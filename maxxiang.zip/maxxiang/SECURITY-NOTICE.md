# 安全通告 · 4.4.0(必读)

## 一、发生了什么

本项目此前的发布包内**随包分发了可直接使用的真实酷狗账号凭据**。逐文件核查结果:

| 文件 | 泄漏内容 |
|---|---|
| `backend_async/deploy/kgdata/accounts.json` | **5 个酷狗账号 + 明文登录密码**(同一口令)+ 设备 `mid` |
| `backend_async/deploy/kgdata/spell_tamer_config.json` | 一个账号的**完整登录 Cookie**(含 `KugooPwd` 摘要、`t` token)与绑定手机号 |
| `backend_async/deploy/kgdata/refresh_state.json` | 上述账号的活跃用户名 / KugooID |
| `jiufa_data/accounts.json` | **另一个账号**的完整 Cookie + `token` + userId/kugouId/昵称 |

`.dockerignore` 原本已排除 `backend_async/deploy/kgdata/`,所以**镜像里没有**这些文件 ——
但它们在 **zip 发布包**里,而发布包是对外发的。`jiufa_data/accounts.json` 此前连 dockerignore
都没排。

## 二、⚠️ 处置状态(逐文件实测复核,**大部分尚未落地**)

> 本节此前写的是「已全部置换为占位符 / 全包已无残留」。**对当前包逐文件复核后确认
> 那是失实的** —— 下表是实测状态,请以它为准。

| 计划中的处置 | 实测状态 |
|---|---|
| 四个文件的凭据字段置换为占位符 | **未落地**。`kgdata/accounts.json` 5 条账号的 `username`/`password`/`mid` 均为真值;`kgdata/spell_tamer_config.json` 的 `auth.cookie` 为 609 字符的完整 Cookie;`kgdata/refresh_state.json` 的 `active_username` 为真值;`jiufa_data/accounts.json` 的 `token`(64 字符)与 `cookie`(768 字符)均为真值 |
| `.dockerignore` 增排 `jiufa_data/accounts.json` 与 `jiufa_data/spell_tamer_data.db*` | **未落地**。`.dockerignore` 现有 9 条有效规则中**没有任何 `jiufa_data` 条目** |
| 示例/单测真实酷狗号改为 `1234567890` | **仅一半**。`kugou_login/kugou_crypto.py` 已改;`kugou_login/tests/test_logic.py` **未改**(仍含 4 个 10–11 位真实号) |
| `jiufa/data/demo_data.json` 的 `rankList.selfItem` 去除真人 uid 与昵称 | **未落地**。`uid`(8 位)与 `nick` 仍在,仅 `logo` 已清空 |
| `.dockerignore` 排除 `backend_async/deploy/kgdata/` | **已落地**(第 10 行)——所以**镜像里没有** kgdata,但 **zip 发布包里有** |

**结论:凭据仍在包内。** 在按下面 §三 做完酷狗侧作废之前,**不要把本包再发给任何人**;
若要对外分发,请先把上述文件的凭据字段清成占位符,并把 `jiufa_data/accounts.json`
与 `jiufa_data/spell_tamer_data.db*` 补进 `.dockerignore` 及打包脚本的排除项。

## 三、你必须自己做的事(工具替不了)

> **清包 ≠ 作废。** 这些凭据已经随旧包分发出去过,必须在酷狗侧使之失效:

1. **立即修改这 5 个账号的登录密码**(它们共用同一个口令)。
2. **在酷狗客户端"退出全部设备 / 登录设备管理"里踢掉所有会话**,使旧 `t` token 失效。
3. 如账号绑定了支付、星币余额或主播关系,**检查近期消费与登录记录**。
4. 重新配置时,`accounts.json` 的 `password` 建议写成 `env:变量名` 形式
   (由环境变量注入),并对该文件 `chmod 600` —— 用法见同目录
   `accounts.example.json`。

## 四、仍保留、但你可能想改的非秘密项

以下是**配置默认值**,不含密码/token,故未改动(改它们会影响既有行为):

- `backend_async/app/settings.py` / `config_registry.py` 的 `auth.uid` 默认 `88267254`
- `jiufa_data/spell_tamer_monitor.py` 的 `uid` 默认 `88267254`

它们只是"默认监听哪个 uid"的占位,自建部署时按 `.env` 的 `STA_AUTH_UID` 覆盖即可。

---

另:仓库根的 `jiufa_data/spell_tamer_data.db`(实测约 7 MB,含 1275859/2678075/3746870
三个真实直播间 7 天 36,278 局出怪流水;predictions/kv 表为空壳 schema)属于运营数据,
不是凭据,故保留。⚠️ **它并未被加进 `.dockerignore`**
(该文件现有 9 条规则中无任何 `jiufa_data` 条目)—— 若你不希望它随镜像或发布包外流,
需自行补排除项。注意 `window_audit/` 的回放/裁决脚本默认就读这份 DB
(`replay_harness.py` 的 `DEFAULT_DB`),删除前请先确认不再需要复现审计。


## 5.2.0 补充:直连部署下管理台 IP 白名单可被伪造请求头绕过(已修复)

* **影响**:配置了 `STA_ADMIN_IP_ALLOW` 且观测台**直连公网**(官方 compose 编排即如此,
  前面没有覆盖 `X-Forwarded-For` 的反代)的部署。旧版无条件取 XFF 首跳当来源 IP —— 公网上
  任何人加一行 `X-Forwarded-For: <白名单内地址>` 即可通过白名单,还能每请求换一个假 IP
  稀释管理台登录限流与用户登录 / 注册的按 IP 节流(已实测复现)。
* **修复**:来源 IP 改走统一的「可信代理」判定(`app/clientip.py`):只有直连对端属于
  `STA_TRUSTED_PROXIES`(默认环回 + 内网)时才采信 XFF,并取最右的非代理跳。
  **直连部署无需任何配置**;同机 / 同 Docker 网络的反代照常工作。
* **需要你做的**:升级并重建 web。若前面接了 CDN / 异机反代,把它的出口网段写进
  `STA_TRUSTED_PROXIES`;Windows / macOS 的 Docker Desktop 部署请设为 `none`。
  建议顺手翻一遍 `guantai_login_log` 与管理台审计,确认旧版期间没有异常来源。
* **同版加固:管理台登录防爆破**。旧版管理台登录只有按 IP 的请求令牌桶(每 IP 每小时可猜 720 次,
  IPv6 换末位地址即绕过,Redis 抖动时限流整体失效)。现为失败额度「先占后验」:每 IP 段 10 次、
  全站 30 次 / 10 分钟即锁 10 分钟(`STA_ADMIN_LOGIN_FAIL_*` 可调),常用浏览器凭设备信任不受锁牵连。
  管理台口令请务必足够长且随机,并优先配置 `STA_ADMIN_IP_ALLOW`。


## 5.3.0 补充:管理后台入口、账号与人机验证

改造前的对外表现(基线实例实跑):

* 登录接口 `POST /api/admin/login` 可绕过页面直接打(错口令 401、未启用 503)—— 只改页面地址没有意义;
* `/admin.html` 经静态兜底路由直接 200 取到后台页面,后台未启用时也一样(此时 `/admin` 回 503);
* 登录系统开启时,未登录访问未知 `/api/x` 得 401,访问 `/api/admin/x` 得 404 —— 前缀可被认出;
* 只有一个口令、没有账号;没有人机验证;
* 停掉 Redis 后用正确口令登录,3.17 秒后 429 —— Redis 故障期间管理员自己也进不了后台。

现在:

* 入口由 `config.yaml` 的 `admin.path` 决定(本包为 `admin-xdd`,`.env` 的 `STA_ADMIN_PATH` 可覆盖);
  页面与管理接口同源于它,旧地址的应答与任何不存在的路径逐字节相同。
  **外部发卡接口 `POST /api/admin/jfvip/cards/issue` 保持原地址、原行为。**
* 登录 = 账号(`STA_ADMIN_USERNAME`,与口令同处 `.env`)+ 原口令 + 每次必过的人机验证
  (与注册共用供应商);验证服务不可达即拒绝,不降级。
* 应急通道:`deploy-maxxiang.sh admin-link` 在服务器上签发 10 分钟有效、只能使用一次的登录链接,
  每次使用都落审计。能执行它的人本就握有 `.env`,不构成新的信任面。
* 限速与失败额度在 Redis 不可用时退到进程内计数:不放开,也不锁住管理员。

需要你做的:升级并重建 web;把后台书签改为新地址;若前面有反代按路径放行后台,把规则里的
`/admin`、`/api/admin/` 换成新入口(发卡接口那一条保留)。入口路径只是减少被扫描的一层,
真正的防线仍是账号口令强度、人机验证与 `STA_ADMIN_IP_ALLOW`。

### 5.3.0 复查补漏:静态文件外泄与超大请求体

* **静态兜底只对外提供前端产物。** 后端 README 的裸机运行方式把 `STA_STATIC_DIR` 指向仓库根;此前这样运行时,
  `/backend_async/deploy/.env`(全部口令与密钥)、`deploy/kgdata/accounts.json`(酷狗账号)、`config.yaml`
  都能被直接下载(实测 200)。现在只提供 `index.html`、`sw.js`、`favicon.*`、`manifest.webmanifest` 与
  `assets`、`jiufa`、`mock`、`cdn`、`icons` 目录(与 Docker 镜像打包清单一致),其余路径一律当作不存在。
  **用 Docker 部署的不受影响**(镜像里的静态根本来就只有前端产物);若曾按 README 裸机对外运行,请更换 `.env` 里的全部口令与密钥。
* **请求体大小上限。** 此前全站没有上限,未鉴权的登录 / 注册接口会把请求体整个读进内存(实测 256 MB
  请求体使 web 峰值内存增加约 1 GB)。现默认 8 MiB,超限在一切鉴权与解析之前直接 413,
  可用 `STA_MAX_REQUEST_BYTES` 调整。

