#!/usr/bin/env python3
"""
Spell Tamer（御剑驯妖 / 驯龙）游戏监控脚本  —— v3.1
"""

import argparse
import copy
import csv
import json
import logging
import logging.handlers
import math
import os
import signal
import sqlite3
import sys
import time
import unicodedata
from collections import Counter, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

#: 脏序列告警的节流表(room -> 上次告警时刻)。模块级,因为桥模式下
#: Predictor 每局重建,实例级去重形同虚设。
_DIRTY_SEQ_WARNED: Dict[str, float] = {}
# 风格类告警的节流表。与 _DIRTY_SEQ_WARNED 同范式,但**键不含房间号** ——
# "风格没实现" / "缺 frontier_planner.py" 是**配置级**问题,一万房会同时命中,
# 按房去重仍会刷到 33 行/s。按"问题身份"去重才对:每进程、每种问题 5 分钟一条。
# (4.9.0 第五轮复查实测:桥模式下 Predictor 每局重建,原来那个实例级去重标志完全
#  失效 —— 200 局刷 200 条,折算 1 万房 ≈ 200 行/s ≈ 1728 万行/天,比
#  RARE_LOG_MULTIPLIER_THRESHOLD 当初要治的 200 万行/天还严重 8.6 倍。)
_STYLE_WARNED: Dict[str, float] = {}

try:                                    # 天花板前沿调度器(纯 Python,零第三方依赖)
    from frontier_planner import ALL_SETS as _FR_SETS, Scheduler as _FrSched, plan as _fr_plan
except ImportError:                     # 与旧部署共存:缺文件时 frontier 风格自动退回原行为
    _FR_SETS = _FrSched = _fr_plan = None

try:
    import requests
except ImportError:
    print("缺少依赖 requests，请先运行:  pip install requests", file=sys.stderr)
    sys.exit(1)



BASE_URL = "https://mapi.tencentmusic.com"
API_PREFIX = "/kugou/spell_tamer.SpellTamerApi"

EP_MAIN_PAGE = f"{API_PREFIX}/MainPage"
EP_GAME_HISTORY = f"{API_PREFIX}/GameHistory"
EP_ROUND_AWARD = f"{API_PREFIX}/RoundAward"
EP_POP_LIST = f"{API_PREFIX}/PopList"
EP_LAMP_LIST = f"{API_PREFIX}/LampList"
EP_RELAY_EVENT = f"{API_PREFIX}/RelayEvent"

DEFAULT_ACTIVITY_ID = 2
CONFIG_FILENAME = "spell_tamer_config.json"
ROUND_STEP = 50001
DRAW_OFFSET_MS = 40_000
END_OFFSET_MS = 50_000

BEASTS_BASE: List[Tuple[int, str, str, int]] = [
    (1, "金羽皇", "御金术", 100),
    (2, "苍梧魔", "御木术", 50),
    (3, "沧溟龙", "御水术", 500),
    (4, "焚天雀", "御火术", 330),
    (5, "镇岳甲", "御土术", 10),
    (6, "白虹骥", "御剑术", 250),
    (7, "踏荒牛", "御道术", 50),
    (8, "青鸾凤", "御丹术", 50),
    (9, "玄兵猿", "御器术", 100),
]

DEFAULT_CUSTOM_IDS: Dict[str, int] = {
    "镇岳甲": 1, "苍梧魔": 2, "焚天雀": 3, "白虹骥": 4, "玄兵猿": 5,
    "金羽皇": 6, "踏荒牛": 7, "青鸾凤": 8, "沧溟龙": 9,
}

RARE_MULTIPLIER_THRESHOLD = 250

DEFAULT_BROWSER_HEADERS = {
    "accept": "application/json",
    "accept-language": "zh-CN,zh;q=0.9",
    "cache-control": "no-cache",
    "content-type": "application/json",
    "origin": "https://game.tme.kugou.com",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "referer": "https://game.tme.kugou.com/",
    "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "user-agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
    ),
}



def parse_kugou_cookie(cookie: str) -> Dict[str, str]:
    """把浏览器 Cookie 串解析成扁平 dict。

    顶层按 ';' 分隔取 key=value(value 里可能还含 '=',只按首个 '=' 切分);
    并把复合值 'KuGoo=KugooID=1&...&t=xxx&...' 里的 '&' 分隔子项一并展开
    (子项与顶层同名时以子项为准),这样 t / KugooID 等都能取到。
    """
    flat: Dict[str, str] = {}
    if not cookie:
        return flat
    for seg in str(cookie).split(";"):
        seg = seg.strip()
        if not seg or "=" not in seg:
            continue
        key, _, val = seg.partition("=")
        key, val = key.strip(), val.strip()
        flat[key] = val
        # 展开 KuGoo 复合值(a=1&b=2&...),票据 t 就藏在这里
        if "&" in val and "=" in val:
            for sub in val.split("&"):
                if "=" not in sub:
                    continue
                sk, _, sv = sub.partition("=")
                flat[sk.strip()] = sv.strip()
    return flat


@dataclass
class AuthConfig:
    app_id: str = "1000756"
    cookie: str = ""
    uid: str = "88267254"
    ticket: str = "PUT_YOUR_FRESH_X_AUTH_TICKET_HERE"
    token_type: str = "1010"

    def __post_init__(self) -> None:
        # 提供了 cookie 时,uid / ticket 以 cookie 为准自动提取:
        #   uid    <- Cookie 中的 KugooID
        #   ticket <- Cookie 中的 t(登录 token)
        if self.cookie:
            jar = parse_kugou_cookie(self.cookie)
            kugoo_id = jar.get("KugooID")
            t = jar.get("t")
            if kugoo_id:
                self.uid = kugoo_id
            if t:
                self.ticket = t

    def to_headers(self) -> Dict[str, str]:
        return {
            "x-auth-app-id": str(self.app_id),
            "x-auth-uid": str(self.uid),
            "x-auth-ticket": str(self.ticket),
            "x-auth-token-type": str(self.token_type),
        }


@dataclass
class PredictionConfig:
    enabled: bool = True
    recent_window: int = 60
    ewma_half_life: float = 30.0
    markov_shrink: float = 6.0
    markov2_shrink: float = 4.0
    omission_gamma: float = 0.5
    hedge_eta: float = 0.15
    hedge_mix: float = 0.02
    max_train: int = 5000
    train_window_hours: float = 24.0   # 预测训练样本只取近 N 小时(<=0 则不限时间,退回 max_train 计数窗)
    accuracy_window: int = 100
    freq_anchor: bool = True
    anchor_window: int = 80
    anchor_drift_floor: float = 0.15
    anchor_drift_ref: float = 0.30
    anchor_lambda_min: float = 0.05
    predict_mode: str = "adaptive"
    adaptive_lambda: float = 0.3
    explore_every: int = 6
    explore_patrol: int = 35
    explore_min_z: float = 0.5
    explore_z0: float = 0.8
    explore_calib: int = 240
    explore_rhythm_w: float = 0.20
    explore_style: str = "frontier"   # 4.9.8 由 "showcase" 改;三层同批(本行/config_registry/config.yaml)
    explore_abstain: float = 0.12
    explore_tie_eps: float = 0.004
    seat_order: str = "recency"
    main_swap_band: float = 0.02
    showcase_kdist: str = "35,40,15"   # 恰好带 1/2/3 只冷门的目标份额(%)
    # ⚠ 语义澄清(4.9.10 审计中钉实):三个数是**恰好** k=1/2/3 的份额;引擎用的
    # cums 才是 k≥1/k≥2/k=3 —— 本值 cums = 90/55/15,达成份额实测逐位跟踪。
    # 4.9.10 由 "45,31.5,13.5" 改来(45,30,15 → 4.9.7 45,31.5,13.5 → 本值):
    # 十一档全量扫描(三房 34,982 成熟配对局,生产代码路径逐局因果回放)证明
    # kdist 只是「命中↔回报」单调权衡曲线上的取点,4.9.7 值(=自然份额中性点)
    # 不是任何指标的最优。本值:四码命中 −1.12pp(52.61%, McNemar p=1e-4)换
    # 回报/注 8.230→8.449(+2.7%)、冷门中 11.51→12.60%、稀有中 1.632→1.830%;
    # 满足产品 4.9.8 三条下限(冷门≥11.66/稀有≥1.68/回报≥8.358)的共五档
    # (本值/40,35,20/30,38,27/25,40,30/0,0,95),本值是其中四码命中最高的一档
    # (=下限约束下的命中最优);6/6 时间×房间切片同号。全表见
    # window_audit/AUDIT-4.9.10-showcase-kdist-全档扫描.md。
    # ⚠ 与 cadence_governor 成对纪律不变:滴水速率就是本键的 cums,关态也读
    # (决定 k 判定阈值);完整回滚到原版 = cadence_governor→0 且本键→"45,30,15"。
    # 解析失败的静默兜底仍是 45,30,15(原版关态刻度,刻意不随默认值走)。
    matched_window: int = 30
    anti_stubborn: int = 1          # 反固执总开关(1=默认开启;0=字节级等价原版)
    # 4.9.7 与 showcase_rotate / repeat_guard 同批翻面。三者是 _DEAD_SWITCH_KEYS
    # 同一组,必须同进同退:只翻其中一个会造出仓库从未测过的中间态。
    # 翻面后裸引擎缺省 == config.yaml 部署刻度(实测逐局四码 300/300 全同),
    # 由 tests/test_config_registry.py::
    # test_prediction_defaults_match_engine_dataclass_except_documented_tiering 钉守。
    # 注:此前那条「裸引擎缺省=逐字节等价原版」的纪律,在 explore_style 缺省由
    # ceiling_adaptive 改为 showcase 时就已不可能成立(实测只回退这两个开关、
    # 风格仍为 showcase 时,与真原版仅 28/300 局相同)—— 故取「等于部署刻度」
    # 这条可验证的不变量,而不是半held 的旧纪律。
    as_alpha: float = 0.08          # 集合选择:连败压力强度(受 mcap 封顶)
    as_alpha_ord: float = 0.14      # 座次排序:压力强度(主/防标签轮转,零EV成本)
    as_mcap_hot: float = 0.12       # 热池集合削发上限(保号1恒驻四码)
    as_mcap_cold: float = 0.18      # 冷池集合削发上限
    as_gamma: float = 0.15         # 在位惯性(赢家恒推·抑制回摆)
    as_pen_cap: int = 8             # 压力封顶
    as_pen_on_hit: int = 0          # 命中局是否也累积压力(0=只在四码未中时累积,赢局不摇席)
    as_breaker: int = 3            # 同串连败熔断阈值(0=关)
    as_khyst: float = 0.05          # k 分位死区
    as_cooldown: int = 0            # 熔断换出号的再入冷却局数(实测负收益,默认关;留作应急开关)
    as_beta: float = 0.3           # 冷位老化(打破5/6垄断,受 agecap 有界)
    as_agecap: int = 24             # 冷位老化封顶局数
    # ── 份额闭环·赤字调度(showcase 身份轮换;总开关=0 时与原版逐字节等价) ──
    # 背景:showcase 的「带几只冷门」(k)有份额闭环(showcase_kdist),但「带哪几只」
    # 是对固定冷池做 argmax(融合概率) —— 冷池内概率序在千局尺度上几乎不翻转,
    # 于是冷位退化成常数(真机三房实测:号5 进四码 72.9%、号9 仅 2.2% 且 100% 靠保底)。
    # 本组刻度给「身份」也加一条与 k 同构的份额闭环:目标份额 ∝ p^eta,用赤字账本
    # (Deficit Round-Robin)驱动,确定性、零随机源、可回测、EV 失真有解析上界。
    showcase_rotate: int = 1        # 总开关(1=默认开启份额闭环;0=字节级等价原版)
    # 4.9.7 起裸引擎缺省即为「开」。此前缺省为 0(未开刀姿态),由部署侧 config.yaml
    # 显式打开;现改为引擎自带默认,单测 test_showcase_rotate::test_config_three_way
    # _consistency 的「裸引擎缺省必须是关」一条已同批改为断言「必须是开」。
    # 回滚 = 本行改回 0 并同批回改该断言(sc_* 各刻度未动,行为可逐字节复现)。
    sc_eta_cold: float = 1.0        # 冷池目标份额 ∝ p^eta(1=按概率 0=均匀 <0=偏倍率 大=趋近原版)
    sc_eta_hot: float = 20.0        # 热池目标份额指数(20≈冻结热位=原版行为)
    sc_floor_cold: float = 0.08     # 每个冷号的份额下限(0=不设)
    sc_floor_hot: float = 0.0       # 每个热号的份额下限
    sc_lambda: float = 0.6          # 赤字→打分强度(乘性 exp(lam*debt);0=只留连推硬帽)
    sc_debt_cap: float = 4.0        # 赤字截断 → EV 失真上界 = exp(lam*cap)
    sc_repeat_cap: int = 3          # 同四码集合连推硬帽(0=关;达阈值强制换血一位)
    sc_beta_off: int = 1            # 轮换开启时置零 as_beta(冷位老化与赤字账本功能重叠)
    sc_fp_depth: int = 12           # 指纹取近 N 局(<=3 即原版 seq[-3:];原版存在碰撞)
    # ── 冷位节拍器(cadence_governor;4.9.7 落地)──────────────────────────────
    # 病灶:k(本局带几只冷门)由「近窗热度自参照分位」判定,而热度信号是长记忆量
    # (M2 窗 60 局 / EWMA 半衰 30 局),叠加 as_khyst 的**双边**死区(上一局 k 更高
    # 时门槛反被调低),于是边际份额达标而时间结构成串。真机三房 36,182 已结算局
    # 实测:k=3 逐局黏滞率 36.8~42.9%(独立假设下应≈13.4%,即黏了约 3 倍)、
    # k>=3 最长连串 22~29 局(约 18~24 分钟)、存在 20 局窗内三冷占满 20 局。
    # 本机制只**后置整形展示的 k**:信号与阈值学习(_kd)一律照吃原始 exc,不受影响。
    # 因出怪序列与 i.i.d. 不可区分(一阶转移 p=0.675、各滞后互信息均在噪声底),
    # 在**保持边际份额不变**的前提下重排时间顺序,对命中率期望值为零影响。
    cadence_governor: int = 1       # 总开关(0=与未改造的 showcase 逐局字节级等价)
    # 4.9.7 默认开启。三房 36,182 已结算局实测(开 vs 关):
    #   k=3 逐局黏滞率 40.54% → 0.02%(独立期望 13.4%,原先黏了 3 倍)
    #   k>=3 最长连串 29 → 2 局(约 24 分钟 → 100 秒)
    #   20 局窗内最大三冷局数 20 → 4
    #   总命中 53.71% → 53.61%(-0.10pp)、倍率加权/注 8.2923 → 8.3009(+0.0086)
    # 即:节奏问题彻底解决,命中损失可忽略,倍率回报略有改善。
    # ⚠ 回滚需**两键同批**:cadence_governor→0 且 showcase_kdist→"45,30,15"
    #   (kdist 关态也读,决定 k 的判定阈值)。「只关开关」中间态实测(4.9.7,
    #   当时开态刻度 45,31.5,13.5)与改造前基线仅 5,162/12,064 局相同;
    #   两键同批改回才是 12,064/12,064 全同。4.9.10 默认改 35,40,15 后
    #   「只关开关」是另一个未测中间态,回滚纪律不变:两键同批。
    # 三层(引擎缺省/注册表/config.yaml)必须同值,由 tests/test_config_registry.py 两条守卫钉住。
    cg_run3: int = 2                # k>=3 最长连串(局)
    cg_run2: int = 6                # k>=2 最长连串(局)
    cg_cap3: float = 1.9            # 三冷令牌桶容量(⇒ 任意 W 局内 k=3 局数 <= rate3*W+cap3)
    cg_cap2: float = 3.2            # 双冷令牌桶容量
    cg_force3: float = 1.5          # 软促发阈:三冷桶攒到此值即主动推一次三冷
    cg_force2: float = 1.8          # 软促发阈:双冷桶
    cg_rfloor: float = 0.30         # 硬保底触发的「距桶满余量」(阈=cap-rfloor,并不低于 force)
    # 4.9.7 与 showcase_rotate 同批翻面。二者**必须成对**:深度 3 的指纹碰撞会让
    # 相邻两局整局复用并**跳过 miss4/赤字推进**,而赤字账本正是轮换机制的心脏 ——
    # 「轮换开 + 深度 3」是本仓库从未审计过的组合(测试夹具 ON 里二者一直是 1+12)。
    # 回滚必须同批:本行改回 3 且 showcase_rotate 改回 0。
    # 冷池成员(自定义编号,逗号分隔,必须恰好 5 个 1~9 的不重复号)。原引擎把
    # (3,4,5,6,9) 硬编码在 showcase / matched / 熔断三处,而 custom_beast_ids 是
    # 可配置的 —— 换编号映射即整套冷热判定错位(现行配置恰好对齐,属「碰巧正确」)。
    # 落成配置项后由部署侧显式声明,并由 test_showcase_rotate 的「倍率推导」钉守住:
    # 它必须等于 custom_beast_ids 下倍率最高的 5 只妖兽的编号。
    showcase_cold_ids: str = "3,4,5,6,9"
    # ── 重现观察期(《灵机推演重现观察期优化方案.md》;三房 7 天 36,278 局定稿)──
    # 病灶:稀有冷号(如 9 号 500x)刚开出的下一局,M2/M3 近因模型把它的短窗概率
    # 抬高 3~5 倍,叠加轮换赤字(常年顶着 ±cap)的 e^{λ·debt}≈11× 加成,乘积峰值
    # 恰落在「刚开出之后」—— 于是四码在最扎眼的时刻仍带它、甚至借 85 分位 z 升座
    # 主位(真机生产口径回放,三房 34,982 成熟局:上局出稀有 → 本局仍带 = 3/4/9 号
    # 各 498/749/291 次,其中 628 次进主位)。
    # 实地核查(1275859/2678075/3746870 三房 7 天):**九兽危险率对间隔全部平坦**
    # (|z|≤1.8;9 号刚出后再出 3.02% ≈ 基率 3.56%,z−1.1,N=1292;4 号 6.63% ≈
    # 6.52%,z+0.2,N=2367;9×9 转移 χ²=67.0/df64 与独立不可区分)⇒ 刚出后的
    # 短窗概率飙升没有预测力,把该号的份额**推迟**到间隔更大的时刻统计等价、观感
    # 更优。观察期只整形「何时带」,不动份额闭环(赤字照常累积,期满即优先补发)。
    repeat_guard: int = 1           # 总开关(1=默认开启;0=字节级等价原版;showcase 风格域内生效)
    rg_theta: float = 0.35          # 观察期长度 = ceil(θ/p̂) 局(按 24h 长程频率缩放)
    rg_cap: int = 20                # 观察期封顶(局);当前频率下 L(9)=ceil(.35/.036)≈10
                                    # 已低于封顶,cap 是频率骤降时防观察期失控的安全阀
    rg_pmax: float = 0.075          # 仅 24h 滑窗频率 ≤ 此值的号受观察期约束 ——「当下
                                    # 稀有档」语义:330x/500x(频带 3.1~6.3%/2.7~4.7%)
                                    # 全时段在罩内;4 号(5.0~8.3%)与 5/6 号(下探 7.4/
                                    # 6.5%)按其实时稀有度自适应进出。九兽危险率全平坦
                                    # ⇒ 罩谁都零 EV 成本(34,982 局配对:命中 +0.04pp
                                    # p=0.833、主中 +0.40pp、稀有命中持平)。历史注:旧
                                    # 样本曾见 4 号紧随 9.3%(z+2.7)的真扎堆并为此定过
                                    # 0.05 豁开,7 天大样本(N=2367)不复现(6.63%,z+0.2)
                                    # —— 这类时段性扎堆改由下方四关豁免按窗放行
    rg_seat_damp: float = 0.25      # 观察期内座次降权(只轮转主/防标签,零 EV 成本)
    rg_minm: int = 30               # 房间自证豁免:紧随样本下限
    rg_zpos: float = 2.5            # 房间自证豁免:z 门槛(另有 k≥4 与 1.6× 基率两道硬关)
    # ── 天花板前沿调度(frontier;explore_style="frontier" 时生效)──────────────
    # 依据:真机 36,278 局(三房 7 天)实地核查证明出怪与 i.i.d. 多项分布不可区分
    # (21 项规律检验 p<0.05 者 0 项;转移矩阵滞后 1/2/3/5/10 全部 p>0.2;九兽危险率
    # 对间隔 |z|≤1.8;间隔几何拟合全部 p≥0.088)。该前提下有可证结论:策略的长期期望
    # 只取决于它使用 126 个四码集合的频率分布 x ⇒ 最优策略 = 一个线性规划的解,
    # 这就是数学天花板。本组刻度即该 LP 的约束。
    # 目标口径(全部为"每局的期望值",与命中率同量纲):
    #   fr_cold_min 冷门(showcase_cold_ids)命中率下限
    #   fr_rare_min 稀有(fr_rare_ids)命中率下限
    #   fr_ret_min  每注回报下限 = Σ_{S} p·倍率 / 4(倍率单位代理,见 frontier_planner)
    # 默认刻度来自"因果滚动实测四项全不劣于现行 showcase 口径"的最小安全余量扫描
    # (δ=8%:命中 53.71→53.93%、冷门 11.41→12.01%、稀有 1.669→1.907%、回报
    #  8.2923→8.5651;δ=0 时冷门/回报会实测掉队,故余量不可去)。
    # 4.9.7:三条聚合下限的 dataclass 缺省由 4.8.9 的 0.1232/0.018/8.624 对齐为 0.0。
    # 4.9.0 已用逐号份额地板(fr_share_floors)取代聚合下限,config.yaml 与注册表
    # 早已是 0.0,只有引擎缺省停在旧值 —— 三层曾各持一值。它们只在
    # explore_style="frontier" 域内被读取,4.9.7 当时默认风格是 showcase ⇒ 那次对齐零行为变化。
    # 〔4.9.8 更正:默认已改为 "frontier",这三条现在**是活的**,取值见下方 4.9.8 段。〕
    # ── 4.9.8 三条聚合下限重新启用(0.0 → 下列值),同批 fr_share_floors 清空 ──────
    #   出厂逐号地板硬钉号9(真机 p=3.561%,九号最低)进 30% 的局、号3 进 40%,把 LP
    #   自由度吃光 —— 那是 4.9.7 判 frontier 落败的真因。清空地板后改回聚合下限口径。
    #   取值 = 欠达比反解迭代两步,再经**严格样本外协议**(前2/3选优→后1/3验证,
    #   20 个候选刻度)定稿 —— 验证段唯一仍满足「四项全不劣」的就是本组。
    #   三房 36,182 配对局实测(vs showcase):命中 +1.009pp(6/6 时间段全正,
    #   段级 t=+3.82, McNemar p=0.0020)/ 主中 +1.689pp / 冷门 +0.147pp /
    #   稀有 +0.180pp / 回报 +1.97%,五项无一为负。
    #   ⚠ 冷门是最脆的一项(6 段只 3 段为正);可主张「不劣」,不可宣传「更准」。
    fr_cold_min: float = 0.116633 # 冷门命中率下限(两步反解;样本外验证段 +0.091pp)
    fr_rare_min: float = 0.01683  # 稀有命中率下限(两步反解;样本外验证段 +0.108pp)
    fr_ret_min: float = 8.358387  # 每注回报下限(两步反解;样本外验证段 +0.71%)
    fr_share_min: float = 0.08      # 每号进四码份额下限。**不可设 0** —— 见 config.yaml 同名段:
                                    # 设 0 时号9 曾连续 4273 局不进四码(约 59 小时)
    fr_share_max: float = 0.8       # 每号进四码份额上限(数学下界 4/9≈0.4444)
    # 主位(主2)份额下限。frontier 的主位规则是"四码中 p̂ 最高的两只",于是低频号
    # **永远排不进前二**:真机实测 sm=0.08 时号3/4/9 的主位份额恒为 0.0%、
    # 主位饥饿 = 全程 4273 局(≈59 小时一次没当过主推);showcase 靠 seat_order
    # + main_swap_band 还能给它们 3~5%。**默认 0 = 保持纯 p̂ 序,行为不变**;
    # 设 >0 则启用主位赤字轮转:某号在四码里累积够配额就顶进主位。
    # 代价见 config.yaml 同名段(主中率会掉,因为主位不再总是最高概率的两只)。
    fr_main_share_min: float = 0.08
    fr_replan: int = 200            # 每 N 局用最新 p̂ 重解一次 LP(0=只在首局解一次)
    fr_rare_ids: str = "3,9"        # 稀有池(自定义编号);默认=倍率 ≥330x 的两只
    fr_share_floors: str = ""   # 逐号份额地板 "3:0.40,9:0.30,4:0.20"；空=不启用
    fr_mult: str = ""               # 号位倍率表 "1:10,2:50,…";留空则由 BEASTS_BASE+
                                    # DEFAULT_CUSTOM_IDS 推导(测试 test_frontier 钉死一致)
    # ── 冷启动自适应收缩(4.9.4;只作用于 frontier 风格的概率口径)────────────────
    #   病灶:frontier 的唯一概率输入是 _m1_global(seq) = 归一化(计数+2.0),那个
    #   「+2.0」是**均匀分布先验**(等效 18 局)。真机三房 36,278 局实测,均匀分布距
    #   实盘真表 ‖·‖₁=0.4308 —— 是九个候选先验里最差的一个。房间刚起抓时(n≈30~200)
    #   它占 10%~37% 权重,把 p̂ 硬拽向 11.11%/号,LP 随即落到错误顶点,而 fr_replan=200
    #   会让这个错解**再挺 200 局**。真机回放实测冷启动期望命中 49.30%(本身就在 50%
    #   以下),要跑到第 400~450 局(≈6 小时)才爬回稳态 53.00%。
    #   处方:在现行 Laplace 估计之上做**自适应收缩**(见 _p_frontier 的公式)。
    #   ══ ⚠ 4.9.9 更正:原文写的「n→∞ → λ→0」**是错的**,而且错得有后果 ══════════
    #   λ 的 n→∞ 极限**取决于先验对不对**,不是无条件塌向 0:
    #     · p₀ = 真分布 ⇒ 分母 (n−1)·Σ(p̂−p₀)² 的期望 ≈ (n−1)/n·(1−Σp²) → 分子
    #       ⇒ **λ→1**,收缩**永不退场**,先验全程盖过数据;
    #     · p₀ ≠ 真分布 ⇒ 分母含 (n−1)·‖p−p₀‖² 随 n 线性发散 ⇒ λ→0(此半句原文正确)。
    #   数值实证(数据由 p 生成、p₀=p,直接跑本函数算式):n=10³/10⁴/10⁵/10⁶ 的 λ
    #   **中位数恒为 1.000**、均值 0.85~0.94;换成官方公示表当 p₀(‖·‖₂=0.0281)时
    #   n=10³/10⁴/10⁵ 才依次给出 0.542/0.104/0.011。真机三房逐局实测(24h 窗)λ
    #   中位数 1.000、全期均值 0.82~0.86、λ=1.0 的局占 45~58%。
    #   ⇒ 本项**不是**「冷启动收缩」,是**全程生效的固定表覆盖**。原文那半句会让人
    #     误以为稳态无风险,而实测代价恰恰全在稳态段(见 config.yaml 同名段 4.9.9 复核)。
    #   **λ=0 时逐位等于现行值** ⇒ prior_shrink=False 与改造前逐局字节级等价
    #   (tests/test_prior_shrink.py 钉住;该文件另有一条守卫禁止这句错话回潮)。
    #   ⚠ **出厂缺省 False**。4.9.4 给的理由是「实测口径 −0.29pp 与期望口径 +2.53pp
    #   打架、样本不足以判定」;4.9.9 在现行 4.9.8 刻度下用四张先验表重测,**两个口径
    #   已同向为负**,判据不再悬空 —— 详见 config.yaml 同名段。开之前仍请自行 A/B。
    prior_shrink: bool = False
    # 先验概率表 "号:概率,…"(和须≈1)。默认值 = 真机三房 7 天 36,278 局实盘频率,
    # **不是**官方公示表 —— 官方表与实盘 χ²=726.6 p≈0(9号 500x 实盘 3.56% vs 公示
    # 2.00% z=+21.2;3号 330x 实盘 4.93% vs 公示 3.50% z=+14.8)。留空 = 关闭收缩。
    prior_table: str = ("1:0.183748,2:0.156955,3:0.049286,4:0.065246,5:0.093307,"
                        "6:0.096725,7:0.157203,8:0.161916,9:0.035614")


@dataclass
class MonitorConfig:
    activity_id: int = DEFAULT_ACTIVITY_ID
    room_id: str = "2678075"
    request_timeout: float = 15.0
    verify_tls: bool = True
    proxy: Optional[str] = None

    award_delay: float = 2.5
    award_retry_interval: float = 1.5
    award_max_retries: int = 6
    mainpage_retry: float = 5.0
    history_every_rounds: int = 5

    fetch_lamp: bool = True
    log_file: str = "spell_tamer_monitor.log"
    data_file: str = "spell_tamer_events.jsonl"
    db_file: str = "spell_tamer_data.db"
    log_level: str = "INFO"

    custom_beast_ids: Dict[str, int] = field(default_factory=lambda: dict(DEFAULT_CUSTOM_IDS))
    prediction: PredictionConfig = field(default_factory=PredictionConfig)
    auth: AuthConfig = field(default_factory=AuthConfig)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "MonitorConfig":
        d = dict(d)
        auth_d = d.pop("auth", {}) or {}
        pred_d = d.pop("prediction", {}) or {}
        cfg = cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})
        cfg.auth = AuthConfig(**{k: v for k, v in auth_d.items()
                                 if k in AuthConfig.__dataclass_fields__})
        cfg.prediction = PredictionConfig(**{k: v for k, v in pred_d.items()
                                             if k in PredictionConfig.__dataclass_fields__})
        if not cfg.custom_beast_ids:
            cfg.custom_beast_ids = dict(DEFAULT_CUSTOM_IDS)
        return cfg

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def write_config_template(path: str) -> None:
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                old = json.load(f)
            merged = MonitorConfig.from_dict(old).to_dict()
            old_pred = (old.get("prediction") or {})
            if "explore_tie_eps" not in old_pred and \
                    old_pred.get("explore_style") == "norm_cold":
                merged["prediction"]["explore_style"] = "ceiling_adaptive"
                print("↻ 检测到 v2.x 的 norm_cold 风格, 已迁移为 ceiling_adaptive"
                      " (v3.0 迁移落点;注意 4.9.8 起引擎默认风格是 frontier)"
                      " (如确需旧行为, 可在配置中改回 norm_cold)")
            with open(path, "w", encoding="utf-8") as f:
                json.dump(merged, f, ensure_ascii=False, indent=2)
            print(f"✅ 已在保留旧值的基础上补齐新字段: {path}")
            return
        except Exception:
            pass
    with open(path, "w", encoding="utf-8") as f:
        json.dump(MonitorConfig().to_dict(), f, ensure_ascii=False, indent=2)
    print(f"✅ 已生成配置模板: {path}")
    print("请编辑后重点填写：auth.ticket / auth.uid / room_id")


def load_config(path: str) -> MonitorConfig:
    if not os.path.exists(path):
        print(f"❌ 找不到配置文件: {path}")
        print(f"   请先运行:  python {os.path.basename(sys.argv[0])} --init")
        sys.exit(1)
    with open(path, "r", encoding="utf-8") as f:
        return MonitorConfig.from_dict(json.load(f))



class BeastCatalog:
    def __init__(self, custom_ids: Dict[str, int]):
        names = [b[1] for b in BEASTS_BASE]
        if sorted(custom_ids.get(n) for n in names) != list(range(1, 10)):
            raise ValueError(f"custom_beast_ids 必须给 9 只妖兽分配 1~9 的不重复编号: {custom_ids}")
        self.name2official = {b[1]: b[0] for b in BEASTS_BASE}
        self.official2name = {b[0]: b[1] for b in BEASTS_BASE}
        self.name2mult = {b[1]: b[3] for b in BEASTS_BASE}
        self.name2spell = {b[1]: b[2] for b in BEASTS_BASE}
        self.name2custom = {n: int(custom_ids[n]) for n in names}
        self.custom2name = {v: k for k, v in self.name2custom.items()}
        self.official2custom = {self.name2official[n]: c for n, c in self.name2custom.items()}

    def resolve(self, official_id: Any = None, name: str = "") -> Tuple[Optional[int], str, Optional[int], Optional[int]]:
        """返回 (official_id, name, custom_id, multiplier)。以官方id优先，名字兜底。"""
        try:
            oid = int(official_id) if official_id not in (None, "", 0, "0") else None
        except (TypeError, ValueError):
            oid = None
        if oid in self.official2name:
            nm = self.official2name[oid]
            return oid, nm, self.name2custom[nm], self.name2mult[nm]
        if name in self.name2official:
            return self.name2official[name], name, self.name2custom[name], self.name2mult[name]
        return oid, name or "?", None, None

    def ordered_names(self) -> List[str]:
        """按自定义编号 1..9 升序返回妖兽名。"""
        return [self.custom2name[i] for i in range(1, 10)]



def now_ms() -> int:
    return int(time.time() * 1000)


# ── 时区:整项目统一北京时间(UTC+8,无夏令时) ────────────────────────────────
# 用固定偏移而非 zoneinfo/tzdata:不依赖系统时区数据库(Windows 裸机同样生效),
# 且中国无夏令时,固定 +8 永远正确。所有落库/展示的"本地时间"(draw_local /
# date_local / created_at / 日界 00:00)一律以此为准,与部署机器时区无关。
BEIJING_TZ = timezone(timedelta(hours=8), "Asia/Shanghai")


def bj_now() -> datetime:
    """当前北京时间(tz-aware)。"""
    return datetime.now(BEIJING_TZ)


def ms_to_local(ms: Any, fmt: str = "%H:%M:%S") -> str:
    try:
        return datetime.fromtimestamp(int(ms) / 1000, tz=BEIJING_TZ).strftime(fmt)
    except (ValueError, TypeError, OSError):
        return "?"


def ms_to_date(ms: int) -> str:
    try:
        return datetime.fromtimestamp(ms / 1000, tz=BEIJING_TZ).strftime("%Y-%m-%d")
    except (ValueError, TypeError, OSError):
        return "?"


def fmt_rid(rid: Any) -> str:
    """roundId 即开局毫秒时间戳，日志展示时附上人类可读时间文本。"""
    try:
        r = int(rid)
        if r > 1_000_000_000_000:
            return f"{r}({ms_to_local(r)}开局)"
        return str(rid)
    except (TypeError, ValueError):
        return str(rid)


def day_bounds_ms(date_str: str) -> Tuple[int, int]:
    """北京日期 -> 当天 [00:00, 24:00) 的毫秒时间戳区间(按北京时间日界)。"""
    d = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=BEIJING_TZ)
    start = int(d.timestamp() * 1000)
    return start, start + 86_400_000


def wlen(s: str) -> int:
    """东亚宽度：全角算2，保证含中文表格对齐。"""
    return sum(2 if unicodedata.east_asian_width(ch) in "FW" else 1 for ch in s)


def wpad(s: str, width: int, align: str = "<") -> str:
    pad = max(0, width - wlen(s))
    if align == ">":
        return " " * pad + s
    if align == "^":
        left = pad // 2
        return " " * left + s + " " * (pad - left)
    return s + " " * pad


def parse_dt(text: str) -> datetime:
    """把用户输入的墙钟时间按**北京时间**解读(tz-aware,.timestamp() 换算无歧义)。"""
    for f in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, f).replace(tzinfo=BEIJING_TZ)
        except ValueError:
            continue
    raise ValueError(f"无法解析时间: {text!r}，支持 'YYYY-MM-DD[ HH:MM[:SS]]'")



class SpellTamerClient:
    def __init__(self, cfg: MonitorConfig, logger: logging.Logger):
        self.cfg = cfg
        self.log = logger
        self.session = requests.Session()
        headers = dict(DEFAULT_BROWSER_HEADERS)
        headers.update(cfg.auth.to_headers())
        self.session.headers.update(headers)
        if cfg.proxy:
            self.session.proxies = {"http": cfg.proxy, "https": cfg.proxy}

    def _post(self, endpoint: str, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        name = endpoint.split("/")[-1]
        try:
            resp = self.session.post(
                BASE_URL + endpoint,
                data=json.dumps(payload, separators=(",", ":")),
                timeout=self.cfg.request_timeout,
                verify=self.cfg.verify_tls,
            )
        except requests.RequestException as e:
            self.log.error(f"[{name}] 请求异常: {e}")
            return None

        err_code = resp.headers.get("X-Error-Code") or resp.headers.get("x-error-code")
        err_msg = (resp.headers.get("X-Error-Message")
                   or resp.headers.get("X-Error-Msg")
                   or resp.headers.get("x-error-message"))
        if err_code and err_code not in ("0", ""):
            self.log.warning(f"[{name}] 业务错误 code={err_code} msg={err_msg}")

        if resp.status_code != 200:
            body = resp.text[:200]
            if '"code":100005' in body or "本局已结束" in body:
                self.log.info(f"[{name}] 本局刚结束(服务端衔接窗口)，稍后重试")
                return None
            self.log.warning(f"[{name}] HTTP {resp.status_code}: {body}")
            if resp.status_code in (401, 403):
                self.log.error("⚠️  x-auth-ticket 可能已过期，请重新抓包更新配置。")
            return None

        try:
            return resp.json()
        except ValueError:
            if not resp.text.strip():
                return {}
            self.log.debug(f"[{name}] 非 JSON 响应: {resp.text[:200]}")
            return {"_raw": resp.text}

    def main_page(self) -> Optional[Dict[str, Any]]:
        return self._post(EP_MAIN_PAGE, {"activityId": self.cfg.activity_id,
                                         "roomId": self.cfg.room_id})

    def game_history(self) -> Optional[Dict[str, Any]]:
        return self._post(EP_GAME_HISTORY, {"activityId": self.cfg.activity_id,
                                            "roomId": self.cfg.room_id})

    def round_award(self, round_id: str) -> Optional[Dict[str, Any]]:
        return self._post(EP_ROUND_AWARD, {"activityId": self.cfg.activity_id,
                                           "roundId": str(round_id),
                                           "roomId": self.cfg.room_id})

    def pop_list(self) -> Optional[Dict[str, Any]]:
        return self._post(EP_POP_LIST, {"activityId": self.cfg.activity_id})

    def lamp_list(self) -> Optional[Dict[str, Any]]:
        return self._post(EP_LAMP_LIST, {"activityId": self.cfg.activity_id,
                                         "roomId": self.cfg.room_id})



SCHEMA = """
CREATE TABLE IF NOT EXISTS rounds (
    room_id     TEXT    NOT NULL,
    round_id    INTEGER NOT NULL,
    beast_name  TEXT    NOT NULL,
    official_id INTEGER,
    custom_id   INTEGER,
    multiplier  INTEGER,
    start_ms    INTEGER,
    draw_ms     INTEGER,
    draw_local  TEXT,
    date_local  TEXT,
    source      TEXT,
    created_at  TEXT,
    PRIMARY KEY (room_id, round_id)
);
CREATE INDEX IF NOT EXISTS idx_rounds_room_draw ON rounds(room_id, draw_ms);
CREATE INDEX IF NOT EXISTS idx_rounds_room_date ON rounds(room_id, date_local);

CREATE TABLE IF NOT EXISTS predictions (
    room_id     TEXT    NOT NULL,
    round_id    INTEGER NOT NULL,          -- 被预测的目标局
    main_ids    TEXT,                      -- JSON [自定义编号 x2]
    guard_ids   TEXT,                      -- JSON [自定义编号 x2]
    detail      TEXT,                      -- JSON 各模型概率明细
    created_at  TEXT,
    actual_custom_id INTEGER,
    hit         TEXT,                      -- main / guard / miss / NULL=未开
    PRIMARY KEY (room_id, round_id)
);

CREATE TABLE IF NOT EXISTS kv (
    room_id TEXT NOT NULL,
    k       TEXT NOT NULL,
    v       TEXT,
    PRIMARY KEY (room_id, k)
);
"""


class RoundStore:
    def __init__(self, db_file: str, catalog: BeastCatalog):
        self.cat = catalog
        self.conn = sqlite3.connect(db_file, check_same_thread=False)
        try:
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA busy_timeout=5000")
            self.conn.execute("PRAGMA synchronous=NORMAL")
        except sqlite3.Error:
            pass
        self.conn.executescript(SCHEMA)
        self.conn.commit()
        self._writes = 0

    def checkpoint(self, mode: str = "PASSIVE") -> None:
        """把 -wal 中的数据落回主 .db 文件（备份/拷库前的一致性保障）。"""
        try:
            self.conn.execute(f"PRAGMA wal_checkpoint({mode})")
        except sqlite3.Error:
            pass

    def add_round(self, room_id: str, round_id: int, official_id: Any,
                  beast_name: str, source: str) -> bool:
        oid, name, cid, mult = self.cat.resolve(official_id, beast_name)
        if not name or name == "?":
            return False
        start_ms = int(round_id)
        draw_ms = start_ms + DRAW_OFFSET_MS
        cur = self.conn.execute(
            "INSERT OR IGNORE INTO rounds (room_id, round_id, beast_name, official_id,"
            " custom_id, multiplier, start_ms, draw_ms, draw_local, date_local, source, created_at)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (str(room_id), int(round_id), name, oid, cid, mult, start_ms, draw_ms,
             ms_to_local(draw_ms, "%Y-%m-%d %H:%M:%S"), ms_to_date(draw_ms),
             source, bj_now().isoformat(timespec="seconds")))
        self.conn.commit()
        if cur.rowcount > 0:
            self._writes += 1
            if self._writes % 50 == 0:
                self.checkpoint()
        return cur.rowcount > 0

    def has_round(self, room_id: str, round_id: int) -> bool:
        r = self.conn.execute("SELECT 1 FROM rounds WHERE room_id=? AND round_id=?",
                              (str(room_id), int(round_id))).fetchone()
        return r is not None

    def sequence(self, room_id: str, limit: Optional[int] = None,
                 since_ms: Optional[int] = None) -> List[int]:
        """按时间升序返回自定义编号序列（预测训练用）。
           since_ms 给定时只取该时刻及以后开局的回合(即「近 N 小时」训练窗)。"""
        sql = "SELECT custom_id FROM rounds WHERE room_id=? AND custom_id IS NOT NULL"
        args = [str(room_id)]
        if since_ms:
            sql += " AND start_ms IS NOT NULL AND start_ms >= ?"
            args.append(int(since_ms))
        sql += " ORDER BY round_id DESC"
        if limit:
            sql += f" LIMIT {int(limit)}"
        rows = self.conn.execute(sql, tuple(args)).fetchall()
        return [r[0] for r in reversed(rows)]

    def day_rows(self, room_id: str, date_local: str) -> List[Tuple[int, int]]:
        rows = self.conn.execute(
            "SELECT round_id, custom_id FROM rounds"
            " WHERE room_id=? AND date_local=? AND custom_id IS NOT NULL"
            " ORDER BY round_id ASC", (str(room_id), date_local)).fetchall()
        return [(r[0], r[1]) for r in rows]

    def query_rows(self, room_id: Optional[str], since_ms: Optional[int] = None,
                   until_ms: Optional[int] = None, date_local: Optional[str] = None
                   ) -> List[sqlite3.Row]:
        self.conn.row_factory = sqlite3.Row
        conds, args = [], []
        if room_id and room_id != "all":
            conds.append("room_id=?"); args.append(str(room_id))
        if date_local:
            conds.append("date_local=?"); args.append(date_local)
        if since_ms is not None:
            conds.append("draw_ms>=?"); args.append(int(since_ms))
        if until_ms is not None:
            conds.append("draw_ms<=?"); args.append(int(until_ms))
        where = ("WHERE " + " AND ".join(conds)) if conds else ""
        rows = self.conn.execute(
            f"SELECT * FROM rounds {where} ORDER BY room_id, round_id ASC", args).fetchall()
        self.conn.row_factory = None
        return rows

    def rooms(self) -> List[str]:
        return [r[0] for r in self.conn.execute(
            "SELECT DISTINCT room_id FROM rounds ORDER BY room_id").fetchall()]

    def save_prediction(self, room_id: str, round_id: int, main_ids: List[int],
                        guard_ids: List[int], detail: Dict[str, Any]) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO predictions"
            " (room_id, round_id, main_ids, guard_ids, detail, created_at,"
            "  actual_custom_id, hit)"
            " VALUES (?,?,?,?,?,?,"
            "  (SELECT actual_custom_id FROM predictions WHERE room_id=? AND round_id=?),"
            "  (SELECT hit FROM predictions WHERE room_id=? AND round_id=?))",
            (str(room_id), int(round_id), json.dumps(main_ids), json.dumps(guard_ids),
             json.dumps(detail), bj_now().isoformat(timespec="seconds"),
             str(room_id), int(round_id), str(room_id), int(round_id)))
        self.conn.commit()

    def fill_prediction_outcome(self, room_id: str, round_id: int,
                                actual_cid: int) -> Optional[Dict[str, Any]]:
        """出怪后回填命中情况；返回该预测行(dict)供权重更新，不存在返回 None。"""
        row = self.conn.execute(
            "SELECT main_ids, guard_ids, detail, hit FROM predictions"
            " WHERE room_id=? AND round_id=?", (str(room_id), int(round_id))).fetchone()
        if not row:
            return None
        main_ids = json.loads(row[0] or "[]")
        guard_ids = json.loads(row[1] or "[]")
        hit = "main" if actual_cid in main_ids else ("guard" if actual_cid in guard_ids else "miss")
        already = row[3]
        self.conn.execute(
            "UPDATE predictions SET actual_custom_id=?, hit=? WHERE room_id=? AND round_id=?",
            (int(actual_cid), hit, str(room_id), int(round_id)))
        self.conn.commit()
        return {"main_ids": main_ids, "guard_ids": guard_ids,
                "detail": json.loads(row[2] or "{}"), "hit": hit,
                "first_time": already is None}

    def accuracy(self, room_id: str, last_n: int) -> Tuple[int, int, int]:
        """返回 (评估局数, 主命中数, 主+防命中数)。"""
        rows = self.conn.execute(
            "SELECT hit FROM predictions WHERE room_id=? AND hit IS NOT NULL"
            " ORDER BY round_id DESC LIMIT ?", (str(room_id), int(last_n))).fetchall()
        n = len(rows)
        main = sum(1 for r in rows if r[0] == "main")
        cover = sum(1 for r in rows if r[0] in ("main", "guard"))
        return n, main, cover

    def accuracy_between(self, room_id: str, start_ms: int, end_ms: int) -> Tuple[int, int, int]:
        """指定出怪时间区间内的命中率（如: 当天实测）。round_id+40000 即出怪时刻。"""
        rows = self.conn.execute(
            "SELECT hit FROM predictions WHERE room_id=? AND hit IS NOT NULL"
            " AND round_id >= ? AND round_id < ?",
            (str(room_id), int(start_ms) - DRAW_OFFSET_MS, int(end_ms) - DRAW_OFFSET_MS)
        ).fetchall()
        n = len(rows)
        main = sum(1 for r in rows if r[0] == "main")
        cover = sum(1 for r in rows if r[0] in ("main", "guard"))
        return n, main, cover

    def gaps(self, room_id: str, since_ms: Optional[int] = None
             ) -> List[Tuple[int, int]]:
        """扫描相邻 roundId 缺口。返回 [(缺口内首个缺失rid, 缺失局数), ...]。"""
        sql = "SELECT round_id FROM rounds WHERE room_id=?"
        params: List[Any] = [str(room_id)]
        if since_ms:
            sql += " AND round_id >= ?"
            params.append(int(since_ms))
        sql += " ORDER BY round_id ASC"
        rids = [r[0] for r in self.conn.execute(sql, params).fetchall()]
        out: List[Tuple[int, int]] = []
        for a, b in zip(rids, rids[1:]):
            diff = b - a
            if diff > ROUND_STEP and diff % ROUND_STEP == 0:
                out.append((a + ROUND_STEP, diff // ROUND_STEP - 1))
        return out

    def kv_get(self, room_id: str, key: str) -> Optional[str]:
        r = self.conn.execute("SELECT v FROM kv WHERE room_id=? AND k=?",
                              (str(room_id), key)).fetchone()
        return r[0] if r else None

    def kv_set(self, room_id: str, key: str, value: str) -> None:
        self.conn.execute("INSERT OR REPLACE INTO kv (room_id,k,v) VALUES (?,?,?)",
                          (str(room_id), key, value))
        self.conn.commit()

    def junk_scan(self, room_id: str) -> Dict[str, List[int]]:
        """本地体检: 找疑似垃圾行。offgrid=不在等差网格上(删); future=离谱未来局(删);
        unknown=妖兽无法识别(仅报告不删——可能是平台新增妖兽的有效记录)。"""
        rows = self.conn.execute(
            "SELECT round_id, custom_id FROM rounds WHERE room_id=? ORDER BY round_id",
            (str(room_id),)).fetchall()
        out: Dict[str, List[int]] = {"offgrid": [], "unknown": [], "future": []}
        if not rows:
            return out
        residues = Counter(r[0] % ROUND_STEP for r in rows)
        majority, maj_n = residues.most_common(1)[0]
        grid_trusted = maj_n >= 20
        horizon = now_ms() + 6 * 3600 * 1000
        for rid, cid in rows:
            if grid_trusted and rid % ROUND_STEP != majority:
                out["offgrid"].append(rid)
            elif rid > horizon:
                out["future"].append(rid)
            elif cid is None:
                out["unknown"].append(rid)
        return out

    def delete_rounds(self, room_id: str, rids: List[int]) -> int:
        """删除指定局并复位其关联预测的结算(actual/hit 置空，待真实数据到来再结算)。"""
        n = 0
        for rid in rids:
            cur = self.conn.execute("DELETE FROM rounds WHERE room_id=? AND round_id=?",
                                    (str(room_id), int(rid)))
            n += cur.rowcount
            self.conn.execute("UPDATE predictions SET actual_custom_id=NULL, hit=NULL"
                              " WHERE room_id=? AND round_id=?", (str(room_id), int(rid)))
        self.conn.commit()
        return n

    def fix_round(self, room_id: str, round_id: int, official_id: Any,
                  beast_name: str, source: str) -> Optional[Tuple[str, str]]:
        """按服务器权威结果修正一局；返回 (旧名, 新名)，未变化返回 None。"""
        oid, name, cid, mult = self.cat.resolve(official_id, beast_name)
        row = self.conn.execute(
            "SELECT beast_name FROM rounds WHERE room_id=? AND round_id=?",
            (str(room_id), int(round_id))).fetchone()
        if not row or row[0] == name:
            return None
        self.conn.execute(
            "UPDATE rounds SET beast_name=?, official_id=?, custom_id=?, multiplier=?,"
            " source=? WHERE room_id=? AND round_id=?",
            (name, oid, cid, mult, source, str(room_id), int(round_id)))
        self.conn.commit()
        return row[0], name

    def recent_rows(self, room_id: str, n: int) -> List[Tuple[int, str]]:
        """最近 n 局 (round_id, beast_name)，按时间升序。"""
        rows = self.conn.execute(
            "SELECT round_id, beast_name FROM rounds WHERE room_id=?"
            " ORDER BY round_id DESC LIMIT ?", (str(room_id), int(n))).fetchall()
        return [(r[0], r[1]) for r in reversed(rows)]

    def settled_predictions(self, room_id: str) -> List[Tuple[int, Dict[str, Any], int]]:
        """全部已结算预测 (round_id, detail, actual)，升序，供权重精确重放。"""
        rows = self.conn.execute(
            "SELECT round_id, detail, actual_custom_id FROM predictions"
            " WHERE room_id=? AND hit IS NOT NULL AND actual_custom_id IS NOT NULL"
            " ORDER BY round_id ASC", (str(room_id),)).fetchall()
        out = []
        for rid, det, actual in rows:
            try:
                out.append((rid, json.loads(det or "{}"), int(actual)))
            except (ValueError, TypeError):
                continue
        return out

    def close(self) -> None:
        try:
            self.conn.commit()
            self.checkpoint("TRUNCATE")
            self.conn.close()
        except Exception:
            pass



def day_stats(catalog: BeastCatalog, day_seq: List[int]) -> List[Dict[str, Any]]:
    """day_seq: 当天按时间升序的自定义编号序列。"""
    total = len(day_seq)
    cnt = Counter(day_seq)
    miss: Dict[int, int] = {}
    for cid in range(1, 10):
        m = 0
        for x in reversed(day_seq):
            if x == cid:
                break
            m += 1
        miss[cid] = m if cid in cnt else total
    out = []
    for cid in range(1, 10):
        name = catalog.custom2name[cid]
        c = cnt.get(cid, 0)
        out.append({
            "cid": cid, "name": name, "mult": catalog.name2mult[name],
            "miss": miss[cid], "count": c,
            "prob": (c / total) if total else 0.0,
        })
    return out


def render_day_table(catalog: BeastCatalog, room_id: str, date_local: str,
                     day_seq: List[int]) -> str:
    rows = day_stats(catalog, day_seq)
    total = len(day_seq)
    lines = [f" 当天统计 {date_local} | 房间 {room_id} | 今日共 {total} 局",
             " " + wpad("编号", 5) + wpad("妖兽", 8) + wpad("倍数", 7, ">")
             + wpad("连空", 6, ">") + wpad("出现", 6, ">") + wpad("概率", 8, ">")]
    for r in rows:
        lines.append(" " + wpad(str(r["cid"]), 5)
                     + wpad(r["name"], 8)
                     + wpad(f"{r['mult']}倍", 7, ">")
                     + wpad(str(r["miss"]), 6, ">")
                     + wpad(str(r["count"]), 6, ">")
                     + wpad(f"{r['prob']*100:.1f}%" if total else "-", 8, ">"))
    return "\n".join(lines)


def range_stats_table(catalog: BeastCatalog, seq: List[int], title: str) -> str:
    """任意区间统计表（--query / --stats 用），额外含最大连空。"""
    total = len(seq)
    cnt = Counter(seq)
    cur_miss: Dict[int, int] = {}
    max_miss: Dict[int, int] = {}
    for cid in range(1, 10):
        m = 0
        for x in reversed(seq):
            if x == cid:
                break
            m += 1
        cur_miss[cid] = m if cid in cnt else total
        mx, run = 0, 0
        for x in seq:
            if x == cid:
                mx = max(mx, run); run = 0
            else:
                run += 1
        max_miss[cid] = max(mx, run) if total else 0
    lines = [title,
             " " + wpad("编号", 5) + wpad("妖兽", 8) + wpad("倍数", 7, ">")
             + wpad("出现", 6, ">") + wpad("概率", 8, ">")
             + wpad("当前连空", 10, ">") + wpad("最大连空", 10, ">")]
    for cid in range(1, 10):
        name = catalog.custom2name[cid]
        c = cnt.get(cid, 0)
        lines.append(" " + wpad(str(cid), 5) + wpad(name, 8)
                     + wpad(f"{catalog.name2mult[name]}倍", 7, ">")
                     + wpad(str(c), 6, ">")
                     + wpad(f"{c/total*100:.1f}%" if total else "-", 8, ">")
                     + wpad(str(cur_miss[cid]), 10, ">")
                     + wpad(str(max_miss[cid]), 10, ">"))
    return "\n".join(lines)



MODEL_KEYS = ["M1", "M2", "M3", "M4", "M5", "M6"]
MODEL_NAMES = {"M1": "全量频率", "M2": "近窗频率", "M3": "指数衰减",
               "M4": "马尔可夫1", "M5": "马尔可夫2", "M6": "未出场回补"}


class Predictor:
    """
    每个子模型输出 9 维概率分布（索引 = 自定义编号-1），
    线性池融合，权重用 Hedge/EWA 依据各模型历史 log-loss 在线自适应，
    并持久化到数据库 kv 表（按房间隔离）。
    """

    def __init__(self, cfg: PredictionConfig, store: Optional[RoundStore], room_id: str,
                 logger: logging.Logger, persistent: bool = True):
        self.cfg = cfg
        self.store = store
        self.room_id = str(room_id)
        self.log = logger
        self.persistent = persistent and store is not None
        self.weights = self._load_weights()
        self._miss4: Dict[int, int] = {c: 0 for c in range(1, 10)}
        self._settled_seen = 0
        self._tok: float = 1.0
        cal = max(60, int(self.cfg.explore_calib))
        self._zh: Dict[int, deque] = {c: deque(maxlen=cal) for c in range(1, 10)}
        self._sx: deque = deque(maxlen=cal)
        self._last_fp: Optional[List[int]] = None
        self._last_four: Optional[List[int]] = None
        self._last_exp: Optional[Dict[str, Any]] = None
        self._last_abst: Optional[Dict[str, Any]] = None
        self._last_seat: Optional[Dict[str, Any]] = None
        self._kd = [deque(maxlen=self._zh[1].maxlen) for _ in range(3)]
        # 冷位节拍器状态:两只令牌桶(float)+两只连串计数(int),随 explore_state 落盘
        self._cgb3 = 0.0
        self._cgb2 = 0.0
        self._cgr3 = 0
        self._cgr2 = 0
        self._pen: Dict[int, int] = {c: 0 for c in range(1, 10)}
        self._cstk: int = 0
        self._pk: int = -1
        self._cool: Dict[int, int] = {}
        self._dbt: Dict[int, float] = {c: 0.0 for c in range(1, 10)}
        self._rep: int = 0
        self._fr_mix: Optional[Dict[Tuple[int, ...], float]] = None
        self._fr_diag: Optional[Dict[str, Any]] = None
        self._fr_debt: Dict[Tuple[int, ...], float] = {}
        self._fr_plan_age: int = 0
        self._fr_key: str = ""
        self._fr_mdbt: Dict[int, float] = {}
        self._load_explore_state()

    def _load_explore_state(self) -> None:
        raw = self.store.kv_get(self.room_id, "explore_state") if self.persistent else None
        if not raw:
            return
        try:
            st = json.loads(raw)
            m = st.get("miss4") or {}
            self._miss4 = {c: int(m.get(str(c), 0)) for c in range(1, 10)}
            self._tok = min(2.0, max(0.0, float(st.get("tok", 1.0))))
            pn = st.get("pen") or {}
            self._pen = {c: int(pn.get(str(c), 0)) for c in range(1, 10)}
            self._cstk = int(st.get("cstk", 0))
            self._pk = int(st.get("pk", -1))
            db = st.get("dbt") or {}
            self._dbt = {c: float(db.get(str(c), 0.0)) for c in range(1, 10)}
            self._rep = int(st.get("rep", 0))
            self._fr_debt = (_FrSched.load(st.get("frd"))
                             if _FrSched is not None else {})
            self._fr_plan_age = int(st.get("fra", 0))
            self._fr_key = str(st.get("frk") or "")
            try:
                self._fr_mdbt = {int(k): float(v)
                                 for k, v in (st.get("frmd") or {}).items()}
            except (TypeError, ValueError):
                self._fr_mdbt = {}
            _m = st.get("frm")
            if isinstance(_m, list) and _m:
                try:
                    self._fr_mix = {tuple(int(c) for c in row[:4]): float(row[4])
                                    for row in _m if len(row) == 5}
                except (TypeError, ValueError):
                    self._fr_mix = None
                if not self._fr_mix:          # 解析后为空 = kv 被写坏,
                    self._fr_mix = None       # 回到 None 触发重规划,别把空方案喂给调度器
                self._fr_diag = st.get("frq") if isinstance(st.get("frq"), dict) else None
            cl = st.get("cool") or {}
            self._cool = {int(c): int(v) for c, v in cl.items() if int(v) > 0}
            zh = st.get("zh") or {}
            for c in range(1, 10):
                for v in (zh.get(str(c)) or [])[-self._zh[c].maxlen:]:
                    self._zh[c].append(float(v))
            for v in (st.get("sx") or [])[-self._sx.maxlen:]:
                self._sx.append(float(v))
            self._last_fp = st.get("fp") or None
            self._last_four = st.get("four") or None
            self._last_exp = st.get("exp") or None
            self._last_abst = st.get("abst") or None
            self._last_seat = st.get("seat") or None
            for j, arr in enumerate(st.get("kd") or []):
                if j < 3:
                    for v in arr[-self._kd[j].maxlen:]:
                        self._kd[j].append(float(v))
            # 节拍器状态:旧状态无这四个键 ⇒ 按 0 起算(向后兼容,由
            # tests/test_cadence_governor.py::test_state_roundtrip_and_backward_compat 钉守)
            self._cgb3 = float(st.get("cgb3") or 0.0)
            self._cgb2 = float(st.get("cgb2") or 0.0)
            self._cgr3 = int(st.get("cgr3") or 0)
            self._cgr2 = int(st.get("cgr2") or 0)
        except Exception:
            pass

    def _save_explore_state(self) -> None:
        if not self.persistent:
            return
        st = {"miss4": {str(c): v for c, v in self._miss4.items()},
              "tok": round(self._tok, 6),
              "fp": self._last_fp, "four": self._last_four, "exp": self._last_exp,
              "abst": self._last_abst, "seat": self._last_seat,
              "kd": [[round(v, 4) for v in d] for d in self._kd],
              "cgb3": round(self._cgb3, 6), "cgb2": round(self._cgb2, 6),
              "cgr3": int(self._cgr3), "cgr2": int(self._cgr2),
              "pen": {str(c): v for c, v in self._pen.items()},
              "cstk": self._cstk, "pk": self._pk,
              "dbt": {str(c): round(v, 5) for c, v in self._dbt.items()
                      if abs(v) > 1e-9},
              "rep": self._rep,
              # frontier:混合方案本身也要落盘。桥模式下 Predictor 每局重建,
              # 不持久化就等于「每局重解一次 LP」—— fr_replan 会变成一个不生效的
              # 装饰参数(已实测:fr_replan=200 时 100 局仍解 100 次)。
              "frd": {",".join(map(str, k)): round(v, 6)
                      for k, v in self._fr_debt.items()},
              "fra": self._fr_plan_age,
              "frk": self._fr_key,
              "frmd": {str(k): round(v, 6) for k, v in self._fr_mdbt.items()},
              "frm": ([[*k, round(v, 8)] for k, v in self._fr_mix.items()]
                      if self._fr_mix else None),
              "frq": self._fr_diag,
              "cool": {str(c): v for c, v in self._cool.items() if v > 0},
              "sx": [round(v, 4) for v in self._sx],
              "zh": {str(c): [round(v, 4) for v in self._zh[c]] for c in range(1, 10)}}
        self.store.kv_set(self.room_id, "explore_state", json.dumps(st))

    def _load_weights(self) -> Dict[str, float]:
        raw = self.store.kv_get(self.room_id, "model_weights") if self.persistent else None
        if raw:
            try:
                w = json.loads(raw)
                if set(w) == set(MODEL_KEYS):
                    s = sum(w.values())
                    if s > 0:
                        return {k: v / s for k, v in w.items()}
            except Exception:
                pass
        return {k: 1.0 / len(MODEL_KEYS) for k in MODEL_KEYS}

    def _save_weights(self) -> None:
        if self.persistent:
            self.store.kv_set(self.room_id, "model_weights", json.dumps(self.weights))

    @staticmethod
    def _norm(v: List[float]) -> List[float]:
        s = sum(v)
        return [x / s for x in v] if s > 0 else [1 / 9] * 9

    def _m1_global(self, seq: List[int]) -> List[float]:
        cnt = Counter(seq)
        return self._norm([cnt.get(c, 0) + 2.0 for c in range(1, 10)])

    def _prior_vec(self) -> Optional[List[float]]:
        """解析 prior_table。非法/缺项/和不为 1 一律返回 None(=关闭收缩,退回现行)。

        解析失败**不抛异常也不改行为** —— 这是热更改错时的安全姿态:配置写坏
        只应让优化失效,不应让 predict() 崩掉(崩了表现为「这一局没有预测」,
        而调用方只有 try/except 兜底,查不出原因)。
        """
        raw = str(getattr(self.cfg, "prior_table", "") or "")
        # 缓存按**原始串**取键:管理台热更 prior_table 后必须当场生效,不能被旧缓存盖住
        # (本项目历史上 fr_replan 就吃过「缓存把热更拖住」的亏,见 config.yaml 同段注释)。
        if getattr(self, "_prior_key", None) == raw:
            return self._prior_cache or None
        out = [0.0] * 9
        for kv in raw.split(","):
            if ":" not in kv:
                continue
            try:
                c, v = kv.split(":", 1)
                c = int(c.strip())
                v = float(v)
            except (TypeError, ValueError):
                continue
            if 1 <= c <= 9 and v > 0.0:
                out[c - 1] = v
        s = sum(out)
        # 九项必须全部为正(缺一项 ⇒ 该号先验概率 0 ⇒ LP 会永久判它不可能出),
        # 且总和须在 1 附近(容忍手写四舍五入)。
        ok = all(x > 0.0 for x in out) and 0.98 <= s <= 1.02
        self._prior_cache = [x / s for x in out] if ok else []
        self._prior_key = raw
        return self._prior_cache or None

    def _p_frontier(self, seq: List[int]) -> List[float]:
        """frontier 风格的概率口径:现行 Laplace 估计 + 自适应收缩。

        λ 是多项分布收缩估计的经验贝叶斯权重(与 James-Stein 同族),形式如下。
        ⚠ 本处**不写文献署名** —— 4.9.4 复查时容器内 Crossref/DOI 均不可达,
        无法当场核实出处;查不实的引用比没有引用更坏(它会让后来人以为已被审过)。
        选它的依据是**本仓库内的实测**,不是权威:见 config.yaml 同名段的
        4 真值场景 × 6 样本量矩阵(150 次重复),以及与固定 κ 的对照。

            p̂ = 归一化(计数 + 2.0)                      ← 与 _m1_global 逐位相同
            λ = (1 − Σp̂ᵢ²) / ((n−1)·Σ(p̂ᵢ − p₀ᵢ)²)      ← 钳到 [0,1]
            p = λ·p₀ + (1−λ)·p̂

        为什么架在 Laplace 之上而不是裸频率之上:裸频率在 n=2 且两局同兽时
        Σp̂²=1 ⇒ 分子 0 ⇒ λ=0 ⇒ 直接吐出 one-hot 概率,LP 会把该号当成必出。
        Laplace 底座使 p̂ 恒不退化(已对 n=0..6 的全部同兽/异兽组合穷举验证:
        输出恒 >1e-6、和为 1、有限)。附带好处是 λ=0 时本函数**逐位等于**
        _m1_global,回滚有字节级保证。

        零随机源、O(9)、逐局可复现 —— 满足本项目对可回放性的硬要求。
        """
        cnt = Counter(seq)
        ph = self._norm([cnt.get(c, 0) + 2.0 for c in range(1, 10)])
        if not getattr(self.cfg, "prior_shrink", False):
            return ph
        p0 = self._prior_vec()
        if p0 is None:
            return ph
        n = float(len(seq))
        if n < 2.0:                       # 样本不足以说任何话 ⇒ 全用先验
            return list(p0)
        num = 1.0 - sum(x * x for x in ph)
        den = (n - 1.0) * sum((ph[i] - p0[i]) ** 2 for i in range(9))
        lam = 1.0 if den <= 1e-12 else min(1.0, max(0.0, num / den))
        if lam <= 0.0:                    # 数据已足够否定先验 ⇒ 逐位退回现行值
            return ph
        return self._norm([lam * p0[i] + (1.0 - lam) * ph[i] for i in range(9)])

    def _m2_window(self, seq: List[int]) -> List[float]:
        win = seq[-self.cfg.recent_window:]
        cnt = Counter(win)
        return self._norm([cnt.get(c, 0) + 1.0 for c in range(1, 10)])

    def _m3_ewma(self, seq: List[int]) -> List[float]:
        hl = max(1.0, self.cfg.ewma_half_life)
        s = [0.5] * 9
        for age, cid in enumerate(reversed(seq)):
            s[cid - 1] += 0.5 ** (age / hl)
        return self._norm(s)

    def _m4_markov1(self, seq: List[int], p_glob: List[float]) -> List[float]:
        if len(seq) < 2:
            return list(p_glob)
        trans: Dict[int, Counter] = {}
        for a, b in zip(seq[:-1], seq[1:]):
            trans.setdefault(a, Counter())[b] += 1
        last = seq[-1]
        row = trans.get(last, Counter())
        tau = self.cfg.markov_shrink
        tot = sum(row.values())
        return self._norm([row.get(c, 0) + tau * p_glob[c - 1] for c in range(1, 10)]) \
            if (tot + tau) > 0 else list(p_glob)

    def _m5_markov2(self, seq: List[int], p_m4: List[float]) -> List[float]:
        if len(seq) < 3:
            return list(p_m4)
        trans: Dict[Tuple[int, int], Counter] = {}
        for a, b, c in zip(seq[:-2], seq[1:-1], seq[2:]):
            trans.setdefault((a, b), Counter())[c] += 1
        key = (seq[-2], seq[-1])
        row = trans.get(key, Counter())
        tau = self.cfg.markov2_shrink
        return self._norm([row.get(c, 0) + tau * p_m4[c - 1] for c in range(1, 10)])

    def _m6_omission(self, seq: List[int], p_glob: List[float]) -> List[float]:
        """传统"未出场回补"战况信号：连空超过期望越多，越被上调（软性）。
        注：对真正独立随机的过程无预测力，仅作为集成中的一路信号，
        其权重会被在线学习自动调整。"""
        g = self.cfg.omission_gamma
        if g <= 0 or not seq:
            return list(p_glob)
        s = []
        for c in range(1, 10):
            gap = 0
            for x in reversed(seq):
                if x == c:
                    break
                gap += 1
            ratio = (gap + 1) * p_glob[c - 1]
            s.append(p_glob[c - 1] * (max(ratio, 1e-6) ** g))
        return self._norm(s)

    @staticmethod
    def _zclamp(x: float, lo: float = -4.0, hi: float = 4.0) -> float:
        return max(lo, min(hi, x))

    def _signal_battery(self, seq: List[int], p1: List[float]) -> Dict[int, Any]:
        """对每只兽计算 6 路标准化规律信号并按当前 Hedge 权重加权成综合z。
        信号: M2近窗热度 / M3指数热度 / M4一阶转移 / M5二阶转移 / M6未出场超期 /
              RH间隔节律(历史上"再空这么多局后恰好开出"的条件命中率 vs 基率)。
        全部为标准化 z 分(±4 截断)，可解释、可回测、无任何随机成分。"""
        n = len(seq)
        last = seq[-1]
        ctx2 = (seq[-2], seq[-1]) if n >= 2 else None
        win = seq[-self.cfg.recent_window:]
        nwin = len(win)
        gap: Dict[int, int] = {}
        last_pos: Dict[int, Optional[int]] = {c: None for c in range(1, 10)}
        spacings: Dict[int, List[int]] = {c: [] for c in range(1, 10)}
        row1: Counter = Counter(); m1s = 0
        row2: Counter = Counter(); m2s = 0
        for i, x in enumerate(seq):
            lp = last_pos[x]
            if lp is not None:
                spacings[x].append(i - lp)
            last_pos[x] = i
            if i >= 1 and seq[i - 1] == last:
                row1[x] += 1; m1s += 1
            if i >= 2 and ctx2 and (seq[i - 2], seq[i - 1]) == ctx2:
                row2[x] += 1; m2s += 1
        for c in range(1, 10):
            gap[c] = (n - 1 - last_pos[c]) if last_pos[c] is not None else n
        hl = max(1.0, self.cfg.ewma_half_life)
        cap = int(min(n, 8 * hl))
        T = T2 = 0.0
        for age in range(cap):
            w = 0.5 ** (age / hl)
            T += w; T2 += w * w
        wsum = {c: 0.0 for c in range(1, 10)}
        for age, cid in enumerate(seq[-cap:][::-1]):
            wsum[cid] += 0.5 ** (age / hl)
        wr = max(0.0, self.cfg.explore_rhythm_w)
        base_w = {k: self.weights[k] for k in ("M2", "M3", "M4", "M5", "M6")}
        tot = sum(base_w.values()) + wr
        Wsig = {**{k: v / tot for k, v in base_w.items()}, "RH": wr / tot}
        out: Dict[int, Any] = {}
        for c in range(1, 10):
            p = p1[c - 1]
            parts: List[Tuple[str, float, Dict[str, Any]]] = []
            k = win.count(c)
            mu = nwin * p
            sd = math.sqrt(max(nwin * p * (1 - p), 1e-9))
            parts.append(("M2", self._zclamp((k - mu) / sd), {"n": nwin, "k": k, "mu": mu}))
            mu3 = p * T
            sd3 = math.sqrt(max(p * (1 - p) * T2, 1e-9))
            parts.append(("M3", self._zclamp((wsum[c] - mu3) / sd3), {}))
            if m1s >= 8:
                z1 = self._zclamp((row1[c] - m1s * p) / math.sqrt(max(m1s * p * (1 - p), 1e-9)))
            else:
                z1 = 0.0
            parts.append(("M4", z1, {"last": last, "m": m1s, "k": row1[c]}))
            if ctx2 and m2s >= 6:
                z2 = self._zclamp((row2[c] - m2s * p) / math.sqrt(max(m2s * p * (1 - p), 1e-9)))
            else:
                z2 = 0.0
            parts.append(("M5", z2, {"ctx": ctx2, "m": m2s, "k": row2.get(c, 0)}))
            g = gap[c]
            zg = self._zclamp((g - (1 - p) / p) * p / math.sqrt(max(1 - p, 1e-9)))
            parts.append(("M6", zg, {"g": g}))
            ds = spacings[c]
            m_r = sum(1 for d in ds if d >= g + 1)
            k_r = sum(1 for d in ds if d == g + 1)
            if m_r >= 8:
                zr = self._zclamp((k_r - m_r * p) / math.sqrt(max(m_r * p * (1 - p), 1e-9)))
            else:
                zr = 0.0
            parts.append(("RH", zr, {"m": m_r, "k": k_r, "g": g}))
            Z = sum(Wsig[key] * z for key, z, _ in parts)
            out[c] = (Z, parts, Wsig)
        return out

    _SIG_NAME = {"M2": "近窗热度", "M3": "指数热度", "M4": "一阶转移",
                 "M5": "二阶转移", "M6": "未出场超期", "RH": "间隔节律"}

    def _explain_signal(self, cid: int, entry: Any, theta: float) -> str:
        """把该兽综合z里贡献最大的两路信号翻成人话，附动态门槛。"""
        Z, parts, Wsig = entry
        ranked = sorted(parts, key=lambda kv: -(Wsig[kv[0]] * kv[1]))
        bits: List[str] = []
        for key, z, d in ranked[:2]:
            if Wsig[key] * z <= 0:
                break
            if key == "M2":
                bits.append(f"近{d['n']}局出{d['k']}次(基准{d['mu']:.1f},z+{z:.1f})")
            elif key == "M3":
                bits.append(f"指数热度z+{z:.1f}")
            elif key == "M4":
                bits.append(f"上局{d['last']}后历史{d['m']}次内{d['k']}次接它(z+{z:.1f})")
            elif key == "M5":
                a, b = d["ctx"]
                bits.append(f"前两局({a},{b})后{d['m']}次内{d['k']}次接它(z+{z:.1f})")
            elif key == "M6":
                bits.append(f"已{d['g']}局未开·超期(z+{z:.1f})")
            elif key == "RH":
                bits.append(f"历史间隔≥{d['g']+1}的{d['m']}次中{d['k']}次恰在此步开出(z+{z:.1f})")
        head = "·".join(bits) if bits else "多路信号合力"
        return f"信号·{head}·综合z={Z:.2f}≥门槛{theta:.2f}(每兽自校准)"

    @staticmethod
    def _pools_n(raw: Any, n: int, fallback: Tuple[int, ...]) -> Tuple[int, ...]:
        """解析"逗号分隔的 n 个 1~9 不重复编号";非法值回落 fallback。"""
        try:
            ids = tuple(sorted({int(x) for x in str(raw).split(",") if str(x).strip()}))
        except (TypeError, ValueError):
            ids = ()
        if len(ids) != n or any(not (1 <= c <= 9) for c in ids):
            ids = fallback
        return ids

    def _fr_multipliers(self) -> Dict[int, int]:
        """号位→倍率。留空则由 BEASTS_BASE + DEFAULT_CUSTOM_IDS 推导。
        注意:部署若改过 custom_beast_ids,必须同批显式填 fr_mult —— 由
        tests/test_frontier.py 的「倍率推导」钉守住,改了不同步 CI 直接红。"""
        raw = str(getattr(self.cfg, "fr_mult", "") or "").strip()
        if raw:
            out: Dict[int, int] = {}
            try:
                for part in raw.split(","):
                    k, _, v = part.partition(":")
                    out[int(k)] = int(v)
            except (TypeError, ValueError):
                out = {}
            if sorted(out) == list(range(1, 10)):
                return out
        name2mult = {b[1]: b[3] for b in BEASTS_BASE}
        return {int(cid): int(name2mult[nm]) for nm, cid in DEFAULT_CUSTOM_IDS.items()}

    @staticmethod
    def _pools(raw: Any) -> Tuple[Tuple[int, ...], Tuple[int, ...]]:
        """解析冷池配置 → (冷池, 热池);非法值回落到原版 (3,4,5,6,9)。"""
        try:
            ids = tuple(sorted({int(x) for x in str(raw).split(",") if str(x).strip()}))
        except (TypeError, ValueError):
            ids = ()
        if len(ids) != 5 or any(not (1 <= c <= 9) for c in ids):
            ids = (3, 4, 5, 6, 9)
        return ids, tuple(c for c in range(1, 10) if c not in ids)

    #: predict() 里真正实现了分支的风格。未登记的取值会**静默落到通用兜底分支**
    #: —— 历史上 hot_rotate/ceiling_adaptive 就是这么"看着改了其实没改"的
    #: (实证:hot_rotate / ceiling_adaptive / 任意乱写串三者输出逐字节相同)。
    #: 现在至少喊一声,并由 tests/test_frontier.py 钉住它与注册表 enum 同集合。
    #: 注:ceiling_adaptive 是 write_config_template 里 v2.x norm_cold 的迁移目标,
    #: 其实现就是 predict() 的最终 else 分支 —— 它是**有名字的**风格,不是漏网的
    #: 乱写串,故必须在册。(4.9.7 前它同时是引擎 dataclass 默认值,现默认已改为
    #: showcase;未知取值仍静默落到该分支不变。)
    IMPLEMENTED_STYLES = ("budget", "norm_cold", "matched", "showcase",
                          "ceiling_adaptive", "frontier")

    @staticmethod
    def _style_throttle(key: str, window: float = 300.0) -> bool:
        """风格类告警去重:同一问题 window 秒内只喊一次。返回 True = 本次该喊。

        为什么不能用实例级标志:桥模式(生产)下 Predictor **每局重建**,实例属性
        每局归零 —— 与 _DIRTY_SEQ_WARNED 那段注释是同一个理由,但那次只修了脏序列
        一处,这两条风格告警被漏掉了(4.9.0 第五轮复查补上)。
        为什么键里不含 room_id:这是配置级问题,一万房会同时命中。
        """
        now = time.time()
        if now - _STYLE_WARNED.get(key, 0.0) > window:
            _STYLE_WARNED[key] = now
            return True
        return False

    def predict(self, seq: List[int]) -> Dict[str, Any]:
        st = str(self.cfg.explore_style or "")
        if st not in self.IMPLEMENTED_STYLES:
            if self._style_throttle("unimpl:" + st):
                self.log.warning(
                    "explore_style=%r 未实现,已静默落到通用兜底分支(行为=通用冷门探索,"
                    "不是你以为的那个风格)。可选值:%s",
                    st, "/".join(self.IMPLEMENTED_STYLES))
        elif st == "frontier" and _fr_plan is None:
            # 这条是给"镜像漏拷 frontier_planner.py"准备的:没有它,frontier 会
            # 一声不吭地跑成通用兜底分支 —— 正是本项目历史上 hot_rotate 的病。
            if self._style_throttle("no-planner"):
                self.log.error(
                    "explore_style=\"frontier\" 但同目录缺 frontier_planner.py"
                    "(STA_ENGINE_DIR=%r),前沿调度未生效,已落回通用兜底分支。"
                    "请确认镜像/部署把该文件与 spell_tamer_monitor.py 一起投放。",
                    os.environ.get("STA_ENGINE_DIR", "<未设>"))
        # 入口净化:seq 里混进非 1~9 的值(0 / 10 / -1 / None / 超大整数)会在下游
        # 直接 IndexError / TypeError —— 实测 showcase 与 frontier **都崩**,是既有
        # 缺陷。数据源理论上受 custom_beast_ids 约束,但配置改错、抓取异常、DB 脏
        # 数据都能把它带进来,而调用方(_push_next_prediction / _handle_award)只有
        # try/except 兜底 ⇒ 表现为"这一局没有预测",查不出原因。
        # 正常数据下本行是恒等变换,故不影响任何既有口径(有字节级等价核验)。
        _bad = sum(1 for c in seq
                   if isinstance(c, bool) or not isinstance(c, int) or not 1 <= c <= 9)
        if _bad:
            # 节流:桥模式下 Predictor 每局重建,实例级去重不起作用 —— 不节流的话
            # 一条脏序列会让日志**每局每房刷一次**,自己变成新的故障模式。
            _now = time.time()
            if _now - _DIRTY_SEQ_WARNED.get(self.room_id, 0.0) > 300.0:
                _DIRTY_SEQ_WARNED[self.room_id] = _now
                self.log.warning("[%s] seq 含 %d 个非法 custom_id(应为 1~9),已剔除"
                                 "(本条 5 分钟内不再重复)", self.room_id, _bad)
            seq = [c for c in seq
                   if not isinstance(c, bool) and isinstance(c, int) and 1 <= c <= 9]
        seq = seq[-self.cfg.max_train:]
        _C5, _H4 = self._pools(getattr(self.cfg, "showcase_cold_ids", "3,4,5,6,9"))
        if not seq:
            u = [1.0 / 9] * 9
            return {"models": {k: list(u) for k in MODEL_KEYS}, "ens": u, "raw_ens": list(u),
                    "anchor_lambda": 1.0, "drift": 0.0,
                    "mode": (self.cfg.predict_mode or "adaptive").lower(), "explore": None,
                    "main": [1, 2], "guard": [3, 4], "cover": 4 / 9,
                    "weights": dict(self.weights), "train_n": 0}
        p1 = self._m1_global(seq)
        p2 = self._m2_window(seq)
        p3 = self._m3_ewma(seq)
        p4 = self._m4_markov1(seq, p1)
        p5 = self._m5_markov2(seq, p4)
        p6 = self._m6_omission(seq, p1)
        models = {"M1": p1, "M2": p2, "M3": p3, "M4": p4, "M5": p5, "M6": p6}

        ens = [0.0] * 9
        for k, p in models.items():
            w = self.weights[k]
            for i in range(9):
                ens[i] += w * p[i]
        ens = self._norm(ens)

        raw_ens = list(ens)
        W = max(20, int(self.cfg.anchor_window))
        recent = self._m1_global(seq[-W:]) if len(seq) >= W else p1
        drift = 0.5 * sum(abs(recent[i] - p1[i]) for i in range(9))

        mode = (self.cfg.predict_mode or "adaptive").lower()
        explore: Optional[Dict[str, Any]] = None
        abstain: Optional[Dict[str, Any]] = None
        seat: Optional[Dict[str, Any]] = None

        if mode == "ceiling" and self.cfg.freq_anchor:
            floor = max(0.0, self.cfg.anchor_drift_floor)
            ref = max(floor + 1e-6, self.cfg.anchor_drift_ref)
            eff = max(0.0, drift - floor)
            lam = 1.0 - min(1.0, eff / (ref - floor)) * (1.0 - self.cfg.anchor_lambda_min)
            final = self._norm([lam * p1[i] + (1.0 - lam) * ens[i] for i in range(9)])
            order = sorted(range(1, 10), key=lambda c: (-final[c - 1], -seq.count(c), c))
            four = order[:4]
        elif mode == "ceiling":
            lam, final = 1.0, list(p1)
            order = sorted(range(1, 10), key=lambda c: (-final[c - 1], -seq.count(c), c))
            four = order[:4]
        else:
            lam = min(1.0, max(0.0, self.cfg.adaptive_lambda))
            final = self._norm([lam * p1[i] + (1.0 - lam) * ens[i] for i in range(9)])
            order = sorted(range(1, 10), key=lambda c: (-final[c - 1], -seq.count(c), c))
            four = list(order[:4])
            _fd = max(3, int(getattr(self.cfg, "sc_fp_depth", 3)))
            fp = [len(seq)] + list(seq[-_fd:])
            if (fp == self._last_fp and isinstance(self._last_four, list)
                    and len(set(self._last_four)) == 4
                    and all(isinstance(c, int) and 1 <= c <= 9 for c in self._last_four)):
                four = list(self._last_four)
                explore = dict(self._last_exp) if self._last_exp else None
                abstain = dict(self._last_abst) if self._last_abst else None
                seat = dict(self._last_seat) if self._last_seat else None
            else:
                _ao = bool(getattr(self.cfg, "anti_stubborn", 1))
                if _ao:
                    _lo = seq[-1]
                    if self._cool:
                        self._cool = {c: v - 1 for c, v in self._cool.items() if v - 1 > 0}
                    _pf = (self._last_four if (isinstance(self._last_four, list)
                           and len(set(self._last_four)) == 4) else None)
                    if _pf:
                        _cap = max(1, int(getattr(self.cfg, "as_pen_cap", 8)))
                        _hit = _lo in _pf
                        _acc = (not _hit) or bool(getattr(self.cfg, "as_pen_on_hit", 0))
                        for _c in range(1, 10):
                            if _c in _pf:
                                if _lo == _c:
                                    self._pen[_c] = 0
                                elif _acc:
                                    self._pen[_c] = min(_cap, self._pen[_c] + 1)
                            else:
                                self._pen[_c] = max(0, self._pen[_c] - 1)
                        self._cstk = 0 if _hit else self._cstk + 1
                    _a1 = float(getattr(self.cfg, "as_alpha", 0.08))
                    _a2 = float(getattr(self.cfg, "as_alpha_ord", 0.20))
                    _mh = float(getattr(self.cfg, "as_mcap_hot", 0.12))
                    _mc = float(getattr(self.cfg, "as_mcap_cold", 0.30))
                    _gm = float(getattr(self.cfg, "as_gamma", 0.08))
                    _bt = float(getattr(self.cfg, "as_beta", 0.5))
                    if (bool(getattr(self.cfg, "showcase_rotate", 1))
                            and int(getattr(self.cfg, "sc_beta_off", 0))
                            and self.cfg.explore_style == "showcase"):
                        _bt = 0.0
                    _ac = max(1, int(getattr(self.cfg, "as_agecap", 24)))
                    _inc = set(_pf or [])
                    def _ss(c, cold_seat=False):     # 集合选择:EV 有界
                        if self._cool.get(c, 0) > 0:
                            return final[c - 1] * 1e-6
                        cut = max(math.exp(-_a1 * self._pen[c]), 1.0 - (_mc if cold_seat else _mh))
                        v = final[c - 1] * cut
                        if c in _inc:
                            v *= (1.0 + _gm)
                        if cold_seat and _bt > 0:
                            v *= (1.0 + _bt * min(self._miss4[c], _ac) / _ac)
                        return v
                    def _so(c):                      # 座次排序:自由压力重排(零EV成本)
                        v = final[c - 1] * math.exp(-_a2 * self._pen[c])
                        if c in _inc:
                            v *= (1.0 + _gm)
                        return v
                else:
                    def _ss(c, cold_seat=False):
                        return final[c - 1]
                    _so = lambda c: final[c - 1]
                # ── 重现观察期(repeat_guard;showcase 风格域内)────────────────
                # 实地核查(三房 7 天 36,278 真机局)证明九兽危险率对间隔全平坦:
                # 刚开出后的 M2/M3 短窗概率飙升没有预测力。观察期把「当下稀有」的
                # 号(24h 滑窗频率 ≤ rg_pmax)的自由入选推迟 ceil(θ/p̂)(封顶
                # rg_cap)局 —— 统计等价(份额由赤字账本照常补发)、观感不再「刚开完
                # 500x 立刻又推它」。保底(patrol)不受约束(饿死保护优先);若房间
                # 自身窗内证据显示该号显著扎堆重复(四关合一),观察期为证据让位。
                _rg = (int(getattr(self.cfg, "repeat_guard", 1))
                       if self.cfg.explore_style == "showcase" else 0)
                if _rg:
                    _rgt = max(0.0, float(getattr(self.cfg, "rg_theta", 0.35)))
                    _rgc = max(1, int(getattr(self.cfg, "rg_cap", 20)))
                    _rgp = float(getattr(self.cfg, "rg_pmax", 0.075))
                    _rgm = max(1, int(getattr(self.cfg, "rg_minm", 30)))
                    _rgz = float(getattr(self.cfg, "rg_zpos", 2.5))
                    _rgn = len(seq)
                    _rgap: Dict[int, int] = {}
                    for _c in _C5:
                        _g = _rgn
                        for _i in range(_rgn - 1, -1, -1):
                            if seq[_i] == _c:
                                _g = _rgn - 1 - _i
                                break
                        _rgap[_c] = _g
                    _rgm_n = {c: 0 for c in _C5}
                    _rgm_k = {c: 0 for c in _C5}
                    for _a, _b in zip(seq[:-1], seq[1:]):
                        if _a in _rgm_n:
                            _rgm_n[_a] += 1
                            if _b == _a:
                                _rgm_k[_a] += 1

                    def _rg_len(c):
                        p = max(p1[c - 1], 1e-6)
                        if p > _rgp:
                            return 0
                        return min(_rgc, int(math.ceil(_rgt / p)))

                    def _guarded(c):
                        if c not in _rgap:
                            return False
                        L = _rg_len(c)
                        if L <= 0 or _rgap[c] >= L:
                            return False
                        m = _rgm_n.get(c, 0)
                        if m >= _rgm:      # 房间自证豁免:本窗紧随重复显著超基线
                            p = p1[c - 1]
                            sd = math.sqrt(max(m * p * (1 - p), 1e-9))
                            k = _rgm_k.get(c, 0)
                            # 滑窗多重比较下,豁免须三关合一:显著性 z≥rg_zpos、
                            # 绝对样本 k≥4、且局部复现率 ≥1.6× 基率 —— 缺一即噪声。
                            # 刻度依据(三房 7 天真机):z≥2.0 单关在 3746870 房
                            # 3 号可占 13.8% 时点(峰值 3.29),单关放行必误放;
                            # 三关合一后占比压到 4.5% —— 恰好只剩它真扎堆的那段
                            # (窗内 k=6/m≈30,z+3.0 级),放行局 why 落款「随势跟进」
                            # 自解释;平坦危险率的 9 号(紧随 3.02%≈基率 3.56%,
                            # z−1.1)全程零误放。z≥2.5 在当前频率下(9 号窗内 m≈60,
                            # μ≈2.2)已隐含 k≥6;k≥4 是 m 贴着下限时的绝对保险。
                            if (k >= 4 and k >= 1.6 * m * p
                                    and (k - m * p) / sd >= _rgz):
                                return False
                        return True
                    _so_rg = _so
                    _rgd = max(0.0, min(1.0, float(getattr(self.cfg,
                                                           "rg_seat_damp", 0.25))))

                    def _so(c):            # 座次端降权:观察期号沉入防区(零EV成本)
                        v = _so_rg(c)
                        return v * _rgd if _guarded(c) else v
                else:
                    def _guarded(c):
                        return False
                patrol = max(2, int(self.cfg.explore_patrol))
                _is_fr = (self.cfg.explore_style == "frontier"
                          and _fr_plan is not None)
                # frontier 风格不算信号电池:①数据里没有可用信号(实地核查见
                # PredictionConfig 注释) ②省掉每局 O(n) 的最大开销项。
                sig = None if _is_fr else self._signal_battery(seq, p1)
                cold = order[4:]
                worst = max(range(1, 10), key=lambda c: self._miss4[c])
                pend = [c for c in range(1, 10) if self._miss4[c] >= patrol + 11]
                hard = bool(pend) and self._miss4[worst] >= patrol + 15 - (len(pend) - 1)
                tie_gap: Optional[float] = None
                organic: Optional[Dict[str, Any]] = None
                if self.cfg.explore_style == "budget":
                    K = max(2, int(self.cfg.explore_every))
                    rate = 1.0 / K
                    patrol = max(K, patrol)
                    pend = [c for c in range(1, 10) if self._miss4[c] >= patrol + 11]
                    hard = bool(pend) and self._miss4[worst] >= patrol + 15 - (len(pend) - 1)
                    share = rate / max(1, len(cold))
                    r_b = min(0.5, max(share * 0.5, share * self._tok))
                    idle = self._tok >= 2.0 - 1e-9
                    best = None
                    for c in cold:
                        h = self._zh[c]
                        due = self._miss4[c] >= patrol
                        relax = due or idle
                        if len(h) >= 40:
                            qr = 0.5 if relax else (1 - r_b)
                            q = sorted(h)[min(len(h) - 1, int(len(h) * qr))]
                        else:
                            q = 0.0 if relax else self.cfg.explore_z0
                        th_c = q if relax else max(q, self.cfg.explore_min_z)
                        ex = sig[c][0] - th_c
                        if best is None or ex > best[2]:
                            best = (c, th_c, ex)
                    c_sig, theta, excess = best
                    fire = hard or (self._tok >= 1.0 and excess >= 0)
                    if fire:
                        self._tok = max(0.0, self._tok - 1.0)
                    self._tok = min(2.0, self._tok + rate)
                elif self.cfg.explore_style == "norm_cold":
                    med = {}
                    for c in cold:
                        h = self._zh[c]
                        med[c] = sorted(h)[len(h) // 2] if len(h) >= 40 else 0.0
                    S = max(sig[c][0] - med[c] for c in cold)
                    due = [c for c in cold if self._miss4[c] >= patrol]
                    if due:
                        c_sig = max(due, key=lambda c: sig[c][0] - med[c])
                        theta = med[c_sig]
                    else:
                        kappa = 0.004
                        c_sig = max(cold, key=lambda c: final[c - 1] + kappa * max(0.0, sig[c][0] - med[c]))
                        theta = med[c_sig]
                    if len(self._sx) >= 40:
                        sx = sorted(self._sx)
                        s_thr = sx[min(len(sx) - 1, int(len(sx) * max(0.0, min(0.9, self.cfg.explore_abstain))))]
                    else:
                        s_thr = -0.8
                    fire = hard or (S >= s_thr)
                    self._sx.append(S)
                    if not fire:
                        abstain = {"S": round(S, 2), "thr": round(s_thr, 2)}
                elif self.cfg.explore_style == "matched":
                    fire = False
                    COLD5 = _C5
                    W = max(10, int(getattr(self.cfg, "matched_window", 30)))
                    wc = Counter(seq[-W:])
                    rank = sorted(range(1, 10),
                                  key=lambda c: (-wc.get(c, 0), -p1[c - 1], c))
                    four = list(rank[:4])
                    incold = [c for c in four if c in COLD5]
                    if len(incold) > 3:
                        drop = min(incold, key=lambda c: (wc.get(c, 0), p1[c - 1]))
                        add = next(c for c in rank if c not in four and c not in COLD5)
                        four[four.index(drop)] = add
                    note = ""; gb = None
                    pcold = sorted([c for c in pend if c in COLD5], key=lambda c: -self._miss4[c])
                    phot = sorted([c for c in pend if c not in COLD5], key=lambda c: -self._miss4[c])
                    for lst, grp in ((pcold, COLD5), (phot, _H4)):
                        if lst and lst[0] not in four:
                            same = [c for c in four if c in grp]
                            out = (min(same, key=lambda c: (wc.get(c, 0), p1[c - 1]))
                                   if same else four[3])
                            four[four.index(out)] = lst[0]
                            gb = lst[0]
                            note += f"·含保底{lst[0]}号(已{self._miss4[lst[0]]}局未进预测)"
                    four.sort(key=lambda c: (-wc.get(c, 0), -p1[c - 1], c))
                    cs = [c for c in four if c in COLD5]
                    if cs or gb is not None:
                        lead = cs[0] if cs else gb
                        explore = {"cid": lead, "z": round(sig[lead][0], 3), "theta": 0.0,
                                   "why": (f"对标一致·近{W}局排座·本局带{len(cs)}只冷门"
                                           + ("/".join(str(c) for c in cs) if cs else "(纯热)")
                                           + "".join(f"·{c}号近{W}局出{wc.get(c, 0)}次"
                                                     f"(全期基准{p1[c-1]*W:.1f}次)" for c in cs[:2])
                                           + note)}
                elif _is_fr:
                    # ── 天花板前沿调度 ──────────────────────────────────────
                    # 不预测"下一局出什么"(数据证明不可预测),而是解 LP 求出
                    # 「126 个四码集合的最优使用频率」,再用确定性最大赤字轮转出集合。
                    # 零随机源、逐局可复现、份额跟踪误差 < 1 局(Bresenham 不变量)。
                    fire = False
                    # 4.9.4:概率口径由 _m1_global 换成 _p_frontier(现行 Laplace +
                    # 自适应收缩)。prior_shrink=False 或 prior_table 非法时 _p_frontier
                    # 逐位等于 _m1_global ⇒ 与改造前字节级等价。
                    # 三处消费点(LP 输入 / 主位排序 / final)必须**同用一个口径**:
                    # final 就是返回给前端的 "ens"(本函数末尾 return 处),前端把它渲染成
                    # 每个号后面那个「· XX.X%」。用两套口径会让「显示的概率」与「据以选号
                    # 的概率」脱节 —— 那是比数值本身更难查的一类失真。
                    _pfr = self._p_frontier(seq)
                    final = list(_pfr)               # 概率口径回到纯频率估计:
                    # 实测(三房 31,097 局因果):六路融合 log-loss 2.08661,常量真频
                    # 2.08022 —— 集成显著更差(t=+8.04,p=9e-16);事后最优凸组合的
                    # 权重解也是 M1=1.000、其余全 0。故此处只用 M1。
                    _mult = self._fr_multipliers()
                    _rare = self._pools_n(getattr(self.cfg, "fr_rare_ids", "3,9"), 2,
                                          (3, 9))
                    _rep = max(0, int(getattr(self.cfg, "fr_replan", 200)))
                    # 配置指纹:热更改了任一 fr_* / 冷池 / 稀有池 / 倍率表,
                    # 必须当场重规划,不能被 fr_replan 的节拍拖住(注册表把这些
                    # 参数标成 hot=HOOK,运维改完期望的是"立刻生效")。
                    # 逐号份额地板。**每个值钳到 [0, fr_share_max]** —— 手改配置写出
                    # 单个越界值(如 "3:1.5" 而 fr_share_max=0.8)时,若不钳位就会把 LP
                    # 变成不可行,放宽链随后连 fr_share_min 一起丢掉,直接落进项目明令
                    # 防范的"号饿死几百上千局"配置。钳位后越界值只是被截平,不改变可行性。
                    _smx = min(1.0, max(0.0, float(getattr(self.cfg, "fr_share_max", 1.0))))
                    _fl = {}
                    for _kv in str(getattr(self.cfg, "fr_share_floors", "") or "").split(","):
                        if ":" in _kv:
                            try:
                                _c, _v = _kv.split(":", 1)
                                _c = int(_c.strip()); _v = float(_v)
                                if 1 <= _c <= 9 and _v > 0:
                                    _fl[_c] = min(_smx, _v)
                            except (TypeError, ValueError):
                                continue
                    # prior_* 纳入指纹:热更改了先验 ⇒ p̂ 口径当场变,LP 必须立刻重解,
                    # 不能被 fr_replan 的 200 局节拍拖住(与上面 fr_* 同理)。
                    # ⚠ **仅在收缩开启时才追加这一段**,原因是 _fr_key 会**落库持久化**
                    # ("frk",见 _dump_state):无条件改变指纹格式的话,升级那一刻每个
                    # 存量房的 frk 都对不上 ⇒ 首局被强制**离期重解 LP**(旧代码本该等到
                    # _fr_plan_age >= fr_replan),重解还会顺带按新 mix 修剪赤字账本
                    # _fr_debt ⇒ 关闭态下也会出现最多 fr_replan 局的四码分歧。
                    # 关闭时不追加 ⇒ 指纹与 4.9.3 逐字节相同 ⇒ 带持久化状态的实盘升级
                    # 同样零扰动。四种切换都仍被覆盖:关→开/开→关(段落有无变化)、
                    # 开着改表(段落内容变化)、关着改表(本就无影响,不该重解)。
                    _pri = ((bool(getattr(self.cfg, "prior_shrink", False)),
                             str(getattr(self.cfg, "prior_table", "") or ""))
                            if getattr(self.cfg, "prior_shrink", False) else ())
                    _key = "|".join(str(x) for x in (
                        *_pri,
                        getattr(self.cfg, "fr_cold_min", 0.0),
                        getattr(self.cfg, "fr_rare_min", 0.0),
                        getattr(self.cfg, "fr_ret_min", 0.0),
                        getattr(self.cfg, "fr_share_min", 0.0),
                        getattr(self.cfg, "fr_share_max", 1.0),
                        sorted(_fl.items()),
                        _C5, _rare, sorted(_mult.items())))
                    _due = (self._fr_mix is None or _key != self._fr_key
                            or (bool(_rep) and self._fr_plan_age >= _rep))
                    if _due:
                        self._fr_mix, self._fr_diag = _fr_plan(
                            _pfr, _mult, _C5, _rare,
                            cold_min=float(getattr(self.cfg, "fr_cold_min", 0.0)) or None,
                            rare_min=float(getattr(self.cfg, "fr_rare_min", 0.0)) or None,
                            ret_min=float(getattr(self.cfg, "fr_ret_min", 0.0)) or None,
                            share_min=max(0.0, float(getattr(self.cfg, "fr_share_min", 0.0))),
                            share_max=min(1.0, float(getattr(self.cfg, "fr_share_max", 1.0))),
                            share_floors=_fl)
                        self._fr_plan_age = 0
                        self._fr_key = _key
                        self._fr_debt = {k: v for k, v in self._fr_debt.items()
                                         if k in self._fr_mix}
                    self._fr_plan_age += 1
                    _sch = _FrSched(self._fr_mix, self._fr_debt)
                    four = list(_sch.next())
                    self._fr_debt = dict(_sch.debt)
                    # 座次:主 2 = 四码中频率最高的两只(纯概率序,不声称择时能力)
                    four.sort(key=lambda c: (-_pfr[c - 1], c))
                    _mm = max(0.0, float(getattr(self.cfg, "fr_main_share_min", 0.0)))
                    if _mm > 0.0:
                        # 主位赤字轮转:每局给"在四码里"的号各记 _mm 的主位配额,
                        # 谁攒够 1 就顶进主位(每局最多顶 2 个,按赤字降序)。
                        # 与四码调度器同源的最大赤字规则 ⇒ 零随机、逐局可复现。
                        for _c in four:
                            self._fr_mdbt[_c] = self._fr_mdbt.get(_c, 0.0) + _mm
                        _due2 = sorted((c for c in four if self._fr_mdbt.get(c, 0.0) >= 1.0),
                                       key=lambda c: (-self._fr_mdbt[c], c))[:2]
                        if _due2:
                            _rest = [c for c in four if c not in _due2]
                            four = _due2 + _rest
                            for _c in _due2:
                                self._fr_mdbt[_c] -= 1.0
                        self._fr_mdbt = {c: v for c, v in self._fr_mdbt.items()
                                         if abs(v) > 1e-9}
                    _d = self._fr_diag or {}
                    _rl = _d.get("relaxed") or []
                    # 落款只陈述**当前生效的那种配额**,不得凭空说一个没配的"目标":
                    # 4.9.0 起聚合下限(冷门/稀有/回报)默认置 0、改由逐号地板钉份额,
                    # 此时再写"目标:冷门≥x%"是在描述一个不存在的约束。两种口径分开写。
                    _fltxt = "·".join(f"{c}号≥{v*100:.0f}%"
                                      for c, v in sorted(_fl.items())) if _fl else ""
                    _aggs = [s for s in (
                        (f"冷门≥{float(getattr(self.cfg, 'fr_cold_min', 0) or 0)*100:.2f}%"
                         if float(getattr(self.cfg, "fr_cold_min", 0) or 0) > 0 else ""),
                        (f"稀有≥{float(getattr(self.cfg, 'fr_rare_min', 0) or 0)*100:.2f}%"
                         if float(getattr(self.cfg, "fr_rare_min", 0) or 0) > 0 else ""),
                        (f"回报≥{float(getattr(self.cfg, 'fr_ret_min', 0) or 0):.2f}"
                         if float(getattr(self.cfg, "fr_ret_min", 0) or 0) > 0 else "")) if s]
                    _tgt_txt = ""
                    if _fltxt:
                        _tgt_txt += f"(露面配额:{_fltxt})"
                    if _aggs:
                        _tgt_txt += f"(下限:{'·'.join(_aggs)})"
                    explore = {"cid": four[0], "z": 0.0, "theta": 0.0,
                               "why": ("覆盖调度·本局四码由前沿配额轮转产出"
                                       + _tgt_txt
                                       + f"·本方案实测 冷门{_d.get('cold', 0)*100:.2f}%"
                                       f"·稀有{_d.get('rare', 0)*100:.2f}%"
                                       f"·回报{_d.get('ret', 0):.2f}"
                                       f"·当前方案 {_d.get('n_sets', 0)} 组轮换"
                                       f"·理论总命中 {_d.get('hit', 0)*100:.2f}%"
                                       + (f"·约束已自动放宽:{'/'.join(_rl)}" if _rl else ""))}
                elif self.cfg.explore_style == "showcase":
                    fire = False
                    COLD5, HOT4 = _C5, _H4
                    _ro = bool(getattr(self.cfg, "showcase_rotate", 1))
                    _lam = max(0.0, float(getattr(self.cfg, "sc_lambda", 0.6)))
                    _dcp = abs(float(getattr(self.cfg, "sc_debt_cap", 4.0)))

                    def _tgt(pool, eta, floor):
                        """目标份额 ∝ p^eta,抬到下限后重归一。纯确定性,零随机源。"""
                        # 在对数空间做「减最大值再指数」的归一(log-sum-exp 定式):
                        # 与直接 p**eta 数学等价、且对任意 eta 都不会溢出 ——
                        # config.yaml 手改越界(如 eta=±300)时 p**eta 会抛
                        # OverflowError 把 predict() 打崩。
                        lw = {c: (eta * math.log(max(p1[c - 1], 1e-6)) if eta != 0.0
                                  else 0.0) for c in pool}
                        _mx = max(lw.values())
                        w = {c: math.exp(max(-700.0, lw[c] - _mx)) for c in pool}
                        s0 = sum(w.values()) or 1.0
                        sh = {c: w[c] / s0 for c in pool}
                        fl = max(0.0, min(float(floor), 1.0 / len(pool)))
                        if fl > 0:
                            need = sum(max(0.0, fl - sh[c]) for c in pool)
                            sur = sum(sh[c] - fl for c in pool if sh[c] > fl)
                            if need > 0 and sur > 0:
                                sh = {c: (fl if sh[c] <= fl
                                          else sh[c] - need * (sh[c] - fl) / sur)
                                      for c in pool}
                        s1 = sum(sh.values()) or 1.0
                        return {c: v / s1 for c, v in sh.items()}

                    if _ro:
                        _tc = _tgt(COLD5, float(getattr(self.cfg, "sc_eta_cold", 1.0)),
                                   getattr(self.cfg, "sc_floor_cold", 0.0))
                        _th = _tgt(HOT4, float(getattr(self.cfg, "sc_eta_hot", 20.0)),
                                   getattr(self.cfg, "sc_floor_hot", 0.0))

                        def _rf(c):
                            # 指数额外钳到 ±60(e^60≈1.1e26,动态范围远超所需):
                            # config.yaml 是手改文件、不过注册表的 ge/le,
                            # 越界刻度不得把 predict() 打成 OverflowError。
                            _e = _lam * max(-_dcp, min(_dcp, self._dbt.get(c, 0.0)))
                            return math.exp(max(-60.0, min(60.0, _e)))
                    else:
                        _tc = _th = None

                        def _rf(c):
                            return 1.0
                    try:
                        p1s, p2s, p3s = [max(0.0, float(x)) for x in
                                         str(getattr(self.cfg, "showcase_kdist", "45,30,15")).split(",")[:3]]
                    except Exception:
                        p1s, p2s, p3s = 45.0, 30.0, 15.0
                    tot = max(1.0, p1s + p2s + p3s)
                    if tot > 95.0:
                        p1s, p2s, p3s = (x * 95.0 / tot for x in (p1s, p2s, p3s))
                    cums = ((p1s + p2s + p3s) / 100.0, (p2s + p3s) / 100.0, p3s / 100.0)
                    _cg_on = (bool(getattr(self.cfg, "cadence_governor", 0))
                              and self.cfg.explore_style == "showcase")
                    med = {}
                    for c in COLD5:
                        h = self._zh[c]
                        med[c] = sorted(h)[len(h) // 2] if len(h) >= 40 else 0.0
                    exc = sorted(((sig[c][0] - med[c], c) for c in COLD5), reverse=True)
                    fallback = (0.0, 0.35, 0.75)
                    k = 0
                    for j in range(3):
                        hh = sorted(self._kd[j])
                        thr = (hh[min(len(hh) - 1, int(len(hh) * (1.0 - cums[j])))]
                               if len(hh) >= 60 else fallback[j])
                        _kh = float(getattr(self.cfg, "as_khyst", 0.0)) if _ao else 0.0
                        # khyst 单边化(节拍器五机制之一):原式在「上一局 k 更高」时把
                        # 门槛**调低** _kh,这是标准滞回 —— 也正是时间成串的直接来源之一
                        # (实测 k=3 黏滞率 36.8~42.9% vs 独立期望 13.4%)。节拍器开启后
                        # 只保留「更难上台」那一支,不再保留「更容易赖着不走」那一支。
                        if _cg_on:
                            _th2 = thr + _kh
                        else:
                            _th2 = (thr - _kh) if self._pk > j else (thr + _kh)
                        if k == j and exc[j][0] >= _th2:
                            k = j + 1
                    # ⚠ 热身门必须用**本局判定时**的历史长度:_kd 在下一行才写入本局,
                    #    若在其后取 len 会多算一局,导致第 60 局就促发(测试
                    #    「热身期不得出现促发排播」会红)。故在写入前取快照。
                    _kd_len = len(self._kd[0])
                    for j in range(3):
                        self._kd[j].append(exc[j][0])
                    _cg_note = ""
                    if _cg_on:
                        # ── 冷位节拍器:令牌桶整形(纯确定性,零随机源)──────────────
                        # 滴水速率**就是**目标份额:rate3=cums[2]、rate2=cums[1]
                        # ⇒ 边际份额天然守恒,只把同样多的三冷/双冷局摊平到时间上。
                        # 守恒直接给出两条与数据无关的上界:
                        #   · 任意 W 局内 k>=3 的局数 <= rate3*W + cap3
                        #   · 转正后 k>=3 的旱段 <= ceil(cap3/rate3)+ceil(1/rate2)+1
                        # 刻度解析一律走容错取值:config.yaml 手改成非数(或 null)时
                        # 必须回落缺省而不是把 predict() 打崩 —— 与 _tgt 用 log-sum-exp
                        # 防 eta=±300 溢出是同一条纪律(实测 {"cg_cap3":"x"} 会抛
                        # ValueError 冒到 predict 外)。
                        def _cgf(name, dflt, lo=0.0):
                            try:
                                return max(lo, float(getattr(self.cfg, name, dflt)))
                            except (TypeError, ValueError):
                                return dflt

                        def _cgi(name, dflt, lo=0):
                            try:
                                return max(lo, int(getattr(self.cfg, name, dflt)))
                            except (TypeError, ValueError):
                                return dflt
                        _r3, _r2 = cums[2], cums[1]
                        _c3 = _cgf("cg_cap3", 1.9)
                        _c2 = _cgf("cg_cap2", 3.2)
                        _n3 = _cgi("cg_run3", 2)
                        _n2 = _cgi("cg_run2", 6)
                        _f3 = _cgf("cg_force3", 1.5)
                        _f2 = _cgf("cg_force2", 1.8)
                        # ⚠⚠ 本段与原设计的**已知偏离**,请连同下面这段一起读 ⚠⚠
                        # 方案文档《灵机推演冷位节拍器优化方案.md》不在本包内,而
                        # tests/test_cadence_governor.py 对 cg_rfloor **零断言**,
                        # 对「软促发 / 硬保底」二者的**行为差异**也零断言。
                        # 首版实现按机制清单排除法把 cg_rfloor 当成「硬保底触发阈」
                        # (阈=cap-rfloor,夹到不低于软促发阈),结果实测它是**死参数**:
                        # 0.0→2.0 逐局四码 0/3970 不同 —— 因为两条促发分支都只是把 k
                        # 抬到同一个值,差别仅在 why 的落款文字。这与本仓库反复警告的
                        # hot_rotate / showcase_q 同款病,故推翻重做。
                        # 曾考虑让「硬保底」越过 cg_run3 连串帽以做出行为差异,但那会
                        # 直接违反本文件测试的硬不变量 (a) maxrun(ks,3) <= cg_run3,不可行。
                        # 现行实现的取舍(须知悉):
                        #   · 促发**合并为单路径**(阈=cg_force*),不区分软/硬 —— 因为
                        #     在测试给出的全部约束下,找不到一种既有行为差异、又不破坏
                        #     硬不变量的区分方式;
                        #   · cg_rfloor 改作「动用预算须保留的储备」:花 1 个令牌要求桶里
                        #     先有 1.0 + rfloor。实测有效且单调(0.0/0.1/0.3/1.0/2.0 →
                        #     0 / 2338 / 2743 / 3343 / 3465 局四码不同,共 3970 局)。
                        #     它只会让花费**更保守**,故所有上界不变量天然仍成立。
                        # 若找回方案文档:请优先核对「软促发 vs 硬保底」的区分方式与
                        # cg_rfloor 的原义,并替换本段。
                        # cg_rfloor = **动用预算时须保留的储备**:花 1 个令牌要求桶里
                        # 先有 1.0 + rfloor,而不是刚够 1.0。rfloor 越大越保守。
                        _rf0 = _cgf("cg_rfloor", 0.30)
                        _need3, _need2 = 1.0 + _rf0, 1.0 + _rf0
                        # 1) 滴水
                        self._cgb3 = min(_c3, self._cgb3 + _r3)
                        self._cgb2 = min(_c2, self._cgb2 + _r2)
                        _k0 = k
                        # 2) 连串封顶(硬帽:降)
                        if k >= 3 and self._cgr3 >= _n3:
                            k = 2
                        if k >= 2 and self._cgr2 >= _n2:
                            k = min(k, 1)
                        # 3) 预算桶(没令牌不许上台:降)
                        if k >= 3 and self._cgb3 < _need3:
                            k = 2
                        if k >= 2 and self._cgb2 < _need2:
                            k = min(k, 1)
                        _down = k < _k0
                        # 4) 促发/保底(升)。热身门:阈值历史不足 60 局时只治理、不促发 ——
                        #    引擎自带的 fallback 阈值(0/0.35/0.75)本就刻意保守,
                        #    无证据时不该由预算硬把冷门推上台。
                        _warm = _kd_len >= 60
                        _ok2 = (self._cgr2 < _n2 and self._cgb2 >= _need2)
                        _ok3 = (self._cgr3 < _n3 and self._cgb3 >= _need3 and _ok2)
                        _up = ""
                        if _warm:
                            if k < 2 and _ok2 and self._cgb2 >= _f2:
                                k, _up = 2, "促发"
                            if k < 3 and _ok3 and self._cgb3 >= _f3:
                                k, _up = 3, "促发"
                        # 5) 结账:花令牌 + 推进连串计数
                        if k >= 3:
                            self._cgb3 -= 1.0
                            self._cgr3 += 1
                        else:
                            self._cgr3 = 0
                        if k >= 2:
                            self._cgb2 -= 1.0
                            self._cgr2 += 1
                        else:
                            self._cgr2 = 0
                        self._cgb3 = min(_c3, max(0.0, self._cgb3))
                        self._cgb2 = min(_c2, max(0.0, self._cgb2))
                        self._cgr3 = max(0, min(_n3, self._cgr3))
                        self._cgr2 = max(0, min(_n2, self._cgr2))
                        # 诚实落款:治理动作必须在 why 留痕,不冒充"信号占优"
                        if _up:
                            _cg_note = (f"·节奏排播({_up}:冷位数 {_k0}→{k},"
                                        f"三冷桶{self._cgb3 + 1.0 if k >= 3 else self._cgb3:.2f}"
                                        f"/{_c3:.2f})")
                        elif _down:
                            _cg_note = (f"·节奏治理(冷位数 {_k0}→{k};"
                                        + ("连串已达上限" if _k0 >= 3 and self._cgr3 == 0
                                           and _n3 > 0 else "本档预算不足")
                                        + f",三冷桶{self._cgb3:.2f}/{_c3:.2f})")
                        # 滞回跟随**实际展示**的 k,而不是未经治理的自然 k
                        self._pk = k
                    if _ao and not _cg_on:
                        self._pk = k
                    pcold = sorted([c for c in pend if c in COLD5], key=lambda c: -self._miss4[c])
                    phot = sorted([c for c in pend if c not in COLD5], key=lambda c: -self._miss4[c])
                    if pcold:
                        _k_before_floor = k
                        k = max(k, 1)
                        if _cg_note and k != _k_before_floor:
                            # 保底优先级高于节拍器(饿太久的冷号仍须带回),但落款是在
                            # 治理当时写的。若不补这一句,why 会同时出现「本局带1只冷门」
                            # 与「冷位数 X→0」——自相矛盾。诚实自解释不允许这种对不上。
                            # 注:k 由 0 抬到 1 不动任何令牌桶(cgb3 管 k>=3、cgb2 管 k>=2),
                            # 故守恒不变量不受影响。
                            _cg_note += f"·随后被保底抬回{k}只(冷号已久未进预测)"
                    note = ""
                    picks: List[int] = []
                    if k > 0:
                        # 观察期号排最后;若仍被迫携带(k 超过未罩数),取间隔最大者
                        # —— 结构上保证「刚开出下一局就带回」只剩保底一条路。
                        picks = sorted(COLD5, key=lambda c: (
                            _guarded(c),
                            -(_rgap[c] if _rg and _guarded(c) else 0),
                            -_ss(c, True) * _rf(c), -sig[c][0], c))[:k]
                        if pcold and pcold[0] not in picks:
                            picks[-1] = pcold[0]
                            note += f"·含保底{pcold[0]}号(已{self._miss4[pcold[0]]}局未进预测)"
                    hots = sorted(HOT4, key=lambda c: (
                        _guarded(c),
                        -(_rgap.get(c, 0) if _rg and _guarded(c) else 0),
                        -_ss(c) * _rf(c), c))[:4 - k]
                    if phot and phot[0] not in hots:
                        hots[-1] = phot[0]
                        note += f"·含保底{phot[0]}号(已{self._miss4[phot[0]]}局未进预测)"
                    four = sorted(hots + picks, key=lambda c: (-_so(c), c))
                    if _rg and picks:
                        _p0 = picks[0]
                        _L0 = _rg_len(_p0)
                        if _L0 > 0 and _rgap[_p0] >= _L0:
                            note += f"·{_p0}号距上次开出{_rgap[_p0]}局"
                        else:
                            for _pw in picks:   # 豁免放行的在窗号 ⇒ 落款自解释
                                _Lw = _rg_len(_pw)
                                if (_Lw > 0 and _rgap[_pw] < _Lw
                                        and not _guarded(_pw)):
                                    _m0 = _rgm_n.get(_pw, 0)
                                    _k0 = _rgm_k.get(_pw, 0)
                                    note += (f"·{_pw}号随势跟进(本窗紧随复现"
                                             f"{_k0}/{_m0}次,独立基准"
                                             f"{_m0 * p1[_pw - 1]:.1f}次)")
                                    break
                    if not picks and _cg_note:
                        # k 被治理到 0 ⇒ 本局无冷位,picks 为空,上面那支不会执行。
                        # 治理动作仍须留痕,否则「为什么这局一只冷门都没有」无处可查。
                        explore = {"cid": four[0], "z": 0.0, "theta": 0.0,
                                   "why": (f"冷门调度·目标份额{p1s:.0f}/{p2s:.0f}/{p3s:.0f}"
                                           f"·本局带0只冷门{_cg_note}")}
                    if picks:
                        pc = max(picks, key=lambda c: sig[c][0])
                        hh = sorted(self._zh[pc])
                        hi = hh[min(len(hh) - 1, int(len(hh) * 0.85))] if len(hh) >= 40 else 0.9
                        if sig[pc][0] >= hi and pc not in four[:2] and not _guarded(pc):
                            four.remove(pc)
                            four.insert(1, pc)
                            note += f"·{pc}号信号进入自身85分位高段, 升座主位"
                        lead = picks[0]
                        explore = {"cid": lead, "z": round(sig[lead][0], 3), "theta": 0.0,
                                   "why": ((f"份额轮换·冷池目标"
                                             + "/".join(f"{c}号{_tc[c]*100:.0f}%"
                                                        for c in COLD5) + "·"
                                             if _ro else "")
                                           + f"冷门调度·目标份额{p1s:.0f}/{p2s:.0f}/{p3s:.0f}"
                                           f"·本局带{k}只冷门"
                                           f"{'/'.join(str(c) for c in picks)}"
                                           f"{_cg_note}{note}·"
                                           + self._explain_signal(lead, sig[lead], 0.0)
                                             .split("≥门槛")[0])}
                else:
                    med = {}
                    for c in cold:
                        h = self._zh[c]
                        med[c] = sorted(h)[len(h) // 2] if len(h) >= 40 else 0.0
                    due = [c for c in cold if self._miss4[c] >= patrol]
                    if hard:
                        c_sig, theta, fire = worst, 0.0, True
                    elif due:
                        c_sig = max(due, key=lambda c: sig[c][0] - med[c])
                        theta = med[c_sig]
                        fire = sig[c_sig][0] >= theta
                    else:
                        eps = max(0.0, float(getattr(self.cfg, "explore_tie_eps", 0.004)))
                        c_sig = max(cold, key=lambda c: final[c - 1])
                        theta = med[c_sig]
                        gap = final[four[3] - 1] - final[c_sig - 1]
                        if eps > 0 and gap <= eps and (sig[c_sig][0] - med[c_sig]) >= 0.0:
                            fire = True
                            tie_gap = max(0.0, gap)
                        else:
                            fire = False
                    if not fire:
                        freq_cold = sorted(range(1, 10), key=lambda c: p1[c - 1])[:5]
                        if four[3] in freq_cold:
                            oc = four[3]
                            organic = {"cid": oc, "organic": True,
                                       "z": round(sig[oc][0], 3), "theta": 0.0,
                                       "why": (f"概率竞价胜出·以融合{final[oc-1]*100:.1f}%自然进入第4位"
                                               f"(未换掉任何热兽)·"
                                               + self._explain_signal(oc, sig[oc], 0.0))}
                if fire:
                    cstar: Optional[int] = None
                    if hard:
                        if worst in four:
                            abstain = {"S": 0.0, "thr": 0.0,
                                       "note": f"保底·{worst}号已{self._miss4[worst]}局未进预测, 本局保留热四选回补"}
                        else:
                            cstar, theta = worst, 0.0
                            why = f"巡检·已连续{self._miss4[worst]}局未被预测(硬保底)"
                    elif self._miss4[c_sig] >= patrol:
                        cstar = c_sig
                        why = ("巡检择时·已空" + str(self._miss4[cstar]) + "局·"
                               + self._explain_signal(cstar, sig[cstar], theta)[3:])
                    else:
                        cstar = c_sig
                        why = self._explain_signal(cstar, sig[cstar], theta)
                        if tie_gap is not None:
                            why = (f"并列竞价·与第4位融合概率仅差{tie_gap*100:.2f}pp"
                                   f"(≤容差{self.cfg.explore_tie_eps*100:.2f}pp)·信号占优故换入·" + why)
                    if cstar is not None:
                        explore = {"cid": cstar, "why": why,
                                   "z": round(sig[cstar][0], 3), "theta": round(theta, 3)}
                        four[3] = cstar
                # frontier 风格自带硬不变量(份额跟踪 <1 局),不叠加反固执熔断
                _R = (int(getattr(self.cfg, "as_breaker", 0))
                      if (_ao and not _is_fr) else 0)
                if _R > 0:
                    _pf2 = set(self._last_four or [])
                    if len(_pf2) == 4 and set(four) == _pf2 and self._cstk >= _R:
                        _hotset = _H4
                        _out = max(four, key=lambda c: (self._pen[c], -final[c - 1], c))
                        _cold = _out not in _hotset
                        _pool = [c for c in (_C5 if _cold else _hotset)
                                 if c not in four and self._cool.get(c, 0) <= 0
                                 and not _guarded(c)]
                        if not _pool:
                            _pool = [c for c in (_C5 if _cold else _hotset)
                                     if c not in four and self._cool.get(c, 0) <= 0]
                        if not _pool:
                            _pool = [c for c in range(1, 10) if c not in four]
                        _in = max(_pool, key=lambda c: (
                            (_rgap.get(c, 0) if _rg and _guarded(c) else 0),
                            _ss(c, _cold), -self._pen[c], -c))
                        four[four.index(_out)] = _in
                        four.sort(key=lambda c: (-_so(c), c))
                        self._cstk = 0
                        _H = int(getattr(self.cfg, "as_cooldown", 0))
                        if _H > 0:
                            self._cool[_out] = _H
                        _w = (f"连败换血·同四码连推且已{_R}局未中·撤下{_out}号"
                              f"(连败压力{self._pen[_out]})·同池换入{_in}号")
                        explore = {"cid": _in, "z": round(sig[_in][0], 3), "theta": 0.0,
                                   "why": (((explore or {}).get("why") or "") + "·" + _w)
                                   if explore else _w}
                # ── 连推硬帽:同四码集合连推达 sc_repeat_cap 局即强制换血一位 ──
                # 与 as_breaker(连败才换)互补 —— 这条是「连推就换」,不依赖输赢。
                # 优先在槽位多的一侧同池换;池已用尽(k=0 时四码恰为整个热池)则跨池
                # 换血(等效把 k 抬 1),保证硬帽在任何 k 下都是真不变量。
                _RC = (int(getattr(self.cfg, "sc_repeat_cap", 0))
                       if (self.cfg.explore_style == "showcase"
                           and bool(getattr(self.cfg, "showcase_rotate", 1))) else 0)
                if _RC > 0:
                    _pv = set(self._last_four or [])
                    self._rep = (self._rep + 1) if (len(_pv) == 4 and set(four) == _pv) else 0
                    if self._rep >= _RC:
                        _ci = [c for c in four if c in _C5]
                        _hi = [c for c in four if c in _H4]
                        _pool, _cur = ((_C5, _ci) if len(_ci) >= len(_hi) else (_H4, _hi))
                        # 次级键取 final 升序:赤字齐平时撤下「诉求最弱」的一号
                        # (账本钳位后热池确实会齐平饱和,此处必须语义正确)。
                        _out = min(_cur, key=lambda c: (self._dbt.get(c, 0.0),
                                                        final[c - 1], c))
                        _cand = ([c for c in _pool if c not in four
                                  and not _guarded(c)]
                                 or [c for c in _pool if c not in four])
                        if not _cand:                      # 同池无可换 → 跨池
                            _cand = ([c for c in ((_H4 + _C5)) if c not in four
                                      and not _guarded(c)]
                                     or [c for c in ((_H4 + _C5)) if c not in four])
                            _out = min(four, key=lambda c: (self._dbt.get(c, 0.0),
                                                            final[c - 1], c))
                        if _cand:
                            _in = max(_cand, key=lambda c: (
                                (_rgap.get(c, 0) if _rg and _guarded(c) else 0),
                                self._dbt.get(c, 0.0), final[c - 1], -c))
                            four[four.index(_out)] = _in
                            four.sort(key=lambda c: (-_so(c), c))
                            self._rep = 0
                            _w3 = (f"轮换换血·同四码已连推{_RC}局(硬帽)·撤下{_out}号"
                                   f"·换入{_in}号(份额赤字最大)")
                            explore = {"cid": _in, "z": round(sig[_in][0], 3), "theta": 0.0,
                                       "why": (((explore or {}).get("why") or "") + "·" + _w3)
                                       if explore else _w3}
                if explore is None and organic is not None:
                    explore = organic
                if sig is not None:
                    for c in cold:
                        self._zh[c].append(sig[c][0])
                for c in range(1, 10):
                    self._miss4[c] = 0 if c in four else self._miss4[c] + 1
                if (self.cfg.explore_style == "showcase"
                        and bool(getattr(self.cfg, "showcase_rotate", 1))):
                    _kc = sum(1 for c in four if c in _C5)
                    _sc, _sh = (_tc or {}), (_th or {})
                    for c in _C5:
                        self._dbt[c] += _sc.get(c, 0.2) * _kc
                    for c in _H4:
                        self._dbt[c] += _sh.get(c, 0.25) * (4 - _kc)
                    for c in four:
                        self._dbt[c] -= 1.0
                    # 抗积分饱和(anti-windup):目标份额若不可满足(如热池 eta 很大时
                    # 号1 每局应得 ~2.5 槽却最多只能占 1 槽),赤字会线性发散 ——
                    # 真机 1,700 局实测号1 累计 +2453、号2/7/8 −400~−976。
                    # _rf 本就在 ±cap 处饱和,故把账本一并钳在 ±cap:
                    #   · 冷池实测 |dbt| ≤ 1.4 ≪ cap ⇒ 逐字节无影响;
                    #   · 热池饱和值相同 ⇒ 输出不变(改造期全量回放逐局已验);
                    #   · 换来的是「改 sc_eta_hot 后十几局内生效」,而不是被上千局的
                    #     陈年赤字锁住 —— 让方案里那条产品可选项真正可用。
                    for c in range(1, 10):
                        self._dbt[c] = max(-_dcp, min(_dcp, self._dbt[c]))
                if (self.cfg.seat_order == "recency" and not _is_fr
                        and self.cfg.explore_style not in ("showcase", "matched")):
                    band = max(0.0, float(getattr(self.cfg, "main_swap_band", 0.0)))
                    f2, f3 = final[four[1] - 1], final[four[2] - 1]
                    z2, z3 = sig[four[1]][0], sig[four[2]][0]
                    if band > 0 and f3 >= f2 - band and z3 > z2 + 0.10:
                        seat = {"swap": [four[2], four[1]],
                                "why": (f"近势z{z3:+.2f}明显强于{four[1]}号(z{z2:+.2f}), "
                                        f"融合概率仅差{(f2 - f3) * 100:.1f}pp≤带宽"
                                        f"{band * 100:.1f}pp, 对调主2席位")}
                        four[1], four[2] = four[2], four[1]
                    four[0:2] = sorted(four[0:2], key=lambda c: (-sig[c][0], -final[c - 1], c))
                    four[2:4] = sorted(four[2:4], key=lambda c: (-sig[c][0], -final[c - 1], c))
                self._settled_seen += 1
                self._last_fp = fp
                self._last_four = list(four)
                self._last_exp = dict(explore) if explore else None
                self._last_abst = dict(abstain) if abstain else None
                self._last_seat = dict(seat) if seat else None
                if self.persistent:
                    self._save_explore_state()

        main_ids, guard_ids = four[:2], four[2:4]
        return {"models": models, "ens": final, "raw_ens": raw_ens,
                "anchor_lambda": lam, "drift": drift,
                "mode": mode, "explore": explore, "abstain": abstain, "seat": seat,
                "style": self.cfg.explore_style,
                "main": main_ids, "guard": guard_ids,
                "cover": sum(final[c - 1] for c in four),
                "weights": dict(self.weights),
                "train_n": len(seq)}

    def _hedge_step(self, models: Dict[str, Any], actual_cid: int) -> None:
        eta, mix = self.cfg.hedge_eta, self.cfg.hedge_mix
        neww = {}
        for k in MODEL_KEYS:
            p = models.get(k)
            pv = max(float(p[actual_cid - 1]), 1e-4) if p and len(p) == 9 else 1 / 9
            loss = -math.log(pv)
            neww[k] = self.weights.get(k, 1 / 6) * math.exp(-eta * loss)
        s = sum(neww.values()) or 1.0
        k_n = len(MODEL_KEYS)
        self.weights = {k: (1 - mix) * (v / s) + mix / k_n for k, v in neww.items()}

    def update_weights(self, detail: Dict[str, Any], actual_cid: int) -> None:
        models = (detail or {}).get("models") or {}
        if not models:
            return
        self._hedge_step(models, actual_cid)
        self._save_weights()

    def rebuild_weights(self) -> int:
        """从均匀权重出发，按时间顺序精确重放全部已结算预测。
        任何数据修正(删除错乱局/纠正出怪结果)之后调用，即可让权重与修正后的
        历史完全一致——这是错乱数据的最终自愈步骤。"""
        self.weights = {k: 1.0 / len(MODEL_KEYS) for k in MODEL_KEYS}
        n = 0
        if self.store is None:
            return 0
        for _, detail, actual in self.store.settled_predictions(self.room_id):
            models = (detail or {}).get("models") or {}
            if models:
                self._hedge_step(models, actual)
                n += 1
        self._miss4 = {c: 0 for c in range(1, 10)}
        self._tok = 1.0
        for c in range(1, 10):
            self._zh[c].clear()
        self._sx.clear()
        self._pen = {c: 0 for c in range(1, 10)}   # 反固执状态与其余探索态同生共死:
        self._cstk = 0                              # 数据修正后的自愈必须把连败压力/
        self._pk = -1                               # 连败计数/k记忆/冷却一并清零,
        self._cool = {}                             # 否则陈旧压力会渗进修正后的时间线
        # 4.8.0 复查补齐:上面那条纪律("探索态同生共死")在 showcase_rotate /
        # repeat_guard 上线时**没有跟进** —— 赤字账本 _dbt、连推计数 _rep、k 分位
        # 历史 _kd 一直没被自愈清零,数据修正后陈年赤字会直接渗进新时间线。
        # 连同本次新增的 frontier 状态一并归零。
        self._dbt = {c: 0.0 for c in range(1, 10)}
        self._rep = 0
        for d in self._kd:
            d.clear()
        self._fr_mix = self._fr_diag = None
        self._fr_debt = {}
        self._fr_plan_age = 0
        self._fr_key = ""
        self._fr_mdbt = {}
        self._last_fp = self._last_four = self._last_exp = self._last_abst = None
        self._last_seat = None
        self._save_explore_state()
        self._save_weights()
        return n


def render_prediction(catalog: BeastCatalog, pred: Dict[str, Any],
                      next_round_id: int, acc: Tuple[int, int, int],
                      acc_window: int,
                      acc_today: Optional[Tuple[int, int, int]] = None) -> str:
    ens = pred["ens"]

    def tag(cid: int) -> str:
        return f"{cid} {catalog.custom2name[cid]}({ens[cid-1]*100:.1f}%)"

    def rate(t: Tuple[int, int, int]) -> str:
        n, main, cover = t
        return (f"主中 {main}/{n}={main/n*100:.0f}%"
                f" | 主+防中 {cover}/{n}={cover/n*100:.0f}%")

    lines = [f" 🔮 下一局预测 round={next_round_id} "
             f"预计出怪{ms_to_local(next_round_id + DRAW_OFFSET_MS)}"
             f" (训练样本 {pred['train_n']} 局)",
             f"    主: {tag(pred['main'][0])} 、 {tag(pred['main'][1])}",
             f"    防: {tag(pred['guard'][0])} 、 {tag(pred['guard'][1])}",
             f"    四选合计覆盖 {pred['cover']*100:.1f}%"]
    if acc_today and acc_today[0]:
        lines.append(f"    当天实测: {rate(acc_today)}")
    n = acc[0]
    if n:
        lines.append(f"    近{min(n, acc_window)}局实测: {rate(acc)}"
                     f" (盲选基线 22%/44%)")
    lam = pred.get("anchor_lambda", 1.0)
    drift = pred.get("drift", 0.0)
    if pred.get("mode") == "adaptive":
        style = pred.get("style", "ceiling_adaptive")
        label = ("全员竞价·逐局天花板" if style == "ceiling_adaptive"
                 else "对标一致·近窗排座" if style == "matched"
                 else "对标观感·展示位(明码标价)" if style == "showcase" else "全信号驱动")
        seat = pred.get("seat")
        lines.append(f"    模式: 自适应·{label}[{style}](基座锚定{lam:.1f}·漂移{drift:.3f})")
        if seat and seat.get("swap"):
            a, b = seat["swap"]
            lines.append(f"    🔁 主位对调: {a} {catalog.custom2name[a]} ⇄ {b} "
                         f"{catalog.custom2name[b]} —— {seat['why']}")
        exp = pred.get("explore")
        if exp:
            cid = exp["cid"]
            title = ("本局窗口排座" if style == "matched"
                     else "本局展示位" if style == "showcase"
                     else "本局冷门(防区)" if exp.get("organic") else "本局探索位(防区)")
            lines.append(f"    🎯 {title}: {cid} {catalog.custom2name[cid]}"
                         f"({ens[cid-1]*100:.1f}%) —— {exp['why']}")
        elif pred.get("abstain"):
            ab = pred["abstain"]
            note = ab.get("note")
            if note:
                lines.append(f"    🎯 本局探索位: 弃权 —— {note}")
            else:
                lines.append(f"    🎯 本局探索位: 弃权 —— 五只冷门信号同处各自历史低位"
                             f"(S={ab['S']:+.2f}<门槛{ab['thr']:+.2f}), 维持集成原四选")
    else:
        if lam >= 0.98:
            mode = f"天花板·纯频率锚定(漂移{drift:.3f})"
        elif lam <= 0.55:
            mode = f"⚡漂移期·集成主导(漂移{drift:.3f}, 锚定{lam:.2f})"
        else:
            mode = f"过渡期(漂移{drift:.3f}, 锚定{lam:.2f})"
        lines.append(f"    模式: {mode}")
    w = pred["weights"]
    wtxt = " ".join(f"{MODEL_NAMES[k]} {w[k]*100:.0f}%" for k in MODEL_KEYS)
    lines.append(f"    模型权重: {wtxt}")
    return "\n".join(lines)



SEP = "─" * 64


class SpellTamerMonitor:
    def __init__(self, cfg: MonitorConfig, logger: logging.Logger):
        self.cfg = cfg
        self.log = logger
        self.catalog = BeastCatalog(cfg.custom_beast_ids)
        self.client = SpellTamerClient(cfg, logger)
        self.store = RoundStore(cfg.db_file, self.catalog)
        self.predictor = Predictor(cfg.prediction, self.store, cfg.room_id, logger)
        self._running = True
        self._clock_offset = 0
        self._last_round_id: Optional[int] = None
        self._rounds_since_history = 0
        self._lamp_seen: set = set()
        self._data_fp = open(cfg.data_file, "a", encoding="utf-8") if cfg.data_file else None

    def stop(self, *_):
        self._running = False

    def _emit(self, event_type: str, payload: Dict[str, Any]) -> None:
        if not self._data_fp:
            return
        rec = {"ts": bj_now().isoformat(),
               "ts_local": bj_now().strftime("%Y-%m-%d %H:%M:%S"), "type": event_type,
               "room_id": self.cfg.room_id, "activity_id": self.cfg.activity_id, **payload}
        self._data_fp.write(json.dumps(rec, ensure_ascii=False) + "\n")
        self._data_fp.flush()

    def _srv_now(self) -> int:
        return now_ms() + self._clock_offset

    def _sleep(self, seconds: float) -> None:
        end = time.monotonic() + max(0.0, seconds)
        while self._running and time.monotonic() < end:
            time.sleep(min(0.5, max(0.0, end - time.monotonic())))

    def _sleep_until_srv(self, target_ms: int) -> None:
        while self._running:
            d = (target_ms - self._srv_now()) / 1000
            if d <= 0:
                return
            time.sleep(min(0.5, d))

    def bootstrap(self) -> None:
        self.log.info("=" * 64)
        self.log.info("Spell Tamer（御剑驯妖）监控启动  v3.0"
                      f"  预测风格={self.cfg.prediction.explore_style}")
        self.log.info(f"  房间 roomId={self.cfg.room_id}  玩法 activityId={self.cfg.activity_id}")
        self.log.info(f"  出怪捕获延迟={self.cfg.award_delay}s  UID={self.cfg.auth.uid}")
        self.log.info(f"  数据库={self.cfg.db_file}  自定义编号=" + " ".join(
            f"{self.catalog.custom2name[i]}{i}" for i in range(1, 10)))
        self.log.info("=" * 64)

        pop = self.client.pop_list()
        n_pop = len((pop or {}).get("popList", []) or [])
        self.log.info(f"[启动] PopList -> {n_pop} 条弹窗")

        if self.cfg.fetch_lamp:
            self._poll_lamp(initial=True)

        self._backfill_history(tag="启动")
        try:
            since = now_ms() - 24 * 3600 * 1000
            gs = self.store.gaps(self.cfg.room_id, since)
            if gs:
                miss = sum(n for _, n in gs)
                self.log.warning(f"⚠️ 近24小时数据存在 {len(gs)} 处缺口(共缺 {miss} 局)。"
                                 f"GameHistory 只保留最近30局，更早的可运行"
                                 f" --repair 逐局尝试恢复")
            junk = self.store.junk_scan(self.cfg.room_id)
            n_bad = len(junk["offgrid"]) + len(junk["future"])
            if n_bad:
                self.log.warning(f"⚠️ 检测到 {n_bad} 行疑似错乱/垃圾数据，"
                                 f"可运行 --verify 自动体检修复")
            if junk["unknown"]:
                self.log.warning(f"🐾 库中有 {len(junk['unknown'])} 局未知妖兽(可能是平台新增)，"
                                 f"请在配置 custom_beast_ids 分配编号后重启以参与统计")
        except Exception:
            pass

    def _backfill_history(self, tag: str = "回填") -> int:
        hist = self.client.game_history()
        if not hist:
            return 0
        added = 0
        for g in hist.get("gameList", []) or []:
            try:
                rid = int(g.get("roundId", 0))
            except (TypeError, ValueError):
                continue
            bi = g.get("beastInfo") or {}
            if rid and self.store.add_round(self.cfg.room_id, rid,
                                            bi.get("beastId"), bi.get("beastName", ""),
                                            "history"):
                added += 1
                _, name, cid, _ = self.catalog.resolve(bi.get("beastId"), bi.get("beastName", ""))
                self._after_round_recorded(rid, cid, announce=False)
        if added:
            self.log.info(f"[{tag}] GameHistory 回填 {added} 局入库")
        return added

    def run(self) -> None:
        self.bootstrap()
        fails = 0
        while self._running:
            try:
                self._cycle()
                fails = 0
            except Exception as e:
                fails += 1
                self.log.exception(f"本轮异常(连续{fails}次): {e}")
                self._sleep(min(60, 5 * fails))
        self.log.info("监控停止，收尾保存...")
        self.store.close()
        if self._data_fp:
            self._data_fp.close()

    def _cycle(self) -> None:
        main = self.client.main_page()
        if not main:
            self.log.warning(f"MainPage 无有效返回，{self.cfg.mainpage_retry:.0f}s 后重试。")
            self._sleep(self.cfg.mainpage_retry)
            return

        try:
            rid = int(main.get("roundId", 0))
            srv = int(main.get("serverTime", 0))
            spell_t = int(main.get("spellTime", 0))
            draw_t = int(main.get("drawTime", 0))
            end_t = int(main.get("endTime", 0))
        except (TypeError, ValueError):
            self.log.warning(f"MainPage 字段异常: {str(main)[:200]}")
            self._sleep(self.cfg.mainpage_retry)
            return
        if not rid:
            self.log.warning("MainPage 未含 roundId，重试。")
            self._sleep(self.cfg.mainpage_retry)
            return

        if srv:
            self._clock_offset = srv - now_ms()
        can_play = main.get("canPlay")

        def remain(t: int) -> str:
            return f"{(t - self._srv_now())/1000:+.0f}s"

        self.log.info(f"[当前局] round={fmt_rid(rid)} canPlay={can_play} "
                      f"施法截止={ms_to_local(spell_t)}({remain(spell_t)}) "
                      f"出怪={ms_to_local(draw_t)}({remain(draw_t)}) "
                      f"结束={ms_to_local(end_t)}")

        if self._last_round_id is None:
            self._emit("first_seen_round", {"round_id": rid})
        elif rid != self._last_round_id:
            gap = rid - self._last_round_id
            self.log.info(f"🆕 新一局: {fmt_rid(self._last_round_id)} -> {fmt_rid(rid)}")
            self._emit("new_round", {"prev_round_id": self._last_round_id, "round_id": rid})
            if gap > ROUND_STEP:
                self.log.warning(f"检测到漏局(跨 {gap//ROUND_STEP} 局)，GameHistory 补齐...")
                self._backfill_history(tag="漏局")
            if not self.store.has_round(self.cfg.room_id, self._last_round_id):
                self._capture_award(self._last_round_id,
                                    self._last_round_id + DRAW_OFFSET_MS, tag="补拉上局")
        self._last_round_id = rid

        target = draw_t + int(self.cfg.award_delay * 1000)
        if self._srv_now() < target:
            self._sleep_until_srv(target)
        if not self._running:
            return
        if end_t and self._srv_now() > end_t + 8000:
            if not self.store.has_round(self.cfg.room_id, rid):
                self._backfill_history(tag="过期局")
            self._sleep(self.cfg.mainpage_retry)
            return
        self._capture_award(rid, draw_t)

        if self.cfg.fetch_lamp:
            self._poll_lamp()
        self._rounds_since_history += 1
        if self._rounds_since_history >= max(1, self.cfg.history_every_rounds):
            self._rounds_since_history = 0
            self._backfill_history(tag="定期校验")

        if end_t and self._srv_now() < end_t + 1000:
            self._sleep_until_srv(end_t + 1000)
        else:
            self._sleep(min(self.cfg.mainpage_retry, 2.0))

    def _capture_award(self, round_id: int, draw_t: int, tag: str = "出怪") -> bool:
        """返回 True 表示本次新记录并已完成展示(统计表+预测)。"""
        if self.store.has_round(self.cfg.room_id, round_id):
            return False
        award, bi = None, {}
        for attempt in range(1, self.cfg.award_max_retries + 1):
            if not self._running:
                return False
            award = self.client.round_award(str(round_id))
            bi = (award or {}).get("beastInfo") or {}
            if bi.get("beastId") or bi.get("beastName"):
                break
            self.log.info(f"[{tag}] round={fmt_rid(round_id)} 结果未就绪(第{attempt}次)，"
                          f"{self.cfg.award_retry_interval}s 后重试")
            self._sleep(self.cfg.award_retry_interval)
        else:
            self.log.warning(f"[{tag}] round={fmt_rid(round_id)} RoundAward 多次为空，改用 GameHistory 兜底")
            self._backfill_history(tag="兜底")
            return False

        latency = (self._srv_now() - draw_t) / 1000
        oid, name, cid, mult = self.catalog.resolve(bi.get("beastId"), bi.get("beastName", ""))
        if cid is None:
            self.log.warning(f"⚠️ 未知妖兽【{name}】(官方id={oid})——平台可能新增/改动了妖兽，"
                             f"已照常入库(不参与编号统计)，请更新 custom_beast_ids 映射")
        is_new = self.store.add_round(self.cfg.room_id, round_id, oid, name, "award")

        my_spell = award.get("spellId", 0)
        my_mult = award.get("multiplier", "")
        hit_score = award.get("hitScore", "0")
        award_status = award.get("awardStatus")
        won_flag = ""
        try:
            if my_spell and int(my_spell) == int(bi.get("beastId", -1)):
                won_flag = f"  🎉 我猜中！+{my_mult or (str(mult)+'倍')} 得分{hit_score}"
            elif my_spell:
                won_flag = f"  ✗ 我施法spellId={my_spell} 未中"
        except (TypeError, ValueError):
            pass

        rare = mult is not None and mult >= RARE_MULTIPLIER_THRESHOLD
        prefix = "💎 稀有！" if rare else ""
        self.log.info(SEP)
        line = (f"[{tag}] {prefix}round={fmt_rid(round_id)} 出怪{ms_to_local(draw_t)} "
                f"本局出【{name}】编号{cid} ({mult}倍) awardStatus={award_status}"
                f"{won_flag}   ⚡出怪后{latency:.1f}s捕获")
        (self.log.warning if rare else self.log.info)(line)

        self._emit("round_award", {
            "round_id": str(round_id), "beast_name": name, "official_id": oid,
            "custom_id": cid, "multiplier": mult, "rare": rare,
            "capture_latency_s": round(latency, 2),
            "my_spell_id": my_spell, "my_multiplier": my_mult,
            "my_hit_score": hit_score, "award_status": award_status,
        })

        if is_new and cid:
            self._after_round_recorded(round_id, cid, announce=True)
            return True
        return False

    def _after_round_recorded(self, round_id: int, actual_cid: Optional[int],
                              announce: bool) -> None:
        try:
            self._after_round_inner(round_id, actual_cid, announce)
        except Exception as e:
            self.log.error(f"统计/预测环节异常(已隔离，不影响监控): {e!r}")

    def _after_round_inner(self, round_id: int, actual_cid: Optional[int],
                           announce: bool) -> None:
        if actual_cid:
            outcome = self.store.fill_prediction_outcome(self.cfg.room_id, round_id, actual_cid)
            if outcome and outcome.get("first_time"):
                self.predictor.update_weights(outcome.get("detail") or {}, actual_cid)
                if announce:
                    mark = {"main": "✅主中", "guard": "🛡️防中", "miss": "❌全空"}[outcome["hit"]]
                    self.log.info(f" 上局预测核对: 主{outcome['main_ids']} "
                                  f"防{outcome['guard_ids']} -> 实际{actual_cid} {mark}")
        if not announce:
            return

        today = ms_to_date(round_id + DRAW_OFFSET_MS)
        day_seq = [cid for _, cid in self.store.day_rows(self.cfg.room_id, today)]
        self.log.info(SEP)
        for ln in render_day_table(self.catalog, self.cfg.room_id, today, day_seq).splitlines():
            self.log.info(ln)

        if self.cfg.prediction.enabled:
            _tw = self.cfg.prediction.train_window_hours
            _since = now_ms() - int(_tw * 3600 * 1000) if _tw and _tw > 0 else None
            seq = self.store.sequence(self.cfg.room_id, self.cfg.prediction.max_train, _since)
            pred = self.predictor.predict(seq)
            next_rid = round_id + ROUND_STEP
            self.store.save_prediction(self.cfg.room_id, next_rid,
                                       pred["main"], pred["guard"],
                                       {"models": pred["models"], "ens": pred["ens"]})
            acc = self.store.accuracy(self.cfg.room_id, self.cfg.prediction.accuracy_window)
            d0, d1 = day_bounds_ms(today)
            acc_today = self.store.accuracy_between(self.cfg.room_id, d0, d1)
            self.log.info(SEP)
            for ln in render_prediction(self.catalog, pred, next_rid, acc,
                                        self.cfg.prediction.accuracy_window,
                                        acc_today).splitlines():
                self.log.info(ln)
            self.log.info(SEP)
            self._emit("prediction", {"target_round_id": str(next_rid),
                                      "target_draw_local": ms_to_local(next_rid + DRAW_OFFSET_MS),
                                      "main": pred["main"], "guard": pred["guard"],
                                      "ens": [round(x, 5) for x in pred["ens"]]})

    def _poll_lamp(self, initial: bool = False) -> None:
        lamp = self.client.lamp_list()
        if not lamp:
            return
        items = lamp.get("lampList", []) or []
        new_items = []
        for it in items:
            key = (it.get("nick", ""), it.get("multiplier", ""))
            if key not in self._lamp_seen:
                self._lamp_seen.add(key)
                new_items.append(it)
        if initial:
            self.log.info(f"[跑马灯] 初始 {len(items)} 条命中播报")
        elif new_items:
            for it in new_items[:10]:
                self.log.info(f"[跑马灯] 🏆 {it.get('nick')} 中 {it.get('multiplier')}倍")
            self._emit("lamp_new", {"items": new_items})

    def once(self) -> None:
        self.bootstrap()
        announced = False
        main = self.client.main_page()
        if main:
            rid = int(main.get("roundId", 0) or 0)
            srv = int(main.get("serverTime", 0) or 0)
            if srv:
                self._clock_offset = srv - now_ms()
            draw_t = int(main.get("drawTime", 0) or 0)
            self.log.info(f"[当前局] round={fmt_rid(rid)} 出怪={ms_to_local(draw_t)}")
            if rid:
                self._last_round_id = rid
            if rid and draw_t and self._srv_now() >= draw_t + int(self.cfg.award_delay * 1000):
                announced = self._capture_award(rid, draw_t)
        if not announced:
            today = bj_now().strftime("%Y-%m-%d")
            day_seq = [cid for _, cid in self.store.day_rows(self.cfg.room_id, today)]
            for ln in render_day_table(self.catalog, self.cfg.room_id, today,
                                       day_seq).splitlines():
                self.log.info(ln)
            if self.cfg.prediction.enabled:
                _tw = self.cfg.prediction.train_window_hours
                _since = now_ms() - int(_tw * 3600 * 1000) if _tw and _tw > 0 else None
                seq = self.store.sequence(self.cfg.room_id, self.cfg.prediction.max_train, _since)
                if seq:
                    pred = self.predictor.predict(seq)
                    nxt = (self._last_round_id or 0) + ROUND_STEP
                    acc = self.store.accuracy(self.cfg.room_id,
                                              self.cfg.prediction.accuracy_window)
                    d0, d1 = day_bounds_ms(today)
                    acc_today = self.store.accuracy_between(self.cfg.room_id, d0, d1)
                    for ln in render_prediction(self.catalog, pred, nxt, acc,
                                                self.cfg.prediction.accuracy_window,
                                                acc_today).splitlines():
                        self.log.info(ln)
        self.store.close()



def cmd_query(cfg: MonitorConfig, args: argparse.Namespace) -> None:
    catalog = BeastCatalog(cfg.custom_beast_ids)
    store = RoundStore(cfg.db_file, catalog)

    since_ms = until_ms = None
    date_local = None
    desc = []
    if args.date:
        date_local = args.date
        desc.append(f"日期={args.date}")
    if args.days is not None:
        since_ms = now_ms() - int(args.days * 86400 * 1000)
        desc.append(f"最近{args.days}天")
    if args.hours is not None:
        since_ms = now_ms() - int(args.hours * 3600 * 1000)
        desc.append(f"最近{args.hours}小时")
    if args.time_from:
        since_ms = int(parse_dt(args.time_from).timestamp() * 1000)
        desc.append(f"从 {args.time_from}")
    if args.time_to:
        until_ms = int(parse_dt(args.time_to).timestamp() * 1000)
        desc.append(f"到 {args.time_to}")
    if not desc:
        desc.append("全部时间")

    room = args.room or cfg.room_id
    rows = store.query_rows(room, since_ms, until_ms, date_local)
    if not rows:
        print(f"(无数据) 条件: 房间={room} " + " ".join(desc))
        store.close()
        return

    by_room: Dict[str, List[sqlite3.Row]] = {}
    for r in rows:
        by_room.setdefault(r["room_id"], []).append(r)

    for rm, rs in by_room.items():
        seq = [r["custom_id"] for r in rs if r["custom_id"]]
        t0, t1 = rs[0]["draw_local"], rs[-1]["draw_local"]
        print(range_stats_table(catalog, seq,
              f"房间 {rm} | {' '.join(desc)} | 共 {len(rs)} 局 ({t0} ~ {t1})"))
        if args.detail:
            n = args.limit or 20
            print(f"  -- 最近 {min(n, len(rs))} 局明细 (新→旧) --")
            for r in list(reversed(rs))[:n]:
                print(f"  {r['draw_local']}  round={r['round_id']}  "
                      f"编号{r['custom_id']} {r['beast_name']} ({r['multiplier']}倍) [{r['source']}]")
        print()

    if args.export:
        with open(args.export, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["room_id", "round_id", "draw_local", "date_local",
                        "custom_id", "beast_name", "official_id", "multiplier", "source"])
            for r in rows:
                w.writerow([r["room_id"], r["round_id"], r["draw_local"], r["date_local"],
                            r["custom_id"], r["beast_name"], r["official_id"],
                            r["multiplier"], r["source"]])
        print(f"✅ 已导出 {len(rows)} 行 -> {args.export}")
    store.close()


def cmd_stats(cfg: MonitorConfig) -> None:
    catalog = BeastCatalog(cfg.custom_beast_ids)
    store = RoundStore(cfg.db_file, catalog)
    room = cfg.room_id
    today = bj_now().strftime("%Y-%m-%d")
    day_seq = [cid for _, cid in store.day_rows(room, today)]
    print(render_day_table(catalog, room, today, day_seq))
    print()
    seq = store.sequence(room)
    print(range_stats_table(catalog, seq, f"房间 {room} | 累计全部 | 共 {len(seq)} 局"))
    d0, d1 = day_bounds_ms(today)
    tn, tmain, tcover = store.accuracy_between(room, d0, d1)
    if tn:
        print(f"\n预测命中率(当天{tn}局): 主 {tmain}/{tn}={tmain/tn*100:.0f}%"
              f" | 主+防 {tcover}/{tn}={tcover/tn*100:.0f}%")
    n, main, cover = store.accuracy(room, cfg.prediction.accuracy_window)
    if n:
        print(f"预测命中率(近{n}局): 主 {main}/{n}={main/n*100:.0f}%"
              f" | 主+防 {cover}/{n}={cover/n*100:.0f}% (盲选基线 22%/44%)")
    store.close()


def cmd_import_har(cfg: MonitorConfig, har_path: str) -> None:
    catalog = BeastCatalog(cfg.custom_beast_ids)
    store = RoundStore(cfg.db_file, catalog)
    with open(har_path, "r", encoding="utf-8") as f:
        har = json.load(f)
    added = 0
    for e in har.get("log", {}).get("entries", []):
        url = e.get("request", {}).get("url", "")
        body = (e.get("response", {}).get("content", {}) or {}).get("text", "")
        if not body:
            continue
        try:
            d = json.loads(body)
        except ValueError:
            continue
        try:
            req = json.loads(e["request"].get("postData", {}).get("text", "{}"))
        except (ValueError, KeyError):
            req = {}
        room = str(req.get("roomId") or cfg.room_id)
        if url.endswith("GameHistory"):
            for g in d.get("gameList", []) or []:
                bi = g.get("beastInfo") or {}
                try:
                    rid = int(g.get("roundId", 0))
                except (TypeError, ValueError):
                    continue
                if rid and store.add_round(room, rid, bi.get("beastId"),
                                           bi.get("beastName", ""), "har"):
                    added += 1
        elif url.endswith("RoundAward"):
            bi = d.get("beastInfo") or {}
            try:
                rid = int(req.get("roundId", 0))
            except (TypeError, ValueError):
                continue
            if rid and (bi.get("beastId") or bi.get("beastName")):
                if store.add_round(room, rid, bi.get("beastId"),
                                   bi.get("beastName", ""), "har"):
                    added += 1
    print(f"✅ 从 {har_path} 导入 {added} 局(去重后)入库 {cfg.db_file}")
    store.close()


def cmd_import_jsonl(cfg: MonitorConfig, path: str) -> None:
    catalog = BeastCatalog(cfg.custom_beast_ids)
    store = RoundStore(cfg.db_file, catalog)
    added = 0
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except ValueError:
                continue
            if rec.get("type") != "round_award":
                continue
            try:
                rid = int(rec.get("round_id", 0))
            except (TypeError, ValueError):
                continue
            room = str(rec.get("room_id") or cfg.room_id)
            oid = rec.get("official_id", rec.get("beast_id"))
            if rid and store.add_round(room, rid, oid, rec.get("beast_name", ""), "jsonl"):
                added += 1
    print(f"✅ 从 {path} 导入 {added} 局(去重后)入库 {cfg.db_file}")
    store.close()



def cmd_backtest(cfg: MonitorConfig, args: argparse.Namespace) -> None:
    # 冷池口径与预测路径同源(去硬编码后由 prediction.showcase_cold_ids 决定)
    _BC5, _ = Predictor._pools(getattr(cfg.prediction, "showcase_cold_ids", "3,4,5,6,9"))
    """逐局前推回测：严格只用"当时已知"的历史预测下一局，检验预测器真实水平。
    同时对比 频率锚定ON/OFF 与 静态频率天花板，量化"是否已达天花板"。"""
    catalog = BeastCatalog(cfg.custom_beast_ids)
    store = RoundStore(cfg.db_file, catalog)
    room = (args.room if args.room and args.room != "all" else None) or cfg.room_id
    seq = store.sequence(room)
    store.close()
    warmup = max(9, int(args.warmup or 12))
    if len(seq) < warmup + 10:
        print(f"数据不足: 共 {len(seq)} 局，至少需要预热 {warmup} + 评估 10 局。"
              f"可先 --import-har / --import-jsonl 或让监控多跑一段时间。")
        return
    log = logging.getLogger("backtest")

    def walk(mode: str) -> Dict[str, Any]:
        """一趟walk-forward。mode: 'adaptive' 或 'ceiling'。"""
        pcfg = copy.deepcopy(cfg.prediction)
        pcfg.predict_mode = mode
        pred = Predictor(pcfg, None, room, log, persistent=False)
        r = {"n": 0, "main": 0, "cover": 0, "ll": 0.0,
             "combos": set(), "cold": Counter(), "gapmax": {c: 0 for c in range(1, 10)},
             "sig": [0, 0, 0], "pat": [0, 0, 0], "maxrun": 0,
             "coldr": 0, "org": 0, "tie": 0, "tieh": 0, "chg": 0,
             "mpairs": set(), "mchg": 0, "mcold": 0, "swap": [0, 0], "kcnt": Counter(),
             "comp": {"n": 0, "c4": 0, "c2": 0, "pairs": set(), "chg": 0, "cold": 0}}
        last = None; runlen = 0
        lastm = None
        win30: deque = deque(maxlen=30)
        for x in seq[:warmup]:
            win30.append(x)
        lastc = None
        lastin = {c: warmup - 1 for c in range(1, 10)}
        for i in range(warmup, len(seq)):
            hist, actual = seq[:i], seq[i]
            out = pred.predict(hist)
            four = out["main"] + out["guard"]
            r["ll"] += -math.log(max(out["ens"][actual - 1], 1e-9))
            r["main"] += actual in out["main"]
            r["cover"] += actual in four
            key = tuple(sorted(four))
            runlen = runlen + 1 if key == last else 1
            if last is not None and key != last:
                r["chg"] += 1
            r["maxrun"] = max(r["maxrun"], runlen); last = key
            r["combos"].add(key)
            for c in range(1, 10):
                if c in four:
                    r["gapmax"][c] = max(r["gapmax"][c], i - lastin[c] - 1)
                    lastin[c] = i
            if any(c in _BC5 for c in four):
                r["coldr"] += 1
            r["kcnt"][sum(1 for c in four if c in _BC5)] += 1
            for c in four:
                if c in _BC5:
                    r["cold"][c] += 1
            mkey = tuple(sorted(out["main"]))
            if lastm is not None and mkey != lastm:
                r["mchg"] += 1
            lastm = mkey; r["mpairs"].add(mkey)
            if any(c in _BC5 for c in out["main"]):
                r["mcold"] += 1
            st = out.get("seat")
            if st and st.get("swap"):
                r["swap"][0] += 1; r["swap"][1] += actual in out["main"]
            wc = Counter(win30)
            ctop = sorted(range(1, 10), key=lambda c: (-wc.get(c, 0), -hist.count(c), c))
            cm = r["comp"]; cm["n"] += 1
            cm["c4"] += actual in ctop[:4]; cm["c2"] += actual in ctop[:2]
            ck = tuple(sorted(ctop[:2]))
            if lastc is not None and ck != lastc:
                cm["chg"] += 1
            lastc = ck; cm["pairs"].add(ck)
            if any(c in _BC5 for c in ctop[:2]):
                cm["cold"] += 1
            win30.append(actual)
            exp = out.get("explore")
            if exp and exp.get("organic"):
                r["org"] += 1
            elif exp:
                ch = r["pat"] if "巡检" in exp["why"] else r["sig"]
                ch[0] += 1; ch[1] += actual == exp["cid"]
                if "并列竞价" in exp["why"]:
                    r["tie"] += 1
                    r["tieh"] += actual == exp["cid"]
            pred.update_weights({"models": out["models"]}, actual)
            r["n"] += 1
        r["weights"] = dict(pred.weights)
        return r

    ada = walk("adaptive")
    cei = walk("ceiling")
    n = ada["n"]

    static_cover = static_main = 0
    run_cnt = Counter(seq[:warmup])
    for i in range(warmup, len(seq)):
        actual = seq[i]
        order = sorted(range(1, 10), key=lambda c: (-run_cnt.get(c, 0), c))
        static_cover += actual in order[:4]
        static_main += actual in order[:2]
        run_cnt[actual] += 1

    def ci(h: int) -> str:
        p = h / n
        e = 1.96 * math.sqrt(p * (1 - p) / n)
        return f"{h}/{n}={p*100:.1f}% (95%CI ±{e*100:.1f})"

    style = cfg.prediction.explore_style
    print(f"🧪 逐局前推回测 | 房间 {room} | 预热 {warmup} 局 | 评估 {n} 局"
          f" | 当前配置 predict_mode={cfg.prediction.predict_mode} style={style}")
    print(f"\n  【主+防 4选覆盖】")
    print(f"    v3.0 自适应[{style}]: {ci(ada['cover'])}")
    print(f"    纯天花板模式(选择基本恒定): {cei['cover']}/{n}={cei['cover']/n*100:.1f}%")
    print(f"    静态频率上限:    {static_cover}/{n}={static_cover/n*100:.1f}%  ← 独立同分布下的理论上限")
    print(f"    盲选基线 44.4%")
    print(f"\n  【主 2选命中】 自适应 {ada['main']}/{n}={ada['main']/n*100:.1f}%"
          f" | 天花板 {cei['main']}/{n}={cei['main']/n*100:.1f}%"
          f" | 静态上限 {static_main}/{n}={static_main/n*100:.1f}% | 盲选 22.2%")
    print(f"  【平均对数损失】(越低越好)  自适应 {ada['ll']/n:.4f} | 天花板 {cei['ll']/n:.4f}"
          f" | 均匀盲猜 {math.log(9):.4f}")
    cold = ada["cold"]
    gmax = max(ada["gapmax"].values()) if ada["gapmax"] else 0
    print(f"\n  【自适应模式·多样性】四选组合 {len(ada['combos'])} 种"
          f" | 组合发生变化 {ada['chg']}/{n-1}局({ada['chg']/max(n-1,1)*100:.0f}%)"
          f" | 最长连续相同 {ada['maxrun']} 局")
    print(f"    含3/4/5/6/9的局: {ada['coldr']}/{n}={ada['coldr']/n*100:.1f}%"
          f" | 各冷门进四选局数: " + " ".join(f"{c}:{cold.get(c,0)}" for c in _BC5)
          + " | 每局冷门数k分布: " + "/".join(f"{k}只:{ada['kcnt'].get(k,0)}" for k in (0, 1, 2, 3)))
    print(f"    第4位构成: 概率榜自然入选冷门 {ada['org']}次 | 并列竞价换入 {ada['tie']}次(中{ada['tieh']})"
          f" | 信号换入 {max(0, ada['sig'][0]-ada['tie'])}次(中{max(0, ada['sig'][1]-ada['tieh'])})"
          f" | 巡检择时+硬保底 {ada['pat'][0]}次(中{ada['pat'][1]})")
    print(f"    全编号回补最大间隔 {gmax} 局 (保底铁律 ≤{cfg.prediction.explore_patrol + 15})"
          f"  ← 全部由概率竞价/规律信号/保底铁律决定, 无任何节拍或随机")
    mc = ada["mchg"] / max(n - 1, 1) * 100
    print(f"\n  【主位座次·多样性】主二组合 {len(ada['mpairs'])} 种"
          f" | 主位组成变化 {ada['mchg']}/{n-1}局({mc:.0f}%)"
          f" | 主含3/4/5/6/9: {ada['mcold']}局"
          f" | 带宽内席位对调 {ada['swap'][0]}次(对调局主中率{(ada['swap'][1]/ada['swap'][0]*100 if ada['swap'][0] else 0):.0f}%)")
    cm = ada["comp"]
    if cm["n"]:
        print(f"  【对标模拟·近30局频率排座】4选覆盖 {cm['c4']}/{cm['n']}={cm['c4']/cm['n']*100:.1f}%"
          f" | 主2命中 {cm['c2']}/{cm['n']}={cm['c2']/cm['n']*100:.1f}%"
          f" | 主二组合 {len(cm['pairs'])} 种/变化率{cm['chg']/max(cm['n']-1,1)*100:.0f}%"
          f" | 主含冷门 {cm['cold']}局")
        print(f"      ← 观感同款(主位常换、冷门可坐主), 但同一份数据上其覆盖/主中"
          f"比本策略低 {(ada['cover']-cm['c4'])/n*100:.1f}pp / {(ada['main']-cm['c2'])/n*100:.1f}pp——多样性是有价格的")
    w = (ada if cfg.prediction.predict_mode != "ceiling" else cei)["weights"]
    print("  终局模型权重: " + " ".join(f"{MODEL_NAMES[k]} {w[k]*100:.0f}%" for k in MODEL_KEYS))
    gap_a = (ada["cover"] - static_cover) / n * 100
    gap_c = (cei["cover"] - static_cover) / n * 100
    tail = ("matched 与对标逻辑一致(近窗排座+保底), 分数≈该观感在本房间数据上的可达"
            "上限; 要更高覆盖切 ceiling_adaptive" if style == "matched" else
            "showcase=冷门调度: 按目标份额 showcase_kdist 每局带 0~3 只冷门"
            "(纯热局最罕见), 该展示分布的后见之明上限≈60%, 本成绩≈贴着该上限跑"
            if style == "showcase" else
            "ceiling_adaptive 目标≈0pp——四选全由概率竞出, 不再有结构性换冷;"
            " 旧 norm_cold 在融合第4名是热兽时每局纯亏3~7pp, 已弃用")
    print(f"\n  📊 结论: 纯天花板模式距静态上限 {gap_c:+.1f}pp; 当前风格[{style}]距静态上限 {gap_a:+.1f}pp"
          f" ({tail})。")
    print(f"  ⚠️ 若差异在95%CI内则不显著；若服务端每局独立随机，任何策略长期都无法超过"
          f"'押最高频4只'这条上限——命中率高于盲选来自分布偏斜，不代表可预测下一局。")


def cmd_verify(cfg: MonitorConfig, args: argparse.Namespace) -> None:
    """错乱数据自愈: ①本地体检删垃圾行 ②最近N局对照服务器纠错 ③精确重建模型权重。"""
    catalog = BeastCatalog(cfg.custom_beast_ids)
    store = RoundStore(cfg.db_file, catalog)
    room = (args.room if args.room and args.room != "all" else None) or cfg.room_id
    dry = bool(args.dry_run)
    tagline = "(试运行，仅报告不修改)" if dry else ""
    print(f"🩺 数据体检与自愈 | 房间 {room} {tagline}")
    if not dry:
        print("   提示: 建议先停止正在运行的监控再执行(避免两个进程同时写模型权重)。")

    junk = store.junk_scan(room)
    to_delete = junk["offgrid"] + junk["future"]
    if to_delete or junk["unknown"]:
        for kind, label in (("offgrid", "偏离等差网格(疑似导入错乱)"),
                            ("future", "时间在未来(疑似脏数据)")):
            for rid in junk[kind]:
                print(f"  🗑️ {label}: {fmt_rid(rid)}")
        for rid in junk["unknown"]:
            print(f"  🐾 未知妖兽(不删除，可能是平台新增): {fmt_rid(rid)}")
        if junk["unknown"]:
            print(f"  ↳ 共 {len(junk['unknown'])} 局未知妖兽已保留。若平台确实新增了妖兽，"
                  f"请在配置 custom_beast_ids 为其分配编号后重启，即可参与统计与预测。")
        if to_delete and not dry:
            deleted = store.delete_rounds(room, to_delete)
            print(f"[体检] 删除垃圾行 {deleted} 条，其关联预测已复位待重结算")
    else:
        print("[体检] 本地扫描无垃圾/错乱行 ✅")

    depth = int(args.verify_depth if args.verify_depth is not None else 30)
    if depth > 0:
        if "PUT_YOUR_FRESH" in cfg.auth.ticket:
            print("⚠️ 票据是占位符，跳过服务器核对(仅完成本地体检)。")
        else:
            log = logging.getLogger("verify")
            if not log.handlers:
                h = logging.StreamHandler(sys.stdout)
                h.setFormatter(logging.Formatter("%(message)s"))
                log.addHandler(h)
                log.setLevel(logging.WARNING)
            client = SpellTamerClient(cfg, log)
            authoritative: Dict[int, Dict[str, Any]] = {}
            hist = client.game_history() or {}
            for g in hist.get("gameList", []) or []:
                try:
                    authoritative[int(g.get("roundId", 0))] = g.get("beastInfo") or {}
                except (TypeError, ValueError):
                    continue
            checked = fixed = unknowable = 0
            for rid, stored_name in store.recent_rows(room, depth):
                bi = authoritative.get(rid)
                if bi is None:
                    award = client.round_award(str(rid)) or {}
                    bi = award.get("beastInfo") or {}
                    time.sleep(0.35)
                if not (bi.get("beastId") or bi.get("beastName")):
                    unknowable += 1
                    continue
                checked += 1
                _, srv_name, srv_cid, _ = catalog.resolve(bi.get("beastId"),
                                                          bi.get("beastName", ""))
                if srv_name != stored_name:
                    print(f"  ✏️ {fmt_rid(rid)} 本地={stored_name} 服务器={srv_name}"
                          f"{' (试运行，不修改)' if dry else ' -> 已按服务器修正'}")
                    if not dry:
                        store.fix_round(room, rid, bi.get("beastId"),
                                        bi.get("beastName", ""), "verify")
                        if srv_cid:
                            store.fill_prediction_outcome(room, rid, srv_cid)
                    fixed += 1
            print(f"[核对] 最近{depth}局: 可核对{checked} 不一致{fixed} 服务端无数据{unknowable}"
                  + (" ✅ 全部一致" if checked and not fixed else ""))

    if not dry:
        log2 = logging.getLogger("verify")
        pred = Predictor(cfg.prediction, store, room, log2)
        n = pred.rebuild_weights()
        w = pred.weights
        print(f"[重建] 已按修正后的历史重放 {n} 条已结算预测，模型权重: "
              + " ".join(f"{MODEL_NAMES[k]}{w[k]*100:.0f}%" for k in MODEL_KEYS))
        store.checkpoint("TRUNCATE")
    store.close()


def cmd_repair(cfg: MonitorConfig, args: argparse.Namespace) -> None:
    """扫描数据库缺口并尝试恢复：先 GameHistory(近30局保证可回)，再逐局试 RoundAward。"""
    catalog = BeastCatalog(cfg.custom_beast_ids)
    store = RoundStore(cfg.db_file, catalog)
    room = (args.room if args.room and args.room != "all" else None) or cfg.room_id
    if "PUT_YOUR_FRESH" in cfg.auth.ticket:
        print("⚠️ 配置中的 x-auth-ticket 仍是占位符，请先填入有效票据再运行 --repair。")
        return
    log = logging.getLogger("repair")
    if not log.handlers:
        h = logging.StreamHandler(sys.stdout)
        h.setFormatter(logging.Formatter("%(asctime)s %(message)s", datefmt="%H:%M:%S"))
        log.addHandler(h)
        log.setLevel(logging.INFO)
    client = SpellTamerClient(cfg, log)
    predictor = Predictor(cfg.prediction, store, room, log)

    def record(rid: int, bi: Dict[str, Any], source: str) -> bool:
        if not store.add_round(room, rid, bi.get("beastId"), bi.get("beastName", ""), source):
            return False
        _, _, cid, _ = catalog.resolve(bi.get("beastId"), bi.get("beastName", ""))
        if cid:
            oc = store.fill_prediction_outcome(room, rid, cid)
            if oc and oc.get("first_time"):
                predictor.update_weights(oc.get("detail") or {}, cid)
        return True

    hist_added = 0
    hist = client.game_history() or {}
    for g in hist.get("gameList", []) or []:
        try:
            rid = int(g.get("roundId", 0))
        except (TypeError, ValueError):
            continue
        if rid and record(rid, g.get("beastInfo") or {}, "history"):
            hist_added += 1
    print(f"[修复] GameHistory 补回 {hist_added} 局(接口固定只保留最近30局)")

    days = float(args.repair_days or 3)
    since = now_ms() - int(days * 86_400_000)
    gs = store.gaps(room, since)
    missing: List[int] = []
    for start_rid, cnt in gs:
        missing.extend(start_rid + k * ROUND_STEP for k in range(cnt))
    if not missing:
        print(f"[修复] 近 {days:g} 天无缺口，数据完整 ✅")
        store.close()
        return

    cap = int(args.repair_max or 200)
    todo = missing[-cap:]
    print(f"[修复] 近 {days:g} 天发现 {len(gs)} 处缺口，共缺 {len(missing)} 局；"
          f"本次逐局尝试 RoundAward 恢复 {len(todo)} 局(上限 --repair-max={cap})...")
    ok = fail = 0
    for i, rid in enumerate(todo, 1):
        award = client.round_award(str(rid)) or {}
        bi = award.get("beastInfo") or {}
        if (bi.get("beastId") or bi.get("beastName")) and record(rid, bi, "repair"):
            ok += 1
            _, name, cid, _ = catalog.resolve(bi.get("beastId"), bi.get("beastName", ""))
            print(f"  ✅ {fmt_rid(rid)} -> {name} 编号{cid}")
        else:
            fail += 1
        if i % 25 == 0:
            print(f"  ...进度 {i}/{len(todo)} (成功{ok} 失败{fail})")
        time.sleep(0.35)
    print(f"[修复] 完成: 恢复 {ok} 局，失败 {fail} 局。"
          f"{'失败局大概率是服务端已不保留该局数据(或票据失效)，无法恢复。' if fail else ''}")
    store.close()


def setup_logger(cfg: MonitorConfig) -> logging.Logger:
    logger = logging.getLogger("spell_tamer")
    logger.setLevel(getattr(logging, cfg.log_level.upper(), logging.INFO))
    logger.handlers.clear()
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s",
                            datefmt="%Y-%m-%d %H:%M:%S")
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)
    logger.addHandler(ch)
    if cfg.log_file:
        fh = logging.handlers.RotatingFileHandler(
            cfg.log_file, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    return logger


def main() -> None:
    p = argparse.ArgumentParser(description="Spell Tamer（御剑驯妖）监控 v3.0")
    p.add_argument("-c", "--config", default=CONFIG_FILENAME,
                   help=f"配置文件路径(默认 {CONFIG_FILENAME})")
    p.add_argument("--init", action="store_true", help="生成/升级配置模板后退出")
    p.add_argument("--once", action="store_true", help="只跑一轮后退出(调试)")
    p.add_argument("--stats", action="store_true", help="打印今天+累计统计与命中率后退出")
    p.add_argument("--import-har", metavar="FILE", help="从 HAR 抓包导入历史出怪入库")
    p.add_argument("--import-jsonl", metavar="FILE", help="从旧版 events.jsonl 导入入库")
    p.add_argument("--query", action="store_true", help="离线筛选数据库")
    p.add_argument("--room", help="筛选房间(默认取配置 room_id，可用 all)")
    p.add_argument("--date", help="按本地日期筛选 YYYY-MM-DD")
    p.add_argument("--days", type=float, help="最近 N 天内(滚动)")
    p.add_argument("--hours", type=float, help="最近 N 小时内(滚动)")
    p.add_argument("--from", dest="time_from", help='起始时间 "YYYY-MM-DD[ HH:MM]"')
    p.add_argument("--to", dest="time_to", help='结束时间 "YYYY-MM-DD[ HH:MM]"')
    p.add_argument("--detail", action="store_true", help="附带逐局明细")
    p.add_argument("--limit", type=int, help="明细条数(默认20)")
    p.add_argument("--export", metavar="CSV", help="导出为 CSV 文件")
    p.add_argument("--backtest", action="store_true",
                   help="逐局前推回测预测器(只用当时已知历史)，输出命中率/对数损失/置信区间")
    p.add_argument("--warmup", type=int, help="回测预热局数(默认12)")
    p.add_argument("--repair", action="store_true",
                   help="扫描数据缺口并尝试恢复(GameHistory+逐局RoundAward)")
    p.add_argument("--repair-days", type=float, help="修复扫描范围: 近N天(默认3)")
    p.add_argument("--repair-max", type=int, help="单次最多尝试恢复局数(默认200)")
    p.add_argument("--verify", action="store_true",
                   help="数据体检与自愈: 删垃圾行+对照服务器纠错+精确重建权重")
    p.add_argument("--verify-depth", type=int,
                   help="服务器核对最近N局(默认30; 0=仅本地体检)")
    p.add_argument("--dry-run", action="store_true", help="verify试运行, 仅报告不修改")
    p.add_argument("--style",
                   choices=["ceiling_adaptive", "matched", "showcase", "norm_cold", "budget"],
                   help="本次运行临时覆盖预测风格(不改配置文件): ceiling_adaptive=分数优先"
                        " | matched=对标一致(近W局排座) | showcase=展示位 | norm_cold/budget=旧风格")
    args = p.parse_args()

    if args.init:
        write_config_template(args.config)
        return

    cfg = load_config(args.config)
    if getattr(args, "style", None):
        cfg.prediction.explore_style = args.style
        print(f"⚙️ 本次运行预测风格临时覆盖为 [{args.style}] (配置文件未改动)")

    if args.import_har:
        cmd_import_har(cfg, args.import_har)
        return
    if args.import_jsonl:
        cmd_import_jsonl(cfg, args.import_jsonl)
        return
    if args.query:
        cmd_query(cfg, args)
        return
    if args.stats:
        cmd_stats(cfg)
        return
    if args.backtest:
        cmd_backtest(cfg, args)
        return
    if args.repair:
        cmd_repair(cfg, args)
        return
    if args.verify:
        cmd_verify(cfg, args)
        return

    logger = setup_logger(cfg)
    if "PUT_YOUR_FRESH" in cfg.auth.ticket:
        logger.error("配置中的 x-auth-ticket 仍是占位符，请填入你抓包得到的真实票据。")
        sys.exit(1)

    monitor = SpellTamerMonitor(cfg, logger)
    signal.signal(signal.SIGINT, monitor.stop)
    try:
        signal.signal(signal.SIGTERM, monitor.stop)
    except (ValueError, OSError, AttributeError):
        pass

    if args.once:
        monitor.once()
        logger.info("单次抓取完成。")
    else:
        monitor.run()


if __name__ == "__main__":
    main()
