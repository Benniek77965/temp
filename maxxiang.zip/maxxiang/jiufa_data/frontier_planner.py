#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
frontier_planner.py — 「灵机推演」天花板前沿规划器（纯 Python，零第三方依赖）
================================================================================
为什么是这样：真机 36,278 局（三房 7 天）的实地核查证明出怪过程与 i.i.d. 多项分布
不可区分（21 项规律检验 p<0.05 者 0 项；转移矩阵滞后 1/2/3/5/10 全部 p>0.2；九兽
危险率对间隔 |z|≤1.8；间隔几何拟合全部 p≥0.088）。在这样的过程上有一条可证的结论：

    一个策略的长期期望表现（总命中 / 冷门命中 / 稀有命中 / 倍率回报）**只取决于**
    它使用 126 个四码集合的频率分布 x（Σx=1, x≥0），与择时、信号、顺序全部无关。

于是"最优策略"退化成一个线性规划，其解就是数学天花板 —— 不存在能超过它的算法。
本模块做两件事：

  1) `plan()`  ——  解 LP：max 总命中  s.t. 冷门/稀有/回报/单号露面 各自达标；
                   自带精确单纯形（Bland 规则，无循环、确定性），不依赖 numpy/scipy。
  2) `Scheduler` —— 按目标频率 x 逐局出集合的**确定性**最大赤字调度器
                   （Deficit Round-Robin / Bresenham），零随机源、可回放、可对拍。

诚实边界（务必与产品文案一致）：
  · 本模块**不预测**下一局出什么，也不声称发现了规律 —— 数据里没有可发现的规律。
  · 它做的是"覆盖调度"：在总命中率、冷门覆盖、稀有覆盖、倍率回报之间，取到
    数学上可证的最优折中，并让四码组合自然轮换而不是常年钉死同几个号。
  · 因此 `why` 落款只应陈述调度事实（配额/赤字/份额），不得出现任何暗示择时能力
    的措辞（如"信号 z 超门槛""历史间隔命中率"）。
"""
from __future__ import annotations

import itertools
from typing import Dict, List, Optional, Sequence, Tuple

__all__ = ["ALL_SETS", "set_metrics", "plan", "Scheduler", "LPInfeasible"]

ALL_SETS: Tuple[Tuple[int, ...], ...] = tuple(itertools.combinations(range(1, 10), 4))
_EPS = 1e-9


class LPInfeasible(Exception):
    """约束组合在当前 p̂ 下无可行解。"""


# ───────────────────────── 精确单纯形（纯 Python） ─────────────────────────
def _simplex(c: List[float], A: List[List[float]], b: List[float],
             maxit: int = 20000, rule: str = "bland") -> List[float]:
    """求 max cᵀx  s.t. Ax ≤ b, x ≥ 0（b 可为负 → 两阶段法）。
    Bland 最小下标规则 ⇒ 不循环、同输入必同输出（可回放的硬要求）。"""
    m, n = len(A), len(c)
    # ── 修复一:行均衡(equilibration)────────────────────────────────────────
    # Ax ≤ b 与 (A/s)x ≤ b/s 逐点等价(s>0),最优解不变,但把各行量纲拉回同一档。
    # 不做时系数量级跨好几档(「回报」行 ~500、「份额」行 ~1、极端 p̂ 的概率行到
    # 1e-10),固定阈值就不再有意义。
    A = [list(row) for row in A]
    b = list(b)
    for i in range(m):
        sc = max((abs(v) for v in A[i]), default=0.0)
        sc = max(sc, abs(b[i]))
        if sc > 0.0 and (sc > 1e3 or sc < 1e-3):
            inv = 1.0 / sc
            A[i] = [v * inv for v in A[i]]
            b[i] = b[i] * inv
    neg = [i for i in range(m) if b[i] < -_EPS]
    art = len(neg)
    W = n + m + art                      # 决策 + 松弛 + 人工
    nrow = m + 2                         # 末两行：phase2 目标 / phase1 目标
    T = [[0.0] * (W + 1) for _ in range(nrow)]
    for i in range(m):
        for j in range(n):
            T[i][j] = float(A[i][j])
        T[i][n + i] = 1.0
        T[i][W] = float(b[i])
    basis = [n + i for i in range(m)]
    for k, i in enumerate(neg):          # 该行整体乘 −1，再补人工变量作基
        T[i] = [-v for v in T[i]]
        T[i][n + m + k] = 1.0
        basis[i] = n + m + k

    def pivot(pr: int, pc: int) -> None:
        pv = T[pr][pc]
        T[pr] = [v / pv for v in T[pr]]
        Tp = T[pr]
        for r in range(nrow):            # ★ 必须把目标行一起消元
            if r != pr and abs(T[r][pc]) > _EPS:
                f = T[r][pc]
                Tr = T[r]
                for j in range(W + 1):
                    Tr[j] -= f * Tp[j]
        basis[pr] = pc

    def run(obj: int, ncols: int) -> None:
        for _ in range(maxit):
            pc = -1
            if rule == "bland":          # 第一个可改进列：理论上防循环
                for j in range(ncols):
                    if T[obj][j] < -1e-10:
                        pc = j
                        break
            else:                        # Dantzig：最负既约成本，收敛快
                bestc = -1e-10
                for j in range(ncols):
                    if T[obj][j] < bestc:
                        bestc, pc = T[obj][j], j
            if pc < 0:
                return
            pr, best = -1, None
            for r in range(m):
                if T[r][pc] > _EPS:
                    ratio = T[r][W] / T[r][pc]
                    # 并列判据必须**相对**:绝对 1e-12 下 5.6 与 5.6000000001 会被
                    # 判成"不并列",Bland 的最小下标离基规则随之失效 ⇒ 防循环保证
                    # 失效 ⇒ 退化基上打转到迭代上限 ⇒ 被误报"不可行"。
                    tie = 1e-9 * max(1.0, abs(ratio), abs(best or 0.0))
                    if (best is None or ratio < best - tie
                            or (abs(ratio - best) <= tie and basis[r] < basis[pr])):
                        best, pr = ratio, r
            if pr < 0:
                raise LPInfeasible("目标无界")
            pivot(pr, pc)
        raise LPInfeasible("单纯形超过迭代上限")

    if art:
        ph1 = m + 1
        for k in range(art):             # min Σa  ⇔  max −Σa
            T[ph1][n + m + k] = 1.0
        for i in neg:
            for j in range(W + 1):
                T[ph1][j] -= T[i][j]
        run(ph1, n + m)                  # 人工列不参与进基
        if abs(T[ph1][W]) > 1e-7 * max(1.0, m):   # 均衡后按行数放宽
            raise LPInfeasible("一阶段残差非零：约束不可行")
        for r in range(m):               # 残留人工基换出
            if basis[r] >= n + m:
                for j in range(n + m):
                    if abs(T[r][j]) > _EPS:
                        pivot(r, j)
                        break
    for j in range(n):                   # 装载 phase2 目标（max cᵀx）
        T[m][j] = -float(c[j])
    T[m][W] = 0.0
    for r in range(m):
        if basis[r] < n and abs(T[m][basis[r]]) > _EPS:
            f = T[m][basis[r]]
            for j in range(W + 1):
                T[m][j] -= f * T[r][j]
    run(m, n + m)
    x = [0.0] * n
    for r in range(m):
        if basis[r] < n:
            x[basis[r]] = max(0.0, T[r][W])
    return x


# ───────────────────────── 集合指标 ─────────────────────────
def set_metrics(p: Sequence[float], mult: Dict[int, int],
                cold: Sequence[int], rare: Sequence[int]
                ) -> Tuple[List[float], List[float], List[float], List[float]]:
    """返回 126 个集合的 (总命中, 冷门命中, 稀有命中, 每注回报)。
    p 为 9 维概率（索引 = 号位-1）；回报口径 = Σ p·倍率 / 4（倍率单位代理）。"""
    cs, rs = set(cold), set(rare)
    cov, cld, rar, ev = [], [], [], []
    for S in ALL_SETS:
        cov.append(sum(p[c - 1] for c in S))
        cld.append(sum(p[c - 1] for c in S if c in cs))
        rar.append(sum(p[c - 1] for c in S if c in rs))
        ev.append(sum(p[c - 1] * mult[c] for c in S) / 4.0)
    return cov, cld, rar, ev


def plan(p: Sequence[float], mult: Dict[int, int],
         cold: Sequence[int] = (3, 4, 5, 6, 9), rare: Sequence[int] = (3, 9),
         cold_min: Optional[float] = None, rare_min: Optional[float] = None,
         ret_min: Optional[float] = None, share_min: float = 0.0,
         share_max: float = 1.0, relax: bool = True,
         share_floors: Optional[Dict[int, float]] = None
         ) -> Tuple[Dict[Tuple[int, ...], float], Dict[str, object]]:
    """解 LP，返回 ({四码集合: 目标频率}, 诊断信息)。

    约束不可行时（relax=True）按 稀有 → 冷门 → 回报 → 露面 的顺序依次放宽并记录，
    保证 predict() 永不因配置越界而崩 —— 最差回落到"无约束 = 最大命中"。"""
    # ── 输入护栏:把 p̂ 的动态范围钳进单纯形能稳住的量程 ──────────────────────
    # 病灶(模糊测试实证):p 里出现 1e-10 量级的分量时,约束矩阵的动态范围到 1e9,
    # 退化基上 Bland / Dantzig 两条主元规则都会停滞并被误报"不可行"。
    # 处置是治因不治症 —— 直接给 p 设下限再重归一。语义无损:低于 1e-6 的分量
    # 对任何目标/约束的贡献都在展示精度以下。
    # 生产口径**逐字节不受影响**:p1 带 Laplace +2,1727 局窗下实测 min(p) ≈ 0.026,
    # 理论下界 2/(n+18) ≈ 0.0011,都远在 1e-6 之上,钳位不触发。
    _pf = 1e-6
    if min(p) < _pf:
        p = [max(float(v), _pf) for v in p]
        _ps = sum(p)
        p = [v / _ps for v in p]
    cov, cld, rar, ev = set_metrics(p, mult, cold, rare)
    n = len(ALL_SETS)
    share = [[1.0 if c in S else 0.0 for S in ALL_SETS] for c in range(1, 10)]
    dropped: List[str] = []
    # 放宽顺序：稀有 → 冷门 → 回报 → 露面下限 → 份额上限。
    # 份额上限排最后：它是"观感"约束，而 4/9≈0.4444 是数学下界
    # （每局用掉 4 个号 ⇒ 九号份额之和恒为 4），配到 0.25 必然不可行。
    # 放宽顺序：稀有 → 冷门 → 回报 → **逐号地板** → 露面下限 → 份额上限。
    # share_floors 必须排在 share_min **之前**被丢：share_min 是"任一号不得被饿死
    # 几百上千局"的保底保护(见 tests/test_frontier.py::test_share_floor_is_not_zero_
    # by_default)，而 share_floors 是加码。若反过来，一个写过头的地板会先把保底
    # 冲掉，落进比不配置还差的状态。
    order = [("rare", rare_min), ("cold", cold_min), ("ret", ret_min),
             ("share_floors", share_floors or None),
             ("share_min", share_min if share_min > 0 else None),
             ("share_max", share_max if share_max < 1.0 else None)]
    active = {k: v for k, v in order}
    while True:
        A: List[List[float]] = []
        b: List[float] = []
        # Σx = 1 拆成两个不等式（单纯形只吃 ≤）
        A.append([1.0] * n); b.append(1.0)
        A.append([-1.0] * n); b.append(-1.0)
        for key, vec in (("cold", cld), ("rare", rar), ("ret", ev)):
            lim = active.get(key)
            if lim is not None:
                A.append([-v for v in vec]); b.append(-float(lim))
        if active.get("share_min"):
            for row in share:
                A.append([-v for v in row]); b.append(-float(share_min))
        if active.get("share_floors") and share_floors:
            # 逐号份额地板：Σ_{S∋c} x_S ≥ floor_c。聚合约束(冷门/稀有/回报)总被
            # 最便宜的成员满足 —— 想让某个号真的出场，只能直接钉它自己的份额。
            for c, fl in sorted(share_floors.items()):
                if 1 <= int(c) <= 9 and float(fl) > 0:
                    A.append([-v for v in share[int(c) - 1]]); b.append(-float(fl))
        if active.get("share_max") is not None:
            for row in share:
                A.append(list(row)); b.append(float(active["share_max"]))
        try:
            try:
                x = _simplex(list(cov), A, b, rule="bland")
            except LPInfeasible as e:
                if "迭代上限" not in str(e):
                    raise
                # Bland 在重度退化基上会停滞（模糊测试实证：126 变量 / 十余条约束
                # 的问题能顶满迭代上限），换 Dantzig 重试。两条规则都出不来才认
                # 不可行 —— 绝不把"我算不动"说成"你无解"。
                x = _simplex(list(cov), A, b, rule="dantzig")
            # 出解 ≠ 真满足：数值算法必须自证。逐条复核，不过关按不可行走放宽路径。
            _s = sum(x) or 1.0
            _xn = [v / _s for v in x]
            for _row, _lim in zip(A, b):
                if sum(a * v for a, v in zip(_row, _xn)) > _lim + 1e-6:
                    raise LPInfeasible("解未通过约束复核")
            x = _xn
            break
        except LPInfeasible:
            if not relax:
                raise
            nxt = next((k for k, v in order if active.get(k) is not None), None)
            if nxt is None:
                raise
            active[nxt] = None
            dropped.append(nxt)
    s = sum(x) or 1.0
    mix = {ALL_SETS[i]: x[i] / s for i in range(n) if x[i] / s > 1e-6}
    ssum = sum(mix.values()) or 1.0
    mix = {k: v / ssum for k, v in mix.items()}
    diag = {
        "hit": sum(cov[ALL_SETS.index(k)] * v for k, v in mix.items()),
        "cold": sum(cld[ALL_SETS.index(k)] * v for k, v in mix.items()),
        "rare": sum(rar[ALL_SETS.index(k)] * v for k, v in mix.items()),
        "ret": sum(ev[ALL_SETS.index(k)] * v for k, v in mix.items()),
        "relaxed": dropped,
        "n_sets": len(mix),
    }
    return mix, diag


# ───────────────────────── 确定性调度器 ─────────────────────────
class Scheduler:
    """最大赤字轮转：每局给所有成分加各自目标频率，取赤字最大者出场并扣 1。
    · 零随机源；同一 (mix, 起始赤字, 步数) 必产出同一序列 —— 可回放、可对拍。
    · 任一成分的实际份额与目标份额的偏差恒 < 1 局（Bresenham 不变量）。"""

    def __init__(self, mix: Dict[Tuple[int, ...], float],
                 debt: Optional[Dict[Tuple[int, ...], float]] = None):
        if not mix:                       # 双保险:空方案 = 上游状态被写坏,
            mix = {ALL_SETS[0]: 1.0}      # 退到一个合法集合而不是让 max() 炸
        self.sets = sorted(mix, key=lambda s: (-mix[s], s))
        tot = sum(mix.values()) or 1.0
        self.w = {s: mix[s] / tot for s in self.sets}
        self.debt = {s: float((debt or {}).get(s, 0.0)) for s in self.sets}

    def next(self) -> Tuple[int, ...]:
        for s in self.sets:
            self.debt[s] += self.w[s]
        pick = max(self.sets, key=lambda s: (self.debt[s], -ALL_SETS.index(s)))
        self.debt[pick] -= 1.0
        return pick

    def dump(self) -> Dict[str, float]:
        return {",".join(map(str, s)): round(v, 6) for s, v in self.debt.items()}

    @staticmethod
    def load(raw: Optional[Dict[str, float]]) -> Dict[Tuple[int, ...], float]:
        out: Dict[Tuple[int, ...], float] = {}
        for k, v in (raw or {}).items():
            try:
                t = tuple(int(x) for x in str(k).split(","))
            except (TypeError, ValueError):
                continue
            if len(t) == 4:
                out[t] = float(v)
        return out
