# 酷狗多账号 Cookie 自动刷新（kugou_login）

酷狗登录票据 `t`（配置里 `auth.cookie` 中的那个 `t`）大约 **30 天过期**。本工具用你自己的
一组账号，定时自动登录，**只要有一个账号成功**，就把新 Cookie 写回
`spell_tamer_config.json` 的 `auth.cookie`。支持 **Docker 一起部署、随栈自动启动**。

> 仅用于登录**你自己**的账号、刷新**你自己**的会话。请勿用于他人账号。

---

## 一、两种登录方式

| 方式 | 依赖 | 说明 |
|------|------|------|
| **http（默认）** | requests / curl_cffi / pycryptodome | 纯 HTTP 走 `login_by_pwd_get`，无需浏览器，**Docker 首选**。用你提供的 `mid` 免短信验证。|
| browser（可选） | playwright | 驱动官方登录页，最抗前端改版、便于人工过滑块。`--browser` 切换。|

http 方式的加密信封（AES-256-CBC + RSA-1024）与 `签名` 均已用官方 JS / 真实抓包实证：
`python -m kugou_login.kugou_crypto`、`python kugou_sign.py` 可自检；密码信封更用 Node
实跑官方 `kguser.v2.min.js` 逐字节对拍通过（见 `tests/test_logic.py` 的
`test_pwd_envelope_matches_official_js`）。

> 密码登录结构直接取自官方 `kguser.v2.min.js` 的 `login_by_pwd_get`：
> `params = AES({"pwd": 明文密码})`（11 位酷狗ID/手机号登录时 AES 载荷里另加完整 username、
> 查询串里的 username 打码），`pk = RSA({clienttime_ms, key})`。**密码是明文经 AES 保护、
> 不是 md5**（JS 里 md5 只用于注册）。

## 二、mid（等同 kg_mid）

`mid` 由**你自己**提供：从你浏览器登录成功后的 Cookie 里取 `kg_mid` 的值（32 位十六进制）。
**用该账号上次登录成功过的那台设备的 mid**，酷狗会视为已知设备，**登录不再要短信验证**。
每个账号在 `accounts.json` 里各配一个 `mid`。

---

## 三、本地直接用

```bash
pip install requests curl_cffi pycryptodome      # http 方式(默认)
# 如需 browser 方式再: pip install playwright && playwright install chromium

cd jiufa_data/kugou_login
cp accounts.example.json accounts.json && chmod 600 accounts.json
# 编辑 accounts.json：填 username / password / mid（可放多个作备用）
```

```bash
# 在 jiufa_data 目录下：
python -m kugou_login.refresher --once            # 立刻刷新一次（逐个账号试到成功）
python -m kugou_login.refresher --check           # 检查当前 Cookie 是否有效
python -m kugou_login.refresher --daemon          # 常驻:每分钟探测 Cookie 有效性、失效即刷(另每 25 天兜底刷一次)
python -m kugou_login.refresher --once --account 0000000000   # 只用指定账号
python -m kugou_login.refresher --once --browser --headed     # 改用浏览器（首次/过滑块）
```

成功后更新 `../spell_tamer_config.json` 的 `auth.cookie`，并在 `refresh_state.json`
记录当前活跃账号与时间（下次优先试它）。

---

## 四、Docker 自动部署（随栈启动，无需手动另起）

已在 `backend_async/deploy/` 集成为一个 **`login` 服务**，`docker compose up` 时自动启动。

```bash
cd backend_async/deploy
docker compose up -d --build          # postgres/redis/worker/web + login 一起起
```

- 首启会在宿主目录 `./kgdata/`（可用 `KG_DATA_DIR` 改）生成：
  - `accounts.json`（空账号库）
  - `accounts.example.json`（参考模板）
- 编辑 `kgdata/accounts.json` 填入你自己的账号（username/password/mid）后，执行
  `docker compose restart login` 让它**立刻重新登录**。
  （守护进程按周期探测/刷新，改完账号想立即生效就重启本服务；不重启的话下个探测/刷新周期也会读到。）
- 刷新得到的新 Cookie 写入 `kgdata/spell_tamer_config.json`（持久化在宿主目录）。

**续期守护策略**：常驻模式**每分钟探测一次当前 Cookie 是否还有效、失效就立刻重登**；
另外每 25 天兜底强制刷新一次（防探测启发式误判导致永不续期）；某轮全部账号失败则每 2 小时重试。

**自动喂给抓取 worker（已打通）**：`worker` 服务已挂载同一个 `kgdata` 目录（只读）并设
`STA_AUTH_COOKIE_FILE=/kgdata/spell_tamer_config.json`。它启动时从该文件读取
`x-auth-uid`/`x-auth-ticket`，并有后台任务**每 60 秒热更新**——所以 `login` 续期后，
**worker 无需重启**就用上新票据（日志里会看到 `✅ 鉴权票据已热更新`）。首启时 `login`
要花几十秒登录写文件，worker 会在其写好后的一个探测周期内自动接上。

可调环境变量（写在 `.env` 或 compose 环境里）：

| 变量 | 默认 | 含义 |
|------|------|------|
| `KG_DATA_DIR` | `./kgdata` | 账号库/配置/状态所在宿主目录（login 写、worker 读） |
| `KG_CHECK_MINUTES` | `1` | 探测 Cookie 有效性的间隔（分钟），失效即刷（默认每 1 分钟）|
| `KG_REFRESH_DAYS` | `25` | 兜底强制刷新周期（天，<30 天过期）|
| `KG_RETRY_MINUTES` | `120` | 全部账号失败后的重试间隔（分钟）|
| `STA_AUTH_REFRESH_S` | `60` | worker 热更新票据的轮询间隔（秒）|

查看日志：`docker compose logs -f login`（登录）、`docker compose logs -f worker`（热更新/抓取）

> 说明：
> - **抓取 worker** 用的单一 `x-auth-ticket` 已由上面的桥接自动续期（uid+t 正好来自登录）。
> - **网页端账号库**（`/data/accounts.json`，网页扫码登录的多账号，用于按账号下单等）仍是
>   **另一套**，本工具默认不动它；若也想用「账号密码自动刷新」喂它，告诉我再加个适配器。
> - `--check` 的有效性探测是**启发式**（过期判定用的错误码为经验值），仅供参考；真正续期以
>   实际登录为准。守护里即便探测判不定，也有 25 天兜底刷新兜底。

---

## 注意事项

- **人机验证（SSA-CODE / 滑块）**：风控触发时 http 方式会抛错并跳过该账号（多备几个账号即可
  提高「至少一个成功」的概率）；也可 `--browser --headed` 手动过一次。工具不含任何验证码绕过。
- **TLS 指纹**：酷狗对非浏览器指纹可能扣发登录票据 → 取不到 `t`。http 方式会优先用
  `curl_cffi`（Chrome 指纹，已在依赖里）规避；请确保它已安装。
- **账号安全**：`accounts.json` 明文密码务必 `chmod 600`，或把 `password` 写成 `"env:变量名"`
  走环境变量；别提交进版本库（Docker 下它在宿主 `kgdata/`，注意别误传）。
- **合规**：自动化登录可能违反酷狗用户协议，账号被风控等风险自行承担，仅对自己的账号使用。

## 目录

```
kugou_login/
  kugou_sign.py          Web 接口签名（已用真实抓包验证）
  kugou_crypto.py        登录信封加密 AES+RSA（已实证）+ 密码信封
  cookie_util.py         Cookie 组装/解析 + 写回 spell_tamer_config.json
  http_login.py          纯 HTTP 账号密码登录（默认）
  browser_login.py       浏览器登录单账号（可选，需 playwright）
  refresher.py           多账号轮换/失败转移/定时刷新（主入口）
  login_types.py         登录结果/异常公共类型
  accounts.example.json  账号模板（复制成 accounts.json 填写）
  tests/test_logic.py    纯逻辑单测（不触网）
```
