#!/usr/bin/env python3
"""Cookie 组装 / 解析, 以及把新 Cookie 写回 spell_tamer_config.json。

与 spell_tamer_monitor.parse_kugou_cookie 保持同样口径:
    uid    <- Cookie 中的 KugooID
    ticket <- Cookie 中的 t
"""

import collections
import json
import os
from typing import Dict, List, Optional


# ---------------------------------------------------------------- 解析 ----
def parse_cookie(cookie: str) -> Dict[str, str]:
    """把浏览器 Cookie 串解析成扁平 dict, 并展开 KuGoo 复合值(t 藏在里面)。"""
    flat: Dict[str, str] = {}
    if not cookie:
        return flat
    for seg in str(cookie).split(";"):
        seg = seg.strip()
        if not seg or "=" not in seg:
            continue
        key, _, val = seg.partition("=")
        key, val = key.strip(), val.strip()
        flat[key] = val
        if "&" in val and "=" in val:  # 展开 KuGoo=a=1&b=2&...
            for sub in val.split("&"):
                if "=" not in sub:
                    continue
                sk, _, sv = sub.partition("=")
                flat[sk.strip()] = sv.strip()
    return flat


def extract_uid_ticket(cookie: str) -> Dict[str, Optional[str]]:
    jar = parse_cookie(cookie)
    return {"uid": jar.get("KugooID"), "ticket": jar.get("t")}


# ---------------------------------------------------------------- 组装 ----
def compose_cookie_from_jar(jar: List[Dict]) -> str:
    """把浏览器 context.cookies() 返回的 cookie 列表拼成标准 Cookie 请求头串。

    jar 里每项形如 {"name": "t", "value": "...", "domain": ".kugou.com", ...}。
    只保留 .kugou.com 域下的 cookie, 直接原样拼接, 最大程度保真。
    """
    parts = []
    seen = set()
    for c in jar:
        dom = (c.get("domain") or "").lstrip(".")
        if dom and "kugou.com" not in dom:
            continue
        name = c.get("name")
        if not name or name in seen:
            continue
        seen.add(name)
        parts.append(f"{name}={c.get('value', '')}")
    return "; ".join(parts)


def compose_minimal_cookie(kugoo_id: str, t: str, extra: Optional[Dict[str, str]] = None) -> str:
    """在拿不到完整 jar 时, 用 KugooID + t 拼一个够监控脚本用的最小 Cookie。

    监控脚本只从 Cookie 里取 KugooID 与 t, 所以这已足够;可通过 extra 附加字段。
    """
    kv = collections.OrderedDict()
    kugoo_inner = collections.OrderedDict()
    kugoo_inner["KugooID"] = kugoo_id
    kugoo_inner["t"] = t
    if extra:
        for k, v in extra.items():
            kugoo_inner[k] = v
    kv["KuGoo"] = "&".join(f"{k}={v}" for k, v in kugoo_inner.items())
    kv["KugooID"] = kugoo_id
    kv["t"] = t
    return "; ".join(f"{k}={v}" for k, v in kv.items())


# ------------------------------------------------ 写回 spell_tamer_config ----
def update_config_cookie(config_path: str, cookie: str) -> Dict[str, Optional[str]]:
    """把新 Cookie 写进配置文件的 auth.cookie 字段, 原子替换, 保留其余字段与顺序。

    返回本次解析出的 {uid, ticket}, 便于日志核对。
    """
    if not os.path.exists(config_path):
        raise FileNotFoundError(config_path)
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = json.load(f, object_pairs_hook=collections.OrderedDict)

    auth = cfg.get("auth")
    if not isinstance(auth, dict):
        auth = collections.OrderedDict()
        cfg["auth"] = auth
    auth["cookie"] = cookie
    # uid / ticket 由 cookie 派生, 不再静态存储 —— 若历史残留则清掉, 避免误导。
    auth.pop("uid", None)
    auth.pop("ticket", None)

    tmp = config_path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, config_path)  # 原子替换, 防止写一半损坏配置
    return extract_uid_ticket(cookie)
