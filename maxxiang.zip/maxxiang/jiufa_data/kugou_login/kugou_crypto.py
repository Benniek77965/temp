#!/usr/bin/env python3
"""酷狗登录票据信封加密(AES-256-CBC + RSA-1024-NoPadding)。

AES / RSA 与 backend_async/app/accounts/kugou_login_core.py 同源, 均出自官方
staticssl.kugou.com/common/js/min/login/kguser.v2.min.js, 并用 Node 跑官方 JS
逐字节比对通过(见 _selftest 里的参考值)。此处独立一份是为了让 kugou_login 自包含。

  · build_token_pk_params(token)            —— login_by_token_get 用
  · build_pwd_pk_params(username, password) —— login_by_pwd_get 用

密码登录信封结构直接取自官方 JS 的 login_by_pwd_get:
    t = {pwd: <明文密码>}                       # 11 位酷狗ID登录时另加 t.username=<完整ID>
    params = AES.encrypt(JSON.stringify(t))     # 密码放在 params(AES)里, 明文(非 md5!)
    pk     = RSA.encrypt({clienttime_ms, key})  # 与 token 登录同构
  注:官方 JS 里 md5 只用于「注册」, 登录发送的是明文密码(由 AES 保护)。

依赖: pip install pycryptodome
"""

import hashlib
import json
import random
import string

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

# ── 官方硬编码 RSA 公钥(1024 位, 指数 65537, NoPadding) ──────────────────────
_RSA_MOD = int(
    "B1B1EC76A1BBDBF0D18E8CD9A87E53FA3881E2F004C67C9DDA2CA677DBEFA3D6"
    "1DF8463FE12D84FF4B4699E02C9D41CAB917F5A8FB9E35580C4BDF97763A0420"
    "A476295D763EE10174E6F9EBF7DF8A77BA5B20CDA4EE705DEF5BBA3C88567B96"
    "56E52C9CD5CD95CA735FF2D25F762B133273EEEB7B4F3EA8B6DA29040F3B67CD", 16)
_RSA_EXP = 0x10001


def _rand_seed16() -> str:
    """AES 会话密钥种子: 16 位 [0-9A-Z](对应官方 t[Math.ceil(35*Math.random())])。"""
    alphabet = string.digits + string.ascii_uppercase
    return "".join(random.choice(alphabet) for _ in range(16))


def aes_encrypt(plaintext: str, seed: str) -> str:
    """AES-256-CBC / Pkcs7。
    key = UTF8(md5(seed) 的 32 位 hex) → 32 字节;iv = 该 hex 后 16 位 → 16 字节;
    输出为密文小写 hex。"""
    keyhex = hashlib.md5(seed.encode("utf-8")).hexdigest()
    key = keyhex.encode("utf-8")
    iv = keyhex[-16:].encode("utf-8")
    ct = AES.new(key, AES.MODE_CBC, iv).encrypt(pad(plaintext.encode("utf-8"), 16))
    return ct.hex()


def rsa_encrypt_nopadding(plaintext: str) -> str:
    """RSA-1024 NoPadding: 明文右补零到 128 字节, 大端整数做 m^e mod n, 输出 256 位 hex。"""
    b = plaintext.encode("latin-1")
    if len(b) > 128:
        raise ValueError("RSA 明文超过 128 字节")
    m = int.from_bytes(b.ljust(128, b"\x00"), "big")
    return format(pow(m, _RSA_EXP, _RSA_MOD), "0256x")


# ── token 登录(已实证) ──────────────────────────────────────────────────────
def build_token_pk_params(token: str, clienttime_ms: int):
    """login_by_token_get 的 (pk, params)。键序: pk 内 clienttime_ms 在前、key 在后。"""
    seed = _rand_seed16()
    params = aes_encrypt(json.dumps({"token": token}, separators=(",", ":")), seed)
    pk = rsa_encrypt_nopadding(
        json.dumps({"clienttime_ms": clienttime_ms, "key": seed}, separators=(",", ":")))
    return pk, params


# ── 账号密码登录(结构取自官方 JS) ──────────────────────────────────────────
def _is_kugou_id(username: str) -> bool:
    """11 位、位于 [1e10, 2e10) 的纯数字才按酷狗ID处理(params 里需带完整 username)。"""
    u = str(username)
    return u.isdigit() and 1e10 < int(u) < 2e10


def mask_username(username: str) -> str:
    """酷狗ID登录时查询串里的 username 要打码: 前2位 + '********' + 第11位。"""
    u = str(username)
    if _is_kugou_id(u):
        return u[:2] + "********" + u[10:11]
    return u


def build_pwd_pk_params(username: str, password: str, clienttime_ms: int):
    """login_by_pwd_get 的 (pk, params)。密码明文放进 params(AES)。

    查询串里的 username 是否要打码, 用 mask_username 另行处理。
    """
    seed = _rand_seed16()
    payload = {"pwd": password}
    if _is_kugou_id(username):
        payload["username"] = str(username)     # 完整ID放进 AES 载荷(查询串里则打码)
    params = aes_encrypt(json.dumps(payload, separators=(",", ":")), seed)
    pk = rsa_encrypt_nopadding(
        json.dumps({"clienttime_ms": clienttime_ms, "key": seed}, separators=(",", ":")))
    return pk, params


# ── 自检: 与 Node 跑官方 JS 的参考值逐字节比对(AES/RSA 基元) ──────────────────
def _selftest() -> bool:
    ok = True
    aes_ref = ("f4ef27bb3781529aad2ff388769bb25bf15f2d6f7803229e981ce3b35e0"
               "36b7ae8f8dfa4d9c5034afa16f004c17a0122")
    ok &= aes_encrypt('{"token":"testtoken1234567890abcdef"}', "ABCDEF0123456789") == aes_ref
    rsa_ref = ("5ae4560d18453248e95664982e43b482e3060e0baa84b18333acf439cfb2fa61"
               "7513da4b029b8a9c655d74e8b90f514c0054e6d3144894f56b55aaf4c80436d3"
               "202c07af95f2ca3f7c65107137dbc3be19cd81db278748f01912a33885ea59ac"
               "b356a64f42270531e20fd17f379c5fe7fb1a1f44f823bc3b53f00b020e52b5d8")
    ok &= rsa_encrypt_nopadding(
        '{"clienttime_ms":1783321779371,"key":"ABCDEF0123456789"}') == rsa_ref
    return bool(ok)


if __name__ == "__main__":
    print("crypto selftest:", "PASS ✅" if _selftest() else "FAIL ❌")
    # 用固定 seed 演示密码信封(便于和 Node 跑官方 JS 对拍)
    pk, params = build_pwd_pk_params("1473527080", "myPassw0rd", 1783490620062)
    print("pwd params(hex) =", params)
    print("pwd pk    (hex) =", pk[:32], "…")
