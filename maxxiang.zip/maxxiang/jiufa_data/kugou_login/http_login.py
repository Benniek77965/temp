#!/usr/bin/env python3
"""纯 HTTP 账号密码登录(login_by_pwd_get), 无需浏览器 —— Docker 首选。

流程(对应 login.har):
  POST https://loginservice.kugou.com/v1/login_by_pwd_get?<签名后的查询串>
  Cookie: kg_mid=<mid>; kg_mid_temp=<mid>          # 传入你自己的 mid → 免短信验证
  查询串含 username / pk / params / signature 等, 成功后响应 Set-Cookie 里带 t。

关键点:
  · mid 由你提供(等同 kg_mid)。用「用过的 mid」登录, 酷狗视为已知设备, 不再要短信验证。
  · pk / params 由本地信封加密生成(见 kugou_crypto), signature 见 kugou_sign(已实证)。
  · TLS 指纹: 酷狗对非浏览器指纹(标准库)可能扣发登录票据 → 取不到 t。故优先用
    curl_cffi 以 Chrome 指纹发包(已在 requirements 里); 未装则退回 requests(可能取不到票据)。
  · 命中人机验证时响应头带 SSA-CODE → 抛 SliderChallenge, 交由上层换账号/人工。

只用于登录你自己的账号。
"""

import time
from typing import Callable, Dict, List, Optional
from urllib.parse import urlencode

from .kugou_sign import sign_params
from .kugou_crypto import build_pwd_pk_params, mask_username
from .cookie_util import compose_cookie_from_jar, extract_uid_ticket
from .login_types import LoginResult, LoginError, SliderChallenge

LOGIN_URL = "https://loginservice.kugou.com/v1/login_by_pwd_get"

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36")


def _build_query(username: str, mid: str, pk: str, params: str, ct_ms: int) -> str:
    q = {
        "appid": "1010", "clientver": "1000",
        "clienttime": str(ct_ms), "mid": mid, "uuid": mid, "dfid": "-",
        "dev": "web", "plat": "4", "clienttime_ms": str(ct_ms),
        "support_third": "0", "support_multi": "0", "support_face_verify": "0",
        "support_verify": "1", "from_sdk": "1", "expire_day": "3",
        "autologin": "false", "username": str(username),
        "pk": pk, "params": params, "srcappid": "2919",
    }
    q["signature"] = sign_params(q)
    return urlencode(q)


def _post(url: str, cookies: Dict[str, str], timeout: float):
    """优先用 curl_cffi(Chrome 指纹), 退回 requests。返回 (status, headers, set_cookie_jar)。

    set_cookie_jar 统一成 [{"name","value","domain"}] 形式, 便于组装 Cookie。
    """
    headers = {"User-Agent": _UA, "Origin": "https://fanxing.kugou.com",
               "Referer": "https://fanxing.kugou.com/"}
    # ---- 1) curl_cffi(强烈推荐, 避免 TLS 指纹被扣票据) ----
    try:
        from curl_cffi import requests as creq
        r = creq.post(url, headers=headers, cookies=cookies, data=b"",
                      timeout=timeout, impersonate="chrome")
        jar = [{"name": k, "value": v, "domain": ".kugou.com"} for k, v in r.cookies.items()]
        return r.status_code, dict(r.headers), jar, (r.text or "")
    except ImportError:
        pass
    # ---- 2) requests 兜底 ----
    import requests
    s = requests.Session()
    for k, v in cookies.items():
        s.cookies.set(k, v, domain=".kugou.com")
    r = s.post(url, headers=headers, data=b"", timeout=timeout)
    jar = [{"name": c.name, "value": c.value, "domain": c.domain or ".kugou.com"}
           for c in s.cookies]
    return r.status_code, dict(r.headers), jar, (r.text or "")


def login_once(
    username: str,
    password: str,
    *,
    mid: Optional[str] = None,
    timeout: float = 20.0,
    on_status: Optional[Callable[[str], None]] = None,
    **_ignore,   # 吞掉 headless/proxy 等仅浏览器方案用的参数, 保持与 browser_login 同签名
) -> LoginResult:
    """用账号密码 + mid 登录, 成功返回 LoginResult, 失败抛 LoginError/SliderChallenge。"""
    status = on_status or (lambda *_: None)
    if not mid:
        raise LoginError(f"账号 {username} 缺少 mid。请在 accounts.json 里为该账号填入 mid"
                         "(等同 kg_mid;用你自己用过的 mid 可免短信验证)。")

    ct_ms = int(time.time() * 1000)
    pk, params = build_pwd_pk_params(username, password, ct_ms)
    # 11 位酷狗ID登录时查询串里的 username 要打码(完整ID已在 params 的 AES 载荷里)
    url = f"{LOGIN_URL}?{_build_query(mask_username(username), mid, pk, params, ct_ms)}"
    cookies = {"kg_mid": mid, "kg_mid_temp": mid}

    status("提交账号密码登录…")
    try:
        st, headers, jar, body = _post(url, cookies, timeout)
    except Exception as e:
        raise LoginError(f"登录请求异常: {type(e).__name__}: {e}") from e

    # 人机验证(SSA-CODE)
    ssa = ""
    for k, v in headers.items():
        if k.lower() == "ssa-code":
            ssa = v
            break
    if ssa or ("需要验证" in body) or ("slide" in body.lower()):
        raise SliderChallenge(f"命中人机验证(SSA-CODE={ssa or '?'})。请换个账号, "
                              "或先用 --browser 有头模式手动过一次。")

    # 成功判据: cookie 里拿到 KugooID + t
    all_cookies = list(jar) + [{"name": "kg_mid", "value": mid, "domain": ".kugou.com"}]
    cookie = compose_cookie_from_jar(all_cookies)
    info = extract_uid_ticket(cookie)
    if info.get("uid") and info.get("ticket"):
        status("登录成功, 已取到 t")
        return LoginResult(username=username, kugoo_id=info["uid"], t=info["ticket"],
                           cookie=cookie, raw_jar=all_cookies)

    # 没拿到票据: 给出可诊断的信息
    snippet = (body or "").strip().replace("\n", " ")[:200]
    raise LoginError(
        f"登录未取到 t(HTTP {st})。常见原因: ①密码错误 ②mid 不是该账号用过的设备 "
        f"③未装 curl_cffi 导致 TLS 指纹被扣票据。响应片段: {snippet or '(空)'}")
