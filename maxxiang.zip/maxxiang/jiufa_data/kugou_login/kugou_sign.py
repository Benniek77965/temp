#!/usr/bin/env python3
"""酷狗 Web 端接口签名算法。

已用 login.har 里真实的 login_by_pwd_get 请求逐字节验证:
    signature = MD5( SALT + "".join(f"{k}={v}" for k,v in sorted(params)) + SALT ).upper()
其中 params 为除 signature 外的全部查询参数, 按 key 升序排列。

SALT 为酷狗 Web 端公开的固定盐 (存在于其前端 JS 中, 非账号密钥)。
本模块只做参数签名, 不涉及任何账号凭据。
"""

import hashlib
from typing import Dict, Iterable, Tuple

# 酷狗 Web 端固定签名盐(公开常量, 见其登录 JS)。
KUGOU_WEB_SALT = "NVPh5oo715z5DIWAeQlhMDsWXXQV4hwt"


def sign_params(params: Dict[str, str], salt: str = KUGOU_WEB_SALT) -> str:
    """对参数字典计算 signature(大写 32 位 MD5)。

    传入的 params 不要包含 signature 本身;value 会被转成 str。
    """
    items: Iterable[Tuple[str, str]] = sorted(
        (str(k), "" if v is None else str(v)) for k, v in params.items() if k != "signature"
    )
    raw = salt + "".join(f"{k}={v}" for k, v in items) + salt
    return hashlib.md5(raw.encode("utf-8")).hexdigest().upper()


def with_signature(params: Dict[str, str], salt: str = KUGOU_WEB_SALT) -> Dict[str, str]:
    """返回带 signature 字段的新参数字典(浅拷贝)。"""
    out = {k: v for k, v in params.items() if k != "signature"}
    out["signature"] = sign_params(out, salt)
    return out


if __name__ == "__main__":
    # 自检:用 HAR 中真实请求的参数复现 signature。
    demo = {
        "appid": "1010", "clientver": "1000", "clienttime": "1783490620062",
        "mid": "79f1e8221cf75ffa936893eca4ee5398",
        "uuid": "79f1e8221cf75ffa936893eca4ee5398", "dfid": "-", "dev": "web",
        "plat": "4", "clienttime_ms": "1783490620062", "support_third": "0",
        "support_multi": "0", "support_face_verify": "0", "support_verify": "1",
        "from_sdk": "1", "expire_day": "3", "autologin": "false",
        "username": "0000000000",
        "pk": ("1f2b5dce08f677d95eb58ea50c39bb1f3c5b568f6e7fc30e39bae071990e975878aa72fab5"
               "f61aad8157fe3b2b2ff031bcb1425743a64ee89e00f11a70f950d2c92c8407d486c7218a5"
               "e00274d9575ff76b0d40aef52613d76d10ab3aa350d7a0bee3dac292a2d52e8bda132cdb2"
               "cca5032efdbd3d83d08e16d4fb45e678a98a"),
        "params": "20a4cde77c63ee3470736f52260a867b737821143311d7787426c2c989e9399e",
        "srcappid": "2919",
    }
    got = sign_params(demo)
    expect = "8FB67271BA258C89826998A7A9227BE5"
    print("signature =", got, "OK" if got == expect else f"MISMATCH (expect {expect})")
