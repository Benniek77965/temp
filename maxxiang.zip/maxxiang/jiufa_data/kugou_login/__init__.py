"""酷狗多账号 Cookie 自动登录 / 刷新工具包。

模块:
  kugou_sign    —— Web 接口签名(已用真实抓包验证)
  kugou_crypto  —— 登录票据信封加密 AES+RSA(与后端同源, 已实证)
  cookie_util   —— Cookie 组装/解析, 写回 spell_tamer_config.json
  http_login    —— 纯 HTTP 账号密码登录(默认, 无浏览器, Docker 友好)
  browser_login —— 浏览器登录单账号(可选, 需 playwright)
  refresher     —— 多账号轮换/失败转移/定时刷新(主入口)

注: kugou_crypto/http_login 需 pycryptodome 等依赖, 故不在包级默认导入,
    用到时按需 import(见各模块)。
"""

from .cookie_util import (
    parse_cookie, extract_uid_ticket,
    compose_cookie_from_jar, compose_minimal_cookie, update_config_cookie,
)
from .kugou_sign import sign_params, with_signature, KUGOU_WEB_SALT
from .login_types import LoginResult, LoginError, SliderChallenge

__all__ = [
    "parse_cookie", "extract_uid_ticket",
    "compose_cookie_from_jar", "compose_minimal_cookie", "update_config_cookie",
    "sign_params", "with_signature", "KUGOU_WEB_SALT",
    "LoginResult", "LoginError", "SliderChallenge",
]
