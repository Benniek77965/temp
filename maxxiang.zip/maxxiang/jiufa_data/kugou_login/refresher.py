#!/usr/bin/env python3
"""多账号 Cookie 自动刷新器。

目标(对应需求):
  · 维护 N 个【你自己的】酷狗账号(账号密码放在 accounts.json)。
  · 定时尝试登录, 逐个试, 只要有 1 个成功就把新 Cookie 写进 spell_tamer_config.json。
  · 酷狗 t 大约 30 天过期, 所以默认每 25 天刷新一次(留出缓冲); 失败则更短间隔重试。

用法:
  python -m kugou_login.refresher --once            # 立刻刷新一次(试到一个成功为止)
  python -m kugou_login.refresher --once --headed   # 有头模式(首次/过滑块时用)
  python -m kugou_login.refresher --daemon          # 常驻, 到期自动刷新
  python -m kugou_login.refresher --check           # 检查当前 Cookie 是否还有效
  python -m kugou_login.refresher --account 1476..  # 只用指定账号刷新

也可直接被别的脚本调用: refresh_once(cfg) / RefreshManager。

安全提醒: accounts.json 含明文密码, 请 chmod 600 并妥善保管;支持用
          "password": "env:VAR_NAME" 从环境变量读取, 避免落盘明文。
"""

import argparse
import collections
import json
import logging
import os
import sys
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from .cookie_util import extract_uid_ticket, update_config_cookie

# 登录实现可替换(便于测试/换方案)。默认用纯 HTTP(轻量, Docker 友好),
# 也可切到浏览器方案(--browser, 更抗改版/便于人工过滑块)。
from .login_types import LoginError, SliderChallenge

try:
    from .http_login import login_once as _http_login_once
except Exception:  # pragma: no cover
    _http_login_once = None

try:
    from .browser_login import login_once as _browser_login_once
except Exception:  # pragma: no cover
    _browser_login_once = None


def _pick_login_fn(method: str):
    if method == "browser":
        return _browser_login_once
    return _http_login_once


_HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_ACCOUNTS = os.path.join(_HERE, "accounts.json")
DEFAULT_CONFIG = os.path.normpath(os.path.join(_HERE, "..", "spell_tamer_config.json"))
DEFAULT_STATE = os.path.join(_HERE, "refresh_state.json")

log = logging.getLogger("kugou_login")

_CHECK_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
             "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36")


# ------------------------------------------------------------- 数据结构 ----
@dataclass
class Account:
    username: str
    password: str
    mid: str = ""          # 等同 kg_mid;用你自己用过的 mid 可免短信验证
    note: str = ""
    enabled: bool = True

    def resolve_password(self) -> str:
        """支持 env: 前缀从环境变量取密码。"""
        if self.password.startswith("env:"):
            var = self.password[4:]
            val = os.environ.get(var)
            if not val:
                raise LoginError(f"环境变量 {var} 未设置(账号 {self.username} 的密码)")
            return val
        return self.password


@dataclass
class RefreshConfig:
    accounts_path: str = DEFAULT_ACCOUNTS
    config_path: str = DEFAULT_CONFIG
    state_path: str = DEFAULT_STATE
    refresh_days: float = 25.0        # 兜底强制刷新周期(< 30 天过期), 探测失效时会更早刷
    retry_minutes: float = 120.0      # 全部账号失败后的重试间隔
    check_interval_s: float = 60.0    # 定期探测 Cookie 有效性的间隔(秒), 默认每 1 分钟
    method: str = "http"              # 登录方式: "http"(默认, 轻量) | "browser"
    headless: bool = True
    per_account_timeout: float = 30.0
    proxy: Optional[str] = None
    login_fn: Optional[Callable] = None   # 覆盖登录实现(测试/自定义用)


# --------------------------------------------------------------- 载入 ----
def load_accounts(path: str) -> List[Account]:
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"找不到账号文件: {path}\n请复制 accounts.example.json 为 accounts.json 并填入你自己的账号。")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict):          # 允许 {"accounts": [...]} 或直接 [...]
        data = data.get("accounts", [])
    accts = []
    for item in data:
        if str(item.get("username", "")).startswith("_"):   # 跳过模板里的 _说明 之类
            continue
        accts.append(Account(
            username=str(item["username"]).strip(),
            password=str(item.get("password", "")),
            mid=str(item.get("mid", "")).strip(),
            note=str(item.get("note", "")),
            enabled=bool(item.get("enabled", True)),
        ))
    return [a for a in accts if a.enabled and a.username]


def load_state(path: str) -> Dict:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(path: str, state: Dict) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, path)


# ------------------------------------------------------------ 核心逻辑 ----
class RefreshManager:
    def __init__(self, cfg: RefreshConfig):
        self.cfg = cfg
        self.login_fn = cfg.login_fn or _pick_login_fn(cfg.method)
        if self.login_fn is None:
            raise LoginError(
                f"登录方式 '{cfg.method}' 不可用。http 需要 requests/curl_cffi + pycryptodome; "
                "browser 需要 playwright。请检查依赖安装。")
        # 管理台「立即触发续期」信号文件:与 state 同目录(compose 下即 /kgdata)。
        # web 侧写入该文件, daemon 在休眠中以 ≤2s 粒度感知并提前醒来消费 —— 改完
        # 账号库不必重启本服务、也不必苦等重试/兜底周期。旧版镜像遇到该文件会忽略,
        # 纯增量兼容。
        self.trigger_path = os.path.join(
            os.path.dirname(self.cfg.state_path) or ".", "refresh_now")
        # 降级守卫:触发文件删不掉(目录权限异常)时,记录已按触发处理过的那份
        # 文件 mtime,同一份残留绝不重复触发 —— 否则会陷入连环重登热循环
        # (实测 8 秒可打出上万次登录,足以触发风控锁号并刷爆日志)。
        self._handled_trigger_mtime = None

    def _order_accounts(self, accounts: List[Account]) -> List[Account]:
        """把上次成功的账号排到最前面, 提高一次命中率。"""
        state = load_state(self.cfg.state_path)
        last = state.get("active_username")
        if last:
            accounts = sorted(accounts, key=lambda a: 0 if a.username == last else 1)
        return accounts

    def refresh_once(self, only_username: Optional[str] = None) -> bool:
        """逐个账号尝试登录, 第一个成功就写回配置并记录状态。返回是否成功。"""
        accounts = load_accounts(self.cfg.accounts_path)
        if only_username:
            accounts = [a for a in accounts if a.username == only_username]
        accounts = self._order_accounts(accounts)
        if not accounts:
            log.error("没有可用账号。")
            return False

        errors = []
        for acct in accounts:
            log.info("尝试登录账号 %s %s", acct.username,
                     f"({acct.note})" if acct.note else "")
            try:
                result = self.login_fn(
                    acct.username, acct.resolve_password(),
                    mid=acct.mid,
                    headless=self.cfg.headless,
                    timeout=self.cfg.per_account_timeout,
                    proxy=self.cfg.proxy,
                    on_status=lambda s, u=acct.username: log.debug("[%s] %s", u, s),
                )
            except SliderChallenge as e:
                log.warning("账号 %s 命中滑块: %s", acct.username, e)
                errors.append((acct.username, f"slider: {e}"))
                continue
            except LoginError as e:
                log.warning("账号 %s 登录失败: %s", acct.username, e)
                errors.append((acct.username, str(e)))
                continue
            except Exception as e:  # 兜底, 不让单个账号异常中断整轮
                log.warning("账号 %s 异常: %s", acct.username, e)
                errors.append((acct.username, repr(e)))
                continue

            # 成功:写回配置 + 记录状态
            info = update_config_cookie(self.cfg.config_path, result.cookie)
            log.info("✅ 登录成功: %s → 已写入 %s (uid=%s ticket=%s…)",
                     result.summary(), os.path.basename(self.cfg.config_path),
                     info["uid"], (info["ticket"] or "")[:12])
            save_state(self.cfg.state_path, {
                "active_username": acct.username,
                "kugoo_id": result.kugoo_id,
                "refreshed_at": time.time(),
                "refreshed_at_str": time.strftime("%Y-%m-%d %H:%M:%S"),
                "last_result": "ok",
            })
            return True

        log.error("❌ 全部 %d 个账号都没登录成功: %s", len(accounts), errors)
        st = load_state(self.cfg.state_path)
        st.update({"last_result": "fail", "last_fail_at": time.time(),
                   "last_errors": errors})
        save_state(self.cfg.state_path, st)
        return False

    # --------------------------------------------------- 有效性检查 ----
    def current_cookie_valid(self) -> Optional[bool]:
        """用当前配置里的 Cookie 探测 t 是否还有效(仅 --check 用, 不参与自动刷新)。

        返回 True/False;无法判断时返回 None。
        注意: 这是**启发式**探测 —— 过期判定依据的错误码/状态是经验值, 未逐一对过真实
        过期票据, 可能有误报;仅作参考, 真正的续期以 --once/--daemon 的实际登录为准。
        """
        cookie = self._read_config_cookie()
        info = extract_uid_ticket(cookie)
        if not info.get("ticket"):
            return False
        headers = {
            "x-auth-app-id": "1000756",
            "x-auth-uid": str(info["uid"] or ""),
            "x-auth-ticket": str(info["ticket"]),
            "x-auth-token-type": "1010",
            "User-Agent": _CHECK_UA,
        }
        url = "https://mapi.tencentmusic.com/kugou/spell_tamer.SpellTamerApi/MainPage"
        body = {"activityId": 2}
        # 与登录一致优先用 curl_cffi(Chrome 指纹), 避免 TLS 指纹被拦导致误判;退回 requests。
        try:
            try:
                from curl_cffi import requests as creq
                r = creq.post(url, headers=headers, json=body,
                              timeout=self.cfg.per_account_timeout, impersonate="chrome")
            except ImportError:
                import requests
                r = requests.post(url, headers=headers, json=body,
                                  timeout=self.cfg.per_account_timeout)
        except Exception as e:
            log.debug("有效性探测网络异常: %s", e)
            return None
        code = str(r.headers.get("X-Error-Code") or r.headers.get("x-error-code") or "")
        if code in ("20001", "20002", "30001") or r.status_code in (401, 403):
            return False
        return True

    def _read_config_cookie(self) -> str:
        with open(self.cfg.config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        return (cfg.get("auth") or {}).get("cookie", "") or ""

    # ------------------------------------------------------- 常驻 ----
    def run_daemon(self) -> None:
        check_s = max(60, int(self.cfg.check_interval_s))
        log.info("刷新守护启动:每 %.0f 分钟探测一次 Cookie 有效性、失效即刷;"
                 "另每 %.1f 天兜底强制刷新;失败每 %.0f 分钟重试;"
                 "落 %s 可随时手动触发。",
                 check_s / 60, self.cfg.refresh_days, self.cfg.retry_minutes,
                 self.trigger_path)
        while True:
            need, reason = self._should_refresh()
            if need:
                log.info("触发刷新:%s", reason)
                ok = self.refresh_once()
                wait_s = check_s if ok else self.cfg.retry_minutes * 60
            else:
                log.debug("Cookie %s,%.0f 分钟后再探。", reason, check_s / 60)
                wait_s = check_s
            self._sleep_interruptible(max(60, wait_s))

    def _sleep_interruptible(self, seconds: float) -> None:
        """步进休眠(≤2s 粒度):期间出现「尚未处理」的触发即提前返回。
        不在此处消费触发 —— 交由下一轮 _should_refresh 统一消费并记日志,
        保证「谁触发、为何刷」在日志/语义上只有一个入口。判定用 _trigger_pending
        而非裸 exists:降级(文件删不掉)时残留文件不应导致 2s 级空转唤醒。"""
        deadline = time.time() + seconds
        while True:
            remain = deadline - time.time()
            if remain <= 0:
                return
            if self._trigger_pending():
                log.info("检测到手动触发信号,提前结束休眠(剩余 %.0fs)。", remain)
                return
            time.sleep(min(2.0, remain))

    def _trigger_mtime(self):
        """触发文件 mtime(纳秒);不存在/不可读返回 None。"""
        try:
            return os.stat(self.trigger_path).st_mtime_ns
        except OSError:
            return None

    def _trigger_pending(self) -> bool:
        """是否存在「尚未处理」的触发:文件在,且不是降级下已处理过的那一份。"""
        m = self._trigger_mtime()
        return m is not None and m != self._handled_trigger_mtime

    def _consume_trigger(self) -> bool:
        """消费触发文件,返回是否应按「手动触发」刷新。
        · 正常:删除成功 → True(一次性语义由删除保证)
        · 降级(文件在但删不掉):同一份文件(mtime 不变)只处理一次并记录 mtime,
          后续轮次返回 False;web 重写该文件(mtime 变化)视为新触发再处理一次。
          —— 绝不能对残留文件反复返回 True,否则连环重登热循环。"""
        m = self._trigger_mtime()
        if m is None:
            return False
        try:
            os.unlink(self.trigger_path)
            self._handled_trigger_mtime = None
            return True
        except FileNotFoundError:
            return False
        except OSError as e:
            if m == self._handled_trigger_mtime:
                return False                      # 同一份残留,已按触发处理过
            self._handled_trigger_mtime = m
            log.warning("触发文件无法删除(%s):本次按触发处理一次,同一文件不再"
                        "重复触发;请检查 %s 所在目录权限。", e, self.trigger_path)
            return True

    def _should_refresh(self):
        """返回 (是否需要刷新, 原因)。策略:手动触发 > 定期探测有效性 + 时间兜底上限。

        · 存在触发文件(管理台/运维手动落下)→ 消费并刷
        · 无成功记录 → 刷
        · 距上次成功 ≥ refresh_days → 刷(兜底, 防探测启发式误判导致永不续期)
        · 探测到失效(False)→ 刷
        · 探测有效(True)或判不定(None)→ 不刷(等下次探测或兜底)
        """
        if self._consume_trigger():
            return True, "管理台手动触发"
        st = load_state(self.cfg.state_path)
        last_ok = st.get("refreshed_at", 0) if st.get("last_result") == "ok" else 0
        if not last_ok:
            return True, "尚无成功记录"
        age = time.time() - last_ok
        if age >= self.cfg.refresh_days * 86400:
            return True, f"已达兜底刷新周期({self.cfg.refresh_days:.0f}天)"
        valid = self.current_cookie_valid()
        if valid is False:
            return True, "探测到 Cookie 已失效"
        return False, ("有效" if valid else "探测未定(暂不刷,等兜底)")


# ------------------------------------------------------------ 便捷函数 ----
def refresh_once(cfg: Optional[RefreshConfig] = None, only_username: Optional[str] = None) -> bool:
    return RefreshManager(cfg or RefreshConfig()).refresh_once(only_username)


# --------------------------------------------------------------- CLI ----
def _build_cfg(args) -> RefreshConfig:
    return RefreshConfig(
        accounts_path=args.accounts,
        config_path=args.config,
        state_path=args.state,
        refresh_days=args.refresh_days,
        retry_minutes=args.retry_minutes,
        check_interval_s=args.check_interval_minutes * 60,
        method="browser" if args.browser else "http",
        headless=not args.headed,
        proxy=args.proxy,
    )


def main(argv=None):
    ap = argparse.ArgumentParser(description="酷狗多账号 Cookie 自动刷新器")
    ap.add_argument("--accounts", default=DEFAULT_ACCOUNTS, help="账号文件路径")
    ap.add_argument("--config", default=DEFAULT_CONFIG, help="要写回的 spell_tamer_config.json")
    ap.add_argument("--state", default=DEFAULT_STATE, help="状态文件路径")
    ap.add_argument("--refresh-days", type=float, default=25.0, help="正常刷新周期(天)")
    ap.add_argument("--retry-minutes", type=float, default=120.0, help="失败重试间隔(分钟)")
    ap.add_argument("--check-interval-minutes", type=float, default=1.0,
                    help="常驻模式下探测 Cookie 有效性的间隔(分钟), 失效即刷(默认每 1 分钟)")
    ap.add_argument("--browser", action="store_true",
                    help="用浏览器方案登录(默认纯 HTTP;浏览器更抗改版、便于人工过滑块)")
    ap.add_argument("--headed", action="store_true", help="有头模式(配合 --browser, 首次/过滑块)")
    ap.add_argument("--proxy", default=None, help="代理, 如 http://127.0.0.1:7890")
    ap.add_argument("--account", default=None, help="只用指定用户名刷新")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--once", action="store_true", help="立刻刷新一次")
    g.add_argument("--daemon", action="store_true", help="常驻按周期刷新")
    g.add_argument("--check", action="store_true", help="检查当前 Cookie 是否有效")
    ap.add_argument("--log-level", default="INFO")
    args = ap.parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.log_level.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(message)s")

    cfg = _build_cfg(args)
    mgr = RefreshManager(cfg)

    if args.check:
        v = mgr.current_cookie_valid()
        print({True: "✅ 当前 Cookie 有效", False: "❌ 当前 Cookie 已失效, 需要刷新",
               None: "⚠️ 无法判断(缺 requests 或网络问题)"}[v])
        sys.exit(0 if v else 1)

    if args.once:
        ok = mgr.refresh_once(only_username=args.account)
        sys.exit(0 if ok else 1)

    if args.daemon:
        try:
            mgr.run_daemon()
        except KeyboardInterrupt:
            print("\n已停止。")


if __name__ == "__main__":
    main()
