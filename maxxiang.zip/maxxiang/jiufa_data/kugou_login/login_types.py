#!/usr/bin/env python3
"""登录结果 / 异常的公共类型(浏览器登录与 HTTP 登录共用)。"""

from dataclasses import dataclass, field
from typing import Dict, List
import time


class LoginError(Exception):
    """普通登录失败(账号密码错误、被拒、超时等)。"""


class SliderChallenge(LoginError):
    """命中滑块/人机验证(SSA-CODE), 需人工或外部 solver 介入。"""


@dataclass
class LoginResult:
    username: str
    kugoo_id: str
    t: str
    cookie: str
    obtained_at: float = field(default_factory=time.time)
    raw_jar: List[Dict] = field(default_factory=list)

    def summary(self) -> str:
        return f"account={self.username} KugooID={self.kugoo_id} t={self.t[:12]}…"
