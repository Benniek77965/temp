#!/usr/bin/env python3
"""kugou_login 纯逻辑单测(不触网、不登录真实账号)。

覆盖:签名复现、Cookie 组装/解析往返、写回配置、多账号失败转移。
运行:  在 jiufa_data 目录下  python -m kugou_login.tests.test_logic
"""

import collections
import json
import os
import tempfile

from kugou_login import (
    sign_params, extract_uid_ticket,
    compose_minimal_cookie, compose_cookie_from_jar, update_config_cookie,
)
from kugou_login.refresher import RefreshManager, RefreshConfig, Account
import kugou_login.browser_login as bl


def test_signature_matches_har():
    params = {
        "appid": "1010", "clientver": "1000", "clienttime": "1783490620062",
        "mid": "79f1e8221cf75ffa936893eca4ee5398",
        "uuid": "79f1e8221cf75ffa936893eca4ee5398", "dfid": "-", "dev": "web",
        "plat": "4", "clienttime_ms": "1783490620062", "support_third": "0",
        "support_multi": "0", "support_face_verify": "0", "support_verify": "1",
        "from_sdk": "1", "expire_day": "3", "autologin": "false",
        "username": "1476381744",
        "pk": ("1f2b5dce08f677d95eb58ea50c39bb1f3c5b568f6e7fc30e39bae071990e975878aa72fab5"
               "f61aad8157fe3b2b2ff031bcb1425743a64ee89e00f11a70f950d2c92c8407d486c7218a5"
               "e00274d9575ff76b0d40aef52613d76d10ab3aa350d7a0bee3dac292a2d52e8bda132cdb2"
               "cca5032efdbd3d83d08e16d4fb45e678a98a"),
        "params": "20a4cde77c63ee3470736f52260a867b737821143311d7787426c2c989e9399e",
        "srcappid": "2919",
    }
    assert sign_params(params) == "8FB67271BA258C89826998A7A9227BE5"


def test_minimal_cookie_roundtrip():
    ck = compose_minimal_cookie("1476381744", "deadbeefTOKEN")
    info = extract_uid_ticket(ck)
    assert info["uid"] == "1476381744"
    assert info["ticket"] == "deadbeefTOKEN"


def test_compose_from_browser_jar():
    # 模拟 playwright context.cookies() 的返回(含 KuGoo 复合值 + 独立 t)。
    jar = [
        {"name": "KuGoo", "value": "KugooID=999&t=abc123token&a_id=1010", "domain": ".kugou.com"},
        {"name": "KugooID", "value": "999", "domain": ".kugou.com"},
        {"name": "t", "value": "abc123token", "domain": ".kugou.com"},
        {"name": "unrelated", "value": "x", "domain": ".example.com"},  # 应被过滤
    ]
    ck = compose_cookie_from_jar(jar)
    assert "example.com" not in ck  # 非酷狗域被剔除
    info = extract_uid_ticket(ck)
    assert info["uid"] == "999" and info["ticket"] == "abc123token"


def test_update_config_cookie(tmp_config):
    new_cookie = compose_minimal_cookie("2222", "newTicketXYZ")
    info = update_config_cookie(tmp_config, new_cookie)
    assert info["uid"] == "2222" and info["ticket"] == "newTicketXYZ"
    # 复核落盘内容
    with open(tmp_config, encoding="utf-8") as f:
        cfg = json.load(f)
    assert cfg["auth"]["cookie"] == new_cookie
    assert "uid" not in cfg["auth"] and "ticket" not in cfg["auth"]  # 静态值已清除
    assert cfg["auth"]["app_id"] == "1000756"  # 其余字段保留


def test_failover_second_account_succeeds(tmp_env):
    accounts_path, config_path, state_path = tmp_env

    calls = []

    def fake_login(username, password, **kw):
        calls.append(username)
        if username == "acctA":                     # 第一个账号失败
            raise bl.LoginError("bad password")
        # 第二个账号成功, 返回一个带 t 的结果
        return bl.LoginResult(
            username=username, kugoo_id="555", t="ticketFromB",
            cookie=compose_minimal_cookie("555", "ticketFromB"))

    cfg = RefreshConfig(accounts_path=accounts_path, config_path=config_path,
                        state_path=state_path, login_fn=fake_login)
    ok = RefreshManager(cfg).refresh_once()
    assert ok is True
    assert calls == ["acctA", "acctB"]              # 确实按顺序 A→B 试

    # 配置被写成 B 的票据
    info = extract_uid_ticket(json.load(open(config_path, encoding="utf-8"))["auth"]["cookie"])
    assert info["uid"] == "555" and info["ticket"] == "ticketFromB"
    # 状态记录了当前活跃账号
    st = json.load(open(state_path, encoding="utf-8"))
    assert st["active_username"] == "acctB" and st["last_result"] == "ok"


def test_all_accounts_fail_returns_false(tmp_env):
    accounts_path, config_path, state_path = tmp_env

    def always_fail(username, password, **kw):
        raise bl.LoginError("nope")

    cfg = RefreshConfig(accounts_path=accounts_path, config_path=config_path,
                        state_path=state_path, login_fn=always_fail)
    ok = RefreshManager(cfg).refresh_once()
    assert ok is False
    st = json.load(open(state_path, encoding="utf-8"))
    assert st["last_result"] == "fail"


def test_crypto_selftest():
    from kugou_login.kugou_crypto import _selftest, build_pwd_pk_params
    assert _selftest() is True
    pk, params = build_pwd_pk_params("1473527080", "myPassw0rd", 1783490620062)
    assert len(params) == 64 and len(pk) == 256   # 与抓包一致的长度


def test_pwd_envelope_matches_official_js():
    """密码信封与官方 kguser.v2.min.js 用 Node 实跑的输出逐字节一致(固定 seed 对拍)。"""
    from kugou_login.kugou_crypto import aes_encrypt, rsa_encrypt_nopadding
    import json as _json
    seed = "XJJ4FS6E45D7HPDP"
    assert aes_encrypt('{"pwd":"myPassw0rd"}', seed) == \
        "eb27ea234ef3ceff2442f03cb00764a592a68feceb9db5993181622457504a3d"
    assert rsa_encrypt_nopadding(
        _json.dumps({"clienttime_ms": 1783490620062, "key": seed}, separators=(",", ":"))) == (
        "2ebd4ad9856c663045ef18c3da7c74865c62d75c101517b1c21b9b1f2e8eb6777ba33c94b430015793f911"
        "39d9fe0776b9453b9afd85c8a0e3c4a2dba96b05b92aac41db7d05bd3002775f0e2946f8ebdfab820f7f09"
        "ac3a47adb5994f37e2f81aedc2fd2afd971774e87bebc7ab2be004057c9144fd3d35b46f2f0171579239")


def test_mask_username():
    from kugou_login.kugou_crypto import mask_username
    assert mask_username("14763817440") == "14********0"   # 11 位 → 打码
    assert mask_username("1473527080") == "1473527080"     # 10 位酷狗ID → 原样
    # 11 位手机号也落入 [1e10,2e10), 与官方 JS 一致地打码(完整号在 params 的 AES 载荷里)
    assert mask_username("13800138000") == "13********0"


def test_http_login_requires_mid():
    import kugou_login.http_login as h
    try:
        h.login_once("1476381744", "pw", mid="")
        assert False, "缺 mid 应报错"
    except h.LoginError as e:
        assert "mid" in str(e)


def test_http_login_success_mocked(monkeypatch_post):
    import kugou_login.http_login as h
    # 伪造网络层:返回带 KugooID + t 的 cookie jar
    def fake_post(url, cookies, timeout):
        assert "login_by_pwd_get" in url and "signature=" in url  # 确实签了名
        jar = [{"name": "KugooID", "value": "1476381744", "domain": ".kugou.com"},
               {"name": "t", "value": "freshTicket123", "domain": ".kugou.com"}]
        return 200, {}, jar, "{}"
    monkeypatch_post(h, fake_post)
    res = h.login_once("1476381744", "pw", mid="79f1e8221cf75ffa936893eca4ee5398")
    assert res.kugoo_id == "1476381744" and res.t == "freshTicket123"


def test_http_login_slider_mocked(monkeypatch_post):
    import kugou_login.http_login as h
    def fake_post(url, cookies, timeout):
        return 200, {"SSA-CODE": "12345"}, [], ""   # 命中人机验证
    monkeypatch_post(h, fake_post)
    try:
        h.login_once("1476381744", "pw", mid="79f1e8221cf75ffa936893eca4ee5398")
        assert False, "SSA-CODE 应触发 SliderChallenge"
    except h.SliderChallenge:
        pass


def test_should_refresh_logic(tmp_env):
    """守护判定:无状态/失效→刷;有效/判不定→不刷;超兜底周期→刷。"""
    import time as _t
    accounts_path, config_path, state_path = tmp_env
    cfg = RefreshConfig(accounts_path=accounts_path, config_path=config_path,
                        state_path=state_path, login_fn=lambda *a, **k: None,
                        refresh_days=25.0)
    m = RefreshManager(cfg)

    assert m._should_refresh()[0] is True                      # 无成功记录 → 刷
    json.dump({"last_result": "ok", "refreshed_at": _t.time()},
              open(state_path, "w"))
    m.current_cookie_valid = lambda: True
    assert m._should_refresh()[0] is False                     # 有效 → 不刷
    m.current_cookie_valid = lambda: False
    assert m._should_refresh()[0] is True                      # 失效 → 刷
    m.current_cookie_valid = lambda: None
    assert m._should_refresh()[0] is False                     # 判不定 → 不刷(等兜底)
    json.dump({"last_result": "ok", "refreshed_at": _t.time() - 26 * 86400},
              open(state_path, "w"))
    m.current_cookie_valid = lambda: True
    assert m._should_refresh()[0] is True                      # 超 25 天兜底 → 刷


def test_manual_trigger_consumed(tmp_env):
    """触发文件:优先于一切判定,消费(删除)后返回「手动触发」;消费后恢复常规判定。"""
    import time as _t
    accounts_path, config_path, state_path = tmp_env
    cfg = RefreshConfig(accounts_path=accounts_path, config_path=config_path,
                        state_path=state_path, login_fn=lambda *a, **k: None)
    m = RefreshManager(cfg)
    json.dump({"last_result": "ok", "refreshed_at": _t.time()},
              open(state_path, "w"))
    m.current_cookie_valid = lambda: True                      # 常态:有效不刷
    assert m._should_refresh()[0] is False
    open(m.trigger_path, "w").write("now")                     # 管理台落触发
    need, reason = m._should_refresh()
    assert need is True and "手动触发" in reason
    assert not os.path.exists(m.trigger_path)                  # 已消费
    assert m._should_refresh()[0] is False                     # 一次性,不复触


def test_trigger_unlink_denied_no_hot_loop(tmp_env):
    """降级回归:触发文件删不掉时,同一份触发只刷 1 次(绝不连环重登);
    web 重写触发(mtime 变化)则再刷恰好 1 次 —— 降级下功能仍可用。"""
    import threading
    import time as _t
    accounts_path, config_path, state_path = tmp_env
    calls = []

    def fake_login(username, password, **kw):
        calls.append(_t.time())
        return type("R", (), {"cookie": "KugooID=7;t=" + "c" * 64 + ";",
                              "kugoo_id": "7", "summary": lambda self: username})()

    cfg = RefreshConfig(accounts_path=accounts_path, config_path=config_path,
                        state_path=state_path, login_fn=fake_login,
                        check_interval_s=60, retry_minutes=120)
    m = RefreshManager(cfg)
    json.dump({"last_result": "ok", "refreshed_at": _t.time()},
              open(state_path, "w"))
    m.current_cookie_valid = lambda: True         # 空转:只休眠
    real_unlink = os.unlink

    def deny(path, *a, **k):
        if path == m.trigger_path:
            raise PermissionError(13, "denied")
        return real_unlink(path, *a, **k)

    os.unlink = deny
    try:
        threading.Thread(target=m.run_daemon, daemon=True).start()
        _t.sleep(0.5)
        open(m.trigger_path, "w").write("now")
        _t.sleep(5.0)                             # 给足时间暴露潜在热循环
        assert len(calls) == 1, f"降级触发应恰好刷 1 次,实际 {len(calls)} 次"
        _t.sleep(0.2)
        open(m.trigger_path, "w").write("again")  # 新 mtime = 新触发
        _t.sleep(3.0)
        assert len(calls) == 2, f"重写触发应再刷 1 次,实际共 {len(calls)} 次"
    finally:
        os.unlink = real_unlink


def test_daemon_wakes_on_trigger_within_seconds(tmp_env):
    """守护线程在长休眠(模拟失败重试 2h)中,落触发文件应 ≤3s 内唤醒并执行刷新。"""
    import threading
    import time as _t
    accounts_path, config_path, state_path = tmp_env
    calls = []
    fired = threading.Event()

    Result = collections.namedtuple("R", "cookie kugoo_id")

    def fake_login(username, password, **kw):
        calls.append(username)
        fired.set()
        return type("R", (), {"cookie": "KugooID=1;t=" + "a" * 64 + ";",
                              "kugoo_id": "1",
                              "summary": lambda self: username})()

    cfg = RefreshConfig(accounts_path=accounts_path, config_path=config_path,
                        state_path=state_path, login_fn=fake_login,
                        retry_minutes=120, check_interval_s=60)
    m = RefreshManager(cfg)
    json.dump({"last_result": "ok", "refreshed_at": _t.time()},
              open(state_path, "w"))
    m.current_cookie_valid = lambda: True                      # 守护空转:只休眠
    th = threading.Thread(target=m.run_daemon, daemon=True)
    th.start()
    _t.sleep(0.5)                                              # 进入首轮休眠
    t0 = _t.time()
    open(m.trigger_path, "w").write("now")
    assert fired.wait(timeout=3.0), "3s 内未唤醒执行刷新"
    assert _t.time() - t0 <= 3.0 and calls, f"唤醒耗时超限或未调登录: {calls}"
    assert not os.path.exists(m.trigger_path)                  # 触发已消费


# --------------------------------------------------------- 简易测试运行器 ----
def _make_tmp_config():
    fd, path = tempfile.mkstemp(suffix=".json")
    os.close(fd)
    cfg = collections.OrderedDict()
    cfg["activity_id"] = 2
    cfg["auth"] = collections.OrderedDict(
        [("app_id", "1000756"), ("cookie", "KuGoo=KugooID=1&t=old; KugooID=1"),
         ("token_type", "1010")])
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    return path


def _make_tmp_env():
    d = tempfile.mkdtemp()
    accounts_path = os.path.join(d, "accounts.json")
    with open(accounts_path, "w", encoding="utf-8") as f:
        json.dump({"accounts": [
            {"username": "acctA", "password": "pa"},
            {"username": "acctB", "password": "pb"},
        ]}, f)
    config_path = _make_tmp_config()
    state_path = os.path.join(d, "state.json")
    return accounts_path, config_path, state_path


def _monkeypatch_post(module, fake):
    """把 module._post 换成 fake(测试用, 不做还原——每个用例各自设置)。"""
    module._post = fake


def _run():
    passed = failed = 0

    def _do(fn, *args):
        nonlocal passed, failed
        try:
            fn(*args); print(f"  ok  {fn.__name__}"); passed += 1
        except Exception as e:
            print(f" FAIL {fn.__name__}: {e}"); failed += 1

    # 无 fixture 的
    for t in (test_signature_matches_har, test_minimal_cookie_roundtrip,
              test_compose_from_browser_jar, test_crypto_selftest,
              test_pwd_envelope_matches_official_js, test_mask_username,
              test_http_login_requires_mid):
        _do(t)
    # 需要临时 config 的
    _do(test_update_config_cookie, _make_tmp_config())
    # 需要完整临时环境的
    for t in (test_failover_second_account_succeeds, test_all_accounts_fail_returns_false,
              test_should_refresh_logic, test_manual_trigger_consumed,
              test_trigger_unlink_denied_no_hot_loop,
              test_daemon_wakes_on_trigger_within_seconds):
        _do(t, _make_tmp_env())
    # 需要 monkeypatch 网络层的
    _do(test_http_login_success_mocked, _monkeypatch_post)
    _do(test_http_login_slider_mocked, _monkeypatch_post)

    print(f"\n{passed} passed, {failed} failed")
    return failed == 0


if __name__ == "__main__":
    import sys
    sys.exit(0 if _run() else 1)
