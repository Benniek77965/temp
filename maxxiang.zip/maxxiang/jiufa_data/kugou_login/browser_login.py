#!/usr/bin/env python3
"""用无头浏览器完成一次酷狗账号密码登录, 取回新鲜的 Cookie / t。

为什么用浏览器而不是纯 HTTP:
  登录请求里的 pk / params 是酷狗前端用 RSA+AES 加密出来的(密钥藏在混淆 JS 里,
  且会不定期轮换)。直接驱动官方登录页, 让酷狗自己的 JS 生成这些字段, 最稳,
  不会因为对方改密钥就失效。登录成功后直接从浏览器上下文读 Cookie 即可。

依赖(仅本模块需要):
    pip install playwright
    playwright install chromium

注意:
  - 本模块只负责"用你自己的账号密码登录你自己的账号"。请勿用于他人账号。
  - 若命中滑块验证(风控触发时才会出现), 默认行为见 slider_handler 说明。
"""

from typing import Callable, Dict, List, Optional
import time

from .cookie_util import compose_cookie_from_jar, extract_uid_ticket
from .login_types import LoginResult, LoginError, SliderChallenge

LOGIN_PAGE = "https://fanxing.kugou.com/"
LOGIN_API_HINT = "login_by_pwd_get"   # 登录接口 URL 特征, 用于监听结果


def _default_slider_handler(page, headless: bool) -> None:
    """默认滑块处理:有头模式下暂停等你手动拖动;无头模式下直接报错。

    可传入自定义 slider_handler(page, headless) 接入你自己的解法。
    """
    if headless:
        raise SliderChallenge(
            "命中滑块验证且处于无头模式。请改用 --headed 首次手动过一次, "
            "或提供 slider_handler 回调。")
    print("⚠️  出现滑块验证, 请在弹出的浏览器窗口中手动完成, 完成后脚本会自动继续…")
    # 有头模式:给足时间人工拖动, 期间轮询 cookie 是否出现由上层负责。
    time.sleep(20)


def login_once(
    username: str,
    password: str,
    *,
    mid: Optional[str] = None,
    headless: bool = True,
    timeout: float = 90.0,
    user_agent: Optional[str] = None,
    proxy: Optional[str] = None,
    slider_handler: Optional[Callable] = None,
    on_status: Optional[Callable[[str], None]] = None,
    **_ignore,
) -> LoginResult:
    """驱动官方登录页完成一次登录, 成功返回 LoginResult, 失败抛 LoginError。

    参数:
      mid       : 你自己的 mid(等同 kg_mid)。进页面前预置该 Cookie → 视为已知设备, 免短信。
      headless  : 是否无头。首次或调试建议 headless=False 便于过滑块。
      timeout   : 整体超时(秒)。
      user_agent: 覆盖 UA(建议与真实浏览器一致)。
      proxy     : 形如 "http://host:port" 的代理。
      slider_handler(page, headless): 自定义滑块处理回调。
      on_status(str): 状态回调, 便于上层打日志。
    """
    try:
        from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
    except ImportError as e:  # pragma: no cover - 依赖缺失时的友好提示
        raise LoginError(
            "未安装 playwright。请先:\n"
            "    pip install playwright\n"
            "    playwright install chromium") from e

    slider_handler = slider_handler or _default_slider_handler
    status = on_status or (lambda *_: None)
    ua = user_agent or (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36")

    login_api_seen = {"ok": False, "error": None}

    with sync_playwright() as p:
        launch_kw = {"headless": headless}
        if proxy:
            launch_kw["proxy"] = {"server": proxy}
        browser = p.chromium.launch(**launch_kw)
        ctx = browser.new_context(user_agent=ua)
        if mid:  # 预置 kg_mid → 让登录页 JS 以「已知设备」发包, 免短信验证
            ctx.add_cookies([
                {"name": n, "value": mid, "domain": ".kugou.com", "path": "/"}
                for n in ("kg_mid", "kg_mid_temp", "mid")
            ])
        page = ctx.new_page()

        def _on_response(resp):
            if LOGIN_API_HINT in resp.url:
                # 200 且随后能读到 t 即视为成功; 具体成功判定以 cookie 为准。
                login_api_seen["ok"] = resp.status == 200
                try:
                    body = resp.text()
                    if body and ("slide" in body.lower() or "验证" in body):
                        login_api_seen["error"] = "slider"
                except Exception:
                    pass

        page.on("response", _on_response)

        try:
            status("打开登录页…")
            page.goto(LOGIN_PAGE, timeout=timeout * 1000, wait_until="domcontentloaded")

            _open_password_form(page, status)
            _fill_and_submit(page, username, password, status)

            # 轮询等待 t cookie 出现(登录成功的最终判据)。
            deadline = time.time() + timeout
            while time.time() < deadline:
                jar = ctx.cookies()
                info = extract_uid_ticket(compose_cookie_from_jar(jar))
                if info.get("ticket") and info.get("uid"):
                    cookie = compose_cookie_from_jar(jar)
                    status("登录成功, 已取到 t")
                    return LoginResult(username=username, kugoo_id=info["uid"],
                                       t=info["ticket"], cookie=cookie, raw_jar=jar)
                if login_api_seen["error"] == "slider" or _slider_present(page):
                    status("检测到滑块验证")
                    slider_handler(page, headless)
                    login_api_seen["error"] = None  # 处理后重试等待
                time.sleep(1.0)

            raise LoginError("登录超时:未在限定时间内取到 t(可能账号密码错误或被风控)。")
        except PWTimeout as e:
            raise LoginError(f"页面操作超时: {e}") from e
        finally:
            ctx.close()
            browser.close()


# ----------------------------------------------------- 页面操作(带兜底) ----
def _first_visible(page, selectors, timeout_ms=8000):
    """在若干候选选择器里返回第一个可见的元素句柄, 都不行则抛超时。

    酷狗登录面板 UI 版本较多, 这里用多组选择器兜底; 如遇改版, 优先在此处调整。
    """
    from playwright.sync_api import TimeoutError as PWTimeout
    last = None
    for sel in selectors:
        try:
            loc = page.locator(sel).first
            loc.wait_for(state="visible", timeout=timeout_ms // len(selectors) + 500)
            return loc
        except PWTimeout as e:
            last = e
            continue
    raise PWTimeout(f"none of selectors visible: {selectors}") from last


def _open_password_form(page, status):
    """切到"账号登录/密码登录"标签(默认可能是扫码登录)。"""
    status("切换到账号密码登录…")
    candidates = [
        "text=账号登录", "text=密码登录", "text=账号密码登录",
        ".login-type-pwd", "[data-type='pwd']", "a:has-text('账号')",
    ]
    for sel in candidates:
        try:
            page.locator(sel).first.click(timeout=2000)
            return
        except Exception:
            continue
    # 找不到就假设当前已是密码表单, 交给后续填充步骤。


def _fill_and_submit(page, username, password, status):
    status("填写账号密码…")
    user_sel = [
        "input[name='username']",
        "input[placeholder*='酷狗']", "input[placeholder*='手机']",
        "input[placeholder*='邮箱']", "input[type='text']:visible",
    ]
    pwd_sel = [
        "input[name='password']", "input[type='password']:visible",
        "input[placeholder*='密码']",
    ]
    submit_sel = [
        "button:has-text('登录')", "a:has-text('登录')",
        ".login-btn", "input[type='submit']", "[data-action='login']",
    ]
    _first_visible(page, user_sel).fill(username)
    _first_visible(page, pwd_sel).fill(password)
    status("提交登录…")
    for sel in submit_sel:
        try:
            page.locator(sel).first.click(timeout=2500)
            return
        except Exception:
            continue
    # 兜底:密码框回车提交。
    _first_visible(page, pwd_sel).press("Enter")


def _slider_present(page) -> bool:
    """粗略判断页面上是否出现了滑块/验证码。"""
    markers = [
        "iframe[src*='captcha']", "iframe[src*='verify']",
        ".geetest_panel", ".sliderCheck", "text=拖动滑块", "text=完成验证",
    ]
    for sel in markers:
        try:
            if page.locator(sel).first.is_visible(timeout=500):
                return True
        except Exception:
            continue
    return False
