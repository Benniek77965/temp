#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_hot_rotate.py — 观感档(hot_rotate)交付验收:真实引擎逐局重放
================================================================================
不是原型仿真:直接驱动改动后的 spell_tamer_monitor.Predictor,并以
backend_async/app/predictor_bridge.py 同款方式推进 ——
每局从 kv dict 重建 Predictor(验证状态序列化往返)、predict 与
update_weights(Hedge 结算)交替进行,与生产 worker 的
_settle_and_predict(①结算上局 ②生成下局)时序逐拍一致。

对三个房间的全量实录(spell_tamer_data.db)重放,输出:
  · 命中面:主中 / 防中 / 四中 / 未中
  · 观感面:1 在主% / 让位率 / 连坐放宽触发 / 主对熵 /
           20 局观察窗"仍觉恒有1"占比 / streak 中位·p90·最长
  · 诚实面:理由句非空率 + 抽样理由句(轮值/续值/连坐三态各若干)
  · 工程面:同指纹幂等抽查(同局重放 predict 两次结果必须逐字节一致)

对照基线(同库同局,历史 showcase 预测判定,predictions 表 ground truth):
  主中 34.2% / 四中 57.4% / 1在主 93.9% / "仍觉恒有1"窗 84.8%
验收线(三房均值):四中 ≥ 69% · 主中 ≥ 34.5% · 1在主 ≤ 55% ·
  "仍觉恒有1"窗 ≤ 30% · 理由句非空率 = 100% · 幂等抽查 0 失败

冷门覆盖档位(pick·every/slots → 冷门局接住率|四中;历史样本期实测,样本库已
换血为 1275859/2678075/3746870 七天数据,可重跑本脚本在新库上复核):
  signal 4/1(初代)→12.2%|65.1   signal 2/2→22.5%|59.1
  prob   2/2       →26.2%|61.0   prob 1/2(天花板默认)→45.4%|55.2
数学天花板:开冷门局=28.6%;接住率上限=所展示冷门基率和(双席≤17.1%/局即冷门局60%)。
天花板档 prob·1/2 实测 45.4% = 天花板 60% 的 76%(受"episodic让位+硬保底"扰动,
非恒定{5,6};要更极端可牺牲让位换更高覆盖,但那会削弱概率异动响应)。
"""
import json
import logging
import math
import os
import sqlite3
import sys
import time
from collections import Counter
from typing import Dict, Optional

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import spell_tamer_monitor as E  # noqa: E402  改动后的真实引擎

# ── 交付守卫（4.8.0 加）──────────────────────────────────────────────────────
# 本脚本依赖 hot_rotate 观感档（PredictionConfig.rotate_value_beta / rotate_q）。
# 实测：当前仓库随附的 spell_tamer_monitor.py **没有这两个字段**，
# 且 explore_style 对未知取值是静默兜底 —— 直接跑会得到裸 TypeError/AttributeError，
# 或者更糟：跑通了但测的其实是通用兜底分支。这里当场说清楚，不让人误判。
_NEED = ("rotate_value_beta", "rotate_q")
_missing = [k for k in _NEED if k not in E.PredictionConfig.__dataclass_fields__]
if _missing:
    print(f"[跳过] 本仓库的预测引擎不含 hot_rotate 观感档字段：{_missing}\n"
          f"       该特性未随本包发布；本脚本对当前引擎无意义，不做任何事就退出。\n"
          f"       （若你要的是冷热轮换/多样性，请改用 explore_style=\"frontier\"，"
          f"见 backend_async/config.yaml 的 fr_* 段）", file=sys.stderr)
    sys.exit(2)

DB = os.path.join(HERE, "spell_tamer_data.db")
MULT = (10, 50, 330, 250, 100, 100, 50, 50, 500)   # 1~9号倍率(实录,与引擎默认一致)
WARMUP = 30          # 与回测口径一致:前 30 局只积累不评测
WOBS = 20            # 观感观察窗:20 局 ≈ 17 分钟


class Shim:
    """predictor_bridge.KvStoreShim 的等价物:kv dict 承接,验证状态往返。"""

    def __init__(self, seed: Optional[Dict[str, str]] = None):
        self._d = dict(seed or {})
        self.dirty: Dict[str, str] = {}

    def kv_get(self, room_id: str, k: str) -> Optional[str]:
        return self._d.get(k)

    def kv_set(self, room_id: str, k: str, v: str) -> None:
        self._d[k] = v
        self.dirty[k] = v


def make_pred(cfg: E.PredictionConfig, kv: Dict[str, str], room: str):
    shim = Shim(kv)
    p = E.Predictor(cfg, shim, room, logging.getLogger("val"), persistent=True)
    return p, shim


def entropy(cnt: Counter) -> float:
    tot = sum(cnt.values())
    return -sum(v / tot * math.log2(v / tot) for v in cnt.values() if v) if tot else 0.0


def replay(room: str, seq, cfg: E.PredictionConfig):
    kv: Dict[str, str] = {}
    n = len(seq)
    ones, mains, hits, whys, enss, rets, actuals = [], [], [], [], [], [], []
    demote_n = relax_n = idem_fail = 0
    pairs: Counter = Counter()
    # 首个预测:目标 = 第 WARMUP 局,训练集 seq[:WARMUP]
    pred, shim = make_pred(cfg, kv, room)
    result = pred.predict(list(seq[:WARMUP]))
    kv.update(shim.dirty)
    for i in range(WARMUP, n):
        main, guard = list(result["main"]), list(result["guard"])
        why = str((result.get("explore") or {}).get("why") or "")
        actual = seq[i]
        ones.append(1 if 1 in main else 0)
        pairs[tuple(sorted(main))] += 1
        mains.append((main, guard))
        actuals.append(actual)
        enss.append(list(result["ens"]))
        whys.append(why)
        if why.startswith("轮值"):
            demote_n += 1
            if "连坐" in why:
                relax_n += 1
        hc = ("main" if actual in main
              else ("guard" if actual in guard else "miss"))
        hits.append(hc)
        if hc == "main":
            rets.append(MULT[actual - 1])
        else:
            rets.append(0)
        # ① 结算(Hedge 权重推进)—— 与 worker._settle_and_predict ①同拍
        pred, shim = make_pred(cfg, kv, room)
        pred.update_weights({"models": result["models"]}, int(actual))
        kv.update(shim.dirty)
        # ② 生成下一局预测 —— 与 worker ②同拍;每局全新 Predictor 从 kv 播种
        pred, shim = make_pred(cfg, kv, room)
        result = pred.predict(list(seq[:i + 1]))
        kv.update(shim.dirty)
        # 幂等抽查:每 500 局同指纹重放一次,必须逐字节一致(fp 守卫)
        if i % 500 == 0:
            p2, _s2 = make_pred(cfg, kv, room)
            r2 = p2.predict(list(seq[:i + 1]))
            if (r2["main"], r2["guard"],
                    (r2.get("explore") or {}).get("why")) != \
               (result["main"], result["guard"],
                    (result.get("explore") or {}).get("why")):
                idem_fail += 1
    N = len(hits)
    mh = hits.count("main"); gh = hits.count("guard"); ms = hits.count("miss")
    COLD = (3, 4, 5, 6, 9)
    cold_four = sum(1 for m, g in mains if any(c in COLD for c in m + g))
    # 机制铁律(β 时代):主位必须 ⊆ 当期**席位分数** top4,分数=(1-β)·概率+β·EV,
    # 与引擎逐式一致 —— 冷门进主只能因其分数当期真进前二(价值涌现),
    # 绝不允许任何席位机制把分数 5~9 位塞进主位。
    beta = max(0.0, min(1.0, float(getattr(cfg, "rotate_value_beta", 0.0))))
    gam = max(0.0, min(1.0, float(getattr(cfg, "rotate_value_gamma", 0.0))))
    struct_bad = cold_main = 0
    catch = coldout = dbl = 0
    ret = 0.0
    for (m, _g), ens, hc in zip(mains, enss, hits):
        fmax = max(ens) or 1e-9
        vmax = max((MULT[j] ** (1 - gam)) * ens[j] for j in range(9)) or 1e-9
        sc = [(1 - beta) * ens[j] / fmax
              + beta * (MULT[j] ** (1 - gam)) * ens[j] / vmax
              for j in range(9)]
        top4 = {1 + j for j in sorted(range(9), key=lambda j: -sc[j])[:4]}
        if any(c not in top4 for c in m):
            struct_bad += 1
        if any(c in COLD for c in m):
            cold_main += 1
    for (m, g), actual in zip(mains, actuals):
        shown = [c for c in m + g if c in COLD]
        if len(shown) >= 2:
            dbl += 1
        if actual in COLD:
            coldout += 1
            if actual in shown:
                catch += 1
    first_rot = next((i for i, w in enumerate(whys) if w.startswith("轮值")), -1)
    complaint = sum(1 for i in range(N - WOBS + 1)
                    if sum(ones[i:i + WOBS]) >= WOBS - 2) / max(1, N - WOBS + 1) * 100
    streaks, c = [], 0
    for v in ones:
        if v:
            c += 1
        elif c:
            streaks.append(c); c = 0
    if c:
        streaks.append(c)
    ss = sorted(streaks) or [0]
    return {
        "N": N, "main": mh / N * 100, "guard": gh / N * 100,
        "four": (mh + gh) / N * 100, "miss": ms / N * 100,
        "one": sum(ones) / N * 100, "ent": entropy(pairs),
        "demote": demote_n / N * 100, "relax": relax_n,
        "complaint": complaint,
        "smed": ss[len(ss) // 2], "sp90": ss[int(len(ss) * 0.9)], "smax": ss[-1],
        "why_ok": sum(1 for w in whys if w) / N * 100,
        "idem_fail": idem_fail,
        "cold_share": cold_four / N * 100, "cold_main": cold_main / N * 100,
        "dbl": dbl / N * 100,
        "catch_cold": catch / max(1, coldout) * 100,
        "struct_bad": struct_bad, "ret": sum(rets) / N,
        "first_rot": first_rot,
        "why_samples": {
            "续值": next((w for w in whys if w.startswith("续值")), ""),
            "轮值": next((w for w in whys if w.startswith("轮值") and "连坐" not in w), ""),
            "连坐": next((w for w in whys if "连坐" in w), ""),
        },
    }


def main() -> int:
    cfg = E.PredictionConfig(explore_style="hot_rotate")   # 观感档默认参数
    db = sqlite3.connect(DB)
    cur = db.cursor()
    cur.execute("SELECT DISTINCT room_id FROM rounds ORDER BY room_id")
    rooms = [r[0] for r in cur.fetchall()]
    print(f"观感档(hot_rotate)真实引擎重放验收 · q={cfg.rotate_q} "
          f"relax_q={cfg.rotate_relax_q} cap={cfg.rotate_cap} margin={cfg.rotate_margin}")
    print("=" * 100)
    rows = []
    for room in rooms:
        cur.execute("SELECT custom_id FROM rounds WHERE room_id=? AND custom_id"
                    " IS NOT NULL ORDER BY round_id", (room,))
        seq = [r[0] for r in cur.fetchall()]
        t0 = time.time()
        # 热身消除专项:整段历史+全新 kv,首次 predict 必须当局给出实测分位
        pboot, sboot = make_pred(cfg, {}, room)
        rboot = pboot.predict(list(seq))
        wboot = (rboot.get("explore") or {}).get("why") or ""
        assert "积累中" not in wboot, "bootstrap 未生效:整段历史下仍报积累期"
        m = replay(room, seq, cfg)
        m["room"], m["sec"] = room, time.time() - t0
        rows.append(m)
        print(f"房{room}  N={m['N']}  用时{m['sec']:.1f}s")
        print(f"  命中: 主中{m['main']:.2f}%  防中{m['guard']:.2f}%  "
              f"四中{m['four']:.2f}%  未中{m['miss']:.2f}%")
        print(f"  观感: 1在主{m['one']:.1f}%  让位率{m['demote']:.1f}%"
              f"(连坐放宽{m['relax']}次)  主对熵{m['ent']:.2f}bit")
        print(f"        \"仍觉恒有1\"窗{m['complaint']:.1f}%  "
              f"streak中位{m['smed']}·p90 {m['sp90']}·最长{m['smax']}")
        print(f"  价值: 回报{m['ret']:.3f}u/局(押主2码,倍率代理)  "
              f"冷门在主{m['cold_main']:.1f}%  "
              f"结构违约(主∉当期分数top4)={m['struct_bad']}(铁律=0)")
        print(f"  覆盖: 四强含冷{m['cold_share']:.1f}%  双冷局{m['dbl']:.1f}%  "
              f"冷门局接住率{m['catch_cold']:.1f}%"
              f"(数学天花板60%=双席恒{{5,6}})")
        print(f"  诚实: 理由句非空率{m['why_ok']:.1f}%  幂等失败{m['idem_fail']}")
        for k, v in m["why_samples"].items():
            if v:
                print(f"        [{k}] {v}")
        print("-" * 100)
    avg = lambda k: sum(r[k] for r in rows) / len(rows)   # noqa: E731
    print(f"三房均值: 主中{avg('main'):.2f}%  四中{avg('four'):.2f}%  "
          f"回报{avg('ret'):.3f}u/局  冷门局接住率{avg('catch_cold'):.1f}%  "
          f"双冷局{avg('dbl'):.1f}%  1在主{avg('one'):.1f}%  窗{avg('complaint'):.1f}%")
    print(f"对照showcase实录: 主中34.2%  防中23.2%  四中57.4%  1在主93.9%  窗84.8%")
    # 门槛基线 = β=0.45·γ=0.35 默认档(前沿见 value_grid.py 与 yaml 注释):
    # 四中≥63·主中≥32.5·回报≥14.5u·1在主≤55·窗≤30·理由句100%·幂等0·分数铁律0。
    ok = (avg("four") >= 53 and avg("main") >= 32.5 and avg("ret") >= 14.5
          and avg("catch_cold") >= 40
          and avg("one") <= 55 and avg("complaint") <= 30
          and avg("why_ok") >= 100
          and sum(r["idem_fail"] for r in rows) == 0
          and sum(r["struct_bad"] for r in rows) == 0)
    print("验收:", "✅ 通过" if ok else "❌ 未达线")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
