#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
value_grid.py — 价值权重 β 的"命中↔回报"前沿(真实引擎逐局重放)
================================================================================
回报口径(倍率单位代理):每局对主 2 码各押 1u(共 2u),命中得该号倍率 u。
倍率取实录(rounds 表逐号恒定):1×10 2×50 3×330 4×250 5×100 6×100 7×50 8×50 9×500。
注意:若 p×倍率 为真实赔付,则本表为字面期望;实际赔付语义(奖励池/成本结构)需以
一局实拍核对 —— 相对排序在按倍率成比例赔付的任何模型下都稳健,绝对值是代理。
参照:原版 showcase 实录回报 11.83u/局(主中 34.2%);纯价值贪婪主{4,3}=26.5u(9.4%)。
注:各 β 档均在引擎默认 γ(冷门命中偏好,当前 0.35)下重放;改 γ 会整体移动前沿。
"""
import logging
import os
import sqlite3
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import spell_tamer_monitor as E  # noqa: E402

# ── 交付守卫（4.8.0 加）──────────────────────────────────────────────────────
# 本脚本依赖 hot_rotate 观感档（PredictionConfig.rotate_value_beta / rotate_q）。
# 实测：当前仓库随附的 spell_tamer_monitor.py **没有这两个字段**，
# 且 explore_style 对未知取值是静默兜底 —— 直接跑会得到裸 TypeError/AttributeError，
# 或者更糟：跑通了但测的其实是通用兜底分支。这里当场说清楚，不让人误判。
_NEED = ("rotate_value_beta", "rotate_q")
_missing = [k for k in _NEED if k not in E.PredictionConfig.__dataclass_fields__]
if _missing:
    print(f"[跳过] 本仓库的预测引擎不含 hot_rotate 观感档字段：{_missing}\n"
          f"       该特性未随本包发布；本脚本对当前引擎无意义，不做任何事就退出。\n"
          f"       （若你要的是冷热轮换/多样性，请改用 explore_style=\"frontier\"，"
          f"见 backend_async/config.yaml 的 fr_* 段）", file=sys.stderr)
    sys.exit(2)

MULT = {1: 10, 2: 50, 3: 330, 4: 250, 5: 100, 6: 100, 7: 50, 8: 50, 9: 500}
COLD = (3, 4, 5, 6, 9)
WARMUP = 30


class Shim:
    def __init__(self, seed=None):
        self._d = dict(seed or {})
        self.dirty = {}

    def kv_get(self, r, k):
        return self._d.get(k)

    def kv_set(self, r, k, v):
        self._d[k] = v
        self.dirty[k] = v


def replay(room, seq, beta):
    cfg = E.PredictionConfig(explore_style="hot_rotate", rotate_value_beta=beta)
    kv = {}
    sh = Shim(kv)
    pred = E.Predictor(cfg, sh, room, logging.getLogger("g"), True)
    res = pred.predict(list(seq[:WARMUP]))
    kv.update(sh.dirty)
    N = mh = fh = one = cmain = 0
    ret = ret2 = 0.0
    pairs = Counter()
    for i in range(WARMUP, len(seq)):
        m, g = res["main"], res["guard"]
        x = seq[i]
        N += 1
        one += 1 in m
        cmain += any(c in COLD for c in m)
        pairs[tuple(sorted(m))] += 1
        if x in m:
            mh += 1
            ret += MULT[x]
            if x == m[1]:
                ret2 += MULT[x]
        if x in m + g:
            fh += 1
        sh = Shim(kv)
        p2 = E.Predictor(cfg, sh, room, logging.getLogger("g"), True)
        p2.update_weights({"models": res["models"]}, int(x))
        kv.update(sh.dirty)
        sh = Shim(kv)
        pred = E.Predictor(cfg, sh, room, logging.getLogger("g"), True)
        res = pred.predict(list(seq[:i + 1]))
        kv.update(sh.dirty)
    return dict(N=N, main=mh / N * 100, four=fh / N * 100,
                ret=ret / N, ret2=ret2 / N, one=one / N * 100,
                cmain=cmain / N * 100, pairs=pairs)


def main():
    db = sqlite3.connect(os.path.join(HERE, "spell_tamer_data.db"))
    cur = db.cursor()
    cur.execute("SELECT DISTINCT room_id FROM rounds ORDER BY room_id")
    rooms = {}
    for (room,) in cur.fetchall():
        cur.execute("SELECT custom_id FROM rounds WHERE room_id=? AND custom_id"
                    " IS NOT NULL ORDER BY round_id", (room,))
        rooms[room] = [r[0] for r in cur.fetchall()]
    print("β 前沿(三房 %d 局 · 真实引擎逐局重放 · 押主2码/局=2u)"
          % sum(len(s) for s in rooms.values()))
    print("%-6s %7s %7s %9s %9s %8s %10s  %s"
          % ("β", "主中%", "四中%", "回报u/局", "席2回报", "1在主%", "冷门在主%", "主对Top3"))
    for beta in (0.0, 0.35, 0.45, 0.55, 0.62, 0.70, 1.0):
        agg = Counter()
        pairs = Counter()
        tot = 0
        acc = dict(main=0.0, four=0.0, ret=0.0, ret2=0.0, one=0.0, cmain=0.0)
        for room, seq in rooms.items():
            r = replay(room, seq, beta)
            w = r["N"]
            tot += w
            for k in acc:
                acc[k] += r[k] * w
            pairs.update(r["pairs"])
        top = " ".join(f"{a}{b}:{c * 100 // tot}%" for (a, b), c in pairs.most_common(3))
        print("%-6.2f %7.2f %7.2f %9.3f %9.3f %8.1f %10.1f  %s"
              % (beta, acc["main"] / tot, acc["four"] / tot, acc["ret"] / tot,
                 acc["ret2"] / tot, acc["one"] / tot, acc["cmain"] / tot, top))
    print("参照: 原版showcase实录 主中34.2% 回报11.826u | 价值贪婪{4,3} 9.4% 26.541u")


if __name__ == "__main__":
    main()
