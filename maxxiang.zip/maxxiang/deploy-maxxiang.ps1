﻿<#
══════════════════════════════════════════════════════════════════════════════
 deploy-maxxiang.ps1 — 九法观测台（SpellTamer 观测台）Windows 一键 Docker 部署
──────────────────────────────────────────────────────────────────────────────
 针对本项目实际编排（实地核查 backend_async/deploy/{Dockerfile,docker-compose.yml}
 与双 entrypoint / .env.example / app 源码后编写）：

   栈组成 : postgres:16-alpine + redis:7-alpine
            + worker(默认 3 副本,可 --scale) + web(:5173) + login(票据自动续期)
   健康点 : GET /api/version → {"ok":true,...}
   强约束 : compose 声明 env_file: .env —— 该文件不存在整栈无法启动;
            .env 必须 UTF-8 无 BOM + LF 行尾(本脚本保证);
            kgdata 绑定挂载(entrypoint 对 chown 失败静默容错,Windows 可直用)。

 系统要求 : Windows 10 2004+ / Windows 11(x64 或 ARM64),
            Docker Desktop(缺失时本脚本经 winget/官方安装器自动安装,WSL2 后端)。

 用法（在 PowerShell 中）:
   powershell -ExecutionPolicy Bypass -File .\deploy-maxxiang.ps1
       # 交互式安装(或已部署则进入管理菜单);安装类操作会自动请求管理员权限
   powershell -ExecutionPolicy Bypass -File .\deploy-maxxiang.ps1 install -Yes `
       -Port 5173 -Ticket <64位hex> -Uid <数字> -AdminPassword '口令' -Workers 3

 常用子命令：
   status | logs [服务] [-Follow] | seed [房号.. | -File F | -List]
   scale <N> | start | stop | restart | rebuild | accounts | admin-hash | admin-link
   backup | restore <目录> | update | env | firewall | doctor | uninstall | menu

 安装选项（非交互）：
   -Yes                     全部采用默认值
   -Dir <路径>              安装目录（默认 C:\maxxiang）
   -Source <URL|zip|目录>   项目来源（默认官方 zip；脚本已在项目内时自动复用）
   -Port <P>                Web 端口（默认 5173，带占用检测）
   -Ticket <T> -Uid <U>     酷狗 x-auth-ticket / x-auth-uid（票据强制 32-128 位 hex）
   -PgPassword <P>          PostgreSQL 密码（仅限字母数字，默认随机）
   -AdminPassword <P>       启用管理后台并设口令（禁英文单引号）；-AdminOff 明确关闭
   -AdminUser <U>           后台登录账号（与口令成对写入 .env；不给则向导询问；填 off = 不设账号、只验口令）
   -Workers <N>             worker 副本数（默认 3；按需 ≈⌈总房数/4300⌉+1，硬顶 11）
   -Retention <天>          历史保留天数（默认 7；<=0 永久）
   -Keep <N>                backup / update 成功后，完整备份与代码快照各只留最近 N 份（默认 7；0 = 不清理）
   -Discovery on|off        直播间自动发现（默认 on）
   -RegistryMirror <URL>    写入 Docker 镜像加速（可多个，逗号分隔或重复参数）
   -PipMirror <URL>         构建期 PyPI 源（容器内 pip 拉依赖走此源，如清华/阿里镜像）
   -CN                      中国大陆网络预设（引导 Docker 镜像加速与 PyPI 构建源）
   -NoDocker                跳过 Docker Desktop 自动安装（自行保证可用）

 环境变量同名覆盖：MAXX_DIR / MAXX_SOURCE / MAXX_PORT / MAXX_TICKET / MAXX_UID /
   MAXX_PG_PASSWORD / MAXX_ADMIN_PASSWORD / MAXX_ADMIN_USER / MAXX_WORKERS / MAXX_RETENTION / MAXX_PIP_MIRROR

 Windows 差异说明（相对 Linux 版）:
   · Docker Desktop 首次安装后可能提示注销/重启（加入 docker-users 组生效），
     重启后重新运行本脚本即可无缝续跑（幂等）。
   · 日志跟随(-Follow)模式下 Ctrl+C 会连同脚本一起退出（PowerShell 控制台语义），
     重新运行脚本可回到菜单。
   · 备份中的数据库导出经容器内落盘 + docker cp 传输，规避 PowerShell 管道
     对二进制流的编码损坏。
══════════════════════════════════════════════════════════════════════════════
#>
#Requires -Version 5.1
[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSReviewUnusedParameter','',
  Justification='所有参数经各函数以脚本作用域读取（$Yes/$Ticket/...），该规则不追作用域属已知误报')]
[CmdletBinding()]
param(
  [Parameter(Position=0)][string]$Command = '',
  [Parameter(Position=1, ValueFromRemainingArguments=$true)][string[]]$CommandArgs = @(),
  [switch]$Yes,
  [switch]$CN,
  [switch]$NoDocker,
  [string]$Dir            = $(if ($env:MAXX_DIR)            { $env:MAXX_DIR }            else { '' }),
  [string]$Source         = $(if ($env:MAXX_SOURCE)         { $env:MAXX_SOURCE }         else { '' }),
  [string]$Port           = $(if ($env:MAXX_PORT)           { $env:MAXX_PORT }           else { '' }),
  [string]$Ticket         = $(if ($env:MAXX_TICKET)         { $env:MAXX_TICKET }         else { '' }),
  [string]$Uid            = $(if ($env:MAXX_UID)            { $env:MAXX_UID }            else { '' }),
  [string]$PgPassword     = $(if ($env:MAXX_PG_PASSWORD)    { $env:MAXX_PG_PASSWORD }    else { '' }),
  [string]$AdminPassword  = $(if ($env:MAXX_ADMIN_PASSWORD) { $env:MAXX_ADMIN_PASSWORD } else { '' }),
  [switch]$AdminOff,
  [string]$AdminUser      = $(if ($env:MAXX_ADMIN_USER) { $env:MAXX_ADMIN_USER } else { '' }),
  [string]$Workers        = $(if ($env:MAXX_WORKERS)        { $env:MAXX_WORKERS }        else { '' }),
  [string]$Retention      = $(if ($env:MAXX_RETENTION)      { $env:MAXX_RETENTION }      else { '' }),
  [string]$Discovery      = '',
  [string[]]$RegistryMirror = @(),
  [string]$PipMirror       = $(if ($env:MAXX_PIP_MIRROR)   { $env:MAXX_PIP_MIRROR }   else { '' }),
  [string]$Keep           = $(if ($env:MAXX_BACKUP_KEEP)    { $env:MAXX_BACKUP_KEEP }    else { '' }),   # 备份轮转:各保留最近 N 份(默认 7;0 = 不清理)
  [switch]$Follow,          # logs 子命令：持续跟随
  [string]$File = '',       # seed 子命令：批量文件
  [switch]$List,            # seed 子命令：仅打印名录
  [switch]$Help
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ── 全局常量 ──────────────────────────────────────────────────────────────────
$script:ScriptVersion     = '1.1.0'   # 1.1.0:backup / update 后自动轮转旧备份(-Keep / MAXX_BACKUP_KEEP)
$script:SelfPath          = $PSCommandPath
$script:SelfName          = Split-Path -Leaf $script:SelfPath
$script:ProjectName       = 'maxxiang'
$script:DefaultZipUrl     = 'https://fxck-old-1256231079.cos.ap-guangzhou.myqcloud.com/maxxiang.zip'
$script:DefaultInstallDir = 'C:\maxxiang'
$script:WebHealthPath     = '/api/version'
$script:OnWindows         = ([Environment]::OSVersion.Platform -eq 'Win32NT')
$script:TestMode          = ($env:MAXX_PS_TEST -eq '1')

# 指针/日志位置：ProgramData 优先（写探针验证），普通用户不可写时退 LOCALAPPDATA；
# 位置随权限漂移时，部署定位仍有『向上探测/默认目录』兜底（Find-ExistingInstall）。
$script:PointerFile = Join-Path ([IO.Path]::GetTempPath()) 'maxxiang-deploy.conf'
$script:LogFile     = Join-Path ([IO.Path]::GetTempPath()) 'maxxiang-deploy.log'
if ($script:OnWindows) {
  $base = $env:ProgramData
  try { Add-Content -LiteralPath (Join-Path $base 'maxxiang-deploy.log') -Value '' -Encoding UTF8 -ErrorAction Stop }
  catch { $base = $env:LOCALAPPDATA }   # ProgramData 下日志不可写（他人所建等）→ 退用户目录，零探针垃圾
  $script:PointerFile = Join-Path $base 'maxxiang-deploy.conf'
  $script:LogFile     = Join-Path $base 'maxxiang-deploy.log'
}

# ── 运行期变量 ────────────────────────────────────────────────────────────────
$script:InstallDir = ''; $script:DeployDir = ''; $script:EnvFile = ''; $script:StateFile = ''
$script:WorkerReplicas = 3; $script:CfgWebPort = 5173
$script:PypiCnDefault = 'https://pypi.tuna.tsinghua.edu.cn/simple'
$script:TestAnswers = $null           # 测试注入：System.Collections.Queue，非空时交互原语从此取答
$script:LastComposeArgs = $null       # 测试观察点：最近一次 compose 参数
$script:LastDCExit      = 0           # 最近一次 compose 退出码（-AllowFail 时由调用方读取）
$script:LastDCOutput    = ''          # 最近一次 compose 全文输出（构建失败根因甄别用；上屏行为不变）
$script:LastDockerExit  = 0

# ── 输出 / 日志 ───────────────────────────────────────────────────────────────
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { $null = $_ }
function Add-DeployLog([string]$Level, [string]$Msg) {
  try { Add-Content -LiteralPath $script:LogFile -Value ("{0} {1,-5} {2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Msg) -Encoding UTF8 } catch { $null = $_ }
}
function Say ([string]$m) { Write-Host $m; Add-DeployLog 'INFO' $m }
function Step([string]$m) { Write-Host ''; Write-Host "==> $m" -ForegroundColor Cyan; Add-DeployLog 'STEP' $m }
function Ok  ([string]$m) { Write-Host " √ $m" -ForegroundColor Green;  Add-DeployLog 'OK' $m }
function Warn([string]$m) { Write-Host " ! $m" -ForegroundColor Yellow; Add-DeployLog 'WARN' $m }
function Err ([string]$m) { Write-Host " × $m" -ForegroundColor Red;    Add-DeployLog 'ERR' $m }
function Die ([string]$m) { Err $m; Err "详细日志：$($script:LogFile)"; exit 1 }

# ── 交互原语（-Yes 自动取默认；$script:TestAnswers 队列可注入，测试用） ─────────
function Confirm([string]$Question, [string]$Default = 'Y') {
  if ($Yes) { return ($Default -eq 'Y') }
  if ($script:TestAnswers -and $script:TestAnswers.Count -gt 0) {
    $a = [string]$script:TestAnswers.Dequeue(); Write-Host "$Question [$Default](test)=$a"
  } else {
    $hint = if ($Default -eq 'Y') { 'Y/n' } else { 'y/N' }
    $a = Read-Host "$Question [$hint]"
  }
  if ([string]::IsNullOrWhiteSpace($a)) { $a = $Default }
  return ($a -match '^[Yy]')
}
function Ask([string]$Prompt, [string]$Default = '') {
  if ($Yes) { return $Default }
  if ($script:TestAnswers -and $script:TestAnswers.Count -gt 0) {
    $a = [string]$script:TestAnswers.Dequeue(); Write-Host "$Prompt [$Default](test)=$a"
  } else {
    $suffix = if ($Default -ne '') { " [$Default]" } else { '' }
    $a = Read-Host ("$Prompt$suffix")
  }
  if ([string]::IsNullOrWhiteSpace($a)) { return $Default }
  return $a.Trim()
}
function AskSecret([string]$Prompt) {
  while ($true) {
    if ($script:TestAnswers -and $script:TestAnswers.Count -gt 0) {
      $a = [string]$script:TestAnswers.Dequeue()
      $b = [string]$script:TestAnswers.Dequeue()
      Write-Host "$Prompt (test)=***"
    } else {
      $s1 = Read-Host -AsSecureString $Prompt
      $s2 = Read-Host -AsSecureString '再次输入确认'
      $a = [Runtime.InteropServices.Marshal]::PtrToStringUni([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s1))
      $b = [Runtime.InteropServices.Marshal]::PtrToStringUni([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s2))
    }
    if ($a -eq $b -and -not [string]::IsNullOrEmpty($a)) { return $a }
    Warn '两次输入不一致或为空，请重试'
  }
}
function New-RandomPassword([int]$Len = 20) {
  $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  -join (1..$Len | ForEach-Object { $chars[(Get-Random -Maximum $chars.Length)] })
}

# ── 管理员提权（仅安装/更新/卸载/防火墙需要） ───────────────────────────────────
function Test-Admin {
  if (-not $script:OnWindows) { return $true }
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  ([Security.Principal.WindowsPrincipal]$id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Get-RelaunchArgs {
  $a = New-Object System.Collections.Generic.List[string]
  $a.AddRange([string[]]@('-NoProfile','-ExecutionPolicy','Bypass','-File', $script:SelfPath))
  if ($Command) { $a.Add($Command) }
  foreach ($x in @($CommandArgs)) { $a.Add($x) }
  foreach ($kv in @(@('-Dir',$Dir),@('-Source',$Source),@('-Port',$Port),@('-Ticket',$Ticket),
                    @('-Uid',$Uid),@('-PgPassword',$PgPassword),@('-AdminPassword',$AdminPassword),@('-AdminUser',$AdminUser),
                    @('-Workers',$Workers),@('-Retention',$Retention),@('-Discovery',$Discovery),@('-PipMirror',$PipMirror),
                    @('-File',$File))) {
    if ($kv[1]) { $a.Add($kv[0]); $a.Add($kv[1]) }
  }
  foreach ($m in $RegistryMirror) { $a.Add('-RegistryMirror'); $a.Add($m) }
  foreach ($sw in @(@('-Yes',$Yes),@('-CN',$CN),@('-NoDocker',$NoDocker),@('-AdminOff',$AdminOff),
                    @('-Follow',$Follow),@('-List',$List))) {
    if ($sw[1]) { $a.Add($sw[0]) }
  }
  return $a.ToArray()
}
function Ensure-Admin {
  if (Test-Admin) { return }
  Warn '本操作需要管理员权限，正在弹出 UAC 重新执行…'
  $exe = if ($PSVersionTable.PSEdition -eq 'Core') { (Get-Process -Id $PID).Path } else { 'powershell.exe' }
  Start-Process -FilePath $exe -Verb RunAs -ArgumentList (Get-RelaunchArgs)
  exit 0
}

# ── 系统检测 / 资源体检 ────────────────────────────────────────────────────────
function Get-SystemInfo {
  $os   = Get-CimInstance Win32_OperatingSystem
  $arch = $env:PROCESSOR_ARCHITECTURE
  Say ("系统：{0}（build {1}）| 架构：{2}" -f $os.Caption.Trim(), $os.BuildNumber, $arch)
  return @{ Build = [int]$os.BuildNumber; Arch = $arch; MemMB = [int]($os.TotalVisibleMemorySize/1024) }
}
function Test-Resources {
  Step '资源体检'
  $info = Get-SystemInfo
  if ($info.Build -lt 19041) {
    Warn 'Windows 版本低于 10 2004（build 19041）：Docker Desktop/WSL2 官方支持从此起步'
    if (-not (Confirm '仍要继续吗？' 'N')) { Die '已取消' }
  }
  if ($info.MemMB -gt 0 -and $info.MemMB -lt 7800) {
    Warn ("物理内存仅 {0} MB。栈内 PostgreSQL shared_buffers=2GB + WSL2 VM 开销，" -f $info.MemMB)
    Warn '建议 ≥8GB；小内存机器有 OOM/卡顿风险（可把 compose 中该值调回 1GB 并调小 worker 副本）。'
    if (-not (Confirm '仍要继续吗？' 'N')) { Die '已取消' }
  } else { Ok ("内存 {0} MB" -f $info.MemMB) }
  try {
    $drive = (Get-Item ($script:InstallDir + '\')).PSDrive
  } catch { $drive = Get-PSDrive -Name 'C' }
  $freeGB = [math]::Round($drive.Free/1GB, 1)
  if ($drive.Free -lt 8GB) {
    Warn ("磁盘 {0}: 可用 {1} GB（<8GB）：镜像构建 + WSL 虚拟盘可能吃紧" -f $drive.Name, $freeGB)
    if (-not (Confirm '仍要继续吗？' 'Y')) { Die '已取消' }
  } else { Ok ("磁盘 {0}: 可用 {1} GB" -f $drive.Name, $freeGB) }
  return $info
}
function Test-PortInUse([int]$P) {
  if ($script:OnWindows) {
    try {
      if (Get-NetTCPConnection -State Listen -LocalPort $P -ErrorAction Stop) { return $true }
      return $false
    } catch {
      if ($_.FullyQualifiedErrorId -match 'NoMatchingConnections|ObjectNotFound') { return $false }
      # 其他异常（如 cmdlet 不可用）→ 落 TcpListener 兜底
    }
  }
  foreach ($ip in @([Net.IPAddress]::Any, [Net.IPAddress]::Loopback)) {
    $l = [Net.Sockets.TcpListener]::new($ip, $P)
    try { $l.Start(); $l.Stop() } catch { return $true }
  }
  return $false
}

# ── Docker CLI / Compose 包装（$LASTEXITCODE 显式检查是 PS 下的生命线） ─────────
# 注意：以下三个包装刻意使用『普通函数 + $args』——advanced 函数会注入公共参数，
# 使 -d/-v 等短参被前缀绑定到 -Debug/-Verbose 而被吞掉（compose 参数破坏）。
# 关键设计：包装函数【不向输出流返回任何值】——native 命令的 stdout 会与 return 值
# 混流成数组，令 `$rc = Invoke-DC ...; if($rc -ne 0)` 的判断在成功时也为真（数组过滤语义）。
# 输出一律 Out-Host 上屏；退出码经 $script:LastDCExit / LastDockerExit 传递；失败默认 throw。
function Invoke-Docker {
  $rest = @($args)
  & docker @rest 2>&1 | Out-Host
  $script:LastDockerExit = $LASTEXITCODE
  if ($LASTEXITCODE -ne 0) { throw "docker $($rest -join ' ') 失败（退出码 $LASTEXITCODE）" }
}
# ── PG 连接账本护栏(3.4.4;警告不拦截):每副本≈32 连接,默认 max_connections=400 → 硬顶 11。
# 超账本的真机实证后果:pool.acquire 排队 → 出怪入库散布局内 41~70s、预测长 null,而 Redis 积压恒 0。
function Warn-PgLedger([int]$n){
  if ($n -gt 11) {
    Warn ("worker=$n 已超 PG 连接账本硬顶 11（默认 max_connections=400；{0}×32+web 32+预留 3={1}）。" -f $n, ($n*32+35))
    Warn "  后果：任务在 PG 排队执行 → 出怪晚显示/预测长 null（Redis 积压却恒 0）。请降副本或先调大 max_connections。"
  }
}

function Invoke-DC {
  $rest = @($args); $allow = $false
  if ($rest.Count -gt 0 -and $rest[0] -eq '-AllowFail') { $allow = $true; $rest = @($rest | Select-Object -Skip 1) }
  $script:LastComposeArgs = $rest
  Push-Location $script:DeployDir
  $dcOut = $null
  try {
    Add-DeployLog 'RUN' ("(compose) " + ($rest -join ' '))
    # Tee-Object：上屏行为与原先完全一致，同时留存全文供 Invoke-BuildStack 甄别失败根因
    & docker compose @rest 2>&1 | Tee-Object -Variable dcOut | Out-Host
    $code = $LASTEXITCODE
  } finally { Pop-Location }
  $script:LastDCOutput = if ($null -ne $dcOut) { @($dcOut | ForEach-Object { "$_" }) -join "`n" } else { '' }
  $script:LastDCExit = $code
  if ($code -ne 0 -and -not $allow) { throw "docker compose $($rest -join ' ') 失败（退出码 $code）" }
}
function Get-DCOutput {
  $rest = @($args)
  $script:LastComposeArgs = $rest
  Push-Location $script:DeployDir
  try { $out = & docker compose @rest 2>$null; $code = $LASTEXITCODE } finally { Pop-Location }
  if ($code -ne 0) { return $null }
  return $out
}
function Test-DockerDaemon { try { $null = & docker info 2>$null; return ($LASTEXITCODE -eq 0) } catch { return $false } }

# ── WSL2 / Docker Desktop ─────────────────────────────────────────────────────
function Ensure-WSL {
  Step '检查 WSL2（Docker Desktop 的 Linux 后端）'
  $wsl = Get-Command wsl.exe -ErrorAction SilentlyContinue
  $ok = $false
  if ($wsl) {
    try { $null = & wsl.exe --status 2>$null; $ok = ($LASTEXITCODE -eq 0) } catch { $ok = $false }
  }
  if ($ok) { Ok 'WSL 可用'; try { & wsl.exe --update 2>$null | Out-Null } catch { $null = $_ }; return }
  Warn '未检测到可用的 WSL。'
  if (-not (Confirm '现在启用 WSL2（wsl --install --no-distribution，需管理员，可能要求重启）？' 'Y')) {
    Die 'WSL2 是 Docker Desktop 的必需后端，已取消。可手动执行：wsl --install --no-distribution'
  }
  Ensure-Admin
  & wsl.exe --install --no-distribution
  Warn '若系统提示需要重启：请重启后重新运行本脚本继续（脚本幂等，会从当前进度续跑）。'
  Start-Sleep -Seconds 3
}
function Get-DockerDesktopExe {
  foreach ($p in @("$env:ProgramFiles\Docker\Docker\Docker Desktop.exe",
                   "$env:LOCALAPPDATA\Docker\Docker Desktop.exe")) {
    if (Test-Path -LiteralPath $p) { return $p }
  }
  return $null
}
function Wait-DockerEngine([int]$TimeoutSec = 180) {
  Say "等待 Docker 引擎就绪（最长 ${TimeoutSec}s，Docker Desktop 首次启动较慢）…"
  $deadline = (Get-Date).AddSeconds($TimeoutSec)
  while ((Get-Date) -lt $deadline) {
    if (Test-DockerDaemon) { Ok 'Docker 引擎已就绪'; return $true }
    Start-Sleep -Seconds 3
  }
  return $false
}
function Install-DockerDesktop {
  Ensure-Admin
  $winget = Get-Command winget -ErrorAction SilentlyContinue
  if ($winget) {
    Step '通过 winget 安装 Docker Desktop'
    & winget install -e --id Docker.DockerDesktop --accept-package-agreements --accept-source-agreements --silent 2>&1 | Out-Host
    if ($LASTEXITCODE -eq 0) { return $true }
    Warn "winget 安装失败（退出码 $LASTEXITCODE），改用官方安装器兜底"
  }
  Step '下载 Docker Desktop 官方安装器'
  $archPath = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'amd64' }
  $url = "https://desktop.docker.com/win/main/$archPath/Docker%20Desktop%20Installer.exe"
  $tmp = Join-Path ([IO.Path]::GetTempPath()) 'DockerDesktopInstaller.exe'
  Invoke-Download $url $tmp
  Step '静默安装 Docker Desktop（可能耗时数分钟）'
  $p = Start-Process -FilePath $tmp -ArgumentList 'install','--quiet','--accept-license' -Wait -PassThru
  Remove-Item -LiteralPath $tmp -ErrorAction SilentlyContinue
  return ($p.ExitCode -eq 0)
}
function Ensure-Docker {
  Step '检查 Docker Desktop'
  if ($NoDocker) {
    if (-not (Test-DockerDaemon)) { Die '-NoDocker 模式下需自行保证 Docker 已安装并运行' }
    Ok '已按 -NoDocker 跳过安装检查'; return
  }
  $haveCli = [bool](Get-Command docker -ErrorAction SilentlyContinue)
  if (-not $haveCli) {
    Ensure-WSL
    if (-not (Confirm '未检测到 Docker Desktop，现在自动安装？' 'Y')) { Die 'Docker 是必需组件，已取消' }
    if (-not (Install-DockerDesktop)) {
      Die '自动安装失败。请手动安装：https://docs.docker.com/desktop/setup/install/windows-install/'
    }
    Warn 'Docker Desktop 已安装。首次使用通常需要【注销并重新登录】(加入 docker-users 组生效)，'
    Warn '若接下来引擎无法就绪：请注销/重启后重新运行本脚本继续。'
    $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User')
  }
  if (-not (Test-DockerDaemon)) {
    $exe = Get-DockerDesktopExe
    if ($exe) { Say '启动 Docker Desktop…'; Start-Process -FilePath $exe | Out-Null }
    else { Warn '未定位到 Docker Desktop.exe，等待引擎自行就绪…' }
    if (-not (Wait-DockerEngine 180)) {
      Die 'Docker 引擎未能就绪。请手动打开 Docker Desktop 确认其运行（首次可能需注销/重启），随后重跑本脚本。'
    }
  } else { Ok ('Docker：' + ((& docker --version) 2>$null)) }
  $null = & docker compose version 2>$null
  if ($LASTEXITCODE -ne 0) { Die 'docker compose v2 不可用：请在 Docker Desktop 中更新到较新版本后重试' }
  Ok ('Compose：' + (((& docker compose version --short) 2>$null) | Select-Object -First 1))
}

# ── Docker Desktop 镜像加速（%USERPROFILE%\.docker\daemon.json） ───────────────
function Restart-DockerDesktop {
  $exe = Get-DockerDesktopExe
  Say '重启 Docker Desktop 使配置生效…'
  foreach ($n in 'com.docker.backend','Docker Desktop','com.docker.build') {
    Get-Process -Name $n -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
  }
  Start-Sleep -Seconds 2
  if ($exe) { Start-Process -FilePath $exe | Out-Null }
  if (-not (Wait-DockerEngine 180)) { Die '写入镜像加速后 Docker 未能重启就绪，请手动打开 Docker Desktop 检查 Settings→Docker Engine 配置' }
}
function Set-RegistryMirrors {
  $mirrors = @($RegistryMirror | Where-Object { $_ })
  if ($mirrors.Count -eq 0) {
    if ($Yes) { return }
    $def = if ($CN) { 'Y' } else { 'N' }
    if (-not (Confirm '是否配置 registry 镜像加速（拉取基础镜像更快，中国大陆常需要）？' $def)) { return }
    $m = Ask '输入加速地址（形如 https://xxxx.mirror.aliyuncs.com，留空跳过）' ''
    if (-not $m) { return }
    $mirrors = @($m)
  }
  Step '配置 Docker registry 镜像加速'
  $dj = Join-Path $HOME '.docker\daemon.json'
  $obj = $null
  if (Test-Path -LiteralPath $dj) {
    Copy-Item -LiteralPath $dj -Destination ($dj + '.bak.' + (Get-Date -Format 'yyyyMMddHHmmss'))
    try { $obj = Get-Content -LiteralPath $dj -Raw | ConvertFrom-Json } catch { Warn 'daemon.json 解析失败，将重建（原文件已备份）' }
  }
  if (-not $obj) { $obj = [pscustomobject]@{} }
  if ($obj.PSObject.Properties.Name -contains 'registry-mirrors') { $obj.'registry-mirrors' = @($mirrors) }
  else { $obj | Add-Member -NotePropertyName 'registry-mirrors' -NotePropertyValue @($mirrors) }
  New-Item -ItemType Directory -Force -Path (Split-Path $dj) | Out-Null
  Set-Content -LiteralPath $dj -Value (ConvertTo-Json -InputObject $obj -Depth 10) -Encoding UTF8   # -InputObject：规避 PS5.1 管道单元素数组降级
  Ok "已写入 $dj"
  Restart-DockerDesktop
}

# ── 下载 / 解压 / 项目定位 ─────────────────────────────────────────────────────
function Invoke-Download([string]$Url, [string]$OutFile) {
  Say "下载：$Url"
  try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { $null = $_ }
  Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $OutFile
}
function Test-Markers([string]$D) {
  # 防御：路径解析异常（如指向不存在的盘符）一律视为『非项目』，绝不上抛
  try {
    (Test-Path -LiteralPath (Join-Path $D 'backend_async\deploy\docker-compose.yml')) -and
    (Test-Path -LiteralPath (Join-Path $D 'backend_async\deploy\Dockerfile')) -and
    (Test-Path -LiteralPath (Join-Path $D 'jiufa_data\spell_tamer_monitor.py')) -and
    (Test-Path -LiteralPath (Join-Path $D 'index.html'))
  } catch { $false }
}
function Find-ProjectUpward([string]$Start) {
  $d = $Start
  for ($i = 0; $i -lt 5 -and $d; $i++) {
    if (Test-Markers $d) { return $d }
    $parent = Split-Path -Parent $d
    if (-not $parent -or $parent -eq $d) { break }
    $d = $parent
  }
  return $null
}
function Expand-ProjectZip([string]$Zip, [string]$Dst) {
  $tmp = Join-Path ([IO.Path]::GetTempPath()) ('mx-' + [Guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp | Out-Null
  try {
    try { Expand-Archive -LiteralPath $Zip -DestinationPath $tmp -Force }
    catch { throw "解压失败：$Zip（$($_.Exception.Message)）" }
    $root = $tmp
    if (-not (Test-Markers $root)) {
      $only = Get-ChildItem -LiteralPath $tmp -Directory | Select-Object -First 1
      if ($only -and (Test-Markers $only.FullName)) { $root = $only.FullName }
    }
    if (-not (Test-Markers $root)) { throw '压缩包内容不符合本项目结构（缺少 backend_async/deploy 等标志文件）' }
    New-Item -ItemType Directory -Force -Path $Dst | Out-Null
    Copy-Item -Path (Join-Path $root '*') -Destination $Dst -Recurse -Force
  } finally { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
}
function Set-ProjectPaths([string]$Root) {
  $script:InstallDir = $Root.TrimEnd('\')
  $script:DeployDir  = Join-Path $script:InstallDir 'backend_async\deploy'
  $script:EnvFile    = Join-Path $script:DeployDir '.env'
  $script:StateFile  = Join-Path $script:DeployDir '.deploy-state'
}
function Save-Pointer { try { Set-Content -LiteralPath $script:PointerFile -Value ("INSTALL_DIR=" + $script:InstallDir) -Encoding UTF8 } catch { $null = $_ } }
function Load-State {
  if (-not (Test-Path -LiteralPath $script:StateFile)) { return }
  foreach ($ln in Get-Content -LiteralPath $script:StateFile) {
    if ($ln -match '^WORKER_REPLICAS=(\d+)$') { $script:WorkerReplicas = [int]$Matches[1] }
    if ($ln -match '^CFG_WEB_PORT=(\d+)$')    { $script:CfgWebPort    = [int]$Matches[1] }
  }
}
function Save-State {
  $txt = "# 由 $($script:SelfName) 维护，请勿手工编辑`nWORKER_REPLICAS=$($script:WorkerReplicas)`nCFG_WEB_PORT=$($script:CfgWebPort)`n"
  [IO.File]::WriteAllText($script:StateFile, $txt, [Text.UTF8Encoding]::new($false))
}
function Get-Project {
  Step '获取项目代码'
  if ($Source) {
    if (Test-Path -LiteralPath $Source -PathType Container) {
      if (-not (Test-Markers $Source)) { Die "-Source 目录不是本项目根：$Source" }
      $src = (Resolve-Path -LiteralPath $Source).Path
      if ($src -ne $script:InstallDir) {
        New-Item -ItemType Directory -Force -Path $script:InstallDir | Out-Null
        Copy-Item -Path (Join-Path $src '*') -Destination $script:InstallDir -Recurse -Force
      }
    } elseif (Test-Path -LiteralPath $Source -PathType Leaf) {
      Expand-ProjectZip $Source $script:InstallDir
    } else {
      $z = Join-Path ([IO.Path]::GetTempPath()) ('mx-' + [Guid]::NewGuid().ToString('N') + '.zip')
      try { Invoke-Download $Source $z } catch { Die "下载失败：$Source（$($_.Exception.Message)）" }
      Expand-ProjectZip $z $script:InstallDir
      Remove-Item -LiteralPath $z -ErrorAction SilentlyContinue
    }
  } elseif (Test-Markers $script:InstallDir) {
    Ok "检测到 $($script:InstallDir) 已包含项目代码，原地复用"
  } else {
    $near = Find-ProjectUpward (Split-Path -Parent $script:SelfPath)
    if (-not $near) { $near = Find-ProjectUpward (Get-Location).Path }
    if ($near) {
      Say "在 $near 发现项目代码"
      if ((Resolve-Path -LiteralPath $near).Path -eq $script:InstallDir) { Ok '安装目录即项目目录，原地部署' }
      elseif (Confirm "复制到安装目录 $($script:InstallDir) 使用？（选 N 则直接在原位部署）" 'Y') {
        New-Item -ItemType Directory -Force -Path $script:InstallDir | Out-Null
        Copy-Item -Path (Join-Path $near '*') -Destination $script:InstallDir -Recurse -Force
      } else { Set-ProjectPaths $near }
    } else {
      Say "本地未发现项目，将从官方地址下载"
      $z = Join-Path ([IO.Path]::GetTempPath()) ('mx-' + [Guid]::NewGuid().ToString('N') + '.zip')
      try { Invoke-Download $script:DefaultZipUrl $z } catch { Die "下载失败，请检查网络或用 -Source 指定本地 zip/目录" }
      Expand-ProjectZip $z $script:InstallDir
      Remove-Item -LiteralPath $z -ErrorAction SilentlyContinue
    }
  }
  if (-not (Test-Markers $script:InstallDir)) { Die "项目获取后校验失败：$($script:InstallDir)" }
  Set-ProjectPaths $script:InstallDir
  Ok "项目就绪：$($script:InstallDir)"
}
function Find-ExistingInstall {
  param([switch]$Probe)   # Probe：探测模式，返回 $true/$false，绝不 exit 也绝不 throw（Main 空分支专用）
  try {
  $cand = $null
  if ($env:MAXX_DIR -and (Test-Markers $env:MAXX_DIR)) { $cand = $env:MAXX_DIR }
  elseif (Test-Path -LiteralPath $script:PointerFile) {
    foreach ($ln in Get-Content -LiteralPath $script:PointerFile) {
      if ($ln -match '^INSTALL_DIR=(.+)$') { $cand = $Matches[1].Trim() }
    }
  }
  if (-not $cand -or -not (Test-Markers $cand)) {
    $cand = Find-ProjectUpward (Get-Location).Path
    if (-not $cand) { $cand = Find-ProjectUpward (Split-Path -Parent $script:SelfPath) }
    if (-not $cand -and (Test-Markers $script:DefaultInstallDir)) { $cand = $script:DefaultInstallDir }
  }
  if (-not $cand) {
    if ($Probe) { return $false }
    Die "未找到已部署的项目。请先执行：$($script:SelfName) install"
  }
  Set-ProjectPaths $cand
  if (-not (Test-Path -LiteralPath $script:EnvFile)) {
    if ($Probe) { return $false }
    Die "缺少配置文件 $($script:EnvFile)（compose 依赖 env_file 强制存在）。请执行：$($script:SelfName) install"
  }
  Load-State
  if ($Probe) { return $true }
  } catch {
    # 意外异常（如底层 IO/驱动器故障）：Probe 静默判否，非 Probe 原样上抛
    if ($Probe) { return $false }
    throw
  }
}

# ── .env 读写（UTF-8 无 BOM + LF：dotenv/compose 的硬约束） ─────────────────────
function Get-EnvValue([string]$Key) {
  if (-not (Test-Path -LiteralPath $script:EnvFile)) { return $null }
  $val = $null
  foreach ($ln in Get-Content -LiteralPath $script:EnvFile) {
    if ($ln -match ('^' + [regex]::Escape($Key) + '=(.*)$')) { $val = $Matches[1] }
  }
  if ($null -eq $val) { return $null }
  $val = $val.Trim()
  # 5.2.0:与 Docker Compose 的 .env 语法同口径(同 Linux 版 env_get)——引号值取到配对的闭引号为止,
  # 未加引号的值「空白 + #」起为行内注释
  if ($val.Length -ge 1 -and ($val[0] -eq "'" -or $val[0] -eq '"')) {
    $end = $val.IndexOf($val[0], 1)
    if ($end -ge 1) { $val = $val.Substring(1, $end - 1) } else { $val = $val.Substring(1) }
  } else {
    $val = ($val -replace '\s+#.*$', '').Trim()
  }
  if ($val -eq '') { return $null }   # 空值行视同不存在：调用方一律走默认回退（与 Linux 版一致）
  return $val
}
function Write-EnvLF([string]$Path, [string[]]$Lines) {
  $Lines = @($Lines)   # 防御：调用侧标量/单元素解包一律归一为数组
  $txt = ($Lines -join "`n") + "`n"
  [IO.File]::WriteAllText($Path, $txt, [Text.UTF8Encoding]::new($false))
  if ($script:OnWindows) {
    try { & icacls $Path /inheritance:r /grant:r "$($env:USERNAME):(F)" "SYSTEM:(F)" | Out-Null } catch { $null = $_ }
  }
}
function Initialize-KgData([string]$KgDir) {
  $abs = if ([IO.Path]::IsPathRooted($KgDir)) { $KgDir } else { Join-Path $script:DeployDir ($KgDir -replace '^\./','') }
  Step "准备票据数据目录 $abs（容器内 /kgdata；entrypoint 对属主调整失败静默容错，Windows 绑定挂载可直用）"
  New-Item -ItemType Directory -Force -Path $abs | Out-Null
  return $abs
}

# ── 健康等待 ──────────────────────────────────────────────────────────────────
function Get-ContainerState([string]$Cid) {
  $json = & docker inspect --format '{{json .State}}' $Cid 2>$null
  if ($LASTEXITCODE -ne 0 -or -not $json) { return $null }
  return ($json | ConvertFrom-Json)
}
function Wait-Stack {
  Step '等待各服务就绪'
  foreach ($svc in 'postgres','redis') {
    $deadline = (Get-Date).AddSeconds(180)
    while ($true) {
      $cid = (Get-DCOutput ps -q $svc | Select-Object -First 1)
      $st = if ($cid) { Get-ContainerState $cid } else { $null }
      $health = if ($st -and $st.PSObject.Properties.Name -contains 'Health' -and $st.Health) { $st.Health.Status } elseif ($st) { $st.Status } else { 'starting' }
      if ($health -eq 'healthy') { Ok "$svc healthy"; break }
      if ((Get-Date) -gt $deadline) { Invoke-DC -AllowFail logs --tail 30 $svc; Die "$svc 在 180s 内未达 healthy" }
      Start-Sleep -Seconds 2
    }
  }
  $url = "http://127.0.0.1:$($script:CfgWebPort)$($script:WebHealthPath)"
  $deadline = (Get-Date).AddSeconds(120)
  while ($true) {
    try {
      $r = Invoke-WebRequest -UseBasicParsing -Uri $url -TimeoutSec 3
      if ($r.Content -match '"ok"') { Ok "web 就绪：$url"; break }
    } catch { $null = $_ }
    if ((Get-Date) -gt $deadline) { Invoke-DC -AllowFail logs --tail 40 web; Die "web 在 120s 内未就绪（$url）" }
    Start-Sleep -Seconds 2
  }
  Start-Sleep -Seconds 3
  $cid = (Get-DCOutput ps -q worker | Select-Object -First 1)
  $st = if ($cid) { Get-ContainerState $cid } else { $null }
  if ($st -and $st.Running) { Ok "worker 运行中（副本 x$($script:WorkerReplicas)）" }
  else { Invoke-DC -AllowFail logs --tail 40 worker; Die 'worker 未能保持运行，请查看上方日志' }
  Ok 'login 服务将随栈常驻（首启会在 kgdata\ 生成 accounts.json 空库与示例）'
}
function Invoke-Preflight {
  Step '启动前预检'
  if (-not (Test-DockerDaemon)) { Die 'Docker 引擎不可用' }
  Invoke-DC config -q
  Ok 'compose 配置校验通过'
}

# ══════════════════════════════════════════════════════════════════════════════
#  配置向导 → 生成 .env（LF/无 BOM；所有入库值在输入侧完成校验）
# ══════════════════════════════════════════════════════════════════════════════
$script:V = @{ Port=5173; PgUser='star'; PgPw=''; PgDb='spelltamer'; Ticket=''; Uid='';
               AdminMode='off'; AdminPw=''; AdminUser=''; AdminAllow=''; Retention=7; Discovery='on'; PipMirror='';
               KgDir='./kgdata'; LogLevel='INFO' }

function Invoke-Wizard {
  Step '部署配置向导（回车采用默认值）'
  # 端口
  $p = if ($Port) { $Port } else { '5173' }
  while ($true) {
    $v = Ask 'Web 服务对外端口' $p
    if ($v -notmatch '^\d+$' -or [int]$v -lt 1 -or [int]$v -gt 65535) { Warn '端口无效'; $p = '5173'; continue }
    if ((Test-PortInUse ([int]$v)) -and -not (Get-DCOutput ps -q)) {
      Warn "端口 $v 已被占用"
      if (Confirm '换一个端口？' 'Y') { $p = [string]([int]$v + 1); continue }
    }
    $script:V.Port = [int]$v; break
  }
  $script:CfgWebPort = $script:V.Port

  # PostgreSQL 口令（仅限字母数字：该值会被 compose 插进 DSN）
  $script:V.PgPw = if ($PgPassword) { $PgPassword } else { New-RandomPassword 20 }
  if (-not $Yes -and -not $PgPassword) {
    Say "PostgreSQL 仅容器内网可达，已生成随机密码：$($script:V.PgPw)"
    if (-not (Confirm '使用该随机密码？（选 N 手动输入，限字母数字）' 'Y')) {
      while ($true) {
        $script:V.PgPw = Ask '输入 PostgreSQL 密码（仅字母数字，≥6 位）' ''
        if ($script:V.PgPw -match '^[A-Za-z0-9]{6,}$') { break }
        Warn '至少 6 位且仅限字母数字'
      }
    }
  }
  if ($script:V.PgPw -notmatch '^[A-Za-z0-9]+$') { Die 'PostgreSQL 密码只能包含字母数字（将拼入连接串）' }

  # 酷狗票据（强制 32-128 位十六进制；留空走示例占位 + login 续期）
  Say ''
  Say '关于酷狗票据：抓取上游 mapi 需要 x-auth-ticket / x-auth-uid（浏览器登录酷狗/繁星后从请求头复制）。'
  Say '票据约 30 天过期；本栈自带 login 服务可用账号密码自动续期（部署后编辑 kgdata\accounts.json）。'
  $script:V.Ticket = $Ticket; $script:V.Uid = $Uid
  if (-not $script:V.Ticket) {
    while ($true) {
      $script:V.Ticket = Ask 'x-auth-ticket（可留空：先用仓库示例票据占位，靠 login 服务续期）' ''
      if (-not $script:V.Ticket) { break }
      if ($script:V.Ticket -match '^[0-9a-fA-F]{32,128}$') { break }
      Warn '票据应为 32-128 位十六进制串（其他字符会破坏 .env 解析/插值），请重输或留空'
      $script:V.Ticket = ''
    }
  } elseif ($script:V.Ticket -notmatch '^[0-9a-fA-F]{32,128}$') {
    Die '-Ticket / MAXX_TICKET 应为 32-128 位十六进制串（当前值含非法字符，会破坏 .env）'
  }
  if ($script:V.Ticket) {
    while ($true) {
      $script:V.Uid = Ask 'x-auth-uid（纯数字）' $script:V.Uid
      if ($script:V.Uid -match '^\d+$') { break }
      Warn 'uid 应为纯数字'
    }
  } else {
    $exPath = Join-Path $script:InstallDir 'backend_async\deploy\.env.example'   # 5.2.0:样例与 .env 同目录
    if (-not (Test-Path -LiteralPath $exPath)) { $exPath = Join-Path $script:InstallDir 'backend_async\.env.example' }
    $t = ''; $u = ''
    if (Test-Path -LiteralPath $exPath) {
      foreach ($ln in Get-Content -LiteralPath $exPath) {
        if ($ln -match '^STA_AUTH_TICKET=(.*)$') { $t = $Matches[1].Trim().Trim("'`"") }
        if ($ln -match '^STA_AUTH_UID=(.*)$')    { $u = $Matches[1].Trim().Trim("'`"") }
      }
    }
    if ($t -notmatch '^[0-9a-fA-F]{32,128}$') { $t = 'PUT_FRESH_TICKET_HERE' }
    if ($u -notmatch '^\d+$') { $u = '0' }
    $script:V.Ticket = $t; $script:V.Uid = $u
    Warn '未提供票据：先以示例票据占位（大概率已过期，抓取将 401），'
    Warn '请部署后尽快：① 配置 kgdata\accounts.json 让 login 自动续期；或 ② 在管理后台或 .env 更新真票据。'
  }

  # 管理后台（入口路径见 Get-AdminCfg；口令暂以单引号明文写入 .env，部署成功后自动转 PBKDF2 散列；禁英文单引号）
  if ($AdminOff) { $script:V.AdminMode = 'off' }
  elseif ($AdminPassword) {
    if ($AdminPassword -match "'") { Die '-AdminPassword 不能包含英文单引号' }
    $script:V.AdminMode = 'on'; $script:V.AdminPw = $AdminPassword
    Read-AdminUser (Get-AdminUserDefault)
  }
  elseif (Confirm '启用管理后台（全参数热更/票据面板/账号库编辑）？不启用则相关接口一律 503' 'Y') {
    $script:V.AdminMode = 'on'
    if ($Yes) { $script:V.AdminPw = New-RandomPassword 16; Say "已生成后台口令：$($script:V.AdminPw)（请立即记录）" }
    else {
      while ($true) {
        $script:V.AdminPw = AskSecret '设置后台口令'
        if ($script:V.AdminPw -notmatch "'") { break }
        Warn '口令不能包含英文单引号，请重设'
      }
    }
    # 5.3.0:后台改为「账号 + 口令」—— 账号与口令成对写进 .env(重配时默认沿用旧 .env 里的账号)
    Read-AdminUser (Get-AdminUserDefault)
    while ($true) {
      $script:V.AdminAllow = Ask '可选：管理后台来源 IP 白名单（逗号分隔 CIDR，留空不限制，例 10.0.0.0/8,127.0.0.1/32）' ''
      if (-not $script:V.AdminAllow) { break }
      if ($script:V.AdminAllow -match '^[0-9a-fA-F:./,]+$') { break }
      Warn '白名单只允许 IPv4/IPv6 CIDR 与逗号（当前含非法字符，会破坏 .env），请重输或留空'
    }
  }

  # 数据保留 / 自动发现 / worker 副本
  $r = Ask '每房历史保留天数（<=0 永久保留）' $(if ($Retention) { $Retention } else { '7' })
  if ($r -notmatch '^-?\d+$') { $r = '7' }
  $script:V.Retention = [int]$r
  $d = if ($Discovery) { $Discovery.ToLower() } else { 'on' }
  switch ($d) { 'true' {$d='on'} '1' {$d='on'} 'yes' {$d='on'} 'false' {$d='off'} '0' {$d='off'} 'no' {$d='off'} }
  if ($d -notin @('on','off')) { Warn '-Discovery 仅支持 on/off，按 on 处理'; $d = 'on' }
  if ($Discovery -or $Yes) { $script:V.Discovery = $d }
  elseif (Confirm '启用直播间自动发现（每分钟遍历繁星在播列表自动纳管，前端不显示这些房）？' 'Y') { $script:V.Discovery = 'on' }
  else { $script:V.Discovery = 'off' }

  # 构建期 PyPI 源（容器内 pip 拉依赖走此源；大陆网络强烈建议）
  $script:V.PipMirror = $PipMirror
  if ($script:V.PipMirror) {
    if ($script:V.PipMirror -notmatch '^https?://\S+$') { Die '-PipMirror / MAXX_PIP_MIRROR 需为 http(s):// URL' }
  } elseif ($Yes) {
    if ($CN) { $script:V.PipMirror = $script:PypiCnDefault }
  } else {
    $pdef = if ($CN) { 'Y' } else { 'N' }
    if (Confirm '配置构建期 PyPI 镜像源（镜像构建时 pip 从此源拉依赖；大陆网络建议开启，否则易在 pip install 阶段超时失败）？' $pdef) {
      while ($true) {
        $script:V.PipMirror = Ask 'PyPI 源地址（阿里可用 https://mirrors.aliyun.com/pypi/simple/）' $script:PypiCnDefault
        if ($script:V.PipMirror -match '^https?://\S+$') { break }
        Warn '需为 http(s):// 开头的 URL'
      }
    }
  }

  Say ''
  Say 'worker 副本数：默认 3（≈8600 房容量；1 万房真机实测 = 每局 11.2ms CPU × 200 局/s = 2.2 核）；更大按 ≈⌈总监控房数/4300⌉+1 加副本，硬顶 11（README §5.1/§5.3）'
  $w = Ask 'worker 副本数' $(if ($Workers) { $Workers } else { '3' })
  if ($w -notmatch '^\d+$' -or [int]$w -lt 1) { $w = '10' }
  $script:WorkerReplicas = [int]$w
  $script:V.LogLevel = Ask '日志级别（INFO/DEBUG/WARNING）' 'INFO'
}

function Write-EnvFile {
  Step "生成 $($script:EnvFile)"
  if (Test-Path -LiteralPath $script:EnvFile) {
    $bak = $script:EnvFile + '.bak.' + (Get-Date -Format 'yyyyMMddHHmmss')
    Copy-Item -LiteralPath $script:EnvFile -Destination $bak
    Warn "已备份原有 .env → $bak"
  }
  $adminLine = if ($script:V.AdminMode -eq 'on') { "STA_ADMIN_USERNAME=$($script:V.AdminUser)`nSTA_ADMIN_PASSWORD='$($script:V.AdminPw)'" }
               else { '# 未启用管理后台（需要时设置 STA_ADMIN_PASSWORD 或 STA_ADMIN_PASSWORD_HASH 后 up -d）' }
  $allowLine = if ($script:V.AdminAllow) { "STA_ADMIN_IP_ALLOW=$($script:V.AdminAllow)" }
               else { '# STA_ADMIN_IP_ALLOW=10.0.0.0/8,127.0.0.1/32' }
  $disc = if ($script:V.Discovery -eq 'on') { 'true' } else { 'false' }
  $L = @(
    "# ── 由 $($script:SelfName) v$($script:ScriptVersion) 生成于 $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ──"
    '# 本文件同时承担两职：compose 变量插值 + 注入容器环境(env_file)。'
    '# 编码硬约束：UTF-8 无 BOM + LF 行尾（本脚本已保证；请勿用记事本另存为改动编码）。'
    "# 含 `$ 的值一律用单引号包裹（如 PBKDF2 散列）：单引号保证按字面读取。"
    ''
    '# 钉死 compose 项目名（否则默认取目录名 "deploy"，易与他项目冲突）'
    "COMPOSE_PROJECT_NAME=$($script:ProjectName)"
    ''
    '# ── 端口 / 数据目录（compose 插值用） ──'
    "WEB_PORT=$($script:V.Port)"
    "KG_DATA_DIR=$($script:V.KgDir)"
    ''
    '# ── 构建期镜像源（可选；compose 作为 build args 注入镜像构建；大陆网络建议设置） ──'
    $(if ($script:V.PipMirror) { @("PIP_INDEX_URL=$($script:V.PipMirror)") }
      else { @('# PIP_INDEX_URL=https://pypi.tuna.tsinghua.edu.cn/simple',
               '# PIP_INDEX_URL=https://mirrors.aliyun.com/pypi/simple/') })
    '# 构建期 APT 源（加速 gosu/tzdata 安装层；填主机名即可，启用时取消下行注释）'
    '# APT_MIRROR=mirrors.aliyun.com'
    '# 构建期 npm 源（加速前端混淆 fe-build 依赖层；启用时取消下行注释）'
    '# NPM_REGISTRY=https://registry.npmmirror.com'
    ''
    '# ── PostgreSQL（compose 据此拼 DSN 并建库；密码仅限字母数字） ──'
    "POSTGRES_USER=$($script:V.PgUser)"
    "POSTGRES_PASSWORD=$($script:V.PgPw)"
    "POSTGRES_DB=$($script:V.PgDb)"
    ''
    '# ── 酷狗抓取票据（必需；login 服务续期成功后 worker 会热切换到新 Cookie） ──'
    "STA_AUTH_TICKET=$($script:V.Ticket)"
    "STA_AUTH_UID=$($script:V.Uid)"
    'STA_AUTH_REFRESH_S=60'
    ''
    '# ── 抓取端并发 / 连接池（沿用项目推荐值） ──'
    'STA_HTTP_CONN_LIMIT=500'
    'STA_HTTP_CONN_PER_HOST=500'
    'STA_WORKER_CONCURRENCY=800'
    'STA_PG_POOL_MIN=4'
    'STA_PG_POOL_MAX=32'
    ''
    '# ── 数据保留 / 自动发现 / 日志 ──'
    "STA_RETENTION_DAYS=$($script:V.Retention)"
    "STA_DISCOVERY_ENABLED=$disc"
    "STA_LOG_LEVEL=$($script:V.LogLevel)"
    ''
    '# ── 管理后台（不设口令则后台整体 503；账号与口令成对，账号留空=只验口令） ──'
    $adminLine
    '# 入口路径 / 人机验证档位默认取 backend_async/config.yaml 的 admin.path / admin.login_captcha；'
    '# 写在这里可覆盖它（环境变量优先，且 update 升级不会覆盖本文件）：'
    '# STA_ADMIN_PATH=admin-xdd'
    '# STA_ADMIN_LOGIN_CAPTCHA=auto'
    $allowLine
    '# STA_ADMIN_SESSION_TTL_S=2592000'
    '# STA_MONITOR_WRITE_TOKEN='
    ''
    '# ── login 服务（酷狗 Cookie 自动续期）节奏 ──'
    'KG_REFRESH_DAYS=25'
    'KG_RETRY_MINUTES=120'
    'KG_CHECK_MINUTES=1'
  )
  Write-EnvLF $script:EnvFile $L
  Ok '.env 已写入（UTF-8 无 BOM · LF · 权限已收紧）'
}

# ── 部署 / 口令散列加固 ────────────────────────────────────────────────────────
function Set-EnvKV([string]$Key, [string]$Val) {
  # 追加或替换 .env 单键（裸值；保持 LF/无 BOM 硬约束）
  $kept = @()
  if (Test-Path -LiteralPath $script:EnvFile) {
    $kept = @((Get-Content -LiteralPath $script:EnvFile) | Where-Object { $_ -notmatch ('^' + [regex]::Escape($Key) + '=') })
  }
  Write-EnvLF $script:EnvFile ($kept + @("$Key=$Val"))
}
function Invoke-BuildStack {
  # 构建并启动；失败时甄别根因（requirements 钉错版本 vs PyPI 网络不通），
  # 后者可一键写国内源并重试一次。返回 $true/$false
  param([int]$Attempt = 1)
  Warn-PgLedger ([int]$script:WorkerReplicas)
  Invoke-DC -AllowFail up -d --build --scale ("worker=" + $script:WorkerReplicas)
  if ($script:LastDCExit -eq 0) { return $true }
  $out = $script:LastDCOutput
  # 先甄别「requirements 钉错版本」：索引正常应答但该版本不存在时，pip 的
  # "Could not find a version …" 行会回显【非空】候选列表（from versions: 0.3, 0.4, …）；
  # 网络不通时该列表为 none。二者都伴随 "No matching distribution"，不能只看那一句。
  # 钉错版本换 PIP 源无济于事（任何镜像都不会有不存在的版本），直接指路改钉版。
  $badLine = @($out -split "`r?`n") | Where-Object {
      $_ -match 'Could not find a version that satisfies the requirement' -and
      $_ -notmatch 'from versions:\s*none' } | Select-Object -Last 1
  if ($badLine) {
    $badReq = if ($badLine -match 'requirement\s+(\S+)') { $Matches[1] } else { '见上方 pip 输出' }
    Err "构建失败诊断：requirements.txt 钉住了 PyPI 上不存在的版本（$badReq）——索引已正常应答并列出全部可选版本，属钉版错误而非网络问题，换 PIP 镜像源无济于事。"
    Err '  修法：把 backend_async/requirements.txt 中该行改为真实存在的版本（pypi.org 可查）后执行 rebuild。'
    return $false
  }
  if ($Attempt -ge 2) { return $false }
  if ($out -notmatch '(?i)from versions:\s*none|No matching distribution|Read timed out|Temporary failure in name resolution|Could not fetch URL .*pypi') {
    return $false   # 非 PyPI 拉取类失败：compose 报错已上屏，换源引导只会误导
  }
  Warn '构建失败诊断：容器内访问 PyPI 超时/不通（"from versions: none" / 拉取超时，典型于大陆网络）——非软件包版本问题（钉错版本的情形已在上一步单独识别）。'
  $cur = Get-EnvValue 'PIP_INDEX_URL'
  if ($cur) {
    Err "已配置 PIP_INDEX_URL=$cur 仍构建失败：请检查该镜像可用性、DNS 或代理后重试。"
    return $false
  }
  if (Confirm "写入国内 PyPI 镜像（$($script:PypiCnDefault)）到 .env 并自动重试构建？" 'Y') {
    $m = $script:PypiCnDefault
    if (-not $Yes) {
      $in = Ask 'PyPI 源地址（可改阿里 https://mirrors.aliyun.com/pypi/simple/）' $m
      if ($in -match '^https?://\S+$') { $m = $in } else { Warn 'URL 无效，改用清华源' }
    }
    Set-EnvKV 'PIP_INDEX_URL' $m
    Ok "已写入 .env：PIP_INDEX_URL=$m，重试构建…"
    return (Invoke-BuildStack -Attempt 2)
  }
  return $false
}
function Invoke-DeployUp {
  Step '构建镜像并启动整栈（首次构建需拉取基础镜像与 pip 依赖，可能耗时数分钟）'
  if (-not (Invoke-BuildStack)) { Die '构建/启动失败（诊断见上方；可在 .env 配置 PIP_INDEX_URL 后执行 rebuild 重试，或运行 doctor 体检）' }
  Save-State
  Wait-Stack
}
function Get-AdminHash([string]$Pw) {
  $out = Get-DCOutput run --rm --no-deps -T --entrypoint python worker -m app.admin_auth hash $Pw
  $h = ($out | Where-Object { $_ } | Select-Object -Last 1)
  if ($h) { $h = $h.Trim() }
  if ($h -and $h.StartsWith('pbkdf2_sha256$')) { return $h }
  return $null
}
function Protect-AdminPassword {
  # 无论新配还是复用旧 .env：只要存在明文口令行，就转为 PBKDF2 散列（口径=镜像内官方工具）
  if (-not (Test-Path -LiteralPath $script:EnvFile)) { return }
  $lines = Get-Content -LiteralPath $script:EnvFile
  if (-not ($lines | Where-Object { $_ -match '^STA_ADMIN_PASSWORD=' })) { return }
  $pw = $script:V.AdminPw
  if (-not $pw) { $pw = Get-EnvValue 'STA_ADMIN_PASSWORD' }
  if (-not $pw) { return }
  Step '将后台口令升级为 PBKDF2 散列存储'
  $hash = Get-AdminHash $pw
  if ($hash) {
    Set-EnvAdminHash $hash
    Invoke-DC -AllowFail up -d web
    Ok '已写入散列并热重建 web；.env 中不再保留明文口令'
  } else {
    Warn "散列生成失败，暂以明文形式保留在 .env。可稍后执行：$($script:SelfName) admin-hash"
  }
}

# ══════════════════════════════════════════════════════════════════════════════
#  日常管理子命令
# ══════════════════════════════════════════════════════════════════════════════
function Ensure-Runtime {
  if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { Die "未安装 Docker Desktop。请先执行：$($script:SelfName) install" }
  if (-not (Test-DockerDaemon)) {
    $exe = Get-DockerDesktopExe
    if ($exe) { Say '启动 Docker Desktop…'; Start-Process -FilePath $exe | Out-Null }
    if (-not (Wait-DockerEngine 120)) { Die 'Docker 引擎未运行：请打开 Docker Desktop 后重试' }
  }
  $null = & docker compose version 2>$null
  if ($LASTEXITCODE -ne 0) { Die "缺少 Docker Compose v2。请更新 Docker Desktop 或执行：$($script:SelfName) install" }
}
function Resolve-KgDir {
  $k = Get-EnvValue 'KG_DATA_DIR'; if (-not $k) { $k = './kgdata' }
  if ([IO.Path]::IsPathRooted($k)) { return $k }
  return (Join-Path $script:DeployDir ($k -replace '^\./',''))
}
function Show-SampleTicketWarn {
  $t = Get-EnvValue 'STA_AUTH_TICKET'
  $ex = ''
  $p = Join-Path $script:InstallDir 'backend_async\deploy\.env.example'   # 5.2.0:样例与 .env 同目录
  if (-not (Test-Path -LiteralPath $p)) { $p = Join-Path $script:InstallDir 'backend_async\.env.example' }
  if (Test-Path -LiteralPath $p) {
    foreach ($ln in Get-Content -LiteralPath $p) { if ($ln -match '^STA_AUTH_TICKET=(.*)$') { $ex = $Matches[1].Trim() } }
  }
  if ($t -and ($t -eq $ex -or $t -eq 'PUT_FRESH_TICKET_HERE')) {
    Warn '当前 .env 使用的是示例/占位票据，上游抓取会 401 —— 请配置 accounts.json 自动续期或更新真票据'
  }
}
function Cmd-Status {
  Step "服务状态（compose 项目：$($script:ProjectName)）"
  Invoke-DC -AllowFail ps
  foreach ($svc in 'postgres','redis','web','login') {
    $cid = (Get-DCOutput ps -q $svc | Select-Object -First 1)
    $st = if ($cid) { Get-ContainerState $cid } else { $null }
    $h = if ($st -and $st.PSObject.Properties.Name -contains 'Health' -and $st.Health) { $st.Health.Status } elseif ($st) { $st.Status } else { '未创建' }
    Say ("  {0,-8} : {1}" -f $svc, $h)
  }
  $n = @(Get-DCOutput ps -q worker).Count
  Say ("  {0,-8} : {1} 个运行中（期望副本 {2}）" -f 'worker', $n, $script:WorkerReplicas)
  $url = "http://127.0.0.1:$($script:CfgWebPort)$($script:WebHealthPath)"
  try { $r = Invoke-WebRequest -UseBasicParsing -Uri $url -TimeoutSec 3; Say "探针 $url ：$($r.Content)" }
  catch { Warn "web 探针未通过（$url）" }
  Say '数据卷：'
  & docker volume ls --filter "label=com.docker.compose.project=$($script:ProjectName)" --format '  {{.Name}}' 2>$null | Out-Host
  Show-SampleTicketWarn
}
function Cmd-Logs {
  $svcArgs = @($CommandArgs | Where-Object { $_ -and $_ -notin @('-f','--follow') })
  $follow  = $Follow -or ($CommandArgs -contains '-f') -or ($CommandArgs -contains '--follow')
  if ($follow) {
    Say '（跟随模式下 Ctrl+C 会退出脚本；重新运行脚本即可回到菜单）'
    Invoke-DC -AllowFail logs -f --tail 120 @svcArgs
  } else {
    Invoke-DC -AllowFail logs --tail 120 @svcArgs
  }
}
function Cmd-Seed {
  Show-SampleTicketWarn
  $rest = @($CommandArgs)
  if ($List) { $rest = @('--list') + $rest }
  if ($File) {
    $abs = (Resolve-Path -LiteralPath $File -ErrorAction SilentlyContinue)
    if (-not $abs) { Die "文件不存在：$File" }
    $posix = ($abs.Path -replace '\\','/')
    Step '批量注入（经批量准入：去重 → 有界并发归一 → 落库 → 错峰起抓）'
    Invoke-DC run --rm -T -v ("${posix}:/tmp/rooms.seed:ro") seed --file /tmp/rooms.seed @rest
    return
  }
  if ($rest.Count -eq 0) {
    Say '示例：直接输入房号（空格分隔，短号/靓号会自动归一），或输入文件路径（每行一个房号），'
    Say '      直接回车 = 仅打印当前监控名录（--list）'
    $line = Ask '房号 / 文件路径' ''
    if (-not $line) { $rest = @('--list') }
    elseif (Test-Path -LiteralPath $line -PathType Leaf) {
      $posix = ((Resolve-Path -LiteralPath $line).Path -replace '\\','/')
      Invoke-DC run --rm -T -v ("${posix}:/tmp/rooms.seed:ro") seed --file /tmp/rooms.seed
      return
    }
    else { $rest = @($line -split '\s+' | Where-Object { $_ }) }
  }
  Step ("注入房间：" + ($rest -join ' '))
  Invoke-DC run --rm -T seed @rest
}
function Cmd-Scale {
  $n = if ($CommandArgs.Count -gt 0) { $CommandArgs[0] } else { '' }
  if (-not $n) { $n = Ask 'worker 副本数（默认 3(≈8600 房容量)；1 万房实测需 2.2 CPU 核；按需 ≈⌈总房数/4300⌉+1；PG 连接账本硬顶 11）' "$($script:WorkerReplicas)" }
  if ($n -notmatch '^\d+$' -or [int]$n -lt 1) { Die '副本数需为 ≥1 的整数' }
  $script:WorkerReplicas = [int]$n; Save-State
  Step "调整 worker 副本 → $n（共享 Redis 延迟队列，自动负载均衡）"
  Warn-PgLedger $n
  Invoke-DC up -d --no-build --scale ("worker=$n") worker
  Ok ("当前运行副本：" + @(Get-DCOutput ps -q worker).Count)
}
function Cmd-Start   { Step '启动整栈'; Invoke-DC up -d --scale ("worker=" + $script:WorkerReplicas); Wait-Stack }
function Cmd-Stop    { Step '停止整栈（保留容器与数据）'; Invoke-DC stop }
function Cmd-Restart { Step '重启整栈'; Invoke-DC restart; Wait-Stack }
function Cmd-Rebuild { Step '重建镜像并滚动更新'; if (-not (Invoke-BuildStack)) { Die '重建失败（诊断见上；.env 可配 PIP_INDEX_URL 换构建源）' }; Wait-Stack }
function Cmd-Accounts {
  $kg = Resolve-KgDir
  New-Item -ItemType Directory -Force -Path $kg | Out-Null
  $acc = Join-Path $kg 'accounts.json'
  $exSrc = Join-Path $script:InstallDir 'jiufa_data\kugou_login\accounts.example.json'
  $exDst = Join-Path $kg 'accounts.example.json'
  if (-not (Test-Path -LiteralPath $exDst) -and (Test-Path -LiteralPath $exSrc)) { Copy-Item -LiteralPath $exSrc -Destination $exDst }
  if (-not (Test-Path -LiteralPath $acc)) { [IO.File]::WriteAllText($acc, '{"accounts": []}' + "`n", [Text.UTF8Encoding]::new($false)) }
  Say "账号库：$acc（参照同目录 accounts.example.json；字段 username/password/mid，"
  Say "        password 支持写成 'env:变量名' 从环境读取以避免明文）"
  if (Confirm '现在用记事本打开编辑？' 'Y') { Start-Process notepad -ArgumentList $acc -Wait }
  if (Get-DCOutput ps -q login) {
    Step '重启 login 服务使账号立即生效'
    Invoke-DC restart login
    Start-Sleep -Seconds 2
    Invoke-DC -AllowFail logs --tail 25 login
  } else { Say 'login 服务尚未运行，启动整栈后会自动读取该账号库' }
}
# ── 管理后台登录账号（5.3.0）：与口令成对放 .env，问答 / 升级补齐 / 散列原位替换 ──────
function Test-AdminUser([string]$U) { return ($U -cmatch '^[A-Za-z0-9._@+-]{1,64}$') }   # 会进 .env：输入侧就拦住引号 / 空白 / $ / #
function Get-AdminUserDefault {
  if ($AdminUser) { return $AdminUser }
  try { $v = [string](Get-EnvValue 'STA_ADMIN_USERNAME') } catch { $v = '' }
  return $v
}
function Read-AdminUser([string]$Default = '') {   # → $script:V.AdminUser（合法值或空）
  $d = "$Default".Trim()
  if (@('off', 'none') -contains $d.ToLower()) { $d = '' }
  if ($d -and -not (Test-AdminUser $d)) {
    if ($Yes) { Die "后台登录账号 [$d] 含非法字符（只允许字母/数字/. _ @ + -，1–64 位）" }
    Warn "预设账号 [$d] 含非法字符，已忽略"; $d = ''
  }
  while ($true) {
    $v = "$(Ask '后台登录账号（与口令成对；填 off 表示不设账号）' $d)".Trim()
    if (@('off', 'none') -contains $v.ToLower()) { $v = '' }
    if (-not $v -or (Test-AdminUser $v)) { $script:V.AdminUser = $v; return }
    Warn '账号只允许字母/数字/. _ @ + -（1–64 位），请重输；不设账号请填 off'
  }
}
function Add-EnvAdminUser([string]$U) {   # 把 STA_ADMIN_USERNAME=<值> 插到口令行正上方（没有口令行则追加）
  $out = New-Object System.Collections.Generic.List[string]; $done = $false
  foreach ($l in @(Get-Content -LiteralPath $script:EnvFile -Encoding UTF8)) {
    if (-not $done -and $l -match '^\s*STA_ADMIN_PASSWORD(_HASH)?=') { $out.Add("STA_ADMIN_USERNAME=$U"); $done = $true }
    $out.Add($l)
  }
  if (-not $done) { $out.Add("STA_ADMIN_USERNAME=$U") }
  Write-EnvLF $script:EnvFile $out.ToArray()
}
function Set-EnvAdminHash([string]$Hash) {   # 口令行**原位**换成散列行（账号行紧挨在上面，不拆散这一对）
  $out = New-Object System.Collections.Generic.List[string]; $done = $false
  foreach ($l in @(Get-Content -LiteralPath $script:EnvFile -Encoding UTF8)) {
    if ($l -match '^\s*STA_ADMIN_PASSWORD(_HASH)?=') {
      if (-not $done) { $out.Add("STA_ADMIN_PASSWORD_HASH='$Hash'"); $done = $true }
      continue
    }
    $out.Add($l)
  }
  if (-not $done) { $out.Add("STA_ADMIN_PASSWORD_HASH='$Hash'") }
  Write-EnvLF $script:EnvFile $out.ToArray()
}
# 5.3.0 迁移：update 会保留服务器上的旧 .env（那里没有登录账号这个键）—— 不补就会悄悄退回只验口令。
# 只在「后台已启用 且 .env 里根本没有这个键」时处理：键在（哪怕值为空）= 运维已明确决定，不再问。
# 默认值：-AdminUser > 新代码包自带 .env 里的账号（快照式打包会带上）。-Yes 下有默认值就写入，没有就不写。
function Ensure-AdminUsername([string]$PkgEnv = '') {
  if (-not (Test-Path -LiteralPath $script:EnvFile)) { return }
  if (-not ((Get-EnvValue 'STA_ADMIN_PASSWORD') -or (Get-EnvValue 'STA_ADMIN_PASSWORD_HASH'))) { return }
  if (@(Get-Content -LiteralPath $script:EnvFile -Encoding UTF8) -match '^\s*STA_ADMIN_USERNAME=') { return }
  $cand = ''
  if ($PkgEnv -and (Test-Path -LiteralPath $PkgEnv)) {
    $saved = $script:EnvFile; $script:EnvFile = $PkgEnv
    try { $cand = [string](Get-EnvValue 'STA_ADMIN_USERNAME') } catch { $cand = '' } finally { $script:EnvFile = $saved }
  }
  if ($AdminUser) { $cand = $AdminUser }
  Step '后台登录已改为「账号 + 口令」：补齐 .env 的 STA_ADMIN_USERNAME'
  Read-AdminUser $cand
  $u = $script:V.AdminUser
  if (-not $u -and $Yes) {
    Warn '未设置后台登录账号：后台继续只验口令（可用 -AdminUser 指定，或在 .env 填 STA_ADMIN_USERNAME 后重启 web）'
    return
  }
  Add-EnvAdminUser $u
  if ($u) { Ok "已写入后台登录账号：$u（与口令相邻，位于 $($script:EnvFile)）" }
  else { Warn '已记下「不设账号」：后台继续只验口令（之后可在 .env 填 STA_ADMIN_USERNAME 并重启 web）' }
}

# ── 管理后台入口 / 账号（5.3.0）────────────────────────────────────────────────
# 与后端 settings.py 同口径：
#   path     = .env 的 STA_ADMIN_PATH > config.yaml 的 admin.path > 默认（入口是访问拓扑，放文件里）
#   username = 只认 .env 的 STA_ADMIN_USERNAME（账号是凭据，与口令同处 .env，不进 config.yaml）
# 入口只认单段（字母或数字开头，其后可含 - _，且不与静态挂载同名），否则回落默认 —— 与后端一致。
function Get-AdminCfg([string]$Key) {
  if ($Key -eq 'username') {
    $v = ''
    try { $v = [string](Get-EnvValue 'STA_ADMIN_USERNAME') } catch { $v = '' }
    if (-not $v) { $v = '' }
    if (@('off', 'none') -contains $v.ToLower()) { $v = '' }
    return $v
  }
  if ($Key -ne 'path') { return '' }
  $v = ''
  try { $v = [string](Get-EnvValue 'STA_ADMIN_PATH') } catch { $v = '' }
  if (-not $v -and $script:InstallDir) {
    $yml = Join-Path (Join-Path $script:InstallDir 'backend_async') 'config.yaml'
    if (Test-Path -LiteralPath $yml) {
      $inBlk = $false
      foreach ($line in (Get-Content -LiteralPath $yml -Encoding UTF8)) {
        if ($line -match '^admin:\s*(#.*)?$') { $inBlk = $true; continue }
        if ($inBlk -and $line -match '^[^\s#]') { break }
        if ($inBlk -and $line -match '^\s+path:\s*(.*)$') {
          $v = ($Matches[1] -replace '\s+#.*$', '').Trim().Trim('"').Trim("'")
          break
        }
      }
    }
  }
  if (-not $v) { $v = '' }
  $v = $v.Trim('/')
  # 与后端 admin_auth._PATH_RESERVED 同一份清单(后端测试守着两边一致):顶层首段 + /api/ 下既有首段
  $reserved = @('account', 'active-room', 'api', 'assets', 'auth', 'cdn', 'crawler', 'discovery', 'docs', 'events', 'fx', 'game', 'icons', 'jiufa', 'live-rooms', 'mock', 'monitor', 'pow', 'redoc', 'rooms', 'static', 'version', 'vip')
  if ($v -cnotmatch '^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$' -or $reserved -contains $v.ToLower()) { $v = 'admin-xdd' }
  return $v
}

# 应急登录：人机验证每次必过、验证服务不可达即拒绝 —— 这是不依赖第三方的那条进门路。
# 票据在 web 容器内签发（签名密钥取自容器环境），默认 10 分钟有效、只能用一次。
function Cmd-AdminLink {
  $mins = 10; $base = ''
  foreach ($a in @($CommandArgs)) {
    $s = "$a"
    if (-not $s) { continue }
    if ($s -match '^https?://') { $base = $s.TrimEnd('/') }
    elseif ($s -match '^\d+$') { $mins = [int]$s }
    else { Die "admin-link 参数无法识别：[$s]（用法：admin-link [分钟] [访问基址，如 https://你的域名]）" }
  }
  # 优先取带默认网关的网卡（排除 Hyper-V / WSL 的 vEthernet 等虚拟网卡），否则退回第一块非回环地址
  $ip = $null
  try {
    $c = Get-NetIPConfiguration -ErrorAction Stop | Where-Object { $_.IPv4DefaultGateway } | Select-Object -First 1
    if ($c) { $ip = @($c.IPv4Address)[0].IPAddress }
  } catch { $null = $_ }
  if (-not $ip) { $ip = '127.0.0.1' }
  if ($ip -eq '127.0.0.1') { try {
    $cand = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
      Where-Object { $_.IPAddress -notmatch '^(127\.|169\.254\.)' } | Select-Object -First 1
    if ($cand) { $ip = $cand.IPAddress }
  } catch { $null = $_ } }
  if (-not $base) { $base = 'http://{0}:{1}' -f $ip, $script:CfgWebPort }
  Step "在 web 容器内签发一次性应急登录链接（$mins 分钟内有效）"
  $link = $null
  $out = Get-DCOutput exec -T web python -m app.admin_auth link --minutes $mins --base $base
  $link = @($out | ForEach-Object { "$_".Trim() } | Where-Object { $_ -match '^https?://.+#t=' }) | Select-Object -Last 1
  if (-not $link) {
    $out = Get-DCOutput run --rm --no-deps -T --entrypoint python web -m app.admin_auth link --minutes $mins --base $base
    $link = @($out | ForEach-Object { "$_".Trim() } | Where-Object { $_ -match '^https?://.+#t=' }) | Select-Object -Last 1
  }
  if (-not $link) { Die '签发失败：管理后台未启用（.env 未设 STA_ADMIN_PASSWORD / STA_ADMIN_PASSWORD_HASH），或镜像尚未构建（先执行 rebuild）' }
  Ok '应急登录链接（只能使用一次；浏览器打开即进入后台，无需账号口令与人机验证）：'
  Write-Host $link
  Say "若打不开，把主机部分换成你平时访问后台的域名 / 公网 IP（票据不绑定主机），或直接执行：$($script:SelfName) admin-link https://你的域名"
  Say '链接等同一次登录凭据，请勿外传。'
}

function Cmd-AdminHash {
  $pw = if ($CommandArgs.Count -gt 0) { $CommandArgs[0] } else { '' }
  if (-not $pw) { $pw = AskSecret '输入新的后台口令' }
  if ($pw -match "'") { Die '口令不能包含英文单引号（.env 存储限制）' }
  Step '在镜像内生成 PBKDF2 散列（与后端 app.admin_auth 完全同口径）'
  $hash = Get-AdminHash $pw
  if (-not $hash) { Die '散列生成失败（镜像未构建？先执行 rebuild）' }
  Set-EnvAdminHash $hash
  Invoke-DC up -d web
  Ok '后台口令已更新为散列存储并热重建 web'
}
# ── 备份轮转(1.1.0;与 deploy-maxxiang.sh 同一语义)────────────────────────────────
# backup 每次留一份完整导出、update 每次留一份代码快照 —— 此前都只增不减。每次成功后各只留
# 最近 N 份(-Keep / MAXX_BACKUP_KEEP,默认 7;0 = 不清理)。只碰本脚本生成且能确认完整的条目:
# backups\<YYYYmmdd-HHMMSS>\ 且含 meta.txt;backups\pre-update-<YYYYmmdd-HHMMSS>-code.zip(.tgz 一并识别)。
# 缺 meta.txt 的不完整备份不计数也不删除,只点名;保留份数非法时一律不删。
$script:BackupKeepDefault = 7
function Get-BackupKeep { if ($Keep) { [string]$Keep } else { [string]$script:BackupKeepDefault } }
function Invoke-PruneBackups([string]$Dir, [string]$KeepRaw, [string]$Kind) {
  if ($KeepRaw -notmatch '^\d+$') { Warn "备份保留份数无效：'$KeepRaw'（应为非负整数）—— 本次不清理旧备份"; return }
  $k = [int]$KeepRaw
  if ($k -le 0 -or -not (Test-Path -LiteralPath $Dir -PathType Container)) { return }
  if ($Kind -eq 'full') {
    $all = @(Get-ChildItem -LiteralPath $Dir -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^\d{8}-\d{6}$' })
    $partial = @($all | Where-Object { -not (Test-Path -LiteralPath (Join-Path $_.FullName 'meta.txt')) })
    if ($partial.Count -gt 0) { Warn ('发现不完整的备份（缺 meta.txt，未计入保留份数、也不会自动删除，请自行确认）：' + (($partial | ForEach-Object { $_.Name }) -join ' ')) }
    $items = @($all | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'meta.txt') })
  } else {
    $items = @(Get-ChildItem -LiteralPath $Dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^pre-update-\d{8}-\d{6}-code\.(tgz|zip)$' })
  }
  if ($items.Count -le $k) { return }
  foreach ($it in @($items | Sort-Object Name -Descending | Select-Object -Skip $k)) {
    try { Remove-Item -LiteralPath $it.FullName -Recurse -Force -ErrorAction Stop; Say "  轮转：已删除旧备份 $($it.Name)（只留最近 $k 份）" }
    catch { Warn "删除旧备份失败：$($it.Name)" }
  }
}

function Cmd-Backup {
  $ts = Get-Date -Format 'yyyyMMdd-HHmmss'
  $bk = Join-Path $script:InstallDir ("backups\" + $ts)
  New-Item -ItemType Directory -Force -Path $bk | Out-Null
  $pgUser = Get-EnvValue 'POSTGRES_USER'; if (-not $pgUser) { $pgUser = 'star' }
  $pgDb   = Get-EnvValue 'POSTGRES_DB';   if (-not $pgDb)   { $pgDb = 'spelltamer' }
  $kg = Resolve-KgDir
  Step "备份 → $bk"
  $cid = (Get-DCOutput ps -q postgres | Select-Object -First 1)
  $st = if ($cid) { Get-ContainerState $cid } else { $null }
  if (-not ($st -and $st.Running)) { Die "postgres 未运行，无法导出数据库（先执行：$($script:SelfName) start）" }
  Say '① PostgreSQL（pg_dump 自定义格式；经容器内落盘 + docker cp 传输，规避 PS 二进制管道损坏）'
  Invoke-DC exec -T postgres sh -c ("pg_dump -Fc -U $pgUser -d $pgDb -f /tmp/db.dump")
  Invoke-Docker cp ("${cid}:/tmp/db.dump") (Join-Path $bk 'db.dump')
  Invoke-DC -AllowFail exec -T postgres rm -f /tmp/db.dump
  Say '② 票据数据目录 kgdata（cookie/账号库/刷新状态）'
  if (Test-Path -LiteralPath $kg) {
    try { Compress-Archive -Path (Join-Path $kg '*') -DestinationPath (Join-Path $bk 'kgdata.zip') -Force }
    catch { Warn 'kgdata 打包告警（目录可能为空）' }
  }
  Say '③ web 账号库卷 acctdata（/data/accounts.json）'
  $bkPosix = ($bk -replace '\\','/')
  Invoke-DC -AllowFail run --rm -T --no-deps -v ("${bkPosix}:/backup") --entrypoint tar web czf /backup/acctdata.tgz -C /data .
  Say '④ 配置文件'
  Copy-Item -LiteralPath $script:EnvFile -Destination (Join-Path $bk 'env.backup')
  if (Test-Path -LiteralPath $script:StateFile) { Copy-Item -LiteralPath $script:StateFile -Destination (Join-Path $bk 'deploy-state') }
  Set-Content -LiteralPath (Join-Path $bk 'meta.txt') -Value @("time=$ts","script=$($script:ScriptVersion)","compose=" + (((& docker compose version --short) 2>$null) | Select-Object -First 1)) -Encoding UTF8
  Ok "备份完成：$bk"
  $bkRoot = Join-Path $script:InstallDir 'backups'
  Invoke-PruneBackups $bkRoot (Get-BackupKeep) 'full'
  $sz = (Get-ChildItem -LiteralPath $bkRoot -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
  Say ("备份目录当前占用：{0:N1} MB（-Keep N 调整保留份数）" -f ([double]$sz / 1MB))
  Say "恢复：$($script:SelfName) restore `"$bk`""
}
function Cmd-Restore {
  $bk = if ($CommandArgs.Count -gt 0) { $CommandArgs[0] } else { '' }
  if (-not $bk) {
    Say '可用备份：'
    Get-ChildItem -LiteralPath (Join-Path $script:InstallDir 'backups') -Directory -ErrorAction SilentlyContinue |
      Sort-Object Name -Descending | ForEach-Object { Say ("  " + $_.FullName) }
    $bk = Ask '输入要恢复的备份目录' ''
  }
  $bk = $bk.TrimEnd('\')
  if (-not (Test-Path -LiteralPath (Join-Path $bk 'db.dump'))) { Die "备份目录无效（缺少 db.dump）：$bk" }
  Warn '恢复将【覆盖】数据库全部内容，并替换 kgdata / 账号库（如备份中存在）'
  if (-not (Confirm '确认继续恢复？' 'N')) { Warn '已取消'; return }
  $pgUser = Get-EnvValue 'POSTGRES_USER'; if (-not $pgUser) { $pgUser = 'star' }
  $pgDb   = Get-EnvValue 'POSTGRES_DB';   if (-not $pgDb)   { $pgDb = 'spelltamer' }
  $kg = Resolve-KgDir
  Step '① 启动 postgres 并停止写入方（worker/web/login）'
  Invoke-DC up -d postgres
  $deadline = (Get-Date).AddSeconds(120)
  while ($true) {
    $cid = (Get-DCOutput ps -q postgres | Select-Object -First 1)
    $st = if ($cid) { Get-ContainerState $cid } else { $null }
    if ($st -and $st.PSObject.Properties.Name -contains 'Health' -and $st.Health -and $st.Health.Status -eq 'healthy') { break }
    if ((Get-Date) -gt $deadline) { Die 'postgres 未就绪' }
    Start-Sleep -Seconds 2
  }
  Invoke-DC -AllowFail stop worker web login
  Step '② 恢复数据库（pg_restore --clean --if-exists）'
  Invoke-Docker cp (Join-Path $bk 'db.dump') ("${cid}:/tmp/db.dump")
  Invoke-DC -AllowFail exec -T postgres pg_restore -U $pgUser -d $pgDb --clean --if-exists /tmp/db.dump
  if ($script:LastDCExit -ne 0) { Warn "pg_restore 报告了非致命告警（向空库恢复时的 DROP 提示可忽略）" }
  Invoke-DC -AllowFail exec -T postgres rm -f /tmp/db.dump
  if (Test-Path -LiteralPath (Join-Path $bk 'kgdata.zip')) {
    Step "③ 恢复 kgdata → $kg"
    if (Test-Path -LiteralPath $kg) { Rename-Item -LiteralPath $kg -NewName ((Split-Path -Leaf $kg) + '.old.' + (Get-Date -Format 'yyyyMMddHHmmss')) }
    New-Item -ItemType Directory -Force -Path $kg | Out-Null
    Expand-Archive -LiteralPath (Join-Path $bk 'kgdata.zip') -DestinationPath $kg -Force
  }
  if (Test-Path -LiteralPath (Join-Path $bk 'acctdata.tgz')) {
    Step '④ 恢复 web 账号库卷'
    $bkPosix = ($bk -replace '\\','/')
    Invoke-DC -AllowFail run --rm -T --no-deps -v ("${bkPosix}:/backup:ro") --entrypoint sh web -c 'rm -rf /data/* 2>/dev/null; tar xzf /backup/acctdata.tgz -C /data && chown -R app:app /data'
    if ($script:LastDCExit -ne 0) { Warn 'acctdata 卷恢复失败' }
  }
  if ((Test-Path -LiteralPath (Join-Path $bk 'env.backup')) -and (Confirm '同时恢复当时的 .env 配置？' 'N')) {
    Copy-Item -LiteralPath $script:EnvFile -Destination ($script:EnvFile + '.pre-restore.' + (Get-Date -Format 'yyyyMMddHHmmss')) -ErrorAction SilentlyContinue
    Copy-Item -LiteralPath (Join-Path $bk 'env.backup') -Destination $script:EnvFile -Force
    $p = Get-EnvValue 'WEB_PORT'; if ($p) { $script:CfgWebPort = [int]$p }
  }
  Step '⑤ 重新拉起整栈'
  Invoke-DC up -d --scale ("worker=" + $script:WorkerReplicas)
  Wait-Stack
  Ok '恢复完成'
}
function Cmd-Update {
  Ensure-Admin
  $src = if ($Source) { $Source } else { $script:DefaultZipUrl }
  Warn "更新会用新代码覆盖 $($script:InstallDir)（保留 .env / kgdata / 备份 / 部署状态），随后重建镜像"
  if (-not (Confirm "从 '$src' 更新？" 'Y')) { Warn '已取消'; return }
  $ts = Get-Date -Format 'yyyyMMdd-HHmmss'
  New-Item -ItemType Directory -Force -Path (Join-Path $script:InstallDir 'backups') | Out-Null
  Step '① 快照当前代码 → backups\pre-update-*.zip'
  try {
    $snap = Join-Path $script:InstallDir ("backups\pre-update-$ts-code.zip")
    $kgTop = Split-Path -Leaf ((Get-EnvValue 'KG_DATA_DIR') -replace '^\./','' -replace '^$','kgdata')
    Get-ChildItem -LiteralPath $script:InstallDir -Exclude 'backups' |
      Where-Object { $_.Name -ne $kgTop -and $_.Name -notmatch '^\.env' -and $_.Name -ne '.deploy-state' } |
      Compress-Archive -DestinationPath $snap -Force
  } catch { Warn "代码快照失败（继续更新）：$($_.Exception.Message)" }
  Step '② 获取新代码'
  $tmp = Join-Path ([IO.Path]::GetTempPath()) ('mxupd-' + [Guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp | Out-Null
  $root = $null
  try {
    if (Test-Path -LiteralPath $src -PathType Container) {
      if (-not (Test-Markers $src)) { Die '-Source 目录无效' }
      $root = $src
    } else {
      $z = Join-Path $tmp 'src.zip'
      if (Test-Path -LiteralPath $src -PathType Leaf) { Copy-Item -LiteralPath $src -Destination $z }
      else { Invoke-Download $src $z }
      Expand-ProjectZip $z (Join-Path $tmp 'extract')
      $root = Join-Path $tmp 'extract'
    }
    Step '③ 同步到安装目录（robocopy /MIR，保留本地配置与数据）'
    $kgRel = Get-EnvValue 'KG_DATA_DIR'; if (-not $kgRel) { $kgRel = './kgdata' }
    $kgName = Split-Path -Leaf ($kgRel -replace '^\./','')
    & robocopy $root $script:InstallDir /MIR /NFL /NDL /NJH /NJS `
        /XD backups $kgName __pycache__ .pytest_cache `
        /XF .env '.env.bak.*' '.env.pre-restore.*' .deploy-state $script:SelfName
    $rc = $LASTEXITCODE
    if ($rc -ge 8) { Die "robocopy 同步失败（退出码 $rc；0-7 为成功语义）。可用 backups\pre-update-$ts-code.zip 回滚" }
    # 5.3.0 迁移:上面保留了服务器的旧 .env —— 那里还没有登录账号这个键,不补就会悄悄退回只验口令
    Ensure-AdminUsername (Join-Path (Join-Path (Join-Path $root 'backend_async') 'deploy') '.env')
    $newSelf = Join-Path $root $script:SelfName
    if (Test-Path -LiteralPath $newSelf) {
      Copy-Item -LiteralPath $newSelf -Destination (Join-Path $script:InstallDir ($script:SelfName + '.new')) -Force
      Warn "新版部署脚本已存为 $($script:SelfName).new（本次运行结束后可自行替换）"
    }
  } finally { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
  if (-not (Test-Markers $script:InstallDir)) { Die "更新后项目结构校验失败，请用 backups\pre-update-$ts-code.zip 回滚" }
  Step '④ 重建并滚动更新'
  if (-not (Invoke-BuildStack)) { Die '更新后重建失败（诊断见上；.env 可配 PIP_INDEX_URL 换构建源）' }
  Wait-Stack
  Ok '更新完成'
  Invoke-PruneBackups (Join-Path $script:InstallDir 'backups') (Get-BackupKeep) 'code'
}
function Cmd-Env {
  Copy-Item -LiteralPath $script:EnvFile -Destination ($script:EnvFile + '.bak.' + (Get-Date -Format 'yyyyMMddHHmmss'))
  Start-Process notepad -ArgumentList $script:EnvFile -Wait
  # 记事本可能引入 BOM/CRLF：读回并按硬约束重写
  $raw = Get-Content -LiteralPath $script:EnvFile
  Write-EnvLF $script:EnvFile $raw
  Invoke-DC config -q
  $p = Get-EnvValue 'WEB_PORT'; if ($p) { $script:CfgWebPort = [int]$p }; Save-State
  if (Confirm '应用配置（up -d，仅重建受影响的容器）？' 'Y') {
    Invoke-DC up -d --scale ("worker=" + $script:WorkerReplicas)
    Wait-Stack
  }
}
function Cmd-Firewall {
  Ensure-Admin
  $name = "maxxiang-web-$($script:CfgWebPort)"
  if (Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue) { Ok "防火墙规则已存在：$name"; return }
  if (Confirm "放行入站 TCP $($script:CfgWebPort)（供局域网访问观测台）？" 'Y') {
    New-NetFirewallRule -DisplayName $name -Direction Inbound -Protocol TCP -LocalPort $script:CfgWebPort -Action Allow | Out-Null
    Ok "已放行 $($script:CfgWebPort)/tcp"
  }
}
function Cmd-Doctor {
  Step '环境体检'
  $null = Get-SystemInfo
  try {
    $cs = Get-CimInstance Win32_ComputerSystem
    Say ("虚拟化   ：HypervisorPresent=" + $cs.HypervisorPresent)
  } catch { $null = $_ }
  try { Say ('WSL      ：' + (((& wsl.exe --status) 2>$null | Select-Object -First 2) -join ' | ')) } catch { Warn 'WSL 状态获取失败' }
  Say ('Docker   ：' + $(try { (& docker --version) 2>$null } catch { '未安装' }))
  Say ('Compose  ：' + $(try { ((& docker compose version --short) 2>$null | Select-Object -First 1) } catch { '不可用' }))
  Say ("端口     ：$($script:CfgWebPort) " + $(if (Test-PortInUse $script:CfgWebPort) { '已监听' } else { '未监听' }))
  Cmd-Status
  Step '近期错误摘录（各服务最近 200 行）'
  $errs = Get-DCOutput logs --tail 200
  if ($errs) { $errs | Select-String -Pattern 'error|traceback|401|403|refused|denied' | Select-Object -Last 20 | Out-Host }
  & docker system df 2>$null | Out-Host
}
function Cmd-Uninstall {
  Ensure-Admin
  Warn "即将卸载 compose 项目 '$($script:ProjectName)'（目录：$($script:InstallDir)）"
  if (-not (Confirm '确认停止并移除全部容器？' 'N')) { Warn '已取消'; return }
  $flags = @()
  if (Confirm '同时删除数据卷（PostgreSQL 历史数据 + 已登录账号库将【永久丢失】）？' 'N') { $flags += '--volumes' }
  if (Confirm '同时删除本项目构建的镜像？' 'Y') { $flags += @('--rmi','local') }
  Invoke-DC down @flags
  Ok ('容器/网络已移除' + $(if ($flags) { "（含 $($flags -join ' ')）" } else { '' }))
  if (Confirm "删除安装目录 $($script:InstallDir) ？" 'N') {
    $bkDir = Join-Path $script:InstallDir 'backups'
    if ((Test-Path -LiteralPath $bkDir) -and (Get-ChildItem -LiteralPath $bkDir -ErrorAction SilentlyContinue) -and
        (Confirm "保留 backups\ 目录（移动到 $($script:InstallDir)-backups）？" 'Y')) {
      Move-Item -LiteralPath $bkDir -Destination ($script:InstallDir + '-backups')
    }
    Remove-Item -LiteralPath $script:InstallDir -Recurse -Force
    Ok '安装目录已删除'
  }
  Get-NetFirewallRule -DisplayName "maxxiang-web-*" -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $script:PointerFile -ErrorAction SilentlyContinue
  Say '如需彻底清理 Docker 层缓存：docker builder prune'
}

function Show-Summary {
  $kgAbs = Resolve-KgDir
  Write-Host ''
  Write-Host '══════════════════ 部署完成 ══════════════════' -ForegroundColor Green
  Say "安装目录     ：$($script:InstallDir)"
  Say "compose 项目 ：$($script:ProjectName)（deploy 目录：$($script:DeployDir)）"
  Say "观测台入口   ：http://127.0.0.1:$($script:CfgWebPort)/"
  try {
    Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
      Where-Object { $_.IPAddress -notmatch '^(127\.|169\.254\.)' } |
      ForEach-Object { Say ("               http://{0}:{1}/" -f $_.IPAddress, $script:CfgWebPort) }
  } catch { $null = $_ }
  if ($script:V.AdminMode -eq 'on') {
    $admUrl = "http://<host>:$($script:CfgWebPort)/$(Get-AdminCfg 'path')"
    $admUser = Get-AdminCfg 'username'
    if ($admUser) { $admUrl += "（账号 $admUser）" }
    if ($script:V.AdminPw) { Say "管理后台     ：$admUrl（口令即刚才所设）" }
    else { Say "管理后台     ：$admUrl（沿用原 .env 中的口令/散列）" }
    Say '               登录账号见 deploy\.env 的 STA_ADMIN_USERNAME（与口令成对）；入口路径见 config.yaml 的 admin.path（.env 的 STA_ADMIN_PATH 可覆盖）'
    Say "               人机验证服务不可用、进不了后台时：$($script:SelfName) admin-link（一次性应急登录链接）"
  } else { Say "管理后台     ：未启用（需要时在 .env 设 STA_ADMIN_PASSWORD 后执行 '$($script:SelfName) env' 应用）" }
  Write-Host ''
  Write-Host '—— 后续两步（重要）——' -ForegroundColor White
  Say '① 注入监控房间：'
  Say "     .\$($script:SelfName) seed 321 2678075"
  Say "     .\$($script:SelfName) seed -File rooms.txt      # 每行一个，支持数千房"
  Say '② 配置票据自动续期（强烈建议，票据约 30 天过期）：'
  Say "     编辑 $kgAbs\accounts.json（参照同目录 accounts.example.json 填酷狗账号），"
  Say "     然后：.\$($script:SelfName) accounts"
  Write-Host ''
  Say "日常管理：.\$($script:SelfName)    （进入菜单：状态/日志/扩容/备份/更新/卸载…）"
  Write-Host '═══════════════════════════════════════════════' -ForegroundColor Green
}

function Cmd-Install {
  Step "九法观测台 · Windows Docker 部署（脚本 v$($script:ScriptVersion)）"
  Ensure-Admin
  $script:InstallDir = if ($Dir) { $Dir } else { '' }
  if (-not $script:InstallDir) {
    $def = $script:DefaultInstallDir
    if (Test-Path -LiteralPath $script:PointerFile) {
      foreach ($ln in Get-Content -LiteralPath $script:PointerFile) {
        if ($ln -match '^INSTALL_DIR=(.+)$' -and (Test-Path -LiteralPath $Matches[1].Trim())) { $def = $Matches[1].Trim() }
      }
    }
    $script:InstallDir = Ask '安装目录' $def
  }
  Set-ProjectPaths $script:InstallDir
  Ensure-Docker
  Set-RegistryMirrors
  Get-Project
  Test-Resources | Out-Null
  Load-State

  $reuse = $false
  if (Test-Path -LiteralPath $script:EnvFile) {
    Say "检测到既有配置：$($script:EnvFile)"
    if (Confirm '复用现有 .env 直接部署（选 N 则重新走配置向导并覆盖）？' 'Y') { $reuse = $true }
  }
  if ($reuse) {
    $p = Get-EnvValue 'WEB_PORT'; if ($p) { $script:CfgWebPort = [int]$p }
    $k = Get-EnvValue 'KG_DATA_DIR'; if ($k) { $script:V.KgDir = $k }
    if ((Get-EnvValue 'STA_ADMIN_PASSWORD') -or (Get-EnvValue 'STA_ADMIN_PASSWORD_HASH')) { $script:V.AdminMode = 'on'; Ensure-AdminUsername } else { $script:V.AdminMode = 'off' }
  } else {
    Invoke-Wizard
    Write-EnvFile
  }
  Initialize-KgData $script:V.KgDir | Out-Null
  if ((Test-PortInUse $script:CfgWebPort) -and -not (Get-DCOutput ps -q web | Select-Object -First 1)) {
    Die "端口 $($script:CfgWebPort) 已被其他进程占用；换端口后重试（修改 .env 的 WEB_PORT）"
  }
  Invoke-Preflight
  Invoke-DeployUp
  Protect-AdminPassword
  Cmd-Firewall
  Save-Pointer
  Save-State
  Show-Summary
  if (-not $Yes -and (Confirm '现在就注入要监控的房间吗？' 'Y')) { $script:CommandArgs = @(); Cmd-Seed }
}

function Show-Menu {
  while ($true) {
    Write-Host ''
    Write-Host ("┌─────────── 九法观测台 · 管理菜单（{0}）───────────┐" -f $script:InstallDir) -ForegroundColor White
    @'
  1) 状态总览            2) 查看日志           3) 注入监控房间(seed)
  4) 调整 worker 副本    5) 票据账号续期设置    6) 重启整栈
  7) 停止                8) 启动               9) 重建镜像并更新
 10) 备份               11) 从备份恢复         12) 更新项目代码
 13) 编辑 .env 并应用   14) 重设后台口令       15) 防火墙放行端口
 16) 环境体检(doctor)   17) 卸载              18) 后台应急登录链接
  0) 退出
'@ | Write-Host
    $c = Ask '请选择' '0'
    $script:CommandArgs = @()
    switch ($c) {
      '1'  { Cmd-Status }
      '2'  { $s = Ask '服务名（postgres/redis/worker/web/login，留空=全部）' ''
             $script:CommandArgs = @($s | Where-Object { $_ })
             if (Confirm '持续跟随输出（Ctrl+C 将退出脚本）？' 'N') { $script:CommandArgs += '-f' }
             try { Cmd-Logs } catch { Warn $_.Exception.Message } }
      '3'  { try { Cmd-Seed } catch { Warn $_.Exception.Message } }
      '4'  { try { Cmd-Scale } catch { Warn $_.Exception.Message } }
      '5'  { Cmd-Accounts }
      '6'  { Cmd-Restart }
      '7'  { Cmd-Stop }
      '8'  { Cmd-Start }
      '9'  { Cmd-Rebuild }
      '10' { Cmd-Backup }
      '11' { try { Cmd-Restore } catch { Warn $_.Exception.Message } }
      '12' { try { Cmd-Update } catch { Warn $_.Exception.Message } }
      '13' { Cmd-Env }
      '14' { try { Cmd-AdminHash } catch { Warn $_.Exception.Message } }
      '15' { Cmd-Firewall }
      '16' { Cmd-Doctor }
      '17' { Cmd-Uninstall; break }
      '18' { try { Cmd-AdminLink } catch { Warn $_.Exception.Message } }
      '0'  { break }
      ''   { break }
      default { Warn '无效选择' }
    }
    if ($c -in @('0','','17')) { break }
  }
}

function Show-Usage {
  $raw = Get-Content -LiteralPath $script:SelfPath -Raw
  $m = [regex]::Match($raw, '(?s)^<#(.*?)#>')
  if ($m.Success) { Write-Host $m.Groups[1].Value.Trim("`r`n") } else { Write-Host '（用法说明缺失）' }
}

function Main {
  if ($Help -or $Command -in @('-h','--help','help')) { Show-Usage; exit 0 }
  if (-not $script:OnWindows -and -not $script:TestMode) {
    Die '本脚本仅适用于 Windows（Linux/macOS 请使用 deploy-maxxiang.sh）'
  }
  Add-DeployLog 'INFO' ("===== {0} v{1} 启动：cmd='{2}' args='{3}' =====" -f $script:SelfName, $script:ScriptVersion, $Command, ($CommandArgs -join ' '))
  switch ($Command) {
    'install' { Cmd-Install }
    '' {
      # 注意：不能用 try/catch 包非 Probe 调用——Die 是 exit，catch 接不住，
      # 会把『新机器首次运行』这条主入口直接杀死。Probe 模式专为此路径而设。
      $hasDeploy = [bool](Find-ExistingInstall -Probe)
      if ($hasDeploy) {
        Ensure-Runtime
        $p = Get-EnvValue 'WEB_PORT'; if ($p) { $script:CfgWebPort = [int]$p }
        Say "已定位部署：$($script:InstallDir)（进入管理菜单；重新安装请执行：$($script:SelfName) install）"
        Show-Menu
      } else { Cmd-Install }
    }
    default {
      $known = @('status','logs','seed','scale','start','stop','restart','rebuild','accounts',
                 'admin-hash','admin-link','backup','restore','update','env','firewall','doctor','uninstall','menu')
      if ($Command -notin $known) { Die "未知子命令：$Command（-Help 查看用法）" }
      Ensure-Runtime
      Find-ExistingInstall
      $p = Get-EnvValue 'WEB_PORT'; if ($p) { $script:CfgWebPort = [int]$p }
      switch ($Command) {
        'status'     { Cmd-Status }
        'logs'       { Cmd-Logs }
        'seed'       { Cmd-Seed }
        'scale'      { Cmd-Scale }
        'start'      { Cmd-Start }
        'stop'       { Cmd-Stop }
        'restart'    { Cmd-Restart }
        'rebuild'    { Cmd-Rebuild }
        'accounts'   { Cmd-Accounts }
        'admin-hash' { Cmd-AdminHash }
        'admin-link' { Cmd-AdminLink }
        'backup'     { Cmd-Backup }
        'restore'    { Cmd-Restore }
        'update'     { Cmd-Update }
        'env'        { Cmd-Env }
        'firewall'   { Cmd-Firewall }
        'doctor'     { Cmd-Doctor }
        'uninstall'  { Cmd-Uninstall }
        'menu'       { Show-Menu }
      }
    }
  }
}

# 直接执行时进入 Main；MAXX_PS_TEST=1 时仅加载函数（便于 dot-source 测试）
if ($env:MAXX_PS_NO_MAIN -ne '1') {
  try { Main } catch { Err $_.Exception.Message; Err "详细日志：$($script:LogFile)"; exit 1 }
}
