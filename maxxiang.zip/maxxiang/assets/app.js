/* ═══════════════════════════════════════════════════════════════
   小叮当九法数据 · 观测台   app.js (界面 2.9.9 · 驾驶舱 + 纵览双模
   + 模拟游戏停靠面板)
   2.9.0:全部 /api/*(含 SSE 与灵机推演)由 server.py 后端应答 —— 后端整合
   项目 B 的九法真实数据引擎(真实抓取出怪 + 六模型集成预测),观测台数据模拟
   已彻底移除;支持同时监控多个房间号。左侧模拟游戏面板仍为独立单机模拟(与
   观测台真实数据无关),经 window.JiufaShared 共享当前房号。
   2.9.1:倒计时以项目 B 为准(MainPage 权威计时经 SSE/live-rooms 下发,真实
   步进 50001,换局/出怪即时推送 = 第一时间);主播名录删除通用化(全部房间可删,
   后端同步停监控并出配置,重启不复现)。
   2.9.2:「施法期」与「备战」倒计时合并为同一段「距出怪」连续读秒(40→1 不重置),
   进度环整段一笔扫满;相位标签/配色保留。
   3.1.1:出怪序列 / 近24h战况 的末位悬挂珠同样吃这段合并读秒 —— 备战期不再显示
   「封」字,徽记由 数字→封→开 三态收敛为 数字→开 两态(相位仍由配色标注)。
   3.4.5:悬挂珠语义回归「距下一颗珠落盘」—— 本局结果一上盘(与九法阵 is-latest 同判据),
   立即改读秒至**下一局出怪**(秒数跨换局边界严格连续 …42·41｜换局｜40·39…);
   朱砂「开」自此专属「官方出怪窗内、结果未到」的等待态,不再与已落地的结果珠
   并存整段出怪期(实测健康链路下该冗余每局约 13.5s,且与 tooltip 语义错位)。
   3.1.1:名录与账号库上限 —— 直播间 ≤50、账号 ≤10(前端闸,见 MAX_ROOMS/MAX_ACCOUNTS)。
   3.2.0:拉取改自适应 —— 拆掉 setInterval(pollNew, 8000) 定频轮询。
     · /history  只在「本局结果按理已存在、本地却还没有」时拉,退避到手为止(封顶 8s,不劣于旧定频)
     · /prediction 与 /history 解耦,由 predChase 在新局落地后按学到的结算滞后拉一次(AIMD)
     · SSE 掉线时靠响应的 HTTP Date 头校时(此前 calibrate 只由 SSE 调用,一断就冻住)
     · 主动探测系统钟跳变(Date.now() - performance.now() 突变),它是本方案唯一的死锁模式
     · document.hidden 期间完全静默;回到前台补一枪
     实测(SSE 健康):/history 6.3 → 0 次/局;后台标签页 17 → 0 次/分。
   3.3.4:全站清除用户读不懂的「结算中」字样 —— ① 推演判定徽标:该局判定
     未回填时只显「上局开 X ⋯」(悬停提示「判定同步中」),回填后自然补上
     主中/防中/未中;无预测的局停在纯号位,不再挂 50s 误导词。② 模拟面板
     局相位标签 end 态改「本局结束」(data-p 样式键不变)。随本条 bump
     index.html 的 ?v=3.3.4 —— /assets 走启发式缓存,改 JS 必须同步 bump。
   3.3.5:同帧判定 —— 出怪 SSE 载荷捎带 pred(上局 settled 判定 + 新局 next
     推演;后端 publish 前本就已结算,判定现成),前端在 ingest 前合入:珠与
     主中/防中/未中同帧出现,「⋯」只剩降级路径(SSE 断/该局无预测)。predChase
     保留:权威对账 + accuracy 刷新。index.html 随之 bump ?v=3.3.5。
   3.3.6:判定徽标唯一形态化 —— 无判定(引导局/停机档无预测、降级空档)整枚
     隐藏,不再有「上局开 X ⋯」中间态;有判定即一次成型。CSS 撤销已废的
     data-v=pending 规则(app.css → 2.9.21)。index.html 随之 bump ?v=3.3.6。
   3.3.7:本地即时判定 —— 目标局精确匹配时前端直接做三选一包含判断(规则与
     后端逐字一致,输入同源 ⇒ 零分歧),判定与出怪号同帧成型不再依赖任何
     网络时序;旧版 worker/轮询降级/事件乱序全覆盖。权威记录仍由 predChase
     对账(同值覆盖,零可见变化)。index.html 随之 bump ?v=3.3.7。
   3.3.8:applyPredPush 单调守卫 —— 乱序/重放的陈旧 pred 载荷整体忽略(判定榜首
     只进不退、推演目标只进不退),防御性堵死"旧载荷覆写新状态"的理论向量。
     index.html 随之 bump ?v=3.3.8。
   3.4.4:号位聚光 —— 单击九法阵任一妖怪卡,出怪序列(含全屏)只亮该号、其余压暗,
     一眼读出该号的疏密与节奏;再点取消,可多选叠加(如同时点亮主推两号对照)。
     · 状态挂序列**容器**类(hl-on/hl-nN):renderRoad 的 innerHTML 重建只换子节点,
       聚光天然幸存,增量快路径零适配;换房随 applyRoomData 清空(异房节奏不可比)。
     · 序列头部/全屏头部出「聚光」徽标:各号色印 + 在盘珠数(与序列同窗口口径),
       点徽标或 Esc 一键清除(Esc 让位于全屏/弹层/名录,先关覆盖层再清聚光)。
     · 妖怪卡补 role=button/tabindex/aria-pressed,Enter/Space 同击;卡面 is-picked
       元素色描边呼应。压暗仅 opacity(实测裁掉逐珠过渡与 saturate 滤镜:前者令切换
       样式重算约翻倍,后者在 .14 透明度下像素差不可辨);脉冲珠豁免不被压暗。
     index.html 随之 bump ?v=3.4.4,app.css → 2.9.22。
   3.6.0:按日回看 —— 全屏序列升格双模:实时全景(现状)/按日回看(retention>1
     时自动出现)。日导航(昨天/前天/日期下拉/←→键/回到实时)、当日九宫简报、
     会话级 LRU 8 日缓存 + 冻结日 immutable 长缓存两级免流量。隔离铁律:回看
     只活在覆盖层,对 S.hist/lagMs/coverage 自愈/推演对齐(2.9.5)/SSE 单调
     守卫(3.3.8)零触碰 —— renderRoad 的 wideGrid 分支仅加 WV.mode 半行守卫。
     「今天」恒为实时,不存在会悄悄过期的静态今日;门控看 /history/days 的
     **数据存在性**而非配置(retention=1 时导航整体隐形,亦天然覆盖管理台
     热更 retention 与 ≤0 永久保留)。日归属=北京**起局日**,与 dayNo/后端
     日桶逐字一致。index.html 随之 bump ?v=3.6.0,app.css → 2.9.23。
   3.9.0:安全加固 —— 每账号「同时只监控 1 个活跃房」:所有 /api 请求带 X-JF-Tab
     标签页标识(SSE 走 ?tab=),后端据此发租约。3.9.0 为 incumbent-wins(后来者被拒
     409 room_busy / leaseBusy);**3.9.3 起改 last-wins**,见下方 3.9.3 条目。
   3.9.1:执行证明(L2,3.9.2 起后端默认开)—— /api/auth/session 回 pow.enabled 时,前端
     向 /api/pow/mint 取挑战、用 powAnswer() 算应答,明细端点统一带 X-JF-Proof。
     powAnswer 与后端 app/web.py::_pow_answer **必须逐位一致**(tests/
     test_proof_of_browser.py 跨语言对拍钉住;改一侧忘另一侧当场红)。部署时本文件
     被 build-deploy.mjs 混淆 —— 混淆语义保持,不改变应答值。
   3.9.3:活跃房租约改 **last-wins**(以最后一次切换的直播间为准)——
     ① **显式**切房(rail 点击/搜索/添加/URL ?room=)先 POST /api/active-room/claim
        抢占租约(loadRoom 的 explicit 选项);跟随/恢复**不**抢占(只 renew),
        否则两窗会互抢产生抖动;
     ② 活跃房被别处切走时:SSE 收 follow 事件 / 明细回 409 room_switched(均带目标房)
        → followRoom() **自动切换过去** + 单次轻提示,**不再有窗口被拒**;
     ③ 关页 pagehide 经 sendBeacon 主动交还租约(release);
     ④ room_busy 分支保留为**老后端兜底**(短固定重试,不进指数退避)。
     实测:另一窗口切房后本页 ~2.5s 自动跟随;收敛后不抖动;单窗正常路径零影响。
   3.9.2:后端 L2 默认开启(STA_USER_PROOF_OF_BROWSER=1)—— 本文件必须是含
     powAnswer 的新版,否则明细端点会 401。index.html 已 bump ?v=3.9.2 强制刷新;
     另新增纯服务端行为遥测(L4),**不涉及本文件**。
   3.9.4:单活跃房的可用性四补(逐条实地核查后修,详见 LOGIN-SYSTEM.md §6.5「可用性四补 + 运维可见性」):
     ① **?room= 只消费一次**:dataBoot 读到即 replaceState 清参 —— 移动端后台标签
        被系统回收后回前台整页重载,若参数常驻,每次重载都被当"显式切房"claim,
        把其它设备硬拽回旧房(违背 last-wins 的**意图**语义;实测确定性复现);
     ② 跟随提示补归因("由另一窗口/设备切换")+「切回 <原房>」按钮(= 一次显式
        claim,把"以谁为准"交还用户)+ 120s 内被跟随 ≥2 次时点破拉锯并披露规则;
        新增 toastAction()(共 #toast 单管线);connState 悬停常驻规则说明;
     ③ **跟随发现降到亚秒**:后端 claim 成功即广播 alr:evt:u{uid},SSE 收到做一次
        权威 renew,被切走立即 follow(本文件零改动 —— 复用既有 follow 监听);
     ④ **侧栏速览**:名录每房「开/下 Ns」倒计时角标(railChip/railTickPaint,
        数据 = 既有 live-rooms 字段 + 50001 格点外推;30s 静默重拉刷新锚点)——
        单活跃房下非活跃房不再是信息黑洞,合法的"哪房快出怪"对比不必逐个切换。
   3.8.0:登录系统 —— 后端启用用户库鉴权时(/api/auth/session enabled:true),
     未登录全屏登录门 + 各面板霜罩;所有 /api 请求统一带 X-JF-Auth 头
   4.1.0:链接快速登录(SSO)—— URL 片段 #sso=<64hex> 一次性票据,boot 在鉴权前
     兑换正式会话(读到即清片段,只消费一次;已登录他号先确认再切换);见 SSO-LOGIN.md
     (CSRF 防线,SSE/<img> 天然豁免);会话失效(401 kicked/expired…)即时
     回落登录门。名录与账号数据按登录账号隔离由**服务端**保证,前端零特判;
     用户级 localStorage 键(room/snap/myRooms/模拟钱包…)按登录账号加
     @u<id> 后缀,同设备多账号互不串档。登录/登出以 location.reload() 收束,
     整树状态从零重建 —— 杜绝上一账号的内存残留。index.html bump ?v=3.8.1。
   4.1.1:移动端"关浏览器重开后官方游戏永卡「正在装载」"根治(两处正交死端,
     均三内核实证复现;详见 loadJiufaFrame/loadRoom 尾部长注)—— 数据面:
     loadRoom 零基线死端加指数退避重试,visibilitychange/online 遇 spells 空
     改走全量补齐;呈现面:iframe 就位判定改看帧内真实文档+引擎形态(会话恢复
     的"幽灵帧"零重载直接采纳),遮罩生命周期三保险(750ms 轮询 + 常驻 load
     监听 + 12s 起步退避看门狗补导航),揭遮罩不再以父页法术表为前置。
     index.html bump ?v=4.1.1。
   4.1.2:官方象限「正在装载模拟游戏」永驻的三个残余死端根治(Playwright
     移动端视口逐一实机复现后修复;详见 jfHintShow 前长注):① 4.1.1 看门狗
     「在途装载豁免」无封顶 —— 移动网前置资源(CSS/引擎脚本)连接停摆时
     readyState 永远不 complete,豁免变永动机、遮罩无限期;现豁免累计封顶
     45s,越顶判停摆照踢(重导航重建停摆连接)。② sim-engine 被拦/引擎双侧
     缺位时踢了也白踢 —— 旧版无限盲踢(移动网每踢整帧重下)且用户只见永恒
     转圈;现连踢 3 次未就位转「失败终态」:可点击重试的明确提示,盲踢停止、
     轮询照跑(自愈仍即时揭开)。③ 帧内对偶自愈新增 jiufa/jf-boot.js:
     sim-engine 未就位时装 fetch 桩止血(掐断 /kugou/* 对真实后端的 405
     风暴)并有界重载自愈(10 分钟 ≤3 次;账本 sessionStorage,被禁站点数据
     时退 window.name 兜底,两介质皆失效则放弃自愈交父页,任何环境绝无无限
     重载);误装独立引擎(会话恢复竞态)帧内轮询父页引擎就绪即重载纠形态。
     失败终态无障碍完备:aria-hidden 翻 false、role=button、tabindex=0、
     Enter/Space 键盘等价重试(装载态维持纯装饰 aria-hidden)。
     jiufa/index.html 两枚裸引用
     window.tmegame.report 的内联上报补判空(bridge.js 加载失败时不再抛错)。
     index.html bump ?v=4.1.2。
   3.8.2:出怪规律五处钉真(逐条实测复现后修复,详见各处行内注)——
     ① S.hist 钉真为「最新局 − 24h」锚定时间窗(pruneHistWindow):此前是
       ≤HIST_CAP 的局数窗,retention>1 / 低在线率房的最近 1800 局可跨多天,
       序列/战况/出怪规律/聚光的"24h"标注整体失真(实测注入 3 天前数据仍称 24h);
     ② 偏差着色改 2σ 显著性判据 + 50 局样本下限(旧 ±0.05pp 低于抽样噪声,
       1 局样本也能顶满权重红字);③ 零数据空态(司历/九法阵),不再把空历史
       误标九个「刚出」+ 大幅负偏差;④ 「今日」日界改校准钟 nowC(与按日回看
       同因同修);⑤ tick 侦测跨北京零点自动重渲司历(断流跨夜不再整晚顶着
       昨天的今日计数)。「最大」列措辞钉真为"24h窗内最大连空(含边界截断)"。
       复审补:序列增量路径(tryAppendRoad)收边界随 ① 改为 min(容量, hist 长度)
       —— 锚定窗下 hist 稳态低于容量,旧收边"只进不出",实测 80 局后盘头 72 颗
       越窗陈珠滞留;战况为真虚拟化(行数组/容器高每帧从 hist 重建)天然免疫,已实测确认。
     index.html bump ?v=3.8.2,app.css → 2.9.24。
   3.9.5:名录速览角标**诚实化**(实地核查复盘,四处失真同修;railChip 处有全案注)——
     ① 旧「休(可能已下播)」在实配(curated-idle enforce)下是结构性假警报:
       用户驻留单房 30 分钟后,其余名录房被降级为低频采集,后端 lastOkAt 冻结,
       10 分钟阈值一到全员永久挂"休" —— 而数据其实每 T 都在成功入库、零缺口,
       且九法为 24 小时连续出怪,"下播"与数据有无本就无关。现按后端新发 mode /
       dataOkAt 分档:idle 房照常读秒 + 虚线「省流」态;真失联才显『断』并携带
       lastError 真因(票据过期/上游异常);pending/从未抓到显『待』;
     ② 失联判据改「名录快照落地时刻」口径(S.roomsFetchedAt − okAt):后台标签
       ≥10 分钟回前台的 0~34s 内,S.rooms 冻结、now−okAt 高估数据年龄,旧判据
       让**连当前正看的房**都闪"休"(与主舞台自相矛盾,可稳定复现);
     ③ visibilitychange/online 回前台补拉一次名录(此前只补主舞台不补侧栏);
     ④ loadRoom 成功后 3s 补拉名录 —— 冷房唤醒(mp@now)写入新鲜快照后,
       角标不再多挂最长 ~34s 的过期状态。idle 失联阈随后端 histIntervalS 自适应
       (2×T + 2min 余量),旧后端无该字段时取缺省。index.html bump ?v=3.9.5,
       app.css 增 .ri-tick.slow/.lost 两态。
   4.4.0:basic 档「在线累计窗」+ 连空口径钉真(两件事其实是同一件)——
     ① basic 档不再「刷新即清零」:用户**在线期间实际读到过**的局可留存本机并在
       刷新后回灌,窗口由后端 jf.basicOnlineH 下发(0=关闭=逐字节 4.3.x 行为)。
       服务端 history 的 limit/until 硬闸**一行未动** —— 没多给一个字节新数据,
       只是不再把他自己看过的东西丢掉。掉档(vip→basic)由两道拦:档位变化清场 +
       快照 tier 戳校验(伪造前者仍被后者拒);
     ② 快照升 v3 精简格式 {b:基准, r:"号位串"},缺局占位 '0'。1728 局 646KB→~3KB
       —— v2 格式下满窗留存根本放不进 localStorage(6 房 LRU 需 3.9MB);
     ③ 断档不再重建基线,改为保留 + 标断口:断口后那颗珠带 data-gap(**零新增
       节点** —— 插节点会打乱 tryAppendRoad 的珠序算术,实测会错位);
     ④ 连空(deriveStats)从「数组下标」改为「格点距离」。真机 25h 快照里
       2678075 房有 17 局连续缺口,旧口径把号位 9 的 89 格报成 72,判档可能把
       「极冷」显示成「正常」。跨断口时真值只知落在 [lo,hi],给区间 `lo~hi`,
       判档取保守下界(初版只给下界被实测打脸:比旧值更弱,反而掩盖极冷号)。
       无断口时新旧输出逐字节相同,零打扰。
     后端:新增 STA_JF_BASIC_ONLINE_H(🟢 热更)、web.vip_matrix() 让对比表文案
     随生效配置渲染(写死会在调窗后撒谎)。index.html bump ?v=4.4.0。
   4.7.0:移动端 24h 战况可读性 + 缺局占位格(纯前端,后端零改动)——
     ① 位数默认收敛:此前写死 24,而 rgRoadFitCols 按容器实宽夹紧,六款主流
       手机实际生效档是 10/20/22/22/24/24 —— 同一份代码给出四种「默认」。
       现按视口二分(rgColsDefault:<1024 → 20,否则 24),并把行内缝在 ≤380px
       收到 3px(rgRoadGap,与 CSS @media 同源)—— 否则 320 宽机型 fit 只有 18,
       档池里根本没有 20 位。用户显式改过档的持久值优先,此处只兜底。
     ② 战况高度三处根因一起修:(a) .of-aide 的成长曲线**只写给了 ≥1024**,
       移动端恒锁 186px —— 932 高的机器与 667 高的机器拿到一样的战况仓;
       (b) .rg-road-row 的 min-height:60px 是硬地板,内容压不进父级,那 60px
       其实是**溢出**换来的(实测 .of-aide-body 溢出 27px);(c) 战况珠因 grid
       子项 min-height:auto 把 aspect-ratio:1 顶破,实测 12.13w×17.05h,每行
       白吃 4.2px。三条修完:常规档可见行 3.04 → 3.91~8.06,溢出归零。
       底仓同步 186→208(拆账见 app.css P2-g:少 10.5px 正是靠溢出掩盖的,
       只堵溢出不抬底仓会让**桌面**战况从 60px 掉到 38px —— 已实测复现)。
     ③ 折叠钮升三态(收起/常规/加高,持久化 KEY.aideSize)+ 战况头一键「全屏」
       (复用成熟的 #wideView:z70 > 坞 z60,且在 #shell 外不吃 inert)。
       加高档舞台保 280px 下限 —— 再低游戏在 iframe 内 contain 到不可玩。
       侧栏形态(容器 ≥620px 且宽:高 ≥0.62)下加高无意义,CSS 侧显式复位:
       不复位会把通高侧列压塌(实测横屏手机面板 30px、iPad 竖屏 971→664 倒挂)。
     ④ 缺局占位格:4.4.0 的断口只是「后一颗珠左缘一道竖线」,**不占格** ——
       17 局的洞和 1 局的洞一样宽,列位与时间轴对不齐。现升格为占实格的占位珠,
       g ≤ GAP_INLINE_MAX(5)逐格出,更大的出 1 枚折叠珠、点/回车就地展开
       (正面回应 4.4.0 原注「17 个灰格在 72 列档能吃掉半屏」)。
       4.4.0 原注的另一条顾虑「插节点会打乱 tryAppendRoad 的珠序算术」成立,
       解法:三处算术改读 grid.dataset.n / dataset.last 单一真相,不再依赖
       children 序。五个渲染点一次改齐(主盘全量/增量、实时全屏、按日回看、
       游戏战况),折叠珠在四处盘面都绑了点击+键盘(#roadGrid 此前一个 click
       监听都没有、#wideGrid 只认重试键、bindRg 也不认它)。
       战况三线图同标断口,但**刻意不插行**(trend-row 走 top:i*pitch 绝对定位,
       插行会让行序算术错位),只在期号格画一条朱砂下边线。
       实时全屏补上「· 缺 N」,与按日回看口径对齐。
     index.html bump ?v=4.7.0。
   4.7.1:占位珠取消折叠,近24小时缺口恒按时间格逐珠展开 —— 删除折叠珠的
     role/button/键盘委托与专属样式;voidHtml/voidNodes 无条件生成 g 颗占位珠。
     新增 gapSlots/missingSlots 单一口径,主盘、实时全屏、按日回看、游戏战况的
     缺口渲染和「缺 N」计数逐颗一致。24h 窗总格点仍约 1729,节点数有硬上界。
     index.html bump ?v=4.7.1。
   4.7.2:序列贴底守卫(stick-to-bottom guard)—— 全部序列「载入即在底部,且此后
     一直在底部」。病灶不是占位珠(已 A/B 实测排除:有/无占位珠两组行为逐字节同构),
     而是**贴底一直被当成一次性事件**:四处序列各在渲染尾巴打一发 snapScroll 就撒手,
     此后容器高度/内容高度每变一次就掉一次底,无人补救。真机(Chromium 390x844)实测:
       · 手机地址栏收起(视口 844->780)     战况余 21px;缩到 700 时余 49px  ← 用户反馈的「刚载入就偏」
       · 横竖屏切换                        主序列余 168px
       · DIY 盘战况                        余 1518px,且自锁死在顶部永不恢复
     改为订阅式维持:stickInit/stickPin/stickPinAll 三件套 + ResizeObserver(容器盒
     + 内容盒)+ MutationObserver(珠子增删)+ visualViewport.resize / orientationchange
     / img load(capture)/ fonts.ready 四类迟到事件。用户上翻即**立即**让出控制权,
     滚动停稳在锚点上才重新接管(「路过锚点」不算「停在锚点」);守卫自己贴的那一跳
     用「一帧内 + 位置确实在锚点上」双条件识别,既不会自己误伤自己、也不会吞掉
     夹在其间的用户操作。
     ★ 判据走过两条弯路,均已实测复现后废弃,勿再走回头路:
       (a) 150ms 时间静默窗 —— 会吞掉窗内**用户真实的**上翻,armed 不翻转,
           下一次几何变化又把人拽回底部;
       (b) 位置回声(比对上次贴到的坐标)—— 用户自己滑回锚点时坐标恰好相同,
           被当成回声吞掉,永远不再接管;而滚动**路过**锚点的头几帧又会被判成
           「停在锚点」误重新接管,把 pulseBead 的平滑定位掐回底部。
     配套:stickReap 在每次 stickInit 时回收离场条目 —— AIDE 每落一局换一个新的
     战况节点,而 stickPinAll 只由用户驱动的事件触发,挂着不动的页面根本触发不到;
     实测连做 280 次重渲染,_sticks.size 由 4 涨到 144 线性无收敛(24h 约 1728 条,
     每条还拖着一个脱离文档的 DOM 与两个观察者),回收后恒定 3。
     pulseBead(点战况行联动序列)开头显式解除贴底 —— 那是用户明确要离开底部。
     applyLayout 里原先那发绕过守卫的裸 snapScroll 一并撤除(它会把翻历史的用户拽回)。
     顺带修复 renderRealGame 的 roadStick 自锁死:判据由「几何快照」改读守卫 armed
     —— 几何快照会被 rgFitRoad 的 88px 地板污染成「用户在翻历史」,一旦落到顶部就
     再也回不来;armed 只由用户真实滚动翻转,布局抖动动不了它。
     按日回看仍锚定顶部(当日回放从清晨读起,与实时贴底互为镜像),集中在常量
     WV_DAY_ANCHOR,一行可切。
     实测零回归:longtask 30->29、堆 10MB 持平、无 ResizeObserver loop 告警、零控制台报错。
     index.html bump ?v=4.7.2。
   4.7.3:序列位数按容器实宽夹紧 —— 修「序列数据全部重叠在一起」(用户实报)。
     珠字号是 clamp(4px, 珠径x0.62, 18px):珠径 >=6.45px 时字随珠等比缩、永远装得下;
     一旦跌破 6.45px,字号被 4px 下限顶住而格子继续缩 —— 字比格子还大,相邻数字直接
     咬在一起。而每行位数 S.cols 是**设备级持久值**(jf2:cols),其「按屏宽自适应」只在
     首访且从未存过值时生效;在桌面选过 36/72 的用户把这个值原样带到手机就中招。
     真机 390x844 实测(基线):
         jf2:cols=36 → 主序列 珠径 5.69px / 字号 4px
         jf2:cols=72 → 主序列 珠径 2.00px / 字号 4px(字是格子的两倍),全屏 3.05px / 4px
     而全屏的位数菜单在手机上仍无条件列出 72,用户能亲手选进这个坏状态。
     战况早在 4.1 就用 rgRoadFitCols 夹紧了,序列两处一直没有 —— 现补齐同一契约:
     新增 roadFitCols / roadColsFor / syncColSelects,**S.cols(用户档)绝不被覆写**,
     只夹「本次渲染实际用几列」,菜单只留装得下的档,容器变宽自动回到用户原档。
     下限 6.5px 取自上述 clamp 触底的数学临界点,不多夹一档:实测桌面 1440/1920 与
     平板 820 的 72 档逐字节不变(珠径 11 / 14 / 7.05px),仅手机 390 由 72 夹到 30
     (珠径 2px → 7.42px)。applyLayout 在夹紧结果跨档时重排一次,拖拽途中空转。
     index.html bump ?v=4.7.3。
   4.7.4:战况(.rg-road-row)行轨道塌陷 —— 修「近24小时战况里所有数据全部重叠」(用户实报,附图)。
     现象:整块糊成连续竖色条,只有最后一行看得清。
     量化(Chromium 1440x900 / 24 位档):珠径 15.52px,而**行距只有 4px**(恰等于 gap,
     即行轨道高 = 0)。逐珠检测「上一行底 > 下一行顶」:基线 400/400 全部相压;
     桌面/手机/平板、10~30 各档**无一幸免**,是全条件缺陷而非个例。
     成因:P2-a 为正方化给战况珠加了 min-height:0,同时把 grid 项的**自动最小尺寸**
     (min-height:auto = 「行至少装得下这一项」的保底)一并取消了。主序列不中招是因为
     .road-grid 高度为 auto、行按内容自然撑开;而 .rg-road-row 自己就是滚动容器、
     且在 .of-aide 里是 flex:1 1 0 的**定高**网格容器 —— 定高容器 + auto 行 +
     没了自动最小尺寸 ⇒ 行轨道塌到 0,珠子按 aspect-ratio 画出全尺寸后溢出行、
     层层相压,最后一行没人盖所以独独清楚。
     药方(CSS 一处):珠高由「靠 aspect-ratio 隐式推」改为**显式给定**,与既有字号规则
     同一条公式、同一个 cqw 容器。cqw 必须写在**后代**上才指向 .rg-road-row 的内容盒,
     故这条放在 .rg-bead-n 而非 .rg-road-row。高度成定值后行轨道按它来,再塌不下去;
     宽仍由 1fr 均分,两者同式 ⇒ 依然严格正方(实测 bw==bh 逐档成立)。
     修复后逐珠相压 0/400,行距 = 珠高 + gap(15.52+4=19.52),战况内容高 308→1401px。
     index.html bump ?v=4.7.4。
   4.7.5:灵机推演命中率行文案收束 —— 移除 4.6.0 加的回测溯源角标。命中率行由
     「全实盘一种形态 / 有回测另一种形态」的二分,收敛回**恒定单一形态**
     `近N局 主中X · 防中Y`(= 4.4.x 逐字节文案),tooltip 里分列实盘与回测条数
     的那一句一并去掉;观测台推演卡与官方模式随身面板共用 predStatText,
     两处同步生效。
     ★ 后端契约零改动:pred_replay 照常因果重跑、补算行照常带 source='replay'
       落库、/prediction 的 accuracy 照常回 replay 字段、record 照常回 s 字段。
       本轮删的只是前端这一层展示,运维/管理台/单测的溯源能力分毫未减;
       要恢复角标只需在 predStatText/predStatTitle 里重新读 acc.replay。
     ★ 「上局开X · 主中/防中/未中」徽标的实盘过滤(`r.s !== 'replay'`)**保持不变** ——
       角标是文案取舍,那道过滤是「不冒领战绩」的硬约束,两者正交,禁一并回退。
     顺带修一处既有隐患:rgPredToken 的指纹末位原是 accuracy.replay(角标没了它
     就成了纯空转重绘),而真正被渲染的 main/cover 反倒不在指纹里 —— 窗口跑满后
     n 恒等于 window 不再变化,只有命中数变时指纹判等 ⇒ 随身面板命中率行漏刷。
     可达路径已查证:web.py 3.4.6 换手回退窗内 target/main/guard 三者与结算前
     逐字节相同,而该局判定已进 accuracy ⇒ 旧指纹整串判等。
     整位换成 n|main|cover,与 predStatText 真正读的字段一一对应。
     index.html bump ?v=4.7.5(app.js 有实质改动;按 4.3.0 既裁先例 js/css 同步推进)。
   4.9.4:触屏可达性 —— 全站「悬停才看得见」的信息在触屏上一律不可达,本轮补齐。
     实地核查(Chromium 触屏模拟 iPhone 12 / iPad Pro 横屏 1366×1024)坐实三件事:
     ① 战况悬浮卡在触屏上**物理不可达**(三道锁,见 initInputBus 前长注);
     ② 全站 3500+ 个 title 在触屏浏览器**一律不渲染** —— 主序列 1728 颗珠、
        游戏面板战况 1727 颗、出怪规律 9 行与「偏差/最大」两个表头承载的 2σ
        显著性判据与 24h 窗截断口径、「单击聚光」用法、真实/模拟游戏「真实扣除
        星币」的差别、名录「断」态释义,手机上一个字都读不到;
     ③ iPad Pro 横屏落 cockpit 且 hover:none —— 名录轨的 pointerenter 展开
        永不派发,☰ 又被 body[data-layout=cockpit] 隐掉,只剩 64px 牌匾一个无
        提示的暗门。
     修法三条,均**只加不改**、桌面路径逐字节不动:
     · <html data-input> 按**最后一次 pointerdown 的 pointerType** 动态标记
       (媒体查询只作首帧默认值)—— 触屏笔记本/接了妙控板的 iPad 都能收敛;
     · 触屏提示总线:document 级单点委托,tap 判据(位移/时长)把「点」与「滑」
       分开,命中 [title] 即读同一份文本自绘气泡。**只读不写 title** ——
       仓库既有三支回归钉逐字节钉住 title(predgap/replay/it 三个 jsdom),
       删 title 当场三红;
     · 战况另走专线(悬浮卡内容含「距上次」等推导,不是纯 title):触屏点行
       = 显卡 + 十字准星 + pulseBead 联动,再点同行收卡。
   5.0.4:「出怪序列」缺局占位不再只能靠刷新页面才恢复(jsdom 走真实启动链路逐条实证)——
     ── 实测到的三种形态(修前)──────────────────────────────────────────────
     ① VIP、洞距最新 ≤30 局、后端随后补齐 → **本来就会自愈**(下一局落地时
        checkCoverage 补上),这条修前修后逐字节相同,勿误以为是新功能;
     ② VIP、洞距最新 >30 局 → **永不自愈**。且这类洞并非罕见:pollNew 按
        since=最新+1&limit=200 拉,而 db.history 是 DESC LIMIT —— 离开超过
        200 局(≈2.8h)时这一枪只回最新 200 局,**它自己就是造洞的那个人**。
        实测挂后台 300 局回前台:当场 100 颗占位珠,再过 5 局仍是 100,
        coverage 零调用;挂一夜(≈576 局)≈376 颗,占整条 24h 序列的 22%;
     ③ basic 档 → checkCoverage 一行 `if (isBasic()) return` 全关,哪怕洞就在
        最新 3 局内、后端早已补齐,也要等用户自己刷新。
     ── 修法(三处,均只加不改)────────────────────────────────────────────
     · ingest 是所有数据进 S.hist 的唯一咽喉,断层全从那里产生 → 在那里 markGap
       登记,由 resyncGap 定向补一枪(见其长注:limit 必须按 span 给足,否则
       DESC+LIMIT 取回的全是洞之上那截新局,洞原样不动);
     · basic 档同一枪即可受益且**不构成绕过** —— since 只抬下界,后端仍把 limit
       钳到 jf_basic_history_limit,结果恒 ⊆「最新 N 局」,与直接 /history?limit=N
       是同一批数据(§4.1 的数学论证一字未动);断口提示改报**补齐后的真实剩余**;
     · checkCoverage 防抖改自适应(15s 起、补不到翻倍、封顶 5min、补到即复位):
       后端哨兵 2~4 局内必给定案,那段窗口不再每局空打 coverage + history 两枪。
     ── 刻意没做的两件事(复核后撤回)────────────────────────────────────
     · **不**加宽 COVERAGE_WINDOW:洞落在窗外的成因是 pollNew 造洞,已在源头堵住;
       加宽只会让后端每次多扫行,换不来一个洞。
     · **不**给占位珠加「点此重取」:补完之后仍在的洞,按定义是官方本身缺失、
       或 basic 档硬闸外——按钮点了也补不回,那是骗人。tooltip 保持如实。
     index.html bump ?v=5.0.4。
   5.0.5:5.0.4 的复审修正 + 同族缺陷清理(逐条 jsdom 实证,详见各函数长注)——
     ① gapDead 键错(存 from、应存**格点**):止损标记与 gaps 列表不是同一个键,
        basic 扫描在首次判死后被同一个洞永久占住 Math.min。改为与 offMissing 同构,
        由 localGridGaps 一并过滤;
     ② resyncGap 的「还欠多少」口径:原用 missingSlots 全量数,把后端已确证
        official_missing 的格点也算在内(VIP 侧 coverage 第 0 局就定案了,却还要
        烧满预算),且 g.from 被 24h 窗裁掉后会把窗外格点永久算成缺 ⇒ left 恒 >0。
        现逐格点数并刨掉 offMissing/gapDead,下界夹到保留窗最旧一局;
     ③ 冷却点位:S.gapAt 原设在发枪前,而 api() 对 GET 重试 3 次 × 8s 超时,
        半死网络下单次可耗 ~24s、冷却早过期 ⇒ 退化成连打。改按**完成时刻**计;
     ④ flushIngest 次序:checkCoverage 的 basic 分支是同步 markGap 登记,必须排在
        resyncGap **之前**才能当帧补齐(颠倒要多等整整一局,实测 34.5s → 18.3s);
     ⑤ 预算 3 → 4:后端哨兵 COV_AUDIT_LAG_ROUNDS=2 + 5s 冷却 ⇒ 定案窗口 2~4 局,
        3 次的尾巴正好压在最坏情况上,会「差一局放弃」;
     ⑥ **同族缺陷**:jfFetchCross 固定 limit=3 —— 同样是 DESC+LIMIT 取最新 n 条,
        目标局早于最新 3 局就永远取不回来。sim-engine(混淆产物,'resultFo'+'r'
        经 RC4 解码,grep 抓不到)的结算主路走 RoundEngine.resultFor,拿不到即
        挂单永不结算,而 handle() 每次都重扫 bets 再催一次 ⇒ 持续空拉。
        实测(跨房、目标距最新 40 局):修前 12 次调用 = 12 次空拉且恒 null;
        修后 VIP 一次 until 精确取那一局(1 行)即命中,basic 按格点给足 limit、
        取不到即指数退避并在 5 次后判死。
     ⑦ resyncGap 的预算改**按格点各自计**(初版按 span 计,且 markGap 合并分支不
        重置)—— 决定性 A/B:断层 A 不可得、其 span 仍活着时产生断层 B,按 span
        计会把 B 连坐判死并写进 gapDead,后端随后补上 B 也再没人去取(末态 2 个
        占位珠);按格点计则 A 死归 A 死、B 用自己的预算补回(末态 1 个);
     ⑧ jfFetchCross 的 .catch 补退避 —— 403(档位不符/旧后端)、500、超时都走那里,
        而 handle() 每次都会重催,不压节奏就是按 RTT 持续重打。失败**不消耗**
        判死预算(与 resyncGap 同一纪律),只压 5s 节奏。
     ⑨ resyncGap 尾部的上界改重取 S.hist[0].start(原用发枪前捕获的 head):
        请求在飞那段 SSE 可能又推来一局并带着新断层,用陈旧 head 会把新格点排除在
        miss 之外,而随后又整体重写 S.gapSpan ⇒ 刚登记的新断层当场被抹掉;
        同处补 hist 空守卫(rebaseHist 与本函数无锁并发时 S.hist[len-1] 会是
        undefined,取 .start 直接抛)。
     ⑩ 见 loadRoom 里那两行 gapSpan 作废的适用面标注 —— A/B 实测证明它在常态下
        是空操作,原注释「每次开页白发 4 枪」不成立,已改为如实描述。
     ⑪ 跨 await 的状态写入收紧(A/B 实证,原以为只是 ≤8s 延迟,实测是**整枪丢失**):
        resyncGap 的 finally 原来无条件给 S.gapAt 打戳 —— 换房后回来的陈旧一枪
        会盖掉 applyRoomData 刚清零的节流位,新房紧接着产生的断层被节流拦掉:
        VIP 侧还有 coverage 兜住,**basic 侧没有 coverage,补齐枪一枪都发不出**
        (实测 13s 窗口内零请求)。现 gapAt 按 alias 守卫;gapBusy 则相反 ——
        它是本函数自持的互斥位,必须无条件释放(漏放会把整个会话的补齐锁死)。
        同处 pollNew 的 basic 断口提示补 alias 守卫:resyncGap 也是一次 await,
        期间换房则那条提示属于旧房。
        ★ checkCoverage 复核后**不需要改**:covAt 在发枪前打戳、covWait 赋值在
          alias 检查之后,不存在陈旧写入。
     index.html bump ?v=5.0.5。
   ═══════════════════════════════════════════════════════════════ */
'use strict';

/* ───────── 常量 ───────── */
const T = { ROUND: 50001, CAST: 35000, DRAW: 40000, END: 50000 };   // 2.9.1:ROUND=真实步进 50001(项目 B ROUND_STEP,相邻局 round_id 实测差),CAST/DRAW/END 为局内偏移
/* 3.8.0:localStorage 键分两类 ——
   · 设备级(布局/列宽/游戏坞几何等纯显示偏好):键名不变,跨账号共享;
   · 用户级(当前房/快照/自添名录/模拟钱包与法术记录):登录后追加 @u<id> 后缀
     (KEY_NS 由 authInit 在**任何用户级键读写之前**设定),同设备多账号互不串档。
   getter 动态取名 → 全部既有调用点(KEY.snap + alias 等)零改动。未启用登录时
   KEY_NS.v === '',键名与旧版逐字节一致。 */
const KEY_NS = { v: '' };
const KEY = { layout:'jf2:layout', cols:'jf2:cols', rgCols:'jf2:rgCols', wideCols:'jf2:wideCols', aideSize:'jf2:aideSize',
              rgSize:'jf2:rgSize',   /* 5.0.9:DIY 盘「常规/加高」档(设备级,与 aideSize 同规不带用户命名空间) */
              jiufaOpen:'jf2:jiufaOpen',
              gameTab:'jf2:gameTab', rgSkin:'jf2:rgSkin',
              get room(){ return 'jf2:room' + KEY_NS.v; },
              get snap(){ return 'jf2:snap' + KEY_NS.v + ':'; },
              get snapIdx(){ return 'jf2:snapIdx' + KEY_NS.v; },
              get myRooms(){ return 'jf2:myRooms' + KEY_NS.v; },
              get simWallet(){ return 'jf2:simWallet' + KEY_NS.v; },
              get simBets(){ return 'jf2:simBets' + KEY_NS.v; },
              /* 4.2.2:本机「有一笔在途订单尚未确认到账」的标记。用途见 payRecover ——
                 它让对账兜底只在**确实有单**时才发一次请求:从不充值的用户零成本,
                 free 档的「零数据请求」纪律也因此逐字节不变。 */
              get payPend(){ return 'jf2:payPend' + KEY_NS.v; },
              /* 4.3.3:首入 basic 档一次性说明已弹过的标记(按用户,永不复弹) */
              get jfIntro(){ return 'jf2:jfIntro' + KEY_NS.v; },
              /* 4.4.0:本机上一次落地的档位。掉档(vip→basic)是唯一真实的绕过
                 向量 —— 昨天以 VIP 身份存的满窗历史,今天不能以 basic 身份回灌。
                 快照自身也带 tier 戳(双保险:这里漏判,hydrate 仍会拒)。 */
              get jfTier(){ return 'jf2:jfTier' + KEY_NS.v; },
              /* 4.8.0:「各房各出各的怪」一次性说明已弹过的标记(按用户,永不复弹) */
              get roomIntro(){ return 'jf2:roomIntro' + KEY_NS.v; },
              /* 5.0.3:「可以添加更多直播间」新手引导的消解标记(按用户)。落键即永不再见 ——
                 两条路径:① 名录达 ≥2 房(用户已用行动学会,syncNudge 自动落);② 引导条 × 显式关闭。
                 空名录的引导(空态卡/自动弹层/5.0.2 空引导卡)**不受**本键约束:名录空时无事可做,
                 引导就是内容本身;本键只管「单房还看不出能多房」这一态。 */
              get addNudge(){ return 'jf2:addNudge' + KEY_NS.v; } };
/* 4.4.0 快照格式 v3(**破坏性升版,v2 一律作废重取**):
   v2 存整对象数组,1728 局实测 646 KB(UTF-16);而 beast/mult/spell_* 全部可由
   display_number 经 S.spells 反查、时间是 50001ms 等差格点 —— 真正不可推导的
   只有「起点 + 号位」两列。v3 存 {b: 基准起点, r: "号位串"},缺局占位 '0',
   同样 1728 局实测 **~3 KB**,6 房 LRU 合计 ~18 KB(v2 满窗需 3.9 MB,逼近
   localStorage 5 MB 上限 —— basic 档满窗留存在 v2 格式下根本放不下)。
   注:缺局的占位字符 '0' 同时就是断口标记 —— 序列的「此处未观测」与快照的
   体积优化,是同一个表示法的两面。 */
const SNAP_V = 3;
const HISTORY_LIMIT = 1800;
const HIST_CAP      = 2200;
/* 3.8.2 时间窗钉真:S.hist 恒被修剪到「最新一局起点 − 24h」的锚定窗内(pruneHistWindow,
   ingest / applyRoomData 双入口)。此前口径是**局数窗**(≤HIST_CAP),仅在
   retention=1 且主播近乎全天直播时才恰好 ≈24h —— retention>1 或低在线率主播的
   最近 1800 局可跨多天,序列/战况/出怪规律/聚光各处的「24h」标注全部失真
   (实测注入 3 天前数据:标签仍称"近 24 小时",样本实跨 72h)。
   锚定最新局而非墙钟:断流期间窗口不缩(盘面不因下播而慢慢清空),
   直播中两者相差 ≤1 局;HIST_CAP 退居极端兜底(24h 满打 ≈1729 局,常态摸不到)。 */
const HIST_WINDOW_MS = 86400000;
/* 3.9.5 名录速览失联阈值(railChip)——
   · 实时房(mode:realtime):>10 分钟无成功抓取才判『断』。MainPage 每局一拍
     (~50s)+ 失败退避 60s 封顶,10 分钟 ≈ 连败 8+ 拍,足以排除抖动误报;
   · 闲置房(mode:idle,curated-idle 低频采集):阈值 = 2×轮询周期 + 2 分钟余量,
     周期由后端 live-rooms 顶层 histIntervalS 下发(生效值,含服务端钳制),
     旧后端无此字段时取缺省 2×900s+120s —— 连丢两拍才算真失联,单拍失败自身
     的退避链(90→300s)仍在阈内自愈,不闪报。 */
const RAIL_LIVE_STALE_MS  = 600000;
const RAIL_IDLE_STALE_DEF = 1920000;
/* 3.3.0 完整性自愈:近 COVERAGE_WINDOW 局若已完整则**不拉 history**。
   增量 pollNew 只拉「比最新更新的」,从不回头补中间缺口 —— 网络抖动漏抓一局就永远缺。
   这里按 50001 格点检查近 30 局:
     · 本地齐(或缺的正是官方本身缺失的)→ 完整,零 history
     · 有本项目漏抓的格点 → 拉一次 history 补齐
     · 缺口 ∈ 官方缺失 → 记住,不再为它反复拉
   触发:仅在「新局落地」时查一次(低频、事件驱动),不额外起定时器。 */
const COVERAGE_WINDOW = 30;
const COVERAGE_COOLDOWN_MS = 15000;   // 两次 coverage 检查的最小间隔(防抖起点)
/* 5.0.4:连查而补不到时逐次翻倍到 5 分钟。后端哨兵在 2~4 局内必给定案(入库
   或登记「官方缺失」),这段窗口里旧实现每局固定两枪(coverage + history);
   洞若一直判不了,25 分钟内最多空打 60 次。补到 / 后端判定完整即复位 ——
   常态(首枪即补到)行为逐字节不变。 */
const COVERAGE_COOLDOWN_MAX_MS = 300000;
/* 5.0.4:头部断层定向补齐(见 resyncGap 长注)的预算与节流 */
/* 同一段断层最多补 4 次(尝试落在第 0/1/2/3 局);网络失败不计数。
   为什么是 4 不是 3:后端覆盖哨兵 COV_AUDIT_LAG_ROUNDS=2 + 5s 冷却 ⇒ 定案窗口 2~4 局,
   3 次的尾巴(第 2 局)正好压在它的最坏情况上,会「差一局放弃」。 */
const GAP_RESYNC_TRY_MAX  = 4;
const GAP_RESYNC_COOLDOWN_MS = 8000;  // 两次补齐之间的最小间隔(一局 50s,实际每局至多一枪)
const ROAD_MAX      = 1800;     // 序列展示局数上限 = HISTORY_LIMIT(≈24h);双模统一,容器内纵向滚动看全
const ROAD_COL_OPTIONS = [10, 20, 22, 24, 30, 36, 72];   // 每行珠数档位(双模共用)
const ROAD_COLS_DEF    = 36;                              // 桌面默认档;窄屏首访自适应(见 S.cols)
const TREND_N       = 100;      // 纵览模式战况局数
const PRED_EVAL     = 20;       // 灵机推演:命中统计窗口(局)
const PRED_REPLAY   = 40;       // 灵机推演:加载时按同口径回放的局数
/* ═══ 3.2.0 自适应拉取(取代 8s 定频轮询)═══
   旧:setInterval(pollNew, 8000) —— 一局(50.001s)打 7 次 /history + 7 次 /prediction,
   其中至多 1 次有新数据;且完全不看 SSE 是否连着。
   新:只在「本局结果按理已该存在、但本地还没有」时才拉,拉到为止;
       用单调钟做保险丝兜住系统时间跳变这唯一能让判据永远为假的情形。

   S.lagMs        「备战后多久数据可取」的估计,自学习(AIMD,见 learnLag)。
                  (3.3.1:锚点由出怪改备战 —— 后端 award 抓取在备战+1.5s,数据备战后 ~2s 入库。)
                  初值取项目 B 的经验值;不同部署的入库节奏不同,写死会每局白拉几枪。
   SSE_GRACE_MS   SSE 在线时再多等一会儿 —— 它会零请求把这一局推过来,
                  等到了就一次 /history 都不用发。
   CHASE_*        追赶退避。封顶 8000 = 旧的 POLL_MS,保证任何时刻
                  「数据已就绪却还没取」的等待都不劣于改造前。
   STALE_FUSE_MS  保险丝:距上次真实数据到达超过它就无条件拉一次。
                  必须用 performance.now()(单调钟)计时 —— 系统时间被 NTP
                  校正/休眠唤醒往回跳时,墙钟差值会变负,保险丝会永不熔断。 */
const INGEST_LAG_MS = 2600;     // S.lagMs 初值(备战后约 2.6s 数据可取:后端备战+1.5s 抓 + 入库)
const LAG_MIN_MS    = 1200;     // 再快也不可能早于此
const LAG_MAX_MS    = 9000;     // 备战后最多 9s(备战35s+9s=44s < 结束50s);超过就滑进下一局
const LAG_PROBE_MS  = 200;      // 首枪即中 → 往前探(加性递减)
const LAG_MARGIN_MS = 250;      // 需退避才中 → 退到「命中偏移 + 余量」
const SSE_GRACE_MS  = 600;      // SSE 推送到达 ≈ 入库时刻 + 网络(~200ms);留 ~650ms 边际即可
const SSE_SILENT_MS = 45000;    // 3.3.9 SSE 活性窗:后端心跳 20s,静默 >2 个心跳+余量 = 半开/假活
                                // (onerror 只覆盖显式断开;代理挂死时连接"看似 live"却无事件)
                                // 给太宽(试过 1200ms)只会让「SSE 静默」这种阴险故障多晚 1 秒才追上
const CHASE_MIN_MS  = 1200;
const CHASE_MAX_MS  = 8000;
const CHASE_GROW    = 1.6;
const STALE_FUSE_MS = 70000;    // ≈1.4 局:健康链路(SSE 或追赶)每 50s 必有数据,永不熔断
const STALE_MS      = 120000;

/* 3.1.1 容量闸(前端):名录直播间 ≤ 50、账号库 ≤ 10。
   · 账号 10:后端 AccountStore.MAX_ACCOUNTS 本就硬限(upsert 新增分支直接拒),
     但那是**扫完码之后**才报错。前端同值闸把话提前说清楚,不让人白扫一次码。
   · 直播间 50:后端无同名限制,这是纯前端闸 —— 直接打 /api/monitor/add 仍可越界。
   触顶后「＋ 添加…」入口不再放行;已在库的房间仍可正常搜索/切换/删除。 */
const MAX_ROOMS     = 50;
const MAX_ACCOUNTS  = 10;   // 必须与 backend_async/app/accounts/accounts_backend.py 的 AccountStore.MAX_ACCOUNTS 同值

const ELEM = { 1:'土',2:'木',3:'火',4:'剑',5:'器',6:'金',7:'道',8:'丹',9:'水' };

/* 战况(legacy 竖排表格):行高与展示局数 */
const TREND_ROW_STACK   = 28;   // 纵览行高(2.6:26→28,给命中圆珠留呼吸位,珠径/字号随 --trh 推导)
const TREND_ROW_COCKPIT = 24;   // 驾驶舱行高(2.6:22→24,同上;战况容器内滚动,行高抬升不挤版)
const TREND_ROWS        = 1800; // 战况展示局数 = 24h(驾驶舱/纵览一致,容器内滚动;有增量渲染,不整页重画)
/* 战况侧区(大小单双)属性表:列键 → [汉字, 判定];准星列检测与悬浮卡未出场共用 */
const TREND_SIDE_META = { big:['大', x=>x>=5], small:['小', x=>x<5], odd:['单', x=>x%2===1], even:['双', x=>x%2===0] };

/* ───────── 工具 ───────── */
const $  = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => [...r.querySelectorAll(s)];
const pad2 = n => String(n).padStart(2, '0');
const clampN = (lo, v, hi) => Math.max(lo, Math.min(hi, v));
/* —— 时区:整项目统一北京时间(UTC+8,无夏令时)。所有时钟/日界换算钉死 +8,
      不随浏览器时区漂移(海外访问同样显示北京时间,期号不串日)。 —— */
const BJ_OFFSET_MS = 8 * 3600 * 1000;
const bjMidnightOf = ms => { const t = Number(ms) + BJ_OFFSET_MS; return t - (t % 86400000) - BJ_OFFSET_MS; };
const fmtClock = ms => { const d=new Date(Number(ms) + BJ_OFFSET_MS); return `${pad2(d.getUTCHours())}:${pad2(d.getUTCMinutes())}:${pad2(d.getUTCSeconds())}`; };
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
/* 北京时间今日 00:00(毫秒)。3.8.2:改用校准钟 nowC —— 「今日」列比对的是
   服务端局起点,日界却曾取裸 Date.now():客户端钟偏跨零点时今日计数整段错标。
   按日回看处早已为同一原因钉 nowC(见 wvDayLabel 注"免客户端钟漂标错"),此处对齐。
   (nowC 声明在后,箭头函数调用期求值 —— midnight 仅在 boot 后的渲染路径被调,安全。) */
const midnight = () => bjMidnightOf(nowC());
const sleep = ms => new Promise(r => setTimeout(r, ms));
const normDigits = s => String(s||'').replace(/[０-９]/g, c => String.fromCharCode(c.charCodeAt(0)-0xFEE0)).trim();

/* 本地存储安全层(2.6.3):隐私模式 / 企业策略 /「阻止站点数据」下,访问
   localStorage 本身就会抛 SecurityError —— 此前模块顶层的 S.cols 裸读会让
   整个应用在启动瞬间崩死成白屏。全站读写一律走此层:存储不可用时静默降级为
   "仅本次会话"(档位/布局/名录不持久,页面照常可用),可用时行为与原先逐字节一致。 */
const store = {
  get(k){ try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v){ try { localStorage.setItem(k, v); return true; } catch { return false; } },
  remove(k){ try { localStorage.removeItem(k); } catch {} },
};

/* ═══════════ 提示管线(4.9.0 重构:单元素 · 单计时器 · **带优先级的排队**)═══════
   3.9.4 已把「双计时器互掐」修掉,但留下了更根本的一条:**后到者无条件覆盖先到者**。
   在 jsdom 真 DOM 上实测(backend_async/scripts/toast_contention_probe.js)确证三处
   实伤,都不是理论推演:

     ① **动作型提示被信息型提示静默抢占**。toastAction 承诺展示 8000ms 的「切回 <原房>」
        「去续费」「开通VIP」等 CTA,只要期间任何一处 toast() 落下,`el.textContent = msg`
        就把按钮**连节点一起抹掉**,且无任何补救入口 —— 动作**永久丢失**。最讽刺的一例:
        跟随目标加载失败时 loadRoom 的失败分支会打普通 toast,而「切回」恰恰是那一刻
        用户最需要的按钮。
     ② **一次性提示会被永久吞掉**。jfIntro / roomIntro 是「先 store.set('已看过')、
        再 toastAction」的写法,若那一瞬被覆盖,用户**一次都没看见**却永不再弹。
        原有的 S._bootToast 护栏只挡住 jfIntro↔roomIntro 一对,管不了 vipExpiryNudge
        (它在同一个 dataBoot 里、同步执行)与任何网络失败提示。
     ③ **连续提示无到达线索**。.toast 的 rise 动画绑在元素上,只在 hidden 翻转时触发;
        已显示态下换文案不闪不动,用户直接错过。

   新管线的规则(刻意保持最小惊奇,不引入叠层 UI):
     · 单元素 #toast、单计时器 —— 与既有语义一致,不做多气泡堆叠;
     · **动作型(带 label+onClick)在其承诺时长内不可被抢占**,后来者排队;
     · 信息型之间仍是「后到覆盖先到」(队列里只保留最后一条,零行为变化);
     · 队列封顶,且同文案自动去重,不会堆积成弹幕;
     · 每次出场强制走一次 hidden→显示,让 rise 动画重放(真实浏览器里额外读一次
       offsetWidth 触发回流,jsdom 无布局时该读取无副作用);
     · 点击动作按钮 = 立即消费本条并播下一条。
   toast() / toastAction() 的**签名与既有语义保持不变**,全站 95 处调用点零改动;
   opt 新增可选 onShown —— 供「一次性提示」在**确实出场后**才落"已看过"。 */
const TOAST_Q_MAX = 3;
const TQ = { timer: 0, cur: null, q: [] };
function _toastEl(){ return $('#toast'); }
function _toastPaint(it){
  const el = _toastEl();
  if (!el) return;
  clearTimeout(TQ.timer);
  /* 4.9.2 无障碍修正:#toast 带 role=status + aria-live=polite,是一块**活动区域**。
     4.9.0 我为了重放 rise 动画,写成「每次都先 hidden=true 再改文本再 hidden=false」——
     那正好踩中活动区域的头号反模式:hidden 会让元素落到 display:none、**被移出无障碍树**,
     而被移出的活动区域不会被播报;更不该把「改 display」与「改内容」放在同一拍里。
     后果是**连续提示对读屏用户整条静默**(原代码在已可见时是直接改文本的,能播报;
     是我把所有情况都拖进了隐藏循环)。
     现在分两条路,两边都拿到动画且都不动无障碍树:
       · 元素本来就可见 → **不碰 hidden**,用 `animation:none` + 强制回流 + 还原 的
         规范手法就地重启动画(CSS Animations 的标准重启法,不涉及 display);
       · 元素本来是隐藏的 → 照旧 hidden=false(display:none→非 none 时,规范明文规定
         会重新启动该元素上的全部动画,无需额外处理)。 */
  const wasHidden = el.hidden;
  el.textContent = '';
  if (!wasHidden){
    try { el.style.animation = 'none'; void el.offsetWidth; el.style.animation = ''; } catch {}
  }
  el.appendChild(document.createTextNode(it.msg));
  if (it.label && typeof it.onClick === 'function'){
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'toast-act'; b.textContent = it.label;
    b.onclick = () => { const f = it.onClick; _toastNext(); try { f(); } catch {} };
    el.appendChild(b);
  }
  if (wasHidden) el.hidden = false;      // 隐藏→显示这一步本身就会重启动画(规范保证)
  TQ.cur = it; it.shownAt = Date.now();
  if (typeof it.onShown === 'function'){ try { it.onShown(); } catch {} }
  TQ.timer = setTimeout(_toastNext, it.ms);
}
function _toastNext(){
  clearTimeout(TQ.timer);
  TQ.cur = null;
  const nx = TQ.q.shift();
  if (nx) return void _toastPaint(nx);
  const el = _toastEl();
  if (el) el.hidden = true;
}
function _toastPush(it){
  const el = _toastEl();
  if (!el) return;                        // 裸宿主(无 #toast):交由 jfToast 的兜底分支
  // 当前是**未过期的动作型**提示 → 不抢占,排队。其余情况直接出场。
  const busy = TQ.cur && TQ.cur.act && (Date.now() - TQ.cur.shownAt) < TQ.cur.ms;
  if (!busy) return void _toastPaint(it);
  if (TQ.q.some(x => x.msg === it.msg && x.label === it.label)) return;   // 同文案去重
  if (!it.act){
    const i = TQ.q.findIndex(x => !x.act);
    if (i >= 0){ TQ.q[i] = it; return; }  // 信息型之间维持「后到覆盖先到」
  }
  TQ.q.push(it);
  while (TQ.q.length > TOAST_Q_MAX){      // 封顶:优先丢弃最老的信息型,动作型最后才丢
    const i = TQ.q.findIndex(x => !x.act);
    TQ.q.splice(i >= 0 ? i : 0, 1);
  }
}
function toast(msg){
  _toastPush({ msg: String(msg), ms: 2400, act: false });
}
/* 3.9.4:带动作按钮的 toast(跟随提示「切回」用)。ms 可加长:可操作提示 2.4s 点不到。
   4.9.0:带 label+onClick 时视为**动作型**,在承诺时长内不被信息型抢占(见上)。 */
function toastAction(msg, opt = {}){
  const act = !!(opt.label && typeof opt.onClick === 'function');
  _toastPush({ msg: String(msg), ms: opt.ms || 2400, act,
               label: opt.label, onClick: opt.onClick, onShown: opt.onShown });
}

/* ───────── 全局状态 ───────── */
const S = {
  rooms: [],
  alias: '',
  profile: null,
  spells: [], spellByN: {},
  hist: [], ids: new Set(),
  anchor: 0,
  cols: (() => {                                           // 每行珠数(双模共用)
    const v = Number(store.get(KEY.cols));
    if (ROAD_COL_OPTIONS.includes(v)) return v;            // 用户显式选过:尊重并持久
    // 首次默认按屏宽自适应:窄屏 36 位会把珠压到 ~6px、数字不可读,
    // 手机给 10、平板 20、桌面 36;之后任何一处改档仍三处同步并持久化
    return innerWidth < 560 ? 10 : innerWidth < 900 ? 20 : ROAD_COLS_DEF;
  })(),
  /* 4.7.6:全屏序列的每行位数 —— 与观测台面板的 S.cols **解耦**。
     病灶:两者共用一个 jf2:cols,而两个容器实宽差 3～4 倍(实测桌面 972 / 1384,
     手机 330 / 362 且面板还要再让出 rail)。共用一档必然一边对一边错 ——
     用户在全屏里选 72 位,回到面板就变成珠径 11.5px / 字号 7.1px 的糊盘。
     0 = 用户从未在全屏里亲手改过档 → 渲染时按容器实宽取「舒适上限」(见 wideColsFor)。 */
  wideCols: (() => { const v = Number(store.get(KEY.wideCols)); return ROAD_COL_OPTIONS.includes(v) ? v : 0; })(),
  /* 灵机推演:项目 B 集成预测(后端提供)。
     why = 引擎自解释(explore.why)。4.9.6 起**不再渲染**(原 #predWhy 已移除,
     理由与实测见 index.html 推演卡页脚处注释),但**刻意保留**这个字段:
       · 它是浏览器侧唯一能拿到引擎自述的地方,排障时 JiufaDev.S.pred.why
         直接可读,不必抓包 /prediction;
       · 后端契约未动,将来若在管理台/回放侧展示,前端已在手。
     故它不是漏删的死代码 —— 请勿"顺手清理";同样,它有值也**不代表**该把
     #predWhy 加回卡面(那条路的几何冲突尚未解决)。 */
  pred: { main: [], guard: [], nextStart: 0, record: [], ens: [], accuracy: null, why: '' },
  hl: new Set(),           // 3.4.4 号位聚光:被点亮的号位集合(可多选;换房即清,不持久)
  es: null, tickId: 0, sseRetry: 0, sseRetryT: 0, leaseBusyPending: false, roomBusyT: 0,
  sse: 'idle',             // 连接态镜像(setConn 单点维护):'live'|'poll'|'off'|'idle'
  sseSeenPerf: 0,          // 3.3.9 最近一次收到任意 SSE 事件(单调钟)—— sseAlive() 活性判据用
  pollBackoff: 0,          // 追赶退避(ms);追平即清零
  nextPollAt: 0,           // 下次允许发 /history 的时刻(校准钟)
  behind: false,           // 上一拍的「本地落后于应有进度」判定,用于识别状态翻转
  pollBusy: false,         // /history 在飞:防重叠
  lastDataPerf: 0,         // 最近一次真实数据到达(**单调钟**,保险丝专用)
  lastMonoProbe: 0,        // 3.4.3 SSE 死时单调钟兜底轮询的上次发枪时刻(节流用)
  wallRef: 0,              // Date.now() - performance.now() 的参考值,用于探测系统钟跳变
  lagMs: INGEST_LAG_MS,    // 学到的「出怪后多久数据可取」;AIMD 调节,见 learnLag()
  covAt: 0,                // 上次 coverage 检查时刻(墙钟,防抖)
  covBusy: false,          // coverage 检查在飞
  covWait: COVERAGE_COOLDOWN_MS,   // 5.0.4:当前 coverage 防抖间隔(补不到就翻倍,补到即复位)
  offMissing: new Set(),   // 已知「官方本身缺失」的格点(本会话内记住,不再为它拉 history)
  gapSpan: null,           // 5.0.4:待补齐的断层 {from:断层前最后一局起点, to:断层后第一局起点}
  gapDead: new Set(),      // 5.0.4:补满预算仍取不到的**格点**(与 offMissing 同构;本会话内记住,不再纠缠)
  gapTry: new Map(),       // 5.0.5:格点 → 已补齐次数(只在「拉到了但仍缺」时计数;满额进 gapDead)
  gapBusy: false,          // 5.0.4:断层补齐在飞
  gapAt: 0,                // 5.0.4:上次断层补齐时刻(墙钟,节流)
  snapSeed: null,          // 4.4.0:本机回灌的历史种子,待 loadRoom 落地后并回(消费恰一次)
  predChaseT: 0,           // 预测补拉定时器
  predSettleMs: 1500,      // 学到的「后端结算滞后」估计(EMA);首局用保守初值
  loadSeq: 0,
  L: null,                 // 布局引擎输出
  clockOffset: 0,          // serverNowMs 校时 (EMA)
  lastDataTs: Date.now(),  // 最近一次真实数据到达(墙钟)
  offline: false,
  trendCtx: null,          // 驾驶舱战况交互上下文
  trendWin: null,          // 3.3.1 战况虚拟化:当前已渲染的行区间 {start,end}
  input: '',               // 4.9.4 最后一次输入方式:'touch'|'mouse'(initInputBus 单点维护)
  trendTapId: '',          // 4.9.4 触屏当前展开的战况行 id(再点同行 = 收卡)
  trendTipT: 0,            // 4.9.4 触屏战况卡自动收起定时器
  hoverT: 0, leaveT: 0, hoverOpen: false,
  jiufa: false,            // 游戏停靠面板开合(真实/模拟共用同一停靠槽)
  roomsReady: false,       // 房名录首拉是否已返回(未返回前 alias 为空属开机窗口,盘面显示载入而非「选直播间」)
  roomsFetchedAt: 0,       // 3.9.5:名录快照落地时刻(校准钟)—— 速览失联判据的时间基准(见 railChip 注)
  histStaleMs: RAIL_IDLE_STALE_DEF,   // 3.9.5:idle 房失联阈(2×后端 histIntervalS + 余量;旧后端取缺省)
  roomWakeT: 0,            // 3.9.5:切房后名录补拉定时器(冷房唤醒 → 角标秒级跟上)
  roomRetryT: 0, roomRetryN: 0,   // 4.1.1:首装零基线死端自愈 —— 退避重试定时器/步进(见 loadRoom 尾注)
  gameTab: 'real',         // 停靠面板当前模式:real=真实游戏(默认) / sim=模拟游戏
  rgSkin: 'diy',           // 界面风格:diy=玉青纸墨(默认) / official=官方风(真实=自绘深色金调皮肤;模拟=原版官方 iframe)
};
const nowC = () => Date.now() + S.clockOffset;   // 校准时钟
/* 当日期号:以该局所在自然日(**北京时间**)第一局为 00001,逐局 +1。
   纯由局起点毫秒推算(全体局起点构成步进 50001 的等差格点):
   期号 = floor((局起点 − 北京当日零点) / 50001) + 1 —— 与是否抓到中间某局无关,缺局不串号。 */
function dayNo(startMs){
  const t = Number(startMs) || 0; if (!t) return '—';
  const mid = bjMidnightOf(t);
  return String(Math.floor((t - mid) / ((typeof T !== 'undefined' && T.ROUND) || 50001)) + 1).padStart(5, '0');
}

/* 模拟游戏共享桥(2.8.0):iframe 内 sim-engine 经 window.parent.JiufaShared
   实时读取当前观测房号 —— 观测台切主播,模拟游戏自下一局起自动同房。 */
window.JiufaShared = {
  get alias(){ return S.alias || String(S.rooms[0]?.alias || ''); },
  get nickname(){ return S.profile?.nickname || S.alias || ''; },
};

/* ── 真实数据版共享回合引擎(2.9.3) ──────────────────────────────
   模拟游戏 iframe 经 window.parent.RoundEngine 直读观测台「当前所选主播房」
   的同一份真实数据:回合时钟 = S.anchor(项目 B MainPage 权威计时),出怪
   实录 = S.hist(项目 B 抓取入库),法术表 = S.spells(后端九法配置)。由此
   模拟游戏的盘面倒计时、每一局开出的妖兽与左侧序列/战况逐局恒等,并随名录
   切换主播自动同房(JiufaShared.alias 实时读 S.alias;进行中一局按布法时
   房间结算)。接口面与 2.8.x assets/round-engine.js 对齐(sim-engine 消费的
   子集):T / spells / spellByBeast / data.liveRooms.rooms / liveTimer /
   advance / resultFor。行为差异仅一点:真实结果未捕获时 resultFor 返回
   null(绝不臆造出怪),sim-engine 2.9.3 相应改为「暂缓结算、稍后重询」。 */
const JFX = { rounds: new Map(), busy: new Set(), miss: new Map() };   // 跨房结果缓存:alias → Map(start → {bid,beast});miss = 取不到时的退避/判死台账
const JFX_MISS_TRY_MAX = 5;                           // 同一局连取 5 次仍无 → 判定不可得,不再纠缠
function jfSpellsReal(){
  return S.spells.map(sp => Object.assign({}, sp, { p: (parseFloat(sp.probability) || 0) / 100 }));
}
function jfSpellByNum(n){ return S.spells.find(s => Number(s.display_number) === Number(n)); }
function jfContractRound(r){                          // 观测台内部回合 → 引擎契约字段
  const sp = jfSpellByNum(r.n) || {};
  return {
    round_id: r.id, beast_id: sp.beast_id ?? -1, beast_name: r.beast || sp.beast_name || '',
    spell_key: r.key, spell_name: r.name,
    display_number: r.n, multiplier: r.mult,
    start_time_ms: r.start, spell_time_ms: r.start + T.CAST,
    draw_time_ms: r.draw, end_time_ms: r.start + T.END,
    source: 'GameHistory', captured_at: '',
  };
}
/* ── 5.0.5:跨房补拉某局(passive=1:只读,不拉起监控)─────────────────────────
   ★ 旧写法 `since=startMs&limit=3` 是 5.0.4 那条 DESC+LIMIT 坑的**同族**:
     db.history 是 `round_id >= since ORDER BY round_id DESC LIMIT n`,固定 3 只
     取回「≥since 的最新 3 局」—— 目标局比该房最新局早 3 局以上就**永远拿不回来**。
     后果是实打实的:sim-engine 的 aE() 结算路走 RoundEngine.resultFor,拿不到就
     返回 null,那笔挂单永远结算不了;而 handle() 每次调用都会重扫 bets 再催一次,
     JFX.busy 只挡并发不挡重复 ⇒ 持续空拉。
     (sim-engine.js 是混淆产物,'resultFo'+'r' 经 RC4 解码,普通 grep 抓不到 ——
      别再据 grep 结果判定「无人调用」。)
   ★ 取法:VIP 走半开区间 until 精确取那一局(1 行;且 until ≤ now−1h 时后端发
     immutable,同一局的重复查询由浏览器缓存兜住)。basic 不许用 until(403),
     退回按格点距离给足 limit —— 后端仍钳到 jf_basic_history_limit,不构成绕过。
   ★ 止损:取不到就指数退避(2/4/8/16/32s,封顶 60s),连 JFX_MISS_TRY_MAX 次
     无果即判死不再打;取到即清账。 */
function jfFetchCross(alias, startMs){
  const key = alias + '@' + startMs;
  if (JFX.busy.has(key)) return;
  const st = JFX.miss.get(key);
  if (st && (st.n < 0 || Date.now() < st.at)) return;   // 已判死 / 退避中
  JFX.busy.add(key);
  const s = Number(startMs);
  const q = isVip()
    ? `since=${s}&until=${s + 1}&limit=3`
    : `since=${s}&limit=${clampN(3, Math.round((nowC() - s) / T.ROUND) + 3, HISTORY_LIMIT)}`;
  api(`/api/rooms/${encodeURIComponent(alias)}/history?${q}&passive=1`)
    .then(d => {
      let m = JFX.rounds.get(alias);
      if (!m){ m = new Map(); JFX.rounds.set(alias, m); }
      (d.rounds || []).forEach(raw => {
        const rr = normRound(raw);
        const sp = jfSpellByNum(rr.n);
        m.set(rr.start, { bid: raw.beast_id ?? (sp ? sp.beast_id : -1), beast: rr.beast });
      });
      if (m.has(s)) JFX.miss.delete(key);
      else {
        const n = ((st && st.n) || 0) + 1;
        JFX.miss.set(key, n >= JFX_MISS_TRY_MAX ? { n: -1, at: 0 }
                    : { n, at: Date.now() + Math.min(60000, 2000 * Math.pow(2, n - 1)) });
      }
    })
    /* ★ 失败同样要压节奏:403(档位不符/旧后端)、500、超时都会走这里,而
       sim-engine 的 handle() 每次都会重扫 bets 再催一次 —— 不设退避就是按 RTT
       持续重打。与 resyncGap 同一纪律:失败**不消耗**判死预算,只压节奏。 */
    .catch(() => {
      JFX.miss.set(key, { n: (st && st.n > 0) ? st.n : 0, at: Date.now() + 5000 });
    })
    .finally(() => JFX.busy.delete(key));
}
/* 2.9.16-real:立即拉数钩子 —— 模拟游戏 sim-engine 在"等实录结算"的窗口
   (出怪后至多 6.5s)内调用,催观测台马上 pollNew 一次(节流 1.2s)。
   3.2.0:加 isBehind() 守卫。sim-engine 常在出怪后 0.5s 就催,那时后端还没入库
   (INGEST_LAG_MS),拉了必空。落后时才发;不落后就把这一拍让给 schedulePolls,
   它会在门槛到点时自己去拉。节流戳照常更新,避免落后期间被它反复催。
   pollNew 为函数声明,提升后此处可安全引用;其内部自带 try/catch,不会向
   本 fire-and-forget 调用抛出未处理拒绝。 */
let _pullNowAt = 0;
function jfPullNow(){
  const n = Date.now();
  if (n - _pullNowAt < 1200) return;
  _pullNowAt = n;
  if (!isBehind()) return;                 // 数据尚不可取 / 已是最新 → 不白发
  try { pollNew(); } catch {}
}
window.RoundEngine = {
  version: '3.1.0-real',   // 3.1.0: 统一北京时间 + 默认7天保留
  pullNow: jfPullNow,
  // 2.9.4:引擎钟(服务器校准)。模拟游戏(sim-engine)一切时刻判断都取
  // 这里,而不是 iframe 自己的 Date.now() —— 引擎给出的 spellTime/drawTime/
  // endTime 全是服务器纪元,若拿本机钟去比对,本机快 40s 以上(双系统 UTC
  // 错乱/虚拟机漂移/长期未校时)时游戏一进场就"已过 endTime",永久停在
  // 「妖兽即将到来」。时刻与坐标必须同源,才能保证倒计时横幅正确。
  nowMs(){ return nowC(); },
  T: Object.assign({ REVEAL: 2800 }, T),              // REVEAL≈项目 B 出怪后捕获时延实测值
  data: { liveRooms: { get rooms(){ return S.rooms; } } },
  get spells(){ return jfSpellsReal(); },
  get spellByBeast(){
    const m = {}; for (const sp of jfSpellsReal()) m[sp.beast_id] = sp; return m;
  },
  liveTimer(alias){
    const cur = String(alias) === S.alias && S.anchor;
    const start = cur ? curStart(nowC()) : nowC();    // 非当前房仅作「历史局」上界判定 → 给保守值
    return { currentRoundId: String(start), serverOffsetMs: Math.round(S.clockOffset),
             roundStartTimeMs: start, spellTimeMs: start + T.CAST,
             drawTimeMs: start + T.DRAW, endTimeMs: start + T.END };
  },
  advance(alias){                                     // GameHistory 回放:观测台已知实录(升序)
    const rounds = String(alias) === S.alias
      ? S.hist.slice().reverse().map(jfContractRound) : [];
    return { alias: String(alias), rounds };
  },
  resultFor(alias, startMs){
    alias = String(alias); startMs = Number(startMs);
    let bid = null, beast = '';
    if (alias === S.alias){
      const hit = S.hist.find(r => r.start === startMs);
      if (hit){ const sp = jfSpellByNum(hit.n); bid = sp ? sp.beast_id : -1; beast = hit.beast; }
    }
    if (bid == null){
      const c = JFX.rounds.get(alias)?.get(startMs);
      if (c){ bid = c.bid; beast = c.beast; }
    }
    if (bid == null){                                 // 真实结果尚未捕获/不在手:异步补拉,本轮不结算
      jfFetchCross(alias, startMs);
      return null;
    }
    return this.spellByBeast[bid]
        || { beast_id: bid, beast_name: beast, spell_key: '', spell_name: '',
             display_number: 0, multiplier: 0, probability: '0%', p: 0 };
  },
};

/* 调试/测试钩子(与 iframe 内 JiufaSim 同一惯例):控制台可读写内部态,
   便于演练引导层/自愈/结算等分支。业务代码不得依赖它。 */
window.JiufaDev = { get S(){ return S; }, get RG(){ return (typeof RG !== 'undefined') ? RG : null; } };

/* ───────── DOM 引用 ───────── */
const D = {};
function cacheDom(){
  const ids = ['rail','railVeil','railOpen','railClose','roomSearch','roomSearchGo','railCount','roomList',
    'anchorIdentity','anchorAvatar','anchorName','anchorAlias','connState',
    'topClock','staleBadge','layoutToggle',
    'liveRing','ringSeconds','ringPhase','roundNo','roundClock','phaseFill','phaseHint',
    'resultSeal','resultGlyph','resultNum','resultName','resultInfo',
    'spellBoard','roadCols','roadExpand','roadWrap','roadGrid','roadSpot',
    'roadSub','trendSub','wideTitle',                    // 4.8.0 房间归属标注位
    'wideView','wideBack','wideGrid','wideCount','wideCols','wideSpot',
    'wideNav','wvPrev','wvNext','wvDay','wvLiveBtn','wvCensus','roadReplay',
    'predictCard','predRound','predMain','predGuard','predVerdict','predStats',
    'predGap',                                           // 4.9.3 窗口缺口注脚
    'streakChips','trendScroll','trendBody','trendLine','censusBody','censusRange',
    'censusFoot','quickRead','censusFootText',
    'addRoomOpen','addRoomModal','addRoomForm','addRoomInput','addRoomMsg',
    'acctList','acctCount','acctCheckAll','addAcctOpen','addAcctModal','addAcctMsg',
    'qrBox','qrMask','qrMaskText','qrRefresh','qrStatus',
    'jiufaOpen','realGameOpen','jiufaDock','jiufaClose','jiufaSync','jiufaFrame','jiufaHint',
    'tabReal','tabSim','realPane','simPane','realBody','simBody','skinSwitch','skinDiy','skinOfficial','jiufaFoot','officialAide','officialAcct',
    'veil','veilTitle','veilText',
    'authGate','authSub','authForm','authUser','authPass','authMsg','authSubmit','authCaptchaBox',
    'authTitle','authToReg','regForm','regUser','regPass','regPass2','regInviteWrap',
    'regInvite','regCaptchaBox','regContact','regMsg','regSubmit','regBack',
    'regDone','regDoneText','regDoneBack',
    'userChip','ucName','ucDue','ucLogout',
    // 4.2.0 九法VIP
    'ucVip','ucBuy','vipGate','vipTitle','vipLede','vipPlans','vipCompare',
    'vipCompareBody','vipBuyBtn','vipCardBtn','vipCardForm','vipCardInput',
    'vipCardSubmit','vipCsHint','vipMsg','vipFoot','vipClose','predVipBar',
    'vipStatus','vipLogout','vipRecBtn','vipRecords',
    'payModal','payClose','payPlan','payQr','payMask','payMaskText','payAmount',
    'payCountdown','paySimBtn','payMsg','payNote',
    // 4.9.8 客服渠道(顶栏入口 + 联系客服弹层)
    'csOpen','csModal','csBody',
    // 5.0.3 空名录主舞台引导卡
    'stageEmpty'];
  ids.forEach(id => D[id] = document.getElementById(id));
  D.phaseTrack = $('.phase-track');
  D.phaseNodes = { cast: $('.phase-node[data-phase=cast]'), seal: $('.phase-node[data-phase=seal]'), draw: $('.phase-node[data-phase=draw]') };
  D.deck = $('.deck');
  D.predictDock = document.getElementById('predictDock');
  D.trendBodyWrap = $('.trend-body-wrap');
  D.wideBody = $('.wide-body');
  D.censusTable = $('.census');
  D.railPlaque = $('.rail-plaque');
  D.trendTip = document.createElement('div');
  D.trendTip.className = 'trend-tip'; D.trendTip.hidden = true;
  D.trendBodyWrap.appendChild(D.trendTip);
  D.pendingEls = [];   // 悬挂珠缓存,renderRoad 每次重建后刷新(tick 免全文档查询)
  /* 4.7.2:两块静态序列开机即登记贴底守卫 —— 此后无论视口、字体、图片、档位
     怎么变,守卫都会把它们维持在底部,不再依赖各渲染函数各打一发 snapScroll。 */
  stickInit(D.roadWrap,  { anchor: 'bottom', content: D.roadGrid });
  stickInit(D.wideBody,  { anchor: 'bottom', content: D.wideGrid });
}


/* ═══════════ 4.9.4:输入方式判定 + 触屏提示总线(tap-to-reveal)═══════════
   ★ 病灶(实地核查坐实,非推断)——「战况 · 悬停看详情」在触屏上物理不可达,
     三道锁串联,任何一道都足以致命:
       ① 唯一触发路径是 #trendScroll 的 pointermove,而触屏**静止点按根本不派发
          pointermove**(规范行为:touch 的 pointermove 只在手指移动时才来);
       ② 实测事件序列 pointerdown→touchstart→pointerup→**pointerleave**→touchend
          →mousemove→click —— pointerleave 早于 click 抵达,onTrendLeave 先把卡
          藏掉、十字准星 data-col 一并清掉,后面再怎么点都是空的;
       ③ 旧 onTrendClick 里还写着 D.trendTip.hidden = true(旧注「触屏点按后随手
          收起」),把最后一条路也堵死。
     而面板副标题至今仍写着「悬停看详情」—— 在移动端宣传一个物理上按不出来的功能。
     同族问题远不止战况:全站 3500+ 个 title 在触屏浏览器**一律不渲染**。

   ★ 为什么不删 title 改成自绘(上一版方案的错):
     仓库既有三支回归钉逐字节钉住 title ——
       · frontend_predgap_jsdom.js  断言 predStats.title 含「窗口 100 局」
       · frontend_replay_jsdom.js   断言 r0.title === r1.title,并逐句钉住
                                    命中率本体 / 盲选基线 / 窗口未满三句
       · frontend_it_jsdom.js       断言 /回看/.test(roadExpand.title)
     删 title 当场三红。故本层**只读不写**:title 继续是唯一事实源,桌面继续走
     系统气泡(行为逐字节不变),触屏另开一条自绘通道读同一份文本 ——
     零内容改动 ⇒ 零内容回归面,也不必去动那 20 余处 title 生成点。

   ★ 为什么按「最后一次输入方式」而不是媒体查询:
     单用 (hover:none) 会漏两类真实设备 —— 触屏笔记本(Surface)是
     hover:hover + pointer:coarse;接了妙控板的 iPad 是 hover:hover,而用户
     随时可能改回手指。媒体查询只作首帧默认值,之后每一次 pointerdown 按
     e.pointerType 改写 <html data-input>,插拔鼠标即时收敛,无需刷新。

   ★ 为什么是单击而不是长按:
     长按在 iOS 会触发系统选择/放大镜/上下文菜单,且与滚动手势抢同一条手势通道;
     单击成本最低、可发现性最高。代价是必须把「点」与「滑」分开 —— 序列与战况
     都是可滚容器,不分开的话每一次滚动都会弹卡(同类改造最常见的翻车点)。
     判据:位移 ≤ TAP_SLOP_PX 且时长 ≤ TAP_MAX_MS,两者同时满足才算 tap。

   ★ 气泡不吃点击(pointer-events:none)、不 preventDefault:原有 click 语义
     一条不改 —— 点妖怪卡照样聚光、点战况行照样脉冲联动、点名录条目照样切房。 */
const TAP_SLOP_PX  = 10;      // 点/滑判据:位移阈(px)
const TAP_MAX_MS   = 600;     // 点/滑判据:时长阈(ms)
const TIP_HOLD_MS  = 4200;    // 通用气泡自动收起:防止跳转/开层后卡片孤悬
const TIP_WATCH_MS = 260;     // 锚点存活巡检:元素被移除/隐藏即收
const TREND_TIP_HOLD_MS = 6000;

const isTouchInput = () => S.input === 'touch';
/* 触屏没有实体键盘 —— 气泡里不必把 Esc/←/→ 当路径写给用户。
   只在**展示时**剥,title 属性本体逐字节不动(既有 jsdom 钉子读的是属性)。 */
const tipDisplayText = t => isTouchInput()
  ? String(t).replace(/[（(](?:Esc|←|→)[）)]/g, '').replace(/\s{2,}/g, ' ').trim()
  : String(t);
const trendHint = () => isTouchInput() ? '点格看详情,点行联动序列' : '悬停看详情,点行联动序列';

function setInput(kind){
  const v = (kind === 'touch' || kind === 'pen') ? 'touch' : 'mouse';
  if (S.input === v) return;
  S.input = v;
  document.documentElement.dataset.input = v;
  syncInputCopy();
}
/* 随输入方式改写的文案(只此一处;syncRoomScope 落房号时复用 trendHint) */
function syncInputCopy(){
  if (!D.trendSub) return;
  if (S.alias) syncRoomScope();
  else D.trendSub.textContent = `号位·大小·单双三线轨迹图 · 最新在上 · ${trendHint()}`;
}

/* ── 通用气泡 ────────────────────────────────────────────────────────────── */
let tipHideT = 0, tipWatchT = 0, tipAnchor = null, tipPrev = null, tipFollowRaf = 0;
let tapX = 0, tapY = 0, tapT = 0;

function hideTip(){
  clearTimeout(tipHideT); clearInterval(tipWatchT); tipWatchT = 0;
  tipAnchor = null;
  if (D.tipBubble) D.tipBubble.hidden = true;
}
/* title 与元素自身可见文案完全重合时不弹(如名录条目 title="321",正文已含 321)
   —— 这类点击多半还伴随切房/收名录,弹出来只是孤悬一瞬。 */
function tipWorth(el, txt){
  const own = (el.textContent || '').replace(/\s+/g, '');
  return own.indexOf(txt.replace(/\s+/g, '')) < 0;
}
/* 定位单独抽出 —— 首次显示与滚动跟随共用同一套夹紧规则:
   默认出现在**目标上方**(手指在下方,不挡读),上方放不下才翻到下方;
   水平夹紧在视口内。 */
function placeTip(r){
  const b = D.tipBubble;
  const bw = b.offsetWidth, bh = b.offsetHeight;
  const below = r.top < bh + 16;
  b.classList.toggle('is-below', below);
  b.style.left = Math.round(clampN(bw / 2 + 8, r.left + r.width / 2, innerWidth - bw / 2 - 8)) + 'px';
  b.style.top  = Math.round(below ? r.bottom : r.top) + 'px';
}
/* 4.9.4 六审补:滚动时**跟随**锚点,而不是一律收掉。
   ★ 病灶(Firefox 上实测复现,Chromium 侥幸测不出):容器带 scroll-behavior:smooth,
     程序化平滑滚动会持续派发 scroll —— 实测 Firefox 一次 scrollIntoView 的动画
     跑了 **1.4 秒**,期间用户点出的气泡在**同一毫秒**被自己的 scroll 监听收掉
     (显隐翻转 t=14624 false → t=14624 true)。而本项目到处是程序化滚动:
     stickPin 每局贴底、pulseBead 联动定位、snapScroll、scrollIntoView ——
     新局落地那一下正在平滑滚动,用户此刻点珠子,气泡必被自己人掐掉。
   ★ 改成跟随后严格更好:程序化滚动不再误杀,用户手动滚动时气泡也不再错位;
     锚点真的滚出视口(或被移除/隐藏)才收。
   ★ 性能:rAF 合帧,且只在气泡显示期间(≤TIP_HOLD_MS)工作。 */
function followTip(){
  if (!tipAnchor) return;
  if (!tipAnchor.isConnected) return hideTip();
  const r = tipAnchor.getBoundingClientRect();
  if (!r.width || !r.height) return hideTip();
  if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) return hideTip();
  placeTip(r);
}
function showTipFor(el){
  const raw = (el.getAttribute('title') || '').trim();
  const txt = tipDisplayText(raw);
  if (!txt) return false;
  const r = el.getBoundingClientRect();
  if (!r.width || !r.height) return false;
  const b = D.tipBubble;
  b.textContent = txt;
  b.hidden = false;
  b.classList.remove('is-below');
  b.style.left = '0px'; b.style.top = '0px';
  placeTip(r);                       // 先落内容再量尺寸(与 onTrendMove 同一惯例)
  tipAnchor = el;
  clearTimeout(tipHideT); tipHideT = setTimeout(hideTip, TIP_HOLD_MS);
  clearInterval(tipWatchT);
  tipWatchT = setInterval(() => {
    if (!tipAnchor || !tipAnchor.isConnected) return hideTip();
    const rr = tipAnchor.getBoundingClientRect();
    if (!rr.width || !rr.height) hideTip();
  }, TIP_WATCH_MS);
  return true;
}

/* ── 事件总线:document 级单点委托 ─────────────────────────────────────────
   全站只加这一对监听,不给 1728 颗珠子逐个绑 —— 与既有 onTrendClick / roomList
   的委托惯例一致。全部 passive,永不 preventDefault。 */
function initInputBus(){
  const mqHover  = matchMedia('(hover:none)');
  const mqCoarse = matchMedia('(pointer:coarse)');
  setInput((mqHover.matches || mqCoarse.matches) ? 'touch' : 'mouse');   // 首帧默认值
  D.tipBubble = document.createElement('div');
  D.tipBubble.className = 'tip-bubble'; D.tipBubble.id = 'tipBubble';
  D.tipBubble.setAttribute('role', 'tooltip'); D.tipBubble.hidden = true;
  document.body.appendChild(D.tipBubble);

  document.addEventListener('pointerdown', e => {
    setInput(e.pointerType);
    /* 4.9.4 五审补:多指手势的**非主指针**必须整条排除,双向缺陷 ——
       ① 第二指落下又抬起(位移≈0、时长≈0)会被判成 tap,捏合缩放时误弹气泡;
       ② 更隐蔽的一半:第二指的 pointerdown 会**覆盖 tapX/tapY/tapT**,主指抬起时
          位移是相对第二指落点算的,轻易超过 TAP_SLOP_PX 而被误判成"滑动" ——
          于是捏合期间**正常的单指 tap 反而弹不出来**。
       输入方式判定(setInput)不受此限:第几指按下都能证明用户在用手指。 */
    if (!e.isPrimary) return;
    tapX = e.clientX; tapY = e.clientY; tapT = Date.now();
    tipPrev = tipAnchor;           // 供「再点同处 = 收」判定
    if (tipAnchor) hideTip();      // 点任何地方先收上一张
  }, { capture: true, passive: true });

  document.addEventListener('pointerup', e => {
    if (!e.isPrimary) return;              // 与 pointerdown 同一条门:非主指针不参与 tap
    if (!isTouchInput()) return;
    if (Date.now() - tapT > TAP_MAX_MS) return;                                  // 长按 → 不是 tap
    if (Math.abs(e.clientX - tapX) > TAP_SLOP_PX
     || Math.abs(e.clientY - tapY) > TAP_SLOP_PX) return;                        // 滑动 → 不是 tap
    const t = e.target instanceof Element ? e.target : null;
    if (!t) return;
    if (t.closest('#tipBubble, .trend-tip')) return;
    if (t.closest('#trendScroll')) return;      // 战况走专线(卡片内容含「距上次」推导,不是纯 title)
    const host = t.closest('[title]');
    if (!host || host.tagName === 'IFRAME') return;   // iframe 的 title 是无障碍名,不是提示
    const raw = (host.getAttribute('title') || '').trim();
    if (!raw || !tipWorth(host, raw)) return;
    if (host === tipPrev){ tipPrev = null; return; }  // 再点同处 = 收(pointerdown 已收,这里只是不重开)
    showTipFor(host);
  }, { capture: true, passive: true });

  addEventListener('scroll', () => {
    if (!tipAnchor || tipFollowRaf) return;
    tipFollowRaf = requestAnimationFrame(() => { tipFollowRaf = 0; followTip(); });
  }, { capture: true, passive: true });
  addEventListener('resize', () => { if (tipAnchor) followTip(); }, { passive: true });
  document.addEventListener('visibilitychange', hideTip);
  mqHover.addEventListener?.('change',  () => setInput(mqHover.matches || mqCoarse.matches ? 'touch' : 'mouse'));
  mqCoarse.addEventListener?.('change', () => setInput(mqHover.matches || mqCoarse.matches ? 'touch' : 'mouse'));
}

/* ═══════════ 安全传输层(3.9.0 单账号单活跃房 / 3.9.1 执行证明)═══════════
   把三件与业务无关的安全信号统一收在 API/SSE 层,登录系统未启用时后端全部忽略、
   本层零副作用:
     · JF_TAB —— 本标签页一次性标识(内存态,刷新即变):后端「每账号同时只监控
       1 个房」租约据此区分同账号的多个页面。fetch 走 X-JF-Tab 头、EventSource
       走 ?tab=(它带不了自定义头)。
     · 执行证明(L2,3.9.2 起默认开)—— 明细端点要求 X-JF-Proof = powAnswer(服务端挑战);
       只有真正执行了这段(部署时被混淆的)JS 才算得出,纯 API 搬运器算不出被挡。
     · jfToast —— leaseBusy(老后端兜底)等轻提示,复用页面 #toast。
       (last-wins 主路径的「已切换到最新监控的房」跟随提示走 toast,见 followRoom。) */
const JF_TAB = (() => {
  try {
    return (crypto && crypto.randomUUID) ? crypto.randomUUID().replace(/-/g, '').slice(0, 24)
      : (Date.now().toString(36) + Math.random().toString(36).slice(2, 12));
  } catch { return Date.now().toString(36) + Math.random().toString(36).slice(2, 12); }
})();

/* 4.9.0:去抖账本改成**按内容分桶**。旧写法是一个全局 `_jfToastAt`:4 秒内任何
   一条 jfToast 都会把**内容完全不同、可能更重要**的下一条整条丢弃(jsdom 实测确证);
   而 toast() 又不更新这个账本,两条管线的节流互不感知。分桶后:同一句话 4s 内不刷屏
   (原意保住),不同的话各自独立(误伤消失)。Map 带容量上限,不会无界增长。 */
const _jfToastAt = new Map();
const JF_TOAST_DEBOUNCE_MS = 4000, JF_TOAST_KEYS_MAX = 32;
function jfToast(msg){
  try {
    const now = Date.now();
    const key = String(msg);
    const prev = _jfToastAt.get(key) || 0;
    if (now - prev < JF_TOAST_DEBOUNCE_MS) return;    // 同一句 4s 去抖,避免轮询/重连刷屏
    _jfToastAt.set(key, now);
    if (_jfToastAt.size > JF_TOAST_KEYS_MAX){         // 容量兜底:淘汰最老的一批
      for (const k of [..._jfToastAt.keys()].slice(0, _jfToastAt.size - JF_TOAST_KEYS_MAX))
        _jfToastAt.delete(k);
    }
    let el = document.getElementById('toast');
    if (el){
      /* 3.9.4 复审加固:命中页面 #toast 时**委托 toast()** —— 旧实现自设匿名 3.4s
         计时器且与全站计时器互不感知,形成双计时器竞争。委托后单管线单计时器,
         语义与全站一致(4.9.0 起该管线还带优先级排队)。 */
      toast(msg);
      return;
    }
    // 裸环境兜底(无 #toast 的极端宿主):自建独立元素,与页面管线零竞争面。
    el = document.getElementById('__jf_toast__');
    if (!el){
      el = document.createElement('div'); el.id = '__jf_toast__';
      el.style.cssText = 'position:fixed;left:50%;bottom:32px;transform:translateX(-50%);z-index:99999;max-width:82%;padding:10px 16px;border-radius:10px;background:rgba(38,50,44,.94);color:#fff;font:14px/1.55 -apple-system,system-ui,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.25);text-align:center;transition:opacity .25s';
      (document.body || document.documentElement).appendChild(el);
    }
    el.textContent = msg; el.hidden = false; el.style.opacity = '1';
    // 4.9.0:计时器挂在元素上并先清 —— 连续调用不再留下互相掐灭的孤儿计时器;
    // 淡出后一并 hidden,避免透明元素继续参与命中测试(与 admin 侧同款修法)。
    clearTimeout(el._h);
    el._h = setTimeout(() => {
      try { el.style.opacity = '0'; el.hidden = true; } catch {}
    }, 3400);
  } catch {}
}
const JF_BUSY_MSG = '同一账号同一时间只能监控 1 个直播间 —— 你已在另一个窗口/设备监控中,请关闭其它监控窗口后再使用本页。';

/* 执行证明变换 T —— **必须与后端 app/web.py 的 _pow_answer() 逐位一致**
   (已用 1000+ 组随机输入含中文/符号做 Python↔JS 字节级对拍;部署混淆语义保持,
   不改变其输出)。选非标准算法(而非 SHA/HMAC)是刻意的:搬运器无法调库,必须
   跑这段 JS 或逆向它。 */
function powAnswer(challenge){
  let h1 = 0x811c9dc5 >>> 0, h2 = 0x1000193 >>> 0;
  for (let i = 0; i < challenge.length; i++){
    const c = challenge.charCodeAt(i) >>> 0;
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h1 = ((h1 << 13) | (h1 >>> 19)) >>> 0;
    h2 = Math.imul((h2 + c + i) >>> 0, 0x85ebca6b) >>> 0;
    h2 = (h2 ^ (h2 >>> 15)) >>> 0;
    h1 = (h1 + h2) >>> 0;
  }
  h1 = (h1 ^ (h1 >>> 16)) >>> 0; h1 = Math.imul(h1, 0x7feb352d) >>> 0; h1 = (h1 ^ (h1 >>> 15)) >>> 0;
  h2 = (h2 ^ (h2 >>> 13)) >>> 0; h2 = Math.imul(h2, 0x846ca68b) >>> 0; h2 = (h2 ^ (h2 >>> 16)) >>> 0;
  const hx = x => (x >>> 0).toString(16).padStart(8, '0');
  return hx(h1) + hx(h2);
}

/* 4.9.0:POW 状态多了 exp / gen 两个字段,原因见 ensurePow 的注释。 */
const POW = { on: false, ans: null, exp: 0, gen: 0, minting: null };
/* **明细端点口径必须与后端实际设闸的 4 个端点逐字对齐**(web.py 的
   _proof_guard 调用点:/history、/coverage、/prediction、以及**裸** /api/rooms/{room}
   = summary)。旧正则写成 `/summary` 后缀 —— 后端根本没有那条路径,而真正受闸的裸
   summary 反倒不带证明头。目前前端恰好没调裸路径所以没炸,但这是颗定时炸弹:
   任何人日后加一处 summary 调用就会**永久 401**(重试预算耗尽后硬报错),并把
   pow_fail 灌成天文数字。顺带补 `^` 锚定,避免任何形如 `/x/api/rooms/…` 的误匹配。
   反面必须不匹配:/api/rooms(名录列表)、/history/days、/config —— 后端均未设闸。 */
const JF_DETAIL_RE = /^\/api\/rooms\/[^/?]+(?:\/(?:prediction|coverage|history))?(?:\?|$)/;
function jfIsDetail(path){ try { return JF_DETAIL_RE.test(String(path)); } catch { return false; } }
/* 执行证明挑战的取得与**主动续铸**。
   3.9.x 的写法是「铸一次,把应答永久缓存,只在收到 401 后被动重铸」——而后端挑战
   TTL 默认 180s。于是真人**每 3 分钟稳吃一次 pow_fail**,30 分钟窗口刚好凑够 10 次,
   精确点亮管理台的「执行证明失败 N 次」(+20)。实测复现无误。
   4.9.0 改为:
     · 记住到期时刻,在 **0.75×ttl** 处主动续铸(留足时钟漂移 + 在飞时延的余量);
     · 用 gen 代际号防止并发自伤 —— 见 api() 里 proof_required 分支的注释。
   `force` 仅供 401 分支使用(那种情况下缓存的应答确已作废,必须立刻换)。 */
async function ensurePow(force){
  if (!POW.on) return;
  if (!force && POW.ans && Date.now() < POW.exp) return;   // 还在有效期内:零请求
  if (POW.minting) return POW.minting;                     // 单飞:并发只铸一次
  POW.minting = (async () => {
    try {
      const r = await api('/api/pow/mint', { timeout: 8000 });   // 非明细端点,不递归
      if (r && r.enabled && r.challenge){
        POW.ans = powAnswer(String(r.challenge));
        const ttl = Math.max(10, Number(r.ttl) || 180);   // 后端一直在下发 ttl,此前前端从不使用
        POW.exp = Date.now() + ttl * 750;                 // = ttl*1000*0.75,提前续铸
        POW.gen++;                                        // 代际推进:并发方据此判断"别人已铸过"
      } else {
        POW.on = false; POW.ans = null; POW.exp = 0;      // 服务端说未开 → 前端停用,不再纠缠
      }
    } catch { /* mint 失败:留空,下个明细请求再试;绝不阻断 UI */ }
    finally { POW.minting = null; }
  })();
  return POW.minting;
}

/* ───────── API 层(8s 超时 + GET 指数重试×2) ───────── */
async function api(path, opt = {}){
  const method = (opt.method || 'GET').toUpperCase();
  const attempts = method === 'GET' ? 3 : 1;
  let lastErr;
  let proofBudget = 1;                                  // 3.9.1:proof_required 重铸重试预算
  let myGen = -1;                                       // 4.9.0:本次请求所带应答的代际号
  for (let i = 0; i < attempts; i++){
    const ctl = new AbortController();
    const tid = setTimeout(() => ctl.abort(), opt.timeout || 8000);
    const t0 = performance.now();
    try {
      const headers = { 'X-JF-Auth': '1', 'X-JF-Tab': JF_TAB, ...(opt.headers || {}) };   // 3.8.0 CSRF 头 + 3.9.0 标签页标识
      if (opt.body && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
      // 3.9.1:明细端点带执行证明头(特性开启时);首个明细请求会先 mint 一次挑战。
      // 4.9.0:ensurePow 现在会在挑战到期前主动续铸,故这里通常是零请求的快路径。
      if (POW.on && jfIsDetail(path)){
        try { await ensurePow(); } catch {}
        if (POW.ans){ headers['X-JF-Proof'] = POW.ans; myGen = POW.gen; }
      }
      const res = await fetch(path, { ...opt, headers, signal: ctl.signal,
        body: opt.body ? JSON.stringify(opt.body) : undefined });
      clearTimeout(tid);
      // 3.2.0:把 Response 与往返时延交给调用方(仅 /history 用它读 Date 头校时)。
      // 多余的 onRes 键被 fetch 的 RequestInit 忽略,与 timeout 同理。
      if (opt.onRes) { try { opt.onRes(res, performance.now() - t0); } catch {} }
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.ok === false){
        // 3.8.0:会话级 401/403(未登录/被顶下/到期/封停)→ 即时回落登录门。
        // 房间级 403(room_not_bound)不在此列 —— 那是数据归属提示,交调用方 toast。
        if ((res.status === 401 || res.status === 403) && AUTH_ERRS.has(data.error))
          handleAuthError(data);
        // 4.2.0:vip_required 是**档位**错误,不是会话错误 —— 绝不能拉起登录门
        // (用户是登录着的,只是没买)。交由调用方按上下文处理/静默。

        /* 3.9.1:proof_required(挑战过期/缺失)→ 重铸并重试一次(不算登录错误)。
           4.9.0 修掉这里的**自伤式踩踏**:旧写法无条件 `POW.ans = null` 再 ensurePow(),
           这会把**另一个并发请求刚铸好的有效应答**一起清掉,进而作废对方,对方再铸又
           作废自己 …… 实测在多标签/并发轮询下形成永不收敛的乒乓(12 拍 → 14 次
           pow_fail / 1 次 pow_ok)。现在按代际号判断:只有「我用的还是当前这一代」时
           才真正重铸;若代际已被别人推进,说明手上已有更新的应答,直接带着它重试即可。 */
        if (data.error === 'proof_required' && POW.on && proofBudget > 0){
          proofBudget--;
          const mineIsCurrent = (myGen === POW.gen);   // 我用的还是当前这一代 → 确实该换
          if (mineIsCurrent){ POW.ans = null; POW.exp = 0; }
          try { await ensurePow(mineIsCurrent); } catch {}
          continue;
        }
        // 2.6.3:5xx / 408 / 429 属瞬态服务端故障 → 走既有 GET 指数退避重试;
        // 其余(4xx / 业务 ok:false)为终态,立即上抛不重试(与原行为一致)
        const transient = !res.ok && (res.status >= 500 || res.status === 408 || res.status === 429);
        throw Object.assign(new Error(data.error || ('HTTP ' + res.status)),
          { status: res.status, data, final: !transient });
      }
      return data;
    } catch (e){
      clearTimeout(tid);
      lastErr = e;
      if (e.final) throw e;                               // 业务错误不重试
      if (i < attempts - 1) await sleep(400*(i+1) + Math.random()*300);
    }
  }
  throw lastErr;
}

/* ═══════════ 登录系统(3.8.0)═══════════
   服务端会话是唯一真相:前端只问 /api/auth/session,enabled:false(或旧后端
   404)= 未启用,一切行为与 3.7.0 逐字节一致。启用且未登录 → 登录门 + 霜罩,
   **不发任何数据请求**(后端中间件同样会 401,这里省下注定失败的往返)。 */
const AUTH = { enabled: false, user: null, locked: false };

/* ═══════════ 九法VIP 分层(4.2.0)═══════════
   tier 默认 'vip' 是**刻意**的:旧后端/未启用 VIP 体系时前端行为与 4.1.2 逐字节
   一致(同 POW.on / REG.mode / AUTH.enabled 的既有约定)。只有后端明确回
   jf.enabled=true 才进入分层逻辑。 */
const JF = { on: false, tier: 'vip', plans: [], matrix: [],
             vipUntil: '', vipDays: null, ddAlive: true,
             histLimit: 30, predWindow: 100, simulate: false,
             /* 4.4.0:basic 档「在线累计窗」小时数(后端 jf.basicOnlineH 下发)。
                0 = 关闭 = 逐字节 4.3.x 行为。默认 0:**旧后端不下发该字段时
                必须退回旧行为**,绝不能因为前端新版就擅自替后端放开限制。 */
             onlineH: 0,
             /* 4.4.1:本站是否提供「在线扫码付款」(后端 jf.site.pay 下发)。
                ★ 默认 true,与上面 onlineH 默认 0 的方向**相反**,这不是笔误:
                onlineH 的保守方向是「漏下发时宁可少给数据」;站点分流的保守方向
                是**维持旧行为** —— 旧后端根本没有「代理镜像站」这个概念,它服务的
                每个域名都是直营站,此时替后端把在线支付藏掉才是擅自改变行为。 */
             payOn: true };

/* ═══════════ 客服联系方式(4.4.2)═══════════
   数据源:/api/auth/session 的**顶层** `contact` 段(不在 jf 下面 —— jf 会随
   jf_vip_enabled 整体退场,而客服是站点级事实,将来要在开通门之外复用)。

   四条约定,顺序即优先级:
     ① **服务端已经裁剪过站点**:代理镜像站的响应体里根本没有这几个字段(后端
        userauth.cs_info 的第一道闸)。前端因此**不需要、也不应该**自己判站点 ——
        多写一个判据就多一个两边打架的可能;
     ② 缺字段 = 没有客服 = 逐字节 4.4.1 行为(一句纯提示,无联系方式);
     ③ url 在这里**再过一次 http/https 白名单**。后端才是真闸,这一道是纵深:
        本模块是要被多处复用的,谁都可能把它接到另一个数据源上,而
        `href="javascript:…"` 里没有任何需要 HTML 转义的字符 —— esc() 挡不住它;
     ④ 一切文本走 textContent / createElement,**绝不 innerHTML**。
        4.4.1 在 showVipGate 那行留下的原话是「将来若要把文案改成可配置项,
        这一行必须同步改回 textContent + esc()」—— 现在正是那个"将来"。 */
const CS = { label: '', value: '', url: '', note: '' };
const csOn = () => !!(CS.value || CS.url);
/* 与后端 userauth.cs_url 同口径:必须 http/https 开头,且 :// 之后真有主机名
   (`//evil.com` 会继承当前页协议直指外站,看着却像相对路径,一并拒绝)。 */
const CS_URL_OK = /^https?:\/\/[^/\s]/i;
function csLand(contact){
  const c = contact && typeof contact === 'object' ? contact : {};
  CS.label = String(c.label || '').trim();
  CS.value = String(c.value || '').trim();
  CS.note  = String(c.note  || '').trim();
  const u = String(c.url || '').trim();
  CS.url = CS_URL_OK.test(u) ? u : '';
}
/* 复制到剪贴板。**兜底是必需项不是加固**:本项目 cookie_secure 默认 auto、
   部署形态明确包含 http(IP:端口 直连自测在文档里被反复提及),而
   navigator.clipboard 在非安全上下文**根本不存在**。范式照搬 admin.js 已验证过
   的那套(clipboard → execCommand → 明确告知失败),不另造一套。
   返回 true/false;失败时调用方负责给出"手动复制"的出路,绝不静默。 */
async function copyText(txt){
  const s = String(txt == null ? '' : txt);
  if (!s) return false;
  try {
    if (navigator.clipboard && navigator.clipboard.writeText){
      await navigator.clipboard.writeText(s);
      return true;
    }
  } catch { /* 落兜底 */ }
  let ta = null;
  try {
    ta = document.createElement('textarea');
    ta.value = s;
    ta.setAttribute('readonly', '');
    /* 不用 display:none / visibility:hidden —— 那两种情况下 select() 是空操作,
       execCommand('copy') 必然失败。挪出视口 + 透明是唯一可行的藏法。
       fixed + top:0 而非负 top:是为了不在 iOS 上触发滚动跳变。 */
    ta.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;'
                     + 'opacity:0;padding:0;border:none;pointer-events:none';
    document.body.appendChild(ta);
    ta.select();
    if (ta.setSelectionRange) ta.setSelectionRange(0, s.length);
    return !!document.execCommand('copy');
  } catch { return false; }
  finally { if (ta && ta.parentNode) ta.parentNode.removeChild(ta); }
}
/* 把客服联系方式渲染进任意容器(开通门是第一个调用方,不是唯一一个)。
   返回是否真的渲染了 —— 调用方据此决定要不要留出间距/分隔符。

   为什么号码是「展示 + 复制按钮」而不是做成链接:微信号根本没有可用深链;
   QQ 的 mqqwpa:// / tencent:// 在桌面浏览器点了毫无反应,那是本项目一贯拒绝的
   死控件(§12.6 当初拒绝把提示做成按钮,是同一条理由)。**复制在任何形态下
   都成立**,所以它是默认动作;真正点得动的去处只有运维显式填了 https 链接时才有。 */
function csAppendTo(host){
  if (!host || !csOn()) return false;
  const line = document.createElement('span');
  line.className = 'vip-cs-line';
  if (CS.label){
    const l = document.createElement('span');
    l.className = 'vip-cs-label';
    l.textContent = CS.label;
    line.appendChild(l);
  }
  if (CS.value){
    const v = document.createElement('b');
    v.className = 'vip-cs-value';
    v.textContent = CS.value;
    line.appendChild(v);
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'vip-cs-copy';
    btn.textContent = '复制';
    /* 可及名称必须自带上下文:读屏用户听到的不能只是"复制" ——
       一层弹层里可能有多个复制入口,光一个动词无从分辨复制的是什么。 */
    btn.setAttribute('aria-label', '复制' + (CS.label || '客服') + ' ' + CS.value);
    btn.addEventListener('click', async () => {
      const ok = await copyText(CS.value);
      /* 失败不假装成功:直接告诉用户还有"长按/选中手动复制"这条路 ——
         .vip-cs-value 保留了 user-select:text 正是为这一刻(见 app.css)。 */
      toast(ok ? '已复制:' + CS.value : '复制失败 —— 请长按号码手动复制');
    });
    line.appendChild(btn);
  }
  if (CS.url){
    const a = document.createElement('a');
    a.className = 'vip-cs-link';
    a.href = CS.url;                 // 已过 CS_URL_OK 白名单(见 csLand)
    a.target = '_blank';
    a.rel = 'noopener noreferrer';   // 新窗必带:免 window.opener 反向控制本页
    /* 有号码时链接是"另一条路",给它一个自解释的名字;只有链接时它就是主体,
       用运维填的渠道名。两种情况下都不出现"点击这里"这种无信息量的词。 */
    a.textContent = CS.value ? '在线客服' : (CS.label || '在线客服');
    line.appendChild(a);
  }
  host.appendChild(line);
  if (CS.note){
    const n = document.createElement('span');
    n.className = 'vip-cs-note';
    n.textContent = CS.note;
    host.appendChild(n);
  }
  return true;
}

/* ═══════════ 客服渠道(4.9.8)═══════════
   首页(顶栏)常驻入口 #csOpen + 「联系客服」弹层 #csModal —— csAppendTo
   注释里那句「开通门是第一个调用方,不是唯一一个」的第二个调用方:同一份
   CS 数据、同一套渲染(复制两级兜底 / URL 白名单 / 逐节点 createElement)
   原样继承,不造第二份实现。
   ① 入口只在 csOn() 时出现:未配置、或本次请求不是直营主站(后端 cs_info
      在下发边界就裁掉了,响应体里根本没有 contact 段)⇒ 按钮保持 HTML 里的
      hidden 初值 —— 点了没有去处的按钮正是本项目一贯拒绝的死控件(§12.6)。
      显隐由 syncCsEntry 在 authInit 落地 contact 之后同步一次即可:本页
      生命周期内 CS 不再变化(登录成功走 location.reload 从零重建,authInit
      只在 boot 跑一次),无需再挂其它同步点;authInit 的 catch 路径不落
      contact ⇒ csOn() 恒假 ⇒ 初值 hidden 原样保持,同样不必显式再藏。
   ② 弹层复用 .modal 全套既有设施:遮罩点击 / [data-close] / Esc 关闭与
      Tab 焦点收容全部由 bindStatic 的 $$('.modal') 中心化接管(2.6.5),
      openModal/closeModal 负责焦点记录与归还(开启者 = 点击时的 #csOpen,
      关层焦点原路退回)—— 零新增机制。
   ③ 每次打开都重建内容(textContent='' 后重渲):非为热更,只为幂等 ——
      重复开合绝不叠出第二行。 */
function syncCsEntry(){ if (D.csOpen) D.csOpen.hidden = !csOn(); }
function openCsModal(){
  if (!csOn() || !D.csModal) return;
  if (D.csBody){ D.csBody.textContent = ''; csAppendTo(D.csBody); }
  /* 焦点目标不显式指定:openModal 的回落链会抓到复制按钮(有号码时);
     只有链接时按钮选择器落空、回落到「×」,链接仍在 Tab 序内 ——
     两种形态都有可用落点,不为此多写一条分支。 */
  openModal(D.csModal, null);
}

/* basic 档是否留存「在线期间读过的数据」。vip 恒为真(它本就有满窗快照),
   basic 看后端下发的窗口,free 恒假(它一个数据请求都不发,无物可存)。 */
const snapWindowH = () => isVip() ? 26 : (isBasic() ? JF.onlineH : 0);
const snapOn = () => snapWindowH() > 0;
const isFree  = () => JF.on && JF.tier === 'free';
const isBasic = () => JF.on && JF.tier === 'basic';
const isVip   = () => !JF.on || JF.tier === 'vip';
const AUTH_ERRS = new Set(['auth_required', 'kicked', 'banned', 'expired']);
const AUTH_TEXT = {
  auth_required: ['', ''],                                  // 常规登录门:无副题
  session_expired: ['', '登录状态已过期,请重新登录'],
  kicked: ['账号已在其他设备登录', '当前设备会话已被顶下;如是本人操作,重新登录即可'],
  expired: ['账号已到期', '请续费后重新登录;如有疑问请联系管理员'],
  banned: ['账号已被停用', '请联系管理员'],
  logged_out: ['已退出登录', ''],
  unavailable: ['用户库暂时不可用', '请稍后重试'],          // session.state 实际取值
  userdb_unavailable: ['用户库暂时不可用', '请稍后重试'],   // login 错误码同义映射
};

async function authInit(){
  try {
    const s = await api('/api/auth/session', { timeout: 10000 });
    AUTH.enabled = !!s.enabled;
    AUTH.user = (s.enabled && s.authed) ? (s.user || null) : null;
    POW.on = !!(s && s.pow && s.pow.enabled);   // 3.9.1:执行证明是否开启(据此决定是否 mint 挑战)
    REG.mode = (s && s.reg && s.reg.mode) || 'off';   // 4.0.0:注册入口开关(旧后端无字段 → off,恒隐藏)
    REG.captcha = (s && s.reg && s.reg.captcha) || null;
    /* 5.2.0:登录人机验证(旧后端 / 未开启 → login 为空对象 → 一切维持原样) */
    LOGIN.captcha = (s && s.login && s.login.captcha) || null;
    LOGIN.mode = (LOGIN.captcha && s.login.captchaMode === 'always') ? 'always' : (LOGIN.captcha ? 'risk' : 'off');
    /* 4.4.2 客服联系方式。**在 JF.on 判定之外无条件落地** —— 它是顶层 contact 段,
       与 jf.enabled 无关(后端 jf_vip_enabled=false 时 jf 整段退场,而客服照发)。
       缺字段(旧后端 / 未配置 / 本次请求不是直营主站)⇒ 三个字段全空 ⇒ csOn()
       为假 ⇒ 一切逐字节维持 4.4.1。 */
    csLand(s && s.contact);
    syncCsEntry();   // 4.9.8:contact 一落地即同步顶栏「客服」入口(默认 hidden,csOn() 才现身)
    // 4.2.0:档位必须在 boot **最早期**落地 —— hydrateSnapshot 的短路、
    // dataBoot 的 free 档直接进开通页,都依赖它先于任何数据请求就位。
    const jf = (s && s.jf) || null;
    JF.on = !!(jf && jf.enabled);
    if (JF.on){
      JF.tier = jf.tier || 'free';
      JF.plans = jf.plans || [];
      JF.matrix = jf.matrix || [];
      JF.vipUntil = jf.jfVipUntil || '';
      JF.vipDays = (jf.jfVipDays == null) ? null : Number(jf.jfVipDays);
      JF.ddAlive = jf.ddAlive !== false;
      JF.histLimit = Number(jf.basicHistoryLimit) || 30;
      JF.predWindow = Number(jf.basicPredWindow) || 100;
      /* 4.4.0:缺字段(旧后端)→ 0 = 关闭。用 `|| 0` 而不是 `|| 24`:
         默认值的方向必须偏保守,漏下发时宁可少给,不可擅自多给。 */
      JF.onlineH = Math.max(0, Number(jf.basicOnlineH) || 0);
      /* 4.4.1:站点分流。用 `=== false` 而不是 truthy 判断 —— 只有后端**明确说
         不给**才关;字段缺失(旧后端)、结构走样、类型不对一律按 true(旧行为)。
         同一份静态产物被多个域名共用(index.html 走 no-cache+304,站点身份不可能
         烘进 HTML),前端只能靠这一跳知道自己此刻是哪种站。 */
      JF.payOn = !(jf.site && jf.site.pay === false);
    }
    document.body.dataset.jfTier = JF.on ? JF.tier : '';
    if (AUTH.user) KEY_NS.v = '@u' + AUTH.user.id;   // 用户级 localStorage 键后缀(须先于一切用户级读写)
    return s;
  } catch (e){
    // 旧后端无此端点(404 final)→ 未启用;网络失败 → 保守视作未启用,
    // 若后端实际启用,首个数据请求会 401 → handleAuthError 兜底拉起登录门。
    AUTH.enabled = !!(e && e.data && e.data.enabled);
    AUTH.user = null;
    return e && e.data || null;
  }
}

function setAuthMsg(t, ok){
  if (!D.authMsg) return;
  D.authMsg.textContent = t || '';
  if (ok) D.authMsg.dataset.ok = '1'; else delete D.authMsg.dataset.ok;
}

function lockApp(reason, extra){
  AUTH.locked = true;
  document.body.dataset.auth = 'locked';
  try { stopRealtime(); } catch {}
  try { hideVeil(); } catch {}
  const [sub, msg] = AUTH_TEXT[reason] || AUTH_TEXT.auth_required;
  if (D.authSub) D.authSub.textContent = sub;
  setAuthMsg((extra && extra.message) || msg || '');
  if (D.authGate){ D.authGate.hidden = false; }
  regShowLogin();                    // 4.0.0:回登录态 + 按 REG.mode 决定注册入口可见性
  renderAuthChip();
  setTimeout(() => { try { D.authUser && D.authUser.focus(); } catch {} }, 60);
}

/* JF.vipDays 可能是 null(后端没给,或 onVipGranted 里 /api/vip/state 那一跳失败)。
   ★ 4.2.2 修复(实机复验时暴露):`Number(null) === 0` 且 `Number.isFinite(0) === true`
   —— 于是 null 被当成「剩 0 天」,三处一起出错:
     · 身份牌显示「九法VIP 剩 0 天」并转警示色
     · 开通门状态条显示「今日到期」并转红
     · 临期提醒弹出「九法VIP 今日到期 · 去续费」
   最糟的触发点是**刚付完钱**:onVipGranted 里 /api/vip/state 若失败(付款后网络
   抖一下就够),JF.vipDays 保持开通前的 null —— 用户付完 ¥88,立刻被告知
   「今日到期,去续费」。null 与 0 必须区分:未知 ≠ 到期。 */
function vipDaysNum(){
  const d = JF.vipDays;
  if (d === null || d === undefined || d === '') return null;
  const n = Number(d);
  return Number.isFinite(n) ? n : null;
}

function renderAuthChip(){
  if (!D.userChip) return;
  if (!(AUTH.enabled && AUTH.user)){ D.userChip.hidden = true; return; }
  const u = AUTH.user;
  D.ucName.textContent = u.userName || '—';
  /* 4.3.7:补 title —— app.css 已让用户名在所有形态下不设宽度上限(放不下就折行),
     唯一例外是驾驶舱(body[data-layout=cockpit]):那里顶栏被钉死 52px 高、且
     computeLayout 的 `L.mainH = h - 52 - …` 硬编码了这个 52,名字折第二行会把
     chip 顶出顶栏盖住 .deck,故该形态保持单行。实测 1240 宽仍可完整显示 30 字
     中文(注册上限 20 字,userauth.py:1171),只有上游 tb_user 那种 30 字以上的
     超长名才会走到省略号 —— 而驾驶舱恒为桌面(≥1240×680),鼠标悬停必可用,
     title 正好是这一个边角的兜底。其余形态名字本就全显,title 只是冗余不冒犯。 */
  D.ucName.title = u.userName || '';
  const days = Number(u.dueDays);
  if (Number.isFinite(days)){
    // 4.2.0:VIP 体系开启后这一行明确标注是「小叮当」——
    // 否则 basic 档用户看到孤零零的「剩 30 天」却处处受限,只会认为是 bug。
    const t = days <= 0 ? '已到期' : `剩 ${days} 天`;
    D.ucDue.textContent = JF.on ? `小叮当 ${t}` : (days <= 0 ? '今日到期' : `剩 ${days} 天`);
    D.userChip.dataset.warn = days <= 3 ? '1' : '';
  } else { D.ucDue.textContent = ''; D.userChip.dataset.warn = ''; }
  // 第二行:九法VIP 独立时间线
  if (D.ucVip){
    if (!JF.on){ D.ucVip.hidden = true; }
    else {
      const d = vipDaysNum();
      D.ucVip.textContent = JF.tier !== 'vip' ? '九法VIP 未开通'
        : (d === null ? '九法VIP 有效' : `九法VIP 剩 ${Math.max(0, d)} 天`);
      D.ucVip.dataset.on = JF.tier === 'vip' ? '1' : '';
      D.ucVip.dataset.warn = (JF.tier === 'vip' && d !== null && d <= 3) ? '1' : '';
      D.ucVip.hidden = false;
    }
  }
  /* 4.2.1 修复:此前条件是 `tier !== 'vip'`,于是 **VIP 用户看不到任何按钮** ——
     而 predVipBar 也只在 basic 出现,等于**已付费用户根本没有续费入口**。
     现在按钮常驻(VIP 体系开着就有),只换文案:未开通=「开通」/ 已开通=「续费」。
     到期 ≤3 天时按钮转警示色,与身份牌的 data-warn 同一口径。 */
  if (D.ucBuy){
    const isVip = JF.tier === 'vip';
    const vd = vipDaysNum();
    /* 4.3.3:补宾语 —— ≤640 两条状态行让位后(见 app.css 同名注),「开通」是
       顶栏唯一常驻引导,孤词无宾语对小白零信息量;「开通VIP」4 字仍紧凑,
       360 宽实测不折行(topbar 高度前后相等,见回归钉)。 */
    D.ucBuy.textContent = isVip ? '续费' : '开通VIP';
    D.ucBuy.title = isVip ? '续费九法VIP(从当前到期日顺延,不亏时长)' : '开通九法VIP';
    D.ucBuy.dataset.warn = (isVip && vd !== null && vd <= 3) ? '1' : '';
    D.ucBuy.hidden = !JF.on;
  }
  D.userChip.hidden = false;
}

/* 5.2.0 登录:后端在可疑时回 428 challenge_required(附 challenge 与/或 captcha
   要求)。本函数自动补齐后重提,真人只看到按钮上的「安全校验中…」:
   ① challenge → powAnswer(salt) 主线程跑本站 JS(执行证明)→ 复用注册那枚已验证
      的内联 Worker 穷举 SHA-256 前导零(同一份求解器,零新增算法代码);
   ② captcha → #authCaptchaBox 挂 Turnstile/极验挂件,或弹腾讯云验证码,拿一次性 token。
   正常用户(未触发加码、未开 always)与旧版完全一样:一次提交,零额外等待。 */
async function doLogin(ev){
  ev.preventDefault();
  if (LOGIN.solving) return;
  const u = (D.authUser.value || '').trim(), p = D.authPass.value || '';
  if (!u || !p){ setAuthMsg('请输入用户名与密码'); return; }
  LOGIN.solving = true;
  D.authSubmit.disabled = true;
  setAuthMsg('');
  const btn = t => { try { D.authSubmit.textContent = t; } catch {} };
  let proof = {}, usedCap = false, ok = false;
  try {
    if (LOGIN.mode === 'always' && LOGIN.captcha){
      btn('人机验证中…');
      proof.captchaToken = await loginCaptchaToken(LOGIN.captcha);
      usedCap = true;
    }
    for (let round = 0; ; round++){
      btn('登录中…');
      try {
        await api('/api/auth/login', { method: 'POST', body: { userName: u, password: p, ...proof }, timeout: 15000 });
        ok = true;
        setAuthMsg('登录成功,正在进入…', true);
        // reload 收束:整树状态从零重建(名录/账号/快照命名空间全部按新账号),
        // 杜绝「上一账号的内存残留 + 新账号的数据」混装。
        setTimeout(() => location.reload(), 260);
        return;
      } catch (e){
        const d = (e && e.data) || {};
        if (usedCap){ loginCapReset(); usedCap = false; }   // 令牌单次有效:用过即换
        // 加码最多自动补 3 轮(挑战过期 / 换网换段 / 验证码重试),仍不过就把话说清
        if (d.error !== 'challenge_required' || round >= 3) throw e;
        proof = {};
        if (d.captcha && d.captcha.provider){
          btn('人机验证中…');
          if (d.captcha.provider !== 'tencent') setAuthMsg('请完成下方人机验证');
          proof.captchaToken = await loginCaptchaToken(d.captcha);
          usedCap = true;
          setAuthMsg('');
        }
        if (d.challenge && d.challenge.salt){
          btn('安全校验中…');
          const prefix = powAnswer(String(d.challenge.salt));   // 执行证明:主线程跑本站(混淆)JS
          const sol = await regWorkerCall({ type: 'solve', prefix, bits: d.challenge.bits | 0 }, (tried, expect) => {
            const pct = expect > 0 ? Math.min(99, Math.floor(tried / expect * 100)) : 0;
            btn('安全校验中… ' + pct + '%');
          });
          proof.challengeId = d.challenge.challengeId;
          proof.nonce = sol.nonce;
        }
      }
    }
  } catch (e){
    const d = (e && e.data) || {};
    const fallback = { bad_credentials: '用户名或密码错误',
                       throttled: '尝试过于频繁,请稍后再试',
                       banned: '该账号已被停用,请联系管理员',
                       expired: '账号已到期,请续费后再登录',
                       missing_fields: '请输入用户名与密码',
                       userdb_unavailable: '用户库暂时不可用,请稍后重试',
                       login_disabled: '本部署未启用登录系统',
                       challenge_required: '安全校验未完成,请重试',
                       captcha_failed: '人机验证未通过,请重试',
                       captcha_unavailable: '人机验证暂不可用,请稍后重试',
                       login_unavailable: '安全校验暂不可用,请稍后重试',
                       bad_origin: '请求来源校验未通过',
                       bad_request: '请求格式有误,请刷新页面后重试' };
    // challenge_required 的后端文案是写给「不认识 428 的旧页面」看的(请刷新),新页面不照抄
    let msg = d.error === 'challenge_required' ? fallback.challenge_required
      : (d.message || fallback[d.error] || '登录失败,请检查网络后重试');
    if (d.error === 'throttled' && d.retryAfter && !d.message)
      msg += `(约 ${Math.max(1, Math.ceil(d.retryAfter / 60))} 分钟后可再试)`;
    setAuthMsg(msg);
    try { D.authPass.select(); } catch {}
  } finally {
    LOGIN.solving = false;
    if (!ok){ D.authSubmit.disabled = false; btn('登 录'); }
  }
}

async function doLogout(){
  try { await api('/api/auth/logout', { method: 'POST', body: {}, timeout: 8000 }); } catch {}
  location.reload();   // 与登录同理:reload 收束,回到登录门
}

let _authHandled = false;
function handleAuthError(d){
  // api() 层拦到会话级 401/403(未登录/被顶/到期/封停):幂等地拉起登录门。
  if (_authHandled) return;
  _authHandled = true;
  AUTH.enabled = true;         // 后端既然回了会话错,登录系统必然启用
  AUTH.user = null;
  const reason = (d && d.sessionExpired) ? 'session_expired' : (d && d.error) || 'auth_required';
  lockApp(reason, d);
}

/* ═══════════════════════════════════════════════════════════════════════════
   九法VIP · 开通引导与充值(4.2.0)
   ---------------------------------------------------------------------------
   代入小白用户的三条设计纪律:
     ① free 档**只展示 VIP 功能** —— 不渲染任何数据面板、不发任何数据请求。
        样例图是静态示意,不含真实出怪数据。
     ② basic 档**展示区别** —— 应用照常可用,但每个受限处都有如实归因的小字,
        且「回看/全屏/推演」入口**保留可见**(隐藏等于放弃转化点,用户根本不知
        道自己错过了什么)。对比表由后端 jf.matrix 驱动,与实际放行永不脱节。
     ③ 开通成功**不 reload** —— 用户刚扫完码,整页刷新会让人以为出错了。
   ═══════════════════════════════════════════════════════════════════════════ */
const VIP_PAY_POLL_MS = 2000;
const VIP_PAY_GRACE_MS = 60000;   // 倒计时归零后的宽限轮询;须 < 后端 jf_settle_grace_s(90s)

const PAY = { orderNo: '', timer: 0, cdTimer: 0, graceTimer: 0, closeT: 0,
              paidHandled: false, expireAt: 0, simulate: false, ddHours: 0 };

function vipMsg(t, ok){
  if (!D.vipMsg) return;
  D.vipMsg.textContent = t || '';
  if (ok) D.vipMsg.dataset.ok = '1'; else delete D.vipMsg.dataset.ok;
}
function payMsg(t, ok){
  if (!D.payMsg) return;
  D.payMsg.textContent = t || '';
  if (ok) D.payMsg.dataset.ok = '1'; else delete D.payMsg.dataset.ok;
}

/* 小时 → 人话时长。
   锚点取自小叮当**既有卡类型**的 recharge_length:月卡 744h / 季卡 2232h /
   半年卡 4464h / 年卡 8928h —— 这些不是"约等于",而是那边卡类型的**真实定义**,
   所以说「1 个月」是准确的,不是把 31 天四舍五入。
   (原先一律 `ddHours/24` 会显示成「送小叮当 31 天 / 93 天」——数字没错,
    但把一个有名字的档位说成了零碎天数,用户对不上"我买的是月卡"。)
   非锚点值按整月 → 整天 → 小时逐级回落,运营改成任意时长也不会显示成怪值。 */
function durText(hours){
  const h = Math.round(Number(hours) || 0);
  if (h <= 0) return '';
  if (h === 8928) return '1 年';        // 小叮当年卡
  if (h === 4464) return '半年';        // 小叮当半年卡
  if (h % 744 === 0) return `${h / 744} 个月`;   // 744h = 小叮当月卡
  if (h % 24 === 0) return `${h / 24} 天`;
  return `${h} 小时`;
}

/* 价格文案。整数价按整数显示(「¥18」而不是「¥18.00」),带小数才给两位。
   ★ 4.2.2 修复:原先一律 `toFixed(0)` —— 运营把价配成 39.9 时,档位卡显示
   **¥40**,而支付弹层(`toFixed(2)`)与管理台(`jvMoney`)都显示 ¥39.90。
   同一档位、两个界面、两个价 —— 小白的第一反应是「被多收了」。
   后端 `jfvip.plans()` 本就 `round(price, 2)`,即**允许两位小数**,
   所以这不是假想场景。 */
function priceText(v){
  const n = Number(v) || 0;
  return Number.isInteger(n) ? String(n) : n.toFixed(2);
}

/* 档位卡渲染。tag 非空即挂角标(如「最多人选」)。 */
function renderVipPlans(){
  if (!D.vipPlans) return;
  const ps = JF.plans || [];
  /* ★ 4.4.1 代理镜像站:在线扫码付款整条链退场 —— 档位卡与「立即开通」**同进同退**。
     档位卡为什么也藏(这是本次唯一超出「隐藏扫码」字面的一步,写在这里以便回退):
       ① pickedPlan() 全仓库**只被 openPay() 一个调用方消费**(实地核查)。藏掉主
          CTA 后,档位卡就成了点得动、有选中反馈、却没有任何去处的**死选择器**——
          与本函数下方「档位表为空即禁用立即开通」拒绝的是同一件事:不给用户
          可点却不通的控件。
       ② 卡上印的是**平台直营价**。代理按自己的价卖卡,把直营价摆在代理站上,
          用户第一反应是「被加价了」—— 而这恰恰是代理要求藏掉在线支付的原因本身。
     藏与显成对写在这一处,杜绝「只藏不显」(与 setGameEntriesVisible 同款纪律)。
     要保留档位卡:删掉下面这个 if 分支即可,其余逻辑逐字节不受影响。 */
  if (!JF.payOn){
    if (D.vipBuyBtn) D.vipBuyBtn.hidden = true;
    D.vipPlans.hidden = true;
    D.vipPlans.innerHTML = '';      // 不留死 DOM:读屏器的转子也摸不到已退场的档位
    return;
  }
  if (D.vipBuyBtn) D.vipBuyBtn.hidden = false;
  D.vipPlans.hidden = false;
  /* ★ 4.2.9:后端 jfvip.plans() 是 fail-safe 的 —— JSON 配坏或没配就回**空表**。
     改前此时「立即开通」仍可点,点了只回一句「请选择一个档位」——
     而页面上一个档位都没有,等于让用户去做一件不可能的事;free 档用户还被
     锁在门里,唯一可点的按钮在骗他。禁用它,并把话说成可执行的。
     不连带禁用「我有卡密」:档位表是热更的(配置中枢改完下次调用即生效),
     且卡密路径失败时后端会给精确原因(card_plan_gone →「该卡密对应的档位
     已下架,请联系管理员」),留着不会产生假死路。 */
  if (D.vipBuyBtn){
    D.vipBuyBtn.disabled = !ps.length;
    D.vipBuyBtn.title = ps.length ? '' : '档位暂未配置,暂时无法在线开通';
  }
  if (!ps.length){
    D.vipPlans.innerHTML =
      '<p class="vip-empty">档位暂未配置,暂时无法在线开通<br>请联系管理员</p>';
    return;
  }
  D.vipPlans.innerHTML = ps.map((p, i) => {
    /* ★ 复审补:后端 plans() 只过滤 price>0 与 jfHours>0,**ddHours=0 是合法配置**
       (运营随时可以停掉赠送)。原先无条件拼「送小叮当 ${durText(ddHours)}」,
       而 durText(0) 回空串 —— 卡上会出现断句的「送小叮当」。 */
    const gift = durText(p.ddHours);
    return `
    <button class="vp" type="button" data-code="${esc(p.code)}"
            aria-pressed="${i === Math.min(1, ps.length - 1) ? 'true' : 'false'}">
      ${p.tag ? `<i class="vp-tag">${esc(p.tag)}</i>` : ''}
      <b class="vp-name">${esc(p.name)}</b>
      <span class="vp-price"><em>¥</em>${priceText(p.price)}</span>
      ${gift ? `<i class="vp-gift">送小叮当 ${esc(gift)}</i>` : ''}
    </button>`;
  }).join('');
  // 默认选中第二档(通常是「最多人选」);只有一档时选它
  const def = D.vipPlans.querySelector('.vp[aria-pressed="true"]');
  if (def) def.classList.add('is-on');
  D.vipPlans.querySelectorAll('.vp').forEach(b => b.addEventListener('click', () => {
    D.vipPlans.querySelectorAll('.vp').forEach(x => {
      x.classList.remove('is-on'); x.setAttribute('aria-pressed', 'false');
    });
    b.classList.add('is-on'); b.setAttribute('aria-pressed', 'true');
  }));
}
function pickedPlan(){
  const b = D.vipPlans && D.vipPlans.querySelector('.vp.is-on');
  return b ? b.dataset.code : ((JF.plans[0] || {}).code || '');
}

/* 状态条:把"用户当下最该知道的那个事实"放在标题正下方。
   原先这些埋在页脚 #vipFoot 的 11.5px 灰字里 —— 那个位置用户不会看,
   而这恰恰是他做决定要用的信息:
     free   → **为什么什么都看不到**(小叮当已到期)
     renew  → **我还剩多久、到哪天**(续费决策的唯一依据)
     upsell → 不显示(他的状态是"没开通",标题已经说了,再说一遍是废话) */
function renderVipStatus(mode){
  if (!D.vipStatus) return;
  const u = AUTH.user || {};
  if (mode === 'renew'){
    const d = vipDaysNum();                 // null = 未知,**不是** 0(见 vipDaysNum 注)
    const until = JF.vipUntil ? String(JF.vipUntil).replace('T', ' ').slice(0, 16) : '';
    const warn = d !== null && d <= 3;
    D.vipStatus.innerHTML =
      `<span class="vs-k">当前九法VIP</span>`
      + `<b class="vs-v">${d === null ? '有效' : (d <= 0 ? '今日到期' : `剩 ${d} 天`)}</b>`
      + (until ? `<span class="vs-sub">到期 ${esc(until)}</span>` : '');
    D.vipStatus.dataset.tone = warn ? 'warn' : 'ok';
    D.vipStatus.hidden = false;
    return;
  }
  if (mode === 'free'){
    const due = u.dueTime ? String(u.dueTime).replace('T', ' ').slice(0, 16) : '';
    D.vipStatus.innerHTML =
      `<span class="vs-k">当前状态</span>`
      + `<b class="vs-v">暂无可看数据</b>`
      + `<span class="vs-sub">小叮当${due ? ' 已于 ' + esc(due) + ' 到期' : '已到期'}`
      + ` · 九法VIP 未开通</span>`;
    D.vipStatus.dataset.tone = 'warn';
    D.vipStatus.hidden = false;
    return;
  }
  D.vipStatus.hidden = true;
}

/* 锁形。4.2.2:从 emoji 🔒 改为内联 SVG —— emoji 在不同平台/字体下会被渲染成
   彩色、单色、不同字重的三种样子,与同一行的 ✓、与整卡的自绘印章(法)都不同源;
   `currentColor` 则保证它永远与文字同色同重。类名 `.vc-lock` 保持不变
   (jsdom 断言与样式都以它为锚)。 */
const VC_LOCK = '<i class="vc-lock" role="img" aria-label="需要VIP">'
  + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"'
  + ' stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
  + '<rect x="4.2" y="10.4" width="15.6" height="11.2" rx="2.6"></rect>'
  + '<path d="M8 10.4V7a4 4 0 0 1 8 0v3.4"></path></svg></i>';

/* 「当前 vs VIP」对比表 —— 数据源是后端 jf.matrix(与 _vip_guard 接线同源)。
   basic 档才显示(free 档还没有"当前"可比,展示它只会增加认知负担)。 */
function renderVipCompare(renew){
  if (!D.vipCompare || !D.vipCompareBody) return;
  const rows = JF.matrix || [];
  // 续费态不给对比表:他已经全都有了,列一张两栏全绿的表没有信息量,只会稀释重点
  if (renew || !rows.length || JF.tier !== 'basic'){ D.vipCompare.hidden = true; return; }
  D.vipCompareBody.innerHTML = rows.map(r => {
    /* 4.2.3:只给一个灰色小锁,小白读不出"我现在没有"。补一句人话。 */
    const cur = r.need === 'vip' ? VC_LOCK + '<span class="vc-off">未开通</span>'
                                 : `<span>${esc(r.basic || '✓')}</span>`;
    return `<div class="vc-row"><span class="vc-k">${esc(r.label)}</span>
            <span class="vc-cur">${cur}</span>
            <span class="vc-vip">${esc(r.vip || '✓')}</span></div>`;
  }).join('');
  D.vipCompare.hidden = false;
}

/* 卡密是否为本站**唯一**开通路径(代理镜像站,或档位表为空的直营站)。
   写成实时求值的谓词而**不是模块级标志**,理由有二:
     ① JF.payOn / JF.plans 全仓只在 authInit 落地一次、此后不再变(已逐点核过),
        故"开门时求值"与"用时求值"恒等 —— 既然恒等,就不该多留一份需要有人
        记得同步的可变副本。派生态用函数、可变态用变量,是本文件既有的分工
        (isFree / isBasic / isVip / snapOn / csOn 全是这个写法;而 VIP_REC_LOADED /
        SSO_BUSY 那三个 let 是**闩锁**,不是派生态)。
     ② 判据只此一处成文,showVipGate 与 setVipCardOpen 引用同一个函数,
        根本不存在"两边各写一遍再打架"的可能。 */
const vipCardOnly = () => !JF.payOn || !((JF.plans || []).length);

/* 卡密表单展开态的**唯一写入口**(4.9.9)。
   全仓库只有两个调用方:showVipGate(开门时定初值)与「我有卡密」的点击(切换)。

   为什么要收成一个函数:这个态现在同时管**三样东西** ——
     ① 卡密表单 #vipCardForm 的显隐;
     ② 「我有卡密」的 aria-expanded(折叠控件的读屏契约,与 #vipRecBtn 同款);
     ③ 「没有卡密?可联系客服购买」#vipCsHint 的显隐(本次新增)。
   三样是同一件事的三个面。分散在两处各写一遍,迟早漂移出「表单开着、提示还收着」
   这种自相矛盾的中间态 —— 与 setGameEntriesVisible「藏与显成对写在一处」同款纪律。

   ★ 4.9.9 变更点:客服提示由「开门即在」改为**跟随卡密表单展开态**。
     · 用户还没表示要走卡密这条路时,不替他假设「没有卡密?」这个问题 ——
       直营站首选路径是「立即开通」,先摆一句关于卡密的备注是抢答;
     · 收起态省下的**卡片高度**(Chromium 141 @320×568 真机实测,不是估算):
         未配客服联系方式 ⇒ **29.2px**(12×1.6 = 19.2 行高 + 10px 上边距;
                            display:none 连外边距一并收,故边距要算进去)
         配齐联系方式     ⇒ **81.6px**(整块一起收:再叠 .vip-cs-line 与
                            .vip-cs-note 及各自上边距)
       ★ 但**不可**把它写成「主 CTA 更靠上」—— 本行在 DOM 里位于「立即开通」
         **之后**,收起它对主 CTA 的首屏位置**零影响**:同一 scrollTop 下实测
         两态 #vipBuyBtn 都在 y=424(320×568)。省下的是卡片总高(988→850,
         连带卡密表单),即门内要滚的距离更短、视觉噪音更少。
         (app.css 4.2.9 段那次首屏优化动的是排在 CTA **之前**的元素,
          与本行不是一回事,不要套用它的结论 —— 本注上一版就套错过。)

   ★ **唯一例外:vipCardOnly() 时恒显**。这不是补丁,是本改动成立的边界 ——
     镜像站与档位表为空时,「立即开通」与档位卡都已退场,这一句既是唯一的购买
     去处,也是「为什么这里没有立即开通」的唯一交代。若让它跟着收起,用户点一下
     折叠按钮就会得到一个**没有任何去处、也不解释缺口的门** —— 那正是 §12.6 立
     这句话时点名要避免的「让用户对着一个缺口发懵」。
     (实测确认过这个态:收起后门内 vipBuyBtn/vipPlans/vipCsHint 三者全隐。)
     另:需求原文点名的是直营站那句「没有卡密?可联系客服购买」;镜像站那句
     「本站仅支持卡密开通 · 请…」是另一句话,不在本次收起范围内。

   ★ 提示的**内容**由 showVipGate 无条件写好(不受本函数管辖):收起只是不可见,
     点开即在,不重算 —— 展开是高频交互,不该每次都重跑一遍 csAppendTo。 */
function setVipCardOpen(open){
  if (D.vipCardForm) D.vipCardForm.hidden = !open;
  /* 折叠控件必须同步 aria-expanded,否则读屏用户听不出这个按钮是
     「展开/收起」还是「跳转」(4.2.9 立的契约,原样保留)。
     注:按钮的 aria-controls 仍只指 #vipCardForm —— 提示在 vipCardOnly() 时并不
     受它控制,把它一并写进 aria-controls 反而会对读屏器说一句不总成立的话。 */
  if (D.vipCardBtn) D.vipCardBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
  if (D.vipCsHint) D.vipCsHint.hidden = !(open || vipCardOnly());
}

/* 开通门。mode='free' = 全屏拦截(不可关);'upsell' = basic 档主动点开(可关)。 */
/* 三种形态:
     free   —— 小叮当也到期,全屏拦截、不可关(关了就是白屏)
     upsell —— basic 档主动点开,给「当前 vs VIP」对比,可关
     renew  —— **已是 VIP** 的续费(4.2.1 补:此前完全没有这条路径)。
                不给对比表(他什么都有了,对比没有信息量),改为把
                「当前到期日 + 续费从到期日顺延」讲清楚 —— 后者是
                _grant_tx 的真实口径(GREATEST(NOW(), vip_until) + N),
                不是营销话术,提早续费一天都不会亏。 */
function showVipGate(mode){
  if (!D.vipGate) return;
  /* 5.0.2:门 z-index 70 **低于**单开弹层的 80 —— 加房/扫码层开着时进门,门会
     整个压在弹层底下,点「看看九法VIP」像没反应(空名录自动弹层 × jfIntro 升档
     入口是最易撞上的组合;用户手动开层再点 toast 按钮同样命中,属原有隐患)。
     开门前先收起这两枚单开层;closeModal 自带焦点归还与扫码轮询停止。 */
  for (const l of [D.addRoomModal, D.addAcctModal]) if (l && !l.hidden) closeModal(l);
  // 已是 VIP 时,任何入口进来都按「续费」呈现 —— 对已付费用户说「开通」是错的
  if (mode !== 'free' && JF.tier === 'vip') mode = 'renew';
  const free = mode === 'free', renew = mode === 'renew';
  D.vipGate.dataset.mode = mode;
  if (D.vipTitle) D.vipTitle.textContent =
    free ? '开通九法VIP' : renew ? '续费九法VIP' : '升级九法VIP';
  if (D.vipLede) D.vipLede.textContent =
    free ? '看懂每一局,先人一步'
    : renew ? '续费从当前到期日顺延,提早续不亏时长'
    : '解锁下一局预测参考 · 满 24 小时序列 · 按日回看';
  if (D.vipClose) D.vipClose.hidden = free;     // free 档没有「关」——关了就是白屏
  if (D.vipFoot){
    const u = AUTH.user || {};
    const d = Number(JF.vipDays);
    D.vipFoot.textContent = free
      ? `当前账号:${u.userName || '—'} · 小叮当${JF.ddAlive ? '有效' : '已到期'}`
      // 续费态的到期信息已在状态条(标题正下方)显眼呈现,页脚只留账号 ——
      // 同一事实说两遍会稀释重点,也让人以为是两个不同的东西。
      : `当前账号:${u.userName || '—'}`;
  }
  renderVipStatus(mode);
  if (D.vipLogout) D.vipLogout.hidden = !free;   // 只有 free 档需要(壳被禁用)
  /* ★ 4.3.0:主 CTA 随形态换词。9.10 的原则「对已付费用户说开通是错的」当时改了
     标题(续费九法VIP)、顶栏按钮(续费)与副标题,唯独漏了页面最大的这颗金色
     按钮 —— 续费页上写「立即开通」,已付费用户第一反应是「我不是开通过了吗,
     点它会不会重复开通」。free / upsell 维持原文案;renderVipPlans 只动
     disabled/title,不与本行打架(顺序上先置词、后置可用性,任一顺序结果相同)。 */
  if (D.vipBuyBtn) D.vipBuyBtn.textContent = renew ? '立即续费' : '立即开通';
  renderVipPlans();
  /* ★ 复审补:「开通即赠送同时长小叮当会员」在**任一档位** ddHours=0 时就是假话。
     付费页上说假话是最不能忍的一类 —— 逐档是否赠送,档位卡自己已经写了。 */
  const giftLine = D.vipGate.querySelector('.vip-gift');
  if (giftLine){
    const ps = JF.plans || [];
    giftLine.hidden = !(ps.length && ps.every(p => Number(p.ddHours) > 0));
  }
  renderVipCompare(renew);
  vipMsg('');
  /* 4.4.1:「卡密是唯一开通方式」时默认就把输入框展开 —— 已经没有第二条路可选了,
     还要用户再点一下才看见输入框,是纯粹的多余仪式。两种情形都算「唯一」:
       ① 代理镜像站(payOn=false):「立即开通」已整个退场;
       ② 直营站但**档位表为空**:renderVipPlans 会把「立即开通」置为 disabled 并
          写上「档位暂未配置,暂时无法在线开通」—— 此刻能走通的同样只剩卡密。
          (判据取 JF.plans,与 renderVipPlans 里 disabled 的判据同源,不会打架。)
     ★ 焦点仍落在「我有卡密」按钮上,**刻意不落输入框**:free 档的门是**自动**弹出的
       (无用户手势),此时 focus() 到 input 会在安卓上直接顶起软键盘、把卡片推出视口;
       而点按钮展开那条路仍照旧 focus 输入框 —— 那是用户主动点的,前提不同,取舍也不同。
     ★ 仍是**每次开门都重置**(而非记忆上次状态):门的形态由站点/档位决定,
       不该被用户上一次的折叠动作污染。 */
  const cardOnly = vipCardOnly();
  /* 「联系客服购买」(4.4.1 / 4.4.2):两句都含这五个字,但各自只说**对本站成立**
     的话 —— 直营站两条路都通,它是备选;镜像站的在线支付整条链已退场,它是唯一
     去处,顺带如实交代「为什么这里没有立即开通」,而不是让用户对着一个缺口发懵。

     ★ 4.4.2 兑现 4.4.1 留下的那句承诺。原注释写着:「两句都是字面常量、零插值,
       故直接 innerHTML 用 <b> 强调而不经 esc();**将来若要把文案改成可配置项,
       这一行必须同步改回 textContent + esc()**」—— 现在正是那个"将来":
       客服联系方式来自配置(ENV / config.yaml / 管理台三条路都能灌),
       它一旦拼进 innerHTML 就是一条注入面。这里改为**逐节点 createElement +
       textContent**,比 esc() 拼串更彻底:根本不存在"忘了转义某个位置"这回事。

     ★ 两句首句**逐字未动**。既有 jsdom 冒烟按字面钉着它们(直营站断言不含
       「仅支持卡密」、镜像站断言含),联系方式另起一行追加,互不干扰。

     ★ 联系方式**只会在直营主站出现** —— 不是前端在这里判的,是后端 cs_info()
       在下发时就裁掉了(镜像站响应体里根本没有那几个字段)。前端不复述这条
       判据:多一个判据就多一处两边打架的可能。 */
  if (D.vipCsHint){
    D.vipCsHint.textContent = JF.payOn ? '没有卡密?可' : '本站仅支持卡密开通 · 请';
    const csB = document.createElement('b');
    csB.textContent = '联系客服购买';
    D.vipCsHint.appendChild(csB);
    csAppendTo(D.vipCsHint);          // 未配置 / 非直营站时返回 false 且不改动 DOM
  }
  /* ★ 4.9.9:内容**先就位、再定显隐**(顺序不可颠倒的理由只有一条:读起来
     就是这个因果)。收起态下这一句是写好但不可见的 —— 点开即在,不重算。
     显隐三处(表单 / aria-expanded / 客服提示)统一交给 setVipCardOpen,
     与「我有卡密」的点击共用同一个写入口。 */
  setVipCardOpen(cardOnly);
  // 记录区每次开层都收起(默认不占高度;移动端弹层本就吃紧)
  if (D.vipRecBtn){ D.vipRecBtn.hidden = false; D.vipRecBtn.setAttribute('aria-expanded', 'false'); }
  if (D.vipRecords) D.vipRecords.hidden = true;
  /* 焦点管理:复用项目现成的 openModal / closeModal(它带「归还到屏外元素」的
     门卫,见 onScreen 注)—— 不另造一套。项目对此有明确契约:既有
     frontend_it_jsdom.js 就在断言「Esc 关层 + 焦点归还开启处」。
     落焦点优先给**主行动按钮**:free 档给「立即开通」,其余同理 —— 键盘用户
     一进来就落在能推进的地方,而不是「×」上。 */
  /* 4.2.5 保险(**不是修既发 bug**):inert 由 openPay 置、closePay 撤,
     自审已逐条走通全部关闭路径 —— Esc(handler 先判 payModal 走 closePay)、
     「×」(此时在 inert 子树内点不到)、onVipGranted(先 closePay 再藏层)、
     payExpired(延时 closePay)—— **当前没有可达的泄漏路径**。
     但一旦泄漏,后果是开通门整层点不动(付费页彻底失灵),代价与收益不对称,
     故在唯一的开层入口无条件复位一次。 */
  D.vipGate.inert = false;
  /* ★ 4.4.1:落焦点必须跟着**真正能走通的那条路**走,判据用 cardOnly 而不是 payOn。
     两种失焦都得防,且**都不会报错**:
       ① 镜像站:「立即开通」是 hidden 的。openModal 只对 disabled 做了回落
          (见其 4.2.9 注),对 hidden 元素调 focus() 是静默空操作 ⇒ 整层没落焦点;
       ② 直营站档位为空:「立即开通」是 disabled,openModal 会走
          layer.querySelector(...) 回落 —— 而卡密表单此刻**已展开**,回落抓到谁
          全凭 DOM 文档顺序。实测当前抓的不是输入框(冒烟已钉住这条),但那是
          **碰巧**:任何一次 DOM 重排都可能让它漂到输入框上,而自动弹出的门
          一旦把焦点落进 input,安卓会当场顶起软键盘、把卡片推出视口。
     显式指定,不把结果交给选择器的文档顺序。 */
  openModal(D.vipGate, (cardOnly ? D.vipCardBtn : D.vipBuyBtn) || null);
  /* 与上面的 preventScroll 互补而非重复:preventScroll 到 Safari 15.5 才支持,
     旧内核会静默忽略它;这一行无条件生效,保证任何内核上都从顶部开始看。 */
  D.vipGate.scrollTop = 0;
  document.body.dataset.vipGate = mode;
}
function hideVipGate(){
  if (!D.vipGate) return;
  if (D.vipGate.dataset.mode === 'free') return;   // free 档不可关(关了就是白屏)
  closeModal(D.vipGate);                            // 焦点归还开启处(见 showVipGate 注)
  delete document.body.dataset.vipGate;
}

/* basic 档的受限提示:统一入口,文案如实、不夸张、附一键开通。 */
function vipUpsell(what){
  const M = {
    replay: '「按日回看」是九法VIP功能',
    wide:   '序列全景回放是九法VIP功能',
    pred:   '「下一局预测参考」是九法VIP功能',
    road:   JF.onlineH > 0
      ? `基础档按你在线看到的累计(最长 ${JF.onlineH} 小时),VIP 直接看满 24 小时`
      : `当前从最近 ${JF.histLimit} 局起累计,VIP 可看满 24 小时`,
  };
  /* 4.3.0:补 ms —— toastAction 自己的注释写明「可操作提示 2.4s 点不到,ms 可加长」,
     既有唯一先例「切回」也确实传了 8000;此前这里与临期提醒都漏传,按钮闪没。 */
  toastAction(M[what] || '该功能需要开通九法VIP',
              { label: '去开通', ms: 8000, onClick: () => showVipGate('upsell') });
}

/* 面板角标:basic 档常驻小字,如实说明当前口径。vip / 未启用时恒隐藏。 */
function syncVipNotes(){
  const on = isBasic();
  /* 角标做成**可点** —— 用户在哪看到限制,就能在哪行动。
     这是零新增 UI 面积的可发现性:不加横幅、不弹窗(那才叫突兀),
     但每个受限点本身都成了入口。绑定用幂等守卫,重复调用不会叠加监听。 */
  const set = (id, txt) => {
    const el = document.getElementById(id);
    if (!el) return;
    // 4.4.0:本函数改为随累计量重算(每局一次),加变更守卫免除无谓 DOM 触碰
    if (el.textContent !== txt) el.textContent = txt;
    el.hidden = !on;
    if (on && el.tagName === 'BUTTON' && !el.dataset.bound){
      el.dataset.bound = '1';
      el.title = '点击查看九法VIP能看到什么';
      el.addEventListener('click', () => showVipGate('upsell'));
    }
  };
  /* 4.4.0:窗>0 时口径已不是「本次从 N 局起」,而是「在线累计」——
     角标是用户唯一常驻可见的口径说明,说错就是撒谎。 */
  /* ★ 文案随**已累计量**切换 —— 这不是营销措辞,是准确性问题:
     对一个已经攒到 23 小时的用户说「VIP 直接满 24 小时」几乎等于没说,
     而他此刻真正还没有的是「下一局预测」与「按日回看」。角标是用户唯一常驻
     可见的口径说明,内容必须始终对他成立。
     阈值取窗口的 60%:此前强调**即时性**(你要等,VIP 现在就有);
     之后改为陈述他**仍然缺**的能力。窗=0 时逐字节维持 4.3.x 文案。 */
  const spanH = S.hist.length > 1
    ? (S.hist[0].start - S.hist[S.hist.length - 1].start) / 3600e3 : 0;
  const nearFull = JF.onlineH > 0 && spanH >= JF.onlineH * 0.6;
  const acc = JF.onlineH <= 0
    ? `本次从 ${JF.histLimit} 局起累计 · VIP 看满 24 小时`
    : nearFull
      ? `已累计 ${Math.round(spanH)}h · VIP 另有下一局预测 · 按日回看`
      : `在线累计 · 最长 ${JF.onlineH}h · VIP 直接满 24 小时`;
  set('vipNote-road',   acc);
  set('vipNote-trend',  acc);
  set('vipNote-census', JF.onlineH <= 0
    ? `样本 ${JF.histLimit} 局起累计 · VIP 满窗更准`
    : nearFull
      ? `样本 ${S.hist.length} 局(你在线看到的)· VIP 另有下一局预测`
      : `样本 = 你在线看到的局 · VIP 满窗更准`);
  if (D.predVipBar) D.predVipBar.hidden = !on;
}

/* ── 支付 ─────────────────────────────────────────────────────────────────── */
/* 把网关回来的二维码串变成可用的 data URL。
   **不要硬编码 image/png** —— 真机联调实测(type=tulong)回的是 **JPEG**:
   base64 前缀 `/9j/`、魔数 ff d8 ff。浏览器对 data: URL 多半会嗅探真实类型
   而容忍错误 MIME,但那是运气不是契约(严格 CSP / 个别内核会拒渲染)。
   这里按 base64 魔数前缀判定:`/9j/`=JPEG、`iVBORw0KGgo`=PNG,
   其余回落 png(模拟模式的占位图正是 PNG)。 */
function qrDataUrl(raw){
  const s = String(raw || '');
  if (!s) return '';
  if (s.startsWith('data:')) return s;              // 网关若已给完整 data URL
  const mime = s.startsWith('/9j/') ? 'image/jpeg'
             : s.startsWith('iVBORw0KGgo') ? 'image/png'
             : s.startsWith('R0lGOD') ? 'image/gif'
             : s.startsWith('UklGR') ? 'image/webp'
             : 'image/png';
  return `data:${mime};base64,${s}`;
}

/* 「本机有一笔在途订单尚未确认到账」的标记 —— payRecover 的触发条件。
   **刻意不在 payExpired() 里清**:payExpired 也会被本地宽限计时器触发,
   而「用户扫码已付、网关确认晚到几秒」恰恰长这样;那时清掉标记 =
   把唯一的救回机会一起清掉。只在三种情形清:开通成功 / 网关明确说该单已过期
   未付 / 超过后端回溯窗(24h,救回已无意义)。 */
function payPendMark(orderNo){
  try { store.set(KEY.payPend, JSON.stringify({ o: String(orderNo || ''), t: Date.now() })); }
  catch {}
}
function payPendClear(){ store.remove(KEY.payPend); }

function payStop(){
  clearInterval(PAY.timer); PAY.timer = 0;
  clearInterval(PAY.cdTimer); PAY.cdTimer = 0;
  clearTimeout(PAY.graceTimer); PAY.graceTimer = 0;
  clearTimeout(PAY.closeT); PAY.closeT = 0;
}
function closePay(){
  // 关层 = 轮询停止 = 从此再没有任何人会去问网关「这笔到账没有」。先记下来。
  const pending = !!PAY.orderNo && !PAY.paidHandled;
  payStop();
  /* ★ 必须在 closeModal 之前解除:closeModal 要把焦点还给开通门里的
     「立即开通」,而 inert 的子树是不可聚焦的 —— 顺序反了焦点就丢了。 */
  if (D.vipGate) D.vipGate.inert = false;
  if (D.payModal){
    if (D.payModal.hidden) { /* 已关:不重复归还焦点 */ }
    else closeModal(D.payModal);
  }
  PAY.orderNo = ''; PAY.paidHandled = false;
  /* ★ 4.2.2:这正是 jfpay.py 安全不变量 8 所说的场景 —— 让后端亲自去查一次。
     不 await(不阻塞关层动画),失败静默(本机标记还在,下次开机再试)。
     注:此处 PAY.orderNo 已置空,故 payRecover→onVipGranted→closePay 不会递归。 */
  if (pending) payRecover();
}
function payExpired(){
  payStop();
  if (D.payMask){ D.payMaskText.textContent = '二维码已过期'; D.payMask.hidden = false; }
  if (D.payCountdown) D.payCountdown.textContent = '二维码已过期';
  payMsg('订单已过期,请重新发起');
  /* ★ 4.3.0【真缺陷·实机复现】这曾是**第四个、未被追踪**的定时器:4.2.9 只把
     timer/cdTimer/graceTimer 三个句柄纳入了 payStop,漏了这一枚匿名 setTimeout。
     而上一行红字恰恰在指挥用户「请重新发起」—— 照做(3s 内 × 关层 → 再点
     「立即开通」)的用户,新开的支付层会在二维码已显示后被这枚旧定时器无声关闭
     (真 Chromium 141 实测:B 单开层可见 → 3s 后 hidden,且顺带触发一次
     payRecover 白打后端)。openPay 入口的 payStop() 本就是为清遗留计时器而设的
     纵深防御,句柄不入册它就够不着。现纳入 PAY.closeT,与其余三枚同生共死。 */
  PAY.closeT = setTimeout(closePay, 3000);   // 延迟 3s 再关,让用户看清红字(继承繁星交互)
}

/* ★ 4.2.9【真缺陷·实机复现】连点「立即开通」→ 定时器泄漏 + 焦点错乱。
   原先这里**没有任何在途守卫**(而同文件的 doRedeem 是有 vipCardSubmit.disabled 的
   —— 说明这不是风格取舍,是漏了一处)。按钮按下去零视觉变化,唯一反馈是按钮
   **下方**的 12.5px 灰字「正在生成支付二维码…」;慢网下小白点第二次是默认行为。

   实测(390×844,网关 400ms):点两次 ⇒
     · POST /api/vip/order/create **2 次**(网关按「同账号+同金额」返同一 orderNo,
       第二笔走 _reuse_after_dup 分支⑥复用 —— 所以两次都会成功返回);
     · 第二次 openPay 直接覆盖 PAY.timer / PAY.cdTimer,**第一对 interval 成为孤儿**;
     · closePay 的 payStop() 只清得掉最后一对 ⇒ 关层后孤儿轮询仍以
       `?orderNo=`(closePay 已把 PAY.orderNo 置空)每 2 秒打一次后端,
       后端 _own_order 查不到 → 404,**一直打到用户关页面**(实测 9 秒内 5 次),
       每次还是一条真实的用户库 SQL;倒计时也仍在跳(关层后仍见「剩余 4 分 47 秒」);
     · openModal 被调两次 ⇒ 单槽位的 S._modalOpener 被覆盖成层内的 payClose,
       关层后焦点归还到 railOpen 而不是「立即开通」。

   守卫放在 openPay 内而不是监听器里:这里是唯一的收口点(卡密路径不经过)。
   入口无条件 payStop() 是纵深防御 —— 任何历史遗留计时器在此一并清掉。 */
let _payOpening = false;
async function openPay(planCode){
  if (_payOpening) return;                       // 在途:直接吞掉重复点击
  const plan = (JF.plans || []).find(p => p.code === planCode);
  if (!plan){ vipMsg('请选择一个档位'); return; }
  /* ★ 4.3.0:在**入口处**捕获开启者 —— 此刻第一击刚落、第二击尚未发生,
     activeElement 还是「立即开通」本尊。等到 await 网关归来再让 openModal 去读,
     慢网下用户的第二次物理点击早已穿透 pointer-events:none 把焦点打到 BODY
     (真机探针:第一击后=vipBuyBtn,第二击后=BODY)。Safari 系不给按钮
     click 焦点,activeElement 可能仍是 body —— 回落到 vipBuyBtn 本体,
     它在每条真实路径上都恰是语义上的开启处。 */
  const payOpener = (document.activeElement instanceof HTMLElement
                     && document.activeElement !== document.body)
    ? document.activeElement : (D.vipBuyBtn || null);
  _payOpening = true;
  /* ★ 在途反馈**不能**用 disabled:给当前持焦元素置 disabled 会让它当场失焦到
     document.body,而紧随其后的 openModal 正是靠 document.activeElement 记录
     「开启者」—— 实测探针读到 op=BODY,onScreen(body)恒假 ⇒ 关层后焦点退到
     railOpen 兜底而不是归还「立即开通」。
     改用 data-busy + CSS pointer-events:none:同样点不动、看得出在忙,
     但**不夺焦、不出 Tab 序**。键盘回车路径由上面的 _payOpening 守住。 */
  if (D.vipBuyBtn){
    D.vipBuyBtn.dataset.busy = '1';
    D.vipBuyBtn.setAttribute('aria-busy', 'true');
  }
  payStop();                                     // ★ 清掉任何遗留计时器,杜绝孤儿
  vipMsg('正在生成支付二维码…');
  let d;
  try {
    d = await api('/api/vip/order/create', { method: 'POST',
                                             body: { plan: planCode }, timeout: 20000 });
  } catch (e){
    vipMsg((e && e.data && e.data.message) || '下单失败,请稍后重试');
    return;
  } finally {
    /* finally 覆盖上面的 return 与后续同步段的任何抛出 —— 按钮绝不会卡在禁用态。
       此后到 setInterval 之间**没有 await**,不存在重入窗口;而支付层一旦开起来
       就把开通门整层 inert 了,按钮本身也点不到。 */
    _payOpening = false;
    if (D.vipBuyBtn){
      delete D.vipBuyBtn.dataset.busy;
      D.vipBuyBtn.removeAttribute('aria-busy');
    }
  }
  vipMsg('');
  PAY.orderNo = d.orderNo; PAY.paidHandled = false;
  PAY.ddHours = Number(plan.ddHours) || 0;   // 4.3.1:留给成功 toast 判断赠送真伪(订单状态响应不带 ddHours)
  payPendMark(d.orderNo);          // 4.2.2:从这一刻起,这笔单值得被追回
  PAY.simulate = !!d.simulate;
  PAY.expireAt = Number(d.expireTime) * 1000;
  if (D.payPlan){
    const g = durText(plan.ddHours);
    D.payPlan.textContent = g ? `九法VIP · ${plan.name}(送小叮当 ${g})`
                              : `九法VIP · ${plan.name}`;   // 不赠送时别留个空括号
  }
  if (D.payAmount) D.payAmount.textContent = `¥${Number(d.amount).toFixed(2)}`;
  /* 4.2.9:金额单一真源取的是**网关的 price**,而 JFVIP-SYSTEM.md §6.1.1 的真机
     实测就写着「请求 price=18 → 网关返回 17.99」。于是档位卡写 ¥18、支付页写
     ¥17.99 —— 两个数字对不上却无人解释,小白的第一反应是「被改价 / 被多收」。
     只在真不一致时出这一行(0.005 的判据与后端 _reuse_after_dup 的同价判定一致)。 */
  if (D.payNote){
    const paid = Number(d.amount), listed = Number(plan.price);
    D.payNote.textContent = (Number.isFinite(paid) && Number.isFinite(listed)
                             && Math.abs(paid - listed) >= 0.005)
      ? `档位标价 ¥${priceText(listed)},支付网关本次实际结算 ¥${paid.toFixed(2)},以此金额为准`
      : '';
  }
  if (D.payQr) D.payQr.src = qrDataUrl(d.qrCode);
  if (D.payMask) D.payMask.hidden = true;
  if (D.paySimBtn) D.paySimBtn.hidden = !PAY.simulate;
  payMsg('');
  /* 4.2.3:支付层盖在开通门之上,两层同时挂 aria-modal="true" —— 读屏器的
     转子仍能摸到被盖住的「立即开通 / 我有卡密」。inert 把身后整层移出
     无障碍树与 Tab 序;旧内核不支持时静默降级为原行为。 */
  /* ★ 4.2.9【真因·实机定位】这两行原先是反的:先置 inert、后开层。
     置 inert 会让子树内**当前获得焦点**的元素当场失焦(落到 document.body),
     而紧随其后的 openModal 正是靠 document.activeElement 记录「开启者」——
     于是记下的是 body。关层时 onScreen(body) 恒为假(offsetParent===null),
     焦点便退到 railOpen 兜底,而不是归还给「立即开通」。
     实测佐证:关层前 vipBuyBtn 几何 top:472 / bottom:518 / vh:844 / offsetParent:true
     —— 明明在屏内却拿不到焦点,排除了「滚出视口」这一解释。
     对调后:openModal 在 vipBuyBtn 仍持焦点时捕获开启者,并把焦点交给 payClose
     (它在 payModal 内、不在 vipGate 子树里),随后置 inert 不会误伤它。 */
  if (D.payModal) openModal(D.payModal, D.payClose, payOpener);   // 支付层里唯一可按的就是关闭;开启者用入口捕获值(4.3.0,见上)
  if (D.vipGate) D.vipGate.inert = true;

  // 倒计时:归零**不停轮询**,进入宽限期继续查(网关确认可能比本地倒计时晚几秒)
  const tick = () => {
    const left = PAY.expireAt - Date.now();
    if (left <= 0){
      clearInterval(PAY.cdTimer); PAY.cdTimer = 0;
      if (D.payCountdown) D.payCountdown.textContent = '二维码已过期,正在确认到账…';
      if (D.payMask){ D.payMaskText.textContent = '正在确认到账…'; D.payMask.hidden = false; }
      PAY.graceTimer = setTimeout(payExpired, VIP_PAY_GRACE_MS);
      return;
    }
    const m = Math.floor(left / 60000), sec = Math.floor(left % 60000 / 1000);
    if (D.payCountdown) D.payCountdown.textContent =
      `剩余支付时间:${m} 分 ${String(sec).padStart(2, '0')} 秒`;
  };
  tick(); PAY.cdTimer = setInterval(tick, 1000);

  PAY.timer = setInterval(async () => {
    if (PAY.paidHandled) return;                    // 防并发回调重入(繁星实证)
    try {
      const r = await api(`/api/vip/order/status?orderNo=${encodeURIComponent(PAY.orderNo)}`);
      if (PAY.paidHandled) return;                  // 二次防御:await 期间被别的回调置位
      if (r && r.paid){
        PAY.paidHandled = true; payStop();
        /* 4.3.2 ⑤′:ddHours 由**确知本单**的调用方显式携带 —— 状态响应不带
           该字段,而 onVipGranted 里再兜 PAY.ddHours 会在「跨单救回」时取到
           错单的值(A 弃 dd=0、B 弃 dd>0、A 晚到账被救回 ⇒ 用 B 的值谎称
           赠送)。真话的边界:谁确知订单归属,谁负责携带。 */
        await onVipGranted(Object.assign({}, r, { ddHours: PAY.ddHours }));
        return;
      }
      /* ★ 4.2.9【契约断裂·实机复现】后端 jfpay.query_and_settle 有这条分支:
             网关已确认收款,只是 grant_by_order 那一跳失败(库抖动)
             → return "", {"paid": False, "expired": False, "settling": True}
         而 `settling` 在改前是**全仓库零引用**的(grep 前端零命中)。
         后果实测:倒计时归零 → 「二维码已过期,正在确认到账…」→ 宽限 60s →
         payExpired() 打出红字「**订单已过期,请重新发起**」并关层 —— 一个
         已经把钱付了的人被告知重新下单,照做就是**付两次**。
         这里必须停掉 payExpired 的唯一两个触发者(倒计时与宽限计时),
         轮询继续:后端每次查单都会幂等重试 grant,成功后自然走上面的 paid 分支。
         用户若等不及关层,closePay 的 pending 判据仍成立 → payRecover() 兜底。 */
      if (r && r.settling){
        clearInterval(PAY.cdTimer); PAY.cdTimer = 0;
        clearTimeout(PAY.graceTimer); PAY.graceTimer = 0;
        if (D.payCountdown) D.payCountdown.textContent = '已收到支付,正在为你开通…';
        if (D.payMask){ D.payMaskText.textContent = '已收到支付'; D.payMask.hidden = false; }
        payMsg('已收到你的支付,正在开通,请不要重复付款', true);
        return;
      }
      if (r && r.expired) payExpired();
    } catch { /* 单次查单失败不中断轮询 */ }
  }, VIP_PAY_POLL_MS);
}

/* 开通成功 —— **不 reload**。后端 _grant_tx 提交后已 refresh_tier 清了全网缓存,
   这次重拉打到的每个端点都已是 vip 档,不存在「付了钱还要等 20 秒」的窗口。 */
/* ★ 对账兜底的**唯一**触发者(4.2.2 新增)。
   ── 为什么必须有 ──
   `jfpay.py` 的安全不变量 8 白纸黑字写着「前端轮询停了(关弹窗/切页/最后一次
   请求失败)时,由后端亲自向网关查证把卡住的订单救回来」,而在 4.2.1 里
   `POST /api/vip/order/reconcile` **全仓库无人调用**(前端零引用、管理台零引用、
   无定时任务)。于是:用户扫码付了钱,然后关标签页 / 手机切后台被系统杀 /
   最后一次轮询恰好失败 —— 订单永远停在 pending,九法VIP 与小叮当都不到账,
   且**没有任何自动救回路径**。这是资损,不是体验问题。

   ── 为什么用本机标记,而不是每次开机无脑调 ──
   实读代码确认:被遗弃的 pending 单**不会自动转 expired**(`_mark_expired` 只由
   `query_and_settle` / `reconcile` 调用),会在库里挂满整个 24h 回溯窗;而
   reconcile 单次最多向网关查 `jf_reconcile_max`(默认 10)笔。无脑调 ⇒ 一个弃单
   用户每天开 20 次页面 = 200 次网关请求 —— 正是本项目用 `jf_order_rate_hourly`
   所防的「替人白刷网关」。
   有标记才发请求 ⇒ 从不充值的用户零开销;free 档「一个数据请求都不发」的纪律
   也因此**逐字节不变**(既有 jsdom 钉 NET.data===0 无需改动即通过)。
   服务端另有 `jfvip.reconcile_rate_ok` 限频,防手搓客户端绕过本机标记。 */
let _payRecovering = false;
async function payRecover(){
  if (!JF.on) return;
  /* 复审补:两个触发点可能重叠 —— 开机那次尚在飞行中(最长 30s),用户已经
     开了支付层又关掉。没有守卫就会并发打两次网关,并可能重入 onVipGranted。 */
  if (_payRecovering) return;
  let mark = null;
  try { mark = JSON.parse(store.get(KEY.payPend) || 'null'); } catch { mark = null; }
  /* ★ 严格由本机标记驱动,**没有标记就一个请求都不发**。
     曾试过加「每台设备一次性补扫」以覆盖升级前的存量在途单,实测它会打破
     free 档「一个数据请求都不发」这条纪律(jsdom 最硬的一条当场变红),
     而收益近乎为零 —— 见 JFVIP-SYSTEM.md §10 第 5 条:真实支付回调**从未跑通过**,
     也就不存在"升级前已付未到账"的存量。用永久的客户端代价换一个空集合,
     是坏交易;一次性迁移属于运维动作,不该长在每台设备上。 */
  if (!mark || !mark.t) return;
  if (Date.now() - Number(mark.t) > 86400000){ payPendClear(); return; }   // 超回溯窗
  _payRecovering = true;
  try {
    /* 超时给足:后端最坏要逐笔查 10 次网关(每笔 6s)。即便前端超时也无妨 ——
       救回动作在服务端已经完成,本机标记留着,下次开机就会看到已是 VIP。 */
    const r = await api('/api/vip/order/reconcile',
                        { method: 'POST', body: {}, timeout: 30000 });
    if (r && Number(r.recovered) > 0){
      payPendClear();
      toast('已确认到账,九法VIP 已开通');
      await onVipGranted({});
    } else if (r && Number(r.expired) > 0 && !Number(r.recovered)){
      payPendClear();      // 网关明确说这单未付且已过期 —— 无可救回,不必再试
    } else if (r && Number(r.candidates) === 0){
      /* 库里根本没有待救回的单 ⇒ 本机标记已陈旧(典型成因:另一个标签页把它
         轮询结算掉了)。不清的话,这个标记会让**每次开机都白发一次 POST**、
         连发 24 小时,还会吃掉 reconcile 的限频配额,掩盖后续真正需要的救回。
         注意必须用 candidates 而不是 checked:checked=0 也可能是「有单但网关
         全查失败」,那种情况标记**必须留着**下次再试。
         旧后端无此字段 → Number(undefined)=NaN ≠ 0 → 保持原行为,向后兼容。 */
      payPendClear();
    }
  } catch { /* 静默:标记还在,下次开机/下次关层再试 */ }
  finally { _payRecovering = false; }
}

async function onVipGranted(res){
  /* 4.3.1 ⑤:成败文案要在**改写 tier 之前**看清来路 —— 已是 VIP 的人这次是
     「续费」,再对他说「开通成功!已解锁全部功能」既不合事实(本就全解锁)
     又与 9.10「对已付费用户说开通是错的」相抵。 */
  const wasVip = JF.tier === 'vip';
  JF.tier = 'vip';
  payPendClear();          // 4.2.2:已到账,标记完成使命
  /* 复审补:记录区是「首次展开才拉」的,不失效的话 —— 用户开通前看过一次记录、
     开通后再展开,看到的还是**没有这次开通**的旧列表,像是"没买成"。 */
  VIP_REC_LOADED = false;
  if (D.vipRecords){ D.vipRecords.hidden = true; D.vipRecords.innerHTML = ''; }
  if (D.vipRecBtn) D.vipRecBtn.setAttribute('aria-expanded', 'false');
  JF.vipUntil = (res && res.vipUntil) || JF.vipUntil;
  if (res && res.dueTime && AUTH.user) AUTH.user.dueTime = res.dueTime;
  try {
    const st = await api('/api/vip/state', { timeout: 8000 });
    JF.vipDays = (st && st.jfVipDays != null) ? Number(st.jfVipDays) : JF.vipDays;
    if (st && st.ddDueTime && AUTH.user){
      AUTH.user.dueTime = st.ddDueTime;
      AUTH.user.dueDays = Math.max(0, Math.round(
        (new Date(st.ddDueTime).getTime() - Date.now()) / 86400000));
    }
  } catch {}
  document.body.dataset.jfTier = 'vip';
  closePay();
  /* 4.3.1 ⑥:门在开着时走 closeModal 关 —— 直接 hidden=true 会把「焦点归还
     开启处」的契约整段跳过:closePay 刚把焦点还给门内的「立即开通/续费」,
     紧接着门一藏,焦点就掉到 body(键盘用户凭空失位)。closeModal 消费本层
     WeakMap 里的开启者,升级/续费回 ucBuy,free 档(开启者为空)落 railOpen。
     dataset.vipGate 的清理照旧由本函数负责(closeModal 不管 body 标记)。 */
  if (D.vipGate){
    D.vipGate.dataset.mode = 'upsell';
    if (!D.vipGate.hidden) closeModal(D.vipGate);
  }
  delete document.body.dataset.vipGate;
  renderAuthChip();
  syncVipNotes();
  /* 4.3.3:basic→vip 翻转会改变出怪规律头形态(静态角标行退场,data-jf-tier 选择器
     即时切回 absolute)与 crh 预算(NOTE_H 归零)。无 force 调用只重算几何、
     重置 --crh,不走 renderAll —— 付款成功路径零额外重绘。 */
  applyLayout();
  /* 4.3.1 ⑤:赠送只在**真的送了**才说 —— test_zero_gift_plan… 的判据原文:
     「原先三处无条件拼接全部出错…付费页上说假话是最不能忍的一类」。那轮修了
     档位卡/支付弹层/总说明三处,这条成功 toast 是漏网的第四处:ddHours=0 的
     档位付完款仍被告知「已赠送同时长小叮当会员」。真源:卡密路径响应自带
     ddHours(_grant_tx 透传);订单两条路径由调用方显式携带 PAY.ddHours
     (4.3.2 ⑤′,见轮询处注);对账救回路径 res={} —— 该路径**不确知**救回的
     是哪张单,兜 PAY.ddHours 会在跨单救回时拿错单的值谎称赠送,故宁可省略:
     少说一句真话可以,多说一句假话不行。 */
  const dd = Number(res && res.ddHours) || 0;
  const gift = dd > 0 ? ',并已赠送同时长小叮当会员' : '';
  toast(wasVip ? `续费成功!时长已从原到期日顺延${gift}`
               : `开通成功!已解锁全部功能${gift}`);
  // 重拉满窗数据(basic 档时被钳到 N 局,现在要拿全量)
  const alias = S.alias || (S.rooms[0] && String(S.rooms[0].alias)) || '';
  if (alias) loadRoom(alias, { silent: false, explicit: true });
  else dataBoot();
}

async function doRedeem(ev){
  if (ev) ev.preventDefault();
  const raw = (D.vipCardInput && D.vipCardInput.value) || '';
  if (!raw.trim()){ vipMsg('请输入卡密'); return; }
  if (D.vipCardSubmit) D.vipCardSubmit.disabled = true;
  vipMsg('正在兑换…');
  try {
    const r = await api('/api/vip/redeem', { method: 'POST',
                                             body: { card: raw }, timeout: 20000 });
    vipMsg('兑换成功', true);
    await onVipGranted(r);
  } catch (e){
    // 后端已给出**可操作**的提示(如「卡密不含 0/1/I/O,请核对」),原样透出
    vipMsg((e && e.data && e.data.message) || '兑换失败,请核对卡密');
    /* 4.3.1 ⑦:提交按钮用 disabled 置忙 —— 点击路径下按钮失焦到 body(4.2.9
       对「立即开通」弃用 disabled 的同一原因)。失败后把焦点还给输入框:
       正是用户要改的地方;成功路径的焦点由 onVipGranted→closeModal 按契约归还。 */
    if (D.vipCardInput && D.vipCardForm && !D.vipCardForm.hidden){
      try { D.vipCardInput.focus(); } catch {}
    }
  } finally {
    if (D.vipCardSubmit) D.vipCardSubmit.disabled = false;
  }
}

/* VIP 临期提醒:≤3 天时一次轻提示 + 直达续费。
   为什么需要:到期是**静默**的 —— 某天打开页面,序列忽然只剩 30 局、推演变成锁,
   用户会以为系统坏了而不是"我到期了"。顶栏身份牌虽然会转警示色,但那是被动的。
   纪律:**每次页面生命周期至多一次**,且用 toastAction(可一键去续费、不阻断)。
   不做弹窗、不做每日轮询 —— 那是骚扰,不是提醒。 */
/* 我的开通记录(4.2.2 新增)。
   后端 `/api/vip/orders` 在 4.2.0 就实现了(orders 流水 + grants 流水,与管理台
   「开通流水」同一口径),但前端**零引用** —— 付了钱的用户查不到自己买过什么、
   到期到哪天,更无法自查「我付了钱怎么没开通」。对一个收费产品,这是基础信任设施。
   取两张表而不是只取 grants:grants 是唯一对账口径(含卡密与管理员开通),
   而 orders 额外给出**没到账**的单 —— 那正是用户最需要看见的一类。 */
let VIP_REC_LOADED = false;
const VIP_REC_SRC = { order: '在线充值', card: '卡密兑换',
                      admin: '管理员开通', revoke: '管理员撤销' };
const recTime = v => String(v || '').replace('T', ' ').slice(0, 16);

async function loadVipRecords(){
  if (!D.vipRecords) return;
  D.vipRecords.innerHTML = '<p class="vr-empty">正在读取…</p>';
  let r;
  try { r = await api('/api/vip/orders', { timeout: 12000 }); }
  catch { D.vipRecords.innerHTML = '<p class="vr-empty">读取失败,请稍后重试</p>'; return; }
  /* 时长带符号。★ 复审补:`revoke_by_admin` 往流水里写的是 **-abs(hours)**,
     而 durText(h<=0) 恒回空串 —— 直接拼会渲染成「九法VIP +」这样的断句,
     且给撤销记录标了个「+」号,语义正好相反。 */
  const signed = h => {
    const n = Number(h) || 0;
    if (!n) return '';
    return (n > 0 ? '+' : '−') + durText(Math.abs(n));
  };
  const rows = ((r && r.grants && r.grants.items) || []).map(g => ({
    t: g.createdAt || '',
    title: VIP_REC_SRC[g.source] || g.source || '开通',
    sub: `九法VIP ${signed(g.jfHours)}`
       + (g.ddHours ? ` · 小叮当 ${signed(g.ddHours)}` : '')
       + (g.vipAfter ? ` · 到期 ${recTime(g.vipAfter)}` : ''),
    amt: Number(g.amount) > 0 ? `¥${Number(g.amount).toFixed(2)}` : '—',
    bad: Number(g.jfHours) < 0,
  }));
  ((r && r.orders && r.orders.items) || []).filter(o => !o.credited).forEach(o => rows.push({
    t: o.createTime || '', title: '在线充值',
    sub: o.status === 'expired' ? '未支付,已过期' : '待支付 / 待确认到账',
    amt: `¥${Number(o.amount).toFixed(2)}`, bad: true,
  }));
  rows.sort((a, b) => String(b.t).localeCompare(String(a.t)));
  D.vipRecords.innerHTML = rows.length
    ? rows.slice(0, 30).map(x => `
      <div class="vr-row">
        <span class="vr-k">${esc(x.title)}</span>
        <span class="vr-amt${x.bad ? ' vr-bad' : ''}">${esc(x.amt)}</span>
        <span class="vr-sub${x.bad ? ' vr-bad' : ''}">${esc(recTime(x.t))} · ${esc(x.sub)}</span>
      </div>`).join('')
    : '<p class="vr-empty">还没有开通记录</p>';
}

/* 游戏入口显隐的**唯一**出入口 —— 成对操作,杜绝"只藏不显"。 */
function setGameEntriesVisible(on){
  if (D.realGameOpen) D.realGameOpen.hidden = !on;
  if (D.jiufaOpen) D.jiufaOpen.hidden = !on;
}

function vipExpiryNudge(){
  if (!(JF.on && JF.tier === 'vip')) return;
  const d = vipDaysNum();
  // null(未知)绝不能当 0 —— 否则刚付完钱的人会被告知「今日到期,去续费」
  if (d === null || d > 3) return;
  /* 4.3.0:补 ms:8000(同 vipUpsell 注)。本提醒每页面生命周期至多一次,
     2.4s 即灭等于形同虚设 —— 真机时序采样确证按钮存续不足以完成一次点按。 */
  /* 4.9.0:同样占用本次开机的提示位。此前 vipExpiryNudge 与 roomIntro 都在
     dataBoot() 里同步执行,而 S._bootToast 护栏只覆盖 jfIntro↔roomIntro 一对 ——
     于是「VIP 还有 N 天到期」会被房间说明覆盖,而房间说明的"已看过"已经落盘。
     两侧都占位 + onShown 落盘后,这条链路彻底闭合。 */
  S._bootToast = true;
  toastAction(d <= 0 ? '九法VIP 今日到期' : `九法VIP 还有 ${d} 天到期`,
              { label: '去续费', ms: 8000, onClick: () => showVipGate('renew') });
}

function bindVip(){
  if (D.ucBuy) D.ucBuy.addEventListener('click', () => showVipGate('upsell'));
  if (D.vipClose) D.vipClose.addEventListener('click', hideVipGate);
  // free 档的唯一出口:壳被 pointer-events:none 禁用,顶栏「退出」点不到 ——
  // 用错账号登进来的人必须能换号,否则被彻底锁死在本页。
  if (D.vipLogout) D.vipLogout.addEventListener('click', doLogout);
  if (D.vipBuyBtn) D.vipBuyBtn.addEventListener('click', () => openPay(pickedPlan()));
  if (D.vipCardBtn) D.vipCardBtn.addEventListener('click', () => {
    if (!D.vipCardForm) return;
    /* 取反即切换。表单显隐 / aria-expanded / 客服提示三者由 setVipCardOpen 一并置位
       (4.9.9:提示与表单同开同收 —— 见该函数注)。 */
    setVipCardOpen(D.vipCardForm.hidden);
    // 用户主动点开的这条路仍照旧 focus 输入框(与自动弹门的取舍不同,见 showVipGate 注)
    if (!D.vipCardForm.hidden && D.vipCardInput) D.vipCardInput.focus();
  });
  if (D.vipCardForm) D.vipCardForm.addEventListener('submit', doRedeem);
  if (D.vipRecBtn) D.vipRecBtn.addEventListener('click', () => {
    if (!D.vipRecords) return;
    const open = D.vipRecords.hidden;
    D.vipRecords.hidden = !open;
    D.vipRecBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open && !VIP_REC_LOADED){ VIP_REC_LOADED = true; loadVipRecords(); }
  });
  if (D.payClose) D.payClose.addEventListener('click', closePay);
  if (D.paySimBtn) D.paySimBtn.addEventListener('click', async () => {
    try {
      const r = await api(`/api/vip/order/simulate-pay?orderNo=${encodeURIComponent(PAY.orderNo)}`,
                          { method: 'POST', body: {} });
      PAY.paidHandled = true; payStop();
      await onVipGranted(Object.assign({}, r, { ddHours: PAY.ddHours }));   // 4.3.2 ⑤′:同轮询处注
    } catch (e){ payMsg((e && e.data && e.data.message) || '模拟支付失败'); }
  });
  if (D.predVipBar) D.predVipBar.addEventListener('click', () => showVipGate('upsell'));
  // Esc 关(free 档不可关,hideVipGate 内部已判)
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape'){
      if (D.payModal && !D.payModal.hidden){ closePay(); return; }
      if (D.vipGate && !D.vipGate.hidden) hideVipGate();
    }
  });
}

/* ═══════════ 链接快速登录(4.1.0,SSO)═══════════
   同库其它项目(续费/管理系统)确认身份后签发一次性票据,链接形如
   https://观测台/#sso=<64位hex>。票据走 **URL 片段**(# 后内容浏览器不发给
   服务器 —— 不进访问日志、不进 Referer、链接预览爬虫抓不到),boot 在鉴权前:
   ① 读到即 replaceState 清片段(与 ?room= 同款「只消费一次」纪律 —— 刷新/
      后台标签重载不会拿同一票据反复撞后端);
   ② POST /api/auth/sso 兑换正式会话 Cookie(后端单语句原子核销,单次有效);
   ③ 已登录**另一账号**时后端回 409 switch_confirm(不消费票据)—— 弹确认,
      同意才带 allowSwitch 重试,防「点了他人链接被静默换号」;
   ④ 成功后不 reload:此刻 authInit 尚未运行、未发生任何用户级读写,直接
      继续启动即以新会话进入(与登录后 reload 收束的语义等价但省一跳)。
   失败不阻断启动 —— 登录门照常拉起,失败原因摆在门上;后端未启用时静默略过。 */
const SSO_FAIL_TEXT = {
  bad_ticket: '快速登录链接已失效或已使用,请回到来源页面重新进入',
  throttled: '尝试过于频繁,请稍后再试',
  banned: '该账号已被停用,请联系管理员',
  expired: '账号已到期,请续费后再登录',
  sso_disabled: '本部署未启用链接快速登录,请直接输入账号密码',
  login_disabled: '本部署未启用登录系统',
  userdb_unavailable: '用户库暂时不可用,请稍后重试',
  bad_origin: '请求来源校验未通过,请直接输入账号密码登录',
};

async function ssoConsume(){
  const m = /(?:^|[#&])sso=([0-9a-fA-F]{64})(?:&|$)/.exec(location.hash || '');
  if (!m) return '';
  const ticket = m[1].toLowerCase();
  try { history.replaceState(null, '', location.pathname + location.search); } catch {}
  let body = { ticket };
  for (let i = 0; i < 2; i++){
    try {
      const d = await api('/api/auth/sso', { method: 'POST', body, timeout: 15000 });
      if (d && d.switched && d.user) toast(`已切换为「${(d.user.userName || '')}」`);
      return '';
    } catch (e){
      const dd = (e && e.data) || {};
      if (dd.error === 'switch_confirm' && i === 0){
        const yes = confirm(`当前已登录「${dd.current || ''}」。\n要切换为「${dd.target || ''}」吗?`);
        if (!yes) return '';                       // 保持当前账号;票据未被消费,自然过期
        body = { ticket, allowSwitch: true };
        continue;
      }
      return dd.message || SSO_FAIL_TEXT[dd.error] || '快速登录失败,请重试或直接输入账号密码登录';
    }
  }
  return '';
}

/* 4.3.4:补上「页面不重载」那条路。
   浏览器规则:目标 URL 与当前文档**只有 # 后不同**时,不做导航、不重新加载,
   只改 location.hash 并派发 hashchange。于是这两种真实场景会「按了没反应」:
     ① 人已经停在观测台(如登录门),把 https://观测台/#sso=<票据> 粘进地址栏回车;
     ② 来源站在**同一标签页**里执行 location.href = 那条链接,而该标签页恰好
        已经打开着观测台同一路径。
   (从别的域名跳过来是跨文档导航,一律真实加载 —— 那条路本来就好使,不受影响。)
   boot() 里的 ssoConsume() 只跑一次,页面不重载它就再没机会执行 —— 本监听即那一刀。

   纪律:
     · 复用同一个 ssoConsume():读到即 replaceState 清片段,「单次消费」逐字节不变;
     · replaceState **不会**触发 hashchange(规范如此),故不存在自我循环;
     · 成功后必须 location.reload() —— 此刻 boot() 早已跑完、应用可能正处于锁定态,
       只有重载才能带着新会话把整个应用重建(片段已被清掉,重载不会二次消费);
     · SSO_BUSY 防抖:连点/连粘时同一时刻只在飞一发;
     · 失败按当前是否在登录门,分别摆 #authMsg / toast —— 与 boot() 的既有语义同款。 */
let SSO_BUSY = false;

function bindSsoHashChange(){
  if (window.__ssoHashBound) return;      // 幂等:boot 万一被重入也只绑一次
  window.__ssoHashBound = true;
  window.addEventListener('hashchange', async () => {
    if (!/(?:^|[#&])sso=[0-9a-fA-F]{64}(?:&|$)/.test(location.hash || '')) return;
    if (SSO_BUSY) return;
    SSO_BUSY = true;
    try {
      const msg = await ssoConsume();
      if (!msg){ location.reload(); return; }
      if (AUTH.enabled && !AUTH.user) setAuthMsg(msg);
      else { try { toast(msg); } catch {} }
    } finally { SSO_BUSY = false; }
  });
}

/* ═══════════ 注册系统(4.0.0)═══════════
   同一张 auth-card 的注册态。防线纵深 R0–R8 见 REGISTER-SYSTEM.md;前端职责:
   ① 仅当 session.reg.mode ≠ off 才渲染入口(旧后端无字段 → 恒隐藏);
   ② 打开注册表单时即取挑战(填表时长从挑战签发起算 —— R4 最短填表;提交时才
      解 PoW,避免「解题耗时被当填表时长」的误伤);
   ③ 提交链:powAnswer(salt) 在**主线程**跑(执行证明:必须执行本站混淆 JS)→
      prefix 交给内联 Worker 纯 JS SHA-256 穷举 nonce(刻意不用 crypto.subtle:
      安全上下文外整段失效,内网 http 部署会翻车)→ POST /api/auth/register;
   ④ 字段级即时校验只做体验,后端才是闸(密码规则:5–16 位,无组合限制)。 */
const REG = { mode: 'off', captcha: null, chal: null, worker: null, jobs: {}, seq: 0,
              solving: false, capToken: '', capMounted: false, mounting: null, fp: '' };
/* 5.2.0 登录加码 / 登录人机验证的前端状态(见 doLogin 与下方 login* 函数) */
const LOGIN = { captcha: null, mode: 'off', capToken: '', capMounted: '', widgetId: null,
                gt: null, waiters: [], solving: false, mounting: null };

/* 内联求解 Worker(Blob 构造,零新增静态资源)。**自包含字符串**:混淆器的
   string-array 编码在运行时还原原文,Worker 内不依赖外层任何符号 —— 这是它在
   混淆包里活下来的前提。标记注释供 tests/test_register.py 抠源码做 JS↔Python
   活体对拍(与 test_proof_of_browser 同手法);内容避开反引号与 ${},原文即真值。 */
const JF_REG_WORKER_SRC = /*__JF_REG_WORKER_BEGIN__*/`'use strict';
var K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
var HS = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
var W = new Int32Array(64);
function compress(h, blk, off){
  var t, x, y, s0, s1;
  for (t = 0; t < 16; t++){
    var o = off + t * 4;
    W[t] = ((blk[o] << 24) | (blk[o+1] << 16) | (blk[o+2] << 8) | blk[o+3]) | 0;
  }
  for (t = 16; t < 64; t++){
    x = W[t-15]; y = W[t-2];
    s0 = (((x >>> 7) | (x << 25)) ^ ((x >>> 18) | (x << 14)) ^ (x >>> 3)) | 0;
    s1 = (((y >>> 17) | (y << 15)) ^ ((y >>> 19) | (y << 13)) ^ (y >>> 10)) | 0;
    W[t] = (W[t-16] + s0 + W[t-7] + s1) | 0;
  }
  var a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
  for (t = 0; t < 64; t++){
    var S1 = (((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7))) | 0;
    var ch = ((e & f) ^ (~e & g)) | 0;
    var t1 = (hh + S1 + ch + K[t] + W[t]) | 0;
    var S0 = (((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10))) | 0;
    var mj = ((a & b) ^ (a & c) ^ (b & c)) | 0;
    var t2 = (S0 + mj) | 0;
    hh = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
  }
  h[0] = (h[0] + a) | 0; h[1] = (h[1] + b) | 0; h[2] = (h[2] + c) | 0; h[3] = (h[3] + d) | 0;
  h[4] = (h[4] + e) | 0; h[5] = (h[5] + f) | 0; h[6] = (h[6] + g) | 0; h[7] = (h[7] + hh) | 0;
}
function sha256Bytes(msg){
  var l = msg.length, total = (((l + 9 + 63) >> 6) << 6);
  var pad = new Uint8Array(total);
  pad.set(msg); pad[l] = 0x80;
  var bits = l * 8;
  pad[total-4] = (bits >>> 24) & 255; pad[total-3] = (bits >>> 16) & 255;
  pad[total-2] = (bits >>> 8) & 255;  pad[total-1] = bits & 255;
  var h = HS.slice(0);
  for (var i = 0; i < total; i += 64) compress(h, pad, i);
  var out = new Uint8Array(32);
  for (var j = 0; j < 8; j++){
    out[j*4] = (h[j] >>> 24) & 255; out[j*4+1] = (h[j] >>> 16) & 255;
    out[j*4+2] = (h[j] >>> 8) & 255; out[j*4+3] = h[j] & 255;
  }
  return out;
}
function hex(u8){
  var s = '';
  for (var i = 0; i < u8.length; i++) s += (u8[i] + 256).toString(16).slice(1);
  return s;
}
function leadZeroBits(u8){
  var n = 0;
  for (var i = 0; i < u8.length; i++){
    var b = u8[i];
    if (b === 0){ n += 8; continue; }
    while (!(b & 0x80)){ n++; b = (b << 1) & 255; }
    return n;
  }
  return n;
}
var enc = new TextEncoder();
self.onmessage = function(ev){
  var d = ev.data || {};
  if (d.type === 'sha256'){
    self.postMessage({ id: d.id, hex: hex(sha256Bytes(enc.encode(String(d.text || '')))) });
    return;
  }
  if (d.type !== 'solve') return;
  var prefix = String(d.prefix || ''), bits = d.bits | 0, id = d.id;
  var pre = enc.encode(prefix + ':');
  // 消息恒 ≤ 27 字节(16 hex + ':' + ≤10 位十进制)< 56 → 单块快路径:复用一块
  // 64B 缓冲,穷举循环零分配(低端手机也扛得住);超长兜底走通用路径(不该发生)。
  var single = pre.length + 12 <= 55;
  var blk = new Uint8Array(64), h = new Int32Array(8);
  if (single) blk.set(pre);
  var n = 0, tried = 0;
  // 期望尝试次数 = 2^bits(几何分布均值)。进度按此折算百分比 —— 报「已算多少万次」
  // 对用户没有意义(不知道总数是多少);上报约 25 次,足够平滑又不刷爆 postMessage。
  var expect = Math.pow(2, bits), step = Math.max(4096, Math.round(expect / 25));
  for (;;){
    var ns = '' + n, dg;
    if (single){
      var L = pre.length + ns.length;
      for (var k = 0; k < ns.length; k++) blk[pre.length + k] = ns.charCodeAt(k);
      blk[L] = 0x80;
      for (var z = L + 1; z < 62; z++) blk[z] = 0;
      var bits8 = L * 8;
      blk[62] = (bits8 >>> 8) & 255; blk[63] = bits8 & 255;
      h[0]=HS[0];h[1]=HS[1];h[2]=HS[2];h[3]=HS[3];h[4]=HS[4];h[5]=HS[5];h[6]=HS[6];h[7]=HS[7];
      compress(h, blk, 0);
      dg = new Uint8Array(32);
      for (var j = 0; j < 8; j++){
        dg[j*4] = (h[j] >>> 24) & 255; dg[j*4+1] = (h[j] >>> 16) & 255;
        dg[j*4+2] = (h[j] >>> 8) & 255; dg[j*4+3] = h[j] & 255;
      }
    } else {
      dg = sha256Bytes(enc.encode(prefix + ':' + ns));
    }
    tried++;
    if (leadZeroBits(dg) >= bits){ self.postMessage({ id: id, nonce: ns, tried: tried }); return; }
    n++;
    if ((tried % step) === 0)
      self.postMessage({ id: id, progress: tried, expect: expect });
  }
};`/*__JF_REG_WORKER_END__*/;

function regWorker(){
  if (REG.worker) return REG.worker;
  const blob = new Blob([JF_REG_WORKER_SRC], { type: 'text/javascript' });
  REG.worker = new Worker(URL.createObjectURL(blob));
  REG.worker.onmessage = ev => {
    const d = ev.data || {}, job = REG.jobs[d.id];
    if (!job) return;
    if (d.progress != null){
      try { job.onProgress && job.onProgress(d.progress, d.expect); } catch {}
      return;
    }
    delete REG.jobs[d.id];
    job.resolve(d);
  };
  return REG.worker;
}
function regWorkerCall(payload, onProgress){
  return new Promise(resolve => {
    const id = ++REG.seq;
    REG.jobs[id] = { resolve, onProgress };
    regWorker().postMessage({ ...payload, id });
  });
}
async function regFingerprint(){
  // R8:极轻量指纹源,本地 SHA-256 只传前 16 位 hex;失败即空(线索不判决)。
  if (REG.fp) return REG.fp;
  try {
    let cv = '';
    try {
      const c = document.createElement('canvas'); c.width = 64; c.height = 16;
      const g = c.getContext('2d');
      g.textBaseline = 'top'; g.font = '12px sans-serif';
      g.fillStyle = '#f60'; g.fillRect(0, 0, 64, 16);
      g.fillStyle = '#069'; g.fillText('九法jf40', 2, 2);
      cv = c.toDataURL().slice(-64);
    } catch {}
    const sig = [navigator.userAgent, navigator.language,
                 Intl.DateTimeFormat().resolvedOptions().timeZone || '',
                 screen.width + 'x' + screen.height + 'x' + (devicePixelRatio || 1),
                 cv].join('|');
    const r = await regWorkerCall({ type: 'sha256', text: sig });
    REG.fp = String(r.hex || '').slice(0, 16);
  } catch { REG.fp = ''; }
  return REG.fp;
}

/* 注册端点用单发 fetch(不走 api():其 GET 对 429/5xx 自动重试会白烧挑战签发
   配额;/api/auth/ 前缀天然豁免会话与 CSRF 头,无需任何附加机制)。 */
async function regApi(path, opt = {}){
  const ctl = new AbortController();
  const tid = setTimeout(() => ctl.abort(), opt.timeout || 12000);
  try {
    const res = await fetch(path, {
      method: opt.method || 'GET', signal: ctl.signal,
      headers: opt.body ? { 'Content-Type': 'application/json' } : {},
      body: opt.body ? JSON.stringify(opt.body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) throw Object.assign(new Error(data.error || ('HTTP ' + res.status)), { status: res.status, data });
    return data;
  } finally { clearTimeout(tid); }
}

async function ensureRegChallenge(force){
  const now = Date.now();
  if (!force && REG.chal && now < REG.chal.expAt) return REG.chal;
  const fp = await regFingerprint();
  const d = await regApi('/api/auth/register/challenge' + (fp ? ('?fp=' + fp) : ''));
  REG.chal = { cid: d.challengeId, salt: d.salt, bits: d.bits | 0,
               minFillS: d.minFillS | 0, issuedAt: now,
               expAt: now + Math.max(30, (d.ttl | 0) - 10) * 1000 };
  if (d.mode && d.mode !== REG.mode){ REG.mode = d.mode; regApplyMode(); }
  return REG.chal;
}

function setRegMsg(t, ok){
  if (!D.regMsg) return;
  D.regMsg.textContent = t || '';
  if (ok) D.regMsg.dataset.ok = '1'; else delete D.regMsg.dataset.ok;
}
function regApplyMode(){
  if (D.authToReg) D.authToReg.hidden = !(AUTH.enabled && REG.mode !== 'off');
  if (D.regInviteWrap) D.regInviteWrap.hidden = REG.mode !== 'invite';
}
function regClearFields(){
  // 4.0.1:注册成功后清空表单 —— 此前旧值残留,零赠送用户「返回登录→再开注册」
  // 会带着已注册的用户名再提交,必吃 name_taken;口令也不应滞留在 DOM 里。
  // 蜜罐(regContact)不动:真人路径本就恒空,清它反而抹掉脚本已填的证据。
  for (const el of [D.regUser, D.regPass, D.regPass2, D.regInvite]){
    if (!el) continue;
    el.value = '';
    if (el.type === 'text' && (el === D.regPass || el === D.regPass2)) el.type = 'password';
  }
  for (const b of (D.regForm ? D.regForm.querySelectorAll('.pw-eye.on') : [])){
    b.classList.remove('on');
    b.setAttribute('aria-pressed', 'false');
    b.setAttribute('aria-label', '显示密码');
  }
}
function regShowLogin(){
  const card = D.authGate && D.authGate.querySelector('.auth-card');
  if (card) card.dataset.mode = 'login';
  if (D.authTitle) D.authTitle.textContent = '小叮当九法登录';
  if (D.authForm) D.authForm.hidden = false;
  if (D.regForm) D.regForm.hidden = true;
  if (D.regDone) D.regDone.hidden = true;
  if (D.regBack) D.regBack.hidden = true;
  regApplyMode();
  // 5.2.0:运营选了「每次登录都要人机验证」→ 开门即预挂挂件,用户输完密码时令牌已就绪
  if (LOGIN.mode === 'always' && LOGIN.captcha) loginMountCaptcha(LOGIN.captcha).catch(() => {});
}
function regShow(){
  const card = D.authGate && D.authGate.querySelector('.auth-card');
  if (card) card.dataset.mode = 'reg';
  if (D.authTitle) D.authTitle.textContent = '注册账号';
  if (D.authSub) D.authSub.textContent = '';
  if (D.authForm) D.authForm.hidden = true;
  if (D.regDone) D.regDone.hidden = true;
  if (D.regForm) D.regForm.hidden = false;
  if (D.authToReg) D.authToReg.hidden = true;
  if (D.regBack) D.regBack.hidden = false;
  setRegMsg('');
  // 打开表单即取挑战:填表时长从签发起算(R4);顺带预热求解 Worker 与验证码挂件
  ensureRegChallenge().then(() => regMountCaptcha()).catch(e => {
    const d = (e && e.data) || {};
    setRegMsg(d.message || REG_ERR[d.error] || '安全校验初始化失败,提交时将自动重试');
  });
  setTimeout(() => { try { D.regUser && D.regUser.focus(); } catch {} }, 60);
}
const REG_ERR = {
  register_disabled: '本部署未开放注册',
  register_closed: '注册暂时关闭,请稍后再试',
  register_unavailable: '注册暂时不可用,请稍后重试',
  throttled: '操作过于频繁,请稍后再试',
  challenge_required: '安全校验已过期,请重试',
  challenge_expired: '安全校验已过期,请重试',
  pow_failed: '安全校验未通过,请重试',
  captcha_failed: '人机验证未通过,请重试',
  captcha_unavailable: '人机验证暂不可用,请稍后重试',
  invite_required: '本站注册需要邀请码',
  invite_invalid: '邀请码无效,请核对后重试',
  invite_exhausted: '邀请码已用尽',
  invite_expired: '邀请码已过期',
  name_invalid: '用户名不合规',
  name_reserved: '该用户名不可用,请更换一个',
  name_taken: '该用户名已被使用,请更换',
  password_invalid: '密码需为 5–16 位字符',
  bad_origin: '请求来源校验未通过',
  bad_request: '注册失败,请稍后重试',
};

/* R3 人机验证挂件(默认关;供应商脚本按需加载,主包零依赖)。
   turnstile / geetest 预先渲染进 #regCaptchaBox 收集 token;tencent 为弹窗式,
   提交时按需唤起。任一供应商脚本加载失败 → 提交时后端 fail-closed 会把话说清。 */
/* 外链脚本按 src 去重(5.2.0 复查):注册与登录共用一家验证码后,同一页可能两处都要它。
   同一 api.js 加载两次,Turnstile 会报重复加载并可能重建全局 turnstile 对象,先挂的挂件随之
   失联。加载失败则撤销缓存并移除标签,下次可重试(网络可能已恢复)。 */
const _SCRIPT_LOADS = {};
function loadScript(src){
  if (_SCRIPT_LOADS[src]) return _SCRIPT_LOADS[src];
  const p = new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = src; s.async = true; s.onload = res;
    s.onerror = () => { delete _SCRIPT_LOADS[src]; try { s.remove(); } catch {} rej(new Error('script ' + src)); };
    document.head.appendChild(s);
  });
  _SCRIPT_LOADS[src] = p;
  return p;
}
async function regMountCaptcha(){
  const cap = REG.captcha;
  if (!cap || !cap.provider || REG.capMounted || !D.regCaptchaBox) return;
  // 5.2.0 复查:capMounted 要等脚本加载完才置位 —— 加载期间再次进入(切卡片过快 / 登录侧同时挂)
  // 会在同一容器里渲染第二枚挂件。在途的挂载一律复用同一个 Promise。
  if (REG.mounting) return REG.mounting;
  REG.mounting = regMountCaptchaOnce(cap);
  try { await REG.mounting; } finally { REG.mounting = null; }
}
async function regMountCaptchaOnce(cap){
  try {
    if (cap.provider === 'turnstile'){
      D.regCaptchaBox.hidden = false;
      await loadScript('https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit');
      window.turnstile.render(D.regCaptchaBox, {
        sitekey: cap.appId, action: 'register',   // 5.2.0:后端核对 action,注册令牌不能拿去登录
        callback: t => { REG.capToken = t; },
        'expired-callback': () => { REG.capToken = ''; },
      });
      REG.capMounted = true;
    } else if (cap.provider === 'geetest'){
      D.regCaptchaBox.hidden = false;
      await loadScript('https://static.geetest.com/v4/gt4.js');
      window.initGeetest4({ captchaId: cap.appId, product: 'float' }, obj => {
        obj.appendTo(D.regCaptchaBox);
        obj.onSuccess(() => { try { REG.capToken = JSON.stringify(obj.getValidate()); } catch {} });
        obj.onError(() => { REG.capToken = ''; });
      });
      REG.capMounted = true;
    } else if (cap.provider === 'tencent'){
      await loadScript('https://turing.captcha.qcloud.com/TCaptcha.js');
      REG.capMounted = true;         // 弹窗式:regCaptchaToken() 按需唤起
    }
  } catch (e){ console.warn('[注册] 验证码挂件加载失败', e); }
}
function regCaptchaToken(){
  const cap = REG.captcha;
  if (!cap || !cap.provider) return Promise.resolve('');
  if (cap.provider === 'tencent'){
    return new Promise((res, rej) => {
      try {
        const t = new window.TencentCaptcha(cap.appId, r => {
          if (r && r.ret === 0) res(JSON.stringify({ ticket: r.ticket, randstr: r.randstr }));
          else rej(Object.assign(new Error('captcha'), { data: { error: 'captcha_failed' } }));
        });
        t.show();
      } catch (e){ rej(Object.assign(e, { data: { error: 'captcha_unavailable' } })); }
    });
  }
  if (!REG.capToken)
    return Promise.reject(Object.assign(new Error('captcha'), { data: { error: 'captcha_failed', message: '请先完成人机验证' } }));
  return Promise.resolve(REG.capToken);
}

/* ───────── 5.2.0 登录人机验证(与注册同款供应商;按需加载,主包零依赖) ─────────
   与注册挂件**分开实例**:两张表单各自一枚令牌、各自 reset,互不吞令牌。
   Turnstile 渲染时标 action:'login'(注册标 'register'),后端核对 action,
   一种用途的令牌不能挪作另一种用途。挂件加载失败(大陆网络访问 Cloudflare 受限
   是常见原因)→ 明确提示「暂不可用」,绝不让按钮无限转圈。 */
function loginCapFail(kind, message){
  return Object.assign(new Error('captcha'), { data: { error: kind, message } });
}
function loginCapDeliver(tok){
  if (!tok){
    const ws = LOGIN.waiters.splice(0);
    for (const w of ws) w.rej(loginCapFail('captcha_unavailable', '人机验证加载失败(当前网络可能无法访问验证服务),请稍后重试'));
    return;
  }
  const w = LOGIN.waiters.shift();
  if (w) w.res(tok); else LOGIN.capToken = tok;
}
function loginCapReset(){
  LOGIN.capToken = '';
  if (LOGIN.capMounted === 'turnstile' && window.turnstile && LOGIN.widgetId != null){
    try { window.turnstile.reset(LOGIN.widgetId); } catch {}
  } else if (LOGIN.capMounted === 'geetest' && LOGIN.gt){
    try { LOGIN.gt.reset(); } catch {}
  }
}
async function loginMountCaptcha(cap){
  if (!cap || !cap.provider || !D.authCaptchaBox || LOGIN.capMounted === cap.provider) return;
  // 5.2.0 复查:always 档开门即预挂;脚本还在加载时用户就点了登录 → 第二次进入。在途挂载复用
  // 同一个 Promise,否则同一容器里会渲染两枚挂件(令牌各发各的,reset 只管得住一枚)。
  if (LOGIN.mounting) return LOGIN.mounting;
  LOGIN.mounting = loginMountCaptchaOnce(cap);
  try { await LOGIN.mounting; } finally { LOGIN.mounting = null; }
}
async function loginMountCaptchaOnce(cap){
  if (cap.provider === 'turnstile'){
    D.authCaptchaBox.hidden = false;
    await loadScript('https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit');
    LOGIN.widgetId = window.turnstile.render(D.authCaptchaBox, {
      sitekey: cap.appId, action: 'login',
      callback: t => loginCapDeliver(t),
      'expired-callback': () => { LOGIN.capToken = ''; },
      'error-callback': () => { loginCapDeliver(''); return true; },
    });
    LOGIN.capMounted = 'turnstile';
  } else if (cap.provider === 'geetest'){
    D.authCaptchaBox.hidden = false;
    await loadScript('https://static.geetest.com/v4/gt4.js');
    await new Promise(res => window.initGeetest4({ captchaId: cap.appId, product: 'float' }, obj => {
      obj.appendTo(D.authCaptchaBox);
      obj.onSuccess(() => { try { loginCapDeliver(JSON.stringify(obj.getValidate())); } catch { loginCapDeliver(''); } });
      obj.onError(() => loginCapDeliver(''));
      LOGIN.gt = obj;
      res();
    }));
    LOGIN.capMounted = 'geetest';
  } else if (cap.provider === 'tencent'){
    await loadScript('https://turing.captcha.qcloud.com/TCaptcha.js');
    LOGIN.capMounted = 'tencent';         // 弹窗式:取令牌时按需唤起
  }
}
async function loginCaptchaToken(cap){
  try { await loginMountCaptcha(cap); }
  catch { throw loginCapFail('captcha_unavailable', '人机验证加载失败(当前网络可能无法访问验证服务),请稍后重试'); }
  if (cap.provider === 'tencent'){
    return new Promise((res, rej) => {
      try {
        const t = new window.TencentCaptcha(cap.appId, r => {
          if (r && r.ret === 0) res(JSON.stringify({ ticket: r.ticket, randstr: r.randstr }));
          else rej(loginCapFail('captcha_failed', '已取消人机验证'));
        });
        t.show();
      } catch { rej(loginCapFail('captcha_unavailable', '人机验证暂不可用,请稍后重试')); }
    });
  }
  if (LOGIN.capToken){ const t = LOGIN.capToken; LOGIN.capToken = ''; return t; }
  return new Promise((res, rej) => {
    const w = {};
    w.tid = setTimeout(() => {
      LOGIN.waiters = LOGIN.waiters.filter(x => x !== w);
      rej(loginCapFail('captcha_failed', '请先完成人机验证'));
    }, 120000);
    w.res = t => { clearTimeout(w.tid); res(t); };
    w.rej = e => { clearTimeout(w.tid); rej(e); };
    LOGIN.waiters.push(w);
  });
}

/* 4.0.2:邀请码归一的前端镜像 —— 与后端 norm_invite_code 逐字节同规格:
   去一切非字母数字(全角分隔/空格/emoji 同灭)→ O→0 / I→1 / L→1 手滑宽恕
   (两种大小写)→ 大写 → 恰 16 位且全落 Crockford32(无 I/L/O/U)。仅作
   doRegister 的就地预检:格式必败的码不再白付一次 PoW 并烧一次 R1 尝试配额。
   payload 仍发原始输入(归一是后端的事);宽恕规则若在后端演进,此处必须同步 ——
   标记注释供 frontend_reg_jsdom.js 在源码态抠出本函数与规格向量硬对拍。 */
/*__JF_INVITE_NORM_BEGIN__*/
function jfInviteNorm(s){
  const up = String(s || '').replace(/[^0-9A-Za-z]/g, '')
    .replace(/[Oo]/g, '0').replace(/[IiLl]/g, '1').toUpperCase();
  return (up.length === 16 && /^[0-9ABCDEFGHJKMNPQRSTVWXYZ]+$/.test(up)) ? up : '';
}
/*__JF_INVITE_NORM_END__*/

async function doRegister(ev){
  ev.preventDefault();
  if (REG.solving) return;
  const name = (D.regUser.value || '').trim();
  const pw = D.regPass.value || '', pw2 = D.regPass2.value || '';
  // 字段级即时校验(与后端同规则,只为体验;后端才是闸)
  if (name.length < 2 || name.length > 20){ setRegMsg('用户名需为 2–20 个字符'); return; }
  /* 4.0.6:用户名字符集收窄为 [A-Za-z0-9](运营拍板,纯数字放行)。本式必须与后端
     userauth.py 的 _REG_USER_RE **逐字同规则** —— 由 test_frontend_backend_username_charset
     从两侧源码抠出对拍钉死,改一处忘另一处当场变红。
     它一并取代了 4.0.2 的空格闸与 emoji 代理对预检:中文、韩文、emoji、全角字母
     (ＡＢ 这类同形字仿冒)、连字符下划线全部落在同一条闸下,文案统一且可操作,用户
     不必先白付一次 PoW(≈0.3–1.5s)、也不烧那次 R1 配额(默认 5 次/时)才被打脸。
     闸序与后端一致「先长度、后字符集」:空输入应得到长度提示而非字符集提示。
     刻意不对口令做同款预检:入库形态前端不可知,摘要形态(md5/sha1/sha256)存 hex、
     emoji 口令合法 —— 前端拦了反而比后端更严,违背「与后端同规则」。
     也刻意**不做输入时静默过滤**:静默改写用户输入正是本项目反复栽过的陷阱
     (见上方口令框 maxlength 的注),超范围字符原样入框、由本闸可见地拦下。 */
  if (!/^[A-Za-z0-9]+$/.test(name)){ setRegMsg('用户名只能包含英文字母和数字'); return; }
  if (pw.length < 5 || pw.length > 16){ setRegMsg('密码需为 5–16 位字符'); return; }
  if (pw !== pw2){ setRegMsg('两次输入的密码不一致'); return; }
  let invite = '';
  if (REG.mode === 'invite'){
    invite = (D.regInvite.value || '').trim();
    if (!invite){ setRegMsg('请填写邀请码'); return; }
    // 4.0.2:格式镜像预检(jfInviteNorm,见其上方注释)—— 文案与后端
    // invite_invalid 同款;含宽恕映射,永不比后端更严(后端才是闸)。
    // 复查补:被拦时后台刷新一次挑战 —— 若运营已把 invite 热切为 open,
    // 借挑战回包的 mode 字段让本页跟上(regApplyMode 收起邀请码框),否则
    // 格式必败的码会把用户卡死在陈旧模式里直到手动刷新。空码分支无此问题:
    // 用户随手补一个像样的码即可通过,open 后端本就忽略 inviteCode 字段。
    if (!jfInviteNorm(invite)){
      setRegMsg('邀请码无效,请核对后重试');
      ensureRegChallenge(true).catch(() => {});
      return;
    }
  }
  REG.solving = true;
  D.regSubmit.disabled = true;
  setRegMsg('');
  const btnText = t => { try { D.regSubmit.textContent = t; } catch {} };
  try {
    let captchaToken = '';
    if (REG.captcha && REG.captcha.provider){
      btnText('人机验证中…');
      captchaToken = await regCaptchaToken();
    }
    let retryBudget = 1;             // challenge_expired 自动重取重试一次(预算 1)
    for (;;){
      let chal = await ensureRegChallenge();
      btnText('安全校验中…');
      const prefix = powAnswer(String(chal.salt));      // 执行证明:主线程跑本站(混淆)JS
      const sol = await regWorkerCall(
        { type: 'solve', prefix, bits: chal.bits },
        (tried, expect) => {
          // 报百分比而非原始次数:「74 万」用户无从判断是多是少,也看不出还要多久。
          // PoW 是几何分布、没有确定总数,故按期望值(2^bits)折算并封顶 99% ——
          // 宁可停在 99% 也不谎报 100%(约 37% 的情况会超过期望值才解出)。
          const pct = expect > 0 ? Math.min(99, Math.floor(tried / expect * 100)) : 0;
          btnText('安全校验中… ' + pct + '%');
        });
      // 4.0.1 复查:**先解题、后补最短填表余量** —— 旧序是"等满 minFill 再解题",
      // 快速提交(自动填充/失败重试的已填表单)总耗时 = 等待 + 解题;现在解题时间
      // 与等待窗重叠,总耗时 = max(等待, 解题)。服务端只看提交到达时刻 ≥ 签发 +
      // min_fill(以**服务端签发时刻**为准),客户端内部次序对防线零影响;
      // 重取挑战的极端路径仍按新挑战补足等待,免误伤。
      const waitMs = chal.issuedAt + chal.minFillS * 1000 - Date.now();
      if (waitMs > 0){ btnText('安全校验中…'); await sleep(waitMs + 120); }
      const fp = await regFingerprint();
      btnText('提交中…');
      try {
        const d = await regApi('/api/auth/register', { method: 'POST', timeout: 15000, body: {
          userName: name, password: pw,
          inviteCode: invite || undefined,
          challengeId: chal.cid, nonce: sol.nonce,
          captchaToken: captchaToken || undefined,
          fp: fp || undefined,
          contact: (D.regContact && D.regContact.value) || '',   // 蜜罐:真人恒空
        }});
        REG.chal = null;                                  // 挑战单次性:成败都作废
        regClearFields();                                 // 4.0.1:成功即清(见函数注释)
        if (d.autoLogin){
          setRegMsg('注册成功,正在进入…', true);
          setTimeout(() => location.reload(), 260);       // 与登录同款 reload 收束(C10 预置房已种下)
        } else {
          if (D.regForm) D.regForm.hidden = true;
          if (D.regBack) D.regBack.hidden = true;
          if (D.regDone){ D.regDone.hidden = false; D.regDoneText.textContent = d.hint || '注册成功!'; }
        }
        return;
      } catch (e){
        REG.chal = null;                                  // 无论何种失败,该挑战已被核销
        const derr = (e && e.data && e.data.error) || '';
        // 4.0.1:pow_failed 并入单次自动重试 —— 手机中途切网(WiFi⇄流量)会换 IP 段,
        // 旧挑战按签发时 IP 桶核验必败;换新挑战重解一次即自愈,免让真人白看一次报错。
        // 预算仍共用 1 次:真的持续失败照旧把错误亮给用户。
        if ((derr === 'challenge_expired' || derr === 'pow_failed') && retryBudget > 0){ retryBudget--; continue; }
        throw e;
      }
    }
  } catch (e){
    const d = (e && e.data) || {};
    let msg = d.message || REG_ERR[d.error] || '注册失败,请检查网络后重试';
    if (d.error === 'throttled' && d.retryAfter)
      msg += `(约 ${Math.max(1, Math.ceil(d.retryAfter / 60))} 分钟后可再试)`;
    setRegMsg(msg);
    // 重名是最常见的正常失败:直接把光标送回用户名框并全选,方便立刻改一个
    if (d.error === 'name_taken' && D.regUser){
      try { D.regUser.focus(); D.regUser.select(); } catch {}
    }
    if (D.regCaptchaBox && REG.captcha && REG.captcha.provider === 'turnstile' && window.turnstile){
      try { window.turnstile.reset(); REG.capToken = ''; } catch {}
    }
    ensureRegChallenge(true).catch(() => {});             // 预取下一枚,下次提交免等
  } finally {
    REG.solving = false;
    D.regSubmit.disabled = false;
    btnText('注 册');
  }
}

/* ───────── 回合归一化 ───────── */
function normRound(r){
  const n = Number(r.display_number);
  return {
    id: String(r.round_id ?? r.start_time_ms),
    n,
    key: r.spell_key || ELEM[n] || '',
    name: r.spell_name || ('御' + (ELEM[n]||'') + '术'),
    beast: r.beast_name || '',
    mult: Number(r.multiplier) || 0,
    start: Number(r.start_time_ms),
    draw: Number(r.draw_time_ms) || (Number(r.start_time_ms) + T.DRAW),
  };
}

/* ═══════════ 布局引擎 ═══════════
   2.8.0:一切宽度判定以「有效宽度」为准 —— 模拟游戏停靠在右侧时,
   主区可用宽 = 视口宽 − 面板宽(窄屏底部抽屉不占横向宽度)。
   驾驶舱资格、栅格几何、名录抽屉判定与 CSS 挤压态标记全部同源。 */
/* 3.9.4:游戏面板改「双形态」—— 桌面(视口 ≥1024,与 app.css 同名节共用
   同一断点)停靠为 #shell 尾列,重新从主区扣除横向宽度(2.8.0 的 data-w-md/xs
   挤压态标记体系即为此而生,原样复用);窄屏保持 3.9.0 全屏悬浮层,不占横向宽。
   面板实宽以 offsetWidth 实测(CSS --jf-dock-w 为单一事实源),开合瞬间由
   openGameDock/closeGameDock 显式补一次 applyLayout,视口变化走 resize 防抖。 */
const JF_DOCK_MQ = matchMedia('(min-width:1024px)');
const jfDocked = () => S.jiufa && JF_DOCK_MQ.matches;          // 面板当前处于桌面停靠形态
const jfFullscreen = () => S.jiufa && !JF_DOCK_MQ.matches;     // 面板当前处于窄屏全屏形态
function effW(){
  return jfDocked() ? Math.max(320, innerWidth - (D.jiufaDock?.offsetWidth || 0)) : innerWidth;
}

/* 3.3.1 阈值迟滞:原先驾驶舱资格是硬阈值 1240×680,拖拽在边界上来回蹭时
   每越线一次就 modeChanged → renderAll(),整页重建实测 139ms 同步冻结。
   现进/出用两套阈值(进 1240×680,出 1200×660),边界带宽 40×20px,
   拖过去就不再抖回来。 */
const ELIG_IN_W = 1240, ELIG_IN_H = 680;
const ELIG_OUT_W = 1200, ELIG_OUT_H = 660;
function computeLayout(){
  const w = effW(), h = innerHeight;
  const eligible = S.L?.eligible
    ? (w >= ELIG_OUT_W && h >= ELIG_OUT_H)
    : (w >= ELIG_IN_W  && h >= ELIG_IN_H);
  const pref = store.get(KEY.layout) || 'cockpit';
  const mode = (eligible && pref !== 'stack') ? 'cockpit' : 'stack';
  const L = { mode, eligible, w, h };
  if (mode !== 'cockpit') return L;

  L.rail   = w >= 1720 ? 264 : 64;
  L.ledger = 0;                                          // 九法已移顶部,左列取消
  L.right  = Math.round(clampN(324, w * .22, 432));
  L.center = w - L.rail - 28 - L.right - 12;             // 主区(序列/战况)可用宽
  L.mainH  = h - 52 - 84 - 28 - 12;                      // 顶栏/心跳/外距/间距
  const BOARD_H = 132, PRED_H = 48, GAPS = 12 * 3;       // 九法横排高 + 推演带定高 + 三道行间距
  const stack = L.mainH - BOARD_H - PRED_H - GAPS;       // 序列 + 战况 总高
  /* 5.0.0:主区高度再分配 —— 出怪序列是首要功能,战况退居次席。
     旧分法 road:trend = 3:7 的 3(序列 3/7 ≈43%,战况 4/7 ≈57%,次要功能反而更高)。
     现改「战况定窗、序列吃满」:战况只留一格舒适阅读窗 —— 目标 38%,但下钳
     TREND_MIN(实测构成:面板留白 18 + 容器边框 2 + 表头行 21 + 3 行×25 + 余 8,
     即极限 680 窗下最近 3 局整可读、第 4 局露头示滚;vip 档 h2 头为 absolute 零流高),
     上封 TREND_MAX(≈13 行整,再高只是复读滚动条,大屏余量应归序列);
     序列拿走其余全部像素。极限窗下序列较旧制 +33%,1080p 约 62%,
     2K/4K 战况封顶后序列尽收增量。
     像素值经 applyLayout 写回 --road-h,CSS 端 grid-template-rows 直接消费
     (app.css「驾驶舱模式」同名注)—— 旧制 JS 1.05/2.45 与 CSS 1.02fr/1.36fr
     是同一个 3/7 的两种写法、双份维护,现收敛为此处单一真源。
     NOTE_H:basic 档 vip-note 静态头(4.3.3,实测 角标 21 + 下距 6 = 27)在
     战况/出怪规律两面板各占一行 —— 战况地板与出怪规律 Fit-Height 都要补扣;
     不补的话 basic 档极限窗下战况实测只剩 2.2 行,地板名存实亡(2.5.8 同型)。 */
  const NOTE_H = isBasic() ? 27 : 0;                     // 声明上提:战况地板 + 出怪规律 Fit-Height 两处共用
  const TREND_MIN = 124, TREND_MAX = 374;                // 战况窗:表头 21 + 3 行×25 + 余 …… ≈13 行(行距 = 24+1)
  L.trendBandH = clampN(TREND_MIN + NOTE_H, Math.round(stack * .38), TREND_MAX);
  L.roadRowH   = stack - L.trendBandH;                   // 序列区高(首要功能,吃满余量)

  // 序列:每行珠数由用户指定(10–72,默认 36),珠径 = 中列宽 / 珠数
  // 上限 30 防低档位过度膨胀(超出部分居中留白),72 档间距收窄保证不溢出
  // 真实内容盒 = 区高/宽 − 面板 padding(9×2) − road-wrap padding(10×2) − 工具行(静态头,不再悬浮遮珠)
  const PAD = 18 + 20;
  const TOOLS_H = 36;                                    // 「每行 N 位 + 全屏」工具行(含下间距)
  const gridW = L.center - PAD, gridH = L.roadRowH - PAD - 4 - TOOLS_H;
  const cols = S.cols;
  const g = cols >= 72 ? 2 : 3;
  const BEAD_MAX = 30, BEAD_MIN = 7;
  const cell = clampN(BEAD_MIN, Math.floor((gridW - (cols - 1) * g) / cols), BEAD_MAX);
  const rows = Math.max(1, Math.floor((gridH + g) / (cell + g)));
  L.beadS = cell; L.roadCols = cols; L.roadRows = rows; L.roadGap = g;
  L.roadCount = cols * rows;                             // 含 pending 位

  // 战况 legacy 竖排:行高固定;展示局数恒 TREND_ROWS(容器内滚动,不再随视口高折算)
  L.trendRowH = TREND_ROW_COCKPIT;

  // 出怪规律 Fit-Height(右列跨序列+战况两行;2.5.8 修:补扣 2.4 引入的推演带,
  // 此前少扣 PRED_H+一道缝,最紧视口 680 高下出怪规律表被裁 ~118px)
  const avail = stack + 12 - 20;                         // 右列面板内高 = 两行 + 中缝 − 面板留白
  /* 4.3.3:basic 档的 vip-note 改为静态头行(见 app.css 同名注),实测占高
     角标 21 + 下距 6 ≈ 27。不扣这一口,Fit-Height 按旧预算放大行高,会把
     表尾/速读挤出面板 —— 2.5.8「少扣 PRED_H,出怪规律表被裁 ~118px」同型。
     (5.0.0:NOTE_H 声明已上提到序列/战况分法处 —— 战况地板窗同扣此口,两处共用单一真源。) */
  L.crh = clampN(24, Math.floor((avail - 30 - 70 - NOTE_H) / 9), 40);   // 70 = 盘感速读两条(14px 高)+文字+间距
  L.censusHide = L.right < 340 ? 'max today' : L.right < 392 ? 'max' : '';   // 392:九列禁换行表实测最小合身宽+余量
  return L;
}

function applyLayout(force){
  // 挤压态标记:CSS 端的 ≤1060 / ≤560 版式按有效宽度触发(见 app.css 2.8.0 节)
  const ew = effW();
  const md = ew <= 1060;
  document.body.toggleAttribute('data-w-md', md);
  document.body.toggleAttribute('data-w-xs', ew <= 560);
  /* 5.1.0:第三档挤压标记 data-w-lg = 有效宽 1061–1239.98(「死区」)——
     侧栏还没收成抽屉(那是 ≤1060)、驾驶舱又还没够格(ELIG_IN_W=1240),
     顶栏可用宽实测只有 746–919,比 ≤1060 的 1009 更紧却一条压缩规则都没有。
     判据必须走**有效宽**而非视口宽:模拟游戏面板停靠后主区可用宽 = 视口宽 −
     --jf-dock-w,实算视口 1607–1666 且面板停靠时有效宽正落在本带,纯媒体
     查询版够不着(app.css 同名节详注)。与上面两行同处、同款、同一口径。 */
  document.body.toggleAttribute('data-w-lg', ew > 1060 && ew <= 1239.98);
  /* 5.1.1:第四档 data-w-sm = 有效宽 ≤899.98(含 xs)——「单排物理装不下」带,
     由 app.css 同名节切成双层甲板。上界来自实测省略号触发面(900 起五种状态缺口全 0)。
     与上面三行同处、同款、同一口径;xs 由 CSS 侧 :not([data-w-xs]) 排除。 */
  document.body.toggleAttribute('data-w-sm', ew <= 899.98);
  // 3.9.0:挤压态下身份区整块可点按打开名录(☰ 之外的大热区);宽屏撤销按钮语义
  if (D.anchorIdentity){
    if (md){
      D.anchorIdentity.setAttribute('role', 'button');
      D.anchorIdentity.setAttribute('tabindex', '0');
      D.anchorIdentity.setAttribute('aria-label', '切换主播(打开名录)');
      D.anchorIdentity.title = '切换主播';
    } else {
      D.anchorIdentity.removeAttribute('role');
      D.anchorIdentity.removeAttribute('tabindex');
      D.anchorIdentity.removeAttribute('aria-label');
      D.anchorIdentity.removeAttribute('title');
    }
  }

  const prev = S.L;
  const L = computeLayout();
  S.L = L;
  document.body.dataset.layout = L.mode;
  D.layoutToggle.hidden = !L.eligible;
  D.layoutToggle.textContent = L.mode === 'cockpit' ? '纵览' : '驾驶舱';

  // 2.9.4:灵机推演不再随形态搬运 —— 常驻 #predictDock(DOM 紧贴九法阵之后),
  // 任何视口/形态下顺序恒为「九法阵 → 灵机推演」;驾驶舱经 grid-area:predict
  // 落在阵正下方通栏带,纵览/移动按文档流自然紧随阵后。
  if (L.mode === 'cockpit'){
    document.body.dataset.rail = L.rail === 264 ? 'full' : 'icon';
    D.deck.style.setProperty('--L-right',  L.right + 'px');
    D.deck.style.setProperty('--road-h',   L.roadRowH + 'px');   // 5.0.0:序列/战况行高单一真源(见 computeLayout 同名注)
    D.censusTable.style.setProperty('--crh', L.crh + 'px');
    D.censusTable.setAttribute('data-hide', L.censusHide);
    D.roadGrid.style.setProperty('--cols', L.roadCols);
    D.roadGrid.style.setProperty('--rows', L.roadRows);
    D.roadGrid.style.setProperty('--bead', L.beadS + 'px');
    D.roadGrid.style.setProperty('--g', L.roadGap + 'px');
    D.trendScroll.style.setProperty('--trh', L.trendRowH + 'px');
    D.censusFoot.hidden = false;
  } else {
    delete document.body.dataset.rail;
    D.deck.style.removeProperty('--road-h');             // 5.0.0:变量仅驾驶舱网格消费,离场即清
    D.censusTable.removeAttribute('data-hide');
    D.trendScroll.style.setProperty('--trh', TREND_ROW_STACK + 'px');
    D.censusFoot.hidden = true;
  }

  const modeChanged = force || !prev || prev.mode !== L.mode;
  /* 3.3.1:原条件是 roadCount || beadS || roadCols 任一变化就 renderRoad() 全量重建
     1733 颗珠(实测 44ms)。但珠径/行数/列数在 CSS 里全由 --bead / --cols / --rows
     驱动(见上方 setProperty),珠子 DOM 与之无关 —— 拖宽必然改 beadS,于是每次
     落定都白重建一次。现拆成两档:
       · 档位(每行 N 位)真的变了 → 重建(只可能由下拉触发,非拖拽路径);
       · 只是珠径/行数随视口变 → 不碰 DOM,但沿用旧 renderRoad 的收尾语义:
         重排后跟随到最新珠(旧代码全量重建时 appended=false,必定 snap 到底)。 */
  const roadColsChanged = L.mode === 'cockpit' && prev && prev.roadCols !== L.roadCols;
  const roadGeomChanged = L.mode === 'cockpit' && prev && (prev.beadS !== L.beadS || prev.roadCount !== L.roadCount);
  const widthChanged    = prev && prev.w !== L.w;

  if (modeChanged){
    swapRoadSelect();
    closeRail();
    renderAll();
  } else {
    if (roadColsChanged) renderRoad();
    /* 4.7.2:此处原为一发**裸** snapScroll —— 它绕过守卫无条件贴底,会把正在
       翻历史的用户直接拽回底部(与本轮确立的「用户翻走就交还控制权」相抵触);
       且函数末尾的 stickPinAll() 已覆盖同一件事。改为走守卫,按 armed 判定。 */
    else if (roadGeomChanged) stickPin(D.roadWrap);
    // 2.5.10:战况恒定局数,序列档位/窗高变化不再连带重建战况(读位滚动保持);
    // 中列宽若变了,战况格宽随之自适应,仅重取折线几何即可
    if (widthChanged) scheduleTrendLine();
  }
  renderTrendWindow();     // 3.3.1:容器高度变化时补/裁可视窗口(窗口未变则空转)
  /* 4.7.3:容器实宽跨过某一档的容纳边界(转屏、拖窗、坞开合)→ 按新档重排序列并刷新菜单。
     只在「夹紧结果真的变了」时重绘,拖拽途中的绝大多数帧都是空转。 */
  {
    /* 4.7.6 复审补:全屏那一半的侦测键必须用 wideColsFor —— 它已与面板档解耦,
       继续用 roadColsFor(=min(S.cols,fit)) 会漏掉「面板档没变、全屏档变了」的那一类。
       实测缺口:1440→900 缩窗时 roadColsFor 两档恒为 36(键不变、不重排),
       而 wideColsFor 从 72 掉到 36 —— 全屏开着拖窗/转屏不会按新宽重排。 */
    const fitNow = roadColsFor(D.roadWrap) + ':' + wideColsFor(D.wideBody);
    if (fitNow !== S._roadFit){
      const first = !S._roadFit;
      S._roadFit = fitNow;
      syncColSelects();
      if (!first && S.hist.length) renderRoad();
    }
  }
  syncStackBead();         // 3.3.2:纵览下把真实珠径回写 --bead(驾驶舱空转)
  /* 4.7.2:补上原 roadGeomChanged 只在 cockpit 分支求值留下的窟窿 ——
     纵览/手机形态下几何一变从不补贴底(实测横竖屏后主盘余 168px)。
     守卫内部按 armed 逐个判定,用户正在翻历史的盘不会被拽回;集合最多 4 项,开销可忽略。 */
  stickPinAll();
  tick();
}
/* ═══════════ 4.7.3:序列位数按容器实宽夹紧 ══════════════════════════════════
   ── 病灶（实测，非推断）────────────────────────────────────────────────
   序列的珠字号是 clamp(4px, 珠径×0.62, 18px)。珠径 ≥ 6.45px 时字号随珠径等比缩,
   永远装得下;一旦珠径跌破 6.45px,字号被 **4px 下限顶住**而格子继续缩 —— 字比格子
   还大,相邻数字直接咬在一起,盘面糊成一团。
   而每行位数 S.cols 是**设备级持久值**(jf2:cols),其「按屏宽自适应」只在**首访且
   从未存过值**时生效;用户在桌面选过 36/72,或首访就是宽屏,这个值会被原样带到手机。
   真机实测 390×844:
       jf2:cols=36 → 主序列 珠径 5.69px / 字号 4px      (字已探出格子)
       jf2:cols=72 → 主序列 珠径 2.00px / 字号 4px      (字是格子的 2 倍,完全重叠)
                     全屏序列 珠径 3.05px / 字号 4px
   而全屏的位数菜单在手机上仍**无条件**列出 72 —— 用户能亲手选进这个坏状态。
   战况早在 4.1 就用 rgRoadFitCols 解决了同一问题,序列这两处却一直没有夹紧。

   ── 药方 ──────────────────────────────────────────────────────────────
   与 rgRoadFitCols 同一契约:**S.cols(用户档)绝不被覆写**,只夹「本次渲染实际用
   几列」;菜单只留当前容器装得下的档;容器一变宽,自动回到用户原本的档。
   下限取 6.5px —— 正是上面那个「字号 clamp 触底」的数学临界点,不多夹一档:
   桌面 700px 中列下 72 档珠径 7.75px 仍在阈上,原有的高密度纵览完整保留。 */
const ROAD_BEAD_MIN = 6.5;                       // 珠径下限(px):低于此值字号 clamp 触底 → 字必溢出格子
const roadGapFor = c => (c >= 72 ? 2 : 3);       // 与 CSS .road-grid gap / .is-wide gap 严格同源
/* 容器实宽能容下的最大档。未上屏(宽为 0)时不夹,返回最大档,交由下次布局落定时再算。 */
function roadFitCols(el){
  const w = el ? el.clientWidth : 0;
  if (!(w > 0)) return ROAD_COL_OPTIONS[ROAD_COL_OPTIONS.length - 1];
  let best = ROAD_COL_OPTIONS[0];
  for (const c of ROAD_COL_OPTIONS){
    const g = roadGapFor(c);
    if ((w - (c - 1) * g) / c >= ROAD_BEAD_MIN) best = c;
  }
  return best;
}
/* 本次渲染实际用几列 = min(用户档, 容器容得下的档) */
function roadColsFor(el){ return Math.min(S.cols, roadFitCols(el)); }

/* ═══════════ 4.7.6:全屏序列(全景回放)的列档与几何 ═════════════════════════
   ── 病灶(实测,非推断)────────────────────────────────────────────────
   全屏此前走 roadColsFor(D.wideBody) = min(S.cols, fit) —— 只向下夹,**永不向上放**。
   于是它照搬面板那一档,而容器宽了 1.4 倍,珠子被 1fr 直接撑成巨块。
   Chromium 1440x900 实测(1728 局 = 满 24h):
       36 位(现状,继承面板):珠 36.50px / 字 18.00px(clamp 顶死)
                              字/珠 0.493 · 缝/珠 0.055 · 48 行 · 一屏只见 44.9%
       24 位(用户手选):     珠 55.75px / 字 18.00px
                              字/珠 0.323 · 缝/珠 0.036 · 72 行 · 一屏只见 20.1%
       72 位:               珠 17.25px / 字 10.70px
                              字/珠 0.620 · 缝/珠 0.116 · 24 行 · **一屏 100%**
   清晰度不由珠子多大决定,由**字/珠比**与**缝/珠比**决定:珠越大,字被 18px 上限
   顶住、缝仍是 2px 定值,两个比值同时塌 —— 这就是「放大后反而不如放大前清晰」。
   ── 药方 ────────────────────────────────────────────────────────────
   ① 默认取「珠径 ≥ 舒适下限」的**最大**档,而不是继承面板档 ——
      全屏该给的是「更多」,不是「更大」(桌面自动落 72 = 一屏看全 24h;
      手机落 24,信息量较现状 ×3.4)。舒适下限 12px 对应字号 ~7.4px;
      硬上限仍用 roadFitCols 的 6.5px(字号 clamp 触底点)兜底,双闸不冲突。
   ② 用户在全屏里亲手改的档记在 S.wideCols(独立键),不再污染面板档。
   ③ --g 与 --cols 同步下发 —— 此前只有驾驶舱写 --g,全屏的字号公式
      拿 var(--g,3px) 兜底却实际排 2px 的缝,珠径被高估 5.8%,
      字/珠实测 0.585 而非设计值 0.62。这是本次顺手修掉的既有失准。 */
const WIDE_BEAD_MIN = 12;                        // 全屏默认档的珠径舒适下限(px)
function wideFitCols(el){                        // 珠径 ≥ WIDE_BEAD_MIN 的最大档;未上屏返回 0
  const w = el ? el.clientWidth : 0;
  if (!(w > 0)) return 0;
  let best = 0;
  for (const c of ROAD_COL_OPTIONS){
    if ((w - (c - 1) * roadGapFor(c)) / c >= WIDE_BEAD_MIN) best = c;
  }
  return best;
}
/* 全屏「想用几列」:用户显式选过则尊重,否则取舒适上限(退化时回落硬上限) */
function wideColsWant(el){ return S.wideCols || wideFitCols(el) || roadFitCols(el); }
/* 全屏本次渲染实际用几列 = min(想用的, 硬上限) */
function wideColsFor(el){ return Math.min(wideColsWant(el), roadFitCols(el)); }
/* 全屏网格几何下发:--cols 与 --g 必须同源同拍(CSS 的珠径封顶与字号公式都读它俩) */
function setWideGeom(){
  const c = wideColsFor(D.wideBody);
  D.wideGrid.style.setProperty('--cols', c);
  D.wideGrid.style.setProperty('--g', roadGapFor(c) + 'px');
  return c;
}
/* 两个位数下拉:只列当前各自容器装得下的档,选中项 = 夹紧后的实际档。
   ★ 不写回 S.cols —— 用户档只有用户亲手改才变(与战况 rgRoadHtml 同规)。 */
function syncColSelects(){
  const build = (sel, host, want) => {
    if (!sel) return;
    const fit = roadFitCols(host);
    const pool = ROAD_COL_OPTIONS.filter(n => n <= fit);
    if (!pool.length) pool.push(ROAD_COL_OPTIONS[0]);
    const cur = Math.min(want, pool[pool.length - 1]);
    const html = pool.map(n => `<option value="${n}">${n} 位</option>`).join('');
    if (sel.innerHTML !== html) sel.innerHTML = html;
    sel.value = String(cur);
  };
  build(D.roadCols, D.roadWrap, S.cols);                     // 面板:用户档 jf2:cols
  build(D.wideCols, D.wideBody, wideColsWant(D.wideBody));   // 4.7.6 全屏:独立档 jf2:wideCols(未设 = 舒适上限)
}
function swapRoadSelect(){
  const opts = ROAD_COL_OPTIONS.map(n => `<option value="${n}">${n} 位</option>`).join('');
  D.roadCols.innerHTML = opts;
  D.roadCols.value = String(S.cols);
  D.wideCols.innerHTML = opts;
  D.wideCols.value = String(S.cols);
  syncColSelects();      // 4.7.3:随即按各自容器实宽夹紧菜单与选中项
}
/* 统一的位数落位:持久化 + 双下拉同步 + 触发对应模式重排 */
function applyCols(v){
  v = Number(v);
  S.cols = ROAD_COL_OPTIONS.includes(v) ? v : ROAD_COLS_DEF;
  store.set(KEY.cols, String(S.cols));
  D.roadCols.value = String(S.cols);
  if (S.L?.mode === 'cockpit') applyLayout();   // 重推珠径/行数,差异分支自动重绘
  else renderRoad();
  syncColSelects();                             // 4.7.6:两档已解耦 —— 面板改档不再改写全屏下拉
}
/* 4.7.6:全屏序列的位数落位(独立持久键,不触碰面板档)。
   按日回看态由既有的第二枚 change 监听补渲(注册序在本函数之后,S.wideCols 已更新),
   此处只管实时态 —— 与 3.6.0 原有分工逐字保持一致,不重复渲染。 */
function applyWideCols(v){
  v = Number(v);
  if (!ROAD_COL_OPTIONS.includes(v)) return;
  S.wideCols = v;
  store.set(KEY.wideCols, String(v));
  D.wideCols.value = String(v);
  if (WV.mode !== 'day') renderRoad();
}

/* ═══════════ 启动 ═══════════ */
async function boot(){
  cacheDom();
  initInputBus();     // 4.9.4:必须早于 bindStatic —— 战况/名录的分支逻辑读 S.input
  bindStatic();
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(()=>{});
  // 旧版本(含登录/收费体系)遗留的本地存储一次性清理
  store.remove('jf2:token'); store.remove('jf2:pwaDismiss');

  // 游戏面板:恢复模式偏好(设备级,先于鉴权;开合状态在 dataBoot 恢复)
  S.gameTab = (store.get(KEY.gameTab) === 'sim') ? 'sim' : 'real';
  S.rgSkin = (store.get(KEY.rgSkin) === 'official') ? 'official' : 'diy';
  applyLayout(true);

  // 4.1.0:链接快速登录 —— URL 片段带一次性票据时,先兑换正式会话再走鉴权引导
  // (只消费一次:读到即清片段;失败不阻断,原因摆到登录门上)。
  const ssoMsg = await ssoConsume();
  bindSsoHashChange();   // 4.3.4:补「页面不重载」那条路,见函数注

  // 3.8.0:鉴权先行 —— 登录系统启用且未登录时,壳照常渲染(骨架 + 霜罩),
  // 但**不发任何数据请求**;登录成功后 location.reload() 从零重建。
  const sess = await authInit();
  renderAuthChip();
  if (AUTH.enabled && !AUTH.user){
    lockApp((sess && sess.state) || 'auth_required', sess);
    if (ssoMsg) setAuthMsg(ssoMsg);   // 快速登录失败原因优先摆在门上(压过通用副题)
    return;
  }
  if (ssoMsg) { try { toast(ssoMsg); } catch {} }  // 已在登录态(如切换重试撞过期):toast 即可
  bindVip();               // 4.2.0:VIP 开通门 / 支付 / 卡密 的事件绑定
  await dataBoot();
}

/* 数据启动:名录 → 账号库 → 定房 → 实时(3.8.0 自 boot 拆出;登录后才走到) */
async function dataBoot(){
  /* 4.2.0:free 档(小叮当到期且无九法VIP)—— **一个数据请求都不发**,直接进开通页。
     与 3.8.0「未登录时不发任何数据请求」同款纪律:省下注定 403 的往返,
     也不给页面留下任何可抓的数据骨架。 */
  if (isFree()){
    hideVeil();
    /* 4.2.0(复审补):free 档隐藏两个游戏入口。父页没有任何数据 ⇒ 点进去
       只会看到永远转圈的「正在装载模拟游戏」—— 那比不给入口更伤。
       (开通门的 pointer-events:none 已经挡住点击,这里是语义层的第二道:
        不给不能用的入口,而不是给了再挡。) */
    setGameEntriesVisible(false);
    showVipGate('free');
    renderAuthChip();
    /* 4.2.2:free 档**最需要**这一下 —— 付完钱就关掉标签页的人,再打开时正是
       这个分支。仅当本机有在途单标记时才真的发请求,故「零数据请求」纪律不变。 */
    payRecover();
    return;
  }
  /* basic 档:若上一次是 VIP(快照里可能存着 400 局),现在必须清掉 —— 否则
     昨天以 VIP 身份存的历史会在今天以 basic 身份被回灌,绕过 30 局限制。 */
  /* ★ 必须显式恢复:free 档分支把两个游戏入口 hidden=true 了,
     而 free 用户开通成功后 onVipGranted → dataBoot 会走到这里 ——
     若不恢复,**刚付完钱的用户反而看不到「真实游戏 / 模拟游戏」入口**
     (原先只有置 true 没有置 false,隐藏后无人恢复)。 */
  setGameEntriesVisible(true);
  payRecover();            // 4.2.2:见 payRecover 注(有在途单标记才发请求)
  /* 4.4.0:清快照的判据从「是不是 basic」改成「档位**变了没有**」。
     4.2.0 无条件清是因为 basic 根本不许留存;现在 basic 可留存,唯一必须清的
     只剩掉档(vip→basic:昨天的满 24h 不能今天以 basic 身份接着用)。
     升档(basic→vip)同样清 —— 不是安全需要,是口径需要:basic 期间的窗口
     可能带断口,留着会让刚付完钱的用户第一眼看到一个洞。
     (hydrateSnapshot 的 tier 戳是同一件事的第二道;这里漏判它仍会拒。) */
  {
    const now = JF.on ? JF.tier : 'vip';
    if (store.get(KEY.jfTier) !== now){ pruneAllSnaps(); store.set(KEY.jfTier, now); }
  }
  syncVipNotes();
  /* 4.3.3:启动序是 applyLayout(true) → await authInit() → dataBoot() ——
     首屏布局跑在档位落地之前,NOTE_H(见 computeLayout)算不进预算;而
     app.css 的 [data-jf-tier="basic"] 属性选择器在 dataset 写入瞬间即生效。
     不补这一下,basic 档首载会有「头已静态、预算未扣」的 27px 裁表窗口,
     直到下一次 resize 才自愈。无 force:只重算几何、重置 --crh,不触发
     renderAll(此刻历史尚未拉取,renderAll 也无意义)。 */
  applyLayout();
  vipExpiryNudge();
  /* 4.3.3:首入 basic 的一次性说明。「从最近 N 局起累计」这条核心口径原先只
     散在 11px 角标与踩锁才弹的 toast 里 —— 小白全靠碰壁式发现。复用
     toastAction 8000ms 既有先例(「切回」/ 重基线提示同款),零新增 UI 面积;
     按用户记忆(KEY_NS 后缀),同机换号各自只见一次,永不纠缠。 */
  if (isBasic() && !store.get(KEY.jfIntro)){
    /* 4.9.0:「已看过」改到 onShown 里落 —— 旧写法是先落盘再显示,一旦那一瞬被
       别的提示覆盖(实测可复现),用户**一次都没看见**却永不再弹。管线现在保证
       动作型提示不被抢占,onShown 只在它真正出场那一刻触发,两道保险。 */
    S._bootToast = true;        // 4.8.0:占用本次开机的提示位,房间说明改下次再弹
    toastAction(JF.onlineH > 0
      ? `当前为基础档:序列/战况/出怪规律按**你在线看到的**逐局累计(最长 ${JF.onlineH} 小时)`
      : `当前为基础档:序列/战况/出怪规律从最近 ${JF.histLimit} 局起累计`,
      { label: '看看九法VIP多什么', ms: 8000,
        onShown: () => store.set(KEY.jfIntro, '1'),
        onClick: () => showVipGate('upsell') });
  }
  /* 3.9.4:规则披露 —— 此前「单账号单活跃房」在 UI 上零说明,用户只能在被跟随的
     一瞬间从 2.4s 的 toast 里猜。连接态徽章是长期可见且语义相邻(它显示实时链路
     状态)的落点,悬停即得完整规则;仅登录系统启用时设置(规则本就只在此时生效)。 */
  if (AUTH.enabled && D.connState)
    D.connState.title = '同一账号同一时间只实时监控 1 个直播间;'
      + '在其它窗口/设备切换直播间时,本窗口会自动跟随过去(提示上可一键切回)。';
  if (store.get(KEY.jiufaOpen) === '1') openGameDock(S.gameTab);

  let roomsOk = true;   // 5.0.2:成/败分流的依据 —— 失败≠空,见下方空名录分支
  try { const lr = await api('/api/live-rooms'); S.rooms = lr.rooms || []; noteRoomsFetched(lr); }
  catch { S.rooms = []; roomsOk = false; }
  S.roomsReady = true;   // 名录已回(成败皆算):此前 alias 为空只是「开机窗口」,不该弹「选直播间」引导
  mergeMyRooms();
  renderRail();
  // 3.9.4:侧栏速览 —— 每秒本地重绘角标(document.hidden 时函数内自跳过),
  // 每 30s(±抖动)静默重拉名录刷新锚点;dataBoot 每次页面生命周期只走一次,
  // 仍以幂等守卫防御未来的重入改动。
  if (!S.railTickT)  S.railTickT  = setInterval(railTickPaint, 1000);
  if (!S.railFetchT) S.railFetchT = setInterval(refreshLiveRooms,
                                                30000 + Math.floor(Math.random() * 4000));
  loadAccounts();          // 账号库(扫码登录):异步载入,不阻塞主流程

  // 2.9.0:默认房间取「当前监控中的第一个房间」(来自后端 live-rooms),
  // 而非模拟时代硬编码的 321;URL ?room= 优先,其次是仍在名录内的上次房间。
  // 3.9.3:URL/存储里可能是**归一后的真实房号**(分享链接、或早期 follow 把归一号写进了
  //   存储),而 inRoster 按 **alias** 匹配 → 会失配成「回退首房」。此处 S.rooms 刚拉取
  //   (最新),用它把归一号映射回别名 —— 既覆盖名录过期的残留,也**自动修好已被写坏的
  //   存储**(老版本遗留的归一号无需用户手动重选)。映射不中则原样保留(尽力而为)。
  const rawRoomParam = new URLSearchParams(location.search).get('room') || '';
  const urlRoom = followTarget(rawRoomParam);
  /* 3.9.4:分享链接的显式意图**只消费一次** —— 读到即从地址栏移除(replaceState,
     不产生历史条目)。否则参数常驻:移动端后台标签被系统回收后回前台会整页重载,
     每次重载都按「显式切房」claim 抢占,把其它设备/窗口硬拽回本房 —— 重载不是
     用户的"切换",这违背 last-wins「以最后一次切换为准」的意图语义(实测:手机开过
     分享链接后每次切回该标签,电脑端都被无故拉回旧房 + 一句无从解释的跟随提示)。
     消费后刷新走存储恢复(renew,汇聚不抢占);重新点开分享链接 = 新导航仍带参数,
     显式意图照常生效。失败(极端环境无 history API)静默放过:仅退回旧行为。 */
  if (rawRoomParam){
    try {
      const u = new URL(location.href);
      u.searchParams.delete('room');
      const qs = u.searchParams.toString();
      history.replaceState(history.state, '', u.pathname + (qs ? '?' + qs : '') + u.hash);
    } catch {}
  }
  const stored = followTarget(store.get(KEY.room) || '');
  const inRoster = a => S.rooms.some(r => String(r.alias) === String(a));
  const firstRoom = (S.rooms[0] && String(S.rooms[0].alias)) || '';
  const alias = (urlRoom || (stored && inRoster(stored) ? stored : firstRoom) || stored || '') + '';
  if (!alias){                                   // 后端未监控任何房间且用户未指定 → 提示添加
    hideVeil(); renderIdentity();
    /* 5.0.2:与删空名录(handleRoomGone → openModal)同处置 —— 空名录时唯一可做的
       事就是添加,直接把弹层递到眼前,不再让人按 toast 找按钮。旧文案「请在左侧
       「＋ 添加直播间」」在图标轨下对不上字(左侧只有裸「＋」)、在手机上指向
       空无一物(侧栏是收起的抽屉),实测截图为证;toast 现只述状态,零方位依赖。
       bindStatic 先于本函数执行(boot 顺序实地核查),.click() 转发安全。
       失败≠空:名录**没拉到**(断网/后端异常;本地「我的房」也空,否则 mergeMyRooms
       已给出 alias)时,「尚未监控」是撒谎、弹添加层是误导 —— 此路只给诚实的
       失败提示,不弹层。401/403 会话失效同落此支,弹层本会被 z120 登录门盖住,
       现在干脆不弹。 */
    if (roomsOk){
      toast('尚未监控任何房间,先添加一个直播间开始观测');
      D.addRoomOpen.click();
    } else {
      setConn('off', '名录拉取失败');
      toast('名录拉取失败,请检查网络后刷新重试');
    }
    return;
  }

  const snapped = hydrateSnapshot(alias);
  // 4.4.0:回灌结果做成可观测出参(与既有 window.__flushMs 同款约定)——
  // 整机冒烟要断言「掉档快照必被拒 / 同档快照必回灌」,而这两件事在 DOM 上
  // 的痕迹会被随后的真实拉取覆盖,只能在此刻取证。
  window.__jfHydrated = snapped ? S.hist.length : 0;   // 局数(0=未回灌),兼作窗口钳制的取证点
  S.alias = alias;        // 名录已定房:立刻钉住 alias(数据仍在路上)。游戏盘由此显示「载入中」而非误导的「选直播间」
  /* 4.8.0:一次性讲清房间口径。副题上的常驻说明在**驾驶舱**下看不到
     (.panel-sub 恒 display:none),而首次误解恰恰发生在开机头几分钟 ——
     故补一发点名当前房的说明,并给「换直播间」直达名录。写法与 4.3.3 的
     jfIntro 同款(toastAction 8000ms + 按用户记忆,永不复弹)。 */
  if (!store.get(KEY.roomIntro) && !S._bootToast){
    // 4.9.0:同 jfIntro —— 「已看过」落到 onShown,确保用户真的看见过才不再弹。
    /* 5.0.3:按钮按名录数分流。旧版恒「换直播间」→ openRail —— 名录只有正在看的
       这一个房时根本无从换起,按钮名不副实(5.0.2 批判过的同型问题:旧 rgGotoRooms
       「选择直播间」在空名录下没得选)。单房改「＋ 添加直播间」直达添加弹层
       (与引导条/空态卡同一转发,容量闸等同一套);≥2 房维持原语义零变化。 */
    const single = S.rooms.length <= 1;
    toastAction(`正在观测 ${alias} 房 —— 各直播间各出各的怪,序列只对这一个房有效`,
      { label: single ? '＋ 添加直播间' : '换直播间', ms: 8000,
        onShown: () => store.set(KEY.roomIntro, '1'),
        onClick: single ? () => D.addRoomOpen.click() : () => openRail(true) });
  }
  // last-wins:URL ?room= 是**显式**意图(如分享链接)→ claim 抢占;否则(存储/首房恢复)
  // 只 renew,跟随账号当前活跃房 —— 别的设备在盯别的房时,本次恢复会自动汇聚过去。
  loadRoom(alias, { silent: snapped, explicit: !!urlRoom });
}

/* ═══════════ 快照秒开(v2 + LRU) ═══════════ */
/* 4.2.0:VIP 到期回落 basic 时,**必须**主动删掉该账号的全部房间快照 ——
   否则昨天以 VIP 身份存下的 400 局会在今天以 basic 身份被回灌,绕过限制。
   幂等、静默、只删本账号命名空间(KEY.snap 已带 @u<id> 后缀)。 */
function pruneAllSnaps(){
  try {
    const idx = JSON.parse(store.get(KEY.snapIdx) || '{}');
    for (const a of Object.keys(idx)) store.remove(KEY.snap + a);
    store.remove(KEY.snapIdx);
  } catch {}
}
function pruneSnaps(alias){
  try {
    const idx = JSON.parse(store.get(KEY.snapIdx) || '{}');
    idx[alias] = Date.now();
    const keep = Object.entries(idx).sort((a,b)=>b[1]-a[1]).slice(0,6);
    const keepSet = new Set(keep.map(e=>e[0]));
    for (const a of Object.keys(idx)) if (!keepSet.has(a)) store.remove(KEY.snap + a);
    store.set(KEY.snapIdx, JSON.stringify(Object.fromEntries(keep)));
  } catch {}
}
/* ═══ 4.4.0:快照 v3 —— 「在线期间读过的数据」的本机留存 ═══════════════════
   ── 这是什么、更重要的是**不是**什么 ────────────────────────────────────
   是:把用户**自己在线时已经从服务端合法取到**的局,按 50001ms 格点压成一条
       号位串存本机,刷新后原样回灌 —— 让 basic 档不再「一刷新就清零」。
   不是:一道安全闸的松动。服务端 history 仍钳 jf_basic_history_limit 且禁 until
       (JFVIP-SYSTEM.md §4.1 的数学论证逐字不变),本改动**没有多给 basic 档
       一个字节的新数据**,只是不再把他看过的东西在刷新时丢掉。
   ── 掉档(vip→basic)仍必须挡住 ────────────────────────────────────────
   这是唯一真实的绕过向量:昨天以 VIP 身份存的满 24h,今天以 basic 身份回灌就
   等于白嫖了 VIP 的窗口。三道拦:① 快照自带 tier 戳,hydrate 只认同档;
   ② dataBoot 侦测到档位变化即 pruneAllSnaps();③ 窗口长度按**当前**档位钳。
   ── 诚实声明 ──────────────────────────────────────────────────────────
   localStorage 用户可改 ⇒ 他能伪造自己的序列。但伪造不出预测 / 按日回看 /
   coverage —— 那些每一次都要过服务端闸。与既有 simWallet/simBets 同一风险面,
   不新增攻击面;客户端留存本就只是 UX,从来不是边界。 */
/* 号位串编码:旧→新逐格点一字符,'0' = 该格点未观测(断口占位)。
   起点由 b 基准 + 序号×步进 还原(round_id ≡ start_ms,web.py:1099 明述)。 */
function encodeHist(hist){
  if (!hist.length) return null;
  const oldest = hist[hist.length - 1].start, newest = hist[0].start;
  const span = Math.round((newest - oldest) / T.ROUND);
  if (!(span >= 0) || span > HIST_CAP) return null;         // 越界:宁可不存也不存坏的
  const arr = new Array(span + 1).fill('0');
  for (const r of hist){
    const i = Math.round((r.start - oldest) / T.ROUND);
    /* ★ 复审加固:初版对"落不到格点上"的局是**静默跳过** —— 那等于悄悄丢数据。
       实测确认每房相位恒定(真机三房各自 mod 50001 只有一个同余类),故正常情况
       不会走到这里;但万一上游重开导致相位漂移,宁可**整份不存**(下次重存)
       也不能存一份缺了一半的快照:回灌时用户看到的会是一个假的"断口密布"序列,
       而他根本没离线过。失败即返回 null,saveSnapshot 直接跳过本次。 */
    if (!(i >= 0 && i <= span) || Math.abs(oldest + i * T.ROUND - r.start) >= 2) return null;
    arr[i] = String(r.n);
  }
  return { b: oldest, r: arr.join('') };
}
/* 两份号位串按**绝对起点**对齐取并集(同房恒同相位,见 encodeHist 注)。
   ★ 为什么落盘必须单调不减:同账号同房开两个标签页时,各自的 S.hist 是各自
   「在线期间看到的」——多数时候相同,但存在窄窗会分叉(典型:一个陈旧标签页
   被租约挤下、长期不再 ingest,关闭时的 saveSnapshot 会用它较少的历史**覆盖**
   另一页积累的满窗)。覆盖式落盘等于用户白攒几小时。
   并集式落盘让这一整类竞态**结构上不存在**:任何一页写盘都只增不减,谁先谁后
   都收敛到同一个并集。代价是每次落盘多一次 ~3KB 的读+解析,可忽略。 */
function mergeEnc(prev, cur){
  if (!prev || typeof prev.r !== 'string' || !prev.r || !Number.isFinite(prev.b)) return cur;
  const b = Math.min(prev.b, cur.b);
  const end = Math.max(prev.b + (prev.r.length - 1) * T.ROUND,
                       cur.b + (cur.r.length - 1) * T.ROUND);
  const len = Math.round((end - b) / T.ROUND) + 1;
  if (!(len > 0) || len > HIST_CAP) return cur;          // 越界:退回本次,不冒险
  const arr = new Array(len).fill('0');
  for (const e of [prev, cur]){
    const off = Math.round((e.b - b) / T.ROUND);
    if (off < 0 || Math.abs(b + off * T.ROUND - e.b) >= 2) continue;   // 相位不合:整份忽略
    for (let i = 0; i < e.r.length; i++)
      if (e.r[i] !== '0' && off + i < len) arr[off + i] = e.r[i];
  }
  return { b, r: arr.join('') };
}
/* 把并集按**当前**窗口裁到「最新一局往回 H 小时」,并削掉首尾多余的占位符。 */
function clampEnc(enc, hours){
  if (!enc) return enc;
  const len = enc.r.length;
  const newest = enc.b + (len - 1) * T.ROUND;
  let from = Math.max(0, Math.ceil((newest - hours * 3600e3 - enc.b) / T.ROUND));
  while (from < len && enc.r[from] === '0') from++;      // 前导占位符无信息,削掉
  if (from >= len) return null;
  return { b: enc.b + from * T.ROUND, r: enc.r.slice(from) };
}
function decodeHist(b, str, spells){
  const byN = {}; for (const sp of (spells || [])) byN[sp.display_number] = sp;
  const out = [];
  for (let i = 0; i < str.length; i++){
    const n = Number(str[i]);
    if (!(n >= 1 && n <= 9)) continue;                       // '0' = 未观测,跳过
    const start = b + i * T.ROUND, sp = byN[n] || {};
    out.push({ round_id: start, display_number: n,
               spell_key: sp.spell_key || ELEM[n] || '',
               spell_name: sp.spell_name || ('御' + (ELEM[n] || '') + '术'),
               beast_name: sp.beast_name || '', multiplier: Number(sp.multiplier) || 0,
               start_time_ms: start, draw_time_ms: start + T.DRAW });
  }
  return out;
}
function saveSnapshot(){
  /* 4.4.0:basic 档是否落地由**后端下发的窗口**决定(isBasic() 仍在判据里 ——
     窗=0 时 snapOn() 为假,行为与 4.2.0 的无条件短路逐字节相同)。 */
  if (!snapOn() || !S.alias || !S.hist.length) return;
  const cutH = snapWindowH();
  const cut = S.hist[0].start - cutH * 3600e3;
  const keep = S.hist.filter(r => r.start >= cut);           // 按**当前档位**的窗口钳
  let enc = encodeHist(keep);
  if (!enc) return;
  /* 与盘上已有的并集(见 mergeEnc 注:落盘单调不减,消灭多标签页覆盖竞态)。
     只与**同档、同格点、未过期**的旧快照合并 —— 掉档/换版/过期一律当不存在。 */
  try {
    const old = JSON.parse(store.get(KEY.snap + S.alias) || 'null');
    if (old && old.v === SNAP_V && (old.tier || 'vip') === (JF.on ? JF.tier : 'vip')
        && Date.now() - old.t <= cutH * 3600e3)
      enc = mergeEnc({ b: Number(old.b), r: String(old.r || '') }, enc);
  } catch {}
  enc = clampEnc(enc, cutH);
  if (!enc) return;
  try {
    // set 失败(配额/隐私模式)返回 false —— 静默降级为「本次不留存」,
    // 绝不抛错打断渲染;下一局再试(局局都调,天然自愈)。
    const ok = store.set(KEY.snap + S.alias, JSON.stringify({
      v: SNAP_V, t: Date.now(), tier: (JF.on ? JF.tier : 'vip'),
      profile: S.profile, spells: S.spells, b: enc.b, r: enc.r,
    }));
    if (ok) pruneSnaps(S.alias);
  } catch {}
}
function hydrateSnapshot(alias){
  if (!snapOn()) return false;                               // 窗=0 / free 档:逐字节旧行为
  let snap = null;
  try { snap = JSON.parse(store.get(KEY.snap + alias) || 'null'); } catch {}
  // v2 及更早一律作废(格式不兼容,且可能是掉档前的 VIP 满窗)
  if (!snap || snap.v !== SNAP_V || typeof snap.r !== 'string' || !snap.r
      || !Number.isFinite(Number(snap.b))
      || !Array.isArray(snap.spells) || !snap.spells.length) return false;
  /* ★ 掉档闸:快照的 tier 戳必须与当前档位一致。不一致即删 —— 留着只会在
     下次同档时被误认为「自己存的」。旧 VIP 快照因此不可能被 basic 回灌。 */
  if ((snap.tier || 'vip') !== (JF.on ? JF.tier : 'vip')){
    store.remove(KEY.snap + alias);
    return false;
  }
  if (Date.now() - snap.t > snapWindowH() * 3600e3) return false;
  let rounds = decodeHist(Number(snap.b), snap.r, snap.spells);
  if (!rounds.length) return false;
  /* ★ 复审补漏:窗口是热更项。运维把 24 调到 6 之后,**存的时候**是 24h 的旧快照
     仍会被整份回灌 —— 相当于旧值继续生效,调窗没落地。故按**当前**窗口对内容
     再钳一次(以快照内最新一局为锚,与 saveSnapshot 的裁法同源)。 */
  const newest = rounds[rounds.length - 1].start_time_ms;   // decodeHist 产出为升序
  const cut = newest - snapWindowH() * 3600e3;
  rounds = rounds.filter(r => r.start_time_ms >= cut);
  if (!rounds.length) return false;
  applyRoomData(alias, snap.profile, snap.spells, rounds);
  /* ★ 五轮复审修正(jsdom 取证实锤):光回灌是**不够**的。dataBoot 紧接着会
     loadRoom,而 loadRoom 落地走 applyRoomData —— 那是「换房重锤」,**整体替换**
     S.hist。basic 档本次 history 只回 N 局(硬闸),于是回灌的满窗会在一个 RTT
     后被这 N 局整段冲掉;更糟的是 loadRoom 随后还会 saveSnapshot(),用这 N 局
     把本机满窗快照**覆盖**掉 —— 特性不但不生效,还会自毁。
     实测(4.4.0 前):回灌 6 局 → loadRoom 后 S.hist=2 局,磁盘快照 '111111'→'11'。
     故在此留一份种子,由 loadRoom 在 applyRoomData 之后、saveSnapshot 之前并回。 */
  S.snapSeed = { alias, rounds };
  renderAll();
  startTick();
  return true;
}

/* ═══════════ 房间加载 ═══════════ */
function applyRoomData(alias, profile, spells, rawRounds){
  S.alias = alias;
  syncStageEmpty();   // 5.0.3 复审:alias 钉住即收口 —— 空名录经搜索观测的房,数据落地时空舞台卡让位(条件含 !S.alias,见同名函数注)
  S.profile = profile || null;
  S.spells = (spells || []).slice().sort((a,b) => a.display_number - b.display_number);
  S.spellByN = {}; S.spells.forEach(sp => S.spellByN[sp.display_number] = sp);
  S.hist = (rawRounds || []).map(normRound)
    .filter(r => Number.isInteger(r.n) && r.n >= 1 && r.n <= 9 && Number.isFinite(r.start))  // 与 ingest 同口径门卫
    .sort((a,b) => b.start - a.start);
  S.ids = new Set(S.hist.map(r => r.id));
  pruneHistWindow();   // 3.8.2:首装同样钉真 24h 锚定窗(retention>1 / 低在线率房的跨天尾巴在此裁掉)
  S.anchor = S.hist[0]?.start || nowC();
  S.lastDataTs = Date.now();
  S.lastDataPerf = performance.now();
  resetPollState();                     // 换房:追赶退避从头开始
  S.roomRetryN = 0; clearTimeout(S.roomRetryT); S.roomRetryT = 0;   // 4.1.1:基线已到 → 零基线重试作废归零
  S.offMissing = new Set(); S.covAt = 0; S.covBusy = false;   // 换房:官方缺失/防抖状态清空
  S.covWait = COVERAGE_COOLDOWN_MS;                           // 5.0.4:自适应退避复位
  S.gapSpan = null; S.gapTry = new Map(); S.gapBusy = false; S.gapAt = 0;   // 5.0.4:异房断层不可比,整体作废
  S.gapDead = new Set();
  if (S._jfWait && S.spells.length && S.gameTab && S.rgSkin === 'official'){ S._jfWait = false; loadJiufaFrame(S._jfWaitMode || (S.gameTab === 'real' ? 'real' : 'sim')); }   // 法术表就绪 → 补装官方 iframe(按等待时的 mode)
  rgRoomMaybeChanged();   // 真实游戏:切主播后自动同房重取官方盘面
  D.boardCells = null;   // 换房:丢弃骨架引用,以新房妖怪图/倍率重建
  S.hl.clear();          // 3.4.4 换房:序列聚光随房清空(异房号位节奏不可比);renderAll → syncSpotlight 落地
  if (WV.mode === 'day'){ WV.mode = 'live'; WV.day = ''; ++WV.seq; wvSyncNav(); }   // 3.6.0 换房:回看视图态复位(缓存键含 alias,数据本不串;在飞响应作废)
  wvLoadDays();          // 3.6.0 换房即预取日目录:「全屏」入口可见性(wvSyncEntry)与导航就绪都在 ~RTT 内落定;60s 门与 openWide 的调用天然去重
  S.pred = { main: [], guard: [], nextStart: 0, record: [], ens: [], accuracy: null, vipLocked: false, why: '' };
  // 2.9.0:命中记录/主防号位改由后端(项目 B 集成预测)提供,loadRoom 拉取后渲染
}

/* 4.2.0:**最小重基线**(basic 档「离开太久」用)。
   刻意不复用 applyRoomData —— 那是「换房」的重锤,会顺带:
     · 清空 S.pred(把 basic 档用户正在看的**命中率/命中串**也抹掉)
     · 清序列聚光 S.hl(用户手选的号位没了)
     · rgRoomMaybeChanged() 重取真实游戏盘面(同一个房,纯浪费)
     · wvLoadDays() 多发一次日目录请求
     · D.boardCells=null 强制重建九法阵(无谓闪烁)
   本场景是「同房、只换一批历史」,以上一件都不该发生。故只动历史三件套。 */
function rebaseHist(rows){
  S.hist = (rows || []).map(normRound)
    .filter(r => Number.isInteger(r.n) && r.n >= 1 && r.n <= 9 && Number.isFinite(r.start))
    .sort((a, b) => b.start - a.start);
  S.ids = new Set(S.hist.map(r => r.id));
  pruneHistWindow();
  S.anchor = S.hist[0]?.start || nowC();
  S.lastDataTs = Date.now();
  S.lastDataPerf = performance.now();
}

/* 3.9.3 last-wins:显式切房先抢占租约,再加载 —— 确保后续 renew 命中本房。
   跟随(follow):活跃房被别的窗口/设备切走时,本页**自动切换过去**,不阻断、不死等。 */
let _followToastAt = 0;
/* 跟随目标**加载失败冷却**(实测修复):若跟随目标刚加载失败过(如该房数据面 500、
   或它已被移出名录 → 403),不可立刻再跟随 —— 否则 loadRoom 的通用失败分支会
   startRealtime() → SSE renew 本房 → 又收 follow → 又加载失败 → **无退避空转**
   (实测 3.3 请求/秒,持续到租约 TTL 到期;触发场景:某窗口 claim 某房后崩溃未释放,
   而该房数据面同时故障 —— 无人能挪走租约)。冷却期内改走指数退避重连,冷却到期后
   自然会再试一次跟随 —— 该房恢复即自愈。 */
const FOLLOW_FAIL_MS = 15000;
const _followFail = Object.create(null);
function markFollowFail(room){ _followFail[String(room)] = Date.now() + FOLLOW_FAIL_MS; }
function followBlocked(room){ return Date.now() < (_followFail[String(room)] || 0); }
function scheduleSseBackoff(alias){
  const delay = Math.min(15000, 3000 * Math.pow(1.6, S.sseRetry++)) + Math.random() * 500;
  clearTimeout(S.sseRetryT);
  S.sseRetryT = setTimeout(() => {
    if (S.alias === alias && !document.hidden && !S.offline) connectSSE();
  }, delay);
}
/* **归一号 → 别名映射**(实测修复):后端租约存的是 canon 归一后的**真实房号**,而前端
   整个模型按**用户输入的别名**组织 —— 短号/靓号 ≠ 真实房号(starmeta:「观众输入的房号
   可能是短号/靓号(例:321)」,canon 正是为此存在)。直接拿归一号 loadRoom 会:
   ① store 记成归一号 → 下次启动 inRoster(按 **alias** 匹配)失配 → **「恢复上次房」失效**:
      先打开错的首房、再被 follow 拽回(实测:多一次加载 + 一次误导提示);
   ② 快照键(KEY.snap+alias)错位 → 秒开失效;③ rail 高亮按 dataset.alias 比对 → 失配。
   名录条目本就带 roomId,故映射回本账号熟悉的别名,无需改协议。
   **必须在 followBlocked 之前做**:冷却是按 alias 标记的(markFollowFail(alias)),
   若拿归一号去查冷却会键不匹配 → 冷却形同虚设 → 空转风暴回归。 */
function followTarget(room){
  room = String(room || '').trim();
  if (!room) return '';
  const hit = S.rooms.find(r => String(r.roomId) === room);
  return hit ? String(hit.alias) : room;
}
/* 3.9.4:跟随提示三处补强(实测修正) ——
   ① 归因:旧文案「已切换到**你**最新监控的直播间」在共享账号/多设备场景把别人的
     动作归因给本人,被拽走的一侧只会觉得"软件自己乱跳"。改为如实说明来源
     (另一窗口/设备),并顺带完成规则披露。
   ② 可操作:提示上给「切回 <原房>」按钮 —— last-wins 下"切回"就是一次显式 claim,
     零协议成本把"以谁为准"交还给用户;展示 8s(2.4s 点不到)。
   ③ 拉锯识别:120s 内本窗被跟随 ≥2 次 = 对端在持续切换(共享账号拔河 / 对端设备
     反复重载),升级文案点破现象与规则本身,不再让两边都以为遇到了灵异事件。
   计数只统计"本窗被动跟随",单人单窗自己切房不会触发 —— 无误伤面。 */
const FOLLOW_STORM_WIN = 120000, FOLLOW_STORM_N = 2;
let _followLog = [];
let _followPend = { room: '', at: 0 };   // 同目标去重:S.alias 要到 applyRoomData(fetch 成功后)
                                          // 才更新,在飞窗口内的重复 follow 不该二次计数/重载
function followRoom(room){
  room = followTarget(room);
  if (!room || room === S.alias) return;
  const now = Date.now();
  /* 3.9.4 复审加固:**同目标 5s 去重**。跟随触发到 S.alias 落定之间有一段网络在飞
     窗口 —— 期间若同目标 follow 再次到达(混部老后端兜底/未来新增通道/极端时序),
     `room === S.alias` 挡不住,会把单次切换污染成"拉锯"计数并白增一次 loadRoom。
     不同目标不受此限(对端连续切换本就该逐次计入);首次失败的自愈不依赖重复
     follow(loadRoom 失败分支自带回退首房/冷却),去重无副作用。 */
  if (room === _followPend.room && now - _followPend.at < 5000) return;
  _followPend = { room, at: now };
  _followLog = _followLog.filter(t => now - t < FOLLOW_STORM_WIN);
  _followLog.push(now);
  if (now - _followToastAt > 3000){
    _followToastAt = now;
    const prev = S.alias;                                  // 被切走前本窗正看的房
    const storm = _followLog.length >= FOLLOW_STORM_N;
    const msg = storm
      ? `另一窗口/设备正在切换直播间(同一账号同一时间只实时监控 1 个),已跟随到 ${room}`
      : `已跟随到 ${room} —— 由另一窗口/设备切换`;
    if (prev && prev !== room){
      toastAction(msg, { label: `切回 ${prev}`, ms: 8000,
                         onClick: () => loadRoom(prev, { explicit: true }) });
    } else {
      toastAction(msg, { ms: storm ? 8000 : 5000 });
    }
  }
  loadRoom(room, { explicit: false, silent: false });   // 跟随:renew(不抢占),命中即收敛
}
async function claimActiveRoom(alias){
  // 显式切房抢占;走 api() 正常通道(带 X-JF-Auth)。失败不阻断切房(fail-open)。
  try {
    await api('/api/active-room/claim?roomId=' + encodeURIComponent(alias)
              + '&tab=' + encodeURIComponent(JF_TAB), { method: 'POST' });
  } catch {}
}
async function loadRoom(alias, { silent = false, explicit = false, claimTry = 0, bindTry = 0 } = {}){
  alias = String(alias).trim();
  if (!alias) return;
  const seq = ++S.loadSeq;
  clearTimeout(S.roomBusyT); S.roomBusyT = 0;   // 3.9.3:切房/重载即取消在途重试
  clearTimeout(S.roomRetryT); S.roomRetryT = 0; // 4.1.1:零基线退避重试同拆(本次就是一次重试/换房,旧表作废)
  /* 3.9.4 复审加固:用户**显式**切房 = 旧的跟随上下文作废 —— 清掉同目标去重记录。
     否则极端三连切竞态(对端切 X → 本窗跟随中 → 本窗显式切 Y → 对端 <5s 内又切回 X)
     下,重来的合法 follow(X) 会被 5s 去重误挡:此时 SSE 已随上一个 follow 收流,
     只能靠退避重连兜底,平白多 ~5s 延迟与一次空转重连。显式动作即新纪元,清除即解。 */
  if (explicit) _followPend = { room: '', at: 0 };
  stopRealtime();
  if (!silent) showVeil('正在切换主播', `读取房间 ${alias} 的九法数据`);
  // last-wins:用户**显式**切房 → 先抢占租约到本房(其它窗口随后跟随过来)。
  // 跟随/恢复(explicit=false)不抢占,仅 renew —— 否则会与源窗口互相抢,产生抖动。
  // **按登录开关 gate**(与 POW.on 同款约定):登录系统未启用时后端根本没有租约,
  //   claim 必然是空转往返 —— 不发,保住「未登录/旧后端零影响、逐字节 3.7.0 行为」。
  //   会话请求失败时 AUTH.enabled 保守为 false:那个窗口期数据请求本就会 401 →
  //   登录门 → 登录后再切房自然会 claim,故不会漏抢。
  if (explicit && AUTH.enabled) await claimActiveRoom(alias);
  if (seq !== S.loadSeq) return;                // 抢占期间用户又切了别的房:作废本次

  try {
    const [prof, cfg, hist] = await Promise.all([
      /* 5.0.7:切房准入可能要打一次 roomStatus(后端预算 5s)——
         默认 8s 超时会在后端还没定谳时先抛,把整次切房推进退避重试。 */
      api(`/api/live-rooms/${encodeURIComponent(alias)}/profile?switch=1`, { timeout: 12000 }),
      api(`/api/rooms/${encodeURIComponent(alias)}/config`),
      api(`/api/rooms/${encodeURIComponent(alias)}/history?limit=${HISTORY_LIMIT}`),
    ]);
    if (seq !== S.loadSeq) return;
    if (prof.profile?.exists === false){            // 2.6.14/2.6.16:确认不存在(旧存档遗留/主播已下播)→ 清退并优雅回退
      hideVeil();
      const wasCurrent = S.alias === alias;
      removeCustomRoom(alias, { message: `直播间 ${alias} 已下播或不存在,已移除` });
      // removeCustomRoom 内:删的是当前房时已重载首房。其余情况在此兜底,避免冻结/空白骨架:
      if (!wasCurrent){
        if (S.hist.length) startRealtime();                        // 原有房仍在看 → 恢复其实时,勿冻结
        else if (S.rooms.length) loadRoom(String(S.rooms[0].alias), { explicit: true }); // 无房可显(如启动即失效)→ 回退首房(claim:本页将实际观看它)
      }
      return;
    }
    applyRoomData(alias, prof.profile, cfg.spells, hist.rounds);
    // 2.9.1:SSE 连上前先用 live-rooms 里该房的项目 B 计时垫底(服务器钟差 + 本局锚点)
    const rr = S.rooms.find(r => String(r.alias) === alias);
    if (rr){
      if (S.clockOffset === 0 && Number.isFinite(Number(rr.serverOffsetMs)) && Number(rr.serverOffsetMs) !== 0)
        S.clockOffset = Number(rr.serverOffsetMs);
      applyTimer(rr);                                  // rr.roundStartTimeMs:只前移,空值自动忽略
    }
    /* ★ 见 hydrateSnapshot 尾注:把本机留存的历史并回来,再落快照。
       ingest 按 id 幂等去重、按 start 有序插入,pruneHistWindow 负责裁窗 ——
       并集语义完全复用既有热路径,不新增任何合并逻辑。
       **消费恰一次**:命中即用、不命中即弃(用户在首帧内又切了房的竞态下,
       旧房的种子绝不能并进新房)。 */
    if (S.snapSeed){
      if (S.snapSeed.alias === alias) S.snapSeed.rounds.forEach(ingest);
      S.snapSeed = null;
    }
    /* 5.0.4:首装已是一枪 limit=HISTORY_LIMIT 的全量 —— 后端有的都在盘上了,
       快照回灌那串带 '0' 的旧断口按定义补不回来,故在此作废。
       ★ 诚实标注适用面(5.0.5 A/B 实测修正):这条**只在极窄组合下真的省枪** ——
         后端该房返回空(retention 清过/冷房)+ 快照带断口,且档位为 VIP。
         常态下它是空操作:history 非空时快照种子恒比盘头旧,走 splice 分支根本
         不触 markGap;而 basic 档即便清了,同一帧 checkCoverage 的简版自愈也会
         立刻重新登记(它排在 resyncGap 之前)。留着是两行防御,别把它当性能项。 */
    S.gapSpan = null; S.gapTry = new Map();
    store.set(KEY.room, alias);
    saveSnapshot();
    renderAll();
    // 2.9.0:拉取项目 B 集成预测(主/防号位、命中记录、命中率)
    // 3.2.0:立刻拉(首屏要有内容);若后端刚重启、下一局预测尚未生成,则按退避补问 ——
    // 原先这一步只拉一次,靠 8s 定频兜底;定频没了就必须自己把这条路补上。
    predChase(S.hist[0]?.start || 0, { firstWait: 0, learn: false });
    startRealtime();
    hideVeil();
    /* 3.9.5:冷房唤醒(本次 history/SSE 已触发后端 _touch_room → mp@now)后,
       名录卡片要等 mp 成功写快照才有新鲜 lastOkAt/mode —— 3s 后补拉一次,
       角标从「slow/断」秒级翻回实时读秒,不再多挂最长 ~34s 的过期状态。
       每次切房仅一发、覆盖式定时(连切只留最后一发),成本 = 一次名录读。 */
    clearTimeout(S.roomWakeT);
    S.roomWakeT = setTimeout(refreshLiveRooms, 3000);
    if (!prof.profile?.avatar) lateFillProfile(alias);   // 2.6.9:直开/恢复自添房,资料晚到回填
  } catch (e){
    if (seq !== S.loadSeq) return;
    hideVeil();
    if (AUTH.locked) return;   // 3.8.0:已回落登录门 —— 不再叠加失败 toast
    /* 5.0.7 切房准入的**终态**三种:后台没有它、核验确证未开播、号根本不存在。
       与 exists===false 同款处理 —— 清退 + 优雅回退,而不是落进下面的退避重试:
       那条路会每 3~30s 重试一个后端已经明确说了"没有"的房,永远不会成功,
       还会把用户钉在空白页上。
       **live_unverifiable 刻意不在此列**:那是"上游问不到",不是"这房没了"
       (与后端「问不到 ≠ 没开播」同一条戒律)。它会落到下面的通用失败分支 ——
       提示 + 退避重试,卡留着,上游一恢复就自己回来。 */
    if (['room_not_monitored', 'not_live_now', 'room_unresolved']
        .includes((e && e.data && e.data.error) || '')){
      const wasCurrent = S.alias === alias;
      removeCustomRoom(alias, { message: e.data.message });
      if (!wasCurrent){
        if (S.hist.length) startRealtime();
        else if (S.rooms.length) loadRoom(String(S.rooms[0].alias), { explicit: true });
      }
      return;
    }
    /* 5.0.8 切换即添加:登录态下这个房**不在本账号名录**(room_not_bound)。
       旧行为是甩一句「不在你的名录中,请先添加」就停 —— 后端在这条路上根本没查过
       主播是否在播,而"添加"走的正是「查在册 → 查核验台账 → 打 roomStatus 定谳 →
       在播即绑定」这条阶梯(/api/monitor/add:名额闸 / VIP 闸 / 写令牌 / 溯源标全在
       里面)。用户的意图就是"看这个房",那就替他把这一步走完:在播 → 自动入名录并
       重载;未开播 / 号不存在 → 用后端原话告知,若它是名录里的残影卡(localStorage
       并回来的、服务端早已解绑的房)则顺手清掉,别让一张点不开的卡一直挂着;
       问不到(瞬态)→ 只提示、不删卡。
       三条纪律:
         · 只在**显式**动作上做(点卡 / 搜索框敲号 / 分享链接 ?room=);跟随、存储
           恢复、退避重试一律不做 —— monitor/add 没有同房冷却,自动路径会按
           30s×标签页数的节奏打上游;
         · 每次切房只补绑一次(bindTry 预算,与 claimTry 同款):绑定已落却仍 403
           属基础设施异常,不能无限打转;
         · 补绑失败**不进退避重试**:重试是 explicit=false 的静默路径,只会重复同一个
           403;用户再点一次就是新的一次尝试。 */
    if (explicit && AUTH.enabled && bindTry < 1
        && ((e && e.data && e.data.error) || '') === 'room_not_bound'){
      if (!silent) showVeil('正在核实开播状态', `直播间 ${alias} 不在名录,开播中将自动加入并打开`);
      let bindErr = null;
      try { await api(`/api/monitor/add?room=${encodeURIComponent(alias)}`, { timeout: 15000 }); }
      catch (e2){ bindErr = e2 || new Error('bind_failed'); }
      if (seq !== S.loadSeq) return;              // 等待期间用户又切了别的房:本次作废(绑定若已落,无害且幂等)
      if (!bindErr){
        const mine = loadMyRooms();
        if (!mine.includes(alias)){ mine.push(alias); saveMyRooms(mine); }   // 与 submitAddRoom 同序:后端应答之后才落盘
        upsertCustomRoom(alias); renderRail(D.roomSearch.value);
        toast(`直播间 ${alias} 已自动加入名录,正在打开`);
        loadRoom(alias, { explicit: true, bindTry: bindTry + 1 });   // 重载:绑定已落,顺带重新抢占租约
        return;
      }
      hideVeil();
      const code = (bindErr.data && bindErr.data.error) || '';
      // 业务拒绝用后端原话(未开播 / 查不到 / 名录满 / 问不到…);网络类失败照实说是添加失败,
      // 不能把「不在你的名录中」再抛回给用户 —— 那句在这条路上已经不是事实的全部。
      const msg = (bindErr.data && bindErr.data.message) || (bindErr.data && bindErr.data.error)
                  || `自动添加直播间 ${alias} 失败,请稍后重试`;
      const wasCurrent = S.alias === alias;
      // 终态(确证未开播 / 号不存在)且它是名录卡或当前房 → 按终态清退;其余只提示。
      if ((code === 'not_live_now' || code === 'room_unresolved')
          && (wasCurrent || S.rooms.some(r => String(r.alias) === alias))){
        removeCustomRoom(alias, { message: msg });   // 删的是当前房时它自带回退(切首房 / 开添加层)
        if (!wasCurrent){
          if (S.hist.length) startRealtime();
          else if (S.rooms.length) loadRoom(String(S.rooms[0].alias), { explicit: true });
        }
        return;
      }
      toast(msg);
      if (!wasCurrent && S.hist.length){ startRealtime(); return; }     // 原来的房仍在看 → 恢复其实时(当前房就是它时不恢复:那只会去撞同一个 403)
      if (S.rooms.length && alias !== String(S.rooms[0].alias)) loadRoom(String(S.rooms[0].alias), { explicit: true });
      return;                                                            // 无处回退也不进退避:那条路只会重复同一个 403
    }
    // 3.9.3 last-wins:活跃房被别的窗口/设备切走 → 后端回 room_switched + 应跟随的房号。
    //   本页**自动切换过去**(不是失败、不是死等),与"最后一次切换为准"的模型一致。
    if ((e && e.data && e.data.error) === 'room_switched' && e.data.room){
      // **显式**切房却被回 room_switched → 本次 claim 没生效(POST 故障/竞争;api() 对
      //   非 GET 只试 1 次且失败被吞)。用户「最后一次切换」就是本房,**不能被静默还原
      //   到别人的房**(实测:claim 注入 500 → 用户点 321 却落到 654 + 误导提示)。
      //   补抢一次并重试一次,claimTry 预算封顶,绝不无限重试。
      if (explicit && claimTry < 1){
        loadRoom(alias, { silent: true, explicit: true, claimTry: claimTry + 1 });
        return;
      }
      const _t = followTarget(e.data.room);   // 先归一号→别名,再判冷却
      if (_t && !followBlocked(_t)) followRoom(_t);
      return;                          // 冷却中:不跟随、不重试(SSE 侧的退避会择机再试)
    }
    // 兜底:老后端/边缘态若仍回 room_busy(incumbent 语义),用短固定间隔自动重试本房
    //   (不再死路、不再静默换房)。新后端走 last-wins,此分支通常不触发。
    if ((e && e.data && e.data.error) === 'room_busy'){
      if (!silent) toast(e.data.message || JF_BUSY_MSG);
      clearTimeout(S.roomBusyT);
      S.roomBusyT = setTimeout(() => {
        if (S.alias === alias && !S.offline && !AUTH.locked && !document.hidden)
          loadRoom(alias, { silent: true });
      }, 2500 + Math.random() * 800);
      return;
    }
    if (!silent || !S.roomRetryN) toast((e && e.data && e.data.message) || `读取房间 ${alias} 失败,请重试`);
    // ↑ 4.1.1 复查加固:零基线退避循环内的静默重试不再每轮弹「读取失败」(长时断网
    //   会每 3~30s 骚扰一次);首次失败(roomRetryN 尚为 0)与非退避路径照旧提示。
    markFollowFail(alias);   // 该房确实加载不了 → 冷却期内不再自动跟随它(打断空转)
    if (S.hist.length){ startRealtime(); return; }   // 快照仍在:保持倒计时与轮询,勿僵死
    if (S.rooms.length && alias !== String(S.rooms[0].alias)){
      // claim:本页将实际观看首房。若只 renew,租约可能仍指向那个刚加载失败的房 →
      // 被回 room_switched 弹回去 → 再失败 → 反复打转。
      loadRoom(S.rooms[0].alias, { explicit: true });
      return;
    }
    /* 4.1.1:零基线死端自愈 —— 首装三请求全灭且无处回退(典型:移动端杀浏览器重开,
       首几秒电台/Wi-Fi 未醒,恰逢快照过期 26h)。此前这里静默放弃后,**再无任何
       代码路径**会重新触发 loadRoom:SSE/轮询/名录拍乃至游戏帧的 pullNow 都只走
       ingest 增量补局,永不补 spells(唯一赋值点在 applyRoomData)→ 九法阵永远
       空板、官方象限「正在装载」永驻,收起重开面板亦无解,唯有整页刷新
       (Chromium/WebKit 实证)。指数退避重试:3s 起 ×2 封顶 30s + 抖动,不设次数
       上限(与「基线终会到位」的全站预期对齐);成功(applyRoomData)/换房
       (loadRoom 序言)即拆表归零。隐藏页与离线不空转 —— 让位给 visibilitychange
       / online 钩子的零基线补拉,回前台/联网即时救。 */
    const n = S.roomRetryN || 0; S.roomRetryN = n + 1;
    const wait = Math.min(30000, 3000 * Math.pow(2, Math.min(n, 4))) + Math.random() * 800;
    clearTimeout(S.roomRetryT);
    S.roomRetryT = setTimeout(() => {
      S.roomRetryT = 0;
      if (S.alias === alias && !S.offline && !AUTH.locked && !document.hidden && !S.spells.length)
        loadRoom(alias, { silent: true });
    }, wait);
  }
}

/* ═══════════ 实时层:回合时钟 + SSE + 轮询 ═══════════ */
function curStart(now = nowC()){
  if (!S.anchor) return now;
  // 2.9.3:不再把 n 钳制到 ≥0 —— 锚点只是 50001 栅格上的一个参考点;
  // 若种子/推送带来「下一局」起点(未来值),当前局 = 前一个栅格槽
  // (n = -1),读秒/相位仍然如实(杜绝 >40s 读秒与相位错报)。
  const n = Math.floor((now - S.anchor) / T.ROUND);
  return S.anchor + n * T.ROUND;
}
function calibrate(serverNowMs){
  const ms = Number(serverNowMs);
  if (!ms) return;
  const raw = ms - Date.now();
  S.clockOffset = S.clockOffset === 0 ? raw : S.clockOffset * 0.8 + raw * 0.2;
}
/* 3.2.0:SSE 掉线时的退化校时通道 —— 每个 /history 响应都自带 HTTP `Date` 头。
   Date 只有秒级精度:真实生成时刻落在 [D, D+1000),取中点 +500;再补半个 RTT
   作为回程时延。误差 ≲600ms,远小于 S.lagMs(≈2.6s)的判据窗口。
   为什么必须有它:calibrate() 原本只被 SSE 的两个 handler 调用,SSE 一断
   S.clockOffset 就冻住;本地钟偏 5 秒,「出怪时刻」就算偏 5 秒,追赶的第一枪必空。
   SSE 在线时不用它 —— serverNowMs 是毫秒级、更准,别让秒级精度去污染 EMA。 */
function calibrateFromDate(res, rtt){
  if (sseAlive()) return;   // 3.3.9:活性判据 —— 半开假活时 SSE 校时已断供,须启用本降级通道
  const raw = res && res.headers && res.headers.get('date');
  if (!raw) return;
  let ms = Date.parse(raw);
  if (!Number.isFinite(ms)){
    // 反代/上游可能重复下发 Date;fetch 把同名头用 ", " 合并 → Date.parse 直接 NaN。
    // HTTP-date 自身含一个逗号("Thu, 09 Jul 2026 05:39:14 GMT"),故取到第二个逗号之前。
    const m = String(raw).match(/^[^,]+,[^,]+/);
    ms = m ? Date.parse(m[0]) : NaN;
  }
  if (!Number.isFinite(ms)) return;
  calibrate(ms + 500 + Math.min(Math.max(rtt, 0), 2000) / 2);
}

/* ── 「本地是否落后于应有进度」──────────────────────────────────────────
   局起点栅格步进 50001ms,出怪在局内 T.DRAW;后端约 T.DRAW+2.6s 才把这一局写进库。
   所以 **在这一刻之前,拉取必然返回空数组**,一次都不该发。
   expectedLatestStart(now) = 按当前时刻,本地理应已经持有的最新一局的起点。
   注:S.anchor 每落地一局就被 ingest() 重置为 hist[0].start(服务端真值),
   栅格本身不会漂;会漂的只有「现在几点」,那由上面的校时兜住。 */
function chaseThreshold(){
  // 3.3.1:锚点从 drawTime 移到备战(T.CAST)—— 与后端一致。
  // 后端 award 抓取在备战+1.5s、抓到即 SSE 广播,数据在库约局内 37s 就有。
  // 旧锚 T.DRAW(40s)+lagMs(下限1.2s)= 最早局内 41.2s,SSE 掉线用户白等约 4s。
  // 现锚 T.CAST(35s)+lagMs(初值2.6s)≈ 局内 37.6s,与后端写库时刻对齐;
  // learnLag 的 AIMD 会把 lagMs 收敛到真实的「备战后多久可取」。
  return T.CAST + S.lagMs + (S.sse === 'live' ? SSE_GRACE_MS : 0);
}
/* 学「出怪后多久数据可取」。AIMD,与 predSettleMs 同构:
     · 首枪即中   → 减 200ms,慢慢往前探(加性递减)
     · 退避后才中 → 退到「命中那一枪的发出偏移 + 250ms」(跳跃式后退)
   千万别写成「命中就 EMA(偏移) + 固定余量」:偏移里含着退避多等的那段,
   每命中一次估计就再涨一点,单调爬到上限,稳态退化成每局固定几枪。
   (predChase 第一版就是这么发散的,实测同局重试间隔 2.14→3.82→5.90s 爬满。)
   只在追赶路径上学 —— SSE 健康时根本不发请求,自然也没得学,lagMs 停在初值,
   而那时门槛偏大反而更保险(不会抢在 SSE 推送之前)。 */
function learnLag(offsetMs, firstShot){
  S.lagMs = firstShot
    ? clampN(LAG_MIN_MS, S.lagMs - LAG_PROBE_MS, LAG_MAX_MS)
    : clampN(LAG_MIN_MS, Math.round(offsetMs) + LAG_MARGIN_MS, LAG_MAX_MS);
}
function expectedLatestStart(now = nowC()){
  const cs = curStart(now);
  return (now - cs) >= chaseThreshold() ? cs : cs - T.ROUND;
}
function isBehind(now = nowC()){
  if (!S.hist.length) return true;                 // 一局都没有:必须拉
  return S.hist[0].start < expectedLatestStart(now);
}
function resetPollState(){
  S.pollBackoff = 0; S.nextPollAt = 0; S.behind = false; S.lastMonoProbe = 0;
}

/* ── 墙钟跳变探测(容错的关键一环)──────────────────────────────────────
   performance.now() 单调,不受系统时间校正影响;Date.now() - performance.now()
   在系统钟稳定时是个常量(≈ timeOrigin)。NTP 校正、休眠唤醒会让它**突变**。
   为什么非探不可:系统时间往回跳时,curStart(now) 退回旧栅格,
   expectedLatestStart 随之退回,isBehind() 会永远为假 —— 前端自以为已是最新,
   彻底静默。这是本方案唯一的死锁模式。
   探到就:作废旧校时偏移(它建立在旧墙钟上)+ 重置追赶节奏 + 立刻拉一次
   (响应的 Date 头顺手把 clockOffset 重建)。~200ms 内自愈。
   STALE_FUSE_MS 仍留作最后一道(tick 被节流、跳变幅度小于阈值等)。 */
const WALL_JUMP_MS = 2000;
function detectWallJump(){
  const d = Date.now() - performance.now();
  if (!S.wallRef){ S.wallRef = d; return false; }
  if (Math.abs(d - S.wallRef) > WALL_JUMP_MS){
    S.wallRef = d;
    S.clockOffset = 0;                          // calibrate() 见 0 会直接取下一个观测值重建
    resetPollState();
    return true;
  }
  S.wallRef = S.wallRef * 0.98 + d * 0.02;      // 慢跟随:吸收 ppm 级漂移,不误触发
  return false;
}

/* ── 自适应调度(由 tick 的 200ms 心跳驱动,不另开定时器)──────────────
   ① 未落后 → 一次都不发。SSE 健康时它会零请求把新局推过来,于是**整局零 /history**。
   ② 落后   → 立刻发一次,之后按 1.2s→1.9s→3.1s→5s→8s(封顶)退避重拉,直到追平。
              封顶 8s = 旧的定频间隔,所以「数据已就绪却还没取」的最坏等待不劣于改造前。
   ③ 保险丝 → 距上次真实数据到达超过 STALE_FUSE_MS(单调钟)就无条件拉一次。
              这是 ① 的唯一失效模式的解药:系统时间**往回跳**时 curStart 退回旧栅格,
              expectedLatestStart 随之退回,isBehind 会永远为假、静默卡死。 */
function schedulePolls(now){
  if (!S.alias || S.offline || document.hidden) return;

  if (detectWallJump()){ pollNew(); return; }    // 系统钟跳了:偏移作废,立刻重取并重建校时

  const perf = performance.now();
  if (S.lastDataPerf && perf - S.lastDataPerf > STALE_FUSE_MS && !S.pollBusy){
    S.lastDataPerf = perf;                          // 熔断即重置,避免每拍狂拉
    resetPollState();
    pollNew();
    return;
  }

  /* 3.3.9 追拉风暴修复(真机 HAR 实证):chaseThreshold 假设「后端约备战+2.6s 就把
     本局写进库」——真机上游可取时刻在**备战后 4~40s+**高方差波动(HAR 实测),该假设
     远早于真实入库。SSE 健康时 isBehind 会在 [备战+2.6s, 真实捕获] 这段空窗里持续为真,
     每拍(退避 1.2→8s)空拉 /history 直到数据落库 —— 慢局甚至拖到下一局倒计时 ~30s 才
     命中(HAR round …3286038/…4486062 实证)。但 SSE **必**在真实捕获时刻把该局推来,
     此处的追拉纯属冗余。故:SSE 健康 → 不因落后而追拉,完整性交给 checkCoverage(每落地
     一局查洞,15s 防抖)+ STALE_FUSE(SSE 静默熔断)兜底。这才真正兑现 ①「SSE 健康 →
     整局零 /history」。判据用 sseAlive()(活性,而非裸 'live' 态):半开假活连接静默
     >45s 自动回退下方追拉;SSE 掉线(sse!=='live')时原逻辑照常,失效模式不变。
     断线重连的漏局由 connected 握手补拉(见 connectSSE)即时捞回。 */
  if (sseAlive()){
    if (S.behind){ S.behind = false; S.pollBackoff = 0; S.nextPollAt = Infinity; }
    return;
  }

  const behind = isBehind(now);
  if (behind !== S.behind){                         // 状态翻转:重排节奏
    S.behind = behind;
    S.pollBackoff = 0;
    S.nextPollAt = behind ? 0 : Infinity;           // 追平后不再定频;等下一次翻转或保险丝
  }

  /* 3.4.3 SSE 死时的单调钟兜底(真机 HAR 实证的滞后修复):
     isBehind 依赖**绝对钟**(curStart = anchor + ⌊(now−anchor)/ROUND⌋)。而 SSE 是
     clockOffset 的主校时源(calibrate 由 SSE 的 connected/heartbeat 调用)——SSE 一旦
     被反代缓冲/阻断(用户部署实测:HAR 里 /api/events 零请求),clockOffset 只剩
     一次加载时的 live-rooms 垫值 + Date 头的秒级校时。本地钟只要比服务器**慢** ~10s+
     (NTP 漂移/休眠唤醒很常见),curStart 就会算成「还没进到下一局的就绪时刻」,
     isBehind 恒假 → 主动追拉从不触发 → 数据只能靠 STALE_FUSE(70s)兜回来。
     这正是 HAR 里 /history 稳定 ~68s 一拍(≈STALE_FUSE)、数据恒晚 1.3 局的成因。

     兜底:SSE 不活时,用**单调钟**(performance.now,不受 NTP/钟偏影响)确保
     「距上次拿到新数据超过 ~1 局」就无条件追一枪。它与上面基于绝对钟的 chase 并存 ——
     钟准时 chase 先触发(局内 ~37s 即追,数据几乎不晚);钟偏导致 chase 哑火时,
     这条把最坏滞后从 STALE_FUSE(70s)压到约 1 局(~50s)且**与钟偏无关**。
     封顶节流 CHASE_MAX_MS,避免数据真没就绪时空拉风暴。 */
  if (!behind && !S.pollBusy){
    const sinceData = S.lastDataPerf ? (perf - S.lastDataPerf) : Infinity;
    const sinceProbe = S.lastMonoProbe ? (perf - S.lastMonoProbe) : Infinity;
    if (sinceData >= T.ROUND && sinceProbe >= CHASE_MAX_MS){
      S.lastMonoProbe = perf;
      pollNew();                                    // 不带 chase 上下文:不污染 lagMs 学习
      return;
    }
  }

  if (!behind || now < S.nextPollAt) return;

  const firstShot = S.pollBackoff === 0;            // 本轮追赶的第一枪
  const cs = curStart(now);
  S.pollBackoff = S.pollBackoff
    ? Math.min(CHASE_MAX_MS, Math.round(S.pollBackoff * CHASE_GROW))
    : CHASE_MIN_MS;
  S.nextPollAt = now + S.pollBackoff;
  // chase 上下文交给 pollNew:命中当前局时用它来学 lagMs
  pollNew({ chase: true, firstShot, cs, offset: now - cs - T.CAST });   // 3.3.1:锚点备战(见 chaseThreshold)
}
/* 2.9.1:倒计时锚点以项目 B 为准 —— 后端把项目 B 每局从 MainPage 拿到的权威计时
   (本局起点 roundStartTimeMs 等)经 SSE(connected/heartbeat/换局即时推)与
   live-rooms 下发;锚点只前移(旧局回填/迟到事件不回拨),配合真实步进 50001
   与 calibrate 的服务器钟,倒计时与项目 B 完全同源。 */
function applyTimer(t){
  const start = Number(t && t.roundStartTimeMs);
  if (!Number.isFinite(start) || start <= 0) return;
  if (start > (S.anchor || 0)){
    S.anchor = start;
    tick();                                    // 锚点跃迁即时反映到相位环/倒计时
  }
}

function startTick(){
  clearInterval(S.tickId);
  S.tickId = setInterval(tick, 200);
  tick();
}
function tick(){
  const now = nowC();
  const cs = curStart(now);
  const t = now - cs;

  let phase, remain, pct, hint, pendTxt, pendCls, pendPct, pendMode;
  if (t < T.DRAW){
    /* 2.9.2:「施法期」与「备战」的倒计时合并 —— 同一段「距出怪」读秒
       (40→1 连续,不再在 35s 处重置为 5→1);进度环一笔扫满 40s,恰在出怪归零。
       3.1.1:悬挂珠彻底跟随这段合并读秒 —— 备战期不再把数字换成「封」字。
       3.3.1:结果提前到账(备战后即可取,后端备战+1.5s 抓即广播)→ 本局已是结果珠时,
       悬挂珠与提示直接显示「已开出」,不再倒数本局(已出结果旁还倒数会矛盾)。
       相位环/标签仍按官方时间线走(距出怪读秒),诚实反映「官方还没揭晓、我们已拿到」。
       3.4.5:上条的「开」进一步收窄为**等待态专属** —— 结果一上盘(landed,与九法阵
       is-latest 同判据 h0.start===cs)悬挂珠即改读秒至下一局出怪(cs+ROUND+DRAW−now),
       秒数跨换局边界严格连续(…42·41｜换局｜40·39…),语义回归「距下一颗珠落盘」;
       进度环按下一局 40s 刻度计,本局未完恒 0(蓄势),换局起步与常规读秒环无缝衔接。
       实测旧行为:健康链路下「开」与结果珠并存约 13.5s/局,且无法与「结果未到」区分。 */
    const sealed = t >= T.CAST;
    phase = sealed ? 'seal' : 'cast';
    remain = T.DRAW - t; pct = t / T.DRAW;
    const h0 = S.hist[0];
    const landed = !!(h0 && h0.start === cs);      // 本局结果已上盘(原 drawnEarly)
    if (landed){
      hint = `本局已开出 <b>${h0.n} · ${esc(h0.name)}</b>`;
      pendMode = 'next';
    } else {
      hint = sealed
        ? `备战中,<b>${Math.ceil(remain/1000)}s</b> 后出怪`
        : `施法期进行中,距出怪 <b>${Math.ceil(remain/1000)}s</b>`;
      pendMode = 'this';
      pendCls = sealed ? 'is-seal' : '';           // 配色仍标注备战相位
    }
  } else {
    phase = 'draw'; remain = T.END - t; pct = (t - T.DRAW) / (T.END - T.DRAW);
    const latest = S.hist[0];
    const landed = !!(latest && latest.start === cs);
    hint = landed
      ? `本局已开出 <b>${latest.n} · ${esc(latest.name)}</b>`
      : `出怪结果揭晓中…`;
    pendMode = landed ? 'next' : 'wait';
  }
  /* 3.4.5 悬挂珠三态收敛点(this=本局读秒 / wait=开·等待揭晓 / next=下局读秒) */
  if (pendMode === 'next'){
    pendTxt = String(Math.max(1, Math.ceil((cs + T.ROUND + T.DRAW - now) / 1000)));
    pendCls = '';                                  // 回到青绿本色 = 常规读秒同款,换局零跳变
    pendPct = Math.max(0, (t - T.ROUND) / T.DRAW); // 下一局刻度:未开局恒 0,换局即接上
  } else if (pendMode === 'wait'){
    pendTxt = '开'; pendCls = 'is-draw';           // 朱砂「开」= 官方出怪中、结果未到
    pendPct = pct;
  } else {
    pendTxt = String(Math.ceil(remain/1000));      // 纯数字,不带 s;备战期照常读秒
    pendPct = pct;
  }
  // 3.2.0:拉取时机由 schedulePolls 统一裁决(取代原先「出怪后定点一枪 + 8s 定频」)。
  // 放在相位分支之外:落后判定对施法期同样有效 —— 比如上一局压根没落地。
  schedulePolls(now);

  const secs = Math.max(0, Math.ceil(remain/1000));
  D.ringSeconds.textContent = secs;
  D.ringPhase.textContent = phase === 'cast' ? '施法期' : phase === 'seal' ? '备战' : '出怪';
  D.liveRing.style.setProperty('--p', (pct*100).toFixed(1));
  D.liveRing.classList.toggle('is-seal', phase === 'seal');
  D.liveRing.classList.toggle('is-draw', phase === 'draw');

  D.phaseFill.style.width = (t / T.ROUND * 100).toFixed(1) + '%';
  D.phaseTrack.classList.toggle('is-seal', phase === 'seal');
  D.phaseTrack.classList.toggle('is-draw', phase === 'draw');
  for (const k of ['cast','seal','draw']){
    const node = D.phaseNodes[k];
    const order = { cast:0, seal:1, draw:2 };
    node.classList.toggle('is-on', k === phase);
    node.classList.toggle('is-done', order[k] < order[phase]);
  }
  D.phaseHint.innerHTML = hint;
  D.roundNo.textContent = '№ ' + dayNo(cs);
  D.roundClock.textContent = fmtClock(cs) + ' 起';
  D.topClock.textContent = fmtClock(now);

  const pendP = (pendPct*100).toFixed(1);        // 3.4.5:环随悬挂珠三态,不再恒等相位环
  const pendTitle = PEND_TITLES[pendMode];
  for (const el of D.pendingEls || []){
    el.textContent = pendTxt;
    el.classList.toggle('is-seal', pendCls === 'is-seal');
    el.classList.toggle('is-draw', pendCls === 'is-draw');
    el.style.setProperty('--p', pendP);          // 相位进度环(与心跳环同源)
    if (el.title !== pendTitle) el.title = pendTitle;   // 3.4.5:tooltip 随三态;重建后下一拍自愈
  }

  // 数据陈旧守护
  if (S.alias && S.hist.length){
    const age = Date.now() - S.lastDataTs;
    if (age > STALE_MS){
      D.staleBadge.hidden = false;
      D.staleBadge.textContent = `滞后 ${Math.floor(age/1000)}s`;
    } else D.staleBadge.hidden = true;
  }
  paintConnTruth();   // 4.3.6:半开连接下把徽章从「实时」纠正为「轮询中」(见函数注)

  // 2.6.3:标题按秒变化,tick 每 200ms 一次 —— 仅在文本真正变化时写入
  /* 4.8.0:标题补房号 —— 同时开多个标签页盯不同直播间时,页签是唯一的区分处。
     房号排在品牌名之前:页签宽度不足时浏览器从右截断,靠后的字先没。 */
  const title = `${secs}s ${D.ringPhase.textContent} · `
    + (roomTag() ? roomTag() + ' · ' : '') + '小叮当九法数据';
  if (S._title !== title){ S._title = title; document.title = title; }
  refreshBoardLatest();    // 相位驱动的出怪态:施法/备战期重置,出怪期点亮
  refreshPredictLabel();   // 相位驱动的推演标签:目标局开始后「下一局」翻为「本局」
  // 3.8.2 跨零点自刷新:「今日」列此前只随 ingest / 换房重算 —— 断流跨北京零点
  // 期间整晚顶着昨天的计数。tick 每拍(200ms,后台钳到 ~1s)核对日界,翻日即重渲
  // 出怪司历一次;日界未变零成本(一次 bjMidnightOf 纯算术)。校准钟跳变恰好
  // 跨界时同样触发 —— 那正是"今日"边界真实移动的时刻,重算即正确。
  const mid0 = midnight();
  if (S._midSeen !== mid0){
    const first = S._midSeen === undefined;
    S._midSeen = mid0;
    if (!first) renderCensus();
  }
  renderJiufaSync(phase, secs, cs);   // 模拟游戏同步条:同一引擎、同一局的常驻凭证
}

function setConn(state, label){
  S.sse = state;                                   // 3.2.0:连接态单点镜像,供拉取策略读取
  S.connLabel = label;                             // 4.3.6:供 paintConnTruth 在假活解除后原样还原
  D.connState.dataset.state = state;
  D.connState.querySelector('b').textContent = label;
}
/* ═══ 4.3.6 连接徽章诚实化(实机复现驱动)═══════════════════════════════════
   下面 sseAlive() 的 3.3.9 注早已写明:'live' 只代表「未收到 onerror」,半开连接
   不触发 onerror ⇒ 状态会假活。该判据当时只被**取数策略**消费,那枚用户唯一能
   看见的连接徽章从未据此纠正过。

   ★ 复现条件必须精确,否则会得出相反结论(以下三条都是实测走过的弯路):
     · 用 Playwright 的 set_offline 复现 → **无效**:它不拆已建立的 localhost
       连接,心跳照常到达,此时显示「实时」是**正确**的。
     · 用 fuser -k / pkill 杀服务端 → **无效**:命令可能静默失败,服务端根本没死。
     · 真把服务端杀掉(且已核实端口不可达)→ **也不是本缺口**:socket 断开会触发
       onerror,既有代码 15s 内就正确切到「轮询中」。这一条无需修。
   真正的缺口只有一种形态:**半开** —— TCP 连接活着,但对端不再下发任何字节
   (反代挂死 / 中间盒静默丢流 / 服务端线程卡死)。此时 onerror 永不触发。
   实测(SSE 建连 8s 后转静默、socket 保持打开):
     未打补丁:t=10/30/50/60/75/95s **全程「实时」**,且此后永不改变;
     打补丁后:t=60s 起转为「轮询中」(= SSE_SILENT_MS 45s + tick 节拍),与
               取数策略此刻的真实行为完全一致。
   对一个卖点就是实时数据的产品,这是诚实性缺口 —— 项目自己在
   README「3.9.5 名录角标诚实化 / lastOkAt 不再伪装新鲜」立的就是这条标准。

   实现纪律:
     · **只改显示,绝不动 S.sse** —— 重连退避(scheduleSseBackoff)、追拉抑制、
       校时通道选择、租约续期全部读 S.sse,改它等于改行为面。本函数零副作用。
     · 复用既有 'poll' 态与「轮询中」文案:不新增 CSS、不新造词汇,且**字面为真**
       —— sseAlive() 为假时,取数各路本就已回退到轮询语义。
     · 幂等:仅在值真变化时写 DOM(tick 每 200ms 一拍,不能每拍都写)。
     · 未连过(S.sse='idle'/'连接中')不介入 —— 开机窗口不该被误标。 */
function paintConnTruth(){
  const el = D.connState; if (!el) return;
  const b = el.querySelector('b'); if (!b) return;
  const fake = !S.offline && S.sse === 'live' && !sseAlive();
  const state = fake ? 'poll' : S.sse;
  const label = fake ? '轮询中' : (S.connLabel || b.textContent);
  if (el.dataset.state !== state) el.dataset.state = state;
  if (b.textContent !== label)    b.textContent = label;
}
/* 3.3.9 SSE 活性判据:'live' 只代表「未收到 onerror」—— 半开连接(反代挂死、链路
   静默断)不触发 onerror,状态会假活。后端心跳恒 20s 一拍(另有每局换局推送),
   健康连接的事件间隔必 ≤20s;静默超 SSE_SILENT_MS 即视为不活,信任推送的各路
   (追拉抑制 / 预测单发对账 / 校时通道选择)全部回退到轮询语义,数据不断供。 */
function sseAlive(){
  return S.sse === 'live' && S.sseSeenPerf &&
         (performance.now() - S.sseSeenPerf) < SSE_SILENT_MS;
}

function startRealtime(){
  resetPollState();
  startTick();                                     // 200ms 心跳:相位渲染 + schedulePolls
  connectSSE();
  // 3.2.0:不再 setInterval(pollNew, 8000)。拉取完全由 schedulePolls 按需触发。
}
function stopRealtime(){
  clearInterval(S.tickId);
  clearTimeout(S.predChaseT); S.predChaseT = 0;
  clearTimeout(S.sseRetryT); S.sseRetryT = 0;   // 3.9.3:停流即取消在途重连(含 leaseBusy 短重试),
                                               // 免得关页/切房后还有孤儿定时器把连接拉回来
  S.leaseBusyPending = false;
  resetPollState();
  if (S.es){ try { S.es.close(); } catch {} S.es = null; }
  setConn('idle', '连接中');
}
function connectSSE(){
  if (S.offline) return;
  if (S.es){ try { S.es.close(); } catch {} }
  clearTimeout(S.sseRetryT);              // 新连接:清掉任何在途重连定时器,避免叠加
  S.leaseBusyPending = false;             // 每次新连接从干净态开始(见 leaseBusy/onerror)
  const alias = S.alias;
  const es = new EventSource(`/api/events?roomId=${encodeURIComponent(alias)}&tab=${encodeURIComponent(JF_TAB)}`);
  S.es = es;
  const onAlive = ev => {
    if (S.alias !== alias) return;
    S.sseSeenPerf = performance.now();             // 3.3.9:活性时间戳(sseAlive 判据)
    S.sseRetry = 0; setConn('live','实时');
    try {
      const d = JSON.parse(ev.data || '{}');
      calibrate(d.serverNowMs);
      if (d.timer) applyTimer(d.timer);        // 连上/心跳即以项目 B 权威计时对齐倒计时
    } catch {}
  };
  es.addEventListener('connected', ev => {
    onAlive(ev);
    // 3.3.9 重连补拉:断线期间漏掉的局,原版靠追赶轮询捞回;3.3.9 起 SSE 活性期
    // 抑制追拉,故重连握手时若本地已落后,立即补拉一枪(在线且未落后则零请求)。
    if (S.alias === alias && isBehind()) pollNew();
  });
  es.addEventListener('heartbeat', onAlive);
  // 3.8.0 复查修复:服务端在心跳节拍上复核会话,被顶/封停/到期即发本事件并断流 ——
  // 立刻回落登录门(与轮询 401 同一收口;登录未启用时该事件永不出现)。
  es.addEventListener('authRevoked', ev => {
    let d = {}; try { d = JSON.parse(ev.data || '{}'); } catch {}
    handleAuthError({ error: d.error || 'auth_required' });
  });
  // 3.9.3 last-wins:活跃房被别的窗口/设备切走 → 后端发 follow(带应跟随的房号)并收流。
  //   本页**自动切换过去** —— "以最后一次切换的直播间为准"。收流后不再退避重连本房。
  es.addEventListener('follow', ev => {
    if (S.alias !== alias) return;
    let d = {}; try { d = JSON.parse(ev.data || '{}'); } catch {}
    S.leaseBusyPending = true;           // 本次收流是"被切走",非故障 → 让 onerror 跳过退避
    try { es.close(); } catch {}
    const _t = followTarget(d.room);     // 先归一号→别名,再判冷却(键须与 markFollowFail 一致)
    if (_t && !followBlocked(_t)){
      followRoom(_t);                    // 自动跟随到最新的房(followRoom 内部 loadRoom 会重连)
      return;
    }
    // 跟随目标处于失败冷却(该房刚加载失败过)→ 不跟随,改退避重连本房,避免空转风暴
    scheduleSseBackoff(alias);
  });
  // 兜底:老后端若仍发 leaseBusy(incumbent 语义)→ 短固定重试本房(不进指数退避)。
  //   新后端走 last-wins、发 follow,此监听通常不触发。
  es.addEventListener('leaseBusy', () => {
    if (S.alias !== alias) return;
    jfToast(JF_BUSY_MSG);
    S.leaseBusyPending = true;
    try { es.close(); } catch {}
    clearTimeout(S.sseRetryT);
    S.sseRetryT = setTimeout(() => {
      if (S.alias === alias && !document.hidden && !S.offline) connectSSE();
    }, 2500 + Math.random() * 800);
  });
  es.addEventListener('room-updated', ev => {
    if (S.alias !== alias) return;
    S.sseSeenPerf = performance.now();             // 3.3.9:活性时间戳(sseAlive 判据)
    try {
      const d = JSON.parse(ev.data || '{}');
      calibrate(d.serverNowMs);
      if (d.timer) applyTimer(d.timer);        // 换局即时推:倒计时锚点第一时间跳到新局
      if (d.pred) applyPredPush(d.pred);       // 3.3.5 同帧判定:先合入,再 ingest → 首帧即主中/防中/未中
      if (d.round) ingest(d.round);            // 出怪即时推:数据第一时间入账(项目 B 捕获时刻)
      else if (d.roundsTouched) pollNew();
    } catch { pollNew(); }
  });
  /* 4.9.3:接上后端一直在发、前端一直没接的 `pred-updated` 通道(worker 自
     3.3.5 起在补链/结算路径 publish,SSE 网关按 payload.type 转发事件名 ——
     旧前端无监听器故整条通道被静默丢弃,当时注释也写明「旧前端忽略」)。
     两个用途:① 载荷含 next/settled 时与 room-updated 内联 pred 同构,直接
     applyPredPush(幂等 + 单调守卫俱在,双路到达零害);② 4.9.3 补算把窗口
     补满后发 {pred:{acc:1}} —— 命中率是聚合量,推送只携「变了」信号,前端
     refreshPrediction 权威拉取(与 predChase 的对账哲学一致:推送保鲜,
     拉取定真)。后台标签不拉(document.hidden),回前台由既有可见性钩子对账。
     不碰 sseSeenPerf:活性判据仍以 room-updated/heartbeat 为准,补算推送
     不该掩盖出怪断流。 */
  es.addEventListener('pred-updated', ev => {
    if (S.alias !== alias) return;
    try {
      const d = JSON.parse(ev.data || '{}');
      if (d.pred) applyPredPush(d.pred);
      if (d.pred && d.pred.acc && !document.hidden) refreshPrediction(alias);
    } catch { /* 载荷异常不致命:predChase 权威对账兜底 */ }
  });
  es.onerror = () => {
    if (S.alias !== alias) return;
    if (S.leaseBusyPending) { S.leaseBusyPending = false; return; }  // leaseBusy 已自排短重连,勿再退避
    if (!S.offline) setConn('poll', '轮询中');
    try { es.close(); } catch {}
    scheduleSseBackoff(alias);
  };
}
/* 只拉 /history。3.2.0 起不再搭车拉 /prediction ——
   后者是 3 条 SQL,而预测只随「局」变,由 predChase() 在新局落地后按需补拉。
   opt(仅追赶路径传):{chase, firstShot, cs, offset} —— 命中当前局时喂给 learnLag。 */
async function pollNew(opt){
  if (!S.alias || S.offline || S.pollBusy) return;
  const alias = S.alias;
  S.pollBusy = true;
  try {
    const since = (S.hist[0]?.start || 0) + 1;
    const d = await api(`/api/rooms/${encodeURIComponent(alias)}/history?since=${since}&limit=200`,
                        { onRes: calibrateFromDate });
    if (S.alias !== alias) return;
    const rows = (d.rounds || []).slice().sort((a,b) => a.start_time_ms - b.start_time_ms);
    /* ── 4.2.0 basic 档:断档即**重新起算**,而不是留一个洞 ────────────────
       一局 ≈ 50s,后端把 basic 档的 limit 钳到 N(默认 30)≈ 25 分钟。用户把标签
       挂后台超过这个时长再回来,增量拉取只能回 N 条 —— 中间必然有缺口。
       与其在序列上留一段莫名其妙的空白(用户会当成数据丢失来投诉),不如如实
       按「最新 N 局」重建基线并一句话说明:长时间离线在语义上**等同于一次刷新**,
       这与需求「每次刷新页面后只提供最后 N 个数据开始累计」完全自洽。 */
    if (isBasic() && rows.length && S.hist.length){
      const oldest = Number(rows[0].start_time_ms) || 0;
      const newest = Number(S.hist[0].start) || 0;
      if (oldest > newest + T.ROUND * 1.5){      // 中间确实断了 ≥1 局
        const miss = Math.max(1, Math.round((oldest - newest) / T.ROUND) - 1);
        if (JF.onlineH > 0){
          /* ── 4.4.0:保留已看到的,把缺口如实标成断口 ──────────────────────
             §4.3 当初选择重基线,顾虑是「序列上留一段空白,用户会当成数据丢失
             来投诉」—— 那个顾虑是对的,但正解是**说明**,不是**清空**。清空
             会把用户攒了半天的窗口一次抹掉,那才是真的"数据丢失"。
             现在:断口后那颗珠带 data-gap(hover 读「此处 N 局未观测」),
             连空统计在断口处截断并显 ≥(见 deriveStats)。
             这段缺口在 API 层**补不回来**(limit 钳 N + until 被拒),
             所以唯一诚实的做法是标出来,而不是假装它不存在。 */
          rows.forEach(ingest);                   // 渲染交 flushIngest(与常态同路)
          /* 5.0.4:先按 basic 硬闸能取到的范围定向补一次(since 只抬下界,后端把
             limit 钳到 jf_basic_history_limit,结果恒 ⊆「最新 N 局」,与直接
             /history?limit=N 同一批数据,不多给一个字节)。补不到的才是真断口 ——
             提示数字改用**补齐后的真实剩余**,否则盘上明明补上了 20 局,提示还在
             说「中间 20 局未观测」。 */
          const left = await resyncGap();
          if (S.alias !== alias) return;          // resyncGap 也是一次 await:期间换房则这条提示属于旧房
          const shown = left >= 0 ? left : miss;
          if (shown > 0)
            toastAction(`离开较久,中间 ${shown} 局未观测,序列已标断口`,
                        { label: '开通VIP看满24小时', ms: 8000,
                          onClick: () => showVipGate('upsell') });
          return;
        }
        rebaseHist(d.rounds || []);               // 窗=0:逐字节 4.3.x 行为
        renderAll();
        toastAction(`离开较久,已按最新 ${JF.histLimit} 局重新起算`,
                    { label: '开通VIP看满24小时', ms: 8000,   // 4.3.0:可操作提示对齐「切回」的 8000ms 先例
                      onClick: () => showVipGate('upsell') });
        return;
      }
    }
    rows.forEach(ingest);
    // 命中 = 这一枪把「当前局」拉回来了。空枪不学(它只证明 lagMs 偏小,由退避吸收)。
    if (opt && opt.chase && opt.offset >= 0 &&
        rows.some(r => Number(r.start_time_ms) >= opt.cs)){
      learnLag(opt.offset, opt.firstShot);
    }
  } catch {}
  finally { S.pollBusy = false; }
}

/* ── 近30局完整性自愈(3.3.0)──────────────────────────────────────────────
   局起点是 50001ms 等差格点。先在**本地**算近 COVERAGE_WINDOW 局应有的格点,
   扣掉已知的「官方缺失」后,若本地全有 → 完整,一次网络都不发。
   本地有洞才问后端 /coverage:它告诉哪些洞是官方本身缺的(记住,别再管)、
   哪些是本项目漏抓的(拉一次 history 补齐)。
   只在新局落地时触发,且 15s 防抖 —— 稳态(数据完整)几乎零开销。 */
/* 近30局的「内部缺口」—— 只算比本地最旧一局更新、却缺失的格点。
   为什么必须「内部」:历史不足30局的新房(新加入/主播刚开播),往回数30格里
   有一段是「该房还没存在那么久」,不是漏抓。若把它们也当缺口,checkCoverage 会
   每局触发、每局拉全量 history —— 恰好违背「数据完整就别拉」的初衷。
   本地最旧一局 oldest 之前的格点一律不算缺口(无从判断是漏抓还是从未开过)。 */
function localGridGaps(win){
  if (!S.hist.length) return { latest: 0, gaps: [] };
  const W = Math.max(1, Number(win) || COVERAGE_WINDOW);   // 5.0.4:basic 档按自己的硬闸窗口扫
  const latest = S.hist[0].start;
  const oldest = S.hist[S.hist.length - 1].start;   // 本地最旧一局(S.hist 新→旧)
  const have = new Set(S.hist.map(r => r.start));
  const gaps = [];
  for (let i = 0; i < W; i++){
    const g = latest - i * T.ROUND;
    if (g <= oldest) break;                          // 到达/越过最旧一局 → 更早的不是缺口
    /* 5.0.4:gapDead 与 offMissing 同一语义位(「别再为它拉了」),差别只在
       出处 —— offMissing 是后端确证,gapDead 是本地补满预算仍取不到。
       不在此一并过滤,basic 档会被最老那个死洞永久占住 Math.min,后来出现的
       **可补的**新洞一次都轮不上(复审实测)。 */
    if (!have.has(g) && !S.offMissing.has(g) && !S.gapDead.has(g)) gaps.push(g);
  }
  return { latest, gaps };
}
async function checkCoverage(){
  if (!S.alias || S.offline || S.covBusy) return;
  /* ── 5.0.4:basic 档的简版自愈(无 coverage 口径)────────────────────────────
     /coverage 需 VIP(403),但 /history 本身 basic 可读。洞落在硬闸窗口(最新 N 局)
     内时,一枪 since=洞−1 就能补上;since 只抬下界 ⇒ 结果恒 ⊆「最新 N 局」,与直接
     /history?limit=N 是同一批数据,**不多给一个字节**(JFVIP-SYSTEM.md §4.1 的数学
     论证不受影响)。窗口取 min(COVERAGE_WINDOW, JF.histLimit) —— 绝不为够不到的
     格点发注定空手的请求。没有「官方缺失」口径可依,故直接复用 resyncGap 的预算:
     补 GAP_RESYNC_TRY_MAX 次不成即登记为不可得、不再纠缠(洞 ~25 分钟后自然滑出
     该窗)。修前:一行 `if (isBasic()) return` 全关 —— 洞就在最新 3 局内、后端早已
     补齐,也非要用户自己刷新页面(jsdom 实证)。 */
  if (isBasic()){
    const win = Math.min(COVERAGE_WINDOW, JF.histLimit || COVERAGE_WINDOW);
    const { gaps } = localGridGaps(win);
    if (gaps.length) markGap(Math.min(...gaps) - T.ROUND, S.hist[0].start);
    return;
  }
  if (Date.now() - S.covAt < (S.covWait || COVERAGE_COOLDOWN_MS)) return;   // 5.0.4:自适应防抖
  const { gaps } = localGridGaps();
  if (!gaps.length){ S.covWait = COVERAGE_COOLDOWN_MS; return; }   // 本地已完整 → 零网络 + 退避复位
  S.covBusy = true; S.covAt = Date.now();
  const alias = S.alias;
  try {
    const c = await api(`/api/rooms/${encodeURIComponent(alias)}/coverage?window=${COVERAGE_WINDOW}`);
    if (S.alias !== alias) return;
    // 官方本身缺失的格点:本会话记住,不再为它拉 history
    for (const g of (c.official_missing || [])) S.offMissing.add(Number(g));
    if (c.complete){ S.covWait = COVERAGE_COOLDOWN_MS; return; }   // 后端也判定完整(缺口皆官方缺)
    // 仍有本项目漏抓的洞 → 定向补齐:从最旧的洞往新拉一段(不是全量 1800)。
    // since=(最旧洞 - 1) 返回该洞及更新的局,limit 覆盖窗口 + 余量即可。
    const holes = gaps.filter(g => !S.offMissing.has(g));
    if (holes.length){
      const since = Math.min(...holes) - 1;
      const lim = Math.min(HISTORY_LIMIT, COVERAGE_WINDOW * 2 + 20);
      const d = await api(`/api/rooms/${encodeURIComponent(alias)}/history?since=${since}&limit=${lim}`);
      if (S.alias !== alias) return;
      (d.rounds || []).slice().sort((a,b) => a.start_time_ms - b.start_time_ms).forEach(ingest);
    }
    // 5.0.4:这一枪补到了就复位退避,没补到就翻倍(封顶 5 分钟)——
    // 后端「官方缺失」尚未定案的窗口里不再每局空打两枪。
    S.covWait = localGridGaps().gaps.length < gaps.length
      ? COVERAGE_COOLDOWN_MS
      : Math.min(COVERAGE_COOLDOWN_MAX_MS, (S.covWait || COVERAGE_COOLDOWN_MS) * 2);
  } catch {}
  finally { S.covBusy = false; }
}

/* ── 5.0.4:头部断层定向补齐 ─────────────────────────────────────────────────
   ★ 病灶不是 coverage 的窗口太窄,而是 pollNew 会**自己制造洞却从不回头补**:
     它按 since=最新+1&limit=200 拉,而 db.history 是 `round_id >= since
     ORDER BY round_id DESC LIMIT n` —— 离开超过 200 局(≈2.8 小时)时这一枪
     只回**最新 200 局**,中间那段直接成洞;洞落在 30 格窗外,checkCoverage
     连查都不会查。实测(jsdom 走真实启动链路,离开 300 局):回前台后 100 颗
     占位珠,再过 5 局仍是 100,coverage 零调用。挂一夜 ≈376 颗。
   ★ limit 必须按 span 给足:同样因为 DESC + LIMIT 取的是**最新**的 n 条,
     若只给「洞的长度」,拿回来的全是洞之上那截新局,洞原样不动。故
     limit = 从断层起点到当前头的全部格点数 + 余量。
   ★ basic 档同样受益且**不构成绕过**:since 只抬下界,后端把 limit 钳到
     jf_basic_history_limit,结果恒 ⊆「最新 N 局」——与直接 /history?limit=N
     是同一批数据,不多给一个字节(JFVIP-SYSTEM.md §4.1 的数学论证不受影响)。
   ★ 预算:同段断层最多补 GAP_RESYNC_TRY_MAX 次,且**只在「拉到了但仍缺」时
     计数** —— 网络失败不消耗预算,否则一次断网就把可补的洞判死。补不动的
     交给 checkCoverage 的官方缺失口径定案(窗内)或如实留占位珠(窗外)。
   返回:该段内**仍然缺失**的格点数;-1 = 本次未执行(无断层/在飞/节流/失败)。 */
function markGap(from, to){
  /* 已有更早的断层在排队 → 并进去(一枪 since=更早起点 天然覆盖后面的洞);
     更早的新断层则整体接管(活儿更大,since 往前挪)。
     ★ 两处「不在此做」都是复审踩出来的:
       ① 不查 gapDead —— 它存的是**格点**,而 from 是断层前那个**存在的**局;
          止损靠 localGridGaps 过滤死格点实现,两者不是同一个键(初版键错,
          老死洞永久占住 Math.min、新的可补洞一次都轮不上);
       ② 不动计数表 —— 预算按格点各自计(见 resyncGap)。初版按 span 计且合并
          分支不重置,新洞并进一段只剩 1 次预算的活 span 会当场被判死,并连同
          写进 gapDead ⇒ 后端随后补上也再没人去取,**永久丢一个可补回的洞**
          (A/B 实测:按 span 末态 2 个占位珠,按格点 1 个)。 */
  if (S.gapSpan && S.gapSpan.from <= from){ S.gapSpan.to = Math.max(S.gapSpan.to, to); return; }
  S.gapSpan = { from, to };        // 预算按格点各自计(见 resyncGap),此处不动计数表
}
async function resyncGap(){
  const g = S.gapSpan;
  if (!g || !S.alias || S.offline || S.gapBusy || !S.hist.length) return -1;
  if (Date.now() - S.gapAt < GAP_RESYNC_COOLDOWN_MS) return -1;
  const alias = S.alias, head = S.hist[0].start;
  const span = Math.round((head - g.from) / T.ROUND);
  if (!(span > 0)){ S.gapSpan = null; return 0; }
  S.gapBusy = true;
  try {
    const lim = Math.min(HISTORY_LIMIT, span + 8);       // +8 余量:补齐期间可能又落了一两局
    const d = await api(`/api/rooms/${encodeURIComponent(alias)}/history?since=${g.from + 1}&limit=${lim}`);
    if (S.alias !== alias) return -1;
    (d.rounds || []).slice().sort((a,b) => a.start_time_ms - b.start_time_ms).forEach(ingest);
  } catch { return -1; }                                 // 网络失败:不计预算,下一局再来
  /* ★ 冷却按**完成时刻**计,不能设在发枪前:api() 对 GET 重试 3 次 × 8s 超时,
       半死不活的网络下单次可耗 ~24s,冷却早就过期 → 请求一回来下一帧立刻再打,
       退化成连打。并发本就由 gapBusy 挡住,这里只管节奏。 */
  /* gapBusy 是本函数自己持有的互斥位,**无条件释放**:await 落地到 finally 之间
     没有别的代码能插进来,不存在「别人已经开了新一枪」的窗口,漏放才会把整个会话
     的补齐锁死(换房把 alias 清空的路径上尤其致命)。
     gapAt 则要按 alias 守卫 —— 换房后回来的陈旧一枪若照样打戳,新房的首次补齐
     要白等 ≤8s(applyRoomData 本已把它清零,盖回去等于倒退)。 */
  finally { S.gapBusy = false; if (S.alias === alias) S.gapAt = Date.now(); }
  /* 还欠着多少 —— 必须逐格点数,且刨掉三类「不该再算」的:
       · 已在盘上的                                   → 补到了
       · S.offMissing:后端确证官方本身没有            → 再拉一百次也没有
       · S.gapDead:本地已补满预算仍取不到              → 同上
     下界夹到**保留窗最旧一局**:长时间离开(>24h)时 g.from 早被 pruneHistWindow
     裁走,不夹就会把窗外格点永远算成「还欠着」,left 恒 >0、预算白白烧光。
     初版用 missingSlots(rows) 少了后两项与下界夹,VIP 侧 coverage 第 0 局就已
     定案「官方缺失」,resyncGap 仍要白打满预算(复审实测)。 */
  /* ★ 上界必须重取 `S.hist[0].start`,不能用发枪前捕获的 head:请求在飞的那段
       (慢链路可达数秒)SSE 可能又推来一局、且与旧头之间就带着新断层 —— 用陈旧
       head 会把这些新格点排除在 miss 之外,而下面又要**整体重写** S.gapSpan,
       于是刚 markGap 登记的新断层当场被抹掉(VIP 侧只能等 checkCoverage 兜、
       basic 侧要等下一局重新登记)。
     ★ hist 可能在此期间被清空(rebaseHist 与本函数无锁并发):不守卫则
       S.hist[S.hist.length-1] 为 undefined,取 .start 直接抛。 */
  if (!S.hist.length){ S.gapSpan = null; return 0; }
  const head2 = S.hist[0].start;
  const lo = Math.max(g.from + T.ROUND, S.hist[S.hist.length - 1].start);
  const have = new Set(S.hist.map(r => r.start));
  const miss = [];
  for (let t = lo; t < head2; t += T.ROUND)
    if (!have.has(t) && !S.offMissing.has(t) && !S.gapDead.has(t)) miss.push(t);
  /* ★ 预算**按格点各自计**,不能按 span 计。按 span 计时,markGap 的合并分支不重置
     gapTry —— 一个刚出现的、后端还差两局才补上的新洞,并进一段预算只剩 1 次的活
     span,当场就被判死。现每个格点自带计数:老洞死了不牵连新洞,新洞恒拿到完整的
     GAP_RESYNC_TRY_MAX 次。计数表每轮按「当下仍缺」重建 —— 已补上的格点自然出表,
     不留陈账。 */
  const nextTry = new Map();
  const live = [];
  for (const t of miss){
    const n = (S.gapTry.get(t) || 0) + 1;
    if (n >= GAP_RESYNC_TRY_MAX) S.gapDead.add(t);      // 止损:localGridGaps 随即跳过
    else { nextTry.set(t, n); live.push(t); }
  }
  S.gapTry = nextTry;
  // 收紧下界:老格点死光后 since 不必再从远处起算(limit 随之变小)
  let lo2 = 0;
  for (const t of live) if (!lo2 || t < lo2) lo2 = t;
  S.gapSpan = lo2 ? { from: lo2 - T.ROUND, to: head2 } : null;
  return miss.length;
}

/* 预测「结算最终一致」补拉:新局刚落地那一刻,后端往往还没写完命中记录、
   也还没生成下一局预测 —— 此时拉到的 target_round_id 仍停在刚开的这一局。
   取代原先「每 8 秒无脑拉一次 /prediction(3 条 SQL)」。

   opt.firstWait  首拉延迟(首屏传 0:预测卡片要立刻有内容)
   opt.learn      是否让本次结果去调 predSettleMs。首屏拉的是几十秒前的历史局,
                  后端早已结算 —— 拿它去学只会把估计压到下界,害得之后每局先空拉一枪。

   重试退避:800 → 1440 → 2592 → 4666 → 6000 …… 不设次数上限。
   封顶 6s 之后相当于改造前那条「每 8 秒拉一次 /prediction」的定频线(还更密些)——
   区别在于:它只在「后端确实还没生成下一局预测」时才跑,正常一次就停。
   (退避基数必须夹到 PRED_RETRY_MIN:firstWait=0 时 0×1.8 仍是 0,
    会退化成零间隔连打 —— 第一版就栽在这。)

   predSettleMs 的自适应用 AIMD,**不能用 EMA**:
     · 首拉即中   → 往前探 200ms(加性递减)
     · 需重试才中 → 退到「实测成功偏移 + 250ms」(跳跃式后退)
   为什么:took 里本就含着「首拉失败后多等的那段」。若写成「成功就 EMA(took)+固定余量」,
   每成功一次估计都再涨一点,必然单调爬到上限,稳态退化成每局固定两次 ——
   第一版实测同局重试间隔 2.14→3.82→5.90s 一路爬满,正是这么来的。 */
const PRED_SETTLE_MIN = 800, PRED_SETTLE_MAX = 6000;   // 封顶 6s < 旧定频 8s;
                                                       // 预测须赶在下一局施法期(出怪后 10s)前拿到
const PRED_RETRY_MIN = 800, PRED_PROBE_MS = 200, PRED_MARGIN_MS = 250;
function predChase(landedStart, opt){
  opt = opt || {};
  clearTimeout(S.predChaseT); S.predChaseT = 0;
  if (!S.alias || !landedStart) return;
  const learn = opt.learn !== false;
  const alias = S.alias, seq = S.loadSeq, t0 = performance.now();
  const firstWait = opt.firstWait != null
    ? opt.firstWait : clampN(PRED_SETTLE_MIN, S.predSettleMs, PRED_SETTLE_MAX);
  /* 3.3.9 预测重复拉取修复(真机 HAR 实证):收敛判据只有 `nextStart > landedStart`,
     当后端 pending 被「孤儿局」占住 —— 该局仅经 GameHistory 补齐 / 妖兽未知(cid=NULL)
     入库,worker.py line 578 `if is_new and cid:` 使**仅结算、未生成下一局预测**——
     /prediction 会把 target 卡在 landedStart(== 刚落这局),nextStart 恒 == landedStart,
     判据永不成立 → 每 ~退避(0.8→…→6s)重拉一次、结果**逐拍相同**,直到某个更晚的
     已知妖兽局把 pending 顶上去(HAR t=127…149 七连相同 target 实证)。SSE 健康时,
     下一局预测会在其上游被捕获时由后端经 pred-updated 同帧推来(3.3.5),追拉纯属冗余:
     故 SSE 健康(sseAlive 活性判据,半开假活自动回退下方重试环)→ 只单发一枪对账
     (权威记录/accuracy),不进重试环;后台标签页延后到可见语义与原 attempt 一致。 */
  if (sseAlive()){
    const fire = () => {
      if (S.alias !== alias || S.loadSeq !== seq) return;
      if (document.hidden){ S.predChaseT = setTimeout(fire, PRED_SETTLE_MAX); return; }
      refreshPrediction(alias);
    };
    S.predChaseT = setTimeout(fire, Math.max(0, firstWait));
    return;
  }
  let retry = 0;                                          // 0 = 尚未重试过(还在首拉)
  const again = () => {
    // 兜底封顶:SSE 掉线降级追拉时,若 pending 被孤儿局占住,收敛判据同样永不成立。
    // 单次 predChase 最多追一局时长(T.ROUND);逾时收手,交由下一局落地重新触发,
    // 杜绝「同一 landedStart 无限重拉」(旧版此路径亦会死拉,只是被退避封顶到每 6s 一枪)。
    if (performance.now() - t0 > T.ROUND){ S.predChaseT = 0; return; }
    retry = retry ? clampN(PRED_RETRY_MIN, Math.round(retry * 1.8), PRED_SETTLE_MAX)
                  : PRED_RETRY_MIN;
    S.predChaseT = setTimeout(attempt, retry);
  };
  const attempt = async () => {
    if (S.alias !== alias || S.loadSeq !== seq) return;    // 期间换房 → 放弃
    if (document.hidden){ S.predChaseT = setTimeout(attempt, PRED_SETTLE_MAX); return; }
    await refreshPrediction(alias);
    if (S.alias !== alias || S.loadSeq !== seq) return;
    // 收敛判据只看 target 是否推进到下一局。别再加 `&& main.length`:
    // 后端「无 pending」时 refreshPrediction 会把 nextStart 兜成 landedStart+ROUND(照样收敛),
    // 而「有 pending 却给不出 main」是异常数据 —— 那样会变成永不收敛的死拉。
    if (S.pred.nextStart > landedStart){
      if (learn){
        S.predSettleMs = retry === 0
          ? clampN(PRED_SETTLE_MIN, S.predSettleMs - PRED_PROBE_MS, PRED_SETTLE_MAX)
          : clampN(PRED_SETTLE_MIN,
                   Math.round(performance.now() - t0) + PRED_MARGIN_MS, PRED_SETTLE_MAX);
      }
      return;
    }
    again();
  };
  if (firstWait <= 0) attempt(); else S.predChaseT = setTimeout(attempt, firstWait);
}

/* 新出怪入账(数据路径;渲染/快照经 rAF 合帧) */
let flushRaf = 0, flushCount = 0, snapT = 0;
function scheduleSnapshot(){                       // 快照移出渲染帧:空闲时落盘
  if (snapT) return;
  const run = () => { snapT = 0; saveSnapshot(); };
  snapT = ('requestIdleCallback' in window)
    ? requestIdleCallback(run, { timeout: 1500 })
    : setTimeout(run, 250);
}
let flushRaf2 = 0, flushTrend = 0;
function flushIngest(){
  const t0 = performance.now();
  flushRaf = 0;
  const single = flushCount === 1;
  flushCount = 0;
  // 帧1:用户最先注视的两件事(新珠落盘 + 出怪印章)—— 增量,极轻
  renderRoad(single);
  renderResult(single);
  tick();
  window.__flushMs = +(performance.now() - t0).toFixed(1);
  // 帧2:九法司历(原地更新)+ 出怪规律 + 连开 —— 轻
  if (!flushRaf2) flushRaf2 = requestAnimationFrame(() => {
    flushRaf2 = 0;
    const t1 = performance.now();
    renderBoard(); renderCensus(); renderStreaks();
    syncVipNotes();                              // 4.4.0:角标随已累计量重算(内含变更守卫,稳态零 DOM 触碰)
    renderPredict();                             // 先按现有预测态渲染(含上局命中标注)
    // 3.2.0:原先这里只拉一次,若后端尚未结算就拿到旧 target,靠 8s 轮询「最终一致」。
    // 现在改为「立刻拉 + 未结算则 1.5/4/9s 补问」,拉到就停 —— 不再靠定频兜。
    predChase(S.hist[0]?.start || 0);
    /* 5.0.4:**次序不可颠倒** —— checkCoverage 的 basic 分支是同步的 markGap 登记,
       排在前面才能让紧随其后的 resyncGap 当帧补齐;反过来要多等整整一局(≈50s,实测)。 */
    checkCoverage();                             // 3.3.0:新局落地顺带查完整性(自适应防抖,完整则零网络)
    resyncGap();                                 // 5.0.4:有断层则定向补齐(无断层零网络)
    scheduleSnapshot();
    window.__flushMs2 = +(performance.now() - t1).toFixed(1);
  });
  // 空闲帧:战况竖排表单独错峰(增量插行,极轻;1 局延迟不可感)
  if (!flushTrend){
    const run = () => { flushTrend = 0; const t2=performance.now(); renderTrend(true); window.__flushMs3 = +(performance.now()-t2).toFixed(1); };
    flushTrend = ('requestIdleCallback' in window)
      ? requestIdleCallback(run, { timeout: 600 })
      : requestAnimationFrame(() => requestAnimationFrame(run));
  }
}
function ingest(raw){
  const r = normRound(raw);
  // 2.6.3 入账门卫:号位必须为 1–9 整数、起始时间必须为有限数 —— 畸形数据
  // (缺字段 / 越界 / NaN)一律拒收,防止污染排序、S.anchor 与相位推导;
  // 正常契约数据(mock 与线上均为 1–9 + 毫秒时间戳)不受任何影响。
  if (!Number.isInteger(r.n) || r.n < 1 || r.n > 9 || !Number.isFinite(r.start) || S.ids.has(r.id)) return;
  S.ids.add(r.id);
  if (!S.hist.length || r.start >= S.hist[0].start){
    /* 5.0.4:头部断层登记。新局比本地最新**跳过了**至少一个格点 = 中间那几局
       本地永远不会再有人去拿 —— pollNew 只拉「比最新更新的」且 limit 封顶 200,
       checkCoverage 又只扫近 30 格。实测:标签页挂后台 300 局回前台,当场留下
       100 颗占位珠且此后零请求,只能刷新页面。断层全部从这一处产生,故在此
       登记、交 resyncGap 定向补齐。 */
    const head = S.hist.length ? S.hist[0].start : 0;
    if (head && gapSlots(head, r.start) > 0) markGap(head, r.start);
    S.hist.unshift(r);                                   // 常态:追加最新
  } else {
    const i = S.hist.findIndex(x => x.start <= r.start); // 罕见乱序:定位插入
    if (i === -1) S.hist.push(r); else S.hist.splice(i, 0, r);
  }
  if (S.hist.length > HIST_CAP){
    S.hist.splice(HIST_CAP).forEach(x => S.ids.delete(x.id));
  }
  pruneHistWindow();                    // 3.8.2:钉真 24h 锚定窗(见 HIST_WINDOW_MS 注)
  S.anchor = S.hist[0].start;
  S.lastDataTs = Date.now();
  S.lastDataPerf = performance.now();   // 保险丝时基:单调钟,不受系统时间跳变影响
  flushCount++;
  if (!flushRaf) flushRaf = requestAnimationFrame(flushIngest);
}

/* 3.8.2:把 S.hist 修剪到「最新一局起点 − 24h」窗内(含边界)。
   hist 恒按 start 降序,窗外只可能在尾部 —— 尾扫即可,均摊 O(1)/局。
   ids 同步删除,维持「S.ids ↔ S.hist」双向一致的既有不变量。 */
function pruneHistWindow(){
  if (!S.hist.length) return;
  const cut = S.hist[0].start - HIST_WINDOW_MS;
  while (S.hist.length && S.hist[S.hist.length - 1].start < cut){
    S.ids.delete(S.hist.pop().id);
  }
}

/* ═══════════ 派生统计 ═══════════ */
/* ═══ 4.4.0:连空口径钉真 ═══════════════════════════════════════════════════
   ── 旧实现错在哪(实地复现)──────────────────────────────────────────────
   旧代码 `gap[r.n] = i` 用的是 **S.hist 的数组下标**,即「往前数几**条记录**」。
   而全架构的前提是「九法 24 小时连续出怪,每个 50001ms 格点都是应有之局」
   (见 railChip 注 ③)。仓库自带的 25h 真机快照里,2678075 房有一段 17 局的
   连续缺口 —— 旧口径下,某号位真实空了 50 个格点会被显示成 33,再经 stateOf()
   判档,「极冷」被误标成「正常」。出怪规律与未出场正是本产品的核心读数,这是实打实的
   失真,不是洁癖。
   ── 但纯按格点算会**反向出错** ──────────────────────────────────────────
   4.4.0 起 basic 档留存窗里可能有「未观测」断口(用户离线那段)。纯格点会把
   「我没看」当成「它没出」,把连空吹大 —— 比低估更糟。
   ── 正解:给**区间**,不给单边(实测推翻了初版设计)────────────────────
   初版只给下界(=断口近端距离),真机切片实测立刻打脸:号位 9 观测到的上次
   出现在 72 格之外,初版却报「≥12」—— 比旧口径**更弱**,会把真正的极冷号
   说成正常。缺口让「中间开了什么」未知,但**两个端点的格点距离是可算的**:
     · 下界 lo = 到第一个断口近端的格点距离(断口里可能就有它)
     · 上界 hi = 到**观测到的**上次出现的格点距离(它确实在那里出现过)
   真值必在 [lo, hi]。无断口时 lo === hi,退化为精确值(=旧口径的修正版)。
   展示:相等给单数,不等给 `lo~hi`;**stateOf 判档一律取 lo** —— 不拿未观测的
   区间去喊「极冷」,与本项目「绝不臆造出怪」的既有原则同源。
   maxGap 只在各连续段**内部**统计,不让 run 跨断口累加(同理是下界)。 */
function deriveStats(){
  const hist = S.hist;
  const counts = {}, today = {}, gap = {}, gapHi = {}, maxGap = {}, gapMin = {}, gapOpen = {};
  for (let n=1; n<=9; n++){ counts[n]=0; today[n]=0; gap[n]=-1; gapHi[n]=-1; maxGap[n]=0; gapMin[n]=false; gapOpen[n]=false; }
  const mid = midnight();
  const N = hist.length;
  if (!N){                       // 与 4.3.x 逐字节对齐:空历史时 gap 为 0 而非哨兵 -1
    for (let n=1; n<=9; n++){ gap[n]=0; gapHi[n]=0; }
    return { counts, today, gap, gapHi, maxGap, gapMin, gapOpen, total: 0, todayTotal: 0, holes: 0 };
  }
  const step = (a, b) => Math.max(1, Math.round((a - b) / T.ROUND));   // 两局间的格点距离
  /* 一趟(新→旧):累计格点距离;遇到第一个断口即封顶 —— 更旧的只能给下界。 */
  let steps = 0, bound = -1, holes = 0, todayTotal = 0;
  for (let i = 0; i < N; i++){
    if (i > 0){
      const d = step(hist[i-1].start, hist[i].start);
      if (d > 1){                                 // 断口:两条记录之间缺 d-1 个格点
        holes++;
        if (bound < 0) bound = steps + 1;         // 可证下界 = 断口近端的格点距离
      }
      steps += d;
    }
    const r = hist[i];
    counts[r.n]++;
    if (r.start >= mid){ today[r.n]++; todayTotal++; }
    if (gap[r.n] === -1){
      gapHi[r.n] = steps;                                        // 上界:观测到的上次出现(恒可算)
      if (bound >= 0){ gap[r.n] = bound; gapMin[r.n] = true; }   // 跨断口 → 下界=断口近端
      else gap[r.n] = steps;                                     // 段内 → lo===hi,精确
    }
  }
  /* ★ 四轮复审修正(对拍模糊测试实测打脸,2127 组样本中 1.8% 违反)——
     「窗内从未出现」的号位,连空是**上不封顶**的:它完全可能在窗口开始之前就出现过。
     初版给它配了一个闭区间上界(=整窗跨度),对拍立刻抓到反例:真值 42 而 UI 显示
     「1~41」;无断口时更糟 —— 显示成单数「5」仿佛精确,真值却是 7。
     区间是一句**强断言**(真值必在其中),不能拿下界冒充。故这类号位单独标
     gapOpen,展示为 `≥lo`,只声明我们能证明的那一半。
     (旧 4.3.x 显示 hist.length 且在 tooltip 里说"含窗口边界截断" —— 同样是把下界
      当精确值摆在正文里,只是没人把它当区间读;这轮一并纠正。) */
  const spanAll = (bound >= 0) ? bound : steps + 1;
  for (let n=1; n<=9; n++) if (gap[n] === -1){
    gap[n] = spanAll; gapHi[n] = spanAll; gapMin[n] = true; gapOpen[n] = true;
  }
  /* maxGap:逐**连续段**统计,不跨断口(跨了就是把"没看"算成"没出") */
  const run = {};
  const flushSeg = (a, b) => {                    // [a,b] 闭区间,新→旧下标
    for (let n=1;n<=9;n++) run[n]=0;
    for (let i = b; i >= a; i--){                 // 段内旧→新
      const hit = hist[i].n;
      for (let n=1;n<=9;n++){
        if (n === hit){ if (run[n] > maxGap[n]) maxGap[n] = run[n]; run[n]=0; }
        else run[n]++;
      }
    }
    for (let n=1;n<=9;n++) if (run[n] > maxGap[n]) maxGap[n] = run[n];
  };
  let segStart = 0;
  for (let i = 1; i < N; i++)
    if (step(hist[i-1].start, hist[i].start) > 1){ flushSeg(segStart, i - 1); segStart = i; }
  flushSeg(segStart, N - 1);
  return { counts, today, gap, gapHi, maxGap, gapMin, gapOpen, total: N, todayTotal, holes };
}
/* 连空展示三形态,严格对应我们**能证明什么**:
     精确  `N`      —— 该号在连续观测段内出现过,格点距离即真值
     区间  `lo~hi`  —— 跨了断口:它可能落在没看到的那段里,真值必在区间内
     开区间 `≥lo`   —— 窗内**从未**出现:上不封顶(可能在窗口之前就出现过),
                      只声明下界。四轮复审经对拍模糊测试确立(见 deriveStats 注)。 */
function gapText(st, n){
  const lo = st.gap[n], hi = st.gapHi[n];
  if (st.gapOpen[n]) return `≥${lo}`;
  return (st.gapMin[n] && hi > lo) ? `${lo}~${hi}` : String(lo);
}
function officialProb(n){
  const sp = S.spellByN[n];
  const p = sp ? parseFloat(String(sp.probability).replace('%','')) : NaN;
  /* 4.8.7:判据收严。**解得出 != 说得通** —— 0% / 负数 / >100 / Infinity 都能被
     parseFloat 解出来，却照样能算出满屏红蓝的假结论（0% 还会让下面 stateOf 的
     100/(prob||10) 把 0 悄悄换成 10%，同源病）。这里只回「可用的概率」，其余一律
     NaN，由调用方 officialProbOr 显式兜底 —— 于是「能不能用」这件事有了单一判据，
     并与后端 web._probability_ok 用 node 逐例活体对拍（test_official_probability）。
     行为影响：仅当配置里真出现 0%/负/>100 时才与旧版不同，而后端加载器现在会在
     下发前把这类值按妖兽表回填，故实盘不可观测。 */
  return (isFinite(p) && p > 0 && p <= 100) ? p : NaN;
}
function officialProbOr(n){
  /* 调用方兜底：与 4.8.7 之前的 officialProb 逐字节等价（解不出就回落均匀 100/9）。 */
  const p = officialProb(n);
  return isNaN(p) ? 100/9 : p;
}
function stateOf(gap, prob){
  const cycle = Math.max(1, Math.round(100 / (prob || 10)));
  if (gap >= cycle * 2.5) return { s:'极冷', heat: 1,             c:'var(--cold-deep)' };
  if (gap >= cycle * 1.5) return { s:'偏冷', heat: gap/(cycle*2.5), c:'var(--cold)' };
  if (gap === 0)          return { s:'刚出', heat: .08,           c:'var(--seal)' };
  if (gap <= cycle * .3)  return { s:'活跃', heat: gap/(cycle*2.5), c:'var(--seal)' };
  return { s:'正常', heat: Math.min(1, gap/(cycle*2.5)), c:'var(--gilt)' };
}

/* ═══════════ 渲染:侧栏 & 身份 ═══════════ */
function renderRail(filter = ''){
  const q = filter.trim().toLowerCase();
  const list = S.rooms.filter(r => !q ||
    String(r.alias).includes(q) || String(r.roomId).includes(q) ||
    (r.nickname||'').toLowerCase().includes(q));
  // 无搜索词时展示「已用/上限」;有搜索词时仍是命中条数(旧语义)
  D.railCount.textContent = q ? String(list.length) : `${S.rooms.length}/${MAX_ROOMS}`;
  syncAddRoomBtn();
  syncNudge();         // 5.0.3:renderRail 是名录变化的汇聚点(启动/增删/30s 重拉/搜索),在此同步新手态
  syncStageEmpty();    // 5.0.3:空名录主舞台引导卡随名录状态同步显隐
  if (!list.length){
    /* 5.0.2:名录本空 ≠ 搜索无果。空名录(新装首启/删空)是最需要「添加」的第一现场,
       原文案却把人引去搜索(名录空,搜什么都没有);现分流成引导卡,把添加按钮直接
       递到空态文案旁 —— 常驻侧栏形态下原按钮远在栏底,与空态文案之间隔着整段
       flex:1 空白(1920 实测约 540px),小白视线未必下扫。按钮借 .rail-add 的既有
       视觉,点击转发 #addRoomOpen 走同一套闸(容量闸/closeRail/清 msg)。
       图标轨收起态下本块由 CSS 整体隐藏(64px 内竖排破版,实测截图为证),
       入口交还给轨上的「＋」。 */
    D.roomList.innerHTML = S.rooms.length
      ? `<p class="room-empty">没有匹配的主播,可直接回车按房间号搜索</p>`
      : `<div class="room-empty room-empty-guide"><b>名录还是空的</b><span>添加一个直播间即可开始观测</span><button type="button" class="rail-add room-empty-add">＋ 添加直播间</button></div>`;
    return;
  }
  /* 5.0.1:第二行(`№ 房号` + 速览角标)包进 .ri-sub —— 改前两者是同一行框里的
     两枚 inline,长房号 + 两位读秒必然按 UAX #14 断行(数字后接汉字即合法断点),
     角标整枚掉行、甚至被拦腰劈开(实测「下」留上行、「49s」掉下行),条目高度
     随之在 62.94 ↔ 86.19px 之间逐分钟抖动。.ri-sub 在 app.css 里是**横向不换行
     的 flex 且跨到删除钮那一列之下**,换行自此在盒模型层面即不可发生;房号另起
     .ri-no 是为了让「可读性上调」那两条通选字号只打房号、不再顶掉角标的 10.5px
     (那正是把这一行撑破的推手之一)。三处的推导与实测余量见 app.css 同名节。 */
  D.roomList.innerHTML = list.map(r => `
    <button type="button" class="room-item ${String(r.alias)===S.alias?'is-on':''}" data-alias="${esc(r.alias)}" title="${esc(r.nickname||r.alias)}">
      <img src="${esc(r.avatar||'')}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">
      <span class="ri-meta"><b>${esc(r.nickname||r.alias)}</b><span class="ri-sub"><span class="ri-no">№ ${esc(r.alias)}</span><span class="ri-tick" data-ta="${esc(r.alias)}" hidden></span></span></span>
      <i class="ri-del" title="删除该直播间并停止监控">×</i>
      <i class="ri-live" data-la="${esc(r.alias)}" role="img" aria-label="" hidden></i>
    </button>`).join('')
    /* 5.0.3:单房新手引导条 —— 名录只有 1 个房(典型:首登预置房 321,后端
       _first_login_seed;或部署 seed 的全局房)时,小白不知道还能添加/切换其它
       直播间:唯一提示是 4.8.0 那条 8s 一次性 toast,错过即永久消失;而栏底
       「＋ 添加直播间」远在整段 flex:1 空白之下(1920 实测按钮 y=869,与唯一
       条目隔约 540px —— 5.0.2 已为空名录实证过"小白视线未必下扫",单房态是
       同一病灶的另一半)。条带紧贴唯一条目渲染在视线停留处,文案复用 4.8.0
       既有口径不造新概念。**显隐单一真源在 CSS body[data-nudge]**(syncNudge
       维护):无搜索词且恰 1 房时无条件拼进 DOM,新手态之外 display:none 零成本 ——
       renderRail 自身不读消解键,逻辑不分叉。已见过 ≥2 房或点过 × 的用户
       (KEY.addNudge 已落)永不再见;点击经 roomList 既有委托转发 #addRoomOpen,
       与 5.0.2 空引导卡同一套闸(容量闸/closeRail/清 msg/locked 锁)。
       图标轨收起态下与 .room-empty 同款整体隐藏(64px 内无处安放,app.css 同名节)。 */
    + ((!q && S.rooms.length === 1)
      ? `<div class="room-nudge"><button type="button" class="room-nudge-close" aria-label="不再提示">×</button><span>还可以添加更多直播间 —— 各直播间各出各的怪,多房可对比观测</span><button type="button" class="rail-add room-nudge-add">＋ 添加直播间</button></div>`
      : '');
  railTickPaint();     // 3.9.4:重绘后立即上色速览角标,不等下一秒的定时拍
}

/* ═══ 3.9.4:侧栏速览(名录每房「距出怪/下局」倒计时角标) ═══
   动机:单账号单活跃房下,用户对非活跃房**零实时信息**,想知道"哪个房快出怪了"
   只能逐个切换 —— 合法的多房对比需求被完全屏蔽,而脚本却能串行轮转(能力倒挂)。
   本速览不触碰任何硬边界:数据全部来自既有 /api/live-rooms 字段(该端点本就
   按账号回名录并携带每房 roundStartTimeMs/serverOffsetMs/lastOkAt),不走明细
   端点、不建 SSE、不 claim/renew 租约 —— 与 passive 预取同一哲学:只读速览,
   不是"监控"。倒计时靠 50001ms 等差格点纯本地外推(与 curStart 同源),锚点
   哪怕陈旧几局仍在格点上,读秒依然如实;每 30s 静默重拉一次名录刷新锚点/资料。
   成本账:重拉 = 每用户每 30s 一次 live-rooms(每房一次 Redis 快照 + 600s 缓存的
   资料),50 房名录 ≈ 100 Redis 读/30s/用户;本地重绘 = 每秒 ≤50 个 textContent。 */
/* 3.9.5 状态语义重造(实地核查复盘:旧「休(可能已下播)」四处失真)——
   ① 结构性假警报:实配开启 curated-idle enforce 时,用户驻留单房 30 分钟后其余
     名录房降级低频采集(GameHistory 每 T 一页),后端 lastOkAt 从降级起冻结,
     10 分钟一到全员永久"休" —— 而数据其实每 T 都在成功入库、零缺口。本速览
     (3.9.4)的立意恰是"不切换也能看别房读秒",与降级机制在同一份实配下自相
     摧毁;② 回前台假警报:S.rooms 在 document.hidden 期冻结,回前台瞬间
     now−okAt 高估数据年龄,**连当前正看的房**都闪"休"(与主舞台自相矛盾);
   ③ 因果错置:九法 24 小时连续出怪(覆盖哨兵把每个 50001ms 格点视为应有之局、
     按日回看 ~1728 局/天、司历 24h 窗 —— 全架构以此为前提),抓不到数据的
     真因永远在我方(闲置降级/票据过期/上游异常),与主播是否开播无关;
   ④ 反向撒谎:旧后端在快照缺失时把 lastOkAt 伪装成"现在",从未抓过数据的房
     反而显示正常倒计时。
   现分五档(后端 3.9.5 起卡片新发 mode/dataOkAt/lastError,详见 web.py
   _live_room_card 注;旧后端无 mode → 自然落入 realtime 阈值,行为不劣于旧版):
     待  mode:pending 或从未有成功抓取 —— 归一中/等待首抓,不再伪装读秒;
     断  数据管线真失联(见下阈值)—— 读秒虽仍可格点外推,但已知管线中断时
         继续显示"活着的倒计时"会误导,故以状态字替代;悬停给出 lastError 真因
         与「24h 连续出怪、与开播无关」的澄清,恢复后历史自动补齐;
     开/下 + slow  idle 房(低频采集,数据完整)—— 读秒照常(锚点冻结无妨:
         格点外推与主舞台同源,陈旧几局仍如实),叠虚线「省流」态,悬停说明
         点开即恢复实时;
     开/下  实时房正常读秒(hot/next 原样)。
   失联判据用**名录快照落地时刻**(S.roomsFetchedAt),不用 now:okAt 的年龄
   只在快照落地那一刻可信 —— 快照冻结期间服务端可能已刷新多轮,now−okAt 是
   上界而非真值;改判 fetchedAt−okAt 后,后台回前台的 0~34s 补拉窗内结构上
   不可能误报(② 由此根治,visibilitychange 的补拉负责随后校正)。阈值:
   实时房 RAIL_LIVE_STALE_MS;idle 房 S.histStaleMs(随后端 histIntervalS
   自适应)。时基注:fetchedAt 为校准钟(≈游戏服务器钟)、okAt 为后端主机钟,
   两者均 NTP 同步,偏差远小于分钟级阈值,不足虑。 */
function railChip(r, now){
  if (r.mode === 'pending')
    return { txt: '待', cls: 'idle', tip: '房号确认中,等待首次抓取' };
  const anchor = Number(r.roundStartTimeMs) || 0;
  if (!anchor) return null;                              // 无锚点(纯本地自添房等):不显示
  const okAt = Date.parse(r.dataOkAt || r.lastOkAt || '') || 0;
  const idle = r.mode === 'idle';
  if (okAt && S.roomsFetchedAt
      && S.roomsFetchedAt - okAt > (idle ? S.histStaleMs : RAIL_LIVE_STALE_MS))
    return { txt: '断', cls: 'lost',
             tip: '该房数据抓取中断(网络/上游/票据异常)。九法为 24 小时连续出怪,'
                + '与主播是否开播无关;恢复抓取后历史会自动补齐'
                + (r.lastError ? ' · 最近错误:' + r.lastError : '') };
  if (!okAt && r.mode)                                   // 新后端明示「从未成功抓取」
    return { txt: '待', cls: 'idle', tip: '等待首次抓取(服务刚启动/恢复)' };
  const n = Math.floor((now - anchor) / T.ROUND);        // 锚点只是格点参考,同 curStart 语义
  const t = now - (anchor + n * T.ROUND);
  let c;
  if (t < T.DRAW){
    const s = Math.max(1, Math.ceil((T.DRAW - t) / 1000));
    c = { txt: '开 ' + s + 's', cls: s <= 10 ? 'hot' : '', tip: '距本局出怪' };
  } else {
    const s = Math.max(1, Math.ceil((T.ROUND - t) / 1000));
    c = { txt: '下 ' + s + 's', cls: 'next', tip: '距下一局开始' };
  }
  if (idle){                                             // 省流态:读秒照常,虚线标识
    c.cls += (c.cls ? ' ' : '') + 'slow';
    c.tip += ' · 该房处于闲置省流(低频采集,数据完整);点开即恢复实时';
  }
  return c;
}
/* 3.9.5:名录快照落地登记 —— 失联判据的时间基准 + idle 阈值随后端周期自适应。
   dataBoot 首拉与 refreshLiveRooms 静默重拉共用(成功路径才调,失败不推进
   fetchedAt:旧快照的判定继续以旧时点为准,方向保守)。 */
function noteRoomsFetched(lr){
  S.roomsFetchedAt = nowC();
  const t = Number(lr && lr.histIntervalS) || 0;
  S.histStaleMs = t > 0 ? t * 2000 + 120000 : RAIL_IDLE_STALE_DEF;
}
/* ═══ 5.0.6:名录直播状态点 —— .ri-live 由装饰位改为状态位 ═══════════════════
   改前它是**纯装饰**:每条名录恒亮一颗绿点、选中房转朱砂,不携带任何信息 ——
   而「这个主播现在开播了没有」恰恰是切房前最想知道的一件事,此前要逐个点开繁星
   才看得到。现在它就是那个答案,三态:
     直播中 → 绿点脉冲(沿用改前的视觉,零学习成本)
     未开播 → 整枚隐藏(需求口径)
     **未知** → 静态灰环 —— 这一态是刻意留的。判据链上任何一环缺位(总开关关闭、
       worker 未跑/停摆、上游探测受阻、观测过期、房号待归一)都会落到这里;若把
       它压成「未开播」,一次后台停摆就是满屏「主播全体下播」的静默撒谎,而用户
       无从分辨。宁可承认不知道 —— 与 3.9.5 名录角标诚实化同一条戒律。
   数据面:后端 live-rooms 卡片的 live 字段(true/false/null),判据与实测推导见
   backend_async/app/settings.py LiveStatusCfg。旧后端无此字段 ⇒ undefined ⇒ 未知,
   新前端配旧后端自然降级,不会误报。
   刷新面:并入 railTickPaint 逐秒重绘 —— 名录 DOM 在「交互中不重绘」守卫下可能
   连续多个 30s 不重建(悬停/焦点/删除钮武装态),状态若只写在模板里就会卡住不动;
   逐秒按 data-la 对当前 S.rooms 取值,与速览角标同一套机制,不新增计时器。 */
function railLiveChip(r){
  if (r && r.live === true)
    return { cls: 'ri-live is-live', aria: '直播中',
             tip: '直播中 · 主播此刻正在开播(九法 24 小时连续出怪,与开播与否无关)' };
  if (r && r.live === false) return null;              // 未开播:整枚隐藏
  return { cls: 'ri-live is-unknown', aria: '直播状态未知',
           tip: '直播状态未知(未取到状态,**不代表**未开播);'
              + '出怪数据不受影响,以本行读秒角标为准' };
}
function railTickPaint(){
  if (document.hidden || !D.roomList) return;
  const els = D.roomList.querySelectorAll('.ri-tick');
  const lives = D.roomList.querySelectorAll('.ri-live');
  if (!els.length && !lives.length) return;
  const now = nowC();
  const map = new Map(S.rooms.map(r => [String(r.alias), r]));
  els.forEach(el => {
    const r = map.get(el.dataset.ta || '');
    const c = r ? railChip(r, now) : null;
    if (!c){ el.hidden = true; return; }
    el.hidden = false;
    if (el.textContent !== c.txt) el.textContent = c.txt;
    const cls = 'ri-tick' + (c.cls ? ' ' + c.cls : '');
    if (el.className !== cls) el.className = cls;
    if (el.title !== c.tip) el.title = c.tip;
  });
  lives.forEach(el => {
    // 取不到该房(名录刚被别处删掉、DOM 尚未重建)按**未知**画,不按未开播 ——
    // 同一条戒律:没有依据时不许下结论。
    const c = railLiveChip(map.get(el.dataset.la || ''));
    if (!c){ el.hidden = true; return; }
    el.hidden = false;
    if (el.className !== c.cls) el.className = c.cls;
    if (el.title !== c.tip) el.title = c.tip;
    /* title 只服务鼠标:**真 Chromium CDP 实测**(a11y_probe.mjs)—— 后代元素的
       title 不进祖先按钮的 computed name,`主播A № 321 开 12s ×` 里一个字都没有;
       换 role="img"+aria-label 后名字才变成 `… × 直播中`(隐藏时自动不计)。
       触屏另有既有事实:title 一律不渲染。故状态必须双写,缺一即对某类用户失声。 */
    if (el.getAttribute('aria-label') !== c.aria) el.setAttribute('aria-label', c.aria);
  });
}
async function refreshLiveRooms(){
  if (document.hidden || S.offline || AUTH.locked) return;
  try {
    const lr = await api('/api/live-rooms');
    S.rooms = lr.rooms || [];
    noteRoomsFetched(lr);                                // 3.9.5:登记快照时刻(失联判据基准)
    mergeMyRooms();                                      // 本地乐观自添房不被静默刷掉
    syncNudge(); syncStageEmpty();                       // 5.0.3:必须在下方「交互中不重绘」守卫**之外** —— 两函数不碰 roomList DOM/焦点,而别的窗口增删房后本窗口的新手态/空舞台卡要即时跟上
    /* 3.9.4 复审加固:**交互中不重绘**。每 30s 的 innerHTML 重建会 ① 夺走键盘用户
       在名录项上的焦点(可达性回归);② 抹掉删除钮的两步确认武装态([data-armed],
       3s 窗口);③ 悬停将点时换掉元素让点击落空。此时只更新 S.rooms 数据面 ——
       角标读秒经 railTickPaint 按 data-ta 对新数组取锚点,DOM 不重建也照常刷新;
       昵称/头像等结构性变化等下一拍补绘。重绘时**保持滚动位**:.room-list 自身
       overflow-y:auto,innerHTML 重建会把 scrollTop 归零 —— 50 房长表滚到中部的
       用户每 30s 被弹回顶(复审实锤的回归),读写一次 scrollTop 即消除。 */
    let hover = false;
    try { hover = !!(D.roomList && D.roomList.matches(':hover')); } catch {}
    const interacting = hover
      || (document.activeElement && D.roomList && D.roomList.contains(document.activeElement))
      || (D.roomList && D.roomList.querySelector('[data-armed]'));
    if (!interacting){
      const st = D.roomList ? D.roomList.scrollTop : 0;
      renderRail(D.roomSearch.value);                  // 保留搜索过滤;is-on 高亮随模板重算
      if (D.roomList) D.roomList.scrollTop = st;
    }
  } catch {}
}
function renderIdentity(){
  const p = S.profile || {};
  D.anchorName.textContent = p.nickname || `房间 ${S.alias}`;
  D.anchorAlias.textContent = '№ ' + S.alias;
  if (p.avatar) { D.anchorAvatar.src = p.avatar; D.anchorAvatar.style.visibility=''; }
  else D.anchorAvatar.style.visibility = 'hidden';
  $$('.room-item', D.roomList).forEach(el => el.classList.toggle('is-on', el.dataset.alias === S.alias));
  syncRoomScope();
}

/* ═══ 4.8.0 房间归属:让「这份数据属于哪个直播间」随数据一起出现 ═══════════════
   出怪按 (room_id, round_id) 主键逐房入库,各房出怪彼此独立(随包 3 房 5103 局
   实测:同刻同号位 15.4%,与「各房独立」的理论基准 Σp²=14.9% 一致)。而此前房号
   在界面上**只出现一处** —— 顶栏 11.5px 灰字 `№321`;全屏序列会把顶栏整个盖掉,
   标题页签也不带房号。于是在别的直播间看盘的用户,面对的是一份没有署名的序列,
   自然当成「全站统一的出怪」,一对不上就判定成数据错误(实测错房时 1 局即有
   84.6% 概率对不上,3 局内 99.6%)。
   对策不是加装饰,而是**把房号钉到数据本身的说明位上**:序列/战况/出怪规律的副题、
   全屏标题、标签页标题、游戏坞同步条,凡是能看到出怪的地方都带上归属。
   落点刻意选既有文本节点(不新增角标):驾驶舱下 .panel-sub 本就 display:none,
   零几何影响 —— 既不动 computeLayout 的 NOTE_H 预算,也不重演 4.3.3 那轮
  「角标压住战况/出怪规律表头」的同族缺陷。 */
function roomTag(){ return S.alias ? `${S.alias} 房` : ''; }
function roomWho(){
  const n = (S.profile && S.profile.nickname) || '';
  return S.alias ? (n ? `${n} · ${S.alias} 房` : `${S.alias} 房`) : '';
}
function syncRoomScope(){
  const tag = roomTag(); if (!tag) return;              // 开机窗口(未定房)保持静态原文
  if (D.roadSub)
    D.roadSub.textContent = `${tag} · 近 24 小时出怪顺序,左旧右新 —— 各房各出各的怪,不与别的直播间通用`;
  if (D.trendSub)
    D.trendSub.textContent = `${tag} · 号位·大小·单双三线轨迹图 · 最新在上 · ${trendHint()}`;
  if (D.wideTitle) D.wideTitle.textContent = `${roomWho()} 出怪序列 · 全景回放`;
  if (D.anchorAlias)
    D.anchorAlias.title = `当前观测:${roomWho()}。观测台一次只统计一个直播间,各房出怪互不相同。`;
}

/* ═══════════ 渲染:九法阵(横排卡片,骨架+原地更新) ═══════════ */
function buildBoardSkeleton(){
  const topMult = Math.max(...S.spells.map(sp => Number(sp.multiplier) || 0));  // 最高倍率(当前配置为 9 · ×500)
  D.spellBoard.innerHTML = S.spells.map(sp => {
    const n = sp.display_number;
    const isTop = topMult > 0 && Number(sp.multiplier) === topMult;
    return `
    <article class="spell-cell${isTop ? ' is-top' : ''}" data-n="${n}" style="--e:var(--e${n});--es:var(--e${n}s)"
      role="button" tabindex="0" aria-pressed="false"
      title="单击聚光:出怪序列只亮「${n}·${esc(sp.spell_key)}」,再点取消(可多选叠加)">
      ${isTop ? '<i class="top-ring" aria-hidden="true"></i>' : ''}
      <span class="spell-num">${n}</span>
      <i class="pred-flag" aria-hidden="true" hidden></i>
      <span class="spell-beast"><img src="${esc(sp.beast_icon||'')}" alt="${esc(sp.beast_name)}"></span>
      <h3 class="spell-key">${esc(sp.spell_key)}<small>${esc(sp.beast_name)}</small></h3>
      <b class="spell-mult"><i>×</i>${sp.multiplier}</b>
      <span class="spell-prob">${esc(sp.probability)}</span>
      <div class="spell-gap">
        <div class="spell-gap-row"><span>连空</span><b></b></div>
        <div class="heat"><i></i></div>
        <span class="state-chip"></span>
      </div>
    </article>`;
  }).join('');
  D.boardCells = {};
  S._boardLatestKey = undefined;         // 骨架重建后强制重算出怪态
  $$('.spell-cell', D.spellBoard).forEach(cell => {
    D.boardCells[cell.dataset.n] = {
      cell, heat: cell.querySelector('.heat i'),
      gap: cell.querySelector('.spell-gap-row b'), chip: cell.querySelector('.state-chip'),
      flag: cell.querySelector('.pred-flag'),
    };
  });
}
function renderBoard(){
  if (!S.spells.length){ D.spellBoard.innerHTML = ''; D.boardCells = null; return; }
  const st = deriveStats();
  const ok = D.boardCells && Object.keys(D.boardCells).length === S.spells.length
    && S.spells.every(sp => D.boardCells[sp.display_number]);
  if (!ok) buildBoardSkeleton();
  for (const sp of S.spells){
    const n = sp.display_number, g = st.gap[n];
    // 3.8.2 零数据态:空历史时 gap 恒 0 会让九个号全标「刚出」(stateOf 的语义误伤),
    // 与出怪司历同口径改为明示「待数据」,连空显「—」、热度条清零。
    const state = st.total ? stateOf(g, officialProbOr(n))
                           : { s:'待数据', heat: 0, c:'var(--gilt)' };
    const ref = D.boardCells[n];
    ref.heat.style.setProperty('--h', state.c);
    ref.heat.style.width = (state.heat*100).toFixed(0) + '%';
    ref.gap.textContent = st.total ? gapText(st, n) + ' 局' : '— 局';
    if (ref.chip.dataset.s !== state.s){ ref.chip.dataset.s = state.s; ref.chip.textContent = state.s; }
  }
  refreshBoardLatest();                  // 出怪态由相位驱动:仅"本局刚开出"点亮,施法/备战期自动重置
  markBoardPrediction();                 // 灵机推演联动:把主/防号位标注回九法阵
  syncSpotlight();                       // 3.4.4 号位聚光:骨架若刚重建,把 is-picked/aria 补回
}

/* 「开」态相位化:出怪样式只在"本局(当前相位周期)已开出"时点亮,
   进入下一局施法期即重置——避免上一局的「开」章/描边/呼吸在整局施法期里
   一直亮着、把已成历史的结果误显为"刚开出",也把阵面让给本局的主/防推演印。
   由 tick()(200ms)驱动,相位翻面即时生效,状态未变时零 DOM 抖动。 */
function refreshBoardLatest(){
  if (!D.boardCells) return;
  const h0 = S.hist[0];
  const fresh = !!(h0 && h0.start === curStart(nowC()));   // 最新一局属于当前相位周期 → 视为"刚开出"
  const key = fresh ? String(h0.id) : '';
  if (key === S._boardLatestKey) return;                   // 出怪态无变化,免重复触碰 DOM
  S._boardLatestKey = key;
  const latestN = fresh ? Number(h0.n) : null;
  for (const k in D.boardCells)
    D.boardCells[k].cell.classList.toggle('is-latest', latestN != null && Number(k) === latestN);
}

/* 灵机推演 ←→ 九法阵 联动:在本局推演命中的号位卡上打「主 / 防」印,
   让用户读到推演号位后可直接在阵中定位(与卡片颜色/号位金印同源) */
function markBoardPrediction(){
  if (!D.boardCells) return;
  const main  = new Set((S.pred?.main  || []).map(Number));
  const guard = new Set((S.pred?.guard || []).map(Number));
  for (const key in D.boardCells){
    const ref = D.boardCells[key];
    const n = Number(key);
    const p = main.has(n) ? 'main' : guard.has(n) ? 'guard' : null;
    ref.cell.classList.toggle('is-pred-main',  p === 'main');
    ref.cell.classList.toggle('is-pred-guard', p === 'guard');
    if (ref.flag){
      if (p){ ref.flag.hidden = false; ref.flag.dataset.p = p; ref.flag.textContent = p === 'main' ? '主' : '防'; }
      else { ref.flag.hidden = true; ref.flag.removeAttribute('data-p'); }
    }
  }
}

/* ═══════════ 3.4.4 号位聚光:九法阵妖怪卡 ⇄ 出怪序列 ═══════════
   单击九法阵任一妖怪卡,出怪序列只亮该号、其余压暗 —— 该号的疏密/节奏/扎堆
   一眼可读(等价于把出怪司历的「连空」摊开成整条 24h 时间轴)。再点取消;
   可多选叠加(如同时点亮推演主推两号对照节奏)。
   · 状态落在序列**容器**类上(hl-on + hl-nN):renderRoad 无论全量 innerHTML
     重建还是增量补珠都只动子节点,容器类天然幸存 —— 聚光零重放、零适配。
   · 主序列与全屏序列(wideGrid)同步同一份状态;换房由 applyRoomData 清空。
   · 压暗只用 opacity(瞬时切换,无过渡/滤镜 —— 取舍账本见 app.css 同名注释);
     脉冲珠(战况点行联动 pulseBead)豁免,聚光下仍全亮可寻。 */
function toggleSpot(n){
  n = Number(n);
  if (!(n >= 1 && n <= 9)) return;
  const on = !S.hl.has(n);
  if (on) S.hl.add(n); else S.hl.delete(n);
  syncSpotlight();
  if (on && !S._hlTaught){                 // 首次开启:一次性教学吐司(本会话仅一次)
    S._hlTaught = true;
    toast('聚光已开:再点该妖怪卡或按 Esc 取消,可多选叠加');
  }
}
function clearSpot(){
  if (!S.hl.size) return;
  S.hl.clear();
  syncSpotlight();
}
function syncSpotlight(){
  // 1) 序列容器类(主盘 + 全屏共用一份状态;隐藏中的 wideGrid 一并写好,开屏即生效)
  for (const g of [D.roadGrid, D.wideGrid]){
    if (!g) continue;
    g.classList.toggle('hl-on', S.hl.size > 0);
    for (let n = 1; n <= 9; n++) g.classList.toggle('hl-n' + n, S.hl.has(n));
  }
  /* 1.5) 4.7.6:近 24h 战况珠盘同享聚光。类挂**常驻容器**(#officialAide / .rg-body),
     而不是每次重渲染都换新节点的 .rg-road-row —— 这样 renderAide / rgSyncRender
     的 innerHTML 重建天然幸存,与序列容器(#roadGrid 常驻)同一哲学,零重放。 */
  for (const b of [D.officialAide, D.realBody, D.simBody]){
    if (!b) continue;
    b.classList.toggle('hl-on', S.hl.size > 0);
    for (let n = 1; n <= 9; n++) b.classList.toggle('hl-n' + n, S.hl.has(n));
  }
  // 2) 九法阵卡片按下态(与主/防印同法:类开关 + aria-pressed)
  if (D.boardCells) for (const k in D.boardCells){
    const on = S.hl.has(Number(k));
    D.boardCells[k].cell.classList.toggle('is-picked', on);
    D.boardCells[k].cell.setAttribute('aria-pressed', on ? 'true' : 'false');
  }
  renderSpotChip();
}
/* 「聚光」徽标(序列头部 + 全屏头部同款):各号色印 + 在盘珠数 + × 清除。
   计数口径 = S.hist 全量 —— 与出怪司历(censusRange 的"近24小时·N期")、全屏
   序列(renderRoad 的 all = 全量)同一口径。3.8.2 起 S.hist 本身已被钉真为
   锚定 24h 窗(pruneHistWindow):三处口径不再是"约等",而是同一真 24h 集合;
   24h 满打 ≈1729 局 < ROAD_MAX(1800),旧注所述 >25h 驻留的 ≤400 局尾差不复存在。
   状态未变零 DOM 抖动:同帧多路调用(renderBoard 与 renderRoad 各触一次)时,
   以渲染串比对短路,不重复触碰 innerHTML/hidden。 */
function renderSpotChip(){
  const chips = [D.roadSpot, D.wideSpot].filter(Boolean);
  if (!chips.length) return;
  let html = '';
  if (S.hl.size){
    const counts = {}; for (const n of S.hl) counts[n] = 0;
    for (const r of S.hist) if (counts[r.n] !== undefined) counts[r.n]++;
    html = '<b>聚光</b>' + [...S.hl].sort((a, b) => a - b).map(n =>
      `<i class="rs-dot" style="--e:var(--e${n})">${n}</i><em>${counts[n]}珠</em>`
    ).join('') + '<span class="rs-x" aria-hidden="true">×</span>';
  }
  if (html === S._spotHtml) return;
  S._spotHtml = html;
  for (const c of chips){ c.innerHTML = html; c.hidden = !html; }
}

/* ═══════════ 渲染:出怪序列 ═══════════ */
/* 3.4.5:悬挂珠三态 tooltip(与 tick 的 pendMode 一一对应;首帧静态 title 取 this 态) */
const PEND_TITLES = {
  this: '下一颗珠 · 距本局出怪读秒(秒,施法期与备战期连续)',
  wait: '本局出怪中 · 官方结果待揭晓',
  next: '本局已开出 · 读秒至下一局出怪落珠(秒,跨局连续)',
};
const PENDING_HTML =
  `<span class="bead-pending" title="${PEND_TITLES.this}">--</span>`;
/* ── 4.4.0:断口标记 ────────────────────────────────────────────────────────
   缺局在序列上原本是**隐形**的 —— 两颗不相邻的珠直接挨着,用户读到的是一段
   连续历史,而它并不连续。仓库自带真机快照里 2678075 房那段 17 局缺口,在旧
   渲染下就是这样被抹平的。
   ★ 为什么是「给后一颗珠加属性」而不是「插一个断口节点」:
     renderRoad/tryAppendRoad 对珠序做了紧凑算术 —— `grid.children.length - 1`
     当珠数、`grid.children[beads-1]` 取末珠、收边靠 `firstElementChild.remove()`。
     插入非珠节点会让这三处**同时静默算错**(实测:末珠定位错位 → 增量路径退化
     或重复插珠)。加属性则节点数逐字节不变,以上算术一行都不用动。
   gapBefore = 本珠与前一颗珠之间缺失的格点数(0 = 连续)。 */
function gapTitle(g){
  return `　⟨此处 ${g} 局未观测,序列不连续⟩`;
}
/* ── 4.7.1:缺局占位珠恒展开 ───────────────────────────────────────────────
   4.7.0 曾把大于 5 局的连续缺口压成一枚可点击折叠珠。那会让 1 个珠格代表 N 个
   时间格,盘面列位再次与真实时间轴错位;用户不主动展开时,「近24小时战况」也并未
   真正把全部缺失局展示出来。
   现统一为**一缺一珠**:无论缺口长度,每个 50001ms 格点都生成一颗静态占位珠。
   24h 锚定窗最多约 1729 个格点,真实珠与占位珠二者之和仍受该上限约束,不存在
   因取消折叠而无界增长。主盘全量/增量、实时全屏、按日回看、游戏战况全部复用
   voidHtml / voidNodes,因此不会出现某一入口仍压缩缺口的口径分叉。
   占位珠不带 data-id / data-n:聚光计数与 pulseBead 继续只命中真实珠。 */
function gapSlots(prevStart, nextStart){
  const a = Number(prevStart), b = Number(nextStart);
  if (!Number.isFinite(a) || !Number.isFinite(b) || b <= a) return 0;
  return Math.max(0, Math.round((b - a) / T.ROUND) - 1);
}
/* rows 必须为旧→新。统计口径与 beadsHtml 逐颗渲染共用 gapSlots,
   「缺 N」因此恒等于盘面实际占位珠数量,不再另写一套首末局推导公式。 */
function missingSlots(rows, prev0 = 0){
  let prev = Number(prev0) || 0, total = 0;
  for (const r of rows || []){
    total += prev ? gapSlots(prev, r.start) : 0;
    prev = Number(r.start) || prev;
  }
  return total;
}
function voidTitle(startMs){ return `第 ${dayNo(startMs)} 局 · 未观测`; }
function voidHtml(g, fromStart, cls){
  const k = cls || 'bead';
  const count = Math.max(0, Math.floor(Number(g) || 0));
  let s = '';
  for (let i = 0; i < count; i++)
    s += `<span class="${k} is-void" aria-hidden="true" title="${esc(voidTitle(fromStart + i * T.ROUND))}">·</span>`;
  return s;
}
function voidNodes(g, fromStart, cls){
  const k = cls || 'bead';
  const count = Math.max(0, Math.floor(Number(g) || 0));
  const f = document.createDocumentFragment();
  for (let i = 0; i < count; i++){
    const s = document.createElement('span');
    s.className = k + ' is-void'; s.setAttribute('aria-hidden', 'true');
    s.title = voidTitle(fromStart + i * T.ROUND); s.textContent = '·';
    f.appendChild(s);
  }
  return f;
}
function beadHtml(r, isNew=false, gapBefore=0){
  const g = gapBefore > 0 ? ` data-gap="${gapBefore}"` : '';
  return `<span class="bead ${isNew?'is-new':''}"${g} data-n="${r.n}" data-id="${esc(r.id)}" style="--e:var(--e${r.n})"
    title="${esc(r.key)} · ${esc(r.name)} ×${r.mult}  ${fmtClock(r.start)}${gapBefore>0?esc(gapTitle(gapBefore)):''}">${r.n}</span>`;
}
function beadNode(r, isNew=false, gapBefore=0){
  const el = document.createElement('span');
  el.className = 'bead' + (isNew ? ' is-new' : '');
  el.dataset.n = r.n; el.dataset.id = r.id;
  if (gapBefore > 0) el.dataset.gap = String(gapBefore);
  el.style.setProperty('--e', `var(--e${r.n})`);
  el.title = `${r.key} · ${r.name} ×${r.mult}  ${fmtClock(r.start)}`
    + (gapBefore > 0 ? gapTitle(gapBefore) : '');
  el.textContent = r.n;
  return el;
}
/* 旧→新一串珠的 HTML(逐颗算断口)。prev0 = 串首之前那颗珠的起点(0=无) */
function beadsHtml(rows, popLast = false, prev0 = 0){
  let prev = prev0;
  const out = rows.map((r, i) => {
    const g = prev ? gapSlots(prev, r.start) : 0;
    const vh = g > 0 ? voidHtml(g, prev + T.ROUND) : '';     // P3:占位格插在断口原位
    prev = r.start;
    return vh + beadHtml(r, popLast && i === rows.length - 1, g);
  });
  return out.join('');
}
/* 增量快路径:仅当结构已存在、新增末尾若干局时,补节点而非重建整格
   —— 实测全量重建 799 珠触发 ~60ms reflow;增量只动个位数节点 */
/* 程序化滚动:**瞬时**贴到目标位。容器带 scroll-behavior:smooth 时,直接赋
   scrollTop 会触发平滑动画;动画期若有新一帧渲染/再次赋值,动画中断停在半途 ——
   表现为「自动跟底偶尔差一点点,底部数字只露一半」。程序化贴位(跟随最新/恢复
   原位)必须瞬时到位;用户手动滚动仍享受容器自身的 smooth。 */
/* 3.3.2:纵览/移动版序列的珠径回写。
   主序列的列是 1fr,珠径由容器宽均分而来,JS 并不知道它是多少;而珠字号需要它。
   原先靠 CSS 容器查询(100cqw)在样式侧推导 —— 代价是容器内联尺寸每变一次,
   1733 颗珠的 font-size 全量重算(纵览下占 resize 单帧开销的 79%)。
   现改为:量一颗真实珠的盒宽写回 --bead,字号纯由 --bead 推导。
   注意只在纵览生效 —— 驾驶舱的列宽本就 = var(--bead),回写会形成反馈环。 */
function syncStackBead(){
  if (S.L?.mode === 'cockpit') return;                  // 驾驶舱由 computeLayout 给出 --bead
  const g = D.roadGrid;
  if (!g || !g.querySelector('.bead')) return;          // 尚无数据:留给 renderRoad 之后再量
  const cs   = getComputedStyle(g);
  const cols = parseFloat(cs.getPropertyValue('--cols')) || S.cols;
  const gap  = parseFloat(cs.columnGap) || 0;
  const w    = g.getBoundingClientRect().width;         // 无 border/padding,即 100cqw 的内联尺寸
  if (!(w > 0) || !(cols > 0)) return;
  // 与原 cqw 公式逐字等价:(100cqw − (cols−1)×gap) ÷ cols。
  // 注意不能改量单颗珠的盒宽 —— 1fr 会把小数摊到各列(19.1094/19.125 交替),
  // 而 cqw 用的是未摊分的理想列宽,量出来会差 ~0.005px,字号随之偏移。
  const bead = (w - (cols - 1) * gap) / cols;
  const cur = parseFloat(g.style.getPropertyValue('--bead'));
  if (Math.abs(cur - bead) < 0.001) return;             // 未变则不写,免得白白让 1733 颗珠失效
  g.style.setProperty('--bead', bead + 'px');
}
function snapScroll(el, top){
  if (!el) return;
  const prev = el.style.scrollBehavior;
  el.style.scrollBehavior = 'auto';
  el.scrollTop = top;
  el.style.scrollBehavior = prev;
}

/* ═══════════ 4.7.2:贴底守卫(stick-to-bottom guard)══════════════════════════
   ── 病灶（真机实测，非推断）─────────────────────────────────────────────
   4.7.1 之前四处序列各自在渲染尾巴上打一发 snapScroll:主盘 renderRoad(rAF)、
   全屏 openWide/renderRoad(rAF)、DIY 盘 rgFitRoad(rAF)、官方随身面板 renderAide
   (同步)。要害在于 —— **贴底是一次性事件,容器高度与内容高度却是持续变量**。
   贴好之后任何一次事后回流都会把它掀下来,而无人补救:

     · 手机地址栏收起/展开 → 视口高变 → .of-aide(flex:1 1 0 叠加 100cqh 曲线)
       高度随之变。Chromium 390×844 实测:战况 scrollTop 停在 236 不动,可滚上限
       却从 236 涨到 257 —— **余 21px 未贴底**;缩到 390×700 时余 49px。
       这正是「手机 + 官方盘、刚载入就偏」的成因:载入瞬间地址栏收起/视口重算
       是移动浏览器的常态动作,而它发生在 renderAide 贴底之后。
     · aideTick 的推演带就地换血(el.outerHTML = rgPredictHtml())只换节点、不补贴底;
       推演带由「等待」两枚灰片变成带命中率统计的形态时会长高,战况随之被压矮。
     · renderOfficialAcct 写入的头像 <img> 无固定尺寸,图片落位后账号条长高,同样压矮战况。
     · applyLayout 的 roadGeomChanged 补偿只在 L.mode==='cockpit' 分支求值,
       纵览/手机形态**恒不补**(实测横竖屏切换后主盘余 168px 未贴底)。

   ── 已排除 ──────────────────────────────────────────────────────────────
   与占位珠(.is-void)无关。同一视口下 A/B 对照:有占位珠(1727 珠 + 23 占位)
   与无占位珠(1728 珠 + 0 占位)两组,初始均贴底、视口变矮后均差 28px,逐字节同构。
   占位珠与真实珠在同一次 innerHTML 里生成,snapScroll 读到的 scrollHeight 早已
   把它们计入 —— 它只会让盘更长,不会让盘贴不到底。

   ── 药方 ────────────────────────────────────────────────────────────────
   改「一次性打点」为「订阅式维持」:容器一经 stickInit 即被守卫接管,由
   ResizeObserver(容器盒 + 内容盒)+ MutationObserver(子节点增删)+ 视口/字体/
   图片三类迟到事件共同驱动,持续把它钉在锚点上,直到**用户自己翻走**;用户翻回
   锚点附近(STICK_EPS)即自动重新接管。程序化滚动带时间戳静默窗,不会被自己
   触发的 scroll 事件误判成用户操作。
   锚点二选一:bottom(实时盘 —— 首要诉求是「现在」)/ top(按日回看 —— 当日
   回放从清晨读起,与实时互为镜像)。语义由调用方给,守卫只负责「维持」。 */
/* 「按日回看」的锚点。回看是一整天的**静态成像**,原设计从当日清晨读起,与实时盘
   「贴底看最新」互为镜像 —— 故默认 'top'。若希望回看也一律贴底,改成 'bottom' 即可,
   全项目只此一处生效(renderWideDay / wvGoLive 均取此常量)。 */
const WV_DAY_ANCHOR = 'top';
const STICK_EPS    = 24;    // 距锚点 ≤24px 视同「在锚点上」(与 renderRealGame 既有判据同值)
const STICK_SETTLE = 140;   // 滚动静止判定(ms):这么久没有新 scroll 才认为「停下了」
const _sticks = new Set();

function stickAtAnchor(el, anchor){
  if (!el) return false;
  return anchor === 'top'
    ? el.scrollTop <= STICK_EPS
    : (el.scrollHeight - el.clientHeight - el.scrollTop) <= STICK_EPS;
}
/* 贴位,并把「这一跳是我干的」标记住**一帧**。
   为什么恰好是一帧:按 HTML 规范,scroll 事件与 requestAnimationFrame 回调同在一次
   『更新渲染』步骤里跑,且 scroll 先于 rAF —— 在 rAF 里清标记,窗口精确覆盖本次赋值
   引发的那一个 scroll 事件,不多不少,不依赖任何经验性时长。
   ★ 两条弯路的教训(均已实测复现,勿再走回头路):
     · 时间静默窗(150ms):会把窗内**用户真实的**上翻一并吞掉 → armed 不翻转
       → 下一次几何变化又把人拽回底部;
     · 位置回声(比对上次贴到的坐标):用户自己滑回锚点时坐标恰好相同,被当成回声
       吞掉 → 永远不再重新接管。 */
function stickSnap(el, anchor){
  const st = el.__stick;
  if (st){
    st.self = true;
    if (st.selfRaf) cancelAnimationFrame(st.selfRaf);
    st.selfRaf = requestAnimationFrame(() => { st.self = false; st.selfRaf = 0; });
  }
  snapScroll(el, anchor === 'top' ? 0 : el.scrollHeight);
}
/* 贴一次 + 双 rAF 兜底:innerHTML 刚落、hidden 刚解除、容器刚从 0 高长出来时,
   同帧内的 scrollHeight 可能还不是终值;两帧之后必然落定。 */
function stickPin(el, opts){
  const st = el && el.__stick; if (!st) return;
  if (opts && opts.force) st.armed = true;
  if (!st.armed) return;
  stickSnap(el, st.anchor);
  if (st.raf) cancelAnimationFrame(st.raf);
  st.raf = requestAnimationFrame(() => {
    st.raf = requestAnimationFrame(() => {
      st.raf = 0;
      if (st.armed && el.isConnected) stickSnap(el, st.anchor);
    });
  });
}
/* 回收已离开文档的条目。**必须在每次 stickInit 时做**,不能只挂在 stickPinAll 上:
   AIDE 每落一局就整块重建随身面板(aideTick),战况因此每 ~50s 换一个新节点;而
   stickPinAll 只由 resize / 视口 / 字体 / 图片 / 换账号这些**用户驱动**的事件触发,
   一个把页面挂在那儿不动的手机用户根本触发不到它 —— 旧条目连同脱离文档的 DOM、
   ResizeObserver、MutationObserver 一起滞留。实测:连做 280 次重渲染,_sticks.size
   由 4 涨到 144,线性无收敛;按生产节拍 24h 约 1728 条。 */
function stickReap(){
  for (const st of _sticks){
    if (st.el.isConnected) continue;
    try { st.ro && st.ro.disconnect(); st.mo && st.mo.disconnect(); } catch (_){}
    if (st.raf)     cancelAnimationFrame(st.raf);
    if (st.selfRaf) cancelAnimationFrame(st.selfRaf);
    if (st.settleT) clearTimeout(st.settleT);
    st.el.__stick = null;
    _sticks.delete(st);          // 边遍历边删对 Set 是安全的
  }
}
/* 幂等:同一元素重复调用只更新锚点,不重复挂观察者。
   content = 内容盒(如 #roadWrap 的内容是 #roadGrid);不给则以容器自身为内容宿主。 */
function stickInit(el, { anchor = 'bottom', content = null } = {}){
  if (!el) return null;
  let st = el.__stick;
  if (st){
    if (st.anchor !== anchor){ st.anchor = anchor; st.armed = true; }
    return st;
  }
  stickReap();                 // 每新增一个容器就顺手清一次死条目 —— 见 stickReap 注
  st = el.__stick = { el, anchor, armed: true, self: false, selfRaf: 0, settleT: 0, raf: 0, ro: null, mo: null };
  const onGeom = () => { if (st.armed) stickPin(el); };
  try {
    st.ro = new ResizeObserver(onGeom);
    st.ro.observe(el);                                     // 容器高/宽变(视口、flex 重分配、折叠档)
    if (content && content !== el) st.ro.observe(content);  // 内容高变(珠径随列宽、行数随档位)
  } catch (_){}
  try {
    st.mo = new MutationObserver(onGeom);
    st.mo.observe(content || el, { childList: true });     // 珠子增删(增量落珠、全量重建、收边)
  } catch (_){}
  el.addEventListener('scroll', () => {
    /* ① 守卫自己贴的那一跳,不参与判定。判据是「self 标记 **且** 位置确实落在锚点上」——
          只看 self 不够:stickPin 的双 rAF 兜底会再开一个 self 窗口,夹在中间的**用户**
          滚动会被一并吞掉(实测:贴底后 30ms 上翻,armed 不翻转,下一次几何变化又被拽回)。
          而我们自己贴的一跳**必然**停在锚点上,所以 self 期内位置不在锚点的,一定是用户。
          时序上也安全:HTML 规范「更新渲染」步骤里 scroll 事件先于 rAF 回调派发,
          故用户这一跳总能在双 rAF 兜底重贴之前把 armed 翻掉。 */
    if (st.self && stickAtAnchor(el, st.anchor)) return;
    /* ② 离开锚点 → **立即**交还控制权。必须即时:慢一拍守卫就会在用户的手指(或
          scrollIntoView 的平滑动画)还在动的时候把人拽回去,表现为「甩不掉的底部」。 */
    if (!stickAtAnchor(el, st.anchor)) st.armed = false;
    /* ③ 回到锚点 → 等滚动**停下来**再接管。不能一见到「此刻在锚点上」就接管:
          从底部往上滑的头几帧仍在 STICK_EPS 之内,那是**路过**而非**停留**,
          当场接管会把用户正要离开的动作原地掐断(点战况行联动序列 pulseBead
          就是这样被掐回底部的,已实测复现)。 */
    clearTimeout(st.settleT);
    st.settleT = setTimeout(() => {
      st.settleT = 0;
      if (el.isConnected) st.armed = stickAtAnchor(el, st.anchor);
    }, STICK_SETTLE);
  }, { passive: true });
  _sticks.add(st);
  stickPin(el);
  return st;
}
/* 全量重贴(先回收再贴,集合恒等于「在世容器数」) */
function stickPinAll(){
  stickReap();
  for (const st of _sticks) if (st.armed) stickPin(st.el);
}
/* 迟到事件三连 —— 它们全都发生在「贴底之后」,且全都会改变几何:
     · visualViewport.resize:手机地址栏收起/展开、软键盘起落(window.resize 在
       iOS Safari 地址栏动画期并不可靠,visualViewport 才是权威信号);
     · orientationchange:横竖屏(延一帧等布局落定);
     · load(capture)+ fonts.ready:头像/妖兽图与自定义字体落位后的回流。 */
if (window.visualViewport) visualViewport.addEventListener('resize', stickPinAll);
addEventListener('orientationchange', () => setTimeout(stickPinAll, 60));
addEventListener('load', stickPinAll);
addEventListener('load', e => { if (e.target && e.target.tagName === 'IMG') stickPinAll(); }, true);
if (document.fonts && document.fonts.ready) document.fonts.ready.then(stickPinAll).catch(() => {});

function tryAppendRoad(capacity){
  const grid = D.roadGrid;
  const pend = grid.lastElementChild;
  if (!pend || !pend.classList.contains('bead-pending')) return false;   // 结构不符 → 回退全建
  // P3:珠数 / 末珠不再靠节点位置推 —— 占位珠(.is-void)会打乱 children 序。
  //     改读 grid 上维护的单一真相,插多少占位格算术都不受影响。
  const beads = Number(grid.dataset.n || 0);
  if (beads <= 0) return false;
  const lastId = grid.dataset.last || '';
  if (!lastId) return false;
  const idx = S.hist.findIndex(r => r.id === lastId);                    // 定位当前末珠在历史中的位置
  if (idx < 0) return false;
  const fresh = S.hist.slice(0, idx).reverse();                         // 比末珠更新的局(旧→新)
  if (!fresh.length || fresh.length > 64) return false;                 // 无新增或跨度过大 → 全建更稳
  const frag = document.createDocumentFragment();
  let prev = Number(lastId) || 0;                                       // 4.4.0:接续末珠算断口
  fresh.forEach((r, i) => {
    const g = prev ? gapSlots(prev, r.start) : 0;
    if (g > 0) frag.appendChild(voidNodes(g, prev + T.ROUND));          // P3:断口占位格
    prev = r.start;
    frag.appendChild(beadNode(r, i === fresh.length - 1, g));
  });
  grid.insertBefore(frag, pend);                                        // 插到 pending 之前
  grid.dataset.n = String(beads + fresh.length);                        // P3:真珠数
  grid.dataset.last = String(fresh[fresh.length - 1].id);               //     末珠 id
  // 3.8.2 收边界改 min(容量, hist 长度):此前只按容量(1801)收边 —— 24h 锚定窗
  // 落地后 hist 稳态 ≈1728 < 容量,增量路径"只进不出",每局 +1 珠而窗口尾局已被
  // pruneHistWindow 裁走 → 实测 80 局后 DOM 1800 珠 vs hist 1728,盘头 72 颗
  // 陈珠越窗滞留(聚光计数、24h 标注随之失真)。现按两者取小收边,DOM 恒为
  // S.hist 的逐珠镜像;hist ≥ 容量的旧场景(理论上限 1729 摸不到 1800)语义不变。
  // P3:收边按**真珠**计 —— 删到占位格不减计数,否则每有一个占位格就少收一颗真珠。
  const keep = Math.min(capacity - 1, S.hist.length);
  let extra = Number(grid.dataset.n || 0) - keep;
  while (extra > 0){
    const f = grid.firstElementChild;
    if (!f || f === pend) break;
    if (!f.classList.contains('is-void')) extra--;
    f.remove();
  }
  while (grid.firstElementChild && grid.firstElementChild !== pend
         && grid.firstElementChild.classList.contains('is-void'))
    grid.firstElementChild.remove();                                    // 盘头孤立占位格无所指,一并清
  grid.dataset.n = String(Math.min(Number(grid.dataset.n || 0), keep));
  return true;
}
function renderRoad(withPop = false){
  const cockpit = S.L?.mode === 'cockpit';
  // 24h 全量(双模统一):此前驾驶舱按容器高折算 capacity(定高裁剪,只见最近
  // 数十~数百局)。现两模式都画满 ROAD_MAX(=HISTORY_LIMIT,≈24h),超出容器
  // 高度由 .road-wrap 的纵向滚动条承接(纵览原生就有;驾驶舱 CSS 已同步放开)。
  const capacity = ROAD_MAX + 1;
  // 4.7.3:纵览/手机按容器实宽夹紧(驾驶舱的 L.roadCols 由 computeLayout 另行给出)
  D.roadGrid.style.setProperty('--cols', cockpit ? S.L.roadCols : roadColsFor(D.roadWrap));

  // 「是否停在底部」必须在 DOM 变更前采样——插珠/删旧珠会触发浏览器
  // scroll anchoring 同步调整 scrollTop,事后读取会把"本在底部"误判成"已上翻"
  const wasBottom =
    (D.roadWrap.scrollTop + D.roadWrap.clientHeight >= D.roadWrap.scrollHeight - 48);

  // 单局到账优先走增量;失败(首建/布局变/乱序)再全量重建
  const appended = withPop && tryAppendRoad(capacity);
  if (!appended){
    const rows = S.hist.slice(0, capacity - 1).reverse();     // 旧 → 新
    D.roadGrid.innerHTML = beadsHtml(rows, withPop) + PENDING_HTML;
    D.roadGrid.dataset.n = String(rows.length);                          // P3:真珠数 / 末珠 id 单一真相
    D.roadGrid.dataset.last = rows.length ? String(rows[rows.length - 1].id) : '';
  }
  // 自动跟随最新珠(双模同规),但仅当用户本就停在底部附近(±48px,变更前采样)
  // 或本次为全量重建(首建/换房/改档);用户上翻回看旧珠时,新珠入账不拽回底部
  // 4.7.2:全量重建(首建/换房/改档)恒重新接管;增量落珠沿用「变更前采样」的
  //        wasBottom,用户上翻回看时不拽回。守卫此后负责持续维持,不再是一次性。
  if (!appended) stickPin(D.roadWrap, { force: true });
  else if (wasBottom) stickPin(D.roadWrap, { force: true });

  if (!cockpit) syncStackBead();          // 3.3.2:珠子刚落地/档位刚变,重新量一次珠径

  wvSyncEntry();   // 3.6.0:入口可见性单源化 —— 旧规则 + "有可回放日则不隐藏"(见 wvSyncEntry 注)

  if (!D.wideView.hidden && WV.mode === 'live'){   // 3.6.0:按日回看态由 renderWideDay 静态成像,出怪不重绘本层
    // 与主序列同规:「是否在底部」在 DOM 变更前采样(规避 scroll anchoring),
    // 仅底部附近(±48px)自动跟随最新;用户上翻回看时全量重建不拽回
    const wasWideBottom = D.wideBody.scrollTop + D.wideBody.clientHeight >= D.wideBody.scrollHeight - 48;
    const all = S.hist.slice().reverse();
    setWideGeom();   // 4.7.3 夹紧 + 4.7.6 独立档与 --g 同步下发(见 wideColsFor 注)
    D.wideGrid.innerHTML = beadsHtml(all) + PENDING_HTML;
    // P3 复审补:按日回看早有「· 缺 N」,实时全屏没有 —— 口径对齐(与 renderWideDay 同式)
    const liveMiss = missingSlots(all);
    D.wideCount.textContent = `${all.length} 局${liveMiss ? ` · 缺 ${liveMiss}` : ''} · 24h`;
    if (wasWideBottom) stickPin(D.wideBody, { force: true });
  }
  // 2.6.3:悬挂珠节点仅在本函数内创建/替换 —— 在此一次性缓存,
  // tick(200ms)不再每次全文档 querySelectorAll(实测 45.5µs/次 → 0)
  D.pendingEls = $$('.bead-pending');
  if (S.hl.size) renderSpotChip();       // 3.4.4:新珠入账 → 聚光徽标计数跟进(容器类无须重放)
  tick();
}
function pulseBead(id){
  const el = D.roadGrid.querySelector(`.bead[data-id="${CSS.escape(id)}"]`);
  if (!el){ toast('该局早于当前序列窗口,可用「全屏」回看'); return; }
  /* 4.7.2:点战况行来看某颗旧珠,是**用户明确要离开底部**的意图 —— 先把贴底守卫
     解除,再滚过去。不解除的话有两条打断路径:(a) smooth 动画期间恰好落新珠,
     MO 触发重贴会把动画掐断并弹回底部;(b) 动画头几帧还没离开 STICK_EPS,
     armed 尚未翻转,同样会被拽回。解除后由用户自己滑回底部时自动重新接管。 */
  if (D.roadWrap.__stick) D.roadWrap.__stick.armed = false;
  // 目标珠可能在序列滚动区之外(纵览低档位/手机):先滚入可视区,脉冲才看得见
  el.scrollIntoView({ block:'nearest', inline:'nearest',
    behavior: matchMedia('(prefers-reduced-motion:reduce)').matches ? 'auto' : 'smooth' });
  el.classList.remove('pulse'); void el.offsetWidth; el.classList.add('pulse');
}

/* ═══════════ 渲染:战况(界面 2.6.1 · 典藏珠线版·三线) ═══════════ */
/* 每局一行:期号 | 号位1-9 | 大 小 单 双。经典战况图解剖 × 三区三线:
   · 命中号位 = 九法色圆珠(.tb,白字),未命中 = 极浅底网数字(带 data-c 供列准星);
   · 大小单双同为珠线区:开出者结成与号位同规格的色珠(大朱砂/小青蓝/单鎏金/双官青),
     未开者留浅字锚定列位;两区各自有贯线(青蓝/官青),与号位朱砂主线并行三轨;
   · 三条折线均连接相邻两行命中珠圆心,从珠下穿过(层序见 CSS)。
   最新在顶部;容器高度有限时内部纵向滚动。 */
/* 3.3.1:i = 绝对局序(0 = 最新),pitch = 行距(行高 + 1px 下边线)。
   行绝对定位到 i*pitch;斑马/计数线按 i 推导,与旧 :nth-child(1 基)对齐。 */
function trendRowHtml(r, i, pitch, gapAfter = 0){
  const big = r.n >= 5, odd = r.n % 2 === 1;
  const side = (cls, on, ch) => on
    ? `<span class="trend-cell side hit ${cls}" data-c="${cls}"><i class="tb">${ch}</i></span>`
    : `<span class="trend-cell side off" data-c="${cls}">${ch}</span>`;
  // P3 复审补:战况三线图同样是一句「连续」的断言,缺局在此也是隐形的。
  // 这里**刻意不插行** —— trend-row 走 top:i*pitch 绝对定位 + 斑马/计数线按 i 推导,
  // 插行会让三处算术同时错位(与序列 4.4.0 原注同类风险)。故只标属性,零节点新增。
  let cells = `<span class="trend-cell idx"${gapAfter > 0 ? ` data-gap="${gapAfter}"` : ''}`
            + ` title="${fmtClock(r.start)}${gapAfter > 0 ? esc(gapTitle(gapAfter)) : ''}">${dayNo(r.start)}</span>`;
  for (let k=1; k<=9; k++){
    cells += (k === r.n)
      ? `<span class="trend-cell hit" data-c="${k}" data-n="${k}" style="--e:var(--e${k});--es:var(--e${k}s)"><i class="tb">${k}</i></span>`
      : `<span class="trend-cell miss" data-c="${k}">${k}</span>`;
  }
  cells += side('big',  big,  '大');
  cells += side('small', !big, '小');
  cells += side('odd',  odd,  '单');
  cells += side('even', !odd, '双');
  const z = (i + 1) % 2 === 0 ? ' data-z' : '';       // 旧 :nth-child(even)
  const f = (i + 1) % 5 === 0 ? ' data-f' : '';       // 旧 :nth-child(5n)
  return `<div class="trend-row${i===0?' is-latest':''}" data-id="${esc(r.id)}"${z}${f}`
       + ` style="top:${i * pitch}px">${cells}</div>`;
}
function trendCount(){
  return TREND_ROWS;   // 2.5.10:驾驶舱与纵览统一 100 局(此前驾驶舱按可视高折算 ~10–25 局)
}
/* 折线叠加:读取已渲染行的命中珠几何,连成三条贯线 ——
   号位(朱砂,主线 2.5px)+ 大小(青蓝,副线 2px)+ 单双(官青,副线 2px)。
   三线互不越区,均为双描线(宽软晕托底 + 细实心),从各自命中珠下穿过。 */
/* 3.3.1:原实现对每一行做 3 次 querySelector + getBoundingClientRect
   (1733 行 = 5199 次强制布局读取,实测 35ms/次调用),且窗口化后离屏行
   根本不在 DOM 里。改为「量一行、算全表」:
   · 全表共用同一 grid 列模板,故列心 x 只需从任一已渲染行量 14 格;
   · .tb 由 .trend-cell{place-items:center} 居中于内容盒,
     内容盒中心 = 格左 + clientLeft(左边框) + clientWidth/2 —— 边框差异自动抵消;
   · 行 y 心 = i*pitch + 格内 y 心,行距恒定。
   DOM 读取从 5199 次降到 14 次,且与离屏行无关。 */
function drawTrendLine(){
  const body = D.trendBody, svg = D.trendLine;
  const rows = S.trendCtx?.rows || [];
  const probe = body.firstElementChild;                     // 窗口内任一行:列几何全表通用
  if (rows.length < 2 || !probe || probe.children.length < 14){ svg.innerHTML = ''; return; }

  const pitch = trendRowPitch();
  const bodyRect = body.getBoundingClientRect();
  const probeRect = probe.getBoundingClientRect();
  const cx = new Array(14);                                  // 0=期号 1..9=号位 10=大 11=小 12=单 13=双
  let cy = 0;
  for (let k = 0; k < 14; k++){
    const c = probe.children[k], cr = c.getBoundingClientRect(), cs = getComputedStyle(c);
    // 用计算样式取边框(小数精度),不用 clientLeft/clientWidth —— 后者取整会带入 ≤0.5px 偏移
    const bl = parseFloat(cs.borderLeftWidth)  || 0, br = parseFloat(cs.borderRightWidth)  || 0;
    const bt = parseFloat(cs.borderTopWidth)   || 0, bb = parseFloat(cs.borderBottomWidth) || 0;
    cx[k] = cr.left - bodyRect.left + bl + (cr.width - bl - br) / 2;
    if (k === 1) cy = cr.top - probeRect.top + bt + (cr.height - bt - bb) / 2;
  }

  const W = bodyRect.width, H = rows.length * pitch;
  svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
  svg.setAttribute('width', W); svg.setAttribute('height', H);

  const pts = { n:[], bs:[], oe:[] };
  for (let i = 0; i < rows.length; i++){
    const n = rows[i].n;
    const y = (i * pitch + cy).toFixed(1);
    pts.n .push(`${cx[n].toFixed(1)},${y}`);                          // 号位命中珠
    pts.bs.push(`${cx[n >= 5 ? 10 : 11].toFixed(1)},${y}`);           // 大/小命中珠
    pts.oe.push(`${cx[n % 2 === 1 ? 12 : 13].toFixed(1)},${y}`);      // 单/双命中珠
  }
  const dline = (arr, color, wh, oh, wc, oc) => arr.length < 2 ? '' :
    `<polyline points="${arr.join(' ')}" fill="none" stroke="${color}" stroke-width="${wh}" stroke-linejoin="round" stroke-linecap="round" opacity="${oh}"/>` +
    `<polyline points="${arr.join(' ')}" fill="none" stroke="${color}" stroke-width="${wc}" stroke-linejoin="round" stroke-linecap="round" opacity="${oc}"/>`;
  svg.innerHTML =
    dline(pts.bs, 'var(--cold-deep)',  6, .10, 2,   .8 ) +
    dline(pts.oe, 'var(--brand-deep)', 6, .10, 2,   .8 ) +
    dline(pts.n , 'var(--seal)',       7, .12, 2.5, .9 );
}
let trendLineRaf = 0;
function scheduleTrendLine(){
  if (trendLineRaf) return;
  trendLineRaf = requestAnimationFrame(() => { trendLineRaf = 0; drawTrendLine(); });
}
/* ── 3.3.1 战况虚拟化 ────────────────────────────────────────────────
   原实现把 TREND_ROWS(1800)局一次性铺进 DOM:1733 行 × 14 格 = 24,262 个
   .trend-cell,每格自身还是 grid,列模板含 9 条 1fr —— 视口宽一变,这 2.4 万
   个格子全部要重新求解轨道。实测拖拽时单帧「样式重算 + 布局」= 494ms,
   占整帧开销的 91%。

   改为只渲染可视窗口(上下各留 TREND_BUF 行缓冲):
   · .trend-body 高度钉成 局数 × 行距,滚动条长度与滚动手感不变;
   · 每行按绝对局序绝对定位,DOM 序 ≠ 局序,故斑马/计数线改由索引写属性;
   · 滚出窗口即卸载,滚入即挂载(rAF 合帧,窗口未变则整帧零工作);
   · 新局到账不再走「插一行」的增量路径 —— 重画 40 行比维护增量还便宜,
     只需按新增行数补偿 scrollTop,保证下翻读旧行的人视线零漂移。 */
const TREND_BUF = 6;                       // 窗口上下缓冲行数:滚动时不见白边

/* 行距 = 行高(--trh)+ 1px 下边线。两种形态的 --trh 由 applyLayout 写入。 */
function trendRowPitch(){
  return (S.L?.mode === 'cockpit' ? TREND_ROW_COCKPIT : TREND_ROW_STACK) + 1;
}

/* 按当前 scrollTop 计算应渲染的行区间;区间未变则直接返回(滚动时的常态) */
function renderTrendWindow(force){
  const rows = S.trendCtx?.rows;
  if (!rows || !rows.length) return;
  const pitch = trendRowPitch();
  const wrap  = D.trendBodyWrap;
  const top   = wrap ? wrap.scrollTop : 0;
  const vh    = (wrap && wrap.clientHeight) || 480;
  const start = Math.max(0, Math.floor(top / pitch) - TREND_BUF);
  const end   = Math.min(rows.length, Math.ceil((top + vh) / pitch) + TREND_BUF);

  const w = S.trendWin;
  if (!force && w && w.start === start && w.end === end) return;
  S.trendWin = { start, end };

  let html = '';
  // P3:rows 为「新 → 旧」,故第 i 行与第 i+1 行(更旧)之间的缺局挂在第 i 行上。
  // 窗口化渲染下 rows[i+1] 可能在窗口外,但它始终在数组里 —— 断口计算与滚动位置无关。
  for (let i = start; i < end; i++){
    const nx = rows[i + 1];
    const gp = nx ? Math.max(0, Math.round((rows[i].start - nx.start) / T.ROUND) - 1) : 0;
    html += trendRowHtml(rows[i], i, pitch, gp);
  }
  /* 4.9.4:整窗重建会换掉锚点行元素(新局到账/窗口滚动)——**只对触屏**收卡。
     触屏的卡锚在具体行元素上,行一被回收卡就成孤儿;桌面的卡由每一次 pointermove
     重新生成,不锚任何节点,收它反而是白白改掉既有行为。
     ★ 这一条最初写成了无条件收 —— 复查实测(1440×900,hover 住第 4 行后滚 120px):
       hover 卡 hidden false → true,桌面平白少了一张卡。属自伤,已门控修正。 */
  if (isTouchInput() && !D.trendTip.hidden) hideTrendTip();
  D.trendBody.innerHTML = html;
}

let trendScrollRaf = 0;
function onTrendScroll(){
  // 4.9.4:触屏卡锚在行元素上,而虚拟化会回收行 —— 一滚就收,不留孤卡
  if (isTouchInput() && !D.trendTip.hidden) hideTrendTip();
  if (trendScrollRaf) return;
  trendScrollRaf = requestAnimationFrame(() => { trendScrollRaf = 0; renderTrendWindow(); });
}

function renderTrend(prepend = false){
  const cap = trendCount();
  const rows = S.hist.slice(0, cap);           // 新→旧(最新在顶)
  const prev = S.trendCtx?.rows || [];
  S.trendCtx = { rows };
  if (!rows.length){
    D.trendBody.innerHTML = ''; D.trendBody.style.height = '0px';
    D.trendLine.innerHTML = ''; S.trendWin = null; return;
  }

  const pitch = trendRowPitch();
  D.trendBody.style.height = (rows.length * pitch) + 'px';

  /* 顶部新增了几局?对齐旧 tryPrependTrend 的三种归宿:
       k === 0            无新增(重复调用)      → 滚动位置原样不动
       0 < k <= 64        常态增量              → 补偿 k 行,视线所在行零漂移
       k > 64 / k === -1  大批回填 / 换房 / 对不上 → 视同全量重建,回顶  */
  const k = (prepend && prev.length) ? rows.findIndex(r => r.id === prev[0].id) : 0;
  const added = (k > 0 && k <= 64) ? k : 0;
  const rebuilt = !prepend || k > 64 || k === -1;

  const wrap = D.trendBodyWrap;
  if (wrap){
    const preTop = wrap.scrollTop;
    if (rebuilt) wrap.scrollTop = 0;                          // 首建/换房/形态切换/大批回填
    else if (added && preTop > 2) wrap.scrollTop = preTop + added * pitch;
    // 停在顶部的读者:不动,新行自然出现在最上
  }

  renderTrendWindow(true);
  scheduleTrendLine();
}

/* 战况交互:悬停高亮整行 + 悬浮卡 + 点击联动序列 */
function trendRowFromEvent(e){
  const row = e.target.closest('.trend-row');
  return row ? row.dataset.id : null;
}
/* 4.9.4:内容与定位拆开 —— 桌面沿用「跟指针」,触屏改「锚元素」(手指正压在指针位上,
   跟指针必然被自己的手挡住)。两条路径共用同一份内容生成与同一套夹紧规则。 */
function trendTipFill(id, col){
  const rows = S.trendCtx?.rows || [];
  const i = rows.findIndex(x => x.id === id);
  const r = i >= 0 ? rows[i] : null;
  if (!r) return null;
  // 2.6 未出场补注:同号上一次开出距今几期(窗口内未再现则不注)
  let gap = '';
  for (let j = i + 1; j < rows.length; j++){
    if (rows[j].n === r.n){ gap = ` · 距上次 <b>${j - i}</b> 期`; break; }
  }
  // 2.6.1 侧区未出场:落在大小/单双列上时,再补该性质自身的"距上次"——
  // 命中珠 = 两次同性质的间隔;浅字 = 该行时点此性质已未出场几期
  const sm = TREND_SIDE_META[col];
  if (sm){
    for (let j = i + 1; j < rows.length; j++){
      if (sm[1](rows[j].n)){ gap += ` · 「${sm[0]}」距上次 <b>${j - i}</b> 期`; break; }
    }
  }
  /* 4.9.4 三审补:断口提示在战况面板的**触屏路径上是丢的**。
     断口原文只挂在最左那格 `.trend-cell.idx` 的 title 上(trendRowHtml),而本卡
     此前不含断口段;通用气泡又把整个 #trendScroll 排除在外(战况另走专线)。
     于是桌面还能精确悬停到那格 10px 宽的 idx 看到「⟨此处 N 局未观测⟩」,
     触屏则一点办法都没有 —— 4.4.0 花大力气做的断口标记在这条路径上等于没做。
     ★ 只补触屏分支:桌面有 idx 格的原生 title 兜底,补了反而改动既有文案 ——
       「桌面路径零回归面」是本轮更重要的承诺(二审已因违反它自伤过一次)。
     gap 口径与 trendRowHtml 的 gapAfter 逐字一致:rows 为新→旧,故第 i 行与
     第 i+1 行(更旧)之间的缺格挂在第 i 行上,同一条算式,不另立一套。 */
  let hole = '';
  if (isTouchInput()){
    const nx = rows[i + 1];
    const g = nx ? Math.max(0, Math.round((r.start - nx.start) / T.ROUND) - 1) : 0;
    if (g > 0) hole = ` · <b>${g}</b> 局未观测(序列不连续)`;
  }
  D.trendTip.innerHTML = `<i class="tt-dot" style="--e:var(--e${r.n})"></i>${fmtClock(r.start)} · <b>${esc(r.key)}${r.n}</b> · ${r.n>=5?'大':'小'} · ${r.n%2===1?'单':'双'}${gap}${hole}`;
  return r;
}
/* cx/cy 为视口坐标锚点。定位三条修正逐字保留:
   1) 上方放不下 → 翻到下方(原先首行悬浮卡被容器上缘裁得只剩 1px);
   2) 水平夹紧在容器内(原先靠右时右半张卡被 overflow 裁掉);
   3) 叠加容器滚动量(绝对定位随内容滚动,原先容器滚动后卡整体错位)。 */
function trendTipPlace(cx, cy){
  const wrap = D.trendBodyWrap, wrapRect = wrap.getBoundingClientRect();
  const tw = D.trendTip.offsetWidth, th = D.trendTip.offsetHeight;
  const below = (cy - wrapRect.top) < th + 16;
  D.trendTip.classList.toggle('is-below', below);
  const x = clampN(tw/2 + 6, cx - wrapRect.left, wrap.clientWidth - tw/2 - 6) + wrap.scrollLeft;
  D.trendTip.style.left = x + 'px';
  D.trendTip.style.top  = (cy - wrapRect.top + wrap.scrollTop) + 'px';
}
function hideTrendTip(){
  clearTimeout(S.trendTipT); S.trendTipT = 0;
  D.trendTip.hidden = true; S.trendTapId = '';
  delete D.trendScroll.dataset.col;
}
function onTrendMove(e){
  // 4.9.4:触屏一律不走本路径 —— ① 静止点按根本不派发 pointermove,借不到道;
  // ② 滑动时倒是会派发,若不挡住,每一次滚动都会拖着一张卡跟手跑。
  if (isTouchInput()) return;
  // 2.6 列十字准星:悬停任一号位格(含表头)→ 容器记列号,CSS 点亮整列;移开清除
  const colEl = e.target.closest('[data-c]');
  const col = colEl ? colEl.dataset.c : '';
  if ((D.trendScroll.dataset.col || '') !== col){
    if (col) D.trendScroll.dataset.col = col; else delete D.trendScroll.dataset.col;
  }
  const id = trendRowFromEvent(e);
  if (!id){ D.trendTip.hidden = true; return; }
  if (!trendTipFill(id, col)){ D.trendTip.hidden = true; return; }
  D.trendTip.hidden = false;
  trendTipPlace(e.clientX, e.clientY);
}
function onTrendLeave(){
  // 4.9.4:触屏下 pointerleave **早于 click 抵达**(实测序列见 initInputBus 前长注)——
  // 在这里收卡等于替 click 提前把桌子掀了,故触屏一律不响应。
  if (isTouchInput()) return;
  D.trendTip.hidden = true; delete D.trendScroll.dataset.col;
}
/* 触屏专线:点行 = 显卡 + 十字准星 + 联动脉冲;再点同一行 = 收卡。
   三者互不冲突 —— 卡是纯展示(pointer-events:none)、准星是 CSS、脉冲在主序列上。 */
function onTrendTap(row, cell){
  const id = row.dataset.id;
  const col = cell ? cell.dataset.c : '';
  if (col) D.trendScroll.dataset.col = col; else delete D.trendScroll.dataset.col;
  if (!trendTipFill(id, col)){ hideTrendTip(); return ''; }
  D.trendTip.hidden = false;
  const anchor = (cell || row).getBoundingClientRect();
  // 锚在目标**上缘**:卡默认向上展开,手指在下方不挡读(与通用气泡同策)
  trendTipPlace(anchor.left + anchor.width / 2, anchor.top + 1);
  clearTimeout(S.trendTipT);
  S.trendTipT = setTimeout(hideTrendTip, TREND_TIP_HOLD_MS);
  return id;
}
function onTrendClick(e){
  const row = e.target.closest?.('.trend-row');
  const id = row ? row.dataset.id : null;
  if (!id) return;
  if (isTouchInput()){
    if (S.trendTapId === id && !D.trendTip.hidden) hideTrendTip();   // 再点同行 = 收
    else S.trendTapId = onTrendTap(row, e.target.closest('[data-c]'));
  } else {
    D.trendTip.hidden = true;    // 桌面:点击后随手收起(2.6 既有行为,逐字保留)
  }
  pulseBead(id);
}

/* 4.4.0 复审自查:本函数与 deriveStats 的连空是**同一类失真**,上一轮漏改。
   runOf 沿 S.hist 逐**记录**回溯,一旦中间有断口,断口两侧若恰好同号/同大小/
   同奇偶,就会被连成一串 —— 报出「连开 水 × 5」而其中两颗之间隔着 17 局没看过的
   出怪。「连开」是比「连空」更强的断言(它宣称刚刚接连开出),跨断口硬连比连空
   低估更容易误导。故 run 一律在断口处**停住**:只统计确实连续观测到的那一段。 */
function renderStreaks(){
  const h = S.hist;
  if (!h.length){ D.streakChips.innerHTML=''; return; }
  const runOf = fn => {
    let c = 0; const v = fn(h[0]);
    for (let i = 0; i < h.length; i++){
      // 与上一条记录之间若缺了格点 → 断口,连开到此为止(不跨洞硬连)
      if (i > 0 && Math.round((h[i-1].start - h[i].start) / T.ROUND) > 1) break;
      if (fn(h[i]) === v) c++; else break;
    }
    return c;
  };
  const num = h[0], numRun = runOf(r => r.n);
  const big = num.n >= 5, sizeRun = runOf(r => r.n >= 5);
  const odd = num.n % 2 === 1, parRun = runOf(r => r.n % 2 === 1);
  D.streakChips.innerHTML = `
    <span>连开 <b>${esc(num.key)} × ${numRun}</b></span>
    <span>${big?'大':'小'} <b>连 ${sizeRun}</b></span>
    <span>${odd?'单':'双'} <b>连 ${parRun}</b></span>`;
}

/* ═══════════ 渲染:出怪司历 + 盘感速读 ═══════════ */
/* 3.8.2 偏差着色改显著性判据:旧阈值 ±0.05pp 远低于抽样噪声(本窗样本量下
   1σ ≈ 0.3~1pp),等于永远着色 —— 极端时 1 局样本也顶着"+90.0"满权重红字。
   现按二项抽样波动 σ = √(p(1−p)/N)×100pp,|偏差| > 2σ 且 N ≥ CENSUS_MIN_N
   才着色(N 下限挡掉正态近似失效的冷启动段;50 局 ≈ 42 分钟)。
   偏差数字照常显示 —— 只有"这是信号还是噪声"的视觉暗示随样本量收放。 */
const CENSUS_MIN_N = 50;
function renderCensus(){
  const st = deriveStats();
  // 4.8.0:本行每次重算都整条覆写,故房号只能在此就地前置(不能交给 syncRoomScope)
  D.censusRange.textContent = (roomTag() ? roomTag() + ' · ' : '')
    + `近 24 小时 · ${st.total} 期 · 今日 ${st.todayTotal} 期`
    + (st.holes ? ` · ${st.holes} 处断口` : '');
  if (!st.total){
    // 3.8.2 零数据空态:此前空历史会给九个号各标"刚出"+ 大幅负偏差(gap=0 的
    // 语义误伤),新房/断流首屏读到的是错误结论 —— 现明示等待,不出伪统计。
    D.censusBody.innerHTML = `<tr class="census-empty"><td colspan="9">暂无出怪样本,等待第一局落地…</td></tr>`;
    D.quickRead.innerHTML = '';
    D.censusFootText.textContent = '近24h 0 期';
    return;
  }
  let html = '';
  for (let n=1; n<=9; n++){
    const prob = officialProbOr(n);
    const pct = st.counts[n]/st.total*100;
    const dev = pct - prob;
    const p01 = clampN(0.0001, prob/100, 0.9999);                       // 概率夹到 (0,1),防配置 0%/100% 除零
    const sigma = Math.sqrt(p01*(1-p01)/st.total)*100;                  // 抽样波动(百分点)
    const sig = st.total >= CENSUS_MIN_N && Math.abs(dev) > 2*sigma;    // 2σ 显著才着色
    const devCls = sig ? (dev > 0 ? 'dev-hot' : 'dev-cold') : '';
    const devTxt = (dev>0?'+':'') + dev.toFixed(1);
    const state = stateOf(st.gap[n], prob);
    const sp = S.spellByN[n] || {};
    // 4.4.0:跨断口时真值只知落在 [lo, hi],给区间而非单边(见 deriveStats 注)
    const gTxt = gapText(st, n);
    html += `<tr title="今日 ${st.today[n]} · 24h窗内最大连空 ${st.maxGap[n]}(逐连续段统计,不跨断口)${
      st.gapOpen[n] ? ` · 该号在本窗内从未出现,连空至少 ${st.gap[n]} 局(上不封顶,可能在窗口之前就出现过)`
      : st.gapMin[n] ? ` · 连空落在 ${st.gap[n]}~${st.gapHi[n]} 之间(中间有局未观测,判档按保守下界)` : ''}${
      st.holes ? ` · 本窗有 ${st.holes} 处断口` : ''}">
      <td><span class="c-id"><i class="c-dot" style="--e:var(--e${n})">${n}</i><b class="c-key">${esc(sp.spell_key||ELEM[n])}</b></span></td>
      <td class="c-strong">${st.counts[n]}</td>
      <td>${pct.toFixed(1)}%</td>
      <td>${prob.toFixed(1)}%</td>
      <td class="${devCls}">${devTxt}</td>
      <td>${st.today[n]}</td>
      <td class="c-strong">${gTxt}</td>
      <td>${st.maxGap[n]}</td>
      <td><span class="state-chip" data-s="${state.s}">${state.s}</span></td>
    </tr>`;
  }
  D.censusBody.innerHTML = html;

  // 盘感速读(驾驶舱右栈底):今日样本不足 12 期时退回 24h
  const useToday = st.todayTotal >= 12;
  const src = useToday ? st.today : st.counts;
  const tot = useToday ? st.todayTotal : st.total;
  let big=0, odd=0;
  for (let n=1;n<=9;n++){ if(n>=5) big+=src[n]; if(n%2===1) odd+=src[n]; }
  const p = v => tot ? Math.round(v/tot*100) : 0;
  const bar = (aP,bP,ca,cb) => `<div class="qr-bar"><i class="${ca}" style="width:${aP}%">${aP}%</i><i class="${cb}" style="width:${100-aP}%">${100-aP}%</i></div>`;
  D.quickRead.innerHTML = tot ? `
    <div class="qr-row"><em>大</em>${bar(p(big),100-p(big),'qr-a','qr-b')}<em>小</em></div>
    <div class="qr-row"><em>单</em>${bar(p(odd),100-p(odd),'qr-c','qr-d')}<em>双</em></div>` : '';
  D.censusFootText.textContent = `近24h ${st.total} 期 · 今日 ${st.todayTotal} 期${useToday?'':' · 样本:24h'}`;
}

/* ═══════════ 渲染:出怪印章 ═══════════ */
function renderResult(stamp = false){
  const r = S.hist[0];
  if (!r){
    D.resultSeal.className = 'result-seal is-empty';
    D.resultGlyph.textContent = '—'; D.resultNum.textContent = '';
    D.resultName.textContent = '等待出怪'; D.resultInfo.textContent = '';
    return;
  }
  D.resultSeal.className = 'result-seal';
  D.resultSeal.style.setProperty('--sc', `var(--e${r.n})`);
  D.resultSeal.dataset.n = r.n;
  D.resultGlyph.textContent = r.key;
  D.resultNum.textContent = r.n;
  D.resultName.textContent = `${r.name} · ${r.beast}`;
  D.resultInfo.textContent = `×${r.mult} · ${fmtClock(r.draw)}`;
  if (stamp && !matchMedia('(prefers-reduced-motion:reduce)').matches){
    D.resultSeal.classList.remove('stamp');
    void D.resultSeal.offsetWidth;
    D.resultSeal.classList.add('stamp');
  }
}

/* ═══════════ 灵机推演(主 2 · 防 2)—— 项目 B 集成预测(真实) ═══════════
   2.9.0:观测台不再本地模拟推演。主/防号位、命中记录、近窗命中率一律取自
   后端 /api/rooms/{alias}/prediction —— 即项目 B 的集成预测引擎(全量频率/近窗
   频率/指数衰减/一阶·二阶马尔可夫/未出场 六模型 Hedge 在线加权 + 频率锚定 + 探索位,
   按房间隔离、随每局在服务端有状态推进并落库)。前端只读展示,零重算、零副作用。 */
/* 3.3.5 卡片脉冲(新预测落地提示)—— refreshPrediction 与 SSE 同帧推送共用 */
function pulsePredictCard(){
  if (!D.predictCard || matchMedia('(prefers-reduced-motion:reduce)').matches) return;
  D.predictCard.classList.remove('is-fresh');
  void D.predictCard.offsetWidth;
  D.predictCard.classList.add('is-fresh');
}

/* 3.3.5 同帧判定:出怪 SSE 载荷捎带的 pred(后端 publish 前已结算,判定现成)。
   settled → 预置进 record(与 /prediction 的 {id,n,v} 同构,按 id 去重),使 ingest
   后首帧 renderPredict 直接命中 —— 珠与「主中/防中/未中」同帧,不再闪「⋯」;
   next → 新一局 main/guard/target 同帧翻新。predChase 照旧拉权威 /prediction
   (对账 + accuracy 刷新);降级路径(SSE 断/旧后端无此字段)行为与从前一致。*/
function applyPredPush(p){
  if (!p) return;
  try {
    const st = p.settled;
    if (st && st.id != null && st.v){
      const id = String(st.id);
      const top = S.pred.record[0];
      // 3.3.8 单调守卫:只接受比现有榜首更新的判定(等 = 重放,旧 = 乱序陈旧载荷,
      // 丢弃即幂等),保证 record 恒按 round_id 降序 —— 与 /prediction 契约一致。
      if ((!top || Number(id) > Number(top.id)) &&
          !S.pred.record.some(r => String(r.id) === id))
        S.pred.record = [{ id, n: Number(st.n), v: String(st.v) }, ...S.pred.record].slice(0, 40);
    }
    const nx = p.next;
    if (nx && nx.target){
      const t = Number(nx.target) || 0;
      if (t && t >= (S.pred.nextStart || 0)){   // 3.3.8 单调不回退:陈旧推演整体忽略
        if (t > (S.pred.nextStart || 0)) pulsePredictCard();
        S.pred.main  = (nx.main  || []).map(Number).filter(n => n >= 1 && n <= 9);
        S.pred.guard = (nx.guard || []).map(Number).filter(n => n >= 1 && n <= 9);
        S.pred.why   = String(nx.why || '');   // 引擎自解释(连败换血落款)与号位同帧同守卫
        S.pred.nextStart = t;
      }
    }
  } catch { /* 载荷异常不致命:predChase 权威对账兜底 */ }
}

async function refreshPrediction(alias){
  alias = alias || S.alias;
  if (!alias) return;
  try {
    const d = await api(`/api/rooms/${encodeURIComponent(alias)}/prediction`);
    if (S.alias !== alias) return;                     // 期间换房 → 丢弃
    const prevTop = S.pred.record?.[0]?.id;
    // 权威对账信息(判定记录 / accuracy)恒更新 —— 与「下一局预测」是两码事。
    // ens(集成概率)属 pending 载荷:孤儿空响应里恒为 [](实查 _build_prediction),
    // 故随 main/guard 一起受守卫保护,避免保留旧号时 tooltip 概率被抹空。
    S.pred.record = (d.record || []).filter(r => r && r.v);
    S.pred.accuracy = d.accuracy || null;
    // 4.2.0:后端在 basic 档裁掉了 main/guard/ens/target,并置 vipLocked。
    // 这里如实记录 —— renderPredict 据此走「VIP 可见」锁态,而不是误显「等待数据」
    // (那会让用户以为系统坏了,是最糟的产品表达)。
    S.pred.vipLocked = !!d.vipLocked;
    /* 3.3.9 预测号消失修复(真机 HAR 实证):后端 pending 被孤儿局占住时,_build_prediction
       回 main:[] / target_round_id:null(孤儿过滤:pend+50001<=latest)。旧版在此**无条件**
       用响应覆盖 main/guard/nextStart → 把在手的有效预测抹成空 → renderPredict 落到「等待
       数据」占位,预测号凭空消失(HAR 大量 size≈1781 的 target=null 响应实证)。
       守卫(与 applyPredPush 单调守卫同构):空响应 / 比在手更旧的 target 不得覆盖有效预测;
       仅当①响应有有效 main 且 target 不倒退,或②手里本就没有有效预测(引导局/首帧,照旧
       兜底、维持旧「等待数据」语义)时才写入。权威预测稍后经 pred-updated 推送/对账带回。 */
    const nm  = (d.main  || []).map(Number).filter(n => n >= 1 && n <= 9);
    const ng  = (d.guard || []).map(Number).filter(n => n >= 1 && n <= 9);
    const tgt = Number(d.target_round_id) || 0;
    // 3.3.9 对称滤(纵深防御):后端孤儿过滤的 latest 取自 Redis 快照,而
    // /history 直读 DB —— GameHistory 补齐的局曾有「入库→快照跟上」的空窗
    // (后端 3.3.9 轻量补推已同步快照,此处兜多副本竞态等残余),空窗内
    // /prediction 可能漏滤、回一个按本地实录已死(目标已过 ≥1 局)的 target。
    // 按后端同一判据(+50001<=latest)以本地 hist[0] 为 latest 对称过滤:
    // 死响应视同空响应 —— 不得覆盖在手预测,也不得在引导期写入死号。
    const respDead  = tgt > 0 && S.hist.length > 0 &&
                      (tgt + T.ROUND <= S.hist[0].start);
    const respGood  = nm.length > 0 && !respDead;
    const respStale = tgt && S.pred.nextStart && tgt < S.pred.nextStart;
    const haveGood  = S.pred.main.length > 0 && S.pred.nextStart > 0;
    // 3.3.9 保留上界(与后端铁孤儿判据 pend+50001<=latest 对称):在手预测的目标局
    // 比最新落地局旧一整局以上 = 该预测已死(其判定早经 record 定案),空响应允许
    // 清成「等待数据」—— 否则预测器长期停摆时会无限期挂着古老号(标签"本局 № 古局"、
    // 九法阵残留死主/防标)。「目标==刚落这局」的判定过渡态(3.3.7)不满足此条件,
    // 依然受守卫保护;respGood 已含 !respDead,故本分支实际只放行空清。
    const heldOrphan = S.pred.nextStart > 0 && S.hist.length > 0 &&
                       (S.pred.nextStart + T.ROUND <= S.hist[0].start);
    if ((respGood && !respStale) || !haveGood || heldOrphan){
      S.pred.main  = respDead ? [] : nm;
      S.pred.guard = respDead ? [] : ng;
      S.pred.ens   = respDead ? [] : (d.ens || []);
      S.pred.why   = respDead ? '' : String(d.why || '');
      S.pred.nextStart = (respDead ? 0 : tgt) || ((S.hist[0]?.start || 0) + T.ROUND);
    }   // 否则:手里有有效(且未过期)预测而响应空/旧/死 → 保持不动,修复消失
    if (S.pred.record?.[0]?.id !== prevTop) pulsePredictCard();   // 新预测落地:卡片脉冲提示
    renderPredict();
  } catch { /* 后端不可达时保持上一次展示,轮询/换房自愈 */ }
}
/* 4.7.5 推演卡文案收束:移除 4.6.0 加的回测溯源角标(正文里那个按 accuracy.replay
   拼出来的条数后缀,与 title 里分列实盘/回测条数的那句)。命中率行现在**恒为**
   单一形态 `近N局 主中X · 防中Y` —— 与 4.4.x 逐字节相同,不再随 replay 分叉。

   ── 改这一处时必须同时知道的三件事(勿逐条回退)──────────────────────────
   1) 后端契约**不动**:pred_replay 照常按生产同一条代码路径因果重跑历史、补算行
      照常带 source='replay' 落库,/prediction 的 accuracy 照常回 replay 字段、
      record 照常回 s 字段。移除的只是前端这层展示,运维/管理台/单测的溯源能力
      分毫未减(后端 README §10.1)。要恢复角标,只需在下面两个函数里重新读
      acc.replay 拼字符串,无需碰后端一行。
   2) 「上局开X · 主中/防中/未中」徽标的实盘过滤(`r.s !== 'replay'`,见 renderPredict)
      **保持不变** —— 那是战绩,冒领是另一回事,和本行的统计量口径正交。
      本轮**只动文案,不动那道过滤**。
   3) 由此 predStatText 不再依赖 acc.replay ⇒ rgPredToken 的指纹里那一位随之作废,
      已同步换成真正被渲染的 main/cover(见该函数注释),否则会出现「渲染内容变了
      指纹没变」的漏刷与「补算扫描跑一轮就白重绘一次」的空转。 */
function predStatText(acc){
  if (!acc || !acc.n) return '';
  const g = Math.max(0, acc.cover - acc.main);
  return `近${acc.n}局 主中${acc.main} · 防中${g}`;
}
function predStatTitle(acc){
  if (!acc || !acc.n) return '';
  let t = `近${acc.n}局实测:主命中 ${acc.main}/${acc.n}=`
    + `${(100 * acc.main / acc.n).toFixed(0)}%,主+防 ${acc.cover}/${acc.n}=`
    + `${(100 * acc.cover / acc.n).toFixed(0)}%(盲选基线 22%/44%,仅供参考)`;
  if (acc.window && acc.n < acc.window) t += `;窗口 ${acc.window} 局,其余局无判定`;
  return t;
}
/* 4.9.3 窗口缺口注脚:n < window 时,把「为什么不是满窗」用**可见正文**说清。
   此前这句话只存在于上面 predStatTitle 的 title 悬浮里 —— 触屏无 hover,手机
   (本产品主场,4.3.7 免责声明轮已确立此结论)上等于没写;用户看到「近44局」
   而 24h 序列明明是满的,只能得出「系统坏了」的结论 —— 这正是本轮工单的直接
   来源。措辞只陈述事实(窗口多大、几局暂无判定),不涉任何口径溯源(4.7.5 的
   文案收束不变式:predStatText/predStatTitle 一个字节未动,本注脚是**独立元素**
   #predGap,常态满窗时恒隐藏,不新增命中率行自身的形态)。
   「暂无判定」的成因(冷段/停播段/结构性缺口)在补算秒级快道(4.9.3 后端)生效
   后只剩后两者 —— 即真实世界里确实无法判定的局;此时如实说明就是天花板。 */
function predGapText(acc){
  if (!acc || !acc.n || !acc.window || acc.n >= acc.window) return '';
  return `窗口${acc.window}局 · ${acc.window - acc.n}局暂无判定`;
}
function renderPredGap(acc){
  if (!D.predGap) return;
  const t = predGapText(acc);
  D.predGap.textContent = t;
  D.predGap.hidden = !t;
}

/* 4.2.0:命中率/命中串的单独渲染 —— 锁态与常态共用。
   basic 档拿得到近 N 局的 accuracy,这是它花钱前唯一能验证"准不准"的凭据。 */
function renderPredStatsOnly(){
  const acc = S.pred.accuracy;
  if (D.predVerdict) D.predVerdict.hidden = true;
  if (!D.predStats) return;
  if (acc && acc.n){
    D.predStats.textContent = predStatText(acc);
    D.predStats.title = predStatTitle(acc);
    renderPredGap(acc);
  } else { D.predStats.textContent = ''; renderPredGap(null); }
}

function renderPredict(){
  if (!D.predMain) return;
  const H = S.hist, p = S.pred;
  /* 4.2.0 basic 档锁态:主/防号位显示锁形占位,**但命中率与近 N 局命中串照常渲染** ——
     那是 basic 档的真实价值,也是最强的转化素材:「它准不准你自己看得见,
     就是不告诉你下一局」。后端已把 main/guard/ens 裁空,前端这里只是把
     「等待数据」的空态换成语义正确的「VIP 可见」。 */
  if (isBasic() && p.vipLocked){
    D.predMain.innerHTML = D.predGuard.innerHTML =
      '<i class="p-chip is-lock" title="下一局预测参考(主 2 码 · 防 2 码)—— 开通九法VIP可见">?</i>'
      + '<i class="p-chip is-lock" title="下一局预测参考(主 2 码 · 防 2 码)—— 开通九法VIP可见">?</i>';
    D.predRound.textContent = 'VIP 可见';
    D.predictCard.dataset.vip = 'lock';
    if (D.predVipBar) D.predVipBar.hidden = false;
    renderPredStatsOnly();
    return;
  }
  if (D.predictCard) delete D.predictCard.dataset.vip;
  if (!H.length || !p.main.length){
    D.predMain.innerHTML = D.predGuard.innerHTML =
      '<i class="p-chip is-wait">–</i><i class="p-chip is-wait">–</i>';
    D.predRound.textContent = '等待数据';
    D.predVerdict.hidden = true; D.predStats.textContent = '';
    renderPredGap(null);
    return;
  }
  if (!p.nextStart) p.nextStart = H[0].start + T.ROUND;
  markBoardPrediction();                               // 推演更新即刻联动九法阵
  const pct = n => (Array.isArray(p.ens) && p.ens[n-1] != null)
    ? ` · ${(p.ens[n-1]*100).toFixed(1)}%` : '';
  const chip = n => {
    const sp = S.spellByN[n] || {};
    return `<i class="p-chip" style="--e:var(--e${n})" title="${esc(sp.spell_key || ELEM[n])} · ×${sp.multiplier ?? '—'}${pct(n)}">${n}</i>`;
  };
  D.predMain.innerHTML  = p.main.map(chip).join('');
  D.predGuard.innerHTML = p.guard.map(chip).join('');
  /* 4.9.6:引擎自解释行(原 #predWhy)已不再上屏 —— 原注释所据的「why 只随熔断局
     出现、常态为空」经实测不成立(实配下 92.3% 的局非空、中位 85 字),几何代价与
     完整实测数据见 index.html 该元素原位的注释。S.pred.why 仍照常收下(见 S 的
     初始化注),只是不渲染;渲染层这里一行都不该有。 */
  refreshPredictLabel();
  /* 2.9.5:「上局开 X」的号一律取实录管线 S.hist[0](与序列/战况同源)。
     此前取 p.record[0].n —— 那是预测结算管线(predictions 表回填)里最新
     一条,与实录管线并不同步:换局瞬间 flushIngest 先用旧 record 渲染、
     再异步 refreshPrediction;结算回填滞后或轮询兜底(出怪+2.8s 定点拉取)
     时 record[0] 仍停在上一局 → 卡片比序列落后一局("上局开2却显示开1")。
     现按 round_id 把预测记录对齐到实录同一局:号永远与序列一致。
     3.3.6 徽标只有一种形态 = 完整判定「上局开 X · 主中/防中/未中」:
     判定未到手时整枚隐藏,绝不显示「⋯」等任何中间态;沿用旧局判定则是
     2.9.5 修过的张冠李戴,禁走回头路。3.3.7 起"未到手"只剩一种情形 ——
     该局根本没有预测(引导局/停机档):有预测在手即本地同帧判定,不存在等待。 */
  const lastRound = H[0];
  /* 4.6.0:徽标只认**实盘**判定。补算行(r.s==='replay')是回测口径 —— 那一局
     系统当时并没有真的下过注,把它显示成「上局开5·主中」就是在冒领战绩。
     跳过它 ⇒ 落到既有的「该局没有预测 ⇒ 整枚隐藏」状态,不新增第三种形态
     (3.3.6 定下的「徽标只有一种形态」不变式因此保持)。
     4.7.5:命中率行的溯源角标已移除(见 predStatText 头注),**本过滤不受影响** ——
     角标是文案取舍,这里是「不冒领战绩」的硬约束,两者互不承接。删掉这行过滤
     会让补算判定直接顶着「上局开X·主中」出现在卡面上,那是本轮明确不做的事。 */
  let rec = lastRound && p.record.find(
    r => String(r.id) === String(lastRound.id) && r.s !== 'replay');
  /* 3.3.7 本地即时判定(通用同帧兜底):权威记录未到、但手里恰好持有「目标局
     == 刚落这局」的预测(main/guard 于上局结算后经推送/追拉而来)时,判定只是
     一次三选一包含判断 —— 规则与后端 fill_prediction_outcome 逐字一致(主优先),
     输入(号 + 两组号位)同源同值 ⇒ 结论必然一致,零分歧面。由此判定不再依赖
     SSE 载荷或追拉时序:旧版 worker(载荷无 pred)、轮询降级、事件乱序一律
     同帧成型;predChase 稍后带回的权威记录同值覆盖,肉眼零变化。目标局不
     匹配(引导局/预测停机档/持仓过期)则绝不猜,徽标保持隐藏。 */
  if (!rec && lastRound && p.main.length &&
      String(p.nextStart) === String(lastRound.id)){
    const n = Number(lastRound.n);
    rec = { v: p.main.includes(n) ? 'main' : (p.guard.includes(n) ? 'guard' : 'miss') };
  }
  if (rec){
    D.predVerdict.hidden = false;
    D.predVerdict.dataset.v = rec.v;
    D.predVerdict.textContent = `上局开 ${lastRound.n} · ${
      rec.v === 'main' ? '主中' : rec.v === 'guard' ? '防中' : '未中'}`;
    D.predVerdict.title = '';
  } else D.predVerdict.hidden = true;
  const acc = p.accuracy;
  if (acc && acc.n){
    D.predStats.textContent = predStatText(acc);
    D.predStats.title = predStatTitle(acc);
    renderPredGap(acc);
  } else {
    /* 4.6.0:record 现已与 accuracy 同源按局锚定(db.prediction_records),
       故此兜底不会再拿几天前的旧记录算出一个假的「近N局」。它只在后端未回
       accuracy 时才可能走到,保留作纵深。4.9.3:此路窗口未知,缺口注脚恒藏。 */
    renderPredGap(null);
    const win = p.record.slice(0, PRED_EVAL);
    if (win.length){
      const m = win.filter(x => x.v === 'main').length;
      const g = win.filter(x => x.v === 'guard').length;
      D.predStats.textContent = `近${win.length}局 主中${m} · 防中${g}`;
      D.predStats.title = `项目 B 集成预测:主命中 ${m}/${win.length},防命中 ${g}/${win.length}(预测仅供参考)`;
    } else D.predStats.textContent = '';
  }
}

/* 推演目标局标签相位化(2.5.6 时机审计):推演在上局结果入账瞬间生成,
   彼时目标局未开始,称「下一局」;目标局一旦开始(占每局约 42/50 秒),
   顶部「当前局」面板与本卡显示同一局号,原先仍称「下一局」互相矛盾。
   现由 tick()(200ms)按相位翻面:未开始 →「下一局」,已开始 →「本局」;
   文本未变时零 DOM 触碰。数据断流超过一局时目标局已成历史,以「滞后」
   徽章为准,标签保持「本局」,重连补洞后自愈。 */
function refreshPredictLabel(){
  if (!D.predRound || !S.pred.nextStart) return;
  const txt = (S.pred.nextStart <= curStart(nowC()) ? '本局' : '下一局')
            + ' № ' + dayNo(S.pred.nextStart);
  if (D.predRound.textContent !== txt) D.predRound.textContent = txt;
}

function renderAll(){
  renderIdentity(); renderBoard(); renderRoad(); renderTrend();
  renderStreaks(); renderCensus(); renderResult(); renderPredict();
}

/* ═══════════ 添加直播间(免费:加入名录并立即观测) ═══════════ */
/* 容量闸:名录满 MAX_ROOMS 间时,「＋ 添加直播间」不再放行并说明原因。
   注意「已在名录的房号」不占新名额 —— 提交时命中 exists 只是切房,应当放行。 */
const ROOMS_FULL_TIP = `名录已满(上限 ${MAX_ROOMS} 个直播间)—— 请先删除不再关注的直播间`;
function roomsFull(){ return S.rooms.length >= MAX_ROOMS; }
/* 不用 disabled:触屏没有 tooltip,置灰按钮无处解释「为什么点不动」。
   保持可点,点下去给一条明白话的 toast —— 顺带用 data-full 留出样式钩子。 */
function syncAddRoomBtn(){
  const b = D.addRoomOpen; if (!b) return;
  const full = roomsFull();
  b.toggleAttribute('data-full', full);
  b.title = full ? ROOMS_FULL_TIP : '添加一个直播间到名录并立即观测';
}

/* ═══ 5.0.3:「添加直播间」新手态(名录 ≤1 房)═══
   判定与消解的单一真源。body[data-nudge] 是唯一输出,四处视觉强化(名录内引导条 /
   ☰ 徽点 / 图标轨小钮升 brand / 弹层被关后的兜底)全部由 CSS 按此属性门控 ——
   不在四个地方各写一份显隐逻辑。
   · 为什么判 rooms.length<=1 而不是识别「预置房」:后端 _live_room_card 逐字段核过
     不下发预置标记,first_login_room 也不经 /api/auth/session 下发,前端结构上造不出
     该判定;且「单房用户不知道能多房对比」与那个房是谁加的无关 —— 对自加单房的
     用户引导同样成立,不撒谎。
   · 失败≠空(5.0.2 同款纪律):名录从未成功拉到(S.roomsFetchedAt===0,断网/后端
     异常/401)时不出任何"添加"引导 —— 此时引导添加是误导,只走既有的诚实失败提示。
   · 自动消解:达 ≥2 房即落 KEY.addNudge —— 用户已用行动证明学会,此后哪怕删回
     单房/删空也永不再见(空名录另有不受本键约束的引导兜底,见 KEY.addNudge 注)。
   · 调用点:renderRail(名录一切变化的汇聚点)+ refreshLiveRooms(其 3.9.4
     「交互中不重绘」守卫会跳过 renderRail,而本函数只 toggle body 属性、不碰
     roomList DOM、不夺焦点,必须在守卫之外无条件执行,否则别的窗口加了房、
     本窗口悬停名录时新手态不撤)。
   · 复审补 !roomsFull():本引导是三处添加入口里唯一没查容量闸的(syncAddRoomBtn
     与 submitAddRoom 都查),口径必须一致。默认 MAX_ROOMS=50 时单房恒不满、本条
     不可达;但后端 userauth.room_max 是管理台可改字段(ge=1)且**要求与前端
     MAX_ROOMS 同值**(settings.py 296 注),真按 1 部署时,不查闸就会用一个醒目
     引导去许诺后端硬拒(400 rooms_full)的事 —— 正是本项目一贯拒绝的死控件。 */
function syncNudge(){
  if (S.roomsReady && S.rooms.length >= 2 && !store.get(KEY.addNudge))
    store.set(KEY.addNudge, '1');                       // 尽力而为:存储被禁时静默,本次会话仍按属性即时撤
  const on = S.roomsReady && S.roomsFetchedAt > 0
          && S.rooms.length <= 1 && !roomsFull() && !store.get(KEY.addNudge);
  document.body.toggleAttribute('data-nudge', on);
}
/* 5.0.3:空名录主舞台引导卡。空名录既有引导(dataBoot/删空自动弹层 + 侧栏空引导卡)
   在两个形态上是漏洞:① 手机/平板(≤1060)侧栏是收起抽屉,弹层被 ×/Esc/点遮罩关掉后
   主舞台只剩空骨架,引导卡锁在看不见的抽屉里,唯一入口是无语义的 ☰(实测截图为证);
   ② 驾驶舱 1240–1719 图标轨,空引导卡被 CSS 整块隐藏(5.0.2 定案),入口只剩 64px 轨上
   10px 竖排小字钮。本卡固定层居中、常驻到名录非空为止,z:29 —— 在 topbar(30)/
   rail(40)/railVeil(35)/modal(80)/veil(90)/authGate 之下:抽屉、添加弹层、登录门照常
   盖过它;外壳 pointer-events:none 只有卡体可点,不挡底下任何交互。显示条件与
   data-nudge 刻意不同:**不看消解键**(名录空时无事可做,引导就是内容本身),但同守
   「失败≠空」(fetchedAt>0 才显示)。视觉承接 rg-guard 的「印章+标题+一句话+按钮」
   语言;按钮转发 #addRoomOpen 同一套闸,locked 态同受锁(app.css 同名节)。
   5.0.3 复审补:条件含 !S.alias —— 空名录下经搜索框直接观测某房是既有能力
   (doSearch→loadRoom,房不入名录,rooms 恒 0),彼时数据满屏在放,本卡不该盖在
   活数据中央;同理服务端清空名录而本地仍在播时也保持退让(侧栏空引导卡照常)。
   代价是 alias 的两个生命周期节点必须补调本函数:loadRoom 钉 alias 处(卡即隐)
   与 removeCustomRoom 清 alias 处(卡即显)—— 后者的既有语序是 renderRail 先于
   S.alias='',仅靠 renderRail 内的那次同步会在删空场景永远读到旧 alias。 */
function syncStageEmpty(){
  const el = D.stageEmpty; if (!el) return;
  el.hidden = !(S.roomsReady && S.roomsFetchedAt > 0
             && S.rooms.length === 0 && !S.alias);
}

function loadMyRooms(){
  try {
    const arr = JSON.parse(store.get(KEY.myRooms) || '[]');
    return Array.isArray(arr) ? arr.map(String).filter(a => /^\d{2,12}$/.test(a)) : [];
  } catch { return []; }
}
function saveMyRooms(list){ store.set(KEY.myRooms, JSON.stringify(list)); }
/* 把一个自添房号并入 S.rooms(占位昵称,profile 异步补齐后按当前搜索词重绘)——
   submitAddRoom 与 mergeMyRooms 共用;与官方名录按 alias/roomId 双键去重。
   2.6.3:入名录不再依赖「写 storage → mergeMyRooms 回读」的往返 —— 存储被禁
   (写入静默失败)时会话内加房曾因此不进名录,现直接入列、持久化只作尽力而为。 */
function upsertCustomRoom(alias){
  if (S.rooms.some(r => String(r.alias) === alias || String(r.roomId) === alias)) return false;
  S.rooms.push({ alias, roomId: alias, nickname: '房间 ' + alias, avatar: '', custom: true });
  api(`/api/live-rooms/${encodeURIComponent(alias)}/profile?switch=1`, { timeout: 12000 }).then(d => {
    const p = d.profile || {};
    if (p.exists === false) return removeCustomRoom(alias);   // 2.6.14:确认不存在 → 清退
    const it = S.rooms.find(r => r.custom && String(r.alias) === alias);
    if (!it) return;
    if (p.nickname) it.nickname = p.nickname;
    if (p.avatar) it.avatar = p.avatar;
    // 2.9.4:记下后端解析出的真实房间号 —— 仅用于双键去重与搜索命中,不上名录展示
    if (p.roomId && String(p.roomId) !== alias) it.roomId = String(p.roomId);
    renderRail(D.roomSearch.value);
    if (!p.avatar) lateFillProfile(alias);          // 2.6.9:代理慢,首包占位 → 轮询补挂
  }).catch(e => {
    /* 5.0.7:切房准入 —— 后端不再监控这个房(名录与后台注册表分叉的残影,
       典型来源是 localStorage 里跨设备/跨部署带过来的旧房号)。清掉它,
       别让轨道上留一张点进去永远空白的卡;其余失败维持旧的轮询补挂。 */
    if (['room_not_monitored', 'not_live_now', 'room_unresolved']
        .includes(e?.data?.error || ''))
      return removeCustomRoom(alias, { message: e.data.message });
    /* live_unverifiable = 上游问不到,**不是**「这房没了」—— 绝不能据此清卡
       (与后端「问不到 ≠ 没开播」同一条戒律)。留着卡,下一拍再试。 */
    lateFillProfile(alias);
  });
  return true;
}

/* 2.6.9:自添房资料「晚到回填」—— 代理慢/瞬断时 profile 先回占位放行页面,
   模拟层后台仍在拉取(成功即落缓存)。这里按 3.5s/8s/15s/32s 最多补问四次(末档触发上游全新重试,自愈瞬断),
   一旦拿到头像或真名:更新名录条目并重绘;若正是当前房间,同步刷新顶部主播区。
   官方名录房自带头像不会进入此路径;三问皆空则安静作罢,保持占位。 */
function lateFillProfile(alias, tryIdx = 0){
  const delays = [3500, 8000, 15000, 32000];  // 第四档落在双层失败缓存过期后 → 全新上游重试
  if (tryIdx >= delays.length) return;
  setTimeout(async () => {
    const it = S.rooms.find(r => String(r.alias) === alias);
    if (it && it.avatar) return;                    // 已由其他路径补到
    try {
      const d = await api(`/api/live-rooms/${encodeURIComponent(alias)}/profile`);
      const p = d.profile || {};
      if (p.exists === false) return removeCustomRoom(alias);   // 2.6.14:晚到确认不存在 → 清退
      const got = p.avatar || (p.nickname && p.nickname !== alias && p.nickname !== '房间 ' + alias);
      if (got){
        if (it){
          if (p.nickname) it.nickname = p.nickname;
          if (p.avatar)   it.avatar   = p.avatar;
          renderRail(D.roomSearch.value);
        }
        if (S.alias === alias && S.profile){
          if (p.nickname) S.profile.nickname = p.nickname;
          if (p.avatar)   S.profile.avatar   = p.avatar;
          renderIdentity();
        }
        if (p.avatar) return;                       // 头像到手即收工;仅有名则继续等图
      }
    } catch (_){}
    lateFillProfile(alias, tryIdx + 1);
  }, delays[tryIdx]);
}
function mergeMyRooms(){
  for (const alias of loadMyRooms()) upsertCustomRoom(alias);
}
/* 5.0.8 切换即添加(搜索框入口):登录态下在名录搜索框敲一个**不在名录**的房号。
   旧路径直接 loadRoom → 明细端点 403 room_not_bound → 「不在你的名录中,请先添加」。
   未启用登录时搜索框是「看而不加」(房不入名录,5.0.3 注),那条语义原样保留;
   登录态下明细端点本就只放行名录内的房,「看而不加」在结构上不存在,唯一能兑现
   用户意图的做法就是先加后看 —— 走与「＋ 添加直播间」完全相同的后端阶梯
   (/api/monitor/add:在册直接放行;否则查核验台账;再否则打一次 roomStatus,
   在播即绑定,未开播 / 号不存在 / 问不到各说各的真话)。
   与 submitAddRoom 的两处刻意区别:
     · 名额先拦(roomsFull)—— 满额时连上游都不打,直接说满;
     · 网络类失败**不做乐观入名录**:那会造一张服务端没有绑定的残影卡
       (loadRoom 的 room_not_bound 分支就是在善后这种卡),失败就只提示。
   落盘序与 submitAddRoom 同:后端应答之后才 saveMyRooms(被拒的房绝不残留)。
   期间用户又切了别的房(S.loadSeq 变化)→ 放弃打开,不劫持他后来的选择;
   绑定若已落是无害的:它本就是用户刚才敲进来的房。 */
async function addAndOpenRoom(alias){
  alias = String(alias).trim();
  if (!/^\d{2,12}$/.test(alias)) return toast('请输入房间号,或从名录中选择主播');
  if (roomsFull()) return toast(ROOMS_FULL_TIP);
  const seq = ++S.loadSeq;                          // 与 loadRoom 同一代际:让在途切房作废,也让本次可被后来者作废
  stopRealtime();                                   // 与 loadRoom 同款:切房期间停旧房实时;失败后按 S.hist 恢复
  showVeil('正在核实开播状态', `直播间 ${alias} 不在名录,开播中将自动加入并打开`);
  try { await api(`/api/monitor/add?room=${encodeURIComponent(alias)}`, { timeout: 15000 }); }
  catch (e){
    if (seq !== S.loadSeq) return;
    hideVeil();
    toast((e && e.data && e.data.message) || (e && e.data && e.data.error) || '添加失败,请稍后重试');
    if (S.hist.length) startRealtime();             // 原来的房仍在看 → 恢复其实时
    else if (S.rooms.length) loadRoom(String(S.rooms[0].alias), { explicit: true });
    return;
  }
  if (seq !== S.loadSeq) return;
  const mine = loadMyRooms();
  if (!mine.includes(alias)){ mine.push(alias); saveMyRooms(mine); }   // 持久化尽力而为(存储被禁时静默)
  upsertCustomRoom(alias); renderRail(D.roomSearch.value);
  toast(`直播间 ${alias} 已自动加入名录,正在打开`);
  loadRoom(alias, { explicit: true, bindTry: 1 });   // 绑定已落;bindTry=1 防同房再补绑打转
}
async function submitAddRoom(e){
  e.preventDefault();
  const alias = normDigits(D.addRoomInput.value);
  D.addRoomMsg.textContent = '';
  if (!/^\d{2,12}$/.test(alias)) return void (D.addRoomMsg.textContent = '请输入正确的房间号');
  const exists = S.rooms.some(r => String(r.alias) === alias || String(r.roomId) === alias);
  if (!exists && roomsFull())   // 已在名录的房号只是切房、不占新名额,故只拦新增
    return void (D.addRoomMsg.textContent = ROOMS_FULL_TIP);
  if (!exists){
    /* 2.6.14:入名录前先校验房号 —— 服务器对「页面 404 + roomStatus 查无此房」双重
       确认后返回 exists:false(终态)。不存在:弹窗内联提示、留在原地方便改号;
       校验通道不畅(离线/慢)不阻断,放行走原有乐观添加,由晚到回填/清退兜底。 */
    if (S.addChecking)
      return void (D.addRoomMsg.textContent = '上一次校验仍在进行,请稍候…');   // 2.6.18:取消后窗口内重提交,给反馈而非静默吞掉
    S.addChecking = true;
    const tk = S.addToken | 0;                          // 2.6.17:取消令牌 —— 校验期间弹窗被关(Esc/×/遮罩)即失效
    D.addRoomMsg.textContent = '正在校验房间号…';
    try {
      for (let t = 0; t < 2; t++){                      // 首询 + 1.6s 后复询:覆盖服务器 404 判定窗口
        const d = await api(`/api/live-rooms/${encodeURIComponent(alias)}/profile`, { timeout: 6000 });
        if (tk !== (S.addToken | 0)) return;            // 用户已取消 → 静默放弃,不添加/不提示/不切房
        if (d.profile?.exists === false)
          return void (D.addRoomMsg.textContent = '该房间号不存在,请核对后重试');
        if (d.profile?.avatar || d.profile?.nickname !== alias) break;   // 已有真资料,无需复询
        if (t === 0) await sleep(1600);
      }
      D.addRoomMsg.textContent = '';
    } catch (_){ D.addRoomMsg.textContent = ''; }
    finally { S.addChecking = false; }
    if (tk !== (S.addToken | 0)) return;                // 兜底:异常/复询路径归来同样尊重取消
    if (roomsFull())                                    // 校验期间(可达数秒)名录可能被别处填满 —— 落库前复查
      return void (D.addRoomMsg.textContent = ROOMS_FULL_TIP);
    // 2.9.1:显式告知后端「长期监控此房」—— 即刻拉起抓取线程并写入配置 room_ids
    // (重启后名录一致);await 保证 loadRoom 首拉历史时命中「等首批数据」宽限。
    // 3.0:后端有准入限制,被拒时展示后端给出的提示并**中止添加**
    // (不入名录、不提示成功、不关弹窗),而非静默吞掉。
    // 5.0.7 两处修正:
    //   ① 持久化挪到后端应答**之后**。旧序是「先 saveMyRooms 再问后端」,一旦被拒
    //      就直接 return —— 但房号已经落进 storage,mergeMyRooms 每 30s 把它当
    //      「乐观自添房」塞回名录,显示成一个永远没数据的「房间 X」,且删不干净。
    //   ② 超时 5s → 15s。后端新增的开播核验要打一次上游 roomStatus(外层天花板 8s),
    //      5s 会在后端还没定谳时先抛超时 → 落进「网络瞬断」分支照常入名录,
    //      而后端那边可能正要拒 —— 前后端说法当场分叉。
    D.addRoomMsg.textContent = '正在核实开播状态…';
    try { await api(`/api/monitor/add?room=${encodeURIComponent(alias)}`, { timeout: 15000 }); }
    catch (e){
      if (e?.status === 400 || e?.data?.ok === false){
        D.addRoomMsg.textContent = e?.data?.message || e?.data?.error || '添加失败,请稍后重试';
        return;
      }
      /* 网络瞬断等非业务失败:维持旧行为(尽力而为继续,janitor 会兜底) */
    }
    D.addRoomMsg.textContent = '';
    const mine = loadMyRooms();
    if (!mine.includes(alias)){ mine.push(alias); saveMyRooms(mine); }   // 持久化尽力而为(存储被禁时静默)
    upsertCustomRoom(alias);                                             // 会话内立即入名录,不依赖存储回读
    renderRail(D.roomSearch.value);
  }
  closeModal(D.addRoomModal);
  D.addRoomForm.reset();
  toast(exists ? `直播间 ${alias} 已在名录,正在打开` : `已添加直播间 ${alias}`);
  loadRoom(alias, { explicit: true });   // 用户显式添加并打开 → 抢占
}

/* 名录删除(2.9.1 通用化):适用于名录内**所有**房间(配置房与自添房一视同仁)。
   ① 通知后端 /api/monitor/remove —— 停掉该房抓取线程并从配置 room_ids 移除,
      保证删除「真正生效」:刷新/重启后不再回到名录(库中历史数据无损保留);
   ② 出名录、清持久化与快照;③ 删的是当前房 → 切到首个剩余房;名录删空 →
      停实时层并引导添加。也承接 2.6.14 的「确认不存在自动清退」路径。 */
function removeCustomRoom(alias, { notify = true, message } = {}){
  alias = String(alias);
  api(`/api/monitor/remove?room=${encodeURIComponent(alias)}`).catch(() => {});  // 尽力而为;后端不可达时本地照删
  const i = S.rooms.findIndex(r => String(r.alias) === alias);
  const removed = i >= 0, wasCurrent = S.alias === alias;
  if (removed) S.rooms.splice(i, 1);
  saveMyRooms(loadMyRooms().filter(a => a !== alias));   // 存储过滤保留:兜底清理游离持久化
  dropSnapshot(alias);                                   // 一并清理该房本地快照
  if (store.get(KEY.room) === alias) store.remove(KEY.room);
  if (!removed && !wasCurrent) return;                   // 2.6.17:重入幂等 —— 已删过且非当前房,静默(防迟到轮询重复 toast)
  renderRail(D.roomSearch.value);
  if (notify) toast(message || `直播间 ${alias} 不存在,已从名录移除`);
  if (wasCurrent){
    // 3.9.3:必须 explicit(claim)—— 删的是当前房时租约**仍指向已删房**,若只 renew
    //   会被回 room_switched 指回已删房 → 跟随加载必 403 → 页面卡死无实时(实测复现)。
    if (S.rooms.length){ loadRoom(String(S.rooms[0].alias), { explicit: true }); return; }
    stopRealtime();                                      // 名录已空:停时钟/SSE/轮询,防已删房被在途请求复活
    S.alias = '';
    syncStageEmpty();  // 5.0.3 复审:上面的 renderRail 跑在本行之前、读到的还是旧 alias —— 清空后必须补一次同步,空舞台卡才会在删空场景现身(含「搜索观测的房确认不存在」经本分支清退的路径)
    setConn('idle', '未监控');
    toast('名录已空,可点「＋ 添加直播间」继续监控');
    openModal(D.addRoomModal, D.addRoomInput);
  }
}
function dropSnapshot(alias){
  store.remove(KEY.snap + alias);
  try {
    const idx = JSON.parse(store.get(KEY.snapIdx) || '{}');
    if (alias in idx){ delete idx[alias]; store.set(KEY.snapIdx, JSON.stringify(idx)); }
  } catch {}
}

/* 2.6.15:名录删除的两步确认 —— 首次点 × 转为「确认删除」胶囊,3s 无操作自动撤防;
   同一时刻仅一枚在防,再点其他条目或名录重绘均自然撤防。 */
let armedDel = null, armedDelT = 0;
function disarmDel(){
  clearTimeout(armedDelT);
  if (armedDel && armedDel.isConnected){
    armedDel.closest('.room-item')?.removeAttribute('data-armed');
    armedDel.textContent = '×';
  }
  armedDel = null;
}
function handleDelClick(del){
  const item = del.closest('.room-item');
  const alias = item?.dataset.alias;
  if (!alias) return;
  if (armedDel === del){                                 // 第二击:执行删除
    disarmDel();
    removeCustomRoom(alias, { message: `已删除直播间 ${alias}` });
    return;
  }
  disarmDel();                                           // 换目标:先撤上一枚
  armedDel = del;
  item.setAttribute('data-armed', '1');
  del.textContent = '确认删除';
  armedDelT = setTimeout(disarmDel, 3000);
}

/* ═══════════ 遮罩 ═══════════ */
function showVeil(title, text){ D.veilTitle.textContent = title; D.veilText.textContent = text; D.veil.hidden = false; }
function hideVeil(){ D.veil.hidden = true; }

/* ═══════════ 账号(扫码登录 · 星币/登录时间/已登录天数) ═══════════
   「添加账号」以「酷狗直播」/「酷狗音乐」App 扫码登录:后端代理官方二维码链路(见
   accounts_backend.py),前端只负责显示二维码 + 轮询状态 + 渲染账号库。
   凭据(token/cookie)仅存后端本地账号库,前端拿到的是安全视图。 */
const ACCT = { pollTimer: 0, sid: '', armedDel: null, armedDelT: 0, lastList: [], autoTimer: 0, autoKick: 0, autoBusy: false, closeT: 0 };

/* 容量闸:账号库满 MAX_ACCOUNTS 个时不再开扫码弹窗(与名录同一套做法)。
   计数取最近一次 /api/account/list 的权威结果(renderAccounts 落 ACCT.lastList)。 */
const ACCTS_FULL_TIP = `账号已满(上限 ${MAX_ACCOUNTS} 个)—— 请先删除不再使用的账号`;
function acctsFull(){ return (ACCT.lastList || []).length >= MAX_ACCOUNTS; }
function syncAddAcctBtn(){
  const b = D.addAcctOpen; if (!b) return;
  const full = acctsFull();
  b.toggleAttribute('data-full', full);
  b.title = full ? ACCTS_FULL_TIP : '用「酷狗直播」/「酷狗音乐」App 扫码登录添加账号';
}

function acctAvatar(url){
  if (!url) return '';
  // 与主播头像一致走 /fx/avatar 中转(https 化 + 尺寸规整 + 代理容灾)
  let u = String(url);
  if (u.startsWith('//')) u = 'https:' + u;
  if (/^\/fx\/avatar/.test(u)) return u;
  if (/^https?:\/\//.test(u)) return '/fx/avatar?u=' + encodeURIComponent(u);
  return u;   // 相对路径(如 /v2/fxuserlogo/...):后端 getUserInfo 已给,原样用
}

function renderAccounts(data){
  const box = D.acctList; if (!box) return;
  const list = (data && data.accounts) || [];
  const cur = (data && data.current) || '';
  acctCurrentMaybeChanged(cur);   // 「当前账号」变了(切换/扫码登录成功)→ 真实盘/官方账号条即时换新,不等轮询
  ACCT.lastList = list;   // 供「按需自动检测」判定各账号是否需复检(validStatus / lastCheckAt)
  D.acctCount.textContent = list.length ? `${list.length}/${MAX_ACCOUNTS}` : '—';
  syncAddAcctBtn();
  if (!list.length){
    box.innerHTML = '<p class="acct-empty">未添加账号</p>';
    return;
  }
  box.innerHTML = list.map(a => {
    const on = String(a.kugouId) === String(cur);
    const av = acctAvatar(a.userLogo);
    const coin = (a.coin === '' || a.coin == null) ? '—' : esc(a.coin);
    const days = Number(a.loginDays) || 0;
    // 2.9.12:仅取日期(去掉时:分)——264px 窄轨里「日期+时间+N天」必溢出被截断,
    // 去时间后「2026-07-03 · N天」方能整行容纳(实测 116<122px 可用)。
    const added = a.addedAtText ? esc(String(a.addedAtText).split(' ')[0]) : '';
    const sub = `${added}${added ? ' · ' : ''}${days}天`;
    // 有效性标:""=未检测 / valid=有效 / invalid=失效
    const vs = a.validStatus || '';
    const flagSt = vs === 'valid' ? 'valid' : vs === 'invalid' ? 'invalid' : 'unknown';
    const flagTx = flagSt === 'valid' ? '有效' : flagSt === 'invalid' ? '失效' : '未检测';
    const flagTip = a.lastCheckText ? esc('上次检测 ' + a.lastCheckText) : '尚未检测';
    return `<div class="acct-item ${on ? 'is-cur' : ''}" data-kid="${esc(a.kugouId)}" role="button" tabindex="0"
                 title="点击切换为当前账号">
      <img src="${esc(av)}" alt="" onerror="this.style.visibility='hidden'">
      <span class="ai-meta">
        <span class="ai-name">${esc(a.nickName || ('酷狗' + a.kugouId))}</span>
        <span class="ai-coin"><i>币</i><b>星币 ${coin}</b></span>
        <span class="ai-sub">
          <em class="ai-flag" data-st="${flagSt}" title="${flagTip}">${flagTx}</em>
          <span class="ai-when">${sub}</span>
        </span>
      </span>
      <span class="ai-actions">
        <i class="ai-btn ai-refresh" title="刷新星币/资料" role="button" tabindex="0">⟳</i>
        <i class="ai-btn ai-del" title="删除该账号" role="button" tabindex="0">×</i>
      </span>
    </div>`;
  }).join('');
}

async function loadAccounts(opt){
  opt = opt || {};
  try {
    const r = await api('/api/account/list');
    renderAccounts(r);
    if (!opt.quiet) scheduleAutoCheck();   // 非静默载入 → 安排一次「按需自动检测」并启动周期复检
    return r;
  } catch (_){ /* 后端未就绪:名录区留空,不打断 */ return null; }
}

function disarmAcctDel(){
  if (ACCT.armedDelT){ clearTimeout(ACCT.armedDelT); ACCT.armedDelT = 0; }
  if (ACCT.armedDel){
    ACCT.armedDel.textContent = '×';
    ACCT.armedDel.closest('.acct-item')?.removeAttribute('data-armed');
    ACCT.armedDel = null;
  }
}

async function switchAccount(kid){
  disarmAcctDel();
  try {
    const r = await api('/api/account/switch?kugouId=' + encodeURIComponent(kid));
    renderAccounts(r);
    toast('已切换账号');
  } catch (_){ toast('切换失败'); }
}

async function refreshAccount(kid, el){
  if (el){ el.textContent = '⟳'; el.style.animation = 'spin .8s linear infinite'; }
  try {
    const r = await api('/api/account/refresh?kugouId=' + encodeURIComponent(kid), { timeout: 15000 });
    renderAccounts(r);
    toast('已刷新');
  } catch (_){ toast('刷新失败'); }
  finally { if (el) el.style.animation = ''; }
}

/* ── 有效性检测:检测账号存下的登录态 token 是否还活着 ──
   valid=有效(绿) / invalid=失效(红) / checking=检测中 / error=网络异常无法判定。
   后端复用「用 token 重新换登录态 → getUserInfo」链路,回本人档案即有效。 */
const ACCT_FLAG_TX = { valid:'有效', invalid:'失效', checking:'检测中', error:'异常', unknown:'未检测' };

function setAcctFlag(kid, st){
  const box = D.acctList; if (!box) return;
  const item = box.querySelector('.acct-item[data-kid="' + String(kid).replace(/"/g, '\\"') + '"]');
  const flag = item && item.querySelector('.ai-flag');
  if (!flag) return;
  flag.dataset.st = st;
  flag.textContent = ACCT_FLAG_TX[st] || '未检测';
}

/* 有效性检测共用执行器:对给定账号小并发(3)检测,结果逐个实时回填状态标;
   收尾静默拉一次权威列表(星币/落库时间已回填)。silent 仅用于区分调用方,是否弹提示由调用方决定。 */
async function runAcctChecks(kids, opt){
  opt = opt || {};
  kids = (kids || []).filter(Boolean);
  if (!kids.length) return { vi: 0, iv: 0, er: 0 };
  kids.forEach(k => setAcctFlag(k, 'checking'));
  let vi = 0, iv = 0, er = 0;
  const queue = kids.slice();
  const worker = async () => {
    while (queue.length){
      const kid = queue.shift();
      try {
        const r = await api('/api/account/check?kugouId=' + encodeURIComponent(kid), { timeout: 15000 });
        const st = r.status === 'valid' ? 'valid' : r.status === 'invalid' ? 'invalid' : 'error';
        setAcctFlag(kid, st);
        if (st === 'valid') vi++; else if (st === 'invalid') iv++; else er++;
      } catch (_){ setAcctFlag(kid, 'error'); er++; }
    }
  };
  await Promise.all(Array.from({ length: Math.min(3, kids.length) }, worker));
  await loadAccounts({ quiet: true });   // 拉权威(星币/lastCheckAt 已回填);quiet=不再二次触发自动检测
  return { vi, iv, er };
}

/* 自动有效性检测:载入后 + 每隔一段时间,静默复检「从未检测 / 距上次检测过久」的账号,
   让列表里的有效/失效标始终新鲜,无需手动点检。按需(跳过刚检过的)+ 小并发,避免触发风控;
   页面不可见时跳过,不在后台空耗接口。 */
const AUTO_CHECK_TTL   = 6 * 60 * 1000;   // 单账号复检间隔下限(6 分钟内检过的跳过)
const AUTO_CHECK_EVERY = 5 * 60 * 1000;   // 周期扫描节拍

function scheduleAutoCheck(){
  clearTimeout(ACCT.autoKick);
  ACCT.autoKick = setTimeout(autoCheckStale, 800);   // 首屏先渲染,稍等一拍再检
  if (!ACCT.autoTimer) ACCT.autoTimer = setInterval(autoCheckStale, AUTO_CHECK_EVERY);
}

async function autoCheckStale(){
  if (ACCT.autoBusy || (typeof document !== 'undefined' && document.hidden)) return;
  const now = Date.now();
  const due = (ACCT.lastList || []).filter(a => {
    const vs = a.validStatus || '';
    const last = (Number(a.lastCheckAt) || 0) * 1000;
    return !vs || (now - last) > AUTO_CHECK_TTL;   // 没检测过 / 太久没检测 → 需复检
  }).map(a => String(a.kugouId)).filter(Boolean);
  if (!due.length) return;
  ACCT.autoBusy = true;
  try { await runAcctChecks(due, { silent: true }); }
  finally { ACCT.autoBusy = false; }
}

/* 手动「检测有效性」按钮:立即全量复检并给出汇总提示(自动检测之外的即时兜底,如临下真实注前想确认)。 */
async function checkAllAccounts(btn){
  const box = D.acctList;
  const kids = box ? Array.from(box.querySelectorAll('.acct-item')).map(el => el.dataset.kid).filter(Boolean) : [];
  if (!kids.length){ toast('未添加账号'); return; }
  if (btn){ btn.disabled = true; btn.dataset.busy = '1'; btn.textContent = '检测中…'; }
  ACCT.autoBusy = true;   // 手动检测期间挡住周期自动检测,避免并发重复打接口
  try {
    const { vi, iv, er } = await runAcctChecks(kids, { silent: true });
    toast(`检测完成:有效 ${vi} · 失效 ${iv}${er ? ' · 异常 ' + er : ''}`);
  } finally {
    ACCT.autoBusy = false;
    if (btn){ btn.disabled = false; btn.removeAttribute('data-busy'); btn.textContent = '检测有效性'; }
  }
}

function armOrDeleteAccount(kid, delEl){
  if (ACCT.armedDel === delEl){                 // 第二击:执行删除
    disarmAcctDel();
    api('/api/account/remove?kugouId=' + encodeURIComponent(kid))
      .then(r => { renderAccounts(r); toast('已删除账号'); })
      .catch(() => toast('删除失败'));
    return;
  }
  disarmAcctDel();
  ACCT.armedDel = delEl;
  delEl.closest('.acct-item')?.setAttribute('data-armed', '1');
  delEl.textContent = '确认删除';
  ACCT.armedDelT = setTimeout(disarmAcctDel, 3000);
}

function onAcctListClick(e){
  const item = e.target.closest('.acct-item'); if (!item) return;
  const kid = item.dataset.kid;
  if (e.target.closest('.ai-del')){ e.stopPropagation(); armOrDeleteAccount(kid, e.target.closest('.ai-del')); return; }
  if (e.target.closest('.ai-refresh')){ e.stopPropagation(); refreshAccount(kid, e.target.closest('.ai-refresh')); return; }
  switchAccount(kid);
}

const QR_STATUS_TEXT = {
  waiting: '请用「酷狗直播」/「酷狗音乐」App 扫码登录',
  scanned: '已扫描,请在手机上确认登录',
  confirmed: '确认中…',
  done: '登录成功',
  expired: '二维码已过期',
  error: '登录失败,请重试',
};

function stopQrPoll(){ if (ACCT.pollTimer){ clearInterval(ACCT.pollTimer); ACCT.pollTimer = 0; } }

function setQrStatus(s, text){
  D.qrStatus.dataset.s = s || '';
  D.qrStatus.textContent = text || QR_STATUS_TEXT[s] || '';
}

/* 2.9.9:扫码预览。扫码成功(status==2)后,后端把官方回显的昵称/头像放在
   poll 响应的 preview 里;这里在二维码位即时显示,消除「扫码后头像迟迟不出」的观感。
   只渲染一次(previewShown 守卫),避免每 1.5s 轮询导致的重复重绘/闪烁。 */
function renderScanPreview(p){
  if (ACCT.previewShown || !D.qrBox) return;
  ACCT.previewShown = true;
  const av = p.userLogo ? acctAvatar(p.userLogo) : '';
  const name = esc(p.nickName || '');
  D.qrBox.innerHTML =
    `<div class="qr-preview">` +
      (av ? `<img class="qr-preview-av" src="${esc(av)}" alt="" onerror="this.style.display='none'">` : '') +
      `<div class="qr-preview-name">${name || '已扫描'}</div>` +
      `<div class="qr-preview-hint">请在手机上确认登录</div>` +
    `</div>`;
}

async function openAcctModal(){
  if (acctsFull()){ toast(ACCTS_FULL_TIP); return; }   // 容量闸:满了就不生成二维码
  /* 4.3.1 ⑧:清掉上一次「扫码成功」遗留的 700ms 自动关 —— 与 4.3.0 ①同族:
     成功→关层→700ms 内重开加号,旧定时器的 !hidden 守卫看到的是**新层**,
     照关不误。句柄入册 ACCT.closeT,开层与关层(closeModal 分支)双向清。 */
  clearTimeout(ACCT.closeT); ACCT.closeT = 0;
  closeRail();
  D.addAcctMsg.textContent = '';
  D.qrMask.hidden = true;
  D.qrBox.innerHTML = '<div class="qr-spin" aria-hidden="true"></div>';
  setQrStatus('', '正在生成二维码…');
  openModal(D.addAcctModal, D.qrRefresh);
  await startQrLogin();
}

async function startQrLogin(){
  stopQrPoll();
  if (acctsFull()){                       // 「刷新二维码」也走这里:满了就不再签发新码
    setQrStatus('error', ACCTS_FULL_TIP); showQrMask('账号已满'); return;
  }
  D.qrMask.hidden = true;
  D.qrBox.innerHTML = '<div class="qr-spin" aria-hidden="true"></div>';
  setQrStatus('', '正在生成二维码…');
  let r;
  try {
    r = await api('/api/account/qr/create', { timeout: 15000 });
  } catch (_){ r = null; }
  if (!r || !r.ok || !r.img){
    setQrStatus('error', (r && r.error) || '二维码生成失败,请检查网络后重试');
    D.addAcctMsg.textContent = '';
    showQrMask('二维码生成失败');
    return;
  }
  ACCT.sid = r.sid;
  ACCT.scanTicks = 0;
  ACCT.previewShown = false;   // 2.9.9:新会话重置扫码预览标记
  D.qrBox.innerHTML = `<img src="${esc(r.img)}" alt="登录二维码">`;
  setQrStatus('waiting');
  // 轮询扫码状态(1.5s 间隔)
  ACCT.pollTimer = setInterval(() => pollQr(), 1500);
}

function showQrMask(text){
  D.qrMaskText.textContent = text || '二维码已过期';
  D.qrMask.hidden = false;
}

async function pollQr(){
  if (!ACCT.sid){ stopQrPoll(); return; }
  let r;
  try {
    r = await api('/api/account/qr/poll?sid=' + encodeURIComponent(ACCT.sid), { timeout: 12000 });
  } catch (_){ return; }   // 单次网络抖动:下个周期再试
  if (!r || !r.ok) return;
  const st = r.status;
  if (st === 'waiting' || st === 'confirmed'){ ACCT.scanTicks = 0; setQrStatus(st); return; }
  if (st === 'scanned'){
    setQrStatus('scanned');
    // 2.9.9:扫码那一刻官方就回显了昵称/头像(见后端 poll 的 preview 字段)。
    // 立即在二维码位展示,用户扫完即见头像,无需再等「确认+换登录态+取资料」那 1~2s。
    if (r.preview && (r.preview.userLogo || r.preview.nickName)){
      renderScanPreview(r.preview);
    }
    // 已确认却长时间停在「已扫描」:提示可能是确认态未被识别,给出诊断线索
    ACCT.scanTicks = (ACCT.scanTicks || 0) + 1;
    if (ACCT.scanTicks === 12){   // ~18s 仍未确认
      D.addAcctMsg.textContent = '若已在手机确认仍停留此步,可稍候或刷新二维码重试;持续如此可打开 /api/account/qr/diag 反馈。';
    }
    return;
  }
  if (st === 'done'){
    stopQrPoll();
    setQrStatus('done');
    await loadAccounts();
    const nick = (r.account && r.account.nickName) || '账号';
    toast('已添加:' + nick);
    ACCT.closeT = setTimeout(() => { ACCT.closeT = 0;
      if (!D.addAcctModal.hidden) closeModal(D.addAcctModal); }, 700);   // 4.3.1 ⑧:入册,见 openAcctModal 注
    return;
  }
  if (st === 'expired'){ stopQrPoll(); setQrStatus('expired'); showQrMask('二维码已过期'); return; }
  if (st === 'error'){ stopQrPoll(); setQrStatus('error', (r.error) || '登录失败,请重试'); showQrMask('登录失败'); return; }
}


/* ═══════════ 弹层开合(2.6.3:焦点管理) ═══════════
   打开时记录开启处、关闭时把焦点归还 —— 此前 Esc/×/遮罩关闭后焦点掉到
   <body>,键盘用户失位(实测 activeElement 为 BODY)。四条关闭路径
   (Esc / × / 遮罩点击 / 提交成功)统一走 closeModal。 */
/* 焦点归还的可见性门卫(2.6.6):元素虽在文档中,却可能随抽屉平移出屏
   (≤1060px 打开弹层时 closeRail 已把名录移到 -105%)。归还到屏外元素 =
   焦点环不可见 + Shift+Tab 会在闭合抽屉的屏外条目间隐形游走(实测 right=-24
   连走三步)。屏外时退落到可见的 ☰(仅窄屏存在),桌面路径不受影响。 */
function onScreen(el){
  if (!el || !document.contains(el) || el.offsetParent === null) return false;
  const r = el.getBoundingClientRect();
  return r.width > 0 && r.right > 0 && r.left < innerWidth && r.bottom > 0 && r.top < innerHeight;
}
/* ★ 4.3.0:开启者从「单槽位 S._modalOpener」改为**逐层** WeakMap。
   单槽位在「开通门 → 支付层」这唯一的嵌套场景下必然丢外层:内层 openModal
   一记录,门的开启者就被覆写销毁 —— 真机实测:门-only 时 Esc 正确归还 ucBuy,
   经过一次支付层开合后再关门,焦点退到 railOpen 兜底(项目契约「焦点归还
   开启处」被嵌套打破)。逐层记录 = 同一契约的逐层版本;对其余单开弹层
   (加房 / 扫码)行为逐字节不变。4.2.9 的「层已可见时不覆盖」语义原样保留
   (仍只在 hidden→显 的那一次记录)。WeakMap 以层元素为键,层被移出文档即
   自动可回收,不引入任何生命周期管理。 */
const MODAL_OPENERS = new WeakMap();
function openModal(layer, focusEl, opener){
  /* ★ 4.2.9(沿革,机制已由上方 WeakMap 接管):对一个**已经打开**的层再调
     openModal 会把开启者覆盖成层内元素(实测:连点「立即开通」两次后被写成
     payClose)—— 故只在层原本是隐藏态时记录,重开同一层保持原开启者不变。
     ★ 4.3.0 第三参 opener:调用方可**显式指定**开启者。真机探针坐实:慢网下
     用户的第二次物理点击会穿透 data-busy 的 pointer-events:none、mousedown 落在
     下层容器上,焦点当场掉到 BODY —— 此刻才开层的话,activeElement 已不是真正
     的开启处(4.2.9 用 data-busy 替代 disabled 只防住了**程序性**失焦,防不住
     这条物理路径)。openPay 在入口(第二击尚未发生时)捕获并显式传入。
     BODY 永远不是有意义的开启者(onScreen(body) 恒假),显式值也照此过滤。 */
  if (layer.hidden){
    const ae = document.activeElement;
    const op = (opener instanceof HTMLElement && opener !== document.body) ? opener
      : (ae instanceof HTMLElement && ae !== document.body ? ae : null);
    MODAL_OPENERS.set(layer, op);
  }
  layer.hidden = false;
  /* 4.2.3 ★ preventScroll:focus() 默认会把目标滚进视口。开通门的焦点目标是
     底部的「立即开通」,而卡片在手机上高达 1088px —— 弹层一开就被滚到最底,
     标题 / 状态条 / 关闭「×」全在屏外(320×568~390×844 与横屏必现)。
     其余 4 个弹层的焦点目标本就在首屏内,此项对它们是空操作。 */
  /* 4.2.9:focusEl 可能是**禁用**的(档位表为空时「立即开通」即为禁用态),
     对禁用元素调 focus() 是空操作 ⇒ 整层开起来没有落焦点,键盘用户无处着手。
     禁用则回落到层内下一个可聚焦元素。 */
  ((focusEl && !focusEl.disabled) ? focusEl
    : (layer.querySelector('input:not([disabled]),select:not([disabled]),textarea:not([disabled]),button:not(.modal-close):not([disabled])')
       || layer.querySelector('button:not([disabled])')))?.focus({ preventScroll: true });
}
function closeModal(layer){
  if (layer === D.addRoomModal) S.addToken = (S.addToken | 0) + 1;   // 2.6.17:关闭即作废进行中的房号预校验
  if (layer === D.addAcctModal){ stopQrPoll(); ACCT.sid = '';
    clearTimeout(ACCT.closeT); ACCT.closeT = 0; }                       // 关闭扫码弹窗即停轮询,释放会话;4.3.1 ⑧:自动关句柄同清
  layer.hidden = true;
  const op = MODAL_OPENERS.get(layer) || null;   // 4.3.0:取**本层**的开启者(见 openModal 注)
  MODAL_OPENERS.delete(layer);
  if (onScreen(op)) op.focus();
  else if (D.railOpen && D.railOpen.offsetParent !== null) D.railOpen.focus();
}

/* ═══════════ 3.6.0 按日回看(retention>1 天时的 >24h 历史回放) ═══════════
   形态:全屏序列双模 —— live(现状,openWide 恒先落于此)/ day(按日回看)。
   隔离铁律:对主舱只读 S.alias/S.cols/S.hl,绝不触碰 S.hist/S.ids/S.anchor/
   S.pred/S.lagMs —— 自适应拉取、覆盖自愈、推演对齐(2.9.5)、SSE 单调守卫
   (3.3.8)四套机制零感知;live 态渲染仍由 renderRoad 全权负责。
   日归属口径 = 北京**起局日**(floor((round_id+8h)/86400000),与 dayNo 及
   后端 /history/days 的日桶逐字一致;date_local 是出怪日口径,不参与本功能)。
   「今天」恒为实时 —— 不存在会悄悄过期的静态今日视图。
   流量账:同日切换吃会话 LRU(8 日 ≈1.7MB 内存);冻结日(区间上界早于
   now-1h,后端判定)带 immutable,浏览器 HTTP 缓存承担跨会话层。 */
const WV = {
  mode: 'live',            // 'live' 实时全景(现状) | 'day' 按日回看
  day: '',                 // 'YYYY-MM-DD'(北京起局日)
  rounds: [],              // 当日局(normRound 后,升序=旧→新)
  days: null, daysFor: '', daysAt: 0,   // 日目录 60s 会话缓存(按房)
  retentionDays: 0,        // 服务端保留天数(随日目录带回;仅用于「部分日」精确判据与文案)
  cache: new Map(),        // LRU:`${alias}|${date}` → 当日局
  seq: 0,                  // 竞态令牌:只认最后一次导航意图(同构 S.loadSeq)
  navigated: false, prefetching: false, _navSig: '',
};
const WV_DAY_MS = 86400000, WV_CACHE_MAX = 8;

const wvDayStart = d => { const [y, m, dd] = String(d).split('-').map(Number);
  return Date.UTC(y, (m || 1) - 1, dd || 1) - BJ_OFFSET_MS; };
function wvDayLabel(d){
  const t0 = wvDayStart(d);
  const diff = Math.round((bjMidnightOf(nowC()) - t0) / WV_DAY_MS);   // 「昨天/前天」用校准钟,免客户端钟漂标错
  const dt = new Date(t0 + BJ_OFFSET_MS), wk = '日一二三四五六'[dt.getUTCDay()];
  const tag = diff === 1 ? '昨天' : diff === 2 ? '前天' : '';
  return `${tag ? tag + ' · ' : ''}${dt.getUTCMonth() + 1}月${dt.getUTCDate()}日 · 周${wk}`;
}
/* 可回放日 = 日目录中除「今天」外的日期(新→旧;今天恒为实时,不进回放集) */
function wvNavDays(){
  if (WV.daysFor !== S.alias || !Array.isArray(WV.days)) return [];
  const today = bjMidnightOf(nowC());
  return WV.days.filter(d => Number(d.dayStartMs) !== today);
}

/* 「全屏」按钮 = 回看的唯一入口。旧规则(驾驶舱且主盘已全显 → 隐藏)在 3.6.0 前
   成立 —— 彼时全屏的唯一价值是"看更多珠";现在全屏多了第二价值(按日回看),
   有可回放日时不得隐藏,否则默认驾驶舱布局下功能不可达(四轮复查实锤)。
   无可回放日(retention=1 常态 / 旧后端 / 断网)时表达式退化为旧规则,默认部署
   行为逐字节不变。 */
function wvSyncEntry(){
  if (!D.roadExpand) return;
  const replay = wvNavDays().length > 0;
  const cockpit = S.L?.mode === 'cockpit';
  D.roadExpand.hidden = cockpit && S.hist.length > 0
    && ROAD_MAX >= S.hist.length && !replay;
  D.roadExpand.title = replay ? '全屏全景 · 含按日回看(昨天/前天…)' : '';
  if (D.roadReplay) D.roadReplay.hidden = !replay;   // 五轮 UX:显性直达入口,与全屏并排;无可回放日不占位
}

/* 导航行同步:门控即「若有」—— 可回放日为空(retention=1 常态)则整行隐藏。
   下拉重建按签名去重(目录/日期未变则零 DOM 触碰,tick 级调用无压力)。 */
function wvSyncNav(){
  if (!D.wideNav) return;
  const nav = wvNavDays();
  D.wideNav.hidden = !nav.length;
  if (!nav.length){ if (WV.mode === 'day') wvGoLive(); return; }
  const sig = nav.map(d => d.date + ':' + d.n).join('|')
    + '@' + bjMidnightOf(nowC()) + '@' + WV.retentionDays;
  if (sig !== WV._navSig){
    WV._navSig = sig;
    // 「部分」精确判据:retention 截止线是滚动毫秒线(now − days×86400000,非日对齐),
    // 起局早于截止线的日已被巡检逐时裁剪 —— 按截止线落点判定,而非局数启发式
    // (停机造成的缺口日局数也会偏少,但那不是"已清理",不可误标)。
    const cutoff = WV.retentionDays > 0 ? nowC() - WV.retentionDays * WV_DAY_MS : 0;
    D.wvDay.innerHTML = '<option value="">今天(实时)</option>' + nav.map(d =>
      `<option value="${esc(d.date)}">${esc(wvDayLabel(d.date))} · ${d.n}局${
        cutoff && Number(d.dayStartMs) < cutoff ? '(部分,已滚动清理)' : ''}</option>`).join('');
  }
  D.wvDay.value = WV.mode === 'day' ? WV.day : '';
  const i = WV.mode === 'day' ? nav.findIndex(d => d.date === WV.day) : -1;
  D.wvPrev.disabled = WV.mode === 'day' ? i >= nav.length - 1 : false;
  D.wvNext.disabled = WV.mode !== 'day';
  D.wvLiveBtn.hidden = WV.mode !== 'day';
  if (WV.mode !== 'day' && D.wvCensus) D.wvCensus.hidden = true;
  if (D.wideSpot) D.wideSpot.title = WV.mode === 'day'
    ? '取消聚光(Esc) · 徽标计数口径为实时窗(近24h)' : '取消聚光(Esc)';   // 与 index.html 初始 title 逐字对齐
}

/* 日目录:懒取 + 60s 会话缓存;失败静默(旧后端/断网 → 导航不出现,行为=现状) */
async function wvLoadDays(force){
  if (!S.alias) return;
  if (!force && WV.daysFor === S.alias && Date.now() - WV.daysAt < 60000) return wvSyncNav();
  try {
    const d = await api(`/api/rooms/${encodeURIComponent(S.alias)}/history/days`);
    WV.days = d.days || []; WV.daysFor = S.alias; WV.daysAt = Date.now();
    WV.retentionDays = Number(d.retentionDays) || 0;
  } catch (_){
    if (WV.daysFor !== S.alias){ WV.days = null; WV.daysFor = S.alias; WV.daysAt = Date.now(); }
  }
  wvSyncNav(); wvSyncEntry();
}

async function wvFetchDay(date, alias = S.alias){
  const t0 = wvDayStart(date);
  const d = await api(`/api/rooms/${encodeURIComponent(alias)}/history`
                      + `?since=${t0}&until=${t0 + WV_DAY_MS}&limit=${HISTORY_LIMIT}`);
  return (d.rounds || []).map(normRound)                     // 与 applyRoomData 同口径门卫
    .filter(r => Number.isInteger(r.n) && r.n >= 1 && r.n <= 9 && Number.isFinite(r.start))
    .sort((a, b) => a.start - b.start);
}
function wvCachePut(key, rounds){
  WV.cache.delete(key); WV.cache.set(key, rounds);           // 触碰即置新 = 真 LRU
  if (WV.cache.size > WV_CACHE_MAX) WV.cache.delete(WV.cache.keys().next().value);
}

async function wvGoto(date){
  if (!S.alias || !date) return;
  const seq = ++WV.seq, key = `${S.alias}|${date}`;
  WV.mode = 'day'; WV.day = date; WV.navigated = true; wvSyncNav();
  const hit = WV.cache.get(key);
  if (hit){ wvCachePut(key, hit); WV.rounds = hit; renderWideDay(); wvPrefetch(); return; }
  if (D.wvCensus) D.wvCensus.hidden = true;
  D.wideGrid.innerHTML = '<div class="wide-empty">正在读取该日出怪…</div>';
  D.wideCount.textContent = wvDayLabel(date);
  try {
    const rounds = await wvFetchDay(date);
    if (seq !== WV.seq) return;                              // 过期响应整体丢弃(只认末次意图)
    WV.rounds = rounds; wvCachePut(key, rounds);
    renderWideDay();
    if (!rounds.length) wvLoadDays(true);   // 空日多为 retention 赛跑(方案 §11):强刷目录,下拉即时反映清理
    wvPrefetch();
  } catch (_){
    if (seq !== WV.seq) return;
    D.wideGrid.innerHTML = '<div class="wide-empty">该日读取失败'
      + ' <button type="button" class="tool-btn" data-wv-retry>重试</button></div>';
  }
}

function wvGoLive(){
  if (WV.mode === 'live'){ wvSyncNav(); return; }
  WV.mode = 'live'; WV.day = ''; ++WV.seq; wvSyncNav();
  renderRoad();                                              // 借道现状分支整层回灌实时盘(含 wideCount)
  stickInit(D.wideBody, { anchor: 'bottom', content: D.wideGrid });   // 4.7.2:回实时 → 锚点换回底部
  stickPin(D.wideBody, { force: true });
}

/* dir:+1 前一天(更旧) / -1 后一天(更新;越过最新回放日即回实时) */
function wvStep(dir){
  const nav = wvNavDays(); if (!nav.length) return;
  if (WV.mode !== 'day'){ if (dir > 0) wvGoto(nav[0].date); return; }
  const i = nav.findIndex(d => d.date === WV.day), j = i + dir;
  if (j < 0) return wvGoLive();
  if (j >= nav.length) return;
  wvGoto(nav[j].date);
}

function renderWideDay(){
  const rows = WV.rounds;
  setWideGeom();   // 4.7.3 夹紧 + 4.7.6 与实时全屏同一套独立档/几何(见 wideColsFor 注)
  /* 4.4.0 复审补:回看态此前裸调 beadHtml,**不算断口** —— 那正是本轮要修的同一个
     问题换了个视图。回看的整日数据同样可能缺局(停机/上游缺),不标就是把不连续的
     一天画成连续的。改走 beadsHtml(rows 已是旧→新升序,见 wvFetchDay 的 sort)。 */
  D.wideGrid.innerHTML = rows.length
    ? beadsHtml(rows)                                        // 静态成像:回看态没有"下一颗",不挂悬挂珠
    : '<div class="wide-empty">该日无出怪数据(当时未监控,或已滚出保留窗)</div>';
  const wvMiss = missingSlots(rows);
  D.wideCount.textContent = rows.length
    ? `${rows.length} 局${wvMiss ? ` · 缺 ${wvMiss}` : ''} · ${wvDayLabel(WV.day)}`
    : wvDayLabel(WV.day);
  wvRenderCensus(rows);
  /* 与实时"贴底看最新"互为镜像:回看是一整天的静态成像,从当日清晨读起。
     4.7.2:同样交给守卫维持(锚点 top)—— 此前只打一发 rAF,回看态下旋转屏幕
     或收起地址栏同样会把读位掀走。要改成"回看也贴底"只需把 anchor 改成 'bottom'。 */
  stickInit(D.wideBody, { anchor: WV_DAY_ANCHOR, content: D.wideGrid });
  stickPin(D.wideBody, { force: true });
  D.pendingEls = $$('.bead-pending');                        // 本层无 pending → tick 对本层自动歇脚
  if (S.hl.size) renderSpotChip();                           // 聚光挂容器类,换日重建天然幸存
}

/* 当日九宫简报:9 号位当日次数 + 首末局时刻,从已到手的 rows 就地统计(零请求) */
function wvRenderCensus(rows){
  if (!D.wvCensus) return;
  if (!rows.length){ D.wvCensus.hidden = true; D.wvCensus.innerHTML = ''; return; }
  const c = {}; for (let n = 1; n <= 9; n++) c[n] = 0;
  rows.forEach(r => c[r.n]++);
  let dots = '';
  for (let n = 1; n <= 9; n++)
    dots += `<i style="--e:var(--e${n})" title="号位 ${n} · 当日 ${c[n]} 次">${n}</i><em>${c[n]}</em>`;
  D.wvCensus.innerHTML = `<b>当日九宫</b>${dots}`
    + `<em class="wvc-meta">首局 ${fmtClock(rows[0].start)} · 末局 ${fmtClock(rows[rows.length - 1].start)}</em>`;
  D.wvCensus.hidden = false;
}

/* 相邻更旧一日的 idle 预取:仅在用户已导航过 ≥1 次后启用(不为未用的功能付费),
   单飞、静默、requestIdleCallback 兜底 setTimeout —— 让「继续往前翻」零等待。 */
function wvPrefetch(){
  if (!WV.navigated || WV.prefetching || WV.mode !== 'day') return;
  const nav = wvNavDays(), i = nav.findIndex(d => d.date === WV.day);
  const nxt = i >= 0 ? nav[i + 1] : null;
  if (!nxt) return;
  const alias = S.alias, key = `${alias}|${nxt.date}`;
  if (WV.cache.has(key)) return;
  (window.requestIdleCallback || (f => setTimeout(f, 800)))(async () => {
    if (WV.prefetching || WV.cache.has(key)) return;
    WV.prefetching = true;
    try { wvCachePut(key, await wvFetchDay(nxt.date, alias)); } catch (_){}
    finally { WV.prefetching = false; }
  }, { timeout: 4000 });
}

/* 全屏序列开合(2.6.4:与弹层同族的焦点缺陷,复查揪出)——
   此前键盘 Enter 打开后焦点仍停在遮罩层下的「全屏」按钮(实测 focusInWide=false,
   Tab 起点在层后);点「← 返回」关闭后该按钮随层隐藏、焦点掉到 <body>。
   现打开即把焦点移入层(返回键),×/Esc 两条关闭路径统一归还开启处。 */
function openWide(){
  S._wideOpener = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  WV.mode = 'live'; WV.day = ''; ++WV.seq;   // 3.6.0:打开恒先落实时(首要诉求是"现在",往前翻日才是回放)
  D.wideView.hidden = false;
  wvSyncNav(); wvLoadDays();                 // 日导航懒取:retention=1 → 可回放日为空 → 整行恒隐藏(「若有」门控)
  renderRoad();
  // 打开即定位到最新(底部,含悬挂珠倒计时):观测台的首要诉求是"现在",往上翻即回放
  syncColSelects();                                   // 4.7.3:全屏容器比主盘宽,菜单按它自己的宽度重列
  stickInit(D.wideBody, { anchor: 'bottom', content: D.wideGrid });
  stickPin(D.wideBody, { force: true });
  D.wideBack.focus();
}
function closeWide(){
  D.wideView.hidden = true;
  WV.mode = 'live'; WV.day = ''; ++WV.seq;   // 3.6.0:离场复位,在飞回看响应作废;下次打开即"现在"
  const op = S._wideOpener; S._wideOpener = null;
  if (onScreen(op)) op.focus();               // 与 closeModal 同一可见性门卫(开启处「全屏」按钮各形态恒在屏,无需兜底)
}

/* ═══════════ 九法游戏面板(3.9.4:双形态 —— 桌面右侧停靠 / 窄屏全屏) ═══════════
   2.7.0 弹窗 → 2.8.0 停靠 → 3.9.0 全屏 → 3.9.4 按视口二择一:
   · 桌面(视口 ≥1024,断点与 app.css 3.9.4 节同源):停靠为 #shell 尾列
     (sticky 通高,与名录同法),**非模态** —— 背后观测台保持完全可交互、
     可滚动,主区按有效宽度自动重排(布局引擎/挤压态见 effW);
     「边看数据边施法」的 2.8.0 初衷回归。
   · 窄屏(<1024,含移动端):保持 3.9.0 全屏形态 —— 满幅铺开、锁背景
     滚动、主区 inert、名录切覆盖式(CSS 同名节均按同一断点媒体查询限定)。
   开着面板拖拽视口跨越断点时,MQ change 就地重定形态(jfApplyChrome)
   并重排主区。iframe 首开才装载(~10MB 游戏资源不拖累观测台启动),
   收起仅 display:none 不卸载 —— 局中收起再展开,战局与模拟币原地继续。
   数据侧:iframe 内 sim-engine 与本页共享同一 RoundEngine 实例,同一局、
   同一倒计时、同一出怪;面板头同步条(tick 驱动)即此事的常驻可视凭证。 */
/* 官方 iframe:按 mode 载入(sim=本地模拟 / real=星币经父页施法通道);mode 变化即换 src 重载。
   room 由共享回合引擎(JiufaShared/RoundEngine)实时读观测台房号,无需塞进 URL。 */
function jiufaFrameSrc(mode){
  // 3.8.0:登录用户带 u=<id> —— iframe 内 sim-engine 的模拟存档(jf3:sim)据此
  // 按账号分命名空间,与父页 jf2:*@u 同一哲学;未登录/未启用登录不带参,旧键旧行为。
  const u = (AUTH.enabled && AUTH.user) ? ('u=' + encodeURIComponent(AUTH.user.id)) : '';
  if (mode === 'real') return '/jiufa/?mode=real' + (u ? '&' + u : '');
  return '/jiufa/' + (u ? '?' + u : '');
}
/* 4.1.1:装载态修复(移动端「杀浏览器重开 → 面板恢复但永远停在'正在装载模拟游戏'」,
   三内核 Playwright 实地复现,详见 window_audit 之外的独立复盘)。三处根因:
   ① 会话恢复(Android/iOS 杀进程后重开标签、以及任何 back/reload)时,浏览器会按
     **子帧会话历史**自行把 #jiufaFrame 导航回 /jiufa/…,而 src **内容属性保持为空**
     (Chromium/WebKit/Firefox 实测均如此:load 事件先于任何 JS 触达,attr=null)。
     旧代码以 getAttribute('src') 判断"已装载" → 恒判否 → 把 ~26MB 游戏再整帧重载
     一遍;移动网络 + 生产 no-cache 逐文件重验证,就是每次重开浏览器都白多一轮
     「正在装载」。
   ② 遮罩 #jiufaHint 在 HTML 里**默认可见**,唯一的收起路径是本函数内一枚
     {once:true} 的 load 监听。恢复路径上法术表未就绪(_jfWait)期间无人挂监听;
     若 loadRoom 失败且快照过期,补装永不发生 → 遮罩永久停留(WebKit 离线恢复
     实测复现:attr=null、spells=0、遮罩常驻);导航失败/子资源悬挂时部分内核
     不派发 load,同样卡死。收起面板再展开撞上 attr===want 早退,连重试机会都没有。
   ③ 恢复竞态下 iframe 可能先于父页 app.js 解析 → 其内联装载器兜底装了**独立
     round-engine**(README「独立形态」),嵌入语境下盘面与观测台脱钩。
   ④ 数据面死端(与 ①②③ 正交,单独即可复现整症):恢复瞬间电台/Wi-Fi 未醒 →
     loadRoom 三请求全灭;快照恰过期 26h → S.hist 为空、名录也拉空 → 兜底 catch
     无处回退后**静默放弃且不设任何重试**。此后 SSE/轮询/名录拍/游戏帧 pullNow
     全走 ingest 增量,只补局、永不补 spells(唯一赋值点在 applyRoomData)——
     观测台九法阵永远空板;官方象限因 _jfWait 连 loadJiufaFrame 都不会被调用,
     遮罩(HTML 默认可见)永驻;收起重开面板重走同一 spells 门,依旧卡死;唯有
     整页刷新可救(Chromium 实证:联网恢复后局史经幽灵帧 pullNow 涨回 200,
     spells 恒 0,遮罩 60s+ 不动)。
   修复分两层,互不托底也各自成立:
   · 数据面 —— loadRoom 死端处起 3s→30s 指数退避自动重试(成功/换房即拆);
     visibilitychange/online 钩子遇零基线(spells 为空)改走全量 loadRoom 而非
     pollNew。基线必达,九法阵与法术表最终一致。
   · 呈现面 —— 就位判定看**帧内真实文档**(同源 contentWindow 的 path+search)
     与引擎形态(JiufaSim.embedded),已就位即收遮罩、零重载;遮罩生命周期交给
     jfHintShow 的三保险 —— 750ms 就绪轮询 + bindStatic 常驻 load 监听 + 12s 起步
     /30/60/120s 退避的看门狗补导航;揭遮罩**不再以父页法术表为前置**(④ 实证
     二者可长期解耦)。任何事件时序都不可能把「正在装载」永久留在屏上,也不会
     打断慢网在途装载。 */
function jfFrameDoc(){                       // 帧内真实落点(同源可读;未落地/错误页返回 null)
  try {
    const w = D.jiufaFrame && D.jiufaFrame.contentWindow;
    if (!w) return null;
    return { path: w.location.pathname + w.location.search, win: w };
  } catch (_){ return null; }
}
function jfFrameReady(want){                 // 帧已停在目标 URL 且为嵌入形态(共享观测台引擎)
  const d = jfFrameDoc();
  return !!(d && d.path === want && d.win.JiufaSim && d.win.JiufaSim.embedded);
}
let _jfHintT = 0, _jfKickAt = 0, _jfKickStep = 0;
/* 4.1.2:遮罩生命周期再加固(截图级死端「正在装载模拟游戏」永驻,三内核 + 真机
   路径 Playwright 实地复现,三个正交死因逐一堵死):
   ① **在途豁免无封顶**(4.1.1 引入的回归):帧停在目标 URL 且 readyState 未
     complete 时看门狗只顺延 +15s、永不重踢。移动网(5G↔基站切换/电梯/弱信号)
     下 head 里任何一个前置资源(425KB CSS / polyfill / sim-engine 本体)的连接
     **停摆不超时**,解析器就停在 sim-engine 之前 —— JiufaSim 永不落地、readyState
     永远 loading,豁免变成永动机,遮罩无限期停留(实测 50s+ 纹丝不动,理论上直到
     手动刷新)。现豁免累计封顶 _JF_STALL_CAP(45s,远超正常慢网收尾、又短于用户
     弃疗):越顶即视作「装载停摆」照踢 —— 重导航会重建连接,正是停摆 TCP 需要的。
   ② **踢了也白踢的死端无终态**:sim-engine 被拦/引擎双侧缺位时,JiufaSim 永不
     出现,看门狗 30/60/120s 盲踢每次都踩同一坑 —— 旧版无限盲踢(移动网每踢
     整帧重下)且用户只看到永恒的「正在装载」。现连续 _JF_FAIL_AFTER 次踢仍未
     就位 → 遮罩转「失败终态」:文案换成可操作提示 + 可点击(点即重置计数立刻
     重试),盲踢停止(轮询仍在,自愈了照样揭)。
   ③ 帧内侧的对偶自愈(引擎缺位/误装形态的就地重载)见 jiufa/jf-boot.js。 */
const _JF_STALL_CAP = 45000;        // 在途豁免累计封顶:超过即判停摆照踢
const _JF_FAIL_AFTER = 3;           // 连续盲踢 N 次仍未就位 → 失败终态(可点重试)
let _jfStallSince = 0, _jfKickN = 0;
function jfHintMode(fail){
  if (!D.jiufaHint) return;
  const s = D.jiufaHint.querySelector('strong'), p = D.jiufaHint.querySelector('p');
  if (fail){
    D.jiufaHint.dataset.fail = '1';
    if (s) s.textContent = '模拟游戏装载失败';
    if (p) p.textContent = '网络不稳或资源被拦截 · 点此重试(多次失败可下拉刷新整页)';
    // 失败终态是可交互控件:向读屏/键盘暴露(装载态恒 aria-hidden 纯装饰,见 index.html)
    D.jiufaHint.setAttribute('aria-hidden', 'false');
    D.jiufaHint.setAttribute('role', 'button');
    D.jiufaHint.setAttribute('tabindex', '0');
    D.jiufaHint.setAttribute('aria-label', '模拟游戏装载失败,点击重试');
  } else {
    delete D.jiufaHint.dataset.fail;
    if (s) s.textContent = '正在装载模拟游戏';
    if (p) p.textContent = '九法盘面 · 单机模拟,首次装载稍候';
    D.jiufaHint.setAttribute('aria-hidden', 'true');
    D.jiufaHint.removeAttribute('role');
    D.jiufaHint.removeAttribute('tabindex');
    D.jiufaHint.removeAttribute('aria-label');
  }
}
function jfHintHide(){
  clearInterval(_jfHintT); _jfHintT = 0;
  _jfStallSince = 0; _jfKickN = 0;
  jfHintMode(false);
  if (D.jiufaHint) D.jiufaHint.hidden = true;
}
/* 失败终态点击重试:重置计数、恢复装载文案、立刻补导航(bindStatic 挂接) */
function jfHintRetry(){
  if (!D.jiufaHint || !D.jiufaHint.dataset.fail) return;
  _jfKickN = 0; _jfKickStep = 0; _jfStallSince = 0;
  jfHintMode(false);
  _jfKickAt = Date.now() + 12000;
  try { D.jiufaFrame.src = jiufaFrameSrc(S.gameTab === 'real' ? 'real' : 'sim'); } catch {}
}
function jfHintShow(){
  if (D.jiufaHint) D.jiufaHint.hidden = false;
  jfHintMode(false);
  clearInterval(_jfHintT); _jfKickStep = 0; _jfKickN = 0; _jfStallSince = 0;
  _jfKickAt = Date.now() + 12000;
  _jfHintT = setInterval(() => {
    if (!S.jiufa || S.rgSkin !== 'official'){ jfHintHide(); return; }   // 离开官方象限:遮罩无宿主,停拍
    const want = jiufaFrameSrc(S.gameTab === 'real' ? 'real' : 'sim');
    // 就位即揭 —— 只看帧内真实状态(同源落点 + 嵌入引擎),**不看父页法术表**:
    // 首装死端实证里父页 spells 可长期为空而帧内游戏完全健康(会话恢复出的
    // "幽灵帧"自带引擎、甚至反向 pullNow 喂父页);法术表由 loadRoom 侧的零基线
    // 退避自己去救。把游戏遮罩耦合到父页数据面,只会把一个故障变成两个。
    if (jfFrameReady(want)) return jfHintHide();
    // 在途停摆计时:帧在目标页、脚本引擎(JiufaSim)未落地、文档未 complete
    // → 属「装载在途」;每拍累计,任何一项翻转即清零(见 ① 的封顶语义)。
    {
      const d0 = jfFrameDoc();
      const inflight = !!(d0 && d0.path === want && !d0.win.JiufaSim
                          && d0.win.document.readyState !== 'complete');
      if (inflight){ if (!_jfStallSince) _jfStallSince = Date.now(); }
      else _jfStallSince = 0;
    }
    // 失败终态:连续盲踢 ≥ _JF_FAIL_AFTER 仍未就位 → 停止盲踢,换可操作提示。
    // 轮询继续跑:帧内 jf-boot 自愈/网络恢复/用户点重试,任一到位遮罩照常揭开。
    if (_jfKickN >= _JF_FAIL_AFTER){
      if (D.jiufaHint && !D.jiufaHint.dataset.fail) jfHintMode(true);
      return;
    }
    // 看门狗补导航:12s 起步,此后 30/60/120s 退避(封顶)——
    // 导航失败(WebKit 失败子帧导航**不派发 load**,实证)/子资源悬挂/恢复竞态
    // 误装独立引擎,皆由此路自愈;退避间隔给足慢网在途装载收尾时间,不打断正常载入。
    if (Date.now() >= _jfKickAt){
      // 在途装载豁免(4.1.1 引入,4.1.2 加封顶):帧已停在目标 URL 且文档仍在装载
      // (readyState 未 complete)且累计在途 < _JF_STALL_CAP → 这是真的慢网首装
      // (26MB 冷缓存可远超 12s),顺延观察、不打断重来 —— 否则看门狗会把每次
      // 快到手的装载掐死重下,慢网上永远装不完。豁免只延后看门狗、不延后揭开
      // (装载自然收尾由就绪轮询与 bindStatic 常驻 load 监听揭遮罩)。
      // 越过封顶(45s 无进展到 JiufaSim)= 前置资源连接停摆(移动网典型),
      // 照踢重建连接;readyState 到 complete 仍无引擎(脚本报错/被拦/误装形态)、
      // 或压根不在目标页(WebKit 失败导航停 about:blank;Chromium 错误页跨源
      // 不可读 → jfFrameDoc 为 null)同样照踢。
      const d = jfFrameDoc();
      const stalled = _jfStallSince && (Date.now() - _jfStallSince >= _JF_STALL_CAP);
      if (!stalled && d && d.path === want && d.win.document.readyState !== 'complete'){
        _jfKickAt = Date.now() + 15000;   // 顺延不升档(封顶内)
      } else {
        _jfKickStep = Math.min(_jfKickStep + 1, 3);
        _jfKickN += 1;
        _jfStallSince = 0;                // 重导航即新一轮在途计时
        _jfKickAt = Date.now() + [30000, 60000, 120000, 120000][_jfKickStep - 1];
        try { D.jiufaFrame.src = want; } catch {}
      }
    }
  }, 750);
}
function loadJiufaFrame(mode){
  mode = (mode === 'real') ? 'real' : 'sim';
  const want = jiufaFrameSrc(mode);
  const d = jfFrameDoc();
  const atWant = !!(d && d.path === want);
  if (atWant && d.win.JiufaSim && d.win.JiufaSim.embedded){ jfHintHide(); return; }   // 会话恢复已就位:收遮罩,零重载
  jfHintShow();
  // 帧不在目标页,或引擎形态错误(恢复竞态误装独立引擎)→ 导航;
  // 在目标页但 sim-engine 尚在执行(装载中)→ 交给轮询收尾,不打断在途装载。
  if (!atWant || (d.win.JiufaSim && !d.win.JiufaSim.embedded)) D.jiufaFrame.src = want;
}

/* ── 停靠面板双模式(真实游戏 / 模拟游戏)──────────────────────────────
   两模式共用同一停靠槽(宽屏右列 / 窄屏底部抽屉),互斥呈现。S.jiufa 仍表
   「面板开合」(布局引擎据此预留右列),S.gameTab 记当前模式。 */
function setGameTab(tab, { focus = false } = {}){
  tab = (tab === 'sim') ? 'sim' : 'real';
  S.gameTab = tab;
  store.set(KEY.gameTab, tab);
  applyGameSurface({ focus });
}
/* 风格开关:diy=玉青纸墨 / official=官方风(真实页签=自绘深色金调皮肤;模拟页签=原版官方 iframe)*/
function setSkin(skin){
  skin = (skin === 'official') ? 'official' : 'diy';
  if (S.rgSkin === skin) return;
  S.rgSkin = skin;
  store.set(KEY.rgSkin, skin);
  applyGameSurface({});
}
/* 面板矩阵落位:页签(真实/模拟)×风格(DIY/官方)→ 四象限。
   真实×DIY → #realBody(本模块);模拟×DIY → #simBody(本模块);
   真实×官方 → 官方 iframe(mode=real,星币);模拟×官方 → 官方 iframe(mode=sim,模拟)。 */
function applyGameSurface({ focus = false } = {}){
  const isReal = S.gameTab === 'real';
  const official = S.rgSkin === 'official';
  const realDiy = isReal && !official, simDiy = !isReal && !official;
  if (D.tabReal){ D.tabReal.classList.toggle('is-on', isReal); D.tabReal.setAttribute('aria-selected', String(isReal)); }
  if (D.tabSim){ D.tabSim.classList.toggle('is-on', !isReal); D.tabSim.setAttribute('aria-selected', String(!isReal)); }
  if (D.skinDiy){ D.skinDiy.classList.toggle('is-on', !official); D.skinDiy.setAttribute('aria-pressed', String(!official)); }
  if (D.skinOfficial){ D.skinOfficial.classList.toggle('is-on', official); D.skinOfficial.setAttribute('aria-pressed', String(official)); }
  // 面板显隐:realPane 仅承载 真实×DIY;其余三象限走 simPane(模拟×DIY 用 #simBody,两官方象限用 iframe 舞台)
  if (D.realPane) D.realPane.hidden = !realDiy;
  if (D.simPane) D.simPane.hidden = realDiy;
  if (D.simBody) D.simBody.hidden = !simDiy;
  const stage = D.simPane && D.simPane.querySelector('.jiufa-stage');
  if (stage) stage.hidden = !official;                    // iframe 舞台:两官方象限展示
  if (D.jiufaFoot){
    const footOn = official && !isReal;                   // 脚注仅模拟×官方保留(离线单机说明);真实×官方不放提示
    D.jiufaFoot.hidden = !footOn;
    // 文案随显隐一并落位:真实×官方下清空 —— 这句只对模拟形态成立(单机 / 模拟币),
    // 仅靠 hidden 挡住等于把一句错话留在 DOM 里(读屏、全选复制、任何一次误解除 hidden 都会漏出)。
    D.jiufaFoot.textContent = footOn ? '离线单机:施法真实扣除模拟币、出怪与观测台序列逐局同源,不连任何实盘、不做任何出怪预测。' : '';
  }
  if (D.realGameOpen) D.realGameOpen.setAttribute('aria-pressed', String(S.jiufa && isReal));
  if (D.jiufaOpen) D.jiufaOpen.setAttribute('aria-pressed', String(S.jiufa && !isReal));
  if (!S.jiufa){ if (D.officialAide) D.officialAide.hidden = true; if (D.officialAcct) D.officialAcct.hidden = true; aideStop(); return; }   // 面板未开:仅同步态
  if (official){
    rgDeactivate();                                       // 官方象限:iframe 接管,停本模块节拍
    const mode = isReal ? 'real' : 'sim';
    RG.mode = mode;                                       // 官方象限也钉住 mode:账号条/星币桥按此分流,不残留上个象限的态
    if (S.spells.length) loadJiufaFrame(mode);
    else {
      S._jfWait = true; S._jfWaitMode = mode;
      // 4.1.1:等待法术表期间,遮罩同样要有生命周期 —— 会话恢复出的"幽灵帧"若已
      // 就位则立即揭开(零重载、零闪烁);未就位则起 750ms 轮询 + 看门狗,任何
      // 事件时序都不会把「正在装载」永久留在屏上(旧代码此分支什么都不做,遮罩
      // 是否收起完全押在"日后必有 loadJiufaFrame"上 —— 首装死端里它永不到来)。
      if (jfFrameReady(jiufaFrameSrc(mode))) jfHintHide(); else jfHintShow();
    }
    if (D.officialAcct) D.officialAcct.hidden = !isReal;  // 顶部账号条:仅真实×官方(与 DIY .rg-acct 同款)
    if (D.officialAide) D.officialAide.hidden = false;
    aideStart();                                          // 随身面板:推演 + 24h战况 + 我的记录
  } else {
    if (D.officialAcct) D.officialAcct.hidden = true;
    if (D.officialAide) D.officialAide.hidden = true;
    aideStop();
    rgActivate();                                         // DIY 象限:本模块接管(mode=页签)
    if (focus){ const b = rgBox(); b && b.focus?.(); }
  }
}
/* 3.9.4:形态相关「罩壳」单点落位 —— 只有窄屏全屏形态才是模态:
   主区/收起态名录 inert、aria-modal(背景滚动锁与名录覆盖式改写在
   CSS 侧按同一断点媒体查询限定)。桌面停靠为非模态:背后观测台保持
   完全可交互。开着面板拖视口跨越断点(MQ change)时就地重定。 */
function jfApplyChrome(){
  const full = jfFullscreen();
  const stage = document.querySelector('.stage');
  if (full){
    stage?.setAttribute('inert', '');                            // 盖住的主区对键盘/读屏惰化(3.9.1)
    if (!D.rail?.classList.contains('is-open')) D.rail?.setAttribute('inert', '');   // 收起态离屏名录同惰化;展开态浮在坞上须保持可交互,收起时由 closeRail 接管
  } else {
    stage?.removeAttribute('inert');
    D.rail?.removeAttribute('inert');
  }
  D.jiufaDock?.setAttribute('aria-modal', full ? 'true' : 'false');
}
/* 开着面板拖拽视口跨越 1024 断点:形态与主区几何就地重定
   (resize 防抖也会兜到 applyLayout,这里补的是即时性 + inert/aria 语义) */
const _jfMqChanged = () => { if (S.jiufa){ jfApplyChrome(); applyLayout(); } };
if (JF_DOCK_MQ.addEventListener) JF_DOCK_MQ.addEventListener('change', _jfMqChanged);
else JF_DOCK_MQ.addListener?.(_jfMqChanged);   // 旧内核兜底(无此 API 时由 resize 防抖兜)

function openGameDock(tab){
  if (D.wideView && !D.wideView.hidden) closeWide();   // 3.9.1:全屏序列(z70)在上时先收 —— 否则键盘可把坞(z60)开在其下形成怪态
  const first = !S.jiufa;
  S.jiufa = true;
  store.set(KEY.jiufaOpen, '1');
  D.jiufaDock.hidden = false;
  document.body.dataset.jiufa = 'open';
  jfApplyChrome();                              // 3.9.4:模态性按形态落位(全屏才 inert/aria-modal)
  applyLayout();                                // 3.9.4:桌面停靠占位后主区按有效宽度重排(全屏形态下宽度未变,近零开销)
  if (first){ S._jfSync = ''; tick(); }
  setGameTab(tab || S.gameTab || 'real');
  // 焦点收进面板(关闭键):全屏形态即对话框语义;停靠形态同样把键盘起点交给面板
  requestAnimationFrame(() => { D.jiufaClose?.focus?.(); });
}
function closeGameDock(){
  if (!S.jiufa) return;
  closeRail();                                  // 3.9.1:游戏内开的名录随坞一并收(避免残留 is-open 叠驾驶舱边距)
  S.jiufa = false;
  store.set(KEY.jiufaOpen, '0');
  rgDeactivate();
  aideStop();                                   // 随身面板节拍同停(否则空转)
  const hadFocus = D.jiufaDock.contains(document.activeElement);
  D.jiufaDock.hidden = true;
  delete document.body.dataset.jiufa;
  jfApplyChrome();                              // 3.9.4:S.jiufa 已落 false → 撤主区/名录惰化(先撤再归还焦点,inert 子树不可聚焦)
  applyLayout();                                // 3.9.4:桌面停靠让出的宽度归还主区(全屏形态下宽度未变,近零开销)
  if (D.realGameOpen) D.realGameOpen.setAttribute('aria-pressed', 'false');
  if (D.jiufaOpen) D.jiufaOpen.setAttribute('aria-pressed', 'false');
  if (hadFocus || document.activeElement === document.body){
    (S.gameTab === 'sim' ? D.jiufaOpen : D.realGameOpen)?.focus();
  }
}
/* 顶栏入口点击:未开→按该模式打开;已开且同模式→收起;已开异模式→切到该模式 */
function onGameEntry(tab){
  if (!S.jiufa) openGameDock(tab);
  else if (S.gameTab === tab) closeGameDock();
  else setGameTab(tab, { focus: true });
}
/* 兼容旧调用名(启动恢复 / ESC / 关闭按钮沿用) */
function closeJiufa(){ closeGameDock(); }
function openJiufa(){ openGameDock('sim'); }

/* 同步条(tick 驱动,内容变化才触碰 DOM):相位点 + 倒计时 + 最近开出珠。
   模拟游戏与观测台共用同一引擎,这里展示的就是双方共同的那一局。 */
function renderJiufaSync(phase, secs, cs){
  if (!S.jiufa || !D.jiufaSync) return;
  /* 4.8.0:房号在本条上**恒显**。真实游戏的施法走官方 preOrder(带 roomId 与
     toUid=主播)—— 观测房与用户实际在看的房不一致时,扣的是真星币、打赏的是
     另一个主播。这枚房号是扣款前唯一常驻的归属凭证,四个象限一个都不能缺。 */
  const room = roomTag()
    ? `<i class="js-room" title="本盘面对应的直播间">${esc(roomTag())}</i>` : '';
  if (S.gameTab === 'real' && S.rgSkin === 'official'){       // 真实×官方:官方盘面自带倒计时横幅,同步胶囊不叠加读秒
    const k = 'off|' + S.alias;
    if (S._jfSync !== k){ S._jfSync = k; D.jiufaSync.innerHTML = room; }   // 只留房号;无房时 :empty 即隐藏
    return;
  }
  const label = phase === 'cast' ? '施法' : phase === 'seal' ? '备战' : '出怪';
  const r0 = S.hist[0] || null;
  const key = `${S.alias}|${phase}|${secs}|${r0 ? r0.id : ''}`;   // 4.8.0:含房号,切房必重绘
  if (S._jfSync === key) return;
  S._jfSync = key;
  const bead = r0
    ? `<i class="js-bead" style="--e:var(--e${r0.n})" title="最近开出 ${r0.n} · ${esc(r0.name)}${r0.start === cs ? '(本局)' : ''}">${r0.n}</i>`
    : '';
  D.jiufaSync.innerHTML = `${room}<i class="js-dot" data-p="${phase}"></i><b>${label} ${secs}s</b>${bead}`;
}

/* ══════════════════════════════════════════════════════════════════════════
   真实游戏(官方礼物游戏「九法降妖」· 用左侧名录里正在选择的账号亲手玩)
   —— 后端 game_backend.py 代理官方 spell_tamer 接口;前端只做展示 + 交互。
   —— 与观测台同一局 / 同一倒计时:相位时刻直接取官方 spellTime/drawTime/endTime,
      本地按「校准时钟」(clockOffset)细分到 250ms 刷新,不额外造轮子。
   —— 一切"真金白银"动作(施法扣星币)前必弹「确认施法」小层,余额醒目常显。
   ══════════════════════════════════════════════════════════════════════════ */
const RG = {
  view: 'cast',            // 内页签:cast 施法盘 / records 我的记录 / rank 榜单
  mode: 'real',            // 数据驱动:real=官方星币盘(默认) / sim=本地模拟(模拟钱包 + 观测台出怪结算)
  simShownRound: 0,        // 模拟:已展示过出怪条的局起点(防重复结算/重复弹条)
  simWaitSince: 0,         // 模拟:法术表未就绪的起始时刻(>8s 才升级为可重试的异常提示)
  predSeen: '',            // 灵机推演内容指纹(变了就地刷新推演带)
  aliasKick: '',           // 真实模式:alias 落位后已即时取盘的房号(开机窗口免等 4s 轮询)
  state: false,            // 是否已成功取到官方牌面(决定骨架 vs 内容)
  room: '',                // 已拉取的房间(与 S.alias 比对以侦测换主播)
  anchorUid: null,         // 该房主播 UID(后端已解析,前端仅备用)
  account: null,           // 当前选择账号摘要 {kugouId,nickName,userLogo,coin,validStatus}
  guard: null,             // 阻断态 {kind,message};need_login/invalid/business/network/api
  sel: null,               // 选中的法术编号 1..9
  count: 1,                // 攻击次数(1..99)
  spells: [],              // 规整后的 9 法术(含 beast/倍率/我的攻击次数 spellNum)
  canPlay: true,           // 官方 canPlay 闸(活动是否可玩)
  roundId: null,           // 当前局号(= 起始毫秒)
  spellTime: 0,            // 施法截止(起始+35s)
  drawTime: 0,             // 出怪(起始+40s)
  endTime: 0,              // 本局结束(起始+50s)
  clockOffset: 0,          // 游戏服务器与本地的时钟差(EMA 平滑)
  tips: [],                // 官方提示语
  history: [],             // 近局妖兽序列(出怪序列面板数据源)
  histRoom: '',            // 序列对应房间(换主播需重载)
  records: null,           // 我的记录(null=未加载)
  rank: null,              // 榜单(null=未加载)
  award: null,             // 最近一局出怪结果 {awardStatus,beast,multiplier,...}
  awardFetchedRound: null, // 已拉过奖励的局号(每局一次)
  endPolledRound: null,    // 已在 endTime 触发过续拉的局号(每局一次)
  pollTimer: 0, tickTimer: 0,
  castBusy: false,         // 施法请求进行中(防重复提交)
  cols: (() => { const v = Number(store.get(KEY.rgCols)); return ROAD_COL_OPTIONS.includes(v) ? v : rgColsDefault(); })(),  // 战况每行位数:DIY 独立设置
  size: (store.get(KEY.rgSize) === 'tall' ? 'tall' : 'normal'),   // 5.0.9:DIY 盘高度档 —— normal=完整施法盘 / tall=速选条(数据优先),见 rgToggleSize 长注
  sig: '',                 // 渲染签名(骨架级变化才整屏重绘,否则软更新)
  confirm: null,           // 确认层态 {spellId,count};非空即展示
  castErr: null,           // 最近一次施法失败的可读提示 {kind,message};非空即在施法盘顶部友好提示
  loadingHist: false, loadingRec: false, loadingRank: false,
};

/* 原始 fetch(后端恒 200 + 信封,不走异常;网络/解析失败才 throw)
   3.8.0:统一带 X-JF-Auth 头;会话级 401/403(被顶/到期等)同样回落登录门。 */
async function gapi(path, opt = {}){
  const ctl = new AbortController();
  const tid = setTimeout(() => ctl.abort(), opt.timeout || 9000);
  try {
    const res = await fetch(path, { signal: ctl.signal, headers: { 'X-JF-Auth': '1', 'X-JF-Tab': JF_TAB } });
    clearTimeout(tid);
    const data = (await res.json().catch(() => ({}))) || {};
    if ((res.status === 401 || res.status === 403) && AUTH_ERRS.has(data.error))
      handleAuthError(data);
    return data;
  } catch (e){ clearTimeout(tid); throw e; }
}

/* 官方图片 URL 归一:协议补全 + 相对路径挂酷狗图床 */
function rgImg(u){
  if (!u) return '';
  u = String(u);
  if (u.startsWith('//')) return 'https:' + u;
  if (u.startsWith('http://')) return 'https://' + u.slice(7);
  if (u.startsWith('/')) return 'https://s4fx.kgimg.com' + u;
  return u;
}
/* 法术/妖兽编号 → 九法元素色谱(与观测台同一 --e1..--e9)*/
function rgSpellColor(id){ const n = (((Number(id) - 1) % 9) + 9) % 9 + 1; return `var(--e${n})`; }
function rgSpellColorS(id){ const n = (((Number(id) - 1) % 9) + 9) % 9 + 1; return `var(--e${n}s)`; }
/* 观测台自定义号位:妖兽 → 号位(与左侧序列/战况同一套 custom_beast_ids 编号)。
   真实游戏原按官方 spellId / beastId 展示,与观测台不是同一套编号 —— 于是「近期战况」对不上。
   统一改用观测台号位后,真实游戏的格子编号、序列、配色即与观测台逐格恒等。
   以妖兽名命中最稳(配置以名定号),兜底按官方 beast_id;观测台法术表未就绪时返回 0,由调用方退回官方编号。 */
function rgBeastNo(beast){
  if (!beast) return 0;
  const sp = S.spells || [];
  const name = beast.beastName || beast.beast_name || '';
  if (name){ const hit = sp.find(x => x.beast_name === name); if (hit && +hit.display_number) return +hit.display_number; }
  const bid = beast.beastId != null ? beast.beastId : beast.beast_id;
  if (bid != null){ const hit = sp.find(x => Number(x.beast_id) === Number(bid)); if (hit && +hit.display_number) return +hit.display_number; }
  return 0;
}
/* 面板矩阵:页签=数据模式(真实/模拟),风格开关=皮肤(DIY/官方)。
   两个 DIY 象限(真实×DIY、模拟×DIY)由本模块渲染;两个官方象限(真实×官方、模拟×官方)
   一律走原版官方 iframe —— 仅 iframe 的 mode 不同(real=星币经父页已验证施法通道;sim=本地模拟)。 */
function rgActive(){ return S.jiufa && S.rgSkin === 'diy'; }
function rgBox(){ return RG.mode === 'sim' ? D.simBody : D.realBody; }   // 当前模式的渲染容器
function rgClock(){ return RG.mode === 'sim' ? nowC() : (Date.now() + RG.clockOffset); }   // 模拟以观测台校准钟为准
function rgSig(v){ RG.sig = v; }                 // 置空即强制下次整屏重绘
function rgLoadingHtml(msg){ return `<div class="rg-loading"><div class="rg-spin"></div>${esc(msg || '加载中…')}</div>`; }

/* 时钟对齐:以官方 serverTime 校准本地(EMA,抗抖动)*/
function rgClockSync(serverMs){
  if (!serverMs) return;
  const off = serverMs - Date.now();
  RG.clockOffset = RG.clockOffset ? Math.round(RG.clockOffset * 0.7 + off * 0.3) : off;
}

/* 当前相位:施法/备战/出怪/本局结束 —— 直接用官方三时刻切窗,倒计时到各自边界 */
function rgPhaseNow(){
  const now = rgClock();
  const sp = +RG.spellTime || 0, dr = +RG.drawTime || 0, en = +RG.endTime || 0;
  if (!RG.roundId || !dr) return { phase: 'wait', label: '等待开局', secs: 0, pct: 0, canCast: false, ended: true };
  if (now < dr){
    // 「施法期」与「备战」倒计时合并 —— 同一段「距出怪」连续读秒(不在施法截止 sp 处重置为 5→1),
    // 与 #liveRing 同口径:进度环一笔扫满约 40s、恰在出怪归零;相位语义(可否施法/标签/配色)仍在 sp 处切换。
    const sealed = now >= sp;
    const secs = Math.max(0, Math.ceil((dr - now) / 1000));       // 连续到出怪,不重置
    const span = T.DRAW;                                          // 施法+备战合并窗 ≈40s(局起点→出怪)
    const pct = clampN(0, (dr - now) / span * 100, 100);          // 一笔连续:窗起 100 → 出怪 0
    return { phase: sealed ? 'seal' : 'cast', label: sealed ? '备战待出' : '施法期', secs, pct, canCast: sealed ? false : RG.canPlay, ended: false };
  }
  if (now < en){                                 // 出怪展示:倒计时到本局结束
    const secs = Math.max(0, Math.ceil((en - now) / 1000));
    const span = Math.max(1000, en - dr);              // ≈10s
    return { phase: 'draw', label: '出怪', secs, pct: clampN(0, (en - now) / span * 100, 100), canCast: false, ended: false };
  }
  return { phase: 'end', label: '本局结束', secs: 0, pct: 0, canCast: false, ended: true };
}

/* ═══════════ 模拟驱动(模拟×DIY:本地钱包 + 观测台真实出怪结算)═══════════
   与 iframe 模拟游戏同一世界观:出怪 = 观测台实录(S.hist,与左侧序列逐局同源),
   钱包 = 本地模拟币(localStorage 持久),绝不发任何官方施法/下单请求。 */
const SIM_COIN_DEF = 100000;
/* 妖兽图标(模拟盘):与官方 iframe 同一份打包素材(/jiufa/data/demo_data.json →
   spellList[].beastInfo.beastIcon/beastLogo + spellLogo,均为本地 qqcdn/ 资源)。
   父页读一次建映射;相对路径前缀 jiufa/(不带斜杠开头,避开 rgImg 的官方 CDN 补全)。 */
const SIMICON = { map: null, busy: false };
function simIconFix(u){
  u = String(u || '');
  if (!u) return '';
  if (/^https?:|^\/\//i.test(u)) return u;
  return 'jiufa/' + u.replace(/^\/+/, '');
}
function simIconsEnsure(){
  if (SIMICON.map || SIMICON.busy) return;
  SIMICON.busy = true;
  fetch('/jiufa/data/demo_data.json')
    .then(r => r.json())
    .then(d => {
      const m = {};
      (((d || {}).mainPageTemplate || {}).spellList || []).forEach(sp => {
        const b = sp.beastInfo || {};
        if (b.beastId == null) return;
        m[Number(b.beastId)] = { beastIcon: simIconFix(b.beastIcon), beastLogo: simIconFix(b.beastLogo), spellLogo: simIconFix(sp.spellLogo) };
      });
      SIMICON.map = m;
      if (rgActive() && RG.mode === 'sim'){
        if (RG.award && RG.award.beast && !RG.award.beast.beastIcon && RG.award._bid != null)
          RG.award.beast.beastIcon = simIcon(RG.award._bid).beastIcon || '';     // 补挂已在场的出怪条
        RG.state = false; simSync();                                             // 重建法术表以挂图
        rgSig(''); rgSyncRender();
      }
    })
    .catch(() => {})
    .finally(() => { SIMICON.busy = false; });
}
function simIcon(beastId){ return (SIMICON.map && SIMICON.map[Number(beastId)]) || {}; }
function simWallet(){ const raw = store.get(KEY.simWallet); if (raw == null || raw === '') return SIM_COIN_DEF; const v = Number(raw); return Number.isFinite(v) && v >= 0 ? Math.round(v) : SIM_COIN_DEF; }   // 3.8.1:未存档回初始额度(Number(null)===0 曾令全新浏览器钱包为 0、无法施法)
function simWalletSet(v){ store.set(KEY.simWallet, String(Math.max(0, Math.round(v)))); }
function simBetsLoad(){ try { const a = JSON.parse(store.get(KEY.simBets) || '[]'); return Array.isArray(a) ? a : []; } catch (_){ return []; } }
function simBetsSave(list){ store.set(KEY.simBets, JSON.stringify(list.slice(0, 120))); }
function simAccount(){ return { kugouId: 'SIM', nickName: '模拟钱包', userLogo: '', coin: simWallet(), validStatus: 'valid' }; }

/* 以观测台为源就地成盘:法术表(S.spells)→ 九法阵,校准钟(nowC)→ 本局四时刻。
   引导态分两种:没选直播间 → 引导选房;选了房但法术表未就绪 → 载入态(rgTick 每拍自愈,
   房号/法术表一就绪立即自动成盘,无需来回切页签)。 */
function simSync(){
  if (!S.alias){
    if (!S.roomsReady || (S.rooms && S.rooms.length)){     // 开机窗口 / 名录有房待自动落位:均为暂态 → 载入态(自愈每拍重探)
      if (!RG.simWaitSince) RG.simWaitSince = Date.now();
      RG.guard = (Date.now() - RG.simWaitSince > 8000)
        ? { kind: 'network', message: '房间数据迟迟未就绪(网络或后端异常),可点重试。' }
        : null;
      RG.state = false; return;
    }
    RG.guard = { kind: 'business', message: '模拟盘与观测台同房、同局、同出怪 —— 先添加一个直播间。' };   // 5.0.2:方位指引撤掉,「添加直播间」按钮就在本卡上(rgGuardHtml)
    RG.state = false; return;
  }
  if (!(S.spells && S.spells.length)){
    if (!RG.simWaitSince) RG.simWaitSince = Date.now();
    RG.guard = (Date.now() - RG.simWaitSince > 8000)
      ? { kind: 'network', message: '法术配置迟迟未就绪(网络或后端异常),可点重试。' }
      : null;                                            // 短暂未就绪:显示「正在铺开模拟盘面…」载入态
    RG.state = false; return;
  }
  RG.simWaitSince = 0;
  RG.guard = null;
  simIconsEnsure();                                            // 妖兽图:与官方 iframe 同一份素材(就绪后自动补挂)
  const cs = curStart(nowC());
  const bets = simBetsLoad();
  const mine = {};                                             // 本局各妖兽已布法数(官方 beast_id 维度)
  bets.forEach(b => { if (b.start === cs && !b.settled) mine[b.spellId] = (mine[b.spellId] || 0) + (+b.count || 0); });
  RG.room = String(S.alias);
  RG.roundId = cs;
  RG.spellTime = cs + T.CAST; RG.drawTime = cs + T.DRAW; RG.endTime = cs + T.END;
  RG.canPlay = true; RG.tips = [];
  RG.spells = S.spells.map(sp => {
    const bid = Number(sp.beast_id), ic = simIcon(bid);
    return {
      spellId: bid,
      spellName: sp.spell_name || ('御' + (sp.spell_key || ELEM[sp.display_number] || '') + '术'),
      spellLogo: ic.spellLogo || '',
      beast: { beastId: bid, beastName: sp.beast_name || '', beastIcon: ic.beastIcon || '', beastLogo: ic.beastLogo || '' },
      multiplier: sp.multiplier, iconFootText: sp.multiplier ? `${sp.multiplier}倍` : '',
      spellPrice: 1000, spellNum: mine[bid] || 0,
    };
  });
  RG.account = simAccount();
  if (RG.sel == null || !RG.spells.some(s => s.spellId === RG.sel)) RG.sel = RG.spells[0] ? RG.spells[0].spellId : null;
  RG.state = true;
}

/* 模拟施法:即时扣模拟币入账本;出怪由 simSettleTick 对着观测台实录结算 */
function simCast(spellId, count, unit){
  const s = RG.spells.find(x => x.spellId === spellId);
  if (!s){ RG.confirm = null; toast('法术未就绪'); rgSig(''); rgSyncRender(); return; }   // 3.8.1:早退也要收确认层
  const total = unit * count;
  const coin = simWallet();
  if (coin < total){
    // 3.8.1:与真实盘同款盘顶横幅 + 关闭确认层(旧版仅 toast 且确认层悬留,「确认施法」看似无响应)
    RG.castErr = { kind: 'business', message: `模拟币不足(还差 ${total - coin}),可在上方钱包栏「重置」补满。` };
    RG.confirm = null;
    toast('模拟币不足(可在钱包栏重置)');
    rgSig(''); rgSyncRender();
    return;
  }
  simWalletSet(coin - total);
  const no = rgBeastNo(s.beast) || spellId;
  const bets = simBetsLoad();
  bets.unshift({ start: RG.roundId, spellId, no, spellName: s.spellName, beastName: s.beast.beastName,
                 count, unit, total, mult: +s.multiplier || 0, at: Date.now(), settled: false, hit: null, win: 0 });
  simBetsSave(bets);
  s.spellNum = (+s.spellNum || 0) + count;
  RG.account = simAccount();
  RG.confirm = null; RG.castBusy = false;
  toast(`已模拟施法【${s.beast.beastName}】×${count} · 扣 ${total} 模拟币`);
  rgSig(''); rgSyncRender();
}

/* 逐拍结算:观测台实录里出现某局结果 → 该局所有未结法术记录立刻兑付;
   最新一局落地时同步弹出出怪条(命中/未中/未参与),与真实盘同一套 rg-result。 */
function simSettleTick(){
  const hist = S.hist || []; if (!hist.length) return;
  const bets = simBetsLoad();
  let dirty = false, credit = 0;
  for (const b of bets){
    if (b.settled) continue;
    const r = hist.find(x => x.start === b.start); if (!r) continue;
    b.settled = true;
    b.hit = (Number(r.n) === Number(b.no));
    b.win = b.hit ? Math.round(b.total * (+r.mult || +b.mult || 0)) : 0;
    b.result = { n: r.n, beast: r.beast, mult: r.mult };
    if (b.win) credit += b.win;
    dirty = true;
  }
  if (dirty){
    if (credit) simWalletSet(simWallet() + credit);
    simBetsSave(bets);
    RG.account = simAccount();
  }
  const r0 = hist[0];
  if (r0 && r0.start !== RG.simShownRound && rgClock() >= (r0.start + T.DRAW)){
    RG.simShownRound = r0.start;
    const mineBets = bets.filter(b => b.start === r0.start);
    const stake = mineBets.reduce((n, b) => n + b.total, 0);
    const win = mineBets.reduce((n, b) => n + (b.win || 0), 0);
    const st = !mineBets.length ? 3 : (win > 0 ? 1 : 2);
    const hitBet = mineBets.find(b => b.hit);
    const rsp = jfSpellByNum(r0.n) || {};                       // 出怪妖兽 → 官方 beast_id → 图标
    const rbid = (rsp.beast_id != null) ? Number(rsp.beast_id) : null;
    RG.award = { roundId: r0.start, awardStatus: st, multiplier: r0.mult,
                 beast: { beastName: r0.beast, beastIcon: rbid != null ? (simIcon(rbid).beastIcon || '') : '' },
                 _bid: rbid,
                 spellId: hitBet ? hitBet.spellId : null,
                 awardList: win ? [{ giftScore: win }] : [], stake };
    rgSig(''); rgSyncRender();
    if (st === 1) rgHitAnimation(RG.award);
  }
}

/* 重置模拟钱包(法术记录历史保留,便于复盘) */
function simResetWallet(){
  if (!window.confirm(`把模拟钱包重置为 ${SIM_COIN_DEF.toLocaleString()} 模拟币?(法术记录历史保留)`)) return;
  simWalletSet(SIM_COIN_DEF);
  RG.account = simAccount();
  toast('模拟钱包已重置');
  rgSig(''); rgSyncRender();
}

/* ═══════════ 星币桥(真实×官方 iframe → 父页)═══════════
   官方原版 UI(iframe,mode=real)经 window.parent.RealGameBridge 读真实账号余额、
   并把「施法」委托给父页**已验证的施法通道**(/api/game/cast:preOrder→SpellUse 一次成)。
   —— 星币只走这一条通道,iframe 不自建任何下单/扣费逻辑,杜绝重复下单/错扣。 */
window.RealGameBridge = {
  ready(){ return !!(RG.account && RG.account.kugouId && RG.account.validStatus !== 'invalid' && S.alias); },
  coin(){ const c = RG.account && RG.account.coin; return (c === '' || c == null) ? 0 : (Number(c) || 0); },
  account(){ const a = RG.account || {}; return { kugouId: a.kugouId || '', nickName: a.nickName || '', userLogo: a.userLogo || '' }; },
  room(){ return String(S.alias || ''); },
  unitPrice(spellId){ const s = (RG.spells || []).find(x => Number(x.spellId) === Number(spellId)); return s ? (+s.spellPrice || 1000) : 1000; },
  async cast({ spellId, count, roundId }){
    if (!this.ready()) return { ok: false, kind: 'invalid', message: '请先在名录选择一个有效账号与直播间。' };   // 5.0.2:去「左侧」—— 窄屏全屏面板下方位失准
    const sid = Number(spellId), cnt = Math.max(1, Number(count) || 1), unit = this.unitPrice(sid);
    try {
      const d = await gapi(`/api/game/cast?room=${encodeURIComponent(S.alias)}&spell=${sid}&count=${cnt}&round=${encodeURIComponent(roundId)}&price=${unit}`, { timeout: 15000 });
      if (d.gameOk === false) return { ok: false, kind: d.kind, code: d.code, message: d.message || '施法未成功' };
      if (d.account) RG.account = d.account;
      rgRefreshCoin();                                    // 拉权威余额,名录/头条同步
      AIDE.records = null;                                // 官方象限「我的记录」失效重取,新法术记录立刻可见
      if (aideActive() && AIDE.tab === 'records') renderAide();
      const coin = (d.account && d.account.coin != null) ? Number(d.account.coin) : this.coin();
      return { ok: true, coin, orderId: d.orderId || (d.raw && d.raw.orderId) || '', message: d.message || '施法成功' };
    } catch (e){ return { ok: false, kind: 'network', message: '与官方服务器连接不稳,施法未发出。' }; }
  },
};

/* ═══════════ 官方模式随身面板(AIDE:灵机推演 + 近24h战况 + 我的记录)═══════════
   官方象限里游戏主体是 iframe,这三块信息以「游戏下方的随身面板」补齐,与 DIY 盘
   共用同一套组件(rgPredictHtml / rgRoadHtml,含位数设置与末位倒计时珠,口径完全一致)。
   我的记录按数据模式取源:真实=官方 recordList;模拟=直读 iframe 引擎法术记录(同源可达)。 */
const AIDE = { tab: 'trend', open: true, size: (store.get(KEY.aideSize) === 'tall' ? 'tall' : 'normal'), timer: 0, lastRound: 0, mode: '', records: null, recNote: '', loading: false, predSeen: '', roadFit: 0,
               acctFor: '', acctBusy: false, acctGuard: '', acctSeen: '' };   // 真实×官方顶部账号条(与 DIY .rg-acct 同款)
/* P2:折叠钮由二态升三态 —— 收起 / 常规 / 加高。
   实测移动端 .of-aide 恒锁 186px(桌面那条成长曲线只写给了 ≥1024),
   932 高的机器与 667 高的机器拿到一样的战况高度。三档把「游戏优先 / 数据优先」
   交回用户,并持久化(设备级键,与 jf2:rgCols 同规,不带用户命名空间)。
   ★ 侧栏形态(容器 ≥620px 且 宽:高 ≥0.62)下 aide 本就是通高侧列,
     加高无意义 —— CSS 侧在该容器查询内显式复位(见 app.css P2-d 复审补)。 */
const AIDE_SIZE_LABEL = {
  fold:   { icon:'▴',  aria:'展开数据面板', tip:'展开:推演 / 战况 / 记录' },
  normal: { icon:'▾',  aria:'加高战况',     tip:'加高:把更多高度分给 24h 战况' },
  tall:   { icon:'▾▾', aria:'收起数据面板', tip:'收起:把全部高度还给游戏' },
};
const AIDE_SIZE_NEXT = { fold:'normal', normal:'tall', tall:'fold' };
function aideSize(){ return AIDE.open ? (AIDE.size === 'tall' ? 'tall' : 'normal') : 'fold'; }
function aideActive(){ return S.jiufa && S.rgSkin === 'official'; }
function aideMode(){ return S.gameTab === 'real' ? 'real' : 'sim'; }

/* 名录「当前账号」变更(切换 / 扫码登录成功)→ 正在展示真实数据的面即时换新:
   官方账号条立刻重取(记录一并失效);DIY 真实盘立刻补一拍轮询,不等 4s。 */
function acctCurrentMaybeChanged(cur){
  cur = String(cur || '');
  if (!cur) return;
  if (RG.account && String(RG.account.kugouId) === cur) return;
  AIDE.acctFor = '';
  if (aideActive() && aideMode() === 'real'){ AIDE.records = null; aideLoadAcct(true); }
  else if (rgActive() && RG.mode === 'real') rgPoll();
}

/* 顶部账号条(仅真实×官方):完全复用 DIY 的 rgAcctHtml —— 头像/昵称/有效徽章/星币/ID/换号/刷新,一处样式两处同。 */
function renderOfficialAcct(){
  const box = D.officialAcct; if (!box) return;
  if (!(aideActive() && aideMode() === 'real')){ box.hidden = true; return; }
  box.hidden = false;
  if (RG.account){ box.innerHTML = rgAcctHtml(); stickPinAll(); }   // 4.7.2:账号条(含无固定尺寸的头像)改高度 → 随身面板战况被压矮,补贴底
  else {
    const msg = AIDE.acctBusy ? '正在读取账号…' : (AIDE.acctGuard || '未选择有效账号,无法用星币施法。');
    box.innerHTML = `<div class="of-acct-note"><span>${esc(msg)}</span>${AIDE.acctBusy ? '' : '<button class="of-aide-lnk" data-acct-go>去账号列表</button>'}</div>`;
  }
  if (!box._acctBound){
    box._acctBound = true;
    box.addEventListener('click', e => {
      if (e.target.closest('[data-acct-go]') || e.target.closest('[data-act="pickacct"]')) return rgGotoAccounts();
      if (e.target.closest('[data-act="refresh"]')){
        const kid = RG.account && RG.account.kugouId;
        if (kid) rgRefreshCoin(); else aideLoadAcct(true);            // 权威余额 + 名录同步;指纹监听会自动重绘本条
      }
    });
  }
}
async function aideLoadAcct(force){
  if (AIDE.acctBusy || aideMode() !== 'real') return;
  if (!S.alias) return;
  if (!force && AIDE.acctFor === S.alias && RG.account) return;
  AIDE.acctBusy = true; renderOfficialAcct();
  try {
    const d = await gapi('/api/game/state?room=' + encodeURIComponent(S.alias), { timeout: 9000 });
    if (d.account) RG.account = d.account;
    if (Array.isArray(d.spells) && d.spells.length) RG.spells = d.spells;   // 缓存法术表:星币桥按真实 spellPrice 下单,杜绝退回 1000 的老价格坑
    AIDE.acctGuard = (d.gameOk === false) ? (d.message || '账号未就绪') : (d.account ? '' : '未选择有效账号,无法用星币施法。');
  } catch (_){ AIDE.acctGuard = '账号信息读取失败,可点刷新重试。'; }
  finally {
    AIDE.acctFor = S.alias; AIDE.acctAt = Date.now();     // 成败都记「已尝试」:失败不进 0.5s 风暴,15s 后 tick 才温和重试
    AIDE.acctBusy = false; renderOfficialAcct();
  }
}

function renderAide(){
  const box = D.officialAide; if (!box) return;
  const tab = (v, label) => `<button data-aide-tab="${v}" class="${AIDE.tab === v ? 'is-on' : ''}">${label}</button>`;
  box.innerHTML = `
    <div class="of-aide-head">
      <div class="of-aide-nav">${tab('trend', '推演 · 战况')}${tab('records', '我的记录')}</div>
      <button class="of-aide-fold" data-aide-fold aria-label="${AIDE_SIZE_LABEL[aideSize()].aria}" title="${esc(AIDE_SIZE_LABEL[aideSize()].tip)}">${AIDE_SIZE_LABEL[aideSize()].icon}</button>
    </div>
    <div class="of-aide-body"${AIDE.open ? '' : ' hidden'}>${aideBodyHtml()}</div>`;
  box.toggleAttribute('data-folded', !AIDE.open);           // 折叠时 CSS 解除游戏舞台的纵横比封顶(高度还给游戏)
  box.setAttribute('data-size', aideSize());                // P2:收起 / 常规 / 加高 三档
  AIDE.predSeen = rgPredToken();
  bindAide(box);
  /* 4.7.2:战况节点每次重渲染都是新节点 —— 逐次登记守卫(幂等),由它此后维持贴底。
     这是「手机 + 官方盘、刚载入就偏」的正面修复点:原先此处只同步贴一次,
     而 .of-aide 的高度在地址栏收起/推演带换血/头像落位之后还会再变好几次。 */
  const road = box.querySelector('[data-rg-road]');
  if (road){ stickInit(road, { anchor: 'bottom' }); stickPin(road, { force: true }); }
}
function aideBodyHtml(){
  if (AIDE.tab === 'records') return aideRecordsHtml();
  return rgPredictHtml() + rgRoadHtml();                 // 与 DIY 完全同一套推演带 + 24h 战况(共用位数设置)
}

/* 我的记录:真实=官方接口;模拟=iframe 引擎法术记录(pending + 已结算) */
function aideRecordsHtml(){
  if (aideMode() === 'sim') return aideSimRecordsHtml();
  if (AIDE.records == null){ aideLoadRecords(); return rgLoadingHtml('正在读取我的记录…'); }
  if (AIDE.recNote){
    return `<div class="rg-empty">${esc(AIDE.recNote)} <button class="of-aide-lnk" data-aide-acct>去账号列表</button></div>`;
  }
  if (!AIDE.records.length) return '<div class="rg-empty">还没有游戏记录 · 施一次法就有啦</div>';
  return `<div class="rg-records">${AIDE.records.slice(0, 30).map(rgRecItemHtml).join('')}</div>`;
}
async function aideLoadRecords(){
  if (AIDE.loading) return; AIDE.loading = true;
  try {
    const d = await gapi('/api/game/records', { timeout: 9000 });
    if (d.gameOk === false){ AIDE.records = []; AIDE.recNote = d.message || '需要有效账号才能读取记录。'; }
    else { AIDE.records = Array.isArray(d.recordList) ? d.recordList : []; AIDE.recNote = ''; }
  } catch (_){ AIDE.records = []; AIDE.recNote = '记录读取失败,可稍后重试。'; }
  finally { AIDE.loading = false; if (aideActive() && AIDE.tab === 'records') renderAide(); }
}
function aideSpellName(sid){
  const sp = (S.spells || []).find(x => Number(x.beast_id) === Number(sid));
  return sp ? { spell: sp.spell_name || '', beast: sp.beast_name || '' } : { spell: '法术' + sid, beast: '' };
}
function aideSimRecordsHtml(){
  let st = null;
  try { st = D.jiufaFrame && D.jiufaFrame.contentWindow && D.jiufaFrame.contentWindow.JiufaSim && D.jiufaFrame.contentWindow.JiufaSim.state; } catch (_){ st = null; }
  if (!st) return '<div class="rg-empty">游戏加载中…法术记录稍后可见</div>';
  const rows = [];
  const settledIds = Object.keys(st.settled || {}).map(Number).filter(Number.isFinite).sort((a, b) => b - a);
  const pendIds = Object.keys(st.bets || {}).map(Number).filter(Number.isFinite).sort((a, b) => b - a);
  for (const rid of pendIds){                                        // 待开法术记录
    const bk = (st.bets[String(rid)] || {}).s || {};
    const stake = Object.entries(bk).reduce((n, [sid, c]) => n + (+c || 0) * 1000, 0);
    if (!stake) continue;
    const chips = Object.entries(bk).map(([sid, c]) => { const nm = aideSpellName(sid); return `<span class="rg-rec-chip"><b>${esc(nm.spell)}</b> 克【${esc(nm.beast)}】<em>×${esc(String(c))}</em></span>`; }).join('');
    rows.push(`<div class="rg-rec"><div class="rg-rec-head"><span class="rg-rec-when">${fmtClock(rid)}</span><span class="rg-rec-st" data-st="none">待开</span><span class="rg-rec-gain is-out">-${stake}</span></div><div class="rg-rec-spells">${chips}</div></div>`);
  }
  for (const rid of settledIds){                                     // 已结算(仅本人参与过的局)
    const lt = st.settled[String(rid)] || {}; const sm = lt.sim || {};
    const stake = +sm.totalStake || 0; if (!stake) continue;
    const win = lt.st === 1;
    const chips = Object.entries(sm.bets || {}).map(([sid, c]) => { const nm = aideSpellName(sid); return `<span class="rg-rec-chip"><b>${esc(nm.spell)}</b> 克【${esc(nm.beast)}】<em>×${esc(String(c))}</em></span>`; }).join('');
    rows.push(`<div class="rg-rec"><div class="rg-rec-head"><span class="rg-rec-when">${fmtClock(rid)}</span><span class="rg-rec-st" data-st="${win ? 'win' : 'miss'}">${win ? '命中' : '未中'}</span><span class="rg-rec-gain ${win ? 'is-in' : 'is-out'}">${win ? '+' + (+sm.grossWin || 0) : '-' + stake}</span></div><div class="rg-rec-spells">${chips}<span class="rg-rec-note">开出【${esc(sm.beastName || '')}】</span></div></div>`);
    if (rows.length >= 30) break;
  }
  if (!rows.length) return '<div class="rg-empty">还没有模拟法术记录 · 在上方游戏里施一次法就有啦</div>';
  return `<div class="rg-records">${rows.join('')}</div>`;
}

/* 每 500ms:末位倒计时珠(连续读秒→开,与 DIY/序列同口径)+ 新局落地时重建战况与推演 */
function aideTick(){
  if (!aideActive()) return;
  const box = D.officialAide; if (!box) return;
  if (aideMode() === 'real'){                               // 顶部账号条:alias 落位即取;施法/刷新后指纹一变就地重绘
    if (!AIDE.acctBusy && S.alias){
      if (AIDE.acctFor !== S.alias) aideLoadAcct();
      else if (!RG.account && Date.now() - (AIDE.acctAt || 0) > 15000) aideLoadAcct(true);   // 温和重试:15s 一次,绝不 0.5s 风暴
    }
    const a = RG.account;
    const fp = a ? `${a.kugouId}|${a.coin}|${a.validStatus || ''}` : `-|${AIDE.acctBusy ? 'b' : ''}${AIDE.acctGuard}`;
    if (fp !== AIDE.acctSeen){ AIDE.acctSeen = fp; renderOfficialAcct(); }
  }
  const now = nowC(), cs = curStart(now), sp = cs + T.CAST, dr = cs + T.DRAW;
  const pend = box.querySelector('[data-rg-pending]');
  if (pend){
    const drawing = now >= dr;
    // 3.1.1:施法期 + 备战期同属「距出怪」这一段,末位珠连续读秒到出怪(不再在 sp 处换成「封」字)
    // 3.4.5:与主序列 tick 同判据同三态 —— 结果一上盘即改读秒至下一局出怪(跨局连续),
    //        「开」专属等待态;两处「同源」战况自此不再打架(旧版提前到账期主盘已「开」这里仍在倒数)。
    const h0 = S.hist[0];
    const landed = !!(h0 && h0.start === cs);
    if (landed){
      pend.textContent = String(Math.max(1, Math.ceil((cs + T.ROUND + T.DRAW - now) / 1000)));
      pend.classList.remove('is-seal', 'is-draw');
      if (pend.title !== PEND_TITLES.next) pend.title = PEND_TITLES.next;
    } else {
      pend.textContent = drawing ? '开' : String(Math.max(0, Math.ceil((dr - now) / 1000)));
      pend.classList.toggle('is-seal', !drawing && now >= sp);   // 相位仍由配色标注
      pend.classList.toggle('is-draw', drawing);
      const tt = drawing ? PEND_TITLES.wait : PEND_TITLES.this;
      if (pend.title !== tt) pend.title = tt;
    }
  }
  const pt = rgPredToken();                                 // 推演到达/更新:就地换推演带(修官方模式「----悬置」)
  if (pt !== AIDE.predSeen){
    AIDE.predSeen = pt;
    if (AIDE.open && AIDE.tab === 'trend'){
      const el = box.querySelector('.rg-pred');
      /* 4.7.2:推演带就地换血会改高度(「等待」两枚灰片 → 带命中率统计的形态),
         战况被压矮而滚动位不动 = 掉出底部。换完立刻补一次贴底。 */
      if (el){ el.outerHTML = rgPredictHtml(); const rd = box.querySelector('[data-rg-road]'); if (rd) stickPin(rd); }
    }
  }
  const fitNow = rgRoadFitCols();                           // 4.1 面板宽变(停靠↔侧栏/拖窗跨档)→ 就地按新档重排战况
  if (fitNow !== AIDE.roadFit){
    const first = !AIDE.roadFit;
    AIDE.roadFit = fitNow;
    if (!first && AIDE.open && AIDE.tab === 'trend'){
      const body = box.querySelector('.of-aide-body');
      if (body){ body.innerHTML = aideBodyHtml(); const road = body.querySelector('[data-rg-road]'); if (road){ stickInit(road, { anchor: 'bottom' }); stickPin(road, { force: true }); } }
    }
  }
  const cur = (S.hist && S.hist[0]) ? S.hist[0].start : 0;
  if (cur && cur !== AIDE.lastRound){
    AIDE.lastRound = cur;
    if (AIDE.open){                                          // 新局落地:战况/推演重建;记录页同样就地重读(模拟盘新结算即刻可见)
      const body = box.querySelector('.of-aide-body');
      if (body){ body.innerHTML = aideBodyHtml(); const road = body.querySelector('[data-rg-road]'); if (road){ stickInit(road, { anchor: 'bottom' }); stickPin(road, { force: true }); } }
    }
  }
}
function aideStart(){
  const mode = aideMode();
  if (AIDE.mode !== mode){ AIDE.mode = mode; AIDE.records = null; AIDE.recNote = ''; AIDE.acctFor = ''; AIDE.acctGuard = ''; }   // 换数据模式:记录/账号换源重取
  AIDE.lastRound = (S.hist && S.hist[0]) ? S.hist[0].start : 0;
  renderAide();
  renderOfficialAcct();
  clearInterval(AIDE.timer); AIDE.timer = setInterval(aideTick, 500);
}
function aideStop(){ clearInterval(AIDE.timer); AIDE.timer = 0; }
function bindAide(box){
  if (box._aideBound) return; box._aideBound = true;
  box.addEventListener('click', e => {
    const t = e.target.closest('[data-aide-tab]');
    if (t){ AIDE.tab = t.getAttribute('data-aide-tab'); renderAide(); return; }
    if (e.target.closest('[data-aide-fold]')){                 // P2:三档循环 收起→常规→加高→收起
      const nx = AIDE_SIZE_NEXT[aideSize()];
      AIDE.open = nx !== 'fold';
      AIDE.size = (nx === 'tall') ? 'tall' : 'normal';
      store.set(KEY.aideSize, AIDE.size);
      renderAide(); return;
    }
    if (e.target.closest('[data-rg-full]')){ openWide(); return; }   // P2:一键全屏战况(复用成熟的 #wideView)
    if (e.target.closest('[data-aide-acct]')){ rgGotoAccounts(); return; }
  });
  box.addEventListener('change', e => {
    const cols = e.target.closest('[data-rg-cols]');
    if (cols){ const v = Number(cols.value); if (ROAD_COL_OPTIONS.includes(v)){ RG.cols = v; store.set(KEY.rgCols, String(v)); renderAide(); } }
  });
}

/* ── 轮询官方牌面(4s 一次;仅真实模式)──────────────────────────────── */
async function rgPoll(){
  if (!rgActive() || RG.mode === 'sim') return;   // 模拟模式绝不发官方请求(本地 simSync 驱动)
  const room = S.alias;
  if (!room){
    if (!S.roomsReady || (S.rooms && S.rooms.length)){ if (!RG.state && RG.guard){ RG.guard = null; rgSyncRender(); } return; }   // 暂态:保持「正在读取…」载入
    RG.guard = { kind: 'business', message: '先添加一个直播间,再来玩真实游戏。' }; rgSyncRender(); return;   // 5.0.2:同上,按钮就在守卫卡上
  }
  let d;
  try { d = await gapi('/api/game/state?room=' + encodeURIComponent(room), { timeout: 9000 }); }
  catch (_){ if (!RG.state){ RG.guard = { kind: 'network', message: '网络不稳,正在重试…' }; rgSyncRender(); } return; }
  RG.account = d.account || RG.account;
  if (d.gameOk === false){ RG.guard = { kind: d.kind || 'api', message: d.message || '暂时无法加载官方牌面' }; rgSyncRender(); return; }
  RG.guard = null;
  RG.room = d.room || room;
  RG.anchorUid = d.anchorUid ?? RG.anchorUid;
  rgClockSync(+d.serverTime);
  RG.roundId = d.roundId;
  RG.spellTime = +d.spellTime || 0;
  RG.drawTime = +d.drawTime || 0;
  RG.endTime = +d.endTime || 0;
  RG.canPlay = d.canPlay !== false;
  RG.tips = Array.isArray(d.tips) ? d.tips : [];
  if (Array.isArray(d.spells) && d.spells.length) RG.spells = d.spells;
  RG.state = true;
  if (RG.sel == null || !RG.spells.some(s => s.spellId === RG.sel)) RG.sel = RG.spells[0] ? RG.spells[0].spellId : null;
  rgSyncRender();
}

/* ── 细分节拍(250ms):倒计时刷新 + 到点拉奖 / 模拟结算 + 到点续拉 / 换局 ── */
function rgTick(){
  if (!rgActive()) return;
  if (RG.mode === 'sim' && !RG.state){
    // 模拟盘自愈:引导/载入态下每拍(250ms)本地重探 —— 你在左侧一选好直播间、
    // 或法术表一加载完,盘面立即自动铺开,不需要来回切页签。(纯本地判断,零网络开销)
    const g0 = RG.guard ? RG.guard.kind + (RG.guard.message || '') : '-';
    simSync();
    const g1 = RG.guard ? RG.guard.kind + (RG.guard.message || '') : '-';
    if (RG.state || g0 !== g1){ rgSig(''); rgSyncRender(); }
    if (!RG.state) return;
  }
  if (RG.mode === 'real' && !RG.state && S.alias && RG.aliasKick !== S.alias){
    RG.aliasKick = S.alias; rgPoll();                     // 开机窗口结束(alias 刚落位):立刻取盘,不等 4s 轮询
  }
  if (!RG.state) return;
  const pt = rgPredToken();                               // 灵机推演到达/更新:就地只换推演带(不整屏重绘,修「----悬置」)
  if (pt !== RG.predSeen){ RG.predSeen = pt; const el = rgBox() && rgBox().querySelector('.rg-pred'); if (el) el.outerHTML = rgPredictHtml(); }
  const p = rgPhaseNow();
  rgUpdateRound(p);
  rgUpdateLocks(p);
  if (RG.mode === 'sim'){
    simSettleTick();                                          // 观测台实录一到即兑付 + 弹出怪条
    const cs = curStart(nowC());
    if (cs !== RG.roundId){ simSync(); rgSyncRender(); }      // 栅格换局:就地铺新盘(清本局攻击次数徽记)
    return;
  }
  if (p.phase === 'draw' && RG.awardFetchedRound !== RG.roundId && rgClock() >= RG.drawTime + 2500){
    RG.awardFetchedRound = RG.roundId;
    rgFetchAward(RG.roundId);
  }
  if (p.ended && RG.roundId && RG.endPolledRound !== RG.roundId){
    RG.endPolledRound = RG.roundId;
    setTimeout(() => { if (rgActive()) rgPoll(); }, 400);   // 进入下一局
  }
}

/* 本局出怪详情(命中/未中/未参与 + 奖励)*/
async function rgFetchAward(round){
  try {
    const d = await gapi('/api/game/award?room=' + encodeURIComponent(S.alias) + '&round=' + encodeURIComponent(round));
    if (d.gameOk === false) return;
    RG.award = d;
    rgSig(''); rgSyncRender();
    if (d.awardStatus === 1) rgHitAnimation(d);
    if (d.awardStatus === 1 || d.awardStatus === 2) rgRefreshCoin();
  } catch (_){ /* 拉奖失败不打断 */ }
}

/* 渲染签名:仅"骨架级"字段;变了才整屏重绘,否则走软更新 */
function rgComputeSig(){
  const a = RG.account;
  const sp = RG.spells.map(s => s.spellId).join('.');
  return [
    RG.mode,                                         // 模式切换(真实/模拟)必然整屏重绘
    RG.guard ? RG.guard.kind : 'ok',
    RG.state ? '1' : '0',
    RG.view, RG.roundId || '', RG.sel == null ? '' : RG.sel, sp,
    RG.canPlay ? '1' : '0',
    RG.award ? (RG.award.roundId + ':' + RG.award.awardStatus) : '-',
    a ? (a.kugouId + ':' + (a.validStatus || '')) : '-',
    RG.confirm ? ('cf' + RG.confirm.spellId + 'x' + RG.confirm.count) : '-',
    RG.castErr ? ('e' + (RG.castErr.kind || '')) : '-',
    (S.spells && S.spells.length) ? 'no1' : 'no0',   // 观测台号位就绪 → 触发一次整屏重绘补上编号
    'rc' + rgRoadFitCols(),                          // 4.1 容器可容位数档:拖窗跨档即重绘战况(夹紧随宽实时生效)
  ].join('|');
}
function rgSyncRender(){
  if (!rgActive()) return;
  const sig = rgComputeSig();
  if (sig !== RG.sig){ RG.sig = sig; renderRealGame(); }
  else rgSoftUpdate();
}

/* ── 整屏渲染 ──────────────────────────────────────────────────────────── */
function renderRealGame(){
  const box = rgBox(); if (!box) return;
  box.setAttribute('data-rg-size', RG.size);   // 5.0.9:高度档挂**常驻容器**(#realBody/#simBody),innerHTML 重建换不掉;真实/模拟两 DIY 象限共享同一档
  if (RG.guard){ box.innerHTML = rgGuardHtml(RG.guard); return; }
  if (!RG.state){ box.innerHTML = rgLoadingHtml(RG.mode === 'sim' ? '正在铺开模拟盘面…' : '正在读取官方牌面…'); return; }
  const parts = [
    rgAcctHtml(),
    rgRoundHtml(),
    rgNavHtml(),
    `<div class="rg-view" data-view="cast"${RG.view === 'cast' ? '' : ' hidden'}>${rgCastViewHtml()}</div>`,
    `<div class="rg-view" data-view="records"${RG.view === 'records' ? '' : ' hidden'}>${rgRecordsHtml()}</div>`,
    `<div class="rg-view" data-view="rank"${RG.view === 'rank' ? '' : ' hidden'}>${rgRankHtml()}</div>`,
  ];
  if (RG.confirm) parts.push(rgConfirmHtml());
  // 战况条:重绘前记下滚动状态 —— 贴底(看最新)则续贴底,否则保留用户查看历史的位置,避免整屏重绘时乱跳
  const oldRoad = box.querySelector('[data-rg-road]');
  /* 4.7.2 修「DIY 战况自锁死在顶部」(既有缺陷,基线复现):原判据是几何快照
     —— rgFitRoad 的 88px 地板把战况压到 88px 而内容 1606px,快照算出 1518 ≥ 24
     便误判成「用户在翻历史」,于是下一轮 snapScroll(road, prevTop=0) 钉死在顶,
     再下一轮又从这个「不在底部」的旧节点判出 false,自我循环,永无出口。
     改读守卫的 armed:它只由用户真实滚动翻转(程序化滚动有静默窗),布局抖动
     无论怎么折腾都动不了它 —— 既根治自锁死,又原样保住「上翻回看不被拽回」。 */
  const roadStick = !oldRoad || !oldRoad.__stick || oldRoad.__stick.armed;
  const roadPrevTop = oldRoad ? oldRoad.scrollTop : 0;
  box.innerHTML = parts.join('');
  const p = rgPhaseNow(); rgUpdateRound(p); rgUpdateLocks(p);
  if (RG.view === 'cast') requestAnimationFrame(() => rgFitRoad(roadStick, roadPrevTop));   // 视口够高时战况吃满剩余高度 + 定位滚动
  if (RG.mode !== 'sim'){                                                                   // 模拟盘的记录本地即取,榜单不适用
    if (RG.view === 'records' && RG.records == null && !RG.loadingRec) rgLoadRecords();
    if (RG.view === 'rank' && RG.rank == null && !RG.loadingRank) rgLoadRank();
  }
}

/* 战况自适应高度:视口够高时,让「近24小时战况」吃满从战况条顶到面板底的剩余空间(不写死高度);
   视口偏矮时保底 88px、内部仍可滚。stick=false 则保留用户查看历史的滚动位,否则贴底看最新。 */
function rgFitRoad(stick, prevTop){
  const box = rgBox(); if (!box) return;
  const road = box.querySelector('[data-rg-road]'); if (!road) return;
  const bodyBottom = box.getBoundingClientRect().bottom;
  const roadTop = road.getBoundingClientRect().top;
  const avail = Math.floor(bodyBottom - roadTop - 6);      // 5.0.8:底部留白 8→6(盘面底衬同批 6→5,留白仍大于底衬,十视口实测盘面不冒滚动条)
  road.style.maxHeight = Math.max(88, avail) + 'px';
  /* 4.7.2:同样交给守卫。stick===false = 用户此前在翻历史 → 恢复原位并让出控制权;
     否则接管并持续维持贴底(此前只贴一次,拖窗/换档/图片落位后即失效)。 */
  const st = stickInit(road, { anchor: 'bottom' });
  if (stick === false){
    /* 用户此前确在翻历史:恢复其读位并让出控制权。prevTop 夹回合法区间 ——
       maxHeight 刚变过,旧读位可能已越界(越界会被浏览器静默夹到底,反而假装贴底)。 */
    if (st) st.armed = false;
    snapScroll(road, Math.max(0, Math.min(prevTop || 0, road.scrollHeight - road.clientHeight)));
  } else stickPin(road, { force: true });
}
function rgSoftUpdate(){
  const box = rgBox(); if (!box) return;
  const a = RG.account;
  if (a){
    const coinEl = box.querySelector('.rg-acct-coin');
    if (coinEl){ const c = (a.coin === '' || a.coin == null) ? '—' : esc(String(a.coin)); coinEl.innerHTML = `<i>币</i>${c}`; }
  }
  const map = {}; RG.spells.forEach(s => { map[s.spellId] = s; });
  box.querySelectorAll('.rg-cell[data-spell]').forEach(cell => {
    const id = +cell.getAttribute('data-spell'); const s = map[id];
    const n = s ? (+s.spellNum || 0) : 0; const cur = cell.querySelector('.rg-cell-mine');
    if (n > 0){ if (cur) cur.textContent = n; else { const b = document.createElement('span'); b.className = 'rg-cell-mine'; b.textContent = n; cell.prepend(b); } }
    else if (cur) cur.remove();
  });
}

/* 账号头条:正在选择的账号(头像/昵称/有效性/星币/ID + 换号/刷新)*/
function rgAcctHtml(){
  if (RG.mode === 'sim'){                                  // 模拟盘:钱包栏(不涉及真实账号)
    const coin = simWallet();
    return `<div class="rg-acct is-sim">
      <span class="rg-acct-av rg-acct-simav" aria-hidden="true">模</span>
      <span class="rg-acct-meta">
        <span class="rg-acct-name">模拟钱包<span class="rg-acct-badge" data-st="sim">模拟</span></span>
        <span class="rg-acct-sub"><span class="rg-acct-coin"><i>币</i>${esc(coin.toLocaleString())}</span><span class="rg-acct-id">不扣真实星币</span></span>
      </span>
      <button class="rg-acct-switch" data-act="simreset" title="把模拟币重置为初始额度">重置</button>
      <button class="rg-acct-refresh" data-act="refresh" title="刷新模拟币" aria-label="刷新模拟币">⟳</button>
    </div>`;
  }
  const a = RG.account;
  if (!a) return `<div class="rg-acct"><span class="rg-acct-meta"><span class="rg-acct-name">未选择账号</span>
      <span class="rg-acct-sub">先在名录里登录并选中一个账号</span></span>
      <button class="rg-acct-switch" data-act="pickacct">去选择</button></div>`;
  const av = acctAvatar(a.userLogo);
  const vs = a.validStatus || '';
  const st = vs === 'valid' ? 'valid' : vs === 'invalid' ? 'invalid' : 'unknown';
  const stTx = st === 'valid' ? '有效' : st === 'invalid' ? '失效' : '未检测';
  const coin = (a.coin === '' || a.coin == null) ? '—' : esc(String(a.coin));
  return `<div class="rg-acct">
    <img class="rg-acct-av" src="${esc(av)}" alt="" onerror="this.style.visibility='hidden'">
    <span class="rg-acct-meta">
      <span class="rg-acct-name">${esc(a.nickName || ('酷狗' + a.kugouId))}<span class="rg-acct-badge" data-st="${st}">${stTx}</span></span>
      <span class="rg-acct-sub"><span class="rg-acct-coin"><i>币</i>${coin}</span><span class="rg-acct-id">ID ${esc(a.kugouId)}</span></span>
    </span>
    <button class="rg-acct-switch" data-act="pickacct" title="切换用于游戏的账号">换号</button>
    <button class="rg-acct-refresh" data-act="refresh" title="刷新星币/资料" aria-label="刷新星币">⟳</button>
  </div>`;
}

/* 局条:倒计时环 + 相位 + 局号 + 提示 */
function rgRingColor(phase){ return phase === 'cast' ? 'var(--brand)' : phase === 'seal' ? 'var(--gilt)' : phase === 'draw' ? 'var(--seal)' : 'var(--line-strong)'; }
/* 局条提示语:**两个 DIY 象限同一套**(4.9.1)。
   改前:真实盘优先取官方下发的 RG.tips[0] —— 那是一句**恒定的规则说明**
   (「每局出现一只妖兽,每种法术可击败一只妖兽」),既不随相位变化,又和左边的
   倒计时环 / 相位标在语义上重复;而模拟盘因为 RG.tips 恒为空(见 simSync),
   反倒走了随相位走字的分支。同一个 DIY 盘、两个象限行为不一致,这是缺陷不是设计。
   现统一走相位文案。官方那句规则说明并不丢 —— 移到 title 上,悬停可见,零布局成本。 */
function rgHintText(p){
  return p.phase === 'cast' ? '选妖兽 · 布置法术'
       : p.phase === 'seal' ? '备战中 · 待出怪'
       : p.phase === 'draw' ? '出怪中…'
       : '等待下一局';
}
function rgHintTitle(){
  return (RG.tips && RG.tips[0]) ? String(RG.tips[0]) : '';
}
function rgRoundHtml(){
  const p = rgPhaseNow();
  const no = RG.roundId ? dayNo(RG.roundId) : '——';
  const tt = rgHintTitle();
  return `<div class="rg-round">
    <div class="rg-round-ring" style="--p:${p.pct.toFixed(0)};--rc:${rgRingColor(p.phase)}"><b>${p.secs}</b></div>
    <div class="rg-round-info"><span class="rg-round-phase" data-p="${p.phase}">${p.label}</span><span class="rg-round-no">第 ${no} 局</span></div>
    <span class="rg-round-hint"${tt ? ` title="${esc(tt)}"` : ''}>${esc(rgHintText(p))}</span>
  </div>`;
}
function rgUpdateRound(p){
  const box = rgBox(); if (!box) return;
  const ring = box.querySelector('.rg-round-ring');
  if (ring){ ring.style.setProperty('--p', p.pct.toFixed(0)); ring.style.setProperty('--rc', rgRingColor(p.phase)); const b = ring.querySelector('b'); if (b) b.textContent = p.secs; }
  const ph = box.querySelector('.rg-round-phase'); if (ph){ ph.textContent = p.label; ph.setAttribute('data-p', p.phase); }
  /* 4.9.1:提示语此前**只在整屏重绘时**才重算 —— 而整屏重绘只发生在换局/换态,
     于是一局之内 施法→备战→出怪 三个相位翻过去,提示还停在开局那句。两个象限同病。
     此处随 250ms 心跳就地更新(与相位标同一拍),提示才真的跟着相位走。
     只在文本确有变化时写 DOM:250ms 一次的空转赋值会让这条常驻栏白白吃重排。 */
  const hn = box.querySelector('.rg-round-hint');
  if (hn){
    const tx = rgHintText(p);
    if (hn.textContent !== tx) hn.textContent = tx;
    const tt = rgHintTitle();
    if ((hn.getAttribute('title') || '') !== tt){
      if (tt) hn.setAttribute('title', tt); else hn.removeAttribute('title');
    }
  }
  const pend = box.querySelector('[data-rg-pending]');
  if (pend){                                            // 战况末位「待开」珠:距出怪连续读秒 → 开(与九法阵/序列同口径)
    // p.secs 本就是 rgPhaseNow 合并施法+备战两窗后的「距出怪」秒数,直接用即可
    // 3.4.5:与主序列同三态。此路珠子取自 S.hist、计时取官方钟(RG.*)——landed 判据
    //        用官方局号对齐实录(roundId 即 50001 栅格上的局起始 ms,dayNo/fmtClock 同源),
    //        下局出怪 = 官方 drawTime + ROUND;phase==='wait'(未开局)沿用旧显示。
    const h0 = S.hist && S.hist[0];
    const landed = p.phase !== 'wait' && !!(h0 && h0.start === Number(RG.roundId));
    if (landed){
      pend.textContent = String(Math.max(1, Math.ceil((+RG.drawTime + T.ROUND - rgClock()) / 1000)));
      pend.classList.remove('is-seal', 'is-draw');
      if (pend.title !== PEND_TITLES.next) pend.title = PEND_TITLES.next;
    } else {
      pend.textContent = p.phase === 'draw' ? '开' : String(p.secs);
      pend.classList.toggle('is-seal', p.phase === 'seal');
      pend.classList.toggle('is-draw', p.phase === 'draw');
      const tt = p.phase === 'draw' ? PEND_TITLES.wait : PEND_TITLES.this;
      if (pend.title !== tt) pend.title = tt;
    }
  }
}
/* 相位闸:不可施法时锁网格 + 禁施法钮/步进 */
function rgUpdateLocks(p){
  const box = rgBox(); if (!box) return;
  const locked = !p.canCast;
  box.querySelectorAll('.rg-cell[data-spell]').forEach(c => c.classList.toggle('is-locked', locked));
  const btn = box.querySelector('.rg-cast-btn'); if (btn) btn.disabled = locked || RG.castBusy || RG.sel == null;
  box.querySelectorAll('.rg-step button, .rg-step input').forEach(el => { el.disabled = locked; });
}

/* 内页签 */
function rgNavHtml(){
  const tab = (v, label) => `<button data-view="${v}" class="${RG.view === v ? 'is-on' : ''}">${label}</button>`;
  const rank = RG.mode === 'sim' ? '' : tab('rank', '榜单');   // 榜单是官方实盘数据,模拟盘不适用
  return `<div class="rg-nav">${tab('cast', '施法盘')}${tab('records', '我的记录')}${rank}</div>`;
}

/* 施法盘视图 = 结果横幅 + 九妖兽格 + 近局序列 + 施法条 */
function rgCastViewHtml(){ return rgCastErrHtml() + rgResultHtml() + rgGridHtml() + rgPredictHtml() + rgCastbarHtml() + rgRoadHtml(true); }
/* 施法失败友好提示:把可读原因(余额不足 / 票据过期 / 备战中 / 网络不稳…)明明白白摆在盘面顶部,
   而不是一闪而过的 toast;附对应操作(去账号列表 / 重新检测 / 关闭)。 */
function rgCastErrHtml(){
  const e = RG.castErr; if (!e) return '';
  const kind = e.kind || 'business';
  const seal = kind === 'invalid' ? '验' : kind === 'network' ? '网' : '注';
  const msg = esc(e.message || '施法未成功,请重试');
  let act = '<button class="rg-cerr-btn" data-act="err-close">知道了</button>';
  if (kind === 'invalid') act = '<button class="rg-cerr-btn" data-act="pickacct">去账号列表</button><button class="rg-cerr-btn is-alt" data-act="recheck">重新检测</button>';
  else if (kind === 'network') act = '<button class="rg-cerr-btn" data-act="err-close">知道了</button>';
  return `<div class="rg-cerr" data-kind="${kind}" role="alert">
    <span class="rg-cerr-seal">${seal}</span>
    <div class="rg-cerr-body"><span class="rg-cerr-title">施法未成功</span><span class="rg-cerr-msg">${msg}</span></div>
    <button class="rg-cerr-x" data-act="err-close" aria-label="关闭提示">×</button>
    <div class="rg-cerr-acts">${act}</div></div>`;
}
/* 灵机推演(主/防号位):与观测台同一份后端集成预测(S.pred),号位/配色同源,方便据此选妖兽布法。
   4.7.5 指纹口径:末两位原为 accuracy.n|accuracy.replay。角标移除后 replay 不再进入
   任何渲染,留着只会让补算扫描每跑一轮就白重绘一次推演带;而真正被渲染的
   main/cover 反倒不在指纹里 —— 窗口跑满后 n 恒等于 window(默认 100)不再变化,
   此时若只有命中数变了,指纹判等 ⇒ 随身面板的命中率行漏刷、挂着旧数字。
   ★ 这条**不是**理论隐患,可达路径已查证 —— web.py 的 3.4.6 换手回退:某局结算后、
     下一局预测尚未写出的窗口里,`pending_prediction` 取不到行,回退到
     `latest_prediction` 且恰好 `lp.round_id == latest` ⇒ 回给前端的
     target_round_id / main / guard **与结算前逐字节相同**,而该局刚落的判定
     已经进了 accuracy 的 main/cover。此时旧指纹三位(nextStart|main|guard)全等、
     n 因跑满不变、replay 因是实盘行不变 ⇒ 整串判等,命中率行停在旧数字。
     (该窗口正是 web.py 注释里「真机 HAR 实证 22% 命中」的那一个,不是罕见路径。)
   故整位换成 n|main|cover —— 指纹恰好覆盖 predStatText 真正读的三个字段,不多不少。
   取值安全:accuracy 整体来自后端(S.pred.accuracy = d.accuracy || null),
   main/cover 是比 replay 更早的旧三键,任何版本后端都带;缺失时也只是稳定地
   落到 undefined 串,不会抖动。 */
function rgPredToken(){
  const p = S.pred || {}, a = p.accuracy;
  // 4.9.3:末位追加 window —— 缺口注脚(rgPredictHtml 的 gap 子句)读它,
  // 渲染依赖必须全员入指纹,否则「注脚变了指纹没变」= 漏刷(4.7.5 同一教训)。
  return `${p.nextStart || 0}|${(p.main || []).join('')}|${(p.guard || []).join('')}`
       + `|${a ? a.n : 0}|${a ? a.main : 0}|${a ? a.cover : 0}|${a && a.window ? a.window : 0}`;
}
function rgPredictHtml(){
  const p = S.pred || {};
  const ready = Array.isArray(p.main) && p.main.length;
  const pct = n => (Array.isArray(p.ens) && p.ens[n - 1] != null) ? ` · ${(p.ens[n - 1] * 100).toFixed(1)}%` : '';
  const chip = n => {
    const sp = (S.spellByN && S.spellByN[n]) || {};
    return `<i class="rg-pchip" style="--e:var(--e${n})" title="号位 ${n} · ${esc(sp.spell_key || ELEM[n] || '')} · ×${sp.multiplier ?? '—'}${pct(n)}">${n}</i>`;
  };
  const wait = '<i class="rg-pchip is-wait">–</i><i class="rg-pchip is-wait">–</i>';
  const mainC = ready ? p.main.map(chip).join('') : wait;
  const guardC = ready ? (p.guard || []).map(chip).join('') || wait : wait;
  const acc = p.accuracy;
  // 4.9.3:窗口未满时以子句说明缺口(文案与主卡 #predGap 同源:predGapText)。
  // predStatText 本体一个字节不动 —— 4.7.5 收束不变式;这里只是并列追加事实。
  const gap = predGapText(acc);
  const stat = (acc && acc.n)
    ? `${predStatText(acc)}${gap ? ` · ${gap}` : ''} · 仅供参考`
    : '预测仅供参考';
  // 5.0.8:统计行补 title(与观测台 #predStats 同一来源 predStatTitle,含命中率拆账)。
  // 桌面鼠标 B/C 档下该行并入单行、省略号收尾(app.css C7),悬停可取全文;触屏不合并、
  // 不省略,故 title 不渲染也不缺信息(全站 title 触屏一律不渲染,5.0.6 实证)。
  // 渲染依赖已入指纹:rgPredToken 末四位 n|main|cover|window 恰是 predStatTitle
  // 的全部读数,title 变则指纹必变,无漏刷(4.7.5 纪律)。
  const tt = (acc && acc.n) ? predStatTitle(acc) : '';
  return `<div class="rg-pred"><div class="rg-pred-row">
      <span class="rg-pred-tag is-main">主</span><span class="rg-pred-chips">${mainC}</span>
      <span class="rg-pred-tag is-guard">防</span><span class="rg-pred-chips">${guardC}</span></div>
    <p class="rg-pred-stat"${tt ? ` title="${esc(tt)}"` : ''}>灵机推演 · ${stat}</p></div>`;
}

/* 5.0.7 施法盘落位:3×3 → **双行 + 王格**。
     上行 3 4 5 6 · 下行 1 2 7 8 · 9 独占最右一列、纵跨两行。
   为什么是这个序(不是随手排的):按 room-321 实配核对,上行 3/4/5/6 出怪概率
   3.5%/6.5%/10%/10%(倍率 330/250/100/100)= 稀有档;下行 1/2/7/8 为
   20%/16%/16%/16%(10/50/50/50)= 常见档;号位 9 概率 2.00%、倍率 500,
   全场至稀至高 —— 故独占整列、格身最大。倍率随房配置浮动,概率分档不变。
   本数组是**唯一事实源**:DOM 输出序 = 视觉序(Tab 焦点不跳,WCAG 2.4.3),
   落位另由 app.css 的 .rg-cell[data-no=N] 显式指定,不依赖网格自动流 ——
   两道各自成立,任一侧被改也不会排错。 */
const RG_GRID_ORDER = [3, 4, 5, 6, 9, 1, 2, 7, 8];
function rgGridHtml(){
  // 妖兽按上述双行序排布(格内号位仍是观测台号位,与序列/战况编号一致);data-spell 仍用官方 spellId 供施法。
  const byNo = {};
  RG.spells.forEach(s => { const no = rgBeastNo(s.beast || {}) || s.spellId; if (!byNo[no]) byNo[no] = s; });
  const cells = [];
  for (const no of RG_GRID_ORDER){
    const ec = rgSpellColor(no), ecs = rgSpellColorS(no);
    const lord = no === 9 ? ' is-lord' : '';           // 王格:纵跨两行,内部另起一套排布(见 app.css)
    const s = byNo[no];
    if (!s){
      // data-no 两个分支都必须给:CSS 靠它落位,缺一格就会掉进自动流、整盘错位。
      cells.push(`<div class="rg-cell is-locked${lord}" data-no="${no}" style="--ec:${ec};--ecs:${ecs}" aria-disabled="true"><span class="rg-cell-no">${no}</span><div class="rg-cell-icon"></div><span class="rg-cell-name">—</span><span class="rg-cell-beast">未开放</span><span class="rg-cell-mult">—</span></div>`);
      continue;
    }
    const b = s.beast || {};
    const id = s.spellId;
    const sel = RG.sel === id ? ' is-sel' : '';
    const icon = rgImg(b.beastIcon || b.beastLogo || s.spellLogo);
    const mult = esc(s.iconFootText || (s.multiplier ? `${s.multiplier}倍` : ''));
    const mine = (+s.spellNum > 0) ? `<span class="rg-cell-mine">${s.spellNum}</span>` : '';
    // title 追加倍率:五列后格身变窄,过长的官方 iconFootText 会被省略号截断
    // (窄格里不截断就是横向溢出,二选一)。截断的字必须有地方取回 —— 这里就是。
    cells.push(`<div class="rg-cell${sel}${lord}" data-spell="${id}" data-no="${no}" role="button" tabindex="0" style="--ec:${ec};--ecs:${ecs}" title="号位 ${no} · ${esc(s.spellName)} · 克【${esc(b.beastName || '')}】${mult ? ` · ${mult}` : ''}">
      <span class="rg-cell-no">${no}</span>${mine}<img class="rg-cell-icon" src="${esc(icon)}" alt="" onerror="this.style.visibility='hidden'">
      <span class="rg-cell-name">${esc(s.spellName)}</span><span class="rg-cell-beast">${esc(b.beastName || '')}</span><span class="rg-cell-mult">${mult}</span></div>`);
  }
  return `<div class="rg-grid">${cells.join('')}</div>`;
}

/* P1:战况位数的**兜底默认**。此前写死 24,而 rgRoadFitCols 会按容器实宽夹紧,
   实测六款主流手机的实际生效档是 10/20/22/22/24/24 —— 同一份代码给出四种"默认"。
   现按视口二分:移动端 20(可读性与信息量的平衡点,且 320~430 全宽段可达),
   桌面维持 24(实测 1280/1440 逐字节不变)。用户显式改过档的持久值优先,此处只兜底。 */
function rgColsDefault(){ return innerWidth < 1024 ? 20 : 24; }
/* 战况行内缝(与 CSS .rg-road-row 的 gap 严格同源,两处必须同改):
   ≤380px 收到 3px —— 否则 320 宽机型 fit 只有 18,档池里根本没有 20 位。 */
function rgRoadGap(){ return innerWidth <= 380 ? 3 : 4; }
/* 4.1 战况位数按容器实宽夹紧 —— 珠格宽 <11.5px 时数字即不可读(与观测台
   S.cols 首访自适应同一口径):档位菜单只留当前容器装得下的档,渲染取
   min(用户档, 可容上限);容器变宽自动回到用户档 —— RG.cols 本身不被覆写,
   只有用户显式改档才持久。官方象限量随身面板实宽(停靠 559 / 侧栏 ~210),
   DIY 量盘面滚动体宽。30 ≈ 容器内衬 20~22 + 行内衬 4 + 纵滚动条 ~10 的
   合计预算;15.5 = 珠格下限 11.5 + 缝 4(与 .rg-road-row gap 同源)。 */
function rgRoadFitCols(){
  const box = (S.jiufa && S.rgSkin === 'official') ? D.officialAide : rgBox();
  const w = box && !box.hidden ? box.clientWidth : 0;
  if (!(w > 0)) return ROAD_COL_OPTIONS[ROAD_COL_OPTIONS.length - 1];   // 未上屏:不夹
  return Math.max(ROAD_COL_OPTIONS[0], Math.floor((w - 30) / (11.5 + rgRoadGap())));
}
/* ═══ 5.0.9:DIY「近24小时战况」高度档(常规/加高)—— 把「游戏优先 / 数据优先」交回用户 ═══
   用户实报(手机端):DIY 的战况容器比官方象限「感觉小、没法尽可能看更多数据」。
   真 Chromium 十视口逐容器实测(frontend_rg_road_probe.py,--baseline 口径)坐实三件事:
   ① 控制权不对称是主因 —— 官方象限 4.7.0 就有三态折叠钮(收起/常规/加高,KEY.aideSize),
      原注明言「三档把游戏优先/数据优先交回用户」;DIY 从未获得对等控制:战况只能吃
      rgFitRoad 算出的剩余,施法盘(208.4~234.6px)/施法条/账号条/局条/页签恒展开,
      用户想看数据也换不动一像素。官方加高档实测 390×844 战况行高 280px,
      而 DIY 恒 266px 且无档可调 —— 「官方能变大、DIY 不能」正是体感来源;
   ② 矮屏手机上 DIY 已在地板之下 —— 375×667 战况仅 62px(3 行),320×568 为 **−37px**
      (88px 地板顶着盘面溢出,须滚动才够到战况);
   ③ 5.0.8 的公开量测**不含结果横幅**,而 RG.award 只在换房/换模式时清空 —— 首局出怪后
      横幅(实测 60px 含缝)常驻,实况战况比公版数字再矮一截(375×667 实况 −5px,0 行)。
   药方:战况头新增「加高/还原」钮(KEY.rgSize 设备级持久,真实/模拟两 DIY 象限共享)。
   加高档**纯 CSS** 把施法盘收成速选条(app.css 5.0.9 节:图标/法术名/妖兽名隐去,
   号位徽记转正为主体 —— 与战况珠/推演片同一套号位配色,识别语义不换轨;倍率徽记保留,
   我的攻击数徽记保留,is-sel/is-locked/is-hit 三态与格上脉冲环全数照旧),结果横幅同批
   收衬;DOM/事件/data-no 落位零改动,省出的高度由 rgFitRoad 既有逻辑自动全数归战况。
   十视口实测(加高 vs 常规,战况可用高,px):
     手机 320 −37→69 | 375 62→168 | 360 195→301 | 390 266→426 | 430 345→514
     桌面坞 1024 204→364 | 1280 245→414 | 1440 345→514 | 1920 525→694 | 剧场 820 573→759;
   横幅在场时 375 实况 −5→111(0→6 行)。常规档十视口与 5.0.8 基线**逐像素相同**(零回归),
   倍率徽记全档零截断,战况头全档单行(≤380 容器同批隐去「位数」二字给标题让位 ——
   select 选项自带「N 位」且 aria-label 恒在,信息零删减)。
   ★ 信息取舍的诚实说明:加高档隐去的法术名/妖兽名**均一步可回** —— 点格即在施法条
     全文回显「御X术 · 克【X妖】」,确认层恒显全名;号位数字+配色本就是全站的妖兽
     身份语言(序列珠/战况珠/推演片同源)。这是用户显式选择、随时可还原的档位,
     与 4.9.3「静默截断=删信息」禁令针对的场景不同类。
   ★ 作用域纪律(与 5.0.8 同):新钮由本形参门控,只在 DIY 施法盘视图渲染 ——
     官方随身面板(aideBodyHtml 同样调本函数)不传参即无此钮,零改动;
     CSS 侧规则一律带 .rg-body[data-rg-size="tall"] 前缀,#wideView/.of-aide 天然隔离。 */
function rgToggleSize(){
  RG.size = RG.size === 'tall' ? 'normal' : 'tall';
  store.set(KEY.rgSize, RG.size);
  rgSig(''); rgSyncRender();   // 强制整屏重绘:属性/钮面/盘面同帧落位,rAF 里 rgFitRoad 按守卫 armed 续贴底或保读位(4.7.2 机制原样)
}
/* 按钮语义:可见文案随态翻转(加高⇄还原,始终描述「按下去会发生什么」),故按
   APG 按钮模式视作**动作钮**,不并用 aria-pressed —— 标签翻转 + pressed 同挂会让
   读屏播报自相矛盾(「还原,已按下」)。与官方象限折叠钮(AIDE_SIZE_LABEL,
   aria-label 随态翻转、无 pressed)同一模式;加高档的按钮着色由容器档位属性驱动
   (app.css S1:.rg-body[data-rg-size="tall"] .rg-road-size),单一事实源,
   不存在钮面属性与容器属性漂移的可能。 */
const RG_SIZE_LABEL = {
  normal: { txt:'加高', tip:'数据优先:施法盘收成速选条,省出的高度全部给战况(可随时还原)' },
  tall:   { txt:'还原', tip:'还原完整施法盘(妖兽图标 · 法术名 · 妖兽名)' },
};
function rgRoadHtml(sizeBtn){
  // 近 24 小时战况:取观测台本房实录 S.hist(与左侧序列/战况同源、同为观测台号位),
  // 只保留近 24h,按「旧 → 新」排列(最新在最右下)。每行位数走 RG.cols(独立键 jf2:rgCols,
  // 与观测台 S.cols/jf2:cols 解耦 —— 原注写「复用观测台档位(与左侧联动)」已与实现不符,此处订正)。
  const since = nowC() - 24 * 3600 * 1000;
  const rows = (S.hist || []).filter(r => Number(r.start) >= since && Number.isInteger(r.n) && r.n >= 1 && r.n <= 9);
  rows.reverse();   // S.hist 为「新 → 旧」;reverse 得「旧 → 新」
  /* 4.4.0 复审补:本条战况与左侧序列同源(S.hist),同样是一句「连续」的断言,
     故同样标断口。这是本轮查出的第三处 —— 前两处是主序列与按日回看。 */
  let rgPrev = 0;
  const beads = rows.map(r => {
    const g = rgPrev ? gapSlots(rgPrev, r.start) : 0;
    const vh = g > 0 ? voidHtml(g, rgPrev + T.ROUND, 'rg-bead-n') : '';   // P3:与主序列同一函数,口径不可能分叉
    rgPrev = r.start;
    return vh + `<span class="rg-bead-n" data-n="${r.n}"${g ? ` data-gap="${g}"` : ''} style="--ec:${rgSpellColor(r.n)}"`
      + ` title="第${dayNo(r.start)}局 · ${esc(r.beast || '')}（号位 ${r.n}）${g ? esc(gapTitle(g)) : ''}">${r.n}</span>`;
  }).join('');
  // 末位「待开」珠:与九法阵同理,在战况最后一位显示距出怪倒计时(rgUpdateRound 每拍刷新)
  const pend = `<span class="rg-bead-n rg-bead-pending" data-rg-pending title="${PEND_TITLES.this}">--</span>`;
  const fit = rgRoadFitCols();
  const pool = ROAD_COL_OPTIONS.filter(n => n <= fit);
  if (!pool.length) pool.push(ROAD_COL_OPTIONS[0]);
  const want = ROAD_COL_OPTIONS.includes(RG.cols) ? RG.cols : rgColsDefault();
  const cols = Math.min(want, pool[pool.length - 1]);
  const opts = pool.map(n => `<option value="${n}"${n === cols ? ' selected' : ''}>${n} 位</option>`).join('');
  const sz = RG_SIZE_LABEL[RG.size] || RG_SIZE_LABEL.normal;
  const szBtn = sizeBtn ? `<button class="rg-road-size" data-rg-sizebtn type="button" title="${esc(sz.tip)}">${sz.txt}</button>` : '';
  return `<div class="rg-road"><div class="rg-road-head"><p class="rg-road-h">近 24 小时战况</p>
    <span class="rg-road-tools"><label class="rg-cols"><span>位数</span><select data-rg-cols aria-label="每行位数">${opts}</select></label>
    ${szBtn}<button class="rg-road-full" data-rg-full type="button" title="全屏看战况(整屏序列 · 可按日回看)">全屏</button></span></div>
    <div class="rg-road-row" data-rg-road style="--cols:${cols};--rg-gap:${rgRoadGap()}px;grid-template-columns:repeat(${cols},minmax(0,1fr))">${beads}${pend}</div></div>`;
}

function rgCastbarHtml(){
  const s = RG.sel != null ? RG.spells.find(x => x.spellId === RG.sel) : null;
  const unit = s ? (+s.spellPrice || 1000) : 1000;
  const total = unit * RG.count;
  const name = s ? `${esc(s.spellName)} · 克【${esc(s.beast && s.beast.beastName || '')}】` : '请先选择妖兽';
  const dis = !rgPhaseNow().canCast || RG.sel == null;
  // 币名随模式(与 rgConfirmHtml / rgAcctHtml 同口径)—— 施法条是 DIY 两象限共用的,
  // 写死「星币」会让模拟盘报出真金白银的口径。右侧按钮的「币」是窄位省略,保持中性不改。
  const coin = RG.mode === 'sim' ? '模拟币' : '星币';
  return `<div class="rg-castbar">
    <div class="rg-castbar-sel"><b>${name}</b><span>单次投入 ${unit} ${coin}</span></div>
    <div class="rg-step">
      <button data-act="dec"${dis ? ' disabled' : ''} aria-label="减少一注">−</button>
      <input type="number" inputmode="numeric" min="1" max="99" value="${RG.count}" data-rg-count${dis ? ' disabled' : ''} aria-label="攻击次数">
      <button data-act="inc"${dis ? ' disabled' : ''} aria-label="增加一注">＋</button>
    </div>
    <button class="rg-cast-btn" data-act="cast"${dis ? ' disabled' : ''}>施法<span class="rg-cast-cost">${total} 币</span></button>
  </div>`;
}

/* 最近出怪结果横幅 */
function rgResultHtml(){
  const a = RG.award;
  if (!a || a.awardStatus == null) return '';
  const st = a.awardStatus, beast = a.beast || {};
  const icon = rgImg(beast.beastIcon);
  const title = st === 1 ? '命中！' : st === 2 ? '未命中' : '本局出怪';
  let sub, gain = '';
  if (st === 1){
    const total = (a.awardList || []).reduce((n, x) => n + (+x.giftScore || 0), 0) || a.hitScore || '';
    sub = `开出【${esc(beast.beastName || '')}】· 倍率 ${esc(String(a.multiplier || ''))}`;
    gain = total ? `+${esc(String(total))}` : '';
  } else if (st === 2){ sub = `开出【${esc(beast.beastName || '')}】· 本局未押中`; }
  else { sub = `开出【${esc(beast.beastName || '')}】· 本局未参与`; }
  const iconEl = icon ? `<img class="rg-result-icon" src="${esc(icon)}" alt="" onerror="this.style.visibility='hidden'">` : '<div class="rg-result-icon"></div>';
  return `<div class="rg-result" data-st="${st}">${iconEl}<div class="rg-result-txt"><span class="rg-result-title">${title}</span><span class="rg-result-sub">${sub}</span></div>${gain ? `<span class="rg-result-gain">${gain}</span>` : ''}</div>`;
}
function rgHitAnimation(a){
  const box = rgBox(); if (!box || !a) return;
  const cell = box.querySelector(`.rg-cell[data-spell="${a.spellId}"]`);
  if (cell){ cell.classList.remove('is-hit'); void cell.offsetWidth; cell.classList.add('is-hit'); setTimeout(() => cell.classList.remove('is-hit'), 1200); }
}

/* 我的记录(真实=官方 recordList;模拟=本地法术记录账本,含待开/命中/未中与得失) */
function rgRecordsHtml(){
  if (RG.mode === 'sim') return simRecordsHtml();
  if (RG.records == null) return rgLoadingHtml('正在读取我的记录…');
  if (!RG.records.length) return '<div class="rg-empty">还没有游戏记录 · 施一次法就有啦</div>';
  return `<div class="rg-records">${RG.records.slice(0, 30).map(rgRecItemHtml).join('')}</div>`;
}
function simRecordsHtml(){
  const bets = simBetsLoad();
  if (!bets.length) return '<div class="rg-empty">还没有模拟法术记录 · 施一次法就有啦</div>';
  const rows = bets.slice(0, 40).map(b => {
    const cls = !b.settled ? 'none' : (b.hit ? 'win' : 'miss');
    const tx = !b.settled ? '待开' : (b.hit ? '命中' : '未中');
    const when = fmtClock(+b.start);
    const gain = !b.settled ? `-${b.total}` : (b.hit ? `+${b.win}` : `-${b.total}`);
    const gcls = (!b.settled || !b.hit) ? 'is-out' : 'is-in';
    const res = b.settled && b.result ? ` · 开出【${esc(b.result.beast || '')}】` : '';
    return `<div class="rg-rec"><div class="rg-rec-head"><span class="rg-rec-when">${when}</span><span class="rg-rec-st" data-st="${cls}">${tx}</span><span class="rg-rec-gain ${gcls}">${gain}</span></div>
      <div class="rg-rec-spells"><span class="rg-rec-chip"><b>${esc(b.spellName || '')}</b> 克【${esc(b.beastName || '')}】<em>×${esc(String(b.count))}</em></span><span class="rg-rec-note">${b.unit}币/注${res}</span></div></div>`;
  }).join('');
  return `<div class="rg-records">${rows}</div>`;
}
function rgRecItemHtml(r){
  const st = String(r.status);
  const cls = st === '1' ? 'win' : st === '2' ? 'miss' : 'none';
  const tx = cls === 'win' ? '命中' : cls === 'miss' ? '未中' : '参与';
  const when = r.startTime ? fmtClock(+r.startTime) : '';
  const chips = (r.spells || []).map(s => {
    const icon = rgImg(s.beast && (s.beast.beastIcon || s.beast.beastLogo) || s.spellLogo);
    return `<span class="rg-rec-chip"><img src="${esc(icon)}" alt="" onerror="this.style.display='none'"><b>${esc(s.spellName || '')}</b><em>×${esc(String(s.spellNum || 1))}</em></span>`;
  }).join('');
  return `<div class="rg-rec"><div class="rg-rec-head"><span class="rg-rec-when">${when}</span><span class="rg-rec-st" data-st="${cls}">${tx}</span></div><div class="rg-rec-spells">${chips || '<span class="rg-empty" style="padding:2px">—</span>'}</div></div>`;
}
async function rgLoadRecords(silent){
  if (RG.loadingRec) return; RG.loadingRec = true;
  try {
    const d = await gapi('/api/game/records', { timeout: 9000 });
    RG.records = (d.gameOk === false) ? (silent && RG.records != null ? RG.records : []) : (Array.isArray(d.recordList) ? d.recordList : []);
  } catch (_){ if (RG.records == null) RG.records = []; }
  finally { RG.loadingRec = false; if (rgActive() && RG.view === 'records'){ rgSig(''); rgSyncRender(); } }
}

/* 榜单 */
function rgRankHtml(){
  if (RG.rank == null) return rgLoadingHtml('正在读取榜单…');
  if (!RG.rank.length) return '<div class="rg-empty">暂无榜单数据</div>';
  return `<div class="rg-rank">${RG.rank.slice(0, 50).map((r, i) => {
    const no = r.rank || i + 1;
    const av = rgImg(r.logo || r.userLogo);
    const nick = esc(r.nick || r.nickName || r.nickname || ('酷狗' + (r.uid || '')));
    const score = esc(String(r.score != null ? r.score : (r.value != null ? r.value : '')));
    return `<div class="rg-rank-item"><span class="rg-rank-no">${no}</span><img class="rg-rank-av" src="${esc(av)}" alt="" onerror="this.style.visibility='hidden'"><span class="rg-rank-nick">${nick}</span><span class="rg-rank-score">${score}</span></div>`;
  }).join('')}</div>`;
}
async function rgLoadRank(){
  if (RG.loadingRank) return; RG.loadingRank = true;
  try {
    const d = await gapi('/api/game/rank?type=1&cat=0', { timeout: 9000 });
    RG.rank = (d.gameOk === false) ? [] : (Array.isArray(d.rankList) ? d.rankList : []);
  } catch (_){ if (RG.rank == null) RG.rank = []; }
  finally { RG.loadingRank = false; if (rgActive() && RG.view === 'rank'){ rgSig(''); rgSyncRender(); } }
}

/* 登录 / 失效 / 选房 引导层 */
function rgGuardHtml(g){
  const kind = g.kind || 'need_login';
  const invalid = kind === 'invalid', business = kind === 'business', network = kind === 'network', api = kind === 'api';
  const seal = invalid ? '验' : business ? '房' : network ? '网' : api ? '异' : '登';
  /* 5.0.2:business 守卫的**前端**触发点实地核查仅两处(rgSimTick / rgPoll),且都是
     名录为空;但 7992 行会把**后端** state 响应的 kind:'business' 原样落入本分支
     (现行后端仅 room 参数缺失时发,而前端 room=S.alias 恒非空 —— 防御分支,现行
     不可达)。为后端未来任何 state 层业务拒绝留正确出口:按名录空与否分流 ——
     名录空 → 「添加直播间」直达添加弹层(.modal z80 > .jiufa-dock z60,窄屏 jf
     全屏下弹层照常盖上;实测该形态顶栏 ☰ 被面板标签盖住不可点,「去侧栏找」的
     指引必落空);名录非空(只可能来自后端,message 必随行) → 中性标题 +
     「打开名录」(rgGotoRooms)。旧按钮「选择直播间」在空名录下名不副实(没得选),
     rgGotoRooms 聚焦搜索框同样落空(名录空,搜什么都没有)。 */
  const noRooms = !(S.rooms && S.rooms.length);
  const title = invalid ? '账号登录态失效' : business ? (noRooms ? '需要先添加直播间' : '暂时无法进入游戏') : network ? '网络不稳' : api ? '官方服务暂时异常' : '尚未登录账号';
  const text = esc(g.message || (invalid ? '当前账号的登录票据已过期,请重新登录该账号后再来玩。'
    : business ? (noRooms ? '名录还是空的,先添加一个直播间。' : '暂时无法进入游戏,请稍后重试。')
      : network ? '与官方服务器的连接不稳定,可稍后重试。'
        : api ? '与官方游戏服务通讯出错,系统会自动重试;也可点下方按钮立即重试。'
          : '真实游戏要用你自己的酷狗账号来玩。请先添加/登录一个账号,并在账号列表选中它。'));
  let btns;
  if (invalid) btns = '<button class="rg-guard-btn" data-act="pickacct">去账号列表</button><button class="rg-guard-btn is-alt" data-act="recheck">重新检测</button>';
  else if (business) btns = noRooms
    ? '<button class="rg-guard-btn" data-act="addroom">添加直播间</button><button class="rg-guard-btn is-alt" data-act="recheck">重试</button>'
    : '<button class="rg-guard-btn" data-act="pickroom">打开名录</button><button class="rg-guard-btn is-alt" data-act="recheck">重试</button>';
  else if (network || api) btns = '<button class="rg-guard-btn" data-act="recheck">重试</button>';   // 3.8.1:api 态曾错落「尚未登录」文案与扫码按钮
  else btns = '<button class="rg-guard-btn" data-act="login">扫码登录账号</button><button class="rg-guard-btn is-alt" data-act="pickacct">已登录 · 去选择</button>';
  return `<div class="rg-guard" data-kind="${kind}"><div class="rg-guard-seal">${seal}</div><div class="rg-guard-title">${title}</div><p class="rg-guard-text">${text}</p><div class="rg-guard-btns">${btns}</div></div>`;
}

/* 施法确认层(真金白银前置确认)*/
function rgConfirmHtml(){
  const c = RG.confirm; if (!c) return '';
  const s = RG.spells.find(x => x.spellId === c.spellId);
  const unit = s ? (+s.spellPrice || 1000) : 1000;
  const total = unit * c.count;
  const icon = s ? rgImg(s.beast && (s.beast.beastIcon || s.beast.beastLogo) || s.spellLogo) : '';
  const balRaw = (RG.account && RG.account.coin !== '' && RG.account.coin != null) ? String(RG.account.coin) : '';
  const enough = balRaw === '' ? true : (Number(balRaw) >= total);
  const iconEl = icon ? `<img class="rg-confirm-icon" src="${esc(icon)}" alt="" onerror="this.style.visibility='hidden'">` : '<div class="rg-confirm-icon"></div>';
  const sim = RG.mode === 'sim';
  const chargeLine = sim ? '将扣除<b>模拟币</b>(不扣真实星币)' : '将从当前账号<b>真实扣除星币</b>';
  const unitName = sim ? '模拟币' : '星币';
  return `<div class="rg-confirm"><div class="rg-confirm-card">
    ${iconEl}
    <div class="rg-confirm-h">确认施法</div>
    <p class="rg-confirm-p">对【${esc(s && s.beast && s.beast.beastName || '')}】施展 ${esc(s && s.spellName || '')} ×${c.count}<br>${chargeLine}</p>
    <div class="rg-confirm-cost">${total} ${unitName}</div>
    <div class="rg-confirm-bal">当前余额 ${esc(balRaw || '—')} ${unitName}${enough ? '' : ' · 余额可能不足'}</div>
    <div class="rg-confirm-row"><button class="rg-confirm-cancel" data-act="cf-cancel">再想想</button><button class="rg-confirm-ok" data-act="cf-ok"${RG.castBusy ? ' disabled' : ''}>确认施法</button></div>
  </div></div>`;
}

/* ── 交互动作 ──────────────────────────────────────────────────────────── */
function rgSelectSpell(id){ if (!RG.spells.some(s => s.spellId === id)) return; RG.sel = id; RG.castErr = null; rgSyncRender(); }
function rgSetCount(v){
  RG.count = clampN(1, Math.round(Number(v)) || 1, 99);
  const box = rgBox(); if (!box) return;
  const inp = box.querySelector('input[data-rg-count]'); if (inp && document.activeElement !== inp) inp.value = RG.count;
  const s = RG.sel != null ? RG.spells.find(x => x.spellId === RG.sel) : null;
  const unit = s ? (+s.spellPrice || 1000) : 1000;
  const cost = box.querySelector('.rg-cast-btn .rg-cast-cost'); if (cost) cost.textContent = (unit * RG.count) + ' 币';
}
function rgOpenConfirm(){
  if (RG.sel == null) return toast('请先选择要施法的妖兽');
  if (!rgPhaseNow().canCast) return toast('本局已停止布法,请等下一局');
  RG.castErr = null;
  RG.confirm = { spellId: RG.sel, count: RG.count };
  rgSyncRender();
}
function rgCloseConfirm(){ if (!RG.confirm) return; RG.confirm = null; rgSyncRender(); }
async function rgDoCast(){
  if (!RG.confirm || RG.castBusy) return;
  const { spellId, count } = RG.confirm, round = RG.roundId;
  const s0 = RG.spells.find(x => x.spellId === spellId);
  const unit = s0 ? (+s0.spellPrice || 1000) : 1000;   // 真实单价(随法术;后端据此下预订单,避免与官方价不符导致不扣费)
  if (!rgPhaseNow().canCast){ RG.confirm = null; rgSyncRender(); return toast('本局已停止布法'); }
  if (RG.mode === 'sim') return simCast(spellId, count, unit);   // 模拟盘:本地钱包结算,不发任何官方请求
  RG.castErr = null;
  RG.castBusy = true;
  const okBtn = rgBox() && rgBox().querySelector('.rg-confirm-ok'); if (okBtn){ okBtn.disabled = true; okBtn.textContent = '施法中…'; }
  try {
    const d = await gapi(`/api/game/cast?room=${encodeURIComponent(S.alias)}&spell=${spellId}&count=${count}&round=${encodeURIComponent(round)}&price=${unit}`, { timeout: 15000 });
    if (d.gameOk === false){
      toast(d.message || '施法失败');
      RG.castErr = { kind: d.kind || 'business', message: d.message || '施法未成功,请重试' };   // 友好提示:摆在盘面顶部
      if (d.kind === 'invalid') RG.guard = { kind: 'invalid', message: d.message };
      RG.confirm = null; RG.castBusy = false; rgSig(''); rgSyncRender();
      return;
    }
    toast(d.message || '施法成功');
    RG.castErr = null;
    const s = RG.spells.find(x => x.spellId === spellId); if (s) s.spellNum = (+s.spellNum || 0) + count;   // 乐观回显
    if (d.account) RG.account = d.account;
    RG.confirm = null; RG.castBusy = false; rgSig(''); rgSyncRender();
    rgRefreshCoin();
    setTimeout(() => { if (rgActive()) rgPoll(); }, 700);                                                   // 回读官方攻击次数校正
  } catch (err){
    RG.castErr = { kind: 'network', message: '与官方服务器连接不稳,施法未发出,请重试。' };
    RG.confirm = null; RG.castBusy = false; toast('施法请求失败,请重试'); rgSig(''); rgSyncRender();
  }
}
/* 刷新当前账号星币(权威余额)并同步名录 + 头条;模拟盘直接读本地钱包 */
async function rgRefreshCoin(){
  if (RG.mode === 'sim'){ RG.account = simAccount(); rgSig(''); rgSyncRender(); return; }
  const kid = RG.account && RG.account.kugouId; if (!kid) return;
  try {
    const r = await api('/api/account/refresh?kugouId=' + encodeURIComponent(kid), { timeout: 15000 });
    renderAccounts(r);
    const me = (r.accounts || []).find(a => String(a.kugouId) === String(kid));
    if (me){ RG.account = { ...RG.account, coin: me.coin, validStatus: me.validStatus, nickName: me.nickName, userLogo: me.userLogo }; rgSig(''); rgSyncRender(); }
  } catch (_){ /* 刷新失败保持原值 */ }
}
function rgSetView(v){ if (RG.view === v) return; RG.view = v; rgSyncRender(); }
/* 引导:去账号列表 / 去选房 / 扫码登录 / 重新检测 */
function rgGotoAccounts(){ toast('请在账号列表选择或登录用于游戏的账号'); openRail(true); setTimeout(() => { D.acctList && D.acctList.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, 60); }
function rgGotoRooms(){ openRail(true); setTimeout(() => { D.roomSearch && D.roomSearch.focus(); }, 60); }
function rgAddRoom(){ D.addRoomOpen && D.addRoomOpen.click(); }   // 5.0.2:转发既有入口(容量闸/closeRail/清 msg 同一套);modal z80 盖过 jf 面板 z60
function rgStartLogin(){ openRail(true); openAcctModal(); }
async function rgRecheck(){
  if (RG.mode === 'sim'){ RG.simWaitSince = 0; RG.guard = null; simSync(); rgSig(''); rgSyncRender(); return; }   // 模拟盘:本地重探即可
  const kid = RG.account && RG.account.kugouId;
  try { if (kid){ const r = await api('/api/account/check?kugouId=' + encodeURIComponent(kid), { timeout: 15000 }); renderAccounts(r); } }
  catch (_){ /* 忽略 */ }
  RG.guard = null; rgSig(''); rgPoll();
}

/* 切主播时(观测台已换房)重置游戏本局态并重取(真实=重拉官方;模拟=清钱包外的局态并就地重推) */
function rgRoomMaybeChanged(){
  if (RG.room && S.alias && String(RG.room) !== String(S.alias)){
    RG.state = false; RG.award = null; RG.awardFetchedRound = null; RG.endPolledRound = null;
    RG.history = []; RG.histRoom = ''; RG.roundId = null; RG.sel = null; RG.confirm = null;
    RG.anchorUid = null; RG.room = String(S.alias); RG.simShownRound = 0; rgSig('');
    if (rgActive()){
      const box = rgBox();
      if (RG.mode === 'sim'){ simSync(); rgSyncRender(); }
      else { if (box) box.innerHTML = rgLoadingHtml('已切换主播,正在读取新牌面…'); rgPoll(); }
    }
  }
}

/* 激活 / 停用(由停靠面板 applyGameSurface 调用)。mode 由当前页签/皮肤决定:
   真实页签 → real(轮询官方盘面);模拟页签×DIY 皮肤 → sim(本地驱动,不发任何官方请求)。 */
function rgActivate(){
  if (!rgActive()) return;
  const mode = (S.gameTab === 'sim') ? 'sim' : 'real';
  if (RG.mode !== mode){                                  // 模式切换:清跨模式不可复用的局态(钱包/记录各自持久,勿混)
    RG.mode = mode;
    RG.state = false; RG.sel = null; RG.confirm = null; RG.award = null;
    RG.records = null; RG.rank = null; RG.view = 'cast'; RG.castBusy = false;
  }
  RG.award = null; RG.awardFetchedRound = null; RG.endPolledRound = null; RG.simShownRound = 0; RG.sig = '';
  const box = rgBox();
  clearInterval(RG.pollTimer); RG.pollTimer = 0;
  if (RG.mode === 'sim'){
    if (box) box.innerHTML = rgLoadingHtml('正在铺开模拟盘面…');
    simSync(); rgSyncRender();                            // 本地即时成盘,无网络往返
  } else {
    if (!RG.state && box) box.innerHTML = rgLoadingHtml('正在连接官方牌面…');
    rgPoll();
    RG.pollTimer = setInterval(rgPoll, 4000);
  }
  clearInterval(RG.tickTimer); RG.tickTimer = setInterval(rgTick, 250);
}
function rgDeactivate(){
  clearInterval(RG.pollTimer); RG.pollTimer = 0;
  clearInterval(RG.tickTimer); RG.tickTimer = 0;
}

/* 事件委托:施法盘 / 头条 / 导航 / 确认 / 引导 —— 真实盘(#realBody)与模拟盘(#simBody)
   各绑一次同一套委托;处理函数经 rgBox()/RG.mode 自然分流,新增动作 simreset=重置模拟钱包。 */
function bindRealGame(){
  [D.realBody, D.simBody].forEach(bindRgSurface);
  // 3.3.1:原先这里自挂一个未防抖的 resize —— 每个 resize 事件都排一个 rAF,
  // 拖拽一秒能堆出几十个。现统一并入 bindStatic 的防抖管线(onResizeSettled)。
}
function bindRgSurface(root){
  if (!root || root._rgBound) return; root._rgBound = true;
  root.addEventListener('click', e => {
    const hit = e.target.closest('[data-act]');
    const act = hit ? hit.getAttribute('data-act') : '';
    if (act){
      e.preventDefault();
      if (act === 'inc') return rgSetCount(RG.count + 1);
      if (act === 'dec') return rgSetCount(RG.count - 1);
      if (act === 'cast') return rgOpenConfirm();
      if (act === 'cf-cancel') return rgCloseConfirm();
      if (act === 'cf-ok') return rgDoCast();
      if (act === 'refresh') return rgRefreshCoin();
      if (act === 'pickacct') return rgGotoAccounts();
      if (act === 'pickroom') return rgGotoRooms();
      if (act === 'addroom') return rgAddRoom();          // 5.0.2:空名录守卫直达添加弹层
      if (act === 'login') return rgStartLogin();
      if (act === 'recheck') return rgRecheck();
      if (act === 'simreset') return simResetWallet();
      if (act === 'err-close'){ RG.castErr = null; rgSig(''); rgSyncRender(); return; }
      return;
    }
    if (e.target.closest('[data-rg-full]')) return openWide();               // P2:DIY 盘同样给全屏入口
    if (e.target.closest('[data-rg-sizebtn]')) return rgToggleSize();        /* 5.0.9:常规/加高档切换(见 rgToggleSize 前长注)。
       ★ 钩子必须是 data-rg-sizebtn 而非 data-rg-size —— 后者是挂在 #realBody/#simBody
         上的**档位状态属性**,而本委托的 root 恰是这两个节点,closest 会一路命中容器,
         盘内任意一次点击都会误触发切档(实装前自查抓获,勿改回)。 */
    const nav = e.target.closest('.rg-nav button'); if (nav) return rgSetView(nav.getAttribute('data-view'));
    const cell = e.target.closest('.rg-cell[data-spell]'); if (cell) return rgSelectSpell(+cell.getAttribute('data-spell'));
    if (e.target.classList.contains('rg-confirm')) return rgCloseConfirm();   // 点遮罩空白关闭
  });
  root.addEventListener('input', e => {
    if (!e.target.matches('input[data-rg-count]')) return;
    const v = e.target.value.replace(/[^\d]/g, ''); RG.count = clampN(1, Number(v) || 1, 99);
    const s = RG.sel != null ? RG.spells.find(x => x.spellId === RG.sel) : null;
    const unit = s ? (+s.spellPrice || 1000) : 1000;
    const cost = root.querySelector('.rg-cast-btn .rg-cast-cost'); if (cost) cost.textContent = (unit * RG.count) + ' 币';
  });
  root.addEventListener('change', e => {
    if (e.target.matches('input[data-rg-count]')){ e.target.value = RG.count; return; }
    const cols = e.target.closest('[data-rg-cols]');
    if (cols){ const v = Number(cols.value); if (ROAD_COL_OPTIONS.includes(v)){ RG.cols = v; store.set(KEY.rgCols, String(v)); rgSig(''); rgSyncRender(); } }
  });
  root.addEventListener('keydown', e => {
    const cell = e.target.closest && e.target.closest('.rg-cell[data-spell]');
    if (cell && (e.key === 'Enter' || e.key === ' ')){ e.preventDefault(); rgSelectSpell(+cell.getAttribute('data-spell')); }
  });
}

/* ═══════════ 事件绑定 ═══════════ */
function closeRail(){
  D.rail.classList.remove('is-open');
  if (jfFullscreen()) D.rail.setAttribute('inert', ''); // 3.9.1/3.9.4:仅坞**全屏**期间收起的离屏名录对键盘惰化(openRail 再撤);桌面停靠形态名录照常可交互
  D.railVeil.hidden = true;
  S.hoverOpen = false;
  clearTimeout(S.hoverT); clearTimeout(S.leaveT);
  // 2.5.9:名录开合不再平移主区几何(CSS 补偿边距),原「收起时顺手收起
  // 战况悬浮卡防错位」的守卫失去前提且会把用户正看着的悬浮卡无故闪掉
  // (悬停误开的名录 280ms 后自动收起即触发),故移除;悬浮卡位置始终有效。
}
function openRail(pinned){
  D.rail.removeAttribute('inert');              // 3.9.1:坞开期间收起态名录被惰化 —— 滑出前先解除,后续 focus 才可入
  D.rail.classList.add('is-open');
  const overlay = document.body.dataset.layout === 'cockpit' || effW() <= 1060 || jfFullscreen();   // 3.9.1/3.9.4:仅坞**全屏**期间名录必为覆盖式(见 CSS 同名节);桌面停靠按常规布局判定
  if (pinned && overlay) D.railVeil.hidden = false;
  S.hoverOpen = !pinned;
}
function bindStatic(){
  // 登录系统(3.8.0):登录门表单与用户 chip 的退出(元素常驻 DOM,绑定恒安全)
  if (D.authForm) D.authForm.addEventListener('submit', doLogin);
  if (D.ucLogout) D.ucLogout.addEventListener('click', doLogout);
  // 注册系统(4.0.0):同卡切换注册态/返回登录(入口仅当 session.reg.mode≠off 显示)
  if (D.authToReg) D.authToReg.addEventListener('click', regShow);
  if (D.regBack) D.regBack.addEventListener('click', regShowLogin);
  if (D.regDoneBack) D.regDoneBack.addEventListener('click', regShowLogin);
  if (D.regForm) D.regForm.addEventListener('submit', doRegister);
  // 4.0.1:密码可见性切换(登录/注册三处共用;aria-pressed 同步给读屏)
  if (D.authGate) D.authGate.addEventListener('click', ev => {
    const b = ev.target && ev.target.closest && ev.target.closest('.pw-eye');
    if (!b) return;
    const inp = b.parentElement && b.parentElement.querySelector('input');
    if (!inp) return;
    const show = inp.type === 'password';
    inp.type = show ? 'text' : 'password';
    b.classList.toggle('on', show);
    b.setAttribute('aria-pressed', show ? 'true' : 'false');
    b.setAttribute('aria-label', show ? '隐藏密码' : '显示密码');
    try { inp.focus(); } catch {}
  });
  // 4.0.1:登录门焦点困笼 —— aria-modal 声明之外真把 Tab 圈在门内
  // (此前 Tab 可逃逸到磨砂背景里的页面控件;数据仍有 401 兜底,但键盘体验破相)。
  // 不用 inert:本站兼容口径顾及旧内网 WebView(与弃用 crypto.subtle 同一理由)。
  document.addEventListener('keydown', ev => {
    if (ev.key !== 'Tab' || !D.authGate || D.authGate.hidden) return;
    const els = Array.from(D.authGate.querySelectorAll('button, input, a[href], [tabindex]'))
      .filter(el => !el.disabled && el.tabIndex >= 0 && el.offsetParent !== null);
    if (!els.length) return;
    const first = els[0], last = els[els.length - 1], cur = document.activeElement;
    const inside = D.authGate.contains(cur);
    if (!inside){ ev.preventDefault(); (ev.shiftKey ? last : first).focus(); return; }
    if (!ev.shiftKey && cur === last){ ev.preventDefault(); first.focus(); }
    else if (ev.shiftKey && cur === first){ ev.preventDefault(); last.focus(); }
  });

  D.railOpen.addEventListener('click', () => openRail(true));
  // 3.9.0:身份区点按 = 打开名录(仅当 ☰ 可见的挤压态;桌面态无按钮语义、不响应)
  const identityGo = () => { if (document.body.hasAttribute('data-w-md')) openRail(true); };
  D.anchorIdentity.addEventListener('click', identityGo);
  D.anchorIdentity.addEventListener('keydown', e => {
    if ((e.key === 'Enter' || e.key === ' ') && document.body.hasAttribute('data-w-md')){
      e.preventDefault(); openRail(true);
    }
  });
  D.railClose.addEventListener('click', closeRail);
  D.railVeil.addEventListener('click', closeRail);
  // 5.0.3:空名录主舞台引导卡 → 转发既有入口(与侧栏空引导卡/单房引导条同一套闸)
  if (D.stageEmpty) D.stageEmpty.addEventListener('click', e => {
    if (e.target.closest('.stage-empty-add')) D.addRoomOpen.click();
  });

  // 驾驶舱图标轨:悬停 350ms 展开 / 牌匾点击固定展开
  // 4.9.4:触屏(含 iPad Pro 横屏 1366×1024 —— 实测落 cockpit 且 hover:none)一律
  // 不走悬停通道 —— 触屏的 pointerenter 只有进没有出,展开后再也收不回去。
  // 触屏的等价入口是顶栏 ☰(app.css 同名节把它在 cockpit 下放出来)与牌匾点击。
  D.rail.addEventListener('pointerenter', e => {
    if (e.pointerType === 'touch' || e.pointerType === 'pen') return;
    if (document.body.dataset.layout !== 'cockpit') return;
    if (document.body.dataset.rail === 'full') return;
    if (D.rail.classList.contains('is-open')) { clearTimeout(S.leaveT); return; }
    clearTimeout(S.hoverT);
    S.hoverT = setTimeout(() => openRail(false), 350);
  });
  D.rail.addEventListener('pointerleave', e => {
    if (e.pointerType === 'touch' || e.pointerType === 'pen') return;
    clearTimeout(S.hoverT);
    if (S.hoverOpen){ clearTimeout(S.leaveT); S.leaveT = setTimeout(closeRail, 280); }
  });
  D.railPlaque.addEventListener('click', () => {
    if (document.body.dataset.layout !== 'cockpit') return;
    if (document.body.dataset.rail === 'full') return;
    if (!D.rail.classList.contains('is-open')) { openRail(true); D.roomSearch.focus(); }
  });

  D.roomList.addEventListener('click', e => {
    if (e.target.closest('.room-empty-add')){ D.addRoomOpen.click(); return; }   // 5.0.2:空名录引导卡 → 转发既有入口(与栏底按钮同一套闸)
    if (e.target.closest('.room-nudge-add')){ D.addRoomOpen.click(); return; }   // 5.0.3:单房引导条 → 同一转发
    if (e.target.closest('.room-nudge-close')){                                  // 5.0.3:显式消解 —— 落键 + 同帧撤属性(CSS 门控立即隐藏,免重绘)
      store.set(KEY.addNudge, '1'); syncNudge(); return;
    }
    const del = e.target.closest('.ri-del');
    if (del){ e.stopPropagation(); handleDelClick(del); return; }
    const btn = e.target.closest('.room-item');
    if (!btn) return;
    closeRail();
    if (btn.dataset.alias !== S.alias) loadRoom(btn.dataset.alias, { explicit: true }); // 用户点房 → 抢占
  });
  D.roomList.addEventListener('keydown', e => {          // 键盘可达:聚焦条目按 Delete/Backspace
    if (e.key !== 'Delete' && e.key !== 'Backspace') return;
    const del = e.target.closest?.('.room-item')?.querySelector('.ri-del');
    if (!del) return;
    e.preventDefault();
    handleDelClick(del);
  });
  D.roomSearch.addEventListener('input', () => renderRail(D.roomSearch.value));
  const doSearch = () => {
    const q = normDigits(D.roomSearch.value);
    if (!q) return;
    const hit = S.rooms.find(r => String(r.alias)===q || String(r.roomId)===q || (r.nickname||'')===q);
    const alias = hit ? String(hit.alias) : (/^\d{2,12}$/.test(q) ? q : '');
    if (!alias) return toast('请输入房间号,或从名录中选择主播');
    closeRail(); D.roomSearch.value=''; renderRail();
    /* 5.0.8 切换即添加:登录态下敲的是**不在名录**的房号 → 先加后看(addAndOpenRoom,
       与「＋ 添加直播间」同一条后端阶梯:在播即入名录,未开播/号不存在照实说)。
       未启用登录时维持「看而不加」的旧语义(5.0.3 注:房不入名录,rooms 恒 0)。
       名录内命中(含残影卡)仍走 loadRoom —— 若服务端其实没绑定,由其 room_not_bound
       分支同样自动补绑。 */
    if (!hit && AUTH.enabled) return addAndOpenRoom(alias);
    loadRoom(alias, { explicit: true });   // 用户搜索并打开 → 抢占
  };
  D.roomSearchGo.addEventListener('click', doSearch);
  D.roomSearch.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.isComposing) doSearch(); });

  // 每行位数(纵览/驾驶舱/全屏三处共用同一档位)/ 全屏
  D.roadCols.addEventListener('change', () => applyCols(D.roadCols.value));
  D.wideCols.addEventListener('change', () => applyWideCols(D.wideCols.value));   // 4.7.6:全屏档独立,不写回面板
  D.roadExpand.addEventListener('click', () => {
    // 4.2.0:basic 档**不隐藏**入口,点击弹引导 —— 隐藏等于放弃转化点,
    // 用户根本不知道自己错过了什么。
    if (isBasic()){ vipUpsell('wide'); return; }
    openWide();
  });
  D.wideBack.addEventListener('click', closeWide);
  // 3.6.0 按日回看:日导航(下拉/前后一天/回到实时)+ 失败重试(事件委托,序列点击本无绑定,零冲突)
  D.wvDay.addEventListener('change', () => { const v = D.wvDay.value; v ? wvGoto(v) : wvGoLive(); });
  D.wvPrev.addEventListener('click', () => wvStep(+1));
  D.wvNext.addEventListener('click', () => wvStep(-1));
  D.wvLiveBtn.addEventListener('click', wvGoLive);
  D.wideCols.addEventListener('change', () => {           // 3.6.0:列档在回看态即时生效 ——
    if (WV.mode === 'day') renderWideDay();                // applyCols→renderRoad 被 WV 守卫拦下,这里从 WV.rounds 补渲(注册序在 applyCols 之后,S.cols 已更新)
  });
  D.wideGrid.addEventListener('click', e => {
    if (e.target.closest('[data-wv-retry]') && WV.mode === 'day') wvGoto(WV.day);
  });
  if (D.roadReplay) D.roadReplay.addEventListener('click', () => {   // 3.6.0 直达:开全屏并直落最近回放日(通常=昨天)
    const nav = wvNavDays();
    openWide();
    if (nav.length) wvGoto(nav[0].date);
  });

  // 顶栏双入口(真实游戏 / 模拟游戏):点击进入对应模式,展开前先收名录。
  // onGameEntry:未开→按该模式打开;已开且同模式→收起;已开异模式→切模式。
  if (D.realGameOpen) D.realGameOpen.addEventListener('click', () => { closeRail(); onGameEntry('real'); });
  D.jiufaOpen.addEventListener('click', () => { closeRail(); onGameEntry('sim'); });
  // 面板头页签:仅在面板已开时切换两模式
  if (D.tabReal) D.tabReal.addEventListener('click', () => { if (S.gameTab !== 'real') setGameTab('real', { focus: true }); });
  if (D.tabSim) D.tabSim.addEventListener('click', () => { if (S.gameTab !== 'sim') setGameTab('sim', { focus: true }); });
  if (D.skinDiy) D.skinDiy.addEventListener('click', () => setSkin('diy'));
  if (D.skinOfficial) D.skinOfficial.addEventListener('click', () => setSkin('official'));
  D.jiufaClose.addEventListener('click', closeGameDock);
  // 4.1.1:游戏帧常驻 load 监听 —— 任何一次装载落地(含浏览器会话恢复自行发起的
  // 子帧导航),只要落点与形态就位就立即揭遮罩,不必等 750ms 轮询下一拍;
  // 未就位(错误页/独立引擎)则按兵不动,交由 jfHintShow 的轮询与看门狗。
  // 取代旧的 {once:true} 一次性监听 —— 那枚监听会被失败导航白白消费
  // (Chromium 错误页也派发 load),且 WebKit 失败子帧导航根本不派发 load。
  if (D.jiufaFrame) D.jiufaFrame.addEventListener('load', () => {
    if (!S.jiufa || S.rgSkin !== 'official') return;
    if (jfFrameReady(jiufaFrameSrc(S.gameTab === 'real' ? 'real' : 'sim'))) jfHintHide();
  });
  // 4.1.2:遮罩失败终态点击重试(仅 data-fail 态可点;CSS 同步放开 pointer-events)
  if (D.jiufaHint) D.jiufaHint.addEventListener('click', jfHintRetry);
  if (D.jiufaHint) D.jiufaHint.addEventListener('keydown', (e) => {   // 失败终态 role=button 的键盘等价操作
    if ((e.key === 'Enter' || e.key === ' ') && D.jiufaHint.dataset.fail){ e.preventDefault(); jfHintRetry(); }
  });
  bindRealGame();

  // 布局切换
  D.layoutToggle.addEventListener('click', () => {
    const next = S.L?.mode === 'cockpit' ? 'stack' : 'cockpit';
    store.set(KEY.layout, next);
    applyLayout(true);
  });

  // 滞后重连
  D.staleBadge.addEventListener('click', () => {
    toast('正在强制重连…');
    resetPollState();
    connectSSE(); pollNew(); refreshPrediction();
  });

  // 战况交互(驾驶舱)
  // 3.3.1 战况虚拟化:滚动时按 rAF 合帧重算可视窗口(窗口未变 → 整帧零工作)
  /* 3.4.4 号位聚光:单击妖怪卡 ⇄ 序列只亮该号(再点取消,可多选);
     Enter/Space 同击(卡已带 role=button/tabindex);徽标点击一键清除 */
  D.spellBoard.addEventListener('click', e => {
    const cell = e.target.closest('.spell-cell');
    if (cell) toggleSpot(cell.dataset.n);
  });
  D.spellBoard.addEventListener('keydown', e => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const cell = e.target.closest('.spell-cell');
    if (cell){ e.preventDefault(); toggleSpot(cell.dataset.n); }
  });
  if (D.roadSpot) D.roadSpot.addEventListener('click', clearSpot);
  if (D.wideSpot) D.wideSpot.addEventListener('click', clearSpot);

  D.trendBodyWrap.addEventListener('scroll', onTrendScroll, { passive: true });
  D.trendScroll.addEventListener('pointermove', e => { if (S.trendCtx) onTrendMove(e); });
  D.trendScroll.addEventListener('pointerleave', onTrendLeave);
  D.trendScroll.addEventListener('click', e => { if (S.trendCtx) onTrendClick(e); });

  // 4.9.8 客服渠道:顶栏入口 → 「联系客服」弹层(入口显隐由 syncCsEntry 门控)
  if (D.csOpen) D.csOpen.addEventListener('click', openCsModal);

  D.addRoomOpen.addEventListener('click', () => {
    if (roomsFull()) return toast(ROOMS_FULL_TIP);      // 容量闸:满了就别开弹窗白填一遍
    closeRail(); D.addRoomMsg.textContent=''; openModal(D.addRoomModal, D.addRoomInput);
  });
  D.addRoomForm.addEventListener('submit', submitAddRoom);
  if (D.addAcctOpen){
    D.addAcctOpen.addEventListener('click', openAcctModal);
    D.qrRefresh.addEventListener('click', startQrLogin);
    D.acctList.addEventListener('click', onAcctListClick);
    if (D.acctCheckAll) D.acctCheckAll.addEventListener('click', () => checkAllAccounts(D.acctCheckAll));
    document.addEventListener('visibilitychange', () => { if (!document.hidden) autoCheckStale(); });   // 回到本页 → 立刻补检过期账号
    D.acctList.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' '){
        const item = e.target.closest('.acct-item, .ai-btn');
        if (item){ e.preventDefault(); onAcctListClick(e); }
      }
    });
  }
  $$('.modal').forEach(layer => {
    layer.addEventListener('click', e => {
      if (e.target === layer || e.target.closest('[data-close]')) closeModal(layer);
    });
    // Tab 焦点收容已于 2.6.5 中心化到文档级(见 keydown 内 Tab 分支):
    // 同时覆盖弹层与全屏序列、并处理"焦点落在层外/隐式可聚焦滚动容器"两类洞
  });

  document.addEventListener('keydown', e => {
    if (e.key === '/' && !/input|select|textarea/i.test(e.target.tagName)){
      if (!D.wideView.hidden || $$('.modal').some(l => !l.hidden)) return;   // 2.6.3:弹层/全屏在上,不在其下开名录抢焦点
      e.preventDefault();
      openRail(true);
      D.roomSearch.focus();
      return;
    }
    // 3.6.0 按日回看:全屏内 ←/→ 翻日(焦点在下拉/输入框时放行原生行为;导航隐藏时不劫持)
    if ((e.key === 'ArrowLeft' || e.key === 'ArrowRight')
        && !D.wideView.hidden && D.wideNav && !D.wideNav.hidden
        && !/input|select|textarea/i.test(e.target.tagName)){
      e.preventDefault();
      wvStep(e.key === 'ArrowLeft' ? +1 : -1);
      return;
    }
    // 2.6.5 Tab 焦点收容中心化 —— 复查实测两处串层(Chromium):全屏序列正向
    // 第 3 次 Tab 经隐式可聚焦的 .wide-body 后逃逸到 <body>、第 4 次落到遮罩层下
    // 名录按钮;wideBack 前 Shift+Tab 直接串到背景 .trend-body-wrap(Chrome 把
    // overflow:auto 容器视为可聚焦)。统一规则:焦点在最上层覆盖层(全屏/弹层)
    // 之外一律收回层内;层内但不在名册的隐式聚焦点按文档序接续;名册首尾环绕;
    // 其余放行原生步进(层内自然顺序、含滚动容器的键盘滚动能力)。
    if (e.key === 'Tab'){
      /* ★ 4.2.5:VIP 的两层此前**不在收容名单里** —— 它们的类名是 .vip-gate /
         .pay-modal,而这里只找 .modal。实测(free 档、1440×900):连按 Tab 第 4 次
         即逃出开通门,第 5~11 次依次落在 addRoomOpen / addAcctOpen / ucBuy /
         ucLogout / layoutToggle / roadCols / roadExpand —— 这些控件虽被
         `body[data-vip-gate="free"] .shell{pointer-events:none}` 挡了鼠标,但
         **pointer-events 不影响 Tab 序**,键盘用户照样能聚焦并回车触发。
         两层都写着 aria-modal="true",不收容就是一句空话;这与 4.0.1 给登录门
         补 Tab 困笼、2.6.5 给 .modal 做中心化收容,是同一条纪律的同一个漏项。
         优先级按实际层序:pay(z=80) > vipGate(z=70) > wideView(z=70,同级由
         DOM 序决定,且二者在 UI 上不可同时出现) > .modal。
         登录门(z=120)有自己的困笼(4.0.1),此处显式让位,避免两个处理器互相抢焦点。 */
      if (D.authGate && !D.authGate.hidden) return;
      const scope = (D.payModal && !D.payModal.hidden) ? D.payModal
                  : (D.vipGate && !D.vipGate.hidden) ? D.vipGate
                  : !D.wideView.hidden ? D.wideView
                  : $$('.modal').find(l => !l.hidden);
      if (!scope) return;
      const f = $$('button,input,select,textarea,a[href],[tabindex]:not([tabindex="-1"])', scope)
        .filter(el => !el.disabled && el.offsetParent !== null);
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1], a = document.activeElement;
      if (!scope.contains(a)){ e.preventDefault(); (e.shiftKey ? last : first).focus(); return; }
      const i = f.indexOf(a);
      if (i === -1){                                   // 层内隐式聚焦点(如滚动容器):按文档序接续
        e.preventDefault();
        if (e.shiftKey){
          const prev = [...f].reverse().find(el => a.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_PRECEDING);
          (prev || last).focus();
        } else {
          const next = f.find(el => a.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING);
          (next || first).focus();
        }
        return;
      }
      if (e.shiftKey && a === first){ e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && a === last){ e.preventDefault(); first.focus(); }
      return;
    }
    if (e.key !== 'Escape') return;
    if (tipAnchor) hideTip();          // 4.9.4:Esc 顺手收掉通用气泡
    if (!D.trendTip.hidden) hideTrendTip();
    if (!D.wideView.hidden) return void closeWide();
    const topLayer = $$('.modal').find(l => !l.hidden);    // 逐层关闭:先最上层弹层
    if (topLayer) return void closeModal(topLayer);
    if (D.rail.classList.contains('is-open')) return void closeRail();   // 再关名录
    if (S.hl.size) return void clearSpot();                // 3.4.4 再清序列聚光(内容态,让位于覆盖层)
    if (S.jiufa) return void closeJiufa();                 // 最后收起模拟游戏(非模态,末位让行)
  });

  /* 3.2.0:隐藏期间 schedulePolls 完全静默(SSE 本就不在隐藏时重连)。
     回到前台无条件补一枪 —— 这是「隐藏时 SSE 悄悄断了」的唯一解药,
     一次请求换确定性,值。pollNew 不再搭车拉预测,故显式补一次。 */
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden){
      refreshLiveRooms();  // 3.9.5:名录与主舞台同拍复苏 —— 隐藏期 S.rooms 冻结,
                           // 不补拉则角标要再等最长 ~34s 的下一定时拍才更新
                           // (状态判定本身已由 railChip 的快照时点判据兜底不误报)。
      if (S.alias){
        if (!S.spells.length){ loadRoom(S.alias, { silent: true }); return; }   // 4.1.1:零基线(首装从未成功)→ 全量补齐;pollNew 只增量补局、永远补不了 spells
        resetPollState(); S.lastDataPerf = performance.now();   // 保险丝不为「隐藏的那段」误熔断
        pollNew(); refreshPrediction(); tick();
        railTickPaint();   // 3.9.4:速览角标同拍复活(隐藏期跳过重绘;锚点是格点,读秒无损)
        if (!S.es || S.es.readyState === 2) connectSSE();
      }
    }
  });
  window.addEventListener('offline', () => { S.offline = true; setConn('off','离线'); });
  window.addEventListener('online', () => {
    S.offline = false; setConn('poll','轮询中');
    refreshLiveRooms();   // 3.9.5:离线期名录同样冻结,恢复即补拉(同 visibilitychange)
    if (S.alias){
      if (!S.spells.length){ loadRoom(S.alias, { silent: true }); return; }   // 4.1.1:零基线 → 全量补齐(同 visibilitychange 注)
      resetPollState(); S.lastDataPerf = performance.now();
      connectSSE(); pollNew(); refreshPrediction(); tick(); }
  });
  window.addEventListener('pagehide', () => {
    // 3.9.3 天花板级鲁棒:关页/切走时**显式**交还活跃房租约(sendBeacon 在卸载期保证送达,
    // 独立于「连接是否被浏览器优雅关闭」)——另一窗口据此零等待换房。带不了自定义头,
    // 故后端该端点已豁免 CSRF 头;幂等无害。服务端 SSE 断流释放仍在,双保险。
    if (S.alias && AUTH.enabled) {          // 同上:登录未启用时后端无租约,不发空转信标
      try {
        navigator.sendBeacon('/api/active-room/release?roomId='
          + encodeURIComponent(S.alias) + '&tab=' + encodeURIComponent(JF_TAB));
      } catch {}
    }
    stopRealtime(); saveSnapshot();
  });

  // 3.3.1:全站唯一的 resize 落点 —— 80ms 防抖 + rAF 合帧,且 rAF 不重复排队。
  // 游戏停靠面板的路盘贴底(原 bindRealGame 里那个未防抖监听)一并收编于此。
  let rT = 0, rRaf = 0;
  const onResizeSettled = () => {
    rRaf = 0;
    applyLayout();                       // 内部收尾已 stickPinAll()
    if (rgActive() && RG.view === 'cast'){
      /* 4.7.2:此前硬传 true —— 用户正翻历史时拖一下窗口就被拽回底部。
         改按守卫的 armed 实况决定,尊重用户在读的位置。 */
      const rd = (rgBox() || document).querySelector('[data-rg-road]');
      rgFitRoad(!rd || !rd.__stick || rd.__stick.armed);
    }
  };
  window.addEventListener('resize', () => {
    clearTimeout(rT);
    rT = setTimeout(() => { if (!rRaf) rRaf = requestAnimationFrame(onResizeSettled); }, 80);
  });
  if (document.fonts?.ready) document.fonts.ready.then(() => { applyLayout(); stickPinAll(); }).catch(()=>{});
}

/* ═══════════ 观测钩子 ═══════════ */
try {
  new PerformanceObserver(l => { window.__lt = (window.__lt||0) + l.getEntries().length; })
    .observe({ entryTypes: ['longtask'] });
} catch {}
/* 2.6.3:未捕获异常/拒绝静默入册(封顶 20 条),供排障读取;
   不向控制台输出,保持"零控制台报错"的可验证基线不被观测本身污染 */
window.__errlog = [];
const logErr = (kind, m) => { if (window.__errlog.length < 20) window.__errlog.push({ t: Date.now(), kind, msg: String(m && m.message || m).slice(0, 300) }); };
window.addEventListener('error', e => logErr('error', e.message || e.error));
window.addEventListener('unhandledrejection', e => logErr('rejection', e.reason));
window.__jf = { S, ingest, applyLayout, computeLayout, deriveStats, pulseBead, _sticks, stickPinAll };

/* ═══════════ 出发 ═══════════ */
boot();
