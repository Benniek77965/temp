/* ═══════════════════════════════════════════════════════════════
   九法配置中枢 · admin.js (v1.11.0)
   零构建 ES module,完全由管理接口的 /schema 驱动渲染:
   后端注册表新增参数,本页自动出现对应卡片,前端零改动(方案 §3.3)。
   1.1.0:错误码全面人话化(message/hint/映射三级兜底)、原生 confirm/prompt
   → 统一 ask() 对话框、玺印键盘可达、导出改 fetch+Blob(不再依赖 cookie 通道)、
   危险确认即时反馈、帮助图例浮层、票据视图容错。
   1.2.0:.rail 固定左侧(sticky)、会话保持 30 天(令牌落 localStorage + exp 戳)、
   名录管理服务端分页 + 事件委托(数千房不再卡)。
   1.3.0:新增「疑似脚本来源」视图(L4 行为遥测,3.9.2)—— 按会话行为画像的
   疑度呈现,**仅供人工研判、绝不自动封禁**;10s 自动刷新,阈值可筛。
   (原独立页 admin-signals.html 收编回中枢,单入口单会话。)
   1.3.1:「疑」视图内新增**活跃房租约**观测表(3.9.4)—— 单账号单活跃房此前对
   运维完全不可见;呈现 uid/用户名/活跃房/活页数/最近活动,附「释放」兜底
   (仅供极端卡死解卡,语义与 TTL 过期自愈同源,不断流不踢人)。
   1.4.3(实地审计修复,逐条见各处行内注释):
   · A3 变更与版本 / 审计两视图读取失败不再伪装成空态(与票据/名录同款诚实报错);
   · B1 审计筛选补齐 1.3.1/4.0.x 落下的 8 种动作,动作码全面人话化;
   · B2 ⌘K 搜索五字段统一小写比较(含大写英文的标签此前永远搜不到);
   · B3 应用后抽屉头部不再残留「N 项待应用」;B4 敏感项已暂存态占位符明示;
   · C2 名录报错改玺印红;C3 占位票据黄条(吃后端 configured);C4 空口令本地拦截。
   1.7.5:触屏可达性 —— 本台在手机上有两处「悬停才看得见」的信息黑洞,实地核查
   (Chromium 触屏模拟 390×664)坐实:
   · 左栏十一枚印的全名写在 .tip 里靠 :hover 揭示,而 admin.css 在 max-width:760px
     下把 .tip 整个 display:none —— 手机上只剩「览 参 更 名 票 审 疑 注 值 署」十个
     孤立汉字,零可见全名。帮助页原本还写着「手机小屏不显示悬停提示,认字即认路」,
     那是记录在案的投降,不是修复。现改为**内联出全名**(admin.css 同名节)。
   · 全台 31 处 title(rev 徽章、指纹/UA 全量、各视图动作说明…)在触屏浏览器
     **一律不渲染**。现补一条 tap-to-reveal 通道:document 级单点委托、tap 判据
     把「点」与「滑」分开、命中 [title] 即读同一份文本自绘气泡。
     **只读不写 title** —— 与 app.js 4.9.4 同策,零内容改动、零回归面。
   1.8.0:变更工作台去仪式化。「校验」按钮、高危项「键入参数名」输入框、警告
   「我已知悉」勾选三者一并下线 —— 抄一遍键名并不能证明填对了值,它只是把每次
   调参都变成一场抄写。改为**边改边自动预检**(350ms 防抖、带代际号守卫),错误/
   提醒/高危项/需重启项直接摊在工作台上;只有会把配置写坏的硬错才禁用应用按钮。
   真正的护栏一个没动:每次应用仍落只增不改的 rev、写审计(提醒与高危项一并留痕)、
   可一键回滚。注册模式切换同步改为普通危级二次确认(把后果写进弹窗,比抄键名有用)。
   ═══════════════════════════════════════════════════════════════ */
'use strict';

/* ───────── 安全存储(storage 受限环境兜底) ─────────
   Safari 私密模式 / 部分 webview / 「阻止站点数据」策略下,storage 的 setItem 会抛
   QuotaExceededError / SecurityError —— 此前 doLogin 无 catch,异常静默吞掉登录
   流程,表现为「登录接口 200 但页面毫无反应」。
   统一经 store 读写:localStorage → sessionStorage → 页面级内存,逐级兜底。
   1.2.0:主存改 localStorage(此前 sessionStorage 一关标签页即失忆,与「保持登录
   30 天」的诉求直接冲突);会话过期由 sta_admin_exp 戳把关,与后端 SESSION_TTL_S
   同口径。 */
const _mem = {};
const store = {
  get(k) {
    // _mem 优先:set() 若两层 storage 都写失败(隐私模式/配额/被策略拦),
    // 持久层里可能还躺着上一次的**旧值**;先读 storage 会把本页刚写的新值盖掉。
    // (旧实现 `sessionStorage.getItem(k) ?? _mem[k]` 同样有此倒置,顺手修掉。)
    if (k in _mem) return _mem[k];
    try { const v = localStorage.getItem(k);   if (v != null) return v; } catch (_) {}
    try { const v = sessionStorage.getItem(k); if (v != null) return v; } catch (_) {}
    return '';
  },
  set(k, v) {
    _mem[k] = v;
    try { localStorage.setItem(k, v); return; } catch (_) {}
    try { sessionStorage.setItem(k, v); } catch (_) {}
  },
  del(k) {
    delete _mem[k];                       // 删掉 _mem 后 get() 自然回落到 storage(下面也已清)
    try { localStorage.removeItem(k); }   catch (_) {}
    try { sessionStorage.removeItem(k); } catch (_) {}
  },
};

/* ───────── 会话保持 30 天 ─────────
   服务端令牌形如 <base64url(payload)>.<hmac>,payload.exp 为秒级过期时刻。
   直接读它作本地过期戳:与后端签发的 TTL 永远一致,不会因两端常量漂移而失配。
   解不出(令牌格式变更/旧版)时回落到「此刻 + 30 天」。 */
const SESSION_KEYS   = ['sta_admin_csrf', 'sta_admin_tok', 'sta_admin_mtok', 'sta_admin_exp'];
const SESSION_MAX_MS = 30 * 24 * 3600 * 1000;
function tokenExpMs(tok) {
  try {
    const p = String(tok || '').split('.')[0].replace(/-/g, '+').replace(/_/g, '/');
    if (!p) return 0;
    const exp = +JSON.parse(atob(p + '='.repeat((4 - p.length % 4) % 4))).exp;
    return Number.isFinite(exp) && exp > 0 ? exp * 1000 : 0;
  } catch (_) { return 0; }
}
function rememberSession() {                       // 登录成功后记下过期时刻
  store.set('sta_admin_exp',
            String(tokenExpMs(S.tok) || (Date.now() + SESSION_MAX_MS)));
}
function purgeExpiredSession() {                    // 首屏:过期令牌不必再往服务端跑一趟
  const exp = +store.get('sta_admin_exp') || 0;
  if (exp && Date.now() >= exp) SESSION_KEYS.forEach(k => store.del(k));
}
function clearSession() {                          // 登出 / 401:存储与内存态同时作废
  SESSION_KEYS.forEach(k => store.del(k));
  S.csrf = ''; S.tok = ''; S.mtok = '';
}
/* 绕过 _mem,只看**真正落盘**的那份令牌。
   401 处理要拿它和本次送出的令牌比对:store.get() 会优先返回本标签页内存里的旧值,
   用它比对等于自欺 —— 见 api() 里的说明。 */
function persistedTok() {
  try { const v = localStorage.getItem('sta_admin_tok');   if (v != null) return v; } catch (_) {}
  try { const v = sessionStorage.getItem('sta_admin_tok'); if (v != null) return v; } catch (_) {}
  return '';
}

/* 跨标签页同步登出。
   令牌从 sessionStorage(每标签页各一份)搬到 localStorage(全浏览器共享)之后,
   多开的标签页共用同一份凭据 —— 在 A 页登出只清了存储,B 页内存里的 S.tok 照旧能用,
   人以为「已登出」其实没有。localStorage 的 removeItem 会在**其他**标签页触发
   storage 事件,借此把 B 页也踢回登录屏。
   注:storage 事件只在同源的其他文档触发,不会在发起方自己触发,不必防重入。
   e.key === null 表示对方调了 localStorage.clear(),同样按登出处理。 */
window.addEventListener('storage', e => {
  if (e.key !== null && e.key !== 'sta_admin_tok') return;
  if (e.newValue) return;                         // 是写入/换令牌,不是清除
  if ($('#login').hidden) {                       // 本页还停在主界面 → 踢回登录
    S.csrf = ''; S.tok = ''; S.mtok = '';         // 只清内存:存储已由对方清掉,别再触发一轮事件
    showLogin('会话已在其他标签页结束 —— 请重新登录');
  }
});
purgeExpiredSession();   // 必须在下面 S 从 store 读令牌**之前**跑(否则读到已过期的旧令牌)

/* ───────── 全局状态 ───────── */
const S = {
  csrf: store.get('sta_admin_csrf') || '',
  tok:  store.get('sta_admin_tok')  || '',   // 会话令牌:X-Admin-Session 头回传(主通道)
  mtok: store.get('sta_admin_mtok') || '',
  schema: null,            // {sections, fields, deploy}
  eff: new Map(),          // key → effective item(含 layers/source)
  rev: 0, appliedRev: 0,
  staged: new Map(),       // key → 新值(原始输入,服务端收敛)
  view: 'overview',
  timers: [],
};
const $  = (q, el=document) => el.querySelector(q);
const $$ = (q, el=document) => [...el.querySelectorAll(q)];
const esc = s => String(s ?? '').replace(/[&<>"']/g,
  c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const idOf = k => 'pc-' + String(k).replace(/[^a-zA-Z0-9_-]/g, '_');
const fmtTs = ms => { if (!ms) return '—';
  const d = new Date(+ms);
  return d.toLocaleString('zh-CN', {timeZone:'Asia/Shanghai', hour12:false,
    month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', second:'2-digit'}); };
const ago = ms => { if (!ms) return '—';
  const s = Math.max(0, (Date.now() - +ms) / 1000 | 0);
  if (s < 60) return s + ' 秒前';
  if (s < 3600) return (s/60|0) + ' 分前';
  if (s < 86400) return (s/3600|0) + ' 时前';
  return (s/86400|0) + ' 天前'; };
const fmtVal = v => v === null || v === undefined ? '—'
  : typeof v === 'object' ? JSON.stringify(v) : String(v);
/* 错误 → 人话:优先服务端 message/hint,其次已知错误码映射,最后兜底文案。
   1.0.1 只读 hint||error,导致名录接口把人话放在 message 的场景(如
   not_recent_live)以及无人话的 bad_room 都以裸错误码打到用户脸上。 */
const ERRTXT = {
  bad_room: '房号需为 2–12 位纯数字',
  not_recent_live: '只允许添加近期直播过的直播间',
  room_unresolved: '查不到这个房间号 —— 请核对后重试',
  not_live_now: '该直播间当前未开播,后台也没有它的开播记录 —— 请在主播开播时再添加',
  live_unverifiable: '暂时核实不了该直播间的状态,请稍后再试',
  monitor_token_required: '名录写保护已启用 —— 请重新登录以刷新访问令牌',
  rate_limited: '操作过于频繁,请稍后再试',
  room_not_found: '房间不存在或已被移除',
  rev_not_found: '目标版本不存在',
  not_writable: '目标文件不可写(挂载只读或目录无权限)',
  not_configured: '相关路径尚未配置',
  ip_forbidden: '来源 IP 不在管理台白名单内',
  /* 1.10.0 登录:账号 + 密码 + 人机验证 + 应急链接 */
  bad_credentials: '账号或密码不正确',
  captcha_failed: '人机验证未通过,请重试',
  captcha_unavailable: '人机验证服务暂时不可用,本次登录已被拒绝 —— 请稍后重试;急用请在服务器上生成一次性应急登录链接',
  bad_ticket: '应急登录链接无效、已过期或已被使用 —— 请在服务器上重新生成',
  bad_origin: '请求来源校验未通过 —— 请直接从后台入口地址打开本页',
  no_rooms: '未解析到任何房号(以逗号 / 空格 / 换行分隔)',
  not_found: '接口不存在(前后端版本可能不一致,请刷新页面)',
  /* ── 九法VIP(4.2.5 补)──────────────────────────────────────────────
     后端 jfvip.py / admin_api.py 会回这些码。此前「值」视图压根不走 errText,
     无论哪种失败都显示 `[object Object]`;补齐映射的同时,该视图已全量改用
     errText(见 renderJfvip),两边缺一不可。 */
  disabled: '九法VIP 未启用 —— 开关可能刚改还没重启 web,或登录系统未配置',
  bad_plan: '档位不存在 —— 该 code 已从 jf_vip_plans 移除,或档位表解析失败回了空表',
  bad_hours: '撤销小时数必须大于 0',
  collision: '卡号连撞三轮仍不够 —— 卡长/字符集被改小,或卡库已近饱和,请检查配置',
  db: '用户库读写失败 —— 请查 web 日志确认 userdb 连通性',
  user_not_found: '查无此用户 —— 请核对用户名拼写与大小写',
  user_gone: '用户在事务执行期间已不存在(可能刚被删除)',
  card_not_found: '卡密不存在 —— 请核对后重输',
  card_used: '该卡密已被使用',
  card_disabled: '该卡密已作废',
  card_plan_gone: '该卡对应的档位已从配置中删除,无法兑换(fail-closed)',
  order_not_found: '订单不存在或不属于该用户',
  order_hours_invalid: '订单记录的时长非法,已拒绝入账',
  userdb_unavailable: '用户库暂不可用 —— 请查 web 日志确认连接',
  /* 4.3.0 实地核查补:以下五个码后端都会回,而映射表里一个都没有 ——
     errText 的兜底顺序是 message → hint → errors → ERRTXT → **error 原码**,
     于是它们会以裸英文码打到运维脸上。其中 too_many / purge_disabled 后端
     另带了 hint(会优先命中),但 hint 是后端某一处的临时文案,不该成为
     前端唯一的指望:哪天那个 hint 被删掉,这里就又是裸码了。 */
  no_vip_row: '该用户从未开通过九法VIP,没有可撤销的时长 —— 已取消,未写入任何流水',
  too_many: '单次提交的卡片数超过上限(500)—— 请分批操作',
  purge_disabled: '删除能力未启用 —— 请先在参数中心开启 jf_card_purge_enabled',
  bad_ids: '未选中任何有效的卡片',
  bad_request: '请求参数不完整或超出允许范围',
  /* 4.3.1:以下五个码后端**不带 hint/message**(其余未收录的码都带,errText
     会优先命中那一层),不补映射就会以裸英文码打到运维脸上。
     其中 bad_count 已实测可从管理台发卡表单触达(张数填小数)。 */
  bad_count: '发卡张数需为 1–500 之间的整数(小数会被拒绝,不做静默取整)',
  bad_dd_hours: '赠送小叮当时长需为 0–87600 之间的整数小时',
  both_plan_and_hours: '「档位」与「指定时长」只能二选一 —— 同时给出会拒绝,不替你挑',
  missing_plan_or_hours: '必须给出「档位」或「指定时长」其中之一',
  code_too_long: '内联时长码超出 plan_code 的 16 字符上限 —— 请减小时长位数',
};
const errText = (e, fb) => {
  const d = (e && e.data) || {};
  return d.message || d.hint || (Array.isArray(d.errors) && d.errors.join(';'))
    || ERRTXT[d.error] || d.error || fb;
};

/* ───────── 管理面 API 前缀(1.10.0:入口路径可配,前端不再写死) ─────────
   后端把页面挂在 /<入口>、API 挂在 /api/<入口>/*,二者同源于一个配置值(config.yaml 的
   admin.path)。这里从**页面自己的地址**推出 API 前缀:入口改名时前端零改动,源码里也不留
   任何一份路径 —— 本文件是公开可取的静态资源,读它的人读不出后台在哪。
   取地址路径的最后一段;推不出时(本地直接打开 admin.html、测试夹具把页面放在 /)回落 'admin'。 */
const API_BASE = (() => {
  let seg = '';
  try { seg = decodeURIComponent(location.pathname.split('/').filter(Boolean).pop() || ''); } catch (_) {}
  seg = seg.replace(/\.html?$/i, '');
  return '/api/' + (/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(seg) ? seg : 'admin');
})();

/* ───────── API 封装(X-Admin-Session 头主通道 + cookie 兜底 + CSRF 双提交) ───────── */
async function api(path, opt = {}) {
  const headers = Object.assign({'Content-Type': 'application/json'},
                                opt.headers || {});
  const sentTok = S.tok;
  if (sentTok) headers['X-Admin-Session'] = sentTok;   // 免疫反代/cookie 策略问题
  if ((opt.method || 'GET') !== 'GET') headers['X-Admin-CSRF'] = S.csrf;
  const r = await fetch(API_BASE + path,
                        Object.assign({credentials: 'same-origin'}, opt, {headers}));
  let data = null;
  try { data = await r.json(); } catch (_) { data = {}; }
  if (r.status === 401) {
    /* 令牌失效:本地一并作废,免得下次刷新又拿它去撞 401。
       但只作废「本次真正送出的那一份」—— 令牌现在存在 localStorage(全浏览器共享),
       一个长开的旧标签页拿着过期令牌撞 401 时,若无差别清存储,会把另一个标签页
       刚登录写入的新令牌一起删掉,还顺带把它广播踢下线(实测可复现)。
       比对必须用 persistedTok():store.get() 会先返回本页 _mem 里的旧值,比了等于没比。 */
    if (persistedTok() === sentTok) clearSession();
    else { S.csrf = ''; S.tok = ''; S.mtok = ''; }     // 存储里已是别人的新令牌:只清本页内存
    showLogin('会话已过期,请重新登录');
    throw {status: 401, data};
  }
  if (!r.ok) throw {status: r.status, data};
  return data;
}
async function monitorApi(path, opt = {}) {           // 复用既有名录接口
  const headers = Object.assign({'Content-Type': 'application/json'}, opt.headers || {});
  if (S.mtok) headers['X-Monitor-Token'] = S.mtok;
  const r = await fetch(path, Object.assign({}, opt, {headers}));
  let data = null; try { data = await r.json(); } catch (_) { data = {}; }
  if (!r.ok) throw {status: r.status, data};
  return data;
}
/* ── 确认/输入对话框:替代原生 confirm()/prompt()(1.1.0) ──
   返回 Promise:确认 → true(无输入)或输入串;取消/Esc/点遮罩 → null。
   原生弹窗功能可靠但观感与全站精致度不齐,且无法带样式化正文/危险色按钮。 */
let _askRes = null;
let _askCollect = null;
function ask(o) {
  return new Promise(res => {
    if (_askRes) _askRes(null);                 // 防重入:旧弹窗按取消收场
    _askRes = res;
    _askCollect = o.collect || null;            // 4.0.0:自定义字段回收器(仅 html 表单弹窗用)
    $('#askT').textContent = o.title || '请确认';
    // body:o.html(受信任的本地模板,innerHTML)优先于 o.body(textContent,防注入)。
    // 自定义表单字段渲染进 #askB,提交时经 collect() 回收 —— 老的纯文本/单输入弹窗
    // 不传 html/collect,走原路径,逐字节不变。
    const b = $('#askB');
    if (o.html != null) { b.innerHTML = o.html; }
    else { b.textContent = o.body || ''; }
    const i = $('#askI');
    i.hidden = !o.input; i.value = o.value || ''; i.placeholder = o.placeholder || '';
    /* 4.2.5:输入长度须与后端落库宽度对齐。九法VIP 的操作原因写进
       guantai_jf_grant_log.ref,后端 `str(note)[:64]` 静默截断 —— 不设 maxlength
       的话,运维写满一段话、以为流水里留全了,实际只留了前 64 字。
       未传 maxlength 的老调用点走 removeAttribute,行为逐字节不变。 */
    if (o.maxlength) i.setAttribute('maxlength', String(o.maxlength));
    else i.removeAttribute('maxlength');
    const y = $('#askYes');
    y.textContent = o.yes || '确定';
    y.classList.toggle('danger', !!o.danger);
    y.classList.toggle('primary', !o.danger);
    $('#ask').classList.add('open');
    // 焦点:自定义表单聚第一个可输入控件;单输入弹窗聚 #askI;否则聚确定键
    if (o.html) { const f = b.querySelector('input,select,textarea'); (f || y).focus(); if (f && f.select) f.select(); }
    else if (o.input) { i.focus(); i.select(); }
    else y.focus();
  });
}
function askDone(v) {
  $('#ask').classList.remove('open');
  const r = _askRes, col = _askCollect;
  _askRes = null; _askCollect = null;
  if (!r) return;
  // 表单弹窗:确定(v!==null)时用 collect() 现场回收字段值(元素随即被清空)
  if (col && v !== null) { let out = null; try { out = col(); } catch {} r(out); return; }
  r(v);
}

/* 提示气泡(1.4.4 加固)。此前有两处实伤,均在 jsdom 真 DOM 上复现确证:
     ① **淡出后留下一条隐形的点击拦截条**。实现只把 opacity 归 0,从不设
        hidden / display:none / pointer-events:none,而元素是
        `position:fixed; left:50%; bottom:26px; z-index:99; max-width:86vw`。
        实测淡出后 `display=block, pointerEvents=auto, opacity=0` —— 首次 toast
        之后,屏幕底部中央就**永久驻留**一条看不见却吃点击的横条,挡住其下方的
        按钮/链接。admin.css 里完全没有 #toast 规则,样式全在这段内联里,
        所以这颗雷只能在这里拆。
     ② **读屏完全听不到**。前台 index.html 的 #toast 带 role=status + aria-live,
        管理台这个动态建的元素两者皆无。
   修法:补 pointer-events:none(气泡本就不需要接收点击)、补 a11y 属性、
   淡出结束后一并 visibility:hidden(比 display:none 平滑,且彻底移出命中测试)。 */
function toast(msg, kind = 'ok') {
  let t = $('#toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast';
    t.setAttribute('role', 'status'); t.setAttribute('aria-live', 'polite');
    t.style.cssText = 'position:fixed;left:50%;bottom:26px;transform:translateX(-50%);'
      + 'z-index:99;padding:10px 18px;border-radius:10px;box-shadow:var(--shadow-pop);'
      + 'font-size:13.5px;max-width:86vw;pointer-events:none;'
      + 'transition:opacity .2s linear';
    document.body.appendChild(t); }
  t.style.background = kind === 'err' ? 'var(--seal)' : 'var(--brand)';
  t.style.color = '#fff'; t.textContent = msg;
  t.style.visibility = 'visible'; t.style.opacity = '1';
  clearTimeout(t._h); clearTimeout(t._h2);
  t._h = setTimeout(() => {
    t.style.opacity = '0';
    // 等淡出动画走完再彻底移出渲染/命中测试;时长与上面的 transition 对齐。
    t._h2 = setTimeout(() => { t.style.visibility = 'hidden'; }, 220);
  }, 2600);
}

/* ───────── 登录人机验证(1.10.0;与观测台注册 / 登录同一家供应商,脚本按需加载) ─────────
   后端口径:每次登录都要一枚**新**令牌(令牌一次性),且排在验密码之前 —— 没有令牌的请求
   连密码都碰不到;验证服务不可达时后端直接拒绝(不降级)。所以这里的纪律是:
     · 任何一次登录失败后都 reset 挂件、重新取令牌(旧令牌已被后端消费);
     · 挂件加载不出来(网络到不了验证服务)时把话说清并指路应急链接,绝不让按钮无限转圈;
     · 同一外链脚本只加载一次(重复加载 Turnstile 会重建全局对象,先挂的挂件随之失联)。 */
const CAP = { mounted: '', widgetId: null, gt: null, token: '', waiters: [], mounting: null, errored: false };
const CAP_LOAD_FAIL = '人机验证加载失败(当前网络可能无法访问验证服务)—— 可稍后重试;'
  + '急用请在服务器上生成一次性应急登录链接';
const _SCRIPT_LOADS = {};
function loadScript(src) {
  if (_SCRIPT_LOADS[src]) return _SCRIPT_LOADS[src];
  const p = new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = src; s.async = true; s.onload = () => res();
    s.onerror = () => { delete _SCRIPT_LOADS[src]; try { s.remove(); } catch (_) {} rej(new Error('script ' + src)); };
    document.head.appendChild(s);
  });
  _SCRIPT_LOADS[src] = p;
  return p;
}
const capErr = (code, message) => ({cap: code, message});
function capDeliver(tok) {
  if (!tok) {                                   // 挂件报错:在等令牌的人立刻得到明确答复
    CAP.token = '';
    CAP.waiters.splice(0).forEach(w => w.rej(capErr('captcha_unavailable', CAP_LOAD_FAIL)));
    return;
  }
  const w = CAP.waiters.shift();
  if (w) w.res(tok); else CAP.token = tok;
}
function capReset() {
  CAP.token = '';
  if (CAP.mounted === 'turnstile' && window.turnstile && CAP.widgetId != null) {
    try { window.turnstile.reset(CAP.widgetId); } catch (_) {}
  } else if (CAP.mounted === 'geetest' && CAP.gt) {
    try { CAP.gt.reset(); } catch (_) {}
  }
}
async function capMount(conf) {
  if (!conf || !conf.provider || CAP.mounted === conf.provider) return;
  if (CAP.mounting) return CAP.mounting;        // 在途的挂载复用同一个 Promise(防同一容器渲染两枚)
  CAP.mounting = capMountOnce(conf);
  try { await CAP.mounting; } finally { CAP.mounting = null; }
}
async function capMountOnce(conf) {
  const box = $('#capBox');
  if (conf.provider === 'turnstile') {
    box.hidden = false;
    await loadScript('https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit');
    CAP.widgetId = window.turnstile.render(box, {
      sitekey: conf.appId, action: conf.action || 'admin',   // 后端核对 action:注册 / 用户登录的令牌拿来无效
      // 官方尺寸:flexible = 宽度随容器(最小 300px);容器不足 300px(窄屏手机)用 compact(150×140)
      size: (box.clientWidth && box.clientWidth < 300) ? 'compact' : 'flexible',
      callback: t => { CAP.errored = false; capDeliver(t); },
      'expired-callback': () => { CAP.token = ''; },
      // 出错:在等令牌的人立刻得到答复;记下状态,下一次点登录先 reset 重新跑一遍挑战
      // (不赌验证框会不会自己重试 —— 不 reset 的话用户只能干等到超时)
      'error-callback': () => { CAP.errored = true; capDeliver(''); return true; },
    });
    CAP.mounted = 'turnstile';
  } else if (conf.provider === 'geetest') {
    box.hidden = false;
    await loadScript('https://static.geetest.com/v4/gt4.js');
    await new Promise(res => window.initGeetest4({captchaId: conf.appId, product: 'float'}, obj => {
      obj.appendTo(box);
      obj.onSuccess(() => { CAP.errored = false; try { capDeliver(JSON.stringify(obj.getValidate())); } catch (_) { capDeliver(''); } });
      obj.onError(() => { CAP.errored = true; capDeliver(''); });
      CAP.gt = obj;
      res();
    }));
    CAP.mounted = 'geetest';
  } else if (conf.provider === 'tencent') {
    await loadScript('https://turing.captcha.qcloud.com/TCaptcha.js');
    CAP.mounted = 'tencent';                     // 弹窗式:取令牌时按需唤起
  }
}
async function capToken(conf) {
  try { await capMount(conf); }
  catch (_) { throw capErr('captcha_unavailable', CAP_LOAD_FAIL); }
  if (conf.provider === 'tencent') {
    return new Promise((res, rej) => {
      try {
        const t = new window.TencentCaptcha(conf.appId, r => {
          if (r && r.ret === 0) res(JSON.stringify({ticket: r.ticket, randstr: r.randstr}));
          else rej(capErr('captcha_failed', '已取消人机验证'));
        });
        t.show();
      } catch (_) { rej(capErr('captcha_unavailable', CAP_LOAD_FAIL)); }
    });
  }
  if (CAP.token) { const t = CAP.token; CAP.token = ''; return t; }
  if (CAP.errored) { CAP.errored = false; capReset(); }   // 上一轮挑战出错:先重置再等新令牌
  return new Promise((res, rej) => {             // 令牌还没到:等挂件(必要时等人点完)再发
    const w = {};
    w.tid = setTimeout(() => {
      CAP.waiters = CAP.waiters.filter(x => x !== w);
      rej(capErr('captcha_failed', '请先完成上方的人机验证,再点「进入中枢」'));
    }, 60000);
    w.res = t => { clearTimeout(w.tid); res(t); };
    w.rej = e => { clearTimeout(w.tid); rej(e); };
    CAP.waiters.push(w);
  });
}

/* ───────── 会话:登录/登出/自恢复 ─────────
   1.10.0:登录由「一个管理口令」改为「账号 + 密码 (+ 人机验证)」。
   进门规则由后端说了算 —— 开门时先问一句 GET <API>/login:
     account  true = 必须填账号;false = 本部署未设账号(只验密码,隐藏账号框);
     captcha  {provider, appId, action} = 每次登录要过的人机验证;null = 不需要。
   问不到(网络抖动)不拦人:账号框照常显示、提交时再补问一次;判定始终在后端。 */
const LOGIN = { account: null, captcha: null, loaded: false, at: 0, busy: false, asking: null };
async function loadLoginInfo() {
  if (LOGIN.asking) return LOGIN.asking;
  // 进门规则是部署项(改了要重启 web),一分钟内不重复问:首屏会连着亮三次登录屏
  // (无令牌即亮 → /session 401 → 恢复失败),问一次就够。问失败则不缓存,下次再问。
  if (LOGIN.loaded && Date.now() - LOGIN.at < 60000)
    return {status: 200, data: {account: LOGIN.account, captcha: LOGIN.captcha}};
  LOGIN.asking = (async () => {
    try {
      const r = await fetch(API_BASE + '/login', {credentials: 'same-origin', cache: 'no-store'});
      const j = await r.json().catch(() => ({}));
      if (!r.ok) return {status: r.status, data: j};
      LOGIN.account = j.account; LOGIN.captcha = j.captcha || null; LOGIN.loaded = true; LOGIN.at = Date.now();
      const un = $('#un');
      const hide = j.account === false;
      if (hide && document.activeElement === un) $('#pw').focus();
      un.hidden = hide;
      return {status: 200, data: j};
    } catch (_) { return null; }
    finally { LOGIN.asking = null; }
  })();
  return LOGIN.asking;
}
const CAP_NOT_READY = '人机验证尚未配置完整,网页登录暂不可用 —— 请在服务器上生成一次性应急登录链接';
async function prepareLogin() {
  const res = await loadLoginInfo();
  if ($('#login').hidden) return;                // 期间已经进去了(应急链接 / 会话恢复)
  const cap = LOGIN.captcha;
  const say = t => { if (!$('#loginMsg').textContent) $('#loginMsg').textContent = t; };
  if (res && res.status === 503) say((res.data && res.data.hint) || '管理台未启用:请设置 STA_ADMIN_PASSWORD 后重启 web');
  else if (res && res.status === 403) say('来源 IP 不在白名单内');
  else if (cap && cap.unavailable) say(CAP_NOT_READY);
  else if (cap && cap.provider) {
    if (CAP.mounted) capReset();                 // 再次回到登录屏:旧令牌多半已过期,换一枚
    capMount(cap).catch(() => say(CAP_LOAD_FAIL));
  }
}
function showLogin(msg) {
  $('#shell').classList.remove('on'); $('#login').hidden = false;
  $('#drawerBtn').hidden = true; $('#loginMsg').textContent = msg || '';
  const un = $('#un');
  ((!un.hidden && !un.value) ? un : $('#pw')).focus();
  prepareLogin();
}
function acceptSession(j) {
  // 会话令牌走响应体 → JS → X-Admin-Session 头,不再依赖 cookie 回传;
  // cookie 仍由服务端同时下发,作纵深兜底。
  S.csrf = j.csrf || ''; S.tok = j.token || ''; S.mtok = j.monitor_token || '';
  store.set('sta_admin_csrf', S.csrf);
  store.set('sta_admin_tok',  S.tok);
  store.set('sta_admin_mtok', S.mtok);
  rememberSession();          // 令牌落 localStorage + 记过期时刻 → 30 天内刷新/重开浏览器免登录
}
function loginErrText(status, j) {
  if (status === 503 && j.error !== 'captcha_unavailable')
    return j.hint || '管理台未启用:请设置 STA_ADMIN_PASSWORD 后重启 web';
  if (status === 429) return j.hint || '尝试过于频繁,稍后再试';
  if (status === 403 && j.error === 'ip_forbidden') return '来源 IP 不在白名单内';
  if (status === 401 && j.error !== 'bad_ticket')
    return LOGIN.account === false ? '密码不正确' : '账号或密码不正确';
  return ERRTXT[j.error] || j.hint || '登录失败,请重试';
}
async function doLogin() {
  if (LOGIN.busy) return;          // 防连点:人机验证令牌一次性,两发并行必有一发白废
  const un = $('#un').hidden ? '' : $('#un').value.trim();
  const pw = $('#pw').value;
  if (LOGIN.account === true && !un) {
    $('#loginMsg').textContent = '请先输入管理账号'; $('#un').focus(); return;
  }
  if (!pw) {                       // 1.4.3(C4):空密码本地拦截 —— 不打后端、
    $('#loginMsg').textContent = '请先输入管理密码';   // 不吃登录限流计数,
    $('#pw').focus();                                  // 文案也不再张冠李戴。
    return;
  }
  LOGIN.busy = true; $('#loginMsg').textContent = ''; $('#loginBtn').disabled = true;
  try {
    if (!LOGIN.loaded) await loadLoginInfo();          // 开门那一问没问到:提交前补问
    const cap = LOGIN.captcha;
    let captchaToken;
    if (cap && cap.unavailable) { $('#loginMsg').textContent = CAP_NOT_READY; return; }
    if (cap && cap.provider) {
      if (cap.provider !== 'tencent' && !CAP.token) $('#loginMsg').textContent = '安全校验中…';
      try { captchaToken = await capToken(cap); }
      catch (e) { $('#loginMsg').textContent = (e && e.message) || ERRTXT.captcha_failed; return; }
      $('#loginMsg').textContent = '';
    }
    const d = await fetch(API_BASE + '/login', {method: 'POST',
      credentials: 'same-origin',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({username: un, password: pw, captchaToken})});
    const j = await d.json().catch(() => ({}));
    if (!d.ok) {
      capReset();                  // 这枚令牌后端已消费(或已作废):下一次必须换新的
      $('#loginMsg').textContent = loginErrText(d.status, j);
      if (d.status === 401) $('#pw').select();
      return;
    }
    acceptSession(j);
    $('#pw').value = '';
    await enterShell();
  } catch (e) {
    // 此前无 catch:fetch 网络异常 / 存储异常等直接吞掉整个登录流程,
    // 页面零反馈(「接口 200 但没反应」的元凶之一)。现在一律可见。
    if (!(e && e.status))   // api() 抛出的带状态错误已由 showLogin 呈现,不覆盖
      $('#loginMsg').textContent = '登录异常:'
        + ((e && (e.message || e.name)) || '网络错误') + ' —— 请查看控制台/网络面板';
  } finally { LOGIN.busy = false; $('#loginBtn').disabled = false; }
}
/* 应急登录(1.10.0):服务器上 `deploy-maxxiang.sh admin-link` 打印的链接形如
   <入口地址>#t=<票据>。票据放在 # 之后 —— 不进服务端访问日志、不随 Referer 外泄;
   读到即从地址栏抹掉,再向后端兑换成正常会话(票据 10 分钟有效、只能用一次)。 */
async function loginWithTicket(ticket) {
  showLogin('正在验证应急登录链接…');
  $('#loginBtn').disabled = true;
  try {
    const d = await fetch(API_BASE + '/login/ticket', {method: 'POST',
      credentials: 'same-origin',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ticket})});
    const j = await d.json().catch(() => ({}));
    if (!d.ok) { $('#loginMsg').textContent = loginErrText(d.status, j); return; }
    acceptSession(j);
    await enterShell();
  } catch (e) {
    $('#loginMsg').textContent = '应急登录异常:' + ((e && (e.message || e.name)) || '网络错误');
  } finally { $('#loginBtn').disabled = false; }
}
async function tryResume() {
  try {
    const j = await api('/session');
    S.csrf = j.csrf || S.csrf; S.mtok = j.monitor_token || '';
    store.set('sta_admin_csrf', S.csrf);
    store.set('sta_admin_mtok', S.mtok);
    // 服务端权威过期时刻(秒)→ 本地戳;走 HttpOnly cookie 恢复的会话也能对齐
    if (j.exp) store.set('sta_admin_exp', String(+j.exp * 1000));
    await enterShell();
  } catch (e) {
    if (e && e.status === 503)
      showLogin((e.data && e.data.hint) || '管理台未启用:请设置 STA_ADMIN_PASSWORD 后重启 web');
    else showLogin('');
  }
}
async function enterShell() {
  $('#login').hidden = true; $('#shell').classList.add('on');
  $('#drawerBtn').hidden = false;
  try {
    S.schema = await api('/schema');
    await refreshEffective();
    switchView(location.hash.replace(/^#\/?/, '') || 'overview');
    refreshRevPill();
  } catch (e) {
    // 登录成功但加载首屏数据失败。会话已改走 X-Admin-Session 头主通道,
    // 常规反代/cookie 问题不再致此;仍 401 多为多实例密钥不一致
    // (各实例 STA_ADMIN_SECRET / 密码不同)或中间层剥自定义头。
    const code = e && e.status;
    if (code === 401) {
      showLogin('登录成功但会话校验未通过。请确认多实例部署时 '
        + 'STA_ADMIN_SECRET(或密码)一致,且反代未剥离 X-Admin-Session 头。');
    } else {
      $('#main').innerHTML = '<div class="err-line" style="margin:24px">'
        + '加载失败:' + esc(errText(e, e && e.status ? 'HTTP ' + e.status : '网络错误'))
        + ' —— 请刷新重试;若持续,检查 web 服务日志。</div>';
    }
  }
}

/* ───────── 生效值拉取 ───────── */
async function refreshEffective() {
  const d = await api('/config/effective');
  S.rev = d.rev; S.appliedRev = d.applied_rev;
  S.eff = new Map(d.items.map(it => [it.key, it]));
}
async function refreshRevPill() {
  try {
    const f = await api('/fleet');
    const n = f.instances.filter(i => i.converged && !i.needs_restart.length).length;
    $('#revPill').textContent =
      'rev ' + f.target_rev + ' · ' + n + '/' + f.instances.length + ' 收敛';
    $('#revPill').style.background = f.converged ? 'var(--brand-soft)' : 'var(--gilt-soft)';
    $('#revPill').style.color = f.converged ? 'var(--brand-deep)' : '#6d5116';
  } catch (_) { $('#revPill').textContent = 'rev ' + S.rev; }
}

/* ───────── 视图路由 ───────── */
const VIEWS = {overview: '总览', params: '参数中心', revisions: '变更与版本',
               rooms: '名录管理', ticket: '票据与账号', audit: '审计日志',
               signals: '疑似脚本来源', reg: '注册与邀请', userlogin: '登录风控',
               jfvip: '九法VIP与充值', storage: '存储与保留', deploy: '部署层(只读)'};
function clearTimers() {
  S.timers.forEach(clearInterval); S.timers = [];
  clearTimeout(RM.qTimer); RM.qTimer = 0;    // 名录搜索的防抖定时器随视图一起收摊
}
function switchView(name) {
  if (!VIEWS[name]) name = 'overview';
  S.view = name; clearTimers();
  location.hash = '/' + name;
  $$('.nav-item').forEach(b => b.classList.toggle('on', b.dataset.view === name));
  $('#crumb').textContent = VIEWS[name];
  /* 1.7.3:分发处兜底。十个 render* 全是 async,此前**裸调用不接 catch** ——
     任一视图在写 innerHTML 之前抛错(4.7.7 的「注」视图就是这样),异常只会变成
     一条 unhandledrejection 沉进控制台,页面停在骨架的「加载中…/载入中…」,
     运维看到的是一个「一直在转」的页面,而不是一个报错的页面。这正是那个 bug
     能在生产里隐身的系统性原因:**没有人告诉任何人出事了**。
     这里把它翻出来 —— 十个视图一次性获得诚实的失败态。 */
  const r = ({overview: renderOverview, params: renderParams, revisions: renderRevisions,
    rooms: renderRooms, ticket: renderTicket, audit: renderAudit,
    signals: renderSignals, reg: renderReg, userlogin: renderUserLogin, jfvip: renderJfvip,
    storage: renderStorage, deploy: renderDeploy}[name])();
  if (r && typeof r.catch === 'function') r.catch(e => {
    console.error('[admin] 视图 ' + name + ' 渲染失败', e);
    if (S.view !== name) return;                 // 已经切走,别污染新视图
    const m = $('#main');
    if (m) m.innerHTML = '<div class="view-title">' + esc(VIEWS[name] || name) + '</div>'
      + '<div class="err-line">本视图渲染失败:'
      + esc(String((e && e.message) || e))
      + ' —— 请刷新重试;若持续,把浏览器控制台的报错发给维护者。</div>';
  });
}

/* ───────── 玺印:来源链(签名交互,方案 §4.2) ───────── */
const LAYERS = [
  ['default', '默', '代码默认'],
  ['yaml', '文', 'config.yaml'],
  ['env', '环', '环境变量'],
  ['runtime', '枢', '运行时覆盖'],
];
function sealsHtml(it) {
  const f = S.schema.fields[it.key];
  let h = '<span class="seal-wrap"><span class="seal-chain" role="button" tabindex="0" '
        + 'aria-label="来源链" title="点击展开四层来源">';
  for (const [l, ch] of LAYERS) {
    const set = l === 'default' ? true : !!it.layers[l + '_set'];
    const on = it.source === l;
    h += '<span class="sl' + (on ? ' on' : set ? ' set' : '') + '" data-l="' + l + '">'
       + ch + '</span>';
  }
  h += '</span>';
  if (it.source === 'cookie')
    h += ' <span class="sl-cookie" title="运行期由 login 服务 cookie 自动续期维护">续期</span>';
  h += '<span class="seal-pop">';
  for (const [l, ch, name] of LAYERS) {
    const set = l === 'default' ? true : !!it.layers[l + '_set'];
    const val = l === 'default' ? it.layers.default : it.layers[l];
    const on = it.source === l;
    h += '<div class="row' + (on ? ' cur' : '') + '">'
       + '<span class="sl' + (on ? ' on' : set ? ' set' : '') + '" data-l="' + l + '">' + ch + '</span>'
       + '<span style="flex:none;width:82px">' + name + '</span>'
       + '<span class="val">' + (set ? esc(fmtVal(val)) : '未设') + '</span></div>';
  }
  if (it.source === 'cookie')
    h += '<div class="row"><span class="sl-cookie">续期</span>'
       + '<span class="val">当前值由 cookie 自动续期链路维护(auth 系最高优先)</span></div>';
  if (it.layers.runtime_set && f && !f.readonly)
    h += '<div class="actions"><button class="btn" data-clear="' + esc(it.key)
       + '">清除运行时覆盖 → 回落</button></div>';
  h += '</span></span>';
  return h;
}
document.addEventListener('click', async e => {
  const chain = e.target.closest('.seal-chain');
  const wrapOpen = $('.seal-wrap.open');
  if (chain) {
    const w = chain.closest('.seal-wrap');
    if (wrapOpen && wrapOpen !== w) wrapOpen.classList.remove('open');
    w.classList.toggle('open'); e.stopPropagation(); return;
  }
  const clr = e.target.closest('[data-clear]');
  if (clr) {
    const key = clr.dataset.clear;
    const f = S.schema.fields[key];
    const tip = f && f.no_reset
      ? '\n(该项不回落基线:清除后保持现值,由票据自动续期接管)' : '';
    if (!await ask({title: '清除运行时覆盖',
                    body: '「' + key + '」将回落到 ENV / YAML / 默认。' + tip,
                    danger: true, yes: '清除并回落'})) return;
    try {
      const r = await api('/config/override/' + encodeURIComponent(key),
                          {method: 'DELETE'});
      toast('已清除覆盖(rev ' + r.rev + ')' + (r.hint ? ' · ' + r.hint : ''));
      await refreshEffective();
      if (S.view === 'params') renderParams();
      refreshRevPill();
    } catch (err) {
      toast(errText(err, '清除失败'), 'err');
    }
    return;
  }
  if (wrapOpen && !e.target.closest('.seal-pop')) wrapOpen.classList.remove('open');
});

/* ───────── 参数中心 ───────── */
const HOTBADGE = {hot: ['b-hot', '🟢 即时热更'], hook: ['b-hook', '🟡 钩子热更'],
                  restart: ['b-restart', '🔴 需重启'], reserved: ['b-reserved', '⚪ 预留/只读']};
function ctlHtml(key, f, it) {
  const cur = it ? it.effective : f.default;
  const dis = S.staged.has(key);
  const v = dis ? S.staged.get(key) : cur;
  if (f.readonly || f.hot === 'reserved')
    return '<div class="pvalue-ro" title="只读项:改动请编辑对应文件后重启">'
         + esc(fmtVal(cur)) + '</div>';
  if (f.type === 'bool') {
    const on = String(v) === 'true' || v === true;
    return '<button class="toggle' + (on ? ' on' : '') + '" data-k="' + esc(key)
         + '" role="switch" aria-checked="' + on + '" aria-label="' + esc(f.label) + '"></button>'
         + '<span class="mut" style="font-size:12.5px">' + (on ? '开启' : '关闭') + '</span>';
  }
  if (f.type === 'enum') {
    let o = '';
    for (const c of (f.choices || []))
      o += '<option' + (String(v) === c ? ' selected' : '') + '>' + esc(c) + '</option>';
    return '<select data-k="' + esc(key) + '" aria-label="' + esc(f.label) + '">' + o + '</select>';
  }
  if (f.sensitive) {
    // 1.4.3(B4):已暂存的新值重渲染后 value 依旧不回显(密文不落 DOM),
    // 但占位符明示状态 —— 否则切走再切回,输入框空空如也,极易误判
    // 「没存上」再输一遍(实测取证:value=""、仅剩卡片高亮)。
    const ph = dis ? '新值已暂存 ••••••••(输入以替换;清空则撤销暂存)'
                   : fmtVal(cur) + '(输入新值以覆盖)';
    /* ── 🎲 生成随机密钥(1.7.0)────────────────────────────────────────────
       只给**声明了 genBytes** 的密钥项,不是所有 sensitive 都给 —— auth.ticket
       之类是**上游签发**的凭据,本地随机生成一个只会把接入打挂;而发卡 API 密钥
       是「我方自定、对方照抄」,自己生成才是正解。

       为什么值得做:文档写的是 `openssl rand -hex 32`,而管理台的使用者可能在
       Windows / 手机 / 只有浏览器。没有便捷入口时,人会去输一个自己记得住的串 ——
       长度闸(≥24)拦得住 `123456`,拦不住 `mycompanycardkey2026x`(24 位、零熵)。
       而这把密钥的唯一作用是**凭空造出可兑换的 VIP 时长**。
       让安全的那条路成为最省事的那条路,是这个按钮存在的全部理由。

       ⚠ 必须用 crypto.getRandomValues,**绝不能用 Math.random** —— 后者是
       可预测的 PRNG(V8 用 xorshift128+,观察若干输出即可反推内部状态),
       拿它生成的"密钥"等于没有密钥。本文件此前不含任何随机源,这是第一处。 */
    const gen = Number(f.genBytes) > 0
      ? '<button class="btn ghost sec-gen" data-gen="' + esc(key)
        + '" data-bytes="' + Number(f.genBytes)
        + '" title="生成随机密钥(crypto.getRandomValues)">🎲 生成</button>'
      : '';
    /* 👁 揭示明文(1.7.0)。本台对敏感项一律掩码,而发卡密钥是**我方自定、需要交付
       给对端**的凭据 —— 没存好就再也拿不回来,只能重新生成一把、再把发卡平台的
       配置改一遍。给一个随时可点的入口,把这笔运维债消掉。
       做成「点击揭示」而不是「默认明文」:对「随时都能看到」的满足度完全相同
       (一次点击),但默认明文会让密钥随每一次配置页拉取走一遍网络、在屏幕上常驻、
       且拿不到「谁在什么时候看过」的记录 —— 后端每次揭示都落审计。 */
    const rev = f.revealable
      ? '<button class="btn ghost sec-rev" data-rev="' + esc(key)
        + '" title="查看明文(会记入审计)">👁 查看</button>'
      : '';
    /* ★ 返回**并列兄弟节点**而不是包一层 <span>。实地核查:.pctl 是 display:flex,
       输入框靠 `.pctl input[type=password]{flex:1;min-width:0}` 撑开。包一层普通
       <span> 会让 input 变成孙节点 —— 选择器仍命中(后代选择器),但 flex:1 相对的是
       那个非 flex 的 <span>,等于失效,输入框当场变窄错位。
       bool 分支(toggle + span)与数值分支(input + .unit)都是并列兄弟,照它们来。 */
    return '<input type="password" data-k="' + esc(key)
         + '" placeholder="' + esc(ph) + '" autocomplete="off">' + rev + gen;
  }
  if (f.type === 'json')
    return '<textarea data-k="' + esc(key) + '" rows="1" spellcheck="false">'
         + esc(typeof v === 'object' ? JSON.stringify(v) : v) + '</textarea>';
  const numeric = f.type === 'int' || f.type === 'float';
  return '<input type="' + (numeric ? 'number' : 'text') + '"'
       + (numeric && f.type === 'float' ? ' step="any"' : '')
       + ' data-k="' + esc(key) + '" value="' + esc(fmtVal(v)) + '" spellcheck="false">'
       + (f.unit ? '<span class="unit">' + esc(f.unit) + '</span>' : '');
}
function cardHtml(key, f) {
  const it = S.eff.get(key);
  const [bc, bt] = HOTBADGE[f.hot] || HOTBADGE.hot;
  let badges = '<span class="tag ' + bc + '">' + bt + '</span>';
  if (f.danger) badges += '<span class="tag b-danger" title="高危参数:改错代价大。不阻断应用,但请先看清说明;应用后可一键回滚">危 · 高危</span>';
  if (f.sensitive) badges += '<span class="tag b-sens">🔒 敏感</span>';
  if (f.readonly) badges += '<span class="tag b-ro">只读</span>';
  const staged = S.staged.has(key);
  let meta = '<div class="pmeta">' + esc(f.desc || '');
  if (f.depends) meta += ' <span class="dep">· ' + esc(f.depends) + '</span>';
  if (f.danger && key === 'retention.days')
    meta += ' <span class="dz">· 改小 = 下一清理周期起不可逆删除超窗数据</span>';
  meta += '</div>';
  return '<div class="pcard' + (staged ? ' staged' : '') + '" id="' + idOf(key) + '">'
    + '<div class="phead"><span class="plabel">' + esc(f.label) + '</span>'
    + '<span class="pkey">' + esc(key) + (f.env ? ' · ' + esc(f.env) : '') + '</span></div>'
    + '<div class="pbadges">' + badges + '</div>'
    + '<div class="pctl">' + ctlHtml(key, f, it) + '</div>'
    + meta
    + '<div class="pfoot"><span class="pdefault">默认 ' + esc(fmtVal(f.default))
    + '</span>' + (it ? sealsHtml(it) : '') + '</div></div>';
}
function renderParams(focusKey) {
  const secs = S.schema.sections;
  const byS = new Map(secs.map(s => [s, []]));
  for (const [k, f] of Object.entries(S.schema.fields))
    (byS.get(f.section) || byS.set(f.section, []).get(f.section)).push([k, f]);
  let h = '<div class="view-title">参数中心</div>'
    + '<div class="view-sub">全部 ' + Object.keys(S.schema.fields).length
    + ' 项 · 修改先入右下角工作台暂存,自动预检后一次应用 · 玺印展示四层来源'
    + '(<span class="sl on" data-l="runtime" style="vertical-align:-5px">枢</span>=当前生效层)</div>';
  for (const s of secs) {
    const items = byS.get(s) || [];
    if (!items.length) continue;
    h += '<div class="sec-head">' + esc(s) + '<span class="mut" style="font:12px var(--sans)">'
       + items.length + ' 项</span></div><div class="pgrid">';
    for (const [k, f] of items) h += cardHtml(k, f);
    h += '</div>';
  }
  $('#main').innerHTML = h;
  bindParamControls();
  if (focusKey) {
    const el = $('#' + idOf(focusKey));
    if (el) { el.scrollIntoView({block: 'center'}); el.classList.add('flash');
              setTimeout(() => el.classList.remove('flash'), 1700); }
  }
}
function stage(key, value) {
  const it = S.eff.get(key);
  const cur = it ? String(fmtVal(it.effective)) : '';
  if (String(value) === cur && !S.schema.fields[key].sensitive) S.staged.delete(key);
  else S.staged.set(key, value);
  const card = $('#' + idOf(key));
  if (card) card.classList.toggle('staged', S.staged.has(key));
  updateDrawerBtn();
  renderDrawerBody();
  scheduleValidate();
}
function bindParamControls() {
  $$('#main [data-k]').forEach(el => {
    const key = el.dataset.k;
    if (el.classList.contains('toggle')) {
      el.addEventListener('click', () => {
        const on = !el.classList.contains('on');
        el.classList.toggle('on', on); el.setAttribute('aria-checked', on);
        el.nextElementSibling.textContent = on ? '开启' : '关闭';
        stage(key, on);
      });
    } else {
      el.addEventListener('change', () => {
        const v = el.value;
        if (S.schema.fields[key].sensitive && !v.trim()) { S.staged.delete(key);
          $('#' + idOf(key)).classList.remove('staged'); updateDrawerBtn();
          // 1.4.3(B4 配套):撤销暂存也要让敞开的工作台立刻少一条,
          // 与 stage() 的抽屉同步口径一致。
          renderDrawerBody(); scheduleValidate();
          return; }
        stage(key, v);
      });
    }
  });
}

/* ───────── ⌘K 全局搜索 ───────── */
let palIdx = 0, palItems = [];
function openPalette() {
  $('#palette').classList.add('open');
  const inp = $('#palInput'); inp.value = ''; palRender(''); inp.focus();
}
function closePalette() { $('#palette').classList.remove('open'); }
function palRender(q) {
  q = q.trim().toLowerCase();
  const all = Object.entries(S.schema.fields);
  // 1.4.3(B2):五个字段统一小写比较。此前仅键名/env 小写,查询却被整体小写
  // —— 「上游全局 QPS」这类含大写英文的标签,无论用户输 QPS 还是 qps 都
  // 永远搜不到(实测 QPS/qps 均 0 命中);中文命中纯属侥幸(无大小写之分)。
  palItems = (q ? all.filter(([k, f]) =>
      k.toLowerCase().includes(q) || f.label.toLowerCase().includes(q)
      || (f.desc || '').toLowerCase().includes(q)
      || (f.env || '').toLowerCase().includes(q)
      || (f.section || '').toLowerCase().includes(q)) : all).slice(0, 30);
  palIdx = 0;
  $('#palList').innerHTML = palItems.map(([k, f], i) =>
    '<li data-i="' + i + '" class="' + (i === 0 ? 'on' : '') + '"><b>' + esc(f.label)
    + '</b><span class="lk">' + esc(k) + '</span><span class="ls">' + esc(f.section)
    + '</span></li>').join('') || '<li class="mut">没有匹配的参数</li>';
}
function palGo(i) {
  const it = palItems[i]; if (!it) return;
  closePalette(); switchView('params');
  requestAnimationFrame(() => renderParams(it[0]));
}

/* ───────── 变更工作台(右抽屉):暂存 → 自动预检 → 应用 → 收敛 → 回滚 ──────────
   1.8.0:去掉「校验」按钮与两道仪式性闸门(高危项逐一键入参数名、警告勾选
   「我已知悉」)。它们拦不住真正的错 —— 抄对一个键名不代表填对了值 —— 却让
   每次调参都要走一遍抄写。现在改为**边改边自动预检**(350ms 防抖):错误/提醒/
   需重启项一律直接摊在工作台上,不用点任何按钮就能看见;只有「会把配置写坏的
   硬错」才会禁用应用按钮。高危项照旧醒目标注,并写进审计,真出事一键回滚。 */
const D = {phase: 'edit', validated: null, checking: false, seq: 0, timer: 0,
           appliedRev: 0, prevRev: 0, pollN: 0};
function updateDrawerBtn() {
  $('#stCnt').textContent = S.staged.size;
  $('#drawerBtn').classList.toggle('primary', S.staged.size > 0);
}
function openDrawer() { $('#drawer').classList.add('open'); renderDrawer();
  // 只在还没有结论时补一次预检 —— 否则每次开合抽屉都白闪一遍「预检中…」,
  // 还平白多一次 /config/validate 往返。
  if (S.staged.size && !D.validated && !D.checking) scheduleValidate(0); }
function closeDrawer() { $('#drawer').classList.remove('open'); }
function resetDrawer() { D.phase = 'edit'; D.validated = null; D.checking = false;
  D.seq++; clearTimeout(D.timer); D.timer = 0; }
/* 暂存集一变就重新预检。防抖 350ms:参数中心里连打几个数字只发一次请求。
   seq 是**代际号** —— 晚到的应答若已不属于当前代际就整份丢弃,否则快慢两次
   请求交错回来会把旧结论盖到新暂存集上(与 app.js 的 addToken 同款守卫)。 */
function scheduleValidate(delay) {
  clearTimeout(D.timer);
  D.validated = null;
  if (!S.staged.size) { D.checking = false; D.seq++; renderDrawerResult(); return; }
  D.checking = true;
  renderDrawerResult();
  D.timer = setTimeout(doValidate, delay === undefined ? 350 : delay);
}
function stagedItemsHtml() {
  if (!S.staged.size) return '<div class="empty">尚无暂存变更 —— 到「参数中心」修改任意项,'
    + '会先聚拢到这里,自动预检后一次应用。</div>';
  let h = '';
  for (const [k, v] of S.staged) {
    const f = S.schema.fields[k], it = S.eff.get(k);
    const old = it ? fmtVal(it.effective) : '—';
    const nv = f.sensitive ? '••••••••(新值已录入)' : fmtVal(v);
    h += '<div class="d-item"><button class="rm" data-rm="' + esc(k)
       + '" aria-label="移除">✕</button><span class="k">' + esc(f.label) + '</span> '
       + (f.danger ? '<span class="tag b-danger">危</span> ' : '')
       + '<span class="pkey">' + esc(k) + '</span><br>'
       + '<span class="ov">' + esc(old) + '</span> → <span class="nv">' + esc(nv)
       + '</span></div>';
  }
  return h;
}
/* 渲染分两层,**刻意的**:
     renderDrawerBody()   —— 暂存条目 + 备注框 + 一个空的 #dResult 容器。
                             只在暂存集真的变了(暂存/移除/清空/开抽屉)时重建。
     renderDrawerResult() —— 只换 #dResult 里那几行结论 + 页脚按钮。
   分层的理由是**焦点**:预检是异步的,回来时若整块 innerHTML 重建,用户正在
   输入的备注框会连同焦点与光标位置一起被销毁重建(输一半的备注光标跳回开头)。
   旧实现只在显式动作时重绘所以碰不到这条;改成自动预检后,一次在途预检恰好
   撞上用户开始敲备注就会踩中 —— 分层后 #dNote 从此不在重建范围内。 */
function renderDrawerBody() {
  const body = $('#dBody');
  if (!body || D.phase === 'applied') return;
  let h = stagedItemsHtml();
  if (S.staged.size)
    h += '<textarea class="d-note" id="dNote" placeholder="变更备注(进审计;例:上游限流调优)"></textarea>';
  h += '<div id="dResult"></div>';
  body.innerHTML = h;
  $$('#dBody [data-rm]').forEach(b => b.addEventListener('click', () => {
    S.staged.delete(b.dataset.rm);
    const card = $('#' + idOf(b.dataset.rm)); if (card) card.classList.remove('staged');
    updateDrawerBtn(); renderDrawerBody(); scheduleValidate(0);
    if (S.view === 'params') renderParams();
  }));
  renderDrawerResult();
}
function renderDrawerResult() {
  const box = $('#dResult');
  if (!box || D.phase === 'applied') return;
  let h = '';
  const V = D.validated;
  if (!S.staged.size) h = '';
  else if (D.checking) h = '<div class="hint-line">预检中…</div>';
  else if (V) {
    // 5.2.0 复查:预检是便利设施不是闸门(见 doValidate 注)—— 回包缺 errors 也不能让抽屉炸掉
    const errs = Array.isArray(V.errors) ? V.errors : [];
    for (const e of errs) h += '<div class="err-line">✕ ' + esc(e) + '</div>';
    for (const w of (V.warnings || [])) h += '<div class="warn-line">⚠ ' + esc(w) + '</div>';
    if ((V.danger_keys || []).length)
      h += '<div class="warn-line">危 · 高危项:' + V.danger_keys.map(esc).join('、')
         + ' —— 改错代价大,应用前请再看一眼;出事可一键回滚到上一版</div>';
    if ((V.restart_keys || []).length)
      h += '<div class="hint-line">🔴 含需重启项:' + V.restart_keys.map(esc).join('、')
         + ' —— 应用后各实例会标注「等待重启」,并给出重启指令</div>';
    if (!errs.length)
      h += '<div class="hint-line">✓ 预检通过,可以应用</div>';
  }
  box.innerHTML = h;
  renderDrawerActions();
}
function renderDrawer() {
  $('#dSub').textContent = S.staged.size ? S.staged.size + ' 项待应用' : '';
  if (D.phase === 'applied') { renderConverge(); return; }
  renderDrawerBody();
}
/* 只有硬错才拦人。预检还没回来时也放行 —— 应用路径后端会再校一遍同一份规则,
   真有错就是 422 回来照样拦得住;为一次网络往返把按钮锁死才是白等。 */
function canApply() {
  return S.staged.size > 0 && !(D.validated && Array.isArray(D.validated.errors) && D.validated.errors.length);
}
function renderDrawerActions() {
  const act = $('#dActions');
  if (D.phase === 'applied') {
    act.innerHTML = '<button class="btn" id="dDone">完成</button>'
      + (D.prevRev > 0 ? '<button class="btn danger" id="dRoll">回滚到 rev '
         + D.prevRev + '</button>' : '');
    const done = $('#dDone'); if (done) done.onclick = () => { resetDrawer(); renderDrawer(); };
    const roll = $('#dRoll'); if (roll) roll.onclick = () => doRollback(D.prevRev);
    return;
  }
  act.innerHTML = '<button class="btn" id="dClr"' + (S.staged.size ? '' : ' disabled')
    + '>清空</button><span style="flex:1"></span>'
    + '<button class="btn primary" id="dApply"' + (canApply() ? '' : ' disabled')
    + '>应用变更</button>';
  $('#dClr').onclick = () => { S.staged.clear();
    $$('.pcard.staged').forEach(c => c.classList.remove('staged'));
    updateDrawerBtn(); renderDrawerBody(); scheduleValidate(0);
    $('#dSub').textContent = ''; };
  $('#dApply').onclick = doApply;
}
async function doValidate() {
  const gen = ++D.seq;
  if (!S.staged.size) { D.checking = false; renderDrawerResult(); return; }
  try {
    const r = await api('/config/validate', {method: 'POST',
      body: JSON.stringify({changes: Object.fromEntries(S.staged)})});
    if (gen !== D.seq) return;
    D.validated = r;
  } catch (e) {
    if (gen !== D.seq) return;
    // 预检是**便利设施**不是闸门:它自己挂了不该让人无法保存。留空结论、
    // 放行应用按钮,由应用路径的后端校验兜底(同一份规则,同样会拦)。
    D.validated = null;
    toast(errText(e, '预检请求失败(不影响应用,后端会再校一次)'), 'err');
  } finally {
    if (gen === D.seq) { D.checking = false; renderDrawerResult(); }
  }
}
async function doApply() {
  const note = ($('#dNote') && $('#dNote').value) || '';
  clearTimeout(D.timer); D.seq++; D.checking = false;
  try {
    const r = await api('/config/apply', {method: 'POST',
      body: JSON.stringify({changes: Object.fromEntries(S.staged), note})});
    D.prevRev = S.rev; D.appliedRev = r.rev; D.phase = 'applied'; D.pollN = 0;
    S.staged.clear(); updateDrawerBtn();
    await refreshEffective(); refreshRevPill();
    if (S.view === 'params') renderParams();
    toast('已应用为 rev ' + r.rev
      + ((r.restart_keys || []).length ? '(含需重启项)' : '')
      + ((r.warnings || []).length ? ' · ' + r.warnings.length + ' 条提醒已记入审计' : ''));
    renderConverge(); pollConverge();
  } catch (e) {
    // 1.8.0:need_confirm / warnings 两类阻断已下线,这里只剩 errors 一种真错。
    const d = e.data || {};
    if (d.errors) D.validated = {errors: d.errors, warnings: [],
                                 restart_keys: [], danger_keys: []};
    else toast(errText(e, '应用失败'), 'err');
    renderDrawer();
  }
}
function instChip(i, target) {
  /* 1.7.3:把「基础设施抖动」与「配置真错」分开呈现。
     此前只看 errors.length 就写死「套用异常」——运维看到红字会以为参数填错了,
     实际上最常见的那条是 Redis 读超时(`敏感值读取失败 …`)。后端现在会在心跳里
     带 retry_pending=1 表示「这次没套完,下个心跳周期会自己重来」;此时按黄色
     「重试中」呈现,并明说无需人工介入。老后端不带该字段 → undefined → 落回旧行为。 */
  const retrying = !!i.retry_pending && i.errors.length > 0;
  const cls = retrying ? 'lag' : i.errors.length ? 'err' : i.needs_restart.length ? 'lag'
            : i.applied_rev >= target ? 'ok' : 'lag';
  let st = retrying ? '重试中' : i.errors.length ? '套用异常'
         : i.needs_restart.length ? '等待重启'
         : i.applied_rev >= target ? '已收敛' : '套用中 rev ' + i.applied_rev;
  let extra = '';
  if (i.needs_restart.length)
    extra = '<div class="restart-cmd" data-copy="docker compose restart ' + esc(i.role)
      + '" title="点击复制">$ docker compose restart ' + esc(i.role) + ' <span class="mut"># '
      + i.needs_restart.map(esc).join('、') + ' 待生效</span></div>';
  if (i.errors.length)
    extra = '<div class="err-line" style="margin:6px 0 0">' + i.errors.map(esc).join('<br>')
      + (retrying ? '<div class="mut" style="margin-top:4px">基础设施抖动 · 下个心跳周期(≤30s)'
                    + '自动重试,无需人工介入;若一直不消,查 Redis 可达性与负载。</div>' : '')
      + '</div>';
  return '<div class="inst ' + cls + '"><span class="dot"></span><span class="who">'
    + esc(i.instance) + '</span><span class="st">' + st + '</span></div>' + extra;
}
async function renderConverge() {
  const body = $('#dBody');
  // 1.4.3(B3):头部计数与事实对齐 —— 应用/回滚后暂存已清,此前 #dSub 残留
  // 「N 项待应用」,与正文「已落为 rev N · 已收敛」同框互撞(实测取证)。
  $('#dSub').textContent = S.staged.size ? S.staged.size + ' 项待应用' : '';
  let f;
  try { f = await api('/fleet'); } catch (_) { f = {target_rev: D.appliedRev, instances: []}; }
  let h = '<div class="hint-line">已落为 <b class="mono">rev ' + D.appliedRev
    + '</b>,正在等待各实例回执收敛(pub/sub 秒级 · 心跳 ≤30s 兜底)</div>';
  if (!f.instances.length)
    h += '<div class="empty">尚无实例心跳 —— worker/web 启动后每 30s 上报;'
       + '若长期为空请确认进程在运行且 Redis 可达。</div>';
  for (const i of f.instances) h += instChip(i, f.target_rev);
  body.innerHTML = h;
  $$('#dBody [data-copy]').forEach(el => el.onclick = () => {
    navigator.clipboard && navigator.clipboard.writeText(el.dataset.copy);
    toast('已复制重启指令'); });
  renderDrawerActions(); refreshRevPill();
}
function pollConverge() {
  const t = setInterval(async () => {
    if (D.phase !== 'applied' || ++D.pollN > 40) { clearInterval(t); return; }
    try {
      const f = await api('/fleet');
      if ($('#drawer').classList.contains('open')) renderConverge();
      if (f.converged) { clearInterval(t); toast('全部实例已收敛 ✓'); }
    } catch (_) {}
  }, 1500);
}
async function doRollback(toRev) {
  if (!await ask({title: '回滚到 rev ' + toRev,
                  body: '将以该版本快照落一版新 revision(链路只增不改);'
                      + '敏感项不参与回滚,保持现值。',
                  danger: true, yes: '回滚'})) return;
  try {
    const r = await api('/config/rollback', {method: 'POST',
      body: JSON.stringify({to_rev: toRev})});
    toast('已回滚:落为 rev ' + r.rev
      + (r.skipped_sensitive && r.skipped_sensitive.length ? '(敏感项保持现值)' : ''));
    D.prevRev = 0; D.appliedRev = r.rev; D.pollN = 0;
    await refreshEffective(); refreshRevPill();
    if (S.view === 'params') renderParams();
    if (S.view === 'revisions') renderRevisions();
    renderConverge(); pollConverge();
  } catch (e) {
    toast(errText(e, '回滚失败'), 'err');
  }
}

/* ───────── 览:总览驾驶舱 ───────── */
async function renderOverview() {
  $('#main').innerHTML = '<div class="view-title">总览</div>'
    + '<div class="view-sub">进程舰队 · 配置收敛 · 运行脉搏(5s 轮询)</div>'
    + '<div id="ovBody" class="empty">载入中…</div>';
  const draw = async () => {
    let o = {}, f = {instances: [], target_rev: 0};
    let oErr = false, fErr = false;
    try { o = await api('/overview'); } catch (e) { if (e && e.status === 401) return; oErr = true; }
    try { f = await api('/fleet'); }    catch (e) { if (e && e.status === 401) return; fErr = true; }
    // 1.4.3(A3 同族扫尾):两路都失败 = 纯网络/后端故障,此前照画一屏「—」加
    // 「暂无实例心跳」,读起来像系统状态而非读取失败。本视图 5s 自愈,故给
    // 诚实错误 + 重试承诺即可;单路失败仍按原样局部呈现(各卡自带排障提示)。
    if (oErr && fErr) {
      const el = $('#ovBody');
      if (el) el.outerHTML = '<div id="ovBody"><div class="err-line">总览读取失败'
        + ' —— 5 秒后自动重试;若持续,检查 web 服务日志。</div></div>';
      return;
    }
    const st = (n, l) => '<div class="stat"><div class="num">' + (n ?? '—')
      + '</div><div class="lab">' + l + '</div></div>';
    let h = '<div class="ov-grid">'
      + st(o.rooms ? o.rooms.manual : '—', '策展房(前端可见)')
      + st(o.rooms ? o.rooms.discovered : '—', '自动发现房')
      + st(o.rooms ? o.rooms.active_total : '—', '后台抓取总数')
      + st(o.pending ?? '—', '挂起待归一')
      + st(o.queue_depth ?? '—', '调度队列深度')
      + st(o.ingest ? (o.ingest.per_min ?? '—') : '—', '近 1 分入库局数')
      + '</div>';
    /* 1.11.0:存储告警上首屏。「储」视图再详尽,运维不点进去就等于没有 ——
       清扫报错 / 流水触及行数上限 / 清扫停摆 / 保留期被关 / worker 大表清理停摆,
       这五类直接顶在总览最上面。后端只读进程内状态,worker 那条复用总览本来就有的
       一次 Redis 读取,故可以跟着 5s 轮询走。 */
    if (o.storage_alerts && o.storage_alerts.length)
      h = o.storage_alerts.map(a => '<div class="' + (a.level === 'bad' ? 'err-line' : 'warn-line')
        + '" style="margin:0 0 8px">' + esc(a.text)
        + ' <a href="#/storage" style="color:inherit;font-weight:600;white-space:nowrap">'
        + '去「储」查看 →</a></div>').join('') + h;
    h += '<div class="ov-two"><div class="card"><b>实例舰队</b> <span class="mut">目标 rev '
      + f.target_rev + '</span>';
    if (!f.instances.length)
      h += '<div class="empty">暂无实例心跳(worker/web 每 30s 上报;检查进程与 Redis)</div>';
    for (const i of f.instances)
      h += instChip(i, f.target_rev)
        + '<div class="kv mut" style="margin:-2px 0 6px 18px;font-size:12px">'
        + '<span>boot rev ' + i.boot_rev + ' · 启动于 ' + fmtTs(i.started_ms)
        + '</span><span>心跳 ' + ago(i.ts_ms) + '</span></div>';
    h += '</div><div class="card"><b>后台巡检</b>';
    const rl = o.retention_last, dl = o.discovery_last;
    h += '<div class="kv"><span>保留清理 · 上次</span><b>' + (rl ? esc(rl.ts || fmtTs(rl.ts_ms))
      : '尚未执行') + '</b></div>';
    if (rl) h += '<div class="kv mut"><span>删除 rounds/pred</span><b>' + rl.rounds + ' / '
      + rl.predictions + (rl.capped ? '(达护栏)' : '') + '</b></div>';
    h += '<div class="kv"><span>自动发现 · 上次</span><b>' + (dl ? esc(dl.ts || fmtTs(dl.ts_ms))
      : '尚未执行') + '</b></div>';
    if (dl) h += '<div class="kv mut"><span>在播/新增/回收</span><b>' + dl.unique + ' / '
      + dl.new_admitted + ' / ' + dl.pruned + '</b></div>';
    if (o.ingest) h += '<div class="kv mut"><span>入库速率</span><b>'
      + (o.ingest.rate ?? '—') + ' 局/s · 活跃 ' + (o.ingest.active ?? '—')
      + ' 房(' + ago(o.ingest.ts_ms) + ')</b></div>';
    h += '</div></div>';
    const el = $('#ovBody'); if (el) el.outerHTML = '<div id="ovBody">' + h + '</div>';
  };
  await draw(); refreshRevPill();
  S.timers.push(setInterval(() => { draw(); refreshRevPill(); }, 5000));
}

/* ───────── 更:变更与版本 ───────── */
async function renderRevisions() {
  let d;
  try { d = await api('/config/revisions?limit=100'); }
  catch (e) {
    if (e && e.status === 401) return;            // 已由 api() 弹回登录
    // 1.4.3(A3):读取失败不再伪装成「尚无运行时覆盖」空态 —— 假空态会让
    // 运维误以为链路健康(与「注」视图 4.0.5「假数据比没数据更糟」同一原则,
    // 补齐当时漏改的本视图);报错口径对齐票据/名录视图。
    $('#main').innerHTML = '<div class="view-title">变更与版本</div>'
      + '<div class="err-line">版本历史读取失败:'
      + esc(errText(e, (e && e.status) ? 'HTTP ' + e.status : '网络错误'))
      + ' —— 请刷新重试;若持续,检查 web 服务日志。</div>';
    return;
  }
  let h = '<div class="view-title">变更与版本</div>'
    + '<div class="view-sub">每次应用都是一版不可变快照;回滚 = 以历史快照落新版本,链路只增不改 '
    + '<button class="btn" id="expY">导出 YAML 覆盖</button> '
    + '<button class="btn" id="expE">导出 .env 片段</button></div>';
  if (!d.items.length) h += '<div class="empty">尚无运行时覆盖 —— 所有参数按 ENV / YAML / 默认生效。</div>';
  else {
    h += '<table class="tbl"><tr><th>rev</th><th>时间</th><th>操作者</th><th>备注</th>'
      + '<th>变更</th><th></th></tr>';
    const latest = d.items[0].rev;
    for (const r of d.items) {
      const keys = Object.keys(r.diff || {});
      h += '<tr><td class="mono">' + r.rev + '</td><td>' + fmtTs(r.ts_ms) + '</td><td>'
        + esc(r.author) + '</td><td>' + esc(r.note || '—') + '</td>'
        + '<td><details><summary>' + keys.length + ' 项</summary><div class="mono" '
        + 'style="font-size:12px;max-width:420px;word-break:break-all">'
        + keys.map(k => esc(k) + ': ' + esc(fmtVal((r.diff[k] || {}).old)) + ' → '
                      + esc(fmtVal((r.diff[k] || {}).new))).join('<br>')
        + '</div></details></td>'
        + '<td>' + (r.rev !== latest ? '<button class="btn" data-roll="' + r.rev
                    + '">回滚至此</button>' : '<span class="mut">当前</span>') + '</td></tr>';
    }
    h += '</table>';
  }
  $('#main').innerHTML = h;
  $('#expY').onclick = () => dlExport('yaml');
  $('#expE').onclick = () => dlExport('env');
  $$('#main [data-roll]').forEach(b => b.onclick = () => doRollback(+b.dataset.roll));
}
/* 导出走 fetch + X-Admin-Session 头 + Blob 下载(1.1.0)。
   1.0.1 用 window.open 只能靠 cookie 兜底通道 —— 与本页会话架构的立论
   (cookie 在部分反代/浏览器策略下不可靠,故头为主通道)自相矛盾:
   在那些环境点导出会开出一个 401 JSON 标签页。 */
async function dlExport(fmt) {
  try {
    const headers = {};
    if (S.tok) headers['X-Admin-Session'] = S.tok;
    const r = await fetch(API_BASE + '/config/export?fmt=' + fmt,
                          {credentials: 'same-origin', headers});
    if (r.status === 401) { showLogin('会话已过期,请重新登录'); return; }
    if (!r.ok) throw 0;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(await r.blob());
    a.download = fmt === 'env' ? 'sta-overrides.env' : 'sta-overrides.yaml';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast('已导出 ' + a.download);
  } catch (_) { toast('导出失败', 'err'); }
}

/* ───────── 名:名录管理(1.2.0 分页) ─────────
   此前:GET /rooms 一把梭返回全部房 → 前端把整表拼成一个巨型 innerHTML,
   再给每行两个按钮各挂一个 onclick。数千房时 = 数千次 Redis 往返 + 几万个
   DOM 节点 + 上万个监听器,「载入就卡」。
   现在:服务端分页(page/page_size/q/src),前端每页只画 50 行,行内动作走
   **事件委托**(表体一个监听器)。工具条与表体分离渲染 —— 翻页/搜索只换表体,
   搜索框不被重建,焦点与光标位置自然保住。 */
const RM = {page: 1, size: 50, q: '', src: 'all', ppage: 1, qTimer: 0, seq: 0};
const RM_SIZES = [25, 50, 100, 200];

/* 页码写进 data-* 而不是从文案里正则抠 —— 文案随时会改,属性不会 */
function rmPagerHtml(id, page, pages, total, unit) {
  if (!total) return '';
  const btn = (act, label, dis, aria) =>
    `<button class="btn ghost pg-b" data-act="${act}" ${dis ? 'disabled' : ''} `
    + `aria-label="${aria}" title="${aria}">${label}</button>`;
  return `<div class="pager" data-pg="${id}" data-page="${page}" data-pages="${pages}">
    ${btn('first', '«', page <= 1, '首页')}${btn('prev', '‹', page <= 1, '上一页')}
    <span class="pg-at">第 <b>${page}</b> / ${pages} 页<span class="mut"> · 共 ${total} ${unit}</span></span>
    ${btn('next', '›', page >= pages, '下一页')}${btn('last', '»', page >= pages, '末页')}
  </div>`;
}

function rmRowsHtml(d) {
  if (!d.total) {
    return `<div class="empty">${d.q || d.src !== 'all'
      ? '没有匹配的房间 —— 换个关键词或来源筛选试试。'
      : '名录为空 —— 用上方入口添加,或等待自动发现纳管。'}</div>`;
  }
  let h = '<table class="tbl"><thead><tr><th>房号</th><th>别名</th><th>来源</th>'
        + '<th>加入</th><th></th></tr></thead><tbody>';
  for (const r of d.items)
    h += '<tr><td class="mono">' + esc(r.room) + '</td><td>' + esc(r.alias)
      + ' <button class="btn ghost" data-al="' + esc(r.room) + '" data-alias="' + esc(r.alias)
      + '" title="改别名">✎</button></td>'
      + '<td>' + (r.discovered ? '<span class="tag b-hook">自动发现</span>'
                               : '<span class="tag b-hot">策展</span>') + '</td>'
      + '<td class="mut">' + (r.added_at ? ago(r.added_at) : '—') + '</td>'
      + '<td><button class="btn" data-rmv="' + esc(r.room) + '">移除</button></td></tr>';
  return h + '</tbody></table>' + rmPagerHtml('r', d.page, d.pages, d.total, '房');
}

function rmPendHtml(d) {
  if (!d.pending_total) return '';
  let h = '<div class="card" style="margin-top:14px"><b>挂起待归一</b> '
    + '<span class="mut">归一暂时失败的短号,janitor 周期重试;>24h 自动放弃</span>'
    + '<table class="tbl"><thead><tr><th>别名</th><th>挂起时长</th><th></th></tr></thead><tbody>';
  for (const p of d.pending)
    h += '<tr><td class="mono">' + esc(p.alias) + '</td><td>' + ago(p.since_ms) + '</td>'
      + '<td><button class="btn" data-ab="' + esc(p.alias) + '">放弃</button></td></tr>';
  return h + '</tbody></table>'
    + rmPagerHtml('p', d.pending_page, d.pending_pages, d.pending_total, '条') + '</div>';
}

/* 只重画表体 / 计数 / 分页条(工具条与输入框原地不动)。
   连点翻页不丢点击:用递增令牌作废迟到的旧响应,而不是 busy 锁把点击吞掉。 */
async function loadRooms() {
  if (S.view !== 'rooms') return;      // 防抖定时器在切走视图后迟到触发 → 别再白发一次请求
  const my = ++RM.seq;
  const body = $('#rmBody');
  if (body) body.setAttribute('aria-busy', 'true');
  const qs = new URLSearchParams({page: RM.page, page_size: RM.size, q: RM.q,
                                  src: RM.src, ppage: RM.ppage});
  let d;
  try { d = await api('/rooms?' + qs); }
  catch (e) {
    if (my !== RM.seq || S.view !== 'rooms') return;
    if (e && e.status === 401) return;              // 已由 api() 弹回登录
    if (body) { body.removeAttribute('aria-busy');
      body.innerHTML = '<div class="err-line">名录读取失败:'
        + esc(errText(e, '网络错误')) + '</div>'; }
    return;
  }
  if (my !== RM.seq || S.view !== 'rooms') return;  // 有更新的请求在跑 / 用户切走了视图
  // 服务端会把越界页码夹紧(如删掉末页最后一行);以回执为准,避免前后端页码打架
  RM.page = d.page; RM.size = d.page_size; RM.ppage = d.pending_page;
  if (body) { body.removeAttribute('aria-busy'); body.innerHTML = rmRowsHtml(d); }
  const cnt = $('#rmCount');
  if (cnt) cnt.textContent = `${d.active_total} 房(策展 ${d.manual_total}`
    + ` · 自动发现 ${d.discovered_total})`
    + (d.q || d.src !== 'all' ? ` · 命中 ${d.total}` : '');
  const pend = $('#rmPend');
  if (pend) pend.innerHTML = rmPendHtml(d);
  const sel = $('#rmSize');
  if (sel && +sel.value !== RM.size) sel.value = String(RM.size);
}

/* 分页条点击:页码/总页数从 .pager 的 data-* 读,不依赖文案 */
function rmOnPager(e) {
  const b = e.target.closest('[data-act]');
  if (!b || b.disabled) return false;
  const box = b.closest('.pager'); if (!box) return false;
  const page = +box.dataset.page, pages = +box.dataset.pages, act = b.dataset.act;
  const to = act === 'first' ? 1 : act === 'last' ? pages
           : act === 'prev' ? page - 1 : page + 1;
  const next = Math.max(1, Math.min(to, pages));
  if (next === page) return true;
  if (box.dataset.pg === 'r') RM.page = next; else RM.ppage = next;
  loadRooms();
  return true;
}

/* 行内动作委托。#rmBody / #rmPend 每次 renderRooms 都是全新元素,
   监听器随旧元素一起被丢弃 —— 不会像挂在常驻的 #main 上那样逐次累积。 */
async function rmOnBody(e) {
  if (rmOnPager(e)) return;
  const al = e.target.closest('[data-al]');
  if (al) {
    const room = al.dataset.al;
    const alias = await ask({title: '设置展示别名', body: '房 ' + room,
                             input: true, value: al.dataset.alias || room,
                             placeholder: '留空 = 用房号本身', yes: '保存'});
    if (alias === null) return;
    try { await api('/rooms/' + encodeURIComponent(room) + '/alias',
        {method: 'POST', body: JSON.stringify({alias})});
      toast('别名已更新'); loadRooms();
    } catch (err) { toast(errText(err, '别名更新失败'), 'err'); }
    return;
  }
  const rmv = e.target.closest('[data-rmv]');
  if (rmv) {
    if (!await ask({title: '移除监控房 ' + rmv.dataset.rmv,
                    body: '历史数据保留在库,可随时重新添加。',
                    danger: true, yes: '移除'})) return;
    try { await monitorApi('/api/monitor/remove?room=' + encodeURIComponent(rmv.dataset.rmv),
                           {method: 'POST'});
      toast('已移除'); loadRooms();
    } catch (err) { toast(errText(err, '移除失败'), 'err'); }
  }
}
async function rmOnPend(e) {
  if (rmOnPager(e)) return;
  const ab = e.target.closest('[data-ab]');
  if (!ab) return;
  if (!await ask({title: '放弃挂起房 ' + ab.dataset.ab,
                  body: '将停止对该房号的归一重试;之后仍可重新添加。',
                  danger: true, yes: '放弃'})) return;
  try { await api('/rooms/pending/' + encodeURIComponent(ab.dataset.ab), {method: 'DELETE'});
    toast('已放弃'); loadRooms();
  } catch (err) { toast(errText(err, '操作失败'), 'err'); }
}

async function renderRooms() {
  RM.page = 1; RM.ppage = 1; RM.q = ''; RM.src = 'all'; RM.seq++;   // 进本视图从头开始
  const sizeOpts = RM_SIZES.map(n =>
    `<option value="${n}"${n === RM.size ? ' selected' : ''}>每页 ${n}</option>`).join('');
  $('#main').innerHTML = '<div class="view-title">名录管理</div>'
    + '<div class="view-sub">复用既有 /api/monitor 通路:添加走批量准入(去重·有界归一·错峰起抓);'
    + 'config.yaml 的 rooms 仅作首启种子,日常增删在此</div>'
    + '<div class="card" style="margin-bottom:14px"><b>添加监控房</b>'
    + '<div class="pctl" style="margin-top:8px"><input id="rmOne" placeholder="单房号(短号自动归一)">'
    + '<button class="btn primary" id="rmAdd">添加</button></div>'
    + '<div class="pctl"><textarea id="rmBulk" rows="2" '
    + 'placeholder="批量粘贴:逗号/空格/换行分隔,一次数千房也安全"></textarea>'
    + '<button class="btn" id="rmBulkGo">批量添加</button></div>'
    + '<div class="mut" id="rmMsg" style="font-size:12.5px"></div></div>'
    + '<div class="card"><b>活跃名录</b> <span class="mut" id="rmCount">读取中…</span>'
    + '<div class="rm-tools">'
    +   '<input id="rmQ" class="rm-q" placeholder="搜索房号 / 别名…" autocomplete="off" '
    +          'enterkeyhint="search" aria-label="搜索活跃名录" '
    +          'title="只筛本表(活跃名录);下方挂起表不受影响">'
    +   '<select class="sel" id="rmSrc" aria-label="来源筛选">'
    +     '<option value="all">全部来源</option><option value="manual">仅策展</option>'
    +     '<option value="discovered">仅自动发现</option></select>'
    +   `<select class="sel" id="rmSize" aria-label="每页条数">${sizeOpts}</select>`
    + '</div>'
    + '<div id="rmBody"><div class="empty">读取中…</div></div></div>'
    + '<div id="rmPend"></div>';

  // 1.4.3(C2):错误与成功不再同权重同灰 —— 失败用玺印红,一眼可辨
  // (此前「房号需为 2–12 位纯数字」是一行不起眼的灰字,小白极易漏看)。
  const msg = (t, kind) => { const m = $('#rmMsg'); if (!m) return;
    m.textContent = t; m.style.color = kind === 'err' ? 'var(--seal-deep)' : ''; };

  $('#rmAdd').onclick = async () => {
    const r = $('#rmOne').value.trim(); if (!r) return;
    try { const j = await monitorApi('/api/monitor/add?room=' + encodeURIComponent(r),
                                     {method: 'POST'});
      if (j.ok) { $('#rmOne').value = ''; msg('已添加 ' + (j.resolvedRoomId || j.room || r)); }
      else msg(errText({data: j}, '添加失败'), 'err');
      loadRooms();
    } catch (e) { msg(errText(e, '添加失败'), 'err'); }
  };
  $('#rmBulkGo').onclick = async () => {
    const t = $('#rmBulk').value.trim(); if (!t) return;
    msg('批量准入中…(有界归一 + 错峰起抓)');
    try { const j = await monitorApi('/api/monitor/add-bulk', {method: 'POST',
        body: JSON.stringify({rooms: t})});
      // 1.0.1 读 j.total,但后端字段是 deduped —— 「去重后」恒显 ?;现按实契约读取
      msg('完成:新增 ' + (j.added ?? '?') + ' · 挂起 ' + (j.pending ?? 0)
        + ' · 去重后 ' + (j.deduped ?? j.total ?? '?')
        + (j.truncated ? ' · 超上限截断 ' + j.truncated : ''));
      $('#rmBulk').value = '';
      loadRooms();
    } catch (e) { msg(errText(e, '批量添加失败'), 'err'); }
  };

  // 搜索:250ms 防抖,回车立即;改词回到第 1 页(否则会停在一个空页上)
  const doSearch = v => { RM.q = v.trim(); RM.page = 1; RM.ppage = 1; loadRooms(); };
  $('#rmQ').addEventListener('input', e => {
    clearTimeout(RM.qTimer);
    const v = e.target.value;
    RM.qTimer = setTimeout(() => doSearch(v), 250);
  });
  $('#rmQ').addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.isComposing) { clearTimeout(RM.qTimer); doSearch(e.target.value); }
  });
  $('#rmSrc').addEventListener('change', e => { RM.src = e.target.value; RM.page = 1; loadRooms(); });
  $('#rmSize').addEventListener('change', e => { RM.size = +e.target.value || 50; RM.page = 1; loadRooms(); });

  $('#rmBody').addEventListener('click', rmOnBody);
  $('#rmPend').addEventListener('click', rmOnPend);

  await loadRooms();
}

/* ───────── 票:票据与账号 ───────── */
async function renderTicket() {
  let d = null;
  try { d = await api('/auth/status'); } catch (e) {
    if (e && e.status === 401) return;          // 已由 api() 弹回登录
    // 1.0.1 兜底 {} 继续渲染,页面出现 "undefined / undefined";现在诚实报错
    $('#main').innerHTML = '<div class="view-title">票据与账号</div>'
      + '<div class="err-line">票据状态读取失败:' + esc(errText(e, '网络错误'))
      + ' —— 请刷新重试;若持续,检查 web 服务日志。</div>';
    return;
  }
  const srcName = {runtime: '运行时应急覆盖', cookie: 'Cookie 自动续期', env: '环境变量',
                   'yaml/default': 'config.yaml / 默认'}[d.source] || d.source || '—';
  const ck = d.cookie || {};
  let h = '<div class="view-title">票据与账号</div>'
    + '<div class="view-sub">抓取凭证健康一屏可见;扫码登录与多账号管理在观测台(/)账号面板,'
    + 'login 服务负责自动续期</div>'
    + '<div class="ov-two"><div class="card"><b>当前抓取票据</b><div style="margin:10px 0">'
    + '<span class="src-badge ' + esc(d.source || '') + '">' + esc(srcName) + '</span></div>'
    // 1.4.3(C3):占位/空票据显式亮牌 —— 掩码后的占位串带指纹,静态看与真票
    // 无异,小白无从分辨「已配置」与「还没换」。仅当后端显式 configured===false
    // 才出黄条(老后端无此字段时不误报)。
    + (d.configured === false
        ? '<div class="warn-line" style="margin:0 0 10px">⚠ 当前为占位票据,尚未配置真实 '
          + 'x-auth-ticket —— 抓取不可用。可在下方「应急手动覆盖」粘贴新鲜票据,'
          + '或配好账号库由 login 服务自动续期。</div>'
        : '')
    + '<div class="kv"><span>UID</span><b>' + esc(d.uid || '—') + '</b></div>'
    + '<div class="kv"><span>票据(掩码)</span><b class="tk-fp">' + esc(d.ticket_masked || '—')
    + '</b></div>'
    + '<div class="kv"><span>指纹</span><b class="mono" style="font-size:12px">'
    + esc(d.ticket_fp || '—') + '</b></div>'
    + '<div class="kv"><span>app_id / type</span><b>' + esc(d.app_id) + ' / '
    + esc(d.token_type) + '</b></div>'
    + '<div style="margin-top:12px"><button class="btn primary" id="tkVerify">验证票据'
    + '(打一次 MainPage)</button> <span id="tkVr" class="mut"></span></div></div>';
  h += '<div class="card"><b>自动续期链路</b>';
  if (!ck.path) h += '<div class="empty">未配置 STA_AUTH_COOKIE_FILE —— 票据仅来自 ENV/YAML;'
    + '建议按 compose 部署启用 login 服务自动续期。</div>';
  else {
    h += '<div class="kv"><span>Cookie 文件</span><b class="mono" style="font-size:12px">'
      + esc(ck.path) + '</b></div>'
      + '<div class="kv"><span>状态</span><b>' + (ck.exists ? '存在 · 更新于 ' + ago(ck.mtime_ms)
        : '不存在(login 尚未写入?)') + '</b></div>';
    const rs = ck.refresh_state;
    if (rs) {
      // 结构化呈现(替代原生 JSON 截断):结果徽章 / 时间 / 命中账号 / 失败明细
      const okr = rs.last_result === 'ok';
      h += '<div class="kv"><span>上次刷新</span><b>'
        + '<span class="tag ' + (okr ? 'b-hot' : 'b-restart') + '">'
        + (okr ? '🟢 成功' : rs.last_result === 'fail' ? '🔴 失败' : esc(rs.last_result || '—'))
        + '</span> ' + (okr ? ago((rs.refreshed_at || 0) * 1000)
                            : rs.last_fail_at ? ago(rs.last_fail_at * 1000) : '—')
        + '</b></div>';
      if (okr && rs.active_username)
        h += '<div class="kv"><span>命中账号</span><b>' + esc(rs.active_username)
          + (rs.kugoo_id ? ' <span class="mut mono" style="font-size:11.5px">KugooID '
             + esc(rs.kugoo_id) + '</span>' : '') + '</b></div>';
      if (!okr && Array.isArray(rs.last_errors) && rs.last_errors.length) {
        h += '<div class="kv" style="align-items:flex-start"><span>失败明细</span>'
          + '<b style="font-weight:400;max-width:62%">'
          + rs.last_errors.slice(0, 4).map(e2 => '<div class="mono" style="font-size:11.5px;'
              + 'word-break:break-all">' + esc(Array.isArray(e2) ? e2[0] + ':' + e2[1] : e2)
              + '</div>').join('')
          + (rs.last_errors.length > 4 ? '<div class="mut">… 共 '
             + rs.last_errors.length + ' 条</div>' : '') + '</b></div>';
      }
    }
    h += '<div style="margin-top:12px"><button class="btn primary" id="rfNow">立即触发续期'
      + '</button>' + (ck.trigger_pending ? ' <span class="tag b-hook">已有触发待处理</span>' : '')
      + ' <span id="rfMsg" class="mut" style="font-size:12.5px"></span></div>';
  }
  h += '</div></div>'
    + '<div class="card" style="margin-top:14px" id="kgCard"><b>酷狗账号库</b> '
    + '<span class="mut">kgdata/accounts.json —— 自动续期的燃料;'
    + '保存即写盘,login 下轮刷新自动读取</span>'
    + '<div id="kgBody" style="margin-top:10px"><span class="mut">加载中…</span></div></div>'
    + '<div class="card" style="margin-top:14px"><b>应急手动覆盖</b> '
    + '<span class="mut">仅救急:login 服务下轮刷新出新 Cookie 时将按既有链路盖回本值</span>'
    + '<div class="pctl" style="margin-top:10px"><input id="ovUid" placeholder="UID(可留空)">'
    + '<input id="ovTk" type="password" placeholder="新鲜 x-auth-ticket" style="flex:2">'
    + '<button class="btn danger" id="ovGo">下发覆盖</button></div>'
    + '<div class="mut" id="ovMsg" style="font-size:12.5px"></div></div>';
  $('#main').innerHTML = h;
  const rf = $('#rfNow');
  if (rf) rf.onclick = async () => {
    if (!await ask({title: '立即触发续期',
                    body: 'login 将按账号库逐个尝试重登,成功即热更抓取票据。',
                    yes: '触发'})) return;
    rf.disabled = true; $('#rfMsg').textContent = '下发触发…';
    try {
      const r = await api('/auth/refresh_now', {method: 'POST', body: '{}'});
      const m = $('#rfMsg'); m.textContent = r.hint || '已触发'; m.style.color = '';
      setTimeout(() => { if (S.view === 'ticket') renderTicket(); }, 4000);
    } catch (e) {
      const m = $('#rfMsg');                                   // 1.4.3(C2 同族)
      m.textContent = errText(e, '触发失败'); m.style.color = 'var(--seal-deep)';
      rf.disabled = false;
    }
  };
  $('#tkVerify').onclick = async () => {
    $('#tkVr').textContent = '探活中…';
    try { const r = await api('/auth/verify', {method: 'POST', body: '{}'});
      $('#tkVr').textContent = r.ok ? '✓ 票据有效(房 ' + (r.room || '') + ')'
        : '✕ ' + (r.hint || r.result);
      $('#tkVr').style.color = r.ok ? 'var(--brand-deep)' : 'var(--seal-deep)';
    } catch (_) { $('#tkVr').textContent = '探活请求失败'; }
  };
  $('#ovGo').onclick = async () => {
    const tk = $('#ovTk').value.trim();
    if (!tk) { const m = $('#ovMsg');                          // 1.4.3(C2 同族)
      m.textContent = '请先粘贴票据'; m.style.color = 'var(--seal-deep)'; return; }
    if (!await ask({title: '下发票据应急覆盖',
                    body: '将即时热更全部 worker 抓取会话;login 下轮刷新出的'
                        + '新 Cookie 会按既有链路盖回本值。',
                    danger: true, yes: '下发覆盖'})) return;
    try {
      const r = await api('/auth/override', {method: 'POST',
        body: JSON.stringify({ticket: tk, uid: $('#ovUid').value.trim()})});
      const m = $('#ovMsg'); m.style.color = '';
      m.textContent = '已下发(rev ' + r.rev + ')· ' + (r.hint || '');
      $('#ovTk').value = ''; refreshRevPill(); renderTicket();
    } catch (e) {
      const m = $('#ovMsg');                                   // 1.4.3(C2 同族)
      m.textContent = errText(e, '下发失败'); m.style.color = 'var(--seal-deep)';
    }
  };
  renderKgAccounts();
}

/* ── 酷狗账号库编辑器(票视图内嵌) ──
   密码策略与参数中心敏感项一致:服务端永不回传明文;输入框留空 = 沿用旧密,
   填写 = 覆盖(支持 env:变量名)。删除/新增/改密经确认摘要后一次 PUT 原子落盘。 */
async function renderKgAccounts() {
  const box = $('#kgBody');
  if (!box) return;
  let d;
  try { d = await api('/auth/accounts'); }
  catch (e) {
    box.innerHTML = '<div class="err-line">账号库读取失败:'
      + esc(errText(e, e && e.status ? 'HTTP ' + e.status : '网络错误')) + '</div>';
    return;
  }
  if (!d.path) { box.innerHTML = '<div class="empty">' + esc(d.hint || '未配置账号库路径') + '</div>'; return; }
  if (d.ok === false) { box.innerHTML = '<div class="err-line">' + esc(d.hint || '账号库解析失败') + '</div>'; return; }
  const ro = !d.writable;
  const rowHtml = a => '<tr class="kg-row">'
    + '<td><input type="checkbox" class="kg-en"' + (a.enabled ? ' checked' : '')
    + (ro ? ' disabled' : '') + ' aria-label="启用"></td>'
    + '<td><input class="kg-user" value="' + esc(a.username) + '"'
    + (ro ? ' disabled' : '') + ' placeholder="酷狗号/手机号/邮箱"></td>'
    + '<td><input class="kg-pwd" type="password" autocomplete="new-password"'
    + (ro ? ' disabled' : '') + ' placeholder="'
    + (a.password_env ? '当前 env:' + esc(a.password_env) + '(留空不改)'
       : a.password_set ? '已设(留空不改)' : '必填:密码或 env:变量名') + '"></td>'
    + '<td><input class="kg-mid mono" value="' + esc(a.mid) + '"'
    + (ro ? ' disabled' : '') + ' placeholder="kg_mid(32位hex)" style="font-size:12px"></td>'
    + '<td><input class="kg-note" value="' + esc(a.note) + '"'
    + (ro ? ' disabled' : '') + ' placeholder="备注"></td>'
    + '<td>' + (ro ? '' : '<button class="btn ghost kg-del" title="删除本行">✕</button>') + '</td></tr>';
  let h = '';
  if (ro) h += '<div class="err-line" style="margin-bottom:8px">只读:'
    + esc(d.hint || '账号库不可写') + '</div>';
  h += '<table class="tbl kg-tbl"><tr><th style="width:44px">启用</th><th>用户名</th>'
    + '<th>密码</th><th>mid</th><th>备注</th><th style="width:40px"></th></tr>'
    + (d.accounts || []).map(rowHtml).join('')
    + '</table>';
  if (!(d.accounts || []).length)
    h += '<div class="empty" style="margin-top:6px">账号库为空 —— 添加至少 1 个账号后,'
      + 'login 服务才能自动续期票据。</div>';
  if (!ro)
    h += '<div style="margin-top:10px;display:flex;gap:10px;align-items:center">'
      + '<button class="btn" id="kgAdd">+ 添加账号</button>'
      + '<button class="btn primary" id="kgSave">保存账号库</button>'
      + '<span class="mut" id="kgMsg" style="font-size:12.5px"></span></div>'
      + '<div class="mut" style="font-size:12px;margin-top:6px">密码可填明文或 '
      + '<span class="mono">env:变量名</span>(从 login 容器环境读取,避免明文落盘);'
      + '文件更新于 ' + (d.mtime_ms ? ago(d.mtime_ms) : '—')
      + ' · 多账号互为备份,刷新时逐个尝试。</div>';
  box.innerHTML = h;
  if (ro) return;
  const blankRow = () => rowHtml({username: '', mid: '', note: '', enabled: true,
                                  password_set: false, password_env: ''});
  $('#kgAdd').onclick = () => {
    // 追加到最后一行之后(而非 table 的 beforeend):后者会让浏览器新建第二个
    // 隐式 tbody 包住新 <tr>,新行与既有行不同父,:nth-child 定位与后续遍历全乱。
    $('.kg-tbl tr:last-child', box).insertAdjacentHTML('afterend', blankRow());
    const rows = $$('.kg-row', box); $('.kg-user', rows[rows.length - 1]).focus();
  };
  box.onclick = e => {                            // 覆盖式:重渲染不叠加监听
    const del = e.target.closest('.kg-del');
    if (del) del.closest('tr').remove();
  };
  $('#kgSave').onclick = async () => {
    const rows = $$('.kg-row', box);
    const accounts = rows.map(r => ({
      username: $('.kg-user', r).value.trim(),
      password: $('.kg-pwd', r).value,          // 留空 = 沿用旧密(服务端合并)
      mid: $('.kg-mid', r).value.trim(),
      note: $('.kg-note', r).value.trim(),
      enabled: $('.kg-en', r).checked,
    }));
    const olds = new Set((d.accounts || []).map(a => a.username));
    const news = new Set(accounts.map(a => a.username).filter(Boolean));
    const added = [...news].filter(u => !olds.has(u));
    const removed = [...olds].filter(u => !news.has(u));
    const pwdN = accounts.filter(a => a.password).length;
    if (!await ask({title: '保存账号库',
        body: '共 ' + accounts.length + ' 个账号'
          + (added.length ? '\n新增:' + added.join('、') : '')
          + (removed.length ? '\n删除:' + removed.join('、') + '(其密码将随保存丢弃)' : '')
          + (pwdN ? '\n' + pwdN + ' 处密码将被更新' : ''),
        danger: removed.length > 0, yes: '保存并写盘'})) return;
    $('#kgSave').disabled = true; $('#kgMsg').textContent = '写入中…';
    try {
      const r = await api('/auth/accounts', {method: 'PUT',
                                             body: JSON.stringify({accounts})});
      toast('账号库已保存(共 ' + r.total + ' 个)');
      const m = $('#kgMsg'); m.style.color = '';
      m.textContent = ((r.warnings || []).length
        ? '⚠ ' + r.warnings.join(';') + ' · ' : '') + (r.hint || '');
      d = null; renderKgAccounts();               // 重拉:密码框归空、占位符更新
    } catch (e) {
      const m = $('#kgMsg');                                   // 1.4.3(C2 同族)
      m.textContent = errText(e, '保存失败'); m.style.color = 'var(--seal-deep)';
    } finally { $('#kgSave').disabled = false; }
  };
}

/* ───────── 审:审计日志 ───────── */
async function renderAudit() {
  // 1.4.3(B1):补齐 1.3.1「疑」租约与 4.0.x「注」两轮功能落下的 8 种动作
  // (lease_force_release + 7 个 reg_*)—— 此前表里看得到、下拉里筛不到;
  // 并给全部动作码配人话:下拉纯人话,表格「人话 + 小字原码」便于与接口对账。
  const AUDIT_ACT = {
    apply: '应用变更', rollback: '回滚', clear_override: '清除运行时覆盖',
    auth_override: '票据应急覆盖', auth_verify: '票据验证',
    auth_refresh_now: '触发票据续期', kg_accounts_edit: '编辑酷狗账号库',
    room_alias: '设置房间别名', pending_abandon: '放弃挂起房',
    login: '登录', login_fail: '登录失败', logout: '登出',
    login_captcha_fail: '登录人机验证未过', login_ticket: '应急链接登录',
    login_ticket_fail: '应急链接登录失败',   // 1.10.0:应急链接由服务器签发,一次性
    login_unlock: '解锁用户登录',   // 5.2.0「登」登录风控:清一个账号 / IP 段的失败计数
    lease_force_release: '强制释放活跃房租约', reg_mode: '切换注册模式',
    reg_breaker_clear: '恢复注册(清熔断)', reg_throttle_clear: '清空注册限流',
    reg_invites_generate: '生成邀请码', reg_invite_disable: '禁用邀请码',
    reg_block: '观测台封禁', reg_unblock: '观测台解封',
    /* 4.2.8 补齐:这六个动作后端一直在写,而字典里一个都没有 —— 后果有两层。
       ① 表格渲染走 `AUDIT_ACT[a.action] || a.action`,发卡记录显示成生硬的
          英文码 jfvip_cards_gen;
       ② 更严重:筛选下拉是 `ACTIONS = ['', ...Object.keys(AUDIT_ACT)]`,
          **发卡与作废这两个直接对应真金白银的动作,在审计页根本无法筛选**,
          要查「谁发过卡」只能翻全量 200 条。
       同类漏项由 test_audit_dict_covers_all_backend_actions 永久守门。 */
    jfvip_cards_gen: '发卡', jfvip_cards_disable: '作废/恢复卡密',
    jfvip_cards_purge: '删除卡密', jfvip_cards_note: '改卡密备注',
    jfvip_grant: '手动开通VIP', jfvip_revoke: '撤销VIP',
    /* 4.2.9:外部 API 发卡。actor 形如 cardapi@<调用方IP>,与管理台的
       admin@<IP> 一眼可分 —— 「这批卡是人在后台点的还是发卡平台调的」
       是事后追查的第一个问题。 */
    jfvip_cards_issue: '外部API发卡',
    /* 1.7.0:敏感值揭示。这是「谁在什么时候看过这把能凭空造 VIP 时长的密钥」
       的唯一记录 —— 不进筛选下拉的话,要查它只能翻全量。 */
    config_reveal: '查看敏感值明文',
    /* 1.11.0:「储」视图的「立即清扫」。清扫只删已过期的数据,但它毕竟是一次
       人为触发的删除 —— 谁在什么时候按的,要查得到。 */
    storage_sweep: '立即清扫(存储与保留)',
  };
  const ACTIONS = ['', ...Object.keys(AUDIT_ACT)];
  let cur = '';
  const draw = async () => {
    let d;
    try { d = await api('/audit?limit=200' + (cur ? '&action=' + cur : '')); }
    catch (e) {
      if (e && e.status === 401) return;          // 已由 api() 弹回登录
      // 1.4.3(A3):同 renderRevisions —— 读取失败诚实报错,
      // 不再伪装「暂无审计记录」。
      $('#main').innerHTML = '<div class="view-title">审计日志</div>'
        + '<div class="err-line">审计读取失败:'
        + esc(errText(e, (e && e.status) ? 'HTTP ' + e.status : '网络错误'))
        + ' —— 请刷新重试;若持续,检查 web 服务日志。</div>';
      return;
    }
    let h = '<div class="view-title">审计日志</div>'
      + '<div class="view-sub">谁在何时改了什么 —— 配置版本与全部管理动作;敏感值只留指纹 '
      + '<select id="auF" class="sel" aria-label="按动作筛选">'
      + ACTIONS.map(a => '<option value="' + a + '"'
        + (a === cur ? ' selected' : '') + '>' + (a ? (AUDIT_ACT[a] || a) : '全部动作')
        + '</option>').join('')
      + '</select></div>';
    if (!d.items.length) h += '<div class="empty">暂无审计记录。</div>';
    else {
      h += '<table class="tbl"><tr><th>时间</th><th>操作者</th><th>动作</th><th>rev</th>'
        + '<th>详情</th></tr>';
      for (const a of d.items)
        h += '<tr><td>' + fmtTs(a.ts_ms) + '</td><td class="mono">' + esc(a.actor)
          + '</td><td>' + esc(AUDIT_ACT[a.action] || a.action)
          + (AUDIT_ACT[a.action] ? ' <span class="mut mono" style="font-size:11px">'
             + esc(a.action) + '</span>' : '')
          + '</td><td class="mono">' + (a.rev ?? '—')
          + '</td><td><details><summary class="mut">展开</summary><div class="mono" '
          + 'style="font-size:11.5px;max-width:480px;word-break:break-all">'
          + esc(JSON.stringify(a.detail)) + '</div></details></td></tr>';
      h += '</table>';
    }
    $('#main').innerHTML = h;
    $('#auF').onchange = e => { cur = e.target.value; draw(); };
  };
  draw();
}

/* ───────── 疑:疑似脚本来源(L4 行为遥测,1.3.0) ─────────
   纯呈现层:分数与依据来自管理接口 GET /signals(服务端按会话画像折算)。
   铁律与后端一致 —— 疑度**永不**触发自动动作;拦截只由 L1 租约违规 / L2 证明
   缺失等确定性事件完成。此视图存在的意义是「让人看一眼」,不是替人下判决。 */
function sigAgo(ms) {
  if (!ms) return '—';
  const s = Math.max(0, Math.round((Date.now() - ms) / 1000));
  if (s < 60) return s + ' 秒前';
  if (s < 3600) return Math.floor(s / 60) + ' 分前';
  return Math.floor(s / 3600) + ' 时前';
}
function sigStamp(score) {
  const n = Math.max(0, Math.min(100, +score || 0));
  return '<span class="sig-stamp' + (n < 40 ? ' low' : '') + '" style="--p:'
       + (n / 100).toFixed(2) + '" title="疑度 ' + n + '/100">' + n + '</span>';
}
/* 3.9.4:活跃房租约(单账号单活跃房)运维可见性 —— 此前该状态对管理台完全不可见,
   只能靠前端行为反推。只读清单 + 「强制释放」兜底(语义与 TTL 过期自愈同源:释放后
   各窗口下一拍 renew 重新授予自己在看的房,先到者持租、其余跟随)。 */
function leaseBlock(ld) {
  let h = '<div class="view-title" style="margin-top:26px">活跃房租约</div>'
    + '<div class="view-sub">每账号同一时间只实时监控 1 个直播间(last-wins,以最后一次'
    + '切换为准)。此表为<b>只读观测</b>;「释放」仅供极端卡死解卡 —— 常态下关页信标 / '
    + 'SSE 断流 / 40s TTL 三路自愈已自洽,<b>不需要也不应该日常点它</b>。</div>';
  if (!ld) return h + '<div class="empty">加载失败 —— 10 秒后自动重试。</div>';
  if (ld.enabled === false)
    return h + '<div class="empty">登录系统未启用 —— 租约本就不生效,此处无可展示。</div>';
  if (!(ld.leases || []).length)
    return h + '<div class="empty">当前没有任何账号持有活跃房租约(没人在实时观看)。</div>';
  h += '<table class="tbl sig-tbl"><tr><th>账号</th><th>活跃房</th>'
    + '<th style="width:70px">活页数</th><th style="width:90px">最近活动</th>'
    + '<th style="width:76px">操作</th></tr>';
  for (const r of ld.leases) {
    const who = '<b>' + esc(r.uname || ('#' + r.uid)) + '</b>'
      + (r.uname ? ' <span class="mut">#' + esc(String(r.uid)) + '</span>' : '');
    const room = '<span class="mono">' + esc(String(r.room || '—')) + '</span>'
      + (r.alias ? ' <span class="mut">(输入号 ' + esc(String(r.alias)) + ')</span>' : '');
    const stale = r.stale ? ' <span class="mut">· 已过期待剪</span>' : '';
    h += '<tr><td>' + who + '</td><td>' + room + '</td>'
      + '<td><b>' + (r.tabs | 0) + '</b></td>'
      + '<td class="mut" style="white-space:nowrap">' + sigAgo(r.ts) + stale + '</td>'
      + '<td><button class="btn ghost lease-free" data-uid="' + esc(String(r.uid))
      + '" data-who="' + esc(r.uname || ('#' + r.uid)) + '">释放</button></td></tr>';
  }
  return h + '</table>';
}
async function renderSignals() {
  let thr = 50;                                   // 默认只看值得一看的
  const draw = async () => {
    let d = null, ld = null;
    try { d = await api('/signals?limit=200&min_score=' + thr); }
    catch (e) { if (e && e.status === 401) return; d = null; }
    try { ld = await api('/leases'); }
    catch (e) { if (e && e.status === 401) return; ld = null; }
    let h = '<div class="view-title">疑似脚本来源</div>'
      + '<div class="view-sub">按会话行为画像折算的「疑度」,<b>仅供人工研判</b> —— '
      + '拦截只由确定性事件(单账号多房租约违规、执行证明缺失)完成,疑度再高也'
      + '<b>不会自动封禁</b>。1.4.4 起改为<b>速率制</b>并引入「无罪证据」:执行证明'
      + '通过过(证明✓>0)或本会话留有浏览器足迹时,「从不加载页面」「不取静态资源」'
      + '两个软因子整条抑制 —— 此前手机锁屏超窗后画像重建,会把真人稳稳打成 65 分。'
      + '看分之前请先看右侧的<b>研判辅助</b>与观察跨度 '
      + '<select id="sgThr" class="sel" aria-label="疑度阈值">'
      + [0, 30, 50, 70].map(v => '<option value="' + v + '"' + (v === thr ? ' selected' : '')
          + '>' + (v ? '疑度 ≥ ' + v : '全部来源') + '</option>').join('')
      + '</select></div>';
    if (!d) h += '<div class="empty">加载失败 —— 10 秒后自动重试。</div>';
    else if (d.enabled === false)
      h += '<div class="empty">行为遥测未开启。置 <span class="mono">STA_USER_SIGNAL_SCORING=1</span>'
        + ' 且启用登录系统后,此处按行为画像呈现疑似采集流量。</div>';
    else if (!(d.sources || []).length)
      h += '<div class="empty">观察窗口(' + Math.round((d.window_s || 1800) / 60)
        + ' 分钟)内没有达到阈值的可疑来源 —— <b>这通常是好事</b>:流量看起来都像真浏览器。</div>';
    else {
      h += '<table class="tbl sig-tbl"><tr><th style="width:56px">疑度</th><th>来源 / 账号</th>'
        + '<th>研判依据 / 辅助</th><th>行为计数</th><th style="width:70px">最近</th></tr>';
      for (const r of d.sources) {
        const who = (r.uid != null && String(r.uid) !== '')
          ? '<b>' + esc(r.uname || ('#' + r.uid)) + '</b>'
            + (r.uname ? ' <span class="mut">#' + esc(String(r.uid)) + '</span>' : '')
          : '<span class="mut">未解析账号</span>';
        const meta = [(r.ip ? 'IP ' + esc(r.ip) : ''),
                      '会话 <span class="mono">' + esc(String(r.sid).slice(0, 12)) + '…</span>']
          .filter(Boolean).join(' · ');
        const rz = ((r.reasons && r.reasons.length)
          ? r.reasons.map((x, i) => '<span class="sig-rz'
              + (i === 0 && r.score >= 60 ? ' hot' : '') + '">' + esc(x) + '</span>').join('')
          : '<span class="mut">无明显特征</span>')
          /* 1.4.4:把此前被评分函数丢弃的「无罪信号」摆到研判者眼前 ——
             执行证明通过次数 / 浏览器足迹 / 因服务端挑战轮转而未命中的次数 /
             SSE 长连 / 明细成功率 / 观察跨度。只呈现,不参与计分。 */
          + ((r.notes && r.notes.length)
              ? '<div class="sig-meta" style="margin-top:6px">辅助:'
                + r.notes.map(x => esc(x)).join(' · ') + '</div>' : '');
        const pf = (r.pow_fail | 0) > 0
          ? '<b class="sig-warn">' + (r.pow_fail | 0) + '</b>'
            + ((+r.fail_rate) ? ' <span class="mut">(' + r.fail_rate + '/分)</span>' : '')
          : '<b>0</b>';
        h += '<tr><td>' + sigStamp(r.score) + '</td>'
          + '<td>' + who + '<div class="sig-meta">' + meta + '</div>'
          + (r.ua ? '<div class="sig-meta">' + esc(String(r.ua).slice(0, 100)) + '</div>' : '')
          + '</td>'
          + '<td><div class="sig-rzs">' + rz + '</div></td>'
          + '<td><div class="sig-counts">'
          + '<span>页面 <b>' + (r.html | 0) + '</b></span><span>静态 <b>' + (r.asset | 0) + '</b></span>'
          + '<span>明细 <b>' + (r.detail | 0) + '</b></span><span>成功 <b>' + (r.detail_ok | 0) + '</b></span>'
          + '<span>证明✓ <b>' + (r.pow_ok | 0) + '</b></span><span>证明✗ ' + pf + '</span>'
          /* 1.4.4:挑战过期/轮转导致的未命中单列 —— 那是**服务端**的过期,不是
             客户端算不出应答,恒不计疑度;混在「证明✗」里会误导研判。 */
          + '<span>过期 <b>' + (r.pow_stale | 0) + '</b></span>'
          + '<span>SSE <b>' + (r.sse | 0) + '</b></span><span>房间 <b>' + (r.rooms | 0) + '</b></span>'
          + (r.foot ? '<span class="mut">浏览器足迹 ✓</span>' : '')
          + ((+r.span_min > 1) ? '<span class="mut">跨度 ' + r.span_min + ' 分</span>' : '')
          + '</div></td>'
          + '<td class="mut" style="white-space:nowrap">' + sigAgo(r.last) + '</td></tr>';
      }
      h += '</table>';
    }
    h += leaseBlock(ld);                          // 3.9.4:同视图追加「活跃房租约」观测块
    $('#main').innerHTML = h;
    const sel = $('#sgThr');
    if (sel) sel.onchange = e => { thr = +e.target.value; draw(); };
    for (const b of $$('.lease-free')) b.onclick = async () => {
      const ok = await ask({
        title: '强制释放活跃房租约',
        body: '账号 ' + b.dataset.who + ' 的租约将被整把删除。其各窗口会在下一拍'
          + '心跳时重新授予"自己正在看的房"(先到者持租、其余跟随)—— 与 TTL 过期'
          + '自愈同一语义,不断流、不踢人。仅用于极端卡死解卡,确认继续?',
        yes: '释放', danger: true});
      if (!ok) return;
      try { await api('/leases/' + encodeURIComponent(b.dataset.uid) + '/release',
                      {method: 'POST'}); }
      // 1.4.3(C2 同族扫尾):「极端解卡」按钮失败静默会引导反复点 —— 亮出原因。
      catch (e) { toast(errText(e, '释放失败'), 'err'); }
      draw();
    };
  };
  await draw();
  S.timers.push(setInterval(draw, 10000));        // 视图切走由 clearTimers 统一收摊
}

/* ───────── 注:注册与邀请(4.0.0;4.0.5 结构化刷新)─────────
   4.0.5 复查落地(逐条对着 REGISTER-SYSTEM.md §5-R7 规范与实测核过):
   · 视图拆「静态骨架 + 动态区」:#regTop(横幅/总控卡)与各数据区独立刷新,
     筛选条/封禁表单常驻 —— 15s 心跳不再清空正在输入的内容、不丢焦点;
   · 失败态心跳整页重试 —— 「15 秒后自动重试」从此是真话(此前文案抄自
     「疑」视图,机制没抄,承诺无人兑现);ok:false 不再被静默渲染成一排 0;
   · 邀请码:服务端分页贯通(此前写死 page=1,>50 枚静默不可见)+ §5-R7②
     规定却缺席的「导出 txt」(仅有效码,分发即用);
   · 流水:§5-R7③ 规定却缺席的「同源近时批量」聚类高亮(本页内同 IP/指纹
     ×3 起淡金提示,仅提示不判决);指纹/UA 悬停可看全量;回车即筛;
   · 模式 seg 高亮/守卫改按 modeConfigured —— seg 设置的本就是配置档,
     熔断压制下点「当前配置档」此前会空转出高危确认 + 无效 rev。 */
/* ───────── 5.2.0「登」登录风控:全局态势 · 当前被锁 · 可疑来源 · 被针对账号 · 登录流水 ─────────
   运维诉求:注册侧早有流水与熔断可看,登录侧的可疑活动此前只躺在库表里。本视图与「注」同一套
   分区容错 —— 各区独立渲染,一个区炸只炸自己并把错写进那个区,绝不留永恒的「加载中…」。
   只读为主;唯一的写是「解锁」(清一个账号 / IP 段的失败计数,二次确认 + 管理台审计)。 */
const LG_REASON = {
  ok: '成功', ok_free: '成功(免费档)', bad_credentials: '口令错 / 查无此人', throttled: '频繁被拒',
  banned: '已停用(口令正确)', expired: '已到期(口令正确)',
  'challenge:risk': '要求加码(可疑)', 'challenge:always': '要求人机验证', 'challenge:expired': '加码挑战过期',
  'challenge:pow_failed': '加码未通过', 'challenge:captcha_failed': '人机验证未通过',
  'challenge:captcha_degraded': '验证码降级为 PoW', attack_mode: '进入全局攻击态',
  sso: 'SSO 登录', sso_free: 'SSO 登录(免费档)', sso_bad: 'SSO 票据无效', sso_throttled: 'SSO 频繁被拒',
  sso_link: '账密签发', sso_link_bad: '账密签发失败', sso_link_rate: '账密签发限频',
};
let UL_EPOCH = 0;
const ulLeft = s => { s = s | 0; if (s <= 0) return '—'; const m = Math.floor(s / 60);
                      return m ? m + ' 分 ' + (s % 60) + ' 秒' : s + ' 秒'; };
const ulTime = t => esc(String(t || '').replace('T', ' ').slice(0, 19)) || '—';
async function renderUserLogin() {
  const epoch = ++UL_EPOCH;
  const stale = () => S.view !== 'userlogin' || epoch !== UL_EPOCH;
  const F = {page: 1, ip: '', name: '', res: 'suspect'};
  const ZONES = ['#ulTop', '#ulLocked', '#ulIps', '#ulUsers'];
  const errLine = (name, e) => '<span class="err-line">' + esc(name) + '渲染失败:'
    + esc(String((e && e.message) || e)) + ' —— 60 秒后自动重试;若持续,请把浏览器控制台的报错发给维护者。</span>';
  const pcard = (title, sub, id) => '<div class="pcard" style="margin-bottom:14px"><div class="phead">'
    + '<span class="plabel">' + title + '</span><span class="mut" style="font-size:12px">' + sub + '</span></div>'
    + '<div id="' + id + '" style="margin-top:10px"><span class="mut">加载中…</span></div></div>';
  $('#main').innerHTML = '<div class="view-title">登录风控</div>'
    + '<div class="view-sub">登录侧的可疑活动一屏看全:全局攻击态 · 当前被锁的账号与 IP 段 · 近 24 小时可疑来源与被针对的账号 · 登录流水。'
    + '注册侧的可疑流水见左栏「注」·<a href="#/reg" style="color:var(--brand)">注册与邀请</a>;机制与阈值见 LOGIN-SYSTEM.md §4.5。</div>'
    + '<div id="ulTop"><span class="mut">加载中…</span></div>'
    + pcard('当前被锁', '计数键实时读数;解锁 = 清掉该账号 / IP 段的失败计数(写入审计)', 'ulLocked')
    + pcard('可疑来源 · 近 24 小时', '按 IP 段合并(IPv6 按 /64);只算失败、被拒、要求加码类记录', 'ulIps')
    + pcard('被针对的账号 · 近 24 小时', '失败次数多、来源 IP 多的账号最值得关注', 'ulUsers')
    + '<div class="pcard"><div class="phead"><span class="plabel">登录流水 · 近 7 天</span>'
    + '<button class="btn ghost" id="ulRefresh">↻ 刷新</button></div><div style="margin-top:10px">'
    + '<div id="ulBar" style="display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap">'
    + '<input id="ulIp" placeholder="按 IP 精确筛" aria-label="按 IP 精确筛选" style="width:150px">'
    + '<input id="ulName" placeholder="按用户名精确筛" aria-label="按用户名精确筛选" style="width:130px">'
    + '<select id="ulRes" class="sel" aria-label="按结果或原因筛选">'
    + '<option value="suspect">只看可疑</option><option value="">全部</option>'
    + '<option value="ok1">仅成功</option><option value="ok0">仅失败</option>'
    + '<option value="challenge">要求加码 / 人机验证</option><optgroup label="按具体原因">'
    + Object.keys(LG_REASON).map(k => '<option value="r:' + esc(k) + '">' + esc(LG_REASON[k]) + '</option>').join('')
    + '</optgroup></select><button class="btn" id="ulGo">筛选</button>'
    + '<button class="btn ghost" id="ulReset" title="回到「只看可疑」并回第 1 页">重置</button></div>'
    + '<div id="ulTbl"><span class="mut">加载中…</span></div></div></div>';

  const drawRisk = async () => {
    let d;
    try { d = await api('/userlogin/risk?hours=24&top=20'); }
    catch (e) { if (!stale()) ZONES.forEach(z => { const el = $(z); if (el) el.innerHTML = errLine('风控概览', e); }); return; }
    if (stale()) return;
    if (!d.enabled) {
      $('#ulTop').innerHTML = '<div class="empty">登录系统未启用 —— 本视图没有数据。</div>';
      ZONES.slice(1).forEach(z => { $(z).innerHTML = ''; });
      return;
    }
    const a = d.attack || {}, L = d.limits || {}, br = d.byReason || {};
    const sum = ks => ks.reduce((t, k) => t + (br[k] | 0), 0);
    const chal = Object.keys(br).filter(k => k.startsWith('challenge:')).reduce((t, k) => t + (br[k] | 0), 0);
    $('#ulTop').innerHTML = '<div class="kpis" style="margin:0 0 14px">'
      + '<div class="kpi"><b>' + (a.on ? '攻击态' : '正常') + '</b><span>全局态势'
      + (a.threshold ? '(近 5 分钟失败 ' + (a.fails5m | 0) + ' / 阈值 ' + (a.threshold | 0) + ')' : '(攻击态检测已关)') + '</span></div>'
      + '<div class="kpi"><b>' + sum(['bad_credentials']) + '</b><span>口令错 · 近 24 小时</span></div>'
      + '<div class="kpi"><b>' + sum(['throttled', 'sso_throttled']) + '</b><span>频繁被拒 · 近 24 小时</span></div>'
      + '<div class="kpi"><b>' + chal + '</b><span>要求加码 / 人机验证 · 近 24 小时</span></div>'
      + '<div class="kpi"><b>' + sum(['ok', 'ok_free', 'sso', 'sso_free']) + '</b><span>成功登录 · 近 24 小时</span></div></div>'
      + '<div class="pmeta" style="margin:-4px 0 14px">硬上限:同名 ' + (L.user | 0) + ' / 同 IP 段 ' + (L.ip | 0)
      + '(' + Math.round((L.windowS | 0) / 60) + ' 分钟窗,锁 ' + Math.round((L.lockS | 0) / 60) + ' 分钟)· 加码阈值:同名 '
      + (L.stepupUser || '关') + ' / 同 IP 段 ' + (L.stepupIp || '关') + ' · 登录人机验证:'
      + esc(L.captcha === 'off' ? '关' : L.captcha + '(' + (L.captchaMode === 'always' ? '每次登录' : '仅可疑时') + ')')
      + (d.dbError ? '<br><span class="err-line">用户库暂不可用:统计与账号锁缺失;被锁的 IP 段仍来自 Redis 实时计数</span>' : '')
      + '</div>';
    const lu = (d.locked && d.locked.users) || [], li = (d.locked && d.locked.ips) || [];
    $('#ulLocked').innerHTML = (!lu.length && !li.length) ? '<div class="empty">当前没有被锁的账号或 IP 段</div>'
      : '<table class="tbl"><tr><th>类型</th><th>对象</th><th>窗口内失败</th><th>剩余锁定</th><th></th></tr>'
        + lu.map(x => '<tr><td>账号</td><td>' + esc(x.name) + '</td><td>' + (x.fails | 0) + '</td><td>' + ulLeft(x.leftS)
          + '</td><td><button class="btn" data-unlock="user" data-v="' + esc(x.name) + '">解锁</button> '
          + '<button class="btn ghost" data-fname="' + esc(x.name) + '">看流水</button></td></tr>').join('')
        + li.map(x => '<tr><td>IP 段</td><td>' + esc(x.bucket) + '</td><td>' + (x.fails | 0) + '</td><td>' + ulLeft(x.leftS)
          + '</td><td><button class="btn" data-unlock="ip" data-v="' + esc(x.bucket) + '">解锁</button></td></tr>').join('')
        + '</table>';
    const ti = d.topIps || [];
    $('#ulIps').innerHTML = !ti.length ? (d.dbError ? '' : '<div class="empty">近 24 小时没有可疑来源</div>')
      : '<table class="tbl"><tr><th>IP 段</th><th>可疑次数</th><th>涉及账号</th><th>最近</th><th>状态</th><th></th></tr>'
        + ti.map(x => '<tr><td>' + esc(x.bucket) + '</td><td>' + (x.n | 0) + '</td><td>' + (x.approx ? '≈' : '') + (x.users | 0)
          + '</td><td>' + ulTime(x.last) + '</td><td>' + (x.locked ? '<span class="tag warn">锁定中 ' + ulLeft(x.leftS) + '</span>' : '—')
          + '</td><td><button class="btn ghost" data-fip="' + esc(x.sample) + '">看流水</button></td></tr>').join('') + '</table>';
    const tu = d.topUsers || [];
    $('#ulUsers').innerHTML = !tu.length ? (d.dbError ? '' : '<div class="empty">近 24 小时没有被针对的账号</div>')
      : '<table class="tbl"><tr><th>账号</th><th>失败次数</th><th>来源 IP 数</th><th>最近</th><th>状态</th><th></th></tr>'
        + tu.map(x => '<tr><td>' + esc(x.name) + '</td><td>' + (x.n | 0) + '</td><td>' + (x.ips | 0) + '</td><td>' + ulTime(x.last)
          + '</td><td>' + (x.locked ? '<span class="tag warn">锁定中 ' + ulLeft(x.leftS) + '</span>' : '—')
          + '</td><td><button class="btn ghost" data-fname="' + esc(x.name) + '">看流水</button></td></tr>').join('') + '</table>';
    ['#ulLocked', '#ulIps', '#ulUsers'].forEach(z => { $(z).onclick = onRowAct; });
  };

  const drawLog = async () => {
    const q = new URLSearchParams({page: String(F.page), size: '30', hours: '168'});
    if (F.ip) q.set('ip', F.ip);
    if (F.name) q.set('name', F.name);
    if (F.res === 'ok1') q.set('ok', '1');
    else if (F.res === 'ok0') q.set('ok', '0');
    else if (F.res === 'suspect' || F.res === 'challenge') q.set('reason', F.res);
    else if (F.res.startsWith('r:')) q.set('reason', F.res.slice(2));
    const d = await api('/userlogin/log?' + q.toString());
    if (stale()) return;
    if (!d.enabled) { $('#ulTbl').innerHTML = '<div class="empty">登录系统未启用</div>'; return; }
    const pages = Math.max(1, Math.ceil((d.total | 0) / (d.size || 30)));
    if (F.page > pages && (d.total | 0) > 0) { F.page = pages; return drawLog(); }   // 悬空页自愈
    let h = '<div class="mut" style="font-size:12px;margin-bottom:6px">共 ' + (d.total | 0) + ' 条 · 第 '
      + F.page + ' / ' + pages + ' 页</div>';
    const items = d.items || [];
    h += !items.length ? '<div class="empty">无匹配记录</div>'
      : '<table class="tbl"><tr><th>时间</th><th>账号</th><th>IP</th><th>结果</th><th>原因</th><th>UA</th></tr>'
        + items.map(r => '<tr><td>' + ulTime(r.created_at) + '</td><td>' + esc(r.user_name || '—') + '</td><td>'
          + esc(r.ip || '—') + '</td><td>' + (r.ok ? '<span class="tag ok">成功</span>' : '<span class="tag warn">失败</span>')
          + '</td><td>' + esc(LG_REASON[r.reason] || r.reason || '—') + '</td><td title="' + esc(r.ua) + '">'
          + esc(String(r.ua || '').slice(0, 40)) + '</td></tr>').join('') + '</table>';
    h += '<div style="margin-top:8px">' + (F.page > 1 ? '<button class="btn" id="ulPrev">上一页</button> ' : '')
      + (F.page < pages ? '<button class="btn" id="ulNext">下一页</button>' : '') + '</div>';
    $('#ulTbl').innerHTML = h;
    const pv = $('#ulPrev'), nx = $('#ulNext');
    if (pv) pv.onclick = () => { F.page--; logZone(); };
    if (nx) nx.onclick = () => { F.page++; logZone(); };
  };
  const logZone = async () => {
    try { await drawLog(); }
    catch (e) { console.error('[userlogin] 登录流水渲染失败', e); if (!stale()) $('#ulTbl').innerHTML = errLine('登录流水', e); }
  };
  const goLog = () => {
    F.ip = $('#ulIp').value.trim(); F.name = $('#ulName').value.trim(); F.res = $('#ulRes').value; F.page = 1;
    logZone();
  };
  const onRowAct = async ev => {
    const b = ev.target.closest('button');
    if (!b) return;
    if (b.dataset.fname !== undefined || b.dataset.fip !== undefined) {
      $('#ulIp').value = b.dataset.fip || ''; $('#ulName').value = b.dataset.fname || ''; $('#ulRes').value = '';
      goLog();
      $('#ulTbl').scrollIntoView && $('#ulTbl').scrollIntoView({block: 'start'});
      return;
    }
    if (!b.dataset.unlock) return;
    const kind = b.dataset.unlock, v = b.dataset.v || '';
    if (!await ask({title: kind === 'user' ? '解锁账号' : '解锁 IP 段',
                    body: '将清掉「' + esc(v) + '」的登录失败计数,立即可以再尝试登录(此操作写入审计)。确认?',
                    yes: '解锁', danger: true})) return;
    try {
      const r = await api('/userlogin/unlock', {method: 'POST', body: JSON.stringify({kind, value: v})});
      toast(r && r.existed ? '已解锁 ' + v : '该计数已不存在(可能刚好过期)');
      await drawRisk();
    } catch (e) { toast(errText(e, '解锁失败'), 'err'); }
  };
  $('#ulGo').onclick = goLog;
  $('#ulRes').onchange = goLog;
  $('#ulReset').onclick = () => { $('#ulIp').value = ''; $('#ulName').value = ''; $('#ulRes').value = 'suspect'; goLog(); };
  $('#ulIp').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.isComposing) goLog(); });
  $('#ulName').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.isComposing) goLog(); });
  $('#ulRefresh').onclick = () => { drawRisk(); logZone(); };
  await drawRisk();
  await logZone();
  S.timers.push(setInterval(() => { if (!stale()) drawRisk(); }, 60000));   // 概览每分钟自刷;流水只在操作时刷,不打断翻页
}

const REG_REASON = {
  ok: '成功', name_taken: '重名', name_invalid: '用户名不合规', name_reserved: '保留名',
  password_invalid: '密码不合规', pow_failed: 'PoW 未过', challenge_expired: '挑战过期',
  too_fast: '秒提交', honeypot: '蜜罐命中', throttled: '触发限流',
  invite_required: '缺邀请码', invite_invalid: '邀请码无效', invite_exhausted: '邀请码用尽',
  invite_expired: '邀请码过期', captcha_failed: '验证码未过', captcha_unavailable: '验证码不可用',
  cb_off: '熔断关闸', cb_invite: '熔断降档',
};
function regModePill(m){
  const map = {off: ['关闭', '#8a94a6'], invite: ['邀请码', '#0f6f5c'], open: ['开放', '#b4791a']};
  const [t, c] = map[m] || ['—', '#8a94a6'];
  return '<span class="rev-pill" style="background:' + c + '22;color:' + c + '">' + t + '</span>';
}
let REG_EPOCH = 0;   // 「注」视图代际:每次进入视图 +1,晚到的旧闭包异步结果据此作废
async function renderReg() {
  const epoch = ++REG_EPOCH;                         // 本届代际号(终审收口:旧闭包防污染)
  const IV = {page: 1};                              // 邀请码分页(4.0.5)
  const RL = {page: 1, ip: '', name: '', ok: '', reason: ''};   // 流水筛选(已提交的;4.0.7 增 reason)
  let lastOk = false, busy = false, queued = false;  // 心跳重试 / draw 防重入
  // 过期判定:视图已切走,或已被新一届 renderReg 接管(切走再切回)——
  // 两种情况下本闭包的任何晚到异步结果都不得再写 DOM。
  const stale = () => S.view !== 'reg' || epoch !== REG_EPOCH;

  /* ── 分区容错(1.7.3 事故后补)──────────────────────────────────────────
     背景(真机复现,非推断):流水区曾因一行 `const purgeOn = !!ov.purgeEnabled;`
     误粘贴进 drawRegLog(ov 不在其作用域)抛 ReferenceError,而该异常在
     `box.innerHTML = ...` **之前**抛出 —— 于是流水区停在骨架的「加载中…」,
     并且异常外溢出 draw()(它只有 try/finally),把排在后面的 drawBlocks()
     整个吃掉,封禁区也永远停在「加载中…」。两个区一起变砖,页面上却看不出
     任何错。心跳每 15s 重演一次,「15 秒后自动重试」的承诺形同虚设。

     教训:**骨架占位文案不是渲染结果**,不能靠「没人改它」来充当已完成态。
     各数据区的渲染必须彼此隔离 —— 一个区炸只该炸自己,且必须把错显式写进
     那个区,让运维一眼看见,而不是留一句永恒的「加载中…」。 */
  const zone = async (fn, sel, name) => {
    try { await fn(); }
    catch (e) {
      console.error('[reg] ' + name + ' 渲染失败', e);
      const el = $(sel);
      if (el && !stale()) el.innerHTML = '<span class="err-line">' + esc(name)
        + '渲染失败:' + esc(String((e && e.message) || e))
        + ' —— 15 秒后自动重试;若持续,请把浏览器控制台的报错发给维护者。</span>';
    }
  };

  const HEAD = '<div class="view-title">注册与邀请</div>'
    + '<div class="view-sub">前端自助注册的总控 · 邀请码 · 流水 · 观测台封禁。'
    + '恶意注册纵深见 REGISTER-SYSTEM.md;观测台封禁走自有表,<b>不触碰 tb_user</b>。</div>';

  /* ── 动态总控区(#regTop):横幅 + 四卡;随心跳/操作独立重绘 ── */
  const topHtml = ov => {
    const br = ov.breaker || {};
    const brBanner = (br && br.mode)
      ? '<div class="pcard" style="border-color:#c0392b55;background:#c0392b0d;margin-bottom:12px">'
        + '<b style="color:#c0392b">🔴 熔断中 → ' + esc(br.mode) + '</b> · '
        + esc(br.why || '') + ' <span class="mut">(' + esc(br.at || '') + ')</span>'
        + '<button class="btn danger" id="brClear" style="margin-left:10px">恢复注册</button></div>'
      : '';
    // 4.0.4:注册启动自检(后端 preflight 字段)—— tb_user 缺列/口令列长/Redis 任一
    // 不过关都会让注册整体 503,这里显式亮出病灶与可照抄的修复配置,免翻容器日志。
    const pf = ov.preflight || {};
    let pfBanner = '';
    if (pf && pf.ok === false) {
      const miss = Object.keys(pf.missing || {});
      const bits = [];
      if (pf.reason === 'shape_unset') bits.push('未配置口令入库形态 STA_USER_REG_PASS_SHAPE(注册前置条件)');
      if (pf.reason === 'extra_cols_invalid') bits.push('STA_USER_REG_EXTRA_COLS 不是合法 JSON(fail-closed)');
      if (miss.length) bits.push('tb_user 缺覆盖列 <b>' + esc(miss.join(', ')) + '</b>(INSERT 必撞 1364)');
      if ((pf.uncoverable || []).length) bits.push('列名超白名单需 ALTER:' + esc((pf.uncoverable || []).join(', ')));
      if (pf.pwLen != null && pf.pwReq && pf.pwLen < pf.pwReq) bits.push('pass_word 列长 ' + (pf.pwLen | 0) + ' &lt; ' + (pf.pwReq | 0) + '(形态 ' + esc(pf.shape || '') + ' 放不下)');
      if (pf.redisMissing) bits.push('Redis 未接入(挑战/限流不可用)');
      pfBanner = '<div class="pcard" style="border-color:#b4791a66;background:#b4791a0d;margin-bottom:12px">'
        + '<b style="color:#8a5a00">⚠️ 注册启动自检未过</b> —— '
        + (ov.modeEffective === 'off' ? '开启注册前需先处理:' : '注册端点将回 503。')
        + (bits.length ? '<div class="pmeta" style="margin-top:6px">' + bits.join(' · ') + '</div>' : '')
        + (pf.suggestExtraCols ? '<div class="mono" style="margin-top:6px;user-select:all;word-break:break-all">STA_USER_REG_EXTRA_COLS=' + esc(pf.suggestExtraCols) + '</div>' : '')
        + '<div class="pmeta" style="margin-top:4px">改配置后重启 web 生效;复核可跑 scripts/userdb_check.py --reg-preflight。</div></div>';
    }
    const t = ov.today || {}, days = ov.days || [], inv = ov.invites || {}, pw = ov.pow || {};
    const spark = days.length
      ? days.map(d => '<span title="' + esc(d.d) + ':成功 ' + d.ok + ' / 失败 ' + d.fail
          + '" style="display:inline-block;width:26px;text-align:center;font-size:11px">'
          + '<b style="color:var(--brand-deep)">' + d.ok + '</b>'
          + '<span class="mut" style="font-size:10px">/' + d.fail + '</span></span>').join('')
      : '<span class="mut">近 7 日暂无注册</span>';
    return brBanner + pfBanner
      + '<div class="pgrid" style="margin-bottom:14px">'
      + '<div class="pcard"><div class="phead"><span class="plabel">注册模式</span></div>'
      + '<div style="margin:8px 0">生效 ' + regModePill(ov.modeEffective)
      + ' <span class="mut" style="font-size:12px">配置档 ' + esc(ov.modeConfigured) + '</span></div>'
      + '<div class="seg" role="group" style="display:flex;gap:6px;margin-top:6px">'
      + ['off', 'invite', 'open'].map(m => '<button class="btn' + (m === ov.modeConfigured ? ' primary' : '')
          + '" data-mode="' + m + '">' + ({off: '关闭', invite: '邀请码', open: '开放'}[m]) + '</button>').join('')
      + '</div>'
      + ((br && br.mode)
          ? '<div class="pmeta" style="margin-top:6px;color:#8a5a00">熔断压制中:实际生效以上方红色横幅为准;'
            + '「恢复注册」后回到所选配置档。</div>'
          : '')
      + '<div class="pmeta" style="margin-top:8px">口令入库形态:<b>' + esc(ov.passShape || '未配置')
      + '</b>(5–16 位,无组合限制)</div></div>'
      + '<div class="pcard"><div class="phead"><span class="plabel">今日注册</span></div>'
      + '<div style="font-size:22px;margin:6px 0"><b style="color:var(--brand-deep)">' + (t.ok | 0)
      + '</b> <span class="mut" style="font-size:14px">成功 / ' + (t.fail | 0) + ' 失败</span></div>'
      + '<div class="pmeta">近 7 日:' + spark + '</div></div>'
      + '<div class="pcard"><div class="phead"><span class="plabel">PoW 难度水位</span></div>'
      + '<div style="font-size:22px;margin:6px 0"><b>' + (pw.current | 0) + '</b>'
      + ' <span class="mut" style="font-size:13px">位(基础 ' + (pw.base | 0) + ')</span></div>'
      + '<div class="pmeta">自适应只升不降;高压来源自动加难度</div></div>'
      + '<div class="pcard"><div class="phead"><span class="plabel">邀请码</span></div>'
      + '<div style="font-size:15px;margin:6px 0">有效 <b>' + (inv.active | 0) + '</b> / 共 '
      + (inv.total | 0) + ' · 已用 ' + (inv.used | 0) + '</div>'
      + '<div class="pmeta">在下方「邀请码」区批量生成 / 禁用 / 导出</div></div>'
      + '</div>';
  };
  const bindTop = ov => {
    const bc = $('#brClear');
    if (bc) bc.onclick = async () => {
      if (!await ask({title: '恢复注册', body: '将清除熔断状态,注册模式回到配置档。确认?',
                      yes: '恢复', danger: true})) return;
      try { await api('/reg/breaker/clear', {method: 'POST', body: '{}'}); toast('已恢复'); draw(); }
      catch (e) { toast(errText(e, '恢复失败'), 'err'); }
    };
    for (const b of $$('[data-mode]')) b.onclick = async () => {
      const m = b.dataset.mode;
      // 4.0.5:守卫对象改为**配置档** —— seg 设置的就是它。熔断压制期
      // (effective≠configured)旧守卫会放行「点当前配置档」,空转出高危确认
      // 并写入一枚同值 rev;现与高亮口径一致,同值直接无操作。
      if (m === ov.modeConfigured) return;
      // 1.8.0:与参数中心同步 —— 键名抄写下线,保留一次危级二次确认。
      // 抄对 `userauth.reg_mode` 从来不能证明「切到 open 是对的」,而这句话
      // 里写清切到哪一档、后果是什么,才是真正让人停一下的东西。
      if (!await ask({title: '切换注册模式',
                      body: '将把注册模式切为「' + m + '」'
                        + (m === 'open' ? ' —— 任何人都能自助注册。' :
                           m === 'off' ? ' —— 将关闭全部自助注册入口。' :
                           ' —— 仅持邀请码可注册。')
                        + '变更即刻生效并记入审计,可在「更」视图一键回滚。',
                      yes: '切换', danger: true})) return;
      try { await api('/reg/mode', {method: 'POST', body: JSON.stringify({mode: m})}); toast('已切换 → ' + m); draw(); refreshRevPill(); }
      catch (e) { toast(errText(e, '切换失败'), 'err'); }
    };
  };
  const renderTop = ov => {
    const el = $('#regTop'); if (!el) return;
    el.innerHTML = topHtml(ov); bindTop(ov);
  };
  const refreshTop = async () => {
    let ov = null;
    try { ov = await api('/reg/overview'); }
    catch (e) { if (e && e.status === 401) return; ov = null; }
    if (stale()) return;                             // 晚到结果作废(终审收口)
    if (!ov || ov.ok === false || ov.enabled === false) { lastOk = false; return draw(); }
    renderTop(ov);
  };

  /* ── 静态骨架:标题 + 限流运维 + 三个数据区外壳;进入视图仅建一次。
     筛选条(#rlBar)与封禁表单常驻其中 —— 心跳只动各自数据区,
     正在输入的内容与焦点全程无损(此前 15s 一到整块 innerHTML 重建,
     打一半的筛选串直接蒸发,与代码注释「避免打断输入框」自相矛盾)。 ── */
  const buildShell = () => {
    $('#main').innerHTML = HEAD
      + '<div id="regTop"><span class="mut">加载中…</span></div>'
      // 限流运维(4.0.3):一键清 guantai:reg:* 计数 —— 熔断态刻意不在此列(有专属恢复路径)
      + '<div class="pcard" style="margin-bottom:14px"><div class="phead"><span class="plabel">限流运维</span>'
      + '<button class="btn danger" id="thrClear">清空全部注册限流</button></div>'
      + '<div class="pmeta" style="margin-top:6px">清除 R1 时/日窗、全局时/日窗、难度阶梯、同名/重名计数、'
      + '成功配额、挑战签发计数、审计限幅与事务锁(Redis + 进程内兜底双清)。'
      + '适用:自测打满日窗、反代未透传真实 IP 的全站误伤急救。'
      + '<b>不触碰</b>进行中挑战、登录失败锁与熔断态(熔断恢复走上方横幅)。</div></div>'
      // 邀请码区(4.0.5:分页贯通 + §5-R7② 的「导出 txt」)
      + '<div class="pcard" style="margin-bottom:14px"><div class="phead"><span class="plabel">邀请码</span>'
      + '<button class="btn" id="invExp">导出 txt</button>'
      + '<button class="btn primary" id="invGen">批量生成</button></div>'
      + '<div id="invBox" style="margin-top:10px"><span class="mut">加载中…</span></div></div>'
      // 流水区(4.0.5:筛选条/数据区分离;§5-R7③ 的聚类高亮在数据区落地)
      + '<div class="pcard" style="margin-bottom:14px"><div class="phead"><span class="plabel">注册流水</span>'
      // 4.0.7:高亮语义补上时窗(见 drawRegLog 内聚类段的复现记录),并把
      // 「点行看详情」写进提示 —— 这是触屏用户读到完整 UA/指纹的唯一入口,
      // 藏在交互里不说等于没有(4.9.4 触屏钉的教训:title 在手机上一个字都不渲染)。
      + '<span class="mut" style="font-size:12px">本页内同 IP / 同指纹 ×3 且 60 分钟内 → 淡金高亮'
      + '「同源近时批量」,仅提示不判决;点任意行看完整 UA / 指纹与快捷筛选</span></div>'
      + '<div style="margin-top:10px">'
      + '<div id="rlBar" style="display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap">'
      + '<input id="rlIp" placeholder="按 IP 精确筛" aria-label="按 IP 精确筛选" style="width:130px">'
      + '<input id="rlName" placeholder="按用户名精确筛" aria-label="按用户名精确筛选" style="width:130px">'
      // 4.0.7:「结果」下拉升级为 全部/仅成功/仅失败 + 具体原因 一体式(§5-R7③
      // 本就把「原因」列为流水维度,却一直只能筛成败 —— 排查「为什么一片
      // throttled」得翻页肉眼数)。选项取自 REG_REASON 的规范码,与后端落库
      // 值一一对应;值前缀 r: 与 0/1 区分,goLog 解包。
      + '<select id="rlOk" class="sel" aria-label="按结果或具体原因筛选"><option value="">全部</option>'
      + '<option value="1">仅成功</option><option value="0">仅失败</option>'
      + '<optgroup label="按具体原因">'
      + Object.keys(REG_REASON).filter(k => k !== 'ok')
          .map(k => '<option value="r:' + k + '">' + esc(REG_REASON[k]) + '</option>').join('')
      + '</optgroup></select>'
      + '<button class="btn" id="rlGo">筛选</button>'
      // 1.7.8:「重置」—— 进入筛选态处处一步(下拉选择即筛、详情弹窗一键按 IP 筛),
      // 退出却要 清两输入框+复位下拉+点筛选 三步;下方空态文案写着「清空上方筛选」
      // 却一直没给出那个动作。一键全维归零(含未提交的半截输入)并回第 1 页;
      // 无筛选时点击 = 回到最新第 1 页,顺手即是深翻页后的「回家」。
      + '<button class="btn ghost" id="rlReset" title="清空全部筛选并回到第 1 页">重置</button></div>'
      + '<div id="rlTbl"><span class="mut">加载中…</span></div></div></div>'
      // 封禁区
      + '<div class="pcard"><div class="phead"><span class="plabel">观测台封禁</span>'
      + '<span class="mut" style="font-size:12px">写自有表,登录即回 banned;在线会话 ≤20s 下线</span></div>'
      + '<div id="blockBox" style="margin-top:10px"><span class="mut">加载中…</span></div></div>';
    // 静态区一次性绑定(元素随视图切换被整体替换,无泄漏;动态区各自就地绑定)
    const tc = $('#thrClear');
    tc.onclick = async () => {
      if (!await ask({title: '清空全部注册限流',
                      body: '将删除 guantai:reg:* 全部限流计数(Redis + 进程内兜底)。'
                        + '所有 IP / 用户名的注册配额与难度阶梯立即复位;'
                        + '熔断态与进行中挑战<b>不受影响</b>。确认?',
                      yes: '清空', danger: true})) return;
      try {
        const d = await api('/reg/throttle/clear', {method: 'POST', body: '{}'});
        const c = (d && d.cleared) || {};
        toast('已清空:Redis ' + (c.redis | 0) + ' 键 / 进程内 ' + (c.mem | 0) + ' 项'
          + (c.redis_ok === false ? '(Redis 异常,仅清进程内)' : ''));
        draw();
      } catch (e) { toast(errText(e, '清空失败'), 'err'); }
    };
    $('#invGen').onclick = doGenInvites;
    $('#invExp').onclick = doExportInvites;
    $('#rlGo').onclick = goLog;
    $('#rlReset').onclick = () => {                    // 1.7.8:一键清空(见上方按钮注释)
      $('#rlIp').value = ''; $('#rlName').value = ''; $('#rlOk').value = '';
      goLog();
    };
    $('#rlOk').onchange = goLog;                       // 选择即筛,少点一次
    // 终审对齐:'Enter' 须排除输入法组字确认(!e.isComposing)—— 本文件 1.2.0
    // 名录搜索(rmQ)与 app.js 房号搜索早有此范式;rlName 按中文用户名筛选时,
    // 组字中的 Enter 只是在选候选词,不是提交。
    $('#rlIp').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.isComposing) goLog(); });
    $('#rlName').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.isComposing) goLog(); });
  };

  /* ── 整页装配:失败/未启用态整页呈现;成功态建骨架(仅首次)+ 各区重绘。
     queued 防重入:心跳与操作触发的 draw 重叠时,后到的排队而非并发写 DOM。 ── */
  const draw = async () => {
    if (busy) { queued = true; return; }
    busy = true;
    try {
      let ov = null;
      try { ov = await api('/reg/overview'); }
      catch (e) { if (e && e.status === 401) return; ov = null; }
      // 终审加固:fetch 期间用户可能已切走视图(失败态心跳每 15s 一发,窗口不小),
      // 甚至切走又切回(此时 #main 属于新一届 renderReg)。两种晚到都作废,
      // 不许污染当前 DOM。
      if (stale()) return;
      if (!ov || ov.ok === false) {
        // ok:false(如 stats_failed)此前会被静默渲染成一排 0 —— 假数据比没数据更糟。
        lastOk = false;
        $('#main').innerHTML = HEAD + '<div class="empty">加载失败'
          + (ov && ov.hint ? '(' + esc(ov.hint) + ')' : '')
          + ' —— 15 秒后自动重试。</div>';
        return;
      }
      if (ov.enabled === false) {
        lastOk = false;                    // 心跳继续探:配齐配置后无需手刷,15s 内自动亮起
        $('#main').innerHTML = HEAD + '<div class="empty">登录系统未启用 —— 注册功能不生效。'
          + '配齐 <span class="mono">STA_USERDB_*</span> 并设置 '
          + '<span class="mono">STA_USER_REG_PASS_SHAPE</span> 后,此处可切换注册模式与管理邀请码。</div>';
        return;
      }
      const fresh = !$('#regTop');
      if (fresh) buildShell();
      renderTop(ov);
      lastOk = true;
      await zone(drawInvites, '#invBox', '邀请码');
      await zone(drawRegLog, '#rlTbl', '注册流水');
      // 封禁区仅动作后变化,不吃心跳(表单不被扰动)
      if (fresh) await zone(drawBlocks, '#blockBox', '观测台封禁');
    } finally {
      busy = false;
      if (queued) { queued = false; if (!stale()) draw(); }
    }
  };

  /* ── 邀请码:分页列表 + 禁用 + 导出 ── */
  const drawInvites = async () => {
    const box = $('#invBox'); if (!box) return;
    let d = null;
    try { d = await api('/reg/invites?page=' + IV.page + '&size=50&all=1'); }
    catch (e) { box.innerHTML = '<span class="mut">加载失败</span>'; return; }
    if (stale()) return;                             // 晚到结果作废(终审收口)
    if (!(d.items || []).length) {
      if ((IV.page | 0) > 1) { IV.page = 1; return drawInvites(); }   // 悬空页回退
      box.innerHTML = '<span class="mut">还没有邀请码。点「批量生成」创建。</span>'; return;
    }
    let hh = '<table class="tbl"><tr><th>码</th><th>赠送</th><th>配额</th><th>已用</th>'
      + '<th>有效期</th><th>状态</th><th></th></tr>';
    for (const r of d.items) {
      const st = r.disabled ? '<span class="mut">已禁用</span>'
        : r.expired ? '<span class="mut">已过期</span>'
          : (r.used_count >= r.quota) ? '<span class="mut">已用尽</span>'
            : '<span style="color:var(--brand-deep)">有效</span>';
      hh += '<tr><td class="mono" style="font-size:12px">' + esc(r.code_disp) + '</td>'
        + '<td>' + r.days_granted + ' 天</td><td>' + r.quota + '</td><td>' + r.used_count + '</td>'
        + '<td class="mut" style="font-size:12px">' + (r.expires_at ? esc(r.expires_at.slice(0, 10)) : '不过期') + '</td>'
        + '<td>' + st + '</td>'
        + '<td>' + (r.disabled ? '' : '<button class="btn" data-dis="' + r.id + '">禁用</button>') + '</td></tr>';
    }
    hh += '</table>';
    const total = d.total | 0, size = (d.size | 0) || 50;
    const pages = Math.max(1, Math.ceil(total / size));
    hh += '<div style="margin-top:8px;font-size:12px">共 ' + total + ' 枚 · 第 ' + (d.page | 0)
      + ' / ' + pages + ' 页 '
      + (d.page > 1 ? '<button class="btn" id="invPrev">上一页</button> ' : '')
      + (d.page < pages ? '<button class="btn" id="invNext">下一页</button>' : '') + '</div>';
    box.innerHTML = hh;
    for (const b of box.querySelectorAll('[data-dis]')) b.onclick = async () => {
      if (!await ask({title: '禁用邀请码', body: '该码将立即失效(已注册的账号不受影响)。确认?', yes: '禁用', danger: true})) return;
      try {
        await api('/reg/invites/' + b.dataset.dis + '/disable', {method: 'POST', body: JSON.stringify({disabled: true})});
        toast('已禁用'); drawInvites(); refreshTop();   // 4.0.5:总控卡的有效数同步刷新
      } catch (e) { toast(errText(e, '禁用失败'), 'err'); }
    };
    if ($('#invPrev')) $('#invPrev').onclick = () => { IV.page--; drawInvites(); };
    if ($('#invNext')) $('#invNext').onclick = () => { IV.page++; drawInvites(); };
  };
  // §5-R7② 的「导出 txt」:只导**有效码**(未禁用/未过期/未用尽,后端 all=0 口径),
  // 一行一枚四段展示,拿去即可分发;禁用/过期码混进分发名单只会制造客诉。
  const doExportInvites = async () => {
    try {
      let page = 1, total = Infinity;
      const out = [];
      while (out.length < total && page <= 25) {       // 硬顶 25×200=5000,防御异常 total
        const d = await api('/reg/invites?page=' + page + '&size=200&all=0');
        total = d.total | 0;
        const items = d.items || [];
        for (const r of items) out.push(r.code_disp);
        if (!items.length) break;
        page++;
      }
      if (!out.length) { toast('没有可导出的有效邀请码', 'err'); return; }
      const blob = new Blob([out.join('\n') + '\n'], {type: 'text/plain;charset=utf-8'});
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'invite-codes-' + new Date().toISOString().slice(0, 10) + '.txt';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      // 终审加固:撞到 25×200 硬顶时如实报截断,而不是「已导出 N 枚」装作完整
      // (静默截断正是 A4/A7 批过的病,自家新功能不许再犯)。
      if (out.length < total) toast('已导出前 ' + out.length + ' 枚(共 ' + total
        + ' 枚,超出单次导出上限 —— 可分批禁用后再导)', 'err');
      else toast('已导出 ' + out.length + ' 枚有效邀请码');
    } catch (e) { toast(errText(e, '导出失败'), 'err'); }
  };
  const doGenInvites = async () => {
    const html = '<div style="display:grid;gap:8px;text-align:left">'
      + '<label>条数 <input id="giCount" type="number" value="10" min="1" max="200" style="width:100%"></label>'
      + '<label>每码配额(可注册次数,上限 100000) <input id="giQuota" type="number" value="1" min="1" max="100000" style="width:100%"></label>'
      + '<label>赠送天数 <input id="giDays" type="number" value="1" min="0" max="3650" style="width:100%"></label>'
      + '<label>有效期天数(0=不过期) <input id="giExp" type="number" value="0" min="0" max="3650" style="width:100%"></label>'
      + '<label>备注 <input id="giNote" type="text" maxlength="100" style="width:100%"></label></div>';
    // collect 在弹窗**清空前**现场回收字段值(#askB 用 innerHTML 承载表单;
    // 这些 #giXxx 是弹窗内的临时元素,提交后即被下一次 ask 覆盖)
    const payload = await ask({title: '批量生成邀请码', html, yes: '生成',
      collect: () => ({
        count: +$('#giCount').value || 1, quota: +$('#giQuota').value || 1,
        days: +$('#giDays').value || 0, expiresDays: +$('#giExp').value || 0,
        note: ($('#giNote').value || '').trim(),
      })});
    if (!payload) return;                          // 取消
    try {
      const r = await api('/reg/invites/generate', {method: 'POST', body: JSON.stringify(payload)});
      const codes = (r.codes || []).join('\n');
      const n = (r.codes || []).length;
      // 4.0.5:文案与事实对齐 —— 码在下方列表与「导出 txt」随时可查(§5-R7② 设计
      // 即列表明文四段展示),旧文案「明文仅此一次展示」是错的,吓人还不真;
      // 复制改显式按钮 + 明确回执(navigator.clipboard,失败退 execCommand 兜底),
      // 不再在点「完成」时静默 execCommand(成没成只有天知道)。
      const p2 = ask({title: '已生成 ' + n + ' 枚',
                 html: '<p style="margin:0 0 6px;font-size:13px">一行一枚 —— 随时也可在下方列表查看,或「导出 txt」取全部有效码:</p>'
                   + '<textarea id="giOut" readonly style="width:100%;height:120px;'
                   + 'font-family:monospace;font-size:12px;resize:vertical">' + esc(codes) + '</textarea>'
                   + '<button class="btn" id="giCopy" type="button" style="margin-top:8px">复制全部</button>',
                 yes: '完成'});
      const cb = $('#giCopy');
      if (cb) cb.onclick = async () => {
        const txt = $('#giOut') ? $('#giOut').value : codes;
        try { await navigator.clipboard.writeText(txt); toast('已复制 ' + n + ' 枚到剪贴板'); }
        catch (_) {
          try { $('#giOut').select(); document.execCommand('copy'); toast('已复制 ' + n + ' 枚(兼容模式)'); }
          catch (__) { toast('复制失败 —— 请在文本框内手动全选复制', 'err'); }
        }
      };
      await p2;
      IV.page = 1; drawInvites(); refreshTop();    // 新码在第 1 页;总控卡计数同步
    } catch (e) { toast(errText(e, '生成失败'), 'err'); }
  };

  /* ── 注册流水:只重绘数据区(#rlTbl);聚类高亮 + 指纹/UA 全量悬停 ── */
  const goLog = () => {
    RL.ip = ($('#rlIp').value || '').trim();
    RL.name = ($('#rlName').value || '').trim();
    // 4.0.7:下拉现在承载三类值 —— ''(全部)/ '1'|'0'(成败)/ 'r:<码>'(具体原因)。
    const v = $('#rlOk').value;
    RL.ok = (v === '0' || v === '1') ? v : '';
    RL.reason = (v && v.slice(0, 2) === 'r:') ? v.slice(2) : '';
    RL.page = 1; drawRegLog();
  };
  const drawRegLog = async () => {
    const box = $('#rlTbl'); if (!box) return;
    let d = null;
    const qs = '?page=' + RL.page + '&size=30'
      + (RL.ip ? '&ip=' + encodeURIComponent(RL.ip) : '')
      + (RL.name ? '&name=' + encodeURIComponent(RL.name) : '')
      + (RL.ok !== '' ? '&ok=' + RL.ok : '')
      + (RL.reason ? '&reason=' + encodeURIComponent(RL.reason) : '');
    try { d = await api('/reg/log' + qs); } catch (e) { box.innerHTML = '<span class="mut">加载失败</span>'; return; }
    if (stale()) return;                             // 晚到结果作废(终审收口)
    const items = d.items || [];
    if (!items.length) {
      // 4.0.7 悬空页回退(与 drawInvites 同款,此前独漏本区):停在第 N 页时
      // 数据被每日清扫/筛选收缩,旧实现直接落「无匹配记录」,而上一页按钮
      // 与表格是同一块 innerHTML —— 一起消失。真机复现:第 3 页等 15s 心跳,
      // 人被困在一个既无数据也无任何按钮能离开的页码上,唯一生路是知道
      // 「筛选」会重置页码 —— 新人不知道。
      if ((RL.page | 0) > 1) { RL.page = 1; return drawRegLog(); }
      // 空态分流:带着筛选条件扑空 ≠ 库里真没有 —— 前者给下一步,后者说事实。
      box.innerHTML = '<span class="mut">' + (RL.ip || RL.name || RL.ok !== '' || RL.reason
        ? '无匹配记录 —— 可调整筛选,或点上方「重置」清空全部条件。' : '还没有注册流水。') + '</span>';
      return;
    }
    // §5-R7③ 聚类:页面按 id 倒序取 30 条;本页内同 IP 或同指纹 ≥3 **且这些行
    // 首尾相距 ≤60 分钟**,才视作「同源近时批量」,整行淡金 + 悬停给出依据。
    // 4.0.7 修:旧口径只数条数、不看时间 —— 家庭固定 IP 三口人分散 33 天各注册
    // 一次,按 IP 一筛,三行整片淡金、悬停还写着「近时」(真库实测复现),把最
    // 该被温柔对待的真人场景标成批量嫌疑。时窗取 60 分钟:与后端 R8「同指纹
    // 10 分钟 ≥3 → 难度 +4」同一哲学,只是展示层放宽到页级形态可见的尺度;
    // 时距一并写进悬停 —— 是不是批量,让人带着证据自己看(仍是提示不判决)。
    // 同因,按 IP 精确筛时不再按 IP 聚类:全员同 IP 是筛选的必然,零信息量,
    // 反把「淡金=可疑」的语义冲成噪声(指纹维度不受影响,仍照常聚)。
    // 终审加固(沿袭):计数字典用 null 原型 —— ip 在 STA_USER_TRUST_XFF 开启时
    // 属用户可控串,'__proto__' 等魔法键会让普通对象的计数悄悄失效(无污染,
    // 但该行永远数不到 3,高亮漏标)。
    const HOT_WIN = 60 * 60 * 1000;
    const cIp = Object.create(null), cFp = Object.create(null);
    const bump = (m, k, t) => {
      const g = m[k] || (m[k] = {n: 0, lo: Infinity, hi: -Infinity});
      g.n++; if (t === t) { if (t < g.lo) g.lo = t; if (t > g.hi) g.hi = t; }
    };
    for (const r of items) {
      const t = Date.parse(r.created_at || '');
      if (r.ip && !RL.ip) bump(cIp, r.ip, t);
      if (r.fp) bump(cFp, r.fp, t);
    }
    // lo<=hi 兜底:时间全解析失败(理论不可达,列 NOT NULL)时宁可不亮,
    // 也不给一个没有时间证据的「近时」标签。
    const hotOf = (m, k) => {
      const g = k ? m[k] : null;
      return (g && g.n >= 3 && g.lo <= g.hi && g.hi - g.lo <= HOT_WIN) ? g : null;
    };
    const spanTxt = g => Math.max(1, Math.ceil((g.hi - g.lo) / 60000)) + ' 分钟内';
    let hh = '<table class="tbl"><tr><th>时间</th><th>结果</th><th>用户名</th><th>IP</th>'
      + '<th>指纹</th><th>UA</th></tr>';
    for (let i = 0; i < items.length; i++) {
      const r = items[i];
      const gIp = hotOf(cIp, r.ip), gFp = hotOf(cFp, r.fp);
      const why = (gIp || gFp) ? esc('同源近时:'
            + (gIp ? 'IP ×' + gIp.n + '(' + spanTxt(gIp) + ')' : '')
            + (gIp && gFp ? ' ' : '')
            + (gFp ? '指纹 ×' + gFp.n + '(' + spanTxt(gFp) + ')' : '')) : '';
      hh += '<tr data-ri="' + i + '"' + (why ? ' style="background:var(--gilt-soft)" title="' + why + '"' : '') + '>'
        + '<td class="mut" style="font-size:11px;white-space:nowrap">' + esc((r.created_at || '').replace('T', ' ').slice(0, 19)) + '</td>'
        + '<td>' + (r.ok ? '<span style="color:var(--brand-deep)">成功</span>'
          : '<span class="mut">' + esc(REG_REASON[r.reason] || r.reason || '失败') + '</span>') + '</td>'
        + '<td>' + esc(r.user_name || '—') + (r.user_id ? ' <span class="mut">#' + r.user_id + '</span>' : '') + '</td>'
        + '<td class="mono" style="font-size:11px">' + esc(r.ip || '') + '</td>'
        + '<td class="mono" style="font-size:10px" title="' + esc(r.fp || '') + '">' + esc((r.fp || '').slice(0, 10)) + '</td>'
        + '<td class="mut" style="font-size:10px" title="' + esc(r.ua || '') + '">' + esc((r.ua || '').slice(0, 60)) + '</td></tr>';
    }
    hh += '</table>';
    const rlTotal = d.total | 0, rlSize = (d.size | 0) || 30;
    const pages = Math.max(1, Math.ceil(rlTotal / rlSize));
    // 4.0.7:表格独居横向滚动容器(.tbl-scroll)—— 390px 真机实测,570px 宽的
    // 表塞进 364px 的卡片,两层容器 overflow-x 全是 visible,表格洇出卡片边框,
    // 横滚条落在 #main 上,一拖整页(标题/筛选条/其余卡)跟着平移。收容后滚动
    // 只发生在数据自己身上;分页/跳页留在容器外,翻页永远不用先把表拖回来。
    let ph = '<div style="margin-top:8px;font-size:12px">第 ' + (d.page | 0) + ' / ' + pages + ' 页 · 共 ' + rlTotal + ' 条 '
      + (d.page > 1 ? '<button class="btn" id="rlPrev">上一页</button> ' : '')
      + (d.page < pages ? '<button class="btn" id="rlNext">下一页</button>' : '')
      // 跳页:阈值与「值」视图分页器同款(>3 页才值得多一个控件),样式复用
      // 既有 .jv-pjump 令牌 —— 日增留存下靠 上/下一页 一格格爬回历史不现实。
      + (pages > 3 ? ' <span class="jv-pjump">跳至<input id="rlJump" type="number" min="1" max="' + pages
          + '" value="' + (d.page | 0) + '" aria-label="跳至第几页" enterkeyhint="go">页 '
          + '<button class="btn" id="rlJumpGo">跳转</button></span>' : '')
      + '</div>';
    box.innerHTML = '<div class="tbl-scroll">' + hh + '</div>' + ph;
    if ($('#rlPrev')) $('#rlPrev').onclick = () => { RL.page--; drawRegLog(); };
    if ($('#rlNext')) $('#rlNext').onclick = () => { RL.page++; drawRegLog(); };
    const rlJump = () => {
      const el = $('#rlJump'); if (!el) return;
      const n = Math.max(1, Math.min(pages, Math.round(+el.value) || 1));   // 越界钳制
      if (n !== RL.page) { RL.page = n; drawRegLog(); }
    };
    if ($('#rlJumpGo')) $('#rlJumpGo').onclick = rlJump;
    if ($('#rlJump')) $('#rlJump').addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); rlJump(); } });
    // 4.0.7 行点按 → 详情弹窗。动机三合一(均实测坐实,非推演):
    //   ① 触屏读不到 title —— 指纹后 6 位/UA 第 61 字起/聚类依据,手机上物理
    //      不可达(4.9.4 触屏钉点名的同病类,那次是前台 3500+ 个 title);
    //   ② 心跳每 15s 重建表格,正选中一半准备复制的 IP 被连根抹掉(真机复现:
    //      选区 '116.25.180.7' → 心跳后 '')—— 弹窗游离于重绘区之外,想选多久
    //      选多久;③ 「按此 IP 筛选」把 选中→复制→粘贴→点筛选 四步收成一步。
    // 正在拖字复制时点按不抢戏(getSelection 非空即让路)。
    const tb = box.querySelector('table');
    if (tb) tb.addEventListener('click', async e => {
      const tr = e.target.closest('tr[data-ri]'); if (!tr) return;
      if (String(window.getSelection ? window.getSelection() : '')) return;
      const r = items[+tr.dataset.ri]; if (!r) return;
      const gIp = hotOf(cIp, r.ip), gFp = hotOf(cFp, r.fp);
      const line = (k, v, mono) => '<div style="display:flex;gap:8px;margin:3px 0">'
        + '<span class="mut" style="flex:none;width:52px">' + k + '</span>'
        + '<span style="min-width:0;overflow-wrap:anywhere'
        + (mono ? ';font-family:var(--mono);font-size:12px' : '') + '">' + v + '</span></div>';
      const html = '<div style="text-align:left;font-size:13px">'
        + line('时间', esc((r.created_at || '').replace('T', ' ').slice(0, 19)))
        + line('结果', r.ok ? '<span style="color:var(--brand-deep)">成功</span>'
            : esc(REG_REASON[r.reason] || r.reason || '失败')
              + (r.reason && REG_REASON[r.reason]
                 ? ' <span class="mut">(' + esc(r.reason) + ')</span>' : ''))
        + line('用户名', esc(r.user_name || '—')
            + (r.user_id ? ' <span class="mut">#' + r.user_id + '</span>' : ''))
        + line('IP', esc(r.ip || '—'), true)
        + line('指纹', esc(r.fp || '—'), true)
        + (r.invite_id ? line('邀请码', '#' + (r.invite_id | 0)) : '')
        + line('UA', esc(r.ua || '—'), true)
        + ((gIp || gFp) ? '<div class="warn-line" style="margin-top:8px;font-size:12px">同源近时:'
            + (gIp ? '同 IP ×' + gIp.n + '(' + spanTxt(gIp) + ')' : '')
            + (gIp && gFp ? ' · ' : '')
            + (gFp ? '同指纹 ×' + gFp.n + '(' + spanTxt(gFp) + ')' : '')
            + ' —— 仅提示不判决</div>' : '')
        + '</div>';
      const go = await ask({title: '注册流水详情', html,
                            yes: r.ip ? '按此 IP 筛选' : '关闭'});
      if (go !== null && r.ip && !stale()) {
        // 「按此 IP 筛选」语义 = **只**看这个 IP:名称/结果两维一并复位,
        // 免得残留的旧条件把该 IP 的其余行悄悄滤没,人还以为它就这几条。
        $('#rlIp').value = r.ip; $('#rlName').value = ''; $('#rlOk').value = '';
        goLog();
      }
    });
  };

  /* ── 观测台封禁:表单 + 列表(仅动作后重绘,不吃心跳)── */
  const drawBlocks = async () => {
    const box = $('#blockBox'); if (!box) return;
    let d = null;
    try { d = await api('/reg/blocks'); } catch (e) { box.innerHTML = '<span class="mut">加载失败</span>'; return; }
    if (stale()) return;                             // 晚到结果作废(终审收口)
    const items = d.items || [];
    const total = (d.total != null ? d.total | 0 : items.length);
    let hh = '<div style="display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap">'
      + '<input id="blkUids" placeholder="user_id(逗号分隔)" aria-label="待封禁的 user_id,逗号分隔" style="flex:1;min-width:180px">'
      + '<input id="blkNote" placeholder="备注(可选)" aria-label="封禁备注" style="width:150px">'
      + '<button class="btn danger" id="blkAdd">封禁</button></div>';
    if (!items.length) hh += '<span class="mut">当前没有观测台侧封禁的账号。</span>';
    else {
      hh += '<div class="mut" style="font-size:12px;margin-bottom:6px">共 ' + total + ' 条'
        + (total > items.length ? ' · 仅显示最近 ' + items.length + ' 条' : '') + '</div>';
      hh += '<table class="tbl"><tr><th>user_id</th><th>用户名</th><th>原因</th><th>备注</th><th>时间</th><th></th></tr>';
      for (const r of items) {
        hh += '<tr><td>#' + r.user_id + '</td><td>' + esc(r.user_name || '—') + '</td>'
          + '<td class="mut">' + esc(r.reason || '') + '</td><td>' + esc(r.note || '') + '</td>'
          + '<td class="mut" style="font-size:11px">' + esc((r.created_at || '').replace('T', ' ').slice(0, 19)) + '</td>'
          + '<td><button class="btn" data-unblk="' + r.user_id + '">解封</button></td></tr>';
      }
      hh += '</table>';
    }
    box.innerHTML = hh;
    const addFn = async () => {
      const uids = ($('#blkUids').value || '').split(',').map(x => x.trim()).filter(x => /^\d+$/.test(x));
      if (!uids.length) { toast('请输入至少一个 user_id', 'err'); return; }
      if (!await ask({title: '观测台封禁', body: '将封禁 ' + uids.length + ' 个账号(不改 tb_user;登录即回 banned)。确认?', yes: '封禁', danger: true})) return;
      try { await api('/reg/block', {method: 'POST', body: JSON.stringify({userIds: uids, note: ($('#blkNote').value || '').trim()})}); toast('已封禁'); drawBlocks(); }
      catch (e) { toast(errText(e, '封禁失败'), 'err'); }
    };
    $('#blkAdd').onclick = addFn;
    // 4.0.5 真机走查抓到的误触链:input 的 Enter(keydown)→ addFn 同步弹 ask →
    // 焦点落到「确认」钮 → **同一次击键**的默认激活(Chromium 在 keydown 阶段
    // 对聚焦按钮派发合成 click,isTrusted=true/detail=0)直通确认 —— 危级封禁
    // 一键放行,确认框形同虚设。preventDefault 声明本次击键已被消费,阻断默认激活。
    // 终审再收口:并排除输入法组字确认(!e.isComposing,同库 rmQ 既有范式)——
    // 否则在备注框打中文选词的那一下 Enter 就会蹦出危级封禁确认框。
    $('#blkUids').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); addFn(); } });
    $('#blkNote').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); addFn(); } });
    for (const b of box.querySelectorAll('[data-unblk]')) b.onclick = async () => {
      if (!await ask({title: '解封', body: '解除对 #' + b.dataset.unblk + ' 的观测台封禁?', yes: '解封'})) return;
      try { await api('/reg/block', {method: 'POST', body: JSON.stringify({userIds: [b.dataset.unblk], unblock: true})}); toast('已解封'); drawBlocks(); }
      catch (e) { toast(errText(e, '解封失败'), 'err'); }
    };
  };

  await draw();
  S.timers.push(setInterval(async () => {
    // 4.0.5:心跳覆盖「总控 + 邀请码 + 流水」(旧注释声称刷总控实则只刷流水,
    // 现在实现追平承诺);失败/未启用态改为整页重试 —— 让「15 秒后自动重试」
    // 是真话。筛选条与封禁表单在静态区,心跳只动各自数据区,输入与焦点无损。
    // 视图切走由 clearTimers 统一收摊(与其它视图同款,不留全局监听器)。
    if (!$('#main') || stale()) return;
    if (!lastOk) { await draw(); return; }
    await refreshTop();
    if (!lastOk) return;                 // refreshTop 内已降级为整页 draw
    await zone(drawInvites, '#invBox', '邀请码');
    await zone(drawRegLog, '#rlTbl', '注册流水');
  }, 15000));
}
/* ═══════════ 「值」· 九法VIP 与充值(4.2.5)═══════════
   与既有九视图同构:走同一个 api()/ask()/toast(),不引入任何新机制。
   高危动作(手动开通 / 撤销)必填操作原因,后端同时落
   guantai_jf_grant_log.operator 与 admin_audit —— 事后能一眼看出
   「谁在什么时候给谁开了多久、为什么」。

   ★ 4.2.5 复审修补(每条均为真 DOM 实测复现,非纸面推演):
     ① 本视图曾是**全站唯一**不走 errText() 的视图 —— 写成 `String(e.message || e)`,
        而 api() 抛的是 `{status, data}` 纯对象、没有 .message ⇒ 8 处错误分支
        **一律显示 `[object Object]`**,后端精心写的中文 hint 全被丢弃。
     ② ask() 的 `input` 只作布尔用(文案走 placeholder),而此处传的是提示串 ⇒
        手动开通/撤销这两个最高危操作,弹出的是**无标签空白输入框**。
     ③ GET /jfvip/* 在关闭态回 **HTTP 200 + ok:false**,api() 不抛 ⇒ 前端把失败
        当成功渲染成「共 undefined 张 · 第 undefined 页」。
     ④ 「导出本批」实际只导出**当前页**;⑤ CSV 零转义(逗号即错列)且未防公式注入;
     ⑥ 作废弹窗承诺「可用同一入口恢复」,而前端根本没有恢复入口(后端 undo 早已实现)。 */
const JV = { tab: 'overview', plans: [],
             /* 4.2.8:card=卡号前缀搜索;
                sel=按 id 的选择集(Set,不挂 DOM,翻页/重绘后不丢)。
                ★ 4.3.0 实地核查:此处原有一句「reveal=是否显示完整卡号(默认掩码)」,
                  而 JV.cards 里**从来没有 reveal 这个字段**,列表渲染也一直是
                  `esc(c.card)` 明文直出 —— 全文检索 reveal 只命中参数中心的密钥
                  揭示,与本视图无关。功能不存在而注释宣称存在,正是本项目反复
                  写的「谎报比不报危险」:后来者会以为掩码已经做了。
                  管理台展示完整卡号是刻意的(运维要按卡号排障、要导给渠道),
                  故删掉这句假话,而不是去补一个没人要的掩码。 */
             cards: {page: 1, size: 50, batch: '', status: '', plan: '',
                     card: '', sel: null, selMeta: null, _batches: null},
             /* 订单检索条件(4.2.6)。每一项都对应后端一条实测过代价的谓词 ——
                orderNo 只做前缀(中缀 LIKE 实测 200,048 行 vs 前缀 24 行),
                userName 由后端解析成 uid 再查(裸 user_name= 实测 400,000 行)。 */
             orders: {page: 1, size: 50, status: '', orderNo: '', userName: '',
                      plan: '', dateFrom: '', dateTo: '', amtMin: '', amtMax: '',
                      simulate: '', credited: ''},
             /* 4.3.0:开通流水补时间区间。它是本项目宣告的**唯一对账口径**,
                而对账天然按期做 —— 订单页早就有下单起/止,这里却一直只有
                「来源」一个条件;后端建表时留的 idx_time / idx_source(source,
                created_at) 两把索引也一直闲置。连带解开的死结见 jvFetchAll 注。 */
             grants: {page: 1, size: 50, source: '', uid: 0,
                      dateFrom: '', dateTo: ''},
             _timer: 0, _refocus: false, _refocusPager: '' };

const JV_PAGE = 50;                    // 列表页长
const JV_BULK = 500;                   // 导出时每次往返取多少条(后端 size 上限亦为 500)
const JV_SEL_CAP = 500;                // 单次可选/可提交上限,必须与后端 _MAX_IDS_PER_CALL 同值
const JV_EXPORT_CAP = 5000;            // 导出总条数护栏:超过则提示改用按批次/状态收窄

function jvMoney(n) { return '¥' + Number(n || 0).toFixed(2); }
/* ── 客服联系方式的生效值回显(4.4.2)────────────────────────────────────────
   与上面那块「站点分流已启用」并列,存在理由也完全一样:**这一项配错是静默的**
   —— 开通门上要么少一行,要么多一串错号码,页面不会报任何错,运维只会在用户
   找上门时才知道。此前他连"服务端最终认下了什么"都无从得知。

   ★ 显示的是后端 cs_text() / cs_url() **收敛之后**的值,不是参数中枢里的原始串:
     被白名单丢弃的链接在这里就是空(并另给一条醒目告警),全角数字则会原样
     留着 —— 那是刻意的(系统不替运维猜字符),但必须让他看见。 */
function jvCsHtml(ov) {
  const cs = (ov.site && ov.site.cs) || {};
  const hasCs = !!(cs.value || cs.url);
  const lim = cs.limits || {};
  const dropped = !!(cs.urlRaw && !cs.url);      // 填了链接却被整条丢弃
  const valDropped = !!(cs.valueRaw && !cs.value);   // 号码超长被整条丢弃
  if (!hasCs && !dropped && !valDropped) return '';
  const direct = ((ov.site || {}).directHosts || []).length;
  let h = '';
  if (hasCs) {
    h += `<p class="mut" style="margin-top:8px">
      ☎️ <b>客服联系方式已配置</b> · ${esc(cs.label || '客服')}`
      + (cs.value ? ` <b>${esc(cs.value)}</b>` : '')
      + (cs.url ? ` · 链接 <b>${esc(cs.url)}</b>` : '')
      + (cs.note ? ` · 备注「${esc(cs.note)}」` : '')
      + `<br>展示位:九法VIP 开通门的「联系客服购买」一行(号码给「展示 + 复制」,
      填了 https 链接才多一个点得动的去处)。`
      + (direct
          ? `<b>仅直营主站展示</b> —— 代理镜像站的 /api/auth/session 响应体里
             根本不会出现它(不是前端藏起来:藏起来的话 F12 就能把平台客服从
             代理站页面里挖出去)。用不在直营名单里的域名/IP 自测时看不到它是
             <b>预期行为</b>。`
          : `当前<b>未启用站点分流</b>(「直营主站域名」为空)⇒ 全部域名都会展示。`)
      + `<br>★ 这里是<b>服务端收敛后的生效值</b>,不是参数中枢里的原始串 ——
      请逐字核对,这就是付费用户会照着复制的那一串。本项可热改,改完刷新本页复核。
    </p>`;
  }
  if (valDropped) {
    /* 「填了却没出现」是本组最难自查的状态 —— 必须点名成因与改法,
       而不是让运维对着一个空位反复怀疑是不是没生效。 */
    h += `<div class="err-line" style="margin-top:8px">
      ⚠ <b>客服号码/账号已被整条丢弃</b>:超过 ${lim.value || 64} 字符上限
      (当前 ${cs.valueRaw.length})。<b>刻意不截断</b> —— 一串被截短的号码会让用户
      照着抄却永远打不通,比没有号码更糟(与定制时长卡的 fail-closed 同一取向)。
      请到<a href="#/params" style="color:var(--brand)">参数中心</a>搜「客服」缩短它。
    </div>`;
  }
  if (dropped) {
    h += `<div class="err-line" style="margin-top:8px">
      ⚠ <b>在线客服链接已被整条丢弃</b>:<code>${esc(cs.urlRaw)}</code>
      ${cs.urlRaw.length > (lim.url || 256)
        ? `超过 ${lim.url || 256} 字符上限(当前 ${cs.urlRaw.length})—— 超长同样丢弃
           而不截断:被截短的 URL 会<b>通过</b>白名单却指向别处或 404,是一条看不出
           异常的坏链`
        : '不是合法的 http/https 绝对 URL(须带主机名)'},页面上<b>不会出现链接</b>(且不会报错)。
      只放行 <code>http://</code> / <code>https://</code> 开头且带主机名的地址 ——
      <code>javascript:</code> / <code>data:</code> 是注入面,而
      <code>mqqwpa://</code> / <code>weixin://</code> 这类深链在桌面浏览器点了
      毫无反应,属死控件。要放 QQ 临时会话/加群,请填对方给的 https 网页版链接。
    </div>`;
  }
  return h;
}
/* 小时 → 人话时长(与前端 app.js 的 durText 同口径:锚点是小叮当既有卡类型的
   recharge_length,月卡 744h / 季卡 2232h / 半年卡 4464h / 年卡 8928h)。
   管理台仍以**小时**为权威值展示,人话只作括注 —— 运维需要精确数。 */
function jvDur(hours) {
  const h = Math.round(Number(hours) || 0);
  if (h <= 0) return '—';
  if (h === 8928) return '1 年';
  if (h === 4464) return '半年';
  if (h % 744 === 0) return `${h / 744} 个月`;
  if (h % 24 === 0) return `${h / 24} 天`;
  return `${h} 小时`;
}
function jvTime(s) { return s ? String(s).replace('T', ' ').slice(0, 16) : '—'; }

/* 后端时间串('2026-07-25T00:00:00' / '2026-07-25 00:00:00')→ Date。
   刻意不塞时区后缀:后端用的是**库钟本地时刻**,补 Z 会平移 8 小时,
   预览就会比真实结果差一整天 —— 那比不给预览更糟。 */
function jvParseTime(s) {
  const t = String(s || '').replace('T', ' ').trim();
  const m = t.match(/^(\d{4})-(\d{2})-(\d{2})[ ]?(\d{2})?:?(\d{2})?:?(\d{2})?/);
  if (!m) return null;
  return new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0));
}
function jvFmtDate(d) {
  if (!(d instanceof Date) || isNaN(d)) return '—';
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} `
       + `${p(d.getHours())}:${p(d.getMinutes())}`;
}

/* 档位 code → 给人看的整句。高危弹窗里出现的必须是「1 个月 ¥88.00」,
   而不是「m3」—— 代码是给数据库看的,运维按下确定前需要看到钱和时长。 */
/* ── 内联时长码(4.2.9)────────────────────────────────────────────────────────
   `@H<九法VIP小时>[D<小叮当小时>]` —— 「指定时长卡密」把时长直接编进 plan_code,
   于是这类卡的档位**不在** JV.plans 里(内联档位刻意不进价格表)。
   若不在前端也认这套语法,管理台会把每一张定制卡都渲染成
   「@H720D720(该档位已不在配置表中)」—— 那是一句**假话**:档位没丢,是它
   压根就不该在配置表里。谎报比不报危险,故本函数与后端 jfvip.parse_inline()
   逐条对齐(上限 87600 亦同值,由 test_jfvip_hours_card 双向钉死)。 */
const JV_INLINE_MAX_HOURS = 87600;
const JV_INLINE_RE = /^@H(\d{1,6})(?:D(\d{1,6}))?$/;
function jvInline(code) {
  const m = JV_INLINE_RE.exec(String(code || '').trim());
  if (!m) return null;
  const jf = Number(m[1]), dd = Number(m[2] || 0);
  /* 上限在解析侧也钳一次(与后端同):手工改库塞进来的畸形码在后端会被
     fail-closed 拒兑,前端就不该把它显示成一张正常卡。 */
  if (!(jf > 0 && jf <= JV_INLINE_MAX_HOURS && dd <= JV_INLINE_MAX_HOURS)) return null;
  return {jfHours: jf, ddHours: dd, price: 0, inline: true,
          name: jvDur(jf) === '—' ? `定制 ${jf} 小时` : `定制 ${jvDur(jf)}`};
}

/* 档位码 → 一句话时长（CSV 与紧凑显示用）。认内联码，也认配置档位；
   都不认时回原码本身而不是空串 —— 导出文件里出现空格子会让人以为数据丢了。 */
/* 生成随机密钥并**一次性明示**。

   为什么必须明示而不是悄悄填进 password 框:这把密钥要交给发卡平台,而 sensitive
   输入框在本台是 type=password 且**重渲染后不回显**(密文不落 DOM,见 field 渲染
   的 B4 注释)。若只填进框里,运维点了「应用」之后就**再也看不到它了** ——
   然后他只能重新生成一次、再把对方的配置改一遍。一次性展示 + 复制按钮,
   是这个功能能用的前提,不是锦上添花。 */
async function genSecret(key, bytes) {
  /* crypto.getRandomValues:CSPRNG。**绝不用 Math.random** —— V8 的实现是
     xorshift128+,观察若干输出即可反推内部状态,拿它生成的"密钥"等于没有密钥。
     非安全上下文(http:// 且非 localhost)下 crypto 可能不可用,此时**拒绝生成**
     而不是回退 —— 悄悄给一把可预测的密钥,比不给这个按钮危险得多。 */
  if (!(window.crypto && window.crypto.getRandomValues)) {
    return toast('当前环境不提供安全随机源(需 HTTPS 或 localhost),'
               + '请改用 openssl rand -hex 32 自行生成', 'err');
  }
  const buf = new Uint8Array(Math.max(16, Math.min(64, Number(bytes) || 32)));
  window.crypto.getRandomValues(buf);
  const hex = Array.from(buf, b => b.toString(16).padStart(2, '0')).join('');
  const inp = $('[data-k="' + key + '"]');
  /* ★ 必须派发 **change** 而不是 input:参数卡的暂存逻辑监听的是 `change`
     (见本文件 el.addEventListener('change', …))。初版派发 input,后果是
     **生成的密钥根本没进暂存** —— 运维看到框里有值、弹窗里有明文,点「应用」
     却什么也没发生;他拿这把密钥去配发卡平台,每次调用都 401 bad_key,
     而管理台屏幕上零迹象。
     这条是**只有真实浏览器**测得出来的:jsdom 用例断言 inp.value 被写入 → 绿;
     静态扫描更看不到。admin_secret_browser.py 的「生成后参数卡进入暂存态」
     就是为这一条加的。 */
  const fire = el => el.dispatchEvent(new Event('change', {bubbles: true}));
  if (inp) { inp.value = hex; fire(inp); }
  /* 必须**一次性明示**:这把密钥要交给发卡平台,而本台的 sensitive 输入框是
     type=password 且重渲染后不回显(密文不落 DOM,见 field 渲染的 B4 注释)。
     只填进框里的话,点完「应用」就再也看不到它了 —— 运维只能重新生成一次、
     再把对方的配置改一遍。展示 + 复制是这个功能能用的前提,不是锦上添花。
     形态照搬邀请码那处已验证的范式(textarea + 显式复制 + execCommand 兜底)。 */
  const pr = ask({
    title: '已生成新密钥', yes: '我已复制,继续',
    html: '<p class="mut" style="margin:0 0 8px">这是<b>唯一一次</b>能看到它的机会 ——'
        + ' 本台敏感项不回显。</p>'
        + '<textarea id="gsOut" rows="2" readonly spellcheck="false"'
        + ' style="width:100%;font-family:ui-monospace,monospace;word-break:break-all">'
        + esc(hex) + '</textarea>'
        + '<div class="row" style="gap:8px;margin-top:8px">'
        + '<button class="btn" id="gsCopy">复制到剪贴板</button></div>'
        + '<p class="mut" style="margin:10px 0 0">① 先把它配到发卡平台;② 再回来点「应用」。<br>'
        + '⚠ 应用后<b>旧密钥立即失效</b>,仍在用旧密钥的调用方会收到 <code>401 bad_key</code>。</p>'});
  const cb = $('#gsCopy');
  if (cb) cb.onclick = async () => {
    try { await navigator.clipboard.writeText(hex); toast('密钥已复制到剪贴板'); }
    catch (_) {
      try { $('#gsOut').select(); document.execCommand('copy'); toast('已复制(兼容模式)'); }
      catch (__) { toast('复制失败 —— 请在文本框内手动全选复制', 'err'); }
    }
  };
  /* 取消 = 撤销暂存。运维点「取消」的语义是"我没拿到这把密钥",此时若把它留在
     暂存区,他下次点「应用」就会把一把自己没有的密钥推上生产,发卡平台当场全挂。 */
  if (!await pr && inp) { inp.value = ''; fire(inp); }   // 同上:change 才撤销暂存
}

document.addEventListener('click', e => {
  /* 参数卡会整片重绘,逐个绑事件会在重绘后失效 —— 用 document 级委托。
     与本文件既有的 [data-copy] 委托同款(见 807 行附近)。 */
  const b = e.target.closest && e.target.closest('.sec-gen');
  if (b) { e.preventDefault(); return genSecret(b.dataset.gen, b.dataset.bytes); }
  const r = e.target.closest && e.target.closest('.sec-rev');
  if (r) { e.preventDefault(); revealSecret(r.dataset.rev); }
});

/* 取回并展示某个敏感项的明文。每次都打后端(不缓存)——
   缓存等于把明文留在前端内存里,而这里的全部意义就是「要看的时候才有」。 */
async function revealSecret(key) {
  let d;
  try { d = await api('/config/reveal', {method: 'POST', body: JSON.stringify({key})}); }
  catch (e) { return toast(errText(e, '取回明文失败'), 'err'); }
  if (d.value == null) {
    /* 值来自 ENV/默认,或 Redis 重启丢了运行时真值。诚实说清楚,
       而不是显示一个空串让人以为"密钥是空的"。 */
    return ask({title: '本台没有该项的明文', yes: '知道了',
                body: d.message || '当前生效值来自环境变量或默认,请到部署侧查看。'});
  }
  const pr = ask({
    title: '当前密钥明文', yes: '关闭',
    html: '<p class="mut" style="margin:0 0 8px">本次查看已记入审计'
        + (d.auditOk === false ? '(<b style="color:var(--seal)">审计写入失败</b>)' : '')
        + ' —— 谁在什么时候看过这把密钥是可追溯的。</p>'
        + '<textarea id="rvOut" rows="2" readonly spellcheck="false"'
        + ' style="width:100%;font-family:ui-monospace,monospace;word-break:break-all">'
        + esc(d.value) + '</textarea>'
        + '<div class="row" style="gap:8px;margin-top:8px">'
        + '<button class="btn" id="rvCopy">复制到剪贴板</button></div>'});
  const cb = $('#rvCopy');
  if (cb) cb.onclick = async () => {
    try { await navigator.clipboard.writeText(d.value); toast('密钥已复制到剪贴板'); }
    catch (_) {
      try { $('#rvOut').select(); document.execCommand('copy'); toast('已复制(兼容模式)'); }
      catch (__) { toast('复制失败 —— 请在文本框内手动全选复制', 'err'); }
    }
  };
  await pr;
}

function jvPlanDur(code) {
  const p = jvInline(code) || (JV.plans || []).find(x => x.code === code);
  if (!p) return String(code || '');
  return `VIP ${p.jfHours}h(${jvDur(p.jfHours)}) + 小叮当 ${p.ddHours}h`;
}

/* 表格里的「档位」单元格。
   ★ 4.3.0 实地核查缺陷:卡密 / 订单 / 开通流水**三张表**的档位列一直是
     `esc(r.plan)` 直出原码 —— 屏幕上只有 `m3` `y1` `@H720D720`。
     而同一页的概览表用的是 `月卡 (m1)`,CSV 导出更专门加了一列人话时长,
     那处注释还写着「档位列逐字可回溯、时长列给人看的派生值,**两者都要**」——
     同一条道理,屏幕上却只给了机器看的那一列。小白根本认不出 m3 是季卡、
     @H720D720 是 30 天,而这三张表正是他最常盯的地方。
   形态照抄概览已有的 `名称 + 灰括注原码`:人话在前、原码仍在,逐字可回溯,
   不牺牲对账时「屏幕与库里一个字都能对上」的要求。
   认不出的码(档位被删/脏数据)**原样回码**,绝不编一个名字 —— 谎报比不报危险。 */
function jvPlanCell(code) {
  const c = String(code || '');
  if (!c) return '';
  const p = jvInline(c) || (JV.plans || []).find(x => x.code === c);
  if (!p) return esc(c);
  return `${esc(p.name)}<span class="mut"> (${esc(c)})</span>`;
}

function jvPlanText(code) {
  const inl = jvInline(code);
  const p = inl || (JV.plans || []).find(x => x.code === code);
  if (!p) return `${code}(该档位已不在配置表中)`;
  return `${p.name}${inl ? ' · 定制' : ` · ${jvMoney(p.price)}`}`
       + ` · 九法VIP ${p.jfHours}h(${jvDur(p.jfHours)})`
       + ` + 赠小叮当 ${p.ddHours}h(${jvDur(p.ddHours)})`;
}

/* GET 端点在关闭态回 HTTP 200 + ok:false(见 admin_api.py:1233/1280/1294/1304),
   api() 因 r.ok 为真而不抛 —— 若不显式拦,前端会把失败当成功渲染。 */
function jvGuard(d) {
  if (d && d.ok === false) throw {status: 200, data: d};
  return d;
}

/* ── CSV:RFC 4180 转义 + 公式注入防护 ────────────────────────────────────────
   初版直接 `[...].join(',')`:批次名「渠道A,华南」或用户名含逗号就**整行错列**
   (实测表头 7 列 / 数据行 8 列),而对账文件错列比没有文件更危险。
   另:以 = + - @ 或制表/回车开头的单元格会被 Excel/WPS 当公式执行
   (CSV injection),用户名与备注都可能带 —— 统一前置单引号钝化。 */
function jvCsvCell(v) {
  let s = v === null || v === undefined ? '' : String(v);
  /* ★ 复审自查修补(第二轮收窄):不得钝化**纯数值**,但豁免只给负号。
     · 必须放行:撤销流水的 jf_hours 落库为负(revoke_by_admin 传 -abs(hours)),
       若写成 `'-240` Excel 当文本 —— 运维在**唯一对账口径**上做 SUM 会把
       全部撤销行悄悄漏掉,账直接对错。
     · 不放行 `+` 开头:本表所有数值字段都不会产出 `+` 前缀
       (String(744)==='744'、String(-240)==='-240'),而 `+8613800138000`
       这种手机号型用户名是真实存在的 —— 放行会被 Excel 求值、吃掉那个加号。 */
  const isNum = s !== '' && /^-?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(s);
  if (!isNum && /^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
function jvCsv(head, rows) {
  return '\ufeff' + [head.map(jvCsvCell).join(',')]
    .concat(rows.map(r => r.map(jvCsvCell).join(','))).join('\r\n');
}

/* 导出必须覆盖**全部命中行**,不是当前页。
   初版按钮写「导出本批」却只导当前 50 条:发卡单批上限 500,运维把 50 条当
   整批交给渠道,静默少 450 张 —— 且文件里毫无迹象。
   这里按 size=500 逐页取满(后端 size 上限即 500),取数期间禁用按钮并报进度。 */
/* 超限时该让人「按什么收窄」—— 必须是**当前页签真有的**那几个条件。
   ★ 4.3.0 实地核查缺陷:这句提示原先三个页签硬编码共用「请先按批次/状态收窄」,
     而开通流水页**批次和状态一个都没有**(它此前只有「来源」一个下拉)。
     实测复现:命中 9000 条时导出被拒,提示指向两个不存在的控件,而仅有的
     4 个来源值根本压不到 5000 以下 ⇒ **唯一对账口径无法导出且无补救路径**。
     根治靠本轮给流水页补上的时间区间(见 JV.grants 注),这句文案则跟着
     按页签给出真实可用的维度 —— 指着一个不存在的旋钮让人去拧,比不给提示更坏。 */
const JV_NARROW_HINT = {
  '卡密': '请先按批次 / 状态 / 档位 / 卡号前缀收窄再导出',
  '订单': '请先按下单日期区间 / 状态 / 用户名收窄再导出',
  '流水': '请先按发生日期区间(建议按月)收窄再导出',
};

async function jvFetchAll(buildUrl, label) {
  const first = jvGuard(await api(buildUrl(1, JV_BULK)));
  const total = Number(first.total || 0);
  if (total > JV_EXPORT_CAP) {
    toast(`命中 ${total} 条,超过单次导出上限 ${JV_EXPORT_CAP} 条 —— `
          + (JV_NARROW_HINT[label] || '请先收窄筛选条件再导出'), 'err');
    return null;
  }
  let items = (first.items || []).slice();
  const pages = Math.ceil(total / JV_BULK);
  for (let p = 2; p <= pages; p++) {
    toast(`正在取${label}… ${items.length}/${total}`);
    const d = jvGuard(await api(buildUrl(p, JV_BULK)));
    items = items.concat(d.items || []);
  }
  /* ★ 复审自查:后端一律 ORDER BY id DESC。取数期间若有人发新卡/下新单,
     新行占据 page 1,其后整体下移一位 ⇒ **页边界那条会被取两遍**。
     导给渠道的卡密表里出现重复行,是会真的多发货的。按 id 去重兜底 ——
     比改后端上 keyset 分页便宜得多,效果一样。 */
  const seen = new Set();
  items = items.filter(r => {
    const k = r && r.id !== undefined ? r.id : JSON.stringify(r);
    if (seen.has(k)) return false;
    seen.add(k); return true;
  });
  return {items, total};
}

/* 空态:total=0 时若只留一排孤零零的表头,新人无法区分「真没有」与「没查对」。 */
function jvEmptyRow(cols, text) {
  return `<tr><td colspan="${cols}" class="jv-empty">${esc(text)}</td></tr>`;
}

async function renderJfvip() {
  const m = $('#main');
  /* 页签切换不经 switchView(它才调 clearTimers),必须自行收摊。
     ★ 复审自查修补:此前只 clearInterval,旧 id 仍留在 S.timers 里 ——
     概览每 30 秒重绘一次就多一条,一直开着页面数组只增不减。
     clearInterval 对陈旧 id 无害,但数组该清就得清。 */
  if (JV._timer) {
    clearInterval(JV._timer);
    S.timers = S.timers.filter(t => t !== JV._timer);
    JV._timer = 0;
  }
  m.innerHTML = '<div class="card"><div class="mut">载入中…</div></div>';
  let ov;
  try { ov = jvGuard(await api('/jfvip/overview')); }
  catch (e) { m.innerHTML = '<div class="card"><div class="err">载入失败:'
                             + esc(errText(e, '无法读取九法VIP 概览,请稍后重试'))
                             + '</div></div>'; return; }
  if (!ov.enabled) {
    /* 4.2.1:显示**具体原因**。此前只说"未启用",运维把开关设成 true 后看到
       同一句话,无从判断是没重启、还是登录系统没配 —— 真机反馈的正是这一类。 */
    const REASON = {
      switch_off: ['总开关未开 / 或改了还没重启',
        '① 在<a href="#/params" style="color:var(--brand)">参数中心</a>把 '
        + '<code>userauth.jf_vip_enabled</code> 设为 true(高危项,改完需重启 web);<br>'
        + '② 它是 <b>🔴 重启级</b>参数 —— 保存后<b>必须重启 web</b>:'
        + '<code>deploy-maxxiang.sh restart</code> 或 <code>docker compose restart web</code>;<br>'
        + '③ 重启后在 web 日志里应看到 <code>[九法VIP] 已启用</code> 横幅。'],
      login_off: ['登录系统未配置',
        '九法VIP 以登录身份作为档位载体 —— 没有登录就没有档位。'
        + '请先在 <code>.env</code> 配齐 <code>STA_USERDB_HOST / _NAME / _USER / _PASSWORD</code> '
        + '并重建 web。<b>在此之前把开关设成 true 不会有任何效果。</b>'],
      no_driver: ['缺少 aiomysql 依赖', '重建 web 镜像即可(requirements.txt 已包含)。'],
      not_inited: ['web 进程尚未完成初始化', '稍候刷新;若持续如此请看 web 日志。'],
    };
    const [title, how] = REASON[ov.reason] || ['九法VIP 未启用', ''];
    m.innerHTML = '<div class="card"><h3>九法VIP 未启用 —— ' + esc(title) + '</h3>'
      + (ov.message ? '<p class="mut">' + esc(ov.message) + '</p>' : '')
      + (how ? '<div class="mut" style="line-height:1.9">' + how + '</div>' : '')
      + '<p class="mut" style="margin-top:10px">开启前请先在部署机跑实机预检'
      + '(三项任一不过就不要开):<br>'
      + '<code>docker compose run --rm web python3 scripts/userdb_check.py --jfvip-preflight</code></p>'
      + '</div>';
    return;
  }
  const plans = ov.plans || [];
  JV.plans = plans;
  const byPlan = ov.byPlan || {};
  const noPlans = plans.length === 0;
  const TABS = [['overview', '概览'], ['cards', '卡密'], ['orders', '订单'],
                ['grants', '开通流水'], ['user', '用户']];
  m.innerHTML = `
    <div class="card">
      <div class="row jv-tabs" role="tablist" aria-label="九法VIP 视图" style="gap:8px;flex-wrap:wrap;align-items:center">
        ${TABS.map(([k, n]) => { const on = JV.tab === k;
            return `<button class="btn${on ? ' primary' : ''}" role="tab" id="jvTab-${k}"`
                 + ` aria-selected="${on}" aria-controls="jvBody" tabindex="${on ? 0 : -1}"`
                 + ` data-jv="${k}">${on ? '● ' : ''}${n}</button>`; }).join('')}
        <span class="spacer" style="flex:1"></span>
        <button class="btn ghost" id="jvReload" aria-label="重新读取当前页数据"
                title="重新读取">↻ 刷新</button>
      </div>
    </div>
    ${noPlans ? `<div class="card"><div class="warn-line"><span>⚠</span><span>
        <b>档位表为空</b> —— 后端 <code>jf_vip_plans</code> 解析失败或未配置时会 fail-safe 回空表。
        此时<b>按档位发卡与手动开通都会失败</b>(后端回 <code>bad_plan</code>),前台也看不到价格卡。
        <b>「⏱ 指定时长」发卡不受影响</b> —— 它的时长写在卡自己身上,不查档位表。<br>
        请到<a href="#/params" style="color:var(--brand)">参数中心</a>搜 <code>jf_vip_plans</code>
        修正 JSON 后重试;若刚改过,注意它走变更工作台、需应用生效。
      </span></div></div>` : ''}
    <div id="jvBody" role="tabpanel" tabindex="0"
         aria-labelledby="jvTab-${JV.tab}"></div>`;
  const tabBtns = $$('[data-jv]');
  tabBtns.forEach(b => b.addEventListener('click', () => {
    JV.tab = b.dataset.jv; renderJfvip();
  }));
  /* ★ 复审自查修补:光声明 role=tab 而不实现键盘模式,比用朴素 <button> 更糟 ——
     读屏会播报「选项卡 1/5,可用方向键切换」,而方向键**按了没反应**。
     此处补齐 WAI-ARIA APG 的 tablist 模式:← → 循环移动、Home/End 跳首尾,
     配合上面的 roving tabindex(仅选中项 tabindex=0)让 Tab 键一次跳过整组。 */
  $('.jv-tabs').addEventListener('keydown', e => {
    const i = tabBtns.indexOf(e.target);
    if (i < 0) return;
    const K = {ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: tabBtns.length - 1};
    if (!(e.key in K)) return;
    e.preventDefault();
    const n = (K[e.key] + tabBtns.length) % tabBtns.length;
    /* ★ 真实浏览器实测修补:不能只 focus() 再 click() —— click 会触发
       renderJfvip(),整段 innerHTML 重写会**把刚聚焦的按钮直接销毁**,
       焦点掉回 document,后续方向键全部失灵(键盘用户一按就出不来)。
       jsdom 测不出这个:它的 activeElement 回退与真实浏览器不同,
       而按 textContent 包含判断更是必然假阳性(body 的文本当然含「卡密」)。
       改为置标志位,由重绘后的收尾统一把焦点还给新的选中项。 */
    JV._refocus = true;
    tabBtns[n].click();
  });
  $('#jvReload').addEventListener('click', () => renderJfvip());
  if (JV._refocus) {                    // 键盘切换过来的:焦点跟着选中项走(APG 自动激活模式)
    JV._refocus = false;
    const cur = $(`[data-jv="${JV.tab}"]`);
    if (cur) cur.focus();
  }
  const body = $('#jvBody');

  if (JV.tab === 'overview') {
    /* 后端 overview() 每段统计都裹 contextlib.suppress —— 查询挂了 key 直接缺席,
       前端 `?? 0` 会把它渲染成「今日金额 ¥0.00」,与**真的一分没卖**完全无法区分。
       4.2.5 起后端回 degraded[],这里据此把失败项显示为「?」并挂降级横幅。 */
    const deg = new Set(ov.degraded || []);
    const num = (k, v) => deg.has(k) ? '?' : v;
    body.innerHTML = `
      ${deg.size ? `<div class="card"><div class="err-line">
        ⚠ <b>部分统计取数失败</b>(${esc([...deg].join('、'))})—— 下方标「?」的格子
        <b>不是 0,是没读到</b>。请查 web 日志确认用户库连通性后点右上角「↻ 刷新」。
      </div></div>` : ''}
      <div class="card">
        <h3>经营概览</h3>
        <div class="kpis">
          <div class="kpi"><b>${num('vipAlive', ov.vipAlive ?? '—')}</b><span>VIP 在期人数</span></div>
          <div class="kpi"><b>${num('today', (ov.today || {}).grants ?? 0)}</b><span>今日开通</span></div>
          <div class="kpi"><b>${num('today', jvMoney((ov.today || {}).amount))}</b><span>今日金额</span></div>
          <div class="kpi"><b>${num('week', (ov.week || {}).grants ?? 0)}</b><span>7 日开通</span></div>
          <div class="kpi"><b>${num('week', jvMoney((ov.week || {}).amount))}</b><span>7 日金额</span></div>
          <div class="kpi"><b>${num('cardsUnused', ov.cardsUnused ?? 0)}</b><span>未使用卡密</span></div>
          <div class="kpi"><b>${num('freeVisits7d', ov.freeVisits7d ?? 0)}</b><span>7 日 free 档到访</span></div>
        </div>
        <p class="mut" style="margin-top:10px">
          「free 档到访」= 小叮当已到期的用户登录进来看开通页的次数
          (审计 reason=ok_free/sso_free),是转化漏斗的左端。本页每 30 秒自动刷新。
        </p>
        ${(ov.site && (ov.site.directHosts || []).length) ? `<p class="mut" style="margin-top:8px">
          🌐 <b>站点分流已启用</b> · 直营主站 ${(ov.site.directHosts || []).length} 个:
          <b>${esc((ov.site.directHosts || []).join('、'))}</b> ——
          其余任何域名一律按<b>代理镜像站</b>(隐藏在线扫码与档位价格卡,仅卡密开通,
          下单端点拒单)。站点身份取自
          ${ov.site.trustXfh ? '<b>X-Forwarded-Host 首跳</b>(缺失回落 Host)' : '<b>Host 头</b>'}。
          <br>★ 这里显示的是<b>服务端解析后的生效值</b>,不是参数中枢里的原始串 ——
          本项可热改,改完刷新本页即可复核是否漏写 www / 混入多余字符
          (启动横幅只在开机时打一次,热改后这里是唯一的运行时读数)。
        </p>` : ''}
        ${jvCsHtml(ov)}
      </div>
      <div class="card">
        <h3>档位与销量</h3>
        <table class="tbl"><thead><tr><th>档位</th><th>价格</th><th>九法VIP</th>
          <th>赠送小叮当</th><th>累计售出</th></tr></thead><tbody>
          ${noPlans ? jvEmptyRow(5, '档位表为空 —— 见上方提示,请先修正 jf_vip_plans')
            : plans.map(p => `<tr><td>${esc(p.name)}<span class="mut"> (${esc(p.code)})</span></td>
            <td>${jvMoney(p.price)}</td><td>${p.jfHours}h(${jvDur(p.jfHours)})</td>
            <td>${p.ddHours}h(${jvDur(p.ddHours)})</td>
            <td>${deg.has('byPlan') ? '?' : (byPlan[p.code] || 0)}</td></tr>`).join('')}
          <!-- 定制时长卡不在档位表里（内联档位刻意不进价格表），但它确实卖出去了。
               不给这一行的话，「档位与销量」会把定制卡的销量整个吞掉 —— 后端算了、
               前端一行都不显示，是个"看不见的洞"。合计由后端聚合（键 customGrants），
               而不是前端去数 byPlan 里以 @ 开头的键：那些键数量无上限。 -->
          <tr><td>定制时长<span class="mut"> (@H…)</span></td>
            <td class="mut">不计入金额</td><td class="mut">按卡指定</td>
            <td class="mut">按卡指定</td>
            <td>${deg.has('byPlan') ? '?' : (ov.customGrants || 0)}</td></tr>
        </tbody></table>
        <p class="mut" style="margin-top:8px">
          改价/改时长请去<a href="#/params" style="color:var(--brand)">参数中心</a>
          搜 <code>jf_vip_plans</code>(走变更工作台,rev 收敛广播)。
          ⚠ <b>code 一经售出不可删除</b> —— 历史订单靠它解释;卡密对应档位被删时兑换会 fail-closed。
        </p>
      </div>`;
    /* 概览页无任何输入框,定时重绘不会吞掉运维正在敲的字;其余页签一律不自动刷新。 */
    JV._timer = setInterval(() => { if (S.view === 'jfvip' && JV.tab === 'overview') renderJfvip(); }, 30000);
    S.timers.push(JV._timer);
    return;
  }

  if (JV.tab === 'cards') {
    /* ★ 第五轮复审实测缺陷(**原始版即有**,本轮把触发面从 3 个条件扩到 10 个):
       URL 构造器闭包读的是 `JV.cards` **对象本身**,而 doQuery() 是就地改它。
       导出要逐页取满(单次上限 5000 行 = 10 个来回),期间运维若改筛选点「查询」,
       后半段就用**新条件**取数 —— CSV 变成两套条件的混合物,而文件名、行数
       全都看不出异常。真浏览器实测复现:第 1 页无筛选、第 2/3 页带 userName=bob。
       对账文件出这种事比没有文件更危险(项目在 CSV 转义那处写过同一句话)。
       改法:构造器接受状态对象,列表用活引用、**导出用冻结快照**。 */
    const mkCardsUrl = c => (page, size) => `/jfvip/cards?page=${page}&size=${size}`
      + `&batch=${encodeURIComponent(c.batch)}`
      + `&status=${encodeURIComponent(c.status)}`
      + `&plan=${encodeURIComponent(c.plan)}`
      + `&card=${encodeURIComponent(c.card || '')}`;
    const cardsUrl = mkCardsUrl(JV.cards);
    let d;
    try { d = jvGuard(await api(cardsUrl(JV.cards.page, JV.cards.size || JV_PAGE))); }
    catch (e) { JV._refocusPager = '';        // 同上:翻页失败后不得把标志留给下一次渲染
                body.innerHTML = '<div class="card"><div class="err">'
                                 + esc(errText(e, '卡密列表读取失败')) + '</div></div>'; return; }
    /* ★ 复审自查修正:初版在**每次渲染**都拉一次带三态计数的批次枚举。
       真库实测(MariaDB 10.11 / 40 万行 / 800 批次)那条 GROUP BY 扫 400,000 行,
       等于每翻一页都付一次全表级开销 —— 与本项目设立 _count_capped 要避免的
       是同一件事。现在拆成两条:
         · 批次名清单:**惰性**,只在运维点「载入批次清单」时拉一次并缓存(100,000 行);
         · 三态计数:只查**当前筛选的那一个批次**(实测 500 行,idx_batch 直击),
           而那正是唯一需要它的时刻 —— 已选定某批、正要对它做「作废整批」。 */
    const batches = JV.cards._batches || [];
    let bStat = null;
    if (JV.cards.batch) {
      try { bStat = (await api('/jfvip/cards/batches?batch='
              + encodeURIComponent(JV.cards.batch))).stat || null; }
      catch (e) { bStat = null; }
    }
    const scope = JV.cards.batch ? `批次「${JV.cards.batch}」` : '当前筛选';
    /* ★ 复审补:卡密页此前**没有**消费 totalCapped —— 后端已给三张表统一封顶,
       而这里仍把 50000 当精确值渲染成「共 50000 张」。那正是我在分页器注释里
       写过「谎报一个精确总数比显示 50000+ 危险得多」的同一件事,却在三个页签里
       漏了一个。单批发卡上限 500,一百个批次就够到上限,并非够不着的极端值。 */
    const cTotal = Number(d.total) || 0;
    const cCapped = !!d.totalCapped;
    const items = d.items || [];
    /* 删除总开关(userauth.jf_card_purge_enabled)默认关。前端如实反映它 ——
       否则运维会走完整套「选中 → 键入 DELETE」的仪式,最后才被 403 打回,
       而那恰恰会把二次确认训练成条件反射。 */
    const purgeOn = !!ov.purgeEnabled;
    /* 选择集按 **id** 存,不挂 DOM —— 重绘/翻页后不丢。
       4.2.8:后端 cards_disable(ids=) 早就支持按 id 精确操作、admin_api 也一直
       在透传,但前端**从来没有勾选框**,这条通路等于不存在(与本项目当年抓到
       并修掉的 undo 缺陷是同一函数同一行的同类问题)。本轮接出来。 */
    if (!JV.cards.sel) JV.cards.sel = new Set();
    if (!JV.cards.selMeta) JV.cards.selMeta = new Map();
    const sel = JV.cards.sel;
    /* ★ 复审自查揪出的**我自己引入**的缺陷:初版删除时
         ids  = [...sel]                        ← 跨页全部
         rows = items.filter(c => sel.has(c.id)) ← **仅当前页**
       于是确认框里的数字、以及删除前强制下载的存档 CSV,都只覆盖当前页,
       而实际删除的是跨页全部。存档与实删范围不一致 —— 而存档的全部意义
       就是覆盖被删的那些行。
       改法:选中时把整行数据一并记进 selMeta,取消时移除。这样预检与存档
       无论翻到哪一页都拿得到完整数据,且不必再打一次库(那反而可能取到
       与所见不一致的快照)。 */
    const selMeta = JV.cards.selMeta;
    for (const c of items) if (sel.has(c.id)) selMeta.set(c.id, c);   // 回填/刷新本页
    const onPage = items.map(c => c.id);
    const selOnPage = onPage.filter(id => sel.has(id));
    const stTag = c => c.used ? (c.disabled
        ? '<span class="tag warn">异常态</span>' : '<span class="tag">已使用</span>')
      : c.disabled ? '<span class="tag warn">已作废</span>'
                   : '<span class="tag ok">未使用</span>';
    body.innerHTML = `
      <div class="card">
        <h3>发卡</h3>
        <div class="row" style="gap:8px;flex-wrap:wrap;align-items:center">
          <select id="jvGenPlan" aria-label="发卡档位">
            ${noPlans ? '<option value="" disabled>(档位表为空)</option>'
              : plans.map(p => `<option value="${esc(p.code)}">${esc(p.name)} ${jvMoney(p.price)} · ${jvDur(p.jfHours)}</option>`).join('')}
            <option value="__hours__"${noPlans ? ' selected' : ''}>⏱ 指定时长(自定义)</option>
          </select>
          <input id="jvGenN" type="number" min="1" max="500" value="10" style="width:90px"
                 aria-label="发卡张数(1–500)" placeholder="张数">
          <input id="jvGenBatch" placeholder="批次号(留空自动)" style="width:170px"
                 maxlength="32" aria-label="批次号,留空则自动生成">
          <input id="jvGenNote" placeholder="备注" style="width:150px"
                 maxlength="100" aria-label="批次备注">
          <button class="btn primary" id="jvGenBtn">生成</button>
          <span class="mut">单批 ≤500</span>
        </div>
        <!-- 指定时长行:默认隐藏,选中「指定时长」才出现。刻意不做成第二个面板 ——
             两个发卡入口并排摆着,运维迟早会在其中一个里填好参数、去另一个点生成。 -->
        <div class="row" id="jvGenHoursRow" hidden
             style="gap:8px;flex-wrap:wrap;align-items:center;margin-top:8px">
          <input id="jvGenHours" type="number" min="1" max="${JV_INLINE_MAX_HOURS}"
                 value="720" style="width:120px" placeholder="九法VIP 小时"
                 aria-label="九法VIP 时长(小时,1–${JV_INLINE_MAX_HOURS})">
          <span class="mut" id="jvGenHoursHint">= 30 天</span>
          <label style="display:inline-flex;align-items:center;gap:4px">
            <input type="checkbox" id="jvGenDdSame" checked>
            <span>同时赠送等量小叮当时长</span>
          </label>
          <input id="jvGenDd" type="number" min="0" max="${JV_INLINE_MAX_HOURS}"
                 value="0" style="width:120px" placeholder="小叮当 小时" hidden
                 aria-label="赠送小叮当时长(小时,0=不赠)">
          <span class="mut">档位码将写成 <code id="jvGenCode">@H720D720</code>,
            不进档位表、不上前台价格卡</span>
        </div>
      </div>
      <div class="card">
        <div class="row" style="gap:8px;flex-wrap:wrap;align-items:center">
          <input id="jvCardNo" placeholder="按卡号搜索(前缀)" value="${esc(JV.cards.card || '')}"
                 style="width:190px" maxlength="32" aria-label="按卡号前缀搜索,回车即查询">
          <input id="jvCardBatch" placeholder="按批次筛选" value="${esc(JV.cards.batch)}"
                 style="width:170px" maxlength="32" list="jvBatchList"
                 aria-label="按批次号筛选,可从清单选择,回车即查询">
          <datalist id="jvBatchList">
            ${batches.map(b => `<option value="${esc(b.batch)}"></option>`).join('')}
          </datalist>
          <select id="jvCardStatus" aria-label="按卡密状态筛选">
            ${[['', '全部'], ['unused', '未使用'], ['used', '已使用'], ['disabled', '已作废'],
               ['orphan', '异常态(需核对)']]
              .map(([v, n]) => `<option value="${v}"${JV.cards.status === v ? ' selected' : ''}>${n}</option>`).join('')}
          </select>
          <select id="jvCardPlan" aria-label="按档位筛选">
            <option value="">全部档位</option>
            ${plans.map(p => `<option value="${esc(p.code)}"${JV.cards.plan === p.code ? ' selected' : ''}>${esc(p.name)}</option>`).join('')}
            <!-- 单独一个 '@' = 后端按 plan_code LIKE '@%' 筛全部定制时长卡。
                 不给这条通路的话,定制卡在本下拉里一个选项都没有(下拉数据源是
                 plans(),而内联档位刻意不在其中)—— 卡发得出去却筛不出来。 -->
            <option value="@"${JV.cards.plan === '@' ? ' selected' : ''}>⏱ 定制时长(全部)</option>
          </select>
          <button class="btn" id="jvCardQuery">查询</button>
          <button class="btn" id="jvCardBatchLoad"${batches.length ? ' disabled' : ''}>${batches.length ? `批次清单已载入 (${batches.length})` : '载入批次清单'}</button>
          <span class="spacer" style="flex:1"></span>
          <button class="btn" id="jvCardExport">导出全部命中 (${cTotal}${cCapped ? '+' : ''}) CSV</button>
        </div>
        <!-- ★ 4.3.0 可用性修补:此前「作废整批未用卡 / 恢复整批」与「作废选中 /
             恢复选中」四颗按钮挤在相邻两行,名字只差后缀两字,作用域却完全不同
             (整个批次 vs 屏幕上勾中的行),而其中一组通向不可逆链路。
             实测同屏 13 颗按钮、无任何分组标签。
             现在给两组各加一句**作用域前缀**,并把批次组单独成行、显式写出
             当前作用于哪个批次 —— 破坏性操作的作用域必须写在按钮旁边,
             而不是要人回头去看上面筛选框里填了什么。 -->
        <div class="row jv-scope" id="jvBatchBar">
          <span class="jv-scope-tag">按批次</span>
          <span class="mut">${JV.cards.batch
            ? `作用于批次「<b>${esc(JV.cards.batch)}</b>」的<b>全部未使用卡</b>`
            : '<b>请先在上方填写批次号并查询</b>,否则以下两颗按钮不可用'}</span>
          <button class="btn danger" id="jvCardDisable"${JV.cards.batch ? '' : ' disabled'}>作废整批未用卡</button>
          <button class="btn" id="jvCardRestore"${JV.cards.batch ? '' : ' disabled'}>恢复整批</button>
        </div>
        <div class="row jv-scope" id="jvSelBar">
          <span class="jv-scope-tag">按勾选</span>
          <span class="mut">已选 <b id="jvSelN">${sel.size}</b> 张</span>
          <button class="btn" id="jvSelClear"${sel.size ? '' : ' disabled'}>清空选择</button>
          <button class="btn danger" id="jvSelDisable"${sel.size ? '' : ' disabled'}>作废选中</button>
          <button class="btn" id="jvSelRestore"${sel.size ? '' : ' disabled'}>恢复选中</button>
          <button class="btn" id="jvSelNote"${sel.size ? '' : ' disabled'}>改备注</button>
          <button class="btn danger" id="jvSelPurge"${(sel.size && purgeOn) ? '' : ' disabled'}
                  title="${purgeOn ? '永久删除选中的卡(无需先作废,不可撤销)' : '删除能力未启用'}">删除选中</button>
          <span class="mut">${purgeOn
            ? '删除<b>直接生效、无需先作废</b>,未使用/已作废/已兑换一并删除,且<b>不可撤销</b>;'
              + '要可撤回的下架请改用「作废选中」'
            : '删除能力<b>未启用</b> —— 去<a href="#/params" style="color:var(--brand)">参数中心</a>搜 <code>jf_card_purge_enabled</code> 开启(🔴 高危项)'}</span>
        </div>
        ${cCapped ? `<div class="hint-line">命中数已达统计上限 <b>${cTotal}</b> 张并停止计数
          (显示为「${cTotal}+」)—— 这是为了不让每次翻页都全表数一遍。
          需要精确总数请按批次/状态收窄。</div>` : ''}
        ${bStat ? `<div class="hint-line">批次「${esc(JV.cards.batch)}」共
          <b>${bStat.total}</b> 张 · 未用 <b>${bStat.unused}</b>
          · 已用 <b>${bStat.used}</b> · 已作废 <b>${bStat.disabled}</b></div>` : ''}
        <p class="mut">共 ${cTotal}${cCapped ? '+' : ''} 张 · 第 ${Number(d.page) || 1} 页 · 导出按${esc(scope)}的全部命中行,不止本页</p>
        <table class="tbl"><thead><tr>
          <th style="width:30px"><input type="checkbox" id="jvSelAll" aria-label="全选本页"
              ${onPage.length && selOnPage.length === onPage.length ? 'checked' : ''}></th>
          <th>卡密</th><th>档位</th><th>批次</th><th>状态</th>
          <th>使用者</th><th>使用时间</th><th>备注</th></tr></thead><tbody>
          ${items.length ? items.map(c => `<tr>
            <td><input type="checkbox" class="jv-ck" data-id="${c.id}"
                 ${sel.has(c.id) ? 'checked' : ''} aria-label="选择卡 ${esc(c.card)}"></td>
            <td class="mono">${esc(c.card)}</td><td>${jvPlanCell(c.plan)}</td><td>${esc(c.batch)}</td>
            <td>${stTag(c)}</td>
            <td>${c.usedBy ? `<a href="#/jfvip" class="jv-uid" data-uid="${c.usedBy}"
                   style="color:var(--brand)" title="uid ${c.usedBy}">${esc(c.usedName || ('uid ' + c.usedBy))}</a>`
                 : '—'}</td><td>${jvTime(c.usedAt)}</td>
            <td>${esc(c.note || '')}</td></tr>`).join('')
            : jvEmptyRow(8, JV.cards.batch || JV.cards.status || JV.cards.plan || JV.cards.card
                ? '当前筛选条件下没有卡密 —— 试试清空批次号/卡号或把状态改回「全部」'
                : '还没有发过卡 —— 用上方「发卡」生成第一批')}
        </tbody></table>
        ${jvPager(d)}
      </div>`;
    jvBindPager(body, (p, size) => {
      JV.cards.page = p; if (size) JV.cards.size = size; renderJfvip();
    });
    jvRestorePagerFocus(body);

    /* ── 选择集绑定 ───────────────────────────────────────────────────────
       只更新计数与按钮禁用态,**不整段重绘** —— 重绘会把运维刚敲进筛选框的
       字吞掉(项目在概览页自动刷新那处写过同一条)。 */
    const syncSel = () => {
      const n = sel.size;
      const el = $('#jvSelN'); if (el) el.textContent = String(n);
      for (const id of ['jvSelClear', 'jvSelDisable', 'jvSelRestore', 'jvSelNote']) {
        const b = $('#' + id); if (b) b.disabled = !n;
      }
      const pb = $('#jvSelPurge'); if (pb) pb.disabled = !n || !purgeOn;
      const all = $('#jvSelAll');
      if (all) all.checked = !!onPage.length && onPage.every(i => sel.has(i));
    };
    /* 上限闸放在**加入选择集**这一步,而不是提交时截断 —— 后端对超限是显式
       拒绝(too_many),但更好的是运维在勾第 501 个时当场就知道,而不是选完
       一大片再被打回。JV_SEL_CAP 与后端 _MAX_IDS_PER_CALL 必须同值。 */
    const capReached = () => {
      if (sel.size < JV_SEL_CAP) return false;
      toast(`单次最多选 ${JV_SEL_CAP} 张 —— 请分批操作`, 'err');
      return true;
    };
    body.querySelectorAll('.jv-ck').forEach(ck => ck.addEventListener('change', e => {
      const t = e.currentTarget, id = Number(t.dataset.id);
      if (t.checked) {
        if (capReached()) { t.checked = false; return; }
        sel.add(id); selMeta.set(id, items.find(c => c.id === id));
      } else { sel.delete(id); selMeta.delete(id); }
      syncSel();
    }));
    const selAll = $('#jvSelAll');
    if (selAll) selAll.addEventListener('change', e => {
      const on = e.currentTarget.checked;
      for (const id of onPage) {
        if (on) {
          if (sel.has(id)) continue;
          if (capReached()) break;
          sel.add(id); selMeta.set(id, items.find(c => c.id === id));
        } else { sel.delete(id); selMeta.delete(id); }
      }
      body.querySelectorAll('.jv-ck').forEach(ck => {
        ck.checked = sel.has(Number(ck.dataset.id));
      });
      syncSel();
    });
    $('#jvSelClear').addEventListener('click', () => {
      sel.clear(); selMeta.clear();
      body.querySelectorAll('.jv-ck').forEach(ck => { ck.checked = false; }); syncSel();
    });
    /* 从卡跳到人:后端 4.2.8 起返回 usedBy(此前 SQL 一直取着 used_by,返回体却
       只映射成布尔的 used,uid 被丢掉 —— 用户名可重名可变更,当不了跳转锚点)。 */
    body.querySelectorAll('.jv-uid').forEach(a => a.addEventListener('click', e => {
      e.preventDefault();
      JV.tab = 'grants'; JV.grants.uid = Number(e.currentTarget.dataset.uid) || 0;
      JV.grants.page = 1; renderJfvip();
    }));

    /* ── 指定时长模式的联动 ─────────────────────────────────────────────────
       三件事必须实时可见,否则运维是在盲填:
         ① 小时数换算成人话(720 → 30 天)—— 「多打一个 0」在数字上看不出来,
            在「300 天」这三个字上一眼就看得出来;
         ② 最终落库的档位码(@H720D720)—— 它会出现在卡密列表与开通流水里;
         ③ 送不送小叮当。默认勾选「等量」是因为既有三档全是等量,但**后端默认
            是 0** —— 少送可补、多送收不回(revoke 明确不回收小叮当)。 */
    const jvGenIsHours = () => $('#jvGenPlan').value === '__hours__';
    const jvGenHoursVal = () => Number($('#jvGenHours').value || 0);
    const jvGenDdVal = () => $('#jvGenDdSame').checked
      ? jvGenHoursVal() : Number($('#jvGenDd').value || 0);
    const jvGenSync = () => {
      const on = jvGenIsHours();
      $('#jvGenHoursRow').hidden = !on;
      if (!on) return;
      const h = jvGenHoursVal(), dd = jvGenDdVal();
      $('#jvGenDd').hidden = $('#jvGenDdSame').checked;
      $('#jvGenHoursHint').textContent =
        (h >= 1 && h <= JV_INLINE_MAX_HOURS) ? `= ${jvDur(h)}` : '⚠ 超出范围';
      $('#jvGenCode').textContent = (h >= 1 && h <= JV_INLINE_MAX_HOURS)
        ? `@H${h}${dd > 0 ? `D${dd}` : ''}` : '—';
    };
    $('#jvGenPlan').addEventListener('change', jvGenSync);
    $('#jvGenDdSame').addEventListener('change', jvGenSync);
    for (const id of ['jvGenHours', 'jvGenDd']) {
      $('#' + id).addEventListener('input', jvGenSync);
    }
    jvGenSync();

    $('#jvGenBtn').addEventListener('click', async () => {
      const n = Number($('#jvGenN').value || 0);
      const plan = $('#jvGenPlan').value;
      /* ★ 4.3.1:张数同样必须判整数。后端 norm_count → _norm_int 拒绝浮点,
         回的是**不带 hint 的** `bad_count`,而 ERRTXT 此前没有这个码 ⇒
         运维会看到一个裸英文码 `bad_count`。实测 `{count:10.5, plan:'m1'}`
         确实走到这一步。前端补闸(说人话)+ ERRTXT 补码(兜底)两手都要。 */
      if (!(Number.isInteger(n) && n >= 1 && n <= 500)) {
        return toast('张数需为 1–500 之间的整数', 'err');
      }
      const hoursMode = jvGenIsHours();
      if (!hoursMode && !plan) {
        return toast('档位表为空,无法按档位发卡 —— 请改用「指定时长」'
                   + '或先修正 jf_vip_plans', 'err');
      }
      let payload, planText, faceValue;
      if (hoursMode) {
        const h = jvGenHoursVal(), dd = jvGenDdVal();
        if (!(Number.isInteger(h) && h >= 1 && h <= JV_INLINE_MAX_HOURS)) {
          return toast(`九法VIP 时长需为 1–${JV_INLINE_MAX_HOURS} 的整数小时`, 'err');
        }
        if (!(Number.isInteger(dd) && dd >= 0 && dd <= JV_INLINE_MAX_HOURS)) {
          return toast(`赠送小叮当时长需为 0–${JV_INLINE_MAX_HOURS} 的整数小时`, 'err');
        }
        payload = {count: n, hours: h, ddHours: dd};
        planText = `指定时长 · 九法VIP ${h}h(${jvDur(h)})`
                 + ` + 赠小叮当 ${dd}h(${dd > 0 ? jvDur(dd) : '不赠'})`
                 + `\n档位码:@H${h}${dd > 0 ? `D${dd}` : ''}`;
        /* 定制卡没有面值 —— 它不走网关,grant_log.amount 恒 0。这里如实写
           「不计入金额」,而不是算一个 ¥0.00 让人以为是免费档位。 */
        faceValue = '不计入经营看板金额(定制卡无网关流水)';
      } else {
        const p = plans.find(x => x.code === plan) || {price: 0};
        payload = {count: n, plan};
        planText = jvPlanText(plan);
        faceValue = jvMoney(n * (p.price || 0));
      }
      const yes = await ask({title: '确认发卡', danger: true, yes: '确认生成',
        body: `档位:${planText}\n数量:${n} 张\n`
            + `面值合计:${faceValue}\n\n`
            + '卡密一经生成即可被兑换。生成后会自动下载 txt,请妥善保管。'});
      if (!yes) return;
      try {
        const r = await api('/jfvip/cards/generate', {method: 'POST', body: JSON.stringify(
          Object.assign(payload, {batch: $('#jvGenBatch').value.trim(),
                                  note: $('#jvGenNote').value.trim()}))});
        toast(`已生成 ${r.count} 张 · ${r.planName || r.plan}(批次 ${r.batch})`);
        jvDownload(`jfvip-${r.batch}.txt`, (r.cards || []).join('\r\n'));
        JV.cards.batch = r.batch; JV.cards.status = ''; JV.cards.plan = ''; JV.cards.card = '';
        JV.cards.page = 1; sel.clear(); selMeta.clear(); renderJfvip();
      } catch (e) { toast(errText(e, '发卡失败'), 'err'); }
    });

    const doQuery = () => {
      JV.cards.batch = $('#jvCardBatch').value.trim();
      JV.cards.card = $('#jvCardNo').value.trim();
      JV.cards.status = $('#jvCardStatus').value;
      JV.cards.plan = $('#jvCardPlan').value;
      JV.cards.page = 1; renderJfvip();
    };
    $('#jvCardQuery').addEventListener('click', doQuery);
    /* 惰性载入批次清单:实测 100,000 行,不该在每次渲染时付。载入后缓存于
       JV.cards._batches,本次会话内不再重复拉。 */
    $('#jvCardBatchLoad').addEventListener('click', async e => {
      const btn = e.currentTarget; btn.disabled = true; btn.textContent = '载入中…';
      try {
        JV.cards._batches = (await api('/jfvip/cards/batches?limit=200')).items || [];
        toast(`已载入 ${JV.cards._batches.length} 个批次`); renderJfvip();
      } catch (err) {
        btn.disabled = false; btn.textContent = '载入批次清单';
        toast(errText(err, '批次清单载入失败'), 'err');
      }
    });
    // 回车即查询 —— 与用户页保持一致,别让人填完还得去找按钮
    for (const id of ['jvCardBatch', 'jvCardNo']) {
      $('#' + id).addEventListener('keydown', e => {
        if (e.key === 'Enter' && !e.isComposing) doQuery();
      });
    }
    $('#jvCardExport').addEventListener('click', async e => {
      const btn = e.currentTarget; btn.disabled = true;
      const snap = Object.assign({}, JV.cards);   // 冻结本次导出的筛选条件
      try {
        const all = await jvFetchAll(mkCardsUrl(snap), '卡密');
        if (!all) return;
        jvDownload(`jfvip-cards-${snap.batch || 'all'}-${all.items.length}.csv`,
          /* 「时长」是新增列而不是替换「档位」：档位列是库里 plan_code 的原值，
             对账时必须逐字可回溯；时长列是给人看的派生值。两者都要。 */
          jvCsv(['卡密', '档位', '时长', '批次', '状态', '使用者uid', '使用者', '使用时间', '备注', '发卡人', '发卡时间'],
            all.items.map(c => [c.card, c.plan, jvPlanDur(c.plan), c.batch,
              c.used ? (c.disabled ? '异常态' : '已使用') : c.disabled ? '已作废' : '未使用',
              c.usedBy || '', c.usedName || '', c.usedAt || '', c.note || '',
              c.createdBy || '', c.createdAt || ''])));
        toast(`已导出 ${all.items.length} 张`);
      } catch (err) { toast(errText(err, '导出失败'), 'err'); }
      finally { btn.disabled = false; }
    });

    const bulkDisable = async (undo) => {
      const b = JV.cards.batch;
      if (!b) return toast('请先在上方按批次筛选,再对该批操作', 'err');
      const m = bStat;
      const yes = await ask({title: undo ? '恢复整批' : '作废整批未使用卡', danger: !undo,
        yes: undo ? '确认恢复' : '确认作废',
        body: (m ? `批次「${b}」共 ${m.total} 张(未用 ${m.unused} / 已用 ${m.used} / 已作废 ${m.disabled})\n\n` : '')
          + (undo
          ? `将把批次「${b}」中已作废且**未被使用**的卡恢复为可用。\n`
            + '已兑换的卡不受影响。本操作可用「作废整批未用卡」再次撤回。'
          : `将把批次「${b}」中所有**未使用**的卡置为作废(已兑换的不受影响,`
            + '因为时长已经发出去了)。\n本操作可用同一行的「恢复整批」按钮撤回。')});
      if (!yes) return;
      try {
        const r = await api('/jfvip/cards/disable',
          {method: 'POST', body: JSON.stringify({batch: b, undo})});
        toast(r.affected ? `已${undo ? '恢复' : '作废'} ${r.affected} 张`
                         : `没有需要${undo ? '恢复' : '作废'}的卡(该批未使用卡均已是目标状态)`);
        renderJfvip();
      } catch (e) { toast(errText(e, undo ? '恢复失败' : '作废失败'), 'err'); }
    };
    $('#jvCardDisable').addEventListener('click', () => bulkDisable(false));
    $('#jvCardRestore').addEventListener('click', () => bulkDisable(true));

    /* ── 按 id 的选中操作(4.2.8 把后端既有能力接出来)───────────────────── */
    const selDisable = async (undo) => {
      const ids = [...sel];
      if (!ids.length) return;
      const yes = await ask({title: undo ? '恢复选中' : '作废选中', danger: !undo,
        yes: undo ? '确认恢复' : '确认作废',
        body: `将对选中的 ${ids.length} 张卡执行${undo ? '恢复' : '作废'}。\n`
            + '只对**未使用**的卡生效,已兑换的会被后端跳过。\n本操作可逆。'});
      if (!yes) return;
      try {
        const r = await api('/jfvip/cards/disable',
          {method: 'POST', body: JSON.stringify({ids, undo})});
        /* 请求数与生效数不等时必须给出确切解释 —— 静默的数量差异比报错危险得多
           (项目在 _count_capped / CSV 导出 / 概览降级三处写过同一条原则)。 */
        toast(r.affected === ids.length
          ? `已${undo ? '恢复' : '作废'} ${r.affected} 张`
          : `请求 ${ids.length} 张,实际${undo ? '恢复' : '作废'} ${r.affected} 张 —— `
            + `其余为已兑换卡,状态不可改`);
        sel.clear(); selMeta.clear(); renderJfvip();
      } catch (e) { toast(errText(e, '操作失败'), 'err'); }
    };
    $('#jvSelDisable').addEventListener('click', () => selDisable(false));
    $('#jvSelRestore').addEventListener('click', () => selDisable(true));

    $('#jvSelNote').addEventListener('click', async () => {
      const ids = [...sel];
      if (!ids.length) return;
      const v = await ask({title: '批量改备注', yes: '保存', input: true, maxlength: 100,
        placeholder: '新备注(留空则清空)',
        body: `将把选中的 ${ids.length} 张卡的备注统一改写。\n改动会写入审计日志。`});
      if (v === null) return;
      try {
        const r = await api('/jfvip/cards/note',
          {method: 'POST', body: JSON.stringify({ids, note: String(v || '')})});
        /* ★ 4.3.1:请求数与生效数不等时必须给出解释 —— 这条规则本文件在
           selDisable / jvSelPurge / bulkDisable 三处都写了,唯独改备注这处
           只报 affected。选中 100 张、其中 40 张已被他人删除时,屏幕上是
           「已更新 60 张的备注」,而那 40 张的去向零迹象。
           静默的数量差异比报错危险得多(项目在 _count_capped / CSV 导出 /
           概览降级三处写过同一条原则)。 */
        toast(r.affected === ids.length
          ? `已更新 ${r.affected} 张的备注`
          : `请求 ${ids.length} 张,实际更新 ${r.affected} 张 —— `
            + '其余卡已不存在(可能已被删除或被保留期清扫)');
        sel.clear(); selMeta.clear(); renderJfvip();
      } catch (e) { toast(errText(e, '改备注失败'), 'err'); }
    });

    /* 删除:**不可撤销**。4.2.9 起取消「先作废才能删」的前置 —— 勾中即删,
       未使用/已作废/已兑换一视同仁。保护由剩下三道承担 ——
       ① 能力总开关 jf_card_purge_enabled(默认关,🔴 高危项);
       ② 只提交**屏幕上勾中的 id 清单**,永远没有「按批次整批删」的入口 ——
          批次是自由文本,把不可逆操作押在不打错字上是不可接受的;
       ③ 键入「DELETE」二次确认,且确认框**逐类摊开**本次会毁掉什么,
          尤其把「仍可兑换」那一类单独列出来 —— 那是唯一会造成资损的一类,
          它以前根本删不掉,现在能删了,就必须让人在按下确认前看见它。
       真正的批量清理仍走保留期自动清扫(只碰终态卡),那条路径有明确时间判据。 */
    $('#jvSelPurge').addEventListener('click', async () => {
      const ids = [...sel];
      if (!ids.length) return;
      // 用 selMeta 而非 items —— items 只有当前页,统计会漏掉其它页选中的行
      const rows = ids.map(i => selMeta.get(i)).filter(Boolean);
      if (rows.length !== ids.length) {
        // 理论上不该发生(勾选时必然入表)。真发生了就是有行数据丢了,
        // 此时**宁可不删** —— 数不清要毁掉什么,就不该按下确认。
        return toast('选择集数据不完整,已取消 —— 请点「清空选择」后重选', 'err');
      }
      const live = rows.filter(c => !c.used && !c.disabled);   // 仍可兑换 = 唯一资损面
      const dead = rows.filter(c => !c.used && c.disabled);    // 已作废未使用
      const used = rows.filter(c => c.used);                   // 已兑换(账在流水里)
      const v = await ask({title: '永久删除卡密', danger: true, yes: '确认永久删除',
        /* 4.3.0:实测键入小写 delete 也能通过(判据是 `.toUpperCase() !== 'DELETE'`)。
           **刻意不收紧**成大小写敏感:这道闸的作用是制造「必须逐字母敲一遍」的
           刻意摩擦,而大小写并不增加摩擦、只增加挫败,与本轮「人人都能用」的
           目标相反。要改的是**标签**:让屏幕上写的和代码里做的是同一件事。 */
        input: true, maxlength: 16, placeholder: '键入 delete 以确认(不区分大小写)',
        body: `将永久删除选中的 ${ids.length} 张卡(无需先作废,全部直接删除):\n`
            + `  · 仍可兑换(未使用未作废):${live.length} 张\n`
            + `  · 已作废未使用:${dead.length} 张\n`
            + `  · 已兑换:${used.length} 张\n\n`
            + (live.length
                ? `⚠ 其中 ${live.length} 张**仍可兑换**。若这些卡已印制或已发到用户手里,\n`
                  + '删除后用户兑换会失败(card_not_found),且**没有任何补救手段**。\n'
                  + '需要可撤回的下架,请改用「作废选中」。\n\n'
                : '')
            + '此操作**不可撤销**,也不会被「恢复整批」找回。\n'
            + '被删卡号会完整写入审计日志(可在「审」视图按「删除卡密」筛出)。\n\n'
            + '注:已兑换卡的账在开通流水(guantai_jf_grant_log)里,删卡行不影响对账。'});
      if (v === null) return;
      if (String(v).trim().toUpperCase() !== 'DELETE') {
        return toast('未键入 delete,已取消', 'err');
      }
      try {
        const r = await api('/jfvip/cards/purge',
          {method: 'POST', body: JSON.stringify({ids})});
        if (r.auditOk === false) {
          /* 第二条取回路径:弹窗可能被误关(Esc 也能关),控制台留一份。
             不是"下载",只是不让唯一的证据挂在一个模态框上。 */
          console.error('[卡密删除·审计写入失败] 被删卡号:',
                        (r.cards || []).map(c => c.card));
          /* 删除已提交、无法回滚。能做的是**绝不假装它被记录了** ——
             把卡号摊在屏幕上让运维当场人工留痕。用 ask 而非 toast:
             toast 2.6 秒就消失,而这条信息可能是唯一的证据。 */
          await ask({title: '⚠ 删除已执行,但审计写入失败', danger: true, yes: '我已记录',
            body: `已永久删除 ${r.affected} 张,但审计日志写入失败 —— `
                + '这批卡号**没有**留下系统记录。\n请立即人工留存以下卡号:\n\n'
                + (r.cards || []).map(c => c.card).join('\n')});
        } else {
          /* 4.2.9:前置取消后 skipped 只剩一种成因 —— 那几行**已经不在库里**
             (他人先删了 / 自动清扫扫走了)。措辞必须跟着改,否则会指着一个
             不存在的原因让运维去排查。数量差异照旧绝不静默。 */
          toast(r.skipped
            ? `已删除 ${r.affected} 张,跳过 ${r.skipped} 张(这些卡已不存在,可能已被删除或清扫)`
            : `已永久删除 ${r.affected} 张`);
        }
        sel.clear(); selMeta.clear(); renderJfvip();
      } catch (e) {
        toast(errText(e, '删除失败'), 'err');
      }
    });
    return;
  }

  if (JV.tab === 'orders' || JV.tab === 'grants') {
    const isOrd = JV.tab === 'orders';
    const st = isOrd ? JV.orders : JV.grants;
    /* 只把**非空**条件拼进 URL:空串也拼会让地址栏/日志里全是 `&amtMin=&amtMax=`,
       排障时看不出运维到底筛了什么;后端对空串本来也是当没传处理。 */
    const qs = o => Object.entries(o).filter(([, v]) => v !== '' && v != null)
      .map(([k, v]) => `&${k}=${encodeURIComponent(v)}`).join('');
    /* 同 mkCardsUrl:构造器接受状态,列表用活引用、导出用冻结快照(见那处长注)。 */
    const mkListUrl = o => (page, size) => isOrd
      ? `/jfvip/orders?page=${page}&size=${size}` + qs({
          status: o.status, orderNo: o.orderNo, userName: o.userName,
          plan: o.plan, dateFrom: o.dateFrom, dateTo: o.dateTo,
          amtMin: o.amtMin, amtMax: o.amtMax,
          simulate: o.simulate, credited: o.credited})
      /* 4.2.8:补上 uid —— 后端 /jfvip/grants 一直收 `uid: int = Query(0, ge=0)`,
         而前端从不发送,那条通路等于不存在。卡密页「使用者」列点击跳转到本页时
         正是靠它把范围收到那一个人身上。 */
      : `/jfvip/grants?page=${page}&size=${size}&source=${encodeURIComponent(o.source)}`
        + (o.uid ? `&uid=${encodeURIComponent(o.uid)}` : '')
        + qs({dateFrom: o.dateFrom, dateTo: o.dateTo});   // 4.3.0:按期对账
    const listUrl = mkListUrl(st);
    let d;
    try { d = jvGuard(await api(listUrl(st.page, st.size || JV_PAGE))); }
    catch (e) { JV._refocusPager = '';        // 见 jvRestorePagerFocus 注:标志必须消费掉
                body.innerHTML = '<div class="card"><div class="err">'
                                 + esc(errText(e, isOrd ? '订单列表读取失败' : '开通流水读取失败'))
                                 + '</div></div>'; return; }
    /* ★ 复审自查缺陷:卡密页「使用者」链接会设上 JV.grants.uid 把流水收窄到
       某个人,而流水页**既不显示这个筛选、也没有清除入口** —— 运维会看到一个
       「为什么流水这么少」的页面且无从下手。这与本项目反复强调的「静默状态
       比报错危险」是同一件事。现在把它显式化并给出出口。 */
    const uidChip = (!isOrd && st.uid)
      ? `<div class="hint-line">已按用户 <b>uid ${st.uid}</b> 收窄(从卡密页跳转而来)
         <button class="btn" id="jvGrantUidClear" style="margin-left:8px">清除该筛选</button></div>`
      : '';
    const SRC = {order: '在线充值', card: '卡密', admin: '手动', revoke: '撤销'};
    const STATUS = {paid: '已支付', pending: '待支付', expired: '已过期'};
    const total = Number(d.total) || 0;
    const capped = !!d.totalCapped;
    /* 订单页的筛选条。刻意**不**做成"输入即查":每敲一个字符就发一次请求,
       在多条件表单上既打库又抖屏;统一由「查询」/回车触发,与卡密页同款。

       ★ 元素 id 一律写成**字面量**,不走模板变量 —— tests/test_register.py::
         test_admin_reg_view_ids_exist 用正则扫「引用了但没渲染的 id」,那道守门
         是因为真出过事故才立的(弹窗读 #giCount,而 ask() 用 textContent 渲染
         压根不建这些元素 ⇒ 点「批量生成」当场 TypeError)。用模板变量拼 id 会让
         这些元素对静态扫描**隐形** —— 守门还在,但看不见我这一片了。

       ★ 无障碍名一律**由包裹的 <label> 可见文字提供**,不写 aria-label ——
         aria-label 会**覆盖**可见标签,而 WCAG 2.5.3(Label in Name)要求
         无障碍名必须包含可见文字。实测本轮初版有 5 处不合规:可见「下单起」/
         无障碍名「下单日期起(含当天)」、可见「金额 ≥」/ 无障碍名「金额下限」……
         语音控制用户念屏幕上看得见的那几个字,点不中。
         补充说明改挂 title=,它进的是**描述**而非名称,不参与该判据。 */
    const fld = (label, inner) => `<label class="jv-f"><span>${label}</span>${inner}</label>`;
    const opts = (list, cur) => list.map(([v, n]) =>
      `<option value="${esc(v)}"${cur === v ? ' selected' : ''}>${esc(n)}</option>`).join('');
    const ordFilters = `
      <div class="jv-filters">
        ${fld('订单号', `<input id="jvOrdNo" value="${esc(st.orderNo)}" maxlength="64"
                 placeholder="前缀即可" title="按订单号前缀检索(中缀会退化成全表扫,故不支持)"
                 enterkeyhint="search">`)}
        ${fld('用户名', `<input id="jvOrdUser" value="${esc(st.userName)}" maxlength="50"
                 placeholder="精确匹配" title="按用户名精确匹配,与登录时所填一致"
                 enterkeyhint="search">`)}
        ${fld('状态', `<select id="jvFlt" title="按订单状态筛选">${opts(
                 [['', '全部'], ['pending', '待支付'], ['paid', '已支付'],
                  ['expired', '已过期']], st.status)}</select>`)}
        ${fld('档位', `<select id="jvOrdPlan" title="按档位筛选">${opts(
                 [['', '全部档位']].concat(plans.map(p => [p.code, p.name])), st.plan)}</select>`)}
        ${fld('下单起', `<input id="jvOrdFrom" type="date" value="${esc(st.dateFrom)}"
                 title="下单日期起,含当天">`)}
        ${fld('下单止', `<input id="jvOrdTo" type="date" value="${esc(st.dateTo)}"
                 title="下单日期止,含当天全天">`)}
        ${fld('金额 ≥', `<input id="jvOrdAmin" type="number" min="0" step="0.01"
                 value="${esc(st.amtMin)}" title="金额下限(含)" enterkeyhint="search">`)}
        ${fld('金额 ≤', `<input id="jvOrdAmax" type="number" min="0" step="0.01"
                 value="${esc(st.amtMax)}" title="金额上限(含)" enterkeyhint="search">`)}
        ${fld('是否模拟', `<select id="jvOrdSim" title="按是否模拟支付筛选">${opts(
                 [['', '全部'], ['0', '真实'], ['1', '模拟']], st.simulate)}</select>`)}
        ${fld('是否入账', `<select id="jvOrdCred" title="按是否已入账筛选">${opts(
                 [['', '全部'], ['1', '已入账'], ['0', '未入账']], st.credited)}</select>`)}
      </div>
      <div class="row jv-acts">
        <button class="btn primary" id="jvFltGo">查询</button>
        <button class="btn" id="jvFltReset">重置</button>
        <span class="mut jv-hint">订单号按<b>前缀</b>匹配;用户名<b>精确</b>匹配(与登录时所填一致)</span>
        <span class="spacer"></span>
        <button class="btn" id="jvExp">导出全部命中 (${total}${capped ? '+' : ''}) CSV</button>
      </div>`;
    /* 4.3.0:补时间区间。id 一律写字面量(理由见上面 ordFilters 的长注:
       test_admin_reg_view_ids_exist 用正则扫「引用了但没渲染的 id」,
       模板变量拼 id 会让元素对那道守门隐形)。
       无障碍名同样由 <label> 的可见文字提供、补充说明挂 title —— 与订单页同款,
       满足 WCAG 2.5.3(Label in Name)。 */
    const grantFilters = `
      <div class="jv-filters">
        ${fld('来源', `<select id="jvFlt" title="按开通来源筛选">${opts(
                 [['', '全部'], ['order', '在线充值'], ['card', '卡密'],
                  ['admin', '手动开通'], ['revoke', '撤销']], st.source)}</select>`)}
        ${fld('发生起', `<input id="jvGrFrom" type="date" value="${esc(st.dateFrom)}"
                 title="开通/撤销发生日期起,含当天">`)}
        ${fld('发生止', `<input id="jvGrTo" type="date" value="${esc(st.dateTo)}"
                 title="开通/撤销发生日期止,含当天全天">`)}
      </div>
      <div class="row jv-acts">
        <button class="btn primary" id="jvFltGo">查询</button>
        <button class="btn" id="jvGrReset">重置</button>
        <span class="mut jv-hint">对账请按<b>月</b>或按<b>结算周期</b>选定日期区间后再导出</span>
        <span class="spacer"></span>
        <button class="btn" id="jvExp">导出全部命中 (${total}${capped ? '+' : ''}) CSV</button>
      </div>`;
    const anyFilter = isOrd
      ? !!(st.status || st.orderNo || st.userName || st.plan || st.dateFrom
           || st.dateTo || st.amtMin || st.amtMax || st.simulate || st.credited)
      /* `st.source || st.uid` 这个子串被 test_grants_uid_filter_is_visible_and
         _clearable 逐字断言(空态判据必须把 uid 算作筛选条件),故原样保留、
         只在后面追加日期两项。 */
      : !!(st.source || st.uid || st.dateFrom || st.dateTo);
    body.innerHTML = `
      <div class="card">
        <h3>${isOrd ? '在线充值订单' : '开通流水(唯一对账口径)'}</h3>
        ${isOrd ? '' : `<p class="mut">⚠ 九法赠送的小叮当时长<b>不会</b>出现在繁星后台的卡密/订单流水里
           (我们不写它的表)。对账请以本表为准,两边相加。</p>`}
        ${isOrd ? ordFilters : grantFilters}
        ${uidChip}
        ${isOrd && d.userNotFound ? `<div class="warn-line"><span>⚠</span><span>
          用户名「${esc(st.userName)}」在用户库中<b>不存在</b>(可能已注销或拼写有误)——
          下表是按订单里保存的<b>历史用户名快照</b>匹配的结果,可能为空。
        </span></div>` : ''}
        ${capped ? `<div class="hint-line">命中数已达统计上限 <b>${total}</b> 条并停止计数
          (显示为「${total}+」)—— 这是为了不让每次翻页都全表数一遍。
          需要精确总数请收窄筛选条件。</div>` : ''}
        <p class="mut">共 ${total}${capped ? '+' : ''} 条 · 第 ${Number(d.page) || 1} 页 · 导出为当前筛选的全部命中行,不止本页</p>
        <table class="tbl"><thead><tr>${(isOrd
          ? ['订单号', '用户', '档位', '金额', '状态', '入账', '下单', '支付']
          : ['时间', '用户', '来源', '凭据/原因', '档位', '金额', '九法+', 'VIP 到期变为', '小叮当+', '操作人'])
          .map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>
          ${(d.items || []).length ? (d.items || []).map(r => isOrd ? `<tr>
              <td class="mono" style="font-size:11px">${esc(r.orderNo)}</td>
              <td>${esc(r.userName)}<span class="mut"> #${esc(String(r.userId))}</span></td>
              <td>${jvPlanCell(r.plan)}</td><td>${jvMoney(r.amount)}</td>
              <td>${r.status === 'paid' ? '<span class="tag ok">已支付</span>'
                   : r.status === 'expired' ? '<span class="tag">已过期</span>'
                   : '<span class="tag warn">待支付</span>'}${r.simulate ? ' <span class="tag warn">模拟</span>' : ''}</td>
              <td>${r.credited ? '<span class="tag ok">已入账</span>'
                   : '<span class="tag warn">未入账</span>'}</td>
              <td>${jvTime(r.createTime)}</td><td>${jvTime(r.payTime)}</td></tr>`
            : `<tr><td>${jvTime(r.createdAt)}</td><td>${esc(r.userName)}</td>
              <td>${esc(SRC[r.source] || r.source)}</td>
              <td class="mono" style="font-size:11px">${esc(r.ref || '')}</td>
              <td>${jvPlanCell(r.plan)}</td><td>${jvMoney(r.amount)}</td>
              <td>${r.jfHours}h</td><td>${jvTime(r.vipAfter)}</td>
              <td>${r.ddHours}h</td>
              <td>${esc(r.operator || '')}</td></tr>`).join('')
            : jvEmptyRow(isOrd ? 8 : 10,
                anyFilter
                  ? '当前筛选条件下没有记录 —— 点「重置」清空全部条件再看看'
                  : (isOrd ? '还没有任何在线充值订单' : '还没有任何开通记录'))}
        </tbody></table>
        ${jvPager(d)}
      </div>`;
    jvBindPager(body, (p, size) => { st.page = p; if (size) st.size = size; renderJfvip(); });
    jvRestorePagerFocus(body);
    const doQuery = () => {
      if (isOrd) {
        JV.orders.status = $('#jvFlt').value;
        JV.orders.orderNo = $('#jvOrdNo').value.trim();
        JV.orders.userName = $('#jvOrdUser').value.trim();
        JV.orders.plan = $('#jvOrdPlan').value;
        JV.orders.dateFrom = $('#jvOrdFrom').value.trim();
        JV.orders.dateTo = $('#jvOrdTo').value.trim();
        JV.orders.amtMin = $('#jvOrdAmin').value.trim();
        JV.orders.amtMax = $('#jvOrdAmax').value.trim();
        JV.orders.simulate = $('#jvOrdSim').value;
        JV.orders.credited = $('#jvOrdCred').value;
      } else {
        JV.grants.source = $('#jvFlt').value;
        JV.grants.dateFrom = $('#jvGrFrom').value.trim();
        JV.grants.dateTo = $('#jvGrTo').value.trim();
      }
      st.page = 1; renderJfvip();
    };
    const uidClr = $('#jvGrantUidClear');
    if (uidClr) uidClr.addEventListener('click', () => {
      JV.grants.uid = 0; JV.grants.page = 1; renderJfvip();
    });
    $('#jvFltGo').addEventListener('click', doQuery);
    if (isOrd) {
      // 回车即查询 —— 与卡密页/用户页一致,别让人填完还得去找按钮
      ['jvOrdNo', 'jvOrdUser', 'jvOrdFrom', 'jvOrdTo', 'jvOrdAmin', 'jvOrdAmax']
        .forEach(id => { const el = $('#' + id); if (el) el.addEventListener('keydown',
          e => { if (e.key === 'Enter' && !e.isComposing) doQuery(); }); });
      $('#jvFltReset').addEventListener('click', () => {
        Object.assign(JV.orders, {page: 1, status: '', orderNo: '', userName: '',
          plan: '', dateFrom: '', dateTo: '', amtMin: '', amtMax: '',
          simulate: '', credited: ''});
        renderJfvip();
      });
    } else {
      // 回车即查询 + 重置 —— 与订单页/卡密页/用户页一致,别让人填完还得去找按钮
      ['jvGrFrom', 'jvGrTo'].forEach(id => { const el = $('#' + id); if (el)
        el.addEventListener('keydown', e => {
          if (e.key === 'Enter' && !e.isComposing) doQuery(); }); });
      const gr = $('#jvGrReset');
      if (gr) gr.addEventListener('click', () => {
        /* uid 也一并清 —— 它同样是「当前生效的筛选」,而运维点「重置」的语义
           就是「把条件清干净」。只清一半会留下一个他刚亲手点过重置、却仍然
           只显示某一个人的流水页,那正是 uidChip 当初要解决的同一类困惑。 */
        Object.assign(JV.grants, {page: 1, source: '', uid: 0, dateFrom: '', dateTo: ''});
        renderJfvip();
      });
    }
    $('#jvExp').addEventListener('click', async e => {
      const btn = e.currentTarget; btn.disabled = true;
      const snap = Object.assign({}, st);         // 冻结本次导出的筛选条件
      const tab = JV.tab;                         // 文件名也要用快照,免得导完落到别的页签名下
      try {
        const all = await jvFetchAll(mkListUrl(snap), isOrd ? '订单' : '流水');
        if (!all) return;
        /* 订单导出必须带「是否模拟」—— 屏幕上有「模拟」徽标而导出里没有,
           模拟支付单在对账文件中与真实付款单一模一样,是会算错钱的。 */
        const head = isOrd
          ? ['订单号', '用户', '用户ID', '档位', '金额', '状态', '是否模拟', '是否已入账', '下单时间', '支付时间']
          : ['时间', '用户', '用户ID', '来源', '凭据/原因', '档位', '金额',
             '九法小时', '小叮当小时', 'VIP前', 'VIP后', '到期前', '到期后', '操作人'];
        const rows = all.items.map(r => isOrd
          ? [r.orderNo, r.userName, r.userId, r.plan, r.amount, STATUS[r.status] || r.status,
             r.simulate ? '模拟' : '真实', r.credited ? '已入账' : '未入账',
             r.createTime, r.payTime]
          : [r.createdAt, r.userName, r.userId, SRC[r.source] || r.source, r.ref, r.plan,
             r.amount, r.jfHours, r.ddHours, r.vipBefore, r.vipAfter,
             r.dueBefore, r.dueAfter, r.operator]);
        jvDownload(`jfvip-${tab}-${all.items.length}.csv`, jvCsv(head, rows));
        toast(`已导出 ${all.items.length} 条`);
      } catch (err) { toast(errText(err, '导出失败'), 'err'); }
      finally { btn.disabled = false; }
    });
    return;
  }

  // ── 用户:查状态 / 手动开通 / 撤销 ──────────────────────────────────────
  body.innerHTML = `
    <div class="card">
      <h3>用户 VIP 状态</h3>
      <div class="row" style="gap:8px;align-items:center;flex-wrap:wrap">
        <input id="jvUName" placeholder="用户名" style="width:220px"
               aria-label="要查询的用户名,回车即查询" maxlength="64" enterkeyhint="search">
        <button class="btn" id="jvUGo">查询</button>
        <span class="mut">按用户名精确匹配(与登录时所填一致)</span>
      </div>
      <!-- 状态播报单独一行:aria-live 挂在整块结果面板上,读屏会把整张表
           连同四个按钮全念一遍(WAI-ARIA 的 live region 是给**状态短句**用的)。 -->
      <p id="jvUStatus" class="sr-only" role="status" aria-live="polite"></p>
      <div id="jvUBox" style="margin-top:12px"></div>
    </div>`;
  const query = async () => {
    const n = $('#jvUName').value.trim();
    const box = $('#jvUBox');
    const say = t => { const el = $('#jvUStatus'); if (el) el.textContent = t; };
    if (!n) { box.innerHTML = '<div class="mut">请先输入用户名</div>';
              say('请先输入用户名'); return; }
    box.innerHTML = '<div class="mut">查询中…</div>'; say('查询中');
    let u;
    try { u = jvGuard(await api('/jfvip/user?userName=' + encodeURIComponent(n))); }
    catch (e) {
      const d = (e && e.data) || {};
      box.innerHTML = '<div class="err">' + esc(d.error === 'user_not_found'
        ? `查无此用户「${n}」—— 请核对拼写与大小写(此处按用户名精确匹配,不做模糊搜索)`
        : errText(e, '查询失败')) + '</div>';
      say(d.error === 'user_not_found' ? '查无此用户' : '查询失败');
      return;
    }
    const tier = u.alive ? 'vip' : (u.ddAlive ? 'basic' : 'free');
    say(`已找到 ${u.userName},当前档位 ${tier}`
        + (u.vipUntil ? `,九法VIP 到期 ${jvTime(u.vipUntil)}` : ',从未开通九法VIP'));
    const noPlanNow = (JV.plans || []).length === 0;
    box.innerHTML = `
      <table class="tbl"><tbody>
        <tr><th>用户</th><td>${esc(u.userName)} <span class="mut">#${esc(u.userId)}</span></td></tr>
        <tr><th>当前档位</th><td><span class="tag ${tier === 'vip' ? 'ok' : tier === 'free' ? 'warn' : ''}">${tier}</span></td></tr>
        <tr><th>小叮当到期</th><td>${jvTime(u.ddDueTime)} ${u.ddAlive ? '' : '<span class="tag warn">已到期</span>'}</td></tr>
        <tr><th>九法VIP到期</th><td>${u.vipUntil ? jvTime(u.vipUntil) : '<span class="mut">从未开通</span>'}
            ${u.vipDays != null ? `<span class="mut">(剩 ${esc(u.vipDays)} 天)</span>` : ''}</td></tr>
        <tr><th>累计开通</th><td>${esc(u.totalHours || 0)} 小时</td></tr>
      </tbody></table>
      <div class="row" style="gap:8px;margin-top:12px;align-items:center;flex-wrap:wrap">
        <select id="jvGPlan" aria-label="手动开通的档位"${noPlanNow ? ' disabled' : ''}>
          ${noPlanNow ? '<option value="">(档位表为空)</option>'
            : (JV.plans || []).map(p => `<option value="${esc(p.code)}">${esc(p.name)} ${jvMoney(p.price)} · ${jvDur(p.jfHours)}</option>`).join('')}
        </select>
        <button class="btn primary" id="jvGrant"${noPlanNow ? ' disabled' : ''}>手动开通</button>
        <span class="mut" style="margin-left:10px">撤销</span>
        <input id="jvRHours" type="number" min="1" max="8928" value="24" style="width:96px"
               aria-label="撤销小时数(1–8928,即最多 1 年)"${u.vipUntil ? '' : ' disabled'}>
        <span class="mut">小时</span>
        <!-- 4.3.0:从未开通过 VIP 的用户,撤销在后端是**无操作**(guantai_jf_vip
             没有他的行)。此前这里照样可点,点完还会弹绿色「已撤销」,而库里
             什么都没变、流水里却多一条 jf_hours=-N 的幽灵记录(后端已在
             _grant_tx 里 fail-closed 拦掉,回 no_vip_row)。
             按钮如实禁用 = 让人在**按下之前**就知道这条路走不通,而不是
             走完全套仪式再吃一个错误。两端都拦:后端是正确性,前端是可用性。 -->
        <button class="btn danger" id="jvRevoke"${u.vipUntil ? '' : ' disabled'}
                title="${u.vipUntil ? '按小时回扣九法VIP,不回收已赠送的小叮当'
                                    : '该用户从未开通过九法VIP,没有可撤销的时长'}">撤销</button>
      </div>
      <p class="mut" style="margin-top:8px">
        手动开通走与付费开通<b>完全相同</b>的事务 ⇒ 同样幂等、同样落流水、同样赠送小叮当。<br>
        撤销<b>只扣九法VIP,不回收已赠送的小叮当时长</b> —— 那部分已进父项目的账,
        回收会让两个系统口径打架;需要时请在繁星后台单独处理。
      </p>`;
    $('#jvGrant').addEventListener('click', async () => {
      const plan = $('#jvGPlan').value;
      if (!plan) return toast('档位表为空,无法开通', 'err');
      const note = await ask({title: '手动开通', input: true, maxlength: 64,
        placeholder: '操作原因(必填,如:客服补偿工单 #123)',
        danger: true, yes: '确认开通',
        body: `用户:${u.userName}(#${u.userId})\n档位:${jvPlanText(plan)}\n\n`
            + '原因会同时写入开通流水与审计日志(流水侧保留前 64 字)。'});
      if (!note || !note.trim()) return toast('操作原因必填,已取消', 'err');
      try { const r = await api('/jfvip/grant', {method: 'POST',
              body: JSON.stringify({userName: u.userName, plan, note: note.trim()})});
        toast(`已开通 · VIP 到 ${jvTime(r.vipUntil)}`); query();
      } catch (e) { toast(errText(e, '开通失败'), 'err'); }
    });
    $('#jvRevoke').addEventListener('click', async () => {
      const h = Number($('#jvRHours').value || 0);
      /* ★ 4.3.1:必须显式判整数。后端的整数口径由 jfvip._norm_int 定义,它
         **刻意拒绝浮点**(那处注释:「int(72.9) 静默变 72,而 JSON 里写 72.9 的人
         显然不想要 72」),同文件的「⏱ 指定时长」发卡前端也照此写了
         Number.isInteger 两道闸 —— 唯独这里漏了。
         `<input type=number>` 的 .value 对 "24.5" 会原样返回(它是合法浮点串),
         于是 24.5 能穿过 `h > 0` 送到后端,再被后端以 422 打回,而运维看到的
         是一句笼统的「参数不完整或超出允许范围」。两端口径必须一致:
         前端说清楚「要整数」,后端保持拒绝。 */
      if (!(Number.isInteger(h) && h > 0)) {
        return toast('撤销小时数需为大于 0 的整数小时', 'err');
      }
      if (h > 8928) return toast('单次撤销上限 8928 小时(1 年);确需更多请分次执行', 'err');
      /* 后端口径:vip_until = GREATEST(NOW(), vip_until - N 小时)。
         预览按同一公式本地算一遍 —— 少一个 GREATEST 就会把「其实已经归零」
         说成「还剩几天」,那种预览比不给更坏。 */
      const cur = jvParseTime(u.vipUntil);
      const now = new Date();
      let after = '(该用户尚无 VIP 记录,撤销不会有任何效果)';
      if (cur) {
        const t = new Date(cur.getTime() - h * 3600000);
        const eff = t < now ? now : t;
        after = `${jvFmtDate(cur)} → ${jvFmtDate(eff)}`
              + (t < now ? '(已扣到底,不会早于此刻)' : '');
      }
      const note = await ask({title: '撤销 VIP', input: true, maxlength: 64,
        placeholder: '操作原因(必填,如:误开通回滚工单 #456)',
        danger: true, yes: '确认撤销',
        body: `用户:${u.userName}(#${u.userId})\n`
            + `撤销时长:${h} 小时(${jvDur(h)})\n`
            + `VIP 到期预计:${after}\n\n`
            + '已赠送的小叮当时长不会回收。原因会写入流水与审计(流水侧保留前 64 字)。'});
      if (!note || !note.trim()) return toast('操作原因必填,已取消', 'err');
      try { await api('/jfvip/revoke', {method: 'POST',
              body: JSON.stringify({userName: u.userName, hours: h, note: note.trim()})});
        toast('已撤销'); query();
      } catch (e) { toast(errText(e, '撤销失败'), 'err'); }
    });
  };
  $('#jvUGo').addEventListener('click', query);
  $('#jvUName').addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.isComposing) query();
  });
}

/* 分页器。
   ⚠ 初版把翻页回调**字符串化**塞进内联事件属性(`(${go})(${n})`)——
   闭包在字符串化时就丢了,而 admin.js 是 `<script type="module">`,
   顶层的 JV / renderJfvip 并不在全局作用域 → 点击必 `ReferenceError: JV is not defined`,
   **任何超过一页的列表都翻不动**(发卡单批 500,必然触发)。而且内联事件属性
   在收紧 CSP 后也会被直接拦掉。
   现改为:只产出结构,回调由 `jvBindPager` 在插入 DOM 后用 addEventListener 挂 ——
   闭包完整保留,零内联脚本。 */
/* ── 分页器(4.2.6 重做)──────────────────────────────────────────────────────
   旧版只有「上一页 / 下一页」两颗按钮,且第一行就是 `if (pages<=1) return ''`。
   实测(jsdom 真 DOM,total=30 单页)整条分页器**凭空消失**,页面上只剩一行
   灰字 —— 这正是「订单没有分页功能」这个印象的来源:日常量不大时,运维打开
   看到的就是什么都没有。空态与「没查对」无法区分,和 jvEmptyRow 要解决的
   是同一个病,不该只治表格不治分页条。

   现在:
     · 单页也渲染,退化成静态的「共 N 条 · 第 1/1 页」——「真没有」看得见;
     · 首页«/上页‹/下页›/末页» 四向 + 直接跳页输入框(>3 页才出,免得两页也塞一个框);
     · 每页条数 25/50/100/200,与名录视图(RM_SIZES)同款;
     · 复用既有 .pager/.pg-b/.pg-at 样式(名录视图在用,已是 flex 且有窄屏居中规则),
       同时保留 .jv-pager 与 data-jvp="prev|next" —— 既有冒烟脚本按这两个选择器
       断言,不能因为重做就把别人的钉子拔了。
     · 总数被后端封顶时(totalCapped)显示「50000+」并禁用末页 —— 谎报一个
       精确总数比显示「50000+」危险得多。 */
const JV_SIZES = [25, 50, 100, 200];

function jvPager(d) {
  const total = Number(d.total) || 0;
  const size = Number(d.size) || JV_PAGE;
  const capped = !!d.totalCapped;
  const pages = Math.max(1, Math.ceil(total / size));
  const p = Math.min(Math.max(1, Number(d.page) || 1), pages);
  const btn = (act, label, dis, aria) =>
    `<button class="btn ghost pg-b" data-jvp="${act}"${dis ? ' disabled' : ''}`
    + ` aria-label="${aria}" title="${aria}">${label}</button>`;
  const sizeSel = `<label class="jv-psize">每页
    <select data-jvps aria-label="每页条数">${JV_SIZES.map(n =>
      `<option value="${n}"${n === size ? ' selected' : ''}>${n}</option>`).join('')}
    </select></label>`;
  const jump = pages > 3
    ? `<span class="jv-pjump">跳至<input type="number" data-jvpg min="1" max="${pages}"
         value="${p}" aria-label="跳至第几页" enterkeyhint="go">页
       <button class="btn" data-jvp="go">跳转</button></span>`
    : '';
  return `<div class="pager jv-pager" data-page="${p}" data-pages="${pages}"
               data-size="${size}">
    ${btn('first', '«', p <= 1, '首页')}${btn('prev', '‹', p <= 1, '上一页')}
    <span class="pg-at">第 <b>${p}</b> / ${pages} 页<span class="mut"> · 共 ${total}${capped ? '+' : ''} 条</span></span>
    ${btn('next', '›', p >= pages, '下一页')}${btn('last', '»', p >= pages || capped, capped ? '总数已封顶,末页不可达 —— 请收窄筛选' : '末页')}
    ${jump}<span class="spacer"></span>${sizeSel}
  </div>`;
}

/* 把翻页回调挂到刚渲染出来的分页器上(在 innerHTML 之后调用)。
   go(page, size) —— 第二参可选,只有改「每页条数」时才带。
   ★ 翻页会整段 innerHTML 重写、把刚点的按钮销毁,焦点掉回 document,
     键盘用户连按「下一页」按一次就出不来(与 tablist 那处 JV._refocus 同源的坑,
     那次是真实浏览器实测逮到的)。故此处记下刚点的动作,由重绘后归还焦点。 */
function jvBindPager(root, go) {
  const box = (root || document).querySelector('.jv-pager');
  if (!box || box.dataset.bound) return;
  box.dataset.bound = '1';
  const cur = Number(box.dataset.page) || 1;
  const max = Number(box.dataset.pages) || 1;
  const size = Number(box.dataset.size) || JV_PAGE;
  const jumpEl = box.querySelector('[data-jvpg]');
  const goto = (t, act) => {
    const n = Math.max(1, Math.min(Math.round(t) || 1, max));
    if (n === cur && act !== 'size') return;
    JV._refocusPager = act || '';
    go(n, size);
  };
  box.querySelectorAll('[data-jvp]').forEach(b => b.addEventListener('click', () => {
    const a = b.dataset.jvp;
    goto(a === 'first' ? 1 : a === 'last' ? max
       : a === 'prev' ? cur - 1 : a === 'next' ? cur + 1
       : Number(jumpEl && jumpEl.value), a);
  }));
  if (jumpEl) jumpEl.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); goto(Number(jumpEl.value), 'go'); }
  });
  const sel = box.querySelector('[data-jvps]');
  if (sel) sel.addEventListener('change', () => {
    const ns = Number(sel.value) || JV_PAGE;
    JV._refocusPager = 'size';
    go(1, ns);                       // 改页长必须回第 1 页,否则会停在一个空页上
  });
}

/* 重绘后把焦点还给分页器上刚才那颗按钮(没有则不动)。 */
function jvRestorePagerFocus(root) {
  const act = JV._refocusPager;
  if (!act) return;
  JV._refocusPager = '';
  const el = (root || document).querySelector(`.jv-pager [data-jvp="${act}"]`)
          || (root || document).querySelector('.jv-pager [data-jvps]');
  if (el && !el.disabled) el.focus();
}

function jvDownload(name, text) {
  try {
    /* ★ 复审自查修补:MIME 不能写死。本函数同时服务发卡的 .txt 与流水的 .csv,
       此前一律标成 text/csv —— 卡密 txt 在部分环境会被当表格打开/改后缀。 */
    const mime = /\.csv$/i.test(name) ? 'text/csv;charset=utf-8'
                                      : 'text/plain;charset=utf-8';
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], {type: mime}));
    a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  } catch (_) { toast('导出失败(浏览器不支持)', 'err'); }
}

/* ───────── 存储与保留(1.11.0 · 后端 5.4.0 数据生命周期) ─────────
   回答「库里每一张表凭什么不会无限增长」。本页完全由 /storage 驱动:后端的全表登记
   (lifecycle.TABLES)决定有哪些行 —— 后端登记一张新表,这里自动多一行,前端零改动。
   口径(与帮助页同文):行数带「约」= 估计值(大表不做逐行计数,体检不该制造负载);
   「—」= 该表在库里不存在(如未启用登录系统时的用户库各表)。
   读取失败诚实报错,不伪装成空态(与 1.4.3 A3 同一条纪律)。 */
const fmtBytes = n => {
  if (n == null) return '—';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0, v = Number(n);
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return (i === 0 ? String(v) : v >= 100 ? v.toFixed(0) : v.toFixed(1)) + ' ' + u[i];
};
const fmtInt = n => Number(n).toLocaleString('en-US');
const fmtRows = t => t.rows == null ? '—' : (t.exact ? '' : '约 ') + fmtInt(t.rows);
function stLast(sw, table) {
  // 本表在最近一轮清扫里的各条规则:删了多少 / 没清完 / 报错(报错原文挂 title,触屏可点开)
  const out = [];
  for (const r of Object.values((sw && sw.tasks) || {})) {
    if (r.table !== table) continue;
    if (r.error) out.push('<span class="bad" title="' + esc(r.error) + '">' + esc(r.rule) + ':失败</span>');
    else out.push(esc(r.rule) + ':' + (r.deleted ? '−' + fmtInt(r.deleted) : '无可清')
      + (r.capped ? '(未清完,续扫中)' : '')
      + (r.note ? ' <span class="bad">' + esc(r.note) + '</span>' : ''));
  }
  return out.join('<br>');
}
function stTable(title, sub, rows, sw) {
  let t = '<h3 class="st-h">' + esc(title) + ' <span class="mut">' + esc(sub) + '</span></h3>'
    + '<div class="st-wrap"><table class="tbl st-tbl"><tr><th>表</th><th>类别</th>'
    + '<th class="st-num">行数</th><th class="st-num">占用</th><th>怎么清 · 凭什么有界</th>'
    + '<th>谁来清</th><th>上次清扫</th></tr>';
  for (const r of rows)
    t += '<tr><td class="st-name">' + esc(r.table) + '</td>'
      + '<td><span class="st-k" data-k="' + esc(r.klass) + '">' + esc(r.klassLabel) + '</span></td>'
      + '<td class="st-num">' + (r.present ? fmtRows(r) : '—') + '</td>'
      + '<td class="st-num">' + (r.present ? fmtBytes(r.bytes) : '—') + '</td>'
      + '<td class="st-pol">' + esc(r.policy) + '<span class="mut">有界依据:' + esc(r.bound)
      + (r.oldest ? ' · 最旧一行 ' + esc(String(r.oldest).replace('T', ' ')) : '') + '</span></td>'
      + '<td class="st-last">' + esc(r.sweeper) + '</td>'
      + '<td class="st-last">' + (stLast(sw, r.table) || '<span class="mut">—</span>') + '</td></tr>';
  return t + '</table></div>';
}
async function renderStorage() {
  $('#main').innerHTML = '<div class="view-title">存储与保留</div>'
    + '<div class="view-sub">库里每一张表凭什么不会无限增长 —— 全表登记 · 现在多大 · 上次清了多少(30s 自动刷新)</div>'
    + '<div id="stBody" class="empty">载入中…</div>';
  let busy = false;
  const draw = async fresh => {
    let d;
    try { d = await api('/storage' + (fresh ? '?fresh=1' : '')); }
    catch (e) {
      if (e && e.status === 401) return;          // 已由 api() 弹回登录
      const el = $('#stBody');
      if (el && S.view === 'storage')
        el.outerHTML = '<div id="stBody"><div class="err-line">存储体检读取失败:'
          + esc(errText(e, (e && e.status) ? 'HTTP ' + e.status : '网络错误'))
          + ' —— 请刷新重试;若持续,检查 web 服务日志。</div></div>';
      return;
    }
    if (S.view !== 'storage') return;             // 请求在途时已切走,别污染新视图
    const sw = (d.sweeps && d.sweeps.stores) || {};
    const swk = (d.sweeps && d.sweeps.worker) || {};    // worker 侧 rounds / predictions 的清理
    const my = d.mysql || {tables: []}, pg = d.pg || {tables: []}, rd = d.redis || {}, ef = d.effective || {};
    const when = s => (s && s.at_ms) ? ago(s.at_ms) : '尚未执行';
    const kpi = (v, l) => '<div class="kpi"><b>' + esc(String(v)) + '</b><span>' + esc(l) + '</span></div>';
    let h = '';
    for (const a of (d.alerts || []))
      h += '<div class="' + (a.level === 'bad' ? 'err-line' : 'warn-line') + '">' + esc(a.text) + '</div>';
    const nTab = pg.tables.length + (my.enabled ? my.tables.length : 0);
    if (!(d.alerts || []).length)
      h += '<div class="st-ok">✓ ' + nTab + ' 张表全部登记了生命周期策略;上次清扫无报错,没有表触及行数上限。</div>';
    if (pg.error) h += '<div class="err-line">观测库容量体检失败:' + esc(pg.error) + '</div>';
    h += '<div class="st-acts"><button class="btn" id="stRefresh">↻ 刷新</button>'
      + '<button class="btn primary" id="stSweep">立即清扫</button>'
      + '<span class="mut">清扫只删「已经过期的」,与定时清扫是同一份代码;rounds / predictions 两张大表由 worker 每小时裁剪,不在此按钮范围。</span></div>';
    h += '<div class="kpis">'
      + kpi(fmtBytes(pg.db_bytes), '观测库(PostgreSQL)总大小')
      + kpi(my.enabled ? fmtBytes(my.tables.reduce((a, t) => a + (t.bytes || 0), 0)) : '未启用', '用户库 guantai_* 合计')
      + kpi(rd.used != null ? fmtBytes(rd.used) + (rd.maxmemory ? ' / ' + fmtBytes(rd.maxmemory) : '') : '—', 'Redis 内存(已用 / 上限)')
      + kpi(when(swk), '出怪/预测历史(worker)· 上次清理')
      + kpi(when(sw.pg), '观测库小表 · 上次清扫')
      + (my.enabled ? kpi(when(sw.mysql), '用户库 · 上次清扫') : '')
      + kpi(when(sw.redis) + (sw.redis && sw.redis.deleted ? ' · −' + fmtInt(sw.redis.deleted) : ''),
            'Redis 离场房快照 · 上次回收')
      + '</div>';
    const off = v => (v > 0 ? fmtInt(v) : '关');
    h += '<div class="st-eff mut">当前生效:历史保留 <b>' + (ef['retention.days'] > 0 ? ef['retention.days'] + ' 天' : '永久')
      + '</b> · 登录流水 <b>' + (ef['userauth.log_retention_days'] > 0 ? ef['userauth.log_retention_days'] + ' 天' : '永久')
      + '</b> · 流水行数上限 <b>' + off(ef['userauth.log_max_rows'])
      + '</b> · 未支付订单 <b>' + (ef['userauth.jf_order_unpaid_retention_days'] > 0 ? ef['userauth.jf_order_unpaid_retention_days'] + ' 天' : '永久')
      + '</b> · 管理审计(会话类)<b>' + (ef['retention.audit_days'] > 0 ? ef['retention.audit_days'] + ' 天' : '永久')
      + '</b> · 离场房回收 <b>' + (ef['retention.state_gc'] ? '开' : '关')
      + '</b> —— 默认值即安全值。改动走<a href="#/params" style="color:var(--brand)">参数中心</a>「数据保留」板块;'
      + '其中<b>登录流水保留、流水行数上限、管理审计保留</b>会删除审计证据,管理台只读,需改服务器 <code>.env</code> 后重启 web。</div>';
    h += stTable('观测库 · PostgreSQL', pg.tables.length + ' 张表', pg.tables,
      {tasks: Object.assign({}, (sw.pg || {}).tasks, swk.tasks)});
    h += my.enabled
      ? stTable('用户库 · MySQL(guantai_* 新表;既有 tb_user 等只读不碰)', my.tables.length + ' 张表', my.tables, sw.mysql)
      : '<h3 class="st-h">用户库 · MySQL</h3><div class="empty">未启用登录系统(STA_USERDB_HOST 为空)—— 用户库各表不存在,无需清理。</div>';
    const el = $('#stBody');
    if (!el) return;
    el.outerHTML = '<div id="stBody">' + h + '</div>';
    $('#stRefresh').addEventListener('click', () => draw(true));
    $('#stSweep').addEventListener('click', async () => {
      const ok = await ask({title: '立即清扫一轮?',
        body: '按当前保留策略删除已经过期的数据 —— 与定时清扫完全相同,只是不等下一个周期。'
          + '删除不可恢复:若刚改过保留期,请先确认数值无误。', yes: '清扫'});
      if (!ok) return;
      busy = true;
      const b = $('#stSweep');
      if (b) { b.disabled = true; b.textContent = '清扫中…'; }
      try {
        const r = await api('/storage/sweep', {method: 'POST', body: '{}'});
        if (r.running) toast('积压较多,清扫已转入后台继续;本页会自动刷新结果');
        else {
          const res = r.result || {};
          const n = ['pg', 'mysql', 'redis'].reduce((a, k) => a + ((res[k] && res[k].deleted) || 0), 0);
          const bz = ['pg', 'mysql', 'redis'].some(k => res[k] && res[k].busy);
          toast(bz ? '定时清扫正在进行,本次未重复执行' : '清扫完成:共删除 ' + fmtInt(n) + ' 条');
        }
      } catch (e) {
        if (!(e && e.status === 401)) toast('清扫失败:' + errText(e, '网络错误'), 'err');
      }
      busy = false;
      await draw(true);
    });
  };
  await draw(false);
  S.timers.push(setInterval(() => { if (!document.hidden && !busy) draw(false); }, 30000));
}

function renderDeploy() {
  let h = '<div class="view-title">部署层(只读)</div>'
    + '<div class="view-sub">这些参数天然属于文件/编排层 —— 中枢诚实陈列并指路,不假装能写(方案 §8)</div>'
    + '<div class="pgrid">';
  for (const it of (S.schema.deploy || []))
    h += '<div class="pcard"><div class="phead"><span class="plabel">' + esc(it.label)
      + '</span><span class="pkey">' + esc(it.key) + '</span></div>'
      + '<div class="pmeta">' + esc(it.desc) + '</div>'
      + '<div class="pvalue-ro" style="margin-top:8px">改动位置:' + esc(it.where) + '</div></div>';
  h += '</div>';
  $('#main').innerHTML = h;
}

/* ───────── 启动装配 ───────── */
function boot() {
  $('#loginBtn').addEventListener('click', doLogin);
  $('#pw').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.isComposing) doLogin(); });
  // 1.10.0:账号框回车 → 跳到密码框(已填密码则直接登录);<form> 只为让浏览器的密码管理器
  // 认出「账号 + 密码」这一对,提交仍走上面的按钮 / 回车,原生 submit 一律拦下。
  $('#un').addEventListener('keydown', e => {
    if (e.key !== 'Enter' || e.isComposing) return;
    e.preventDefault();
    if ($('#pw').value) doLogin(); else $('#pw').focus();
  });
  $('#loginForm').addEventListener('submit', e => e.preventDefault());
  $('#logoutBtn').addEventListener('click', async () => {
    try { await api('/logout', {method: 'POST'}); } catch (_) {}
    clearSession();             // 含 sta_admin_exp:主动登出即刻失忆,不吃 30 天保持
    showLogin('已登出');
  });
  $$('.nav-item').forEach(b => b.addEventListener('click', () => switchView(b.dataset.view)));
  $('#drawerBtn').addEventListener('click', openDrawer);
  $('#dClose').addEventListener('click', closeDrawer);
  $('#searchOpen').addEventListener('click', openPalette);
  document.addEventListener('keydown', e => {
    // 顶层模态(ask/help)开启时,⌘K 不应在其下方偷偷打开搜索面板
    // (z-index:ask 90 / help 85 > palette 80);否则 Esc 关掉模态后会露出幽灵面板。
    const modalOpen = $('#ask').classList.contains('open')
                   || $('#help').classList.contains('open');
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      if (S.schema && !modalOpen) openPalette();
    } else if ((e.key === 'Enter' || e.key === ' ')
               && e.target.closest && e.target.closest('.seal-chain')) {
      // 玺印键盘可达(1.1.0):此前 tabindex=0 能聚焦却无按键处理,
      // 键盘用户停在印链上无法展开来源弹层。复用既有 click 分发路径。
      e.preventDefault(); e.target.closest('.seal-chain').click();
    } else if (e.key === 'Escape') {
      // 按层级关闭最上层浮层:对话框 > 帮助 > 玺印弹层 > 搜索/抽屉
      if ($('#ask').classList.contains('open')) { askDone(null); return; }
      if ($('#help').classList.contains('open')) { $('#help').classList.remove('open'); return; }
      const sw = $('.seal-wrap.open');
      if (sw) { sw.classList.remove('open'); return; }
      closePalette(); closeDrawer();
    }
  });
  // ask 对话框
  $('#askYes').addEventListener('click', () =>
    askDone($('#askI').hidden ? true : $('#askI').value));
  $('#askNo').addEventListener('click', () => askDone(null));
  $('#ask').addEventListener('click', e => { if (e.target.id === 'ask') askDone(null); });
  $('#askI').addEventListener('keydown', e => {
    // 1.4.3 同类扫尾:askI 承接**中文别名**输入(名录改别名走此弹窗)——
    // 组字选词的 Enter 不是提交;缺守卫会把打到一半的别名直接确认存库
    // (与 rmQ/blkUids 既有范式对齐;A10 横扫当年漏了本处与 palInput/#pw)。
    if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); $('#askYes').click(); }
  });
  // 帮助与图例
  $('#helpBtn').addEventListener('click', () => $('#help').classList.add('open'));
  $('#helpX').addEventListener('click', () => $('#help').classList.remove('open'));
  $('#help').addEventListener('click', e => {
    if (e.target.id === 'help') $('#help').classList.remove('open');
  });
  $('#palInput').addEventListener('input', e => palRender(e.target.value));
  $('#palInput').addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { palIdx = Math.min(palIdx + 1, palItems.length - 1); }
    else if (e.key === 'ArrowUp') { palIdx = Math.max(palIdx - 1, 0); }
    else if (e.key === 'Enter') { if (!e.isComposing) palGo(palIdx); return; }
    else return;
    e.preventDefault();
    $$('#palList li').forEach((li, i) => li.classList.toggle('on', i === palIdx));
  });
  $('#palList').addEventListener('click', e => {
    const li = e.target.closest('li[data-i]'); if (li) palGo(+li.dataset.i);
  });
  $('#palette').addEventListener('click', e => { if (e.target.id === 'palette') closePalette(); });
  window.addEventListener('hashchange', () => {
    const v = location.hash.replace(/^#\/?/, '');
    if (VIEWS[v] && v !== S.view && S.schema) switchView(v);
  });
  updateDrawerBtn();
  // 首屏:修复 [hidden] 后登录浮层初始真正隐藏,/session 探测期间会短暂白屏
  // (此前因浮层 bug 恒显被掩盖)。无本地令牌 ≈ 必然要登录 —— 立即亮出登录框,
  // 慢网络下不白等;若 HttpOnly cookie 尚在且恢复成功,enterShell 会正常盖切。
  // 有令牌则保持静默恢复,已登录用户刷新不闪登录框。
  if (!S.tok) showLogin('');
  // 1.10.0:地址带 #t=<票据> = 应急登录链接;先把票据从地址栏抹掉再去兑换
  const tk = /^#t=([A-Za-z0-9_.-]{40,1024})$/.exec(location.hash || '');
  if (tk) {
    try { history.replaceState(null, '', location.pathname + location.search); }
    catch (_) { try { location.hash = ''; } catch (__) {} }
    loginWithTicket(tk[1]);
  } else tryResume();
}
/* ───────── 1.7.5 触屏提示总线(tap-to-reveal) ─────────
   触屏浏览器不渲染 title,本台却把 31 处说明全押在上面。此处补一条通道:
     · <html data-input> 按最后一次 pointerdown 的 pointerType 标记 —— 媒体查询
       单独用会漏触屏笔记本(hover:hover + pointer:coarse)与接了妙控板的 iPad;
     · 单击(不是长按 —— 长按在 iOS 会抢系统选择/放大镜)唤出;必须把「点」与
       「滑」分开,否则表格与列表每滚一次都弹卡;
     · 气泡 pointer-events:none 且永不 preventDefault,原有 click 语义一条不改
       (这正是本文件 toast 那轮踩过的坑:淡出后仍 pointerEvents=auto 吃掉点击)。 */
const TIP_TAP_SLOP = 10, TIP_TAP_MS = 600, TIP_HOLD = 4200;
let tipEl = null, tipAnchor = null, tipPrev = null, tipT = 0, tipFollowRaf = 0;
let tipX = 0, tipY = 0, tipAt = 0;

function tipSetInput(kind) {
  const v = (kind === 'touch' || kind === 'pen') ? 'touch' : 'mouse';
  if (document.documentElement.dataset.input !== v) document.documentElement.dataset.input = v;
}
const tipIsTouch = () => document.documentElement.dataset.input === 'touch';

function tipHide() {
  clearTimeout(tipT); tipAnchor = null;
  if (tipEl) tipEl.hidden = true;
}
function tipPlace(r) {
  const bw = tipEl.offsetWidth, bh = tipEl.offsetHeight;
  const below = r.top < bh + 16;                            // 上方放不下 → 翻下方
  tipEl.classList.toggle('is-below', below);
  const cx = Math.max(bw / 2 + 8, Math.min(r.left + r.width / 2, innerWidth - bw / 2 - 8));
  tipEl.style.left = Math.round(cx) + 'px';
  tipEl.style.top = Math.round(below ? r.bottom : r.top) + 'px';
}
/* 滚动时跟随锚点而非一律收掉 —— 带 scroll-behavior:smooth 的容器在程序化滚动时
   会持续派发 scroll(Firefox 实测单次动画长达 1.4s),一律收会把用户刚点出的气泡
   在同一毫秒掐掉。锚点真的滚出视口/被移除才收。与 app.js 4.9.4 同策。 */
function tipFollow() {
  if (!tipAnchor) return;
  if (!tipAnchor.isConnected) return tipHide();
  const r = tipAnchor.getBoundingClientRect();
  if (!r.width || !r.height) return tipHide();
  if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) return tipHide();
  tipPlace(r);
}
function tipShow(el) {
  const txt = (el.getAttribute('title') || '').trim();
  if (!txt) return;
  const own = (el.textContent || '').replace(/\s+/g, '');
  if (own.indexOf(txt.replace(/\s+/g, '')) >= 0) return;   // title 与正文重合 → 不弹
  const r = el.getBoundingClientRect();
  if (!r.width || !r.height) return;
  tipEl.textContent = txt; tipEl.hidden = false;
  tipEl.classList.remove('is-below');
  tipEl.style.left = '0px'; tipEl.style.top = '0px';
  tipPlace(r);
  tipAnchor = el;
  clearTimeout(tipT); tipT = setTimeout(tipHide, TIP_HOLD);
}
function initTipBus() {
  tipSetInput((matchMedia('(hover:none)').matches || matchMedia('(pointer:coarse)').matches) ? 'touch' : 'mouse');
  tipEl = document.createElement('div');
  tipEl.className = 'tip-bubble'; tipEl.id = 'tipBubble';
  tipEl.setAttribute('role', 'tooltip'); tipEl.hidden = true;
  document.body.appendChild(tipEl);
  document.addEventListener('pointerdown', e => {
    tipSetInput(e.pointerType);
    // 非主指针整条排除:捏合时第二指既会误弹,又会覆盖 tipX/tipY/tipAt 把主指的
    // 点/滑判据污染成"滑动"(与 app.js 4.9.4 同策,详见那里的长注)。
    if (!e.isPrimary) return;
    tipX = e.clientX; tipY = e.clientY; tipAt = Date.now();
    tipPrev = tipAnchor; if (tipAnchor) tipHide();
  }, { capture: true, passive: true });
  document.addEventListener('pointerup', e => {
    if (!e.isPrimary) return;
    if (!tipIsTouch()) return;
    if (Date.now() - tipAt > TIP_TAP_MS) return;
    if (Math.abs(e.clientX - tipX) > TIP_TAP_SLOP || Math.abs(e.clientY - tipY) > TIP_TAP_SLOP) return;
    const t = e.target instanceof Element ? e.target : null; if (!t) return;
    if (t.closest('#tipBubble')) return;
    const host = t.closest('[title]');
    if (!host || host.tagName === 'IFRAME') return;
    if (host === tipPrev) { tipPrev = null; return; }        // 再点同处 = 收
    tipShow(host);
  }, { capture: true, passive: true });
  addEventListener('scroll', () => {
    if (!tipAnchor || tipFollowRaf) return;
    tipFollowRaf = requestAnimationFrame(() => { tipFollowRaf = 0; tipFollow(); });
  }, { capture: true, passive: true });
  addEventListener('resize', () => { if (tipAnchor) tipFollow(); }, { passive: true });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') tipHide(); });
}
initTipBus();
boot();
