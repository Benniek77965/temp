/**
 * round-engine.js — 回合引擎(观测台与模拟游戏共用的唯一数据源)
 * ------------------------------------------------------------------
 * 2.8.0 自 mock/mock-api.js 抽出:房间名录、九法配置、录制历史、回合
 * 时钟与出怪生成全部集中于此,暴露为 window.RoundEngine。
 *
 *   · 观测台:mock/mock-api.js 基于本引擎应答全部 /api/*(含 SSE);
 *   · 模拟游戏:jiufa/sim-engine.js 直接取 **父页面同一个引擎实例**
 *     (iframe 同源),盘面倒计时 / 每一局开出的妖兽与观测台序列、
 *     战况、出怪规律逐局一致 —— 「同一套数据」由共享对象保证,而非两边
 *     各算一遍再对表。独立打开 /jiufa/ 时才会另行装载本文件自成引擎。
 *
 * 与 2.7.x 引擎的唯一行为差异(为共享而做):
 *   出怪改为「无状态定局」—— 每一局的结果 = f(房号, 该局起始毫秒),
 *   用 mulberry32(hash(alias@start)) 按官方概率抽样,与生成顺序、
 *   页面存续、调用方无关。由此:
 *     ① 任何时刻、任何调用方对同一局求值,结果恒等(模拟游戏结算、
 *        跨刷新补结算与观测台展示三处天然一致);
 *     ② 旧引擎按序消耗随机流(rand),两处实例各自推进即分叉,
 *        无法共享。录制的 321 真实历史仍按原样回放,不受影响。
 *
 * 模拟规则(与录制数据一致,原样保留):
 *   - 每局 50s:0-35s 施法期 → 40s 出怪 → 50s 结束,下一局立刻开始
 *   - 房间 321 使用录制的 1734 局真实历史(时间整体平移到「现在」;
 *     录制相邻步进实测恒为 50001ms,原样保留;引擎推进的新局按 50000ms)
 *   - 其他房间按官方概率、以房号+局起点为种子生成 24h 历史
 *   - 出怪后 ~2s 才出现在 history(录制值≈2s)
 */
(function () {
  'use strict';
  if (window.RoundEngine) return;   // 幂等:重复装载(如 iframe 兜底)不重建

  /* ================= 常量(与录制数据吻合) ================= */
  var ROUND_MS = 50000;          // 每局时长
  var SPELL_OFF = 35000;         // 施法截止 = start + 35s
  var DRAW_OFF  = 40000;         // 出怪 = start + 40s
  var END_OFF   = 50000;         // 结束 = start + 50s
  var REVEAL_LAG = 2000;         // 出怪后多久出现在 history(录制值≈2s)
  var HISTORY_WINDOW = 24 * 3600 * 1000;

  var DATA_BASE = '/mock/data/';

  /* ================= 工具 ================= */
  function nowMs() { return Date.now(); }
  // 可复现随机数(mulberry32)
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function hashStr(s) {
    var h = 2166136261;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }

  /* ================= 静态数据加载(同步 XHR,保证先于业务请求就绪) ================= */
  function loadJSON(name) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', DATA_BASE + name, false); // sync — 仅本地小文件,页面启动一次
    xhr.send(null);
    if (xhr.status >= 200 && xhr.status < 300) return JSON.parse(xhr.responseText);
    throw new Error('mock data missing: ' + name);
  }

  var D = {
    liveRooms:       loadJSON('live-rooms.json'),
    crawlerStatus:   loadJSON('crawler-status.json'),
    roomSummary:     loadJSON('room-321-summary.json'),
    roomConfig:      loadJSON('room-321-config.json'),
    roomProfile:     loadJSON('room-321-profile.json'),
    rounds321:       loadJSON('room-321-rounds.json') // 升序 start_time_ms
  };

  /* ================= 法术表(观测台九法配置 = 模拟游戏妖兽表) ================= */
  var SPELLS = D.roomConfig.spells.map(function (s) {
    return {
      beast_id: s.beast_id, beast_name: s.beast_name,
      spell_key: s.spell_key, spell_name: s.spell_name,
      display_number: s.display_number, multiplier: s.multiplier,
      probability: s.probability,
      p: parseFloat(s.probability) / 100
    };
  });
  /* 概率是**出怪抽样的权重**，不是展示字段 —— 坏数据必须当场炸，不能静默换个盘面。
     实测原版行为（jsdom 装真实文件 + 注入坏配置）：
       · 九项里**只坏一项** → NaN 污染下面 pickAt 的 acc，`r < acc` 恒假，
         1728 局 **100% 开出号位9 沧溟龙(×500)**，全程不抛错；
       · 各项合法但合计仅 50% → 号位9 从 2.0% 静默抬到 **50.9%**（无 NaN、无报错，
         纯隐形偏置 —— 这一类比 NaN 更难发现）。
     判据与后端 web._probability_ok / 前端 officialProb 同口径：有限且 0<p≤100，
     且九项合计必须是 100%（逐项合法 ≠ 整体成立）。抛出后由 jiufa/jf-boot.js 的
     「死端 D」守卫接管（掐断请求泄漏、有界重试、交父页失败提示）。 */
  (function checkSpellProbabilities() {
    var total = 0;
    for (var i = 0; i < SPELLS.length; i++) {
      var pv = SPELLS[i].p * 100;
      if (!isFinite(pv) || !(pv > 0) || pv > 100) {
        throw new Error('round-engine: 号位' + SPELLS[i].display_number +
          ' 的 probability 不可用(' + JSON.stringify(SPELLS[i].probability) +
          ') —— 它是出怪抽样权重，拒绝以失真盘面启动');
      }
      total += pv;
    }
    if (Math.abs(total - 100) > 0.01) {
      throw new Error('round-engine: 九法概率合计 ' + total.toFixed(2) +
        '% ≠ 100% —— 逐项合法不代表整体成立，拒绝以失真盘面启动');
    }
  }());

  var SPELL_BY_BEAST = {};
  SPELLS.forEach(function (s) { SPELL_BY_BEAST[s.beast_id] = s; });

  /* 无状态定局:结果 = f(房号, 局起始毫秒)。同一 (alias, start) 恒等。 */
  function pickAt(alias, startMs) {
    var r = rng(hashStr(String(alias) + '@' + String(startMs)))();
    var acc = 0;
    for (var i = 0; i < SPELLS.length; i++) {
      acc += SPELLS[i].p;
      if (r < acc) return SPELLS[i];
    }
    return SPELLS[SPELLS.length - 1];
  }

  /* ================= 全局回合时钟 =================
   * 把录制的最后一局平移到「页面打开前 8 秒开始」,之后按 50s 步进,
   * 让倒计时/出怪立即活起来。模拟游戏共享同一实例,天然同钟同局。
   */
  var RECORDED_LAST_START = D.rounds321[D.rounds321.length - 1].start_time_ms;
  var BOOT = nowMs();
  var OFFSET = (BOOT - 8000) - RECORDED_LAST_START; // 所有录制时间统一 + OFFSET

  function currentRoundStart(anchorStart) {
    // 距 anchor 的整 50s 步进,返回「当前进行中」这一局的 start
    var t = nowMs();
    var n = Math.floor((t - anchorStart) / ROUND_MS);
    if (n < 0) n = 0;
    return anchorStart + n * ROUND_MS;
  }

  /* ================= 房间引擎 ================= */
  // alias -> engine
  var engines = {};

  // 从 live-rooms 建 alias/roomId 双向索引
  var roomIndex = {};
  (D.liveRooms.rooms || []).forEach(function (r) {
    roomIndex[String(r.alias)] = r;
    roomIndex[String(r.roomId)] = r;
  });

  function shiftRound(r, extra) {
    var s = r.start_time_ms + OFFSET + (extra || 0);
    return {
      round_id: String(s),
      beast_id: r.beast_id, beast_name: r.beast_name,
      spell_key: r.spell_key, spell_name: r.spell_name,
      display_number: r.display_number, multiplier: r.multiplier,
      start_time_ms: s,
      spell_time_ms: s + SPELL_OFF,
      draw_time_ms:  s + DRAW_OFF,
      end_time_ms:   s + END_OFF,
      source: r.source || 'GameHistory',
      captured_at: new Date(s + DRAW_OFF + REVEAL_LAG).toISOString()
    };
  }

  function makeRound(start, spell, source) {
    return {
      round_id: String(start),
      beast_id: spell.beast_id, beast_name: spell.beast_name,
      spell_key: spell.spell_key, spell_name: spell.spell_name,
      display_number: spell.display_number, multiplier: spell.multiplier,
      start_time_ms: start,
      spell_time_ms: start + SPELL_OFF,
      draw_time_ms:  start + DRAW_OFF,
      end_time_ms:   start + END_OFF,
      source: source || 'RoundAward',
      captured_at: new Date(start + DRAW_OFF + REVEAL_LAG).toISOString()
    };
  }

  function getEngine(key) {
    var alias = String(key || '').trim();
    var info = roomIndex[alias];
    var canonical = info ? String(info.alias) : alias;
    if (engines[canonical]) return engines[canonical];

    var e = {
      alias: canonical,
      roomId: info ? String(info.roomId) : canonical,
      nickname: info ? (info.nickname || canonical) : canonical,
      avatar: info ? (info.avatar || '') : '',
      jitter: hashStr(canonical) % 1500,       // 各房间相差 0-1.5s,贴近真实
      rounds: [],                              // 升序
      lastGenStart: 0
    };

    var anchorLast = RECORDED_LAST_START + OFFSET + e.jitter; // 该房间「录制末局」的平移起点

    if (canonical === '321') {
      e.rounds = D.rounds321.map(function (r) { return shiftRound(r, e.jitter); });
    } else {
      // 生成 24h 合成历史:与末局对齐,往回按 50s 生成(逐局无状态定局)
      var count = Math.floor(HISTORY_WINDOW / ROUND_MS); // 1728 局
      var arr = new Array(count);
      for (var i = 0; i < count; i++) {
        var start = anchorLast - (count - 1 - i) * ROUND_MS;
        arr[i] = makeRound(start, pickAt(canonical, start), 'GameHistory');
      }
      e.rounds = arr;
    }
    e.lastGenStart = e.rounds[e.rounds.length - 1].start_time_ms;
    engines[canonical] = e;
    return e;
  }
  function asEngine(x) { return (x && x.rounds) ? x : getEngine(x); }

  // 补齐从 lastGenStart 到「最近一局已开始」的所有新局
  function advance(e) {
    e = asEngine(e);
    var target = currentRoundStart(e.lastGenStart);
    while (e.lastGenStart < target) {
      e.lastGenStart += ROUND_MS;
      e.rounds.push(makeRound(e.lastGenStart, pickAt(e.alias, e.lastGenStart)));
      if (e.rounds.length > 5000) e.rounds.splice(0, e.rounds.length - 5000);
    }
    return e;
  }

  // 已「可见」的局:出怪 + 2s 之后(新 → 旧)
  function revealedRounds(e) {
    e = advance(e);
    var t = nowMs();
    var out = [];
    for (var i = e.rounds.length - 1; i >= 0; i--) {
      var r = e.rounds[i];
      if (r.draw_time_ms + REVEAL_LAG <= t) out.push(r);
    }
    return out;
  }

  function liveTimer(e) {
    e = advance(e);
    var start = currentRoundStart(e.lastGenStart);
    return {
      currentRoundId: String(start),
      serverOffsetMs: 0,
      roundStartTimeMs: start,
      spellTimeMs: start + SPELL_OFF,
      drawTimeMs:  start + DRAW_OFF,
      endTimeMs:   start + END_OFF
    };
  }

  /* 某局的定局结果:引擎已生成该局(录制/合成/推进)则取实录,
     否则退回无状态定局。模拟游戏结算与跨刷新补结算共用此口。
     2.8.1 加固:索引直算仅作快路径 —— 321 的录制历史实测相邻步进为
     50001ms(非 50000),1733 局累计漂移 1.7s,Math.round 目前仍能
     命中,但这是踩在数据运气上;录制数据若有任何缺局会令索引整体
     错位。快路径以「精确相等」验证,未中则升序二分兜底,对任意
     非等距历史恒正确。 */
  function findRound(alias, startMs) {
    var e = advance(alias);
    var arr = e.rounds;
    if (!arr.length) return null;
    // 快路径:合成房恒等距,索引直算 O(1);验证不过再走慢路径
    var i = Math.round((startMs - arr[0].start_time_ms) / ROUND_MS);
    if (i >= 0 && i < arr.length && arr[i].start_time_ms === startMs) return arr[i];
    // 慢路径:升序二分 O(log n),精确命中才返回
    var lo = 0, hi = arr.length - 1;
    while (lo <= hi) {
      var mid = (lo + hi) >> 1, s = arr[mid].start_time_ms;
      if (s === startMs) return arr[mid];
      if (s < startMs) lo = mid + 1; else hi = mid - 1;
    }
    return null;
  }
  function resultFor(alias, startMs) {
    var hit = findRound(alias, startMs);
    if (hit) return SPELL_BY_BEAST[hit.beast_id] || pickAt(alias, startMs);
    return pickAt(alias, startMs);
  }

  window.RoundEngine = {
    version: '2.8.4',
    T: { ROUND: ROUND_MS, CAST: SPELL_OFF, DRAW: DRAW_OFF, END: END_OFF, REVEAL: REVEAL_LAG },
    data: D,
    spells: SPELLS,
    spellByBeast: SPELL_BY_BEAST,
    roomIndex: roomIndex,
    boot: BOOT,
    nowMs: nowMs,
    hashStr: hashStr,
    rng: rng,
    pickAt: pickAt,
    getEngine: getEngine,
    advance: advance,
    revealedRounds: revealedRounds,
    liveTimer: liveTimer,
    findRound: findRound,
    resultFor: resultFor,
    currentRoundStart: currentRoundStart
  };
})();
