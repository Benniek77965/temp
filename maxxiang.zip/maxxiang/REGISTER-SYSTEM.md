# 注册系统 —— 前端自助注册 · 防恶意注册纵深

> **5.3.0 起后台入口可配**:页面在 `/{入口}`、管理接口在 `/api/{入口}/*`,`{入口}` = `config.yaml` 的 `admin.path`(默认 `admin-xdd`,`.env` 的 `STA_ADMIN_PATH` 可覆盖)。本文中的 `{入口}` 均指它;旧地址 `/admin`、`/admin.html`、`/api/admin/*` 按不存在的路径应答。唯一例外:外部发卡接口 `POST /api/admin/jfvip/cards/issue` 是机器契约,地址恒定。详见根 `README.md`「管理后台:入口、账号与人机验证」。

> 一句话:给「九法观测台」加**前端自助注册**,写入与你既有注册/续费系统同一份
> 用户库(`fanxing_changkong_user_db.tb_user`),并以**九层纵深(R0–R8)**把恶意
> 批量注册的**产出压到 ≈0、速率压到有界、总量压到有顶**。
> **不配置即不存在**:`STA_USER_REG_MODE=off`(默认)时,注册面整体不存在,
> 系统与未引入本功能前逐字节同行为。
>
> 全部结论基于对源码的逐文件实地核查(核查清单见 §1),外部事实(验证码大陆
> 可用性)已联网复核。
>
> **口令规则(运营已拍板)**:注册口令 **5–16 位字符,无字符组合限制**——不强制
> 大小写/数字/符号搭配,纯数字亦可。技术性底线仅两条:禁控制字符;`plain` 形态
> 须 gbk 可编码(列的物理约束)。
>
> **验证方式**:1:1 本地 MariaDB 复刻真库(gbk + gbk_bin + 多形态口令)上跑通全部
> 联测;前端在 jsdom 真 DOM 中以**交付版 index.html + app.js** 跑通整条注册链,
> 并对**混淆后的部署产物**再跑一遍(证明 Worker 源码经 terser+obfuscator 的
> `splitStrings`/RC4 字符串编码后仍然可用)。

---

## 0. 方案总览(一张图)

```
                    ┌──────────────────────────────────────────────────────┐
 浏览器(注册态)──►│  R4 表单侧:蜜罐字段 + 最短填表时长                   │ 廉价初筛
                    │  R2 双证明:powAnswer(混淆JS) ⊕ SHA-256 前导零 PoW   │ 抬价·自适应难度
                    │  R3 人机验证(可插拔:腾讯云/极验/Turnstile,默认关) │ 可选外挂
                    ├──────────────────────────────────────────────────────┤
 POST /api/auth/    │  R1 服务端限流:挑战签发/注册尝试 按IP·按名·全局      │ 确定性削平
   register         │  R5 账号形态闸:用户名字符集/长度/口令/保留名         │ 确定性拒绝
                    │  R0 经济闸:注册零赠送 或 邀请码携带时长(核心)      │ 产出≈0
                    │  R6 全局熔断:小时/日总量顶格 → 自动降档 invite/关闸  │ 损失有上界
                    ├──────────────────────────────────────────────────────┤
 MySQL(单库事务) │  [占坑邀请码配额 → INSERT tb_user → INSERT 注册审计]  │ 原子一致
                    ├──────────────────────────────────────────────────────┤
 管理台「注」视图   │  R7 观测处置:注册流水/邀请码 CRUD/可疑聚类/观测台封禁│ 人工兜底
                    │  R8 设备指纹摘要:纯软信号,超限只升 PoW 难度         │ 线索不判决
                    └──────────────────────────────────────────────────────┘
```

「天花板」的本质不是某一层"绝对挡住",而是三条不可绕的结构性保证:
**① 攻了也白攻**(R0:空壳账号既进不了门也读不到任何数据)、
**② 攻得再快也有界**(R1/R2/R6:速率与总量双顶格)、
**③ 攻穿了有止损**(R6 熔断 + R7 一键处置)。其余各层负责把绝大多数攻击
在到达这三条保证之前就低成本地筛掉。

---

## 1. 实地核查结论(方案的地基,逐条可复验)

以下每条均经源码逐行核实,注册系统的设计**逐条依赖**它们:

| # | 核查结论 | 出处 |
| --- | --- | --- |
| C1 | 登录守卫对 `/api/auth/` 前缀**整体豁免**会话与 CSRF 头(`_EXEMPT_PREFIX`)——新增 `/api/auth/register*` 端点天然可在未登录态访问,**零改守卫** | `app/userauth.py` guard() 段,`_EXEMPT_PREFIX = ("/api/auth/",)`(管理面的豁免 5.3.0 起跟随入口路径,见 `_exempt()`) |
| C2 | 登录失败节流已有成熟范式:按「用户名 hash / 来源 IP」双维 Redis 计数(`guantai:lf:*`),Redis 抖动**退化为进程内计数而非放开**;web 镜像 CMD 钉死单 uvicorn worker,进程内兜底计数在单进程内自洽 | `userauth.py` `_throttled/_fail_bump`(5.2.0 起为 `_lg_admit` 防爆破闸门 + `wincount` 原子计数,见 LOGIN-SYSTEM.md §4.5);README「关键工程决策」 |
| C3 | 节流 IP 来源可信度已有统一开关 `STA_USER_TRUST_XFF`(反代取 XFF 首跳 / 直连取 client.host)——注册限流**复用同一口径**,不另起炉灶 | `userauth.py` `client_ip()` |
| C4 | 执行证明变换 `powAnswer`(JS,`assets/app.js:551`)与 `_pow_answer`(Python,`app/web.py:656`)逐位一致,且有「活体对拍 + 黄金向量」双守卫(`tests/test_proof_of_browser.py`)——注册的浏览器执行证明**直接复用该变换与该测试手法** | 前后端两处源码 + 测试 |
| C5 | 既有 L2 挑战按**会话**存 Redis(`powchal:{sid}`,sid 派生自会话 Cookie)——注册时**没有会话**,故注册挑战必须独立键(`guantai:regchal:{id}`,单次性),不能复用 mint 端点 | `app/web.py` pow_mint/`_pow_sid` |
| C6 | 用户库写通道 `_q()` 是**逐语句 autocommit**(连接层错误换池重试一次)——注册的「占坑邀请码 + INSERT tb_user + 落审计」需要新增一个**单连接事务**helper(`_tx()`),恰好 `guantai_*` 与 `tb_user` 同库,单库事务天然原子 | `userauth.py` `_q()` 实现 |
| C7 | 口令校验自适应 明文/MD5/SHA1/SHA256(hex) 四形态、常数时间比较——**审计发现一处文档矛盾**:`pass_word` 各处注为 `varchar(50)`,而 SHA-256 hex 长 64 字符,**物理放不进 varchar(50)**。要么真实列更长、要么库里不可能存在 sha256 行。这不影响登录(校验按存量形态自适应),但**直接决定注册写入形态的可选空间**——预检工具必须读真实 DDL(§11)。**实施期实测**:在 1:1 复刻库上 `--reg-preflight` 正确读出 `varchar(50)` 并直接判定「sha256 放不下,只能选 plain/md5/sha1」,同时给出多数派建议值 | `userauth.py` 模块注释 / `LOGIN-SYSTEM.md` §3 / `verify_password()` |
| C8 | `user_name` 列 `gbk_bin`(大小写敏感)、连接 charset=gbk;代码注释称 user_name 为唯一键,但**唯一键的存在性未经程序化验证**——预检必须 `SHOW INDEX` 实测(§11);无唯一键时注册需 Redis 名义锁兜底并发重名 | `userauth.py` 注释 / `userdb_check.py` |
| C9 | `is_off` 封停判定取值可配(默认 `'1'`,settings 注释称库列 varchar(1));`due_time > NOW()` 用**数据库的钟**判活——注册写入 `is_off='0'`、`due_time=NOW()+赠送天数` 与登录侧判定口径天然一致 | `userauth.py` `_is_banned`/login SQL |
| C10 | 首登预置房经 `on_login_ok` 回调解耦(登录 200 前 await 完成)——「注册即登录」分支复用登录的会话下发 + 该回调,新注册用户进门即有 321 可看 | `userauth.py` on_login_ok / `web.py` lifespan 注册 |
| C11 | `_janitor()` 每日清扫过期会话与超保留期审计——注册审计表并入同一清扫任务,零新增后台任务 | `userauth.py` `_janitor()` |
| C12 | 管理台已有成熟范式:左栏视图(览/参/更/名/票/审/疑/署)、`/api/{入口}/*` 自有会话 + CSRF、运行时参数覆盖带 rev 收敛广播、审计落盘——「注」视图与注册模式热切换全部**复用既有机制** | `admin.html` / `admin_api.py` / `config_center.py` |
| C13 | 配置管道四层(代码默认 → config.yaml → 环境变量 → 运行时覆盖)与 `config_registry` 参数卡已就绪——`STA_USER_REG_*` 全family 按既有 `userauth.*` 组同款接入 | `settings.py` UserAuthCfg / `config_registry.py` userauth 组 |
| C14 | compose 的 web 服务 `env_file: .env` 全量注入——新增环境变量**不必**逐个写进 compose 的 environment 块即可生效(显式列出仅为文档性) | `deploy/docker-compose.yml` |
| C15 | 前端登录门为 `index.html:396` 的 `#authGate` 单卡结构,`app.js` 的 `AUTH/doLogin/setAuthMsg/lockApp` 全套已就绪;`api()` 统一附 `X-JF-Auth` 头;`/api/auth/session` 是前端开机首问——注册入口/表单/错误呈现全部在该骨架上扩展 | `index.html` / `assets/app.js` |
| C16 | 测试基建:1:1 本地 MariaDB 复刻真库(gbk + gbk_bin + 多形态口令)、`smoke_auth.py` 端到端、契约测试钉「前后端同值」——注册的三对齐钉子有现成跑道 | `LOGIN-SYSTEM.md` §7 / `tests/`、`scripts/smoke_auth.py` |
| C17 | 外部事实(联网复核):Turnstile 的 `challenges.cloudflare.com` 在大陆访问慢/不稳定,社区请求中国 CDN 未获满足——**不可作为大陆部署的主防线**;腾讯云行为验证码明确覆盖「阻止注册机批量注册小号」场景且拦截等级可调,极验同类——作为**可插拔选项**而非硬依赖(§5 R3) | 见文末「外部信源」 |

---

## 2. 用户库纪律的**红线重画**(已采纳并落地 · 附静态钉)

登录系统的原纪律是「对 `tb_user` **绝对只读**」,且 FAQ 明言"注册/续费仍由你既有
系统负责(它写 tb_user,我们读)"。前端自助注册意味着观测台**必须获得对
`tb_user` 的 INSERT 能力**——这是本方案唯一一处触碰既有红线的地方,故把修订
写成与旧纪律同等强度的**新纪律**,并配静态钉子(§13-T5)让它不可能被悄悄突破:

| 引入注册前的纪律 | 现行纪律 |
| --- | --- |
| `tb_user` 绝对只读:仅 SELECT | `tb_user` **旧行绝对零改动**:全项目**永远**没有任何 UPDATE / DELETE / ALTER / TRUNCATE 语句触及该表;仅当 `reg_mode ≠ off` 时存在**恰好一条** INSERT 语句(新行) |
| 新表全部 `guantai_` 前缀 | 不变(本方案新增三张 `guantai_` 新表,见 §6) |
| `sys_*` 零引用零触碰 | 不变(邀请码自建 `guantai_invite_code`,**不**复用同库任何既有卡密/代理表) |
| —— | **封禁不碰 tb_user**:观测台侧封禁走自有 `guantai_user_block` 表(§5 R7),`is_off` 的写权仍完全属于你的外部系统 |

配套要求:数据库账号需追加 `INSERT` on `tb_user` 权限(预检工具会实测,§11);
`reg_mode=off` 时即便权限在,代码路径也不含任何写 `tb_user` 的可达分支。

全项目对 `tb_user` 的 SQL 现状(静态扫描实测):
`SELECT` 三处(登录识别 / 会话复核 JOIN / 注册查重)、`INSERT` **恰一处**
(`app/userauth.py::_register_tx`)、`UPDATE/DELETE/ALTER/TRUNCATE` **零处**。
`tests/test_register.py::test_tb_user_sql_discipline` 扫描全部 `app/*.py`,
对该表的危险动词命中即红、INSERT 多于一处即红、唯一那处不在 `_register_tx`
里也红 —— 纪律是机器保证,不是口头承诺。

> 若你不愿重画这条红线,存在一个**零触碰替代**:注册写入自建
> `guantai_user`(观测台私有用户表),登录识别改为「tb_user ∪ guantai_user
> 双源」。代价:新用户**不存在于你的续费系统**,续费/管理两套账本从此分叉——
> 与"同一份账号"的既有立意相悖,故本方案**不推荐**,仅列作备忘。

---

## 3. 威胁模型与经济学(为什么这套是"天花板")

先把「恶意注册」拆成动机,再逐一让动机破产——**验证码堆得再高,不如让攻击
没有产出**:

| 攻击动机 | 攻击者拿到什么 | 本方案的釜底抽薪 |
| --- | --- | --- |
| 批量囤号搬运数据(最现实的动机:绕开单账号 4 QPS 限流与单活跃房租约,N 号并发) | N 个可登录账号 = N × (4 QPS + 1 活跃房) | **R0**:默认注册**零赠送时长**(`due_time=NOW()`),注册完的账号连登录都过不去(`expired` 403)——既有 L1–L4 防线约束的是"已登录者",而空壳号**到不了已登录态**。开放送体验时长的部署,体验天数就是唯一"战利品",由 R1/R2/R3/R6 联合定价 |
| 囤号转卖 / 薅体验期 | 带时长的账号 | invite 模式下时长只随**邀请码**发放:码有配额、有效期、可禁用——泄露损失有上界;open+体验模式下,体验天数默认 0,>0 时熔断器钳总量 |
| 撑爆用户库(垃圾行填充) | tb_user 行数膨胀、id 空耗 | R1 限流 + R6 全局日顶(默认 open 200/日、invite 随码配额)——**最坏情况下每天新增行数有硬上界**;R7 支持按注册批次一键观测台封禁(库行清理属外部系统职权,方案不越权) |
| 用户名占坑 / 仿冒(注册 `Admin` 仿 `admin`) | 混淆视听 | R5 保留名单 + 大小写折叠查重(仅约束新增,不追溯存量);gbk_bin 唯一键仍是最后闸。**4.0.6 追加**:字符集收窄为 `[A-Za-z0-9]` 后,全角同形字(`ＡＤＭＩＮ`)、带零宽/组合符的变体一并在形态闸内闭合 —— 这类字符 gbk 编码得了,旧规则是放行的 |
| 用注册端点做用户名枚举(探测哪些名字已存在) | 存量用户名清单 | 注册必须告知重名,枚举**无法消除**——但被定价:每次探测都要消耗一枚已解 PoW + 占用 IP 小时配额(默认 5 次/时),枚举 1 万名字 ≈ 数月;**刻意不提供**独立"查重"端点 |
| 短信轰炸他人(若接短信) | 骚扰第三方 | **R9 刻意不做短信验证**(§5 末),此攻击面整体不存在 |

---

## 4. 三档注册模式(总开关,运行时热切换)

`STA_USER_REG_MODE = off | invite | open`,经 config_registry 注册为热更参数
(管理台「注」视图一键切换,走既有 rev 收敛广播;环境变量层为部署基线):

| 模式 | 语义 | 适用 |
| --- | --- | --- |
| `off`(默认) | 注册端点回 503 `register_disabled`;前端不渲染任何注册入口;**全项目行为与未启用注册时逐字节一致**(关闭态契约测试钉住) | 现状延续、出问题时的一键回退 |
| `invite`(**推荐起步**) | 必须携带有效邀请码;码由管理台生成,四属性:**配额**(可用次数)、**有效期**、**赠送天数**(该码注册成功即获得的 due_time 增量,可为 0)、**备注**;可随时禁用 | 熟人分发 / 代理分发 / 灰度试运行。恶意注册在结构上**不可能**(无码寸步难行),码泄露损失 ≤ 配额 |
| `open` | 开放注册,吃满 R1–R6 全栈;赠送天数 = `STA_USER_REG_TRIAL_DAYS`(默认 **0**) | 确有拉新需求时。**强烈建议**:体验天数 >0 之前先接入 R3 国产验证码并确认 R6 阈值 |

前置条件:登录系统已启用(`STA_USERDB_HOST` 已配)——未启用登录时注册无意义,
`reg_mode` 非 off 会在启动日志醒目告警并按 off 运行。

---

## 5. 防御纵深 R0–R8(注册面专属;与既有 L1–L4 编号空间独立)

### R0 经济闸(核心,不可绕)

已到期账号在登录时被 403 `expired` 拦下(`due_time > NOW()` 由**数据库的钟**
判定,3.8.0 既有逻辑零改动)——因此「注册零赠送」不是一句口号,而是复用既有
硬闸的结构性事实:**空壳账号 = 不能登录 = 读不到一个字节的数据**。赠送天数的
三种来源与建议:invite 模式随码(码是运营者显式签发的"时长支票");open 模式
`STA_USER_REG_TRIAL_DAYS`(默认 0,改 >0 前先读 §14 边界);两者都为 0 时,
注册的全部产出是"一个等待续费开通的用户名"——攻击产出 ≈ 0。

### R1 服务端限流(确定性,Redis 计数 + 进程内兜底)

完全沿用登录失败节流的实现范式(C2/C3):INCR+EXPIRE 窗口计数(5.2.0 起由 Lua 一步完成,
EXPIRE 抖动不再留下永久键;IP 口径同步改为「可信代理」,见 LOGIN-SYSTEM.md §4.5)、
`STA_USER_TRUST_XFF` 决定 IP 口径、IPv6 按 /64 前缀分桶、Redis 故障退化为
进程内计数(**风控组件故障不放开注册**——注意这与明细读路径的 fail-open 哲学
**刻意相反**:fail-open 保护的是"正在使用中的真人读路径",而注册是低频身份
**写**路径且本身就是攻击面,协调层抖动时宁可让新注册稍候,绝不裸奔。挑战
无法落 Redis 时注册端点回 503 `register_unavailable`,已有会话的一切功能不受
影响):

| 闸 | 键 | 默认 | 说明 |
| --- | --- | --- | --- |
| 挑战签发/IP | `guantai:reg:chal:ip:{ip}` | 10 次 / 10 分钟 | 挑战是廉价 Redis 写,先钳签发 |
| 注册尝试/IP·时 | `guantai:reg:try:ip:{ip}` | 5 次 / 小时 | 含一切失败(重名/弱口令/PoW 错) |
| 注册尝试/IP·日 | `guantai:reg:tryd:ip:{ip}` | 10 次 / 日 | 双窗防慢速滴灌 |
| 成功注册/IP·日 | `guantai:reg:okd:ip:{ip}` | 2 个 / 日 | 真人极少一天注册第 3 个号 |
| 同名尝试 | `guantai:reg:name:{md5前16}` | 3 次 / 10 分钟 | 钳单名爆破/占坑拉锯 |
| 全局/时·日 | `guantai:reg:g:h:{时}` `…:d:{日}` | 见 R6 | 熔断器的输入 |

触限统一回 429 `throttled` + `Retry-After`(与登录节流同款语义)。审计写入
限幅:被节流的失败**每 IP 每窗口至多落一行**审计(Redis 去重键),防审计表
本身被打成写放大——手法与 worker `lastError`「每连败串首拍恰一次」同源。

**落地细节**:IPv6 按 `/64` 前缀分桶(`_ip_bucket`),难度阶梯的邻域桶
IPv4 取 `/24`、IPv6 取 `/64`(`_net24`);挑战文档里存的是**分桶后的**值,
提交时比对同一口径——换一个 IPv6 末位地址绕不开挑战绑定。

### R2 双证明(浏览器执行证明 ⊕ 工作量证明,自适应难度)

注册没有会话,不能复用 L2 的按会话挑战(C5),故独立一条链,且比 L2 多一重
**可调成本**:

①  `GET /api/auth/register/challenge` → 服务端 `secrets.token_hex(16)` 生成
    `salt`,连同当前难度 `bits`、签发时刻、IP 分桶存
    `guantai:regchal:{challengeId}`(TTL 默认 600s,**单次性**);
②  前端主线程算 `prefix = powAnswer(salt)`——既有混淆变换(C4),**证明真正
    执行了本站 JS**;把 `prefix` 交给内联 Worker(Blob 构造,不新增静态资源);
③  Worker 内纯 JS SHA-256(**刻意不依赖** WebCrypto——`crypto.subtle` 要求
    安全上下文,内网 http 部署会整段失效;纯 JS 实现对短输入也更快)穷举
    `nonce`,直至 `SHA-256(prefix + ':' + nonce)` 前导零位 ≥ `bits`;
    消息恒 ≤27 字节 < 56 → 走**单块快路径**(复用一块 64B 缓冲、循环内零分配,
    低端机也扛得住);
④  提交时携带 `{challengeId, nonce}`;服务端取键即删(GETDEL 语义,防重放)、
    校验 IP 分桶一致、重算 `_pow_answer(salt)`、**一次哈希**验前导零——服务端
    验证成本恒为 O(1),不对称性正确。

难度自适应(阶梯只升不降,随窗口滑动自然回落):基础 `bits=17`
(主流手机纯 JS ≈0.3–1.5s,真人无感;§14 有诚实的校准边界),同 /24 十分钟内
尝试 ≥3 → +2,≥6 → +4;全局小时计数越过熔断阈值 70% → 全站 +2;
R8 同指纹超限 → 该指纹 +4;硬顶 `bits=25`(数十秒——只有高压来源会尝到)。
当前难度回给挑战端点,前端如实显示"安全校验中…"进度。

为何是"⊕"而不是二选一:`powAnswer` 单独用是**常数成本**(逆向一次即可离线
批算);SHA-256 前导零单独用则**任何脚本一行调库就能算**(丢失"必须跑本站
JS"的语义)。两者串联:想批量注册,既要跑(或逆向)混淆 JS,又要按我们随时
上调的难度真实烧算力——而 salt 服务端随机签发,**无法预计算**。

### R3 人机验证(可插拔,默认关)

`STA_USER_REG_CAPTCHA = off | tencent | geetest | turnstile`。默认 off——
(5.2.0 起这一项是**注册与登录共用**的供应商;注册时要不要过由 `STA_USER_REG_CAPTCHA_REQUIRED`
决定,默认 1 = 要,与旧行为一致;登录何时要过见 LOGIN-SYSTEM.md §4.5)
保持本项目"自包含、零第三方运行时依赖"的一贯风格,R2 已提供基础人机成本;
确要开放注册(尤其 open+体验天数>0)时再插:

| 供应商 | 大陆可用性(联网复核) | 接入面 |
| --- | --- | --- |
| 腾讯云行为验证码 | 官方文档明确覆盖"登录注册:阻止注册机批量注册小号"场景,拦截等级可调(体验优先/平衡/安全优先) | 前端挂件容器 + 后端 `DescribeCaptchaResult` 二次校验 |
| 极验 GeeTest | 大陆主流行为验证,斗鱼/新浪等直播语境同行在用 | 同上模式(validate 二次校验) |
| Cloudflare Turnstile | `challenges.cloudflare.com` 在大陆**访问慢/不稳定**;2026-11 复核:Cloudflare 官方 China Network FAQ 已明文写「Turnstile 不支持中国大陆」——仅建议海外部署选用 | 前端挂件 + `siteverify`(5.2.0 起核对 `action=register`;同一套供应商与凭据也供登录使用,见 LOGIN-SYSTEM.md §4.5) |

统一契约:前端把供应商 token 放进注册 payload 的 `captchaToken`,后端按
provider 分发到对应校验器;校验器网络异常 → 回 503 `captcha_unavailable`
(同 R1 的 fail-closed 姿态);密钥只走环境变量(`STA_USER_REG_CAPTCHA_ID/KEY`),
管理台只读打码展示(与 `STA_USERDB_PASSWORD` 同款纪律)。

### R4 表单侧廉价初筛(蜜罐 + 时序)

①  **蜜罐字段**:注册表单渲染一个视觉与可达性上都不存在的输入
    (`position:absolute` 移出视口 + `tabindex=-1` + `aria-hidden="true"` +
    `autocomplete="off"`,字段名伪装成 `contact`)——真人永远不会填;有值即拒,
    审计 reason=`honeypot`,但**对外回通用失败文案**「注册失败,请稍后重试」,
    不教学;
②  **最短填表时长**:挑战签发时刻已存服务端(R2①),提交时校验
    `now - issued ≥ 3s`(可配)且 ≤ TTL——秒提交是脚本铁证。
诚实定位:两者都可被针对性绕过(不填隐藏字段、sleep 3 秒),它们的职责是
**零成本筛掉最懒的大多数**,不是防线主力——但正因为零成本,没有理由不设。

### R5 账号形态闸(输入校验,确定性)

| 项 | 规则 | 依据 |
| --- | --- | --- |
| 用户名 | 2–20 字符,**字符集仅 `[A-Za-z0-9]`**(运营拍板 4.0.6;**纯数字放行**)。一条正则同时吃掉空白、控制符、中文、emoji、全角字母与连字符下划线,文案统一为「用户名只能包含英文字母和数字」。**仅约束新增注册,绝不追溯存量** —— 登录侧 `_authenticate` 对用户名恒不做字符集校验,存量中文名与外部续费系统建的手机号型名(`+8613800138000` 这类)照常登录。字符集**写死为常量 `_REG_USER_RE`,刻意不入参数中心**:前端 `app.js` 拿不到热改值,可热改必然产生「后端已收窄、前端还在放行」的漂移(用户白付一次 PoW 才被打脸),同值性由 `test_frontend_backend_username_charset` 源码级对拍钉死。闸序「先长度、后字符集」——否则空输入会拿到字符集提示。禁保留名(内置 `admin/root/test/guest` 等,`STA_USER_REG_RESERVED` 可追加);名单里的中文条目**保留不删**,字符集一旦放宽即刻重新生效,但此后它们由字符集闸先行拦下、错误码为 `name_invalid`。20 字符 × ASCII 1 字节 = 20 字节,对 varchar(50) 余量充裕 | C7/C8 |
| 查重 | 事务内先 `SELECT`(精确 + ASCII 大小写折叠双查,防 `Admin` 仿 `admin`——仅约束新增,不追溯存量);唯一键存在时以捕获 1062 为最终闸;预检发现**无唯一键**时,额外以 `SET NX EX` Redis 名义锁(键=用户名 md5)桥接并发窗口 | C6/C8 |
| 口令 | **5–16 位字符,无字符组合限制**(运营拍板 D8):不强制大小写/数字/符号搭配,纯数字亦可,中文/空格/符号均放行。**刻意不设弱口令黑名单**——按要求「没有字符组合的限制」。技术性底线仅两条:① 禁控制字符(0x00–0x1F/0x7F:不可见、必属误输入或注入);② `plain` 形态须 gbk 可编码(`pass_word` 列是 gbk,emoji 物理存不下;摘要形态存 hex,天然无此约束)。摘要一律取口令 **UTF-8 字节**——与登录侧 `verify_password` 的 `s.encode('utf-8')` 逐字节同口径,保证注册的账号必然登得进(`test_password_encoding_matches_login_verify` 钉住) | C7 |
| 存储形态 | `STA_USER_REG_PASS_SHAPE = plain | md5 | sha1`(**必填**,无默认——预检工具按你库里的多数派形态给出建议值;不设则 reg_mode 强制视作 off 并启动告警)。**硬约束**:必须选你既有续费系统登录时能校验的形态,否则观测台注册的用户到你那边登录不进——这是跨系统契约,只有你能拍板(§15-D2)。sha256 是否可选取决于预检读到的真实列长(C7 的矛盾点)。**落地加固**:除预检外,运行期首次注册时另对 `information_schema` 实测一次列长并缓存——列长 <64 而配了 sha256 → 注册回 503 `register_unavailable` 并打醒目日志,**绝不**让 MySQL 非严格模式静默截断出「永远登不进」的脏行 | C7 |

如实声明:若多数派形态是 md5/明文,这是既有库的历史现实;登录侧已有节流 +
常数时间比较 + 审计缓解,本方案**不越权改表迁移**,仅在 §15 列一条改造建议
供未来采纳。

### R6 全局熔断(损失有上界的最后保证)

滑动计数(R1 表末两键)驱动两级动作,全部走既有 config_center 运行时覆盖
(rev 收敛广播,多进程即时一致,C12):

| 触发 | 动作 | 默认阈值 |
| --- | --- | --- |
| open 模式下,小时成功注册数**达到**上限 | 自动降档 `open → invite`,管理台横幅 + 审计落盘 + 「注」视图归因 | 30 / 小时 |
| 任意模式下,日成功注册数**达到**上限 | 当日直接 `→ off`(关闸),同上呈现 | open 200 / invite 500 / 日 |

**阈值语义的落地修正**:实现之初写作「**超过**阈值才降档」,联测暴露出这会放过
`阈值+1` 个注册 —— 与 §3「每天新增行数有**硬上界**」的承诺差一格。现改为
**达到即降档**,于是当日成功注册数的硬上界**恰等于阈值本身**
(`test_breaker_daily_closes` 钉住)。

**刻意不自动回升**:自动恢复会被脉冲式攻击当节拍器玩弄;恢复是管理台一次
显式点击(带确认),归因与时刻全程留痕。熔断状态对 Redis 故障 fail-closed
(计不出数 → 视作未触发?**否**——计数不可用时新注册本就已被 R1 的 503 拦住,
熔断器无输入也无洞)。

### R7 观测与处置(管理台「注」视图 + 观测台级封禁)

左栏新增「注」视图(与「疑」同级,复用管理台会话/CSRF/审计,C12),四块:
①  **总控**:三档模式热切换(危级确认)、熔断状态与手动恢复、今日/本周注册
    曲线、当前 PoW 难度水位;
②  **邀请码**:批量生成(条数/配额/有效期/赠送天数/备注)、列表(剩余配额/
    已用/过期/禁用)、一键禁用、导出 txt;码为 16 位 Crockford Base32
    (无 0O1I 混淆)四段展示 `XXXX-XXXX-XXXX-XXXX`,查验时去分隔符大写归一;
③  **注册流水**:`guantai_reg_log` 分页(成败/原因/IP/UA/指纹摘要/邀请码/
    时刻),按 IP/UA/指纹/时间窗聚类高亮"同源近时批量"形态;
④  **观测台封禁**:对可疑注册(单个或按聚类圈选)写 `guantai_user_block`
    ——登录与会话逐次复核处**多一枚 LEFT JOIN**(命中即回 `banned` 语义,
    最迟一个会话缓存周期 20s 内全网下线,与外部封停同一时效),**不碰
    tb_user 一个字节**(§2 新纪律);解封同视图一键。

### R8 设备指纹摘要(纯软信号,与 L4 同哲学)

前端采集极轻量指纹源(UA/语言/时区/屏幕/canvas 摘要),本地 SHA-256 后**只传
前 16 位十六进制**;服务端只落审计与聚类展示,**唯一的自动效果**是"同指纹
10 分钟内尝试 ≥3 → 该来源 PoW 难度 +4"(减速,不是拦截)。指纹可伪造、可
清空——它是线索不是判决,绝不参与拒绝决策(与 L4「软信号永不触发自动封禁」
逐字同款)。隐私面:不落原始指纹、不跨用途使用、摘要随审计保留期一并清扫。

### R9 短信/邮箱验证:**刻意不做,留设计备忘**

复核结论:① `tb_user` 无已知手机列,落地需自建 `guantai_reg_meta` 存手机
哈希;② 大陆短信需实名签名报备与供应商接入,引入持续成本与合规面;
③ **接码平台让"一人一号"以极低单价即可穿透**——短信验证挡不住职业批量,
挡住的恰是它本想服务的真人转化;④ 在 R0 零赠送经济学下,短信的边际防护
收益趋近于 0。若未来开放注册且体验天数 >0 且 R3+R6 实测仍压不住,再按备忘
落地:挑战流程中插短信位、`guantai_reg_meta(user_id, phone_hash)` 全局一号
一注册、发送侧独立限流与图形验证前置(防短信轰炸他人)。

---

## 6. 数据面(新表 DDL + tb_user 写入契约)

三张 `guantai_` 新表(等价 SQL 进 `scripts/init_userdb.sql`,web 首启幂等自建,
与既有两表同一 `_ensure_schema` 通道):

```sql
CREATE TABLE IF NOT EXISTS guantai_invite_code (
  id           BIGINT      NOT NULL AUTO_INCREMENT,
  code         VARCHAR(20) NOT NULL COMMENT 'Crockford Base32,存大写去分隔',
  days_granted INT         NOT NULL DEFAULT 0 COMMENT '注册成功赠送天数(0=不赠)',
  quota        INT         NOT NULL DEFAULT 1 COMMENT '可用次数',
  used_count   INT         NOT NULL DEFAULT 0,
  expires_at   DATETIME    NULL     COMMENT 'NULL=不过期',
  disabled     TINYINT     NOT NULL DEFAULT 0,
  note         VARCHAR(100) NOT NULL DEFAULT '',
  created_at   DATETIME    NOT NULL,
  PRIMARY KEY (id), UNIQUE KEY uk_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台注册邀请码(4.0.0 新建)';

CREATE TABLE IF NOT EXISTS guantai_reg_log (
  id         BIGINT       NOT NULL AUTO_INCREMENT,
  user_id    BIGINT       NOT NULL DEFAULT 0 COMMENT '成功时=新 tb_user.id',
  user_name  VARCHAR(50)  NOT NULL DEFAULT '',
  ip         VARCHAR(45)  NOT NULL DEFAULT '',
  ua         VARCHAR(200) NOT NULL DEFAULT '',
  fp         CHAR(16)     NOT NULL DEFAULT '' COMMENT '设备指纹摘要(前16hex,可空)',
  invite_id  BIGINT       NOT NULL DEFAULT 0,
  ok         TINYINT      NOT NULL DEFAULT 0,
  reason     VARCHAR(30)  NOT NULL DEFAULT '' COMMENT 'ok/name_taken/pow_failed/…',
  created_at DATETIME     NOT NULL,
  PRIMARY KEY (id), KEY idx_ip_time (ip, created_at),
  KEY idx_time (created_at), KEY idx_fp (fp),
  KEY idx_name (user_name)                       -- 4.0.7:name 筛选补索引
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台注册审计(4.0.0 新建;并入每日清扫)';

CREATE TABLE IF NOT EXISTS guantai_user_block (
  user_id    BIGINT      NOT NULL COMMENT '关联 tb_user.id',
  reason     VARCHAR(30) NOT NULL DEFAULT '' COMMENT 'malicious_reg/manual/…',
  note       VARCHAR(100) NOT NULL DEFAULT '',
  created_at DATETIME    NOT NULL,
  PRIMARY KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台侧封禁(4.0.0 新建;不触碰 tb_user.is_off)';
```

**tb_user 写入契约**(全项目唯一 INSERT,置于事务中):基础四列
`(user_name, pass_word, due_time, is_off)` 取值分别为 校验后的用户名 /
按 `reg_pass_shape` 编码的口令 / `NOW() + INTERVAL %s DAY`(赠送天数,数据库
的钟,与登录判活同源)/ `'0'`;真实表若存在**其它 NOT NULL 且无默认**的列
(预检工具会逐列点名,§11),经 `STA_USER_REG_EXTRA_COLS`(JSON,如
`{"create_time":"$now","qq":""}`)补齐——列名经 `[A-Za-z0-9_]` 白名单校验后
拼入语句,取值全部参数化,`$now` 展开为 `NOW()`。

**注册事务**(单连接,C6 新增 `_tx()` helper;`guantai_*` 与 `tb_user` 同库,
原子性天然成立):
```
BEGIN
  ① invite 模式:UPDATE guantai_invite_code
       SET used_count = used_count + 1
       WHERE code=%s AND disabled=0 AND used_count < quota
         AND (expires_at IS NULL OR expires_at > NOW())      → rowcount=1 才算占坑
  ② INSERT INTO tb_user (...)                                → 撞唯一键 1062 = 重名
  ③ INSERT INTO guantai_reg_log (..., ok=1, reason='ok')
COMMIT   (任一步失败整体 ROLLBACK:占坑自动回吐,零补偿逻辑)
```
失败路径的审计(ok=0)在事务外独立落一行(带 R1 限幅)。

---

## 7. API 面

```
GET  /api/auth/register/challenge
       → 200 {ok, challengeId, salt, bits, ttl, minFillS,
              captcha:{provider, appId}?}          · 429 throttled(+retryAfter)
       → 503 register_disabled / register_unavailable(Redis 不可用)
POST /api/auth/register
       body {userName, password, inviteCode?, challengeId, nonce,
             captchaToken?, fp?, contact?(蜜罐), ...}
       → 200 {ok, user:{id,userName,dueTime,dueDays}, autoLogin:bool}
             (+ Set-Cookie,仅 autoLogin=true 时)
       → 4xx/5xx 见错误码表
GET  /api/auth/session   (扩展,向后兼容)
       → 原有字段 + reg:{mode:"off|invite|open", captcha:{provider,appId}?}
管理台(自有鉴权 + CSRF,全部审计):
GET/POST /api/{入口}/reg/mode        模式读取/热切换(危级确认)
GET/POST /api/{入口}/reg/invites     列表/批量生成/禁用
GET      /api/{入口}/reg/log         注册流水分页(ip/name/ok/reason 筛选)+ 聚类
POST     /api/{入口}/reg/block       观测台封禁/解封(user_id 列表)
GET      /api/{入口}/reg/stats       曲线/熔断状态/难度水位
```

| 错误码 | HTTP | 对用户文案 | 备注 |
| --- | --- | --- | --- |
| register_disabled | 503 | 本部署未开放注册 | mode=off |
| register_closed | 403 | 注册暂时关闭,请稍后再试 | R6 熔断中(不点破阈值) |
| register_unavailable | 503 | 注册暂时不可用,请稍后重试 | Redis/用户库不可用(fail-closed) |
| throttled | 429 | 操作过于频繁,请稍后再试 | 带 Retry-After |
| challenge_required / challenge_expired | 400 | 安全校验已过期,请重试 | 前端自动重取挑战重试一次(预算 1,复用 proof_required 手法) |
| pow_failed | 400 | 安全校验未通过,请重试 | nonce 不达难度/IP 分桶不符;前端会单次自动重取并重试(与 challenge_expired 共用预算 1,自愈手机中途切网换 IP 段的场景) |
| captcha_failed / captcha_unavailable | 400/503 | 人机验证未通过/暂不可用 | R3 启用时 |
| invite_required / invite_invalid / invite_exhausted / invite_expired | 400 | 需要邀请码 / 邀请码无效 / 已用尽 / 已过期 | invite 模式 |
| name_invalid / name_reserved / name_taken | 400 | 用户名不合规 / 不可用 / 已被使用 | R5 |
| weak_password / password_invalid | 400 | 密码过于简单 / 密码格式不合规 | R5 |
| bad_request | 400 | 注册失败,请稍后重试 | **蜜罐命中与秒提交统一走此通用码**,不教学 |

CSRF 姿态:`/api/auth/` 本就豁免 `X-JF-Auth`(C1);注册端点只收
`application/json`(`request.json()` 解析失败即 400)——跨站纯表单
(urlencoded/text-plain)天然失效,跨源 fetch 带 JSON 必被 CORS 预检拦;
再加一道 best-effort:请求带 Origin/Referer 头且与 Host 不同源时直接 403
(头缺失不拒,兼容隐私浏览器)。

---

## 8. 前端改造(#authGate 扩展,零新增静态资源)

登录卡(`index.html:396`)底部追加一行入口
`<button id="authToReg">还没有账号?注册</button>`——**仅当** session 回包
`reg.mode ≠ off` 时显示(旧后端无 reg 字段 → 恒隐藏,兼容矩阵 §12)。点击
后同一张 `auth-card` 切换为注册态(dataset 驱动,不新开弹层):用户名 /
密码 / 确认密码 / 邀请码(invite 模式)/ 验证码容器(R3 启用时)/ 蜜罐字段
/「注册」与「返回登录」。

提交链:`doRegister()` → 取挑战(节流错误就地呈现)→ 主线程
`powAnswer(salt)` → Blob 内联 Worker 纯 JS SHA-256 穷举(按钮转「安全校验中…」,
Worker 每 10 万次哈希回报进度防假死观感;挑战过期/pow_failed 自动重取重试一次,共用预算 1)
→ 补足最短填表余量(先解题后补余,解题与 minFill 窗重叠,快速提交总
耗时从「等待+解题」降为 max(等待, 解题))→ `api('/api/auth/register', …)`。成功分支二分:`autoLogin=true`(赠送
天数 >0)→ 「注册成功,正在进入…」+ 260ms 后 `location.reload()`(与登录
同款收束,首登预置房经 on_login_ok 已种下,C10);`autoLogin=false` → 成功卡
+ 开通指引文案(`STA_USER_REG_SUCCESS_HINT`,如"注册成功,请联系管理员
开通使用时长")。错误呈现全部复用 `setAuthMsg` 管线;字段级即时校验(长度/
字符集/两次密码一致/弱口令)与后端同规则,前端只做体验、后端才是闸。

构建面:全部改动落在 `assets/app.js` 与 `index.html`——`build-deploy.mjs`
混淆管线零改动(powAnswer 已在混淆包内;Worker 源码以字符串内联,SHA-256
穷举循环无秘密,不依赖混淆)。`index.html` bump `?v=4.0.0`(既有 no-cache
+ 版本参强刷机制)。

---

## 9. 管理台「注」视图

`admin.html` 左栏 `signals` 后新增 `<button class="nav-item" data-view="reg">注`
(「注册与邀请」);`admin.js` 按「疑」视图同款模式挂路由 `#/reg`,四块布局
见 §5-R7。帮助弹层追加一段「注册与邀请」图例;模式切换按「危 · 二次确认」(管理台 1.8.0 起不再要求抄写键名;确认框写明切到哪一档、后果是什么)
既有交互(高危参数原样键入确认)。所有写操作经既有管理审计通道落盘。

---

## 10. 配置总表(STA_USER_REG_*;环境变量 > config.yaml `userauth:` 组 > 默认)

| 环境变量 | 默认 | 说明 |
| --- | --- | --- |
| `STA_USER_REG_MODE` | `off` | off / invite / open(热更,管理台可运行时覆盖) |
| `STA_USER_REG_PASS_SHAPE` | *(空=注册不启用)* | plain / md5 / sha1 / sha256(sha256 另受真实列长把关)——**必须**与外部续费系统校验兼容,预检给建议 |
| `STA_USER_REG_TRIAL_DAYS` | `0` | open 模式赠送天数;invite 模式忽略(随码) |
| `STA_USER_REG_EXTRA_COLS` | *(空)* | tb_user 额外必填列映射 JSON(预检输出后照抄) |
| `STA_USER_REG_POW_BITS` | `17` | PoW 基础难度(前导零位);自适应只升不降,硬顶 25 |
| `STA_USER_REG_CHAL_TTL_S` | `600` | 挑战有效期(亦是最长填表时长) |
| `STA_USER_REG_MIN_FILL_S` | `3` | 最短填表时长(秒) |
| `STA_USER_REG_CAPTCHA` | `off` | off / tencent / geetest / turnstile(5.2.0 起注册与登录共用) |
| `STA_USER_REG_CAPTCHA_REQUIRED` | `1` | **5.2.0** 注册时要不要过人机验证;0 = 注册不要,供应商只给登录用 |
| `STA_USER_REG_CAPTCHA_ID` / `_KEY` | *(空)* | 供应商凭据(仅环境变量;管理台打码只读) |
| `STA_USER_REG_CAPTCHA_SECRET_ID` / `_SECRET_KEY` | *(空)* | **仅 tencent 需要**:云 API 凭据(`DescribeCaptchaResult` 的 TC3 签名) |
| `STA_USER_REG_IP_HOURLY` / `_IP_DAILY` | `5` / `10` | 每 IP 注册尝试(时/日) |
| `STA_USER_REG_IP_OK_DAILY` | `2` | 每 IP 成功注册/日 |
| `STA_USER_REG_CHAL_IP_10M` | `10` | 每 IP 挑战签发/10 分钟 |
| `STA_USER_REG_NAME_10M` | `3` | 同名尝试/10 分钟 |
| `STA_USER_REG_GLOBAL_HOURLY` | `30` | open 小时熔断阈(越顶 → invite) |
| `STA_USER_REG_GLOBAL_DAILY` | `200` | open 日熔断阈(**达到** → off) |
| `STA_USER_REG_GLOBAL_DAILY_INVITE` | `500` | invite 日熔断阈(**达到** → off);拆成两个键是因为注册表 drift-guard 要求「一个字段一个键」 |
| `STA_USER_REG_RESERVED` | *(空)* | 追加保留用户名(逗号分隔;内置名单恒生效) |
| `STA_USER_REG_SUCCESS_HINT` | 内置文案 | 零赠送分支的开通指引 |
| `STA_USER_REG_LOG_RETENTION_DAYS` | `-1`(= 跟随 `STA_USER_LOG_RETENTION_DAYS`) | 注册审计保留期;`0`=永久。用 `-1` 而非空串表达「跟随」,是为满足配置注册表 drift-guard 对「默认值必须与 dataclass 逐项相等」的要求 |

全部字段进 `settings.UserAuthCfg`(`reg_` 前缀平铺,与既有风格一致)与
`config_registry` userauth 组(热更徽章:mode/阈值/难度/PASS_SHAPE/EXTRA_COLS
=即时热更;CAPTCHA 凭据=需重启,readonly 打码)。
`.env.example` 「登录系统」段后追加「注册系统」块,注释密度对齐既有文风。

---

## 11. 预检工具(`userdb_check.py --reg-preflight`,启用前必跑)

在既有体检项之后追加,全部只读(除权限探针的事务内回滚):
①  `SHOW FULL COLUMNS FROM tb_user` → 打印全列/类型/NULL/默认;**逐列点名**
    「NOT NULL 且无默认」者并生成 `STA_USER_REG_EXTRA_COLS` 建议 JSON;
②  读 `pass_word` **真实列长**(裁决 C7 矛盾:实为 varchar(50) → sha256 不可
    选;实测更长 → 选择空间如实放宽)+ 复述形态分布并给 `PASS_SHAPE` 建议值
    (多数派);
③  `SHOW INDEX FROM tb_user` → user_name 唯一键**实存性**;缺失则醒目告警并
    说明将启用 Redis 名义锁兜底;
④  INSERT 权限探针:`START TRANSACTION; INSERT …占位行…; ROLLBACK;`——
    零数据副作用(如实注明:AUTO_INCREMENT 计数会前进一格);
⑤  `--init` 同步扩为幂等创建三张新表。

---

## 12. 兼容矩阵与灰度上线

| 组合 | 行为 |
| --- | --- |
| mode=off(默认) | 与未启用注册时逐字节一致(关闭态契约测试钉住);新端点回 503,新表照建(幂等、零引用) |
| 新前端 × 旧后端 | session 无 `reg` 字段 → 注册入口恒隐藏,零可见差异 |
| 旧前端 × 新后端 | 无注册入口;登录/一切既有行为不变(端点存在但无人调用) |
| 登录系统未启用 | reg 强制视作 off + 启动告警(§4 前置条件) |

上线路径:① 部署机跑 `--reg-preflight`,据输出拍板 §15 的 D2/D5;
② `.env` 填注册块,`mode=invite` 起步,生成一枚 quota=1 测试码走通全流程
(注册 → 赠 1 天 → 自动登录 → 首登预置房可见 → 管理台流水可查);
③ 观察一周流水与聚类;④ 确需 open:先接国产验证码 + 复核熔断阈值,再切;
⑤ 任何异常:管理台一键 `mode=off` 即回到未启用注册的行为(不必回滚镜像)。

---

## 13. 测试与三对齐钉子(文档-代码-测试)

| 钉 | 内容 |
| --- | --- |
| T1 单元 | 用户名/口令校验矩阵(**字符集放行面与拒绝面**·全角同形字·gbk 边界·emoji·保留名·弱口令·长度);「字符集只约束注册不追溯存量」静态钉(扫 `_authenticate` 函数体);「字符集不得挪进参数中心」钉;前后端字符集源码对拍;`_log_reg` 编码防回退钉;PoW 校验(位数/单次性/IP 绑定/过期/重放);邀请码状态机;`_tx()` 回滚语义 |
| T2 并发原子 | quota=1 的码被 10 路并发抢注 → 恰 1 成;重名 1062 → 事务回滚后 `used_count` 不变(占坑回吐) |
| T3 活体对拍 | 从 `app.js` 抠出注册版求解器交 node 执行,与 Python 校验器互证(复用 test_proof_of_browser 的抠源码手法 + 黄金向量);故障注入(改一位常数)必红 |
| T4 契约 | mode=off 关闭态逐项 == 未启用注册时;限流/难度/长度等阈值前后端与本文档三处同值钉住;session `reg` 字段新旧后端矩阵 |
| T5 **静态纪律钉** | 扫描全部 Python 源:对 `tb_user` 出现的 SQL 动词仅允许 SELECT 与恰一处 INSERT;任何 UPDATE/DELETE/ALTER/TRUNCATE 命中即红——把 §2 新纪律写进测试,不是口头承诺 |
| T6 e2e(1:1 MariaDB 复刻,C16) | 三模式全流程;熔断触发降档与手动恢复;蜜罐/秒提交拒绝且回通用文案;autoLogin 二分;`guantai_user_block` 命中 → 登录 banned + 在线会话 20s 内下线;审计限幅 |
| T7 冒烟 | `smoke_auth.py` 含**关闭态契约段**(session `reg.mode=off`、两个端点 503、tb_user 未被触碰),自动建表断言覆盖 5 张表;`scripts/frontend_reg_jsdom.js` 以交付版 `index.html`+`app.js` 在 jsdom 真 DOM 跑通整条注册链(含「成功即清空」「眼睛切换」「emoji 用户名 / 格式必败邀请码就地拦不发请求」「invite→open 热切后格式拦截自愈拨模式」,另含 jfInviteNorm 源码级规格对拍),并对**混淆后的部署产物**再跑一遍(证明 Worker 源码经 `splitStrings`+RC4 字符串编码后仍可用) |


> 管理台侧另有 `scripts/admin_reg_jsdom.js`(「注」视图的真 DOM 冒烟)。
> 两者都支持 `--js <混淆产物>` 再跑一遍。改动前后应逐一重跑对照。
> ⚠ 跑 jsdom 一律 `npm i --no-save jsdom` —— 裸 `npm i` 会写进 package.json,
> 目标机 `npm ci` 撞「not in sync」导致镜像重建中断(有回归钉,且复犯过)。
**实测记录**:
* 联测在 1:1 复刻 MariaDB(gbk + `gbk_bin` + 多形态口令)上真实建号:三模式全流程、
  quota=1 十路并发抢注恰 1 成且 `used_count` 精确为 1、重名回滚占坑回吐、
  `autoLogin` 二分、封禁命中登录 `banned` 且 `tb_user.is_off` 未被改动、
  熔断关闸与手动恢复、sha256 短列 fail-closed。
* PoW 难度实测(node,单线程):17 位平均 ≈73ms/≈6.7 万次哈希,20 位 ≈690ms——
  与 §14「主流手机纯 JS ≈0.3–1.5s」的量级估计相符(手机约慢 3–8×);
  最终校准仍以真机为准。

---

## 14. 诚实的能力边界(务必读)

PoW 挡不住肯烧算力的人——GPU/优化实现算 SHA-256 比浏览器快几个数量级,
R2 是**限速器与定价器**,不是墙;它与 R0 叠加后的真实语义是"你花算力买到的
是一个不能用的空壳"。难度校准数字(17 位 ≈0.3–1.5s)基于纯 JS 单线程的
量级估计,**以 T7 真机实测为准**,低端机偏慢时下调基础位数是正当取舍。
验证码存在人工打码产业,单次成本以分计——任何人机验证都可被人力外包穿透,
R3 的价值是把"免费"变成"每号都要花钱"。邀请码会被转卖/泄露——码不是
秘密等级的凭据,配额与有效期使损失有界,这是设计内行为。指纹可伪造、
一键清空——只作线索。用户名枚举无法消除(注册必须告知重名),只能被
PoW+限流定价。熔断是止损不是防御——它承认"一切都可能被穿透",并保证穿透
后的损失存在硬上界。最后,`mode=off` 是永远在场的一键归零:任何未预见的
对抗形态,先关闸,再从审计里学习。

---

## 15. 决策点清单(设计取舍的既定结论)

| # | 决策 | 结论 | 落地形态 |
| --- | --- | --- | --- |
| D1 | 纪律修订:tb_user INSERT-only | **采纳**(不走双源备忘方案) | §2 新纪律 + T5 静态钉;实测 INSERT 恰一处 |
| D2 | `PASS_SHAPE` 口令入库形态 | **不设默认、必填才启用**;预检按库里多数派给建议值(本地 1:1 复刻实测建议 `md5`)。运行期对 `sha256` 另做真实列长把关 | `STA_USER_REG_PASS_SHAPE` 空 = 注册强制 off + 启动告警 |
| D3 | 初始模式与赠送 | **invite 起步**;邀请码默认赠 1–3 天(生成时可填);`open` 的 `TRIAL_DAYS` 保持 **0** | `reg_mode` 默认 `off`;`.env` 示例以 invite 为推荐起步 |
| D4 | 验证码 | invite 阶段**不接**;转 open 前接腾讯云或极验;Turnstile 仅海外 | `reg_captcha` 默认 `off`,三家适配器均已实现(fail-closed) |
| D5 | tb_user 额外必填列 | **预检输出后照抄** | `--reg-preflight` 逐列点名并直接生成建议 JSON |
| D6 | 自动登录 | 赠送 >0 → **注册即登录**;=0 → 成功卡 + 开通指引 | `autoLogin` 二分已落地(联测与前端冒烟双向覆盖) |
| D7 | (远期)存量口令形态升级 | **暂不动**(与续费系统同步改造后再议) | 无代码改动 |
| **D8** | **口令复杂度**(运营要求) | **5–16 位字符,无字符组合限制** | 前后端同规则;`test_register.py` 端到端验证纯数字/纯字母/含空格口令均可注册并登录 |

## 16. 涉及文件清单

后端:`app/userauth.py`(注册路由/校验/事务 `_tx()`/挑战与限流/邀请码 DAO/
block JOIN 接入 login+validate/`_janitor` 扩 reg_log)、`app/settings.py`
(UserAuthCfg 增 `reg_*`)、`app/config_registry.py`(userauth 组增卡)、
`app/admin_api.py`(/api/{入口}/reg/*)、`scripts/init_userdb.sql`(三新表)、
`scripts/userdb_check.py`(--reg-preflight)、`scripts/smoke_auth.py`(注册段)。
前端:`index.html`(authGate 注册态 + bump ?v)、`assets/app.js`(入口/
doRegister/求解 Worker/session reg 消费)、`assets/app.css`(注册态样式)、
`admin.html` + `assets/admin.js` + `assets/admin.css`(「注」视图)。
配置:`backend_async/deploy/.env.example` 注册块。测试:`tests/test_register.py`
(T1–T5)与 e2e 扩展(T6)。

---

## 外部信源(联网复核,2026-07)

Turnstile 大陆可用性:Cloudflare 社区帖「Request CF Turnstile services in
China」(challenges.cloudflare.com 大陆访问慢、请求中国 CDN)及多起加载失败
报告;腾讯云验证码产品文档(产品概述/简介:登录注册场景「阻止注册机批量
注册小号」、恶意拦截等级可调);极验为大陆主流行为验证供应商(腾讯云开发者
社区评测)。以上仅影响 R3 供应商建议排序,不影响本方案任何硬机制。

---

