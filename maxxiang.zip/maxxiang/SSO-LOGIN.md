# 链接快速登录(SSO)—— 从同库其它项目一键登进观测台

> 一句话:你的续费/管理系统(与观测台共用 `fanxing_changkong_user_db.tb_user`)
> 在用户已登录它自己的前提下,往共享库 **INSERT 一枚一次性短命票据**,再把用户
> 跳到 `https://观测台域名/#sso=<票据>` —— 观测台凭票换出自己的正式会话,
> 用户全程零输入。**不传密码、不共享密钥、不打通 Redis**,共享 MySQL 本身
> 就是双方唯一的信任媒介。

---

## 0. 大白话:整个流程一共四步

```
 你的系统(签发方)                          观测台(消费方)
──────────────────────                 ─────────────────────────
① 用户在你那已登录,点「进入观测台」
② 你后端:生成 64 位随机 hex 票据 T
   把 SHA-256(T) INSERT 进共享库的
   guantai_sso_ticket(60 秒后过期)
③ 302/window.open 跳到
   https://观测台/#sso=T  ────────────►  ④ 前端读到 #sso= 片段,立刻清掉,
                                           POST /api/auth/sso 兑换:
                                           · 库里核对哈希 + 没用过 + 没过期
                                           · 核对 tb_user 没封停/没到期
                                           · 原子核销(单次有效)
                                           · 签发观测台自己的会话 Cookie
                                           → 用户直接进入,和输密码登录一模一样
```

关键性质(为什么这样是"天花板"而不是"能用就行"):

| 性质 | 落实 |
| --- | --- |
| 密码零出场 | 票据是纯随机数,和 `pass_word` 毫无数学关系;链接泄露也推不出密码 |
| 单次有效 | 观测台核销走 `UPDATE ... SET used=1 WHERE id=? AND used=0` 单语句原子写,并发/重放恰一名赢家 |
| 短命 | 签发方写 `expires_at = NOW()+60 秒`;观测台另叠一道 `created_at` 300 秒硬顶(`STA_USER_SSO_MAX_AGE_S`)—— 签发方哪怕写错超长有效期,票据寿命也有上界 |
| 无钟差 | 签发与核销的时效判定**都用数据库的 NOW()** —— 两台服务器各自的系统时间根本不参与 |
| 票据不落库 | 库里只存 SHA-256(与观测台会话表同纪律);拖库拿不到可用票据 |
| 不进日志 | 票据放在 URL 的 `#` 片段里 —— 浏览器**不会把 # 后内容发给服务器**,访问日志、Referer、链接预览爬虫都抓不到;前端读到即 `replaceState` 清掉,浏览器历史里也不留 |
| 防静默换号 | 浏览器里已登录**另一个**观测台账号时,后端回 `409 switch_confirm`(此时票据**不消费**),前端弹确认框,同意才切换 —— 封死「给别人发我的链接,他一点就悄悄变成我的账号」这条社工路 |
| 审计一体 | 成功/失败都落 `guantai_login_log`(reason=`sso` / `sso_bad`),和账密登录同一张审计表、同一保留期 |
| 状态一体 | 兑换前照常核对 `tb_user` 的 `is_off` 封停、`due_time` 到期与观测台侧封禁 —— 续费/封号的生效逻辑与账密登录逐字节相同 |
| 后续无特殊 | 兑换成功走的就是登录系统现成的 `_issue_session()`:单设备互顶、首登预置房、30 天会话,全部同款 |

---

## 1. 观测台侧:开启(已替你配好)

`backend_async/deploy/.env` 已加:

```bash
STA_USER_SSO=1        # 置 0/删行 = 整体关闭(端点回 503,前端零行为)
```

重建 web 生效(其它服务不动):

```bash
cd backend_async/deploy
docker compose up -d --build web
```

首启会**幂等**多建一张 `guantai_sso_ticket` 新表(照旧 `guantai_` 前缀,
对既有 `tb_user`/`sys_*` 绝对零触碰;手动预建可跑 `scripts/init_userdb.sql`)。

可选微调:`STA_USER_SSO_MAX_AGE_S`(消费侧票据年龄硬顶,默认 300 秒)。

---

## 2. 其它项目侧:接入三步(核心就一条 INSERT)

> 前提:你的项目本来就连着 `fanxing_changkong_user_db`,并且知道当前登录
> 用户在 `tb_user` 里的 `id`。**票据必须在用户点击时现签**,不要预生成、
> 不要做成固定死链(固定链接 = 把钥匙焊在门上,见 §4 红线)。
>
> 跳转建议用 `window.open(url, '_blank')` 而不是 `location.href = url`:后者
> 若恰好停在观测台同一路径上,浏览器会判定「只有 `#` 后不同」而**不重新加载**,
> 只改 `location.hash`。观测台已监听 `hashchange` 并在该形态下照常兑换票据,
> 但新标签页可以完全绕开这类同源片段问题。

**第 1 步 · 生成票据**:32 字节加密随机数,转 **64 位小写 hex** 字符串 `T`。

**第 2 步 · 入库**(哈希在你代码里算,别用 SQL 的 SHA2() —— 那会把明文票据
写进 SQL 语句,可能被 binlog/慢日志记下):

```sql
INSERT INTO guantai_sso_ticket (user_id, token_hash, created_at, expires_at, note)
VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 60 SECOND), '续费系统');
--      ↑当前用户的 tb_user.id   ↑SHA-256(T) 的 64 位小写 hex
```

**第 3 步 · 跳转**:把用户带到(注意是 `#` 不是 `?`):

```
https://你的观测台域名/#sso=T
```

### 各语言最小可用样例(任选其一,逐行可抄)

**PHP(PDO):**
```php
$ticket = bin2hex(random_bytes(32));                     // 64 位小写 hex
$hash   = hash('sha256', $ticket);                       // 对小写 hex 字符串求摘要
$pdo->prepare("INSERT INTO guantai_sso_ticket
               (user_id, token_hash, created_at, expires_at, note)
               VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 60 SECOND), '续费系统')")
    ->execute([$uid, $hash]);
header("Location: https://观测台域名/#sso=" . $ticket);
```

**Java(JDBC):**
```java
byte[] buf = new byte[32];
new java.security.SecureRandom().nextBytes(buf);
StringBuilder sb = new StringBuilder();
for (byte b : buf) sb.append(String.format("%02x", b));
String ticket = sb.toString();                            // 64 位小写 hex
String hash = org.apache.commons.codec.digest.DigestUtils.sha256Hex(ticket);
try (PreparedStatement ps = conn.prepareStatement(
        "INSERT INTO guantai_sso_ticket (user_id, token_hash, created_at, expires_at, note) " +
        "VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 60 SECOND), '续费系统')")) {
    ps.setLong(1, uid); ps.setString(2, hash); ps.executeUpdate();
}
response.sendRedirect("https://观测台域名/#sso=" + ticket);
```

**Python:**
```python
import hashlib, secrets
ticket = secrets.token_hex(32)                            # 64 位小写 hex
hash_ = hashlib.sha256(ticket.encode()).hexdigest()
cur.execute("INSERT INTO guantai_sso_ticket (user_id, token_hash, created_at, "
            "expires_at, note) VALUES (%s, %s, NOW(), "
            "DATE_ADD(NOW(), INTERVAL 60 SECOND), %s)", (uid, hash_, "续费系统"))
return redirect(f"https://观测台域名/#sso={ticket}")
```

**Node.js(mysql2):**
```js
const crypto = require('crypto');
const ticket = crypto.randomBytes(32).toString('hex');    // 64 位小写 hex
const hash = crypto.createHash('sha256').update(ticket).digest('hex');
await pool.execute(
  "INSERT INTO guantai_sso_ticket (user_id, token_hash, created_at, expires_at, note) " +
  "VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 60 SECOND), '续费系统')", [uid, hash]);
res.redirect(`https://观测台域名/#sso=${ticket}`);
```

跨端契约就三条:**64 位小写 hex** → **对这串字符本身求 SHA-256** → **60 秒 TTL
用数据库 NOW() 写**。观测台消费侧会先做同样的小写归一再求同款摘要,两端必然对上
(实现见 `backend_async/app/userauth.py` 的 `sso_ticket_norm()`)。

---

## 2.6 另一条通道:`POST /api/auth/sso/link` —— 账密换链接

> **和 §2 是二选一,不是替代。** 能连共享库就用 §2 的 INSERT(少一跳、无需密钥);
> **不便连库、或懒得再实现一遍那段容易接错的哈希契约**,就用本通道 —— 一次 HTTP
> POST,观测台替你撕票据。两条通道写的是同一张 `guantai_sso_ticket`、走的是同一个
> 消费端点 `/api/auth/sso`,单次核销与年龄硬顶完全一致。

### 开启

```bash
# backend_async/deploy/.env
STA_USER_SSO=1                                  # 消费端点(前提,必须开)
STA_USER_SSO_LINK=1                             # 本通道开关
STA_USER_SSO_LINK_BASE=https://你的观测台域名     # 留空则只回 ticket 不回 url
                                                 # ⚠ 多 origin 部署请留空,见下方「多 origin」小节
STA_USER_SSO_LINK_KEY=<openssl rand -hex 32>    # 可选;留空=不校验调用方
STA_USER_SSO_LINK_TTL_S=60                      # 票据寿命,代码内硬顶 300
```

```bash
cd backend_async/deploy && docker compose up -d --build web
```

> ⚠️ **`.env` 会被 `deploy-maxxiang.sh install` 整体覆盖**(第 749 行 `cat > "$ENV_FILE"`,
> 覆盖前自动备份成 `.env.bak.<时间戳>`)。而向导模板里**不含任何** `STA_USERDB_*` /
> `STA_USER_*` 键 —— 也就是说**整个登录系统的配置**(含你现在用着的 `STA_USER_SSO=1`)
> 本来就靠手工写入。本通道的四个键与它们同一处境:`restart` / `update` 不受影响,
> 但重跑 `install` 后需要从备份里把这些行搬回来。这是项目既有性质,非本次引入。

### 调用

```http
POST /api/auth/sso/link            ← 服务端对服务端(本项目全局无 CORS,浏览器直连调不通)
Content-Type: application/json
Authorization: Bearer <STA_USER_SSO_LINK_KEY>      ← 未配 KEY 时可省略

{"userName": "abc", "password": "用户刚输入的明文", "note": "续费系统"}
```

```jsonc
// 200
{"ok": true,
 "url": "https://观测台域名/#sso=<64hex>",   // 未配 _BASE 则无此字段
 "ticket": "<64hex>",
 "expiresIn": 60,
 "user": {"id": 123, "userName": "abc", "dueTime": "...", "dueDays": 12, "ddAlive": true}}

// 400 bad_request | missing_fields    401 bad_key | bad_credentials
// 403 banned | expired(带 dueTime) | bad_origin(浏览器跨站发起)
// 429 throttled(带 Retry-After;两种来源:口令失败节流 / 密钥错误节流)
// 503 login_disabled | sso_disabled | sso_link_disabled | userdb_unavailable
//     ↑ 两个 503 分开报:sso_disabled=漏了 STA_USER_SSO;sso_link_disabled=漏了 STA_USER_SSO_LINK
```

**PHP:**
```php
$ch = curl_init("https://观测台域名/api/auth/sso/link");
curl_setopt_array($ch, [CURLOPT_POST => 1, CURLOPT_RETURNTRANSFER => 1,
  CURLOPT_HTTPHEADER => ["Content-Type: application/json",
                         "Authorization: Bearer " . SSO_LINK_KEY],
  CURLOPT_POSTFIELDS => json_encode(["userName" => $name, "password" => $pw,
                                     "note" => "续费系统"])]);
$r = json_decode(curl_exec($ch), true);
if (!empty($r["url"])) { header("Location: " . $r["url"]); exit; }
```

**Python:**
```python
r = requests.post("https://观测台域名/api/auth/sso/link", timeout=8,
                  headers={"Authorization": f"Bearer {SSO_LINK_KEY}"},
                  json={"userName": name, "password": pw, "note": "续费系统"}).json()
if r.get("url"):
    return redirect(r["url"])
```

**Node.js:**
```js
const r = await (await fetch("https://观测台域名/api/auth/sso/link", {
  method: "POST",
  headers: {"Content-Type": "application/json",
            "Authorization": `Bearer ${SSO_LINK_KEY}`},
  body: JSON.stringify({userName: name, password: pw, note: "续费系统"})})).json();
if (r.url) res.redirect(r.url);
```

### 本通道相对 §2 的差异(逐条,全部是**更严**或**等同**)

| 维度 | §2 INSERT 通道 | §2.6 本通道 |
| --- | --- | --- |
| 接入方要做的事 | 连库 + 生成随机数 + 算 SHA-256 + 写 SQL | 一次 HTTP POST |
| 哈希接错的可能 | **存在**(见 §6 排错表第 2 条,历史头号翻车点) | **不存在** —— 签发与消费调的是同一个 `_hash_token()` |
| 接入方需要的凭据 | 共享库的写权限(能写任意 `guantai_*` 表) | 可选的一把签发密钥(只能签票) |
| 票据有效期 | 签发方自己写(可能误写超长) | **观测台自己写**,调用方不得指定,硬顶 300s |
| 何时可签发 | 任意时刻(知道 `tb_user.id` 即可) | **只在用户刚输完明文口令那一刻**(见 §7.2) |
| 消费侧 | 完全相同 —— 同表、同端点、同单次核销、同年龄硬顶 | 同左 |

---


## 3. 用户看到什么

| 场景 | 行为 |
| --- | --- |
| 正常点击 | 秒进观测台,顶栏直接是自己的身份牌 —— 与输密码登录后无任何区别(单设备互顶、首登预置房照旧) |
| 链接被二次点击 / 超 60 秒 / 被预览爬虫抢先消费 | 登录门照常拉起,门上提示「快速登录链接已失效或已使用,请回到来源页面重新进入」—— 回你系统再点一次即可 |
| 浏览器里已登录**另一个**观测台账号 | 弹确认「当前已登录 A,要切换为 B 吗?」—— 取消则保持 A(票据不消费,60 秒后自然作废);确认则切到 B 并 toast 提示。注:toast 为项目既有**单管线后到覆盖**语义 —— 若 B 账号名录为空,切换提示会被随后的空名录引导覆盖,以顶栏身份牌为准(确认框本身已是明确反馈) |
| 账号已封停 / 已到期 | 与账密登录同款提示(到期含具体时刻);票据不被白白消费在 409 确认阶段 |
| 观测台未开 SSO / 用户库瞬断 | 门上如实提示,可直接改输账号密码 |

---

## 4. 安全边界(诚实说明,别越线)

1. **红线:绝不把 `user_name`/`pass_word`(哪怕 MD5)放进任何链接。** 库里
   口令是无盐 MD5(线上实测 27.7 万行全是 md5),URL 会进
   历史/日志/转发,泄露即等于交出密码本体。本方案的票据与密码零数学关联。
2. **链接必须"点击现签、一次一发"。** 固定不变的"免登录链接"在密码学上
   不可能安全 —— 谁拿到谁登录,等于账号共享。60 秒 + 单次核销就是为逼死
   这种用法。
3. **信任是传递的。** 观测台接受"你的系统对用户身份的判断";你的系统被攻破
   (或它的 DB 写权限泄露),攻击者就能给任意 `user_id` 签票据。这是一切
   单点登录的固有属性 —— 两边的安全水位从此取最低者。DB 账号请只留必需权限、
   不进前端、不进版本库。
4. **换号确认挡的是"静默"不是"切换"。** 用户明确点了确认就会切 —— 教育
   用户:别点陌生人发来的观测台链接,正如别在陌生设备输密码。
5. **限频与审计。** 兑换端点每 IP 30 次/10 分钟(票据空间 2^256,爆破无意义,
   此闸只为压噪);一切成败落 `guantai_login_log`,管理台照常可查。
6. **HTTPS。** 观测台若经 Nginx/Caddy 反代 TLS,Cookie 自动带 `Secure`
   (`STA_USER_COOKIE_SECURE=auto` 经 `x-forwarded-proto` 感知)—— SSO 链接
   同样应只在 HTTPS 下分发。

---

## 5. 设计取舍备案(为什么不是别的方案)

| 备选 | 为什么不 |
| --- | --- |
| URL 带账密 / 带 MD5 | 见 §4 红线 —— 这是反面教材,不是方案 |
| 共享 HMAC 密钥签名票据(JWT 式) | 安全水位相同,但:多一把要保管/轮换的密钥(泄露=可伪造任意用户);两台服务器存在钟差要额外容忍;防重放仍要观测台 Redis 记 nonce;签发方各语言实现 HMAC 规范串容易接错。共享库方案把这四个坑全部消掉 —— 签发=一条 INSERT,时钟=数据库同一口 NOW(),单次=DB 原子核销,信任媒介=本来就共享的 MySQL,**零新增秘密** |
| 两项目共享会话 Cookie | 不同域名下 Cookie 天然不共享;强行同域耦合远大于收益 |
| 票据放 `?query` 而非 `#片段` | query 会进服务器访问日志与同源 Referer;片段浏览器根本不发出去,配合"读到即清"连浏览器历史都不留 |

## 6. 排错速查

| 现象 | 原因与处置 |
| --- | --- |
| 门上提示「本部署未启用链接快速登录」 | `.env` 的 `STA_USER_SSO` 不是 1,或改后没 `docker compose up -d --build web` |
| 总是「链接已失效」 | ① 签发到点击超 60 秒(检查你 INSERT 的 `expires_at`);② `token_hash` 没按「小写 hex 字符串求 SHA-256」的契约算(最常见:对**二进制**而不是 hex 字符串求了摘要);③ 同一链接点了第二次(单次有效,预期行为) |
| 提示「账号已到期/停用」 | 与账密登录同源 —— `tb_user.due_time`/`is_off` 说了算,续费后再点即可 |
| 想彻底关掉 | `.env` 置 `STA_USER_SSO=0` 重建 web;表留着无副作用(零引用) |

验证链路(部署机):`docker compose logs web | grep 登录` 应见「登录系统已启用」;
前端整机冒烟(开发机,五场景,支持 `--js` 指向混淆产物):
`npm i jsdom && node backend_async/scripts/frontend_sso_jsdom.js`;
对真库全流程烟测可跑 `scripts/smoke_auth.py`(本地 1:1 库),表体检
`scripts/userdb_check.py`(need 集合已含 `guantai_sso_ticket`)。

---

## 7. 账密签发通道的诚实边界(读完再决定开不开)

§4 的红线与安全性质**对本通道原样适用**(票据仍是纯随机数、仍单次、仍短命、
仍走 `#` 片段、仍有换号确认)。以下是本通道**独有**的三条,逐条说清楚。

### 7.1 它不比 `/api/auth/login` 更危险,也不比它更安全

`/api/auth/login` 本来就是公开端点。5.2.0 起它不再「裸」:失败额度先占后验、可疑时
要求加码(本站 PoW / 可选人机验证)、同源校验、设备信任(详见 LOGIN-SYSTEM.md §4.5)。

本通道的口令校验**复用同一个 `_authenticate()`**,也就复用同一套
「用户名 10 次 / IP 30 次 每 10 分钟」失败节流桶 —— 攻击者从两个端点合起来
能拿到的尝试次数,与只有 `/api/auth/login` 时**逐次相等**。5.2.0 起两者还共用同一套
加码判定:本通道是服务端对服务端、解不了题,需要加码时直接 429(配了
`STA_USER_SSO_LINK_KEY` 的受托调用方视为已自行把关,照常验密)—— 只会比网页登录更严。

> 这条性质由 `tests/test_sso_link.py::test_link_shares_login_throttle_bucket`
> 活体钉住:先用 `login()` 打满某用户名的失败计数,再换 IP 拿**正确口令**调
> 本端点,必须 429。谁把口令校验复制成第二份实现,此用例当场变红。

反过来说:**它也不会让你的口令体系变强**。库里存量口令多为无盐 MD5,且
`verify_password()` 的第一条分支是明文逐字节比较 —— 这意味着**把库里存的那串
MD5 原样递交,就能通过校验**(pass-the-hash)。所以对一个**本来就能读共享库**
的项目,本通道的口令校验挡不住它任何东西;它防的是外人,不防兄弟项目。

### 7.2 它只覆盖「登录即跳转」,覆盖不了「已登录后再点」

调用本通道需要用户的**明文口令**,而兄弟项目只在用户敲密码登录它自己的那一刻
手里有明文(之后存的是它自己的会话)。所以:

* ✅ 用户在续费系统**登录的同时**直接进观测台 —— 本通道适用;
* ❌ 用户**已经登录**续费系统,过一会儿点「进入观测台」—— 此刻没有明文口令,
  **必须走 §2 的 INSERT 通道**。

两条通道并存正是为了这个:各覆盖一半场景,共用同一条消费路径。
**若兄弟项目为了用本通道而去存明文口令,那是它的重大安全问题,本设计不鼓励。**

### 7.3 密钥的作用是「治理」,不是「防爆破」

`STA_USER_SSO_LINK_KEY` 留空是允许的(此时能力**不超过**已公开的 `/api/auth/login`:
同一套失败计数与加码判定,且需要加码时直接 429 —— 不构成新增敞口)。配上它换来的是三件**运营**上的事:

1. **按调用方审计** —— `guantai_login_log` 里 `reason='sso_link'` 的每一行,
   都是「某调用方为某账号签出了一张票」;失败的密钥尝试落 `sso_link_bad`。
2. **单独吊销** —— 某个接入方出问题,换一把密钥即可,不用动数据库账号。
3. **权限收窄** —— 相比给出共享库写权限(能写任意 `guantai_*` 表),
   一把签发密钥只能干签票一件事。

诚实提醒:**密钥泄露 = 可为任意账号签票**(仍需该账号的口令,因为口令闸在
密钥闸之后)。密钥请只放在服务端配置里,不进前端、不进版本库。

### 7.4 为什么没有 CORS(而且不该有)

全项目**没有任何 CORS 中间件**,本端点也不例外 —— 浏览器跨源直连调不通,
只能服务端对服务端。这是**刻意的**:开了 CORS 就等于要求接入方把签发密钥
放进前端 JS,那把密钥当场作废。

### 7.5 审计口径

| 场景 | `guantai_login_log.reason` |
| --- | --- |
| 签发成功 | `sso_link`(一行 ⇔ 一张票据被签出) |
| 密钥错 | `sso_link_bad`(每 IP 20 次/10 分钟;**触限后静默 429,不再写审计** —— 否则等于替攻击者放大日志,打的是与别的项目共用的生产 MySQL) |
| 每账号签发限频触顶 | `sso_link_rate`(10 次/分钟) |
| 口令错 / 封停 / 到期 / 节流 | `bad_credentials` / `banned` / `expired` / `throttled`(与账密登录**同一词表**,**不双写**) |

管理台「登录审计」视图零改动即可查全部签发流水。

### 7.6 排错

| 现象 | 原因与处置 |
| --- | --- |
| 回 `503 sso_link_disabled` | `.env` 少了 `STA_USER_SSO_LINK=1`;改后需 `docker compose up -d --build web` |
| 回 `503 sso_disabled` | `STA_USER_SSO` 不是 1。本通道**串联**消费端点开关 —— 签得出票却没有 `/api/auth/sso` 可兑换是纯误配,故在签发侧就拒绝。两个开关分开报码,免得你一直去查 `_LINK` 而漏掉总开关 |
| `note` 里的 emoji 变成了 `?` | 预期行为。票据表随 `tb_user` 是 `CHARSET=gbk`,GBK 表示不了的字符会被替换。**不会**因此签发失败(早期版本会误报 503,已修) |
| 回 `403 bad_origin` | 你是从浏览器跨站发起的。本端点是服务端对服务端,浏览器直连本就调不通(全项目无 CORS,见 §7.4) |
| 回 200 但没有 `url` 字段 | 没配 `STA_USER_SSO_LINK_BASE`。这是设计行为 —— 观测台**拒绝**从 `Host`/`X-Forwarded-Host` 头推导自己的域名(那是调用方可控输入),要么配上,要么你自己拼 `<你的域名>/#sso=<ticket>` |
| 代理镜像站的用户点链接却落到直营主站 | `STA_USER_SSO_LINK_BASE` 是**单值**,而本部署有多个公网 origin。**清空本项**,让各调用方用自己的 origin 拼 —— 见下方「多 origin」小节 |
| 回 `401 bad_key` | `Authorization` 头缺失或值不对。格式:`Bearer <key>`(裸 key 也接受) |
| 回 `429 throttled` 但口令是对的 | 该用户名的失败计数被打满了(与账密登录共用桶,见 §7.1),等锁定期过;或触发了每账号 10 次/分钟的签发上限 |
| 回 `429 throttled`,message 写「需要人机验证,账密签发通道无法完成」(5.2.0) | 该用户名 / 来源 IP 段近期失败已达加码阈值、或处于全局攻击态、或登录人机验证开了 always 档 —— 网页登录此时会要求算题 / 过验证框,本通道是服务端对服务端解不了题。给本通道配上 `STA_USER_SSO_LINK_KEY`(受托调用方视为已自行把关,照常验密),或等计数窗口过去 |
| 拿到 ticket 但兑换回 `bad_ticket` | 票据只活 `expiresIn` 秒且单次有效。检查是不是超时了、被重复点了,或被链接预览爬虫抢先消费 |


---

## 8. 在管理页改这些设置

### 8.1 两个开关别搞混(实地踩过的坑)

| 管理页标签 | 环境变量 | 管什么 |
| --- | --- | --- |
| **SSO 快速登录(消费)** | `STA_USER_SSO` | `/api/auth/sso` —— 用票换会话 |
| **账密换链接(SSO签发)** | **`STA_USER_SSO_LINK`** | `/api/auth/sso/link` —— 验账密吐链接 |

只设 `STA_USER_SSO=1` 时,「账密换链接」**仍然显示 false** —— 那是正确的,
它有自己的开关。**两个都要为 1**,签发通道才可用。

### 8.2 六项全部可在管理页热改

`STA_USER_SSO` / `STA_USER_SSO_MAX_AGE_S` / `STA_USER_SSO_LINK` /
`_TTL_S` / `_BASE` / `_KEY` —— 管理页「配置」视图直接改,**即时生效,无需重建容器**。

> 为什么是 `HOT` 而不是 `RESTART`:六个使用点全部是**调用时**读 `UA.cfg`,而
> `web.py` 传给 `userauth.init()` 的就是 `settings.userauth` **本身**(同一对象引用),
> 管理页的原地写入立即可见。
> (活体证明常驻:`tests/test_sso_link.py::test_sso_family_hot_change_takes_effect`。)

标了 **危险** 的四项(两枚开关 / 年龄硬顶 / 密钥)应用前须键入参数名确认,防手滑
—— 与 `reg_mode`(开放注册)、`auth.ticket`(酷狗票据)同款待遇。
密钥另标 **敏感**:真值只经 Redis 内存分发,**绝不落 PG 版本快照**。

### 8.3 ⚠️ 覆盖优先级(反直觉,务必知道)

冷启动顺序是「**文件/ENV 基线 → 叠加 PG 覆盖**」。所以:

* 一旦你在管理页改过某个键,之后再改 `.env` 里的同一个键就**不再生效**;
* 要回到 `.env` 语义,须在管理页对该键执行**清除覆盖**。

排错时如果发现「.env 明明改了却没效果」,先去管理页看这个键有没有覆盖。

### 8.35 ⚠️⚠️ 密钥请务必写进 `.env`,管理页只当临时轮换用

**这条最要紧,因为出问题是静默的安全降级。**

`sso_link_key` 标了 `sensitive`,真值只存在 Redis 的 `cfg:sensitive` 里,
**不落 PG 版本快照**。而实地核查确认两件事:

1. `config_center.bootstrap()` 冷启动用 `mode="boot"`,而该模式下对敏感项是
   **直接跳过**的(`app/config_center.py:174` 「启动期敏感真值不可得:跳过」);
2. 本项目的 Redis 是 `--save "" --appendonly no`(`docker-compose.yml:118`),
   **完全无持久化** —— Redis 一重启,`cfg:sensitive` 就空了,而代码遇到
   「Redis 重启丢真值」时的处置是**保持现值**。

合起来的后果:**只在管理页设了密钥、没写进 `.env` 的话,任何一次 web/Redis 重启
之后,`sso_link_key` 都会回落到 `.env` 的取值**(默认是空)。而空 = 不校验调用方
—— 端点从「要密钥」静默变成「不要密钥」,没有任何报错。

> 这不是本通道的缺陷,是 `config_center` 对敏感项的既有设计(`auth.ticket` 同款,
> 只是它另有 cookie 自动续期链路接管,所以对它无害)。

**正确用法**:

* 密钥的**权威来源永远是 `.env`**,改完重建 web;
* 管理页改密钥只用于**应急/临时轮换**,事后必须补写回 `.env`;
* 想确认当前到底生效的是哪一把:拿旧密钥调一次端点,回 `401 bad_key` 说明新密钥
  在生效,回 `200` 说明已经回落了。

### 8.4 `_BASE` 的形态守卫

`STA_USER_SSO_LINK_BASE` 必须以 `http://` 或 `https://` 开头,否则**视同未配**
(只回 `ticket`,不回 `url`)。填成 `guantai.example.com`(缺协议)或占位符
`https://你的观测台域名` 之外的乱值都会被降级,而不是产出一条点不开的废链接。
守卫做在 `sso_link_url()` 里 —— 无论值经 ENV / 管理页 / 代码哪条路进来都拦得住。

同理,`sso_link_ttl_s` 的 `[10,300]` 区间有**两道**把关,而且两条路径的行为**不同**:

| 值从哪进来 | 有没有范围校验 | 结果 |
| --- | --- | --- |
| **管理页** | 有 —— `config_registry.coerce()` 按 `ge`/`le` 校验 | 设 99999 直接被拒:`ValueError: 不得大于 300` |
| **`.env`** | **没有** —— `settings._env_int()` 只做整数转换 | 99999 会原样进入 `settings`,靠 `sso_link_ttl_s()` 内的 `max(10, min(300, ...))` 兜住,实际生效 300 |

实测:`.env` 写 99999 → `settings.userauth.sso_link_ttl_s == 99999`,但
`userauth.sso_link_ttl_s()` 返回 **300**。管理页设 1 / -5 / 0 → 实际生效 10 / 10 / 60。

**结论**:`coerce` 挡住的只是管理页那条路;`.env` 那条路**只有使用点的硬钳挡得住**。
这正是把守卫放在唯一使用点(而不是只挂校验器)的价值 —— `sso_link_base` 的
http/https 形态守卫同理。


---


---

## 多 origin 部署:`STA_USER_SSO_LINK_BASE` 请留空

**结论先行:本部署对外有多个公网 origin(直营主站 + 若干代理镜像站,见
`JFVIP-SYSTEM.md` §12)时,这一项应当留空。**

### 为什么可以留空

`url` 字段是**纯便利项**,不是凭证。真正的凭证是 `ticket`:

- `sso_link_url()` 在未配置(或形态不合 `http(s)://`)时返回空串,端点据此
  **只是不回 `url` 字段**,`ticket` 照常返回 —— 签发本身不受任何影响。
- 票据表 `guantai_sso_ticket` 只有
  `token_hash / user_id / created_at / expires_at / used / used_at / used_ip / note`,
  **没有任何 host 或 origin 列**。票据不绑定域名,同一张票在本部署服务的
  **任何** origin 上都能核销。

所以调用方拿到 ticket 后,自己拼 `<自己的origin>/#sso=<ticket>` 就是完整答案,
且天然对每个 origin 都正确 —— 这是一行字符串拼接。

### 为什么不能填

本项是**单值**。填了之后,`/api/auth/sso/link` 回给**所有**调用方的 `url` 都指向
同一个 origin。代理镜像站的接入方拿到的链接指着直营主站,代理的用户点开就被送去
了主站 —— `JFVIP-SYSTEM.md` §12 好不容易做出来的站点隔离,在这一环上整个漏掉。

配置中枢已挂交叉告警:本项非空 + 「账密换链接」已开 + 站点分流已启用,三者同时
成立时保存会告警(三项分属不同 section,各自单看都正常,只有合在一起才是错的)。

### 那能不能「从哪个 origin 调用就拼哪个」

目标是对的,但在这个端点上从请求里推导有两处硬伤:

1. **这是服务端对服务端端点,根本没有 `Origin` 头。** 本端点 docstring 已写明
   「服务端调用无 Origin/Referer 头,照常通过」——`Origin` 是浏览器行为。于是只能
   退而取 `Host`,而反代改写 Host 是极常见配置(参见站点分流为此设的
   `STA_JF_DIRECT_TRUST_XFH`),真那么做会拼出 `http://upstream-pool/#sso=...`
   然后发给真实用户:**静默失效,比不回 `url` 糟得多**。
2. **`Host` 不含 scheme。** 要拼完整 origin 还得再信一个 `X-Forwarded-Proto`;
   判断错就会发出一条 `http://` 的、**带着有效票据**的链接。片段虽不进服务器日志,
   但链接要穿过邮件 / 短信 / 客服转发,明文传输是实打实的暴露。

> 补充一句公道话:原注释「Host 由调用方控制,拿可控输入拼 URL 是反模式」这条,
> 在**本端点上**其实不算强论据 —— 调用方本来就在响应体里拿到了 ticket,给他一条
> 带他自己 Host 的 URL 并没有多泄露任何东西。真正站得住的是上面两条**运维正确性**
> 问题,而不是攻击面问题。

### 若确实需要服务端保留控制权

(适用于接入方是改不动的第三方、只会原样转发你给的 `url`)
更稳的形态是让调用方在请求体里**显式传** `origin`,服务端拿一份白名单校验后再拼:
意图明确、scheme 自带、白名单还能防住密钥泄漏后被人签出指向任意域名的链接
(注意 `sso_link_key` 未配置时 `sso_link_key_ok()` 是恒 `True` 的)。
本次未实现 —— 它需要新增配置项与端点契约变更,超出「清空即可」的范围。
