/* ═══════════════════════════════════════════════════════════════════════
   小叮当九法 · 前端部署构建器(4.0.0)
   目标(用户诉求 3):产出可直接部署的 dist/ —— 移除全部前端注释,
   对**项目自研**的 JS/CSS/HTML 进行压缩 + 混淆加密,尽量抬高逆向门槛。

   分层策略(基于实地契约审计):
   · 自研 JS(app/admin/round-engine/bridge/sim-engine/sim-hud)
       → terser 压缩去注释 → javascript-obfuscator 深度混淆
         (控制流平坦 + 字符串数组 base64+rc4 + 死代码 + 自我保护)。
       关键:**关闭属性名混淆**,并把所有跨文件/跨 iframe 全局契约
       (对象名 + 成员名)列入 reservedNames/reservedStrings 白名单,
       否则父子页 window.JiufaShared.alias / tmegame.gift 之类会断链。
   · 官方原版 bundle(jiufa/js/*.js:React/业务)本就压缩且含点号契约,
       **原样拷贝,不二次处理**(二次混淆既无收益又易破坏)。
   · CSS → csso 结构级压缩去注释。
   · HTML → html-minifier-terser 去注释、压行,内联 JS 用 terser。
   · 其余静态资源(图片/字体/json/wasm…)原样拷贝。

   4.0.0 —— 构建提速(混淆强度/产物契约零变化;实测热点全在
   javascript-obfuscator:7 个自研 JS 单核串行 ≈ 38s,低配 VPS 数分钟):
   ① 并行:重 CPU 的 JS/CSS/HTML 变换分发到 worker_threads 线程池
      (默认 = CPU 核数,FE_JOBS 可覆写;单核机不起线程,零额外开销),
      冷构建墙钟从「各文件之和」降为「最慢单文件」。
   ② 内容寻址缓存:FE_CACHE 指向持久目录时,每个变换产物按
      sha256(工具版本 + 全部变换选项 + 类别 + 源内容) 落盘复用 ——
      重建镜像只重算**真正改过的文件**,其余毫秒级回放(改一个
      app.js 的日常迭代:仅 app.js 重混淆,其余全部命中)。
      Dockerfile 侧经 BuildKit `RUN --mount=type=cache` 把该目录
      挂成跨次构建的持久缓存(docker builder prune 即清空,安全)。
      选项/工具版本纳入指纹:任何调参或升级依赖都会整体自动失效,
      不存在"陈旧产物"问题;未设 FE_CACHE 时行为与无缓存版完全一致。
   ═══════════════════════════════════════════════════════════════════════ */
import { promises as fs } from 'fs';
import path from 'path';
import os from 'os';
import crypto from 'crypto';
import { createRequire } from 'module';
import { Worker, isMainThread, parentPort } from 'worker_threads';
import { minify as terserMinify } from 'terser';
import JsObfuscator from 'javascript-obfuscator';
import { minify as htmlMinify } from 'html-minifier-terser';
import { minify as cssoMinify } from 'csso';

/* SRC/OUT 可经环境变量注入(镜像内:SRC=/fe/src OUT=/fe/dist);默认当前目录 → ./dist */
const SRC = path.resolve(process.env.FE_SRC || '.');
const OUT = path.resolve(process.env.FE_OUT || path.join(SRC, 'dist'));
/* 持久变换缓存目录(可选)。镜像内经 BuildKit cache mount 注入 /fe/cache;
   本地 build-frontend.sh 默认 .fe-cache。留空 = 关闭缓存(行为同 3.9.0)。 */
const CACHE = process.env.FE_CACHE ? path.resolve(process.env.FE_CACHE) : '';
/* 并行度:默认 = min(可用核数, 4);FE_JOBS 显式指定则原样尊重(=1 时不起
   worker,主线程内联执行,零线程开销)。封顶 4 的实测依据(见 4.0.0 审计):
   ① 内存 —— 每个并行混淆线程独立 V8 堆,峰值增量 ≈180MB(1 线程 325MB /
     4 线程 856MB 实测);默认不设顶时 8 核 2GB VPS 冷构建可冲 ~1.6GB,
     与运行中的栈(PostgreSQL 512MB 等)叠加有 OOM 风险。
   ② 速度 —— 7 个重混淆文件里除最大者(≈13s)外合计 ≈27s,3 个辅助线程
     即可在最慢单文件的墙钟内消化完:>4 线程对本仓库零收益。 */
const JOBS = Math.max(1, Number(process.env.FE_JOBS)
  || Math.min(4, (os.availableParallelism ? os.availableParallelism() : os.cpus().length) || 1));

/* 前端资产白名单(相对 SRC 的第一段路径)。
   v2 由"整树黑名单"改为白名单:无论构建上下文里有什么(backend_async、
   *.md、备份 zip…),dist 永远只含前端可部署资产 —— 镜像/产物零源码泄漏
   不再依赖任何手工清理。 */
const WHITELIST = new Set([
  'index.html', 'admin.html', 'sw.js',
  'favicon.ico', 'favicon.png', 'manifest.webmanifest',
  'assets', 'cdn', 'icons', 'jiufa', 'mock',
]);

/* —— 跨文件 / 跨 iframe 全局契约白名单(对象 + 成员名,混淆时保名) —— */
const RESERVED_NAMES = [
  // 顶层共享对象(父页暴露 / 子页读取)
  'JiufaShared', 'JiufaSim', 'JiufaDev', 'RoundEngine', 'RealGameBridge',
  'tmegame', 'FXQFRAME_HOST_WHITE_LIST',
  // 这些对象的成员(点号跨文件访问,必须保名)
  'alias', 'nickname', 'state',
  'ready', 'coin', 'account', 'room', 'unitPrice',
  'gift', 'report', 'request', 'utils',
  // 调试挂载(可选保留,便于线上排障;去掉也不影响功能)
  '__jf', '__errlog', '__lt',
];
const RESERVED_STRINGS = [...RESERVED_NAMES];

/* —— 变换选项(集中为常量:worker 与缓存指纹共用同一事实源)—— */
const TERSER_OB_PRE = {            // 混淆前置:去注释/压缩(自研 JS 第一遍)
  compress: { drop_debugger: true, passes: 2 },
  mangle: { reserved: RESERVED_NAMES },
  format: { comments: false },
};
const TERSER_LIGHT = {             // 轻处理:仅压缩去注释(sw.js / mock 层)
  compress: { passes: 2 },
  mangle: { reserved: RESERVED_NAMES },
  format: { comments: false },
};
const TERSER_INLINE = {            // HTML 内联 <script> 压缩
  compress: true,
  mangle: { reserved: RESERVED_NAMES },
  format: { comments: false },
};
const OBFUSCATE_OPTS = {
  compact: true,
  controlFlowFlattening: true,
  controlFlowFlatteningThreshold: 0.72,
  deadCodeInjection: true,
  deadCodeInjectionThreshold: 0.32,
  stringArray: true,
  stringArrayEncoding: ['base64', 'rc4'],
  stringArrayThreshold: 0.78,
  stringArrayWrappersType: 'function',
  stringArrayWrappersCount: 2,
  stringArrayCallsTransform: true,
  splitStrings: true,
  splitStringsChunkLength: 8,
  numbersToExpressions: true,
  simplify: true,
  transformObjectKeys: false,          // ★ 不改对象键 —— 保跨文件成员契约
  renameProperties: false,             // ★ 不改属性名 —— 同上
  identifierNamesGenerator: 'mangled',
  renameGlobals: true,                 // ★ 顶层函数/变量也重命名(白名单契约名经 reservedNames 豁免)
  selfDefending: true,
  disableConsoleOutput: false,
  reservedNames: RESERVED_NAMES.map(n => `^${n}$`),
  reservedStrings: RESERVED_STRINGS.map(s => `^${s}$`),
};
const HTML_OPTS_STATIC = {          // 函数成员(minifyJS)不可序列化,静态部分单列供指纹
  collapseWhitespace: true,
  removeComments: true,
  minifyCSS: true,
  ignoreCustomComments: [],
  keepClosingSlash: true,
  caseSensitive: true,
};

/* —— 变换实现(主线程内联 / worker 内均直接调用)—— */
async function buildJs(code, label) {
  const pass1 = await terserMinify(code, TERSER_OB_PRE);
  if (pass1.error) throw new Error(`terser ${label}: ${pass1.error}`);
  const ob = JsObfuscator.obfuscate(pass1.code, OBFUSCATE_OPTS);
  return ob.getObfuscatedCode();
}
async function buildJsLight(code, label) {
  const r = await terserMinify(code, TERSER_LIGHT);
  if (r.error) throw new Error(`terser ${label}: ${r.error}`);
  return r.code ?? code;
}
async function buildCss(code) { return cssoMinify(code).css; }
async function buildHtml(html) {
  return htmlMinify(html, {
    ...HTML_OPTS_STATIC,
    minifyJS: (code) => terserMinify(code, TERSER_INLINE)
      .then(r => r.code || code).catch(() => code),
  });
}
const TRANSFORM = { js_ob: buildJs, js_light: buildJsLight, css: buildCss, html: buildHtml };

/* ═══ worker 分支:同文件自举 —— 收 {id,kind,code,label},回 {id,out|err} ═══ */
if (!isMainThread) {
  parentPort.on('message', async ({ id, kind, code, label }) => {
    try { parentPort.postMessage({ id, out: await TRANSFORM[kind](code, label) }); }
    catch (e) { parentPort.postMessage({ id, err: String(e && e.message || e) }); }
  });
} else {
  main().catch(e => { console.error('FATAL ::', e && e.message || e); process.exit(1); });
}

/* ═══ 缓存指纹:工具版本 + 全部变换选项 —— 调参/升级即自动整体失效 ═══
   ⚠ 维护护栏:指纹**不含变换实现代码本身**(builder 重构不应白白作废缓存)。
   若改动 buildJs/buildJsLight/buildCss/buildHtml 的**输出语义**(而非仅上方
   选项常量),必须手动把下方 fmt 版本号 +1,否则旧缓存会回放旧式产物。 */
function fingerprint() {
  const req = createRequire(import.meta.url);
  const v = (p) => { try { return req(`${p}/package.json`).version; } catch { return '?'; } };
  return crypto.createHash('sha256').update(JSON.stringify({
    fmt: 'fe-cache-1', node: process.version.split('.')[0],
    tools: { terser: v('terser'), obfuscator: v('javascript-obfuscator'),
             html: v('html-minifier-terser'), csso: v('csso') },
    opts: { TERSER_OB_PRE, TERSER_LIGHT, TERSER_INLINE, OBFUSCATE_OPTS,
            HTML_OPTS_STATIC, minifyJS: 'terser:TERSER_INLINE' },
  })).digest('hex');
}
const cacheKey = (fp, kind, raw) =>
  crypto.createHash('sha256').update(fp).update('\0' + kind + '\0').update(raw).digest('hex');
const cachePath = (key) => path.join(CACHE, key.slice(0, 2), key + '.bin');
async function cacheGet(key) {
  try { return await fs.readFile(cachePath(key)); } catch { return null; }
}
async function cachePut(key, buf) {
  try {
    const dst = cachePath(key);
    await fs.mkdir(path.dirname(dst), { recursive: true });
    const tmp = dst + '.tmp-' + process.pid + '-' + Math.random().toString(36).slice(2);
    await fs.writeFile(tmp, buf);
    await fs.rename(tmp, dst);                            // 原子落位:并发构建互不踩踏
  } catch { /* 缓存写失败不致命:仅本次不复用 */ }
}
/* 轻量修剪:仅保最近 500 个产物(按 mtime),防缓存目录无界膨胀 */
async function cachePrune() {
  try {
    const all = [];
    for (const d of await fs.readdir(CACHE)) {
      if (d.length !== 2) continue;
      const dir = path.join(CACHE, d);
      for (const f of await fs.readdir(dir)) {
        if (!f.endsWith('.bin')) continue;
        const abs = path.join(dir, f);
        all.push({ abs, m: (await fs.stat(abs)).mtimeMs });
      }
    }
    all.sort((a, b) => b.m - a.m);
    await Promise.all(all.slice(500).map(e => fs.unlink(e.abs).catch(() => {})));
  } catch { /* 修剪失败无害 */ }
}

/* ═══ 线程池:惰性起 worker,先到先服务;JOBS=1 时纯内联(零线程开销) ═══ */
function makePool() {
  if (JOBS <= 1) return {
    run: (kind, code, label) => TRANSFORM[kind](code, label),
    destroy: () => {},
  };
  const workers = [], idle = [], queue = [];
  const pending = new Map();   // id → {res, rej}
  let seq = 0;
  const spawn = () => {
    const w = new Worker(new URL(import.meta.url));
    w.on('message', (m) => {
      const p = pending.get(m.id); pending.delete(m.id);
      if (p) (m.err != null) ? p.rej(new Error(m.err)) : p.res(m.out);
      idle.push(w); pump();
    });
    w.on('error', (e) => {           // worker 崩溃:在途 + 排队任务全部失败,构建整体中止
      for (const p of pending.values()) p.rej(e);
      pending.clear();
      for (const t of queue.splice(0)) t.rej(e);
    });
    w.on('exit', (code) => {         // 兜底:worker 非零退出却未触发 error(如线程内 process.exit)
      if (!code) return;             //   —— 同样拒绝全部任务,杜绝 Promise 悬挂导致构建卡死
      const e = new Error(`worker 异常退出(code=${code})`);
      for (const p of pending.values()) p.rej(e);
      pending.clear();
      for (const t of queue.splice(0)) t.rej(e);
    });
    workers.push(w);
    return w;
  };
  const pump = () => {
    while (queue.length && (idle.length || workers.length < JOBS)) {
      const w = idle.pop() || spawn();
      const t = queue.shift();
      pending.set(t.id, t);
      w.postMessage({ id: t.id, kind: t.kind, code: t.code, label: t.label });
    }
  };
  return {
    run: (kind, code, label) => new Promise((res, rej) => {
      queue.push({ id: ++seq, kind, code, label, res, rej }); pump();
    }),
    destroy: () => workers.forEach(w => w.terminate()),
  };
}

/* 自研 JS:需重度混淆的业务代码 */
const SELF_JS = new Set([
  'assets/app.js', 'assets/admin.js', 'assets/round-engine.js',
  'jiufa/bridge.js', 'jiufa/sim-engine.js', 'jiufa/sim-hud.js',
]);
// 仅压缩去注释(不做激进混淆):
//  · sw.js —— Service Worker 环境,selfDefending/字符串数组包装易报错
//  · mock/mock-api.js —— 纯本地演示层(生产接真实后端时 index.html 不加载它),
//    其 window.fetch 拦截 + 正则路由被 splitStrings/numbersToExpressions 改坏,
//    且无重度保护价值
//  · jiufa/jf-fix.js —— 劫持媒体元素原生 src setter 的兼容垫片:深度混淆会破坏
//    setter 的 this 绑定(实测 Illegal invocation + a[aV(...)] is not a function ×11,
//    业务 bundle 初始化即崩,React 不挂载);无保护价值,轻压缩即可
//  · jiufa/jf-boot.js —— 装载自愈守卫(4.1.2):与 jf-fix 同档轻处理 —— 守卫类
//    垫片深度混淆有破坏 this 绑定/时序的前科,且其价值在可靠性不在保密
//  · jiufa/jf-num.js —— 真实×官方妖兽编号叠加层(2.9.8):MutationObserver
//    叠加类垫片同 jf-fix/jf-boot 档轻处理,价值在可靠性不在保密
//  · jiufa/jf-coin.js —— 币种口径开关(真实×官方=星币):以 getter/setter 占住
//    window.fetch 并按赋值时序包住 sim-engine 的 shim,深度混淆易改坏属性描述符
//    与包装时序,同 jf-fix/jf-boot/jf-num 档轻处理
const LIGHT_JS = new Set(['sw.js', 'mock/mock-api.js', 'jiufa/jf-fix.js', 'jiufa/jf-boot.js', 'jiufa/jf-num.js', 'jiufa/jf-coin.js']);
// 官方原版 bundle 目录:原样拷贝(不二次混淆)
const VENDOR_JS_DIRS = ['jiufa/js/'];
// 预混淆产物(源码即 javascript-obfuscator 输出,自带 selfDefending 护甲):
//  二次混淆会把护甲诱饵函数 function(){return'newState';} 里的字符串字面量
//  抽进外层字符串表,诱饵 toString() 失去引号 → 护甲正则校验必败 →
//  进入无限 push(Math.random()) 惩罚循环 → 主线程死锁 + 堆暴涨,整页崩溃
//  (实测:混淆后单独加载即冻死,heap 100–800MB;同源 iframe 连父页一起死)。
//  它们已是混淆态,再包一层无保护增益,故原样拷贝。
const PREOBF_JS = new Set(['jiufa/sim-engine.js', 'jiufa/bridge.js', 'jiufa/sim-hud.js']);

const isVendorJs = (rel) => VENDOR_JS_DIRS.some(d => rel.startsWith(d));

async function walk(dir) {
  const out = [];
  for (const ent of await fs.readdir(dir, { withFileTypes: true })) {
    if (ent.name.startsWith('.') || ent.name === 'node_modules') continue;
    const abs = path.join(dir, ent.name);
    const first = path.relative(SRC, abs).split(path.sep)[0];   // 相对 SRC 第一段
    if (!WHITELIST.has(first)) continue;                        // 白名单外一律不进 dist
    if (ent.isDirectory()) { out.push(...await walk(abs)); continue; }
    if (/\.(md|markdown|txt|py|map|zip|log)$/i.test(ent.name)) continue;   // 资产子树里混入的文档/源码/映射一律不入 dist(如 jiufa/README.md)
    out.push(abs);
  }
  return out;
}

/* 文件分类:kind=null 表示原样拷贝(官方 bundle / 静态资源) */
function classify(rel) {
  const ext = path.extname(rel).toLowerCase();
  if (ext === '.js') {
    if (isVendorJs(rel)) return { kind: null, tag: 'js_copy' };
    if (PREOBF_JS.has(rel)) return { kind: null, tag: 'js_copy' };   // 预混淆产物:原样拷贝(见 PREOBF_JS 注释)
    if (LIGHT_JS.has(rel)) return { kind: 'js_light', tag: 'js_light' };
    return { kind: 'js_ob', tag: 'js_ob' };                     // 自研 / 未分类:混淆
  }
  if (ext === '.css') return { kind: 'css', tag: 'css' };
  if (ext === '.html') return { kind: 'html', tag: 'html' };
  return { kind: null, tag: 'asset' };
}

/* 简单信号量:限制并发文件处理数(喂满线程池又不一次性读爆内存) */
function semaphore(n) {
  let active = 0; const waiters = [];
  const next = () => { active--; const w = waiters.shift(); if (w) { active++; w(); } };
  return async (fn) => {
    if (active >= n) await new Promise(r => waiters.push(r));
    else active++;
    try { return await fn(); } finally { next(); }
  };
}

const stat = { js_ob: 0, js_copy: 0, css: 0, html: 0, asset: 0,
               bytesIn: 0, bytesOut: 0, js_light: 0, cache_hit: 0, cache_miss: 0 };

async function main() {
  const t0 = Date.now();
  await fs.rm(OUT, { recursive: true, force: true });
  if (CACHE) await fs.mkdir(CACHE, { recursive: true });
  const fp = CACHE ? fingerprint() : '';
  const pool = makePool();
  const limit = semaphore(Math.max(4, JOBS * 2));
  const files = await walk(SRC);
  /* 大文件优先派发:多核下墙钟下界 = 最慢单文件(≈13s 的 sim-hud)。若按
     目录序先到先服务,最大文件可能排队到后段才开工,墙钟被推高到
     「排队延迟 + 单文件耗时」。这里把待变换文件按体量降序置前(资产拷贝
     纯 I/O、顺序无关,殿后),保证重活第一时间铺满线程池。 */
  const sized = await Promise.all(files.map(async abs => {
    const rel = path.relative(SRC, abs).split(path.sep).join('/');
    const heavy = classify(rel).kind ? (await fs.stat(abs)).size : -1;
    return { abs, heavy };
  }));
  sized.sort((a, b) => b.heavy - a.heavy);

  try {
    await Promise.all(sized.map(({ abs }) => limit(async () => {
      const rel = path.relative(SRC, abs).split(path.sep).join('/');
      const dst = path.join(OUT, rel);
      await fs.mkdir(path.dirname(dst), { recursive: true });
      const raw = await fs.readFile(abs);
      stat.bytesIn += raw.length;
      try {
        const { kind, tag } = classify(rel);
        if (!kind) {                                  // 官方 bundle / 静态资源:原样
          await fs.writeFile(dst, raw);
          stat[tag]++; stat.bytesOut += raw.length;
          return;
        }
        let out = null, key = '';
        if (CACHE) {
          key = cacheKey(fp, kind, raw);
          const hit = await cacheGet(key);
          if (hit) { out = hit; stat.cache_hit++; console.log(`  ⚡ 缓存命中  ${rel}`); }
        }
        if (out == null) {
          const t = Date.now();
          out = Buffer.from(await pool.run(kind, raw.toString('utf8'), rel), 'utf8');
          if (CACHE) { stat.cache_miss++; await cachePut(key, out); }
          console.log(`  ⚒ ${((Date.now() - t) / 1000).toFixed(1).padStart(5)}s  ${rel}`);
        }
        await fs.writeFile(dst, out);
        stat[tag]++; stat.bytesOut += out.length;
      } catch (e) {
        console.error('FAIL', rel, '::', e.message);
        throw e;
      }
    })));
  } finally {
    pool.destroy();
  }
  if (CACHE) await cachePrune();
  stat.jobs = JOBS; stat.ms = Date.now() - t0;
  console.log(JSON.stringify(stat, null, 1));
}
