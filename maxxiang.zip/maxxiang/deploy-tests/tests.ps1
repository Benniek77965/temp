﻿# tests.ps1 — deploy-maxxiang.ps1 函数级测试（Linux/pwsh 与 Windows 均可运行）
# 路径可用环境变量覆盖：S / PROJ / ZIP。约定：用例体内不使用单引号字符（以 [char]39 拼接）。
$ErrorActionPreference = 'Stop'
$S    = if ($env:S)    { $env:S }    else { Join-Path $PSScriptRoot 'deploy-maxxiang.ps1' }
$PROJ = if ($env:PROJ) { $env:PROJ } else { '/home/claude/maxxiang_extract/maxxiang' }
$ZIP  = if ($env:ZIP)  { $env:ZIP }  else { '/home/claude/maxxiang.zip' }
$env:S = $S; $env:PROJ = $PROJ; $env:ZIP = $ZIP
$script:PASS = 0; $script:FAIL = 0

function T([string]$Name, [string]$Body) {
  $pre = '$ErrorActionPreference="Stop"; $env:MAXX_PS_TEST="1"; $env:MAXX_PS_NO_MAIN="1"; . $env:S; '
  $out = & pwsh -NoProfile -Command ($pre + $Body) 2>&1
  if ($LASTEXITCODE -eq 0) { Write-Host "PASS  $Name"; $script:PASS++ }
  else { Write-Host "FAIL  $Name"; $out | ForEach-Object { Write-Host "      $_" }; $script:FAIL++ }
}

# ── T1/T2 帮助与平台闸（直接 -File 路径） ─────────────────────────────────────
$h = & pwsh -NoProfile -File $S -Help 2>&1 | Out-String
if ($LASTEXITCODE -eq 0 -and $h -match '九法观测台' -and $h -match '-Yes') { Write-Host 'PASS  -Help 头部渲染'; $PASS++ }
else { Write-Host 'FAIL  -Help'; $FAIL++ }
$g = & pwsh -NoProfile -File $S status 2>&1 | Out-String
if ($LASTEXITCODE -ne 0 -and $g -match 'Windows') { Write-Host 'PASS  非 Windows 平台闸（指引 .sh）'; $PASS++ }
else { Write-Host "FAIL  平台闸 rc=$LASTEXITCODE"; $FAIL++ }

# ── 1.1.0 备份轮转 ──────────────────────────────────────────────────────────────
T 'Invoke-PruneBackups：完整备份只留最近 N 份；不完整备份与外来条目不碰' '
$d = Join-Path ([IO.Path]::GetTempPath()) ("bk-"+[Guid]::NewGuid().ToString("N")); New-Item -ItemType Directory $d | Out-Null
foreach ($ts in "20260101-000000","20260102-000000","20260103-000000","20260104-000000") { $p = Join-Path $d $ts; New-Item -ItemType Directory $p | Out-Null; Set-Content (Join-Path $p "db.dump") "x"; Set-Content (Join-Path $p "meta.txt") "x" }
$p5 = Join-Path $d "20260105-000000"; New-Item -ItemType Directory $p5 | Out-Null; Set-Content (Join-Path $p5 "db.dump") "x"
New-Item -ItemType Directory (Join-Path $d "my-keep") | Out-Null; Set-Content (Join-Path $d "notes.txt") "x"; Set-Content (Join-Path $d "pre-update-20260101-000000-code.zip") "x"
$out = (Invoke-PruneBackups $d "2" "full" *>&1 | Out-String)
foreach ($n in "20260104-000000","20260103-000000","20260105-000000","my-keep","notes.txt","pre-update-20260101-000000-code.zip") { if (-not (Test-Path (Join-Path $d $n))) { throw "不该删:$n" } }
foreach ($n in "20260102-000000","20260101-000000") { if (Test-Path (Join-Path $d $n)) { throw "该删未删:$n" } }
if ($out -notmatch "不完整") { throw "应点名不完整备份" }
Remove-Item $d -Recurse -Force
'

T 'Invoke-PruneBackups：代码快照轮转；0=不清理；非法值不删；前导零按十进制' '
$d = Join-Path ([IO.Path]::GetTempPath()) ("bk-"+[Guid]::NewGuid().ToString("N")); New-Item -ItemType Directory $d | Out-Null
foreach ($ts in "20260101-000000","20260102-000000","20260103-000000") { Set-Content (Join-Path $d "pre-update-$ts-code.zip") "x" }
Set-Content (Join-Path $d "pre-update-20260104-000000-code.tgz") "x"; Set-Content (Join-Path $d "pre-update-junk-code.zip") "x"
Invoke-PruneBackups $d "0" "code" *>$null; if (@(Get-ChildItem $d).Count -ne 5) { throw "0 不该清理" }
$out = (Invoke-PruneBackups $d "abc" "code" *>&1 | Out-String); if (@(Get-ChildItem $d).Count -ne 5 -or $out -notmatch "无效") { throw "非法值不该删且应告警" }
Invoke-PruneBackups $d "-1" "code" *>$null; if (@(Get-ChildItem $d).Count -ne 5) { throw "负数不该删" }
Invoke-PruneBackups $d "02" "code" *>$null
foreach ($n in "pre-update-20260104-000000-code.tgz","pre-update-20260103-000000-code.zip","pre-update-junk-code.zip") { if (-not (Test-Path (Join-Path $d $n))) { throw "不该删:$n" } }
foreach ($n in "pre-update-20260102-000000-code.zip","pre-update-20260101-000000-code.zip") { if (Test-Path (Join-Path $d $n)) { throw "该删未删:$n" } }
Remove-Item $d -Recurse -Force
'

T 'Get-BackupKeep：默认 7；-Keep / MAXX_BACKUP_KEEP 覆盖' '
if ((Get-BackupKeep) -ne "7") { throw "默认应为 7" }
$Keep = "3"; if ((Get-BackupKeep) -ne "3") { throw "-Keep 应覆盖" }
$env:MAXX_BACKUP_KEEP = "5"      # 子进程继承本进程环境(含框架设好的测试模式开关)
$v = & pwsh -NoProfile -Command (". " + $env:S + "; Get-BackupKeep")
if (($v | Select-Object -Last 1) -ne "5") { throw "环境变量应覆盖,实得 $v" }
'

T 'Test-Markers 正/反' '
if (-not (Test-Markers $env:PROJ)) { throw "真项目应通过" }
if (Test-Markers "/tmp") { throw "/tmp 不应通过" }
'

T 'Expand-ProjectZip：真实压缩包（嵌套一层）+ 坏包明确报错' '
$d = Join-Path ([IO.Path]::GetTempPath()) ("t-"+[Guid]::NewGuid().ToString("N"))
Expand-ProjectZip $env:ZIP $d
if (-not (Test-Markers $d)) { throw "解压后 markers 缺失" }
Remove-Item $d -Recurse -Force
$bad = Join-Path ([IO.Path]::GetTempPath()) ("bad-"+[Guid]::NewGuid().ToString("N")+".zip")
Set-Content $bad "not a zip"
$threw = $false
try { Expand-ProjectZip $bad ($d+"-x") } catch { $threw = ($_.Exception.Message -match "解压失败") }
if (-not $threw) { throw "坏包应抛解压失败" }
'

T 'Write-EnvLF 字节级（无 BOM/纯 LF）+ Get-EnvValue 语义' '
$q = [char]39
$f = Join-Path ([IO.Path]::GetTempPath()) ("env-"+[Guid]::NewGuid().ToString("N"))
$script:EnvFile = $f
Write-EnvLF $f @("A=1", ("B=" + $q + "sq" + $q), "C=`"dq`"", "EMPTY=", "A=2",
                 ("HASH=" + $q + "pbkdf2_sha256`$2`$x`$y" + $q))
$raw = [IO.File]::ReadAllBytes($f)
if ($raw[0] -eq 0xEF) { throw "不应有 BOM" }
if ($raw -contains 0x0D) { throw "不应含 CR" }
if ($raw[-1] -ne 0x0A) { throw "应以 LF 结尾" }
if ((Get-EnvValue "A") -ne "2") { throw "尾行覆盖失败" }
if ((Get-EnvValue "B") -ne "sq") { throw "单引号剥离失败" }
if ((Get-EnvValue "C") -ne "dq") { throw "双引号剥离失败" }
if ($null -ne (Get-EnvValue "EMPTY")) { throw "空值应视同不存在" }
if ($null -ne (Get-EnvValue "NOPE")) { throw "缺键应为 null" }
$got = Get-EnvValue "HASH"
if ($got -ne "pbkdf2_sha256`$2`$x`$y") { throw "散列单引号保真失败：$got" }
# 5.2.0:与 Docker Compose 同口径 —— 行内注释 / 引号后的注释 / 无空白的 # 不是注释
Write-EnvLF $f @("P=5199   # port", ("Q=" + $q + "x # n" + $q), "R=`"y`" # c", "S=z#n")
if ((Get-EnvValue "P") -ne "5199") { throw "行内注释未剥离" }
if ((Get-EnvValue "Q") -ne "x # n") { throw "引号内的 # 被误当注释" }
if ((Get-EnvValue "R") -ne "y") { throw "引号后的注释未剥离" }
if ((Get-EnvValue "S") -ne "z#n") { throw "无空白的 # 被误当注释" }
'

T 'Test-PortInUse：监听/空闲（TcpListener 兜底路径）' '
$l = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, 45123); $l.Start()
try {
  if (-not (Test-PortInUse 45123)) { throw "45123 应判占用" }
} finally { $l.Stop() }
if (Test-PortInUse 45177) { throw "45177 应判空闲" }
'

T '向导金测：票据/uid/白名单三处重输 + 新默认(retention=7,workers=10) + 落盘断言' '
$q = [char]39
function Get-DCOutput { $null }
$d = Join-Path ([IO.Path]::GetTempPath()) ("wiz-"+[Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $d | Out-Null
$script:InstallDir = $env:PROJ
$script:DeployDir  = $d
$script:EnvFile    = Join-Path $d ".env"
$tick = "a" * 64
$queue = [System.Collections.Queue]::new()
@("", "y", "BAD`$TICKET!!", $tick, "abc", "12345",
  "y", "pw123!ok", "pw123!ok", "bad acct!", "13268237005", "10.0.0.0/8; rm -rf /", "",
  "", "y", "", "", "") | ForEach-Object { $queue.Enqueue($_) }
$script:TestAnswers = $queue
$log = & { Invoke-Wizard } 6>&1 | Out-String
if ($log -notmatch "请重输或留空") { throw "缺票据重输提示`n$log" }
if ($log -notmatch "uid 应为纯数字") { throw "缺 uid 重输提示" }
if ($log -notmatch "白名单只允许") { throw "缺白名单重输提示" }
if ($log -notmatch "账号只允许") { throw "缺账号重输提示" }
Write-EnvFile 6>&1 | Out-Null
$e = Get-Content $script:EnvFile -Raw
foreach ($must in @("`nWEB_PORT=5173`n", ("`nSTA_AUTH_TICKET=" + $tick + "`n"),
                    "`nSTA_AUTH_UID=12345`n",
                    ("`nSTA_ADMIN_USERNAME=13268237005`nSTA_ADMIN_PASSWORD=" + $q + "pw123!ok" + $q + "`n"),
                    "`nSTA_RETENTION_DAYS=7`n", "`nSTA_DISCOVERY_ENABLED=true`n",
                    "`nSTA_LOG_LEVEL=INFO`n")) {
  if (-not $e.Contains($must)) { throw ("缺字段：" + $must.Trim() + "`n----`n" + $e) }
}
if ($e -match "(?m)^STA_ADMIN_IP_ALLOW=") { throw "白名单留空不应写入键" }
if ($e -match "(?m)^PIP_INDEX_URL=") { throw "K2：默认不应写入实键" }
if ($e -notmatch "(?m)^# PIP_INDEX_URL=https://pypi\.tuna") { throw "K1：应保留注释示例" }
if ($script:WorkerReplicas -ne 3) { throw "空输入下 worker 默认应为 3（3.6.0 起脚本顶部单源默认=3；旧期望 10 为 3.4.2 口径，5.2.0 复查修正），实为 $($script:WorkerReplicas)" }
$raw = [IO.File]::ReadAllBytes($script:EnvFile)
if ($raw[0] -eq 0xEF -or ($raw -contains 0x0D)) { throw "编码硬约束被破坏" }
Remove-Item $d -Recurse -Force
'

T '向导非交互：-Ticket 非法 → Die（测试内改抛以便断言）' '
function Die([string]$m) { throw $m }
function Get-DCOutput { $null }
$script:InstallDir = $env:PROJ
$script:Ticket = "xx`$bad"
$queue = [System.Collections.Queue]::new()
@("", "y") | ForEach-Object { $queue.Enqueue($_) }
$script:TestAnswers = $queue
$threw = $null
try { Invoke-Wizard 6>&1 | Out-Null } catch { $threw = $_.Exception.Message }
if (-not $threw) { throw "应当 Die" }
if ($threw -notmatch "MAXX_TICKET" -or $threw -notmatch "十六进制") { throw "提示不完整：$threw" }
'

T 'Protect-AdminPassword：复用遗留明文自取 → 转散列 + 双键清理' '
$q = [char]39
$d = Join-Path ([IO.Path]::GetTempPath()) ("hd-"+[Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $d | Out-Null
$script:EnvFile = Join-Path $d ".env"
Write-EnvLF $script:EnvFile @(("STA_ADMIN_PASSWORD=" + $q + "leftpw" + $q),
                              ("STA_ADMIN_PASSWORD_HASH=" + $q + "pbkdf2_sha256`$1`$old`$old" + $q),
                              "OTHER=1")
$script:V.AdminPw = ""
$script:Seen = $null
function Get-AdminHash([string]$Pw) { $script:Seen = $Pw; return "pbkdf2_sha256`$2`$new`$new" }
function Invoke-DC { $script:LastDCExit=0 }
Protect-AdminPassword 6>&1 | Out-Null
if ($script:Seen -ne "leftpw") { throw "应从 .env 取回遗留明文，实收：$($script:Seen)" }
$e = Get-Content $script:EnvFile -Raw
if ($e -match "(?m)^STA_ADMIN_PASSWORD=") { throw "明文行未清除" }
if ((@([regex]::Matches($e,"(?m)^STA_ADMIN_PASSWORD_HASH="))).Count -ne 1) { throw "HASH 行应恰 1 条" }
$want = "STA_ADMIN_PASSWORD_HASH=" + $q + "pbkdf2_sha256`$2`$new`$new" + $q
if (-not $e.Contains($want)) { throw "新散列未按单引号写入" }
if ($e -notmatch "(?m)^OTHER=1$") { throw "其余键应保留" }
Remove-Item $d -Recurse -Force
'

T 'Cmd-AdminHash：另一入口的双键清理与热重建参数' '
$q = [char]39
$d = Join-Path ([IO.Path]::GetTempPath()) ("ah-"+[Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $d | Out-Null
$script:EnvFile = Join-Path $d ".env"
Write-EnvLF $script:EnvFile @(("STA_ADMIN_PASSWORD=" + $q + "x" + $q), "K=1")
function Get-AdminHash([string]$Pw) { "pbkdf2_sha256`$9`$s`$t" }
function Invoke-DC { $r=@($args); if($r.Count -gt 0 -and $r[0] -eq "-AllowFail"){$r=@($r|Select-Object -Skip 1)}; $script:LastComposeArgs=$r; $script:LastDCExit=0 }
$script:CommandArgs = @("newpw")
Cmd-AdminHash 6>&1 | Out-Null
$e = Get-Content $script:EnvFile -Raw
if ($e -match "(?m)^STA_ADMIN_PASSWORD=") { throw "明文未清" }
if ((@([regex]::Matches($e,"(?m)^STA_ADMIN_PASSWORD_HASH="))).Count -ne 1) { throw "HASH 应为独立行且恰 1 条（粘连回归）" }
if ($e -notmatch "(?m)^K=1$") { throw "K 行应独立保留（粘连回归）" }
if ($e -notmatch "pbkdf2_sha256.9.s.t") { throw "散列未写入" }
if (($script:LastComposeArgs -join " ") -ne "up -d web") { throw ("热重建参数异常：" + ($script:LastComposeArgs -join " ")) }
Remove-Item $d -Recurse -Force
'

T 'Cmd-Scale：持久化 + 编排参数' '
$d = Join-Path ([IO.Path]::GetTempPath()) ("sc-"+[Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $d | Out-Null
$script:StateFile = Join-Path $d "st"; $script:CfgWebPort = 5173
function Invoke-DC { $r=@($args); if($r.Count -gt 0 -and $r[0] -eq "-AllowFail"){$r=@($r|Select-Object -Skip 1)}; $script:LastComposeArgs=$r; $script:LastDCExit=0 }
function Get-DCOutput { @("c1","c2","c3") }
$script:CommandArgs = @("3")
Cmd-Scale 6>&1 | Out-Null
if ((Get-Content $script:StateFile -Raw) -notmatch "WORKER_REPLICAS=3") { throw "状态未持久化" }
if (($script:LastComposeArgs -join " ") -ne "up -d --no-build --scale worker=3 worker") { throw ("编排参数异常：" + ($script:LastComposeArgs -join " ")) }
Remove-Item $d -Recurse -Force
'

T 'Cmd-Seed -File：宿主路径正斜杠化挂载翻译' '
$f = Join-Path ([IO.Path]::GetTempPath()) ("rooms-"+[Guid]::NewGuid().ToString("N")+".txt")
Set-Content $f "2678075"
function Invoke-DC { $r=@($args); if($r.Count -gt 0 -and $r[0] -eq "-AllowFail"){$r=@($r|Select-Object -Skip 1)}; $script:LastComposeArgs=$r; $script:LastDCExit=0 }
function Show-SampleTicketWarn { }
$script:File = $f; $script:CommandArgs = @()
Cmd-Seed 6>&1 | Out-Null
$j = $script:LastComposeArgs -join " "
$expect = ((Resolve-Path $f).Path -replace "\\","/") + ":/tmp/rooms.seed:ro"
if ($j -notmatch "run --rm -T -v ") { throw "缺 -v 挂载参数（公共参数吞噬回归）：$j" }
if ($j -notmatch [regex]::Escape($expect)) { throw "挂载翻译异常：$j" }
if ($j -notmatch "seed --file /tmp/rooms.seed") { throw "seed 参数异常：$j" }
Remove-Item $f -Force
'

T 'Get-RelaunchArgs：提权参数完整重建（值参/开关/数组）' '
$script:Ticket = "abc123"; $script:Yes = $true; $script:AdminOff = $true; $script:AdminUser = "13268237005"
$script:RegistryMirror = @("https://m1","https://m2")
$a = Get-RelaunchArgs
$j = $a -join " "
foreach ($must in @("-Ticket abc123","-RegistryMirror https://m1","-RegistryMirror https://m2","-Yes","-AdminOff","-AdminUser 13268237005")) {
  if ($j -notmatch [regex]::Escape($must)) { throw ("缺参数片段 [" + $must + "]：" + $j) }
}
if ($a[3] -ne "-File" -or $a[4] -ne $env:S) { throw "-File 段应为脚本自身路径" }
'

# （哨兵已移至文件末尾）

T 'PIP 源写入路径 + Set-EnvKV 幂等替换' '
$d = Join-Path ([IO.Path]::GetTempPath()) ("pip-"+[Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $d | Out-Null
$script:EnvFile = Join-Path $d ".env"
$script:V.PipMirror = $script:PypiCnDefault
$script:V.Ticket = "PUT_FRESH_TICKET_HERE"; $script:V.Uid = "0"; $script:V.PgPw = "Abc123"
Write-EnvFile 6>&1 | Out-Null
$e = Get-Content $script:EnvFile -Raw
if ($e -notmatch "(?m)^PIP_INDEX_URL=https://pypi\.tuna") { throw "实键未落盘" }
if ($e -match "(?m)^# PIP_INDEX_URL=https://pypi\.tuna") { throw "注释示例应被实键取代" }
Set-EnvKV "PIP_INDEX_URL" "https://mirrors.aliyun.com/pypi/simple/"
$e2 = Get-Content $script:EnvFile -Raw
if ((@([regex]::Matches($e2,"(?m)^PIP_INDEX_URL="))).Count -ne 1) { throw "Set-EnvKV 应替换而非追加" }
if ((Get-EnvValue "PIP_INDEX_URL") -ne "https://mirrors.aliyun.com/pypi/simple/") { throw "替换值未生效" }
$raw = [IO.File]::ReadAllBytes($script:EnvFile)
if ($raw[0] -eq 0xEF -or ($raw -contains 0x0D)) { throw "Set-EnvKV 破坏了 LF/无BOM 约束" }
Remove-Item $d -Recurse -Force
'

T 'Invoke-BuildStack 自愈：首败写清华源重试成功；已配源不重试' '
$d = Join-Path ([IO.Path]::GetTempPath()) ("bs-"+[Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $d | Out-Null
$script:EnvFile = Join-Path $d ".env"; Write-EnvLF $script:EnvFile @("K=1")
$script:Yes = $true; $script:WorkerReplicas = 3; $script:Calls = 0
function Invoke-DC { $r=@($args); if($r[0] -eq "-AllowFail"){$r=@($r|Select-Object -Skip 1)}
  $script:LastComposeArgs=$r; $script:Calls++
  # 5.2.0 复查:Invoke-BuildStack 早已改为「先甄别根因,只有 PyPI 拉取类失败才换源重试」,
  # 旧桩只给退出码、不给输出,于是永远被判为「非 PyPI 失败」—— 用例随之过期。桩补上真实的 pip 报错。
  $script:LastDCOutput = $(if($script:Calls -eq 1){"ERROR: Could not find a version that satisfies the requirement fastapi (from versions: none)"}else{""})
  $script:LastDCExit = $(if($script:Calls -eq 1){17}else{0}) }
$ok = Invoke-BuildStack 6>&1 | Select-Object -Last 1
if (-not $ok) { throw "应自愈成功" }
if ($script:Calls -ne 2) { throw "应恰重试一次，calls=$($script:Calls)" }
if ((Get-EnvValue "PIP_INDEX_URL") -ne $script:PypiCnDefault) { throw "应写入清华源" }
if (($script:LastComposeArgs -join " ") -ne "up -d --build --scale worker=3") { throw ("编排参数异常：" + ($script:LastComposeArgs -join " ")) }
$script:Calls = 0
function Invoke-DC { $script:Calls++; $script:LastDCExit=17 }
$ok2 = Invoke-BuildStack 6>&1 | Select-Object -Last 1
if ($ok2) { throw "已配源仍失败时应返回 false" }
if ($script:Calls -ne 1) { throw "已配源不应重试，calls=$($script:Calls)" }
Remove-Item $d -Recurse -Force
'

T 'Invoke-DC 生产形态不变量：真外部命令下输出零污染 + 码经 LastDCExit（防混流回归）' '
$fake = Join-Path ([IO.Path]::GetTempPath()) ("fkbin-"+[Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $fake | Out-Null
$dk = Join-Path $fake "docker"
Set-Content -Path $dk -Value "#!/bin/sh`necho compose-noise-line`nexit `${FAKE_RC:-5}" -NoNewline
& chmod +x $dk
$oldPath = $env:PATH; $env:PATH = "$fake" + [IO.Path]::PathSeparator + $env:PATH
$script:DeployDir = [IO.Path]::GetTempPath()
try {
  $env:FAKE_RC = "5"
  $cap = Invoke-DC -AllowFail version 2>&1
  if ($null -ne $cap -and @($cap).Count -gt 0) { throw ("输出流被污染：[" + (@($cap) -join "|") + "]") }
  if ($script:LastDCExit -ne 5) { throw "LastDCExit 应=5，实为 $($script:LastDCExit)" }
  $env:FAKE_RC = "0"
  Invoke-DC -AllowFail up -d
  if ($script:LastDCExit -ne 0) { throw "成功码未归零" }
  $threw = $false
  $env:FAKE_RC = "7"
  try { Invoke-DC up -d } catch { $threw = ($_.Exception.Message -match "退出码 7") }
  if (-not $threw) { throw "非 AllowFail 失败应 throw 且含真码" }
} finally { $env:PATH = $oldPath; Remove-Item $fake -Recurse -Force }
'

T 'Find-ExistingInstall -Probe 三态：无部署→false 且不退出；缺 .env→false；齐备→true' '
$pre = Join-Path $env:PROJ "backend_async/deploy/.env"
if (Test-Path $pre) { Write-Host "SKIP：PROJ 指向真实部署（已有 .env），不触碰生产配置"; exit 0 }
$script:PointerFile = Join-Path ([IO.Path]::GetTempPath()) ("np-"+[Guid]::NewGuid().ToString("N"))
$env:MAXX_DIR = $null
Push-Location ([IO.Path]::GetTempPath())
try {
  $r1 = [bool](Find-ExistingInstall -Probe)
  if ($r1) { throw "无部署应为 false" }
  $env:MAXX_DIR = $env:PROJ
  $envPath = Join-Path $env:PROJ "backend_async/deploy/.env"
  if (Test-Path $envPath) { Remove-Item $envPath -Force }
  $r2 = [bool](Find-ExistingInstall -Probe)
  if ($r2) { throw "缺 .env 应为 false" }
  Set-Content -Path $envPath -Value "WEB_PORT=5173"
  $r3 = [bool](Find-ExistingInstall -Probe)
  Remove-Item $envPath -Force
  if (-not $r3) { throw "齐备应为 true" }
  if ($script:InstallDir -ne $env:PROJ) { throw "true 时应完成路径装配" }
} finally { Pop-Location; $env:MAXX_DIR = $null }
'

T 'F10 封条：daemon.json 序列化必须走 -InputObject 且单元素镜像保持数组形态' '
$src = Get-Content -LiteralPath $env:S -Raw
$dollar = [char]36
if (-not $src.Contains("ConvertTo-Json -InputObject " + $dollar + "obj -Depth 10")) { throw "静态锚缺失：-InputObject 写法被改动" }
if ($src.Contains($dollar + "obj | ConvertTo-Json")) { throw "回归：出现管道式 ConvertTo-Json（PS5.1 单元素降级面）" }
$o = [pscustomobject]@{ "registry-mirrors" = @("https://only-one.example") }
$j = ConvertTo-Json -InputObject $o -Depth 10
if ($j -notmatch "\[") { throw "单元素镜像未保持 JSON 数组形态：$j" }
if ($j -notmatch "only-one\.example") { throw "序列化内容异常：$j" }
'

T 'Get-AdminCfg：入口 path = .env > config.yaml > 默认；账号 username 只认 .env（不碰 config.yaml）（5.3.0）' '
$d = Join-Path ([IO.Path]::GetTempPath()) ("adm-"+[Guid]::NewGuid().ToString("N"))
$null = New-Item -ItemType Directory -Path (Join-Path $d "backend_async") -Force
$script:InstallDir = $d; $script:EnvFile = Join-Path $d ".env"
$yml = Join-Path (Join-Path $d "backend_async") "config.yaml"
function Eq($got, $want, $why) { if ($got -cne $want) { throw ("{0}: 期望 [{1}] 实得 [{2}]" -f $why, $want, $got) } }
Write-EnvLF $script:EnvFile @("X=1")
Set-Content -LiteralPath $yml -Encoding UTF8 -Value @("x: 1", "admin:   # c", "  path: `"my_entry`"   # c", "  username: 13800138000", "userauth:", "  path: nope")
Eq (Get-AdminCfg "path") "my_entry" "yaml 引号+行尾注释"; Eq (Get-AdminCfg "username") "" "yaml 的 username 被忽略（账号只认 .env）"
Write-EnvLF $script:EnvFile @("STA_ADMIN_PATH=ops-9", "STA_ADMIN_USERNAME=boss")
Eq (Get-AdminCfg "path") "ops-9" ".env 入口优先于 yaml"; Eq (Get-AdminCfg "username") "boss" ".env 账号生效"
Write-EnvLF $script:EnvFile @("STA_ADMIN_PATH=a/b", "STA_ADMIN_USERNAME=OFF")
Eq (Get-AdminCfg "path") "admin-xdd" "非法入口回落默认"; Eq (Get-AdminCfg "username") "" "账号 OFF = 不要账号"
Write-EnvLF $script:EnvFile @("STA_ADMIN_PATH=Assets"); Eq (Get-AdminCfg "path") "admin-xdd" "保留词"
Write-EnvLF $script:EnvFile @("X=1")
Set-Content -LiteralPath $yml -Encoding UTF8 -Value @("admin:", "  login_captcha: auto", "other:", "  path: zzz", "  username: zzz")
Eq (Get-AdminCfg "path") "admin-xdd" "admin 段没写 path 时不串段"; Eq (Get-AdminCfg "username") "" "无 .env 账号即为空"
Remove-Item $yml; Eq (Get-AdminCfg "path") "admin-xdd" "没有 config.yaml"
Copy-Item (Join-Path (Join-Path $env:PROJ "backend_async") "config.yaml") $yml
Write-EnvLF $script:EnvFile @("X=1")
if ((Get-AdminCfg "path") -cnotmatch "^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$") { throw "发货 config.yaml 解析不出入口" }
if (Select-String -LiteralPath $yml -Pattern "^\s*username:" -Quiet) { throw "发货 config.yaml 不应含 admin.username 键" }
if ((Get-AdminCfg "username") -cne "") { throw "发货配置无 .env 账号时应为空" }
Remove-Item $d -Recurse -Force
'

T 'Cmd-AdminLink：容器内签发一次性应急登录链接（exec 优先、run 兜底、失败明说）（5.3.0）' '
$script:CfgWebPort = 5199; $script:Calls = @(); $script:Mode = "exec"; $CommandArgs = @()
function Get-NetIPAddress { throw "no such cmdlet here" }
function Get-DCOutput { $a = @($args); $script:Calls += ,($a -join " ")
  if ($script:Mode -eq "exec" -and $a[0] -eq "exec") { return @("http://127.0.0.1:5199/admin-xdd#t=TICKET.sig") }
  if ($script:Mode -eq "run" -and $a[0] -eq "run") { return @("noise", "http://127.0.0.1:5199/admin-xdd#t=TICKET2.sig ") }
  return $null }
$out = (Cmd-AdminLink *>&1 | Out-String)
if ($out -notmatch "admin-xdd#t=TICKET\.sig") { throw "exec 路径未打印链接: $out" }
if ($script:Calls.Count -ne 1) { throw "exec 成功后不应再 run" }
if ($script:Calls[0] -cne "exec -T web python -m app.admin_auth link --minutes 10 --base http://127.0.0.1:5199") { throw ("exec 参数不符: " + $script:Calls[0]) }
$script:Mode = "run"; $script:Calls = @(); $CommandArgs = @("5")
$out = (Cmd-AdminLink *>&1 | Out-String)
if ($out -notmatch "admin-xdd#t=TICKET2\.sig") { throw "run 兜底未生效: $out" }
if ($script:Calls[1] -cne "run --rm --no-deps -T --entrypoint python web -m app.admin_auth link --minutes 5 --base http://127.0.0.1:5199") { throw ("run 参数不符: " + $script:Calls[1]) }
$script:Mode = "none"; $threw = $false
function Die([string]$m) { throw $m }    # 默认的 Die 会直接退出进程；测试内改抛以便断言
try { Cmd-AdminLink *>&1 | Out-Null } catch { $threw = ($_.Exception.Message -match "签发失败") }
if (-not $threw) { throw "两条路都拿不到链接时应明说签发失败" }
$CommandArgs = @("nonsense"); $threw = $false
try { Cmd-AdminLink *>&1 | Out-Null } catch { $threw = ($_.Exception.Message -match "参数无法识别") }
if (-not $threw) { throw "无法识别的参数应报错" }
$script:Mode = "exec"; $script:Calls = @(); $CommandArgs = @("https://adm.example.com/", "3")
Cmd-AdminLink *>&1 | Out-Null
if ($script:Calls[0] -cne "exec -T web python -m app.admin_auth link --minutes 3 --base https://adm.example.com") { throw ("基址 / 分钟未生效：" + $script:Calls[0]) }
'

T 'Ensure-AdminUsername / Set-EnvAdminHash：升级补齐账号（包内候选 / -AdminUser 优先 / 键在不动 / -Yes 无候选不写 / 交互重输）+ 散列原位（5.3.0）' '
$q = [char]39
$d = Join-Path ([IO.Path]::GetTempPath()) ("au-"+[Guid]::NewGuid().ToString("N")); $null = New-Item -ItemType Directory -Path $d
$script:EnvFile = Join-Path $d ".env"; $pkg = Join-Path $d "pkg.env"
function Above { $prev = $null; foreach ($l in (Get-Content -LiteralPath $script:EnvFile)) { if ($l -match "^STA_ADMIN_PASSWORD(_HASH)?=") { return $prev }; $prev = $l }; return $null }
function Die([string]$m) { throw $m }
Write-EnvLF $pkg @("A=1", "STA_ADMIN_USERNAME=13268237005", "STA_ADMIN_PASSWORD=pkgpw")
$script:Yes = $true; $script:AdminUser = ""
Write-EnvLF $script:EnvFile @("A=1"); Ensure-AdminUsername $pkg *>&1 | Out-Null
if ((Get-Content $script:EnvFile) -match "STA_ADMIN_USERNAME") { throw "未启用不应写" }
Write-EnvLF $script:EnvFile @("A=1", "STA_ADMIN_PASSWORD=srvpw", "B=2"); Ensure-AdminUsername $pkg *>&1 | Out-Null
if ((Above) -cne "STA_ADMIN_USERNAME=13268237005") { throw ("应插在口令行上方：" + ((Get-Content $script:EnvFile) -join " | ")) }
if (-not ((Get-Content $script:EnvFile) -contains "STA_ADMIN_PASSWORD=srvpw")) { throw "口令被动了" }
Write-EnvLF $script:EnvFile @("STA_ADMIN_USERNAME=", "STA_ADMIN_PASSWORD_HASH=x"); Ensure-AdminUsername $pkg *>&1 | Out-Null
if (@((Get-Content $script:EnvFile) -match "STA_ADMIN_USERNAME").Count -ne 1) { throw "键在应不动" }
Write-EnvLF $script:EnvFile @(("STA_ADMIN_PASSWORD_HASH=" + $q + "h" + $q)); $script:AdminUser = "boss.ops"; Ensure-AdminUsername $pkg *>&1 | Out-Null
if ((Above) -cne "STA_ADMIN_USERNAME=boss.ops") { throw "-AdminUser 应优先" }
Write-EnvLF $script:EnvFile @("STA_ADMIN_PASSWORD=x"); $script:AdminUser = ""; $o = (Ensure-AdminUsername *>&1 | Out-String)
if ((Get-Content $script:EnvFile) -match "STA_ADMIN_USERNAME") { throw "-Yes 无候选不应写" }
if ($o -notmatch "只验口令") { throw "缺提示：$o" }
$script:AdminUser = "bad acct!"; $threw = $false; try { Ensure-AdminUsername *>&1 | Out-Null } catch { $threw = $true }
if (-not $threw) { throw "非法账号应失败" }
if ((Get-Content $script:EnvFile) -match "STA_ADMIN_USERNAME") { throw "非法账号不应落盘" }
$script:AdminUser = ""; $script:Yes = $false
$queue = [System.Collections.Queue]::new(); @("bad acct!", "13800138000") | ForEach-Object { $queue.Enqueue($_) }; $script:TestAnswers = $queue
$o = (Ensure-AdminUsername *>&1 | Out-String)
if ((Above) -cne "STA_ADMIN_USERNAME=13800138000" -or $o -notmatch "账号只允许") { throw "交互重输失败：$o" }
Write-EnvLF $script:EnvFile @("A=1", "STA_ADMIN_USERNAME=u1", ("STA_ADMIN_PASSWORD=" + $q + "pw" + $q), "B=2", ("STA_ADMIN_PASSWORD_HASH=" + $q + "old" + $q))
$h = "pbkdf2_sha256`$200000`$s/a+lt`$d=k"
Set-EnvAdminHash $h
$got = (Get-Content -LiteralPath $script:EnvFile) -join "|"
$want = "A=1|STA_ADMIN_USERNAME=u1|STA_ADMIN_PASSWORD_HASH=" + $q + $h + $q + "|B=2"
if ($got -cne $want) { throw ("散列原位替换不符：" + $got) }
if ((Get-EnvValue "STA_ADMIN_PASSWORD_HASH") -cne $h) { throw "Get-EnvValue 回读不符" }
Remove-Item $d -Recurse -Force
'

# ═══════ 新用例请追加在本行【之上】：以下为汇总哨兵，必须保持文件末尾 ═══════
Write-Host ''
Write-Host ("==== 结果：PASS={0} FAIL={1} ====" -f $PASS, $FAIL)
if ($FAIL -gt 0) { exit 1 }
