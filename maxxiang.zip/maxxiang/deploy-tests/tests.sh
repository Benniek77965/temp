#!/usr/bin/env bash
# 函数级测试：每个用例在独立 bash 进程里 source 脚本后断言，互不污染。
set -u
# 路径均可用环境变量覆盖；默认假定与本脚本同目录 / 常规解压位置
S="${S:-$(cd "$(dirname "$0")" && pwd)/deploy-maxxiang.sh}"
PROJ="${PROJ:-/home/claude/maxxiang_extract/maxxiang}"
ZIP="${ZIP:-/home/claude/maxxiang.zip}"
export S PROJ ZIP   # 用例子进程需读取
PASS=0; FAIL=0
t() { # t "名称" <<'CASE' ... CASE
  local name="$1" body; body="$(cat)"
  if out=$(bash -c "set +e; source '$S' >/dev/null 2>&1; trap - ERR INT; set +e +o pipefail; $body" 2>&1); then
    echo "PASS  $name"; PASS=$((PASS+1))
  else
    echo "FAIL  $name"; echo "$out" | sed 's/^/      /'; FAIL=$((FAIL+1))
  fi
}

# 1 帮助头渲染
if bash "$S" --help | grep -q '九法观测台' && bash "$S" --help | grep -q -- '--yes' \
   && ! bash "$S" --help | grep -q 'set -Eeuo'; then echo "PASS  help 头部渲染"; PASS=$((PASS+1)); else echo "FAIL  help"; FAIL=$((FAIL+1)); fi
# 2 版本
bash "$S" --version | grep -q "v1.1.0" && { echo "PASS  --version"; PASS=$((PASS+1)); } || { echo "FAIL  --version"; FAIL=$((FAIL+1)); }
# 3 未知选项报错
if ! bash "$S" --nope 2>&1 | grep -q '未知选项'; then echo "FAIL  未知选项"; FAIL=$((FAIL+1)); else echo "PASS  未知选项报错"; PASS=$((PASS+1)); fi
# 4 无 docker 时 status 明确失败
out=$(bash "$S" status 2>&1); rc=$?
if [ $rc -ne 0 ] && echo "$out" | grep -q 'Docker'; then echo "PASS  status 无 docker 提示"; PASS=$((PASS+1)); else echo "FAIL  status 无 docker（rc=$rc）: $out"; FAIL=$((FAIL+1)); fi

# 1.1.0 备份轮转
if bash "$S" --keep 4 --version | grep -q "v1.1.0"; then echo "PASS  --keep 选项被接受"; PASS=$((PASS+1)); else echo "FAIL  --keep 选项"; FAIL=$((FAIL+1)); fi

t "prune_backups：完整备份只留最近 N 份；不完整备份与外来条目不碰" <<'CASE'
d=$(mktemp -d)
for ts in 20260101-000000 20260102-000000 20260103-000000 20260104-000000; do mkdir -p "$d/$ts"; : > "$d/$ts/db.dump"; : > "$d/$ts/meta.txt"; done
mkdir -p "$d/20260105-000000"; : > "$d/20260105-000000/db.dump"
mkdir -p "$d/my-keep"; : > "$d/notes.txt"; : > "$d/pre-update-20260101-000000-code.tgz"
out=$(prune_backups "$d" 2 full 2>&1)
[ -d "$d/20260104-000000" ] && [ -d "$d/20260103-000000" ] || exit 1
[ ! -e "$d/20260102-000000" ] && [ ! -e "$d/20260101-000000" ] || exit 1
[ -d "$d/20260105-000000" ] && [ -d "$d/my-keep" ] && [ -f "$d/notes.txt" ] && [ -f "$d/pre-update-20260101-000000-code.tgz" ] || exit 1
echo "$out" | grep -q "不完整" || exit 1
rm -rf "$d"; exit 0
CASE

t "prune_backups：代码快照轮转；0=不清理；非法值不删；前导零按十进制" <<'CASE'
d=$(mktemp -d)
for ts in 20260101-000000 20260102-000000 20260103-000000; do : > "$d/pre-update-$ts-code.tgz"; done
: > "$d/pre-update-20260104-000000-code.zip"; : > "$d/pre-update-junk-code.tgz"
prune_backups "$d" 0 code >/dev/null 2>&1; [ "$(ls "$d" | wc -l)" -eq 5 ] || exit 1
out=$(prune_backups "$d" abc code 2>&1); [ "$(ls "$d" | wc -l)" -eq 5 ] && echo "$out" | grep -q "无效" || exit 1
prune_backups "$d" -1 code >/dev/null 2>&1; [ "$(ls "$d" | wc -l)" -eq 5 ] || exit 1
prune_backups "$d" 02 code >/dev/null 2>&1
[ -f "$d/pre-update-20260104-000000-code.zip" ] && [ -f "$d/pre-update-20260103-000000-code.tgz" ] || exit 1
[ ! -e "$d/pre-update-20260102-000000-code.tgz" ] && [ ! -e "$d/pre-update-20260101-000000-code.tgz" ] || exit 1
[ -f "$d/pre-update-junk-code.tgz" ] || exit 1
rm -rf "$d"; exit 0
CASE

t "backup_keep：默认 7；--keep 与 MAXX_BACKUP_KEEP 覆盖" <<'CASE'
[ "$(backup_keep)" = 7 ] || exit 1
OPT_KEEP=3; [ "$(backup_keep)" = 3 ] || exit 1
v=$(MAXX_BACKUP_KEEP=5 bash -c "source \"$S\" >/dev/null 2>&1; backup_keep"); [ "$v" = 5 ] || exit 1
exit 0
CASE

t "cmd_backup 端到端(桩掉 docker):连跑 3 次、--keep 2 → 只剩最新两份完整备份" <<'CASE'
root=$(mktemp -d); INSTALL_DIR="$root"; DEPLOY_DIR="$root/backend_async/deploy"; mkdir -p "$DEPLOY_DIR" "$root/kg"
ENV_FILE="$DEPLOY_DIR/.env"; STATE_FILE="$DEPLOY_DIR/.deploy-state"; LOG_FILE=/dev/null
printf 'POSTGRES_USER=star\nPOSTGRES_DB=spelltamer\n' > "$ENV_FILE"; : > "$root/kg/cookie.json"
dc() { case "$1" in ps) echo cid123;; exec) echo "PGDMP-fake";; run) echo "acct-fake";; *) return 0;; esac; }
docker() { echo true; }
resolve_kgdir() { echo "$root/kg"; }
COMPOSE=(true); OPT_KEEP=2
for i in 1 2 3; do cmd_backup > "$root/out$i.txt" 2>&1 || { cat "$root/out$i.txt"; exit 1; }; sleep 1.1; done
n=$(find "$root/backups" -mindepth 1 -maxdepth 1 -type d | wc -l); [ "$n" -eq 2 ] || { echo "剩 $n 份"; ls -la "$root/backups"; exit 1; }
for d in "$root"/backups/*/; do [ -f "$d/meta.txt" ] && [ -s "$d/db.dump" ] || exit 1; done
grep -q "轮转：已删除旧备份" "$root/out3.txt" && grep -q "备份目录当前占用" "$root/out3.txt" || { cat "$root/out3.txt"; exit 1; }
newest=$(ls -1 "$root/backups" | sort | tail -1); grep -q "$newest" "$root/out3.txt" || exit 1
rm -rf "$root"; exit 0
CASE

t "verify_markers 正/反" <<CASE
verify_markers '$PROJ' || exit 1
verify_markers /tmp && exit 1
exit 0
CASE

t "extract_zip 真实压缩包（含单层嵌套目录处理）" <<CASE
d=\$(mktemp -d)
extract_zip '$ZIP' "\$d" || exit 1
verify_markers "\$d" || exit 1
[ -f "\$d/backend_async/deploy/docker-compose.yml" ] || exit 1
rm -rf "\$d"
CASE

t "env_get 与 Docker Compose 同口径:行内注释 / 引号 / 首尾空白(5.2.0)" <<'CASE'
d=$(mktemp -d); ENV_FILE="$d/.env"
printf '%s\n' 'WEB_PORT=5199   # 端口' "A='x # not comment'" 'B="y" # comment' 'C=z#notcomment' 'D=  spaced  ' >"$ENV_FILE"
[ "$(env_get WEB_PORT)" = 5199 ] || exit 1
[ "$(env_get A)" = 'x # not comment' ] || exit 1
[ "$(env_get B)" = y ] || exit 1
[ "$(env_get C)" = 'z#notcomment' ] || exit 1
[ "$(env_get D)" = spaced ] || exit 1
rm -rf "$d"
CASE
t "样例搬家:env_example_file 新位置优先、旧位置兜底;prune_stale_example 只删有新位置时的旧残留(5.2.0)" <<'CASE'
d=$(mktemp -d); INSTALL_DIR="$d"; mkdir -p "$d/backend_async/deploy"
echo old >"$d/backend_async/.env.example"
[ "$(env_example_file)" = "$d/backend_async/.env.example" ] || exit 1
prune_stale_example >/dev/null 2>&1
[ -f "$d/backend_async/.env.example" ] || exit 1
echo new >"$d/backend_async/deploy/.env.example"
[ "$(env_example_file)" = "$d/backend_async/deploy/.env.example" ] || exit 1
prune_stale_example >/dev/null 2>&1
[ ! -f "$d/backend_async/.env.example" ] || exit 1
[ -f "$d/backend_async/deploy/.env.example" ] || exit 1
rm -rf "$d"
CASE
t ".env 生成 + env_get 回读 + \$ 散列保真 + 600 权限" <<'CASE'
d=$(mktemp -d); DEPLOY_DIR="$d"; ENV_FILE="$d/.env"
V_PORT=5199; V_PGUSER=star; V_PGPW=Abc123def456; V_PGDB=spelltamer
V_TICKET=0000000000000000000000000000000000000000000000000000000000000000
V_UID=1000000000; V_ADMIN_MODE=on; V_ADMIN_PW='p@ss word"x'
V_ADMIN_ALLOW=""; V_RETENTION=7; V_DISCOVERY=on; V_KGDIR=./kgdata; V_LOGLEVEL=INFO
write_env_file >/dev/null 2>&1 || exit 1
[ "$(stat -c %a "$ENV_FILE")" = 600 ] || exit 1
[ "$(env_get WEB_PORT)" = 5199 ] || exit 1
[ "$(env_get POSTGRES_PASSWORD)" = Abc123def456 ] || exit 1
[ "$(env_get STA_ADMIN_PASSWORD)" = 'p@ss word"x' ] || exit 1
[ "$(env_get STA_DISCOVERY_ENABLED)" = true ] || exit 1
[ "$(env_get COMPOSE_PROJECT_NAME)" = maxxiang ] || exit 1
printf "STA_ADMIN_PASSWORD_HASH='pbkdf2_sha256\$200000\$ab\$cd'\n" >>"$ENV_FILE"
[ "$(env_get STA_ADMIN_PASSWORD_HASH)" = 'pbkdf2_sha256$200000$ab$cd' ] || exit 1
grep -q '\${' "$ENV_FILE" && exit 1
rm -rf "$d"
CASE

t "gen_pw 长度与字符集" <<'CASE'
p=$(gen_pw 24)
[ ${#p} -eq 24 ] || exit 1
[[ "$p" =~ ^[A-Za-z0-9]+$ ]] || exit 1
CASE

t "port_in_use 探测（监听/空闲）" <<'CASE'
python3 -m http.server 45123 --bind 127.0.0.1 >/dev/null 2>&1 &
pid=$!; sleep 0.6
port_in_use 45123 || { kill $pid; exit 1; }
port_in_use 45177 && { kill $pid; exit 1; }
kill $pid 2>/dev/null
exit 0
CASE

t "compose_ver_major：v2 / v1 / 异常" <<'CASE'
fake=$(mktemp); chmod +x "$fake"
printf '#!/bin/sh\necho v2.32.4\n' >"$fake"; COMPOSE=("$fake")
[ "$(compose_ver_major)" = 2 ] || exit 1
printf '#!/bin/sh\necho 1.29.2\n' >"$fake"
[ "$(compose_ver_major)" = 1 ] || exit 1
printf '#!/bin/sh\nexit 1\n' >"$fake"
[ "$(compose_ver_major)" = 0 ] || exit 1
CASE

t "locate：无 .env → die 指引 install；建 .env 后成功定位" <<CASE
# 守卫：若 PROJ 指向真实部署（已有 .env），跳过本用例（视同通过），绝不触碰生产配置
[ -f '$PROJ'/backend_async/deploy/.env ] && exit 0
POINTER_FILE=\$(mktemp)
trap "rm -f '$PROJ'/backend_async/deploy/.env" EXIT   # 守卫已保证 .env 必为本用例自建 → 失败路径清理无破坏面
printf 'INSTALL_DIR=%s\n' '$PROJ' >"\$POINTER_FILE"
out=\$( (locate_existing_install) 2>&1 ); rc=\$?
[ \$rc -ne 0 ] || { echo "无 .env 应当 die"; exit 1; }
echo "\$out" | grep -q "install" || { echo "\$out"; exit 1; }
echo "WEB_PORT=5173" >'$PROJ'/backend_async/deploy/.env
locate_existing_install >/dev/null 2>&1; rc=\$?
rm -f '$PROJ'/backend_async/deploy/.env
[ \$rc -eq 0 ] || exit 1
[ "\$INSTALL_DIR" = '$PROJ' ] || exit 1
[ "\$DEPLOY_DIR" = '$PROJ/backend_async/deploy' ] || exit 1
CASE

t "cmd_logs 参数组装（普通/跟随）" <<'CASE'
dc() { echo "DC $*"; }
o=$(cmd_logs web)
[ "$o" = "DC logs --tail 120 web" ] || { echo "$o"; exit 1; }
o=$(cmd_logs web -f | tail -n1)
[ "$o" = "DC logs -f --tail 120 web" ] || { echo "$o"; exit 1; }
CASE

t "cmd_scale：校验 + 持久化 + 编排调用" <<'CASE'
d=$(mktemp -d); STATE_FILE="$d/st"; WORKER_REPLICAS=1
dc(){ [ "$1 $2" = "ps -q" ] && printf 'cid1\ncid2\ncid3\n'; }
dc_logged(){ echo "DCL $*" >"$d/call"; }
cmd_scale 3 >/dev/null 2>&1 || exit 1
grep -q 'WORKER_REPLICAS=3' "$d/st" || exit 1
grep -q 'up -d --no-build --scale worker=3 worker' "$d/call" || exit 1
( cmd_scale 0 >/dev/null 2>&1 ); [ $? -ne 0 ] || exit 1
rm -rf "$d"
CASE

t "cmd_seed --file：宿主文件挂载翻译" <<'CASE'
f=$(mktemp); echo 2678075 >"$f"
d=$(mktemp -d); INSTALL_DIR=/nonexist
warn_if_sample_ticket(){ :; }
dc_logged(){ echo "$*" >"$d/call"; }
cmd_seed --file "$f" >/dev/null 2>&1 || exit 1
abs=$(readlink -f "$f")
grep -q -- "run --rm -T -v $abs:/tmp/rooms.seed:ro seed --file /tmp/rooms.seed" "$d/call" || { cat "$d/call"; exit 1; }
CASE

t "cmd_admin_hash：容器散列写回 .env（去明文/单引号包裹）" <<'CASE'
d=$(mktemp -d); ENV_FILE="$d/.env"
printf "STA_ADMIN_PASSWORD='old'\nOTHER=1\n" >"$ENV_FILE"; chmod 600 "$ENV_FILE"
dc(){ if [[ "$*" == *admin_auth* ]]; then echo 'pbkdf2_sha256$200000$aa$bb'; fi; }
dc_logged(){ :; }
cmd_admin_hash newpass >/dev/null 2>&1 || exit 1
grep -q '^STA_ADMIN_PASSWORD=' "$ENV_FILE" && exit 1
[ "$(env_get STA_ADMIN_PASSWORD_HASH)" = 'pbkdf2_sha256$200000$aa$bb' ] || exit 1
grep -q "STA_ADMIN_PASSWORD_HASH='pbkdf2" "$ENV_FILE" || exit 1
grep -q '^OTHER=1$' "$ENV_FILE" || exit 1
CASE

t "resolve_kgdir：相对/绝对两种写法" <<'CASE'
d=$(mktemp -d); DEPLOY_DIR="$d"; ENV_FILE="$d/.env"
echo 'KG_DATA_DIR=./kgdata' >"$ENV_FILE"
[ "$(resolve_kgdir)" = "$d/kgdata" ] || exit 1
echo 'KG_DATA_DIR=/srv/kg' >"$ENV_FILE"
[ "$(resolve_kgdir)" = /srv/kg ] || exit 1
CASE

t "健康探针辅助：health_of 缺容器返回 missing" <<'CASE'
docker(){ return 1; }
[ "$(health_of deadbeef)" = missing ] || exit 1
CASE

# （哨兵已移至文件末尾）

# ───────────── 复查轮新增用例 ─────────────
if ! grep -q 'mktemp --suffix' "$S"; then echo "PASS  静态：无 busybox 不兼容的 mktemp --suffix"; PASS=$((PASS+1)); else echo "FAIL  mktemp --suffix 仍存在"; FAIL=$((FAIL+1)); fi
if grep -q -- '--exclude "\$kg_ex"' "$S"; then echo "PASS  静态：update 动态保护自定义 kgdata"; PASS=$((PASS+1)); else echo "FAIL  update 动态排除缺失"; FAIL=$((FAIL+1)); fi

t "extract_zip 坏压缩包 → 明确 die" <<'CASE'
bad=$(mktemp); echo "not a zip" >"$bad"
d=$(mktemp -d)
out=$( (extract_zip "$bad" "$d/out") 2>&1 ); rc=$?
[ $rc -ne 0 ] || exit 1
echo "$out" | grep -q "解压失败" || { echo "$out"; exit 1; }
[ ! -e "$d/out/backend_async" ] || exit 1
CASE

t "wizard 交互金测：票据非法重输 + 白名单非法重输 + admin 口令 + 落盘断言" <<'CASE'
export INSTALL_DIR="$PROJ"
DEPLOY_DIR=$(mktemp -d); ENV_FILE="$DEPLOY_DIR/.env"; COMPOSE=(true); ASSUME_YES=0
TICK=$(printf 'a%.0s' $(seq 1 64))
wlog="$DEPLOY_DIR/wiz.log"
wizard >"$wlog" 2>&1 <<IN

y
BAD\$TICKET!!
$TICK
abc
12345
y
pw123!ok
pw123!ok
bad acct!
13268237005
10.0.0.0/8; rm -rf /


y


INFO
IN
rc=$?
[ $rc -eq 0 ] || { cat "$wlog"; exit 1; }
grep -q "请重输或留空" "$wlog" || { echo "缺票据重输提示"; cat "$wlog"; exit 1; }
grep -q "白名单只允许" "$wlog" || { echo "缺白名单重输提示"; cat "$wlog"; exit 1; }
grep -q "uid 应为纯数字" "$wlog" || { echo "缺 uid 重输提示"; cat "$wlog"; exit 1; }
write_env_file >/dev/null 2>&1 || { echo "write_env_file 失败"; exit 1; }
grep -q "^WEB_PORT=5173$" "$ENV_FILE"                       || { echo A; cat "$ENV_FILE"; exit 1; }
grep -Eq "^POSTGRES_PASSWORD=[A-Za-z0-9]{20}$" "$ENV_FILE"  || { echo B; cat "$ENV_FILE"; exit 1; }
grep -q "^STA_AUTH_TICKET=$TICK$" "$ENV_FILE"               || { echo C; exit 1; }
grep -q "^STA_AUTH_UID=12345$" "$ENV_FILE"                  || { echo D; exit 1; }
grep -q "^STA_ADMIN_PASSWORD='pw123!ok'$" "$ENV_FILE"       || { echo E; exit 1; }
grep -q "账号只允许" "$wlog"                                 || { echo "E2 缺账号重输提示"; cat "$wlog"; exit 1; }
awk '/^STA_ADMIN_PASSWORD=/{ if (prev != "STA_ADMIN_USERNAME=13268237005") exit 1; found = 1 } { prev = $0 } END { exit !found }' "$ENV_FILE" \
                                                           || { echo "E3 账号行应紧挨在口令行上方"; cat "$ENV_FILE"; exit 1; }
grep -q "^STA_ADMIN_IP_ALLOW=" "$ENV_FILE"                  && { echo F; exit 1; }
grep -q "^STA_DISCOVERY_ENABLED=true$" "$ENV_FILE"          || { echo G; exit 1; }
grep -q "^STA_LOG_LEVEL=INFO$" "$ENV_FILE"                  || { echo H; exit 1; }
grep -q "^STA_RETENTION_DAYS=7$" "$ENV_FILE"                || { echo I; cat "$ENV_FILE"; exit 1; }
grep -q "^# PIP_INDEX_URL=https://pypi.tuna" "$ENV_FILE"    || { echo K1; exit 1; }
grep -q "^PIP_INDEX_URL=" "$ENV_FILE"                       && { echo K2; exit 1; }
[ "$WORKER_REPLICAS" = 3 ]                                  || { echo "J WORKER=$WORKER_REPLICAS"; exit 1; }  # 3.6.0 起默认 3(脚本顶部单源 + --help「默认 3」);旧期望 10 是 3.4.2 的口径,5.2.0 复查时修正
rm -rf "$DEPLOY_DIR"
CASE

t "wizard 非交互：--ticket 非法 → die" <<'CASE'
export INSTALL_DIR="$PROJ"
DEPLOY_DIR=$(mktemp -d); ENV_FILE="$DEPLOY_DIR/.env"; COMPOSE=(true)
ASSUME_YES=1; OPT_TICKET='xx$bad'; OPT_UID=1
out=$( (wizard) 2>&1 ); rc=$?
[ $rc -ne 0 ] || { echo "$out"; exit 1; }
echo "$out" | grep -q -- "--ticket" || { echo "$out"; exit 1; }
CASE

t "harden：reuse 遗留明文自取转散列 + 双键清理" <<'CASE'
DEPLOY_DIR=$(mktemp -d); ENV_FILE="$DEPLOY_DIR/.env"; V_ADMIN_PW=""
printf "STA_ADMIN_PASSWORD='leftpw'\nSTA_ADMIN_PASSWORD_HASH='pbkdf2_sha256\$1\$old\$old'\nOTHER=1\n" >"$ENV_FILE"
seen="$DEPLOY_DIR/seen"
dc(){ if [[ "$*" == *admin_auth* ]]; then
        local a; for a in "$@"; do :; done; printf '%s' "$a" >"$seen"
        echo 'pbkdf2_sha256$2$new$new'
      else return 0; fi; }
harden_admin_password >/dev/null 2>&1 || exit 1
[ "$(cat "$seen")" = leftpw ] || { cat "$seen"; exit 1; }
grep -q "^STA_ADMIN_PASSWORD=" "$ENV_FILE" && exit 1
[ "$(grep -c '^STA_ADMIN_PASSWORD_HASH=' "$ENV_FILE")" -eq 1 ] || exit 1
[ "$(env_get STA_ADMIN_PASSWORD_HASH)" = 'pbkdf2_sha256$2$new$new' ] || exit 1
grep -q '^OTHER=1$' "$ENV_FILE" || exit 1
rm -rf "$DEPLOY_DIR"
CASE

t "reuse 判定：空值行 → off；有散列 → on" <<'CASE'
DEPLOY_DIR=$(mktemp -d); ENV_FILE="$DEPLOY_DIR/.env"
echo "STA_ADMIN_PASSWORD=" >"$ENV_FILE"
if [ -n "$(env_get STA_ADMIN_PASSWORD 2>/dev/null || true)" ] || [ -n "$(env_get STA_ADMIN_PASSWORD_HASH 2>/dev/null || true)" ]; then exit 1; fi
echo "STA_ADMIN_PASSWORD_HASH='x'" >"$ENV_FILE"
if [ -n "$(env_get STA_ADMIN_PASSWORD 2>/dev/null || true)" ] || [ -n "$(env_get STA_ADMIN_PASSWORD_HASH 2>/dev/null || true)" ]; then :; else exit 1; fi
rm -rf "$DEPLOY_DIR"
CASE

t "env_get 空值语义：视同不存在（return 1）→ 默认回退" <<'CASE'
DEPLOY_DIR=$(mktemp -d); ENV_FILE="$DEPLOY_DIR/.env"
printf 'KG_DATA_DIR=\nWEB_PORT=\n' >"$ENV_FILE"
if env_get KG_DATA_DIR >/dev/null 2>&1; then exit 1; fi
[ "$(env_get WEB_PORT || echo 5173)" = 5173 ] || exit 1
[ "$(resolve_kgdir)" = "$DEPLOY_DIR/kgdata" ] || { resolve_kgdir; exit 1; }
rm -rf "$DEPLOY_DIR"
CASE

t "PIP 源写入路径：V_PIP_MIRROR 有值 → 实键落盘且无注释示例" <<'CASE'
d=$(mktemp -d); DEPLOY_DIR="$d"; ENV_FILE="$d/.env"
V_PORT=5199; V_PGUSER=star; V_PGPW=Abc123; V_PGDB=spelltamer
V_TICKET=PUT_FRESH_TICKET_HERE; V_UID=0; V_ADMIN_MODE=off; V_ADMIN_PW=""; V_ADMIN_ALLOW=""
V_RETENTION=1; V_DISCOVERY=on; V_KGDIR=./kgdata; V_LOGLEVEL=INFO
V_PIP_MIRROR="https://pypi.tuna.tsinghua.edu.cn/simple"
write_env_file >/dev/null 2>&1 || exit 1
grep -q "^PIP_INDEX_URL=https://pypi.tuna.tsinghua.edu.cn/simple$" "$ENV_FILE" || exit 1
grep -q "^# PIP_INDEX_URL=" "$ENV_FILE" && exit 1
rm -rf "$d"
CASE

t "build_stack 自愈：pip 网络错误 → 自动写清华源并重试成功；已配源则不再换" <<'CASE'
d=$(mktemp -d); ENV_FILE="$d/.env"; LOG_FILE="$d/log"; : >"$ENV_FILE"; : >"$LOG_FILE"
ASSUME_YES=1; WORKER_REPLICAS=3; CALLS=0
dc_logged(){ CALLS=$((CALLS+1))
  if [ "$CALLS" -eq 1 ]; then
    echo "ERROR: No matching distribution found for aiohttp==3.14.1 (from versions: none)" >>"$LOG_FILE"
    return 17
  fi
  echo "RETRY-OK $*" >>"$LOG_FILE"; return 0; }
build_stack || exit 1
[ "$CALLS" -eq 2 ] || { echo "calls=$CALLS"; exit 1; }
[ "$(env_get PIP_INDEX_URL)" = "$PYPI_CN_DEFAULT" ] || { cat "$ENV_FILE"; exit 1; }
grep -q "RETRY-OK up -d --build --scale worker=3" "$LOG_FILE" || exit 1
# 已配源仍失败 → 不换源不重试，向上抛真码
CALLS=0
dc_logged(){ CALLS=$((CALLS+1)); echo "from versions: none" >>"$LOG_FILE"; return 17; }
rc=0; build_stack >/dev/null 2>&1 || rc=$?
[ "$rc" -eq 17 ] || { echo "rc=$rc"; exit 1; }
[ "$CALLS" -eq 1 ] || { echo "calls2=$CALLS"; exit 1; }
rm -rf "$d"
CASE

t "取消软返回：restore/update/uninstall 反悔 → rc=0 且提示已取消（不再杀脚本）" <<'CASE'
confirm(){ return 1; }
dc(){ :; }; dc_logged(){ :; }; require_root(){ :; }; ensure_admin(){ :; }
INSTALL_DIR=/tmp/nx; DEPLOY_DIR=/tmp/nx; ENV_FILE=/tmp/nx/.env
out=$(cmd_uninstall 2>&1); rc=$?
[ "$rc" -eq 0 ] && echo "$out" | grep -q "已取消" || { echo "uninstall rc=$rc"; exit 1; }
out=$(cmd_update 2>&1); rc=$?
[ "$rc" -eq 0 ] && echo "$out" | grep -q "已取消" || { echo "update rc=$rc"; exit 1; }
mkdir -p /tmp/nx-bk && echo x >/tmp/nx-bk/db.dump
CMD_ARGS=(/tmp/nx-bk)
out=$(cmd_restore /tmp/nx-bk 2>&1); rc=$?
rm -rf /tmp/nx-bk
[ "$rc" -eq 0 ] && echo "$out" | grep -q "已取消" || { echo "restore rc=$rc: $out"; exit 1; }
CASE

t "build_stack 甄别钉错版本：非空 from versions 列表 → 点名坏钉版、不换源不重试" <<'CASE'
d=$(mktemp -d); ENV_FILE="$d/.env"; LOG_FILE="$d/log"; : >"$ENV_FILE"; : >"$LOG_FILE"
ASSUME_YES=1; WORKER_REPLICAS=2; CALLS=0
dc_logged(){ CALLS=$((CALLS+1))
  printf '%s\n' \
    'ERROR: Ignored the following yanked versions: 1.0.0' \
    'ERROR: Could not find a version that satisfies the requirement PyMySQL==1.4.6 (from versions: 0.3, 0.4, 1.1.3, 1.2.0)' \
    'ERROR: No matching distribution found for PyMySQL==1.4.6' >>"$LOG_FILE"
  return 17; }
rc=0; build_stack >"$d/out" 2>&1 || rc=$?   # 重定向而非 $()：避免子壳吞掉 CALLS 计数
out=$(cat "$d/out")
[ "$rc" -eq 17 ] || { echo "rc=$rc"; exit 1; }                       # 真退出码向上抛
[ "$CALLS" -eq 1 ] || { echo "calls=$CALLS"; exit 1; }               # 不自动重试
env_get PIP_INDEX_URL >/dev/null 2>&1 && { echo "不应写换源键"; exit 1; }
echo "$out" | grep -q 'PyMySQL==1.4.6' || { echo "未点名坏钉版: $out"; exit 1; }
echo "$out" | grep -q '钉' || exit 1                                 # 诊断口径为钉版而非网络
rm -rf "$d"
CASE

t "admin_cfg：入口 path = .env > config.yaml > 默认；账号 username 只认 .env（不碰 config.yaml）（5.3.0）" <<'CASE'
d=$(mktemp -d); INSTALL_DIR="$d"; ENV_FILE="$d/.env"; CFG_WEB_PORT=5173; mkdir -p "$d/backend_async"
yml="$d/backend_async/config.yaml"
eq() { [ "$1" = "$2" ] || { echo "期望 '$2' 实得 '$1'（$3）"; exit 1; }; }
# config.yaml 里即便残留 username，账号也不认它（账号是凭据，只走 .env）
: >"$ENV_FILE"
printf "x: 1\nadmin:   # 注释\n  path: 'my_entry'   # 行尾注释\n  username: 13800138000\nuserauth:\n  path: nope\n" >"$yml"
eq "$(admin_cfg path)" my_entry "yaml 引号+行尾注释"; eq "$(admin_cfg username)" "" "yaml 的 username 被忽略（账号只认 .env）"
eq "$(admin_url_hint)" "http://<host>:5173/my_entry" "摘要行（无账号）"
printf 'STA_ADMIN_PATH=ops-9   # 注释\nSTA_ADMIN_USERNAME=boss\n' >"$ENV_FILE"
eq "$(admin_cfg path)" ops-9 ".env 入口优先于 yaml"; eq "$(admin_cfg username)" boss ".env 账号生效"
eq "$(admin_url_hint)" "http://<host>:5173/ops-9（账号 boss）" "摘要行（有账号）"
printf 'STA_ADMIN_PATH=a/b\nSTA_ADMIN_USERNAME=OFF\n' >"$ENV_FILE"
eq "$(admin_cfg path)" admin-xdd "非法入口回落默认（与后端一致）"; eq "$(admin_cfg username)" "" "账号 OFF = 不要账号"
printf 'STA_ADMIN_PATH=Assets\n' >"$ENV_FILE"; eq "$(admin_cfg path)" admin-xdd "与静态挂载同名的保留词"
: >"$ENV_FILE"; printf "admin:\n  login_captcha: auto\nother:\n  path: zzz\n  username: zzz\n" >"$yml"
eq "$(admin_cfg path)" admin-xdd "admin 段没写 path 时不串到别的段"; eq "$(admin_cfg username)" "" "无 .env 账号即为空"
rm -f "$yml"; eq "$(admin_cfg path)" admin-xdd "没有 config.yaml"; eq "$(admin_url_hint)" "http://<host>:5173/admin-xdd" "无账号时的摘要行"
# 仓库自带的 config.yaml：入口解析得出且合法，且**不含账号**（账号不随代码分发）
cp "$PROJ/backend_async/config.yaml" "$yml"; : >"$ENV_FILE"
[[ "$(admin_cfg path)" =~ ^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$ ]] || { echo "发货 config.yaml 解析不出入口"; exit 1; }
grep -q "^  path: \"$(admin_cfg path)\"" "$yml" || { echo "解析值与文件内容不一致: $(admin_cfg path)"; exit 1; }
grep -qE '^[[:space:]]*username:' "$yml" && { echo "发货 config.yaml 不应含 admin.username 键"; exit 1; }
eq "$(admin_cfg username)" "" "发货配置无 .env 账号时为空"
rm -rf "$d"
CASE

t "cmd_admin_link：容器内签发一次性应急登录链接（exec 优先、run 兜底、失败明说）（5.3.0）" <<'CASE'
d=$(mktemp -d); INSTALL_DIR="$d"; DEPLOY_DIR="$d"; ENV_FILE="$d/.env"; : >"$ENV_FILE"; CFG_WEB_PORT=5199
primary_ip() { printf 10.1.2.3; }
MODE=exec
dc() { echo "$*" >>"$d/calls"
  case "$MODE:$1" in
    exec:exec) printf 'http://10.1.2.3:5199/admin-xdd#t=TICKET.sig\r\n';;
    run:run)   printf 'http://10.1.2.3:5199/admin-xdd#t=TICKET2.sig\n';;
  esac; return 0; }
out=$(cmd_admin_link 2>&1) || { echo "exec 路径失败: $out"; exit 1; }
echo "$out" | grep -qx 'http://10.1.2.3:5199/admin-xdd#t=TICKET.sig' || { echo "未原样打印链接: $out"; exit 1; }
grep -qx -- 'exec -T web python -m app.admin_auth link --minutes 10 --base http://10.1.2.3:5199' "$d/calls" || { cat "$d/calls"; exit 1; }
[ "$(wc -l <"$d/calls")" -eq 1 ] || { echo "exec 成功后不应再 run"; exit 1; }
MODE=run; : >"$d/calls"
out=$(cmd_admin_link 5 2>&1) || { echo "run 兜底失败: $out"; exit 1; }
echo "$out" | grep -qx 'http://10.1.2.3:5199/admin-xdd#t=TICKET2.sig' || { echo "run 兜底未生效: $out"; exit 1; }
grep -qx -- 'run --rm --no-deps -T --entrypoint python web -m app.admin_auth link --minutes 5 --base http://10.1.2.3:5199' "$d/calls" || { cat "$d/calls"; exit 1; }
MODE=none
out=$( (cmd_admin_link) 2>&1 ) && { echo "两条路都拿不到链接时应失败"; exit 1; }
echo "$out" | grep -q '签发失败' || { echo "失败提示缺失: $out"; exit 1; }
out=$( (cmd_admin_link nonsense) 2>&1 ) && { echo "无法识别的参数应报错"; exit 1; }
echo "$out" | grep -q '参数无法识别' || { echo "缺参数报错: $out"; exit 1; }
MODE=exec; : >"$d/calls"
cmd_admin_link https://adm.example.com/ 3 >/dev/null 2>&1 || { echo "传基址失败"; exit 1; }
grep -qx -- 'exec -T web python -m app.admin_auth link --minutes 3 --base https://adm.example.com' "$d/calls" \
  || { echo "基址 / 分钟(顺序随意)未生效"; cat "$d/calls"; exit 1; }
rm -rf "$d"
CASE

t "ensure_admin_username：升级补齐账号（包内 .env 候选 / --admin-user 优先 / 键在不动 / --yes 无候选不写 / 交互重输 / off）（5.3.0）" <<'CASE'
d=$(mktemp -d); ENV_FILE="$d/.env"; pkg="$d/pkg.env"
above() { awk '/^STA_ADMIN_PASSWORD(_HASH)?=/{ print prev; exit } { prev = $0 }' "$ENV_FILE"; }
printf 'A=1\nSTA_ADMIN_USERNAME=13268237005\nSTA_ADMIN_PASSWORD=pkgpw\n' >"$pkg"
# 后台未启用：不动
printf 'A=1\n' >"$ENV_FILE"; ASSUME_YES=1; OPT_ADMIN_USER=""
ensure_admin_username "$pkg" >/dev/null 2>&1; grep -q STA_ADMIN_USERNAME "$ENV_FILE" && { echo "未启用不应写"; exit 1; }
# 启用 + 无键 + 包内有账号 + --yes → 写在口令行正上方
printf 'A=1\nSTA_ADMIN_PASSWORD=srvpw\nB=2\n' >"$ENV_FILE"
ensure_admin_username "$pkg" >/dev/null 2>&1
[ "$(above)" = "STA_ADMIN_USERNAME=13268237005" ] || { echo "应插在口令行上方"; cat "$ENV_FILE"; exit 1; }
grep -q '^STA_ADMIN_PASSWORD=srvpw$' "$ENV_FILE" || { echo "口令被动了"; exit 1; }
[ "$(stat -c %a "$ENV_FILE")" = 600 ] || { echo "权限应为 600"; exit 1; }
# 键已在（哪怕为空）= 已有明确决定：不再改
printf 'STA_ADMIN_USERNAME=\nSTA_ADMIN_PASSWORD_HASH=x\n' >"$ENV_FILE"; ensure_admin_username "$pkg" >/dev/null 2>&1
[ "$(grep -c STA_ADMIN_USERNAME "$ENV_FILE")" = 1 ] && grep -q '^STA_ADMIN_USERNAME=$' "$ENV_FILE" || { echo "键在应不动"; cat "$ENV_FILE"; exit 1; }
# --admin-user 优先于包内候选；散列模式同样识别为已启用
printf "STA_ADMIN_PASSWORD_HASH='h'\n" >"$ENV_FILE"; OPT_ADMIN_USER="boss.ops"
ensure_admin_username "$pkg" >/dev/null 2>&1; [ "$(above)" = "STA_ADMIN_USERNAME=boss.ops" ] || { echo "--admin-user 应优先"; cat "$ENV_FILE"; exit 1; }
# --yes 且无任何候选：不写键（下次交互再问），给出提示
printf 'STA_ADMIN_PASSWORD=x\n' >"$ENV_FILE"; OPT_ADMIN_USER=""
out=$(ensure_admin_username 2>&1); grep -q STA_ADMIN_USERNAME "$ENV_FILE" && { echo "--yes 无候选不应写"; exit 1; }
echo "$out" | grep -q "只验口令" || { echo "缺提示: $out"; exit 1; }
# --yes + 非法候选：直接失败（不把坏值写进 .env）
OPT_ADMIN_USER="bad acct'x"; ( ensure_admin_username >/dev/null 2>&1 ) && { echo "非法账号应失败"; exit 1; }
grep -q STA_ADMIN_USERNAME "$ENV_FILE" && { echo "非法账号不应落盘"; exit 1; }
# 交互：先输非法值 → 重输；填 off → 记下「不设账号」（空键）
OPT_ADMIN_USER=""; ASSUME_YES=0
printf 'bad acct!\n13800138000\n' | ensure_admin_username >"$d/o" 2>&1
[ "$(above)" = "STA_ADMIN_USERNAME=13800138000" ] && grep -q "账号只允许" "$d/o" || { echo "交互重输失败"; cat "$d/o" "$ENV_FILE"; exit 1; }
printf 'STA_ADMIN_PASSWORD=x\n' >"$ENV_FILE"; printf 'off\n' | ensure_admin_username "$pkg" >/dev/null 2>&1
[ "$(above)" = "STA_ADMIN_USERNAME=" ] || { echo "off 应写空键"; cat "$ENV_FILE"; exit 1; }
rm -rf "$d"
CASE

t "env_set_admin_hash：口令行原位换成散列（账号行仍紧挨其上），多余口令行删除，\$ 保真，600 权限（5.3.0）" <<'CASE'
d=$(mktemp -d); ENV_FILE="$d/.env"
printf "A=1\nSTA_ADMIN_USERNAME=u1\nSTA_ADMIN_PASSWORD='pw'\nB=2\nSTA_ADMIN_PASSWORD_HASH='old'\n" >"$ENV_FILE"; chmod 644 "$ENV_FILE"
env_set_admin_hash 'pbkdf2_sha256$200000$s/a+lt$d=k'
want=$(printf "A=1\nSTA_ADMIN_USERNAME=u1\nSTA_ADMIN_PASSWORD_HASH='pbkdf2_sha256\$200000\$s/a+lt\$d=k'\nB=2")
[ "$(cat "$ENV_FILE")" = "$want" ] || { echo "内容不符："; cat "$ENV_FILE"; exit 1; }
[ "$(stat -c %a "$ENV_FILE")" = 600 ] || exit 1
[ "$(env_get STA_ADMIN_PASSWORD_HASH)" = 'pbkdf2_sha256$200000$s/a+lt$d=k' ] || { echo "env_get 回读不符"; exit 1; }
printf 'A=1\n' >"$ENV_FILE"; env_set_admin_hash 'h2'; [ "$(tail -n1 "$ENV_FILE")" = "STA_ADMIN_PASSWORD_HASH='h2'" ] || exit 1
rm -rf "$d"
CASE

t "cmd_update：rsync 与无 rsync 两条路径都保留 .env / kgdata / 部署状态，并从包内 .env 补齐账号（5.3.0）" <<'CASE'
mk() { mkdir -p "$1/backend_async/deploy/kgdata" "$1/jiufa_data"; : >"$1/backend_async/deploy/docker-compose.yml"
       : >"$1/backend_async/deploy/Dockerfile"; : >"$1/jiufa_data/spell_tamer_monitor.py"; : >"$1/index.html"; }
build_stack() { return 0; }; wait_stack() { return 0; }
for mode in rsync norsync; do
  d=$(mktemp -d); src="$d/src"; INSTALL_DIR="$d/inst"; mk "$src"; mk "$INSTALL_DIR"
  echo new >"$src/newcode.txt"
  printf 'STA_ADMIN_USERNAME=13268237005\nSTA_ADMIN_PASSWORD=pkgpw\n' >"$src/backend_async/deploy/.env"
  echo pkg >"$src/backend_async/deploy/.deploy-state"; echo pkg >"$src/backend_async/deploy/kgdata/accounts.json"
  printf 'X=1\nSTA_ADMIN_PASSWORD=srvpw\n' >"$INSTALL_DIR/backend_async/deploy/.env"
  echo srv >"$INSTALL_DIR/backend_async/deploy/.deploy-state"; echo srv >"$INSTALL_DIR/backend_async/deploy/kgdata/accounts.json"
  DEPLOY_DIR="$INSTALL_DIR/backend_async/deploy"; ENV_FILE="$DEPLOY_DIR/.env"; LOG_FILE="$d/log"
  OPT_SOURCE="$src"; ASSUME_YES=1; OPT_ADMIN_USER=""   # SELF_PATH 只读:脚本本身不在临时安装目录内,自更新分支自然跳过
  if [ "$mode" = norsync ]; then have() { [ "$1" = rsync ] && return 1; command -v "$1" >/dev/null 2>&1; }; fi
  cmd_update >"$d/out" 2>&1 || { echo "[$mode] cmd_update 失败"; cat "$d/out"; exit 1; }
  [ "$(cat "$INSTALL_DIR/newcode.txt")" = new ] || { echo "[$mode] 新代码未同步"; exit 1; }
  grep -q '^STA_ADMIN_PASSWORD=srvpw$' "$ENV_FILE" || { echo "[$mode] 服务器 .env 被覆盖"; cat "$ENV_FILE"; exit 1; }
  grep -q pkgpw "$ENV_FILE" && { echo "[$mode] 包内口令混入"; exit 1; }
  [ "$(cat "$DEPLOY_DIR/.deploy-state")" = srv ] || { echo "[$mode] 部署状态被覆盖"; exit 1; }
  [ "$(cat "$DEPLOY_DIR/kgdata/accounts.json")" = srv ] || { echo "[$mode] 票据账号库被覆盖"; exit 1; }
  awk '/^STA_ADMIN_PASSWORD=/{ exit (prev != "STA_ADMIN_USERNAME=13268237005") } { prev = $0 }' "$ENV_FILE" \
    || { echo "[$mode] 账号未补齐到口令行上方"; cat "$ENV_FILE"; exit 1; }
  rm -rf "$d"
done
CASE

t "primary_ip：取默认路由出口 IP；路由不可用时跳过 docker0 / br-* 网桥取真实网卡（5.3.0）" <<'CASE'
ip() { [ "$2" = route ] && { echo "1.1.1.1 via 10.0.0.1 dev eth0 src 10.0.0.5 uid 0"; return 0; }; return 1; }
[ "$(primary_ip)" = 10.0.0.5 ] || { echo "应取路由 src：$(primary_ip)"; exit 1; }
ip() { [ "$2" = route ] && return 1
       printf '%s\n' "3: docker0    inet 172.17.0.1/16 brd 172.17.255.255 scope global docker0" \
                     "4: br-ab12cd    inet 172.18.0.1/16 brd 172.18.255.255 scope global br-ab12cd" \
                     "2: eth0    inet 192.168.1.20/24 brd 192.168.1.255 scope global eth0"; }
[ "$(primary_ip)" = 192.168.1.20 ] || { echo "应跳过网桥：$(primary_ip)"; exit 1; }
# ★ 在脚本**真实的严格模式**下跑:测试框架默认 set +e +o pipefail 会掩盖「管道失败致整个脚本中止」;
#   且探测不能放在 || / && 链里(bash 在那种上下文里连子 shell 内重新 set -e 也一并忽略)→ 独立 bash 进程
probe="$(declare -f primary_ip have); set -Eeuo pipefail; ip() { return 1; }; hostname() { return 1; }; primary_ip; echo '|rc=0'"
out="$(bash -c "$probe" 2>&1)"; rc=$?
[ "$rc" -eq 0 ] && [ "$out" = "127.0.0.1|rc=0" ] || { echo "严格模式下 primary_ip 让脚本中止了(rc=$rc)：$out"; exit 1; }
CASE

t "严格模式冒烟：5.3.0 新增函数在 set -Eeuo pipefail + ERR 陷阱下走「什么都没找到」分支不中止" <<'CASE'
# 测试框架为便于断言关闭了 -e / pipefail,会掩盖「管道失败致脚本中止」(primary_ip 曾因此漏网);
# 这里在独立进程里按真实方式 source 脚本(其 set -Eeuo pipefail 与 ERR 陷阱保持生效)逐个调用。
d=$(mktemp -d); mkdir -p "$d/backend_async"; printf 'x: 1\n' >"$d/backend_async/config.yaml"
printf 'STA_ADMIN_USERNAME=13268237005\n' >"$d/pkg.env"
out="$(D="$d" bash -c '
  source "$S" >/dev/null 2>&1; LOG_FILE="$D/log"; INSTALL_DIR="$D"; ENV_FILE="$D/.env"; CFG_WEB_PORT=5173; ASSUME_YES=1; OPT_ADMIN_USER=""
  ip() { return 1; }; hostname() { return 1; }
  printf "A=1\n" >"$ENV_FILE"
  # 直接调用 + 重定向(不放进 $(...):命令替换不继承 errexit,会让严格模式形同虚设)
  admin_cfg path >"$D/o1"; admin_cfg username >"$D/o2"; admin_url_hint >"$D/o3"
  [ "$(cat "$D/o1")" = admin-xdd ] && echo OK1
  [ ! -s "$D/o2" ] && echo OK2
  [ "$(cat "$D/o3")" = "http://<host>:5173/admin-xdd" ] && echo OK3
  ensure_admin_username "$D/pkg.env" >/dev/null 2>&1; echo OK4                      # 后台未启用
  printf "STA_ADMIN_USERNAME=\nSTA_ADMIN_PASSWORD=x\n" >"$ENV_FILE"
  ensure_admin_username >/dev/null 2>&1; echo OK5                                    # 键已在
  printf "STA_ADMIN_PASSWORD=x\n" >"$ENV_FILE"
  ensure_admin_username >/dev/null 2>&1; echo OK6                                    # --yes 无候选
  ensure_admin_username "$D/pkg.env" >/dev/null 2>&1; grep -q "^STA_ADMIN_USERNAME=13268237005$" "$ENV_FILE" && echo OK7
  printf "A=1\n" >"$ENV_FILE"; env_set_admin_hash h >/dev/null 2>&1; echo OK8      # 没有口令行:追加
  primary_ip >"$D/o9"; [ "$(cat "$D/o9")" = 127.0.0.1 ] && echo OK9
' 2>&1)"; rc=$?
[ "$rc" -eq 0 ] && [ "$(echo "$out" | grep -c '^OK[0-9]$')" = 9 ] || { echo "严格模式下中止或结果不符(rc=$rc)："; echo "$out" | tail -5; exit 1; }
# 同一模式的原有缺陷:seed --file 指向父目录不存在的文件 → 应给出人话提示,而不是被 ERR 陷阱笼统中止
out="$(D="$d" bash -c 'source "$S" >/dev/null 2>&1; LOG_FILE="$D/log"; warn_if_sample_ticket() { :; }; cmd_seed --file /nonexistent-dir-x/rooms.txt' 2>&1)"
echo "$out" | grep -q "文件不存在：/nonexistent-dir-x/rooms.txt" || { echo "seed --file 缺人话提示：$out"; exit 1; }
rm -rf "$d"
CASE

# ═══════ 新用例请追加在本行【之上】：以下为汇总哨兵，必须保持文件末尾 ═══════
echo; echo "==== 结果：PASS=$PASS FAIL=$FAIL ===="
[ "$FAIL" -eq 0 ]
