# 九法观测台 · Docker 一键部署工具包

面向「九法观测台」（酷狗直播 SpellTamer 出怪监控预测系统）的交互式部署与运维脚本。
针对项目实际编排逐文件核查后编写（`backend_async/deploy/{docker-compose.yml,Dockerfile}`、双 entrypoint、`.env.example`、`app/` 源码），并非通用模板。

## 包内文件

| 文件 | 说明 |
|---|---|
| `deploy-maxxiang.sh` | Linux 部署 + 日常运维主脚本（单文件，无外部依赖） |
| `deploy-maxxiang.ps1` | Windows 部署 + 日常运维主脚本（Docker Desktop/WSL2，PowerShell 5.1+） |
| `deploy-maxxiang.bat` | Windows 双击启动器（自动放行执行策略、pwsh 优先、结束防闪退；参数原样透传给 .ps1；口令含 `&`/`^` 等 cmd 元字符时请整体加引号或改用 PowerShell 直呼） |
| `README.md` | 本文档 |
| `deploy-tests/tests.sh` / `deploy-tests/tests.ps1` | 两平台函数级测试套件（开发/回归用，生产环境可忽略） |

## 快速开始

要求：主流 Linux（Debian/Ubuntu、RHEL 系含 openEuler/Anolis/Alibaba Cloud Linux、openSUSE、Arch、Alpine）、root 或 sudo、可访问外网、Docker ≥20.10（脚本自动安装的版本天然满足；机器上已有更旧引擎时会在构建前明确提示升级——前端混淆构建的持久缓存依赖 BuildKit `RUN --mount`）。内存建议 **≥ 8 GB**（compose 把 PostgreSQL `shared_buffers` 钉为 **2 GB**，是按 ≥8G 机器设计的；脚本在物理内存 <7.7 GB 时会警告 OOM 风险并要求确认才继续。小内存机请先把 compose 里该值调回 1GB/512MB 并调小 worker 副本）。

```bash
# 交互式：自动装 Docker/Compose → 拉取项目 → 配置向导 → 起栈 → 健康等待
sudo bash deploy-maxxiang.sh

# 非交互示例（中国大陆网络预设 + 指定端口/口令/副本数）
sudo bash deploy-maxxiang.sh install -y --cn --port 5173 \
  --ticket <64位hex票据> --uid <数字uid> \
  --admin-password '你的口令' --workers 4
```

再次运行同一脚本会自动定位既有部署并进入管理菜单。

## Windows 快速开始

要求：Windows 10 2004+ / Windows 11（x64 或 ARM64）。脚本会自动引导 WSL2 与 Docker Desktop（winget 优先，官方安装器兜底）；首次安装 Docker Desktop 后通常需要**注销/重启一次**（加入 docker-users 组生效），重启后重新运行本脚本即可无缝续跑（幂等）。

最简单的方式：**双击 `deploy-maxxiang.bat`**（自动绕过执行策略并保持窗口；命令行用法同样支持，如 `deploy-maxxiang.bat status`）。等价的 PowerShell 直呼：

```powershell
# 交互式（安装类操作会自动弹 UAC 提权）
powershell -ExecutionPolicy Bypass -File .\deploy-maxxiang.ps1

# 非交互示例
powershell -ExecutionPolicy Bypass -File .\deploy-maxxiang.ps1 install -Yes `
  -Port 5173 -Ticket <64位hex> -Uid <数字> -AdminPassword '口令' -Workers 3
```

子命令与 Linux 版一一对应（`status / logs / seed / scale / backup / restore / update / doctor / uninstall …`）；安装选项改用 PowerShell 风格（`-Yes -Port -Ticket -AdminOff -RegistryMirror -PipMirror -Workers -Retention -Keep -Discovery -Dir -Source -PgPassword -AdminPassword -CN -NoDocker`）。**两处不对等**：Linux 的 `--gh-proxy`（GitHub 下载代理）在 Windows 版没有对应参数，`--version` 亦无。`MAXX_*` 环境变量除 `MAXX_GH_PROXY` / `MAXX_REGISTRY_MIRROR` 外同样生效（后者请改用 `-RegistryMirror` 传参）。Windows 特有处理已内建：`.env` 强制 UTF-8 无 BOM + LF（`env` 子命令用记事本编辑后会自动按硬约束重写）；数据库备份经容器内落盘 + `docker cp` 传输，规避 PowerShell 管道对二进制流的编码损坏；更新走 robocopy 并正确处理其 0-7 成功退出码；镜像加速写入 `%USERPROFILE%\.docker\daemon.json` 并安全重启 Docker Desktop。`-PipMirror` 与构建失败后的换源引导同样可用（检出 PyPI 网络故障特征才询问写入国内源并重试一次；若是 requirements 钉了不存在的版本，会点名坏钉版并指路改法——此时换源无效，不再误导）。差异一处：日志跟随模式下 Ctrl+C 会连同脚本一起退出（PowerShell 控制台语义），重跑脚本即可回到菜单。

## 安装选项速查

| 选项 | 说明 |
|---|---|
| `-y` / `--yes` | 全部采用默认值（配合下列选项） |
| `--dir <路径>` | 安装目录（默认 `/opt/maxxiang`） |
| `--source <URL\|zip\|目录>` | 项目来源（默认官方 zip；脚本已在项目内运行时自动复用） |
| `--port <P>` | Web 端口（默认 5173，带占用检测） |
| `--ticket <T>` / `--uid <U>` | 酷狗 `x-auth-ticket` / `x-auth-uid`；票据强制 32–128 位十六进制 |
| `--pg-password <P>` | PostgreSQL 密码，仅限字母数字（默认随机 20 位） |
| `--admin-password <P>` / `--admin-off` | 启用管理后台并设置口令（禁含英文单引号）/ 明确关闭。入口路径与登录账号见下文「管理后台:入口、账号与人机验证」 |
| `--admin-user <U>` | 后台登录账号，与口令成对写入 `.env`（字母/数字/`. _ @ + -`，1–64 位；不给则向导询问，填 `off` = 不设账号）。Windows 版为 `-AdminUser` |
| `--workers <N>` | worker 副本数（默认 **3**；1 万房真机实测需 2.2 CPU 核。账本与公式见下） |
| `--retention <天>` | 历史保留天数（默认 7；≤0 永久；**>1 时前端全屏序列自动出现「按日回看」导航**） |
| `--keep <N>` | `backup` / `update` 成功后，完整备份与代码快照各只留最近 N 份（默认 **7**；`0` = 不清理；也可用环境变量 `MAXX_BACKUP_KEEP`） |
| `--discovery on\|off` | 直播间自动发现（默认 on） |
| `--registry-mirror <URL>` | 写入 Docker 镜像加速（可多次） |
| `--pip-mirror <URL>` | 构建期 PyPI 源（容器内 pip 拉依赖走此源；清华/阿里等，Windows 版为 `-PipMirror`） |
| `--gh-proxy <前缀>` / `--cn` / `--no-docker` | GitHub 下载代理 / 大陆预设（含 Docker 加速与 PyPI 构建源引导） / 跳过 Docker 安装 |

同名环境变量 `MAXX_*`（如 `MAXX_TICKET`、`MAXX_PG_PASSWORD`）可替代命令行传参。

## 子命令速查

| 子命令 | 作用 |
|---|---|
| `status` | 各服务健康状态、worker 副本计数、`/api/version` 探针、数据卷 |
| `logs [服务] [-f]` | 查看/跟随日志（跟随中 Ctrl+C 只退出跟随，不杀脚本） |
| `seed [房号.. \| --file F \| --list]` | 注入监控房间；`--file` 支持数千房批量准入 |
| `scale <N>` | 调整 worker 副本并持久化 |
| `start` / `stop` / `restart` / `rebuild` | 整栈起停 / 重启 / 重建镜像滚动更新 |
| `accounts` | 配置酷狗账号库（票据自动续期），改完自动重启 login |
| `admin-hash [口令]` | 重设后台口令（容器内生成 PBKDF2 散列写回） |
| `admin-link [分钟] [访问基址]` | 签发一次性**应急登录链接**（默认 10 分钟有效；人机验证服务不可用、进不了后台时用）。主机默认取默认路由出口 IP，经域名 / 公网 IP 访问时传基址，如 `admin-link https://你的域名` |
| `backup` / `restore <目录>` | 三件套备份（库 dump + kgdata + 账号卷）/ 覆盖式恢复 |
| `update` | 拉新代码覆盖（保留 .env / kgdata / 备份），重建镜像 |
| `env` | 编辑 .env → compose 校验 → 可选热应用 |
| `firewall` / `doctor` / `uninstall` / `menu` | 放行端口 / 环境体检 / 卸载 / 管理菜单 |

## 部署完成后的两件事

1. **注入监控房间**：`sudo bash deploy-maxxiang.sh seed 321` 或 `seed --file rooms.txt`（每行一个房号）。
2. **配置票据自动续期**（强烈建议，票据约 30 天过期）：编辑 `kgdata/accounts.json`（参照同目录 `accounts.example.json`，字段 `username/password/mid`，password 支持 `env:变量名`），然后执行 `accounts` 子命令或 `compose restart login`。留空票据部署时脚本会以仓库示例票据占位并持续醒目告警（抓取将 401，续期成功后 worker 自动热切换）。

### 可选第三步：启用登录系统（MySQL 用户库鉴权）

启用后前端必须登录才能用，主播名录与酷狗账号库按登录账号隔离。用 `env` 子命令
（或直接编辑 `deploy/.env`）补五行后重建 web：

```bash
sudo bash deploy-maxxiang.sh env          # 追加以下五行(参考 backend_async/deploy/.env.example「登录系统」段)
# STA_USERDB_HOST=120.79.26.174
# STA_USERDB_PORT=3306
# STA_USERDB_NAME=fanxing_changkong_user_db
# STA_USERDB_USER=fanxing_admin
# STA_USERDB_PASSWORD=<真实密码>
docker compose -f backend_async/deploy/docker-compose.yml up -d --build web
```

启用前建议先体检用户库连通性/字符集/权限/口令形态：
`docker compose run --rm web python3 scripts/userdb_check.py`。
不设 `STA_USERDB_HOST` 即整体关闭（旧行为）。4.5.0 起该项可填**一组** IP
（`ip[:端口][*权重]`，逗号分隔）作为「同一逻辑库的多个网络入口」，用于分摊弹性 IP
带宽；单值与旧行为逐字节一致。完整方案/配置表/行为矩阵见仓库根
**`LOGIN-SYSTEM.md`**。

5.2.0 起登录自带**防爆破**(先占后验、可疑时自动加码、设备信任防锁人、全局攻击态),
正常用户零打扰、无需任何配置;另有**登录人机验证开关**(`STA_USER_LOGIN_CAPTCHA=risk|always`,
默认关;供应商与凭据和注册共用 `STA_USER_REG_CAPTCHA*` 一套。Turnstile 官方声明不支持
中国大陆,大陆用户为主请选腾讯云/极验)。同版修复:直连部署下伪造 `X-Forwarded-For`
可绕过管理台 IP 白名单 —— 现只有可信代理(默认环回 + 内网)发来的 XFF 才被采信。
管理台左栏新增「登」·登录风控:攻击态、当前被锁(可一键解锁)、可疑来源、被针对的账号与登录流水一屏看全。
详见 `LOGIN-SYSTEM.md` §4.5。

## 管理后台:入口、账号与人机验证(5.3.0)

| 项 | 现在是什么 | 在哪改 |
|---|---|---|
| 入口地址 | `http://<主机>:<端口>/admin-xdd` | `backend_async/config.yaml` → `admin.path`;或 `deploy/.env` → `STA_ADMIN_PATH`(优先) |
| 登录方式 | 账号 `13268237005` + 密码(密码即原来的管理口令,未改) | 账号与密码成对放 `deploy/.env`:`STA_ADMIN_USERNAME` / `STA_ADMIN_PASSWORD(_HASH)` |
| 人机验证 | 站点配了供应商(`STA_USER_REG_CAPTCHA*`,与注册共用同一套)就**每次登录必过** | `admin.login_captcha` / `STA_ADMIN_LOGIN_CAPTCHA`:`auto`(默认)/ `always` / `off` |

**账号和密码都在 `deploy/.env`**(凭据成对,不进代码库):改完 `sudo bash deploy-maxxiang.sh env`
重启 web 即生效,升级不丢。改账号就是改 `STA_ADMIN_USERNAME`。

部署脚本对这一对凭据的处理:安装向导在设口令之后问账号(重配时默认沿用旧 `.env` 里的账号);
`update` 保留服务器上的 `.env`,若其中还没有 `STA_ADMIN_USERNAME`,会以新代码包自带 `.env` 里的账号
(或 `--admin-user`)为默认值询问一次并写在口令行正上方(`--yes` 时直接采用默认值;键已存在、哪怕为空,
视为已明确决定,不再询问);部署后把明文口令转成散列、以及 `admin-hash`,都是**原位替换**口令行,
账号与口令始终相邻。

**入口路径和人机验证档位**在 `config.yaml` 的 `admin:` 段(入口是访问拓扑、不是秘密,放文件里便于
与反代规则一起版本化)。两种改法(优先级 `.env` > `config.yaml` > 默认):改 `config.yaml` 后
`sudo bash deploy-maxxiang.sh rebuild`(打进镜像,`update` 升级会被新包覆盖);或在 `deploy/.env`
写 `STA_ADMIN_PATH` / `STA_ADMIN_LOGIN_CAPTCHA`(重启即生效,升级不丢)。

**改了入口之后**:后台页面在 `/<入口>`,管理接口在 `/api/<入口>/*`,前端从页面地址自动推出接口前缀,
不需要改任何别的地方。旧地址 `/admin`、`/admin.html`、`/api/admin/*` 的应答与任何不存在的路径逐字节
相同(登录系统开启时未登录访问同样先得 401),从外面分辨不出这里有过后台。入口取值须为单段
(字母或数字开头,其后可含 `-` `_`,共 1–64 位),且不能与站点已有路径同名(如 `auth`、`monitor`、`rooms`,
否则会互相遮蔽 —— 例如配成 `auth` 会让观测台用户登录失效);写错了 web 会在启动日志里告警并回落 `admin-xdd`。

**唯一例外 —— 外部发卡接口保持原地址**:`POST /api/admin/jfvip/cards/issue` 是给外部系统的机器契约,
地址、鉴权(API Key)、返回体都与改造前相同,不随入口改名。

**登录的闸序**:IP 白名单 → 同源 + 只收 JSON → 请求速率(每 IP 段 20 次/分)→ 失败额度(每 IP 段 10 次、
全站 30 次 / 10 分钟,触顶锁 10 分钟)→ 人机验证 → 账号 + 密码。人机验证排在验密码之前:没过验证的请求
连密码都碰不到,也不消耗失败额度;账号错与密码错返回同一个错误。Redis 不可用时限速与失败额度退到进程内
计数 —— 不放开,也不会把管理员自己挡在外面(旧版 Redis 一挂,正确口令也只会得到「尝试过于频繁」)。

**人机验证不可用时怎么进后台**:验证服务不可达(或当前网络加载不出验证框)时,网页登录一律被拒绝,
不降级放行。此时在服务器上执行:

```bash
sudo bash deploy-maxxiang.sh admin-link        # Windows: deploy-maxxiang.bat admin-link
```

会打印一条 10 分钟内有效、只能使用一次的登录链接,浏览器打开即进入后台(发的是正常会话)。
正门被锁时它同样有效 —— 比如有人在分布式猜口令、全站失败额度已顶满,陌生设备的账号密码登录一律 429,
握着这条链接照样进得来(有效票据先验先过;坏票据只记在递它的来源头上,不占全站额度)。
票据在 web 容器内签发,签名密钥只在服务器环境里;每次使用都写审计(动作「应急链接登录」)。
裸机 / 自编排环境等价命令:`docker compose exec web python -m app.admin_auth link --base http://<主机>:<端口>`。

**升级须知**:① 旧书签 `/admin` 会打开观测台首页,请改存新地址;② 已登录的会话不受影响(签名密钥
由口令派生,口令没变);「常用浏览器」的设备信任需重新登录一次后恢复;③ `maxx-diag.sh` 的 S3 段
已改为用服务器签发的一次性票据登录(口令登录过不了人机验证)。

## 用词口径(4.x:前端文案对齐官方盘面)

九法是**游戏**,不是彩票。前端用户可见文案一律以 `jiufa/js/index.web.*.js`(未改动的官方
原版 bundle)的用词为准,不再使用博彩/彩票词汇。映射与依据:

| 旧 | 新 | 官方原文依据 |
|---|---|---|
| 开奖 / 开奖序列 | 出怪 / 出怪序列 | 「关注最近妖兽,提前预判**出怪**规律」 |
| 封盘 | 备战(短语用「已停止布法」) | 「妖兽即将出动,当前不可布置法术」 |
| 施法押注 | 布置法术 | 「布置法术」 |
| 注单 / 注数 / 单注 | 法术记录 / 攻击次数 / 单次 | 「暂无法术记录」「攻击次数」「本轮投入」 |
| 赔率 / 派彩 / 中奖 | 倍数 / 奖励 / 命中 | 「倍数」「经验值奖励」「有效 / 攻击失败」 |
| 号位冷热 | 出怪规律 | 「预判出怪规律」 |
| 走势 / 遗漏 / 珠图 | 战况 / 未出场 / 轨迹图 | 无官方对应,项目取词 |
| 下注 / 盈亏 | 布法 / 得失 | 同上 |
| 返还率 / 庄家优势 | 回报率 / 平台留存 | 同上 |
| 奖池 / 开盘 / 收盘 / 盘口 | 奖励池 / 开局 / 局末 / 局面 | 同上 |

覆盖范围:用户可见文案、代码注释、后端日志与 docstring、管理台配置项 `label`/`desc`、
全部 `.md` 文档、部署脚本与 `config.yaml` 注释。

### 通用义例外(改这批词必须逐条判读,不能全局替换)

下列词在中文里另有通用含义,**不是**术语,一律保持原样 —— 全局替换会写出错话:

| 原文 | 断词/语义 |
|---|---|
| 「两处**遗漏**」「最严重的一次**遗漏**」「**遗漏**会自动变红」 | 遗漏 = 疏漏,不是「距上次出现的期数」 |
| 「省**下注**定失败的往返」 | 是「省下 + 注定」,不是「下注」 |
| 「实**盘口**径」 | 是「实盘 + 口径」,不是「盘口」 |
| 「让**开奖**重试阶梯偏移」 | 是「让 + 开奖」(动词让),这一处**要**替 |

领域义的「遗漏」统一用**未出场**(不带「次」):「已未出场几期」通顺,
「已未出场次几期」不通;需要计数时才写「未出场次数」。

**未改动**(改了会破坏契约):`localStorage` 键、API/DB 字段名、CSS 类名与 `data-*` 值
(如 `data-phase="seal|draw"`)、`jiufa/js/` 官方 bundle、`sim-hud.js` / `bridge.js`;
`sim-engine.js` 仅改了 `*/` 之前的文件头明文注释,混淆体逐字节未动。

前端文案受后端测试**静态守卫**(`tests/test_rail_status.py`、`test_frontend_backend_limits.py`、
`test_jfvip_contract.py` 等直接读 `assets/app.js` / `index.html` 断言关键句)——改文案必须
同批改守卫,否则 CI 挂。

## 关键工程决策（为什么脚本长这样）

这些均来自对项目源码的实地核查，脚本据此钉死行为：

- compose 声明 `env_file: .env`——**该文件不存在整栈无法启动**，脚本必生成且 600 权限；管理子命令定位到部署但缺 .env 时直接指引重装。
- `.env` 内写死 `COMPOSE_PROJECT_NAME=maxxiang`，否则项目名会落成目录名 `deploy`，易与他项目冲突。
- 镜像内应用用户 uid=10001：kgdata 绑定目录预先 `chown`，SELinux Enforcing 时自动 `chcon -t container_file_t`，消除 login 首启竞态。
- web 镜像 CMD 钉死单 uvicorn worker（账号后端为进程内内存态），脚本任何路径都不改这一点。
- PostgreSQL 密码强制字母数字（该值被 compose 拼进 DSN）；票据强制 32–128 位 hex、管理后台 IP 白名单强制 CIDR 字符集、口令禁英文单引号——**所有会进 .env 的值都在输入侧拦截**，防 dotenv/插值被破坏。
- 后台口令先以单引号明文起栈，部署成功后自动调用镜像内 `python -m app.admin_auth hash` 换成 PBKDF2 散列并单引号写回（`$` 不被吞），热重建 web；复用旧 .env 时若发现上次中断遗留的明文，同样会被转散列。
- worker 默认副本 **3**（= 公式基线，≈8600 房容量；真机实测账本：每局 worker CPU = 11.2ms → 1 万房 200 局/s = **2.2 核**，1 万房按公式取 4 副本）；按需 ≈⌈总监控房数/4300⌉+1。**默认配置下硬顶 11**（PG 连接账本：400 − web 池 32 − 超管预留 3 ≈ 365，÷ 每副本 32 ≈ 11），再往上先调 `max_connections`；3 副本实际占用 **131/400**。副本数持久化在 `deploy/.deploy-state`，每次 `up` 显式 `--scale`（compose 文件里的 `replicas` 不是生效值）。副本是否充足的三步体检（到期积压 ZCOUNT / 统计行吞吐对账 / CPU 顶格）见 `backend_async/README.md` §5.3。
- 建议机器最低配置：默认参数（worker×3 · PG `shared_buffers=2GB` · redis `maxclients=20000`）按 **4 核 / 8G 内存 / 100G SSD** 起步（3 副本按公式适配 ≤8600 房，更多加副本即可）；~2 万房 8C16G/200G、~5 万房 16C32G/500G NVMe；磁盘按 ~5–7MB/房 估算（保留 1 天）。**内存 <8G 的小机**请把 compose 里 `shared_buffers` 调回 1GB/512MB 并 `--workers 2`。规格表详见 `backend_async/README.md` §5.1。
- **命中率口径（4.6.0）**：推演卡的「近 N 局命中率」此前取的是「最近 N **条**判定行」，预测链中断过（房间移出名录 / 降级为发现房 / curated-idle 冷房）再回来时，会把**几天前**的旧行当成近 N 局展示（真机实测：那 100 条只跨 1.4h，最新一条距今 142.6h）。现改为以最新一局为锚做区间约束；链连续的健康房逐字节无变化。空出来的窗口由**命中率补算**（`prediction.replay_*`，默认开）按生产同一条代码路径因果重跑填齐，补算行带 `source='replay'` 单独计数。**它是回测不是实盘战绩**，详见 `backend_async/README.md` §10.1。补算绝不触碰 `predictor_state`，实盘预测流逐字节不变。
- **推演卡命中率行文案（4.7.5）**：4.6.0 曾在有补算局时于命中率行追加一个回测条数角标，现已按产品要求移除——推演卡与随身面板的命中率行恒为 `近N局 主中X · 防中Y`（= 4.4.x 文案），tooltip 里分列实盘/回测条数的那句一并去掉。**后端契约零改动**（补算行照常带 `source='replay'`、`accuracy` 照常回 `replay` 字段），删的只是前端展示层；「上局开X·主中」徽标的实盘过滤仍在，补算判定永不冒充战绩。取舍与恢复方式详见 `backend_async/README.md` §10.1「诚实边界」。
- **冷位份额闭环（本次）**：`showcase` 风格对「本局带几只冷门」有份额闭环，对「带哪几只」没有 —— 冷位是对固定冷池 (3,4,5,6,9) 做 `argmax(融合概率)`，而冷池内概率序在千局尺度上几乎不翻转。真机三房（1275859/2678075/3746870）7 天 34,988 成熟局实测（关掉轮换、其余生产口径）：号5/号6 进四码 **61.9%/67.0%**、号9 仅 **3.2%**（几乎全靠保底，保底率 3.04%），相邻局四码集合全同 **35.1%**、同四码最长连推 **14 局**、单号最长连续在册 **410 局**、组合熵仅 4.44 bit —— 用户侧的表现就是「一直推那几个冷门号，像卡死」。现给「身份」补上与 k 同构的份额闭环（目标份额 ∝ p^η + 赤字账本 DRR）+ 同四码连推硬帽。同批配对实测（开=现生产口径）：邻局全同 **35.1%→7.1%**、最长连推 **14→3**（硬不变量）、冷位 HHI 0.381→0.225、熵 4.44→5.46 bit、保底率 3.04%→0.05%、9 号进四码 3.2%→15.7%、四码期望回报 **+8.1%**；代价是四码命中 55.78→53.75%（**−2.03pp**，McNemar b/c=3990/3280 **p<0.001** —— 3.5 万局把旧样本上的「不显著」钉成了确定的小额代价：约每 49 局少中 1 次四码，换来多样性与回报），主中 −0.56pp。两行均含重现观察期（现生产口径，见下条）。总开关 `prediction.showcase_rotate`，关闭时与改造前**逐局字节级等价**（等价门禁 `analyze_rotate.py --gate`）。复跑用 `window_audit/analyze_rotate.py`，回归钉在 `backend_async/tests/test_showcase_rotate.py`。
- **天花板前沿调度（4.8.0；4.9.0 起默认开 → 4.9.7 默认关 → **4.9.8 起再次默认开，且刻度全变**，见本条末尾 4.9.8 段）**：三房 7 天 36,278 真机局的实地核查证明出怪与 i.i.d. 多项分布不可区分 —— 21 项规律检验（时段/星期/一阶~三阶条件/游程/冷门聚集/跨房同步）p<0.05 者 **0 项**，Bonferroni 后通过者无；转移矩阵滞后 1/2/3/5/10 全部 p>0.2；九兽危险率对间隔 |z|≤1.8。子模型逐路因果 log-loss 显示 **M5（二阶转移）比均匀分布还差**，且事后最优凸组合权重解 = M1 1.000、其余全 0；生产融合 log-loss 2.08661 vs 常量真频 2.08022（t=+8.04，p=9e-16）—— 整套集成净信息贡献显著为负。该前提下有可证结论：策略长期期望只取决于「126 个四码集合的使用频率分布 x」⇒ 最优策略 = 一个线性规划的解（数学天花板）。新增 `explore_style: "frontier"` 即「解 LP + 确定性最大赤字轮转」，自带纯 Python 精确单纯形（生产无 numpy/scipy；经 **220 例随机 p̂ × 随机约束**模糊对拍定型 —— 第四轮复查曾炸出 8 例假不可行，根因是极端量级下主元规则停滞被误当无解，已用输入钳位＋Dantzig 兜底＋出解后逐条复核三道堵死；修复前后生产口径解逐字节一致）。真机 A/B（36,182 配对局，**4.9.0 复核后更正**）：总命中 53.71→53.67%（McNemar **p=0.913，无差异**）、主中 30.39→31.65%、冷门 11.41→12.23%、稀有 1.669→1.907%、回报 8.2923→8.5674 —— **总命中并未提升，四项其余指标上升**。〔更正记录：本行原写「总命中 53.71→54.55%（p=0.0095）、主中 33.41%、冷门 11.88%、稀有 1.761%、回报 8.3572」，4.9.0 用同一套工具在同一份自带库上复跑**不复现** —— showcase 基线逐位吻合（53.71/30.39/11.41/1.669/8.2923，证明工具链无误），仅 frontier 一侧对不上；回溯 4.8.7/4.8.8 历史口径（fr_share_min 0/0.05 ＋ fr_main_share_min 0）也只得 53.79%/53.65%。原数字来源不明，且它自身违反了同句的「勿按更大的数字宣传」，故按实测更正。复跑：`python3 window_audit/ceiling_recheck/bench_variants.py --plan <方案json>`〕单局耗时 7.57→5.76 ms（−24%）、explore_state 3804→1302 B（−66%）。〔**4.9.7 复查更正**：后半句在本包**不可复现**。实测 frontier 稳态 explore_state = 1,593 B、showcase = **17.3 KB**（不是 3804 B），差 10.9× 而非 66%。逐字段拆开大头是 `zh`≈10.3 KB 与 `kd`≈5.8 KB，二者均为 `deque(maxlen=max(60, explore_calib)=240)` ⇒ **有界、非泄漏**，但要跑满 240 局（≈3.3 小时）才到平台；3804 B 对应约 40~50 局的未到平台状态，**原测量取样过早**。单局耗时同批实测 3.34→5.52 ms。⇒ 切回 showcase 的真实代价是 **CPU +65%、持久化体积 ×10.9、PG 写入放大 ×9.8**（实测稳态每局写回 17,292 B vs 1,786 B；8600 房外推 ≈0.95 核 / 148 MB / 2.84 MB/s，原 0.29 MB/s），规划容量时必须连着看，详见 config.yaml `explore_style` 段。〕代价：组合熵 5.56→4.52 bit、号4/号9 份额被挤压（28.5→7.8% / 15.9→5.8%）。**默认配置下与改造前逐局字节级等价（36,188 局 0 处不同，实测非声明）**。它**不预测**下一局、也不声称发现规律，`why` 落款只陈述配额事实（由 `tests/test_frontier.py` 的诚实性守卫钉住）。〔**4.9.8 更正 —— 本条上面所有「现行/休眠」的说法均已作废**：`explore_style` 已改为 `frontier`，`fr_share_floors` **清空**，三条聚合下限启用为 `0.116633 / 0.01683 / 8.358387`。上文那组 A/B（总命中 53.71→53.67%、冷门 11.41→12.23%）测的是**带出厂逐号地板**`"3:0.40,9:0.30,4:0.20,5:0.20,6:0.20"` 的 frontier —— 那把钉子硬把号9（实测 p=3.561%，九号最低）钉进 30% 的局、号3 进 40%，把 LP 自由度吃光，**frontier 输在钉子上不是输在机制上**。清空地板后三房 36,182 配对局实测：总命中 **53.737→54.746%（+1.009pp，McNemar b/c=7138/6773，p=0.00203）**、主中 30.222→31.911%、冷门 11.497→11.644%、稀有 1.625→1.805%、回报 8.2365→8.3923（+1.892%）—— **五项无一为负**。刻度由「欠达比反解迭代两步」得出，再经**严格样本外协议**（前 2/3 选优 → 后 1/3 验证，20 个候选）定稿：验证段 n=12,062 里**只有它一个**仍满足四项全不劣（δ=0 那档训练段第一名，验证段命中归零、冷门 −0.531pp、回报 −5.21%）。诚实边界：命中 6/6 时间段全正（段级 t=+3.82）是唯一又大又稳的一项；冷门仅 +0.147pp、6 段中 3 段为正（t=+0.85），是最脆的一项，要钉死需约 16 房×7 天。⇒ 现在 `fr_*` 全组**生效**，反过来是 `as_*/sc_*/rg_*/cg_*` 与六路子模型刻度整组休眠。同批红利：单局耗时 8.20→4.23 ms（同批比值 1.94×）、explore_state 20,509→1,773 B（11.6×）、逐号最长不进四码 46→27 局；代价：组合数 117→60、熵 5.51→4.27 bit、邻局全同 2.6%→8.0%。复验新房用 `window_audit/export-rooms.sh` + `verify-holdout.py`，详见根《4.9.8-变更说明.md》。〕完整报告见根 **`灵机推演天花板前沿方案.md`**，复跑用 `window_audit/frontier_audit.py`。
- **逐号份额地板（4.9.0 落地；`explore_style` 默认曾同批由 `showcase` 改为 `frontier`，**4.9.7 已改回 `showcase`** ⇒ 本条连同整组 `fr_*` 现为休眠，仅作回滚基线）**：实地核查发现 frontier 的三条**聚合下限总被最便宜的成员满足**，钉不住具体号 —— `fr_ret_min=8.624` 由 6/7/8 号（100x/50x/50x）顶掉（只加它时 s₃=s₉=0.08、稀有仅 0.679%），且它恰是把稀有钉死的那根钉子：同总命中同冷门下带 ret≥8.624 时稀有最大值 = **1.800%（一分抬不动）**，去掉立刻到 2.341%；`fr_cold_min=0.1232` 的 **81% 由 5/6 号贡献**（原解 s₆=0.80、s₅=0.24），真正稀有的 3/4/9 只贡献 2.32pp，抬冷门下限只是在买更多 6 号（实测 fr_cold_min=0.155 时 s₅=64%/s₆=71%，稀有纹丝不动 1.700%）；把稀有池扩到 `"3,4,9"` 同样失效（LP 全用 4 号顶）。处置 = 新增 `fr_share_floors`「号:份额」直接钉份额，三条聚合下限置 0。地板**不含 p̂** ⇒ 份额是保证值而非估计值，顺带消掉聚合下限的估计噪声泄漏（实测 `fr_cold_min` 真实达标率仅 **29.5%**）。定稿刻度 `"3:0.40,9:0.30,4:0.20,5:0.20,6:0.20"`，真机 A/B（36,182 配对局 vs 4.8.9 frontier）：**主中 31.65→32.25%（p=0.022）**、**稀有 1.907→3.118%（+63%，p=3.3e-34）**、**回报 8.5674→8.9743（p=6.6e-4）**、总命中 53.67→53.15%（**p=0.107 不显著**）；冷门（聚合）12.23→8.44%（p=1.3e-78，**变差**）。逐兽捕获率 3号 29.8→41.2%、4号 16.3→20.2%、9号 12.3→**30.5%**；最长连续未进四码全线 21~26 局 → **6~14 局**。**代价必须连着看**：聚合冷门掉 3.79pp、5/6 号（100x）露面近乎腰斩（38.7→21.2% / 58.3→20.9%）—— 该指标不在前端展示（前端只展示主中率与总命中率），但若产品口径的「冷门」含 5/6，改用 `"3:0.40,9:0.30,4:0.25,5:0.40,6:0.40"`（冷门 12.39% 与现行持平 p=0.44、稀有 3.060%、回报 9.1796，代价总命中 −3.40pp）。旋钮只有一个：5/6 号地板每 +0.10（两只同调）约换 1.2pp 总命中。⚠ 切到 frontier 后 `anti_stubborn`/`showcase_rotate`/`repeat_guard` 及其 as_*/sc_*/rg_* 全组**不生效**（硬门在 `explore_style == "showcase"`；实测开/关四码逐字节相同），config.yaml 保留它们只为回滚，引擎启动会就此喊一声 WARNING。回滚 = `fr_share_floors` 改空串 ＋ 三条下限改回旧值（`fr_main_share_min` 维持 0.08，**不要为那 0.91pp 主中率把它调 0** —— 会让号 3/4/5/7/9 永不进主位）。守卫见 `backend_async/tests/test_share_floors.py`（16 例），复核脚本见 `window_audit/ceiling_recheck/`。
- **默认风格改回 `showcase`＋冷位节拍器三层补齐（4.9.7）**：交付时仓库处于**半迁移**状态 —— 引擎 `PredictionConfig` 已是 4.9.7 姿态（`explore_style="showcase"`、`showcase_kdist="45,31.5,13.5"`、`cadence_governor=1`、三条聚合下限归 0），而 `config.yaml` 与 `config_registry.py` 没跟上，实测 **5 条测试红灯**（`test_frontier::test_default_style_is_the_audited_choice`、`test_config_registry` 两条 drift-guard、`test_cadence_governor::test_config_three_way_consistency`、`test_share_floors::test_dead_switches_under_non_showcase_style_are_loud`）。本次按「三层同值」纪律一次改齐：
  · `config.yaml` `explore_style` `frontier`→`showcase`（4.9.0 那条「showcase 帕累托被支配」的依据把**LP 天花板 55.13%**与**实测值**混用了，且 53.67% 对应 4.8.9 聚合下限口径而非出厂逐号地板口径；按出厂刻度复测三房 36,182 配对局，showcase 53.71% vs frontier 53.15%，McNemar b/c=7539/6292 **p=3.2e-26，showcase 更优**）；
  · **关联参数同批**：`showcase_kdist` `45,30,15`→`45,31.5,13.5` —— 它与 `cadence_governor` 是**成对**的（节拍器令牌桶的滴水速率**就是**这里的 cums），只翻一个是仓库从未测过的中间态（实测只关开关时与基线仅 5,162/12,064 局相同）。而 `cadence_governor` 及 7 个 `cg_*` 此前**只存在于引擎 dataclass**，`config.yaml` 与注册表都没登记 ⇒ 静默取引擎缺省「开」，配上关态刻度的 kdist，正好落在引擎注释明令禁止的半状态。三层补齐后该组转绿；
  · 注册表 `fr_cold_min` / `fr_rare_min` / `fr_ret_min` 由 4.8.9 旧值 `0.1232`/`0.0180`/`8.624` 对齐为 `0.0`（引擎与 yaml 从 4.9.0 起就是 0）—— 注册表 default 是「重置/回落基线」的取值来源，漂了会让管理台「默」印说谎、并可能把休眠的聚合下限重新激活；
  · 补实现 `predictor_bridge._warn_inert_frontier_keys`（测试引用它但**函数根本不存在**）：`_warn_dead_switches` 的镜像，非 frontier 风格下点名空转的 `fr_*`/`prior_*`，两条按键名分域、永不同时触发；
  · 两个独立引擎配置 `jiufa_data/spell_tamer_config.json`、`backend_async/deploy/kgdata/spell_tamer_config.json` 同款半状态，一并补齐。
  行为实测（生产代码路径，120 局因果驱动）：新旧配置四码 **0/120 相同**（风格确实换了）；`explore_state` 出现 `cgb3/cgb2/cgr3/cgr2`（节拍器已激活）；节拍器开/关 15/120 相同、三大总开关开/关 6/120 相同（**在 showcase 下真生效**）；`fr_*` 拨到极端 **120/120 全同**（**确认惰性**）。回滚 = `explore_style` 改回 `frontier` ＋ `cadence_governor: false` 与 `showcase_kdist: "45,30,15"` 两键同批，并回改上述测试断言。
- **showcase K 分布默认值改为 `35,40,15`（4.9.10）**：对 `prediction.showcase_kdist` 做了十一档全量扫描 —— 三房 7 天 34,982 成熟配对局、生产代码路径（predictor_bridge → 引擎）逐局因果回放、零随机源；测量口径先经双重外验（PyPy 与 CPython 逐字节全同；D 档五指标与本文件 4.9.7 节拍器开态实测 53.74/30.22/11.50/1.625/8.2365 逐位吻合）。结论：**kdist 只是「命中↔回报」单调权衡曲线上的取点**，主导变量是期望冷位数（命中率≈线性 −8.4pp/冷位，三档拆分是二阶效应：45,31.5,13.5 与 45,30,15 在 34,982 局上命中 18,795 vs 18,796、McNemar p=1.0000），4.9.7 值（=自然份额中性点）不是任何指标的最优，但也不被任何档位双指标支配。新默认 `35,40,15`（cums 90/55/15）：四码命中 53.73→52.61%（−1.12pp，p=1e-4）换 回报/注 8.230→8.449（+2.7%）、冷门中 11.51→12.60%、稀有中 1.632→1.830%，6/6 时间×房间切片同号；满足 4.9.8 产品三条下限（冷门≥11.66%/稀有≥1.68%/回报≥8.358/注）的共五档（`35,40,15`/`40,35,20`/`30,38,27`/`25,40,30`/`0,0,95`），新默认是其中**四码命中最高**的一档（=下限约束下的命中最优；4.9.7 默认三条全不达 11.51/1.632/8.230）；目标 k≥1 仍 90%，风格人设不变。边界档实测：`0,0,0` 命中 +10.2pp 但硬帽率 22.2%、冷稀覆盖崩塌（与反固执机制互搏，超出设计包络）；`0,0,95` 回报/注 9.511 为上界，达成份额被节拍器 run 帽精确钉在 k≥2=6/7、k=3=4/7（帽算术逐位吻合，硬不变量实测成立）。**语义澄清**：三个原始数是**恰好**带 1/2/3 只冷门的份额，引擎实际使用的 cums 才是 k≥1/k≥2/k=3。**域提示**：本键仅在 `explore_style="showcase"` 分支被读取，当前默认风格 frontier 下休眠 ⇒ 本次改默认**不改变现行生产输出**（已实测惰性），生效于任何切回 showcase 的部署。四处同批（引擎 dataclass / config_registry / config.yaml / `predictor_bridge._CADENCE_KDIST_ON`，由 `test_config_three_way_consistency` 钉住）；桥护栏新增「旧默认 45,31.5,13.5 快照残留」喊话（累积继承会静默盖掉新默认）。回滚到原版仍是两键同批：`cadence_governor→false` ＋ 本键→`"45,30,15"`（解析失败兜底刻意维持 45,30,15 不随默认走）。全表、分房、时间切片与复跑脚本见 **`window_audit/AUDIT-4.9.10-showcase-kdist-全档扫描.md`**（`window_audit/kdist_sweep.py` + `analyze_kdist_sweep.py`）。
- **`explore_style` 对未知取值是静默兜底**（实证：`hot_rotate` / `ceiling_adaptive` / 任意乱写串三者输出逐字节相同，全落到通用冷门探索分支）。4.8.0 起引擎会打一次 WARNING，注册表 enum 补齐 `frontier` 并写明该行为；`jiufa_data/value_grid.py` 与 `validate_hot_rotate.py`（引用引擎不存在的 `rotate_value_beta`/`rotate_q`）改为明确报错退出，`tests/test_hot_rotate.py` 整体 `skipif` —— 它此前会**全绿通过但测的是通用兜底分支**。
- **自带真机库的陈旧边车已清除（4.8.1）**：`jiufa_data/spell_tamer_data.db` 主库头部写版本=1（rollback-journal 模式，本不该有 WAL），却带着一个 ckpt 序号=9、4.1MB 的陈旧 `-wal`（手工解帧：1003 帧中仅前 489 帧 salt 匹配且校验通过）。SQLite 套用后 b-tree 当场坏（`invalid page number 218103808`），`rounds` 整表不可读 —— 这正是 `tests/test_pred_replay.py` 六个真机钉长期全红的根因。主库自身 `integrity_check=ok`、36,278 行一行不少，故直接删掉 `-wal`/`-shm` 两个边车（主库字节不动）。修后该批测试 **6 failed → 0 failed（46 passed）**；`window_audit/` 全部工具现在可直接用自带库开箱跑。防回归钉：`tests/test_probability_drift.py::test_bundled_db_is_readable_at_all`。
- **公示概率表与实盘的偏离已被钉住（4.8.1，未改表）**：`mock/data/room-321-config.json` 是前端「官方」列、2σ 偏差着色、九法阵 `stateOf` 周期 `round(100/p)` 的唯一真源，而它与自带真机库系统性不符 —— 号9(500x) 公示 2.00%/实测 3.561%(z=+21.2)、号3(330x) 3.50%/4.929%(z=+14.8)，χ²=726.6(df=8)，**逐日复现**（号9 日 z +7.1~+8.8）、分房齐性 p=0.441，既非过期快照也非分房差异。后果是号3/号9 在 24h 满窗下**恒被判偏热**，与盘面无关。**处置口径：不拿实测值覆盖公示表**（公示值是游戏方声明的事实，实测是我们的估计，替换只是换一种失真），改为把"已知偏离"钉成常量 —— 偏离变了会红，有人把表改成实测值也会红，两种都需要人做一次显式决定。守卫 `tests/test_probability_drift.py`，复现工具 `window_audit/prob_drift.py`。
  另：`tests/test_official_probability.py` 在本包里**无法收集**（`app/constants.py` 缺 `OFFICIAL_PROBABILITY`/`fmt_probability`、`web.py` 缺 `_js_parse_float`/`_probability_ok`，源文件比测试旧了一代）——即"守卫上一条的那个测试本身是死的"。未修，理由见根《灵机推演天花板前沿方案.md》§5.5。
- **名录直播状态（5.0.6）**：主播名录那颗 `.ri-live` 绿点由**纯装饰**（每条恒亮、选中转朱砂、不携带任何信息）改为**状态位**，三态：直播中=绿点脉冲 / 未开播=整枚隐藏 / **未知=静态灰环**。判据分两级，均为实地核查定案（2026-08-12 真机实测）：① **在册即在播**——在播列表遍历（`discovery.sweep`）的 rooms 全集本就**含策展房**（reconcile 只是不把策展房写进发现集），策展房出现在里面即此刻在播，顺手记一笔，**零请求**（实测在册房 2 分钟后逐个复核 roomStatus，60 房中 59 房仍 `liveStatus=1`）；② **缺席不算下播**——在播列表是**推荐流**，45s 两轮实测 A=1373/B=1387，掉榜的 17 房里 **6 房（35%）仍在直播**；更硬的反例是频道房（`roomType=3`，本项目固定房 321→2678075 即是）**从不上榜**，只看列表等于对每个新用户的第一个房永久谎报「未开播」。故列表缺席的策展房逐个打 `roomStatus`（`starmeta._room_status` 一直在解析 `liveStatus`，只是被 `_resolve` 丢掉了）。**纪律：只有成功观测才改判**——探测失败/超时/短号不可判一律不写，保留旧观测让它自然变陈，陈过 `livestatus.stale_s` 由 web 降为 `null`（前端画灰环）；绝不把「问不到」画成「没开播」（与 3.9.5 名录角标诚实化同一条戒律）。成本：探测只覆盖**策展房**（前端可见房），60s 周期百房量级 ≈1.7 rps，经繁星令牌桶，`max_probe` 再给一道硬闸。开关与刻度见 `config.yaml` `livestatus:` 段与管理台新板块「直播状态」（`STA_LIVESTATUS_ENABLED` / `_INTERVAL_S` / `_MAX_PROBE`）；`interval_s` 与 `stale_s` 有跨字段硬校验（`stale_s ≥ interval_s×2`，否则观测恒在下轮探测前过期 = 名录全员永久灰环，属静默失效）。观测出口：`/api/crawler/status` 的 `liveStatus` 块（在播/未开播/未知/本轮探测数）。守卫 `backend_async/tests/test_livestatus.py`。
- **状态位可见性与视觉语言(5.0.6 同批)**：真 Chromium 逐色量测（`backend_async/scripts/frontend_rilive_probe.mjs`、`frontend_rilive_a11y.mjs`、`frontend_nudge_badge.mjs`，均可复跑）发现并修掉三处「画了等于没画 / 画重了」：① `.ri-live` 的**未知**态原用 `--line` 描边，实测名录底上仅 **1.08:1**（WCAG 1.4.11 非文本门槛 3:1）——该态存在的唯一理由是「不许把问不到说成没开播」，看不见就等于没有这个理由，改 `--mute` 后 **5.04:1**；② 同族排查发现 `.ri-tick.slow`（闲置省流）与 `.ri-tick.idle`（待）的虚线同样是 `--line` 1.08:1，而 `.slow` 排在 `.hot/.next` **之前**、底色被后者覆盖，那道虚线是「省流」与常态的**唯一**区别 ⇒ 该状态实际上从未被标注，同批改 `--mute`；**二修**：只换颜色**没修好** —— 做真 alpha 合成后实测 `hot slow` 的描边仍是 **1.17:1**（`.hot` 排在 `.slow` 之后、底色被朱砂实底覆盖，而 `--mute` 是给浅底调的），而「出怪窗内的省流房」恰是这条组合态最常出现的时刻，补 `.ri-tick.slow.hot` 近白描边后 **4.39:1**；`.lost` 的朱砂描边 4.30:1 原样，按色相区分告警；其**字色**原为 `--seal` 实测 4.30:1，差 0.2 够不着 AA 正文 4.5（本字号 10.5px，不适用大字例外）——「断」是全名录唯一的告警字，最不该是看不清的那一个，改用色板里现成的 `--seal-deep` 后 **5.65:1**（**不动全站 `--seal` 令牌**，只换这一处字色，做法与 4.3.6 星币色 #a8781f→#8a6114 同源）；③ ☰ 新手徽点原文「逐字节承接 `.ri-live`（7px brand 圆点 + pulse）」，那是在 `.ri-live` 还是无意义装饰的前提下做的承接 —— 5.0.6 起绿色脉冲圆点 =「主播在播」，承接即撞车。实测 iPad 驾驶舱触屏下 `#railOpen` 为 `display:grid` 与名录**同屏**，而 `data-nudge` 的触发条件是「名录只有 1 房」= **每个新用户的默认状态**，新手第一屏会看到两颗一模一样的绿点、两种意思。改为 `--gilt` 金调 + 圆角方块（色相与形状双双区分，色觉障碍下靠形状仍分得开；7×7 与定位一字未动，扩散环改用 `pulse-gilt` 不复用绿调）。另：状态必须**双写** —— Chromium CDP 实测后代元素的 `title` **不进**祖先按钮的 computed name（只挂 title 时按钮名里一个字都没有），故 `.ri-live` 同时写 `role="img"+aria-label`；叠加仓库既有事实「全站 title 在触屏一律不渲染」，只写 title 等于对读屏与触屏用户同时失声。**量测纪律**：上一轮的探针把 `rgba(0,0,0,.035)` 这类半透明底当纯黑算，把 `.ri-tick.next` 误报成 3.42:1「文字不达标」——真值 **4.67:1，是达标的**；错误的量测比不量测更坏，它会把人引去改一个本来没病的地方。`frontend_dot_language.mjs` 现做真 over 合成，并自带一枚钉守住这条，同时对全站 ≤10px 小点做「同形同色」普查。守卫见 `tests/test_livestatus.py`。**端到端已用真栈跑通**：`scripts/e2e_stage_livestatus.py`（起真 web + 真 PG + 真 Redis 并播种一房，带双闸：必须 `MAXX_E2E_STAGE=1` 且 DSN 指向 localhost，否则拒绝执行——它会往 PG 写伪造 rounds）配 `scripts/frontend_rilive_e2e.mjs`（真 Chromium 逐态改后端观测再整页重载）：`live=true→绿点+aria「直播中」`、`live=false→整枚 display:none`、`无观测→灰环+aria「直播状态未知」`，三态 10 项断言全绿、零未捕获异常。真栈还实测到一次**上游探测超时**（elapsed 6.14s = StarMeta 会话超时先于 `request_timeout` 生效，与文档一致），此时 `probeOk=0/probeFail=1`、**不写任何状态**、该房如实报 unknown——「失败不改判」这条纪律是被真实失败验过的，不是纸面声明。
- **DIY「近24小时战况」增高（5.0.8）**：两个 DIY 象限的盘面常驻件（头部同步条/账号条/局条/内页签/施法盘/推演带/施法条）把滚动口吃掉大半——1024×768 停靠列战况只剩 5 行、375 手机直接 0 行。本批**只压不删**：同步条在 DIY 下只留 4.8.0 房号凭证（相位点/倒计时/最近珠与盘内局条逐项重复；官方象限原样）；账号条/局条/施法盘/推演带/施法条按容器档各收一档（图标 44/48/54→40/42/46 等，字号档全部不动）；`rgFitRoad` 留白 8→6 与盘面底衬 6→5 联动。真 Chromium 十视口实测（移动端真触屏仿真、基线同口径复测），战况可用高：1024×768 坞 86→204（5→12 行）、1280 94→245、1440 194→345、1920 405→525、剧场 820 472→573、手机 390 154→266、430 218→345、375 从必滚（−39）到可见 3 行；十视口零横向溢出、零意外折行。**作用域红线**：全部规则锁 `.rg-body` 前缀，或以 `:has(> .real-pane:not([hidden]))` / `:has(> .sim-pane:not([hidden]) > .rg-body:not([hidden]))` 面板级判 DIY（`applyGameSurface` 落位矩阵的两条充要判据；`#realBody` 永不挂 hidden，判 `.rg-body:not([hidden])` 会误伤官方象限）——`.of-acct`/`.of-aide` 复用同款类但不在 `.rg-body` 内，官方象限实测零变化（免疫断言入探针）。**触屏纪律**：推演带单行合并、施法主钮 38→34、A 档页签收窄三处收紧只给「悬停+细指针」设备，并叠 `html:not([data-input="touch"])` 按最后一次输入方式运行时收敛（4.9.4 同式，媒体查询作首帧默认值）；触屏统计行永不省略——全站 title 触屏一律不渲染（5.0.6 实证），省略即删信息，4.9.3 缺口注脚在触屏靠折行全量可见（实测 390 长文案零截断）。顺修一处既有缺陷：施法条副行 ≤400 内容宽时折行把条高撑到 74.5/91.5，补 nowrap+省略（截掉的只是单价尾巴：主钮恒显合计、确认层恒显 ×次数+合计+余额，扣款前关键数字一个不缺）。复查轮抓出并守住一条 5.0.7 不变式：格缝 6→5/7→6 后命中脉冲环默认 6px 会压到邻格边框，B/C 档随缝补 `--rg-hit:4/5px`。推演统计行补 `title=predStatTitle`（与观测台 `#predStats` 同源；`rgPredToken` 末四位 n|main|cover|window 恰覆盖其全部读数，无漏刷）。量测夹具与断言探针入库可复跑：`backend_async/scripts/frontend_rg_road_fixture.html` + `frontend_rg_road_probe.py`（留白值从 app.js 实文解析、不另存一份数字；含官方象限免疫 / `data-input` 收敛 / 长文案三组专项断言，`--baseline` 可出改前对照表）。
- 就绪判定用真实探针：postgres/redis 走 compose healthcheck，web 轮询 `GET /api/version`，worker 校验保持 Running。
- Docker 安装三级兜底（官方脚本可选 Aliyun 源 → 发行版仓库 → Compose 独立二进制），registry 加速经 python3 安全合并进已有 `daemon.json`。

## 备份 / 恢复 / 更新

`backup` 产物位于 `<安装目录>/backups/<时间戳>/`：`db.dump`（pg_dump -Fc）、`kgdata.tgz`、`acctdata.tgz`（web 账号卷）、`env.backup`、`deploy-state`、`meta.txt`。
`restore <目录>` 会先起 postgres 等 healthy、停全部写入方，再 `pg_restore --clean --if-exists`，随后原目录挪 `.old.<ts>` 后解包 kgdata、灌回账号卷，可选恢复当时 .env，最后整栈拉起并健康等待。
**自动轮转（部署脚本 1.1.0）**：每次 `backup` / `update` 成功后，完整备份与代码快照各只保留最近 7 份；`--keep N`（Windows 版 `-Keep N`）或环境变量 `MAXX_BACKUP_KEEP` 调整，`0` 表示不清理。只删本脚本自己生成、且能确认完整的条目（完整备份以 `meta.txt` 为准，缺它的不完整备份只告警、不自动删），刚生成的那份必定保留；每次备份后会打印备份目录当前占用。
`update` 先快照当前代码到 `backups/pre-update-*.tgz`，rsync 同步新代码时排除 `.env`、`.deploy-state`、`kgdata`（含用户自定义的树内相对路径）、`backups/` 与脚本自身；新版脚本若随包附带会存为 `*.new` 防覆盖运行中的自己。

## 故障排查速查

| 现象 | 处理 |
|---|---|
| 构建停在 `pip install`，报 `No matching distribution` | **看 `from versions:` 后面的列表分两种病因**（脚本会自动甄别）：① 列表为 `none` → 构建容器访问 PyPI 不通（大陆网络典型），脚本询问一键写入清华源重试；也可手动在 `.env` 加 `PIP_INDEX_URL=https://pypi.tuna.tsinghua.edu.cn/simple` 后执行 `rebuild`（该键经 compose 作为 build args 注入镜像构建）。② 列表**非空**（如 `from versions: 0.3, …, 1.2.0`）→ 索引应答正常，是 `requirements.txt` 钉了不存在的版本，换源无效；改钉版为 pypi.org 上真实存在的版本后 `rebuild` |
| 首次构建卡在 apt-get（安装 gosu/tzdata），从 deb.debian.org 拉取缓慢 | 大陆网络典型。在 `.env` 加 `APT_MIRROR=mirrors.aliyun.com` 后执行 `rebuild`（经 compose build args 注入，构建时自动改写镜像内 apt 源；误带 http(s):// 前缀会被自动归一）。该层已前置于代码层，日常改代码不会重跑它 |
| 抓取全 401 | 用的是示例/占位票据：配置 `accounts.json` 续期，或在管理后台、`env` 更新真票据 |
| 端口被占 | 向导会检测并建议换端口；启动前终检会拒绝与非本项目进程抢端口 |
| 小内存 OOM | 物理内存 <7.7 GB 时脚本已警告并要求确认；可先调低 compose 中 `shared_buffers`（2GB→1GB/512MB）再部署 |
| SELinux 拒写 kgdata | 脚本已自动 `chcon`；失败时按提示手动执行或临时 `setenforce 0` 验证 |
| Alpine 等无 systemd | openrc 路径已覆盖；`doctor` 输出足够定位其余发行版差异 |
| 任何疑难 | `sudo bash deploy-maxxiang.sh doctor`：版本/资源/SELinux/端口/各服务近 200 行错误摘录 |

## 测试套件

> 预测引擎侧另有两套仓内回归钉（不依赖 PG/Redis/真机 DB，可长期跑）：
> `backend_async/tests/test_anti_stubborn.py`（反固执）与
> `backend_async/tests/test_showcase_rotate.py`（冷位份额闭环，15 个钉：三方一致性 /
> 开关惰性 / 四风格惰性 / 连推硬帽硬不变量 / 份额收敛 / 状态往返向后兼容 / 指纹碰撞）。

两平台各一套函数级断言，位于 `deploy-tests/`：真实 zip 解压、.env 生成与回读（含 `$` 散列单引号保真、600 权限）、**向导交互全流程金测**（管道喂完整问答，覆盖票据/uid/白名单三处非法重输与口令双输）、harden 遗留明文转散列、seed 文件挂载翻译、scale 持久化、备份轮转（只留最近 N 份；不完整备份与非法保留值一律不删；bash 侧另有桩掉 Docker 的 `backup` 端到端用例）、端口探测、compose 版本判定、构建失败后的 PyPI 换源自愈黄金流等。Docker 相关调用以 stub 注入，只验证脚本自身逻辑；另有少数用例走真外部命令垫片，锁住「native 输出不得污染判码」这一不变量。

两套脚本默认到**自己所在目录**找被测主脚本（`deploy-tests/deploy-maxxiang.sh`），
而主脚本在仓库根，所以在本仓库里跑**必须用 `S=` 指过去**，否则全部用例报
`No such file or directory`：

```bash
# Linux（仓库根执行）；部分用例依赖项目源码与官方 zip，路径同样可覆盖
S=./deploy-maxxiang.sh PROJ=/path/to/maxxiang ZIP=/path/to/maxxiang.zip \
  bash deploy-tests/tests.sh

# Windows/跨平台（需 PowerShell 7）
$env:S='./deploy-maxxiang.ps1'; pwsh -File deploy-tests/tests.ps1
```

## 能力边界（诚实声明）

- Linux 脚本 shellcheck 零警告（仅保留动态 `source` 的 SC1090/1091 文件级豁免）；Windows 脚本 PSScriptAnalyzer Error/Warning 全清（仅豁免五条交互式 CLI 场景的风格规则）。
- 构建期 PyPI 换源链路（`.env` 的 `PIP_INDEX_URL` → compose build args → Dockerfile `ARG` + `pip install -i`）两平台均有黄金流用例覆盖：注入真实 pip 网络错误 → 自动写国内源 → 重试成功；已配源则不再重试。
- **未端到端实跑的一段**：开发环境无 Docker 守护进程，`up --build` 到健康等待的完整链路只做过静态与 stub 级验证（compose 调用形态、探针地址、健康判定逐项核对过）。目标机器首次执行如遇发行版特有问题，`doctor` 子命令的输出足够定位。

## 项目文档索引

部署脚本之外的系统文档：

| 文档 | 内容 |
|---|---|
| `SECURITY-NOTICE.md` | **凭据泄漏通告与必做处置**，部署前必读 |
| `backend_async/README.md` | 异步后端总纲：架构、目录、运行、配置、机器规格表、运维要点 |
| `LOGIN-SYSTEM.md` | 登录系统（MySQL 用户库鉴权 · 名录/账号按登录账号隔离） |
| `REGISTER-SYSTEM.md` | 注册系统（前端自助注册 · 防恶意注册纵深） |
| `SSO-LOGIN.md` | 链接快速登录（同库其它项目一键登进观测台） |
| `JFVIP-SYSTEM.md` | 九法 VIP 分层与收费（三档模型 · 充值卡密 · 管理台「值」视图） |
| `DATA-LIFECYCLE.md` | **数据生命周期（5.4.0）**：每张表、每族 Redis 键凭什么不会无限增长 —— 全表与键族登记 · 统一清扫引擎 · 管理台「储」视图 |
| `jiufa/README.md` | 九法降妖模拟游戏（浏览器内引擎） |
| `jiufa_data/kugou_login/README.md` | 酷狗多账号 Cookie 自动刷新（票据续期） |
| `window_audit/README.md` | 训练窗口裁决工具包（retention 攒够数据后跑） |
| `灵机推演天花板前沿方案.md` | **本次改造（4.8.0）**：实地核查结论、天花板定理、定稿刻度与已知代价 |

---
支持 Compose v2（缺失时自动安装，兜底二进制 v2.32.4）
