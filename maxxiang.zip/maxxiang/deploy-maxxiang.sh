#!/usr/bin/env bash
# shellcheck disable=SC1090,SC1091
# ══════════════════════════════════════════════════════════════════════════════
#  deploy-maxxiang.sh — 九法观测台（SpellTamer 观测台）交互式 Docker 部署脚本
# ──────────────────────────────────────────────────────────────────────────────
#  针对本项目实际编排（实地核查 backend_async/deploy/{Dockerfile,docker-compose.yml}
#  与 .env.example / web-entrypoint.sh / login-entrypoint.sh / app 源码后编写）：
#
#    栈组成 : postgres:16-alpine + redis:7-alpine
#             + worker(可横向扩副本) + web(:5173, FastAPI+前端SPA)
#             + login(酷狗 Cookie 自动续期) + seed(一次性注房, profile=tools)
#    健康点 : GET /api/version → {"ok":true,...}（web 就绪探针）
#    强约束 : compose 声明 `env_file: .env` —— .env 不存在则整栈无法启动；
#             容器内应用用户 uid=10001（kgdata 绑定目录属主需照顾）；
#             web 必须单 uvicorn worker（镜像 CMD 已钉死，勿改）。
#
#  支持发行版：Ubuntu / Debian / RHEL / CentOS(Stream) / Rocky / AlmaLinux /
#             Fedora / openEuler / Anolis / Alibaba Cloud Linux / openSUSE /
#             Arch / Alpine（其余 systemd 发行版尽力兼容，未覆盖时给出指引）。
#
#  用法：
#    sudo bash deploy-maxxiang.sh                 # 交互式安装（或已装则进管理菜单）
#    sudo bash deploy-maxxiang.sh install [选项]  # 显式安装/重配
#    sudo bash deploy-maxxiang.sh <子命令>        # 见 help
#
#  常用子命令：
#    status | logs [服务] [-f] | seed [房号.. | --file F | --list]
#    scale <N> | start | stop | restart | rebuild | accounts | admin-hash | admin-link
#    backup | restore <目录> | update | env | firewall | doctor | uninstall | menu
#
#  安装选项（非交互）：
#    -y|--yes                 全部采用默认值（配合下列选项使用）
#    --dir <路径>             安装目录（默认 /opt/maxxiang）
#    --source <URL|zip|目录>  项目来源（默认官方 zip；已在项目内运行时自动复用）
#    --port <P>               Web 端口（默认 5173）
#    --ticket <T> --uid <U>   酷狗 x-auth-ticket / uid
#    --pg-password <P>        PostgreSQL 密码（默认随机）
#    --admin-password <P>     启用管理后台并设口令；--admin-off 明确关闭
#    --admin-user <U>         后台登录账号（与口令成对写入 .env；不给则向导询问；填 off = 不设账号、只验口令）
#    --workers <N>            worker 副本数（默认 3；按需 ≈⌈总房数/4300⌉+1，硬顶 11）
#    --retention <天>         历史保留天数（默认 7；<=0 永久）
#    --discovery on|off       直播间自动发现（默认 on，随 config.yaml）
#    --registry-mirror <URL>  写入 Docker registry 镜像加速（可多次）
#    --pip-mirror <URL>       构建期 PyPI 源（容器内 pip 拉依赖走此源，如清华/阿里镜像）
#    --gh-proxy <前缀>        下载 GitHub 资产时的加速前缀（如 https://xx/）
#    --cn                     中国大陆网络优化预设（get.docker.com 走 Aliyun 源等）
#    --no-docker              跳过 Docker 自动安装（自行保证可用）
#    --keep <N>               backup / update 成功后，完整备份与代码快照各只留最近 N 份（默认 7；0 = 不清理）
#
#  环境变量同名覆盖：MAXX_DIR / MAXX_SOURCE / MAXX_PORT / MAXX_TICKET /
#    MAXX_UID / MAXX_PG_PASSWORD / MAXX_ADMIN_PASSWORD / MAXX_ADMIN_USER / MAXX_WORKERS /
#    MAXX_RETENTION / MAXX_REGISTRY_MIRROR / MAXX_GH_PROXY / MAXX_PIP_MIRROR / MAXX_BACKUP_KEEP
# ══════════════════════════════════════════════════════════════════════════════
set -Eeuo pipefail

# ── 全局常量 ──────────────────────────────────────────────────────────────────
readonly SCRIPT_VERSION="1.1.0"   # 1.1.0:backup / update 后自动轮转旧备份(--keep / MAXX_BACKUP_KEEP)
readonly BACKUP_KEEP_DEFAULT=7
SELF_PATH="$(readlink -f "${BASH_SOURCE[0]}" 2>/dev/null || echo "${BASH_SOURCE[0]}")"; readonly SELF_PATH
SELF_NAME="$(basename "$SELF_PATH")"; readonly SELF_NAME
readonly PROJECT_NAME="maxxiang"                       # COMPOSE_PROJECT_NAME（钉死，避免落成 "deploy"）
readonly DEFAULT_ZIP_URL="https://fxck-old-1256231079.cos.ap-guangzhou.myqcloud.com/maxxiang.zip"
readonly DEFAULT_INSTALL_DIR="/opt/maxxiang"
readonly COMPOSE_FALLBACK_VER="v2.32.4"                # 无包可装时的独立 compose 二进制兜底版本
readonly APP_UID=10001                                 # 镜像内 app 用户（Dockerfile: useradd -u 10001）
readonly WEB_HEALTH_PATH="/api/version"                # web.py 提供的就绪探针
POINTER_FILE="/etc/maxxiang-deploy.conf"; [ "$(id -u)" -eq 0 ] || POINTER_FILE="$HOME/.maxxiang-deploy.conf"

# ── 运行期变量 ────────────────────────────────────────────────────────────────
INSTALL_DIR=""; DEPLOY_DIR=""; STATE_FILE=""; ENV_FILE=""
COMPOSE=()                                             # (docker compose) 或 (docker-compose)
OS_ID=""; OS_LIKE=""; OS_PRETTY=""; PKG=""; ARCH=""; INIT_SYS=""
ASSUME_YES=0; CN_MODE=0; NO_DOCKER=0
OPT_SOURCE="${MAXX_SOURCE:-}"; OPT_PORT="${MAXX_PORT:-}"; OPT_TICKET="${MAXX_TICKET:-}"
OPT_KEEP="${MAXX_BACKUP_KEEP:-}"
OPT_UID="${MAXX_UID:-}"; OPT_PGPW="${MAXX_PG_PASSWORD:-}"; OPT_ADMIN_PW="${MAXX_ADMIN_PASSWORD:-}"; OPT_ADMIN_USER="${MAXX_ADMIN_USER:-}"
OPT_ADMIN_OFF=0; OPT_WORKERS="${MAXX_WORKERS:-}"; OPT_RETENTION="${MAXX_RETENTION:-}"
OPT_DISCOVERY=""; GH_PROXY="${MAXX_GH_PROXY:-}"
REGISTRY_MIRRORS=(); [ -n "${MAXX_REGISTRY_MIRROR:-}" ] && REGISTRY_MIRRORS+=("$MAXX_REGISTRY_MIRROR")
OPT_PIP_MIRROR="${MAXX_PIP_MIRROR:-}"
PYPI_CN_DEFAULT="https://pypi.tuna.tsinghua.edu.cn/simple"
# 持久化状态（写入 $STATE_FILE）
WORKER_REPLICAS=3; CFG_WEB_PORT=5173

# ── 输出 / 日志 ───────────────────────────────────────────────────────────────
LOG_FILE="/var/log/maxxiang-deploy.log"; [ -w /var/log ] 2>/dev/null || LOG_FILE="${TMPDIR:-/tmp}/maxxiang-deploy.log"
if [ -t 1 ]; then
  C_R=$'\033[31m'; C_G=$'\033[32m'; C_Y=$'\033[33m'; C_B=$'\033[34m'; C_C=$'\033[36m'; C_W=$'\033[1m'; C_0=$'\033[0m'
else
  C_R=""; C_G=""; C_Y=""; C_B=""; C_C=""; C_W=""; C_0=""
fi
_ts()  { date '+%F %T'; }
_log() { printf '%s %s\n' "$(_ts)" "$*" >>"$LOG_FILE" 2>/dev/null || true; }
say()  { printf '%s\n' "$*";                     _log "INFO  $*"; }
step() { printf '\n%s==>%s %s%s%s\n' "$C_B" "$C_0" "$C_W" "$*" "$C_0"; _log "STEP  $*"; }
ok()   { printf '%s ✔ %s%s\n' "$C_G" "$*" "$C_0"; _log "OK    $*"; }
warn() { printf '%s ⚠ %s%s\n' "$C_Y" "$*" "$C_0" >&2; _log "WARN  $*"; }
err()  { printf '%s ✘ %s%s\n' "$C_R" "$*" "$C_0" >&2; _log "ERR   $*"; }
die()  { err "$*"; err "详细日志：$LOG_FILE"; exit 1; }
on_err(){ local ec=$? ln=${1:-?}; err "第 ${ln} 行命令失败（退出码 $ec）：${BASH_COMMAND}"; err "详细日志：$LOG_FILE"; exit "$ec"; }
trap 'on_err $LINENO' ERR
trap 'echo; die "已被用户中断"' INT

run() { _log "RUN   $*"; "$@" >>"$LOG_FILE" 2>&1; }              # 静默执行，输出进日志
runv(){ _log "RUN   $*"; "$@" 2>&1 | tee -a "$LOG_FILE"; }        # 边执行边显示

have() { command -v "$1" >/dev/null 2>&1; }

# ── 交互原语（--yes 时自动取默认） ─────────────────────────────────────────────
confirm() { # confirm "问题" [Y|N默认]
  local q="$1" def="${2:-Y}" a
  if [ "$ASSUME_YES" -eq 1 ]; then [ "$def" = "Y" ]; return; fi
  while :; do
    read -rp "$(printf '%s%s%s [%s]: ' "$C_C" "$q" "$C_0" "$( [ "$def" = Y ] && echo Y/n || echo y/N )")" a || a=""
    a="${a:-$def}"
    case "$a" in [Yy]*) return 0;; [Nn]*) return 1;; esac
  done
}
ask() { # ask 变量名 "提示" "默认值"
  local __v="$1" p="$2" d="${3:-}" a
  if [ "$ASSUME_YES" -eq 1 ]; then printf -v "$__v" '%s' "$d"; return; fi
  read -rp "$(printf '%s%s%s%s: ' "$C_C" "$p" "$C_0" "${d:+ [$d]}")" a || a=""
  printf -v "$__v" '%s' "${a:-$d}"
}
ask_secret() { # ask_secret 变量名 "提示"（二次确认）
  local __v="$1" p="$2" a b
  while :; do
    read -rsp "$(printf '%s%s%s: ' "$C_C" "$p" "$C_0")" a || die "口令需要在交互终端输入（或以参数/选项提供）"
    echo
    read -rsp "$(printf '%s再次输入确认%s: ' "$C_C" "$C_0")" b || die "口令需要在交互终端输入（或以参数/选项提供）"
    echo
    [ "$a" = "$b" ] && [ -n "$a" ] && { printf -v "$__v" '%s' "$a"; return; }
    warn "两次输入不一致或为空，请重试"
  done
}
gen_pw() { # 定长读取再过滤，避免 pipefail 下 head 截断引发 SIGPIPE
  local n="${1:-20}" out=""
  while [ "${#out}" -lt "$n" ]; do
    out+="$(head -c 256 /dev/urandom | LC_ALL=C tr -dc 'A-Za-z0-9')"
  done
  printf '%s\n' "${out:0:$n}"
}

# ── 系统识别 ──────────────────────────────────────────────────────────────────
detect_os() {
  ARCH="$(uname -m)"
  case "$ARCH" in x86_64|amd64) ARCH=x86_64;; aarch64|arm64) ARCH=aarch64;;
    *) warn "架构 $ARCH 未经验证，继续尝试（Docker 官方仅正式支持 x86_64/aarch64 等）";; esac
  if [ -r /etc/os-release ]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    OS_ID="${ID:-unknown}"; OS_LIKE="${ID_LIKE:-}"; OS_PRETTY="${PRETTY_NAME:-$OS_ID}"
  else
    OS_ID="unknown"; OS_PRETTY="unknown"
  fi
  if have apt-get; then PKG=apt
  elif have dnf; then PKG=dnf
  elif have yum; then PKG=yum
  elif have zypper; then PKG=zypper
  elif have pacman; then PKG=pacman
  elif have apk; then PKG=apk
  else PKG=none; fi
  if [ -d /run/systemd/system ]; then INIT_SYS=systemd
  elif have rc-service; then INIT_SYS=openrc
  else INIT_SYS=other; fi
  say "系统：$OS_PRETTY（id=$OS_ID${OS_LIKE:+ like=$OS_LIKE}）| 架构：$ARCH | 包管理：$PKG | init：$INIT_SYS"
}

require_root() {
  [ "$(id -u)" -eq 0 ] && return 0
  if have sudo; then
    warn "本操作需要 root 权限，正在通过 sudo 重新执行…"
    exec sudo -E bash "$SELF_PATH" ${ORIG_ARGS[@]+"${ORIG_ARGS[@]}"}
  fi
  die "请以 root 身份运行（或安装 sudo）：sudo bash $SELF_NAME ..."
}

pkg_install() { # pkg_install 包名...
  [ "$PKG" = none ] && { warn "无已知包管理器，跳过自动安装：$*"; return 1; }
  step "安装依赖：$*"
  case "$PKG" in
    apt)    run apt-get update -y || true; run env DEBIAN_FRONTEND=noninteractive apt-get install -y "$@";;
    dnf)    run dnf install -y "$@";;
    yum)    run yum install -y "$@";;
    zypper) run zypper --non-interactive install --no-recommends "$@";;
    pacman) run pacman -Sy --noconfirm --needed "$@";;
    apk)    run apk add --no-cache "$@";;
  esac
}

ensure_base_tools() {
  local need=()
  have curl || have wget || need+=(curl)
  have tar  || need+=(tar)
  have unzip|| need+=(unzip)
  [ "${#need[@]}" -gt 0 ] && pkg_install "${need[@]}" || true
  have curl || have wget || die "curl/wget 均不可用且自动安装失败，请手动安装后重试"
  have unzip || have python3 || warn "缺少 unzip 且无 python3，若需从 zip 部署将失败"
}

fetch_url() { # fetch_url <url> <输出文件>
  local u="$1" o="$2"
  if have curl; then run curl -fSL --retry 3 --connect-timeout 15 -o "$o" "$u"
  else run wget -q --tries=3 --timeout=20 -O "$o" "$u"; fi
}

check_resources() {
  step "资源体检"
  local mem_kb mem_mb
  mem_kb=$(awk '/MemTotal/{print $2}' /proc/meminfo 2>/dev/null || echo 0); mem_mb=$((mem_kb/1024))
  if [ "$mem_mb" -gt 0 ] && [ "$mem_mb" -lt 7900 ]; then
    warn "内存仅 ${mem_mb}MB。compose 默认 PostgreSQL shared_buffers=2GB（为 ≥8G 内存机器设计），"
    warn "小内存机器有 OOM 风险；建议 ≥8GB，或部署前把 deploy/docker-compose.yml 中该值调回 1GB/512MB 并把 worker 副本调小。"
    confirm "仍要继续吗？" N || die "已取消"
  else ok "内存 ${mem_mb}MB"
  fi
  local free_docker free_dir
  free_docker=$(df -Pm /var/lib/docker 2>/dev/null | awk 'NR==2{print $4}' || echo "")
  [ -z "$free_docker" ] && free_docker=$(df -Pm / | awk 'NR==2{print $4}')
  free_dir=$(df -Pm "$(dirname "$INSTALL_DIR")" 2>/dev/null | awk 'NR==2{print $4}' || echo "$free_docker")
  if [ "${free_docker:-0}" -lt 5120 ]; then
    warn "Docker 数据盘可用 ${free_docker}MB（<5GB）：镜像构建含 pip 依赖，空间可能吃紧"
    confirm "仍要继续吗？" Y || die "已取消"
  else ok "Docker 数据盘可用 ${free_docker}MB；安装目录所在盘可用 ${free_dir}MB"
  fi
}

# ── 端口检测 ──────────────────────────────────────────────────────────────────
port_in_use() { # port_in_use <端口> → 0=占用
  local p="$1"
  if have ss;      then ss -Hlnt 2>/dev/null | awk '{print $4}' | grep -Eq "[:.]${p}\$" && return 0
  elif have netstat; then netstat -lnt 2>/dev/null | awk '{print $4}' | grep -Eq "[:.]${p}\$" && return 0
  fi
  (exec 3<>"/dev/tcp/127.0.0.1/$p") 2>/dev/null && { exec 3>&- 3<&-; return 0; }
  return 1
}

# ══════════════════════════════════════════════════════════════════════════════
#  Docker / Compose
# ══════════════════════════════════════════════════════════════════════════════
docker_daemon_ok() { docker info >/dev/null 2>&1; }

start_enable_docker() {
  case "$INIT_SYS" in
    systemd) run systemctl enable --now docker || run systemctl start docker || true;;
    openrc)  run rc-update add docker boot || true; run rc-service docker start || true;;
    *)       have service && run service docker start || true;;
  esac
  local _; for _ in $(seq 1 15); do docker_daemon_ok && { ok "Docker 守护进程已就绪"; return 0; }; sleep 1; done
  return 1
}

install_docker_get_script() {
  step "通过官方便捷脚本安装 Docker（get.docker.com）"
  local tmp mirror_arg=()
  tmp="$(mktemp)"
  fetch_url "https://get.docker.com" "$tmp" || return 1
  if [ "$CN_MODE" -eq 1 ]; then mirror_arg=(--mirror Aliyun); say "已启用 --mirror Aliyun（中国大陆加速）"
  elif confirm "使用中国大陆镜像源（Aliyun）安装 Docker？" N; then mirror_arg=(--mirror Aliyun); fi
  runv sh "$tmp" ${mirror_arg[@]+"${mirror_arg[@]}"} || { rm -f "$tmp"; return 1; }
  rm -f "$tmp"; return 0
}

install_docker_distro() {
  step "通过发行版仓库安装 Docker（便捷脚本不适用时的兜底）"
  case "$PKG" in
    apt)    pkg_install docker.io || return 1;;
    pacman) pkg_install docker || return 1;;
    zypper) pkg_install docker || return 1;;
    apk)    pkg_install docker docker-cli-compose || return 1;;
    dnf|yum)
      # openEuler / Anolis / Alibaba Cloud Linux 等自带 docker(-engine) 包
      pkg_install docker || pkg_install docker-engine || pkg_install moby-engine || return 1;;
    *) return 1;;
  esac
}

# ── BuildKit 版本地板预检(4.0.0)────────────────────────────────────────────
# fe-build 阶段用 `RUN --mount=type=cache` 做跨次构建的持久缓存(见
# backend_async/deploy/Dockerfile),这使既有的「BuildKit / Docker ≥20.10」
# 声明从注释变成硬性前提:旧引擎(如发行版仓库兜底装出的 18.x/19.x,
# openEuler/Debian10 实见)会在 #42 一步报晦涩的 Dockerfile 语法错。
# 本预检把它换成一次性、可执行的明确指引。容错设计:拿不到 Server 版本
# (守护未起 / 单元测试桩环境)一律放行 —— 后续步骤自带各自的清晰报错,
# 预检只在「确认过旧」时拦截,绝不制造新的误杀面。
ensure_buildkit_floor() {
  local v maj min
  v="$(docker version -f '{{.Server.Version}}' 2>/dev/null)" || return 0
  [ -n "$v" ] || return 0
  maj="${v%%.*}"; min="${v#*.}"; min="${min%%.*}"
  case "$maj" in ''|*[!0-9]*) return 0;; esac
  case "$min" in ''|*[!0-9]*) return 0;; esac
  if [ "$maj" -lt 20 ] || { [ "$maj" -eq 20 ] && [ "$min" -lt 10 ]; }; then
    die "Docker $v 过旧：前端混淆构建的持久缓存(Dockerfile fe-build 的 RUN --mount=type=cache)需 BuildKit / Docker ≥20.10。请先升级引擎（推荐官方脚本 https://get.docker.com；大陆机器可用本脚本 --cn 预设重装）后重试。"
  fi
  if [ "${DOCKER_BUILDKIT:-}" = "0" ]; then
    die "检测到环境变量 DOCKER_BUILDKIT=0：本项目 Dockerfile 依赖 BuildKit（RUN --mount 持久缓存、COPY --from 多阶段）。请执行 unset DOCKER_BUILDKIT 后重试。"
  fi
  return 0
}

ensure_docker() {
  step "检查 Docker"
  if have docker; then
    ok "已安装：$(docker --version 2>/dev/null || echo docker)"
  else
    [ "$NO_DOCKER" -eq 1 ] && die "未检测到 Docker，且指定了 --no-docker。请先自行安装。"
    confirm "未检测到 Docker，现在自动安装？" Y || die "Docker 是必需组件，已取消"
    install_docker_get_script || {
      warn "官方便捷脚本安装失败/不支持当前发行版，改用发行版仓库兜底"
      install_docker_distro || die "Docker 自动安装失败。请参照 https://docs.docker.com/engine/install/ 手动安装后重试"
    }
  fi
  docker_daemon_ok || start_enable_docker || die "Docker 守护进程无法启动（journalctl -u docker 查看原因）"
  # 提示把发起 sudo 的普通用户加进 docker 组（免 sudo 日常运维）
  if [ -n "${SUDO_USER:-}" ] && ! id -nG "$SUDO_USER" 2>/dev/null | grep -qw docker; then
    if confirm "把用户 $SUDO_USER 加入 docker 组（重新登录后免 sudo 使用 docker）？" Y; then
      run usermod -aG docker "$SUDO_USER" && ok "已加入，重新登录后生效"
    fi
  fi
  ensure_buildkit_floor   # 4.0.0：装好/已有引擎都过一遍版本地板（过旧 → 明确指路升级，而非 #42 处报晦涩语法错）
}

compose_ver_major() { # 输出 compose 主版本号（失败输出 0）
  local v
  v=$("${COMPOSE[@]}" version --short 2>/dev/null || true)
  v="${v#v}"; printf '%s' "${v%%.*}" | grep -E '^[0-9]+$' || printf '0'
}

install_compose_plugin_binary() {
  step "安装 Docker Compose v2（独立二进制兜底）"
  local dst_dir=/usr/local/lib/docker/cli-plugins dst arch_tag url
  case "$ARCH" in x86_64) arch_tag=x86_64;; aarch64) arch_tag=aarch64;; *) arch_tag="$ARCH";; esac
  url="https://github.com/docker/compose/releases/download/${COMPOSE_FALLBACK_VER}/docker-compose-linux-${arch_tag}"
  [ -n "$GH_PROXY" ] && url="${GH_PROXY%/}/$url" && say "经代理下载：$url"
  mkdir -p "$dst_dir"; dst="$dst_dir/docker-compose"
  fetch_url "$url" "$dst" || return 1
  chmod +x "$dst"; ln -sf "$dst" /usr/local/bin/docker-compose
  ok "已安装 compose ${COMPOSE_FALLBACK_VER} → $dst"
}

ensure_compose() {
  step "检查 Docker Compose（需 v2：项目 compose 文件用到 profiles / 健康依赖等特性）"
  if docker compose version >/dev/null 2>&1; then
    COMPOSE=(docker compose)
  elif have docker-compose; then
    COMPOSE=(docker-compose)
  else
    COMPOSE=(docker compose)
  fi
  if [ "$(compose_ver_major)" -lt 2 ]; then
    warn "未检测到可用的 Compose v2，尝试安装 docker-compose-plugin 包…"
    case "$PKG" in
      apt)     pkg_install docker-compose-plugin || pkg_install docker-compose-v2 || true;;
      dnf|yum) pkg_install docker-compose-plugin || true;;
      zypper)  pkg_install docker-compose || true;;
      pacman)  pkg_install docker-compose || true;;
      apk)     pkg_install docker-cli-compose || true;;
    esac
    if docker compose version >/dev/null 2>&1; then COMPOSE=(docker compose)
    elif have docker-compose; then COMPOSE=(docker-compose); fi
    if [ "$(compose_ver_major)" -lt 2 ]; then
      install_compose_plugin_binary || die "Compose v2 安装失败。可自行安装后重试（docker compose version 应输出 v2.x）"
      if docker compose version >/dev/null 2>&1; then COMPOSE=(docker compose); else COMPOSE=(docker-compose); fi
    fi
  fi
  ok "Compose：$("${COMPOSE[@]}" version --short 2>/dev/null || echo '?')（命令：${COMPOSE[*]}）"
}

configure_registry_mirror() {
  [ "${#REGISTRY_MIRRORS[@]}" -eq 0 ] || step "配置 Docker registry 镜像加速"
  if [ "${#REGISTRY_MIRRORS[@]}" -eq 0 ]; then
    [ "$ASSUME_YES" -eq 1 ] && return 0
    confirm "是否配置 registry 镜像加速（拉取 postgres/redis/python 基础镜像更快，中国大陆常需要）？" "$( [ "$CN_MODE" -eq 1 ] && echo Y || echo N )" || return 0
    local m; ask m "输入加速地址（形如 https://xxxx.mirror.aliyuncs.com，留空跳过）" ""
    [ -z "$m" ] && return 0
    REGISTRY_MIRRORS+=("$m")
  fi
  local dj=/etc/docker/daemon.json list="" m
  for m in "${REGISTRY_MIRRORS[@]}"; do list="${list:+$list, }\"$m\""; done
  mkdir -p /etc/docker
  if [ -s "$dj" ]; then
    if have python3; then
      cp -a "$dj" "$dj.bak.$(date +%s)"
      MIRRORS_JSON="[$list]" python3 - "$dj" <<'PYEOF'
import json,os,sys
p=sys.argv[1]; d=json.load(open(p))
d["registry-mirrors"]=json.loads(os.environ["MIRRORS_JSON"])
json.dump(d,open(p,"w"),indent=2,ensure_ascii=False)
PYEOF
    else
      warn "$dj 已存在且本机无 python3，无法安全合并；请手动加入 \"registry-mirrors\": [$list] 后重启 docker"
      return 0
    fi
  else
    printf '{\n  "registry-mirrors": [%s]\n}\n' "$list" >"$dj"
  fi
  case "$INIT_SYS" in
    systemd) run systemctl restart docker;;
    openrc)  run rc-service docker restart;;
    *)       have service && run service docker restart || true;;
  esac
  local _; for _ in $(seq 1 15); do docker_daemon_ok && break; sleep 1; done
  docker_daemon_ok && ok "镜像加速已写入 $dj 并重启生效" || die "写入镜像加速后 Docker 未能重启，请检查 $dj 语法"
}

# ══════════════════════════════════════════════════════════════════════════════
#  项目获取 / 定位
# ══════════════════════════════════════════════════════════════════════════════
verify_markers() { # verify_markers <目录> → 0=是本项目根
  local d="$1"
  [ -f "$d/backend_async/deploy/docker-compose.yml" ] &&
  [ -f "$d/backend_async/deploy/Dockerfile" ] &&
  [ -f "$d/jiufa_data/spell_tamer_monitor.py" ] &&
  [ -f "$d/index.html" ]
}

find_project_upward() { # 自某目录向上找项目根
  local d="$1" _
  for _ in 1 2 3 4 5; do
    verify_markers "$d" && { printf '%s' "$d"; return 0; }
    [ "$d" = "/" ] && break
    d="$(dirname "$d")"
  done
  return 1
}

extract_zip() { # extract_zip <zip> <目标目录>：兼容顶层多包一层 maxxiang/ 的布局
  local zip="$1" dst="$2" tmp
  tmp="$(mktemp -d)"
  if have unzip; then run unzip -q -o "$zip" -d "$tmp" || { rm -rf "$tmp"; die "解压失败：$zip"; }
  elif have python3; then run python3 -c "import zipfile,sys; zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])" "$zip" "$tmp" || { rm -rf "$tmp"; die "解压失败：$zip"; }
  else rm -rf "$tmp"; die "无 unzip/python3，无法解压 $zip"; fi
  local root="$tmp"
  if ! verify_markers "$root"; then
    local only
    only=$(find "$tmp" -mindepth 1 -maxdepth 1 -type d | head -n1 || true)
    [ -n "$only" ] && verify_markers "$only" && root="$only"
  fi
  verify_markers "$root" || { rm -rf "$tmp"; die "压缩包内容不符合本项目结构（缺少 backend_async/deploy 等标志文件）"; }
  mkdir -p "$dst"
  if have rsync; then run rsync -a "$root"/ "$dst"/
  else run cp -a "$root"/. "$dst"/; fi
  rm -rf "$tmp"
}

sync_source_dir() { # sync_source_dir <源目录> <目标目录>
  local src="$1" dst="$2"
  mkdir -p "$dst"
  if have rsync; then run rsync -a "$src"/ "$dst"/
  else run cp -a "$src"/. "$dst"/; fi
}

# 5.2.0:.env.example 已随 .env 搬进 backend_async/deploy/。解压/叠加复制都不会删旧文件,
# 旧位置会残留一份过期样例(两份并存极易看串)—— 新位置在时清掉旧的。
prune_stale_example() {
  if [ -f "$INSTALL_DIR/backend_async/deploy/.env.example" ] && [ -f "$INSTALL_DIR/backend_async/.env.example" ]; then
    rm -f "$INSTALL_DIR/backend_async/.env.example"
    ok "已清理旧位置的 backend_async/.env.example(样例现位于 backend_async/deploy/)"
  fi
}

acquire_project() {
  step "获取项目代码"
  # 1) 显式来源
  if [ -n "$OPT_SOURCE" ]; then
    if [ -d "$OPT_SOURCE" ]; then
      verify_markers "$OPT_SOURCE" || die "--source 目录不是本项目根：$OPT_SOURCE"
      [ "$(readlink -f "$OPT_SOURCE")" = "$(readlink -f "$INSTALL_DIR")" ] || sync_source_dir "$OPT_SOURCE" "$INSTALL_DIR"
    elif [ -f "$OPT_SOURCE" ]; then
      extract_zip "$OPT_SOURCE" "$INSTALL_DIR"
    else
      local z; z="$(mktemp)"
      say "下载：$OPT_SOURCE"
      fetch_url "$OPT_SOURCE" "$z" || die "下载失败：$OPT_SOURCE"
      extract_zip "$z" "$INSTALL_DIR"; rm -f "$z"
    fi
  # 2) 目标目录已是完整项目 → 原地复用
  elif verify_markers "$INSTALL_DIR"; then
    ok "检测到 $INSTALL_DIR 已包含项目代码，原地复用"
  # 3) 脚本自身位于项目内 / 当前目录在项目内 → 复用该项目到安装目录（或原地）
  else
    local near=""
    near="$(find_project_upward "$(dirname "$SELF_PATH")" 2>/dev/null || true)"
    [ -z "$near" ] && near="$(find_project_upward "$PWD" 2>/dev/null || true)"
    if [ -n "$near" ]; then
      say "在 $near 发现项目代码"
      if [ "$(readlink -f "$near")" = "$(readlink -f "$INSTALL_DIR")" ]; then
        ok "安装目录即项目目录，原地部署"
      elif confirm "复制到安装目录 $INSTALL_DIR 使用？（选 N 则直接在 $near 原地部署）" Y; then
        sync_source_dir "$near" "$INSTALL_DIR"
      else
        INSTALL_DIR="$near"
      fi
    else
      say "本地未发现项目，将从官方地址下载：$DEFAULT_ZIP_URL"
      local z; z="$(mktemp)"
      fetch_url "$DEFAULT_ZIP_URL" "$z" || die "下载失败，请检查网络或用 --source 指定本地 zip/目录"
      extract_zip "$z" "$INSTALL_DIR"; rm -f "$z"
    fi
  fi
  verify_markers "$INSTALL_DIR" || die "项目获取后校验失败：$INSTALL_DIR"
  prune_stale_example
  DEPLOY_DIR="$INSTALL_DIR/backend_async/deploy"
  ENV_FILE="$DEPLOY_DIR/.env"
  STATE_FILE="$DEPLOY_DIR/.deploy-state"
  ok "项目就绪：$INSTALL_DIR"
}

save_pointer() { printf 'INSTALL_DIR=%q\n' "$INSTALL_DIR" >"$POINTER_FILE" 2>/dev/null || true; }
load_state()  { [ -f "$STATE_FILE" ] && . "$STATE_FILE" || true; }
save_state()  {
  {
    printf '# 由 %s 维护，请勿手工编辑\n' "$SELF_NAME"
    printf 'WORKER_REPLICAS=%q\n' "$WORKER_REPLICAS"
    printf 'CFG_WEB_PORT=%q\n' "$CFG_WEB_PORT"
  } >"$STATE_FILE"
}

locate_existing_install() { # 用于非 install 子命令：定位既有部署
  if [ -n "${MAXX_DIR:-}" ] && verify_markers "$MAXX_DIR"; then INSTALL_DIR="$MAXX_DIR"
  elif [ -f "$POINTER_FILE" ]; then . "$POINTER_FILE"; fi
  if [ -z "$INSTALL_DIR" ] || ! verify_markers "$INSTALL_DIR"; then
    local near
    near="$(find_project_upward "$PWD" 2>/dev/null || true)"
    [ -z "$near" ] && near="$(find_project_upward "$(dirname "$SELF_PATH")" 2>/dev/null || true)"
    [ -z "$near" ] && [ -d "$DEFAULT_INSTALL_DIR" ] && verify_markers "$DEFAULT_INSTALL_DIR" && near="$DEFAULT_INSTALL_DIR"
    INSTALL_DIR="${near:-}"
  fi
  [ -n "$INSTALL_DIR" ] && verify_markers "$INSTALL_DIR" || die "未找到已部署的项目。请先执行：sudo bash $SELF_NAME install"
  DEPLOY_DIR="$INSTALL_DIR/backend_async/deploy"; ENV_FILE="$DEPLOY_DIR/.env"; STATE_FILE="$DEPLOY_DIR/.deploy-state"
  [ -f "$ENV_FILE" ] || die "缺少配置文件 $ENV_FILE（compose 依赖 env_file 强制存在）。请执行：sudo bash $SELF_NAME install"
  load_state
}

# compose 统一入口：cwd 钉在 deploy 目录 → compose 自动读取同目录 .env 做插值
dc() { ( cd "$DEPLOY_DIR" && "${COMPOSE[@]}" "$@" ); }
# ── PG 连接账本护栏(3.4.4;警告不拦截)────────────────────────────────────────
# 每 worker 副本连接池 ≈32,web 32,超管预留 3。默认 max_connections=400 →
# 硬顶 ⌊(400−35)/32⌋ = **11 副本**。超账本的真实后果(真机实证,16 副本现场):
# pool.acquire 无限期排队 → 任务「按时被领、执行中卡死」→ 出怪入库散布局内
# 41~70s、预测出现十几秒 null 空窗;而 Redis 到期积压恒 0,旧 health 看不见。
warn_pg_ledger(){
  local n="$1"
  [[ "$n" =~ ^[0-9]+$ ]] || return 0
  if [ "$n" -gt 11 ]; then
    warn "worker=$n 已超 PG 连接账本硬顶 11（默认 max_connections=400；$n×32+web 32+预留 3=$((n*32+35))）。"
    warn "  后果：任务在 PG 排队执行 → 出怪晚显示/预测长 null（Redis 积压却恒 0）。"
    warn "  请降副本（health.suggestReplicas 给实测值），或先调大 postgres 的 max_connections 再扩。"
  fi
}

dc_logged() {  # 输出镜像到部署日志；失败向上抛 compose 真退出码（避免 pipefail 下误报 tee 行）
  ( cd "$DEPLOY_DIR" || exit 1
    _log "RUN   (compose) $*"
    set +e
    "${COMPOSE[@]}" "$@" 2>&1 | tee -a "$LOG_FILE"
    exit "${PIPESTATUS[0]}" )
}

set_env_kv() {  # 追加或替换 .env 单键（裸值；调用方保证值安全）
  local k="$1" v="$2" tmp; tmp="$(mktemp)"
  grep -v "^${k}=" "$ENV_FILE" >"$tmp" || true
  printf '%s=%s\n' "$k" "$v" >>"$tmp"
  mv "$tmp" "$ENV_FILE"; chmod 600 "$ENV_FILE" 2>/dev/null || true
}

build_stack() {  # 构建并启动；失败时自动诊断（钉错版本 vs PyPI 网络不通），后者可一键换国内源重试一次
  local attempt="${1:-1}" rc=0
  ensure_buildkit_floor   # 4.0.0：rebuild/update 等全部构建路径同享版本地板预检（拿不到版本即放行，见函数注释）
  warn_pg_ledger "$WORKER_REPLICAS"
  dc_logged up -d --build --scale "worker=$WORKER_REPLICAS" || rc=$?
  [ "$rc" -eq 0 ] && return 0
  # 先甄别「requirements 钉错版本」：索引正常应答但该版本不存在时，pip 的
  # "Could not find a version …" 行会回显【非空】候选列表（from versions: 0.3, 0.4, …）；
  # 网络不通时该列表为 none。二者都伴随 "No matching distribution"，不能只看那一句。
  # 钉错版本换 PIP 源无济于事（任何镜像都不会有不存在的版本），直接指路改钉版。
  local badreq
  badreq="$(tail -n 300 "$LOG_FILE" \
              | grep -iE 'Could not find a version that satisfies the requirement' \
              | grep -ivE 'from versions:[[:space:]]*none' \
              | tail -n 1 | sed -E 's/.*requirement[[:space:]]+([^[:space:]]+).*/\1/' || true)"
  if [ -n "$badreq" ]; then
    err "构建失败诊断：requirements.txt 钉住了 PyPI 上不存在的版本（$badreq）——索引已正常应答并列出全部可选版本，属钉版错误而非网络问题，换 PIP 镜像源无济于事。"
    err "  修法：把 backend_async/requirements.txt 中该行改为真实存在的版本（pypi.org 可查）后执行 rebuild。"
    return "$rc"
  fi
  [ "$attempt" -ge 2 ] && return "$rc"
  if tail -n 300 "$LOG_FILE" | grep -qiE 'from versions:[[:space:]]*none|No matching distribution|Read timed out|Temporary failure in name resolution|Could not fetch URL .*pypi'; then
    warn "构建失败诊断：容器内访问 PyPI 超时/不通（典型于大陆网络）——非软件包版本问题（钉错版本的情形已在上一步单独识别）。"
    local cur; cur="$(env_get PIP_INDEX_URL 2>/dev/null || true)"
    if [ -n "$cur" ]; then
      err "当前已配置 PIP_INDEX_URL=$cur 仍失败：请检查该镜像可用性、DNS 或代理后重试。"
      return "$rc"
    fi
    local m="$PYPI_CN_DEFAULT"
    if confirm "写入国内 PyPI 镜像（$m）到 .env 并自动重试构建？" Y; then
      if [ "$ASSUME_YES" -ne 1 ]; then
        ask m "PyPI 源地址（可改阿里 https://mirrors.aliyun.com/pypi/simple/）" "$m"
        [[ "$m" =~ ^https?://[^[:space:]]+$ ]] || { warn "URL 无效，改用清华源"; m="$PYPI_CN_DEFAULT"; }
      fi
      set_env_kv PIP_INDEX_URL "$m"
      ok "已写入 .env：PIP_INDEX_URL=$m，重试构建…"
      build_stack 2; return $?
    fi
  fi
  return "$rc"
}

env_get() { # env_get KEY → 打印 .env 中的值(与 Docker Compose 的 .env 语法同口径)
  [ -f "$ENV_FILE" ] || return 1
  local line q
  line=$(grep -E "^${1}=" "$ENV_FILE" | tail -n1 || true)
  [ -n "$line" ] || return 1
  line="${line#*=}"
  line="${line#"${line%%[![:space:]]*}"}"           # 去前导空白
  # 5.2.0:与 Compose 同口径 —— 引号值取到配对的闭引号为止(其后的「# 注释」丢弃);
  # 未加引号的值,「空白 + #」起为行内注释(VAR=VAL # 注释 → VAL)。旧实现把注释一并
  # 当成值:`WEB_PORT=5173  # 端口` 会让健康检查去连「5173  # 端口」,而容器里拿到的却是 5173。
  q="${line:0:1}"
  if [ "$q" = "'" ] || [ "$q" = '"' ]; then
    line="${line:1}"; line="${line%%"$q"*}"
  else
    line="$(printf '%s' "$line" | sed -E 's/[[:space:]]+#.*$//; s/[[:space:]]+$//')"
  fi
  [ -n "$line" ] || return 1   # 空值行视同不存在:调用方一律走默认值回退
  printf '%s' "$line"
}

# ══════════════════════════════════════════════════════════════════════════════
#  配置向导 → 生成 backend_async/deploy/.env
#  （compose 声明 env_file: .env，本文件必须存在；同时被 compose 用于变量插值。
#    含 $ 的值一律单引号包裹，防止被 compose 插值阶段误解析。）
# ══════════════════════════════════════════════════════════════════════════════
V_PORT=5173; V_PGUSER=star; V_PGPW=""; V_PGDB=spelltamer
V_TICKET=""; V_UID=""; V_ADMIN_MODE=off; V_ADMIN_PW=""; V_ADMIN_ALLOW=""; V_ADMIN_USER=""
V_RETENTION=7; V_DISCOVERY=on; V_KGDIR="./kgdata"; V_LOGLEVEL=INFO; V_PIP_MIRROR=""

wizard() {
  step "部署配置向导（回车采用默认值）"

  # 端口
  local p="${OPT_PORT:-$CFG_WEB_PORT}"   # 3.6.0:单源到顶部默认,绝 workers 式双写漂移
  while :; do
    ask V_PORT "Web 服务对外端口" "$p"
    [[ "$V_PORT" =~ ^[0-9]+$ ]] && [ "$V_PORT" -ge 1 ] && [ "$V_PORT" -le 65535 ] || { warn "端口无效"; p=5173; continue; }
    if port_in_use "$V_PORT" && ! dc ps -q 2>/dev/null | grep -q .; then
      warn "端口 $V_PORT 已被占用"
      confirm "换一个端口？" Y && { p=$((V_PORT+1)); continue; }
    fi
    break
  done
  CFG_WEB_PORT="$V_PORT"

  # PostgreSQL 口令（仅限 A-Za-z0-9：该值会被 compose 插进 DSN，特殊字符会破坏 URL/插值）
  V_PGPW="${OPT_PGPW:-$(gen_pw 20)}"
  if [ "$ASSUME_YES" -ne 1 ] && [ -z "$OPT_PGPW" ]; then
    say "PostgreSQL 仅容器内网可达，已生成随机密码：$V_PGPW"
    confirm "使用该随机密码？（选 N 手动输入，限字母数字）" Y || {
      while :; do ask V_PGPW "输入 PostgreSQL 密码（仅字母数字）" ""
        [[ "$V_PGPW" =~ ^[A-Za-z0-9]{6,}$ ]] && break || warn "至少 6 位且仅限字母数字"; done
    }
  fi
  [[ "$V_PGPW" =~ ^[A-Za-z0-9]+$ ]] || die "PostgreSQL 密码只能包含字母数字（将拼入连接串）"

  # 酷狗票据（抓取上游必需；.env.example 里的示例票据会过期）
  say ""
  say "${C_W}关于酷狗票据${C_0}：抓取上游 mapi 需要 x-auth-ticket / x-auth-uid（浏览器登录酷狗/繁星后"
  say "从请求头复制）。票据约 30 天过期；本栈自带 login 服务可用账号密码自动续期"
  say "（部署完成后编辑 kgdata/accounts.json 并 restart login，详见部署总结）。"
  V_TICKET="${OPT_TICKET:-}"; V_UID="${OPT_UID:-}"
  if [ -z "$V_TICKET" ]; then
    while :; do
      ask V_TICKET "x-auth-ticket（可留空：先用仓库示例票据占位，靠 login 服务续期）" ""
      [ -z "$V_TICKET" ] && break
      [[ "$V_TICKET" =~ ^[0-9a-fA-F]{32,128}$ ]] && break
      warn "票据应为 32-128 位十六进制串（其他字符会破坏 .env 解析/插值），请重输或留空"
      V_TICKET=""
    done
  elif ! [[ "$V_TICKET" =~ ^[0-9a-fA-F]{32,128}$ ]]; then
    die "--ticket / MAXX_TICKET 应为 32-128 位十六进制串（当前值含非法字符，会破坏 .env）"
  fi
  if [ -n "$V_TICKET" ]; then
    while :; do
      ask V_UID "x-auth-uid（纯数字）" "${V_UID:-}"
      [[ "$V_UID" =~ ^[0-9]+$ ]] && break || warn "uid 应为纯数字"
    done
  else
    # 复用仓库示例占位（明确警告：会 401，需尽快经 login 服务续期或后台热更票据）
    V_TICKET="$(grep -E '^STA_AUTH_TICKET=' "$(env_example_file)" | head -n1 | cut -d= -f2- || true)"
    V_UID="$(grep -E '^STA_AUTH_UID=' "$(env_example_file)" | head -n1 | cut -d= -f2- || true)"
    V_TICKET="${V_TICKET%\'}"; V_TICKET="${V_TICKET#\'}"; V_TICKET="${V_TICKET%\"}"; V_TICKET="${V_TICKET#\"}"
    [[ "$V_TICKET" =~ ^[0-9a-fA-F]{32,128}$ ]] || V_TICKET="PUT_FRESH_TICKET_HERE"
    [[ "${V_UID:-}" =~ ^[0-9]+$ ]] || V_UID="0"
    V_TICKET="${V_TICKET:-PUT_FRESH_TICKET_HERE}"; V_UID="${V_UID:-0}"
    warn "未提供票据：先以示例票据占位（大概率已过期，抓取将 401），"
    warn "请部署后尽快：① 配置 kgdata/accounts.json 让 login 自动续期；或 ② 在管理后台或 .env 更新真票据。"
  fi

  # 管理后台（入口路径见 admin_cfg；口令暂以单引号明文写入 .env，部署成功后自动转 PBKDF2 散列；
  #   dotenv 单引号内不支持转义 → 口令禁止包含英文单引号）
  if [ "$OPT_ADMIN_OFF" -eq 1 ]; then V_ADMIN_MODE=off
  elif [ -n "$OPT_ADMIN_PW" ]; then
    case "$OPT_ADMIN_PW" in *"'"*) die "--admin-password 不能包含英文单引号";; esac
    V_ADMIN_MODE=on; V_ADMIN_PW="$OPT_ADMIN_PW"
    ask_admin_user "${OPT_ADMIN_USER:-$(env_get STA_ADMIN_USERNAME 2>/dev/null || true)}"
  elif confirm "启用管理后台（全参数热更/票据面板/账号库编辑）？不启用则相关接口一律 503" Y; then
    V_ADMIN_MODE=on
    if [ "$ASSUME_YES" -eq 1 ]; then V_ADMIN_PW="$(gen_pw 16)"; say "已生成后台口令：$V_ADMIN_PW（请立即记录）"
    else
      while :; do
        ask_secret V_ADMIN_PW "设置后台口令"
        case "$V_ADMIN_PW" in *"'"*) warn "口令不能包含英文单引号，请重设";; *) break;; esac
      done
    fi
    # 5.3.0:后台改为「账号 + 口令」—— 账号与口令成对写进 .env(重配时默认沿用旧 .env 里的账号)
    ask_admin_user "${OPT_ADMIN_USER:-$(env_get STA_ADMIN_USERNAME 2>/dev/null || true)}"
    while :; do
      ask V_ADMIN_ALLOW "可选：管理后台来源 IP 白名单（逗号分隔 CIDR，留空不限制，例 10.0.0.0/8,127.0.0.1/32)" ""
      [ -z "$V_ADMIN_ALLOW" ] && break
      [[ "$V_ADMIN_ALLOW" =~ ^[0-9a-fA-F:./,]+$ ]] && break
      warn "白名单只允许 IPv4/IPv6 CIDR 与逗号（当前含非法字符，会破坏 .env），请重输或留空"
    done
  fi

  # 数据保留 / 自动发现 / worker 副本
  ask V_RETENTION "每房历史保留天数（<=0 永久保留）" "${OPT_RETENTION:-$V_RETENTION}"
  [[ "$V_RETENTION" =~ ^-?[0-9]+$ ]] || V_RETENTION=7
  local disc_def="${OPT_DISCOVERY:-on}"
  case "$disc_def" in
    on|off) ;; true|1|yes) disc_def=on;; false|0|no) disc_def=off;;
    *) warn "--discovery 仅支持 on/off，按 on 处理"; disc_def=on;;
  esac
  if [ -n "$OPT_DISCOVERY" ] || [ "$ASSUME_YES" -eq 1 ]; then V_DISCOVERY="$disc_def"
  elif confirm "启用直播间自动发现（每分钟遍历繁星在播列表自动纳管，前端不显示这些房）？" Y; then V_DISCOVERY=on
  else V_DISCOVERY=off; fi

  local w="${OPT_WORKERS:-$WORKER_REPLICAS}"  # 3.6.0:单源到顶部默认(=3);ask() 在 --yes 下直接采用本默认,交互回车亦同 —— 此处即两条路径的实际生效值
  say ""
  # 构建期 PyPI 源（容器内 pip 拉依赖走此源；大陆网络强烈建议）
  V_PIP_MIRROR="$OPT_PIP_MIRROR"
  if [ -n "$V_PIP_MIRROR" ]; then
    [[ "$V_PIP_MIRROR" =~ ^https?://[^[:space:]]+$ ]] || die "--pip-mirror / MAXX_PIP_MIRROR 需为 http(s):// URL"
  elif [ "$ASSUME_YES" -eq 1 ]; then
    [ "${CN_MODE:-0}" -eq 1 ] && V_PIP_MIRROR="$PYPI_CN_DEFAULT"
  else
    local pdef=N; [ "${CN_MODE:-0}" -eq 1 ] && pdef=Y
    if confirm "配置构建期 PyPI 镜像源（镜像构建时 pip 从此源拉依赖；大陆网络建议开启，否则易在 pip install 阶段超时失败）？" "$pdef"; then
      while :; do
        ask V_PIP_MIRROR "PyPI 源地址（阿里可用 https://mirrors.aliyun.com/pypi/simple/）" "$PYPI_CN_DEFAULT"
        [[ "$V_PIP_MIRROR" =~ ^https?://[^[:space:]]+$ ]] && break
        warn "需为 http(s):// 开头的 URL"
      done
    fi
  fi

  say "worker 副本数：默认 3（≈8600 房容量；1 万房真机实测 = 每局 11.2ms CPU × 200 局/s = 2.2 核）；更大按 ≈⌈总监控房数/4300⌉+1 加副本，硬顶 11（README §5.1/§5.3）"
  ask WORKER_REPLICAS "worker 副本数" "$w"
  [[ "$WORKER_REPLICAS" =~ ^[0-9]+$ ]] && [ "$WORKER_REPLICAS" -ge 1 ] || WORKER_REPLICAS=3

  ask V_LOGLEVEL "日志级别（INFO/DEBUG/WARNING）" "INFO"
}

write_env_file() {
  step "生成 $ENV_FILE"
  if [ -f "$ENV_FILE" ]; then
    local bak; bak="$ENV_FILE.bak.$(date +%Y%m%d%H%M%S)"
    cp -a "$ENV_FILE" "$bak"; warn "已备份原有 .env → $bak"
  fi
  local admin_block
  case "$V_ADMIN_MODE" in
    on)  admin_block="STA_ADMIN_USERNAME=$V_ADMIN_USER
STA_ADMIN_PASSWORD='$V_ADMIN_PW'";;
    *)   admin_block="# 未启用管理后台（需要时设置 STA_ADMIN_PASSWORD 或 STA_ADMIN_PASSWORD_HASH 后 up -d）";;
  esac
  cat >"$ENV_FILE" <<EOF
# ── 由 $SELF_NAME v$SCRIPT_VERSION 生成于 $(_ts) ─────────────────────────────
# 本文件同时承担两职：compose 变量插值 + 注入容器环境(env_file)。
# 含 \$ 的值一律用单引号包裹（如 PBKDF2 散列）：单引号保证按字面读取，
# 双引号/裸值在不同 dotenv 解析路径下可能触发变量扩展或告警。

# 钉死 compose 项目名（否则默认取目录名 "deploy"，易与他项目冲突）
COMPOSE_PROJECT_NAME=$PROJECT_NAME

# ── 端口 / 数据目录（compose 插值用） ─────────────────────────────────────────
WEB_PORT=$V_PORT
KG_DATA_DIR=$V_KGDIR

# ── 构建期镜像源（可选；compose 作为 build args 注入镜像构建；大陆网络建议设置） ──
$( if [ -n "$V_PIP_MIRROR" ]; then echo "PIP_INDEX_URL=$V_PIP_MIRROR"; else printf '%s\n%s' '# PIP_INDEX_URL=https://pypi.tuna.tsinghua.edu.cn/simple' '# PIP_INDEX_URL=https://mirrors.aliyun.com/pypi/simple/'; fi )
# 构建期 APT 源（加速 gosu/tzdata 安装层；填主机名即可，启用时取消下行注释）
# APT_MIRROR=mirrors.aliyun.com
# 构建期 npm 源（加速前端混淆 fe-build 依赖层；启用时取消下行注释）
# NPM_REGISTRY=https://registry.npmmirror.com

# ── PostgreSQL（compose 据此拼 DSN 并建库；密码仅限字母数字） ──────────────────
POSTGRES_USER=$V_PGUSER
POSTGRES_PASSWORD=$V_PGPW
POSTGRES_DB=$V_PGDB

# ── 酷狗抓取票据（必需；login 服务续期成功后 worker 会热切换到新 Cookie） ───────
STA_AUTH_TICKET=$V_TICKET
STA_AUTH_UID=$V_UID
STA_AUTH_REFRESH_S=60

# ── 抓取端并发 / 连接池（沿用项目推荐值） ─────────────────────────────────────
STA_HTTP_CONN_LIMIT=500
STA_HTTP_CONN_PER_HOST=500
STA_WORKER_CONCURRENCY=800
STA_PG_POOL_MIN=4
STA_PG_POOL_MAX=32

# ── 数据保留 / 自动发现 / 日志 ────────────────────────────────────────────────
STA_RETENTION_DAYS=$V_RETENTION
STA_DISCOVERY_ENABLED=$( [ "$V_DISCOVERY" = on ] && echo true || echo false )
STA_LOG_LEVEL=$V_LOGLEVEL

# ── 管理后台（不设口令则后台整体 503；账号与口令成对，账号留空=只验口令） ──────
$admin_block
# 入口路径 / 人机验证档位默认取 backend_async/config.yaml 的 admin.path / admin.login_captcha；
# 写在这里可覆盖它（环境变量优先，且 update 升级不会覆盖本文件）：
# STA_ADMIN_PATH=admin-xdd
# STA_ADMIN_LOGIN_CAPTCHA=auto
$( [ -n "$V_ADMIN_ALLOW" ] && echo "STA_ADMIN_IP_ALLOW=$V_ADMIN_ALLOW" || echo "# STA_ADMIN_IP_ALLOW=10.0.0.0/8,127.0.0.1/32" )
# STA_ADMIN_SESSION_TTL_S=2592000
# STA_MONITOR_WRITE_TOKEN=

# ── login 服务（酷狗 Cookie 自动续期）节奏 ────────────────────────────────────
KG_REFRESH_DAYS=25
KG_RETRY_MINUTES=120
KG_CHECK_MINUTES=1
EOF
  chmod 600 "$ENV_FILE"
  ok ".env 已写入（权限 600）"
}

prepare_kgdata() {
  # login/worker/web 三方共享的绑定目录：容器内应用 uid=10001；预置属主避免首启竞态
  local d
  case "$V_KGDIR" in /*) d="$V_KGDIR";; *) d="$DEPLOY_DIR/${V_KGDIR#./}";; esac
  step "准备票据数据目录 $d（容器内路径 /kgdata）"
  mkdir -p "$d"
  chown -R "$APP_UID:$APP_UID" "$d" 2>/dev/null || warn "chown $APP_UID 失败（非 root？web 容器启动时会以 root 兜底 chown）"
  if have getenforce && [ "$(getenforce 2>/dev/null)" = "Enforcing" ]; then
    if chcon -Rt container_file_t "$d" 2>/dev/null; then
      ok "SELinux Enforcing：已为 $d 打 container_file_t 标签"
    else
      warn "SELinux Enforcing 且 chcon 失败：容器可能无法写 $d；可执行"
      warn "  chcon -Rt container_file_t '$d'  或临时 setenforce 0 验证"
    fi
  fi
}

# ══════════════════════════════════════════════════════════════════════════════
#  部署 / 健康等待
# ══════════════════════════════════════════════════════════════════════════════
preflight() {
  step "启动前预检"
  docker_daemon_ok || die "Docker 守护进程不可用"
  dc config -q || die "compose 配置校验失败（多为 .env 语法/插值问题），请检查 $ENV_FILE"
  ok "compose 配置校验通过"
}

health_of() { docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "$1" 2>/dev/null || echo "missing"; }

wait_stack() {
  step "等待各服务就绪"
  local deadline=$((SECONDS+180)) cid st
  for svc in postgres redis; do
    while :; do
      cid="$(dc ps -q "$svc" 2>/dev/null | head -n1 || true)"
      st="$( [ -n "$cid" ] && health_of "$cid" || echo starting )"
      [ "$st" = "healthy" ] && { ok "$svc healthy"; break; }
      [ $SECONDS -ge $deadline ] && { dc logs --tail 30 "$svc" || true; die "$svc 在 180s 内未达 healthy"; }
      sleep 2
    done
  done
  # web：以真实 HTTP 探针为准（/api/version）
  local url="http://127.0.0.1:${CFG_WEB_PORT}${WEB_HEALTH_PATH}"
  deadline=$((SECONDS+120))
  while :; do
    if have curl && curl -fsS --max-time 3 "$url" 2>/dev/null | grep -q '"ok"'; then ok "web 就绪：$url"; break; fi
    if ! have curl && (exec 3<>"/dev/tcp/127.0.0.1/$CFG_WEB_PORT") 2>/dev/null; then exec 3>&- 3<&-; ok "web 端口已开放"; break; fi
    [ $SECONDS -ge $deadline ] && { dc logs --tail 40 web || true; die "web 在 120s 内未就绪（$url）"; }
    sleep 2
  done
  # worker：容器保持 running 即视为启动成功（无内建 healthcheck）
  sleep 3
  cid="$(dc ps -q worker 2>/dev/null | head -n1 || true)"
  if [ -n "$cid" ] && [ "$(docker inspect -f '{{.State.Running}}' "$cid" 2>/dev/null)" = "true" ]; then
    ok "worker 运行中（副本 x$WORKER_REPLICAS）"
  else
    dc logs --tail 40 worker || true
    die "worker 未能保持运行，请查看上方日志"
  fi
  ok "login 服务将随栈常驻（首启会在 kgdata/ 生成 accounts.json 空库与示例）"
}

deploy_up() {
  step "构建镜像并启动整栈（首次构建需拉取基础镜像与 pip 依赖，可能耗时数分钟）"
  build_stack || die "构建/启动失败（诊断与完整日志见上方；可运行 doctor 体检，或在 .env 配置 PIP_INDEX_URL 后执行 rebuild 重试）"
  save_state
  wait_stack
}

# 部署后：把 .env 里的明文后台口令换成 PBKDF2 散列（调用镜像内官方工具，口径与后端一致）
harden_admin_password() {
  # 无论本次是新配还是复用旧 .env：只要存在明文口令行，就转为 PBKDF2 散列
  grep -q '^STA_ADMIN_PASSWORD=' "$ENV_FILE" || return 0
  local pw="${V_ADMIN_PW:-}"
  [ -n "$pw" ] || pw="$(env_get STA_ADMIN_PASSWORD 2>/dev/null || true)"
  [ -n "$pw" ] || return 0
  step "将后台口令升级为 PBKDF2 散列存储"
  local hash
  hash="$(dc run --rm --no-deps -T --entrypoint python worker -m app.admin_auth hash "$pw" 2>/dev/null | tr -d '\r' | tail -n1 || true)"
  if [[ "$hash" == pbkdf2_sha256\$* ]]; then
    env_set_admin_hash "$hash"
    dc up -d web >>"$LOG_FILE" 2>&1 || true
    ok "已写入散列并热重建 web；.env 中不再保留明文口令"
  else
    warn "散列生成失败，暂以明文形式保留在 .env（600 权限）。可稍后执行：$SELF_NAME admin-hash"
  fi
}

offer_firewall() {
  local p="$CFG_WEB_PORT"
  if have ufw && ufw status 2>/dev/null | grep -q "Status: active"; then
    confirm "检测到 ufw 已启用，放行 ${p}/tcp？" Y && run ufw allow "${p}/tcp" && ok "ufw 已放行 ${p}/tcp"
  elif have firewall-cmd && firewall-cmd --state >/dev/null 2>&1; then
    confirm "检测到 firewalld 运行中，放行 ${p}/tcp？" Y && {
      run firewall-cmd --permanent --add-port="${p}/tcp"; run firewall-cmd --reload; ok "firewalld 已放行 ${p}/tcp"; }
  fi
}

host_ips() {
  {
    have ip && ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 || true
    have hostname && hostname -I 2>/dev/null | tr ' ' '\n' || true
  } | grep -E '^[0-9]+\.' | sort -u || true
}

print_summary() {
  local kgdir_abs
  case "$V_KGDIR" in /*) kgdir_abs="$V_KGDIR";; *) kgdir_abs="$DEPLOY_DIR/${V_KGDIR#./}";; esac
  echo
  printf '%s══════════════════ 部署完成 ══════════════════%s\n' "$C_G" "$C_0"
  say "安装目录     ：$INSTALL_DIR"
  say "compose 项目 ：$PROJECT_NAME（deploy 目录：$DEPLOY_DIR）"
  say "观测台入口   ：http://127.0.0.1:${CFG_WEB_PORT}/"
  local ip; for ip in $(host_ips); do say "               http://${ip}:${CFG_WEB_PORT}/"; done
  if [ "$V_ADMIN_MODE" = on ]; then
    if [ -n "${V_ADMIN_PW:-}" ]; then say "管理后台     ：$(admin_url_hint)（口令即刚才所设）"
    else say "管理后台     ：$(admin_url_hint)（沿用原 .env 中的口令/散列）"; fi
    say "               登录账号见 deploy/.env 的 STA_ADMIN_USERNAME（与口令成对）；入口路径见 config.yaml 的 admin.path（.env 的 STA_ADMIN_PATH 可覆盖）"
    say "               人机验证服务不可用、进不了后台时：sudo bash $SELF_NAME admin-link（一次性应急登录链接）"
  else say "管理后台     ：未启用（需要时在 .env 设 STA_ADMIN_PASSWORD 后执行 '$SELF_NAME env' 应用）"; fi
  echo
  printf '%s—— 后续两步（重要）——%s\n' "$C_W" "$C_0"
  say "① 注入监控房间："
  say "     sudo bash $SELF_NAME seed 321 2678075"
  say "     sudo bash $SELF_NAME seed --file rooms.txt      # 每行一个，支持数千房"
  say "② 配置票据自动续期（强烈建议，票据约 30 天过期）："
  say "     编辑 $kgdir_abs/accounts.json（参照同目录 accounts.example.json 填酷狗账号），"
  say "     然后：sudo bash $SELF_NAME accounts   # 或 compose restart login"
  echo
  say "日常管理：sudo bash $SELF_NAME    （进入菜单：状态/日志/扩容/备份/更新/卸载…）"
  printf '%s═══════════════════════════════════════════════%s\n' "$C_G" "$C_0"
}

# ══════════════════════════════════════════════════════════════════════════════
#  日常管理子命令
# ══════════════════════════════════════════════════════════════════════════════
ensure_runtime() { # 管理命令的最小运行时（不做安装）
  have docker || die "未安装 Docker。请先执行：sudo bash $SELF_NAME install"
  docker_daemon_ok || die "Docker 守护进程未运行（systemctl start docker）"
  if docker compose version >/dev/null 2>&1; then COMPOSE=(docker compose)
  elif have docker-compose; then COMPOSE=(docker-compose)
  else die "缺少 Docker Compose v2。请先执行：sudo bash $SELF_NAME install"; fi
}

resolve_kgdir() {
  local k; k="$(env_get KG_DATA_DIR || echo ./kgdata)"
  case "$k" in /*) printf '%s' "$k";; *) printf '%s' "$DEPLOY_DIR/${k#./}";; esac
}

# 5.2.0:.env.example 随 .env 搬进 backend_async/deploy/;老安装目录(update 不删旧文件)回落旧位置
env_example_file() {
  local f="$INSTALL_DIR/backend_async/deploy/.env.example"
  [ -f "$f" ] || f="$INSTALL_DIR/backend_async/.env.example"
  printf '%s' "$f"
}

warn_if_sample_ticket() {
  local t ex
  t="$(env_get STA_AUTH_TICKET || true)"
  ex="$(grep -E '^STA_AUTH_TICKET=' "$(env_example_file)" 2>/dev/null | head -n1 | cut -d= -f2- || true)"
  if [ -n "$t" ] && { [ "$t" = "$ex" ] || [ "$t" = "PUT_FRESH_TICKET_HERE" ]; }; then
    warn "当前 .env 使用的是示例/占位票据，上游抓取会 401 —— 请配置 accounts.json 自动续期或更新真票据"
  fi
}

cmd_status() {
  step "服务状态（compose 项目：$PROJECT_NAME）"
  dc ps || true
  echo
  local cid st
  for svc in postgres redis web login; do
    cid="$(dc ps -q "$svc" 2>/dev/null | head -n1 || true)"
    st="$( [ -n "$cid" ] && health_of "$cid" || echo '未创建' )"
    printf '  %-8s : %s\n' "$svc" "$st"
  done
  printf '  %-8s : %s 个运行中（期望副本 %s）\n' "worker" "$(dc ps -q worker 2>/dev/null | wc -l | tr -d ' ')" "$WORKER_REPLICAS"
  local url="http://127.0.0.1:${CFG_WEB_PORT}${WEB_HEALTH_PATH}"
  if have curl; then
    echo; say "探针 $url ："
    curl -fsS --max-time 3 "$url" 2>/dev/null && echo || warn "web 探针未通过"
  fi
  echo; say "数据卷："
  docker volume ls --filter "label=com.docker.compose.project=$PROJECT_NAME" --format '  {{.Name}}' 2>/dev/null || true
  warn_if_sample_ticket
}

cmd_logs() { # cmd_logs [服务...] [-f]（其余参数透传 compose logs）
  local args=(--tail 120) follow=0 a
  for a in "$@"; do
    case "$a" in -f|--follow) follow=1;; *) args+=("$a");; esac
  done
  if [ "$follow" -eq 1 ]; then
    say "（Ctrl+C 退出日志跟随，不影响服务运行）"
    trap : INT                     # 跟随期间：SIGINT 只终止前台 compose logs
    dc logs -f "${args[@]}" || true
    trap 'echo; die "已被用户中断"' INT
  else
    dc logs "${args[@]}"
  fi
}

cmd_seed() {
  warn_if_sample_ticket
  if [ $# -eq 0 ]; then
    say "示例：直接输入房号（空格分隔，短号/靓号会自动归一），或输入文件路径（每行一个房号），"
    say "      直接回车 = 仅打印当前监控名录（--list）"
    local line; read -rp "$(printf '%s房号 / 文件路径%s: ' "$C_C" "$C_0")" line || line=""
    if [ -z "$line" ]; then set -- --list
    elif [ -f "$line" ]; then set -- --file "$line"
    else # shellcheck disable=SC2086
      set -- $line
    fi
  fi
  if [ "${1:-}" = "--file" ]; then
    local f="${2:?用法: seed --file <文件>}" abs
    # || true:父目录不存在时 readlink -f 返回 1,严格模式下会被 ERR 陷阱以笼统的「第 N 行命令失败」中止,
    # 走不到下面这句人话提示(复查实测)
    abs="$(readlink -f "$f" 2>/dev/null || true)"; [ -n "$abs" ] && [ -f "$abs" ] || die "文件不存在：$f"
    shift 2
    step "批量注入（经批量准入：去重 → 有界并发归一 → 落库 → 错峰起抓）"
    dc_logged run --rm -T -v "$abs:/tmp/rooms.seed:ro" seed --file /tmp/rooms.seed "$@"
  else
    step "注入房间：$*"
    dc_logged run --rm -T seed "$@"
  fi
}

cmd_scale() {
  local n="${1:-}"
  [ -z "$n" ] && ask n "worker 副本数（默认 3(≈8600 房容量;1 万房真机实测需 2.2 CPU 核);按需 ≈⌈总房数/4300⌉+1;PG 连接账本硬顶 11）" "$WORKER_REPLICAS"
  [[ "$n" =~ ^[0-9]+$ ]] && [ "$n" -ge 1 ] || die "副本数需为 ≥1 的整数"
  WORKER_REPLICAS="$n"; save_state
  step "调整 worker 副本 → $n（共享 Redis 延迟队列，自动负载均衡）"
  warn_pg_ledger "$n"
  dc_logged up -d --no-build --scale "worker=$n" worker
  ok "当前运行副本：$(dc ps -q worker | wc -l | tr -d ' ')"
}

cmd_start()   { step "启动整栈"; dc_logged up -d --scale "worker=$WORKER_REPLICAS"; wait_stack; }
cmd_stop()    { step "停止整栈（保留容器与数据）"; dc_logged stop; }
cmd_restart() { step "重启整栈"; dc_logged restart; wait_stack; }
cmd_rebuild() { step "重建镜像并滚动更新"; build_stack || die "重建失败（诊断见上；.env 可配 PIP_INDEX_URL 换构建源）"; wait_stack; }

cmd_accounts() {
  local kgdir acc ex_src
  kgdir="$(resolve_kgdir)"; acc="$kgdir/accounts.json"
  ex_src="$INSTALL_DIR/jiufa_data/kugou_login/accounts.example.json"
  mkdir -p "$kgdir"
  [ -f "$kgdir/accounts.example.json" ] || cp -a "$ex_src" "$kgdir/accounts.example.json" 2>/dev/null || true
  [ -f "$acc" ] || printf '{"accounts": []}\n' >"$acc"
  say "账号库：$acc（参照同目录 accounts.example.json；字段 username/password/mid，"
  say "        password 支持写成 'env:变量名' 从环境读取以避免明文；含明文时保持 600 权限）"
  if confirm "现在用 ${EDITOR:-vi} 打开编辑？" Y; then "${EDITOR:-vi}" "$acc"; fi
  chmod 600 "$acc" 2>/dev/null || true
  chown "$APP_UID:$APP_UID" "$acc" "$kgdir" 2>/dev/null || true
  if dc ps -q login 2>/dev/null | grep -q .; then
    step "重启 login 服务使账号立即生效"
    dc_logged restart login
    sleep 2; dc logs --tail 25 login || true
  else
    say "login 服务尚未运行，启动整栈后会自动读取该账号库"
  fi
}

# ── 管理后台登录账号（5.3.0）：与口令成对放 .env，问答 / 升级补齐 / 散列原位替换 ──────
valid_admin_user() { [[ "$1" =~ ^[A-Za-z0-9._@+-]{1,64}$ ]]; }   # 会进 .env：输入侧就拦住引号 / 空白 / $ / #
ask_admin_user() { # ask_admin_user [默认值] → 设置 V_ADMIN_USER（合法值或空）
  local d="${1:-}" v
  case "${d,,}" in off|none) d="";; esac
  if [ -n "$d" ] && ! valid_admin_user "$d"; then
    [ "$ASSUME_YES" -eq 1 ] && die "后台登录账号 '$d' 含非法字符（只允许字母/数字/. _ @ + -，1–64 位）"
    warn "预设账号 '$d' 含非法字符，已忽略"; d=""
  fi
  while :; do
    ask v "后台登录账号（与口令成对；填 off 表示不设账号）" "$d"
    case "${v,,}" in off|none) v="";; esac
    if [ -z "$v" ] || valid_admin_user "$v"; then V_ADMIN_USER="$v"; return 0; fi
    warn "账号只允许字母/数字/. _ @ + -（1–64 位），请重输；不设账号请填 off"
  done
}
env_insert_admin_user() { # 把 STA_ADMIN_USERNAME=<值> 插到口令行正上方（没有口令行则追加）
  local tmp; tmp="$(mktemp)"
  awk -v line="STA_ADMIN_USERNAME=$1" '
    !done && /^[[:space:]]*STA_ADMIN_PASSWORD(_HASH)?=/ { print line; done = 1 }
    { print }
    END { if (!done) print line }' "$ENV_FILE" >"$tmp" && cat "$tmp" >"$ENV_FILE"
  rm -f "$tmp"; chmod 600 "$ENV_FILE" 2>/dev/null || true
}
env_set_admin_hash() { # 口令行**原位**换成散列行（账号行紧挨在上面，不拆散这一对）；多余的口令行删掉
  local tmp; tmp="$(mktemp)"
  awk -v line="STA_ADMIN_PASSWORD_HASH='$1'" '
    /^[[:space:]]*STA_ADMIN_PASSWORD(_HASH)?=/ { if (!done) { print line; done = 1 }; next }
    { print }
    END { if (!done) print line }' "$ENV_FILE" >"$tmp" && cat "$tmp" >"$ENV_FILE"
  rm -f "$tmp"; chmod 600 "$ENV_FILE" 2>/dev/null || true
}
# 5.3.0 迁移：后台改为「账号 + 口令」后，账号只认 .env 的 STA_ADMIN_USERNAME；而 update 会保留服务器上的
# 旧 .env（那里没有这个键）—— 不补就会悄悄退回只验口令。只在「后台已启用 且 .env 里**根本没有**这个键」
# 时处理：键在（哪怕值为空）= 运维已明确决定，不再问。默认值：--admin-user > 新代码包自带 .env 里的账号
# （快照式打包会带上）。交互时可确认 / 修改；--yes 下有默认值就直接写入，没有就不写（下次交互再问）。
ensure_admin_username() { # ensure_admin_username [新代码包的 .env]
  local pkg="${1:-}" d="" saved
  [ -f "$ENV_FILE" ] || return 0
  [ -n "$(env_get STA_ADMIN_PASSWORD 2>/dev/null || true)$(env_get STA_ADMIN_PASSWORD_HASH 2>/dev/null || true)" ] || return 0
  grep -qE '^[[:space:]]*STA_ADMIN_USERNAME=' "$ENV_FILE" && return 0
  if [ -n "$pkg" ] && [ -f "$pkg" ]; then
    saved="$ENV_FILE"; ENV_FILE="$pkg"; d="$(env_get STA_ADMIN_USERNAME 2>/dev/null || true)"; ENV_FILE="$saved"
  fi
  [ -n "${OPT_ADMIN_USER:-}" ] && d="$OPT_ADMIN_USER"
  step "后台登录已改为「账号 + 口令」：补齐 .env 的 STA_ADMIN_USERNAME"
  ask_admin_user "$d"
  if [ -z "$V_ADMIN_USER" ] && [ "$ASSUME_YES" -eq 1 ]; then
    warn "未设置后台登录账号：后台继续只验口令（可用 --admin-user 指定，或在 .env 填 STA_ADMIN_USERNAME 后重启 web）"
    return 0
  fi
  env_insert_admin_user "$V_ADMIN_USER"
  if [ -n "$V_ADMIN_USER" ]; then ok "已写入后台登录账号：$V_ADMIN_USER（与口令相邻，位于 $ENV_FILE）"
  else warn "已记下「不设账号」：后台继续只验口令（之后可在 .env 填 STA_ADMIN_USERNAME 并重启 web）"; fi
}

# ── 管理后台入口 / 账号（5.3.0）────────────────────────────────────────────────
# 与后端 settings.py 同口径：
#   · path     ：.env 的 STA_ADMIN_PATH > config.yaml 的 admin.path > 默认（入口是访问拓扑，放文件里）
#   · username ：**只认 .env 的 STA_ADMIN_USERNAME**（账号是凭据，与口令同处 .env，不进 config.yaml）
# 入口只认单段（字母或数字开头，其后可含 - _，且不与静态挂载同名），否则回落默认 —— 与后端一致，
# 这里打印出来的地址才不会和 web 实际挂载的对不上。
admin_cfg() { # admin_cfg path|username
  local key="$1" v="" yml="$INSTALL_DIR/backend_async/config.yaml"
  if [ "$key" = username ]; then
    v="$(env_get STA_ADMIN_USERNAME 2>/dev/null || true)"
    case "${v,,}" in off|none) v="";; esac
    printf '%s' "$v"; return 0
  fi
  [ "$key" = path ] || return 1
  v="$(env_get STA_ADMIN_PATH 2>/dev/null || true)"
  if [ -z "$v" ] && [ -f "$yml" ]; then
    v="$(awk -v k="$key" '
      /^admin:[[:space:]]*(#.*)?$/ { blk = 1; next }
      blk && /^[^[:space:]#]/      { blk = 0 }
      blk && $0 ~ ("^[[:space:]]+" k ":") {
        sub("^[[:space:]]+" k ":[[:space:]]*", "")
        sub(/[[:space:]]+#.*$/, ""); sub(/[[:space:]]+$/, "")
        gsub(/^["\047]|["\047]$/, "")
        print; exit
      }' "$yml" 2>/dev/null || true)"
  fi
  v="${v#/}"; v="${v%/}"
  [[ "$v" =~ ^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$ ]] || v="admin-xdd"
  # 与后端 admin_auth._PATH_RESERVED 同一份清单(后端测试守着两边一致):顶层首段 + /api/ 下既有首段
  case "${v,,}" in account|active-room|api|assets|auth|cdn|crawler|discovery|docs|events|fx|game|icons|jiufa|live-rooms|mock|monitor|pow|redoc|rooms|static|version|vip) v="admin-xdd";; esac
  printf '%s' "$v"
}
admin_url_hint() { # 「后台地址（账号 …）」
  local u; u="$(admin_cfg username)"
  printf 'http://<host>:%s/%s' "$CFG_WEB_PORT" "$(admin_cfg path)"
  [ -z "$u" ] || printf '（账号 %s）' "$u"
}

# 应急登录：人机验证每次必过、验证服务不可达即拒绝 —— 这是不依赖第三方的那条进门路。
# 票据在 web 容器内签发（签名密钥取自容器环境），默认 10 分钟有效、只能用一次。
primary_ip() { # 默认路由的出口 IP；退而求其次取第一块非容器网桥（docker0 / br-* / veth*）的网卡地址。
  # 不用 host_ips 排序后的第一个：字典序会让 docker0 的 172.17.0.1 排在 47.x / 192.168.x 前面（复查实测）。
  local ip=""
  if have ip; then
    # 每条管道都 || true:脚本在 set -Eeuo pipefail 下运行,ip 返回非零会让整条赋值失败、整个脚本中止
    ip="$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{ for (i = 1; i < NF; i++) if ($i == "src") { print $(i + 1); exit } }' || true)"
    [ -n "$ip" ] || ip="$(ip -4 -o addr show scope global 2>/dev/null \
      | awk '$2 !~ /^(docker|br-|veth|virbr|cni|flannel)/ { split($4, a, "/"); print a[1]; exit }' || true)"
  fi
  [ -n "$ip" ] || ip="$(hostname -I 2>/dev/null | awk '{ print $1 }' || true)"
  printf '%s' "${ip:-127.0.0.1}"
}

cmd_admin_link() { # cmd_admin_link [分钟] [访问基址，如 https://你的域名]（顺序随意）
  local mins=10 base="" a out
  for a in "$@"; do
    case "$a" in
      "") ;;
      http://*|https://*) base="${a%/}";;
      *) [[ "$a" =~ ^[0-9]+$ ]] && mins="$a" || die "admin-link 参数无法识别：'$a'（用法：admin-link [分钟] [访问基址，如 https://你的域名]）";;
    esac
  done
  [ -n "$base" ] || base="http://$(primary_ip):${CFG_WEB_PORT}"
  step "在 web 容器内签发一次性应急登录链接（${mins} 分钟内有效）"
  out="$(dc exec -T web python -m app.admin_auth link --minutes "$mins" --base "$base" 2>/dev/null | tr -d '\r' | tail -n1 || true)"
  case "$out" in http*'#t='*) ;; *)
    out="$(dc run --rm --no-deps -T --entrypoint python web -m app.admin_auth link --minutes "$mins" --base "$base" 2>/dev/null | tr -d '\r' | tail -n1 || true)";;
  esac
  case "$out" in http*'#t='*) ;; *)
    die "签发失败：管理后台未启用（.env 未设 STA_ADMIN_PASSWORD / STA_ADMIN_PASSWORD_HASH），或镜像尚未构建（先执行 rebuild）";;
  esac
  ok "应急登录链接（只能使用一次；浏览器打开即进入后台，无需账号口令与人机验证）："
  printf '%s\n' "$out"
  say "若打不开，把主机部分换成你平时访问后台的域名 / 公网 IP（票据不绑定主机），或直接执行：$SELF_NAME admin-link https://你的域名"
  say "链接等同一次登录凭据，请勿外传。"
}

cmd_admin_hash() {
  local pw="${1:-}"
  [ -z "$pw" ] && ask_secret pw "输入新的后台口令"
  step "在镜像内生成 PBKDF2 散列（与后端 app.admin_auth 完全同口径）"
  local hash
  hash="$(dc run --rm --no-deps -T --entrypoint python worker -m app.admin_auth hash "$pw" 2>/dev/null | tr -d '\r' | tail -n1 || true)"
  [[ "$hash" == pbkdf2_sha256\$* ]] || die "散列生成失败（镜像未构建？先执行 rebuild）"
  env_set_admin_hash "$hash"
  dc_logged up -d web
  ok "后台口令已更新为散列存储并热重建 web"
}

# ── 备份轮转(1.1.0)──────────────────────────────────────────────────────────────
# backup 每次留一份完整导出(含保留期内全部历史,规模大时 GB 级),update 每次留一份代码
# 快照 —— 两者此前都只增不减,迟早写满磁盘。每次成功后各只留最近 N 份(--keep N /
# MAXX_BACKUP_KEEP,默认 7;0 = 不清理)。只碰本脚本自己生成、且能确认完整的条目:
#   · 完整备份:backups/<YYYYmmdd-HHMMSS>/ 且含 meta.txt(cmd_backup 的最后一步才写它);
#     缺 meta.txt 的不完整备份既不计数也不删除,只点名提示,由人决定;
#   · 代码快照:backups/pre-update-<YYYYmmdd-HHMMSS>-code.tgz(Windows 版为 .zip,一并识别)。
# 名字里的时间戳按字典序即时间序;刚生成的那份必在保留之列;保留份数非法时一律不删。
backup_keep() { printf '%s' "${OPT_KEEP:-$BACKUP_KEEP_DEFAULT}"; }

prune_backups() {  # prune_backups <backups 目录> <保留份数> <full|code>
  local dir="$1" keep="$2" kind="$3" p b
  case "$keep" in ''|*[!0-9]*) warn "备份保留份数无效：'$keep'（应为非负整数）—— 本次不清理旧备份"; return 0;; esac
  keep=$((10#$keep))
  { [ "$keep" -gt 0 ] && [ -d "$dir" ]; } || return 0
  local -a items=() partial=()
  if [ "$kind" = full ]; then
    for p in "$dir"/*/; do
      [ -d "$p" ] || continue
      b="$(basename "$p")"
      [[ "$b" =~ ^[0-9]{8}-[0-9]{6}$ ]] || continue
      if [ -f "$p/meta.txt" ]; then items+=("$b"); else partial+=("$b"); fi
    done
    if [ "${#partial[@]}" -gt 0 ]; then
      warn "发现不完整的备份（缺 meta.txt，未计入保留份数、也不会自动删除，请自行确认）：${partial[*]}"
    fi
  else
    for p in "$dir"/pre-update-*-code.tgz "$dir"/pre-update-*-code.zip; do
      [ -f "$p" ] || continue
      b="$(basename "$p")"
      if [[ "$b" =~ ^pre-update-[0-9]{8}-[0-9]{6}-code\.(tgz|zip)$ ]]; then items+=("$b"); fi   # 不写 && 链:循环末条非零在 set -E + ERR 陷阱下有歧义
    done
  fi
  [ "${#items[@]}" -gt "$keep" ] || return 0
  local -a old=()
  mapfile -t old < <(printf '%s\n' "${items[@]}" | sort -r | tail -n +"$((keep + 1))")
  for b in "${old[@]}"; do
    if rm -rf -- "${dir:?}/$b"; then say "  轮转：已删除旧备份 $b（只留最近 $keep 份）"
    else warn "删除旧备份失败：$b"; fi
  done
  return 0
}

cmd_backup() {
  local ts bk pguser pgdb kgdir
  ts="$(date +%Y%m%d-%H%M%S)"; bk="$INSTALL_DIR/backups/$ts"; mkdir -p "$bk"
  pguser="$(env_get POSTGRES_USER || echo star)"; pgdb="$(env_get POSTGRES_DB || echo spelltamer)"
  kgdir="$(resolve_kgdir)"
  step "备份 → $bk"
  local cid; cid="$(dc ps -q postgres 2>/dev/null | head -n1 || true)"
  [ -n "$cid" ] && [ "$(docker inspect -f '{{.State.Running}}' "$cid")" = "true" ] \
    || die "postgres 未运行，无法导出数据库（先执行：$SELF_NAME start）"
  say "① PostgreSQL（pg_dump 自定义格式，支持 --clean 恢复）"
  dc exec -T postgres pg_dump -Fc -U "$pguser" -d "$pgdb" >"$bk/db.dump"
  say "② 票据数据目录 kgdata（cookie/账号库/刷新状态）"
  tar -C "$kgdir" -czf "$bk/kgdata.tgz" . 2>>"$LOG_FILE" || warn "kgdata 打包告警（目录可能为空）"
  say "③ web 账号库卷 acctdata（/data/accounts.json）"
  dc run --rm -T --no-deps --entrypoint tar web czf - -C /data . >"$bk/acctdata.tgz" 2>>"$LOG_FILE" \
    || warn "acctdata 卷导出失败（可能尚无数据）"
  say "④ 配置文件"
  cp -a "$ENV_FILE" "$bk/env.backup"; chmod 600 "$bk/env.backup"
  [ -f "$STATE_FILE" ] && cp -a "$STATE_FILE" "$bk/deploy-state"
  {
    echo "time=$ts"; echo "script=$SCRIPT_VERSION"
    echo "compose=$("${COMPOSE[@]}" version --short 2>/dev/null || true)"
    echo "pg=$(dc exec -T postgres postgres --version 2>/dev/null | head -n1 || true)"
  } >"$bk/meta.txt"
  ok "备份完成：$bk"
  prune_backups "$INSTALL_DIR/backups" "$(backup_keep)" full
  say "备份目录当前占用：$(du -sh "$INSTALL_DIR/backups" 2>/dev/null | cut -f1 || true)（--keep N 调整保留份数）"
  say "恢复：sudo bash $SELF_NAME restore '$bk'"
}

cmd_restore() {
  local bk="${1:-}"
  [ -z "$bk" ] && {
    say "可用备份："; ls -1dt "$INSTALL_DIR"/backups/*/ 2>/dev/null | sed 's/^/  /' || say "  （无）"
    ask bk "输入要恢复的备份目录" ""; }
  bk="${bk%/}"
  [ -f "$bk/db.dump" ] || die "备份目录无效（缺少 db.dump）：$bk"
  warn "恢复将【覆盖】数据库全部内容，并替换 kgdata / 账号库（如备份中存在）"
  confirm "确认继续恢复？" N || { warn "已取消"; return 0; }
  local pguser pgdb kgdir
  pguser="$(env_get POSTGRES_USER || echo star)"; pgdb="$(env_get POSTGRES_DB || echo spelltamer)"
  kgdir="$(resolve_kgdir)"
  step "① 启动 postgres 并停止写入方（worker/web/login）"
  dc_logged up -d postgres
  local cid deadline=$((SECONDS+120))
  while :; do cid="$(dc ps -q postgres | head -n1)"; [ -n "$cid" ] && [ "$(health_of "$cid")" = healthy ] && break
    [ $SECONDS -ge $deadline ] && die "postgres 未就绪"; sleep 2; done
  dc stop worker web login >>"$LOG_FILE" 2>&1 || true
  step "② 恢复数据库（pg_restore --clean --if-exists）"
  dc exec -T postgres pg_restore -U "$pguser" -d "$pgdb" --clean --if-exists <"$bk/db.dump" \
    || warn "pg_restore 报告了非致命告警（向空库恢复时的 DROP 提示可忽略），详见 $LOG_FILE"
  if [ -f "$bk/kgdata.tgz" ]; then
    step "③ 恢复 kgdata → $kgdir"
    [ -d "$kgdir" ] && mv "$kgdir" "${kgdir}.old.$(date +%s)" || true
    mkdir -p "$kgdir"; tar -C "$kgdir" -xzf "$bk/kgdata.tgz"
    chown -R "$APP_UID:$APP_UID" "$kgdir" 2>/dev/null || true
    have getenforce && [ "$(getenforce 2>/dev/null)" = Enforcing ] && chcon -Rt container_file_t "$kgdir" 2>/dev/null || true
  fi
  if [ -f "$bk/acctdata.tgz" ]; then
    step "④ 恢复 web 账号库卷"
    dc run --rm -T --no-deps --entrypoint sh web -c 'rm -rf /data/* 2>/dev/null; tar xzf - -C /data && chown -R app:app /data' \
      <"$bk/acctdata.tgz" >>"$LOG_FILE" 2>&1 || warn "acctdata 卷恢复失败"
  fi
  if [ -f "$bk/env.backup" ] && confirm "同时恢复当时的 .env 配置？" N; then
    cp -a "$ENV_FILE" "$ENV_FILE.pre-restore.$(date +%s)" 2>/dev/null || true
    cp -a "$bk/env.backup" "$ENV_FILE"; chmod 600 "$ENV_FILE"
    CFG_WEB_PORT="$(env_get WEB_PORT || echo "$CFG_WEB_PORT")"
  fi
  step "⑤ 重新拉起整栈"
  dc_logged up -d --scale "worker=$WORKER_REPLICAS"
  wait_stack
  ok "恢复完成"
}

cmd_update() {
  local src="${OPT_SOURCE:-$DEFAULT_ZIP_URL}" ts tmp root
  warn "更新会用新代码覆盖 $INSTALL_DIR（保留 .env / kgdata / 备份 / 部署状态），随后重建镜像"
  confirm "从 '$src' 更新？" Y || { warn "已取消"; return 0; }
  ts="$(date +%Y%m%d-%H%M%S)"; mkdir -p "$INSTALL_DIR/backups"
  step "① 快照当前代码 → backups/pre-update-$ts-code.tgz"
  tar -C "$INSTALL_DIR" -czf "$INSTALL_DIR/backups/pre-update-$ts-code.tgz" \
      --exclude=./backups --exclude=./backend_async/deploy/kgdata \
      --exclude=./backend_async/deploy/.env --exclude='./backend_async/deploy/.env.bak.*' \
      --exclude='./backend_async/deploy/.env.pre-restore.*' \
      --exclude=./backend_async/deploy/.deploy-state . 2>>"$LOG_FILE" || true
  step "② 获取新代码"
  tmp="$(mktemp -d)"
  if [ -d "$src" ]; then verify_markers "$src" || die "--source 目录无效"; root="$src"
  else
    local z="$tmp/src.zip"
    if [ -f "$src" ]; then cp -a "$src" "$z"; else fetch_url "$src" "$z" || die "下载失败：$src"; fi
    extract_zip "$z" "$tmp/extract"; root="$tmp/extract"
  fi
  step "③ 同步到安装目录（保留本地配置与数据）"
  local kg_rel; kg_rel="$(env_get KG_DATA_DIR 2>/dev/null || echo ./kgdata)"
  local kg_ex="/backend_async/deploy/kgdata/"
  case "$kg_rel" in /*) ;; *) kg_ex="/backend_async/deploy/${kg_rel#./}/";; esac
  if have rsync; then
    run rsync -a --delete \
      --exclude '/backups/' \
      --exclude "$kg_ex" \
      --exclude '/backend_async/deploy/.env' --exclude '/backend_async/deploy/.env.bak.*' \
      --exclude '/backend_async/deploy/.env.pre-restore.*' \
      --exclude '/backend_async/deploy/.deploy-state' \
      --exclude '/backend_async/deploy/kgdata/' \
      --exclude "/$SELF_NAME" \
      "$root"/ "$INSTALL_DIR"/
  else
    warn "无 rsync：改用叠加复制（不删除旧文件）；建议安装 rsync 获得干净同步"
    # 与上面 rsync 分支**同一套排除**:此前这里是不带排除的 cp -a,代码包若带着 .env / 部署状态 /
    # 票据账号库(快照式打包就会带),会把服务器上的同名文件整个覆盖 —— 与「保留本地配置」的承诺相反。
    ( cd "$root" && tar -cf - \
        --exclude=./backups --exclude=".${kg_ex%/}" \
        --exclude=./backend_async/deploy/.env --exclude='./backend_async/deploy/.env.bak.*' \
        --exclude='./backend_async/deploy/.env.pre-restore.*' \
        --exclude=./backend_async/deploy/.deploy-state --exclude=./backend_async/deploy/kgdata \
        --exclude="./$SELF_NAME" . ) | tar -C "$INSTALL_DIR" -xpf - \
      || die "叠加复制失败，请用 backups/pre-update-$ts-code.tgz 回滚"
  fi
  prune_stale_example
  # 5.3.0 迁移:上面保留了服务器的旧 .env —— 那里还没有登录账号这个键,不补就会悄悄退回只验口令
  ensure_admin_username "$root/backend_async/deploy/.env"
  # 若脚本自身位于安装目录内，把新版本放到 .new，避免覆盖运行中的自己
  if [ -f "$root/$SELF_NAME" ] && [ "$(readlink -f "$INSTALL_DIR/$SELF_NAME" 2>/dev/null)" = "$SELF_PATH" ]; then
    cp -a "$root/$SELF_NAME" "$INSTALL_DIR/$SELF_NAME.new" 2>/dev/null || true
    warn "新版部署脚本已存为 $SELF_NAME.new（本次运行结束后可自行替换）"
  fi
  rm -rf "$tmp"
  verify_markers "$INSTALL_DIR" || die "更新后项目结构校验失败，请用 backups/pre-update-$ts-code.tgz 回滚"
  step "④ 重建并滚动更新"
  build_stack || die "更新后重建失败（诊断见上；.env 可配 PIP_INDEX_URL 换构建源）"
  wait_stack
  ok "更新完成"
  prune_backups "$INSTALL_DIR/backups" "$(backup_keep)" code
}

cmd_env() {
  cp -a "$ENV_FILE" "$ENV_FILE.bak.$(date +%s)"
  "${EDITOR:-vi}" "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  dc config -q || die ".env 修改后 compose 校验失败，请修正（备份在同目录 .bak.*）"
  CFG_WEB_PORT="$(env_get WEB_PORT || echo "$CFG_WEB_PORT")"; save_state
  if confirm "应用配置（up -d，仅重建受影响的容器）？" Y; then
    dc_logged up -d --scale "worker=$WORKER_REPLICAS"
    wait_stack
  fi
}

cmd_doctor() {
  step "环境体检"
  detect_os
  say "Docker  ：$(docker --version 2>/dev/null || echo 未安装)"
  say "Compose ：$("${COMPOSE[@]}" version --short 2>/dev/null || echo 未安装)（${COMPOSE[*]:-?}）"
  say "内存    ：$(awk '/MemTotal/{printf "%.1f GB", $2/1048576}' /proc/meminfo 2>/dev/null || echo ?)"
  say "磁盘    ：/var/lib/docker 可用 $(df -Ph /var/lib/docker 2>/dev/null | awk 'NR==2{print $4}' || df -Ph / | awk 'NR==2{print $4}')"
  have getenforce && say "SELinux ：$(getenforce 2>/dev/null)"
  say "端口    ：$CFG_WEB_PORT $(port_in_use "$CFG_WEB_PORT" && echo 已监听 || echo 未监听)"
  echo; cmd_status || true
  echo; step "近期错误摘录（各服务最近 200 行）"
  dc logs --tail 200 2>/dev/null | grep -iE 'error|traceback|401|403|refused|denied' | tail -n 20 || say "（未发现明显错误行）"
  echo; docker system df 2>/dev/null || true
}

cmd_uninstall() {
  warn "即将卸载 compose 项目 '$PROJECT_NAME'（目录：$INSTALL_DIR）"
  confirm "确认停止并移除全部容器？" N || { warn "已取消"; return 0; }
  local flags=()
  if confirm "同时删除数据卷（PostgreSQL 历史数据 + 已登录账号库将【永久丢失】）？" N; then flags+=(--volumes); fi
  if confirm "同时删除本项目构建的镜像？" Y; then flags+=(--rmi local); fi
  dc_logged down ${flags[@]+"${flags[@]}"}
  local fl="${flags[*]:-}"
  ok "容器/网络已移除${fl:+（含 $fl）}"
  if confirm "删除安装目录 $INSTALL_DIR ？" N; then
    if [ -d "$INSTALL_DIR/backups" ] && [ -n "$(ls -A "$INSTALL_DIR/backups" 2>/dev/null)" ] \
       && confirm "保留 backups/ 目录（移动到 ${INSTALL_DIR}-backups）？" Y; then
      mv "$INSTALL_DIR/backups" "${INSTALL_DIR}-backups"
    fi
    rm -rf "$INSTALL_DIR"
    ok "安装目录已删除"
  fi
  rm -f "$POINTER_FILE" 2>/dev/null || true
  say "如需彻底清理 Docker 层缓存：docker builder prune"
}

# ══════════════════════════════════════════════════════════════════════════════
#  安装主流程 / 菜单 / 入口
# ══════════════════════════════════════════════════════════════════════════════
cmd_install() {
  step "九法观测台 · Docker 部署（脚本 v$SCRIPT_VERSION）"
  require_root
  detect_os
  ensure_base_tools
  if [ "$NO_DOCKER" -eq 1 ]; then
    have docker && docker_daemon_ok || die "--no-docker 模式下需自行保证 Docker 已安装并运行"
    ensure_compose
  else
    ensure_docker
    ensure_compose
  fi
  configure_registry_mirror

  # 安装目录
  if [ -z "$INSTALL_DIR" ]; then
    local def="$DEFAULT_INSTALL_DIR"
    [ -f "$POINTER_FILE" ] && . "$POINTER_FILE" 2>/dev/null && [ -n "${INSTALL_DIR:-}" ] && def="$INSTALL_DIR"
    INSTALL_DIR=""
    ask INSTALL_DIR "安装目录" "$def"
  fi
  INSTALL_DIR="${INSTALL_DIR%/}"
  acquire_project
  check_resources
  load_state

  # 既有配置：可直接复用
  local reuse_env=0
  if [ -f "$ENV_FILE" ]; then
    say "检测到既有配置：$ENV_FILE"
    if confirm "复用现有 .env 直接部署（选 N 则重新走配置向导并覆盖）？" Y; then reuse_env=1; fi
  fi
  if [ "$reuse_env" -eq 1 ]; then
    CFG_WEB_PORT="$(env_get WEB_PORT || echo 5173)"
    V_KGDIR="$(env_get KG_DATA_DIR || echo ./kgdata)"
    if [ -n "$(env_get STA_ADMIN_PASSWORD 2>/dev/null || true)" ] || [ -n "$(env_get STA_ADMIN_PASSWORD_HASH 2>/dev/null || true)" ]; then
      V_ADMIN_MODE=on
      ensure_admin_username
    else
      V_ADMIN_MODE=off
    fi
  else
    # 向导默认值预填自旧配置（若有）
    OPT_PORT="${OPT_PORT:-$(env_get WEB_PORT 2>/dev/null || true)}"
    OPT_RETENTION="${OPT_RETENTION:-$(env_get STA_RETENTION_DAYS 2>/dev/null || true)}"
    [ -z "$OPT_UID" ] && OPT_UID="$(env_get STA_AUTH_UID 2>/dev/null || true)"
    wizard
    write_env_file
  fi

  prepare_kgdata
  # 端口冲突终检：被占用且占用者不是本项目 web → 拒绝启动
  if port_in_use "$CFG_WEB_PORT"; then
    local wcid; wcid="$(dc ps -q web 2>/dev/null | head -n1 || true)"
    [ -n "$wcid" ] || die "端口 $CFG_WEB_PORT 已被其他进程占用；换端口后重试（修改 .env 的 WEB_PORT）"
  fi
  preflight
  deploy_up
  harden_admin_password
  offer_firewall
  save_pointer
  save_state
  print_summary
  if [ "$ASSUME_YES" -ne 1 ] && confirm "现在就注入要监控的房间吗？" Y; then cmd_seed; fi
}

menu() {
  while :; do
    echo
    printf '%s┌─────────── 九法观测台 · 管理菜单（%s）───────────┐%s\n' "$C_W" "$INSTALL_DIR" "$C_0"
    cat <<'MENU'
  1) 状态总览            2) 查看日志           3) 注入监控房间(seed)
  4) 调整 worker 副本    5) 票据账号续期设置    6) 重启整栈
  7) 停止                8) 启动               9) 重建镜像并更新
 10) 备份               11) 从备份恢复         12) 更新项目代码
 13) 编辑 .env 并应用   14) 重设后台口令       15) 防火墙放行端口
 16) 环境体检(doctor)   17) 卸载              18) 后台应急登录链接
  0) 退出
MENU
    local c; read -rp "$(printf '%s请选择%s: ' "$C_C" "$C_0")" c || c=0
    case "$c" in
      1) cmd_status;;
      2) local s f; ask s "服务名（postgres/redis/worker/web/login，留空=全部）" ""
         confirm "持续跟随输出（Ctrl+C 结束）？" N && f="-f" || f=""
         # shellcheck disable=SC2086
         cmd_logs $s $f || true;;
      3) cmd_seed;;
      4) cmd_scale;;
      5) cmd_accounts;;
      6) cmd_restart;;
      7) cmd_stop;;
      8) cmd_start;;
      9) cmd_rebuild;;
     10) cmd_backup;;
     11) cmd_restore;;
     12) cmd_update;;
     13) cmd_env;;
     14) cmd_admin_hash;;
     18) cmd_admin_link;;
     15) offer_firewall;;
     16) cmd_doctor;;
     17) cmd_uninstall; break;;
      0|q|"") break;;
      *) warn "无效选择";;
    esac
  done
}

usage() {
  awk 'NR>1 && /^set -Eeuo/{exit} NR>1 && !/^# shellcheck/{sub(/^# ?/,""); print}' "$SELF_PATH"
}

main() {
  ORIG_ARGS=("$@")
  local CMD="" CMD_ARGS=()
  # 前置全局选项 → 子命令 → 其余参数
  while [ $# -gt 0 ]; do
    case "$1" in
      -y|--yes) ASSUME_YES=1;;
      --cn) CN_MODE=1;;
      --no-docker) NO_DOCKER=1;;
      --dir) INSTALL_DIR="${2:?}"; shift;;
      --source) OPT_SOURCE="${2:?}"; shift;;
      --keep) OPT_KEEP="${2:?}"; shift;;
      --port) OPT_PORT="${2:?}"; shift;;
      --ticket) OPT_TICKET="${2:?}"; shift;;
      --uid) OPT_UID="${2:?}"; shift;;
      --pg-password) OPT_PGPW="${2:?}"; shift;;
      --admin-password) OPT_ADMIN_PW="${2:?}"; shift;;
      --admin-off) OPT_ADMIN_OFF=1;;
      --admin-user) OPT_ADMIN_USER="${2:?}"; shift;;
      --workers) OPT_WORKERS="${2:?}"; shift;;
      --retention) OPT_RETENTION="${2:?}"; shift;;
      --discovery) OPT_DISCOVERY="${2:?}"; shift;;
      --registry-mirror) REGISTRY_MIRRORS+=("${2:?}"); shift;;
      --pip-mirror)      OPT_PIP_MIRROR="${2:?}"; shift;;
      --gh-proxy) GH_PROXY="${2:?}"; shift;;
      -h|--help|help) usage; exit 0;;
      -v|--version) echo "$SELF_NAME v$SCRIPT_VERSION"; exit 0;;
      -*) die "未知选项：$1（--help 查看用法）";;
      *) CMD="$1"; shift; CMD_ARGS=("$@"); break;;
    esac
    shift
  done
  # install/update 允许把选项放在子命令之后
  if [ "$CMD" = "install" ] || [ "$CMD" = "update" ]; then
    set -- ${CMD_ARGS[@]+"${CMD_ARGS[@]}"}; CMD_ARGS=()
    while [ $# -gt 0 ]; do
      case "$1" in
        -y|--yes) ASSUME_YES=1;;
        --cn) CN_MODE=1;;
        --no-docker) NO_DOCKER=1;;
        --dir) INSTALL_DIR="${2:?}"; shift;;
        --source) OPT_SOURCE="${2:?}"; shift;;
        --keep) OPT_KEEP="${2:?}"; shift;;
        --port) OPT_PORT="${2:?}"; shift;;
        --ticket) OPT_TICKET="${2:?}"; shift;;
        --uid) OPT_UID="${2:?}"; shift;;
        --pg-password) OPT_PGPW="${2:?}"; shift;;
        --admin-password) OPT_ADMIN_PW="${2:?}"; shift;;
        --admin-off) OPT_ADMIN_OFF=1;;
        --admin-user) OPT_ADMIN_USER="${2:?}"; shift;;
        --workers) OPT_WORKERS="${2:?}"; shift;;
        --retention) OPT_RETENTION="${2:?}"; shift;;
        --discovery) OPT_DISCOVERY="${2:?}"; shift;;
        --registry-mirror) REGISTRY_MIRRORS+=("${2:?}"); shift;;
        --pip-mirror)      OPT_PIP_MIRROR="${2:?}"; shift;;
        --gh-proxy) GH_PROXY="${2:?}"; shift;;
        *) die "install/update 不接受该参数：$1";;
      esac
      shift
    done
  fi

  _log "===== $SELF_NAME v$SCRIPT_VERSION 启动：cmd='${CMD:-<auto>}' args='${CMD_ARGS[*]:-}' ====="

  case "$CMD" in
    install) cmd_install;;
    "" )
      if [ ! -t 0 ]; then usage; exit 1; fi
      if [ -n "${MAXX_DIR:-}" ] || [ -f "$POINTER_FILE" ] || verify_markers "${DEFAULT_INSTALL_DIR}" 2>/dev/null \
         || find_project_upward "$PWD" >/dev/null 2>&1 || find_project_upward "$(dirname "$SELF_PATH")" >/dev/null 2>&1; then
        ensure_runtime; locate_existing_install
        CFG_WEB_PORT="$(env_get WEB_PORT || echo "$CFG_WEB_PORT")"
        say "已定位部署：$INSTALL_DIR（进入管理菜单；重新安装请执行：$SELF_NAME install）"
        menu
      else
        cmd_install
      fi;;
    status|logs|seed|scale|start|stop|restart|rebuild|accounts|admin-hash|admin-link|backup|restore|update|env|firewall|doctor|uninstall|menu)
      ensure_runtime
      locate_existing_install
      CFG_WEB_PORT="$(env_get WEB_PORT || echo "$CFG_WEB_PORT")"
      case "$CMD" in
        status)     cmd_status;;
        logs)       cmd_logs ${CMD_ARGS[@]+"${CMD_ARGS[@]}"};;
        seed)       cmd_seed ${CMD_ARGS[@]+"${CMD_ARGS[@]}"};;
        scale)      cmd_scale "${CMD_ARGS[@]:-}";;
        start)      cmd_start;;
        stop)       cmd_stop;;
        restart)    cmd_restart;;
        rebuild)    cmd_rebuild;;
        accounts)   cmd_accounts;;
        admin-hash) cmd_admin_hash "${CMD_ARGS[@]:-}";;
        admin-link) cmd_admin_link "${CMD_ARGS[@]:-}";;
        backup)     cmd_backup;;
        restore)    cmd_restore "${CMD_ARGS[@]:-}";;
        update)     require_root; cmd_update;;
        env)        cmd_env;;
        firewall)   offer_firewall;;
        doctor)     cmd_doctor;;
        uninstall)  cmd_uninstall;;
        menu)       menu;;
      esac;;
    *) die "未知子命令：$CMD（--help 查看用法）";;
  esac
}

# 直接执行时进入 main；被 source 时仅加载函数（便于调试/自测）
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
  main "$@"
fi
