@echo off
chcp 65001 >nul 2>nul
rem ============================================================================
rem  audit-maxxiang.bat - window_audit Docker 跑测器(Windows 一键)
rem  - 与同目录 audit-maxxiang.sh 同口径(同镜像/同挂载/同环境变量/同基线)
rem  - 本文件放在 window_audit\ 内；项目根 = 上一级目录
rem  - 为什么必须进容器：宿主 Python 若为 3.6 会分四段报错
rem      (1) PyYAML 3.x 拒 config.yaml 注释里的 emoji U+1F48E -> position 310
rem      (2) predictor_bridge.py `from __future__ import annotations` 需 3.7+
rem      (3) spell_tamer_monitor.py `dataclasses` 需 3.7+
rem      (4) analyze_extra.py `math.comb` 需 3.8+
rem  - 关键坑：镜像内 ENV STA_ENGINE_DIR=/app/engine，脚本用 setdefault，
rem            不显式覆盖会静默回放镜像内旧引擎 -- 下方 -e 已钉死。
rem  用法： 双击 = 菜单； audit-maxxiang.bat test|doctor|shell = 直接执行
rem ============================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"
for %%A in ("%~dp0..") do set "ROOT=%%~fA"
set "OUT=%TEMP%\maxxiang-audit"
if not exist "%OUT%" mkdir "%OUT%"

where docker >nul 2>nul || (echo [ERROR] 未找到 docker，请先安装并启动 Docker Desktop & goto :end1)
docker info >nul 2>nul || (echo [ERROR] Docker 守护进程不可达，请先启动 Docker Desktop & goto :end1)
if not exist "%ROOT%\window_audit\replay_harness.py" (
  echo [ERROR] 未找到项目根 ^(期望 %ROOT%\window_audit\replay_harness.py^) & goto :end1
)
if not exist "%ROOT%\window_audit\out" mkdir "%ROOT%\window_audit\out"

set "IMG="
for %%I in (maxxiang-worker maxxiang_worker maxxiang-web deploy-worker deploy_worker maxxiang-audit:1.0) do (
  if not defined IMG ( docker image inspect %%I >nul 2>nul && set "IMG=%%I" )
)
if not defined IMG (
  echo [*] 未见可复用镜像，构建 maxxiang-audit:1.0 ^(基于 python:3.12-slim^)...
  set "DFD=%TEMP%\maxxiang-audit-build"
  if exist "!DFD!" rd /s /q "!DFD!"
  mkdir "!DFD!"
  > "!DFD!\Dockerfile"  echo FROM python:3.12-slim
  >>"!DFD!\Dockerfile"  echo ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 TZ=Asia/Shanghai
  >>"!DFD!\Dockerfile"  echo RUN pip install --no-cache-dir PyYAML==6.0.3 requests==2.33.1
  >>"!DFD!\Dockerfile"  echo WORKDIR /repo/window_audit
  docker build -t maxxiang-audit:1.0 "!DFD!" || (echo [ERROR] 镜像构建失败 & goto :end1)
  rd /s /q "!DFD!"
  set "IMG=maxxiang-audit:1.0"
)
echo [*] 项目根：%ROOT%
echo [*] 运行镜像：!IMG!

if /i "%~1"=="test"   goto :suite
if /i "%~1"=="doctor" goto :doctor
if /i "%~1"=="shell"  goto :shell
if not "%~1"==""      goto :suite

:menu
echo.
echo ============ window_audit . Docker 跑测器 (Windows) ============
echo   1^) 全套跑测并比对 README 基线
echo   2^) 单房回放 replay
echo   3^) 裁决器演示 window_judge
echo   4^) 进容器 shell
echo   0^) 退出
set "SEL="
set /p "SEL=请选择 [1]: "
if "!SEL!"=="" set "SEL=1"
if "!SEL!"=="1" goto :suite
if "!SEL!"=="2" goto :one
if "!SEL!"=="3" goto :judge
if "!SEL!"=="4" goto :shell
if "!SEL!"=="0" goto :end0
echo 无效选择 & goto :menu

:one
set "RM="
set /p "RM=  房号 [2678075]: "
if "!RM!"=="" set "RM=2678075"
call :run "%OUT%\one.txt" replay_harness.py !RM!
goto :menu

:judge
call :run "%OUT%\judge.txt" window_judge.py --windows 24,72
goto :menu

:shell
docker run --rm -it -v "%ROOT%:/repo" -w /repo/window_audit --user 0:0 ^
  -e STA_ENGINE_DIR=/repo/jiufa_data --entrypoint bash "!IMG!"
goto :end0

:doctor
docker run --rm -i -v "%ROOT%:/repo" -w /repo/window_audit --user 0:0 ^
  -e STA_ENGINE_DIR=/repo/jiufa_data --entrypoint python "!IMG!" -c ^
  "import sys,yaml,os;print('Python',sys.version.split()[0]);print('PyYAML',yaml.__version__);yaml.safe_load(open('/repo/backend_async/config.yaml',encoding='utf-8'));print('config.yaml 解析成功(emoji 已放行)');print('STA_ENGINE_DIR',os.environ.get('STA_ENGINE_DIR'))"
goto :end0

:suite
call :run "%OUT%\r1.txt"    replay_harness.py 2678075   || goto :end1
call :run "%OUT%\r2.txt"    replay_harness.py 1395093   || goto :end1
call :run "%OUT%\r3.txt"    replay_harness.py 4787261   || goto :end1
call :run "%OUT%\cold.txt"  analyze_cold.py             || goto :end1
call :run "%OUT%\extra.txt" analyze_extra.py            || goto :end1
call :run "%OUT%\judge.txt" window_judge.py             || goto :end1
echo.
echo == 与 README 首轮审计基线(2026-07-18)比对 ==
set /a FAIL=0
call :chk "%OUT%\r1.txt"    "=57.10"    "房2678075 四码命中率 57.10"
call :chk "%OUT%\r2.txt"    "=56.41"    "房1395093 四码命中率 56.41"
call :chk "%OUT%\r3.txt"    "=58.61"    "房4787261 四码命中率 58.61"
call :chk "%OUT%\cold.txt"  "=616"      "三房合并冷门命中 616"
call :chk "%OUT%\cold.txt"  "441.6"     "同k随机基线 441.6"
call :chk "%OUT%\cold.txt"  "z=+10.87"  "冷门显著性 z=+10.87"
call :chk "%OUT%\extra.txt" "0.850"     "McNemar 双侧 p 约 0.850"
call :chk "%OUT%\extra.txt" "=21.7"     "shuffle 后一致率 21.7"
call :chk "%OUT%\extra.txt" "=23.8"     "reverse 后一致率 23.8"
call :chk "%OUT%\extra.txt" ": True"    "同数据重跑逐字节确定"
call :chk "%OUT%\judge.txt" "96h"       "裁决器如实标记不可裁决"
echo --------------------------------------------------------------
if !FAIL! EQU 0 (
  echo  [OK] 全部 11 项与基线吻合 -- 工具包在 Docker 中复现成功
  echo       明细产物：%ROOT%\window_audit\out\
  if "%~1"=="" goto :menu
  goto :end0
) else (
  echo  [FAIL] !FAIL! 项与基线不符；原始输出保留在 %OUT%
  goto :end1
)

:run
docker run --rm -i -v "%ROOT%:/repo" -w /repo/window_audit --user 0:0 ^
  -e STA_ENGINE_DIR=/repo/jiufa_data -e PYTHONDONTWRITEBYTECODE=1 -e PYTHONUNBUFFERED=1 ^
  --entrypoint python "!IMG!" %~2 %~3 %~4 > "%~1" 2>&1
set "RC=!errorlevel!"
type "%~1"
if not "!RC!"=="0" echo [ERROR] 步骤失败：%~2 %~3 %~4  ^(输出见 %~1^)
exit /b !RC!

:chk
findstr /c:"%~2" "%~1" >nul 2>nul
if errorlevel 1 (set /a FAIL+=1 & echo   [X] %~3   ^(未匹配到 "%~2"^)) else (echo   [v] %~3)
exit /b 0

:end0
set "RC=0"
goto :fin
:end1
set "RC=1"
goto :fin
:fin
if "%~1"=="" (
  echo.
  echo [audit-maxxiang] finished, exit code %RC%. Press any key to close . . .
  pause >nul
)
exit /b %RC%
