#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""kdist 扫描分析。口径与 analyze_rotate.py 一致：成熟期=跳过前400局预测，
只统计已结算局；显著性=McNemar 精确二项(同批局配对)。"""
import json
import math
import os
from collections import Counter

WORK = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out_kdist", "done")
COLD = (3, 4, 5, 6, 9)
RARE = (3, 9)
MULT = {1: 10, 2: 50, 3: 330, 4: 250, 5: 100, 6: 100, 7: 50, 8: 50, 9: 500}
ROOMS = ["1275859", "2678075", "3746870"]
WARM = 400

GRID = [
    ("D_45_31.5_13.5", "45,31.5,13.5"),
    ("O_45_30_15", "45,30,15"),
    ("L1_50_27_8", "50,27,8"),
    ("L2_55_20_5", "55,20,5"),
    ("S1_55_25_10", "55,25,10"),
    ("S2_35_40_15", "35,40,15"),
    ("H2_40_35_20", "40,35,20"),
    ("H3_30_38_27", "30,38,27"),
    ("X0_0_0_0", "0,0,0"),
    ("P1_25_40_30", "25,40,30"),
    ("P2_0_0_95", "0,0,95"),
]


def load(name):
    per = {}
    for room in ROOMS:
        d = json.load(open(os.path.join(WORK, f"{name}__{room}.json")))
        recs = [r for r in d["recs"][WARM:] if r[1] is not None]
        per[room] = recs
    return per


def room_stats(recs):
    n = len(recs)
    h4 = hm = ret = ch = rh = 0
    k1 = k2 = k3 = ksum = 0
    bd = hc = 0
    hits4, hitsm, rets = [], [], []
    for four, actual, ncold, flag in recs:
        in4 = actual in four
        inm = actual in four[:2]
        h4 += in4
        hm += inm
        r = MULT[actual] if in4 else 0
        ret += r
        hits4.append(1 if in4 else 0)
        hitsm.append(1 if inm else 0)
        rets.append(r)
        if actual in COLD and in4:
            ch += 1
        if actual in RARE and in4:
            rh += 1
        ksum += ncold
        k1 += ncold >= 1
        k2 += ncold >= 2
        k3 += ncold >= 3
        bd += (flag >> 1) & 1
        hc += flag & 1
    return dict(n=n, h4=h4, hm=hm, ret=ret, ch=ch, rh=rh,
                k1=k1, k2=k2, k3=k3, ksum=ksum, bd=bd, hc=hc,
                hits4=hits4, hitsm=hitsm, rets=rets)


def merge(per):
    tot = {k: sum(per[r][k] for r in ROOMS) for k in
           ("n", "h4", "hm", "ret", "ch", "rh", "k1", "k2", "k3", "ksum", "bd", "hc")}
    return tot


def mcnemar(a, b):
    x = sum(1 for i in range(len(a)) if a[i] and not b[i])
    y = sum(1 for i in range(len(a)) if b[i] and not a[i])
    N, k = x + y, min(x, y)
    if N == 0:
        return x, y, 1.0
    lp = sum(math.comb(N, i) for i in range(k + 1)) / 2 ** N
    return x, y, min(1.0, 2 * lp)


def main():
    base = load("D_45_31.5_13.5")
    bstats = {r: room_stats(base[r]) for r in ROOMS}
    # 对齐性守卫：各配置各房已结算局数必须一致，否则配对无效
    for name, _ in GRID:
        per = load(name)
        for r in ROOMS:
            assert len(per[r]) == len(base[r]), (name, r, len(per[r]), len(base[r]))

    print("=" * 138)
    print("【showcase_kdist 扫描 · 三房合并 · 成熟期 · 生产代码路径逐局因果回放】"
          "Δ/p=对 4.9.7 默认档 D(扫描基准)的 McNemar 精确二项(四码命中,同批局配对)")
    print("=" * 138)
    hdr = (f"{'档位(k=1/2/3份额%)':<22}{'cums(≥1/≥2/=3)':<17}{'四码中%':>8}{'Δpp':>7}"
           f"{'p值':>9}{'主中%':>7}{'回报u/局':>9}{'Δ回报':>8}{'冷门中%':>8}{'稀有中%':>8}"
           f"{'达成≥1/≥2/=3%':>16}{'保底%':>7}{'硬帽%':>7}")
    print(hdr)
    print("-" * 138)
    rows = []
    for name, kd in GRID:
        per = load(name)
        st = {r: room_stats(per[r]) for r in ROOMS}
        m = merge(st)
        n = m["n"]
        # McNemar 与 回报配对差(逐局)
        if name == "D_45_31.5_13.5":
            x = y = 0
            p = float("nan")
            dret = 0.0
            se = 0.0
        else:
            a4 = sum((bstats[r]["hits4"] for r in ROOMS), [])
            b4 = sum((st[r]["hits4"] for r in ROOMS), [])
            x, y, p = mcnemar(a4, b4)
            da = sum((bstats[r]["rets"] for r in ROOMS), [])
            db = sum((st[r]["rets"] for r in ROOMS), [])
            diffs = [db[i] - da[i] for i in range(len(da))]
            dret = sum(diffs) / len(diffs)
            mu = dret
            var = sum((d - mu) ** 2 for d in diffs) / (len(diffs) - 1)
            se = math.sqrt(var / len(diffs))
        p1, p2, p3 = [float(v) for v in kd.split(",")]
        t = max(1.0, p1 + p2 + p3)
        if t > 95:
            p1, p2, p3 = (v * 95 / t for v in (p1, p2, p3))
        cums = f"{p1+p2+p3:.0f}/{p2+p3:.0f}/{p3:.1f}"
        d4 = (m["h4"] - merge(bstats)["h4"]) / n * 100
        rows.append((name, m, st))
        print(f"{kd:<22}{cums:<17}{m['h4']/n*100:>8.2f}{d4:>+7.2f}"
              f"{('' if p != p else f'{p:.4f}'):>9}{m['hm']/n*100:>7.2f}"
              f"{m['ret']/n:>9.3f}{dret:>+8.3f}{m['ch']/n*100:>8.2f}{m['rh']/n*100:>8.3f}"
              f"{m['k1']/n*100:>6.1f}/{m['k2']/n*100:>4.1f}/{m['k3']/n*100:>4.1f}"
              f"{m['bd']/n*100:>7.2f}{m['hc']/n*100:>7.2f}"
              + (f"  (回报差SE={se:.3f})" if se else ""))
    print(f"\n成熟局合计 n={merge(bstats)['n']};四码命中配对差 SE≈"
          f"{math.sqrt(0.5*0.5/merge(bstats)['n'])*100*1.1:.2f}pp 量级")

    # 分房一致性(四码命中% 与 回报u/局)
    print("\n" + "=" * 138)
    print("【分房一致性】每格 = 四码中% | 回报u/局(相对 D 的差)")
    print("=" * 138)
    print(f"{'档位':<22}" + "".join(f"{('房'+r):>36}" for r in ROOMS))
    for name, kd in GRID:
        per = load(name)
        st = {r: room_stats(per[r]) for r in ROOMS}
        cells = []
        for r in ROOMS:
            s, b = st[r], bstats[r]
            cells.append(f"{s['h4']/s['n']*100:>7.2f}%({(s['h4']-b['h4'])/s['n']*100:+.2f})"
                         f" {s['ret']/s['n']:>7.3f}({s['ret']/s['n']-b['ret']/b['n']:+.3f})")
        print(f"{kd:<22}" + "".join(f"{c:>36}" for c in cells))


if __name__ == "__main__":
    main()
