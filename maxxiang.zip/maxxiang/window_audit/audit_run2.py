#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""audit_run2.py —— 训练窗长端扩展扫描 96 / 120 / 144 / 168h(口径同 audit_run.py)。

⚠ 本机数据跨度 167.98h ⇒ 168h 窗在任何一局都切不掉任何数据,预期与 tw=0
  (不限时间)**逐局全同**;144/120/96h 分别只在数据的最后 24/48/72h 才开始
  真正生效。这一点在分析阶段用逐局比对验证,不靠推断。
"""
import os, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from audit_run import run, rounds, ROOMS, BIG  # noqa: E402  复用同一条生产回放路径

if __name__ == "__main__":
    print("[4] 训练窗长端扩展 96/120/144/168h", flush=True)
    for h in (96.0, 120.0, 144.0, 168.0):
        for rm in ROOMS:
            run(f"{rm}_tw{h:g}", rm, {"train_window_hours": h, "max_train": BIG})
    print("扩展完成", flush=True)
