#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""冷门检验(审计存档) — 对 out/replay_{room}.json 做三类检验:
①冷门选择是否具备超越基线的规律性(命中提升+显著性:同k随机MC/固定轮播/频率top-k)
②信号通道是否多路真实参与 ③输出是否固定顺序(熵/滞后自相似/席位变化率)。
先运行: python3 replay_harness.py <room> (逐房生成回放明细)。
2026-07-18 首轮审计结论(本仓 25h 快照,种子固定可复现):三房合并冷门命中
616 vs 同k随机 441.6±16.0 (z=+10.87);与 24h 频率 top-k 打平;非固定顺序。"""
import json, math, random, re, sqlite3, bisect, os, sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(HERE, "out")
DB = os.path.join(ROOT, "jiufa_data", "spell_tamer_data.db")
COLD = (3, 4, 5, 6, 9)
ROOMS = sys.argv[1].split(",") if len(sys.argv) > 1 else ["1275859", "2678075", "3746870"]


def load(room):
    p = os.path.join(OUT, f"replay_{room}.json")
    if not os.path.exists(p):
        return None, None
    recs = json.load(open(p))
    con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    rounds = con.execute("SELECT round_id, custom_id, start_ms FROM rounds "
                         "WHERE room_id=? AND custom_id IS NOT NULL ORDER BY round_id",
                         (room,)).fetchall()
    con.close()
    return recs, rounds


def window_counts(rounds, upto_idx, since_ms):
    starts = [r[2] for r in rounds]
    lo = bisect.bisect_left(starts, since_ms, 0, upto_idx + 1)
    return Counter(r[1] for r in rounds[lo:upto_idx + 1])


random.seed(20260718)
pool = []
print("═" * 78)
for room in ROOMS:
    recs, rounds = load(room)
    if recs is None:
        print(f"[{room}] 缺 out/replay_{room}.json —— 先跑 replay_harness.py,跳过")
        continue
    rid2idx = {r[0]: i for i, r in enumerate(rounds)}
    settled = [r for r in recs if r["actual"] is not None]
    n = len(settled)
    kc = Counter(r["k"] for r in settled)
    coldpick = Counter()
    for r in settled:
        coldpick.update(r["coldset"])
    promo = sum(1 for r in settled if r["promoted"])
    baodi = sum(1 for r in settled if r["baodi"])
    m4max = max(max((int(v) for v in r["miss4"].values()), default=0) for r in settled)
    actual_cold = sum(1 for r in settled if r["actual"] in COLD)
    print(f"[{room}] 已结算 {n} 局 | 实际冷门占比 {actual_cold/n*100:.1f}%")
    print(f"  冷门席位数k分布: " + "  ".join(f"k={i}:{kc.get(i,0)}({kc.get(i,0)/n*100:.0f}%)" for i in range(4))
          + f" | ≥1:{sum(kc[i] for i in (1,2,3))/n*100:.0f}% ≥2:{sum(kc[i] for i in (2,3))/n*100:.0f}%"
          + f" ≥3:{kc.get(3,0)/n*100:.0f}% (目标90/45/15)")
    print(f"  冷门被选频次: {dict(sorted(coldpick.items()))} | 升座主位 {promo} 次 | 保底 {baodi} 次 | miss4峰值 {m4max}")
    eng_hit = rot_hit = freq_hit = rec30_hit = 0
    per_beast = defaultdict(lambda: [0, 0])
    rot_state = 0
    krounds = []
    for r in settled:
        a, k = r["actual"], r["k"]
        if a in r["coldset"]:
            eng_hit += 1
        for c in r["coldset"]:
            per_beast[c][0] += 1
            per_beast[c][1] += a == c
        if k == 0:
            continue
        gi = r["gen_after_idx"]
        krounds.append(r)
        rot = [COLD[(rot_state + j) % 5] for j in range(k)]
        rot_state = (rot_state + k) % 5
        rot_hit += a in rot
        wc = window_counts(rounds, gi, rounds[gi][2] - 86400000)
        freq_hit += a in sorted(COLD, key=lambda c: (-wc.get(c, 0), c))[:k]
        w30 = Counter(x[1] for x in rounds[max(0, gi - 29):gi + 1])
        rec30_hit += a in sorted(COLD, key=lambda c: (-w30.get(c, 0), c))[:k]
    MC = 4000
    hits = []
    for _ in range(MC):
        hits.append(sum(1 for r in krounds if r["actual"] in random.sample(COLD, r["k"])))
    mu = sum(hits) / MC
    sd = (sum((x - mu) ** 2 for x in hits) / MC) ** 0.5
    pval = sum(1 for x in hits if x >= eng_hit) / MC
    print(f"  冷门命中(k≥1的{len(krounds)}局): 引擎={eng_hit}  同k随机={mu:.1f}±{sd:.1f} (p={pval:.4f})"
          f"  固定轮播={rot_hit}  24h频率top-k={freq_hit}  近30局top-k={rec30_hit}")
    for c in COLD:
        s_, h = per_beast[c]
        base = sum(1 for r in settled if r["actual"] == c) / n * 100
        if s_:
            cond = h / s_ * 100
            print(f"    {c}号: 被选{s_}局 命中{h} 条件命中率{cond:.2f}% vs 基率{base:.2f}%"
                  f" (×{cond/base:.2f})" if base else "")
    tk = {i: [0, 0] for i in range(4)}
    for r in settled:
        tk[r["k"]][0] += 1
        tk[r["k"]][1] += r["actual"] in COLD
    print("  择时P(实际开冷门|k): " + "  ".join(
        f"k={i}:{tk[i][1]}/{tk[i][0]}={tk[i][1]/tk[i][0]*100:.1f}%" if tk[i][0] else f"k={i}:-"
        for i in range(4)))
    seqs = [tuple(sorted(r["coldset"])) for r in settled]
    firsts = [r["coldset"][0] for r in settled if r["k"] >= 1]
    fc = Counter(firsts)
    ent = -sum((c/len(firsts)) * math.log2(c/len(firsts)) for c in fc.values())
    lag = {L: sum(firsts[i] == firsts[i-L] for i in range(L, len(firsts))) / (len(firsts)-L)
           for L in (1, 2, 3, 4, 5, 6, 10)}
    oc = sum(settled[i]["four"] != settled[i-1]["four"] for i in range(1, n)) / (n-1)
    mp = sum(set(settled[i]["main"]) != set(settled[i-1]["main"]) for i in range(1, n)) / (n-1)
    print(f"  首选冷门熵={ent:.2f}bit(上限{math.log2(5):.2f}) 四码序变化率={oc*100:.0f}%"
          f" 主2组合变化率={mp*100:.0f}%")
    print(f"  滞后自相似(固定轮播会在某滞后≈100%): " + ", ".join(f"L{L}:{v*100:.0f}%" for L, v in lag.items()))
    chan = Counter()
    for r in settled:
        for pat, name in (("近\\d+局出", "M2近窗"), ("指数热度", "M3指数"), ("上局\\d+后", "M4一阶"),
                          ("前两局\\(", "M5二阶"), ("超期", "M6未出场"), ("恰在此步", "RH节律")):
            if re.search(pat, r["why"]):
                chan[name] += 1
    print(f"  信号通道计数: {dict(chan)}")
    pool.append((eng_hit, mu, sd))
    print("─" * 78)
if len(pool) > 1:
    te, tm = sum(x[0] for x in pool), sum(x[1] for x in pool)
    ts = math.sqrt(sum(x[2] ** 2 for x in pool))
    print(f"合并: 引擎冷门命中={te}  同k随机={tm:.1f}±{ts:.1f}  z={(te-tm)/ts:+.2f}")
