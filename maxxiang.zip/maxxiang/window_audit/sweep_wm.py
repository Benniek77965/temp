#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""train_window_hours / max_train 联合扫描 —— 走生产代码路径(replay_harness.replay)。
逐局记录 (target, hit, actual, train_n),落 out_sweep/*.json.gz 供配对检验。
用法: python3 sweep_wm.py <room> <spec...>   spec = W:<hours>:<max_train>
"""
import gzip, json, os, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import replay_harness as rh          # noqa: E402  生产代码路径

OUT = os.path.join(HERE, "out_sweep")
os.makedirs(OUT, exist_ok=True)
BIG = 10 ** 7


def run(room, hours, max_train, rounds):
    tag = f"{room}_h{hours:g}_m{max_train}"
    path = os.path.join(OUT, tag + ".json.gz")
    if os.path.exists(path):
        print(f"  跳过(已存在) {tag}", flush=True)
        return
    cfg = dict(rh.PRED_CFG)
    cfg["train_window_hours"] = hours
    cfg["max_train"] = max_train
    t0 = time.time()
    recs, _ = rh.replay(room, rounds, cfg)
    rows = [[r["target"], (0 if r["hit"] == "miss" else 1),
             r["actual"], r["train_n"], list(r["four"])]
            for r in recs if r["actual"] is not None]
    hit = sum(r[1] for r in rows)
    meta = {"room": room, "hours": hours, "max_train": max_train,
            "n": len(rows), "hit4": hit, "p4": hit / len(rows) if rows else 0,
            "max_train_n": max(r[3] for r in rows) if rows else 0,
            "secs": round(time.time() - t0, 1)}
    with gzip.open(path, "wt") as f:
        json.dump({"meta": meta, "rows": rows}, f)
    print(f"  {tag}: n={meta['n']} 四码={meta['p4']*100:.2f}% "
          f"max(train_n)={meta['max_train_n']} {meta['secs']}s", flush=True)


def main():
    room = sys.argv[1]
    rounds = rh.load_rounds(room)
    print(f"[{room}] {len(rounds)} 局", flush=True)
    for spec in sys.argv[2:]:
        _, h, m = spec.split(":")
        run(room, float(h), BIG if m in ("BIG", "inf") else int(m), rounds)


if __name__ == "__main__":
    main()
