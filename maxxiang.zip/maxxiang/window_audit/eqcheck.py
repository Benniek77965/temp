#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""eqcheck.py —— 逐局等价/差异比对(不靠推断,直接比四码集合与 train_n)。"""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from audit_analyze import load

def cmp2(a, b, rooms):
    tot = dif = dtn = 0
    for rm in rooms:
        A, B = load(f"{rm}_{a}"), load(f"{rm}_{b}")
        if not A or not B:
            print(f"  {rm}: 缺 {a if not A else b}"); continue
        da = {r[0]: (tuple(r[4]), r[3]) for r in A["rows"]}
        db = {r[0]: (tuple(r[4]), r[3]) for r in B["rows"]}
        k = set(da) & set(db)
        d = sum(1 for x in k if da[x][0] != db[x][0])
        t = sum(1 for x in k if da[x][1] != db[x][1])
        tot += len(k); dif += d; dtn += t
        print(f"  {rm}: 共同局 {len(k)}  四码不同 {d}  train_n 不同 {t}")
    print(f"  → 合计 {tot} 局:四码不同 {dif} 局({dif/tot*100:.3f}%),train_n 不同 {dtn} 局")
    return dif

R3 = ["2678075", "1275859", "3746870"]
R1 = ["2678075"]
print("① tw=168h(max_train=∞) vs tw=0 不限时间 —— 数据跨度 167.98h,预期逐局全同")
cmp2("tw168", "tw0", R3)
print("\n② tw=144h vs tw=0 —— 只有最后 24h 的局能生效,前面必然全同")
cmp2("tw144", "tw0", R3)
print("\n③ tw=96h vs tw=0 —— 只有最后 72h 的局能生效")
cmp2("tw96", "tw0", R3)
print("\n④ 生产 max_train=5000 的静默截短:tw=168h/mt=5000 vs tw=0/mt=5000")
cmp2("tw168_mt5000", "tw0_mt5000", R1)
print("\n⑤ 同一 tw=168h,mt=5000 vs mt=∞ —— 这就是「改了窗口等于没改」的量")
cmp2("tw168_mt5000", "tw168", R1)
print("\n⑥ 对照:24h 窗下 mt=5000 vs mt=∞(仓库称 max_train 空转)")
cmp2("base", "base", R1)
