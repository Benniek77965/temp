#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""扫描结果分析:公平评估域 + 配对 McNemar + 二项区间。

关键方法论修正(相对 window_judge.py):
  两个候选窗在「数据跨度 < 大窗」的前缀上取到的 seq **完全相同** ⇒ 预测逐字节
  相同 ⇒ 那一段对两边贡献同一批命中,只会**稀释**差异。故本脚本额外给出
  「公平域」口径:只统计目标局起点 ≥ 数据起点 + max(两窗) 的部分。
"""
import gzip, json, math, os, sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out_sweep")


def load(room, hours, mt=10 ** 7):
    p = os.path.join(OUT, f"{room}_h{hours:g}_m{mt}.json.gz")
    if not os.path.exists(p):
        return None
    return json.load(gzip.open(p, "rt"))


def scope(rows, t_from):
    return {r[0]: r[1] for r in rows if r[0] >= t_from}


def mcnemar(a, b):
    """a,b: dict target->hit(0/1) 同域。返回 (b01, b10, p_two_sided)"""
    keys = set(a) & set(b)
    b01 = sum(1 for k in keys if a[k] == 1 and b[k] == 0)   # a 中 b 不中
    b10 = sum(1 for k in keys if a[k] == 0 and b[k] == 1)
    n = b01 + b10
    if n == 0:
        return b01, b10, 1.0, len(keys)
    # 精确二项(p=0.5)双侧
    k = min(b01, b10)
    s = sum(math.comb(n, i) for i in range(0, k + 1))
    p = min(1.0, 2 * s / (2 ** n))
    return b01, b10, p, len(keys)


def main():
    rooms = sys.argv[1:] or ["2678075", "1275859", "3746870"]
    wins = [1, 3, 6, 12, 24, 36, 48, 72, 120, 0]
    # 数据起点
    import sqlite3
    con = sqlite3.connect("file:" + os.path.join(os.path.dirname(HERE), "jiufa_data",
                                                 "spell_tamer_data.db") + "?mode=ro", uri=True)
    t0 = {r[0]: r[1] for r in con.execute(
        "SELECT room_id, MIN(round_id) FROM rounds GROUP BY room_id")}

    for tag, cutoff_h in (("全域(含共同热身前缀)", 0.0), ("公平域(起点+72h 之后)", 72.0)):
        print(f"\n═══ {tag} ═══")
        print(f"{'窗口h':>6} | " + " | ".join(f"{r:>16}" for r in rooms) + " |     合计")
        agg = {}
        for h in wins:
            cells, tot_n, tot_h = [], 0, 0
            for room in rooms:
                d = load(room, h)
                if not d:
                    cells.append(f"{'—':>16}"); continue
                s = scope(d["rows"], t0[room] + int(cutoff_h * 3600 * 1000))
                n = len(s); hit = sum(s.values())
                tot_n += n; tot_h += hit
                cells.append(f"{hit/n*100:>7.2f}% ({n:>5})" if n else f"{'—':>16}")
            agg[h] = (tot_h, tot_n)
            tt = f"{tot_h/tot_n*100:>7.2f}%" if tot_n else "   —"
            print(f"{h:>6g} | " + " | ".join(cells) + f" | {tt}")
        # 合计二项 σ
        if agg.get(24) and agg[24][1]:
            p = agg[24][0] / agg[24][1]
            sd = math.sqrt(p * (1 - p) / agg[24][1]) * 100
            print(f"  (合计口径 24h 的二项 1σ = {sd:.3f}pp;n={agg[24][1]})")

    # ── 配对 McNemar:24h vs 其它(公平域) ────────────────────────────────
    print("\n═══ 配对检验 24h vs X(公平域:起点+72h 之后;三房合并) ═══")
    print(f"{'X':>6} | {'24中X不中':>9} {'X中24不中':>9} {'净差pp':>8} {'精确p':>10} {'配对n':>7}")
    base = {}
    for room in rooms:
        d = load(room, 24)
        if d:
            for k, v in scope(d["rows"], t0[room] + 72 * 3600000).items():
                base[(room, k)] = v
    for h in wins:
        if h == 24:
            continue
        oth = {}
        for room in rooms:
            d = load(room, h)
            if d:
                for k, v in scope(d["rows"], t0[room] + 72 * 3600000).items():
                    oth[(room, k)] = v
        if not oth:
            continue
        b01, b10, p, n = mcnemar(base, oth)
        print(f"{h:>6g} | {b01:>9} {b10:>9} {(b10-b01)/n*100:>+8.3f} {p:>10.4f} {n:>7}")


if __name__ == "__main__":
    main()
