#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""win_report2.py —— 两件 McNemar 做不到的事。

(A) 序列相关校正:LP 每 fr_replan=200 局才重解一次,其间四码由确定性 Bresenham
    赤字轮转产出 ⇒ 相邻局的预测**高度序列相关**,而 McNemar 把 20,720 局当独立
    配对处理,p 值是**反保守**的。这里改用「每 200 局一块」的整块配对检验
    (块内取命中率之差,块间做配对 t 与符号检验),块 = 一个完整重规划周期。
(B) 约束面:LP 的目标是「在冷门/稀有/回报三条下限之下最大化命中」,而这三条下限
    是**用 p-hat 自己算的**。p-hat 越噪,约束被评估得越偏 ⇒ 可能靠「实际没满足
    约束」换来命中。故必须把冷门/稀有/回报与命中一起看。
"""
import math, os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from audit_analyze import load, seg_rows, stats, ROOMS  # noqa
from win_report import WINS, BASE  # noqa

FAIR, BLK = 72.0, 200


def blocks(tag, dom):
    """返回 [(room, 块序号, 命中数, 局数)] —— 块按局序切,块 = 一个 fr_replan 周期。"""
    out = []
    for rm in ROOMS:
        d = load(f"{rm}_{tag}")
        if not d:
            return None
        rows = sorted(seg_rows(d, rm, lo_h=dom).items())
        for i in range(0, len(rows) - BLK + 1, BLK):
            seg = rows[i:i + BLK]
            out.append((rm, i // BLK, sum(v[0] for _k, v in seg), len(seg)))
    return out


def paired_block(a, b, dom):
    A, B = blocks(a, dom), blocks(b, dom)
    if A is None or B is None:
        return None
    ka = {(r, i): (h, n) for r, i, h, n in A}
    kb = {(r, i): (h, n) for r, i, h, n in B}
    keys = sorted(set(ka) & set(kb))
    d = [(kb[k][0] - ka[k][0]) / ka[k][1] * 100 for k in keys]
    m = len(d)
    if m < 3:
        return None
    mean = sum(d) / m
    sd = (sum((x - mean) ** 2 for x in d) / (m - 1)) ** 0.5
    t = mean / (sd / math.sqrt(m)) if sd > 0 else 0.0
    p = math.erfc(abs(t) / math.sqrt(2))               # 双尾正态近似(m>=50)
    pos = sum(1 for x in d if x > 0); neg = sum(1 for x in d if x < 0)
    n2 = pos + neg
    k = min(pos, neg)
    ps = min(1.0, 2 * sum(math.comb(n2, i) for i in range(k + 1)) / (2 ** n2)) if n2 else 1.0
    return m, mean, sd, t, p, pos, neg, ps


def metric_row(tag, dom):
    n = 0
    acc = {"p4": 0.0, "cold": 0.0, "rare": 0.0, "ret": 0.0, "exl": 0.0}
    for rm in ROOMS:
        d = load(f"{rm}_{tag}")
        if not d:
            return None
        s = stats(seg_rows(d, rm, lo_h=dom), rm)
        n += s["n"]
        for k in acc:
            acc[k] += s[k] * s["n"]
    return n, {k: v / n for k, v in acc.items()}


print(__doc__)
print("\n" + "=" * 96)
print(f"(A) 整块配对检验 · 公平域起点+{FAIR:g}h · 块长 {BLK} 局(= fr_replan 周期)")
print("=" * 96)
print(f'{"窗口":>8}{"块数":>6}{"块均差pp":>10}{"块间SD":>9}{"t":>8}{"配对t的p":>10}'
      f'{"正/负块":>10}{"符号检验p":>11}')
for tag, h in WINS:
    r = paired_block(BASE, tag, FAIR)
    if r is None:
        print(f'{(f"{h:g}h" if h else "无限"):>8}  (缺)'); continue
    m, mean, sd, t, p, pos, neg, ps = r
    print(f'{(f"{h:g}h" if h else "无限"):>8}{m:>6}{mean:>+10.3f}{sd:>9.3f}{t:>+8.2f}'
          f'{p:>10.4f}{f"{pos}/{neg}":>10}{ps:>11.4f}')

print("\n" + "=" * 96)
print(f"(B) 四项一起看 · 公平域起点+{FAIR:g}h(LP 的三条下限:冷门/稀有/回报)")
print("=" * 96)
print(f'{"窗口":>8}{"四码%":>9}{"冷门%":>9}{"稀有%":>9}{"回报":>9}{"期望(留一)%":>13}')
base = metric_row(BASE, FAIR)
for tag, h in WINS:
    r = metric_row(tag, FAIR)
    if r is None:
        continue
    n, s = r
    mark = " <-现行" if tag == BASE else ""
    print(f'{(f"{h:g}h" if h else "无限"):>8}{s["p4"]:>9.3f}{s["cold"]:>9.3f}'
          f'{s["rare"]:>9.3f}{s["ret"]:>9.4f}{s["exl"]:>13.3f}{mark}')
