#!/usr/bin/env bash
# shellcheck disable=SC1090,SC1091
# ══════════════════════════════════════════════════════════════════════════════
#  audit-maxxiang.sh — window_audit 训练窗裁决工具包 · Docker 跑测器（交互式菜单）
# ──────────────────────────────────────────────────────────────────────────────
#  放哪都能跑：脚本会从自身位置逐级上溯找项目根（推荐放 window_audit/ 内）。
#
#  为什么必须进容器（实地核查 window_audit/ + backend_async/deploy/Dockerfile）：
#    宿主自带 python3（CentOS 7 = 3.6）会**分四段**报错：
#      ① PyYAML 3.x 拒 config.yaml 注释里的 💎(U+1F48E) → ReaderError position 310
#      ② app/predictor_bridge.py:20 `from __future__ import annotations` → 需 3.7+
#      ③ jiufa_data/spell_tamer_monitor.py:20 `dataclasses` → 需 3.7+
#      ④ window_audit/analyze_extra.py:80 `math.comb` → 需 3.8+
#    生产镜像本就是 python:3.12-slim + PyYAML 6.0.3 + requests 2.33.1，进去即通。
#
#  三个脚本代劳的坑：
#    · 镜像 ENV STA_ENGINE_DIR=/app/engine，而 replay_harness.py 的 `os.environ.setdefault(\"STA_ENGINE_DIR\", ...)` 用 setdefault
#      → 不显式覆盖会**静默回放镜像内旧引擎**；
#    · 镜像内应用用户 uid=10001，仓库属主 root → 不处理写不出 out/；
#    · 引擎顶层硬依赖 requests（缺失即 sys.exit(1)），README 只写了 pyyaml。
#
#  用法：
#    bash audit-maxxiang.sh                 # 交互式菜单（无参数且在终端时）
#    bash audit-maxxiang.sh <子命令> [参数]  # 非交互，适合 cron/CI
#
#  子命令：
#    test              全套回放 + 与 README 首轮审计基线逐项比对（有差异退出码 1）
#    all               全套跑一遍，只出结果不判定
#    doctor            运行环境体检（Python/PyYAML/💎解析/引擎目录/快照/写权限）
#    config            配置耦合体检（train_window_hours × max_train × retention）
#    pgstat            看生产 PG 攒到哪了（自动读 .env 的 DSN + 自动接入 compose 网络）
#    judge7            **正式裁决**：裁决器 A + 同口径独立实现 B（互为交叉验证）+ max_train 建议
#    export [归档路径]  从生产 PG 增量导出 SQLite（绕开 retention 滚动删除，可每天跑）
#    replay <房号> [参数...] / cold / extra / judge [参数...]
#    image | shell | clean | menu
#
#  选项：
#    -y|--yes  --dir <路径>  --image <镜像>  --rebuild  --pip-mirror <URL>  --cn
#    --rooms <a,b,c|random|random:N>   --seed <整数>   --min-density <0~1>
#    --data <归档.db>  让 5)/6) 读归档而非自带快照   --refresh 强制重跑回放明细
#    --windows <24,72>  --net <模式>  --user <u[:g]>
#    --selinux <auto|disable|relabel|off>  --keep
#
#  环境变量同名覆盖：AUDIT_DIR / AUDIT_IMAGE / AUDIT_ROOMS / AUDIT_PIP_MIRROR
# ══════════════════════════════════════════════════════════════════════════════
set -Eeuo pipefail

readonly SCRIPT_VERSION="2.2.0"
SELF_PATH="$(readlink -f "${BASH_SOURCE[0]}" 2>/dev/null || echo "${BASH_SOURCE[0]}")"; readonly SELF_PATH
SELF_NAME="$(basename "$SELF_PATH")"; readonly SELF_NAME
readonly AUDIT_IMAGE_LOCAL="maxxiang-audit:1.0"
readonly BASE_IMAGE="python:3.12-slim"
readonly PIN_YAML="PyYAML==6.0.3"
readonly PIN_REQUESTS="requests==2.33.1"
readonly PIN_ASYNCPG="asyncpg==0.31.0"
readonly PYPI_CN_DEFAULT="https://pypi.tuna.tsinghua.edu.cn/simple"
readonly DEFAULT_ROOMS="1275859,2678075,3746870"
REUSE_IMAGES=(maxxiang-worker maxxiang_worker maxxiang-web deploy-worker deploy_worker)

ROOT="${AUDIT_DIR:-}"; IMAGE="${AUDIT_IMAGE:-}"; ROOMS="${AUDIT_ROOMS:-$DEFAULT_ROOMS}"
WINDOWS="24,72"; PIP_MIRROR="${AUDIT_PIP_MIRROR:-}"
ASSUME_YES=0; CN_MODE=0; FORCE_REBUILD=0; KEEP_TMP=0
NET=""; RUN_USER="0:0"; SELINUX_MODE="auto"; IMAGE_IS_REUSED=0; SKIP_NATIVE=0
SEED=0; ROOMS_SPEC=""; MIN_DENSITY="0.95"; DATA_ARCHIVE=""; DATA_OVERLAY=""; FORCE_REPLAY=0
TMPDIR_RUN=""; DOCKER=(docker); DOCK_FLAGS=(); MOUNT_SUFFIX=""; EXTRA_ARGS=()
PG_DSN=""; PG_NET=""; PG_CTR=""; JSRC=()

LOG_FILE="${TMPDIR:-/tmp}/maxxiang-audit.log"
if [ -t 1 ]; then
  C_R=$'\033[31m'; C_G=$'\033[32m'; C_Y=$'\033[33m'; C_B=$'\033[34m'; C_C=$'\033[36m'; C_W=$'\033[1m'; C_0=$'\033[0m'
else
  C_R=""; C_G=""; C_Y=""; C_B=""; C_C=""; C_W=""; C_0=""
fi
_ts()  { date '+%F %T'; }
_log() { printf '%s %s\n' "$(_ts)" "$*" >>"$LOG_FILE" 2>/dev/null || true; }
say()  { printf '%s\n' "$*";                      _log "INFO  $*"; }
step() { printf '\n%s==>%s %s%s%s\n' "$C_B" "$C_0" "$C_W" "$*" "$C_0"; _log "STEP  $*"; }
ok()   { printf '%s ✔ %s%s\n' "$C_G" "$*" "$C_0"; _log "OK    $*"; }
warn() { printf '%s ⚠ %s%s\n' "$C_Y" "$*" "$C_0" >&2; _log "WARN  $*"; }
err()  { printf '%s ✘ %s%s\n' "$C_R" "$*" "$C_0" >&2; _log "ERR   $*"; }
die()  { err "$*"; err "详细日志：$LOG_FILE"; exit 1; }
on_err(){ local ec=$? ln=${1:-?}; err "第 ${ln} 行命令失败（退出码 $ec）：${BASH_COMMAND}"; err "详细日志：$LOG_FILE"; exit "$ec"; }
trap 'on_err $LINENO' ERR
trap 'echo; die "已被用户中断"' INT
cleanup() { trap - ERR; [ "$KEEP_TMP" -eq 1 ] || [ -z "$TMPDIR_RUN" ] || rm -rf "$TMPDIR_RUN"; return 0; }
trap cleanup EXIT

have() { command -v "$1" >/dev/null 2>&1; }
confirm() {
  local q="$1" def="${2:-Y}" a
  if [ "$ASSUME_YES" -eq 1 ]; then [ "$def" = "Y" ]; return; fi
  while :; do
    read -rp "$(printf '%s%s%s [%s]: ' "$C_C" "$q" "$C_0" "$( [ "$def" = Y ] && echo Y/n || echo y/N )")" a || a=""
    a="${a:-$def}"
    case "$a" in [Yy]*) return 0;; [Nn]*) return 1;; esac
  done
}
ask() { # ask 变量名 "提示" "默认值"
  local __v="$1" p="$2" d="${3:-}" a
  if [ "$ASSUME_YES" -eq 1 ]; then printf -v "$__v" '%s' "$d"; return; fi
  read -rp "$(printf '%s%s%s%s: ' "$C_C" "$p" "$C_0" "${d:+ [$d]}")" a || a=""
  printf -v "$__v" '%s' "${a:-$d}"
}

# ── 环境探测 ──────────────────────────────────────────────────────────────────
detect_docker() {
  have docker || die "未找到 docker 命令（本项目部署脚本可装：bash deploy-maxxiang.sh install）"
  if ! docker info >/dev/null 2>&1; then
    if [ "$(id -u)" -ne 0 ] && have sudo; then
      warn "当前用户无法直连 Docker 守护进程，改用 sudo docker"; DOCKER=(sudo docker)
      "${DOCKER[@]}" info >/dev/null 2>&1 || die "sudo docker 仍不可用：确认 dockerd 已启动"
    else
      die "Docker 守护进程不可达：先 systemctl start docker（或把用户加进 docker 组）"
    fi
  fi
  say "Docker 服务端版本：$("${DOCKER[@]}" version --format '{{.Server.Version}}' 2>/dev/null || echo '?')"
}

is_project_root() {
  [ -f "$1/window_audit/replay_harness.py" ] && [ -f "$1/backend_async/config.yaml" ] \
    && [ -f "$1/backend_async/app/predictor_bridge.py" ] && [ -f "$1/jiufa_data/spell_tamer_monitor.py" ]
}

locate_root() {   # 支持脚本放在项目根、window_audit/、或任意子目录
  if [ -n "$ROOT" ]; then
    ROOT="$(cd "$ROOT" 2>/dev/null && pwd)" || die "目录不存在：$ROOT"
    is_project_root "$ROOT" || die "指定目录不是 maxxiang 项目根：$ROOT"
  else
    local d cand
    for cand in "$(dirname "$SELF_PATH")" "$PWD"; do
      d="$cand"
      while :; do
        if is_project_root "$d"; then ROOT="$d"; break 2; fi
        [ "$d" = "/" ] && break
        d="$(dirname "$d")"
      done
    done
    [ -n "$ROOT" ] || die "未能从 $(dirname "$SELF_PATH") 逐级上溯找到项目根（用 --dir 指定）"
  fi
  [ -f "$ROOT/jiufa_data/spell_tamer_data.db" ] || warn "未见自带快照 jiufa_data/spell_tamer_data.db"
  say "项目根目录：$ROOT"
  mkdir -p "$ROOT/window_audit/out"
}

selinux_flags() {
  local mode="$SELINUX_MODE" enforce="Disabled"
  have getenforce && enforce="$(getenforce 2>/dev/null || echo Disabled)"
  [ "$mode" = auto ] && { [ "$enforce" = "Enforcing" ] && mode=disable || mode=off; }
  case "$mode" in
    off)     MOUNT_SUFFIX="";;
    disable) MOUNT_SUFFIX=""; DOCK_FLAGS+=(--security-opt label=disable);;
    relabel) MOUNT_SUFFIX=":z";;
    *) die "--selinux 取值应为 auto|disable|relabel|off";;
  esac
}

# ── 生产 PG 自动识别 ──────────────────────────────────────────────────────────
#  实地核查 backend_async/deploy/docker-compose.yml：postgres 服务**没有 ports 段**，
#  端口不发布到宿主机 → 宿主上 127.0.0.1:5432 必然连不上，--net host 也没用。
#  正确姿势：把审计容器接进 compose 自建的那张网络，用服务名 postgres 解析。
#  DSN 本就在 deploy/.env 的 STA_PG_DSN 里，不必让人手填密码。
redact_dsn() { printf '%s' "$1" | sed -E 's#(//[^:/]*):[^@]*@#\1:***@#'; }

detect_pg() {
  PG_DSN=""; PG_NET=""; PG_CTR=""
  local envf="$ROOT/backend_async/deploy/.env" line cid
  if [ -f "$envf" ]; then
    line="$(grep -m1 '^[[:space:]]*STA_PG_DSN=' "$envf" 2>/dev/null || true)"
    if [ -n "$line" ]; then
      PG_DSN="${line#*=}"; PG_DSN="${PG_DSN%$'\r'}"
      PG_DSN="$(printf '%s' "$PG_DSN" | sed -e 's/^"//' -e 's/"$//' -e "s/^'//" -e "s/'\$//")"
    fi
  fi
  line="$("${DOCKER[@]}" ps --format '{{.ID}} {{.Image}} {{.Names}}' 2>/dev/null \
          | awk '$2 ~ /^postgres(:|$)/ {print $1" "$3; exit}')" || line=""
  if [ -n "$line" ]; then
    cid="${line%% *}"; PG_CTR="${line#* }"
    PG_NET="$("${DOCKER[@]}" inspect -f '{{range $k,$v := .NetworkSettings.Networks}}{{$k}} {{end}}' \
              "$cid" 2>/dev/null | awk '{print $1}')" || PG_NET=""
  fi
}

# ── 镜像 ──────────────────────────────────────────────────────────────────────
image_exists() { "${DOCKER[@]}" image inspect "$1" >/dev/null 2>&1; }

resolve_image() {
  if [ -n "$IMAGE" ]; then image_exists "$IMAGE" || die "指定镜像不存在：$IMAGE"; ok "使用指定镜像：$IMAGE"; return; fi
  if [ "$FORCE_REBUILD" -eq 0 ]; then
    local c
    for c in ${REUSE_IMAGES[@]+"${REUSE_IMAGES[@]}"}; do
      if image_exists "$c"; then IMAGE="$c"; IMAGE_IS_REUSED=1
        ok "复用已部署的生产镜像：$IMAGE（runtime 与线上逐字一致，无需联网）"; return; fi
    done
    if image_exists "$AUDIT_IMAGE_LOCAL"; then IMAGE="$AUDIT_IMAGE_LOCAL"; ok "复用已构建的审计镜像：$IMAGE"; return; fi
  fi
  build_audit_image
}

build_audit_image() {
  step "构建审计镜像 $AUDIT_IMAGE_LOCAL（基于 $BASE_IMAGE，与生产同 runtime）"
  [ "$CN_MODE" -eq 1 ] && [ -z "$PIP_MIRROR" ] && PIP_MIRROR="$PYPI_CN_DEFAULT"
  TMPDIR_RUN="${TMPDIR_RUN:-$(mktemp -d "${TMPDIR:-/tmp}/maxxiang-audit.XXXXXX")}"
  {
    echo "FROM $BASE_IMAGE"
    echo "ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 TZ=Asia/Shanghai"
    echo "ARG PIP_INDEX_URL=https://pypi.org/simple"
    echo "RUN pip install --no-cache-dir -i \"\$PIP_INDEX_URL\" $PIN_YAML $PIN_REQUESTS \\"
    echo " && (pip install --no-cache-dir -i \"\$PIP_INDEX_URL\" $PIN_ASYNCPG \\"
    echo "     || echo '[warn] asyncpg 未装：judge --pg-dsn 不可用，其余功能不受影响')"
    echo "WORKDIR /repo/window_audit"
  } >"$TMPDIR_RUN/Dockerfile"
  local -a bargs=()
  [ -n "$PIP_MIRROR" ] && { bargs+=(--build-arg "PIP_INDEX_URL=$PIP_MIRROR"); say "PyPI 源：$PIP_MIRROR"; }
  "${DOCKER[@]}" build -t "$AUDIT_IMAGE_LOCAL" ${bargs[@]+"${bargs[@]}"} "$TMPDIR_RUN" 2>&1 | tee -a "$LOG_FILE" \
    || die "镜像构建失败（大陆网络可加 --cn 或 --pip-mirror <URL>）"
  IMAGE="$AUDIT_IMAGE_LOCAL"; ok "镜像就绪：$IMAGE"
}

# ── 容器执行 ──────────────────────────────────────────────────────────────────
build_flags() {
  DOCK_FLAGS=(--rm -i)          # -i 必须：heredoc 喂脚本时容器需接上 stdin
  selinux_flags
  DOCK_FLAGS+=(-v "$ROOT:/repo${MOUNT_SUFFIX}" -w /repo/window_audit --user "$RUN_USER")
  DOCK_FLAGS+=(-e STA_ENGINE_DIR=/repo/jiufa_data -e PYTHONDONTWRITEBYTECODE=1 -e PYTHONUNBUFFERED=1)
  [ -z "$DATA_OVERLAY" ] || DOCK_FLAGS+=(-v "$DATA_OVERLAY:/repo/jiufa_data${MOUNT_SUFFIX}")
  DOCK_FLAGS+=(--network "${NET:-bridge}")
  [ -t 0 ] && [ -t 1 ] && DOCK_FLAGS+=(-t) || true
}

map_sqlite_arg() {   # 仓库外的 --sqlite 路径自动只读挂进 /extdb
  EXTRA_ARGS=(); local -a out=() argv=("$@"); local i=0 n=$# a p d b
  while [ "$i" -lt "$n" ]; do
    a="${argv[$i]}"; p=""
    case "$a" in
      --sqlite) i=$((i+1)); [ "$i" -lt "$n" ] && p="${argv[$i]}";;
      --sqlite=*) p="${a#--sqlite=}";;
      *) out+=("$a"); i=$((i+1)); continue;;
    esac
    if [ -n "$p" ] && [ -f "$p" ]; then
      p="$(readlink -f "$p")"
      case "$p" in
        "$ROOT"/*) out+=(--sqlite "/repo${p#"$ROOT"}");;
        *) d="$(dirname "$p")"; b="$(basename "$p")"
           DOCK_FLAGS+=(-v "$d:/extdb:ro${MOUNT_SUFFIX:+,z}"); out+=(--sqlite "/extdb/$b")
           warn "外部库 $p → 只读挂到 /extdb（该库若有未合并的 -wal，只读打开可能失败）";;
      esac
    elif [ -n "$p" ]; then
      out+=(--sqlite "$p"); warn "--sqlite $p 在宿主机上不存在（README 里 /path/exported.db 只是占位符）"
    fi
    i=$((i+1))
  done
  EXTRA_ARGS=(${out[@]+"${out[@]}"})
}

dock() { # dock <脚本> [参数...]
  local script="$1"; shift
  build_flags; map_sqlite_arg ${@+"$@"}
  "${DOCKER[@]}" run ${DOCK_FLAGS[@]+"${DOCK_FLAGS[@]}"} --entrypoint python "$IMAGE" \
    "$script" ${EXTRA_ARGS[@]+"${EXTRA_ARGS[@]}"}
}

dock_stdin() { # dock_stdin [python 参数...] ；脚本体由调用方经 stdin 喂入
  build_flags; map_sqlite_arg ${@+"$@"}
  "${DOCKER[@]}" run ${DOCK_FLAGS[@]+"${DOCK_FLAGS[@]}"} --entrypoint python "$IMAGE" \
    - ${EXTRA_ARGS[@]+"${EXTRA_ARGS[@]}"}
}

run_step() { # run_step <输出文件> <脚本> [参数...]
  local f="$1"; shift
  if ! dock "$@" 2>&1 | tee "$f"; then KEEP_TMP=1; err "步骤失败：$*（输出保留在 $f）"; exit 1; fi
}

# ── 子命令 ────────────────────────────────────────────────────────────────────
cmd_doctor() {
  step "运行环境体检"
  say "镜像：$IMAGE$( [ "$IMAGE_IS_REUSED" -eq 1 ] && echo '（复用生产镜像）' )"
  dock_stdin <<'PY'
import sys, os, sqlite3
print(f"  Python        : {sys.version.split()[0]}   (需 ≥3.8；宿主 CentOS7 的 3.6 会四段报错)")
try:
    import yaml
    v = tuple(int(x) for x in yaml.__version__.split(".")[:2])
    print(f"  PyYAML        : {yaml.__version__}  {'OK(≥5.1 认星光面字符)' if v >= (5,1) else '过旧！<5.1 会拒 💎'}")
    with open("/repo/backend_async/config.yaml", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    print(f"  config.yaml   : 解析成功（💎 U+1F48E @字符310 已放行），prediction 段 {len(cfg['prediction'])} 项")
except Exception as e:
    print(f"  config.yaml   : 失败 → {type(e).__name__}: {e}")
for mod, note in (("requests", "引擎顶层硬依赖，缺失即 sys.exit(1)"), ("asyncpg", "judge --pg-dsn 用")):
    try:
        m = __import__(mod); print(f"  {mod:<14}: {getattr(m,'__version__','?')}（{note}）")
    except Exception:
        print(f"  {mod:<14}: 未装（{note}）")
e = os.environ.get("STA_ENGINE_DIR")
print(f"  STA_ENGINE_DIR: {e}  {'OK' if e=='/repo/jiufa_data' else '← 未指向仓库引擎，会回放镜像内旧引擎！'}")
db = "/repo/jiufa_data/spell_tamer_data.db"
if os.path.exists(db):
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        for r in con.execute("SELECT room_id,COUNT(*),MIN(start_ms),MAX(start_ms) FROM rounds "
                             "WHERE custom_id IS NOT NULL GROUP BY room_id"):
            h = (r[3]-r[2])/3600000
            print(f"  快照 room={r[0]:<9} {r[1]:>5} 局  跨度 {h:.2f}h" + ("  （<168h → 尚不足以裁决 72h 窗）" if h < 168 else ""))
        con.close()
    except Exception as ex:
        print(f"  快照读取失败 : {ex}")
else:
    print("  快照          : 缺失")
try:
    p = "/repo/window_audit/out/.wtest"; open(p, "w").close(); os.remove(p); print("  out/ 写权限   : OK")
except Exception as ex:
    print(f"  out/ 写权限   : 失败 → {ex}")
PY
  ok "体检完成"
}

cmd_config() {
  step "配置耦合体检（train_window_hours × max_train × retention.days）"
  local rc=0
  dock_stdin <<'PY' || rc=$?
import os, yaml
STEP = 50001
with open("/repo/backend_async/config.yaml", encoding="utf-8") as f:
    cfg = yaml.safe_load(f)
pred = cfg.get("prediction", {}) or {}
twh  = float(pred.get("train_window_hours", 24.0) or 0)
mt   = int(pred.get("max_train", 5000))
ryd  = float((cfg.get("retention") or {}).get("days", 1))

need = int(twh*3600*1000/STEP) + 1 if twh > 0 else 0
cover = mt*STEP/3600000.0
print(f"  config.yaml  train_window_hours = {twh:g} h")
print(f"               max_train          = {mt} 局  （可覆盖 {cover:.2f} h）")
print(f"               retention.days     = {ryd:g} 天 （= {ryd*24:.0f} h）")
print(f"  节拍         ROUND_STEP={STEP}ms → {3600000/STEP:.4f} 局/h；{twh:g}h 窗需 {need} 局\n")

bad = 0
if twh > 0 and mt < need:
    bad += 1
    print(f"  ✘ max_train={mt} < {need}：训练窗被**静默截短**到 {cover:.2f}h —— 改了窗口等于没改。")
    print(f"    生产代码双重截短（均已核对）：db.py sequence() 的 SQL LIMIT，")
    print(f"    以及 spell_tamer_monitor.py 的 `seq = seq[-self.cfg.max_train:]`（搜代码原文，勿按行号）。")
    print(f"    建议 max_train ≥ {int(need*1.15//100*100)}（含 15% 抖动余量）")
else:
    print(f"  ✔ max_train 覆盖得住训练窗（{cover:.2f}h ≥ {twh:g}h）")

if 0 < ryd*24 < twh:
    bad += 1; print(f"  ✘ retention {ryd*24:.0f}h < 训练窗 {twh:g}h：样本被保留窗截短（worker 会打 WARNING）")
elif ryd > 0 and ryd*24 < twh + 96:
    print(f"  ⚠ retention {ryd*24:.0f}h < 训练窗+96h评估期({twh+96:.0f}h)：裁决器会一直标〔不可裁决〕")
else:
    print(f"  ✔ retention 覆盖得住「训练窗 + 96h 评估期」")

envp = "/repo/backend_async/deploy/.env"
print()
if os.path.exists(envp):
    val = None
    for line in open(envp, encoding="utf-8", errors="replace"):
        line = line.strip()
        if line.startswith("STA_RETENTION_DAYS="):
            val = line.split("=", 1)[1].strip().strip('"').strip("'")
    if val is None:
        print(f"  deploy/.env  未设 STA_RETENTION_DAYS → 实际生效 = config.yaml 的 {ryd:g} 天")
    else:
        print(f"  deploy/.env  STA_RETENTION_DAYS={val}  ← **环境变量优先级高于 config.yaml**")
        try:
            if float(val) < 7:
                bad += 1
                print(f"  ✘ 实际只保留 {val} 天！config.yaml 写 7 天是**无效**的（settings.py 的 `s.retention.days = _env_float(\"STA_RETENTION_DAYS\", s.retention.days)` 优先级链）。")
                print(f"    .env.example 出厂就是 1；`update` 会原样保留旧 .env —— 这正是攒不满 7 天的元凶。")
                print(f"    改法：编辑 {envp} 改成 7，然后 cd backend_async/deploy && docker compose up -d")
        except ValueError:
            pass
else:
    print(f"  deploy/.env  未找到（{envp}）：无法核对 STA_RETENTION_DAYS 覆盖层")
print("  注：管理台 config_revisions 快照的优先级还在 env 之上，最终以管理台「配置中枢」显示为准。")
raise SystemExit(1 if bad else 0)
PY
  if [ "$rc" -ne 0 ]; then err "配置耦合体检发现阻塞项（见上），修好再攒数据"; return "$rc"; fi
  ok "配置耦合体检通过"
}

cmd_replay() { [ $# -ge 1 ] || die "用法：$SELF_NAME replay <房号> [--hours 72]"; step "回放房 $1"; dock replay_harness.py "$@"; }
cmd_cold() {
  need_archive_for_rooms; setup_overlay; ensure_replays || return 1
  step "冷门规律性/顺序性检验（房 $ROOMS，数据源 $(data_tag)）"
  dock analyze_cold.py "$ROOMS"
}
cmd_extra() {
  need_archive_for_rooms; setup_overlay; ensure_replays || return 1
  step "独立性 / 配对分歧 / 反事实扰动（房 $ROOMS，数据源 $(data_tag)）"
  dock analyze_extra.py "$ROOMS"
}
cmd_judge()  {
  step "训练窗裁决器（4.9.5 起为公平域 + 配对口径）"
  case " $* " in *" --pg-dsn "*) [ "${NET:-bridge}" = none ] && die "--pg-dsn 需要网络：去掉 --net none 或用 --net host";; esac
  dock window_judge.py "$@"
}

cmd_judge7() {   # 正式裁决：原生裁决器 + 剔除预热期的同批次对比
  local -a src=()
  case " $* " in *" --pg-dsn "*|*" --sqlite "*) src=("$@");; *) src=();; esac
  [ ${#src[@]} -gt 0 ] || src=()
  if [ "$SKIP_NATIVE" -eq 1 ]; then
    say "（已跳过 A 段裁决器，耗时约减半；B 段与之同口径，可独立下结论）"
  else
    step "正式裁决 A：window_judge.py（4.9.5 起本身即公平域 + 配对 McNemar 精确检验）"
    cmd_judge --rooms "$ROOMS" --windows "$WINDOWS" ${src[@]+"${src[@]}"} || true
  fi
  step "正式裁决 B：剔除预热期的同批次对比（推荐据此下结论）"
  say "  4.9.5 前的裁决器对**全部**已结算局统计命中率、未剔除窗口预热期，"
  say "  数据前段长窗还在半饥饿状态 → 系统性低估长窗；本 B 段就是当时的补救。"
  say "  4.9.5 起该缺陷已修进 window_judge.py 本体（公平域 + 配对精确二项），"
  say "  于是 A 与 B 现在是**同一口径的两份独立实现**：A 用精确二项，B 用正态近似，"
  say "  过滤锚点也差一局（A 按目标局、B 按生成局）。两者结论不一致才是要查的信号。"
  dock_stdin --rooms "$ROOMS" --windows "$WINDOWS" ${src[@]+"${src[@]}"} <<'PY'
import os, sys, math, argparse
sys.path.insert(0, "/repo/window_audit")
import replay_harness as rh
import window_judge as wj

ap = argparse.ArgumentParser()
ap.add_argument("--rooms", default="1275859,2678075,3746870")
ap.add_argument("--windows", default="24,72")
ap.add_argument("--sqlite", default=rh.DEFAULT_DB)
ap.add_argument("--pg-dsn", default=None)
a = ap.parse_args()
wins = [float(x) for x in a.windows.split(",")]
warm = max(wins)
rooms = [r.strip() for r in a.rooms.split(",") if r.strip()]
print(f"数据源: {'PG ' + a.pg_dsn.split('@')[-1] if a.pg_dsn else a.sqlite}")
print(f"口径: 共用评估起点 = 各房首局 + {warm:g}h（两窗都喂饱后才开始计分）\n")

def evaluate(room, rounds, hours, eval_from_ms):
    cfg = dict(rh.PRED_CFG); cfg["train_window_hours"] = hours
    need = int(hours*3600*1000/rh.STEP) + 8 if hours > 0 else 10**7
    cfg["max_train"] = max(int(cfg.get("max_train", 5000)), need)
    recs, _ = rh.replay(room, rounds, cfg)
    starts = [r[2] for r in rounds]
    sel = [r for r in recs if r["actual"] is not None and starts[r["gen_after_idx"]] >= eval_from_ms]
    kr = [r for r in sel if r["k"] >= 1]
    return {"n": len(sel), "hit4": sum(1 for r in sel if r["hit"] != "miss"),
            "kn": len(kr), "cold": sum(1 for r in kr if r["actual"] in r["coldset"]),
            "mt": cfg["max_train"],
            "hits": {r["target"]: (r["hit"] != "miss") for r in sel}}

agg = {h: {"n":0,"hit4":0,"cold":0,"kn":0} for h in wins}; usable = 0
paired = {h: {} for h in wins}          # 窗口 → {局号: 是否命中}，供配对检验
for room in rooms:
    rounds = wj.rounds_from_pg(a.pg_dsn, room) if a.pg_dsn else rh.load_rounds(room, a.sqlite)
    if len(rounds) < 200:
        print(f"[{room}] 仅 {len(rounds)} 局，跳过"); continue
    span = (rounds[-1][2]-rounds[0][2])/3600000
    ev = span - warm
    flag = "" if ev >= 96 else f"  ← 评估期仅 {max(ev,0):.1f}h（<96h，结论仅供参考）"
    print(f"[{room}] {len(rounds)} 局, 跨度 {span:.1f}h → 评估期 {max(ev,0):.1f}h{flag}")
    if ev <= 0:
        print("    评估期为 0：跨度还没超过最长窗口，无法裁决\n"); continue
    usable += 1
    ef = rounds[0][2] + int(warm*3600*1000)
    for h in wins:
        r = evaluate(room, rounds, h, ef)
        p = r["hit4"]/r["n"] if r["n"] else 0
        print(f"    窗口{h:>5g}h: 四码 {r['hit4']}/{r['n']}={p*100:.2f}%  冷门 {r['cold']}/{r['kn']}"
              f"  (实验口径 max_train={r['mt']})")
        g = agg[h]; g["n"]+=r["n"]; g["hit4"]+=r["hit4"]; g["cold"]+=r["cold"]; g["kn"]+=r["kn"]
        paired[h].update({(room, t): v for t, v in r["hits"].items()})
if not usable:
    print("\n无可用房 → 继续攒数据，勿据此改配置。"); raise SystemExit(2)

print("─"*72)
rows = []
for h in wins:
    g = agg[h]
    if not g["n"]: continue
    p = g["hit4"]/g["n"]; rows.append((h,p,g))
    print(f"合计 窗口{h:>5g}h: 四码 {p*100:.2f}% ({g['hit4']}/{g['n']})  冷门 {g['cold']}/{g['kn']}")
if len(rows) >= 2:
    rows.sort(key=lambda x: -x[1])
    (h1,p1,g1),(h2,p2,g2) = rows[0], rows[1]
    se = math.sqrt(p1*(1-p1)/g1["n"] + p2*(1-p2)/g2["n"]); d = p1-p2
    print(f"差值 {d*100:+.2f}pp   非配对二项 2σ = {2*se*100:.2f}pp   z = {d/se if se else 0:.2f}")
    cur_mt = int(rh.PRED_CFG.get("max_train", 5000))

    # ── 配对 McNemar：两臂打的是同一批局，非配对二项过于保守（功效被浪费）──
    #    同目录 analyze_extra.py 对同类问题用的正是 McNemar；window_judge.py 用的是非配对。
    sig = None
    ha, hb = paired[h1], paired[h2]
    common = set(ha) & set(hb)
    if common:
        bb = sum(1 for t in common if ha[t] and not hb[t])
        cc = sum(1 for t in common if hb[t] and not ha[t])
        nd = bb + cc
        conc = (len(common) - nd) / len(common) * 100
        print(f"配对 McNemar: 同批 {len(common)} 局，一致 {conc:.1f}%，"
              f"分歧 {nd} 局（{h1:g}h 独中 {bb} / {h2:g}h 独中 {cc}）")
        if nd:
            z = (abs(bb - cc) - 1) / math.sqrt(nd)
            pv = math.erfc(z / math.sqrt(2))
            se_p = math.sqrt(nd) / len(common)
            print(f"              配对 2σ = {2*se_p*100:.2f}pp（比非配对紧 "
                  f"{(2*se)/(2*se_p) if se_p else 0:.1f}×）  z={z:.2f}  双侧 p={pv:.4f}")
            sig = pv < 0.05
    if sig is True:
        need = int(h1*3600*1000/rh.STEP) + 1
        rec = int(need*1.15//100*100)
        print(f"\n结论: 窗口 {h1:g}h 显著更优，落地要**同时**改两处：")
        print(f"   prediction.train_window_hours: {rh.PRED_CFG.get('train_window_hours')} → {h1:g}")
        print(f"   prediction.max_train         : {cur_mt} → {rec}   （{h1:g}h 理论需 {need} 局，+15% 抖动余量）")
        print(f"   只改前者不改后者 = 白改（会被静默截回 {cur_mt*50001/3600000:.1f}h）。")
    elif sig is False and d > 2 * (math.sqrt((sum(1 for t in common if ha[t]!=hb[t])))/max(len(common),1)):
        print(f"\n结论: 配对检验 p≥0.05，未达显著 → **维持现状**（{h2:g}h 与 {h1:g}h 无法区分）；")
        print(f"   注意方向：{h1:g}h 一致占优 {d*100:.2f}pp，若要下定论需更多数据或更多房。")
        print(f"   prediction.max_train 保持 {cur_mt} 不动。")
    else:
        print(f"\n结论: 差异在噪声带内 → **维持现状**（不改 train_window_hours）；")
        print(f"   prediction.max_train 保持 {cur_mt} 不动（24h 仅需约 1728 局，已有 {cur_mt/1728:.1f}× 余量）。")
PY
}

# ── 数据源覆盖 ────────────────────────────────────────────────────────────────
#  analyze_cold.py / analyze_extra.py 的 DB 路径是写死的（ROOT/jiufa_data/
#  spell_tamer_data.db），没有 --db 参数 —— 只有 replay_harness.py 有。
#  为了在**不改这两个受审文件**的前提下让它们读归档，这里造一个临时目录，
#  内含「引擎文件 + 归档库(改名为 spell_tamer_data.db)」，整个覆盖挂到
#  容器内 /repo/jiufa_data。STA_ENGINE_DIR 指向同一路径，引擎照样能找到。
setup_overlay() {
  [ -n "$DATA_ARCHIVE" ] || return 0
  [ -z "$DATA_OVERLAY" ] || return 0
  [ -f "$DATA_ARCHIVE" ] || die "归档文件不存在：$DATA_ARCHIVE"
  DATA_OVERLAY="$(mktemp -d "${TMPDIR:-/tmp}/maxx-data.XXXXXX")"
  cp "$ROOT/jiufa_data/spell_tamer_monitor.py" "$DATA_OVERLAY/" || die "复制引擎文件失败"
  cp "$DATA_ARCHIVE" "$DATA_OVERLAY/spell_tamer_data.db" || die "复制归档失败"
  chmod -R a+rX "$DATA_OVERLAY"
  say "  数据源覆盖：$(basename "$DATA_ARCHIVE") → 容器内 /repo/jiufa_data/spell_tamer_data.db"
}

data_tag() { [ -n "$DATA_ARCHIVE" ] && printf 'archive:%s' "$(basename "$DATA_ARCHIVE")" || printf 'bundled'; }

need_archive_for_rooms() {   # 房号不在自带快照里时，必须给归档
  [ "$ROOMS" = "$DEFAULT_ROOMS" ] && return 0
  [ -n "$DATA_ARCHIVE" ] && return 0
  local def="$ROOT/window_audit/archive/rounds_archive.db"
  if [ -f "$def" ]; then
    warn "当前房号不在自带 25h 快照里，而 analyze_*.py 的库路径写死在 jiufa_data 下"
    ask DATA_ARCHIVE "  用哪个归档" "$def"
  else
    die "当前房号($ROOMS)不在自带快照里。请先跑菜单 10) 从 PG 导出归档，或 --data <归档.db>"
  fi
}

ensure_replays() {   # 保证 out/ 里的明细来自「当前房号 + 当前数据源」，否则重跑
  local marker="$ROOT/window_audit/out/.source" want cur r
  want="$(data_tag)|$ROOMS"
  cur="$(cat "$marker" 2>/dev/null || true)"
  if [ "$FORCE_REPLAY" -eq 1 ] || [ "$cur" != "$want" ]; then
    [ -n "$cur" ] && warn "out/ 里的明细来自「$cur」，与当前「$want」不符 → 作废重跑"
    rm -f "$ROOT"/window_audit/out/replay_*.json
  fi
  for r in ${ROOMS//,/ }; do
    [ -f "$ROOT/window_audit/out/replay_$r.json" ] && continue
    step "回放房 $r（为后续检验准备明细）"
    dock replay_harness.py "$r" || return 1
  done
  printf '%s' "$want" > "$marker"
}

pick_rooms() {   # pick_rooms <抽几个> <最小跨度h> <最小密度>
  local want="$1" min_span="$2" min_dens="$3" mode src raw picked
  detect_pg
  if [ -n "$PG_DSN" ]; then
    mode="pg"; src="$PG_DSN"; [ -n "$PG_NET" ] && NET="$PG_NET"
  else
    mode="sqlite"; src="/repo/jiufa_data/spell_tamer_data.db"
    warn "未识别到生产 PG，改从仓库自带快照抽（只有 3 个房，随机意义有限）"
  fi
  [ "$SEED" -gt 0 ] 2>/dev/null || SEED=$(( $(date +%s) % 1000000 ))
  step "随机抽取 $want 个房（seed=$SEED，资格：跨度≥${min_span}h 且 数据密度≥${min_dens}）"
  raw="$(dock_stdin "$mode" "$src" "$want" "$min_span" "$min_dens" "$SEED" 400 <<'PY'
import sys, random, sqlite3, asyncio
STEP = 50001                       # 引擎 ROUND_STEP：一局 50.001s
mode, src, want, min_span, min_dens, seed, max_probe = (
    sys.argv[1], sys.argv[2], int(sys.argv[3]), float(sys.argv[4]),
    float(sys.argv[5]), int(sys.argv[6]), int(sys.argv[7]))

def judge(n, a, b):
    """返回 (跨度h, 密度比)。密度 = 实有局数 / 该跨度理论应有局数。
       发现房走 GameHistory 批量入库(3.5.0)，漏局会拉低密度；序列不完整会毁掉回放。"""
    if not n or a is None or b is None or b <= a:
        return 0.0, 0.0
    span_h = (b - a) / 3600000.0
    theo = (b - a) / STEP + 1
    return span_h, (n / theo if theo else 0.0)

def report(picked, probed, cands, rejected):
    print(f"  候选池 {cands} 房 → 随机探测 {probed} 个 → 合格 {len(picked)} 个"
          f"（淘汰 {rejected}：跨度不足或有漏局）")
    if picked:
        print(f"  {'房号':<12}{'局数':>8}{'跨度':>9}{'密度':>8}")
        for rid, n, sp, d in picked:
            print(f"  {rid:<12}{n:>8}{sp:>8.1f}h{d:>8.3f}")
    print("__ROOMS__=" + ",".join(r[0] for r in picked))

if mode == "sqlite":
    con = sqlite3.connect(f"file:{src}?mode=ro", uri=True)
    cands = [r[0] for r in con.execute("SELECT DISTINCT room_id FROM rounds")]
    rng = random.Random(seed); rng.shuffle(cands)
    picked, probed, rej = [], 0, 0
    for rid in cands:
        if len(picked) >= want or probed >= max_probe: break
        probed += 1
        n, a, b = con.execute("SELECT COUNT(*), MIN(start_ms), MAX(start_ms) FROM rounds "
                              "WHERE room_id=? AND custom_id IS NOT NULL", (rid,)).fetchone()
        sp, d = judge(n, a, b)
        if sp >= min_span and d >= min_dens: picked.append((rid, n, sp, d))
        else: rej += 1
    con.close(); report(picked, probed, len(cands), rej)
else:
    try:
        import asyncpg
    except ImportError:
        print("  容器内没有 asyncpg：请用已部署的生产镜像（deploy-worker）"); raise SystemExit(3)
    async def go():
        con = await asyncpg.connect(src)
        # 候选池取自两张小表（策展名录 + 自动发现），避免对上亿行的 rounds 做全表 GROUP BY
        cands = [r["room_id"] for r in await con.fetch(
            "SELECT room_id FROM rooms WHERE active UNION SELECT room_id FROM discovered_rooms")]
        rng = random.Random(seed); rng.shuffle(cands)
        picked, probed, rej = [], 0, 0
        for rid in cands:                      # 逐房走 (room_id, round_id) 主键索引，很快
            if len(picked) >= want or probed >= max_probe: break
            probed += 1
            row = await con.fetchrow(
                "SELECT COUNT(*) AS n, MIN(start_ms) AS a, MAX(start_ms) AS b FROM rounds "
                "WHERE room_id=$1 AND custom_id IS NOT NULL", rid)
            sp, d = judge(row["n"], row["a"], row["b"])
            if sp >= min_span and d >= min_dens: picked.append((rid, row["n"], sp, d))
            else: rej += 1
        await con.close(); report(picked, probed, len(cands), rej)
    asyncio.run(go())
PY
)" || { err "抽房失败"; return 1; }
  printf '%s\n' "$raw" | grep -v '^__ROOMS__='
  picked="$(printf '%s\n' "$raw" | sed -n 's/^__ROOMS__=//p')"
  [ -n "$picked" ] || return 2
  ROOMS="$picked"
  ok "本次房号：$ROOMS"
  say "  复现这次抽样：--rooms random:$want --seed $SEED"
}

resolve_rooms() {   # ROOMS = random[:N] 时实地抽取；带宽松兜底
  case "$ROOMS" in random|random:*) ;; *) return 0;; esac
  local want=3 strict
  case "$ROOMS" in random:*) want="${ROOMS#random:}";; esac
  ROOMS_SPEC="$ROOMS"
  strict="$(awk -v w="$WINDOWS" 'BEGIN{m=0;n=split(w,a,",");for(i=1;i<=n;i++)if(a[i]+0>m)m=a[i]+0;print m+96}')"
  pick_rooms "$want" "$strict" "$MIN_DENSITY" && return 0
  warn "按裁决口径（跨度≥${strict}h）没抽到足够的房，放宽到 跨度≥12h / 密度≥0.90 重试"
  ROOMS="$ROOMS_SPEC"
  pick_rooms "$want" 12 0.90 || die "候选池里没有任何合格房：先跑 8) 看看库里到底有什么"
}

cmd_pgstat() {   # 看生产 PG 攒到什么程度了：还差多久能裁决
  detect_pg
  [ -n "$PG_DSN" ] || ask PG_DSN "  PG DSN" ""
  [ -n "$PG_DSN" ] || die "无 DSN：deploy/.env 里没有 STA_PG_DSN，也未手动提供"
  [ -n "$PG_NET" ] && NET="$PG_NET"
  step "生产 PG 数据进度（DSN $(redact_dsn "$PG_DSN")${PG_NET:+ ，网络 $PG_NET}）"
  dock_stdin "$PG_DSN" "$WINDOWS" "$ROOMS" <<'PY'
import sys, asyncio
try:
    import asyncpg
except ImportError:
    print("  容器内没有 asyncpg：请用已部署的生产镜像（deploy-worker/maxxiang-worker），"
          "或用菜单 13) 重建镜像后重试"); raise SystemExit(3)
dsn, wins, rooms = sys.argv[1], [float(x) for x in sys.argv[2].split(",")], sys.argv[3]
need_h = max(wins) + 96.0
watch = [r.strip() for r in rooms.split(",") if r.strip()]

async def main():
    con = await asyncpg.connect(dsn)
    tot = await con.fetchval("SELECT COUNT(DISTINCT room_id) FROM rounds")
    rows = await con.fetch(
        "SELECT room_id, COUNT(*) AS n, MIN(start_ms) AS a, MAX(start_ms) AS b "
        "FROM rounds WHERE custom_id IS NOT NULL GROUP BY room_id ORDER BY COUNT(*) DESC LIMIT 40")
    await con.close()
    print(f"  库里共有 {tot} 个房有出怪行；下表按局数取前 {len(rows)} 个\n")
    print(f"  {'房号':<12}{'局数':>8}  {'跨度':>9}   可裁决门槛 = 最长窗{max(wins):g}h + 96h 评估期 = {need_h:g}h")
    ready = 0
    for r in rows:
        span = (r["b"] - r["a"]) / 3600000.0
        mark = "★" if r["room_id"] in watch else " "
        if span >= need_h:
            note = "✔ 可裁决"; ready += 1
        else:
            lack = need_h - span
            note = f"还差 {lack:.1f}h（约 {lack/24:.1f} 天）"
        print(f" {mark}{r['room_id']:<12}{r['n']:>8}  {span:>7.1f}h   {note}")
    print(f"\n  ★ = 本次要裁决的房（--rooms）；其中可裁决 {sum(1 for r in rows if r['room_id'] in watch and (r['b']-r['a'])/3600000.0 >= need_h)}/{len(watch)}")
    if ready == 0:
        print("  → 还没到点。retention=7 天上限恰好 168h，与 72h 窗的门槛 168h 正好相等，")
        print("    刚清理完那一瞬会差一点点；可临时把 retention 调到 8 天，或用菜单 10) 定期导出归档。")
asyncio.run(main())
PY
}

cmd_export() {   # 从生产 PG 增量导出到 SQLite 归档（绕开 retention 的滚动删除）
  detect_pg
  [ -n "$PG_DSN" ] || ask PG_DSN "  PG DSN" ""
  [ -n "$PG_DSN" ] || die "无 DSN"
  [ -n "$PG_NET" ] && NET="$PG_NET"
  local arch="${1:-/repo/window_audit/archive/rounds_archive.db}"
  step "导出生产 PG → SQLite 归档（增量合并，可反复跑）"
  say "  归档文件：${arch/\/repo/$ROOT}"
  dock_stdin "$PG_DSN" "$ROOMS" "$arch" <<'PY'
import sys, os, asyncio, sqlite3
try:
    import asyncpg
except ImportError:
    print("  容器内没有 asyncpg：请用已部署的生产镜像（deploy-worker/maxxiang-worker）"); raise SystemExit(3)
dsn, rooms, out = sys.argv[1], [r.strip() for r in sys.argv[2].split(",") if r.strip()], sys.argv[3]
os.makedirs(os.path.dirname(out), exist_ok=True)
db = sqlite3.connect(out)
db.execute("""CREATE TABLE IF NOT EXISTS rounds(
    room_id TEXT NOT NULL, round_id INTEGER NOT NULL, custom_id INTEGER,
    start_ms INTEGER, draw_ms INTEGER, PRIMARY KEY(room_id, round_id))""")
db.commit()
before = db.execute("SELECT COUNT(*) FROM rounds").fetchone()[0]

async def main():
    con = await asyncpg.connect(dsn)
    total = 0
    for room in rooms:
        rows = await con.fetch(
            "SELECT room_id, round_id, custom_id, start_ms, draw_ms FROM rounds "
            "WHERE room_id=$1 AND custom_id IS NOT NULL ORDER BY round_id", str(room))
        db.executemany("INSERT OR IGNORE INTO rounds VALUES (?,?,?,?,?)",
                       [(r["room_id"], r["round_id"], r["custom_id"], r["start_ms"], r["draw_ms"]) for r in rows])
        db.commit(); total += len(rows)
        print(f"  [{room}] PG 取回 {len(rows)} 行")
    await con.close()
    print(f"\n  本次自 PG 取回 {total} 行；归档 {before} → {db.execute('SELECT COUNT(*) FROM rounds').fetchone()[0]} 行")
    print(f"  {'房号':<12}{'归档局数':>10}  {'归档跨度':>10}")
    for room, n, a, b in db.execute(
            "SELECT room_id, COUNT(*), MIN(start_ms), MAX(start_ms) FROM rounds GROUP BY room_id"):
        print(f"  {room:<12}{n:>10}  {(b-a)/3600000.0:>8.1f}h")
    print("\n  用法：菜单 9) 正式裁决 → 数据源选 2)，路径填上面这个归档文件。")
    print("  每天跑一次本项，归档就会**越过 retention 的滚动删除持续增长**，不再受 168h 天花板限制。")
asyncio.run(main())
PY
}

cmd_shell() { step "进入容器（/repo/window_audit）"; build_flags; "${DOCKER[@]}" run ${DOCK_FLAGS[@]+"${DOCK_FLAGS[@]}"} --entrypoint bash "$IMAGE"; }

cmd_clean() {
  local d="$ROOT/window_audit/out"
  [ -d "$d" ] || { ok "无产物可清理"; return; }
  confirm "确认删除 $d 下全部回放产物？" Y || { say "已取消"; return; }
  rm -rf "${d:?}"/*; ok "已清理 $d"
}

cmd_all() {
  local r
  for r in ${ROOMS//,/ }; do step "回放房 $r"; dock replay_harness.py "$r"; done
  cmd_cold; cmd_extra
  if [ "$ROOMS" = "$DEFAULT_ROOMS" ]; then cmd_judge; else cmd_judge --rooms "$ROOMS"; fi
}

T_DESC=(); T_OK=(); T_WANT=()
chk() { T_DESC+=("$1"); T_WANT+=("$3"); if grep -Fq -- "$3" "$2" 2>/dev/null; then T_OK+=(1); else T_OK+=(0); fi; }

cmd_test() {
  [ "$ROOMS" = "$DEFAULT_ROOMS" ] || die "test 的基线只对默认三房有效；自定义 --rooms 请用 all"
  [ -n "$NET" ] || NET="none"
  TMPDIR_RUN="${TMPDIR_RUN:-$(mktemp -d "${TMPDIR:-/tmp}/maxxiang-audit.XXXXXX")}"
  local o="$TMPDIR_RUN"
  step "① 逐房回放（生产窗口 24h，网络已断开：--network $NET）"
  run_step "$o/r1.txt" replay_harness.py 2678075
  run_step "$o/r2.txt" replay_harness.py 1275859
  run_step "$o/r3.txt" replay_harness.py 3746870
  step "② 冷门规律性/顺序性检验";      run_step "$o/cold.txt"  analyze_cold.py
  step "③ 独立性/配对分歧/反事实扰动"; run_step "$o/extra.txt" analyze_extra.py
  step "④ 裁决器演示";                run_step "$o/judge.txt" window_judge.py

  printf '%s|%s' "$(data_tag)" "$ROOMS" > "$ROOT/window_audit/out/.source"
  chk "房2678075 四码命中率 54.20%"        "$o/r1.txt"    "四码命中率=54.20%"
  chk "房1275859 四码命中率 53.23%"        "$o/r2.txt"    "四码命中率=53.23%"
  chk "房3746870 四码命中率 53.70%"        "$o/r3.txt"    "四码命中率=53.70%"
  chk "三房合并冷门命中 4127"              "$o/cold.txt"  "引擎冷门命中=4127"
  chk "同k随机基线 3690.9±47.7"            "$o/cold.txt"  "同k随机=3690.9±47.7"
  chk "冷门显著性 z=+9.15"                 "$o/cold.txt"  "z=+9.15"
  chk "与24h频率top-k配对分歧显著(轮换取舍)" "$o/extra.txt" "McNemar双侧p≈0.000"
  chk "shuffle 后一致率 6.9%（非固定顺序）"  "$o/extra.txt" "shuffle: 冷门组合一致率=6.9%"
  chk "reverse 后一致率 7.9%（非固定顺序）"  "$o/extra.txt" "reverse: 冷门组合一致率=7.9%"
  chk "同数据重跑逐字节确定"                "$o/extra.txt" "同数据重跑输出完全一致(确定性): True"
  chk "裁决器如实标记〔不可裁决〕"           "$o/judge.txt" "存在不可裁决窗口"

  printf '\n%s══ 与 README 首轮审计基线（2026-07-18）比对 ══%s\n' "$C_W" "$C_0"
  local i fail=0
  for i in "${!T_DESC[@]}"; do
    if [ "${T_OK[$i]}" -eq 1 ]; then printf '  %s✔%s %s\n' "$C_G" "$C_0" "${T_DESC[$i]}"
    else printf '  %s✘%s %s  ← 未匹配到「%s」\n' "$C_R" "$C_0" "${T_DESC[$i]}" "${T_WANT[$i]}"; fail=$((fail+1)); fi
  done
  printf '%s──────────────────────────────────────────────────────────%s\n' "$C_W" "$C_0"
  if [ "$fail" -eq 0 ]; then
    ok "全部 ${#T_DESC[@]} 项与基线逐字吻合 —— 工具包在 Docker 中复现成功"
    say "  明细产物：$ROOT/window_audit/out/"
  else
    KEEP_TMP=1; err "$fail/${#T_DESC[@]} 项与基线不符；原始输出保留在 $o"; exit 1
  fi
}

# ── 交互式菜单 ────────────────────────────────────────────────────────────────
pause_key() { [ "$ASSUME_YES" -eq 1 ] && return 0; read -rp "$(printf '\n%s回车返回菜单…%s' "$C_C" "$C_0")" _ || true; }

ask_source() {   # 交互选择数据源 → 结果写入全局 JSRC（必要时顺带切 NET）
  JSRC=(); local c dsn p
  detect_pg
  printf '  数据源：\n'
  if [ -n "$PG_DSN" ] && [ -n "$PG_NET" ]; then
    printf '    %s1) 生产 PG（已自动识别，无需手填）%s\n' "$C_W" "$C_0"
    printf '       DSN  %s\n       容器 %s   网络 %s\n' "$(redact_dsn "$PG_DSN")" "$PG_CTR" "$PG_NET"
  elif [ -n "$PG_DSN" ]; then
    printf '    1) 生产 PG（.env 里读到 DSN，但未找到 postgres 容器网络）\n'
  else
    printf '    1) 生产 PG（未能自动识别，需手填 DSN）\n'
  fi
  printf '    2) 已导出的 SQLite 归档文件\n'
  printf '    3) 仓库自带 25h 快照（仅演示流程，必然〔不可裁决〕）\n'
  ask c "  选择" "1"
  case "$c" in
    1) if [ -z "$PG_DSN" ]; then
         warn "compose 未把 PG 端口发布到宿主机，DSN 里的主机名应是服务名 postgres"
         ask dsn "  PG DSN" "postgresql://star:口令@postgres:5432/spelltamer"; PG_DSN="$dsn"
       fi
       [ -n "$PG_DSN" ] || { warn "未提供 DSN，改用自带快照"; return 0; }
       if [ -n "$PG_NET" ]; then
         NET="$PG_NET"; say "  → 审计容器将接入 compose 网络 $PG_NET（PG 端口未对宿主机暴露，只能这样连）"
       else
         warn "未找到 postgres 容器：若栈没起来或网络名特殊，可加 --net <网络名> 手动指定"
       fi
       JSRC=(--pg-dsn "$PG_DSN");;
    2) ask p "  SQLite 路径" "$ROOT/window_audit/archive/rounds_archive.db"; JSRC=(--sqlite "$p");;
    *) JSRC=();;
  esac
}

menu() {
  local c
  while :; do
    printf '\n%s════════════ window_audit · Docker 跑测器 v%s ════════════%s\n' "$C_B" "$SCRIPT_VERSION" "$C_0"
    printf '  项目根 %s   镜像 %s\n' "$ROOT" "$IMAGE"
    printf '  房号   %s%s   候选窗口 %sh\n' "$ROOMS" \
           "$( [ -n "$ROOMS_SPEC" ] && printf '  (随机 seed=%s)' "$SEED" )" "$WINDOWS"
    printf '%s── 日常 ─────────────────────────────────────────────────%s\n' "$C_B" "$C_0"
    printf '   1) 全套跑测并比对 README 基线   （首次来这里）\n'
    printf '   2) 运行环境体检 doctor\n'
    printf '   3) 配置耦合体检 config          （max_train / retention 是否拖后腿）\n'
    printf '   4) 单房回放 replay      5) 冷门规律性检验      6) 补充检验\n'
    printf '   7) 裁决器演示 window_judge（公平域口径，跑自带快照）\n'
    printf '%s── 正式裁决（攒满 7 天走这里；数据源全自动识别）───────────%s\n' "$C_B" "$C_0"
    printf '  %s8) 看生产 PG 攒到哪了（还差多久能裁决）%s\n' "$C_W" "$C_0"
    printf '  %s9) 正式裁决 judge7%s\n' "$C_W" "$C_0"
    printf '  10) 从生产 PG 增量导出 SQLite 归档（绕开 retention 滚动删除）\n'
    printf '%s── 维护 ─────────────────────────────────────────────────%s\n' "$C_B" "$C_0"
    printf '  11) 只跑全套不判定    12) 进容器 shell    13) 重建镜像    14) 清理 out/\n'
    printf '   %sR) 随机换一批房（按跨度+密度筛合格房）%s    F) 恢复 README 固定三房\n' "$C_W" "$C_0"
    printf '   0) 退出\n'
    ask c "请选择" "1"
    case "$c" in
      1) cmd_test || true; pause_key;;
      2) cmd_doctor || true; pause_key;;
      3) cmd_config || true; pause_key;;
      4) local room hrs; ask room "  房号" "2678075"; ask hrs "  训练窗小时数（留空=用 config.yaml 值）" ""
         if [ -n "$hrs" ]; then cmd_replay "$room" --hours "$hrs" || true; else cmd_replay "$room" || true; fi; pause_key;;
      5) cmd_cold || true; pause_key;;
      6) cmd_extra || true; pause_key;;
      7) cmd_judge --rooms "$ROOMS" --windows "$WINDOWS" || true; pause_key;;
      8) cmd_pgstat || true; pause_key;;
      9) ask_source; ask WINDOWS "  候选窗口（逗号分隔）" "$WINDOWS"
         confirm "  跳过 A 段裁决器？（耗时减半，B 段同口径可独立下结论）" Y && SKIP_NATIVE=1 || SKIP_NATIVE=0
         cmd_judge7 ${JSRC[@]+"${JSRC[@]}"} || true; pause_key;;
      10) local ar; ask ar "  归档文件（容器内路径）" "/repo/window_audit/archive/rounds_archive.db"
          cmd_export "$ar" || true; pause_key;;
      11) cmd_all || true; pause_key;;
      12) cmd_shell || true;;
      13) FORCE_REBUILD=1; build_audit_image || true; FORCE_REBUILD=0; pause_key;;
      14) cmd_clean || true; pause_key;;
      R|r) local rw; ask rw "  抽几个房" "3"; SEED=0; ROOMS="random:$rw"
           resolve_rooms || warn "抽房失败，房号维持原样"; pause_key;;
      F|f) ROOMS="$DEFAULT_ROOMS"; ROOMS_SPEC=""; ok "已恢复固定三房：$ROOMS"; pause_key;;
      0|q|Q) say "再见"; exit 0;;
      *) warn "无效选择：$c";;
    esac
  done
}

usage() { awk 'NR>1 && /^set -Eeuo/{exit} NR>1 && !/^# shellcheck/{sub(/^# ?/,""); print}' "$SELF_PATH"; }

main() {
  local CMD="" ARGS=()
  while [ $# -gt 0 ]; do
    case "$1" in
      -y|--yes) ASSUME_YES=1;;
      --cn) CN_MODE=1;;
      --dir) ROOT="${2:?}"; shift;;
      --image) IMAGE="${2:?}"; shift;;
      --rebuild) FORCE_REBUILD=1;;
      --pip-mirror) PIP_MIRROR="${2:?}"; shift;;
      --rooms) ROOMS="${2:?}"; shift;;
      --windows) WINDOWS="${2:?}"; shift;;
      --net) NET="${2:?}"; shift;;
      --user) RUN_USER="${2:?}"; shift;;
      --selinux) SELINUX_MODE="${2:?}"; shift;;
      --keep) KEEP_TMP=1;;
      --skip-native) SKIP_NATIVE=1;;
      --seed) SEED="${2:?}"; shift;;
      --data) DATA_ARCHIVE="${2:?}"; shift;;
      --refresh) FORCE_REPLAY=1;;
      --min-density) MIN_DENSITY="${2:?}"; shift;;
      -h|--help|help) usage; exit 0;;
      -v|--version) echo "$SELF_NAME v$SCRIPT_VERSION"; exit 0;;
      -*) die "未知选项：$1（--help 查看用法）";;
      *) CMD="$1"; shift; ARGS=("$@"); break;;
    esac
    shift
  done
  if [ -z "$CMD" ]; then
    if [ -t 0 ] && [ "$ASSUME_YES" -eq 0 ]; then CMD="menu"; else CMD="test"; fi
  fi

  detect_docker
  locate_root
  case "$CMD" in clean) cmd_clean; exit 0;; image) resolve_image; exit 0;; esac
  resolve_image
  case "$ROOMS" in random|random:*)
    [ "$CMD" = test ] && die "test 的基线只对固定三房有效，不能用 --rooms random"
    resolve_rooms;; esac

  case "$CMD" in
    menu)   menu;;
    test)   cmd_test;;
    all)    cmd_all;;
    doctor) cmd_doctor;;
    config) cmd_config || exit $?;;
    judge7) cmd_judge7 ${ARGS[@]+"${ARGS[@]}"};;
    pgstat) cmd_pgstat;;
    export) cmd_export ${ARGS[@]+"${ARGS[@]}"};;
    replay) cmd_replay ${ARGS[@]+"${ARGS[@]}"};;
    cold)   cmd_cold   ${ARGS[@]+"${ARGS[@]}"};;
    extra)  cmd_extra  ${ARGS[@]+"${ARGS[@]}"};;
    judge)  cmd_judge  ${ARGS[@]+"${ARGS[@]}"};;
    shell)  cmd_shell;;
    *) die "未知子命令：$CMD（--help 查看用法）";;
  esac
}

main ${@+"$@"}
