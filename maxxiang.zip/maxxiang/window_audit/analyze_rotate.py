#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
analyze_rotate.py — 冷位份额闭环(showcase_rotate)的诊断器 / 门禁 / 消融台
================================================================================
走生产代码路径(backend_async/app/predictor_bridge.py → jiufa_data/
spell_tamer_monitor.py),在仓内自带的真机库(1275859/2678075/3746870
三房 7 天)上逐局因果回放,产出 README「冷位份额闭环」条目的**全部实测
数字**。零随机源、逐字节确定性,重跑必须复现。

用法
----
  python3 analyze_rotate.py                      # 关/开 A/B 全表(默认)
  python3 analyze_rotate.py --gate               # 仓内等价门禁(确定性 + 风格惰性)
  python3 analyze_rotate.py --gate --baseline /path/to/old/jiufa_data
                                                 # 与改造前引擎逐局字节比对
  python3 analyze_rotate.py --sweep sc_eta_cold=0.0,0.5,1.0,2.0
                                                 # 单刻度扫描(可重复 --sweep)
  python3 analyze_rotate.py --rooms 2678075 --db /path/x.db

口径
----
· 成熟期 = 跳过前 400 局热身(与生产 replay_warmup=400 同量级),避免冷启动伪影。
· 「四码回报」= 每局对四码各押 1u,命中得该号倍率 u(倍率取 rounds 表实录:
  1×10 2×50 3×330 4×250 5×100 6×100 7×50 8×50 9×500)。它是倍率单位代理,
  相对排序在按倍率成比例赔付的任何模型下稳健,绝对值不是实盘派彩。
· 显著性用 McNemar 精确二项(同一批局的配对检验)。三房 7 天 34,988 成熟局上
  配对差的标准误 ≈0.24pp ⇒ **±0.5pp 以内的档位差异不可分辨**,读表勿过度解读。
"""
import argparse
import bisect
import importlib.util
import json
import math
import os
import sqlite3
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
STEP = 50001
COLD5 = (3, 4, 5, 6, 9)
HOT4 = (1, 2, 7, 8)
MULT = {1: 10, 2: 50, 3: 330, 4: 250, 5: 100, 6: 100, 7: 50, 8: 50, 9: 500}
WARMUP_SKIP = 400

import yaml  # noqa: E402

with open(os.path.join(ROOT, "backend_async", "config.yaml"), encoding="utf-8") as f:
    _ALL = yaml.safe_load(f)
PRED_CFG = dict(_ALL["prediction"])
BEAST_IDS = dict(_ALL["custom_beast_ids"])
DEFAULT_DB = os.path.join(ROOT, "jiufa_data", "spell_tamer_data.db")


def _bridge_module(engine_dir):
    """按指定引擎目录加载一份独立的 predictor_bridge(便于与旧引擎并排比对)。"""
    os.environ["STA_ENGINE_DIR"] = engine_dir
    for m in ("spell_tamer_monitor", "predictor_bridge"):
        sys.modules.pop(m, None)
    spec = importlib.util.spec_from_file_location(
        "predictor_bridge", os.path.join(ROOT, "backend_async", "app", "predictor_bridge.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def load_rounds(room, db):
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    rows = con.execute("SELECT round_id, custom_id, start_ms, draw_ms FROM rounds "
                       "WHERE room_id=? AND custom_id IS NOT NULL ORDER BY round_id",
                       (room,)).fetchall()
    con.close()
    return rows


def rooms_in(db):
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    r = [x[0] for x in con.execute("SELECT DISTINCT room_id FROM rounds ORDER BY room_id")]
    con.close()
    return r


def replay(pb, room, rounds, cfg, first=30):
    """复刻 worker._settle_and_predict 的时序:先结算推权重,再生成下一局预测。"""
    br = pb.PredictorBridge(cfg, BEAST_IDS)
    kv, pending, recs = {}, {}, []
    tw = int(float(cfg.get("train_window_hours", 24.0) or 0) * 3600 * 1000)
    mx = int(cfg.get("max_train", 5000))
    starts = [r[2] for r in rounds]
    cids = [r[1] for r in rounds]
    for idx, (rid, cid, sms, dms) in enumerate(rounds):
        p = pending.pop(rid, None)
        if p is not None:
            p["actual"] = cid
            p["hit"] = ("main" if cid in p["four"][:2]
                        else ("guard" if cid in p["four"][2:] else "miss"))
            kv.update(br.update_after_settle(
                room, {"models": p["models"], "ens": p["ens"]}, cid, kv))
        if idx < first:
            continue
        now = (dms or sms + 46500) + 1500
        lo = bisect.bisect_left(starts, now - tw, 0, idx + 1) if tw > 0 else 0
        seq = cids[lo:idx + 1][-mx:]
        res, dirty = br.run_prediction(room, seq, kv)
        kv.update(dirty)
        rec = {"four": list(res["main"]) + list(res["guard"]),
               "models": res["models"], "ens": res["ens"],
               "why": ((res.get("explore") or {}).get("why") or ""),
               "actual": None, "hit": None}
        pending[rid + STEP] = rec
        recs.append(rec)
    return recs


def metrics(recs):
    m = recs[WARMUP_SKIP:]
    st = [r for r in m if r["hit"]]
    n, N = len(m), len(st)
    sets = [tuple(sorted(r["four"])) for r in m]
    sel = Counter()
    for r in m:
        for c in r["four"]:
            sel[c] += 1
    cs = sum(sum(1 for c in r["four"] if c in COLD5) for r in m) / max(1, n)

    def maxrun(seq):
        b = cur = 1
        for i in range(1, len(seq)):
            cur = cur + 1 if seq[i] == seq[i - 1] else 1
            b = max(b, cur)
        return b

    def streak(c):
        b = cur = 0
        for r in m:
            cur = cur + 1 if c in r["four"] else 0
            b = max(b, cur)
        return b

    cnt = Counter(sets)
    return dict(
        n=n, N=N,
        hit4=sum(1 for r in st if r["hit"] != "miss") / N * 100,
        hitm=sum(1 for r in st if r["hit"] == "main") / N * 100,
        retf=sum(MULT[r["actual"]] for r in st if r["actual"] in r["four"]) / N,
        sel={c: sel.get(c, 0) / n * 100 for c in range(1, 10)},
        hhi=(sum((sel.get(c, 0) / n / cs) ** 2 for c in COLD5) if cs else 0.0),
        same=sum(1 for i in range(1, n) if sets[i] == sets[i - 1]) / max(1, n - 1) * 100,
        maxrun=maxrun(sets), H=-sum((v / n) * math.log2(v / n) for v in cnt.values()),
        nsets=len(cnt), streak=max(streak(c) for c in range(1, 10)),
        swap=sum(1 for r in m if "硬帽" in r["why"]) / n * 100,
        baodi=sum(1 for r in m if "保底" in r["why"]) / n * 100,
        hits=[1 if r["hit"] != "miss" else 0 for r in st])


def merge(per):
    rs = list(per.values())
    N = sum(x["n"] for x in rs)
    w = lambda k: sum(x[k] * x["n"] for x in rs) / N
    sel = {c: sum(x["sel"][c] * x["n"] for x in rs) / N for c in range(1, 10)}
    cs = sum(sel[c] for c in COLD5) / 100
    return dict(n=N, hit4=w("hit4"), hitm=w("hitm"), retf=w("retf"), sel=sel,
                hhi=sum((sel[c] / 100 / cs) ** 2 for c in COLD5) if cs else 0.0,
                same=w("same"), maxrun=max(x["maxrun"] for x in rs), H=w("H"),
                streak=max(x["streak"] for x in rs), swap=w("swap"), baodi=w("baodi"),
                nsets=max(x["nsets"] for x in rs))


def mcnemar(a, b):
    """a/b 为等长 0/1 命中序列;返回 (Δpp, b_only, c_only, 双侧精确 p)。"""
    x = y = 0
    n = min(len(a), len(b))
    d = sum(b[i] - a[i] for i in range(n))
    for i in range(n):
        if a[i] and not b[i]:
            x += 1
        if b[i] and not a[i]:
            y += 1
    k, N = min(x, y), x + y
    p = min(1.0, sum(math.comb(N, i) for i in range(k + 1)) / 2 ** N * 2) if N else 1.0
    return d / n * 100, x, y, p


HDR = (f"{'方案':<26}{'四码中%':>8}{'Δpp':>7}{'p值':>8}{'主中%':>7}{'四码回报':>9}"
       f"{'冷HHI':>7}{'邻同%':>7}{'连推':>5}{'单号最长':>9}{'熵':>6}{'硬帽%':>7}{'保底%':>7}")


def line(name, a, mc=None):
    d = f"{mc[0]:>7.2f}{mc[3]:>8.4f}" if mc else f"{'—':>7}{'—':>8}"
    return (f"{name:<26}{a['hit4']:>8.2f}{d}{a['hitm']:>7.2f}{a['retf']:>9.2f}"
            f"{a['hhi']:>7.3f}{a['same']:>7.1f}{a['maxrun']:>5}{a['streak']:>9}"
            f"{a['H']:>6.2f}{a['swap']:>7.2f}{a['baodi']:>7.2f}")


def run_cfg(pb, data, over):
    cfg = {**PRED_CFG, **over}
    per, fours, hits = {}, {}, []
    for room, rounds in data.items():
        rec = replay(pb, room, rounds, cfg)
        per[room] = metrics(rec)
        fours[room] = [r["four"] for r in rec]
        hits += per[room]["hits"]
    return merge(per), fours, hits, per


def cmd_gate(args, pb, data):
    print("=" * 96)
    print("【门禁 1】确定性:同配置重跑必须逐局全同(补算/回测自还原的前提)")
    print("=" * 96)
    _, f1, _, _ = run_cfg(pb, data, {})
    _, f2, _, _ = run_cfg(pb, data, {})
    ok = all(f1[r] == f2[r] for r in f1)
    print(f"  {'✅ 全同' if ok else '❌ 不确定'}  共 {sum(len(v) for v in f1.values())} 局")

    print()
    print("=" * 96)
    print("【门禁 2】关态惰性:showcase_rotate=0 时任何 sc_* 刻度都不得改变输出")
    print("=" * 96)
    off = {"showcase_rotate": 0, "sc_fp_depth": 3}
    wild = {**off, "sc_eta_cold": -3.0, "sc_eta_hot": 0.0, "sc_floor_cold": 0.2,
            "sc_floor_hot": 0.25, "sc_lambda": 3.5, "sc_debt_cap": 12.0,
            "sc_repeat_cap": 1, "sc_beta_off": 1}
    _, a, _, _ = run_cfg(pb, data, off)
    _, b, _, _ = run_cfg(pb, data, wild)
    tot = same = 0
    for r in a:
        eq = sum(1 for x, y in zip(a[r], b[r]) if x == y)
        tot += len(a[r]); same += eq
        print(f"  房{r}: {eq}/{len(a[r])} {'✅' if eq == len(a[r]) else '❌'}")
    print(f"  合计 {same}/{tot}")

    print()
    print("=" * 96)
    print("【门禁 3】风格惰性:非 showcase 的四式在刻度全拨极端下必须与关态全同")
    print("=" * 96)
    one = {list(data)[0]: data[list(data)[0]]}
    for style in ("budget", "norm_cold", "matched", "ceiling_adaptive"):
        _, x, _, _ = run_cfg(pb, one, {**off, "explore_style": style})
        _, y, _, _ = run_cfg(pb, one, {**wild, "showcase_rotate": 1,
                                       "explore_style": style})
        r = list(one)[0]
        eq = sum(1 for i, j in zip(x[r], y[r]) if i == j)
        print(f"  {style:<18} {eq}/{len(x[r])} {'✅' if eq == len(x[r]) else '❌'}")

    if args.baseline:
        print()
        print("=" * 96)
        print(f"【门禁 4】与改造前引擎逐字节比对(baseline={args.baseline})")
        print("=" * 96)
        pb0 = _bridge_module(args.baseline)
        _, base, _, _ = run_cfg(pb0, data, {})
        pb1 = _bridge_module(os.path.join(ROOT, "jiufa_data"))
        _, cur, _, _ = run_cfg(pb1, data, off)
        tot = same = 0
        for r in base:
            eq = sum(1 for x, y in zip(base[r], cur[r]) if x == y)
            tot += len(base[r]); same += eq
            print(f"  房{r}: {eq}/{len(base[r])} {'✅' if eq == len(base[r]) else '❌'}")
        print(f"  合计 {same}/{tot} = {same / tot * 100:.4f}%"
              f"  {'✅ 字节级等价' if same == tot else '❌ 不等价'}")
    else:
        print()
        print("  提示:与改造前引擎的字节级比对需 --baseline <旧 jiufa_data 目录>。")


def cmd_ab(args, pb, data):
    scen = [("关(showcase_rotate=0)", {"showcase_rotate": 0, "sc_fp_depth": 3}),
            ("开(生产定稿刻度)", {})]
    for sw in args.sweep or []:
        key, _, vals = sw.partition("=")
        for v in vals.split(","):
            scen.append((f"{key.strip()}={v.strip()}",
                         {key.strip(): yaml.safe_load(v.strip())}))
    base_hits = None
    rows = []
    for name, over in scen:
        a, _, hits, per = run_cfg(pb, data, over)
        mc = None if base_hits is None else mcnemar(base_hits, hits)
        if base_hits is None:
            base_hits = hits
        rows.append((name, a, mc, per))

    print("=" * 132)
    print(f"【冷位份额闭环 A/B】{'/'.join(data)} · 成熟期 {rows[0][1]['n']} 局 · "
          f"生产代码路径 · Δ/p 相对首行")
    print("=" * 132)
    print(HDR)
    print("-" * 132)
    for name, a, mc, _ in rows:
        print(line(name, a, mc))
    print()
    print("=" * 132)
    print("【各号进四码占比 %】(冷池=3/4/5/6/9,热池=1/2/7/8)")
    print("=" * 132)
    print(f"{'方案':<26}" + "".join(f"{'号' + str(c):>8}" for c in range(1, 10)))
    print("-" * 132)
    for name, a, _, _ in rows:
        print(f"{name:<26}" + "".join(f"{a['sel'][c]:>8.1f}" for c in range(1, 10)))
    print()
    print("注:±1.1pp 以内的命中率差异在本数据量下不可分辨(配对差 SE≈0.56pp);"
          "「四码回报」为倍率单位代理,非实盘派彩。")
    if args.json:
        json.dump({n: {k: v for k, v in a.items() if k != "hits"} for n, a, _, _ in rows},
                  open(args.json, "w"), ensure_ascii=False, indent=1)
        print("明细 →", args.json)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gate", action="store_true", help="跑仓内等价门禁")
    ap.add_argument("--baseline", default=None, help="改造前引擎目录(含 spell_tamer_monitor.py)")
    ap.add_argument("--sweep", action="append", default=[], metavar="K=v1,v2",
                    help="单刻度扫描,可重复")
    ap.add_argument("--rooms", default=None, help="逗号分隔房号(默认库内全部)")
    ap.add_argument("--db", default=DEFAULT_DB)
    ap.add_argument("--json", default=None, help="把汇总写成 JSON")
    a = ap.parse_args()

    rooms = a.rooms.split(",") if a.rooms else rooms_in(a.db)
    data = {r: load_rounds(r, a.db) for r in rooms}
    data = {r: v for r, v in data.items() if len(v) > WARMUP_SKIP + 60}
    if not data:
        sys.exit(f"数据源可用局数不足(需 > {WARMUP_SKIP + 60} 局/房): {a.db}")
    pb = _bridge_module(os.path.join(ROOT, "jiufa_data"))
    (cmd_gate if a.gate else cmd_ab)(a, pb, data)


if __name__ == "__main__":
    main()
