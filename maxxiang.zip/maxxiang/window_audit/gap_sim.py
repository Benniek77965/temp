#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""断流恢复仿真 —— 训练窗「时间制」与「局数制」的鲁棒性对照。

前置事实(已逐局证明):连续数据上 (tw=24h, max_train=BIG) 与
(tw=0, max_train=1728) 逐局 0 差异。故本实验中两者的任何分歧,
**全部**来自断流这一件事。

做法:在 t0+96h 处挖掉 G 小时的局(模拟抓取中断/上游故障/冷房期),
两套配置各跑一遍完整回放,统计恢复后前 N 局的 train_n 与四码命中。
"""
import os, sys, json

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import replay_harness as rh   # noqa: E402

ROOM = "2678075"
BIG = 10 ** 7
STEP = 50001


def carve(rounds, gap_start_ms, gap_h):
    """挖掉 [gap_start, gap_start+gap_h) 的局"""
    end = gap_start_ms + int(gap_h * 3600 * 1000)
    return [r for r in rounds if not (gap_start_ms <= r[2] < end)]


def run(rounds, cfg, resume_rid):
    recs, _ = rh.replay(ROOM, rounds, cfg)
    s = [r for r in recs if r["actual"] is not None]
    post = [r for r in s if r["target"] >= resume_rid]
    return s, post


def main():
    rounds = rh.load_rounds(ROOM)
    t0 = rounds[0][2]
    gap_start = t0 + 96 * 3600 * 1000
    print(f"[{ROOM}] {len(rounds)} 局  断流起点 = 数据起点+96h")
    for gap_h in (12.0, 30.0):
        cut = carve(rounds, gap_start, gap_h)
        resume_rid = min(r[0] for r in cut if r[2] >= gap_start + gap_h * 3600000)
        print(f"\n─── 断流 {gap_h:g}h(挖掉 {len(rounds)-len(cut)} 局,恢复局 {resume_rid}) ───")
        for name, cfg_over in (
                ("时间制 tw=24h(生产)", {"train_window_hours": 24.0, "max_train": BIG}),
                ("局数制 tw=0/mt=1728 ", {"train_window_hours": 0.0, "max_train": 1728})):
            cfg = dict(rh.PRED_CFG); cfg.update(cfg_over)
            s, post = run(cut, cfg, resume_rid)
            first = post[:1][0] if post else None
            for N in (50, 200, 1000):
                seg = post[:N]
                if not seg:
                    continue
                hit = sum(1 for r in seg if r["hit"] != "miss")
                tn = [r["train_n"] for r in seg]
                print(f"  {name} 恢复后前{N:>4}局: 四码={hit/len(seg)*100:5.2f}%  "
                      f"train_n min/中位/max = {min(tn)}/{sorted(tn)[len(tn)//2]}/{max(tn)}")
            allhit = sum(1 for r in s if r["hit"] != "miss")
            print(f"  {name} 全程 {len(s)} 局: 四码={allhit/len(s)*100:.2f}%"
                  f"   恢复首局 train_n={first['train_n'] if first else '—'}")


if __name__ == "__main__":
    main()
