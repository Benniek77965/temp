#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""audit_run.py —— 4.9.8 现行配置下,prior_shrink 与 train_window_hours 的全量重测。

零改写生产代码:全部经 replay_harness.replay() → predictor_bridge → spell_tamer_monitor。
逐条实验落 out_audit/<tag>.json.gz(含 meta + 逐局 rows),中断可续跑。
"""
import gzip, json, os, sys, time
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import replay_harness as rh  # noqa: E402

OUT = os.path.join(HERE, "out_audit")
os.makedirs(OUT, exist_ok=True)
BIG = 10 ** 7
ROOMS = ["2678075", "1275859", "3746870"]

OFFICIAL = "1:0.200000,2:0.160000,3:0.035000,4:0.065000,5:0.100000,6:0.100000,7:0.160000,8:0.160000,9:0.020000"

_ROUNDS = {}


def rounds(room):
    if room not in _ROUNDS:
        _ROUNDS[room] = rh.load_rounds(room)
    return _ROUNDS[room]


def freq_table(cids):
    c = Counter(cids)
    n = sum(c.values())
    return ",".join(f"{i}:{c[i]/n:.6f}" for i in range(1, 10))


def run(tag, room, over):
    path = os.path.join(OUT, tag + ".json.gz")
    if os.path.exists(path):
        print(f"  跳过 {tag}", flush=True)
        return
    cfg = dict(rh.PRED_CFG)
    cfg.update(over)
    t0 = time.time()
    recs, _ = rh.replay(room, rounds(room), cfg)
    rows = [[r["target"], (0 if r["hit"] == "miss" else 1), r["actual"],
             r["train_n"], sorted(r["four"]), r["gen_after_idx"]]
            for r in recs if r["actual"] is not None]
    hit = sum(r[1] for r in rows)
    meta = {"tag": tag, "room": room, "over": {k: v for k, v in over.items()},
            "n": len(rows), "hit4": hit, "p4": hit / len(rows) if rows else 0,
            "secs": round(time.time() - t0, 1)}
    with gzip.open(path, "wt") as f:
        json.dump({"meta": meta, "rows": rows}, f)
    print(f"  {tag}: n={meta['n']} 四码={meta['p4']*100:.3f}% {meta['secs']}s", flush=True)


def main():
    which = sys.argv[1] if len(sys.argv) > 1 else "all"

    # ── 阶段 1:基线(=现行 config.yaml,prior_shrink=false,tw=24h) ────────────
    if which in ("all", "base", "prior"):
        print("[1] 基线 24h / prior off", flush=True)
        for rm in ROOMS:
            run(f"{rm}_base", rm, {"max_train": BIG})

    # ── 阶段 2:prior_shrink 四种先验表 ───────────────────────────────────────
    if which in ("all", "prior"):
        allcids = {rm: [r[1] for r in rounds(rm)] for rm in ROOMS}
        print("[2] prior_shrink=true", flush=True)
        for rm in ROOMS:
            # (a) 出厂表(样本内 —— 该表就是这三房 36,278 局拟合出来的)
            run(f"{rm}_prior_in", rm, {"max_train": BIG, "prior_shrink": True})
            # (b) 留一房表(去掉本房的贡献)
            loo = freq_table([c for o in ROOMS if o != rm for c in allcids[o]])
            run(f"{rm}_prior_loo", rm,
                {"max_train": BIG, "prior_shrink": True, "prior_table": loo})
            # (c) 时间留出:只用本房前 72h 的局拟合先验,评估留在 72h 之后
            t0 = rounds(rm)[0][2]
            head = [r[1] for r in rounds(rm) if r[2] < t0 + 72 * 3600 * 1000]
            run(f"{rm}_prior_h72", rm,
                {"max_train": BIG, "prior_shrink": True, "prior_table": freq_table(head)})
            # (d) 官方公示表(= 表过期/换活动没更新的现实失效模式)
            run(f"{rm}_prior_off", rm,
                {"max_train": BIG, "prior_shrink": True, "prior_table": OFFICIAL})

    # ── 阶段 3:训练窗扫描 ────────────────────────────────────────────────────
    if which in ("all", "win"):
        print("[3] train_window_hours 扫描", flush=True)
        for h in (3.0, 6.0, 12.0, 48.0, 72.0, 0.0):
            for rm in ROOMS:
                run(f"{rm}_tw{h:g}", rm, {"train_window_hours": h, "max_train": BIG})

    print("完成", flush=True)


if __name__ == "__main__":
    main()
