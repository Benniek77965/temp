#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""补充检验(审计存档) — ①出怪流独立性(G检验/互信息) ②引擎vs频率基线的
分歧局配对McNemar ③反事实扰动(打乱/倒放数据→输出应大变;同数据重跑→全同)
④冷门席位与频率top-k重合率。先运行 replay_harness.py 生成 out/ 明细。"""
import json, math, random, bisect, sqlite3, os, sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import replay_harness as rh

ROOT = os.path.dirname(HERE)
OUT = os.path.join(HERE, "out")
DB = os.path.join(ROOT, "jiufa_data", "spell_tamer_data.db")
COLD = (3, 4, 5, 6, 9)
ROOMS = sys.argv[1].split(",") if len(sys.argv) > 1 else ["1275859", "2678075", "3746870"]
CF_ROOM = ROOMS[0]


def load(room):
    p = os.path.join(OUT, f"replay_{room}.json")
    if not os.path.exists(p):
        return None, None
    recs = json.load(open(p))
    con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    rounds = con.execute("SELECT round_id, custom_id, start_ms, draw_ms FROM rounds "
                         "WHERE room_id=? AND custom_id IS NOT NULL ORDER BY round_id",
                         (room,)).fetchall()
    con.close()
    return recs, rounds


print("① 出怪序列独立性(若独立,任何择时信号理论增益=0)")
for room in ROOMS:
    _, rounds = load(room)
    if not rounds:
        continue
    seq = [r[1] for r in rounds]
    n = len(seq)
    marg = Counter(seq)
    trans = Counter(zip(seq[:-1], seq[1:]))
    G = sum(2 * o * math.log(o / (marg[a] * marg[b] / n))
            for (a, b), o in trans.items() if marg[a] * marg[b])
    dof = 64
    zz = ((G / dof) ** (1 / 3) - (1 - 2 / (9 * dof))) / math.sqrt(2 / (9 * dof))
    Hm = -sum((c / n) * math.log2(c / n) for c in marg.values())
    Hc = 0.0
    for a in marg:
        row = {b: trans.get((a, b), 0) for b in marg}
        ra = sum(row.values())
        if ra:
            Hc += (ra / (n - 1)) * -sum((c / ra) * math.log2(c / ra) for c in row.values() if c)
    print(f"  [{room}] 一阶G={G:.1f} (dof=64, z≈{zz:.2f})  互信息={Hm-Hc:.4f}bit")

print("\n② 分歧局配对检验: 引擎冷门组 vs 24h频率top-k(同k)")
tb = tc = tsame = 0
for room in ROOMS:
    recs, rounds = load(room)
    if not recs:
        continue
    starts = [r[2] for r in rounds]
    b = c = same = 0
    for r in recs:
        if r["actual"] is None or r["k"] == 0:
            continue
        gi = r["gen_after_idx"]
        lo = bisect.bisect_left(starts, rounds[gi][2] - 86400000, 0, gi + 1)
        wc = Counter(x[1] for x in rounds[lo:gi + 1])
        ftop = set(sorted(COLD, key=lambda x: (-wc.get(x, 0), x))[:r["k"]])
        eset = set(r["coldset"])
        if eset == ftop:
            same += 1
            continue
        eh, fh = r["actual"] in eset, r["actual"] in ftop
        b += eh and not fh
        c += fh and not eh
    print(f"  [{room}] 组合全同={same}  引擎中/频率空={b}  频率中/引擎空={c}")
    tb += b; tc += c; tsame += same
from math import comb
nt = tb + tc
p2 = min(1.0, sum(comb(nt, i) for i in range(min(tb, tc) + 1)) / 2 ** nt * 2) if nt else 1.0
print(f"  合并: b={tb} c={tc} (McNemar双侧p≈{p2:.3f})  组合重合率={tsame}/{tsame+nt}")

print(f"\n③ 反事实扰动(房{CF_ROOM}): 固定顺序应对扰动免疫,数据驱动则大变")
base_recs, rounds = load(CF_ROOM)
if base_recs:
    rng = random.Random(42)
    cids = [r[1] for r in rounds]
    sh = cids[:]
    rng.shuffle(sh)
    base_map = {r["target"]: (tuple(sorted(r["coldset"])), tuple(r["four"])) for r in base_recs}
    for name, rv in {"shuffle": [(r[0], sh[i], r[2], r[3]) for i, r in enumerate(rounds)],
                     "reverse": [(r[0], cids[-1 - i], r[2], r[3]) for i, r in enumerate(rounds)]}.items():
        recs2, _ = rh.replay(CF_ROOM, rv)
        ac = af = tot = 0
        for r in recs2:
            bm = base_map.get(r["target"])
            if not bm:
                continue
            tot += 1
            ac += tuple(sorted(r["coldset"])) == bm[0]
            af += tuple(r["four"]) == bm[1]
        print(f"  {name}: 冷门组合一致率={ac/tot*100:.1f}%  四码完全一致率={af/tot*100:.1f}%")
    recs3, _ = rh.replay(CF_ROOM, rounds)
    det = all(tuple(a["four"]) == tuple(b["four"]) for a, b in zip(base_recs, recs3))
    print(f"  同数据重跑输出完全一致(确定性): {det}")

print("\n④ 冷门席位与同窗频率top-k逐席重合率")
for room in ROOMS[:1]:
    recs, rounds = load(room)
    if not recs:
        continue
    starts = [r[2] for r in rounds]
    inter = tot = 0
    for r in recs:
        if r["k"] == 0:
            continue
        gi = r["gen_after_idx"]
        lo = bisect.bisect_left(starts, rounds[gi][2] - 86400000, 0, gi + 1)
        wc = Counter(x[1] for x in rounds[lo:gi + 1])
        ftop = set(sorted(COLD, key=lambda x: (-wc.get(x, 0), x))[:r["k"]])
        inter += len(set(r["coldset"]) & ftop)
        tot += r["k"]
    print(f"  [{room}] {inter}/{tot} = {inter/tot*100:.1f}%")
