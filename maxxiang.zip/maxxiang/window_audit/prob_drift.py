#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
prob_drift.py — 「官方公示概率表」vs「实盘出怪频率」对照
================================================================================
公示表（mock/data/room-321-config.json）是前端「官方」列、「偏差」2σ 着色、
九法阵 `stateOf` 周期 `round(100/p)` 的**唯一真源**。仓库既有的
`tests/test_official_probability.py` 守的是"表与表一致"，守不住"表与现实一致"。
本工具就是补上后半句，产出 `tests/test_probability_drift.py` 里登记的那组数字。

用法：
    python3 prob_drift.py                      # 用仓库自带真机库
    python3 prob_drift.py --db /path/x.db      # 指定数据源
    python3 prob_drift.py --by-day             # 逐日复现（判断是不是"表过期了"）

口径说明：**不要**拿本工具的实测值去覆盖公示表。公示值是游戏方对外声明的事实，
实测频率是我们自己的估计；用后者冒充前者是另一种失真。发现偏离时正确的动作是
确认来源 + 更新 `OBSERVED_PCT` 登记值，而不是让公示列显示我们的估计。
"""
import argparse
import json
import math
import os
import sqlite3
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DEF_DB = os.path.join(ROOT, "jiufa_data", "spell_tamer_data.db")
CFG = os.path.join(ROOT, "mock", "data", "room-321-config.json")


def shipped():
    with open(CFG, encoding="utf-8") as f:
        sp = json.load(f)["spells"]
    return ({int(s["display_number"]): float(str(s["probability"]).rstrip("%")) for s in sp},
            {int(s["display_number"]): int(s["multiplier"]) for s in sp},
            {int(s["display_number"]): s["beast_name"] for s in sp})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=DEF_DB)
    ap.add_argument("--by-day", action="store_true")
    a = ap.parse_args()
    tbl, mult, name = shipped()
    con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
    rows = con.execute("SELECT room_id, custom_id, date_local FROM rounds "
                       "WHERE custom_id IS NOT NULL").fetchall()
    con.close()
    n = len(rows)
    cnt = Counter(c for _r, c, _d in rows)
    print(f"数据源 {a.db}\n局数 N={n}\n")
    print(f"{'号':>2} {'妖兽':<5} {'倍率':>5} {'公示%':>7} {'实测%':>7} {'偏差pp':>8} {'z':>8}")
    chi = 0.0
    for c in range(1, 10):
        p0 = tbl[c] / 100
        k = cnt[c]
        exp = n * p0
        z = (k - exp) / math.sqrt(n * p0 * (1 - p0))
        chi += (k - exp) ** 2 / exp
        print(f"{c:>2} {name[c]:<5} {mult[c]:>5} {tbl[c]:>7.2f} {k/n*100:>7.3f} "
              f"{k/n*100-tbl[c]:>+8.3f} {z:>+8.2f}")
    # χ²(8) 尾概率
    p = math.erfc(math.sqrt(max(chi - 8, 0) / 2)) if chi > 8 else 1.0
    print(f"\n拟合优度 χ²={chi:.1f} (df=8)  —— {'极显著偏离' if chi > 26 else '未见显著偏离'}"
          f"（χ²(8) 的 0.1% 临界值 = 26.1）")
    print(f"公示表 Σp·倍率 = {sum(tbl[c]/100*mult[c] for c in range(1,10)):.4f}")
    print(f"实测   Σp·倍率 = {sum(cnt[c]/n*mult[c] for c in range(1,10)):.4f}")

    print("\n分房实测占比（检验是不是某一房的问题）：")
    byroom = defaultdict(Counter)
    for r, c, _d in rows:
        byroom[r][c] += 1
    for r, cc in sorted(byroom.items()):
        m = sum(cc.values())
        print(f"  {r} " + " ".join(f"{c}:{cc[c]/m*100:5.2f}" for c in range(1, 10)))

    if a.by_day:
        print("\n逐日复现（判断是不是『表过期了』——若逐日稳定偏离，就不是过期）：")
        byday = defaultdict(Counter)
        for _r, c, d in rows:
            byday[d][c] += 1
        for d, cc in sorted(byday.items()):
            m = sum(cc.values())
            if m < 500:
                continue
            out = []
            for c in (9, 3, 1):
                p0 = tbl[c] / 100
                z = (cc[c] - m * p0) / math.sqrt(m * p0 * (1 - p0))
                out.append(f"{c}号{cc[c]/m*100:5.2f}%(z{z:+5.1f})")
            print(f"  {d} n={m:5d}  " + " ".join(out))

    print("\n前端后果量化（24h 满窗 ≈1727 局、2σ 着色）：")
    N24 = 1727
    for c in range(1, 10):
        p0 = tbl[c] / 100
        s2 = 2 * math.sqrt(p0 * (1 - p0) / N24) * 100
        dev = cnt[c] / n * 100 - tbl[c]
        if abs(dev) > s2:
            print(f"  号{c} 恒被判「{'偏热' if dev > 0 else '偏冷'}」"
                  f"（偏差 {dev:+.2f}pp > 2σ={s2:.2f}pp）—— 与盘面无关，纯基线错")


if __name__ == "__main__":
    main()
