#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
analyze_repeat.py — 重现观察期(repeat_guard)的诊断器 / 门禁 / 消融台
================================================================================
走生产代码路径(backend_async/app/predictor_bridge.py → jiufa_data/
spell_tamer_monitor.py),在仓内自带的真机库上逐局因果回放,产出《灵机推演重现
观察期优化方案.md》里的**全部实测数字**。零随机源、逐字节确定性,重跑必须复现。

用法
----
  python3 analyze_repeat.py                      # 关/定稿 A/B 全表(附旧默认对照)
  python3 analyze_repeat.py --hazard             # 实地核查:逐兽危险率对间隔审计
  python3 analyze_repeat.py --gate               # 仓内等价门禁(确定性 + 刻度惰性)
  python3 analyze_repeat.py --gate --baseline /path/to/old/jiufa_data
                                                 # 与改造前引擎逐局字节比对
  python3 analyze_repeat.py --sweep rg_theta=0.25,0.35,0.5
                                                 # 单刻度扫描(可重复 --sweep)
  python3 analyze_repeat.py --rooms 2678075 --db /path/x.db

口径
----
· 成熟期 = 跳过前 400 局热身(与 analyze_rotate 同口径),避免冷启动伪影。
· 「刚出仍带」= 上一局实际开出 330x/250x/500x 稀有号,本局四码仍带它 —— 即
  用户投诉的原型场景;「主位」为其中进主推两席的子集。「放弃的重复命中」=
  上局出 c、本局未带 c、而本局又开 c。定稿 pmax=0.075 为「当下稀有档」语义:
  少量残留来自该号 24h 频率暂越 7.5% 的豁开段与四关豁免段,均可逐条归因。
· 「四码回报」= 每局对四码各押 1u,命中得该号倍率 u。相对排序稳健,绝对值不是
  实盘派彩。显著性用 McNemar 精确二项;三房 7 天 34,982 成熟局配对标准误
  ≈0.20pp ⇒ **±0.4pp 以内的档位差异在这批数据上不可分辨**,读表勿过度解读。
  逐局确定性连锁(改一局四码 ⇒ 后续赤字/惩罚/权重全链漂移)是波动的主要来源。
"""
import argparse
import bisect
import importlib.util
import json
import math
import os
import sqlite3
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
STEP = 50001
COLD5 = (3, 4, 5, 6, 9)
RARE3 = (3, 4, 9)                # 报表口径:330x/250x/500x 三只大倍率
MULT = {1: 10, 2: 50, 3: 330, 4: 250, 5: 100, 6: 100, 7: 50, 8: 50, 9: 500}
WARMUP_SKIP = 400

import yaml  # noqa: E402

with open(os.path.join(ROOT, "backend_async", "config.yaml"), encoding="utf-8") as f:
    _ALL = yaml.safe_load(f)
PRED_CFG = dict(_ALL["prediction"])
BEAST_IDS = dict(_ALL["custom_beast_ids"])
DEFAULT_DB = os.path.join(ROOT, "jiufa_data", "spell_tamer_data.db")

FINAL = {"repeat_guard": 1, "rg_theta": 0.35, "rg_cap": 20, "rg_pmax": 0.075,
         "rg_seat_damp": 0.25, "rg_minm": 30, "rg_zpos": 2.5}
LEGACY = {**FINAL, "rg_pmax": 0.05}         # 旧默认对照:3 号骑线漏罩(仅供迁移期比对)
WILD_OFF = {"repeat_guard": 0, "rg_theta": 2.0, "rg_cap": 200, "rg_pmax": 0.25,
            "rg_seat_damp": 0.0, "rg_minm": 1, "rg_zpos": 0.0}


def _bridge_module(engine_dir):
    """按指定引擎目录加载一份独立的 predictor_bridge(便于与旧引擎并排比对)。"""
    os.environ["STA_ENGINE_DIR"] = engine_dir
    for m in ("spell_tamer_monitor", "predictor_bridge"):
        sys.modules.pop(m, None)
    spec = importlib.util.spec_from_file_location(
        "predictor_bridge", os.path.join(ROOT, "backend_async", "app", "predictor_bridge.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def load_rounds(room, db):
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    rows = con.execute("SELECT round_id, custom_id, start_ms, draw_ms FROM rounds "
                       "WHERE room_id=? AND custom_id IS NOT NULL ORDER BY round_id",
                       (room,)).fetchall()
    con.close()
    return rows


def rooms_in(db):
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    r = [x[0] for x in con.execute(
        "SELECT DISTINCT room_id FROM rounds ORDER BY room_id")]
    con.close()
    return r


def replay(pb, room, rounds, cfg, first=30):
    """复刻 worker._settle_and_predict 的时序:先结算推权重,再生成下一局预测。
    每局附带引擎口径(24h 窗内)的逐稀有号间隔 gap。"""
    br = pb.PredictorBridge(cfg, BEAST_IDS)
    kv, pending, recs = {}, {}, []
    tw = int(float(cfg.get("train_window_hours", 24.0) or 0) * 3600 * 1000)
    mx = int(cfg.get("max_train", 5000))
    starts = [r[2] for r in rounds]
    cids = [r[1] for r in rounds]
    for idx, (rid, cid, sms, dms) in enumerate(rounds):
        p = pending.pop(rid, None)
        if p is not None:
            p["actual"] = cid
            p["hit"] = ("main" if cid in p["four"][:2]
                        else ("guard" if cid in p["four"][2:] else "miss"))
            kv.update(br.update_after_settle(
                room, {"models": p["models"], "ens": p["ens"]}, cid, kv))
        if idx < first:
            continue
        now = (dms or sms + 46500) + 1500
        lo = bisect.bisect_left(starts, now - tw, 0, idx + 1) if tw > 0 else 0
        seq = cids[lo:idx + 1][-mx:]
        gap = {}
        for c in COLD5:
            g = len(seq)
            for i in range(len(seq) - 1, -1, -1):
                if seq[i] == c:
                    g = len(seq) - 1 - i
                    break
            gap[c] = g
        res, dirty = br.run_prediction(room, seq, kv)
        kv.update(dirty)
        rec = {"four": list(res["main"]) + list(res["guard"]),
               "models": res["models"], "ens": res["ens"],
               "why": ((res.get("explore") or {}).get("why") or ""),
               "prev": seq[-1], "gap": gap, "actual": None, "hit": None}
        pending[rid + STEP] = rec
        recs.append(rec)
    return recs


def metrics(recs):
    m = [r for r in recs[WARMUP_SKIP:] if r["hit"]]
    n = len(m)
    inc = Counter()
    seat = Counter()
    opp = Counter()
    forf = Counter()
    for r in m:
        for c in RARE3:
            if r["gap"][c] == 0:
                opp[c] += 1
                if c in r["four"]:
                    inc[c] += 1
                    if c in r["four"][:2]:
                        seat[c] += 1
                elif r["actual"] == c:
                    forf[c] += 1
    sel = Counter()
    for r in m:
        for c in r["four"]:
            if c in COLD5:
                sel[c] += 1
    tc = sum(sel.values()) or 1
    rare_hits = sum(1 for r in m if r["actual"] in RARE3 and r["actual"] in r["four"])
    return dict(
        n=n,
        hit4=sum(1 for r in m if r["hit"] != "miss") / n * 100,
        hitm=sum(1 for r in m if r["hit"] == "main") / n * 100,
        retf=sum(MULT[r["actual"]] for r in m if r["actual"] in r["four"]) / n,
        inc=dict(inc), seat=dict(seat), opp=dict(opp), forf=dict(forf),
        rare_hits=rare_hits,
        shares={c: sel.get(c, 0) / tc * 100 for c in COLD5},
        baodi=sum(1 for r in m if "保底" in r["why"]) / n * 100,
        waived=sum(1 for r in m if "随势跟进" in r["why"]),
        expiry=sum(1 for r in m if "距上次开出" in r["why"]),
        hits=[1 if r["hit"] != "miss" else 0 for r in m])


def merge(per):
    rs = list(per.values())
    N = sum(x["n"] for x in rs)
    w = lambda k: sum(x[k] * x["n"] for x in rs) / N
    agg = lambda k: {c: sum(x[k].get(c, 0) for x in rs) for c in RARE3}
    sh = {c: sum(x["shares"][c] * x["n"] for x in rs) / N for c in COLD5}
    return dict(n=N, hit4=w("hit4"), hitm=w("hitm"), retf=w("retf"),
                inc=agg("inc"), seat=agg("seat"), opp=agg("opp"), forf=agg("forf"),
                rare_hits=sum(x["rare_hits"] for x in rs), shares=sh,
                baodi=w("baodi"), waived=sum(x["waived"] for x in rs),
                expiry=sum(x["expiry"] for x in rs))


def mcnemar(a, b):
    x = y = 0
    n = min(len(a), len(b))
    d = sum(b[i] - a[i] for i in range(n))
    for i in range(n):
        if a[i] and not b[i]:
            x += 1
        if b[i] and not a[i]:
            y += 1
    k, N = min(x, y), x + y
    p = min(1.0, sum(math.comb(N, i) for i in range(k + 1)) / 2 ** N * 2) if N else 1.0
    return d / n * 100, x, y, p


def run_cfg(pb, data, over):
    cfg = {**PRED_CFG, **over}
    per, hits = {}, []
    for room, rounds in data.items():
        per[room] = metrics(replay(pb, room, rounds, cfg))
        hits += per[room]["hits"]
    return merge(per), hits, per


def _fmt3(d):
    return "/".join(str(d.get(c, 0)) for c in RARE3)


HDR = (f"{'方案':<18}{'四码中%':>8}{'Δpp':>7}{'p值':>8}{'主中%':>7}{'四码回报':>9}"
       f"{'刚出仍带3/4/9(机会)':>26}{'主位':>5}{'放弃重复中':>11}{'稀有中':>7}"
       f"{'保底%':>7}{'随势':>5}{'期满注':>7}")


def line(name, a, mc=None):
    d = f"{mc[0]:>7.2f}{mc[3]:>8.4f}" if mc else f"{'—':>7}{'—':>8}"
    return (f"{name:<18}{a['hit4']:>8.2f}{d}{a['hitm']:>7.2f}{a['retf']:>9.2f}"
            f"{_fmt3(a['inc']) + '(' + _fmt3(a['opp']) + ')':>26}"
            f"{sum(a['seat'].values()):>5}{sum(a['forf'].values()):>11}"
            f"{a['rare_hits']:>7}{a['baodi']:>7.2f}{a['waived']:>5}{a['expiry']:>7}")


# ─────────────────────────── 实地核查:危险率审计 ───────────────────────────────
def cmd_hazard(args, data):
    print("═" * 78)
    print("实地核查:逐兽危险率对间隔(问题「刚出后是否更不容易再出?」的直接测量)")
    print("═" * 78)
    cids_all = {room: [r[1] for r in rounds] for room, rounds in data.items()}
    for c in RARE3:
        tot = sum(x.count(c) for x in cids_all.values())
        n = sum(len(x) for x in cids_all.values())
        base = tot / n
        buckets = [(0, 0), (1, 3), (4, 7), (8, 15), (16, 31), (32, 63), (64, 10 ** 9)]
        cnt = Counter()
        hit = Counter()
        rep = [0, 0]
        for x in cids_all.values():
            last = None
            for i, v in enumerate(x):
                if last is not None:
                    g = i - last - 1
                    for lo, hi in buckets:
                        if lo <= g <= hi:
                            cnt[(lo, hi)] += 1
                            if v == c:
                                hit[(lo, hi)] += 1
                            break
                if v == c:
                    if last is not None and i - last == 1:
                        rep[1] += 1
                    last = i
            # 紧随样本量 = 该房 c 的出现次数(末次除外)
            rep[0] += max(0, x.count(c) - (1 if x and x[-1] == c else 0))
        print(f"\n{c}号({MULT[c]}x)  24h 长程基率={base * 100:.2f}%  "
              f"紧随再出 {rep[1]}/{rep[0]}"
              f" = {rep[1] / max(1, rep[0]) * 100:.2f}%")
        for lo, hi in buckets:
            m = cnt[(lo, hi)]
            if not m:
                continue
            h = hit[(lo, hi)] / m
            z = (hit[(lo, hi)] - m * base) / math.sqrt(max(m * base * (1 - base), 1e-9))
            tag = f"{lo}" if lo == hi else (f"{lo}-{hi}" if hi < 10 ** 9 else f"{lo}+")
            print(f"    间隔{tag:>6}: 危险率 {h * 100:5.2f}%  (n={m:5d}, z{z:+.1f})")
    print("\n判读:z 全程 |z|<2 ⇒ 危险率对间隔平坦 ⇒ 「刚出后再出」与任意时刻等概率,")
    print("推迟携带统计等价;若某号紧随段显著为正(如 4 号),它就是「真扎堆」,由")
    print("rg_pmax 豁开或由房间自证豁免按窗放行。")


# ─────────────────────────────── 等价门禁 ─────────────────────────────────────
def cmd_gate(args, pb, data):
    ok = True
    print("═" * 78)
    print("门禁 A:开关关(repeat_guard=0)+ 极端刻度 ⇒ 输出必须与纯关逐局全同")
    print("═" * 78)
    for room, rounds in data.items():
        a = replay(pb, room, rounds, {**PRED_CFG, "repeat_guard": 0})
        b = replay(pb, room, rounds, {**PRED_CFG, **WILD_OFF})
        same = sum(1 for x, y in zip(a, b)
                   if (x["four"], x["why"]) == (y["four"], y["why"]))
        flag = "✅" if same == len(a) else "❌"
        ok &= same == len(a)
        print(f"  [{room}] {same}/{len(a)} {flag}")

    print("═" * 78)
    print("门禁 B:定稿刻度重跑两遍 ⇒ 逐局确定(含 why)")
    print("═" * 78)
    for room, rounds in data.items():
        a = replay(pb, room, rounds, {**PRED_CFG, **FINAL})
        b = replay(pb, room, rounds, {**PRED_CFG, **FINAL})
        same = sum(1 for x, y in zip(a, b)
                   if (x["four"], x["why"]) == (y["four"], y["why"]))
        flag = "✅" if same == len(a) else "❌"
        ok &= same == len(a)
        print(f"  [{room}] {same}/{len(a)} {flag}")

    if args.baseline:
        print("═" * 78)
        print("门禁 C:与改造前引擎逐局字节比对(repeat_guard=0)")
        print("═" * 78)
        for room, rounds in data.items():
            pbo = _bridge_module(args.baseline)
            a = replay(pbo, room, rounds, dict(PRED_CFG))
            pbn = _bridge_module(os.path.join(ROOT, "jiufa_data"))
            b = replay(pbn, room, rounds, {**PRED_CFG, "repeat_guard": 0})
            same = sum(1 for x, y in zip(a, b)
                       if (x["four"], x["why"], x["models"], x["ens"])
                       == (y["four"], y["why"], y["models"], y["ens"]))
            flag = "✅" if same == len(a) else "❌"
            ok &= same == len(a)
            print(f"  [{room}] {same}/{len(a)} {flag}")
    print("\n门禁结论:", "✅ 全部通过" if ok else "❌ 存在破坏,不得合入")
    return 0 if ok else 1


# ─────────────────────────────── A/B 与扫描 ───────────────────────────────────
def cmd_ab(args, pb, data):
    sweeps = []
    for s in args.sweep:
        k, vs = s.split("=", 1)
        for v in vs.split(","):
            sweeps.append((f"{k}={v}", {**FINAL, k.strip(): float(v)}))
    plans = [("关(现行)", {"repeat_guard": 0}),
             ("定稿 p.075", FINAL),
             ("对照 p.05(旧默认)", LEGACY)] + sweeps
    print(HDR)
    print("─" * len(HDR))
    base_hits = None
    out = {}
    for name, over in plans:
        a, hits, per = run_cfg(pb, data, over)
        mc = mcnemar(base_hits, hits) if base_hits is not None else None
        if base_hits is None:
            base_hits = hits
        out[name] = {"merged": {k: v for k, v in a.items() if k != "hits"},
                     "per_room": {r: {k: v for k, v in x.items() if k != "hits"}
                                  for r, x in per.items()}}
        print(line(name, a, mc))
    print("\n判读:「刚出仍带」括号内为机会数(上局开出该号的局数)。定稿档残留应")
    print("可逐条归因:pmax 豁开段(该号 24h 频率暂越 7.5%)、四关豁免段(why 落款")
    print("「随势跟进」)、保底/换血结构位(均带落款)。±0.4pp 内的四码中差异不可分辨。")
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=1)
        print(f"\n汇总已写入 {args.json}")
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--hazard", action="store_true", help="实地核查:危险率对间隔审计")
    ap.add_argument("--gate", action="store_true", help="跑仓内等价门禁")
    ap.add_argument("--baseline", default=None,
                    help="改造前引擎目录(含 spell_tamer_monitor.py)")
    ap.add_argument("--sweep", action="append", default=[], metavar="K=v1,v2",
                    help="在定稿刻度上单刻度扫描(可重复)")
    ap.add_argument("--rooms", default=None, help="逗号分隔房号(默认库内全部)")
    ap.add_argument("--db", default=DEFAULT_DB)
    ap.add_argument("--json", default=None, help="把汇总写成 JSON")
    args = ap.parse_args()

    rooms = args.rooms.split(",") if args.rooms else rooms_in(args.db)
    data = {r: load_rounds(r, args.db) for r in rooms}
    data = {r: v for r, v in data.items() if len(v) > WARMUP_SKIP + 60}
    if not data:
        print("库内无足量房间数据")
        return 2
    if args.hazard:
        return cmd_hazard(args, data) or 0
    pb = _bridge_module(os.path.join(ROOT, "jiufa_data"))
    if args.gate:
        return cmd_gate(args, pb, data)
    return cmd_ab(args, pb, data)


if __name__ == "__main__":
    sys.exit(main())
