#!/usr/bin/env bash
# ============================================================================
# export-rooms.sh —— 从生产 PG 导出「其它房间」的 rounds 到同构 SQLite,
#                    供 window_audit/ 全套脚本离线复验(样本外验证用)。
# 用法(在部署机上,与 deploy-maxxiang.sh 同一台):
#     sudo bash export-rooms.sh                    # 交互:先列候选房再选
#     sudo bash export-rooms.sh --days 7 --min-rounds 10000 --limit 30
#     sudo bash export-rooms.sh --rooms 111,222    # 指定房号
#     sudo bash export-rooms.sh --list             # 只列候选,不导
# 产物: ./holdout.db   (rounds 表,列名/类型与 jiufa_data/spell_tamer_data.db 同构)
# ============================================================================
set -Eeuo pipefail

INSTALL_DIR="${INSTALL_DIR:-/opt/maxxiang}"
DAYS=7; MIN_ROUNDS=10000; LIMIT=30; ROOMS=""; LIST_ONLY=0
OUT="$(pwd)/holdout.db"
# 已用于定标的三个房,默认排除(它们是训练集,不能当验证集)
EXCLUDE="1275859,2678075,3746870"

while [ $# -gt 0 ]; do
  case "$1" in
    --days) DAYS="$2"; shift 2;;
    --min-rounds) MIN_ROUNDS="$2"; shift 2;;
    --limit) LIMIT="$2"; shift 2;;
    --rooms) ROOMS="$2"; shift 2;;
    --exclude) EXCLUDE="$2"; shift 2;;
    --out) OUT="$2"; shift 2;;
    --list) LIST_ONLY=1; shift;;
    *) echo "未知参数: $1" >&2; exit 2;;
  esac
done

cd "$INSTALL_DIR" 2>/dev/null || { echo "找不到 $INSTALL_DIR(用 INSTALL_DIR=... 覆盖)" >&2; exit 1; }

# 房号白名单:只允许数字与逗号(繁星房号恒为数字串)。挡住注入与手滑的引号。
chk_ids() { case "$1" in ""|*[!0-9,]*) echo "非法房号列表(只允许数字与逗号): $1" >&2; exit 2;; esac; }
[ -n "$ROOMS" ] && chk_ids "$ROOMS"
[ -n "$EXCLUDE" ] && chk_ids "$EXCLUDE"
DEPLOY_DIR="$INSTALL_DIR/deploy"; [ -d "$DEPLOY_DIR" ] || DEPLOY_DIR="$INSTALL_DIR"
ENV_FILE="$DEPLOY_DIR/.env"; [ -f "$ENV_FILE" ] || ENV_FILE="$INSTALL_DIR/.env"

if docker compose version >/dev/null 2>&1; then DC=(docker compose); else DC=(docker-compose); fi
dc() { (cd "$DEPLOY_DIR" && "${DC[@]}" -p maxxiang "$@"); }

envget() { [ -f "$ENV_FILE" ] && sed -n "s/^$1=//p" "$ENV_FILE" | tail -n1 || true; }
PGUSER="$(envget POSTGRES_USER)"; PGUSER="${PGUSER:-star}"
PGDB="$(envget POSTGRES_DB)";     PGDB="${PGDB:-spelltamer}"

psqlq() { dc exec -T postgres psql -U "$PGUSER" -d "$PGDB" -v ON_ERROR_STOP=1 "$@"; }

echo "▶ PG: user=$PGUSER db=$PGDB  (compose 目录 $DEPLOY_DIR)"
EXCL_SQL="$(echo "$EXCLUDE" | sed "s/[^,]*/'&'/g")"

# ── ① 候选房清单 ──────────────────────────────────────────────────────────
CAND_SQL="
SELECT room_id,
       count(*)                                        AS n,
       min(date_local)                                 AS d0,
       max(date_local)                                 AS d1,
       (max(start_ms)-min(start_ms))/86400000.0        AS span_days,
       count(*) FILTER (WHERE custom_id IS NULL)       AS null_cid
FROM rounds
WHERE room_id NOT IN ($EXCL_SQL)
GROUP BY room_id
HAVING count(*) >= $MIN_ROUNDS
   AND (max(start_ms)-min(start_ms))/86400000.0 >= $DAYS - 0.5
ORDER BY n DESC
LIMIT $LIMIT;"

echo "▶ 候选房(局数 ≥ $MIN_ROUNDS 且跨度 ≥ ${DAYS}天,已排除训练三房):"
psqlq -c "$CAND_SQL"
[ "$LIST_ONLY" = 1 ] && exit 0

if [ -z "$ROOMS" ]; then
  ROOMS="$(psqlq -At -c "$CAND_SQL" | cut -d'|' -f1 | paste -sd, -)"
  ROOMS="$(printf %s "$ROOMS" | tr -d " \r")"; chk_ids "$ROOMS"
fi
[ -n "$ROOMS" ] || { echo "没有满足条件的房。放宽 --min-rounds / --days 再试。" >&2; exit 1; }
echo "▶ 将导出 $(echo "$ROOMS" | tr ',' '\n' | wc -l) 个房: $ROOMS"

# ── ② 导出 CSV(NULL 用空串,与 sqlite 装载约定一致) ────────────────────────
ROOMS_SQL="$(echo "$ROOMS" | sed "s/[^,]*/'&'/g")"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
echo "▶ 导出 CSV …"
psqlq -c "
COPY (SELECT room_id, round_id, beast_name, official_id, custom_id, multiplier,
             start_ms, draw_ms, draw_local, date_local, source, created_at
      FROM rounds WHERE room_id IN ($ROOMS_SQL) ORDER BY room_id, round_id)
TO STDOUT WITH (FORMAT csv, HEADER true, NULL '');" > "$TMP/rounds.csv"
CSV_N=$(wc -l < "$TMP/rounds.csv"); echo "  CSV 行数: $CSV_N"
[ "$CSV_N" -gt 1 ] || { echo "CSV 只有表头,没导出任何行 —— 检查房号与 PG 连通性" >&2; exit 1; }

# ── ③ 灌入同构 SQLite ─────────────────────────────────────────────────────
echo "▶ 构建 SQLite → $OUT"
rm -f "$OUT" "$OUT-wal" "$OUT-shm"
python3 - "$TMP/rounds.csv" "$OUT" <<'PY'
import csv, sqlite3, sys
src, dst = sys.argv[1], sys.argv[2]
con = sqlite3.connect(dst)
con.execute("""CREATE TABLE rounds (
    room_id     TEXT    NOT NULL,
    round_id    INTEGER NOT NULL,
    beast_name  TEXT    NOT NULL,
    official_id INTEGER,
    custom_id   INTEGER,
    multiplier  INTEGER,
    start_ms    INTEGER,
    draw_ms     INTEGER,
    draw_local  TEXT,
    date_local  TEXT,
    source      TEXT,
    created_at  TEXT,
    PRIMARY KEY (room_id, round_id))""")
con.execute("CREATE TABLE predictions (room_id TEXT, round_id INTEGER, main_ids TEXT, guard_ids TEXT)")
con.execute("CREATE TABLE kv (k TEXT PRIMARY KEY, v TEXT)")
INTS = {1,3,4,5,6,7}
rows = 0
with open(src, newline="", encoding="utf-8") as f:
    rd = csv.reader(f); next(rd)
    buf = []
    for r in rd:
        rec = [None if v == "" else (int(v) if i in INTS else v) for i, v in enumerate(r)]
        buf.append(rec); rows += 1
        if len(buf) >= 5000:
            con.executemany("INSERT OR IGNORE INTO rounds VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", buf); buf = []
    if buf: con.executemany("INSERT OR IGNORE INTO rounds VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", buf)
con.commit()
n = con.execute("SELECT count(*) FROM rounds").fetchone()[0]
print(f"  写入 {n} 行 (CSV {rows} 行)")
print("  逐房:")
for rm, c, d0, d1 in con.execute(
        "SELECT room_id,count(*),min(date_local),max(date_local) FROM rounds GROUP BY room_id ORDER BY 2 DESC"):
    print(f"    {rm}  {c:>6} 局  {d0} ~ {d1}")
bad = con.execute("SELECT count(*) FROM rounds WHERE custom_id IS NULL").fetchone()[0]
if bad: print(f"  ⚠ custom_id 为空 {bad} 行(回放会自动跳过)")
con.execute("VACUUM"); con.close()
PY
echo "✅ 完成: $OUT"
echo
echo "接下来(把 holdout.db 拷到有项目源码的机器上):"
echo "  cd window_audit"
echo "  python3 replay_harness.py <房号> --db /path/holdout.db"
echo "  python3 frontier_audit.py --db /path/holdout.db"
