#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
训练窗口裁决器 — retention 调 7 天的收官动作。
================================================================================
对每个候选训练窗在同一份真实出怪流上做完整生产口径回放,比较四码命中率与冷门命中。

⚠ 4.9.5 方法论修正(旧版结论偏保守,勿再用旧版数字)
--------------------------------------------------------------------------------
旧版把**全部**回放局都算进命中率。但两个候选窗在「数据跨度 < 大窗」的那段前缀上
取到的 seq **完全相同** ⇒ 预测逐字节相同 ⇒ 那一段对两边贡献同一批命中,只会
**稀释**差异。自带三房库实测:24h vs ∞ 的净差在全域是 −0.39pp、在公平域是
−0.77pp —— 旧口径把真实差异砍掉一半,足以让一个该被裁决的窗口逃过判据。

本版给出两套口径,并以**公平域**为准:
  · 全域    = 所有已结算回放局(与旧版可比,仅作对照);
  · 公平域  = 目标局起点 ≥ 数据起点 + max(有限候选窗) 的部分 —— 此时所有候选窗
              都已「满窗」,seq 真正不同,比较才有意义。
同时把不配对的二项 σ 换成**配对 McNemar 精确检验**:同一局两窗各中/各不中高度
相关,配对检验功效高得多(实测同一组数据:24h vs ∞ 不配对不显著、配对 p=0.027)。

判读规则(脚本自动执行并打印结论):
  · 数据跨度必须 ≥ 窗口 + 96h 评估期,否则该窗口标记〔不可裁决〕;
  · 公平域配对检验 p < 0.05 且净差为正 → 有裁决力,取该候选;
  · 否则 → 维持现行值(短窗抗漂移,且不必改 max_train)。

⚠ 4.9.9 修复:公平域为空时不再静默退出
--------------------------------------------------------------------------------
公平域下界 = 数据起点 + **候选集合里最大的有限窗**。于是往候选里加一个超长窗
(如 168h,而自带库跨度只有 167.98h)会把**所有**候选一起判死。旧版对此毫无表示:
实测 `--rooms 2678075 --windows 3,168 --keep 3` 会照常打印「公平域 0.00% (0/0)」,
随后因 `len(rows) < 2` **裸 return —— 无结论、退出码 0**,与「跑完了、没问题」
在输出上不可区分。现改为:该房提前判空并跳过(顺带省掉每窗数分钟的无谓回放)、
公平域列显示「—」而非伪造的 0.00%、结尾打印明确的〔无法裁决〕并以退出码 2 退出。
本轮**未动**统计口径(仍是共享公平域 + 配对 McNemar)—— 换成逐候选严格域
(起点 + max(现行窗, W))能避开空域,但代价是各候选落在不同的域上、净差列不再
横向可比,那是另一种失真。逐候选严格域作为**旁证**放在 window_audit/win_report.py
的「层三」,不替换本裁决器的判据。

数据源二选一:
  --sqlite /path/x.db          (缺省: 仓库自带三房 7 天快照)
  --pg-dsn postgresql://user:pw@host:5432/spelltamer   (线上正式跑法)
覆写窗口时自动解除 max_train 的静默截短(5000 局 ≈ 69.4h,详见 README)。
"""
import argparse, asyncio, math, os, random, sqlite3, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import replay_harness as rh

COLD = (3, 4, 5, 6, 9)
STEP = 50001
MIN_EVAL_H = 96.0


def rounds_from_pg(dsn, room):
    import asyncpg

    async def _go():
        con = await asyncpg.connect(dsn)
        rows = await con.fetch(
            "SELECT round_id, custom_id, start_ms, draw_ms FROM rounds "
            "WHERE room_id=$1 AND custom_id IS NOT NULL ORDER BY round_id", str(room))
        await con.close()
        return [(r["round_id"], r["custom_id"], r["start_ms"], r["draw_ms"]) for r in rows]
    return asyncio.run(_go())


def mcnemar(a, b):
    """配对精确检验(二项 p=0.5)。a/b: {key: 0|1} 同域。

    返回 (b01, b10, p, n_pairs):b01 = a 中而 b 不中,b10 = b 中而 a 不中。
    只有**分歧局**进入检验 —— 两边都中或都不中的局不含任何区分信息,
    把它们算进去正是不配对检验功效低的原因。
    """
    keys = set(a) & set(b)
    b01 = sum(1 for k in keys if a[k] == 1 and b[k] == 0)
    b10 = sum(1 for k in keys if a[k] == 0 and b[k] == 1)
    n = b01 + b10
    if n == 0:
        return b01, b10, 1.0, len(keys)
    k = min(b01, b10)
    s = sum(math.comb(n, i) for i in range(k + 1))
    # 注意写法:必须是 `2 * s`(整数)再整数真除,**不能**写 `2.0 * s` ——
    # 后者会先把 s 转成 float,而 n≈4500 时 s 是一个上千位的大整数,
    # 当场 OverflowError(已实测炸过一次)。整数真除由 CPython 正确定舍入。
    try:
        p = min(1.0, 2 * s / (2 ** n))
    except OverflowError:            # n 极大时连整数真除都可能越界 ⇒ 正态近似兜底
        z = (abs(b01 - b10) - 1.0) / math.sqrt(n)
        p = math.erfc(max(0.0, z) / math.sqrt(2.0))
    return b01, b10, p, len(keys)


def replay_one(room, rounds, hours):
    """跑一个候选窗,返回逐局已结算记录(供配对检验与分域统计)。"""
    cfg = dict(rh.PRED_CFG)
    cfg["train_window_hours"] = hours
    need = int(hours * 3600 * 1000 / STEP) + 8 if hours > 0 else 10 ** 7
    cfg["max_train"] = max(int(cfg.get("max_train", 5000)), need)
    recs, _ = rh.replay(room, rounds, cfg)
    return [r for r in recs if r["actual"] is not None]


def summarize(settled, t_from, mc_seed=20260718, mc_n=2000):
    """在 [t_from, ∞) 这一域上统计四码与冷门(随机基线走同 k 蒙特卡洛)。"""
    s = [r for r in settled if r["target"] >= t_from]
    n = len(s)
    hit4 = sum(1 for r in s if r["hit"] != "miss")
    kr = [r for r in s if r["k"] >= 1]
    ch = sum(1 for r in kr if r["actual"] in r["coldset"])
    rng = random.Random(mc_seed)
    hits = [sum(1 for r in kr if r["actual"] in rng.sample(COLD, r["k"]))
            for _ in range(mc_n)]
    mu = sum(hits) / mc_n
    sd = (sum((x - mu) ** 2 for x in hits) / mc_n) ** 0.5 or 1e-9
    return {"n": n, "hit4": hit4, "p4": hit4 / n if n else 0.0,
            "kn": len(kr), "cold": ch, "mc_mu": mu, "mc_sd": sd,
            "z_cold": (ch - mu) / sd,
            "flags": {r["target"]: (0 if r["hit"] == "miss" else 1) for r in s}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rooms", default="1275859,2678075,3746870")
    ap.add_argument("--windows", default="24,72", help="候选窗口小时数,逗号分隔;0=不限")
    ap.add_argument("--keep", type=float, default=None,
                    help="现行生效窗(缺省取候选里的第一个);裁决以它为基准做配对比较")
    src = ap.add_mutually_exclusive_group()
    src.add_argument("--sqlite", default=rh.DEFAULT_DB)
    src.add_argument("--pg-dsn", default=None)
    a = ap.parse_args()

    wins = [float(x) for x in a.windows.split(",")]
    rooms = [r.strip() for r in a.rooms.split(",") if r.strip()]
    keep = a.keep if a.keep is not None else wins[0]
    finite = [h for h in wins if h > 0]
    fair_h = max(finite) if finite else 0.0

    print(f"数据源: {'PG ' + a.pg_dsn.split('@')[-1] if a.pg_dsn else a.sqlite}")
    print(f"公平域下界: 数据起点 + {fair_h:g}h(此后所有候选窗才都满窗)")

    per = {h: {} for h in wins}
    agg = {h: {"n": 0, "hit4": 0, "cold": 0, "mu": 0.0, "var": 0.0, "bad": 0}
           for h in wins}
    empty_rooms = []                       # 公平域为空的房(见 4.9.9 缺陷 E)
    for room in rooms:
        rounds = (rounds_from_pg(a.pg_dsn, room) if a.pg_dsn
                  else rh.load_rounds(room, a.sqlite))
        if len(rounds) < 200:
            print(f"[{room}] 仅 {len(rounds)} 局,跳过")
            continue
        t0 = rounds[0][2]
        span_h = (rounds[-1][2] - t0) / 3600000.0
        t_fair = t0 + int(fair_h * 3600 * 1000)
        # ── 4.9.9 修复:公平域为空要**当场喊**,不能一路跑下去印 0.00% ──────────────
        # 旧行为(实测 --windows 3,168 于 168.0h 跨度的自带库):公平域 n=0 却照样
        # 打印「公平域  0.00% (0/0)」,随后 rows 为空、`len(rows) < 2` 静默 return,
        # **连结论都不打一行、退出码还是 0**。运维看到的是两条 0.00% 和一个干净退出。
        # 这里改成:提前判死该房并跳过(顺带省掉每窗数分钟的无谓全量回放)。
        if span_h <= fair_h:
            print(f"[{room}] {len(rounds)} 局, 跨度 {span_h:.1f}h  "
                  f"⚠〔公平域为空:跨度 ≤ 公平域下界 {fair_h:g}h〕—— 跳过该房,"
                  f"不做无谓回放。候选里最大的有限窗是 {fair_h:g}h,"
                  f"要裁决它至少需要 {fair_h + MIN_EVAL_H:g}h 数据。")
            empty_rooms.append(room)
            continue
        print(f"[{room}] {len(rounds)} 局, 跨度 {span_h:.1f}h")
        for h in wins:
            settled = replay_one(room, rounds, h)
            full = summarize(settled, 0)
            fair = summarize(settled, t_fair)
            ok = span_h >= (h + MIN_EVAL_H) if h > 0 else span_h >= MIN_EVAL_H
            flag = "" if ok else "〔不可裁决:跨度<窗口+96h评估期〕"
            fair_txt = (f"{fair['p4']*100:5.2f}% ({fair['hit4']}/{fair['n']})"
                        if fair["n"] else "  —   (0/0,公平域为空)")
            print(f"    窗口{h:>5g}h  全域 {full['p4']*100:5.2f}% "
                  f"({full['hit4']}/{full['n']})"
                  f" │ 公平域 {fair_txt}"
                  f"  冷门 {fair['cold']} (随机{fair['mc_mu']:.0f}±{fair['mc_sd']:.1f},"
                  f" z={fair['z_cold']:+.1f}) {flag}")
            g = agg[h]
            g["n"] += fair["n"]; g["hit4"] += fair["hit4"]; g["cold"] += fair["cold"]
            g["mu"] += fair["mc_mu"]; g["var"] += fair["mc_sd"] ** 2
            g["bad"] += 0 if ok else 1
            for tgt, v in fair["flags"].items():
                per[h][(room, tgt)] = v

    print("─" * 78)
    rows = []
    for h in wins:
        g = agg[h]
        if not g["n"]:
            continue
        p = g["hit4"] / g["n"]
        rows.append((h, p, g))
        print(f"合计(公平域) 窗口{h:>5g}h: 四码 {p*100:.2f}% ({g['hit4']}/{g['n']})  "
              f"冷门 {g['cold']} vs 随机 {g['mu']:.0f}±{g['var']**0.5:.1f}"
              + ("  〔含不可裁决房〕" if g["bad"] else ""))
    if len(rows) < 2:
        # 4.9.9:旧版在这里裸 return —— 无结论、退出码 0,与「跑完了、没问题」不可区分。
        if empty_rooms:
            print(f"结论:**无法裁决** —— {len(empty_rooms)}/{len(rooms)} 个房的公平域为空"
                  f"(跨度 ≤ 候选里最大有限窗 {fair_h:g}h)。")
            print(f"      公平域下界由**候选集合里最大的有限窗**决定,所以加一个超长候选"
                  f"(如 168h)会把所有候选一起判死。")
            print(f"      两条出路:① 去掉超长候选,只比数据撑得住的那几档"
                  f"(需要跨度 ≥ 窗口 + {MIN_EVAL_H:g}h 评估期);② 继续攒数据。")
        else:
            print("结论:**无法裁决** —— 公平域内没有两个及以上可比候选窗,勿据此改配置。")
        sys.exit(2)

    print("─" * 78)
    print(f"配对检验(公平域,基准 = 现行 {keep:g}h):")
    base = per.get(keep) or {}
    best, best_p, best_d = keep, 1.0, 0.0
    for h in wins:
        if h == keep or not per[h]:
            continue
        b01, b10, p, n = mcnemar(base, per[h])
        d = (b10 - b01) / n * 100 if n else 0.0
        print(f"  {keep:g}h vs {h:>5g}h: 基准中/对方中 = {b01}/{b10}  "
              f"净差 {d:+.3f}pp  精确 p={p:.4f}  配对n={n}")
        if p < best_p and d > 0:
            best, best_p, best_d = h, p, d

    if any(agg[h]["bad"] for h in wins if agg[h]["n"]):
        print("结论: 存在不可裁决窗口 —— 继续攒数据,勿据此改配置。")
    elif best_p < 0.05:
        need = int(best * 3600 * 1000 / STEP) + 1 if best > 0 else 0
        print(f"结论: 窗口 {best:g}h 在公平域配对检验下显著优于现行 {keep:g}h"
              f"(+{best_d:.2f}pp, p={best_p:.4f})→ 建议改 train_window_hours"
              + (f"(并同步把 max_train 提到 ≥{need} 局)。" if need else "。"))
    else:
        print(f"结论: 无候选窗在公平域显著优于现行 {keep:g}h(最优候选 p={best_p:.4f})"
              f" → 维持 {keep:g}h。短窗抗漂移、不必触碰 max_train;"
              f"若只为省 CPU 而缩窗,请注意抗断流余量按比例同步缩小。")


if __name__ == "__main__":
    main()
