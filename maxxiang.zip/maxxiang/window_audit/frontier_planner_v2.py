#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
frontier_planner_v2.py — 「灵机推演」天花板前沿规划器（9 维精确版）【参考实现·未接线】
⚠ 本文件**不在生产调用链上**，故意放在 window_audit/ 而非 jiufa_data/：
  · 引擎当前仍用 jiufa_data/frontier_planner.py（v1），本次上线不涉及替换；
  · 若将来要换，必须先补 deploy/Dockerfile 的 COPY（test_frontier.py 的
    test_dockerfile_copies_every_engine_module 只扫「被 import 的同目录模块」，
    未接线时扫不到它 —— 漏拷不会报错，只会让风格静默失效）；
  · 并且需单独 A/B：v1/v2 在**退化（并列最优）**时会选到不同顶点，
    真机 p̂ 轨迹上占 1.0% 的求解点，均值差 −0.0003pp（噪声级，不构成收益）。
================================================================================
与 v1(frontier_planner.py) 的关系：**同一个天花板，更小的问题，精确算术**。

可证化简（本文件的立论，已由 window_audit 实地核查坐实）：
    四项指标（总命中/冷门命中/稀有命中/每注回报）对 126 维集合频率 x 的依赖，
    完全经由 9 维号位份额  s_i = Σ_{S∋i} x_S  ——
        总命中 = Σ p_i s_i        冷门 = Σ_{i∈cold} p_i s_i
        稀有  = Σ_{i∈rare} p_i s_i  回报 = Σ p_i·mult_i·s_i / 4
    且 x 的可达份额集恰为超单纯形 Δ(9,4) = { s : Σs_i = 4, 0 ≤ s_i ≤ 1 }
    （其顶点即 126 个四码指示向量；实测 300 个随机 s 全部可达，误差 5e-15）。
  ⇒ 126 变量 LP ≡ 9 变量 LP。同解，且：
     · 用 Fraction 精确有理算术 ⇒ **不存在**浮点退化基停滞，
       v1 注释里"极端量级下主元规则停滞被误当无解"那一整类故障从构造上消失，
       输入钳位/Dantzig 兜底/出解复核三道补丁不再需要（保留复核作最后一道断言）。
     · 无解就是真无解 —— 一阶段残差是精确有理数，与 0 比较不需要阈值。

调度：直接对 9 个号位做最大赤字轮转（每局 debt_i += s_i，取 debt 最大的 4 个各扣 1）。
比 v1 的"126 个集合各自记赤字"更小、更准：
     · 状态 9 个浮点 vs 最多 126 个集合条目；
     · 份额偏差有 Bresenham 界；无需先把 s 分解成集合再调度。

诚实边界（与 v1 一致，勿改）：本模块**不预测**下一局出什么，数据里没有可发现的规律。
它做的是覆盖调度：在四项指标间取数学上可证的最优折中。
"""
from __future__ import annotations

import itertools
from fractions import Fraction as F
from typing import Dict, List, Optional, Sequence, Tuple

__all__ = ["ALL_SETS", "set_metrics", "plan", "plan_shares", "ShareScheduler",
           "decompose", "Scheduler", "LPInfeasible"]

ALL_SETS: Tuple[Tuple[int, ...], ...] = tuple(itertools.combinations(range(1, 10), 4))
N_ID = 9
K_PICK = 4


class LPInfeasible(Exception):
    """约束组合在当前 p̂ 下无可行解（精确算术判定，非数值失败）。"""


# ─────────────────── 精确有理单纯形（小规模、Bland、可证终止） ───────────────────
def _simplex_exact(c: List[F], A: List[List[F]], b: List[F]) -> List[F]:
    """max cᵀu  s.t. Au ≤ b, u ≥ 0。全程 Fraction —— 无舍入、无停滞、Bland 防循环。"""
    m, n = len(A), len(c)
    neg = [i for i in range(m) if b[i] < 0]
    art = len(neg)
    W = n + m + art
    nrow = m + 2
    T = [[F(0)] * (W + 1) for _ in range(nrow)]
    for i in range(m):
        for j in range(n):
            T[i][j] = A[i][j]
        T[i][n + i] = F(1)
        T[i][W] = b[i]
    basis = [n + i for i in range(m)]
    for k, i in enumerate(neg):
        T[i] = [-v for v in T[i]]
        T[i][n + m + k] = F(1)
        basis[i] = n + m + k

    def pivot(pr: int, pc: int) -> None:
        pv = T[pr][pc]
        T[pr] = [v / pv for v in T[pr]]
        Tp = T[pr]
        for r in range(nrow):
            if r != pr and T[r][pc]:
                f = T[r][pc]
                Tr = T[r]
                for j in range(W + 1):
                    Tr[j] -= f * Tp[j]
        basis[pr] = pc

    def run(obj: int, ncols: int) -> None:
        # Bland 最小下标规则 + 精确算术 ⇒ 有限步必停，无需迭代上限兜底
        while True:
            pc = -1
            for j in range(ncols):
                if T[obj][j] < 0:
                    pc = j
                    break
            if pc < 0:
                return
            pr = -1
            best: Optional[F] = None
            for r in range(m):
                if T[r][pc] > 0:
                    ratio = T[r][W] / T[r][pc]
                    if best is None or ratio < best or (ratio == best and basis[r] < basis[pr]):
                        best, pr = ratio, r
            if pr < 0:
                raise LPInfeasible("目标无界")
            pivot(pr, pc)

    if art:
        ph1 = m + 1
        for k in range(art):
            T[ph1][n + m + k] = F(1)
        for i in neg:
            for j in range(W + 1):
                T[ph1][j] -= T[i][j]
        run(ph1, n + m)
        if T[ph1][W] != 0:                    # 精确比较：残差非零 = 真不可行
            raise LPInfeasible("一阶段残差非零：约束确实不可行")
        for r in range(m):
            if basis[r] >= n + m:
                for j in range(n + m):
                    if T[r][j]:
                        pivot(r, j)
                        break
    for j in range(n):
        T[m][j] = -c[j]
    T[m][W] = F(0)
    for r in range(m):
        if basis[r] < n and T[m][basis[r]]:
            f = T[m][basis[r]]
            for j in range(W + 1):
                T[m][j] -= f * T[r][j]
    run(m, n + m)
    u = [F(0)] * n
    for r in range(m):
        if basis[r] < n:
            u[basis[r]] = T[r][W]
    return u


def _frac(x, den: int = 10 ** 12) -> F:
    return F(x).limit_denominator(den) if not isinstance(x, F) else x


# ───────────────────────── 集合指标（与 v1 逐字同口径） ─────────────────────────
def set_metrics(p: Sequence[float], mult: Dict[int, int],
                cold: Sequence[int], rare: Sequence[int]
                ) -> Tuple[List[float], List[float], List[float], List[float]]:
    cs, rs = set(cold), set(rare)
    cov, cld, rar, ev = [], [], [], []
    for S in ALL_SETS:
        cov.append(sum(p[c - 1] for c in S))
        cld.append(sum(p[c - 1] for c in S if c in cs))
        rar.append(sum(p[c - 1] for c in S if c in rs))
        ev.append(sum(p[c - 1] * mult[c] for c in S) / 4.0)
    return cov, cld, rar, ev


# ───────────────────────── 9 维 LP ─────────────────────────
def plan_shares(p: Sequence[float], mult: Dict[int, int],
                cold: Sequence[int] = (3, 4, 5, 6, 9), rare: Sequence[int] = (3, 9),
                cold_min: Optional[float] = None, rare_min: Optional[float] = None,
                ret_min: Optional[float] = None, share_min: float = 0.0,
                share_max: float = 1.0, relax: bool = True,
                tiebreak: Sequence[str] = ("rare", "cold", "ret")
                ) -> Tuple[List[float], Dict[str, object]]:
    """解 9 维 LP，返回 (目标份额 s[9], 诊断)。放宽顺序与 v1 一致：稀有→冷门→回报→露面→上限。

    tiebreak —— **字典序分级优化**。总命中最大化后，最优解常常不唯一（退化），
    此时"带哪几个号"在总命中意义下完全等价，但冷门/稀有/回报会差很多。
    v1 把这个选择交给浮点单纯形的主元顺序（= 求解器运气），实测 400 例模糊对拍里
    56 例出现材料级差异，最悬殊的一例同为 68.377% 总命中、稀有却差 8.88% vs 3.36%。
    这里改成显式分级：先钉死 hit = hit*，再依次最大化 rare → cold → ret。
    **对总命中零成本**，纯捡回被浪费的次级指标。设 tiebreak=() 可关掉。
    """
    pf = [max(_frac(v), F(1, 10 ** 6)) for v in p]
    ssum = sum(pf)
    pf = [v / ssum for v in pf]
    cs, rs = set(cold), set(rare)
    w_hit = list(pf)
    w_cold = [pf[i] if (i + 1) in cs else F(0) for i in range(N_ID)]
    w_rare = [pf[i] if (i + 1) in rs else F(0) for i in range(N_ID)]
    w_ret = [pf[i] * F(int(mult[i + 1])) / 4 for i in range(N_ID)]

    lo = max(F(0), min(_frac(share_min), F(K_PICK, N_ID)))
    hi = min(F(1), max(_frac(share_max), lo))
    span = hi - lo
    budget = F(K_PICK) - N_ID * lo                    # u = s − lo, Σu = budget
    order = [("rare", rare_min), ("cold", cold_min), ("ret", ret_min),
             ("share_min", share_min if share_min > 0 else None),
             ("share_max", share_max if share_max < 1.0 else None)]
    active: Dict[str, object] = {k: v for k, v in order}
    dropped: List[str] = []

    while True:
        _lo = lo if active.get("share_min") is not None else F(0)
        _hi = hi if active.get("share_max") is not None else F(1)
        _span = _hi - _lo
        _bud = F(K_PICK) - N_ID * _lo
        if _bud < 0 or _bud > N_ID * _span:
            raise LPInfeasible("露面上下限本身与 Σs=4 冲突")
        A: List[List[F]] = []
        b: List[F] = []
        A.append([F(1)] * N_ID); b.append(_bud)       # Σu ≤ budget
        A.append([F(-1)] * N_ID); b.append(-_bud)     # Σu ≥ budget
        for i in range(N_ID):                          # u_i ≤ span
            row = [F(0)] * N_ID; row[i] = F(1)
            A.append(row); b.append(_span)
        for key, w in (("cold", w_cold), ("rare", w_rare), ("ret", w_ret)):
            lim = active.get(key)
            if lim is not None:
                # Σ w_i s_i ≥ lim  ⇔  −Σ w_i u_i ≤ −(lim − lo·Σw)
                A.append([-v for v in w])
                b.append(-(_frac(lim) - _lo * sum(w)))
        try:
            u = _simplex_exact(list(w_hit), A, b)
            # ── 字典序分级：钉死已达成的目标值，再最大化下一级 ──────────────────
            stages = [("hit", w_hit)] + [(k, {"rare": w_rare, "cold": w_cold,
                                              "ret": w_ret}[k])
                                         for k in tiebreak
                                         if k in ("rare", "cold", "ret")]
            AA, bb = [list(r) for r in A], list(b)
            for si, (_nm, w_prev) in enumerate(stages[:-1]):
                val = sum(a * v for a, v in zip(w_prev, u))       # 本级最优值（精确）
                AA.append([-v for v in w_prev]); bb.append(-val)  # 钉死 ≥ 最优值
                u = _simplex_exact(list(stages[si + 1][1]), AA, bb)
            s = [_lo + v for v in u]
            tot = sum(s)
            if tot != K_PICK:                          # 精确断言：必然相等
                s = [v * K_PICK / tot for v in s]
            for key, w in (("cold", w_cold), ("rare", w_rare), ("ret", w_ret)):
                lim = active.get(key)
                if lim is not None and sum(a * v for a, v in zip(w, s)) < _frac(lim) - F(1, 10 ** 9):
                    raise LPInfeasible("解未通过约束复核")
            break
        except LPInfeasible:
            if not relax:
                raise
            nxt = next((k for k, _v in order if active.get(k) is not None), None)
            if nxt is None:
                raise
            active[nxt] = None
            dropped.append(nxt)

    sf = [float(v) for v in s]
    diag = {
        "hit": float(sum(a * b_ for a, b_ in zip(w_hit, s))),
        "cold": float(sum(a * b_ for a, b_ in zip(w_cold, s))),
        "rare": float(sum(a * b_ for a, b_ in zip(w_rare, s))),
        "ret": float(sum(a * b_ for a, b_ in zip(w_ret, s))),
        "relaxed": dropped,
        "shares": [round(v, 8) for v in sf],
    }
    return sf, diag


# ───────────── Carathéodory 分解：份额 s → ≤9 个四码集合的混合（兼容 v1 状态格式）─────────────
def decompose(s: Sequence[float], tol: float = 1e-12) -> Dict[Tuple[int, ...], float]:
    """把 s（Σs=4, 0≤s≤1）写成四码集合的凸组合（Carathéodory）。确定性、至多 9 项。

    每步取残量最大的 4 个号组成 S，权重
        w = min( r_(4) ,  R − r_(5) )
    其中 R=Σr/4 是剩余总权重、r_(4) 是被选中者里最小的、r_(5) 是未选中者里最大的。
    第一项保证被选号不被减成负数；第二项保证剩下的残量仍满足 r_i ≤ R−w
    （即残差仍落在缩放后的超单纯形里）—— 少了它会在 r_(5) 逼近 R 时卡死。
    每步至少令 r_(4)=0 或 r_(5)=R−w 之一取等 ⇒ 最多 9 步终止。"""
    r = [float(v) for v in s]
    mix: Dict[Tuple[int, ...], float] = {}
    for _ in range(N_ID + 2):
        R = sum(r) / K_PICK                            # 剩余总权重
        if R <= tol:
            break
        idx = sorted(range(N_ID), key=lambda i: (-r[i], i))[:K_PICK]
        chosen = set(idx)
        r4 = min(r[i] for i in idx)
        rest = [r[i] for i in range(N_ID) if i not in chosen]
        r5 = max(rest) if rest else 0.0
        w = min(r4, R - r5)
        if w <= tol:
            break
        S = tuple(sorted(i + 1 for i in idx))
        mix[S] = mix.get(S, 0.0) + w
        for i in idx:
            r[i] = max(0.0, r[i] - w)
    z = sum(mix.values()) or 1.0
    return {k: v / z for k, v in mix.items()}


def plan(p: Sequence[float], mult: Dict[int, int],
         cold: Sequence[int] = (3, 4, 5, 6, 9), rare: Sequence[int] = (3, 9),
         **kw) -> Tuple[Dict[Tuple[int, ...], float], Dict[str, object]]:
    """v1 API 兼容层：返回 ({四码集合: 频率}, 诊断)。内部走 9 维精确 LP。"""
    s, diag = plan_shares(p, mult, cold, rare, **kw)
    mix = decompose(s)
    diag = dict(diag); diag["n_sets"] = len(mix)
    return mix, diag


# ───────────────────────── 号位级最大赤字调度器 ─────────────────────────
class ShareScheduler:
    """每局给 9 个号各加目标份额 s_i，取赤字最大的 4 个出场并各扣 1。
    · 状态只有 9 个数（v1 是最多 126 个集合条目）；零随机源、可回放、可对拍。
    · Σdebt 恒为 0；任一号的累计出场次数与 N·s_i 的偏差有界（Bresenham）。"""

    def __init__(self, shares: Sequence[float], debt: Optional[Dict[int, float]] = None):
        v = [max(0.0, float(x)) for x in shares]
        t = sum(v) or 1.0
        self.s = [x * K_PICK / t for x in v]
        self.debt = {c: float((debt or {}).get(c, 0.0)) for c in range(1, N_ID + 1)}

    def next(self) -> Tuple[int, ...]:
        for c in range(1, N_ID + 1):
            self.debt[c] += self.s[c - 1]
        pick = sorted(range(1, N_ID + 1), key=lambda c: (-self.debt[c], c))[:K_PICK]
        for c in pick:
            self.debt[c] -= 1.0
        return tuple(sorted(pick))

    def dump(self) -> Dict[str, float]:
        return {str(c): round(v, 6) for c, v in self.debt.items()}

    @staticmethod
    def load(raw: Optional[Dict[str, float]]) -> Dict[int, float]:
        out: Dict[int, float] = {}
        for k, v in (raw or {}).items():
            try:
                out[int(k)] = float(v)
            except (TypeError, ValueError):
                continue
        return out


# v1 集合级调度器（保留，便于与旧状态互操作 / 对拍）
class Scheduler:
    def __init__(self, mix: Dict[Tuple[int, ...], float],
                 debt: Optional[Dict[Tuple[int, ...], float]] = None):
        if not mix:
            mix = {ALL_SETS[0]: 1.0}
        self.sets = sorted(mix, key=lambda s: (-mix[s], s))
        tot = sum(mix.values()) or 1.0
        self.w = {s: mix[s] / tot for s in self.sets}
        self.debt = {s: float((debt or {}).get(s, 0.0)) for s in self.sets}

    def next(self) -> Tuple[int, ...]:
        for s in self.sets:
            self.debt[s] += self.w[s]
        pick = max(self.sets, key=lambda s: (self.debt[s], -ALL_SETS.index(s)))
        self.debt[pick] -= 1.0
        return pick

    def dump(self) -> Dict[str, float]:
        return {",".join(map(str, s)): round(v, 6) for s, v in self.debt.items()}

    @staticmethod
    def load(raw: Optional[Dict[str, float]]) -> Dict[Tuple[int, ...], float]:
        out: Dict[Tuple[int, ...], float] = {}
        for k, v in (raw or {}).items():
            try:
                t = tuple(int(x) for x in str(k).split(","))
            except (TypeError, ValueError):
                continue
            if len(t) == 4:
                out[t] = float(v)
        return out
