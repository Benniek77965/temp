import os,sys,json
sys.path.insert(0,'.')
import replay_harness as rh
BIG=10**7
rounds=rh.load_rounds('2678075')
t0=rounds[0][2]; gs=t0+96*3600*1000; ge=gs+int(30*3600*1000)
cut=[r for r in rounds if not (gs<=r[2]<ge)]
resume=min(r[0] for r in cut if r[2]>=ge)
out={}
for name,ov in (('tw24',{'train_window_hours':24.0,'max_train':BIG}),
                ('cnt1728',{'train_window_hours':0.0,'max_train':1728})):
    cfg=dict(rh.PRED_CFG); cfg.update(ov)
    recs,_=rh.replay('2678075',cut,cfg)
    out[name]={r['target']:(tuple(sorted(r['four'])), r['train_n'], r['hit']) for r in recs if r['actual'] is not None}
A,B=out['tw24'],out['cnt1728']
keys=sorted(set(A)&set(B))
post=[k for k in keys if k>=resume]
dif=[k for k in keys if A[k][0]!=B[k][0]]
difpost=[k for k in post if A[k][0]!=B[k][0]]
dtn=[k for k in post if A[k][1]!=B[k][1]]
print(f'共同局 {len(keys)}  恢复后 {len(post)}')
print(f'四码集合不同: 全程 {len(dif)}  恢复后 {len(difpost)}')
print(f'train_n 不同: 恢复后 {len(dtn)} 局')
print('恢复后前 5 局明细:')
for k in post[:5]:
    print(f'  {k}: tw24 four={A[k][0]} train_n={A[k][1]} hit={A[k][2]} | cnt four={B[k][0]} train_n={B[k][1]} hit={B[k][2]}')
