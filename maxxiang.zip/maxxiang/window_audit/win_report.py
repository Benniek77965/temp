#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""win_report.py —— 训练窗扫描的三层判读(口径写在 __doc__ 里,报告直接引用)。

层一 全域        :所有局。两窗在「已用跨度 < 大窗」的前缀上取到的 seq 完全相同、
                  预测逐字节相同 —— 那一段只**稀释**差异,故全域只作参照。
层二 公平域 +72h :仓库 4.9.5 用的判据口径(起点 + 当时最大有限候选窗 = 72h)。
                  ⚠ 本轮把候选扩到 168h 后该规则会要求「起点+168h」⇒ 域为空。
                  所以 +72h 域对 >=96h 的窗**不严格**:在 elapsed∈[72,W) 段,
                  W 窗仍等同于「不限时间」。
层三 严格域      :对候选 W,取 elapsed >= max(24, W) 的局 —— 基准与候选**双方**
                  都已跑满窗口之后才比。W=168h 在本数据(跨度 167.98h)上域为空,
                  这是数据跨度的硬限制,不是结论。
判据             :配对 McNemar 精确二项。10 个候选窗对 24h ⇒ 10 次比较,
                  Bonferroni 阈 alpha=0.05/10=0.005(表中 ** = 过校正,* = 仅裸 p<0.05)。
低噪声参照       :期望命中 = sum_{c in 四码} p[c],p 用**留一房**真表(与本房序列独立)。
                  用本房全样本真表会给长窗一个样本内优势 —— 窗口越长 p-hat 越贴近该
                  真值,那等于把「更长更好」这个结论部分地内生出来。
"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from audit_analyze import load, seg_rows, stats, mcnemar, ROOMS  # noqa: E402

WINS = [("tw3", 3.0), ("tw6", 6.0), ("tw12", 12.0), ("base", 24.0), ("tw48", 48.0),
        ("tw72", 72.0), ("tw96", 96.0), ("tw120", 120.0), ("tw144", 144.0),
        ("tw168", 168.0), ("tw0", None)]
BASE, NCMP = "base", 10
_C = {}


def pooled(tag, lo_h):
    k = (tag, lo_h)
    if k in _C:
        return _C[k]
    out = {}
    for rm in ROOMS:
        d = load(f"{rm}_{tag}")
        if not d:
            _C[k] = None
            return None
        for kk, v in seg_rows(d, rm, lo_h=lo_h).items():
            out[(rm, kk)] = v
    _C[k] = out
    return out


def agg(D, keys):
    n = hit = 0
    ex = 0.0
    for rm in ROOMS:
        sub = {kk: D[kk] for kk in keys if kk[0] == rm}
        if not sub:
            continue
        s = stats(sub, rm)
        n += s["n"]; hit += s["p4"] * s["n"] / 100; ex += s["exl"] * s["n"] / 100
    return n, hit / n * 100, ex / n * 100


def secs_of(tag):
    t = [load(f"{rm}_{tag}") for rm in ROOMS]
    t = [x["meta"]["secs"] for x in t if x]
    return sum(t) / len(t) if t else 0.0


def block(title, mode):
    print("\n" + "=" * 104 + "\n" + title + "\n" + "=" * 104)
    print(f'{"窗口":>8}{"域n":>8}{"基准%":>9}{"候选%":>9}{"净差pp":>9}{"b/c":>13}'
          f'{"精确p":>10}{"判":>5}{"期望(留一)Δ":>13}{"CPU s/房":>10}')
    for tag, h in WINS:
        if mode == "all":
            dom = None
        elif mode == "fair":
            dom = 72.0
        else:
            dom = max(24.0, h) if h else 24.0
        A, B = pooled(BASE, dom), pooled(tag, dom)
        name = f"{h:g}h" if h else "无限"
        if B is None or A is None:
            print(f'{name:>8}   (未跑完)')
            continue
        keys = set(A) & set(B)
        if not keys:
            print(f'{name:>8}   (该口径下域为空 —— 数据跨度 167.98h 不足以让本窗跑满)')
            continue
        na, pa, xa = agg(A, keys)
        nb, pb, xb = agg(B, keys)
        b = sum(1 for k in keys if A[k][0] and not B[k][0])
        c = sum(1 for k in keys if not A[k][0] and B[k][0])
        p = mcnemar(b, c)
        star = "**" if p < 0.05 / NCMP else ("*" if p < 0.05 else "")
        cur = " <-现行" if tag == BASE else ""
        print(f'{name:>8}{nb:>8}{pa:>9.3f}{pb:>9.3f}{pb - pa:>+9.3f}{f"{b}/{c}":>13}'
              f'{p:>10.4f}{star:>5}{xb - xa:>+13.3f}{secs_of(tag):>10.1f}{cur}')


if __name__ == "__main__":
    print(__doc__)
    block("层一 . 全域(参照)", "all")
    block("层二 . 公平域 起点+72h(仓库 4.9.5 判据口径)", "fair")
    block("层三 . 严格域 起点+max(24,W)(双方均已跑满窗口)", "strict")
