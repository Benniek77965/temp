#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""verify-holdout.py —— 用导出的新房数据对 4.9.8 定稿刻度做**样本外验证**。

放在 window_audit/ 目录下运行:
    python3 verify-holdout.py --db /path/holdout.db
    python3 verify-holdout.py --db /path/holdout.db --rooms 111,222

它做三件事(与本轮定标口径完全一致,零改写):
  ① 用生产代码路径,在每个新房上分别跑 showcase 基线 与 4.9.8 定稿刻度;
  ② 按「四项全不劣于 showcase」判定;
  ③ 以「房」为独立单元做 t 检验 —— 这才是判定「H1 是否拟合了原三房噪声」的那一步。
"""
import argparse, json, math, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import replay_harness as RH

MULT = {1: 10, 2: 50, 3: 330, 4: 250, 5: 100, 6: 100, 7: 50, 8: 50, 9: 500}
COLD, RARE = {3, 4, 5, 6, 9}, {3, 9}

BASELINE = dict(explore_style="showcase")                 # 切换前的出厂风格
CANDIDATE = dict(explore_style="frontier", fr_share_floors="",
                 fr_cold_min=0.116633, fr_rare_min=0.01683, fr_ret_min=8.358387)


def metrics(recs):
    st = [r for r in recs if r["actual"] is not None]
    n = len(st)
    if n == 0:
        return None
    hit = sum(1 for r in st if r["hit"] != "miss")
    return dict(
        n=n, hit=hit / n * 100,
        main=sum(1 for r in st if r["hit"] == "main") / n * 100,
        cold=sum(1 for r in st if r["hit"] != "miss" and r["actual"] in COLD) / n * 100,
        rare=sum(1 for r in st if r["hit"] != "miss" and r["actual"] in RARE) / n * 100,
        ret=sum(MULT[r["actual"]] / 4 if r["hit"] != "miss" else 0.0 for r in st) / n)


def run(room, over, db):
    cfg = dict(RH.PRED_CFG); cfg.update(over)
    return RH.replay(room, RH.load_rounds(room, db), cfg)[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--rooms", default="")
    ap.add_argument("--min-rounds", type=int, default=3000)
    a = ap.parse_args()

    import sqlite3
    con = sqlite3.connect(f"file:{a.db}?mode=ro", uri=True)
    if a.rooms:
        rooms = [r.strip() for r in a.rooms.split(",") if r.strip()]
    else:
        rooms = [r[0] for r in con.execute(
            "SELECT room_id FROM rounds WHERE custom_id IS NOT NULL "
            "GROUP BY room_id HAVING count(*)>=? ORDER BY count(*) DESC", (a.min_rounds,))]
    con.close()
    if not rooms:
        print("没有满足 --min-rounds 的房"); return

    print(f"样本外验证 · {len(rooms)} 个新房 · 数据源 {a.db}")
    print(f"候选刻度: {CANDIDATE}\n")
    hdr = f'{"房":<12}{"n":>7}{"命中Δ":>9}{"主中Δ":>9}{"冷门Δ":>9}{"稀有Δ":>9}{"回报Δ%":>9}{"四项":>6}'
    print(hdr); print("-" * len(hdr))
    units, tot = [], {"b": [], "c": []}
    for rm in rooms:
        b = metrics(run(rm, BASELINE, a.db))
        c = metrics(run(rm, CANDIDATE, a.db))
        if not b or not c:
            continue
        d = (c["hit"] - b["hit"], c["main"] - b["main"], c["cold"] - b["cold"],
             c["rare"] - b["rare"], (c["ret"] - b["ret"]) / b["ret"] * 100)
        ok = all(v >= 0 for v in (d[0], d[2], d[3], d[4]))
        units.append(d); tot["b"].append(b); tot["c"].append(c)
        print(f'{rm:<12}{b["n"]:>7}' + "".join(f"{v:>+9.3f}" for v in d) + f'{("✔" if ok else "✘"):>6}')

    k = len(units)
    if k < 2:
        print("\n有效房数不足,无法做单元级检验"); return
    print("\n=== 以「房」为独立单元的样本外判定 ===")
    print(f'{"指标":<8}{"均值":>10}{"房间SD":>10}{"t":>8}{"单尾p":>10}{"为正的房数":>12}')
    names = ("命中", "主中", "冷门", "稀有", "回报")
    for j, nm in enumerate(names):
        v = [u[j] for u in units]
        m = sum(v) / k
        sd = (sum((x - m) ** 2 for x in v) / (k - 1)) ** 0.5 if k > 1 else 0.0
        t = m / (sd / math.sqrt(k)) if sd > 0 else float("inf")
        p = 0.5 * math.erfc(t / math.sqrt(2)) if sd > 0 else 0.0
        print(f'{nm:<8}{m:>+10.3f}{sd:>10.3f}{t:>+8.2f}{p:>10.4f}{sum(1 for x in v if x>0):>8}/{k}')
    npos = sum(1 for u in units if all(v >= 0 for v in (u[0], u[2], u[3], u[4])))
    print(f'\n「四项全不劣」的房: {npos}/{k}')
    # 合并口径
    N = sum(b["n"] for b in tot["b"])
    agg = lambda side, key: sum(x[key] * x["n"] for x in tot[side]) / N
    print(f'合并(n={N}): 命中 {agg("b","hit"):.3f}→{agg("c","hit"):.3f} ({agg("c","hit")-agg("b","hit"):+.3f}pp) · '
          f'冷门 {agg("b","cold"):.3f}→{agg("c","cold"):.3f} ({agg("c","cold")-agg("b","cold"):+.3f}pp) · '
          f'回报 {agg("b","ret"):.4f}→{agg("c","ret"):.4f} ({(agg("c","ret")-agg("b","ret"))/agg("b","ret")*100:+.2f}%)')
    print("\n判读:命中 t>2 且四项均值全 ≥0 ⇒ 4.9.8 定稿在新房上成立,可保留;"
          "\n     若冷门均值转负或多数房 ✘ ⇒ 说明它拟合了原三房噪声,应回滚 explore_style 到 showcase。")


if __name__ == "__main__":
    main()
