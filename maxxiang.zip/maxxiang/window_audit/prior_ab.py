import sys, json, os, gzip, sqlite3
from collections import Counter
sys.path.insert(0,'.')
import replay_harness as rh
con=sqlite3.connect('file:../jiufa_data/spell_tamer_data.db?mode=ro',uri=True)
rooms=['2678075','1275859','3746870']
S={r:[x[0] for x in con.execute("select custom_id from rounds where room_id=? and custom_id is not null order by round_id",(r,))] for r in rooms}
def tab(rs):
    c=Counter()
    for r in rs: c.update(S[r])
    N=sum(c.values()); return ",".join(f"{i}:{c[i]/N:.6f}" for i in range(1,10))
os.makedirs('out_prior',exist_ok=True)
for room in rooms:
    loo=tab([r for r in rooms if r!=room])
    for name,ov in (('on_loo',{'prior_shrink':True,'prior_table':loo}),):
        p=f'out_prior/{room}_{name}.json.gz'
        if os.path.exists(p): print('skip',p); continue
        cfg=dict(rh.PRED_CFG); cfg.update(ov)
        rounds=rh.load_rounds(room)
        recs,_=rh.replay(room,rounds,cfg)
        rows=[[r['target'],(0 if r['hit']=='miss' else 1)] for r in recs if r['actual'] is not None]
        json.dump(rows,gzip.open(p,'wt'))
        print(f"{room} {name}: 四码={sum(x[1] for x in rows)/len(rows)*100:.2f}% n={len(rows)}",flush=True)
