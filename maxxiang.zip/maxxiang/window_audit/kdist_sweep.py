#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""showcase_kdist 扫描回放器（可断点续跑;AUDIT-4.9.10 复跑工具）。

方法论与 window_audit/analyze_rotate.py 完全同款：
  · 生产代码路径 backend_async/app/predictor_bridge.py → jiufa_data/spell_tamer_monitor.py
  · 逐局因果回放：先结算上局(update_after_settle)再生成下局(run_prediction)
  · 训练序列 = 24h 时窗 ∩ max_train，与 worker 同口径
  · 零随机源，重跑逐字节复现
新增：每 ~12s 原子检查点(状态含 kv/pending/recs)，单元完成写 done/ 并删状态，
     故进程被外部超时杀死也不丢进度，重复调用自动续跑。
"""
import bisect
import json
import os
import sqlite3
import sys
import time

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(HERE, "backend_async", "app"))
os.environ["STA_ENGINE_DIR"] = os.path.join(HERE, "jiufa_data")

import yaml  # noqa: E402

with open(os.path.join(HERE, "backend_async", "config.yaml"), encoding="utf-8") as f:
    _ALL = yaml.safe_load(f)
PRED_CFG = dict(_ALL["prediction"])
BEAST_IDS = dict(_ALL["custom_beast_ids"])
DB = os.path.join(HERE, "jiufa_data", "spell_tamer_data.db")
STEP = 50001
FIRST = 30
COLD5 = (3, 4, 5, 6, 9)

WORK = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out_kdist")
STATE = os.path.join(WORK, "state")
DONE = os.path.join(WORK, "done")
os.makedirs(STATE, exist_ok=True)
os.makedirs(DONE, exist_ok=True)

# ── 扫描网格：名字 -> showcase_kdist 串（exact k=1/2/3 份额%；cums=k≥1/k≥2/k=3）──
GRID = [
    ("D_45_31.5_13.5", "45,31.5,13.5"),   # 4.9.7 默认(扫描基准) cums .90/.45/.135
    ("O_45_30_15",     "45,30,15"),       # 旧值    cums .90/.45/.15
    ("X0_0_0_0",       "0,0,0"),          # 下界：几乎不带冷门
    ("H3_30_38_27",    "30,38,27"),       # 高强度  .95/.65/.27
    ("L2_55_20_5",     "55,20,5"),        # 低强度  .80/.25/.05
    ("S1_55_25_10",    "55,25,10"),       # 同k≥1，少2/3档 .90/.35/.10
    ("S2_35_40_15",    "35,40,15"),       # 4.9.10 新默认  .90/.55/.15
    ("H2_40_35_20",    "40,35,20"),       # 偏高    .95/.55/.20
    ("L1_50_27_8",     "50,27,8"),        # 偏低    .85/.35/.08
    ("P1_25_40_30",    "25,40,30"),      # .95/.70/.30
    ("P2_0_0_95",      "0,0,95"),        # 满冷角点 .95/.95/.95(受 cg_run3 帽约束)
]
ROOMS = ["1275859", "2678075", "3746870"]


def load_rounds(room):
    con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    rows = con.execute(
        "SELECT round_id, custom_id, start_ms, draw_ms FROM rounds "
        "WHERE room_id=? AND custom_id IS NOT NULL ORDER BY round_id",
        (room,)).fetchall()
    con.close()
    return rows


def bridge_for(kdist):
    import importlib
    for m in ("spell_tamer_monitor", "predictor_bridge"):
        sys.modules.pop(m, None)
    import predictor_bridge as pb  # noqa: E402
    cfg = {**PRED_CFG, "explore_style": "showcase", "showcase_kdist": kdist}
    return pb.PredictorBridge(cfg, BEAST_IDS), cfg


def atomic_write(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(obj, f)
    os.replace(tmp, path)


def run_cell(name, kdist, room, rounds, deadline):
    """返回 True=本单元完成。断点自 state/ 续。"""
    sp = os.path.join(STATE, f"{name}__{room}.json")
    dp = os.path.join(DONE, f"{name}__{room}.json")
    if os.path.exists(dp):
        return True
    if os.path.exists(sp):
        st = json.load(open(sp))
        idx0, kv, recs = st["idx"], st["kv"], st["recs"]
        pend = {int(k): v for k, v in st["pend"].items()}  # rid -> recs 下标
    else:
        idx0, kv, recs, pend = 0, {}, [], {}

    br, cfg = bridge_for(kdist)
    tw = int(float(cfg.get("train_window_hours", 24.0) or 0) * 3600 * 1000)
    mx = int(cfg.get("max_train", 5000))
    starts = [r[2] for r in rounds]
    cids = [r[1] for r in rounds]
    last_ck = time.time()

    for idx in range(idx0, len(rounds)):
        rid, cid, sms, dms = rounds[idx]
        j = pend.pop(rid, None)
        if j is not None:
            r = recs[j]
            r[1] = cid  # actual
            four = r[0]
            kv.update(br.update_after_settle(
                room, {"models": r[3], "ens": r[4]}, cid, kv))
            r[3] = r[4] = None  # 结算后释放，压缩检查点体积
        if idx >= FIRST:
            now = (dms or sms + 46500) + 1500
            lo = bisect.bisect_left(starts, now - tw, 0, idx + 1) if tw > 0 else 0
            seq = cids[lo:idx + 1][-mx:]
            res, dirty = br.run_prediction(room, seq, kv)
            kv.update(dirty)
            four = list(res["main"]) + list(res["guard"])
            why = (res.get("explore") or {}).get("why") or ""
            flag = (1 if "硬帽" in why else 0) | (2 if "保底" in why else 0)
            ncold = sum(1 for c in four if c in COLD5)
            recs.append([four, None, ncold, res["models"], res["ens"], flag])
            pend[rid + STEP] = len(recs) - 1
        t = time.time()
        if t - last_ck >= 12:
            atomic_write(sp, {"idx": idx + 1, "kv": kv, "recs": recs,
                              "pend": {str(k): v for k, v in pend.items()}})
            last_ck = t
            if t >= deadline:
                return False
    # 完成：落 done（丢弃未结算行的 models/ens）
    slim = [[r[0], r[1], r[2], r[5]] for r in recs]
    atomic_write(dp, {"kdist": kdist, "room": room, "recs": slim})
    if os.path.exists(sp):
        os.remove(sp)
    return True


def main():
    budget = float(sys.argv[1]) if len(sys.argv) > 1 else 100.0
    only = sys.argv[2].split(",") if len(sys.argv) > 2 else None
    deadline = time.time() + budget
    data = {r: load_rounds(r) for r in ROOMS}
    for name, kdist in GRID:
        if only and name not in only:
            continue
        for room in ROOMS:
            ok = run_cell(name, kdist, room, data[room], deadline)
            print(f"[{name} @ {room}] {'done' if ok else 'checkpointed'}", flush=True)
            if not ok:
                return
    print("ALL DONE", flush=True)


if __name__ == "__main__":
    main()
