"""
⚠️ 4.6.0 提示 —— 本工具与**生产补算**(backend_async/app/pred_replay.py)不是同一口径:

  · 本工具 first_pred_idx=30(从数据开头热身 30 局就开始预测,目的是把整段历史
    都跑一遍做窗口审计);
  · 生产补算默认 replay_warmup=400,且**热身不足的目标局一行都不写**。

真机实测:热身 30 局时与真机落库的四码全同率约 88%、逐局判定还原 81~84%;
热身 ≥400 局才收敛到判定 98~99%、命中率偏差 ≤1pp。
所以拿本工具的数字去"复核补算准不准"会得到一个偏低的结论并误判成故障。
要复核生产补算,请用 backend_async/tests/test_pred_replay.py 里的
test_replay_reproduces_live_hit_rate_on_real_data(同真机库、同热身)。
两者的因果时序与调用链本身仍然一致 —— 差的只是热身长度与写入策略。
"""
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
真机回放器(可移植版) — 用生产代码路径在真实出怪数据上逐局回放灵机推演。
================================================================================
调用链与生产逐字节一致:backend_async/app/predictor_bridge.py → jiufa_data/
spell_tamer_monitor.py;时序复刻 worker._settle_and_predict / 旧引擎
_after_round_inner:每局落地 ①有在手预测则 update_after_settle(Hedge 权重)
②seq=近 N 小时(≤max_train,升序) ③run_prediction 记为下一局预测,kv 逐局传递。

用法:
  python3 replay_harness.py 2678075                 # 生产窗口(config.yaml 值)
  python3 replay_harness.py 2678075 --set anti_stubborn=0 --set cadence_governor=0
      # 反固执改造 / 冷位节拍器上线后,自带库里的历史落库行仍是旧口径 —— 按历史
      # 口径对账须把**两个总开关一起关**,逐局全同应回到 ~88%(热身 30 局)。
      # 不加 --set 时按现行口径回放,对账行照常打印并就地标注口径差异
      # (那不是回放失真,是口径不同)。
  python3 replay_harness.py 2678075 --hours 72      # 覆写训练窗为 72h
  python3 replay_harness.py 2678075 --db /path/x.db # 指定 SQLite 数据源
输出: window_audit/out/replay_{room}.json(覆写窗口时带 _{H}h 后缀)
注意: --hours 覆写时会同步放大 max_train 至窗口局数上限(仅实验口径;生产
      max_train=5000 会把 >69.4h 的窗口静默截短 —— 裁决时必须解除该耦合)。
"""
import sqlite3, json, sys, os, bisect, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
STEP = 50001
COLD = (3, 4, 5, 6, 9)

import yaml
with open(os.path.join(ROOT, "backend_async", "config.yaml"), encoding="utf-8") as f:
    CFG_ALL = yaml.safe_load(f)
PRED_CFG = dict(CFG_ALL["prediction"])
BEAST_IDS = dict(CFG_ALL["custom_beast_ids"])

os.environ.setdefault("STA_ENGINE_DIR", os.path.join(ROOT, "jiufa_data"))
import importlib.util
_spec = importlib.util.spec_from_file_location(
    "predictor_bridge", os.path.join(ROOT, "backend_async", "app", "predictor_bridge.py"))
pb = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(pb)

DEFAULT_DB = os.path.join(ROOT, "jiufa_data", "spell_tamer_data.db")


def load_rounds(room, db=DEFAULT_DB):
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    rows = con.execute(
        "SELECT round_id, custom_id, start_ms, draw_ms FROM rounds "
        "WHERE room_id=? AND custom_id IS NOT NULL ORDER BY round_id", (room,)).fetchall()
    con.close()
    return rows


def load_db_preds(room, db=DEFAULT_DB):
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    out = {}
    try:
        for rid, m, g in con.execute(
                "SELECT round_id, main_ids, guard_ids FROM predictions WHERE room_id=?", (room,)):
            out[rid] = (tuple(json.loads(m)), tuple(json.loads(g)))
    except sqlite3.OperationalError:
        pass                                   # 导出库可无 predictions 表
    con.close()
    return out


def replay(room, rounds, cfg=None, first_pred_idx=30):
    """按生产时序回放。cfg 缺省用 config.yaml prediction 段。返回逐局预测记录。"""
    cfg = dict(cfg or PRED_CFG)
    bridge = pb.PredictorBridge(cfg, BEAST_IDS)
    kv, pending, recs = {}, {}, []
    tw_ms = int(float(cfg.get("train_window_hours", 24.0) or 0) * 3600 * 1000)
    max_train = int(cfg.get("max_train", 5000))
    starts = [r[2] for r in rounds]
    cids = [r[1] for r in rounds]
    for idx, (rid, cid, sms, dms) in enumerate(rounds):
        p = pending.pop(rid, None)
        if p is not None:
            p["actual"] = cid
            p["hit"] = ("main" if cid in p["main"]
                        else ("guard" if cid in p["guard"] else "miss"))
            kv.update(bridge.update_after_settle(
                room, {"models": p["models"], "ens": p["ens"]}, cid, kv))
        if idx < first_pred_idx:
            continue
        now = (dms or sms + 46500) + 1500
        lo = bisect.bisect_left(starts, now - tw_ms, 0, idx + 1) if tw_ms > 0 else 0
        seq = cids[lo:idx + 1][-max_train:]
        res, dirty = bridge.run_prediction(room, seq, kv)
        kv.update(dirty)
        st = json.loads(kv["explore_state"]) if "explore_state" in kv else {}
        rec = {"target": rid + STEP, "gen_after_idx": idx,
               "main": tuple(res["main"]), "guard": tuple(res["guard"]),
               "four": tuple(res["main"]) + tuple(res["guard"]),
               "models": res["models"], "ens": list(res["ens"]),
               "weights": dict(res["weights"]), "explore": res.get("explore"),
               "abstain": res.get("abstain"), "train_n": res["train_n"],
               "miss4": dict(st.get("miss4") or {}), "actual": None, "hit": None}
        rec["coldset"] = tuple(c for c in rec["four"] if c in COLD)
        rec["k"] = len(rec["coldset"])
        why = (res.get("explore") or {}).get("why", "") or ""
        rec["why"], rec["promoted"], rec["baodi"] = why, "升座主位" in why, "保底" in why
        pending[rid + STEP] = rec
        recs.append(rec)
    return recs, kv


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("room")
    ap.add_argument("--hours", type=float, default=None,
                    help="覆写训练窗小时数(0=不限);缺省用 config.yaml 值")
    ap.add_argument("--set", action="append", default=[], metavar="K=V",
                    help="覆写 prediction 键(可重复;值经 yaml 解析)。"
                         "如 --set anti_stubborn=0 以历史口径对账改造前的落库行")
    ap.add_argument("--db", default=DEFAULT_DB)
    ap.add_argument("--out", default=os.path.join(HERE, "out"))
    a = ap.parse_args()
    cfg = dict(PRED_CFG)
    tag = ""
    if a.hours is not None:
        cfg["train_window_hours"] = a.hours
        need = int(a.hours * 3600 * 1000 / STEP) + 8 if a.hours > 0 else 10 ** 7
        cfg["max_train"] = max(int(cfg.get("max_train", 5000)), need)
        tag = f"_{a.hours:g}h"
    for kv in a.set:
        k, _, v = kv.partition("=")
        if not k or not _:
            sys.exit(f"--set 需要 K=V 形式,收到: {kv!r}")
        cfg[k.strip()] = yaml.safe_load(v)
        tag += f"_{k.strip()}"
    rounds = load_rounds(a.room, a.db)
    if not rounds:
        sys.exit(f"[{a.room}] 数据源无该房出怪行: {a.db}")
    recs, _ = replay(a.room, rounds, cfg)
    settled = [r for r in recs if r["actual"] is not None]
    hit4 = sum(1 for r in settled if r["hit"] != "miss")
    line = (f"[{a.room}] 窗口={cfg['train_window_hours']:g}h 回放预测={len(recs)} "
            f"已结算={len(settled)} 四码命中率={hit4/len(settled)*100:.2f}%")
    if a.hours is None:                        # 生产窗口才有落库对账意义
        dbp = load_db_preds(a.room, a.db)
        same = sum(1 for r in recs if dbp.get(r["target"]) == (r["main"], r["guard"]))
        cmp_n = sum(1 for r in recs if r["target"] in dbp)
        if cmp_n:
            line += f"  与真机落库逐局全同={same}/{cmp_n}"
            # 反固执改造 / 冷位节拍器上线后,自带库历史行仍是旧口径:现行口径回放
            # 与其逐局比对必然大面积不同 —— 这不是回放失真,是口径差异。就地把话说清。
            _hist_off = [k for k in ("anti_stubborn", "cadence_governor",
                                      "repeat_guard") if cfg.get(k)]
            if _hist_off:
                line += ("(现行口径 vs 历史口径行;历史对账加 "
                         + " ".join(f"--set {k}=0" for k in _hist_off) + ")")
    print(line)
    os.makedirs(a.out, exist_ok=True)
    path = os.path.join(a.out, f"replay_{a.room}{tag}.json")
    json.dump([{k: v for k, v in r.items() if k != "models"} for r in recs],
              open(path, "w"), ensure_ascii=False)
    print("  明细 →", os.path.relpath(path, ROOT))


if __name__ == "__main__":
    main()
