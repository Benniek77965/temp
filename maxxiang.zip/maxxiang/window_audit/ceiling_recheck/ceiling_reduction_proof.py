#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""天花板的数学化简与真实前沿计算。

核心命题（本脚本要证）：
  四项指标(总命中/冷门命中/稀有命中/回报)对 126 维集合频率 x 的依赖，
  **完全经由 9 维"号位份额"向量 s_i = Σ_{S∋i} x_S**。
  且 {s : Σs=4, 0≤s≤1}（超单纯形 Δ(9,4)）与 x 的可达集一一对应。
  ⇒ 126 变量 LP ≡ 9 变量 LP，可解析求解，无需单纯形。
"""
import os as _os, sys as _sys
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_ROOT = _os.path.dirname(_os.path.dirname(_HERE))
_ENGINE = _os.path.join(_ROOT, "jiufa_data")
_DB = _os.environ.get("STA_DB") or _os.path.join(_ENGINE, "spell_tamer_data.db")
if _ENGINE not in _sys.path: _sys.path.insert(0, _ENGINE)

import itertools, math, sys
import numpy as np
from scipy.optimize import linprog
pass  # 见文件头 _ENGINE
import frontier_planner as FP

P = np.array([0.18375,0.15695,0.04929,0.06525,0.09331,0.09673,0.15720,0.16192,0.03561])
P = P/P.sum()
MULT = {1:10,2:50,3:330,4:250,5:100,6:100,7:50,8:50,9:500}
MV = np.array([MULT[i] for i in range(1,10)])
COLD = [3,4,5,6,9]; RARE=[3,9]
SETS = list(itertools.combinations(range(1,10),4))
A_share = np.array([[1.0 if i in S else 0.0 for S in SETS] for i in range(1,10)])  # 9x126

print("="*88)
print("命题①  126 维集合频率 x 的可达指标集 == 9 维份额 s 的可达指标集")
print("="*88)
rng=np.random.default_rng(7)
worst=0
for _ in range(200):
    x=rng.dirichlet(np.ones(126)*rng.uniform(0.05,3))
    s=A_share@x
    cov,cld,rar,ev = FP.set_metrics(P, MULT, COLD, RARE)
    m_x=np.array([np.dot(cov,x), np.dot(cld,x), np.dot(rar,x), np.dot(ev,x)])
    m_s=np.array([P@s, P[[c-1 for c in COLD]]@s[[c-1 for c in COLD]],
                  P[[c-1 for c in RARE]]@s[[c-1 for c in RARE]], (P*MV)@s/4])
    worst=max(worst,np.abs(m_x-m_s).max())
print(f"随机 200 个 x：|经 x 算的四项 − 经 s 算的四项| 最大误差 = {worst:.3e}")
print("  ⇒ 指标只依赖 s，与 x 在同一 s 下的分布方式无关（成立）")

# 反向：Δ(9,4) 内任意 s 是否都可由 4-子集混合实现
print("\n反向可达性：随机取 Σs=4, 0≤s≤1 的 s，检验是否存在 x≥0,Σx=1,A_share·x=s")
bad=0
for _ in range(300):
    v=rng.random(9); v=v/v.sum()*4
    for _ in range(200):
        v=np.clip(v,0,1); d=4-v.sum()
        if abs(d)<1e-12: break
        free=(v<1-1e-12) if d>0 else (v>1e-12)
        v[free]+=d/free.sum()
    r=linprog(np.zeros(126), A_eq=np.vstack([A_share,np.ones(126)]),
              b_eq=np.append(v,1.0), bounds=(0,None), method="highs")
    if not r.success: bad+=1
print(f"  300 个随机 s 中不可达 = {bad}   ⇒ 可达集恰为超单纯形 Δ(9,4)（Σs=4, 0≤s≤1）")

print()
print("="*88)
print("命题②  于是天花板 = 一个 9 变量 LP，且各单项极值可手算")
print("="*88)
def topk_max(w, k=4, lo=0.0, hi=1.0):
    """max w·s s.t. Σs=4, lo≤s≤hi —— 贪心：先给全体 lo，余额按 w 降序灌到 hi"""
    s=np.full(9,lo); rem=4-9*lo
    for i in np.argsort(-w):
        add=min(hi-lo, rem); s[i]+=add; rem-=add
        if rem<=1e-12: break
    return w@s, s
for nm,w in (("总命中", P), ("冷门命中", P*np.isin(np.arange(1,10),COLD)),
             ("稀有命中", P*np.isin(np.arange(1,10),RARE)), ("每注回报", P*MV/4)):
    v,s=topk_max(w)
    unit = "%" if nm!="每注回报" else ""
    val = v*100 if nm!="每注回报" else v
    print(f"  单项无约束上限 {nm:<6}: {val:8.4f}{unit}   最优四码 = {sorted(np.argsort(-s)[:4]+1)}")

print()
print("="*88)
print("命题③  用 9 变量 LP 复算 frontier_planner 的解 —— 两者必须同值")
print("="*88)
def lp9(p, cold_min=None, rare_min=None, ret_min=None, share_min=0.0, share_max=1.0,
        main_share_min=None, obj=None):
    """max obj·s  s.t. Σs=4, share_min≤s≤share_max, 冷门/稀有/回报 达标"""
    c = -(obj if obj is not None else p)
    A_ub=[]; b_ub=[]
    if cold_min: A_ub.append(-(p*np.isin(np.arange(1,10),COLD))); b_ub.append(-cold_min)
    if rare_min: A_ub.append(-(p*np.isin(np.arange(1,10),RARE))); b_ub.append(-rare_min)
    if ret_min:  A_ub.append(-(p*MV/4)); b_ub.append(-ret_min)
    r=linprog(c, A_ub=(np.array(A_ub) if A_ub else None), b_ub=(b_ub or None),
              A_eq=np.ones((1,9)), b_eq=[4.0],
              bounds=[(share_min,share_max)]*9, method="highs")
    return r

CFG=dict(cold_min=0.1232, rare_min=0.0180, ret_min=8.624, share_min=0.08, share_max=0.8)
mix,diag = FP.plan(list(P), MULT, COLD, RARE, **CFG)
s_fp = A_share @ np.array([mix.get(S,0.0) for S in SETS])
r = lp9(P, **CFG)
print("现行定稿刻度 cold≥0.1232 rare≥0.0180 ret≥8.624 share∈[0.08,0.80]")
print(f"  frontier_planner(126维单纯形) 总命中 = {diag['hit']*100:.5f}%")
print(f"  9 维 LP(scipy HiGHS)         总命中 = {-r.fun*100:.5f}%")
print(f"  差 = {abs(diag['hit']+r.fun)*100:.2e} pp   -> "
      f"{'一致，单纯形求解正确' if abs(diag['hit']+r.fun)<1e-7 else '★不一致'}")
print(f"  份额向量 planner = [{' '.join(f'{v:.4f}' for v in s_fp)}]")
print(f"  份额向量 LP9     = [{' '.join(f'{v:.4f}' for v in r.x)}]")
print(f"  实际指标: 冷门 {diag['cold']*100:.4f}%  稀有 {diag['rare']*100:.4f}%  回报 {diag['ret']:.4f}")

print()
print("="*88)
print("命题④  现行生产 showcase 的份额向量离前沿有多远")
print("="*88)
# 三房 showcase 实测份额（frontier_audit 输出，下面会用真机回放复核）
sc = {"2678075": np.array([97.0,43.1,21.8,28.0,43.2,41.2,58.3,51.6,15.7])/100}
for rm,s in sc.items():
    s=s/ s.sum()*4
    hit=P@s; cold=P[[c-1 for c in COLD]]@s[[c-1 for c in COLD]]
    rare=P[[c-1 for c in RARE]]@s[[c-1 for c in RARE]]; ret=(P*MV)@s/4
    print(f"房{rm} showcase 份额 -> 理论 总命中 {hit*100:.3f}% 冷门 {cold*100:.3f}% "
          f"稀有 {rare*100:.3f}% 回报 {ret:.4f}")
    # 同等 cold/rare/ret 下的总命中上限
    r2=lp9(P, cold_min=cold, rare_min=rare, ret_min=ret, share_min=0.0, share_max=1.0)
    print(f"    在**同等**冷门/稀有/回报下，总命中的数学上限 = {-r2.fun*100:.3f}%"
          f"   -> 差距 {(-r2.fun-hit)*100:+.3f} pp")
    r3=lp9(P, cold_min=None, rare_min=None, ret_min=ret, share_min=0.0, share_max=1.0,
           obj=P*np.isin(np.arange(1,10),COLD))
    print(f"    在**同等**回报下，冷门命中的数学上限   = {-r3.fun*100:.3f}%"
          f"   -> 差距 {(-r3.fun-cold)*100:+.3f} pp")
