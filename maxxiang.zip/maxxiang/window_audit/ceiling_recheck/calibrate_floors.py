#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""候选刻度定标：在生产 share∈[0.08,0.80] 边界内，扫 (冷门下限, 稀有下限) 的可行域与代价。"""
import os as _os, sys as _sys
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_ROOT = _os.path.dirname(_os.path.dirname(_HERE))
_ENGINE = _os.path.join(_ROOT, "jiufa_data")
_DB = _os.environ.get("STA_DB") or _os.path.join(_ENGINE, "spell_tamer_data.db")
if _ENGINE not in _sys.path: _sys.path.insert(0, _ENGINE)

import numpy as np
from scipy.optimize import linprog

P=np.array([0.18375,0.15695,0.04929,0.06525,0.09331,0.09673,0.15720,0.16192,0.03561]); P/=P.sum()
MV=np.array([10,50,330,250,100,100,50,50,500.0])
mC=np.isin(np.arange(1,10),[3,4,5,6,9]).astype(float); mR=np.isin(np.arange(1,10),[3,9]).astype(float)
W={"hit":P,"cold":P*mC,"rare":P*mR,"ret":P*MV/4}

def lp(cold=None,rare=None,ret=None,smin=0.08,smax=0.8):
    A=[];b=[]
    for k,v in (("cold",cold),("rare",rare),("ret",ret)):
        if v: A.append(-W[k]); b.append(-v)
    r=linprog(-W["hit"],A_ub=(np.array(A) if A else None),b_ub=(b or None),
              A_eq=np.ones((1,9)),b_eq=[4.0],bounds=[(smin,smax)]*9,method="highs")
    if not r.success: return None
    s=r.x; return dict(s=s,**{k:W[k]@s for k in W})

print("="*118)
print("A. 可行域网格：share∈[0.08,0.80]、无 ret 下限，格点=该 (冷门,稀有) 下的最大总命中%")
print("="*118)
rares=[0.018,0.022,0.026,0.030,0.034,0.038,0.042,0.046]
colds=[0.090,0.105,0.1232,0.135,0.150,0.165,0.180]
print("冷门下限\\稀有下限 "+"".join(f"{v*100:>8.1f}" for v in rares))
for c in colds:
    row=""
    for r in rares:
        d=lp(cold=c,rare=r)
        row+=f"{d['hit']*100:>8.2f}" if d else f"{'不可行':>7}"
    print(f"     {c*100:>5.2f}%      "+row)

print()
print("="*118)
print("B. 候选定标详表（全部去掉 ret 下限；对照组为现行两式）")
print("="*118)
CAND=[
 ("现行 frontier(cold .1232/rare .0180/ret 8.624)", dict(cold=0.1232,rare=0.0180,ret=8.624)),
 ("C1 去ret · cold .1050 · rare .0300",             dict(cold=0.1050,rare=0.0300)),
 ("C2 去ret · cold .1100 · rare .0350",             dict(cold=0.1100,rare=0.0350)),
 ("C3 去ret · cold .1550 · rare .0180",             dict(cold=0.1550,rare=0.0180)),
 ("C4 去ret · cold .1232 · rare .0250",             dict(cold=0.1232,rare=0.0250)),
 ("C5 去ret · cold .1232 · rare .0300",             dict(cold=0.1232,rare=0.0300)),
 ("C6 去ret · cold .1400 · rare .0260",             dict(cold=0.1400,rare=0.0260)),
]
print(f"{'方案':<46}{'总命中%':>9}{'冷门%':>8}{'稀有%':>8}{'回报':>8}   份额 s1..s9")
for nm,kw in CAND:
    d=lp(**kw)
    if d is None: print(f"{nm:<46}{'不可行':>9}"); continue
    print(f"{nm:<46}{d['hit']*100:>9.3f}{d['cold']*100:>8.3f}{d['rare']*100:>8.3f}{d['ret']:>8.3f}"
          f"   [{' '.join(f'{v:.2f}' for v in d['s'])}]")

print()
print("="*118)
print("C. 优化者诅咒的安全余量定标：约束加 margin 后，按真 p 结算的实际达标率")
print("   (p̂ 用 24h 窗；margin=约束值上浮比例)")
print("="*118)
import sqlite3, sys, itertools
from collections import Counter
pass  # 见文件头 _ENGINE
import frontier_planner as FP
SETS=list(itertools.combinations(range(1,10),4))
AS=np.array([[1.0 if i in S else 0.0 for S in SETS] for i in range(1,10)])
MULT={1:10,2:50,3:330,4:250,5:100,6:100,7:50,8:50,9:500}
DB=_DB
con=sqlite3.connect(f"file:{DB}?mode=ro",uri=True)
seqs={rm:[r[0] for r in con.execute("select custom_id from rounds where room_id=? and "
      "custom_id is not null order by round_id",(rm,))] for rm in
      ("1275859","2678075","3746870")}
con.close()
TARGET_C, TARGET_R = 0.1100, 0.0350
print(f"{'margin':<10}{'实际冷门%':>11}{'实际稀有%':>11}{'冷门达标率':>11}{'稀有达标率':>11}{'实际总命中%':>12}")
for mg in (0.00,0.02,0.04,0.06,0.08,0.12):
    hs=[];cs=[];rs=[];fc=[];fr=[]
    for rm,s in seqs.items():
        for t in range(2000,len(s),120):
            c=Counter(s[max(0,t-1727):t]); n=min(t,1727)
            ph=np.array([(c[i]+2)/(n+18) for i in range(1,10)])
            m,_=FP.plan(list(ph),MULT,[3,4,5,6,9],[3,9],
                        cold_min=TARGET_C*(1+mg), rare_min=TARGET_R*(1+mg),
                        ret_min=None, share_min=0.08, share_max=0.8)
            sv=AS@np.array([m.get(S,0.0) for S in SETS])
            hs.append(W["hit"]@sv); cs.append(W["cold"]@sv); rs.append(W["rare"]@sv)
            fc.append(W["cold"]@sv>=TARGET_C-1e-9); fr.append(W["rare"]@sv>=TARGET_R-1e-9)
    print(f"{mg*100:>5.0f}%    {np.mean(cs)*100:>11.4f}{np.mean(rs)*100:>11.4f}"
          f"{np.mean(fc)*100:>10.1f}%{np.mean(fr)*100:>10.1f}%{np.mean(hs)*100:>12.4f}")
print(f"\n目标: 冷门≥{TARGET_C*100:.2f}%  稀有≥{TARGET_R*100:.2f}%  (n={len(hs)} 个求解点)")
