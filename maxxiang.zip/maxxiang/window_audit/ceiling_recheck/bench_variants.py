#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""真机严格回放对拍台 —— 走生产代码路径（replay_harness → predictor_bridge → 引擎）。
用法: python3 bench.py <方案json文件>   或直接改 VARIANTS。
输出逐方案四项指标 + 份额 + 与基线的 McNemar/配对 t。
"""
import sys, os, math, json, argparse
from collections import Counter
HERE=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE,"window_audit"))
import replay_harness as RH

MULT={1:10,2:50,3:330,4:250,5:100,6:100,7:50,8:50,9:500}
ROOMS=("1275859","2678075","3746870")
COLD={3,4,5,6,9}; RARE={3,9}

def summarize(recs,label):
    st=[r for r in recs if r["actual"] is not None]; n=len(st)
    hits=[r["hit"]!="miss" for r in st]
    mains=[r["hit"]=="main" for r in st]
    colds=[r["hit"]!="miss" and r["actual"] in COLD for r in st]
    rares=[r["hit"]!="miss" and r["actual"] in RARE for r in st]
    rets=[MULT[r["actual"]]/4 if r["hit"]!="miss" else 0.0 for r in st]
    # 逐号命中率(该号出现且被四码覆盖 / 总局数)
    per={c:sum(1 for r in st if r["actual"]==c and r["hit"]!="miss")/n for c in range(1,10)}
    # 逐号"条件捕获率" = 该号出现时被覆盖的比例
    cap={}
    for c in range(1,10):
        occ=[r for r in st if r["actual"]==c]
        cap[c]=sum(1 for r in occ if r["hit"]!="miss")/max(1,len(occ))
    sh=Counter(); mh=Counter()
    for r in st:
        sh.update(r["four"]); mh.update(r["main"])
    fours=[tuple(sorted(r["four"])) for r in st]
    cb=Counter(fours); ent=-sum(v/n*math.log2(v/n) for v in cb.values())
    run=mx=1
    for a,b in zip(fours[:-1],fours[1:]):
        run=run+1 if a==b else 1; mx=max(mx,run)
    # 最长"某号连续不进四码"
    starve={}
    for c in range(1,10):
        cur=best=0
        for r in st:
            if c in r["four"]: cur=0
            else: cur+=1; best=max(best,cur)
        starve[c]=best
    return dict(label=label,n=n,hit=sum(hits)/n,main=sum(mains)/n,cold=sum(colds)/n,
                rare=sum(rares)/n,ret=sum(rets)/n,combos=len(cb),entropy=ent,maxrun=mx,
                share={c:sh[c]/n for c in range(1,10)},
                mshare={c:mh[c]/n for c in range(1,10)},per=per,cap=cap,starve=starve,
                hits=hits,mains=mains,colds=colds,rares=rares,rets=rets,
                fours=[tuple(r["four"]) for r in st],keys=[r["target"] for r in st])

def mcnemar(a,b):
    bb=sum(1 for x,y in zip(a,b) if x and not y)
    cc=sum(1 for x,y in zip(a,b) if y and not x)
    if bb+cc==0: return bb,cc,0.0,1.0
    chi=(abs(bb-cc)-1)**2/(bb+cc)
    return bb,cc,chi,math.erfc(math.sqrt(max(chi,0.0)/2.0))

def paired_t(x,y):
    d=[a-b for a,b in zip(x,y)]; n=len(d); mu=sum(d)/n
    var=sum((v-mu)**2 for v in d)/(n-1); se=math.sqrt(var/n) or 1e-12
    t=mu/se; return mu,t,math.erfc(abs(t)/math.sqrt(2))

def run_variant(over,rooms):
    cfg=dict(RH.PRED_CFG); cfg.update(over)
    allrecs=[]
    for rm in rooms:
        rounds=RH.load_rounds(rm, RH.DEFAULT_DB)
        recs,_=RH.replay(rm,rounds,cfg)
        allrecs+=recs
    return allrecs

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--plan",required=True)
    ap.add_argument("--rooms",default=",".join(ROOMS))
    ap.add_argument("--out",default=None)
    a=ap.parse_args()
    rooms=[r for r in a.rooms.split(",") if r.strip()]
    VAR=json.load(open(a.plan,encoding="utf-8"))
    out={}
    for label,over in VAR:
        recs=run_variant(over,rooms)
        out[label]=summarize(recs,label)
        d=out[label]
        print(f"[done] {label:<44} n={d['n']} hit={d['hit']*100:.2f}% "
              f"cold={d['cold']*100:.2f}% rare={d['rare']*100:.3f}% ret={d['ret']:.4f}",flush=True)
    print()
    print("="*140)
    print(f"{'方案':<44}{'总命中':>8}{'主中':>8}{'冷门':>8}{'稀有':>8}{'每注回报':>10}{'组合':>6}{'熵':>7}{'连推':>5}")
    print("="*140)
    for d in out.values():
        print(f"{d['label']:<44}{d['hit']*100:>7.2f}%{d['main']*100:>7.2f}%{d['cold']*100:>7.2f}%"
              f"{d['rare']*100:>7.3f}%{d['ret']:>10.4f}{d['combos']:>6}{d['entropy']:>7.2f}{d['maxrun']:>5}")
    print()
    print(f"{'方案':<44}"+"".join(f"{c:>7}" for c in range(1,10))+"   ← 各号进四码份额%")
    for d in out.values():
        print(f"{d['label']:<44}"+"".join(f"{d['share'][c]*100:>7.1f}" for c in range(1,10)))
    print()
    print(f"{'方案':<44}"+"".join(f"{c:>7}" for c in range(1,10))+"   ← 各号「出现时被捕获」率%")
    for d in out.values():
        print(f"{d['label']:<44}"+"".join(f"{d['cap'][c]*100:>7.1f}" for c in range(1,10)))
    print()
    print(f"{'方案':<44}"+"".join(f"{c:>7}" for c in range(1,10))+"   ← 各号进主位份额%")
    for d in out.values():
        print(f"{d['label']:<44}"+"".join(f"{d['mshare'][c]*100:>7.1f}" for c in range(1,10)))
    print()
    print(f"{'方案':<44}"+"".join(f"{c:>7}" for c in range(1,10))+"   ← 各号最长连续未进四码(局)")
    for d in out.values():
        print(f"{d['label']:<44}"+"".join(f"{d['starve'][c]:>7d}" for c in range(1,10)))
    base=out[VAR[0][0]]
    for label,d in out.items():
        if label==VAR[0][0] or d["keys"]!=base["keys"]: continue
        print(f"\n── 配对检验：{label}  vs  {VAR[0][0]}   n={d['n']} ──")
        for nm,ka,kb in (("总命中",base["hits"],d["hits"]),("主中",base["mains"],d["mains"]),
                         ("冷门命中",base["colds"],d["colds"]),("稀有命中",base["rares"],d["rares"])):
            bb,cc,chi,p=mcnemar(ka,kb)
            who="本方案更优" if cc>bb else ("基线更优" if bb>cc else "持平")
            star="***" if p<0.001 else ("**" if p<0.01 else ("*" if p<0.05 else "  "))
            print(f"   {nm:<5}: 基线独中{bb:5d} / 本方案独中{cc:5d}  χ²={chi:7.1f} p={p:.3e} {star} → {who}")
        mu,t,p=paired_t(d["rets"],base["rets"])
        print(f"   回报差 = {mu:+.4f}  t={t:+.2f}  p={p:.3e}")
    if a.out: json.dump({k:{kk:vv for kk,vv in v.items() if kk not in ("hits","mains","colds","rares","rets","fours","keys")}
                         for k,v in out.items()}, open(a.out,"w"), ensure_ascii=False, indent=1)

if __name__=="__main__": sys.exit(main())
