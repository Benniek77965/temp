#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第二轮核查：
 1) 名义显著项的样本外复现（前半段发现 -> 后半段验证）
 2) 概率平稳性（p 是否随时间漂移）—— 决定 train_window_hours 该多长
 3) 因果经济检验：任何"模型"能否在真实时序上打败常数真频
"""
import os as _os, sys as _sys
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_ROOT = _os.path.dirname(_os.path.dirname(_HERE))
_ENGINE = _os.path.join(_ROOT, "jiufa_data")
_DB = _os.environ.get("STA_DB") or _os.path.join(_ENGINE, "spell_tamer_data.db")
if _ENGINE not in _sys.path: _sys.path.insert(0, _ENGINE)

import sqlite3, math, json
from collections import Counter, defaultdict
import numpy as np
from scipy import stats

DB = _DB
con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
rooms = [r[0] for r in con.execute("select distinct room_id from rounds order by room_id")]
data = {rm: con.execute("select round_id,custom_id,start_ms,draw_ms from rounds "
                        "where room_id=? and custom_id is not null order by round_id",
                        (rm,)).fetchall() for rm in rooms}
seqs = {rm: [r[1] for r in data[rm]] for rm in rooms}

print("="*84); print("F. 名义显著项的样本外复现（发现集=前半 / 验证集=后半）"); print("="*84)

def lag_chi2(seq, lag):
    t=np.zeros((9,9))
    for a,b in zip(seq[:-lag],seq[lag:]): t[a-1,b-1]+=1
    t=t[np.ix_(t.sum(1)>0,t.sum(0)>0)]
    c,p,d,_=stats.chi2_contingency(t); return c,d,p

print("① 房2678075 lag=1 (全样本 p=0.0053)")
s=seqs["2678075"]; h=len(s)//2
for nm,sub in (("前半",s[:h]),("后半",s[h:])):
    c,d,p=lag_chi2(sub,1); print(f"   {nm} n={len(sub)}: chi2={c:.2f} df={d} p={p:.4f}")
# 方向一致性：前半的转移偏差方向能否预测后半
def dev(seq,lag):
    t=np.zeros((9,9))
    for a,b in zip(seq[:-lag],seq[lag:]): t[a-1,b-1]+=1
    e=np.outer(t.sum(1),t.sum(0))/t.sum()
    return (t-e)/np.sqrt(e+1e-9)
d1,d2=dev(s[:h],1),dev(s[h:],1)
r=np.corrcoef(d1.ravel(),d2.ravel())[0,1]
print(f"   前后半 Pearson 残差相关 r={r:+.4f}  (真信号应 >0 且显著；n=81)"
      f"  p={2*(1-stats.t.cdf(abs(r)*math.sqrt(79/(1-r**2)),79)):.4f}")

print("\n② 合并 lag=3 (全样本 p=0.0137)")
for nm,sl in (("前半",slice(None,None)),):
    pass
for nm in ("前半","后半"):
    t=np.zeros((9,9))
    for rm in rooms:
        ss=seqs[rm]; hh=len(ss)//2
        sub = ss[:hh] if nm=="前半" else ss[hh:]
        for a,b in zip(sub[:-3],sub[3:]): t[a-1,b-1]+=1
    c,p,d,_=stats.chi2_contingency(t)
    print(f"   {nm}: chi2={c:.2f} df={d} p={p:.4f}")
t1=np.zeros((9,9)); t2=np.zeros((9,9))
for rm in rooms:
    ss=seqs[rm]; hh=len(ss)//2
    for a,b in zip(ss[:hh-3],ss[3:hh]): t1[a-1,b-1]+=1
    for a,b in zip(ss[hh:-3],ss[hh+3:]): t2[a-1,b-1]+=1
def z(t):
    e=np.outer(t.sum(1),t.sum(0))/t.sum(); return (t-e)/np.sqrt(e+1e-9)
r=np.corrcoef(z(t1).ravel(),z(t2).ravel())[0,1]
print(f"   前后半残差相关 r={r:+.4f}  p={2*(1-stats.t.cdf(abs(r)*math.sqrt(79/max(1e-9,1-r**2)),79)):.4f}")

print()
print("="*84); print("G. 概率平稳性 —— 决定 train_window_hours 的正确长度"); print("="*84)
pool=[c for rm in rooms for c in seqs[rm]]
N=len(pool); p_glob=np.array([Counter(pool)[i]/N for i in range(1,10)])
print("全样本 p̂: "+" ".join(f"{v*100:.3f}%" for v in p_glob))

# 逐日 x 号位 独立性 = 日间漂移检验
import datetime
day_tab=defaultdict(lambda: np.zeros(9))
for rm in rooms:
    for rid,cid,sms,dms in data[rm]:
        d=datetime.datetime.fromtimestamp(((dms or sms)/1000)+8*3600, datetime.UTC).strftime("%Y-%m-%d")
        day_tab[d][cid-1]+=1
days=sorted(day_tab)
M=np.array([day_tab[d] for d in days])
c,p,dof,_=stats.chi2_contingency(M)
print(f"\n逐日({len(days)}天) x 号位 齐性: chi2={c:.2f} df={dof} p={p:.4f}"
      f"  -> {'平稳（无日间漂移）' if p>0.05 else '存在漂移'}")
for d,row in zip(days,M):
    print(f"   {d} n={int(row.sum()):5d}: "+" ".join(f"{v/row.sum()*100:5.2f}" for v in row))

# 滑窗 p̂ 的方差 vs 二项理论方差（过离散=真漂移，等于=纯抽样噪声）
print("\n滑窗 p̂ 过离散检验（窗口内 p̂ 的实际方差 / 二项理论方差；1.0=纯噪声无漂移）:")
for W in (500, 1000, 1727, 3000, 5000):
    ratios=[]
    for i in range(9):
        vs=[]
        for rm in rooms:
            s=np.array(seqs[rm])
            for st in range(0,len(s)-W+1,W):
                vs.append((s[st:st+W]==i+1).mean())
        vs=np.array(vs)
        if len(vs)<3: continue
        theo=p_glob[i]*(1-p_glob[i])/W
        ratios.append(vs.var(ddof=1)/theo)
    print(f"   W={W:5d} 局: 过离散比中位数={np.median(ratios):.3f}  "
          f"各号=[{' '.join(f'{r:.2f}' for r in ratios)}]")

print()
print("="*84); print("H. 因果经济检验：任何模型能否打败常数真频"); print("="*84)
# 逐局因果：用 t 局之前的全部数据估 p，比较不同估计器的 log-loss 与 top4 命中
def run_causal(estimator, warm=400):
    ll=[]; hit=[]
    for rm in rooms:
        s=seqs[rm]
        for t in range(warm,len(s)):
            p=estimator(s,t)
            p=np.clip(p,1e-9,None); p=p/p.sum()
            ll.append(-math.log(p[s[t]-1]))
            hit.append(1 if s[t] in set(np.argsort(-p)[:4]+1) else 0)
    return np.array(ll), np.array(hit)

def est_global(s,t):
    c=Counter(s[:t]); return np.array([(c[i]+2)/(t+18) for i in range(1,10)])
def est_w(W):
    def f(s,t):
        c=Counter(s[max(0,t-W):t]); n=min(t,W)
        return np.array([(c[i]+2)/(n+18) for i in range(1,10)])
    return f
def est_ewma(hl):
    lam=0.5**(1/hl)
    def f(s,t):
        w=np.zeros(9); k=1.0
        for c in reversed(s[max(0,t-3000):t]):
            w[c-1]+=k; k*=lam
            if k<1e-6: break
        return (w+2)/(w.sum()+18)
    return f
def est_markov1(s,t):
    prev=s[t-1]; c=Counter(b for a,b in zip(s[:t-1],s[1:t]) if a==prev)
    n=sum(c.values()); g=est_global(s,t)
    return np.array([(c[i]+6*g[i-1])/(n+6) for i in range(1,10)])

cands = [("常数真频(全历史,Laplace+2)", est_global),
         ("滑窗1727局(≈24h)", est_w(1727)),
         ("滑窗800局", est_w(800)),
         ("滑窗5000局", est_w(5000)),
         ("EWMA半衰30", est_ewma(30)),
         ("EWMA半衰500", est_ewma(500)),
         ("一阶马尔可夫(shrink6)", est_markov1),
         ("理论/全样本真频(作弊上界)", lambda s,t: p_glob)]
base=None
print(f"{'估计器':<28}{'log-loss':>12}{'vs常数Δ':>12}{'配对t':>9}{'p':>10}{'top4命中%':>11}")
res={}
for nm,f in cands:
    ll,ht=run_causal(f)
    res[nm]=(ll,ht)
    if base is None: base=ll; b_nm=nm
    d=ll-base
    t=d.mean()/(d.std(ddof=1)/math.sqrt(len(d))) if d.std()>0 else 0
    pv=2*(1-stats.norm.cdf(abs(t))) if t else 1.0
    print(f"{nm:<28}{ll.mean():>12.5f}{d.mean():>+12.5f}{t:>+9.2f}{pv:>10.2e}{ht.mean()*100:>11.3f}")
con.close()
