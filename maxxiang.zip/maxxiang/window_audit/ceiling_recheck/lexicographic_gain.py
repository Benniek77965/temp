"""测量字典序分级在真机 p̂ 轨迹上捡回多少冷门/稀有（对总命中零成本）"""
import os as _os, sys as _sys
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_ROOT = _os.path.dirname(_os.path.dirname(_HERE))
_ENGINE = _os.path.join(_ROOT, "jiufa_data")
_DB = _os.environ.get("STA_DB") or _os.path.join(_ENGINE, "spell_tamer_data.db")
if _ENGINE not in _sys.path: _sys.path.insert(0, _ENGINE)

import sys, sqlite3, itertools
from collections import Counter
pass  # 见文件头 _ENGINE
import numpy as np, frontier_planner as V1, frontier_planner_v2 as V2
SETS=list(itertools.combinations(range(1,10),4))
A=np.array([[1.0 if i in S else 0.0 for S in SETS] for i in range(1,10)])
MULT={1:10,2:50,3:330,4:250,5:100,6:100,7:50,8:50,9:500}
MV=np.array([MULT[i] for i in range(1,10)],float)
COLD=[3,4,5,6,9]; RARE=[3,9]
mC=np.isin(np.arange(1,10),COLD).astype(float); mR=np.isin(np.arange(1,10),RARE).astype(float)
P=np.array([0.18375,0.15695,0.04929,0.06525,0.09331,0.09673,0.15720,0.16192,0.03561]); P/=P.sum()
CUR=dict(cold_min=0.1232,rare_min=0.0180,ret_min=8.624,share_min=0.08,share_max=0.8)
DB=_DB
con=sqlite3.connect(f"file:{DB}?mode=ro",uri=True)
seqs={rm:[r[0] for r in con.execute("select custom_id from rounds where room_id=? and custom_id "
     "is not null order by round_id",(rm,))] for rm in ("1275859","2678075","3746870")}
con.close()
def met(s): return np.array([P@s,(P*mC)@s,(P*mR)@s,(P*MV)@s/4])
rows={"v1(126维·任意顶点)":[], "v2 无分级":[], "v2 分级(rare>cold>ret)":[], "v2 分级(cold>rare>ret)":[]}
ndeg=0; n=0
for rm,s in seqs.items():
    for t in range(2000,len(s),150):
        c=Counter(s[max(0,t-1727):t]); nn=min(t,1727)
        ph=[(c[i]+2)/(nn+18) for i in range(1,10)]
        m1,_=V1.plan(ph,MULT,COLD,RARE,**CUR); s1=A@np.array([m1.get(S,0.0) for S in SETS])
        a,_=V2.plan_shares(ph,MULT,COLD,RARE,tiebreak=(),**CUR)
        b,_=V2.plan_shares(ph,MULT,COLD,RARE,tiebreak=("rare","cold","ret"),**CUR)
        d,_=V2.plan_shares(ph,MULT,COLD,RARE,tiebreak=("cold","rare","ret"),**CUR)
        for k,v in (("v1(126维·任意顶点)",s1),("v2 无分级",np.array(a)),
                    ("v2 分级(rare>cold>ret)",np.array(b)),("v2 分级(cold>rare>ret)",np.array(d))):
            rows[k].append(met(v))
        n+=1
        if np.abs(np.array(a)-np.array(b)).max()>1e-9: ndeg+=1
print(f"真机 p̂ 轨迹 {n} 个求解点（三房 24h 滑窗，步长150局）")
print(f"其中总命中最优解**不唯一**（分级能改变结果）的点 = {ndeg} ({ndeg/n*100:.1f}%)\n")
print(f"{'方案':<28}{'总命中%':>10}{'冷门%':>9}{'稀有%':>9}{'回报':>9}")
for k,v in rows.items():
    m=np.array(v).mean(0)
    print(f"{k:<28}{m[0]*100:>10.4f}{m[1]*100:>9.4f}{m[2]*100:>9.4f}{m[3]:>9.4f}")
base=np.array(rows["v1(126维·任意顶点)"]).mean(0)
for k in ("v2 分级(rare>cold>ret)","v2 分级(cold>rare>ret)"):
    m=np.array(rows[k]).mean(0)-base
    print(f"\n{k} 相对 v1: 总命中{m[0]*100:+.4f}pp  冷门{m[1]*100:+.4f}pp  稀有{m[2]*100:+.4f}pp  回报{m[3]:+.4f}")
