#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""真实帕累托前沿测绘：冷门/稀有命中率要抬高，总命中要付多少？
另诊断 fr_ret_min / fr_share_max / fr_share_min 三条约束各自的真实作用。"""
import numpy as np, itertools
from scipy.optimize import linprog

P=np.array([0.18375,0.15695,0.04929,0.06525,0.09331,0.09673,0.15720,0.16192,0.03561]); P/=P.sum()
MULT={1:10,2:50,3:330,4:250,5:100,6:100,7:50,8:50,9:500}
MV=np.array([MULT[i] for i in range(1,10)])
COLD=[3,4,5,6,9]; RARE=[3,9]
mC=np.isin(np.arange(1,10),COLD).astype(float); mR=np.isin(np.arange(1,10),RARE).astype(float)
wHIT=P; wCOLD=P*mC; wRARE=P*mR; wRET=P*MV/4

def solve(cold_min=None,rare_min=None,ret_min=None,smin=0.0,smax=1.0,obj=wHIT):
    A=[];b=[]
    if cold_min: A.append(-wCOLD); b.append(-cold_min)
    if rare_min: A.append(-wRARE); b.append(-rare_min)
    if ret_min:  A.append(-wRET);  b.append(-ret_min)
    r=linprog(-obj, A_ub=(np.array(A) if A else None), b_ub=(b or None),
              A_eq=np.ones((1,9)), b_eq=[4.0], bounds=[(smin,smax)]*9, method="highs")
    if not r.success: return None
    s=r.x
    return dict(s=s, hit=wHIT@s, cold=wCOLD@s, rare=wRARE@s, ret=wRET@s)

def row(tag,d):
    if d is None: return f"{tag:<34}{'不可行':>10}"
    return (f"{tag:<34}{d['hit']*100:>9.3f}{d['cold']*100:>9.3f}{d['rare']*100:>9.3f}"
            f"{d['ret']:>9.3f}   [{' '.join(f'{v:.2f}' for v in d['s'])}]")

HDR=f"{'方案':<34}{'总命中%':>9}{'冷门%':>9}{'稀有%':>9}{'回报':>9}   份额 s1..s9"
print("="*130); print("一、四个单目标极点（无任何约束，Σs=4, 0≤s≤1）"); print("="*130)
print(HDR)
for nm,o in (("max 总命中",wHIT),("max 冷门命中",wCOLD),("max 稀有命中",wRARE),("max 回报",wRET)):
    print(row(nm,solve(obj=o)))

print()
print("="*130); print("二、现行两条刻度的真实位置"); print("="*130)
print(HDR)
cur=dict(cold_min=0.1232,rare_min=0.0180,ret_min=8.624,smin=0.08,smax=0.8)
print(row("现行 frontier 定稿刻度", solve(**cur)))
sc=np.array([97.0,43.1,21.8,28.0,43.2,41.2,58.3,51.6,15.7])/100; sc=sc/sc.sum()*4
print(row("现行生产 showcase(实测份额)",
          dict(s=sc,hit=wHIT@sc,cold=wCOLD@sc,rare=wRARE@sc,ret=wRET@sc)))

print()
print("="*130); print("三、稀有命中率(3/9号)抬升的完整代价曲线  [其余约束放开，只保留 Σs=4]"); print("="*130)
print(f"{'稀有下限%':>9}{'总命中%':>10}{'较峰值损失pp':>13}{'冷门%':>9}{'回报':>9}   份额 s1..s9")
for rm in [0.0,1.0,1.8,2.5,3.0,4.0,5.0,6.0,7.0,8.0,8.4899]:
    d=solve(rare_min=rm/100 or None)
    if d: print(f"{rm:>9.2f}{d['hit']*100:>10.3f}{(d['hit']-0.659813)*100:>13.3f}"
                f"{d['cold']*100:>9.3f}{d['ret']:>9.3f}   [{' '.join(f'{v:.2f}' for v in d['s'])}]")

print()
print("="*130); print("四、冷门命中率抬升的完整代价曲线"); print("="*130)
print(f"{'冷门下限%':>9}{'总命中%':>10}{'较峰值损失pp':>13}{'稀有%':>9}{'回报':>9}   份额 s1..s9")
for cm in [0,5,10,12.32,15,18,20,22,25,28,30.4577]:
    d=solve(cold_min=cm/100 or None)
    if d: print(f"{cm:>9.2f}{d['hit']*100:>10.3f}{(d['hit']-0.659813)*100:>13.3f}"
                f"{d['rare']*100:>9.3f}{d['ret']:>9.3f}   [{' '.join(f'{v:.2f}' for v in d['s'])}]")

print()
print("="*130); print("五、约束诊断：现行三条下限各自真的在起什么作用？（逐条拆掉看总命中回升多少）"); print("="*130)
base=solve(**cur)
print(HDR); print(row("全约束(现行)",base))
for k in ("cold_min","rare_min","ret_min"):
    c=dict(cur); c[k]=None
    print(row(f"去掉 {k}", solve(**c)))
for k,v in (("smin",0.0),("smax",1.0)):
    c=dict(cur); c[k]=v
    print(row(f"放开 {k}", solve(**c)))

print("\n★ 关键诊断：ret_min 是不是「带稀有号」的有效代理？")
for rt in [0,8.624,10,11,12,13,14,15.0139]:
    d=solve(ret_min=rt or None,smin=0.08,smax=0.8)
    if d: print(f"   只约束 回报≥{rt:<7.3f} -> 总命中{d['hit']*100:6.3f}% 冷门{d['cold']*100:6.3f}% "
                f"稀有{d['rare']*100:6.3f}%  s3={d['s'][2]:.2f} s9={d['s'][8]:.2f}")

print()
print("="*130); print("六、二维前沿：给定稀有下限，冷门命中的最大值（总命中不低于若干档）"); print("="*130)
for hmin in (0.50,0.52,0.54,0.56,0.58):
    out=[]
    for rm in (0.018,0.03,0.04,0.05,0.06):
        A=[-wRARE,-wHIT]; b=[-rm,-hmin]
        r=linprog(-wCOLD,A_ub=np.array(A),b_ub=b,A_eq=np.ones((1,9)),b_eq=[4.0],
                  bounds=[(0,1)]*9,method="highs")
        out.append(f"{-r.fun*100:6.3f}" if r.success else "  ——  ")
    print(f"  总命中≥{hmin*100:.0f}% :  稀有≥1.8%/3%/4%/5%/6% 时冷门上限 = "+" ".join(out))
