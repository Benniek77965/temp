#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""两项独立核查：
 (1) 赤字轮转调度器能否无偏实现 LP 目标份额（Bresenham 不变量是否真成立）
 (2) p̂ 用 24h 窗 vs 全历史，对 LP 解与实际达标率的影响（优化者诅咒 optimizer's curse）
"""
import os as _os, sys as _sys
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_ROOT = _os.path.dirname(_os.path.dirname(_HERE))
_ENGINE = _os.path.join(_ROOT, "jiufa_data")
_DB = _os.environ.get("STA_DB") or _os.path.join(_ENGINE, "spell_tamer_data.db")
if _ENGINE not in _sys.path: _sys.path.insert(0, _ENGINE)

import sys, math, sqlite3
import numpy as np
from collections import Counter
pass  # 见文件头 _ENGINE
import frontier_planner as FP
import itertools

P_TRUE=np.array([0.18375,0.15695,0.04929,0.06525,0.09331,0.09673,0.15720,0.16192,0.03561])
P_TRUE/=P_TRUE.sum()
MULT={1:10,2:50,3:330,4:250,5:100,6:100,7:50,8:50,9:500}
MV=np.array([MULT[i] for i in range(1,10)],float)
COLD=[3,4,5,6,9]; RARE=[3,9]
mC=np.isin(np.arange(1,10),COLD).astype(float); mR=np.isin(np.arange(1,10),RARE).astype(float)
SETS=list(itertools.combinations(range(1,10),4))
A=np.array([[1.0 if i in S else 0.0 for S in SETS] for i in range(1,10)])
CUR=dict(cold_min=0.1232,rare_min=0.0180,ret_min=8.624,share_min=0.08,share_max=0.8)

print("="*100)
print("(1) 调度器保真度：目标份额 vs 实际出场份额")
print("="*100)
mix,diag=FP.plan(list(P_TRUE),MULT,COLD,RARE,**CUR)
tgt=A@np.array([mix.get(S,0.0) for S in SETS])
for N in (200,1000,4000,12000):
    sch=FP.Scheduler(mix)
    cnt=Counter()
    for _ in range(N):
        for c in sch.next(): cnt[c]+=1
    act=np.array([cnt[c]/N for c in range(1,10)])
    print(f"  N={N:6d} 局: 最大份额偏差 = {np.abs(act-tgt).max()*100:.4f} pp"
          f"   实际总命中 {P_TRUE@act*100:.4f}% (目标 {P_TRUE@tgt*100:.4f}%)"
          f"   稀有 {(P_TRUE*mR)@act*100:.4f}% (目标 {(P_TRUE*mR)@tgt*100:.4f}%)")
print(f"  方案含 {len(mix)} 个四码集合；目标份额 = [{' '.join(f'{v:.4f}' for v in tgt)}]")

print()
print("="*100)
print("(2) p̂ 估计噪声的代价（优化者诅咒）：LP 用 p̂ 求解，实际按 p_true 结算")
print("="*100)
DB=_DB
con=sqlite3.connect(f"file:{DB}?mode=ro",uri=True)
seqs={rm:[r[0] for r in con.execute(
        "select custom_id from rounds where room_id=? and custom_id is not null order by round_id",(rm,))]
      for rm in ("1275859","2678075","3746870")}
con.close()

def phat_window(s,t,W):
    c=Counter(s[max(0,t-W):t]); n=min(t,W)
    return np.array([(c[i]+2)/(n+18) for i in range(1,10)])

def eval_window(W,step=50,warm=2000):
    """逐点用窗口 p̂ 解 LP，再用真实 p 结算四项指标"""
    hits=[];colds=[];rares=[];rets=[];feas=[]
    for rm,s in seqs.items():
        for t in range(warm,len(s),step):
            ph=phat_window(s,t,W) if W else np.array(
                [(Counter(s[:t])[i]+2)/(t+18) for i in range(1,10)])
            m,_=FP.plan(list(ph),MULT,COLD,RARE,**CUR)
            sv=A@np.array([m.get(S,0.0) for S in SETS])
            hits.append(P_TRUE@sv); colds.append((P_TRUE*mC)@sv)
            rares.append((P_TRUE*mR)@sv); rets.append((P_TRUE*MV)@sv/4)
            feas.append((P_TRUE*mC)@sv>=CUR["cold_min"]-1e-9)
    return (np.mean(hits),np.mean(colds),np.mean(rares),np.mean(rets),np.mean(feas),len(hits))

# 理论最优（用真 p 解）
m0,_=FP.plan(list(P_TRUE),MULT,COLD,RARE,**CUR)
s0=A@np.array([m0.get(S,0.0) for S in SETS])
print(f"{'p̂ 口径':<26}{'总命中%':>9}{'冷门%':>9}{'稀有%':>9}{'回报':>9}{'冷门达标率':>11}{'样本':>7}")
print(f"{'真 p（不可得·上界）':<26}{P_TRUE@s0*100:>9.4f}{(P_TRUE*mC)@s0*100:>9.4f}"
      f"{(P_TRUE*mR)@s0*100:>9.4f}{(P_TRUE*MV)@s0/4:>9.4f}{'100.0%':>11}{'-':>7}")
for W,nm in ((864,"滑窗864局(≈12h)"),(1727,"滑窗1727局(≈24h·现行)"),(3454,"滑窗3454局(≈48h)"),
             (5000,"滑窗5000局(≈69h)"),(None,"全历史")):
    h,c,r,rt,f,n=eval_window(W)
    print(f"{nm:<26}{h*100:>9.4f}{c*100:>9.4f}{r*100:>9.4f}{rt:>9.4f}{f*100:>10.1f}%{n:>7}")
print("\n注：'冷门达标率' = LP 声称冷门≥12.32%，但按真 p 结算时实际达标的比例。")
print("    低于 100% 即优化者诅咒 —— 约束被 p̂ 的估计噪声骗过去了。")
