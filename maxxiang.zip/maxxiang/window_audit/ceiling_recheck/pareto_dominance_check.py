#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""决定性检验：现行两个刻度点是否被帕累托支配？若被支配，支配点长什么样？"""
import numpy as np
from scipy.optimize import linprog

P=np.array([0.18375,0.15695,0.04929,0.06525,0.09331,0.09673,0.15720,0.16192,0.03561]); P/=P.sum()
MV=np.array([10,50,330,250,100,100,50,50,500.0])
COLD=[3,4,5,6,9]; RARE=[3,9]
mC=np.isin(np.arange(1,10),COLD).astype(float); mR=np.isin(np.arange(1,10),RARE).astype(float)
W={"hit":P,"cold":P*mC,"rare":P*mR,"ret":P*MV/4}
NAMES=["总命中","冷门","稀有","回报"]; KEYS=["hit","cold","rare","ret"]

def metrics(s): return {k:W[k]@s for k in KEYS}

def dominate_check(s0, smin=0.0, smax=1.0, tag=""):
    """max Σ(松弛) s.t. 四项都 ≥ 现值。若最优>0 则被严格支配。"""
    m0=metrics(s0)
    # 变量 = s(9) + t(4 个松弛)；max Σt s.t. W_k·s - t_k >= m0_k ; 0<=t
    c=np.zeros(13); c[9:]=-1.0
    A=[];b=[]
    for i,k in enumerate(KEYS):
        row=np.zeros(13); row[:9]=-W[k]; row[9+i]=1.0
        A.append(row); b.append(-m0[k])
    Aeq=np.zeros((1,13)); Aeq[0,:9]=1.0
    bnds=[(smin,smax)]*9+[(0,None)]*4
    r=linprog(c,A_ub=np.array(A),b_ub=b,A_eq=Aeq,b_eq=[4.0],bounds=bnds,method="highs")
    print(f"\n【{tag}】 现值: "+"  ".join(
        f"{n} {m0[k]*100:.3f}%" if k!="ret" else f"{n} {m0[k]:.4f}" for n,k in zip(NAMES,KEYS)))
    if not r.success:
        print("   LP 失败"); return
    slack=r.x[9:]
    if slack.sum()<1e-9:
        print("   → 帕累托最优：四项无法在不牺牲任一项的前提下同时改进 ✓")
    else:
        s1=r.x[:9]; m1=metrics(s1)
        print("   → ★被严格支配★  存在同时不劣、且以下项更优的份额向量：")
        for n,k in zip(NAMES,KEYS):
            d=m1[k]-m0[k]
            u="%" if k!="ret" else ""
            v0=m0[k]*100 if k!="ret" else m0[k]; v1=m1[k]*100 if k!="ret" else m1[k]
            print(f"      {n:<4} {v0:8.4f}{u} → {v1:8.4f}{u}   ({d*100 if k!='ret' else d:+.4f}{'pp' if k!='ret' else ''})")
        print(f"      支配点份额 s = [{' '.join(f'{v:.3f}' for v in s1)}]")
    return r

# ── 1. 现行生产 showcase（真机实测份额，三房） ──
SC={"1275859":None,"2678075":np.array([97.0,43.1,21.8,28.0,43.2,41.2,58.3,51.6,15.7])/100}
s_sc=SC["2678075"]; s_sc=s_sc/s_sc.sum()*4
dominate_check(s_sc, 0.0, 1.0, "现行生产 explore_style=showcase（房2678075 实测份额）")

# ── 2. 现行 frontier 定稿刻度 ──
def lp(cold_min=None,rare_min=None,ret_min=None,smin=0.0,smax=1.0,obj=None):
    A=[];b=[]
    for k,v in (("cold",cold_min),("rare",rare_min),("ret",ret_min)):
        if v: A.append(-W[k]); b.append(-v)
    r=linprog(-(obj if obj is not None else W["hit"]),
              A_ub=(np.array(A) if A else None),b_ub=(b or None),
              A_eq=np.ones((1,9)),b_eq=[4.0],bounds=[(smin,smax)]*9,method="highs")
    return r.x if r.success else None

s_fr=lp(0.1232,0.0180,8.624,0.08,0.8)
dominate_check(s_fr,0.08,0.8,"现行 frontier 定稿刻度（在其自身 share 边界内检验）")
dominate_check(s_fr,0.0,1.0,"现行 frontier 定稿刻度（放开 share 边界检验）")

print()
print("="*118)
print("三、share_min / share_max 这两条「观感」约束的真实价格")
print("="*118)
print(f"{'配置':<38}{'总命中%':>9}{'冷门%':>9}{'稀有%':>9}{'回报':>9}")
for tag,smin,smax in (("smin=0.08 smax=0.80（现行）",0.08,0.8),("smin=0.08 smax=1.00",0.08,1.0),
                      ("smin=0.05 smax=0.80",0.05,0.8),("smin=0.00 smax=1.00（纯前沿）",0.0,1.0)):
    s=lp(0.1232,0.0180,8.624,smin,smax)
    if s is None: print(f"{tag:<38}{'不可行':>9}"); continue
    m=metrics(s)
    print(f"{tag:<38}{m['hit']*100:>9.3f}{m['cold']*100:>9.3f}{m['rare']*100:>9.3f}{m['ret']:>9.3f}")

print()
print("="*118)
print("四、目标导向搜索：在「总命中不低于现行 frontier 53.155%」的前提下，冷门+稀有能抬到多高")
print("="*118)
print(f"{'方案':<44}{'总命中%':>9}{'冷门%':>9}{'稀有%':>9}{'回报':>9}   份额")
base=metrics(s_fr)
for tag,ret_min in (("保留 ret≥8.624",8.624),("放弃 ret 下限",None)):
    for obj,on in ((W["cold"],"max 冷门"),(W["rare"],"max 稀有"),(W["cold"]+3*W["rare"],"max 冷门+3×稀有")):
        A=[-W["hit"]]; b=[-base["hit"]]
        if ret_min: A.append(-W["ret"]); b.append(-ret_min)
        r=linprog(-obj,A_ub=np.array(A),b_ub=b,A_eq=np.ones((1,9)),b_eq=[4.0],
                  bounds=[(0.08,0.8)]*9,method="highs")
        if not r.success: continue
        m=metrics(r.x)
        print(f"{on+' / '+tag:<44}{m['hit']*100:>9.3f}{m['cold']*100:>9.3f}{m['rare']*100:>9.3f}"
              f"{m['ret']:>9.3f}   [{' '.join(f'{v:.2f}' for v in r.x)}]")
print(f"{'（对照）现行 frontier':<44}{base['hit']*100:>9.3f}{base['cold']*100:>9.3f}"
      f"{base['rare']*100:>9.3f}{base['ret']:>9.3f}   [{' '.join(f'{v:.2f}' for v in s_fr)}]")
