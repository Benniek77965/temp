import os as _os, sys as _sys
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_ROOT = _os.path.dirname(_os.path.dirname(_HERE))
_ENGINE = _os.path.join(_ROOT, "jiufa_data")
_DB = _os.environ.get("STA_DB") or _os.path.join(_ENGINE, "spell_tamer_data.db")
if _ENGINE not in _sys.path: _sys.path.insert(0, _ENGINE)

import sys, random, itertools, time
pass  # 见文件头 _ENGINE
import numpy as np, frontier_planner as V1, frontier_planner_v2 as V2
SETS=list(itertools.combinations(range(1,10),4))
A=np.array([[1.0 if i in S else 0.0 for S in SETS] for i in range(1,10)])
MULT={1:10,2:50,3:330,4:250,5:100,6:100,7:50,8:50,9:500}
COLD=[3,4,5,6,9]; RARE=[3,9]
mC=np.isin(np.arange(1,10),COLD).astype(float); mR=np.isin(np.arange(1,10),RARE).astype(float)
MV=np.array([MULT[i] for i in range(1,10)],float)
P_TRUE=np.array([0.18375,0.15695,0.04929,0.06525,0.09331,0.09673,0.15720,0.16192,0.03561]); P_TRUE/=P_TRUE.sum()
def met(p,s):
    p=np.array(p); return np.array([p@s,(p*mC)@s,(p*mR)@s,(p*MV)@s/4])
rng=random.Random(20260802); n=400
diff_obj=0; diff_share=0; worst_obj=0; worst_share=0; degen=0
for k in range(n):
    m=k%4
    if m==0: p=[rng.uniform(0.02,0.3) for _ in range(9)]
    elif m==1: p=[10**rng.uniform(-10,-0.5) for _ in range(9)]
    elif m==2: p=list(P_TRUE*np.array([rng.uniform(0.6,1.6) for _ in range(9)]))
    else: p=[rng.choice([1e-9,1e-3,0.2,0.4]) for _ in range(9)]
    s=sum(p); p=[v/s for v in p]
    kw=dict(cold_min=rng.choice([None,0.05,0.1232,0.20,0.30]),
            rare_min=rng.choice([None,0.005,0.018,0.04,0.08]),
            ret_min=rng.choice([None,3.0,8.624,12.0,20.0]),
            share_min=rng.choice([0.0,0.05,0.08,0.12]),
            share_max=rng.choice([0.5,0.8,1.0]))
    m1,d1=V1.plan(p,MULT,COLD,RARE,**kw); s2,d2=V2.plan_shares(p,MULT,COLD,RARE,**kw)
    if (d1.get("relaxed") or [])!=(d2.get("relaxed") or []): continue
    s1=A@np.array([m1.get(S,0.0) for S in SETS]); s2=np.array(s2)
    # p 需与两者内部同样钳位后归一
    pc=[max(v,1e-6) for v in p]; ps=sum(pc); pc=[v/ps for v in pc]
    o1,o2=met(pc,s1),met(pc,s2)
    ds=np.abs(s1-s2).max(); do=np.abs(o1-o2).max()
    worst_share=max(worst_share,ds); worst_obj=max(worst_obj,do)
    if ds>1e-6:
        diff_share+=1
        if do<=1e-9: degen+=1
        else:
            diff_obj+=1
            if diff_obj<=5:
                print(f"  ★真差异 obj差={do:.3e}  v1={o1}  v2={o2}  kw={kw}")
print(f"\n对拍 {n} 例（约束集相同者）:")
print(f"  份额向量不同的 = {diff_share}   其中【同目标值·仅退化顶点不同】= {degen}   【真目标差异】= {diff_obj}")
print(f"  四项指标最大差 = {worst_obj:.3e}   份额最大差 = {worst_share:.3e}")
