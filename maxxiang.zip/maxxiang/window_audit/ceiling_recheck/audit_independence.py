#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""独立核查：出怪序列是否真的与 i.i.d. 多项分布不可区分。
不复用项目任何脚本/结论，从原始 rounds 表重算。"""
import os as _os, sys as _sys
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_ROOT = _os.path.dirname(_os.path.dirname(_HERE))
_ENGINE = _os.path.join(_ROOT, "jiufa_data")
_DB = _os.environ.get("STA_DB") or _os.path.join(_ENGINE, "spell_tamer_data.db")
if _ENGINE not in _sys.path: _sys.path.insert(0, _ENGINE)

import sqlite3, math, itertools, json
from collections import Counter, defaultdict
import numpy as np
from scipy import stats

DB = _DB
con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
rooms = [r[0] for r in con.execute("select distinct room_id from rounds order by room_id")]

data = {}
for rm in rooms:
    rows = con.execute("select round_id,custom_id,start_ms,draw_ms,draw_local from rounds "
                       "where room_id=? and custom_id is not null order by round_id", (rm,)).fetchall()
    data[rm] = rows
allseq = {rm: [r[1] for r in data[rm]] for rm in rooms}

print("="*84)
print("A. 基本频率与总体拟合")
print("="*84)
pool = [c for rm in rooms for c in allseq[rm]]
N = len(pool)
cnt = Counter(pool)
p_hat = np.array([cnt[i]/N for i in range(1,10)])
print(f"总局数 N={N}")
print("号位     " + "".join(f"{i:>9d}" for i in range(1,10)))
print("频率%    " + "".join(f"{p_hat[i-1]*100:>9.3f}" for i in range(1,10)))
print("计数     " + "".join(f"{cnt[i]:>9d}" for i in range(1,10)))

# 三房频率是否同分布（房间同步/差异检验）
tab = np.array([[Counter(allseq[rm])[i] for i in range(1,10)] for rm in rooms])
chi2, p, dof, _ = stats.chi2_contingency(tab)
print(f"\n三房 9x3 列联表齐性检验: chi2={chi2:.2f} df={dof} p={p:.4f}"
      f"  -> {'三房同分布' if p>0.05 else '三房有差异'}")

print()
print("="*84)
print("B. 序列结构检验（每房独立做，再合并）")
print("="*84)

def markov_test(seq, lag):
    """滞后 lag 的 9x9 转移表独立性检验"""
    tbl = np.zeros((9,9))
    for a,b in zip(seq[:-lag], seq[lag:]):
        tbl[a-1,b-1]+=1
    # 去掉全零行列
    keep_r = tbl.sum(1)>0; keep_c = tbl.sum(0)>0
    t = tbl[np.ix_(keep_r,keep_c)]
    chi2,p,dof,_ = stats.chi2_contingency(t)
    return chi2,dof,p

for rm in rooms:
    s = allseq[rm]
    print(f"\n房 {rm}  n={len(s)}")
    for lag in (1,2,3,5,10,20):
        c,d,p = markov_test(s,lag)
        flag = " *显著*" if p<0.05 else ""
        print(f"   滞后{lag:>3d} 转移独立性: chi2={c:8.2f} df={d:3d} p={p:.4f}{flag}")

print("\n合并三房（每房独立累计转移表后相加）:")
for lag in (1,2,3,5,10):
    tbl = np.zeros((9,9))
    for rm in rooms:
        s=allseq[rm]
        for a,b in zip(s[:-lag], s[lag:]):
            tbl[a-1,b-1]+=1
    chi2,p,dof,_ = stats.chi2_contingency(tbl)
    flag = " *显著*" if p<0.05 else ""
    print(f"   滞后{lag:>3d}: chi2={chi2:8.2f} df={dof} p={p:.4f}{flag}")

print()
print("="*84)
print("C. 间隔分布 / 危险率（重点：稀有号刚出后是否更容易再出）")
print("="*84)
for i in range(1,10):
    gaps=[]
    for rm in rooms:
        s=allseq[rm]; last=None
        for k,c in enumerate(s):
            if c==i:
                if last is not None: gaps.append(k-last)
                last=k
    gaps=np.array(gaps)
    p=p_hat[i-1]
    # 几何分布拟合 KS（离散，用卡方分箱更稳）
    mx=int(np.percentile(gaps,99))
    bins=list(range(1,min(mx,40)))
    obs=Counter(np.clip(gaps,1,len(bins)+1))
    o=np.array([obs.get(k,0) for k in range(1,len(bins)+2)],float)
    e=np.array([p*(1-p)**(k-1) for k in range(1,len(bins)+1)],float)
    e=np.append(e,(1-p)**len(bins))
    e=e/e.sum()*o.sum()
    m=e>=5
    chi2=((o[m]-e[m])**2/e[m]).sum(); dof=m.sum()-1
    pv=1-stats.chi2.cdf(chi2,dof)
    # 危险率：紧随（间隔=1）的比例 vs 基率
    n_after=sum(1 for rm in rooms for a,b in zip(allseq[rm][:-1],allseq[rm][1:]) if a==i)
    k_after=sum(1 for rm in rooms for a,b in zip(allseq[rm][:-1],allseq[rm][1:]) if a==i and b==i)
    ph=k_after/max(1,n_after)
    z=(ph-p)/math.sqrt(p*(1-p)/max(1,n_after))
    print(f"号{i}: 基率{p*100:6.3f}%  紧随后再出 {ph*100:6.3f}% (N={n_after:5d}) z={z:+5.2f}"
          f"   几何拟合 chi2={chi2:7.2f} df={dof:2d} p={pv:.4f}"
          f"{'  *异常*' if abs(z)>2.58 or pv<0.01 else ''}")

print()
print("="*84)
print("D. 时段 / 星期 / 房间同步 效应")
print("="*84)
import datetime
def hour_of(row):
    ms = row[3] or row[2]
    return datetime.datetime.utcfromtimestamp(ms/1000+8*3600)

for label, keyf in (("小时(0-23)", lambda d: d.hour),
                    ("星期", lambda d: d.weekday())):
    tbl=defaultdict(lambda: np.zeros(9))
    for rm in rooms:
        for row in data[rm]:
            d=hour_of(row); tbl[keyf(d)][row[1]-1]+=1
    M=np.array([tbl[k] for k in sorted(tbl)])
    M=M[:, M.sum(0)>0]
    chi2,p,dof,_=stats.chi2_contingency(M)
    print(f"{label} x 号位 独立性: chi2={chi2:8.2f} df={dof} p={p:.4f}"
          f"{'  *显著*' if p<0.05 else ''}")

# 跨房同步：同一时刻三房是否同号
print("\n跨房同步（按 draw_ms 对齐 ±30s）:")
import bisect
base=rooms[0]
bt=[ (r[3] or r[2]) for r in data[base] ]
bc=[ r[1] for r in data[base] ]
for rm in rooms[1:]:
    same=tot=0
    for r in data[rm]:
        t=r[3] or r[2]
        j=bisect.bisect_left(bt,t)
        for jj in (j-1,j):
            if 0<=jj<len(bt) and abs(bt[jj]-t)<=30000:
                tot+=1; same+= (bc[jj]==r[1]); break
    if tot:
        exp=sum(p_hat**2)
        z=(same/tot-exp)/math.sqrt(exp*(1-exp)/tot)
        print(f"  {base} vs {rm}: 配对{tot} 同号率{same/tot*100:.3f}% "
              f"独立期望{exp*100:.3f}% z={z:+.2f}{'  *显著*' if abs(z)>2.58 else ''}")

print()
print("="*84)
print("E. 游程 / 熵 / 序列压缩检验")
print("="*84)
for rm in rooms:
    s=allseq[rm]
    runs=1
    for a,b in zip(s[:-1],s[1:]):
        if a!=b: runs+=1
    n=len(s); pe=1-sum(p_hat**2)
    er=1+(n-1)*pe; sd=math.sqrt((n-1)*pe*(1-pe))
    z=(runs-er)/sd
    ent=-sum(v/n*math.log2(v/n) for v in Counter(s).values())
    print(f"房{rm}: 游程{runs} 期望{er:.1f}±{sd:.1f} z={z:+.2f}   一阶熵={ent:.4f} bit "
          f"(上界 log2(9)={math.log2(9):.4f})")

# 条件熵（是否能靠前一局降熵）
print("\n条件熵检验（H(X_t | X_{t-1}) 是否显著低于 H(X_t)）:")
for lag in (1,2,3):
    j=Counter()
    for rm in rooms:
        s=allseq[rm]
        for a,b in zip(s[:-lag],s[lag:]): j[(a,b)]+=1
    tot=sum(j.values())
    pj={k:v/tot for k,v in j.items()}
    pa=Counter(); 
    for (a,b),v in j.items(): pa[a]+=v
    Hc=-sum(v*math.log2(v/(pa[k[0]]/tot)) for k,v in pj.items())
    H=-sum(p*math.log2(p) for p in p_hat if p>0)
    # 互信息显著性: 2*N*ln2*MI ~ chi2(df=(9-1)^2)
    MI=H-Hc
    stat=2*tot*math.log(2)*MI
    pv=1-stats.chi2.cdf(stat,64)
    print(f"  lag={lag}: H={H:.5f}  H(X|X-{lag})={Hc:.5f}  互信息={MI:.6f} bit  "
          f"G²={stat:.2f} df=64 p={pv:.4f}{'  *显著*' if pv<0.05 else ''}")
con.close()
