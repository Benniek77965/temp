#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""mt_check.py —— 生产 max_train=5000 对长窗的静默截短:逐局证据(单房即可定性)。"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from audit_run import run, ROOMS  # noqa
RM = ROOMS[0]
run(f"{RM}_tw168_mt5000", RM, {"train_window_hours": 168.0, "max_train": 5000})
run(f"{RM}_tw0_mt5000",   RM, {"train_window_hours": 0.0,   "max_train": 5000})
