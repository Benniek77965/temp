#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""audit_analyze.py —— 对 out_audit/*.json.gz 做配对检验与分段统计。

口径:
  · 配对 McNemar 精确二项(整数真除,避免 4.9.5 报告里记的 OverflowError);
  · 公平域 = 目标局起点 >= 数据起点 + 72h(=有限候选窗的最大值),两窗在更早的
    前缀上 seq 相同、预测逐字节相同,那一段只稀释差异;
  · 期望命中 = Σ_{c∈四码} p_true[c],p_true 用该房全样本频率(低噪声口径,
    但对「先验表就是用同一批数据拟合的」这件事本身有循环性,故只作参考列)。
"""
import gzip, json, math, os, sqlite3, sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(HERE, "out_audit")
DB = os.path.join(ROOT, "jiufa_data", "spell_tamer_data.db")
ROOMS = ["2678075", "1275859", "3746870"]
MULT = {1: 10, 2: 50, 3: 330, 4: 250, 5: 100, 6: 100, 7: 50, 8: 50, 9: 500}
COLD, RARE = {3, 4, 5, 6, 9}, {3, 9}


def load(tag):
    p = os.path.join(OUT, tag + ".json.gz")
    if not os.path.exists(p):
        return None
    with gzip.open(p, "rt") as f:
        return json.load(f)


_META = {}


def room_meta(room):
    if room in _META:
        return _META[room]
    con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    rows = con.execute("SELECT round_id, custom_id, start_ms FROM rounds "
                       "WHERE room_id=? AND custom_id IS NOT NULL ORDER BY round_id",
                       (room,)).fetchall()
    con.close()
    t0 = rows[0][2]
    start = {r[0]: r[2] for r in rows}
    cnt = Counter(r[1] for r in rows)
    n = sum(cnt.values())
    ptrue = [cnt[i] / n for i in range(1, 10)]
    # 留一房真表:用另外两房的合并频率当「真值」。三房分布齐性 χ²=16.18/p=0.44
    # (仓库 4.9.5 已验),故它是同一常数向量的无偏估计,且**与本房实际序列独立**
    # —— 这一条是关键:用本房全样本当真值会给长窗一个样本内优势(窗口越长
    # p̂ 越贴近该真值),把「更长更好」这个结论部分地内生出来。
    con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    oc = Counter(r[0] for r in con.execute(
        "SELECT custom_id FROM rounds WHERE room_id!=? AND custom_id IS NOT NULL", (room,)))
    con.close()
    on = sum(oc.values())
    ploo = [oc[i] / on for i in range(1, 10)]
    _META[room] = (t0, start, ptrue, ploo)
    return _META[room]


def mcnemar(b, c):
    """精确二项双尾。b=A中B不中, c=A不中B中。"""
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    s = sum(math.comb(n, i) for i in range(k + 1))
    if n <= 1000:
        return min(1.0, 2 * s / (2 ** n))
    z = (abs(b - c) - 1) / math.sqrt(n)
    return math.erfc(z / math.sqrt(2))


def seg_rows(d, room, lo_h=None, hi_h=None, lo_idx=None, hi_idx=None):
    t0, start, _, _ = room_meta(room)
    out = {}
    for tgt, hit, act, tn, four, gidx in d["rows"]:
        src = tgt - 50001                       # 生成该预测的那一局
        st = start.get(src)
        if st is None:
            continue
        h = (st - t0) / 3600000.0
        if lo_h is not None and h < lo_h:
            continue
        if hi_h is not None and h >= hi_h:
            continue
        if lo_idx is not None and gidx < lo_idx:
            continue
        if hi_idx is not None and gidx >= hi_idx:
            continue
        out[tgt] = (hit, act, four)
    return out


def stats(rows, room):
    _, _, ptrue, ploo = room_meta(room)
    n = len(rows)
    if n == 0:
        return None
    hit = sum(v[0] for v in rows.values())
    cold = sum(1 for v in rows.values() if v[0] and v[1] in COLD)
    rare = sum(1 for v in rows.values() if v[0] and v[1] in RARE)
    ret = sum(MULT[v[1]] / 4 if v[0] else 0.0 for v in rows.values())
    exp = sum(sum(ptrue[c - 1] for c in v[2]) for v in rows.values())
    exl = sum(sum(ploo[c - 1] for c in v[2]) for v in rows.values())
    return dict(n=n, p4=hit / n * 100, cold=cold / n * 100, rare=rare / n * 100,
                ret=ret / n, exp=exp / n * 100, exl=exl / n * 100)


def compare(tag_a, tag_b, label, lo_h=None, hi_h=None, lo_idx=None, hi_idx=None,
            rooms=ROOMS):
    """A=基准, B=候选。打印分房 + 合计。"""
    print(f"\n=== {label} ===")
    print(f'{"房":<10}{"n":>7}{"基准%":>9}{"候选%":>9}{"净差pp":>9}'
          f'{"b/c":>12}{"配对p":>9}{"期望Δ":>8}{"冷门Δ":>8}{"稀有Δ":>8}{"回报Δ%":>9}')
    TB = TC = 0
    agg = {"n": 0, "ha": 0, "hb": 0}
    for rm in rooms:
        da, db_ = load(f"{rm}_{tag_a}"), load(f"{rm}_{tag_b}")
        if not da or not db_:
            print(f"{rm:<10}  (缺 {tag_a if not da else tag_b})")
            continue
        A = seg_rows(da, rm, lo_h, hi_h, lo_idx, hi_idx)
        B = seg_rows(db_, rm, lo_h, hi_h, lo_idx, hi_idx)
        keys = set(A) & set(B)
        A = {k: A[k] for k in keys}
        B = {k: B[k] for k in keys}
        sa, sb = stats(A, rm), stats(B, rm)
        if not sa:
            continue
        b = sum(1 for k in keys if A[k][0] and not B[k][0])
        c = sum(1 for k in keys if not A[k][0] and B[k][0])
        p = mcnemar(b, c)
        TB += b; TC += c
        agg["n"] += sa["n"]; agg["ha"] += sa["p4"] * sa["n"] / 100
        agg["hb"] += sb["p4"] * sb["n"] / 100
        print(f'{rm:<10}{sa["n"]:>7}{sa["p4"]:>9.3f}{sb["p4"]:>9.3f}'
              f'{sb["p4"]-sa["p4"]:>+9.3f}{f"{b}/{c}":>12}{p:>9.4f}'
              f'{sb["exp"]-sa["exp"]:>+8.3f}{sb["cold"]-sa["cold"]:>+8.3f}'
              f'{sb["rare"]-sa["rare"]:>+8.3f}'
              f'{(sb["ret"]-sa["ret"])/sa["ret"]*100:>+9.2f}')
    if agg["n"]:
        pa, pb = agg["ha"] / agg["n"] * 100, agg["hb"] / agg["n"] * 100
        print(f'{"合计":<10}{agg["n"]:>7}{pa:>9.3f}{pb:>9.3f}{pb-pa:>+9.3f}'
              f'{f"{TB}/{TC}":>12}{mcnemar(TB, TC):>9.4f}')
    return


if __name__ == "__main__":
    print(__doc__)
