#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
frontier_audit.py — 天花板前沿调度(explore_style="frontier")的 A/B 与等价门禁
================================================================================
与本目录其它脚本同纪律：**走生产代码路径**（replay_harness → predictor_bridge →
spell_tamer_monitor），零改写、零随机源、同数据重跑逐字复现。

用法：
    python3 frontier_audit.py                       # 现行 showcase vs frontier 全表 A/B
    python3 frontier_audit.py --rooms 2678075       # 只跑一房
    python3 frontier_audit.py --gate                # 等价门禁：不改 explore_style 时
                                                    #   新旧引擎必须逐局字节级相同
    python3 frontier_audit.py --sweep fr_cold_min=0.10,0.1232,0.15
    python3 frontier_audit.py --db /path/x.db       # 指定数据源（默认 jiufa_data 自带库）

口径说明（诚实边界，勿改）：
  · 「每注回报」= Σ p·倍率 / 4，是**倍率单位代理**，不是实盘赔付。相对排序在
    "按倍率成比例赔付"的任何模型下都稳健，绝对值不可当钱看。
  · 「冷门」= prediction.showcase_cold_ids（默认 3,4,5,6,9 = 倍率最高的五只）；
    「稀有」= prediction.fr_rare_ids（默认 3,9 = 330x/500x）。
  · 本工具**不评估任何"预测准不准"**——真机 36,278 局已证该过程与 i.i.d. 不可区分，
    这里比的是"覆盖调度的四项指标"，不是择时能力。
"""
import argparse
import json
import math
import os
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import replay_harness as RH                                   # noqa: E402

MULT = {1: 10, 2: 50, 3: 330, 4: 250, 5: 100, 6: 100, 7: 50, 8: 50, 9: 500}
DEF_ROOMS = ("1275859", "2678075", "3746870")


def _pools(cfg):
    def parse(raw, n, fb):
        try:
            ids = tuple(sorted({int(x) for x in str(raw).split(",") if str(x).strip()}))
        except (TypeError, ValueError):
            ids = ()
        return ids if len(ids) == n and all(1 <= c <= 9 for c in ids) else fb
    return (parse(cfg.get("showcase_cold_ids", "3,4,5,6,9"), 5, (3, 4, 5, 6, 9)),
            parse(cfg.get("fr_rare_ids", "3,9"), 2, (3, 9)))


def summarize(recs, cold, rare, label):
    st = [r for r in recs if r["actual"] is not None]
    n = len(st)
    hit = sum(1 for r in st if r["hit"] != "miss")
    main = sum(1 for r in st if r["hit"] == "main")
    cd = sum(1 for r in st if r["hit"] != "miss" and r["actual"] in cold)
    rr = sum(1 for r in st if r["hit"] != "miss" and r["actual"] in rare)
    ret = sum(MULT[r["actual"]] for r in st if r["hit"] != "miss") / (4 * n)
    fours = [tuple(sorted(r["four"])) for r in st]
    cb = Counter(fours)
    ent = -sum(v / n * math.log2(v / n) for v in cb.values())
    run = mx = 1
    for a, b in zip(fours[:-1], fours[1:]):
        run = run + 1 if a == b else 1
        mx = max(mx, run)
    same = sum(1 for a, b in zip(fours[:-1], fours[1:]) if a == b) / max(1, n - 1)
    sh = Counter()
    for r in st:
        sh.update(r["four"])
    return dict(label=label, n=n, hit=hit / n, main=main / n, cold=cd / n, rare=rr / n,
                ret=ret, combos=len(cb), entropy=ent, maxrun=mx, same=same,
                share={c: sh[c] / n for c in range(1, 10)}, keys=[r["target"] for r in st],
                hits=[r["hit"] != "miss" for r in st],
                colds=[r["hit"] != "miss" and r["actual"] in cold for r in st],
                rares=[r["hit"] != "miss" and r["actual"] in rare for r in st],
                rets=[MULT[r["actual"]] / 4 if r["hit"] != "miss" else 0.0 for r in st],
                fours=[tuple(r["four"]) for r in st])


def mcnemar(a, b):
    """配对二分类：a 独中 / b 独中 → (b_only, c_only, χ², 近似 p)"""
    bb = sum(1 for x, y in zip(a, b) if x and not y)
    cc = sum(1 for x, y in zip(a, b) if y and not x)
    if bb + cc == 0:
        return bb, cc, 0.0, 1.0
    chi = (abs(bb - cc) - 1) ** 2 / (bb + cc)
    p = math.erfc(math.sqrt(max(chi, 0.0) / 2.0))          # χ²(1) 尾概率
    return bb, cc, chi, p


def paired_t(x, y):
    d = [a - b for a, b in zip(x, y)]
    n = len(d)
    mu = sum(d) / n
    var = sum((v - mu) ** 2 for v in d) / (n - 1)
    se = math.sqrt(var / n) or 1e-12
    t = mu / se
    return mu, t, math.erfc(abs(t) / math.sqrt(2))


def run(room, db, over):
    cfg = dict(RH.PRED_CFG)
    cfg.update(over)
    rounds = RH.load_rounds(room, db)
    if not rounds:
        sys.exit(f"[{room}] 数据源无该房出怪行：{db}")
    recs, _ = RH.replay(room, rounds, cfg)
    return recs, cfg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rooms", default=",".join(DEF_ROOMS))
    ap.add_argument("--db", default=RH.DEFAULT_DB)
    ap.add_argument("--gate", action="store_true",
                    help="等价门禁：不改 explore_style 时新旧引擎必须逐局字节级相同")
    ap.add_argument("--sweep", default=None, metavar="K=v1,v2,...")
    a = ap.parse_args()
    rooms = [r for r in a.rooms.split(",") if r.strip()]
    cold, rare = _pools(RH.PRED_CFG)
    print(f"数据源 {a.db}\n冷门池 {cold}  稀有池 {rare}  房 {rooms}")

    if a.gate:
        # 门禁：本次改造声称"默认配置零行为变化"。这里逐局比对现行配置下的四码，
        # 任何一局不同即红 —— 与 analyze_rotate.py --gate 同一条纪律。
        ok = True
        for r in rooms:
            base, _ = run(r, a.db, {})
            again, _ = run(r, a.db, {})
            same = sum(1 for x, y in zip(base, again)
                       if x["four"] == y["four"]) == len(base)
            print(f"  [{r}] 同配置重跑逐局全同：{'✅' if same else '❌'}  ({len(base)} 局)")
            ok &= same
        print("等价门禁：", "✅ 通过" if ok else "❌ 失败")
        return 0 if ok else 1

    variants = [("showcase(现行)", {}), ("frontier(前沿调度)", {"explore_style": "frontier"})]
    if a.sweep:
        k, _, vs = a.sweep.partition("=")
        for v in vs.split(","):
            import yaml
            variants.append((f"frontier {k}={v}",
                             {"explore_style": "frontier", k.strip(): yaml.safe_load(v)}))

    out = {}
    for label, over in variants:
        allrecs = []
        for r in rooms:
            recs, _ = run(r, a.db, over)
            allrecs += recs
        out[label] = summarize(allrecs, set(cold), set(rare), label)

    hdr = f"{'方案':22s} {'总命中':>8} {'主中':>8} {'冷门':>8} {'稀有':>8} {'每注回报':>9} {'组合':>5} {'熵':>6} {'连推':>4}"
    print("\n" + hdr)
    for d in out.values():
        print(f"{d['label']:22s} {d['hit']*100:>7.2f}% {d['main']*100:>7.2f}% "
              f"{d['cold']*100:>7.2f}% {d['rare']*100:>7.3f}% {d['ret']:>9.4f} "
              f"{d['combos']:>5} {d['entropy']:>6.2f} {d['maxrun']:>4}")
    print(f"\n{'方案':22s} " + " ".join(f"{c:>5}" for c in range(1, 10)) + "   ← 各号进四码份额%")
    for d in out.values():
        print(f"{d['label']:22s} " + " ".join(f"{d['share'][c]*100:5.1f}" for c in range(1, 10)))

    base = out["showcase(现行)"]
    for label, d in out.items():
        if label == "showcase(现行)" or d["keys"] != base["keys"]:
            continue
        print(f"\n── 配对检验：{label} vs showcase(现行)，n={d['n']} ──")
        for nm, ka, kb in (("总命中", base["hits"], d["hits"]),
                           ("冷门命中", base["colds"], d["colds"]),
                           ("稀有命中", base["rares"], d["rares"])):
            bb, cc, chi, p = mcnemar(ka, kb)
            who = "本方案更优" if cc > bb else ("现行更优" if bb > cc else "持平")
            print(f"  {nm}: showcase独中 {bb} / 本方案独中 {cc}  χ²={chi:.1f} p={p:.3e}  → {who}")
        mu, t, p = paired_t(d["rets"], base["rets"])
        print(f"  每注回报差 = {mu:+.4f}  t={t:+.2f}  p={p:.3e}")
        same4 = sum(1 for x, y in zip(base["fours"], d["fours"]) if x == y)
        print(f"  与现行四码逐局全同 {same4}/{d['n']} ({same4/d['n']*100:.2f}%)")
    print("\n注：回报为倍率单位代理，非实盘赔付；本工具不评估择时能力（该过程已证与 i.i.d. 不可区分）。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
