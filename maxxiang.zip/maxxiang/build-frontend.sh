#!/usr/bin/env bash
# build-frontend.sh — 就地把未混淆前端源码构建为混淆产物 dist/
# 平时:本目录全是未混淆源码(可读、可维护、可 git)。
# 部署:跑本脚本 → 自动「注释清除 + 压缩 + 深度混淆」→ 产出 dist/(只含混淆产物)。
# dist/ 即前端可部署静态根;源码原样保留、不被改动。
set -Eeuo pipefail
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "✗ 需要 Node.js 18+(用于混淆构建)"; exit 1; }
[ -f package-lock.json ] && NPM_CMD="npm ci" || NPM_CMD="npm install"
echo "① 安装构建依赖($NPM_CMD)…"
[ -n "${NPM_REGISTRY:-}" ] && npm config set registry "$NPM_REGISTRY"
$NPM_CMD --no-audit --no-fund
echo "② 混淆构建 → dist/ …"
# 4.0.0:本地构建同样启用增量缓存(.fe-cache/,内容寻址;FE_CACHE="" 可关闭)
# 与多核并行(FE_JOBS 可覆写);未改动文件毫秒级回放,只有真正改过的才重混淆。
export FE_CACHE="${FE_CACHE-.fe-cache}"
node build-deploy.mjs
echo
echo "✓ 完成。前端可部署产物在 ./dist/(混淆);源码未改动。"
echo "  抽验:head -c 60 dist/assets/app.js   # 应见 (function(f,g){const … 混淆头"
