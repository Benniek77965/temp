/*!
 * jf-fix.js —— 九法降妖 · 兼容性修复层
 * 必须在 js/index.web.*.js(业务 bundle) 之前加载。
 *
 * 修复 A：localStorage 不可用时(隐私模式/禁站点数据/file://)，
 *         hasSeenNewbieGuideVideo 退化为 false → 新手引导层弹出 → 引导视频 404。
 *         这里用内存 shim 兜底，并强制两个"已看过"标记恒为 true。
 * 修复 B：本项目未内置任何 mp4(fxams/*.mp4 全部 404)。国产浏览器(小米/UC/QQ/夸克)
 *         会用内置播放器接管 <video>，src 404 时全屏弹出"视频不存在"并遮挡页面。
 *         这里在 src 落地前就拦下，改为立即派发 error，让官方组件走它自带的
 *         fallbackSrc(图片)分支 —— 零视频请求，浏览器无从接管。
 */
(function () {
  'use strict';

  var GUIDE_KEYS = {
    'kugou_jiufa_has_seen_guide': 'true',
    'kugou_jiufa_has_seen_newbie_guide_video': 'true'
  };

  /* ---------- 修复 A：localStorage 兜底 ---------- */
  (function fixStorage() {
    var usable = false;
    try {
      var ls = window.localStorage;
      var probe = '__jf_probe__';
      ls.setItem(probe, '1');
      ls.removeItem(probe);
      usable = true;
    } catch (e) { usable = false; }

    if (usable) {
      try {
        for (var k in GUIDE_KEYS) localStorage.setItem(k, GUIDE_KEYS[k]);
      } catch (e) { usable = false; }
    }

    if (usable) return;

    // localStorage 不可用 → 装一个内存实现，保证 getItem 不抛异常且引导标记为已看过
    var mem = {};
    for (var g in GUIDE_KEYS) mem[g] = GUIDE_KEYS[g];
    var shim = {
      getItem: function (k) { k = String(k); return Object.prototype.hasOwnProperty.call(mem, k) ? mem[k] : null; },
      setItem: function (k, v) { mem[String(k)] = String(v); },
      removeItem: function (k) { delete mem[String(k)]; },
      clear: function () { mem = {}; },
      key: function (i) { var ks = Object.keys(mem); return i < ks.length ? ks[i] : null; }
    };
    try { Object.defineProperty(shim, 'length', { get: function () { return Object.keys(mem).length; } }); } catch (e) {}
    try {
      Object.defineProperty(window, 'localStorage', { configurable: true, get: function () { return shim; } });
    } catch (e) {}
  })();

  /* ---------- 修复 B：视频拦截 ---------- */
  (function fixVideo() {
    // 只拦"注定 404"的站内视频；blob:/data: 等放行，日后若补齐 mp4 可把 SHOULD_BLOCK 改为返回 false
    function shouldBlock(url) {
      var s = String(url || '');
      if (!s) return false;
      if (/^(blob:|data:)/i.test(s)) return false;
      return /\.(mp4|webm|mov|m4v)(\?|#|$)/i.test(s);
    }

    function neuter(el) {
      if (el.__jfNeutered) return;
      el.__jfNeutered = true;

      var fire = function () {
        // 官方组件在赋 src 之前已挂好 error 监听 → 这里派发即触发它自带的 fallback(图片)
        setTimeout(function () {
          try { el.dispatchEvent(new Event('error')); } catch (e) {
            try { var ev = document.createEvent('Event'); ev.initEvent('error', false, false); el.dispatchEvent(ev); } catch (e2) {}
          }
        }, 0);
      };

      // 1) 拦 src property（InlineVideo / AlphaVideoPlayer 都是 n.src = t）
      try {
        Object.defineProperty(el, 'src', {
          configurable: true,
          enumerable: true,
          get: function () { return ''; },
          set: function (v) { if (shouldBlock(v)) { fire(); } else { el.setAttribute('src', v); } }
        });
      } catch (e) {}

      // 2) 拦 setAttribute('src', ...)
      var origSetAttr = el.setAttribute;
      el.setAttribute = function (name, value) {
        if (String(name).toLowerCase() === 'src' && shouldBlock(value)) { fire(); return; }
        return origSetAttr.apply(el, arguments);
      };

      // 3) 不覆盖 load()/play()：被拦的 video 始终无 src，原生 play() 会以
      //    bundle 已处理的同一 NotSupportedError 拒绝；不覆盖可保证日后放行
      //    白名单源或 blob:/data: 时视频功能完好。
    }

    // 动态创建的 video（本项目全部走这条路径）
    var origCreate = document.createElement;
    document.createElement = function (tag) {
      var el = origCreate.apply(document, arguments);
      try { if (String(tag).toLowerCase() === 'video') neuter(el); } catch (e) {}
      return el;
    };

    // 兜底：静态/第三方插入的 video
    function sweep(root) {
      try {
        var vs = (root || document).querySelectorAll ? (root || document).querySelectorAll('video') : [];
        for (var i = 0; i < vs.length; i++) neuter(vs[i]);
      } catch (e) {}
    }
    if (window.MutationObserver) {
      var mo = new MutationObserver(function (recs) {
        for (var i = 0; i < recs.length; i++) {
          var added = recs[i].addedNodes || [];
          for (var j = 0; j < added.length; j++) {
            var n = added[j];
            if (!n || n.nodeType !== 1) continue;
            if (n.tagName === 'VIDEO') neuter(n); else sweep(n);
          }
        }
      });
      var startMO = function () { try { mo.observe(document.documentElement, { childList: true, subtree: true }); } catch (e) {} };
      if (document.documentElement) startMO(); else document.addEventListener('readystatechange', startMO, { once: true });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { sweep(document); });
    else sweep(document);
  })();
})();
