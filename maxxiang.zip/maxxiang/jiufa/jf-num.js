/*!
 * jf-num.js —— 九法降妖 · 真实×官方 妖兽编号叠加层(2.9.8 新增)
 * 加载位置:jiufa/index.html 业务 bundle 与 sim-hud.js 之后(body 末尾)。
 *
 * 背景(实地核查结论,Playwright 四形态逐一实证):
 *   官方盘面的「观测台号位」角标(球面 1-9 圆片、妖兽名旁编号)一直由
 *   sim-hud.js 注入,而 sim-hud 在 mode=real(真实×官方)下随模拟钱包一并
 *   整体退场 —— 于是模拟×官方处处有编号、真实×官方一个编号都没有。
 *   sim-hud.js 是 javascript-obfuscator 预混淆产物(自带 selfDefending 护甲,
 *   见 README「源码形态说明」),不可就地改写;按既定惯例(jf-fix / jf-boot
 *   同款),补齐逻辑放本独立明文小文件,构建器按 LIGHT_JS 轻压缩。
 *
 * 行为(仅 mode=real 生效;模拟形态零副作用,编号仍由 sim-hud 负责):
 *   1) 球面编号角标:九宫格每个 .spell-orb 左上角补「观测台号位」圆片
 *      (.jfn-orbnum,几何/配色与 sim-hud 的 .jf-orbnum 逐像素同款),并镜像
 *      data-jf-num 属性。号位优先解析球体 aria-label 里的「N号·」前缀
 *      (该前缀由 sim-engine 按共享引擎 display_number 生成,权威同源);
 *      兜底走「球体元素类 → spell_key → 引擎法术表」查表。
 *   2) 妖兽名编号圆片:凡可见文本中出现妖兽名(布置法术弹窗「可击败【××】」、
 *      结算/二级页等),在其后补 .jfn-nchip 编号圆片 —— 与模拟形态 HUD 图鉴
 *      的「名旁编号」同一视觉语言。跑马灯(.notice)与榜单类容器不装饰。
 *   3) 开出妖兽编号:出怪揭示层把当局号位圆片钉在妖兽名幅
 *      (.battle-monster-tag,z3)顶上 —— 名幅层级高于妖兽画容器(z1),
 *      且避开页顶横幅(.logo)对容器上缘约 .45rem 的覆盖带(实测像素级取证:
 *      角标若挂容器右上角会被横幅整体压住,DOM/计算样式全对但不上屏);
 *      名幅缺位时兜底挂画容器右侧但下移出覆盖带(--safe)。结算页仍在妖兽画
 *      (.settlement-page__beast-logo)右上角(该页无横幅覆盖,已像素验证)。
 *      身份取 img[alt](引擎 beast_name 直通)或 battle-monster-tag--<元素> 类。
 *
 * 数据与配色:
 *   · 号位/名录:window.JiufaSim.engine.spells(嵌入形态 = 父页真实数据版
 *     RoundEngine.spells,display_number 即观测台 custom_beast_ids 权威号位;
 *     独立形态 = /assets/round-engine.js 同接口)。法术表未就绪时跳过本拍,
 *     就绪后由观察器/巡检自动补上;切房后号位有变亦由同一巡检自愈。
 *   · 珠色:优先读父页(观测台)CSS 变量 --e1..--e9 实时同源;跨源/独立形态
 *     退回内置色表(与 assets/app.css 逐值一致,亦即 sim-hud 独立形态用色)。
 *
 * React 安全性(为什么是「附加兄弟/子节点」而不是「切割文本节点」):
 *   业务 bundle 为 React 产物。第三方脚本若包裹/切割其托管文本节点,后续
 *   reconcile 可能 removeChild 触发 NotFoundError 整页崩(Google 翻译经典坑)。
 *   本文件只在元素末尾 append 自有节点、只删除自有节点(jfn- 前缀),文本
 *   变更(React 就地改 nodeValue)由 MutationObserver 巡检把圆片改号或撤下,
 *   任何路径都不触碰 React 托管节点。
 *
 * 本文件为未混淆源码;构建器(build-deploy.mjs)按 LIGHT_JS 轻压缩处理
 * (与 jf-fix / jf-boot 同档:叠加/守卫类垫片深度混淆有破坏 this 绑定 /
 * 时序的前科,且其价值在可靠性不在保密)。
 */
(function () {
  'use strict';

  /* ── 0. 仅真实×官方生效:mode=real 之外零副作用退场 ─────────────────── */
  var MODE_REAL = /(?:\?|&)mode=real(?:&|$)/.test(String(window.location.search || ''));
  if (!MODE_REAL) return;

  /* ── 1. 常量与数据源 ─────────────────────────────────────────────────── */
  // 观测台九法元素色谱(与 assets/app.css 的 --e1..--e9 逐值一致;
  // 嵌入形态运行时优先读父页实时变量,本表仅作跨源/独立形态兜底)
  var PALETTE = { 1: '#8d5e35', 2: '#2e7a3d', 3: '#bf371d', 4: '#526d89', 5: '#7652c1',
                  6: '#87681d', 7: '#13748a', 8: '#b23c6f', 9: '#2b67c2' };
  // 球体/揭示层元素类 → spell_key(据原版 bundle 类名实测:pos-1..9 依次
  // neutral=器 dark=丹 thunder=剑 light=道 jin=金 wind=木 water=水 fire=火 earth=土)
  var CLS_KEY = { neutral: '器', dark: '丹', thunder: '剑', light: '道', jin: '金',
                  wind: '木', water: '水', fire: '火', earth: '土' };
  var ARIA_NUM_RE = /(^|[^0-9])([1-9])\s*号/;   // aria-label / 文本里的「N号」前缀

  function spellsNow() {                         // 共享引擎法术表(未就绪返回 null)
    try {
      var js = window.JiufaSim;
      var arr = js && js.engine && js.engine.spells;
      if (arr && arr.length) return arr;
    } catch (e) {}
    return null;
  }
  function buildMaps(spells) {                   // beast_name / spell_key → 号位
    var byBeast = {}, byKey = {}, names = [];
    for (var i = 0; i < spells.length; i++) {
      var sp = spells[i] || {};
      var n = Number(sp.display_number);
      if (!(n >= 1 && n <= 9)) continue;
      if (sp.beast_name) { byBeast[sp.beast_name] = n; names.push(String(sp.beast_name)); }
      if (sp.spell_key) byKey[sp.spell_key] = n;
    }
    return { byBeast: byBeast, byKey: byKey, names: names };
  }
  function colorFor(n) {                         // 珠色:父页变量实时同源,兜底内置表
    try {
      if (window.parent && window.parent !== window) {
        var v = window.parent.getComputedStyle(window.parent.document.documentElement)
                            .getPropertyValue('--e' + n);
        if (v && v.replace(/\s/g, '')) return v.trim();
      }
    } catch (e) {}                               // 跨源父页:读不了就用兜底表
    return PALETTE[n] || '#8a7340';
  }

  /* ── 2. 样式(几何与 sim-hud 的 .jf-orbnum / .jf-nchip 同款) ─────────── */
  var css =
    '.jfn-orbnum{position:absolute;left:3px;top:3px;z-index:6;pointer-events:none;' +
      'min-width:17px;height:17px;padding:0 3px;border-radius:50%;box-sizing:border-box;' +
      "font:800 11px/17px 'Helvetica Neue',Arial,sans-serif;text-align:center;color:#fff;" +
      'background:var(--jfe,#8a7340);box-shadow:0 0 0 1.5px rgba(255,244,214,.9),0 2px 6px rgba(0,0,0,.45);}' +
    '.jfn-nchip{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;' +
      'border-radius:50%;font:800 10px/1 Arial,sans-serif;color:#fff;background:var(--jfe,#8a7340);' +
      'box-shadow:0 0 0 1px rgba(255,244,214,.8);vertical-align:-2px;margin-left:5px;flex:none;}' +
    '.jfn-beastnum{position:absolute;right:.12rem;top:.12rem;z-index:8;pointer-events:none;' +
      'min-width:.22rem;height:.22rem;padding:0 .04rem;border-radius:50%;box-sizing:border-box;' +
      "font:800 .13rem/.22rem 'Helvetica Neue',Arial,sans-serif;text-align:center;color:#fff;" +
      'background:var(--jfe,#8a7340);box-shadow:0 0 0 .018rem rgba(255,244,214,.9),0 .02rem .06rem rgba(0,0,0,.5);}' +
    /* 揭示层首选:钉在妖兽名幅(battle-monster-tag,z3)顶上 —— 名幅层级高于妖兽画
       (battle-video-container z1),且远离页顶横幅(.logo)的覆盖带;语义即「名旁编号」 */
    '.jfn-beastnum--tag{left:50%;right:auto;top:-.26rem;transform:translateX(-50%);}' +
    /* 无名幅时的兜底:仍挂妖兽画容器,但下移出页顶横幅覆盖带(实测覆盖至容器顶约 .45rem) */
    '.jfn-beastnum--safe{top:.55rem;}';
  var styleEl = document.createElement('style');
  styleEl.setAttribute('data-jfn', '1');
  styleEl.textContent = css;
  (document.head || document.documentElement).appendChild(styleEl);

  /* ── 3. 注入器(全部幂等:只增改自有 jfn- 节点,绝不触碰 React 托管节点) ── */
  function setChip(el, n) {                      // 圆片就地改号(号/色/提示一致化)
    var c = colorFor(n);
    if (el.textContent !== String(n)) el.textContent = String(n);
    if (el.getAttribute('data-n') !== String(n)) el.setAttribute('data-n', String(n));
    if (el.style.getPropertyValue('--jfe') !== c) el.style.setProperty('--jfe', c);
  }

  function orbNumber(orb, maps) {                // 球体 → 号位:aria「N号」优先,类名查表兜底
    var m = ARIA_NUM_RE.exec(String(orb.getAttribute('aria-label') || ''));
    if (m) return Number(m[2]);
    var cls = String(orb.className || '');
    for (var k in CLS_KEY) {
      if (cls.indexOf('spell-orb--' + k) >= 0) {
        var n = maps.byKey[CLS_KEY[k]];
        if (n) return n;
      }
    }
    return 0;
  }
  function paintOrbs(maps) {
    var orbs = document.querySelectorAll('.spell-orb');
    for (var i = 0; i < orbs.length; i++) {
      var orb = orbs[i];
      if (orb.querySelector('.jf-orbnum')) continue;          // sim-hud 已装(理论不共存):不重复
      var n = orbNumber(orb, maps);
      var chip = orb.querySelector(':scope > .jfn-orbnum');
      if (!n) { if (chip) orb.removeChild(chip); continue; }
      if (!chip) {
        chip = document.createElement('i');
        chip.className = 'jfn-orbnum';
        chip.setAttribute('aria-hidden', 'true');
        orb.appendChild(chip);
      }
      chip.title = n + '号法术(与观测台序列同号同色)';
      setChip(chip, n);
      if (orb.getAttribute('data-jf-num') !== String(n)) orb.setAttribute('data-jf-num', String(n));
    }
  }

  // 妖兽名旁编号:装饰范围排除跑马灯与榜单类容器;圆片挂在含名元素末尾
  var SKIP_SEL = '.notice,[class*="rank"],[class*="leaderboard"],script,style,.jfn-nchip,.jfn-orbnum,.jfn-beastnum';
  function inSkipped(el) {
    for (var n = el; n && n.nodeType === 1; n = n.parentElement) {
      if (n.matches && n.matches(SKIP_SEL)) return true;
    }
    return false;
  }
  function directText(el) {                      // 元素直属文本(不含子元素文本)
    var t = '';
    for (var c = el.firstChild; c; c = c.nextSibling) if (c.nodeType === 3) t += c.nodeValue;
    return t;
  }
  function paintNames(maps) {
    if (!maps.names.length || !document.body) return;
    // 先巡检既有圆片:所在元素直属文本已不含其记录的妖兽名 → 撤下(React 就地改文场景)
    var chips = document.querySelectorAll('.jfn-nchip');
    for (var i = 0; i < chips.length; i++) {
      var host = chips[i].parentElement;
      if (!host || directText(host).indexOf(chips[i].getAttribute('data-for') || '\u0000') < 0) {
        if (host) host.removeChild(chips[i]);
      } else {
        var nn = maps.byBeast[chips[i].getAttribute('data-for')];
        if (nn) setChip(chips[i], nn);           // 切房换号位:就地改号
      }
    }
    // 再全量扫描直属文本含妖兽名的元素,补装缺位圆片
    var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    var seen = [], node;
    while ((node = walker.nextNode())) {
      var txt = node.nodeValue;
      if (!txt || txt.length > 200) continue;
      var el = node.parentElement;
      if (!el || seen.indexOf(el) >= 0 || inSkipped(el)) continue;
      for (var j = 0; j < maps.names.length; j++) {
        var name = maps.names[j];
        if (txt.indexOf(name) < 0) continue;
        if (ARIA_NUM_RE.test(txt) && txt.indexOf(name) > txt.search(ARIA_NUM_RE)) continue; // 文本自带「N号」前缀(如法术名行):不重复标注
        var has = false, ex = el.querySelectorAll(':scope > .jfn-nchip');
        for (var k2 = 0; k2 < ex.length; k2++) if (ex[k2].getAttribute('data-for') === name) { has = true; break; }
        if (has) continue;
        var n2 = maps.byBeast[name];
        if (!n2) continue;
        var chip2 = document.createElement('i');
        chip2.className = 'jfn-nchip';
        chip2.setAttribute('data-for', name);
        chip2.title = name + ' · 观测台 ' + n2 + ' 号位';
        setChip(chip2, n2);
        el.appendChild(chip2);
        seen.push(el);
      }
    }
  }

  // 开出妖兽编号:揭示层 / 结算页 —— 身份取 img[alt] 或 tag--<元素> 类
  function beastNumOf(container, maps) {
    var img = container.querySelector('img[alt]');
    if (img && maps.byBeast[img.alt]) return { n: maps.byBeast[img.alt], name: img.alt };
    var tag = container.querySelector('[class*="-tag--"]');
    if (tag) {
      var m = /-tag--([a-z]+)/.exec(String(tag.className));
      if (m && CLS_KEY[m[1]] && maps.byKey[CLS_KEY[m[1]]]) {
        var key = CLS_KEY[m[1]], num = maps.byKey[key];
        for (var i = 0; i < maps.names.length; i++) if (maps.byBeast[maps.names[i]] === num) return { n: num, name: maps.names[i] };
        return { n: num, name: '' };
      }
    }
    return null;
  }
  function ensureCorner(container, hit, variant) {
    var chip = container.querySelector(':scope > .jfn-beastnum');
    if (!hit) { if (chip) container.removeChild(chip); return; }
    var cls = 'jfn-beastnum' + (variant ? ' ' + variant : '');
    if (!chip) {
      chip = document.createElement('i');
      chip.setAttribute('aria-hidden', 'true');
      var pos = window.getComputedStyle(container).position;
      if (pos === 'static') container.style.position = 'relative';
      container.appendChild(chip);
    }
    if (chip.className !== cls) chip.className = cls;
    chip.title = (hit.name ? hit.name + ' · ' : '') + '观测台 ' + hit.n + ' 号位';
    setChip(chip, hit.n);
  }
  function paintReveal(maps) {
    var battle = document.querySelector('.battle-video-container');
    if (battle) {
      var scope = battle.parentElement || battle;
      var hit = beastNumOf(scope, maps);
      var tag = scope.querySelector('[class*="battle-monster-tag"]');
      var host = tag || battle;                          // 首选名幅(z3>画容器z1,且避开页顶横幅)
      ensureCorner(host, hit, tag ? 'jfn-beastnum--tag' : 'jfn-beastnum--safe');
      if (host !== battle) {                             // 宿主切换时清另一侧残片
        var stray = battle.querySelector(':scope > .jfn-beastnum');
        if (stray) battle.removeChild(stray);
      }
    }
    var logo = document.querySelector('.settlement-page__beast-logo');
    if (logo && logo.parentElement) {
      var hitS = (logo.alt && maps.byBeast[logo.alt]) ? { n: maps.byBeast[logo.alt], name: logo.alt } : null;
      ensureCorner(logo.parentElement, hitS);
    }
  }

  /* ── 4. 调度:MutationObserver 节流批 + 2s 兜底巡检(切房/纯属性变更) ── */
  var pending = 0;
  function reconcile() {
    pending = 0;
    try {
      var spells = spellsNow();
      if (!spells) return;                       // 法术表未就绪:跳过本拍,巡检会再来
      var maps = buildMaps(spells);
      paintOrbs(maps);
      paintNames(maps);
      paintReveal(maps);
    } catch (e) { /* 叠加层绝不向游戏抛错 */ }
  }
  function schedule() {
    if (pending) return;
    pending = setTimeout(reconcile, 120);        // 微批:合并 React 一次提交内的连环变更
  }
  try {
    new MutationObserver(function (muts) {
      for (var i = 0; i < muts.length; i++) {
        var t = muts[i].target;
        // 自有节点引发的变更不再回环
        if (t && t.nodeType === 1 && t.className && String(t.className).indexOf('jfn-') >= 0) continue;
        schedule(); return;
      }
    }).observe(document.documentElement, {
      childList: true, subtree: true, characterData: true,
      attributes: true, attributeFilter: ['aria-label', 'alt', 'class'],
    });
  } catch (e) {}
  setInterval(reconcile, 2000);                  // 兜底巡检:引擎迟到 / 切房换号位 / 观察器缺位
  reconcile();

  /* 测试钩子(与 JiufaSim._* 同一惯例;业务代码不得依赖) */
  window.JiufaNum = { version: '2.9.8', reconcile: reconcile };
})();
