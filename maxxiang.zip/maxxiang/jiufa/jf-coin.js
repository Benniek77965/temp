/*!
 * jf-coin.js —— 九法降妖 · 币种口径开关(真实×官方=星币 / 模拟×官方=模拟币)
 * 加载位置:jiufa/index.html <head>,jf-fix.js 之后、sim-engine.js 之前(见下「时序」)。
 *
 * 背景(实地核查结论,逐文件取证):
 *   官方盘面在两个象限复用同一份资源(真实×官方 = /jiufa/?mode=real,
 *   模拟×官方 = /jiufa/),而「模拟币」字样此前是对业务 bundle 与引擎产出
 *   文案做的一次性全量替换,不分模式 —— 于是真金白银的真实×官方盘面上
 *   处处写着「模拟币」。父页 assets/app.js 的 DIY 两象限本就按 RG.mode
 *   分流(sim=模拟币 / real=星币),无需改动;漏口只在 iframe 内,且分两层:
 *
 *     视图层  jiufa/js/index.web.*.js  —— 12 处硬编码字面量
 *             (布置法术弹窗「投入模拟币」、结算页、记录卡、数字键盘提示、
 *              新手 tips 等)。该文件为官方原版 bundle,构建器按 VENDOR_JS_DIRS
 *              原样拷贝,故就地把字面量换成 (window.JF_COIN||"模拟币"),
 *              由本文件在 bundle 执行前赋值 —— 无观察器、无重绘、无闪烁。
 *     数据层  jiufa/sim-engine.js      —— awardDesc「攻击成功可获得 N 倍模拟币奖励」
 *             等文案由引擎拼装后经 fetch 交给 bundle 渲染,两模式返回同一串
 *             (已用 Node 载入引擎实测:mode=real 下 9 条法术的 awardDesc 全部
 *              带「模拟币」)。sim-engine 是 javascript-obfuscator 预混淆产物,
 *             自带 selfDefending 护甲,不可就地改写(见 README「源码形态说明」),
 *             故在本文件包一层 fetch,仅对引擎自应答的接口前缀改口径。
 *
 * 行为(仅 mode=real 生效;模拟形态在设完 JF_COIN 后立即退场,零副作用):
 *   1) window.JF_COIN = '星币'。bundle 的 12 处取值点读它,读不到则回落
 *      '模拟币'(本文件加载失败也只是退回旧文案,不会渲染出 undefined)。
 *   2) 把 /kugou/spell_tamer.SpellTamerApi/* 的应答正文里的「模拟币」整体
 *      改写为「星币」。该前缀正是 sim-engine 自应答的接口族(实测取证),
 *      其正文是引擎就地生成的 JSON,键名全 ASCII,不存在误伤。
 *
 * 时序(为什么必须在 sim-engine 之前,又不会与它打架):
 *   bundle 的部分文案挂在模块顶层数组上(如新手 tips),bundle 一执行就定型,
 *   故 JF_COIN 必须在 <head> 先落位。而 fetch 又必须包住 sim-engine 装的那层
 *   shim —— 两者时序相反。解法是用 getter/setter 占住 window.fetch:
 *   sim-engine 读到的是**原生** fetch(它据此保存放行通道),它写入 shim 时
 *   由 setter 就地包一层。于是「引擎放行 → 原生」与「bundle 调用 → 包装 →
 *   shim」两条链彻底分开,不构成回环(直接前包会让 shim 的放行回调打回包装
 *   函数形成死循环,已按此规避)。
 *
 * 本文件为未混淆源码;构建器(build-deploy.mjs)按 LIGHT_JS 轻压缩处理
 * (与 jf-fix / jf-boot / jf-num 同档:垫片/守卫类深度混淆有破坏 this 绑定与
 *  时序的前科,且其价值在可靠性不在保密)。
 */
(function () {
  'use strict';

  /* ── 0. 模式判定与币名落位 ───────────────────────────────────────────── */
  var MODE_REAL = /(?:\?|&)mode=real(?:&|$)/.test(String(window.location.search || ''));
  var SIM_NAME = '模拟币', REAL_NAME = '星币';

  window.JF_COIN = MODE_REAL ? REAL_NAME : SIM_NAME;   // bundle 的 12 处取值点读这里
  window.JiufaCoin = { version: '1.0.0', real: MODE_REAL, name: window.JF_COIN };

  if (!MODE_REAL) return;                              // 模拟形态:到此为止,不碰 fetch

  /* ── 0.1 控制台口径更正 ────────────────────────────────────────────────
     sim-engine.js 与 bridge.js 随后各会打印一句固定文案(实测原文):
       [sim-engine] …引擎已就绪 · … · 施法为单机模拟(真实扣除/派发模拟币)
       [九法降妖] 原生桥已就绪 · … · 施法为单机模拟(真实扣除/派发模拟币)
     这两句在真实×官方形态下整句都不成立 —— 不只是币名,连「单机模拟」也不对
     (施法实际经父页 RealGameBridge 走官方施法通道真实扣星币)。两者都是
     javascript-obfuscator 预混淆产物,该文案被切片加密进字符串表,无法就地改写;
     劫持 console 又会把整个 iframe 的日志调用点都记到本文件头上,得不偿失。
     故在它们之前先落一句更正,只在真实形态出现,不动任何既有日志。 */
  try {
    console.info('[jf-coin] 真实×官方形态:界面币名 = 星币,施法经父页星币通道真实扣费。' +
                 '随后 sim-engine / bridge 打印的「施法为单机模拟(真实扣除/派发模拟币)」' +
                 '是两个预混淆产物里的固定文案,只对模拟形态成立,本形态以本行为准。');
  } catch (e) {}

  /* ── 1. 数据层改口径:只认引擎自应答的接口族 ─────────────────────────── */
  var API = '/kugou/spell_tamer.SpellTamerApi/';

  function pathOf(input) {                             // 与引擎同款的取路径方式
    var raw = (typeof input === 'string') ? input : (input && input.url) || '';
    return String(raw + '').replace(/^[a-z]+:\/\/[^/]+/i, '').split('?')[0].split('#')[0];
  }

  // Response 构造对 status 有合法区间要求(0 或越界会抛 RangeError,直接打崩盘面),
  // 故一律夹到 200–599;引擎自应答恒为 200,这里只是不让边界值有机会掀桌。
  function reseal(body, res) {
    var st = Number(res && res.status);
    if (!(st >= 200 && st <= 599)) st = 200;
    return new Response(body, { status: st, headers: { 'content-type': 'application/json;charset=utf-8' } });
  }
  function retext(res) {                               // 正文改口径后原样重封
    if (!res || typeof res.text !== 'function') return res;
    return res.text().then(function (body) {
      if (!body || body.indexOf(SIM_NAME) < 0) return reseal(body, res);
      return reseal(body.split(SIM_NAME).join(REAL_NAME), res);
    }, function () { return res; });   // 正文读不出:退回原响应,绝不吞掉这一拍
  }

  function wrap(fn) {
    if (!fn || fn.__jfCoin) return fn;                 // 幂等:已包过不再叠
    var wrapped = function (input) {
      var out = fn.apply(window, arguments);
      var p;
      try { p = pathOf(input); } catch (e) { return out; }
      if (p.indexOf(API) !== 0) return out;            // 非引擎接口:原样放行
      try {
        return Promise.resolve(out).then(retext, function (e) { throw e; });
      } catch (e) { return out; }
    };
    wrapped.__jfCoin = true;
    return wrapped;
  }

  /* ── 2. 用 getter/setter 占位:谁装 shim 就包谁,且不改变别人读到的原生 fetch ── */
  try {
    var current = window.fetch;                        // 此刻是原生 fetch
    Object.defineProperty(window, 'fetch', {
      configurable: true,
      get: function () { return current; },
      set: function (v) { current = wrap(v); }         // sim-engine 装 shim → 就地包一层
    });
  } catch (e) { /* 占位失败:视图层已独立生效,数据层退回旧文案,绝不向游戏抛错 */ }
})();
