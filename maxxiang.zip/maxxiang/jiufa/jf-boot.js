/*!
 * jf-boot.js —— 九法降妖 · 装载自愈守卫(4.1.2 新增)
 * 必须紧跟 sim-engine.js / bridge.js 之后、业务 bundle 之前加载。
 *
 * 背景(Playwright 三场景实地复现的「正在装载模拟游戏」永驻死端):
 *   死端 C:sim-engine.js 本体加载失败(弱网中断 / 省流代理与内置拦截误杀)
 *          → window.JiufaSim 永不定义;业务 bundle 照跑,/kugou/*、/platform/*
 *          的请求失去拦截层**直打真实后端**(实测 405 风暴),父页遮罩永不揭。
 *   死端 D:回合引擎双侧缺位(父页 RoundEngine 未就绪 × /assets/round-engine.js
 *          又拉不下来)→ sim-engine 只打一行 console.error 即放弃,同样无 JiufaSim。
 *   误装形态:会话恢复竞态下帧先于父页解析 → 装了独立引擎(embedded=false),
 *          嵌入语境下盘面与观测台脱钩(父页看门狗 30s 起步才盲踢)。
 * 本文件与父页 app.js 4.1.2 的看门狗封顶/失败终态互为对偶:父页从外面踢,
 * 这里从**帧内**就地自愈 —— 二者各自成立、互不托底。
 *
 * 行为(全部有界,杜绝重载风暴):
 *   1) JiufaSim 已就位且形态正确 → 本文件零副作用,立即退出。
 *   2) JiufaSim 缺位 → 先给 /kugou/* 与 /platform/* 装 fetch 桩(应答
 *      {code:-1} 的失败 JSON),掐断对真实后端的请求泄漏;随后进入有界自愈:
 *        · 嵌入形态:轮询等父页 RoundEngine 出现(恢复竞态的典型收敛点),
 *          出现即重载本帧(重载后装载器会直取父页引擎);
 *        · 等待超时 / 独立形态:直接重载重试(sim-engine 或引擎脚本的
 *          瞬断由重载重取)。
 *   3) JiufaSim 就位但 embedded=false 而父页明明有 RoundEngine(误装独立
 *      引擎)→ 有界重载纠形态。
 *   重载配额:账本首选 sessionStorage(落账回读校验),站点数据被禁时退
 *   window.name(同帧跨导航存续,全仓无其他消费方),两介质皆不可写则放弃
 *   自愈 —— 任何环境 10 分钟内至多 3 次(与 sim-engine 2.9.4 卡局看门狗同一
 *   节制哲学、独立记账键)。配额按 10 分钟滑窗翻新、**不随导航清零**(账本
 *   跨本帧导航存续是防风暴的关键);超额即停手,把终态交给父页遮罩的失败
 *   提示 —— 用户点重试仍可获得父页看门狗的整轮补导航(12s/30s/60s 三踢)。
 *
 * 本文件为未混淆源码;构建器(build-deploy.mjs)按 LIGHT_JS 轻压缩处理
 * (与 jf-fix.js 同档:守卫类垫片深度混淆有破坏 this 绑定 / 时序的前科)。
 */
(function () {
  'use strict';

  /* ── 0. 快乐路径零副作用:sim-engine 已同步就绪即退场 ────────────────── */
  var sim = window.JiufaSim || null;

  var parentEngineReadable = function () {
    try {
      return !!(window.parent && window.parent !== window && window.parent.RoundEngine);
    } catch (e) { return false; }          // 跨源父页:不可读,按独立形态对待
  };
  var isFramed = (function () {
    try { return window.parent && window.parent !== window; }
    catch (e) { return true; }             // 读 parent 都抛 → 必在(跨源)帧里
  })();

  if (sim && (sim.embedded || !isFramed)) return;   // 形态正确(嵌入共享 / 顶层独立):不插手

  /* ── 1. 有界重载记账(10 分钟窗内至多 3 次) ──────────────────────────────
     账本首选 sessionStorage;**站点数据被整体禁用**的浏览器里 getItem/setItem
     会抛(jf-fix 只兜底了 localStorage)—— 若账本恒读空,配额形同虚设,引擎
     持续失败时会退化成无限重载。故落账后回读校验,存不进就退回 window.name
     (同帧跨导航天然存续;全仓 grep 实证 window.name 无任何其他消费方,
     jiufa/js 原版 bundle / react / polyfill / jf-fix / sim-* / app.js 均为 0 处,
     可安全独占)。两个介质都失效的环境(理论上不存在)按配额已尽处理 —— 宁可
     不自愈,也绝不无限重载。 */
  var RELOAD_KEY = 'jfboot:reloads';
  var NAME_MARK = 'jfboot:';
  var RELOAD_WIN_MS = 10 * 60 * 1000;
  var RELOAD_MAX = 3;
  function ledgerRead() {
    try {
      var raw = sessionStorage.getItem(RELOAD_KEY);
      if (raw != null) return JSON.parse(raw);
    } catch (e) {}
    try {
      var n = String(window.name || '');
      if (n.indexOf(NAME_MARK) === 0) return JSON.parse(n.slice(NAME_MARK.length));
    } catch (e) {}
    return [];
  }
  function ledgerWrite(arr) {
    var payload = JSON.stringify(arr);
    try {
      sessionStorage.setItem(RELOAD_KEY, payload);
      if (sessionStorage.getItem(RELOAD_KEY) === payload) return true;   // 回读校验:静默失败也算失败
    } catch (e) {}
    try { window.name = NAME_MARK + payload; return true; } catch (e) {}
    return false;
  }
  function recentReloads() {
    var now = Date.now();
    return ledgerRead().filter(function (t) { return typeof t === 'number' && now - t < RELOAD_WIN_MS; });
  }
  function reloadBudgetLeft() {
    return RELOAD_MAX - recentReloads().length;
  }
  function reloadNow(reason) {
    var recent = recentReloads();
    if (recent.length >= RELOAD_MAX) {
      console.warn('[jf-boot] 自愈重载已达配额(10 分钟 ' + RELOAD_MAX + ' 次),停手交给父页遮罩重试。原因:' + reason);
      return;
    }
    recent.push(Date.now());
    if (!ledgerWrite(recent)) {
      // 账本两个介质都写不进:无法保证有界 → 放弃本次自愈(父页遮罩兜底),绝不冒无限重载的险
      console.warn('[jf-boot] 重载账本不可写(sessionStorage 与 window.name 均失效),放弃自愈交给父页遮罩。原因:' + reason);
      return;
    }
    console.warn('[jf-boot] 就地重载自愈(' + reason + ')');
    try { window.location.reload(); } catch (e) {}
  }

  /* ── 2. 误装形态纠偏:JiufaSim 在、但独立引擎跑进了嵌入语境 ─────────────
     典型来源是**会话恢复竞态**:浏览器按子帧会话历史先把本帧导航回来,父页
     app.js 还在解析 —— 本文件同步执行的瞬间父页 RoundEngine 往往**还没出现**,
     所以不能同步判死,必须轮询等它落地(≤10s),落地即按配额重载改挂共享引擎。
     10s 内始终没有(第三方页面 iframe 嵌入 /jiufa/ 之类)→ 独立引擎本就是该
     场景的设计兜底,保持现场、游戏照玩。父页(观测台)看门狗也会纠(30s 起步
     盲踢);帧内这条腿更快,配额同一记账,两腿合计仍 ≤3 次/10 分钟,不会叠成风暴。 */
  if (sim && !sim.embedded && isFramed) {
    var formWaited = 0;
    var formT = setInterval(function () {
      formWaited += 1000;
      try {
        if (!window.JiufaSim || window.JiufaSim.embedded) { clearInterval(formT); return; }
      } catch (e) {}
      if (parentEngineReadable()) {
        clearInterval(formT);
        reloadNow('嵌入语境误装独立引擎,父页引擎已就绪 → 重载改挂共享引擎');
      } else if (formWaited >= 10000) {
        clearInterval(formT);   // 父页确无引擎(第三方嵌入):独立引擎即正解,保持现场
      }
    }, 1000);
    return;
  }

  /* ── 3. JiufaSim 缺位:先止血(fetch 桩),再有界自愈 ─────────────────── */
  console.error('[jf-boot] sim-engine 未就位(本体加载失败或回合引擎缺位)—— 已装 fetch 桩止血,进入有界自愈');

  // 3a. fetch 桩:没有拦截层时,业务 bundle 的游戏接口请求会直打真实后端
  //     (实测 405 风暴)。桩只接管游戏接口路径,其余请求(图片/CDN)原样放行。
  var nativeFetch = window.fetch ? window.fetch.bind(window) : null;
  if (nativeFetch) {
    window.fetch = function (input, init) {
      var url = '';
      try { url = typeof input === 'string' ? input : (input && input.url) || ''; } catch (e) {}
      var path = String(url).replace(/^[a-z]+:\/\/[^/]+/i, '');
      if (path.indexOf('/kugou/') === 0 || path.indexOf('/platform/') === 0) {
        return Promise.resolve(new Response(
          JSON.stringify({ code: -1, message: '模拟游戏引擎装载失败,正在自动重试' }),
          { status: 200, headers: { 'content-type': 'application/json; charset=utf-8' } }));
      }
      return nativeFetch(input, init);
    };
  }

  // 3b. 有界自愈:嵌入形态优先等父页引擎出现(恢复竞态的收敛点),
  //     每 1s 探一次、至多等 8s;等到或超时即按配额重载。
  //     独立形态(或父页不可读)没有可等的对象,4s 后直接按配额重载重试。
  var budget = reloadBudgetLeft();
  if (budget <= 0) {
    console.warn('[jf-boot] 自愈配额已尽,保持现场;父页遮罩将给出可点击的失败提示');
    return;
  }
  if (isFramed && !parentEngineReadable()) {
    var waited = 0;
    var t = setInterval(function () {
      waited += 1000;
      if (parentEngineReadable()) {
        clearInterval(t);
        reloadNow('父页回合引擎已就绪,重载改挂共享引擎');
      } else if (waited >= 8000) {
        clearInterval(t);
        reloadNow('等待父页引擎超时,重载重试(独立引擎兜底)');
      }
    }, 1000);
  } else {
    setTimeout(function () { reloadNow('sim-engine 未就位,重载重试'); }, 4000);
  }
})();
