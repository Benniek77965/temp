#!/usr/bin/env bash
# ==============================================================================
# maxx-diag.sh — 九法观测台「前端卡顿 / fleet 500 / live-rooms 超时」一键诊断
# ------------------------------------------------------------------------------
# 只读采集，不改配置、不重启任何服务、不写业务数据。
#
#   sudo bash maxx-diag.sh                    # 标准模式（约 4 分钟）
#   sudo bash maxx-diag.sh --long             # 加跑 35 分钟缓存踩踏周期性测试
#   sudo bash maxx-diag.sh --cookie 'jf_sess=xxx'   # 带上浏览器会话，测真实 live-rooms
#   sudo bash maxx-diag.sh --dir /opt/maxxiang      # 手动指定部署目录
#
# 结果写到 ./maxx-diag-<时间戳>.txt，直接把该文件内容贴回即可。
# 口令/票据/密码类字段已在输出中脱敏。
# ==============================================================================
set -uo pipefail   # 刻意不加 -e：单项探针失败要继续跑完其余项

VERSION="1.0"
LONG=0; COOKIE=""; INSTALL_DIR="${MAXX_DIR:-}"
while [ $# -gt 0 ]; do
  case "$1" in
    --long)   LONG=1 ;;
    --cookie) COOKIE="${2:?--cookie 需要参数}"; shift ;;
    --dir)    INSTALL_DIR="${2:?--dir 需要参数}"; shift ;;
    -h|--help) sed -n '2,17p' "$0"; exit 0 ;;
    *) echo "未知参数：$1（-h 看用法）" >&2; exit 2 ;;
  esac
  shift
done

TS="$(date +%Y%m%d-%H%M%S)"
OUT="$(pwd)/maxx-diag-${TS}.txt"
exec > >(tee "$OUT") 2>&1

hr(){ printf '\n%s\n' "────────────────────────────────────────────────────────────────"; }
sec(){ hr; printf '## %s\n' "$*"; hr; }
note(){ printf '  » %s\n' "$*"; }
have(){ command -v "$1" >/dev/null 2>&1; }
# 脱敏：把 =xxx 形式的敏感值抹掉
redact(){ sed -E 's/(PASSWORD|PASSWD|TICKET|SECRET|TOKEN|_KEY|HASH)=[^[:space:]]*/\1=<REDACTED>/gI'; }

printf '九法观测台诊断报告  v%s\n生成时间：%s\n主机：%s\n' \
       "$VERSION" "$(date -Is)" "$(hostname 2>/dev/null || echo '?')"

# ── 0. 定位部署 ───────────────────────────────────────────────────────────────
sec "S0  部署拓扑"

if [ -z "$INSTALL_DIR" ] && [ -f /etc/maxxiang-deploy.conf ]; then
  . /etc/maxxiang-deploy.conf 2>/dev/null || true
fi
[ -z "${INSTALL_DIR:-}" ] && [ -d /opt/maxxiang ] && INSTALL_DIR=/opt/maxxiang
if [ -z "${INSTALL_DIR:-}" ] || [ ! -d "$INSTALL_DIR/backend_async/deploy" ]; then
  echo "!! 未找到部署目录。请用 --dir /你的/安装路径 重跑。"
  echo "   （安装路径下应存在 backend_async/deploy/docker-compose.yml）"
  exit 1
fi
DEPLOY_DIR="$INSTALL_DIR/backend_async/deploy"
ENV_FILE="$DEPLOY_DIR/.env"
STATE_FILE="$DEPLOY_DIR/.deploy-state"

if docker compose version >/dev/null 2>&1; then COMPOSE=(docker compose)
elif have docker-compose; then COMPOSE=(docker-compose)
else echo "!! 未找到 docker compose"; exit 1; fi
dc(){ ( cd "$DEPLOY_DIR" && "${COMPOSE[@]}" "$@" ); }

WEB_PORT=5173; WORKER_REPLICAS="?"
[ -f "$STATE_FILE" ] && . "$STATE_FILE" 2>/dev/null || true
WEB_PORT="${CFG_WEB_PORT:-5173}"

# envget  : 取值并剥掉行尾注释（用于普通参数）
# envraw  : 取原始值，只去首尾空白（用于口令 —— 口令里可能含 #，绝不能按注释剥）
envget(){ grep -E "^[[:space:]]*$1=" "$ENV_FILE" 2>/dev/null | tail -n1 | cut -d= -f2- \
          | sed -e 's/[[:space:]]\+#.*$//' -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//'; }
envraw(){ grep -E "^[[:space:]]*$1=" "$ENV_FILE" 2>/dev/null | tail -n1 | cut -d= -f2- \
          | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//'; }
PG_USER="$(envget POSTGRES_USER)"; PG_USER="${PG_USER:-star}"
PG_DB="$(envget POSTGRES_DB)";     PG_DB="${PG_DB:-spelltamer}"
ADMIN_PW="$(envraw STA_ADMIN_PASSWORD)"; [ -n "$ADMIN_PW" ] || ADMIN_PW="$(envraw STA_ADMIN_PASSWORD_HASH)"
BASE="http://127.0.0.1:${WEB_PORT}"

echo "安装目录        : $INSTALL_DIR"
echo "compose 命令    : ${COMPOSE[*]}"
echo "web 端口        : $WEB_PORT"
echo "期望 worker 副本: ${WORKER_REPLICAS:-?}"
echo "PG 用户/库      : $PG_USER / $PG_DB"
echo "管理后台        : $([ -n "$ADMIN_PW" ] && echo '已启用（.env 有口令 / 散列；S3 走服务器签发的一次性票据登录）' || echo '!! 未启用，S3 会跳过')"
echo

echo "--- docker compose ps ---"
dc ps 2>&1 | head -40

CID_REDIS="$(dc ps -q redis 2>/dev/null | head -n1)"
CID_PG="$(dc ps -q postgres 2>/dev/null | head -n1)"
CID_WEB="$(dc ps -q web 2>/dev/null | head -n1)"
N_WORKER="$(dc ps -q worker 2>/dev/null | wc -l | tr -d ' ')"
echo
echo "容器定位：redis=${CID_REDIS:0:12} postgres=${CID_PG:0:12} web=${CID_WEB:0:12} worker运行中=${N_WORKER}"

rcli(){ [ -n "$CID_REDIS" ] && docker exec "$CID_REDIS" redis-cli "$@" </dev/null 2>&1 || echo "(redis 容器不可用)"; }
psqlq(){ [ -n "$CID_PG" ] && docker exec "$CID_PG" psql -U "$PG_USER" -d "$PG_DB" -qAX -c "$1" </dev/null 2>&1 || echo "(pg 容器不可用)"; }

WEB_IP=""
[ -n "$CID_WEB" ] && WEB_IP="$(docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}} {{end}}' "$CID_WEB" 2>/dev/null | awk '{print $1}')"
echo "web 容器 IP     : ${WEB_IP:-未取到}"

echo
echo "--- 关键运行参数（.env，脱敏）---"
grep -E '^\s*(STA_REDIS_MAX_CONN|STA_REDIS_MAX_CONNECTIONS|STA_WEB_POOL_TIMEOUT|STA_REDIS_POOL_TIMEOUT|STA_PG_POOL_MAX|STA_PG_POOL_MIN|STA_WORKER_CONCURRENCY|STA_USERDB_HOST|STA_USERDB_PORT|STA_USERDB_POOL_MAX|STA_USERDB_QUERY_TIMEOUT_S|STA_STARMETA_CONN_LIMIT|STA_USER_SIGNAL_SCORING|STA_LOG_LEVEL)=' \
  "$ENV_FILE" 2>/dev/null | redact
echo "  （上面没列出的项 = 走代码默认：redis 池 256 / web 池等待 5.0s / starmeta 并发 64）"

# ── 1. 事件循环基线探针 ───────────────────────────────────────────────────────
sec "S1  事件循环基线：/api/version（零 Redis、零 PG、零 MySQL）"
note "判据：p50 若 >200ms，说明 web 单进程事件循环被占死 —— 这是 H1 的直接证据。"
CURLW='%{http_code} %{time_connect} %{time_starttransfer} %{time_total}\n'
echo "code  connect  ttfb    total"
for i in $(seq 1 20); do
  curl -s -o /dev/null --max-time 20 -w "$CURLW" "$BASE/api/version"
  sleep 0.5
done | tee /tmp/_mx_ver.txt | awk '{printf "%-5s %-8s %-7s %s\n",$1,$2,$3,$4}'
echo "--- 汇总 ---"
# 用 sort 求分位，避免依赖 gawk 的 asort（Debian 默认是 mawk）
awk '{print $4+0}' /tmp/_mx_ver.txt | sort -n > /tmp/_mx_ver_s.txt
awk 'NR==FNR{a[FNR]=$1;n=FNR;s+=$1;next} END{
  if(n==0){print "无样本"; exit}
  p50=a[int(n*0.5)>0?int(n*0.5):1]; p90=a[int(n*0.9)>0?int(n*0.9):1];
  printf "n=%d  p50=%.3fs  p90=%.3fs  max=%.3fs  mean=%.3fs\n", n, p50, p90, a[n], s/n
}' /tmp/_mx_ver_s.txt /dev/null

# ── 2. Redis 连接池占用 ───────────────────────────────────────────────────────
sec "S2  Redis 连接池占用（判 H1：池打满）"
note "判据：web 容器持有的连接数若逼近 256，或 blocked_clients>0，H1 坐实。"
echo "--- INFO clients / stats / memory ---"
rcli info clients | grep -Ei 'connected_clients|blocked_clients|maxclients|cluster_connections'
rcli info stats   | grep -Ei 'rejected_connections|total_connections_received|expired_keys|keyspace_'
rcli info memory  | grep -Ei 'used_memory_human|used_memory_peak_human|maxmemory_human|maxmemory_policy|mem_fragmentation_ratio'
echo "dbsize = $(rcli dbsize)"
echo
echo "--- 各来源 IP 的连接数（关键：web 容器占了多少）---"
rcli client list 2>/dev/null | sed -E 's/^.*addr=([0-9.]+):[0-9]+.*$/\1/' | sort | uniq -c | sort -rn | head -15
[ -n "$WEB_IP" ] && echo "  ↑ 其中 web 容器 IP = $WEB_IP（池上限默认 256）"
echo
echo "--- 按当前命令分组（cmd=subscribe 的条数 = SSE 占用的长连接数）---"
rcli client list 2>/dev/null | sed -E 's/^.*[[:space:]]cmd=([a-zA-Z|_-]+).*$/\1/' | sort | uniq -c | sort -rn | head -12
echo "  ↑ subscribe 条数若与在线观众数同量级，说明 SSE 正在蚕食那 256 条池连接"
echo
echo "--- 60 秒逐秒采样：connected / blocked / web持有 ---"
echo "time      connected blocked web_held"
for i in $(seq 1 60); do
  CL="$(rcli info clients 2>/dev/null)"
  C="$(echo "$CL" | awk -F: '/^connected_clients/{gsub(/\r/,"");print $2}')"
  B="$(echo "$CL" | awk -F: '/^blocked_clients/{gsub(/\r/,"");print $2}')"
  W="-"
  [ -n "$WEB_IP" ] && W="$(rcli client list 2>/dev/null | grep -c "addr=${WEB_IP}:")"
  printf '%s  %-9s %-7s %s\n' "$(date +%T)" "${C:-?}" "${B:-?}" "$W"
  sleep 1
done
echo
echo "--- slowlog（最近 20 条）---"
rcli slowlog get 20 | head -60
echo "--- 延迟直方（5 秒）---"
timeout 6 docker exec "$CID_REDIS" redis-cli --latency -i 5 2>&1 | tail -3 || echo "(跳过)"

# ── 3. 判决实验：fleet vs overview 并发对拍 ───────────────────────────────────
sec "S3  判决实验：管理接口 fleet 与 overview 同拍对比"
note "两端点唯一结构差异 = overview 每段被 contextlib.suppress 包住、fleet 裸奔。"
note "判据 A：fleet 耗时稳定落在 5.0s 附近后 500  → web_pool_timeout 到点，H1 确诊"
note "判据 B：fleet 秒回 500（<0.2s）             → fleet() 内类型转换炸了，看 S4"
note "判据 C：fleet 500 的同拍 overview 字段变少   → Redis 间歇不可用铁证"

if [ -z "$ADMIN_PW" ]; then
  echo "!! .env 里没有 STA_ADMIN_PASSWORD / STA_ADMIN_PASSWORD_HASH（管理后台未启用），跳过本节。"
else
  # 5.3.0：管理台登录每次都要过人机验证（脚本过不了），且入口路径可配 ——
  # 改为在 web 容器内签发一次性票据（签名密钥取自容器环境）再换会话；全程只登录一次，复用 token。
  ADM_PATH="$(dc exec -T web python -m app.admin_auth path 2>/dev/null | tr -d '\r' | tail -n1)"
  case "$ADM_PATH" in /*) ;; *) ADM_PATH="/admin-xdd";; esac
  ADM_API="/api${ADM_PATH}"
  TICKET="$(dc exec -T web python -m app.admin_auth ticket 2>/dev/null | tr -d '\r' | tail -n1)"
  LOGIN="$(curl -s --max-time 20 -X POST "$BASE$ADM_API/login/ticket" \
            -H 'Content-Type: application/json' \
            --data-binary "$(printf '{"ticket":"%s"}' "$TICKET")" 2>&1)"
  TOK="$(printf '%s' "$LOGIN" | sed -n 's/.*"token"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')"
  if [ -z "$TOK" ]; then
    echo "!! 管理台登录失败，返回："; printf '%s\n' "$LOGIN" | head -c 400 | redact; echo
    echo "   （若是 rate_limited，等 1 分钟重跑；若是 bad_ticket / 空返回，确认 web 容器在运行且已是 5.3.0+ 镜像）"
  else
    echo "管理台登录成功（token 已脱敏），开始 30 轮对拍。"
    echo
    echo "round  fleet_code fleet_time | overview_code overview_time | overview字段数"
    for i in $(seq 1 30); do
      # 真并发：两发同时出去（池竞争只有在并发下才暴露），结果各自落盘再读
      curl -s -o /tmp/_mx_fleet.json --max-time 30 -w '%{http_code} %{time_total}' \
           -H "X-Admin-Session: $TOK" "$BASE$ADM_API/fleet"    > /tmp/_mx_f.w 2>&1 &
      FP=$!
      curl -s -o /tmp/_mx_ov.json    --max-time 30 -w '%{http_code} %{time_total}' \
           -H "X-Admin-Session: $TOK" "$BASE$ADM_API/overview" > /tmp/_mx_o.w 2>&1 &
      OP=$!
      wait $FP $OP 2>/dev/null
      F="$(cat /tmp/_mx_f.w 2>/dev/null)"; O="$(cat /tmp/_mx_o.w 2>/dev/null)"
      # overview 顶层字段名（suppress 吞掉的段会消失）
      KEYS="$(sed -E 's/\{/\n{/g' /tmp/_mx_ov.json 2>/dev/null | grep -oE '"(ok|now_ms|admin_version|rooms|pending|queue_depth|retention_last|discovery_last|ingest|target_rev)"' | sort -u | tr -d '"' | tr '\n' ',' )"
      NK="$(printf '%s' "$KEYS" | tr ',' '\n' | grep -c . )"
      printf '%-6s %-10s %-10s | %-13s %-13s | %s  [%s]\n' "$i" "${F%% *}" "${F##* }" "${O%% *}" "${O##* }" "$NK" "$KEYS"
      # 只有非 200 时才留证据
      case "${F%% *}" in 200) ;; *) echo "       fleet 响应体：$(head -c 300 /tmp/_mx_fleet.json | tr -d '\n')" ;; esac
      sleep 2
    done
    echo
    echo "--- 参考：overview 完整字段应为 10 个 ---"
    echo "    ok,now_ms,admin_version,rooms,pending,queue_depth,retention_last,discovery_last,ingest,target_rev"
    echo "    少于 10 个 = 该字段所在段的 Redis/PG 调用抛异常被 suppress 吞掉了"
  fi
fi

# ── 4. 心跳键内容（判 fleet 秒回 500 的备选根因）─────────────────────────────
sec "S4  配置中枢心跳键 cfg:hb:*（判 fleet() 内类型转换异常）"
note "判据：boot_rev/applied_rev/pid/ts_ms/retry_pending 任一非纯数字 → int() 抛 ValueError → 500"
note "另：心跳键个数应 ≈ worker副本数 + web，即 ${WORKER_REPLICAS:-?}+1"
HBK="$(rcli --scan --pattern 'cfg:hb:*' 2>/dev/null | tr -d '\r' | grep -v '^$')"
CNT=0
for k in $HBK; do
  CNT=$((CNT+1))
  echo "== $k"
  rcli hgetall "$k" | paste - - | sed 's/^/    /'
done
echo "心跳键总数 = $CNT"

# ── 5. 名录 / 冷房事实 ────────────────────────────────────────────────────────
sec "S5  名录与冷房事实（判 H3：curated-idle 降级导致「出怪序列卡住」）"
echo "rooms:active   (SCARD) = $(rcli scard rooms:active)"
echo "rooms:discovered (HLEN)= $(rcli hlen rooms:discovered)"
echo "rooms:cold     (HLEN)  = $(rcli hlen rooms:cold)"
echo "rooms:pending  (HLEN)  = $(rcli hlen rooms:pending)"
echo "sched          (ZCARD) = $(rcli zcard sched)"
echo "rooms:lastaccess(ZCARD)= $(rcli zcard rooms:lastaccess)"
echo "hist:lastok    (ZCARD) = $(rcli zcard hist:lastok)"
note "前端可见房 = active − discovered。若「可见房」里大量落在 rooms:cold，"
note "它们每 histmode.interval_s（默认 900s）才更新一次 → 前端看就是卡住不动。"
echo
echo "--- 冷房样本（前 30 个）---"
rcli hkeys rooms:cold 2>/dev/null | head -30 | tr '\n' ' '; echo
echo
echo "--- hist 轮询最老成功时刻（越老越危险）---"
rcli zrange hist:lastok 0 4 WITHSCORES | paste - -
echo "  （now_ms 参考：$(date +%s000)）"
echo
echo "--- 会话遥测键规模（sig:*，占池/占内存的另一来源）---"
echo "sig:z (ZCARD) = $(rcli zcard sig:z)"

# ── 6. PostgreSQL 现场 ───────────────────────────────────────────────────────
sec "S6  PostgreSQL 现场"
echo "--- psql 连通性自检 ---"
psqlq "SELECT version();" | head -2
echo
echo "--- 连接状态分布 ---"
psqlq "SELECT state, count(*) FROM pg_stat_activity GROUP BY state ORDER BY 2 DESC;"
echo
echo "--- 最长的 10 条在跑的查询 ---"
psqlq "SELECT round(extract(epoch FROM now()-query_start)::numeric,2) AS dur_s, state, wait_event_type, left(regexp_replace(query,'\s+',' ','g'),90) AS q
       FROM pg_stat_activity WHERE state<>'idle' AND pid<>pg_backend_pid()
       ORDER BY 1 DESC NULLS LAST LIMIT 10;"
echo
echo "--- 关键索引是否 VALID（CONCURRENTLY 建到一半会留 INVALID，规划器不用它）---"
psqlq "SELECT c.relname AS idx, i.indisvalid, i.indisready, pg_size_pretty(pg_relation_size(c.oid)) AS sz
       FROM pg_class c JOIN pg_index i ON i.indexrelid=c.oid
       WHERE c.relname IN ('idx_pred_pending','idx_pred_round','idx_rounds_round','predictions_pkey','rounds_pkey')
       ORDER BY 1;"
note "idx_pred_pending 若 indisvalid=f 或整行缺失 → /api/rooms/*/prediction 走全量扫描（慢 76 倍）"
echo
echo "--- 表体积与死元组 ---"
psqlq "SELECT relname, n_live_tup, n_dead_tup,
              CASE WHEN n_live_tup>0 THEN round(100.0*n_dead_tup/n_live_tup,1) ELSE 0 END AS dead_pct,
              last_autovacuum, last_autoanalyze
       FROM pg_stat_user_tables WHERE relname IN ('rounds','predictions','predictor_state')
       ORDER BY n_dead_tup DESC;"
psqlq "SELECT relname, pg_size_pretty(pg_total_relation_size(relid)) AS total
       FROM pg_stat_user_tables ORDER BY pg_total_relation_size(relid) DESC LIMIT 8;"
echo
echo "--- 热路径 SQL 实测（EXPLAIN ANALYZE，取一个真实房号）---"
SAMPLE_ROOM="$(rcli hkeys rooms:discovered 2>/dev/null | head -n1 | tr -d '\r')"
if [ -n "$SAMPLE_ROOM" ]; then
  echo "样本房号：$SAMPLE_ROOM"
  psqlq "EXPLAIN (ANALYZE, BUFFERS) SELECT * FROM predictions WHERE room_id='$SAMPLE_ROOM' AND actual_custom_id IS NULL ORDER BY round_id DESC LIMIT 1;"
  psqlq "EXPLAIN (ANALYZE, BUFFERS) SELECT * FROM rounds WHERE room_id='$SAMPLE_ROOM' ORDER BY round_id DESC LIMIT 1;"
fi

# ── 7. 外部 MySQL 用户库探针（H0）────────────────────────────────────────────
sec "S7  外部 MySQL 用户库连通性（判 H0：guard 卡住整个事件循环）"
note "登录系统开着时，每个 /api/* 都要过 userauth.guard()；池只有 8 条、超时 15s。"
note "12 个公网入口里只要有几个变慢，单进程 web 就会整体僵住。"
UDB_HOST="$(envget STA_USERDB_HOST)"; UDB_PORT="$(envget STA_USERDB_PORT)"; UDB_PORT="${UDB_PORT:-3306}"
if [ -z "$UDB_HOST" ]; then
  echo "STA_USERDB_HOST 未配置 → 登录系统关闭，本节不适用。"
else
  echo "配置的入口（端口 $UDB_PORT）："
  printf '%s\n' "$UDB_HOST" | tr ',' '\n' | sed -E 's/[[:space:]]//g; s/\*[0-9]+$//' | grep -v '^$' | nl
  echo
  echo "--- 从 web 容器内逐个测 TCP 连通与握手耗时 ---"
  printf '%-20s %-10s %s\n' "endpoint" "result" "seconds"
  while IFS= read -r ep; do
    [ -z "$ep" ] && continue
    H="${ep%%:*}"; P="${ep##*:}"; [ "$H" = "$P" ] && P="$UDB_PORT"
    T0=$(date +%s.%N)
    if docker exec "$CID_WEB" timeout 5 python3 -c "
import socket,sys
s=socket.socket(); s.settimeout(5)
try:
    s.connect(('$H',int('$P'))); s.recv(64); print('ok')
except Exception as e:
    print('FAIL:'+type(e).__name__)
finally:
    s.close()
" </dev/null 2>/dev/null | grep -q ok; then R="ok"; else R="FAIL"; fi
    T1=$(date +%s.%N)
    printf '%-20s %-10s %s\n' "$H:$P" "$R" "$(awk -v a="$T0" -v b="$T1" 'BEGIN{printf "%.3f",b-a}')"
  done <<< "$(printf '%s\n' "$UDB_HOST" | tr ',' '\n' | sed -E 's/[[:space:]]//g; s/\*[0-9]+$//' | grep -v '^$')"
fi

# ── 8. 容器资源 ──────────────────────────────────────────────────────────────
sec "S8  容器资源占用（web 若长期贴近 100% CPU = 单事件循环打满）"
docker stats --no-stream --format 'table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.MemPerc}}\t{{.NetIO}}' 2>&1 | head -25
echo
echo "--- 宿主机负载 / 内存 ---"
uptime
free -h 2>/dev/null || true
echo
echo "--- 宿主 CPU 核数 ---"
nproc 2>/dev/null || true

# ── 9. 日志摘要 ──────────────────────────────────────────────────────────────
sec "S9  日志摘要（近 30 分钟的错误 / 告警）"
echo "--- web：异常与 500 ---"
dc logs --since 30m web 2>&1 | grep -Ei 'Traceback|Error|Exception|MaxConnections|No connection available|Timeout|500 Internal' | tail -40 | redact
echo
echo "--- web：完整尾部 60 行 ---"
dc logs --tail 60 web 2>&1 | tail -60 | redact
echo
echo "--- worker：告警 ---"
dc logs --since 30m worker 2>&1 | grep -E '⚠|WARNING|ERROR|算力不足|连接饥饿|钟差|window_lost' | tail -30 | redact
echo
echo "--- redis / postgres 尾部 ---"
dc logs --tail 20 redis 2>&1 | tail -20
dc logs --tail 20 postgres 2>&1 | grep -Ei 'error|fatal|warning|checkpoint|autovacuum' | tail -20

# ── 10. 真实前端端点（可选，需 cookie）───────────────────────────────────────
sec "S10 前端端点实测"
echo "--- 不带会话（应为 401，但仍能量出 guard + 中间件的耗时）---"
for p in "/api/live-rooms" "/api/crawler/status"; do
  printf '%-28s ' "$p"
  curl -s -o /dev/null --max-time 30 -w "$CURLW" "$BASE$p" -H 'X-JF-Auth: 1'
done
if [ -n "$COOKIE" ]; then
  echo
  echo "--- 带会话：live-rooms 连打 12 次（每 5 秒）---"
  echo "code  connect  ttfb    total"
  for i in $(seq 1 12); do
    curl -s -o /tmp/_mx_lr.json --max-time 60 -w "$CURLW" \
      -H "Cookie: $COOKIE" -H 'X-JF-Auth: 1' "$BASE/api/live-rooms"
    sleep 5
  done
  echo "最后一次返回的房数：$(grep -o '"roomId"' /tmp/_mx_lr.json 2>/dev/null | wc -l)"
  echo "响应体前 300 字节：$(head -c 300 /tmp/_mx_lr.json 2>/dev/null | tr -d '\n')"
  echo
  echo "--- /api/crawler/status 全文（含 health.monitoredRooms / suggestReplicas / histMode）---"
  curl -s --max-time 30 -H "Cookie: $COOKIE" -H 'X-JF-Auth: 1' "$BASE/api/crawler/status" | head -c 4000
  echo
else
  echo
  echo "（未提供 --cookie，跳过带会话实测。"
  echo "  取法：浏览器 F12 → Network → 任一 /api/ 请求 → Request Headers → 复制整行 Cookie 值）"
fi

# ── 11. 长跑：缓存踩踏周期性 ─────────────────────────────────────────────────
if [ "$LONG" -eq 1 ]; then
  sec "S11 长跑：StarMeta profile 缓存踩踏检测（35 分钟，覆盖 3 个 600s 周期）"
  note "判据：耗时尖峰若每 ~600 秒规律出现一次 → 缓存同时过期（H2）确诊。"
  echo "time      code   total"
  for i in $(seq 1 105); do
    printf '%s  ' "$(date +%T)"
    if [ -n "$COOKIE" ]; then
      curl -s -o /dev/null --max-time 60 -w '%{http_code}  %{time_total}\n' \
        -H "Cookie: $COOKIE" -H 'X-JF-Auth: 1' "$BASE/api/live-rooms"
    else
      curl -s -o /dev/null --max-time 60 -w '%{http_code}  %{time_total}\n' "$BASE/api/version"
    fi
    sleep 20
  done
fi

hr
echo "诊断完成。报告已保存到："
echo "  $OUT"
echo
echo "把该文件内容整份贴回即可（口令类字段已脱敏；若你自行确认还有敏感内容，删掉再发）。"
hr
