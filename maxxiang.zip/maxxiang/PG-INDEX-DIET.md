# PG-INDEX-DIET.md —— PostgreSQL 高 CPU 治理（4.9.5）

> **5.3.0 起后台入口可配**:页面在 `/{入口}`、管理接口在 `/api/{入口}/*`,`{入口}` = `config.yaml` 的 `admin.path`(默认 `admin-xdd`,`.env` 的 `STA_ADMIN_PATH` 可覆盖)。本文中的 `{入口}` 均指它;旧地址 `/admin`、`/admin.html`、`/api/admin/*` 按不存在的路径应答。唯一例外:外部发卡接口 `POST /api/admin/jfvip/cards/issue` 是机器契约,地址恒定。详见根 `README.md`「管理后台:入口、账号与人机验证」。

> 全文每一个数字都来自实机基准，不是估算。
> 测试环境：PostgreSQL **16.14**，项目自带 `db.SCHEMA` 原样建表，
> `rounds` 180 万行 / `predictions` 12 万行（含真实体量的 `detail` JSONB），
> 单核 · 4GB。所有 A/B 均为**同机、同数据、同一批语句**，只差被测变量。

---

## 0. 先分开两件事

| 症状 | 结论 |
|---|---|
| PG 内存占用 2GB | **不是问题，是配置**。`deploy/docker-compose.yml:93` 写着 `shared_buffers=2GB`，PG 启动即占住，与泄漏无关。 |
| PG CPU 90–100%，**间歇出现、自己恢复** | 是真问题。见下。 |

**「间歇出现、持续一段、又恢复」这个形态本身就是线索**：结构性慢查询是*恒定*
开销，不会自愈。会这样的只有**周期性批量作业**。本项目里的候选只有四个：

1. 每小时的 retention 清理（`sweep_interval_s: 3600`）及其引发的 autovacuum；
2. 反回卷 autovacuum（anti-wraparound）—— 不可跳过、扫全表全索引，最像「突然」；
3. 配置热更导致 `cfg_fp` 变化 → 全舰队命中率补算重跑；
4. 连接池饥饿（worker 副本超出 `max_connections` 账本）。

**本次改动不猜是哪一个，而是把这四个的成本一起压下去**（索引瘦身让*每一趟*
vacuum 的开销减半），同时提供 `scripts/pg_diagnose.sh` 让你在下次发作时**一击定案**。

---

## 1. 主病灶：`rounds` 上 70% 的索引字节没有任何查询在读

180 万行时的实测体积 —— **索引合计 238MB 超过了堆的 231MB**：

| 索引 | 体积 | 结论 |
|---|---:|---|
| `idx_rounds_room_draw` | **97 MB** | 砍。`draw_ms` 在全项目 WHERE/ORDER BY 中出现 **0 次** |
| `rounds_pkey` | 54 MB | 留 |
| `idx_rounds_room_start` | **54 MB** | 砍。与主键**逐字节重复** |
| `idx_rounds_room_date` | **16 MB** | 砍。唯一消费者 `day_rows()` 是死代码 |
| `idx_rounds_round` | 16 MB | 留（retention 裁剪必需） |

**取证，不是印象：**

- 全表校验 `start_ms IS DISTINCT FROM round_id` → **0 行**。两个写入点
  （`add_round` / `_build_bulk_rounds_sql`）都写死 `start_ms = rid`。
- 全表校验 `draw_ms IS DISTINCT FROM round_id + 40000` → **0 行**。
- `day_rows()` 在 `app/ scripts/ tests/ deploy-tests/` 全域 grep → **零调用点**。

### 代价（A/B 实测）

```
逐行 INSERT（复刻 add_round 路径）   2索引 24161 行/s  vs  5索引 15623 行/s  → 慢 1.55×
批量 INSERT（60 万行 × 2 轮取优）    2索引 5.74s       vs  5索引 9.24s       → 慢 1.61×
VACUUM（删 24 万行后，即 retention 之后 autovacuum 干的活）
                                     2索引 0.29s       vs  5索引 0.60s       → 慢 2.07×
索引字节                             2索引 70MB        vs  5索引 238MB       → 3.4×
```

**约 35–40% 的入库 CPU、以及一半的 VACUUM CPU，花在三个没人读的索引上。**
而 VACUUM 正是候选①②的主体 —— 这一刀直接砍在间歇性高 CPU 的成因上。

### 附带发现：DESC 索引在单调递增插入下膨胀 1.78×

`idx_rounds_room_draw` 是全库最大的索引，比内容相同的主键还大 80%。原因是它建成
`DESC`，而 `draw_ms` 随插入单调递增 → 每条新记录都落在索引**最左端**，吃不到
btree 右端快速填充（~96% 填充率）→ 恒 50/50 页分裂。

> ⚠ 这一条我第一次测错了：用 `CREATE INDEX` 建完再对比，两个方向体积一样
> （批量构建会排序后密集打包）。**必须先建索引、再增量插入**才测得出来。重测后：
>
> ```
> 同表同列同数据，索引先建好再增量插入 40 万行：
>     DESC 2741 页 (21 MB)   vs   ASC 1544 页 (12 MB)   → 膨胀 1.78×
> ```

---

## 2. 前端卡的直接元凶：`pending_prediction` 扫全房历史

`db.pending_prediction()` 是 `/api/rooms/{room}/prediction` 每次必打的第一条 SQL：

```sql
SELECT round_id, main_ids, guard_ids, detail FROM predictions
 WHERE room_id=$1 AND actual_custom_id IS NULL ORDER BY round_id DESC LIMIT 1
```

**此前没有任何索引支撑 `actual_custom_id IS NULL`**，规划器只能把该房整段历史
捞进来再筛掉 99.98%：

```
Bitmap Heap Scan on predictions
  Rows Removed by Filter: 5999
  Buffers: shared hit=1029        ← 每次调用读 ~8MB
Execution Time: 3.041 ms
```

`predictions` 单行含 `detail` JSONB，`pg_stats` 实测 `avg_width = 1156 B`。

**代价随 `retention.days` 线性增长。** `config.yaml` 里 `days: 7` ⇒ 每房约
1728×7 ≈ 12096 行 —— 当初把 retention 从 1 天调到 7 天时，这条查询的成本同步
涨了 **7 倍**，没人算过这笔账。

### 修复

```sql
CREATE INDEX CONCURRENTLY idx_pred_pending ON predictions (room_id, round_id)
  WHERE actual_custom_id IS NULL;
```

```
Index Scan Backward using idx_pred_pending
  Buffers: shared hit=2
Execution Time: 0.027 ms       ← 快 113 倍，缓冲区少 514 倍
索引体积: 16 kB                 ← 稳态每房只有 1 行未结算
```

三个刻意的取舍：

- **偏索引**：只索引未结算行，整库 16 kB，写入与 VACUUM 成本近乎为零。
- **ASC 而非 DESC**：btree 可反向扫。实测走 `Index Scan Backward`、**无 Sort 节点**，
  与 DESC 等效；而 DESC 会因单调递增插入而膨胀 1.78×（见 §1）。
  *（我上一轮方案里写的是 DESC，本轮复查时改正。）*
- **不损写入**：结算 UPDATE（`actual_custom_id` NULL→有值）**本就无法 HOT** ——
  行宽 1.2KB，页内放不下新版本。实测四组配置（含「只有主键」对照组）
  `n_tup_hot_upd` **恒为 0**；加索引前后结算耗时 0.043s vs 0.047s（噪声内）。

> 附带收益：`heal_orphan_settlements` 的 `hit IS NULL AND actual_custom_id IS NULL`
> 同样被本索引覆盖。

---

## 3. `sequence()` 的谓词打错了列

`db.sequence()` 每局每房都跑一次，是 worker 侧最频繁的 PG 读。原写法谓词打在
`start_ms`、排序却按 `round_id`，规划器只能走 `idx_rounds_room_start` 再**额外排序**：

```
现状（start_ms 谓词）: Index Scan + quicksort 116kB  → 0.929 ms
改写（round_id 谓词）: Index Scan Backward pkey，零排序 → 0.608 ms
1728 行训练序列逐行比对：差异 0 行
```

**不是等价重写，是同一个值的两个名字**（`start_ms ≡ round_id`，见 §1 取证）。
顺带让 `idx_rounds_room_start` 失去最后一个使用者。

> ⚠ 顺序要紧：**必须先改这句 SQL，再删索引**。直接删会让这条查询退化成全房扫描。
> 代码与迁移已按此顺序编排。

---

## 4. `predictions.detail` 的统计量白算

`purge_before()` 每轮清理完必跑 `ANALYZE`。而 `detail`（avg_width 1156B，被 TOAST）
从不作为谓词使用，ANALYZE 却要把采样到的 30000 行逐行解压再算 MCV/直方图：

```
ANALYZE predictions 全部列       0.260s
ANALYZE 排除 detail             0.139s      → detail 独占 ~47%
```

已改为 `ALTER TABLE predictions ALTER COLUMN detail SET STATISTICS 0`。
列照常读写，只是规划器不再为它建直方图。

---

## 5. `idx_pred_room_hit` 可以砍

它是 `(room_id, round_id DESC) WHERE hit IS NOT NULL`。稳态下几乎每行 `hit` 都非空
⇒ 近似主键副本，却因 DESC 而实测占 **827 页**（同表同行的主键仅 465 页）。

砍掉后两个使用者双双改走主键反向扫，**零退化**：

```
                     留着          砍掉
accuracy           0.146 ms  →   0.132 ms   （Index Scan Backward using predictions_pkey）
prediction_records 0.086 ms  →   0.088 ms
```

---

## 6. 我上一轮说错、本轮撤回的结论

诚实起见单列一节：

| 上轮说法 | 复查结果 |
|---|---|
| 「`jit` 未关闭是 CPU 暗耗」 | **撤回**。实测项目全部查询的计划代价最高 24159，远低于 `jit_above_cost=100000`，**JIT 根本没被触发**。不需要动这个参数。 |
| 「`idx_pred_pending` 建成 DESC」 | **改正为 ASC**。DESC 在单调递增插入下膨胀 1.78×，而 ASC 经反向扫可提供完全相同的有序性（实测无 Sort 节点）。 |
| 「DESC 索引必然膨胀」的首次测法 | **测法有误**（用 `CREATE INDEX` 批量构建，测不出增量插入行为）。重测后结论成立，但过程需要更正。 |

---

## 7. 本次改了什么

| 文件 | 改动 |
|---|---|
| `app/db.py` | SCHEMA 砍 4 个索引；新增 `idx_pred_pending`（经 CONCURRENTLY 建）；`detail SET STATISTICS 0`；`sequence()` 谓词改写；删死代码 `day_rows()`；新增 `DB.migrate_indexes()` 在线迁移，由 `migrate()` 末尾自动调用 |
| `scripts/pg_diagnose.sh` | **新增**。生产环境一键诊断，定位间歇性高 CPU 的具体成因 |
| `PG-INDEX-DIET.md` | **新增**。本文件 |

**未改动**：前端、worker、web、配置文件、部署脚本、任何测试。

### 存量库怎么升级

**不需要任何手工操作。** 重启一次 worker 或 web 即可 —— `migrate()` 末尾会自动调用
`migrate_indexes()`：

- 全部 DDL 走 `CONCURRENTLY`，**全程不阻塞读写**；
- 顺序保证安全：**先建新索引、再砍旧索引**，中间不存在「两个都没有」的窗口；
- 幂等：每步先查 `pg_index` 再动手，已是目标形态就整段空转；
- 多副本并发首启由 `pg_try_advisory_lock(770100)` 互斥，抢不到锁的直接返回；
- 会自动清理并重建上次 `CONCURRENTLY` 失败留下的 INVALID 索引；
- 全程非致命：任何失败只记账不抛错（索引是性能问题，不是正确性问题），
  结果存在 `DB.last_index_migration`。

`_IDX_TIMEOUT = 3600s`：`CONCURRENTLY` 要等所有在飞事务落幕，存量大表上可达数分钟，
池默认的 `command_timeout=30s` 必然中途砍断并留下 INVALID 索引，故显式给足。

### 验收

```bash
bash backend_async/scripts/pg_diagnose.sh      # §8 应全部 ✔
```

---

## 8. 回归验证

在真 PG 上从「与生产一致的旧库」跑到新形态：

```
迁移结果 = {'created': ['idx_pred_pending'],
            'dropped': ['idx_rounds_room_draw', 'idx_rounds_room_start',
                        'idx_rounds_room_date', 'idx_pred_room_hit'],
            'skipped': False}
幂等复跑 = {'created': [], 'dropped': [], 'skipped': False}   （0.00s）
```

迁移后 8 个 DAO 方法逐一验证：`sequence` 1728 行 / `pending_prediction` 命中 /
`accuracy` n=99 / `prediction_records` 39 条 / `history` 80 行 / `history_days` 4 天 /
`replay_gaps` / `heal_orphan_settlements` —— 全部正常。

**项目测试套与原始包对拍：**

```
原始包   495 passed, 120 skipped, 40 errors
改动包   495 passed, 120 skipped, 40 errors
FAILED 集合 diff：无差异
```

（那 40 个 error 与 2 个 failed 在原始包上同样存在，是本地环境缺少可选依赖
所致，非本次改动引入。）

打在 `rounds`/`predictions` 上的 **9 条项目查询**逐条对拍执行计划
（`oldest_round` / `has_round` / `sequence` / `history` / `history_days` /
`accuracy` 锚 / `rounds_since` / `replay_gaps` / `purge_before` 定位子查询）
—— **全部不变或略快，零退化**。

---

## 9. 还没做、留给你决定的三件事

这三处我核查出了问题但**没有改**，因为都需要你的实际规模数据才能定参数：

1. **`autovacuum_vacuum_cost_limit = 2000`**（`db.py` SCHEMA 末尾的 per-table 调参）。
   PG 默认是 200 —— 这是**10 倍的 autovacuum I/O 预算**，本身就是「准许 autovacuum
   敞开跑」的配置。当初是为 retention=1 天调的，现在 retention=7 天让表大了 7 倍。
   如果 `pg_diagnose.sh` 的 §1 确认是 autovacuum 在烧核，**先看索引瘦身后是否已经
   够用**（VACUUM 成本已减半）；仍不够再把它降到 600–1000 之间。

2. **覆盖哨兵的 N+1**：`worker.py:1212`
   `[g for g in pts if not await self.db.has_round(room, g)]`，`COV_SPAN_CAP = 200`
   —— 水位落后的房每个事件打 **200 次串行 PG 往返**。房间重新上播、worker 重启后
   会成片触发，形态上**也符合「突然出现又恢复」**。可以一条
   `WHERE round_id = ANY($2::bigint[])` 收成 1 次往返。这属于 worker 逻辑改动，
   风险高于索引，建议先看诊断结果再决定是否动。

3. **自动发现的真实房数**：`discovery.enabled: true` + 7 天 grace ⇒ 被监控的房可能
   远多于你手动添加的。所有 CPU/连接账本都是按房数线性的。
   看 `/api/discovery/status` 的 `discoveredCount`。

---
---

# 第二轮（4.9.6）—— 拿到生产诊断数据之后

4.9.5 是**盲改**（只有代码，没有生产数据）。这一轮拿到了真机 `pg_diagnose.sh`
输出与 `/api/{入口}/overview`，结论有实质变化。

## 10. 间歇性 CPU 的成因，现在可以定案了

生产数据把周期对上了：

| 证据 | 数值 | 出处 |
|---|---|---|
| retention 每小时删 | **511,097 行**，耗时 **55.571s** | `retention_last` |
| 清理周期 | 3600s | `config.yaml` |
| rounds 上次 autovacuum | **36 分钟前**（上次清理在 51 分钟前） | 诊断 §3 |
| 每趟 vacuum 要扫的索引 | **6848 MB** | 诊断 §7 |
| autovacuum 强度 | cost_limit=2000 = PG 默认的 **10 倍** | `db.py` SCHEMA |

**链条**：每小时清理删掉 51 万行 → 死元组过阈 → autovacuum 启动 →
**完整扫一遍 6.8 GB 索引**（btree bulkdelete 是全索引扫描，与死元组多少无关）→
因为 cost_limit 是默认的 10 倍，它敞开吃满一个核 → 几分钟后扫完 → 恢复正常 →
下一个小时重来。

**这就是「突然出现、持续一段、又自己恢复」。周期 ≈ 1 小时。**

其余三个候选**已排除**：

- 候选②反回卷：§4 显示 XID 用了 50.4%，离阈值还远，不是现在的成因
  （但会在未来某天触发一次很长的满核，届时是同一条链路的极端版）。
- 候选④池饥饿：§5 显示 66/400 = 16.8%，`pg_ping_ms: 11`（健康 <50ms）。排除。
- 候选③补算重跑：§1 无长跑业务 SQL。排除。

## 11. 新发现：`predictions` 的索引膨胀了 **397 倍**

诊断 §7 里最刺眼的一行：

```
predictions | 堆 82 MB | 索引 1042 MB | 合计 1124 MB      ← 索引是堆的 12.7 倍
```

而这张表只有 **62,300 行**。拆开看：

| 索引 | 实际 | 理论 | 膨胀比 |
|---|---:|---:|---:|
| `predictions_pkey` | **881 MB** | ~2.2 MB | **397×** |
| `idx_pred_round` | **160 MB** | ~2.2 MB | **72×** |

**这不是 4.9.5 造成的，也不是 4.9.5 能修的** —— `DROP INDEX` 只清掉被删的那个，
剩下两个的膨胀原样保留。

### 机制（已实测复现）

B-tree 在大量删除后**不把空间还给操作系统**：VACUUM 只把空页标记为「可在本索引
内部复用」，文件大小原地不动。堆会收缩（VACUUM 能截断尾部空页），索引不会。

```
PG16.14 同表同数据实测：
  灌 120 万行             堆 721 MB   pkey 36 MB    round索引 9544 kB
  删到 1.5 万行 + VACUUM  堆 9232 kB  pkey 36 MB    round索引 9544 kB   ← 索引纹丝不动
  REINDEX CONCURRENTLY    堆 9232 kB  pkey 480 kB   round索引 192 kB    ← 回收 98.7%
```

生产上 `predictions` 正是这个形态：它**曾经**很大（策展闸之前，或更多房在产生预测），
后来缩到 5 个房的量级（62,300 ÷ 12,096 ≈ 5.15 房），堆跟着收缩到 82 MB，索引留在原地。

### 危害不只是磁盘

**VACUUM 每一趟都要完整扫一遍索引。** 一个 881 MB 的空壳索引，就是每次
autovacuum 白读 881 MB。§3 显示 predictions 已 vacuum **98 次** —— 白读了 ~100 GB。

§6 也印证了：`predictions 堆命中率 83.60%`，是整份诊断里最差的数字。

### 修法

新增 `scripts/pg_maintenance.sh`：

```bash
bash backend_async/scripts/pg_maintenance.sh            # 只体检
bash backend_async/scripts/pg_maintenance.sh --reindex  # 执行在线重建
```

走 `REINDEX INDEX CONCURRENTLY`，**不锁表**，读写照常。预期
`predictions` 索引 **1042 MB → ~4 MB**。

`rounds_pkey` 是 5873 MB / 膨胀比 **1.75×**（滚动流水主键的稳态值），
脚本不会自动重建它（阈值设在 3 倍），但会单列出来给手动命令 —— 重建可回收
~2.5 GB，代价是耗时较长且需要等量临时空间，由你决定。

`idx_rounds_round` 973 MB / 膨胀比 **0.29** —— 健康。它索引的 `round_id` 在
8000+ 个房之间大量重复，PG13+ 的 btree 去重把它压得很紧。

## 12. 4.9.5 已经产生的效果（有生产数据佐证了）

被砍掉的 `idx_rounds_room_start` 与 `rounds_pkey` **内容逐字节相同**，膨胀历史也
相同 —— 它当时的体积就是 **~5873 MB**。加上 `idx_rounds_room_draw`（DESC，另有
1.78× 膨胀）与 `idx_rounds_room_date`，4.9.5 这一刀**至少**从每趟 vacuum 里
砍掉了 6 GB 的索引扫描，实际很可能超过 10 GB。

也就是说：你现在看到的 6848 MB，**改之前是这个数的两倍多**。

## 13. 结构性根因：98.8% 的写入量来自没人要的房

`/api/{入口}/overview`：

```
active_total: 8449   discovered: 8347   manual: 102
```

**你手动加的只有 102 个房，另外 8,347 个是自动发现塞进来的。**
`rounds` 之所以长到 9421 万行 / 13 GB，98.8% 是为这些房抓的。

所有账本都按房数线性：每小时删 51 万行、每趟 vacuum 扫 6.8 GB、13 GB 堆常驻 ——
乘数就是这 8,449。

三条路，取舍由你（**本次未改动任何相关配置**）：

1. **关掉自动发现**（`discovery.enabled: false`）：`rounds` 会在 7 天内缩到
   ~1/80，间歇性 CPU 尖峰基本消失。代价是失去「自动统计数据」这个产品能力。
2. **缩短发现房的保留**：现在发现房与手动房共用 `retention.days: 7`。
   若发现房的数据只是「顺带统计」，1 天足矣 —— 但当前代码不区分二者，
   需要改造（本次未做）。
3. **维持现状**，靠索引瘦身 + REINDEX 把单位成本压下去。

## 14. 我这一轮修正的自己的东西

同样单列一节：

| 问题 | 处置 |
|---|---|
| `pg_diagnose.sh` 只显示 `last_autoanalyze`，不显示 `last_analyze` | **已修**。这导致 `rounds` 看起来「9 天没 analyze」，实际上 `purge_before` **每小时**都显式 ANALYZE 一次（手动 ANALYZE 更新的是 `last_analyze`）。统计并不陈旧，是我的脚本在误导。 |
| `pg_diagnose.sh` 展示 `idx_scan` 却没说明那是**建库以来的累计值** | **已修**。§2 现在会打印 `stats_reset`，为空时明确提示「反映历史而非当前行为」，并建议 `pg_stat_reset()` 后隔天再看。 |
| 诊断里没有膨胀检测 —— 于是漏掉了本轮最大的发现 | **已修**。§2 增加膨胀比列与判定，新增 §9 把清理周期与 vacuum 工作量关联起来。 |
| 我曾猜测 `idx_pred_round` 被扫 2.4 亿次是因为 `predictions` 里 `room_id` 选择性极低、规划器改走单列索引 | **假设被实测推翻**。复刻生产形态（predictions 仅 5 个 distinct room_id）后，`has_prediction` 与 `replay_gaps` 的 JOIN **都走主键**。那 2.4 亿次的来源我**没有查清**，不编解释；但它是累计值，且该索引膨胀 72 倍这件事与来源无关，REINDEX 该做还是要做。 |
| SCHEMA 里 `ALTER TABLE ... SET (autovacuum_vacuum_cost_limit = 2000)` **每次启动都执行** | **已修**（这是我 4.9.5 没注意到的运维陷阱）。运维手动调低强度后，下次重启会被原样盖回 —— 调了等于没调，且现象隐蔽。现改为读环境变量 `STA_PG_AUTOVACUUM_COST_LIMIT`，**默认仍是 2000，存量部署行为零变化**。 |
| 我尝试实测 cost_limit 与 VACUUM 强度的关系 | **测法不成立**（结果非单调：200→5.22s、600→1.79s、1000→4.00s、2000→1.83s，缓存与重灌数据污染了对照）。**我不拿这组数据下结论**，改为基于生产实测的死元组占比（0.2%，余量百倍）给建议。 |

## 15. 现在建议你做什么，按顺序

1. **先跑体检**（不动手，只看）：
   ```bash
   bash backend_async/scripts/pg_maintenance.sh
   ```
   确认磁盘余量够（诊断 §7 显示 rounds 合计 19 GB，重建需要临时空间）。

2. **重建膨胀索引**（在线，不锁表，建议低峰期）：
   ```bash
   bash backend_async/scripts/pg_maintenance.sh --reindex
   ```
   预期 `predictions` 索引 1042 MB → ~4 MB。

3. **清零统计计数器**，以便之后能读出**当前**的索引使用率：
   ```bash
   docker exec -i deploy-postgres-1 psql -U star -d spelltamer -c "SELECT pg_stat_reset();"
   ```

4. **观察一两个小时**。若 CPU 尖峰仍明显，再降 autovacuum 强度 ——
   现在这个值可以从 env 调，重启不会被盖回：
   ```bash
   # backend_async/deploy/.env
   STA_PG_AUTOVACUUM_COST_LIMIT=800
   ```
   （想立刻热试而不重启：
   `ALTER TABLE rounds SET (autovacuum_vacuum_cost_limit = 800);`）

5. **最后再考虑第 13 节的结构性取舍** —— 那才是数量级的差别，但涉及产品决策。

## 16. 本轮改了什么

| 文件 | 改动 |
|---|---|
| `app/db.py` | autovacuum 强度改为 env 可配（`STA_PG_AUTOVACUUM_COST_LIMIT`，默认 2000 不变），修掉「重启覆盖运维调参」的陷阱 |
| `scripts/pg_maintenance.sh` | **新增**。索引膨胀体检 + 在线 REINDEX |
| `scripts/pg_diagnose.sh` | 修三处缺陷：补 `last_analyze`、标注 `idx_scan` 为累计值、新增膨胀比与 §9 |
| `PG-INDEX-DIET.md` | 本节及以下 |

**回归**：`495 passed / 120 skipped / 40 errors`，与原始包逐字节一致；
迁移集成测试与 8 个 DAO 方法验证全部通过；
env 覆盖的四种取值（默认 / 800 / 越界 / 非法）逐一验证。

---
---

# 第三轮（4.9.7）—— REINDEX 落地之后

## 17. REINDEX 结果：与预测一致

```
predictions_pkey   881 MB → 2112 kB   （417× 回收，耗时 1s）
idx_pred_round     160 MB → 1016 kB   （161× 回收，耗时 1s）
predictions 合计  1042 MB → 3168 kB
```

膨胀比 414.9 / 75.4 → **1.0 / 0.5**。这张表现在处于健康状态，而且**不会再膨胀**
—— 它当初胀是因为**曾经很大**，现在 62,627 行就是它的自然规模。

## 18. 一个我差点冒领的功劳：55.6s → 10.6s 不是我的改动

`retention_last.elapsed_s` 从 **55.571s 降到 10.572s**（删除量几乎相同：
511,097 → 508,478）。看起来像是 4.9.5 索引瘦身的效果。**我去验了，不是。**

```
同机 A/B，180 万行删 36 万行，逐字复刻 purge_before（分批 DELETE + ANALYZE）：
  lean（索引 69 MB ）  DELETE 1.68s / 1.38s   ANALYZE 0.21s / 0.23s
  full（索引 236 MB）  DELETE 1.47s / 1.48s   ANALYZE 0.23s / 0.26s   ← 无差异
对照 VACUUM：           lean 0.49s   vs   full 0.81s                   ← 只有这里有差异
```

原因是 PG 的设计：**DELETE 只把堆元组标记为死，不当场维护索引**，索引清理发生在
VACUUM。所以清理耗时天然不随索引数变化。

那 5.3 倍从哪来？时间线（换算成 UTC）：

```
15:53:34  retention 清理，55.571s
16:43:39  第一次诊断（此时索引迁移已完成）
16:53:18  retention 清理，10.572s
17:12:05  REINDEX
```

两次清理**都在 REINDEX 之前**，所以也不是 REINDEX 的功劳。最可能是重启后
缓存冷/热的差别，或那一轮恰好与 autovacuum 撞车。**n=2、有混淆变量、机制假设
已被证伪 —— 我不下结论，也不把它算作改动收益。**

索引瘦身的**真实**收益在 VACUUM 上（本地实测 1.65×），而 VACUUM 正是 CPU
尖峰所在 —— 这一点没变，只是收益的位置和我原先说的不同。

## 19. 新发现：`predictor_state` 只增不删

排查「有没有同类问题」时查到的。`db.py` 的清理白名单是：

```python
_PURGE_TABLES = ("rounds", "predictions")   # 仅历史流水;predictor_state/rooms 不清
```

`purge_rooms_history`（发现房 7 天回收时的级联清史）也复用同一份白名单，注释
明写「predictor_state/rooms 仍不清」。全项目对 `predictor_state` 的唯一 DELETE
在 `scripts/smoke_worker.py`（测试脚本）里。

**结果：每个曾经产生过预测的房，其模型权重永久留在库里。** 自动发现每 7 天
淘汰一批房，这张表就这样单向增长。

这是**刻意的设计**（权重是「当前状态」而非「历史流水」，且房间复播时能热启动），
不是 bug。但代价是无界增长，而且——

**更要命的是我的两个脚本都只看 `rounds` 和 `predictions`，压根不会发现它。**
这次一并修了：两个脚本的表范围都放开到全库。`pg_maintenance.sh` 新增
「只增不删的表」一节，会直接算出 `predictor_state` 里的**孤儿房**
（房号既不在 `rooms` 也不在 `discovered_rooms`）行数与占用，并给出清理 SQL
—— 但**脚本绝不自动删**，因为删掉等于丢弃模型权重，属产品决策。

`admin_audit` / `config_revisions` 同样无保留策略，但写入源只有 4 处后台动作、
`target_rev` 才 18，量级可忽略，同样纳入了监控。

## 20. `rounds_pkey` 要不要重建？

体检给的数：`5873 MB / 膨胀比 1.8 / 可回收 2694 MB`。

**收益**：`rounds` 的索引合计从 6848 MB 降到 ~4154 MB，**每趟 vacuum 少扫 39%**。
vacuum 大约每小时一趟，这是直接作用在 CPU 尖峰上的。

**代价**：93,757,488 行。`predictions` 那次 62,627 行用了 1 秒，但 REINDEX 的耗时
主要由**行数**决定，不是体积 —— 这次要读完 13 GB 堆、排序 9375 万个键。
预计 **10~30 分钟**，期间占一个核和相当的 I/O（不锁表，业务照常）。
临时空间需 ~3.2 GB，你有 92.8 GB 可用，没问题。

**它会不会再胀回去？会。** `rounds_pkey` 的键是 `(room_id, round_id)`：插入永远
落在每个房键区间的右端，删除永远从左端切 —— 于是每个房的区间左侧持续产生空页。
空页会被回收进索引的空闲页表复用，但有滞后，所以**稳定在 ~1.8 倍就是它的常态**，
不是异常。重建是**周期性维护**（建议季度级），不是一次性修复。

`predictions` 不同：它已经回到自然规模，不会再胀。

**我的建议**：先只做低成本的部分（已完成），观察一两天 CPU 尖峰是否还明显。
若仍明显，再在低峰期跑：

```bash
docker exec -i deploy-postgres-1 psql -U star -d spelltamer \
  -c "REINDEX INDEX CONCURRENTLY rounds_pkey;"
```

## 21. 本轮改了什么

| 文件 | 改动 |
|---|---|
| `scripts/pg_maintenance.sh` | 表范围由 `rounds`/`predictions` **放开到全库**；新增「只增不删的表」一节与 `predictor_state` 孤儿房检测 |
| `scripts/pg_diagnose.sh` | 同样放开表范围（§2 / §3 / §7 / §9 现在都能看到 `predictor_state`、`admin_audit`） |
| `PG-INDEX-DIET.md` | 本节及以上 |

`app/db.py` **本轮未再改动**。

## 22. 至此仍未处理的（都需要你决策）

1. **`rounds_pkey` 重建** —— 见 §20，10~30 分钟，季度级维护。
2. **`predictor_state` 孤儿清理** —— 先跑体检看量级，删不删是产品决策。
3. **自动发现占 98.8% 的写入量**（8,347 / 8,451）—— 见 §13，数量级的杠杆。
4. **覆盖哨兵 N+1**（`worker.py:1212`，`COV_SPAN_CAP=200` 次串行 `has_round`）——
   改的是 worker 逻辑，风险高于索引，建议等 CPU 尖峰的观察结论出来再定。
