"""
starmeta.py — 繁星资料解析 + 房号归一(异步、尽力而为)
================================================================================
背景(与旧 server.py 一致的领域事实):
  · 观众输入的「房号」可能是**短号/靓号**(例:321),繁星页 fanxing.kugou.com/321
    会 302 到 /channel/2678075(或 /{真实房号}),落点页面里的 roomId 才是
    **真实房号**。上游 mapi 不校验房号,按短号抓取会抓到「凭空局」,故抓取/入库/
    订阅一律必须先归一到真实房号(canon)。
  · 展示资料(昵称/头像)按「用户输入的号」解析更稳(短号频道页 kugouId 稳定),
    抓取则用真实号 —— 二者分离,与旧版观感一致。

本模块把旧 server.py 的多层解析(页面解析 → roomStatus 兜底 kugouId →
getStarInfo 补昵称/头像)搬到 asyncio + aiohttp,并做两级缓存:
  · canon 缓存:短号 → 真实房号。权威答案(页面解析成功)永不过期;失败短存 60s。
  · profile 缓存:房号 → {nickname, avatar, roomId, kugouId}。命中 600s,失败 60s。

**任何一步失败都优雅退回**:归一失败回退原号(只读查询按原号最多得到空结果,
无害);资料失败回退占位「房间 {号}」。核心抓取链路不依赖本模块可用性。
"""
from __future__ import annotations

import asyncio
import re
import time
from typing import Any, Dict, Optional, Tuple

import aiohttp

# ── 域名候选(与旧版一致:失败切换备用域) ───────────────────────────────────
FX_PAGE_HOSTS = ["fanxing.kugou.com"]
FX_STARINFO_HOSTS = ["fx1.service.kugou.com", "fx2.service.kugou.com"]
ROOMSTATUS_URL = ("https://service1.fanxing.kugou.com/roomcen/room/web/roomStatus"
                  "?roomId={room}")

FX_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
         "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36")
FX_HEADERS = {
    "User-Agent": FX_UA,
    "Referer": "https://fanxing.kugou.com/",
    "Origin": "https://fanxing.kugou.com",
    "Accept": "*/*",
    "Accept-Language": "zh-CN,zh;q=0.9",
}

CANON_TTL_OK = float("inf")   # 权威映射永不过期
CANON_TTL_ERR = 60.0
PROFILE_TTL_OK = 600.0
PROFILE_TTL_ERR = 60.0

_ROOM_RE = re.compile(r"^[0-9]{2,12}$")


def _now() -> float:
    return time.time()


# ── 页面解析(移植旧 _fx_parse_page 主路径) ──────────────────────────────────
def _parse_page(html: str) -> Dict[str, Any]:
    out = {"roomId": "", "kugouId": 0, "nickname": "", "logoUrl": "", "channel": False}
    m = re.search(r"roomId=(\d+)", html) or re.search(r'"roomId"\s*:\s*(\d+)', html)
    if m:
        out["roomId"] = m.group(1)
    m = re.search(r'_userkugouid="(\d+)"[^>]*>([^<]{1,40})<', html)
    if m:
        out["kugouId"] = int(m.group(1))
        out["nickname"] = m.group(2).strip()
    # 官方频道页:/{号} 302 → /channel/{rid};内嵌 isChannelRoom + roomStarId
    if not out["kugouId"] and re.search(r"isChannelRoom\s*:\s*true", html):
        out["channel"] = True
        m = re.search(r"roomStarId\s*:\s*['\"](\d+)['\"]", html)
        if m and int(m.group(1)) > 0:
            out["kugouId"] = int(m.group(1))
        m = re.search(r"\broomId\s*:\s*['\"](\d+)['\"]", html)
        if m:
            out["roomId"] = m.group(1)
    if (not out["nickname"] and not out["channel"]
            and (out["roomId"] or out["kugouId"])):
        m = (re.search(r"starName\s*[:=]\s*['\"]([^'\"]{1,50})['\"]", html)
             or re.search(r"<title>([^<|]{1,50}?)\s*\|", html))
        if m:
            out["nickname"] = m.group(1).strip()
    # 头像:新老两代文件名;在 JSON 反转义斜杠的副本上扫描
    un = html.replace("\\/", "/")
    logos = [(lm.start(), lm.group(0)) for lm in re.finditer(
        r"(?:https?:)?//[a-z0-9.-]+/(?:v2/)?fxuserlogo/[A-Za-z0-9_\-]+"
        r"\.[A-Za-z]+(?:_\d+x\d+\.[A-Za-z]+)?", un)]
    uniq = {u: pos for pos, u in reversed(logos)}
    if len(uniq) == 1:
        out["logoUrl"] = next(iter(uniq))
    elif len(uniq) > 1:
        anchor = un.find(str(out["kugouId"])) if out["kugouId"] else un.find(out["nickname"])
        out["logoUrl"] = min(uniq.items(), key=lambda kv: abs(kv[1] - max(anchor, 0)))[0]
    if out["logoUrl"].startswith("//"):
        out["logoUrl"] = "https:" + out["logoUrl"]
    return out


_LOCKS_SOFT_CAP = 4096   # 锁字典软上限;超过则回收未持有的锁,防长期运行内存泄漏
# 复审补漏:_canon / _profile 与 _locks 同为按房号索引的进程内字典,但原实现
# **只给 _locks 加了软上限**。而这两个字典的键直接来自用户输入(SSE 的 roomId、
# 各房间端点的 path 参数),仅受 _ROOM_RE(^[0-9]{2,12}$)约束 —— 键空间 10^12。
# 关键在于:条目只有**逻辑过期**(元组里存的时刻),从不从字典里删除;
# CANON_TTL_OK 更是 inf(权威映射按设计永驻)。于是每一个被查过的**不存在**的
# 房号都会留下一条永久条目 —— 一个登录用户按明细限流(4/s)持续枚举,一天即可
# 灌入数十万条。正常运行只有真实房数量级(本部署约 8400 房 → 约 1.7 万条),
# 故给足余量后再回收,稳态零影响。
# 淘汰是安全的:canon 重解析会**先查跨进程 Redis 缓存**(_cache_get),命中即返回,
# 不会因此多打繁星一次;profile 重解析同理受 per-room 锁保护、不会惊群。
_CANON_SOFT_CAP = 65536     # ≈ 8400 房权威映射(每房 2 条)的 4 倍余量
_PROFILE_SOFT_CAP = 16384   # ≈ 房数的 2 倍余量


class StarMeta:
    """异步繁星解析器。单例即可(内部无每房状态,只有缓存)。

    削峰改造(面向「同时添加数千房」):
      · **繁星令牌桶闸门**(bucket):每次繁星 HTTP 请求前先申领令牌。限流下沉到
        资源边界后,无论谁调用(单房 add / 批量 / seed / janitor / SSE)都自动被
        钳住,不会惊群打爆酷狗繁星(旧实现对这一路零限流)。
      · **跨进程归一缓存**(redis):alias→真实房号 的权威映射写入 Redis,多 web/
        worker 进程共享 —— 数千房只需全局解析一次,而非每进程各解析一遍。
      · 连接器并发上限可配(conn_limit);锁字典带软上限回收。
    """

    def __init__(self, timeout: float = 6.0, conn_limit: int = 64,
                 bucket: Any = None, redis: Any = None,
                 cache_prefix: str = "canon:"):
        self._timeout = aiohttp.ClientTimeout(total=timeout)
        self._conn_limit = int(conn_limit)
        self._bucket = bucket            # ratelimit.TokenBucket | None(繁星专用桶)
        self._redis = redis              # redis.asyncio.Redis | None(跨进程归一缓存)
        self._cprefix = cache_prefix
        self._session: Optional[aiohttp.ClientSession] = None
        self._canon: Dict[str, Tuple[float, str, bool]] = {}   # alias -> (exp, rid, definitive)
        self._profile: Dict[str, Tuple[float, Dict[str, Any]]] = {}  # room -> (exp, profile)
        self._locks: Dict[str, asyncio.Lock] = {}

    async def start(self) -> None:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=self._timeout, headers=FX_HEADERS,
                connector=aiohttp.TCPConnector(limit=self._conn_limit, ttl_dns_cache=300))

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    @staticmethod
    def _cap_dict(d: dict, cap: int) -> None:
        """按房号索引的字典软上限(与 _lock 的锁回收同款范式)。

        先扫掉**逻辑上已过期**的条目(失败缓存 60s、profile 600s);若仍超标,
        再按插入序丢弃最早的四分之一(dict 自 3.7 起保序)。丢弃只会导致一次
        重解析,而重解析先走跨进程 Redis 缓存,代价接近零。"""
        if len(d) < cap:
            return
        now = _now()
        for k in [k for k, v in d.items() if v[0] <= now]:
            d.pop(k, None)
        if len(d) >= cap:
            for k in list(d.keys())[:max(1, len(d) // 4)]:
                d.pop(k, None)

    def _lock(self, key: str) -> asyncio.Lock:
        lk = self._locks.get(key)
        if lk is None:
            if len(self._locks) >= _LOCKS_SOFT_CAP:
                # 回收当前未被持有的锁(locked() 为 False),避免字典无界增长。
                for k in [k for k, v in self._locks.items() if not v.locked()]:
                    self._locks.pop(k, None)
            lk = asyncio.Lock()
            self._locks[key] = lk
        return lk

    async def _gate(self) -> None:
        """繁星请求前的限流闸门:向繁星专用令牌桶申领一枚令牌(阻塞至拿到或超时)。
        无桶时直接放行(向后兼容 / 单测)。"""
        if self._bucket is not None:
            try:
                await self._bucket.acquire()
            except Exception:
                pass   # 桶异常不阻断归一(优雅降级;连接器仍限制并发)

    # ── 跨进程归一缓存(Redis) ────────────────────────────────────────────────
    async def _cache_get(self, alias: str) -> Optional[Tuple[str, bool]]:
        if self._redis is None:
            return None
        try:
            v = await self._redis.get(self._cprefix + alias)
        except Exception:
            return None
        if not v:
            return None
        # 值格式:"1|rid"(权威)/ "0|rid"(暂不可信,通常仅本地负缓存,不入 Redis)
        try:
            flag, rid = str(v).split("|", 1)
            return rid, (flag == "1")
        except ValueError:
            return None

    async def _cache_put(self, alias: str, rid: str, definitive: bool) -> None:
        if self._redis is None or not definitive:
            return   # 只把权威映射写入共享缓存;失败态仅本地短存,避免污染全局
        try:
            # 权威映射长存(7 天);房主换绑极罕见,且 janitor/重启会自然刷新
            await self._redis.set(self._cprefix + alias, f"1|{rid}", ex=7 * 24 * 3600)
        except Exception:
            pass

    # ── 对外:房号归一 ────────────────────────────────────────────────────────
    async def canon(self, alias: str) -> Tuple[str, bool]:
        """短号/靓号 → (真实房号, definitive)。definitive=False 表示暂不可信(离线/超时),
        返回原号回退,**不得用于起监控**。"""
        alias = str(alias or "").strip()
        if not _ROOM_RE.match(alias):
            return alias, False
        hit = self._canon.get(alias)
        if hit and hit[0] > _now():
            return hit[1], hit[2]
        # 跨进程缓存:别的 web/worker 已解析过则直接复用,零繁星请求(数千房只全局解析一次)
        cached = await self._cache_get(alias)
        if cached and cached[1]:
            self._cap_dict(self._canon, _CANON_SOFT_CAP)
            self._canon[alias] = (CANON_TTL_OK, cached[0], True)
            return cached[0], True
        prof = await self.profile(alias)
        rid = str(prof.get("roomId") or "").strip()
        if rid.isdigit():
            self._cap_dict(self._canon, _CANON_SOFT_CAP)
            self._canon[alias] = (CANON_TTL_OK, rid, True)
            self._canon[rid] = (CANON_TTL_OK, rid, True)  # 真实号自映射,零开销
            await self._cache_put(alias, rid, True)        # 写入共享缓存供其它进程复用
            return rid, True
        self._profile.pop(alias, None)  # 清负缓存以便尽快重试
        self._cap_dict(self._canon, _CANON_SOFT_CAP)
        self._canon[alias] = (_now() + CANON_TTL_ERR, alias, False)
        return alias, False

    # ── 对外:直播状态(5.0.6) ───────────────────────────────────────────────
    async def live_status(self, room: str) -> Optional[int]:
        """真实房号 → 1(直播中)/ 0(未开播)/ None(问不到,**不得据此改判**)。

        走的就是既有 `_room_status`(roomStatus 接口),它一直解析着 liveStatus
        却被 `_resolve` 丢掉;此处只是把这枚已有的事实取出来。**不缓存**:
        缓存周期由调用方(worker._livestatus 的 fresh_s)统一管,这里缓存会与那层
        重叠成两套过期语义。

        取值域实地核查(2026-08-12,随机真号段 + 边界号实测):
          code!=0(1100004/1100009)→ 无此房/参数非法 → _room_status 已回 None;
          liveStatus=-1 且 kugouId=0 → 房号无主播绑定(短号/未开通)= **不可判**,
            不是「未开播」(固定房短号 321 即落此档,故探测必须用归一后的真实号);
          liveStatus=0 → 未开播;liveStatus=1 → 直播中(含频道房 roomType=3,
            以及列表侧 liveStatus=6/liveCast=2 的手机开播,复核均为 1)。
        """
        # _room_status 直接用 self._session 而自身不建会话(旧路径靠 _resolve 在入口
        # 处 start())。本方法是**新的公开入口**,不补这一行就会在「首次调用先于任何
        # profile()」或「会话被 close 过」时踩空 self._session → AttributeError 被下面
        # 的兜底吞成 None → 永远「问不到」且零日志。start() 幂等,重复调用零成本。
        await self.start()
        st = await self._room_status(str(room or "").strip())
        if not st:
            return None
        try:
            v = int(st.get("liveStatus", -1))
        except (TypeError, ValueError):
            return None
        return v if v in (0, 1) else None

    # ── 对外:资料(昵称/头像) ───────────────────────────────────────────────
    async def profile(self, room: str) -> Dict[str, Any]:
        room = str(room or "").strip()
        if not _ROOM_RE.match(room):
            return {"roomId": room, "nickname": "", "avatar": ""}
        hit = self._profile.get(room)
        if hit and hit[0] > _now():
            return hit[1]
        async with self._lock(room):
            hit = self._profile.get(room)
            if hit and hit[0] > _now():
                return hit[1]
            prof = await self._resolve(room)
            ok = bool(prof.get("nickname") or prof.get("avatar"))
            self._cap_dict(self._profile, _PROFILE_SOFT_CAP)
            self._profile[room] = (_now() + (PROFILE_TTL_OK if ok else PROFILE_TTL_ERR), prof)
            return prof

    # ── 解析主链(页面 → roomStatus 兜底 kugouId → getStarInfo 补料) ────────────
    async def _resolve(self, room: str) -> Dict[str, Any]:
        await self.start()
        prof: Dict[str, Any] = {"alias": room, "roomId": room, "kugouId": 0,
                                "nickname": "", "avatar": ""}
        page: Optional[Dict[str, Any]] = None
        logo = ""
        # ① 页面解析(多域候选)
        for host in FX_PAGE_HOSTS:
            try:
                await self._gate()   # 繁星令牌桶:限流下沉到资源边界,任何调用者都被钳住
                async with self._session.get(f"https://{host}/{room}",
                                             allow_redirects=True) as r:
                    html = await r.text(errors="ignore")
                page = _parse_page(html)
                if page["roomId"]:
                    prof["roomId"] = page["roomId"]
                if page["kugouId"]:
                    prof["kugouId"] = page["kugouId"]
                if page["nickname"]:
                    prof["nickname"] = page["nickname"]
                logo = page["logoUrl"] or ""
                if page["nickname"] or page["logoUrl"] or page["roomId"]:
                    break
            except Exception:
                page = None
                continue
        # ② roomStatus 兜底(补 kugouId / 页面失败时补 roomId)
        if prof["kugouId"] <= 0 or not page:
            st = await self._room_status(room)
            if st:
                kid = int(st.get("kugouId") or 0)
                if prof["kugouId"] <= 0 and kid > 0:
                    prof["kugouId"] = kid
                if not page and st.get("roomId"):
                    prof["roomId"] = str(st.get("roomId") or room)
        # ③ getStarInfo 补昵称/头像
        if prof["kugouId"] > 0 and (not logo or not prof["nickname"]):
            data = await self._star_info(prof["kugouId"])
            if data:
                if not prof["nickname"]:
                    prof["nickname"] = data.get("nickName") or ""
                if not logo:
                    logo = data.get("userLogo") or ""
        if logo:
            prof["avatar"] = _relay_logo(logo)
        return prof

    async def _room_status(self, room: str) -> Optional[Dict[str, Any]]:
        try:
            await self._gate()   # 繁星令牌桶
            async with self._session.get(ROOMSTATUS_URL.format(room=room)) as r:
                if r.status != 200:
                    return None
                data = await r.json(content_type=None)
        except Exception:
            return None
        # 旧 server.py:code==0 才采信 data(非 0 视为查无此房/接口错误)
        if not isinstance(data, dict) or data.get("code") != 0:
            return None
        d = data.get("data") or {}
        return {"kugouId": d.get("kugouId") or d.get("userId") or 0,
                "roomId": d.get("roomId") or room,
                "liveStatus": d.get("liveStatus", -1)}

    async def _star_info(self, kugou_id: int) -> Optional[Dict[str, Any]]:
        # 旧 server.py 权威端点(路径参数式):
        #   https://fx1.service.kugou.com/room/aggregation/getStarInfo/{kid}/
        # fx1 ↔ fx2 为同一份数据的等价域名候选。
        for host in FX_STARINFO_HOSTS:
            try:
                await self._gate()   # 繁星令牌桶
                url = f"https://{host}/room/aggregation/getStarInfo/{int(kugou_id)}/"
                async with self._session.get(url) as r:
                    if r.status != 200:
                        continue
                    data = await r.json(content_type=None)
                d = (data or {}).get("data") or {}
                if d.get("nickName") or d.get("userLogo"):
                    return {"nickName": d.get("nickName") or "",
                            "userLogo": d.get("userLogo") or ""}
            except Exception:
                continue
        return None


def _relay_logo(url: str) -> str:
    """头像 URL 归一(对齐旧 server.py._relay_logo,前端直用外链):
       ① 协议相对 // → https:;② p{N}.fx.kgimg.com 特例域改写;③ http → https。"""
    if not url:
        return ""
    if url.startswith("//"):
        url = "https:" + url
    m = re.match(r"^http://(p\d+)\.fx\.kgimg\.com/(.*)$", url)
    if m:
        url = f"https://{m.group(1)}fx.kgimg.com/{m.group(2)}"
    return re.sub(r"^http://", "https://", url, count=1)
