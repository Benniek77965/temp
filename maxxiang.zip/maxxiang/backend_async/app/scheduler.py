"""
scheduler.py — 错峰调度的纯计算(便于单测)
================================================================================
「几千房不必对齐同一秒抓取」的核心:把每房的下一次抓取排在**它自己的出怪节奏**
上,并叠加随机抖动打散。于是即便许多房出怪时刻恰好相近,它们的 RoundAward 请求
也会被抹开成一个窗口,配合全局令牌桶,毛刺被削平。

时钟域:上游返回的 roundId / spellTime / drawTime / endTime / serverTime 均为
**服务器时钟毫秒**;而调度队列(Redis ZSET)用**本机 wall-clock 毫秒**。转换只需
用「从服务器此刻到目标时刻的相对差 delta」加到本机此刻上,天然免除时钟漂移:
    due_wall = now_wall + (target_srv - server_now_srv) + jitter
"""
from __future__ import annotations

import random

from .constants import HIST_PAGE_ROUNDS, ROUND_STEP

# ── hist-mode(3.5.0)周期钳位:与 worker.effective_claim_grace_ms 同一先例 ——
#    **打破不变量的配置不允许借任何通道生效**(管理台校验只拦新写入,拦不住
#    配置中枢历史持久快照灌回的越窗值)。
HIST_INTERVAL_MIN_MS = 60_000                                  # 防误配秒级 → 自伤风暴
HIST_INTERVAL_MAX_MS = (HIST_PAGE_ROUNDS - 4) * ROUND_STEP     # 页窗 − 4 局余量 ≈1300s


def effective_hist_interval_ms(histmode_cfg) -> int:
    """hist-mode 实际使用的轮询周期(ms):配置值钳到 [60s, 页窗−4局]。"""
    try:
        v = int(float(getattr(histmode_cfg, "interval_s", 900)) * 1000)
    except (TypeError, ValueError):
        v = 900_000
    return max(HIST_INTERVAL_MIN_MS, min(v, HIST_INTERVAL_MAX_MS))


def jitter_ms(upper: int, rnd: random.Random | None = None) -> int:
    """返回 [0, upper] 的随机抖动毫秒。"""
    if upper <= 0:
        return 0
    r = rnd or random
    return int(r.random() * upper)


def award_due_wall(now_wall: int, server_now: int, anchor_time: int,
                   award_delay_ms: int, jitter_upper: int,
                   rnd: random.Random | None = None) -> int:
    """某局 RoundAward 的抓取 wall-clock 到期时刻。

    anchor_time 是「结果按理已生成」的锚点时刻。
    真机实测(HAR + 活体 cookie 双证):出怪结果在**备战后约 1 秒**(局内 ~35.5–36s)
    就已生成、可拉取 —— 远早于 drawTime(40s)、更早于 endTime(50s)。
    所以 anchor 应传 spellTime(备战),award_delay 只需 ~1.5s;
    盯 drawTime 会白等 ~4 秒才去取,数据平白晚出这么多。
    偶发备战瞬间结果还没落定 → RoundAward 返回空 → _handle_award 的退避重试吸收。
    """
    delta = (anchor_time + award_delay_ms) - server_now
    return now_wall + max(0, delta) + jitter_ms(jitter_upper, rnd)


def next_mainpage_due_wall(now_wall: int, server_now: int, end_time: int,
                           min_interval_ms: int, jitter_upper: int,
                           tail_ms: int = 800, rnd: random.Random | None = None) -> int:
    """下一次 MainPage 刷新的 wall-clock 到期时刻:
       目标 = 本局结束后 tail_ms(去抓下一局的权威计时),但不早于 min_interval(空转保护)。"""
    delta_end = (end_time + tail_ms) - server_now
    wait = max(delta_end, min_interval_ms) if end_time else min_interval_ms
    return now_wall + max(0, wait) + jitter_ms(jitter_upper, rnd)


def retry_due_wall(now_wall: int, backoff_ms: int, attempt: int,
                   jitter_upper: int, cap_ms: int = 15000,
                   rnd: random.Random | None = None) -> int:
    """未就绪重试的到期时刻:指数退避(带上限)+ 抖动。"""
    step = min(cap_ms, backoff_ms * max(1, attempt))
    return now_wall + step + jitter_ms(jitter_upper, rnd)


# ── hist-mode(3.5.0)纯计算:后台发现房 GameHistory 轮询 ─────────────────────

def hist_retry_delay_ms(fails: int, age_ms: int, base_ms: int, cap_ms: int,
                        edge_after_ms: int, edge_retry_ms: int,
                        rnd: random.Random | None = None) -> int:
    """轮询失败后的下一次重试延迟(ms)。

    两段式,核心是**前瞻投影**(复查修正 B):普通退避 base×2^(fails-1) 封顶 cap;
    但若「距上次成功的年龄 + 本次退避」会越过 edge_after(距页窗越界仅 ~2 局的
    抢救线),则改用 edge_retry 抢救节拍 —— 否则退避阶梯的最后一跳会直接跳过
    整个抢救区、把本可挽回的数据推出 30 局页窗(300+90+180+300+300 = 1170,
    再 +300 = 1470,下一跳 1770 > 1500 已丢;投影后 1170 起即切 45s,越窗前
    还有 ~6 次机会)。age_ms<=0(从未成功过,如新房首拍即失败)不投影 ——
    没有页窗时钟可保,按普通退避即可。抖动:普通段 0..1/6 步长;抢救段 ±1/3
    (去同步,全局断供恢复时万房回流自然铺开)。
    """
    r = rnd or random
    step = min(int(cap_ms), int(base_ms) << max(0, min(int(fails) - 1, 6)))
    if age_ms > 0 and age_ms + step > edge_after_ms:
        base = int(edge_retry_ms)
        lo, hi = max(1000, base - base // 3), base + base // 3
        return int(lo + r.random() * (hi - lo))
    return step + int(r.random() * (step // 6 + 1))


def weighted_fleet_load(curated: int, hist_rooms: int, interval_s: float,
                        round_s: float = 50.001, cost_ratio: float = 1.5) -> int:
    """混合舰队的**等效实时房数**(算力体检/建议副本数用)。

    hist-mode 房每 interval_s 才一个事件(整页批量入库),按事件率折算成
    「等效多少个实时房」:hist × (round_s/interval_s) × cost_ratio。
    cost_ratio = 单次轮询 CPU / 单局实时 CPU 的比值 —— 整页解析 + 30 行批量
    INSERT 比单局重,但省掉了每局的任务周期/快照/SSE;暂取 1.5(保守偏高,
    待 §6 微基准钉死后回填,宁可高估负载也不低报)。interval<=0 视为未启用,
    hist 房按实时口径原样计入(与关闭模式时的行为一致)。
    """
    c = max(0, int(curated))
    h = max(0, int(hist_rooms))
    if h == 0:
        return c
    if interval_s <= 0:
        return c + h
    import math as _m
    return c + int(_m.ceil(h * (round_s / float(interval_s)) * cost_ratio))


def curated_idle_split(now_ms: int, rooms, last_access: dict, cold,
                       after_ms: int):
    """curated-idle(3.7.0)降级判定的纯计算前半:按「最近访问年龄」把策展房
    切成 (to_seed, candidates)。**只做年龄判定** —— 第二道观众守卫
    (draws:{room} 订阅数 >0 一票否决)需要 Redis PUBSUB,留在调用方
    (worker._curated_idle_sweep),本函数保持纯、可穷举单测。

      to_seed     无访问记录的房(Redis 重启 / 首次启用 / 新加房):**播种而
                  不判闲** —— 年龄未知时绝不降级(is_discovered「判不出按
                  策展走」同一哲学);调用方以 ZADD NX 记下 now,自此有真实
                  年龄可判。坏时戳(非数值)同按未知处理。
      candidates  年龄 ≥ after_ms 且**未冷**的房 —— 排序确定(便于测试与
                  batch 截断的可复现性)。

    已冷的房与未达龄的房不出现在任何输出(前者已在目标态,后者是活跃房)。
    边界取 ≥:恰达阈即候选 —— 阈值语义是「至少空闲这么久」,与注册表
    ge/le 的闭区间习惯一致。"""
    to_seed, cands = [], []
    after = max(0, int(after_ms))
    coldset = {str(c) for c in (cold or ())}
    for r in sorted(str(x) for x in (rooms or ())):
        if r in coldset:
            continue
        ts = (last_access or {}).get(r)
        if ts is None:
            to_seed.append(r)
            continue
        try:
            age = int(now_ms) - int(ts)
        except (TypeError, ValueError):
            to_seed.append(r)
            continue
        if age >= after:
            cands.append(r)
    return to_seed, cands
