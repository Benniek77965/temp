"""
discovery.py — 直播间自动发现(遍历繁星「在播房间」列表,尽力而为)
================================================================================
背景与目标
----------
繁星有一个**在播房间列表** CDN 接口(分页):

    GET https://fx1.service.kugou.com/mfanxing-home/h5/cdn/room/index/list?...&page=N

每页返回若干在播房间,其中 **roomId 即真实房号**(可直接用于九法抓取,**无需归一**——
与观众手输的短号/靓号不同,这里拿到的已经是真实号)。当 `data.hasNextPage==0`
(或 `data.list` 为空)时表示没有下一页。

本模块只做**两件事**,且都不碰 Redis/PG(纯 I/O + 纯解析,便于单测):

  1. `Discovery.sweep()` —— 从 page=1 起逐页拉取,直到 `hasNextPage==0` / 空页 /
     触达页数护栏 `max_pages`,把所有页的 roomId 去重汇总成一个列表。
  2. `parse_page()` —— 解析单页响应为 (roomId 列表, hasNextPage)。

「把发现到的房登记进后台 + 错峰起抓 + 前端隐藏」这一步由 worker 的发现循环
(`Worker._discovery`)编排,见 worker.py —— 那里才接 Redis 名录与调度队列。这样
本模块保持无状态、可独立单测(`tests/test_discovery.py` 用假响应驱动,不触网)。

健壮性(重要)
--------------
上游偶发返回**非法 JSON**:昵称/标签里出现落单的反斜杠(如 `hi*\\(๑•₃•๑)`)会让
标准 `json.loads` 抛 `JSONDecodeError`。而我们只需要两个**数值字段**(roomId、
hasNextPage),它们不受字符串转义影响。故解析走「严格 JSON 主路径 + 正则兜底」:
JSON 解析失败时,用正则直接抠出 `"roomId":<digits>` 与 `"hasNextPage":<0|1>`,
保证个别坏页不会中断整轮遍历。两条路径在**规范页**上产出完全一致(已实测)。

礼貌性
------
每次翻页请求前可先过**繁星专用令牌桶**(与游戏 API 的令牌桶相互独立,见
ratelimit / settings.ratelimit.fanxing_rps),避免遍历本身把繁星打成惊群。默认
不限流(桶 rate<=0 时始终放行);波次之间也可选加一个极小的 `page_delay_ms` 间隔。

并发翻页(3.4.0;真机实测驱动的修复)
------------------------------------
**旧实现逐页串行**,单页 RTT 实测中位数 **390ms**。页容量实测 **~49 房/页**,于是:

    在播房数    页数    串行遍历耗时      discovery 锁 TTL(= interval_s)
    ~1000      20      ~10s   ✅         60s
    10000     204      ~99s   ❌ 超时     60s

锁是 `SET NX EX=interval_s`(见 redis_bus.discovery_try_lock),**遍历一旦超过 TTL,
锁会在遍历途中过期**,别的 worker 副本随即抢到锁开始**第二轮并发遍历** —— 副本越多
叠得越狠,正是「防惊群」要避免的事,却在**上游规模达到 1 万房时必然发生**。
(README 旧称"常态单轮遍历约 10s 内完成"只在**低谷时段(~1000 房)**成立。)

修复走两条腿:
  ① **本模块:波次并发翻页**(`page_concurrency`,默认 8)—— 204 页实测 **~12s**,
     相对 60s 周期恢复 5 倍余量。语义与串行**逐字节等价**:仍按页序判定终止
     (hasNextPage=0 / 空页 / 取页失败),终止页之后的房**一律不采纳**,故
     `rooms/pages/fetched/stopped_by/truncated` 全部与旧实现一致(契约测试守卫)。
     代价:每轮最多浪费 `page_concurrency-1` 个越界页请求(204 页里的 7 个,可忽略)。
  ② **worker 侧:锁续租心跳**(见 worker._discovery)—— 即便网络劣化让遍历再次
     超过 TTL,持锁者也会续租,不会被别的副本插队。双保险。
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import re
import time
from typing import Any, Dict, List, Optional, Tuple

import aiohttp

log = logging.getLogger("discovery")


def _settings_singleton():
    """进程级 settings 单例的懒读(hist-mode 判定用)。函数级延迟导入:发现器
    的解析纯函数单测不应因 import 本模块而牵连整棵 settings 装载;配置中枢对
    单例**原地改字段**(铁律一),这里每次现读即拿到热更后的值。"""
    from .settings import settings as _s
    return _s

# ── 繁星在播房间列表(CDN 分页接口)默认地址与固定查询参数 ─────────────────────
#    与浏览器抓包一致;page 与 _(缓存串)每次动态注入。device/appid 等为客户端标识,
#    上游不做强校验(实测原样即可用),需要时可经 config/env 覆盖。
DEFAULT_LIST_URL = ("https://fx1.service.kugou.com/mfanxing-home"
                    "/h5/cdn/room/index/list")
DEFAULT_PARAMS: Dict[str, str] = {
    "pid": "0", "kugouId": "0", "doubleLiveFirst": "1", "sysVersion": "0",
    "platform": "7", "device": "7c1d25baae7147dcbc2583c7a3017bfc", "channel": "0",
    "version": "99999", "longitude": "0", "latitude": "0", "appid": "1010",
    "liveTypeFilter": "0", "isNew": "0", "entranceType": "0", "uiMode": "0",
    "areaName": "",
}
# 与 starmeta 对齐的繁星浏览器头(上游对 UA/Referer/Origin 有校验)
FX_HEADERS: Dict[str, str] = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"),
    "Referer": "https://fanxing.kugou.com/",
    "Origin": "https://fanxing.kugou.com",
    "Accept": "application/json",
    "Accept-Language": "zh-CN,zh;q=0.9",
}

# 正则兜底:只抠数值字段,不受字符串转义影响。roomId 为各条目的**顶层**数值字段
# (recomJson 内的相关键是 starKugouId/recom_id 等,且带转义引号 \" ,不会误命中)。
_ROOMID_RE = re.compile(r'"roomId"\s*:\s*(\d+)')
_HASNEXT_RE = re.compile(r'"hasNextPage"\s*:\s*(\d+)')
_ROOM_OK = re.compile(r"^[0-9]{2,12}$")


def _valid_room(rid: Any) -> bool:
    s = str(rid or "").strip()
    return bool(_ROOM_OK.match(s)) and int(s) > 0


def parse_page(text: str) -> Tuple[List[str], Optional[int]]:
    """解析单页响应 → (roomId 列表[保序去重], hasNextPage 或 None)。

    - 主路径:严格 JSON,取 data.list[].roomId 与 data.hasNextPage。
    - 兜底:JSON 解析失败(上游非法转义)时,正则抠 roomId + hasNextPage。
    hasNextPage 缺失时返回 None(由调用方按「空页即止」的规则兜底)。
    """
    rooms: List[str] = []
    seen: set = set()

    # ① 严格 JSON 主路径
    try:
        data = ((json.loads(text) or {}).get("data")) or {}
        lst = data.get("list") or []
        if isinstance(lst, list):
            for it in lst:
                if not isinstance(it, dict):
                    continue
                rid = it.get("roomId")
                if _valid_room(rid):
                    s = str(rid)
                    if s not in seen:
                        seen.add(s)
                        rooms.append(s)
            hnp = data.get("hasNextPage")
            return rooms, (int(hnp) if hnp is not None else None)
    except (ValueError, TypeError, AttributeError):
        pass   # 落到正则兜底

    # ② 正则兜底(malformed JSON)
    for m in _ROOMID_RE.findall(text):
        if _ROOM_OK.match(m) and m not in seen:
            seen.add(m)
            rooms.append(m)
    mn = _HASNEXT_RE.search(text)
    return rooms, (int(mn.group(1)) if mn else None)


class Discovery:
    """繁星在播房间列表的异步遍历器(单例即可;内部无每房状态)。

    与 upstream.Upstream / starmeta.StarMeta 同款生命周期:start() 建会话、
    close() 关会话;sweep() 跑一轮完整分页遍历。
    """

    def __init__(self, list_url: Optional[str] = DEFAULT_LIST_URL,
                 params: Optional[Dict[str, str]] = None, timeout: float = 10.0,
                 conn_limit: int = 32, bucket: Any = None, max_pages: int = 400,
                 page_delay_ms: int = 0, page_concurrency: int = 8):
        self._url = list_url or DEFAULT_LIST_URL
        self._params = dict(DEFAULT_PARAMS)
        if params:
            self._params.update({str(k): str(v) for k, v in params.items()})
        self._timeout = aiohttp.ClientTimeout(total=timeout)
        self._conn_limit = int(conn_limit)
        self._bucket = bucket             # ratelimit.TokenBucket | None(繁星专用桶)
        self._max_pages = max(1, int(max_pages))
        self._page_delay = max(0, int(page_delay_ms)) / 1000.0
        # 波次并发度:每波并发取这么多页(不超过连接器上限,否则并发被连接池吞掉)。
        self._page_conc = max(1, min(int(page_concurrency), self._conn_limit))
        self._session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self) -> "Discovery":
        await self.start()
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()

    async def start(self) -> None:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=self._timeout, headers=FX_HEADERS,
                connector=aiohttp.TCPConnector(limit=self._conn_limit,
                                               ttl_dns_cache=300))

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def _gate(self) -> None:
        """翻页请求前的繁星令牌桶闸门(与 starmeta 同一路)。无桶时直接放行。"""
        if self._bucket is not None:
            try:
                await self._bucket.acquire()
            except Exception:
                pass   # 桶异常不阻断遍历(优雅降级;连接器仍限并发)

    async def _fetch_page(self, page: int) -> Optional[str]:
        """拉取第 page 页原文;失败(网络/非 200)返回 None。字节按 UTF-8 宽松解码,
        绝不因个别非法字节/转义抛异常(交由 parse_page 兜底解析)。"""
        assert self._session is not None, "Discovery 未 start()"
        params = dict(self._params)
        params["page"] = str(page)
        params["_"] = str(int(time.time() * 1000))
        await self._gate()
        try:
            async with self._session.get(self._url, params=params) as r:
                raw = await r.read()
                if r.status != 200:
                    log.warning("[发现] 第 %d 页 HTTP %s", page, r.status)
                    return None
        except Exception as e:
            log.warning("[发现] 第 %d 页请求异常: %r", page, e)
            return None
        return raw.decode("utf-8", "replace")

    async def sweep(self) -> Dict[str, Any]:
        """跑一轮完整分页遍历(**波次并发**;语义与旧串行实现逐字段等价)。

        每波并发取 `page_concurrency` 页,拿回后**严格按页序**逐页判定,遇到终止条件
        即刻收手 —— 终止页**之后**的页即便已取回也**一律不采纳**(故 `rooms` 与串行
        完全一致,不会混入"越界页"的房)。终止条件与旧实现同序同义:

            取页失败(None) → "error"     (该页不计入 pages,rooms 保留已采纳的)
            空 list         → "empty"     (该页计入 pages,无房可加)
            hasNextPage==0  → "hasNextPage"(该页计入 pages,房照常采纳)
            触达 max_pages  → "max_pages" (truncated=True)

        返回:
          rooms      —— 全部去重后的真实房号(str 列表,保序)
          pages      —— 成功解析的页数
          fetched    —— 累计遇到的 roomId 条目数(去重前)
          truncated  —— 是否因触达 max_pages 护栏而提前收尾
          stopped_by —— 结束原因:"hasNextPage" | "empty" | "max_pages" | "error"
        """
        rooms: List[str] = []
        seen: set = set()
        fetched = 0
        pages_ok = 0
        stopped_by = "empty"
        next_page = 1
        done = False

        while not done and next_page <= self._max_pages:
            # 本波次页号(受 max_pages 护栏钳位)
            wave = list(range(next_page,
                              min(next_page + self._page_conc, self._max_pages + 1)))
            texts = await asyncio.gather(*(self._fetch_page(p) for p in wave))

            for text in texts:             # ← 严格按页序判定,与串行同序
                if text is None:
                    stopped_by = "error"   # 网络失败:结束本轮(下一轮再来)
                    done = True
                    break
                page_rooms, hnp = parse_page(text)
                pages_ok += 1
                fetched += len(page_rooms)
                for rid in page_rooms:
                    if rid not in seen:
                        seen.add(rid)
                        rooms.append(rid)
                if not page_rooms:         # 空页:到底了
                    stopped_by = "empty"
                    done = True
                    break
                if hnp == 0:               # 明确没有下一页
                    stopped_by = "hasNextPage"
                    done = True
                    break
            else:
                # 本波每页都还有下一页 → 继续下一波
                next_page = wave[-1] + 1
                if next_page > self._max_pages:
                    stopped_by = "max_pages"      # 触达护栏
                    done = True
                elif self._page_delay:            # 礼貌间隔改按**波次**计
                    await asyncio.sleep(self._page_delay)

        return {"rooms": rooms, "pages": pages_ok, "fetched": fetched,
                "unique": len(rooms), "truncated": stopped_by == "max_pages",
                "stopped_by": stopped_by}


async def _pg_mirror(coro, what: str) -> None:
    """发现房 last_seen 的 PG 镜像写(**尽力而为**):PG 抖动不阻断 Redis 主路径;
    时钟真相由后续轮次的 GREATEST upsert / 删除自行收敛。"""
    try:
        await coro
    except Exception as e:
        log.warning("[发现] %s 落 PG 失败(不阻断,下轮收敛): %r", what, e)


async def reconcile_discovered(bus: Any, db: Any, swept: Dict[str, Any],
                               cfg: Any) -> Dict[str, Any]:
    """把一轮 sweep 结果并入运行态(worker 发现循环与 CLI 共用,保证逻辑一致):

      ① 自愈:任何"策展房(PG active)"若泄漏进发现集(漏转正/重启回灌竞态)本轮移出,
         保证不变式「策展房绝不在发现集」→ 策展房必在一个周期内恢复前端可见;
      ② 登记新发现房(仅 Redis 名录,**不落 PG rooms**)并在 warmup 窗口内错峰起抓;
      ③ 刷新所有在播发现房的 last_seen(离线回收判定依据),并**镜像进 PG
         discovered_rooms 表** —— 回收 grace 长达 7 天,时钟必须跨 Redis/容器重启存续
         (compose 里 Redis 关持久化),重启后由 restore_discovered 回灌;
      ④ 离线回收:连续 grace 未再出现的发现房移除其抓取,并级联清空该房
         rounds/predictions 全部历史(回收即清史);
         仅在遍历成功且非空时执行,避免网络失败/空响应误伤全量发现房。

    参数:bus=RedisBus;db=具异步 active_rooms()/discovered_* 的对象(PG);
    cfg=DiscoveryCfg。返回并入统计(new_admitted / pruned / manual_total / nowv)。
    """
    from .redis_bus import now_ms, task_hist, task_mainpage   # 延迟导入(解析器单测不牵连 Redis)
    from .scheduler import effective_hist_interval_ms
    nowv = now_ms()
    live = swept.get("rooms") or []

    # 策展列表(PG active)。发现房不落 PG rooms,故此集只含用户显式添加的房。
    try:
        manual = {str(r["room_id"]) for r in await db.active_rooms()}
    except Exception:
        manual = set()

    active = set(await bus.active_rooms())          # 全部活跃(策展 + 发现)
    disc_map = await bus.discovered_map()           # 当前发现集 room -> last_seen
    leaked = [r for r in manual if r in disc_map]   # 自愈①
    if leaked:
        await bus.discovered_remove_bulk(leaked)
        await _pg_mirror(db.discovered_delete_bulk(leaked), "转正自愈清理")
        for r in leaked:
            disc_map.pop(r, None)

    to_mark = [r for r in live if r not in manual]  # 待标记发现房(排除策展房)
    new = [r for r in to_mark if r not in active]   # 全新房 → 登记 + 错峰起抓 ②
    if new:
        await bus.add_rooms_bulk([(r, r) for r in new])
        # hist-mode(3.5.0):启用时发现房直接以 hs 轮询任务起抓 —— 首拍满窗
        # U(0,T) 铺开(warmup 60s 窗会造出"每 T 一次的 60s 梳齿");首页即含
        # 近 30 局,首拍最迟 T 后到账、义务窗自该页起,数据零缺口。禁用时
        # 逐字节走既有 mp+warmup 路径。设置经进程单例懒读:配置中枢原地热更
        # 后,下一轮遍历即按新模式起抓(与 discovery 其它逐轮携入项同姿态)。
        _hm = getattr(_settings_singleton(), "histmode", None)
        if getattr(_hm, "enabled", False):
            await bus.schedule_spread([task_hist(r) for r in new],
                                      nowv, effective_hist_interval_ms(_hm))
        else:
            await bus.schedule_spread([task_mainpage(r) for r in new],
                                      nowv, cfg.warmup_window_ms)
    # ★ 5.0.6 直播状态·零成本正信号:本轮 sweep 的 rooms 是**在播全集**(含策展房,
    #   只是策展房不写发现集)。策展房出现在里面 = 此刻在播 —— 实测在册房 2 分钟后
    #   逐个复核 roomStatus,60 房中 59 房仍 liveStatus=1。顺手记一笔即可,零请求;
    #   缺席的房不在此判(列表是推荐流,45s 两轮实测缺席者 35% 仍在播),交由
    #   worker._livestatus 逐房 roomStatus 定谳。开关关闭时一条命令都不多花。
    _ls = getattr(_settings_singleton(), "livestatus", None)
    if getattr(_ls, "enabled", False) and manual:
        live_manual = [r for r in live if r in manual]
        if live_manual:
            with contextlib.suppress(Exception):
                await bus.livestatus_set_bulk([(r, 1) for r in live_manual], ts=nowv)
    if to_mark:                                     # 刷 last_seen ③(Redis + PG 镜像)
        await bus.discovered_seen_bulk(to_mark, ts=nowv)
        await _pg_mirror(db.discovered_upsert_bulk(
            [(r, nowv) for r in to_mark],
            batch_size=max(1, int(getattr(cfg, "batch_size", 500)))),
            "last_seen 镜像")

    pruned = 0                                      # 离线回收 ④
    purged_hist: Dict[str, int] = {}
    if (cfg.prune_grace_s > 0 and swept.get("stopped_by") != "error"
            and swept.get("unique", 0) > 0):
        cutoff = nowv - int(cfg.prune_grace_s) * 1000
        live_marked = set(to_mark)                  # 本轮已刷新 last_seen 的房
        stale = [r for r, seen in disc_map.items()
                 if r not in live_marked and r not in manual and seen < cutoff]
        if stale:
            await bus.discovered_prune_bulk(
                stale, batch_size=max(1, int(getattr(cfg, "batch_size", 500))))
            await _pg_mirror(db.discovered_delete_bulk(stale), "离线回收清理")
            # 级联清史:回收即清空该房 rounds/predictions 全部历史(分批限流;
            # 失败不阻断——时钟已删不会复活抓取,残史至多由 retention 滚动兜底)。
            try:
                purged_hist = await db.purge_rooms_history(stale)
                log.info("[发现] 离线回收 %d 房并清空历史:rounds=%d predictions=%d",
                         len(stale), purged_hist.get("rounds", 0),
                         purged_hist.get("predictions", 0))
            except Exception as e:
                log.warning("[发现] 回收房历史清理失败(残史由 retention 兜底): %r", e)
            pruned = len(stale)

    return {"nowv": nowv, "new_admitted": len(new), "pruned": pruned,
            "purged_rounds": purged_hist.get("rounds", 0),
            "purged_predictions": purged_hist.get("predictions", 0),
            "manual_total": len(manual)}


async def restore_discovered(bus: Any, db: Any, cfg: Any) -> Dict[str, Any]:
    """worker 启动回灌:PG discovered_rooms → 运行态(Redis 名录 + 发现集 + 起抓)。

    发现房的名录/调度只存 Redis(compose 里 Redis 关持久化),而回收 grace 默认
    **7 天** —— 若不回灌,一次 Redis/容器重启就会把所有**当时离线**的发现房提前
    清零(它们不在下一轮在播列表里,无从重建),违背「连续 ≥grace 未检测到才移除」
    的语义。故 worker 启动时按 PG 里的 last_seen 时钟恢复:

      · 已转正(现属策展列表)的:跳过,并清掉 PG 残行(转正后 rooms 表才是真相);
      · last_seen 已超 grace 的:不再恢复,直接清 PG 行并级联清空其历史
        (与常规离线回收同口径);
      · 其余:HSETNX 回灌 last_seen(**运行态更新者恒胜**,多副本并发/与首轮遍历
        竞态皆无害),未在名录的重新登记并错峰起抓。

    幂等,多 worker 副本并发执行安全。返回统计(restored/admitted/expired/promoted)。
    """
    from .redis_bus import now_ms, task_hist, task_mainpage
    from .scheduler import effective_hist_interval_ms
    nowv = now_ms()
    try:
        rows = await db.discovered_all()
    except Exception as e:
        log.warning("[发现] 启动回灌读 PG 失败(跳过;在播房将由遍历重建): %r", e)
        return {"restored": 0, "admitted": 0, "expired": 0, "promoted": 0}
    if not rows:
        return {"restored": 0, "admitted": 0, "expired": 0, "promoted": 0}
    try:
        manual = {str(r["room_id"]) for r in await db.active_rooms()}
    except Exception:
        manual = set()

    grace_ms = int(cfg.prune_grace_s) * 1000 if cfg.prune_grace_s > 0 else None
    fresh: List[tuple] = []
    expired: List[str] = []
    promoted: List[str] = []
    for r in rows:
        rid, ts = str(r["room_id"]), int(r["last_seen_ms"])
        if rid in manual:
            promoted.append(rid)                    # 已转正:策展房不进发现集
        elif grace_ms is not None and ts < nowv - grace_ms:
            expired.append(rid)                     # 已超 grace:等价回收
        else:
            fresh.append((rid, ts))

    admitted = 0
    if fresh:
        await bus.discovered_restore_bulk(fresh)    # HSETNX:运行态更新者胜
        active = set(await bus.active_rooms())
        to_admit = [rid for rid, _ in fresh if rid not in active]
        if to_admit:
            await bus.add_rooms_bulk([(r, r) for r in to_admit])
            # hist-mode(3.5.0):启用时回灌房以 hs 轮询满窗起步(冷启动万房
            # 挤 60s 窗 = 167/s 突刺 + 之后每 T 一次同宽梳齿;满窗后恒 ≈N/T)。
            _hm = getattr(_settings_singleton(), "histmode", None)
            if getattr(_hm, "enabled", False):
                await bus.schedule_spread([task_hist(r) for r in to_admit],
                                          nowv, effective_hist_interval_ms(_hm))
            else:
                await bus.schedule_spread([task_mainpage(r) for r in to_admit],
                                          nowv, cfg.warmup_window_ms)
            admitted = len(to_admit)
    drop = expired + promoted
    if drop:
        await _pg_mirror(db.discovered_delete_bulk(drop), "回灌期清理")
    if expired:
        # 与常规离线回收同口径:超期即清空该房历史(promoted 是策展房,绝不清)。
        try:
            hist = await db.purge_rooms_history(expired)
            log.info("[发现] 回灌期回收 %d 房并清空历史:rounds=%d predictions=%d",
                     len(expired), hist.get("rounds", 0),
                     hist.get("predictions", 0))
        except Exception as e:
            log.warning("[发现] 回灌期历史清理失败(残史由 retention 兜底): %r", e)

    return {"restored": len(fresh), "admitted": admitted,
            "expired": len(expired), "promoted": len(promoted)}
