"""
constants.py — 上游端点、时序常量、妖兽/法术元数据
================================================================================
这些值来自旧引擎 spell_tamer_monitor.py,是游戏侧的**静态事实**(端点路径、
一局的时序偏移、9 只妖兽的官方 id/名称/法术/倍率)。抓取端与 Web 端共用,
保证观测台九法阵、序列计时与旧版逐字节一致。
"""
from __future__ import annotations

from datetime import timedelta, timezone
from typing import Dict, List, Tuple

# ── 时区:整项目统一北京时间(UTC+8,无夏令时) ────────────────────────────────
# 固定偏移、不依赖系统 tzdata:所有落库/展示的"本地时间"(draw_local/date_local/
# _iso/日界)一律按此换算,与部署机器/容器时区无关(与引擎 BEIJING_TZ 同义)。
BEIJING_TZ = timezone(timedelta(hours=8), "Asia/Shanghai")

# ── 上游 API ────────────────────────────────────────────────────────────────
API_PREFIX = "/kugou/spell_tamer.SpellTamerApi"
EP_MAIN_PAGE = f"{API_PREFIX}/MainPage"
EP_GAME_HISTORY = f"{API_PREFIX}/GameHistory"
EP_ROUND_AWARD = f"{API_PREFIX}/RoundAward"
EP_POP_LIST = f"{API_PREFIX}/PopList"
EP_LAMP_LIST = f"{API_PREFIX}/LampList"

# ── 一局时序(毫秒) ──────────────────────────────────────────────────────────
ROUND_STEP = 50001        # 相邻两局 roundId(=起点毫秒)的步进


def rounds_for_hours(hours: float) -> int:
    """N 小时的训练窗覆盖多少局。**训练窗↔局数换算的单一真源。**

    同一判据目前有三处消费者,必须同规则(分歧会让运维在一处看到 ✘、另一处没动静):
      · app/config_center.py  管理台保存时的语义校验(直接 import 本函数);
      · app/predictor_bridge.py  worker 启动/热更时的护栏告警 —— 它**不能**
        import 本模块:该文件被 window_audit/replay_harness.py 用
        spec_from_file_location 当**顶层模块**单独加载,任何相对 import 都会
        `ImportError: attempted relative import with no known parent package`
        把整套审计工具打死(已实测)。故它自行从 E.ROUND_STEP 推导,
        由 tests/test_prior_shrink.py 钉住两处等值;
      · window_audit/audit-maxxiang.sh  离线配置耦合体检(公式逐字同源)。
    """
    return int(float(hours) * 3600.0 * 1000.0 / ROUND_STEP) + 1


# ── 训练窗的两个实测刻度(4.9.5 窗口审计;单一真源,勿在别处复制字面量)────────────
# 背景:frontier 风格下,训练序列的**唯一**出口是 9 格频率直方图 `_p_frontier`,
# 它喂给 LP 解出 126 个四码集合的使用频率。于是「训练样本够不够」这件事有一个
# 可测的定义:**用全样本真频去评估小样本解出来的那份方案**,看它离收敛值差多少。
# 自带三房库(36,278 局)5 个起点的实测(window_audit/ 的扫描台可复跑):
#     n=1 →49.3%  n=10→46.7%  n=30→50.3%  n=100→51.5%  n=200→51.0%
#     n=400→52.8%  n=864→53.0%  n=1728→53.0%  n=5184→53.0%
# ⇒ 收敛点在 400~864 局之间;200 局仍差约 2pp。
#
# 训练时间窗的**硬下限**(小时)。低于它,四码命中实测退化到 45.7~50.8%,而四选九
# 的随机基线是 4/9 = 44.44% —— 即产品退化成掷骰子,故由 config_center 判 error
# 而非 warning。取 3h 的两条依据:①它≈216 局,是上表里第一个明显脱离随机的量级;
# ②它 ≥ prediction.fr_replan(默认 200 局)的重规划节拍,保证每次重解 LP 时窗口内
# 至少有一个完整节拍的数据。**0 不在此列**:0 表示「不限时间、改由 max_train 计数
# 封顶」,是 max_train 告警明确推荐的表达方式,必须放行。
MIN_TRAIN_WINDOW_H = 3.0
# 硬下限对应的局数。**必须推导、不得写字面量** —— 写死 216 就是把
# ROUND_STEP 的换算复制了一份,上游一改步进两处即分家(本文件 rounds_for_hours
# 的 docstring 反复强调的正是这条纪律)。
MIN_TRAIN_ROUNDS = rounds_for_hours(MIN_TRAIN_WINDOW_H)
# 官方 GameHistory 固定只保留最近 N 局(游戏侧静态事实;旧引擎两处实证注明 +
# 仿真/修复台双证)。hist-mode(3.5.0)的轮询周期上限由它推导:两次成功轮询
# 间隔一旦超过 N×ROUND_STEP(≈1500s),滑出页窗的局**永久不可再取得**。
HIST_PAGE_ROUNDS = 30
DRAW_OFFSET_MS = 40_000   # 出怪 = 起点 + 40s
END_OFFSET_MS = 50_000    # 结束 = 起点 + 50s
SPELL_OFFSET_MS = 35_000  # 施法截止 = 起点 + 35s(观测台 T.CAST)

RARE_MULTIPLIER_THRESHOLD = 250

# ── 💎稀有出怪的**日志**阈值(与上面的展示阈值解耦;可经 settings.rare_log_multiplier 覆盖)──
# ⚠ 4.9.0 更正:本段原按**公示概率**推容量,而公示与实盘长期不符,数字整体偏低。
#   公示(mock/data/room-321-config.json,游戏方现行声明,已核对):
#       白虹骥 6.5% + 焚天雀 3.5% + 沧溟龙 2.0% = 12.0%
#   实盘(三房 7 天 36,278 局实测,window_audit/prob_drift.py 可复跑):
#       白虹骥 6.53% + 焚天雀 4.93% + 沧溟龙 3.56% = **15.02%**
#   两者差异极显著(合计 χ²=726.6/df=8;沧溟龙 z=+21.2)——这是游戏方公示与实盘
#   长期不一致的**既有事实**,不是我们的表抄错了(公示值照录不改,前端「官方」列
#   与 2σ 着色维持现状)。但**做容量规划必须用实盘值**,下面按实测重算:
#     倍率 ≥250 的妖兽 = **15.02% 的出怪**(公示口径 12.0%)
# 而 worker 对"稀有"出怪打 INFO(其余逐局日志已降 DEBUG)。于是:
#     1 万房 ≈ 200 局/s  →  💎 INFO ≈ **30 行/s ≈ 260 万行/天**(公示口径会算成 24 行/s)
# 这与 README「稳态日志量与房间数解耦」的设计声明**直接矛盾**,且会把真正有用的
# 高层日志(janitor 统计 / discovery / retention / 各类 WARNING)挤出轮转窗口
# (json-file 50MB×5 下只剩 ~1.5 天可回看)。
#
# 默认取 **500** —— 只有沧溟龙入选,才是名副其实的"稀有"。阈值取值不受上述更正影响
# (沧溟龙无论按 2.0% 还是 3.56% 都是唯一 ≥500 的),但**流量要按实测算**:
#     1 万房 → ≈**7 行/s**(实测 3.56%;公示口径会算成 4 行/s),
#     日志可回看窗口 ≈ **5 天**(公示口径会算成 ~9 天)—— 按 9 天规划存储会踩空。
# 想恢复旧行为(250)在 config.yaml 里设 `rare_log_multiplier: 250` 即可。
RARE_LOG_MULTIPLIER_THRESHOLD = 500

# ── 浏览器请求头(与旧引擎一致;上游对 UA/Origin 等有校验) ───────────────────
DEFAULT_BROWSER_HEADERS: Dict[str, str] = {
    "accept": "application/json",
    "accept-language": "zh-CN,zh;q=0.9",
    "cache-control": "no-cache",
    "content-type": "application/json",
    "origin": "https://game.tme.kugou.com",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "referer": "https://game.tme.kugou.com/",
    "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "user-agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
    ),
}

# (official_id, 妖兽名, 法术, 倍率)
BEASTS_BASE: List[Tuple[int, str, str, int]] = [
    (1, "金羽皇", "御金术", 100),
    (2, "苍梧魔", "御木术", 50),
    (3, "沧溟龙", "御水术", 500),
    (4, "焚天雀", "御火术", 330),
    (5, "镇岳甲", "御土术", 10),
    (6, "白虹骥", "御剑术", 250),
    (7, "踏荒牛", "御道术", 50),
    (8, "青鸾凤", "御丹术", 50),
    (9, "玄兵猿", "御器术", 100),
]

DEFAULT_CUSTOM_IDS: Dict[str, int] = {
    "镇岳甲": 1, "苍梧魔": 2, "焚天雀": 3, "白虹骥": 4, "玄兵猿": 5,
    "金羽皇": 6, "踏荒牛": 7, "青鸾凤": 8, "沧溟龙": 9,
}


# ── 官方公示出怪概率(按**官方 beast_id** 键入,单位 %) ────────────────────────
# 唯一真源与 mock/data/room-321-config.json 对齐,由
# tests/test_official_probability.py::test_constants_match_shipped_config 逐项钉住。
# 为什么按 beast_id 而不是号位:display_number 可被 settings.custom_beast_ids 覆盖,
# 按号位键入则改一次自定义编号就全体串位,而且**照样不报错**。
# ⚠ 它是「官方公示值」,不是实盘频率 —— 二者的系统性偏离(号9 公示 2.00%/实测
#    3.561%,z=+21.2)由 tests/test_probability_drift.py 单独钉住,勿用实测值覆盖本表。
OFFICIAL_PROBABILITY: Dict[int, float] = {
    1: 10.0,    # 金羽皇 100x
    2: 16.0,    # 苍梧魔  50x
    3: 2.0,     # 沧溟龙 500x
    4: 3.5,     # 焚天雀 330x
    5: 20.0,    # 镇岳甲  10x
    6: 6.5,     # 白虹骥 250x
    7: 16.0,    # 踏荒牛  50x
    8: 16.0,    # 青鸾凤  50x
    9: 10.0,    # 玄兵猿 100x
}


def fmt_probability(pct: float) -> str:
    """格式化成与配置文件**逐字符一致**的百分串(20.00% 而非 20% / 20.0%)。
    两条加载路径(读配置 / 妖兽表兜底)给前端的字段因此没有任何差异。"""
    return f"{float(pct):.2f}%"


def _check_probability_table() -> None:
    """概率表自洽校验。**必须是真 raise 而不是 assert** —— `python -O` /
    PYTHONOPTIMIZE 会把 assert 整条剥掉,那样一张 179% 的表能静默 import 成功。
    一个专治静默失真的补丁,自己不能留静默口子。"""
    if sorted(OFFICIAL_PROBABILITY) != list(range(1, 10)):
        raise ValueError(f"OFFICIAL_PROBABILITY 必须覆盖 beast_id 1~9: "
                         f"{sorted(OFFICIAL_PROBABILITY)}")
    total = round(sum(OFFICIAL_PROBABILITY.values()), 6)
    if total != 100.0:
        raise ValueError(f"OFFICIAL_PROBABILITY 合计 {total}% ≠ 100%")
    mult = {oid: m for oid, _n, _s, m in BEASTS_BASE}
    rtp = round(sum(OFFICIAL_PROBABILITY[o] * mult[o] / 100 for o in mult), 2)
    if rtp != 83.80:
        raise ValueError(f"RTP={rtp}% —— 概率与倍率的配对疑似串位(应为 83.80%)")


_check_probability_table()


def build_beast_meta(custom_ids: Dict[str, int] | None = None):
    """返回 (by_official_id, by_custom_id) 两张元数据表。"""
    cids = {**DEFAULT_CUSTOM_IDS, **(custom_ids or {})}
    by_official: Dict[int, dict] = {}
    by_cid: Dict[int, dict] = {}
    for oid, name, spell, mult in BEASTS_BASE:
        cid = int(cids.get(name, DEFAULT_CUSTOM_IDS[name]))
        key = spell[1] if len(spell) >= 2 else ""   # 御X术 → X
        meta = {
            "beast_id": oid, "beast_name": name, "spell_name": spell,
            "spell_key": key, "display_number": cid, "multiplier": mult,
            # 概率必须随元数据一起给出。历史缺陷:兜底路径把它填成空串 "",
            # 前端 officialProb 解不出就静默回落均匀 100/9≈11.11%,于是出怪司历的
            # 「官方/偏差」两列与九法阵出怪规律态**全部按错误基线计算**,不报错、
            # 不缺图、不白屏 —— 只是给出一个看起来很专业的错误结论。
            "probability": fmt_probability(OFFICIAL_PROBABILITY[oid]),
        }
        by_official[oid] = meta
        by_cid[cid] = meta
    return by_official, by_cid
