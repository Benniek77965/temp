"""
powproof.py — 执行证明变换 T(单一真相源,4.0.0 抽出)
================================================================================
原实现在 app/web.py::_pow_answer(L2 执行证明闸,3.9.1)。注册系统(4.0.0)的
R2「浏览器执行证明 ⊕ 工作量证明」需要在 app/userauth.py 复用同一变换,而
web.py 在顶层 import userauth —— 若 userauth 反向 import web 会成环。故把 25 行
纯函数抽到本模块,web.py 以同名别名回挂(`web._pow_answer` 继续存在,
tests/test_proof_of_browser.py 的黄金向量 / 活体对拍钉子零改动、继续生效)。

**必须与前端 assets/app.js 的 powAnswer() 逐位一致**(已用 1000 组随机输入含
中文/符号做 Python↔JS 字节级对拍;部署混淆是语义保持的,不改变其输出)。
选用非标准算法(而非 HMAC/SHA)是刻意的:搬运器无法调库,必须**跑这段 JS
或逆向它**。任何一侧改动而另一侧没跟上 → 全体已登录用户被 401 锁死
(L2 开启时)+ 注册 PoW 全体失败 —— 改前先看 test_proof_of_browser.py。
"""
from __future__ import annotations

M32 = 0xFFFFFFFF


def imul32(a: int, b: int) -> int:
    """32 位无符号乘法(对应 JS Math.imul 的 >>>0 语义)。"""
    return ((a & M32) * (b & M32)) & M32


def pow_answer(challenge: str) -> str:
    """执行证明变换 T:两个 32 位累加器交织 + 终混,输出 16 位十六进制。"""
    h1 = 0x811c9dc5
    h2 = 0x1000193
    for i, chc in enumerate(challenge):
        c = ord(chc) & M32
        h1 = imul32(h1 ^ c, 0x01000193)
        h1 = ((h1 << 13) | (h1 >> 19)) & M32
        h2 = imul32((h2 + c + i) & M32, 0x85ebca6b)
        h2 = h2 ^ (h2 >> 15)
        h1 = (h1 + h2) & M32
    h1 ^= h1 >> 16
    h1 = imul32(h1, 0x7feb352d)
    h1 ^= h1 >> 15
    h2 ^= h2 >> 13
    h2 = imul32(h2, 0x846ca68b)
    h2 ^= h2 >> 16
    return format(h1 & M32, "08x") + format(h2 & M32, "08x")
