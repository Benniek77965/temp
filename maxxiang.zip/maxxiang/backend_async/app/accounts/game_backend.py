# -*- coding: utf-8 -*-
"""
game_backend.py — 九法降妖 · 真实游戏后端(官方 spell_tamer 接口代理)· 1.0.0

本模块给观测台加「真实游戏」能力:用**账号列表中当前选择的账号**的登录票据
(ticket = token = Cookie 里的参数 t)以官方链路直连酷狗/腾讯音乐的降妖玩法接口
(spell_tamer.SpellTamerApi),渲染真实盘面、真实历史、真实「我的记录」,并可
**亲手施法**(真实扣除星币、真实出怪)。

━━━ 鉴权(经真机 HAR 逐字节验证) ━━━
  官方所有降妖接口只认一枚**票据**,三处同源:
    · mapi.tencentmusic.com 系列:请求头 x-auth-ticket
    · fx.service.kugou.com/consume/preOrder:请求头 token
    · SpellUse 请求体 payInfo.mapExt.token
  票据 = 账号 Cookie 中的 t(= 登录 token)。uid = kugouId,token-type = 1010,
  app-id = 1000756。**不依赖 Cookie 会话**,单枚票据即可鉴权 —— 故只要账号有效
  (有效性检测通过),真实游戏即可运行。

━━━ 接口清单(全部 POST,JSON body,JSON 响应) ━━━
  MainPage            {activityId, roomId}                → 盘面(9 法术/妖兽/倍率 + 本局计时 + canPlay)
  GameHistory         {activityId, roomId}                → 近若干局出的妖兽(序列)
  RoundAward          {activityId, roundId, roomId}       → 某局出怪 + 本人命中明细
  UserGameRecordList  {activityId}                        → 「我的记录」
  RankList            {activityId, rankType, rankCategory} → 榜单
  施法(两步):
    ① preOrder  fx.service.kugou.com/kugou_adapter/public/consume/preOrder
       {businessId, price, toUid=主播, std_rid=房, std_kid=本人, std_dev, dfid, ...}
       → {code:0, data:{orderId}}
    ② SpellUse  mapi.../SpellUse
       {activityId, roundId, spellId, count, payApp, paySceneInfo, orderId, payInfo{mapExt{token,...}}}
       → 成功(扣星币、发经验/礼物)或 {code:30418,"余额不足"} / 票据失效 …

设计取舍:取数出口复用 server.py 注入的容灾 fetch(Chrome-TLS/多通道),与账号
模块同源;主播 UID 复用 server.py 注入的繁星资料代理(房号 → starKgId)。
"""

import json
import re
import time
import uuid
import threading

# ─────────────────────────────────────────────────────────────────────────────
# 官方常量(出自实测 HAR + 项目自带 spell_tamer_monitor.py,逐字节一致)
# ─────────────────────────────────────────────────────────────────────────────
MAPI_BASE = "https://mapi.tencentmusic.com"
API_PREFIX = "/kugou/spell_tamer.SpellTamerApi"
EP_MAIN_PAGE = f"{API_PREFIX}/MainPage"
EP_GAME_HISTORY = f"{API_PREFIX}/GameHistory"
EP_ROUND_AWARD = f"{API_PREFIX}/RoundAward"
EP_USER_RECORDS = f"{API_PREFIX}/UserGameRecordList"
EP_RANK_LIST = f"{API_PREFIX}/RankList"
EP_SPELL_USE = f"{API_PREFIX}/SpellUse"
PREORDER_URL = "https://fx.service.kugou.com/kugou_adapter/public/consume/preOrder"

ACTIVITY_ID = 2
AUTH_APP_ID = "1000756"      # x-auth-app-id(降妖玩法固定)
TOKEN_TYPE = "1010"          # x-auth-token-type(= 酷狗直播 appid)
BUSINESS_ID = "8002556"      # 降妖玩法消费业务 id
CURRENCY_TYPE = "121"        # 星币
STD_PLAT = "7"               # PC web 直播
CHANNEL = "0"
CONSUME_APPID = "1010"

# 妖兽 ↔ 法术 ↔ 倍率(spellId 1..9,官方原生映射,与 MainPage 返回一致)
BEASTS_BASE = [
    (1, "金羽皇", "御金术", 100),
    (2, "苍梧魔", "御木术", 50),
    (3, "沧溟龙", "御水术", 500),
    (4, "焚天雀", "御火术", 330),
    (5, "镇岳甲", "御土术", 10),
    (6, "白虹骥", "御剑术", 250),
    (7, "踏荒牛", "御道术", 50),
    (8, "青鸾凤", "御丹术", 50),
    (9, "玄兵猿", "御器术", 100),
]
SPELL_META = {b[0]: {"beastName": b[1], "spellName": b[2], "multiplier": b[3]}
              for b in BEASTS_BASE}

BROWSER_HEADERS = {
    "accept": "application/json",
    "accept-language": "zh-CN,zh;q=0.9",
    "cache-control": "no-cache",
    "content-type": "application/json",
    "origin": "https://game.tme.kugou.com",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "referer": "https://game.tme.kugou.com/",
    "sec-ch-ua": '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "user-agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"),
}

# ── 注入点(server.py 提供;缺省时降级)──
_FETCH = None            # fn(url, timeout, headers=None, jar=None, data=None) -> (status, text, resp_headers)
_ACCOUNT_PROVIDER = None  # fn() -> 当前账号原始 dict(含 cookie/token/mid/kugouId)或 None
_PROFILE_PROVIDER = None  # fn(room) -> {kugouId, nickname, avatar,...}(房号 → 主播 UID)


def set_fetchers(fetch_fn):
    global _FETCH
    _FETCH = fetch_fn


def set_account_provider(fn):
    global _ACCOUNT_PROVIDER
    _ACCOUNT_PROVIDER = fn


def set_profile_provider(fn):
    global _PROFILE_PROVIDER
    _PROFILE_PROVIDER = fn


# ── 主播 UID 缓存(房号 → starKgId),避免每次施法都回查 ──
_ANCHOR_CACHE = {}       # room -> (expire_ts, uid)
_ANCHOR_LOCK = threading.Lock()


def _default_fetch(url, timeout, headers=None, jar=None, data=None):
    import urllib.request
    h = dict(BROWSER_HEADERS)
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, data=data, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        body = r.read().decode("utf-8", "replace")
        rh = {k: v for k, v in r.headers.items()}
        return r.status, body, rh


def _fetch(url, timeout, headers=None, data=None):
    fn = _FETCH or _default_fetch
    try:
        return fn(url, timeout, headers, None, data)
    except TypeError:
        # 兼容旧签名(无 data)
        if data is None:
            return fn(url, timeout, headers, None)
        raise


# ─────────────────────────────────────────────────────────────────────────────
# 票据 / 身份解析
# ─────────────────────────────────────────────────────────────────────────────
def _cookie_val(cookie_str, name):
    """从 'a=1; b=2' 串里取某 Cookie 值。"""
    if not cookie_str:
        return ""
    for seg in str(cookie_str).split(";"):
        seg = seg.strip()
        if "=" in seg:
            k, v = seg.split("=", 1)
            if k.strip() == name:
                return v.strip()
    return ""


def resolve_ticket(acct):
    """票据 = Cookie 里的 t → 退回 token 字段。用户明确:ticket=token=cookie 参数 t。"""
    if not acct:
        return ""
    t = _cookie_val(acct.get("cookie", ""), "t")
    if t:
        return t
    return str(acct.get("token") or "").strip()


def _device_id(acct):
    """设备指纹(std_dev/kfd/ssad)。优先账号 mid(32 hex,与官方口径一致),
    缺省则由 kugouId 稳定派生(不随机,便于风控识别为同一设备)。"""
    mid = str((acct or {}).get("mid") or "").strip()
    if re.fullmatch(r"[0-9a-fA-F]{32}", mid):
        return mid.lower()
    import hashlib
    seed = str((acct or {}).get("kugouId") or "kugou")
    return hashlib.md5(("dev:" + seed).encode()).hexdigest()


def _dfid(acct):
    """dfid:优先账号存下的真实 dfid;否则由设备 id 稳定派生一个 24 位串占位。
    (dfid 主要用于风控,真实 dfid 命中率更高;占位仅保证格式与流程完整。)"""
    d = str((acct or {}).get("dfid") or "").strip()
    if d and d != "-":
        return d
    import base64
    import hashlib
    raw = hashlib.md5(("dfid:" + _device_id(acct)).encode()).digest()
    return base64.b64encode(raw).decode().replace("+", "0").replace("/", "0").replace("=", "")[:24]


def _auth_headers(acct):
    ticket = resolve_ticket(acct)
    return {
        "x-auth-app-id": AUTH_APP_ID,
        "x-auth-uid": str(acct.get("kugouId") or ""),
        "x-auth-ticket": ticket,
        "x-auth-token-type": TOKEN_TYPE,
    }


def current_account():
    """当前选择的账号(原始 dict,含票据)。无账号返回 None。"""
    if _ACCOUNT_PROVIDER is None:
        return None
    try:
        return _ACCOUNT_PROVIDER()
    except Exception:
        return None


def _account_public(acct):
    """给前端的账号摘要(不含票据/Cookie/mid)。"""
    if not acct:
        return None
    logo = acct.get("userLogo") or ""
    return {
        "kugouId": str(acct.get("kugouId") or ""),
        "nickName": acct.get("nickName") or ("酷狗" + str(acct.get("kugouId") or "")),
        "userLogo": logo,
        "coin": acct.get("coin", ""),
        "validStatus": acct.get("validStatus", ""),
    }


class GameError(Exception):
    """携带 kind(need_login/invalid/api/network/business)与用户可读 message。"""
    def __init__(self, kind, message, code=None, raw="", step=""):
        self.kind = kind
        self.message = message
        self.code = code
        self.raw = raw
        self.step = step        # 出错阶段:preflight / preOrder / spellUse —— 便于诊断施法链路
        super().__init__(message)


def _require_account():
    acct = current_account()
    if not acct:
        raise GameError("need_login", "尚未添加任何账号,请先扫码登录")
    if not resolve_ticket(acct):
        raise GameError("need_login",
                        "当前账号没有可用登录票据,请重新扫码登录该账号")
    if acct.get("validStatus") == "invalid":
        raise GameError("invalid", "当前账号登录态已失效,请在账号列表重新登录/检测")
    return acct


# ─────────────────────────────────────────────────────────────────────────────
# 官方接口调用
# ─────────────────────────────────────────────────────────────────────────────
def _post_mapi(endpoint, payload, acct, timeout=12.0):
    """POST mapi.tencentmusic.com 系列(x-auth 鉴权)。返回 (json_dict, resp_headers)。
    识别票据失效(401/403 或 X-Error-Code / body code)并抛 GameError。"""
    headers = dict(BROWSER_HEADERS)
    headers.update(_auth_headers(acct))
    data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    name = endpoint.rsplit("/", 1)[-1]
    try:
        status, body, rh = _fetch(MAPI_BASE + endpoint, timeout, headers, data)
    except Exception as e:                       # noqa: BLE001
        raise GameError("network", f"{name} 请求异常:{type(e).__name__}")
    rh = rh or {}
    err_code = rh.get("X-Error-Code") or rh.get("x-error-code")
    err_msg = (rh.get("X-Error-Message") or rh.get("x-error-message")
               or rh.get("X-Error-Msg") or "")
    if status in (401, 403):
        raise GameError("invalid", "登录票据已过期,请重新登录该账号", code=status,
                        raw=(body or "")[:300])
    try:
        j = json.loads(body) if body and body.strip() else {}
    except ValueError:
        j = {"_raw": (body or "")[:300]}
    # 业务错误码(部分接口把错误放响应头,部分放 body.code)
    code = j.get("code") if isinstance(j, dict) else None
    if err_code and str(err_code) not in ("0", ""):
        # 票据/鉴权类
        if str(err_code) in ("20101", "20102", "20103") or "auth" in str(err_msg).lower():
            raise GameError("invalid", f"鉴权失败({err_code}),请重新登录",
                            code=err_code, raw=(body or "")[:300])
    if status != 200 and code is None:
        raise GameError("api", f"{name} HTTP {status}", code=status,
                        raw=(body or "")[:300])
    return (j if isinstance(j, dict) else {}), rh


def _room_of(q):
    room = (q.get("room") or q.get("roomId") or [""])[0]
    return str(room or "").strip()


def _anchor_uid(room):
    """房号 → 主播 UID(starKgId)。经繁星资料代理解析,缓存 10 分钟。"""
    room = str(room or "").strip()
    if not room:
        return ""
    with _ANCHOR_LOCK:
        hit = _ANCHOR_CACHE.get(room)
        if hit and hit[0] > time.time():
            return hit[1]
    uid = ""
    if _PROFILE_PROVIDER is not None:
        try:
            payload = _PROFILE_PROVIDER(room) or {}
            # fx_star_profile 返回 {ok, profile:{kugouId, nickname, ...}} —— 主播 UID 在 profile 子字典里,
            # 之前直接在顶层取 kugouId 恒为空 → 施法在 preflight 阶段被判「未能解析主播」。此处解包修正。
            prof = payload.get("profile") or payload
            kid = prof.get("kugouId") or prof.get("starKgId") or prof.get("userId") or 0
            uid = str(kid).strip()
            if uid in ("0", "None", ""):
                uid = ""
        except Exception:
            uid = ""
    if uid:
        with _ANCHOR_LOCK:
            _ANCHOR_CACHE[room] = (time.time() + 600, uid)
    return uid


def _norm_spell_list(raw_list):
    """规整 MainPage/记录里的 spellList,补全倍率/beast,统一给前端。"""
    out = []
    for s in (raw_list or []):
        sid = s.get("spellId")
        meta = SPELL_META.get(sid, {})
        bi = s.get("beastInfo") or {}
        out.append({
            "spellId": sid,
            "spellName": s.get("spellName") or meta.get("spellName", ""),
            "spellLogo": s.get("spellLogo") or "",
            "spellDesc": s.get("spellDesc") or "",
            "awardDesc": s.get("awardDesc") or "",
            "spellPrice": s.get("spellPrice") or 1000,
            "iconFootText": s.get("iconFootText") or (f"{meta.get('multiplier','')}倍"),
            "multiplier": meta.get("multiplier"),
            "spellNum": s.get("spellNum", 0),
            "lastSpellNum": s.get("lastSpellNum", 0),
            "beast": {
                "beastId": bi.get("beastId") or sid,
                "beastName": bi.get("beastName") or meta.get("beastName", ""),
                "beastLogo": bi.get("beastLogo") or "",
                "beastIcon": bi.get("beastIcon") or "",
            },
        })
    # 稳定按 spellId 升序(前端 1..9 网格),缺失项前端补位
    out.sort(key=lambda x: (x["spellId"] is None, x["spellId"]))
    return out


# ─────────────────────────────────────────────────────────────────────────────
# 高层动作
# ─────────────────────────────────────────────────────────────────────────────
def main_page(room, acct):
    j, _ = _post_mapi(EP_MAIN_PAGE, {"activityId": ACTIVITY_ID, "roomId": room}, acct)
    spells = _norm_spell_list(j.get("spellList"))
    return {
        "serverTime": j.get("serverTime"),
        "roundId": j.get("roundId"),
        "spellTime": j.get("spellTime"),
        "drawTime": j.get("drawTime"),
        "endTime": j.get("endTime"),
        "canPlay": bool(j.get("canPlay", True)),
        "tips": j.get("tips") or [],
        "spells": spells,
        "lastMap": j.get("lastMap") or {},
    }


def game_history(room, acct):
    j, _ = _post_mapi(EP_GAME_HISTORY, {"activityId": ACTIVITY_ID, "roomId": room}, acct)
    out = []
    for g in (j.get("gameList") or []):
        bi = g.get("beastInfo") or {}
        out.append({
            "roundId": g.get("roundId"),
            "beastId": bi.get("beastId"),
            "beastName": bi.get("beastName") or SPELL_META.get(bi.get("beastId"), {}).get("beastName", ""),
            "beastIcon": bi.get("beastIcon") or "",
            "beastLogo": bi.get("beastLogo") or "",
            "startTime": g.get("startTime"),
            "endTime": g.get("endTime"),
        })
    return {"gameList": out}


def round_award(room, round_id, acct):
    j, _ = _post_mapi(EP_ROUND_AWARD, {"activityId": ACTIVITY_ID,
                                       "roundId": str(round_id), "roomId": room}, acct)
    bi = j.get("beastInfo") or {}
    return {
        "serverTime": j.get("serverTime"),
        "roundId": round_id,
        "awardStatus": j.get("awardStatus"),   # 0 未参与 / 1 命中 / 2 参与未命中
        "spellId": j.get("spellId"),
        "beast": {
            "beastId": bi.get("beastId"),
            "beastName": bi.get("beastName") or SPELL_META.get(bi.get("beastId"), {}).get("beastName", ""),
            "beastIcon": bi.get("beastIcon") or "",
        },
        "multiplier": j.get("multiplier"),
        "hitScore": j.get("hitScore"),
        "awardList": j.get("awardList") or [],
        "endTime": j.get("endTime"),
    }


def user_records(acct):
    j, _ = _post_mapi(EP_USER_RECORDS, {"activityId": ACTIVITY_ID}, acct)
    out = []
    for r in (j.get("recordList") or []):
        out.append({
            "status": r.get("status"),
            "startTime": r.get("startTime"),
            "spells": _norm_spell_list(r.get("spellList")),
        })
    return {"recordList": out}


def rank_list(acct, rank_type=1, rank_category=0):
    j, _ = _post_mapi(EP_RANK_LIST, {"activityId": ACTIVITY_ID,
                                     "rankType": int(rank_type),
                                     "rankCategory": int(rank_category)}, acct)
    return {"rankList": j.get("rankList") or [], "self": j.get("selfRank") or j.get("self")}


def _pre_order(acct, room, anchor_uid, price):
    """① 下预订单,拿 orderId(真实扣费入口)。token 头 = 票据。"""
    ticket = resolve_ticket(acct)
    kid = str(acct.get("kugouId") or "")
    dev = _device_id(acct)
    dfid = _dfid(acct)
    headers = dict(BROWSER_HEADERS)
    headers.update({
        "appid": CONSUME_APPID, "kgid": kid, "pid": kid, "token": ticket,
        "sec-fetch-site": "same-site", "origin": "https://game.tme.kugou.com",
    })
    body = {
        "businessId": int(BUSINESS_ID), "price": int(price), "toUid": str(anchor_uid),
        "std_rid": int(room) if str(room).isdigit() else room, "std_kid": int(kid) if kid.isdigit() else kid,
        "std_dev": dev, "std_plat": int(STD_PLAT), "channel": int(CHANNEL),
        "kfd": dev, "ssad": dev, "dfid": dfid, "appid": int(CONSUME_APPID), "version": 0,
    }
    data = json.dumps(body, separators=(",", ":")).encode("utf-8")
    try:
        status, text, rh = _fetch(PREORDER_URL, 12.0, headers, data)
    except Exception as e:                       # noqa: BLE001
        raise GameError("network", f"下单请求异常:{type(e).__name__}")
    try:
        j = json.loads(text) if text and text.strip() else {}
    except ValueError:
        raise GameError("api", "下单响应异常", raw=(text or "")[:300])
    code = j.get("code")
    if code not in (0, "0", None):
        msg = j.get("msg") or j.get("message") or f"下单失败(code={code})"
        kind = "invalid" if str(code) in ("10004", "20101") else "business"
        raise GameError(kind, msg, code=code, raw=(text or "")[:300])
    order_id = (j.get("data") or {}).get("orderId") or j.get("orderId")
    if not order_id:
        raise GameError("api", "下单未返回 orderId", raw=(text or "")[:300])
    return order_id, dev, dfid


def cast(room, spell_id, count, round_id, acct, unit_price=None):
    """施法 = ① preOrder 拿 orderId → ② SpellUse 真实扣星币 + 布法。
    返回 {ok, awardStatus?, awardList?, message, orderId} 或抛 GameError。"""
    spell_id = int(spell_id)
    count = max(1, int(count or 1))
    if spell_id not in SPELL_META:
        raise GameError("business", "无效的法术编号", step="preflight")
    anchor_uid = _anchor_uid(room)
    if not anchor_uid:
        raise GameError("business", "未能解析该直播间的主播,暂时无法施法(请稍后重试)", step="preflight")

    meta = SPELL_META[spell_id]
    try:
        unit_price = int(unit_price) if unit_price and int(unit_price) > 0 else 1000
    except (TypeError, ValueError):
        unit_price = 1000      # 单价随法术(spellPrice);缺失/非法时退回 1000,避免与官方价不符导致下单被拒
    total_price = unit_price * count

    try:
        order_id, dev, dfid = _pre_order(acct, room, anchor_uid, total_price)
    except GameError as ge:
        if not getattr(ge, "step", ""):
            ge.step = "preOrder"
        raise

    ticket = resolve_ticket(acct)
    kid = str(acct.get("kugouId") or "")
    payload = {
        "activityId": ACTIVITY_ID,
        "roundId": str(round_id),
        "spellId": spell_id,
        "count": count,
        "payApp": {"businessId": BUSINESS_ID, "currencyType": CURRENCY_TYPE, "actId": str(ACTIVITY_ID)},
        "paySceneInfo": {"paySceneType": "PAY_SCENE_TYPE_LIVE", "anchorId": str(anchor_uid),
                         "roomId": str(room), "showId": ""},
        "orderId": order_id,
        "payInfo": {"goodsItems": [], "mapExt": {
            "token": ticket, "std_rid": str(room), "std_kid": kid, "std_dev": dev,
            "std_plat": STD_PLAT, "channel": CHANNEL, "appid": CONSUME_APPID,
            "kfd": dev, "ssad": dev, "dfid": dfid, "version": "",
        }},
    }
    headers = dict(BROWSER_HEADERS)
    headers.update(_auth_headers(acct))
    data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    try:
        status, text, rh = _fetch(MAPI_BASE + EP_SPELL_USE, 12.0, headers, data)
    except Exception as e:                       # noqa: BLE001
        raise GameError("network", f"施法请求异常:{type(e).__name__}")
    try:
        j = json.loads(text) if text and text.strip() else {}
    except ValueError:
        j = {"_raw": (text or "")[:300]}
    code = j.get("code")
    if code in (0, "0", None) and status == 200:
        return {
            "ok": True,
            "spellId": spell_id,
            "spellName": meta["spellName"],
            "beastName": meta["beastName"],
            "count": count,
            "spent": total_price,
            "orderId": order_id,
            "awardStatus": j.get("awardStatus"),
            "awardList": j.get("awardList") or [],
            "message": f"已对【{meta['beastName']}】施展{meta['spellName']}×{count}",
            "diag": {"step": "spellUse", "unit_price": unit_price, "total": total_price,
                     "orderId": order_id, "spellUseStatus": status, "code": code},
            "raw": j,
        }
    # 业务失败:余额不足 / 本局已结束 / 票据失效 …
    msg = j.get("message") or j.get("msg") or f"施法失败(code={code})"
    kind = "business"
    if str(code) in ("30418",) or "余额" in str(msg):
        kind = "business"
        msg = "星币余额不足"
    elif status in (401, 403) or "auth" in str(msg).lower() or str(code) in ("20101",):
        kind = "invalid"
        msg = "登录票据已过期,请重新登录"
    raise GameError(kind, msg, code=code, raw=(text or "")[:400], step="spellUse")


# ─────────────────────────────────────────────────────────────────────────────
# 路由(被 server.py 调用)
# ─────────────────────────────────────────────────────────────────────────────
def _envelope_error(e):
    """把 GameError 折成恒 ok:true 的信封(前端据 gameOk/error/kind 分流,不走异常)。"""
    return {"ok": True, "gameOk": False, "error": e.kind, "kind": e.kind,
            "message": e.message, "code": e.code,
            "step": getattr(e, "step", ""), "raw": getattr(e, "raw", "")}


def handle_api(path, q):
    """/api/game/* 路由。返回 (status, obj) 或 None(非本模块路由)。
    统一信封:{ok:true, gameOk:bool, ...}。gameOk=false 时带 kind/message,
    kind ∈ need_login / invalid / api / network / business。"""
    if not path.startswith("/api/game/"):
        return None

    # 当前账号摘要(前端头部长期显示「正在选择的账号」用,任何子路由都附带)
    acct_now = current_account()

    try:
        if path == "/api/game/state":
            acct = _require_account()
            room = _room_of(q)
            if not room:
                raise GameError("business", "尚未选择直播间")
            mp = main_page(room, acct)
            return 200, {"ok": True, "gameOk": True, "room": room,
                         "anchorUid": _anchor_uid(room),
                         "account": _account_public(acct), **mp}

        if path == "/api/game/history":
            acct = _require_account()
            room = _room_of(q)
            if not room:
                raise GameError("business", "尚未选择直播间")
            return 200, {"ok": True, "gameOk": True, "room": room, **game_history(room, acct)}

        if path == "/api/game/award":
            acct = _require_account()
            room = _room_of(q)
            rid = (q.get("round") or q.get("roundId") or [""])[0]
            if not (room and rid):
                raise GameError("business", "缺少房间或局号")
            return 200, {"ok": True, "gameOk": True, **round_award(room, rid, acct)}

        if path == "/api/game/records":
            acct = _require_account()
            return 200, {"ok": True, "gameOk": True,
                         "account": _account_public(acct), **user_records(acct)}

        if path == "/api/game/rank":
            acct = _require_account()
            rt = (q.get("type") or ["1"])[0]
            rc = (q.get("cat") or ["0"])[0]
            return 200, {"ok": True, "gameOk": True, **rank_list(acct, rt, rc)}

        if path == "/api/game/cast":
            acct = _require_account()
            room = _room_of(q)
            spell = (q.get("spell") or q.get("spellId") or [""])[0]
            count = (q.get("count") or ["1"])[0]
            rid = (q.get("round") or q.get("roundId") or [""])[0]
            price = (q.get("price") or [""])[0]
            if not (room and spell and rid):
                raise GameError("business", "缺少房间/法术/局号")
            res = cast(room, spell, count, rid, acct, price)
            return 200, {"ok": True, "gameOk": True,
                         "account": _account_public(acct), **res}

        if path == "/api/game/account":
            # 仅回当前选择的账号摘要(前端头部轮询/初始化用)
            return 200, {"ok": True, "gameOk": bool(acct_now),
                         "account": _account_public(acct_now)}

        return None
    except GameError as ge:
        env = _envelope_error(ge)
        env["account"] = _account_public(acct_now)
        return 200, env
    except Exception as ex:                      # noqa: BLE001
        return 200, {"ok": True, "gameOk": False, "error": "api", "kind": "api",
                     "message": f"服务异常:{type(ex).__name__}",
                     "account": _account_public(acct_now)}
