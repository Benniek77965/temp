"""
fetcher.py — accounts_backend 的取数出口(cookie 会话感知 + Chrome TLS 指纹)
================================================================================
accounts_backend 通过 set_fetchers(fetch_json) / set_jar_factory(new_jar) 注入取数
能力。登录链路两处关键:
  1) **cookie 会话一致性**:login_by_token_get 种下的 KugooID/token 等 .kugou.com 域
     Cookie,必须延续到后续 getUserInfo —— 否则「登录成功却取不到星币/头像」。
     故用同一个 http.cookiejar.CookieJar 跨请求累积/回放 Cookie。
  2) **Chrome TLS 指纹**:酷狗对非浏览器客户端(标准库 urllib 的 TLS 指纹)会**扣发
     登录票据**,导致 getUserInfo 判「未登录」→ 星币/头像取不到。故**优先 curl_cffi
     以 Chrome 指纹发请求**(与旧 server.py 的 _account_fetch 首选通道逐字节对齐);
     curl_cffi 未装时退回标准库 urllib(直连兜底,cookie 正确,但 TLS 指纹非 Chrome,
     个别登录态可能取不到星币 —— 见 requirements.txt:强烈建议装 curl_cffi)。

签名契约(accounts_backend 依赖):
  new_jar() -> jar(http.cookiejar.CookieJar)
  fetch_json(url, timeout, headers=None, jar=None, data=None)
      -> (status_int, body_text, resp_headers_dict)
  data 非 None 时以 POST 发送(login_by_token_get 需 POST)。
"""
from __future__ import annotations

import http.cookiejar
import ssl
import urllib.request
from typing import Dict, Optional, Tuple

try:                                   # 首选通道:Chrome TLS 指纹
    from curl_cffi import requests as _CURL   # type: ignore
    _HAS_CURL = True
except Exception:                      # pragma: no cover
    _CURL = None
    _HAS_CURL = False

_CHROME_MAJOR = "150"
_UA = (f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       f"(KHTML, like Gecko) Chrome/{_CHROME_MAJOR}.0.0.0 Safari/537.36")
_ctx_noverify = ssl._create_unverified_context()


def new_jar() -> http.cookiejar.CookieJar:
    """开一个空 Cookie 容器(默认不预置 Cookie —— 与浏览器 HAR 实证一致:创建二维码/
    轮询阶段不带 Cookie,登录/取资料阶段才由会话累积)。"""
    return http.cookiejar.CookieJar()


def _jar_cookies(jar) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if jar is None:
        return out
    for ck in jar:
        out[ck.name] = ck.value
    return out


def _store_cookies(jar, resp_cookies) -> None:
    """把响应 Cookie 并回 jar(域固定 .kugou.com,与浏览器登录态同域,供后续
    getUserInfo 自动携带)。"""
    if jar is None or not resp_cookies:
        return
    try:
        items = dict(resp_cookies).items() if not isinstance(resp_cookies, dict) else resp_cookies.items()
    except Exception:
        return
    for name, value in items:
        try:
            jar.set_cookie(http.cookiejar.Cookie(
                0, name, value, None, False, ".kugou.com", True, True,
                "/", False, True, None, False, None, None, {}))
        except Exception:
            pass


def _curl_fetch(url: str, timeout: float, headers: Optional[dict],
                jar, data) -> Tuple[int, str, Dict[str, str]]:
    """curl_cffi + Chrome TLS 指纹(移植自旧 server.py 的 _curl_cffi_fetch:干净的
    浏览器 fetch 头 + impersonate 版本回退 + Set-Cookie 并回 jar)。"""
    h = {"sec-ch-ua": f'"Not;A=Brand";v="8", "Chromium";v="{_CHROME_MAJOR}", '
                      f'"Google Chrome";v="{_CHROME_MAJOR}"',
         "sec-ch-ua-mobile": "?0", "sec-ch-ua-platform": '"Windows"',
         "user-agent": _UA, "accept": "*/*",
         "origin": "https://fanxing.kugou.com",
         "sec-fetch-site": "same-site", "sec-fetch-mode": "cors",
         "sec-fetch-dest": "empty", "referer": "https://fanxing.kugou.com/",
         "accept-encoding": "gzip, deflate, br, zstd",
         "accept-language": "zh-CN,zh;q=0.9", "priority": "u=1, i"}
    if headers:
        h.update(headers)
    cookies = _jar_cookies(jar)
    method = "POST" if data is not None else "GET"
    # curl_cffi 0.15+ 支持 default_headers=False(只发我们这套干净头);老版本无此参数
    try:
        import inspect
        _supports_dh = "default_headers" in inspect.signature(_CURL.request).parameters
    except Exception:
        _supports_dh = False
    _dh = {"default_headers": False} if _supports_dh else {}
    last = None
    for imp in ("chrome146", "chrome142", "chrome136", "chrome131",
                "chrome124", "chrome120", "chrome110"):
        try:
            r = _CURL.request(method, url, headers=h, cookies=(cookies or None),
                              data=data, timeout=timeout, impersonate=imp,
                              verify=False, allow_redirects=True, **_dh)
            _store_cookies(jar, getattr(r, "cookies", None))
            try:
                hdrs = {k: v for k, v in r.headers.items()}
            except Exception:
                hdrs = {}
            return int(r.status_code), r.text, hdrs
        except Exception as e:            # 未知 impersonate 目标 → 换下一个;否则抛出退回 urllib
            last = e
            if "impersonate" in str(e).lower() or "browser" in str(e).lower():
                continue
            raise
    raise last if last else RuntimeError("curl_cffi_fetch_failed")


def _urllib_fetch(url: str, timeout: float, headers: Optional[dict],
                  jar, data) -> Tuple[int, str, Dict[str, str]]:
    """标准库兜底:urllib + HTTPCookieProcessor(cookie 正确)+ 免证上下文(个别
    酷狗边缘证书问题)。TLS 指纹非 Chrome,个别登录态可能取不到星币。"""
    h = {"User-Agent": _UA, "Accept": "*/*",
         "Referer": "https://fanxing.kugou.com/",
         "Origin": "https://fanxing.kugou.com",
         "Accept-Language": "zh-CN,zh;q=0.9"}
    if headers:
        h.update(headers)
    handlers = [urllib.request.HTTPSHandler(context=_ctx_noverify)]
    if jar is not None:
        handlers.append(urllib.request.HTTPCookieProcessor(jar))
    opener = urllib.request.build_opener(*handlers)
    req = urllib.request.Request(url, data=data, headers=h)
    with opener.open(req, timeout=timeout) as r:
        body = r.read().decode("utf-8", "replace")
        hdrs = {k: v for k, v in r.headers.items()}
        return int(getattr(r, "status", 200) or 200), body, hdrs


def fetch_json(url: str, timeout: float, headers: Optional[dict] = None,
               jar=None, data=None) -> Tuple[int, str, Dict[str, str]]:
    if _HAS_CURL:
        try:
            return _curl_fetch(url, timeout, headers, jar, data)
        except Exception:
            pass   # 回退标准库
    return _urllib_fetch(url, timeout, headers, jar, data)
