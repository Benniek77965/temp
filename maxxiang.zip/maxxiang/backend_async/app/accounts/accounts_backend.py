# -*- coding: utf-8 -*-
"""
accounts_backend.py — 繁星账号(扫码登录 + 账号库)· 2.9.5

本模块给观测台加「添加账号」能力,后续用于以登录态调用需要鉴权的接口。

一、扫码登录(与实测 HAR 完全一致的官方链路)
    1) GET login-user.kugou.com/v2/qrcode        → 生成二维码 key + 现成 base64 图
    2) GET login-user.kugou.com/v2/get_userinfo_qrcode(轮询)
         data.status:  1=待扫 / 2=已扫待确认 / 4=已确认(带 token)/ 其它=过期或异常
    3) 已确认后拿 token 换取登录态(login_by_token),随即以该登录态 Cookie
       调 fx.service.kugou.com/mfx-user/pcweb/fx/user/getUserInfo 取昵称/头像/星币。
    · 所有请求带 signature = MD5(SALT + 排序后的 k=v 拼接 + SALT),大写。
      SALT 与算法出自繁星前端 kguser.v2.min.js,已用 HAR 真实签名逐字节验证一致。

二、账号库(本地 JSON,与九法配置同目录,原子写)
    每个账号存:kugouId / userId / nickName / userLogo(经 /fx/avatar 中转)/
    coin(星币)/ token(续期与后续鉴权用)/ addedAt(登录时间)/ lastRefreshAt。
    「已登录天数」= 从 addedAt 到现在的自然天(展示期按需计算,不落库)。
    支持多账号、切换(current)、删除。

三、星币/资料刷新
    以账号 token 重新走 login_by_token → getUserInfo,更新 coin 等字段。

设计取舍:登录链路涉及 Cookie 会话,与繁星资料多通道取数(server.py 的 _fx_*)
职责不同,这里自带 cookie-aware opener;但**取数出口仍复用 server.py 注入的
fetch 回调**(见 set_fetchers),从而共享其代理/DoH/多域名容灾能力。
"""

import json
import os
import re
import time
import uuid
import hashlib
import threading
from urllib.parse import urlencode

# 登录票据信封加密(AES-256-CBC + RSA-1024,与官方 kguser.v2.min.js 逐字节一致)。
# 修复根因:确认态(status==4)拿到 data.token 后,必须构造 pk/params 才能换到登录态。
try:
    import kg_crypto
except Exception:      # noqa: BLE001
    kg_crypto = None

# ── 签名(繁星 kguser.v2.min.js:MD5(SALT + 排序 k=v 拼接 + SALT),大写)──
_SALT = "NVPh5oo715z5DIWAeQlhMDsWXXQV4hwt"


from .kugou_login_core import build_pk_params


def sign_params(params):
    keys = sorted(params.keys())
    joined = _SALT + "".join(f"{k}={params[k]}" for k in keys) + _SALT
    return hashlib.md5(joined.encode("utf-8")).hexdigest().upper()


def signed_query(params):
    """把 params 补上 signature 并编码为 query 串。"""
    p = dict(params)
    p["signature"] = sign_params(p)
    return urlencode(p)


# ── 取数出口:默认自带 opener;server.py 可注入其容灾 fetch 覆盖之 ──
_FETCH_JSON = None      # fn(url, timeout, headers, jar) -> (status_int, text, resp_headers_dict)


def set_fetchers(fetch_json):
    """server.py 注入一个带 Cookie 会话/多通道容灾的取数函数。
    fetch_json(url, timeout, headers=None, jar=None):jar 为不透明的会话对象
    (由 new_jar() 生成),同一 jar 跨请求累积/回放 Cookie —— 登录接口种下的
    KugooID/token 等由此自动附着到后续 getUserInfo。"""
    global _FETCH_JSON
    _FETCH_JSON = fetch_json


_NEW_JAR = None


def set_jar_factory(fn):
    global _NEW_JAR
    _NEW_JAR = fn


# kg_dfid_collect 在前端是 MD5("")(空串),固定值;kg_dfid 允许 "-"。
_DFID_COLLECT = hashlib.md5(b"").hexdigest()   # d41d8cd98f00b204e9800998ecf8427e

# 固定 mid:作为「随机 mid 缺省时」的兜底基准值(32 位十六进制)。2.9.12 起扫码
# 会话改用每会话随机 mid(见 QRSession),此串仅用于刷新/导入等无会话场景的兜底。
# 必须在 new_jar/_seed_identity 之前定义(它们以其为默认参数,导入期即求值)。
_FIXED_MID = "8f3a1c6e0b7d4a92f5e8c1b0a6d9e2f4"


def new_jar(mid=None):
    """开一个 Cookie 容器。**默认空**(不预置任何 Cookie)。
    真机 HAR 实证(2.9.14):浏览器在创建二维码/轮询阶段**完全不带 Cookie**,且
    【全程从不发送 kg_dfid / kg_dfid_collect】。此前预置 kg_mid/kg_dfid/kg_dfid_collect
    (尤其 kg_dfid_collect=MD5(""))疑被酷狗风控判为「伪造设备」→ 确认态(status==4)
    **扣发登录票据 pk/params** → login_by_token_get 换不到登录态 → 星币永远取不到。
    改为默认空;仅在 login_by_token_get / getUserInfo 阶段经 _set_kg_mid 补 kg_mid
    (浏览器这两步才发送 kg_mid=<mid>,创建/轮询不发)。"""
    jar = _NEW_JAR() if _NEW_JAR else None
    if mid:
        _set_kg_mid(jar, mid)
    return jar


def _set_kg_mid(jar, mid):
    """种 kg_mid + kg_mid_temp（浏览器 login_by_token_get 这两个都发，HAR 实证）。"""
    if jar is None or not mid:
        return
    try:
        import http.cookiejar as cj
        for name in ("kg_mid", "kg_mid_temp"):
            jar.set_cookie(cj.Cookie(0, name, mid, None, False, ".kugou.com",
                           True, True, "/", False, True, None, False, None, None, {}))
    except Exception:
        pass


def _seed_identity(jar, mid=None):   # 兼容保留:等价于只种 kg_mid(不再种假 dfid)
    _set_kg_mid(jar, mid)


def _default_fetch(url, timeout, headers=None, jar=None, data=None):
    import urllib.request
    ua = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
          "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
    h = {"User-Agent": ua, "Accept": "*/*",
         "Referer": "https://fanxing.kugou.com/",
         "Origin": "https://fanxing.kugou.com"}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, data=data, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        body = r.read().decode("utf-8", "replace")
        rh = {k: v for k, v in r.headers.items()}
        return r.status, body, rh


def _fetch(url, timeout=12.0, headers=None, jar=None, data=None):
    fn = _FETCH_JSON or _default_fetch
    try:
        return fn(url, timeout, headers, jar, data)
    except TypeError:
        # 兼容未升级的注入 fetcher(不接受 data 参数):无 body 时退回旧签名
        if data is None:
            return fn(url, timeout, headers, jar)
        raise


# ─────────────────────────────────────────────────────────────────────────────
# 扫码登录会话
# ─────────────────────────────────────────────────────────────────────────────
QR_BASE = "https://login-user.kugou.com"
USERINFO_URL = "https://fx.service.kugou.com/mfx-user/pcweb/fx/user/getUserInfo?args=[]&_={t}"
# 备用资料源(HAR 实测同样含 coin/nickName/userLogo):字段在 data.fxUserInfo 下。
USERINFO2_URL = ("https://fanxing.kugou.com/biz/UserPlat/UserService/UserService/"
                 "getCurrentUserInfoV2?args=[]&_={t}")
TOKEN_URL = "https://loginservice.kugou.com/v1/login_by_token_get"

_APPID = "1010"
_SRCAPPID = "2919"

# ── 「未登录/失效」错误码(经真机测试确认,2.9.15 有效性检测判据)──
#   getUserInfo          错误号在 `code` 字段:
#       0        = 成功(且 data 带 kugouId → 有效)
#       2001006  = 未登录(真机实测:真实但过期的 token)
#       2001003  = 参数错误 / 会话缺失(实测:token 不可用/换登录态未成功)
#     二者均代表「登录态不可用」→ 失效。
#   getCurrentUserInfoV2 错误号在 `errorno` 字段:
#       100035031 / 100091043 / 100091033 = 用户尚未登录 → 失效。
# 仅当命中以下集合才判「失效」;其余未知错误码一律判「无法判定」(建议重试),
# 避免限流/人机验证/临时故障被误判为失效。集合易扩展:诊断端点会打印实际码。
_NOTLOGIN_GETUSERINFO = {2001006, 2001003}
_NOTLOGIN_USERINFOV2 = {100035031, 100091043, 100091033}


def _as_int(v):
    """把响应里的错误号安全转 int(可能是字符串或数字);转不了返回 None。"""
    try:
        return int(v)
    except (TypeError, ValueError):
        return None

# mid 说明见上方 _FIXED_MID 定义(已前置到 new_jar 之前)。


def _common(mid=_FIXED_MID):
    return {"appid": _APPID, "clientver": "1", "mid": mid, "uuid": mid,
            "dfid": "-", "plat": "4", "srcappid": _SRCAPPID}


class QRSession:
    """一次扫码会话:持二维码 key、状态、最终账号资料。TTL 内前端轮询。"""
    __slots__ = ("sid", "mid", "qrcode", "img", "created", "status",
                 "account", "error", "jar", "_lock", "scan_nick", "scan_pic")

    def __init__(self):
        self.sid = uuid.uuid4().hex
        self.mid = _FIXED_MID       # 固定 mid,所有账号共用(kg_mid 亦同)。经真机+HAR
        # 验证:随机 mid 不改变确认态被扣发票据的结果(差异在 TLS 指纹层,非 mid),
        # 故恢复固定 mid,与 kg_mid Cookie 保持一致、行为稳定。
        self.qrcode = ""
        self.img = ""
        self.created = time.time()
        self.status = "init"        # init/waiting/scanned/confirmed/done/expired/error
        self.account = None
        self.error = ""
        self.jar = new_jar()  # 2.9.14:空 jar —— 创建二维码/轮询阶段不带任何 Cookie
        # (与浏览器一致);kg_mid 延到 login_by_token_get 阶段由 _exchange_login 补种。
        self._lock = threading.Lock()
        # 扫码(status==2)阶段官方回显的昵称/头像:供前端即时预览 + 确认态兜底
        self.scan_nick = ""
        self.scan_pic = ""


class QRLoginManager:
    SESSION_TTL = 180.0             # 二维码 3 分钟有效
    POLL_MIN_INTERVAL = 0.8

    def __init__(self, store):
        self.store = store
        self.sessions = {}
        self._lock = threading.Lock()
        # 3.8.0 复查修复:三份「最近一次」诊断快照从模块级下沉为**实例属性** ——
        # 每个账号领域(Realm)一套独立的 QRLoginManager,故诊断态天然按账号隔离。
        # 此前是模块级全局:A 扫码的票据线索会被 B 的 /api/account/*/diag 读到
        # (登录系统的账号隔离承诺不容此洞)。默认领域(未启用登录)行为不变。
        self.last_poll = {"sid": "", "code": None, "raw": "", "at": 0}
        self.last_userinfo = {"src": "", "http": None, "code": None, "hasData": False,
                              "dataKeys": [], "coin": None, "coinLike": {}, "raw": "", "at": 0}
        self.last_check = {"kugouId": "", "state": "", "src": "", "http": None,
                           "code": None, "cookieOK": None, "raw": "", "at": 0}

    def _gc(self):
        now = time.time()
        with self._lock:
            for sid in [s for s, o in self.sessions.items()
                        if now - o.created > self.SESSION_TTL + 60]:
                self.sessions.pop(sid, None)

    def create(self):
        """生成二维码。返回 {ok, sid, img, expiresIn} 或 {ok:False, error}。"""
        self._gc()
        s = QRSession()
        p = _common(s.mid)
        p["clienttime"] = int(time.time() * 1000)
        p["type"] = "1"
        p["qrcode_txt"] = ("https://h5.kugou.com/apps/loginQRCode/html/index.html"
                           "?appid=1010&")
        url = f"{QR_BASE}/v2/qrcode?{signed_query(p)}"
        try:
            st, body, _ = _fetch(url, timeout=12.0, jar=s.jar)
            j = json.loads(body)
        except Exception as e:
            return {"ok": False, "error": f"二维码生成失败: {type(e).__name__}"}
        data = j.get("data")
        if not isinstance(data, dict) or not data.get("qrcode"):
            msg = data if isinstance(data, str) else "二维码接口返回异常"
            return {"ok": False, "error": str(msg)}
        s.qrcode = data["qrcode"]
        s.img = data.get("qrcode_img") or ""
        s.status = "waiting"
        with self._lock:
            self.sessions[s.sid] = s
        return {"ok": True, "sid": s.sid, "img": s.img,
                "expiresIn": int(self.SESSION_TTL)}

    def poll(self, sid):
        """轮询扫码状态。返回 {ok, status, [nickName/coin/... 已确认时]}。"""
        with self._lock:
            s = self.sessions.get(sid)
        if s is None:
            return {"ok": False, "status": "expired", "error": "会话不存在或已过期"}
        if time.time() - s.created > self.SESSION_TTL:
            s.status = "expired"
            return {"ok": True, "status": "expired"}
        # 已到终态:直接回放(登录成功后前端可能再轮询一次)
        if s.status in ("done", "error", "expired"):
            out = {"ok": True, "status": s.status}
            if s.status == "done" and s.account:
                out["account"] = _public_account(s.account)
            if s.error:
                out["error"] = s.error
            return out

        with s._lock:
            # 锁内二次确认终态:确认态 _finish_login 现在会真正换登录态+取星币(~1-2s),
            # 而前端每 1.5s 轮询一次,两次轮询可能重叠。前一次在锁内跑完并置 done 后,
            # 后一次(在锁外通过了终态判断)若不复检,会拿着已被消费的二维码票据再次
            # _finish_login。这里复检一次,直接回放结果,避免重复登录。
            if s.status in ("done", "error", "expired"):
                out = {"ok": True, "status": s.status}
                if s.status == "done" and s.account:
                    out["account"] = _public_account(s.account)
                if s.error:
                    out["error"] = s.error
                return out
            p = _common(s.mid)
            p["clienttime"] = int(time.time() * 1000)
            p["qrcode"] = s.qrcode
            url = f"{QR_BASE}/v2/get_userinfo_qrcode?{signed_query(p)}"
            try:
                st, body, _ = _fetch(url, timeout=10.0, jar=s.jar)
                j = json.loads(body)
            except Exception as e:
                return {"ok": True, "status": s.status,
                        "warn": f"轮询异常: {type(e).__name__}"}

            data = j.get("data")
            code = None
            if isinstance(data, dict):
                code = data.get("status")

            # 诊断:记录最近一次「非待扫」的原始响应(status!=1),供 /api/account/qr/diag
            # 排查确认态字段(HAR 未捕获确认响应,真机卡在已扫时以此看清实际结构)。
            if code != 1:
                snapshot = body[:1200]
                self.last_poll["sid"] = sid
                self.last_poll["code"] = code
                self.last_poll["raw"] = snapshot
                self.last_poll["at"] = int(time.time())
                # 2.9.12:确认态(status==4)dump 全部字段名 + 疑似票据字段,便于一眼
                # 看出 token 落在哪个字段(此前落库 token 为空的根因即字段名不符)。
                if isinstance(data, dict):
                    self.last_poll["dataKeys"] = list(data.keys())[:40]
                    self.last_poll["tokenLike"] = _scan_token_like(data)
                    self.last_poll["pickedToken"] = bool(_pick_token(data))
                if code == 2:
                    self.last_poll["scanned_raw"] = snapshot
                # 自动打到服务器日志(stderr):真机确认后卡住时,日志即可见实际响应,
                # 无需额外操作。仅在 code 变化时打,避免刷屏。
                if self.last_poll.get("logged_code") != code:
                    self.last_poll["logged_code"] = code
                    try:
                        import sys as _sys
                        _sys.stderr.write(f"  [账号] 扫码轮询 data.status={code} 原始响应="
                                          f"{snapshot[:500]}\n")
                        _sys.stderr.flush()
                    except Exception:
                        pass

            # 官方语义(与 musicdl 参考实现 / 实测 HAR 一致):
            #   1 = 待扫
            #   2 = 已扫待确认 —— 仅回显 nickname/pic 供手机确认页展示,**尚无 token**
            #   4 = 已确认 —— 此刻才下发 data.token(换登录态用)
            if code == 1:
                s.status = "waiting"
                return {"ok": True, "status": "waiting"}
            # 【2.9.9 修复:星币为空 / 头像延迟 的根因】
            # 旧逻辑把 data.userid / data.kugouId 也当成「确认票据」,于是在 status==2
            # (扫码待确认)阶段就误判为已确认并 _finish_login。但那时官方只给昵称+头像,
            # 并没有 token:
            #   · login_by_token 无票可换 → 拿不到 .kugou.com 登录态 Cookie
            #     → getUserInfo 未登录 → coin(星币)取不到,前端显示为空;
            #   · 落库的 token 也是空的 → 事后点「⟳ 刷新」仍换不到登录态 → 星币依旧空;
            #   · _finish_login 里换登录态/取资料的几个请求还会空跑一轮才返回
            #     → 那一次轮询被拖住,前端要等它结束才拿到账号,头像随之显示延迟。
            # 正确做法(见 musicdl:轮询直到 data.status==4 才 break,再取 data.token):
            # 确认判定只认「真票据」token/t1/pk,或明确的 status==4;userid 不算票据。
            has_ticket = isinstance(data, dict) and (
                data.get("token") or data.get("t1") or data.get("pk"))
            if code == 4 or has_ticket:
                s.status = "confirmed"
                acct = self._finish_login(s, data)
                if acct is None:
                    s.status = "error"
                    return {"ok": True, "status": "error",
                            "error": s.error or "登录换取失败",
                            "diag": self.last_poll.get("raw", "")[:300]}
                s.account = acct
                s.status = "done"
                return {"ok": True, "status": "done",
                        "account": _public_account(acct)}
            if code == 2:
                # 已扫待确认:缓存官方回显的昵称/头像。用途有二 ——
                #   1) 随本次响应回给前端(preview),二维码位可即刻显示头像,
                #      消除「扫码后头像迟迟不出」的观感(此时用户尚未在手机点确认);
                #   2) 万一确认态(status==4)不带昵称/头像,落库时用它兜底。
                nick = (data.get("nickname") or data.get("nickName") or "").strip()
                pic = (data.get("pic") or data.get("img")
                       or data.get("userLogo") or "").strip()
                if nick:
                    s.scan_nick = nick
                if pic:
                    s.scan_pic = pic
                s.status = "scanned"
                out = {"ok": True, "status": "scanned"}
                if s.scan_nick or s.scan_pic:
                    out["preview"] = {"nickName": s.scan_nick,
                                      "userLogo": _norm_logo(s.scan_pic)}
                return out
            # 其它:过期/失效
            if j.get("status") == 0 or code in (0, None):
                if j.get("status") == 1:
                    return {"ok": True, "status": s.status}
                s.status = "expired"
                return {"ok": True, "status": "expired"}
            return {"ok": True, "status": s.status}

    def _finish_login(self, s, data):
        """已确认 → 落库(名字/头像/星币)。

        关键(2.9.9):
          · 确认态(status==4)的 data 至少带 userid + token;昵称/头像不一定重复下发,
            故名字/头像以「扫码阶段(status==2)缓存的 s.scan_nick/s.scan_pic」为兜底,
            并优先采用 getUserInfo 返回的繁星头像(带尺寸、与实测 HAR 落库口径一致)。
          · 星币(coin)必须以登录态调 getUserInfo:先用 token 走 login_by_token 换取
            .kugou.com 登录态 Cookie,再取数。此步依赖「拿到真 token」——正因如此,
            poll() 必须等到 status==4 才进入这里,否则 token 为空,星币必空。
          · getUserInfo 万一失败,也不阻断登录(名字/头像照常入库,星币留空,可「⟳ 刷新」)。
        """
        jar = s.jar or new_jar()
        userid = str(data.get("userid") or data.get("kugouId")
                     or data.get("userId") or "")
        # 2.9.12:票据尽力取——先认 token/pk/t1,再扫描任一疑似票据字段。此前仅认
        # token/pk/t1,若确认响应把票据放在别名字段,则落库 token 为空 → 换不到
        # 登录态 → 星币永远取不到(刷新亦然)。
        token = _pick_token(data)
        # 确认响应直接给的名字/头像(字段名:nickname / pic)
        nick = (data.get("nickname") or data.get("nickName") or "").strip()
        pic = (data.get("pic") or data.get("img") or data.get("userLogo") or "").strip()

        # 用 token 换登录态 Cookie(尽力,失败不阻断登录)——为取星币做准备。
        self._exchange_login(jar, s.mid, userid, token,
                             data.get("params") or data.get("param") or "")

        # 取星币等(尽力):优先 getUserInfo,其次 getCurrentUserInfoV2。
        info = self._fetch_userinfo(jar, s.mid) or {}

        coin = info.get("coin", "")
        # 名字/头像统一以 getUserInfo 的繁星资料为准(与星币同源,身份一致、头像清晰),
        # 取不到时再回退到「确认态 data → 扫码阶段缓存」的酷狗昵称/头像。
        nick = (info.get("nickName") or nick or s.scan_nick
                or ("酷狗用户" + (userid or "")))
        pic = (info.get("userLogo") or info.get("userLogoM")
               or pic or s.scan_pic or "")

        now = int(time.time())
        acct = {
            "kugouId": str(userid or info.get("kugouId") or ""),
            "userId": str(info.get("userId") or ""),
            "nickName": nick,
            "userName": info.get("userName") or "",
            "userLogo": _norm_logo(pic),
            "coin": str(coin) if coin != "" else "",
            "richLevel": info.get("richLevel"),
            "starLevel": info.get("starLevel"),
            "token": token or "",
            "mid": s.mid,
            "cookie": _jar_cookie_str(jar) or "",
            "addedAt": now,
            "lastRefreshAt": now,
        }
        if not acct["kugouId"]:
            s.error = "确认响应缺少 userid,无法建立账号"
            return None
        if not self.store.upsert(acct):
            # 达上限(新增第 11 个被 store 硬限拒绝);已有账号重登不会走到这里。
            s.error = ("最多支持 %d 个账号:请先在「账号」列表移除不用的账号,"
                       "再扫码添加" % AccountStore.MAX_ACCOUNTS)
            return None
        return acct

    def _exchange_login(self, jar, mid, userid, token, params_tok):
        """用 token 换取 .kugou.com 登录态 Cookie（KugooID/t 等）。信封=AES+RSA。"""
        if not token:
            import sys
            print("[账号] 换取登录态跳过：token 为空", file=sys.stderr)
            return
        _set_kg_mid(jar, mid)
        try:
            ct_ms = int(time.time() * 1000)
            pk, params = build_pk_params(token, ct_ms)
            p = _common(mid)
            p["clientver"] = "1000"
            p["clienttime"] = ct_ms // 1000
            p["clienttime_ms"] = ct_ms
            p["dev"] = "web"
            p["userid"] = userid
            p["pk"] = pk
            p["params"] = params
            st, body, rh = _fetch(f"{TOKEN_URL}?{signed_query(p)}",
                                  timeout=12.0, jar=jar, data=b"")
            import sys
            ssa = (rh.get("SSA-CODE") or rh.get("ssa-code") or "") if isinstance(rh, dict) else ""
            if ssa:
                print(f"[账号] login_by_token_get 需人机验证 SSA-CODE={ssa}", file=sys.stderr)
        except Exception as e:
            import sys
            print(f"[账号] 换取登录态异常: {type(e).__name__}", file=sys.stderr)
        try:
            import sys
            names = [c.name for c in jar] if jar is not None else []
            got = [n for n in names if n in ("KugooID", "t", "KuGoo", "UserName")]
            print("[账号] 换取登录态后 Cookie=%s | 登录态票据=%s" %
                  (names, got or "(无——星币取不到)"), file=sys.stderr)
        except Exception:
            pass

    def _fetch_userinfo(self, jar, mid):
        """以登录态(jar 内 Cookie)取用户资料。先试 getUserInfo,失败再试
        getCurrentUserInfoV2(data.fxUserInfo);两者都含 nickName/userLogo/coin。
        返回归一化 data dict 或 None。全程把原始响应记入 self.last_userinfo 供诊断(按账号隔离)。"""
        t = int(time.time() * 1000)
        # 主源:getUserInfo(data 直接是资料)
        try:
            st, body, _ = _fetch(USERINFO_URL.format(t=t), timeout=12.0, jar=jar)
            j = json.loads(body)
            data = j.get("data")
            self.last_userinfo = _snap_userinfo("getUserInfo", st, j, data, body)
            if j.get("code") == 0 and isinstance(data, dict) and data.get("kugouId"):
                return data
        except Exception as ex:      # noqa: BLE001
            self.last_userinfo = _snap_userinfo("getUserInfo", None, None, None, f"[异常]{type(ex).__name__}:{ex}")
        # 备源:getCurrentUserInfoV2(data.fxUserInfo)
        try:
            st, body, _ = _fetch(USERINFO2_URL.format(t=t + 1), timeout=12.0, jar=jar)
            j = json.loads(body)
            d = (j.get("data") or {})
            fx = d.get("fxUserInfo") if isinstance(d, dict) else None
            self.last_userinfo = _snap_userinfo("getCurrentUserInfoV2", st, j, fx, body)
            if isinstance(fx, dict) and fx.get("kugouId"):
                return fx     # 字段名与 getUserInfo 完全一致(nickName/userLogo/coin/...)
        except Exception as ex:      # noqa: BLE001
            self.last_userinfo = _snap_userinfo("getCurrentUserInfoV2", None, None, None, f"[异常]{type(ex).__name__}:{ex}")
        return None

    def refresh_account(self, kugou_id):
        """重新取资料更新星币等。用账号存下的 token 重新换登录态(比仅回放旧
        Cookie 更可靠),再取 getUserInfo。返回公开账号或 None。"""
        acct = self.store.get(kugou_id)
        if not acct:
            return None
        jar = new_jar(acct.get("mid") or _FIXED_MID)
        _jar_load_cookie_str(jar, acct.get("cookie", ""))
        # 用存下的 token 重新换取登录态(尽力),使刷新能拿到星币。
        self._exchange_login(jar, acct.get("mid", ""), acct.get("kugouId", ""),
                             acct.get("token", ""), "")
        info = self._fetch_userinfo(jar, acct.get("mid", ""))
        if not info:
            return _public_account(acct)   # 取不到就返回旧值,不清空
        if info.get("coin", "") != "":
            acct["coin"] = str(info.get("coin"))
        acct["nickName"] = info.get("nickName") or acct.get("nickName")
        _lg = _norm_logo(info.get("userLogo") or info.get("userLogoM") or "")
        if _lg:
            acct["userLogo"] = _lg
        acct["richLevel"] = info.get("richLevel", acct.get("richLevel"))
        acct["starLevel"] = info.get("starLevel", acct.get("starLevel"))
        # 会话可能刷新了 Cookie,回存
        cs = _jar_cookie_str(jar)
        if cs:
            acct["cookie"] = cs
        acct["lastRefreshAt"] = int(time.time())
        self.store.upsert(acct)
        return _public_account(acct)

    # ─────────────────────────────────────────────────────────────────────
    # 有效性检测(登录态是否仍然活着)
    # ─────────────────────────────────────────────────────────────────────
    def _probe_userinfo(self, jar, mid, expect_kid=""):
        """检测专用:以 jar 内登录态调资料接口,按【确认过的错误码】判定,不吞码。

        判据(2.9.15,真机实测确认):
          getUserInfo(错误号在 code):
            · code==0 且 data 带 kugouId          → 有效
            · code ∈ {2001006, 2001003}           → 失效(未登录/会话缺失)
            · 其它 code                           → 判不了(未知,建议重试)
          getCurrentUserInfoV2(错误号在 errorno):
            · data.fxUserInfo 带 kugouId           → 有效
            · errorno ∈ {100035031/100091043/100091033} → 失效(尚未登录)
            · 其它 errorno                         → 判不了
        合并两源:有效 > 失效 > 判不了/网络。有效优先——任一源确认本人档案即有效,
        避免单源抖动/单端点风控把好账号误判失效。两源皆网络异常或皆未知码 → error。

        返回 {state, src, http, code, data, cookieOK, raw},state ∈ valid/invalid/error。
        """
        t = int(time.time() * 1000)
        results = []       # 每源一条:(state, src, http, code, data, raw)
        net_fail = 0       # 请求异常计数(纯网络/DoH/代理问题)

        # 主源 getUserInfo(错误号在 code 字段)
        try:
            st, body, _ = _fetch(USERINFO_URL.format(t=t), timeout=12.0, jar=jar)
            j = json.loads(body)
            data = j.get("data")
            code = _as_int(j.get("code"))
            if code == 0 and isinstance(data, dict) and data.get("kugouId"):
                results.append(("valid", "getUserInfo", st, code, data, body[:600]))
            elif code in _NOTLOGIN_GETUSERINFO:
                results.append(("invalid", "getUserInfo", st, code, None, body[:600]))
            else:
                results.append(("inconclusive", "getUserInfo", st, code, None, body[:600]))
        except Exception:      # noqa: BLE001
            net_fail += 1

        # 备源 getCurrentUserInfoV2(错误号在 errorno 字段;资料在 data.fxUserInfo)
        try:
            st, body, _ = _fetch(USERINFO2_URL.format(t=t + 1), timeout=12.0, jar=jar)
            j = json.loads(body)
            d = j.get("data") or {}
            fx = d.get("fxUserInfo") if isinstance(d, dict) else None
            errorno = _as_int(j.get("errorno"))
            if isinstance(fx, dict) and fx.get("kugouId"):
                results.append(("valid", "getCurrentUserInfoV2", st, errorno, fx, body[:600]))
            elif errorno in _NOTLOGIN_USERINFOV2:
                results.append(("invalid", "getCurrentUserInfoV2", st, errorno, None, body[:600]))
            else:
                results.append(("inconclusive", "getCurrentUserInfoV2", st, errorno, None, body[:600]))
        except Exception:      # noqa: BLE001
            net_fail += 1

        cookie_ok = _has_login_cookie(jar)
        # 合并:有效优先
        for state, src, st, code, data, raw in results:
            if state == "valid":
                return {"state": "valid", "src": src, "http": st, "code": code,
                        "data": data, "cookieOK": cookie_ok, "raw": raw}
        # 次之:任一源命中「已知未登录码」→ 失效
        for state, src, st, code, data, raw in results:
            if state == "invalid":
                return {"state": "invalid", "src": src, "http": st, "code": code,
                        "data": None, "cookieOK": cookie_ok, "raw": raw}
        # 都不是:有响应但为未知码 → 判不了(暴露该码到 diag,便于补进未登录集)
        for state, src, st, code, data, raw in results:
            return {"state": "error", "src": src, "http": st, "code": code,
                    "data": None, "cookieOK": cookie_ok,
                    "raw": "未识别响应(非有效、非已知未登录码): " + raw}
        # 两源皆网络异常
        return {"state": "error", "src": "network", "http": None, "code": None,
                "data": None, "cookieOK": cookie_ok,
                "raw": f"两源请求均异常({net_fail})"}

    def check_account(self, kugou_id):
        """检测单个账号登录态是否仍有效,并把结果落库(validStatus/lastCheckAt)。

        用账号存下的 token 重新换登录态(与「刷新」同法,比只回放旧 Cookie 可靠),
        再经 _probe_userinfo 判定:
          · valid   —— 顺带用返回档案刷新 coin/昵称/头像(检测即刷新)
          · invalid —— 仅标记失效,保留 token/cookie(便于日后重扫续期)
          · error   —— 判不了(网络异常),不改动既有 validStatus,建议重试

        返回 {kugouId, status, code, src, coin, checkedAt, checkedAtText, reason}。
        """
        acct = self.store.get(kugou_id)
        if not acct:
            return {"status": "error", "reason": "账号不存在", "code": None,
                    "src": "", "kugouId": str(kugou_id)}
        jar = new_jar(acct.get("mid") or _FIXED_MID)
        _jar_load_cookie_str(jar, acct.get("cookie", ""))
        # 用存下的 token 重新换登录态(尽力,失败不阻断——失败本身就是失效信号)
        self._exchange_login(jar, acct.get("mid", ""), acct.get("kugouId", ""),
                             acct.get("token", ""), "")
        probe = self._probe_userinfo(jar, acct.get("mid", ""), acct.get("kugouId", ""))
        now = int(time.time())
        self.last_check.update({"kugouId": str(kugou_id), "state": probe["state"],
                            "src": probe["src"], "http": probe["http"],
                            "code": probe["code"], "cookieOK": probe["cookieOK"],
                            "raw": probe["raw"], "at": now})
        try:
            import sys
            print("[账号] 有效性检测 kugouId=%s → %s (src=%s code=%s http=%s cookie=%s)"
                  % (kugou_id, probe["state"], probe["src"], probe["code"],
                     probe["http"], probe["cookieOK"]), file=sys.stderr)
        except Exception:      # noqa: BLE001
            pass

        state = probe["state"]
        if state == "valid":
            info = probe["data"] or {}
            if info.get("coin", "") != "":
                acct["coin"] = str(info.get("coin"))
            if info.get("nickName"):
                acct["nickName"] = info.get("nickName")
            _lg = _norm_logo(info.get("userLogo") or info.get("userLogoM") or "")
            if _lg:
                acct["userLogo"] = _lg
            acct["richLevel"] = info.get("richLevel", acct.get("richLevel"))
            acct["starLevel"] = info.get("starLevel", acct.get("starLevel"))
            cs = _jar_cookie_str(jar)
            if cs:
                acct["cookie"] = cs
            acct["validStatus"] = "valid"
            acct["lastRefreshAt"] = now
        elif state == "invalid":
            acct["validStatus"] = "invalid"
        # error:保留上一次 validStatus,不动
        acct["lastCheckAt"] = now
        self.store.upsert(acct)

        if state == "error":
            reason = ("网络异常,未能判定,请重试" if probe["code"] is None
                      else f"返回未识别错误码 {probe['code']},暂无法判定,请重试")
        else:
            reason = {"valid": "登录态有效",
                      "invalid": "登录态已失效,需重新扫码登录"}[state]
        return {"kugouId": str(kugou_id), "status": state, "code": probe["code"],
                "src": probe["src"], "coin": acct.get("coin", ""),
                "checkedAt": now,
                "checkedAtText": time.strftime("%Y-%m-%d %H:%M", time.localtime(now)),
                "reason": reason}

    def check_all(self):
        """顺序检测全部账号,逐个落库,返回汇总 + 最新公开列表。
        {ok, total, valid, invalid, error, results:[{kugouId,status,code}], accounts, current}。
        并发交给前端(逐个调 /api/account/check,可看结果实时回填);此端点供一次性检测。"""
        pub = self.store.list_public()
        ids = [str(a.get("kugouId")) for a in pub.get("accounts", []) if a.get("kugouId")]
        tally = {"valid": 0, "invalid": 0, "error": 0}
        results = []
        for kid in ids:
            r = self.check_account(kid)
            st = r.get("status", "error")
            tally[st] = tally.get(st, 0) + 1
            results.append({"kugouId": kid, "status": st, "code": r.get("code")})
        return {"ok": True, "total": len(ids), **tally, "results": results,
                **self.store.list_public()}


def _norm_logo(url):
    """把头像地址归一为完整 https URL(供前端 /fx/avatar 中转)。
      · getUserInfo:  /v2/fxuserlogo/xxx.jpg_45x45.jpg(相对)→ 补 https 主机
      · getCurrentUserInfoV2: http://p3.fx.kgimg.com/...(完整)→ https 化
    """
    u = str(url or "").strip()
    if not u:
        return ""
    if u.startswith("//"):
        u = "https:" + u
    if u.startswith("/") and not u.startswith("//"):
        # 相对路径:繁星用户头像走 p3fx.kgimg.com
        u = "https://p3fx.kgimg.com" + u
    # http → https;p3.fx.kgimg.com → p3fx.kgimg.com(与主播头像同源写法)
    u = re.sub(r"^http://", "https://", u, count=1)
    u = re.sub(r"^https://(p\d+)\.fx\.kgimg\.com/", r"https://\1fx.kgimg.com/", u)
    return u



def _jar_cookie_str(jar):
    """把 jar 内 Cookie 导出为 name=value; ... 串(供落库/展示)。"""
    if jar is None:
        return ""
    try:
        parts = []
        seen = set()
        for c in jar:
            if c.name in seen:
                continue
            seen.add(c.name)
            parts.append(f"{c.name}={c.value}")
        return "; ".join(parts)
    except Exception:
        return ""


def _has_login_cookie(jar):
    """jar 内是否已含登录态票据(KugooID / t / KuGoo)。换票成功的强信号,
    仅作有效性检测的诊断佐证——真正的判据仍以 getUserInfo 是否回本人档案为准。"""
    if jar is None:
        return False
    try:
        names = {c.name for c in jar}
        return bool(names & {"KugooID", "t", "KuGoo"})
    except Exception:
        return False


def _jar_load_cookie_str(jar, cookie_str):
    """把落库的 Cookie 串灌回一个新 jar(刷新时复用登录态)。"""
    if jar is None or not cookie_str:
        return
    try:
        import http.cookiejar as cj
        for seg in cookie_str.split(";"):
            seg = seg.strip()
            if "=" not in seg:
                continue
            name, val = seg.split("=", 1)
            ck = cj.Cookie(0, name.strip(), val.strip(), None, False,
                           ".kugou.com", True, True, "/", False, True,
                           None, False, None, None, {})
            jar.set_cookie(ck)
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
# 账号库(本地 JSON,原子写)
# ─────────────────────────────────────────────────────────────────────────────
def _public_account(acct):
    """给前端的安全视图:不含 token/cookie/mid;附「已登录天数」。"""
    added = int(acct.get("addedAt") or 0)
    days = 0
    if added:
        # 自然天差:按本地 00:00 边界计
        a = time.localtime(added)
        n = time.localtime()
        import datetime
        da = datetime.date(a.tm_year, a.tm_mon, a.tm_mday)
        dn = datetime.date(n.tm_year, n.tm_mon, n.tm_mday)
        days = (dn - da).days
    return {
        "kugouId": acct.get("kugouId", ""),
        "userId": acct.get("userId", ""),
        "nickName": acct.get("nickName", ""),
        "userLogo": acct.get("userLogo", ""),
        "coin": acct.get("coin", ""),
        "richLevel": acct.get("richLevel"),
        "starLevel": acct.get("starLevel"),
        "addedAt": added,
        "addedAtText": time.strftime("%Y-%m-%d %H:%M", time.localtime(added)) if added else "",
        "loginDays": days,
        "lastRefreshAt": acct.get("lastRefreshAt", 0),
        # 有效性检测结果(""=未检测 / valid=有效 / invalid=失效),供列表持久展示
        "validStatus": acct.get("validStatus", ""),
        "lastCheckAt": acct.get("lastCheckAt", 0),
        "lastCheckText": (time.strftime("%Y-%m-%d %H:%M",
                          time.localtime(acct.get("lastCheckAt")))
                          if acct.get("lastCheckAt") else ""),
    }


class AccountStore:
    # 账号数量上限:扫码新增第 11 个账号时拒绝(已有账号重新扫码登录 = 更新,
    # 不受限)。上限在 upsert 的新增分支硬性执行 —— 任何新增路径都无法绕过。
    MAX_ACCOUNTS = 10

    def __init__(self, path):
        self.path = path
        self._lock = threading.Lock()
        self._data = {"accounts": [], "current": ""}
        self._load()

    def _load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, dict):
                self._data = {"accounts": d.get("accounts") or [],
                              "current": str(d.get("current") or "")}
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            self._data = {"accounts": [], "current": ""}

    def _save(self):
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self._data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.path)
        except OSError:
            try:
                os.remove(tmp)
            except OSError:
                pass

    def upsert(self, acct):
        """按 kugouId 更新或新增。返回 True=已入库;False=达账号上限被拒
        (仅新增分支可能拒;更新已有账号恒成功)。"""
        kid = str(acct.get("kugouId") or "")
        if not kid:
            return False
        with self._lock:
            arr = self._data["accounts"]
            for i, a in enumerate(arr):
                if str(a.get("kugouId")) == kid:
                    # 保留原 addedAt(首登时间不变),其余覆盖
                    acct["addedAt"] = a.get("addedAt", acct.get("addedAt"))
                    arr[i] = acct
                    break
            else:
                if len(arr) >= self.MAX_ACCOUNTS:      # 新增才受限
                    return False
                arr.append(acct)
            if not self._data["current"]:
                self._data["current"] = kid
            self._save()
        return True

    def count(self):
        with self._lock:
            return len(self._data["accounts"])

    def get(self, kugou_id):
        kid = str(kugou_id)
        with self._lock:
            for a in self._data["accounts"]:
                if str(a.get("kugouId")) == kid:
                    return a
        return None

    def remove(self, kugou_id):
        kid = str(kugou_id)
        with self._lock:
            before = len(self._data["accounts"])
            self._data["accounts"] = [a for a in self._data["accounts"]
                                      if str(a.get("kugouId")) != kid]
            removed = len(self._data["accounts"]) < before
            if self._data["current"] == kid:
                self._data["current"] = (self._data["accounts"][0]["kugouId"]
                                         if self._data["accounts"] else "")
            if removed:
                self._save()
        return removed

    def set_current(self, kugou_id):
        kid = str(kugou_id)
        with self._lock:
            if any(str(a.get("kugouId")) == kid for a in self._data["accounts"]):
                self._data["current"] = kid
                self._save()
                return True
        return False

    def list_public(self):
        with self._lock:
            arr = list(self._data["accounts"])
            cur = self._data["current"]
        return {"ok": True, "current": cur,
                "accounts": [_public_account(a) for a in arr]}

    def current_raw(self):
        """当前选择账号的**原始** dict(含 token/cookie/mid;供真实游戏后端取票据)。
        无当前项时回退第一个账号;账号库空则 None。仅供同进程后端内部使用。"""
        with self._lock:
            cur = self._data["current"]
            accounts = self._data["accounts"]
            if not accounts:
                return None
            for a in accounts:
                if str(a.get("kugouId")) == str(cur):
                    return dict(a)
            return dict(accounts[0])


# ── 领域(realm)注册表:登录系统(3.8.0)下「账号库按登录用户隔离」 ──────────────
# 一个 realm = 一份独立的 AccountStore(JSON 文件)+ 专属 QRLoginManager(扫码会话
# 绑定该 store,_finish_login 落到谁家一目了然)。
#   · 默认领域(key=None)= 旧行为的 accounts.json —— 登录系统未启用时逐字节兼容;
#   · 登录用户领域 key="u<tb_user.id>" → 同目录 accounts-u<id>.json(持久化卷内,
#     与 accounts.json 同受 backup/restore 三件套覆盖)。
# 请求期领域经 contextvars 传递:web.py 在 async 路由里 set_request_realm(),
# 线程池调用(anyio 的 to_thread.run_sync,内部 copy_context)会复制上下文,
# 线程池里的 handle_api / get_current_raw
# (真实游戏后端取当前账号票据)读到的就是该请求用户自己的领域 —— game_backend 零改动。
import contextvars

STORE = None            # 默认领域的 store(向后兼容旧引用)
QR = None               # 默认领域的 QR 管理器
_BASE_PATH = None       # init() 传入的默认库路径;用户领域文件与其同目录
_REALMS = {}            # key -> Realm
_REALMS_LOCK = threading.Lock()
_REQ_REALM = contextvars.ContextVar("acct_realm", default=None)


class Realm:
    __slots__ = ("key", "store", "qr")

    def __init__(self, key, store, qr):
        self.key, self.store, self.qr = key, store, qr


def get_realm(key=None):
    """取(或惰性创建)一个账号领域。key=None/'' = 默认领域(accounts.json)。
    key 只允许 [A-Za-z0-9_-](调用方传 'u<数字id>'),其余字符一律替换 —— 文件名
    由服务端身份派生,用户输入永不参与,杜绝路径拼接歧义。"""
    if not key:
        if STORE is None:
            raise RuntimeError("accounts_backend 未初始化(先调 init)")
        return _REALMS["__default__"]
    key = re.sub(r"[^A-Za-z0-9_-]", "_", str(key))[:40]
    r = _REALMS.get(key)
    if r is not None:
        return r
    with _REALMS_LOCK:
        r = _REALMS.get(key)
        if r is None:
            base_dir = os.path.dirname(os.path.abspath(_BASE_PATH or "accounts.json"))
            path = os.path.join(base_dir, "accounts-%s.json" % key)
            store = AccountStore(path)
            r = Realm(key, store, QRLoginManager(store))
            _REALMS[key] = r
    return r


def set_request_realm(realm):
    """web.py 在处理 /api/account/* 与 /api/game/* 前设置请求期领域。
    返回 token 供恢复(FastAPI 每请求独立上下文,通常无需手动 reset)。"""
    return _REQ_REALM.set(realm)


def request_realm():
    r = _REQ_REALM.get()
    if r is not None:
        return r
    return _REALMS.get("__default__")

# 3.8.0 复查修复:三份诊断快照(轮询/userinfo/检测)已从模块级全局下沉为
# QRLoginManager 的**实例属性**(self.last_poll/last_userinfo/last_check),
# 每账号领域一套,故 /api/account/*/diag 天然按账号隔离,不再跨账号泄漏票据线索。


def _scan_token_like(obj, prefix="", out=None, depth=0):
    """递归扫描响应里所有「疑似登录票据」字段(键名含 token/ticket/tk/pk/t1/t2/
    key/auth/cred/sess/sid/code/str 等)且值像票据(较长的字母数字串)。用于确认响应
    里 token 不在 token/pk/t1 时,仍能定位真实票据字段。返回 {路径: 值缩略}(≤20)。"""
    import re as _re
    if out is None:
        out = {}
    if depth > 4 or len(out) >= 20:
        return out
    pat = _re.compile(r"token|ticket|^tk$|^pk$|^t1$|^t2$|key|auth|cred|sess|^sid$|code|_str|clientkey", _re.I)
    if isinstance(obj, dict):
        for k, v in obj.items():
            path = f"{prefix}.{k}" if prefix else str(k)
            if isinstance(v, str) and pat.search(str(k)) and len(v) >= 12:
                out[path] = (v[:24] + "…") if len(v) > 24 else v
            elif isinstance(v, (dict, list)):
                _scan_token_like(v, path, out, depth + 1)
    elif isinstance(obj, list):
        for i, v in enumerate(obj[:5]):
            if isinstance(v, (dict, list)):
                _scan_token_like(v, f"{prefix}[{i}]", out, depth + 1)
    return out


def _pick_token(data):
    """从确认响应 data 里尽力取登录票据:先认 token/pk/t1/t2,再退而扫描任一
    「疑似票据」字段(键名匹配 + 值像票据)。返回票据串或 ""。"""
    if not isinstance(data, dict):
        return ""
    for k in ("token", "pk", "t1", "t2", "clientkey", "key"):
        v = data.get(k)
        if isinstance(v, str) and len(v) >= 12:
            return v
    # 扫描兜底:取第一个疑似票据字段的完整值
    import re as _re
    pat = _re.compile(r"token|ticket|^tk$|^pk$|^t1$|^t2$|clientkey|auth|cred|clientkey", _re.I)

    def walk(o, d=0):
        if d > 4 or not isinstance(o, (dict, list)):
            return ""
        items = o.items() if isinstance(o, dict) else enumerate(o[:5])
        for k, v in items:
            if isinstance(v, str) and pat.search(str(k)) and len(v) >= 16:
                return v
            if isinstance(v, (dict, list)):
                r = walk(v, d + 1)
                if r:
                    return r
        return ""
    return walk(data)


def _scan_coin_like(obj, prefix="", out=None, depth=0):
    """递归扫描响应里所有「疑似货币/星币」字段(键名含 coin/star/币/bean/
    balance/money/rich/gold/diamond/point 等)及其数值,便于在真机诊断里一眼
    看出星币究竟落在哪个字段(即便不叫 coin)。返回 {路径: 值} (最多 30 条)。"""
    import re as _re
    if out is None:
        out = {}
    if depth > 4 or len(out) >= 30:
        return out
    pat = _re.compile(r"coin|star|币|bean|balance|money|rich|gold|diamond|point|score|value|amount", _re.I)
    if isinstance(obj, dict):
        for k, v in obj.items():
            path = f"{prefix}.{k}" if prefix else str(k)
            if isinstance(v, (int, float, str)) and pat.search(str(k)):
                out[path] = v
            elif isinstance(v, (dict, list)):
                _scan_coin_like(v, path, out, depth + 1)
    elif isinstance(obj, list):
        for i, v in enumerate(obj[:5]):
            if isinstance(v, (dict, list)):
                _scan_coin_like(v, f"{prefix}[{i}]", out, depth + 1)
    return out


def _snap_userinfo(src, http_status, j, data, raw):
    """把一次 getUserInfo 取数结果构造诊断快照 dict 并打印一行日志(3.8.0:返回快照交调用方按账号存)。
    便于真机 CLASH TUN 下判定星币为何取不到:是未登录(data 为空/无 kugouId)、
    还是 coin 落在别的字段(coinLike 里能看到所有疑似货币字段及其值)。"""
    import sys
    keys = list(data.keys()) if isinstance(data, dict) else []
    coin = data.get("coin") if isinstance(data, dict) else None
    code = (j.get("code") if isinstance(j, dict) else None)
    coin_like = _scan_coin_like(j if isinstance(j, (dict, list)) else {})
    snap = dict({
        "src": src, "http": http_status, "code": code,
        "hasData": isinstance(data, dict) and bool(data.get("kugouId")),
        "dataKeys": keys[:40], "coin": coin, "coinLike": coin_like,
        "raw": (raw or "")[:800], "at": int(time.time()),
    })
    logged_in = isinstance(data, dict) and bool(data.get("kugouId"))
    verdict = ("已登录, coin=%r" % coin) if logged_in else "未登录/空档案(星币取不到)"
    try:
        print("[账号] %s → code=%s http=%s %s | 疑似货币字段=%s"
              % (src, code, http_status, verdict, coin_like or "(无)"), file=sys.stderr)
    except Exception:      # noqa: BLE001
        pass
    return snap


def init(accounts_path):
    global STORE, QR, _BASE_PATH
    _BASE_PATH = accounts_path
    STORE = AccountStore(accounts_path)
    QR = QRLoginManager(STORE)
    _REALMS["__default__"] = Realm("__default__", STORE, QR)
    return STORE, QR


def get_current_raw():
    """**请求期领域**当前选择账号的原始 dict(含票据),供真实游戏后端读取。
    登录系统启用时 = 当前登录用户自己的账号库;未启用时 = 默认领域(旧行为)。
    空库返回 None。"""
    realm = request_realm()
    return realm.store.current_raw() if realm is not None else None


# ── 路由处理(被 server.py 调用)──
def handle_api(path, q, realm=None):
    """/api/account/* 路由。返回 (status, obj) 或 None(非本模块路由)。
    realm 未显式给出时取请求期领域(contextvars);两者皆空回默认领域。"""
    realm = realm or request_realm()
    if realm is None or realm.qr is None or realm.store is None:
        return 503, {"ok": False, "error": "accounts_backend_uninitialized"}
    STORE, QR = realm.store, realm.qr   # noqa: N806 —— 局部遮蔽,函数体零改动

    if path == "/api/account/qr/create":
        return 200, QR.create()

    if path == "/api/account/qr/poll":
        sid = (q.get("sid") or [""])[0]
        return 200, QR.poll(sid)

    if path == "/api/account/qr/diag":
        # 诊断:返回最近一次「非待扫」轮询的原始响应(排查卡在「已扫描」)。
        return 200, {"ok": True, "lastPoll": dict(realm.qr.last_poll)}

    if path == "/api/account/userinfo/diag":
        # 诊断:返回最近一次 getUserInfo/V2 的原始响应结构(排查「星币取不到」)。
        # hasData=false 即未登录态(会话没建立);dataKeys 里若无 coin 但登录了,
        # 则字段名与预期不符。真机 CLASH TUN 下点一次账号旁 ⟳ 再看此端点即可定位。
        return 200, {"ok": True, "lastUserInfo": dict(realm.qr.last_userinfo)}

    if path == "/api/account/list":
        return 200, STORE.list_public()

    if path == "/api/account/switch":
        kid = (q.get("kugouId") or [""])[0]
        ok = STORE.set_current(kid)
        return 200, {**STORE.list_public(), "ok": ok}

    if path == "/api/account/remove":
        kid = (q.get("kugouId") or [""])[0]
        ok = STORE.remove(kid)
        return 200, {**STORE.list_public(), "ok": ok}

    if path == "/api/account/refresh":
        kid = (q.get("kugouId") or [""])[0]
        acct = QR.refresh_account(kid)
        return 200, {**STORE.list_public(), "ok": bool(acct), "account": acct}

    if path == "/api/account/check":
        # 检测单个账号是否有效。envelope 恒 ok:true(请求本身成功),
        # 判定结果在 status(valid/invalid/error)+ reason 里,附最新列表供重绘。
        kid = (q.get("kugouId") or [""])[0]
        res = QR.check_account(kid)
        return 200, {**STORE.list_public(), **res, "ok": True}

    if path == "/api/account/check_all":
        # 一次性顺序检测全部账号(前端亦可逐个并发调 /check 以实时回填)。
        return 200, QR.check_all()

    if path == "/api/account/check/diag":
        # 诊断:最近一次检测的官方原始响应(code/http/raw),供科学测试法校准判据。
        return 200, {"ok": True, "lastCheck": dict(realm.qr.last_check)}

    return None
