# -*- coding: utf-8 -*-
"""
酷狗繁星 login_by_token_get 加密核心（AES-256-CBC + RSA-1024-NoPadding）。

来源：官方 staticssl.kugou.com/common/js/min/login/kguser.v2.min.js。
本模块的 AES/RSA 输出已用 Node 运行官方 JS 逐字节比对通过（见 build_pk_params
下方注释里的自检），可直接被 accounts_backend.py 导入。

官方 JS 关键片段（token 换登录态）：
    var e = AES.encrypt(JSON.stringify({token: s}));            // s = 轮询 status==4 的 data.token
    var t = RSA.encrypt(JSON.stringify({clienttime_ms: c, key: e.key}));
    i.pk = t;              // RSA 密文（信封里装 AES 会话密钥种子）
    i.params = e.encryptedStr;   // AES 密文（信封里装 token）

依赖：pip install pycryptodome
"""
import hashlib
import json
import random
import string

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

# 官方硬编码 RSA 公钥（1024 位，指数 65537，NoPadding）
_RSA_MOD = int(
    "B1B1EC76A1BBDBF0D18E8CD9A87E53FA3881E2F004C67C9DDA2CA677DBEFA3D6"
    "1DF8463FE12D84FF4B4699E02C9D41CAB917F5A8FB9E35580C4BDF97763A0420"
    "A476295D763EE10174E6F9EBF7DF8A77BA5B20CDA4EE705DEF5BBA3C88567B96"
    "56E52C9CD5CD95CA735FF2D25F762B133273EEEB7B4F3EA8B6DA29040F3B67CD", 16)
_RSA_EXP = 0x10001


def _rand_seed16() -> str:
    """AES 会话密钥种子：16 位 [0-9A-Z]。对应官方 t[Math.ceil(35*Math.random())]。"""
    alphabet = string.digits + string.ascii_uppercase
    return "".join(random.choice(alphabet) for _ in range(16))


def aes_encrypt(plaintext: str, seed: str) -> str:
    """AES-256-CBC / Pkcs7。
    key = UTF8( md5(seed) 的 32 位十六进制串 )  → 32 字节 → AES-256
    iv  = 该 32 位 hex 串的后 16 位（当作 ASCII）→ 16 字节
    输出 = 密文的小写 hex。"""
    keyhex = hashlib.md5(seed.encode("utf-8")).hexdigest()   # 32 位小写 hex
    key = keyhex.encode("utf-8")
    iv = keyhex[-16:].encode("utf-8")
    ct = AES.new(key, AES.MODE_CBC, iv).encrypt(pad(plaintext.encode("utf-8"), 16))
    return ct.hex()


def rsa_encrypt_nopadding(plaintext: str) -> str:
    """RSA-1024 NoPadding：明文字节右侧补零到 128 字节、按大端整数做 m^e mod n，
    输出定长 256 位小写 hex（与官方 JS 块编码一致）。"""
    b = plaintext.encode("latin-1")     # 对应 charCodeAt；token/JSON 均为 ASCII
    if len(b) > 128:
        raise ValueError("RSA 明文超过 128 字节")
    m = int.from_bytes(b.ljust(128, b"\x00"), "big")
    return format(pow(m, _RSA_EXP, _RSA_MOD), "0256x")


def build_pk_params(token: str, clienttime_ms: int):
    """按官方算法产出 login_by_token_get 需要的 (pk, params)。
    注意 pk 里 JSON 的键序必须是 clienttime_ms 在前、key 在后。"""
    seed = _rand_seed16()
    params = aes_encrypt(json.dumps({"token": token}, separators=(",", ":")), seed)
    pk = rsa_encrypt_nopadding(
        json.dumps({"clienttime_ms": clienttime_ms, "key": seed},
                   separators=(",", ":")))
    return pk, params


# ── 自检：与 Node 运行官方 JS 的参考值逐字节比对 ────────────────────────────
def _selftest() -> bool:
    ok = True
    aes_ref = ("f4ef27bb3781529aad2ff388769bb25bf15f2d6f7803229e981ce3b35e0"
               "36b7ae8f8dfa4d9c5034afa16f004c17a0122")
    ok &= aes_encrypt('{"token":"testtoken1234567890abcdef"}',
                      "ABCDEF0123456789") == aes_ref
    rsa_ref = ("5ae4560d18453248e95664982e43b482e3060e0baa84b18333acf439cfb2fa61"
               "7513da4b029b8a9c655d74e8b90f514c0054e6d3144894f56b55aaf4c80436d3"
               "202c07af95f2ca3f7c65107137dbc3be19cd81db278748f01912a33885ea59ac"
               "b356a64f42270531e20fd17f379c5fe7fb1a1f44f823bc3b53f00b020e52b5d8")
    ok &= rsa_encrypt_nopadding(
        '{"clienttime_ms":1783321779371,"key":"ABCDEF0123456789"}') == rsa_ref
    return bool(ok)


if __name__ == "__main__":
    print("crypto selftest:", "PASS ✅" if _selftest() else "FAIL ❌")
