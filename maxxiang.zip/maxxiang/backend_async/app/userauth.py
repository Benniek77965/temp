"""
userauth.py — 登录系统(3.8.0):外部 MySQL 用户库(tb_user)身份识别 + 服务端会话
================================================================================
定位:给观测台前端加「必须登录才能用」的门,并让「主播名录 / 账号」两块数据
按登录账号隔离(名录绑定存 PG,见 db.py;酷狗账号库按用户分文件,见 accounts)。

设计要点(全部经本地 1:1 复刻库实测,非印象推断):
  · **对既有表绝对只读**:身份只查 `tb_user`(user_name 唯一键 / pass_word /
    due_time 到期 / is_off 封停),不 INSERT/UPDATE/ALTER 任何已存在表。
    新建表全部 `guantai_` 前缀(CREATE TABLE IF NOT EXISTS,幂等),
    满足「允许建新表、不许改旧表」的硬约束。
  · **gbk 连接**:现有库默认 gbk 且 user_name 列 gbk_bin —— aiomysql 以
    charset=gbk 建连,中文用户名参数化查询才不乱码;gbk_bin 同时意味着
    用户名**区分大小写**(逐字节比较),登录语义与既有业务一致。
    用户名含 gbk 无法表示的字符(如 emoji)时,编码失败按「用户名或密码错误」处理。
  · **口令形态自适应**:pass_word varchar(50) 的存量形态未知且不可远程改表 ——
    校验同时尝试「明文逐字节 / MD5 / SHA1 / SHA256(hex)」,全部 hmac.compare_digest
    常数时间比较;varchar(50) 天然排除 bcrypt(60 字)。哪种形态命中都能登录,
    不需要预先知道存量口令是怎么存的(scripts/userdb_check.py 可实测统计形态)。
  · **会话 = 服务端不透明令牌**:secrets.token_hex(32) 下发 HttpOnly Cookie,
    库里只存 SHA-256(令牌不落库,拖库不可重放);单设备互顶(可配)与
    到期/封停的**逐次复核**都以库为准。
  · **公网用户库的现实约束**:用户库在公网(RTT 高、可能抖动),逐请求回源
    不可接受 —— 进程内会话缓存(默认 20s)+ 故障降级窗(默认 10 分钟内
    已验证会话继续放行,新登录不受理),观测台不因用户库瞬断而整体熄火。
    互顶/登出经 Redis `guantai:user:kick` 广播即时失效本地缓存(多进程一致)。
  · **登录节流**:失败计数按「用户名 / 来源 IP」双维度落 Redis(窗口+锁定可配),
    Redis 不可用时退化为进程内计数,永不因风控组件故障而放开暴力破解。
  · **CSRF**:会话走 Cookie(SameSite=Lax),另要求自定义头 `X-JF-Auth`
    (跨站表单/顶级导航无法伪造自定义头;fetch 跨源带自定义头必被 CORS 预检拦)。
    仅两类天然无法带头的端点豁免:SSE `/api/events`(EventSource)与
    `<img>` 直连的 `/fx/avatar` —— 两者皆为只读。

对外接口(web.py 消费):
    init(cfg, redis_client)        生命周期内初始化(建池 + 建表 + 起 kick 订阅/清扫任务)
    close()                        收尾
    enabled()                      登录系统是否启用(host 配了才算)
    router                         /api/auth/login|logout|session
    guard(request)                 中间件守卫:None=放行(state.user 已注入)/ JSONResponse=拦截
"""
from __future__ import annotations

import asyncio
import contextlib
import datetime
import hashlib
import hmac
import ipaddress
import json
import os
import re
import secrets
import time
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple
from urllib.parse import urlparse

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, Response

from .powproof import pow_answer as _reg_pow_transform   # 注册 R2 复用 L2 执行证明变换
from . import userdb_pool                                # 4.5.0:用户库多网络入口路由
from .userdb_pool import heavy_reads   # 5.4.0:管理台分析型查询超时不熔断入口
from . import clientip                                   # 5.2.0:统一「可信代理」来源 IP 判定
from . import wincount                                   # 5.2.0:全项目共用的原子窗口计数

try:
    import aiomysql
except Exception:                    # noqa: BLE001 —— 未装驱动时登录系统整体禁用(旧部署零影响)
    aiomysql = None

from .settings import UserAuthCfg

KICK_CHANNEL = "guantai:user:kick"          # 互顶/登出广播频道(payload = token_hash)
# 4.2.0:VIP 能力矩阵由 web.py 启动时注入(单一真源在 web.VIP_MATRIX;
# userauth 刻意不 import web —— 那会形成循环依赖)。未注入时为空列表,
# 前端据此退化为「不显示对比表」,不影响任何其它功能。
# 4.4.0:注入物可以是 list(旧)**或 callable**(新,web.vip_matrix)。改可调是因为
# road 行文案随热更项 jf_basic_online_h 变,启动时定格会在改窗后变成谎话。
# 两种形态都接受 —— 旧部署/测试桩直接塞 list 仍逐字节可用。
jf_matrix = []
_TOUCH_MIN_S = 60.0                          # last_seen 回写的最小间隔(限频,省公网往返)

# last_seen 回写任务的强引用集(见 validate 内的说明)。
_TOUCH_TASKS: set = set()
_HEX32 = re.compile(r"^[0-9a-fA-F]{32}$")
_HEX40 = re.compile(r"^[0-9a-fA-F]{40}$")
_HEX64 = re.compile(r"^[0-9a-fA-F]{64}$")

# 新建表(幂等;gbk 与既有库一致,注释中文可正常落库)。只建新表,不动任何旧表。
_SCHEMA = [
    """CREATE TABLE IF NOT EXISTS guantai_user_session (
         id            BIGINT      NOT NULL AUTO_INCREMENT,
         user_id       BIGINT      NOT NULL COMMENT '关联 tb_user.id',
         user_name     VARCHAR(50) NOT NULL DEFAULT '' COMMENT '冗余用户名(审计可读)',
         token_hash    CHAR(64)    NOT NULL COMMENT '会话令牌的 SHA-256(令牌本身不落库)',
         created_at    DATETIME    NOT NULL,
         last_seen_at  DATETIME    NOT NULL,
         expires_at    DATETIME    NOT NULL,
         ip            VARCHAR(45) NOT NULL DEFAULT '',
         ua            VARCHAR(200) NOT NULL DEFAULT '',
         revoked       TINYINT     NOT NULL DEFAULT 0 COMMENT '1=已失效',
         revoke_reason VARCHAR(20) NOT NULL DEFAULT '' COMMENT 'kicked/logout/evicted/admin',
         PRIMARY KEY (id),
         UNIQUE KEY uk_token (token_hash),
         KEY idx_user (user_id, revoked)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台登录会话(登录系统 3.8.0 新建)'""",
    """CREATE TABLE IF NOT EXISTS guantai_login_log (
         id         BIGINT      NOT NULL AUTO_INCREMENT,
         user_id    BIGINT      NOT NULL DEFAULT 0,
         user_name  VARCHAR(50) NOT NULL DEFAULT '',
         ip         VARCHAR(45) NOT NULL DEFAULT '',
         ua         VARCHAR(200) NOT NULL DEFAULT '',
         ok         TINYINT     NOT NULL DEFAULT 0,
         reason     VARCHAR(30) NOT NULL DEFAULT '' COMMENT 'ok/bad_credentials/banned/expired/throttled',
         created_at DATETIME    NOT NULL,
         PRIMARY KEY (id),
         KEY idx_name_time (user_name, created_at),
         KEY idx_time (created_at)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台登录审计(登录系统 3.8.0 新建)'""",
    # ── 注册系统(4.0.0)三张新表:同样 guantai_ 前缀、幂等、零触碰旧表。
    #    reg_mode=off 时照建(幂等、零引用)—— 与既有两表同一 _ensure_schema 通道,
    #    保证任何时刻热切到 invite/open 都不缺表。
    """CREATE TABLE IF NOT EXISTS guantai_invite_code (
         id           BIGINT       NOT NULL AUTO_INCREMENT,
         code         VARCHAR(20)  NOT NULL COMMENT 'Crockford Base32,存大写去分隔',
         days_granted INT          NOT NULL DEFAULT 0 COMMENT '注册成功赠送天数(0=不赠)',
         quota        INT          NOT NULL DEFAULT 1 COMMENT '可用次数',
         used_count   INT          NOT NULL DEFAULT 0,
         expires_at   DATETIME     NULL     COMMENT 'NULL=不过期',
         disabled     TINYINT      NOT NULL DEFAULT 0,
         note         VARCHAR(100) NOT NULL DEFAULT '',
         created_at   DATETIME     NOT NULL,
         PRIMARY KEY (id),
         UNIQUE KEY uk_code (code)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台注册邀请码(4.0.0 新建)'""",
    """CREATE TABLE IF NOT EXISTS guantai_reg_log (
         id         BIGINT       NOT NULL AUTO_INCREMENT,
         user_id    BIGINT       NOT NULL DEFAULT 0 COMMENT '成功时=新 tb_user.id',
         user_name  VARCHAR(50)  NOT NULL DEFAULT '',
         ip         VARCHAR(45)  NOT NULL DEFAULT '',
         ua         VARCHAR(200) NOT NULL DEFAULT '',
         fp         CHAR(16)     NOT NULL DEFAULT '' COMMENT '设备指纹摘要(前16hex,可空)',
         invite_id  BIGINT       NOT NULL DEFAULT 0,
         ok         TINYINT      NOT NULL DEFAULT 0,
         reason     VARCHAR(30)  NOT NULL DEFAULT '' COMMENT 'ok/name_taken/pow_failed/…',
         created_at DATETIME     NOT NULL,
         PRIMARY KEY (id),
         KEY idx_ip_time (ip, created_at),
         KEY idx_time (created_at),
         KEY idx_fp (fp),
         KEY idx_name (user_name)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台注册审计(4.0.0 新建；并入每日清扫)'""",
    # ↑ 4.0.7:idx_name 补齐 —— 管理台流水的四个筛选维度里,ip/时刻/指纹各有
    #   索引,唯独 user_name 等值筛选一直在全表扫(留存期配长后逐日劣化)。
    #   CREATE IF NOT EXISTS 只惠及新库;存量库请手动执行
    #   ALTER TABLE guantai_reg_log ADD KEY idx_name (user_name);(在线 DDL,秒级)。
    """CREATE TABLE IF NOT EXISTS guantai_user_block (
         user_id    BIGINT       NOT NULL COMMENT '关联 tb_user.id',
         reason     VARCHAR(30)  NOT NULL DEFAULT '' COMMENT 'malicious_reg/manual/…',
         note       VARCHAR(100) NOT NULL DEFAULT '',
         created_at DATETIME     NOT NULL,
         PRIMARY KEY (user_id)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台侧封禁(4.0.0 新建；不触碰 tb_user.is_off)'""",
    # ── 链接快速登录(4.1.0)一张新表:同 guantai_ 前缀、幂等、零触碰旧表。
    #    sso_enabled=off 时照建(零引用)—— 与注册三表同一 _ensure_schema 通道,
    #    保证任何时刻热开 SSO 都不缺表。签发方(同库其它项目)只 INSERT,
    #    观测台只 SELECT + 单语句原子核销 UPDATE(used 0→1)。
    """CREATE TABLE IF NOT EXISTS guantai_sso_ticket (
         id         BIGINT      NOT NULL AUTO_INCREMENT,
         user_id    BIGINT      NOT NULL COMMENT '关联 tb_user.id(签发方写)',
         token_hash CHAR(64)    NOT NULL COMMENT '票据的 SHA-256(票据本身不落库)',
         created_at DATETIME    NOT NULL COMMENT '签发时刻(签发方写 NOW())',
         expires_at DATETIME    NOT NULL COMMENT '签发方定的失效时刻(建议 NOW()+60s)',
         used       TINYINT     NOT NULL DEFAULT 0 COMMENT '1=已核销(单次有效)',
         used_at    DATETIME    NULL,
         used_ip    VARCHAR(45) NOT NULL DEFAULT '',
         note       VARCHAR(50) NOT NULL DEFAULT '' COMMENT '签发方备注(审计可读,可空)',
         PRIMARY KEY (id),
         UNIQUE KEY uk_token (token_hash),
         KEY idx_exp (expires_at)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='跨项目链接快速登录票据(4.1.0 新建;签发方=同库其它项目)'""",
    # ── 九法 VIP(4.2.0)四张新表:同一 guantai_ 前缀纪律、幂等自建、零触碰旧表。
    #    jf_vip_enabled=off 时照建(与注册/SSO 同款「关着也建、零引用」),
    #    保证任何时刻热开 VIP 体系都不缺表。
    """CREATE TABLE IF NOT EXISTS guantai_jf_vip (
         user_id     BIGINT   NOT NULL COMMENT '关联 tb_user.id',
         vip_until   DATETIME NOT NULL COMMENT '九法VIP到期(一律由库钟判定)',
         first_at    DATETIME NOT NULL COMMENT '首次开通时刻(留存分析)',
         total_hours INT      NOT NULL DEFAULT 0 COMMENT '累计开通小时数',
         updated_at  DATETIME NOT NULL,
         PRIMARY KEY (user_id),
         KEY idx_until (vip_until)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='九法VIP到期(4.2.0 新建)'""",
    """CREATE TABLE IF NOT EXISTS guantai_jf_order (
         id               BIGINT        NOT NULL AUTO_INCREMENT,
         gateway_order_no VARCHAR(64)   NOT NULL COMMENT '网关订单号(幂等的物理底线)',
         user_id          BIGINT        NOT NULL,
         user_name        VARCHAR(50)   NOT NULL DEFAULT '',
         plan_code        VARCHAR(16)   NOT NULL COMMENT 'd3/m1/m3',
         jf_hours         INT           NOT NULL DEFAULT 0 COMMENT '下单时的档位快照(改价不影响在途单)',
         dd_hours         INT           NOT NULL DEFAULT 0 COMMENT '同上:赠送小叮当时长快照',
         amount           DECIMAL(10,2) NOT NULL COMMENT '网关 price(单一真源,非用户请求金额)',
         status           VARCHAR(16)   NOT NULL DEFAULT 'pending' COMMENT 'pending/paid/expired',
         credited         TINYINT       NOT NULL DEFAULT 0 COMMENT '1=已开通(幂等哨兵)',
         is_simulate      TINYINT       NOT NULL DEFAULT 0,
         ip               VARCHAR(45)   NOT NULL DEFAULT '',
         create_time      DATETIME      NOT NULL,
         expire_time      DATETIME      NULL,
         pay_time         DATETIME      NULL,
         PRIMARY KEY (id),
         UNIQUE KEY uk_order (gateway_order_no),
         KEY idx_user (user_id, id),
         KEY idx_status_time (status, create_time)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='九法VIP在线充值订单(4.2.0 新建)'""",
    """CREATE TABLE IF NOT EXISTS guantai_jf_card (
         id         BIGINT       NOT NULL AUTO_INCREMENT,
         card       VARCHAR(32)  NOT NULL COMMENT 'TL+6字母+6数字(排除 I/O/0/1);JF 为历史前缀,仍可兑换',
         plan_code  VARCHAR(16)  NOT NULL,
         batch      VARCHAR(32)  NOT NULL DEFAULT '' COMMENT '批次号(发卡/召回按批)',
         note       VARCHAR(100) NOT NULL DEFAULT '',
         disabled   TINYINT      NOT NULL DEFAULT 0 COMMENT '1=作废(仅未使用卡可召回)',
         used_by    BIGINT       NOT NULL DEFAULT 0 COMMENT '0=未使用;否则 tb_user.id',
         used_name  VARCHAR(50)  NOT NULL DEFAULT '',
         used_at    DATETIME     NULL,
         created_by VARCHAR(32)  NOT NULL DEFAULT '',
         created_at DATETIME     NOT NULL,
         PRIMARY KEY (id),
         UNIQUE KEY uk_card (card),
         KEY idx_batch (batch),
         KEY idx_used (used_by, used_at)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='九法VIP卡密池(4.2.0 新建)'""",
    """CREATE TABLE IF NOT EXISTS guantai_jf_grant_log (
         id         BIGINT        NOT NULL AUTO_INCREMENT,
         user_id    BIGINT        NOT NULL,
         user_name  VARCHAR(50)   NOT NULL DEFAULT '',
         source     VARCHAR(16)   NOT NULL COMMENT 'order/card/admin/revoke',
         ref        VARCHAR(64)   NOT NULL DEFAULT '' COMMENT '订单号/卡号',
         plan_code  VARCHAR(16)   NOT NULL DEFAULT '',
         amount     DECIMAL(10,2) NOT NULL DEFAULT 0,
         jf_hours   INT           NOT NULL DEFAULT 0 COMMENT '本次九法VIP增量(负=撤销)',
         dd_hours   INT           NOT NULL DEFAULT 0 COMMENT '本次赠送小叮当增量',
         vip_before DATETIME      NULL,
         vip_after  DATETIME      NULL,
         due_before DATETIME      NULL,
         due_after  DATETIME      NULL,
         operator   VARCHAR(32)   NOT NULL DEFAULT '',
         created_at DATETIME      NOT NULL,
         PRIMARY KEY (id),
         KEY idx_user (user_id, id),
         KEY idx_time (created_at),
         KEY idx_source (source, created_at)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='九法VIP开通流水(唯一对账口径;4.2.0 新建)'""",
]


@dataclass
class Principal:
    """一次通过校验的登录身份(注入 request.state.user)。"""
    user_id: int
    user_name: str
    session_id: int
    token_hash: str
    due_time_iso: str = ""
    degraded: bool = False           # True = 用户库瞬断,凭缓存降级放行
    # ── 九法 VIP 档位(4.2.0)。VIP 体系关闭时恒为 (True, "", False) → tier="basic",
    #    而 _vip_guard 在体系关闭时根本不生效,故对旧部署零语义影响。
    dd_alive: bool = True            # 小叮当(tb_user.due_time)是否有效
    jf_vip_until_iso: str = ""       # 九法VIP到期(空 = 从未开通)
    jf_alive: bool = False           # 九法VIP是否有效

    @property
    def tier(self) -> str:
        """free / basic / vip —— 判定顺序刻意让 jf 优先:
        「VIP有效但小叮当到期」(运营手动开通、或小叮当侧被手工改小)必须落 vip 档,
        绝不能出现「付了钱反而没数据」。"""
        if self.jf_alive:
            return "vip"
        return "basic" if self.dd_alive else "free"

    def public(self) -> dict:
        return {"id": self.user_id, "userName": self.user_name,
                "dueTime": self.due_time_iso, "dueDays": _due_days(self.due_time_iso),
                # 4.2.0:档位与两条独立时间线(前端顶栏身份牌要分两行显示,
                # 否则用户看到「剩30天」却被限制会直接判定是 bug)
                "tier": self.tier, "ddAlive": bool(self.dd_alive),
                "jfVipUntil": self.jf_vip_until_iso,
                "jfVipDays": (_due_days(self.jf_vip_until_iso)
                              if self.jf_vip_until_iso else None)}


def _due_days(due_iso: str) -> Optional[int]:
    """到期剩余整天数(仅展示用,权威判定在 SQL 的 due_time > NOW())。

    4.0.1:向下取整 → **就近取整(半日进位)**。旧口径下"注册赠 7 天"的下一秒
    chip 即显示「剩 6 天」(6.99…→6),在最需要建立信任的时刻少报一天;就近取整
    使赠 N 天当刻即显示 N,同时保留 <12h 归 0 触发前端「今日到期」警示的语义
    (纯 ceil 会失去该警示,故不取)。"""
    try:
        import datetime as _dt
        d = _dt.datetime.fromisoformat(due_iso)
        return max(0, int((d - _dt.datetime.now()).total_seconds() / 86400 + 0.5))
    except Exception:                # noqa: BLE001
        return None


class _CacheEntry:
    __slots__ = ("principal", "checked_mono", "touched_mono")

    def __init__(self, principal: Principal, mono: float):
        self.principal = principal
        self.checked_mono = mono      # 最近一次「过库复核成功」的单调钟
        self.touched_mono = mono      # 最近一次 last_seen 回写


class _State:
    cfg: UserAuthCfg = None          # type: ignore[assignment]
    router = None                    # userdb_pool.Router(多网络入口连接池路由,4.5.0)
    redis = None                     # redis.asyncio client(节流 + kick 广播)
    cache: Dict[str, _CacheEntry] = {}
    schema_ok: bool = False
    schema_lock: asyncio.Lock = None  # type: ignore[assignment]
    tasks: list = []
    mem_fail: Dict[str, Tuple[int, float]] = {}   # Redis 不可用时的进程内失败计数
    mem_reg: Dict[str, Tuple[int, float]] = {}    # 4.0.0:注册限流的进程内兜底计数
    mem_sso: Dict[str, Tuple[int, float]] = {}    # 4.1.0:SSO 兑换限频的进程内兜底计数
    init_error: str = ""
    reg_probe: Dict[str, Any] = {}                # 4.0.4:注册启动自检结果(供管理台/日志)
    dev_key: bytes = b""                         # 5.2.0:设备信任 Cookie 的 HMAC 密钥
    dev_key_src: str = ""
    dev_key_at: float = 0.0
    lg_attack: tuple = ()                         # 5.2.0:全局攻击态缓存 (单调钟, 是否, 计数)
    cap_down_until: float = 0.0                   # 5.2.0:登录人机验证供应商熔断截止(单调钟)
    lg_warned: Dict[str, float] = {}              # 5.2.0:同类告警日志限频
    risk_cache: tuple = ()                        # 5.2.0:管理台「登录风控」概览短缓存 (键, 单调钟, 数据)

    # ── `UA.pool` 兼容属性(4.5.0)────────────────────────────────────────────
    # 改造前 `UA.pool` 是那唯一一个 aiomysql 池;多入口之后「池」不再是单数,
    # 真身换成了 `UA.router`。但 **既有测试夹具用 `UA.pool = None` 表达「丢弃
    # 连接状态、下次自动重建」**(tests/test_jfvip_db.py 等四处),那是一个明确
    # 而合理的契约,不该因为内部重构而失效 —— 故保留同名属性:
    #   · 读:路由器本身(None = 尚未建立,真值判断与旧代码一致);
    #   · 写 None:同步拆掉全部入口的池与探活任务,下次调用自动重建。
    @property
    def pool(self):
        return self.router

    @pool.setter
    def pool(self, value) -> None:
        if value is None:
            r, self.router = self.router, None
            # 只对**真的路由器**做拆除。既有 ASGI 测试用
            # `monkeypatch.setattr(UA, "pool", object())` 塞一个哨兵对象来让
            # enabled() 成立(tests/test_jfvip_asgi.py:118 等),monkeypatch 在
            # 收尾时会把它设回 None —— 若在这里无条件调 terminate_sync,哨兵没有
            # 这个方法,49 个 ASGI 用例会在 teardown 阶段整片报错(实测)。
            if hasattr(r, "terminate_sync"):
                r.terminate_sync()
        else:
            self.router = value


UA = _State()


def enabled() -> bool:
    return bool(UA.cfg is not None and UA.cfg.enabled and aiomysql is not None)


# ── 初始化 / 收尾 ─────────────────────────────────────────────────────────────
async def init(cfg: UserAuthCfg, redis_client=None) -> None:
    """web 生命周期内调用。建池失败**不抛**(观测台仍可起,登录端点回 503 并持续重试),
    但建表/连通性问题会打醒目日志 —— 用户库在公网,启动窗口的瞬断不该杀死整栈。"""
    UA.cfg = cfg
    UA.redis = redis_client
    clientip.configure(getattr(cfg, "trusted_proxies", None))   # 5.2.0:yaml 亦可配(环境变量优先)
    UA.schema_lock = asyncio.Lock()
    UA.cache = {}
    if not enabled():
        if cfg.enabled and aiomysql is None:
            print("[登录] ⚠️ 已配置用户库但缺少 aiomysql 依赖 —— 登录系统禁用。"
                  "请 pip install aiomysql(requirements.txt 已含)。")
        return
    await _ensure_pool(log=True)
    with contextlib.suppress(Exception):
        await _ensure_schema()
    # kick 广播订阅(互顶/登出即时失效本进程缓存)+ 定时清扫(5.4.0:统一引擎,见 _janitor)
    if UA.redis is not None:
        UA.tasks.append(asyncio.create_task(_kick_listener()))
    UA.tasks.append(asyncio.create_task(_janitor()))
    print(f"[登录] 登录系统已启用 · 用户库 {cfg.user}@{cfg.host}:{cfg.port}/{cfg.db} "
          f"charset={cfg.charset} · 会话 {cfg.session_ttl_h:.0f}h/空闲 {cfg.idle_ttl_h:.0f}h "
          f"· 单设备互顶={'开' if cfg.single_device else '关'} · 名录上限 {cfg.room_max}/账号")
    _login_guard_report()             # 5.2.0:防爆破实际生效口径
    _reg_startup_report()
    # 4.0.4:注册可行性启动自检(登录启用即扫描;仅 reg_mode≠off 打印告警;
    # 零副作用、绝不阻断启动)
    with contextlib.suppress(Exception):
        await _reg_startup_probe()


async def close() -> None:
    for t in UA.tasks:
        t.cancel()
        with contextlib.suppress(BaseException):
            await t
    UA.tasks = []
    if UA.router is not None:
        r, UA.router = UA.router, None
        with contextlib.suppress(Exception):
            await r.close()


async def _ensure_router(log: bool = False):
    """建立(或复用)多入口路由器。

    4.5.0:`STA_USERDB_HOST` 现在可以是**一组**「同一逻辑库的网络入口」
    (`ip[:port][*权重]`,逗号分隔)。单值 = 恰好一个入口 = 与改造前逐字节同行为。
    建池本身不做网络 I/O(minsize=0),故本函数不会因为库不可达而卡住启动;
    真正的可用性由路由器的探活任务判定。
    """
    if UA.router is not None:
        return UA.router
    c = UA.cfg
    try:
        r = userdb_pool.Router(
            c,
            pool_max=int(getattr(c, "pool_max", 8) or 8),
            query_timeout_s=float(getattr(c, "query_timeout_s", 15.0) or 15.0),
            probe_s=float(getattr(c, "probe_s", 10.0) or 10.0))
        await r.start()
        UA.router = r
        UA.init_error = ""
        if log:
            n = len(r.endpoints)
            if n == 0:
                # 0 入口时绝不说「就绪」—— 横幅说了就绪、后面却全 503,是最误导
                # 运维的一种日志(详细成因由 Router.start() 已打的那条给出)。
                print("[登录] ⛔ 用户库没有任何可用入口 —— 登录系统将持续回 503,"
                      "请检查 STA_USERDB_HOST 的写法。")
            else:
                print(f"[登录] 用户库连接池就绪({r.summary_line()} → {c.db};"
                      f"入口 {n} 个 · 每入口至多 {r.per_pool_max} 连接 · "
                      f"查询超时 {r.query_timeout_s:g}s · 探活 {r.probe_s:g}s)")
    except Exception as e:             # noqa: BLE001
        UA.router = None
        UA.init_error = f"{type(e).__name__}: {e}"
        if log:
            print(f"[登录] ⚠️ 用户库暂不可达({UA.init_error})—— 登录请求将回 503,"
                  f"连接会在下次请求时自动重试。")
    return UA.router


async def _ensure_pool(log: bool = False):
    """兼容取池口:回**当下最闲的健康入口**的 aiomysql 池。

    三处手工事务(_register_tx / jfpay._reuse_after_dup / jfvip._grant_tx)直接
    `pool.acquire()` 后自持连接跑 BEGIN…COMMIT。一条连接只属于一个入口,故事务
    **天然整段落在同一个入口上**,与单入口时逐字节同语义(多入口是同一个 mysqld
    的多个网络入口 —— 行锁/自增/唯一键全部是全局的,不存在跨入口的一致性问题)。
    这里只多做一件事:让事务也挑一个当下最闲的健康入口,而不是永远钉在第一个。
    """
    r = await _ensure_router(log=log)
    return None if r is None else r.best_pool()


async def _ensure_schema() -> bool:
    """幂等建新表(guantai_*)。任何一次成功后进程内不再重复执行。"""
    if UA.schema_ok:
        return True
    async with UA.schema_lock:
        if UA.schema_ok:
            return True
        pool = await _ensure_pool()
        if pool is None:
            return False
        try:
            import warnings as _w
            async with pool.acquire() as conn:
                async with conn.cursor() as cur:
                    with _w.catch_warnings():
                        # CREATE TABLE IF NOT EXISTS 在表已存在时,MySQL 回 Note 级
                        # 告警、aiomysql 转 Python Warning —— 幂等建表的预期噪音,静默。
                        _w.simplefilter("ignore")
                        for ddl in _SCHEMA:
                            # 4.5.0:给 DDL 也套上查询预算。本函数在 init() 里被
                            # await,而 aiomysql 没有 read_timeout —— 公网链路半死时
                            # 一条 CREATE 就能把**整个 web 进程的启动**挂住。
                            await asyncio.wait_for(
                                cur.execute(ddl),
                                max(1.0, float(getattr(UA.cfg, "query_timeout_s", 15.0))))
            UA.schema_ok = True
            print("[登录] 会话/审计表就绪(guantai_user_session / guantai_login_log;"
                  "幂等 CREATE IF NOT EXISTS,未触碰任何既有表)")
            return True
        except Exception as e:         # noqa: BLE001
            print(f"[登录] ⚠️ 建表失败(将在下次登录时重试): {e!r}")
            return False


# ══════════════════════════════════════════════════════════════════════════════
# 字符集安全化(4.2.9)—— 本层拥有连接与字符集,故底座放这里,jfvip 只做别名
# ------------------------------------------------------------------------------
# 全表 CHARSET=gbk(随 tb_user 的历史字符集),aiomysql 以 charset=gbk 建连。
# 任何含 emoji 等 GBK 表示不了的字符的参数,在**编码 SQL 时**就抛
# UnicodeEncodeError —— 语句根本没发出去。真库逐条实测过的实际后果:
#   · _issue_session(ua=…)     ⇒ 异常上抛 ⇒ **登录回 503「用户库暂时不可用」**
#     (ua 是 User-Agent 头,完全由请求方控制)
#   · invite_lookup(code=…)    ⇒ **未登录用户**在注册页输入即可让端点 500
#   · _log_login/_log_reg      ⇒ 被 suppress 吞掉 ⇒ **审计行静默丢失**
#     (攻击者用 emoji User-Agent 即可让自己的登录尝试不留痕)
#   · invites_generate/blocks_set/_mint_sso_ticket(note=…) ⇒ 管理台 500 / 签发 503
#
# 两套口径,各有其正确性,绝不能混用:
#   · **写** → 不可表示字符换 '?'(gbk_text)。沿用 sso_link_note 的裁决:
#     「备注只是审计信息,不值得让操作失败」。
#   · **筛选** → 该条件命中零行(gbk_ok 回 False)。沿用 orders_page 对 user_name
#     的裁决:「gbk 表示不了的 ≡ 查无此人」。筛选侧**绝不能**换 '?' —— 那会静默
#     去查一个**不同的串**,屏幕显示「没有记录」,而人只会以为它不存在。
# 两者自洽:写入侧已把 emoji 换成 '?',故库里不可能存在含 emoji 的值。
# ══════════════════════════════════════════════════════════════════════════════
def _charset() -> str:
    """用户库连接字符集。读配置而不硬编码 gbk —— 部署可能换字符集。"""
    c = getattr(UA, "cfg", None)
    return str(getattr(c, "charset", "") or "gbk")


def gbk_ok(s) -> bool:
    """该串能否被连接字符集表示。**筛选侧**用:False ⇒ 该条件应命中零行。

    LookupError 也算 False:字符集名配错时保守收敛到「查不出」,而不是让一个
    配置错误变成满屏 500。
    """
    try:
        str(s if s is not None else "").encode(_charset())
        return True
    except (UnicodeEncodeError, LookupError):
        return False


def gbk_text(raw, limit: int) -> str:
    """**写入侧**用:截断 → 不可表示字符换 '?' → 复截。

    与 sso_link_note 逐字同款(替换只会等长或变短,复截是纯防御)。
    VARCHAR(n) 按**字符**计,故两次都按字符截。
    """
    s = str(raw if raw is not None else "")[:limit]
    cs = _charset()
    try:
        return s.encode(cs, "replace").decode(cs, "replace")[:limit]
    except LookupError:
        return s.encode("gbk", "replace").decode("gbk", "replace")[:limit]


async def _q(sql: str, args: tuple = (), fetch: str = "none", idem: bool = False):
    """执行一条 SQL(dict 游标),经多入口路由器下发。fetch: none|one|all。

    4.5.0 相对改造前的三处收紧(全部为**安全性**修正,详见 userdb_pool 模块头注):
      · **加了查询超时**。aiomysql 0.2.0 只有 connect_timeout、没有 read_timeout
        (逐字核对驱动源码)—— 入口带宽打满、TCP 还在但数据不走时,旧代码会
        无限期挂住,连「这个 IP 不可用」都探测不出来。
      · **换连重试变成换入口重试**,且只丢掉出问题的那个入口的池(旧代码是整池
        close+wait_closed,而 wait_closed 要等所有在用连接归还 —— 挂死的那条
        永远不归还,重建路径会被堵死)。
      · **重试不再无差别**:语句送出之前失败 → 任何语句都可换入口重发;送出之后
        失败 → 只有只读语句(或 idem=True 显式标注的幂等写)才重发。旧代码对
        INSERT 也盲目重发一次,在「服务端已执行、回包途中断线」的窗口会写两行。

    idem=True 仅用于**证明幂等**的写(如 `SET last_seen_at=NOW() WHERE id=?`)。
    抛出的异常由调用方决定语义(登录 503 / 校验降级),与改造前一致。
    """
    r = await _ensure_router()
    if r is None:
        raise ConnectionError(UA.init_error or "userdb pool unavailable")
    return await r.run(sql, args, fetch, idem=idem)


async def _q_maint(sql: str, args: tuple = (), fetch: str = "none",
                   timeout_s: Optional[float] = None):
    """后台维护语句(保留期清扫 / 容量体检)专用通道(5.4.0)。

    经 Router.run_maint 下发:不重试、超时**不熔断入口、不拆连接池** —— 清扫语句超时
    只说明「这一批太重」,不说明入口坏了(真库实测与取舍见该方法头注)。
    业务路径(登录 / 注册 / 会话 / VIP)一律走 _q,不要用这个。
    """
    r = await _ensure_router()
    if r is None:
        raise ConnectionError(UA.init_error or "userdb pool unavailable")
    from . import lifecycle
    return await r.run_maint(
        sql, args, fetch,
        timeout_s=lifecycle.STMT_TIMEOUT_S if timeout_s is None else timeout_s)


_STAT_NAME = re.compile(r"^guantai_[a-z0-9_]{1,48}$")
_STAT_LOG_TABLES = ("guantai_login_log", "guantai_reg_log")   # 自增流水:有 id 与 created_at
_STAT_EXACT_MAX_BYTES = 8 << 20                               # ≤8MB 的表直接 COUNT(*)


async def storage_stats() -> Dict[str, Dict[str, Any]]:
    """用户库里 guantai_* 各表的行数 / 字节(只读体检;lifecycle.snapshot 消费)。

    取数口径(每一项都按「不给共享公网库添负担」取舍):
      · 字节数:information_schema.tables 的 data_length + index_length;
      · 两张流水表的行数:`(MAX(id) - MIN(id)) ÷ 自增步长 + 1` —— 主键两端各一次点查
        (O(1)),对只增流水近乎精确且恒新鲜;最旧一行时刻 MIN(created_at) 走 idx_time;
      · 小表(≤8MB):直接 COUNT(*)(毫秒级,精确);
      · 其余:table_rows 估计值(InnoDB 抽样统计,界面标「约」)。
    MySQL 8.0 会把 information_schema 的统计缓存 24 小时,故带 SET_VAR 提示取现值;
    5.7 不认识该提示,只回一条告警、照常执行(这里静音掉)。
    """
    import warnings as _w
    with _w.catch_warnings():
        _w.simplefilter("ignore")
        rows = await _q_maint(
            "SELECT /*+ SET_VAR(information_schema_stats_expiry=0) */ table_name AS t, "
            "table_rows AS n, data_length AS dl, index_length AS il "
            "FROM information_schema.tables WHERE table_schema = DATABASE() "
            "AND table_name LIKE 'guantai\\_%%'", fetch="all") or []
    out: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        name = str(r.get("t") or "")
        if not _STAT_NAME.match(name):
            continue
        size = int(r.get("dl") or 0) + int(r.get("il") or 0)
        d: Dict[str, Any] = {"rows": int(r.get("n") or 0), "bytes": size,
                             "exact": False, "oldest": None}
        with contextlib.suppress(Exception):      # 明细取不到就退回估计值,不让整张体检表失败
            if name in _STAT_LOG_TABLES:
                x = await _q_maint(f"SELECT MIN(id) AS lo, MAX(id) AS hi, "
                                   f"MIN(created_at) AS oldest, "
                                   f"@@auto_increment_increment AS inc FROM {name}",
                                   fetch="one") or {}
                if x.get("hi") is None:
                    d["rows"], d["exact"] = 0, True
                else:                    # id 跨度 ÷ 自增步长(步长见 _jn_cap 注)
                    d["rows"] = (int(x["hi"]) - int(x["lo"])) // max(1, int(x.get("inc") or 1)) + 1
                    d["oldest"] = _dt_iso(x.get("oldest"))
            elif size <= _STAT_EXACT_MAX_BYTES:
                x = await _q_maint(f"SELECT COUNT(*) AS n FROM {name}", fetch="one") or {}
                d["rows"], d["exact"] = int(x.get("n") or 0), True
        out[name] = d
    return out


# ── 口令校验(形态自适应,全部常数时间比较) ───────────────────────────────────
def verify_password(supplied: str, stored: str) -> bool:
    """存量 pass_word 形态未知(且不许改表迁移):同时校验明文与常见 hex 摘要。
    · 32 hex → 兼容 MD5;40 hex → SHA1;64 hex → SHA256;
    · **明文逐字节**始终参与(覆盖「口令本身恰好长得像 hex」的存量),
      多一次 compare_digest,常数时间性质不变。"""
    s = str(supplied or "")
    st = str(stored or "").strip()
    if not s or not st:
        return False
    ok = hmac.compare_digest(s.encode("utf-8", "ignore"), st.encode("utf-8", "ignore"))
    low = st.lower().encode()
    raw = s.encode("utf-8", "ignore")
    if _HEX32.match(st):
        ok |= hmac.compare_digest(hashlib.md5(raw).hexdigest().encode(), low)
    elif _HEX40.match(st):
        ok |= hmac.compare_digest(hashlib.sha1(raw).hexdigest().encode(), low)
    elif _HEX64.match(st):
        ok |= hmac.compare_digest(hashlib.sha256(raw).hexdigest().encode(), low)
    return bool(ok)


def parse_first_login_room(raw: str) -> Optional[Tuple[str, str]]:
    """解析首登预置房配置「真实号[:展示短号]」→ (room_id, alias);空/畸形 → None。
    两段都须为 2–12 位纯数字(与 /api/monitor/add 的房号形态约束同口径);
    省略短号时展示别名就用真实号。纯函数,零依赖,tests/test_userauth.py 恒跑覆盖。"""
    s = str(raw or "").strip()
    if not s:
        return None
    rid, _, alias = s.partition(":")
    rid, alias = rid.strip(), (alias.strip() or rid.strip())
    for part in (rid, alias):
        if not (part.isdigit() and 2 <= len(part) <= 12):
            return None
    return rid, alias


# 登录成功回调:web 层在 lifespan 里注册(首登预置房种植)。本模块只面向 MySQL
# 用户库,名录在本地 PG(db.py)—— 经回调解耦依赖方向;回调异常一律吞掉,
# **绝不影响登录本身**(预置失败的兜底是用户手动添加,而不是把人挡在门外)。
on_login_ok: Optional[Callable[[int], Awaitable[None]]] = None


def _is_banned(is_off: Any) -> bool:
    banned = {v.strip() for v in str(UA.cfg.banned_values or "1").split(",") if v.strip()}
    return str(is_off or "").strip() in banned


# ══════════════════════════════════════════════════════════════════════════════
# 登录防爆破(5.2.0)—— 先占后验 · 分级加码 · 设备信任 · 全局攻击态
# ------------------------------------------------------------------------------
# 旧实现(3.8.0「失败计数 + 锁定」)经实证存在的缺口(复现脚本与
# tests/test_login_guard.py 钉死,数字均为实测):
#   ① 先查后加竞态:只读计数判锁、验密失败后才 +1 —— 60 个并发错口令**全部**
#      进入验密(上限 10);
#   ② 锁人:同名锁对所有来源生效,任何人每 10 分钟发 10 次错口令就能把真主人
#      挡在门外(正确口令也 429);
#   ③ 锁定期每次请求照写一行审计且零延迟:100 次被拒 = 100 行写入共享公网库;
#   ④ IP 维度不按 /64 分桶:同一 /64 内 40 个 IPv6 地址各试一次,30 的上限形同虚设;
#   ⑤ 无单次尝试成本、无全局视角:30 个 IP × 30 个用户名各试 1 次,零触限;
#   ⑥ INCR 与 EXPIRE 分两步:EXPIRE 抖一次 → 键永久无 TTL(= 永久锁);
#   ⑦ 进程内兜底把 IP 键的锁定阈值错用成用户名阈值。
# 现行机制:
#   · 先占后验:每次尝试**先**原子 +1(Lua 一步完成 INCR + 补 TTL),超上限直接
#     429、不进验密;口令正确 / 未验密(被拒、要求加码、库不可用)即退还 —— 净效果仍是
#     「只数失败」,但并发无从穿透;
#   · 分级加码:同名或同 IP 段失败达软阈值(默认硬上限的 1/3 且至少 3)→ 要求本站
#     PoW(复用注册 R2 的执行证明 ⊕ SHA-256 前导零,自托管、大陆可用);开了登录
#     人机验证(risk 档)再叠验证码;硬上限仍是最终闸;
#   · 设备信任:本浏览器曾成功登录过**该账号** → HttpOnly 签名 Cookie(jf_dev,
#     只发往 /api/auth/)→ 不受同名锁 / IP 锁牵连,改按「每设备」独立计数 ——
#     攻击者锁不住真主人,爆破额度却一分不多(OWASP 设备 Cookie 方案);
#   · 全局攻击态:近 5 分钟全站失败数越线 → 所有未受信设备一律加码(撒网 / 撞库
#     对每个用户名只试一两次,单键阈值永远摸不到,只能靠全局视角);
#   · 审计限幅:被拒(429)与要求加码(428)每 IP 段每窗口至多一行。
# 兼容性:加码关闭(STA_USER_LOGIN_STEPUP_USER/IP=0、攻击态=0)时,串行路径上的
# 401/429 序列与旧实现逐次相同;计数键名 guantai:lf:* 不变(滚动升级不丢锁)。
# ══════════════════════════════════════════════════════════════════════════════
K_LOGIN_CHAL = "guantai:loginchal:{cid}"       # 登录加码挑战(单次性;键空间与注册挑战独立)
_LG_POW_CAP = 22                               # 登录 PoW 硬顶(真人最坏数秒;注册硬顶 25)
_LG_CHAL_TTL_S = 300
_LG_DEV_COOKIE = "jf_dev"
_LG_DEV_RE = re.compile(r"^d1\.([0-9a-f]{16})\.(\d{9,11})\.([0-9a-f]{16})\.([0-9a-f]{32})$")
_LG_ATTACK_CACHE_S = 5.0
_CAP_PROVIDERS = ("tencent", "geetest", "turnstile")



def _warn_once(tag: str, msg: str, every_s: float = 600.0) -> None:
    now = time.monotonic()
    if now - UA.lg_warned.get(tag, -1e9) >= every_s:
        UA.lg_warned[tag] = now
        print(msg)


# ── 窗口计数原语(实现见 app/wincount.py;这里只绑定本模块的 Redis 句柄) ──────
async def _win_incr(key: str, win_s: int, mem: Dict[str, Tuple[int, float]]) -> Tuple[int, int]:
    """窗口计数原子 +1 → (当前计数, 剩余窗口秒)。Redis 抖动退化进程内 —— 绝不放开。"""
    return await wincount.incr(UA.redis, key, win_s, mem)


async def _win_decr(key: str, mem: Dict[str, Tuple[int, float]]) -> None:
    await wincount.decr(UA.redis, key, mem)


async def _win_peek(key: str, mem: Dict[str, Tuple[int, float]]) -> int:
    return await wincount.peek(UA.redis, key, mem)


async def _win_ttl(key: str, mem: Dict[str, Tuple[int, float]], default: int) -> int:
    return await wincount.ttl(UA.redis, key, mem, default)


async def _win_lock(key: str, lock_s: int, mem: Dict[str, Tuple[int, float]]) -> None:
    await wincount.lock(UA.redis, key, lock_s, mem)


async def _lg_audit_once(key: str, cls: str, win_s: int = 600) -> bool:
    """登录侧审计限幅:同键同类每窗口至多一行。**独立键空间** guantai:lg:al:* 与
    独立兜底桶 mem_fail —— 不借注册的 _audit_once(那会把登录的去重键塞进
    guantai:reg:* 与 mem_reg,被管理台「清空全部注册限流」误清,也污染注册计数;
    tests/test_register.py 的作用域用例实测抓到过这一点)。"""
    n, _ = await _win_incr(f"guantai:lg:al:{cls}:{key}", win_s, UA.mem_fail)
    return n == 1


# ── 键与阈值 ────────────────────────────────────────────────────────────────
def _name_hash(user_name: str) -> str:
    # 口径实证:Python gbk 编解码在 BMP 内是单射(0 组多对一),且登录侧先 strip、
    # 列 gbk_bin 逐字节比较 —— 同一账号不存在「另一种写法」,按名分桶无需再按 uid 补桶。
    return hashlib.md5(str(user_name or "").encode("utf-8", "ignore")).hexdigest()[:16]


def _thr_keys(user_name: str, ip: str) -> Tuple[str, str]:
    """(同名键, 同 IP 段键)。IP 段与注册 R1 同口径:IPv4 原址、IPv6 按 /64。"""
    return f"guantai:lf:u:{_name_hash(user_name)}", f"guantai:lf:ip:{_ip_bucket(ip)}"


def _lg_soft(hard: int, raw: Any) -> int:
    """软阈值(要求加码):-1=自动(硬上限的 1/3,至少 3,不超过硬上限);0=关;N=显式。
    「至少 3」:手滑两次是常态,不该第三次就要算题;硬上限 ≤3 的部署因此天然
    不加码(行为与旧版一致)。"""
    try:
        v = int(raw)
    except (TypeError, ValueError):
        v = -1
    hard = max(1, int(hard))
    if v == 0:
        return 0
    if v < 0:
        return min(hard, max(3, -(-hard // 3)))
    return min(v, hard)



def _lg_soft_eff(hard: int, raw: Any) -> int:
    """展示用的「实际生效」软阈值:≥ 硬上限的软阈值永远轮不到(先撞硬锁),如实显示为关(0)。
    复查补漏:旧横幅 / 风控概览在 硬上限=3 时显示「加码 同名≥3」,实际从不加码。"""
    s = _lg_soft(hard, raw)
    return s if 0 < s < max(1, int(hard)) else 0


def _hard_limits() -> Tuple[int, int, int, int]:
    c = UA.cfg
    return (max(1, int(c.login_fail_user)), max(1, int(c.login_fail_ip)),
            max(10, int(c.login_fail_window_s)), max(1, int(c.login_lock_s)))


# ── 设备信任 Cookie(OWASP「设备 Cookie」:锁不住真主人,也不多给攻击者额度) ────
async def _dev_key() -> bytes:
    """HMAC 密钥来源(依次):STA_USER_DEVICE_KEY(≥32 字符)→ 账号库卷上的
    `.login_device.key`(0600,首次随机生成;compose 的 web 已挂 /data,重启不丢)
    → Redis(SET NX,多进程共享;compose 的 Redis 不落盘,重启即换钥)→ 进程内随机。
    换钥的唯一后果是「已受信设备回到未受信」—— 不影响登录,只在恰逢被攻击时少一层豁免。"""
    if UA.dev_key and (UA.dev_key_src != "process" or time.monotonic() - UA.dev_key_at < 60):
        return UA.dev_key
    env = str(os.environ.get("STA_USER_DEVICE_KEY") or "").strip()
    if len(env) >= 32:
        UA.dev_key, UA.dev_key_src = hashlib.sha256(("jf-dev|" + env).encode()).digest(), "env"
        return UA.dev_key
    acct = str(os.environ.get("STA_ACCOUNTS_PATH") or "").strip()
    if acct:
        path = os.path.join(os.path.dirname(acct) or ".", ".login_device.key")
        try:
            try:
                fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(fd, "w") as f:
                    f.write(secrets.token_hex(32))
            except FileExistsError:
                pass
            # 复查补漏:O_EXCL 建文件与写入内容之间有一个极短窗口 —— 同时启动的另一个进程恰在此刻
            # 读到空文件,就会落到 Redis / 进程内密钥并**永久缓存**,两个进程签发的设备 Cookie 从此
            # 互不认账。读到不完整内容时稍候重读(≤1 秒),仍不合法才判损坏并告警。
            raw = ""
            for _ in range(20):
                with open(path, encoding="ascii", errors="replace") as f:
                    raw = f.read().strip()
                if _HEX64.match(raw):
                    UA.dev_key, UA.dev_key_src = bytes.fromhex(raw), "file"
                    return UA.dev_key
                await asyncio.sleep(0.05)
            _warn_once("devkeyfile", f"[登录] ⚠️ 设备信任密钥文件 {path} 内容不合法(应为 64 位十六进制)"
                                     "—— 改用 Redis / 进程内密钥;删掉该文件后重启即可重新生成")
        except OSError:
            pass
    if UA.redis is not None:
        try:
            await UA.redis.set("guantai:lg:devkey", secrets.token_hex(32), nx=True)
            raw = _rs(await UA.redis.get("guantai:lg:devkey"))
            if _HEX64.match(raw):
                UA.dev_key, UA.dev_key_src = bytes.fromhex(raw), "redis"
                return UA.dev_key
        except Exception:                   # noqa: BLE001
            pass
    UA.dev_key, UA.dev_key_src, UA.dev_key_at = secrets.token_bytes(32), "process", time.monotonic()
    return UA.dev_key


def _dev_ttl_s() -> int:
    try:
        return max(0, int(getattr(UA.cfg, "login_device_ttl_d", 90) or 0)) * 86400
    except (TypeError, ValueError):
        return 0


def _dev_sig(key: bytes, uh: str, iat: int, did: str) -> str:
    return hmac.new(key, f"d1|{uh}|{iat}|{did}".encode(), hashlib.sha256).hexdigest()[:32]


async def device_cookie_value(user_name: str) -> str:
    key = await _dev_key()
    uh, iat, did = _name_hash(str(user_name or "").strip()), int(time.time()), secrets.token_hex(8)
    return f"d1.{uh}.{iat}.{did}.{_dev_sig(key, uh, iat, did)}"


async def _device_for(raw: Any, user_name: str) -> str:
    """该 Cookie 对**本用户名**有效 → 设备 id;否则 ""(格式错/签名错/过期/别的账号)。"""
    ttl = _dev_ttl_s()
    m = _LG_DEV_RE.match(str(raw or "").strip())
    if not ttl or not m:
        return ""
    uh, iat, did, sig = m.group(1), int(m.group(2)), m.group(3), m.group(4)
    now = time.time()
    if uh != _name_hash(user_name) or iat > now + 300 or now - iat > ttl:
        return ""
    want = _dev_sig(await _dev_key(), uh, iat, did)
    return did if hmac.compare_digest(want, sig) else ""


async def set_device_cookie(resp: Response, request: Request, user_name: str) -> None:
    """成功认证后下发/轮换设备信任 Cookie。HttpOnly + 仅发往 /api/auth/(业务请求
    根本带不上它);login_device_ttl_d=0 时不下发(设备信任整体关闭)。"""
    ttl = _dev_ttl_s()
    name = str(user_name or "").strip()
    if not ttl or not name:
        return
    try:
        val = await device_cookie_value(name)
    except Exception:                       # noqa: BLE001 —— 设备信任是锦上添花,绝不影响登录
        return
    resp.set_cookie(_LG_DEV_COOKIE, val, max_age=ttl, httponly=True, samesite="lax",
                    secure=_cookie_secure(request), path="/api/auth/")


# ── 全局攻击态(撒网 / 撞库的唯一可见面) ───────────────────────────────────────
async def _lg_global_fail() -> None:
    await _win_incr(f"guantai:lg:gf:{int(time.time() // 60)}", 600, UA.mem_fail)


async def _lg_attack() -> bool:
    lim = int(getattr(UA.cfg, "login_attack_5m", 0) or 0)
    if lim <= 0:
        return False
    now = time.monotonic()
    c = UA.lg_attack
    if c and now - c[0] < _LG_ATTACK_CACHE_S:
        return bool(c[1])
    m = int(time.time() // 60)
    keys = [f"guantai:lg:gf:{m - i}" for i in range(5)]
    tot = None
    if UA.redis is not None:
        with contextlib.suppress(Exception):
            tot = sum(int(v) for v in await UA.redis.mget(keys) if v is not None)
    if tot is None:
        tot = 0
        for k in keys:
            tot += await _win_peek(k, UA.mem_fail)
    hot = tot >= lim
    if hot and not (c and c[1]):
        print(f"[登录] ⚠️ 全局攻击态:近 5 分钟登录失败 {tot} 次 ≥ {lim} —— 未受信设备一律加码"
              f"(PoW{' + 人机验证' if (_cap_conf('login')['provider'] != 'off' and _cap_mode() != 'off') else ''})")
        if await _lg_audit_once("global", "latk", 600):
            await _log_login(0, "", "", "", 0, "attack_mode")
    UA.lg_attack = (now, hot, tot)
    return hot


# ── 人机验证供应商(登录侧熔断:供应商不可达时降级为 PoW,可用性优先) ──────────
def _cap_conf(scope: str = "reg") -> Dict[str, str]:
    """人机验证供应商与凭据 → {provider, id, key, secret_id, secret_key}。

    5.2.0 定稿:**注册与登录共用一套**(STA_USER_REG_CAPTCHA / _ID / _KEY / _SECRET_*,名字
    沿用以兼容已有部署)。一个站点只配一个验证码账号;预览版曾给登录另设一套供应商与凭据,
    管理台里两组同名项并列,极易配串(运维反馈)—— 现 scope 只用于日志与 action 口径,
    登录是否/何时要过由 _cap_mode()(STA_USER_LOGIN_CAPTCHA)决定。"""
    c = UA.cfg
    if c is None and scope == "admin":
        # 5.3.0:管理台登录的人机验证不依赖登录系统是否启用 / 是否已初始化 —— 直接读全局配置
        # (web 生命周期里 UA.cfg 与它本就是同一个对象;此分支只在早期启动 / 独立挂载时走到)
        from .settings import settings as _settings
        c = _settings.userauth
    if c is None:
        return {"provider": "off", "id": "", "key": "", "secret_id": "", "secret_key": ""}
    prov = str(getattr(c, "reg_captcha", "off") or "off").strip().lower()
    if prov not in _CAP_PROVIDERS:
        prov = "off"
    # 注册用不用由「人机验证 · 注册时也要」决定(默认要);关掉时供应商仍可供登录使用
    if scope == "reg" and not bool(getattr(c, "reg_captcha_required", True)):
        prov = "off"

    def pick(n: str) -> str:
        return str(getattr(c, f"reg_captcha_{n}", "") or "").strip()
    return {"provider": prov, "id": pick("id"), "key": pick("key"),
            "secret_id": pick("secret_id"), "secret_key": pick("secret_key")}


def _cap_mode() -> str:
    """登录何时要过人机验证:off / risk / always(STA_USER_LOGIN_CAPTCHA)。"""
    v = str(getattr(UA.cfg, "login_captcha", "off") or "off").strip().lower()
    return v if v in ("risk", "always") else "off"


def _cap_down() -> bool:
    return time.monotonic() < UA.cap_down_until


def _cap_mark_down(seconds: float = 60.0) -> None:
    UA.cap_down_until = time.monotonic() + seconds
    _warn_once("capdown", "[登录] ⚠️ 登录人机验证校验不可用(供应商不可达或凭据有误)—— "
                          f"{int(seconds)}s 内降级为本站 PoW,期满自动重试")


def login_session_info() -> Dict[str, Any]:
    """/api/auth/session 的 login 字段:前端据此知道登录人机验证开没开、何时挂。"""
    if UA.cfg is None:
        return {}
    conf, when = _cap_conf("login"), _cap_mode()
    if conf["provider"] == "off" or when == "off" or not conf["id"]:
        return {}
    return {"captcha": {"provider": conf["provider"], "appId": conf["id"], "action": "login"},
            "captchaMode": when}


# ── 闸门 ────────────────────────────────────────────────────────────────────
class _LgGate:
    __slots__ = ("ku", "ki", "kd", "did", "n_u", "n_ip", "n_d", "trusted", "reject", "done")

    def __init__(self):
        self.ku = self.ki = self.kd = self.did = ""
        self.n_u = self.n_ip = self.n_d = 0
        self.trusted = False
        self.reject = None
        self.done = False


async def _lg_refund(g: "_LgGate") -> None:
    """本次尝试未验密或口令正确 → 退还先占的额度(「只数失败」)。幂等。"""
    if g.done:
        return
    g.done = True
    if g.trusted:
        await _win_decr(g.kd, UA.mem_fail)
    else:
        if g.ku:
            await _win_decr(g.ku, UA.mem_fail)
        if g.ki:
            await _win_decr(g.ki, UA.mem_fail)


async def _lg_failed(g: "_LgGate") -> None:
    """口令错:额度不退;恰达上限即把剩余寿命置为锁定期(锁定时长从此刻起算);计入全局攻击态输入。"""
    g.done = True
    hu, hip, _win, lock = _hard_limits()
    if g.trusted:
        if g.n_d >= hu:
            await _win_lock(g.kd, lock, UA.mem_fail)
    else:
        if g.n_u >= hu:
            await _win_lock(g.ku, lock, UA.mem_fail)
        if g.n_ip >= hip:
            await _win_lock(g.ki, lock, UA.mem_fail)
    await _lg_global_fail()


def _lg_bits(g: "_LgGate", attack: bool) -> int:
    c = UA.cfg
    hu, hip, _w, _l = _hard_limits()
    try:
        base = int(getattr(c, "login_pow_bits", 16) or 16)
    except (TypeError, ValueError):
        base = 16
    bits = max(_REG_BITS_MIN, min(_LG_POW_CAP, base))
    hot_u, hot_ip = -(-2 * hu // 3), -(-2 * hip // 3)
    if (g.n_u and g.n_u - 1 >= hot_u) or (g.n_ip and g.n_ip - 1 >= hot_ip) \
            or (g.trusted and g.n_d - 1 >= hot_u):
        bits += 2
    if attack:
        bits += 2
    return min(bits, _LG_POW_CAP)


async def _lg_need(g: "_LgGate", user_name: str, ip: str, ua: str, *, need_pow: bool,
                   need_cap: bool, why: str, attack: bool) -> "_LgGate":
    """要求加码:退还本次额度(没验密就不算一次失败)→ 签发挑战 → 428。"""
    await _lg_refund(g)
    bucket = _ip_bucket(ip)
    out: Dict[str, Any] = {"ok": False, "error": "challenge_required", "reason": why,
                           "message": "需要完成安全校验,请刷新页面后重试"}
    if need_pow:
        n, ttl = await _win_incr(f"guantai:lg:chal:ip:{bucket}", 600, UA.mem_fail)
        if n > max(1, int(getattr(UA.cfg, "login_chal_ip_10m", 30) or 30)):
            if await _lg_audit_once(bucket, "lchal", 600):
                await _log_login(0, user_name, ip, ua, 0, "throttled")
            g.reject = (429, {"ok": False, "error": "throttled", "retryAfter": ttl,
                              "message": f"尝试过于频繁,请 {max(1, ttl // 60)} 分钟后再试"})
            return g
        cid, salt, bits = secrets.token_hex(16), secrets.token_hex(16), _lg_bits(g, attack)
        doc = {"s": salt, "b": bits, "t": time.time(), "ip": bucket, "k": "login"}
        try:
            await UA.redis.set(K_LOGIN_CHAL.format(cid=cid), json.dumps(doc), ex=_LG_CHAL_TTL_S)
        except Exception:                   # noqa: BLE001 —— 可疑请求在协调层抖动时稍候,绝不裸奔
            g.reject = (503, {"ok": False, "error": "login_unavailable",
                              "message": "安全校验暂不可用,请稍后重试"})
            return g
        out["challenge"] = {"challengeId": cid, "salt": salt, "bits": bits, "ttl": _LG_CHAL_TTL_S}
    if need_cap:
        conf = _cap_conf("login")
        out["captcha"] = {"provider": conf["provider"], "appId": conf["id"], "action": "login"}
    if await _lg_audit_once(bucket, "lstep", 600):
        await _log_login(0, user_name, ip, ua, 0, f"challenge:{why}"[:30])
    g.reject = (428, out)
    return g


async def _lg_admit(user_name: str, ip: str, ua: str, *, channel: str, proof: Dict[str, Any],
                    device: Any, link_keyed: bool) -> "_LgGate":
    """先占 → 硬上限 → 是否加码 → 校验加码证明。g.reject 非空 = 已有结论(不验密)。"""
    c = UA.cfg
    g = _LgGate()
    g.ku, g.ki = _thr_keys(user_name, ip)
    hu, hip, win, _lock = _hard_limits()
    mem = UA.mem_fail
    if channel == "web" and device:
        did = await _device_for(device, user_name)
        if did:
            kd = f"guantai:lg:dev:{did}"
            n_d, _t = await _win_incr(kd, win, mem)
            if n_d <= hu:
                g.trusted, g.did, g.kd, g.n_d = True, did, kd, n_d
            else:
                await _win_decr(kd, mem)    # 设备自身额度已尽 → 按未受信处理
    attack = False
    if g.trusted:
        su = _lg_soft(hu, getattr(c, "login_stepup_user", -1))
        stepup = bool(su) and g.n_d - 1 >= su
    else:
        g.n_u, ttl_u = await _win_incr(g.ku, win, mem)
        g.n_ip, ttl_ip = await _win_incr(g.ki, win, mem)
        over = [t for n, lim, t in ((g.n_u, hu, ttl_u), (g.n_ip, hip, ttl_ip)) if n > lim]
        if over:
            # 被拒的这一次没有验密:两份额度都退还(「只数失败」口径)。复查补漏:旧写法两份都
            # 不退 —— 共享出口(NAT)被 IP 锁时,真人反复点登录会把自己的同名计数顶满,一次
            # 口令都没验就把账号锁了(tests/test_login_guard.py 钉死)。
            await _lg_refund(g)
            left = max(over)
            # 审计限幅按「锁的是谁」去重:同名锁每名每窗口一行(多 IP 轮番撞同一个号
            # 也只记一行),同 IP 锁每 IP 段每窗口一行 —— 写入量与攻击请求量脱钩。
            ak = f"u:{_name_hash(user_name)}" if g.n_u > hu else f"ip:{_ip_bucket(ip)}"
            if await _lg_audit_once(ak, "lthr", win):
                await _log_login(0, user_name, ip, ua, 0, "throttled")
            g.reject = (429, {"ok": False, "error": "throttled", "retryAfter": left,
                              "message": f"尝试过于频繁,请 {max(1, left // 60)} 分钟后再试"})
            return g
        su = _lg_soft(hu, getattr(c, "login_stepup_user", -1))
        sip = _lg_soft(hip, getattr(c, "login_stepup_ip", -1))
        attack = await _lg_attack()
        stepup = bool((su and g.n_u - 1 >= su) or (sip and g.n_ip - 1 >= sip) or attack)
    conf, when = _cap_conf("login"), _cap_mode()
    cap_on = conf["provider"] != "off" and when != "off"
    cap_ready = cap_on and bool(conf["id"] and conf["key"])
    wants_cap = cap_on and (when == "always" or stepup)
    need_cap = wants_cap and cap_ready
    # 复查补漏:开了人机验证却缺站点密钥/私钥时,旧写法照样要求验证码 —— 前端拿空
    # sitekey 渲染必失败,用户卡死在「人机验证加载失败」。现与「供应商不可达」同一取向:
    # 按本站 PoW 加码,登录不中断(启动横幅已醒目告警凭据不全)。
    need_pow = stepup or (wants_cap and not cap_ready)
    if wants_cap and not cap_ready:
        _warn_once("capconf", "[登录] ⚠️ 登录人机验证已开但凭据不全 —— 本次按本站 PoW 加码")
    if need_cap and _cap_down():            # 供应商熔断期:降级为本站 PoW
        need_cap, need_pow = False, True
    if need_pow and UA.redis is None:       # 无协调层:挑战无处存放 → 只靠硬上限(仅加码层 fail-open)
        _warn_once("nopow", "[登录] Redis 不可用:登录加码 PoW 暂停,硬上限照常生效(进程内计数)")
        need_pow = False
    if channel != "web":
        if (need_pow or need_cap) and not link_keyed:
            await _lg_refund(g)
            g.reject = (429, {"ok": False, "error": "throttled", "retryAfter": 60,
                              "message": "需要人机验证,账密签发通道无法完成;请为该通道配置 "
                                         "STA_USER_SSO_LINK_KEY,或稍后再试"})
        return g
    if not (need_pow or need_cap):
        return g
    why = "risk" if stepup else "always"
    pow_ok = False
    if need_pow:
        cid = str(proof.get("challengeId") or "")
        chal = None
        if cid:
            try:
                chal = await _chal_take(cid, K_LOGIN_CHAL)
            except Exception:               # noqa: BLE001
                chal = None
        if not chal or chal.get("k") != "login" or str(chal.get("ip") or "") != _ip_bucket(ip):
            return await _lg_need(g, user_name, ip, ua, need_pow=True, need_cap=need_cap,
                                  why=("expired" if cid else why), attack=attack)
        if not reg_pow_check(str(chal.get("s") or ""), str(proof.get("nonce") or ""),
                             int(chal.get("b") or 0)):
            return await _lg_need(g, user_name, ip, ua, need_pow=True, need_cap=need_cap,
                                  why="pow_failed", attack=attack)
        pow_ok = True
    if need_cap:
        ok, err, _msg = await _captcha_check(proof.get("captchaToken"), ip, scope="login")
        if not ok:
            if err == "captcha_unavailable":
                _cap_mark_down()
                if not pow_ok and UA.redis is not None:
                    return await _lg_need(g, user_name, ip, ua, need_pow=True, need_cap=False,
                                          why="captcha_degraded", attack=attack)
                # 已带有效 PoW(或无从加码):降级放行进入验密,硬上限仍在
            else:
                return await _lg_need(g, user_name, ip, ua, need_pow=need_pow, need_cap=True,
                                      why="captcha_failed", attack=attack)
    return g


async def _fail_clear(user_name: str, did: str = "") -> None:
    """真正成功后清计数。从**受信设备**成功时只清该设备的计数 —— 不替攻击者把同名
    计数归零(否则真主人每登录一次,攻击者就白得一份新额度)。"""
    if did:
        key = f"guantai:lg:dev:{did}"
    else:
        key, _ = _thr_keys(user_name, "")
    if UA.redis is not None:
        with contextlib.suppress(Exception):
            await UA.redis.delete(key)
    UA.mem_fail.pop(key, None)


def _login_guard_report() -> None:
    """启动横幅:把防爆破的实际生效口径一次说清(运维排障第一眼)。"""
    c = UA.cfg
    hu, hip, win, lock = _hard_limits()
    su = _lg_soft_eff(hu, getattr(c, "login_stepup_user", -1))
    sip = _lg_soft_eff(hip, getattr(c, "login_stepup_ip", -1))
    conf, when = _cap_conf("login"), _cap_mode()
    cap_on = conf["provider"] != "off" and when != "off"
    cap = f"{conf['provider']}({'每次登录' if when == 'always' else '仅可疑时'})" if cap_on else "关"
    atk = int(getattr(c, "login_attack_5m", 0) or 0)
    dev = _dev_ttl_s() // 86400
    print(f"[登录] 防爆破:先占后验 · 硬上限 同名 {hu} / 同IP {hip}(窗口 {win}s,锁 {lock}s)"
          f" · 加码 同名{'≥%d' % su if su else '(关)'} / 同IP{'≥%d' % sip if sip else '(关)'}"
          f" · PoW {getattr(c, 'login_pow_bits', 16)} 位"
          f" · 设备信任 {str(dev) + ' 天' if dev else '关'}"
          f" · 全局攻击态 {('≥' + str(atk) + '/5min') if atk > 0 else '关'} · 人机验证 {cap}")
    print(f"[登录] 来源 IP:{clientip.describe(bool(getattr(c, 'trust_forwarded_for', True)))}")
    raw_prov = str(getattr(c, "reg_captcha", "off") or "off").strip().lower()
    if raw_prov not in ("", "off") + _CAP_PROVIDERS:
        print(f"[登录] ⚠️ 人机验证供应商 STA_USER_REG_CAPTCHA={raw_prov!r} 无法识别"
              "(可选 off / tencent / geetest / turnstile)—— 按关闭处理")
    if when != "off" and conf["provider"] == "off":
        print(f"[登录] ⚠️ 已设 STA_USER_LOGIN_CAPTCHA={when},但还没选人机验证供应商"
              "(STA_USER_REG_CAPTCHA,注册与登录共用)—— 登录人机验证不生效")
    if cap_on and not (conf["id"] and conf["key"]):
        print("[登录] ⚠️ 登录人机验证已开,但共用的站点密钥/私钥不全(STA_USER_REG_CAPTCHA_ID/KEY)"
              "—— 将自动按本站 PoW 加码,登录不中断")
    if getattr(c, "_login_captcha_legacy", False):
        print("[登录] ℹ️ 检测到 5.2.0 预览版写法(STA_USER_LOGIN_CAPTCHA=供应商名 / _MODE / _ID / _KEY)"
              "—— 已自动折算。建议改为:供应商与凭据写 STA_USER_REG_CAPTCHA*(注册与登录共用),"
              "登录时机写 STA_USER_LOGIN_CAPTCHA=risk|always")
    if cap_on and when == "always" and sso_link_enabled() \
            and not str(getattr(c, "sso_link_key", "") or "").strip():
        print("[登录] ⚠️ 登录人机验证=always 且账密签发通道未配密钥 —— 该通道将一律 429;"
              "请配置 STA_USER_SSO_LINK_KEY")
    if cap_on and conf["provider"] == "turnstile":
        print("[登录] ℹ️ Cloudflare 官方声明 Turnstile 不支持中国大陆:大陆访客可能加载不出验证框。"
              "大陆用户为主请改用 tencent/geetest,或至少保持 STA_USER_LOGIN_CAPTCHA=risk")


# ── 管理台「登录风控」数据面(5.2.0)───────────────────────────────────────────
# 运维诉求:注册侧早有「注册流水 + 聚类 + 熔断」可看,登录侧却只有一张 guantai_login_log
# 表 —— 谁在撞库、哪些账号正被盯、哪些号 / IP 段此刻被锁,全靠翻库。这里只读(计数键 +
# 审计表);唯一的写是「解锁」(删一个失败计数键,由管理台二次确认并落审计)。
# 「可疑」口径:ok=0 且不是「口令正确但账号停用 / 到期」与「攻击态标记行」。
_LG_SUSPECT_SQL = "ok=0 AND reason NOT IN ('banned','expired','attack_mode')"
_LG_RISK_CACHE_S = 10.0          # 多开几个管理台标签页也不至于反复打共享公网库
_LG_IP_PREFIX = "guantai:lf:ip:"


async def _lg_counts(keys: List[str]) -> List[Tuple[int, int]]:
    """批量读失败计数键 → [(计数, 剩余秒)]。Redis 不可用时读进程内兜底。"""
    if not keys:
        return []
    if UA.redis is not None:
        try:
            pipe = UA.redis.pipeline(transaction=False)
            for k in keys:
                pipe.get(k)
                pipe.ttl(k)
            res = await pipe.execute()
            return [(int(res[i]) if res[i] is not None else 0, max(0, int(res[i + 1] or 0)))
                    for i in range(0, len(res), 2)]
        except Exception:                   # noqa: BLE001 —— 退回进程内兜底的视角
            pass
    now = time.monotonic()
    out = []
    for k in keys:
        n, exp = UA.mem_fail.get(k, (0, 0.0))
        out.append((int(n), max(0, int(exp - now))) if exp > now else (0, 0))
    return out


async def _lg_ip_keys(limit: int = 5000) -> List[str]:
    if UA.redis is not None:
        keys: List[str] = []
        try:
            async for k in UA.redis.scan_iter(match=_LG_IP_PREFIX + "*", count=500):
                keys.append(_rs(k))
                if len(keys) >= limit:
                    break
            return keys
        except Exception:                   # noqa: BLE001
            pass
    return [k for k in list(UA.mem_fail) if k.startswith(_LG_IP_PREFIX)][:limit]


@heavy_reads
async def login_risk_overview(hours: int = 24, top: int = 20) -> Dict[str, Any]:
    """攻击态 + 近 N 小时的失败分布 / 可疑来源(按 IP 段)/ 被针对账号 + 当前被锁的账号与 IP 段。"""
    hours = max(1, min(int(hours or 24), 168))
    top = max(1, min(int(top or 20), 100))
    now = time.monotonic()
    ck = (hours, top)
    if UA.risk_cache and UA.risk_cache[0] == ck and now - UA.risk_cache[1] < _LG_RISK_CACHE_S:
        return UA.risk_cache[2]
    c = UA.cfg
    hu, hip, win, lock = _hard_limits()
    atk = int(getattr(c, "login_attack_5m", 0) or 0)
    m = int(time.time() // 60)
    fails5 = sum(n for n, _t in await _lg_counts([f"guantai:lg:gf:{m - i}" for i in range(5)]))
    when = _cap_mode()
    prov = _cap_conf("login")["provider"]
    out: Dict[str, Any] = {
        "hours": hours,
        "attack": {"on": bool(atk > 0 and fails5 >= atk), "fails5m": fails5, "threshold": atk},
        "limits": {"user": hu, "ip": hip, "windowS": win, "lockS": lock,
                   "stepupUser": _lg_soft_eff(hu, getattr(c, "login_stepup_user", -1)),
                   "stepupIp": _lg_soft_eff(hip, getattr(c, "login_stepup_ip", -1)),
                   "captcha": prov if (prov != "off" and when != "off") else "off",
                   "captchaMode": when},
        "byReason": {}, "topIps": [], "topUsers": [], "locked": {"users": [], "ips": []},
    }
    # ① 当前被锁的 IP 段:计数键里就是明文段,直接扫(Redis 实时,不依赖用户库)
    ipkeys = await _lg_ip_keys()
    out["locked"]["ips"] = sorted(
        ({"bucket": k[len(_LG_IP_PREFIX):], "fails": n, "leftS": t}
         for k, (n, t) in zip(ipkeys, await _lg_counts(ipkeys)) if n >= hip and t > 0),
        key=lambda x: -x["leftS"])[:200]
    if not await _ensure_schema():
        out["dbError"] = "userdb_unavailable"
        return out
    # ② 近 N 小时按原因分布(走 idx_time)
    rows = await _q("SELECT reason, COUNT(*) AS n FROM guantai_login_log "
                    "WHERE created_at >= NOW() - INTERVAL %s HOUR GROUP BY reason",
                    (hours,), fetch="all") or []
    out["byReason"] = {str(r.get("reason") or ""): int(r.get("n") or 0) for r in rows}
    # ③ 可疑来源:先按原始 IP 聚合,再按 IP 段合并(IPv6 /64 —— 与节流同一口径)
    rows = await _q("SELECT ip, COUNT(*) AS n, COUNT(DISTINCT user_name) AS users, MAX(created_at) AS last "
                    f"FROM guantai_login_log WHERE created_at >= NOW() - INTERVAL %s HOUR AND {_LG_SUSPECT_SQL} "
                    "GROUP BY ip ORDER BY n DESC LIMIT 500", (hours,), fetch="all") or []
    agg: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        ip = str(r.get("ip") or "")
        b = _ip_bucket(ip)
        a = agg.setdefault(b, {"bucket": b, "n": 0, "users": 0, "ips": 0, "sample": ip, "last": ""})
        a["n"] += int(r.get("n") or 0)
        a["users"] += int(r.get("users") or 0)
        a["ips"] += 1
        a["last"] = max(a["last"], _dt_iso(r.get("last")) or "")
    tops = sorted(agg.values(), key=lambda x: -x["n"])[:top]
    for x, (n, t) in zip(tops, await _lg_counts([_LG_IP_PREFIX + x["bucket"] for x in tops])):
        x["locked"] = bool(n >= hip and t > 0)
        x["leftS"] = t if x["locked"] else 0
        x["approx"] = x["ips"] > 1          # 合并了多个地址:「涉及账号」为各地址之和,可能重复计
    out["topIps"] = tops
    # ④ 被针对的账号
    rows = await _q("SELECT user_name, COUNT(*) AS n, COUNT(DISTINCT ip) AS ips, MAX(created_at) AS last "
                    f"FROM guantai_login_log WHERE created_at >= NOW() - INTERVAL %s HOUR AND {_LG_SUSPECT_SQL} "
                    "AND user_name <> '' GROUP BY user_name ORDER BY n DESC LIMIT %s",
                    (hours, top), fetch="all") or []
    users = [{"name": str(r.get("user_name") or ""), "n": int(r.get("n") or 0),
              "ips": int(r.get("ips") or 0), "last": _dt_iso(r.get("last")) or ""} for r in rows]
    # ⑤ 当前被锁的账号:计数键是用户名散列,从「窗口 + 锁定期」内口令错过的用户名反查
    span = max(win, lock) + 60
    rows = await _q("SELECT DISTINCT user_name FROM guantai_login_log WHERE created_at >= NOW() - "
                    "INTERVAL %s SECOND AND reason='bad_credentials' AND user_name <> '' LIMIT 2000",
                    (span,), fetch="all") or []
    cand = sorted({str(r.get("user_name") or "") for r in rows} | {u["name"] for u in users})
    st = dict(zip(cand, await _lg_counts([_thr_keys(nm, "")[0] for nm in cand])))
    out["locked"]["users"] = sorted(
        ({"name": nm, "fails": n, "leftS": t} for nm, (n, t) in st.items() if n >= hu and t > 0),
        key=lambda x: -x["leftS"])[:200]
    for u in users:
        n, t = st.get(u["name"], (0, 0))
        u["locked"] = bool(n >= hu and t > 0)
        u["leftS"] = t if u["locked"] else 0
    out["topUsers"] = users
    UA.risk_cache = (ck, now, out)
    return out


async def login_risk_unlock(kind: str, value: str) -> Dict[str, Any]:
    """解锁:清掉一个账号或一个 IP 段的登录失败计数(只动 guantai:lf:* 两类键)。"""
    v = str(value or "").strip()
    if kind == "user":
        key = _thr_keys(v, "")[0]
    elif kind == "ip":
        key = _LG_IP_PREFIX + (v if "/" in v else _ip_bucket(v))
    else:
        raise ValueError("kind must be user|ip")
    existed = False
    if UA.redis is not None:
        with contextlib.suppress(Exception):
            existed = bool(await UA.redis.delete(key))
    existed = (UA.mem_fail.pop(key, None) is not None) or existed
    UA.risk_cache = ()
    return {"key": key, "existed": existed}


@heavy_reads
async def login_log_page(page: int, size: int, q_ip: str = "", q_name: str = "", q_ok: str = "",
                         q_reason: str = "", hours: int = 168) -> Dict[str, Any]:
    """登录流水分页(与 reg_log_page 同一口径;额外按时窗限定,走 idx_time)。
    q_reason:具体原因码 / suspect(只看可疑)/ challenge(要求加码或人机验证)。"""
    size = max(1, min(int(size or 50), 200))
    page = max(1, int(page or 1))
    hours = max(1, min(int(hours or 168), 24 * 90))
    cond: List[str] = ["created_at >= NOW() - INTERVAL %s HOUR"]
    args: List[Any] = [hours]
    if ((q_ip and not gbk_ok(q_ip)) or (q_name and not gbk_ok(q_name))
            or (q_reason and not gbk_ok(q_reason))):
        cond.append("1=0")                  # 筛选侧不可表示 ⇒ 命中零行(同 reg_log_page)
        q_ip = q_name = q_reason = ""
    if q_ip:
        cond.append("ip=%s")
        args.append(str(q_ip)[:45])
    if q_name:
        cond.append("user_name=%s")
        args.append(str(q_name)[:50])
    if q_ok in ("0", "1"):
        cond.append("ok=%s")
        args.append(int(q_ok))
    if q_reason == "suspect":
        cond.append(_LG_SUSPECT_SQL)
    elif q_reason == "challenge":
        cond.append("reason LIKE 'challenge:%%'")
    elif q_reason:
        cond.append("reason=%s")
        args.append(str(q_reason)[:30])
    where = "WHERE " + " AND ".join(cond) + " "
    total = await _q(f"SELECT COUNT(*) AS n FROM guantai_login_log {where}", tuple(args), fetch="one")
    rows = await _q(f"SELECT id, user_id, user_name, ip, ua, ok, reason, created_at "
                    f"FROM guantai_login_log {where}ORDER BY id DESC LIMIT %s OFFSET %s",
                    tuple(args) + (size, (page - 1) * size), fetch="all") or []
    for r in rows:
        r["created_at"] = _dt_iso(r.get("created_at"))
    return {"total": int((total or {}).get("n") or 0), "page": page, "size": size,
            "hours": hours, "items": rows}


# ── 会话:签发 / 校验 / 失效 ──────────────────────────────────────────────────
def _hash_token(token: str) -> str:
    return hashlib.sha256(str(token or "").encode()).hexdigest()


async def _kick_hashes(hashes, reason: str) -> None:
    """本地缓存即时失效 + Redis 广播给其余 web 进程。"""
    for h in hashes:
        UA.cache.pop(h, None)
        if UA.redis is not None:
            with contextlib.suppress(Exception):
                await UA.redis.publish(KICK_CHANNEL, json.dumps(
                    {"tokenHash": h, "reason": reason}))


def _drop_uid_local(uid: int) -> None:
    """按 user_id 清本进程会话缓存(档位变更用)。UA.cache 有界(8192 上限,见
    validate 尾部裁剪),全扫成本可忽略,且只在「开通/撤销 VIP」这种低频动作时发生。"""
    uid = int(uid or 0)
    if uid <= 0:
        return
    for h in [k for k, v in UA.cache.items() if v.principal.user_id == uid]:
        UA.cache.pop(h, None)


async def refresh_tier(uid: int) -> None:
    """VIP 档位变更后即时刷新缓存 —— **不撤销会话**(与 kick 的关键区别:
    用户刚付完钱,把他踢回登录门是最糟的体验)。

    复用 KICK_CHANNEL 而非新开频道:载荷多一个 userId 键、监听端多三行分支,
    零新增订阅管道;旧载荷(只有 tokenHash)走原路径,向后完全兼容。
    效果:多 web 进程亚秒级一致,用户付完款立刻解锁,不必等 cache_ttl_s(20s)。"""
    _drop_uid_local(uid)
    if UA.redis is not None:
        with contextlib.suppress(Exception):
            await UA.redis.publish(KICK_CHANNEL, json.dumps(
                {"userId": int(uid), "reason": "tier"}))


async def _kick_listener() -> None:
    """订阅互顶/登出/档位刷新广播:多 web 进程(或滚动重建的新老进程)缓存一致失效。"""
    # 复审补漏:pubsub 必须**先关再重建**。旧实现在 except 分支直接回到 while
    # 顶部重新 `UA.redis.pubsub()`,旧对象既没 aclose 也没解订阅 —— 连接留在池的
    # in-use 账本、Redis 侧订阅还挂着,**每次 Redis 抖动稳定漏一条**。UA.redis
    # 就是 ST.bus.r(见 userauth.init 的接线),漏的正是 web 那个共享池。
    # 同项目的 config_center._agent 是正确范式(异常分支 aclose 后置 None 重建),
    # 此处对齐它。
    pubsub = None
    while True:
        try:
            if pubsub is None:
                pubsub = UA.redis.pubsub()
                await pubsub.subscribe(KICK_CHANNEL)
            async for m in pubsub.listen():
                if m.get("type") != "message":
                    continue
                with contextlib.suppress(Exception):
                    data = m["data"]
                    if isinstance(data, bytes):
                        data = data.decode("utf-8", "ignore")
                    _d = json.loads(data)
                    if _d.get("userId"):          # 4.2.0:按 uid 刷档位(不撤销会话)
                        _drop_uid_local(int(_d["userId"]))
                    else:                          # 3.8.0 原路径:按 tokenHash 踢会话
                        UA.cache.pop(_d.get("tokenHash", ""), None)
            # listen() 正常返回(pubsub 被关闭等):同样要重建,否则下一轮会在
            # 已关闭的对象上再 listen,空转打日志。
            with contextlib.suppress(BaseException):
                await pubsub.aclose()
            pubsub = None
        except asyncio.CancelledError:
            with contextlib.suppress(BaseException):
                if pubsub is not None:
                    await pubsub.aclose()
            raise
        except Exception:            # noqa: BLE001 —— Redis 抖动:退避重订阅
            with contextlib.suppress(Exception):
                if pubsub is not None:
                    await pubsub.aclose()
            pubsub = None
            await asyncio.sleep(3.0)


async def _janitor() -> None:
    """用户库 guantai_* 表的定时清扫。5.4.0 起由 lifecycle 的统一引擎驱动:

    节拍:启动后 45~120s 首扫 → 此后每 6 小时;任一张表没清完 60s 后续扫;有表报错
    或库尚未就绪 10 分钟后重试。各表判据仍写在本文件(本层拥有连接与字符集),
    见 janitor_sweep。旧实现(先睡 6 小时 / 单条不分批 DELETE / 一张失败全轮作废 /
    异常静默吞掉)的真库实测与逐条对应的修法见 app/lifecycle.py 头注。
    """
    from . import lifecycle
    await lifecycle.run_loop("mysql", janitor_sweep)


async def _jn_delete_2p(table: str, where: str, args: tuple = (), fixed: int = 0,
                        order: Optional[str] = None) -> Dict[str, Any]:
    """两阶段分批删除:先用**不加锁的快照读**选出一批主键,再按主键删除并复核条件。

    用于扫描范围里**混着不该删的行**的语句 —— 会话表(无时间索引,过期删除是全表扫描,
    混着正在使用的会话)、卡密池(作废卡排水走 idx_used 的 used_by=0 段,混着仍可兑换的卡;
    已兑换卡排水的范围是兑换写入新索引项的地方)、订单表(扫描范围里混着已入账的单)。
    单条 `DELETE … WHERE … LIMIT n` 在可重复读下会给**扫描过的每一行**加锁,不管它是否满足
    条件。第七轮复查真库实测(12 万张卡):卡密池排水期间,并发兑换事务被卡最长 141ms
    (基线 4.6ms),且随卡池大小线性增长;本写法下排水期间兑换延迟与基线一致(最长 4.6ms),
    排水量相同。快照读不加锁,DELETE 只按主键锁真正要删的行;复核条件保证「选出之后状态
    变了」的行不会被误删(这种竞态下本批会少删,引擎当它删干净了,下一轮补上)。
    第二阶段**必须强制走主键**:小表上优化器会把 `id IN (…)` 判成全表扫描(8.0 / 5.7 实测
    EXPLAIN 均为 type=ALL),全表扫描的 DELETE 照样锁住扫过的每一行 —— 另一事务锁着一个在用
    会话时普通写法锁等待超时、强制主键写法照常删完。MySQL 单表 DELETE 不接受索引提示,故用
    多表语法 `DELETE t FROM … AS t FORCE INDEX (PRIMARY)`(8.0 / 5.7 均实测 type=range)。
    第八轮复查:**全部**清扫删除都走本函数。带 LIMIT 的 `DELETE … ORDER BY <非唯一列> LIMIT n`
    在语句格式 binlog(binlog_format=STATEMENT)下被 MySQL 判为不安全 —— 从库按语句重放可能删掉
    不同的行(主从不一致),且每批往错误日志写一条告警;5.7 实测流水 / 注册流水 / SSO 票据三条
    原写法都被点名。按主键清单删除是确定性的,两种复制格式下主从一致、零告警。
    order:第一阶段选主键时的排序列。流水表必须传与条件对齐的索引列(created_at / expires_at)——
    `ORDER BY id` 配时间条件在没有过期行时会沿主键把整张表走一遍(第一轮实测);None = 不排序,
    按访问路径的自然顺序取(会话全表扫本就是主键序,订单 / 卡密走各自索引的范围)。
    where 里的 %s 依次取 args;fixed>0 时批量固定(卡密池沿用 5000 的刻度)。
    """
    from . import lifecycle

    async def step(n: int) -> int:
        ob = f" ORDER BY {order}" if order else ""
        rows = await _q_maint(f"SELECT id FROM {table} WHERE {where}{ob} LIMIT %s",
                              args + (int(n),), fetch="all") or []
        ids = [int(r["id"]) for r in rows]
        if not ids:
            return 0
        return int(await _q_maint(
            f"DELETE t FROM {table} AS t FORCE INDEX (PRIMARY) "
            f"WHERE t.id IN ({','.join(['%s'] * len(ids))}) AND ({where})",
            tuple(ids) + args) or 0)
    return await lifecycle.run_batched(step, fixed=fixed)


async def _jn_cap(table: str, cap: int) -> Dict[str, Any]:
    """行数上限(保命阀):只留 id 最大的 cap 行,更旧的分批裁掉。

    `MAX(id)` 走主键 O(1);两阶段:按主键范围选出、按主键删除(第一阶段走 PRIMARY 的范围扫描)。
    截断点 = `MAX(id) - cap × 自增步长`:步长(@@auto_increment_increment)通常是 1,
    此时恰好留下最新的 cap 行;双主 / Galera 一类部署把步长设成 2、3…,id 是稀疏的,
    若仍按 `MAX(id) - cap` 截,实际只会留下 cap/步长 行 —— 保命阀绝不能在**正常运行**时
    偷删历史,故按步长放大(多写入点交错写入时至多留 cap × 步长 行,仍是硬上界)。
    正常站点一辈子摸不到这条线;摸到了 = 流水正在被灌,故结果带 note,管理台「储」
    视图会把它标红。table 取自下方写死的白名单,不接受外部输入。
    """
    from . import lifecycle
    row = await _q_maint(f"SELECT MAX(id) AS hi, @@auto_increment_increment AS inc "
                         f"FROM {table}", fetch="one") or {}
    inc = max(1, int(row.get("inc") or 1))
    edge = int(row.get("hi") or 0) - int(cap) * inc
    if edge <= 0:
        return lifecycle._empty_result()
    res = await _jn_delete_2p(table, "id <= %s", (edge,), order="id")
    if res.get("deleted"):
        res["note"] = f"触及行数上限 {cap}(疑似被灌)"
    return res


# 未支付单的最短保留:远大于一切自动找回窗口(对账回看 jf_reconcile_lookback_s 默认 1 天、
# 过期恢复窗 jf_recover_window_s 默认 1 小时)。配得再小也按它执行 —— 绝不删一张还可能
# 被对账救回来的单。
_ORDER_UNPAID_MIN_DAYS = 7

# 行数上限的下限:保命阀不是保留策略。低于 10 万行(≈27 MB)的上限几乎必然是手误(少打了
# 几个 0)—— 它会在**正常运行**时把登录流水裁到只剩几天。想缩短保留请调保留天数。
_LOG_CAP_MIN = 100_000


def log_cap(c: Any = None) -> int:
    """登录 / 注册流水**实际执行**的行数上限(0 = 不设)。清扫与管理台「当前生效」共用,
    保证界面上显示的就是清扫执行的。"""
    c = c if c is not None else UA.cfg
    v = int(getattr(c, "log_max_rows", 0) or 0)
    return 0 if v <= 0 else max(_LOG_CAP_MIN, v)


def order_unpaid_days(c: Any = None) -> int:
    """未支付订单**实际执行**的保留天数(0 = 永久;下限 _ORDER_UNPAID_MIN_DAYS)。"""
    c = c if c is not None else UA.cfg
    v = int(getattr(c, "jf_order_unpaid_retention_days", 0) or 0)
    return 0 if v <= 0 else max(_ORDER_UNPAID_MIN_DAYS, v)


# 会话表的行数上限(5.4.0 复查新增)。会话行由**成功登录**产生,而登录成功不限速:持有一个
# 有效账号即可脚本化反复登录 —— 单设备互顶下每次登录新增 1 行、把上一行标为已失效,失效行
# 7 天后才删(留给被顶设备看到「已在其他设备登录」)。于是行数 ≈ 登录速率 × 7 天:正常站点
# 几千到几十万行,被刷时没有上界(公网库每秒数十次 ⇒ 一周千万行级)。
# 有效会话受账号数约束(单设备互顶下每账号 1 行,多会话模式下 ≤ max_sessions 行),无界的只有
# 已失效行 ⇒ 超过上限时只裁**最旧的已失效行**,绝不碰有效会话(不会把任何人踢下线)。
# 代价只落在被刷的一侧:最旧的被顶设备回来时看到「请重新登录」而不是「已在其他设备登录」。
_SESSION_ROWS_CAP = 1_000_000


async def _jn_session_cap(cap: int) -> Dict[str, Any]:
    """会话表行数上限:总行数超过 cap 时,按 id 从旧到新裁掉已失效行,至多裁到 cap。
    两阶段删除(快照读选主键 → 按主键删并复核 revoked=1),不锁正在使用的会话。"""
    from . import lifecycle
    row = await _q_maint("SELECT COUNT(*) AS n FROM guantai_user_session", fetch="one") or {}
    excess = int(row.get("n") or 0) - int(cap)
    if excess <= 0:
        return lifecycle._empty_result()
    left = [excess]

    async def step(n: int) -> int:
        k = min(int(n), left[0])
        if k <= 0:
            return 0
        # 两阶段(见 _jn_delete_2p):快照读选出最旧的已失效会话,按主键删 —— 不锁正在使用的会话
        rows = await _q_maint("SELECT id FROM guantai_user_session WHERE revoked=1 "
                              "ORDER BY id LIMIT %s", (k,), fetch="all") or []
        ids = [int(r["id"]) for r in rows]
        if not ids:
            return 0
        got = int(await _q_maint(
            "DELETE t FROM guantai_user_session AS t FORCE INDEX (PRIMARY) "
            f"WHERE t.id IN ({','.join(['%s'] * len(ids))}) AND revoked=1", tuple(ids)) or 0)
        left[0] -= got
        return got
    res = await lifecycle.run_batched(step)
    if res.get("deleted"):
        res["note"] = f"会话表超过行数上限 {cap}(疑似有人反复登录刷表)"
    return res


async def janitor_sweep() -> Dict[str, Any]:
    """清扫一遍用户库的 guantai_* 表(定时轮与管理台「立即清扫」共用)。

    每张表一个独立任务,**逐表隔离**;全部是幂等的「删到没有为止」。**全部**走两阶段删除
    (_jn_delete_2p:快照读选主键 → 强制主键删除):不锁业务正在用的行(第七轮),且在语句格式
    binlog 下主从一致、零告警(第八轮)。判据说明:

      · guantai_user_session  过期满 7 天、或已失效(被顶/登出)且静默满 7 天;另有行数
                              上限 _SESSION_ROWS_CAP(只裁最旧的已失效行,见该常量注)。
      · guantai_sso_ticket    过期满 1 天(票据本就 60s 级短命;已核销/未核销一视同仁,
                              审计线索在 login_log)。第一阶段走 idx_exp,稳态只读 2 行。
      · guantai_login_log     ① 超保留期(log_retention_days;第一阶段走 idx_time,`ORDER BY
                              created_at` 与索引同序,无 filesort —— 8.0 / 5.7 实测稳态只读 2 行);
                              ② 行数上限(log_max_rows;保命阀,见 _jn_cap)。
      · guantai_reg_log       同上;保留期 -1 = 跟随登录流水。
      · guantai_jf_order      **只删未支付单**:`credited=0` 且状态 pending/expired 且下单
                              超过 jf_order_unpaid_retention_days。已支付(credited=1)是
                              账本,任何条件下都不在本语句的射程内。第一阶段走 idx_status_time,
                              稳态只读 2 行。
      · guantai_jf_card       卡密池排水(4.2.8;两项默认 0 = 不清扫,「不配置即不存在」)。
                              两条判据都**只碰终态卡**,绝不碰仍可兑换的卡(used_by=0 且
                              disabled=0)—— 那类卡可能已发到用户手里,删了就是资损。
                              ⚠ 作废卡判据是**卡龄**(created_at)而非作废时长 —— 表无
                              disabled_at 列。参数名与标签已如实反映(jf_card_disabled_age_days
                              /「作废卡清扫(按卡龄)」),绝不用「保留期」这种暗示召回窗的词。
    """
    from . import lifecycle
    if not enabled() or not UA.schema_ok:
        return {"skipped": True}          # 库还没就绪:run_loop 10 分钟后再来(旧:再等 6 小时)
    c = UA.cfg
    days = int(c.log_retention_days or 0)
    rdays = int(getattr(c, "reg_log_retention_days", -1))
    if rdays < 0:
        rdays = days                      # 4.0.0:-1 = 跟随登录审计保留期
    cap = log_cap(c)
    tasks: List[tuple] = [
        ("guantai_user_session", "过期/失效满 7 天", lambda: _jn_delete_2p(
            "guantai_user_session",
            "(expires_at < DATE_SUB(NOW(), INTERVAL 7 DAY) OR (revoked=1 AND "
            "last_seen_at < DATE_SUB(NOW(), INTERVAL 7 DAY)))")),
        ("guantai_user_session", "行数上限", lambda: _jn_session_cap(_SESSION_ROWS_CAP)),
        ("guantai_sso_ticket", "过期满 1 天", lambda: _jn_delete_2p(
            "guantai_sso_ticket", "expires_at < DATE_SUB(NOW(), INTERVAL 1 DAY)",
            order="expires_at")),
    ]
    for table, keep in (("guantai_login_log", days), ("guantai_reg_log", rdays)):
        if keep > 0:
            tasks.append((table, f"超过 {keep} 天", lambda t=table, k=keep: _jn_delete_2p(
                t, "created_at < DATE_SUB(NOW(), INTERVAL %s DAY)", (k,), order="created_at")))
        if cap > 0:
            tasks.append((table, "行数上限", lambda t=table: _jn_cap(t, cap)))
    odays = order_unpaid_days(c)
    if odays > 0:
        tasks.append(("guantai_jf_order", f"未支付单超过 {odays} 天", lambda: _jn_delete_2p(
            "guantai_jf_order",
            "credited=0 AND status IN ('pending','expired') "
            "AND create_time < DATE_SUB(NOW(), INTERVAL %s DAY)", (odays,))))
    cdd = int(getattr(c, "jf_card_disabled_age_days", 0) or 0)
    if cdd > 0:
        tasks.append(("guantai_jf_card", f"作废卡卡龄超过 {cdd} 天", lambda: _jn_delete_2p(
            "guantai_jf_card",
            "used_by=0 AND disabled=1 AND created_at < DATE_SUB(NOW(), INTERVAL %s DAY)",
            (cdd,), fixed=5000)))
    cud = int(getattr(c, "jf_card_used_retention_days", 0) or 0)
    if cud > 0:
        tasks.append(("guantai_jf_card", f"已兑换卡超过 {cud} 天", lambda: _jn_delete_2p(
            "guantai_jf_card",
            "used_by<>0 AND used_at IS NOT NULL AND used_at < DATE_SUB(NOW(), INTERVAL %s DAY)",
            (cud,), fixed=5000)))
    return await lifecycle.run_tasks("mysql", tasks)


async def _authenticate(user_name: str, password: str, ip: str, ua: str, *,
                        channel: str = "web", proof: Optional[Dict[str, Any]] = None,
                        device: Any = "", link_keyed: bool = False
                        ) -> Tuple[int, dict, Optional[Dict[str, Any]]]:
    """口令校验闸 —— 4.3.0 自 login() **原样抽出**(零行为变更),供 login() 与
    「账密换链接」端点 sso_link() 共用。返回 (HTTP 状态, 响应体, 用户行或 None);
    `row is not None` ⇔ 状态 200 ⇔ 校验全过,此时响应体携带 dueIso/ddAlive 两个
    派生量,调用方无须重算。

    **为什么必须抽出而不是复制一份**:节流桶(5.2.0 起为防爆破闸门 _lg_admit)、封停/到期
    判定、审计口径全在本函数体内 —— 两个入口共用同一份实现,也就共用同一套
    「用户名 10 次 / IP 30 次 每 10 分钟」失败计数。这正是 sso_link 端点**不额外
    放大口令爆破面**的根据:攻击者从两个端点合起来拿到的尝试次数,与只有
    /api/auth/login 时**逐次相等**。tests/test_sso_link.py::
    test_link_shares_login_throttle_bucket 以活体行为钉死本性质,复制实现即变红。

    5.2.0:节流段换成「登录防爆破」闸门 _lg_admit(先占后验 / 分级加码 / 设备信任 /
    全局攻击态,见该段总注)。channel=web 才可能被要求加码(428 challenge_required)、
    才认设备信任 Cookie;channel=link(服务端对服务端,解不了题)在需要加码时:
    配了签发密钥 → 视为受托方已自行把关,跳过加码;没配 → 429(否则它就成了绕开
    加码 / 人机验证的后门)。硬上限两条通道照旧共用同一个同名计数。

    另注:`_fail_clear()` 刻意**不**放在本函数里 —— 原 login() 是在会话签发成功
    之后才清计数,签发失败(503)时计数保留。抽出时保持这一语义,由各调用方在
    自己的「真正成功」时刻调用。"""
    user_name = str(user_name or "").strip()
    password = str(password or "")
    ip, ua = str(ip or "")[:45], str(ua or "")[:200]
    if not user_name or not password:
        return 400, {"ok": False, "error": "missing_fields",
                     "message": "请输入用户名与密码"}, None
    if len(user_name) > 50 or len(password) > 64:
        return 401, {"ok": False, "error": "bad_credentials",
                     "message": "用户名或密码错误"}, None

    g = await _lg_admit(user_name, ip, ua, channel=channel, proof=proof or {},
                        device=device, link_keyed=link_keyed)
    if g.reject is not None:
        return g.reject[0], g.reject[1], None

    if not await _ensure_schema():
        await _lg_refund(g)
        return 503, {"ok": False, "error": "userdb_unavailable",
                     "message": "用户库暂时不可用,请稍后重试"}, None

    c = UA.cfg
    try:
        # 4.0.0:多一枚 LEFT JOIN guantai_user_block —— 观测台侧封禁(R7)命中即回
        # banned 语义,不碰 tb_user 一个字节;表为空时结果与 3.9.5 逐行相同。
        row = await _q(
            f"SELECT u.id, u.user_name, u.pass_word, u.is_off, u.due_time, "
            f"NOW() AS db_now, (u.due_time > NOW()) AS alive, "
            f"b.user_id AS blocked, "
            # 4.2.0:九法VIP 档位随同一条 JOIN 取齐 —— 零额外往返(公网库 RTT 昂贵)
            f"jf.vip_until AS jf_until, (jf.vip_until > NOW()) AS jf_alive "
            f"FROM `{c.user_table}` u "
            f"LEFT JOIN guantai_user_block b ON b.user_id = u.id "
            f"LEFT JOIN guantai_jf_vip jf ON jf.user_id = u.id "
            f"WHERE u.user_name=%s",
            (user_name,), fetch="one")
    except (UnicodeEncodeError, LookupError):
        row = None                    # gbk 表示不了的用户名:等价于查无此人
    except Exception as e:            # noqa: BLE001 —— 公网用户库不可达
        print(f"[登录] 用户库查询失败: {e!r}")
        await _lg_refund(g)
        return 503, {"ok": False, "error": "userdb_unavailable",
                     "message": "用户库暂时不可用,请稍后重试"}, None

    # 统一失败路径:恒定小延迟拉平「查无此人 vs 密码错」的时序差,额度不退(计入失败)
    if row is None or not verify_password(password, row.get("pass_word", "")):
        await _lg_failed(g)
        await _log_login(int(row["id"]) if row else 0, user_name, ip, ua, 0, "bad_credentials")
        await asyncio.sleep(0.35 + secrets.randbelow(300) / 1000.0)
        return 401, {"ok": False, "error": "bad_credentials",
                     "message": "用户名或密码错误"}, None

    await _lg_refund(g)               # 口令正确:本次不计失败(「只数失败」口径与旧版逐次相等)
    due_iso = _dt_iso(row.get("due_time"))
    if _is_banned(row.get("is_off")) or row.get("blocked") is not None:
        # 外部封停(is_off)与观测台侧封禁(guantai_user_block,4.0.0)同一对外语义
        # (口令验证之后才揭示,防无口令探测);审计 reason 区分来源便于研判。
        _why = "banned" if _is_banned(row.get("is_off")) else "blocked"
        await _log_login(int(row["id"]), user_name, ip, ua, 0, _why)
        return 403, {"ok": False, "error": "banned",
                     "message": "该账号已被停用,请联系管理员"}, None
    dd_alive = bool(int(row.get("alive") or 0))
    if not dd_alive and not c.jf_enabled:
        # 4.1.2 原行为:小叮当到期 = 硬拒登录。**VIP 体系关闭时逐字节不变。**
        await _log_login(int(row["id"]), user_name, ip, ua, 0, "expired")
        return 403, {"ok": False, "error": "expired", "dueTime": due_iso,
                     "message": f"账号已到期({due_iso[:16].replace('T', ' ')}),请续费后再登录"}, None
    # 4.2.0(VIP 体系开启):到期不再是登录闸,降级为「free 档」——
    # 可建会话但 _vip_guard 会拒绝**全部**数据端点,用户只看得到开通引导页。
    # 不这么做就没有任何路径能把到期用户引到收银台(这是产品需求的直接后果)。
    # 审计 reason 单列 ok_free,便于管理台数出「多少到期用户进来看了开通页」。
    out_ok: Dict[str, Any] = {"dueIso": due_iso, "ddAlive": dd_alive}
    if g.trusted:
        out_ok["_dev"] = g.did        # 内部字段:调用方据此只清设备计数(不外泄到响应体)
    return 200, out_ok, row


async def login(user_name: str, password: str, ip: str, ua: str, *,
                proof: Optional[Dict[str, Any]] = None, device: Any = ""
                ) -> Tuple[int, dict, Optional[str]]:
    """核心登录流程。返回 (HTTP 状态, 响应体, 会话令牌或 None)。
    错误语义:401 bad_credentials(用户不存在/密码错,不区分,防用户名枚举)/
    403 banned|expired(**验证口令之后**才揭示,防无口令探测账号状态)/
    429 throttled / 503 userdb_unavailable。

    4.3.0:口令校验段抽成 _authenticate()(与 sso_link 共用),本函数只剩
    「签发会话」这一段专属逻辑 —— 对外契约(入参/返回三元组/状态码/响应体)
    与 4.2.x **逐字节不变**,tests/test_userauth.py 全套原样恒绿。"""
    user_name = str(user_name or "").strip()
    ip, ua = str(ip or "")[:45], str(ua or "")[:200]
    status, payload, row = await _authenticate(user_name, password, ip, ua, channel="web",
                                               proof=proof, device=device)
    if row is None:
        return status, payload, None
    due_iso, dd_alive = str(payload["dueIso"]), bool(payload["ddAlive"])
    did = str(payload.get("_dev") or "")

    c = UA.cfg
    uid = int(row["id"])
    try:
        token, th, sid = await _issue_session(uid, str(row["user_name"]), ip, ua,
                                              free_tier=(not dd_alive))
    except Exception as e:            # noqa: BLE001
        print(f"[登录] 会话签发失败: {e!r}")
        return 503, {"ok": False, "error": "userdb_unavailable",
                     "message": "用户库暂时不可用,请稍后重试"}, None

    await _fail_clear(user_name, did)
    await _log_login(uid, user_name, ip, ua, 1, "ok" if dd_alive else "ok_free")
    pr = Principal(user_id=uid, user_name=str(row["user_name"]),
                   session_id=sid, token_hash=th, due_time_iso=due_iso,
                   dd_alive=dd_alive,
                   jf_vip_until_iso=_dt_iso(row.get("jf_until")) if row.get("jf_until") else "",
                   jf_alive=bool(int(row.get("jf_alive") or 0)))
    UA.cache[th] = _CacheEntry(pr, time.monotonic())
    return 200, {"ok": True, "user": pr.public(),
                 "singleDevice": bool(c.single_device)}, token


async def _issue_session(uid: int, user_name: str, ip: str, ua: str,
                         free_tier: bool = False) -> Tuple[str, str, int]:
    """签发一枚新会话(互顶/并发上限先行;广播即时清缓存)。返回
    (token, token_hash, session_id)。异常上抛,调用方定语义(登录/注册即登录
    → 503)。4.0.0 自 login() **原样抽出**,供「注册即登录」(赠送天数 >0 的
    注册成功分支)复用 —— 与 3.9.5 登录路径逐字节同行为。"""
    c = UA.cfg
    if c.single_device:
        olds = await _q("SELECT token_hash FROM guantai_user_session "
                        "WHERE user_id=%s AND revoked=0", (uid,), fetch="all") or []
        if olds:
            await _q("UPDATE guantai_user_session SET revoked=1, revoke_reason='kicked' "
                     "WHERE user_id=%s AND revoked=0", (uid,))
            await _kick_hashes([o["token_hash"] for o in olds], "kicked")
    elif int(c.max_sessions) > 0:
        olds = await _q("SELECT id, token_hash FROM guantai_user_session "
                        "WHERE user_id=%s AND revoked=0 AND expires_at > NOW() "
                        "ORDER BY id DESC", (uid,), fetch="all") or []
        evict = olds[max(0, int(c.max_sessions) - 1):]
        if evict:
            await _q("UPDATE guantai_user_session SET revoked=1, revoke_reason='evicted' "
                     "WHERE id IN ({})".format(",".join("%s" for _ in evict)),
                     tuple(o["id"] for o in evict))
            await _kick_hashes([o["token_hash"] for o in evict], "evicted")

    token = secrets.token_hex(32)
    th = _hash_token(token)
    ttl_s = int(max(1.0, float(c.session_ttl_h)) * 3600)
    # 4.2.0:free 档(小叮当到期且无九法VIP)是零数据档位 —— 会话短 TTL,
    # 控制 guantai_user_session 随「进来看一眼开通页就走」的用户膨胀。
    # 0 = 跟随常规 TTL。VIP 体系关闭时 free_ttl 不参与(该分支根本进不来)。
    if free_tier and float(c.jf_free_session_ttl_h) > 0:
        ttl_s = int(max(1.0, float(c.jf_free_session_ttl_h)) * 3600)
    await _q("INSERT INTO guantai_user_session (user_id, user_name, token_hash, "
             "created_at, last_seen_at, expires_at, ip, ua) VALUES "
             "(%s,%s,%s,NOW(),NOW(),DATE_ADD(NOW(), INTERVAL %s SECOND),%s,%s)",
             (uid, gbk_text(user_name, 50), th, ttl_s,
              gbk_text(ip, 45), gbk_text(ua, 200)))
    srow = await _q("SELECT id FROM guantai_user_session WHERE token_hash=%s",
                    (th,), fetch="one")
    return token, th, int(srow["id"]) if srow else 0


async def _log_login(uid: int, name: str, ip: str, ua: str, ok: int, reason: str) -> None:
    if not UA.schema_ok:
        return
    with contextlib.suppress(Exception):
        await _q("INSERT INTO guantai_login_log (user_id, user_name, ip, ua, ok, reason, "
                 "created_at) VALUES (%s,%s,%s,%s,%s,%s,NOW())",
                 (int(uid or 0), gbk_text(name, 50), gbk_text(ip, 45),
                  gbk_text(ua, 200), int(ok), gbk_text(reason, 30)))


def _dt_iso(v) -> str:
    try:
        return v.isoformat(sep="T", timespec="seconds")
    except Exception:                # noqa: BLE001
        return str(v or "")


async def validate(token: str) -> Tuple[str, Optional[Principal], dict]:
    """校验会话令牌。返回 (state, principal, extra):
    state ∈ ok / auth_required / kicked / banned / expired / unavailable。
    进程内缓存 cache_ttl_s 内直接放行;过期回源复核(会话 + 用户到期/封停一次 JOIN);
    用户库瞬断时,已验证会话在 outage_grace_s 内降级放行(principal.degraded=True)。"""
    if not token:
        return "auth_required", None, {}
    th = _hash_token(token)
    now = time.monotonic()
    ent = UA.cache.get(th)
    if ent is not None and (now - ent.checked_mono) <= float(UA.cfg.cache_ttl_s):
        return "ok", ent.principal, {}

    c = UA.cfg
    idle_s = int(max(0.0, float(c.idle_ttl_h)) * 3600)
    try:
        row = await _q(
            f"SELECT s.id AS sid, s.user_id, s.user_name, s.revoked, s.revoke_reason, "
            f"(s.expires_at > NOW()) AS not_expired, "
            f"(%s = 0 OR s.last_seen_at > DATE_SUB(NOW(), INTERVAL %s SECOND)) AS not_idle, "
            f"u.is_off, u.due_time, (u.due_time > NOW()) AS alive, "
            f"bl.user_id AS blocked, "
            f"jf.vip_until AS jf_until, (jf.vip_until > NOW()) AS jf_alive "
            f"FROM guantai_user_session s LEFT JOIN `{c.user_table}` u ON u.id = s.user_id "
            f"LEFT JOIN guantai_user_block bl ON bl.user_id = s.user_id "
            f"LEFT JOIN guantai_jf_vip jf ON jf.user_id = s.user_id "
            f"WHERE s.token_hash=%s", (idle_s, idle_s, th), fetch="one")
    except Exception as e:            # noqa: BLE001 —— 用户库瞬断:降级窗内放行既有会话
        if ent is not None and float(c.outage_grace_s) > 0 \
                and (now - ent.checked_mono) <= float(c.outage_grace_s):
            ent.principal.degraded = True
            return "ok", ent.principal, {"degraded": True}
        print(f"[登录] 会话复核失败(用户库不可达): {e!r}")
        return "unavailable", None, {}

    UA.cache.pop(th, None)
    if row is None:
        return "auth_required", None, {}
    if int(row.get("revoked") or 0):
        reason = str(row.get("revoke_reason") or "")
        return ("kicked" if reason in ("kicked", "evicted") else "auth_required"), None, {}
    if not int(row.get("not_expired") or 0) or not int(row.get("not_idle") or 0):
        return "auth_required", None, {"sessionExpired": True}
    if row.get("due_time") is None:   # 用户行已被外部系统删除
        return "auth_required", None, {}
    if _is_banned(row.get("is_off")) or row.get("blocked") is not None:
        # 4.0.0:观测台侧封禁(guantai_user_block)与外部封停同一 banned 语义;
        # 逐次复核处命中 → 在线会话最迟一个缓存周期(cache_ttl_s,默认 20s)内全网下线。
        return "banned", None, {}
    dd_alive = bool(int(row.get("alive") or 0))
    if not dd_alive and not c.jf_enabled:
        return "expired", None, {"dueTime": _dt_iso(row.get("due_time"))}
    # 4.2.0:VIP 体系开启时,到期会话继续有效(free 档)。数据面由 _vip_guard 全线拒绝;
    # SSE 心跳复核也因此不会把正在看开通页的用户踢回登录门(web.events 的 authRevoked)。

    pr = Principal(user_id=int(row["user_id"]), user_name=str(row["user_name"]),
                   session_id=int(row["sid"]), token_hash=th,
                   due_time_iso=_dt_iso(row.get("due_time")),
                   dd_alive=dd_alive,
                   jf_vip_until_iso=_dt_iso(row.get("jf_until")) if row.get("jf_until") else "",
                   jf_alive=bool(int(row.get("jf_alive") or 0)))
    prev = ent.touched_mono if ent else 0.0
    UA.cache[th] = ent2 = _CacheEntry(pr, now)
    ent2.touched_mono = prev
    if (now - prev) >= _TOUCH_MIN_S:  # last_seen 限频回写(空闲判定的数据源)
        ent2.touched_mono = now
        # 强引用:asyncio 只对任务持**弱引用**,官方文档明写「未被别处引用的
        # 任务可能在完成前的任意时刻被回收」。这条 _touch 写的是 last_seen_at ——
        # 空闲判定的数据源,丢了会让在线用户被误判为空闲。集合 + done_callback
        # 自摘是官方推荐的 fire-and-forget 写法(与 web._SSE_CLEANUPS 同款)。
        _t = asyncio.get_running_loop().create_task(_touch(row["sid"]))
        _TOUCH_TASKS.add(_t)
        _t.add_done_callback(_TOUCH_TASKS.discard)
    if len(UA.cache) > 8192:          # 缓存有界:清最陈旧的一半
        pairs = sorted(UA.cache.items(), key=lambda kv: kv[1].checked_mono)
        for k, _ in pairs[:len(pairs) // 2]:
            UA.cache.pop(k, None)
    return "ok", pr, {}


async def user_names(uids) -> Dict[int, str]:
    """批量解析 uid → 用户名(管理台租约视图展示用,3.9.4)。
    **只查自有 `guantai_user_session`**(每次登录都会写入冗余 user_name,天然覆盖
    所有出现过租约的账号)—— 刻意不触碰 tb_user,维持「对既有表仅登录/复核两处
    SELECT」的最小接触面纪律。失败/未启用回空 dict:呈现层退化为只显 #uid,无害。"""
    ids = sorted({int(u) for u in (uids or []) if str(u).strip().lstrip("-").isdigit()})
    if not ids or not enabled():
        return {}
    ph = ",".join(["%s"] * len(ids))
    try:
        rows = await _q(
            f"SELECT user_id, user_name FROM guantai_user_session "
            f"WHERE user_id IN ({ph}) ORDER BY id", tuple(ids), fetch="all")
    except Exception:                 # noqa: BLE001 —— 观测辅助,库抖动即空
        return {}
    out: Dict[int, str] = {}
    for r in rows or []:              # ORDER BY id 升序:后写覆盖 = 取「最近一次登录」的名字
        with contextlib.suppress(Exception):
            out[int(r["user_id"])] = str(r["user_name"] or "")
    return out


async def _touch(sid) -> None:
    # idem=True:`SET last_seen_at=NOW() WHERE id=?` 是**证明幂等**的写 —— 重放
    # 一次只是把同一行的时戳再刷成 NOW(),没有第二次副作用。这是热路径上唯一的
    # 高频写(每会话至多 60s 一次),给它保留「换入口重试」才不会因为一次公网
    # 瞬断就丢掉空闲判定的数据源。
    with contextlib.suppress(Exception):
        await _q("UPDATE guantai_user_session SET last_seen_at=NOW() WHERE id=%s",
                 (int(sid),), idem=True)


async def logout(token: str) -> None:
    if not token:
        # 没带会话 Cookie 的登出(重复点登出 / 会话早已过期 / 被拒的跨站请求):无会话可撤,
        # 不打共享公网库、不广播 —— 旧写法照样按空串散列去 UPDATE 一次(5.2.0 复查)
        return
    th = _hash_token(token or "")
    with contextlib.suppress(Exception):
        await _q("UPDATE guantai_user_session SET revoked=1, revoke_reason='logout' "
                 "WHERE token_hash=%s AND revoked=0", (th,))
    await _kick_hashes([th], "logout")


# ── Cookie ────────────────────────────────────────────────────────────────────
def _cookie_secure(request: Request) -> bool:
    mode = str(UA.cfg.cookie_secure or "auto").lower()
    if mode in ("on", "1", "true", "always"):
        return True
    if mode in ("off", "0", "false", "never"):
        return False
    xf = (request.headers.get("x-forwarded-proto") or "").split(",")[0].strip().lower()
    return (xf or request.url.scheme) == "https"


def set_session_cookie(resp: Response, request: Request, token: str) -> None:
    resp.set_cookie(UA.cfg.cookie_name, token,
                    max_age=int(max(1.0, float(UA.cfg.session_ttl_h)) * 3600),
                    httponly=True, samesite="lax", secure=_cookie_secure(request),
                    path="/")


def clear_session_cookie(resp: Response, request: Request) -> None:
    resp.delete_cookie(UA.cfg.cookie_name, path="/")


def client_ip(request: Request) -> str:
    """节流分桶 / 审计用的来源 IP。

    5.2.0 改走 app/clientip.py 的「可信代理」判定:仅当直连对端属于可信代理
    (STA_TRUSTED_PROXIES,默认环回 + 内网)时才采信 X-Forwarded-For,且从最右往左
    取第一个非代理跳。旧口径「trust_forwarded_for 开 = 无条件取首跳」在**直连部署**
    (本项目官方编排)下可被任意伪造 —— 实证:公网对端每请求换一个假 XFF,按 IP 的
    登录节流形同虚设。trust_forwarded_for=False 仍是「只认直连地址」。"""
    trust = bool(UA.cfg is not None and getattr(UA.cfg, "trust_forwarded_for", True))
    return clientip.from_request(request, trust_xff=trust)[:45]


# ══════════════════════════════════════════════════════════════════════════════
# 站点分流:直营主站 vs 代理镜像站(4.4.1)
# ------------------------------------------------------------------------------
# 同一套后端同时对外服务多个域名。按请求 Host 判定本次请求落在哪种站点:
#   · 直营主站 → 在线扫码付款 + 卡密,两条路都给;
#   · 代理镜像站 → 只给卡密(代理自己卖卡),前端藏掉扫码入口与档位卡,
#                  后端 /api/vip/order/create 一并拒单。
#
# 三条必须写在代码旁边的认识(而不是只写在文档里):
#
# ① **这是业务分区,不是安全边界。** Host 由调用方给,伪造头即可自称直营。
#    但绕过的收益是"用户直接付钱给平台",而他本来就能打开直营站付款 —— 没有
#    任何东西因此被多拿走。本模块要挡的是两件真事:镜像站页面上不该摆着扫码
#    入口;以及"F12 把按钮 hidden 去掉就能下单"这种一步可达的绕过。
#    因此**绝不可**把本判定复用到任何鉴权/额度/记账语义上。
#
# ② **默认必须是旧行为。** 名单为空 = 特性整体关闭 = 全部按直营 ——「不配置即
#    不存在」,老部署升级上来逐字节无感。
#
# ③ **名单是"直营白名单"而不是"镜像黑名单"。** 新代理接进来无需改配置就自动
#    是镜像站;漏配的代价落在"代理少卖一单",而不是"代理的客户绕过代理直付
#    平台"。反过来做的话每接一个代理都得记得加一行,而忘记是常态。
# ══════════════════════════════════════════════════════════════════════════════
# 配置侧分隔符:半角逗号/分号/空白,外加中文逗号与顿号 —— 后两个是从聊天窗口
# 或文档里粘贴时的高频差错,与 jfvip._CARD_STRIP 容忍粘贴噪音同一取向。
_HOST_SPLIT = re.compile(r"[,\s;、，]+")
# scheme 前缀:`https://`、`ftp://`… 以及协议相对写法 `//host`。
# 剥任意 scheme 而不只剥 http/https —— 只剥两个的话,`ftp://example.com` 会在后面
# 的「去端口」步骤里被切成无意义的 `ftp`(测试实测),运维在启动横幅里看到那个残片
# 也猜不出发生了什么。剥 scheme 是**解析**不是猜测,Host 头本身永远不含 `://`。
_HOST_SCHEME = re.compile(r"^(?:[a-z][a-z0-9+.\-]*:)?//")


def norm_host(raw: Any) -> str:
    """把「一个可能带 scheme/路径/端口/大小写/尾点的域名串」归一成裸主机名。

    只做**无歧义**的变换,不做任何猜测(与 jfvip.norm_card「刻意不做字符纠错」
    同一纪律):去 scheme、去首个 `/` 之后、转小写、去端口、去尾随点。
      · `HTTPS://Example.COM:8443/path` → `example.com`
      · `//example.com`                 → `example.com`(协议相对写法)
      · `example.com.`                  → `example.com`
      · `[::1]:5173`                    → `[::1]`(IPv6 字面量保留方括号形式,
                                          与浏览器 Host 头的写法一致)
    归一化失败/结果为空一律回 `""`,由调用方按"不在名单内"处理(fail-closed)。
    """
    h = str(raw or "").strip().lower()
    if not h:
        return ""
    m = _HOST_SCHEME.match(h)                 # 去 scheme / 协议相对前缀
    if m:
        h = h[m.end():]
    h = h.split("/", 1)[0]                    # 去路径(粘贴整条 URL 的高频差错)
    if not h:
        return ""
    if h.startswith("["):                     # IPv6 字面量:端口在 `]` 之后
        end = h.find("]")
        return h[:end + 1] if end > 0 else h
    if ":" in h:
        h = h.rsplit(":", 1)[0]               # 去端口
    return h.rstrip(".")                      # 去 FQDN 绝对形式的尾随点


def jf_direct_host_set() -> frozenset:
    """解析「直营主站域名」配置为归一化后的集合。空集 = 本特性未启用。

    刻意**不做缓存**:两个调用点都是冷路径(/api/auth/session 每页一次、
    下单端点本就限频 20 次/时),而缓存要么带全局可变状态、要么需要失效钩子,
    换来的收益是一次几微秒的字符串切分 —— 不值得。
    """
    cfg = UA.cfg
    raw = str(getattr(cfg, "jf_direct_hosts", "") or "") if cfg is not None else ""
    if not raw.strip():
        return frozenset()
    out = set()
    for tok in _HOST_SPLIT.split(raw):
        n = norm_host(tok)
        if n:
            out.add(n)
    return frozenset(out)


def site_host(request: Optional[Request]) -> str:
    """本次请求自称的站点主机名(已归一化)。取不到回 ""。"""
    if request is None:
        return ""
    raw = ""
    cfg = UA.cfg
    if cfg is not None and getattr(cfg, "jf_direct_trust_xfh", False):
        # X-Forwarded-Host 多跳时形如 `原始站点, 中间层…` —— 取**首跳**
        # (最靠近客户端的那个)。注意这只服务于站点分流(业务分区,非安全边界);
        # 来源 IP 另走 client_ip() 的可信代理口径(取最右非代理跳),两者刻意不同。
        raw = (request.headers.get("x-forwarded-host", "") or "").split(",")[0]
    if not raw.strip():
        raw = request.headers.get("host", "") or ""
    return norm_host(raw)


def jf_site(request: Optional[Request]) -> Dict[str, Any]:
    """本次请求的站点判定。**唯一出口** —— 前端下发与后端下单闸共用这一份,
    杜绝"界面按直营渲染、后端按镜像拒单"这类两边打架的失真。

    返回:
      host     本次判定用到的主机名(已归一化;回显给前端只是为了让运维能在
               devtools 里一眼看出"后端到底把这个站看成了什么",这是本特性
               最高频的排查问题)
      direct   是否直营主站
      pay      是否提供在线扫码付款(当前 == direct;单列一个键是为了将来若要
               加"某镜像站也放开在线支付"这类例外时,前端契约不必跟着改)
      enforced 本特性是否已启用(名单非空)。false ⇒ 一切按旧行为
    """
    hosts = jf_direct_host_set()
    host = site_host(request)
    if not hosts:                       # 未配置即不存在:全部按直营(逐字节旧行为)
        return {"host": host, "direct": True, "pay": True, "enforced": False}
    direct = host in hosts
    return {"host": host, "direct": direct, "pay": direct, "enforced": True}


# ── 客服联系方式(4.4.2)────────────────────────────────────────────────────────
# 4.4.1 的「联系客服购买」只是一句话;本节给它配上真正可用的联系方式。
#
# 为什么这不是推翻 §12.6 的「不做可配置项」,而是把它收窄:
#   原话是「本站有多个来源,每个来源的客服渠道不同且由该来源自己告知用户,平台
#   这里没有一个『正确的』客服可指」。这句话**只在代理镜像站成立** —— 直营主站上
#   卖家就是平台自己,恰恰存在唯一正确的客服。判别器现成:jf_site().direct。
#
# 本节是**全项目唯一**的客服值出口(前端各处、管理台回显、启动横幅都读它),
# 三件事必须在这里一次做完,别处不许再有第二份实现:
#   ① 站点裁剪:非直营主站直接回 {} —— 镜像站的响应体里根本不出现平台客服号。
#      **不是**下发了再让前端藏起来:那样 F12 一开就能把它从代理站页面里挖出去,
#      正是 §12.3 点名要挡的「一步可达的绕过」;
#   ② 字符收敛:折叠空白、剥控制字符与双向覆盖符(见 _CS_STRIP);
#   ③ 链接白名单:只放行 http/https 绝对 URL。
#
# ⚠ ②③ **必须**落在这里而不是管理台校验里:config_center.semantic_validate 只在
#   /api/admin/config/{validate,apply} 这条路上跑,而 ENV(STA_JF_CS_*)与
#   config.yaml **绕过它直接进 Settings**。把清洗放在管理台,等于给自己留了一条
#   「运维改 .env 就能把 javascript: 送进 href」的路。
_CS_LIMITS = {"label": 16, "value": 64, "url": 256, "note": 48}
# 折叠用:含半角空白 + NBSP + 全角空格(从聊天窗口粘贴的高频噪音)。
_CS_WS = re.compile(r"[\s\u00a0\u3000]+")
# 逐字剥除的不可见/改序字符。**刻意不按 unicodedata 的 Cf 类整类剥** ——
# 那会连 ZWJ(U+200D)一起剥掉,而 ZWJ 是 emoji 组合序列的连接符,渠道名里
# 写个「👨‍💼客服」就会被拆成两个字符。这里只点名两类真正有害的:
#   · 零宽/BOM(U+200B、U+FEFF):能在展示串里藏东西,让肉眼核对失效;
#   · 双向控制与隔离符(U+200E/F、U+202A–E、U+2066–9):能把 "kf@evil.com"
#     渲染成看起来是别的顺序 —— 客服号是要用户照着抄的,顺序被改写就是送错人。
_CS_STRIP = dict.fromkeys(
    [0x200B, 0x200E, 0x200F, 0x2028, 0x2029,
     0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
     0x2066, 0x2067, 0x2068, 0x2069, 0xFEFF], None)


def cs_text(raw: Any, limit: int, *, drop_if_over: bool = False) -> str:
    """把一条展示用短文本收敛到「单行、无不可见字符、长度有上界」。

    ★ 超长的两种处置(4.4.2 自审新增,**不是**可有可无的开关):
      · drop_if_over=False(默认,给 label / note 这类**装饰性**字段):截断。
        一个被截短的标签仍然认得出来,而且没人会去复制它。
      · drop_if_over=True(给 value / url 这类**用户要照抄或点击**的字段):
        **整条丢弃**。截断一个号码 = 用户照着抄却永远打不通;截断一个 URL =
        一条看起来合法、实际指向别处或 404 的链接 —— 后者尤其恶劣,因为它
        通过了 http/https 白名单,看不出任何异常。
        这与本仓库既有的取向一字不差(jfvip.py 定制时长卡):
        「截断会让用户拿到一张与卡面不符的卡,而 fail-closed 只是让他去找客服」。
        丢弃**不静默**:启动横幅与管理台概览都会点名说明(见 jfvip.startup_report)。

    ⚠ 为什么运行期还要管超长 —— 管理台的 semantic_validate 已经对超长报错了,
      但 `STA_JF_CS_*` 与 config.yaml **绕过它直接进 Settings**。凡是只靠管理台
      把关的规则,在这个项目里都等于没有把关。

    **刻意不做字符纠错**(与 jfvip.norm_card、userauth.norm_host 同一条纪律):
    全角数字、错别字、多打的一位都原样留着。猜错一个字符的后果是把付费用户
    送到别人那里,而「看起来像被系统改过」比「一眼看出是自己填错了」更难排查。
    保存时由 semantic_validate 告警,但绝不替运维改。

    截断按**字符**而非字节,且是最后一步 —— 先折叠再剥再截,免得截断刚好切在
    一个被剥掉的字符上、让上界随输入噪音浮动。
    """
    s = _CS_WS.sub(" ", str(raw or "")).strip()
    if not s:
        return ""
    s = s.translate(_CS_STRIP)
    # 折叠后仍可能残留其它 C0/C1 控制字符(如 \x01):它们不是空白,上面折不掉。
    s = "".join(ch for ch in s if ch >= " " and ch != "\x7f")
    if len(s) > limit:
        return "" if drop_if_over else s[:limit].strip()
    return s


def cs_url(raw: Any) -> str:
    """收敛「在线客服链接」。**只放行 http/https 绝对 URL**,其余一律回 ""。

    白名单而非黑名单,理由是黑名单在这里必输:`javascript:`、`JaVaScRiPt:`、
    带前导空白/换行的变体、`data:`、`vbscript:`… 每一个都得想到才挡得住,而
    白名单只需要说清楚「什么是对的」。

    ⚠ HTML 转义**不能**代替这道闸:`href="javascript:alert(1)"` 里没有任何一个
    需要转义的字符,esc() 原样放行,浏览器照样执行。这是本项目第一处把用户可配
    的字符串写进 href,故把这条写在代码里而不只是文档里。

    协议相对写法 `//evil.com` 同样拒绝 —— 它会继承当前页协议直接指向外站,
    看起来却像一条相对路径。
    """
    # 超长 fail-closed:被截短的 URL 会**通过**下面的白名单,却指向别处或 404 ——
    # 一条看不出异常的坏链比没有链接糟得多。
    s = cs_text(raw, _CS_LIMITS["url"], drop_if_over=True)
    if not s:
        return ""
    low = s.lower()
    if not (low.startswith("http://") or low.startswith("https://")):
        return ""
    # 主机名必须真的存在。`https:///path`、`https://:80/`、`https://?x` 三种都是
    # 「有 scheme 没主机」—— 前缀判定放得过去,浏览器却无处可去(又一个死控件)。
    # 刻意不用 urlparse:这里只做**一个**判断(scheme 是不是 http/https),
    # 而 urlparse 的 host 解析在 `\` / `@` 上另有一套与浏览器不一致的口径,
    # 引入它等于把一个简单判断换成一堆需要逐条核对的边界(而目的地本来就由
    # 运维自己指定,我们不替他判断"该不该去这个 host")。
    # maxsplit 用关键字传:module-level re.split 的位置式 maxsplit 自 Python 3.13
    # 起弃用、将来会变成 keyword-only(官方 whatsnew 3.13 明载)。部署镜像现钉
    # python:3.12-slim,今天不会响,但这是全仓**唯一**一处位置式写法 —— 不留。
    host = re.split(r"[/?#]", s.split("://", 1)[1], maxsplit=1)[0]
    if not host or host.startswith(":"):
        return ""
    return s


def cs_resolve(cfg: Any = None) -> Dict[str, str]:
    """把配置收敛成「将要展示的那几个值」。**不含站点闸。**

    存在理由是一次真实的自审事故:收敛逻辑原本在 cs_info / startup_report /
    overview 三处各写了一遍,而横幅那份**漏传了 drop_if_over** —— 于是一个已被
    fail-closed 丢弃的号码,在启动日志里被显示成「联系方式已配置 · 客服QQ 999…」。
    横幅的全部价值就是让运维在用户找上门之前看到真相,它一旦和真相不一致,
    比没有横幅更坏。三处从此共用本函数,不许再有第二份收敛。

    不含站点闸是**刻意**的:管理台与横幅要回答的是「这份配置解析成了什么」,
    而不是「此刻这个 Host 能不能拿到」—— 后者对管理员恒为他自己的域名,
    毫无信息量。站点闸只属于 cs_info(下发路径)。

    返回「有才给」的字典;号码与链接都没有时回 {}(不配置即不存在)。
    """
    c = UA.cfg if cfg is None else cfg
    if c is None:
        return {}
    # value / url 走 fail-closed(见 cs_text 的 drop_if_over 注):被截短的号码
    # 让用户照着抄却永远打不通;被截短的 URL 更糟 —— 它会**通过**白名单。
    value = cs_text(getattr(c, "jf_cs_value", ""), _CS_LIMITS["value"],
                    drop_if_over=True)
    url = cs_url(getattr(c, "jf_cs_url", ""))
    if not (value or url):
        return {}
    out: Dict[str, str] = {}
    label = cs_text(getattr(c, "jf_cs_label", ""), _CS_LIMITS["label"])
    note = cs_text(getattr(c, "jf_cs_note", ""), _CS_LIMITS["note"])
    if label:
        out["label"] = label
    if value:
        out["value"] = value
    if url:
        out["url"] = url
    if note:
        out["note"] = note
    return out


def cs_info(request: Optional[Request] = None) -> Dict[str, str]:
    """本次请求可下发的客服联系方式。**空 dict = 没有**(三种情形合并成一种):

      · 未配置(号码与链接都空)—— 「不配置即不存在」,逐字节 4.4.1 行为;
      · 本次请求不是直营主站 —— 平台客服不进代理的站;
      · 登录系统尚未初始化 —— 取不到配置,宁可不给。

    键按「有才给」下发(而不是给一堆空串):旧前端拿到多余键会忽略,但**响应体
    里出现一个空的 contact 段**会让排查的人误以为特性已生效只是值没填,而真相
    可能是站点判成了镜像。没有就是没有,不留半个影子。
    """
    if UA.cfg is None:
        return {}
    # ★ 站点闸放在最前面:后面任何一行都不该在镜像站上被执行到。
    if not jf_site(request).get("direct", True):
        return {}
    return cs_resolve()


# ── /api/auth 路由 ────────────────────────────────────────────────────────────
router = APIRouter()


@router.post("/api/auth/login")
async def auth_login(request: Request):
    """账密登录。5.2.0 加固(均为实证缺口):
      · best-effort 同源校验(与注册/SSO 同一 _origin_mismatch)+ 只收 JSON:旧版
        接受 `Content-Type: text/plain` 的跨源提交并照发会话 Cookie —— 跨站表单
        (enctype=text/plain 可拼出合法 JSON)即可把受害者静默登进攻击者账号
        (login-CSRF;本应用账号库按用户隔离,受害者随后扫码的酷狗票据会落进攻击者名下);
      · 请求体必须是 JSON 对象:旧版对 `[]` 之类直接 500;
      · 认设备信任 Cookie(jf_dev)、透传加码证明(challengeId/nonce/captchaToken),
        成功后轮换设备 Cookie。"""
    if not enabled():
        return JSONResponse({"ok": False, "error": "login_disabled",
                             "message": "本部署未启用登录系统"}, status_code=503)
    if _origin_mismatch(request):
        return JSONResponse({"ok": False, "error": "bad_origin",
                             "message": "请求来源校验未通过"}, status_code=403)
    ct = (request.headers.get("content-type") or "").split(";")[0].strip().lower()
    if ct not in ("", "application/json"):
        return JSONResponse({"ok": False, "error": "bad_request",
                             "message": "请求格式有误,请刷新页面后重试"}, status_code=415)
    try:
        body = await request.json()
        if not isinstance(body, dict):
            raise ValueError("body must be object")
    except Exception:                # noqa: BLE001
        return JSONResponse({"ok": False, "error": "bad_request",
                             "message": "请求格式有误,请刷新页面后重试"}, status_code=400)
    user_name = str(body.get("userName") or body.get("user_name") or "").strip()
    password = str(body.get("password") or body.get("pass_word") or "")
    proof = {k: body.get(k) for k in ("challengeId", "nonce", "captchaToken")}
    status, payload, token = await login(user_name, password, client_ip(request),
                                         request.headers.get("user-agent", ""),
                                         proof=proof,
                                         device=request.cookies.get(_LG_DEV_COOKIE, ""))
    resp = JSONResponse(payload, status_code=status)
    if status == 429 and payload.get("retryAfter"):
        resp.headers["Retry-After"] = str(int(payload["retryAfter"]))
    if status in (428, 429, 503):
        resp.headers["Cache-Control"] = "no-store"
    if status == 200 and token:
        set_session_cookie(resp, request, token)
        await set_device_cookie(resp, request, user_name)
        if on_login_ok is not None:
            # 首登预置房等登录后动作:await 完成再返回 —— 前端拿到 200 随即
            # reload 拉 /api/live-rooms,预置必须先于那次读落库(避免首屏白名录)。
            try:
                await on_login_ok(int((payload.get("user") or {}).get("id") or 0))
            except Exception as e:                    # noqa: BLE001
                print(f"[登录] 登录成功回调异常(忽略,不影响登录): {e!r}")
    return resp


@router.post("/api/auth/logout")
async def auth_logout(request: Request):
    # 5.2.0 复查(同类模式):与登录 / 注册 / SSO 同一 best-effort 同源校验。会话 Cookie 是
    # SameSite=Lax,跨站 POST 带不上它、注销不了服务端会话;但顶级导航的响应仍可下发
    # 「清 Cookie」—— 跨站表单就能把受害者在本机登出(登出 CSRF,骚扰级),一并堵上。
    if enabled() and _origin_mismatch(request):
        return JSONResponse({"ok": False, "error": "bad_origin",
                             "message": "请求来源校验未通过"}, status_code=403)
    if enabled():
        await logout(request.cookies.get(UA.cfg.cookie_name, ""))
    resp = JSONResponse({"ok": True})
    if UA.cfg is not None:
        clear_session_cookie(resp, request)
    return resp


def _jf_matrix_now() -> list:
    """取当前能力矩阵。兼容 list(旧注入)与 callable(4.4.0,按生效配置渲染)。"""
    m = jf_matrix
    if callable(m):
        try:
            m = m()
        except Exception:            # noqa: BLE001 —— 对比表坏掉不该拖垮 /session
            return []
    return list(m or [])


def jf_session_info(pr: Optional[Principal],
                    request: Optional[Request] = None) -> dict:
    """/api/auth/session 的 jf 段。**未启用时回 {"enabled": False}** ——
    前端据此把 tier 视作 'vip'(全功能),与旧后端/旧部署逐字节同行为
    (同 POW.on / REG.mode 的既有约定)。

    matrix 是「当前 vs VIP」对比表的**唯一数据源**:它与 web._vip_guard 的接线
    共用一份声明(见 web.VIP_MATRIX),所以前端展示的能力表永远不会与后端实际
    放行的端点脱节 —— 杜绝「说能用实际不能用」的欺骗性文案。"""
    c = UA.cfg
    if c is None or not c.jf_enabled:
        return {"enabled": False}
    out = {"enabled": True,
           "tier": pr.tier if pr is not None else "free",
           # ← web.py 注入(list 或 callable);callable 形态每次按生效配置渲染。
           # 渲染失败绝不能让整页起不来 —— 退化成空表 = 不显示对比表。
           "matrix": _jf_matrix_now(),
           "basicHistoryLimit": int(c.jf_basic_history_limit),
           "basicPredWindow": int(c.jf_basic_pred_window),
           # 4.4.0:basic 档在线累计窗(小时;0=关闭)。前端据此决定是否落地/回灌
           # 本机快照。**下发生效值而非常量** —— 与 histIntervalS 同款约定,运维
           # 改 STA_JF_BASIC_ONLINE_H 后前端下次取 session 即跟随,无需重建前端。
           "basicOnlineH": float(c.jf_basic_online_h),
           # 4.4.1:站点分流。**下发生效判定而非常量** —— 与 basicOnlineH 同款约定:
           # 同一份静态产物被多个域名共用(index.html 走 no-cache+304,更不可能
           # 把站点身份烘进 HTML),前端只能靠这一跳知道自己此刻是哪种站。
           # 旧前端忽略本字段;新前端在字段缺失时按 pay=true 走(=旧行为)。
           "site": jf_site(request)}
    try:
        import json as _j
        out["plans"] = _j.loads(c.jf_vip_plans)
    except Exception:                 # noqa: BLE001 —— 档位表配坏不该让整页起不来
        out["plans"] = []
    if pr is not None:
        out["jfVipUntil"] = pr.jf_vip_until_iso
        out["jfVipDays"] = _due_days(pr.jf_vip_until_iso) if pr.jf_vip_until_iso else None
        out["ddAlive"] = bool(pr.dd_alive)
    return out


@router.get("/api/auth/session")
async def auth_session(request: Request, response: Response):
    """前端开机首问:登录系统是否启用、当前是否已登录。未启用时前端维持旧行为。"""
    # ── 4.4.2:本响应**禁止任何缓存**(private, no-store)────────────────────────
    # 依据是 RFC 9111 与 MDN 的明文,不是保守习惯:
    #   ① 共享缓存的「不得存储」豁免**只绑定 Authorization 请求头**;本项目走
    #      Cookie(jf_user_sid),不在豁免内 —— 也就是说,没有显式指令时,一个
    #      中间缓存**可以合法地**存下本响应并拿去满足别人的请求;
    #   ② RFC 9111 安全考量一节专门点名:`Set-Cookie` **不抑制缓存**,带
    #      Set-Cookie 的可缓存响应「可以(而且经常)被用来满足后续请求」。
    #      「这条路在登录后面」不是任何一条被承认的缓存指令。
    # 而本响应恰恰是全站个人化最强的一个:user.id / userName / tier /
    # jfVipUntil,4.4.2 起还加上了**按 Host 裁剪**的客服联系方式。后者让它多了
    # 一重性质 —— 它不只随人不同,还**随站点不同**:一个忽略 Host 的错配缓存
    # 会把直营站的响应回给镜像站,平台客服号就此进了代理的页面。
    #   (site 分流自 4.4.1 起就让本响应带上了 Host 依赖,故这不是 4.4.2 才有的
    #    问题;但 4.4.2 把后果从"少个支付按钮"抬到了"泄漏联系方式",值得显式钉住。)
    # 用 private + no-store 两条:no-store 对私有/共享缓存都生效(最强),
    # private 再显式表明「永远不进共享缓存」—— 这正是本处要防的那一类。
    # ⚠ 刻意**不**做成中间件给全部 /api/* 加:实地核查发现
    #   `/api/rooms/{room}/history` 在冻结窗上有意下发
    #   `public, max-age=604800, immutable`(仅 VIP 可达 —— basic 带 until 会先被
    #   403;内容是按 URI 定键的整房历史,不含个人数据),一刀切会把那处
    #   「同一历史日 7 天零重复传输」的优化白白打掉。
    response.headers["Cache-Control"] = "private, no-store"
    # 4.4.2 客服联系方式:**顶层 `contact` 段,刻意不挂在 `jf` 下面**。
    #   · jf 段在 jf_vip_enabled=false 时整体退场({"enabled": False}),而客服是
    #     站点级事实、将来要在开通门之外的地方复用(登录门的「账号已到期」、
    #     注册零赠送分支的「请联系管理员」…),不能跟着 VIP 开关一起消失;
    #   · 未启用登录系统那条早返回路径也带上它 —— 那条路上前端同样会拿到响应,
    #     漏在那里就成了「某些部署下客服栏莫名其妙不出现」这类最难查的缺陷。
    # 无内容时整个键都不出现(见 cs_info 的 docstring),旧前端零影响。
    _cs = cs_info(request)
    if not enabled():
        out0 = {"ok": True, "enabled": False, "authed": False}
        if _cs:
            out0["contact"] = _cs
        return out0
    state, pr, extra = await validate(request.cookies.get(UA.cfg.cookie_name, ""))
    _pob = bool(getattr(UA.cfg, "proof_of_browser", False))
    _reg = await reg_session_info()               # 4.0.0:注册入口开关(旧前端忽略此字段)
    _lg = login_session_info()                    # 5.2.0:登录人机验证(未开 = 空对象,旧前端忽略)
    # 4.2.0:档位/档位表/能力矩阵;4.4.1 起附带站点分流判定(需 request 取 Host)
    _jf = jf_session_info(pr if state == "ok" else None, request)
    if state == "ok" and pr is not None:
        out1 = {"ok": True, "enabled": True, "authed": True, "user": pr.public(),
                "singleDevice": bool(UA.cfg.single_device),
                "pow": {"enabled": _pob},          # 3.9.1:执行证明闸是否开启(前端据此决定是否 mint)
                "reg": _reg,
                "login": _lg,
                "jf": _jf,                          # 4.2.0:前端 boot 最早期即知档位(快照短路的前提)
                "degraded": bool(extra.get("degraded"))}
        if _cs:
            out1["contact"] = _cs
        return out1
    out = {"ok": True, "enabled": True, "authed": False, "state": state,
           "pow": {"enabled": _pob}, "reg": _reg, "login": _lg, "jf": _jf}
    if _cs:
        out["contact"] = _cs
    if extra.get("dueTime"):
        out["dueTime"] = extra["dueTime"]
    return out


# ── 中间件守卫 ────────────────────────────────────────────────────────────────
# 免用户会话的路径(自身鉴权/公共探针):
_EXEMPT_PREFIX = ("/api/auth/",)
_EXEMPT_EXACT = {"/api/version", "/api/auth"}


def _exempt(path: str) -> bool:
    """免用户会话的路径。5.3.0:管理面的豁免**跟随配置的入口路径**,不再写死 /api/admin/。
    实测旧写法的副作用:未登录访问任意不存在的 /api/x 得 401,访问 /api/admin/x 却得 404 ——
    管理台搬走以后,旧前缀仍能被这个差异一眼认出。现在旧前缀与任何未知路径同样先过会话闸。
    外部发卡接口按**精确路径**豁免(机器契约,地址恒定;精确匹配不构成「前缀口子」)。"""
    if path in _EXEMPT_EXACT or path.startswith(_EXEMPT_PREFIX):
        return True
    from . import admin_auth
    ap = admin_auth.api_prefix()
    return path == ap or path.startswith(ap + "/") or path == admin_auth.CARD_ISSUE_PATH
# 天然带不了自定义头的只读端点(EventSource / <img>):Cookie 门照过,仅豁免 CSRF 头
#   /api/active-room/release 也在此列:关页时经 navigator.sendBeacon 发出(带不了头),
#   语义是「主动交还本会话的活跃房租约」,幂等且无害(至多让自己能更快换房),CSRF 无关。
_NO_HEADER_OK = {"/api/events", "/fx/avatar", "/api/active-room/release"}
# 管理台/运维通道可代用户会话的名录写端点(admin.js 携带管理台会话或 X-Monitor-Token)
_ADMIN_FALLBACK = {"/api/monitor/add", "/api/monitor/add-bulk", "/api/monitor/remove"}
CSRF_HEADER = "x-jf-auth"

_ERR = {
    "auth_required": (401, "请先登录"),
    "kicked":        (401, "账号已在其他设备登录,当前会话已失效"),
    "banned":        (403, "该账号已被停用,请联系管理员"),
    "expired":       (403, "账号已到期,请续费后重新登录"),
    "unavailable":   (503, "用户库暂时不可用,请稍后重试"),
}


def _admin_bypass(request: Request) -> bool:
    """名录写端点的运维旁路:X-Monitor-Token 命中,或管理台会话有效。

    管理台 Cookie 分支**仅认 POST**(复查修复):add/remove 同时接受 GET,而
    管理台 Cookie 是 SameSite=Lax —— 跨站顶层导航的 GET 会带上它;若 GET 也走
    旁路,攻击页一个 <a>/<img> 就能替已登录管理员加/删房(CSRF)。admin.js 对
    名录写全部用 POST(实地核查),POST 在 Lax 下跨站不带 Cookie,收紧零影响。
    令牌头分支不受限:跨站脚本设不了自定义头,天然免疫,保留 GET 的运维便利。"""
    import os as _os
    tok = (_os.environ.get("STA_MONITOR_WRITE_TOKEN") or "").strip()
    if tok and request.headers.get("x-monitor-token", "") == tok:
        return True
    if request.method != "POST":
        return False
    try:
        from . import admin_auth
        if admin_auth.enabled():
            sess = admin_auth.parse_session(request.cookies.get(admin_auth.COOKIE, ""))
            if sess:
                return True
    except Exception:                # noqa: BLE001
        pass
    return False


async def guard(request: Request) -> Optional[JSONResponse]:
    """HTTP 中间件主体:未启用登录系统 → 一律放行(3.7.0 原行为)。
    启用后:/api/*(除豁免)与 /fx/avatar 必须携带有效会话;通过则把身份注入
    request.state.user(端点据此做按账号隔离);写接口同时要求 X-JF-Auth 头。"""
    request.state.user = None
    request.state.user_admin = False
    if not enabled():
        return None
    path = request.url.path
    if not (path.startswith("/api/") or path == "/fx/avatar"):
        return None                   # 静态资源/SPA:壳公开,数据全部在 /api 之后
    if _exempt(path):
        return None

    state, pr, extra = await validate(request.cookies.get(UA.cfg.cookie_name, ""))
    if state == "ok" and pr is not None:
        request.state.user = pr
        # CSRF:除 SSE/<img> 外的所有 /api 请求都必须带自定义头(fetch 层统一附带)
        if path not in _NO_HEADER_OK and not request.headers.get(CSRF_HEADER):
            return JSONResponse({"ok": False, "error": "bad_origin",
                                 "message": "请求缺少来源校验头,已拒绝"}, status_code=403)
        return None

    if path in _ADMIN_FALLBACK and _admin_bypass(request):
        request.state.user_admin = True
        return None                   # 运维全局名录操作:无用户身份,端点走全局旧语义

    code, msg = _ERR.get(state, (401, "请先登录"))
    body = {"ok": False, "error": ("auth_required" if state == "auth_required" else state),
            "message": msg}
    if extra.get("dueTime"):
        body["dueTime"] = extra["dueTime"]
    if extra.get("sessionExpired"):
        body["sessionExpired"] = True
    return JSONResponse(body, status_code=code)


# ══════════════════════════════════════════════════════════════════════════════
# 注册系统(4.0.0)—— 前端自助注册 · 防恶意注册纵深 R0–R8
# ==============================================================================
# 设计/威胁模型/纪律修订见 REGISTER-SYSTEM.md。要点:
#   · **不配置即不存在**:reg_mode=off(默认)时端点回 503、前端零入口。
#   · **tb_user 旧行绝对零改动**:全项目对该表永远没有 UPDATE/DELETE/ALTER/
#     TRUNCATE;仅本文件 _register_tx() 内存在**恰好一条** INSERT(新行)——
#     tests/test_register.py::test_tb_user_sql_discipline 以静态扫描钉死本纪律。
#   · R0 经济闸:默认零赠送(due_time=NOW()),空壳号连登录都过不去,攻击产出≈0。
#   · R1 限流 fail-closed:Redis 抖动退化进程内计数,**绝不放开**;挑战无法落
#     Redis 时注册回 503(已有会话的一切功能不受影响)。
#   · R2 双证明:powAnswer(混淆 JS 执行证明)⊕ SHA-256 前导零 PoW(自适应难度)。
#   · R6 熔断:越顶自动降档(Redis 态,多进程即时一致),**不自动回升**。
#   · 用户名规则(运营拍板,4.0.6):2–20 位,**仅 [A-Za-z0-9]**(纯数字放行)。
#     字符集写死为常量以保前后端零漂移;**只约束新增注册,不追溯存量** ——
#     登录侧不做字符集校验,存量中文名/手机号型名照常登录。
#   · 口令规则(运营拍板):5–16 位字符,**无字符组合限制**;仅拦控制字符,
#     plain 形态额外要求 gbk 可编码(varchar 列物理约束)。摘要形态取 UTF-8 字节,
#     与登录侧 verify_password 同口径。
# ══════════════════════════════════════════════════════════════════════════════

_REG_USER_MIN, _REG_USER_MAX = 2, 20          # 用户名长度(字符)
# 用户名字符集(4.0.6 运营拍板):**仅 ASCII 英文字母与阿拉伯数字**,纯数字放行。
# 刻意写死为常量而**不**入参数中心:前端 app.js 的即时校验必须与本式逐字同规则,
# 而前端拿不到运行期热改的值 —— 做成可热改必然产生「后端已收窄、前端还在放行」的
# 漂移(用户白付一次 PoW 才被打脸)。同值性由 test_frontend_backend_username_charset
# 源码级对拍钉死,与 _REG_PASS_MIN/MAX 的既有姿态一致。
# 只约束**新增注册**,**不追溯存量**:登录侧 _authenticate 对用户名恒不做字符集
# 校验,存量中文名、以及外部续费系统建的手机号型名(如 +8613800138000)照常登录。
_REG_USER_RE = re.compile(r"^[A-Za-z0-9]+$")
_REG_PASS_MIN, _REG_PASS_MAX = 5, 16          # 口令长度(字符;与前端 index.html/app.js 同值,契约测试钉住)
_REG_BITS_MIN, _REG_BITS_CAP = 8, 25          # PoW 难度下限/硬顶(前导零位)
_REG_HP_FIELD = "contact"                      # 蜜罐字段名(R4;与前端同名,契约测试钉住)
_CTRL_RE = re.compile(r"[\x00-\x1f\x7f]")
_FP_RE = re.compile(r"^[0-9a-f]{16}$")
_NONCE_RE = re.compile(r"^[0-9A-Za-z_-]{1,32}$")
_CID_RE = re.compile(r"^[0-9a-f]{32}$")
_EXTRA_COL_RE = re.compile(r"^[A-Za-z0-9_]{1,64}$")
_BASE_COLS = frozenset({"id", "user_name", "pass_word", "due_time", "is_off"})
_SHAPES = ("plain", "md5", "sha1", "sha256")
# 各口令形态写入 pass_word 所需的最小列长(hex 摘要位数;plain 按口令上限 16)。
# 运行期 C7 闸(_shape_storable)只硬拦 sha256/64;md5/sha1/plain 配短列会在
# INSERT 撞 1406 → 同样落入笼统 503,故启动自检按本表提前点名(4.0.4)。
_PW_SHAPE_LEN = {"plain": 16, "md5": 32, "sha1": 40, "sha256": 64}
# 「用户名已被占」的独立限流:重名是真人正常探索(常用名多半被占),不该消耗 R1
# 主配额,否则试几个名字就锁一小时。但仍需封顶 —— 否则可拿它做**用户名枚举**。
# 取值远宽于主配额(默认 5/时),真人试十几个名字绰绰有余;枚举者还得为每次重名
# 付一次完整 PoW(重名检查刻意排在 PoW 校验之后),成本足够劝退。
_NT_HOURLY = 20                                # 每 IP 每小时「重名」上限
# 内置保留名单(恒生效;仅约束**新增注册**,不追溯存量;STA_USER_REG_RESERVED 可追加)
_RESERVED_BUILTIN = frozenset({
    "admin", "administrator", "root", "superadmin", "super", "system", "sysadmin",
    "support", "service", "staff", "operator", "moderator", "owner", "master",
    "test", "guest", "anonymous", "null", "undefined", "guantai", "xiaodingdang",
    "管理员", "超级管理员", "超管", "系统", "客服", "官方", "站长", "运营", "测试",
    "小叮当", "九法", "观测台", "游客",
})
_CROCK = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"   # Crockford Base32(无 I/L/O/U,0O1I 不混淆)
_CROCK_FIX = str.maketrans("OILoil", "011011")

K_REG_CHAL = "guantai:regchal:{cid}"           # 注册挑战(单次性,独立于 L2 的 powchal:{sid},C5)
K_REG_CB = "guantai:reg:cb"                    # R6 熔断态(JSON;无 TTL,恢复须管理台显式点击)
# 原子「取键即删」:GET+DEL 两步存在重放窗口,GETDEL 需 Redis ≥6.2 —— Lua 全版本原子。
_LUA_GETDEL = ("local v=redis.call('GET',KEYS[1]) "
               "if v then redis.call('DEL',KEYS[1]) end return v")

_REG_RT: Dict[str, Any] = {"pwcol_ok": None, "extra_raw": None, "extra": None,
                          "getdel": None}   # getdel: 挑战核销的原子性档位探测缓存


def _rs(v) -> str:
    """Redis 返回值统一成 str(bytes/None 兼容)。"""
    if v is None:
        return ""
    return v.decode("utf-8", "ignore") if isinstance(v, bytes) else str(v)


def _md5_16(s: str) -> str:
    return hashlib.md5(str(s or "").encode("utf-8", "ignore")).hexdigest()[:16]


# ── 模式解析(配置档 × 熔断档 → 生效档) ───────────────────────────────────────
def _reg_shape() -> str:
    s = str(getattr(UA.cfg, "reg_pass_shape", "") or "").strip().lower()
    return s if s in _SHAPES else ""


def reg_mode_configured() -> str:
    """配置档:off/invite/open。前置条件不满足(登录未启用 / 口令形态未配)时
    强制视作 off(启动时 _reg_startup_report 已醒目告警,此处静默兜底)。"""
    if UA.cfg is None:
        return "off"
    m = str(getattr(UA.cfg, "reg_mode", "off") or "off").strip().lower()
    if m not in ("invite", "open"):
        return "off"
    if not enabled() or not _reg_shape():
        return "off"
    return m


async def breaker_get() -> Dict[str, Any]:
    """R6 熔断态(空 dict = 未触发)。Redis 抖动按未触发返回 —— 此时挑战/提交
    本就会因 Redis 不可用回 503(fail-closed),熔断器无输入也无洞。"""
    if UA.redis is None:
        return {}
    try:
        raw = _rs(await UA.redis.get(K_REG_CB))
        return json.loads(raw) if raw else {}
    except Exception:                 # noqa: BLE001
        return {}


async def breaker_set(mode: str, why: str) -> None:
    """自动降档(只降不升:已 off 不会被 invite 覆盖)。"""
    if UA.redis is None:
        return
    with contextlib.suppress(Exception):
        cur = await breaker_get()
        if cur.get("mode") == "off" and mode != "off":
            return
        import datetime as _dt
        await UA.redis.set(K_REG_CB, json.dumps(
            {"mode": mode, "why": why, "by": "auto",
             "at": _dt.datetime.now().isoformat(timespec="seconds")}))


async def breaker_clear() -> bool:
    if UA.redis is None:
        return False
    with contextlib.suppress(Exception):
        return bool(await UA.redis.delete(K_REG_CB))
    return False


async def reg_throttle_clear() -> Dict[str, Any]:
    """管理台运维(4.0.3):清空全部注册限流计数 —— guantai:reg:* 全族,Redis 与
    进程内兜底(mem_reg)双清。覆盖:R1 时/日窗(try/tryd)、全局窗(g:h/g:d)、
    难度阶梯(d24)、同名(name)/重名(nt)计数、成功配额(okd)、挑战签发计数
    (chal:ip)、指纹线索(fp)、审计限幅(al)、事务锁(lk)。

    刻意排除三类(作用域即语义):
    * K_REG_CB 熔断态 —— 它改变注册**生效模式**,且刻意只留手动恢复路径
      (管理台熔断横幅「恢复注册」);清限流不该顺手改模式(最小惊讶);
    * guantai:regchal:* 挑战载荷 —— 正在填表的用户无感,不为清计数付体验税;
    * guantai:lf:* 登录失败锁 —— 登录域,不属注册限流。

    Redis 异常不失败:进程内照清,redis_ok=False 如实上抛给管理台明示。"""
    n_redis, redis_ok = 0, True
    if UA.redis is not None:
        try:
            batch: List[str] = []
            async for k in UA.redis.scan_iter(match="guantai:reg:*", count=500):
                kk = k.decode("utf-8", "ignore") \
                    if isinstance(k, (bytes, bytearray)) else str(k)
                if kk == K_REG_CB:
                    continue
                batch.append(k)
                if len(batch) >= 500:
                    n_redis += int(await UA.redis.delete(*batch))
                    batch = []
            if batch:
                n_redis += int(await UA.redis.delete(*batch))
        except Exception:             # noqa: BLE001 —— Redis 抖动:mem 照清,如实上报
            redis_ok = False
    mem = [k for k in UA.mem_reg
           if k.startswith("guantai:reg:") and k != K_REG_CB]
    for k in mem:
        UA.mem_reg.pop(k, None)
    return {"redis": n_redis, "mem": len(mem), "redis_ok": redis_ok}


async def reg_state() -> Tuple[str, Dict[str, Any]]:
    """(生效档, 熔断态)。生效档 = 配置档与熔断档取更严者(open→invite→off)。"""
    cfgm = reg_mode_configured()
    br = await breaker_get()
    if cfgm == "off":
        return "off", br
    bm = str(br.get("mode") or "")
    if bm == "off":
        return "off", br
    if bm == "invite" and cfgm == "open":
        return "invite", br
    return cfgm, br


async def reg_session_info() -> Dict[str, Any]:
    """/api/auth/session 的 reg 字段:前端据 mode≠off 才渲染注册入口。"""
    try:
        eff, _ = await reg_state()
    except Exception:                 # noqa: BLE001
        eff = "off"
    out: Dict[str, Any] = {"mode": eff}
    if eff != "off":
        prov = _cap_conf("reg")["provider"]          # 5.2.0:尊重「注册时也要」开关
        if prov in ("tencent", "geetest", "turnstile"):
            out["captcha"] = {"provider": prov,
                              "appId": str(getattr(UA.cfg, "reg_captcha_id", "") or "")}
    return out


def _reg_startup_report() -> None:
    """启动自陈:模式/口令形态/额外列/验证码配置的醒目体检(仅打印,不阻断)。"""
    try:
        cfg = UA.cfg
        m = str(getattr(cfg, "reg_mode", "off") or "off").strip().lower()
        if m not in ("invite", "open"):
            print("[注册] 注册系统关闭(reg_mode=off)—— 行为与 3.9.5 一致;"
                  "开启方式见 REGISTER-SYSTEM.md")
            return
        if not _reg_shape():
            print("[注册] ⚠️ reg_mode 非 off 但 STA_USER_REG_PASS_SHAPE 未配置/不合法 —— "
                  "注册强制视作 off。请先跑 `userdb_check.py --reg-preflight` 拿建议值。")
            return
        if reg_extra_cols() is None:
            print("[注册] ⚠️ STA_USER_REG_EXTRA_COLS 不是合法 JSON 映射 —— 注册将回 503 "
                  "register_unavailable(fail-closed),请修正后重启。")
        prov = _cap_conf("reg")["provider"]          # 5.2.0:尊重「注册时也要」开关
        raw = str(getattr(cfg, "reg_captcha", "off") or "off").strip().lower()
        cap = "off" if prov == raw or raw not in _CAP_PROVIDERS else f"关(注册不要;{raw} 仅供登录)"
        if prov in ("tencent", "geetest", "turnstile"):
            miss = (not getattr(cfg, "reg_captcha_id", "")
                    or not getattr(cfg, "reg_captcha_key", "")
                    or (prov == "tencent" and (not getattr(cfg, "reg_captcha_secret_id", "")
                                               or not getattr(cfg, "reg_captcha_secret_key", ""))))
            cap = f"{prov}{'(⚠️ 凭据缺失 → 注册将 503 fail-closed)' if miss else ''}"
        gift = ("随邀请码" if m == "invite"
                else f"{int(getattr(cfg, 'reg_trial_days', 0))} 天")
        print(f"[注册] 注册系统已启用 · 模式={m} · 口令形态={_reg_shape()}"
              f"(5–16 位,无组合限制) · 赠送={gift} · PoW 基础 "
              f"{int(getattr(cfg, 'reg_pow_bits', 17))} 位 · 人机验证={cap}")
    except Exception as e:            # noqa: BLE001
        print(f"[注册] 启动自陈异常(忽略): {e!r}")


async def _reg_startup_probe() -> None:
    """启动期注册可行性自检(4.0.4;登录启用即扫描一次,零数据副作用)。

    动机(真机复现驱动):真实 tb_user 若存在**未被 STA_USER_REG_EXTRA_COLS 覆盖
    的 NOT NULL 且无默认列**,注册事务的那条 INSERT 会撞 MySQL 1364,被上层统一
    兜成对外「注册暂时不可用(register_unavailable)」、对内仅一行日志 —— 运营若不
    盯容器日志便**无从定位**(线上反馈:注册长期 503 而不知病灶在缺列)。

    本自检把这一诊断**从「首个注册请求」提前到「启动」**:`SHOW FULL COLUMNS`
    读一次列结构(纯只读、不写行、不动 AUTO_INCREMENT),点名缺列并直接生成可照抄
    的 EXTRA_COLS 建议;顺带按当前口令形态复核 pass_word 列长(运行期 C7 闸只硬拦
    sha256≥64;md5=32 / sha1=40 / plain=16 若放不下会在 INSERT 撞 1406,同样隐形
    503,故一并提前点名),并确认 Redis 已接入(缺 Redis 时挑战/限流全 503)。
    结果存 `UA.reg_probe`,管理台 /reg/overview 以 preflight 字段带出。

    列型判定经 MariaDB 10.11 与 MySQL 8.0 严格模式**双引擎实测**定标:
      · ENUM NOT NULL 无默认 —— 两家省略均可插(隐式取首枚举值,SHOW 却报
        Default=NULL),故**不判缺**,否则纯误报;
      · 生成列(Extra 含 GENERATED;MySQL 8 允许 NOT NULL 且报 Default=NULL)——
        INSERT 不该也不能供值,**跳过**,否则误报且「补进 EXTRA_COLS」的建议有害;
      · SET / JSON / TIMESTAMP / TIME / YEAR 的 NOT NULL 无默认省略确撞 1364,
        判缺并给类型化建议值(set→首字面量、json→"{}"、time→"00:00:00"、
        year→0;MariaDB 的 JSON 落地为 longtext,建议空串,运营按需改值)。

    扫描不以 reg_mode 为前提(热切 off→open 无需重启即有结论可看);**日志告警**
    按扫描时 mode≠off 门控 —— 注册关着就不在启动/测试输出里刷屏。

    纪律:**绝不抛、绝不阻断启动**(用户库在公网,启动窗口瞬断很常见);读列失败
    只记 unknown 并留待注册路径的既有兜底。完整探针(INSERT 权限/类型实测)仍在
    `scripts/userdb_check.py --reg-preflight`(那条会占一格 AUTO_INCREMENT,不宜每次
    重启都跑,故不并入启动)。"""
    shape = _reg_shape()
    mode = reg_mode_configured()
    loud = mode != "off"
    probe: Dict[str, Any] = {"ok": None, "mode": mode, "reason": "",
                             "table": str(getattr(UA.cfg, "user_table", "tb_user")),
                             "missing": {}, "uncoverable": [],
                             "suggestExtraCols": "", "pwLen": None,
                             "pwReq": _PW_SHAPE_LEN.get(shape), "shape": shape,
                             "redisMissing": UA.redis is None,
                             "extraRaw": str(getattr(UA.cfg, "reg_extra_cols", "") or ""),
                             "scannedAt": time.time()}
    if not shape:                         # 形态未配:注册前置条件缺失(启动自陈已
        probe["reason"] = "shape_unset"   # 醒目告警;此处不做列长判定以免误导归因)
    try:
        extra = reg_extra_cols()
        if extra is None:                 # EXTRA_COLS 非法 JSON:fail-closed;仍继续
            probe["reason"] = probe["reason"] or "extra_cols_invalid"  # 保留先发原因;扫列给「从零照抄」建议
            if loud:
                print("[注册] ⚠️ 启动自检:STA_USER_REG_EXTRA_COLS 非合法 JSON 映射 —— "
                      "注册将回 503;下方缺列建议按「未配任何额外列」计算,修正后重启。")
        try:
            cols = await _q(f"SHOW FULL COLUMNS FROM `{probe['table']}`",
                            fetch="all") or []
        except Exception as e:            # noqa: BLE001 —— 用户库瞬断:留待注册路径兜底
            probe.update(ok=None, reason=probe["reason"]
                         or f"probe_unreadable:{type(e).__name__}")
            UA.reg_probe = probe
            if loud:
                print(f"[注册] 启动自检:tb_user 列信息暂不可读(用户库瞬断?注册路径仍有"
                      f"兜底,不阻断启动): {e!r}")
            return
        covered = set(_BASE_COLS) | {str(k).lower() for k in (extra or {})}
        need: Dict[str, Any] = {}
        uncover: list = []
        pw_len: Optional[int] = None
        for c in cols:
            fld = str(c.get("Field") or "")
            typ_raw = str(c.get("Type") or "")
            typ = typ_raw.lower()
            base = typ.split("(", 1)[0].strip()
            xtra = str(c.get("Extra") or "").upper()
            nullable = str(c.get("Null") or "").upper() == "YES"
            default = c.get("Default")
            if fld.lower() == "pass_word":
                m = re.search(r"\((\d+)\)", typ)
                pw_len = int(m.group(1)) if m else None
            if nullable or default is not None:
                continue
            if "AUTO_INCREMENT" in xtra or "GENERATED" in xtra:
                continue                  # 生成列不能在 INSERT 供值(MySQL 8 实测)
            if base == "enum":
                continue                  # 隐式首枚举值,省略可插(双引擎实测)
            if fld.lower() in covered:
                continue
            if base in ("datetime", "timestamp", "date"):
                need[fld] = "$now"
            elif base == "time":
                need[fld] = "00:00:00"
            elif base == "set":
                m = re.match(r"set\('([^']*)'", typ_raw, re.I)
                need[fld] = m.group(1) if m else ""   # 保留原大小写(_bin 排序规则下才可插)
            elif base == "json":
                need[fld] = "{}"
            elif base in ("int", "bigint", "smallint", "tinyint", "mediumint",
                          "decimal", "float", "double", "numeric", "bit", "year"):
                need[fld] = 0
            else:
                need[fld] = ""
            if not _EXTRA_COL_RE.match(fld):
                uncover.append(fld)       # 列名出白名单:EXTRA_COLS 表达不了,须 ALTER
        probe["pwLen"] = pw_len
        probe["missing"] = need
        probe["uncoverable"] = uncover
        shape_bad = bool(probe["pwReq"] and pw_len is not None
                         and pw_len < probe["pwReq"])
        if need:
            merged = dict(extra or {})
            merged.update({k: v for k, v in need.items() if _EXTRA_COL_RE.match(k)})
            probe["suggestExtraCols"] = json.dumps(merged, ensure_ascii=False)
        probe["ok"] = bool(shape and (not need) and (not shape_bad)
                           and extra is not None and not probe["redisMissing"])
        UA.reg_probe = probe
        if not loud:
            return
        if probe["redisMissing"]:
            print("[注册] ⚠️ 启动自检:Redis 未接入 —— 挑战签发/限流全部 503,"
                  "注册不可用。请检查 userauth.init 的 redis 入参。")
        if need:
            print(f"[注册] ⚠️ 启动自检:`{probe['table']}` 存在未覆盖的 NOT NULL 无默认列 "
                  f"{list(need.keys())} —— 注册的 INSERT 必撞 MySQL 1364,对外回 503 "
                  f"register_unavailable。请设置 STA_USER_REG_EXTRA_COLS(照抄,按需改值):")
            print(f"        STA_USER_REG_EXTRA_COLS={probe['suggestExtraCols']}")
            print("        (改后重启 web;或先跑 scripts/userdb_check.py --reg-preflight 复核)")
        if uncover:
            print(f"[注册] ⚠️ 启动自检:缺列 {uncover} 的列名不符 EXTRA_COLS 白名单"
                  f"([A-Za-z0-9_]),无法用配置覆盖 —— 需外部系统 ALTER 补默认值。")
        if shape_bad:
            gate = ("运行期 C7 闸已硬拦(register_unavailable)" if shape == "sha256"
                    else "INSERT 将撞 1406 截断报错,同样对外 503")
            print(f"[注册] ⚠️ 启动自检:口令形态 {shape} 需 pass_word 列长 ≥ "
                  f"{probe['pwReq']},实际 {pw_len} —— {gate}。"
                  f"请换更短形态或由外部系统扩列。")
        if probe["ok"]:
            print(f"[注册] ✓ 启动自检通过:`{probe['table']}` 基础四列 + 已配 "
                  f"{len(extra or {})} 个额外列即可满足 INSERT(纯列体检,未写任何行)。")
    except Exception as e:                # noqa: BLE001 —— 自检永不阻断启动
        probe.update(ok=None, reason=f"probe_exception:{type(e).__name__}")
        UA.reg_probe = probe
        if loud:
            print(f"[注册] 启动自检异常(忽略,不影响启动): {e!r}")


def reg_probe_status() -> Dict[str, Any]:
    """管理台「注册系统」健康块读取启动自检结论(只读快照)。"""
    return dict(UA.reg_probe or {})


def _probe_drift() -> bool:
    """自检快照相对当前配置是否已漂移(参数中心热改 mode/形态/EXTRA_COLS)。
    user_table 不入指纹:注册表实况 hot=RESTART 且 readonly,运行期不可变。"""
    p = UA.reg_probe or {}
    try:
        return (not p
                or p.get("mode") != reg_mode_configured()
                or p.get("shape") != _reg_shape()
                or str(p.get("extraRaw", "")) !=
                str(getattr(UA.cfg, "reg_extra_cols", "") or ""))
    except Exception:                     # noqa: BLE001 —— cfg 异常时不强刷
        return False


_PROBE_LOCK = asyncio.Lock()
# 复查实测(CPython 3.12,同部署镜像 python:3.12-slim)钉死的安全边界:
#   · 无竞争获取走快路径,**不触碰事件循环**——任何循环任何顺序恒安全;
#   · 慢路径(真实挂起等待)才绑定/比对循环;仅『同进程两个不同循环里
#     **都**发生真实竞争』才 RuntimeError —— uvicorn 单循环生产不可能,
#     且即便发生也被 admin 链路外层 suppress 兜为一次快照陈旧,不崩服务。
# 故模块级创建在本项目形态下正确;若未来移植到多循环/低版本环境,请改为
# 按 get_running_loop() 惰性建锁。


async def reg_probe_fresh() -> Dict[str, Any]:
    """取自检结论;若注册相关配置已被**参数中心热改**(mode / 口令形态 /
    EXTRA_COLS 原串任一与快照不符)则先重扫一次再返回(4.0.4 复查补钳)。

    动机:探针原本只在 init 跑一次;运行期走参数中心把 reg_extra_cols 填对后,
    注册立即恢复(运行时读实时配置),但管理台横幅仍拿着启动时的旧缺列快照 ——
    「明明修好了还报错」的反向陈旧误导。本函数以三元指纹判漂移,变了才重扫
    (SHOW FULL COLUMNS,毫秒级、只读、幂等),未变则零开销直接返快照。
    并发漂移经单飞锁 + 双重检查收敛为一次重扫(消日志噪声;正确性本就幂等)。
    表结构本身被外部 ALTER 的极端情况仍需重启或改一次配置触发重扫(可接受)。"""
    if _probe_drift():
        async with _PROBE_LOCK:
            if _probe_drift():            # 双检:等锁期间可能已被首个协程刷新
                with contextlib.suppress(Exception):
                    await _reg_startup_probe()
    return dict(UA.reg_probe or {})


# ── IP 分桶(IPv6 /64,与 R1 全部键 + 挑战绑定同口径) ──────────────────────────
def _ip_bucket(ip: str) -> str:
    """IPv4 原址 / IPv6 按 /64(实现见 clientip.bucket —— 登录、注册、SSO、管理台同一口径)。"""
    return clientip.bucket(ip)


def _net24(ip: str) -> str:
    """难度阶梯的邻域桶:IPv4 → /24;IPv6 → /64(与 _ip_bucket 同)。"""
    s = str(ip or "").strip()
    if not s:
        return "unknown"
    if ":" in s:
        return _ip_bucket(s)
    try:
        return str(ipaddress.ip_network(f"{s}/24", strict=False))
    except ValueError:
        return s[:45]


# ── 账号形态闸(R5,确定性拒绝) ───────────────────────────────────────────────
def _reserved_names() -> set:
    out = set(_RESERVED_BUILTIN)
    extra = str(getattr(UA.cfg, "reg_reserved", "") or "") if UA.cfg else ""
    for part in extra.split(","):
        p = part.strip()
        if p:
            out.add(p)
            out.add(p.lower())
    return out


def validate_reg_username(name: Any) -> Tuple[Optional[str], str, str]:
    """→ (清洗后的用户名 | None, 错误码, 文案)。登录侧对用户名 .strip(),故此处
    同口径先 strip 再校验(带首尾空格的名字永远登不进来,注册它没有意义)。

    4.0.6:字符集收窄为 **[A-Za-z0-9]**(运营拍板,纯数字放行)。一条正则同时吃掉
    空白、控制符、中文、emoji、全角字母(ＡＢ 这类同形字仿冒)与连字符/下划线,
    文案统一为可操作的一句话。**仅约束新增注册,不追溯存量**——见 _REG_USER_RE 注。

    闸序刻意是「先长度、后字符集」:长度闸同时兜住空串,若字符集在前,空输入会拿到
    「只能包含英文字母和数字」这种驴唇不对马嘴的提示。
    """
    n = str(name or "").strip()
    if not (_REG_USER_MIN <= len(n) <= _REG_USER_MAX):
        return None, "name_invalid", f"用户名需为 {_REG_USER_MIN}–{_REG_USER_MAX} 个字符"
    if not _REG_USER_RE.match(n):
        return None, "name_invalid", "用户名只能包含英文字母和数字"
    # ↓ 以下两闸经 _REG_USER_RE **构造性保证不可达**(ASCII 字母数字必无空白/控制符,
    #   且在 gbk/utf8 等一切部署字符集下恒可编码)。**刻意保留而非删除**:字符集若
    #   将来被放宽,C8 的这两条底线不会随之静默失守。改 _REG_USER_RE 时请连本注一并复核。
    if _CTRL_RE.search(n) or any(ch.isspace() for ch in n):
        return None, "name_invalid", "用户名不能包含空格或控制字符"
    try:
        n.encode("gbk")               # 与登录侧「gbk 表示不了按不存在处理」同口径(C8)
    except Exception:                 # noqa: BLE001
        return None, "name_invalid", "用户名包含无法保存的字符(如 emoji),请更换"
    # 保留名闸排在字符集之后:中文保留名(管理员/客服/官方…)此后由字符集闸先行拦下,
    # 拿到的是「只能包含英文字母和数字」而非「该用户名不可用」——后者对中文输入者
    # 毫无指导意义。名单里的中文条目**保留不删**:字符集一旦放宽,它们立即重新生效。
    rs = _reserved_names()
    if n in rs or n.lower() in rs:
        return None, "name_reserved", "该用户名不可用,请更换一个"
    return n, "", ""


def validate_reg_password(pw: Any, shape: str) -> Tuple[bool, str, str]:
    """口令规则(运营拍板,4.0.0):**5–16 位字符,无字符组合限制** —— 不要求
    大小写/数字/符号搭配,不设弱口令黑名单,纯数字亦可。仅两条技术性底线:
    ① 禁控制字符(不可见、必属误输入/注入,且多系统无法可靠存储);
    ② shape=plain 时须 gbk 可编码(pass_word 列 gbk,物理放不下 emoji 等)——
       摘要形态(md5/sha1/sha256)存的是 hex,天然无此约束。"""
    p = str(pw or "")
    if not (_REG_PASS_MIN <= len(p) <= _REG_PASS_MAX):
        return False, "password_invalid", f"密码需为 {_REG_PASS_MIN}–{_REG_PASS_MAX} 位字符"
    if _CTRL_RE.search(p):
        return False, "password_invalid", "密码不能包含控制字符"
    if shape == "plain":
        try:
            p.encode("gbk")
        except Exception:             # noqa: BLE001
            return False, "password_invalid", "密码包含无法保存的字符(如 emoji),请更换"
    return True, "", ""


def encode_reg_password(pw: str, shape: str) -> str:
    """按入库形态编码口令。摘要取 UTF-8 字节 —— 与登录侧 verify_password 的
    raw = s.encode('utf-8') 逐字节同口径,保证观测台注册的用户在观测台必然登得进。"""
    p = str(pw or "")
    if shape == "md5":
        return hashlib.md5(p.encode("utf-8")).hexdigest()
    if shape == "sha1":
        return hashlib.sha1(p.encode("utf-8")).hexdigest()
    if shape == "sha256":
        return hashlib.sha256(p.encode("utf-8")).hexdigest()
    return p                          # plain


async def _shape_storable(shape: str) -> bool:
    """sha256(64 hex)是否放得进真实 pass_word 列(C7 矛盾的运行期把关):
    首次注册尝试时对 information_schema 实测列长并缓存;不合格即拒(绝不让
    MySQL 非严格模式静默截断出「永远登不进」的脏行)。DB 异常上抛由调用方 503。"""
    if shape != "sha256":
        return True
    if _REG_RT["pwcol_ok"] is None:
        row = await _q(
            "SELECT CHARACTER_MAXIMUM_LENGTH AS L FROM information_schema.COLUMNS "
            "WHERE TABLE_SCHEMA=%s AND TABLE_NAME=%s AND COLUMN_NAME='pass_word'",
            (UA.cfg.db, UA.cfg.user_table), fetch="one")
        length = int(row["L"]) if row and row.get("L") is not None else 0
        _REG_RT["pwcol_ok"] = bool(length >= 64)
        if not _REG_RT["pwcol_ok"]:
            print(f"[注册] ⚠️ pass_word 真实列长 {length} < 64 —— sha256 形态物理放不下,"
                  f"注册已拒绝(register_unavailable)。请改用 plain/md5/sha1,"
                  f"或先由外部系统扩列。")
    return bool(_REG_RT["pwcol_ok"])


def reg_extra_cols() -> Optional[Dict[str, Any]]:
    """解析 STA_USER_REG_EXTRA_COLS(JSON)。合法 → dict(可空);不合法 → None
    (fail-closed:注册回 503,启动自陈已告警)。列名白名单 [A-Za-z0-9_]、禁与
    基础四列重叠;取值仅 str/int/float("$now" 哨兵展开为 NOW())。按原串缓存。"""
    raw = str(getattr(UA.cfg, "reg_extra_cols", "") or "") if UA.cfg else ""
    if _REG_RT["extra_raw"] == raw:
        return _REG_RT["extra"]
    out: Optional[Dict[str, Any]] = {}
    s = raw.strip()
    if s:
        try:
            data = json.loads(s)
            if not isinstance(data, dict):
                raise ValueError("须为 JSON 对象")
            for k, v in data.items():
                if not _EXTRA_COL_RE.match(str(k)) or str(k).lower() in _BASE_COLS:
                    raise ValueError(f"非法列名 {k!r}")
                if not isinstance(v, (str, int, float)):
                    raise ValueError(f"列 {k!r} 取值须为字符串或数值")
                out[str(k)] = v
        except Exception as e:        # noqa: BLE001
            print(f"[注册] ⚠️ REG_EXTRA_COLS 解析失败({e})—— 注册 fail-closed。")
            out = None
    _REG_RT["extra_raw"], _REG_RT["extra"] = raw, out
    return out


# ── R1 限流(Redis INCR+EXPIRE;抖动退化进程内计数 —— 绝不放开) ────────────────
async def _reg_incr(key: str, win_s: int) -> Tuple[int, int]:
    """窗口计数 +1。→ (当前计数, 剩余窗口秒)。5.2.0:改走与登录共用的原子原语
    _win_incr(Lua 一步 INCR + 补 TTL)—— 旧写法 EXPIRE 抖一次即留下永久键。"""
    return await _win_incr(key, win_s, UA.mem_reg)


async def _reg_decr(key: str) -> None:
    """窗口计数 -1(退还,不小于 0;不动 TTL)。

    用于「真人正常失败」的配额退还 —— 目前只有 `name_taken`(用户名被占)。
    重名是真人最常见的正常探索,若与恶意尝试同等计入 R1 主配额,
    试几个名字就被锁一小时,且会推高自适应难度让 PoW 越算越久(4.0.0 线上反馈)。
    退还后改由**独立且宽松**的重名计数器封顶(仍防用户名枚举,见 _NT_HOURLY)。
    5.2.0:键已过期时不再凭空造出无 TTL 的键(见 _win_decr)。
    """
    await _win_decr(key, UA.mem_reg)


async def _reg_peek(key: str) -> int:
    return await _win_peek(key, UA.mem_reg)


async def _audit_once(bucket: str, cls: str, win_s: int = 3600) -> bool:
    """审计限幅(R1):同桶同类失败每窗口至多落一行,防审计表被打成写放大。"""
    n, _ = await _reg_incr(f"guantai:reg:al:{cls}:{bucket}", win_s)
    return n == 1


async def _log_reg(uid: int, name: str, ip: str, ua: str, fp: str,
                   invite_id: int, ok: int, reason: str) -> None:
    """注册审计写入。**四个文本字段必须走 gbk_text()**,不能用裸切片。

    4.0.6 修补(实地复现,非推断):本函数原先传 `str(x)[:n]` 裸串,而连接字符集是
    gbk —— 只要任一字段含 gbk 表示不了的字符(emoji / 韩文 / 越南文 / 土耳其文 /
    CJK 扩展区…),pymysql 在把整条 SQL 编码上线时抛 UnicodeEncodeError;`_q` 只对
    **连接层**异常重试,该异常原样上抛,再被本函数的 suppress 吃掉 —— **整行审计
    静默消失,且无任何日志**。

    危害不止于用户名:`ua` 是**客户端完全可控**的 User-Agent 原串,于是
    `User-Agent: 😀` 就能让该来源的**全部失败注册**在「注」视图的注册流水里查无此事,
    R7 的同源聚类高亮随之失明 —— 这正是运营用来发现批量注册的那块面板。
    成功路径因走 `_register_tx`(本就用 gbk_text)不受影响,故缺陷只吞失败样本,
    恰好是最该留痕的那一半。

    **本缺陷并非新发现**:本文件「字符集安全化(4.2.9)」段落早已把规矩写死,并**明确
    点名**过 `_log_login/_log_reg ⇒ 被 suppress 吞掉 ⇒ 审计行静默丢失(攻击者用 emoji
    User-Agent 即可让自己的登录尝试不留痕)`。当年那轮清扫**只修了 `_log_login`,
    漏了本函数** —— 4.0.6 补上。改本函数前请先回读那段口径。
    4.0.6 把中文用户名改判为 name_invalid 后,失败样本量级显著上升,本修补是前置条件。
    """
    if not UA.schema_ok:
        return
    with contextlib.suppress(Exception):
        await _q("INSERT INTO guantai_reg_log (user_id, user_name, ip, ua, fp, "
                 "invite_id, ok, reason, created_at) VALUES "
                 "(%s,%s,%s,%s,%s,%s,%s,%s,NOW())",
                 (int(uid or 0), gbk_text(name, 50), gbk_text(ip, 45),
                  gbk_text(ua, 200), gbk_text(fp, 16), int(invite_id or 0),
                  int(ok), gbk_text(reason, 30)))


# ── R2:挑战签发 / 单次核销 / PoW 校验(自适应难度) ────────────────────────────
def _clean_fp(v: Any) -> str:
    s = str(v or "").strip().lower()
    return s if _FP_RE.match(s) else ""


async def _reg_bits(ip: str, fp: str) -> int:
    """当前难度 = 基础位 + 阶梯(同 /24 高频 / 全局水位 / 同指纹超限),硬顶 25。
    只升不降 —— 随各窗口计数自然滑落。ip 传空 = 只看全局水位(管理台展示用)。"""
    cfg = UA.cfg
    bits = max(_REG_BITS_MIN, min(_REG_BITS_CAP,
                                  int(getattr(cfg, "reg_pow_bits", 17))))
    if ip:
        n24 = await _reg_peek(f"guantai:reg:d24:{_net24(ip)}")
        if n24 >= 6:
            bits += 4
        elif n24 >= 3:
            bits += 2
    hk = f"guantai:reg:g:h:{time.strftime('%Y%m%d%H')}"
    gh = await _reg_peek(hk)
    lim = max(1, int(getattr(cfg, "reg_global_hourly", 30)))
    if gh >= 0.7 * lim:
        bits += 2
    if fp:
        nfp = await _reg_peek(f"guantai:reg:fp:{fp}")
        if nfp >= 3:                  # R8:同指纹超限只升难度,绝不参与拒绝
            bits += 4
    return min(bits, _REG_BITS_CAP)


async def reg_challenge(ip: str, fp: str) -> Tuple[int, Dict[str, Any]]:
    """GET /api/auth/register/challenge 主体。→ (HTTP 状态, 响应体)。"""
    eff, br = await reg_state()
    if eff == "off":
        if reg_mode_configured() != "off" and str(br.get("mode")) == "off":
            return 403, {"ok": False, "error": "register_closed",
                         "message": "注册暂时关闭,请稍后再试"}
        return 503, {"ok": False, "error": "register_disabled",
                     "message": "本部署未开放注册"}
    if UA.redis is None:
        return 503, {"ok": False, "error": "register_unavailable",
                     "message": "注册暂时不可用,请稍后重试"}
    bucket = _ip_bucket(ip)
    n, ttl = await _reg_incr(f"guantai:reg:chal:ip:{bucket}", 600)
    if n > int(getattr(UA.cfg, "reg_chal_ip_10m", 10)):
        return 429, {"ok": False, "error": "throttled", "retryAfter": ttl,
                     "message": "操作过于频繁,请稍后再试"}
    fp = _clean_fp(fp)
    bits = await _reg_bits(ip, fp)
    cid = secrets.token_hex(16)
    salt = secrets.token_hex(16)
    chal_ttl = max(60, int(getattr(UA.cfg, "reg_chal_ttl_s", 600)))
    doc = {"s": salt, "b": bits, "t": time.time(), "ip": bucket}
    try:
        await UA.redis.set(K_REG_CHAL.format(cid=cid), json.dumps(doc), ex=chal_ttl)
    except Exception:                 # noqa: BLE001 —— fail-closed(与明细读的 fail-open 刻意相反)
        return 503, {"ok": False, "error": "register_unavailable",
                     "message": "注册暂时不可用,请稍后重试"}
    out: Dict[str, Any] = {"ok": True, "challengeId": cid, "salt": salt,
                           "bits": bits, "ttl": chal_ttl,
                           "minFillS": max(0, int(getattr(UA.cfg, "reg_min_fill_s", 3))),
                           "mode": eff}
    prov = _cap_conf("reg")["provider"]              # 5.2.0:尊重「注册时也要」开关
    if prov in ("tencent", "geetest", "turnstile"):
        out["captcha"] = {"provider": prov,
                          "appId": str(getattr(UA.cfg, "reg_captcha_id", "") or "")}
    return 200, out


async def _chal_take(cid: str, fmt: str = K_REG_CHAL) -> Optional[Dict[str, Any]]:
    """单次核销(取即删,防重放)。→ 挑战文档 | None(不存在/已用/过期)。
    Redis 异常上抛,调用方回 503。

    原子性三级降级:① Lua EVAL(全版本 Redis 原子)→ ② GETDEL 命令(Redis
    ≥6.2)→ ③ GET+DEL 两步。①② 不可用只发生在**禁用脚本的托管 Redis** 或测试
    替身上;此时 ③ 仍能保证「同一 cid 至多被一个请求消费掉」的实际效果(DEL
    紧随 GET,窗口以微秒计),且注册路径另有 R1 限流与事务内唯一键双闸兜底 ——
    比整条注册路径因缺 EVAL 而全灭要正确得多。"""
    if not _CID_RE.match(str(cid or "")):
        return None
    key = fmt.format(cid=cid)
    raw = ""
    mode = _REG_RT.get("getdel")          # None=未探测 / 'lua' / 'getdel' / 'plain'
    if mode in (None, "lua"):
        try:
            raw = _rs(await UA.redis.eval(_LUA_GETDEL, 1, key))
            _REG_RT["getdel"] = "lua"
            return _chal_parse(raw)
        except Exception as e:            # noqa: BLE001
            if _REG_RT.get("getdel") == "lua":
                raise                     # 曾经可用却突然失败:真故障,上抛 503
            if "unknown command" not in str(e).lower() \
                    and "not allowed" not in str(e).lower() \
                    and "script" not in str(e).lower():
                raise
            print("[注册] Redis 不支持 EVAL —— 挑战核销降级为 GETDEL/GET+DEL(见 _chal_take 注)")
            mode = None
    if mode in (None, "getdel"):
        try:
            raw = _rs(await UA.redis.getdel(key))
            _REG_RT["getdel"] = "getdel"
            return _chal_parse(raw)
        except Exception as e:            # noqa: BLE001
            if _REG_RT.get("getdel") == "getdel":
                raise
            if "unknown command" not in str(e).lower():
                raise
            mode = None
    _REG_RT["getdel"] = "plain"
    raw = _rs(await UA.redis.get(key))
    await UA.redis.delete(key)
    return _chal_parse(raw)


def _chal_parse(raw: str) -> Optional[Dict[str, Any]]:
    if not raw:
        return None
    with contextlib.suppress(Exception):
        doc = json.loads(raw)
        if isinstance(doc, dict):
            return doc
    return None


def _lead_zero_bits(digest: bytes) -> int:
    n = 0
    for b in digest:
        if b == 0:
            n += 8
            continue
        for k in range(7, -1, -1):
            if b >> k:
                return n + (7 - k)
        return n
    return n


def reg_pow_check(salt: str, nonce: str, bits: int) -> bool:
    """R2 ⊕:prefix=powAnswer(salt)(执行证明变换,C4)串接 nonce 做 SHA-256,
    前导零位 ≥ bits 即通过。服务端一次哈希 O(1),不对称性正确。"""
    if not _NONCE_RE.match(str(nonce or "")):
        return False
    prefix = _reg_pow_transform(str(salt or ""))
    digest = hashlib.sha256(f"{prefix}:{nonce}".encode("utf-8")).digest()
    return _lead_zero_bits(digest) >= int(bits)


# ── R3:人机验证(可插拔;校验异常一律 fail-closed) ────────────────────────────
def _tc3_auth(secret_id: str, secret_key: str, host: str, service: str,
              payload: bytes, ts: int) -> str:
    """腾讯云 TC3-HMAC-SHA256 签名(标准算法,hashlib/hmac 自足,零 SDK)。"""
    date = time.strftime("%Y-%m-%d", time.gmtime(ts))
    ct = "application/json; charset=utf-8"
    canonical = ("POST\n/\n\n"
                 f"content-type:{ct}\nhost:{host}\n\n"
                 "content-type;host\n"
                 + hashlib.sha256(payload).hexdigest())
    scope = f"{date}/{service}/tc3_request"
    sts = ("TC3-HMAC-SHA256\n" + str(ts) + "\n" + scope + "\n"
           + hashlib.sha256(canonical.encode()).hexdigest())
    k_date = hmac.new(("TC3" + secret_key).encode(), date.encode(),
                      hashlib.sha256).digest()
    k_srv = hmac.new(k_date, service.encode(), hashlib.sha256).digest()
    k_sign = hmac.new(k_srv, b"tc3_request", hashlib.sha256).digest()
    sig = hmac.new(k_sign, sts.encode(), hashlib.sha256).hexdigest()
    return (f"TC3-HMAC-SHA256 Credential={secret_id}/{scope}, "
            f"SignedHeaders=content-type;host, Signature={sig}")


_TURNSTILE_VERIFY_URL = "https://challenges.cloudflare.com/turnstile/v0/siteverify"
_GEETEST_VERIFY_URL = "https://gcaptcha4.geetest.com/validate"
_TENCENT_CAPTCHA_HOST = "captcha.tencentcloudapi.com"
_TENCENT_CAPTCHA_URL = f"https://{_TENCENT_CAPTCHA_HOST}/"   # 签名用 HOST,请求发往此 URL(测试可替换)
# 令牌长度上限:Turnstile 文档称令牌最长 2048 字符;腾讯云 / 极验的令牌是本站前端拼的小 JSON。
# 超长一律判「未通过」且**不打供应商** —— 否则畸形巨型令牌可让供应商回 4xx / 解析失败,
# 被误判成「暂不可用」,进而触发登录侧的全站降级(见 _cap_mark_down)。
_CAPTCHA_TOKEN_MAX = 4096
# Turnstile 的这几类错误码说明「是我方配置/对方服务的问题」,不是用户没过验证。
_TS_SERVER_ERRS = ("missing-input-secret", "invalid-input-secret", "internal-error")


async def _captcha_check(token: Any, ip: str, scope: str = "reg") -> Tuple[bool, str, str]:
    """→ (通过?, 错误码, 文案)。off=直接通过;凭据缺失/网络异常/密钥错 → captcha_unavailable;
    供应商判否 → captcha_failed。scope=reg(注册,fail-closed 503)| login(登录:不可用时由
    调用方降级为本站 PoW,见 _lg_admit)。

    5.2.0:① 登录共用本校验器,凭据经 _cap_conf(scope) 解析(登录项留空沿用注册项);
    ② Turnstile 核对 action(挂件渲染时标 login / register,防一种用途的令牌挪作他用;
    action 为空的旧前端令牌照旧放行);③ Turnstile 返回「密钥缺失/无效/内部错误」归为
    captcha_unavailable —— 旧版对用户报「人机验证未通过」,而那是运维配置错了。

    分类铁律(5.2.0 复查):只有**服务端侧**故障(凭据缺失 / 密钥错 / 网络超时 / 供应商内部错误)
    才判「暂不可用」—— 它会触发登录侧的全站降级;一切可由客户端输入引发的异常(超长或畸形令牌、
    参数类错误、极验 status=error 这类可能由伪造字段引起的返回)一律判「未通过」。否则攻击者
    可故意构造畸形令牌把验证码降级掉,只剩本站 PoW。"""
    conf = _cap_conf(scope)
    prov = conf["provider"]
    if prov == "off":
        return True, "", ""
    cid, key = conf["id"], conf["key"]
    if not cid or not key:            # 凭据先于令牌:配置错是运维问题,不该报成「用户没过验证」
        return False, "captcha_unavailable", "人机验证暂不可用,请稍后重试"
    tok = str(token or "").strip()
    if not tok:
        return False, "captcha_failed", "请先完成人机验证"
    if len(tok) > _CAPTCHA_TOKEN_MAX:
        return False, "captcha_failed", "人机验证未通过,请重试"
    # 5.3.0:scope=admin(管理台登录)。三种用途各标各的 action,令牌互不通用。
    tag = {"login": "[登录]", "admin": "[管理台]"}.get(scope, "[注册]")
    want_action = {"login": "login", "admin": "admin"}.get(scope, "register")
    try:
        import aiohttp                        # 项目硬依赖;懒加载保持本模块轻量
        timeout = aiohttp.ClientTimeout(total=6)
        async with aiohttp.ClientSession(timeout=timeout) as sess:
            if prov == "turnstile":
                async with sess.post(_TURNSTILE_VERIFY_URL,
                                     data={"secret": key, "response": tok,
                                           "remoteip": ip or ""}) as r:
                    data = await r.json(content_type=None)
                if not (data or {}).get("success"):
                    codes = [str(x) for x in ((data or {}).get("error-codes") or [])]
                    if any(x in _TS_SERVER_ERRS for x in codes):
                        print(f"{tag} Turnstile 校验返回 {codes} —— 请检查 secret 配置")
                        return False, "captcha_unavailable", "人机验证暂不可用,请稍后重试"
                    return False, "captcha_failed", "人机验证未通过,请重试"
                act = str((data or {}).get("action") or "")
                # action 为空的旧前端令牌对注册 / 登录照旧放行(兼容);管理台是新接入、没有
                # 旧前端可言 —— 必须恰为 admin,不带 action 的令牌(观测台页面上随手可得)不认。
                if act != want_action and (act or scope == "admin"):
                    return False, "captcha_failed", "人机验证未通过,请重试"
                return True, "", ""
            if prov == "geetest":             # v4:validate 二次校验
                try:
                    t = json.loads(tok)
                except Exception:             # noqa: BLE001
                    return False, "captcha_failed", "人机验证未通过,请重试"
                lot = str(t.get("lot_number") or "")
                sign = hmac.new(key.encode(), lot.encode(),
                                hashlib.sha256).hexdigest()
                async with sess.post(
                        f"{_GEETEST_VERIFY_URL}?captcha_id={cid}",
                        data={"lot_number": lot,
                              "captcha_output": str(t.get("captcha_output") or ""),
                              "pass_token": str(t.get("pass_token") or ""),
                              "gen_time": str(t.get("gen_time") or ""),
                              "sign_token": sign}) as r:
                    data = await r.json(content_type=None)
                return ((True, "", "") if str(data.get("result")) == "success"
                        else (False, "captcha_failed", "人机验证未通过,请重试"))
            # tencent:DescribeCaptchaResult(TC3 签名;需另配云 API SecretId/Key)
            sid, skey = conf["secret_id"], conf["secret_key"]
            if not sid or not skey:
                return False, "captcha_unavailable", "人机验证暂不可用,请稍后重试"
            try:
                t = json.loads(tok)
            except Exception:                 # noqa: BLE001
                return False, "captcha_failed", "人机验证未通过,请重试"
            host = _TENCENT_CAPTCHA_HOST
            ts = int(time.time())
            payload = json.dumps({
                "CaptchaType": 9, "Ticket": str(t.get("ticket") or ""),
                "Randstr": str(t.get("randstr") or ""), "UserIp": ip or "0.0.0.0",
                "CaptchaAppId": int(cid), "AppSecretKey": key,
            }, ensure_ascii=False).encode("utf-8")
            headers = {"Content-Type": "application/json; charset=utf-8",
                       "Host": host, "X-TC-Action": "DescribeCaptchaResult",
                       "X-TC-Version": "2019-07-22", "X-TC-Timestamp": str(ts),
                       "Authorization": _tc3_auth(sid, skey, host, "captcha",
                                                  payload, ts)}
            async with sess.post(_TENCENT_CAPTCHA_URL, data=payload,
                                 headers=headers) as r:
                data = await r.json(content_type=None)
            resp = (data or {}).get("Response") or {}
            if resp.get("Error"):
                code = str((resp.get("Error") or {}).get("Code") or "")
                # 参数类错误可能由客户端提交的票据引起 → 判「未通过」(不触发登录侧降级);
                # 鉴权 / 内部 / 限频等才是服务端侧故障 → 「暂不可用」
                if code.startswith("InvalidParameter"):
                    return False, "captcha_failed", "人机验证未通过,请重试"
                print(f"{tag} 腾讯云验证码 API 异常: {resp['Error']}")
                return False, "captcha_unavailable", "人机验证暂不可用,请稍后重试"
            return ((True, "", "") if int(resp.get("CaptchaCode") or 0) == 1
                    else (False, "captcha_failed", "人机验证未通过,请重试"))
    except Exception as e:            # noqa: BLE001 —— 网络/解析异常一律 fail-closed
        print(f"{tag} 人机验证校验异常({prov}): {e!r}")
        return False, "captcha_unavailable", "人机验证暂不可用,请稍后重试"


# ── 邀请码 DAO ────────────────────────────────────────────────────────────────
def gen_invite_code() -> str:
    return "".join(secrets.choice(_CROCK) for _ in range(16))


def norm_invite_code(s: Any) -> str:
    """查验归一:去分隔、大写、O→0 / I→1 / L→1 手滑宽恕;非法 → 空串。"""
    up = re.sub(r"[^0-9A-Za-z]", "", str(s or "")).translate(_CROCK_FIX).upper()
    return up if len(up) == 16 and all(c in _CROCK for c in up) else ""


def fmt_invite_code(c: str) -> str:
    c = str(c or "")
    return "-".join(c[i:i + 4] for i in range(0, len(c), 4)) if len(c) == 16 else c


async def invite_lookup(code: str) -> Optional[Dict[str, Any]]:
    # gbk 闸(4.2.9 审计补):code 由**未登录用户**在注册页自由输入,而本表是
    # CHARSET=gbk —— 含 emoji 的码会在编码 SQL 时抛 UnicodeEncodeError,一路穿到
    # FastAPI ⇒ 注册端点 500(真库实测)。任何人发一个表情符号邀请码即可触发。
    # 口径与 orders_page 对 user_name 的既有裁决同源:表示不了的 ≡ 查无此码。
    if not gbk_ok(code):
        return None
    return await _q("SELECT id, code, days_granted, quota, used_count, expires_at, "
                    "disabled, (expires_at IS NOT NULL AND expires_at <= NOW()) AS expired "
                    "FROM guantai_invite_code WHERE code=%s", (code,), fetch="one")


async def invites_generate(count: int, quota: int, days: int,
                           expires_days: int, note: str) -> list:
    out = []
    for _ in range(max(1, min(int(count), 200))):
        for _try in range(3):         # uk_code 撞车(概率≈0)重掷
            code = gen_invite_code()
            try:
                await _q("INSERT INTO guantai_invite_code (code, days_granted, quota, "
                         "used_count, expires_at, disabled, note, created_at) VALUES "
                         "(%s,%s,%s,0," +
                         ("DATE_ADD(NOW(), INTERVAL %s DAY)" if expires_days > 0
                          else "NULL") +
                         ",0,%s,NOW())",
                         ((code, int(days), max(1, int(quota)), int(expires_days),
                           gbk_text(note, 100)) if expires_days > 0 else
                          (code, int(days), max(1, int(quota)),
                           gbk_text(note, 100))))
                out.append(code)
                break
            except Exception as e:    # noqa: BLE001
                if getattr(e, "args", None) and str(e.args[0]) == "1062":
                    continue
                raise
        else:
            # 4.0.5:三连撞唯一键(16 位 Crockford,概率≈0,真发生即随机源异常)
            # 此前静默 continue 外层 → 少发却回 200,管理员数不到还以为自己眼花。
            # 诚实失败:上抛 → 端点 503 带 hint,已插入的部分照常留在库里可见。
            raise RuntimeError(
                f"invite code collided 3x on uk_code (generated {len(out)}/{count})")
    return out


@heavy_reads
async def invites_page(page: int, size: int, show_all: bool) -> Dict[str, Any]:
    size = max(1, min(int(size or 50), 200))
    page = max(1, int(page or 1))
    where = "" if show_all else ("WHERE disabled=0 AND used_count < quota "
                                 "AND (expires_at IS NULL OR expires_at > NOW()) ")
    total_row = await _q(f"SELECT COUNT(*) AS n FROM guantai_invite_code {where}",
                         (), fetch="one")
    rows = await _q(f"SELECT id, code, days_granted, quota, used_count, expires_at, "
                    f"disabled, note, created_at, "
                    f"(expires_at IS NOT NULL AND expires_at <= NOW()) AS expired "
                    f"FROM guantai_invite_code {where}ORDER BY id DESC "
                    f"LIMIT %s OFFSET %s", (size, (page - 1) * size),
                    fetch="all") or []
    for r in rows:
        r["code_disp"] = fmt_invite_code(str(r.get("code") or ""))
        for k in ("expires_at", "created_at"):
            r[k] = _dt_iso(r.get(k)) if r.get(k) is not None else ""
    return {"total": int((total_row or {}).get("n") or 0), "page": page,
            "size": size, "items": rows}


async def invite_set_disabled(iid: int, disabled: bool) -> bool:
    n = await _q("UPDATE guantai_invite_code SET disabled=%s WHERE id=%s",
                 (1 if disabled else 0, int(iid)))
    return bool(n)


# ── 观测台侧封禁 DAO(R7;不碰 tb_user 一个字节) ──────────────────────────────
async def blocks_set(uids, note: str, unblock: bool) -> int:
    ids = sorted({int(u) for u in (uids or [])
                  if str(u).strip().lstrip("-").isdigit() and int(u) > 0})
    if not ids:
        return 0
    if unblock:
        ph = ",".join(["%s"] * len(ids))
        return int(await _q(f"DELETE FROM guantai_user_block WHERE user_id IN ({ph})",
                            tuple(ids)) or 0)
    n = 0
    for uid in ids:
        await _q("INSERT INTO guantai_user_block (user_id, reason, note, created_at) "
                 "VALUES (%s,%s,%s,NOW()) ON DUPLICATE KEY UPDATE "
                 "note=VALUES(note), reason=VALUES(reason)",
                 (uid, "malicious_reg", gbk_text(note, 100)))
        n += 1
        UA.cache = {k: v for k, v in UA.cache.items()
                    if v.principal.user_id != uid}   # 本进程缓存即时失效(其余 ≤20s 复核)
    return n


async def blocks_list(limit: int = 500) -> Dict[str, Any]:
    """→ {total, items}(4.0.5:总数随行下发 —— 超出 limit 时管理台可如实标注
    「仅显示最近 N 条」,而不是静默丢行让人误以为封禁就这么多)。"""
    lim = max(1, min(int(limit), 2000))
    trow = await _q("SELECT COUNT(*) AS n FROM guantai_user_block", (), fetch="one")
    rows = await _q("SELECT user_id, reason, note, created_at FROM guantai_user_block "
                    "ORDER BY created_at DESC LIMIT %s", (lim,), fetch="all") or []
    names = await user_names([r["user_id"] for r in rows])
    for r in rows:
        r["user_name"] = names.get(int(r["user_id"]), "")
        r["created_at"] = _dt_iso(r.get("created_at"))
    return {"total": int((trow or {}).get("n") or 0), "items": rows}


# ── R6 熔断评估(成功后)与管理台统计 ──────────────────────────────────────────
async def _after_success_bookkeeping(eff_mode: str, ip: str) -> None:
    bucket = _ip_bucket(ip)
    await _reg_incr(f"guantai:reg:okd:ip:{bucket}", 86400)
    hk = f"guantai:reg:g:h:{time.strftime('%Y%m%d%H')}"
    dk = f"guantai:reg:g:d:{time.strftime('%Y%m%d')}"
    nh, _ = await _reg_incr(hk, 7200)
    nd, _ = await _reg_incr(dk, 172800)
    cfg = UA.cfg
    daily_lim = int(getattr(cfg, "reg_global_daily_invite", 500)
                    if eff_mode == "invite"
                    else getattr(cfg, "reg_global_daily", 200))
    # 阈值语义:**达到即关闸**(而非超过才关)—— 这样「每天新增行数的硬上界」
    # 恰等于阈值本身(nd>lim 会放过 lim+1 个,与 §3「有硬上界」的承诺差一格)。
    if nd >= daily_lim:
        await breaker_set("off", f"日成功注册达到上限 {nd}/{daily_lim}")
        await _log_reg(0, "", "", "", "", 0, 0, "cb_off")
        print(f"[注册] 🔴 熔断:日成功注册 {nd} 达上限 {daily_lim} —— 已自动关闸(off);"
              f"恢复须管理台「注」视图显式点击。")
    elif eff_mode == "open" and nh >= int(getattr(cfg, "reg_global_hourly", 30)):
        await breaker_set("invite", f"小时成功注册达到上限 {nh}/"
                                    f"{getattr(cfg, 'reg_global_hourly', 30)}")
        await _log_reg(0, "", "", "", "", 0, 0, "cb_invite")
        print(f"[注册] 🟡 熔断:小时成功注册 {nh} 达上限 —— open 已自动降档 invite;"
              f"恢复须管理台显式点击。")


@heavy_reads
async def reg_stats() -> Dict[str, Any]:
    """管理台「注」视图数据面:模式/熔断/今日与 7 日曲线/难度水位/邀请码概况。"""
    eff, br = await reg_state()
    out: Dict[str, Any] = {
        "modeConfigured": reg_mode_configured(),
        "modeEffective": eff, "breaker": br,
        "passShape": _reg_shape(),
        "pow": {"base": int(getattr(UA.cfg, "reg_pow_bits", 17)),
                "current": await _reg_bits("", "")},
        "thresholds": {
            "ipHourly": int(getattr(UA.cfg, "reg_ip_hourly", 5)),
            "ipDaily": int(getattr(UA.cfg, "reg_ip_daily", 10)),
            "ipOkDaily": int(getattr(UA.cfg, "reg_ip_ok_daily", 2)),
            "globalHourly": int(getattr(UA.cfg, "reg_global_hourly", 30)),
            "globalDaily": int(getattr(UA.cfg, "reg_global_daily", 200)),
            "globalDailyInvite": int(getattr(UA.cfg, "reg_global_daily_invite", 500)),
        },
        "today": {"ok": 0, "fail": 0}, "days": [], "invites": {},
    }
    with contextlib.suppress(Exception):
        t = await _q("SELECT SUM(ok=1) AS okn, SUM(ok=0) AS failn, CURDATE() AS today "
                     "FROM guantai_reg_log WHERE created_at >= CURDATE()",
                     (), fetch="one") or {}
        out["today"] = {"ok": int(t.get("okn") or 0), "fail": int(t.get("failn") or 0)}
        rows = await _q("SELECT DATE(created_at) AS d, SUM(ok=1) AS okn, "
                        "SUM(ok=0) AS failn FROM guantai_reg_log "
                        "WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) "
                        "GROUP BY DATE(created_at) ORDER BY d", (), fetch="all") or []
        # 4.0.5:7 日曲线**零填充** —— 无注册的日子此前直接缺位,前端「近 7 日」
        # 呈现跳日的迷你图(第六轮复查实证)。锚点取 SQL 侧 CURDATE()(与上面
        # 分组查询同一时区权威,不引入 Python 进程时区这个第二个「今天」);
        # 锚点异常拿不到时维持旧行为(只列有数据的日子),绝不空手造日期。
        got = {str(r["d"]): (int(r.get("okn") or 0), int(r.get("failn") or 0))
               for r in rows}
        anchor = t.get("today")
        if isinstance(anchor, datetime.datetime):
            anchor = anchor.date()
        if isinstance(anchor, datetime.date):
            seq = [anchor - datetime.timedelta(days=i) for i in range(6, -1, -1)]
            out["days"] = [{"d": str(d), "ok": got.get(str(d), (0, 0))[0],
                            "fail": got.get(str(d), (0, 0))[1]} for d in seq]
        else:
            out["days"] = [{"d": str(r["d"]), "ok": int(r.get("okn") or 0),
                            "fail": int(r.get("failn") or 0)} for r in rows]
        inv = await _q("SELECT COUNT(*) AS total, SUM(disabled=0 AND used_count<quota "
                       "AND (expires_at IS NULL OR expires_at>NOW())) AS active, "
                       "SUM(used_count) AS used FROM guantai_invite_code",
                       (), fetch="one") or {}
        out["invites"] = {"total": int(inv.get("total") or 0),
                          "active": int(inv.get("active") or 0),
                          "used": int(inv.get("used") or 0)}
    return out


@heavy_reads
async def reg_log_page(page: int, size: int, q_ip: str = "", q_name: str = "",
                       q_ok: str = "", q_reason: str = "") -> Dict[str, Any]:
    size = max(1, min(int(size or 50), 200))
    page = max(1, int(page or 1))
    cond, args = [], []
    # 4.0.6 补漏:本函数是 userauth.py + jfvip.py 两份文件里**唯一**漏掉筛选侧编码闸
    # 的分页器(jfvip 的 cards_page / grants_page / orders_page 三处早已就位)。
    # 口径见本文件「字符集安全化」段:筛选侧不可表示 ⇒ 该条件命中零行,**绝不**换 '?'
    # (换了会静默去查一个不同的串,屏幕显示「没有记录」,人只会以为它不存在)。
    # 不加这道闸时,UnicodeEncodeError 在编码 SQL 时就抛、语句根本没发出去,一路穿到
    # /reg/log 端点被兜成 503「用户库不可用」—— 库其实好好的,这个诊断会把运维引向
    # 假故障。真库实测复现:管理台「注」视图的「按用户名精确筛」里输入含 emoji 的名字。
    # 与写入侧自洽:_log_reg 已把不可表示字符换成 '?',库里本就不可能存在含 emoji 的值。
    if ((q_ip and not gbk_ok(q_ip)) or (q_name and not gbk_ok(q_name))
            or (q_reason and not gbk_ok(q_reason))):
        cond.append("1=0")
        q_ip = q_name = q_reason = ""
    if q_ip:
        cond.append("ip=%s")
        args.append(str(q_ip)[:45])
    if q_name:
        cond.append("user_name=%s")
        args.append(str(q_name)[:50])
    if q_ok in ("0", "1"):
        cond.append("ok=%s")
        args.append(int(q_ok))
    # 4.0.7:按具体原因等值筛(reason 列 VARCHAR(30),规范码全 ASCII;编码闸
    # 同罩只为与本函数「筛选侧不可表示 ⇒ 命中零行」的既有口径逐字一致)。
    # 前端把「结果」下拉升级成 全部/仅成功/仅失败/具体原因 一体式 —— 运维排查
    # 「今天为什么一堆 throttled」不必再翻页肉眼数。
    if q_reason:
        cond.append("reason=%s")
        args.append(str(q_reason)[:30])
    where = ("WHERE " + " AND ".join(cond) + " ") if cond else ""
    total = await _q(f"SELECT COUNT(*) AS n FROM guantai_reg_log {where}",
                     tuple(args), fetch="one")
    rows = await _q(f"SELECT id, user_id, user_name, ip, ua, fp, invite_id, ok, "
                    f"reason, created_at FROM guantai_reg_log {where}"
                    f"ORDER BY id DESC LIMIT %s OFFSET %s",
                    tuple(args) + (size, (page - 1) * size), fetch="all") or []
    for r in rows:
        r["created_at"] = _dt_iso(r.get("created_at"))
    return {"total": int((total or {}).get("n") or 0), "page": page,
            "size": size, "items": rows}


# ── 注册事务(单连接;guantai_* 与 tb_user 同库 → 原子性天然成立,C6) ───────────
async def _register_tx(name: str, stored_pw: str, days: int,
                       invite_code: Optional[str], extra: Dict[str, Any],
                       ip: str, ua: str, fp: str) -> Tuple[str, Dict[str, Any]]:
    """BEGIN → ①精确重名 SELECT → ②占坑邀请码(条件 UPDATE,rowcount=1 才算)
    → ③INSERT tb_user(全项目唯一一条;撞唯一键 1062=重名)→ ④INSERT 注册审计
    → COMMIT。任一步失败整体 ROLLBACK:占坑自动回吐,零补偿逻辑。
    → (错误码|'' , {uid, dueIso, inviteId, days});基础设施异常原样上抛(调用方 503)。"""
    pool = await _ensure_pool()
    if pool is None:
        raise ConnectionError(UA.init_error or "userdb pool unavailable")
    c = UA.cfg
    conn = await pool.acquire()
    try:
        await conn.begin()
        try:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                await cur.execute(f"SELECT id FROM `{c.user_table}` WHERE user_name=%s",
                                  (name,))
                if await cur.fetchone():
                    await conn.rollback()
                    return "name_taken", {}
                invite_id, grant = 0, int(days)
                if invite_code:
                    await cur.execute(
                        "UPDATE guantai_invite_code SET used_count = used_count + 1 "
                        "WHERE code=%s AND disabled=0 AND used_count < quota "
                        "AND (expires_at IS NULL OR expires_at > NOW())",
                        (invite_code,))
                    if cur.rowcount != 1:
                        await conn.rollback()
                        # 4.0.2:占坑失败后在事务外补一次诊断读(池 autocommit=True,
                        # rollback 后本条 SELECT 自提交、不留悬挂事务),把「预检通过
                        # → 事务瞬间态变」竞态窗口内的真实死因说准 —— 此前一律回
                        # 「已用尽」,窗口内刚被禁用/过期/删除的码会拿到误导文案。
                        # 仅失败路径付一次 O(1) 唯一索引读;诊断本身异常则回落旧语义。
                        reason = "invite_exhausted"
                        with contextlib.suppress(Exception):
                            await cur.execute(
                                "SELECT disabled, (expires_at IS NOT NULL AND "
                                "expires_at <= NOW()) AS expired "
                                "FROM guantai_invite_code WHERE code=%s",
                                (invite_code,))
                            drow = await cur.fetchone()
                            if drow is None or int(drow.get("disabled") or 0):
                                reason = "invite_invalid"
                            elif int(drow.get("expired") or 0):
                                reason = "invite_expired"
                        return reason, {}
                    await cur.execute("SELECT id, days_granted FROM guantai_invite_code "
                                      "WHERE code=%s", (invite_code,))
                    irow = await cur.fetchone() or {}
                    invite_id = int(irow.get("id") or 0)
                    grant = int(irow.get("days_granted") or 0)
                cols = ["user_name", "pass_word", "due_time", "is_off"]
                exprs = ["%s", "%s", "DATE_ADD(NOW(), INTERVAL %s DAY)", "%s"]
                args: list = [name, stored_pw, int(grant), "0"]
                for k, v in (extra or {}).items():
                    cols.append(k)
                    if v == "$now":
                        exprs.append("NOW()")
                    else:
                        exprs.append("%s")
                        args.append(v)
                sql = (f"INSERT INTO `{c.user_table}` "
                       f"({', '.join('`' + x + '`' for x in cols)}) "
                       f"VALUES ({', '.join(exprs)})")
                try:
                    await cur.execute(sql, tuple(args))   # ← 全项目唯一 tb_user INSERT
                except aiomysql.IntegrityError as e:
                    await conn.rollback()
                    if e.args and str(e.args[0]) == "1062":
                        return "name_taken", {}
                    raise
                uid = int(cur.lastrowid or 0)
                if not uid:           # id 非 AUTO_INCREMENT 的兜底(按名回查)
                    await cur.execute(f"SELECT id FROM `{c.user_table}` "
                                      f"WHERE user_name=%s", (name,))
                    r = await cur.fetchone()
                    uid = int((r or {}).get("id") or 0)
                await cur.execute(f"SELECT due_time FROM `{c.user_table}` WHERE id=%s",
                                  (uid,))
                drow = await cur.fetchone() or {}
                await cur.execute(
                    "INSERT INTO guantai_reg_log (user_id, user_name, ip, ua, fp, "
                    "invite_id, ok, reason, created_at) VALUES "
                    "(%s,%s,%s,%s,%s,%s,1,'ok',NOW())",
                    (uid, gbk_text(name, 50), gbk_text(ip, 45),
                     gbk_text(ua, 200), gbk_text(fp, 16), invite_id))
            await conn.commit()
            return "", {"uid": uid, "dueIso": _dt_iso(drow.get("due_time")),
                        "inviteId": invite_id, "days": grant}
        except BaseException:
            with contextlib.suppress(Exception):
                await conn.rollback()
            raise
    finally:
        pool.release(conn)


# ── 注册主流程 ────────────────────────────────────────────────────────────────
async def register(body: Dict[str, Any], ip: str, ua: str
                   ) -> Tuple[int, Dict[str, Any], Optional[str]]:
    """POST /api/auth/register 主体。→ (HTTP 状态, 响应体, 会话令牌|None)。
    校验顺序:廉价 → 昂贵;每次失败都消耗当次已解 PoW 与 IP 配额(枚举被定价)。"""
    cfg = UA.cfg
    ip, ua = str(ip or "")[:45], str(ua or "")[:200]
    eff, br = await reg_state()
    if eff == "off":
        if reg_mode_configured() != "off" and str(br.get("mode")) == "off":
            return 403, {"ok": False, "error": "register_closed",
                         "message": "注册暂时关闭,请稍后再试"}, None
        return 503, {"ok": False, "error": "register_disabled",
                     "message": "本部署未开放注册"}, None
    if UA.redis is None:
        return 503, {"ok": False, "error": "register_unavailable",
                     "message": "注册暂时不可用,请稍后重试"}, None
    if not await _ensure_schema():
        return 503, {"ok": False, "error": "register_unavailable",
                     "message": "注册暂时不可用,请稍后重试"}, None
    extra = reg_extra_cols()
    if extra is None:                 # EXTRA_COLS 配错:fail-closed(启动已告警)
        return 503, {"ok": False, "error": "register_unavailable",
                     "message": "注册暂时不可用,请稍后重试"}, None

    bucket = _ip_bucket(ip)
    fp = _clean_fp(body.get("fp"))

    async def _name_taken(nm: str):
        """「用户名已被占」的统一出口:退还 R1 主配额与难度阶梯计数,改记独立的
        宽松重名计数器。重名是真人正常探索,不该与恶意尝试同价(4.0.0 线上反馈)。
        仍防枚举:独立计数器封顶 _NT_HOURLY,且本分支排在 PoW 校验之后(每次重名
        都已付过一次完整 PoW 成本)。"""
        await _reg_decr(f"guantai:reg:try:ip:{bucket}")
        await _reg_decr(f"guantai:reg:tryd:ip:{bucket}")
        await _reg_decr(f"guantai:reg:d24:{_net24(ip)}")     # 免得真人试几个名字就把难度顶上去
        await _reg_decr(f"guantai:reg:chal:ip:{bucket}")     # 挑战单次性:换个名字必须重取,不该为此付费
        n_nt, ttl_nt = await _reg_incr(f"guantai:reg:nt:ip:{bucket}", 3600)
        await _log_reg(0, nm, ip, ua, fp, 0, 0, "name_taken")
        if n_nt > _NT_HOURLY:                                 # 枚举封顶
            return 429, {"ok": False, "error": "throttled", "retryAfter": ttl_nt,
                         "message": "换名尝试过于频繁,请稍后再试"}, None
        return 400, {"ok": False, "error": "name_taken",
                     "message": "该用户名已被使用,请更换"}, None

    # R1:尝试计数(时/日双窗)—— 含一切失败;触限 429 + 限幅审计
    #     例外:name_taken 事后经 _name_taken() 退还(真人正常探索不该被重罚)
    n_h, ttl_h = await _reg_incr(f"guantai:reg:try:ip:{bucket}", 3600)
    n_d, ttl_d = await _reg_incr(f"guantai:reg:tryd:ip:{bucket}", 86400)
    await _reg_incr(f"guantai:reg:d24:{_net24(ip)}", 600)       # 难度阶梯输入
    if fp:
        await _reg_incr(f"guantai:reg:fp:{fp}", 600)            # R8:线索不判决
    if n_h > int(getattr(cfg, "reg_ip_hourly", 5)) \
            or n_d > int(getattr(cfg, "reg_ip_daily", 10)):
        retry = ttl_h if n_h > int(getattr(cfg, "reg_ip_hourly", 5)) else ttl_d
        if await _audit_once(bucket, "thr"):
            await _log_reg(0, "", ip, ua, fp, 0, 0, "throttled")
        return 429, {"ok": False, "error": "throttled", "retryAfter": retry,
                     "message": "操作过于频繁,请稍后再试"}, None

    # R4①:蜜罐 —— 有值即拒,但对外回通用失败(不教学)
    if str(body.get(_REG_HP_FIELD) or "").strip():
        await _log_reg(0, "", ip, ua, fp, 0, 0, "honeypot")
        return 400, {"ok": False, "error": "bad_request",
                     "message": "注册失败,请稍后重试"}, None

    shape = _reg_shape()
    name, err, msg = validate_reg_username(body.get("userName")
                                           or body.get("user_name"))
    if name is None:
        await _log_reg(0, str(body.get("userName") or "")[:50], ip, ua, fp, 0, 0, err)
        return 400, {"ok": False, "error": err, "message": msg}, None
    pw_ok, err, msg = validate_reg_password(body.get("password"), shape)
    if not pw_ok:
        await _log_reg(0, name, ip, ua, fp, 0, 0, err)
        return 400, {"ok": False, "error": err, "message": msg}, None

    # 同名尝试节流(钳单名爆破/占坑拉锯)
    n_name, ttl_n = await _reg_incr(f"guantai:reg:name:{_md5_16(name)}", 600)
    if n_name > int(getattr(cfg, "reg_name_10m", 3)):
        if await _audit_once(_md5_16(name), "thrn"):
            await _log_reg(0, name, ip, ua, fp, 0, 0, "throttled")
        return 429, {"ok": False, "error": "throttled", "retryAfter": ttl_n,
                     "message": "操作过于频繁,请稍后再试"}, None

    # invite:格式与状态预检(具体错误码;事务内占坑是最终闸)
    invite_code: Optional[str] = None
    if eff == "invite":
        invite_code = norm_invite_code(body.get("inviteCode") or body.get("invite"))
        if not str(body.get("inviteCode") or body.get("invite") or "").strip():
            await _log_reg(0, name, ip, ua, fp, 0, 0, "invite_required")
            return 400, {"ok": False, "error": "invite_required",
                         "message": "本站注册需要邀请码"}, None
        if not invite_code:
            await _log_reg(0, name, ip, ua, fp, 0, 0, "invite_invalid")
            return 400, {"ok": False, "error": "invite_invalid",
                         "message": "邀请码无效,请核对后重试"}, None

    # R2:挑战单次核销 + 最短填表时长 + PoW 校验(Redis 异常 → 503 fail-closed)
    try:
        chal = await _chal_take(str(body.get("challengeId") or ""))
    except Exception:                 # noqa: BLE001
        return 503, {"ok": False, "error": "register_unavailable",
                     "message": "注册暂时不可用,请稍后重试"}, None
    if chal is None:
        await _log_reg(0, name, ip, ua, fp, 0, 0, "challenge_expired")
        return 400, {"ok": False, "error": "challenge_expired",
                     "message": "安全校验已过期,请重试"}, None
    if str(chal.get("ip") or "") != bucket:
        await _log_reg(0, name, ip, ua, fp, 0, 0, "pow_failed")
        return 400, {"ok": False, "error": "pow_failed",
                     "message": "安全校验未通过,请重试"}, None
    min_fill = max(0, int(getattr(cfg, "reg_min_fill_s", 3)))
    if time.time() - float(chal.get("t") or 0) < min_fill:      # R4②:秒提交
        await _log_reg(0, name, ip, ua, fp, 0, 0, "too_fast")
        return 400, {"ok": False, "error": "bad_request",
                     "message": "注册失败,请稍后重试"}, None
    if not reg_pow_check(str(chal.get("s") or ""), str(body.get("nonce") or ""),
                         int(chal.get("b") or 0)):
        await _log_reg(0, name, ip, ua, fp, 0, 0, "pow_failed")
        return 400, {"ok": False, "error": "pow_failed",
                     "message": "安全校验未通过,请重试"}, None

    # R3:人机验证(默认关;开启后 fail-closed)
    cap_ok, cap_err, cap_msg = await _captcha_check(body.get("captchaToken"), ip)
    if not cap_ok:
        await _log_reg(0, name, ip, ua, fp, 0, 0, cap_err)
        return (503 if cap_err == "captcha_unavailable" else 400), \
            {"ok": False, "error": cap_err, "message": cap_msg}, None

    # 成功配额(每 IP 每日)
    if await _reg_peek(f"guantai:reg:okd:ip:{bucket}") \
            >= int(getattr(cfg, "reg_ip_ok_daily", 2)):
        if await _audit_once(bucket, "thro"):
            await _log_reg(0, name, ip, ua, fp, 0, 0, "throttled")
        return 429, {"ok": False, "error": "throttled", "retryAfter": 3600,
                     "message": "操作过于频繁,请稍后再试"}, None

    try:
        if not await _shape_storable(shape):
            return 503, {"ok": False, "error": "register_unavailable",
                         "message": "注册暂时不可用,请稍后重试"}, None
        # ASCII 大小写折叠查重(防 Admin 仿 admin;仅约束新增,不追溯存量)。
        # UPPER() 走不了 gbk_bin 索引 → 全表扫,但注册速率被 R1 钳死(≤5 次/时/IP、
        # 全局日顶),代价有界;含 ASCII 字母的名字才需要折叠。
        # 4.0.6 记账:字符集收窄为 [A-Za-z0-9] 后,本条件从「仅英文名命中」变成
        # 「除纯数字名外几乎必然命中」——全表扫的频次上升,但**上界没变**:R6 熔断把
        # 全局成功注册钳在 30/时,R1 把尝试钳在 5/时/IP,最坏也就每小时几十次全表扫。
        # 纯数字名(4.0.6 明确放行)不含 ASCII 字母,跳过折叠是**正确**的:UPPER() 对
        # 数字是恒等变换,折不折等价,精确 SELECT + 唯一键已是完备闸。
        if any(ch.isascii() and ch.isalpha() for ch in name):
            dup = await _q(f"SELECT 1 AS x FROM `{cfg.user_table}` "
                           f"WHERE UPPER(user_name)=UPPER(%s) LIMIT 1",
                           (name,), fetch="one")
            if dup:
                return await _name_taken(name)
        if invite_code:
            inv = await invite_lookup(invite_code)
            if inv is None:
                await _log_reg(0, name, ip, ua, fp, 0, 0, "invite_invalid")
                return 400, {"ok": False, "error": "invite_invalid",
                             "message": "邀请码无效,请核对后重试"}, None
            if int(inv.get("disabled") or 0):
                await _log_reg(0, name, ip, ua, fp, int(inv["id"]), 0, "invite_invalid")
                return 400, {"ok": False, "error": "invite_invalid",
                             "message": "邀请码无效,请核对后重试"}, None
            if int(inv.get("expired") or 0):
                await _log_reg(0, name, ip, ua, fp, int(inv["id"]), 0, "invite_expired")
                return 400, {"ok": False, "error": "invite_expired",
                             "message": "邀请码已过期"}, None
            if int(inv.get("used_count") or 0) >= int(inv.get("quota") or 0):
                await _log_reg(0, name, ip, ua, fp, int(inv["id"]), 0,
                               "invite_exhausted")
                return 400, {"ok": False, "error": "invite_exhausted",
                             "message": "邀请码已用尽"}, None

        # Redis 名义锁桥接并发窗口(恒开;唯一键存在时 1062 仍是最终闸,
        # 不存在时本锁 + 事务内精确 SELECT 即兜底,C8)
        lk = f"guantai:reg:lk:{_md5_16(name)}"
        locked = True
        try:
            locked = bool(await UA.redis.set(lk, "1", nx=True, ex=30))
        except Exception:             # noqa: BLE001 —— 锁失败放行到事务内双闸
            locked = True
        if not locked:
            return await _name_taken(name)
        try:
            stored = encode_reg_password(str(body.get("password") or ""), shape)
            days = 0 if eff == "invite" else max(0, int(getattr(cfg, "reg_trial_days", 0)))
            err, info = await _register_tx(name, stored, days, invite_code,
                                           extra, ip, ua, fp)
        finally:
            with contextlib.suppress(Exception):
                await UA.redis.delete(lk)
        if err:
            if err == "name_taken":       # 事务内 1062:同样按真人正常失败退还配额
                return await _name_taken(name)
            code_msg = {"invite_exhausted": "邀请码已用尽",
                        "invite_invalid": "邀请码无效,请核对后重试",
                        "invite_expired": "邀请码已过期"}
            await _log_reg(0, name, ip, ua, fp, 0, 0, err)
            return 400, {"ok": False, "error": err,
                         "message": code_msg.get(err, "注册失败,请稍后重试")}, None
    except Exception as e:            # noqa: BLE001 —— 用户库层异常
        print(f"[注册] 用户库操作失败: {e!r}")
        return 503, {"ok": False, "error": "register_unavailable",
                     "message": "注册暂时不可用,请稍后重试"}, None

    uid = int(info.get("uid") or 0)
    due_iso = str(info.get("dueIso") or "")
    grant = int(info.get("days") or 0)
    await _after_success_bookkeeping(eff, ip)
    print(f"[注册] ✓ 新用户 #{uid} {name!r} · 赠送 {grant} 天 · 模式 {eff}"
          f"{' · 邀请码 #' + str(info.get('inviteId')) if info.get('inviteId') else ''}")

    user = {"id": uid, "userName": name, "dueTime": due_iso,
            "dueDays": _due_days(due_iso)}
    auto = grant > 0                  # D6:赠送 >0 → 注册即登录;=0 → 成功卡 + 开通指引
    payload: Dict[str, Any] = {"ok": True, "user": user, "autoLogin": auto}
    token: Optional[str] = None
    if auto:
        try:
            token, th, sid = await _issue_session(uid, name, ip, ua)
            UA.cache[th] = _CacheEntry(
                Principal(user_id=uid, user_name=name, session_id=sid,
                          token_hash=th, due_time_iso=due_iso), time.monotonic())
        except Exception as e:        # noqa: BLE001 —— 注册已成,登录失败降级为提示
            print(f"[注册] 注册成功但自动登录会话签发失败(降级为手动登录): {e!r}")
            token = None
            payload["autoLogin"] = False
            payload["hint"] = "注册成功!自动登录未完成,请手动登录。"
    if not payload["autoLogin"] and "hint" not in payload:
        payload["hint"] = str(getattr(cfg, "reg_success_hint", "") or "注册成功!")
    return 200, payload, token


# ── /api/auth/register* 路由(C1:/api/auth/ 前缀天然豁免会话与 CSRF 头) ───────
def _origin_mismatch(request: Request) -> bool:
    """best-effort 同源校验:带 Origin/Referer 且与 Host / X-Forwarded-Host 都
    不同源 → 拒;头缺失不拒(兼容隐私浏览器)。注册端点只收 JSON,跨站纯表单
    天然失效、跨源 fetch 带 JSON 必被 CORS 预检拦 —— 本检查是再多一道纵深。"""
    src = request.headers.get("origin") or request.headers.get("referer") or ""
    if not src:
        return False
    try:
        host = (urlparse(src).hostname or "").lower()
    except Exception:                 # noqa: BLE001
        return False
    if not host:
        return False
    allowed = set()
    for h in (request.headers.get("host", ""),
              request.headers.get("x-forwarded-host", "")):
        h = h.split(",")[0].strip().lower()
        if h.startswith("[") and "]" in h:          # IPv6 字面量:[::1]:5173 → ::1
            allowed.add(h[1:h.index("]")])
        elif h:
            allowed.add(h.split(":")[0])
    return bool(allowed) and host not in allowed


@router.get("/api/auth/register/challenge")
async def auth_register_challenge(request: Request):
    if not enabled():
        return JSONResponse({"ok": False, "error": "register_disabled",
                             "message": "本部署未开放注册"}, status_code=503)
    status, payload = await reg_challenge(client_ip(request),
                                          request.query_params.get("fp", ""))
    resp = JSONResponse(payload, status_code=status)
    if status == 429 and payload.get("retryAfter"):
        resp.headers["Retry-After"] = str(int(payload["retryAfter"]))
    return resp


@router.post("/api/auth/register")
async def auth_register(request: Request):
    if not enabled():
        return JSONResponse({"ok": False, "error": "register_disabled",
                             "message": "本部署未开放注册"}, status_code=503)
    if _origin_mismatch(request):
        return JSONResponse({"ok": False, "error": "bad_origin",
                             "message": "请求来源校验未通过"}, status_code=403)
    try:
        body = await request.json()
        if not isinstance(body, dict):
            raise ValueError("body must be object")
    except Exception:                 # noqa: BLE001 —— 只收 application/json
        return JSONResponse({"ok": False, "error": "bad_request",
                             "message": "注册失败,请稍后重试"}, status_code=400)
    status, payload, token = await register(body, client_ip(request),
                                            request.headers.get("user-agent", ""))
    resp = JSONResponse(payload, status_code=status)
    if status == 429 and payload.get("retryAfter"):
        resp.headers["Retry-After"] = str(int(payload["retryAfter"]))
    if status == 200 and token:
        set_session_cookie(resp, request, token)
        await set_device_cookie(resp, request, str((payload.get("user") or {}).get("userName") or ""))
        if on_login_ok is not None:   # 注册即登录:与登录 200 同款首登预置房回调(C10)
            try:
                await on_login_ok(int((payload.get("user") or {}).get("id") or 0))
            except Exception as e:    # noqa: BLE001
                print(f"[注册] 首登回调异常(忽略,不影响注册): {e!r}")
    return resp


# ══════════════════════════════════════════════════════════════════════════════
# 链接快速登录(4.1.0,SSO)—— 同库其它项目签发一次性票据,观测台凭票换会话
# ==============================================================================
# 完整设计/接入指南/威胁模型见 SSO-LOGIN.md。要点(全部实地对齐既有实现):
#   · 票据 = 64 hex(32 随机字节);库里只存 SHA-256(guantai_sso_ticket.token_hash,
#     与 guantai_user_session 同款「令牌本身不落库」纪律)。**签发 = 签发方向共享
#     MySQL INSERT 一行** —— 不需要共享密钥、不需要打通 Redis:共享库本身就是
#     双方唯一的信任媒介;时效判定统一用**数据库的钟**(NOW()),天然无跨机钟差。
#   · 单次有效:核销走 `UPDATE ... SET used=1 WHERE id=%s AND used=0` 的单语句
#     原子写,rowcount≠1 即视为已被并发消费 —— 多 web 进程零协调、不依赖 Redis。
#   · 消费侧双时效:签发方写的 expires_at 之外再叠加 sso_max_age_s(默认 300s)
#     的 created_at 硬顶 —— 签发方哪怕误写超长有效期,票据寿命也有上界。
#   · 兑换成功即复用 _issue_session():互顶/并发上限/首登预置房/审计与账密登录
#     逐字节同行为;guantai_login_log 落 reason='sso'(成功)/'sso_bad'(失败),
#     与登录审计同一张表、同一保留期。
#   · 已登录**另一账号**时回 409 switch_confirm(**不消费票据**),前端弹确认、
#     同意后带 allowSwitch 重试 —— 封「点了他人票据链接被静默换号」的 login-CSRF 面
#     (本应用账号库按用户隔离,静默换号会让受害者把酷狗扫码票据存进攻击者名下)。
#   · 默认关(sso_enabled,STA_USER_SSO=1 开启):不配置即不存在;表照常幂等自建。
#   · 对 tb_user 仍仅 SELECT(状态复核与登录同一 JOIN 口径);核销写的是自有
#     guantai_ 新表 —— test_tb_user_sql_discipline 全源码扫描恒绿。
# ══════════════════════════════════════════════════════════════════════════════

_SSO_IP_10M = 30                       # 每 IP 兑换尝试/10 分钟(票据空间 2^256,此闸只为压噪/压日志)
_SSO_WIN_S = 600


def sso_enabled() -> bool:
    return bool(enabled() and getattr(UA.cfg, "sso_enabled", False))


def sso_ticket_norm(raw) -> str:
    """票据形态归一:去空白、转小写;不是 64 hex → 空串(调用方按 bad_ticket 处理)。
    纯函数,tests/test_sso.py 恒跑覆盖。小写归一是跨端契约的一半 —— 签发方按
    SSO-LOGIN.md 对**小写 hex** 求 SHA-256,消费侧先归一再求同款摘要,两端必然对上。"""
    t = str(raw or "").strip().lower()
    return t if _HEX64.match(t) else ""


async def _sso_throttled(ip: str) -> Optional[int]:
    """每 IP 兑换尝试限频(计入一切尝试,含格式错)。触限 → 剩余锁定秒数;
    Redis 抖动退化进程内计数 —— 风控组件故障**不放开**(与登录节流同姿态)。"""
    # 5.2.0:原子窗口计数(旧写法 EXPIRE 抖一次即永久锁该 IP)+ IPv6 按 /64 分桶
    n, ttl = await _win_incr(f"guantai:sso:ip:{_ip_bucket(ip)}", _SSO_WIN_S, UA.mem_sso)
    return max(1, ttl) if n > _SSO_IP_10M else None


async def sso_exchange(ticket, allow_switch: bool, current_token: str,
                       ip: str, ua: str) -> Tuple[int, dict, Optional[str]]:
    """核心兑换流程。返回 (HTTP 状态, 响应体, 会话令牌或 None)。
    错误语义(与登录同一词表,前端 fallback 零新增):
      401 bad_ticket(不存在/已核销/已过期/超年龄硬顶/用户行已删,**不区分**,
          防票据探测)/ 403 banned|expired(票据有效才揭示,与登录同口径)/
      409 switch_confirm(已登录另一账号且未确认;**不消费票据**)/
      429 throttled / 503 userdb_unavailable。"""
    ip, ua = str(ip or "")[:45], str(ua or "")[:200]
    lock = await _sso_throttled(ip)
    if lock is not None:
        await _log_login(0, "", ip, ua, 0, "sso_throttled")
        return 429, {"ok": False, "error": "throttled", "retryAfter": lock,
                     "message": f"尝试过于频繁,请 {max(1, lock // 60)} 分钟后再试"}, None
    t = sso_ticket_norm(ticket)
    if not t:
        await _log_login(0, "", ip, ua, 0, "sso_bad")
        await asyncio.sleep(0.3 + secrets.randbelow(200) / 1000.0)
        return 401, {"ok": False, "error": "bad_ticket",
                     "message": "快速登录链接无效,请回到来源页面重新进入"}, None
    if not await _ensure_schema():
        return 503, {"ok": False, "error": "userdb_unavailable",
                     "message": "用户库暂时不可用,请稍后重试"}, None

    c = UA.cfg
    th = _hash_token(t)
    try:
        # 票据 + 用户状态一次 JOIN 取齐(is_off/due_time/观测台侧封禁与登录同口径);
        # fresh/young 都由**数据库的钟**判定 —— 签发方与观测台之间不存在钟差问题。
        row = await _q(
            f"SELECT t.id AS tid, t.user_id, t.used, "
            f"(t.expires_at > NOW()) AS fresh, "
            f"(t.created_at > DATE_SUB(NOW(), INTERVAL %s SECOND)) AS young, "
            f"u.id AS uid_probe, u.user_name, u.is_off, u.due_time, "
            f"(u.due_time > NOW()) AS alive, "
            f"b.user_id AS blocked, "
            f"jf.vip_until AS jf_until, (jf.vip_until > NOW()) AS jf_alive "
            f"FROM guantai_sso_ticket t "
            f"LEFT JOIN `{c.user_table}` u ON u.id = t.user_id "
            f"LEFT JOIN guantai_user_block b ON b.user_id = t.user_id "
            f"LEFT JOIN guantai_jf_vip jf ON jf.user_id = t.user_id "
            f"WHERE t.token_hash=%s",
            (int(max(1, getattr(c, "sso_max_age_s", 300))), th), fetch="one")
    except Exception as e:            # noqa: BLE001 —— 公网用户库不可达
        print(f"[登录] SSO 票据查询失败: {e!r}")
        return 503, {"ok": False, "error": "userdb_unavailable",
                     "message": "用户库暂时不可用,请稍后重试"}, None

    # 统一失败路径:不存在/已核销/过期/超年龄/用户行已删(uid_probe NULL)→ 同一
    # bad_ticket(恒定小延迟拉平时序差;票据持有者无从区分失败原因,不成探测信道)。
    # 注意缺行探针用 u.id 而非 due_time —— due_time 为 NULL 的存量用户走下方
    # alive 判定进 expired 分支,与账密登录 login() 的口径逐字节一致。
    if (row is None or int(row.get("used") or 0)
            or not int(row.get("fresh") or 0) or not int(row.get("young") or 0)
            or row.get("uid_probe") is None):
        await _log_login(int(row["user_id"]) if row else 0,
                         str(row.get("user_name") or "")[:50] if row else "",
                         ip, ua, 0, "sso_bad")
        await asyncio.sleep(0.3 + secrets.randbelow(200) / 1000.0)
        return 401, {"ok": False, "error": "bad_ticket",
                     "message": "快速登录链接已失效或已使用,请回到来源页面重新进入"}, None

    uid, name = int(row["user_id"]), str(row["user_name"])
    due_iso = _dt_iso(row.get("due_time"))
    if _is_banned(row.get("is_off")) or row.get("blocked") is not None:
        _why = "banned" if _is_banned(row.get("is_off")) else "blocked"
        await _log_login(uid, name, ip, ua, 0, _why)
        return 403, {"ok": False, "error": "banned",
                     "message": "该账号已被停用,请联系管理员"}, None
    dd_alive = bool(int(row.get("alive") or 0))
    if not dd_alive and not c.jf_enabled:
        # 4.1.2 原行为。**VIP 体系关闭时逐字节不变。**
        await _log_login(uid, name, ip, ua, 0, "expired")
        return 403, {"ok": False, "error": "expired", "dueTime": due_iso,
                     "message": f"账号已到期({due_iso[:16].replace('T', ' ')}),请续费后再登录"}, None
    # 4.2.0:这是第**三**处到期闸(login / validate / sso_exchange)。三处必须同步 ——
    # 漏掉本处的话,从续费系统点「进入观测台」快速登录的到期用户依旧被 403 挡在门外,
    # 他永远看不到开通引导页(而那正是最该被引导的一批人:他刚在续费系统里)。

    # 已登录另一账号 → 未确认前**不消费票据**直接 409(票据留给确认后的重试;
    # 60s 级 TTL 天然给这个「留」上界)。当前会话无效/不可判 → 视作无会话,继续。
    switched = False
    if current_token:
        st, pr, _ = await validate(current_token)
        if st == "ok" and pr is not None and int(pr.user_id) != uid:
            if not allow_switch:
                return 409, {"ok": False, "error": "switch_confirm",
                             "current": pr.user_name, "target": name,
                             "message": "当前已登录其他账号,请确认是否切换"}, None
            switched = True

    # 单语句原子核销:多标签页/预览爬虫/重放竞速下恰一名赢家,其余按失效处理。
    try:
        n = await _q("UPDATE guantai_sso_ticket SET used=1, used_at=NOW(), "
                     "used_ip=%s WHERE id=%s AND used=0", (ip, int(row["tid"])))
    except Exception as e:            # noqa: BLE001
        print(f"[登录] SSO 票据核销失败: {e!r}")
        return 503, {"ok": False, "error": "userdb_unavailable",
                     "message": "用户库暂时不可用,请稍后重试"}, None
    if int(n or 0) != 1:
        await _log_login(uid, name, ip, ua, 0, "sso_bad")
        return 401, {"ok": False, "error": "bad_ticket",
                     "message": "快速登录链接已失效或已使用,请回到来源页面重新进入"}, None

    try:
        token, th2, sid = await _issue_session(uid, name, ip, ua,
                                               free_tier=(not dd_alive))
    except Exception as e:            # noqa: BLE001
        print(f"[登录] SSO 会话签发失败: {e!r}")
        return 503, {"ok": False, "error": "userdb_unavailable",
                     "message": "用户库暂时不可用,请稍后重试"}, None

    await _log_login(uid, name, ip, ua, 1, "sso" if dd_alive else "sso_free")
    pr2 = Principal(user_id=uid, user_name=name, session_id=sid,
                    token_hash=th2, due_time_iso=due_iso, dd_alive=dd_alive,
                    jf_vip_until_iso=_dt_iso(row.get("jf_until")) if row.get("jf_until") else "",
                    jf_alive=bool(int(row.get("jf_alive") or 0)))
    UA.cache[th2] = _CacheEntry(pr2, time.monotonic())
    return 200, {"ok": True, "user": pr2.public(),
                 "singleDevice": bool(c.single_device), "switched": switched}, token


@router.post("/api/auth/sso")
async def auth_sso(request: Request):
    """兑换端点(C1:/api/auth/ 前缀天然豁免会话与 CSRF 头闸;同源 fetch 自带
    既有会话 Cookie,供换号确认判定)。只收 application/json;best-effort 同源
    校验与注册端点同一 _origin_mismatch(头缺失不拒,兼容隐私浏览器)。"""
    if not enabled():
        return JSONResponse({"ok": False, "error": "login_disabled",
                             "message": "本部署未启用登录系统"}, status_code=503)
    if not sso_enabled():
        return JSONResponse({"ok": False, "error": "sso_disabled",
                             "message": "本部署未启用链接快速登录"}, status_code=503)
    if _origin_mismatch(request):
        return JSONResponse({"ok": False, "error": "bad_origin",
                             "message": "请求来源校验未通过"}, status_code=403)
    try:
        body = await request.json()
        if not isinstance(body, dict):
            raise ValueError("body must be object")
    except Exception:                 # noqa: BLE001 —— 只收 application/json
        return JSONResponse({"ok": False, "error": "bad_request",
                             "message": "请求格式有误"}, status_code=400)
    status, payload, token = await sso_exchange(
        body.get("ticket"), bool(body.get("allowSwitch")),
        request.cookies.get(UA.cfg.cookie_name, ""),
        client_ip(request), request.headers.get("user-agent", ""))
    resp = JSONResponse(payload, status_code=status)
    if status == 429 and payload.get("retryAfter"):
        resp.headers["Retry-After"] = str(int(payload["retryAfter"]))
    if status == 200 and token:
        set_session_cookie(resp, request, token)
        await set_device_cookie(resp, request, str((payload.get("user") or {}).get("userName") or ""))
        if on_login_ok is not None:   # 首登预置房:与账密登录 200 同款回调
            try:
                await on_login_ok(int((payload.get("user") or {}).get("id") or 0))
            except Exception as e:    # noqa: BLE001
                print(f"[登录] SSO 首登回调异常(忽略,不影响登录): {e!r}")
    return resp


# ══════════════════════════════════════════════════════════════════════════════
# 账密签发通道(4.3.0)—— POST /api/auth/sso/link:验账密 → 吐一次性快速登录链接
# ==============================================================================
# 完整接入指南/威胁模型见 SSO-LOGIN.md §2.6 与 §7。要点(全部实地对齐既有实现):
#   · **与 4.1.0 的 INSERT 通道并存,不替代**:同一张 guantai_sso_ticket、同一个
#     消费端点 /api/auth/sso、同一套单次核销与年龄硬顶。接入方二选一 ——
#     能连共享库就用 INSERT(少一跳、无需密钥);不便连库就用本通道(一次 POST)。
#   · **零 DDL 变更**:签发写的是既有 note 列(VARCHAR(50),全项目无读取点),
#     不新增列 —— MySQL 的 CREATE TABLE IF NOT EXISTS 对**已存在**的线上表不会
#     补列,加列就得另写幂等迁移,得不偿失。双通道 DDL 与既有断言原样恒绿。
#   · **哈希契约物理上不可能对不上**:签发用的 _hash_token() 与消费侧
#     sso_exchange() 里那一句是**同一个函数**。SSO-LOGIN.md §6 排错表第 2 条
#     记载的历史头号翻车点(接入方对二进制而非 hex 字符串求摘要)在本通道消失。
#   · **不额外放大口令爆破面**:口令校验走 _authenticate() —— 与 /api/auth/login
#     同一实现、同一套「用户名 10 次 / IP 30 次 每 10 分钟」失败计数与加码判定(5.2.0)。
#     攻击者从两个端点合起来能拿到的尝试次数,与只有 /api/auth/login 时逐次相等。
#   · **绝不 Set-Cookie**:本端点只产票据。会话的唯一出生地仍是 _issue_session(),
#     由消费端点 /api/auth/sso 在用户真正到达时调用。静态钉见 tests/test_sso_link.py。
#   · **票据寿命由观测台自己写**,调用方不得指定(比 INSERT 通道更严);消费侧的
#     sso_max_age_s 年龄硬顶继续叠加,双保险不变。
#   · 默认关(sso_link_enabled,STA_USER_SSO_LINK=1 开启,且需 STA_USER_SSO=1)。
#   · 对 tb_user 仍仅 SELECT(经 _authenticate 与登录同一 JOIN 口径);签发写的是
#     自有 guantai_ 表 —— test_tb_user_sql_discipline 全源码扫描恒绿。
# ══════════════════════════════════════════════════════════════════════════════

_SSO_LINK_TTL_MIN_S = 10               # 票据寿命下限(留足一次 302 + 页面启动)
_SSO_LINK_TTL_MAX_S = 300              # 票据寿命硬顶(与消费侧 sso_max_age_s 默认同阶)
_SSO_LINK_UID_PER_MIN = 10             # 每账号签发上限/分钟(口令正确也不许无限灌表)
_SSO_LINK_WIN_S = 60
_SSO_LINK_BADKEY_10M = 20              # 每 IP **密钥错误**上限/10 分钟(成功不计数)
_SSO_LINK_BADKEY_WIN_S = 600


def sso_link_note(raw) -> str:
    """把调用方给的 note 清洗成票据表存得下的形态。纯函数。

    **为什么必须清洗而不是原样写**:guantai_sso_ticket 是 `CHARSET=gbk`(随
    tb_user 的历史字符集),note 里出现 emoji / 日文假名等 GBK 表示不了的字符时,
    aiomysql 编码 SQL 会抛 UnicodeEncodeError —— 被上层的兜底 except 当成「用户库
    不可用」回 503。那是**彻头彻尾的误导**:库好好的,只是备注里有个表情符号,
    而调用方拿到 503 会去查数据库。note 只是审计备注,不值得让签发失败。
    (实地复现:note='续费🎉系统' → 503 userdb_unavailable。本函数即该缺陷的修根因。)

    先截 50 字符(VARCHAR(50) 按字符计),再把 GBK 不可表示的字符换成 '?',
    最后复截一次 —— 替换只会等长或变短,复截是纯防御。"""
    s = str(raw or "")[:50]
    return s.encode("gbk", "replace").decode("gbk", "replace")[:50]


def sso_link_enabled() -> bool:
    """本通道是否生效。**刻意串联 sso_enabled()** —— 签得出票却没有消费端点
    (/api/auth/sso 回 503)是纯粹的误配,不如在签发侧就诚实拒绝。"""
    return bool(sso_enabled() and getattr(UA.cfg, "sso_link_enabled", False))


def sso_link_ttl_s() -> int:
    """本通道签发的票据寿命(秒),钳在 [10, 300]。纯函数,tests 恒跑覆盖。
    调用方**不能**指定 —— 签发方误写超长有效期这条路在本通道被物理封死。"""
    raw = int(getattr(UA.cfg, "sso_link_ttl_s", 60) or 60)
    return max(_SSO_LINK_TTL_MIN_S, min(_SSO_LINK_TTL_MAX_S, raw))


def sso_link_url(ticket: str) -> str:
    """按配置的公网 origin 拼快速登录链接;未配置/形态不合法 → 空串(端点据此不回
    url,调用方自己拼)。纯函数。

    **只认配置,绝不从 Host / X-Forwarded-Host 推导** —— 那两个头由调用方控制,
    拿可控输入拼一条「要发给终端用户去点」的 URL 是反模式。宁可不回 url。
    片段用 # 不用 ? :# 后内容浏览器不发给服务器,不进访问日志与 Referer
    (与 4.1.0 的链接形态**逐字符一致**,前端 ssoConsume() 零改动即可消费)。

    4.3.0 复审加固:本项自后台可热改(hot,见 config_registry),值不再只来自
    部署期的 .env —— 故在**这里**做形态守卫(须 http:// 或 https:// 开头),
    而不是去 config_center 挂具名校验器。理由:守卫放在唯一使用点,则无论值经
    ENV / 管理页覆盖 / 代码直写哪条路进来都拦得住;放在校验器只拦管理页那一条。
    形态不合法时**降级为「未配」**而不是抛错 —— 签发本身不该因为备用字段的
    格式问题而失败,用户至多少拿一个 url 字段。"""
    base = str(getattr(UA.cfg, "sso_link_base", "") or "").strip().rstrip("/")
    if not base.lower().startswith(("http://", "https://")):
        return ""
    return f"{base}/#sso={ticket}"


def sso_link_key_ok(header: str) -> bool:
    """`Authorization: Bearer <key>` 校验(常数时间比较)。纯函数。

    未配置密钥 → 恒 True。这**不是**妥协:不配密钥时本端点的能力**不超过**已经公开的
    /api/auth/login —— 两者共用 _authenticate() 里同一套先占后验计数与加码判定(5.2.0),
    而本端点解不了题,需要加码时直接 429,只会更严 —— 故不构成新增敞口。配上密钥换来的是「按调用方限频 / 审计 / 单独吊销」,
    而不是「防爆破」—— 防爆破靠的是与登录共用的失败节流桶。"""
    want = str(getattr(UA.cfg, "sso_link_key", "") or "").strip()
    if not want:
        return True
    got = str(header or "").strip()
    if got[:7].lower() == "bearer ":
        got = got[7:].strip()
    return hmac.compare_digest(got.encode("utf-8", "ignore"),
                               want.encode("utf-8", "ignore"))


async def _sso_link_throttled(uid: int) -> Optional[int]:
    """每账号签发限频(**口令正确之后**才计数)。触限 → 剩余锁定秒数。
    姿态与 _sso_throttled / _reg_incr 同款:Redis 优先、抖动退化进程内计数 ——
    风控组件故障**不放开**。复用 UA.mem_sso 兜底桶(键前缀不同,天然不串)。"""
    n, ttl = await _win_incr(f"guantai:ssolink:uid:{int(uid)}", _SSO_LINK_WIN_S, UA.mem_sso)
    return max(1, ttl) if n > _SSO_LINK_UID_PER_MIN else None


async def _sso_link_badkey(ip: str, bump: bool) -> Optional[int]:
    """按 IP 统计**密钥错误**次数。`bump=False` 只读探(不计数),True 才累加。
    命中上限 → 返回剩余锁定秒数。

    **只对失败计数,成功不计数** —— 这一点是刻意的:本端点是服务端对服务端,
    所有终端用户的签发请求都来自签发方那**一个** IP。若把成功也计入 per-IP 桶,
    正常调用方会把自己打死。而正常调用方**永远不会发错密钥**,所以按失败计数
    对它零影响,对爆破者却是硬闸。

    **为什么非有不可**(实地复现的缺陷):密钥闸原本无限频 —— 40 发错误密钥
    全部返回 401,且每一发都往**生产共享库** guantai_login_log 写一行。这既是
    日志放大(打的是别的项目也在用的 MySQL),也是协程占用(每发 sleep 0.3–0.5s)。
    既有 _sso_throttled 的注释写明其存在意义就是「压噪/压日志」,本闸同源。

    姿态同全家:Redis 优先、抖动退化进程内、风控组件故障**不放开**。
    来源 IP 走 client_ip() 的「可信代理」口径(app/clientip.py,5.2.0):直连部署伪造
    XFF 无效,反代覆盖或追加 XFF 都能取到真实客户端;IPv6 按 /64 分桶。

    「先查后加」在这里是**刻意保留**的:签发密钥是高熵秘密,并发多出的几次猜测在
    概率上可以忽略;而改成「先占后验」会让合法调用方(全部来自同一个 IP、可能高并发)
    被自己的在途请求挤爆 —— 与口令(低熵、必须先占后验)的取舍正好相反。"""
    key = f"guantai:ssolink:badkey:{_ip_bucket(ip)}"
    if not bump:
        if await _win_peek(key, UA.mem_sso) >= _SSO_LINK_BADKEY_10M:
            return max(1, await _win_ttl(key, UA.mem_sso, _SSO_LINK_BADKEY_WIN_S))
        return None
    n, _ttl = await _win_incr(key, _SSO_LINK_BADKEY_WIN_S, UA.mem_sso)
    return max(1, _SSO_LINK_BADKEY_WIN_S) if n >= _SSO_LINK_BADKEY_10M else None


async def _mint_sso_ticket(uid: int, ttl_s: int, note: str) -> str:
    """签发一枚票据:随机 64 hex,库里**只落 SHA-256**(与 guantai_user_session
    同款「令牌本身不落库」纪律)。expires_at 用**数据库的 NOW()** 计算 —— 与
    4.1.0 的 INSERT 通道同源,观测台与用户库之间不存在钟差问题。
    异常上抛,调用方定语义(→ 503)。"""
    ticket = secrets.token_hex(32)
    await _q("INSERT INTO guantai_sso_ticket (user_id, token_hash, created_at, "
             "expires_at, note) VALUES (%s, %s, NOW(), "
             "DATE_ADD(NOW(), INTERVAL %s SECOND), %s)",
             (int(uid), _hash_token(ticket), int(ttl_s), gbk_text(note, 50)))
    return ticket


async def sso_link(body: Dict[str, Any], auth_header: str, ip: str, ua: str
                   ) -> Tuple[int, dict]:
    """核心流程:密钥闸 → 口令校验(共用 _authenticate)→ 每账号签发限频 → 签发票据。

    错误语义与登录同一词表(接入方 fallback 零新增):
      400 missing_fields / 401 bad_key|bad_credentials / 403 banned|expired /
      429 throttled / 503 userdb_unavailable。

    审计纪律:失败已由 _authenticate 落过 bad_credentials|banned|expired|throttled,
    此处**不补第二条** —— 否则一次失败两行审计。只有**成功签发**才落
    reason='sso_link',于是审计表里一行 sso_link ⇔ 一张票据被签出,语义无歧义。
    (密钥闸失败发生在 _authenticate 之前,单独落 sso_link_bad,不存在重复。)"""
    ip, ua = str(ip or "")[:45], str(ua or "")[:200]
    # 锁定期内**静默** 429:不写审计 —— 触限那一刻已经写过一行,再写就是自己
    # 帮攻击者放大日志(打的是与别的项目共用的生产 MySQL)。
    lock = await _sso_link_badkey(ip, bump=False)
    if lock is not None:
        return 429, {"ok": False, "error": "throttled", "retryAfter": lock,
                     "message": f"尝试过于频繁,请 {max(1, lock // 60)} 分钟后再试"}
    if not sso_link_key_ok(auth_header):
        await _sso_link_badkey(ip, bump=True)
        await _log_login(0, "", ip, ua, 0, "sso_link_bad")
        await asyncio.sleep(0.3 + secrets.randbelow(200) / 1000.0)
        return 401, {"ok": False, "error": "bad_key",
                     "message": "签发凭据无效"}

    user_name = str(body.get("userName") or body.get("user_name") or "").strip()
    password = str(body.get("password") or body.get("pass_word") or "")
    note = sso_link_note(body.get("note"))     # gbk 安全化:见 sso_link_note 注

    status, payload, row = await _authenticate(
        user_name, password, ip, ua, channel="link",
        link_keyed=bool(str(getattr(UA.cfg, "sso_link_key", "") or "").strip()))
    if row is None:
        return status, payload                 # 失败语义与 /api/auth/login 逐字节相同

    due_iso, dd_alive = str(payload["dueIso"]), bool(payload["ddAlive"])
    uid, name = int(row["id"]), str(row["user_name"])

    lock = await _sso_link_throttled(uid)
    if lock is not None:
        await _log_login(uid, name, ip, ua, 0, "sso_link_rate")
        return 429, {"ok": False, "error": "throttled", "retryAfter": lock,
                     "message": f"签发过于频繁,请 {lock} 秒后再试"}

    ttl = sso_link_ttl_s()
    try:
        ticket = await _mint_sso_ticket(uid, ttl, note or "sso_link")
    except Exception as e:            # noqa: BLE001 —— 公网用户库不可达
        print(f"[登录] SSO 票据签发失败: {e!r}")
        return 503, {"ok": False, "error": "userdb_unavailable",
                     "message": "用户库暂时不可用,请稍后重试"}

    await _fail_clear(user_name)      # 与 login() 同一时刻语义:真正成功后才清计数
    await _log_login(uid, name, ip, ua, 1, "sso_link")
    out: Dict[str, Any] = {
        "ok": True, "ticket": ticket, "expiresIn": ttl,
        "user": {"id": uid, "userName": name, "dueTime": due_iso,
                 "dueDays": _due_days(due_iso), "ddAlive": dd_alive}}
    url = sso_link_url(ticket)
    if url:
        out["url"] = url              # 未配 STA_USER_SSO_LINK_BASE 时不回该字段
    return 200, out


@router.post("/api/auth/sso/link")
async def auth_sso_link(request: Request):
    """账密签发端点(C1:/api/auth/ 前缀天然豁免会话与 CSRF 头闸)。

    面向**服务端对服务端**调用:本项目全局无 CORS 中间件,浏览器跨源直连调不通。
    这是**刻意的** —— 开 CORS 等于要求接入方把签发密钥放进前端 JS。
    仍叠一道 best-effort 同源校验(与注册/兑换端点同一 _origin_mismatch:
    服务端调用无 Origin/Referer 头,照常通过;浏览器跨站发起则被挡)。"""
    if not enabled():
        return JSONResponse({"ok": False, "error": "login_disabled",
                             "message": "本部署未启用登录系统"}, status_code=503)
    # 两个开关分开报 —— 本通道串联 sso_enabled,但运营者配的是 STA_USER_SSO_LINK,
    # 若合并成一个错误码,他会一直去查 _LINK 而漏掉真正没开的 STA_USER_SSO。
    if not sso_enabled():
        return JSONResponse({"ok": False, "error": "sso_disabled",
                             "message": "本部署未启用链接快速登录"
                                        "(需先置 STA_USER_SSO=1)"}, status_code=503)
    if not sso_link_enabled():
        return JSONResponse({"ok": False, "error": "sso_link_disabled",
                             "message": "本部署未启用账密签发通道"
                                        "(需置 STA_USER_SSO_LINK=1)"}, status_code=503)
    if _origin_mismatch(request):
        return JSONResponse({"ok": False, "error": "bad_origin",
                             "message": "请求来源校验未通过"}, status_code=403)
    try:
        body = await request.json()
        if not isinstance(body, dict):
            raise ValueError("body must be object")
    except Exception:                 # noqa: BLE001 —— 只收 application/json
        return JSONResponse({"ok": False, "error": "bad_request",
                             "message": "请求格式有误"}, status_code=400)
    status, payload = await sso_link(
        body, request.headers.get("authorization", ""),
        client_ip(request), request.headers.get("user-agent", ""))
    resp = JSONResponse(payload, status_code=status)
    if status == 429 and payload.get("retryAfter"):
        resp.headers["Retry-After"] = str(int(payload["retryAfter"]))
    # ⚠️ 此处**绝不** set_session_cookie:本端点只产票据,会话的唯一出生地是
    #    _issue_session()(由消费端点 /api/auth/sso 在用户真正到达时调用)。
    #    tests/test_sso_link.py::test_link_never_issues_session 静态扫描钉死。
    return resp
