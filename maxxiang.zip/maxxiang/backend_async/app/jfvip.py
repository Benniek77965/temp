"""
jfvip.py — 九法 VIP 分层与开通(4.2.0)
================================================================================
定位:在既有登录系统(userauth.py)之上加一层**收费档位**,并承载「开通」这一
唯一的写动作。设计与纪律见 JFVIP-SYSTEM.md。要点:

  · **不配置即不存在**:`jf_vip_enabled=False`(默认)时本模块全部退场 ——
    档位判定、VIP 闸、充值端点一律不生效,登录/会话/数据面逐字节维持 4.1.2。

  · **三档**:free(小叮当到期且无 VIP,零数据)/ basic(小叮当有效无 VIP,
    30 局起算 + 双游戏 + 近 100 局命中信息)/ vip(全功能)。
    判定在 userauth.Principal.tier,数据源是 login/validate 那条 JOIN
    (多挂一张 guantai_jf_vip,零额外往返)。

  · **全项目唯一一条针对 tb_user 的 UPDATE** 在本文件 `_grant_tx()` 内 ——
    赠送小叮当时长。除此之外对 tb_user 仍是只读(登录识别 + 会话复核 + 开通
    时的 FOR UPDATE 读)。该纪律由 `tests/test_jfvip_discipline.py` 静态扫描
    钉死:UPDATE 恰好一处且必须在本函数体内,DELETE/ALTER/TRUNCATE/DROP 仍为零,
    INSERT 仍恰好一处且在 userauth._register_tx。任何越界当场变红。

  · **续期口径**:`GREATEST(NOW(), 原到期) + N 小时`,全部在 SQL 侧用**库钟**算 ——
    与 login/validate 的 `due_time > NOW()` 同一把钟,web 机时钟漂移不参与
    任何续期计算。语义 = 未过期不亏时长,已过期从此刻起算(与线上软件、
    与 fanxing-admin `_next_due` 完全一致)。

  · **原子性**:九法 VIP 续期与小叮当赠送在**同一事务**内完成 —— 二者同库
    (guantai_jf_vip 与 tb_user 都在 fanxing_changkong_user_db),不存在
    「VIP 开了但小叮当没送」的中间态。任一步异常整体 ROLLBACK。

  · **幂等**:凭据行(订单/卡)在行锁下复核 credited/used_by,重复调用只入账一次。
    并发两笔开通被行锁串行,两笔时长都不会丢(GREATEST 口径 + ON DUPLICATE)。

  · **指定时长卡密**(4.2.9):卡的时长原先不在卡上而在配置里,发一张非标时长的
    卡必须先永久污染档位表(「code 一经售出不可删除」)。现引入**内联档位码**
    `@H<小时>[D<小时>]` —— 时长直接编进现成的 `plan_code VARCHAR(16)`,零 DDL、
    零新表、兑换路径零额外往返。配套一条只认 API Key 的机器对机器发卡端点
    `POST /api/admin/jfvip/cards/issue`(默认关,密钥为空即整体 503)。

对外接口(web.py / admin_api.py 消费):
    enabled()                    VIP 体系是否生效
    plans() / plan_of(code)      配置档位表(热更,配坏时 fail-safe 回空)
    resolve_plan(code)           ★ 时长解析唯一出口:内联码 + 配置档位
    inline_code(h,dd)/parse_inline(code)/is_inline_code(code)/norm_hours(x)
    vip_state(uid)               某用户的 VIP 状态(管理台/用户端共用)
    grant_by_card(...)           卡密开通
    grant_by_order(...)          订单确认支付后开通(由 jfpay 调用)
    grant_by_admin(...)          管理台手动开通/延长
    revoke_by_admin(...)         管理台撤销
    gen_cards(...)               按配置档位发卡
    gen_cards_hours(...)         ★ 按指定时长发卡
    cards_page(...) / cards_disable(...) / cards_purge(...)
    grants_page(...) / orders_page(...) / overview()
    order_rate_ok(uid) / redeem_fail_bump(uid) / redeem_fail_ok(uid)
    card_api_status() / card_api_key_ok(h) / card_api_ip_ok(ip)
    card_api_rate_ok() / card_api_badkey(ip, bump)     外部发卡 API 的四道闸
"""
from __future__ import annotations

import contextlib
import hashlib
import hmac
import ipaddress
import json
import re
import secrets
import time
from datetime import date as _date
from typing import Any, Dict, List, Optional, Tuple

from . import userauth
from . import wincount  # 5.2.0:原子窗口计数

try:
    import aiomysql
except Exception:                      # noqa: BLE001 —— 与 userauth 同款:未装驱动即整体禁用
    aiomysql = None

# ── 卡密字符集:排除 I / O / 0 / 1 ────────────────────────────────────────────
# 与 fanxing-admin `card_service.CARD_ALPHABET` / `CARD_DIGITS` 逐字符一致。
# 理由(沿用其注释,实为运营硬要求):'I' 与 '1'/'l' 形似、'O' 与 '0' 形似,
# 口头报卡与纸面抄写时是最高频的差错来源。组合空间 24^6 × 8^6 ≈ 6.4e10,
# 唯一性重试 20 次封顶绰绰有余。
CARD_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ"   # 24 个(缺 I、O)
CARD_DIGITS = "23456789"                      # 8 个(缺 0、1)
CARD_PREFIX = "TL"                            # 新发卡前缀
# ── 历史前缀:**只接受兑换,不再生成** ────────────────────────────────────────
# 前缀从 JF 改为 TL 时,库里 guantai_jf_card 已有的 JF 卡、以及**已经发到渠道
# 和用户手上**的未兑换卡都还在。若把校验收紧成只认 TL,这些卡会在下一次兑换时
# 被形态闸当场拒掉 —— 用户拿着花钱买的卡兑不了,是资损与客诉,而且**没有任何
# 补救手段**(卡已经印/发出去了)。故新旧并存:发新卡用 TL,老卡照兑。
# 将来若确认存量 JF 卡已全部兑换或过期,再把这个元组清空即可,一行的事。
CARD_PREFIX_LEGACY = ("JF",)
_CARD_PREFIXES = (CARD_PREFIX,) + CARD_PREFIX_LEGACY
CARD_ALPHA_N = 6
CARD_DIGIT_N = 6
# 正则由上面的常量拼出,而不是再手写一遍字面量 —— 原实现把字符集与前缀
# 在正则里硬编码了第二遍,改前缀时极易只改一处、两边悄悄不一致。
_CARD_RE = re.compile("^(?:%s)[%s]{%d}[%s]{%d}$"
                      % ("|".join(_CARD_PREFIXES), CARD_ALPHABET, CARD_ALPHA_N,
                         CARD_DIGITS, CARD_DIGIT_N))
# 归一化时剔除的分隔符(用户从聊天窗口粘贴常带这些)
_CARD_STRIP = re.compile(r"[\s\-_·、,，.。]+")

_MAX_CARDS_PER_BATCH = 500            # 单批发卡上限(护栏:避免误填 1e6 撑爆事务)
# 单次按 id 操作(作废/恢复/删除)的上限。与发卡上限、列表页 size 上限三者同值 ——
# 「全选本页」最多就是 500 行,运维一次能选中的与一次能提交的严丝合缝。
# 4.2.8:此前 cards_disable(ids=) **完全没有上限**,10 万个 id 会拼出 10 万占位符的
# SQL,撑爆 max_allowed_packet 或事务内存;且元素未做类型净化,`ids:["a"]` 会让
# int("a") 抛 ValueError 一路穿到 FastAPI ⇒ HTTP 500。见 norm_ids()。
_MAX_IDS_PER_CALL = 500

K_ORDER_RATE = "guantai:jf:orderrate:{uid}"   # 下单限频
K_REDEEM_FAIL = "guantai:jf:redeemfail:{uid}"  # 卡密失败限频
K_RECONCILE_RATE = "guantai:jf:reconcile:{uid}"  # 对账兜底限频(4.2.2)

# 进程内兜底计数(Redis 抖动时用;与 userauth 的注册限流同哲学 —— 风控组件
# 故障**不放开**,退化为单进程计数总比完全放开好)
_mem_rate: Dict[str, Tuple[int, float]] = {}


# ══════════════════════════════════════════════════════════════════════════════
# 开关 / 档位表
# ══════════════════════════════════════════════════════════════════════════════
def enabled() -> bool:
    """VIP 体系是否生效。必须先有登录系统 —— 身份是档位的载体。"""
    return status()["enabled"]


def status() -> Dict[str, Any]:
    """带**原因**的启用判定。

    为什么要这个:`jf_vip_enabled=true` 存在多条"设了却没反应"的路径
    (登录系统没配、缺 aiomysql、进程没重启、配置没落到本进程),而原来一律
    静默回 False —— 运维只能看到"开了没用",无从判断卡在哪。真机反馈的正是
    这一类。现在把原因显式化,供启动日志、管理台「值」视图、诊断端点共用。
    """
    c = getattr(userauth.UA, "cfg", None)
    if c is None:
        return {"enabled": False, "reason": "not_inited",
                "message": "登录系统尚未初始化(web 进程刚起或 userauth.init 未跑)"}
    if not getattr(c, "jf_vip_enabled", False):
        return {"enabled": False, "reason": "switch_off",
                "message": "总开关 userauth.jf_vip_enabled 为关。"
                           "注意它是 🔴 重启级参数:管理台保存后**必须重启 web** 才生效"}
    if not getattr(c, "enabled", False):
        return {"enabled": False, "reason": "login_off",
                "message": "九法VIP 依赖登录系统,但用户库未配置"
                           "(STA_USERDB_HOST / _NAME / _USER 三项须齐全)。"
                           "身份是档位的载体,没有登录就没有档位 —— "
                           "此时把 jf_vip_enabled 设成 true 也不会有任何效果"}
    if aiomysql is None:
        return {"enabled": False, "reason": "no_driver",
                "message": "缺少 aiomysql 依赖(requirements.txt 已含,请重建镜像)"}
    return {"enabled": True, "reason": "ok", "message": "九法VIP 已启用"}


def startup_report() -> None:
    """启动横幅 —— 与登录系统的 [登录] 横幅同款:**开没开、为什么**一目了然。
    原先 VIP 体系静默启用/静默不启用,日志里一个字都没有,出了问题无从排查。"""
    st = status()
    if st["enabled"]:
        ps = plans()
        print(f"[九法VIP] 已启用 · 档位 {len(ps)} 档("
              f"{' / '.join(f"{p['name']}¥{p['price']:g}" for p in ps) or '未配置'})"
              f" · basic 档历史上限 {userauth.UA.cfg.jf_basic_history_limit} 局"
              f" · 命中窗口 {userauth.UA.cfg.jf_basic_pred_window} 局"
              f" · 网关 type={userauth.UA.cfg.jf_pay_type}"
              + ("  ⚠️ 模拟支付已开启(生产务必关闭!)"
                 if userauth.UA.cfg.jf_pay_simulate else ""))
        # 4.2.9:外部发卡 API 的状态必须上横幅。它是**唯一**一条能凭 API Key
        # 凭空造出可兑换时长的通路,开着而运维不知道,是最不该发生的事;
        # 而"配了却没开成"同样必须醒目 —— 那正是 status() 当初设立的理由。
        ca = card_api_status()
        if ca["enabled"]:
            _ip = str(getattr(userauth.UA.cfg, "jf_card_api_ip_allow", "") or "").strip()
            print(f"[九法VIP] 🔑 外部发卡 API 已启用 · POST /api/admin/jfvip/cards/issue"
                  f" · 限频 {userauth.UA.cfg.jf_card_api_rate_hourly or '不限'} 次/时"
                  f" · 单卡时长上限 {INLINE_MAX_HOURS}h"
                  f" · IP 白名单 {_ip or '未设(仅凭密钥)'}")
        elif ca["reason"] not in ("api_off",):
            print(f"[九法VIP] ⚠️ 外部发卡 API 未生效({ca['reason']}):{ca['message']}")
        # 4.4.1:站点分流的生效值必须上横幅。这一项配错时**页面上不会有任何报错**
        # —— 主站只是"按镜像站渲染"、静悄悄地没有了在线支付。横幅是运维唯一能在
        # 掉单之前发现它的地方(与外部发卡 API"开着而运维不知道"同一类风险)。
        _dh = sorted(userauth.jf_direct_host_set())
        if _dh:
            print(f"[九法VIP] 🌐 站点分流已启用 · 直营主站 {len(_dh)} 个"
                  f"({'、'.join(_dh)})· 其余任何 Host 一律按代理镜像站"
                  f"(隐藏在线扫码与档位卡,仅卡密开通,下单端点拒单)"
                  f" · 站点身份取自 "
                  + ("X-Forwarded-Host 首跳(缺失回落 Host)"
                     if getattr(userauth.UA.cfg, "jf_direct_trust_xfh", False)
                     else "Host 头")
                  + "  ⚠️ 请确认主站的 www 与裸域都已列入")
    elif st["reason"] != "switch_off":
        # 开关本就是关的属正常静默;其余情形都是"想开却没开成",必须醒目告警
        print(f"[九法VIP] ⚠️ 未生效({st['reason']}):{st['message']}")
    # 4.4.2 客服联系方式。**放在 if 之外无条件打印**,与上面的 VIP 横幅并列:
    #   · 它是站点级配置,不随 jf_vip_enabled 存亡(下发链路照常工作);
    #   · 与站点分流同一类风险 —— 配错时**页面上不会有任何报错**,只是那一行没出现
    #     或出现了一串错号码。横幅是运维在用户找上门之前唯一能发现它的地方。
    # 打印的是**收敛后的生效值**(过 cs_text / cs_url 那两道),不是配置原串 ——
    # 链接被白名单丢弃、全角数字被原样保留,都要在这里看得见。
    # ★ 走 userauth.cs_resolve() 这一份**唯一**收敛,不在这里重算 ——
    #   自审实测:此处曾漏传 drop_if_over,把一个已被丢弃的号码显示成"已配置",
    #   而横幅的全部价值就是不撒谎。
    _cs = userauth.cs_resolve()
    _raw = {k: (str(getattr(userauth.UA.cfg, f"jf_cs_{k}", "") or "").strip()
                if userauth.UA.cfg else "")
            for k in ("value", "url")}
    if _cs:
        _dh2 = userauth.jf_direct_host_set()
        print(f"[客服] ☎️ 联系方式已配置 · {_cs.get('label') or '客服'}"
              + (f" {_cs['value']}" if _cs.get("value") else "")
              + (f" · 链接 {_cs['url']}" if _cs.get("url") else "")
              + " · 展示位:九法VIP 开通门"
              + (f"(仅直营主站 {len(_dh2)} 个,其余 Host 不下发)" if _dh2
                 else "(未启用站点分流 ⇒ 全部域名都会展示)"))
    # 「填了却没出现」是本组最难自查的状态,两条成因分别点名(不合并成一句含糊的
    # "配置无效")—— 运维要知道的是**改哪里**,不是"有问题"。
    if _raw["value"] and not _cs.get("value"):
        print(f"[客服] ⚠️ 客服号码/账号超过 {userauth._CS_LIMITS['value']} 字符上限"
              f"(当前 {len(_raw['value'])}),**已整条丢弃**。刻意不截断:一串被截短的"
              f"号码会让用户照着抄却永远打不通,比没有号码更糟(同定制时长卡的"
              f"fail-closed 取向)。请缩短 STA_JF_CS_VALUE,或到管理台「参数中心」热改")
    if _raw["url"] and not _cs.get("url"):
        _why = (f"超过 {userauth._CS_LIMITS['url']} 字符上限(当前 {len(_raw['url'])})"
                if len(_raw["url"]) > userauth._CS_LIMITS["url"]
                else "不是合法的 http/https 绝对 URL(须带主机名)")
        print(f"[客服] ⚠️ 在线客服链接「{_raw['url'][:80]}」{_why},"
              f"**已整条丢弃**(页面上不会出现链接)。只放行 http:// 或 https:// "
              f"开头且带主机名的地址;mqqwpa:// / weixin:// 这类深链在桌面浏览器"
              f"点了毫无反应,故不放行。超长同样丢弃而不截断 —— 被截短的 URL 会"
              f"通过白名单却指向别处或 404,是一条看不出异常的坏链")


# ══════════════════════════════════════════════════════════════════════════════
# 内联档位码(4.2.9)—— 「指定时长卡密」的机制底座
# ------------------------------------------------------------------------------
# 要解决的真问题:在此之前,一张卡的时长**根本不在卡上**,而在配置里 ——
# `_grant_tx` 兑换时拿 `plan_code` 回 `jf_vip_plans` 查 `jfHours`。于是想发一张
# 「7 小时」或「10 天」的卡(促销 / 客诉补偿 / 渠道定制),运维必须先去配置中枢
# **新增一个档位**;而档位表有一条硬纪律写在 config_registry 上:
#
#       「code 一经售出不可删除(历史订单靠它解释),只能改价/停售」
#
# 也就是说,每做一次一次性的定制时长,就永久污染一次档位表。档位表同时又是
# **前台价格卡的数据源**,污染它等于把内部运营口径推到用户面前。
#
# ── 为什么是「把时长编进 plan_code」而不是给卡表加两列 ────────────────────────
# 加列这条路被三条独立证据堵死,不是风格偏好:
#   ① tests/test_jfvip_discipline.py::test_new_tables_all_guantai_prefixed 断言
#      userauth.py 内 `ALTER TABLE` **恒为零**;
#   ② userauth.py 自己写明:`CREATE TABLE IF NOT EXISTS` 对**已存在**的线上表
#      不补列,加列就得另写幂等迁移;
#   ③ jf_card_disabled_age_days 那条配置的说明把「表无 disabled_at 列且禁止
#      ALTER」当成既定前提 —— 这是全项目共识,不是本轮才发现的。
# 建新表(guantai_jf_card_ext)是合规的,但要在**行锁持有期**内多一次 JOIN/查询,
# 且 cards_purge / _janitor 删卡后会留下孤儿行 —— 用一列现成的 VARCHAR(16) 就能
# 表达的东西,不值得引入一张需要跨表一致性维护的新表。
#
# ── 形态 ─────────────────────────────────────────────────────────────────────
#       @H<九法VIP小时>              例:@H720      = VIP 720 小时,不送小叮当
#       @H<九法VIP小时>D<小叮当小时>  例:@H720D720  = VIP 720h + 小叮当 720h
#
# 长度:'@H' + 5 位 + 'D' + 5 位 = 13 字符,`plan_code VARCHAR(16)` 装得下且有余量
# (INLINE_MAX_HOURS=87600 是 5 位数,这一条由 test 钉死,改上限时会当场告诉你)。
#
# ── 命名空间是**两端同时保留**的,歧义在结构上不可能发生 ──────────────────────
#   · plans() 主动剔除任何「码形态命中内联语法」的配置档位(并大声告警);
#   · resolve_plan() 对 '@' 开头的码只走内联解析,不去查配置。
# 只做其中一端(例如「配置优先、查不到再当内联」)会留下一个真实的坑:运维日后
# 新增一个恰好叫 `@H720` 的配置档位,就会**静默改写**所有已发出的 @H720 卡的时长。
# 卡已经在用户手里,这种改写没有任何补救手段 —— 与本文件顶部为「历史 JF 前缀
# 不可下线」写下的是同一条论证。
#
# ⚠ 诚实边界(不藏):若某台部署**当前**就有一个码形如 `@H<数字>` 的配置档位,
#   升级后它会被 plans() 剔除,已发出的该码卡将按内联语义解释时长。'@' 不是任何
#   正常档位码的写法(既有全部是 d3/m1/m3 这类小写短词),现实中撞上的概率为零;
#   仍给出一条一行的升级前自检,见 JFVIP-SYSTEM.md §6.4:
#       SELECT DISTINCT plan_code FROM guantai_jf_card WHERE plan_code LIKE '@%';
#
# ── 内联卡的 amount 恒 0,且**绝不接受调用方传金额** ──────────────────────────
# guantai_jf_grant_log.amount 是经营看板(overview() 的今日/7日金额)的数据源。
# 定制时长卡没有网关流水,谎报一个金额就是往看板里注水。这与 jfpay 的头号安全
# 不变量「金额单一真源:一律取网关响应的 price,绝不回退到用户请求金额,回退即
# 凭空入账漏洞」是**同一条**,只是换了个入口 —— 外部 API 传金额就是那个漏洞。
# 故:卡密开通数照涨、金额不涨,口径诚实。要看定制卡的量,按 plan_code 前缀筛。
# ══════════════════════════════════════════════════════════════════════════════
INLINE_PREFIX = "@"
# 单卡时长硬顶(小时)。87600h = 10 年 —— 这不是业务上限而是**手滑护栏**:
# 「720」多打一个 0 变成 7200(10 个月)尚可挽回,再多打一个就是 72000(8 年),
# 而 VIP 时长一经写入 guantai_jf_vip 就只能靠 revoke_by_admin 逐笔往回扣。
# 运营真需要更长的,走配置档位(那条路有管理台二次确认)。
INLINE_MAX_HOURS = 87600
_INLINE_RE = re.compile(r"^@H(\d{1,6})(?:D(\d{1,6}))?$")


def is_inline_code(code: Any) -> bool:
    """该码是否**形态上**属于内联命名空间。

    注意判据是「形态命中」而不是「以 @ 开头」:命名空间保留得越窄,升级时误伤
    存量配置的面就越小。`@vip` 这种码不会被剔除,只有真正长得像内联时长的才会。
    """
    return bool(_INLINE_RE.match(str(code or "").strip()))


def inline_code(jf_hours: int, dd_hours: int = 0) -> str:
    """(小时数)→ 内联码。与 parse_inline 互为逆,round-trip 由测试钉死。

    dd_hours=0 时**不写 D 段** —— 少 6 个字符是次要的,主要是让人一眼看出
    「这张卡不送小叮当」,而不是去数一个 D0 后缀。
    """
    jf = max(0, int(jf_hours or 0))
    dd = max(0, int(dd_hours or 0))
    return f"{INLINE_PREFIX}H{jf}" + (f"D{dd}" if dd > 0 else "")


def parse_inline(code: Any) -> Optional[dict]:
    """内联码 → 与 plans() 逐字段同形的档位 dict;不是内联码回 None。

    形态同构是刻意的:`_grant_tx` / 管理台 / 前端拿到的都是同一种 dict,
    调用方**不需要**知道这个档位是配置来的还是内联来的 —— 只有一处需要区分
    (前台价格卡不展示内联档位),那一处读 plans() 而不是 resolve_plan()。

    price 恒 0:见本节顶部「amount 恒 0」的论证。
    """
    m = _INLINE_RE.match(str(code or "").strip())
    if m is None:
        return None
    jf, dd = int(m.group(1)), int(m.group(2) or 0)
    # 上限在**解析侧**也钳一次,而不只在生成侧。理由与 userauth.sso_link_url 的
    # 「守卫放在唯一使用点」同源:库里可能已有一张手工改库塞进去的 @H999999 卡,
    # 生成侧的校验对它毫无约束力,只有解析侧的判断才拦得住。
    # 超限**拒绝解析**(回 None ⇒ 兑换时 card_plan_gone)而不是截断到上限 ——
    # 截断会让用户拿到一张与卡面不符的卡,而 fail-closed 只是让他去找客服。
    if jf <= 0 or jf > INLINE_MAX_HOURS or dd > INLINE_MAX_HOURS:
        return None
    return {"code": inline_code(jf, dd), "name": _inline_name(jf),
            "price": 0.0, "jfHours": jf, "ddHours": dd,
            "tag": "定制", "inline": True}


def _inline_name(hours: int) -> str:
    """给内联档位一个人话名字(管理台列表 / 流水里直接可读,不必让人心算)。

    口径与前端 jvDur() **逐条**对齐 —— 两边显示不一致比不显示更让人怀疑数据。
    ★ 实测抓到过一次真实分歧:本函数初版漏了 8928h / 4464h 两个特例,于是同一张
      年卡在管理台卡密页显示「定制 1 年」、在开通流水里显示「定制 12 个月」。
      而 8928h 恰恰是做年卡最可能填的数,不是够不着的边界。
      分档表任何一侧改动都必须同改另一侧,test_inline_name_matches_frontend_jvdur_buckets
      逐档钉死。
    """
    h = max(0, int(hours or 0))
    if h == 8928:
        return "定制 1 年"
    if h == 4464:
        return "定制 半年"
    if h and h % 744 == 0:
        return f"定制 {h // 744} 个月"
    if h and h % 24 == 0:
        return f"定制 {h // 24} 天"
    return f"定制 {h} 小时"


def _norm_int(raw: Any, lo: int, hi: int) -> Optional[int]:
    """把任意 JSON 输入收敛成 [lo, hi] 内的整数;非法回 None(调用方据此回 400)。

    **不做静默截断**:越界显式拒绝。与 ids_overflow() 那条注释是同一件事 ——
    截断是替调用方做一个他不知道的决定,而这里决定的是「用户买到多少时长」
    或「一次发出多少张卡」。

    bool 必须先挡:True 是 int 的子类,`hours: true` 会被 int() 收成 1,
    而调用方本意多半是别的东西 —— 静默发出一张 1 小时的卡是最坏的结果。
    浮点也必须挡:`int(72.9)` 静默变 72,而 JSON 里写 72.9 的人显然不想要 72。
    """
    if isinstance(raw, bool) or isinstance(raw, float):
        return None
    if isinstance(raw, str):
        raw = raw.strip()
        if not raw:
            return None
    try:
        v = int(raw)
    except (TypeError, ValueError):
        return None
    return v if lo <= v <= hi else None


def norm_hours(raw: Any, *, allow_zero: bool = False) -> Optional[int]:
    """小时数口径:[1, INLINE_MAX_HOURS](allow_zero 时下界放到 0,供 ddHours 用)。"""
    return _norm_int(raw, 0 if allow_zero else 1, INLINE_MAX_HOURS)


def norm_count(raw: Any) -> Optional[int]:
    """发卡张数口径:[1, _MAX_CARDS_PER_BATCH]。

    与 norm_hours 共用同一个整数净化内核 —— 两处各写一份 bool/浮点/字符串的
    防御,迟早有一处在维护里漏掉一条(本文件为 norm_ids 记下的三条实机缺陷
    ①ValueError→500 ②字符串被当可迭代 ③无上限,全都是这一类)。
    """
    return _norm_int(raw, 1, _MAX_CARDS_PER_BATCH)


# ══════════════════════════════════════════════════════════════════════════════
# 字符集安全化(4.2.9)—— gbk 表存不下的字符
# ------------------------------------------------------------------------------
# ★ 本轮审计**实地复现**的一整族缺陷。用户库全表 `CHARSET=gbk`(随 tb_user 的
#   历史字符集),aiomysql 以 charset=gbk 建连;任何含 emoji 等 GBK 表示不了的
#   字符的参数,在**编码 SQL 时**就抛 UnicodeEncodeError —— 语句根本没发出去。
#
#   项目对此早有定论,但**只在一处**落实了(userauth.sso_link_note 与
#   orders_page 的 user_name 分支)。本轮真库逐条实测,发现同族的另外十处全部裸奔:
#
#     读/筛选(异常逃逸 ⇒ 管理台 HTTP 500,admin_api 层零 try/except):
#       cards_page(batch=/card=/plan_code=) · cards_batch_stat(batch=)
#       orders_page(order_no=/plan_code=/status=) · grants_page(source=)
#     写:
#       cards_disable(batch=) · cards_set_note(note=) ⇒ HTTP 500
#       _gen_cards_code(batch/note/operator) ⇒ 被兜底 except 吞成 "db",
#         管理台回 400、**外部发卡 API 回 503** —— 那是彻头彻尾的误导:
#         库好好的,只是渠道名里有个表情符号,而调用方拿到 503 会去查数据库。
#
#   最后这一条尤其要紧:发卡 API 面向机器,渠道名/备注是**调用方自由文本**,
#   撞上的概率远高于管理台手输。
#
# ── 两套口径,各有其正确性,绝不能混用 ────────────────────────────────────────
#   · **写** → 不可表示字符换 '?'(gbk_text)。沿用 sso_link_note 的裁决:
#     「备注只是审计信息,不值得让操作失败」。
#   · **筛选** → 该条件命中零行(gbk_ok 回 False,调用方补 1=0)。沿用
#     orders_page 对 user_name 的裁决:「gbk 表示不了的用户名 ≡ 查无此人」。
#     筛选侧**绝不能**换 '?' —— 那会静默去查一个**不同的串**,屏幕上显示
#     「没有记录」,而人只会以为这批卡不存在。
#   两者是自洽的:写入侧已把 emoji 换成 '?',故库里不可能存在含 emoji 的值,
#   「查不到」是事实而非妥协。
# ══════════════════════════════════════════════════════════════════════════════
# 实现下沉到 userauth —— 它拥有连接与字符集,且登录/注册/邀请码那几条路径同样
# 需要同一套规则。两层各写一份的话,迟早有一份在维护里漏掉一条。
# ★ 本轮审计实测:userauth 侧 5 处(_issue_session / invite_lookup /
#   invites_generate / blocks_set / _mint_sso_ticket)同族裸奔,其中
#   invite_lookup 由**未登录用户**可控 —— 那正是必须共用一份实现的理由。
_charset = userauth._charset
gbk_ok = userauth.gbk_ok
gbk_text = userauth.gbk_text


_plans_cache: Dict[str, Any] = {"raw": None, "val": []}


def plans() -> List[dict]:
    """档位表(热更:配置中枢改 jf_vip_plans 后下次调用即生效)。

    fail-safe:JSON 配坏时回**空表**而不是抛 —— 后果是前端看不到价格卡(可见的
    故障),而不是整个观测台 500(不可见的连带故障)。管理台的 validator 会在
    应用前拦下配坏的值,这里只是最后一道兜底。

    4.2.9:**剔除**码形态命中内联语法的配置档位 —— 内联命名空间的两端保留之一,
    理由见本文件「内联档位码」节。剔除必须大声告警:静默丢一个档位,运维会看到
    前台少一张价格卡却无从知道为什么。
    """
    c = getattr(userauth.UA, "cfg", None)
    raw = getattr(c, "jf_vip_plans", "") if c is not None else ""
    if _plans_cache["raw"] == raw:
        return _plans_cache["val"]
    out: List[dict] = []
    try:
        data = json.loads(raw or "[]")
        seen = set()
        for it in (data if isinstance(data, list) else []):
            code = str(it.get("code") or "").strip()
            if not code or code in seen:
                continue
            if is_inline_code(code):
                print(f"[九法VIP] ⚠️ 档位 code={code!r} 命中内联时长命名空间,已忽略。"
                      f"`@H<小时>[D<小时>]` 形态为「指定时长卡密」保留,"
                      f"配置档位请改用其它码(如 d3/m1/m3)")
                continue
            seen.add(code)
            out.append({
                "code": code,
                "name": str(it.get("name") or code),
                "price": round(float(it.get("price") or 0), 2),
                "jfHours": int(it.get("jfHours") or 0),
                "ddHours": int(it.get("ddHours") or 0),
                "tag": str(it.get("tag") or ""),
            })
        out = [p for p in out if p["price"] > 0 and p["jfHours"] > 0]
    except Exception:                  # noqa: BLE001
        print("[九法VIP] ⚠️ 档位表 jf_vip_plans 解析失败,已回退空表(前端将看不到价格卡)")
        out = []
    _plans_cache["raw"], _plans_cache["val"] = raw, out
    return out


def plan_of(code: str) -> Optional[dict]:
    """**只查配置档位**。前台价格卡、下单(jfpay)走这一条 —— 内联档位是运营侧
    的东西,不该出现在用户能选的商品列表里。"""
    code = str(code or "").strip()
    for p in plans():
        if p["code"] == code:
            return p
    return None


def resolve_plan(code: Any) -> Optional[dict]:
    """**时长解析的唯一出口**:内联码 → 就地算;其余 → 查配置档位。

    ⚠️ 兑换路径(_grant_tx)必须走这个函数而不是 plan_of() —— 全项目只此一处
    需要「两种档位都认」。判定顺序不是随意的:内联在前,使得配置档位在任何情况下
    都无法遮蔽一个已经发出去的内联码(见本节「命名空间两端保留」的论证)。
    """
    return parse_inline(code) or plan_of(code)


def _now_price_days(plan: dict) -> int:
    """透传给网关 create 的 days 字段(仅作商品描述,不参与任何续期计算)。"""
    return max(1, int(plan.get("jfHours") or 0) // 24)


# ══════════════════════════════════════════════════════════════════════════════
# 限频(Redis 优先,进程内兜底 —— fail-closed)
# ══════════════════════════════════════════════════════════════════════════════
async def _incr_window(key: str, win_s: int) -> int:
    """窗口计数 +1,返回当前计数。Redis 不可用时退化为进程内计数(不放开)。"""
    r = getattr(userauth.UA, "redis", None)
    if r is not None:
        try:
            n, _t = await wincount.incr_redis(r, key, int(win_s))   # 5.2.0:原子(旧写法可留永久键)
            return int(n)
        except Exception:              # noqa: BLE001 —— 落进程内兜底
            pass
    now = time.time()
    cnt, exp = _mem_rate.get(key, (0, 0.0))
    if now > exp:
        cnt, exp = 0, now + win_s
    cnt += 1
    _mem_rate[key] = (cnt, exp)
    if len(_mem_rate) > 4096:          # 有界:清掉已过窗的
        for k in [k for k, v in _mem_rate.items() if v[1] < now]:
            _mem_rate.pop(k, None)
    return cnt


async def order_rate_ok(uid: int) -> bool:
    """下单限频。九法面向**任意注册用户(含 free 档)**,不限频等于替人白刷网关。"""
    c = userauth.UA.cfg
    cap = int(getattr(c, "jf_order_rate_hourly", 20))
    if cap <= 0:
        return True
    return await _incr_window(K_ORDER_RATE.format(uid=int(uid)), 3600) <= cap


async def reconcile_rate_ok(uid: int) -> bool:
    """对账兜底限频(4.2.2 新增)。

    为什么单独一把:reconcile 单次最多向网关查 `jf_reconcile_max`(默认 10)笔,
    **放大倍数是下单的 10 倍**。不限频等于给任意注册用户(含 free 档)一个
    白刷网关的杠杆 —— 与 `order_rate_ok` 当初的设立理由完全同源,只是杠杆更长。

    前端 `payRecover()` 只在本机有「在途单标记」时才调,正常用户一天撞不到几次;
    这一条是防**手搓客户端绕过本机标记**。默认 12 次/小时(≈5 分钟一次),
    对真实救回场景绰绰有余。
    """
    c = userauth.UA.cfg
    cap = int(getattr(c, "jf_reconcile_rate_hourly", 12))
    if cap <= 0:
        return True
    return await _incr_window(K_RECONCILE_RATE.format(uid=int(uid)), 3600) <= cap


async def redeem_fail_ok(uid: int) -> bool:
    """卡密兑换是否还在失败配额内(只在**失败**时计数,成功不消耗)。"""
    c = userauth.UA.cfg
    cap = int(getattr(c, "jf_redeem_fail_hourly", 10))
    if cap <= 0:
        return True
    r = getattr(userauth.UA, "redis", None)
    key = K_REDEEM_FAIL.format(uid=int(uid))
    if r is not None:
        try:
            return int(await r.get(key) or 0) < cap
        except Exception:              # noqa: BLE001
            pass
    cnt, exp = _mem_rate.get(key, (0, 0.0))
    return not (time.time() <= exp and cnt >= cap)


async def redeem_fail_bump(uid: int) -> None:
    await _incr_window(K_REDEEM_FAIL.format(uid=int(uid)), 3600)


# ══════════════════════════════════════════════════════════════════════════════
# 外部发卡 API 的闸(4.2.9)—— 机器对机器,只认 API Key
# ------------------------------------------------------------------------------
# 面向发卡平台 / 分销系统 / 自动化补偿脚本:一次 HTTP 调用直接拿到 N 张指定时长
# 的卡密。与管理台端点(会话 + CSRF 双提交)物理隔离,两套凭据互不通用。
#
# ⚠️⚠️ **与 userauth.sso_link_key_ok 口径相反,这一条必须写清楚** ⚠️⚠️
#   那边「未配置密钥 → 恒 True」,论证是:不配密钥时该端点的能力**不超过**已经公开的
#   /api/auth/login(5.2.0 起共用同一套计数与加码判定),故不构成新增敞口。
#   本端点**没有这条退路** —— 它是纯粹的价值创造:调一次就凭空多出 N 张可兑换
#   的 VIP 时长,没有任何已公开端点与之等价。故:
#
#         密钥未配置 ⇒ 端点整体 503(不是"放行")。
#
#   这不是保守,是本项目「不配置即不存在」纪律在**危险方向**上的正确取向:
#   开关默认关、密钥默认空,两道都得显式配上才可能发出一张卡。
#
# 密钥长度下限在**使用点**守卫而不是只在配置校验器上,理由与 sso_link_url 的
# 那段注释同源:本项可从管理台热改,值可能经 ENV / 管理页覆盖 / 代码直写三条路
# 进来,守卫放在唯一使用点则三条路都拦得住,放在校验器只拦管理页那一条。
# ══════════════════════════════════════════════════════════════════════════════
K_CARD_API_RATE = "guantai:jf:cardapi:rate"        # 调用限频(全局按 Key,非按 IP)
K_CARD_API_BADKEY = "guantai:jf:cardapi:badkey:{ip}"   # 密钥错误按 IP 计
_CARD_API_KEY_MIN = 24                 # 密钥长度下限(openssl rand -hex 32 = 64 字符)
_CARD_API_BADKEY_10M = 20              # 每 IP 密钥错误上限 / 10 分钟(成功不计数)
_CARD_API_BADKEY_WIN_S = 600


def card_api_status() -> Dict[str, Any]:
    """带**原因**的启用判定 —— 与 status() 同款。

    为什么不是一个 bool:「配了却没反应」有四条不同的路径(VIP 体系没开、
    本开关没开、密钥没配、密钥太短),而运维在外部只看到一个 503。把原因显式化,
    端点据此回不同的 hint,管理台「值」视图也能直接告诉他卡在哪。
    """
    st = status()
    if not st["enabled"]:
        return {"enabled": False, "reason": st["reason"], "message": st["message"]}
    c = userauth.UA.cfg
    if not bool(getattr(c, "jf_card_api_enabled", False)):
        return {"enabled": False, "reason": "api_off",
                "message": "外部发卡 API 总开关未开(参数中心 · 九法VIP · "
                           "userauth.jf_card_api_enabled,或 STA_JF_CARD_API=1)"}
    key = str(getattr(c, "jf_card_api_key", "") or "").strip()
    if not key:
        return {"enabled": False, "reason": "no_key",
                "message": "外部发卡 API 未设置密钥。本端点是纯价值创造(调一次即"
                           "凭空多出可兑换时长),没有「不配即等价于已公开端点」"
                           "这条退路,故密钥为空时整体关闭。生成:openssl rand -hex 32"}
    if len(key) < _CARD_API_KEY_MIN:
        return {"enabled": False, "reason": "weak_key",
                "message": f"外部发卡 API 密钥过短(须 ≥{_CARD_API_KEY_MIN} 字符,"
                           f"当前 {len(key)})。短密钥可被离线爆破,而本端点发出的"
                           f"每一张卡都是真金白银。生成:openssl rand -hex 32"}
    return {"enabled": True, "reason": "ok", "message": "外部发卡 API 已启用"}


def card_api_enabled() -> bool:
    return card_api_status()["enabled"]


def card_api_key_ok(header: str) -> bool:
    """`Authorization: Bearer <key>` 校验(常数时间比较)。纯函数。

    **未配置/过短一律回 False** —— 与 sso_link_key_ok 相反,见本节顶部论证。
    该分支实际上够不着(端点先被 card_api_status() 挡在 503),但闸必须自身闭合:
    不能指望"上面那个人记得先判一下"。
    """
    want = str(getattr(userauth.UA.cfg, "jf_card_api_key", "") or "").strip()
    if not want or len(want) < _CARD_API_KEY_MIN:
        return False
    got = str(header or "").strip()
    if got[:7].lower() == "bearer ":
        got = got[7:].strip()
    if not got:
        return False
    return hmac.compare_digest(got.encode("utf-8", "ignore"),
                               want.encode("utf-8", "ignore"))


def card_api_ip_ok(ip: str) -> bool:
    """可选的来源 IP 白名单(逗号分隔 CIDR;留空 = 不限)。

    密钥是第一因素,这是可选的第二因素 —— 发卡平台的出口 IP 通常是固定的,
    把它写死能让一次密钥泄漏不至于立刻变成无限发卡。默认留空,不给不需要的人
    添麻烦(用户明确要求「只需要 API Key」)。

    来源 IP 走 client_ip() 的「可信代理」口径(5.2.0):直连部署伪造 XFF 无效,
    反代覆盖或追加 XFF 都能取到真实客户端;IPv6 按 /64 分桶。

    ⚠ 配了却全填错(没有一条合法 CIDR)时 **fail-closed**:回 False 而不是
      "当成没配"。白名单是安全设施,配错的正确表现是把自己关在门外,
      而不是悄悄敞开 —— 后者会让运维以为白名单在生效。
    """
    allow = str(getattr(userauth.UA.cfg, "jf_card_api_ip_allow", "") or "").strip()
    if not allow:
        return True
    try:
        addr = ipaddress.ip_address(str(ip or "").strip())
    except ValueError:
        return False
    for cidr in (c.strip() for c in allow.split(",") if c.strip()):
        try:
            if addr in ipaddress.ip_network(cidr, strict=False):
                return True
        except ValueError:
            continue                    # 单条写错跳过;全写错则下面回 False
    return False


async def card_api_rate_ok() -> bool:
    """发卡调用限频(次/小时,**全局按密钥**而不是按 IP)。

    为什么不按 IP 分桶:本端点是服务端对服务端,正常调用方就那么一两个出口 IP,
    按 IP 分桶等于按调用方分桶 —— 而我们真正要限的是「这把密钥一小时最多能
    发多少次卡」。密钥泄漏后攻击者从任意 IP 打过来,按 IP 分桶给他的是**每个 IP
    一份配额**,等于没限。

    0 = 不限(留给确有大批量需求的部署;默认 60 次/时,单次最多 500 张 ⇒
    理论上限 3 万张/时,已远超任何真实发卡节奏)。
    """
    cap = int(getattr(userauth.UA.cfg, "jf_card_api_rate_hourly", 60) or 0)
    if cap <= 0:
        return True
    return await _incr_window(K_CARD_API_RATE, 3600) <= cap


async def card_api_badkey(ip: str, bump: bool) -> Optional[int]:
    """按 IP 统计**密钥错误**次数。`bump=False` 只读探(不计数),True 才累加。
    命中上限 → 返回剩余锁定秒数。形态与 userauth._sso_link_badkey 一致。

    只对失败计数、成功不计数:正常调用方永远不会发错密钥,故对它零影响;
    对爆破者却是硬闸。这一条同时压掉了「40 发错误密钥 = 40 行日志」那类
    日志放大(打的是与别的项目共用的生产 MySQL)。
    """
    key = K_CARD_API_BADKEY.format(ip=userauth._ip_bucket(ip))       # 5.2.0:IPv6 按 /64
    r = getattr(userauth.UA, "redis", None)
    if r is not None:
        try:
            if not bump:
                n = await r.get(key)
                if n is not None and int(n) >= _CARD_API_BADKEY_10M:
                    ttl = await r.ttl(key)
                    return max(1, int(ttl if ttl and ttl > 0
                                      else _CARD_API_BADKEY_WIN_S))
                return None
            n, _t = await wincount.incr_redis(r, key, _CARD_API_BADKEY_WIN_S)
            return (max(1, _CARD_API_BADKEY_WIN_S)
                    if n >= _CARD_API_BADKEY_10M else None)
        except Exception:              # noqa: BLE001 —— Redis 抖动:落进程内兜底
            pass
    now = time.time()
    cnt, exp = _mem_rate.get(key, (0, 0.0))
    if now > exp:
        cnt, exp = 0, now + _CARD_API_BADKEY_WIN_S
    if not bump:
        return max(1, int(exp - now)) if cnt >= _CARD_API_BADKEY_10M else None
    cnt += 1
    _mem_rate[key] = (cnt, exp)
    if len(_mem_rate) > 4096:          # 有界(与 _incr_window 同款)
        for k in [k for k, v in _mem_rate.items() if v[1] < now]:
            _mem_rate.pop(k, None)
    return max(1, int(exp - now)) if cnt >= _CARD_API_BADKEY_10M else None


# ══════════════════════════════════════════════════════════════════════════════
# 外部发卡的幂等(4.2.9 审计补)—— 网络重试不得重复发卡
# ------------------------------------------------------------------------------
# ★ 本轮审计**实地复现**的自查缺陷,是本轮最严重的一条:
#     完全相同的请求体连调两次 → 库里 10 张卡,卡号不重叠。
#   真实触发路径不是恶意,是最普通的网络抖动:发卡平台 POST,请求已到达、500 张
#   卡已落库,而**响应在回程丢了**;平台按常规重试 → 又 500 张。多出来的卡在渠道
#   手里**同样可兑换**,是直接资损;更糟的是事后**无法分辨**哪 500 张是重复的
#   (卡号不同、批次相同、时间戳相邻)。
#
#   项目对此早有明文标准,写在建表注释里:
#       gateway_order_no VARCHAR(64) COMMENT '网关订单号(**幂等的物理底线**)'
#       UNIQUE KEY uk_order (gateway_order_no)
#   订单侧有物理底线,而我给发卡 API 一条都没有 —— 这是设计缺口,不是疏忽。
#
# ── 为什么不用 batch 当幂等键 ────────────────────────────────────────────────
# 直觉上「同一批次不重复发」很省事,但语义是错的:「往同一批次追加 10 张」是完全
# 正当的运营动作,拿 batch 当幂等键会把它变成静默的空操作 —— 比重复发卡更难排查。
#
# ── 为什么不在库侧做 ─────────────────────────────────────────────────────────
# 库侧要原子只能靠唯一索引,而 guantai_jf_card 唯一可用的是 uk_card(card)。借它做
# 原子 claim 意味着插一行「哨兵卡」,那行会出现在卡密列表、计数、导出、清扫判据里,
# 得改五六处才藏得干净 —— 为一个辅助机制引入横跨全模块的特例,风险远超收益;
# 且项目禁止 ALTER,加不了新的唯一索引。
#
# ── Redis 不可用时 **fail-closed**,这一条是刻意的 ───────────────────────────
# 别处的风控组件(限流、badkey)在 Redis 抖动时退化为**进程内**计数,理由是
# 「风控组件故障不放开」。这里不能照抄:web 是多 worker 进程,重试极可能落到
# **另一个进程**,进程内兜底对幂等**毫无作用**。而调用方既然显式给了幂等键,
# 就是在依赖这个保证 —— 悄悄不提供是最坏的结果:他会放心地重试。
#
# ⚠ 载荷含卡号,与「审计不落卡号」看似矛盾,实则不同:审计是**另一个库、长期
#   保存**的冗余副本;这里是**同信任域、24 小时 TTL**,且幂等重放**必须**回同一
#   批卡号(否则调用方永远拿不到第一次那批卡),属功能必需而非冗余。
# ══════════════════════════════════════════════════════════════════════════════
K_CARD_API_IDEM = "guantai:jf:cardapi:idem:{h}"
_IDEM_TTL_S = 86400                    # 24h:覆盖任何现实中的重试窗
_IDEM_PENDING = "\x00PENDING:"          # 后接参数指纹


def normalize_issue(body: Dict[str, Any]) -> Tuple[str, dict]:
    """把发卡请求体收敛成**规范形态**。纯函数、零 IO。返回 (错误码|'', 规范参数)。

    ★ 为什么必须抽出来:指纹与真正的发卡**必须用同一个解析器**。
      本轮审计实测的缺陷:指纹原先取的是**原始请求体**,于是
          {"hours":24}  与  {"hours":24,"count":1}
      语义完全相同(count 默认就是 1)却指纹不同 —— 调用方的 HTTP 客户端在重试时
      多序列化了一个默认字段,就会收到一个**假的** 409 idempotency_key_reused,
      他会去查自己根本不存在的键复用 bug。{"ddHours":0} 与 {"batch":""} 同理。
      两处各写一份解析,这类分歧只会越来越多。

    ⚠ batch 为空时**不在这里补自动批次号** —— 自动批次号含时间戳,补了以后同一个
      请求隔几秒重试就变成"不同请求"。规范化只做「语义等价的收敛」,不做「填默认值
      产生新信息」。自动批次号在 _gen_cards_code 里生成,那才是它该出现的地方。
    """
    plan = str(body.get("plan") or "").strip()
    raw_hours = body.get("hours", body.get("jfHours"))
    has_hours = raw_hours is not None and str(raw_hours).strip() != ""
    if is_inline_code(plan):
        # ★ 第五轮审计自查:上一轮把发卡入口收敛到 resolve_plan 之后,`plan` 字段
        #   **悄悄开始接受内联码**了 —— 而公开函数 gen_cards() 用的仍是 plan_of,
        #   对同一个串回 None。同一个 "plan" 在代码库里有了两种含义,正是本项目
        #   最反对的那类不一致(「改前缀时只改一处、两边悄悄不一致」)。
        #   一件事只留一种写法:指定时长走 hours,plan 只认配置档位码。
        return "plan_is_inline", {
            "hint": "指定时长请用 hours(小时数),plan 只接受配置档位码"}
    if plan and has_hours:
        return "both_plan_and_hours", {
            "hint": "plan(配置档位)与 hours(指定时长)只能给一个"}
    if not plan and not has_hours:
        return "missing_plan_or_hours", {
            "hint": "须给 plan(配置档位码)或 hours(九法VIP 小时数)其一"}
    count = norm_count(body.get("count", 1))
    if count is None:
        return "bad_count", {"limit": _MAX_CARDS_PER_BATCH,
                             "hint": f"张数须为 1–{_MAX_CARDS_PER_BATCH} 的整数"}
    out = {"count": count,
           "batch": str(body.get("batch") or "").strip(),
           "note": str(body.get("note") or "")}
    if plan:
        out["plan"] = plan
        return "", out
    jf = norm_hours(raw_hours)
    if jf is None:
        return "bad_hours", {"limit": INLINE_MAX_HOURS}
    dd_raw = body.get("ddHours")
    dd = 0 if dd_raw is None else norm_hours(dd_raw, allow_zero=True)
    if dd is None:
        return "bad_dd_hours", {"limit": INLINE_MAX_HOURS}
    out["plan"] = inline_code(jf, dd)     # 规范形态直接就是最终档位码
    return "", out


def idem_fingerprint(body: Dict[str, Any]) -> str:
    """请求的**语义指纹**。走 normalize_issue,与发卡路径同一份解析。

    ★ 审计实测的缺陷:同一个幂等键配**不同参数**再调一次,原实现静默回第一次的
      结果 —— 调用方发 `hours=8760,count=500` 却拿到 `24h × 1 张`,而且 HTTP 200。
      他会以为 500 张年卡发出去了,实际一张都没发。这是**静默的错误答案**,
      正是本项目在 CSV 导出、norm_ids、overview 归零三处反复批判过的同一类东西。

      幂等的语义是「同一个请求重放一次」,不是「同一个键随便配什么参数」。
      键被复用于不同参数 ⇒ **调用方有 bug**,必须当场告诉他,而不是替他掩盖。
      (与 Stripe 的 Idempotency-Key 语义一致。)

    batch / note 也计入:同键不同批次同样是调用方在复用键,一并拦下。
    """
    err, norm = normalize_issue(body)
    if err:
        # 参数本就非法:指纹取错误码本身。这样两次同样写错的请求指纹一致(占位不会
        # 因为一个必然失败的请求而被无谓地烧掉),而写对之后指纹变了 ⇒ 走新流程。
        # (端点在参数校验失败时还会 idem_abort,双保险。)
        norm = {"__err__": err}
    raw = json.dumps(norm, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest()[:16]


def idem_key_norm(raw: Any) -> str:
    """幂等键归一化:只留可打印 ASCII、限长 64。

    剔非 ASCII 不是洁癖 —— 键只进 Redis 不进 gbk 表,但它由调用方自由给定,
    限死字符集能让键在日志/排查时可读可复制,也杜绝长度与编码的意外。
    """
    return re.sub(r"[^\x20-\x7e]", "", str(raw or "").strip())[:64]


def _idem_slot(key: str) -> str:
    return K_CARD_API_IDEM.format(
        h=hashlib.sha256(key.encode("utf-8", "ignore")).hexdigest()[:32])


def _idem_read(val: Any, fp: str) -> Tuple[str, Any]:
    """把 Redis 里的原值解释成 (状态, 载荷)。纯函数,探针与占位共用一份解释,
    两处各写一遍迟早对不上。"""
    if isinstance(val, (bytes, bytearray)):
        val = val.decode("utf-8", "ignore")
    if not val:
        return "miss", None
    if val.startswith(_IDEM_PENDING):
        got = val[len(_IDEM_PENDING):]
        if got and fp and got != fp:
            return "conflict", got
        return "in_flight", None
    try:
        data = json.loads(val)
    except Exception:                       # noqa: BLE001 —— 值被写坏:当没有
        return "miss", None
    if fp and data.get("_fp") and data["_fp"] != fp:
        return "conflict", data["_fp"]
    return "done", data


async def idem_peek(key: str, fp: str) -> Tuple[str, Any]:
    """**只读**探针:不写任何东西。返回 miss/done/in_flight/conflict/unavailable。

    ★ 为什么必须先有一个只读探针,而不是直接 idem_begin:
      ① **重放不该消耗发卡限频配额** —— 实测:cap=3 时连续 4 次重放得到
         [200,429,429,429]。真实场景里平台对 20 笔订单各重试 3 次就打满默认
         cap(60),而重放**根本没创造任何价值**。
      ② 若把 idem_begin 提到限频之前来解决①,限频拒绝时会留下一个 PENDING 占位,
         该键此后 24 小时一直回 409 —— 用一个更难查的故障换掉一个好查的。
      故:只读探在最前(不写、不耗配额)→ 限频 → 原子占位。
      「探」与「占位」之间的窄窗由 SET NX 兜住(见 idem_begin 的返回值分支)。
    """
    r = getattr(userauth.UA, "redis", None)
    if r is None:
        return "unavailable", None
    try:
        return _idem_read(await r.get(_idem_slot(key)), fp)
    except Exception as e:                  # noqa: BLE001
        print(f"[九法VIP] ⚠️ 幂等探针失败(Redis): {type(e).__name__}: {e}")
        return "unavailable", None


async def idem_begin(key: str, fp: str) -> Tuple[str, Any]:
    """原子占位。返回 (状态, 载荷):
        new         首次 —— 载荷是 slot(供 finish/abort)
        done        窄窗内别人刚完成 —— 载荷是那次的完整响应体
        in_flight   上一次仍在进行(或已崩溃未收尾)
        conflict    **同键配了不同参数** —— 载荷是先前的指纹
        unavailable Redis 不可用 ⇒ 保证不成立,端点必须拒绝
    """
    r = getattr(userauth.UA, "redis", None)
    if r is None:
        return "unavailable", None
    slot = _idem_slot(key)
    try:
        if await r.set(slot, _IDEM_PENDING + fp, nx=True, ex=_IDEM_TTL_S):
            return "new", slot
        st, data = _idem_read(await r.get(slot), fp)
        return ("in_flight" if st == "miss" else st), data
    except Exception as e:                  # noqa: BLE001
        print(f"[九法VIP] ⚠️ 幂等占位失败(Redis): {type(e).__name__}: {e}")
        return "unavailable", None


async def idem_finish(slot: str, payload: dict) -> None:
    """把结果写进占位。写失败只告警不抛 —— 卡**已经发出去了**,此时再报错会让
    调用方以为失败而重试,那正是幂等要防的事。"""
    with contextlib.suppress(Exception):
        await getattr(userauth.UA, "redis").set(
            slot, json.dumps(payload, ensure_ascii=False), ex=_IDEM_TTL_S)


def idem_stamp(payload: dict, fp: str) -> dict:
    """把指纹盖进要存的载荷。单独一个函数是为了让「存什么」只有一处定义 ——
    端点直接 payload["_fp"]=fp 的话,重放返回体里会多出这个内部字段。"""
    return {**payload, "_fp": fp}


async def idem_abort(slot: str) -> None:
    """发卡失败:释放占位,让调用方能用**同一个键**重试。
    不释放的话,一次参数写错就把这个键永久烧掉 24 小时。"""
    with contextlib.suppress(Exception):
        await getattr(userauth.UA, "redis").delete(slot)


# ══════════════════════════════════════════════════════════════════════════════
# 卡密
# ══════════════════════════════════════════════════════════════════════════════
def gen_card_no() -> str:
    a = "".join(secrets.choice(CARD_ALPHABET) for _ in range(CARD_ALPHA_N))
    d = "".join(secrets.choice(CARD_DIGITS) for _ in range(CARD_DIGIT_N))
    return f"{CARD_PREFIX}{a}{d}"


def norm_card(raw: Any) -> str:
    """卡密归一化:trim + 去分隔符 + 转大写。**刻意不做字符纠错。**

    卡密字符集排除 I/O/0/1 是为了减少**人眼歧义**,不是为了让程序去猜。
    自动纠错(0→O 之类)有把 A 的卡纠成 B 的卡的真实风险 —— 一旦发生就是
    「用户 A 的卡被 B 用掉」的资损事故,而收益只是省用户几秒。
    用户输入含 0/1/I/O 时,由调用方给出明确提示(见 web 层文案)。
    """
    s = _CARD_STRIP.sub("", str(raw or "")).upper()
    return s[:32]


def card_shape_hint(card: str) -> str:
    """卡密形态不合法时的**可操作**提示(小白用户友好:告诉他错在哪)。"""
    if not card:
        return "请输入卡密"
    if set(card) & set("01IO"):
        return "卡密不含数字 0 和 1、不含字母 I 和 O,请核对后重输"
    if not card.startswith(_CARD_PREFIXES):
        # 只报新前缀:历史前缀仍能兑换,但不该再教用户去输它
        return f"卡密应以 {CARD_PREFIX} 开头,请核对"
    if len(card) != len(CARD_PREFIX) + CARD_ALPHA_N + CARD_DIGIT_N:
        return f"卡密应为 {len(CARD_PREFIX) + CARD_ALPHA_N + CARD_DIGIT_N} 位,请核对"
    return "卡密格式不正确,请核对"


def card_valid_shape(card: str) -> bool:
    return bool(_CARD_RE.match(card or ""))


def ids_overflow(raw: Any) -> bool:
    """提交的 id 个数是否超过单次上限。

    ★ 复审自查揪出的**我自己引入**的缺陷:norm_ids 对超限输入是**静默截断**。
      前端的选择集跨页保留(按 id 存),运维在第 1 页选 500 张、第 2 页再选 500 张
      即可轻松凑到 1000 —— 提交后 norm_ids 悄悄砍到 500,而 cards_purge 回报的
      requested 是**砍完之后**的 500,于是 skipped 恒为 0,前端弹出
      「已永久删除 500 张」。**另外 500 张原封不动,屏幕上零迹象。**

      这正是本项目在 CSV 导出那处写过的同一句话:「静默少 450 张,文件里毫无迹象」。
      我写了 requested/affected 双回报来防静默差异,却在上一层自己造了一个。

      对策:超限**显式拒绝**而不是截断。截断是替用户做决定,而这个决定他不知道。
    """
    return (isinstance(raw, (list, tuple, set))
            and not isinstance(raw, (str, bytes))
            and len(raw) > _MAX_IDS_PER_CALL)


def norm_ids(raw: Any) -> List[int]:
    """把任意 JSON 输入收敛成合法、去重、有界的 id 列表。

    ★ 4.2.8 修复的真实缺陷(实机复现):`cards_disable(ids=)` 原先直接
      `[int(i) for i in ids]`,三处都会出事 ——

        ① `ids: ["a"]`  → int("a") 抛 ValueError,FastAPI 未捕获 ⇒ **HTTP 500**;
        ② `ids: "abc"`  → 传字符串而非数组时 len() 得 3,**把字符当成了 id**;
        ③ 长度无上限    → 10 万个 id 拼出 10 万占位符的 SQL,撑爆包大小/内存。

      这三条此前只因「前端从未发送 ids」而未被触发 —— 是一个被前端缺陷偶然
      掩盖的后端缺陷。本轮把勾选框接出来的同时必须一并关掉,否则等于把一个
      已知的 500 通道推上生产。

    **非法项丢弃而非抛异常**:这是管理台端点,一个手滑的 payload 不该变成 500;
    真正需要被察觉的是「请求 N 个、实际生效 M 个」这一差异,由调用方回报
    requested/affected 两个数说清楚(见 cards_purge)。
    """
    if isinstance(raw, (str, bytes)) or not isinstance(raw, (list, tuple, set)):
        return []                       # 字符串是可迭代的,必须在这里挡掉(缺陷②)
    out: List[int] = []
    for x in list(raw)[:_MAX_IDS_PER_CALL]:
        if isinstance(x, bool):         # bool 是 int 的子类,True 会变成 id=1
            continue
        try:
            v = int(x)
        except (TypeError, ValueError):
            continue                    # 丢弃而非崩溃(缺陷①)
        if 0 < v <= 9223372036854775807:
            out.append(v)
    return sorted(set(out))             # 去重 + 定序:SQL 形态稳定,便于复现与审计


async def gen_cards(count: int, plan_code: str, batch: str, note: str,
                    operator: str) -> Tuple[str, dict]:
    """按**配置档位**批量发卡。返回 (错误码|'', {cards:[...], batch})。"""
    if not enabled():
        return "disabled", {}
    plan = plan_of(plan_code)
    if plan is None:
        return "bad_plan", {}
    return await _gen_cards_code(count, plan["code"], batch, note, operator)


async def gen_cards_hours(count: int, jf_hours: Any, dd_hours: Any,
                          batch: str, note: str, operator: str) -> Tuple[str, dict]:
    """按**指定时长**批量发卡(4.2.9)。返回 (错误码|'', {...})。

    与 gen_cards() 的唯一差别是档位码从哪来:那边查配置表,这边就地编码进卡行。
    落库路径、查重轮次、往返次数、批次/备注语义**逐字节共用** —— 刻意不复制
    一份发卡实现出来:两条发卡路径一旦分家,查重逻辑或 INSERT 列就会在某次
    维护里悄悄不一致,而那类缺陷要等到「有两张一样的卡」时才会被发现。

    dd_hours 默认 0 而不是「等于 jf_hours」,这是**刻意的 fail-safe**:赠送小叮当
    是全项目唯一一条对 tb_user 的写,且 revoke_by_admin 明确**不回收**已送出的
    小叮当时长(那部分已进父项目的账)。少送可以补,多送收不回来 —— 默认值必须
    站在可挽回的那一侧。管理台面板把「同时赠送等量小叮当」做成一个勾选框,
    常用场景仍是一次点击。
    """
    if not enabled():
        return "disabled", {}
    jf = norm_hours(jf_hours)
    dd = norm_hours(dd_hours, allow_zero=True) if dd_hours is not None else 0
    if jf is None:
        return "bad_hours", {"limit": INLINE_MAX_HOURS}
    if dd is None:
        return "bad_dd_hours", {"limit": INLINE_MAX_HOURS}
    return await _gen_cards_code(count, inline_code(jf, dd), batch, note, operator)


async def gen_cards_by_code(plan_code: str, count: int, batch: str, note: str,
                            operator: str) -> Tuple[str, dict]:
    """按**已规范化的档位码**发卡(配置档位码或内联时长码皆可)。

    这是 HTTP 层的入口:normalize_issue() 已经把 plan/hours 两种写法收敛成同一个
    档位码,故此处不再关心调用方原本给的是哪种。与 gen_cards / gen_cards_hours
    共用同一条落库实现 —— 三个入口零复制。
    """
    if not enabled():
        return "disabled", {}
    return await _gen_cards_code(count, plan_code, batch, note, operator)


async def _gen_cards_code(count: int, plan_code: str, batch: str, note: str,
                          operator: str) -> Tuple[str, dict]:
    """发卡的**唯一**落库实现(档位码由调用方定好,本函数不关心它从哪来)。

    ★ 往返账本(复审重写):初版是 N+1 —— 每张卡一次 SELECT 查重 + 一次 INSERT。
      用户库**在公网**(项目自述 RTT 数十毫秒级),500 张 = 1000 次往返 ≈ 50 秒,
      管理台请求会直接超时。现改为**批量**:
        ① 本地一次性生成 n 个互不相同的候选(纯 CPU,零往返);
        ② 一条 `WHERE card IN (...)` 查出已占用的(1 次往返);
        ③ 只对撞上的重新生成,最多复查 3 轮(6.4e10 空间下第一轮几乎必然全过);
        ④ 一条多值 INSERT 落库(1 次往返)。
      稳态 **2 次往返**,与批量大小无关。
    """
    plan = resolve_plan(plan_code)
    if plan is None:
        return "bad_plan", {}
    # 落库前最后一道:码必须装得进 plan_code VARCHAR(16)。内联码在
    # INLINE_MAX_HOURS 下最长 13 字符,这里是纯防御 —— 若将来有人调大上限而
    # 忘了这条,宁可在发卡时当场报错,也绝不让 MySQL 静默截断成一个**含义完全
    # 不同的短码**(gbk 表 + 非 STRICT 模式下截断是不报错的,那会发出一批
    # 时长与卡面不符的卡)。
    if len(plan["code"]) > 16:
        return "code_too_long", {"code": plan["code"], "limit": 16}
    n = max(1, min(int(count or 0), _MAX_CARDS_PER_BATCH))
    # gbk 安全化(4.2.9):三者都是自由文本且都进 CHARSET=gbk 的表。不清洗的话
    # 一个表情符号就让 INSERT 在**编码阶段**抛 UnicodeEncodeError,被下面的兜底
    # except 吞成 "db" ⇒ 外部发卡 API 回 503「库不可用」。库好好的。
    # operator 尤其不能漏:它由 client_ip() 拼出,而 client_ip 取的是
    # **调用方可控的** X-Forwarded-For 首跳 —— 那曾是一条自由文本通道(5.2.0 起 client_ip
    # 只回规范化后的合法 IP,该通道已关;gbk 安全化照留作纵深)。
    batch = gbk_text(str(batch or "").strip() or time.strftime("B%Y%m%d%H%M%S"), 32)
    note, operator = gbk_text(note, 100), gbk_text(operator, 32)

    made: set = set()
    for _round in range(3):
        need = n - len(made)
        if need <= 0:
            break
        # ① 本地生成候选(多要一点冗余,减少复查轮次)
        cand: set = set()
        guard = 0
        while len(cand) < need and guard < need * 40:
            guard += 1
            c = gen_card_no()
            if c not in made:
                cand.add(c)
        if not cand:
            break
        # ② 一次往返查重
        lst = sorted(cand)
        ph = ",".join(["%s"] * len(lst))
        try:
            rows = await userauth._q(
                f"SELECT card FROM guantai_jf_card WHERE card IN ({ph})",
                tuple(lst), fetch="all") or []
        except Exception as e:              # noqa: BLE001
            print(f"[九法VIP] 发卡查重失败: {e!r}")
            return "db", {}
        taken = {str(r["card"]) for r in rows}
        made |= (cand - taken)
    made_list = sorted(made)[:n]
    if len(made_list) < n:
        # 连撞三轮仍不够 —— 只可能是卡长/字符集被改小到不合理,或库里已近饱和
        return "collision", {"made": len(made_list)}

    # ③ 一次往返落库(多值 INSERT)
    vals = ",".join(["(%s,%s,%s,%s,%s,NOW())"] * len(made_list))
    args: list = []
    for c in made_list:
        args += [c, plan["code"], batch, note, operator]
    try:
        await userauth._q(
            "INSERT INTO guantai_jf_card (card, plan_code, batch, note, created_by, "
            f"created_at) VALUES {vals}", tuple(args))
    except Exception as e:                  # noqa: BLE001
        print(f"[九法VIP] 发卡落库失败: {e!r}")
        return "db", {}
    # 返回体带上**解析后的时长**:外部调用方(发卡平台)不该被迫自己去解析
    # 内联码语法才知道自己买到了多长 —— 那等于把一份契约实现复制到调用方,
    # 将来改语法两边就悄悄不一致。planName 同理,直接可印在卡面上。
    return "", {"cards": made_list, "batch": batch, "plan": plan["code"],
                "planName": plan["name"], "jfHours": int(plan["jfHours"]),
                "ddHours": int(plan["ddHours"]),
                "inline": bool(plan.get("inline")), "count": len(made_list)}


# ══════════════════════════════════════════════════════════════════════════════
# 列表分页的公共底座(4.2.6)
# ══════════════════════════════════════════════════════════════════════════════
# 三个列表页(卡密 / 订单 / 开通流水)原先各写一份 `page, size = max(1,…)` +
# 裸 `COUNT(*)`。本轮实测(MariaDB 10.11,按本文件 DDL 1:1 建表灌 40 万行,
# 用 FLUSH STATUS + Handler_read_* 数**真实扫描行数**,不看易受缓存干扰的墙钟)
# 暴露两处与表规模同阶的开销,且**每翻一页都要付一次**:
#
#   ① 裸 COUNT(*) 无筛选 ……………………………… 扫 400,000 行
#      —— 注意这不是深翻页才有的代价,**第 1 页就要付**。导出走
#      jvFetchAll 逐页取满,一次导出要付 10 次。
#   ② OFFSET 线性劣化 ……… 第 1 页 49 行 / 第 1000 页 49,999 行 / 末页 399,999 行
#      而 `page` 原先**只有下界钳制没有上界**(max(1, …)),
#      `?page=99999999` 可以直接让库倒扫整棵主键。
#
# 对策(两个都不需要任何 DDL —— 本项目纪律禁止对用户库做 ALTER,
# tests/test_jfvip_discipline.py 静态钉死):
#   · _count_capped():把 COUNT 封顶。实测缩放律 扫描行数 ≈ 2×cap,
#     与表总量**脱钩**:cap=50000 时恒为 100,002 行,表涨到 400 万也不变。
#     命中数超过 cap 时回 (cap, True),前端显示「50000+」并提示收窄筛选。
#   · _clamp_page():页码按「封顶后的总数」夹紧,越界页自动落到末页 ——
#     既堵掉上面那条 DoS,也顺手修掉「删记录后停在空页上」的老毛病。
#
# ⚠ 诚实边界:cap 只对**高命中率**筛选有效(它靠提前 LIMIT 停下)。
#   稀疏筛选(如无索引可用的时间范围)命中行少,LIMIT 根本停不下来,
#   代价仍由索引可用性决定 —— 见 orders_page() 内逐条谓词的实测注记。
_COUNT_CAP = 50000


async def _count_capped(table: str, where: str, args: tuple,
                        cap: int = _COUNT_CAP) -> Tuple[int, bool]:
    """封顶计数。返回 (总数, 是否被截断)。

    写法是 `SELECT COUNT(*) FROM (SELECT 1 FROM t WHERE … LIMIT cap+1) x` ——
    cap 是模块常量、经 int() 硬转,**不是用户输入**,内联进 SQL 无注入面;
    where 的值一律仍走 %s 参数化。
    """
    cap = max(1, int(cap))
    row = await userauth._q(
        f"SELECT COUNT(*) AS n FROM (SELECT 1 FROM {table} WHERE {where} "
        f"LIMIT {cap + 1}) x", args, fetch="one") or {}
    n = int(row.get("n") or 0)
    return (cap, True) if n > cap else (n, False)


def _clamp_page(page: int, size: int, total: int) -> int:
    """把页码夹进 [1, 末页]。total=0 时恒回第 1 页(空表不该显示「第 3 页」)。"""
    pages = max(1, -(-int(total) // max(1, int(size))))     # 向上取整
    return min(max(1, int(page or 1)), pages)


def _norm_dt(s: str, end_of_day: bool = False) -> str:
    """把 'YYYY-MM-DD' / 'YYYY-MM-DD HH:MM[:SS]'(允许 T 分隔)规范成 DATETIME 串。

    · 形态或**日历**不合法一律回 ''(= 该条件不生效),绝不把半截串塞进 SQL 让库去猜。
      ⚠ 这里必须用 datetime.date() 做真日历校验,不能只判 `1<=月<=12 且 1<=日<=31`:
        真库实测 `create_time >= '2026-02-30'`,MariaDB **既不报错也不返空**,
        而是把这个根本不存在的日期当成 2 月 29 与 3 月 1 之间的一个点来比较,
        回了 138,332 行。运维会拿到一份边界说不清的对账数据却毫无察觉 ——
        比直接报错危险得多。(2026-02-29 同理:2026 不是闰年。)
    · 只给日期时:起点补 00:00:00,终点补 23:59:59 ——「查 7 月 1 日到 7 月 3 日」
      的直觉是**含 3 号全天**,补 00:00:00 会把 3 号整天漏掉(对账少一天)。
      给到分钟时同理补到该分钟末尾(:59),口径一致 = 「含所给精度的整段」。
    · 刻意不带时区:本项目全链路用**库钟本地时刻**(见 admin.js jvParseTime 注),
      在这里补 Z 或做 UTC 换算会整体平移 8 小时。
    """
    t = str(s or "").strip().replace("T", " ")
    if not t:
        return ""
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})(?:[ ](\d{2}):(\d{2})(?::(\d{2}))?)?$", t)
    if not m:
        return ""
    y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try:
        _date(y, mo, d)                 # 真日历校验:2 月 30 日 / 非闰年 2 月 29 日在此被挡下
    except ValueError:
        return ""
    if m.group(4) is None:
        return f"{y:04d}-{mo:02d}-{d:02d} " + ("23:59:59" if end_of_day else "00:00:00")
    hh, mi = int(m.group(4)), int(m.group(5))
    ss = int(m.group(6) or (59 if end_of_day and m.group(6) is None else 0))
    if not (hh <= 23 and mi <= 59 and ss <= 59):
        return ""
    return f"{y:04d}-{mo:02d}-{d:02d} {hh:02d}:{mi:02d}:{ss:02d}"


def _norm_amount(s) -> Optional[float]:
    """金额边界:非数字/负数/超出 DECIMAL(10,2) 量程一律回 None(条件不生效)。"""
    if s is None or str(s).strip() == "":
        return None
    try:
        v = float(str(s).strip())
    except (TypeError, ValueError):
        return None
    if v < 0 or v > 99999999.99 or v != v:          # v!=v 拦 NaN
        return None
    return round(v, 2)


def _norm_bool01(s) -> Optional[int]:
    """三态开关:'' → None(不筛)、'0'/'1' → 0/1、其余 → None。"""
    t = str(s if s is not None else "").strip()
    return int(t) if t in ("0", "1") else None


@userauth.heavy_reads
async def cards_page(page: int, size: int, batch: str = "", status: str = "",
                     plan_code: str = "", card: str = "") -> dict:
    """卡密列表。

    ── card 前缀搜索(4.2.8 新增)────────────────────────────────────────────
    此前**没有任何按卡号查询的通道**:用户报「我的卡兑不了」,运维只能凭批次
    盲翻。而表上现成有 `UNIQUE KEY uk_card (card)` —— 精确查与前缀查都是索引
    直击、代价与表规模无关,零成本的能力白白躺着。

    与 orders_page 处理 order_no 的口径**逐字一致**:只做前缀 LIKE、转义 LIKE
    元字符。理由同处(那里已在真库量过:前缀 24 行走索引 / 中缀 200,048 行全表扫);
    另外不转义 % 的话,运维粘进一个含 % 的串会静默变成全表扫,而屏幕上完全
    看不出发生了什么。
    """
    page, size = max(1, int(page or 1)), max(1, min(int(size or 50), 500))
    where, args = ["1=1"], []
    # gbk 闸(4.2.9):三个自由文本谓词任一不可表示 ⇒ 该条件命中零行。
    # 口径与 orders_page 对 user_name 的既有裁决同源(「表示不了的 ≡ 查无此人」);
    # 不加这道闸时 UnicodeEncodeError 会一路穿到 FastAPI ⇒ 管理台 500(真库实测)。
    if not (gbk_ok(batch) and gbk_ok(plan_code) and gbk_ok(card)):
        where.append("1=0"); batch = plan_code = card = ""
    if batch:
        where.append("batch=%s"); args.append(str(batch)[:32])
    if plan_code == INLINE_PREFIX:
        # 4.2.9:单独一个 '@' = 「全部定制时长卡」。若不给这条通路,定制卡在
        # 档位下拉里**一个选项都没有**(下拉的数据源是 plans(),而内联档位刻意
        # 不在其中)—— 卡发得出去却筛不出来,与本文件为 orphan 第四态写下的
        # 「在任何筛选下都查不出来,是一个不可见的数据黑洞」是同一类问题。
        # 代价与既有 status 筛选同一量级(主键倒扫 + 过滤),不新增索引依赖。
        where.append("plan_code LIKE %s"); args.append(INLINE_PREFIX + "%")
    elif plan_code:
        where.append("plan_code=%s"); args.append(str(plan_code)[:16])
    card = norm_card(card)
    if card:
        esc = card[:32].replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        where.append("card LIKE %s"); args.append(esc + "%")
    if status == "unused":
        where.append("used_by=0 AND disabled=0")
    elif status == "used":
        where.append("used_by<>0")
    elif status == "disabled":
        where.append("disabled=1 AND used_by=0")
    elif status == "orphan":
        # ★ 4.2.8 补齐的第四态:`disabled=1 AND used_by<>0`。
        #   正常流程产生不了它(_grant_tx 对 disabled 卡直接回 card_disabled),
        #   但手工改库/历史脏数据会。而原来的三个筛选值互斥且**不覆盖**这一态 ——
        #   它在任何筛选下都查不出来,是一个不可见的数据黑洞。
        #   平时恒为 0;一旦非 0,就是有人绕过应用层动过库的信号。
        where.append("disabled=1 AND used_by<>0")
    w = " AND ".join(where)
    total, capped = await _count_capped("guantai_jf_card", w, tuple(args))
    page = _clamp_page(page, size, total)
    rows = await userauth._q(
        f"SELECT id, card, plan_code, batch, note, disabled, used_by, used_name, "
        f"used_at, created_by, created_at FROM guantai_jf_card WHERE {w} "
        f"ORDER BY id DESC LIMIT %s OFFSET %s",
        tuple(args) + (size, (page - 1) * size), fetch="all") or []
    return {"total": total, "totalCapped": capped, "page": page, "size": size,
            "items": [{"id": int(r["id"]), "card": r["card"], "plan": r["plan_code"],
                       "batch": r["batch"], "note": r["note"],
                       "disabled": bool(int(r["disabled"])),
                       "used": bool(int(r["used_by"])),
                       # ★ 4.2.8:SQL 一直取着 used_by,返回体却只映射成布尔的
                       #   `used`,**uid 被丢掉了**,只留一个 usedName 字符串。
                       #   用户名可重名、可变更,当不了跳转锚点 —— 从「卡」到「人」
                       #   的链路在此断开。补回 uid 后管理台可直接跳用户页。
                       "usedBy": int(r["used_by"]), "usedName": r["used_name"],
                       "usedAt": userauth._dt_iso(r["used_at"]) if r["used_at"] else "",
                       "createdBy": r["created_by"],
                       "createdAt": userauth._dt_iso(r["created_at"])} for r in rows]}


async def cards_disable(batch: str = "", ids: Optional[Any] = None,
                        undo: bool = False) -> int:
    """作废/恢复卡密。**只对未使用卡生效** —— 已兑换的卡改状态毫无意义
    (时长已经发出去了),且会让流水与卡状态自相矛盾。

    4.2.8:ids 一律先过 norm_ids() —— 见该函数说明的三条实机缺陷。
    """
    val = 0 if undo else 1
    idl = norm_ids(ids)
    if idl:
        ph = ",".join(["%s"] * len(idl))
        return int(await userauth._q(
            f"UPDATE guantai_jf_card SET disabled=%s WHERE used_by=0 AND id IN ({ph})",
            (val, *idl)) or 0)
    if batch:
        if not gbk_ok(batch):
            return 0                    # 没有这个批次 ⇒ 影响 0 行(而不是 500)
        return int(await userauth._q(
            "UPDATE guantai_jf_card SET disabled=%s WHERE used_by=0 AND batch=%s",
            (val, str(batch)[:32])) or 0)
    return 0


# ══════════════════════════════════════════════════════════════════════════════
# 卡密硬删除(4.2.8)
# ------------------------------------------------------------------------------
# 为什么必须有:`guantai_jf_card` 此前是全项目**唯一一张只增不减、无删除通道、
# 无保留策略**的业务表(_janitor 清 session/sso/login_log/reg_log 四张,不含它)。
# 而它与订单表/流水表有本质区别:后两者是**账本**(永不可删是正确的),卡密表是
# **资源池**(池子必须能排水)。把池子当账本管,是原设计的根因错误。
#
# 不排水的实际后果不是抽象的:
#   · 误发批次、联调测试批次只能作废后永久沉淀,列表被垃圾淹没、导出混入无效行;
#   · `_COUNT_CAP = 50000` 是硬封顶。单批上限 500 张,**100 个批次即触顶**,
#     此后卡密页总数永久显示 `50000+`,精确计数永久丢失。
#
# ── 手动删除的口径(4.2.9 变更:取消「先作废才能删」的阶梯)──────────────────
# 4.2.8 曾在 SQL 的 WHERE 里钉死一条不变量「永不删除一张仍可兑换的卡」
#       (NOT (used_by = 0 AND disabled = 0)),运维想删未使用卡必须先作废。
# 4.2.9 按运营要求取消该前置:**勾中即删**,三类状态一视同仁。
#
# 为什么可以取消:这条不变量当初防的是「误删已发往渠道的卡」,而它防的方式是
# 强制多走一步 —— 那是**流程摩擦**,不是权限边界。真正兜住误删的是另外四层,
# 它们一层都没动:
#   ① 能力总开关 `jf_card_purge_enabled` **默认关**,且被参数中心标为 🔴 危险项
#      (改它本身就要原样键入参数名二次确认);
#   ② 只接受**显式 id 清单**,永远没有按批次整批删的入口(见下方 ⚠);
#   ③ 前端必须键入 `DELETE` 二次确认,且确认框逐类列明本次会毁掉多少张可兑换卡;
#   ④ 被删卡号**完整**落 admin_audit 墓碑(不截断),写失败前端当场摊开卡号告警。
# 换言之:门槛从「库侧硬拦」下调为「人在环 + 全程留痕」,这是运营方的取舍。
#
# ⚠ 必须写明而不是含糊带过的后果:删掉一张**未使用且未作废**的卡,若它已印制、
#   已发往渠道、已在用户手里,则用户兑换时命中 card_not_found —— 花钱买的卡失效,
#   资损与客诉,且**没有任何补救手段**(卡已经发出去了,删了就是删了)。
#   需要可撤回的下架手段时,请用「作废选中」(disabled=1,可 undo),不要用删除。
#
# 为什么「已使用」可以删:真账不在这张表。每次兑换都在 guantai_jf_grant_log 落一
# 行完整流水(source='card'、ref=卡号、vip/due 的 before/after 四个时间戳)。卡表
# 对已用卡只是一份冗余索引,删掉它对账口径**逐字节不受影响**;且卡行消失后该卡号
# 再次兑换只会得到 card_not_found,不存在二次发放。
#
# 并发竞态(取消阶梯后新出现,必须说清):未作废的卡现在可以被删,而它同时是
# 可兑换的 —— 理论上存在「运维删、用户兑」撞在一起的窄窗。它是**安全的**:
# _grant_tx 走 `SELECT … FOR UPDATE`,两个事务串行化,先到者赢 ——
#   · 兑换先成:DELETE 等锁,随后删掉一张已 used 的行,时长已正常发放、流水已落;
#   · 删除先成:兑换 SELECT 不到行,回 card_not_found,不会发出任何时长。
# 两种结局都不产生「发了时长却没有流水」或「扣了卡却没发时长」的中间态。
#
# ⚠ 必须写明而不是假装不存在的残留风险:删除卡行会把该卡号**释放回可生成空间**
#   (gen_cards 的查重只对现存行)。理论上存在「旧卡号被重新生成并二次售出」的
#   碰撞。组合空间 24^6 × 8^6 ≈ 6.4e10,实际概率可忽略,但它不是零。
#
# ⚠ 刻意**不做**批次级整批删除。删除不可撤销,而批次是自由文本输入 —— 把破坏性
#   操作押在「运维不打错字」上是不可接受的。删除一律只接受**显式 id 清单**:
#   运维删掉的就是他屏幕上选中的那几行。真正的批量清理交给保留期自动清扫
#   (userauth._janitor),那条路径有明确的时间判据,不依赖任何人手输。
# ══════════════════════════════════════════════════════════════════════════════
# 「仍可兑换」的判据。**全项目只在这里写一次**,杜绝两处各写一遍然后悄悄不一致。
#
# 4.2.9 起它的角色从「删除的过滤器」变成「墓碑的分类器」:手动删除不再拦截可兑换
# 卡,但必须**如实分类并记录**毁掉的是哪一类 —— 拦不住的东西至少要数得清。
# (自动清扫 userauth._janitor 的判据仍写死在那边、仍只碰终态卡,不受本变更影响。)
_CARD_LIVE = "(used_by = 0 AND disabled = 0)"


async def cards_purge(ids: Optional[Any] = None) -> Tuple[str, dict]:
    """按 id 硬删卡密。返回 (错误码|'', {requested, affected, cards, skipped})。

    4.2.9:**勾中即删,不再要求先作废**。未使用 / 已作废 / 已兑换三类一视同仁,
    唯一的筛选条件就是 id 清单本身。取消阶梯的完整论证见上方设计注释。

    先 SELECT 快照再 DELETE:两条语句用**逐字相同**的 WHERE(现在只有 id IN),
    快照即墓碑证据,随响应回给前端,并写进 admin_audit。
    两句之间若有行被并发兑换,状态会变而行仍在,DELETE 照删 —— 快照里的 state
    可能略旧,但**卡号与张数恒准**,而墓碑要的正是这两样。
    skipped = 请求的 id 里根本不存在的那些(此前的语义是「不满足前置条件」,
    前置条件取消后它只剩「查无此卡」一种可能,数值口径不变)。
    """
    if not enabled():
        return "disabled", {}
    # 总开关(默认 False)。闸放在这里而不是端点里 —— 与逻辑同处,不可能被
    # 后来新增的第二个调用方绕开,也让它在模块级就可测。
    if not bool(getattr(userauth.UA.cfg, "jf_card_purge_enabled", False)):
        return "purge_disabled", {}
    # 超限显式拒绝,绝不截断 —— 截断会让「请求 N 张、实删 M 张」这个差异消失在
    # 净化环节,前端拿到的 requested 已经是砍完的数,skipped 恒为 0(见 ids_overflow)。
    if ids_overflow(ids):
        return "too_many", {"limit": _MAX_IDS_PER_CALL, "got": len(ids)}
    idl = norm_ids(ids)
    if not idl:
        return "bad_ids", {}
    ph = ",".join(["%s"] * len(idl))
    try:
        # `_CARD_LIVE` 从 WHERE 挪到 **SELECT 列**:判据文本一字未改、仍只写一处,
        # 但角色从「拦截」变成「取证」—— 「这张卡当时还能不能兑」由**库自己**在
        # 读出该行的同一条语句里判定,而不是拿回 Python 再推一遍。墓碑要的是
        # 库侧的事实,不是应用层的复述。
        # 别名 `live`:已比对 MariaDB 官方保留字表(sql-language-structure/reserved-words,
        # 含 Oracle 模式扩充表)—— LIVE 不在其中,无需反引号;与同文件既有的
        # `SUM(...) AS unused` 同一写法。`disabled` 列不再单独取:三态已可由
        # used_by + live 完整推出(used_by≠0→used;live=1→unused;否则→disabled),
        # 取而不用是死列。
        rows = await userauth._q(
            f"SELECT id, card, plan_code, batch, used_by, used_name, used_at, "
            f"{_CARD_LIVE} AS live "
            f"FROM guantai_jf_card WHERE id IN ({ph})",
            tuple(idl), fetch="all") or []
    except Exception as e:                  # noqa: BLE001
        print(f"[九法VIP] 删卡取证失败: {e!r}")
        return "db", {}
    # 三态如实分类。`unused` = 仍可兑换 —— 4.2.8 时它被 WHERE 挡在门外、根本不会
    # 出现在快照里,4.2.9 起它可以被删,于是**必须**在墓碑里单独成类:
    # 事后追责时「删了 3 张已作废」和「删了 3 张还能兑的」是完全不同的两件事。
    snap = [{"id": int(r["id"]), "card": str(r["card"]), "plan": r["plan_code"],
             "batch": r["batch"], "usedBy": int(r["used_by"]),
             "usedName": r["used_name"],
             "usedAt": userauth._dt_iso(r["used_at"]) if r["used_at"] else "",
             "state": ("used" if int(r["used_by"])
                       else "unused" if int(r["live"] or 0) else "disabled")}
            for r in rows]
    if not snap:
        # 一个 id 都没查到。**不是错误**,但必须与「删了 0 张」区分开 ——
        # 前端据此提示「这些卡已不存在(可能已被他人删除)」而不是笼统一句「已删除」。
        return "", {"requested": len(idl), "affected": 0, "cards": [], "skipped": len(idl)}
    hit = [s["id"] for s in snap]
    ph2 = ",".join(["%s"] * len(hit))
    try:
        n = int(await userauth._q(
            f"DELETE FROM guantai_jf_card WHERE id IN ({ph2})",
            tuple(hit)) or 0)
    except Exception as e:                  # noqa: BLE001
        print(f"[九法VIP] 删卡执行失败: {e!r}")
        return "db", {}
    return "", {"requested": len(idl), "affected": n, "cards": snap,
                "skipped": len(idl) - n}


@userauth.heavy_reads
async def cards_batch_stat(batch: str) -> dict:
    """**单个**批次的三态计数。

    ★ 复审自查揪出的我自己引入的性能缺陷:初版是 `GROUP BY batch` 带三个 SUM,
      在 MariaDB 10.11 真库上按本文件 DDL 1:1 建表灌 40 万行 / 800 批次实测
      (FLUSH STATUS + Handler_read_* 数真实扫描行数)——

          GROUP BY batch + SUM(...)  ……… 扫 400,000 行(全表)
          DISTINCT batch LIMIT 200   ……… 扫 100,000 行
          递归 CTE 索引跳跃法         ……… 扫 320,000,000 行(优化器不下推,灾难)
          **WHERE batch=? 单批**      ……… 扫       500 行  ← 本函数

      而初版是**每次渲染卡密页都调一次**,包括每一次翻页。这与本项目当初设立
      _count_capped 要避免的正是同一件事(「每翻一页都要付一次与表规模同阶的开销」)。

      拆分后:真正需要计数的时刻只有一个 —— 运维已经选定某个批次、正要对它做
      「作废整批」。那时只查这一个批次,走 idx_batch,代价与表规模无关。
      代价 = 该批次的卡数,与总表规模脱钩。
    """
    if not enabled() or not batch or not gbk_ok(batch):
        return {}                       # gbk 表示不了的批次名 ≡ 没有这个批次
    row = await userauth._q(
        "SELECT COUNT(*) AS n, "
        "  SUM(used_by = 0 AND disabled = 0) AS unused, "
        "  SUM(used_by <> 0)                 AS used, "
        "  SUM(disabled = 1 AND used_by = 0) AS disabled "
        "FROM guantai_jf_card WHERE batch=%s", (str(batch)[:32],), fetch="one") or {}
    return {"batch": str(batch)[:32], "total": int(row.get("n") or 0),
            "unused": int(row.get("unused") or 0), "used": int(row.get("used") or 0),
            "disabled": int(row.get("disabled") or 0)}


@userauth.heavy_reads
async def cards_batches(limit: int = 200) -> List[dict]:
    """批次名清单(**惰性**:仅在运维显式索取时调,绝不在每次渲染时调)。

    只回批次名,不带计数 —— 计数走 cards_batch_stat(单批 500 行)。
    实测代价 100,000 行(= LIMIT × 每批卡数),与总表规模无关但**与批次大小成正比**;
    批次名可被重复使用,单个批次并无 500 张的上限,故这条仍不便宜,必须惰性调用。

    为什么保留它:把自由文本输入框变成可选清单能消除打错批次名的风险。但要诚实
    说明这只是**便利**而非安全底线 —— 「作废整批」是可逆的(有「恢复整批」),
    真正不可逆的删除已被设计成只收显式 id 清单,那条路径上根本没有批次名参与。
    """
    if not enabled():
        return []
    lim = max(1, min(int(limit or 200), 500))
    rows = await userauth._q(
        f"SELECT DISTINCT batch FROM guantai_jf_card ORDER BY batch LIMIT {lim}",
        (), fetch="all") or []
    return [{"batch": str(r["batch"] or "")} for r in rows]


async def cards_set_note(ids: Optional[Any] = None, note: str = "") -> int:
    """批量改备注。`note` 列现成,零 DDL。

    渠道调整、批次改用途需要留痕,而 note 原先只在发卡时写入、此后只读。
    改动本身写 admin_audit(含改后值),故此处不再另立流水。
    """
    if not enabled():
        return 0
    idl = norm_ids(ids)
    if not idl:
        return 0
    ph = ",".join(["%s"] * len(idl))
    return int(await userauth._q(
        f"UPDATE guantai_jf_card SET note=%s WHERE id IN ({ph})",
        (gbk_text(note, 100), *idl)) or 0)


# ══════════════════════════════════════════════════════════════════════════════
# 开通事务 —— 全项目唯一的 tb_user 写点
# ══════════════════════════════════════════════════════════════════════════════
async def _grant_tx(uid: int, user_name: str, jf_hours: int, dd_hours: int,
                    source: str, ref: str, plan_code: str = "", amount: float = 0.0,
                    operator: str = "") -> Tuple[str, dict]:
    """把一次开通/撤销原子落地。返回 (错误码|'', 结果)。

    锁序固定(全路径一致,不存在反向锁 ⇒ 不会死锁):
        ① 凭据行(guantai_jf_order / guantai_jf_card)
        ② tb_user 行
        ③ guantai_jf_vip 行
    全程**零网络调用**(网关交互一律在事务之外 —— 见 jfpay.py)。

    幂等:①在行锁下复核 credited/used_by,重复调用直接返回 {"already": True}。
    """
    pool = await userauth._ensure_pool()
    if pool is None:
        raise ConnectionError(userauth.UA.init_error or "userdb pool unavailable")
    c = userauth.UA.cfg
    conn = await pool.acquire()
    try:
        await conn.begin()
        try:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                # ── ① 锁凭据行 + 幂等复核 ────────────────────────────────
                cred_id = 0
                if source == "order":
                    await cur.execute(
                        "SELECT id, status, credited, plan_code, jf_hours, dd_hours, "
                        "amount FROM guantai_jf_order "
                        "WHERE gateway_order_no=%s AND user_id=%s FOR UPDATE",
                        (ref, uid))
                    row = await cur.fetchone()
                    if row is None:
                        await conn.rollback()
                        return "order_not_found", {}
                    if row["status"] == "paid" or int(row["credited"]) == 1:
                        # 自愈:正常情况 credited=1 必然 status='paid'(二者同事务写);
                        # 极端并发理论上可留下 credited=1 但 status≠paid —— 此处在
                        # 持锁下把状态补正,**只改状态、绝不再动时长**。
                        # (形态继承自 fanxing-admin `_settle_paid` 的实证需求。)
                        if row["status"] != "paid":
                            await cur.execute(
                                "UPDATE guantai_jf_order SET status='paid', "
                                "pay_time=IFNULL(pay_time, NOW()) WHERE id=%s",
                                (row["id"],))
                            await conn.commit()
                        else:
                            await conn.rollback()
                        return "", {"already": True}
                    cred_id = int(row["id"])
                    # ★ 时长以**订单行的快照**为准,不读当前配置 ——
                    #   管理台改价/改时长后,已下单未支付的在途单必须按原口径开通。
                    jf_hours = int(row["jf_hours"] or 0)
                    dd_hours = int(row["dd_hours"] or 0)
                    plan_code = str(row["plan_code"] or plan_code)
                    amount = float(row["amount"] or amount)
                    # ★★ fail-closed(复审补):快照为 0 绝不能继续 ★★
                    #    若放行,订单会被标成 paid+credited(幂等哨兵),而 VIP 只加 0 小时
                    #    —— **用户付了钱什么都没得到,且这笔永远无法重试**(下次查单直接
                    #    命中"已开通"分支)。可能成因:滚动升级期建表早于加列、手工改库、
                    #    历史脏数据。宁可报错让运维介入,也绝不静默吞掉一笔真实付款。
                    if jf_hours <= 0:
                        await conn.rollback()
                        print(f"[九法VIP] ⚠️ 订单 {ref} 的时长快照异常"
                              f"(jf_hours={jf_hours}),拒绝开通以免静默漏发。"
                              f"请人工核对该订单后用管理台手动开通。")
                        return "order_hours_invalid", {}
                elif source == "card":
                    await cur.execute(
                        "SELECT id, plan_code, disabled, used_by FROM guantai_jf_card "
                        "WHERE card=%s FOR UPDATE", (ref,))
                    row = await cur.fetchone()
                    if row is None:
                        await conn.rollback()
                        return "card_not_found", {}
                    if int(row["disabled"]):
                        await conn.rollback()
                        return "card_disabled", {}
                    if int(row["used_by"]):
                        await conn.rollback()
                        return "card_used", {}
                    cred_id = int(row["id"])
                    plan_code = str(row["plan_code"] or "")
                    # 4.2.9:resolve_plan 而非 plan_of —— 内联时长码(@H720D720)
                    # 就地算出时长,配置档位照旧查表。**零额外往返、零网络调用**,
                    # 行锁持有时长逐字节不变(test_grant_tx_has_no_network_call
                    # 与本文件顶部的「锁序固定」论证都不受影响)。
                    # 顺带的好处:内联卡在结构上不可能命中下面的 card_plan_gone ——
                    # 它的时长写在卡自己身上,没有任何人能把它从配置里删掉。
                    _p = resolve_plan(plan_code)
                    if _p is None:
                        # 卡的档位已被从配置里删除 —— 这正是「code 一经售出不可删除」
                        # 那条纪律要防的事。fail-closed:拒绝兑换而不是猜一个时长。
                        # (内联码走到这里只有一种可能:手工改库塞进了超过
                        #  INLINE_MAX_HOURS 的畸形码 —— 同样 fail-closed。)
                        await conn.rollback()
                        return "card_plan_gone", {}
                    jf_hours, dd_hours = int(_p["jfHours"]), int(_p["ddHours"])
                    amount = float(_p["price"])

                # ── ② 锁 tb_user 行(防 read-modify-write 的 lost update)──
                await cur.execute(
                    f"SELECT id, user_name, due_time FROM `{c.user_table}` "
                    f"WHERE id=%s FOR UPDATE", (uid,))
                urow = await cur.fetchone()
                if urow is None:
                    await conn.rollback()
                    return "user_gone", {}
                due_before = urow.get("due_time")
                user_name = user_name or str(urow.get("user_name") or "")

                # ── ③ 锁 VIP 行 ──────────────────────────────────────────
                await cur.execute("SELECT vip_until FROM guantai_jf_vip "
                                  "WHERE user_id=%s FOR UPDATE", (uid,))
                vrow = await cur.fetchone()
                vip_before = vrow.get("vip_until") if vrow else None

                # ── ④ 九法VIP 续期 ───────────────────────────────────────
                # GREATEST(NOW(), vip_until) + N 小时 —— 全在 SQL 侧用**库钟**算,
                # 与 login/validate 的 `vip_until > NOW()` 同一把钟。
                # 语义:未过期从原到期点顺延(不亏时长),已过期从此刻起算。
                # ON DUPLICATE 是单语句原子的,配合上面的 FOR UPDATE 行锁,
                # 并发两笔开通被串行,两笔时长都不会丢。
                # 4.2.3:原判据是 `>= 0`,于是 jf_hours==0 会落进"开通"分支,
                # 对一个**从未开通过**的用户 INSERT 出一行 vip_until=NOW()、
                # first_at=NOW()(真库实测坐实)—— 首开统计从此有假样本。
                # 0 小时本就无事可做,直接不写。
                if jf_hours > 0:
                    await cur.execute(
                        "INSERT INTO guantai_jf_vip "
                        "  (user_id, vip_until, first_at, total_hours, updated_at) "
                        "VALUES (%s, DATE_ADD(NOW(), INTERVAL %s HOUR), NOW(), %s, NOW()) "
                        "ON DUPLICATE KEY UPDATE "
                        "  vip_until   = DATE_ADD(GREATEST(NOW(), vip_until), "
                        "                         INTERVAL %s HOUR), "
                        "  total_hours = total_hours + %s, updated_at = NOW()",
                        (uid, jf_hours, jf_hours, jf_hours, jf_hours))
                elif jf_hours < 0:
                    # ★ 4.3.0 实地核查修补:撤销前必须确认**这个人有 VIP 行**。
                    #
                    #   原实现直接 UPDATE。用户若从未开通过(guantai_jf_vip 无行),
                    #   该语句影响 0 行 —— 什么都没撤 —— 但下面第 ⑦ 步照旧 INSERT
                    #   一条 jf_hours=-N 的流水,函数回 err='',管理台弹绿色「已撤销」。
                    #   实测(进程内跑通 _grant_tx 抓真实 SQL)确认三件事同时发生:
                    #     · UPDATE 影响行数 = 0
                    #     · 写入流水 jf_hours=-240 / vip_before=None / vip_after=None
                    #     · COMMIT 且无错误码
                    #   guantai_jf_grant_log 是本项目宣告的**唯一对账口径**,而前端
                    #   导出 CSV 时刻意放行负数正是为了让运维对 jf_hours 做 SUM ——
                    #   一条对应不到任何真实变更的 -N 会永久让这个和偏掉,且事后
                    #   无从分辨哪几条是幽灵。更直接的伤害是:屏幕上说「已撤销」,
                    #   而实际什么也没发生 —— 这正是本项目反复写的「静默的差异比
                    #   报错危险得多」「谎报比不报危险」。
                    #
                    #   判据用 `vrow is None` 而**不是** cur.rowcount:
                    #   MySQL 默认(未开 CLIENT_FOUND_ROWS)的 affected_rows 是
                    #   「实际改变的行数」而非「匹配到的行数」,一次值恰好未变的
                    #   合法撤销同样会回 0 —— 拿它当「行不存在」的判据会误伤。
                    #   而 vrow 就在上面第 ③ 步持锁读出来了,是**直接事实**,零额外往返。
                    if vrow is None:
                        await conn.rollback()
                        return "no_vip_row", {}
                    # 撤销:往回扣,但绝不早于 NOW()(不制造"过去的到期时间"这种脏态)
                    await cur.execute(
                        "UPDATE guantai_jf_vip SET "
                        "  vip_until = GREATEST(NOW(), "
                        "                       DATE_ADD(vip_until, INTERVAL %s HOUR)), "
                        "  updated_at = NOW() WHERE user_id=%s",
                        (jf_hours, uid))

                # ── ⑤ 赠送小叮当:全项目**唯一一处**针对 tb_user 的写 ─────
                # ⚠️⚠️ 本语句由 tests/test_jfvip_discipline.py 白名单钉死:
                #      针对该表的 UPDATE 全项目恰好一处,且必须在 _grant_tx 体内。
                #      新增任何第二处写点(哪怕看起来很合理)都会当场变红。
                #      口径与 fanxing-admin `_next_due` 逐字一致(max(now,due)+N)。
                if dd_hours > 0:
                    await cur.execute(
                        f"UPDATE `{c.user_table}` SET "
                        f"  due_time = DATE_ADD(GREATEST(NOW(), due_time), "
                        f"                      INTERVAL %s HOUR) "
                        f"WHERE id = %s", (dd_hours, uid))

                # ── ⑥ 翻转凭据 ───────────────────────────────────────────
                if source == "order":
                    await cur.execute(
                        "UPDATE guantai_jf_order SET status='paid', credited=1, "
                        "pay_time=NOW() WHERE id=%s", (cred_id,))
                elif source == "card":
                    await cur.execute(
                        "UPDATE guantai_jf_card SET used_by=%s, used_name=%s, "
                        "used_at=NOW() WHERE id=%s", (uid, user_name[:50], cred_id))

                # ── ⑦ 落流水(唯一对账口径:before/after 四个时间戳全留) ──
                await cur.execute("SELECT vip_until FROM guantai_jf_vip WHERE user_id=%s",
                                  (uid,))
                vip_after = (await cur.fetchone() or {}).get("vip_until")
                await cur.execute(f"SELECT due_time FROM `{c.user_table}` WHERE id=%s",
                                  (uid,))
                due_after = (await cur.fetchone() or {}).get("due_time")
                await cur.execute(
                    "INSERT INTO guantai_jf_grant_log (user_id, user_name, source, ref, "
                    "plan_code, amount, jf_hours, dd_hours, vip_before, vip_after, "
                    "due_before, due_after, operator, created_at) "
                    "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW())",
                    (uid, user_name[:50], source, str(ref)[:64], str(plan_code)[:16],
                     round(float(amount or 0), 2), int(jf_hours), int(dd_hours),
                     vip_before, vip_after, due_before, due_after,
                     str(operator or "")[:32]))
            await conn.commit()
            return "", {"vipUntil": userauth._dt_iso(vip_after) if vip_after else "",
                        "dueTime": userauth._dt_iso(due_after) if due_after else "",
                        "jfHours": int(jf_hours), "ddHours": int(dd_hours),
                        "planCode": plan_code}
        except BaseException:
            with contextlib.suppress(Exception):
                await conn.rollback()
            raise
    finally:
        pool.release(conn)


async def _after_grant(uid: int) -> None:
    """开通后置:亚秒级刷新全网档位缓存(不撤销会话 —— 用户刚付完钱)。"""
    with contextlib.suppress(Exception):
        await userauth.refresh_tier(int(uid))


# ── 三条对外开通入口 ──────────────────────────────────────────────────────────
async def grant_by_order(uid: int, user_name: str, order_no: str) -> Tuple[str, dict]:
    err, out = await _grant_tx(uid, user_name, 0, 0, "order", order_no)
    if not err:
        await _after_grant(uid)
    return err, out


async def grant_by_card(uid: int, user_name: str, card: str) -> Tuple[str, dict]:
    err, out = await _grant_tx(uid, user_name, 0, 0, "card", card)
    if not err:
        await _after_grant(uid)
    return err, out


async def grant_by_admin(uid: int, user_name: str, plan_code: str,
                         operator: str, note: str = "") -> Tuple[str, dict]:
    p = plan_of(plan_code)
    if p is None:
        return "bad_plan", {}
    err, out = await _grant_tx(uid, user_name, int(p["jfHours"]), int(p["ddHours"]),
                               "admin", str(note or "")[:64], p["code"], 0.0, operator)
    if not err:
        await _after_grant(uid)
    return err, out


async def revoke_by_admin(uid: int, user_name: str, hours: int,
                          operator: str, note: str = "") -> Tuple[str, dict]:
    """撤销 N 小时 VIP。**刻意不回收已赠送的小叮当时长** ——
    那部分已经进了父项目的账,回收会造成两个系统的口径打架;
    要处理请在繁星后台单独操作(此边界已在 JFVIP-SYSTEM.md 声明)。"""
    # 4.2.3:hours<=0 没有任何意义,且 -abs(0)==0 会走进开通分支。在入口拦下,
    # 与 grant_by_admin 的 bad_plan 同款(admin_api 已把 err 原样回 400)。
    if int(hours) <= 0:
        return "bad_hours", {}
    err, out = await _grant_tx(uid, user_name, -abs(int(hours)), 0, "revoke",
                               str(note or "")[:64], "", 0.0, operator)
    if not err:
        await _after_grant(uid)
    return err, out


# ══════════════════════════════════════════════════════════════════════════════
# 查询
# ══════════════════════════════════════════════════════════════════════════════
async def vip_state(uid: int) -> dict:
    """某用户的 VIP 状态(库钟判定)。管理台与用户端共用同一口径。"""
    row = await userauth._q(
        "SELECT vip_until, first_at, total_hours, (vip_until > NOW()) AS alive "
        "FROM guantai_jf_vip WHERE user_id=%s", (int(uid),), fetch="one")
    if not row:
        return {"vipUntil": "", "vipDays": None, "alive": False, "totalHours": 0}
    iso = userauth._dt_iso(row.get("vip_until"))
    return {"vipUntil": iso, "vipDays": userauth._due_days(iso),
            "alive": bool(int(row.get("alive") or 0)),
            "firstAt": userauth._dt_iso(row.get("first_at")),
            "totalHours": int(row.get("total_hours") or 0)}


async def grants_page(page: int, size: int, uid: int = 0, source: str = "",
                      date_from: str = "", date_to: str = "") -> dict:
    """开通流水 —— **唯一对账口径**。

    ── 为什么必须有时间区间(4.3.0 实地核查补)────────────────────────────────
    本函数原先只支持 uid / source 两个条件。而对账天然是**按期**做的:
    项目自己在 orders_page 里写过「运维按月对账是刚需」,订单页也为此配齐了
    下单起/止两个日期框 —— 偏偏被宣告为「唯一对账口径」的这张表查不了时间。

    更硬的证据是**建表时就为它留了索引**,而这两把索引一直没人用:
        KEY idx_time   (created_at)
        KEY idx_source (source, created_at)
    即:表结构本来就是按「按期查 / 按来源+期查」设计的,缺的只是把参数接出来。
    故本次补齐**零 DDL、零索引新增**,且与 orders_page 的日期口径逐字同源
    (共用 _norm_dt:起点补 00:00:00、终点补 23:59:59,含所给精度的整段)。

    ⚠ 连带修掉的一个死结:前端导出上限 5000 行,而本页此前只有「来源」一个
      筛选(4 个值)。真实系统上单是 source='order' 就会轻易破 5000 ——
      届时**对账台账无法导出且无任何补救路径**(实测复现:命中 9000 条时
      导出被拒,而提示让人「按批次/状态收窄」,这一页两者都没有)。
      有了时间区间,按月导出即可落在上限内。

    日期参数**不需要 gbk 闸**:_norm_dt 的正则只放行 ASCII 数字与分隔符,
    形态或日历不合法一律回 ''(该条件不生效),不存在自由文本进 SQL 的路径。
    这与 orders_page 对 date_from/date_to 的既有处理逐字一致。
    """
    page, size = max(1, int(page or 1)), max(1, min(int(size or 50), 500))
    where, args = ["1=1"], []
    if uid:
        where.append("user_id=%s"); args.append(int(uid))
    if source and not gbk_ok(source):
        where.append("1=0"); source = ""     # gbk 闸:表示不了的来源 ≡ 无此来源
    if source:
        where.append("source=%s"); args.append(str(source)[:16])
    df, dt = _norm_dt(date_from), _norm_dt(date_to, end_of_day=True)
    # ★ 4.3.1:上下限填反了就替他调过来 —— 与本文件金额区间的既有处置**同一条
    #   理由**(「别回空表让人以为没数据」),而那条一直只落实在金额上:
    #   日期填反时两个谓词互斥,回 0 行且屏幕上没有任何提示,运维只会以为
    #   「这段时间真的没有流水」。对账场景下这个误读的代价比金额填反更大。
    #   必须**交换原始入参后重新规范化**,不能直接交换 df/dt:
    #   「起点补 00:00:00 / 终点补 23:59:59」的语义绑在**位置**上而不是值上,
    #   直接换会把「含当天全天」的那一端搬到起点去,少算/多算一整天。
    #   比较用规范化后的串:两者都是 'YYYY-MM-DD HH:MM:SS' 定宽 ASCII,
    #   字典序 == 时间序。
    if df and dt and df > dt:
        df, dt = _norm_dt(date_to), _norm_dt(date_from, end_of_day=True)
    if df:
        where.append("created_at>=%s"); args.append(df)
    if dt:
        where.append("created_at<=%s"); args.append(dt)
    w = " AND ".join(where)
    total, capped = await _count_capped("guantai_jf_grant_log", w, tuple(args))
    page = _clamp_page(page, size, total)
    rows = await userauth._q(
        f"SELECT * FROM guantai_jf_grant_log WHERE {w} ORDER BY id DESC "
        f"LIMIT %s OFFSET %s", tuple(args) + (size, (page - 1) * size),
        fetch="all") or []
    return {"total": total, "totalCapped": capped, "page": page, "size": size,
            "items": [{"id": int(r["id"]), "userId": int(r["user_id"]),
                       "userName": r["user_name"], "source": r["source"],
                       "ref": r["ref"], "plan": r["plan_code"],
                       "amount": float(r["amount"] or 0),
                       "jfHours": int(r["jf_hours"]), "ddHours": int(r["dd_hours"]),
                       "vipBefore": userauth._dt_iso(r["vip_before"]) if r["vip_before"] else "",
                       "vipAfter": userauth._dt_iso(r["vip_after"]) if r["vip_after"] else "",
                       "dueBefore": userauth._dt_iso(r["due_before"]) if r["due_before"] else "",
                       "dueAfter": userauth._dt_iso(r["due_after"]) if r["due_after"] else "",
                       "operator": r["operator"],
                       "createdAt": userauth._dt_iso(r["created_at"])} for r in rows]}


async def orders_page(page: int, size: int, uid: int = 0, status: str = "",
                      order_no: str = "", user_name: str = "", plan_code: str = "",
                      date_from: str = "", date_to: str = "",
                      amt_min=None, amt_max=None,
                      simulate: str = "", credited: str = "") -> dict:
    """在线充值订单检索。

    ── 为什么是这几个谓词、以及每条各值多少钱 ─────────────────────────────────
    本轮把每条谓词都在**真库**上量过(MariaDB 10.11 / 本文件 DDL 1:1 / 40 万行 /
    FLUSH STATUS + Handler_read_* 数真实扫描行数)。可用索引只有建表时那四把,
    项目纪律禁止对用户库 ALTER(test_jfvip_discipline 钉死),所以谓词形态是
    **迁就现有索引设计出来的**,不是想当然列的:

      order_no  前缀 LIKE 'X%'  →     24 行   走 uk_order
                中缀 LIKE '%X%' → 200,048 行  ← 故**只做前缀**,UI 亦如实标注
      user_name 先解析成 uid    →      9 行   走 idx_user
                裸 user_name=   → 400,000 行  ← 该列无索引,故绝不直接查
      uid                       →      9 行   走 idx_user
      status                    →    822 行   主键倒扫 + 过滤(7% 命中率实测)
      amount 区间               →    157 行   主键倒扫 + 过滤
      is_simulate=1             →  1,642 行   同上(3% 命中率)
      时间范围 + status         →  3,698 行   走 idx_status_time
      时间范围(单独)          → 395,113 行  ← 无索引可用,见下

    ⚠ 时间范围单独使用时**代价正比于表规模**,这一条我不藏着:
      查近期区间只扫 49 行(主键倒扫立刻撞上),查久远区间才会退化。
      本项目现实量级(订单以万计)下全表扫也是毫秒级,故照常提供 —— 运维按月
      对账是刚需,不能因为一个理论上的坏情况就把功能砍掉。
      真到十万级仍嫌慢时的正解**不是**加 KEY idx_create(create_time):
      本轮实测加了也没用(优化器因 ORDER BY id DESC 仍选 PRIMARY,395,138 行),
      必须**同时**把排序换成 `ORDER BY create_time DESC, id DESC` 才生效
      (实测 50 行)。那是一次带排序口径变更的改动,不该混在本轮里做。
    """
    size = max(1, min(int(size or 50), 500))
    where, args = ["1=1"], []
    not_found = False

    # 首尾空格必须剥掉:运维从 Excel / 对账单里复制订单号极易带上一个尾随空格,
    # 而 `LIKE 'GW123 %'` 会静默回 0 行 —— 屏幕上显示「没有记录」,人只会以为
    # 这笔单不存在。前端虽已 trim,但本函数也被 /api/vip/orders 与直调 API 使用,
    # 清洗必须落在**唯一入口**上,不能指望每个调用方都记得。
    order_no = str(order_no or "").strip()
    user_name = str(user_name or "").strip()

    # gbk 闸(4.2.9):此前**只有 user_name** 一条做了这个判断,而同一函数里
    # order_no / plan_code / status 三条同样是自由文本、同样进 gbk 连接 ——
    # 真库实测三条各自都能让本端点 500。补齐,口径与 user_name 那条逐字一致。
    if not (gbk_ok(order_no) and gbk_ok(plan_code) and gbk_ok(status)):
        where.append("1=0"); order_no = plan_code = status = ""
    if order_no:
        # 前缀匹配。转义 LIKE 元字符,否则运维粘进一个含 % 的串会变成全表扫,
        # 而屏幕上完全看不出发生了什么。
        esc = order_no[:64].replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        where.append("gateway_order_no LIKE %s"); args.append(esc + "%")

    if user_name:
        # ★ 第五轮复审实测缺陷:用户名含 GBK 表示不了的字符(emoji / 部分日文假名
        #   以外的字)时,resolve_user() 自己吞掉 UnicodeEncodeError 回 None,
        #   而下面的快照回退把**同一个串**再塞进 user_name=%s —— 那条查询没人接,
        #   异常一路穿到 FastAPI ⇒ 管理台 500。真库实测:搜 "user🐟emoji" 必崩。
        #   项目对此早有定论(userauth 登录侧 C8、resolve_user 自身注释):
        #   「gbk 表示不了的用户名 ≡ 查无此人」。这里照同一口径闭合,
        #   用 1=0 让它走正常的空结果路径,保持单一返回出口与响应形状不变。
        try:
            user_name.encode(getattr(userauth.UA.cfg, "charset", "gbk") or "gbk")
        except (UnicodeEncodeError, LookupError):
            where.append("1=0")
            not_found = True
            user_name = ""                      # 跳过下面两条分支
    if user_name:
        row, resolve_failed = None, False
        try:
            row = await resolve_user(user_name[:50])
        except Exception:                       # noqa: BLE001
            resolve_failed = True               # 用户库抖动:退回快照名匹配,不让整条查询失败
        if row:
            where.append("user_id=%s"); args.append(int(row["id"]))
        else:
            # 用户已从 tb_user 删除、或名字打错。订单表存了 user_name 快照,
            # 仍按快照精确匹配 —— **正确性优先于速度**:历史订单不该因为用户
            # 被删就查不出来(那正是要查它的时候)。此路无索引,但只在
            # 「解析不到」这一罕见分支发生,且本端点仅管理员可达。
            #
            # ★ 复审补:not_found 只在**真的查无此人**时置位。解析因用户库抖动
            #   抛异常时同样走快照路径,但**不能**报「该用户不存在」—— 那是一句
            #   假话,会把一次瞬时故障误导成「这人已注销」,运维据此下的判断全是错的。
            not_found = not resolve_failed
            where.append("user_name=%s"); args.append(user_name[:50])

    if uid:
        where.append("user_id=%s"); args.append(int(uid))
    if status:
        where.append("status=%s"); args.append(str(status)[:16])
    if plan_code:
        where.append("plan_code=%s"); args.append(str(plan_code)[:16])

    df, dt = _norm_dt(date_from), _norm_dt(date_to, end_of_day=True)
    # ★ 4.3.1:上下限填反了就替他调过来 —— 与本文件金额区间的既有处置**同一条
    #   理由**(「别回空表让人以为没数据」),而那条一直只落实在金额上:
    #   日期填反时两个谓词互斥,回 0 行且屏幕上没有任何提示,运维只会以为
    #   「这段时间真的没有流水」。对账场景下这个误读的代价比金额填反更大。
    #   必须**交换原始入参后重新规范化**,不能直接交换 df/dt:
    #   「起点补 00:00:00 / 终点补 23:59:59」的语义绑在**位置**上而不是值上,
    #   直接换会把「含当天全天」的那一端搬到起点去,少算/多算一整天。
    #   比较用规范化后的串:两者都是 'YYYY-MM-DD HH:MM:SS' 定宽 ASCII,
    #   字典序 == 时间序。
    if df and dt and df > dt:
        df, dt = _norm_dt(date_to), _norm_dt(date_from, end_of_day=True)
    if df:
        where.append("create_time>=%s"); args.append(df)
    if dt:
        where.append("create_time<=%s"); args.append(dt)

    lo, hi = _norm_amount(amt_min), _norm_amount(amt_max)
    if lo is not None and hi is not None and lo > hi:
        lo, hi = hi, lo                         # 上下限填反了就替他调过来,别回空表让人以为没数据
    if lo is not None:
        where.append("amount>=%s"); args.append(lo)
    if hi is not None:
        where.append("amount<=%s"); args.append(hi)

    sim, cred = _norm_bool01(simulate), _norm_bool01(credited)
    if sim is not None:
        where.append("is_simulate=%s"); args.append(sim)
    if cred is not None:
        where.append("credited=%s"); args.append(cred)

    w = " AND ".join(where)
    total, capped = await _count_capped("guantai_jf_order", w, tuple(args))
    page = _clamp_page(page, size, total)
    rows = await userauth._q(
        f"SELECT * FROM guantai_jf_order WHERE {w} ORDER BY id DESC LIMIT %s OFFSET %s",
        tuple(args) + (size, (page - 1) * size), fetch="all") or []
    return {"total": total, "totalCapped": capped, "page": page, "size": size,
            "userNotFound": not_found,
            "items": [{"id": int(r["id"]), "orderNo": r["gateway_order_no"],
                       "userId": int(r["user_id"]), "userName": r["user_name"],
                       "plan": r["plan_code"], "amount": float(r["amount"] or 0),
                       "status": r["status"], "credited": bool(int(r["credited"])),
                       "simulate": bool(int(r["is_simulate"])),
                       "createTime": userauth._dt_iso(r["create_time"]),
                       "payTime": userauth._dt_iso(r["pay_time"]) if r["pay_time"] else "",
                       } for r in rows]}


@userauth.heavy_reads
async def overview() -> dict:
    """管理台概览:在期人数、今日/7 日开通与金额、档位占比、free 档到访数。

    ★ 4.2.5 复审修补:原实现每段都裸裹 `contextlib.suppress(Exception)` ——
      查询挂了对应 key 直接**缺席**,而管理台前端写的是 `?? 0`,于是屏幕上
      渲染出「今日金额 ¥0.00」。**这与"今天真的一分没卖出去"完全无法区分**,
      运维会把一次用户库故障读成一天零收入。经营看板上的静默归零比报错危险。

      现在:仍然不让单点故障拖垮整个概览(其余格子照常出),但把失败的键名
      收进 `degraded[]` 一并回前端,由前端把这些格子显示成「?」并挂降级横幅。
      键名与前端 num() 的判据一一对应,增删须两侧同步。
    """
    out: Dict[str, Any] = {"enabled": enabled(), "plans": plans(),
                           # ★ 复审自查缺陷:前端此前**无从得知**删除开关的状态,
                           #   而该开关默认关 —— 于是默认体验是「选中 → 点删除 →
                           #   键入 DELETE → 最后被 403 打回」。不仅难用,更糟的是
                           #   它训练运维养成条件反射式键入 DELETE 的习惯,而那正是
                           #   二次确认存在的意义所在。把状态给出去,让按钮如实反映。
                           "purgeEnabled": bool(getattr(
                               userauth.UA.cfg, "jf_card_purge_enabled", False)),
                           # 4.4.1:站点分流是纯配置回显(不打库、不参与 degraded
                           # 记账)。放这里的理由与 purgeEnabled 完全一致 ——
                           # 运维此前无从得知"这套后端现在把哪些域名当直营",
                           # 而这一项配错的表现是**静默**的(主站少一个在线支付入口)。
                           "site": {
                               "directHosts": sorted(userauth.jf_direct_host_set()),
                               "trustXfh": bool(getattr(
                                   userauth.UA.cfg, "jf_direct_trust_xfh", False)),
                               # 4.4.2:客服联系方式的**收敛后生效值**回显。
                               # 与 directHosts 放在一起、理由也完全一样:这一项
                               # 配错的表现是**静默**的(开通门上少一行,或多一串
                               # 错号码),运维此前无从得知服务端最终认下了什么。
                               # 这里给的是过完 cs_text/cs_url 两道闸之后的值 ——
                               # 被白名单丢弃的链接在这里就是空,一眼可辨。
                               # ⚠ 不经站点闸(cs_info):管理台要看的是「配置本身
                               # 解析成了什么」,而不是「管理台此刻这个 Host 能不能
                               # 拿到」——后者恒为管理员自己的域名,毫无信息量。
                               # ★ 与启动横幅、与用户实际看到的值**同一份收敛**
                               # (userauth.cs_resolve)。此前这里各算各的,横幅
                               # 那份漏传 fail-closed 就当场撒了谎 —— 不再有第二份。
                               # 另回两条原串与上限:前端要能说清「为什么它没出现」。
                               "cs": {**userauth.cs_resolve(),
                                      "valueRaw": str(getattr(
                                          userauth.UA.cfg, "jf_cs_value", "") or "").strip(),
                                      "urlRaw": str(getattr(
                                          userauth.UA.cfg, "jf_cs_url", "") or "").strip(),
                                      "limits": dict(userauth._CS_LIMITS)}}}
    degraded: List[str] = []

    async def _stat(key: str, fn) -> None:
        """跑一段统计;失败只记账不抛 —— 但**必须留痕**,不许静默归零。"""
        try:
            await fn()
        except Exception as e:              # noqa: BLE001
            degraded.append(key)
            print(f"[九法VIP] ⚠️ 概览统计 {key} 取数失败: {e!r}")

    async def _vip_alive() -> None:
        r = await userauth._q("SELECT COUNT(*) AS n FROM guantai_jf_vip "
                              "WHERE vip_until > NOW()", fetch="one") or {}
        out["vipAlive"] = int(r.get("n") or 0)

    async def _today() -> None:
        r = await userauth._q(
            "SELECT COUNT(*) AS n, IFNULL(SUM(amount),0) AS amt "
            "FROM guantai_jf_grant_log WHERE source IN ('order','card') "
            "AND created_at >= CURDATE()", fetch="one") or {}
        out["today"] = {"grants": int(r.get("n") or 0), "amount": float(r.get("amt") or 0)}

    async def _week() -> None:
        r = await userauth._q(
            "SELECT COUNT(*) AS n, IFNULL(SUM(amount),0) AS amt "
            "FROM guantai_jf_grant_log WHERE source IN ('order','card') "
            "AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)", fetch="one") or {}
        out["week"] = {"grants": int(r.get("n") or 0), "amount": float(r.get("amt") or 0)}

    async def _by_plan() -> None:
        rows = await userauth._q(
            "SELECT plan_code, COUNT(*) AS n FROM guantai_jf_grant_log "
            "WHERE source IN ('order','card') GROUP BY plan_code", fetch="all") or []
        # 4.2.9:内联时长码(@H…)**聚合成一桶**再回前端,两个理由:
        #   ① 有界:内联码由运营任意指定,GROUP BY 出来的组数没有上限,原样回传
        #      会让概览响应随定制次数无限膨胀(每做一次促销就多一个键);
        #   ② 可见:前端「档位与销量」表是 `plans.map(...)` 渲染的,只遍历**配置
        #      档位** —— 内联码即便回传了也一行都不显示。定制卡卖了多少,在概览页
        #      完全不体现,是一个"后端算了、前端看不到"的洞。
        by: Dict[str, int] = {}
        custom = 0
        for r in rows:
            code = str(r["plan_code"])
            if is_inline_code(code):
                custom += int(r["n"])
            else:
                by[code] = int(r["n"])
        out["byPlan"] = by
        out["customGrants"] = custom

    async def _free_visits() -> None:
        # 转化漏斗左端:到期用户进来看开通页的次数(login 侧 reason='ok_free')
        r = await userauth._q(
            "SELECT COUNT(*) AS n FROM guantai_login_log "
            "WHERE reason IN ('ok_free','sso_free') "
            "AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)", fetch="one") or {}
        out["freeVisits7d"] = int(r.get("n") or 0)

    async def _cards_unused() -> None:
        r = await userauth._q(
            "SELECT COUNT(*) AS n FROM guantai_jf_card WHERE used_by=0 AND disabled=0",
            fetch="one") or {}
        out["cardsUnused"] = int(r.get("n") or 0)

    await _stat("vipAlive", _vip_alive)
    await _stat("today", _today)
    await _stat("week", _week)
    await _stat("byPlan", _by_plan)
    await _stat("freeVisits7d", _free_visits)
    await _stat("cardsUnused", _cards_unused)
    out["degraded"] = degraded
    return out


async def resolve_user(user_name: str) -> Optional[dict]:
    """按用户名解析 tb_user(管理台手动开通用;**只读**)。"""
    c = userauth.UA.cfg
    try:
        return await userauth._q(
            f"SELECT id, user_name, due_time, (due_time > NOW()) AS alive "
            f"FROM `{c.user_table}` WHERE user_name=%s", (str(user_name),), fetch="one")
    except (UnicodeEncodeError, LookupError):
        return None                    # gbk 表示不了的用户名 ≡ 查无此人
