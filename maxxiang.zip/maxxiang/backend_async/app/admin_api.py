"""
admin_api.py — 管理台 API(挂载在 /api/<入口路径>/* —— 见 admin_auth.api_prefix())
================================================================================
5.3.0:本模块的 router **不带前缀**,挂载点由 web.py 按配置的入口路径决定;外部发卡接口
另以恒定地址 admin_auth.CARD_ISSUE_PATH 再挂一次(机器契约不随入口搬家)。
写入口全在此处:变更 → 校验(结构+语义+危险确认)→ PG 落不可变版本 →
Redis 广播 → 本进程即刻套用(其余实例经订阅/心跳收敛)。全部端点要求
会话凭据(除 login):X-Admin-Session 头优先、会话 cookie 兜底(双通道,
免疫反代/HTTPS/浏览器 cookie 策略差异);写操作再要求 X-Admin-CSRF 头(双提交)。
未设置管理密码时一切 503(安全默认关,见 admin_auth)。

依赖注入:web.py 在 lifespan 内调用 `init(ST, hooks)`(共享既有 State:
db/bus/fx_bucket/cfg_state),本模块不 import web —— 无循环依赖。
"""
from __future__ import annotations

import asyncio
import contextlib
import hashlib
import hmac
import json
import os
import re
import secrets
import time
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Query, Request
from fastapi.responses import JSONResponse, PlainTextResponse

from . import admin_auth
from . import clientip   # 5.2.0:来源 IP / 分桶(管理台登录防爆破)
from . import userauth   # 5.2.0:设备信任根密钥(_dev_key)
from . import wincount   # 5.2.0:原子窗口计数
from . import config_center as cfgc
from . import config_registry as reg
from . import jfvip        # 4.2.0:九法VIP 管理
from . import lifecycle    # 5.4.0:数据生命周期(全表登记 / 清扫 / 容量观测)
from .userdb_pool import heavy as _heavy_reads   # 管理台调用共用检索函数时开启重查询语义(超时不熔断入口)
from .redis_bus import K_ROOMS, K_SCHED, now_ms
from .settings import settings
from .upstream import AuthExpired, Upstream

ADMIN_VERSION = "1.11.0"         # 4.3.0:与 admin.html 的 ?v 同步(test_admin_asset_version_pin 钉死)

# 5.3.0:不带前缀 —— 入口路径可配(settings.admin.path),前缀在**挂载时**给:
#   web.py: app.include_router(admin_api.router, prefix=admin_auth.api_prefix())
router = APIRouter()

_ST = None                                   # web.State(db/bus/fx_bucket/cfg_state)
_HOOKS: Dict[str, Any] = {}


def init(st, hooks: Dict[str, Any]) -> None:
    """web.lifespan 注入共享状态与本进程钩子表。"""
    global _ST, _HOOKS
    _ST, _HOOKS = st, dict(hooks or {})


def _state() -> cfgc.CenterState:
    return getattr(_ST, "cfg_state", None) or cfgc.CenterState(role="web")


# ── 守卫(503 未启用 / 403 IP / 401 会话 / 403 CSRF) ──────────────────────────
def _session_token(request: Request) -> str:
    """会话凭据双通道:X-Admin-Session 头优先,cookie 兜底。
    根因修复:HttpOnly cookie 在真实部署里有一整类翻车姿势 —— 反代不透传
    Set-Cookie/Cookie、HTTPS 误判 Secure、浏览器/webview 存储策略、同名旧
    cookie 冲突……任何一环断掉都表现为「登录 200 但后续 401 弹回登录」。
    令牌由 login 响应体直接交给前端、经请求头原样带回,不经过 cookie 机制,
    对上述全部环境问题免疫;cookie 通道保留作纵深与兼容。
    (头由 JS 显式附带、浏览器不会自动发送,天然免 CSRF;csrf 双提交对
    cookie 通道继续生效。)"""
    hdr = (request.headers.get("x-admin-session") or "").strip()
    if hdr:
        return hdr
    return request.cookies.get(admin_auth.COOKIE, "")


def _guard(request: Request) -> Dict[str, Any] | JSONResponse:
    if not admin_auth.enabled():
        return JSONResponse({"ok": False, "error": "admin_disabled",
                             "hint": "设置 STA_ADMIN_PASSWORD 后重启 web 以启用管理台"},
                            status_code=503)
    ip = admin_auth.client_ip(request)
    if not admin_auth.ip_allowed(ip):
        return JSONResponse({"ok": False, "error": "ip_forbidden"}, status_code=403)
    payload = admin_auth.parse_session(_session_token(request))
    if payload is None:
        return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)
    payload["ip"] = ip
    return payload


def _guard_write(request: Request) -> Dict[str, Any] | JSONResponse:
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    if request.headers.get("x-admin-csrf", "") != payload.get("csrf", "@"):
        return JSONResponse({"ok": False, "error": "csrf",
                             "hint": "缺少或不匹配 X-Admin-CSRF 头(重新登录可重发)"},
                            status_code=403)
    return payload


def _actor(payload: Dict[str, Any]) -> str:
    return f"admin@{payload.get('ip', '?')}"


async def _audit(actor: str, action: str, detail: Dict[str, Any],
                 rev: Optional[int] = None) -> None:
    with contextlib.suppress(Exception):
        await _ST.db.audit_add(now_ms(), actor, action, detail, rev)


async def _body(request: Request) -> Dict[str, Any]:
    try:
        b = await request.json()
        return b if isinstance(b, dict) else {}
    except Exception:
        return {}


# ── 会话 ─────────────────────────────────────────────────────────────────────
# ── 管理台登录防爆破(5.2.0;阈值见 admin_auth.login_fail_limits) ──────────────
_ADM_DEV_RE = re.compile(r"^a1\.(\d{9,11})\.([0-9a-f]{16})\.([0-9a-f]{32})$")


def _adm_redis():
    try:
        return _ST.bus.r
    except Exception:                    # noqa: BLE001 —— 未注入(测试 / 早期启动):走进程内兜底
        return None


async def _adm_dev_key() -> bytes:
    # 与用户侧设备信任共用同一把根密钥(同一套存放与轮换),按用途做域隔离
    return hashlib.sha256(b"jf-admin-dev|" + await userauth._dev_key()).digest()


async def _adm_device(raw: str) -> str:
    ttl = admin_auth.device_ttl_s()
    m = _ADM_DEV_RE.match(str(raw or "").strip())
    if not ttl or not m:
        return ""
    iat, did, sig = int(m.group(1)), m.group(2), m.group(3)
    now = time.time()
    if iat > now + 300 or now - iat > ttl:
        return ""
    want = hmac.new(await _adm_dev_key(), f"a1|{iat}|{did}".encode(), hashlib.sha256).hexdigest()[:32]
    return did if hmac.compare_digest(want, sig) else ""


def _adm_cookie_path(request: Request) -> str:
    """设备信任 Cookie 的作用域 = 管理 API 的**实际挂载前缀**(入口路径可配,不写死)。
    登录类端点的路径形如 <前缀>/login[/ticket],截到 /login 之前即前缀本身。"""
    p = str(request.url.path or "")
    i = p.rfind("/login")
    base = p[:i] if i > 0 else admin_auth.api_prefix()
    return base.rstrip("/") + "/"


async def _adm_set_device(resp: JSONResponse, request: Request) -> None:
    ttl = admin_auth.device_ttl_s()
    if not ttl:
        return
    with contextlib.suppress(Exception):
        iat, did = int(time.time()), secrets.token_hex(8)
        sig = hmac.new(await _adm_dev_key(), f"a1|{iat}|{did}".encode(), hashlib.sha256).hexdigest()[:32]
        resp.set_cookie(admin_auth.ADM_DEV_COOKIE, f"a1.{iat}.{did}.{sig}", max_age=ttl,
                        httponly=True, samesite="lax", secure=(request.url.scheme == "https"),
                        path=_adm_cookie_path(request))


async def _adm_admit(request: Request, bucket: str) -> Dict[str, Any]:
    """先占后验:每 IP 段 + 全站两份失败额度(受信设备改用本设备一份)。"""
    lim_ip, lim_g, win, _lock = admin_auth.login_fail_limits()
    r, mem = _adm_redis(), admin_auth._ADM_FAIL_MEM
    g: Dict[str, Any] = {"keys": [], "reject": None}
    did = await _adm_device(request.cookies.get(admin_auth.ADM_DEV_COOKIE, ""))
    if did:
        kd = f"adm:lf:dev:{did}"
        n, _t = await wincount.incr(r, kd, win, mem)
        if n <= lim_ip:
            g["keys"] = [(kd, n, lim_ip)]
            return g
        await wincount.decr(r, kd, mem)          # 设备额度已尽 → 按陌生设备处理
    ki, kg = f"adm:lf:ip:{bucket}", "adm:lf:g"
    n_ip, t_ip = await wincount.incr(r, ki, win, mem)
    n_g, t_g = await wincount.incr(r, kg, win, mem)
    over = [t for n, lim, t in ((n_ip, lim_ip, t_ip), (n_g, lim_g, t_g)) if n > lim]
    if over:
        # 被拒的这一次没验口令:两份额度都退还 —— 否则一个已被锁的 IP 狂刷,就能把全站
        # 计数顶满、连带锁死所有陌生来源(复查补漏;tests/test_login_guard.py 钉死)
        await wincount.decr(r, ki, mem)
        await wincount.decr(r, kg, mem)
        left = max(over)
        g["reject"] = JSONResponse({"ok": False, "error": "rate_limited", "retryAfter": left,
                                    "hint": f"尝试过于频繁,请 {max(1, left // 60)} 分钟后再试"},
                                   status_code=429, headers={"Retry-After": str(left)})
        return g
    g["keys"] = [(ki, n_ip, lim_ip), (kg, n_g, lim_g)]
    return g


async def _adm_settle(g: Dict[str, Any], ok: bool) -> None:
    """口令正确 → 退还先占的额度;口令错 → 不退,恰达上限即抬成锁定期。"""
    _a, _b, _w, lock = admin_auth.login_fail_limits()
    r, mem = _adm_redis(), admin_auth._ADM_FAIL_MEM
    for k, n, lim in g["keys"]:
        if ok:
            await wincount.decr(r, k, mem)
        elif n >= lim:
            await wincount.lock(r, k, lock, mem)
    g["keys"] = []


# ── 5.3.0:入口闸 / 请求速率 / 人机验证 ─────────────────────────────────────────
def _no_store(resp: JSONResponse) -> JSONResponse:
    resp.headers["Cache-Control"] = "no-store"
    return resp


def _login_precheck(request: Request):
    """未启用 → 503;来源 IP 不在白名单 → 403;否则返回来源 IP。"""
    if not admin_auth.enabled():
        return JSONResponse({"ok": False, "error": "admin_disabled",
                             "hint": "设置 STA_ADMIN_PASSWORD 后重启 web 以启用管理台"},
                            status_code=503)
    ip = admin_auth.client_ip(request)
    if not admin_auth.ip_allowed(ip):
        return JSONResponse({"ok": False, "error": "ip_forbidden"}, status_code=403)
    return ip


def _login_shape_ok(request: Request) -> Optional[JSONResponse]:
    """与用户登录端点同一口径(5.2.0 给用户侧补过、管理台当时漏了):
      · best-effort 同源校验 —— 带 Origin/Referer 且与 Host 不同源即拒;
      · 只收 JSON —— 跨站纯表单(enctype=text/plain 可拼出合法 JSON)借受害者浏览器
        往这里灌请求,烧的是受害者那个 IP 段的失败额度(把管理员自己锁在门外)。"""
    if userauth._origin_mismatch(request):
        return JSONResponse({"ok": False, "error": "bad_origin",
                             "hint": "请求来源校验未通过"}, status_code=403)
    ct = (request.headers.get("content-type") or "").split(";")[0].strip().lower()
    if ct not in ("", "application/json"):
        return JSONResponse({"ok": False, "error": "bad_request",
                             "hint": "请求格式有误,请刷新页面后重试"}, status_code=415)
    return None


async def _adm_rate(bucket: str) -> Optional[JSONResponse]:
    """请求速率:每 IP 段每分钟上限(admin_auth.login_rate_per_min,默认 20)。

    5.3.0 由 Redis 令牌桶改为窗口计数。实测旧桶在 Redis 连不上时并不是注释里说的「被 suppress
    掉(放开)」—— TokenBucket 对连接错误先重试满 3 秒预算再判**拒绝**:基线实跑,停掉 Redis 后
    用正确口令登录,3.17s 后 429「尝试过于频繁」。也就是 Redis 一挂,管理员自己也进不了后台,
    而那往往正是最需要进后台的时刻。窗口计数在 Redis 不可用时退化进程内计数:既不放开,
    也不把人锁在外面。"""
    lim = admin_auth.login_rate_per_min()
    n, left = await wincount.incr(_adm_redis(), f"adm:rl:{bucket}", 60, admin_auth._ADM_FAIL_MEM)
    if n <= lim:
        return None
    return _no_store(JSONResponse(
        {"ok": False, "error": "rate_limited", "retryAfter": left,
         "hint": f"尝试过于频繁,请 {left} 秒后再试"},
        status_code=429, headers={"Retry-After": str(left)}))


_ADM_AUDIT_CAP_G = 50     # 每个失败窗口内,未鉴权请求触发的审计(人机验证未过 / 坏票据)全站至多写这么多行


async def _adm_audit_capped(ip: str, bucket: str, action: str, detail: Dict[str, Any]) -> None:
    """未鉴权请求触发的审计:每来源(IP 段)每窗口至多 1 行,全站每窗口至多 _ADM_AUDIT_CAP_G 行。
    这两类请求不消耗失败额度(人机验证未过 = 没验口令;坏票据只记在来源自己头上),若逐条落库,
    分布式请求就能把审计表写爆 —— 落库写入量必须与攻击请求量脱钩(与项目既有审计限幅同一原则)。"""
    win = admin_auth.login_fail_limits()[2]
    if not await _adm_once(f"adm:au:{action}:{bucket}", win):
        return
    n, _t = await wincount.incr(_adm_redis(), f"adm:au:{action}:g", win, admin_auth._ADM_FAIL_MEM)
    if n <= _ADM_AUDIT_CAP_G:
        await _audit(f"admin@{ip}", action, detail)


async def _adm_once(key: str, ttl_s: int) -> bool:
    """同一键在 ttl 内只放行第一次(审计限幅:写入量与攻击请求量脱钩)。"""
    n, _t = await wincount.incr(_adm_redis(), key, ttl_s, admin_auth._ADM_FAIL_MEM)
    return n == 1


def _adm_cap() -> Dict[str, Any]:
    """本次登录要不要过人机验证 → {need, ready, conf, mode}。
    供应商与凭据和注册共用(userauth.reg_captcha*);档位见 admin_auth.captcha_mode()。
      auto   + 配好了 → 要;auto + 没配好 → 不要(启动横幅告警 —— 运维配置错不该把管理员锁在门外,
               修配置本来就要上服务器改 .env,不经过管理台);
      always → 要;没配好时由调用方直接判「暂不可用」拒绝(fail-closed)。"""
    mode = admin_auth.captcha_mode()
    conf = userauth._cap_conf("admin")
    prov = conf["provider"]
    ready = (prov != "off" and bool(conf["id"] and conf["key"])
             and (prov != "tencent" or bool(conf["secret_id"] and conf["secret_key"])))
    need = mode != "off" and (ready or mode == "always")
    return {"need": need, "ready": ready, "conf": conf, "mode": mode}


_CAP_DOWN_HINT = ("人机验证服务暂时不可用,已拒绝本次登录(不降级放行)。请稍后重试;"
                  "急用请在服务器上生成一次性应急登录链接")


async def _login_ok(request: Request, ip: str, *, via: str) -> JSONResponse:
    cookie_val, csrf = admin_auth.issue_session()
    # token 随响应体下发:前端每次请求经 X-Admin-Session 头回传(主通道,
    # 免疫反代/HTTPS/浏览器 cookie 策略等一切 cookie 翻车场景);cookie 继续
    # 设置作兜底(HttpOnly,老前端/无 JS 存储环境仍可工作)。
    resp = JSONResponse({"ok": True, "csrf": csrf, "token": cookie_val,
                         "version": ADMIN_VERSION,
                         "monitor_token": (os.environ.get("STA_MONITOR_WRITE_TOKEN")
                                           or "").strip()})
    # SameSite=Lax(而非 Strict):同源 fetch 均会带上,兼容反代/子路径等部署;
    # CSRF 另由双提交 X-Admin-CSRF 头保护,放宽到 Lax 不削弱防护。
    resp.set_cookie(admin_auth.COOKIE, cookie_val,
                    max_age=admin_auth.session_ttl_s(), httponly=True,
                    samesite="lax", secure=(request.url.scheme == "https"),
                    path="/")
    await _adm_set_device(resp, request)      # 5.2.0:设备信任(攻击者锁不住常用浏览器)
    action = "login"
    if via == "ticket":
        action = "login_ticket"                 # 应急链接进门:审计里单列,便于事后核对
    await _audit(f"admin@{ip}", action, {})
    return _no_store(resp)


@router.get("/login")
async def login_info(request: Request):
    """登录页开门前先问一句:要不要填账号、要不要过人机验证(用哪家、站点密钥是什么)。
    不带任何凭据即可读 —— 给出的只有「怎么登」,站点密钥本就是公开值(观测台注册页同款)。"""
    ip = _login_precheck(request)
    if isinstance(ip, JSONResponse):
        return ip
    cap = _adm_cap()
    out: Dict[str, Any] = {"ok": True, "account": admin_auth.account_required(), "captcha": None}
    if cap["need"]:
        c = cap["conf"]
        out["captcha"] = ({"provider": c["provider"], "appId": c["id"], "action": "admin"}
                          if cap["ready"] else {"provider": "", "appId": "", "action": "admin",
                                                "unavailable": True})
    return _no_store(JSONResponse(out))


@router.post("/login")
async def login(request: Request):
    """账号 + 口令 + 人机验证。闸序(由便宜到昂贵):
        ① 启用 / IP 白名单 → ② 同源 + 只收 JSON → ③ 请求速率 → ④ 失败额度先占(被锁即 429,
        不验任何东西)→ ⑤ 人机验证(没过 = 没验口令,先占的额度退还)→ ⑥ 账号 + 口令。
    人机验证排在验口令**之前**:每猜一次口令都得先真过一次验证,没有令牌的请求连口令都碰不到。"""
    ip = _login_precheck(request)
    if isinstance(ip, JSONResponse):
        return ip
    bad = _login_shape_ok(request)
    if bad is not None:
        return bad
    bucket = clientip.bucket(ip)
    limited = await _adm_rate(bucket)
    if limited is not None:
        return limited
    # 失败额度(5.2.0):先占后验 —— 管「总共能猜几次」,Redis 不可用退化进程内计数,绝不放开。
    gate = await _adm_admit(request, bucket)
    if gate["reject"] is not None:
        return _no_store(gate["reject"])
    body = await _body(request)
    cap = _adm_cap()
    if cap["need"]:
        if cap["ready"]:
            ok, err, _msg = await userauth._captcha_check(body.get("captchaToken"), ip, scope="admin")
        else:                                   # always 档但供应商没配好:无从校验 → 拒绝
            ok, err = False, "captcha_unavailable"
        if not ok:
            await _adm_settle(gate, ok=True)    # 没验口令:先占的额度退还(只数真失败)
            if err == "captcha_unavailable":
                return _no_store(JSONResponse({"ok": False, "error": "captcha_unavailable",
                                               "hint": _CAP_DOWN_HINT}, status_code=503))
            await _adm_audit_capped(ip, bucket, "login_captcha_fail", {})
            return _no_store(JSONResponse({"ok": False, "error": "captcha_failed",
                                           "hint": "人机验证未通过,请重试"}, status_code=400))
    user = body.get("username")
    if not admin_auth.verify_login(user, body.get("password")):
        await _adm_settle(gate, ok=False)
        detail: Dict[str, Any] = {}
        if admin_auth.account_required():       # 给运维一个判断依据:对方知不知道账号
            detail["accountOk"] = admin_auth.username_matches(user)
        await _audit(f"admin@{ip}", "login_fail", detail)
        # 账号错 / 口令错同一个错误码:不泄露哪一项不对
        return _no_store(JSONResponse({"ok": False, "error": "bad_credentials"}, status_code=401))
    await _adm_settle(gate, ok=True)
    return await _login_ok(request, ip, via="password")


async def _adm_ticket_once(t: Dict[str, Any]) -> bool:
    """票据一次性:进程内登记为准(web 钉死单进程),Redis 可用时再占一个键(多进程部署亦严格)。"""
    jti, exp = str(t.get("jti") or ""), int(t.get("exp") or 0)
    if not admin_auth.ticket_mark_used(jti, exp):
        return False
    r = _adm_redis()
    if r is not None:
        try:
            if not await r.set(f"adm:tk:{jti}", "1", nx=True, ex=max(1, exp - int(time.time())) + 5):
                return False
        except Exception:                       # noqa: BLE001 —— Redis 抖动:进程内登记已生效
            pass
    return True


@router.post("/login/ticket")
async def login_ticket(request: Request):
    """应急登录:凭服务器上签发的一次性票据换会话(admin_auth.issue_ticket / `… admin_auth link`)。

    复查后定稿的闸序 —— **先验票,有效票据直接放行**:
        ① 启用 / IP 白名单 → ② 同源 + 只收 JSON → ③ 验签 + 未过期 + 未使用 → 进门;
        ④ 坏票据才计数:只记在该来源自己头上,到上限后该来源再递坏票据一律 429。
    为什么有效票据不看失败额度与限速:这条路存在的理由就是「正门进不去」—— 验证服务不可达,
    或者后台正被分布式猜口令、全站失败额度已顶满(陌生设备一律 429)。票据是服务器环境里的
    密钥签出来的,伪造不了(HMAC-SHA256),验签只是一次散列,先验它不构成可被放大的开销;
    若让它排在失败额度之后,攻击者只要把额度顶满,管理员握着有效票据也进不来。
    为什么坏票据不进**全站**失败额度:登录有人机验证挡在前面,这里没有 —— 坏票据若也算全站
    失败,就成了一条不花任何成本即可把所有陌生设备锁在门外的路。
    不要求人机验证的理由同上;拿得到签名密钥的人早已握有 .env 里的全部凭据。"""
    ip = _login_precheck(request)
    if isinstance(ip, JSONResponse):
        return ip
    bad = _login_shape_ok(request)
    if bad is not None:
        return bad
    body = await _body(request)
    t = admin_auth.parse_ticket(body.get("ticket"))
    if t is not None and await _adm_ticket_once(t):
        return await _login_ok(request, ip, via="ticket")
    lim_ip, _lim_g, win, _lock = admin_auth.login_fail_limits()
    n, left = await wincount.incr(_adm_redis(), f"adm:tf:{clientip.bucket(ip)}", win, admin_auth._ADM_FAIL_MEM)
    if n > lim_ip:                              # 该来源的坏票据已到上限:不再逐条回应、不再写审计
        return _no_store(JSONResponse(
            {"ok": False, "error": "rate_limited", "retryAfter": left,
             "hint": f"尝试过于频繁,请 {max(1, left // 60)} 分钟后再试"},
            status_code=429, headers={"Retry-After": str(left)}))
    why = "invalid"                             # 验签 / 过期 / 形态不过
    if t is not None:
        why = "replayed"                        # 票据本身是真的,但已经用过
    await _adm_audit_capped(ip, clientip.bucket(ip), "login_ticket_fail", {"why": why})
    return _no_store(JSONResponse(
        {"ok": False, "error": "bad_ticket",
         "hint": "应急登录链接无效、已过期或已被使用 —— 请在服务器上重新生成"}, status_code=401))


def startup_report() -> None:
    """启动横幅:把管理台入口与进门规则的**实际生效口径**一次说清(运维排障第一眼)。"""
    if not admin_auth.enabled():
        print("[管理台] 未启用(未设 STA_ADMIN_PASSWORD / STA_ADMIN_PASSWORD_HASH)—— 入口与管理 API 一律 503")
        return
    cap = _adm_cap()
    prov = cap["conf"]["provider"]
    if cap["need"] and cap["ready"]:
        cap_txt = f"{prov}(每次登录必过;校验不可达即拒绝)"
    elif cap["need"]:
        cap_txt = "always 档但供应商未配好 —— 网页登录将被拒绝"
    elif cap["mode"] == "off":
        cap_txt = "关(admin.login_captcha=off)"
    else:
        cap_txt = "未生效(站点未配置人机验证供应商)"
    name = admin_auth.username()
    acct = (f"开({name[:3]}***{name[-2:]})" if len(name) > 5 else "开") if name else "关(只验口令)"
    lim_ip, lim_g, win, lock = admin_auth.login_fail_limits()
    print(f"[管理台] 入口 {admin_auth.page_path()}(API {admin_auth.api_prefix()}/*)· 账号登录 {acct}"
          f" · 人机验证 {cap_txt} · 限速 {admin_auth.login_rate_per_min()}/分·IP段"
          f" · 失败额度 每IP段 {lim_ip} / 全站 {lim_g}(窗口 {win}s,锁 {lock}s)"
          f" · 应急登录:python -m app.admin_auth link")
    if cap["mode"] != "off" and not cap["ready"]:
        raw = str(getattr(settings.userauth, "reg_captcha", "off") or "off")
        why = ("未选择供应商(STA_USER_REG_CAPTCHA)" if prov == "off" and raw in ("", "off")
               else f"供应商 {raw!r} 无法识别" if prov == "off"
               else "站点密钥 / 私钥不全(STA_USER_REG_CAPTCHA_ID / _KEY"
                    + (" / _SECRET_ID / _SECRET_KEY" if prov == "tencent" else "") + ")")
        print(f"[管理台] ⚠️ 登录人机验证未就绪:{why}"
              + (" —— always 档下网页登录一律 503,仅应急登录链接可进" if cap["mode"] == "always"
                 else " —— 当前登录只验账号口令(失败额度与限速照常生效)"))
    if not name:
        print("[管理台] ℹ️ 未设置登录账号(admin.username / STA_ADMIN_USERNAME)—— 当前只验口令")


@router.get("/session")
async def session(request: Request):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    return {"ok": True, "csrf": payload.get("csrf", ""), "version": ADMIN_VERSION,
            "exp": payload.get("exp"),
            "monitor_token": (os.environ.get("STA_MONITOR_WRITE_TOKEN") or "").strip()}


@router.post("/logout")
async def logout(request: Request):
    payload = _guard(request)
    resp = _no_store(JSONResponse({"ok": True}))
    resp.delete_cookie(admin_auth.COOKIE, path="/")
    if not isinstance(payload, JSONResponse):
        await _audit(_actor(payload), "logout", {})
    return resp


# ── Schema / 生效值与来源 ─────────────────────────────────────────────────────
@router.get("/schema")
async def schema(request: Request):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    out = reg.public_schema()
    out.update({"ok": True, "admin_version": ADMIN_VERSION})
    return out


@router.get("/config/effective")
async def config_effective(request: Request):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    rev, snap = await _ST.db.cfg_latest()
    st = _state()
    return {"ok": True, "rev": rev, "applied_rev": st.applied_rev,
            "items": cfgc.describe(settings, snap)}


# ── 预检 / 应用 / 清除覆盖 / 回滚(写路径) ────────────────────────────────────
async def _do_apply(*, changes: Dict[str, Any], removed: tuple, note: str,
                    actor: str, action: str = "apply") -> JSONResponse:
    coerced, errors = cfgc.check_changes(changes)
    if errors:
        return JSONResponse({"ok": False, "errors": errors}, status_code=422)
    for key in removed:
        if key not in reg.REGISTRY:
            return JSONResponse({"ok": False, "errors": [f"{key}: 未登记的参数"]},
                                status_code=422)
        f = reg.REGISTRY[key]
        if f.readonly or f.hot == reg.RESERVED:
            return JSONResponse({"ok": False,
                                 "errors": [f"{key}: 只读/预留项无覆盖可清"]},
                                status_code=422)
    # 1.8.0:两道**仪式性**闸门下线 —— 高危项的「逐一键入参数名」与警告的
    # 「ack_warnings 二次提交」。它们拦不住真正的错(打对一个键名不代表填对了值),
    # 却让每次调参都要走一遍抄写,运维实测负担远大于收益。真正的护栏一个没动:
    # 结构/范围错(check_changes)与跨字段语义错(semantic_validate)照旧 422 硬拦,
    # 每次应用仍落只增不改的 rev + 审计,可一键回滚。
    # danger 标记本身保留 —— 它继续在管理台上作为醒目提示存在,只是不再阻断。
    _cur_rev, snap = await _ST.db.cfg_latest()
    candidate = cfgc.build_candidate(
        {k: v for k, v in snap.items() if k not in removed}, coerced)
    serrs, warns = cfgc.semantic_validate(candidate, set(coerced) | set(removed))
    if serrs:
        return JSONResponse({"ok": False, "errors": serrs}, status_code=422)
    rev = await cfgc.commit(_ST.db, _ST.bus, changes=coerced, removed=removed,
                            author=actor, note=note, base_snapshot=snap)
    # 本进程即刻套用(其余实例经 pub/sub 秒级、心跳 ≤30s 兜底收敛)
    with contextlib.suppress(Exception):
        await cfgc._pull_apply(settings, _ST.bus, _ST.db, _HOOKS, _state())
    restart_keys = [k for k in coerced
                    if reg.REGISTRY[k].hot == reg.RESTART]
    detail = {"changes": {k: (cfgc.fingerprint(v) if reg.REGISTRY[k].sensitive else v)
                          for k, v in coerced.items()},
              "removed": list(removed), "note": note}
    # 1.8.0:警告不再拦人,于是必须**留痕** —— 提醒过什么、当时谁按下了应用,
    # 全在审计里可查;高危项一并列名,回溯事故时不必再去猜哪几项是危级。
    if warns:
        detail["warnings"] = warns
    _dangers = [k for k in list(coerced) + list(removed) if reg.REGISTRY[k].danger]
    if _dangers:
        detail["danger_keys"] = _dangers
    await _audit(actor, action, detail, rev)
    return JSONResponse({"ok": True, "rev": rev, "warnings": warns,
                         "restart_keys": restart_keys})


@router.post("/config/validate")
async def config_validate(request: Request):
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    body = await _body(request)
    changes = dict(body.get("changes") or {})
    coerced, errors = cfgc.check_changes(changes)
    _rev, snap = await _ST.db.cfg_latest()
    serrs, warns = cfgc.semantic_validate(cfgc.build_candidate(snap, coerced),
                                          set(coerced))
    restart_keys = [k for k in coerced if reg.REGISTRY[k].hot == reg.RESTART]
    danger_keys = [k for k in coerced if reg.REGISTRY[k].danger]
    return {"ok": not (errors or serrs), "errors": errors + serrs,
            "warnings": warns, "restart_keys": restart_keys,
            "danger_keys": danger_keys}


@router.post("/config/apply")
async def config_apply(request: Request):
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    body = await _body(request)
    return await _do_apply(
        changes=dict(body.get("changes") or {}), removed=(),
        note=str(body.get("note") or ""), actor=_actor(payload))


@router.delete("/config/override/{key}")
async def config_clear(key: str, request: Request):
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    f = reg.REGISTRY.get(key)
    resp = await _do_apply(changes={}, removed=(key,), note=f"清除覆盖 {key}",
                           actor=_actor(payload), action="clear_override")
    if resp.status_code == 200 and f is not None and f.no_reset:
        data = json.loads(bytes(resp.body).decode("utf-8"))
        data["hint"] = "该项不回落基线:清除后保持现值,由票据自动续期链路接管(≤轮询周期恢复)"
        return JSONResponse(data)
    return resp


@router.post("/config/rollback")
async def config_rollback(request: Request):
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    body = await _body(request)
    # ★ 4.3.1(与 /jfvip/revoke 的 hours 同类,顺手收口):裸 int() 对非数字入参
    #   抛 ValueError,而本文件端点层零 try/except ⇒ 一个手滑的 payload 变成
    #   HTTP 500。同文件 /reg/invites/generate 早就把这一类包了 try→422,
    #   本处是同一模式里唯一没对齐的。
    #   非法值收敛成 0,自然落到下面既有的 rev_not_found(404)分支 ——
    #   不新增分支、不改变任何合法输入的行为。
    try:
        to_rev = int(str(body.get("to_rev", "")).strip() or 0)
    except (TypeError, ValueError):
        to_rev = 0
    row = await _ST.db.cfg_get(to_rev)
    if not row:
        return JSONResponse({"ok": False, "error": "rev_not_found"}, status_code=404)
    target = dict(row.get("snapshot") or {})
    clean, skipped = cfgc.rollback_snapshot(target)
    _rev, cur = await _ST.db.cfg_latest()
    removed = tuple(k for k in cur if k not in clean)
    note = str(body.get("note") or f"回滚到 rev {to_rev}")
    resp = await _do_apply(changes=clean, removed=removed, note=note,
                           actor=_actor(payload), action="rollback")
    if resp.status_code == 200 and skipped:
        data = json.loads(bytes(resp.body).decode("utf-8"))
        data["skipped_sensitive"] = skipped
        data["hint"] = "敏感项不参与回滚(保持现值,由票据续期链路接管)"
        return JSONResponse(data)
    return resp


# ── 版本 / 导出 ──────────────────────────────────────────────────────────────
@router.get("/config/revisions")
async def revisions(request: Request, limit: int = Query(50, ge=1, le=500)):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    return {"ok": True, "items": await _ST.db.cfg_list(limit)}


@router.get("/config/revisions/{rev}")
async def revision_one(rev: int, request: Request):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    row = await _ST.db.cfg_get(rev)
    if not row:
        return JSONResponse({"ok": False, "error": "rev_not_found"}, status_code=404)
    # 敏感占位在快照中本就只有 __redis__,可直接下发
    row["ok"] = True
    return row


@router.get("/config/export")
async def config_export(request: Request, fmt: str = Query("yaml")):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    _rev, snap = await _ST.db.cfg_latest()
    text = cfgc.export_snapshot(snap, "env" if fmt == "env" else "yaml")
    return PlainTextResponse(text, media_type="text/plain; charset=utf-8")


# ── 舰队 / 总览 / 审计 ────────────────────────────────────────────────────────
@router.get("/fleet")
async def fleet(request: Request):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    out = await cfgc.fleet(_ST.bus, _ST.db)
    out["ok"] = True
    return out


@router.get("/overview")
async def overview(request: Request):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    out: Dict[str, Any] = {"ok": True, "now_ms": now_ms(),
                           "admin_version": ADMIN_VERSION}
    with contextlib.suppress(Exception):
        active = await _ST.bus.active_rooms()
        discovered = await _ST.bus.discovered_members()
        out["rooms"] = {"active_total": len(active),
                        "discovered": len(discovered),
                        "manual": len(set(active) - set(discovered))}
    with contextlib.suppress(Exception):
        out["pending"] = len(await _ST.bus.pending_items())
    with contextlib.suppress(Exception):
        out["queue_depth"] = int(await _ST.bus.r.zcard(K_SCHED))
    with contextlib.suppress(Exception):
        out["retention_last"] = await _ST.bus.retention_last()
    with contextlib.suppress(Exception):
        out["discovery_last"] = await _ST.bus.discovery_last()
    with contextlib.suppress(Exception):
        st = await _ST.bus.r.hgetall("stats:ingest")
        out["ingest"] = st or None
    with contextlib.suppress(Exception):
        out["target_rev"] = await _ST.db.cfg_latest_rev()
    with contextlib.suppress(Exception):
        # 5.4.0:清扫报错 / 触及行数上限 / 清扫停摆 / 保留期被关 —— 只读进程内状态,零查询
        out["storage_alerts"] = lifecycle.quick_alerts()
        # worker 大表清理停摆:复用本函数前面已读到的 retention_last,零额外查询
        wa = (lifecycle.worker_retention_alert(out["retention_last"])
              if "retention_last" in out else None)     # 读失败时不臆断停摆
        if wa:
            out["storage_alerts"].append(wa)
    return out


# ── 存储与保留(5.4.0)────────────────────────────────────────────────────────
#    「库里每一张表凭什么不会无限增长」的一屏答案:全表登记(lifecycle.TABLES)+ 各表
#    现在多大 + 上次清扫结果 + 告警。只读体检带 15s 短缓存(用户库在公网,连点刷新
#    不该变成连环查询);fresh=1 跳过缓存。
@router.get("/storage")
async def storage(request: Request, fresh: int = Query(0, ge=0, le=1)):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    snap = await lifecycle.snapshot(_ST.db, _ST.bus.r, fresh=bool(fresh))
    return _no_store(JSONResponse(snap))


_SWEEP_BG: set = set()        # 「立即清扫」后台任务的强引用(防被 GC 掐断)
_SWEEP_WAIT_S = 20.0          # 请求最多陪跑这么久;没跑完的转入后台,界面轮询 /storage 看结果


def _sweep_done(t: "asyncio.Task") -> None:
    _SWEEP_BG.discard(t)
    if not t.cancelled() and t.exception() is not None:
        # 取走异常:不取的话只会在 GC 时冒一句无主的「Task exception was never retrieved」
        print(f"[保留] ⚠️ 立即清扫(后台)异常: {t.exception()!r}")


@router.post("/storage/sweep")
async def storage_sweep(request: Request):
    """立即清扫一轮(三路:观测库小表 / 用户库各表 / Redis 离场房快照;rounds/predictions
    仍由 worker 每小时裁剪)。

    清扫本身全是幂等的「删掉已经过期的」,与定时轮跑的是同一份代码;按钮的用处是
    「改完保留期不想等 6 小时」与「排障时当场看结果」。撞上正在跑的定时轮 → 该存储
    回 busy,不并发。积压很大时本请求只陪跑 20s,其余在后台跑完。
    """
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    task = asyncio.create_task(lifecycle.sweep_now(_ST.db, _ST.bus))
    _SWEEP_BG.add(task)
    task.add_done_callback(_sweep_done)
    done, _pending = await asyncio.wait({task}, timeout=_SWEEP_WAIT_S)
    if not done:
        await _audit(_actor(payload), "storage_sweep", {"background": True})
        return {"ok": True, "running": True}
    try:
        res = task.result()
    except Exception as e:             # noqa: BLE001
        return JSONResponse({"ok": False, "error": "sweep_failed", "hint": repr(e)},
                            status_code=500)
    brief = {k: ({"busy": True} if v.get("busy") else {"skipped": True} if v.get("skipped")
                 else {"deleted": v.get("deleted", 0), "errors": v.get("errors", 0),
                       "capped": bool(v.get("capped"))})
             for k, v in res.items()}
    await _audit(_actor(payload), "storage_sweep", brief)
    return {"ok": True, "running": False, "result": res}


@router.get("/audit")
async def audit(request: Request, limit: int = Query(100, ge=1, le=1000),
                action: str = Query("")):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    return {"ok": True,
            "items": await _ST.db.audit_list(limit, action or None)}


# ── 疑似脚本来源(L4,安全加固 3.9.2)——**纯呈现 / 供人工研判,绝不自动封禁** ─────
def _looks_like_browser(ua: str) -> bool:
    """粗判 UA 是否像主流浏览器。仅作**弱**信号(UA 可随意伪造),故权重很低。"""
    if not ua:
        return False
    s = ua.lower()
    return any(t in s for t in ("mozilla", "chrome", "safari", "firefox",
                                "edg", "opera", "webkit", "gecko"))


def _sig_score(rec: Dict[str, Any]) -> Dict[str, Any]:
    """把一份会话画像折成 0–100 的「疑似脚本」分,并给出**可解释因子**。

    设计要点(务必守住,以维持零误伤 enforcement):
      · 本分数**只**用于管理台呈现 / 人工研判 / 可选的软限流分层,**绝不**用作自动封禁;
      · 真正的自动动作只由确定性事件(L1 租约违规 / L2 证明缺失)触发;
      · 因子对人友好可读,便于运营者自行判断(而非黑箱下判决)。

    ── 4.9.0 误报修复(实地复现驱动,逐条对应一次真实的真人误判)────────────────
    旧版给正常使用的真人稳定打 **65 分**(45+20),复现路径已在 jsdom / fakeredis
    上逐字节钉死。四处结构性缺陷与修法:

    ① **一次性事件 vs 滚动窗口的量纲错配** —— `html` 在 SPA 里整个页面生命周期只
       发生一次,而画像 Hash 的 TTL 由「最近一次事件」续期。手机锁屏 / 标签页后台
       超过窗口 → 画像过期 → 回前台第一拍打明细,画像**以 html=0 重建** → 真人稳踩
       最强因子。修法:引入与画像解耦的长效**浏览器足迹**(`foot`,默认 24h)与
       **执行证明实证**(`pow_ok>0`)作为无罪证据,二者任一成立即不再判「从不加载页面」。
    ② **同一次被拒请求双计** —— `_proof_guard` 记 pow_fail,中间件对同一请求的 401
       又记 detail,而阈值写的是 `detail + pow_fail >= 8`,等于门槛只有 4 次。
       修法:`detail` 本就含被挡请求(见 test_observe_classifies_all_kinds),
       阈值只看 detail。
    ③ **计数而非速率** —— 画像里明明存了 first/last 却一个都没用。「30 分钟里 10 次
       失败」与「5 秒里 10 次失败」旧版同分。修法:折成每分钟速率再判。
    ④ **无罪信号被丢弃** —— detail_ok / sse / pow_ok 采集了却不参与评分,评分只加不减。
       修法:pow_ok>0 抑制「从不加载页面」与「不取静态资源」两个软因子,并把
       detail_ok / sse / pow_stale 作为 notes 呈现给研判者。

    **对搬运器的判定零削弱**:纯 API 搬运器 foot 为假、pow_ok 恒 0、速率极高,
    上述所有门槛照旧全中(回归用例 test_score_scraper_profile_is_high 仍 ≥80)。
    老画像(无 first/last/foot 字段)按「计数即速率」退化,与 3.9.x 同量级。"""
    def _i(k: str) -> int:
        try:
            return int(rec.get(k, 0) or 0)
        except Exception:                     # noqa: BLE001
            return 0

    html, asset = _i("html"), _i("asset")
    detail, detail_ok = _i("detail"), _i("detail_ok")
    pow_ok, pow_fail, pow_stale = _i("pow_ok"), _i("pow_fail"), _i("pow_stale")
    sse, rooms = _i("sse"), _i("rooms")
    first, last = _i("first"), _i("last")
    foot = bool(rec.get("foot", False))
    ua = str(rec.get("ua", "") or "")

    # 观测跨度(分钟)。缺 first/last(老画像/单元测试构造)→ 1.0 = 「计数即速率」,
    # 与 3.9.x 的绝对阈值同量级,故不会因为字段缺失而放走任何搬运器。
    span_min = 1.0
    # 用 `last > first` 而不是 `first and last`:后者会把 first=0 误当成"字段缺失"。
    # 生产里 first 恒为 hsetnx 落的真实时间戳,但守卫本身不该有这个坑。
    if last and last > first:
        span_min = max(1.0, (last - first) / 60000.0)
    # **stale 的良性解释,只授予"证明过自己"的会话**(对抗性自审的第二道闸)。
    # 从未通过过任何一次证明的会话,它的 stale 与 fail 在语义上无法区分 —— 把两者
    # 合并计,搬运器就无法靠"乱发一个证明头"把失败洗成不计分的过期。
    eff_fail = pow_fail if pow_ok > 0 else (pow_fail + pow_stale)
    fail_rate = eff_fail / span_min
    room_rate = rooms / span_min

    # ── 无罪证据(强弱两档)────────────────────────────────────────────────
    # pow_ok>0 最硬:它意味着对方**真的执行了本站(部署时被混淆的)JS**,
    #            这正是 L2 存在的意义 —— 能算出应答的,定义上就不是「不跑 JS 的搬运器」。
    # foot     次之:本会话曾以浏览器姿态取过 HTML/静态资源。长效键,不随画像窗漂移。
    proof_browser = pow_ok > 0
    # 刻意**不**把 `asset > 0` 单列为浏览器证据:取过静态资源的会话本就会被打上
    # foot(足迹在 html/asset 两类事件上都置位),所以它是冗余的;而一旦足迹被关掉
    # (signal_footprint_ttl_s=0),"只取静态、从不取 HTML"反倒成了搬运器的免检通道。
    ever_browser = proof_browser or foot or html > 0

    score = 0
    reasons: list = []
    notes: list = []

    # ① 从不加载页面(HTML)却在打明细端点 —— 纯 API 搬运器的典型形态(最强软信号)
    #    detail 已包含被 401/429 挡下的请求,故**不再**叠加 pow_fail(旧版双计)。
    if detail >= 8 and not ever_browser:
        score += 45
        reasons.append("从未加载页面(HTML)、也无任何浏览器足迹,却在访问明细端点")
    elif detail >= 8 and not proof_browser and html == 0 and foot:
        # 本窗口内确实没取过页面,但本会话更早以浏览器姿态取过 —— 弱化为中等信号,
        # 且文案如实说明,不再把「锁屏回来的真人」按最强因子处理。
        score += 20
        reasons.append("本观察窗内未加载页面,但同一会话此前有浏览器足迹(疑度已下调)")

    # ② 执行证明反复失败且**从未**通过 —— L2 开启时,不跑 JS 的搬运器会卡在这里。
    #    加速率门:真人因挑战过期产生的零星失败(≈0.33 次/分)永远够不着。
    # 这一条**刻意不加速率门**:`pow_ok == 0` 本身就已经排除了任何健康的真人会话
    # (L2 开启时真浏览器必然通过过),再加速率门只会放走"慢速搬运器",纯属自伤。
    if eff_fail >= 5 and pow_ok == 0:
        score += 35
        reasons.append(f"执行证明失败 {eff_fail} 次、从未通过(疑似不执行 JS)")
    # 兜底分支保留 3.9.2 的**绝对下限 10**:画像刚重建时 span_min 会退化到 1 分钟,
    # 若只看速率,"3 次失败 2 次成功"这种开机瞬时抖动也能凑够 2.0/分。下限 + 速率 +
    # 「失败多于成功」三条同时成立才计分,真人的任何瞬时抖动都够不着。
    elif pow_fail >= 10 and fail_rate >= 2.0 and pow_fail > pow_ok:
        score += 20
        reasons.append(f"执行证明高频失败(≈{fail_rate:.1f} 次/分,且失败多于成功)")

    # ③ 加载了页面却从不请求静态资源 —— 次要信号。**热缓存回访的真人天然如此**,
    #    故有执行证明实证时整条抑制(否则它就是一台专produce误报的机器)。
    if html > 0 and asset == 0 and detail >= 10 and not proof_browser:
        score += 15
        reasons.append("加载了页面却从不请求静态资源(注意:热缓存回访亦可能如此)")

    # ④ 短时轮转多个直播间 —— 采集式抓取的常见形态。同样折成速率:
    #    真人半小时里切 6 个房 ≈0.2 个/分;采集器 2 分钟扫 9 个 ≈4.5 个/分。
    if rooms >= 6 and room_rate >= 1.0:
        score += 15
        reasons.append(f"短时访问 {rooms} 个不同直播间(≈{room_rate:.1f} 个/分)")

    # ⑤ 非主流浏览器 UA —— 最弱信号(UA 可伪造),权重最低
    if ua and not _looks_like_browser(ua):
        score += 10
        reasons.append("User-Agent 非主流浏览器")

    # ── 研判辅助(不计分,只呈现)——把此前被丢弃的无罪信号交还给运营者 ────────
    if proof_browser:
        notes.append(f"执行证明通过 {pow_ok} 次 —— 对方确实在执行本站 JS")
    if foot and html == 0:
        notes.append("同一会话此前加载过页面/静态资源(长效足迹仍在)")
    if pow_stale:
        notes.append(f"{pow_stale} 次证明因**服务端挑战过期/轮转**未命中(良性,不计疑度)")
    if sse:
        notes.append(f"持有 {sse} 次 SSE 实时流(浏览器长连形态)")
    if detail and detail_ok:
        notes.append(f"明细请求成功率 {detail_ok}/{detail}")
    if span_min > 1.0:
        notes.append(f"观察跨度 ≈{span_min:.0f} 分钟")

    return {"score": min(100, score), "reasons": reasons, "notes": notes,
            "span_min": round(span_min, 1),
            "fail_rate": round(fail_rate, 2), "room_rate": round(room_rate, 2)}


@router.get("/signals")
async def signals(request: Request, limit: int = Query(100, ge=1, le=500),
                  min_score: int = Query(0, ge=0, le=100)):
    """疑似脚本来源清单:按分降序。**只读呈现**,不触发任何封禁动作。
    未开启 signal_scoring(或登录系统未启用)→ enabled:false + 空表。"""
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    enabled = bool(getattr(settings.userauth, "enabled", False)
                   and getattr(settings.userauth, "signal_scoring", False))
    # settings.userauth.enabled 可能是方法或布尔,做一次兼容取值
    try:
        _en = settings.userauth.enabled
        enabled = bool((_en() if callable(_en) else _en)
                       and getattr(settings.userauth, "signal_scoring", False))
    except Exception:
        pass
    if not enabled:
        return {"ok": True, "enabled": False, "sources": [], "now_ms": now_ms()}
    window_ms = int(float(getattr(settings.userauth, "signal_window_s", 1800.0)) * 1000)
    rows: list = []
    with contextlib.suppress(Exception):
        rows = await _ST.bus.sig_top(window_ms=window_ms, limit=int(limit))
    scored = []
    for r in rows:
        s = _sig_score(r)
        if s["score"] < int(min_score):
            continue
        item = dict(r)
        item["score"] = s["score"]
        item["reasons"] = s["reasons"]
        # 4.9.0:研判辅助字段(无罪信号 / 速率 / 观察跨度)——面板据此避免"只看分数"
        item["notes"] = s["notes"]
        item["span_min"] = s["span_min"]
        item["fail_rate"] = s["fail_rate"]
        item["room_rate"] = s["room_rate"]
        scored.append(item)
    scored.sort(key=lambda x: (x["score"], x.get("last", 0)), reverse=True)
    return {"ok": True, "enabled": True, "now_ms": now_ms(),
            "window_s": int(window_ms // 1000), "count": len(scored),
            "sources": scored}


# ── 活跃房租约(3.9.4):管理台可见性 + 极端卡死的人工解卡 ───────────────────────
@router.get("/leases")
async def leases(request: Request):
    """每账号「同一时间只监控 1 个活跃房」租约的**只读**清单。此前该状态对运维完全
    不可见 —— 只能靠前端行为反推。呈现:uid/用户名/活跃房(归一号+别名)/活页数/
    最近活动。未启用登录系统 → enabled:false + 空表(租约本就不生效)。"""
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    from . import userauth as _ua
    if not _ua.enabled():
        return {"ok": True, "enabled": False, "leases": [], "now_ms": now_ms()}
    rows = await _ST.bus.active_room_leases()
    names: Dict[int, str] = {}
    with contextlib.suppress(Exception):
        names = await _ua.user_names([r["uid"] for r in rows])
    ttl_ms = int(max(5.0, float(getattr(settings.userauth,
                                        "active_room_lease_ttl_s", 40.0))) * 1000)
    out = []
    for r in rows:
        alias = ""
        with contextlib.suppress(Exception):
            alias = await _ST.bus.alias_of(r["room"])
        out.append({**r, "uname": names.get(r["uid"], ""),
                    "alias": ("" if str(alias) == str(r["room"]) else str(alias)),
                    "stale": bool((now_ms() - int(r["ts"] or 0)) > ttl_ms)})
    return {"ok": True, "enabled": True, "now_ms": now_ms(),
            "ttl_ms": ttl_ms, "count": len(out), "leases": out}


@router.post("/leases/{uid}/release")
async def lease_force_release(uid: int, request: Request):
    """强制释放某账号的活跃房租约(整把 DEL,写操作走 CSRF)。语义与「持租端崩溃后
    TTL 过期」完全同源:释放后各窗口下一拍 renew 因空租约重新授予自己在看的房,
    先到者持租、其余跟随 —— 不引入任何新状态,天然自愈。用途仅限极端卡死解卡;
    常态下 last-wins + 三路释放 + TTL 已自洽,本端点是运维兜底不是日常工具。"""
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    freed = await _ST.bus.active_room_lease_force_release(int(uid))
    await _audit(_actor(payload), "lease_force_release",
                 {"uid": int(uid), "freed": bool(freed)})
    return {"ok": True, "uid": int(uid), "freed": bool(freed)}


# ── 名录(复用既有名录机制;别名编辑 / 挂起放弃是管理台补的两个小口) ─────────────
ROOMS_PAGE_SIZE_DEFAULT = 50
ROOMS_PAGE_SIZE_MAX = 200


def _paginate(seq: List[Any], page: int, size: int) -> Dict[str, Any]:
    """把整表切成一页。page 越界向内夹紧(删掉末页最后一行后不会掉进空页)。"""
    size = max(1, min(int(size or ROOMS_PAGE_SIZE_DEFAULT), ROOMS_PAGE_SIZE_MAX))
    total = len(seq)
    pages = max(1, (total + size - 1) // size)
    page = max(1, min(int(page or 1), pages))
    off = (page - 1) * size
    return {"slice": seq[off:off + size], "page": page, "page_size": size,
            "total": total, "pages": pages}


@router.get("/rooms")
async def rooms(request: Request,
                page: int = Query(1, ge=1),
                page_size: int = Query(ROOMS_PAGE_SIZE_DEFAULT, ge=1,
                                       le=ROOMS_PAGE_SIZE_MAX),
                q: str = Query(""),
                src: str = Query("all"),
                ppage: int = Query(1, ge=1),
                ppage_size: int = Query(ROOMS_PAGE_SIZE_DEFAULT, ge=1,
                                        le=ROOMS_PAGE_SIZE_MAX)):
    """名录分页。

    此前逐房 `await bus.room_meta(rid)` —— 一房一次 HGET 往返。数千房时光是
    Redis 往返就要数秒(实测 3000 房 ≈ 3.5s @150µs RTT),前端再一次性铺几万个
    DOM 节点,合起来就是「名录一多载入就卡」。

    现在:整张 rooms 哈希一次 HGETALL 取回(3 次往返封顶,与房数无关),
    过滤/排序/切页都在内存里做,只把当前页(默认 50 行)交给前端。
    `q` 按房号或别名子串匹配(仅作用于活跃名录);`src` ∈ all|manual|discovered。
    挂起表走自己的分页(ppage/ppage_size),避免它成为下一个瓶颈。
    """
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload

    active = await _ST.bus.active_rooms()
    discovered = await _ST.bus.discovered_members()
    metas_raw = await _ST.bus.r.hgetall(K_ROOMS)      # ← 一次拿全,取代 N 次 HGET

    items: List[Dict[str, Any]] = []
    for rid in active:                                # active_rooms() 已排序
        raw = metas_raw.get(rid)
        try:
            meta = json.loads(raw) if raw else {}
        except (TypeError, ValueError):               # 不是 JSON
            meta = {}
        if not isinstance(meta, dict):                # 是 JSON 但不是对象(如 `123` / `[]`)
            meta = {}
        alias = meta.get("alias")
        items.append({"room": rid,
                      # alias 落库时可能被写成数字/None —— 统一成字符串,否则下面 .lower() 会炸
                      "alias": str(alias) if alias not in (None, "") else rid,
                      "added_at": meta.get("added_at"),
                      "discovered": rid in discovered})

    active_total = len(items)
    manual_total = sum(1 for it in items if not it["discovered"])

    if src == "manual":
        items = [it for it in items if not it["discovered"]]
    elif src == "discovered":
        items = [it for it in items if it["discovered"]]

    needle = (q or "").strip().lower()
    if needle:
        items = [it for it in items
                 if needle in it["room"].lower() or needle in it["alias"].lower()]

    # 挂起表独立分页、不受 q/src 影响:搜索框长在「活跃名录」卡片里,
    # 让它顺手筛掉下面另一张卡的内容会很意外(「我的挂起项去哪了?」)。
    # 它的渲染成本由自己的分页兜住,这才是「名录一多就卡」的正解。
    pend = await _ST.bus.pending_items()
    pending_all = [{"alias": a, "since_ms": t} for a, t in sorted(pend.items())]

    pg = _paginate(items, page, page_size)
    pp = _paginate(pending_all, ppage, ppage_size)
    return {"ok": True,
            "items": pg["slice"], "page": pg["page"], "page_size": pg["page_size"],
            "total": pg["total"], "pages": pg["pages"],
            "pending": pp["slice"], "pending_page": pp["page"],
            "pending_pages": pp["pages"], "pending_total": pp["total"],
            "active_total": active_total, "manual_total": manual_total,
            "discovered_total": len(discovered),
            "q": needle, "src": src if src in ("all", "manual", "discovered") else "all"}


@router.post("/rooms/{room}/alias")
async def room_alias(room: str, request: Request):
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    body = await _body(request)
    alias = str(body.get("alias") or "").strip() or str(room)
    raw = await _ST.bus.r.hget(K_ROOMS, str(room))
    if not raw:
        return JSONResponse({"ok": False, "error": "room_not_found"}, status_code=404)
    try:
        meta = json.loads(raw)
    except ValueError:
        meta = {}
    meta["alias"] = alias
    await _ST.bus.r.hset(K_ROOMS, str(room), json.dumps(meta, ensure_ascii=False))
    with contextlib.suppress(Exception):
        await _ST.db.upsert_room(str(room), alias, True, pending=False)
    await _audit(_actor(payload), "room_alias", {"room": room, "alias": alias})
    return {"ok": True, "room": room, "alias": alias}


@router.delete("/rooms/pending/{alias}")
async def pending_abandon(alias: str, request: Request):
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    await _ST.bus.pending_remove(str(alias))
    with contextlib.suppress(Exception):
        await _ST.db.upsert_room(str(alias), str(alias), False, pending=False)
    await _audit(_actor(payload), "pending_abandon", {"alias": alias})
    return {"ok": True}


# ── 票据健康 / 探活 / 应急覆盖 ────────────────────────────────────────────────
def _ticket_fp() -> Dict[str, Any]:
    f = reg.REGISTRY["auth.ticket"]
    tk = str(settings.auth.ticket or "")
    # 1.4.3(C3):占位/空票据显式亮牌。掩码后的占位串(PUT_YOUR…HERE)带着
    # 指纹,静态看与真票无异 —— 小白无从分辨「已配置」与「还没换」;前端据
    # configured=false 给黄条。判据:非空且 ≠ 注册表默认占位符。
    return {"uid": str(settings.auth.uid or ""),
            "ticket_masked": cfgc.mask(f, tk),
            "ticket_fp": cfgc.fingerprint(tk) if tk else "",
            "configured": bool(tk) and tk != str(f.default)}


@router.get("/auth/status")
async def auth_status(request: Request):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    _rev, snap = await _ST.db.cfg_latest()
    if "auth.ticket" in snap:
        source = "runtime"
    elif (settings.auth_cookie_file or "").strip():
        source = "cookie"
    elif os.environ.get("STA_AUTH_TICKET"):
        source = "env"
    else:
        source = "yaml/default"
    out: Dict[str, Any] = {"ok": True, "source": source, **_ticket_fp(),
                           "app_id": str(settings.auth.app_id),
                           "token_type": str(settings.auth.token_type)}
    path = (settings.auth_cookie_file or "").strip()
    cookie: Dict[str, Any] = {"path": path, "exists": False}
    if path:
        with contextlib.suppress(Exception):
            stt = os.stat(path)
            cookie.update({"exists": True, "mtime_ms": int(stt.st_mtime * 1000),
                           "age_s": int(time.time() - stt.st_mtime)})
        state_path = os.path.join(os.path.dirname(path) or ".", "refresh_state.json")
        with contextlib.suppress(Exception):
            with open(state_path, "r", encoding="utf-8") as f:
                cookie["refresh_state"] = json.load(f)
        trg = _kg_trigger_path()
        cookie["trigger_pending"] = bool(trg and os.path.exists(trg))
    out["cookie"] = cookie
    return out


# ── 酷狗账号库(kgdata/accounts.json):管理台可视化编辑 ─────────────────────────
# login 服务(kugou_login.refresher)每次刷新前都会重新 load_accounts,故此处
# 保存即生效于下一轮续期(失效即刷 / 兜底周期),无需重启;refresher 对该文件
# 只读不写(它写的是 config/state),web 侧写入无并发冲突。密码永不回传明文。
def _kg_accounts_path() -> str:
    p = (os.environ.get("STA_KG_ACCOUNTS") or "").strip()
    if p:
        return p
    ck = (settings.auth_cookie_file or "").strip()
    if ck:
        return os.path.join(os.path.dirname(ck) or ".", "accounts.json")
    return ""


def _kg_read_raw(path: str) -> Dict[str, Any]:
    """读原文件为 dict 形态;裸数组归一为 {'accounts': [...]}。
    顶层 '_' 前缀键(_说明/_安全 等模板注释)原样保留,写回不丢。"""
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return {"accounts": data}
    if not isinstance(data, dict):
        return {"accounts": []}
    data.setdefault("accounts", [])
    return data


def _kg_mask(item: Dict[str, Any]) -> Dict[str, Any]:
    pwd = str(item.get("password", "") or "")
    return {"username": str(item.get("username", "")).strip(),
            "mid": str(item.get("mid", "")).strip(),
            "note": str(item.get("note", "") or ""),
            "enabled": bool(item.get("enabled", True)),
            "password_set": bool(pwd),
            # env:VAR 形态展示变量名(本身不敏感),便于辨认来源
            "password_env": pwd[4:] if pwd.startswith("env:") else ""}


def _kg_merge(old: List[Dict[str, Any]], new: List[Dict[str, Any]]
              ) -> tuple[List[Dict[str, Any]], Dict[str, Any], List[str]]:
    """合并语义:new 为最终名单;password 留空 = 按 username 沿用旧密文,
    非空 = 设新值(允许 env:VAR)。返回 (最终列表, 审计摘要, errors)。
    摘要只含用户名与计数 —— 绝不含密码明文。"""
    errors: List[str] = []
    old_by_user = {str(a.get("username", "")).strip(): a for a in old
                   if str(a.get("username", "")).strip()}
    seen: set = set()
    final: List[Dict[str, Any]] = []
    pwd_changed: List[str] = []
    for i, it in enumerate(new):
        u = str(it.get("username", "")).strip()
        if not u:
            errors.append(f"第 {i + 1} 行:用户名不能为空")
            continue
        if u.startswith("_"):
            errors.append(f"第 {i + 1} 行:用户名不能以下划线开头(与模板注释键冲突)")
            continue
        if u in seen:
            errors.append(f"用户名重复:{u}(密码沿用将产生歧义)")
            continue
        seen.add(u)
        pwd = str(it.get("password", "") or "")
        prev = old_by_user.get(u)
        if not pwd:
            if prev is None:
                errors.append(f"新增账号 {u} 必须填写密码(或 env:变量名)")
                continue
            pwd = str(prev.get("password", "") or "")
        elif prev is not None and pwd != str(prev.get("password", "") or ""):
            pwd_changed.append(u)
        mid = str(it.get("mid", "")).strip()
        final.append({"username": u, "password": pwd, "mid": mid,
                      "note": str(it.get("note", "") or ""),
                      "enabled": bool(it.get("enabled", True))})
    added = sorted(seen - set(old_by_user))
    removed = sorted(set(old_by_user) - seen)
    summary = {"total": len(final), "added": added, "removed": removed,
               "pwd_changed": pwd_changed}
    return final, summary, errors


@router.get("/auth/accounts")
async def kg_accounts_get(request: Request):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    path = _kg_accounts_path()
    out: Dict[str, Any] = {"ok": True, "path": path, "exists": False,
                           "writable": False, "accounts": []}
    if not path:
        out["hint"] = ("未配置账号库路径:需设 STA_AUTH_COOKIE_FILE(compose 默认已设,"
                       "账号库取其同目录 accounts.json)或显式 STA_KG_ACCOUNTS。")
        return out
    d = os.path.dirname(path) or "."
    exists = os.path.isfile(path)
    out["exists"] = exists
    out["writable"] = (os.access(path, os.W_OK) if exists
                       else os.access(d, os.W_OK))
    if exists:
        with contextlib.suppress(Exception):
            out["mtime_ms"] = int(os.stat(path).st_mtime * 1000)
        try:
            raw = _kg_read_raw(path)
        except Exception as e:
            out["ok"] = False
            out["error"] = "parse_failed"
            out["hint"] = f"账号库 JSON 解析失败:{e!r} —— 请先在主机上修复该文件"
            return out
        out["accounts"] = [_kg_mask(a) for a in raw.get("accounts", [])
                           if isinstance(a, dict)
                           and not str(a.get("username", "")).startswith("_")]
    if not out["writable"]:
        out["hint"] = ("当前部署对账号库不可写:compose 中 web 服务的 kgdata 挂载需去掉 "
                       ":ro(本版 docker-compose.yml 已放开;若仍只读请检查宿主目录权限)。")
    return out


@router.put("/auth/accounts")
async def kg_accounts_put(request: Request):
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    path = _kg_accounts_path()
    if not path:
        return JSONResponse({"ok": False, "error": "not_configured",
                             "hint": "未配置账号库路径(STA_AUTH_COOKIE_FILE / "
                                     "STA_KG_ACCOUNTS)"}, status_code=400)
    body = await _body(request)
    new = body.get("accounts")
    if not isinstance(new, list):
        return JSONResponse({"ok": False, "errors": ["缺少 accounts 数组"]},
                            status_code=400)
    raw: Dict[str, Any] = {"accounts": []}
    if os.path.isfile(path):
        try:
            raw = _kg_read_raw(path)
        except Exception as e:
            return JSONResponse({"ok": False, "error": "parse_failed",
                                 "hint": f"现有账号库 JSON 损坏,拒绝盲写:{e!r}"},
                                status_code=409)
    final, summary, errors = _kg_merge(
        [a for a in raw.get("accounts", []) if isinstance(a, dict)], new)
    if errors:
        return JSONResponse({"ok": False, "errors": errors}, status_code=400)
    warnings: List[str] = []
    for a in final:                                   # 软校验:提示不阻断
        m = a["mid"]
        if m and not (len(m) == 32 and all(c in "0123456789abcdefABCDEF" for c in m)):
            warnings.append(f"{a['username']} 的 mid 不是 32 位十六进制"
                            "(登录时可能触发短信验证)")
    # 保留所有非 accounts 顶层键(模板注释键、用户自定义键)。此前只保留 "_"
    # 前缀键会静默丢弃用户加的其它顶层键 —— 编辑器只负责 accounts,不动其余。
    doc = {k: v for k, v in raw.items() if k != "accounts"}
    doc["accounts"] = final
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(doc, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp, path)                                        # 原子替换
    except OSError as e:
        with contextlib.suppress(Exception):
            os.unlink(tmp)
        return JSONResponse(
            {"ok": False, "error": "not_writable",
             "hint": ("写入失败(挂载只读或目录无权限):" + repr(e)
                      + " —— compose 需去掉 web 侧 kgdata 的 :ro 并确认宿主目录属主")},
            status_code=409)
    await _audit(_actor(payload), "kg_accounts_edit", summary)       # 摘要无密码
    return {"ok": True, **summary, "warnings": warnings,
            "hint": ("已写盘;可点上方「立即触发续期」马上用新账号重登,"
                     "否则 login 于下轮刷新(失效即刷 / 兜底周期)自动读取。")}


def _kg_trigger_path() -> Optional[str]:
    """「立即续期」触发文件路径,与 refresher 的派生规则对齐:refresher 以 state
    文件所在目录为准,而 state 与 cookie 文件同目录(compose 下均为 /kgdata),
    故优先取 STA_AUTH_COOKIE_FILE 所在目录;未配置时回退 accounts.json 目录。
    单独设置 STA_KG_ACCOUNTS 指向他处时,以 cookie 目录为准才能被 login 感知。"""
    base = (settings.auth_cookie_file or "").strip()
    if base:
        return os.path.join(os.path.dirname(base) or ".", "refresh_now")
    acc = _kg_accounts_path()
    if acc:
        return os.path.join(os.path.dirname(acc) or ".", "refresh_now")
    return None


@router.post("/auth/refresh_now")
async def kg_refresh_now(request: Request):
    """落「立即续期」触发文件:login 守护(本版 kugou_login)在休眠中以 ≤2s 粒度
    感知并提前唤醒执行刷新 —— 改完账号库/口令失效时不必重启、不必苦等重试间隔。
    旧版 login 镜像会忽略该文件(下轮探测周期照常),纯增量兼容。"""
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    trigger = _kg_trigger_path()
    if not trigger:
        return JSONResponse({"ok": False, "error": "not_configured",
                             "hint": "未配置 kgdata 路径(STA_AUTH_COOKIE_FILE / "
                                     "STA_KG_ACCOUNTS)"}, status_code=400)
    # 防重:2 分钟内已有未消费的触发,直接告知无需重复(防连点造成连环真实登录)
    with contextlib.suppress(OSError):
        if time.time() - os.stat(trigger).st_mtime < 120:
            return {"ok": True, "pending": True,
                    "hint": "已有待处理的触发信号(2 分钟内下发过),login 将尽快"
                            "执行;无需重复触发。"}
    try:
        with open(trigger, "w", encoding="utf-8") as f:
            f.write(f"admin@{payload.get('ip', '?')} {int(time.time())}\n")
    except OSError as e:
        return JSONResponse(
            {"ok": False, "error": "not_writable",
             "hint": "触发文件写入失败(kgdata 只读或无权限):" + repr(e)},
            status_code=409)
    await _audit(_actor(payload), "auth_refresh_now", {})
    return {"ok": True,
            "hint": ("已落触发信号;本版 login 服务将在数秒内开始重登(旧版镜像则于"
                     "下轮探测周期生效)。稍后可点「验证票据」确认新 Cookie。")}


@router.post("/auth/verify")
async def auth_verify(request: Request):
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    room = ""
    with contextlib.suppress(Exception):
        act = await _ST.bus.active_rooms()
        room = act[0] if act else ""
    room = room or (settings.rooms[0] if settings.rooms else "2678075")
    up = Upstream(settings.upstream.base_url, settings.auth.to_headers(),
                  timeout=min(10.0, float(settings.upstream.request_timeout)),
                  verify_tls=settings.upstream.verify_tls,
                  conn_limit=4, conn_per_host=4)
    result: Dict[str, Any]
    try:
        await up.start()
        data = await asyncio.wait_for(
            up.main_page(settings.activity_id, str(room)), timeout=12.0)
        if data is None:
            result = {"ok": False, "result": "no_response",
                      "hint": "上游无有效响应(网络/业务错误,详见 web 日志)"}
        else:
            result = {"ok": True, "result": "alive", "room": str(room)}
    except AuthExpired:
        result = {"ok": False, "result": "expired",
                  "hint": "上游返回 401/403:票据已过期,请等待自动续期或应急覆盖"}
    except Exception as e:
        result = {"ok": False, "result": "error", "detail": repr(e)}
    finally:
        with contextlib.suppress(Exception):
            await up.close()
    await _audit(_actor(payload), "auth_verify", {"result": result.get("result")})
    return result


@router.post("/auth/override")
async def auth_override(request: Request):
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    body = await _body(request)
    changes: Dict[str, Any] = {}
    if str(body.get("ticket") or "").strip():
        changes["auth.ticket"] = str(body["ticket"]).strip()
    if str(body.get("uid") or "").strip():
        changes["auth.uid"] = str(body["uid"]).strip()
    if not changes:
        return JSONResponse({"ok": False, "errors": ["ticket/uid 至少提供一项"]},
                            status_code=422)
    note = str(body.get("note") or "票据应急覆盖(管理台)")
    resp = await _do_apply(changes=changes, removed=(), note=note,
                           actor=_actor(payload), action="auth_override")
    if resp.status_code == 200:
        data = json.loads(bytes(resp.body).decode("utf-8"))
        data["hint"] = ("应急覆盖已下发;若 login 服务在跑,其下一轮刷新出的新 Cookie "
                        "将按既有链路盖回本值")
        return JSONResponse(data)
    return resp


# ── 部署层(只读清单) ─────────────────────────────────────────────────────────
@router.get("/deploy")
async def deploy(request: Request):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    return {"ok": True, "items": [dict(d) for d in reg.DEPLOY_ITEMS]}


# ══ 注册与邀请(4.0.0:「注」视图后端;<管理前缀>/reg/*)═══════════════════════
# 全部复用既有守卫(会话 + 写操作 CSRF)与审计通道;SQL/DAO 全在 userauth.py
# (tb_user 纪律的静态扫描只需盯一个文件)。登录系统未启用 → enabled:false。
def _reg_ua():
    from . import userauth as _ua      # 延迟导入:与既有「疑/租约」视图同款姿态
    return _ua


@router.get("/reg/overview")
async def reg_overview(request: Request):
    """总控数据面:模式(配置/生效)/熔断态/今日与 7 日曲线/难度水位/邀请码概况。"""
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    _ua = _reg_ua()
    if not _ua.enabled():
        return {"ok": True, "enabled": False}
    try:
        stats = await _ua.reg_stats()
    except Exception as e:             # noqa: BLE001
        return {"ok": False, "enabled": True, "error": "stats_failed",
                "hint": repr(e)}
    # 4.0.4:带出注册启动自检结论(tb_user 缺列会让注册整体 503,管理台据此显式告警;
    # fresh 版:参数中心热改 mode/形态/EXTRA_COLS 后自动重扫,横幅不再反向陈旧)
    probe = {}
    with contextlib.suppress(Exception):
        probe = await _ua.reg_probe_fresh()
    return {"ok": True, "enabled": True, "preflight": probe, **stats}


@router.get("/userdb/endpoints")
async def userdb_endpoints(request: Request):
    """用户库「多网络入口」实时健康与流量账(4.5.0;只读,零副作用)。

    这是验证「多 IP 到底有没有把带宽叠加上去」的唯一硬证据面:
      · state          up=在分流 / down=熔断中(downForS 秒后重试)/
                       mismatch=**不是同一个库**,已永久隔离 / new=尚未探过
      · bytesIn/Out    精确网络字节(挂在驱动收发收口上计的,不是估算)
      · inflight       路由层在飞查询数 —— 带宽压力的实时指标
      · rttMs          EWMA 往返时延
      · identity       该入口自报的身份指纹(server_uuid / server_id / hostname…)

    用法:curl -s -b cookie.txt http://<观测台>/api/<入口>/userdb/endpoints | jq
    """
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    _ua = _reg_ua()
    if not _ua.enabled():
        return {"ok": True, "enabled": False}
    r = getattr(_ua.UA, "router", None)
    if r is None:
        return {"ok": True, "enabled": True, "ready": False,
                "error": _ua.UA.init_error or "router_not_built"}
    return {"ok": True, "enabled": True, "ready": True, **r.snapshot()}


@router.post("/reg/mode")
async def reg_mode_set(request: Request):
    """三档模式热切换。走**同一** _do_apply 管线:结构/语义校验 → PG 不可变版本
    → rev 广播 → 本进程即刻套用 → 审计 —— 与参数中心手改 userauth.reg_mode
    完全同源(1.8.0 起两侧都不再要求键入参数名,改由 rev + 审计 + 一键回滚兜底)。"""
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    body = await _body(request)
    mode = str(body.get("mode") or "").strip().lower()
    if mode not in ("off", "invite", "open"):
        return JSONResponse({"ok": False, "error": "bad_mode",
                             "hint": "mode 须为 off / invite / open"}, status_code=422)
    return await _do_apply(changes={"userauth.reg_mode": mode}, removed=(),
                           note=str(body.get("note") or f"注册模式 → {mode}"),
                           actor=_actor(payload), action="reg_mode")


@router.post("/reg/breaker/clear")
async def reg_breaker_clear(request: Request):
    """熔断恢复(刻意只有手动路径 —— 自动回升会被脉冲攻击当节拍器玩弄)。"""
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    _ua = _reg_ua()
    if not _ua.enabled():
        return {"ok": True, "enabled": False, "cleared": False}
    cleared = await _ua.breaker_clear()
    await _audit(_actor(payload), "reg_breaker_clear", {"cleared": bool(cleared)})
    return {"ok": True, "enabled": True, "cleared": bool(cleared)}


@router.post("/reg/throttle/clear")
async def reg_throttle_clear(request: Request):
    """一键清空全部注册限流(4.0.3):guantai:reg:* 计数族,Redis + 进程内兜底双清。
    典型场景:自测/压测打满 R1 日窗;反代未透传真实 IP 令全站共享一个桶的误伤急救。
    刻意不触碰:熔断态(专属「恢复注册」手动路径)、进行中挑战载荷、登录失败锁。"""
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    _ua = _reg_ua()
    if not _ua.enabled():
        return {"ok": True, "enabled": False,
                "cleared": {"redis": 0, "mem": 0, "redis_ok": True}}
    cleared = await _ua.reg_throttle_clear()
    await _audit(_actor(payload), "reg_throttle_clear", dict(cleared))
    return {"ok": True, "enabled": True, "cleared": cleared}


@router.get("/reg/invites")
async def reg_invites(request: Request, page: int = Query(1, ge=1),
                      size: int = Query(50, ge=1, le=200),
                      all: int = Query(0, ge=0, le=1)):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    _ua = _reg_ua()
    if not _ua.enabled():
        return {"ok": True, "enabled": False, "items": [], "total": 0}
    try:
        data = await _ua.invites_page(page, size, bool(all))
    except Exception as e:             # noqa: BLE001
        return JSONResponse({"ok": False, "error": "userdb_unavailable",
                             "hint": repr(e)}, status_code=503)
    return {"ok": True, "enabled": True, **data}


@router.post("/reg/invites/generate")
async def reg_invites_generate(request: Request):
    """批量生成:条数(≤200)/ 配额 / 赠送天数 / 有效期天数(0=不过期)/ 备注。"""
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    _ua = _reg_ua()
    if not _ua.enabled():
        return JSONResponse({"ok": False, "error": "login_disabled"}, status_code=503)
    body = await _body(request)
    try:
        count = max(1, min(int(body.get("count") or 1), 200))
        quota = max(1, min(int(body.get("quota") or 1), 100000))
        days = max(0, min(int(body.get("days") or 0), 3650))
        expires = max(0, min(int(body.get("expiresDays") or 0), 3650))
        note = str(body.get("note") or "")[:100]
    except Exception:                  # noqa: BLE001
        return JSONResponse({"ok": False, "error": "bad_request"}, status_code=422)
    try:
        codes = await _ua.invites_generate(count, quota, days, expires, note)
    except Exception as e:             # noqa: BLE001
        return JSONResponse({"ok": False, "error": "userdb_unavailable",
                             "hint": repr(e)}, status_code=503)
    await _audit(_actor(payload), "reg_invites_generate",
                 {"count": len(codes), "quota": quota, "days": days,
                  "expiresDays": expires, "note": note})
    return {"ok": True, "codes": [_ua.fmt_invite_code(c) for c in codes]}


@router.post("/reg/invites/{iid}/disable")
async def reg_invite_disable(iid: int, request: Request):
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    _ua = _reg_ua()
    if not _ua.enabled():
        return JSONResponse({"ok": False, "error": "login_disabled"}, status_code=503)
    body = await _body(request)
    disabled = bool(body.get("disabled", True))
    try:
        okay = await _ua.invite_set_disabled(int(iid), disabled)
    except Exception as e:             # noqa: BLE001
        return JSONResponse({"ok": False, "error": "userdb_unavailable",
                             "hint": repr(e)}, status_code=503)
    await _audit(_actor(payload), "reg_invite_disable",
                 {"id": int(iid), "disabled": disabled})
    return {"ok": True, "changed": bool(okay)}


@router.get("/reg/log")
async def reg_log(request: Request, page: int = Query(1, ge=1),
                  size: int = Query(50, ge=1, le=200),
                  ip: str = Query(""), name: str = Query(""),
                  ok: str = Query(""), reason: str = Query("")):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    _ua = _reg_ua()
    if not _ua.enabled():
        return {"ok": True, "enabled": False, "items": [], "total": 0}
    try:
        data = await _ua.reg_log_page(page, size, ip, name, ok, reason)
    except Exception as e:             # noqa: BLE001
        return JSONResponse({"ok": False, "error": "userdb_unavailable",
                             "hint": repr(e)}, status_code=503)
    return {"ok": True, "enabled": True, **data}


# ── 5.2.0「登」登录风控:只读概览 / 流水 + 唯一的写「解锁」(审计落痕)──────────────
@router.get("/userlogin/risk")
async def userlogin_risk(request: Request, hours: int = Query(24, ge=1, le=168),
                         top: int = Query(20, ge=1, le=100)):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    _ua = _reg_ua()
    if not _ua.enabled():
        return {"ok": True, "enabled": False}
    try:
        data = await _ua.login_risk_overview(hours, top)
    except Exception as e:             # noqa: BLE001
        return JSONResponse({"ok": False, "error": "userdb_unavailable",
                             "hint": repr(e)}, status_code=503)
    return {"ok": True, "enabled": True, **data}


@router.get("/userlogin/log")
async def userlogin_log(request: Request, page: int = Query(1, ge=1),
                        size: int = Query(50, ge=1, le=200), ip: str = Query(""),
                        name: str = Query(""), ok: str = Query(""), reason: str = Query(""),
                        hours: int = Query(168, ge=1, le=2160)):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    _ua = _reg_ua()
    if not _ua.enabled():
        return {"ok": True, "enabled": False, "items": [], "total": 0}
    try:
        data = await _ua.login_log_page(page, size, ip, name, ok, reason, hours)
    except Exception as e:             # noqa: BLE001
        return JSONResponse({"ok": False, "error": "userdb_unavailable",
                             "hint": repr(e)}, status_code=503)
    return {"ok": True, "enabled": True, **data}


@router.post("/userlogin/unlock")
async def userlogin_unlock(request: Request):
    """清掉一个账号或 IP 段的登录失败计数。只动 guantai:lf:* 两类键;落审计。"""
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    _ua = _reg_ua()
    if not _ua.enabled():
        return JSONResponse({"ok": False, "error": "login_disabled"}, status_code=503)
    body = await _body(request)
    kind, value = str(body.get("kind") or ""), str(body.get("value") or "").strip()
    if kind not in ("user", "ip") or not value or len(value) > 64:
        return JSONResponse({"ok": False, "error": "bad_request",
                             "hint": "kind 须为 user/ip,value 非空且 ≤64 字符"}, status_code=400)
    res = await _ua.login_risk_unlock(kind, value)
    await _audit(_actor(payload), "login_unlock", {"kind": kind, "value": value,
                                                   "existed": res["existed"]})
    return {"ok": True, **res}


@router.get("/reg/blocks")
async def reg_blocks(request: Request):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    _ua = _reg_ua()
    if not _ua.enabled():
        return {"ok": True, "enabled": False, "items": []}
    try:
        data = await _ua.blocks_list()
    except Exception as e:             # noqa: BLE001
        return JSONResponse({"ok": False, "error": "userdb_unavailable",
                             "hint": repr(e)}, status_code=503)
    return {"ok": True, "enabled": True, **data}


@router.post("/reg/block")
async def reg_block(request: Request):
    """观测台侧封禁/解封(写 guantai_user_block;**不碰 tb_user 一个字节**)。
    命中者登录回 banned;在线会话最迟一个缓存周期(默认 20s)内全网下线。"""
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    _ua = _reg_ua()
    if not _ua.enabled():
        return JSONResponse({"ok": False, "error": "login_disabled"}, status_code=503)
    body = await _body(request)
    uids = body.get("userIds") or body.get("user_ids") or []
    unblock = bool(body.get("unblock"))
    note = str(body.get("note") or "")[:100]
    try:
        n = await _ua.blocks_set(uids, note, unblock)
    except Exception as e:             # noqa: BLE001
        return JSONResponse({"ok": False, "error": "userdb_unavailable",
                             "hint": repr(e)}, status_code=503)
    await _audit(_actor(payload), "reg_unblock" if unblock else "reg_block",
                 {"userIds": [int(u) for u in uids if str(u).strip().isdigit()],
                  "note": note, "affected": n})
    return {"ok": True, "affected": n}

# ══════════════════════════════════════════════════════════════════════════════
# 敏感值揭示(4.2.9)—— 「随时都能看到」
# ------------------------------------------------------------------------------
# 要解决的真问题:发卡 API 密钥是**我方自定、需要交付给对端**的凭据。而本台对敏感
# 项一律掩码(前 8 后 4),运维一旦没存好,就**再也拿不回来** —— 只能重新生成一把,
# 然后把发卡平台的配置也改一遍。换人接手、平台迁移、排查对不上时,这是纯粹的运维债。
#
# ── 为什么是「按需揭示」而不是「默认明文」 ───────────────────────────────────
# 两者对「随时都能看到」的满足度**完全相同**(一次点击),但默认明文多付三样代价:
#   ① 明文会随**每一次**配置页拉取走一遍网络 —— 任何反代/网关的访问日志、
#      浏览器缓存、企业代理都可能留下它;按需揭示只在运维真的要看时走一次。
#   ② 默认明文 = 屏幕上常驻 —— 截图、投屏、肩窥,全都是零门槛。
#   ③ **拿不到「谁在什么时候看过这把密钥」** —— 而这是一把能凭空造出可兑换 VIP
#      时长的凭据,事后追查时这条记录的价值远高于省下的一次点击。
# 业界主流(AWS/Stripe/GitHub)对这类凭据一律是「点击揭示」,不是常驻明文。
#
# ── 授予面 ───────────────────────────────────────────────────────────────────
# 只给注册表里 revealable=True 的项,**不是**所有 sensitive 都给:
# auth.ticket 之类是**上游签发**的凭据,运维本来就是从对方那里拿的,本台没有
# 交付责任,不该多开一个读取口子。
# ══════════════════════════════════════════════════════════════════════════════
@router.post("/config/reveal")
async def config_reveal(request: Request):
    """取回某个敏感项的**明文**。会话 + CSRF 双闸,且**每次都落审计**。"""
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    body = await _body(request)
    key = str(body.get("key") or "").strip()
    f = reg.REGISTRY.get(key)
    if f is None:
        return JSONResponse({"ok": False, "error": "unknown_key"}, status_code=400)
    if not (f.sensitive and getattr(f, "revealable", False)):
        # 不可揭示的敏感项一律 403,且**不区分**「不是敏感项」与「敏感但不可揭示」——
        # 那点信息对运维毫无用处,对探测者却是免费的枚举回执。
        return JSONResponse({"ok": False, "error": "not_revealable",
                             "hint": "该项不支持揭示明文"}, status_code=403)
    try:
        val = await cfgc.reveal_sensitive(_ST.bus, key)
    except Exception as e:                 # noqa: BLE001
        # 这条路是**纯 Redis 读**(cfg:sensitive),而 redis-py 8.x 给 RedisError
        # 定的 __repr__ 只输出 `类别:类名` —— repr(e) 到运维眼里就剩一句
        # `network:TimeoutError`,「哪台 Redis、什么操作」全没了。与配置中枢的
        # 套用路径同口径,统一走 exc_text(4.7.7)。
        return JSONResponse({"ok": False, "error": "unavailable",
                             "hint": cfgc.exc_text(e)}, status_code=503)
    if val is None:
        # 运行时覆盖不存在(值来自 ENV/默认),本台没有它的明文。诚实地说清楚,
        # 而不是回一个空串让人以为"密钥是空的"。
        return {"ok": True, "key": key, "value": None,
                "message": "本台没有该项的运行时明文 —— 当前生效值来自环境变量或默认,"
                           "请到部署侧查看 " + (f.env or "对应配置")}
    # ⚠ 审计**必须先于返回**,且失败要如实回报:这是「谁看过这把密钥」的唯一记录。
    audit_ok = True
    try:
        await _ST.db.audit_add(now_ms(), _actor(payload), "config_reveal",
                               {"key": key, "fp": cfgc.fingerprint(val)}, None)
    except Exception as e:                 # noqa: BLE001
        audit_ok = False
        print(f"[配置中枢] ⚠️ 揭示审计写入失败(明文已返回): {e!r}")
    return {"ok": True, "key": key, "value": val, "auditOk": audit_ok}


# ══════════════════════════════════════════════════════════════════════════════
# 九法 VIP 与充值(4.2.0)· 管理台「值」视图
# ------------------------------------------------------------------------------
# 全部走管理台自有鉴权(_guard / _guard_write,与既有视图同款),与用户侧
# /api/vip/* 完全隔离。手动开通/撤销是高危动作:必填操作原因,同时落
# guantai_jf_grant_log.operator 与 admin_audit —— 事后能一眼看出
# 「谁在什么时候给谁开了多久、为什么」。
# ══════════════════════════════════════════════════════════════════════════════
@router.get("/jfvip/overview")
async def jfvip_overview(request: Request):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    st = jfvip.status()
    if not st["enabled"]:
        # 4.2.1:回**原因**而非笼统 enabled:false —— 让「值」视图能直接告诉运维
        # 卡在哪(开关没开?没重启?登录系统没配?),不必去翻日志。
        return {"ok": True, "enabled": False,
                "reason": st["reason"], "message": st["message"]}
    return {"ok": True, **(await jfvip.overview())}


@router.get("/jfvip/cards")
async def jfvip_cards(request: Request,
                      page: int = Query(1, ge=1, le=1_000_000),
                      size: int = Query(50, ge=1, le=500),
                      batch: str = Query("", max_length=32),
                      status: str = Query("", max_length=16),
                      plan: str = Query("", max_length=16),
                      card: str = Query("", max_length=32)):
    # 4.2.6 复审补齐:与同组的 /jfvip/orders 对齐。此前三个兄弟端点里只有
    # orders 上了 Query 形态闸,cards/grants 仍是裸 int —— 同一片视图、
    # 同一类参数却两套校验强度,是最容易在后续维护里被当成"另有深意"的不一致。
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    if not jfvip.enabled():
        # 4.2.5:与同功能的四个 POST 对齐为 503。原先回 HTTP 200 + ok:false ——
        # 前端 api() 因 r.ok 为真而不抛,把失败当成功渲染成「共 undefined 张」;
        # 健康探针/反代/日志同样会把故障读成正常。
        # ⚠ /jfvip/overview 刻意**不**在此列:前端要读它的 reason/message 渲染
        #   「未启用」的可操作指引页,改 503 会让那套诊断信息全部失效。
        return JSONResponse({"ok": False, "error": "disabled"}, status_code=503)
    return {"ok": True,
            **(await jfvip.cards_page(page, size, batch, status, plan, card))}


@router.post("/jfvip/cards/generate")
async def jfvip_cards_gen(request: Request):
    """管理台发卡。`plan`(配置档位)与 `hours`(指定时长)**二选一**。

    4.2.9 新增 hours 分支。为什么并进这一个端点而不是另起一个:两条路径除了
    「档位码从哪来」之外**完全相同**(同一套鉴权、审计、批次语义、返回体),
    拆成两个端点就得把这些各写一遍,而那正是本项目在发卡实现上刚避免过的事
    (见 jfvip._gen_cards_code 的说明)。

    ⚠ 两个都给时**显式拒绝**,绝不替他挑一个。发卡是不可撤销的价值创造
      (卡一旦生成即可被兑换),而「你以为发的是 m1、实际发的是 @H24」这种
      误会没有任何补救手段。宁可让他重发一次请求。
    """
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    if not jfvip.enabled():
        return JSONResponse({"ok": False, "error": "disabled"}, status_code=503)
    body = await _body(request)
    err, out = await _issue_cards(body, _actor(payload))
    if err:
        # 审计补:此前一律 400,而 "db"/"collision" 是**服务端**故障 —— 回 400 会让
        # 前端提示「请求有误」并让运维去检查自己填的参数,而问题在库那边。
        # 与外部 API 端点共用同一张状态表,两个入口对同一错误码给同一语义。
        return JSONResponse({"ok": False, "error": err, **out},
                            status_code=_CARD_API_ERR_STATUS.get(err, 400))
    await _audit(_actor(payload), "jfvip_cards_gen",
                 {"count": out["count"], "plan": out["plan"],
                  "planName": out["planName"], "jfHours": out["jfHours"],
                  "ddHours": out["ddHours"], "batch": out["batch"]})
    return {"ok": True, **out}


async def _issue_cards(body: Dict[str, Any], operator: str) -> tuple:
    """发卡的**唯一**参数解析与分派(管理台端点与外部 API 端点共用)。

    共用的理由与 jfvip._gen_cards_code 同源:两个入口一旦各写一份参数解析,
    「hours 边界怎么钳」「plan 与 hours 同时给了怎么办」这类判断就会在某次维护里
    悄悄分家 —— 而这两个入口发出来的是**同一张表里同样可兑换的卡**,判据分家
    等于同一件事有两套规则。返回 (错误码|'', 结果或错误细节)。
    """
    err, n = jfvip.normalize_issue(body)
    if err:
        return err, n
    # 规范化后 plan 已经是最终档位码(内联时长也已编码进去),故两条路合成一条 ——
    # 这同时保证了「指纹看到的」与「实际发出的」是**同一份解析**的产物。
    return await jfvip.gen_cards_by_code(n["plan"], n["count"], n["batch"],
                                         n["note"], operator)


# ══════════════════════════════════════════════════════════════════════════════
# 外部发卡 API(4.2.9)—— 机器对机器,只认 API Key
# ------------------------------------------------------------------------------
# POST /api/admin/jfvip/cards/issue
#   Header : Authorization: Bearer <STA_JF_CARD_API_KEY>
#            Content-Type: application/json
#   Body   : {"hours":720, "ddHours":720, "count":10,
#             "batch":"渠道A-202607", "note":"618活动"}
#            —— 或 {"plan":"m1", "count":10} 走配置档位
#   200    : {"ok":true,"cards":[...],"count":10,"plan":"@H720D720",
#             "planName":"定制 30 天","jfHours":720,"ddHours":720,
#             "inline":true,"batch":"...","auditOk":true}
#
# ── 5.3.0:后台入口可改名,本接口**地址恒定** ───────────────────────────────────
# 对接方按 POST /api/admin/jfvip/cards/issue 写死了调用。入口搬走后,web.py 在这个原地址上
# 把本处理函数再挂一次(admin_auth.CARD_ISSUE_PATH),守卫按**精确路径**豁免它 —— 精确匹配
# 不是前缀,不会让「后来者继承豁免」。下面这段是 4.2.9 当初的选址理由,原样保留。
# ── 为什么挂在 /api/admin/ 下而不是新开一个前缀 ───────────────────────────────
# userauth.guard() 的 _EXEMPT_PREFIX 是**用户会话中间件的安全边界**。新增一个
# 前缀等于在那道边界上开一个新口子,而口子一旦开了,将来任何人往该前缀下加端点
# 都默认免会话 —— 那类"后来者继承了我没打算给他的豁免"是最难在评审里被发现的。
# 挂在既有的 /api/admin/ 下:边界零改动,且本能力本就是管理员级(凭空造时长)。
#
# ── 与同前缀其它端点的三点**故意不同**,每一条都必须写明 ──────────────────────
#  ① 不走 _guard/_guard_write:那两个要求管理台会话 + CSRF 双提交,机器调用方
#     没有浏览器也没有 cookie。本端点改用密钥闸,两套凭据互不通用。
#  ② 不要求 admin_auth.enabled():发卡平台对接不该被迫先给管理台设个口令。
#  ③ **仍然尊重 STA_ADMIN_IP_ALLOW**。这一条是刻意的:运维设了管理台 IP 白名单
#     就有权认为"整个 /api/admin/* 只对内网开放",我绝不在他背后把这个前提捅破。
#     被它挡住时回一个**专属错误码**并点名那个旋钮 —— 而不是让集成方对着一个
#     笼统的 403 猜半天(这与项目为 sso_disabled / sso_link_disabled 分开报错
#     写下的是同一条理由:合并错误码会让人一直查错的那个开关)。
# ══════════════════════════════════════════════════════════════════════════════
_CARD_API_ERR_STATUS = {
    "both_plan_and_hours": 400, "missing_plan_or_hours": 400,
    "bad_count": 400, "bad_hours": 400, "bad_dd_hours": 400,
    "bad_plan": 400, "code_too_long": 400,
    "collision": 503, "db": 503, "disabled": 503,
}


@router.post("/jfvip/cards/issue")
async def jfvip_cards_issue(request: Request):
    """外部机器发卡:一次调用拿 N 张**指定时长**的卡密。

    闸序(由便宜到昂贵,且最不可绕的在前):
        ① 总开关/密钥体检 → 503(带 reason,让运维一眼知道卡在哪)
        ② 密钥错误锁定期 → 静默 429(不写日志:触限那刻已写过,再写就是替
           攻击者放大日志)
        ③ 管理台 IP 白名单 → 403 ip_forbidden_admin(点名旋钮)
        ④ 本端点 IP 白名单 → 403 ip_forbidden
        ⑤ 密钥比对        → 401(计入 badkey 桶 + 抖动延时,压时序侧信道)
        ⑥ 幂等只读探针    → 重放直接回上次结果(**不消耗限频配额**)
        ⑦ 调用限频        → 429 + Retry-After
        ⑧ 幂等原子占位    → 409(在途 / 同键不同参)
        ⑨ 参数校验        → 400(边界一律显式拒绝,绝不静默截断)
    """
    ip = admin_auth.client_ip(request)

    st = jfvip.card_api_status()
    if not st["enabled"]:
        return JSONResponse({"ok": False, "error": "api_disabled",
                             "reason": st["reason"], "message": st["message"]},
                            status_code=503)

    lock = await jfvip.card_api_badkey(ip, bump=False)
    if lock is not None:
        r = JSONResponse({"ok": False, "error": "throttled", "retryAfter": lock,
                          "message": f"尝试过于频繁,请 {max(1, lock // 60)} 分钟后再试"},
                         status_code=429)
        r.headers["Retry-After"] = str(int(lock))
        return r

    # ③ 管理台 IP 白名单:未配置时 ip_allowed() 恒 True,对绝大多数部署零影响。
    if not admin_auth.ip_allowed(ip):
        return JSONResponse(
            {"ok": False, "error": "ip_forbidden_admin", "ip": ip,
             "message": "本机 IP 被管理台 IP 白名单挡下。整个管理面(含本接口)受 "
                        "STA_ADMIN_IP_ALLOW 约束,外部发卡也不例外 —— 请把调用方"
                        "出口 IP 加进该白名单(或清空它,改用本端点专属的 "
                        "userauth.jf_card_api_ip_allow)"}, status_code=403)
    # ④ 本端点专属白名单(默认空=不限;配错一条不落时 fail-closed)。
    if not jfvip.card_api_ip_ok(ip):
        return JSONResponse(
            {"ok": False, "error": "ip_forbidden", "ip": ip,
             "message": "本机 IP 不在外部发卡白名单内"
                        "(参数中心 · userauth.jf_card_api_ip_allow)"},
            status_code=403)

    if not jfvip.card_api_key_ok(request.headers.get("authorization", "")):
        await jfvip.card_api_badkey(ip, bump=True)
        # 抖动延时:与 userauth.sso_link 的密钥闸同款。压掉"比对快慢"这条
        # 时序侧信道,顺带把爆破的单位成本抬上去。
        await asyncio.sleep(0.3 + secrets.randbelow(200) / 1000.0)
        return JSONResponse({"ok": False, "error": "bad_key",
                             "message": "发卡凭据无效"}, status_code=401)

    body = await _body(request)
    actor = f"cardapi@{ip}"

    # ── 幂等(审计补)──────────────────────────────────────────────────────
    # 触发路径不是恶意,是最普通的网络抖动:请求已到达、卡已落库,而响应在回程
    # 丢了 ⇒ 平台按常规重试 ⇒ 又一批卡。多出来的卡同样可兑换,是直接资损,
    # 且事后无法分辨哪一批是重复的(卡号不同、批次相同、时间戳相邻)。
    idem = jfvip.idem_key_norm(body.get("idempotencyKey") or body.get("idempotency_key"))
    fp = jfvip.idem_fingerprint(body) if idem else ""
    slot = None

    def _idem_reply(state, data):
        """幂等的三种非放行态 → 响应。探针与占位共用,两处各写一遍必然漂。"""
        if state == "unavailable":
            # fail-closed:调用方显式要了这个保证,而我们提供不了。悄悄不提供是
            # 最坏的结果 —— 他会放心地重试。
            return JSONResponse(
                {"ok": False, "error": "idempotency_unavailable",
                 "message": "幂等存储(Redis)暂不可用,已拒绝以免重复发卡。"
                            "可稍后重试,或去掉 idempotencyKey 自行承担重试风险"},
                status_code=503)
        if state == "conflict":
            # ★ 同键配了不同参数 ⇒ **调用方有 bug**。原实现静默回第一次的结果:
            #   他发 hours=8760/count=500 却拿到 24h×1 张、HTTP 200,以为发成功了。
            #   静默的错误答案比报错危险得多 —— 当场告诉他,别替他掩盖。
            return JSONResponse(
                {"ok": False, "error": "idempotency_key_reused",
                 "message": "该幂等键此前用于**不同参数**的请求。幂等键必须一请求一个;"
                            "若确实要发新的一批,请换一个键"}, status_code=409)
        if state == "in_flight":
            r = JSONResponse(
                {"ok": False, "error": "idempotency_in_flight",
                 "message": "同一幂等键的上一次请求仍在处理,请稍后重试"},
                status_code=409)
            r.headers["Retry-After"] = "5"
            return r
        return None

    # ── ⑥ 幂等**只读探针**(在限频之前;不写、不耗配额)────────────────────
    #    重放没创造任何价值,不该消耗发卡配额。实测:cap=3 时连续 4 次重放得到
    #    [200,429,429,429] —— 平台对 20 笔订单各重试 3 次即打满默认 cap(60)。
    #    反过来若把原子占位提到限频之前,限频拒绝时会留下 PENDING 占位,该键此后
    #    24 小时一直回 409 —— 用一个更难查的故障换掉一个好查的。故拆成探 + 占位。
    if idem:
        state, data = await jfvip.idem_peek(idem, fp)
        if state == "done":
            return {**{k: v for k, v in data.items() if k != "_fp"}, "idempotent": True}
        bad = _idem_reply(state, data)
        if bad is not None:
            return bad

    if not await jfvip.card_api_rate_ok():
        r = JSONResponse(
            {"ok": False, "error": "throttled",
             "message": "发卡调用过于频繁(参数中心 · userauth.jf_card_api_rate_hourly)"},
            status_code=429)
        r.headers["Retry-After"] = "3600"
        return r

    # ── ⑦ 原子占位(SET NX)。探与占位之间的窄窗由它兜住 ────────────────────
    if idem:
        state, data = await jfvip.idem_begin(idem, fp)
        if state == "done":
            return {**{k: v for k, v in data.items() if k != "_fp"}, "idempotent": True}
        bad = _idem_reply(state, data)
        if bad is not None:
            return bad
        slot = data

    err, out = await _issue_cards(body, actor)
    if err:
        if slot:
            await jfvip.idem_abort(slot)   # 释放占位:同一个键可以改对参数再来
        return JSONResponse({"ok": False, "error": err, **out},
                            status_code=_CARD_API_ERR_STATUS.get(err, 400))

    # 审计:发卡是价值创造,必须留痕。**不落卡号** —— 卡号即等价物,把 500 个
    # 可兑换的卡号写进另一个库(PG admin_audit)是白白多一份可被拖走的资产;
    # 批次 + 张数 + 时长 + 调用方 IP 已足以还原"谁在什么时候发了多少多长的卡",
    # 卡号本身在 guantai_jf_card 里按批次一查即得。
    # (与 cards_purge 的墓碑刻意相反:那边是**删除**,卡号删完就没了,不留在
    #  审计里就永远没了;这边卡号还在表里躺着,复制一份纯属扩大暴露面。)
    audit_ok = True
    try:
        await _ST.db.audit_add(now_ms(), actor, "jfvip_cards_issue",
                               {"count": out["count"], "plan": out["plan"],
                                "planName": out["planName"],
                                "jfHours": out["jfHours"], "ddHours": out["ddHours"],
                                "inline": out["inline"], "batch": out["batch"],
                                "note": str(body.get("note") or "")[:100]}, None)
    except Exception as e:                 # noqa: BLE001
        audit_ok = False
        print(f"[九法VIP] ⚠️ 外部发卡审计写入失败(卡已生成,批次 {out['batch']}): {e!r}")
    resp = {"ok": True, "auditOk": audit_ok, **out}
    if slot:
        # 写占位放在**最后**:此前任一步失败都不该留下一个"已完成"的幂等记录,
        # 否则调用方重试会拿到一批他其实没收到的卡号。
        await jfvip.idem_finish(slot, jfvip.idem_stamp(resp, fp))
    return resp


@router.post("/jfvip/cards/disable")
async def jfvip_cards_disable(request: Request):
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    if not jfvip.enabled():
        return JSONResponse({"ok": False, "error": "disabled"}, status_code=503)
    body = await _body(request)
    # ★ 4.3.0 实地核查补齐:超限**显式拒绝**,与 /jfvip/cards/purge 同一口径。
    #   jfvip.ids_overflow 的注释已就此下过定论 ——「截断是替用户做决定,而这个
    #   决定他不知道」—— 但那道闸当时只装在 purge 上;disable / note 仍走
    #   norm_ids 的静默 `[:500]` 截断。同一原则三处只落实了一处,是最容易在后续
    #   维护里被当成「另有深意」的不一致。
    #   诚实说明:当前 UI 的选择集上限(JV_SEL_CAP)恰为 500,与后端同值,
    #   故经管理台点不出这个场景 —— 这是**纵深防御**,不是在修一个活的缺陷。
    #   闸放在端点而非 cards_disable 内部,是因为后者返回裸 int,改签名会波及
    #   既有调用方与用例;而这两个函数的调用方全项目就只有本端点各一处。
    if jfvip.ids_overflow(body.get("ids")):
        return JSONResponse({"ok": False, "error": "too_many",
                             "hint": f"单次最多 {jfvip._MAX_IDS_PER_CALL} 张,本次提交 "
                                     f"{len(body.get('ids'))} 张,请分批操作"},
                            status_code=400)
    undo = bool(body.get("undo"))
    n = await jfvip.cards_disable(str(body.get("batch") or ""),
                                  body.get("ids") or None, undo)
    await _audit(_actor(payload), "jfvip_cards_disable",
                 {"affected": n, "undo": undo, "batch": body.get("batch") or "",
                  "ids": jfvip.norm_ids(body.get("ids"))})   # 上限 500,不截断(同墓碑理由)
    return {"ok": True, "affected": n}


@router.post("/jfvip/cards/purge")
async def jfvip_cards_purge(request: Request):
    """硬删卡密(4.2.9)。**只接受显式 id 清单,刻意不提供按批次整批删。**

    4.2.9:取消「先作废才能删」的前置 —— 勾中即删,未使用 / 已作废 / 已兑换
    三类一视同仁。剩余四道闸(总开关默认关、只收 id 清单、键入 DELETE 确认、
    完整墓碑)一层未动;完整论证见 jfvip.py 中 cards_purge 上方的设计注释。

    删除不可撤销,而批次是自由文本输入框 —— 把破坏性操作押在「运维不打错字」
    上是不可接受的。真正的批量清理交给保留期自动清扫(userauth._janitor),
    那条路径有明确的时间判据,不依赖任何人手输。

    墓碑落在 admin_audit(PostgreSQL 观测库),与 MySQL 用户库**物理隔离** ——
    删用户库的卡,动不了审计。detail 是 JSONB,天然承载结构化墓碑,零 DDL。

    ⚠ 证据路径只有一条,别指望有第二条。
      本 docstring 曾写着「前端在发起删除**之前**已强制下载 CSV 存档」——
      **那是假的**(4.3.0 实地核查:通读前端 jvSelPurge 处理器,全程没有任何
      jvDownload 调用;tests/test_jfvip_cards_purge.py::test_purge_requires_typed
      _confirmation 更是反向断言 `"jvDownload(" not in p`,把「不得有自动下载」
      钉成了契约)。删除前的强制存档早已按需求移除,而这段话没跟着改。
      对**不可逆操作**谎称有存档,比没有存档危险得多 —— 维护者会据此以为
      「审计挂了也还有一份 CSV」,从而在别处放松要求。
      真实情况:审计是唯一的系统性证据路径,故下面**不走** _audit
      (它是 contextlib.suppress,写失败会静默吞掉),而是直写并把 auditOk
      如实回给前端,由前端在写失败时把卡号摊开让运维当场人工留痕。
    """
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    if not jfvip.enabled():
        return JSONResponse({"ok": False, "error": "disabled"}, status_code=503)
    body = await _body(request)
    err, out = await jfvip.cards_purge(body.get("ids"))
    if err == "purge_disabled":
        # 「不配置即不存在」:总开关默认关,旧部署逐字节无感。403 而非 400 ——
        # 这不是请求写错了,是这台部署压根没开这项能力。
        return JSONResponse({"ok": False, "error": err,
                             "hint": "请先在配置中枢开启 userauth.jf_card_purge_enabled"},
                            status_code=403)
    if err == "too_many":
        # 刻意**不截断**:截断会让「少删了多少」这个差异消失在净化环节,
        # 屏幕上零迹象。宁可让运维分两次点,也不替他做他不知道的决定。
        return JSONResponse({"ok": False, "error": err,
                             "hint": f"单次最多 {out.get('limit')} 张,本次提交 "
                                     f"{out.get('got')} 张,请分批操作"},
                            status_code=400)
    if err:
        return JSONResponse({"ok": False, "error": err}, status_code=400)
    # ── 墓碑 ──────────────────────────────────────────────────────────────
    # ★ 复审自查修正一:**不截断**。此前写 `[:200]`,而单次可删 500 张 ——
    #   最多 300 个被删卡号不进审计,且无任何标记。这与本轮刚修掉的 ids 静默
    #   截断是同一类错误,我在墓碑上又犯了一次。500 个卡号 ≈ 8.9 KB,
    #   PostgreSQL JSONB 单值上限 255 MB,截断毫无必要。
    #
    # ★ 复审自查修正二:**审计写失败必须可见**。删除前的 CSV 存档已按需求移除,
    #   审计因此成为**唯一**证据路径;而项目通用的 _audit 是
    #   `contextlib.suppress(Exception)` —— 写失败静默吞掉,证据就此蒸发。
    #   不可逆操作不能这样。故此处不走 _audit,直接写并把结果如实回报;
    #   写失败时前端弹出显著告警并把卡号列出来,让运维当场人工留痕。
    #   (删除已提交、无法回滚,能做的就是绝不假装它被记录了。)
    tomb = {"requested": out["requested"], "affected": out["affected"],
            "skipped": out["skipped"],
            "cards": [c["card"] for c in out["cards"]],
            # ★ 4.2.9:三态而非两态。取消「先作废才能删」后,`unused`(仍可兑换)
            #   成为**可能被删的一类**,它必须在墓碑里单独可数 —— 事后追责时
            #   「删了 3 张已作废」与「删了 3 张还能兑的」是完全不同的两件事,
            #   把后者混进前者等于让审计说不出真话。
            "byState": {"disabled": sum(1 for c in out["cards"]
                                        if c["state"] == "disabled"),
                        "used": sum(1 for c in out["cards"] if c["state"] == "used"),
                        "unused": sum(1 for c in out["cards"]
                                      if c["state"] == "unused")}}
    audit_ok = True
    try:
        await _ST.db.audit_add(now_ms(), _actor(payload), "jfvip_cards_purge", tomb, None)
    except Exception as e:                 # noqa: BLE001
        audit_ok = False
        print(f"[九法VIP] ⚠️ 删卡审计写入失败(删除已执行,证据仅存于本次响应): {e!r}")
    return {"ok": True, "auditOk": audit_ok, **out}


@router.get("/jfvip/cards/batches")
async def jfvip_cards_batches(request: Request,
                              limit: int = Query(200, ge=1, le=500),
                              batch: str = Query("", max_length=32)):
    """批次名清单(惰性)/ 单批三态计数。

    ★ 真库实测(MariaDB 10.11,本文件 DDL 1:1,40 万行 / 800 批次,
      FLUSH STATUS + Handler_read_* 数真实扫描行数):

          带 batch(单批计数)  ………     500 行  ← idx_batch 直击,与表规模无关
          不带(批次名清单)    ……… 100,000 行  ← 故**只在运维显式索取时调**

      初版把「清单 + 三态计数」合成一个 GROUP BY,实测扫 400,000 行,且是
      **每次渲染卡密页都调一次**(含每一次翻页)—— 与本项目设立 _count_capped
      要避免的是同一件事。拆开后,需要计数的时刻只有「已选定某批、正要作废它」
      这一个,那时只查这一批。
    """
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    if not jfvip.enabled():
        return JSONResponse({"ok": False, "error": "disabled"}, status_code=503)
    if batch:
        return {"ok": True, "stat": await jfvip.cards_batch_stat(batch)}
    return {"ok": True, "items": await jfvip.cards_batches(limit)}


@router.post("/jfvip/cards/note")
async def jfvip_cards_note(request: Request):
    """批量改备注(note 列现成,零 DDL)。改前值一并入审计,便于回溯。"""
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    if not jfvip.enabled():
        return JSONResponse({"ok": False, "error": "disabled"}, status_code=503)
    body = await _body(request)
    # 超限显式拒绝(理由同 /jfvip/cards/disable 处的长注)
    if jfvip.ids_overflow(body.get("ids")):
        return JSONResponse({"ok": False, "error": "too_many",
                             "hint": f"单次最多 {jfvip._MAX_IDS_PER_CALL} 张,本次提交 "
                                     f"{len(body.get('ids'))} 张,请分批操作"},
                            status_code=400)
    ids = jfvip.norm_ids(body.get("ids"))
    if not ids:
        return JSONResponse({"ok": False, "error": "bad_ids"}, status_code=400)
    note = str(body.get("note") or "")[:100]
    n = await jfvip.cards_set_note(ids, note)
    await _audit(_actor(payload), "jfvip_cards_note",
                 {"affected": n, "ids": ids, "note": note})   # 上限 500,不截断
    return {"ok": True, "affected": n}


@router.get("/jfvip/orders")
async def jfvip_orders(request: Request,
                       page: int = Query(1, ge=1, le=1_000_000),
                       size: int = Query(50, ge=1, le=500),
                       uid: int = Query(0, ge=0),
                       status: str = Query("", max_length=16),
                       orderNo: str = Query("", max_length=64),
                       userName: str = Query("", max_length=50),
                       plan: str = Query("", max_length=16),
                       dateFrom: str = Query("", max_length=19),
                       dateTo: str = Query("", max_length=19),
                       amtMin: str = Query("", max_length=16),
                       amtMax: str = Query("", max_length=16),
                       simulate: str = Query("", max_length=1),
                       credited: str = Query("", max_length=1)):
    """订单检索。

    4.2.6:此前只接出 status —— 而 orders_page 早就支持 uid,前端却从未传过;
    运维想按订单号/用户/时间/金额找一笔单,只能一页页翻。本轮把参数补齐。

    校验分两层且**故意重复**:这里用 FastAPI 的 Query 做形态与长度闸(超界
    直接 422,不进业务层),jfvip 内部再做一次语义规范化(非法日期→条件失效
    而非塞进 SQL)。管理台是高权限面,两层都要有。
    page 的上界 1_000_000 是防手滑/防扫描,真正的越界夹紧在 _clamp_page。
    """
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    if not jfvip.enabled():
        # 4.2.5:与同功能的四个 POST 对齐为 503。原先回 HTTP 200 + ok:false ——
        # 前端 api() 因 r.ok 为真而不抛,把失败当成功渲染成「共 undefined 张」;
        # 健康探针/反代/日志同样会把故障读成正常。
        # ⚠ /jfvip/overview 刻意**不**在此列:前端要读它的 reason/message 渲染
        #   「未启用」的可操作指引页,改 503 会让那套诊断信息全部失效。
        return JSONResponse({"ok": False, "error": "disabled"}, status_code=503)
    with _heavy_reads():          # 与用户侧 /api/vip/orders 共用 orders_page:只在管理台这里按重查询处理
        data = await jfvip.orders_page(
            page, size, uid, status, order_no=orderNo, user_name=userName,
            plan_code=plan, date_from=dateFrom, date_to=dateTo,
            amt_min=amtMin, amt_max=amtMax, simulate=simulate, credited=credited)
    return {"ok": True, **data}


@router.get("/jfvip/grants")
async def jfvip_grants(request: Request,
                       page: int = Query(1, ge=1, le=1_000_000),
                       size: int = Query(50, ge=1, le=500),
                       uid: int = Query(0, ge=0),
                       source: str = Query("", max_length=16),
                       dateFrom: str = Query("", max_length=19),
                       dateTo: str = Query("", max_length=19)):
    """开通流水 —— **唯一对账口径**。
    九法赠送的小叮当时长不会出现在繁星后台的卡密/订单流水里(我们不写它的表),
    对账时以本表为准、两边相加。本端点即导出入口。

    4.3.0:补 dateFrom/dateTo。与同组 /jfvip/orders 的日期参数**逐字同款**
    (同名、同 max_length=19、同为两层校验:这里做形态/长度闸,业务层
    _norm_dt 再做真日历校验、不合法即条件失效而非塞进 SQL)。
    补齐的理由与实测证据见 jfvip.grants_page 的 docstring ——
    一句话:表建的时候就为它留了 idx_time / idx_source(source, created_at),
    只是参数一直没接出来,而按期对账是刚需。"""
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    if not jfvip.enabled():
        # 4.2.5:与同功能的四个 POST 对齐为 503。原先回 HTTP 200 + ok:false ——
        # 前端 api() 因 r.ok 为真而不抛,把失败当成功渲染成「共 undefined 张」;
        # 健康探针/反代/日志同样会把故障读成正常。
        # ⚠ /jfvip/overview 刻意**不**在此列:前端要读它的 reason/message 渲染
        #   「未启用」的可操作指引页,改 503 会让那套诊断信息全部失效。
        return JSONResponse({"ok": False, "error": "disabled"}, status_code=503)
    with _heavy_reads():          # 与用户侧 /api/vip/orders 共用 grants_page,同上
        data = await jfvip.grants_page(page, size, uid, source, date_from=dateFrom, date_to=dateTo)
    return {"ok": True, **data}


@router.get("/jfvip/user")
async def jfvip_user(request: Request, userName: str = ""):
    payload = _guard(request)
    if isinstance(payload, JSONResponse):
        return payload
    if not jfvip.enabled():
        # 4.2.5:与同功能的四个 POST 对齐为 503。原先回 HTTP 200 + ok:false ——
        # 前端 api() 因 r.ok 为真而不抛,把失败当成功渲染成「共 undefined 张」;
        # 健康探针/反代/日志同样会把故障读成正常。
        # ⚠ /jfvip/overview 刻意**不**在此列:前端要读它的 reason/message 渲染
        #   「未启用」的可操作指引页,改 503 会让那套诊断信息全部失效。
        return JSONResponse({"ok": False, "error": "disabled"}, status_code=503)
    row = await jfvip.resolve_user(userName)
    if not row:
        return JSONResponse({"ok": False, "error": "user_not_found"}, status_code=404)
    st = await jfvip.vip_state(int(row["id"]))
    return {"ok": True, "userId": int(row["id"]), "userName": str(row["user_name"]),
            "ddDueTime": str(row.get("due_time") or ""),
            "ddAlive": bool(int(row.get("alive") or 0)), **st}


@router.post("/jfvip/grant")
async def jfvip_grant(request: Request):
    """手动开通/延长(高危)。走与付费开通**完全相同**的事务 ⇒ 同样幂等、同样落流水。"""
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    if not jfvip.enabled():
        return JSONResponse({"ok": False, "error": "disabled"}, status_code=503)
    body = await _body(request)
    name = str(body.get("userName") or "").strip()
    note = str(body.get("note") or "").strip()
    if not name or not note:
        return JSONResponse({"ok": False, "error": "bad_request",
                             "hint": "用户名与操作原因均为必填"}, status_code=422)
    row = await jfvip.resolve_user(name)
    if not row:
        return JSONResponse({"ok": False, "error": "user_not_found"}, status_code=404)
    err, out = await jfvip.grant_by_admin(int(row["id"]), str(row["user_name"]),
                                          str(body.get("plan") or ""),
                                          _actor(payload), note)
    if err:
        return JSONResponse({"ok": False, "error": err}, status_code=400)
    await _audit(_actor(payload), "jfvip_grant",
                 {"user": name, "plan": body.get("plan"), "note": note,
                  "vipAfter": out.get("vipUntil"), "dueAfter": out.get("dueTime")})
    return {"ok": True, **out}


# 单次撤销上限。与 admin.js 的 `if (h > 8928)` 同值 —— 8928h = 372 天 ≈ 1 年,
# 取自年卡的 recharge_length,是本项目全链路的「一年」锚点。两端必须同值:
# 只在前端拦等于没拦(任何直调 API 的人都绕得过),只在后端拦则运维要填完
# 才被打回。改动时两处一起改。
# ★ 4.3.1 复查移位:初版把它放在了「外部发卡 API」那段横幅之下、紧邻
#   _CARD_API_ERR_STATUS —— 一个**撤销**的常量坐在**发卡**接口的段落里,
#   维护者会合理地以为它属于卡 API。项目自己写过这类不一致「最容易在后续
#   维护里被当成『另有深意』」。挪到它唯一的使用点正上方。
_MAX_REVOKE_HOURS = 8928


@router.post("/jfvip/revoke")
async def jfvip_revoke(request: Request):
    """撤销 N 小时 VIP(高危)。**刻意不回收已赠送的小叮当时长** ——
    那部分已进父项目的账,回收会让两个系统口径打架;需要时请在繁星后台单独处理。"""
    payload = _guard_write(request)
    if isinstance(payload, JSONResponse):
        return payload
    if not jfvip.enabled():
        return JSONResponse({"ok": False, "error": "disabled"}, status_code=503)
    body = await _body(request)
    name = str(body.get("userName") or "").strip()
    note = str(body.get("note") or "").strip()
    # ★ 4.3.0 实地核查修补(两条,同一行):
    #   ① 原写法 `int(body.get("hours") or 0)` 对非数字入参抛 ValueError,
    #      而本文件的端点层零 try/except ⇒ 一个手滑的 payload 变成 **HTTP 500**。
    #      本项目在 norm_ids 的注释里已就同一件事下过定论:「这是管理台端点,
    #      一个手滑的 payload 不该变成 500」。同组的发卡端点走 normalize_issue
    #      有完整钳制,此处是唯一没对齐的。
    #   ② 原写法**没有上界**。前端写死「单次撤销上限 8928 小时(1 年)」并在
    #      提交前拦截,后端却照单全收 —— 边界只存在于 UI 上等于不存在。
    #      按项目「边界一律显式拒绝,绝不静默截断」的既有口径,超界回 422 而不是钳。
    try:
        hours = int(str(body.get("hours", "")).strip() or 0)
    except (TypeError, ValueError):
        hours = 0
    if not name or not note or hours <= 0:
        return JSONResponse({"ok": False, "error": "bad_request",
                             "hint": "用户名、撤销小时数与原因均为必填,"
                                     "且撤销小时数须为大于 0 的整数"}, status_code=422)
    if hours > _MAX_REVOKE_HOURS:
        return JSONResponse({"ok": False, "error": "bad_request",
                             "hint": f"单次撤销上限 {_MAX_REVOKE_HOURS} 小时(1 年),"
                                     f"本次 {hours} 小时;确需更多请分次执行"},
                            status_code=422)
    row = await jfvip.resolve_user(name)
    if not row:
        return JSONResponse({"ok": False, "error": "user_not_found"}, status_code=404)
    err, out = await jfvip.revoke_by_admin(int(row["id"]), str(row["user_name"]),
                                           hours, _actor(payload), note)
    if err:
        return JSONResponse({"ok": False, "error": err}, status_code=400)
    await _audit(_actor(payload), "jfvip_revoke",
                 {"user": name, "hours": hours, "note": note,
                  "vipAfter": out.get("vipUntil")})
    return {"ok": True, **out}
