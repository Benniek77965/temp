"""
worker.py — 异步抓取 worker(asyncio + aiohttp,替代「一房一线程」)
================================================================================
单进程一个事件循环即可承载数千房并发轮询。核心是「事件驱动 + 短任务」:不再
每房一条常驻线程做 sleep→抓取→sleep,而是把每房的下一步(MainPage 或某局
RoundAward)作为一个**到期任务**放进 Redis 延迟队列;worker 只在任务到期时把它
取出、执行一小段异步 I/O、再排出下一步。任意时刻真正「在飞」的只有少量任务,
内存与调度开销比线程模型低几个数量级,且天然可多进程/多机水平扩展(共享队列)。

一房的生命周期(全异步,无长 sleep):
  ① mp|room 到期 → MainPage → 拿到本局 roundId 与权威计时
     → 排 aw|room|round(draw+delay+抖动)
     → 排下一个 mp|room(本局结束后+抖动;不早于最小间隔)
     → 写房间快照 + 推「换局」SSE
  ② aw|room|round 到期 → RoundAward
     → 入库(幂等)→ 结算上一局预测 + 生成下一局预测(复用旧引擎)
     → 写快照 latestRoundId + 推「新出怪」SSE
     → 未就绪则指数退避重排;超次数用 GameHistory 兜底

并发控制:
  · claimer 协程原子领取到期任务喂给 in-proc asyncio.Queue(背压);
  · N 个 consumer 协程消费;全局令牌桶钳住对上游的总 QPS;
  · 每房 in-proc 锁串行化「结算+预测」临界区,保证权重推进一致。
"""
from __future__ import annotations

import asyncio
import bisect
import contextlib
import json
import logging
import math
import random
import signal
import time
import uuid
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

from . import config_center as cfgc
# 取奖重试阶梯(相对备战,ms;首取=备战+1.5s 由 award_due_wall 锚定)。
# 详注见 _handle_award 空奖分支;升级护栏钳(eff_max)依赖本表长度推导。
AWARD_LADDER_MS = (2300, 3200, 5700, 12000, 14500, 18000, 21000, 24000, 26500)

# 早探 GameHistory 的拍数(3.4.1;修复「出怪倒计时结束、下一局都开跑了才显示上一局」)。
# attempt 是 1-based 索引进 AWARD_LADDER_MS:第 3 拍锚点 = 备战+5.7s。
# 依据(实地核查真实房 321):**GameHistory 在备战后 ~2.3s 就已含当前局**,与
# RoundAward 几乎同时就绪 —— 它是一个"已经就绪却被排在最末"的数据源。旧实现要
# 烧满 11 拍(≈备战+26.9s = 局内 61.9s)才去问它,而倒计时(drawTime)局内 40s 就结束、
# 下一局局内 50s 就开始 → 数据落在下一局中段才显示。
# 取第 3 拍:此时 award 已连空 3 次(备战+2.3/+3.2/+5.7),足证这是"慢局",不是常态;
# 常态(首拍即中,实测 aw≈0.96 次/局)**完全不触发本路径,零额外上游调用**。
EARLY_HIST_ATTEMPT = 3


# ── 全舰队入库统计聚合(3.4.7)──────────────────────────────────────────────────
# 背景(AUDIT §18 实证):stats:ingest 的 per_min/rate 由**每个副本各自**的进程内
# 计数经普通 HSET 覆盖写 —— 多副本时读者只能看到"最后写入的那个副本"的数字。
# 10 副本产线上它把全舰队入库率**低报约 10 倍**,曾直接推出"92.6% 的局靠回填兜底"
# 的错误结论(真机双副本对照:PG 全舰队真值 ÷ hash 读数 = 2.00×)。
# 修法:各副本把窗口计数写进 stats:ingest:replicas 子哈希(字段=副本 id),读时按
# ts 新鲜度聚合求和 → fleet_* 才是全舰队口径;legacy 字段语义保持不动(仍=单副本)。
def aggregate_fleet_ingest(entries: Dict[str, Any], now_ms_v: int,
                           fresh_ms: int = 180_000):
    """聚合 stats:ingest:replicas(wid → json{ts_ms,per_min,rate})为全舰队口径。

    janitor 每副本 ~60s 上报一次;各副本窗口互不对齐,直接求和即"各副本最近
    一窗速率之和",作运营脉搏足够(与 PG 侧真值的对账见 tests/test_stats_fleet.py)。
    ts 超 fresh_ms(默认 180s = 3 个上报周期)视为死副本:不入账,并把 wid 返回给
    调用方顺手 HDEL —— 子哈希的键级 TTL 只兜底整键,字段级陈旧靠这里清,缩容后
    fleet_* 在 ≤3 分钟内自动收敛到新副本数。脏 JSON 一律按陈旧处理。
    返回 (fleet_mapping, stale_wids)。
    """
    per_min = 0.0
    rate = 0.0
    alive = 0
    stale: List[str] = []
    for wid, raw in entries.items():
        try:
            d = json.loads(raw)
            ts = int(d.get("ts_ms", 0))
        except (ValueError, TypeError):
            stale.append(wid)
            continue
        if now_ms_v - ts > fresh_ms:
            stale.append(wid)
            continue
        per_min += float(d.get("per_min", 0) or 0)
        rate += float(d.get("rate", 0) or 0)
        alive += 1
    return ({"fleet_per_min": round(per_min, 1), "fleet_rate": round(rate, 3),
             "replicas_reporting": alive}, stale)


# ── 算力体检(3.4.2)────────────────────────────────────────────────────────────
# 每副本可承载的房数:真机实测每局 worker CPU = 11.2ms;单副本(单进程 Python,GIL)
# ≈1 核 → 1 核 ÷ 11.2ms × 50s(一局) ≈ **4300 房**。见 README §5.1。
ROOMS_PER_REPLICA = 4300
# 「最老到期任务已迟到」超过它 = 抓取窗口(出怪阶梯全长仅 26.5s)已被吃掉,数据必然
# 系统性变晚 —— 前端即表现为「出怪晚一局 + 预测滞后/消失」。
# 健康态实测(1000 房 / 单 worker):积压 0–6,最老迟到 <1s。
BACKLOG_LAG_WARN_MS = 10_000

# 本机钟与游戏服务器钟的偏差告警阈值(ms)。3.4.3 起两者不同步**不再导致抓取变晚**
# (所有服务器钟域的到期时刻都会换算回本机钟域),但大钟偏仍是主机配置有问题的强信号
# (NTP 未开/漂移),且会影响日志时间戳与人工排障,故显式告警。
CLOCK_SKEW_WARN_MS = 5_000

from .constants import (DRAW_OFFSET_MS, END_OFFSET_MS,   # RARE_MULTIPLIER_THRESHOLD
                        HIST_PAGE_ROUNDS,                 # 官方历史页窗(hist-mode 周期上限的推导源)
                        ROUND_STEP, SPELL_OFFSET_MS,      # 已改用 settings.rare_log_multiplier(3.4.0)
                        build_beast_meta, rounds_for_hours)
from .db import (DB, _iso as _iso_local,          # _iso:北京时间 ISO(整项目统一)
                 retention_cutoff_ms)
from .discovery import Discovery, reconcile_discovered, restore_discovered
from .predictor_bridge import PredictorBridge, ms_to_date, ms_to_local
from .pred_replay import config_fingerprint as pred_cfg_fingerprint
from .pred_replay import plan_span
from .pred_replay import replay_window as pred_replay_window
from .ratelimit import TokenBucket
from .redis_bus import (RedisBus, extrapolate_server_now, now_ms, parse_task,
                        task_award, task_hist, task_mainpage)
from .scheduler import (award_due_wall, curated_idle_split,
                        effective_hist_interval_ms, hist_retry_delay_ms,
                        next_mainpage_due_wall, weighted_fleet_load)
from .settings import Settings, settings as _S
from .starmeta import StarMeta
from .upstream import AuthExpired, Upstream

log = logging.getLogger("worker")

# SSE 回合对象的妖兽元数据(spell_key/spell_name 等;与 web/旧观测台同源)
BEAST_BY_OFFICIAL, BEAST_BY_CID = build_beast_meta(_S.custom_beast_ids)

# ── 命中率补算:单房异常后的退避闸(4.9.3 第七轮) ─────────────────────────────
# 旧行为:_replay_room 抛异常时,该房的 replay_gate 已在探查时按整段
# replay_cooldown_s(默认 1h)落下 —— 一次 PG/Redis 瞬时抖动就让用户在推演卡上
# 多等一小时才等到下一次补算。现在异常路径把闸**改写**为本值:瞬断几分钟内自愈,
# 持续性坏房也被钳在 ≤12 次探查/时(每次都在早期廉价失败),不会退化成逐秒重试。
REPLAY_FAIL_BACKOFF_S = 300

# ── 覆盖哨兵(缺口驱动补漏校验;无开关恒开)参数 ────────────────────────────────
# 静默区滞后:只审计 head−2 局之前的格点。取 2 局(≈100s)的依据是 award 重试
# 管线的最坏终局时刻:备战+1.5s 首拉 + 5 次退避(1.5·k,capped)+抖动+请求超时
# ≈ 局起点后 ~78s < 2 局,故静默区外的格点要么已入库、要么已确证官方缺失、
# 要么任务确实丢了(该修)—— 审计判据无竞态。
COV_AUDIT_LAG_ROUNDS = 2
COV_SPAN_CAP = 200            # 单次审计格点上限(对齐 MainPage 漏局分支的 200 护栏)
COV_HIST_COOLDOWN_MS = 5_000  # 哨兵触发 GameHistory 的每房冷却(跨进程 SET NX PX)
# MainPage 失败退避封顶:首败仍 1.5s 快重试(单次抖动秒级自愈),连败按 2^n 升至
# 封顶。成功即清零(mpFails 随主快照 HSET 复位,零额外往返)。
#
# 3.4.0 由 30s 提到 **60s**(真机模拟驱动):一局 = 50s,健康房的 MainPage 节奏就是
# ~50s/次。封顶取 30s 意味着**上游故障中的房反而比健康房被打得更勤**(每 30s 一次
# vs 每 50s 一次)—— 故障时刻恰恰是最该收敛请求的时刻,方向反了。取 60s 后:
#   · 上游全灭 10 分钟,单房调用从 ~20 次降到 ~12 次;万房规模下故障期 MainPage
#     洪峰从 333 rps 降到 167 rps(低于健康稳态的 200 rps —— 方向摆正);
#   · 代价:上游恢复后最坏多等 30s 才恢复该房抓取(抖动令各房相位随机,不同步)。
#     漏掉的局由 GameHistory 兜底 + 覆盖哨兵补齐,数据不丢。
MP_FAIL_BACKOFF_CAP_MS = 60_000

# 核验房复核的**巡检节拍**(秒),与每房的复核周期(discovery.verify_interval_s,
# 默认一天)是两回事:到不到期由每房自己的 next_probe_ms(存 PG)说了算,巡检
# 只是periodically 醒来看看有没有到期的。刻意写死而不做成参数 —— 它只决定
# 「到期后最坏多晚被处理」,对一天一次的周期毫无调节价值,多一个旋钮只会多一处
# 漂移点。取 300 而非 60:每一轮都要读一遍台账 + 策展名录 + livestatus 全表,
# 而 _livestatus 循环本就每 60s 做同量级的事 —— 没必要再叠一份同频扫描;
# ≤5 分钟的处理延迟对 24 小时的周期完全无感。
_VERIFY_TICK_S = 300

# 令牌桶阻塞等待上限(秒):`rl.acquire()` 默认最多阻塞 30s,叠加 upstream.request_timeout
# (15s)后单任务最长可占 45s —— **超过任务租约 stale_task_grace_ms**,租约到期即被别的
# 副本重复领取、重复打上游(恰在限流已经吃紧时雪上加霜)。把等待钳到 8s 后:
#     单任务最长 ≈ 8s(等令牌)+ 15s(请求)= 23s  <  30s 租约  ✅
# 且限流真的咬住时,任务 8s 后就重排回延迟队列(消费者不被长期占住),比死等更健康。
# 注:默认 upstream_rps=0(不限流),此路径直接放行、不触碰 Redis —— 本钳位只在
# 运维**主动开启**限流时才有意义,属"开启限流也不会踩坑"的前置加固。
RL_MAX_WAIT_S = 8.0


def effective_claim_grace_ms(s) -> int:
    """claimer 实际使用的任务租约(ms):配置值,但**下限钳到「单任务最坏耗时 + 2s」**。

    为什么不能只信配置(与 upstream.award_max_retries 的 eff_max 钳同一先例):
    配置中枢的历史持久快照(PG config_revisions,boot 时覆盖 YAML/代码默认)可能存着
    3.4.0 之前的旧值 15000 —— 若按字面生效,就把已修复的 P0(租约 ≤ 上游超时 →
    慢请求在返回瞬间被别的副本重复领取、重复打上游)原样灌回来。**打破不变量的
    配置不允许借任何通道生效**;管理台校验只拦新写入,拦不住历史版本,故代码侧钳底。
    最坏耗时 = 令牌等待(RL_MAX_WAIT_S)+ 上游请求超时(request_timeout,live 读 ——
    运维调大超时,下限自动跟着抬)。往大调租约不受限(那只影响崩溃重投延迟)。"""
    floor_ms = int((RL_MAX_WAIT_S + float(s.upstream.request_timeout)) * 1000) + 2000
    return max(int(s.scheduler.stale_task_grace_ms), floor_ms)


def _snap_server_offset(snap: dict) -> int:
    """快照里实测的**服务器钟 − 本机钟**(ms),由 MainPage 每局刷新
    (`offset = server_now - noww`,见 _handle_mainpage)。

    ── 为什么每一处「用 round_id 算到期时刻」都必须减掉它(3.4.3 真机实证的严重缺陷)──
    `round_id` 是**游戏服务器**的毫秒时间戳(局起点)。而延迟队列的到期判定
    (`redis_bus.claim_due` → `ZRANGEBYSCORE sched -inf now_ms()`)用的是 **worker 本机钟**。
    所以任何 `due = round_id + <局内偏移>` 都是一个**服务器钟域**的值,被当成
    **本机钟域**的 ZSET 分数 —— 两个钟只要不同步,任务就会整体偏移。

    实测(真机模拟,本机钟故意调成落后上游 40s):
        出怪入库时刻 = 局内 **77.5s**(正确应 ≈37.5s)—— 正好晚了 40s = 钟偏。
        而倒计时(drawTime)在局内 40s 就结束、下一局在 50s 就开始
        → **「出怪倒计时结束、下一局都开跑了,才显示上一局的出怪」**。
    且因为**首拍(备战+1.5s)必然落空**(实测上游备战+2.2s 才就绪),
    **每一局都会走到重试拍** —— 无一局幸免,故表现为**系统性**滞后:
    数据一条不丢(coverage 恒 complete)、与房间数/算力无关,只是恒定地晚 N 秒。

    换算:  本机到期时刻 = 服务器目标时刻 − serverOffsetMs
    缺失/异常时按 0(= 假设两钟同步),与旧行为一致。
    """
    try:
        off = int(snap.get("serverOffsetMs") or 0)
    except (TypeError, ValueError, AttributeError):
        return 0
    # 护栏:异常大的钟差(>10 分钟)多半是脏快照,按 0 处理并靠告警暴露
    return off if abs(off) <= 600_000 else 0


def _snap_spell_offset(snap: dict) -> int:
    """备战相对局起点的偏移(ms):优先由快照实时差值推(容忍上游改制),
    异常/缺失回退游戏结构常量 35_000。award 重试拍点以此把绝对时刻
    锚定到「该局备战」,消除 now 基准的抖动逐段累计。"""
    try:
        off = int(snap.get("spellTimeMs") or 0) - int(snap.get("roundStartTimeMs") or 0)
        if 5_000 <= off <= 45_000:
            return off
    except (TypeError, ValueError):
        pass
    return 35_000
# GameHistory 固定只保留最近 N 局(旧引擎 spell_tamer_monitor 两处实证注明为 30;
# 官方头恒 ≥ 本地头,页窗只会更靠前 —— 因此比 head−N 局更老的格点**数学上必不可达**,
# 哨兵对这类格点免打上游、直接确证登记,杜绝注定空手的请求(深洞接力/删房重加场景)。
COV_HIST_PAGE_ROUNDS = HIST_PAGE_ROUNDS   # = 30;单一真相源迁至 constants(3.5.0)


def janitor_spread_window(n_missing: int, warmup_window_ms: int) -> int:
    """janitor 补排 MainPage 起点的错峰窗宽(ms)。3.4.8:随规模自适应 ——
    `min(warmup_window_ms, n×25)`。n≤120 时 n×25 ≤ 3000,经 schedule_spread
    均匀铺开后逐毫秒**等价于旧式** `(i*25)%3000`(i*(n*25)//n == i*25,取模
    本就不生效)—— 常态零星补排零变化;「名录幸存、调度 ZSET 大面积丢失」的
    边缘场景(回灌半失败/误删/非默认部署改驱逐策略;默认 noeviction 不驱逐,
    场景更窄)才铺宽,warmup_window_ms(默认 60s)
    封顶,风暴形状与批量准入/boot 回灌完全同一口径。纯函数,契约测试直测。"""
    return min(int(warmup_window_ms), max(0, int(n_missing)) * 25)


class Worker:
    def __init__(self, s: Settings = _S):
        self.s = s
        # Redis 池按 consumer 并发放大:数百 consumer 同时打 Redis 时,默认 100
        # 的池会撞 MaxConnectionsError。留 128 余量给 claimer/janitor/pubsub 等。
        self.bus = RedisBus(s.redis_url,
                            max_connections=max(s.redis_max_connections,
                                                s.worker_concurrency + 128),
                            pool_timeout=s.redis_pool_timeout)
        self.db = DB(s.pg_dsn, s.pg_pool_min, s.pg_pool_max)
        self.rl = TokenBucket(self.bus.r, "rl:upstream",
                              s.ratelimit.upstream_rps, s.ratelimit.burst)
        # 繁星归一专用令牌桶(与游戏 API 独立的一路)+ 跨进程归一缓存(共享 Redis)。
        # janitor 的挂起短号重试也走它 —— 数千挂起房重试归一不会惊群打爆繁星。
        self.fx_rl = TokenBucket(self.bus.r, "rl:fanxing",
                                 s.ratelimit.fanxing_rps, s.ratelimit.fanxing_burst)
        self.up = Upstream(
            s.upstream.base_url, s.auth.to_headers(),
            timeout=s.upstream.request_timeout, verify_tls=s.upstream.verify_tls,
            conn_limit=s.http_conn_limit, conn_per_host=s.http_conn_per_host)
        self.bridge = PredictorBridge(s.prediction, s.custom_beast_ids)
        self.star = StarMeta(conn_limit=s.starmeta_conn_limit,
                             bucket=self.fx_rl, redis=self.bus.r)
        # 直播间自动发现器(遍历繁星在播列表)。翻页也过繁星令牌桶(与归一同一路),
        # 遍历本身不会惊群打爆繁星。**懒建**:_discovery 协程按开关自行构造/重建
        # (配置中枢可热切 discovery.enabled 及其构造期参数,见 _mark_disc_dirty)。
        self.disc: Optional[Discovery] = None
        self._disc_dirty = False
        # curated-idle(3.7.0):本副本是否见过开关开启 —— 关闭后仅由见过的副本
        # 做一次残留冷标清理(锁内),从未开启的部署一条命令都不多花。跨重启
        # 丢失无害:残留标对所有闸惰性(见 _dormant),纯属观测卫生。
        self._ci_was_on = False
        # 配置中枢:本进程套用状态(心跳/回执载体)+ 热更钩子表(config_center 按标识分发)。
        self.cfg_state = cfgc.CenterState(role="worker")
        self._hooks = {
            "rl_upstream": lambda: self.rl.update(self.s.ratelimit.upstream_rps,
                                                  self.s.ratelimit.burst),
            "rl_fanxing": lambda: self.fx_rl.update(self.s.ratelimit.fanxing_rps,
                                                    self.s.ratelimit.fanxing_burst),
            "bridge": self._rebuild_bridge,
            "auth": lambda: self.up.update_auth(self.s.auth.to_headers()),
            "loglevel": lambda: logging.getLogger().setLevel(
                getattr(logging, str(self.s.log_level).upper(), logging.INFO)),
            "disc_rebuild": self._mark_disc_dirty,
        }
        self._running = True
        self._award_count = 0                      # 自上条聚合统计行以来的新入库局数
        self._hist_ins_count = 0                   # 同窗口经 GameHistory 回填的入库局数
                                                   # (3.5.0:hist-mode 启用时统计行才不撒谎;
                                                   #  含策展房播种/哨兵回填,口径=「回填入库」)
        self._stats_last = time.monotonic()        # 聚合统计行的节拍锚点(janitor 内发)
        # 副本口径标识:stats:ingest:replicas 子哈希的字段名(全舰队聚合见 3.4.7)。
        # 进程重启 = 新 id,旧 id 条目按 ts 新鲜度自然出账并被顺手 HDEL。
        self._stats_wid = uuid.uuid4().hex[:8]
        self._q: asyncio.Queue[str] = asyncio.Queue(maxsize=s.worker_concurrency * 2)
        self._room_locks: Dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)
        self._active_cache: set = set()
        self._active_ts = 0.0

    # ── 配置中枢钩子 ─────────────────────────────────────────────────────────
    def _rebuild_bridge(self) -> None:
        """预测参数变更:原子换新预测桥(进行中的任务继续用旧桥,无状态设计保证安全)。"""
        self.bridge = PredictorBridge(dict(self.s.prediction), self.s.custom_beast_ids)

    def _mark_disc_dirty(self) -> None:
        """发现器构造期参数变更:置脏,由 _discovery 循环在下一轮重建。"""
        self._disc_dirty = True

    async def _build_disc(self) -> Optional[Discovery]:
        """按当前配置构造发现器(enabled=false 返回 None)。"""
        if not self.s.discovery.enabled:
            return None
        d = Discovery(
            list_url=self.s.discovery.list_url or None,
            params=self.s.discovery.params, timeout=self.s.discovery.request_timeout,
            conn_limit=self.s.discovery.conn_limit, bucket=self.fx_rl,
            max_pages=self.s.discovery.max_pages,
            page_delay_ms=self.s.discovery.page_delay_ms,
            page_concurrency=self.s.discovery.page_concurrency)
        await d.start()
        return d

    # ── 生命周期 ────────────────────────────────────────────────────────────
    async def start(self) -> None:
        await self.db.connect()
        await self.db.migrate()
        await self.up.start()
        await self.star.start()
        # 注:发现器(self.disc)的构造/重建/关闭由 _discovery 循环独占管理(懒建),
        # 此处不再预建 —— 避免启动期 aiohttp 会话构造异常拖垮 worker 启动。
        await self.bus.ping()
        # PG → Redis 名录回灌(Redis 作纯运行态;对齐旧版「配置持久化,重启不丢」)
        try:
            rooms = await self.db.restore_rooms()
            act = rooms["active"]
            pend = rooms["pending"]
            # 批量回灌:一次 pipeline 往返(替代逐房 add_room/pending_add 的 N 次往返,
            # 数千房重启时 N 次串行往返可达数秒;与批量准入同一策略)。
            if act:
                await self.bus.add_rooms_bulk(
                    [(r["room_id"], r.get("alias") or r["room_id"]) for r in act])
                # 立即恢复抓取:为回灌的 active 房在 warmup 窗口内错峰排首个 MainPage。
                # 否则要等 janitor 首轮(先 sleep janitor_interval≈30s)才补排 ——
                # 重启即有 ~30s 抓取盲区。错峰铺开避免数千房重启首抓惊群(与冷启动
                # 削峰同理)。janitor 仍作兜底(捕获任何 active 却未排的房)。
                await self.bus.schedule_spread(
                    [task_mainpage(r["room_id"]) for r in act],
                    now_ms(), self.s.admission.warmup_window_ms)
            if pend:
                await self.bus.pending_add_bulk([r["room_id"] for r in pend])
            if act or pend:
                log.info("名录回灌:active=%d pending=%d", len(act), len(pend))
        except Exception as e:
            log.warning("名录回灌失败(不影响启动): %r", e)
        log.info("worker 启动:concurrency=%d upstream_rps=%.0f burst=%.0f",
                 self.s.worker_concurrency, self.s.ratelimit.upstream_rps,
                 self.s.ratelimit.burst)

    async def close(self) -> None:
        with contextlib.suppress(Exception):
            await self.star.close()
        with contextlib.suppress(Exception):
            if self.disc is not None:
                await self.disc.close()
        with contextlib.suppress(Exception):
            await self.up.close()
        with contextlib.suppress(Exception):
            await self.db.close()
        with contextlib.suppress(Exception):
            await self.bus.close()

    def stop(self, *_a) -> None:
        self._running = False

    async def run(self) -> None:
        await self.start()
        consumers = [asyncio.create_task(self._consumer(i))
                     for i in range(self.s.worker_concurrency)]
        tasks = [asyncio.create_task(self._claimer()),
                 asyncio.create_task(self._janitor()),
                 asyncio.create_task(self._retention()),
                 asyncio.create_task(self._pred_replay()),
                 asyncio.create_task(self._discovery()),
                 asyncio.create_task(self._livestatus()),
                 asyncio.create_task(self._verify_sweep()),
                 asyncio.create_task(self._auth_refresher()),
                 asyncio.create_task(cfgc.run_agent(
                     settings=self.s, role="worker", bus=self.bus, db=self.db,
                     hooks=self._hooks, state=self.cfg_state,
                     running=lambda: self._running)),
                 *consumers]
        try:
            await asyncio.gather(*tasks)
        finally:
            await self.close()

    # ── 鉴权票据热更新(自动登录续期桥接) ────────────────────────────────────
    async def _auth_refresher(self) -> None:
        """定期从 cookie 文件读取新票据并热更新到抓取会话。

        kugou_login 刷新服务把新 Cookie 写进 spell_tamer_config.json(共享卷),
        本任务据此更新 x-auth-uid/x-auth-ticket —— 续期后 worker **无需重启**即生效。
        未配置 STA_AUTH_COOKIE_FILE 时本任务直接退出, 不影响原有行为。
        """
        from .settings import auth_from_cookie_file
        if not (self.s.auth_cookie_file or "").strip():
            return
        last = (str(self.s.auth.uid), str(self.s.auth.ticket))
        log.info("鉴权热更新已启用:每 %ds 读取 %s",
                 max(15, int(self.s.auth_refresh_s)), self.s.auth_cookie_file)
        while self._running:
            # 循环内现读 path/interval:配置中枢可热更续期文件路径与轮询间隔。
            path = (self.s.auth_cookie_file or "").strip()
            interval = max(15, int(self.s.auth_refresh_s))
            for _ in range(interval):          # 秒级步进, SIGTERM 后 ≤1s 退出
                if not self._running:
                    return
                await asyncio.sleep(1)
            if not path:
                continue
            try:
                uid, tk = auth_from_cookie_file(path)
            except Exception as e:
                log.debug("鉴权热更新读取异常: %s", e)
                continue
            if uid and tk and (str(uid), str(tk)) != last:
                self.up.update_auth({"x-auth-uid": str(uid), "x-auth-ticket": str(tk)})
                # 同步回 settings.auth:让管理台票据面板/来源判定与实际抓取票据一致
                # (cookie 续期是 auth 系的最高优先来源,方案 §3.2 例外)。
                self.s.auth.uid, self.s.auth.ticket = str(uid), str(tk)
                last = (str(uid), str(tk))
                log.info("✅ 鉴权票据已热更新:uid=%s ticket=%s…", uid, str(tk)[:12])

    # ── 活跃房缓存(避免每个任务都打一次 Redis) ──────────────────────────────
    async def _is_active(self, room: str) -> bool:
        if time.monotonic() - self._active_ts > 2.0:
            self._active_cache = set(await self.bus.active_rooms())
            self._active_ts = time.monotonic()
        return room in self._active_cache

    # ── claimer:原子领取到期任务 → 本地队列(背压) ──────────────────────────
    async def _claimer(self) -> None:
        while self._running:
            try:
                # 循环内现读:claim_batch / stale_task_grace_ms 经配置中枢热更即时生效
                batch = self.s.scheduler.claim_batch
                grace = effective_claim_grace_ms(self.s)   # 下限钳:历史配置也打不破租约不变量
                # 队列快满时先歇一歇,把处理权留给 consumer(也把任务留给别的 worker)
                if self._q.qsize() > self._q.maxsize * 0.7:
                    await asyncio.sleep(0.05)
                    continue
                members = await self.bus.claim_due(batch, grace)
                if not members:
                    await asyncio.sleep(0.1)
                    continue
                for m in members:
                    await self._q.put(m)
            except Exception as e:
                log.error("claimer 异常: %r", e)
                await asyncio.sleep(0.5)

    # ── consumer:执行单个任务 ──────────────────────────────────────────────
    async def _consumer(self, idx: int) -> None:
        while self._running:
            try:
                member = await asyncio.wait_for(self._q.get(), timeout=1.0)
            except asyncio.TimeoutError:
                continue
            try:
                await self._handle(member)
            except AuthExpired:
                # 票据过期:该任务重排稍后重试;上层可在此接换票据流程
                await self.bus.schedule(member, now_ms() + 5000)
            except Exception as e:
                log.exception("处理任务 %s 异常: %r", member, e)
                # 兜底重排,避免任务因偶发异常永久丢失
                with contextlib.suppress(Exception):
                    await self.bus.schedule(member, now_ms() + 3000)
            finally:
                self._q.task_done()

    async def _handle(self, member: str) -> None:
        kind, room, round_id = parse_task(member)
        if not await self._is_active(room):
            await self.bus.ack(member)   # 房已删除:丢弃该任务
            return
        if kind == "mp":
            # 【3.5.0 hist-mode 迁移入口】发现房在模式开启时退出实时管线:本拍
            # 不打 MainPage,改排一个轮询任务。首拍**满窗 U(0,T) 铺开** —— 各房
            # mp 相位本挤在一局 50s 内,若只平移相位会形成"每 T 一次的 50s 梳齿
            # 脉冲"(万房 = 每 T 突刺 200 req/s);满窗随机后恒定均匀(万房
            # T=300s ≈ 33 req/s)。存量在飞的 aw 任务照常跑完(最后一局仍以
            # award 入库,无缝);mp 停排后不再产生新 aw,一局内迁移完毕、零风暴。
            # enabled=False 时 and 短路 —— 既有路径零额外 Redis 命令(契约⑪)。
            # 3.7.0:判据泛化为 _dormant(发现房 ∪ 冷策展房)—— 冷房降级复用
            # 本入口整套机器(改排/满窗抖动/aw 收尾),janitor 只打标不排任务。
            if self.s.histmode.enabled and await self._dormant(room):
                await self.bus.ack(member)
                await self.bus.schedule(
                    task_hist(room),
                    now_ms() + random.randint(0, effective_hist_interval_ms(
                        self.s.histmode)))
                return
            await self._handle_mainpage(room, member)
        elif kind == "aw" and round_id is not None:
            await self._handle_award(room, round_id, member)
        elif kind == "hs":
            await self._handle_hist(room, member)
        else:
            await self.bus.ack(member)

    async def _dormant(self, room: str) -> bool:
        """「无实时消费者」统一判据(3.7.0):自动发现房,或已降级的空闲策展房。

        取代四处裸 is_discovered(mp 迁移入口 / 轮询续跑闸 / 两处预测闸)。
        顺序即成本:is_discovered 先判 —— 舰队主体(发现房)在第一跳短路,
        零新增命令;cold 只在 histmode.enabled **且** curated_idle_enabled
        双开时才查(一次 HEXISTS,且只落在策展房上,常态 1~50 房)。任一开关
        关闭时本函数与旧 is_discovered **逐命令等价**(契约⑪:稳态零额外
        Redis)—— 也因此,功能关闭后残留的冷标对所有闸完全惰性。
        失败语义同源:任何一跳判不出来都按「活跃策展房」走(宁可多算,绝不
        因 Redis 抖动停掉用户在看的房)。"""
        if await self.bus.is_discovered(room):
            return True
        hm = self.s.histmode
        if hm.enabled and getattr(hm, "curated_idle_enabled", False):
            return await self.bus.is_cold(room)
        return False

    # ── MainPage:拿本局权威计时,排 award 与下一次 mainpage ────────────────────
    async def _mp_fail_due(self, room: str, err: str = "") -> int:
        """MainPage 失败重试时刻:连败指数退避(1.5s→3→6→12→24→…→60s 封顶,
        见 MP_FAIL_BACKOFF_CAP_MS)。连败计数存主快照 mpFails 字段(HINCRBY 原子,
        多副本安全;成功路径随主快照写入复位为 0;Redis 掉电=自然清零,重生后
        回到快重试)。

        3.9.5:`err` 非空时把失败原因落快照 lastError —— **每连败串恰一次**
        (fails==1 才写,成功路径既有 `"lastError": ""` 复位),万房级断供时
        不产生逐拍写风暴。lastError 此前只有成功清空、从无写入,是个"有田无人
        耕"的死字段:名录角标『断』的悬停提示与 /api/crawler/status 由此能说出
        票据过期/上游异常的真话,而不是让用户去猜"主播是不是下播了"。
        连败串中途错误类型变化(网络→票据)时消息保持首因不追更 —— 省写,可接受。"""
        fails = await self.bus.snap_incr(room, "mpFails")
        if err and fails == 1:
            with contextlib.suppress(Exception):
                await self.bus.set_snapshot(room, {"lastError": err})
        base = int(self.s.upstream.award_retry_interval * 1000)
        delay = min(MP_FAIL_BACKOFF_CAP_MS, base << (min(fails, 6) - 1))
        # 抖动去同步(与成功拍排期同源同上限 mainpage_jitter_ms):全局断供时
        # 万房退避链若无抖动会保持入供相位(成功拍抖动仅 ≤4s),恢复瞬间回流
        # 成 4s 突刺(万房 ≈2500 次 GameHistory/s);逐拍抖动令相位随机游走,
        # 8 跳后回流自然铺开十余秒(万房 mass2 战役实测驱动)。jitter=0 时
        # 本项为 0,确定性契约/矩阵世界不受影响。
        delay += random.randint(0, max(0, int(self.s.scheduler.mainpage_jitter_ms)))
        return now_ms() + delay

    async def _handle_mainpage(self, room: str, member: str) -> None:
        # 单房节流(安全网):防单房异常自旋。正常 8s+ 间隔远大于该阈值,不触发。
        ok, wait = await self.bus.room_gate(room, self.s.ratelimit.per_room_min_interval_ms)
        if not ok:
            await self.bus.schedule(member, now_ms() + wait)
            return
        if not await self.rl.acquire(max_wait_s=RL_MAX_WAIT_S):
            await self.bus.schedule(member, now_ms() + 1000)   # 限流拿不到令牌:稍后
            return
        # 3.9.5:票据过期(401/403)改走**标准失败退避**,不再抛给 consumer 的
        # +5s 平拍 —— 对齐 hist 侧「复查修正 C」的既定裁决(worker.py hist 段注),
        # 且 config.yaml ratelimit 段早已点名的风险:万房断票下 +5s 平拍 ≈2000
        # 次 401/s 的自伤风暴(封 IP/扣票据);退避链 60s 封顶 ≈167/s。err 落
        # lastError(每连败串一次),名录『断』角标/爬虫状态页由此可诊断。
        # consumer 的 AuthExpired 兜底降为最后一道网:三类处理器(mp/hist/award)
        # 均已就地消化票据过期,仅剩「处理器中途换票据死亡」的罕见竞态
        # (如 mp 成功后播种/漏局的 GameHistory 才 401)会落到它,+5s 一次性无害。
        try:
            main = await self.up.main_page(self.s.activity_id, room)
        except AuthExpired:
            await self.bus.schedule(member, await self._mp_fail_due(
                room, err="上游 401/403:抓取票据(x-auth-ticket)可能已过期"))
            return
        if not main:
            await self.bus.schedule(member, await self._mp_fail_due(
                room, err="MainPage 无有效返回(网络/上游异常)"))
            return
        try:
            rid = int(main.get("roundId", 0) or 0)
            srv = int(main.get("serverTime", 0) or 0)
            spell_t = int(main.get("spellTime", 0) or 0) or (rid + SPELL_OFFSET_MS)
            draw_t = int(main.get("drawTime", 0) or 0) or (rid + DRAW_OFFSET_MS)
            end_t = int(main.get("endTime", 0) or 0) or (rid + END_OFFSET_MS)
        except (TypeError, ValueError):
            await self.bus.schedule(member, await self._mp_fail_due(
                room, err="MainPage 字段异常(上游响应形变)"))
            return
        if not rid:
            await self.bus.schedule(member, await self._mp_fail_due(
                room, err="MainPage 未含 roundId(上游响应异常)"))
            return

        noww = now_ms()
        server_now = srv or noww
        offset = server_now - noww

        # 首见该房:GameHistory 回填历史,让 UI 首屏即有序列
        snap = await self.bus.get_snapshot(room)
        if not snap.get("seeded"):
            # 3.4.8 播种 DB 兜底:`seeded` 只活在 Redis 快照,而「Redis 掉电/被驱逐
            # 但 PG 幸存」重启时全舰队会对**库里明明有数据**的房逐一重打播种
            # GameHistory(万房 = 1 万次上游调用 + 1 万次 30 行 INSERT 空转,虽经
            # boot 60s 错峰摊平 ≈333 req/s,仍是纯浪费)。与哨兵「重生」判据
            # (下方 _coverage_check 的 oldest_round,worker.py 重生注释)同源:
            # 库最老一局存在 = 非新房 → 免打,直接置位;真缺口交给**同一事件末尾**
            # 的哨兵重生审计 —— 免播种分支**不占** hist_gate,恰是把闸留给哨兵
            # 当场一次确证(原语义"播种刚占用,下一事件接手"由此提前一个事件)。
            # 唯一微代价:恰落在审计静默区(最近 ≤2 局)的停机缺口改由后续 1-2 个
            # 事件的哨兵接力补回(≈晚 1-2 局时长),数据完整性不变(契约⑨钉住)。
            # DB 点查 O(1) 主键前缀扫、每房每 Redis 生命周期至多一次;查询异常时
            # 退回原播种路径 —— 行为保守收敛,绝不因 PG 抖动少播种。
            reborn = False
            try:
                reborn = (await self.db.oldest_round(room)) is not None
            except Exception:
                reborn = False
            if reborn:
                await self.bus.set_snapshot(room, {"seeded": "1"})
            elif await self._backfill_history(room):
                await self.bus.set_snapshot(room, {"seeded": "1"})
                # 礼让:占用哨兵冷却闸 —— 刚为此房打过 history,本事件末尾哨兵的
                # 初始化审计(重生页窗)若检出缺口不再立刻重复打,下一事件接手。
                await self.bus.hist_gate(room, COV_HIST_COOLDOWN_MS)

        # 写快照(Web 端渲染倒计时/爬虫状态的唯一来源)
        prev_round = snap.get("roundStartTimeMs")
        await self.bus.set_snapshot(room, {
            "roundStartTimeMs": rid, "spellTimeMs": spell_t,
            "drawTimeMs": draw_t, "endTimeMs": end_t,
            "canPlay": "1" if main.get("canPlay") else "0",
            "serverOffsetMs": offset, "serverNowMs": server_now,
            "lastOkAt": noww, "lastError": "", "mpFails": 0,
        })

        # 漏局检测(对齐旧 _cycle):换局步进 > 一局 → GameHistory 补齐中间缺口
        try:
            prev_i = int(prev_round or 0)
        except (TypeError, ValueError):
            prev_i = 0
        if prev_i and rid - prev_i > ROUND_STEP:
            log.warning("[漏局] room=%s 跨 %d 局,GameHistory 补齐",
                        room, (rid - prev_i) // ROUND_STEP)
            if await self._backfill_history(room):
                # 礼让:占用哨兵冷却闸 —— 本事件末尾的覆盖哨兵若同时检出缺口,
                # 不再重复打一次 history(刚打过);闸过期后下一事件自然接手。
                await self.bus.hist_gate(room, COV_HIST_COOLDOWN_MS)
                # 补齐**成功执行**后仍缺的中间格点 = 官方历史里也没有 → 官方本身
                # 缺失,登记。前提必须是补齐成功:上游失败时「仍缺」不构成任何证据,
                # 误登记会让哨兵把可救的局当已覆盖 → 页窗内数据被永久判死
                # (真机仿真 S9 实证过此缺陷),失败时留白交哨兵重试链兜底。
                # 只查 (prev_i, rid) 开区间格点,数量有界(正常换局跨 1 局不进本分支)。
                gap = (rid - prev_i) // ROUND_STEP
                if gap <= 200:                   # 护栏:异常大跨度不逐格查库
                    for g in range(prev_i + ROUND_STEP, rid, ROUND_STEP):
                        if not await self.db.has_round(room, g):
                            await self.bus.official_missing_mark(room, g)

        # 换局(或首见):即时推权威倒计时锚点(timer 字段对齐旧 HookedMonitor,含 canPlay)
        if str(prev_round or "") != str(rid):
            alias = await self.bus.alias_of(room)
            await self.bus.publish_draw(room, {
                "type": "room-updated", "roomId": room, "alias": alias,
                "serverNowMs": server_now, "roundsTouched": False,
                "timer": {"roundStartTimeMs": rid, "spellTimeMs": spell_t,
                          "drawTimeMs": draw_t, "endTimeMs": end_t,
                          "canPlay": bool(main.get("canPlay"))},
            })

        # 排本局 award + 下一次 mainpage(均带抖动 → 错峰)
        # 锚点 = 备战(spellTime):真机实测结果备战后 ~1s 即可拉,不必等 drawTime,数据早出约 6s。
        # spell_t 上游已内建兜底(MainPage 缺 spellTime 时 = rid + SPELL_OFFSET_MS),恒有合理值,
        # 故此处不再需要 draw_t 分支。award_delay 仅保留给取奖窗口校验器与文档。
        aw_due = award_due_wall(noww, server_now, spell_t,
                                int(self.s.upstream.award_after_seal * 1000),
                                # 首取抖动压窄:各房 spell 相位本就互异,错峰不
                                # 依赖首取满幅抖动;1.2s 满幅曾贡献"落地晚"约
                                # 三成(重试阶梯整串右移)。重试段错峰仍按档抖动。
                                min(self.s.scheduler.award_jitter_ms, 400))
        mp_due = next_mainpage_due_wall(noww, server_now, end_t,
                                        self.s.scheduler.mainpage_min_interval_ms,
                                        self.s.scheduler.mainpage_jitter_ms)
        await self.bus.schedule_many({task_award(room, rid): aw_due,
                                      task_mainpage(room): mp_due})
        # 注:mp member 与本 member 相同 → 上面的 schedule 即完成本任务的 ack+重排

        # 覆盖哨兵:任务已重排(等效 ack)后再审,哨兵异常不影响主链路。
        # MainPage 每局必有一拍 —— 即便 award 任务整段丢失(Redis 掉数据/崩溃
        # 窗口,MainPage 步进恒为 1、漏局分支不触发),哨兵也能在 ≤2 局内检出
        # 真缺口并补漏。snap 为本轮写前读取,covWm/covLastIns 未被本轮触碰,仍新鲜。
        await self._coverage_check(room, rid, snap=snap)

    # ── RoundAward:出怪入库 + 结算/预测 + 推送 ──────────────────────────────
    async def _light_push_if_stale(self, room: str, round_id: int,
                                   snap=None) -> None:
        """轻量补推(幂等):该局已在库但快照/前端可能还不知道 —— 补写
        latestRoundId 并推 roundsTouched(不含 round 详情,前端收到按既有行为
        拉一次 /history 增量即秒达)。入口去重与 GameHistory 升级补齐共用:
        升级路径此前入库后**不推送**(仅 ack),SSE 健康的前端(3.3.9 起活性期
        不追拉)只能等下一局 coverage/熔断兜底 —— 第三峰慢局(备战+26.5s 后才
        就绪)时效倒退 ~25s,由此封死;快照 latestRoundId 同步跟上,/prediction
        孤儿过滤的 latest 数据源不再滞后于 /history(DB 直读)。"""
        if snap is None:
            snap = await self.bus.get_snapshot(room)
        if int(snap.get("latestRoundId") or 0) < round_id:
            await self.bus.set_snapshot(room, {"latestRoundId": round_id})
            await self.bus.publish_draw(room, {
                "type": "room-updated", "roomId": room,
                "alias": await self.bus.alias_of(room),
                "serverNowMs": extrapolate_server_now(snap, now_ms()),
                "roundsTouched": True,
            })

    async def _handle_award(self, room: str, round_id: int, member: str) -> None:
        if await self.db.has_round(room, round_id):
            await self.bus.ack(member)
            await self.bus.award_attempt_clear(room, round_id)
            # 补发兜底:该局已在库(history 抢先补齐/双副本竞态等)但可能从未
            # 推送过(latestRoundId 落后即证)。轻量补推 roundsTouched,
            # 幂等 —— 彻底封死"库里有、前端等"的一切残余成因。
            await self._light_push_if_stale(room, round_id)
            return
        if not await self.rl.acquire(max_wait_s=RL_MAX_WAIT_S):
            await self.bus.schedule(member, now_ms() + 1000)
            return
        # 3.9.5(同类问题同修,与 mp/hist 的 AuthExpired 治理同向):票据过期改
        # 60s 平拍重排,不再逃逸到 consumer 的 +5s —— 万房断票下在飞 award 任务
        # ≈1 条/房,+5s ≈2000 次 401/s 的自伤风暴;60s(=MP_FAIL_BACKOFF_CAP_MS,
        # 与 mp 退避封顶同拍)≈167/s。三条不变量由构造保证:
        #   · attempt **不动** —— auth 失败不构成「官方缺失」的任何证据,升级判定
        #     (末拍+终拍双 GameHistory 验证)从票据恢复处原样续走;
        #   · 队列**有界** —— award 任务只由 mp 成功排入(schedule_many),断票期
        #     mp 自身先失败,不增殖新任务,只有在飞的 ≈1 条/房在慢速自旋;
        #   · 数据零损 —— 恢复后 mp 播种/漏局/哨兵的 GameHistory 页窗回补本就
        #     覆盖出怪结果,award 晚 ≤60s 完全被遮蔽。
        # lastError 不在此写:mp 会以同一票据错在 ≤60s 内经 _mp_fail_due 落写
        # (fails==1 门控),此处再写属冗余。平拍保相位:各房备战相位天然错峰,
        # 平拍(异于退避的相位压缩)恰好原样保持该错峰,仅加微抖去共振。
        try:
            award = await self.up.round_award(self.s.activity_id, room, str(round_id))
        except AuthExpired:
            await self.bus.schedule(member, now_ms() + MP_FAIL_BACKOFF_CAP_MS
                                    + random.randint(0, max(0, int(
                                        self.s.scheduler.mainpage_jitter_ms))))
            return
        bi = (award or {}).get("beastInfo") or {}
        if not (bi.get("beastId") or bi.get("beastName")):
            attempt = await self.bus.award_attempt_incr(room, round_id)
            # 3.3.9 护栏钳:升级时刻由**阶梯表自身**推导 —— 基线 attempt 语义 =
            # len(表)+2(9 锚逐拍 + 末锚复拍 1 次 + 第 11 拍升级 ≈ 备战+26.9,
            # 与旧 6 锚/max=8 的尾部 [26.5 取, 26.7 取, 26.9 升级] 逐拍相同)。
            # 配置中心的历史持久快照(config_revisions,boot 时覆盖 YAML/默认)
            # 或管理台可把 award_max_retries 存成旧值 8 / 任意更小值:若按字面
            # 生效,升级会提前到 21s 拍甚至更早,打破「升级=备战+26.5s 护栏不动」
            # 的钉死不变量、放大误判官方缺失面。故配置只允许**加拍**(> 基线时在
            # 末锚多复拍几次再升级),绝不允许借配置把升级挪早;0/更小值一律按基线。
            eff_max = max(int(self.s.upstream.award_max_retries or 0),
                          len(AWARD_LADDER_MS) + 2)
            if attempt < eff_max:
                # 早段密化的重试阶梯(间隔表,attempt=1..9;第 10 拍复打末锚,
                # 第 11 次空→升级,配 award_max_retries 默认 11)。旧线性阶梯
                # (1.5×attempt)尝试点 ≈ 备战+1.5/3/6/10.5/16.5/24:上游偶发就绪
                # 晚 2~4s 要等第 3 拍(+6s)才命中 —— 前端 ~1s 轮询 /history 恰
                # "连续 5 次才拿到"(真机指纹)。密化表尝试点绝对锚定备战
                # (而非 now+delay 逐段漂移):按真机 HAR 实证的 ready 双峰
                # (房 321)钉制 —— 主峰 备战+~1s(多数局)/次峰 备战+9.5~11s。
                # 拍点表(相对备战,首取=备战+1.5 由 award_due_wall 锚定):
                #   +2.3/3.2/5.7/**12.0**/14.5/18/21/24/26.5 —— 主峰 1 拍;
                #   晚 ≤4.2s → +5.7;**次峰 ≤11.0s → +12.0 = 局内 47.0 钉死**
                #   (旧线性表 46.9 持平;此前两版曾分别探针实测 50.9/49.0 反劣
                #   —— 均匀密化的骑线滚档、now 基准的抖动逐段累计 ~2s,两个教训
                #   入档);**谷段 +18/21/24(3.3.9 真机 HAR2 实证:该段就绪质量
                #   从 ≈0 漂移到实占 —— 备战+22.6/23.7 两局靠限流/异常跳拍链
                #   (+1/+3/+5s)撞运才近拍送达,无运气则拖到 26.5 拍 = 下局倒计时
                #   ~28;密化后该段确定性 ≤3s 内捕获,代价仅就绪>14.5s 的少数局
                #   多 ≤3 次取奖)**。上游分布再漂移时此表单点可调;根治方向=
                #   每房 EMA 自适应锚点(README 后续项)。
                # 升级 = 备战+26.5s 护栏不动(就绪特别晚不误判官方缺)。
                # 抖动仅 0~300ms 微抖(错峰由各房备战相位天然保证)。
                anchor_ms = AWARD_LADDER_MS[min(attempt, len(AWARD_LADDER_MS)) - 1]
                _snap = await self.bus.get_snapshot(room)
                spell_off = _snap_spell_offset(_snap)
                # 【3.4.3 跨钟域修复】round_id 是**游戏服务器**时间戳,而延迟队列的到期
                # 判定(claim_due → ZSET score vs now_ms())用的是**本机钟**。两钟不同步时,
                # `due = round_id + …` 会让整条重试阶梯整体偏移 —— 且首拍(备战+1.5s)必然
                # 落空(上游备战+2.2s 才就绪),**每一局都会走到这里**,故表现为系统性滞后:
                # 本机钟慢 N 秒 → 每局出怪晚 N 秒(真机实测:钟偏 40s → 入库落在局内 77.5s,
                # 而倒计时 40s 就结束、下一局 50s 就开跑)。减去实测钟差即回到本机钟域。
                srv_off = _snap_server_offset(_snap)
                due = round_id + spell_off + anchor_ms - srv_off + random.randint(0, 300)
                await self.bus.schedule(member, max(due, now_ms() + 200))

                # ── 3.4.1 早探 GameHistory(修复「出怪晚一轮才显示」) ─────────────
                # 实地核查(真实房 321):**GameHistory 在备战后 ~2.3s 就已含当前局**
                # —— 与 RoundAward 几乎同时就绪。而旧实现把 GameHistory 排在阶梯
                # **最末**(attempt==eff_max,≈备战+26.9s = 局内 61.9s)才降级去问:
                #   · 倒计时(drawTime)在局内 40s 就结束;
                #   · 下一局在局内 50s 就开始;
                #   · 数据却要等到局内 **61.9s** 才落地 → **下一局都开跑 12s 了,
                #     上一局的出怪才显示** —— 正是用户看到的现象(HAR 实证晚 67~85s)。
                # 明明有一个**已经就绪**的数据源,却白等 24 秒。
                #
                # 修:award 连空到第 EARLY_HIST_ATTEMPT 拍(备战+5.7s —— 已连空 3 拍,
                # 足证这是慢局)时,顺手问一次 GameHistory。命中即入库 + 推送 + 结算
                # + 补预测链,数据在**局内 ~40.7s**(倒计时刚结束)就到手,提前 21s。
                # 没命中就照原阶梯继续,**语义完全不变**:官方缺失仍需末拍 + 终拍的
                # 双重 GameHistory 验证,判据一字未改。
                # 成本:只有"慢局"多打 1 次 GameHistory(稳态 award 首拍即中,零额外
                # 调用),且过 hist_gate 冷却闸(同房 5s 内不重复打),风暴无虞。
                if attempt == EARLY_HIST_ATTEMPT:
                    if await self.bus.hist_gate(room, COV_HIST_COOLDOWN_MS):
                        if await self._backfill_history(room):
                            if await self.db.has_round(room, round_id):
                                log.info("[出怪] room=%s round=%s 早探 GameHistory 命中"
                                         "(省去阶梯剩余 %d 拍 ≈ %.1fs)", room, round_id,
                                         eff_max - attempt,
                                         (AWARD_LADDER_MS[-1] - anchor_ms) / 1000.0)
                                await self.bus.ack(member)
                                await self.bus.award_attempt_clear(room, round_id)
                                # 回填已入库+补链,此处只需保证「入库≠送达」的推送
                                await self._light_push_if_stale(room, round_id)
                                return
            elif attempt == eff_max:
                # 首次升级:GameHistory 兜底。页内若仍无该局,**不立即标缺**——
                # 真机 HAR 实证存在"局内 72~76s(备战+37~41s)才就绪"的第三峰,
                # 升级拍(备战+26.5)落空可能只是超晚就绪;追加**终拍**@备战+43s
                # (绝对锚定,盖实测窗上界 76.5s+1.5s 余量;首版 40s 曾被探针
                # 打出骑线误判 —— 终拍必须钉在峰外而非峰上)做二次验证,把
                # 误判官方缺的窗口推到全部实证峰之外。上游失败同旧原则:留白。
                log.warning("[出怪] room=%s round=%s 多次为空,GameHistory 兜底", room, round_id)
                hist_ok = await self._backfill_history(room)
                if hist_ok:
                    await self.bus.hist_gate(room, COV_HIST_COOLDOWN_MS)
                if await self.db.has_round(room, round_id):
                    await self.bus.ack(member)
                    await self.bus.award_attempt_clear(room, round_id)
                    # 3.3.9 时效补丁:升级补齐「入库 ≠ 送达」—— 本路此前不推送,
                    # 前端只能靠追拉撞见(风暴)或下一局 coverage 兜底。与入口
                    # 去重同构地轻量补推:第三峰慢局与旧版同拍送达且仅 1 次拉取。
                    await self._light_push_if_stale(room, round_id)
                    return
                _snap = await self.bus.get_snapshot(room)
                spell_off = _snap_spell_offset(_snap)
                srv_off = _snap_server_offset(_snap)      # 3.4.3:同上,服务器钟域 → 本机钟域
                due = round_id + spell_off + 43_000 - srv_off + random.randint(0, 300)
                await self.bus.schedule(member, max(due, now_ms() + 200))
            else:
                # 终拍(备战+43s)仍空 → 二次升级验证;两次 GameHistory 均无
                # 才登记「官方缺失」(供 /coverage 区分官方缺与本项目漏)。
                log.warning("[出怪] room=%s round=%s 终拍仍空,二次 GameHistory 验证", room, round_id)
                hist_ok = await self._backfill_history(room)
                if hist_ok:
                    await self.bus.hist_gate(room, COV_HIST_COOLDOWN_MS)
                have = await self.db.has_round(room, round_id)
                if hist_ok and not have:
                    await self.bus.official_missing_mark(room, round_id)
                    log.info("[官方缺失] room=%s round=%s 双重验证亦无此局,已登记", room, round_id)
                elif have:
                    # 3.3.9 时效补丁:终拍补回的超晚局同样「入库 ≠ 送达」,轻量补推。
                    await self._light_push_if_stale(room, round_id)
                await self.bus.ack(member)
                await self.bus.award_attempt_clear(room, round_id)
            return

        oid, name, cid, mult = self.bridge.resolve_beast(bi.get("beastId"), bi.get("beastName", ""))
        draw_ms = round_id + DRAW_OFFSET_MS
        is_new = await self.db.add_round(
            room, round_id, oid, name, cid, mult, "award",
            ms_to_local(draw_ms, "%Y-%m-%d %H:%M:%S"), ms_to_date(draw_ms))

        # 逐局日志降为 DEBUG:万房规模稳态 ≈ 200 局/s,逐条 INFO 会产出 ~2-3 GB/天
        # 且 stdout 写入在事件循环内同步执行(docker 管道被写满时会阻塞抓取)。
        # 运营脉搏由 janitor 每 60s 的聚合统计行(INFO)与 /api/crawler/status 提供;
        # 排障时 STA_LOG_LEVEL=DEBUG 可回看逐局。
        #
        # 💎稀有保留 INFO,但阈值**改为可配**(rare_log_multiplier,默认 500):旧值 250
        # 覆盖了 **实测 15.0%** 的出怪(白虹骥 6.53 + 焚天雀 4.93 + 沧溟龙 3.56;
        # 公示口径为 12%,与实盘长期不符 —— 容量按实测算,见 constants.py 同段),万房下
        # ≈24 行/s —— 并非"低频",且与「日志量与房间数解耦」的设计声明矛盾。
        # 详见 constants.RARE_LOG_MULTIPLIER_THRESHOLD 的实测注释。
        rare = mult is not None and mult >= self.s.rare_log_multiplier
        (log.info if rare else log.debug)(
            "[出怪]%s room=%s round=%s 出【%s】编号%s (%s倍)",
            " 💎稀有" if rare else "", room, round_id, name, cid, mult)
        if is_new:
            self._award_count += 1          # 供 janitor 的分钟级聚合统计行

        # ack 先做:结果已落库,任务完成;后续结算/预测失败不影响已入库数据
        await self.bus.ack(member)
        await self.bus.award_attempt_clear(room, round_id)

        if is_new:
            # 推送先于结算,且与结算解耦 —— 数据已落库,SSE 不被结算连坐。
            # 旧序(settle→publish)曾致低频丢推:settle 偶发异常 → 任务重排 →
            # 重入被入口 has_round 短路 → 该局永不推送,前端只能反复轮询
            # /history 直到撞见数据(实测表象:施法期倒计时 ~28s 才拿到上一局)。
            # cid=None(未知妖兽)同样推送(带 unknownBeast 标),前端立即渲染
            # 原名并停止轮询;结算/预测仍仅在 cid 已知时进行。
            snap = await self.bus.get_snapshot(room)
            alias = await self.bus.alias_of(room)
            await self.bus.set_snapshot(room, {"latestRoundId": round_id})
            await self.bus.publish_draw(room, {
                "type": "room-updated", "roomId": room, "alias": alias,
                # 外推钟,而非快照钟:快照 serverNowMs 是本局起点抓 MainPage 那一刻
                # 的钟,出怪时刻已陈旧 ~42s;前端 calibrate 吃到会把倒计时单拍回拖
                # ~8s(EMA α=0.2)——正是"出数据瞬间倒计时回溯到布置期"的元凶。
                "serverNowMs": extrapolate_server_now(snap, now_ms()),
                "roundsTouched": True,
                "round": self._round_obj(room, round_id, cid, oid, name, mult),
                **({} if cid else {"unknownBeast": True}),
                "timer": {
                    "roundStartTimeMs": int(snap.get("roundStartTimeMs") or 0),
                    "spellTimeMs": int(snap.get("spellTimeMs") or 0),
                    "drawTimeMs": int(snap.get("drawTimeMs") or 0),
                    "endTimeMs": int(snap.get("endTimeMs") or 0),
                    "canPlay": (snap.get("canPlay") == "1"),
                },
            })
        if is_new and cid:
            try:
                pred_push = await self._settle_and_predict(room, round_id, cid)
                if pred_push:
                    # 3.3.5 同帧判定:pred 补推(旧前端忽略);predChase 仍拉权威对账。
                    await self.bus.publish_draw(room, {
                        "type": "pred-updated", "roomId": room,
                        "roundId": str(round_id), "pred": pred_push})
            except Exception as e:                     # noqa: BLE001
                # 结算/预测失败不重排本任务(已 ack;重排会重入短路徒劳)——
                # 缺口由下一局 pending_prediction 的 ORDER BY DESC 自然顶替
                # 自愈(既有语义,Q1 实证);数据与出怪推送均已完成,不受影响。
                log.warning("[结算] room=%s round=%s 异常(推送不受影响): %s",
                            room, round_id, e)
                # …但"下一局预测"不会有人补(本局的 _settle_and_predict 是它唯一的
                # 生成点)→ 预测链断 → 前端预测号消失。补链兜底(幂等)。
                await self._push_next_prediction(room)
        elif is_new:
            # 妖兽未知(cid=NULL):无法结算(没有 actual),但**仍须生成下一局预测**——
            # 否则 `if is_new and cid:` 这一跳过就把预测链打断:pending_prediction
            # 取不到下一局预测 → 被孤儿过滤 → 前端 main=[]/target=null,预测号消失。
            # 预测本身不需要本局的兽:训练序列(db.sequence)本就只取 custom_id 非空
            # 的局,cid=NULL 的局天然被排除,预测语义与旧版逐字一致。
            await self._push_next_prediction(room)

        # 覆盖哨兵(缺口驱动的补漏校验,替代旧「每 N 局盲扫」):放在出怪推送之后
        # —— 快路径纯 Redis 步进零成本;偶发慢路径(审计/补漏)也不拖慢本局 SSE。
        # is_new 时把「本局刚入库」这枚第一手证据交给哨兵推水位(顺序出怪 →
        # 零 DB 零上游;数据完整时 GameHistory 零调用)。
        await self._coverage_check(room, round_id,
                                   inserted=(round_id if is_new else None))

    #: 训练样本过薄的**聚合**账本(进程级)。刻意不做成「每房一条 WARNING」——
    #: 那样日志量会与房间数**线性挂钩**:批量准入 1 万房时,每房在头 12 小时里都
    #: 满足告警条件,按每房 10 分钟节流算 = **16.7 行/s** 持续半天,与 README
    #: 「稳态日志量与房间数解耦」的设计声明直接冲突,并会把真正有用的高层日志
    #: 挤出 json-file 轮转窗口(constants.py 的 RARE_LOG 段吃过同一个亏)。
    #: 改成:窗口内只记账,到点**汇总成一条** —— 日志量恒为 ≤1 行/窗口,与房数无关。
    _THIN_TRAIN_SEEN: Dict[str, Tuple[int, int]] = {}   # room -> (train_n, want)
    _THIN_TRAIN_LAST_EMIT: float = float("-inf")
    _THIN_TRAIN_THROTTLE_S = 600.0

    def _warn_thin_train(self, room: str, train_n: Optional[int],
                         tw_hours: float, max_train: int) -> None:
        """实际喂进引擎的训练局数远低于配置意图时记一笔,按窗口汇总告警(4.9.5 新增,纯观测)。

        为什么需要:`train_n` 是引擎每局都算出来的**实测样本量**,但在 4.9.5 之前
        `backend_async/app/` 里**一个消费者都没有** —— 不落库、不出 API、不上前端。
        于是「训练窗/样本上限到底生效没有」在生产侧完全不可观测:既有的两处护栏
        (config_center 保存时校验、predictor_bridge 构造时告警)都是**按公式预言**
        会发生什么,没有任何一处是**测量**实际发生了什么。

        判据取「配置意图局数」的一半:
          · 时间制(tw>0)→ 意图 = rounds_for_hours(tw) 与 max_train 的较小者;
          · 计数制(tw<=0)→ 意图 = max_train。
        取一半而不是等值,是因为**正常情况下就会低于意图**:新房历史不足、
        retention 刚裁过、断流刚恢复,都会让 train_n 合法地小一截。低于一半才
        值得看一眼。

        本方法**不改变任何预测行为**,只写日志 —— 它要治的是可观测性,不是算法。
        真机实测的样本量-质量曲线见 constants.MIN_TRAIN_ROUNDS 上方的表:
        LP 方案的真实期望四码命中在 400~864 局才收敛,200 局时仍差约 2pp。

        `train_n` 缺失或为 0 一律按 0 处理并**照记**:引擎在 seq 为空时返回的是
        硬编码兜底(main=[1,2] / guard=[3,4] / train_n=0),而 `_settle_and_predict`
        这条路上**没有空序列守卫**(`_ensure_next_prediction` 有),那条兜底预测会
        照常入库、照常呈现给用户 —— 那正是最该被喊出来的一种情形。
        """
        try:
            n = int(train_n or 0)
        except (TypeError, ValueError):
            return
        mt = max(0, int(max_train or 0))
        want = min(rounds_for_hours(tw_hours), mt) if tw_hours > 0 else mt
        # 账本一律走**类属性**读写。写成 `self._THIN_TRAIN_SEEN = {}` 会在实例上
        # 新建一个同名属性把类属性遮蔽掉,此后读写分裂成两本账 —— 已实测踩过。
        if want > 0 and n * 2 < want:
            Worker._THIN_TRAIN_SEEN[room] = (n, want)
        if not Worker._THIN_TRAIN_SEEN:
            return
        now = time.monotonic()
        # 缺省用 -inf 而不是 0.0:time.monotonic() 在 Linux 上以**进程/系统启动**
        # 为原点,开机头 600s 内 `now - 0.0 < 600` 恒成立 —— 用 0.0 会把 worker
        # 刚起那段时间的首条告警整个吞掉,而那恰恰是最该喊的时候(新副本、
        # 冷启动、刚扩容)。本条已实测:改前 0 条,改后 1 条。
        # 副作用是**首个薄样本房会立刻单独喊一条**(count=1),随后才进入窗口聚合 ——
        # 这是有意的:批量准入时运维应当马上看到一条,而不是等满 10 分钟。
        if now - Worker._THIN_TRAIN_LAST_EMIT < self._THIN_TRAIN_THROTTLE_S:
            return
        Worker._THIN_TRAIN_LAST_EMIT = now
        seen = dict(Worker._THIN_TRAIN_SEEN)
        Worker._THIN_TRAIN_SEEN.clear()
        worst = sorted(seen.items(), key=lambda kv: kv[1][0])[:3]
        log.warning(
            "[训练窗] 本窗口内 %d 个房的实际训练样本不足配置意图的一半"
            "(train_window_hours=%g / max_train=%d ⇒ 意图 %d 局)。最薄的几个:%s。"
            "常见成因:新房刚接入、retention 刚裁过、抓取断流刚恢复 —— 批量准入后"
            "出现属预期,应随出怪积累自行消失。样本 <400 局时前沿调度的方案质量尚未"
            "收敛(实测 n=200 差约 2pp、n=10 差约 6pp)。下次汇总在 %.0f 分钟后",
            len(seen), tw_hours, mt, want,
            ", ".join(f"{r}={v[0]}局" for r, v in worst),
            self._THIN_TRAIN_THROTTLE_S / 60.0)

    async def _ensure_next_prediction(self, room: str) -> Optional[Dict[str, Any]]:
        """确保「最新局 + 1」有预测 —— **预测链自愈闸**(幂等;稳态零开销)。

        ── 为什么必须有它(真机 HAR + 全栈 E2E 双证的缺陷) ────────────────────
        生成下一局预测**只**发生在 `_settle_and_predict`,而它**只**在
        `_handle_award` 的「RoundAward 拿到已知妖兽」这一条主路上被调用。
        以下三条路径都会**插入新局却不生成下一局预测**,把预测链打断:

          ① **GameHistory 回填**(`_backfill_history` → `_settle_only`):只结算、
             不预测。而出怪兜底升级、漏局补齐、覆盖哨兵、**首见播种**全走这条路。
          ② **妖兽未知**(cid=NULL):`_handle_award` 的 `if is_new and cid:` 为假,
             连结算带预测一起跳过。
          ③ **首见播种**:回填 30 局后一条预测都没有 —— 新加的房要等第一次
             RoundAward 落地(最长一整局)才有预测号。

        链一断,`pending_prediction`(取 actual IS NULL 里 round_id 最大的那条)就
        再也取不到「下一局」的预测:它停在某条旧的未结算预测上,随后被
        `web._build_prediction` 的孤儿过滤(pend + ROUND_STEP <= latest)滤成
        `target_round_id: null` / `main: []` —— **前端预测号凭空消失**。

        用户真机 HAR 的指纹与此**逐项吻合**:14 次 /prediction 里 **12 次 main=[]**、
        target=null,而 `record`(判定记录)一直在推进 —— 即**结算正常,只是预测
        没生成**。这正是「只 settle 不 predict」的必然表象。

        ── 本函数 ────────────────────────────────────────────────────────────
        在上述路径末尾补齐缺失的那一条预测。幂等:已有即返回(一次主键点查,稳态
        下这就是全部开销);缺了才跑一次预测引擎。per-room 锁串行 + 锁内复查,与
        `_settle_and_predict` 共用同一把锁 —— Hedge 权重推进的顺序语义不受影响。
        返回同帧推送体(与 `_settle_and_predict` 的 `push["next"]` 同构),调用方
        经 SSE `pred-updated` 推给前端,不必等前端 predChase 追拉。
        """
        if not self.s.prediction.get("enabled", True):
            return None
        if await self._dormant(room):
            return None          # 3.4.5 策展闸 + 3.7.0 冷房:无实时消费者不跑预测引擎
        lr = await self.db.latest_round(room)
        if not lr:
            return None
        next_rid = int(lr["round_id"]) + ROUND_STEP
        if await self.db.has_prediction(room, next_rid):
            return None                       # 链完好 —— 稳态走这里,零开销
        async with self._room_locks[room]:
            if await self.db.has_prediction(room, next_rid):
                return None                   # 锁内复查:并发下别的协程可能已补
            kv = await self.db.load_predictor_kv(room)
            tw = float(self.s.prediction.get("train_window_hours", 24.0) or 0)
            since = now_ms() - int(tw * 3600 * 1000) if tw > 0 else None
            max_train = int(self.s.prediction.get("max_train", 5000))
            seq = await self.db.sequence(room, max_train, since)
            if not seq:
                return None                   # 一条已知妖兽的局都没有 → 无从预测
            loop = asyncio.get_running_loop()
            result, dirty = await loop.run_in_executor(
                None, self.bridge.run_prediction, room, seq, kv)
            await self.db.save_prediction(
                room, next_rid, result["main"], result["guard"],
                {"models": result["models"], "ens": result["ens"],
                 "explore": result.get("explore"),
                 "train_n": int(result.get("train_n") or 0)})
            self._warn_thin_train(room, result.get("train_n"), tw, max_train)
            if dirty:
                await self.db.save_predictor_kv(room, dirty)
            log.debug("[预测链] room=%s 补齐缺失预测 round=%s", room, next_rid)
            return {"target": str(next_rid), "main": list(result["main"]),
                    "guard": list(result["guard"]),
                    "why": ((result.get("explore") or {}).get("why") or "")}

    async def _push_next_prediction(self, room: str) -> None:
        """补链 + 推送(SSE pred-updated)。链完好时零开销、零推送。"""
        try:
            nxt = await self._ensure_next_prediction(room)
            if nxt:
                await self.bus.publish_draw(room, {
                    "type": "pred-updated", "roomId": room,
                    "roundId": nxt["target"], "pred": {"next": nxt}})
        except Exception as e:                        # noqa: BLE001
            # 补链失败不影响已入库数据与出怪推送;下一个事件(每局必有 mp/aw)自然重试
            log.warning("[预测链] room=%s 补链异常(不影响出怪): %s", room, e)

    async def _settle_only(self, room: str, round_id: int, actual_cid: int) -> None:
        """仅结算(= 旧 _after_round_recorded 的 announce=False 语义):
           若该局有 pending 预测则回填命中并推权重,不生成新预测。
           回填历史/漏局补齐覆盖到带预测的局时由此保证账目一致。

           注意:**本函数只结算不预测**是有意的(回填一页 30 局时不该跑 30 次预测
           引擎)。但"下一局预测"必须有人补 —— 由调用方在整页回填结束后调一次
           `_ensure_next_prediction`(见其文档:只 settle 不 predict 会打断预测链,
           前端预测号消失)。"""
        async with self._room_locks[room]:
            outcome = await self.db.fill_prediction_outcome(room, round_id, actual_cid)
            if outcome and outcome.get("first_time"):
                kv = await self.db.load_predictor_kv(room)
                loop = asyncio.get_running_loop()
                dirty = await loop.run_in_executor(
                    None, self.bridge.update_after_settle,
                    room, outcome.get("detail") or {}, actual_cid, kv)
                if dirty:
                    await self.db.save_predictor_kv(room, dirty)

    async def _settle_and_predict(self, room: str, round_id: int,
                                   actual_cid: int) -> Optional[Dict[str, Any]]:
        """结算上一局预测(命中回填 + Hedge 权重更新)并生成下一局预测。
           per-room 锁串行化,保证权重推进一致。predict 纯计算放线程池。
           3.3.5 返回「同帧判定」推送体(无预测/未结算则为 None):
             {"settled": {id,n,v}, "next": {target,main,guard}}
           调用方把它塞进出怪 SSE 载荷 —— 结算本就先于 publish,判定现成,
           前端得以让珠与主中/防中/未中同帧出现,消灭 ~1s 的「⋯」空档。"""
        push: Dict[str, Any] = {}
        next_write: Optional[tuple] = None      # 3.4.6:待原子写入的下一局预测
        async with self._room_locks[room]:
            kv = await self.db.load_predictor_kv(room)
            kv_writes: Dict[str, str] = {}

            # ① 只读窥视本局预测(拿 detail 与「是否首次结算」)+ 更新权重
            # 【3.4.6 原子换手】结算这个**写**动作被推迟到 ③,与「写入下一局预测」
            # 合成一个事务 —— 否则 ①(结算旧的)与 ③(写新的)之间,predictions 表里
            # 一条「未结算」的行都没有,pending_prediction 返回 None,前端拿到
            # target:null / main:[] → **四个数字显示成 `-`**(真机 HAR 实测 22% 命中,
            # 因为前端 predChase 恰在出怪到达那一刻拉取,精准撞窗)。详见
            # db.settle_and_save_prediction 的文档。
            prev = await self.db.peek_prediction(room, round_id)
            if prev:
                _m, _g = prev["main_ids"], prev["guard_ids"]
                _hit = ("main" if actual_cid in _m
                        else ("guard" if actual_cid in _g else "miss"))
                push["settled"] = {"id": str(round_id), "n": int(actual_cid),
                                   "v": _hit}
                if prev["first_time"]:
                    loop = asyncio.get_running_loop()
                    dirty = await loop.run_in_executor(
                        None, self.bridge.update_after_settle,
                        room, prev["detail"] or {}, actual_cid, kv)
                    kv_writes.update(dirty)
                    kv.update(dirty)

            # ② 生成下一局预测
            # 【3.4.5 策展闸】只为**用户真正在看的房**跑预测。自动发现的房数以千计、
            # 前端一个都不展示(_visible_rooms 恒过滤掉),为它们跑集成预测是纯浪费:
            # 真机实测每局预测管线 ≈5.5ms(db.sequence 拉 ~1727 行序列 1.8ms +
            # run_prediction 纯 CPU 3.7ms,后者持 GIL、不因线程池而并行)。
            # 6891 房 = 138 局/s → **预测独占 0.83 CPU 核、给 PG 灌 23.8 万行/s**,
            # 挤掉 consumer 的执行力 → 到期任务领不完(真机现场:10121 个到期未领、
            # 最老迟到 79.7s)→ 出怪/预测**系统性晚一整局**。产出的预测还没人看。
            # 关掉后:发现房只做「抓取+入库」(history 照常可查),用户一旦把某房加进
            # 名录(monitor/add → discovered_remove),下一局起自动恢复完整预测;
            # 且 _ensure_next_prediction 会立刻用已有历史补出预测号,零冷启动等待。
            if await self._dormant(room):
                pass                                   # 发现房/冷策展房:不跑预测引擎
            elif self.s.prediction.get("enabled", True):
                tw = float(self.s.prediction.get("train_window_hours", 24.0) or 0)
                since = now_ms() - int(tw * 3600 * 1000) if tw > 0 else None
                max_train = int(self.s.prediction.get("max_train", 5000))
                seq = await self.db.sequence(room, max_train, since)
                loop = asyncio.get_running_loop()
                result, dirty = await loop.run_in_executor(
                    None, self.bridge.run_prediction, room, seq, kv)
                kv_writes.update(dirty)
                next_rid = round_id + ROUND_STEP
                next_write = (next_rid, list(result["main"]), list(result["guard"]),
                              # explore 随 detail 入库:熔断局的「连败换血…」解释文案
                              # (explore.why)由 web._build_prediction 透出、推演卡渲染。
                              # update_weights 只读 detail["models"],多余键天然无害。
                              # train_n 同理(4.9.5):它是「训练窗/样本上限到底喂进去
                              # 多少局」的**实测值**,此前引擎算完即弃,全链路无人消费 ——
                              # 运维改完窗口没有任何一处能确认它真的生效。
                              {"models": result["models"], "ens": result["ens"],
                               "explore": result.get("explore"),
                               "train_n": int(result.get("train_n") or 0)})
                self._warn_thin_train(room, result.get("train_n"), tw, max_train)
                push["next"] = {"target": str(next_rid),
                                "main": list(result["main"]),
                                "guard": list(result["guard"]),
                                "why": ((result.get("explore") or {}).get("why") or "")}

            # ③ 【原子换手】同一事务:结算 round_id 的预测 + 写入 round_id+STEP 的新预测。
            #    读者(pending_prediction)因此永远看得到**恰好一条**未结算预测 ——
            #    要么是旧的(换手前),要么是新的(换手后),绝不会「两个都没有」。
            await self.db.settle_and_save_prediction(
                room, round_id, actual_cid,
                next_round=next_write[0] if next_write else None,
                main_ids=next_write[1] if next_write else None,
                guard_ids=next_write[2] if next_write else None,
                detail=next_write[3] if next_write else None)

            if kv_writes:
                await self.db.save_predictor_kv(room, kv_writes)
        return push or None

    # ── 覆盖哨兵:缺口驱动的 GameHistory 触发器(唯一的补漏校验机制) ──────────
    async def _coverage_check(self, room: str, head_rid: int,
                              inserted: Optional[int] = None,
                              snap: Optional[Dict[str, str]] = None) -> None:
        """维护快照水位线 covWm =「已确证 (本地入库 ∪ 官方缺失) **连续覆盖**到
        的格点」,并只在检出「真漏抓」时调用 GameHistory:

          · 快路径(稳态,占绝对多数):顺序出怪时水位纯 Redis 步进 —— covWm 覆盖
            到上一格,或上一格恰是上次入库的局(covLastIns 桥接静默区),直接推到
            本局。零 DB、零上游 —— **数据完整时 GameHistory 一次都不调用**。
          · 慢路径:只审计已出静默区(head−COV_AUDIT_LAG_ROUNDS 局,award 重试
            管线恒已终局)的格点:库里有 → 覆盖;∈ 官方缺失登记 → 覆盖(官方本身
            就没有,不该也不会再打);两者皆非 → 真漏抓 —— 过冷却闸后 GameHistory
            一次定案:补得回的入库,补不回的 = 官方历史页(固定近30局)亦无 →
            登记官方缺失(与 MainPage 漏局分支同一语义),水位越过,同一格点
            **绝不反复打**。
          · 任何一步失败(上游/DB/Redis)都只让水位原地不动,由下一个事件
            (每局必有的 mp/aw)自然重审 —— 哨兵挂在任务 ack 之后,自身永不抛错、
            不干扰抓取主链路。多 worker 并发时 covWm 可能被写回旧值:无害,
            至多让下一事件多审 1–2 个格点(审计只读、幂等),冷却闸兜住上游侧。
        """
        try:
            if head_rid <= 0:
                return
            if snap is None:
                wm_raw, li_raw = await self.bus.snap_mget(
                    room, "covWm", "covLastIns")
            else:
                wm_raw, li_raw = snap.get("covWm"), snap.get("covLastIns")
            try:
                wm = int(wm_raw or 0)
            except (TypeError, ValueError):
                wm = 0
            try:
                last_ins = int(li_raw or 0)
            except (TypeError, ValueError):
                last_ins = 0

            if inserted:
                # 快路径:本局刚入库是第一手证据,可越过静默区直推水位。
                if wm == inserted - ROUND_STEP or (
                        last_ins == inserted - ROUND_STEP
                        and wm >= inserted - 2 * ROUND_STEP):
                    await self.bus.set_snapshot(
                        room, {"covWm": inserted, "covLastIns": inserted})
                    return
                if inserted > last_ins:   # 单调:乱序/迟到的旧局不回拖桥接锚点
                    await self.bus.set_snapshot(room, {"covLastIns": inserted})

            safe = head_rid - COV_AUDIT_LAG_ROUNDS * ROUND_STEP
            if wm <= 0:
                # 起步/重生:默认(新房、或 DB 与 Redis 同灭的灾难重建)水位自静默区
                # 边界起算,更早的历史是播种界外、与新房同义,不追认。
                # 唯独「重生」(Redis 全量丢失但 **DB 幸存**:covWm 与 offmiss 登记
                # 同灭,而页窗内可能有掉电前确证过的官方缺点,重播种不含它、aw 任务
                # 已蒸发、漏局分支因 prev 丢失不触发 —— 真机 fuzz 种子 1005 实证的
                # 登记闭环缺口)值得回看:以「库中存在 ≤ 重播种页窗起点的任何数据」
                # 为重生判据 —— 库最老一局(oldest_round,每房一生一次
                # PK 前缀正向扫)存在即重生,水位落在 max(页窗起点, 库最老):
                # 年轻房间(寿命<页窗)的历史短于页窗,不能以「页窗起点前有无
                # 数据」判重生(fuzz 1005 打出缺口、1010 打出年轻房误判,双实证);
                # 回看下界夹到库最老,开房之前的「史前」不欠审计。命中后继续
                # 落入下方慢路径 —— 页窗全在库则零成本直推 safe;确有不可得点
                # 则经冷却闸一次调用重新确证登记(3.4.8 起重生走播种 DB 兜底、
                # 免打且**不占闸**,哨兵首个事件即可当场定案;若兜底探测失败退回
                # 真播种,则闸被播种占用,与旧行为同 —— 下一事件接手)。
                init_wm = safe - (COV_HIST_PAGE_ROUNDS - 1) * ROUND_STEP
                oldest = await self.db.oldest_round(room)
                if oldest is not None and oldest < safe:
                    wm = max(init_wm, oldest)
                    await self.bus.set_snapshot(room, {"covWm": wm})
                else:
                    if safe > 0:
                        await self.bus.set_snapshot(room, {"covWm": safe})
                    return
            if wm >= safe:
                return
            # 分窗推进:单事件最多审 COV_SPAN_CAP 个格点(界定单事件成本),水位只
            # 推到已审窗口末端 —— 停机深洞由后续事件逐窗接力(每 ≤35s 必有 mp),
            # 全部格点终将「入库 或 确证不可再取得」,不留永久未审计暗区
            # (页窗仅 30 局,深洞双模式都救不回;止损判据 = 登记后不复打)。
            audit_end = min(safe, wm + COV_SPAN_CAP * ROUND_STEP)
            pts = list(range(wm + ROUND_STEP, audit_end + 1, ROUND_STEP))
            missing = [g for g in pts if not await self.db.has_round(room, g)]
            if missing:
                off = set(await self.bus.official_missing_in(room, missing))
                missing = [g for g in missing if g not in off]
            if not missing:
                await self.bus.set_snapshot(room, {"covWm": audit_end})
                return
            # 页窗外免打:官方历史页固定近 COV_HIST_PAGE_ROUNDS 局且官方头恒 ≥
            # 本地头 —— 全部缺口都比 head−N 局更老时,上游**数学上不可达**,直接
            # 逐点确证登记(与漏局分支同一「不可再取得」语义),不打注定空手的请求。
            # (深洞分窗接力、删房重加/长期下播复播的远古水位追赶,都走这条零调用路。)
            if missing[-1] <= head_rid - COV_HIST_PAGE_ROUNDS * ROUND_STEP:
                log.warning("[哨兵] room=%s %d 个漏抓格点(自 %s)已出官方历史页窗,"
                            "免打直接登记「官方缺失」", room, len(missing), missing[0])
                for g in missing:
                    await self.bus.official_missing_mark(room, g)
                await self.bus.set_snapshot(room, {"covWm": audit_end})
                return
            # 真漏抓(库里无、亦未确证官方缺):冷却闸防并发双打/风暴后,一次定案。
            if not await self.bus.hist_gate(room, COV_HIST_COOLDOWN_MS):
                return           # 冷却中:水位不动,下一事件重审
            log.warning("[哨兵] room=%s 检出 %d 个漏抓格点(自 %s),GameHistory 补漏",
                        room, len(missing), missing[0])
            if not await self._backfill_history(room):
                return           # 上游失败:水位不动,下一事件重试
            for g in missing:
                if not await self.db.has_round(room, g):
                    await self.bus.official_missing_mark(room, g)
                    log.info("[官方缺失] room=%s round=%s 官方历史亦无此局,已登记",
                             room, g)
            await self.bus.set_snapshot(room, {"covWm": audit_end})
        except Exception as e:   # 哨兵永不干扰主链路;失败由下一事件自愈
            log.debug("[哨兵] room=%s 检查异常(下一事件重审): %r", room, e)

    async def _backfill_history(self, room: str,
                                stats: Optional[Dict[str, Any]] = None) -> bool:
        """GameHistory 回填。返回 True 表示上游有有效响应(含空列表 = 新房无历史;
        用于 seeded 判定)。stats(3.5.0,可选;默认 None,既有全部调用方零改动)
        由 hist-mode 轮询传入,回填页观测出参:page_len/page_head/page_oldest ——
        审计边界与页长自检的数据源。对齐旧 _backfill_history:
          · 未知妖兽照常入库(cid=None 不参与编号统计,不丢原始数据);
          · 新入库且 cid 有效的局做「仅结算」(announce=False 语义)——
            漏局补齐覆盖到带 pending 预测的局时,命中账目与权重不缺笔。

        写入改批量:先在内存里解析整页 gameList,再一次多行 INSERT ... RETURNING
        入库(替代旧的逐局 add_round 往返)。冷启动数千房回填时,单房从 ~40 次 PG
        往返降到 ~1 次,连接争用与写入延迟同步大降。只对**新插入**的局做结算。
        """
        if not await self.rl.acquire(max_wait_s=RL_MAX_WAIT_S):
            return False
        hist = await self.up.game_history(self.s.activity_id, room)
        if hist is None:
            return False
        # ① 解析整页到内存(不触库)
        parsed: List[dict] = []
        cid_by_rid: Dict[int, int] = {}
        for g in (hist.get("gameList") or []):
            try:
                rid = int(g.get("roundId", 0))
            except (TypeError, ValueError):
                continue
            if not rid:
                continue
            bi = g.get("beastInfo") or {}
            oid, name, cid, mult = self.bridge.resolve_beast(
                bi.get("beastId"), bi.get("beastName", ""))
            if oid is None and not (name and name != "?"):
                continue   # 官方 id 与名字皆无 → 无效行
            parsed.append({"round_id": rid, "official_id": oid,
                           "beast_name": name or "?", "custom_id": cid,
                           "multiplier": mult, "source": "history"})
            if cid:
                cid_by_rid[rid] = cid
        if stats is not None:                       # hist-mode 观测出参(3.5.0)
            rids = [g["round_id"] for g in parsed]
            stats["page_len"] = len(parsed)
            stats["page_head"] = max(rids) if rids else 0
            stats["page_oldest"] = min(rids) if rids else 0
        if not parsed:
            return True
        # ② 一次多行 INSERT,拿回真正新插入的 round_id(集合,用于成员判定)
        new_ids = set(await self.db.add_rounds_bulk(
            room, parsed, batch_size=self.s.admission.batch_size))
        # ③ 仅对新插入且 cid 有效的局做「仅结算」(命中回填 + 权重推进)。
        #    **按 gameList 顺序**结算(与旧逐局 add_round 版逐笔一致)—— 不依赖 PG
        #    RETURNING 的返回顺序(PG 不保证其等于 VALUES 顺序);漏局补齐覆盖到多个
        #    带 pending 预测的局时,Hedge 权重更新是顺序敏感的,顺序必须与旧版相同。
        for g in parsed:
            rid = g["round_id"]
            if rid in new_ids and cid_by_rid.get(rid):
                await self._settle_only(room, rid, cid_by_rid[rid])
        if new_ids:
            self._hist_ins_count += len(new_ids)    # 分钟统计的「回填入库」口径(3.5.0)
            log.info("[回填] room=%s GameHistory 入库 %d 局", room, len(new_ids))
            # 预测链自愈:`_settle_only` 只结算不预测(整页 30 局不该跑 30 次引擎),
            # 于是**每一条经回填落地的局都不会生成下一局预测** —— 预测链就此打断,
            # pending_prediction 取不到新预测 → 被孤儿过滤 → 前端 main=[]/target=null,
            # **预测号消失**(用户真机 HAR 实证)。整页回填结束后补一次即可:
            #   · 首见播种:回填 30 局后立刻就有预测号(旧行为要等第一次 RoundAward,
            #     最长一整局);
            #   · 出怪兜底/漏局补齐/覆盖哨兵:补回的局同样接上链。
            # 幂等,链完好时只是一次主键点查(见 _ensure_next_prediction)。
            await self._push_next_prediction(room)
        return True

    # ── hist-mode(3.5.0):后台发现房的 GameHistory 轮询状态机 ──────────────────
    async def _handle_hist(self, room: str, member: str) -> None:
        """`hs|room` 到期:后台发现房不打 MainPage/RoundAward,只按周期整页轮询
        GameHistory(近 30 局)批量入库。动机与账本见 settings.HistModeCfg 头注:
        发现房的实时产出没有任何实时消费者,万房稳态 430 req/s → 默认 T=900s
        ≈11 req/s(T=300s 时 ≈33)。

        状态机(每一步的到期都经同一 member 重排 = ack+重排一体,租约语义不变):
          稳态    成功 → 审计推水位 → 下次 = now + T + U(0, T/10)
          失败    退避 base×2^n 封顶 cap,**前瞻投影**(复查修正 B):若
                  「距上次成功年龄 + 本次退避」会越过 edge_after(距页窗越界
                  仅 ~2 局),改用 edge_retry 抢救节拍 —— 越窗前恒有 ~6 次机会
          票据过期 AuthExpired 按普通失败走退避(复查修正 C:不沿用 consumer 的
                  +5s 重排 —— 万房 401 期那是 2000 rps 的锤击;本路 90s 起步,
                  比既有 mp/aw 路径更收敛,且不触碰它们的行为)
          模式退出 转正/回滚 → 先做一次过闸的**收尾回填**把「上次轮询→此刻」的
                  尾窗当场封死(复查修正 A:收尾必须发生在改排 mp 之前,否则
                  永远轮不到),再有机切回实时管线。hs 成员串同名 —— 转正排的
                  hs@now 是移动既有任务而非新增,本分支每房恒只命中一次。

        令牌桶:_backfill_history 自带 rl.acquire(处理器不重复申领,防双扣);
        限流拿不到令牌 = backfill 返回 False = 普通失败,走退避。
        """
        nowv = now_ms()
        if not (self.s.histmode.enabled and await self._dormant(room)):
            await self.bus.ack(member)
            with contextlib.suppress(Exception):
                # 收尾回填「恰一次」:hs 成员串同名("hs|room"),ZADD 覆盖分数
                # 保证同房恒只有一个待办 hs —— web 转正排的 hs@now 是把既有稳态
                # 任务**移到现在**而非新增第二个,结构上本就只会命中本分支一次。
                # 幂等键 = 快照 histLastOkMs(该房确实轮询过,且封尾还没做过;
                # 成功即消费置 0)—— 特意**不用** lastok zset:那是健康指标,
                # 转正统一出口(discovered_remove 族)会先行清它,用它做键会把
                # 封尾静默跳过(复查抓出的自伤回归)。上游恰在此刻断供时键保留,
                # 病理性重排的下一发仍可补封;从未成功轮询过的房无尾可封,
                # mp 首拍播种自会补齐。转正场景封尾回填内的补链会立即生成预测号
                # (_ensure_next_prediction 的策展闸此刻已放行)—— 零冷启动等待。
                _lok_raw, = await self.bus.snap_mget(room, "histLastOkMs")
                try:
                    _had_polls = int(_lok_raw or 0) > 0
                except (TypeError, ValueError):
                    _had_polls = False
                if _had_polls and await self.bus.hist_gate(room, COV_HIST_COOLDOWN_MS):
                    _st: Dict[str, Any] = {}
                    if await self._backfill_history(room, stats=_st):
                        # 3.9.5:并入 lastError 清空 —— 封尾成功即数据链路健康,
                        # 唤醒瞬间不给 crawler_status 残留过期的 hist 失败原因
                        # (否则要等转正首拍 mp 成功才清)。失败路径不写,不误清真错。
                        _fields: Dict[str, Any] = {"histLastOkMs": 0,   # 消费封尾键
                                                   "lastError": ""}
                        if int(_st.get("page_head") or 0):
                            # 收尾页头写回 latestRoundId:status/管理台等被动读者
                            # 的口径即刻跟上(收尾已入库到页头,快照不该还指旧局)。
                            # 注:转正首拍 mp 的「漏局」自愈以 roundStartTimeMs 为锚
                            # (仿真 H4a 实证),经历过实时管线的房会因此多一发幂等
                            # GameHistory —— 那是实时管线对快照钟断档的正确反应,
                            # 人工低频且无放大,不压制(纯 hs 谱系的房 prev 为空,
                            # 恰 1 次封尾即毕)。
                            _fields["latestRoundId"] = int(_st["page_head"])
                        await self.bus.set_snapshot(room, _fields)
            await self.bus.hist_clear(room)
            with contextlib.suppress(Exception):
                # 3.7.0:冷标同为「模式退出即清」—— 唤醒主路(web._touch_room)
                # 已先清,这里覆盖其余退出路径(curated_idle/histmode 被关闭、
                # 唤醒清标那一步恰逢 Redis 抖动)。幂等 HDEL,不冷时零作用。
                await self.bus.cold_clear(room)
            await self.bus.schedule(task_mainpage(room),
                                    nowv + random.randint(0, 2000))
            return

        cfg = self.s.histmode
        interval_ms = effective_hist_interval_ms(cfg)
        last_raw, = await self.bus.snap_mget(room, "histLastOkMs")
        try:
            last_ok = int(last_raw or 0)
        except (TypeError, ValueError):
            last_ok = 0

        stats: Dict[str, Any] = {}
        ok = False
        auth_err = False
        try:
            ok = await self._backfill_history(room, stats=stats)
        except AuthExpired:
            ok = False
            auth_err = True

        if ok:
            head = int(stats.get("page_head") or 0)
            await self._hist_audit(room, head)
            # 3.9.5:成功即清 lastError(与 mp 成功路径同款字段卫生,零额外命令
            # —— 并入既有 HSET)。冷房/发现房的失败原因由此不会跨串残留。
            fields: Dict[str, Any] = {"histLastOkMs": nowv, "histFails": 0,
                                      "lastError": ""}
            if head:
                fields["latestRoundId"] = head     # 管理台/被动读者的口径跟上
            await self.bus.set_snapshot(room, fields)
            with contextlib.suppress(Exception):
                await self.bus.hist_mark_ok(room, nowv)
                # 页长自检(启发式):官方页窗若从 30 缩水,T 的安全推导随之失效。
                # 只在「页连续无洞仍短于 30 且非首拍」时计数(首拍/年轻房天然短页;
                # 页内官方缺失导致的短页不连续,不计)。状态页读 short_page 曲线,
                # 跨大量房持续增长才是窗缩水的信号,零星计数=新房噪声。
                plen = int(stats.get("page_len") or 0)
                oldest = int(stats.get("page_oldest") or 0)
                if (last_ok and head and oldest and 0 < plen < COV_HIST_PAGE_ROUNDS
                        and head - oldest == (plen - 1) * ROUND_STEP):
                    await self.bus.histmode_incr("short_page")
            due = nowv + interval_ms + random.randint(0, max(1, interval_ms // 10))
        else:
            fails = await self.bus.snap_incr(room, "histFails")
            # 3.9.5:失败原因落 lastError(与 _mp_fail_due 同款「每连败串恰一次」
            # 节流;成功路径清空)。冷策展房若真失联,名录『断』角标能报出票据/
            # 上游之别,而不是笼统一个"休"。
            if fails == 1:
                with contextlib.suppress(Exception):
                    await self.bus.set_snapshot(room, {
                        "lastError": ("上游 401/403:抓取票据(x-auth-ticket)可能已过期"
                                      if auth_err else
                                      "GameHistory 轮询失败(网络/上游异常)")})
            age = (nowv - last_ok) if last_ok else 0
            due = nowv + hist_retry_delay_ms(
                fails, age, cfg.retry_base_s * 1000, cfg.retry_cap_s * 1000,
                cfg.edge_after_s * 1000, cfg.edge_retry_s * 1000)
        await self.bus.schedule(member, due)

    async def _hist_audit(self, room: str, head: int) -> None:
        """成功轮询后的覆盖审计(hist-mode 版哨兵;covWm 语义与 _coverage_check
        完全同源 —— 转正后实时哨兵无缝接管同一水位,反向亦然):

          · 构造性覆盖:相邻两次**成功**轮询间隔 < 页窗 ⇒ 页页重叠 ⇒ 官方给出的
            每一局必然已入库;审计只需解释「格点不在库」的两种残因 ——
          · 页窗内缺格 = 官方缺失(整页在手仍没有 → 官方本身跳过这一局;判据与
            MainPage 漏局分支「补齐成功后仍缺才登记」逐字相同);
          · 页窗外缺格 = **越窗丢失**(轮询间隔一度超过页窗,数学上不可再取得)——
            登记语义与既有 S6「页窗外免打直登」一致,另计 stats:histmode 的
            window_lost 并打 WARNING:丢了就大声说,绝不静默。

        失败路径不进本函数(I3 原则:失败绝不构成证据,确证只在成功页上做)。
        单次审计格点数受 COV_SPAN_CAP(200)界定,深洞由后续轮询逐窗接力;
        任何异常只让水位原地不动,下次成功轮询自然重审,绝不干扰轮询主链。
        """
        try:
            if head <= 0:
                return
            wm_raw = await self.bus.snap_get(room, "covWm")
            try:
                wm = int(wm_raw or 0)
            except (TypeError, ValueError):
                wm = 0
            if wm <= 0:
                # 首拍:义务窗自本页起(播种界外与新房同义,与实时播种口径一致)
                await self.bus.set_snapshot(room, {"covWm": head})
                return
            if wm >= head:
                return
            win_start = head - (COV_HIST_PAGE_ROUNDS - 1) * ROUND_STEP
            audit_end = min(head, wm + COV_SPAN_CAP * ROUND_STEP)
            pts = list(range(wm + ROUND_STEP, audit_end + 1, ROUND_STEP))
            missing = [g for g in pts if not await self.db.has_round(room, g)]
            if missing:
                off = set(await self.bus.official_missing_in(room, missing))
                missing = [g for g in missing if g not in off]
            lost = [g for g in missing if g < win_start]
            for g in missing:
                await self.bus.official_missing_mark(room, g)
            if lost:
                await self.bus.histmode_incr("window_lost", len(lost))
                log.warning("[hist] room=%s 越窗丢失 %d 局(%s..%s):轮询间隔一度"
                            "超过官方页窗(近 %d 局 ≈%.0fs),已登记「官方缺失」"
                            "止损、绝不复打;请检查上游/网络,或调小 "
                            "histmode.interval_s", room, len(lost), lost[0],
                            lost[-1], COV_HIST_PAGE_ROUNDS,
                            COV_HIST_PAGE_ROUNDS * ROUND_STEP / 1000.0)
            await self.bus.set_snapshot(room, {"covWm": audit_end})
        except Exception as e:
            log.debug("[hist] room=%s 审计异常(下次成功轮询重审): %r", room, e)

    def _round_obj(self, room, round_id, cid, oid, name, mult) -> dict:
        """SSE 推送用回合对象 —— 逐字段对齐旧 round_from_cid(前端九法阵珠子
        依赖 spell_key/spell_name;captured_at 为北京时间 ISO,代码钉死不随时区漂移)。"""
        start = int(round_id)
        meta = (BEAST_BY_CID.get(int(cid)) if cid is not None else None) or {}
        return {
            "round_id": str(start),
            "beast_id": oid if oid is not None else meta.get("beast_id"),
            "beast_name": name or meta.get("beast_name", ""),
            "spell_key": meta.get("spell_key", ""),
            "spell_name": meta.get("spell_name", ""),
            "display_number": int(cid) if cid is not None else meta.get("display_number"),
            "multiplier": mult if mult is not None else meta.get("multiplier"),
            "start_time_ms": start, "spell_time_ms": start + SPELL_OFFSET_MS,
            "draw_time_ms": start + DRAW_OFFSET_MS, "end_time_ms": start + END_OFFSET_MS,
            "source": "RoundAward",
            "captured_at": _iso_local(start + DRAW_OFFSET_MS + 2000),
        }

    # ── janitor:自愈。给「活跃但队列里没有任何未来任务」的房补一个 mp 起点。 ────
    async def _janitor(self) -> None:
        while self._running:
            # 循环内现读:janitor_interval_s 经配置中枢热更,下一周期生效
            interval = self.s.scheduler.janitor_interval_s
            # 秒级步进睡眠:SIGTERM 后 ≤1s 感知退出(整段 sleep(interval) 会把
            # 优雅停机拖满一个周期,docker 默认宽限期内走不到 close())
            for _ in range(max(1, int(interval))):
                if not self._running:
                    return
                await asyncio.sleep(1)
            try:
                active = set(await self.bus.active_rooms())
                scheduled = await self.bus.scheduled_rooms()
                missing = active - scheduled
                if missing:
                    nowv = now_ms()
                    # 打散重新播种,避免一次性把缺失房全排在同一毫秒。
                    # 3.4.8 窗口随规模自适应:旧 `(i*25)%3000` 把任意规模都环形叠进
                    # 3s —— 正常运维(零星几个房丢任务)没问题,但「名录幸存、调度
                    # ZSET 大面积丢失」的边缘场景(回灌半失败/误删/非默认驱逐策略)下,
                    # 万房 ≈(1 次 mp + 掉快照时 1 次播种 hist)/房挤 3s,与批量准入
                    # (20s→60s 已入档的算术)/boot 回灌(schedule_spread 60s)的同类
                    # 场景口径不一致。改用同一载体 schedule_spread:
                    #   window = min(warmup_window_ms, n×25ms)
                    # n≤120 时 n×25 ≤ 3000,逐毫秒**等价于旧式**(取模本就不生效,
                    # i*25 与 i*span//n 同值)—— 常态零变化;大面积丢失才铺宽,
                    # 60s 封顶,形状与批量准入/boot 完全对齐。幂等:多副本 janitor
                    # 并发补排是 ZADD 覆盖 score,与旧行为同。
                    # hist-mode(3.5.0):启用时发现房的自愈起点应是 hs 轮询任务
                    # 而非 mp —— 否则补进来的 mp 下一拍又被迁移入口改排一次
                    # (多绕一圈、并把首拍相位挤回 3s 窗)。禁用时逐字节走老路。
                    hs_rooms: set = set()
                    if self.s.histmode.enabled:
                        with contextlib.suppress(Exception):
                            hs_rooms = missing & set(
                                await self.bus.discovered_members())
                        # 3.7.0:冷策展房丢任务时,自愈起点同为 hs(它在目标态
                        # 就该被轮询;补 mp 会让迁移入口多绕一圈)。开关关闭时
                        # 冷标惰性,照旧补 mp —— 回实时正是关闭后的正确方向。
                        if getattr(self.s.histmode, "curated_idle_enabled", False):
                            with contextlib.suppress(Exception):
                                hs_rooms |= missing & set(
                                    await self.bus.cold_members())
                    mp_missing = missing - hs_rooms
                    if mp_missing:
                        window = janitor_spread_window(
                            len(mp_missing), self.s.admission.warmup_window_ms)
                        await self.bus.schedule_spread(
                            [task_mainpage(r) for r in sorted(mp_missing)],
                            nowv, window)
                        log.info("janitor 为 %d 个房补排 MainPage 起点(窗 %dms)",
                                 len(mp_missing), window)
                    if hs_rooms:
                        # 满窗铺开(复查修正 D):相位均匀是本模式错峰的根基;
                        # 「调度 ZSET 大面积丢失」场景下万房挤 60s 窗 = 每 T
                        # 一次 167/s 梳齿,满窗后恒定 ≈N/T。
                        await self.bus.schedule_spread(
                            [task_hist(r) for r in sorted(hs_rooms)],
                            nowv, effective_hist_interval_ms(self.s.histmode))
                        log.info("janitor 为 %d 个 hist-mode 房补排轮询起点"
                                 "(满窗铺开)", len(hs_rooms))

                # ── curated-idle(3.7.0):空闲策展房降级扫描 ──────────────────
                # 挂 janitor 而非 discovery.reconcile —— 后者在 discovery.enabled
                # =false(纯策展部署,README §5 明示存在)时整条不跑,降级将永久
                # 失效;janitor 无条件运行。跨副本 SET NX EX=60 互斥兼节拍
                # (全舰队 ≤1 次/分钟);shadow 只观测。详见 _curated_idle_sweep。
                with contextlib.suppress(Exception):
                    await self._curated_idle_sweep(active)

                # 分钟级聚合统计(运营脉搏):替代逐局 INFO(已降 DEBUG)。万房规模
                # 下这里是唯一的稳态高层日志:1 行/分钟,而非 ~200 行/秒。
                elapsed = time.monotonic() - self._stats_last
                if elapsed >= 60:
                    n, self._award_count = self._award_count, 0
                    hn, self._hist_ins_count = self._hist_ins_count, 0
                    self._stats_last = time.monotonic()
                    await self._emit_ingest_stats(
                        n=n, elapsed=elapsed, active=active, hist_ins=hn)

                # 挂起短号周期重试归一(对齐旧 _resolve_loop;canon 60s 负缓存限频,
                # 不会打爆繁星)。成功即转正:入名录 + 落 PG + 排即时 MainPage。
                # 超龄(>24h 仍归一不成,多为无效房号)自动放弃并清净,避免永久占位。
                for alias, since in (await self.bus.pending_items()).items():
                    if since and now_ms() - since > 24 * 3600 * 1000:
                        await self.bus.pending_remove(alias)
                        await self.db.upsert_room(alias, alias, False, pending=False)
                        log.warning("挂起房 %s 超过 24h 仍无法归一(疑无效房号),已放弃", alias)
                        continue
                    try:
                        rid, definitive = await self.star.canon(alias)
                    except Exception:
                        continue
                    if not definitive:
                        continue
                    await self.bus.add_room(rid, alias)
                    await self.db.upsert_room(rid, alias, True, pending=False)
                    # 转正入口一致性:该真实号若恰是当前被自动发现的在播房,清净其
                    # 发现态(Redis 发现集 + PG 时钟残行)—— 与 web add/add-bulk/
                    # config 注入/seed_rooms 四条入口同一不变式:**手动来源的房转正
                    # 即前端可见**,不等 reconcile 自愈(否则最长隐藏一个发现周期)。
                    with contextlib.suppress(Exception):
                        await self.bus.discovered_remove(rid)
                        await self.db.discovered_delete_bulk([rid])
                    if rid != alias:
                        await self.db.upsert_room(alias, alias, False, pending=False)
                    await self.bus.pending_remove(alias)
                    _hm = self.s.histmode
                    if _hm.enabled and getattr(_hm, "curated_idle_enabled", False):
                        with contextlib.suppress(Exception):
                            # curated-idle(3.7.0):归一目标恰为既有冷策展房的边界
                            # —— 转正语义 =「用户要监控」,冷标当场清 + 访问戳 GT
                            # 置新,否则下方 mp@now 会被迁移入口按冷房改排回轮询,
                            # 违背「监控开始」的书面语义(复审 G1;新房两调皆无害
                            # 幂等)。双开关门:禁用态零新增命令(web 单加同款)。
                            await self.bus.touch_rooms([rid], now_ms())
                            await self.bus.cold_clear(rid)
                    await self.bus.schedule(task_mainpage(rid), now_ms())
                    if self.s.histmode.enabled:
                        # hist-mode 转正封尾:与 web 单加同级秒级(键消费恰一次/
                        # 无键自跳;默认 T=900 后有机封尾要等 ≤16.5 分钟)。
                        with contextlib.suppress(Exception):
                            await self.bus.schedule(task_hist(rid), now_ms())
                    log.info("挂起房 %s 已归一为真实房 %s,监控开始", alias, rid)
            except Exception as e:
                log.error("janitor 异常: %r", e)

    async def _curated_idle_sweep(self, active: set) -> None:
        """空闲策展房降级扫描(curated-idle,3.7.0;janitor 每拍尝试,
        SET NX EX=60 跨副本互斥兼节拍 → 全舰队 ≤1 次/分钟)。

        判闲双信号,方向极度不对称(误降是对「用户在看的房必须实时」这条
        核心价值的回归 —— 宁可漏降,绝不误降):
          ① 年龄:rooms:lastaccess 最近访问距今 ≥ curated_idle_after_s;
             无记录(Redis 重启/首次启用/新房)→ 只 ZADD NX 播种,本轮绝不
             判闲(年龄未知不降级,纯函数 curated_idle_split 承载,可单测);
          ② 观众守卫:draws:{room} 当前订阅数 >0(有人开着直播视图)一票
             否决;NUMSUB 查询失败 → 视同有人在看,本轮放弃全部降级。
        shadow=true:仅把结果写 stats:histmode(cold_would / cold_would_ts /
        cold_would_sample)供状态页 curatedIdle 块核对;enforce:HSETNX 冷标
        → 各房**下一拍 mp**(≤50s,相位天然铺开)经既有 3.5.0 迁移入口有机
        改排轮询(首拍再叠 U(0,T) 满窗抖动)—— 本方法不直接排任何任务,
        零新迁移机器,结构上无风暴;batch 只是「整夜集体空闲」的额外削峰。

        双开关任一关闭:仅在锁内做冷标自愈(清残留 —— 标本身对闸已惰性,
        见 _dormant;其 hs 任务会撞 _handle_hist 退出分支自行封尾切回),
        从未开启过则第一步即返回,禁用态锁外零 Redis 命令(契约⑪ 姿态)。"""
        hm = self.s.histmode
        ci_on = bool(hm.enabled and getattr(hm, "curated_idle_enabled", False))
        if not ci_on and not self._ci_was_on:
            return
        if not await self.bus.cold_sweep_try_lock(60):
            return
        if not ci_on:
            stale = await self.bus.cold_members()
            if stale:
                await self.bus.cold_clear_bulk(sorted(stale))
                log.info("curated-idle 已关闭:清残留冷标 %d 房(其轮询任务将"
                         "于下一拍撞退出分支自行封尾切回实时)", len(stale))
            with contextlib.suppress(Exception):
                # gauge 同步归零(复审 j):stats:histmode 七天 TTL,不清则状态页
                # 会在 enabled:false 旁挂着上一开启期的陈旧 wouldDemote —— 关断
                # 清理是它唯一的诚实出口(累计计数 demotes/promotes 保留为史)。
                await self.bus.histmode_set({
                    "cold_would": 0, "cold_would_ts": now_ms(),
                    "cold_would_sample": "[]"})
            self._ci_was_on = False
            return
        self._ci_was_on = True
        nowv = now_ms()
        try:
            discovered = set(await self.bus.discovered_members())
        except Exception:
            return                        # 判不出策展边界:本轮放弃(保守)
        cold = await self.bus.cold_members()
        with contextlib.suppress(Exception):
            # 台账卫生(锁内顺手,均由扫描锁限频 ≤1 次/分钟/舰队;放在
            # curated 空判**之前** —— 全发现房部署里用户直连留下的访问戳
            # 与理论不可达的脱册冷标同样要有出口):
            # ① 访问戳修剪:清不在活跃全集里的残项(SSE 首帧按未归一短号
            #    先行 touch 的那一拍、已删房号的直连请求 —— 僵尸项纪律);
            # ② stray 冷标自愈:cold ⊆ 活跃策展是删房/回收路径维护的不变量,
            #    理论不可达,这里纯防御(出现即说明有路径漏清,日志留证)。
            pruned_la = await self.bus.last_access_prune(active)
            stray = cold - set(active)
            if stray:
                await self.bus.cold_clear_bulk(sorted(stray))
                cold -= stray
                log.warning("curated-idle 清除 %d 个脱册冷标(不变量防御,"
                            "正常不应出现): %s", len(stray),
                            ",".join(sorted(stray)[:5]))
            if pruned_la:
                log.info("curated-idle 修剪访问戳残项 %d 条", pruned_la)
        curated = sorted(set(active) - discovered)
        if not curated:
            return
        after_ms = max(300, int(getattr(hm, "curated_idle_after_s", 1800) or 1800)) * 1000
        to_seed, cands = curated_idle_split(
            nowv, curated, await self.bus.last_access_map(curated), cold, after_ms)
        if to_seed:
            await self.bus.touch_rooms_nx(to_seed, nowv)
        would: List[str] = []
        if cands:
            try:
                subs = await self.bus.draw_subscribers(cands)
            except Exception as e:
                log.warning("curated-idle 观众守卫(PUBSUB NUMSUB)查询失败(%r):"
                            "视同有人在看,本轮放弃降级", e)
                return
            would = [r for r in cands if int(subs.get(r, 0) or 0) == 0]
        would = would[:max(1, int(getattr(hm, "curated_idle_batch", 200) or 200))]
        with contextlib.suppress(Exception):
            # 影子/实降共用的观测台账:每轮全量覆写(含空轮),陈旧 gauge 不撒谎。
            await self.bus.histmode_set({
                "cold_would": len(would), "cold_would_ts": nowv,
                "cold_would_sample": json.dumps(would[:20])})
        if bool(getattr(hm, "curated_idle_shadow", True)) or not would:
            return
        await self.bus.mark_cold_bulk(would, nowv)
        with contextlib.suppress(Exception):
            await self.bus.histmode_incr("cold_demote", len(would))
        log.info("curated-idle 降级 %d 个空闲策展房(访问年龄 ≥%ds 且零订阅;"
                 "各房下一拍 mp 有机改走轮询):%s%s", len(would),
                 after_ms // 1000, ",".join(would[:10]),
                 " …" if len(would) > 10 else "")

    async def _emit_ingest_stats(self, *, n: int, elapsed: float,
                                 active: set, hist_ins: int = 0) -> None:
        """janitor 的分钟级运营脉搏(3.4.2 上墙;3.4.7 增全舰队口径)。

        从 _janitor 原样搬出以便独立测试(tests/test_stats_fleet.py):除
        fleet_* 聚合为新增外,legacy 字段、日志与三项体检(积压/钟偏/PG 饥饿)
        的行为与搬出前逐行相同(含 pg 饥饿告警引用 need 的既有姿态)。
        """
        # ── 到期积压:本系统最重要的健康指标(3.4.2 起上墙 + 告警) ──────
        # 此前它**在任何地方都不可见**(日志/status/管理台皆无),于是
        # 「worker 算力不足」这种最常见的故障只能表现为前端症状,却查不到根因。
        backlog, lag_ms = await self.bus.sched_backlog()
        # ── hist-mode 口径(3.5.0;仅启用时求值,禁用逐字节走老路) ──────────
        # 加权负载:hist 房每 T 才一个事件,按事件率折算等效实时房 —— 否则万房
        # 启用后 need 仍按 1 万实时房算,建议副本虚高 3 副本(算力体检撒谎)。
        hist_n = 0
        eff_load = len(active)
        if self.s.histmode.enabled:
            with contextlib.suppress(Exception):
                hist_n = len(await self.bus.discovered_members())
            if getattr(self.s.histmode, "curated_idle_enabled", False):
                with contextlib.suppress(Exception):
                    # 3.7.0:冷策展房同为轮询节奏,计入 hist 桶(否则等效负载
                    # 按实时口径虚高,建议副本数撒谎 —— 与发现房同一笔账)。
                    hist_n += len(await self.bus.cold_members())
            eff_load = weighted_fleet_load(
                len(active) - hist_n, hist_n,
                effective_hist_interval_ms(self.s.histmode) / 1000.0)
        # ── 全舰队口径(3.4.7):下方 per_min/rate 是**本副本**窗口计数;多副本
        # 对同一 hash 覆盖写,读者只能看到"最后写入的那个副本" —— 曾把 10 副本
        # 舰队的入库率读低一个数量级,酿成「92.6% 靠回填」误判(AUDIT §18,
        # 2 副本真机实证恰 2.00×)。各副本先把窗口计数写进子哈希,聚合出
        # fleet_* 随 legacy 字段一并落盘;legacy 字段语义不动(仍为本副本值)。
        fleet_map: Dict[str, Any] = {}
        with contextlib.suppress(Exception):
            await self.bus.r.hset(
                "stats:ingest:replicas", self._stats_wid,
                json.dumps({"ts_ms": now_ms(), "per_min": n,
                            "rate": round(n / elapsed, 3) if elapsed else 0}))
            await self.bus.r.expire("stats:ingest:replicas", 300)
            entries = await self.bus.r.hgetall("stats:ingest:replicas")
            fleet_map, _stale = aggregate_fleet_ingest(entries, now_ms())
            if _stale:
                await self.bus.r.hdel("stats:ingest:replicas", *_stale)
        with contextlib.suppress(Exception):
            await self.bus.r.hset("stats:ingest", mapping={
                "ts_ms": now_ms(), "per_min": n,
                "rate": round(n / elapsed, 3) if elapsed else 0,
                "active": len(active),
                "backlog": backlog, "backlog_lag_ms": lag_ms,
                # hist-mode 观测字段(3.5.0;附加,读者可忽略):
                #   hist_rooms 当前发现房数(=轮询舰队规模)
                #   hist_per_min 本副本窗口内经 GameHistory 回填入库的局数
                #   effective_rooms 加权等效实时房数(体检口径)
                "hist_rooms": hist_n, "hist_per_min": hist_ins,
                "effective_rooms": eff_load,
                **fleet_map})
            await self.bus.r.expire("stats:ingest", 180)
        if n or hist_ins or fleet_map.get("fleet_per_min"):
            hist_seg = ""
            if self.s.histmode.enabled:
                age_s = -1.0
                with contextlib.suppress(Exception):
                    item = await self.bus.hist_oldest()
                    if item:
                        age_s = max(0.0, (now_ms() - item[1]) / 1000.0)
                _age_txt = ("%.0fs 前" % age_s) if age_s >= 0 else "—"
                hist_seg = (" · hist轮询 %d 房(回填入库 %d 局,最老成功 %s)"
                            % (hist_n, hist_ins, _age_txt))
            log.info("统计:近 %.0fs 本副本入库 %d 局(≈%.1f 局/s)· 全舰队"
                     " ≈%.1f 局/s(%s 副本上报)· 活跃 %d 房"
                     " · 到期积压 %d(最老迟 %.1fs)%s",
                     elapsed, n, (n / elapsed) if elapsed else 0.0,
                     fleet_map.get("fleet_rate", 0.0),
                     fleet_map.get("replicas_reporting", 1),
                     len(active), backlog, lag_ms / 1000.0, hist_seg)
        # 算力不足 → 抓取被整体推迟 → 前端「出怪晚一局 + 预测滞后/消失」。
        # 数据不会丢(coverage 仍 complete),所以**只看数据完整性是查不出来的**,
        # 必须看这里。告警直接给出解法,不让运维再猜。
        if lag_ms > BACKLOG_LAG_WARN_MS:
            need = max(2, math.ceil(eff_load / ROOMS_PER_REPLICA) + 1)
            log.warning(
                "⚠ worker 算力不足:到期积压 %d 个任务,最老已迟到 %.0fs"
                " —— 抓取被整体推迟,前端会看到「出怪倒计时结束、下一局都开跑了"
                "才显示上一局」以及预测滞后/消失(数据不丢,只是系统性地晚)。"
                " 当前监控 **%d 房**(含自动发现的 7 天留存房);实测每副本"
                " ≈%d 房 → 建议 `--scale worker=%d`(硬顶 11,见 README §5.1),"
                "或调小 discovery.prune_grace_s 收敛舰队规模。",
                backlog, lag_ms / 1000.0, len(active),
                ROOMS_PER_REPLICA, need)

        # ── 钟偏体检(3.4.3)─────────────────────────────────────────
        # 3.4.3 之前,本机钟与游戏服务器钟不同步会让出怪重试阶梯整体偏移
        # (round_id 是服务器时间戳,却被当本机钟的 ZSET 到期分数用)——
        # 本机钟慢 N 秒 → 每局出怪晚 N 秒,表现为「倒计时结束、下一局都开跑了
        # 才显示上一局」。现已换算回本机钟域,**抓取不再受钟偏影响**;
        # 但大钟偏仍说明主机 NTP 有问题,显式喊出来。
        with contextlib.suppress(Exception):
            _skews = []
            for _r in list(active)[:20]:      # 抽样即可,不遍历全舰队
                _sk = _snap_server_offset(await self.bus.get_snapshot(_r))
                if _sk:
                    _skews.append(_sk)
            if _skews:
                _skews.sort()
                _med = _skews[len(_skews) // 2]
                await self.bus.r.hset("stats:ingest",
                                      "clock_skew_ms", int(_med))
                if abs(_med) > CLOCK_SKEW_WARN_MS:
                    log.warning(
                        "⚠ 本机钟与游戏服务器钟相差 %.1fs(服务器%s本机)——"
                        "请给宿主机开启 NTP 校时(如 `timedatectl set-ntp true`)。"
                        "3.4.3 起抓取已按实测钟差换算、**不再因此变晚**,但大钟偏"
                        "会让日志时间戳与人工排障错乱,且说明主机配置有问题。",
                        _med / 1000.0, "快于" if _med > 0 else "慢于")

        # ── PG 侧饥饿体检(3.4.4)────────────────────────────────────
        # Redis 积压=0 ≠ 健康:副本扩到连接账本外(每副本≈池 32 连接,
        # 硬顶 ⌊(max_connections−35)/32⌋)时 pool.acquire 无限期排队,
        # 任务「按时被领、执行中卡死」:出怪入库散布局内 41~70s、
        # 结算→预测再拖 3~40s、/prediction 出现十几秒 null(真机实证,
        # 16 副本 × 32 = 547 > 400 的现场)。探针=取连接+SELECT 的耗时,
        # 即业务每次 PG 调用的入场费;>1s = 饥饿实锤。
        with contextlib.suppress(Exception):
            _pg = await self.db.pg_health_probe()
            await self.bus.r.hset("stats:ingest", mapping={
                "pg_ping_ms": int(_pg.get("ping_ms", -1)),
                "pg_used": int(_pg.get("used", -1)),
                "pg_max": int(_pg.get("max_conn", -1))})
            if _pg.get("saturated"):
                _cap = ((_pg["max_conn"] - 35) // 32
                        if _pg.get("max_conn", 0) > 0 else 11)
                log.warning(
                    "⚠ PG 连接饥饿:探针耗时 %sms,连接 %s/%s —— 每副本"
                    "≈32 连接,当前 max_connections 下硬顶 %d 副本;超账本时"
                    "任务按时被领却在 PG 排队执行,出怪入库散布局内 40~70s、"
                    "预测出现长 null 空窗(前端=「出怪晚一局+预测消失」,"
                    "而 Redis 积压恒 0)。请降副本(本舰队按算力只需 %d)"
                    "或调大 max_connections。",
                    _pg.get("ping_ms"), _pg.get("used"),
                    _pg.get("max_conn"), _cap, need)

    # ── retention:滚动裁剪每房历史,默认保留最近 N 天(见 settings.retention)。──
    #    多 worker 副本共存时经 Redis `SET NX EX=周期` 互斥:锁即节拍,同一周期
    #    全局恰好清一次;days<=0 关闭清理(永久保留,旧行为)。
    async def _retention(self) -> None:
        # live-config 循环:days/interval/batch 每轮现读 —— 配置中枢可热切
        # 「关闭↔启用」与各参数,无需重启(days≤0 时 idle continue 而非 return)。
        check_every = 60          # 每分钟醒一次;启用且抢到锁才真正清理
        announced = None          # 去重:仅在「开/关」状态翻转时打一条 info
        twh_warned = False        # 训练窗护栏:仅在「进入违规」时告警一次(热调小会重警)
        while self._running:
            for _ in range(check_every):
                if not self._running:
                    return
                await asyncio.sleep(1)
            cfg = self.s.retention
            if cfg.days <= 0:
                if announced != "off":
                    log.info("retention 关闭(days<=0):历史数据永久保留")
                    announced = "off"
                twh_warned = False
                continue
            if announced != "on":
                log.info("retention 启用:每房保留最近 %.3g 天,巡检周期 %ds,单批 %d 行",
                         cfg.days, max(60, int(cfg.sweep_interval_s)), cfg.batch_rows)
                announced = "on"
            # 护栏:保留窗口不应短于预测训练窗口(样本被截短→预测静默劣化);只告警。
            # 仅在「首次违规」时打一次,避免每分钟刷屏;条件解除后重新武装(热调小会重警)。
            twh = float((self.s.prediction or {}).get("train_window_hours", 24.0) or 0)
            violated = 0 < cfg.days * 24 < twh
            if violated and not twh_warned:
                log.warning("retention.days=%.3g 天(=%.1f 小时) 小于预测训练窗口 "
                            "train_window_hours=%.0f 小时:训练可用数据将被保留窗口截短",
                            cfg.days, cfg.days * 24, twh)
                twh_warned = True
            elif not violated:
                twh_warned = False
            interval = max(60, int(cfg.sweep_interval_s))
            try:
                if not await self.bus.retention_try_lock(interval):
                    continue        # 本周期已有副本负责(或刚清过),下分钟再探
                cutoff = retention_cutoff_ms(now_ms(), cfg.days)
                t0 = time.monotonic()
                stat = await self.db.purge_before(
                    cutoff, cfg.batch_rows, cfg.max_batches,
                    stop=lambda: not self._running)   # SIGTERM 批间即停,不拖停机
                info = {"ts_ms": now_ms(), "ts": _iso_local(now_ms()),
                        "cutoff_ms": cutoff, "cutoff": _iso_local(cutoff),
                        "days": cfg.days, "rounds": stat.get("rounds", 0),
                        "predictions": stat.get("predictions", 0),
                        "capped": stat.get("capped", 0),
                        "elapsed_s": round(time.monotonic() - t0, 3),
                        # 5.4.0:web 侧「储」视图据此判停摆 —— 用 worker 自己生效的周期,
                        # 不用 web 进程那份配置(sweep_interval_s 只被 worker 消费,两边可能不同)
                        "interval_s": interval}
                await self.bus.retention_set_last(info)
                if info["rounds"] or info["predictions"]:
                    log.info("retention 清理完成:rounds=%d predictions=%d "
                             "cutoff=%s 耗时 %.2fs%s",
                             info["rounds"], info["predictions"], info["cutoff"],
                             info["elapsed_s"],
                             "(达批数护栏,余量下周期续删)" if info["capped"] else "")
            except Exception as e:
                log.error("retention 异常: %r", e)

    # ── 命中率补算(4.6.0):把策展房窗口里缺的判定按生产同一条路径因果补齐 ──────
    #
    #    【为什么是独立协程,而不是一个新任务类型】
    #    最初的设计是排一个 `rp|room` 延迟任务。**实地核查后否决**:
    #    `bus.scheduled_rooms()` 读的是反向索引 `sched:rooms`(见 redis_bus),
    #    janitor 用 `missing = active - scheduled` 自愈 MainPage 排程 —— 一个只
    #    排着 rp 任务的房会被误判「已在排」,从而**永久失去 mp 自愈**,静默丢数据。
    #    改用后台协程后与延迟队列零交集,janitor 不变式完好;跨副本互斥/节拍
    #    与 retention 同款(SET NX EX=巡检周期,锁即节拍,不解锁不心跳)。
    #
    #    【CPU 闸门三层】
    #      ① 跨副本锁:全舰队同一周期只有一个副本在算;
    #      ② replay_batch:每周期最多为 N 个房跑补算(默认 8,单房 ≈2.4s 真机实测);
    #      ③ 每房冷却闸:抢到才值得查 PG。稳态下全部房握闸 ⇒ 本协程的开销
    #         收敛为「一次 SMEMBERS + 零 SQL」。
    #
    #    【只补算策展热房】发现房与冷策展房没有实时消费者(_dormant),给它们补算
    #    等于把 3.4.5 策展闸省下来的算力原样还回去 —— 判据与预测闸严格同源。
    async def _pred_replay(self) -> None:
        announced = None
        while self._running:
            interval = max(5, int((self.s.prediction or {})
                                  .get("replay_interval_s", 60) or 60))
            for _ in range(interval):
                if not self._running:
                    return
                await asyncio.sleep(1)
                # 4.9.3 唤醒快道排水:转正/冷房唤醒的房逐秒 SPOP 即时补算,
                # 用户打开推演卡数秒内「近N局」补满(节拍 ≤1s + 单房 ≈2.4s),不必等 60s 巡检
                # (更不必撞残留冷却闸再等 1h)。SPOP 原子 ⇒ 多副本不重不漏;
                # 本副本正在跑 _replay_sweep 时暂停排水(循环互斥),其余副本
                # 照常接手 —— 单副本部署最坏晚一个 sweep 时长(默认 ≈19s)。
                # 排水每拍 ≤2 房、逐房串行(引擎占时时本拍顺延,不并发烧 CPU),
                # 人类节奏的唤醒风暴天然被抹平。
                with contextlib.suppress(Exception):
                    await self._replay_wake_drain(self.s.prediction or {})
            pcfg = self.s.prediction or {}
            # 双闸:预测总开关关掉时补算无从谈起(引擎都不跑);补算开关独立可关。
            if not pcfg.get("enabled", True) or not pcfg.get("replay_enabled", True):
                if announced != "off":
                    log.info("命中率补算关闭:命中率只统计实盘攒出来的判定")
                    announced = "off"
                continue
            if announced != "on":
                log.info("命中率补算启用:热身 %s 局,每轮至多 %s 房,每房冷却 %ss",
                         pcfg.get("replay_warmup", 400),
                         pcfg.get("replay_batch", 8),
                         pcfg.get("replay_cooldown_s", 3600))
                announced = "on"
            try:
                if not await self.bus.replay_try_lock(interval):
                    continue          # 本周期已有副本负责
                await self._replay_sweep(pcfg, interval)
            except Exception as e:                        # noqa: BLE001
                log.error("命中率补算巡检异常: %r", e)

    def _replay_params(self, pcfg: Dict[str, Any]) -> Tuple[int, int]:
        """补算的 (window, warmup) 统一算口 —— 巡检与唤醒快道必须同源,否则两条
        路径会各补各的窗(4.9.3 抽出;算法与 4.6.0 巡检内联版逐字相同)。"""
        window = max(1, int(pcfg.get("accuracy_window", 100) or 100))
        # basic 档另有一个更窄/更宽的命中窗(userauth.jf_basic_pred_window),
        # 两者取大 —— 否则 basic 用户会看到一个填不满的窗。硬顶 500 兜住误配。
        with contextlib.suppress(Exception):
            window = max(window, int(self.s.userauth.jf_basic_pred_window))
        window = min(500, window)
        warmup = max(0, int(pcfg.get("replay_warmup", 400) or 0))
        return window, warmup

    async def _replay_wake_drain(self, pcfg: Dict[str, Any]) -> None:
        """唤醒快道排水(4.9.3):把 monitor/add 转正与冷房唤醒投进来的房当场补算。

        与 _replay_sweep 的分工:巡检是**兜底节拍**(60s 一轮、batch 闸、冷却闸),
        快道是**人类在场**的即时通道 —— config_registry 对 replay_cooldown_s 的
        既有承诺「转正/唤醒会当场清掉该房的冷却」由 web 侧兑现,这里负责让清完闸
        的房**秒级**得到补算,而不是干等下一轮巡检。

        纪律与巡检严格同源:
          · _dormant 同判据(发现房/冷房不补 —— 它们没有实时消费者);
          · 每房仍走 replay_gate(NX):抢不到 = sweep/别副本正在办,让贤;
          · 轻探先行:anchor 为 0(房间尚无一局数据,典型 = 刚 add 还在播种)时
            **不消耗冷却闸**直接放回 —— 否则闸被空耗,真数据到位后反要再等一个
            冷却周期(这正是把 add 路径直接接 _replay_room 会踩的坑);
          · 窗口已满时落闸即入稳态(与巡检「零缺口短路」同效);
          · 异常走 REPLAY_FAIL_BACKOFF_S 短退避(与巡检同款)。
        每次至多 2 房、逐房串行(引擎在线程池,不压事件循环)。"""
        if not pcfg.get("enabled", True) or not pcfg.get("replay_enabled", True):
            return
        rooms = await self.bus.replay_wake_pop(2)
        if not rooms:
            return
        window, warmup = self._replay_params(pcfg)
        cooldown = max(60, int(pcfg.get("replay_cooldown_s", 3600) or 3600))
        for room in rooms:
            if not self._running:
                return
            try:
                if await self._dormant(room):
                    continue          # 冷房/发现房:与预测闸同源,不为无人看的房烧 CPU
                probe = await self.db.replay_gaps(room, window, "")
                if not int(probe.get("anchor") or 0):
                    continue          # 尚无数据:不耗闸,交给播种完成后的巡检/再唤醒
                if not (probe.get("missing") or probe.get("stale")):
                    await self.bus.replay_gate(room, cooldown)
                    continue          # 窗口已满:落闸即稳态
                if not await self.bus.replay_gate(room, cooldown):
                    continue          # 已有人在办(巡检/别副本)
                if await self._replay_room(room, window, warmup, pcfg):
                    log.info("[补算] 快道 room=%s 唤醒即补(节拍 ≤1s + 补算本体)", room)
            except Exception as e:                        # noqa: BLE001
                log.warning("[补算] 快道 room=%s 异常: %r", room, e)
                with contextlib.suppress(Exception):
                    await self.bus.replay_gate_set(room, REPLAY_FAIL_BACKOFF_S)

    async def _replay_sweep(self, pcfg: Dict[str, Any],
                            interval_s: int = 60) -> None:
        """一轮补算巡检:挑候选房 → 过冷却闸 → 查缺口 → 因果回放 → 落库。

        interval_s 同时是跨副本锁的 TTL —— 本轮墙钟不得逼近它(见下方 deadline)。
        """
        active = set(await self.bus.active_rooms())
        if not active:
            return
        # 候选 = 策展热房(与 _dormant 同源:排掉发现房,双开时再排掉冷策展房)
        with contextlib.suppress(Exception):
            active -= set(await self.bus.discovered_members())
        hm = self.s.histmode
        if hm.enabled and getattr(hm, "curated_idle_enabled", False):
            with contextlib.suppress(Exception):
                active -= set(await self.bus.cold_members())
        if not active:
            return
        window, warmup = self._replay_params(pcfg)
        batch = max(1, int(pcfg.get("replay_batch", 8) or 8))
        cooldown = max(60, int(pcfg.get("replay_cooldown_s", 3600) or 3600))
        done = 0
        # 跨副本锁的 TTL = 巡检周期。而 replay_batch 上限 200 × 单房约 2.4s ≈ 480s,
        # 远超默认 60s 的锁 —— 锁一过期,别的副本就会**并发**开跑,协程头注承诺的
        # 「全舰队同一周期恰好一个副本在算」当场失效(每房冷却闸只防重复房,不防
        # 并发烧 CPU)。故本轮再加一道墙钟闸:逼近锁到期就收手,剩下的交给下一轮。
        # 取 80% 余量,给最后一个房留出写库时间。默认配置下(8×2.4s≈19s)永不触发。
        deadline = time.monotonic() + max(1.0, interval_s * 0.8)
        # 4.9.3:候选顺序由 sorted 改为随机洗牌 —— 公平性修正。旧 sorted 是
        # **字典序严格优先级**:batch(8)×每小时轮次(3600/60)=480 房/时是巡检
        # 总吞吐,而每房冷却闸恰好也是 1h ⇒ 有缺口的热房一旦超过 480,每小时的
        # 处理序列都从同一批字典序头部重启,尾部房**永远**轮不到(饿死不是变慢,
        # 是零份额)。洗牌后期望份额均匀,任何规模下每房都有 480/N 的小时概率;
        # 既有测试只断言 batch 计数与集合成员,均与顺序无关。
        cand = list(active)
        random.shuffle(cand)
        for room in cand:
            if not self._running or done >= batch:
                return
            if time.monotonic() >= deadline:
                log.info("[补算] 本轮墙钟到限(已补 %d 房),余下交下一轮", done)
                return
            if not await self.bus.replay_gate(room, cooldown):
                continue              # 该房最近探过 —— 零 SQL 跳过
            try:
                if await self._replay_room(room, window, warmup, pcfg):
                    done += 1
            except Exception as e:                        # noqa: BLE001
                log.warning("[补算] room=%s 异常(不影响任何既有链路): %r", room, e)
                # 4.9.3:异常不再吞掉整段冷却(旧行为 = 一次瞬时抖动让该房的
                # 补算多等 1h)。改写为短退避:瞬断分钟级自愈,坏房被钳住不空转。
                with contextlib.suppress(Exception):
                    await self.bus.replay_gate_set(room, REPLAY_FAIL_BACKOFF_S)

    async def _replay_room(self, room: str, window: int, warmup: int,
                           pcfg: Dict[str, Any]) -> bool:
        """为单房补齐窗口内缺失的命中判定。返回是否真的跑了引擎(用于计入 batch)。"""
        # ★ 桥**只取一次**并在本函数内一路传下去。此前读了两次(算指纹一次、
        #   丢进线程池一次),中间隔着几个 await —— 配置热更恰好插在中间时,
        #   行会被盖上**旧指纹**却是用**新桥**算出的。虽然下一轮会判过期重算
        #   (自愈),但那是白烧一整轮,且期间那个戳在撒谎。取一次即根除。
        bridge = self.bridge
        # 4.9.3 孤儿行补结算(纯账本修复,绝不推权重 —— 理由与竞态论证见
        # db.heal_orphan_settlements 文档):孤儿 = 「有实盘预测行、目标局早已开出、
        # 结算却漏了」的行。accuracy 数不到它,replay_gaps 也刻意不把它当缺口
        # (README §10.1 四道闸),于是它是窗口里唯一**任何机制都填不上**的黑洞。
        # 放在取缺口之前:补完账再看窗,口径自洽。
        with contextlib.suppress(Exception):
            healed = await self.db.heal_orphan_settlements(room, window)
            if healed:
                log.info("[补算] room=%s 补结算 %d 条孤儿判定(只回填账本,不推权重)",
                         room, healed)
        # 配置指纹:预测超参是热更项,改过之后旧配置算出的补算行与当前口径不可比
        # (真机实测错配可致 11pp 偏差),须删掉重算。稳态下指纹不变 ⇒ stale 恒空。
        fp = pred_cfg_fingerprint(bridge)
        gaps = await self.db.replay_gaps(room, window, fp)
        missing = list(gaps.get("missing") or [])
        stale = list(gaps.get("stale") or [])
        if not missing and not stale:
            return False              # 窗口已满且无过期行 —— 稳态恒走这里
        if stale:
            # 先删后插:保住「补算 INSERT 恒 ON CONFLICT DO NOTHING、绝不覆盖
            # 实盘行」这条最硬的保证。DELETE 自带 source='replay' 谓词。
            dropped = await self.db.drop_replay_rows(room, stale)
            log.info("[补算] room=%s 预测配置已变,清掉 %d 条过期补算行待重算",
                     room, dropped)
            missing = sorted(set(missing) | set(stale))
        since = plan_span(missing, warmup,
                          getattr(bridge.pcfg, "train_window_hours", 24.0),
                          getattr(bridge.pcfg, "max_train", 5000))
        rounds = await self.db.rounds_since(room, since)
        # 热身可行性预检(4.6.0 复查修正:旧判据 len(rounds)<=warmup 太粗 ——
        # rounds 里绝大部分是训练窗的量,与「缺口之前有多少局可热身」是两回事)。
        # 精确判据:连**最新**那个缺口都热身不足 ⇒ 一条也写不出来,直接省掉引擎。
        # 该缺口的预测在它前一局处生成,故可用热身 = 它之前的局数 − 1。
        newest_gap = max(missing)
        pre = sum(1 for r in rounds if int(r["round_id"]) < newest_gap)
        if pre - 1 < warmup:
            log.debug("[补算] room=%s 最新缺口前仅 %d 局 < 热身 %d,本轮不跑引擎",
                      room, max(0, pre - 1), warmup)
            return False
        # ── 4.9.3 结构性可行性裁剪:识别「怎么跑都写不出来」的缺口,全不可补时
        # 不再空烧一整轮引擎。两类结构性不可补(判据与 replay_window 的写出条件
        # **逐条对齐**,不多不少):
        #   ① pending 链断:目标 t 的补算判定在 t−ROUND_STEP 那一局生成
        #      (pending[rid+STEP] 精确衔接)。前一格点缺席(官方缺失)或妖兽未知
        #      (custom_id NULL,rounds_since 已滤掉)⇒ 链没人交棒,永远 pop 不中。
        #      这与实盘同构 —— 实盘对纯洞后一局同样无判定(生产在洞处没有事件),
        #      所以**不桥接**:桥接会让补算判到实盘没判的局、kv 轨迹偏离生产,
        #      违背「生产同一条代码路径」的立身之本(README §10.1 诚实边界)。
        #   ② 热身不足:t 之前可用局数 − 1 < warmup(replay_window 的 warm_of 闸,
        #      逐字同判据)。老缺口的「之前」不随时间增长,除非 GameHistory 事后
        #      补入更早的局 —— 故本裁剪**无状态**、每轮现算,深回填一到位自动解锁。
        # 旧行为:窗口里只剩这类缺口时,每个冷却周期都重跑一整轮引擎(热身 400 +
        # 训练窗,真机 ≈2.4s CPU)然后 0 行落库,直到缺口滑出窗口(≈83 分钟)——
        # 纯浪费还占一个 batch 名额。真机数据实证该形态真实存在(样本库三房 7 天:
        # 1275859 房 3 洞/1 个洞后局、3746870 房 4 洞/2 个洞后局)。
        ids = {int(r["round_id"]) for r in rounds}
        order = sorted(ids)
        def _feasible(t: int) -> bool:
            if (t - ROUND_STEP) not in ids:
                return False                              # ① 链断
            return bisect.bisect_left(order, t) - 1 >= warmup   # ② 热身
        doable = [t for t in missing if _feasible(t)]
        skipped = len(missing) - len(doable)
        if not doable:
            log.info("[补算] room=%s 窗口内 %d 个缺口全部结构性不可补"
                     "(洞后局/热身不足),不跑引擎;缺口将随窗口滑动自然出窗",
                     room, skipped)
            return False
        t0 = time.monotonic()
        loop = asyncio.get_running_loop()
        # 纯 CPU 放线程池:虽持 GIL 不能并行,但 GIL 每 5ms 让渡,事件循环仍能
        # 交错推进 —— 加上跨副本锁与 batch 闸,峰值占用被钉在可控区间。
        # 训练窗/最大训练量同样从**这一份**桥的 pcfg 取 —— 它们都是
        # E.PredictionConfig 的字段,与指纹同源;从 self.s.prediction 另取会
        # 在热更瞬间与指纹脱钩,重新引入上面刚根除的那类不一致。
        # 注:传给引擎的仍是**完整** missing(而非 doable)—— 起跑点/热身闸/链衔接
        # 由 replay_window 自身裁决,喂全量可保证与旧版逐字节同输出;doable 只用于
        # 「全不可补」短路与下方的落库数核对,不改变任何计算路径。
        rcfg = {"train_window_hours": getattr(bridge.pcfg, "train_window_hours", 24.0),
                "max_train": getattr(bridge.pcfg, "max_train", 5000)}
        rows = await loop.run_in_executor(
            None, pred_replay_window, bridge, rcfg, room,
            rounds, missing, warmup, now_ms(), fp)
        if not rows:
            # 4.9.3 起走到这里必然异常:上方可行性裁剪保证 doable ≥ 1,而判据与
            # replay_window 的写出条件逐条对齐 —— 引擎 0 产出只能是两处漂移了。
            # 大声说,且仍计入 batch(它确实花了 CPU)。
            log.warning("[补算] room=%s 引擎 0 产出但可补判定 %d 条 —— "
                        "裁剪判据与 replay_window 疑似漂移,请对照两处注释排查",
                        room, len(doable))
            return True
        n = await self.db.save_replay_predictions(room, rows)
        if len(rows) != len(doable):
            # 可行性判据若与引擎写出条件漂移,这里第一时间大声说(而不是静默少补)。
            # 比的是**引擎产出行数**而非落库行数:落库差额只可能来自 ON CONFLICT
            # DO NOTHING 的良性竞态(既有语义),与判据无关。
            log.warning("[补算] room=%s 引擎产出 %d 条 ≠ 可补判定 %d 条 —— "
                        "裁剪判据与 replay_window 疑似漂移,请对照两处注释排查",
                        room, len(rows), len(doable))
        log.info("[补算] room=%s 补齐 %d/%d 条(另 %d 结构性不可补;窗 %d 局,"
                 "热身 %d,取 %d 局,耗时 %.2fs)",
                 room, n, len(missing), skipped, window, warmup, len(rounds),
                 time.monotonic() - t0)
        if n:
            # 4.9.3:补满即时告知前端(SSE `pred-updated` 携 acc 标记)——
            # 新前端据此立刻 refreshPrediction,推演卡「近N局」秒级跳满;
            # 旧前端本就不监听 pred-updated 事件(3.3.5 注:「旧前端忽略」),
            # 零风险。推送量 ≤ batch/巡检周期 + 快道 ≤2/s,舰队级可忽略。
            with contextlib.suppress(Exception):
                await self.bus.publish_draw(room, {
                    "type": "pred-updated", "roomId": str(room),
                    "pred": {"acc": 1}})
        return True

    # ── discovery:每 interval 遍历繁星在播列表,自动纳入后台抓取 ────────────────
    #    发现房只进运行态(Redis 名录 + 调度队列),**不落 PG rooms**(由每轮遍历重建);
    #    照常被抓取,其出怪/预测数据进 PG(即「自动统计数据」)。前端据 rooms:discovered
    #    过滤掉发现房,只显示用户显式添加的房(见 web._build_live_rooms)。
    #    多 worker 副本经 Redis `SET NX EX=遍历周期` 互斥:锁即节拍,同一周期全局一轮。
    async def _discovery(self) -> None:
        # live-config 循环:enabled/interval/构造期参数每轮现读 —— 配置中枢可热切
        # 「关闭↔启用」与发现器重建(_disc_dirty),无需重启。
        announced = None          # 去重:仅在开/关翻转时打一条 info
        restored = False          # 回灌只做一次(启用后首轮;跨开关翻转不重复)
        while self._running:
            cfg = self.s.discovery
            if not cfg.enabled:
                if announced != "off":
                    log.info("discovery 关闭(discovery.enabled=false):不自动发现直播间")
                    announced = "off"
                # 关闭时释放发现器资源(下次启用再懒建)
                if self.disc is not None:
                    with contextlib.suppress(Exception):
                        await self.disc.close()
                    self.disc = None
                for _ in range(5):
                    if not self._running:
                        return
                    await asyncio.sleep(1)
                continue
            # 启用:懒建 / 脏重建发现器(构造失败不崩溃任务,置 None 下轮重试)
            if self.disc is None or self._disc_dirty:
                if self.disc is not None:
                    with contextlib.suppress(Exception):
                        await self.disc.close()
                    self.disc = None
                try:
                    self.disc = await self._build_disc()
                    self._disc_dirty = False
                except Exception as e:
                    log.error("discovery 发现器构造失败(下轮重试): %r", e)
                    for _ in range(5):
                        if not self._running:
                            return
                        await asyncio.sleep(1)
                    continue
            if announced != "on":
                log.info("discovery 启用:每 %ds 遍历繁星在播列表(单轮最多 %d 页,"
                         "首抓错峰窗口 %dms,离线回收 grace=%ds)",
                         max(5, int(cfg.interval_s)), cfg.max_pages,
                         cfg.warmup_window_ms, cfg.prune_grace_s)
                announced = "on"
            # 启动回灌(仅首次启用):grace 内出现过的发现房恢复进运行态。Redis 关
            # 持久化,不回灌则重启会把当时离线的发现房提前清零。幂等,多副本无害。
            if not restored:
                restored = True
                try:
                    rec = await restore_discovered(self.bus, self.db, cfg)
                    if rec["restored"] or rec["expired"] or rec["promoted"]:
                        log.info("discovery 回灌:恢复 %d 发现房(其中重新登记 %d)· "
                                 "超 grace 清理 %d · 已转正跳过 %d",
                                 rec["restored"], rec["admitted"],
                                 rec["expired"], rec["promoted"])
                except Exception as e:
                    log.error("discovery 回灌异常(跳过;在播房将由遍历自行重建): %r", e)
            interval = max(5, int(cfg.interval_s))
            for _ in range(interval):
                if not self._running:
                    return
                await asyncio.sleep(1)
            try:
                # 跨副本互斥:抢到才遍历(TTL=周期,锁即全局节拍)。
                # 遍历耗时随在播规模线性增长(实测 ~49 房/页、单页 RTT ~390ms):
                # 1 万房 ≈ 204 页,并发翻页后 ≈12s,仍远短于 60s 周期。但网络劣化时
                # 可能逼近甚至超过 TTL —— 那会让锁在遍历途中过期、别的副本插队开第二轮
                # (繁星惊群)。故持锁期间挂一个**续租心跳**(compare-and-expire,只续
                # 自己的锁),遍历结束即停,让锁自然到期 —— "锁即节拍"的语义不变。
                token = await self.bus.discovery_try_lock(interval)
                if not token:
                    continue
                hb = asyncio.create_task(self._disc_lock_heartbeat(token, interval))
                try:
                    if self.disc is not None:
                        await self._discover_once(cfg)
                finally:
                    hb.cancel()
                    with contextlib.suppress(asyncio.CancelledError, Exception):
                        await hb
            except Exception as e:
                log.error("discovery 异常: %r", e)

    # ── 主播直播状态(5.0.6:名录绿点)───────────────────────────────────────
    async def _livestatus(self) -> None:
        """每 interval_s 让每个**策展房**都有一条足够新的直播状态观测。

        观测有两个来源,合起来才既权威又便宜(判据的实测推导见 settings.LiveStatusCfg):
          ① 在播列表遍历顺手记(discovery.reconcile_discovered)—— 零请求;
          ② 本循环对「观测已过 fresh_s 的房」逐个打 roomStatus —— 权威定谳。
        于是常驻在播列表的房永不消耗探测预算,真正要花请求的只有「不在榜的房」
        (下播的、以及从不上榜的频道房)。

        与 discovery 循环**完全解耦**:那是后台抓取的纳管机制,这是前端展示的事实;
        运维关掉自动发现时,本循环照常给出正确的直播状态(只是 ① 不再供货,全部
        走 ② 探测,成本仍以策展房数为界)。
        """
        announced = None
        while self._running:
            cfg = self.s.livestatus                 # live-config:开关/周期每轮现读
            if not cfg.enabled:
                if announced != "off":
                    log.info("直播状态探测关闭(livestatus.enabled=false):"
                             "名录绿点一律显示为「未知」")
                    announced = "off"
                for _ in range(5):
                    if not self._running:
                        return
                    await asyncio.sleep(1)
                continue
            if announced != "on":
                log.info("直播状态探测启用:每 %ds 一轮(保鲜 %ds / 有效 %ds / "
                         "单轮上限 %d 房 / 并发 %d)",
                         max(5, int(cfg.interval_s)), cfg.fresh_s, cfg.stale_s,
                         cfg.max_probe, cfg.concurrency)
                announced = "on"
            interval = max(5, int(cfg.interval_s))
            for _ in range(interval):
                if not self._running:
                    return
                await asyncio.sleep(1)
            try:
                token = await self.bus.livestatus_try_lock(interval)  # 跨副本互斥兼节拍
                if not token:
                    continue
                hb = asyncio.create_task(self._live_lock_heartbeat(token, interval))
                try:
                    await self._livestatus_once(cfg)
                finally:
                    hb.cancel()
                    with contextlib.suppress(asyncio.CancelledError, Exception):
                        await hb
            except Exception as e:
                log.error("直播状态探测异常: %r", e)

    async def _live_lock_heartbeat(self, token: str, ttl_s: int) -> None:
        """轮次期间每 TTL/3 续租一次探测锁。上游不可达时一轮可达
        ⌈max_probe/concurrency⌉ × request_timeout(默认 19×8s ≈ 152s)——
        远超 60s 的 TTL,不续租就会被别的副本插队开第二轮。锁一旦易主即自行退出。"""
        step = max(1.0, float(ttl_s) / 3.0)
        while True:
            await asyncio.sleep(step)
            if not await self.bus.livestatus_renew_lock(token, ttl_s):
                log.warning("直播状态锁已易主/失效,停止续租(本轮不再持锁)")
                return

    async def _livestatus_once(self, cfg) -> None:
        """跑一轮:对齐策展房集合 → 选出过期观测 → 有界并发探测 → 只写成功项。"""
        t0 = time.monotonic()
        try:
            curated = {str(r["room_id"]) for r in await self.db.active_rooms()}
        except Exception as e:
            log.warning("直播状态:读策展名录失败(本轮跳过,旧观测自然变陈): %r", e)
            return
        snap = await self.bus.livestatus_map()
        # ① 表对齐:不再是策展房的观测项删掉(删房 / 转回发现房),防表无界增长。
        gone = [r for r in snap if r not in curated]
        if gone:
            await self.bus.livestatus_drop_bulk(gone)
            # 本地快照同步剔除 —— 否则下面的统计仍按**已经删掉的房**计数:
            # live/offline 会超过 curated 总数,unknown 被 max(0,…) 夹成 0,
            # 运维看到的那行「策展 N 房 · 在播 x · 未开播 y · 未知 0」是假的。
            for r in gone:
                snap.pop(r, None)
        nowv = now_ms()
        fresh_ms = max(1, int(cfg.fresh_s)) * 1000
        # ② 待探集:观测缺失或已过保鲜期;**最旧优先**,超过 max_probe 的分轮覆盖。
        due = sorted((r for r in curated
                      if nowv - snap.get(r, (0, 0))[1] > fresh_ms),
                     key=lambda r: snap.get(r, (0, 0))[1])
        due = due[:max(1, int(cfg.max_probe))]
        if not due:
            await self._livestatus_note(nowv, len(curated), snap, 0, 0, t0)
            return
        sem = asyncio.Semaphore(max(1, int(cfg.concurrency)))

        async def _probe(rid: str):
            async with sem:                        # 另有繁星令牌桶在 star 内兜底礼貌
                try:
                    return rid, await asyncio.wait_for(
                        self.star.live_status(rid),
                        timeout=max(1.0, float(cfg.request_timeout)))
                except Exception:
                    return rid, None               # 问不到 ≠ 没开播:不写,留旧值变陈
        got = await asyncio.gather(*(_probe(r) for r in due))
        ok = [(rid, st) for rid, st in got if st is not None]
        if ok:
            await self.bus.livestatus_set_bulk(ok, ts=nowv)
            for rid, st in ok:                     # 本轮结果并进快照,统计口径才对
                snap[rid] = (st, nowv)
        await self._livestatus_note(nowv, len(curated), snap, len(due), len(ok), t0)

    async def _livestatus_note(self, nowv: int, curated_n: int, snap: dict,
                               probed: int, ok: int, t0: float) -> None:
        """落一轮统计(/api/crawler/status 读它:探测在不在跑、几家在播、几家未知)。"""
        stale_ms = max(1, int(self.s.livestatus.stale_s)) * 1000
        live = sum(1 for st, ts in snap.values()
                   if st == 1 and nowv - ts <= stale_ms)
        off = sum(1 for st, ts in snap.values()
                  if st == 0 and nowv - ts <= stale_ms)
        info = {"ts_ms": nowv, "ts": _iso_local(nowv), "curated": curated_n,
                "live": live, "offline": off, "unknown": max(0, curated_n - live - off),
                "probed": probed, "probeOk": ok, "probeFail": max(0, probed - ok),
                "elapsed_s": round(time.monotonic() - t0, 3)}
        with contextlib.suppress(Exception):
            await self.bus.livestatus_set_last(info)
        log.info("直播状态一轮:策展 %d 房 · 在播 %d · 未开播 %d · 未知 %d · "
                 "本轮探测 %d(成功 %d)· 耗时 %.2fs",
                 curated_n, live, off, info["unknown"], probed, ok, info["elapsed_s"])

    # ── 核验房复核(5.0.7:自动发现看不见的房,在播记录由 roomStatus 供货)──────
    async def _verify_sweep(self) -> None:
        """维护 PG 核验台账:刷新 last_live_ms、排下一次复核、清出超期房。

        为什么不能并进 _livestatus:那条循环只服务**策展房**,而台账里真正需要
        花请求的恰恰是「已被用户删光绑定、已不是策展房」的那批 —— 它们不在
        livestatus 的视野里,却仍要维持「后台还认这房近期开过播」的凭据。

        三级供货,请求只花在最后一级:
          ① 台账房仍是发现房 → 直接取 rooms:discovered 的 last_seen(零请求);
          ② 台账房仍是策展房 → 直接取 rooms:livestatus 的观测(零请求,该房本就
             每 fresh_s 被探一次,再探一遍纯属重复劳动);
          ③ 其余(解绑后的孤儿)→ 到期才打 roomStatus。

        节拍:巡检每分钟醒一次(锁 TTL=60s,跨副本互斥),但**每房各有各的到期
        时刻** next_probe_ms = now + interval×U(0.75,1.25)。刻意不用统一时刻:
        「每天 04:00 齐探一次」对固定晚上开播的主播是**确定性漏判** —— 一年都
        判不出它在播;随机相位把这种系统性盲区摊成概率问题。
        """
        announced = None
        while self._running:
            for _ in range(_VERIFY_TICK_S):
                if not self._running:
                    return
                await asyncio.sleep(1)
            cfg = self.s.discovery
            if not getattr(cfg, "verify_enabled", True):
                if announced != "off":
                    log.info("核验房复核关闭(discovery.verify_enabled=false):"
                             "台账不再刷新,超期房将在下次开启后统一清理")
                    announced = "off"
                continue
            if announced != "on":
                log.info("核验房复核启用:每 %ds 巡检一次,每房复核周期 %ds(随机相位)",
                         _VERIFY_TICK_S, int(getattr(cfg, "verify_interval_s", 86400)))
                announced = "on"
            try:
                if not await self.bus.verify_try_lock(self._verify_lock_ttl()):
                    continue
                await self._verify_sweep_once(cfg)
            except Exception as e:
                log.error("核验房复核异常: %r", e)

    def _verify_lock_ttl(self) -> int:
        """本轮互斥锁 TTL。**不能想当然取巡检节拍** —— discovery 与 livestatus 都
        踩过同一个坑并各自写了长篇注释:上游不可达时每一发探测都要耗满
        request_timeout,一轮最坏 = ⌈max_probe/concurrency⌉ × timeout(默认
        ⌈300/16⌉×8 ≈ 152s)。锁若在轮次途中过期,别的副本就会插队开第二轮,
        恰在上游已经出问题时叠加请求。

        本循环与那两条的区别是:节拍不由锁承担(每房的到期时刻存在 PG 的
        next_probe_ms 里),所以锁 TTL 可以**放长到覆盖最坏耗时**,不必像它们
        那样为了维持节拍而钉死在周期上、再另加续租心跳。持锁者崩溃最多让别的
        副本空等一个 TTL,期间没有任何数据损失 —— 排期是持久化的。"""
        ls = self.s.livestatus
        worst = math.ceil(max(1, int(ls.max_probe)) / max(1, int(ls.concurrency))) \
            * max(1.0, float(ls.request_timeout))
        return int(max(_VERIFY_TICK_S, worst * 1.2))

    def _verify_next_ms(self, nowv: int, interval_s: int) -> int:
        """下次复核时刻:周期 × U(0.75, 1.25)。相位随机化见 _verify_sweep 头注。"""
        span = max(1, int(interval_s)) * 1000
        return nowv + int(span * (0.75 + random.random() * 0.5))

    async def _verify_sweep_once(self, cfg) -> None:
        t0 = time.monotonic()
        try:
            rows = await self.db.verified_all()
        except Exception as e:
            log.warning("核验房复核:读台账失败(本轮跳过): %r", e)
            return
        if not rows:
            return
        nowv = now_ms()
        interval_s = int(getattr(cfg, "verify_interval_s", 86400))
        grace_ms = int(cfg.prune_grace_s) * 1000 if int(cfg.prune_grace_s) > 0 else None

        disc = await self.bus.discovered_map()
        try:
            curated = {str(r["room_id"]) for r in await self.db.active_rooms()}
        except Exception:
            curated = set()
        live_snap = await self.bus.livestatus_map() if curated else {}

        # 刷新地板:台账时钟只需要**落在 grace 之内**,精确到分钟毫无意义。不设
        # 地板的话 ①② 每一轮都会给几乎每一行发一条 UPDATE —— 发现房的 last_seen
        # 每 60s 就变,于是万行台账 = 每 300s 一万条 UPDATE(还要连带 WAL)。
        # 取周期的四分之一(默认 6h):每行每天至多 4 次写,而时钟最陈也只差 6h,
        # 相对 7 天的 grace 有 28 倍余量,回收判定不受任何影响。
        refresh_floor = max(60_000, int(interval_s) * 1000 // 4)
        refreshed: List[tuple] = []
        due: List[str] = []
        for r in rows:
            rid = str(r["room_id"])
            last = int(r["last_live_ms"])
            seen = disc.get(rid)                       # ① 发现房:列表在册即在播
            if seen is not None and int(seen) > last:
                if int(seen) > last + refresh_floor:
                    refreshed.append((rid, int(seen),
                                      self._verify_next_ms(nowv, interval_s)))
                continue                               # 无论写不写,都不该再去探它
            if rid in curated:                         # ② 策展房:复用探测观测
                st, ts = live_snap.get(rid, (None, 0))
                if st == 1 and int(ts) > last:
                    if int(ts) > last + refresh_floor:
                        refreshed.append((rid, int(ts),
                                          self._verify_next_ms(nowv, interval_s)))
                    continue
            nxt_at = int(r["next_probe_ms"] or 0)
            if nxt_at <= 0:
                # 还没排过期的新行(_verify_admit 落台账时 next_probe_ms 取默认 0)。
                # 它的 last_live_ms 就是刚刚核验的那一刻 —— 此时再探一次纯属重复:
                # 只排期、不探。复查实测:不这么做的话,每一次核验准入都会在 60s
                # 内换来一发多余的 roomStatus(②那条复用观测的分支因 ts>last 取
                # 严格大于而恰好接不住它)。
                refreshed.append((rid, 0, self._verify_next_ms(nowv, interval_s)))
            elif nxt_at <= nowv:                       # ③ 孤儿:到期才真探
                due.append(rid)
        due = due[:max(1, int(self.s.livestatus.max_probe))]

        probed_ok = 0
        if due:
            sem = asyncio.Semaphore(max(1, int(self.s.livestatus.concurrency)))

            async def _probe(rid: str):
                async with sem:
                    try:
                        return rid, await asyncio.wait_for(
                            self.star.live_status(rid),
                            timeout=max(1.0, float(self.s.livestatus.request_timeout)))
                    except Exception:
                        return rid, None
            for rid, st in await asyncio.gather(*(_probe(r) for r in due)):
                nxt = self._verify_next_ms(nowv, interval_s)
                if st == 1:
                    refreshed.append((rid, nowv, nxt))
                    probed_ok += 1
                else:
                    # 未开播 / 问不到都只是「这一拍没看到」:时钟不动(GREATEST 保证
                    # 不退),只把下次复核排出去。够不够格留在台账由 grace 说了算,
                    # 不由单次探测定生死 —— 与发现房「缺席不算下播」同一条戒律。
                    refreshed.append((rid, 0, nxt))
        if refreshed:
            with contextlib.suppress(Exception):
                await self.db.verified_update_bulk(
                    refreshed, batch_size=max(1, int(cfg.batch_size)))

        pruned = 0
        if grace_ms is not None:
            cutoff = nowv - grace_ms
            fresh = {rid for rid, ts, _ in refreshed if ts >= cutoff}
            stale = [str(r["room_id"]) for r in rows
                     if int(r["last_live_ms"]) < cutoff
                     and str(r["room_id"]) not in fresh]
            if stale:
                with contextlib.suppress(Exception):
                    await self.db.verified_delete_bulk(
                        stale, batch_size=max(1, int(cfg.batch_size)))
                    pruned = len(stale)
        info = {"ts_ms": nowv, "ts": _iso_local(nowv), "ledger": len(rows),
                "refreshed": len(refreshed), "probed": len(due), "probeOk": probed_ok,
                "pruned": pruned, "elapsed_s": round(time.monotonic() - t0, 3)}
        with contextlib.suppress(Exception):
            await self.bus.verify_set_last(info)
        if due or pruned:
            log.info("核验房复核:台账 %d 房 · 本轮探测 %d(在播 %d)· 清出超期 %d · 耗时 %.2fs",
                     len(rows), len(due), probed_ok, pruned, info["elapsed_s"])

    async def _disc_lock_heartbeat(self, token: str, ttl_s: int) -> None:
        """遍历期间每 TTL/3 续租一次发现锁。锁一旦易主(令牌不符)即自行退出 ——
        真持锁者另有其人,本任务不再续,避免两个副本互相续对方的锁。"""
        step = max(1.0, float(ttl_s) / 3.0)
        while True:
            await asyncio.sleep(step)
            if not await self.bus.discovery_renew_lock(token, ttl_s):
                log.warning("discovery 锁已易主/失效,停止续租(本轮遍历将不再持锁)")
                return

    async def _discover_once(self, cfg) -> None:
        """跑一轮:遍历在播列表 → 经 reconcile_discovered 并入运行态 → 记录统计。
        reconcile 逻辑与 CLI(scripts/discover_rooms.py)共用,保证行为一致。"""
        t0 = time.monotonic()
        swept = await self.disc.sweep()
        rec = await reconcile_discovered(self.bus, self.db, swept, cfg)
        nowv = rec["nowv"]
        discovered_total = len(await self.bus.discovered_members())
        active_total = len(await self.bus.active_rooms())
        info = {
            "ts_ms": nowv, "ts": _iso_local(nowv),
            "pages": swept.get("pages", 0), "fetched": swept.get("fetched", 0),
            "unique": swept.get("unique", 0), "new_admitted": rec["new_admitted"],
            "pruned": rec["pruned"], "discovered_total": discovered_total,
            "purged_rounds": rec.get("purged_rounds", 0),
            "purged_predictions": rec.get("purged_predictions", 0),
            "active_total": active_total, "manual_total": rec["manual_total"],
            "truncated": bool(swept.get("truncated")),
            "stopped_by": swept.get("stopped_by", ""),
            "elapsed_s": round(time.monotonic() - t0, 3),
        }
        with contextlib.suppress(Exception):
            await self.bus.discovery_set_last(info)
        _purged = info["purged_rounds"] + info["purged_predictions"]
        log.info("discovery 遍历完成:在播 %d(%d 页)· 新增 %d · 回收 %d%s · "
                 "发现房共 %d · 活跃共 %d · 耗时 %.2fs%s",
                 info["unique"], info["pages"], info["new_admitted"], info["pruned"],
                 "(清史 rounds=%d predictions=%d)" % (
                     info["purged_rounds"], info["purged_predictions"])
                 if _purged else "",
                 info["discovered_total"], info["active_total"], info["elapsed_s"],
                 "(触达页数护栏)" if info["truncated"] else "")


def main() -> None:
    import logging as _l
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    # 配置中枢:构造 Worker **之前**先叠加 PG 运行时覆盖 —— 让连接池/并发等 🔴 项
    # 与 log_level 在进程启动时即按覆盖值生效(它们是构造期参数,启动后不可热更)。
    # 失败仅告警(短超时),绝不阻塞 worker 启动(原则三)。
    boot_state = loop.run_until_complete(cfgc.bootstrap(_S, "worker"))
    _l.basicConfig(level=getattr(_l, _S.log_level.upper(), _l.INFO),
                   format="%(asctime)s %(levelname)s [%(name)s] %(message)s")
    w = Worker()
    w.cfg_state = boot_state          # 承接启动叠加的 boot_rev/applied_rev
    w.cfg_state.role = "worker"
    for sig in (signal.SIGINT, signal.SIGTERM):
        with contextlib.suppress(NotImplementedError):
            loop.add_signal_handler(sig, w.stop)
    try:
        loop.run_until_complete(w.run())
    finally:
        loop.close()


if __name__ == "__main__":
    main()
