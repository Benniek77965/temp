"""
config_center.py — 配置中枢(运行时覆盖层 + 热更协议)
================================================================================
在既有 `ENV(STA_*) > config.yaml > 代码默认` 之上叠加第四层**运行时覆盖**
(PG config_revisions 最新快照,经管理页写入),并实现:

  变更分发:apply → PG 落不可变版本 → PUBLISH cfg:events {"rev":N}(消息只带
  版本号,各实例**拉取式**读 PG 快照再套用 —— 免疫消息伪造/丢失);
  套用回执:worker/web 内置 run_agent 协程(订阅 + 心跳),把 applied_rev 写进
  cfg:hb:{instance},管理页据此渲染「N/N 实例已收敛」;
  心跳对账:每 30s 比对 PG 当前 rev,落后即自拉自补(pub/sub 只是加速器);
  apply_hot 四条铁律(方案 §3.6):只原地改不换对象 / 带状态对象走既定钩子 /
  套用失败不半途而废 / 🔴 项永不动态套用(仅计入 needs_restart)。

冷启动:进程先按文件/ENV 完成合并,再经 `bootstrap()` **尽力**叠加 PG 覆盖
(3s 超时,失败仅告警继续)—— 配置中枢不可用绝不阻塞 worker 启动(原则三)。
敏感值(auth.ticket):版本快照只存占位 `__redis__`,真值放 Redis `cfg:sensitive`
(compose 的 Redis 关持久化,纯内存);启动叠加跳过敏感项,由 cookie 续期接管。
"""
from __future__ import annotations

import asyncio
import contextlib
import hashlib
import json
import logging
import os
import re
import socket
import time
from dataclasses import dataclass, field as dc_field
from typing import Any, Callable, Dict, List, Optional, Tuple

import yaml

from . import config_registry as reg
# ⚠ 部署硬依赖:本行要求 app/constants.py 也是 4.9.4 版(含 rounds_for_hours)。
# 二者必须**同批覆盖** —— 只拷本文件会在 import 期 ImportError,web 起不来。
# (刻意用硬 import 而非 try/except 兜底:起不来是**响的**故障,一眼可见;
#  静默回落到复制的公式才是查不出来的那种 —— 那正是本次要消灭的东西。)
from .constants import (ROUND_STEP as _ROUND_STEP,
                        MIN_TRAIN_WINDOW_H, MIN_TRAIN_ROUNDS,
                        rounds_for_hours as _rounds_for_hours)
from .config_registry import (HOOK, HOT, REGISTRY, RESERVED, RESTART,
                              SENTINEL_REDIS, coerce, flatten_effective,
                              get_path, set_path)

log = logging.getLogger("cfgcenter")

CH_CFG = "cfg:events"          # 变更广播频道(消息:{"rev": N})
K_HB_PREFIX = "cfg:hb:"        # 实例心跳/回执:cfg:hb:{role}-{host}-{pid}
K_SENSITIVE = "cfg:sensitive"  # 敏感真值(内存 Redis;HASH key→plaintext)


async def reveal_sensitive(bus, key: str):
    """取回某个敏感项的运行时明文;不存在回 None。异常上抛,调用方定语义。

    读的就是 apply 时写进去的那把(见本文件 hset(K_SENSITIVE, ...)),
    与生效值同源 —— 不存在「显示的和实际用的不是同一把」这种事。
    Redis 重启会丢真值(设计如此:敏感值刻意不落 PG 快照),此时回 None,
    调用方据此告诉运维「当前生效值来自 ENV/默认,请到部署侧看」。
    """
    v = await bus.r.hget(K_SENSITIVE, key)
    if isinstance(v, (bytes, bytearray)):
        v = v.decode("utf-8", "ignore")
    return v if v else None
HB_INTERVAL_S = 30
HB_TTL_S = 90
BOOT_TIMEOUT_S = 3.0

# 与 config_registry 的 `consumers` 同一口径。只有这两个真实角色参与「本进程是否
# 消费该键」的过滤;测试/脚本传进来的自定义 role(如 "test")一律按老行为全量套用,
# 不因为这条新逻辑被静默架空。
ROLES: Tuple[str, ...] = ("worker", "web")
# 敏感真值读取的有限重试。**只加在这一处**,理由见 _read_sensitive 的 docstring。
SENS_READ_ATTEMPTS = 3
SENS_READ_BACKOFF_S = 0.2


def exc_text(e: BaseException) -> str:
    """异常的可读文本。

    刻意**不用** `{e!r}`(4.7.7 实地核查):redis-py 8.x 给 RedisError 定义了
    `__repr__ = f"{error_type.value}:{ClassName}"`,于是
    `repr(TimeoutError("Timeout reading from redis:6379"))` 只剩
    `network:TimeoutError` —— 「哪台 Redis、哪个端口、读超时还是写超时」这条
    唯一有排障价值的信息被 repr 吞干净了。管理台上那行红字因此变成一句
    没有下文的断言。统一成「类名: 消息」,让运维拿到能直接查的东西。

    公开命名(无下划线):admin_api 在 /config/reveal 的失败分支复用同一口径 ——
    那条路是**纯 Redis 读**,是全仓另一处 RedisError 的 repr 会直达运维眼睛的地方。
    """
    msg = str(e).strip()
    return f"{type(e).__name__}: {msg}" if msg else type(e).__name__


async def _read_sensitive(bus) -> Dict[str, str]:
    """读 `cfg:sensitive` 全量,带有限重试。

    为什么重试只加在这里,而不是给整个 Redis 客户端开 `retry_on_error`
    (4.7.7 读 redis-py 8.0.1 源码后的结论,非推断):
      · redis-py 的 retry 走 `conn.retry.call_with_retry(_send_command_parse_response)`
        —— 重发的是**整条命令**,不是只重连。对 INCR / ZADD / HSET 这类
        **非幂等**命令,「命令已到服务端、回包超时」的场景下重发会重复执行:
        令牌桶多扣一次、调度 ZSET 多插一条。本项目的限流与延迟队列全在这条路上,
        全局开 retry 是拿正确性换可用性。
      · HGETALL 是纯读,重试零副作用 —— 这才是可以安全重试的那一类。
    """
    # max(1, ...) 让「至少跑一轮」成为结构保证,而不是靠 assert 兜底 ——
    # assert 在 python -O 下会被剥掉,那时 last 仍是 None,`raise None` 只会抛出
    # 一句与现场无关的 TypeError,把真正的故障盖掉。
    attempts = max(1, int(SENS_READ_ATTEMPTS))
    last: Optional[BaseException] = None
    delay = SENS_READ_BACKOFF_S
    for attempt in range(attempts):
        try:
            return await bus.r.hgetall(K_SENSITIVE) or {}
        except asyncio.CancelledError:
            raise
        except Exception as e:                   # noqa: BLE001
            last = e
            if attempt + 1 < attempts:
                await asyncio.sleep(delay)
                delay *= 2
    raise last                                   # 循环必至少执行一次,此处必非 None

# ── ENV/YAML/默认 合并基线(bootstrap 时、apply 前捕获;进程生命周期内不变) ────
_BASE: Optional[Dict[str, Any]] = None


def capture_base(settings) -> Dict[str, Any]:
    """捕获「运行时覆盖之前」的合并基线(幂等:只捕获一次)。
    清除某项覆盖时,该项回落到此基线值。"""
    global _BASE
    if _BASE is None:
        _BASE = dict(flatten_effective(settings))
    return _BASE


def base() -> Dict[str, Any]:
    assert _BASE is not None, "config_center.capture_base 尚未执行"
    return _BASE


def _reset_base_for_tests() -> None:   # 仅测试用
    global _BASE
    _BASE = None


# ── 分层取值(来源链玺印的数据源) ─────────────────────────────────────────────
_yaml_cache: Tuple[str, float, Dict[str, Any]] = ("", -1.0, {})


def _yaml_path() -> str:
    return os.environ.get("STA_CONFIG") or os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.yaml")


def yaml_layer() -> Dict[str, Any]:
    """config.yaml 展平到注册表口径(mtime 缓存)。键缺失=该层未设值。"""
    global _yaml_cache
    path = _yaml_path()
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return {}
    if _yaml_cache[0] == path and _yaml_cache[1] == mtime:
        return _yaml_cache[2]
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}
    except Exception:
        raw = {}
    out: Dict[str, Any] = {}
    for key in REGISTRY:
        if "." in key:
            head, _, rest = key.partition(".")
            sub = raw.get(head)
            if isinstance(sub, dict) and rest in sub:
                out[key] = sub[rest]
        elif key in raw:
            out[key] = raw[key]
    _yaml_cache = (path, mtime, out)
    return out


def env_layer() -> Dict[str, Any]:
    """已设置的 STA_* 环境变量展平(仅注册了 env 名的键)。"""
    out: Dict[str, Any] = {}
    for key, f in REGISTRY.items():
        if f.env:
            v = os.environ.get(f.env)
            if v not in (None, ""):
                out[key] = v
    # settings.py 的历史别名:STA_REDIS_MAX_CONN 亦可覆盖 redis_max_connections
    v = os.environ.get("STA_REDIS_MAX_CONN")
    if v not in (None, "") and "redis_max_connections" not in out:
        out["redis_max_connections"] = v
    return out


def mask(f: reg.Field, v) -> Any:
    """敏感值掩码(前 8 后 4;短值全遮)。非敏感原样返回。
    1.4.3:实现移居 config_registry(public_schema 同尺复用,见彼处说明);
    此处保留同名委托,既有调用方零改动。"""
    return reg.mask(f, v)


def fingerprint(v) -> str:
    return "sha256:" + hashlib.sha256(str(v).encode("utf-8")).hexdigest()[:16]


# ── 进程侧状态(回执/舰队心跳的载体) ──────────────────────────────────────────
@dataclass
class CenterState:
    role: str = "?"
    boot_rev: int = 0
    applied_rev: int = 0
    started_ms: int = dc_field(default_factory=lambda: int(time.time() * 1000))
    snapshot: Dict[str, Any] = dc_field(default_factory=dict)
    errors: List[str] = dc_field(default_factory=list)
    # True = 本轮套用被**基础设施**问题(目前仅敏感值读取)打断,配置没落全。
    # 心跳对账据此强制重来一次 —— 否则 applied_rev 已经等于目标 rev,
    # 「落后才补」的条件永远不成立,一次 Redis 抖动就把「套用异常」焊死在
    # 管理台上,直到有人重启进程(4.7.7 实测复现)。
    retry_pending: bool = False

    @property
    def instance(self) -> str:
        return f"{self.role}-{socket.gethostname()}-{os.getpid()}"


# ── 套用(apply_hot;方案 §3.6 四条铁律) ──────────────────────────────────────
async def apply_snapshot(settings, snapshot: Dict[str, Any], *,
                         hooks: Dict[str, Callable], mode: str,
                         state: CenterState, bus=None
                         ) -> Tuple[List[str], List[str], List[str]]:
    """把「完整覆盖快照」套到 settings(幂等、自愈:非仅 diff)。

    mode="hot"  运行中套用:🔴(RESTART)项跳过并计入 needs_restart(铁律四);
    mode="boot" 启动叠加:进程尚未据配置构造对象,🔴 项一并写入 —— 重启即生效;
                敏感占位项(真值在 Redis)跳过,交由 cookie 续期链路接管。
    返回 (changed_keys, needs_restart_keys, errors)。
    """
    changed: List[str] = []
    needs_restart: List[str] = []
    errors: List[str] = []
    pending_hooks: List[str] = []
    sens_cache: Optional[Dict[str, str]] = None
    sens_error: Optional[str] = None     # 非 None = 本轮已试过且失败,不再重复打 Redis
    state.retry_pending = False          # 每轮重新判定(套用是幂等自愈的,不继承上轮结论)
    b = base()

    for key, f in REGISTRY.items():
        if f.readonly or f.hot == RESERVED:
            continue
        if key in snapshot:
            raw = snapshot[key]
            if f.sensitive and raw == SENTINEL_REDIS:
                if mode == "boot" or bus is None:
                    continue                      # 启动期敏感真值不可得:跳过
                # 本进程不消费这个密钥,就没有任何理由为它去打一次 Redis,更没有
                # 理由因此在管理台上报「套用异常」。实测现场正是如此:worker 为
                # `userauth.jf_card_api_key`(consumers=("web",))读 cfg:sensitive
                # 超时,红字挂在 worker 上,而这个密钥 worker 永远不会用到。
                # fleet() 算 needs_restart 早就是按 consumers 过滤的 —— 这里补齐同一口径。
                if state.role in ROLES and state.role not in f.consumers:
                    continue
                if sens_cache is None and sens_error is None:
                    try:
                        sens_cache = await _read_sensitive(bus)
                    except Exception as e:        # noqa: BLE001
                        sens_error = exc_text(e)
                if sens_error is not None:
                    errors.append(f"{key}: 敏感值读取失败 {sens_error}")
                    state.retry_pending = True    # 下个心跳周期强制重来
                    continue
                if key not in sens_cache:         # Redis 重启丢真值:保持现值
                    # 5.2.0 复查:auth.ticket 由 cookie 续期自愈,丢了无妨;其余敏感项(外部发卡
                    # API 密钥、账密签发密钥)没有任何自愈链路 —— web 一重启就悄悄回落到环境
                    # 变量 / 默认:发卡端点整体 503,签发通道变成「不校验密钥」。如实上报到
                    # 实例收敛(管理台可见),别让它静默失效。值本身仍「保持现值」不动。
                    if not f.no_reset:
                        envv = (os.environ.get(f.env) or "").strip() if f.env else ""
                        fallback = f"环境变量 {f.env}" if envv else "默认值(空)"
                        if get_path(settings, key) != b.get(key, f.default):
                            errors.append(f"{key}: 管理台设置的明文已不在 Redis(Redis 重启所致);"
                                          f"本进程仍在用内存里的旧值,但下次重启就会回落到{fallback}"
                                          f" —— 请在管理台重新保存一次,或写入 .env 的 {f.env} 以持久化")
                        else:
                            errors.append(f"{key}: 管理台设置的明文已丢失(Redis 重启所致),当前按"
                                          f"{fallback}生效 —— 请在管理台重新设置,或写入 .env 的 "
                                          f"{f.env} 以持久化")
                    continue
                raw = sens_cache[key]
            try:
                target = coerce(f, raw)
            except Exception as e:
                errors.append(f"{key}: {e}")
                continue
        else:
            if f.no_reset:                        # auth 系:清除覆盖不回落基线
                continue
            target = b.get(key, f.default)
        cur = get_path(settings, key)
        if cur == target:
            continue
        if f.hot == RESTART and mode == "hot":    # 铁律四
            needs_restart.append(key)
            continue
        set_path(settings, key, target)           # 铁律一:原地改
        changed.append(key)
        if f.hook and f.hook not in pending_hooks:
            pending_hooks.append(f.hook)

    for h in pending_hooks:                       # 铁律二/三:钩子逐个跑,异常不中断
        fn = hooks.get(h)
        if fn is None:
            continue
        try:
            r = fn()
            if asyncio.iscoroutine(r):
                await r
        except Exception as e:                    # noqa: BLE001
            # 注:钩子失败**不**置 retry_pending。再拉一次快照时 cur == target、
            # changed 为空,钩子根本不会被重新触发,重试只是空转;真正的修法是
            # 给钩子做「待执行队列」,那是另一件事,不在本次修复范围内 —— 与其
            # 半修,不如在这里写清楚,别让人误以为它也会自愈。
            errors.append(f"hook {h}: {exc_text(e)}")
    state.errors = errors
    return changed, needs_restart, errors


# ── 冷启动叠加(worker main / web lifespan 最先调用) ──────────────────────────
async def bootstrap(settings, role: str) -> CenterState:
    """按原则三:先捕获文件/ENV 基线,再**尽力**叠加 PG 最新覆盖;失败仅告警。"""
    capture_base(settings)
    st = CenterState(role=role)
    try:
        import asyncpg
        con = await asyncio.wait_for(asyncpg.connect(settings.pg_dsn),
                                     timeout=BOOT_TIMEOUT_S)
        try:
            row = await asyncio.wait_for(con.fetchrow(
                "SELECT rev, snapshot FROM config_revisions ORDER BY rev DESC LIMIT 1"),
                timeout=BOOT_TIMEOUT_S)
        finally:
            with contextlib.suppress(Exception):
                await con.close()
        if row:
            snap = row["snapshot"]
            if isinstance(snap, str):
                snap = json.loads(snap)
            st.snapshot = dict(snap or {})
            changed, _, errs = await apply_snapshot(
                settings, st.snapshot, hooks={}, mode="boot", state=st)
            st.boot_rev = st.applied_rev = int(row["rev"])
            log.info("配置中枢:启动叠加 rev=%d(变更 %d 项%s)",
                     st.boot_rev, len(changed),
                     f",异常 {len(errs)}" if errs else "")
    except Exception as e:
        log.warning("配置中枢:启动叠加失败(按 ENV/YAML/默认 继续): %r", e)
    return st


# ── 订阅 + 心跳/对账 协程(worker 与 web 共用) ────────────────────────────────
async def _pull_apply(settings, bus, db, hooks, state: CenterState) -> None:
    rev, snap = await db.cfg_latest()
    if rev <= 0:
        return
    state.snapshot = snap
    changed, needs_restart, errs = await apply_snapshot(
        settings, snap, hooks=hooks, mode="hot", state=state, bus=bus)
    state.applied_rev = int(rev)
    if changed or errs:
        log.info("配置中枢:套用 rev=%d 变更=%s%s%s", rev, changed or "无",
                 f" 需重启={needs_restart}" if needs_restart else "",
                 f" 异常={errs}" if errs else "")


async def _beat(bus, state: CenterState) -> None:
    key = K_HB_PREFIX + state.instance
    mapping = {
        "role": state.role, "host": socket.gethostname(), "pid": os.getpid(),
        "started_ms": state.started_ms, "boot_rev": state.boot_rev,
        "applied_rev": state.applied_rev,
        "errors": json.dumps(state.errors, ensure_ascii=False), "ts_ms": _now_ms(),
        # 管理台据此把「基础设施抖动(会自愈)」与「配置真错(要人管)」分色呈现。
        # 写 int 而非 bool:Redis HASH 只收 str/bytes/int/float。
        "retry_pending": int(state.retry_pending),
    }
    await bus.r.hset(key, mapping=mapping)
    await bus.r.expire(key, HB_TTL_S)


def _now_ms() -> int:
    return int(time.time() * 1000)


async def run_agent(*, settings, role: str, bus, db,
                    hooks: Dict[str, Callable], state: CenterState,
                    running: Callable[[], bool] = lambda: True) -> None:
    """常驻协程:订阅 cfg:events(即时套用)+ 每 30s 心跳(兼对账自拉)。
    Redis 短暂不可用自动重连;绝不让异常外溢拖垮宿主进程。"""
    state.role = role
    pubsub = None
    last_hb = 0.0
    # 起步先对账一次(bootstrap 可能失败/落后),再进入循环
    with contextlib.suppress(Exception):
        await _pull_apply(settings, bus, db, hooks, state)
    with contextlib.suppress(Exception):
        await _beat(bus, state)
        last_hb = time.monotonic()
    try:
        while running():
            try:
                if pubsub is None:
                    pubsub = bus.r.pubsub()
                    await pubsub.subscribe(CH_CFG)
                msg = await pubsub.get_message(ignore_subscribe_messages=True,
                                               timeout=1.0)
                if msg and msg.get("type") == "message":
                    await _pull_apply(settings, bus, db, hooks, state)
                    await _beat(bus, state)      # 套用后立即回执,管理页秒级收敛
                    last_hb = time.monotonic()
                if time.monotonic() - last_hb >= HB_INTERVAL_S:
                    last_hb = time.monotonic()
                    with contextlib.suppress(Exception):
                        cur = await db.cfg_latest_rev()
                        # 两个补拉理由,缺一不可:
                        #   · cur > applied_rev —— 广播丢了,落后要补(原有语义);
                        #   · retry_pending    —— 版本号没落后,但上一轮被基础设施
                        #     问题打断、配置没落全。不加这一条,applied_rev 已经等于
                        #     cur,自愈条件永不成立,一次 5 秒的 Redis 读超时就让
                        #     「套用异常」永久挂在管理台上(4.7.7 实测复现)。
                        if cur > state.applied_rev or state.retry_pending:
                            await _pull_apply(settings, bus, db, hooks, state)
                    await _beat(bus, state)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.debug("配置代理瞬时异常(2s 后重试): %r", e)
                with contextlib.suppress(Exception):
                    if pubsub is not None:
                        await pubsub.aclose()
                pubsub = None
                await asyncio.sleep(2)
    finally:
        with contextlib.suppress(Exception):
            if pubsub is not None:
                await pubsub.aclose()


# ── 生效值与来源(管理页 /config/effective 数据源) ────────────────────────────
def describe(settings, snapshot: Dict[str, Any]) -> List[Dict[str, Any]]:
    y, e, b = yaml_layer(), env_layer(), base()
    cookie_active = bool(getattr(settings, "auth_cookie_file", "") or "")
    out: List[Dict[str, Any]] = []
    for key, f in REGISTRY.items():
        live = get_path(settings, key)
        in_rt = key in snapshot
        if in_rt:
            source = "runtime"
        elif key.startswith("auth.") and cookie_active and f.no_reset:
            source = "cookie"          # 运行期由 cookie 续期链路维护(方案 §3.2 例外)
        elif key in e:
            source = "env"
        elif key in y:
            source = "yaml"
        else:
            source = "default"
        rt_val = snapshot.get(key)
        if f.sensitive and rt_val == SENTINEL_REDIS:
            rt_val = "(经 Redis 内存分发)"
        out.append({
            "key": key,
            "effective": mask(f, live),
            "source": source,
            "layers": {
                "default": mask(f, f.default),
                "yaml": mask(f, y[key]) if key in y else None,
                "yaml_set": key in y,
                "env": mask(f, e[key]) if key in e else None,
                "env_set": key in e,
                "runtime": mask(f, rt_val) if in_rt else None,
                "runtime_set": in_rt,
            },
            "base": mask(f, b.get(key, f.default)),
        })
    return out


# ── 结构 + 语义校验(validate/apply 共用) ─────────────────────────────────────
def check_changes(changes: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    """结构校验:类型收敛 + 范围/枚举 + 只读/预留拒改。返回 (收敛后的变更, errors)。"""
    coerced: Dict[str, Any] = {}
    errors: List[str] = []
    for key, v in changes.items():
        f = REGISTRY.get(key)
        if f is None:
            errors.append(f"{key}: 未登记的参数")
            continue
        if f.readonly or f.hot == RESERVED:
            errors.append(f"{key}: 只读/预留项,不接受运行时覆盖({f.label})")
            continue
        try:
            coerced[key] = coerce(f, v)
        except Exception as ex:
            errors.append(f"{key}: {ex}")
    return coerced, errors


# 4.4.2:客服「只对直营主站下发」这句话有**两个**触发点(改直营名单 / 改客服项),
# 两处必须一字不差 —— 同一件事说成两个版本,运维会以为是两回事。故提成常量。
_CS_MIRROR_NOTE = (
    "客服联系方式**只对直营主站下发**:代理镜像站的 /api/auth/session "
    "响应体里根本不会出现它(不是前端藏起来 —— 藏起来的话 F12 就能把"
    "平台客服从代理站页面里挖出去)。因此用不在直营名单里的域名/IP 自测时"
    "看不到客服栏是**预期行为**,不是没生效;要自测请把该 Host 也列入"
    "「直营主站域名」")


def semantic_validate(candidate: Dict[str, Any],
                      changed: Optional[set] = None) -> Tuple[List[str], List[str]]:
    """跨字段语义校验(candidate=候选生效全集)。返回 (errors, warnings)。

    changed 给出「本次实际触及的键集」:依赖类提示(burst 依赖 rps 等)只在相关
    键本身被改动时才发出 —— 否则会对基线里早已存在、本次未碰的组合反复误伤
    (如只改上游抖动却收到 fanxing_burst 提示)。跨字段硬约束(如训练窗、局周期、
    max_bulk 硬顶)与具体改了哪项无关,始终校验。changed=None 时全量提示(校验预览用)。
    """
    errors: List[str] = []
    warnings: List[str] = []

    def _f(key, default=0.0):
        try:
            return float(candidate.get(key, default))
        except (TypeError, ValueError):
            return default

    def _touched(*keys) -> bool:
        return changed is None or any(k in changed for k in keys)

    # ── 5.0.6 直播状态:观测有效期必须容得下两轮探测 ────────────────────────
    #    两项各自都"合法"却能组合出静默失效区:interval_s=3600 + stale_s=600 时,
    #    观测永远在下一轮探测到来前就过期 → 名录**全员永久灰环**,而管理台上看不出
    #    任何异常。正是本仓库反复警告的「运维以为改生效了其实没有」。
    if _touched("livestatus.interval_s", "livestatus.stale_s",
                "livestatus.fresh_s", "livestatus.enabled",
                "discovery.interval_s", "discovery.enabled"):
        _li = _f("livestatus.interval_s", 60)
        _lst = _f("livestatus.stale_s", 600)
        _lfr = _f("livestatus.fresh_s", 90)
        if _lst < _li * 2:
            errors.append(
                f"livestatus.stale_s({_lst:.0f}s) < 探测周期的两倍({_li * 2:.0f}s):"
                "观测会在下一轮探测到来前就过期,名录直播状态将**全员显示为未知**。"
                f"请把 stale_s 提到 ≥{_li * 2:.0f}s,或把 interval_s 降到 "
                f"≤{_lst / 2:.0f}s")
        # fresh_s 的对标物是**在播列表遍历周期**(零成本正信号的供货节拍),不是
        # livestatus 自己的探测周期 —— 两者默认都是 60 才碰巧重合。discovery 关闭时
        # 本就没有 ① 这路供货,全量探测是预期行为,不提示。
        _de = candidate.get("discovery.enabled", True)
        _de = str(_de).strip().lower() in ("1", "true", "yes", "on") \
            if not isinstance(_de, bool) else _de
        _di = _f("discovery.interval_s", 60)
        if _de and _lfr < _di:
            warnings.append(
                f"livestatus.fresh_s({_lfr:.0f}s) < 在播列表遍历周期"
                f"(discovery.interval_s={_di:.0f}s):遍历顺手记的观测还没被复用就已过"
                "保鲜期,每个策展房每轮都要逐个探 —— **零成本正信号形同虚设**,上游"
                f"请求量按策展房数满打满算。建议取 {_di + 30:.0f}s(遍历周期 + 余量)")

    # ── 5.0.7 核验准入:复核周期必须在台账有效期里跑够几轮 ────────────────────
    #    台账有效期 = discovery.prune_grace_s(与发现房同一把尺)。若复核周期逼近
    #    甚至超过它,核验房会在「还没轮到复核」时就被判超期清出 —— 用户下次添加
    #    又要等主播正好在播,而管理台上看不出任何异常。两项各自都在合法区间,
    #    只有合在一起才是错的,正是本函数存在的意义。
    if _touched("discovery.verify_interval_s", "discovery.prune_grace_s",
                "discovery.verify_enabled"):
        _vfe = candidate.get("discovery.verify_enabled", True)
        _vfe = str(_vfe).strip().lower() in ("1", "true", "yes", "on") \
            if not isinstance(_vfe, bool) else _vfe
        _vfi = _f("discovery.verify_interval_s", 86400)
        _pg = _f("discovery.prune_grace_s", 604800)
        if _vfe and _pg > 0 and _vfi * 2 > _pg:
            warnings.append(
                f"discovery.verify_interval_s({_vfi:.0f}s)相对台账有效期"
                f"(discovery.prune_grace_s={_pg:.0f}s)偏大:核验房在超期前只轮得到"
                f"约 {_pg / max(1.0, _vfi):.1f} 次复核,间歇开播的主播极易被误判超期"
                f"清出台账。建议 verify_interval_s ≤ {_pg / 4:.0f}s,或把 grace 调大")

    # ── 4.2.1 九法VIP 依赖闸(保存时就告诉运维,而不是等他重启完发现没反应)──
    if _touched("userauth.jf_vip_enabled", "userauth.host", "userauth.db",
                "userauth.user"):
        _jf = candidate.get("userauth.jf_vip_enabled")
        _jf = str(_jf).strip().lower() in ("1", "true", "yes", "on") \
            if not isinstance(_jf, bool) else _jf
        if _jf:
            _h = str(candidate.get("userauth.host") or "").strip()
            _d = str(candidate.get("userauth.db") or "").strip()
            _u = str(candidate.get("userauth.user") or "").strip()
            if not (_h and _d and _u):
                warnings.append(
                    "userauth.jf_vip_enabled=true 但登录系统未配置齐全"
                    "(host/db/user 需三项都有,通常经 .env 的 STA_USERDB_* 注入):"
                    "九法VIP 依赖登录身份作为档位载体,此时**开关不会有任何效果**。"
                    "若这三项确实由 .env 注入而管理台此处显示为空,可忽略本提示")
            warnings.append(
                "userauth.jf_vip_enabled 是 🔴 重启级参数:保存后**必须重启 web** "
                "(deploy-maxxiang.sh restart 或 docker compose restart web)才生效;"
                "重启后请在 web 日志里确认出现 “[九法VIP] 已启用” 横幅")
    if _touched("userauth.jf_pay_simulate") and \
            str(candidate.get("userauth.jf_pay_simulate")).strip().lower() in ("1", "true", "yes", "on"):
        warnings.append(
            "userauth.jf_pay_simulate=true:任何登录用户都能凭空给自己开 VIP —— "
            "仅限无外网联调,生产环境必须关闭")

    # ── 4.4.1 「账密换链接」的 origin × 站点分流:单值 origin 会把所有镜像站的
    #    用户都送去同一个站。这条交叉检查的存在理由是:两项分属不同 section
    #    (登录系统 / 九法VIP),各自单看都完全正常,**只有合在一起才是错的** ——
    #    而这正是 semantic_validate 相对于单字段校验器的全部价值所在。
    if _touched("userauth.sso_link_base", "userauth.sso_link_enabled",
                "userauth.jf_direct_hosts"):
        _slb = str(candidate.get("userauth.sso_link_base") or "").strip()
        _sle = candidate.get("userauth.sso_link_enabled")
        _sle = str(_sle).strip().lower() in ("1", "true", "yes", "on") \
            if not isinstance(_sle, bool) else _sle
        _dhr = str(candidate.get("userauth.jf_direct_hosts") or "").strip()
        if _slb and _sle and _dhr:
            warnings.append(
                "userauth.sso_link_base 已配置,同时站点分流(userauth.jf_direct_hosts)"
                "也已启用 —— 本部署存在多个公网 origin,而本项是**单值**:"
                "/api/auth/sso/link 回给**所有**调用方(含代理镜像站)的 url 都会指向"
                f"「{_slb}」,代理站的用户点开就被送去了那个站。"
                "建议**清空本项**:票据不绑定域名(guantai_sso_ticket 无 host 列),"
                "同一张票在本部署任何 origin 都能核销,清空后端点照常回 ticket,"
                "由各调用方用自己的 origin 拼 `<origin>/#sso=<ticket>`(一行字符串拼接)")

    # ── 4.4.1 站点分流(直营主站 vs 代理镜像站)────────────────────────────────
    # 这一项的错配代价不对称:写错一个字,**直营主站自己**就没有在线支付了,
    # 而页面上不会有任何报错(它只是"按镜像站渲染")。所以能在保存这一刻说清的,
    # 一个字都不能省 —— 运维在这里读到,好过在收入曲线上读到。
    if _touched("userauth.jf_direct_hosts", "userauth.jf_direct_trust_xfh",
                "userauth.jf_vip_enabled"):
        _raw = str(candidate.get("userauth.jf_direct_hosts") or "")
        try:
            from .userauth import norm_host as _nh
            _toks = [t for t in re.split(r"[,\s;、，]+", _raw) if t]
            _hosts = sorted({h for h in (_nh(t) for t in _toks) if h})
        except Exception:               # noqa: BLE001 —— 校验器自身绝不可拖垮保存
            _toks, _hosts = [], []
        if any("*" in t for t in _toks):
            errors.append(
                "userauth.jf_direct_hosts 含通配符 `*`:**本项不支持通配符**,"
                "请把每个直营域名完整列出。"
                "(刻意不支持:`*.example.com` 会连带命中代理自建的 "
                "`agent.example.com`,而那正是要防的那一类漏配)")
        if _toks and not _hosts:
            warnings.append(
                "userauth.jf_direct_hosts 非空,但归一化后一个合法域名都没有 —— "
                "本特性将**按未配置处理**(全部域名一律按直营,即旧行为)。请检查是否"
                "只写了分隔符或纯 scheme")
        if _hosts:
            _jf2 = candidate.get("userauth.jf_vip_enabled")
            _jf2 = str(_jf2).strip().lower() in ("1", "true", "yes", "on") \
                if not isinstance(_jf2, bool) else _jf2
            warnings.append(
                f"站点分流已启用:直营主站 {len(_hosts)} 个"
                f"({'、'.join(_hosts)})。**其余任何 Host 一律按代理镜像站**"
                f"(隐藏在线扫码与档位卡、后端拒下单,只留卡密)。"
                f"请逐条确认:① 主站的 www 与裸域是两个 Host,都在用就都要写;"
                f"② 用 IP:端口 直连自测也会被判成镜像站;"
                f"③ 反代若把 Host 改写成上游名,需同时开启「站点分流信任 XFH 头」。"
                f"生效值以 web 启动横幅与 /api/auth/session 的 jf.site 为准")
            if not _jf2:
                warnings.append(
                    "userauth.jf_direct_hosts 已配置,但 userauth.jf_vip_enabled 为关 —— "
                    "九法VIP 整体未启用时充值入口本就不存在,本项**不会有任何效果**")
        # ── 4.4.2 客服 × 站点分流 ────────────────────────────────────────────
        # ⚠ 这里**只覆盖「改了直营名单」那一侧**。「只改了客服号码」那一侧的同款
        #   告警挂在下面 jf_cs 校验器里 —— 告警必须挂在**触发它的那组键**上,
        #   否则运维做最常见的那次操作(只改号码)时恰恰收不到它。
        #   (自查实测:初版只写在这里,漏的正是那条主路径。)
        if _hosts and (str(candidate.get("userauth.jf_cs_value") or "").strip()
                       or str(candidate.get("userauth.jf_cs_url") or "").strip()):
            warnings.append(_CS_MIRROR_NOTE)
        _xfh = candidate.get("userauth.jf_direct_trust_xfh")
        _xfh = str(_xfh).strip().lower() in ("1", "true", "yes", "on") \
            if not isinstance(_xfh, bool) else _xfh
        if _xfh and not _hosts:
            warnings.append(
                "userauth.jf_direct_trust_xfh=true 但「直营主站域名」为空 —— "
                "站点分流未启用,本项暂不起作用")
        elif _xfh:
            warnings.append(
                "userauth.jf_direct_trust_xfh=true:站点身份将取自 `X-Forwarded-Host`。"
                "**只有在你的反代确实会写这个头时才该开** —— 服务直连暴露公网时开启它,"
                "等于让任何人自选站点身份(注:站点分流本就是业务分区而非安全边界,"
                "但也不必主动把门槛降到零)")

    # ── 4.4.2 客服联系方式(具名校验器 jf_cs)────────────────────────────────
    # 这一组的核心手段是**把收敛后的生效值原样回显**,而不是 danger 那种「键入
    # 参数名确认」。理由:本组唯一真实的错误形态是「打错一个字符」(把付费用户
    # 送去陌生人那里),而键入参数名对这种错零帮助 —— 让运维核对**用户将看到的
    # 那一串**才有用。同一取向见 jf_vip_plans(直接涉钱,同样只挂校验器)。
    if _touched("userauth.jf_cs_label", "userauth.jf_cs_value",
                "userauth.jf_cs_url", "userauth.jf_cs_note",
                "userauth.jf_vip_enabled"):
        try:
            from .userauth import _CS_LIMITS as _CSL       # noqa: PLC0415
            from .userauth import cs_text as _cst, cs_url as _csu
        except Exception:            # noqa: BLE001 —— 校验器自身绝不可拖垮保存
            _CSL, _cst, _csu = None, None, None
        if _cst is not None:
            _raw = {k: str(candidate.get(f"userauth.jf_cs_{k}") or "")
                    for k in ("label", "value", "url", "note")}
            _val = _cst(_raw["value"], _CSL["value"])
            _url = _csu(_raw["url"])
            _lab = _cst(_raw["label"], _CSL["label"])
            _note = _cst(_raw["note"], _CSL["note"])
            # ① 链接白名单:配了却被丢弃,是**静默**的 —— 页面上只是少一个链接,
            #    不会有任何报错。必须在保存这一刻说出来。
            if _raw["url"].strip() and not _url:
                errors.append(
                    f"userauth.jf_cs_url「{_raw['url'].strip()[:80]}」不是合法的 "
                    "http/https 绝对 URL,**会被整条丢弃**(页面上只是少一个链接,"
                    "不会报错)。只放行 `http://` / `https://` 开头且带主机名的地址:"
                    "① `javascript:` / `data:` 是注入面,HTML 转义不能中和 href 里的它们;"
                    "② `mqqwpa://` / `tencent://` / `weixin://` 在桌面浏览器点了毫无反应,"
                    "属死控件;③ `//host` 这种协议相对写法同样拒绝。"
                    "要放 QQ 临时会话/加群,请填对方给的 https 网页版链接")
            # ② 超长:这里用 error 而不是静默截断 —— 截断后展示出去的是一串
            #    **不完整的号码**,用户照着抄必然联系不上;报错至少让运维当场知道。
            for _k, _rv in _raw.items():
                _lim = _CSL[_k]
                if len(_rv.strip()) > _lim:
                    errors.append(
                        f"userauth.jf_cs_{_k} 超过 {_lim} 字符上限"
                        f"(当前 {len(_rv.strip())});超出部分会被截断,而一串"
                        f"**不完整的联系方式**比没有更糟。请缩短后再保存")
            # ③ 只填了标签/备注,却没有号码也没有链接 ⇒ 整块不会出现。
            if (_lab or _note) and not (_val or _url):
                warnings.append(
                    "userauth.jf_cs_label / jf_cs_note 有值,但「客服号码/账号」与"
                    "「在线客服链接」都为空 —— 本特性的开关就是这两项(留空=不存在),"
                    "**页面上不会出现任何客服信息**。要展示,请至少填其中一项")
            # ④ 粘贴噪音:全角数字 / 中间空格。**只告警不代改**(同 norm_card
            #    「刻意不做字符纠错」)—— 猜错一个字符就是把用户送去别人的号。
            if _val:
                if re.search(r"[０-９Ａ-Ｚａ-ｚ]", _val):
                    warnings.append(
                        f"userauth.jf_cs_value 含**全角字符**(生效值:{_val})。"
                        "从聊天窗口粘贴时最常见。系统**刻意不替你转成半角** —— "
                        "客服号是要用户照着抄的,系统猜错一个字符就是把人送去别人那里。"
                        "确认无误可忽略本提示")
                if " " in _val:
                    warnings.append(
                        f"userauth.jf_cs_value 中间含空格(生效值:{_val})。"
                        "若是粘贴时带进来的,请删掉 —— 用户复制到的会是带空格的整串")
            # ⑤ 生效值回显:本组最重要的一条。运维在这里核对的,就是用户会看到的。
            if _val or _url:
                _show = " · ".join(x for x in (
                    (_lab or "客服") + (f" {_val}" if _val else ""),
                    (f"链接 {_url}" if _url else ""),
                    (f"备注「{_note}」" if _note else "")) if x)
                warnings.append(
                    f"客服联系方式将展示为:{_show} —— **请逐字核对**,这就是付费"
                    f"用户在开通门上看到、并会照着复制的那一串。"
                    f"另注:它**只在直营主站展示**(见站点分流),"
                    f"且改完立即生效(前端下次取 /api/auth/session 即跟随,无需重建前端)")
            # 与站点分流那一段同一句话(共用 _CS_MIRROR_NOTE),但挂在**客服键组**
            # 上 —— 运维最常做的一次操作是「只改号码」,那一刻他最可能去自测、
            # 然后怀疑没生效。去重:两处 _touched 有交集时只说一遍。
            if (_val or _url) and str(
                    candidate.get("userauth.jf_direct_hosts") or "").strip() \
                    and _CS_MIRROR_NOTE not in warnings:
                warnings.append(_CS_MIRROR_NOTE)
            _jf3 = candidate.get("userauth.jf_vip_enabled")
            _jf3 = str(_jf3).strip().lower() in ("1", "true", "yes", "on") \
                if not isinstance(_jf3, bool) else _jf3
            if (_val or _url) and not _jf3:
                warnings.append(
                    "客服联系方式已配置,但 userauth.jf_vip_enabled 为关 —— "
                    "当前唯一的展示位是九法VIP 开通门,VIP 体系不启用时它不会出现在"
                    "任何地方(下发链路本身照常工作,将来接入其它展示位即可复用)")

    days = _f("retention.days")
    twh = _f("prediction.train_window_hours", 24.0)
    if _touched("retention.days", "prediction.train_window_hours") \
            and 0 < days * 24 < twh:
        warnings.append(
            f"retention.days={days:g} 天(={days * 24:.1f}h)小于预测训练窗口 "
            f"train_window_hours={twh:g}h:训练可用数据将被保留窗口截短,预测质量可能"
            f"静默劣化(worker 侧同款护栏告警)")
    # ── 计数制(train_window_hours=0)下的同一条护栏(4.9.5 补齐)────────────────
    # 上面那条的判据是「retention 小时数 < 训练窗小时数」,twh=0 时恒不成立 ——
    # 于是**放开 0 之后,计数制这一路一句话都不说**。实测:retention.days=1 配
    # tw=0 / max_train=5000 时,训练意图 5000 局而库里只留得下 1727 局,静默截短 3273 局,
    # 零告警。计数制没有「小时数」可比,必须换算成局数比。
    if _touched("retention.days", "prediction.train_window_hours",
                "prediction.max_train") and twh <= 0 and days > 0:
        _mt_cnt = int(_f("prediction.max_train", 5000.0))
        # 局数换算**只能**走 constants.rounds_for_hours —— 本轮初稿这里手写了
        # int(days*24*3600*1000/STEP),与单一真源差 1 局(12095 vs 12096),
        # 正是本仓库反复吃亏的「公式复制」。差 1 局不影响判断,但复制这个动作本身
        # 就是缺陷:ROUND_STEP 一旦随上游变动,手写的那份不会跟着变。
        _ret_rounds = _rounds_for_hours(days * 24)
        if 0 < _ret_rounds < _mt_cnt:
            warnings.append(
                f"train_window_hours=0(计数制)配 prediction.max_train={_mt_cnt} 局,"
                f"而 retention.days={days:g} 天只留得下约 {_ret_rounds} 局 —— "
                f"训练集会被保留窗口静默截短到 {_ret_rounds} 局;"
                f"同时补算(pred_replay.plan_span)会按 max_train 回取,"
                f"等于每轮把整个保留窗读进内存。"
                f"要么把 max_train 降到 ≤{_ret_rounds},要么把 retention.days 提到 "
                f"≥{_mt_cnt * _ROUND_STEP / 86400000.0:.1f} 天")
    # ── 训练窗被静默截短的**第二条路**:max_train(4.9.4 补齐)────────────────────
    # 取数是串联的:先按时间窗切(now - train_window_hours),再被 seq[-max_train:] 截尾。
    # 上面那条只拦住了 retention 那一路;max_train 这一路此前**管理台一句话都不说** ——
    # 而运维恰恰是在管理台改这两个值的。真机实测(2678075 房 12,064 局):
    # train_window_hours=72(≈5184 局)配 max_train=5000 时四码命中 52.40%,抬到 6000
    # 后 52.43% —— 差值属噪声级,即"被截短"本身后果不大;真正的坏处是**运维以为自己
    # 改了窗口**。判据与 predictor_bridge._warn_train_window_truncated 及
    # window_audit/audit-maxxiang.sh 的「配置耦合体检」逐字同源:int(h*3600*1000/STEP)+1。
    # 只告警不报错:配置合法(LP 照跑),错的只是运维的预期。
    mtr = _f("prediction.max_train", 5000.0)
    if _touched("prediction.max_train", "prediction.train_window_hours") and twh > 0 and mtr > 0:
        # 单一真源取自 constants(纯 stdlib 依赖)。**刻意不 import predictor_bridge**:
        # 那会把整个预测引擎(spell_tamer_monitor,含 requests)拉进 web 容器的配置
        # 校验路径 —— 本模块至今只依赖 stdlib+yaml+config_registry,而 web.py 根本
        # 不 import predictor_bridge;失败时静默回落到复制的公式,更会复活它要消灭的重复。
        _step = _ROUND_STEP
        _need = _rounds_for_hours(twh)
        if mtr < _need:
            warnings.append(
                f"prediction.max_train={mtr:g} < {_need} 局:训练窗 "
                f"train_window_hours={twh:g}h 会被**静默截短**到 "
                f"{mtr * _step / 3600000.0:.2f}h —— 改了窗口等于没改。"
                f"要让窗口真正生效请把 max_train 提到 ≥{_need};"
                f"若本就想按局数封顶,把 train_window_hours 设成 0(不限时间)更能表达意图")
    # ── 近随机带:0 < train_window_hours < MIN_TRAIN_WINDOW_H 一律**拒绝**(4.9.5)──────
    # 上面那条告警推荐运维「设成 0」,而 4.9.5 之前注册表把该字段钉在 ge=0.1 ——
    # 告警教的路,管理台自己堵死(实测提交 0 得到「不得小于 0.1」)。现在下限放到 0,
    # 于是必须补上真正该拦的那一段:**极短窗**。这不是保守起见,是实测:
    #   自带三房库 12,064 局回放,四选九的随机基线 = 4/9 = 44.44%,
    #   窗口 0.1h(7 局)=49.03%、0.2h(14 局)=45.69%、1h(72 局)=50.80%,
    #   而 3~48h 全部落在 53.1~53.8% 的平台上。
    # 机理:frontier 的唯一概率输入是 9 格频率直方图,其 LP 方案的**真实**期望四码
    # 命中要 400~864 局才收敛(n=10 时 46.7%、n=200 时 51.0%、n=864 起 53.0%)。
    # 3h≈216 局仍未收敛,故取 3h 作硬下限 —— 它同时 ≥ fr_replan(200 局)的重规划节拍,
    # 保证每次重解 LP 时窗口里至少有一个完整节拍的数据。
    # 与 max_train 那条不同,这里用 errors 而非 warnings:被截短只是「运维预期落空」,
    # 而近随机带是**产品直接退化成掷骰子**,不该用 ack_warnings 一键放行。
    if _touched("prediction.train_window_hours") and 0 < twh < MIN_TRAIN_WINDOW_H:
        errors.append(
            f"prediction.train_window_hours={twh:g}h(≈{_rounds_for_hours(twh)} 局)"
            f"低于硬下限 {MIN_TRAIN_WINDOW_H:g}h(≈{MIN_TRAIN_ROUNDS} 局)—— "
            f"实测该区间四码命中退化到 45.7~50.8%,逼近四选九随机基线 44.44%"
            f"(3~48h 平台为 53.1~53.8%)。"
            f"若本意是「不按时间、只按局数封顶」,请把它设为 **0**(不限时间)"
            f"并用 prediction.max_train 控制样本量")
    if _touched("ratelimit.upstream_rps", "ratelimit.burst") \
            and _f("ratelimit.upstream_rps") <= 0 and "ratelimit.burst" in candidate:
        warnings.append("ratelimit.burst 仅当 upstream_rps > 0 时生效(当前不限流,该值暂不起作用)")
    if _touched("ratelimit.fanxing_rps", "ratelimit.fanxing_burst") \
            and _f("ratelimit.fanxing_rps") <= 0 and "ratelimit.fanxing_burst" in candidate:
        warnings.append("ratelimit.fanxing_burst 仅当 fanxing_rps > 0 时生效")
    if _touched("upstream.award_after_seal", "upstream.award_delay",
                "upstream.award_max_retries", "upstream.award_retry_interval"):
        # 实际主锚点是备战 + award_after_seal(见 worker._handle_mainpage);
        # 校验取奖重试序列是否会拖过一局。取两条路径里更靠后的那个作为窗口基准。
        base = max(_f("upstream.award_after_seal"), _f("upstream.award_delay"))
        cycle = base + _f("upstream.award_max_retries") * _f(
            "upstream.award_retry_interval")
        if cycle > 45:
            warnings.append(
                f"取奖窗口 base(备战后延迟) + max_retries×retry_interval ≈ {cycle:.1f}s,"
                f"接近/超过局周期(≈50s),末次重试可能跨局")
    if _f("admission.max_bulk") > 100000:
        errors.append("admission.max_bulk 硬顶 100000")

    # ── 任务租约 vs 单任务最坏耗时(3.4.0 真机审计发现的缺陷,加校验防复发) ──────
    #    租约 = 领取任务后多久可被别的副本重新领取。若它 ≤ 单任务最坏耗时,一个刚好
    #    跑满超时的慢请求会在返回的同一瞬间被重复领取 → 对同一房重复打上游,而这
    #    恰恰发生在上游已经很慢的时候。最坏耗时 = 令牌等待(worker.RL_MAX_WAIT_S=8s)
    #    + 上游请求超时。
    if _touched("scheduler.stale_task_grace_ms", "upstream.request_timeout"):
        lease_s = _f("scheduler.stale_task_grace_ms", 30000) / 1000.0
        worst_s = _f("upstream.request_timeout", 15.0) + 8.0   # +RL_MAX_WAIT_S
        if lease_s <= worst_s:
            warnings.append(
                f"scheduler.stale_task_grace_ms({lease_s:.0f}s) ≤ 单任务最坏耗时"
                f"({worst_s:.0f}s = 上游超时 {_f('upstream.request_timeout', 15.0):.0f}s"
                f" + 令牌等待 8s):慢请求会在返回瞬间被别的副本**重复领取、重复打上游**。"
                f"建议 ≥ {worst_s + 5:.0f}s。注:代码侧已有下限钳"
                f"(worker.effective_claim_grace_ms),过小的值不会真正生效,"
                f"但配置应与实际一致")

    # ── 发现遍历耗时 vs 遍历周期(= 发现锁 TTL) ────────────────────────────────
    #    实测:在播列表 ~49 房/页、单页 RTT ~390ms。一轮遍历 ≈ 页数/并发 × RTT。
    #    遍历若超过 interval_s(锁 TTL),锁会在遍历途中过期 → 别的副本插队开第二轮
    #    并发遍历(繁星惊群)。worker 已加锁续租兜底,此处仍在配置层显式告警。
    # ── hist-mode:轮询周期/退避 vs 官方页窗(3.5.0) ────────────────────────────
    #    页窗 = 30 局 × 50.001s ≈ 1500s 是信息论硬约束:成功轮询间隔超过它,
    #    滑出页窗的局永久不可再取得。代码侧已钳 interval ≤ 1300s
    #    (scheduler.effective_hist_interval_ms),此处在配置层把"组合越窗"讲清楚。
    if _touched("histmode.enabled", "histmode.interval_s", "histmode.retry_base_s",
                "histmode.retry_cap_s", "histmode.edge_after_s",
                "histmode.edge_retry_s"):
        win_s = 30 * 50.001
        hi = _f("histmode.interval_s", 900)
        hcap = _f("histmode.retry_cap_s", 300)
        hedge = _f("histmode.edge_after_s", 1200)
        hretry = _f("histmode.edge_retry_s", 45)
        if hi * 1.1 + hcap > win_s - 100:
            warnings.append(
                f"histmode:interval_s×1.1(周期+抖动) + retry_cap_s ≈ "
                f"{hi * 1.1 + hcap:.0f}s 逼近官方页窗(30 局 ≈{win_s:.0f}s)——"
                f"一次失败即可能越窗丢数据(登记 window_lost 止损但数据已不可得)。"
                f"建议 interval ≤900、cap ≤300。注:代码侧已把 interval 钳到 ≤"
                f"{26 * 50.001:.0f}s,越窗值不会真正生效,但配置应与实际一致")
        if hedge <= hi:
            warnings.append(
                f"histmode.edge_after_s({hedge:.0f}s) ≤ interval_s({hi:.0f}s):"
                f"正常节拍的首次失败就会触发 {hretry:.0f}s 抢救密集重试,等于把"
                f"轮询周期变相改小。建议 edge_after ≥ interval + retry_cap")
        if hedge + 3 * hretry > win_s:
            warnings.append(
                f"histmode:edge_after_s + 3×edge_retry_s ≈ {hedge + 3 * hretry:.0f}s"
                f" > 页窗 {win_s:.0f}s —— 抢救区不足 3 次重试机会,越窗风险显著上升。"
                f"建议 edge_after ≤1200 或 edge_retry ≤45")

    di = _f("discovery.interval_s", 60)
    if _touched("discovery.interval_s", "discovery.max_pages",
                "discovery.page_concurrency"):
        pages = _f("discovery.max_pages", 400)
        conc = max(1.0, _f("discovery.page_concurrency", 8))
        est_s = pages / conc * 0.39            # 0.39s = 实测单页 RTT 中位数
        if 0 < di < est_s:
            warnings.append(
                f"discovery:满页(max_pages={pages:.0f})时单轮遍历估计 ≈{est_s:.0f}s,"
                f"超过遍历周期 {di:.0f}s(= 发现锁 TTL)。已有锁续租兜底,但建议"
                f"调大 page_concurrency 或 interval_s,以免遍历持续追尾")
    if _touched("discovery.page_concurrency", "discovery.conn_limit"):
        if _f("discovery.page_concurrency", 8) > _f("discovery.conn_limit", 32):
            warnings.append(
                "discovery.page_concurrency > conn_limit:并发翻页会被连接器上限吞掉,"
                "实际并发以 conn_limit 为准")
    return errors, warnings


def build_candidate(snapshot: Dict[str, Any], changes: Dict[str, Any]
                    ) -> Dict[str, Any]:
    """候选生效全集 = 基线 ⊕ 现有覆盖 ⊕ 本次变更(敏感占位不参与语义计算)。"""
    b = dict(base())
    for k, v in snapshot.items():
        if v != SENTINEL_REDIS:
            b[k] = v
    b.update(changes)
    return b


# ── 版本写入 / 回滚 / 清除覆盖(admin_api 调用;PG 为真相,Redis 只做加速) ──────
async def commit(db, bus, *, changes: Dict[str, Any], removed: Tuple[str, ...] = (),
                 author: str, note: str,
                 base_snapshot: Optional[Dict[str, Any]] = None) -> int:
    """落一版不可变 revision 并广播。changes 已过校验;敏感真值转 Redis。"""
    if base_snapshot is None:
        _, base_snapshot = await db.cfg_latest()
    new_snap = dict(base_snapshot)
    diff: Dict[str, Dict[str, Any]] = {}
    sens_set: Dict[str, str] = {}
    sens_del: List[str] = []

    for key in removed:
        if key in new_snap:
            f = REGISTRY.get(key)
            old = new_snap.pop(key)
            if f and f.sensitive:
                sens_del.append(key)
                old = fingerprint(old)
            diff[key] = {"old": old, "new": None, "op": "clear"}
    for key, v in changes.items():
        f = REGISTRY[key]
        old = base_snapshot.get(key)
        if f.sensitive:
            sens_set[key] = str(v)
            diff[key] = {"old": fingerprint(old) if old not in (None, SENTINEL_REDIS)
                                 else old,
                         "new": fingerprint(v), "op": "set"}
            new_snap[key] = SENTINEL_REDIS
        else:
            diff[key] = {"old": old, "new": v, "op": "set"}
            new_snap[key] = v

    if sens_set:
        await bus.r.hset(K_SENSITIVE, mapping=sens_set)
    for k in sens_del:
        with contextlib.suppress(Exception):
            await bus.r.hdel(K_SENSITIVE, k)
    rev = await db.cfg_insert(_now_ms(), author, note, new_snap, diff)
    with contextlib.suppress(Exception):
        await bus.r.publish(CH_CFG, json.dumps({"rev": rev}))
    return int(rev)


def rollback_snapshot(target: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    """回滚目标快照的净化:敏感占位项剔除(Redis 真值可能已失,保持现值),
    返回 (净化快照, 被跳过的敏感键)。"""
    skipped = [k for k, v in target.items()
               if v == SENTINEL_REDIS and k in REGISTRY and REGISTRY[k].sensitive]
    clean = {k: v for k, v in target.items() if k not in skipped}
    return clean, skipped


# ── 快照导出(GitOps 回写文件层;P3) ───────────────────────────────────────────
def export_snapshot(snapshot: Dict[str, Any], fmt: str) -> str:
    items = {k: v for k, v in snapshot.items()
             if k in REGISTRY and v != SENTINEL_REDIS}
    if fmt == "env":
        lines = ["# 由配置中枢导出的运行时覆盖(仅列出有对应 STA_ 变量的项)"]
        for k, v in sorted(items.items()):
            f = REGISTRY[k]
            if f.env:
                lines.append(f"{f.env}={v}")
            else:
                lines.append(f"# {k}={v}  (无对应环境变量,请写入 config.yaml)")
        for k in sorted(set(snapshot) - set(items)):
            lines.append(f"# {k}=<敏感值,未导出;指纹见版本 diff>")
        return "\n".join(lines) + "\n"
    # yaml:按点分路径还原嵌套
    tree: Dict[str, Any] = {}
    for k, v in sorted(items.items()):
        if "." in k:
            head, _, rest = k.partition(".")
            tree.setdefault(head, {})[rest] = v
        else:
            tree[k] = v
    header = "# 由配置中枢导出的运行时覆盖(可合并进 config.yaml)\n"
    return header + yaml.safe_dump(tree, allow_unicode=True, sort_keys=True)


# ── 舰队视图(fleet;admin_api 调用) ───────────────────────────────────────────
async def fleet(bus, db) -> Dict[str, Any]:
    target = await db.cfg_latest_rev()
    keys = await bus.r.keys(K_HB_PREFIX + "*")
    instances: List[Dict[str, Any]] = []
    for k in sorted(keys):
        h = await bus.r.hgetall(k)
        if not h:
            continue
        boot = int(h.get("boot_rev") or 0)
        applied = int(h.get("applied_rev") or 0)
        role = h.get("role") or "?"
        try:
            errors = json.loads(h.get("errors") or "[]")
        except ValueError:
            errors = []
        restart_keys: List[str] = []
        if target > boot:
            with contextlib.suppress(Exception):
                touched = await db.cfg_diff_keys_since(boot)
                restart_keys = sorted(
                    kk for kk in touched
                    if kk in REGISTRY and REGISTRY[kk].hot == RESTART
                    and role in REGISTRY[kk].consumers)
        instances.append({
            "instance": k[len(K_HB_PREFIX):], "role": role,
            "host": h.get("host") or "", "pid": int(h.get("pid") or 0),
            "started_ms": int(h.get("started_ms") or 0),
            "boot_rev": boot, "applied_rev": applied,
            "ts_ms": int(h.get("ts_ms") or 0), "errors": errors,
            # converged 仍要求 not errors:配置确实没落全,写「已收敛」就是撒谎。
            # retry_pending 只改变**呈现方式**(黄「重试中」vs 红「套用异常」),
            # 不改变收敛判定。
            "retry_pending": bool(int(h.get("retry_pending") or 0)),
            "converged": applied >= target and not errors,
            "needs_restart": restart_keys,
        })
    converged = bool(instances) and all(i["converged"] and not i["needs_restart"]
                                        for i in instances)
    return {"target_rev": target, "instances": instances, "converged": converged}
