"""
admin_auth.py — 管理台鉴权(纯标准库:hmac/hashlib/secrets,零新依赖)
================================================================================
安全默认关:未设置 STA_ADMIN_PASSWORD(或 STA_ADMIN_PASSWORD_HASH)时,
/admin 与全部 /api/admin/* 返回 503「管理台未启用」。

会话:HMAC-SHA256 签名的无状态 cookie(HttpOnly · SameSite=Lax · 默认 30 天,
可用 STA_ADMIN_SESSION_TTL_S 覆盖),payload 含过期时刻与一次性 CSRF token
(写操作要求 X-Admin-CSRF 头双提交)。
签名密钥 STA_ADMIN_SECRET;未显式设置则**由密码材料确定性派生** —— 关键:
uvicorn --workers N 是 N 个进程,随机密钥会让会话在 worker 间来回失效,
派生密钥保证多进程一致(其保密性等价于密码本身,对本内网工具足够)。

口令散列:`STA_ADMIN_PASSWORD_HASH` 取 `pbkdf2_sha256$迭代$盐hex$dkhex`;
生成:`python -m app.admin_auth hash <口令>`。
可选 IP 白名单:STA_ADMIN_IP_ALLOW = 逗号分隔 CIDR(如 10.0.0.0/8,127.0.0.1/32)。
5.2.0:来源 IP 走可信代理口径(app/clientip.py,直连部署伪造 XFF 无效);登录在令牌桶之外另有
失败额度「先占后验」(每 IP 段 + 全站)与设备信任,见 login_fail_limits / admin_api.login。

5.3.0(入口 / 账号 / 人机验证 / 应急通道;入口路径与人机验证档位在 config.yaml 的 admin: 段,
登录账号 STA_ADMIN_USERNAME 与口令同处 deploy/.env——账号是凭据,不进 config.yaml):
  · 入口路径可配:页面 = /<path>,管理 API = /api/<path>/*,单一来源 `entry()`;旧地址按
    「不存在的路径」应答。外部发卡接口是机器契约,地址恒为 CARD_ISSUE_PATH;
  · 账号 + 口令:`verify_login()` 两项都算完再合并,任一项错回同一个错误;
  · 人机验证每次登录必过(供应商与注册共用),校验不可达一律拒绝(fail-closed);
  · 应急通道:`python -m app.admin_auth link` 在**服务器上**签发 10 分钟有效、只能用一次的
    登录票据 —— 能执行它的人本就握有 .env 里的全部密钥,不构成新的信任面。
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import ipaddress
import json
import os
import re
import secrets
import time
import unicodedata
from typing import Any, Dict, Optional, Tuple

COOKIE = "sta_admin"
_PBKDF2_ITER = 200_000
_DEFAULT_SESSION_TTL_S = 30 * 24 * 3600      # 30 天:登录一次,一个月内免登录


def _env(key: str) -> str:
    return (os.environ.get(key) or "").strip()


# ── 会话有效期 ───────────────────────────────────────────────────────────────
_ttl_cache: Optional[int] = None


def session_ttl_s() -> int:
    """会话有效期(秒)。默认 30 天;STA_ADMIN_SESSION_TTL_S 覆盖(≤0 / 非法 视为未设)。

    惰性求值 + 进程内缓存,与 `_secret()` 同款 —— 本仓不用 dotenv,环境变量本就
    在进程启动前落定;写成模块级常量也能跑,但那样 monkeypatch.setenv 就影响不到它,
    测试与「先 import 再注入环境」的调用方都会被坑。
    注:浏览器对 cookie 有效期另有上限(Chrome/RFC 6265bis 封顶 400 天);
    超过它时 cookie 通道先过期,localStorage 里的令牌头通道仍按本值有效。
    """
    global _ttl_cache
    if _ttl_cache is not None:
        return _ttl_cache
    try:
        v = int(_env("STA_ADMIN_SESSION_TTL_S") or 0)
    except ValueError:
        v = 0
    _ttl_cache = v if v > 0 else _DEFAULT_SESSION_TTL_S
    return _ttl_cache


def enabled() -> bool:
    return bool(_env("STA_ADMIN_PASSWORD") or _env("STA_ADMIN_PASSWORD_HASH"))


# ── 口令 ─────────────────────────────────────────────────────────────────────
def hash_password(password: str, iterations: int = _PBKDF2_ITER) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return f"pbkdf2_sha256${iterations}${salt.hex()}${dk.hex()}"


def _verify_hash(password: str, stored: str) -> bool:
    try:
        algo, it_s, salt_hex, dk_hex = stored.split("$", 3)
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                                 bytes.fromhex(salt_hex), int(it_s))
        return hmac.compare_digest(dk.hex(), dk_hex)
    except Exception:
        return False


def verify_password(password: str) -> bool:
    if not password:
        return False
    stored_hash = _env("STA_ADMIN_PASSWORD_HASH")
    if stored_hash:
        return _verify_hash(password, stored_hash)
    plain = _env("STA_ADMIN_PASSWORD")
    return bool(plain) and hmac.compare_digest(password, plain)


# ── 会话签名密钥(多 uvicorn worker 进程间必须一致) ───────────────────────────
_secret_cache: Optional[bytes] = None


def _secret() -> bytes:
    global _secret_cache
    if _secret_cache is not None:
        return _secret_cache
    explicit = _env("STA_ADMIN_SECRET")
    if explicit:
        _secret_cache = hashlib.sha256(explicit.encode("utf-8")).digest()
        return _secret_cache
    material = _env("STA_ADMIN_PASSWORD_HASH") or _env("STA_ADMIN_PASSWORD")
    # 未启用时给个进程随机值(反正一切 503);启用时由密码材料确定性派生。
    if not material:
        _secret_cache = secrets.token_bytes(32)
    else:
        _secret_cache = hashlib.sha256(
            b"sta-admin-secret-v1|" + material.encode("utf-8")).digest()
    return _secret_cache


def _reset_for_tests() -> None:
    _ADM_FAIL_MEM.clear()   # 5.2.0:管理台登录失败计数(进程内兜底)一并复位
    _ADM_TICKET_MEM.clear() # 5.3.0:应急登录票据「已使用」登记
    _warned.clear()
    global _secret_cache, _ttl_cache
    _secret_cache = None
    _ttl_cache = None


# ── 会话签发 / 验签 ──────────────────────────────────────────────────────────
def _b64url_encode(data: bytes) -> str:
    """base64url 无 padding:cookie 值不含 '='，避免被 Starlette 加双引号
    (带引号的 cookie 值在个别浏览器/反代下会被误处理,导致 cookie 不回传)。"""
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64url_decode(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _sign(payload_b64: str) -> str:
    return hmac.new(_secret(), payload_b64.encode("ascii"), hashlib.sha256).hexdigest()


def issue_session(ttl_s: Optional[int] = None) -> Tuple[str, str]:
    """返回 (cookie_value, csrf_token)。cookie 值形如 <b64url>.<hex> —— 仅含
    URL 安全字符与 '.'，均为合法 cookie-octet,不触发引用。
    ttl_s 省略时取 session_ttl_s();显式传入(含负值,测试用)则原样生效。"""
    if ttl_s is None:
        ttl_s = session_ttl_s()
    csrf = secrets.token_hex(16)
    payload = {"sub": "admin", "exp": int(time.time()) + int(ttl_s), "csrf": csrf}
    p64 = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    return f"{p64}.{_sign(p64)}", csrf


def parse_session(token: str) -> Optional[Dict[str, Any]]:
    """验签 + 过期检查;通过返回 payload,否则 None。
    防御性容错:去掉可能的包裹引号、忽略末尾多余 padding(反代/浏览器可能补回),
    使验签对 cookie 值的这些无害变形不敏感。"""
    try:
        raw = (token or "").strip().strip('"')      # 去掉可能的包裹引号
        p64, sig = raw.split(".", 1)
        p64 = p64.rstrip("=")                        # 归一化:忽略末尾多余 padding
        if not hmac.compare_digest(sig, _sign(p64)):
            return None
        payload = json.loads(_b64url_decode(p64))
        if int(payload.get("exp", 0)) < time.time():
            return None
        if payload.get("sub") != "admin":
            return None
        return payload
    except Exception:
        return None


# ── 管理台登录防爆破(5.2.0)──────────────────────────────────────────────────
# 复查发现管理台登录是全项目最弱的一道门:只有「每 IP 0.2 次/秒、突发 5」的请求
# 令牌桶(= 每 IP 每小时 720 次猜口令)、键用原始 IP(IPv6 换末位即绕过)、Redis
# 抖动时整个限流被 suppress 掉(fail-open)、没有全站上限(多 IP 分布式猜口令无界)。
# 现补齐与用户登录同一套:失败额度「先占后验」(每 IP 段 + 全站),Redis 不可用
# 退化进程内计数(绝不放开),曾在本浏览器登录成功的管理员不受锁牵连(设备信任)。
# 实现见 admin_api.login;此处只放阈值与进程内兜底存储。
_ADM_FAIL_MEM: dict = {}
ADM_DEV_COOKIE = "jf_adm_dev"


def login_fail_limits():
    """→ (每 IP 段失败上限, 全站失败上限, 计数窗口秒, 锁定秒)。环境变量可调。"""
    def _i(k: str, d: int) -> int:
        try:
            return int(_env(k) or d)
        except (TypeError, ValueError):
            return d
    return (max(1, _i("STA_ADMIN_LOGIN_FAIL_IP", 10)), max(1, _i("STA_ADMIN_LOGIN_FAIL_GLOBAL", 30)),
            max(10, _i("STA_ADMIN_LOGIN_FAIL_WINDOW_S", 600)), max(1, _i("STA_ADMIN_LOGIN_LOCK_S", 600)))


def device_ttl_s() -> int:
    """管理台设备信任有效期(秒);STA_ADMIN_DEVICE_TTL_D=0 关闭。"""
    try:
        return max(0, int(_env("STA_ADMIN_DEVICE_TTL_D") or 90)) * 86400
    except (TypeError, ValueError):
        return 90 * 86400


def login_rate_per_min() -> int:
    """每 IP 段每分钟可发起的登录请求数(STA_ADMIN_LOGIN_RATE_PER_MIN,默认 20)。
    只管速率(挡住无令牌 / 坏令牌的刷请求,人机验证开着时也是对供应商校验接口的保护);
    「总共能猜几次」由失败额度管。"""
    try:
        return max(1, int(_env("STA_ADMIN_LOGIN_RATE_PER_MIN") or 20))
    except (TypeError, ValueError):
        return 20


# ── 入口路径(5.3.0)──────────────────────────────────────────────────────────
# 复查实证(改造前的真实对外表现,均为实跑):
#   · 只把页面从 /admin 挪走没有任何防护价值 —— 登录接口 POST /api/admin/login 可绕过页面
#     直接打(错口令 401、未启用 503,存在性与可爆破性一览无余);
#   · /admin.html 经静态兜底路由可直接取到后台页面,且不看后台是否启用(未启用时 /admin 回
#     503,/admin.html 仍 200);
#   · 登录系统开启时守卫对 /api/admin/ 前缀硬编码豁免:未登录访问任意不存在的 /api/x 得 401,
#     访问 /api/admin/x 得 404 —— 前缀可被一眼认出。
# 故页面与 API 前缀同源于一个配置值,守卫豁免同步跟随,旧地址与 admin.html 一律按未知路径应答。
DEFAULT_PATH = "admin-xdd"
LEGACY_API_PREFIX = "/api/admin"
# 外部发卡接口(4.2.9,凭 API Key 的机器契约):对接方按这个地址写死了调用,绝不随入口搬家。
CARD_ISSUE_PATH = LEGACY_API_PREFIX + "/jfvip/cards/issue"
_PATH_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")
# 与站点既有路由同名的段不可用(否则二者互相遮蔽)。入口**同时**用作 /<入口>(页面)与
# /api/<入口>/*(管理接口),故两个命名空间的首段都要避开。复查实测:入口配成 auth 时,
# POST /api/auth/login 被管理台登录接管(直接签发管理会话),观测台用户登录整体失效。
# 本表由 tests/test_admin_entry.py 对照**实际路由表**守住(新增顶层路由或 /api/ 下新前缀而漏登记,
# 测试即红);两份部署脚本里复刻的同名清单另有一致性守卫。
_PATH_RESERVED = frozenset({
    # 顶层:/api 本身、静态挂载、FastAPI 文档
    "api", "assets", "cdn", "docs", "fx", "icons", "jiufa", "mock", "redoc", "static",
    # /api/ 下既有首段
    "account", "active-room", "auth", "crawler", "discovery", "events", "game", "live-rooms",
    "monitor", "pow", "rooms", "version", "vip",
})
_warned: set = set()


def _acfg():
    from .settings import settings          # 惰性:`python -m app.admin_auth hash` 不必装载配置
    return settings.admin


def _warn_once(key: str, msg: str) -> None:
    if key not in _warned:
        _warned.add(key)
        print(msg)


def normalize_path(raw: Any) -> str:
    """→ 合法的入口段;不合法(空 / 多段 / 含点或其它字符 / 保留词)返回空串。"""
    s = str(raw or "").strip().strip("/")
    if not _PATH_RE.match(s) or s.lower() in _PATH_RESERVED:
        return ""
    return s


def entry() -> str:
    """管理台入口段(单一来源)。配置非法时告警一次并回落默认 —— 一个手滑不该让整站起不来,
    但必须喊出来:否则运维以为入口改了,其实没有。"""
    raw = getattr(_acfg(), "path", "")
    s = normalize_path(raw)
    if s:
        return s
    _warn_once(f"path:{raw!r}",
               f"[管理台] ⚠️ 入口路径配置 {str(raw)!r} 不可用(须为单段:字母或数字开头,其后可含连字符/下划线,"
               f"共 1–64 位,且不能与站点已有路径同名:{'/'.join(sorted(_PATH_RESERVED))})"
               f"—— 已回落为 {DEFAULT_PATH!r}")
    return DEFAULT_PATH


def page_path() -> str:
    return "/" + entry()


def api_prefix() -> str:
    return "/api/" + entry()


# ── 账号 + 口令(5.3.0)────────────────────────────────────────────────────────
def norm_username(s: Any) -> str:
    """账号比对口径:NFKC(全角 → 半角,中文输入法下敲出的「１３２…」也认)、去首尾空白、
    不分大小写(手机键盘首字母自动大写不该把人挡在门外)。"""
    return unicodedata.normalize("NFKC", str(s or "")).strip().casefold()


def username() -> str:
    return norm_username(getattr(_acfg(), "username", ""))


def account_required() -> bool:
    return bool(username())


def username_matches(user: Any) -> bool:
    want = username()
    if not want:
        return True
    got = norm_username(user)[:256]
    # 先各自取摘要再定长比较:比较耗时与两串的长度 / 公共前缀无关
    return hmac.compare_digest(hashlib.sha256(got.encode("utf-8")).digest(),
                               hashlib.sha256(want.encode("utf-8")).digest())


def verify_login(user: Any, password: Any) -> bool:
    """账号与口令**都算完**再合并 —— 不因账号错而跳过口令校验(那会让响应耗时泄露
    「账号对不对」)。未配置账号 = 只验口令(旧模式)。"""
    pw_ok = verify_password(str(password or ""))
    user_ok = username_matches(user)
    return bool(pw_ok) & bool(user_ok)


def captcha_mode() -> str:
    """管理台登录人机验证档位:auto / always / off(settings.AdminCfg.login_captcha)。"""
    v = str(getattr(_acfg(), "login_captcha", "") or "auto").strip().lower()
    return v if v in ("auto", "always", "off") else "auto"


# ── 应急登录票据(5.3.0)──────────────────────────────────────────────────────
# 人机验证「每次必过 + 不可达即拒绝」的另一面:验证服务挂了 / 当前网络加载不出验证框时,
# 管理员需要一条不依赖第三方的进门路。票据只能在服务器上签发(签名密钥取自容器环境),
# 短时(默认 10 分钟)、一次性(用过即作废),兑换成功后发的是与正常登录完全相同的会话。
# 与会话令牌**分域签名**且 sub 不同:票据不能当会话用,会话也不能当票据用。
TICKET_DEFAULT_TTL_S = 600
TICKET_MAX_TTL_S = 3600
_ADM_TICKET_MEM: dict = {}          # jti → exp(墙钟秒):已使用登记(web 钉死单进程,进程内即权威)


def _sign_ticket(payload_b64: str) -> str:
    return hmac.new(_secret(), b"ticket|" + payload_b64.encode("ascii"), hashlib.sha256).hexdigest()


def issue_ticket(ttl_s: Optional[int] = None) -> str:
    ttl = TICKET_DEFAULT_TTL_S if ttl_s is None else min(int(ttl_s), TICKET_MAX_TTL_S)
    payload = {"sub": "admin-ticket", "exp": int(time.time()) + ttl, "jti": secrets.token_hex(16)}
    p64 = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    return f"{p64}.{_sign_ticket(p64)}"


def parse_ticket(token: Any) -> Optional[Dict[str, Any]]:
    """验签 + 过期 + 形态;通过返回 payload,否则 None(不区分原因,对外统一 bad_ticket)。"""
    try:
        raw = str(token or "").strip()
        if not raw or len(raw) > 1024:
            return None
        p64, sig = raw.split(".", 1)
        if not hmac.compare_digest(sig, _sign_ticket(p64)):
            return None
        payload = json.loads(_b64url_decode(p64))
        if payload.get("sub") != "admin-ticket" or int(payload.get("exp", 0)) < time.time():
            return None
        if not re.fullmatch(r"[0-9a-f]{32}", str(payload.get("jti") or "")):
            return None
        return payload
    except Exception:
        return None


def ticket_mark_used(jti: str, exp: int) -> bool:
    """登记「已使用」;首次返回 True,重放返回 False。存储随票据过期自然回收(有界)。"""
    now = time.time()
    for k in [k for k, v in _ADM_TICKET_MEM.items() if v < now]:
        _ADM_TICKET_MEM.pop(k, None)
    if jti in _ADM_TICKET_MEM:
        return False
    _ADM_TICKET_MEM[jti] = int(exp)
    return True


# ── 来源 IP 与白名单 ─────────────────────────────────────────────────────────
def client_ip(request) -> str:
    """来源 IP:白名单据此过滤,管理台登录限流亦按此分桶。

    5.2.0 安全修复(实证):旧实现**无条件**取 X-Forwarded-For 首跳。本项目官方编排是
    直连(没有反代覆盖该头),于是公网上任何人加一行 `X-Forwarded-For: <白名单内地址>`
    就能绕过 STA_ADMIN_IP_ALLOW,并能每请求换假 IP 稀释管理台登录限流。现改走与
    用户登录同一套「可信代理」判定(app/clientip.py):只有直连对端属于
    STA_TRUSTED_PROXIES(默认环回 + 内网)时才采信 XFF。"""
    from . import clientip
    return clientip.from_request(request, trust_xff=True) or "?"


def ip_allowed(ip: str) -> bool:
    allow = _env("STA_ADMIN_IP_ALLOW")
    if not allow:
        return True
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    for cidr in (c.strip() for c in allow.split(",") if c.strip()):
        try:
            if addr in ipaddress.ip_network(cidr, strict=False):
                return True
        except ValueError:
            continue
    return False


def _cli(argv) -> int:
    """命令行(在 web 容器内执行,如 `docker compose exec web python -m app.admin_auth link`):
        hash <口令>                  生成 PBKDF2 散列(写入 STA_ADMIN_PASSWORD_HASH)
        path                         打印当前生效的后台入口路径(部署 / 诊断脚本用)
        ticket [--minutes N]         只打印一次性应急登录票据(脚本用)
        link [--minutes N] [--base URL]
                                     打印一次性应急登录链接(人用);--base 形如 http://1.2.3.4:5173
    约定:要交给脚本的那一行走 stdout,说明文字走 stderr。"""
    import sys

    def _opt(name: str, default: str = "") -> str:
        if name in argv:
            i = argv.index(name)
            if i + 1 < len(argv):
                return argv[i + 1]
        return default

    cmd = argv[0] if argv else ""
    if cmd == "hash" and len(argv) >= 2:
        print(hash_password(argv[1]))
        return 0
    if cmd == "path":
        print(page_path())
        return 0
    if cmd in ("ticket", "link"):
        if not enabled():
            print("管理台未启用:本容器环境里没有 STA_ADMIN_PASSWORD / STA_ADMIN_PASSWORD_HASH,"
                  "签不出能被 web 认可的票据。", file=sys.stderr)
            return 2
        try:
            minutes = int(_opt("--minutes", "0") or 0)
        except ValueError:
            minutes = 0
        ttl = min(max(60, minutes * 60), TICKET_MAX_TTL_S) if minutes > 0 else TICKET_DEFAULT_TTL_S
        tok = issue_ticket(ttl)
        if cmd == "ticket":
            print(tok)
            return 0
        base = (_opt("--base", "") or "http://<你的域名或IP>:<端口>").rstrip("/")
        print(f"应急登录链接({ttl // 60} 分钟内有效,只能使用一次;用浏览器打开即进入后台):", file=sys.stderr)
        print(f"{base}{page_path()}#t={tok}")
        return 0
    print(_cli.__doc__)
    return 1


if __name__ == "__main__":
    import sys
    sys.exit(_cli(sys.argv[1:]))
