"""
settings.py — 配置装载层
================================================================================
优先级:环境变量  >  config.yaml  >  代码内默认值。

- 连接串、票据等敏感/环境相关项走环境变量(STA_ 前缀),便于容器与 CI 注入;
- 抓取参数、预测参数、房间清单走 config.yaml(可读、可版本化);
- 对外暴露一个进程级单例 `settings`(懒加载),各模块 `from .settings import settings`。
"""
from __future__ import annotations

import os
import json
import time
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any, Dict, List

import yaml

from .constants import RARE_LOG_MULTIPLIER_THRESHOLD

# ── 进程时区:整项目统一北京时间 ──────────────────────────────────────────────
# 显示/落库层已在代码内钉死 UTC+8(引擎 ms_to_local/ms_to_date、db._iso 等),
# 此处再把进程默认时区兜底为 Asia/Shanghai,让日志 %(asctime)s、accounts 的
# time.localtime 等"跟随进程时区"的调用同样落在北京时间。
# 仅在操作员**未显式设置 TZ** 时生效(Docker 镜像已内置 TZ=Asia/Shanghai);
# Windows 无 time.tzset,依赖系统时区,但关键数据字段仍由代码钉死不受影响。
os.environ.setdefault("TZ", "Asia/Shanghai")
if hasattr(time, "tzset"):
    time.tzset()


def _env(key: str, default: str | None = None) -> str | None:
    v = os.environ.get(key)
    return v if v not in (None, "") else default


def _env_float(key: str, default: float) -> float:
    v = _env(key)
    try:
        return float(v) if v is not None else default
    except ValueError:
        return default


def _env_int(key: str, default: int) -> int:
    v = _env(key)
    try:
        return int(v) if v is not None else default
    except ValueError:
        return default


@dataclass
class UpstreamCfg:
    base_url: str = "https://mapi.tencentmusic.com"
    request_timeout: float = 15.0
    verify_tls: bool = False   # 默认不校验上游 TLS 证书(运维要求;config.yaml/配置中枢可改回)
    # RoundAward 抓取时机(真机实测:结果备战后 ~1s 即生成,远早于 drawTime/endTime)。
    # award_after_seal:备战(spellTime)后多久去取(秒)。这是新的主锚点。
    # award_delay:退化兜底 —— 仅当 MainPage 未给 spellTime 时,退回盯 drawTime + 该值。
    award_after_seal: float = 1.5
    award_delay: float = 2.5
    award_retry_interval: float = 1.5
    award_max_retries: int = 11       # 配密化 10 档阶梯(worker 内表,3.3.9 谷段+18/21/24):含真机 HAR 实证的局内~45s 尾巴档
    # 补漏校验 = 缺口驱动的覆盖哨兵(worker._coverage_check,无开关、恒开):检出
    # 「真漏抓」(库里无、且未确证官方缺失)才调用 GameHistory;数据完整时**零调用**;
    # 官方本身缺失/页窗外不可达的局确证一次登记(offmiss)后绝不复打。
    # (旧「每 N 局盲扫」的 history_mode/history_every_rounds 已移除 —— 哨兵在
    #  9 场景真机仿真 + 契约测试下全面优于盲扫,回退走版本层,旧引擎仍为终极参照。)
    # 预留:异步后端 worker 暂未消费此开关(upstream.lamp_list 已实现但无调用者)。
    # 监控台不依赖跑马灯,保留以便将来接线;目前置 true/false 均无副作用。
    fetch_lamp: bool = True


@dataclass
class SchedulerCfg:
    award_jitter_ms: int = 1200
    mainpage_jitter_ms: int = 4000
    mainpage_min_interval_ms: int = 8000
    award_backoff_ms: int = 1500
    claim_batch: int = 200
    janitor_interval_s: int = 30
    # 任务租约:领取即把可见时间顺延这么久,期间别的副本不会重复领取。
    # 15000 → 30000(真机审计):旧值**恰好等于** upstream.request_timeout(15s)——
    # 一个刚好跑满超时的慢请求,租约在它返回的同一瞬间到期 → 任务被别的副本重复领取
    # → **对同一个房重复打上游**,而这恰恰发生在上游已经很慢的时候(雪上加霜)。
    # 租约必须 > 单任务最坏耗时:令牌等待(RL_MAX_WAIT_S=8s)+ 请求超时(15s)= 23s,
    # 故取 30s。代价:worker 崩溃后其在飞任务的重投延迟由 15s 变 30s(仍 < 一局 50s,
    # 且 janitor 30s 巡检兜底),不丢局。
    stale_task_grace_ms: int = 30000


@dataclass
class RateLimitCfg:
    # === QPS 限流默认全部关闭(0 = 不限制)===
    # 令牌桶在 rate<=0 时退化为 no-op、始终放行。需要限流时把对应 *_rps 设为正值
    # (例:upstream_rps: 300),burst 会随之生效。config.yaml / STA_ 环境变量均可覆盖。
    upstream_rps: float = 0.0        # 游戏 API 全局 QPS;0=不限制
    burst: float = 600.0             # 仅当 upstream_rps>0 时生效
    per_room_min_interval_ms: int = 0  # 单房最小请求间隔(防自旋安全网);0=关闭
    # 繁星归一(fanxing/service.kugou.com)专用全局令牌桶 —— 与上游游戏 API 完全
    # 独立的一路。批量添加数千房时,房号归一(短号→真实号)会瞬间打出成百上千
    # 请求到繁星网页/接口;这不是游戏 API。此桶可把该路 QPS 钳住,避免惊群触发酷狗
    # 反爬导致 IP 被限。**默认不限制(0)**;若归一被封 IP,把 fanxing_rps 设为正值即可。
    # 注:即便不限流,批量准入仍有 canon_concurrency 并发上限 + 跨进程归一缓存兜底。
    fanxing_rps: float = 0.0         # 繁星归一 QPS;0=不限制
    fanxing_burst: float = 240.0     # 仅当 fanxing_rps>0 时生效


@dataclass
class AdmissionCfg:
    """批量准入(bulk-add)控制 —— 「同时添加数千房」的削峰核心。

    一次性添加 N 房时,准入控制器把三件危险的事变安全:
      · 归一并发有界(canon_concurrency)+ 走繁星令牌桶,不再惊群;
      · 起抓任务在一个热身窗口(warmup_window_ms)内均匀铺开,不再全挤同一毫秒
        造成令牌竞争的『重排风暴』;
      · 库写入/名录写入批量化(batch_size),不再逐房往返。
    """
    canon_concurrency: int = 32       # 归一阶段的最大并发(叠加繁星令牌桶双重约束)
    # 首次 MainPage 起抓在此窗口内均匀铺开(错峰起抓)。20s→60s:1 万房批量准入/
    # 重启回灌时,每房首抓还会连带一次 GameHistory 回填 —— 20s 窗口下 ≈1000 rps
    # 瞬时洪峰(同时砸上游与 PG);60s 降到 ≈333 rps。代价仅首帧晚 ≤40s,且回填补齐不丢局。
    warmup_window_ms: int = 60000
    batch_size: int = 500             # last_seen 落 PG 镜像的批量 upsert 单批行数
    max_bulk: int = 20000             # 单次批量添加允许的最大房数(护栏)


@dataclass
class RetentionCfg:
    """数据保留(每房历史数据滚动窗口)。

    每个主播(房间)的出怪/预测历史默认只保留最近 days 天,由 worker 周期性
    分批清理(跨 worker 副本经 Redis 锁互斥,同一周期全局只跑一次)。
    days<=0 表示关闭清理、永久保留(旧行为)。
    """
    days: float = 1.0                 # 保留天数;<=0=永久保留(关闭清理)
    sweep_interval_s: int = 3600      # 清理巡检周期(秒);兼作跨进程互斥锁 TTL
    batch_rows: int = 50000           # 单批 DELETE 行数(分批删,避免长事务/锁放大)
    max_batches: int = 400            # 单次巡检的批数护栏(超出留给下个周期)
    # ── 5.4.0 数据生命周期:小表的保留策略(调度在 web 进程,见 app/lifecycle.py)──
    # 管理审计(admin_audit)里**会话类**动作(登录/登出/登录失败/人机验证未过)的保留
    # 天数;**操作类**动作(改配置、发卡、删卡墓碑…)是证据,永久保留、不受本项影响。
    # 默认 184 = 任意连续六个自然月的最长天数(见 userauth.log_retention_days 的注)。
    # 0 = 不清。会删除安全审计,故与 userauth.log_retention_days 同一口径:只能在服务器上
    # 改(环境变量 / config.yaml),管理台只读 —— 拿到管理台会话的人不能顺手抹掉自己的登录痕迹。
    audit_days: int = 184
    # 状态回收:房间已离场(不在册)且其历史已随保留期清空 → 回收它的预测器状态
    # (predictor_state)与名录里的停用墓碑行(rooms)。此前这两类行没有任何删除路径。
    # 关掉 = 退回旧行为(只增不减)。判据与安全边界见 db.gc_predictor_state 注。
    state_gc: bool = True


@dataclass
class DiscoveryCfg:
    """直播间自动发现(每 interval_s 遍历一次繁星在播房间列表,自动纳入后台抓取)。

    发现到的房**只进运行态(Redis 名录 + 调度队列),不落 PG rooms 表** —— 故 PG
    rooms 保持「用户显式添加的策展列表」,前端只显示后者(自动发现房被前端过滤掉,
    见 web._build_live_rooms)。发现房照常被 worker 抓取,其出怪/预测数据进 PG
    (即「自动统计数据」)。唯一持久化的是 last_seen 时钟(PG discovered_rooms 表,
    与 rooms 表无关),供 7 天离线回收计时跨重启存续;worker 启动时据此回灌运行态。
    """
    enabled: bool = True              # 总开关;false 时 worker 不跑发现循环
    interval_s: int = 60              # 遍历周期(秒);兼作跨 worker 副本互斥锁 TTL
    # 单轮分页护栏。**实地核查**:在播列表 ~49 房/页 → 1 万房 ≈ **204 页**。
    # 旧默认 200 恰好卡在 1 万房门槛上(200×49 ≈ 9800 < 10000)—— 上游一到 1 万房
    # 就**静默截断**(stopped_by="max_pages"),尾部的房永远发现不到。取 400(≈2 万房)
    # 留一倍余量;护栏只防"异常翻页无限翻",取大不产生任何额外请求(正常遍历遇
    # hasNextPage=0 即止)。
    max_pages: int = 400
    request_timeout: float = 10.0     # 单页请求超时(秒)
    page_delay_ms: int = 0            # 相邻两**波**之间的礼貌间隔(0=不停顿)
    # 波次并发翻页度(3.4.0)。旧实现逐页串行,实测单页 RTT ~390ms:
    #     1 万房(204 页)串行 ≈ 99s  >  发现锁 TTL(= interval_s,默认 60s)
    # → 锁在遍历途中过期,别的副本插队开第二轮并发遍历(把繁星打成惊群 —— 恰是
    #   本设计要避免的事,却在上游达到 1 万房时必然发生)。并发 8 后 204 页实测
    #   ≈12s,对 60s 周期恢复 5 倍余量。详见 discovery.sweep 头注释。
    page_concurrency: int = 8
    # 新发现房首抓错峰窗口。20s→60s:1 万房冷启动(Redis 无持久化,重启即全量重播种)
    # 时,每房首次 MainPage 还会连带一次 GameHistory 回填 —— 20s 窗口下 = 10000/20×2
    # ≈ **1000 rps** 瞬时洪峰(同时砸向上游与 PG);60s 窗口降到 ≈333 rps。
    # 代价仅为个别房首帧数据晚 ≤40s,且 GameHistory 回填会把这期间的局补齐,不丢数据。
    warmup_window_ms: int = 60000
    conn_limit: int = 32              # 发现器 aiohttp 连接器并发上限
    batch_size: int = 500             # 名录/调度批量写入单批行数
    # 回收:发现房连续 prune_grace_s 未再出现在在播列表中即判定长期停播,回收其抓取
    # (从名录/队列移除,已采集的历史数据保留在 PG)。<=0 = 永不回收(只增不减)。
    # 注:在播列表是**推荐流**,数日未出现≠一定停播(主播可能间歇开播但没被带出);
    # 故 grace 取 **7 天**:加入后台后,连续 ≥7 天检测不到才移除。期间该房照常被抓取
    # (直抓不依赖列表在不在榜),一旦真实开播数据不漏。last_seen 时钟持久化在 PG
    # discovered_rooms 表,worker 重启回灌 —— 重启不清零 7 天计时。
    prune_grace_s: int = 604800       # 7 天 = 7*24*3600
    # 覆盖列表接口地址/查询参数(通常无需改;上游变更时可经 config 覆盖)。
    list_url: str = ""                # 空=用 discovery.DEFAULT_LIST_URL
    params: Dict[str, Any] = field(default_factory=dict)   # 合并进默认查询参数
    # 核验准入:在播列表是推荐流,频道房(roomType=3)从不上榜、低流量房也常年不
    # 上榜 —— 这类房后台没有开播记录,用户永远加不进来。开启后 /api/monitor/add
    # 对「后台不存在」的房改经 roomStatus 核验:此刻在播即放行,并记入 PG
    # verified_rooms 台账(核验房 = 自动发现看不见的发现房,在播记录由 roomStatus
    # 供货)。台账内 prune_grace_s 之内的房再次添加免核验;超期自动清出台账。
    verify_enabled: bool = True
    # 核验房复核周期(秒):worker 对台账内的房按此周期复核在播状态以刷新台账时钟。
    # 策展态核验房直接复用 livestatus 的 90s 观测、发现态复用 last_seen,两者零请求;
    # 只有解绑后仍在台账里的房才真正发请求。每房独立随机相位(0.75–1.25 倍周期),
    # 避免固定时刻复核对「每晚固定时段开播」的主播确定性漏判。
    verify_interval_s: int = 86400


@dataclass
class LiveStatusCfg:
    """主播直播状态(5.0.6:名录 .ri-live 由装饰位改为状态位)。

    判据分两级,**实地核查定案**(2026-08-12 真机实测,勿凭印象改):

      ① 在册即在播(零成本正信号)。在播列表遍历(discovery.sweep)本就每
         interval_s 跑一轮,其 rooms 全集**含策展房**(reconcile 只是不把策展房
         写进发现集)。实测:列表在册房 2 分钟后逐个复核 roomStatus,60 房中
         59 房仍 liveStatus=1 —— 在册是极可靠的正信号,顺手记一笔即可,零请求。
      ② 缺席不算下播,须逐房 roomStatus 定谳(权威)。列表是**推荐流**:
         45s 两轮实测 A=1373 / B=1387,A∖B 的 17 房逐个复核,**6 房(35%)仍在
         直播** —— 只看列表会让绿点无规律闪灭;更硬的反例是频道房(roomType=3,
         本项目固定房 321→2678075 即是)**从不出现在列表里**,只看列表等于对每个
         新用户的第一个房永久撒谎「未开播」。故列表缺席的策展房逐个打
         service1.fanxing.kugou.com/roomcen/room/web/roomStatus(starmeta 早已
         在解析该接口,只是把 liveStatus 丢掉了)。

    成本(实测):单请求 350–800ms、60 房并发 16 → 3.2s 全 200、上游无限流;
    探测只覆盖**策展房**(前端可见房,该部署百房量级),60s 周期最坏 1.7 rps,
    且经繁星令牌桶(与归一/遍历同一路),max_probe 再给一道硬闸。

    纪律:**只有成功观测才改判**。网络/上游失败一律不写,保留上一次观测并让它
    自然变陈;陈到 stale_s 之外由 web 降为「未知」交前端画灰环 —— 绝不把
    「问不到」画成「没开播」(与 3.9.5 名录角标诚实化同一条戒律)。
    """
    enabled: bool = True              # 总开关;false = worker 不跑探测、web 不下发 live 字段
    interval_s: int = 60              # 探测周期(秒);兼作跨 worker 副本互斥锁 TTL
    fresh_s: int = 90                 # 观测保鲜期:年龄超过它才值得再探(默认 = 遍历周期 60s + 余量,
                                      #   使「常驻在播列表的房」恒被 ① 覆盖、永不消耗探测预算)
    stale_s: int = 600                # 观测有效期:web 只在年龄 ≤ 它时下发 true/false,超出即 null(未知)
    max_probe: int = 300              # 单轮探测房数硬闸(最旧优先轮转);策展房超过它时分轮覆盖
    concurrency: int = 16             # 探测并发(实测 16 并发 60 房 3.2s;再大对繁星不礼貌)
    request_timeout: float = 8.0      # 单房探测的**外层**天花板(令牌桶等待 + HTTP 全算)。
                                      #   HTTP 那一段另受 StarMeta 会话超时(6s)先兜住 ——
                                      #   本项调到 6s 以下才真正夹住 HTTP。它同时决定
                                      #   上游不可达时一轮最坏耗时 = ⌈max_probe/concurrency⌉
                                      #   × 本值(默认 19×8s ≈ 152s > 锁 TTL,故锁必须续租)


@dataclass
class HistModeCfg:
    """后台发现房的 GameHistory 轮询模式(hist-mode,3.5.0)。

    动机(实地核查账本):舰队主体是 7 天并集的自动发现房,它们走与策展房完全
    相同的实时管线(每局 1 MainPage + ~1 RoundAward ≈ 2 req/50s),而这些实时
    产出**没有任何实时消费者**——前端恒过滤发现房、SSE 每连接单房零订阅、预测
    已被 3.4.5 策展闸停掉。启用本模式后,发现房不再打 MainPage/RoundAward,
    改为每 interval_s 一次 GameHistory 整页(近 30 局)批量入库:
        万房稳态 430 req/s → 默认 T=900s ≈11 req/s(T=300s 时 ≈33;
        仿真台 T=300/900 实测均零数据洞)。
    策展房(用户真正在看的房)管线**零改动**;转正即有机切回实时管线。

    硬约束(信息论,不可谈判):GameHistory 页窗固定近 30 局 = 30×50.001s
    ≈ 1500s。两次**成功**轮询间隔一旦超过它,滑出页窗的局永久不可再取得
    (仿真反例:T=1800s → 42 洞)。因此:
      interval_s 代码侧钳到 ≤ (30−4)×50.001s ≈ 1300s(worker.effective_hist_interval_ms);
      失败退避带**前瞻投影**——若 (距上次成功 + 本次退避) 会越过 edge_after_s,
      改用 edge_retry_s 抢救节拍,保证越窗前有 ~6 次机会;
      真越窗后逐格登记「官方缺失」(与既有 S6「页窗外数学上不可达」同语义)
      并计入 stats:histmode 的 window_lost —— 丢了就大声说,绝不静默。
    """
    enabled: bool = False             # 总开关;默认关(灰度);热更即时、双向有机迁移
    interval_s: int = 900             # 轮询周期(秒);推荐 120–900,代码钳 60..1300
    retry_base_s: int = 90            # 失败退避基步(90→180→cap,逐跳翻倍)
    retry_cap_s: int = 300            # 失败退避封顶
    edge_after_s: int = 1200          # 距上次成功超过它 = 距越窗仅 ~2 局,进入抢救节拍
    edge_retry_s: int = 45            # 抢救节拍(±1/3 抖动)
    # ── curated-idle(3.7.0):空闲策展房降级(依赖 enabled=true;默认关) ──
    # 动机:名录房经 monitor/add 加入后永不自动退出,「加过就忘」的僵尸房永远
    # 付全额实时管线 + 预测引擎(3.4.5 后策展房是唯一还跑预测的角色,5.5ms/局)。
    # 本子模式把 3.4.5/3.5.0 的原则补完整 —— 实时资源 ⟺ 存在实时消费者:判据
    # 从「在名录里」收紧为「近期真被访问过」。冷房仍在名录/前端可见,只是暂以
    # GameHistory 轮询供数、预测暂停(权重只冻结不损坏,醒来带训练充分的权重)。
    # 非对称铁律(is_discovered「判不出按策展走」同源):
    #   降级 = 慢、保守、可逆:最近访问年龄 ≥ after_s **且** draws:{room} 零
    #          订阅(SSE 观众一票否决;年龄未知只播种不判闲),janitor 锁内
    #          ≤1 扫/分钟、每扫 ≤ batch;仅打冷标,迁移交给该房**下一拍 mp**
    #          经既有 3.5.0 迁移入口有机改排(零新迁移机器,结构上无风暴);
    #   唤醒 = 瞬时、激进:任意一次用户侧真实访问(history[非 passive]/days/
    #          prediction/summary/coverage/SSE 连接)当场清标 + mp@now +
    #          hs 封尾 —— 即 monitor/add 转正同款序列,预测号随补链立即再生。
    # 影子先行:shadow=true 时只把「本会降级的房集」写进 stats:histmode
    # (cold_would*)与状态页 curatedIdle 块,不动作;核对吻合后再翻 enforce。
    curated_idle_enabled: bool = False   # 空闲策展房降级总开关
    curated_idle_shadow: bool = True     # 影子模式:只观测不降级(灰度第一档)
    curated_idle_after_s: int = 1800     # 判闲阈值(秒):访问年龄 ≥ 该值才成候选
    curated_idle_batch: int = 200        # 单次扫描降级上限(集体空闲的削峰护栏)


@dataclass
class AuthCfg:
    app_id: str = "1000756"
    uid: str = "88267254"
    ticket: str = "PUT_YOUR_FRESH_X_AUTH_TICKET_HERE"
    token_type: str = "1010"

    def to_headers(self) -> Dict[str, str]:
        return {
            "x-auth-app-id": str(self.app_id),
            "x-auth-uid": str(self.uid),
            "x-auth-ticket": str(self.ticket),
            "x-auth-token-type": str(self.token_type),
        }


@dataclass
class UserAuthCfg:
    """登录系统(3.8.0):以外部 MySQL 5.7 用户库(tb_user)做身份识别。

    · `host` 留空 = **登录系统整体关闭**,一切端点/页面维持 3.7.0 原行为
      (本地开发、测试套件与未配置用户库的旧部署零影响)。
    · 用户库是**既有业务库**(注册/续费由外部系统负责):本项目对 `tb_user`
      **绝对只读**,新建的会话/审计表全部带 `guantai_` 前缀,不触碰任何已存在表。
    · 现有库默认 gbk、user_name 列 gbk_bin —— 必须以 gbk 连接,中文用户名才不乱码
      (aiomysql 会按连接字符集编解码参数;gbk_bin 同时意味着用户名**大小写敏感**)。
    """
    host: str = ""                     # MySQL 主机;留空 = 登录系统关闭
    port: int = 3306
    db: str = ""                       # 库名(如 fanxing_changkong_user_db)
    user: str = ""
    password: str = ""
    charset: str = "gbk"               # 现有库默认 gbk;user_name 列 gbk_bin
    user_table: str = "tb_user"        # 登录识别表(只读;结构见该表 DDL)
    # ── 多网络入口(4.5.0)────────────────────────────────────────────────────
    # `host` 可填**一组**「同一逻辑库的网络入口」:`ip[:port][*权重]`,逗号分隔。
    # 场景:单个弹性 IP 的公网出口带宽有限,给同一台 MySQL 绑多个 EIP(或多台端口
    # 转发机),客户端按可用性与权重分流,把带宽横向摊开。单值 = 一个入口 = 与
    # 4.4.x 逐字节同行为。**前提是同一个 mysqld** —— 若填了从库/别的库,运行期
    # 探活会以身份指纹当场识破并永久隔离该入口(见 userdb_pool._check_identity)。
    pool_max: int = 8                  # **全部入口合计**的连接预算;每入口 ≥2 条
    #   想真正吃满多入口带宽,把它调到「入口数 × 8」量级;默认与 4.2.0 单池 maxsize
    #   同值,升级不会给共享的用户库带去意外连接压力。
    query_timeout_s: float = 15.0      # 单条查询的总预算(取连接+执行),秒
    #   aiomysql 0.2.0 **只有 connect_timeout、没有 read_timeout**(已逐字核对驱动
    #   源码)。入口带宽打满时 TCP 还活着但数据不走,没有这个超时就会无限期挂住,
    #   连「该入口不可用」都探测不出来。0 以下无意义,代码内钳到 ≥1s。
    probe_s: float = 10.0              # 入口探活间隔(秒):测 RTT + 校验身份 + 保温连接
    # 会话
    session_ttl_h: float = 24 * 30.0   # 绝对有效期(默认 30 天,与管理台同款)
    idle_ttl_h: float = 24 * 7.0       # 空闲有效期(7 天未活动需重登;≤0 = 不启用)
    single_device: bool = True         # 单设备互顶(与同库 sys_account_session 的业务惯例一致)
    max_sessions: int = 3              # single_device=False 时,每用户并发会话上限
    cache_ttl_s: float = 20.0          # 会话进程内缓存(用户库在公网,逐请求 RTT 不可接受)
    outage_grace_s: float = 600.0      # 用户库故障期:已验证会话的降级放行窗口(秒;0=关)
    # 名录/风控
    room_max: int = 50                 # 每账号名录上限(必须与前端 MAX_ROOMS 同值)
    # ── 单账号「同时只监控 1 个房」+ 明细读限流(安全加固 3.9.0) ──────────────
    # active_room_lease:每账号同一时间只放行 1 个**活跃**监控房(多标签页/多设备)。
    #   与 room_max 正交 —— 名录可存多个房(收藏),但同时只能有 1 个在实时拉数据。
    #   同一标签页换房、同房多视图不受限;异标签页盯异房被拒(前端弹提示)。
    #   仅在登录系统启用且请求带登录身份时生效;未登录/运维旁路一律不约束(旧行为)。
    active_room_lease: bool = True
    # 租约 TTL(秒):SSE 20s 心跳与明细轮询持续续租;标签页关闭停续 → 到期自动释放。
    #   须 > SSE 心跳周期(20s)方能被一条常开 SSE 稳定续住;默认 40s。
    active_room_lease_ttl_s: float = 40.0
    # 每账号明细端点(prediction/summary/coverage/history[非 passive])读限流:
    #   平均 QPS 与突发桶容量。**注意:SSE(/api/events)不在此闸内**(审计更正 —— 旧注释
    #   误称覆盖 SSE)。SSE 的护栏是「roster 门 + 活跃房租约 + 一条流只推一个房」,
    #   其建流频次由租约 hash 的 tab 上限(_LUA_LEASE_ACQ 的 CAP)兜底。
    #   阈值宽松 —— 真人单房浏览(每局 ~50s、每秒至多数次轮询)
    #   远达不到;纯脚本高频搬运会被削平。0 = 不限流(默认给正值即启用)。fail-open:
    #   Redis 异常时放行,绝不因协调层抖动误伤真人。
    detail_rate_rps: float = 4.0
    detail_rate_burst: float = 40.0
    # ── L2:执行证明闸(proof-of-browser,安全加固 3.9.1;3.9.2 起**默认开**) ────
    # proof_of_browser:开启后,明细端点(prediction/summary/coverage/history 含
    #   passive)要求请求带一枚**只有执行了前端混淆 JS 才能算出**的应答头 X-JF-Proof
    #   —— 纯 API 搬运器(curl/requests,不跑 JS)因算不出应答被 401 proof_required
    #   挡在门外。**诚实边界**:无头浏览器(会真跑 JS)与逆向了变换 T 的人仍能通过,
    #   它抬高成本、不设墙;与登录/单房租约/限流叠加,专打「拿着 Cookie 的无 JS 搬运」。
    #   **3.9.2 默认开**(运营方明确要求)。⚠️ 前提:客户端须加载到含 powAnswer 的
    #   新版 app.js —— index.html 已 bump ?v(HTML no-cache,新开页自动取新包);
    #   升级瞬间**已打开的老页面**在刷新前会 401(内存里旧 JS 无 powAnswer),提示刷新即可。
    #   fail-open:Redis 异常一律放行,绝不因协调层抖动误伤真人。置 0 可一键退回旧行为。
    proof_of_browser: bool = True
    # ── L4:行为遥测「疑似脚本来源」画像(安全加固 3.9.2,**纯遥测 / 不阻断**) ──
    # signal_scoring:开启后,后端为每个会话累积一份滚动行为画像(是否加载过页面
    #   HTML、明细请求量、是否走完 L2 证明链、短时轮转房间数、UA 等),在管理台
    #   「疑似脚本来源」面板按可解释因子打分呈现,供人工研判。**它绝不自动封禁**:
    #   自动动作只由 L1 租约违规 / L2 证明缺失等**确定性事件**触发;软信号至多用于
    #   面板高亮与「更严格的限流分层」(减速而非拦截,真人无感)。fail-safe:任何
    #   遥测异常都静默吞掉,绝不影响主请求。默认开(廉价、只读、无副作用)。
    signal_scoring: bool = True
    # 画像滚动窗口(秒):画像键按此 TTL 过期,面板只看窗口内的活跃会话。
    signal_window_s: float = 1800.0
    # 挑战有效期(秒):前端在 **0.75×ttl** 处主动续铸(4.9.0),不再等 401 被动重铸。
    proof_challenge_ttl_s: float = 180.0
    # ── 4.9.0 误报修复:挑战**轮转宽限**(秒) ─────────────────────────────────
    # 背景(实地复现):挑战键此前只有一把 `powchal:{sid}`,而 sid = sha256(会话
    # Cookie) —— **同一浏览器的所有标签页共用它**。A 页 mint 会直接覆盖 B 页正在
    # 用的挑战,B 页下一拍必 401;B 页重铸又反过来废掉 A 页 …… 实测 12 拍交替产生
    # 14 次 pow_fail、只有 1 次 pow_ok,真人被刷成「执行证明失败 N 次」。
    # 双管齐下:① 挑战键按标签页分号(见 web._pow_key,前端本就在发 X-JF-Tab);
    #           ② 每次 mint 把**旧挑战**转存 `:p` 短活键,宽限期内仍然认 —— 在飞
    #              请求(带的是旧应答)不再变成一次假失败。
    # 安全面:宽限只是把**已经签发过**的挑战多认几十秒,攻击者仍必须跑 JS 才算得出
    # 应答;绑定 sid 的性质不变。置 0 = 关闭宽限(退回 3.9.x 行为)。
    proof_rotate_grace_s: float = 45.0
    # ── 4.9.0:浏览器足迹保留期(秒) ───────────────────────────────────────
    # 见过 html/asset(浏览器专属事件)时另置一枚长效小键;评分据此判断「这个会话
    # 里究竟有没有真浏览器开过页面」,不再依赖恰好落在滚动窗内的一次性 html 计数。
    # 默认 24h,远长于画像窗;每会话 1 键 ~50B,随 TTL 自然消亡,内存严格有界。
    signal_footprint_ttl_s: float = 86400.0
    # 首登预置房「真实号:展示短号」:账号**第一次**登录成功时自动写入其名录
    # (默认即需求固定房 321,真实号 2678075,见 config.yaml rooms/room_aliases)。
    # 留空 = 关闭;环境变量侧因空串被视作未设置,用 off/none/0 表示关闭。
    first_login_room: str = "2678075:321"
    login_fail_user: int = 10          # 失败节流:窗口内同用户名上限
    login_fail_ip: int = 30            # 失败节流:窗口内同 IP 上限
    login_fail_window_s: int = 600     # 失败计数窗口(秒)
    login_lock_s: int = 600            # 触限后的锁定时长(秒)
    banned_values: str = "1"           # is_off 视为封停的取值(逗号分隔;库里 varchar(1))
    # Cookie
    cookie_name: str = "jf_user_sid"
    cookie_secure: str = "auto"        # auto=按请求协议 / on / off
    # guantai_login_log 保留天数(0=永久)。5.4.0:默认 90 → **184**。
    # 依据:《网络安全法》(2025 修正,2026-01-01 施行)第二十三条第(三)项(修正前为
    # 第二十一条)要求网络运营者「留存相关的网络日志不少于六个月」;登录流水正是这类
    # 日志,旧默认 90 天不足半年。取 184 而不是 180:任意连续六个自然月最长是 184 天
    # (如 7/1→1/1、3/1→9/1),写 180 会在含大月的半年里少留 1~4 天。
    # 已在 .env 显式写过 STA_USER_LOG_RETENTION_DAYS 的部署不受默认值变化影响。
    log_retention_days: int = 184
    # 登录 / 注册流水的**行数上限**(各自生效;0=不设)。保命阀:只按时间保留时,
    # 一轮撞库能把保留期内的流水灌到任意大(每个失败口令一行);超过上限即裁掉最旧的。
    # 默认 500 万行:真库实测每行 ≈268 字节(含两个二级索引)⇒ 封顶 ≈1.3 GB;
    # 每天 2 万次登录的站点 184 天也才 370 万行,正常运行永远摸不到这条线。
    # 摸到时管理台「储」视图会标红(= 正在被灌),而不是静默丢历史。
    # 低于 10 万按 10 万执行(防少打几个 0,见 userauth._LOG_CAP_MIN);会删除登录证据,
    # 只能在服务器上改,管理台只读(与 log_retention_days 同一口径)。
    log_max_rows: int = 5_000_000
    # 节流分桶的 IP 来源(5.2.0 起为「可信代理」口径,见 app/clientip.py):
    #   True =**仅当直连对端属于可信代理**(trusted_proxies,默认环回 + 内网)时才采信
    #         X-Forwarded-For,并从最右往左取第一个非代理跳 —— 直连部署(对端是公网
    #         客户端)天然免疫伪造,同机/同 Docker 网络的反代照常生效;
    #   False=只认直连 request.client.host。
    # 旧口径「True = 无条件取 XFF 首跳」在直连部署下可被任意伪造(实证:每请求换一个
    # 假 XFF 即绕过按 IP 节流;管理台白名单同理可绕)。
    trust_forwarded_for: bool = True
    # 可信代理(逗号分隔):loopback / private / CIDR / none / *。用户登录、注册、管理台
    # 白名单与 L4 画像共用同一判定;**以环境变量 STA_TRUSTED_PROXIES 为准**(只读展示)。
    trusted_proxies: str = "loopback,private"
    # ── 登录防爆破(5.2.0):先占后验 · 分级加码 · 设备信任 · 全局攻击态 ──────────
    # 设计/实证见 LOGIN-SYSTEM.md §4.5。硬上限仍是上面的 login_fail_user/ip。
    # 软阈值(达到即要求加码:本站 PoW,开了人机验证再叠验证码):
    #   -1=自动(硬上限的 1/3,至少 3,不超过硬上限)/ 0=关 / N=显式。
    login_stepup_user: int = -1
    login_stepup_ip: int = -1
    login_pow_bits: int = 16           # 加码 PoW 基础难度(前导零位;高压 +2、攻击态再 +2,硬顶 22)
    login_chal_ip_10m: int = 30        # 每 IP 段 10 分钟可领取的加码挑战数(超出 429)
    login_device_ttl_d: int = 90       # 设备信任 Cookie 有效期(天);0 = 关闭设备信任
    login_attack_5m: int = 50          # 全局攻击态:近 5 分钟全站登录失败 ≥ 此值 → 未受信设备一律加码;0=关
    # 登录时的人机验证:off=不用 / risk=只在可疑时(达软阈值或全局攻击态;推荐)/ always=每次登录。
    # **供应商与凭据和注册共用一套**(下方 reg_captcha*,即 STA_USER_REG_CAPTCHA / _ID / _KEY /
    # _SECRET_*;名字沿用以兼容已有部署)—— 一个站点只配一个验证码账号,这里只决定「何时要」。
    #   ⚠ Cloudflare 官方文档写明 Turnstile **不支持中国大陆**;大陆用户为主请选 tencent/geetest。
    login_captcha: str = "off"
    # ── 注册系统(4.0.0):前端自助注册 · 防恶意注册纵深 R0–R8 ──────────────────
    # 设计/纪律/威胁模型见 REGISTER-SYSTEM.md。**不配置即不存在**:reg_mode=off
    # (默认)时,注册端点回 503、前端不渲染入口,全项目行为与 3.9.5 一致。
    # reg_mode:off=关闭 / invite=邀请码注册(推荐起步)/ open=开放注册。
    #   热更(管理台「注」视图一键切换,走 rev 收敛广播);前置条件:登录系统已
    #   启用且 reg_pass_shape 已配,否则强制视作 off 并启动告警。
    reg_mode: str = "off"
    # 新用户口令入库形态:plain / md5 / sha1 / sha256(空 = 注册不启用)。
    #   **必须与你外部续费系统登录时能校验的形态一致**(跨系统契约,只有运营者能
    #   拍板)—— `userdb_check.py --reg-preflight` 会按库里多数派给建议值。
    #   sha256 仅当 pass_word 真实列长 ≥64 才可用(varchar(50) 物理放不下 64 hex;
    #   运行期会对 information_schema 做一次列长实测,不合格即拒注册,绝不静默截断)。
    #   md5/sha1/sha256 摘要一律取口令 UTF-8 字节(与登录侧 verify_password 同口径)。
    reg_pass_shape: str = ""
    # open 模式注册赠送天数(due_time = NOW()+N 天;0=零赠送,注册完连登录都过不去,
    # 恶意注册产出≈0 —— R0 经济闸)。invite 模式忽略此值(赠送随邀请码)。
    reg_trial_days: int = 0
    # tb_user 额外必填列映射(JSON,如 {"create_time":"$now","qq":""})—— 真实表若有
    # 「NOT NULL 且无默认」的其它列,照抄预检工具输出即可。列名白名单 [A-Za-z0-9_],
    # 取值全部参数化,"$now" 展开为 NOW()。留空 = 只写基础四列。
    reg_extra_cols: str = ""
    # PoW 基础难度(SHA-256 前导零位)。自适应只升不降(同 /24 高频、全局水位、
    # 同指纹超限时加位),硬顶 25;主流手机纯 JS 约 0.3–1.5s(以真机实测为准)。
    reg_pow_bits: int = 17
    reg_chal_ttl_s: int = 600          # 挑战有效期(秒;亦是最长填表时长)
    reg_min_fill_s: int = 3            # 最短填表时长(秒;挑战签发→提交,秒提交=脚本铁证)
    # 人机验证(R3,可插拔,默认关):off / tencent / geetest / turnstile。
    #   大陆部署选腾讯云或极验;Turnstile 的 challenges.cloudflare.com 大陆访问
    #   慢/不稳定,仅海外部署选用。校验网络异常 → 503 fail-closed。
    reg_captcha: str = "off"
    # 5.2.0:注册时要不要过人机验证(供应商选了才有意义)。True=要(默认,与旧行为一致);
    # False=注册不要,供应商只给登录用(配合 login_captcha)—— 运维实际配置里出现过
    # 「注册关、登录 risk」的意图,旧设计里「设了供应商 = 注册一律要过」表达不了。
    reg_captcha_required: bool = True
    reg_captcha_id: str = ""           # tencent=CaptchaAppId / geetest=captcha_id / turnstile=sitekey
    reg_captcha_key: str = ""          # tencent=AppSecretKey / geetest=captcha_key / turnstile=secret
    # 仅 tencent 需要:腾讯云 API 凭据(DescribeCaptchaResult 二次校验用,TC3 签名)。
    reg_captcha_secret_id: str = ""
    reg_captcha_secret_key: str = ""
    # ── R1 服务端限流(确定性;Redis 计数,故障退化为进程内计数 —— 风控组件
    #    故障**不放开**注册;挑战无法落 Redis 时注册回 503,fail-closed) ──────
    reg_ip_hourly: int = 5             # 每 IP 注册尝试/小时(含一切失败)
    reg_ip_daily: int = 10             # 每 IP 注册尝试/日(双窗防慢速滴灌)
    reg_ip_ok_daily: int = 2           # 每 IP 成功注册/日
    reg_chal_ip_10m: int = 10          # 每 IP 挑战签发/10 分钟
    reg_name_10m: int = 3              # 同名尝试/10 分钟(钳单名爆破/占坑拉锯)
    # ── R6 全局熔断(损失有上界):越顶自动降档,**不自动回升**(管理台显式恢复)──
    reg_global_hourly: int = 30        # open:小时成功注册越顶 → 自动降档 invite
    reg_global_daily: int = 200        # open:日成功注册越顶 → 当日关闸 off
    reg_global_daily_invite: int = 500 # invite:日成功注册越顶 → 关闸 off
    # 追加保留用户名(逗号分隔;内置 admin/管理员/root/客服/官方 等名单恒生效)
    reg_reserved: str = ""
    # 零赠送分支的开通指引文案(注册成功但不能立即登录时展示)
    reg_success_hint: str = "注册成功!请联系管理员开通使用时长后登录。"
    # 注册审计保留天数:-1=跟随 log_retention_days;0=永久;>0=按天清扫
    reg_log_retention_days: int = -1
    # ── 链接快速登录(4.1.0,SSO):同库其它项目签发一次性票据 → 观测台凭票换会话。──
    # 默认关(**不配置即不存在**,与注册系统同纪律);guantai_sso_ticket 新表照常
    # 幂等自建(关着也建,零引用)。签发方只需向共享库 INSERT 一行(无共享密钥、
    # 无钟差 —— 时效判定统一走数据库的 NOW()),接入方式见 SSO-LOGIN.md。
    sso_enabled: bool = False
    # 消费侧对票据年龄的硬顶(秒):即使签发方误写超长 expires_at,票据自 created_at
    # 起超过此值一律拒收 —— 票据寿命的上界不受签发方 bug/误配摆布(纵深防御)。
    sso_max_age_s: int = 300
    # ── 账密签发通道(4.3.0):POST /api/auth/sso/link ─────────────────────────
    # 「验账密 → 吐一次性链接」。**默认关**(不配置即不存在:端点回 503,
    # 全项目行为与 4.2.x 逐字节一致)。与 4.1.0 的 INSERT 通道**并存**,共用
    # 同一张 guantai_sso_ticket、同一个消费端点 /api/auth/sso —— 接入方二选一:
    #   · 能连共享库 → 用 INSERT 通道(少一跳、无需密钥),见 SSO-LOGIN.md §2;
    #   · 不便连库/怕接错哈希契约 → 用本通道,一次 HTTP POST,见 §2.6。
    # 安全定位(诚实说明,勿高估):本端点的口令校验与 /api/auth/login **同一实现、
    # 同一套失败节流桶**(userauth._authenticate),故**不额外放大口令爆破面**;
    # 但它也不比 /api/auth/login 更强 —— 库里存量口令多为无盐 MD5,且
    # verify_password 接受「库里存的那串」本身(pass-the-hash)。详见 SSO-LOGIN.md §7。
    sso_link_enabled: bool = False
    # 本通道签发的票据寿命(秒)。由观测台自己写入 expires_at —— 调用方**不能**指定,
    # 代码内另钳 sso_link_ttl_max_s 硬顶;消费侧 sso_max_age_s 年龄硬顶继续叠加。
    sso_link_ttl_s: int = 60
    # 观测台自身的公网 origin(如 https://guantai.example.com),用于拼返回的 url。
    # **留空 = 只回 ticket 不回 url**。刻意不从 Host/X-Forwarded-Host 头推导 ——
    # 那两个头由调用方控制,拿用户可控输入拼「要发给用户去点」的链接是反模式。
    sso_link_base: str = ""
    # 可选的调用方密钥:配了则请求必须带 `Authorization: Bearer <key>`(常数时间比较)。
    # 留空 = 不校验(此时本端点能力**不超过**已公开的 /api/auth/login —— 5.2.0 起两者共用
    # 同一套计数与加码判定,需要加码时本端点直接 429 —— 谈不上新增敞口;但配上就能获得「按调用方限频/审计/吊销」的全部好处)。
    sso_link_key: str = ""
    # ── 九法 VIP 分层与收费(4.2.0)───────────────────────────────────────────
    # **不配置即不存在**:jf_vip_enabled=False(默认)时,档位判定、VIP 闸、
    # 充值端点全部退场,登录/会话/数据面逐字节维持 4.1.2 行为(含「到期即拒登录」)。
    # 开启后语义变化(破坏性,已在 JFVIP-SYSTEM.md §1.1 逐条列明):
    #   · `due_time` 到期不再是登录闸,降级为「free 档」——可建会话但零数据;
    #   · 数据端点按 free/basic/vip 三档分层(_vip_guard);
    #   · 开通 VIP 时对 tb_user.due_time 做全项目**唯一一条** UPDATE(赠送小叮当)。
    jf_vip_enabled: bool = False
    # 档位表(JSON 数组字符串)。字段:code/name/price/jfHours/ddHours/tag。
    #   · jfHours = 九法 VIP 增量;ddHours = 赠送小叮当增量(两者可不等,便于做活动)
    #   · m1/m3 默认对齐小叮当既有卡类型 tb_user_recharge_type.recharge_length
    #     (月卡 744h / 季卡 2232h);d3 无对应卡类型,取自然 72h
    #   · code 一经售出**不可删除**(历史订单要靠它解释),只能改价/停售
    jf_vip_plans: str = ('[{"code":"d3","name":"3 天","price":18,"jfHours":72,'
                         '"ddHours":72,"tag":""},'
                         '{"code":"m1","name":"1 个月","price":88,"jfHours":744,'
                         '"ddHours":744,"tag":"最多人选"},'
                         '{"code":"m3","name":"3 个月","price":188,"jfHours":2232,'
                         '"ddHours":2232,"tag":"最划算"}]')
    # basic 档(九法非 VIP + 小叮当有效)的 history 硬顶:每次请求最多回这么多局。
    #   配合「禁用 until」形成硬闸 —— db.history 的 since 只抬下界、ORDER BY DESC,
    #   故禁掉 until 后无论怎么构造参数都取不到 N 局以前的数据(见 JFVIP-SYSTEM.md §4.1)。
    jf_basic_history_limit: int = 30
    # basic 档「灵机推演」命中信息窗口(局):只给历史命中率与命中串,不给下一局主/防。
    jf_basic_pred_window: int = 100
    # free 档会话有效期(小时):零数据档位,短 TTL 控制会话表膨胀。0=跟随 session_ttl_h。
    jf_free_session_ttl_h: float = 24.0
    # ── 4.4.0:basic 档「在线累计窗」(小时)────────────────────────────────────
    # 语义:basic 档用户**在线期间实际读到过**的局,允许在本机留存并在刷新后回灌,
    #       上限为本窗口时长(锚定最新局起点往回数)。
    #   · 0  = 关闭 = **逐字节回到 4.3.x 行为**(刷新即清零、快照不落地);
    #   · 24 = 默认,与前端 HIST_WINDOW_MS(24h 锚定窗)同值。
    # **这不是一道安全闸,是一条 UX 口径。** 真闸始终在服务端:history 仍钳
    # jf_basic_history_limit 且禁 until(见 §4.1 的数学论证),本项目**没有**因此
    # 多给 basic 档一个字节的新数据 —— 只是不再把他自己看过的东西在刷新时丢掉。
    # localStorage 用户可改 ⇒ 他能伪造自己的序列,但伪造不出预测/回看/coverage
    # (那些每一次都要过服务端闸)。与既有 simWallet/simBets 同一风险面,不新增。
    # 调小(如 6)即缩短 basic 档可留存的窗口;调 0 即完全撤回本特性。
    jf_basic_online_h: float = 24.0
    # ── 支付网关(移植自 fanxing-admin/app/services/recharge_service.py)────────
    jf_pay_base: str = "https://pay.lonlonsoft.com"
    # 网关口径:九法用 tulong,**绝不复用**繁星代理余额的 proxy(账目物理隔离)。
    jf_pay_type: str = "tulong"
    jf_pay_timeout_s: float = 10.0
    # 模拟模式:不调真实网关,本地生成占位二维码与订单;仅此开关开启时
    # 「模拟支付成功」端点才会真开通。**生产必须 false**,否则任何人可凭空开 VIP。
    jf_pay_simulate: bool = False
    jf_pay_simulate_ttl_s: int = 300
    # 结算宽限期(秒):订单本地到期后仍在此窗内的查单**继续向网关查证**,
    # 只有超窗且网关仍未确认才标 expired —— 防「扫码已付、网关确认慢几秒」被误判。
    # 须显著大于前端宽限轮询时长(前端 60s)。
    jf_settle_grace_s: int = 90
    # 过期订单可复查窗(秒):expire_time + 本值内仍给一次网关复查,捞回漏账。
    jf_recover_window_s: int = 3600
    # 对账回溯窗(秒)与单次上限:重查本人 pending/expired 订单,救回卡住的到账。
    jf_reconcile_lookback_s: int = 86400
    jf_reconcile_max: int = 10
    jf_reconcile_timeout_s: float = 6.0
    # 每账号每小时对账兜底上限(4.2.2)。reconcile 单次最多查 jf_reconcile_max
    # 笔网关,放大倍数是下单的 10 倍 —— 不限频即白刷网关的杠杆。0=不限。
    jf_reconcile_rate_hourly: int = 12
    # 每账号下单限频(次/小时):九法面向任意注册用户(含 free 档),不限频=替人白刷网关。
    jf_order_rate_hourly: int = 20
    # 每账号卡密兑换失败限频(次/小时):卡号空间 6.4e10 本就不可爆破,仍封顶。
    jf_redeem_fail_hourly: int = 10
    # ── 卡密清理(4.2.8)──────────────────────────────────────────────────────
    # 卡密删除总开关。默认关 = 旧部署逐字节无感(「不配置即不存在」)。
    # 开启后管理台才出现「删除选中」。4.2.9 起**勾中即删、无需先作废**:
    # 未使用 / 已作废 / 已兑换三类一视同仁 —— 包括仍可兑换的卡(那是唯一会
    # 造成资损的一类,前端确认框会把它单独列出来)。删除不可撤销;需要可撤回
    # 的下架请用「作废选中」。自动清扫(下面两项)仍只碰终态卡,不受此影响。
    jf_card_purge_enabled: bool = False
    # 已作废未使用卡的自动清扫阈值,按**卡龄**(created_at)计,0=不清扫。
    # ⚠ 刻意不叫 "retention":表**没有 disabled_at 列**(且禁止 ALTER),
    #   无从得知一张卡是什么时候被作废的。叫「保留期」会让人以为买到了
    #   「作废后 N 天内还能恢复」的召回窗 —— 实际上一张两年前发的卡在作废
    #   一分钟后就会被下一轮清扫删掉。名字必须说实话。
    jf_card_disabled_age_days: int = 0
    # 已兑换卡的自动清扫保留期(天)。0=不清扫。真账在 guantai_jf_grant_log,
    # 删卡行不影响对账口径;这里只是给资源池排水。
    jf_card_used_retention_days: int = 0
    # 未支付订单(pending / expired 且未入账)的保留天数;0=永久保留。5.4.0 新增 ——
    # 此前 guantai_jf_order 没有任何清理:每个账号每小时可下 jf_order_rate_hourly 单,
    # 没付款的单永久堆积。**已支付单是账本,任何取值都不会删它**(判据带 credited=0)。
    # 实际执行不低于 7 天(远大于对账回看与过期恢复窗),见 userauth._ORDER_UNPAID_MIN_DAYS。
    jf_order_unpaid_retention_days: int = 184
    # ── 外部发卡 API(4.2.9)────────────────────────────────────────────────────
    # 面向发卡平台/分销系统:POST /api/admin/jfvip/cards/issue 一次拿 N 张
    # **指定时长**的卡密。只认 API Key(与管理台会话物理隔离)。
    # ⚠ 两道都得显式配上才可能发出一张卡:开关默认关、密钥默认空。
    #   这是「不配置即不存在」在危险方向上的取向 —— 本端点是纯价值创造,
    #   没有 sso_link 那条「不配密钥也不构成新增敞口」的退路(见 jfvip 该节)。
    jf_card_api_enabled: bool = False
    # API 密钥。空 = 端点整体 503;长度 <24 亦 503(短密钥可离线爆破,而这里
    # 发出的每张卡都是真金白银)。生成:openssl rand -hex 32
    jf_card_api_key: str = ""
    # 每小时发卡调用上限,**全局按密钥**而非按 IP —— 密钥泄漏后攻击者从任意 IP
    # 打过来,按 IP 分桶等于给他每个 IP 一份配额。0=不限。
    # 默认 60:单次最多 500 张 ⇒ 理论上限 3 万张/时,远超任何真实发卡节奏。
    jf_card_api_rate_hourly: int = 60
    # 可选的来源 IP 白名单(逗号分隔 CIDR)。留空=不限(仅凭密钥)。
    # 配了却一条合法 CIDR 都没有时 fail-closed —— 白名单配错的正确表现是把自己
    # 关在门外,而不是悄悄敞开让人以为它在生效。
    jf_card_api_ip_allow: str = ""
    # ── 站点分流:直营主站 vs 代理镜像站(4.4.1)────────────────────────────────
    # 同一套后端同时对外服务多个域名(直营主站 + 若干代理镜像站)时,按**请求的
    # Host** 决定该站是否提供「在线扫码付款」。镜像站只留卡密开通(代理自己卖卡)。
    #
    # 语义(逐字对照 jf_card_api_ip_allow 的既有取向,但**默认方向相反**):
    #   · 留空 = **特性整体关闭** = 全部 Host 一律按直营 = 逐字节 4.4.0 行为
    #     (「不配置即不存在」;老部署升级上来一个字节都不变);
    #   · 非空 = 特性启用 ⇒ **只有名单内的 Host 是直营**,其余一律按镜像站。
    #     这个方向是刻意的:新代理接进来(把他的域名解析/反代到本服务)**无需
    #     改任何配置**就自动是镜像站,漏配的代价落在"代理少卖一单"而不是
    #     "代理的客户绕过代理直付平台"。反过来做成镜像黑名单的话,每接一个
    #     代理都得记得加一行,忘了就漏,而忘记是常态。
    #
    # ⚠ 这是**业务分区,不是安全边界**。Host 是调用方可控的头(SSO-LOGIN.md §7
    #   同款认识),会伪造头的人照样能下单 —— 但他本来就能直接打开直营站付款,
    #   并没有因此多拿到任何东西。本项要挡的是"镜像站页面上摆着扫码入口"这件事,
    #   以及"F12 把按钮显示出来就能绕过"这种一步可达的绕过。
    #
    # 匹配口径:**精确匹配**(归一化后)。刻意不支持通配符 —— `*.example.com`
    #   会连带命中代理自建的 `agent.example.com`,那正是要防的那一类漏配。
    #   归一化 = 去 scheme/路径、去端口、转小写、去尾随点(见 userauth.norm_host)。
    #   ⚠ `example.com` 与 `www.example.com` 是**两个** Host,两个都用就两个都写。
    jf_direct_hosts: str = ""
    # 是否信任 `X-Forwarded-Host` 头来判定站点。**默认关**。
    #   · 关(默认):只认 `Host` 头。绝大多数反代(nginx `proxy_set_header Host $host`、
    #     Caddy 默认)会把原始 Host 透传过来,这条路是对的;
    #   · 开:优先取 `X-Forwarded-Host` 的**首跳**(最靠近客户端的那个),缺失才回落
    #     `Host`。仅当你的反代把 Host 改写成了上游名(此时所有站点在后端看起来
    #     是同一个 Host,分流会整体失灵)才需要开。
    # 与 trust_forwarded_for 的取向一致:头由谁写,谁才可信;不确定就别信。
    jf_direct_trust_xfh: bool = False
    # ── 客服联系方式(4.4.2)────────────────────────────────────────────────────
    # 4.4.1 的「联系客服购买」是一句**纯提示**,当时刻意不做可配置项,理由记在
    # JFVIP-SYSTEM.md §12.6:「本站有多个来源,每个来源的客服渠道不同且由该来源
    # 自己告知用户,平台这里没有一个『正确的』客服可指」。
    #
    # 那条理由**只在代理镜像站成立**。直营主站上卖家就是平台自己,恰恰存在唯一
    # 正确的客服 —— 所以本次不是推翻 §12.6,是把它收窄到它真正成立的那一半,
    # 而 `jf_site().direct` 已经是现成的判别器。因此:
    #   · 联系方式**只对直营主站下发**(镜像站的响应体里根本不出现,不是前端藏起来
    #     —— 藏起来的话 F12 就能把平台客服从代理站页面里挖出去);
    #   · value 与 url **两个都留空 = 特性整体不存在**(逐字节 4.4.1 行为),
    #     与 jf_direct_hosts「留空=关闭」同一条惯例,不另设总开关。
    #
    # ⚠ 这四项会走**展示路径**(写进页面、可点成链接),而 ENV / config.yaml 这条
    #   路**绕过管理台的 semantic_validate**。故真正的收敛与白名单落在
    #   userauth.cs_info() 那个下发边界上,管理台校验只负责提前告警。
    jf_cs_label: str = ""              # 渠道名,如「客服QQ」「售后微信」;留空前端按「客服」
    jf_cs_value: str = ""              # 号码 / 微信号 / 群号 —— 展示 + 点击复制
    # 可点的去处。**只放行 http/https 绝对 URL**(其余一律丢弃,见 cs_info):
    #   · `javascript:` / `data:` 是注入面,HTML 转义**不能**中和 href 里的它们;
    #   · `mqqwpa://` / `tencent://` / `weixin://` 在桌面浏览器点了没有任何反应,
    #     那正是本项目一贯拒绝的死控件(与 §12.6 拒绝把提示做成按钮同一条理由)。
    # 留空 = 不渲染链接,只渲染「展示 + 复制」——微信号本来也没有可用深链。
    jf_cs_url: str = ""
    jf_cs_note: str = ""               # 一句话补充,如服务时段;留空即不占高度

    @property
    def enabled(self) -> bool:
        return bool(self.host and self.db and self.user)

    @property
    def jf_enabled(self) -> bool:
        """九法 VIP 体系是否生效 —— 必须先有登录系统(身份是档位的载体)。"""
        return bool(self.enabled and self.jf_vip_enabled)


@dataclass
class AdminCfg:
    """管理台入口(5.3.0)。口令 / 散列 / 签名密钥仍**只走环境变量**(STA_ADMIN_PASSWORD[_HASH] /
    STA_ADMIN_SECRET,敏感项不进文件);本段只放「在哪进、用哪个账号进、要不要人机验证」。
    三项均为部署项:管理台「参数中心」只读展示,改动走 config.yaml 的 admin: 段或对应环境变量,
    重启 web 生效。"""
    # 入口路径(**单段**:字母/数字/连字符/下划线,1–64 位;不能与站点已有路径同名,如 auth /
    # monitor —— 清单见 admin_auth._PATH_RESERVED)。后台页面 = /<path>,
    # 管理 API = /api/<path>/*,二者同源于此(前端从页面地址推出 API 前缀,不另存一份)。
    # 旧地址 /admin、/admin.html、/api/admin/* 一律按「不存在的路径」应答 —— 唯一例外是
    # 外部发卡接口 POST /api/admin/jfvip/cards/issue(机器契约,地址恒定,见 admin_auth.CARD_ISSUE_PATH)。
    # 非法取值(含与静态挂载同名的保留词)→ 启动告警并回落本默认值,绝不让整站起不来。
    path: str = "admin-xdd"
    # 登录账号。**只走环境变量 STA_ADMIN_USERNAME**(与口令 STA_ADMIN_PASSWORD 同处 deploy/.env,
    # 凭据成对、不进代码库)——刻意不做成 config.yaml 字段:账号是凭据的一半,不该和另一半分家。
    # 留空 = 只验口令(5.2.0 及更早的行为);设置后登录须**同时**给对账号与口令,哪一项错都回
    # 同一个错误(不泄露账号是否存在),且同样计入失败额度。
    # 比对口径:NFKC 归一(全角数字/字母 → 半角)+ 去首尾空白 + 不分大小写。
    username: str = ""
    # 登录人机验证(供应商与凭据和注册共用 userauth.reg_captcha*,即 STA_USER_REG_CAPTCHA*):
    #   auto   = 站点配好了供应商就**每次登录**都要过(默认;没配就没有这道闸,启动横幅会说明);
    #   always = 必须过 —— 供应商没配好时拒绝网页登录(只能走服务器应急登录链接);
    #   off    = 不要。
    # 供应商在校验时不可达 → 一律拒绝本次登录(fail-closed,不降级);急用走
    # `python -m app.admin_auth link` 生成的一次性应急登录链接。
    login_captcha: str = "auto"


@dataclass
class Settings:
    # 连接
    pg_dsn: str = "postgresql://star:star@localhost:5432/spelltamer"
    redis_url: str = "redis://localhost:6379/0"
    # 进程/池
    http_conn_limit: int = 500
    http_conn_per_host: int = 500
    worker_concurrency: int = 800
    pg_pool_min: int = 4
    # 注:consumer 协程数(worker_concurrency)远大于 PG 连接数是有意的 —— 多数
    # consumer 任意时刻在做网络 I/O(等上游)而非握着 PG 连接。但冷启动回填会让
    # 大量 consumer 同时抢连接,故默认从 16 提到 32;高并发写入可继续上调(受
    # postgres max_connections × worker 副本数约束)。批量回填已改多行 INSERT,
    # 单房回填从「~40 次往返」降到「~1 次往返」,极大缓解连接争用。
    pg_pool_max: int = 32
    # 繁星归一 aiohttp 连接器并发上限(旧实现硬编码 64;现可配)。真正的削峰靠
    # ratelimit.fanxing_* 令牌桶,此值只是连接层护栏。
    starmeta_conn_limit: int = 64
    log_level: str = "INFO"
    # 💎稀有出怪的**日志**阈值(倍率 ≥ 此值才打 INFO,其余逐局日志为 DEBUG)。
    # 旧行为等价于 250 —— 但官方概率下倍率≥250 的妖兽合计 **12%** 的出怪,万房规模
    # ≈24 行/s(≈200 万行/天),与「稳态日志量与房间数解耦」的设计声明矛盾,还会把
    # janitor/discovery/retention/WARNING 等真正有用的高层日志挤出轮转窗口。
    # 默认 500(只有沧溟龙)→ 万房 ≈**7 行/s**(按实测 3.56% 算;公示 2.0% 会算成 4 行/s,
    # 公示与实盘长期不符,见 constants.py 同段)。设 250 可恢复旧行为。
    rare_log_multiplier: int = RARE_LOG_MULTIPLIER_THRESHOLD   # = 500,单一真相源在 constants
    static_dir: str = ""
    # 账号/扫码登录库(恢复的 accounts_backend 落库路径;/api/account/* 用)。
    # docker 部署建议指向持久化卷,重启不丢账号。默认相对 cwd。
    accounts_path: str = "accounts.json"
    # 自动登录续期桥接:kugou_login 刷新服务把新 Cookie 写到这个文件(spell_tamer_config.json),
    # worker 启动时从中读取 x-auth-uid/x-auth-ticket, 并由后台任务定期热更新(见 worker._auth_refresher)。
    # 留空=不启用(维持原有 STA_AUTH_TICKET/config.yaml 行为)。docker 部署指向共享卷即可。
    auth_cookie_file: str = ""
    auth_refresh_s: int = 60          # 热更新轮询间隔(秒)
    # Redis 连接池。redis-py 8 默认 max_connections=100,而 worker 有 worker_concurrency
    # 个 consumer 协程各自并发打 Redis(claim/ack/快照/令牌桶/room_gate),打满即抛
    # MaxConnectionsError。两道防线:(1)放大上限 —— worker 启动时按 worker_concurrency
    # + 余量自动放大(见 worker.py),此处 256 为 web/seed 基线;(2)用
    # BlockingConnectionPool —— 即便打满也排队等待 redis_pool_timeout 秒再放行而非直接
    # 报错(见 redis_bus.py)。二者叠加,高并发/冷启动下 Redis 层不因池耗尽崩溃。
    redis_max_connections: int = 256
    redis_pool_timeout: float = 30.0
    # web(HTTP/SSE)专用的池等待上限:worker 是后台任务,池打满时**阻塞等待**远好过崩溃
    # (redis_pool_timeout=30s);但 web 服务 HTTP 请求,池若被大量长连 SSE(pubsub 从
    # 同一池取长生命周期连接)占满,普通读不应挂 30s —— 应较快失败返回、由客户端重连。
    # 故 web 用更短的等待上限(仍是阻塞池,只是超时更短:平滑亚秒抖动但不长挂 HTTP)。
    web_pool_timeout: float = 5.0
    # ── SSE 专用 Redis 池(修复:长连与短请求分离)────────────────────────────
    # 背景(实地核查,非推断):每个 SSE 客户端从 `ST.bus` 取一条 **长生命周期**
    # pubsub 连接并持有到断流。它与普通只读 HTTP 请求共用同一个 256 连接的池 ——
    # 于是「第 257 个观众」不是自己连不上,而是**把整个站点拖垮**:普通请求
    # 拿不到连接,BlockingConnectionPool 排队 web_pool_timeout 秒后抛
    # ConnectionError("No connection available."),FastAPI 回 500。
    # 真机实证:web 池 256/256 被 pubsub 占满、恒定不动,而 web 进程 CPU 仅 0.85%
    # —— 纯排队,不是算力问题。故 SSE 单开一个池:再多观众也只挤爆它自己,
    # 普通 HTTP 永远有连接可用(舱壁原则)。
    # 池等待用长超时(30s):SSE 是后台长连,阻塞等待远好过断流。
    sse_max_connections: int = 4096
    sse_pool_timeout: float = 30.0
    # /api/live-rooms 逐房拼卡的并发闸(见 web._build_live_rooms)。
    # 原实现对 N 个房无上限 asyncio.gather —— 一个请求瞬间申领 N 条 Redis 连接,
    # 是把池推向枯竭的助推器。钳到有限并发后,单请求占用可控。
    live_rooms_concurrency: int = 32
    # ── 线程池舱壁(修复:阻塞上游与静态资源分池)──────────────────────────
    # 背景(实地复现,非推断):`/api/account/*` 与 `/api/game/*` 是**同步阻塞**
    # 实现(urllib / curl_cffi 直打酷狗,timeout 10~12s,curl 侧还有 7 档
    # impersonate 重试 + urllib 兜底),经 run_in_threadpool 丢线程池执行。
    # 而 anyio 的**默认线程池只有 40 个令牌**(CapacityLimiter(40),全事件循环
    # 共享),Starlette 的 StaticFiles.lookup_path / FileResponse 的 os.stat +
    # open + read(64KB 一块)**也从这同一个 40 里领号**。
    # 于是慢上游一多就坐满 40,静态资源全在门口排队 —— 与 sse_max_connections
    # 那次「SSE 长连坐满 Redis 池 → 普通请求排队」是同一出戏,只是换了个舞台。
    # 真机量级复现(单进程,阻塞方为 sleep 故 CPU 近乎空闲 = 纯排队):
    #     探针                 空载 p50    40 路阻塞在飞 p50
    #     /(index.html)        1.6 ms        7804 ms
    #     /assets/app.js       3.2 ms        7815 ms(max 13003)
    #     /jiufa/imgs/x.png    2.1 ms        7797 ms
    #     /admin(不碰线程池)   1.2 ms           2.1 ms   ← 对照组,毫发无伤
    # 对策(舱壁,与 SSE 分池同构):阻塞上游调用改用**自己的** CapacityLimiter,
    # 默认线程池只留给静态资源。再多慢上游也只挤爆它自己那格舱,静态资源永远
    # 有线程可用;代价是账号面板在上游雪崩时变慢 —— 那正是应该慢的那一个。
    #
    # upstream_thread_limit:账号/游戏接口的线程配额。
    # 【定值依据,勿凭印象改】
    #   ① **零回退底线 = 40**:修复前这两个接口用的是 anyio 默认池,天花板就是 40
    #      (还要与静态资源抢)。专属配额若低于 40,等于给账号路径做了减法 ——
    #      舱壁的目的是**限制爆炸半径,不是限制吞吐**,不该拿账号并发去换。
    #   ② 线程成本可忽略:实测每个阻塞线程仅 ~19 KB RSS(64 个 = +1.2 MB;
    #      8MB 栈是虚拟地址空间,不占物理内存)。内存不是这里的约束。
    #   ③ 按 Little 定律反推:前端账号面板每 1.5s 轮询一次 ⇒ 单用户 ~0.67 req/s;
    #      上游**完全超时**的最坏情况单次 12s ⇒ 所需并发 = 0.67 × 12 ≈ 8 线程/用户。
    #      64 即"上游全挂时仍能扛 8 个同时扫码的用户";常态(~200ms)下可撑数百用户。
    #   ④ 上游侧无速率限制(已实测确认),故**不需要**为"怕被封"而人为压低并发。
    # 调大它**不会**再波及静态资源(那正是分舱的意义),只按同时在线用户数评估即可。
    upstream_thread_limit: int = 64
    # web_thread_pool:默认线程池(静态资源文件 IO)的令牌数。分舱后这里只剩
    # 毫秒级的本地磁盘操作,40 本已够用;上调到 64 是给大文件分块读留余量 ——
    # 混淆后 app.js 约 884KB,按 64KB 一块 ⇒ **单个文件就要往池里排 ~14 次 read**。
    # 线程按需创建、空闲 10s 自动回收,上调不增加常驻成本。
    web_thread_pool: int = 64
    # 业务
    activity_id: int = 2
    upstream: UpstreamCfg = field(default_factory=UpstreamCfg)
    scheduler: SchedulerCfg = field(default_factory=SchedulerCfg)
    ratelimit: RateLimitCfg = field(default_factory=RateLimitCfg)
    admission: AdmissionCfg = field(default_factory=AdmissionCfg)
    retention: RetentionCfg = field(default_factory=RetentionCfg)
    discovery: DiscoveryCfg = field(default_factory=DiscoveryCfg)
    livestatus: LiveStatusCfg = field(default_factory=LiveStatusCfg)
    histmode: HistModeCfg = field(default_factory=HistModeCfg)
    auth: AuthCfg = field(default_factory=AuthCfg)
    userauth: UserAuthCfg = field(default_factory=UserAuthCfg)   # 登录系统(3.8.0)
    admin: AdminCfg = field(default_factory=AdminCfg)            # 管理台入口(5.3.0)
    prediction: Dict[str, Any] = field(default_factory=dict)
    custom_beast_ids: Dict[str, int] = field(default_factory=dict)
    rooms: List[str] = field(default_factory=list)
    room_aliases: Dict[str, str] = field(default_factory=dict)


def _sub(cls, d: Dict[str, Any]):
    """只取 dataclass 已声明字段,忽略多余键(向后兼容配置演进)。"""
    fields = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
    return cls(**{k: v for k, v in (d or {}).items() if k in fields})


@lru_cache(maxsize=1)
def _uid_ticket_from_cookie(cookie: str):
    """从 Cookie 串里取 (uid, ticket)= (KugooID, t)。展开 KuGoo 复合值(t 藏在里面)。

    与 spell_tamer_monitor.parse_kugou_cookie / kugou_login.cookie_util 同口径。
    """
    if not cookie:
        return None, None
    flat: Dict[str, str] = {}
    for seg in str(cookie).split(";"):
        seg = seg.strip()
        if not seg or "=" not in seg:
            continue
        k, _, v = seg.partition("=")
        k, v = k.strip(), v.strip()
        flat[k] = v
        if "&" in v and "=" in v:            # 展开 KuGoo=a=1&b=2&...
            for sub in v.split("&"):
                if "=" in sub:
                    sk, _, sv = sub.partition("=")
                    flat[sk.strip()] = sv.strip()
    return flat.get("KugooID"), flat.get("t")


def auth_from_cookie_file(path: str):
    """读取 kugou_login 刷新出的 spell_tamer_config.json, 返回 (uid, ticket) 或 (None, None)。"""
    try:
        if not path or not os.path.exists(path):
            return None, None
        with open(path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        cookie = (cfg.get("auth") or {}).get("cookie", "") or ""
        return _uid_ticket_from_cookie(cookie)
    except Exception:
        return None, None


def get_settings() -> Settings:
    cfg_path = _env("STA_CONFIG", os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.yaml"))
    raw: Dict[str, Any] = {}
    if cfg_path and os.path.exists(cfg_path):
        with open(cfg_path, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}

    s = Settings()
    s.activity_id = int(raw.get("activity_id", s.activity_id))
    s.upstream = _sub(UpstreamCfg, raw.get("upstream", {}))
    s.scheduler = _sub(SchedulerCfg, raw.get("scheduler", {}))
    s.ratelimit = _sub(RateLimitCfg, raw.get("ratelimit", {}))
    s.admission = _sub(AdmissionCfg, raw.get("admission", {}))
    s.retention = _sub(RetentionCfg, raw.get("retention", {}))
    s.discovery = _sub(DiscoveryCfg, raw.get("discovery", {}))
    s.livestatus = _sub(LiveStatusCfg, raw.get("livestatus", {}))
    s.histmode = _sub(HistModeCfg, raw.get("histmode", {}))
    s.auth = _sub(AuthCfg, raw.get("auth", {}))
    s.userauth = _sub(UserAuthCfg, raw.get("userauth", {}))
    # ── 管理台入口(5.3.0):config.yaml 的 admin: 段 → 环境变量覆盖(优先级与全项目一致)──
    #    yaml 里账号若没加引号会被解析成整数(如 13268237005),统一收敛为字符串。
    s.admin = _sub(AdminCfg, raw.get("admin", {}))   # config.yaml 只提供 path / login_captcha
    s.admin.path = str(_env("STA_ADMIN_PATH", str(s.admin.path or "")) or "").strip()
    # 账号只认环境变量(不是 config.yaml 字段);off/none = 显式「不要账号」。
    _adm_user = _env("STA_ADMIN_USERNAME") or ""
    if _adm_user.strip().lower() in ("off", "none"):
        _adm_user = ""
    s.admin.username = _adm_user.strip()
    s.admin.login_captcha = str(_env("STA_ADMIN_LOGIN_CAPTCHA", str(s.admin.login_captcha or ""))
                                or "auto").strip().lower()
    s.prediction = dict(raw.get("prediction", {}) or {})
    s.custom_beast_ids = {str(k): int(v) for k, v in (raw.get("custom_beast_ids") or {}).items()}
    s.rooms = [str(r).strip() for r in (raw.get("rooms") or []) if str(r).strip()]
    s.room_aliases = {str(k): str(v) for k, v in (raw.get("room_aliases") or {}).items()}

    # ── 环境变量覆盖(敏感/环境相关) ──
    s.pg_dsn = _env("STA_PG_DSN", s.pg_dsn) or s.pg_dsn
    s.redis_url = _env("STA_REDIS_URL", s.redis_url) or s.redis_url
    s.log_level = _env("STA_LOG_LEVEL", s.log_level) or s.log_level
    s.static_dir = _env("STA_STATIC_DIR", s.static_dir) or s.static_dir
    s.accounts_path = _env("STA_ACCOUNTS_PATH", s.accounts_path) or s.accounts_path
    s.http_conn_limit = _env_int("STA_HTTP_CONN_LIMIT", s.http_conn_limit)
    s.http_conn_per_host = _env_int("STA_HTTP_CONN_PER_HOST", s.http_conn_per_host)
    s.worker_concurrency = _env_int("STA_WORKER_CONCURRENCY", s.worker_concurrency)
    s.pg_pool_min = _env_int("STA_PG_POOL_MIN", s.pg_pool_min)
    s.pg_pool_max = _env_int("STA_PG_POOL_MAX", s.pg_pool_max)
    s.starmeta_conn_limit = _env_int("STA_STARMETA_CONN_LIMIT", s.starmeta_conn_limit)
    s.rare_log_multiplier = _env_int("STA_RARE_LOG_MULTIPLIER", s.rare_log_multiplier)
    s.redis_max_connections = _env_int("STA_REDIS_MAX_CONNECTIONS", s.redis_max_connections)
    s.redis_max_connections = _env_int("STA_REDIS_MAX_CONN", s.redis_max_connections)
    s.redis_pool_timeout = _env_float("STA_REDIS_POOL_TIMEOUT", s.redis_pool_timeout)
    s.web_pool_timeout = _env_float("STA_WEB_POOL_TIMEOUT", s.web_pool_timeout)
    s.sse_max_connections = _env_int("STA_SSE_MAX_CONN", s.sse_max_connections)
    s.sse_pool_timeout = _env_float("STA_SSE_POOL_TIMEOUT", s.sse_pool_timeout)
    s.upstream_thread_limit = _env_int("STA_UPSTREAM_THREAD_LIMIT", s.upstream_thread_limit)
    s.web_thread_pool = _env_int("STA_WEB_THREAD_POOL", s.web_thread_pool)
    s.live_rooms_concurrency = _env_int("STA_LIVE_ROOMS_CONCURRENCY",
                                        s.live_rooms_concurrency)
    s.retention.days = _env_float("STA_RETENTION_DAYS", s.retention.days)
    s.retention.sweep_interval_s = _env_int("STA_RETENTION_SWEEP_S",
                                            s.retention.sweep_interval_s)
    s.retention.batch_rows = _env_int("STA_RETENTION_BATCH_ROWS",
                                      s.retention.batch_rows)
    s.retention.audit_days = _env_int("STA_RETENTION_AUDIT_DAYS", s.retention.audit_days)
    _sgc = _env("STA_RETENTION_STATE_GC")       # 布尔项沿用本文件既有写法(无 _env_bool 助手)
    if _sgc is not None:
        s.retention.state_gc = _sgc.strip().lower() in ("1", "true", "yes", "on")
    # 自动发现(直播间遍历)
    _disc_en = _env("STA_DISCOVERY_ENABLED")
    if _disc_en is not None:
        s.discovery.enabled = _disc_en.strip().lower() in ("1", "true", "yes", "on")
    s.discovery.interval_s = _env_int("STA_DISCOVERY_INTERVAL_S", s.discovery.interval_s)
    s.discovery.max_pages = _env_int("STA_DISCOVERY_MAX_PAGES", s.discovery.max_pages)
    s.discovery.page_concurrency = _env_int("STA_DISCOVERY_PAGE_CONC",
                                            s.discovery.page_concurrency)
    s.discovery.prune_grace_s = _env_int("STA_DISCOVERY_PRUNE_GRACE_S",
                                         s.discovery.prune_grace_s)
    s.discovery.warmup_window_ms = _env_int("STA_DISCOVERY_WARMUP_MS",
                                            s.discovery.warmup_window_ms)
    _vf_en = _env("STA_DISCOVERY_VERIFY_ENABLED")
    if _vf_en is not None:
        s.discovery.verify_enabled = _vf_en.strip().lower() in ("1", "true", "yes", "on")
    s.discovery.verify_interval_s = _env_int("STA_DISCOVERY_VERIFY_INTERVAL_S",
                                             s.discovery.verify_interval_s)
    # 主播直播状态(5.0.6)
    _ls_en = _env("STA_LIVESTATUS_ENABLED")
    if _ls_en is not None:
        s.livestatus.enabled = _ls_en.strip().lower() in ("1", "true", "yes", "on")
    s.livestatus.interval_s = _env_int("STA_LIVESTATUS_INTERVAL_S",
                                       s.livestatus.interval_s)
    s.livestatus.max_probe = _env_int("STA_LIVESTATUS_MAX_PROBE",
                                      s.livestatus.max_probe)
    # 后台轮询模式(hist-mode)
    _hm_en = _env("STA_HISTMODE_ENABLED")
    if _hm_en is not None:
        s.histmode.enabled = _hm_en.strip().lower() in ("1", "true", "yes", "on")
    s.histmode.interval_s = _env_int("STA_HISTMODE_INTERVAL_S", s.histmode.interval_s)
    # curated-idle(3.7.0):空闲策展房降级(其余细粒度项走 config/管理台)
    _ci_en = _env("STA_HISTMODE_CURATED_IDLE")
    if _ci_en is not None:
        s.histmode.curated_idle_enabled = \
            _ci_en.strip().lower() in ("1", "true", "yes", "on")

    if _env("STA_AUTH_TICKET"):
        s.auth.ticket = _env("STA_AUTH_TICKET")  # type: ignore[assignment]
    if _env("STA_AUTH_UID"):
        s.auth.uid = _env("STA_AUTH_UID")        # type: ignore[assignment]

    # 自动登录续期桥接:若配置了 cookie 文件且其中有有效票据, 用它覆盖(比 env/config 更新鲜)。
    s.auth_cookie_file = _env("STA_AUTH_COOKIE_FILE", s.auth_cookie_file) or s.auth_cookie_file
    s.auth_refresh_s = _env_int("STA_AUTH_REFRESH_S", s.auth_refresh_s)
    # ── 登录系统(3.8.0):用户库连接与会话策略。密码等敏感项建议只走环境变量。──
    ua = s.userauth
    ua.host = _env("STA_USERDB_HOST", ua.host) or ua.host
    ua.port = _env_int("STA_USERDB_PORT", ua.port)
    ua.db = _env("STA_USERDB_NAME", ua.db) or ua.db
    ua.user = _env("STA_USERDB_USER", ua.user) or ua.user
    ua.password = _env("STA_USERDB_PASSWORD", ua.password) or ua.password
    ua.charset = _env("STA_USERDB_CHARSET", ua.charset) or ua.charset
    ua.user_table = _env("STA_USERDB_TABLE", ua.user_table) or ua.user_table
    # 多网络入口(4.5.0):语义见 UserAuthCfg 同名字段注
    ua.pool_max = _env_int("STA_USERDB_POOL_MAX", ua.pool_max)
    ua.query_timeout_s = _env_float("STA_USERDB_QUERY_TIMEOUT_S", ua.query_timeout_s)
    ua.probe_s = _env_float("STA_USERDB_PROBE_S", ua.probe_s)
    ua.session_ttl_h = _env_float("STA_USER_SESSION_TTL_H", ua.session_ttl_h)
    ua.idle_ttl_h = _env_float("STA_USER_IDLE_TTL_H", ua.idle_ttl_h)
    _sd = _env("STA_USER_SINGLE_DEVICE")
    if _sd is not None and str(_sd).strip() != "":
        ua.single_device = str(_sd).strip().lower() in ("1", "true", "yes", "on")
    ua.max_sessions = _env_int("STA_USER_MAX_SESSIONS", ua.max_sessions)
    ua.cache_ttl_s = _env_float("STA_USER_CACHE_TTL_S", ua.cache_ttl_s)
    ua.outage_grace_s = _env_float("STA_USER_OUTAGE_GRACE_S", ua.outage_grace_s)
    ua.room_max = _env_int("STA_USER_ROOM_MAX", ua.room_max)
    _arl = _env("STA_USER_ACTIVE_ROOM_LEASE")
    if _arl is not None and str(_arl).strip() != "":
        ua.active_room_lease = str(_arl).strip().lower() in ("1", "true", "yes", "on")
    ua.active_room_lease_ttl_s = _env_float("STA_USER_ACTIVE_ROOM_LEASE_TTL_S",
                                            ua.active_room_lease_ttl_s)
    ua.detail_rate_rps = _env_float("STA_USER_DETAIL_RATE_RPS", ua.detail_rate_rps)
    ua.detail_rate_burst = _env_float("STA_USER_DETAIL_RATE_BURST", ua.detail_rate_burst)
    _pob = _env("STA_USER_PROOF_OF_BROWSER")
    if _pob is not None and str(_pob).strip() != "":
        ua.proof_of_browser = str(_pob).strip().lower() in ("1", "true", "yes", "on")
    ua.proof_challenge_ttl_s = _env_float("STA_USER_PROOF_CHALLENGE_TTL_S",
                                          ua.proof_challenge_ttl_s)
    ua.proof_rotate_grace_s = _env_float("STA_USER_PROOF_ROTATE_GRACE_S",
                                         ua.proof_rotate_grace_s)
    ua.signal_footprint_ttl_s = _env_float("STA_USER_SIGNAL_FOOTPRINT_TTL_S",
                                           ua.signal_footprint_ttl_s)
    _sig = _env("STA_USER_SIGNAL_SCORING")
    if _sig is not None and str(_sig).strip() != "":
        ua.signal_scoring = str(_sig).strip().lower() in ("1", "true", "yes", "on")
    ua.signal_window_s = _env_float("STA_USER_SIGNAL_WINDOW_S", ua.signal_window_s)
    # 首登预置房:_env 把空串视作未设置,故用 off/none/disabled/0 表达「关闭」
    _flr = _env("STA_USER_FIRST_LOGIN_ROOM")
    if _flr is not None:
        _flr = _flr.strip()
        ua.first_login_room = "" if _flr.lower() in ("off", "none", "disabled", "0") else _flr
    ua.login_fail_user = _env_int("STA_USER_LOGIN_FAIL_USER", ua.login_fail_user)
    ua.login_fail_ip = _env_int("STA_USER_LOGIN_FAIL_IP", ua.login_fail_ip)
    ua.login_fail_window_s = _env_int("STA_USER_LOGIN_FAIL_WINDOW_S", ua.login_fail_window_s)
    ua.login_lock_s = _env_int("STA_USER_LOGIN_LOCK_S", ua.login_lock_s)
    ua.banned_values = _env("STA_USER_BANNED_VALUES", ua.banned_values) or ua.banned_values
    ua.cookie_secure = _env("STA_USER_COOKIE_SECURE", ua.cookie_secure) or ua.cookie_secure
    ua.log_retention_days = _env_int("STA_USER_LOG_RETENTION_DAYS", ua.log_retention_days)
    ua.log_max_rows = _env_int("STA_USER_LOG_MAX_ROWS", ua.log_max_rows)
    _txff = _env("STA_USER_TRUST_XFF")
    if _txff is not None and str(_txff).strip() != "":
        ua.trust_forwarded_for = str(_txff).strip().lower() in ("1", "true", "yes", "on")
    # ── 5.2.0:可信代理 + 登录防爆破 + 登录人机验证(语义见 UserAuthCfg 各字段注)──
    ua.trusted_proxies = _env("STA_TRUSTED_PROXIES", ua.trusted_proxies) or ua.trusted_proxies
    ua.login_stepup_user = _env_int("STA_USER_LOGIN_STEPUP_USER", ua.login_stepup_user)
    ua.login_stepup_ip = _env_int("STA_USER_LOGIN_STEPUP_IP", ua.login_stepup_ip)
    ua.login_pow_bits = _env_int("STA_USER_LOGIN_POW_BITS", ua.login_pow_bits)
    ua.login_chal_ip_10m = _env_int("STA_USER_LOGIN_CHAL_IP_10M", ua.login_chal_ip_10m)
    ua.login_device_ttl_d = _env_int("STA_USER_LOGIN_DEVICE_TTL_D", ua.login_device_ttl_d)
    ua.login_attack_5m = _env_int("STA_USER_LOGIN_ATTACK_5M", ua.login_attack_5m)
    # ── 注册系统(4.0.0):STA_USER_REG_* family。语义见 UserAuthCfg 各字段注。──
    ua.reg_mode = (_env("STA_USER_REG_MODE", ua.reg_mode) or ua.reg_mode).strip().lower()
    ua.reg_pass_shape = (_env("STA_USER_REG_PASS_SHAPE", ua.reg_pass_shape)
                         or ua.reg_pass_shape).strip().lower()
    ua.reg_trial_days = _env_int("STA_USER_REG_TRIAL_DAYS", ua.reg_trial_days)
    ua.reg_extra_cols = _env("STA_USER_REG_EXTRA_COLS", ua.reg_extra_cols) or ua.reg_extra_cols
    ua.reg_pow_bits = _env_int("STA_USER_REG_POW_BITS", ua.reg_pow_bits)
    ua.reg_chal_ttl_s = _env_int("STA_USER_REG_CHAL_TTL_S", ua.reg_chal_ttl_s)
    ua.reg_min_fill_s = _env_int("STA_USER_REG_MIN_FILL_S", ua.reg_min_fill_s)
    ua.reg_captcha = (_env("STA_USER_REG_CAPTCHA", ua.reg_captcha)
                      or ua.reg_captcha).strip().lower()
    ua.reg_captcha_id = _env("STA_USER_REG_CAPTCHA_ID", ua.reg_captcha_id) or ua.reg_captcha_id
    ua.reg_captcha_key = _env("STA_USER_REG_CAPTCHA_KEY", ua.reg_captcha_key) or ua.reg_captcha_key
    ua.reg_captcha_secret_id = _env("STA_USER_REG_CAPTCHA_SECRET_ID",
                                    ua.reg_captcha_secret_id) or ua.reg_captcha_secret_id
    ua.reg_captcha_secret_key = _env("STA_USER_REG_CAPTCHA_SECRET_KEY",
                                     ua.reg_captcha_secret_key) or ua.reg_captcha_secret_key
    _rcr = _env("STA_USER_REG_CAPTCHA_REQUIRED")
    if _rcr is not None and str(_rcr).strip() != "":
        ua.reg_captcha_required = str(_rcr).strip().lower() in ("1", "true", "yes", "on")
    # ── 5.2.0 登录人机验证时机:off / risk / always(供应商与凭据 = 上面共用的五项)──
    # 兼容 5.2.0 预览写法(本项填供应商名,另配 _MODE / _ID / _KEY / _SECRET_*):一次性折算
    # 进共用那组 —— 共用项已有值则以共用项为准;启动横幅提示迁移。
    _lc = str(_env("STA_USER_LOGIN_CAPTCHA", ua.login_captcha) or ua.login_captcha).strip().lower()
    if _lc in ("tencent", "geetest", "turnstile"):
        _shared = str(ua.reg_captcha or "off").strip().lower()
        if _shared in ("", "off"):
            ua.reg_captcha = _shared = _lc
        # 只在「同一家供应商」时才折算凭据:把 Turnstile 的私钥塞给腾讯云的 AppId 只会全挂
        if _shared == _lc:
            for _n, _ev in (("id", "STA_USER_LOGIN_CAPTCHA_ID"), ("key", "STA_USER_LOGIN_CAPTCHA_KEY"),
                            ("secret_id", "STA_USER_LOGIN_CAPTCHA_SECRET_ID"),
                            ("secret_key", "STA_USER_LOGIN_CAPTCHA_SECRET_KEY")):
                _v = _env(_ev)
                if _v and not getattr(ua, f"reg_captcha_{_n}"):
                    setattr(ua, f"reg_captcha_{_n}", _v)
        _lc = str(_env("STA_USER_LOGIN_CAPTCHA_MODE") or "risk").strip().lower()
        ua._login_captcha_legacy = True
    ua.login_captcha = _lc if _lc in ("off", "risk", "always") else "off"
    ua.reg_ip_hourly = _env_int("STA_USER_REG_IP_HOURLY", ua.reg_ip_hourly)
    ua.reg_ip_daily = _env_int("STA_USER_REG_IP_DAILY", ua.reg_ip_daily)
    ua.reg_ip_ok_daily = _env_int("STA_USER_REG_IP_OK_DAILY", ua.reg_ip_ok_daily)
    ua.reg_chal_ip_10m = _env_int("STA_USER_REG_CHAL_IP_10M", ua.reg_chal_ip_10m)
    ua.reg_name_10m = _env_int("STA_USER_REG_NAME_10M", ua.reg_name_10m)
    ua.reg_global_hourly = _env_int("STA_USER_REG_GLOBAL_HOURLY", ua.reg_global_hourly)
    ua.reg_global_daily = _env_int("STA_USER_REG_GLOBAL_DAILY", ua.reg_global_daily)
    ua.reg_global_daily_invite = _env_int("STA_USER_REG_GLOBAL_DAILY_INVITE",
                                          ua.reg_global_daily_invite)
    ua.reg_reserved = _env("STA_USER_REG_RESERVED", ua.reg_reserved) or ua.reg_reserved
    ua.reg_success_hint = _env("STA_USER_REG_SUCCESS_HINT",
                               ua.reg_success_hint) or ua.reg_success_hint
    ua.reg_log_retention_days = _env_int("STA_USER_REG_LOG_RETENTION_DAYS",
                                         ua.reg_log_retention_days)
    # ── 链接快速登录(4.1.0,SSO):STA_USER_SSO 布尔开关 + 消费侧年龄硬顶。──
    _sso = _env("STA_USER_SSO")
    if _sso is not None and str(_sso).strip() != "":
        ua.sso_enabled = str(_sso).strip().lower() in ("1", "true", "yes", "on")
    ua.sso_max_age_s = _env_int("STA_USER_SSO_MAX_AGE_S", ua.sso_max_age_s)
    # ── 账密签发通道(4.3.0):STA_USER_SSO_LINK* family。语义见字段注。──────────
    _ssol = _env("STA_USER_SSO_LINK")
    if _ssol is not None and str(_ssol).strip() != "":
        ua.sso_link_enabled = str(_ssol).strip().lower() in ("1", "true", "yes", "on")
    ua.sso_link_ttl_s = _env_int("STA_USER_SSO_LINK_TTL_S", ua.sso_link_ttl_s)
    ua.sso_link_base = (_env("STA_USER_SSO_LINK_BASE", ua.sso_link_base)
                        or ua.sso_link_base).strip()
    ua.sso_link_key = (_env("STA_USER_SSO_LINK_KEY", ua.sso_link_key)
                       or ua.sso_link_key).strip()
    # ── 九法 VIP(4.2.0):STA_JF_* family。语义见 UserAuthCfg 各字段注。──────────
    _jfv = _env("STA_JF_VIP")
    if _jfv is not None:
        ua.jf_vip_enabled = _jfv.strip().lower() in ("1", "true", "yes", "on")
    ua.jf_vip_plans = _env("STA_JF_VIP_PLANS", ua.jf_vip_plans) or ua.jf_vip_plans
    ua.jf_basic_history_limit = _env_int("STA_JF_BASIC_HIST", ua.jf_basic_history_limit)
    ua.jf_basic_pred_window = _env_int("STA_JF_BASIC_PRED_WIN", ua.jf_basic_pred_window)
    ua.jf_free_session_ttl_h = _env_float("STA_JF_FREE_SESSION_TTL_H",
                                          ua.jf_free_session_ttl_h)
    # 4.4.0:basic 档在线累计窗(小时;0=关闭=旧行为)。热更(🟢)—— 前端每次
    # /api/auth/session 取新值,无需重建镜像即可收紧/放开/撤回。
    ua.jf_basic_online_h = _env_float("STA_JF_BASIC_ONLINE_H", ua.jf_basic_online_h)
    ua.jf_pay_base = _env("STA_JF_PAY_BASE", ua.jf_pay_base) or ua.jf_pay_base
    ua.jf_pay_type = _env("STA_JF_PAY_TYPE", ua.jf_pay_type) or ua.jf_pay_type
    ua.jf_pay_timeout_s = _env_float("STA_JF_PAY_TIMEOUT", ua.jf_pay_timeout_s)
    _jfsim = _env("STA_JF_PAY_SIMULATE")
    if _jfsim is not None:
        ua.jf_pay_simulate = _jfsim.strip().lower() in ("1", "true", "yes", "on")
    ua.jf_pay_simulate_ttl_s = _env_int("STA_JF_PAY_SIMULATE_TTL",
                                        ua.jf_pay_simulate_ttl_s)
    ua.jf_settle_grace_s = _env_int("STA_JF_SETTLE_GRACE", ua.jf_settle_grace_s)
    ua.jf_recover_window_s = _env_int("STA_JF_RECOVER_WINDOW", ua.jf_recover_window_s)
    ua.jf_reconcile_lookback_s = _env_int("STA_JF_RECONCILE_LOOKBACK",
                                          ua.jf_reconcile_lookback_s)
    ua.jf_reconcile_max = _env_int("STA_JF_RECONCILE_MAX", ua.jf_reconcile_max)
    ua.jf_reconcile_timeout_s = _env_float("STA_JF_RECONCILE_TIMEOUT",
                                           ua.jf_reconcile_timeout_s)
    ua.jf_reconcile_rate_hourly = _env_int("STA_JF_RECONCILE_RATE_HOURLY",
                                           ua.jf_reconcile_rate_hourly)
    ua.jf_order_rate_hourly = _env_int("STA_JF_ORDER_RATE_HOURLY",
                                       ua.jf_order_rate_hourly)
    ua.jf_redeem_fail_hourly = _env_int("STA_JF_REDEEM_FAIL_HOURLY",
                                        ua.jf_redeem_fail_hourly)
    # 布尔项沿用本文件既有写法(无 _env_bool 助手;与 jf_vip_enabled/jf_pay_simulate 同款)
    _jfcp = _env("STA_JF_CARD_PURGE_ENABLED")
    if _jfcp is not None:
        ua.jf_card_purge_enabled = _jfcp.strip().lower() in ("1", "true", "yes", "on")
    ua.jf_card_disabled_age_days = _env_int(
        "STA_JF_CARD_DISABLED_AGE_DAYS", ua.jf_card_disabled_age_days)
    ua.jf_card_used_retention_days = _env_int(
        "STA_JF_CARD_USED_RETENTION_DAYS", ua.jf_card_used_retention_days)
    ua.jf_order_unpaid_retention_days = _env_int(
        "STA_JF_ORDER_UNPAID_RETENTION_DAYS", ua.jf_order_unpaid_retention_days)
    # ── 外部发卡 API(4.2.9;布尔项沿用本文件既有写法,无 _env_bool 助手)──────
    _jfca = _env("STA_JF_CARD_API")
    if _jfca is not None:
        ua.jf_card_api_enabled = _jfca.strip().lower() in ("1", "true", "yes", "on")
    # 密钥/白名单用 sso_link_key 同款写法:_env 可能回 None,故 or 兜底再 strip
    # —— 尾随空格是从密码管理器粘贴时的高频差错,而常数时间比较不会替你 trim。
    ua.jf_card_api_key = (_env("STA_JF_CARD_API_KEY", ua.jf_card_api_key)
                          or ua.jf_card_api_key).strip()
    ua.jf_card_api_rate_hourly = _env_int("STA_JF_CARD_API_RATE_HOURLY",
                                          ua.jf_card_api_rate_hourly)
    ua.jf_card_api_ip_allow = (_env("STA_JF_CARD_API_IP_ALLOW",
                                    ua.jf_card_api_ip_allow)
                               or ua.jf_card_api_ip_allow).strip()
    # ── 站点分流(4.4.1;语义见 UserAuthCfg.jf_direct_hosts 注)────────────────
    ua.jf_direct_hosts = (_env("STA_JF_DIRECT_HOSTS", ua.jf_direct_hosts)
                          or ua.jf_direct_hosts).strip()
    _jfxfh = _env("STA_JF_DIRECT_TRUST_XFH")
    if _jfxfh is not None:
        ua.jf_direct_trust_xfh = _jfxfh.strip().lower() in ("1", "true", "yes", "on")
    # ── 客服联系方式(4.4.2;语义见 UserAuthCfg.jf_cs_value 注)────────────────
    # 这里**只做 strip**,不做任何字符收敛/白名单 —— 那些一律落在 cs_info() 的
    # 下发边界上。理由:ENV 只是四条来源之一(还有 config.yaml、运行时覆盖、
    # 代码默认),把清洗放在其中一条来源上,另外三条就漏了。
    ua.jf_cs_label = (_env("STA_JF_CS_LABEL", ua.jf_cs_label) or ua.jf_cs_label).strip()
    ua.jf_cs_value = (_env("STA_JF_CS_VALUE", ua.jf_cs_value) or ua.jf_cs_value).strip()
    ua.jf_cs_url = (_env("STA_JF_CS_URL", ua.jf_cs_url) or ua.jf_cs_url).strip()
    ua.jf_cs_note = (_env("STA_JF_CS_NOTE", ua.jf_cs_note) or ua.jf_cs_note).strip()
    if s.auth_cookie_file:
        _uid, _tk = auth_from_cookie_file(s.auth_cookie_file)
        if _uid and _tk:
            s.auth.uid, s.auth.ticket = _uid, _tk
    return s


# 进程级单例:import 即加载一次(get_settings 为纯函数,如需重载可直接再调)。
settings = get_settings()
