"""
ratelimit.py — 跨进程/跨机器共享的分布式令牌桶(削峰核心之一)
================================================================================
所有 worker(无论几个进程、几台机器)对上游的请求都先向同一个 Redis 令牌桶
申领令牌,从而把「对上游的全局 QPS」钳在配置上限内,并允许一定突发(burst)。
配合调度器的 per-room 抖动(错峰),即可把几千房「对齐同一秒」的请求毛刺
削平成平滑曲线。

设计要点:
  · 令牌补充与消费在一段 Lua 里原子完成,避免多 worker 竞态导致超发;
  · 时间以 **Redis 服务器时钟**(redis.call('TIME'))为准,规避各 worker 之间
    的时钟漂移;
  · 申领失败不消费令牌,返回建议等待毫秒(worker 据此 await asyncio.sleep 后重试)。

用法:
    rl = TokenBucket(redis, key="rl:upstream", rate=300, burst=600)
    await rl.acquire()              # 阻塞直至拿到一枚令牌(内部 sleep+重试)
    await rl.try_acquire(cost=1)    # -> (allowed: bool, wait_ms: int) 不阻塞
"""
from __future__ import annotations

import asyncio
import random
import time

try:                       # 连接层瞬时错误(池打满 MaxConnectionsError / 断连)判定用
    from redis.exceptions import ConnectionError as _RedisConnError
except Exception:          # pragma: no cover
    _RedisConnError = Exception


def _is_conn_err(e: Exception) -> bool:
    """是否为可重试的瞬时连接错误(连接池打满、短暂断连等)。"""
    if isinstance(e, _RedisConnError):
        return True
    s = str(e).lower()
    return ("maxconnections" in s or "too many connections" in s
            or "connection" in s and "pool" in s)

# KEYS[1]=bucket key
# ARGV[1]=rate(令牌/秒) ARGV[2]=burst(桶容量) ARGV[3]=cost(本次申领数)
# 返回 {allowed(0/1), wait_ms}
_LUA = """
local key   = KEYS[1]
local rate  = tonumber(ARGV[1])
local burst = tonumber(ARGV[2])
local cost  = tonumber(ARGV[3])

local t = redis.call('TIME')
local now_ms = (tonumber(t[1]) * 1000) + math.floor(tonumber(t[2]) / 1000)

local data = redis.call('HMGET', key, 'tokens', 'ts')
local tokens = tonumber(data[1])
local ts     = tonumber(data[2])
if tokens == nil then
  tokens = burst
  ts = now_ms
end

local elapsed = math.max(0, now_ms - ts)
tokens = math.min(burst, tokens + (elapsed / 1000.0) * rate)

local allowed = 0
local wait_ms = 0
if tokens >= cost then
  tokens = tokens - cost
  allowed = 1
else
  local deficit = cost - tokens
  wait_ms = math.ceil((deficit / rate) * 1000.0)
end

redis.call('HSET', key, 'tokens', tokens, 'ts', now_ms)
-- 令牌桶闲置一段时间后自动回收,避免键泄漏;TTL 取「装满一桶的时间」的 4 倍且至少 60s
local ttl = math.max(60, math.ceil((burst / rate) * 4))
redis.call('EXPIRE', key, ttl)

return {allowed, wait_ms}
"""


class TokenBucket:
    def __init__(self, redis, key: str, rate: float, burst: float,
                 *, degrade_open: bool = False):
        self._redis = redis
        self._key = key
        self._rate = float(rate)
        self._burst = float(burst)
        self._sha: str | None = None
        # 连接层持续不可用、超过 CONN_ERR_BUDGET_S 预算时的**裁决方向**。
        # 默认 False = 维持原语义「暂不放行」——本模块的 try_acquire 文档写死了
        # 「绝不静默放行」,因为对上游/繁星桶而言放行 = 削峰失效被打爆,对
        # rl:adminlogin 桶而言放行 = 暴破节流失效。**只有**明确以可用性优先、
        # 且调用方自身已 fail-open 的桶(web 的 rl:detail,其闸门文档写明
        # 「绝不因 Redis 抖动误伤真人」)才显式传 True。
        self._degrade_open = bool(degrade_open)

    def update(self, rate: float, burst: float) -> None:
        """热更新速率/容量(配置中枢钩子;rate<=0 即退化为不限流)。
        令牌桶状态在 Redis,本对象只携带参数 —— 原地改两枚标量即全量生效。"""
        self._rate = float(rate)
        self._burst = float(burst)

    async def _ensure_script(self) -> str:
        if self._sha is None:
            self._sha = await self._redis.script_load(_LUA)
        return self._sha

    # 连接不可用时的**总时长预算**(秒)。修复一个真实的放大器:
    # 原实现只数重试次数(64 次),没有时间上界。而池是 BlockingConnectionPool ——
    # 池打满时每一次 evalsha 要**先阻塞 pool_timeout 秒**才抛 ConnectionError,
    # 于是 64 次重试 = 64 x pool_timeout:web 侧一次
    # /api/rooms/{room}/prediction 被挂 5 分钟(前端表现不是「报错」而是
    # 「转圈不出数据」,真机实证正是这一条);worker 侧池等待 30s,更是
    # 64 x 30s ≈ 32 分钟 —— 远超 worker.py 里「8s 等令牌 + 15s 请求 < 30s
    # 任务租约」的安全论证,租约到期即被别的副本重复领取、重复打上游。
    # 预算只钳**时间**,不改**裁决** —— 见 _degrade_open。
    CONN_ERR_BUDGET_S = 3.0

    async def _try_on(self, key: str, cost: float) -> tuple[bool, int]:
        """按**给定键**不阻塞申领(桶状态在 Redis,由 key 隔离)。try_acquire /
        try_acquire_key 的公共内核 —— 键作为参数显式传入,**绝不**改写 self._key
        (asyncio 单线程下 evalsha 是 await 点,改共享字段会被其它协程看到,故禁止)。"""
        if self._rate <= 0:          # 不限流:直接放行(也避免 Lua 里 deficit/rate 除零)
            return True, 0
        t0 = time.monotonic()
        for attempt in range(64):
            try:
                sha = await self._ensure_script()
                allowed, wait_ms = await self._redis.evalsha(
                    sha, 1, key, self._rate, self._burst, cost)
                return bool(int(allowed)), int(wait_ms)
            except Exception as e:  # NOSCRIPT(Redis 重启丢脚本)/ 连接池打满等
                if "NOSCRIPT" in str(e):
                    self._sha = None
                    continue
                if _is_conn_err(e):
                    # 连接层持续不可用超过预算 → 立即结束等待。**裁决方向由
                    # _degrade_open 决定**:默认沿用旧语义(暂不放行 + 小等待),
                    # 只把「等 5 分钟」压成「等 3 秒」,不改变放行与否。
                    if time.monotonic() - t0 >= self.CONN_ERR_BUDGET_S:
                        return (True, 0) if self._degrade_open else (False, 50)
                    # 退避等连接释放(池打满场景:随并发回落自然放行,顺带削峰)
                    await asyncio.sleep(0.005 * min(attempt + 1, 20))
                    continue
                raise
        return False, 50   # 连接持续不可用:视为暂不放行(不降级放行)

    async def try_acquire(self, cost: float = 1.0) -> tuple[bool, int]:
        """不阻塞地申领(用本桶的固定键)。返回 (是否成功, 建议等待毫秒)。

        **rate <= 0 表示不限流**:令牌桶退化为 no-op,始终立即放行(不触碰 Redis)。
        默认配置即为不限流,需要时把对应 `*_rps` 设为正值即可启用限流。

        对**瞬时连接错误**(Redis 连接池打满 MaxConnectionsError / 短暂断连)做有界
        退避重试 —— 高并发批量归一时,共享 Redis 池可能瞬时被打满;此时应「等池释放
        后再申领」而非把限流降级放行(那会让繁星削峰失效)。连接持续不可用则返回
        『暂不放行 + 小等待』,由调用方稍后重试,绝不静默放行。"""
        return await self._try_on(self._key, cost)

    async def try_acquire_key(self, key: str, cost: float = 1.0) -> tuple[bool, int]:
        """按**调用方给定键**申领(同一桶实例、同一 rate/burst,按键在 Redis 内互相
        隔离)。用于「每账号一个子桶」——如 rl:detail:u{uid}:一把 TokenBucket 承载
        任意多账号的独立限流,无需为每账号建对象。语义/退避与 try_acquire 完全一致。"""
        return await self._try_on(str(key), cost)

    async def acquire(self, cost: float = 1.0, max_wait_s: float = 30.0) -> bool:
        """阻塞直至拿到令牌;超过 max_wait_s 放弃返回 False(调用方可稍后重排)。

        计时用**墙钟**而非「睡眠时长累加」。旧实现只累加 sleep,不计 try_acquire
        自身的耗时 —— 正常时二者近似相等,但 Redis 连接层出问题时 try_acquire 每次
        都要耗掉退避预算,`waited` 却几乎不涨,于是 max_wait_s 形同虚设:worker.py
        对 RL_MAX_WAIT_S 的安全论证(「8s 等令牌 + 15s 请求 < 30s 任务租约」)被
        击穿,任务超租被别的副本重复领取、重复打上游 —— 恰在限流吃紧时雪上加霜。
        改墙钟后该论证重新成立;健康路径下行为与旧实现无差别。"""
        t0 = time.monotonic()
        while True:
            ok, wait_ms = await self.try_acquire(cost)
            if ok:
                return True
            # 加一点**随机**抖动,避免大量 worker 在同一 wait_ms 后齐步唤醒又齐步失败
            # (期望值仍≈10ms,但打散并发 worker 的重试时刻,启用限流时更平滑)
            delay = min(wait_ms / 1000.0, 0.25) + random.uniform(0.0, 0.02)
            if time.monotonic() - t0 + delay > max_wait_s:
                return False
            await asyncio.sleep(delay)
