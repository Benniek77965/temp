"""
wincount.py — 窗口计数原语(5.2.0 复查收敛:全项目同类计数器统一走这里)
================================================================================
为什么单独成模块:复查发现「INCR 之后仅在 n==1 时 EXPIRE」这一写法在项目里共有
7 处 —— 登录失败计数、注册 R1 限流、SSO 兑换限频、SSO 签发限频与密钥错误计数、
九法VIP 限频、发卡 API 密钥错误计数、worker 的 award 重试计数。两步之间 Redis
抖一次,键就永远没有 TTL(实证 ttl=-1):对限流键而言等于「该用户名 / 该 IP
被永久锁死」,对普通计数键而言是只增不减的泄漏。

现统一为 Lua 一步完成「INCR + 无 TTL 即补」;禁用脚本的托管 Redis 退化为
「INCR + 每次检查并补 TTL」—— 非原子但**自愈**(下一次计数就把 TTL 补上),
不会再留下永久键。进程内兜底(Redis 不可用时)由调用方提供存储 dict,风控
组件故障一律**不放开**。

时钟:进程内兜底默认用单调钟;九法VIP 的既有兜底存储用墙钟比较,故允许传入
clock,保证同一个 dict 的写入与读取口径一致。
"""
from __future__ import annotations

import time
from typing import Any, Callable, Dict, Optional, Tuple

LUA_INCR = ("local n=redis.call('INCR',KEYS[1]) "
            "local t=redis.call('PTTL',KEYS[1]) "
            "if t<0 then redis.call('PEXPIRE',KEYS[1],ARGV[1]) t=tonumber(ARGV[1]) end "
            "return {n,t}")
LUA_DECR = ("if redis.call('EXISTS',KEYS[1])==0 then return 0 end "
            "local n=redis.call('DECR',KEYS[1]) "
            "if n<0 then redis.call('SET',KEYS[1],'0','KEEPTTL') n=0 end "
            "return n")

# 「本 Redis 能否跑脚本」探测结果:None=未探测 / True=能 / False=禁用脚本(托管 Redis)
STATE: Dict[str, Any] = {"lua": None}

Mem = Dict[str, Tuple[int, float]]
Clock = Callable[[], float]

# 进程内兜底的容量:超过 _MEM_SOFT 先清掉已过期项;清完仍超过 _MEM_HARD(只会发生在 Redis 长时间
# 不可用、同时遭遇海量不同键的分布式攻击时)就按「最先到期」淘汰一半 —— 宁可少记几个最快过期的计数,
# 也不能让兜底存储无界增长把 web 进程撑到 OOM(那会把所有用户一起拖下水)。
_MEM_SOFT, _MEM_HARD = 8192, 50000
# 清理节流:旧写法超过软上限后**每次计数**都全表扫一遍过期项 —— 恰恰在 Redis 不可用且正遭受攻击时
# 退化成每请求 O(n)。现在同一个兜底存储至多每 5 秒清一次;硬上限的两倍是不看时间的绝对兜底。
_PRUNE_EVERY_S = 5.0
_PRUNE_AT: Dict[int, float] = {}


def _maybe_prune(mem: Mem, now: float, keep: str) -> None:
    if len(mem) <= _MEM_SOFT:
        return
    if now - _PRUNE_AT.get(id(mem), -1e18) < _PRUNE_EVERY_S and len(mem) <= _MEM_HARD * 2:
        return
    _PRUNE_AT[id(mem)] = now
    for k in [k for k, v in mem.items() if v[1] <= now]:
        mem.pop(k, None)
    if len(mem) > _MEM_HARD:
        for k, _v in sorted(mem.items(), key=lambda kv: kv[1][1])[: len(mem) // 2]:
            if k != keep:                   # 刚计的这一笔绝不淘汰
                mem.pop(k, None)


def _no_script(e: Exception) -> bool:
    s = str(e).lower()
    return any(k in s for k in ("unknown command", "noscript", "not allowed", "script"))


async def _eval(r: Any, script: str, key: str, *args: Any) -> Optional[Any]:
    """跑脚本;本 Redis 禁用脚本时返回 None(并记住,此后直接走非脚本路径)。
    其它异常上抛 —— 「曾经能跑、突然失败」是真故障,交给调用方兜底。"""
    if STATE["lua"] is False:
        return None
    try:
        res = await r.eval(script, 1, key, *args)
        STATE["lua"] = True
        return res
    except Exception as e:                  # noqa: BLE001
        if STATE["lua"] or not _no_script(e):
            raise
        STATE["lua"] = False
        print("[限流] Redis 不支持 EVAL —— 窗口计数降级为「INCR + 每次补 TTL」(自愈,不留永久键)")
        return None


async def incr_redis(r: Any, key: str, win_s: int) -> Tuple[int, int]:
    """Redis 侧窗口计数 +1 → (当前计数, 剩余窗口秒)。异常上抛(调用方决定兜底)。"""
    win_s = max(1, int(win_s))
    res = await _eval(r, LUA_INCR, key, win_s * 1000)
    if res is not None:
        return int(res[0]), max(1, (int(res[1]) + 999) // 1000)
    n = int(await r.incr(key))
    ttl = await r.ttl(key)
    if ttl is None or int(ttl) < 0:
        await r.expire(key, win_s)
        ttl = win_s
    return n, max(1, int(ttl))


async def decr_redis(r: Any, key: str) -> None:
    """Redis 侧 -1(退还;不小于 0;不动 TTL;键已过期则什么都不做 —— 对不存在的键
    直接 DECR 会凭空造出一个**无 TTL** 的键)。异常上抛。"""
    if await _eval(r, LUA_DECR, key) is not None:
        return
    if await r.exists(key):
        n = int(await r.decr(key))
        if n < 0:
            await r.set(key, 0, xx=True, keepttl=True)


def incr_mem(mem: Mem, key: str, win_s: int, clock: Clock = time.monotonic) -> Tuple[int, int]:
    now = clock()
    n, exp = mem.get(key, (0, 0.0))
    if exp <= now:
        n, exp = 0, now + float(max(1, int(win_s)))
    n += 1
    mem[key] = (n, exp)
    _maybe_prune(mem, now, key)             # 兜底存储有界(原地裁剪:调用方持有的是同一个 dict)
    return n, max(1, int(exp - now))


async def incr(r: Any, key: str, win_s: int, mem: Mem,
               clock: Clock = time.monotonic) -> Tuple[int, int]:
    """Redis 优先,抖动退化进程内(绝不放开)。→ (当前计数, 剩余窗口秒)。"""
    if r is not None:
        try:
            return await incr_redis(r, key, win_s)
        except Exception:                   # noqa: BLE001 —— 落进程内兜底
            pass
    return incr_mem(mem, key, win_s, clock)


async def decr(r: Any, key: str, mem: Mem) -> None:
    if r is not None:
        try:
            await decr_redis(r, key)
            return
        except Exception:                   # noqa: BLE001
            pass
    cur = mem.get(key)
    if cur:
        mem[key] = (max(0, cur[0] - 1), cur[1])


async def peek(r: Any, key: str, mem: Mem, clock: Clock = time.monotonic) -> int:
    if r is not None:
        try:
            v = await r.get(key)
            return int(v) if v is not None else 0
        except Exception:                   # noqa: BLE001
            pass
    n, exp = mem.get(key, (0, 0.0))
    return int(n) if exp > clock() else 0


async def ttl(r: Any, key: str, mem: Mem, default: int,
              clock: Clock = time.monotonic) -> int:
    """剩余寿命(秒);键不存在 / 无 TTL / 读不到 → default。"""
    if r is not None:
        try:
            t = await r.ttl(key)
            return int(t) if t is not None and int(t) > 0 else int(default)
        except Exception:                   # noqa: BLE001
            pass
    _n, exp = mem.get(key, (0, 0.0))
    left = int(exp - clock())
    return left if left > 0 else int(default)


async def lock(r: Any, key: str, lock_s: int, mem: Mem, clock: Clock = time.monotonic) -> None:
    """触限:把该键的剩余寿命**置为**锁定期 —— 锁定时长从触限那一刻起算。

    与 3.8.0 起线上(Redis 路径)的语义逐字一致:恰好触限时 `EXPIRE key lock`。复查推翻了
    5.2.0 初稿的「只延长不缩短」:配置 锁定 < 窗口(如窗口 1 小时、锁 1 分钟)时,那样会把
    锁拖到窗口结束,比运维配置的锁定时长长得多。进程内兜底同此口径(旧兜底用 max 只延长,
    与 Redis 路径本就不一致,一并拉齐)。"""
    lock_s = max(1, int(lock_s))
    if r is not None:
        try:
            await r.expire(key, lock_s)
            return
        except Exception:                   # noqa: BLE001
            pass
    cur = mem.get(key)
    if cur:
        mem[key] = (cur[0], clock() + float(lock_s))
