"""
redis_bus.py — Redis 上的协调层(任务分发 + 房间注册 + 快照 + SSE 总线)
================================================================================
一个 Redis 承载四件事,让「抓取端可水平扩展、Web 端只读」成立:

  1. 房间注册表   rooms(hash: room_id -> JSON{alias, active, added_at})
                  + rooms:active(set) —— Web 加/删房只改这里,不起线程。
  2. 延迟队列     sched(ZSET: member=任务串, score=到期毫秒)—— 错峰调度的载体。
                  多 worker 用「租约式原子领取」瓜分到期任务,天然去重、不重复处理;
                  worker 崩溃时任务在租约到期后自动重投(至少一次语义)。
  3. 房间快照     snap:{room}(hash)—— 抓取端每次拿到权威计时/出怪即写透,
                  Web 端渲染 live-rooms / 倒计时 / 爬虫状态全部读它,零上游、零重算。
  4. 事件总线     频道 draws:{room}(pub/sub)—— 新出怪即时推,Web 端 SSE 直接转发。

任务串编码(紧凑、便于 ZSET 去重):
  · "mp|{room}"            —— MainPage 刷新(每房仅一个在排,重排即更新分数)
  · "aw|{room}|{round}"    —— 某局 RoundAward 抓取(每局仅一个在排)
"""
from __future__ import annotations

import json
import random
import time
from typing import Any, Dict, List, Optional, Tuple

import redis.asyncio as aioredis

from . import wincount  # 5.2.0:原子窗口计数

try:
    from redis.asyncio import BlockingConnectionPool as _BlockingPool
except Exception:  # pragma: no cover
    _BlockingPool = None

# ── 键名 ─────────────────────────────────────────────────────────────────────
K_ROOMS = "rooms"                 # hash room_id -> json
K_ROOMS_ACTIVE = "rooms:active"   # set
K_ROOMS_PENDING = "rooms:pending" # hash alias -> 加入时刻 ms(待归一挂起;不开抓)
K_SCHED = "sched"                 # zset
K_SNAP = "snap:{room}"            # hash
CH_DRAWS = "draws:{room}"         # pub/sub channel
K_ATTEMPT = "awr:{room}:{round}"  # award 重试计数(短 TTL)
# ── 确证不可再取得的格点(官方缺失/页窗外;worker 确证自动链路取不到后登记) ──
#    zset,member=round_id,score=round_id。web 的 /coverage 只读它区分「官方缺 vs 本项目漏」。
#    整体 24h TTL:超过数据保留窗口后自然淘汰,不需要单独清理。
K_OFF_MISSING = "offmiss:{room}"  # zset of round_id (官方确证缺失的格点)
K_HIST_GATE = "histgate:{room}"   # 哨兵触发 GameHistory 的每房冷却闸(SET NX PX)
# ── 房→任务反向索引(消除全量 ZSET 扫描,支撑数千房下的 O(1) 删除/自愈) ──────
#    rt:{room}    该房当前在排的任务成员集合(mp|room / aw|room|round)
#    sched:rooms  当前有 ≥1 个在排任务的房集合(janitor 自愈直接读它,不扫 ZSET)
K_ROOM_TASKS = "rt:{room}"        # set of member strings
K_SCHED_ROOMS = "sched:rooms"     # set of room ids
# ── 数据保留(滚动清理) ──
# ── 命中率补算(4.6.0:pred_replay)────────────────────────────────────────────
#    lock 与 retention 同款(SET NX EX=巡检周期):全舰队同一周期恰好一个副本在算,
#    锁本身就是节拍,无需解锁/心跳。gate 是每房冷却,拿到才值得为该房查一次缺口 ——
#    稳态下全部房都握着 gate,补算协程的开销收敛为「一次 SMEMBERS + 零 SQL」。
#    Redis 无持久化(compose 关掉了),掉电即全部重探一遍 —— 幂等,只多几次 SELECT。
K_REPLAY_LOCK = "predreplay:sweep"
K_REPLAY_GATE = "predreplay:gate:{room}"
K_REPLAY_WAKE = "predreplay:wake"  # SET:唤醒/转正即入队的补算快道(worker 逐秒 SPOP 排水)
K_RET_LOCK = "retention:sweep"    # SET NX EX=巡检周期:跨 worker 副本互斥兼节拍
K_RET_LAST = "retention:last"     # json:最近一次清理统计(观测用,/api/crawler/status)
# ── 直播间自动发现(遍历繁星在播列表) ──
#    发现房为**纯运行态**(不落 PG rooms):由每轮遍历重建。前端据 K_ROOMS_DISCOVERED
#    过滤掉自动发现房(只显示用户显式添加的房)。hash 值为该房最近一次出现在在播
#    列表中的时刻(ms),供离线回收(prune)判定。
K_ROOMS_DISCOVERED = "rooms:discovered"  # hash room_id -> last_seen_ms(自动发现房;前端隐藏)
K_DISC_LOCK = "discovery:sweep"          # SET NX EX=遍历周期:跨 worker 副本互斥兼节拍
K_DISC_LAST = "discovery:last"           # json:最近一次遍历统计(观测用)
# ── 核验准入(核验房 = 自动发现看不见的房;台账真相在 PG verified_rooms) ──
#    verify:sweep  SET NX EX:核验房复核巡检的跨副本互斥兼节拍
#    verify:last   json:最近一轮复核统计(观测用,/api/crawler/status)
K_VERIFY_LOCK = "verify:sweep"
K_VERIFY_LAST = "verify:last"
K_VERIFY_PROBE = "verify:probe:{room}"   # SET NX EX:同一房的核验探测冷却(切房路径)
# ── 主播直播状态(5.0.6:名录绿点) ──
#    rooms:livestatus  hash room_id -> "state|ts_ms"(state: 1=直播中 / 0=未开播)。
#      只登记**策展房**(前端可见房),两路写入者:①在播列表遍历顺手记(零请求,
#      见 discovery.reconcile_discovered);②worker._livestatus 逐房 roomStatus 定谳。
#      **只有成功观测才写** —— 问不到就保留旧值让它自然变陈,由 web 按 stale_s
#      降为「未知」。纯运行态,不落 PG:Redis 重启 = 全员未知(方向朝「不知道」,
#      与 is_discovered 失败语义同哲学,绝不朝「没开播」撒谎)。
#    livestatus:sweep  SET NX EX=探测周期:跨副本互斥兼节拍
#    livestatus:last   json:最近一轮探测统计(观测用,/api/crawler/status)
K_ROOMS_LIVE = "rooms:livestatus"
K_LIVE_LOCK = "livestatus:sweep"
K_LIVE_LAST = "livestatus:last"
# ── hist-mode(3.5.0:后台发现房 GameHistory 轮询) ──
#    hist:lastok  zset room -> 最近一次轮询成功时刻 ms —— 「最老轮询年龄」是本模式
#                 第一健康指标(> interval×2 黄、> edge_after 红),ZRANGE 头即最老。
#                 清理:模式退出(转正/回滚)与删房/回收路径 ZREM,防僵尸项撒谎。
#    stats:histmode  hash 运行统计(window_lost 越窗丢失累计 / short_page 短页告警等)
K_HIST_LASTOK = "hist:lastok"
K_HISTMODE_STATS = "stats:histmode"
# ── curated-idle(3.7.0:空闲策展房降级;依赖 hist-mode) ──
#    rooms:cold       hash room_id -> since_ms(已降级的**空闲策展房**)。与发现集
#                     **分离**:冷房仍在名录/前端可见(_visible_rooms 只按发现集
#                     过滤),只是暂以 GameHistory 轮询供数、预测暂停(权重冻结不
#                     损坏)。任何一次用户侧真实访问即刻唤醒(web._touch_room)。
#                     清理:唤醒 / 轮询退出分支 / 删房 / 扫描自愈,四路皆幂等。
#                     不落 PG:标记丢失(Redis 重启)= 全部醒回实时 —— 恢复方向
#                     永远朝「多算」,与 is_discovered 失败语义同一哲学。
#    rooms:lastaccess zset room -> 最近一次**用户侧**访问 ms。web 写(history[非
#                     passive]/days/prediction/summary/coverage/SSE 连接与 20s
#                     心跳),ZADD GT 只进不退。资料(profile)与列表端点**不算
#                     访问** —— 前端启动期会为名录逐房回填头像,若计入则永远无房
#                     可判闲。无记录的房由扫描 ZADD NX 播种(年龄未知绝不判闲)。
#    coldsweep:lock   SET NX EX=60:降级扫描的跨副本互斥兼节拍(全舰队 ≤1 次/分钟)
K_ROOMS_COLD = "rooms:cold"
K_LAST_ACCESS = "rooms:lastaccess"
K_COLD_LOCK = "coldsweep:lock"
# ── 单账号「同时只监控 1 个房」租约(安全加固 3.9.0) ─────────────────────────
#    alr:u{uid}(hash: room / tab / ts_ms)—— 每个登录账号一把独占租约。明细端点
#    (prediction/summary/coverage/history[非 passive])与 SSE 建流/心跳向它「抢/续
#    租」:**3.9.3 起 last-wins** —— 用户显式切房(claim)无条件抢占,明细/SSE 心跳
#    (renew)同房则续、被别处切走则回「跟随目标房」让前端自动切过去。租约靠 SSE 20s
#    心跳与明细轮询续期,标签页关闭/关页 sendBeacon 即释放 → 否则 TTL 到期自动释放。不落 PG:纯运行
#    态,Redis 重启即全部释放(恢复方向永远朝「放行」,与 is_discovered 失败语义同哲学)。
K_ACTIVE_LEASE = "alr:u{uid}"    # hash room/tab/ts_ms（每账号一把活跃房租约）
CH_LEASE_EVT = "alr:evt:u{uid}"  # pub/sub:该账号显式 claim 切房时广播(3.9.4)——
                                 #   SSE 端订阅后**收到即做一次权威 renew**,把「被切走」
                                 #   的发现延迟从「≤20s 心跳下一拍」压到亚秒;消息本身
                                 #   只是触发器,不作决策依据(以 renew 返回为准,天然免疫
                                 #   乱序/陈旧事件)。不订阅/丢消息 = 逐字节退回心跳节拍。
# ── 行为遥测:疑似脚本来源画像(安全加固 3.9.2,**纯遥测 / 绝不阻断**) ─────────
#    sig:h:{sid}(hash)—— 每个会话(sid = 会话 Cookie 的 SHA-256 前 24 位,**不落原值**)
#      的滚动计数:html / asset / detail / detail_ok / pow_ok / pow_fail / sse,外加
#      first / last / ua / ip / uid / uname 上下文。TTL 滚动(默认 30 分钟)——窗口内
#      自然汇聚、过窗自动蒸发,内存有界。
#    sig:z(zset sid→last_ms)—— 枚举用;读时按窗口 zremrangebyscore 剪除过期 sid(自清理)。
#    sig:r:{sid}(**HyperLogLog**)—— 该会话短时访问过的不同直播间的**基数估计**(轮转
#      信号),带同款 TTL 上限。用 HLL 而非 SET 是刻意的:room 在中间件侧按请求路径记入,
#      **被 401/429 挡下也记**,故一个已登录的攻击者能用海量垃圾房号(全 429)把普通 SET
#      按**请求速率无界撑大**(实测 5000 请求→5000 成员/单会话);HLL 在真 Redis 上**固定
#      ~12KB 封顶**、小基数精确(评分只看「≥6」、面板只显计数,近似完全够用),从结构上消除
#      这个内存放大面。
#    纯运行态,不落 PG,Redis 重启即清空。评分**只**用于管理台呈现与「软限流分层」,
#    永不作为自动封禁依据(自动动作仅由 L1 租约违规 / L2 证明缺失等确定性事件触发)。
K_SIG_HASH = "sig:h:{sid}"
K_SIG_INDEX = "sig:z"
K_SIG_ROOMS = "sig:r:{sid}"
#    ── 4.9.0 误报修复:**浏览器足迹**(与画像本体分离的长效小键)────────────────
#    背景(实地复现,非推断):画像 Hash 的 TTL 由「最近一次事件」续期,而 `html`
#    在 SPA 里是**整个页面生命周期只发生一次**的事件。app.js 的 visibilitychange
#    分支明确「隐藏期间 schedulePolls 完全静默」——手机锁屏 / 标签页切后台 > 窗口
#    时长后画像自然过期;回到前台第一拍就打明细,画像**以 html=0 重建**,真人于是
#    稳稳踩中最强因子(+45「从不加载页面」)。实测:静默超窗后 9 次明细即得 45 分。
#    修法:见过 html/asset 时另置一枚 ~50B 的足迹键,TTL 远长于画像窗(默认 24h)。
#    它只回答「这个会话里到底有没有真浏览器开过页面」,不参与任何计数,故不受
#    窗口漂移影响;自带 TTL,内存严格有界(每会话 1 键,随会话消亡)。
K_SIG_FOOT = "sig:f:{sid}"


def _room_of(member: str) -> str:
    """从任务成员串解析房号(mp|room / aw|room|round)。"""
    parts = member.split("|")
    return parts[1] if len(parts) > 1 else ""

now_ms = lambda: int(time.time() * 1000)  # noqa: E731


def extrapolate_server_now(snap: dict, host_now_ms: int) -> int:
    """快照钟外推:返回「当前」的上游服务器毫秒时刻 = 主机当前时刻 + 最近一次
    MainPage 实测的钟差(snapshot.serverOffsetMs)。

    绝不可把快照里的 serverNowMs(**抓取那一刻**的钟,陈旧 0~50s)当作当前时刻
    下发给前端 —— 前端 calibrate() 把每一拍 serverNowMs−Date.now() 以 EMA 融入
    校时,陈旧钟会被吸收成周期性回拖(观测台倒计时"备战归零后回溯到布置期"、
    与游戏差 ±10s 的锯齿抖动,均源于此)。钟差在两次抓取间的漂移仅为晶振 ppm 级,
    外推恒安全;快照缺失/未抓过时钟差按 0(即 host 钟),优于任何陈旧值。
    调用方:web SSE 的 connected/heartbeat、worker 出怪推送、crawler/status。"""
    try:
        off = int(snap.get("serverOffsetMs") or 0)
    except (TypeError, ValueError, AttributeError):
        off = 0
    return int(host_now_ms) + off


def task_mainpage(room: str) -> str:
    return f"mp|{room}"


def task_award(room: str, round_id: int) -> str:
    return f"aw|{room}|{int(round_id)}"


def task_hist(room: str) -> str:
    """hist-mode(3.5.0):后台发现房的 GameHistory 轮询任务(每房仅一个在排,
    重排即更新分数)。parse_task 对未知类型的通用透传天然覆盖它;_room_of /
    反向索引 / 删房清理 / janitor 差集全部零改动兼容(实地核查:63-66/96-103)。"""
    return f"hs|{room}"


def parse_task(member: str) -> Tuple[str, str, Optional[int]]:
    """(kind, room, round_id|None)。kind ∈ {'mp','aw'}。"""
    parts = member.split("|")
    if parts[0] == "mp":
        return "mp", parts[1], None
    if parts[0] == "aw":
        return "aw", parts[1], int(parts[2])
    return parts[0], (parts[1] if len(parts) > 1 else ""), None


# ── 原子领取(租约式):取出到期任务并把它们的分数顺延一个 grace,
#    在处理期间避免被其它 worker 重复领取;处理完由 worker ack(ZREM)或重排(ZADD)。
_LUA_CLAIM = """
local key   = KEYS[1]
local now   = tonumber(ARGV[1])
local batch = tonumber(ARGV[2])
local grace = tonumber(ARGV[3])
local items = redis.call('ZRANGEBYSCORE', key, '-inf', now, 'LIMIT', 0, batch)
if #items > 0 then
  local lease = now + grace
  for i = 1, #items do
    redis.call('ZADD', key, lease, items[i])
  end
end
return items
"""

# ── ack(原子):从延迟队列移除任务,并维护房→任务反向索引 ─────────────────────
#    KEYS[1]=sched(ZSET) KEYS[2]=sched:rooms(SET)  ARGV[1]=member ARGV[2]=rt 键前缀
_LUA_ACK = """
local member = ARGV[1]
local rtpfx  = ARGV[2]
redis.call('ZREM', KEYS[1], member)
-- 解析房号:member 形如 mp|room 或 aw|room|round
local parts = {}
for s in string.gmatch(member, '[^|]+') do parts[#parts+1] = s end
local room = parts[2]
if room then
  local rtkey = rtpfx .. room
  redis.call('SREM', rtkey, member)
  if redis.call('SCARD', rtkey) == 0 then
    redis.call('SREM', KEYS[2], room)
  end
end
return 1
"""

# ── 续租(原子 compare-and-expire):仅当锁仍是**我**持有的令牌时才延长 TTL ──────
#    KEYS[1]=锁键  ARGV[1]=我的令牌  ARGV[2]=新 TTL(秒)
#    返回 1=续租成功;0=锁已易主/已消失(调用方应立刻收手)
_LUA_RENEW = """
if redis.call('GET', KEYS[1]) == ARGV[1] then
  return redis.call('EXPIRE', KEYS[1], tonumber(ARGV[2]))
end
return 0
"""

# ── 活跃房租约 · 抢/续租(原子;**last-wins** —— 以最后一次切换的直播间为准) ─────
#    KEYS[1]=alr:u{uid}
#    ARGV[1]=req_room  ARGV[2]=req_tab(可空)  ARGV[3]=now_ms  ARGV[4]=ttl_ms
#    ARGV[5]=claim(1=用户显式切房,抢占 / 0=心跳·明细续租,不符则跟随)
#    返回 {granted(0/1), room};granted=0 时 room = **应跟随过去的活跃房**
#
#    键结构(hash):room=当前活跃房 · ts=最近一次活动(整把租约的存活判据)
#                  t:{tab}=该标签页最近一次活动 ms(**只记非空标签页**)
#
#    决策表(自上而下,首个命中即返回):
#      · 无持租 / 整把租约过期(now-ts>ttl)   → 授予(重置为本房本页)
#      · claim==1(用户**显式切房**)          → 授予(**无条件抢占**;不 DEL,保留其它
#                                               活页的 t: 项 —— 它们下一拍 renew 时会
#                                               看到活跃房已变而**跟随**过来)
#      · 持租房 == 请求房                     → 授予(同房多视图 / 心跳续租)
#      · 其余(renew 时已被别处切走)          → {0, 活跃房} → 端点回 409 room_switched
#                                               + 房号,前端**自动跟随**(不是阻断)
#
#    为何 renew 对异房**永不抢占**:否则 A/B 两窗的心跳会把租约来回抢 → **抖动**。
#    只有用户显式动作才 claim;跟随后不再续旧房 → 收敛。
#
#    t: 集合的两道剪枝(扫描时顺手做):
#      ① 陈旧项(now-ts>ttl)—— 崩溃/掉线页自然退场,是「永不锁死」的自愈基础;
#      ② **超出 CAP 的最旧活项** —— tab 来自客户端头/查询串(**攻击者可控**),而 SSE
#         建流路径**无限流兜底**,同房 renew 会 HSET t:{tab};不封顶则随机 tab 可按
#         **连接速率**把本 hash 撑大(实测 3000 次建流 → 3000 条目/64KB,单账号)。
#         封顶后稳态 33 条(CAP 32 + 本次自己)≈0.7KB。
#      安全性:last-wins 下 t: 集合**只**用于「剪陈旧」与释放时的「还有没有活页」,
#      无任何决策依赖其条目数;万一误淘活页,它下一拍 renew 会重新 HSET(空租约→授予),
#      行为无损。(`test_lease_tab_set_bounded_against_random_tabs` 钉住)
_LUA_LEASE_ACQ = """
local key = KEYS[1]
local req_room = ARGV[1]
local req_tab  = ARGV[2]
local now = tonumber(ARGV[3])
local ttl = tonumber(ARGV[4])
local claim = tonumber(ARGV[5]) or 0   -- 1=显式切房(last-wins 抢占) / 0=续租(不符则跟随)

local all = redis.call('HGETALL', key)
local hroom = false
local hts = 0
local stale = {}
local live = {}
for i = 1, #all, 2 do
  local k = all[i]
  local v = all[i + 1]
  if k == 'room' then
    hroom = v
  elseif k == 'ts' then
    hts = tonumber(v) or 0
  elseif string.sub(k, 1, 2) == 't:' then
    local tts = tonumber(v) or 0
    if (now - tts) > ttl then
      stale[#stale + 1] = k
    else
      live[#live + 1] = {k = k, ts = tts}
    end
  end
end
-- 活页数上限:tab 由客户端头/查询串提供(**攻击者可控**),而 SSE 建流无限流兜底 ——
-- 同房 renew 会 HSET t:{tab},若不封顶,随机 tab 可按**连接速率**把本 hash 撑大
-- (实测 3000 次建流 → 3000 条目/64KB,单账号)。last-wins 下 t: 集合只用于
-- 「剪陈旧」与 REL 的「还有没有活页」,无决策依赖条目数,故淘汰最旧的绝对安全:
-- 万一误淘活页,它下一拍 renew 会重新 HSET(空租约→grant),行为无损。
local CAP = 32
if #live > CAP then
  table.sort(live, function(a, b) return a.ts > b.ts end)   -- 新 → 旧
  for i = CAP + 1, #live do stale[#stale + 1] = live[i].k end
end
if #stale > 0 then
  -- 分批 HDEL:Lua 5.1 的 unpack 有栈上限(LUAI_MAXCSTACK,默认 8000),
  -- 一次性展开数千条会炸栈;按 200 一批安全展开。
  local _unpack = unpack or table.unpack
  local i = 1
  while i <= #stale do
    local j = i + 199
    if j > #stale then j = #stale end
    local chunk = {}
    for x = i, j do chunk[#chunk + 1] = stale[x] end
    redis.call('HDEL', key, _unpack(chunk))
    i = j + 1
  end
end

local function grant(reset)
  if reset then
    redis.call('DEL', key)
  end
  redis.call('HSET', key, 'room', req_room, 'ts', now)
  if req_tab ~= '' then
    redis.call('HSET', key, 't:' .. req_tab, now)
  end
  redis.call('PEXPIRE', key, ttl)
  return {1, req_room}
end

-- 空租约 / 整把过期 → 直接授予(本页成为活跃房;reset 清掉可能的陈旧碎片)
if (hroom == false) or ((now - hts) > ttl) then return grant(true) end
-- 显式切房(last-wins):无条件抢占到 req_room。**保留**其它活页的 t: 项 —— 它们在
-- 各自下一拍 renew 时会看到活跃房已变、从而**跟随**汇聚到本房(不 DEL,故不误删活页)。
if claim == 1 then return grant(false) end
-- 续租:仍在活跃房 → 续租刷新;已被别处切走 → 返回 {0, 活跃房} 让本页**跟随**过去。
-- (关键:renew 对"异房"永不抢占 —— 否则 A/B 各自心跳会把租约来回抢,产生抖动。)
if hroom == req_room then return grant(false) end
return {0, hroom}
"""

# ── 活跃房租约 · 条件释放(只摘掉**我这一页**;还有别的页在看则租约留任) ─────────
#    KEYS[1]=alr:u{uid}  ARGV[1]=room  ARGV[2]=tab  ARGV[3]=now_ms  ARGV[4]=ttl_ms
#    返回 1=整把租约已释放 / 0=未释放(房不符 或 仍有别的活页)
#    SSE 断流 / 关页 sendBeacon 时调用:摘掉自己后若已无任何活页,整把删除 —— 让
#    「关页后立刻换房」零等待;仍有别的页看同一房时保留租约(它们还在正常监控)。
#
#    **摘 tab 与房号解耦**(3.9.3 审计修正):旧实现一上来就按房号匹配,不符即整个
#    no-op —— 而 last-wins 下别的窗口 claim 走活跃房后,本页 release 用的仍是**旧房号**,
#    于是本页的 t: 项**永久残留**;等最后一个真实观看者关窗时,alive 把残留项算作
#    活页 → 整把租约**不被删除** → 形成「无人观看却仍指向某房」的**幽灵租约**,
#    使新窗口被要求跟随到没人看的房(实测可复现)。
#    现在:① 先无条件摘掉**我这一页**(我要走了就该退场,与活跃房是谁无关,且只动
#    我自己的字段,天然安全);② **整把删除**才需房号匹配 —— 房不符说明别人已 claim
#    走,绝不能删他的租约。(`test_release_no_phantom_lease_after_preempt` 钉住)
_LUA_LEASE_REL = """
local key = KEYS[1]
local room = ARGV[1]
local tab  = ARGV[2]
local now = tonumber(ARGV[3])
local ttl = tonumber(ARGV[4])
if tab ~= '' then
  redis.call('HDEL', key, 't:' .. tab)
end
if redis.call('HGET', key, 'room') ~= room then return 0 end
local all = redis.call('HGETALL', key)
local alive = 0
for i = 1, #all, 2 do
  local k = all[i]
  if string.sub(k, 1, 2) == 't:' then
    if (now - (tonumber(all[i + 1]) or 0)) <= ttl then alive = alive + 1 end
  end
end
if alive == 0 then
  redis.call('DEL', key)
  return 1
end
return 0
"""


class RedisBus:
    def __init__(self, url: str, max_connections: int = 128,
                 pool_timeout: float = 30.0):
        self._url = url
        # 用 BlockingConnectionPool 而非默认非阻塞池:redis-py 8 默认池打满会直接抛
        # MaxConnectionsError,而 worker 的数百 consumer 协程会并发打 Redis
        # (claim/ack/快照/令牌桶/room_gate)。阻塞池在打满时**排队等待 pool_timeout 秒**
        # 再放行,避免任一 Redis 操作因瞬时池压力崩溃(令牌桶另有退避重试兜底,但快照/
        # 调度/ack 等路径没有,阻塞池给它们统一护栏)。上限按并发规模放大。
        # _BlockingPool 不可用(极旧 redis-py)时优雅回退到默认非阻塞池。
        if _BlockingPool is not None:
            self.r: aioredis.Redis = aioredis.Redis(
                connection_pool=_BlockingPool.from_url(
                    url, encoding="utf-8", decode_responses=True,
                    max_connections=int(max_connections),
                    timeout=float(pool_timeout)))
        else:  # pragma: no cover
            self.r = aioredis.from_url(
                url, encoding="utf-8", decode_responses=True,
                max_connections=int(max_connections))
        self._claim_sha: Optional[str] = None
        self._ack_sha: Optional[str] = None
        self._lease_acq_sha: Optional[str] = None
        self._lease_rel_sha: Optional[str] = None

    async def close(self) -> None:
        try:
            await self.r.aclose()
        except Exception:
            pass

    async def ping(self) -> bool:
        return bool(await self.r.ping())

    # ── 房间注册表 ────────────────────────────────────────────────────────────
    async def add_room(self, room: str, alias: Optional[str] = None) -> None:
        room = str(room)
        meta = {"alias": str(alias or room), "active": True, "added_at": now_ms()}
        await self.r.hset(K_ROOMS, room, json.dumps(meta, ensure_ascii=False))
        await self.r.sadd(K_ROOMS_ACTIVE, room)

    async def add_rooms_bulk(self, items: List[Tuple[str, str]],
                             batch_size: int = 1000) -> None:
        """批量入名录(room, alias),并把这些房移出挂起集。

        **分块执行**(3.4.0 复查补齐;默认 1000 房/批):本方法在 1 万房冷启动
        (worker 重启回灌 / 首轮发现)时会被喂入全量房间 —— 不分块时单个 MULTI
        事务 ≈ 1 SADD(N) + N×HSET + 1 HDEL(N) ≈ **1 万+条命令**,单线程的 Redis
        会整体停顿数十毫秒并放大组包内存,这正是 `discovered_prune_bulk` 分块注释
        里点名要避免的事(同一标准应两处一致)。分块后每批 ≤ ~1k 条,停顿摊平。
        批间无原子性要求:每批自身事务内一致;调用方(restore / reconcile /
        admission)全部幂等,半途失败由下一轮回灌/遍历/janitor 补齐。"""
        items = [(str(r), str(a or r)) for r, a in items if str(r)]
        if not items:
            return
        step = max(1, int(batch_size))
        for i in range(0, len(items), step):
            chunk = items[i:i + step]
            pipe = self.r.pipeline(transaction=True)
            rooms = [r for r, _ in chunk]
            pipe.sadd(K_ROOMS_ACTIVE, *rooms)
            for r, a in chunk:
                meta = {"alias": a, "active": True, "added_at": now_ms()}
                pipe.hset(K_ROOMS, r, json.dumps(meta, ensure_ascii=False))
            # 转正:把真实号与别名都从挂起集清净(避免重启回灌把它们再灌回挂起)
            aliases = {a for _, a in chunk} | set(rooms)
            pipe.hdel(K_ROOMS_PENDING, *aliases)
            await pipe.execute()

    async def pending_add_bulk(self, aliases: List[str]) -> None:
        """批量挂起(待归一)。仅对尚未挂起的别名置入(hsetnx 语义,逐个但同一 pipeline)。"""
        aliases = [str(a) for a in aliases if str(a)]
        if not aliases:
            return
        pipe = self.r.pipeline(transaction=True)
        for a in aliases:
            pipe.hsetnx(K_ROOMS_PENDING, a, now_ms())
        await pipe.execute()

    async def remove_room(self, room: str) -> None:
        room = str(room)
        await self.r.srem(K_ROOMS_ACTIVE, room)
        await self.r.hdel(K_ROOMS_PENDING, room)   # 挂起中的也一并删净
        raw = await self.r.hget(K_ROOMS, room)
        if raw:
            try:
                meta = json.loads(raw)
            except ValueError:
                meta = {}
            meta["active"] = False
            await self.r.hset(K_ROOMS, room, json.dumps(meta, ensure_ascii=False))
        # 清掉该房在排的调度任务(mp + 任意 aw)—— 直接读该房的任务索引(小集合),
        # 不再全量扫描 ZSET(旧实现 O(全队列),数千房时每次删房都要拉万级成员)。
        rtkey = K_ROOM_TASKS.format(room=room)
        drop = list(await self.r.smembers(rtkey))
        pipe = self.r.pipeline(transaction=True)
        if drop:
            pipe.zrem(K_SCHED, *drop)
        pipe.delete(rtkey)
        pipe.srem(K_SCHED_ROOMS, room)
        pipe.zrem(K_HIST_LASTOK, room)     # hist-mode 健康指标残项一并清净
        pipe.hdel(K_ROOMS_COLD, room)      # curated-idle 冷标/访问戳同为「删房即清」
        pipe.zrem(K_LAST_ACCESS, room)     #   不变量:cold ⊆ 活跃策展房(僵尸标撒谎)
        await pipe.execute()

    async def remove_rooms_bulk(self, rooms: List[str]) -> None:
        """批量删房(名录 + 挂起 + 索引 + 调度任务),单次 pipeline 往返完成。"""
        rooms = [str(r) for r in rooms if str(r)]
        if not rooms:
            return
        # 先读各房任务索引(collect 后一次清理)
        pipe = self.r.pipeline(transaction=False)
        for r in rooms:
            pipe.smembers(K_ROOM_TASKS.format(room=r))
        task_sets = await pipe.execute()
        pipe = self.r.pipeline(transaction=True)
        pipe.srem(K_ROOMS_ACTIVE, *rooms)
        pipe.hdel(K_ROOMS_PENDING, *rooms)
        for r, members in zip(rooms, task_sets):
            if members:
                pipe.zrem(K_SCHED, *members)
            pipe.delete(K_ROOM_TASKS.format(room=r))
            meta = {"alias": r, "active": False, "added_at": now_ms()}
            pipe.hset(K_ROOMS, r, json.dumps(meta, ensure_ascii=False))
        pipe.srem(K_SCHED_ROOMS, *rooms)
        pipe.zrem(K_HIST_LASTOK, *rooms)   # hist-mode 健康指标残项一并清净
        pipe.hdel(K_ROOMS_COLD, *rooms)    # curated-idle 冷标/访问戳同为「删房即清」
        pipe.zrem(K_LAST_ACCESS, *rooms)
        await pipe.execute()

    async def active_rooms(self) -> List[str]:
        return sorted(await self.r.smembers(K_ROOMS_ACTIVE))

    async def active_count(self) -> int:
        """名录基数(SCARD,O(1))。给「判否之前先确认名录本身是就绪的」用 ——
        0 不是一个正常的运行态,它意味着回灌还没跑完或 Redis 刚被清空。"""
        return int(await self.r.scard(K_ROOMS_ACTIVE) or 0)

    async def is_active(self, room: str) -> bool:
        """该房是否在后台抓取名录里(策展 + 自动发现全集)。

        单房判定必须走 SISMEMBER(O(1)),**不得**用 `room in await active_rooms()`
        —— 后者是 SMEMBERS 全量回传,万房规模下每次判定都要搬一整张集合过网;
        切房是高频路径,那样等于给每次切房加一笔与房数成正比的开销。"""
        return bool(await self.r.sismember(K_ROOMS_ACTIVE, str(room)))

    # ── 待归一挂起(2.9.4 硬性约束:九法数据只允许按真实房间号抓取。归一暂不可用
    #    时绝不按原号开抓 —— 那会抓到 mapi 上另一路「凭空局」。挂起项名录可见,
    #    由 worker janitor 周期重试归一,成功即转正开抓。) ─────────────────────
    async def pending_add(self, alias: str) -> None:
        await self.r.hsetnx(K_ROOMS_PENDING, str(alias), now_ms())

    async def pending_remove(self, alias: str) -> None:
        await self.r.hdel(K_ROOMS_PENDING, str(alias))

    async def pending_remove_bulk(self, aliases: List[str]) -> None:
        """批量移出挂起集(一次 hdel)。批量准入转正时用:把原始输入别名一并清净,
        与单房 add 的 pending_remove(room) 语义对齐(避免自定义别名下短号残留挂起)。"""
        aliases = [str(a) for a in aliases if str(a)]
        if aliases:
            await self.r.hdel(K_ROOMS_PENDING, *aliases)

    async def is_pending(self, alias: str) -> bool:
        """该号是否在「待归一挂起集」里(HEXISTS,O(1))。挂起房尚未进 rooms:active,
        但**前端名录里是有卡的**(_build_live_rooms 会给它画 pending 卡),故任何
        「是否属于本后台」的判定都必须把它算进来,否则会把正在等归一的房误判成
        「已不监控」。"""
        return bool(await self.r.hexists(K_ROOMS_PENDING, str(alias)))

    async def pending_rooms(self) -> List[str]:
        return sorted((await self.r.hgetall(K_ROOMS_PENDING)).keys())

    async def pending_items(self) -> Dict[str, int]:
        """alias -> 加入时刻 ms(janitor 超龄清理用)。"""
        raw = await self.r.hgetall(K_ROOMS_PENDING)
        out: Dict[str, int] = {}
        for k, v in raw.items():
            try:
                out[k] = int(v)
            except (TypeError, ValueError):
                out[k] = 0
        return out

    async def room_meta(self, room: str) -> Dict[str, Any]:
        raw = await self.r.hget(K_ROOMS, str(room))
        if not raw:
            return {}
        try:
            return json.loads(raw)
        except ValueError:
            return {}

    async def alias_of(self, room: str) -> str:
        return (await self.room_meta(room)).get("alias", str(room))

    # ── 调度(延迟队列 + 房→任务反向索引) ──────────────────────────────────────
    async def sched_backlog(self) -> Tuple[int, int]:
        """(**到期未领的任务数**, **最老到期任务已迟到多少 ms**)。

        ── 这是本系统最重要的健康指标,3.4.2 之前它在任何地方都没有暴露 ──────────
        worker 算力不足时,延迟队列里**到期的任务领不完** —— 数据一条都不会丢
        (coverage 仍报 `complete: true`、`official_missing: []`),但**每个房的抓取
        都被整体推迟**。前端表现完全就是用户报的两个症状:

          · 「出怪倒计时结束、下一局都开跑了,才显示上一局的出怪」
            —— 出怪任务本该在备战+2.3s 执行(实测上游备战+2.2s 就绪),积压下被推迟
               整整一局才轮到;
          · 「预测数据不显示/滞后」—— 预测是**随出怪一起**生成的,出怪晚一局,
            预测就晚一局,`pending_prediction` 随之落后 → 被孤儿过滤 → 前端 main=[]。

        判据(实测口径):
          · 健康:积压 0~个位数,最老迟到 < 1s(1000 房单 worker 实测积压 0–6);
          · 病态:最老迟到 > 10s —— 抓取窗口(出怪阶梯全长 26.5s)已被吃掉,数据必晚。
        """
        now = now_ms()
        cnt = await self.r.zcount(K_SCHED, "-inf", now)
        lag = 0
        if cnt:
            oldest = await self.r.zrange(K_SCHED, 0, 0, withscores=True)
            if oldest:
                lag = max(0, now - int(oldest[0][1]))
        return int(cnt), int(lag)

    async def schedule(self, member: str, due_ms: int) -> None:
        room = _room_of(member)
        pipe = self.r.pipeline(transaction=True)
        pipe.zadd(K_SCHED, {member: int(due_ms)})
        if room:
            pipe.sadd(K_ROOM_TASKS.format(room=room), member)
            pipe.sadd(K_SCHED_ROOMS, room)
        await pipe.execute()

    async def schedule_many(self, items: Dict[str, int],
                            batch_size: int = 1000) -> None:
        """批量排期(member -> 到期 ms)并维护房→任务反向索引。

        **分块执行**(3.4.0 复查补齐;默认 1000 任务/批):schedule_spread 在 1 万房
        冷启动时会把全量首抓任务喂进来 —— 不分块时单个 MULTI ≈ 1 ZADD(N 成员) +
        N×SADD(rt:) + 1 SADD ≈ 万级命令,与 add_rooms_bulk 同款的 Redis 整体停顿。
        分块后停顿摊平;常态调用(每事件 2 项)len ≤ batch,行为与旧实现逐字节一致。
        批间无原子性要求:ZADD/SADD 幂等,半途失败由 janitor 补排。"""
        if not items:
            return
        pairs = list(items.items())
        step = max(1, int(batch_size))
        for i in range(0, len(pairs), step):
            chunk = pairs[i:i + step]
            pipe = self.r.pipeline(transaction=True)
            pipe.zadd(K_SCHED, {m: int(d) for m, d in chunk})
            rooms = set()
            for m, _ in chunk:
                room = _room_of(m)
                if room:
                    pipe.sadd(K_ROOM_TASKS.format(room=room), m)
                    rooms.add(room)
            if rooms:
                pipe.sadd(K_SCHED_ROOMS, *rooms)
            await pipe.execute()

    async def ack(self, member: str) -> None:
        sha = await self._ack_script()
        try:
            await self.r.evalsha(sha, 2, K_SCHED, K_SCHED_ROOMS, member, "rt:")
        except Exception as e:
            if "NOSCRIPT" in str(e):
                self._ack_sha = None
                sha = await self._ack_script()
                await self.r.evalsha(sha, 2, K_SCHED, K_SCHED_ROOMS, member, "rt:")
            else:
                raise

    async def _claim_script(self) -> str:
        if self._claim_sha is None:
            self._claim_sha = await self.r.script_load(_LUA_CLAIM)
        return self._claim_sha

    async def _ack_script(self) -> str:
        if self._ack_sha is None:
            self._ack_sha = await self.r.script_load(_LUA_ACK)
        return self._ack_sha

    async def claim_due(self, batch: int, grace_ms: int) -> List[str]:
        """原子取出到期任务(并顺延租约 grace_ms)。返回任务串列表。"""
        sha = await self._claim_script()
        try:
            return await self.r.evalsha(sha, 1, K_SCHED, now_ms(), batch, grace_ms)
        except Exception as e:
            if "NOSCRIPT" in str(e):
                self._claim_sha = None
                sha = await self._claim_script()
                return await self.r.evalsha(sha, 1, K_SCHED, now_ms(), batch, grace_ms)
            raise

    async def scheduled_rooms(self) -> set:
        """当前有在排任务的房集合(janitor 自愈用)。直接读反向索引 sched:rooms,
        不再全量 ZRANGE 整个延迟队列再逐条解析(旧实现每 30s 在每个 worker 里拉
        万级成员;数千房下纯浪费)。"""
        return set(await self.r.smembers(K_SCHED_ROOMS))

    async def schedule_spread(self, members: List[str], base_ms: int,
                              window_ms: int) -> None:
        """把一批任务的到期时刻在 [base, base+window] 内均匀铺开(错峰起抓的载体)。
        用于批量准入:数千房首次 MainPage 不再全排同一毫秒,消除令牌竞争的重排风暴。"""
        members = [m for m in members if m]
        if not members:
            return
        n = len(members)
        span = max(0, int(window_ms))
        items = {m: base_ms + (i * span // n if n > 1 else 0)
                 for i, m in enumerate(members)}
        await self.schedule_many(items)

    # ── 单房对上游的最小请求间隔闸门(防单房异常自旋打爆某一路;安全网,非常态间隔) ──
    async def room_gate(self, room: str, interval_ms: int) -> Tuple[bool, int]:
        """返回 (allowed, wait_ms)。用 Redis `SET NX PX` 做每房冷却锁:拿到=放行并
        置一个 interval_ms 冷却;否则返回剩余冷却毫秒(调用方据此把任务稍后重排)。
        正常运行时每房约每 50s 才一次上游请求,远大于该间隔,闸门永不触发;仅在
        异常(如 bug 导致快速重排)时把单房上游 QPS 兜底钳在 1/interval。"""
        if interval_ms <= 0:
            return True, 0
        key = f"rg:{room}"
        ok = await self.r.set(key, "1", nx=True, px=int(interval_ms))
        if ok:
            return True, 0
        ttl = await self.r.pttl(key)
        return False, max(1, ttl if (ttl and ttl > 0) else interval_ms)

    # ── award 重试计数(短 TTL,随局自然过期) ────────────────────────────────
    async def award_attempt_incr(self, room: str, round_id: int) -> int:
        key = K_ATTEMPT.format(room=room, round=int(round_id))
        n, _t = await wincount.incr_redis(self.r, key, 300)   # 5.2.0:原子(旧写法 EXPIRE 抖一次即永久键)
        return int(n)

    async def award_attempt_clear(self, room: str, round_id: int) -> None:
        await self.r.delete(K_ATTEMPT.format(room=room, round=int(round_id)))

    # ── 官方本身缺失的格点(worker 确证后登记;web /coverage 只读) ─────────────
    async def official_missing_mark(self, room: str, round_id: int) -> None:
        """确证官方也没有这一局 → 登记为「官方缺失」,并把整个 zset 续期到 24h。"""
        key = K_OFF_MISSING.format(room=str(room))
        rid = int(round_id)
        await self.r.zadd(key, {str(rid): rid})
        await self.r.expire(key, 24 * 3600)

    async def official_missing_in(self, room: str, grid) -> list:
        """返回 grid(格点列表)中已被登记为「官方缺失」的那些。空/异常回空列表。"""
        if not grid:
            return []
        key = K_OFF_MISSING.format(room=str(room))
        lo, hi = min(grid), max(grid)
        try:
            members = await self.r.zrangebyscore(key, lo, hi)
        except Exception:
            return []
        gset = {int(g) for g in grid}
        out = []
        for m in members:
            try:
                v = int(m)
            except (TypeError, ValueError):
                continue
            if v in gset:
                out.append(v)
        return out

    # ── 房间快照(Web 端只读渲染) ───────────────────────────────────────────
    async def set_snapshot(self, room: str, fields: Dict[str, Any]) -> None:
        mapping = {k: (json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list))
                       else ("" if v is None else str(v)))
                   for k, v in fields.items()}
        await self.r.hset(K_SNAP.format(room=room), mapping=mapping)

    async def snap_incr(self, room: str, key: str, by: int = 1) -> int:
        """快照字段原子自增(定期校验计数等)。"""
        return int(await self.r.hincrby(K_SNAP.format(room=room), key, by))

    async def snap_get(self, room: str, key: str) -> Optional[str]:
        """快照单字段读(覆盖哨兵水位等;避免为一个字段拉整个 hash)。"""
        return await self.r.hget(K_SNAP.format(room=room), key)

    async def snap_mget(self, room: str, *keys: str) -> list:
        """快照多字段一次读(HMGET)。覆盖哨兵 award 路径本需 covWm+covLastIns
        两字段,合并为单命令:每 award 事件省 1 次 Redis 往返(稳态实测 12.5→12.0
        命令/事件,契约⑪计量)。"""
        return await self.r.hmget(K_SNAP.format(room=room), *keys)

    # ── GameHistory 冷却闸(覆盖哨兵补漏专用;跨进程 SET NX PX) ─────────────────
    async def hist_gate(self, room: str, interval_ms: int) -> bool:
        """同一房两次哨兵触发的 GameHistory 之间的最小间隔闸。抢到闸才允许打;
        没抢到 = 并发事件(同房 mp/aw 落在不同 consumer/进程)或刚打过 —— 调用方
        让水位原地不动,由下一个事件(每局必有 mp/aw)自然重审,绝不丢补漏。
        播种/漏局补齐/出怪兜底三条既有触发不走此闸(语义不变)。"""
        if interval_ms <= 0:
            return True
        return bool(await self.r.set(K_HIST_GATE.format(room=str(room)), "1",
                                     nx=True, px=int(interval_ms)))

    async def get_snapshot(self, room: str) -> Dict[str, str]:
        return await self.r.hgetall(K_SNAP.format(room=room))

    # ── 离场房快照回收(5.4.0 复查)──────────────────────────────────────────────
    # snap:{room} 是全仓唯一一族「按房间拼接、无 TTL、删房与回收路径都不删」的键:每个出现过
    # 的房间留一份(实测 ≈376 字节),自动发现每轮纳入新开播的房间,这个集合只增不减,直到
    # Redis 重启(无持久化)。Redis 配的是 maxmemory 1gb + noeviction —— 写满后全站写入报错。
    # 回收判据只有一条:该房已不在抓取名录 rooms:active(策展 + 发现全集)里。快照里的覆盖
    # 水位 / 播种标记在 Redis 丢失时本就有 PG 兜底,删掉等价于该房的一次 Redis 丢失。
    # 判与删在同一段 Lua 里原子完成:不会误删「刚被加回名录、快照刚写下」的房。
    _LUA_SNAP_GC = """
local n = 0
for i = 1, #KEYS do
  if redis.call('SISMEMBER', ARGV[1], ARGV[i + 1]) == 0 then
    redis.call('UNLINK', KEYS[i])
    n = n + 1
  end
end
return n
"""

    async def gc_orphan_snapshots(self, scan_count: int = 1000, batch: int = 500) -> int:
        """回收不在抓取名录里的房间快照,返回删除的键数。SCAN 增量遍历(不阻塞 Redis)。
        名录为空(回灌未完成 / Redis 刚被清空)时什么都不做 —— 0 不是正常运行态,宁可不删。"""
        if not int(await self.r.scard(K_ROOMS_ACTIVE) or 0):
            return 0
        prefix = K_SNAP.split("{", 1)[0]
        keys: List[str] = []
        deleted = 0

        async def flush() -> int:
            if not keys:
                return 0
            n = await self.r.eval(self._LUA_SNAP_GC, len(keys), *keys, K_ROOMS_ACTIVE,
                                  *[k[len(prefix):] for k in keys])
            keys.clear()
            return int(n or 0)
        async for key in self.r.scan_iter(match=prefix + "*", count=int(scan_count)):
            keys.append(key if isinstance(key, str) else key.decode())
            if len(keys) >= int(batch):
                deleted += await flush()
        return deleted + await flush()

    # ── 命中率补算:跨副本互斥 + 每房冷却 ───────────────────────────────────
    async def replay_try_lock(self, ttl_s: int) -> bool:
        """SET NX EX:抢到即由本副本负责本轮补算巡检。与 retention_try_lock 同款,
        TTL=巡检周期,锁即节拍;不解锁,过期自然让出。"""
        return bool(await self.r.set(K_REPLAY_LOCK, str(now_ms()),
                                     nx=True, ex=max(1, int(ttl_s))))

    async def replay_gate(self, room: str, ttl_s: int) -> bool:
        """每房补算冷却闸(SET NX EX)。抢到才值得为该房去 PG 查一次窗口缺口。

        没抢到 = 该房最近已探过 —— 直接跳过,零 SQL。这一条是补算协程稳态开销
        收敛到近零的关键:窗口填满后每房每 ttl_s 才被探一次,而探到的结果是
        「缺口为空」,立刻返回。"""
        return bool(await self.r.set(K_REPLAY_GATE.format(room=str(room)), "1",
                                     nx=True, ex=max(1, int(ttl_s))))

    async def replay_gate_clear(self, room: str) -> None:
        """清掉某房的冷却闸(转正/唤醒时用:人类刚表达「现在要看这个房」,
        不该让他等满一个冷却周期)。失败无害 —— 下一个周期照样会探。"""
        await self.r.delete(K_REPLAY_GATE.format(room=str(room)))

    async def replay_gate_set(self, room: str, ttl_s: int) -> None:
        """**改写**某房的冷却闸为给定 TTL(普通 SET,不带 NX)。

        唯一用途:补算单房异常后的**失败退避**(worker.REPLAY_FAIL_BACKOFF_S)。
        旧行为是异常也吞掉整段 replay_cooldown_s(默认 1h)—— 一次 PG/Redis 瞬时
        抖动就让用户在推演卡上多等一小时;改成短退避后,瞬断几分钟内自愈,
        而持续性坏房也被退避钳住,不会退化成逐秒重试。"""
        await self.r.set(K_REPLAY_GATE.format(room=str(room)), "1",
                         ex=max(1, int(ttl_s)))

    async def replay_wake_push(self, room: str) -> None:
        """把房号投入补算**唤醒快道**(SADD,幂等)。

        投递方 = 「人类刚表达要看这个房」的两个入口:monitor/add 转正与
        web._touch_room 冷房唤醒。worker._pred_replay 在巡检间隙逐秒 SPOP 排水,
        使推演卡的「近N局」在打开后数秒内补满(排水节拍 ≤1s + 单房补算 ≈2.4s,24h 满窗真机实测 ≈5s),而不是等下一轮 60s 巡检
        (更糟的情形是撞上残留冷却闸再等最长 1h —— 该缺陷的生命周期仿真见
        README §10.1 第七轮:访问间隔 60/68/77 分钟时每次打开恒见 65/55/44)。
        SET 语义天然去重;排水侧 SPOP 原子,多 worker 副本不重不漏。"""
        await self.r.sadd(K_REPLAY_WAKE, str(room))

    async def replay_wake_pop(self, n: int = 1) -> List[str]:
        """从唤醒快道原子取出至多 n 个房号(SPOP count;空集回 [])。"""
        try:
            got = await self.r.spop(K_REPLAY_WAKE, max(1, int(n)))
        except Exception:              # noqa: BLE001 —— 快道是优化,不是本体
            return []
        if got is None:
            return []
        if isinstance(got, (list, tuple, set)):
            return [str(x) for x in got]
        return [str(got)]

    # ── 数据保留:跨进程互斥 + 最近一次统计 ─────────────────────────────────
    async def retention_try_lock(self, ttl_s: int) -> bool:
        """SET NX EX:抢到即负责本周期清理;TTL=巡检周期,锁本身就是全局节拍
        (多 worker 副本下同一周期恰好一次,无需显式解锁/心跳)。"""
        return bool(await self.r.set(K_RET_LOCK, str(now_ms()),
                                     nx=True, ex=max(1, int(ttl_s))))

    async def retention_set_last(self, info: Dict[str, Any]) -> None:
        await self.r.set(K_RET_LAST, json.dumps(info, ensure_ascii=False))

    async def retention_last(self) -> Optional[Dict[str, Any]]:
        raw = await self.r.get(K_RET_LAST)
        if not raw:
            return None
        try:
            return json.loads(raw)
        except (ValueError, TypeError):
            return None

    # ── 核验房复核:跨副本互斥兼节拍 + 最近一轮统计 ────────────────────────────
    async def verify_try_lock(self, ttl_s: int) -> bool:
        """SET NX EX:抢到即负责本轮复核。TTL 取巡检节拍(非复核周期)——
        一轮工作量以台账规模为界、秒级完成,不需要续租心跳。"""
        return bool(await self.r.set(K_VERIFY_LOCK, str(now_ms()),
                                     nx=True, ex=max(1, int(ttl_s))))

    async def verify_probe_gate(self, room: str, ttl_s: int) -> bool:
        """同房核验探测冷却(SET NX EX)。抢到才准打这一发 roomStatus。

        切房路径是**会自动重复**的:前端 refreshLiveRooms 每 30s 用后端名录整体
        替换 S.rooms,随后 mergeMyRooms 会把 localStorage 里那些不在后端名录的房
        重新并回来 —— 于是每 30s 就为同一个房再发一次 profile?switch=1。探测成功
        的房会当场自愈进名录、下一拍即短路;**探测失败的房不会**,它会一直重来,
        而"失败"最常见的原因恰恰是上游本身不好 —— 等于在上游最脆弱的时候按
        30s×标签页数 的节奏持续加压。冷却把同房重探钳到 ttl 一次。

        只用于切房。添加是用户一次性的深思熟虑动作,不该因为别人刚探过同一个房
        就被拒("我明明看着他在播")。"""
        return bool(await self.r.set(K_VERIFY_PROBE.format(room=str(room)),
                                     str(now_ms()), nx=True, ex=max(1, int(ttl_s))))

    async def verify_set_last(self, info: Dict[str, Any]) -> None:
        await self.r.set(K_VERIFY_LAST, json.dumps(info, ensure_ascii=False))

    async def verify_last(self) -> Optional[Dict[str, Any]]:
        raw = await self.r.get(K_VERIFY_LAST)
        if not raw:
            return None
        try:
            return json.loads(raw)
        except (ValueError, TypeError):
            return None

    # ── 直播间自动发现:跨进程互斥 + 发现名录(纯运行态) + 最近一次统计 ─────────
    async def discovery_try_lock(self, ttl_s: int) -> Optional[str]:
        """SET NX EX:抢到即负责本轮遍历;TTL=遍历周期,锁本身即全局节拍
        (多 worker 副本下同一周期恰好一轮)。

        **返回值从 bool 改为「令牌 str | None」**(仍可直接当真值判断,旧调用点
        `if not await discovery_try_lock(...)` 语义不变):令牌用于 `discovery_renew_lock`
        的 compare-and-expire —— 只续租**自己**的锁,绝不误续别人的。

        为什么需要续租(3.4.0,真机实测驱动):遍历耗时随在播规模线性增长
        (实测单页 RTT ~390ms、~49 房/页),1 万房 ≈ 204 页。TTL 恒等于 interval_s
        (默认 60s),一旦遍历超过 TTL,锁在遍历途中过期 → 别的副本抢到并发起
        **第二轮并发遍历** → 副本越多叠得越狠,把繁星打成惊群(正是本设计要防的事)。
        并发翻页已把 204 页压到 ~12s,续租则兜住"网络劣化导致再次超时"的残余风险。
        """
        token = f"{now_ms()}-{random.randint(0, 1 << 30)}"
        ok = await self.r.set(K_DISC_LOCK, token, nx=True, ex=max(1, int(ttl_s)))
        return token if ok else None

    async def discovery_renew_lock(self, token: str, ttl_s: int) -> bool:
        """续租**自己**持有的发现锁(compare-and-expire,原子)。
        令牌不匹配(锁已易主/已过期被他人抢走)返回 False —— 调用方据此得知
        "我已不是持锁者",可提前收手,绝不与新持锁者对打。"""
        if not token:
            return False
        try:
            res = await self.r.eval(_LUA_RENEW, 1, K_DISC_LOCK, token,
                                    max(1, int(ttl_s)))
            return bool(int(res))
        except Exception:
            return False

    async def discovered_map(self) -> Dict[str, int]:
        """自动发现房 room_id -> last_seen_ms(离线回收判定 / 前端过滤用)。"""
        raw = await self.r.hgetall(K_ROOMS_DISCOVERED)
        out: Dict[str, int] = {}
        for k, v in raw.items():
            try:
                out[k] = int(v)
            except (TypeError, ValueError):
                out[k] = 0
        return out

    async def is_discovered(self, room: str) -> bool:
        """该房是否**仅**由自动发现而来(= 前端不展示的后台房)。O(1) HEXISTS。

        用途(3.4.5):**预测管线只为策展房(用户真正在看的房)运行**。
        自动发现的房数以千计,但前端一个都不展示 —— 为它们跑集成预测是纯浪费:
        真机实测每局预测管线 ≈5.5ms(db.sequence 拉 ~1727 行 1.8ms + run_prediction
        纯 CPU 3.7ms),6891 房 = 138 局/s → **独占 0.83 CPU 核 + 给 PG 灌 23.8 万行/s**,
        而这些算力/IO 产出的预测**没有任何人看得到**。
        (用 HEXISTS 而非 SMEMBERS:后者要拉回全部数千个房号,每局每房一次绝不可接受。)
        """
        try:
            return bool(await self.r.hexists(K_ROOMS_DISCOVERED, str(room)))
        except Exception:
            return False        # 判不出来就按"策展房"走(宁可多算,不可少算)

    async def discovered_members(self) -> set:
        """自动发现房集合(前端 live-rooms / crawler-status 据此过滤)。"""
        return set(await self.r.hkeys(K_ROOMS_DISCOVERED))

    async def discovered_seen_bulk(self, rooms: List[str], ts: Optional[int] = None) -> None:
        """把当前在播的自动发现房批量刷 last_seen(单次 pipeline HSET)。
        只刷新时间戳,不改名录 —— 名录登记由 add_rooms_bulk 负责。"""
        rooms = [str(r) for r in rooms if str(r)]
        if not rooms:
            return
        when = int(ts if ts is not None else now_ms())
        mapping = {r: when for r in rooms}
        await self.r.hset(K_ROOMS_DISCOVERED, mapping=mapping)

    async def discovered_restore_bulk(self, pairs: List[tuple]) -> None:
        """PG → Redis 回灌发现房 last_seen(worker 启动时)。逐项 **HSETNX**:
        只填缺失项,绝不覆盖运行态里可能更新的时间戳(多 worker 并发回灌 / 回灌
        与首轮遍历竞态时,新值恒胜)。pairs 每项为 (room_id, last_seen_ms)。"""
        pairs = [(str(r), int(t)) for r, t in pairs if str(r)]
        if not pairs:
            return
        async with self.r.pipeline(transaction=False) as p:
            for rid, ts_v in pairs:
                p.hsetnx(K_ROOMS_DISCOVERED, rid, ts_v)
            await p.execute()

    async def discovered_remove(self, room: str) -> None:
        """把某房移出自动发现集(手动添加转正时用:转正后该房归策展列表,前端可见)。
        不变量(3.5.0):**lastok ⊆ discovered** —— 退出发现集的统一出口同步清
        hist-mode 健康项,防僵尸项把「最老轮询年龄」指标撒谎成无限大(worker
        退出分支的 hist_clear 是即时带,这里是全路径兜底:web add / add-bulk /
        种子迁移 / janitor 挂起转正 / reconcile 泄漏自愈全部经由本函数族)。"""
        pipe = self.r.pipeline(transaction=True)
        pipe.hdel(K_ROOMS_DISCOVERED, str(room))
        pipe.zrem(K_HIST_LASTOK, str(room))
        await pipe.execute()

    async def discovered_remove_bulk(self, rooms: List[str]) -> None:
        rooms = [str(r) for r in rooms if str(r)]
        if rooms:
            pipe = self.r.pipeline(transaction=True)
            pipe.hdel(K_ROOMS_DISCOVERED, *rooms)
            pipe.zrem(K_HIST_LASTOK, *rooms)   # 不变量 lastok ⊆ discovered(见单删注)
            await pipe.execute()

    async def discovered_prune_bulk(self, rooms: List[str],
                                    batch_size: int = 500) -> None:
        """回收离线的自动发现房:从 active 集 / 调度队列 / 任务索引 / 名录 meta /
        发现集彻底移除。发现房为纯运行态,故 meta 直接删除(不留 active:False 残影,
        避免高频churn下 rooms hash 膨胀)。已采集的 rounds/predictions 历史数据由
        调用方(discovery.reconcile_discovered)在本函数之后级联清空(回收即清史);
        本函数只负责 Redis 运行态。

        **分块执行**(默认 500 房/批):7 天回收 grace 存在「到期潮涌」——如节假日
        后大批发现房同时过期,单轮可回收数千房。不分块时单个 MULTI 事务可达
        2+3N ≈ 1.5 万条命令,单线程的 Redis 会整体停顿数十毫秒并放大组包内存;
        分块后每批 ≤ ~1.5k 条,停顿摊平,对 worker 抓取无感。批间无原子性要求:
        每批自身事务内一致,即便中途失败,残余由下一轮遍历幂等补收。"""
        rooms = [str(r) for r in rooms if str(r)]
        if not rooms:
            return
        step = max(1, int(batch_size))
        for i in range(0, len(rooms), step):
            chunk = rooms[i:i + step]
            # 先读各房任务索引(collect 后一次清理),不全量扫 ZSET
            pipe = self.r.pipeline(transaction=False)
            for r in chunk:
                pipe.smembers(K_ROOM_TASKS.format(room=r))
            task_sets = await pipe.execute()
            pipe = self.r.pipeline(transaction=True)
            pipe.srem(K_ROOMS_ACTIVE, *chunk)
            pipe.hdel(K_ROOMS, *chunk)             # 发现房 meta 直接删净
            pipe.hdel(K_ROOMS_DISCOVERED, *chunk)  # 移出发现集
            for r, members in zip(chunk, task_sets):
                if members:
                    pipe.zrem(K_SCHED, *members)
                pipe.delete(K_ROOM_TASKS.format(room=r))
                pipe.delete(K_SNAP.format(room=r))     # 5.4.0:快照随回收删净(此前永久残留)
            pipe.srem(K_SCHED_ROOMS, *chunk)
            pipe.zrem(K_HIST_LASTOK, *chunk)   # hist-mode 健康指标残项一并清净
            # curated-idle(3.7.0)同一「移除即清」纪律:用户直连 URL 看过的
            # 发现房会留下访问戳(读钩子对任意房号生效),回收不清 = 僵尸 zset 项;
            # 冷标结构上不可能落在发现房(to_mark 排除 manual,cold ⊆ 策展),
            # 此处 hdel 纯防御对称,与 lastok 同列。
            pipe.zrem(K_LAST_ACCESS, *chunk)
            pipe.hdel(K_ROOMS_COLD, *chunk)
            await pipe.execute()

    async def discovery_set_last(self, info: Dict[str, Any]) -> None:
        await self.r.set(K_DISC_LAST, json.dumps(info, ensure_ascii=False))

    # ── 主播直播状态(5.0.6):跨进程互斥 + 观测表(纯运行态) + 最近一轮统计 ────
    async def livestatus_try_lock(self, ttl_s: int) -> Optional[str]:
        """SET NX EX:抢到即负责本轮探测(TTL=探测周期,锁即全局节拍)。

        **必须配续租心跳**(与 discovery 同款,勿凭「常态很快」省掉):
        常态一轮 = ⌈max_probe/concurrency⌉ × RTT ≈ 19×0.4s ≈ 8s,远短于 60s 周期;
        但**上游不可达时每发探测都要耗满 request_timeout**,同式变成 19×8s ≈ 152s
        —— 锁会在轮次途中过期,别的副本插队开第二轮,恰在上游已经出问题时叠加请求。
        故持锁期间续租(compare-and-expire,只续自己的),轮次结束即停、让锁自然到期,
        「锁即节拍」的语义不变。"""
        token = f"{now_ms()}-{random.randint(0, 1 << 30)}"
        ok = await self.r.set(K_LIVE_LOCK, token, nx=True, ex=max(1, int(ttl_s)))
        return token if ok else None

    async def livestatus_renew_lock(self, token: str, ttl_s: int) -> bool:
        """续租**自己**持有的探测锁(与 discovery_renew_lock 同一段 Lua)。
        令牌不符(锁已易主/过期被抢)回 False,调用方据此收手,不与新持锁者对打。"""
        if not token:
            return False
        try:
            res = await self.r.eval(_LUA_RENEW, 1, K_LIVE_LOCK, token,
                                    max(1, int(ttl_s)))
            return bool(int(res))
        except Exception:
            return False

    async def livestatus_set_bulk(self, items: List[tuple], ts: Optional[int] = None) -> None:
        """批量写观测:items 每项 (room_id, state),state ∈ {0,1}。
        **调用方只在观测成功时才把该房放进来** —— 失败/未知一律不传,旧值保留。"""
        when = int(ts if ts is not None else now_ms())
        mapping = {str(r): f"{int(st)}|{when}" for r, st in items if str(r)}
        if mapping:
            await self.r.hset(K_ROOMS_LIVE, mapping=mapping)

    async def livestatus_map(self) -> Dict[str, tuple]:
        """全表读:room_id -> (state, ts_ms)。只含策展房,规模 = 前端可见房数。
        解析不了的残值按「未知」丢弃(不让脏数据变成一句谎)。"""
        raw = await self.r.hgetall(K_ROOMS_LIVE)
        out: Dict[str, tuple] = {}
        for k, v in (raw or {}).items():
            try:
                st, _, ts = str(v).partition("|")
                out[k] = (int(st), int(ts))
            except (TypeError, ValueError):
                continue
        return out

    async def livestatus_get_many(self, rooms: List[str]) -> Dict[str, tuple]:
        """按房号批取(web 走这条:O(k) HMGET,不拉全表)。"""
        rooms = [str(r) for r in rooms if str(r)]
        if not rooms:
            return {}
        vals = await self.r.hmget(K_ROOMS_LIVE, rooms)
        out: Dict[str, tuple] = {}
        for rid, v in zip(rooms, vals or []):
            if not v:
                continue
            try:
                st, _, ts = str(v).partition("|")
                out[rid] = (int(st), int(ts))
            except (TypeError, ValueError):
                continue
        return out

    async def livestatus_drop_bulk(self, rooms: List[str]) -> None:
        """清理不再是策展房的观测项(删房/降级为发现房),防表无界增长。"""
        rooms = [str(r) for r in rooms if str(r)]
        if rooms:
            await self.r.hdel(K_ROOMS_LIVE, *rooms)

    async def livestatus_set_last(self, info: Dict[str, Any]) -> None:
        await self.r.set(K_LIVE_LAST, json.dumps(info, ensure_ascii=False))

    async def livestatus_last(self) -> Optional[Dict[str, Any]]:
        raw = await self.r.get(K_LIVE_LAST)
        if not raw:
            return None
        try:
            return json.loads(raw)
        except (ValueError, TypeError):
            return None


    # ── hist-mode 观测(3.5.0):最老轮询年龄 + 越窗/短页计数 ─────────────────────
    async def hist_mark_ok(self, room: str, ts_ms: int) -> None:
        """记录该房最近一次轮询成功时刻(健康指标数据源;每次成功一条 ZADD)。"""
        await self.r.zadd(K_HIST_LASTOK, {str(room): int(ts_ms)})

    async def hist_clear(self, room: str) -> None:
        """模式退出(转正/回滚)时移除健康指标项 —— 僵尸项会把「最老轮询年龄」
        撒谎成无限大;删房/回收路径已在各自 pipeline 内清理。"""
        await self.r.zrem(K_HIST_LASTOK, str(room))

    async def hist_oldest(self) -> Optional[tuple]:
        """(room, last_ok_ms) 最老成功项;空集回 None。读侧零清理(僵尸项由
        模式退出/删房路径负责,读者不写 —— web 保持只读姿态)。"""
        z = await self.r.zrange(K_HIST_LASTOK, 0, 0, withscores=True)
        if not z:
            return None
        m, sc = z[0]
        return str(m), int(sc)

    async def hist_count(self) -> int:
        return int(await self.r.zcard(K_HIST_LASTOK) or 0)

    async def histmode_incr(self, field: str, by: int = 1) -> None:
        """stats:histmode 计数(window_lost / short_page 等);7 天 TTL 自滚动。"""
        await self.r.hincrby(K_HISTMODE_STATS, field, by)
        await self.r.expire(K_HISTMODE_STATS, 7 * 24 * 3600)

    async def histmode_set(self, mapping: Dict[str, Any]) -> None:
        await self.r.hset(K_HISTMODE_STATS, mapping={k: str(v) for k, v in mapping.items()})
        await self.r.expire(K_HISTMODE_STATS, 7 * 24 * 3600)

    async def histmode_stats(self) -> Dict[str, str]:
        try:
            return await self.r.hgetall(K_HISTMODE_STATS) or {}
        except Exception:
            return {}

    # ── curated-idle(3.7.0):冷标记 / 最近访问 / 观众守卫 ───────────────────────
    async def is_cold(self, room: str) -> bool:
        """该房是否为「已降级的空闲策展房」。O(1) HEXISTS。

        失败语义与 is_discovered 同源(判不出来回 False = 按**活跃策展房**走):
        宁可多花一份实时算力,绝不能因一次 Redis 抖动把用户在看的房降级/停预测。"""
        try:
            return bool(await self.r.hexists(K_ROOMS_COLD, str(room)))
        except Exception:
            return False

    async def cold_members(self) -> set:
        """当前全部冷房号(观测/扫描/janitor 自愈用)。失败回空集 = 视同无冷房。"""
        try:
            return set(await self.r.hkeys(K_ROOMS_COLD))
        except Exception:
            return set()

    async def mark_cold_bulk(self, rooms: List[str], ts_ms: int) -> None:
        """批量打冷标(HSETNX:已有 since 绝不回拨 —— 冷龄口径只增不减)。"""
        rooms = [str(r) for r in rooms if str(r)]
        if not rooms:
            return
        pipe = self.r.pipeline(transaction=False)
        for r in rooms:
            pipe.hsetnx(K_ROOMS_COLD, r, int(ts_ms))
        await pipe.execute()

    async def cold_clear(self, room: str) -> Optional[int]:
        """清冷标,返回原 since_ms(本就不冷回 None)。唤醒方用返回值算冷龄
        (falseWake 判定);事务 pipeline 保证「读到的 since 即被删的那份」。"""
        room = str(room)
        pipe = self.r.pipeline(transaction=True)
        pipe.hget(K_ROOMS_COLD, room)
        pipe.hdel(K_ROOMS_COLD, room)
        since, _ = await pipe.execute()
        try:
            return int(since) if since is not None else None
        except (TypeError, ValueError):
            return None

    async def cold_clear_bulk(self, rooms: List[str]) -> None:
        rooms = [str(r) for r in rooms if str(r)]
        if rooms:
            await self.r.hdel(K_ROOMS_COLD, *rooms)

    async def touch_and_check_cold(self, room: str, ts_ms: int) -> Optional[int]:
        """记录一次用户侧访问(ZADD GT 只进不退)并顺带取该房冷标 since_ms
        (非冷回 None)。单次 pipeline 往返 —— 读路径钩子的全部稳态成本。"""
        room = str(room)
        pipe = self.r.pipeline(transaction=False)
        pipe.zadd(K_LAST_ACCESS, {room: int(ts_ms)}, gt=True)
        pipe.hget(K_ROOMS_COLD, room)
        _, since = await pipe.execute()
        try:
            return int(since) if since is not None else None
        except (TypeError, ValueError):
            return None

    async def touch_rooms_nx(self, rooms: List[str], ts_ms: int) -> None:
        """播种「从无访问记录」的房(ZADD NX:绝不覆盖真实访问时戳)。
        Redis 重启/首次启用后年龄未知 —— 播种当下,idle_after 之后才可判闲。"""
        rooms = [str(r) for r in rooms if str(r)]
        if rooms:
            await self.r.zadd(K_LAST_ACCESS, {r: int(ts_ms) for r in rooms},
                              nx=True)

    async def touch_rooms(self, rooms: List[str], ts_ms: int) -> None:
        """批量记录一次真实关注(ZADD GT 只进不退)。add-bulk 转正唤醒用:
        再添加 = 人类意图信号,访问戳置新给足 idle_after 宽限,否则唤醒后
        下一分钟扫描会按陈旧戳立即再降(与单房 touch_and_check_cold 同语义)。"""
        rooms = [str(r) for r in rooms if str(r)]
        if rooms:
            await self.r.zadd(K_LAST_ACCESS, {r: int(ts_ms) for r in rooms},
                              gt=True)

    # ── 单账号「同时只监控 1 个房」租约(安全加固 3.9.0) ──────────────────────
    async def _lease_acq_script(self) -> str:
        if self._lease_acq_sha is None:
            self._lease_acq_sha = await self.r.script_load(_LUA_LEASE_ACQ)
        return self._lease_acq_sha

    async def _lease_rel_script(self) -> str:
        if self._lease_rel_sha is None:
            self._lease_rel_sha = await self.r.script_load(_LUA_LEASE_REL)
        return self._lease_rel_sha

    async def active_room_acquire(self, user_id: int, room: str, tab: str,
                                  now_ms: int, ttl_ms: int,
                                  claim: bool = False) -> Tuple[bool, str]:
        """抢/续「该账号当前活跃房」租约(**last-wins**;决策表见 _LUA_LEASE_ACQ)。
        · claim=True(显式切房):无条件抢占到 room —— 最后一次切换为准,其它窗口随后跟随。
        · claim=False(心跳/明细续租):仍在活跃房则续;已被别处切走则返回 (False, 活跃房)
          让本页**跟随**过去(renew 对异房永不抢占,故不抖动)。
        返回 (是否放行, 放行=当前房 / 未放行=应跟随的活跃房)。放行即已刷租约并续 TTL。
        NOSCRIPT(Redis 重启丢脚本)自动重载重试一次,与 claim/ack 同款。"""
        key = K_ACTIVE_LEASE.format(uid=int(user_id))
        args = (str(room), str(tab or ""), int(now_ms), int(ttl_ms),
                1 if claim else 0)
        sha = await self._lease_acq_script()
        try:
            res = await self.r.evalsha(sha, 1, key, *args)
        except Exception as e:            # noqa: BLE001
            if "NOSCRIPT" in str(e):
                self._lease_acq_sha = None
                sha = await self._lease_acq_script()
                res = await self.r.evalsha(sha, 1, key, *args)
            else:
                raise
        try:
            granted = bool(int(res[0]))
            held = str(res[1]) if len(res) > 1 and res[1] is not None else ""
        except (TypeError, ValueError, IndexError):
            granted, held = True, str(room)   # 返回形态异常:宁可放行(读路径不误伤)
        return granted, held

    async def active_room_release(self, user_id: int, room: str, tab: str,
                                  now_ms: Optional[int] = None,
                                  ttl_ms: int = 40_000) -> None:
        """条件释放:摘掉**本标签页**;若已无任何活页则整把删除(房不符则完全 no-op,
        绝不误删别的标签页刚抢下的租约)。SSE 断流的 finally 调用;best-effort,
        失败无害(TTL 兜底回收)。"""
        key = K_ACTIVE_LEASE.format(uid=int(user_id))
        args = (str(room), str(tab or ""),
                int(now_ms if now_ms is not None else time.time() * 1000), int(ttl_ms))
        sha = await self._lease_rel_script()
        try:
            await self.r.evalsha(sha, 1, key, *args)
        except Exception as e:            # noqa: BLE001
            if "NOSCRIPT" in str(e):
                self._lease_rel_sha = None
                sha = await self._lease_rel_script()
                await self.r.evalsha(sha, 1, key, *args)
            # 其它异常吞掉:释放失败 = 至多多等一个 TTL 自然过期

    # ── 活跃房租约 · 切换广播 / 管理台可见性(3.9.4) ─────────────────────────
    def lease_channel(self, user_id: int) -> str:
        return CH_LEASE_EVT.format(uid=int(user_id))

    async def publish_lease_switch(self, user_id: int, room: str) -> None:
        """claim 成功后广播「本账号活跃房已切换」。best-effort:失败无害——
        订阅端只把它当**触发器**(收到后做权威 renew),丢了就退回 20s 心跳节拍。
        速率天然有界:claim 走会话+CSRF+roster 闸,只有真人显式切房才到这里。"""
        await self.r.publish(self.lease_channel(user_id),
                             json.dumps({"type": "lease-switch", "room": str(room)},
                                        ensure_ascii=False))

    async def active_room_leases(self, limit: int = 500) -> List[Dict[str, Any]]:
        """管理台只读:SCAN 全部 `alr:u*` 租约,回 [{uid, room, ts, tabs}](按 ts 新→旧)。
        与决策路径零耦合(纯观测);单键 HGETALL,t: 项只计数不外泄 tab 值。
        失败回空表(观测缺一拍无害,绝不因此抛错)。"""
        out: List[Dict[str, Any]] = []
        try:
            async for key in self.r.scan_iter(match="alr:u*", count=200):
                k = str(key)
                # 只认精确形态 alr:u<数字>——CH_LEASE_EVT(alr:evt:u*)是频道名不是键,
                # 正常不会出现在 keyspace,此处仍显式排除以防未来键面扩张误入。
                suffix = k[len("alr:u"):]
                if not suffix.isdigit():
                    continue
                h = await self.r.hgetall(k)
                if not h:
                    continue
                out.append({"uid": int(suffix),
                            "room": str(h.get("room", "") or ""),
                            "ts": int(h.get("ts", 0) or 0),
                            "tabs": sum(1 for f in h if str(f).startswith("t:"))})
                if len(out) >= int(limit):
                    break
        except Exception:                 # noqa: BLE001 —— 观测只读,失败即空
            return []
        out.sort(key=lambda x: x["ts"], reverse=True)
        return out

    async def active_room_lease_force_release(self, user_id: int) -> bool:
        """管理台强制释放某账号的活跃房租约(整把 DEL)。用于极端卡死人工解卡:
        释放后该账号各窗口在各自下一拍 renew 时因「空租约」重新授予自己正在看的房,
        先到者持租、其余跟随——与崩溃后 TTL 过期的自愈路径**同一语义**,无新状态。"""
        try:
            return bool(await self.r.delete(K_ACTIVE_LEASE.format(uid=int(user_id))))
        except Exception:                 # noqa: BLE001
            return False

    # ── 行为遥测:疑似脚本来源画像(安全加固 3.9.2) ──────────────────────────
    async def sig_record(self, sid, *, kind=None, now_ms=None, ttl_ms=1_800_000,
                         uid=None, uname=None, ua=None, ip=None, room=None,
                         foot_ttl_ms=None) -> None:
        """把一次可观测事件累进到会话 sid 的滚动画像(单次 pipeline,best-effort)。
        kind ∈ {html, asset, detail, detail_ok, pow_ok, pow_fail, sse}(None=只更上下文)。
        **绝不抛错**:遥测失败不得影响任何请求(外层还有 try/except 兜底)。"""
        sid = str(sid or "").strip()
        if not sid:
            return
        now = int(now_ms if now_ms is not None else time.time() * 1000)
        hkey = K_SIG_HASH.format(sid=sid)
        try:
            pipe = self.r.pipeline(transaction=False)
            if kind:
                pipe.hincrby(hkey, str(kind), 1)
            pipe.hset(hkey, "last", now)
            pipe.hsetnx(hkey, "first", now)
            if uid is not None:
                pipe.hset(hkey, "uid", int(uid))
            if uname:
                pipe.hset(hkey, "uname", str(uname)[:64])
            if ua:
                pipe.hset(hkey, "ua", str(ua)[:200])
            if ip:
                pipe.hset(hkey, "ip", str(ip)[:64])
            pipe.pexpire(hkey, int(ttl_ms))
            pipe.zadd(K_SIG_INDEX, {sid: now})
            # 索引自身无 TTL(它是全局键),故**在写入侧同管道剪除过窗项** ——
            # 否则「没人打开管理台」时 sig:z 会随会话数无界增长(画像本体已随各自
            # TTL 蒸发,只剩一堆指向空 hash 的死 sid)。放同一 pipeline 里 = 不增加
            # 往返;zremrangebyscore 绝大多数调用删 0 项,仅 O(log N),代价可忽略。
            pipe.zremrangebyscore(K_SIG_INDEX, "-inf", now - int(ttl_ms))
            if room:
                rkey = K_SIG_ROOMS.format(sid=sid)
                pipe.pfadd(rkey, str(room))      # HLL:固定 ~12KB 封顶,防按请求率撑大
                pipe.pexpire(rkey, int(ttl_ms))
            # 4.9.0:浏览器足迹 —— 只在 html/asset 这类**浏览器专属**事件上打点。
            # 与画像本体分离、TTL 远长于画像窗:锁屏/切后台导致画像重建时,它仍在,
            # 于是「从不加载页面」这一最强因子不会对真人成立。同管道 = 零额外往返。
            if foot_ttl_ms and kind in ("html", "asset"):
                fkey = K_SIG_FOOT.format(sid=sid)
                pipe.set(fkey, "1")
                pipe.pexpire(fkey, int(foot_ttl_ms))
            await pipe.execute()
        except Exception:
            pass   # 遥测尽力而为:任何失败都静默吞掉,绝不影响主请求

    async def sig_top(self, *, now_ms=None, window_ms=1_800_000, limit=200):
        """读回窗口内的会话画像列表(并顺带按窗剪除过期 sid)。返回**原始计数** dict
        列表(评分留给上层 admin_api,保持存储层与呈现层解耦)。失败返回空表。"""
        now = int(now_ms if now_ms is not None else time.time() * 1000)
        cutoff = now - int(window_ms)
        out = []
        try:
            # 自清理:过期 sid 出索引(画像本体已随各自 TTL 蒸发,这里只清索引残留)
            await self.r.zremrangebyscore(K_SIG_INDEX, "-inf", cutoff)
            sids = await self.r.zrevrange(K_SIG_INDEX, 0, int(limit) - 1)
            for sid in sids:
                h = await self.r.hgetall(K_SIG_HASH.format(sid=sid))
                if not h:
                    continue
                try:
                    rooms = int(await self.r.pfcount(K_SIG_ROOMS.format(sid=sid)))
                except Exception:
                    rooms = 0
                def _i(k):
                    try:
                        return int(h.get(k, 0) or 0)
                    except Exception:
                        return 0

                # 足迹只在**它可能改变判定**时才查:html>0 的行本就已被视作浏览器,
                # 多打一次 RTT 纯属浪费(管理台每 10s 刷一次、最多 500 行,省下的是
                # 每轮数百次往返)。评分侧对 html>0 的行完全不读 foot,故等价。
                foot = False
                if not _i("html"):
                    try:
                        foot = bool(await self.r.exists(K_SIG_FOOT.format(sid=sid)))
                    except Exception:
                        foot = False

                out.append({
                    "sid": sid,
                    "uid": h.get("uid"), "uname": h.get("uname"),
                    "ip": h.get("ip"), "ua": h.get("ua"),
                    "first": _i("first"), "last": _i("last"),
                    "html": _i("html"), "asset": _i("asset"),
                    "detail": _i("detail"), "detail_ok": _i("detail_ok"),
                    "pow_ok": _i("pow_ok"), "pow_fail": _i("pow_fail"),
                    "pow_stale": _i("pow_stale"),
                    "sse": _i("sse"), "rooms": rooms,
                    "foot": foot,            # 4.9.0:本会话曾以浏览器姿态取过页面/静态
                })
        except Exception:
            return []
        return out

    async def last_access_prune(self, keep) -> int:
        """修剪访问戳台账:移除不在 keep(活跃名录)里的残项,返回清除数。

        残项来源:SSE 首帧按未归一短号先行 touch(心跳自愈换真实号前的一拍)、
        以及任何按已删房号打到读钩子的请求。台账规模 = 被访问过的房数(小),
        全量 ZRANGE 由扫描锁限频(≤1 次/分钟/舰队)。keep 取**活跃全集**
        (含发现房 —— 用户直连看过的发现房在被回收前,其访问戳是合法台账,
        回收路径 discovered_prune_bulk 自会同批清除)。"""
        keep = {str(r) for r in (keep or ())}
        try:
            members = await self.r.zrange(K_LAST_ACCESS, 0, -1)
        except Exception:
            return 0
        extra = [m for m in members if str(m) not in keep]
        if extra:
            await self.r.zrem(K_LAST_ACCESS, *extra)
        return len(extra)

    async def last_access_map(self, rooms: List[str]) -> Dict[str, int]:
        """批量取最近访问时戳(ZMSCORE,500/批);无记录的房不在返回里。"""
        out: Dict[str, int] = {}
        rooms = [str(r) for r in rooms if str(r)]
        for i in range(0, len(rooms), 500):
            chunk = rooms[i:i + 500]
            scores = await self.r.zmscore(K_LAST_ACCESS, chunk)
            for r, sc in zip(chunk, scores or []):
                if sc is not None:
                    out[r] = int(sc)
        return out

    async def draw_subscribers(self, rooms: List[str]) -> Dict[str, int]:
        """draws:{room} 频道的当前订阅数 = 打开着该房直播视图的 SSE 连接数
        (全代码库唯一订阅方是 web 的 SSE 转发,信号纯净;单实例 Redis 下
        PUBSUB NUMSUB 即全局真值 —— 各 web 副本的 pubsub 连接挂同一实例)。
        语义:>0 = 确证有人在看,降级**一票否决**。本函数异常向上抛,调用方
        必须按「视同有人在看、本轮放弃降级」处理(保守方向)。"""
        out: Dict[str, int] = {}
        rooms = [str(r) for r in rooms if str(r)]
        prefix = CH_DRAWS.format(room="")
        for i in range(0, len(rooms), 200):
            chunk = rooms[i:i + 200]
            res = await self.r.pubsub_numsub(
                *[CH_DRAWS.format(room=r) for r in chunk])
            for ch, n in res or []:
                if isinstance(ch, bytes):                 # decode 关闭时的兜底
                    ch = ch.decode("utf-8", "replace")
                out[str(ch)[len(prefix):]] = int(n or 0)
        return out

    async def cold_sweep_try_lock(self, ttl_s: int = 60) -> bool:
        """降级扫描互斥兼节拍(SET NX EX;discovery:sweep / retention 同款)。"""
        try:
            return bool(await self.r.set(K_COLD_LOCK, str(now_ms()),
                                         nx=True, ex=max(1, int(ttl_s))))
        except Exception:
            return False

    async def discovery_last(self) -> Optional[Dict[str, Any]]:
        raw = await self.r.get(K_DISC_LAST)
        if not raw:
            return None
        try:
            return json.loads(raw)
        except (ValueError, TypeError):
            return None

    # ── SSE 事件总线 ────────────────────────────────────────────────────────
    async def publish_draw(self, room: str, event: Dict[str, Any]) -> None:
        await self.r.publish(CH_DRAWS.format(room=room),
                             json.dumps(event, ensure_ascii=False))

    def draw_channel(self, room: str) -> str:
        return CH_DRAWS.format(room=room)
