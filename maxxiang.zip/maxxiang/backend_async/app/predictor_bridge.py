"""
predictor_bridge.py — 原封复用旧预测引擎(Predictor / BeastCatalog)的适配层
================================================================================
用户明确要求「不改预测逻辑」。因此本模块**不重写**任何预测算法,而是直接
import 旧引擎 spell_tamer_monitor.py 的 Predictor / BeastCatalog / MonitorConfig,
把它们接到 PostgreSQL 上:

  · 预测器的每房状态(model_weights / explore_state)原本存在旧 SQLite 的 kv 表;
    这里用一个 in-memory 的 KvStoreShim 承接 kv_get/kv_set —— 处理某局前从 PG
    读入该房 kv 播种,处理后把变更刷回 PG。于是「预测器」变成**每次调用无状态**,
    可在水平扩展的多 worker 间安全流转,不依赖某个 worker 常驻内存。
  · predict() 是纯计算(输入编号序列 seq → 预测 dict),放线程池执行,不阻塞事件循环。

对外:
    bridge = PredictorBridge(prediction_cfg_dict, custom_beast_ids)
    result, kv_out = bridge.run_prediction(room, seq, kv_in)      # 生成下一局预测
    kv_out2       = bridge.update_after_settle(room, detail, actual_cid, kv_in)  # 结算更新权重
    oid,name,cid,mult = bridge.resolve_beast(official_id, beast_name)            # 妖兽解析
"""
from __future__ import annotations

import logging
import os
import sys
from typing import Any, Dict, List, Optional, Tuple

# ── 定位并导入旧引擎(默认在仓库同级 jiufa_data/) ──────────────────────────────
_ENGINE_DIR = os.environ.get("STA_ENGINE_DIR") or os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "jiufa_data")
if _ENGINE_DIR not in sys.path:
    sys.path.insert(0, _ENGINE_DIR)

import spell_tamer_monitor as E  # noqa: E402  逐字节复用的预测引擎

_log = logging.getLogger("predictor")


class KvStoreShim:
    """只实现 Predictor 热路径需要的 kv_get/kv_set;用内存 dict 承接,便于批量刷回 PG。
    Predictor 还引用 store.settled_predictions,但仅 rebuild_weights(维护路径)用到,
    热路径(predict + update_weights)不触发,故此处不实现也安全。"""

    def __init__(self, seed: Optional[Dict[str, str]] = None):
        self._d: Dict[str, str] = dict(seed or {})
        self.dirty: Dict[str, str] = {}

    def kv_get(self, room_id: str, k: str) -> Optional[str]:
        return self._d.get(k)

    def kv_set(self, room_id: str, k: str, v: str) -> None:
        self._d[k] = v
        self.dirty[k] = v


def _iso_dummy(*_a, **_k):  # 占位,预测路径不用
    return ""


class PredictorBridge:
    def __init__(self, prediction_cfg: Dict[str, Any], custom_beast_ids: Dict[str, int]):
        # 用引擎自带的 dataclass 构造,忽略未知字段(向后兼容)
        pc_fields = set(E.PredictionConfig.__dataclass_fields__)
        self.pcfg = E.PredictionConfig(**{k: v for k, v in (prediction_cfg or {}).items()
                                          if k in pc_fields})
        self.catalog = E.BeastCatalog(custom_beast_ids or dict(E.DEFAULT_CUSTOM_IDS))
        self._warn_dead_switches()
        self._warn_inert_frontier_keys()
        self._warn_cadence_pairing_mismatch()
        self._warn_infeasible_floors()
        self._warn_mixed_constraint_regimes()
        self._warn_train_window_truncated()
        self._warn_near_random_window()

    #: 反固执 / 冷位份额轮换 / 重现观察期这三组刻度在引擎里**硬门在
    #: explore_style == "showcase"** 上(spell_tamer_monitor.py 的 _rg / showcase 分支,
    #: 以及 _ao 的 `and not _is_fr`)。开着它们却跑别的风格 = 配置在说谎:运维照着
    #: config.yaml 的长篇说明去调 as_*/sc_*/rg_*,一个字也不会生效,却查不到原因
    #: —— 正是本仓库历史上 hot_rotate 的同款病。
    #: 放在**桥构造处**而不是 predict() 里,理由有二(4.9.0 复查踩过的坑):
    #:   ① predict() 的 `if not self._style_warned` 链是 if/elif,插进去会把更严重的
    #:      「缺 frontier_planner.py」ERROR 吃掉;
    #:   ② 桥模式下 Predictor 每局重建,实例级标志挡不住,会**每局刷一条**
    #:      (打爆 tests/test_frontier.py::test_dirty_sequence_warning_is_throttled)。
    #: 桥只在启动与配置热更时重建 ⇒ 每个配置版本恰好一条。仅日志,零行为变化。
    _DEAD_SWITCH_KEYS = ("anti_stubborn", "showcase_rotate", "repeat_guard")

    def _warn_infeasible_floors(self) -> None:
        """露面配额本身就超预算时,启动就喊 —— 否则 LP 会**静默放宽**且无处可查。

        背景(4.9.0 第五轮复查发现的可观测性缺口):frontier 的 plan() 在约束不可行时
        按序自动放宽并把结果记进 diag["relaxed"],但 ①它只出现在 explore.why 里,
        而前端 4.9.6 起已不再渲染该字段;②explore_state(含 frq)没有任何 admin/API
        出口。于是"配置写错 → 引擎悄悄换了套约束在跑"完全不可观测 ——
        正是本仓库反复警告的 hot_rotate 同款病。
        这里只查**与 p̂ 无关**的那部分(逐号地板 / 露面上下限 / Σs=4 的硬预算),
        它在桥构造期就能判定,不必碰 predict() 的热路径。
        (与 p̂ 有关的 fr_cold_min / fr_rare_min / fr_ret_min 放宽仍不可观测 ——
         4.9.0 默认已把三者置 0;若要启用,建议先补 explore_state 的只读出口。)
        """
        if str(getattr(self.pcfg, "explore_style", "") or "") != "frontier":
            return                      # fr_* 只在 frontier 风格域内被读取
        try:
            smin = max(0.0, float(getattr(self.pcfg, "fr_share_min", 0.0) or 0.0))
            smax = min(1.0, max(0.0, float(getattr(self.pcfg, "fr_share_max", 1.0) or 1.0)))
        except (TypeError, ValueError):
            return
        floors: Dict[int, float] = {}
        over: List[str] = []
        for kv in str(getattr(self.pcfg, "fr_share_floors", "") or "").split(","):
            if ":" not in kv:
                continue
            try:
                c, v = kv.split(":", 1)
                c = int(c.strip()); v = float(v)
            except (TypeError, ValueError):
                continue
            if 1 <= c <= 9 and v > 0:
                if v > smax + 1e-9:
                    over.append(f"{c}号({v:.2f}>{smax:.2f})")
                floors[c] = min(smax, v)
        if over:
            _log.warning(
                "fr_share_floors 有地板高于 fr_share_max,已就地钳平:%s。"
                "不钳的话 LP 会变不可行并连 fr_share_min 一起放宽 —— 请核对配置。",
                "、".join(over))
        need = sum(max(smin, floors.get(c, 0.0)) for c in range(1, 10))
        if need > 4.0 + 1e-9:
            _log.warning(
                "fr_share_floors + fr_share_min 的份额之和 = %.3f > 4(每局只有 4 个位子),"
                "LP 将**自动放宽**:先丢逐号地板,再丢 fr_share_min。"
                "实际跑的约束与你配的不是一回事,请调小地板。", need)
        if 9.0 * smax < 4.0 - 1e-9:
            _log.warning(
                "fr_share_max=%.3f 太小:9 个号的上限之和 = %.3f < 4,Σ份额=4 无解,"
                "LP 将自动放宽上限。", smax, 9.0 * smax)

    #: ⚠ 本文件**不得出现任何相对 import**(`from .x import y`):它被
    #: window_audit/replay_harness.py 用 spec_from_file_location 当**顶层模块**
    #: 单独加载,一行相对 import 就会 `ImportError: attempted relative import
    #: with no known parent package`,把整套审计工具全灭(已实测)。
    #: 所以这里**不能**复用 app/constants.py 的 rounds_for_hours,只能自行从
    #: E.ROUND_STEP 推导;两处等值由 tests/test_prior_shrink.py 钉守。
    #: 窗口局数换算必须从 E.ROUND_STEP 推,不许写死常数 —— 与
    #: window_audit/audit-maxxiang.sh 的「配置耦合体检」是同一条判据的两处实现
    #: (那边是离线手动跑,这边是每次启动/热更自动跑),两处分歧会让运维在一处
    #: 看到 ✘、另一处没动静。公式与该脚本逐字一致:int(h*3600*1000/STEP) + 1。
    #: (硬编码 72.0 时二者在 twh=1000h 这类取值上会差 1 局;更要命的是 ROUND_STEP
    #:  一旦随上游改动,写死的常数不会跟着变。)
    @staticmethod
    def _rounds_for_hours(hours: float) -> int:
        step = int(getattr(E, "ROUND_STEP", 50001)) or 50001
        return int(hours * 3600.0 * 1000.0 / step) + 1

    def _warn_train_window_truncated(self) -> None:
        """`max_train` 把 `train_window_hours` **静默截短**时点名。

        两个参数在引擎里是串联的:取数先按时间窗切(`now - train_window_hours`),
        再被 `seq[-max_train:]` 截尾。于是 max_train 比窗口局数小的时候,窗口那一栏
        写多少都不作数 —— 改了等于没改,而**日志里没有任何痕迹**。

        真机实测(2678075 房 12,064 局):train_window_hours=72(≈5184 局)配
        max_train=5000 时四码命中 52.40%,把 max_train 抬到 6000 后 52.43% ——
        差值 0.03pp 属噪声级,即"被截短"这件事本身后果不大;真正的坏处是**运维以为
        自己改了窗口**。所以这里只喊话、不拦截。

        刻意不做成断言/异常:配置改错时崩掉生产,比它要防的这个静默失真更糟。
        """
        try:
            tw = float(getattr(self.pcfg, "train_window_hours", 0.0) or 0.0)
            mt = int(getattr(self.pcfg, "max_train", 0) or 0)
        except (TypeError, ValueError):
            return
        if tw <= 0 or mt <= 0:            # 窗口不限时 / 计数不设上限 ⇒ 无串联可言
            return
        need = self._rounds_for_hours(tw)
        if mt >= need:
            return
        _log.warning(
            "max_train=%d 会把 train_window_hours=%g(约 %d 局)静默截短到 %d 局"
            "(约 %.1f 小时)—— 窗口那一栏此刻**不作数**,改它不会有任何效果。"
            "要让窗口真正生效,请把 max_train 提到 >= %d;若本就想按局数封顶,"
            "把 train_window_hours 设成 0(不限时间)更能表达意图。",
            mt, tw, need, mt,
            mt * (int(getattr(E, "ROUND_STEP", 50001)) or 50001) / 3600000.0, need)

    #: 训练时间窗的近随机硬下限(小时)。**必须与 app/constants.MIN_TRAIN_WINDOW_H 同值**,
    #: 由 tests/test_train_window_guard.py 钉住两处相等。
    #: 这里刻意**复制**而不是 import —— 本文件被 window_audit/replay_harness.py 用
    #: spec_from_file_location 当顶层模块单独加载,任何相对 import 都会 ImportError
    #: 把整套审计工具打死(见 constants.rounds_for_hours 的同款说明与
    #: tests/test_prior_shrink.py::test_predictor_bridge_has_no_relative_imports)。
    MIN_TRAIN_WINDOW_H = 3.0

    def _warn_near_random_window(self) -> None:
        """训练窗落在近随机带时点名 —— 管理台之外的**两条路**只能在这里拦。

        4.9.5 复查发现的覆盖缺口:`config_center.semantic_validate` 里那条 error
        只在**管理台保存**时跑。另外两条路完全绕过它:

          ① `config.yaml` 基线 —— `settings.py` 直接 `dict(raw["prediction"])`,
             不过 `check_range` 也不过语义校验;
          ② `config_revisions.snapshot` —— `apply_snapshot` 只对每个键做 `coerce`,
             **不调用 semantic_validate**(已实测:快照里塞 0.5 启动后生效值就是 0.5,
             errors 为空)。4.9.5 之前 ge=0.1,(0.1, 3) 这一段本来就能落进快照。

        而本方法挂在**桥构造**上,worker 启动与每次配置热更都会重建桥 ⇒ 三条路全覆盖。

        实测依据(自带三房库 12,064 局全量回放,四选九随机基线 = 4/9 = 44.44%):
        0.1h(7 局)=49.03%、0.2h(14 局)=45.69%、1h(72 局)=50.80%,
        而 3~48h 全部落在 53.1~53.8% 的平台上。

        与本文件其它护栏一致:**只喊话,不拦截**。配置改错时崩掉生产,比它要防的
        这个静默失真更糟(见 _warn_train_window_truncated 的同款说明)。
        """
        try:
            tw = float(getattr(self.pcfg, "train_window_hours", 0.0) or 0.0)
        except (TypeError, ValueError):
            return
        if not (0.0 < tw < self.MIN_TRAIN_WINDOW_H):
            return                       # 0 = 计数制(合法入口);>= 下限 = 正常
        _log.warning(
            "train_window_hours=%g h(约 %d 局)落在**近随机带**:真机实测该区间四码"
            "命中退化到 45.7~50.8%%,而四选九的随机基线是 44.44%% —— 预测形同掷骰子"
            "(3~48h 平台为 53.1~53.8%%)。管理台已禁止提交该区间,本条说明当前生效值"
            "来自 config.yaml 基线或历史配置快照(两条路都不过语义校验)。"
            "若本意是「不按时间、只按局数封顶」,请把它设为 0 并用 max_train 控制样本量。",
            tw, self._rounds_for_hours(tw))

    def _warn_mixed_constraint_regimes(self) -> None:
        """逐号地板与旧聚合下限**同时生效**时提示一句 —— 多半是配置中枢的陈旧覆盖。

        4.9.0 第六轮复查发现的部署陷阱:`config_revisions.snapshot` 是**累积继承**的
        (`new_snap = dict(base_snapshot)`),运维只要在管理台改过某个键,它就永久留在
        快照里,并在**每次启动与每次热更**盖掉 config.yaml(`apply_snapshot` 里
        `if key in snapshot:`)。而 `fr_share_floors` 是 4.9.0 新键、不可能在旧快照里
        ⇒ 会从 yaml 生效。于是可能出现"地板生效 + 旧 fr_cold_min/fr_ret_min 也生效"
        的混合态 —— **不崩,但静默变成另一套配置**:实测总命中 53.08% → 50.48%
        (−2.6pp,正好打在前端可见指标上),而 config.yaml 上一个字都看不出来。
        两者并存在数学上合法(LP 可行),故这里只陈述事实、不断言对错。
        """
        if str(getattr(self.pcfg, "explore_style", "") or "") != "frontier":
            return
        if not str(getattr(self.pcfg, "fr_share_floors", "") or "").strip():
            return
        on = []
        for k, label in (("fr_cold_min", "冷门下限"), ("fr_rare_min", "稀有下限"),
                         ("fr_ret_min", "回报下限")):
            try:
                v = float(getattr(self.pcfg, k, 0.0) or 0.0)
            except (TypeError, ValueError):
                continue
            if v > 0:
                on.append(f"{k}={v:g}({label})")
        if on:
            _log.warning(
                "fr_share_floors 与旧聚合下限**同时生效**:%s。4.9.0 的设计是用逐号地板"
                "**取代**这三条(config.yaml 默认已置 0)。若你没有刻意这么配,"
                "多半是配置中枢里还留着上一版的覆盖 —— 覆盖快照是累积继承的,"
                "会盖掉 config.yaml。请到管理台清除这几个键的覆盖,或显式改成新值。"
                "(两者并存合法但会显著改变结果:实测总命中 53.08%%→50.48%%)",
                "、".join(on))

    def _warn_dead_switches(self) -> None:
        st = str(getattr(self.pcfg, "explore_style", "") or "")
        if st != "frontier":
            # ⚠ 只对 frontier 告警。4.9.0 第五轮复查实测(开/关三开关比 160 局四码):
            #   frontier 160/160 全同 = 真死;showcase 0/160;
            #   budget 133/160、norm_cold 155/160、matched 149/160、
            #   ceiling_adaptive 142/160、未知串兜底 142/160 —— **都仍有生效**
            #   (anti_stubborn 的 _ao 那段不按风格设门,只在 frontier 被
            #    `and not _is_fr` 关掉)。早先写成"非 showcase 即失效"是错的。
            return
        on = [k for k in self._DEAD_SWITCH_KEYS if bool(getattr(self.pcfg, k, 0))]
        if not on:
            return
        _log.warning(
            "explore_style=%r 下 %s 及其 as_*/sc_*/rg_* 全组**不生效**"
            "(frontier 自带份额地板+赤字轮转,不叠加这三组;实测开/关 160 局四码逐字节相同)。"
            "若为回滚保留可忽略本条;若指望它们起作用,请把 explore_style 改回 \"showcase\"。",
            st, "/".join(on))

    #: `fr_*` 全组只在 explore_style == "frontier" 域内被读取(引擎里那句
    #: `final = list(_pfr)` 所在的分支;别的风格连 plan() 都不会调用)。
    #: 〔⚠ 4.9.8 更正:默认风格已改为 "frontier" ⇒ 本告警在**出厂配置下不再触发**,
    #:   fr_* 刻度现在全部生效。它只在有人把 explore_style 改回 showcase / budget /
    #:   norm_cold / matched / ceiling_adaptive 时才喊。逻辑本身无需改动 ——
    #:   域判定读的是运行时 explore_style,不是硬编码的默认值。下面 4.9.7 原文照留。〕
    #: 4.9.7 默认风格改回 "showcase" 后,config.yaml 里那一大段 frontier 刻度
    #: (逐号地板 / 露面上下限 / 重规划周期 / 稀有池 / 倍率表 / 冷启动收缩)
    #: **一个字也不会生效** —— 而它们在文件里占了近百行长篇说明,
    #: 不喊一声就是 _warn_dead_switches 的镜像病:运维照着调,查不到原因。
    _INERT_FRONTIER_KEYS = (
        "fr_cold_min", "fr_rare_min", "fr_ret_min", "fr_share_min",
        "fr_share_max", "fr_main_share_min", "fr_replan", "fr_rare_ids",
        "fr_mult", "fr_share_floors", "prior_shrink", "prior_table",
    )

    def _warn_inert_frontier_keys(self) -> None:
        """非 frontier 风格下,配着非空/非零的 fr_* 与 prior_* 时点名。

        与 `_warn_dead_switches` 严格互补(那条只在 frontier 下喊三大总开关,
        这条只在非 frontier 下喊 fr_*/prior_*),两条永不同时触发,
        由 tests/test_share_floors.py::test_dead_switches_under_non_showcase_style_are_loud
        按**键名**分别钉住 —— 早先按「文案含『不生效』」子串匹配会把两条混为一谈。

        判定用「是否偏离惰性值」而不是「是否等于出厂刻度」:出厂 config.yaml 本身
        就带着一整套非零 frontier 刻度(fr_share_floors / fr_share_min 等),
        它们此刻确实都在空转,该喊。只有全部为空/零(= 从未配过 frontier)时才闭嘴,
        免得给根本没碰过这组参数的部署刷无意义告警。

        与本文件其它护栏一致:**只喊话,不拦截**(见 _warn_train_window_truncated)。
        """
        st = str(getattr(self.pcfg, "explore_style", "") or "")
        if st == "frontier":
            return                       # 域内 —— 该由 _warn_dead_switches 那侧管
        on: List[str] = []
        for k in self._INERT_FRONTIER_KEYS:
            v = getattr(self.pcfg, k, None)
            if v is None:
                continue
            if k == "prior_table" and not bool(getattr(self.pcfg, "prior_shrink", False)):
                # prior_table 只在 prior_shrink 开启时才被 _prior_vec 读。收缩关着时
                # 它**换个风格也一样是死的**,死因与本条无关(本条只管「因风格而惰性」)。
                # 出厂 prior_shrink=False 且 prior_table 非空 ⇒ 不做这层过滤会让
                # 每个默认部署都被点名一次,把真正该看的那几个键淹掉。
                continue
            if isinstance(v, bool):
                live = bool(v)
            elif isinstance(v, (int, float)):
                live = float(v) != 0.0
            else:
                live = bool(str(v).strip())
            if live:
                on.append(k)
        if not on:
            return
        _log.warning(
            "explore_style=%r 下 fr_* / prior_* 全组**不生效**(已配置:%s)。"
            "这组刻度只在 explore_style == \"frontier\" 域内被读取 —— 引擎那句 "
            "`final = list(_pfr)` 所在的分支;别的风格连 LP 规划器都不会调用。"
            "若为回滚保留可忽略本条;若指望它们起作用,请把 explore_style 改成 \"frontier\"。",
            st, "/".join(on))

    #: 冷位节拍器的**两个经审计的配对状态**。节拍器的令牌桶滴水速率就是
    #: showcase_kdist 的 cums(rate3=cums[2]、rate2=cums[1]),开启后这三个数由
    #: 「参考目标」变成硬约束 —— 所以两者必须同进同退,引擎注释的纪律要点:
    #: 回滚需**两键同批**;「只关开关」中间态 4.9.7 在当时开态刻度 45,31.5,13.5
    #: 下实测,与改造前基线仅 5,162/12,064 局相同,两键同批改回才是 12,064/12,064 全同。
    #: ON 侧的值由 tests/test_cadence_governor.py::test_config_three_way_consistency
    #: 钉住 == 引擎 dataclass 缺省 == 注册表 default == config.yaml,漂了当场红。
    _CADENCE_KDIST_ON = "35,40,15"          # 4.9.10 起;4.9.7~4.9.9 为 "45,31.5,13.5"
    _CADENCE_KDIST_OFF = "45,30,15"
    #: 4.9.7~4.9.9 的旧开态默认值。它经过大量审计、本身安全,但 4.9.10 改默认后
    #: 最可能以「配置中枢旧快照残留」的形式静默盖掉新默认(本仓库反复警告的
    #: 累积继承陷阱 —— 见 _warn_cadence_pairing_mismatch docstring),届时改默认
    #: 对该部署**不生效**且一个字看不出来。单列出来是为了把这种残留点名喊话,
    #: 与「运维有意自定义的其它值」区分开。
    _CADENCE_KDIST_LEGACY_ON = "45,31.5,13.5"

    @staticmethod
    def _effective_kdist(s: Any) -> Tuple[str, bool]:
        """复刻引擎对 showcase_kdist 的解析与兜底,返回 (实际生效的三档串, 是否走了兜底)。

        引擎那一处是
            `p1s, p2s, p3s = [max(0.0, float(x)) for x in str(...).split(",")[:3]]`
        外包一个 `except Exception:` 回落到 **(45.0, 30.0, 15.0)** —— 恰好就是节拍器
        **关态**的那一侧刻度。

        ⇒ 配对护栏必须比对**生效值**而不是原始串,否则「节拍器开 + 写坏的 kdist」
          会整个绕过它。实测八种写法(None / '' / 'abc' / '45' / '45,30' / '45,,15' /
          列表 / 数字)**全部**落到 45,30,15,而原始串一个也不等于 "45,30,15"。
          这是 4.9.7 复查对本护栏做输入模糊测试时打出来的洞,不是假想。

        刻意**不**复刻 `tot > 95` 那步等比缩放:它只做归一化,两个经审计的配对之和
        都是 90 不触发;自定义值触发缩放后仍是自定义值,不会伪装成任一侧。
        """
        raw = str(s)
        try:
            p1, p2, p3 = [max(0.0, float(x)) for x in raw.split(",")[:3]]
            return f"{p1:g},{p2:g},{p3:g}", False
        except Exception:                    # noqa: BLE001  与引擎同款宽捕获
            return "45,30,15", True

    def _warn_cadence_pairing_mismatch(self) -> None:
        """节拍器开关与 showcase_kdist 落在**未审计的中间态**时点名。

        4.9.7 复查实测发现的部署陷阱(与 _warn_mixed_constraint_regimes 同一根源):
        配置中枢的覆盖快照是**累积继承**的(`new_snap = dict(base_snapshot)`),
        运维只要在管理台改过某个键,它就永久留在快照里,并在每次启动与每次热更
        `apply_snapshot` 里盖掉 config.yaml。而 4.9.7 的这一对里:

          · `showcase_kdist` 是**旧键** —— 完全可能带着 4.9.6 的合法值 "45,30,15"
            躺在旧快照里,升级后照旧生效;
          · `cadence_governor` 是**新键** —— 不可能出现在旧快照里,只能从
            config.yaml 取值(=开)。

        ⇒ 升级那一刻会静默合成「节拍器开 + 关态刻度」这个引擎注释明令禁止、
        仓库从未测过的中间态。已用一份三键快照实地复现:传入
        {"prediction.showcase_kdist": "45,30,15"} 后,解析出的生效值就是
        (cadence_governor=True, showcase_kdist="45,30,15") —— **不崩、无任何日志**。
        这正是本仓库反复警告的「配置在说谎」同款病,只是入口换成了快照继承。

        只在 showcase 风格域内检查:别的风格下 `_cg_on` 恒假,这一对怎么配都不生效,
        喊了反而是噪声(与 _warn_dead_switches / _warn_inert_frontier_keys 同一条纪律)。
        判定只认**两个经审计的配对**,不认「kdist 是不是等于某个漂亮数字」——
        运维有意自定义 kdist 时不会命中本条(自定义值既不等于 ON 侧也不等于 OFF 侧,
        除非他恰好写成另一侧的值,而那正是要拦的情况)。

        与本文件其它护栏一致:**只喊话,不拦截**(见 _warn_train_window_truncated)。
        """
        if str(getattr(self.pcfg, "explore_style", "") or "") != "showcase":
            return
        gov = bool(getattr(self.pcfg, "cadence_governor", 0))
        raw = getattr(self.pcfg, "showcase_kdist", "")
        kd, fellback = self._effective_kdist(raw)
        on_v, _ = self._effective_kdist(self._CADENCE_KDIST_ON)
        off_v, _ = self._effective_kdist(self._CADENCE_KDIST_OFF)
        if fellback:
            # kdist 写坏了 —— 这本身就该喊(引擎静默兜底,配置上一个字看不出来),
            # 且兜底值恰是关态刻度 ⇒ 节拍器开着时同时构成配对失配。
            _log.warning(
                "showcase_kdist=%r **解析失败**,引擎会静默回落到 45,30,15 —— 配置里写的那个值"
                "一个字也不生效。%s"
                "合法格式是三个逗号分隔的数,如 %r(节拍器开)或 %r(节拍器关)。",
                raw,
                ("而回落值恰好是节拍器**关态**刻度,当前节拍器却是**开**的 ⇒ 同时构成"
                 "仓库从未测过的中间态(令牌桶滴水速率就是这三个数的 cums)。"
                 if gov else ""),
                self._CADENCE_KDIST_ON, self._CADENCE_KDIST_OFF)
            return
        if (gov and kd == on_v) or (not gov and kd == off_v):
            return                       # 两个经审计的配对之一,正常
        legacy_v, _ = self._effective_kdist(self._CADENCE_KDIST_LEGACY_ON)
        if gov and kd == legacy_v:
            # 4.9.10 加:旧开态默认值残留。该组合(节拍器开 + 45,31.5,13.5)在
            # 4.9.7~4.9.9 就是部署刻度、审计充分,**不是危险态** —— 喊话只为点名
            # 「新默认 35,40,15 很可能被旧快照静默盖掉了」这件事本身。
            _log.warning(
                "showcase_kdist=%r 是 4.9.7~4.9.9 的**旧默认值** —— 若非有意自定义,"
                "大概率是配置中枢旧快照的残留覆盖盖掉了 4.9.10 新默认 %r(快照累积"
                "继承,升级不清除)。该组合本身经审计安全,但意味着 4.9.10 的默认值"
                "变更对本部署**没有生效**。要用新刻度请到管理台清除 "
                "prediction.showcase_kdist 的覆盖;确要旧刻度请忽略本条。",
                self._CADENCE_KDIST_LEGACY_ON, self._CADENCE_KDIST_ON)
            return
        if gov and kd == off_v:
            _log.warning(
                "cadence_governor=开 却配着**关态**的 showcase_kdist=%r —— 这不是任何"
                "一侧的部署刻度。节拍器的令牌桶滴水速率**就是**这三个数的 cums,"
                "开启后它们由「参考目标」变成硬约束;第三档 %s 高于真机自然值 13.36%%,"
                "会把份额变更夹带进节奏修复。〔4.9.10 审计注:该组合在三房全量回放里"
                "补测过一次,命中面与 4.9.7 开态刻度统计等价(McNemar p=1.0)——所以它"
                "不再是「从未测过」,但它仍不是部署刻度,出现在生产配置里几乎必然是"
                "配对被拆开的症状。〕两个经审计的部署配对只有:开↔%r / 关↔%r。"
                "常见成因:配置中枢的覆盖快照是累积继承的,旧快照里的 showcase_kdist "
                "会盖掉 config.yaml,而 cadence_governor 是新键只能从文件取值 ⇒ 二者"
                "被静默拆开。请到管理台**清除** prediction.showcase_kdist 的覆盖,"
                "或把两键显式配成同一侧。",
                self._CADENCE_KDIST_OFF, off_v.split(",")[-1],
                self._CADENCE_KDIST_ON, self._CADENCE_KDIST_OFF)
        elif (not gov) and kd in (on_v, legacy_v):
            _log.warning(
                "cadence_governor=关 却配着**开态**的 showcase_kdist=%r —— 未经部署审计的"
                "中间态(只翻了开关没翻刻度)。kdist 在关态也被读取(它决定 k 的判定阈值),"
                "「只关开关」中间态 4.9.7 在当时开态刻度 45,31.5,13.5 下实测:与改造前"
                "基线仅 5,162/12,064 局相同,两键同批改回才是全同。"
                "要完整回滚请同批把 showcase_kdist 改成 %r。",
                self._CADENCE_KDIST_ON if kd == on_v else self._CADENCE_KDIST_LEGACY_ON,
                self._CADENCE_KDIST_OFF)

    # ── 妖兽解析:(official_id, name) → (oid, name, custom_id, multiplier) ────────
    def resolve_beast(self, official_id: Any, beast_name: str
                      ) -> Tuple[Optional[int], str, Optional[int], Optional[int]]:
        return self.catalog.resolve(official_id, beast_name)

    def _make_predictor(self, room: str, kv_in: Dict[str, str]) -> Tuple["E.Predictor", KvStoreShim]:
        shim = KvStoreShim(kv_in)
        # store=shim(实现 kv_get/kv_set),persistent=True → 权重/探索态经 shim 读写
        pred = E.Predictor(self.pcfg, shim, room, _log, persistent=True)  # type: ignore[arg-type]
        return pred, shim

    def run_prediction(self, room: str, seq: List[int], kv_in: Dict[str, str]
                       ) -> Tuple[Dict[str, Any], Dict[str, str]]:
        """生成下一局预测。返回 (预测 dict, 需刷回 PG 的 kv 变更)。纯计算,可在线程池跑。"""
        pred, shim = self._make_predictor(room, kv_in)
        result = pred.predict(list(seq))
        return result, dict(shim.dirty)

    def update_after_settle(self, room: str, detail: Dict[str, Any], actual_cid: int,
                            kv_in: Dict[str, str]) -> Dict[str, str]:
        """出怪后按结果做 Hedge 权重更新。返回需刷回 PG 的 kv 变更。"""
        pred, shim = self._make_predictor(room, kv_in)
        pred.update_weights(detail or {}, int(actual_cid))
        return dict(shim.dirty)


# 便捷:引擎里的时间格式化(与旧 DB 的 draw_local/date_local 完全一致)
def ms_to_local(ms: Any, fmt: str = "%Y-%m-%d %H:%M:%S") -> str:
    return E.ms_to_local(ms, fmt)


def ms_to_date(ms: int) -> str:
    return E.ms_to_date(ms)
