"""九法观测台 · 异步后端(抓取 worker + 只读 Web 服务)。"""
__version__ = "3.0.0-async"
