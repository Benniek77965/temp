"""
web.py — FastAPI 只读观测台服务(替代旧 ThreadingHTTPServer / SPAHandler)
================================================================================
定位:**只读**前端服务。抓取由 worker 进程独立完成(见 worker.py),Web 端只从
PostgreSQL(历史/预测)与 Redis 快照(实时计时/爬虫状态)读数,再经 SSE 把
worker 发布到 Redis 频道的「换局 / 新出怪」事件转发给浏览器。

设计要点:
  · 逐字段复刻旧 jiufa_backend.handle_api 的 JSON 契约,前端 SPA **零改动**兼容。
  · 名录管理(/api/monitor/add|remove)是仅有的「写」:把房间写进 Redis(worker
    的 janitor 会自动接管抓取)并 upsert 进 PG;add 时顺手排一个即时 MainPage 任务,
    让「添加直播间」秒级见数据,而非等 janitor 周期。
  · 房号归一 / 昵称 / 头像走 starmeta(异步繁星解析,失败优雅退回原号/占位)。
  · 用 uvicorn 跑本模块(单/多 worker 皆可,纯只读天然水平扩展)。

运行:
    uvicorn app.web:app --host 0.0.0.0 --port 5173 --workers 4
"""
from __future__ import annotations

import anyio     # v2:SSE 清理需要 CancelScope(shield) 逃出取消风暴
import asyncio
import contextlib
import functools
import gzip
import hashlib
import json
import math
import os
import re
import secrets
import time
import aiohttp
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, Query, Request
from fastapi.responses import JSONResponse, FileResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.middleware.gzip import GZipMiddleware   # 4.3.6 响应压缩(SSE 由其内置排除表豁免)
from sse_starlette.sse import EventSourceResponse, ServerSentEvent

from .accounts import accounts_backend as _accounts, fetcher as _acct_fetcher, game_backend as _game

from . import admin_api
from . import admin_auth   # 5.3.0:管理台入口路径(页面 / API 前缀的单一来源)
from . import jfpay, jfvip, userauth
from . import lifecycle   # 5.4.0:数据生命周期(小表定时清扫 + 容量观测)
from . import config_center as cfgc
from .admission import admit_rooms
from .scheduler import effective_hist_interval_ms
from .constants import (DRAW_OFFSET_MS, END_OFFSET_MS, ROUND_STEP, SPELL_OFFSET_MS,
                        build_beast_meta, OFFICIAL_PROBABILITY,
                        fmt_probability)
from .db import DB, _iso   # _iso:本地时区 ISO,与旧 jiufa_backend._iso 逐字节同款
from .ratelimit import TokenBucket
from .redis_bus import RedisBus, extrapolate_server_now
from .scheduler import effective_hist_interval_ms, weighted_fleet_load
from .settings import settings
from .starmeta import StarMeta

VERSION = "4.1.0-async"   # 4.1.0: 链接快速登录 SSO(同库一次性票据,见 SSO-LOGIN.md);3.9.5: 名录速览角标诚实化(卡片 mode/dataOkAt + lastError 落写);3.1.0: 全项目统一北京时间 + 每房历史默认保留 1 天
                          # 3.6.0: 按日回看 —— /history 支持 until 区间 + /history/days 日目录
                          # 3.7.0: curated-idle —— 空闲策展房降级(默认关;shadow 先行)
                          # 3.8.0: 登录系统 —— MySQL 用户库(tb_user)鉴权;
                          #        主播名录/账号库按登录账号隔离(userauth.py + db.user_rooms)
                          # 3.9.0: 安全加固 —— ①每账号「同时只监控 1 个活跃房」租约(多标签页/
                          #        多设备,Redis 原子;3.9.3 起 last-wins;明细端点+SSE 共用);
                          #        ②每账号明细读限流(prediction/summary/coverage/history[非 passive];
                          #        **SSE 不在限流内**,其护栏是租约 + 单连接单房 + tab 上限)。
                          #        二者仅登录启用且带身份时生效,未登录/运维旁路零影响。
                          # 3.9.1: 前端源码化(仓库存未混淆源码,部署经 build-deploy.mjs 混淆)
                          #        + L2 执行证明闸(proof-of-browser,**默认关**):明细端点要求
                          #        X-JF-Proof = _pow_answer(会话挑战),挡住不跑 JS 的纯 API 搬运器。
                          #        前后端变换须逐位一致(tests/test_proof_of_browser.py 跨语言对拍钉住)。
                          # 3.9.2: L2 默认开;新增 L4 行为遥测「疑似脚本来源」(纯遥测/不阻断)——
                          #        按会话累积行为画像,管理台「疑似脚本来源」视图(1.3.0 起收编进 admin.html)呈现,
                          #        供人工研判;自动动作仍只由 L1/L2 确定性事件触发。fail-safe。
                          # 3.9.3: 活跃房租约改 **last-wins**(以最后一次切换的直播间为准)——
                          #        claim(显式切房,POST /api/active-room/claim)无条件抢占;
                          #        renew(明细/SSE 心跳)不符则回 409 room_switched / follow 事件
                          #        + 目标房号,前端**自动跟随**(不再拒绝任何窗口)。
                          #        另:POST /api/active-room/release(关页 sendBeacon 交还租约,
                          #        CSRF 头豁免、幂等 fail-safe);租约 t: 集合加 CAP=32 上限
                          #        (tab 攻击者可控 + SSE 无限流,防按连接速率撑大 hash)。

# 妖兽元数据(与旧观测台九法阵一致;custom_beast_ids 可在 config 覆盖)
BEAST_BY_OFFICIAL, BEAST_BY_CID = build_beast_meta(settings.custom_beast_ids)


# ── 应用状态(生命周期内共享单例) ─────────────────────────────────────────────
class State:
    db: DB
    bus: RedisBus
    sse_bus: RedisBus                 # SSE 专用池(长连与短请求分舱,见 lifespan)
    star: StarMeta
    fx_bucket: TokenBucket
    detail_bucket: TokenBucket        # 每账号明细读限流(按 rl:detail:u{uid} 分桶)
    spells_template: List[dict]
    cfg_state: "cfgc.CenterState"


ST = State()

# v2:SSE 清理任务的强引用集(见 /api/events 的 finally)。清理挪进了独立任务,
# 若无强引用,GC 可能在任务跑完前把它回收 —— done_callback 自摘,无泄漏。
_SSE_CLEANUPS: set = set()

# SSE 清理任务的**有界**等待秒数(见 /api/events 的 finally)。正常清理是
# 毫秒级;这个上界只在 Redis 侧异常时兜底,防止请求帧被钉死。
SSE_CLEANUP_WAIT_S = 5.0


# ── 阻塞上游专用线程闸(舱壁;详见 settings.upstream_thread_limit 的实测记录)──
# 账号/游戏接口是**同步阻塞**实现(urllib / curl_cffi 直打酷狗,timeout 10~12s,
# curl 侧还有 7 档 impersonate 重试 + urllib 兜底)。它们此前走 run_in_threadpool
# —— 即 anyio 的**默认线程池**,而那个池全事件循环只有 40 个令牌,且
# Starlette 的 StaticFiles.lookup_path / FileResponse 的 os.stat + open + read
# **也从同一个 40 里领号**。慢上游一多就坐满,静态资源全在门口排队(实测:
# 40 路阻塞在飞时 /assets/app.js 从 3.2ms 劣化到 7815ms,而不碰线程池的 /admin
# 仍是 2.1ms —— 完美对照组,证明是纯排队而非算力)。
#
# 这与 sse_max_connections 那次「SSE 长连坐满 Redis 池 → 普通请求排队 → 全站
# 500,而 CPU 仅 0.85%」是**同一出戏换了个舞台**,故用同一套解法:分舱。
# 上游调用改领**自己的**令牌,默认池只留给静态资源;再多慢上游也只挤爆它自己。
#
# 为什么模块级建、lifespan 里再调容量:CapacityLimiter 可在无事件循环时构造
# (实测通过,内部是 adapter,首次 acquire 时才绑定后端),这样测试直调端点无需
# 起 lifespan;而配置中枢 cfgc.bootstrap 在 lifespan 里才叠加 PG 运行时覆盖,
# 故最终容量在那里按 settings 定稿(见 lifespan)。
# 跨事件循环复用:adapter 首次 acquire 时缓存 _internal_limiter 并绑定当时的
# 后端,此后**不再重建**。生产是 uvicorn 单循环,不涉及;测试反复 asyncio.run
# 的情形已实测(含"有等待者时强行掐死循环"):令牌均归零、下个循环正常获取,
# 无跨循环污染。**若将来把本闸用在多循环场景,需重跑这条验证。**
_UPSTREAM_THREADS = anyio.CapacityLimiter(settings.upstream_thread_limit)


async def _run_upstream_blocking(fn, *args):
    """把**阻塞的上游调用**丢进线程执行,但只占 _UPSTREAM_THREADS 的配额。

    与 run_in_threadpool 的唯一差别就是 limiter —— 其余语义逐条对齐:
    anyio.to_thread.run_sync 内部同样 copy_context(),故 contextvars 照常复制进
    线程(账号领域 set_request_realm / get_current_raw 依赖这一点,勿改)。
    """
    return await anyio.to_thread.run_sync(functools.partial(fn, *args),
                                          limiter=_UPSTREAM_THREADS)


# ── JS parseFloat 的 Python 等价实现 ────────────────────────────────────────
# 为什么要它:前端 `officialProb` 用 `parseFloat` 判「这个概率能不能用」,后端要按
# 同一判据决定「要不要回填」。两侧口径一旦分叉就是新的静默失真 —— 后端以为没事、
# 前端照旧回落 11.11%。朴素 `float()` **不能**替代:`float("inf")`/`float("１２")`
# (全角)都成功,而 JS parseFloat 两者都给 NaN,正是危险方向。
# 由 tests/test_official_probability.py::test_js_parse_float_parity_live 用 node
# 逐例活体对拍(手挑边界 + 600 条随机串)。
_JS_WS = ("\t\n\x0b\x0c\r \u00a0\u1680\u2000\u2001\u2002\u2003\u2004\u2005"
          "\u2006\u2007\u2008\u2009\u200a\u2028\u2029\u202f\u205f\u3000\ufeff")
_JS_NUM_RE = re.compile(
    r"[+-]?(?:Infinity|(?:[0-9]+\.?[0-9]*|\.[0-9]+)(?:[eE][+-]?[0-9]+)?)")


def _js_parse_float(v: Any) -> float:
    """等价于 JS `parseFloat(String(v))`:跳过前导空白 → 取**最长合法数值前缀**
    → 解不出即 NaN。只认 ASCII 数字,识别 Infinity,不认 inf/NaN/全角。"""
    s = "" if v is None else str(v)
    s = s.lstrip(_JS_WS)
    m = _JS_NUM_RE.match(s)
    if not m:
        return float("nan")
    tok = m.group(0)
    if tok.endswith("Infinity"):
        return float("-inf") if tok[0] == "-" else float("inf")
    try:
        return float(tok)
    except ValueError:                                   # pragma: no cover
        return float("nan")


def _probability_ok(v: Any) -> bool:
    """「这个概率值可用吗」。**解得出 ≠ 说得通**:0% / 负 / >100 / Infinity 都能被
    parseFloat 解出来,却照样能算出满屏红蓝的假结论(0% 还会让前端 stateOf 的
    `100/(prob||10)` 把 0 悄悄换成 10%,同源病)。故判据是「有限 且 0 < p ≤ 100」。"""
    p = _js_parse_float(str(v).replace("%", "") if v is not None else None)
    return math.isfinite(p) and 0.0 < p <= 100.0


def _authoritative_spells() -> List[dict]:
    """妖兽表兜底的九条(概率取 constants.OFFICIAL_PROBABILITY,条条可解析)。"""
    out: List[dict] = []
    for cid in range(1, 10):
        m = BEAST_BY_CID[cid]
        out.append({"beast_id": m["beast_id"], "beast_name": m["beast_name"],
                    "spell_key": m["spell_key"], "spell_name": m["spell_name"],
                    "display_number": cid, "api_spell_id": m["beast_id"],
                    "multiplier": m["multiplier"],
                    "probability": fmt_probability(OFFICIAL_PROBABILITY[m["beast_id"]]),
                    "beast_icon": "", "beast_logo": "", "spell_logo": ""})
    return out


def _load_spells_template() -> List[dict]:
    """九法阵展示配置(妖兽图标/官方概率/倍率/序号 —— 游戏静态元数据)。
    读前端已有的 mock/data/room-321-config.json;缺失/损坏则由妖兽表兜底。

    三道加固(都针对**不报错的**失真,见 tests/test_official_probability.py):
      ① spells 不是数组(写成对象等)→ **加载期**降级,而不是拖到请求期 TypeError;
      ② 个别条目的 probability 缺失/写坏 → 按 beast_id 回填权威值;
      ③ 逐项合法但**合计 ≠ 100%** → 整体重置为权威值。逐项判据放行"每项都在
         (0,100]"的表,而九项加起来未必是 100 —— 实测把号位1 改成 100.00% 后合计
         180%,出怪司历拿它当基线算出 −80pp 的「偏差」并照常 2σ 着色,全程无告警。
         assets/round-engine.js 早已对同一份文件做合计校验,后端作为**司历基线的
         权威来源**没有理由更宽松。"""
    static_dir = settings.static_dir or os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    for base in [static_dir,
                 os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))),
                 os.getcwd()]:
        path = os.path.join(base, "mock", "data", "room-321-config.json")
        try:
            with open(path, "r", encoding="utf-8") as f:
                sp = json.load(f).get("spells")
            if not isinstance(sp, list) or not sp:        # ① 形状不对 → 加载期降级
                if sp:
                    print(f"[web] spells 不是数组({type(sp).__name__}),已降级到妖兽表兜底")
                continue
            fixed = 0
            for item in sp:
                if not isinstance(item, dict):
                    fixed = -1
                    break
                oid = item.get("beast_id")
                try:
                    oid = int(oid)
                except (TypeError, ValueError):
                    oid = None
                if oid not in OFFICIAL_PROBABILITY:
                    fixed = -1
                    break
                if not _probability_ok(item.get("probability")):   # ② 逐条回填
                    item["probability"] = fmt_probability(OFFICIAL_PROBABILITY[oid])
                    fixed += 1
            if fixed < 0:
                print("[web] spells 条目缺 beast_id 或形状异常,已降级到妖兽表兜底")
                continue
            total = sum(_js_parse_float(str(x.get("probability")).replace("%", ""))
                        for x in sp)
            if not (abs(total - 100.0) <= 0.01):          # ③ 合计不对 → 整体重置
                print(f"[web] spells 概率合计 {total:.2f}% ≠ 100%,已整体重置为权威值")
                for item in sp:
                    item["probability"] = fmt_probability(
                        OFFICIAL_PROBABILITY[int(item["beast_id"])])
            elif fixed:
                print(f"[web] spells 有 {fixed} 条概率不可用,已按妖兽表回填")
            return sp
        except Exception as e:
            print(f"[web] 读取 spells 配置失败({e!r}),继续尝试下一候选路径")
            continue
    return _authoritative_spells()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 4.2.0:把 VIP 能力矩阵注入 userauth —— /api/auth/session 的 jf.matrix
    # 与 _vip_guard 的接线共用这一份声明,前端对比表永不与后端实际放行脱节。
    # 4.4.0:注入的是**函数**而非快照 —— jf_basic_online_h 是热更项,
    # 启动时定格一份会在运维改窗后变成谎话(见 vip_matrix 注)。
    userauth.jf_matrix = vip_matrix
    # 配置中枢:在构造连接池/令牌桶**之前**叠加 PG 运行时覆盖 —— 让池尺寸、限流初值
    # 等按覆盖值构造。失败仅告警(短超时),不阻塞 web 启动(原则三)。
    ST.cfg_state = await cfgc.bootstrap(settings, "web")
    # ── 线程池舱壁定稿(必须在 cfgc.bootstrap **之后**:PG 运行时覆盖此刻才落定)──
    # ① 默认线程池:anyio 原生只给 40 个令牌,而 Starlette 的静态资源文件 IO
    #    (StaticFiles.lookup_path / FileResponse 的 os.stat + open + 64KB 分块 read)
    #    全走这里。分舱后它只剩毫秒级本地磁盘操作,但大文件分块会反复申领 ——
    #    混淆后 app.js 约 884KB ⇒ 单个文件就要排约 14 次 read,故留够余量。
    #    可以在这里改的原因:anyio 的 _default_thread_limiter 是 **RunVar**
    #    (按事件循环作用域,不是按 task 的 contextvar),lifespan 里设一次即对
    #    本循环的所有请求生效(实测确证;若换成 contextvar 语义则此处会静默失效)。
    # ② 上游闸:模块级已按 import 期的 settings 建好,此处按覆盖后的终值校准。
    # 两处 max() 是下限护栏(与注册表 ge=8 / ge=1 同口径):env 直配可绕过注册表
    # 校验,配 0 会让整条路径永久阻塞。**日志打印的是钳制后的实际生效值** ——
    # 与注册表「所示即事实」的纪律一致,不让运维看着一个数、跑着另一个数。
    try:
        _pool_n = max(8, int(settings.web_thread_pool))
        _up_n = max(1, int(settings.upstream_thread_limit))
        anyio.to_thread.current_default_thread_limiter().total_tokens = _pool_n
        _UPSTREAM_THREADS.total_tokens = _up_n
        _clamped = (_pool_n != int(settings.web_thread_pool)
                    or _up_n != int(settings.upstream_thread_limit))
        print(f"[web] 线程池舱壁 · 默认池(静态资源) {_pool_n} · "
              f"阻塞上游(账号/游戏) {_up_n}"
              + (f"  ⚠️ 已按下限钳制(配置值 {settings.web_thread_pool}/"
                 f"{settings.upstream_thread_limit})" if _clamped else ""))
    except Exception as e:                       # noqa: BLE001
        # 拿不到限流器绝不该拦启动:退化回 anyio 原生 40 共享池(即修复前行为)。
        print(f"[web] ⚠️ 线程池舱壁设置失败,退回默认共享池: {e!r}")
    ST.db = DB(settings.pg_dsn, settings.pg_pool_min, settings.pg_pool_max)
    # Redis 池:web 侧并发来自只读请求 + 每个 SSE 客户端一条 pubsub 连接;按配置放大
    # (SSE 观众多时应随观众数上调 STA_REDIS_MAX_CONN,与房数无关的另一扩展轴)。
    ST.bus = RedisBus(settings.redis_url, max_connections=settings.redis_max_connections,
                      pool_timeout=settings.web_pool_timeout)
    # ── SSE 专用池(舱壁)────────────────────────────────────────────────────
    # 上面那个池服务**短请求**:拿连接、发命令、立刻归还。SSE 的 pubsub 却是
    # **长生命周期**连接,一握就是整个观看时长。两者共用一个池的后果已被真机
    # 证实:池 256/256 全被 pubsub 占满且恒定不动,普通请求排队 web_pool_timeout
    # 秒后抛 ConnectionError → 全站 500,而 web 进程 CPU 仅 0.85%(纯排队)。
    # 分舱后,观众再多也只挤爆 SSE 自己的池,只读 API 永远有连接可用。
    # 两个池指向同一个 Redis,语义完全一致 —— 只是配额互不侵占。
    ST.sse_bus = RedisBus(settings.redis_url,
                          max_connections=settings.sse_max_connections,
                          pool_timeout=settings.sse_pool_timeout)
    # 繁星归一:装上专用令牌桶(限流下沉到资源边界)+ 跨进程 Redis 缓存(多 web/
    # worker 共享归一结果,数千房只全局解析一次)。连接器并发上限可配。
    ST.fx_bucket = TokenBucket(ST.bus.r, "rl:fanxing",
                               settings.ratelimit.fanxing_rps,
                               settings.ratelimit.fanxing_burst)
    ST.star = StarMeta(conn_limit=settings.starmeta_conn_limit,
                       bucket=ST.fx_bucket, redis=ST.bus.r)
    # 每账号明细读限流(安全加固 3.9.0):一把桶承载任意多账号,按 rl:detail:u{uid}
    # 键在 Redis 内互相隔离。rps<=0 即退化为不限流(默认给正值即启用)。
    # degrade_open=True:本桶的闸门(_detail_gate)文档写明「绝不因 Redis 抖动误伤
    # 真人,仅在明确超配额时回 429」——协调层持续不可用时应放行,与该承诺一致。
    # 这是**唯一**开放降级的桶:fx_bucket(繁星)与 admin 登录桶必须维持
    # 「暂不放行」,否则分别等于削峰失效被上游打爆、暴破节流失效。
    ST.detail_bucket = TokenBucket(ST.bus.r, "rl:detail",
                                   settings.userauth.detail_rate_rps,
                                   settings.userauth.detail_rate_burst,
                                   degrade_open=True)
    ST.spells_template = _load_spells_template()
    await ST.db.connect()
    await ST.db.migrate()
    await ST.star.start()
    # 登录系统(3.8.0):外部 MySQL 用户库鉴权。未配置(STA_USERDB_HOST 留空)时
    # 整体关闭,一切行为与 3.7.0 逐字节一致;配置后所有 /api/*(除自鉴权豁免)
    # 必须携带有效登录会话,名录/账号库按登录账号隔离。用户库瞬断不阻塞 web 启动。
    try:
        await userauth.init(settings.userauth, ST.bus.r)
        # 4.2.1:VIP 体系的启动横幅 —— 原先"开没开、为什么"日志里一个字都没有,
        # 运维只能看到「设了没反应」而无从排查(真机反馈的正是这一类)。
        jfvip.startup_report()
    except Exception as e:
        print(f"[web] 登录系统初始化异常(登录端点将回 503,自动重试): {e!r}")
    # 首登预置房:登录成功回调种植(默认需求固定房 321;userauth.first_login_room
    # 置空即关闭)。挂钩与登录系统开关同生命周期,未启用登录时回调永不触发。
    userauth.on_login_ok = _first_login_seed
    # 账号/扫码登录后端(恢复自旧 accounts_backend;/api/account/* 由本服务提供)。
    # 注入 cookie 会话感知的取数器 + jar 工厂,再以账号库路径初始化。账号后端不可用
    # 不影响监控主功能(登录只是获取票据的一种方式,票据也可继续走 STA_AUTH_TICKET)。
    try:
        _accounts.set_fetchers(_acct_fetcher.fetch_json)
        _accounts.set_jar_factory(_acct_fetcher.new_jar)
        _accounts.init(settings.accounts_path)
        # 账号库可写性自检:目录写不进则账号无法持久化(重建即空)。此前 _save 吞掉
        # PermissionError → 静默失败很误导,故此处显式探测并告警。
        _ap_dir = os.path.dirname(os.path.abspath(settings.accounts_path)) or "."
        _writable = os.access(_ap_dir, os.W_OK)
        print(f"[web] 账号后端已就绪 · 账号库 {settings.accounts_path} · 目录可写={_writable}")
        if not _writable:
            print(f"[web] ⚠️ 账号库目录 {_ap_dir} 不可写 —— 登录的账号无法持久化(重建"
                  f"即空)。docker 部署请确认卷挂载 + entrypoint 已把该目录归属给运行用户。")
    except Exception as e:
        print(f"[web] 账号后端初始化失败(不影响监控): {e!r}")
    # 官方/真实游戏后端(恢复自旧 game_backend;/api/game/* 由本服务提供)。用**当前登录
    # 账号**的票据直连酷狗官方降妖接口(真实盘面/历史/记录/排行/施法)。注入三件:取数器、
    # 当前账号(accounts.get_current_raw)、主播资料(房号→UID)。资料源是异步 StarMeta,
    # 而 game_backend 同步调用,故经事件循环桥接(见 _game_profile)。
    try:
        ST.loop = asyncio.get_running_loop()
        _game.set_fetchers(_acct_fetcher.fetch_json)
        _game.set_account_provider(_accounts.get_current_raw)
        _game.set_profile_provider(_game_profile)
        print("[web] 官方游戏后端已就绪 · /api/game/*")
    except Exception as e:
        print(f"[web] 官方游戏后端初始化失败(不影响监控): {e!r}")
    # PG → Redis 名录回灌(与 worker 同款,幂等;worker 未起时 Web 名录亦不空窗)。
    # 批量回灌:一次 pipeline 往返(替代逐房 add_room/pending_add 的 N 次往返,数千房
    # 时可省数秒)。注:Web 只读,**不排 MainPage 抓取任务**(抓取是 worker 的职责),
    # 此处仅补名录供 /api/crawler/status、alias 展示等使用。
    try:
        _restored = await ST.db.restore_rooms()
        _act = _restored["active"]
        if _act:
            await ST.bus.add_rooms_bulk(
                [(_r["room_id"], _r.get("alias") or _r["room_id"]) for _r in _act])
        if _restored["pending"]:
            await ST.bus.pending_add_bulk([_r["room_id"] for _r in _restored["pending"]])
    except Exception:
        pass
    # 配置内声明的房间自动进名录(幂等),统一走批量准入控制器:
    # 有界并发归一(过繁星令牌桶)→ 批量落库/登记 → 错峰起抓。归一失败进挂起集,
    # 由 worker janitor 收敛。config 里放成百上千房也不再拖慢冷启动 / 惊群。
    if settings.rooms:
        try:
            _seed_res = await admit_rooms(list(settings.rooms), bus=ST.bus, db=ST.db,
                                          star=ST.star, cfg=settings.admission,
                                          do_canon=True, aliases=settings.room_aliases)
            # 配置房属策展列表:若此前被自动发现,移出发现集(前端可见)+ 清 PG 时钟残行
            _seed_added = _seed_res.get("added_rooms", [])
            await ST.bus.discovered_remove_bulk(_seed_added)
            await ST.db.discovered_delete_bulk(_seed_added)
            if settings.histmode.enabled and _seed_added:
                # 封尾同 add-bulk(种子房也可能是上一世的发现房)
                from .redis_bus import task_hist
                await ST.bus.schedule_spread(
                    [task_hist(r) for r in _seed_added],
                    int(time.time() * 1000), max(2000, 80 * len(_seed_added)))
        except Exception:
            pass
    # ── 管理台配置中枢:注入共享状态 + web 侧钩子表 + 启动订阅/心跳协程 ──────────
    # web 侧可热更的仅限流(fanxing 桶)与日志级别;预测参数 web 按请求读 dict、
    # 无需钩子(dict 原地即生效)。其余参数由 worker 消费。
    hooks_web = {
        "rl_fanxing": lambda: ST.fx_bucket.update(settings.ratelimit.fanxing_rps,
                                                  settings.ratelimit.fanxing_burst),
        "loglevel": lambda: __import__("logging").getLogger().setLevel(
            getattr(__import__("logging"), str(settings.log_level).upper(),
                    __import__("logging").INFO)),
    }
    admin_api.init(ST, hooks_web)
    with contextlib.suppress(Exception):
        admin_api.startup_report()        # 5.3.0:入口 / 账号 / 人机验证的实际生效口径
    # 5.4.0 数据生命周期:PG 小表(管理审计 / 离场房状态 / 名录墓碑)的定时清扫。
    # 用户库那一路随 userauth.init 起(未启用登录即不存在);rounds/predictions 仍归 worker。
    with contextlib.suppress(Exception):
        lifecycle.start(ST.db, ST.bus)
    ST._cfg_task = asyncio.create_task(cfgc.run_agent(
        settings=settings, role="web", bus=ST.bus, db=ST.db,
        hooks=hooks_web, state=ST.cfg_state, running=lambda: True))
    yield
    with contextlib.suppress(Exception):
        await lifecycle.stop()
    with contextlib.suppress(Exception):
        await userauth.close()
    with contextlib.suppress(Exception):
        ST._cfg_task.cancel()
    with contextlib.suppress(Exception):
        if _av_session and not _av_session.closed:
            await _av_session.close()
    with contextlib.suppress(Exception):
        # 4.2.0(复审补):支付网关的 aiohttp 会话同样要收尾,否则关停时
        # aiohttp 会打 "Unclosed client session" 并泄漏一个 connector。
        await jfpay.close()
    await ST.star.close()
    with contextlib.suppress(Exception):
        await ST.sse_bus.close()
    await ST.bus.close()
    await ST.db.close()


# 4.2.4 收敛暴露面:FastAPI 默认把 /docs、/redoc、/openapi.json 挂成**匿名可读**。
# 实测(无任何 cookie):/openapi.json 200,吐出 **82 条路径**的完整参数 schema,
# 其中含 /api/admin/config/apply、/api/admin/config/override/{key} 等全部管理面 ——
# 鉴权没被绕过,但等于把攻击面地图连同参数名一并公开。部署链路(compose/入口脚本)
# 里也没有任何反代拦它,全仓库亦无人把它当运维工具用(grep 零引用)。
# 故默认关闭;需要时用 STA_API_DOCS=1 显式打开(构造期读取,非配置中枢参数,
# 不进 REGISTRY,故不影响 test_config_registry 的双向一致性断言)。
_API_DOCS = os.environ.get("STA_API_DOCS", "").strip().lower() in ("1", "true", "yes", "on")
app = FastAPI(title="九法观测台 · 只读服务", version=VERSION, lifespan=lifespan,
              docs_url=("/docs" if _API_DOCS else None),
              redoc_url=("/redoc" if _API_DOCS else None),
              openapi_url=("/openapi.json" if _API_DOCS else None))

# 管理台 API(鉴权在路由内,未设密码时一切 503)。5.3.0:入口路径可配(settings.admin.path,
# 默认 admin-xdd)—— 页面 = /<path>,API = /api/<path>/*,二者同源于 admin_auth.entry()。
# 路由在进程启动时挂载,故改入口需重启 web(注册表里标的就是「需重启」)。
_ADMIN_PAGE = admin_auth.page_path()
_ADMIN_API = admin_auth.api_prefix()
# include_in_schema=False:运维打开 STA_API_DOCS 时,/openapi.json 不得把入口路径列出来
# (否则入口改名白做);外部发卡接口是写进文档的公开契约,下面那条照常进文档。
app.include_router(admin_api.router, prefix=_ADMIN_API, include_in_schema=False)
if _ADMIN_API != admin_auth.LEGACY_API_PREFIX:
    # 外部发卡接口是给对接方的机器契约(4.2.9 起文档即写 POST /api/admin/jfvip/cards/issue),
    # 地址恒定:入口搬走后在原地址再挂一次,处理函数、闸序、返回体与搬家前逐字节相同。
    app.add_api_route(admin_auth.CARD_ISSUE_PATH, admin_api.jfvip_cards_issue, methods=["POST"])

# 登录系统 API(/api/auth/login|logout|session;未启用时 login 回 503、session 回 enabled:false)。
app.include_router(userauth.router)


# ── 登录守卫中间件(3.8.0)──────────────────────────────────────────────────────
# 未启用登录系统 → guard 恒放行(零开销、旧行为)。启用后:
#   · /api/*(除 /api/auth/*、/api/version、管理面 /api/<入口路径>/* 自鉴权)与 /fx/avatar
#     必须携带有效登录会话(HttpOnly Cookie),否则 401/403(封停/到期语义化);
#   · 通过校验的请求把身份注入 request.state.user,各端点据此做**按账号隔离**;
#   · 除 SSE 与 <img> 头像外的 /api 请求同时要求 X-JF-Auth 自定义头(CSRF 防线);
#   · /api/monitor/* 允许管理台会话 / X-Monitor-Token 走运维旁路(全局旧语义)。
@app.middleware("http")
async def _user_auth_middleware(request: Request, call_next):
    deny = await userauth.guard(request)
    if deny is not None:
        return deny
    return await call_next(request)


# ── 行为遥测:疑似脚本来源画像(安全加固 3.9.2,**纯遥测 / 绝不阻断**) ──────────
#   本中间件在 _user_auth_middleware **之外**(注册在后 → 最外层):其「后半段」在
#   guard 已把 request.state.user 落好之后执行,故能把事件归属到具体账号。它只把
#   四类可观测事件(html 文档命中 / 静态资源 / 明细端点 / SSE 建流)累进到会话画像,
#   评分与呈现全在管理台侧;**任何异常都静默吞掉,绝不影响主请求**。
# 明细端点信号正则:与后端**实际强制证明的 4 个端点**精确对齐 ——
#   prediction / coverage / history 带后缀,summary 是**裸** /api/rooms/{room}。
#   刻意排除 /history/days 与 /config(后端未加证明闸、前端也不附证明),以及
#   房间名录 /api/rooms(列表)。$ 锚定确保 /history/days 不被误算为一次明细拉取。
_SIG_DETAIL_RE = re.compile(
    r"^/api/rooms/[^/]+(?:$|/(?:prediction|coverage|history)$)")
_SIG_ROOM_RE = re.compile(r"^/api/rooms/([^/?]+)")


def _sig_enabled() -> bool:
    return bool(userauth.enabled()
                and getattr(settings.userauth, "signal_scoring", False))


def _sig_client_ip(request: Request) -> str:
    """来源 IP(仅作画像上下文展示,不参与鉴权)。5.2.0:与登录/管理台同一「可信代理」
    判定(app/clientip.py)—— 直连部署下伪造的 XFF 不再污染「疑似脚本来源」画像。"""
    try:
        return userauth.client_ip(request)[:64]
    except Exception:
        return ""


async def _sig_pow(request: Request, *, ok: bool, stale: bool = False) -> None:
    """记录一次执行证明结果。best-effort。

    4.9.0 起把「拒绝」拆成**两类**,因为它们是完全不同的事:
      · pow_fail  —— 客户端**根本没带应答**,或当前挑战在、应答却算错了。
                     这才是「不跑 JS 的搬运器 / 逆向失败」的真信号。
      · pow_stale —— 客户端**明明带了应答**,只是服务端这把挑战已经不在了
                     (过期 / 被另一标签页轮转掉)。这是**服务端**的过期,
                     不是客户端的失败 —— 它只说明「对方一直在算应答」,
                     恰恰是浏览器的证据。计入疑度是纯误伤,故单列不计分。
    拆分前:挑战 TTL 180s + 前端铸一次永不主动续铸 ⇒ 真人**每 3 分钟稳吃一次
    pow_fail**,30 分钟窗口刚好凑够 10 次,精确点亮「执行证明失败 N 次」(+20)。"""
    if not _sig_enabled():
        return
    try:
        sid = _pow_sid(request)
        if not sid:
            return
        u = _req_user(request)
        kind = "pow_ok" if ok else ("pow_stale" if stale else "pow_fail")
        ttl_ms = int(float(getattr(settings.userauth, "signal_window_s", 1800.0)) * 1000)
        await ST.bus.sig_record(
            sid, kind=kind, ttl_ms=ttl_ms,
            uid=(getattr(u, "user_id", None) if u else None),
            uname=(getattr(u, "user_name", None) if u else None))
    except Exception:
        pass


async def _sig_observe(request: Request, response) -> None:
    """把一次请求归类为 html/asset/detail/sse 之一并累进画像(其余请求不触 Redis)。"""
    if not _sig_enabled():
        return
    try:
        sid = _pow_sid(request)
        if not sid:
            return                     # 无会话 Cookie → 无法归属账号,跳过
        path = request.url.path
        status = int(getattr(response, "status_code", 0) or 0)
        ctype = ""
        try:
            ctype = response.headers.get("content-type", "") or ""
        except Exception:
            ctype = ""
        kind = None
        room = None
        if path.startswith("/assets/"):
            kind = "asset"            # 静态资源:命中缓存回 304 也算(仍是浏览器行为)
        elif _SIG_DETAIL_RE.match(path):
            kind = "detail"            # 记「尝试」——被 401/429 也算(挡住的搬运器正是信号)
            m = _SIG_ROOM_RE.match(path)
            if m:
                room = m.group(1)[:32]
        elif path == "/api/events":
            kind = "sse"
        elif path.startswith("/api/"):
            return                     # 其它 API(session/account/monitor/pow…)非文档,忽略
        elif status in (200, 304) and (
                ctype.startswith("text/html") or path == "/" or path.endswith(".html")):
            # SPA 文档命中:真浏览器开机必取,纯 API 搬运器绝无。
            # **关键**:HTML 是 no-cache,回访会走条件请求得 304 —— 必须把 304 也计入,
            # 否则「热缓存回访的真人」会 html=0 被误判为搬运器(最强因子 +45)。
            kind = "html"
        else:
            return
        u = _req_user(request)
        ttl_ms = int(float(getattr(settings.userauth, "signal_window_s", 1800.0)) * 1000)
        # 4.9.0:html/asset 是**浏览器专属**事件 —— 顺手在同一 pipeline 里打一枚
        # 长效足迹键。它与画像本体的 TTL 解耦,故「锁屏 35 分钟后画像重建」不会
        # 再把真人变成「从不加载页面」(实测该路径 9 次明细即得 45 分)。
        foot_ms = int(max(0.0, float(getattr(settings.userauth,
                                             "signal_footprint_ttl_s", 86400.0))) * 1000)
        await ST.bus.sig_record(
            sid, kind=kind, ttl_ms=ttl_ms, foot_ttl_ms=(foot_ms or None),
            uid=(getattr(u, "user_id", None) if u else None),
            uname=(getattr(u, "user_name", None) if u else None),
            ua=request.headers.get("user-agent", ""),
            ip=_sig_client_ip(request), room=room)
        if kind == "detail" and status == 200:
            await ST.bus.sig_record(sid, kind="detail_ok", ttl_ms=ttl_ms)
    except Exception:
        pass


@app.middleware("http")
async def _signal_middleware(request: Request, call_next):
    response = await call_next(request)     # 内层(含 guard)先跑完,state.user 就绪
    try:
        await _sig_observe(request, response)
    except Exception:
        pass                                # 遥测绝不影响响应
    return response


# ── 4.3.6 响应压缩(实测驱动)────────────────────────────────────────────────
# 背景(实地量测,非推断):混淆构建后的首屏三件套
#   index.html 23,652 + assets/app.css 114,556 + assets/app.js 883,931 = 1,022,139 B
# 此前**全程不压缩** —— compose 把 web 直接暴露在 5173(无 nginx/caddy 反代),
# 且本文件此前未注册任何压缩中间件。实测 400kbps 弱网首屏 ≈20.4s。
# 注:javascript-obfuscator 会把 app.js 从 428KB 放大到 884KB(+106%),
#     admin.js 从 145KB 放大到 544KB(+276%),压缩因此格外必要。
#
# 为什么安全(逐条实机验证,勿凭印象改动):
#   ① SSE 不会被压:starlette 0.49.3 的 gzip.py 顶部
#      `DEFAULT_EXCLUDED_CONTENT_TYPES = ("text/event-stream",)`,
#      GZipResponder 命中即整条透传。实测 /api/events 响应**无** content-encoding,
#      且每个事件从服务端产出到客户端到达 ≈2ms、500ms 节拍逐拍保真,零缓冲。
#      requirements.txt 已钉死 starlette==0.49.3,该行为确定;
#      **若将来解钉 starlette,必须重跑这条验证**(旧版无此排除表 = SSE 会被缓冲致死)。
#   ② 注册在两个 @app.middleware("http") 之后 ⇒ 最外层,看到的是最终响应体。
#   ③ 304 不受影响:body 为空 < minimum_size,走原样透传分支,不加 content-encoding。
#   ④ pathsend 分支被显式跳过(uvicorn 不上报该扩展,此处仅为完备)。
#
# compresslevel=5 而非默认 9 —— 实测(真实 dist 产物,三件套合计):
#   level 1: 481.0KB / 17.5ms   level 5: 430.5KB / 36.6ms
#   level 6: 425.9KB / 52.0ms   level 9: 422.7KB / 95.8ms
# 9 比 5 只多省 1.8%,CPU 却是 2.6 倍;而 README 明确「web 镜像 CMD 钉死单
# uvicorn worker」(账号后端为进程内内存态),单 worker 下每请求多 60ms 会直接
# 串行化并发冷启。5 拿到 57% 的体积削减(1,022,139 → 430.5KB),是本机形态下的最优点。
#
# ── 为什么不能裸用 GZipMiddleware(复查实测纠正的自身缺陷)────────────────
# starlette 的排除表**只有** text/event-stream,图片/字体照压不误,而它们本就是
# 压缩格式 —— 实测:
#     jiufa/statics/index-bg.png  293,736 → 293,844  (**变大** 108B)
#     assets/fonts/*.woff2         36,860 →  36,893  (**变大** 33B)
#     cdn/*.png                   174,222 → 173,649  (省 0.3%,无意义)
# 而 /jiufa 是 269 个文件 / 26MB —— 游戏 iframe 每开一次就要在单 worker 上把
# 这些全部白压一遍。故按**扩展名**先行分流:决策发生在响应之前、确定且与
# starlette 内部实现无关(不依赖其排除表结构,换版本不会失效)。
# 无扩展名的路径(全部 /api/*)一律走 gzip 分支 —— SSE 由 starlette 自带的
# text/event-stream 排除兜住,两层防线都在。
_GZIP_SKIP_EXT = (
    ".png", ".jpg", ".jpeg", ".webp", ".gif", ".ico", ".bmp", ".avif",
    ".woff", ".woff2", ".ttf", ".otf", ".eot",
    ".mp3", ".mp4", ".webm", ".ogg", ".wav",
    ".zip", ".gz", ".br", ".7z", ".rar", ".pdf",
)
# 无扩展名但回二进制的路由:扩展名判据对它们失效,必须按前缀点名。
#   /fx/avatar —— 头像反代,`Response(content=body, media_type=ctype)`(web.py 内
#   仅此一处非文本 media_type;已 grep 全 app/ 确认无第二处)。名录最多 50 房,
#   每房一张头像 ⇒ 一次开页最多 50 次无谓压缩。
_GZIP_SKIP_PREFIX = ("/fx/avatar",)


# ── 4.4.3 静态产物压缩结果缓存(实测驱动;把上面那 36.6ms 从「每请求」变成「每部署」)──
# 复查实测(对照实验,同样 8 路并发下载真实 app.js,只切 Accept-Encoding):
#     identity(传 556KB 原文)  → 事件循环探针 p50   7.67ms / p95 11.40ms
#     gzip   (传 223KB 压缩)   → 事件循环探针 p50  42.47ms / p95 54.48ms
# 探针打的是 /admin(503,纯内存、零 IO、零线程池)—— 它的延迟就是**事件循环
# 本身的响应性**。差值 ~35ms 确凿归因于压缩 CPU,与上面 level 表里「三件套
# 36.6ms」互为印证:**单 worker 下这段 CPU 会串行化掉所有并发请求**,那正是
# 上面选 5 而不是 9 时已经担心过的事。
#
# 但降等级是拿体积换 CPU(level 1 省一半 CPU、体积涨 10.7%),而弱网首屏预算
# 恰恰是上面选 5 的理由 —— 那是个真实的两难。**本缓存直接取消这个两难**:
# 静态产物在一次部署内是不变的,压一次存起来复用即可 —— 压缩率不变、线路
# 字节不变、level 5 的取舍原样保留,只是 CPU 从「每请求付」变成「每部署付」。
#
# 作用域刻意收窄到**已挂载的静态目录**(/assets、/jiufa、/cdn、/icons、/mock):
#   · 那里才有大体积文本(app.js 884KB、app.css、jiufa 的 js/css),CPU 几乎全在这;
#   · 它们的响应形态**完全确定**(FileResponse:200 带 ETag + Content-Length,
#     或 304 空体),不存在流式/不定长响应 —— 缓冲整体是安全的;
#   · /api/* 与 SPA 兜底**一律不进本层**,继续走 starlette 原装 GZipMiddleware,
#     SSE(text/event-stream,不定长、无 ETag、无 Content-Length)因此在结构上
#     根本不可能落到这里 —— 不是靠判断躲开的,是路由上就到不了。
#
# 键 = (path, ETag)。ETag 由 FileResponse 从 stat(mtime+size)算出,故:
#   · 重新部署 / 换卷 / 改文件 ⇒ ETag 变 ⇒ 旧条目自动失效(不靠重启,也不靠 TTL);
#   · 同一文件的 304 分支不进缓存(空体),不占位。
_GZIP_CACHE_MAX_BYTES = 32 * 1024 * 1024      # 压缩后总量上限;实际需求约 1~2MB,足够宽松
_GZIP_CACHE_MIN = 1024                        # 与 minimum_size 同口径:小响应压了也不划算
_GZIP_CACHE_MAX_ITEM = 8 * 1024 * 1024        # 单条上限(未压缩体积);超过则不缓存、直出
_STATIC_MOUNT_PREFIXES: tuple = ()            # 由 _mount_static 填;本层只认这些前缀


class _GzipBlobCache:
    """path → (etag, gzip 后的字节)。单 worker、事件循环内单线程访问,无需加锁。

    淘汰策略是**整体清空**而不是 LRU:静态产物集合是固定的、总量远小于上限,
    正常永远撞不到;真撞到只可能是配置异常(比如把巨大的目录挂了进来),
    这时清空重来比维护一套 LRU 更简单、也更不容易出错 —— 不为不会发生的
    场景背一套淘汰逻辑。
    """

    __slots__ = ("_d", "_bytes", "_max", "hits", "misses")

    def __init__(self, max_bytes: int):
        self._d: Dict[str, tuple] = {}
        self._bytes = 0
        self._max = int(max_bytes)
        self.hits = 0
        self.misses = 0

    def get(self, path: str, etag: bytes):
        ent = self._d.get(path)
        if ent is not None and ent[0] == etag:
            self.hits += 1
            return ent[1]
        self.misses += 1
        return None

    def put(self, path: str, etag: bytes, blob: bytes) -> None:
        old = self._d.pop(path, None)
        if old is not None:
            self._bytes -= len(old[1])
        if self._bytes + len(blob) > self._max:
            self._d.clear()
            self._bytes = 0
        self._d[path] = (etag, blob)
        self._bytes += len(blob)

    def stats(self) -> dict:
        return {"items": len(self._d), "bytes": self._bytes,
                "hits": self.hits, "misses": self.misses}


_GZIP_CACHE = _GzipBlobCache(_GZIP_CACHE_MAX_BYTES)


class _CachedStaticGzip:
    """静态挂载目录专用:整体缓冲 → 命中缓存直发 / 未命中压一次并存。

    为什么这里可以整体缓冲(而 /api/* 那边绝不可以):本层只接已挂载静态目录的
    请求,响应必然出自 StaticFiles 的 FileResponse —— 定长、带 ETag、一次成型。
    单条未压缩体积上限 _GZIP_CACHE_MAX_ITEM 兜住极端(超限即原样直出,不缓冲)。
    不合格的响应(304 空体、404 等)**原样透传** —— 它们本就小于 minimum_size,
    starlette 的 GZipResponder 对它们同样是不压的透传分支,行为一致。
    """

    def __init__(self, app):
        self._app = app

    async def __call__(self, scope, receive, send):
        state = {"mode": None, "start": None, "buf": [], "etag": None,
                 "path": scope.get("path", "")}

        async def _send(message):
            t = message["type"]
            if t == "http.response.start":
                state["start"] = message
                hdrs = message.get("headers") or []
                etag = clen = None
                for k, v in hdrs:
                    lk = k.lower()
                    if lk == b"etag":
                        etag = v
                    elif lk == b"content-length":
                        clen = v
                    elif lk == b"content-encoding":
                        clen = None      # 已被下游编码过 ⇒ 一律不碰
                        break
                ok = (message.get("status") == 200 and etag is not None
                      and clen is not None and clen.isdigit()
                      and _GZIP_CACHE_MIN <= int(clen) <= _GZIP_CACHE_MAX_ITEM)
                if ok:
                    state["mode"] = "buffer"
                    state["etag"] = etag
                    return                        # start 暂押,压完再补 header 发出
                state["mode"] = "pass"
                await send(message)
                return
            if state["mode"] == "buffer":
                state["buf"].append(message.get("body") or b"")
                if message.get("more_body"):
                    return
                await self._flush(state, send)
                return
            await send(message)

        await self._app(scope, receive, _send)
        # 下游没发完就返回(异常路径):把押着的 start 补发,避免请求悬空。
        if state["mode"] == "buffer" and state["start"] is not None:
            await self._flush(state, send)

    @staticmethod
    async def _flush(state, send) -> None:
        raw = b"".join(state["buf"])
        state["buf"] = []
        blob = _GZIP_CACHE.get(state["path"], state["etag"])
        if blob is None:
            blob = gzip.compress(raw, compresslevel=5)
            _GZIP_CACHE.put(state["path"], state["etag"], blob)
        start = state["start"]
        state["start"] = None
        hdrs = [(k, v) for k, v in (start.get("headers") or [])
                if k.lower() not in (b"content-length", b"content-encoding")]
        hdrs.append((b"content-length", str(len(blob)).encode()))
        hdrs.append((b"content-encoding", b"gzip"))
        # Vary 必须带上:同一 URL 会因 Accept-Encoding 不同而产出不同字节,
        # 中间缓存/浏览器若不按它分桶,不支持 gzip 的客户端会拿到压缩体。
        if not any(k.lower() == b"vary" for k, _ in hdrs):
            hdrs.append((b"vary", b"Accept-Encoding"))
        await send({"type": "http.response.start",
                    "status": start.get("status", 200), "headers": hdrs})
        await send({"type": "http.response.body", "body": blob, "more_body": False})


class SelectiveGZipMiddleware:
    """按「扩展名 + 路由前缀 + Range 头」分流的 gzip:文本类走压缩,其余直出。

    刻意**不**继承 GZipMiddleware / 不改写 GZipResponder —— 后者的排除判据写在
    模块级常量与 send_with_compression 里,复制它等于把 50 行 starlette 内部实现
    钉进本仓库,换版本即腐烂。这里只在**外层按请求 scope 二选一**,决策发生在
    响应之前、确定,行为面最小、最稳。
    SVG 不在跳过表内(它是 XML 文本,压缩率实测 5,218→1,171),这是有意的。

    ★ Range 必须绕开(复查实测抓到的**真协议缺陷**,勿删):
      starlette 的 GZipMiddleware **完全不看状态码** —— 206 Partial Content 一样压。
      实测 `Range: bytes=0-99999` + `Accept-Encoding: gzip`:
          Content-Range: bytes 0-99999/431118   ← 声称 100,000 字节
          Content-Encoding: gzip
          实际 body 43,608 字节                  ← 与 Content-Range 不符
      这会让按区间续传/校验的客户端拿到自相矛盾的响应。小区间之所以"看着没事",
      只是因为 body < minimum_size 侥幸走了透传分支 —— 不是安全,是没触发。
      带 Range 的请求本就极少(媒体类已被扩展名挡掉),整条绕开代价为零。
    """

    def __init__(self, app, **kw):
        self._gzip = GZipMiddleware(app, **kw)
        self._plain = app
        self._cached = _CachedStaticGzip(app)    # 4.4.3:静态挂载目录走缓存分支

    async def __call__(self, scope, receive, send):
        if scope.get("type") == "http":
            path = scope.get("path", "")
            dot = path.rfind(".")
            if (dot > path.rfind("/") and path[dot:].lower() in _GZIP_SKIP_EXT) \
                    or path.startswith(_GZIP_SKIP_PREFIX) \
                    or any(k == b"range" for k, _ in scope.get("headers") or ()):
                await self._plain(scope, receive, send)
                return
            # 4.4.3:已挂载静态目录 + GET + 客户端收 gzip ⇒ 走「压一次、存起来复用」。
            # 三个条件缺一不可:非 GET(HEAD/OPTIONS)体裁不同;不收 gzip 就没得缓存;
            # 不在静态前缀内(/api/*、SPA 兜底)一律回原装 GZipMiddleware —— SSE
            # 因此在**路由结构上**就到不了缓存层,不依赖任何运行期判断。
            if scope.get("method") == "GET" and _STATIC_MOUNT_PREFIXES \
                    and path.startswith(_STATIC_MOUNT_PREFIXES):
                for k, v in scope.get("headers") or ():
                    if k == b"accept-encoding" and b"gzip" in v.lower():
                        await self._cached(scope, receive, send)
                        return
        await self._gzip(scope, receive, send)


app.add_middleware(SelectiveGZipMiddleware, minimum_size=1024, compresslevel=5)


# ── 请求体大小上限(5.3.0 复查补漏)──────────────────────────────────────────────────
# 实况:全站没有任何请求体上限,且 web 直接监听 0.0.0.0、前面没有反代(反代的 client_max_body_size
# 帮不上忙)。登录 / 注册 / 管理台登录这些**未鉴权**端点用 request.json() 一口气读完整个请求体 ——
# 往里面塞一个几 GB 的 JSON,web 进程(全站钉死单进程)会被整个撑爆。
# 合法请求的最大者是名录批量添加(纯文本房号,数千房也只有几十 KB);8 MiB 上限对它宽裕百倍。
# 构造期读取 STA_MAX_REQUEST_BYTES(同 STA_API_DOCS 的范式:非配置中枢参数,不进 REGISTRY)。
def _max_request_bytes() -> int:
    try:
        v = int(os.environ.get("STA_MAX_REQUEST_BYTES", "") or 0)
    except ValueError:
        v = 0
    return v if v > 0 else 8 * 1024 * 1024


class BodySizeLimitMiddleware:
    """纯 ASGI:声明的 Content-Length 超限 → 不读请求体直接 413;未声明长度(分块传输)→ 边读边计数,
    超限即 413、绝不把超出部分交给应用。只管有请求体的方法;GET / SSE / 静态资源零开销。"""

    _BODYLESS = frozenset({"GET", "HEAD", "OPTIONS"})

    def __init__(self, app, max_bytes: int):
        self.app, self.max_bytes = app, int(max_bytes)

    async def _reject(self, send) -> None:
        mb = max(1, self.max_bytes // (1024 * 1024))
        body = json.dumps({"ok": False, "error": "payload_too_large",
                           "hint": f"请求体过大(上限 {mb} MB)"}, ensure_ascii=False).encode("utf-8")
        await send({"type": "http.response.start", "status": 413,
                    "headers": [(b"content-type", b"application/json"),
                                (b"content-length", str(len(body)).encode()),
                                (b"connection", b"close")]})
        await send({"type": "http.response.body", "body": body})

    async def __call__(self, scope, receive, send):
        if scope.get("type") != "http" or scope.get("method", "GET") in self._BODYLESS:
            return await self.app(scope, receive, send)
        cl = None
        for k, v in scope.get("headers") or []:
            if k == b"content-length":
                try:
                    cl = int(v)
                except ValueError:
                    cl = None
                break
        if cl is not None:
            if cl > self.max_bytes:
                return await self._reject(send)
            return await self.app(scope, receive, send)
        # 未声明长度:先在这里读完(至多 max_bytes),超限即拒;未超限则原样回放给应用
        chunks, total = [], 0
        while True:
            msg = await receive()
            if msg["type"] != "http.request":
                chunks.append(msg)
                break
            total += len(msg.get("body", b"") or b"")
            if total > self.max_bytes:
                return await self._reject(send)
            chunks.append(msg)
            if not msg.get("more_body", False):
                break
        it = iter(chunks)

        async def replay():
            try:
                return next(it)
            except StopIteration:
                return await receive()
        return await self.app(scope, replay, send)


# 最后注册 = 最外层:超限请求在一切鉴权 / 解析之前就被挡下
app.add_middleware(BodySizeLimitMiddleware, max_bytes=_max_request_bytes())


def _req_user(request: Request):
    """当前请求的登录身份(userauth.Principal)。登录系统未启用恒为 None。
    容错:request=None(测试直调端点函数)或极简 stub(无 .state)一律视同无身份。"""
    try:
        return getattr(request.state, "user", None) if request is not None else None
    except Exception:
        return None


def _acct_realm(request: Request):
    """本请求应使用的账号库领域:登录用户 → 独立领域 u<id>;未启用登录 → 默认领域。"""
    u = _req_user(request)
    if userauth.enabled() and u is not None:
        return _accounts.get_realm(f"u{u.user_id}")
    return _accounts.get_realm(None)


async def _first_login_seed(user_id: int) -> None:
    """首登预置房:账号**第一次**登录成功时,把需求固定房(默认短号 321,真实号
    2678075)写进其名录 —— 新用户进门名录不是白板,立刻有东西可看。
    · 「首次」以 PG user_first_login 标记为准,标记与绑定同事务(db.py);此后
      用户删除预置房,下次登录**不会**被再次塞回。存量账号(功能上线前注册)
      在上线后的下一次登录补种一次,同样只此一次。
    · 预置走**直绑**、不走 /api/monitor/add 的准入归一:与 config 种子同信任级
      (运营者显式指定),且固定房必须钉真实号 —— 短号过繁星归一有「自回显」
      陷阱(见 config.yaml rooms 注),这正是配置格式要求真实号打头的原因。
    · 绑定后**无条件**做一次与 monitor_add 同款的幂等全局登记(运维钉住语义):
      正常部署 2678075 本就是 config 种子房,登记全为无害幂等;若它彼时只是
      自动发现房或已被运营撤下,登记把它转正/复位,杜绝无数据的僵尸名录项。
    · 名额:预置占用 1/room_max,与用户自添同权(可自行删除);首登时名录已满
      的存量账号只燃标记、不塞房,不突破名额硬上限(见 db.user_first_login_seed)。"""
    if not (userauth.enabled() and int(user_id or 0) > 0):
        return
    seed = userauth.parse_first_login_room(
        getattr(settings.userauth, "first_login_room", ""))
    if seed is None:
        return
    rid, alias = seed
    if not await ST.db.user_first_login_seed(int(user_id), rid, alias,
                                             int(settings.userauth.room_max)):
        return              # 非首登,或首登时名录已满(标记照燃,一次性语义不变)
    # 全局登记:**无条件**逐行复刻 monitor_add 的核心登记序(免准入闸,幂等)。
    # 不设「已在监控就跳过」的前置判断 —— 那会漏掉一个真实态:该房当前是
    # **自动发现房**(active 集包含发现房),不转正则仍随发现生命周期在离线
    # 7 天后被回收,预置绑定沦为僵尸。每账号一生只走一次,重复登记皆无害。
    await ST.bus.pending_remove(alias)
    await ST.bus.add_room(rid, alias)
    await ST.bus.discovered_remove(rid)
    with contextlib.suppress(Exception):
        await ST.db.discovered_delete_bulk([rid])
    await ST.db.upsert_room(rid, alias, True)
    if rid != alias:
        # 与 monitor_add 同款双影防线:此前若以短号挂起过,短号行的 pending
        # 一并清净,否则重启回灌会把它再灌回挂起集(转正/挂起双影)。
        await ST.db.upsert_room(alias, alias, False, pending=False)
    with contextlib.suppress(Exception):
        # 预置房是产品级固定房 → 运维钉住语义(与运维显式添加同款):清掉可能
        # 存在的「用户转正」溯源标,任何账号解绑归零都撤不下它的全局监控;
        # 刻意**不**打 user_added_mark。
        await ST.db.user_added_unmark(rid)
    _hm = settings.histmode
    if _hm.enabled and getattr(_hm, "curated_idle_enabled", False):
        with contextlib.suppress(Exception):
            # curated-idle:登记即「现在要监控」—— 访问戳置新 + 冷标清除,
            # 与 monitor_add 同语义(新房两调皆无害幂等)。
            await ST.bus.touch_rooms([rid], int(time.time() * 1000))
            await ST.bus.cold_clear(rid)
    from .redis_bus import task_hist, task_mainpage
    await ST.bus.schedule(task_mainpage(rid), int(time.time() * 1000))
    if settings.histmode.enabled:
        with contextlib.suppress(Exception):
            # hist-mode 转正封尾窗:同排一个 hs@now,序列/预测零冷启动等待
            # (与 monitor_add 同款;稳态 hs 任务稍后撞同一分支自灭,不留双影)。
            await ST.bus.schedule(task_hist(rid), int(time.time() * 1000))


# ── 九法 VIP 分层闸(4.2.0)──────────────────────────────────────────────────
# VIP_MATRIX 是「当前 vs VIP」对比表的**唯一数据源**:前端 /api/auth/session 取它
# 渲染对比层,后端 _vip_guard 按同一份声明放行 —— 二者同源,永远不会出现
# 「界面说能用、实际 403」的欺骗性文案(这是需求里"展示区别"那条的工程保证)。
# need: "basic" = free 档拒绝;"vip" = free/basic 均拒绝。
# 文案口径(两条,来自真机反馈):
#   ① 不用「主2防2」这种自创简写 —— 小白会读成「推荐数字 2」。
#      能力名用「下一局**预测参考**」而不是「下一局号码」:后者把预测说成了
#      确定的东西,而付费页恰恰最不该给人"买了就有准号"的错觉 ——
#      项目自己在推演卡上写的一直是「仅供参考」——4.3.7 前它在整卡 title 里,
#      该轮改为标题旁的常驻角标 .predict-ref(触屏无 hover,写在 title 里等于
#      没写);命中率 tooltip 与随身面板 rgPredictHtml 的口径同样未变。
#      具体拿到什么由 VIP 列的「主 2 码 + 防 2 码」承担(`码` 字消歧义,
#      对应 index.html 的 aria-label「主推号位」「防守号位」)。
#      分工:label 说**是什么性质**,vip 列说**具体给什么**。
#   ② 不列「两栏取值相同」的灵机推演命中率行 —— 升级表的职责是**呈现差别**,
#      而且原先「灵机推演」出现两行(一行 ✓✓、一行 🔒✓)本身就让人分不清到底
#      锁的是什么。合并为一行后语义唯一:锁的就是"下一局的号"。
#      (末尾游戏/名录两行两栏也相同,但保留 —— 它们回答的是"升级会不会失去
#       现有功能",与"差别"同样是用户真实关心的问题。)
#   ③ 4.4.0:road 行的 basic 列**不再写死** —— `jf_basic_online_h` 是 🟢 热更项,
#      写死就会在运维调窗/关窗后变成谎话,而本表的立身之本恰恰是「永不出现
#      界面说能用、实际不能用」。故 basic 列的**文案**由 vip_matrix() 按生效值
#      渲染;VIP_MATRIX 仍是「有哪些行、每行需要什么档位」的唯一声明。
VIP_MATRIX = [
    {"key": "road",   "label": "出怪序列 / 战况 / 出怪规律", "need": "basic",
     "basic": "本次 30 局起累计", "vip": "满 24 小时"},
    {"key": "pred",   "label": "灵机推演 · 下一局预测参考", "need": "vip",
     "basic": "", "vip": "主 2 码 + 防 2 码"},
    {"key": "replay", "label": "按日回看(昨天 / 前天…)", "need": "vip",
     "basic": "", "vip": "✓"},
    {"key": "wide",   "label": "序列全景回放", "need": "vip",
     "basic": "", "vip": "✓"},
    {"key": "game",   "label": "真实游戏 / 模拟游戏", "need": "basic",
     "basic": "✓", "vip": "✓"},
    {"key": "roster", "label": "主播名录 / 账号库", "need": "basic",
     "basic": "✓", "vip": "✓"},
]


def vip_matrix() -> List[dict]:
    """按**生效配置**渲染的能力矩阵(唯一出口;session 与 /api/vip/state 同源)。

    4.4.0:只有 road 行的 basic 列随 `jf_basic_online_h` 变 ——
      · 窗=0(关闭)→「本次 N 局起累计」(逐字节 4.3.x 文案)
      · 窗>0        →「在线累计,最长 H 小时」
    返回**深拷贝的新列表**:调用方(前端 JSON 序列化)不得触碰模块级常量。
    """
    ua = settings.userauth
    win = float(getattr(ua, "jf_basic_online_h", 0) or 0)
    lim = int(getattr(ua, "jf_basic_history_limit", 30))
    out = [dict(r) for r in VIP_MATRIX]
    for r in out:
        if r.get("key") == "road":
            r["basic"] = (f"本次 {lim} 局起累计" if win <= 0
                          else f"在线累计,最长 {win:g} 小时")
    return out


def _tier(request: Request) -> str:
    """本请求的档位。VIP 体系未启用 / 无登录身份(运维旁路、测试直调)一律回 'vip'
    —— 即全功能放行,保证旧部署与运维通道逐字节维持 4.1.2 行为。"""
    if not jfvip.enabled():
        return "vip"
    u = _req_user(request)
    if u is None:
        return "vip"
    # 防御性 getattr(复审加固):_req_user 返回的是「request.state.user 里的任何东西」。
    # 生产中 guard() 只会注入真 Principal,但本函数在**每个数据请求**上都要跑,
    # 一旦抛异常就是 500;在 SSE 里更会打死整条流。取不到 tier 时按最宽松的
    # "vip" 放行 —— 宁可少收一次钱,也绝不让付费用户看到 500。
    # (实测触发面:项目既有测试的身份桩没有 .tier;跨版本滚动升级同理。)
    t = getattr(u, "tier", None)
    return t if t in ("free", "basic", "vip") else "vip"


async def _vip_guard(request: Request, need: str = "basic") -> Optional[JSONResponse]:
    """VIP 档位闸。放在既有四道闸(roster / proof / 限流 / 租约)之**前** ——
    它最便宜(只读内存里的 Principal,零 I/O),先拒掉就省下后面所有开销。"""
    t = _tier(request)
    if t == "vip" or (need == "basic" and t == "basic"):
        return None
    return JSONResponse(
        {"ok": False, "error": "vip_required", "tier": t, "need": need,
         "message": ("开通九法VIP后可用" if t == "basic" else "请先开通九法VIP")},
        status_code=403)


async def _user_room_deny(request: Request, room: str, rid: str) -> Optional[JSONResponse]:
    """明细类端点(history/prediction/config/coverage/summary/SSE)的按账号访问闸:
    登录系统启用时,只放行**本账号名录内**的房(归一号/输入号双键)。
    未启用(或运维旁路)恒放行 —— 3.7.0 原行为。"""
    if not userauth.enabled():
        return None
    u = _req_user(request)
    if u is None:                      # 运维旁路(admin/token)或异常态:不做账号级过滤
        return None
    try:
        if await ST.db.user_room_allowed(u.user_id, str(rid), str(room)):
            return None
    except Exception:
        return None                    # PG 异常:宁可放行读也不误伤(数据本就非机密隔离级)
    # 5.0.8:前端在**显式**切房(点卡 / 搜索框敲号 / 分享链接)撞到本错时会先走一趟
    # /api/monitor/add(与「＋ 添加直播间」同一条准入阶梯:在播即入名录并重载),故本
    # 文案只在自动补绑不适用的路径上直显(跟随 / 存储恢复 / 写令牌部署)。文案去掉了
    # 「左侧」方位词 —— 与 5.0.2 的定案同口径:图标轨下左侧只有裸「＋」,手机上侧栏是
    # 收起的抽屉,方位词指向空无一物。
    return JSONResponse({"ok": False, "error": "room_not_bound",
                         "message": "该直播间不在你的名录中 —— 请先通过「＋ 添加直播间」加入名录再打开"},
                        status_code=403)


# ── 单账号「同时只监控 1 个房」+ 明细读限流(安全加固 3.9.0)────────────────────
def _client_tab(request: Request) -> str:
    """本请求所属**浏览器标签页**的标识(前端 app.js 安全传输层注入):
    · fetch 走自定义头 X-JF-Tab;· EventSource 带不了头,走 query ?tab=。
    缺失(非本站脚本/守卫未加载)→ 空串,由租约按「无标签页」从严处理(见 Lua 决策表)。
    容错:request=None(测试直调)或无 headers 的 stub 一律回空串。"""
    if request is None:
        return ""
    try:
        t = ""
        try:
            t = request.headers.get("x-jf-tab", "") or ""
        except Exception:
            t = ""
        if not t:
            try:
                t = request.query_params.get("tab", "") or ""
            except Exception:
                t = ""
        return str(t)[:40]
    except Exception:
        return ""


async def _active_room_guard(request: Request, rid: str) -> Optional[JSONResponse]:
    """每账号「同一时间只监控 1 个活跃房」租约闸(明细端点 + SSE 共用)。
    **last-wins 语义**:明细/SSE 是「持续监控」→ 走 renew(claim=False)。
    放行(返回 None)= 仍在活跃房、已续租。以下情形**一律放行**(逐字节旧行为 / 不误伤):
      · 登录系统未启用;· 无登录身份(运维旁路 admin/token,或测试直调 request=None);
      · 该特性被关闭(active_room_lease=False);· Redis 抢租异常(读路径 fail-open)。
    仅当「本账号的活跃房已被**另一个窗口/设备切换**到别的房」时,回
    `room_switched` + 应跟随的房号 —— 前端据此**自动切换到最新监控的房**(不是阻断)。"""
    if not userauth.enabled():
        return None
    u = _req_user(request)
    if u is None:
        return None
    if not bool(getattr(settings.userauth, "active_room_lease", True)):
        return None
    tab = _client_tab(request)
    ttl_ms = int(max(5.0, float(settings.userauth.active_room_lease_ttl_s)) * 1000)
    try:
        ok, held = await ST.bus.active_room_acquire(
            u.user_id, str(rid), tab, int(time.time() * 1000), ttl_ms, claim=False)
    except Exception:                 # noqa: BLE001 —— 协调层抖动不阻断读(与既有降级哲学一致)
        return None
    if ok:
        return None
    return JSONResponse(
        {"ok": False, "error": "room_switched", "room": held,
         # 3.9.4:归因改"本账号"——新前端用自己的归因文案+「切回」按钮,不读本字段;
         # 老前端/第三方直显本 message 时,"你"字会把别人的切换归因给本人(共享账号
         # 场景实测困惑源),故服务端兜底文案同步纠正。
         "message": "已切换到本账号最新监控的直播间"},
        status_code=409)


@app.post("/api/active-room/release")
async def active_room_release_ep(request: Request,
                                 roomId: str = Query(""),
                                 tab: str = Query("")):
    """主动交还本会话的活跃房租约(关页/切房时前端经 navigator.sendBeacon 发出)。
    这是**天花板级鲁棒性**的显式快路径:SSE 断流的服务端释放已够快(实测 <0.2s),
    但显式信标独立于「连接是否被浏览器优雅关闭」——即便强杀标签页/连接被池化,
    也能第一时间释放,让另一窗口零等待换房。幂等 + fail-safe:任何情形都回 ok,
    绝不抛错、绝不误删他人租约(释放 Lua 内有 room 匹配 + 活页计数把关)。
    CSRF 头已豁免(sendBeacon 带不了头);语义无害故安全。"""
    if not userauth.enabled():
        return JSONResponse({"ok": True})
    u = _req_user(request)
    if u is None or not str(roomId).strip():
        return JSONResponse({"ok": True})
    if not bool(getattr(settings.userauth, "active_room_lease", True)):
        return JSONResponse({"ok": True})
    t = str(tab).strip() or _client_tab(request)
    ttl_ms = int(max(5.0, float(settings.userauth.active_room_lease_ttl_s)) * 1000)
    # 租约按**归一后**的真实房号存(SSE/明细端点都 canon 后再抢),故释放也要 canon 对齐,
    # 否则短号别名对不上 lease.room → 释放变 no-op。canon 有缓存,开销可忽略。
    rid = str(roomId).strip()
    with contextlib.suppress(Exception):
        _r, _ = await asyncio.wait_for(ST.star.canon(rid), timeout=1.0)
        rid = _r or rid
    with contextlib.suppress(Exception):
        await ST.bus.active_room_release(
            u.user_id, str(rid), t, int(time.time() * 1000), ttl_ms)
    return JSONResponse({"ok": True})


@app.post("/api/active-room/claim")
async def active_room_claim_ep(request: Request,
                               roomId: str = Query(""),
                               tab: str = Query("")):
    """**显式切房**时抢占活跃房租约(last-wins)—— 用户主动点选/进入某房时,前端先调本端点
    把租约抢占到该房,再加载明细/SSE(确保后续 renew 命中本房、不会误判成"被切走"而回跳)。
    抢占成功即广播(3.9.4):该账号其它窗口的 SSE 订阅着 alr:evt 频道,**亚秒级**收到
    room_switched → 自动跟随到本房;广播丢失/未订阅时退回各自下一拍 renew(SSE 心跳
    ≤20s / 明细按局)兜底发现 —— 即时性是优化,心跳节拍才是保证下限。
    与 release 不同:claim 是用户显式动作(普通 fetch,能带 X-JF-Auth),故**照走 CSRF 头校验**,
    不加入豁免集。fail-open:未启用/无身份/特性关/Redis 异常 一律回 ok(不阻断切房)。

    4.2.4 补闸:全路由扫描发现本端点是 free 档唯一能拿到 200 且**产生服务端状态写入**
    的数据面 POST(实测 free/basic/vip 均 200)。它与 /api/monitor/add 是同一类
    「用户显式动作 + 写状态」,那一条早已接闸,这一条漏了。free 档看不到任何数据,
    自然也没有房可切 —— 接闸零功能影响,只是把纪律补齐。
    **release 刻意不接**:释放租约只会归还资源、永不消耗,且其契约明写
    「任何情形都回 ok,绝不抛错」;给它加 403 会在「会话中途掉档」时
    让租约滞留到 TTL 自然过期,是净损失。"""
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny
    if not userauth.enabled():
        return JSONResponse({"ok": True})
    u = _req_user(request)
    if u is None or not str(roomId).strip():
        return JSONResponse({"ok": True})
    if not bool(getattr(settings.userauth, "active_room_lease", True)):
        return JSONResponse({"ok": True})
    t = str(tab).strip() or _client_tab(request)
    ttl_ms = int(max(5.0, float(settings.userauth.active_room_lease_ttl_s)) * 1000)
    rid = str(roomId).strip()
    with contextlib.suppress(Exception):
        _r, _ = await asyncio.wait_for(ST.star.canon(rid), timeout=1.0)
        rid = _r or rid
    # 只能抢占**本账号名录内**的房(与明细端点同一把 roster 闸,双键 归一号/输入号)。
    # 缺了这道门,用户能把自己的活跃房租约指向一个自己读不了的房 —— 语义错误,且会让
    # 其它窗口被 follow 到该房后连续 403。**添加并打开**流程安全:前端是先 await
    # /api/monitor/add(后端入名录)再 loadRoom(explicit) → claim,故名录必然已就绪。
    # 被拒时**不报错**、只是不抢占(claim 全程 fail-open,绝不阻断切房;真正的
    # room_not_bound 提示由随后的明细请求给出,收口唯一)。
    if await _user_room_deny(request, str(roomId).strip(), rid) is not None:
        return JSONResponse({"ok": True, "room": ""})
    room = rid
    claimed = False
    with contextlib.suppress(Exception):
        _ok, room = await ST.bus.active_room_acquire(
            u.user_id, str(rid), t, int(time.time() * 1000), ttl_ms, claim=True)
        claimed = bool(_ok)
    # 3.9.4:抢占成功即广播 —— 本账号其它窗口的 SSE 订阅了 alr:evt 频道,收到后
    # 立刻做一次权威 renew,「被切走 → 跟随」的发现延迟从「≤20s 心跳下一拍」压到
    # 亚秒。广播 best-effort:失败/无订阅者时逐字节退回既有心跳节拍,零回归面。
    if claimed:
        with contextlib.suppress(Exception):
            await ST.bus.publish_lease_switch(u.user_id, str(room))
    return JSONResponse({"ok": True, "room": room})


async def _detail_rate_guard(request: Request) -> Optional[JSONResponse]:
    """每账号明细读限流闸(prediction / summary / coverage / history[非 passive])。
    **注意:SSE(/api/events)不在此闸内**(审计更正——此前本注释误称覆盖 SSE)。
    SSE 的护栏是「roster 门 + 活跃房租约 + 单连接单房」:一条流只推一个房,拿不到
    横向多房数据;其建流频次由租约 hash 的 tab 上限兜底(见 _LUA_LEASE_ACQ 的 CAP)。
    阈值宽松,真人单房浏览远达不到;纯脚本高频搬运会被削平为配置 QPS。
    放行情形同上(未启用登录/无身份/桶未就绪);**fail-open**:限流器异常一律放行,
    绝不因 Redis 抖动误伤真人。仅在明确超配额时回 429 + Retry-After。"""
    if not userauth.enabled():
        return None
    u = _req_user(request)
    if u is None:
        return None
    b = getattr(ST, "detail_bucket", None)
    if b is None:
        return None
    try:
        ok, wait_ms = await b.try_acquire_key(f"rl:detail:u{int(u.user_id)}", 1.0)
    except Exception:                 # noqa: BLE001 —— fail-open
        return None
    if ok:
        return None
    return JSONResponse(
        {"ok": False, "error": "rate_limited",
         "message": "请求过于频繁,请稍后再试"},
        status_code=429,
        headers={"Retry-After": str(max(1, int((wait_ms or 1000) / 1000)))})


# ── L2:执行证明闸(proof-of-browser,安全加固 3.9.1)──────────────────────────
# 威胁模型与诚实边界见 settings.UserAuthCfg.proof_of_browser 注。核心:明细端点要
# 求一枚 X-JF-Proof 应答头,其值 = 前端**混淆 JS** 对服务端下发挑战算出的 _pow_answer。
# 纯 API 搬运器(不跑 JS)算不出 → 401 proof_required。挑战按会话存 Redis(短 TTL),
# 前端窗口内复用应答;服务端每次明细请求重算比对(一次 Redis GET + 一次纯算,均极廉)。
#    4.0.0:变换 T 抽到 app/powproof.py(注册系统 R2 复用同一实现,web↔userauth
#    不成环)。此处同名回挂 —— `web._pow_answer` 继续存在,黄金向量/活体对拍
#    (tests/test_proof_of_browser.py)与一切既有调用点逐字节同行为。
from .powproof import pow_answer as _pow_answer  # noqa: E402

K_POW_CHALLENGE = "powchal:{sid}"          # string: 会话级挑战(无标签页头时的兼容路径)
K_POW_CHALLENGE_TAB = "powchal:{sid}:{tab}"  # 4.9.0:按标签页分号,多开互不作废
_POW_TAB_RE = re.compile(r"[^0-9A-Za-z_-]")


def _pow_enabled() -> bool:
    return bool(userauth.enabled()
                and getattr(settings.userauth, "proof_of_browser", False))


def _pow_sid(request: Request) -> str:
    """把会话 Cookie 派生成稳定的会话标识(**不落原值**):挑战/证明按会话绑定,
    换会话即另一挑战 —— 把 X-JF-Proof 搬到别的会话也对不上(挑战按 sid 存)。"""
    try:
        raw = request.cookies.get(userauth.UA.cfg.cookie_name, "") or ""
    except Exception:
        raw = ""
    if not raw:
        return ""
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]


def _pow_key(request: Request) -> str:
    """挑战键(4.9.0:**按标签页分号**)。

    为什么必须分号(实地复现,非推断):此前只有一把 `powchal:{sid}`,而 sid 是
    会话 Cookie 的摘要 —— **同一浏览器的所有标签页共用它**。于是 A 页 mint 会直接
    覆盖 B 页正在用的挑战,B 页下一拍必 401;B 页按 proof_required 重铸又反过来废掉
    A 页 …… 实测 12 拍交替 → pow_fail=14 / pow_ok=1,真人被刷成「执行证明失败 N 次」。

    分号的安全面为零损失:键里**仍然含 sid**,把 X-JF-Proof 搬到别的会话照样对不上;
    标签页号只是同一会话内部的命名空间,攻击者自造一个也只是给自己开一把新挑战,
    仍必须跑那段(部署时被混淆的)JS 才算得出应答。
    前端 api() 本就在每个请求上发 X-JF-Tab(3.9.0 起),故 mint 与校验天然同号;
    老前端/运维直连没有该头 → 回落会话级键 = 逐字节 3.9.x 行为。"""
    sid = _pow_sid(request)
    if not sid:
        return ""
    tab = ""
    try:
        tab = _POW_TAB_RE.sub("", str(request.headers.get("x-jf-tab", "") or ""))[:32]
    except Exception:
        tab = ""
    return (K_POW_CHALLENGE_TAB.format(sid=sid, tab=tab) if tab
            else K_POW_CHALLENGE.format(sid=sid))


def _pow_grace_key(key: str) -> str:
    """轮转宽限键:每次 mint 把**旧**挑战转存于此(短活),宽限期内仍然认。"""
    return key + ":p"


async def _proof_guard(request: Request) -> Optional[JSONResponse]:
    """执行证明闸:未开特性 / 未启用登录 / 无身份 → 放行;Redis 异常 → fail-open 放行。
    开启后:请求须带 X-JF-Proof == _pow_answer(该标签页当前挑战)。

    4.9.0 两处加固(均为**减少对真人的假失败**,不放松任何拦截):
      ① **轮转宽限**:当前挑战对不上时再看一眼 `:p`(上一把挑战的短活副本)。
         在飞请求带的是旧应答、或另一标签页刚 mint 过 —— 这类时序性错配不该
         被当成「证明失败」。宽限只是把**已签发过**的挑战多认几十秒,攻击者
         照样得跑 JS 才算得出应答,绑定 sid 的性质不变。
      ② **stale / fail 分类**:客户端带了应答但两把挑战都不在 → pow_stale
         (服务端过期,良性,不计疑度);根本没带应答、或挑战在却算错 → pow_fail
         (真信号)。分类前:真人因 180s 挑战过期每 3 分钟稳吃一次 pow_fail。
    拒绝语义、状态码、报文与 3.9.x 逐字节一致(前端重铸重试路径不变)。"""
    if not _pow_enabled():
        return None
    if _req_user(request) is None:
        return None
    key = _pow_key(request)
    if not key:
        return None                    # 无会话交由 guard 处置,此处不横插
    try:
        chal = await ST.bus.r.get(key)
    except Exception:                  # noqa: BLE001 —— fail-open
        return None
    got = ""
    try:
        got = request.headers.get("x-jf-proof", "") or ""
    except Exception:
        got = ""
    if chal and got and got == _pow_answer(str(chal)):
        await _sig_pow(request, ok=True)
        return None
    prev = None
    grace_on = float(getattr(settings.userauth, "proof_rotate_grace_s", 45.0)) > 0
    if grace_on and got:               # 只有「带了应答」才值得多花一次 GET 查宽限
        try:
            prev = await ST.bus.r.get(_pow_grace_key(key))
        except Exception:              # noqa: BLE001 —— 宽限查不到就当没有,不影响主判
            prev = None
        if prev and got == _pow_answer(str(prev)):
            await _sig_pow(request, ok=True)      # 轮转命中 = 对方确实在跑 JS
            return None
    # 分类必须**不可被绕过**(对抗性自审实测)。曾经写成「带了应答且两把挑战都不在
    # → stale」,结果是:搬运器只要**乱发一个证明头**,20 次失败就全部变成不计分的
    # pow_stale,因子②(+35)整条失效,分数从 95 掉到 60。
    # 正确判据是「我们**确实刚给这把键轮转过挑战**」—— 即 prev 键还在。只有那时
    # 客户端手上的旧应答才可能是被我们自己转掉的;prev 都不在 = 从没发过 / 早就过期,
    # 那属于对方在瞎编,必须记 pow_fail。
    stale = bool(got) and not chal and bool(prev)
    await _sig_pow(request, ok=False, stale=stale)
    return JSONResponse(
        {"ok": False, "error": "proof_required",
         "message": "浏览器校验未通过,请刷新页面重试"},
        status_code=401)


# ── 账号 / 扫码登录(恢复的 accounts_backend,与前端同源)────────────────────────
# 前端 app.js 的账号面板全部调 GET /api/account/*(create/poll/list/switch/remove/
# check/refresh)。accounts_backend.handle_api(path, q) 用阻塞 urllib 打酷狗登录接口,
# 故丢线程池执行,避免阻塞事件循环。q 采用 parse_qs 形态(值为列表),与其约定一致。
@app.api_route("/api/account/{rest:path}", methods=["GET", "POST"])
async def account_api(rest: str, request: Request):
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny                              # 4.2.0:真实游戏依赖账号库 → basic 可用
    path = "/api/account/" + rest
    q = {k: request.query_params.getlist(k) for k in request.query_params.keys()}
    # 领域注入(3.8.0):登录用户各有独立账号库文件(accounts-u<id>.json)。
    # contextvars 会被复制进线程(anyio 的 run_sync 内部 copy_context),handle_api
    # 与真实游戏后端的 get_current_raw 读到的都是**本请求用户**的领域。
    _accounts.set_request_realm(_acct_realm(request))
    try:
        # 走 _UPSTREAM_THREADS 而非默认线程池(舱壁):本调用最坏占线程十余秒,
        # 与静态资源共享 40 令牌时会把整站拖到 8s(实测,见 _UPSTREAM_THREADS 注)。
        res = await _run_upstream_blocking(_accounts.handle_api, path, q)
    except Exception as e:
        return JSONResponse({"ok": False, "error": "account_error", "detail": str(e)},
                            status_code=500)
    if res is None:
        return JSONResponse({"ok": False, "error": "not_found"}, status_code=404)
    status, obj = res
    return JSONResponse(obj, status_code=int(status))


# ── 官方 / 真实游戏(恢复的 game_backend,与前端同源)───────────────────────────
def _game_profile(room: str) -> dict:
    """game_backend 的 profile_provider(同步契约):房号 → {kugouId, nickname, avatar}。
    资料源是异步 StarMeta.profile,本函数在 handle_api 的线程池里被同步调用,故经事件
    循环桥接(run_coroutine_threadsafe:线程池 → 主循环执行协程,拿到结果再返回)。"""
    try:
        loop = getattr(ST, "loop", None)
        if loop is None:
            return {}
        fut = asyncio.run_coroutine_threadsafe(ST.star.profile(str(room)), loop)
        return fut.result(timeout=10) or {}
    except Exception:
        return {}


@app.api_route("/api/game/{rest:path}", methods=["GET", "POST"])
async def game_api(rest: str, request: Request):
    # 前端 gapi 全部 GET + query(含 cast 的 spell/count/round/price)。handle_api(path,q)
    # 用当前登录账号票据打酷狗官方降妖接口(阻塞 urllib,丢线程池)。
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny                              # 4.2.0:「真实游戏」是 basic 档的明示权益
    path = "/api/game/" + rest
    q = {k: request.query_params.getlist(k) for k in request.query_params.keys()}
    # 领域注入(3.8.0):game_backend 经 get_current_raw() 取「当前账号」票据 ——
    # 该函数读请求期领域(contextvars 随线程池调用传递),登录用户
    # 玩真实游戏用的是**自己账号库里选中的账号**,与他人完全隔离。
    _accounts.set_request_realm(_acct_realm(request))
    try:
        # 走 _UPSTREAM_THREADS(舱壁)。本路径比账号侧更重:_post_mapi 阻塞 12s 之外,
        # profile_provider(_game_profile)还会在**同一条线程上**再 fut.result(timeout=10)
        # 等主循环解析主播资料 —— 单请求最坏占线程二十余秒,更不能与静态资源同池。
        res = await _run_upstream_blocking(_game.handle_api, path, q)
    except Exception as e:
        return JSONResponse({"ok": False, "error": "game_error", "detail": str(e)},
                            status_code=500)
    if res is None:
        return JSONResponse({"ok": False, "error": "not_found"}, status_code=404)
    status, obj = res
    return JSONResponse(obj, status_code=int(status))
# 前端 acctAvatar()/房间头像把酷狗头像 URL 重写成 <img src="/fx/avatar?u=…">,由本机
# 中转图片字节(酷狗头像域有防盗链/Referer 校验,浏览器直连会被挡)。仅允许 https 且
# kgimg.com / kugou.com 图片域,避免沦为开放代理;带内存缓存 + 尺寸变体缺失回退原图。
_AV_CACHE: Dict[str, tuple] = {}
_AV_TTL = 3600.0
_AV_MAX = 512
_av_session: Optional[aiohttp.ClientSession] = None
_av_lock = asyncio.Lock()


async def _av_get_session() -> aiohttp.ClientSession:
    global _av_session
    if _av_session is None or _av_session.closed:
        async with _av_lock:
            if _av_session is None or _av_session.closed:
                _av_session = aiohttp.ClientSession(
                    timeout=aiohttp.ClientTimeout(total=8),
                    connector=aiohttp.TCPConnector(limit=32, ttl_dns_cache=300))
    return _av_session


@app.get("/fx/avatar")
async def fx_avatar(u: str = Query("")):
    from urllib.parse import urlparse
    url = str(u).strip()
    pu = urlparse(url)
    host = pu.hostname or ""
    if pu.scheme != "https" or not (host.endswith("kgimg.com") or host.endswith("kugou.com")):
        return Response(status_code=400)
    hit = _AV_CACHE.get(url)
    if hit and hit[0] > time.time():
        return Response(content=hit[1], media_type=hit[2],
                        headers={"Cache-Control": "public, max-age=3600"})
    sess = await _av_get_session()
    hdrs = {"User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                           "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"),
            "Referer": "https://fanxing.kugou.com/", "Accept": "image/*,*/*"}

    async def _grab(target: str):
        async with sess.get(target, headers=hdrs, ssl=False) as r:
            b = await r.read()
            if r.status != 200 or not b:
                raise RuntimeError(f"avatar http {r.status}")
            return b, (r.headers.get("Content-Type") or "image/jpeg")

    try:
        body, ctype = await _grab(url)
    except Exception:
        base = re.sub(r"_\d+x\d+\.[A-Za-z]+$", "", url)   # 尺寸变体缺失 → 回退原图
        if base == url:
            return Response(status_code=502)
        try:
            body, ctype = await _grab(base)
        except Exception:
            return Response(status_code=502)
    if not ctype.startswith("image/"):
        ctype = "image/jpeg"
    if len(_AV_CACHE) >= _AV_MAX:
        _AV_CACHE.pop(next(iter(_AV_CACHE)))
    _AV_CACHE[url] = (time.time() + _AV_TTL, body, ctype)
    return Response(content=body, media_type=ctype,
                    headers={"Cache-Control": "public, max-age=3600"})


# ── 回合对象(PG 行 → 观测台契约;逐字段对齐旧 round_from_row) ────────────────
def _round_from_row(row: dict) -> dict:
    start = int(row["round_id"])
    cid = row.get("custom_id")
    meta = BEAST_BY_CID.get(cid) if cid is not None else None
    oid = row.get("official_id")
    if meta is None and oid is not None:
        meta = BEAST_BY_OFFICIAL.get(oid)
    meta = meta or {}
    draw = row.get("draw_ms") if row.get("draw_ms") is not None else start + DRAW_OFFSET_MS
    return {
        "round_id": str(start),
        "beast_id": oid if oid is not None else meta.get("beast_id"),
        "beast_name": row.get("beast_name") or meta.get("beast_name", ""),
        "spell_key": meta.get("spell_key", ""),
        "spell_name": meta.get("spell_name", ""),
        "display_number": cid if cid is not None else meta.get("display_number"),
        "multiplier": row.get("multiplier") if row.get("multiplier") is not None else meta.get("multiplier"),
        "start_time_ms": start,
        "spell_time_ms": start + SPELL_OFFSET_MS,
        "draw_time_ms": draw,
        "end_time_ms": start + END_OFFSET_MS,
        "source": row.get("source") or "GameHistory",
        "captured_at": _iso(draw + 2000),
    }


async def _room_nick(room: str) -> str:
    prof = await ST.star.profile(room)
    return (prof.get("nickname") or "") or ("房间 " + str(room))


async def _room_avatar(room: str) -> str:
    return (await ST.star.profile(room)).get("avatar") or ""


# ── builders(对齐旧 build_*) ────────────────────────────────────────────────
async def _live_room_card(rid: str, host_now: int, pending: bool = False,
                          cold: bool = False, live: Optional[tuple] = None) -> dict:
    """3.9.5 名录角标诚实化(实地核查修复,三处失真同修):

    ① `lastOkAt` 不再伪装新鲜:旧式 `or srv` 在快照缺失(刚启动/待归一/Redis 重建)
       时回退成「现在」,前端速览把一个**从未抓过数据**的房画成正常倒计时。改为
       缺失即空串 —— 旧前端拿到空串走「无 okAt」分支照旧显示倒计时(可见行为与
       现状逐一推演一致,零回归);新前端(app.js railChip 3.9.5)据此显示「待」。
    ② 新增 `dataOkAt` = max(实时管线 lastOkAt, 低频轮询 histLastOkMs):curated-idle
       降级后 `_handle_hist` 只写 histLastOkMs(worker.py),lastOkAt 从降级那一刻
       冻结 —— 这正是「名录挂『休』但数据其实每 T 都在成功入库、零缺口」的根因。
       数据新鲜度的**唯一诚实口径**是两管线取新者,前端失联判定一律用它。
    ③ 新增 `mode`:pending(待归一)/ idle(curated-idle 冷房,低频采集中)/
       realtime。冷房**数据完整只是节奏不同**,前端据此把倒计时标成「省流」态
       而不是误报成"可能已下播"。cold 由调用方批取一次 cold_members() 传入
       (双开关 gate + fail-open 空集,见 _build_live_rooms)—— 不逐房 HEXISTS。
       注:idle 语义 =「近 30 分钟无任何用户实时访问」,对同部署内其他登录账号
       可见;本工具为私有部署、房间为公开直播间,接受此弱信息面换取展示诚实。"""
    alias = rid if pending else await ST.bus.alias_of(rid)
    snap = {} if pending else await ST.bus.get_snapshot(rid)
    cur = _snap_int(snap, "roundStartTimeMs")
    if not cur:
        latest = await ST.db.latest_round(rid)
        # rounds 行的 round_id 即起点毫秒(start_ms);下一局 = +步进
        cur = (int(latest["round_id"]) + ROUND_STEP) if latest else None
    srv = _snap_int(snap, "serverNowMs") or host_now
    # 展示资料按 alias(用户输入号)解析更稳(短号频道页身份稳定,不随登台主播漂移)
    prof = await ST.star.profile(alias)
    ok_rt = _snap_int(snap, "lastOkAt")        # 实时管线(MainPage)最近成功
    ok_hs = _snap_int(snap, "histLastOkMs")    # 低频轮询(GameHistory)最近成功
    ok_any = max(ok_rt, ok_hs)
    return {
        "alias": alias, "roomId": str(rid),
        "nickname": (prof.get("nickname") or "") or ("房间 " + str(alias)),
        "avatar": prof.get("avatar") or "",
        "currentRoundId": str(cur) if cur else "",
        "serverOffsetMs": _snap_int(snap, "serverOffsetMs") or 0,
        "roundStartTimeMs": cur or 0,
        "spellTimeMs": _snap_int(snap, "spellTimeMs") or ((cur + SPELL_OFFSET_MS) if cur else 0),
        "drawTimeMs": _snap_int(snap, "drawTimeMs") or ((cur + DRAW_OFFSET_MS) if cur else 0),
        "endTimeMs": _snap_int(snap, "endTimeMs") or ((cur + END_OFFSET_MS) if cur else 0),
        "timerUpdatedAt": _iso(srv),
        "lastOkAt": _iso(ok_rt) if ok_rt else "",
        "dataOkAt": _iso(ok_any) if ok_any else "",
        "mode": "pending" if pending else ("idle" if cold else "realtime"),
        "lastError": snap.get("lastError", "") or "",
        # 5.0.6 直播状态:true=直播中 / false=未开播 / **null=未知**(总开关关闭、
        # worker 未跑或停摆、观测已过 stale_s、待归一房)。三态是刻意的 ——
        # 把「问不到」压成 false 就是拿一句谎去省一个字段,与 3.9.5 那轮修的
        # 「快照缺失伪装成刚抓过」是同一种病。前端据此画:绿点 / 隐藏 / 灰环。
        "live": (None if live is None else bool(live[0] == 1)),
        "liveAt": ("" if live is None else _iso(live[1])),
    }


async def _visible_rooms() -> List[str]:
    """前端可见房 = 活跃名录 − 自动发现集。

    自动发现的直播间(遍历繁星在播列表纳入的)只在后台采集数据,**不进任何面向
    前端的房间列表/计数** —— 前端只显示用户显式添加的房;发现房被手动添加时会
    自动转正(移出发现集,见 monitor_add / add-bulk / config 注入),从而变为可见。
    所有返回「房间集合/数量」的端点必须经本函数,禁止直接返回 bus.active_rooms()
    (那是后台抓取全集,含发现房)。按房号访问明细(history/prediction/summary)
    不在此列 —— 那是数据读取,不是列表展示。"""
    active = await ST.bus.active_rooms()
    discovered = await ST.bus.discovered_members()
    if not discovered:
        return list(active)
    return [r for r in active if r not in discovered]


async def _cold_room_set() -> set:
    """curated-idle 冷房集合(3.9.5:供 live-rooms 卡片标注 mode="idle")。

    姿态与 crawler_status 的同名段逐字对齐:双开关 gate(任一关闭 = 零 Redis
    命令,契约⑪;残留冷标对展示同样惰性 —— 与 worker._dormant 的判据一致),
    单次 HKEYS 批取(不逐房 HEXISTS),失败 fail-open 回空集 = 全按 realtime
    展示(方向保守:Redis 抖动绝不把用户在看的房误标成省流态)。"""
    _hm = settings.histmode
    if not (_hm.enabled and getattr(_hm, "curated_idle_enabled", False)):
        return set()
    with contextlib.suppress(Exception):
        return set(await ST.bus.cold_members())
    return set()


async def _live_status_map(rooms: List[str]) -> dict:
    """策展房直播状态批取(5.0.6):room_id -> (state, ts_ms),只回**未过期**的观测。

    姿态与 _cold_room_set 逐字对齐:开关关闭 = 零 Redis 命令;单次 HMGET 批取
    (不逐房 HGET);失败 fail-open 回空 dict —— Redis 抖动时全员降为「未知」,
    而不是被误画成「未开播」。过期判定放在 web 侧而非 worker 侧,是因为
    「worker 整个停摆」恰恰是最该被识破的那种失效,而停摆的 worker 不会来
    给自己的旧观测打上过期标记。"""
    if not (settings.livestatus.enabled and rooms):
        return {}
    with contextlib.suppress(Exception):
        got = await ST.bus.livestatus_get_many(rooms)
        cutoff = int(time.time() * 1000) - \
            max(1, int(settings.livestatus.stale_s)) * 1000
        return {r: v for r, v in got.items() if v[1] >= cutoff}
    return {}


def _hist_interval_s() -> int:
    """低频轮询的**生效**周期(秒,含代码侧钳制)—— 3.9.5 随 live-rooms 顶层下发,
    前端据此推导 idle 房的失联阈值(2×T + 余量),不再硬编码猜服务端配置。
    histmode 关闭时返回 0(前端取缺省,亦兼容旧后端无此字段)。"""
    if not settings.histmode.enabled:
        return 0
    try:
        return int(effective_hist_interval_ms(settings.histmode) // 1000)
    except Exception:
        return 0


def _live_rooms_sem() -> asyncio.Semaphore:
    """/api/live-rooms 逐房拼卡的并发闸(每请求一把,不跨请求共享)。

    每请求新建而非全局单例是刻意的:全局闸会让并发请求互相排队、把 P99 拖成
    队列长度的函数;每请求一把只保证**单个请求**不把池吸干,请求之间仍然并行
    (池本身就是它们的共同上界)。"""
    n = max(1, int(getattr(settings, "live_rooms_concurrency", 32) or 32))
    return asyncio.Semaphore(n)


async def _build_live_rooms(user=None) -> dict:
    host_now = int(time.time() * 1000)
    _sem = _live_rooms_sem()

    async def _gated(coro):
        async with _sem:
            return await coro
    cold_set = await _cold_room_set()          # 3.9.5:一次批取,逐卡查集合(O(1))
    if user is not None:
        # 登录系统(3.8.0):名录按登录账号隔离 —— 只回该账号绑定的房。
        # 监控本体仍是全局的(多账号绑同一房共享同一份抓取数据),
        # alias 覆写为**该用户当初输入的号**(逐字节复刻旧前端展示口径)。
        binds = await ST.db.user_rooms_list(user.user_id)
        pend_set = set(await ST.bus.pending_rooms())
        live_map = await _live_status_map([str(b["room_id"]) for b in binds])

        async def _card(b: dict) -> dict:
            rid = str(b["room_id"])
            c = await _live_room_card(rid, host_now, pending=(rid in pend_set),
                                      cold=(rid in cold_set),
                                      live=live_map.get(rid))
            c["alias"] = str(b.get("alias") or rid)
            return c

        cards = list(await asyncio.gather(*[_gated(_card(b)) for b in binds]))
        return {"ok": True, "rooms": cards, "histIntervalS": _hist_interval_s()}
    active = await _visible_rooms()
    pend = [a for a in await ST.bus.pending_rooms() if a not in set(active)]
    # 并发拼卡片:profile 有 600s 缓存,首轮未命中时 gather 把 N 房的网络解析
    # 并行化(StarMeta 内部 per-room 锁防同房惊群),5000 房目标下保持可用。
    # ★ 修复:并发**必须有闸**。原实现对 N 个房无上限 gather —— 每张卡内部要
    #   串行发 2~3 条 Redis 命令,于是单个请求瞬时申领 N 条池连接。N=199 时就吃掉
    #   256 池的 78%,再来一个并发请求即枯竭(真机实证的池打满推手之一)。
    #   钳到 settings.live_rooms_concurrency 后,单请求占用可控且与房数解耦;
    #   代价仅是首轮冷缓存时稍慢(稳态 profile 命中缓存,几乎无差别)。
    live_map = await _live_status_map(list(active))
    cards = list(await asyncio.gather(
        *[_gated(_live_room_card(r, host_now, cold=(r in cold_set),
                                 live=live_map.get(r))) for r in active],
        *[_gated(_live_room_card(a, host_now, pending=True)) for a in pend]))
    return {"ok": True, "rooms": cards, "histIntervalS": _hist_interval_s()}


async def _build_summary(room: str) -> dict:
    rid, _ = await ST.star.canon(room)
    latest = await ST.db.latest_round(rid)
    latest_obj = _round_from_row(latest) if latest else None
    return {"ok": True, "summary": {
        "requestedRoomId": str(room), "resolvedRoomId": str(rid),
        "room": {"room_id": str(rid), "last_seen_at": _iso(int(time.time() * 1000))},
        "roundCount": 0, "latestRound": latest_obj,
    }}


async def _build_profile(room: str) -> dict:
    """房间资料。exists 三态,**刻意不是布尔**:
      True  —— 归一成功(繁星确实认得这个号)
      False —— 归一确证失败且资料全空
      None  —— 说不准(上游抖动等),前端据此**不做清退**

    诚实标注适用面(复查实测修正,勿高估这个字段):`StarMeta.canon` 的
    `definitive` 在**上游全灭时依然是 True** —— `_resolve` 一开始就把
    `prof["roomId"]` 播种为入参房号,而入参恒是 2–12 位数字,于是
    `rid.isdigit()` 必真(用 DeadSession 实测:`canon("321") -> ("321", True)`)。
    换言之对合法房号本字段**几乎恒为 True**,只有房号本身不合 `^[0-9]{2,12}$`
    才会落到 False —— 而那条路 monitor_add 早已用 bad_room 先行拦下。

    所以这不是「修好了前端那三处 `exists === false` 清退分支」,那三处仍然基本
    不会触发;它只是把一个**保守且真实**的信号补齐,顺带杜绝「上游一抖就把
    用户的房判成不存在」那种更坏的结果。要让它真正可用,得先让
    `StarMeta._room_status` 把「查无此房(code 1100004/1100009)」与「网络失败」
    分开——那是另一件事,不在本次范围内。
    """
    prof = await ST.star.profile(room)
    rid, definitive = await ST.star.canon(room)
    has_meta = bool(prof.get("nickname") or prof.get("avatar"))
    exists: Optional[bool] = True if definitive else (False if not has_meta else None)
    return {"ok": True, "profile": {
        "alias": str(room), "roomId": str(rid),
        "nickname": prof.get("nickname") or ("房间 " + str(room)),
        "avatar": prof.get("avatar") or "",
        "exists": exists,
        "profileUpdatedAt": _iso(int(time.time() * 1000)),
    }}


def _spells_config(room: str) -> List[dict]:
    spells = json.loads(json.dumps(ST.spells_template))
    now = _iso(int(time.time() * 1000))
    for sp in spells:
        sp["room_id"] = str(room)
        sp["updated_at"] = now
    return spells


async def _build_prediction(room: str) -> dict:
    out = {"ok": True, "target_round_id": None, "main": [], "guard": [],
           "ens": [], "record": [], "accuracy": None, "why": "", "trainN": None}
    pend = await ST.db.pending_prediction(room)
    if pend:
        # 陈旧孤儿过滤(仅滤"落后一整局以上"的铁孤儿):首版用 <=latest 曾把
        # 「结算窗/时序边界内的正常 pending」也误杀,前端预测数字消失(真机
        # HAR 实证回归 —— 12 拍中 10 拍 target=None)。宁可让远古值闪现一拍,
        # 绝不误杀正常数字;4.5h 孤儿(落后数百局)仍被本条件拦住。
        # 孤儿成因=目标局妖兽未知(cid=NULL)结算被跳过,存量可 SQL 手清。
        snap = await ST.bus.get_snapshot(room)
        latest = _snap_int(snap, "latestRoundId")
        if not latest:
            lr = await ST.db.latest_round(room)
            latest = int(lr["round_id"]) if lr else 0
        if latest and int(pend["round_id"]) + 50_001 <= latest:
            pend = None
    else:
        # ── 3.4.6 换手回退(读者侧兜底)────────────────────────────────────────
        # `pending_prediction` 取「actual IS NULL 里 round_id 最大的那条」。若某条
        # 路径先把上一局结算掉、再去跑 sequence+run_prediction 才写下一局预测
        # (回填/哨兵路径 _settle_only + _ensure_next_prediction 就是这样),那这中间
        # 表里**一条未结算的行都没有** → 这里拿到 None → 返回 target:null / main:[]
        # → **前端四个数字显示成 `-`**(真机 HAR 实证 22% 命中:前端 predChase 恰在
        # 出怪到达那一刻拉取,精准撞窗)。出怪主路已用 db.settle_and_save_prediction
        # 做成原子换手,窗口消失;这里再补一道**读者侧**兜底,覆盖其余路径。
        #
        # 回退是**有界**的:只有当「最新一条预测行恰好就是刚结算的那一局」时才回退
        # (= 确实处在换手瞬间)。绝不回退到更老的预测 —— 那会把陈旧号当成当前号显示,
        # 正是上面孤儿过滤要防的事。
        lp = await ST.db.latest_prediction(room)
        if lp:
            snap = await ST.bus.get_snapshot(room)
            latest = _snap_int(snap, "latestRoundId")
            if not latest:
                lr = await ST.db.latest_round(room)
                latest = int(lr["round_id"]) if lr else 0
            if latest and int(lp["round_id"]) == latest:
                pend = lp
    if pend:
        out["target_round_id"] = str(pend["round_id"])
        out["main"] = list(pend.get("main_ids") or [])
        out["guard"] = list(pend.get("guard_ids") or [])
        detail = pend.get("detail")
        if isinstance(detail, str):
            try:
                detail = json.loads(detail)
            except ValueError:
                detail = {}
        out["ens"] = (detail or {}).get("ens") or []
        # 反固执改造:explore.why(如「连败换血·同四码连推且已3局未中·撤下8号…」)
        # 随 pending 载荷透出 —— 把"我知道我在连错、我换了"说给用户听,
        # 是对"固执"观感最直接的消解。老 detail 无此键 → 恒空串,前端隐藏。
        out["why"] = str(((detail or {}).get("explore") or {}).get("why") or "")
        # 4.9.5:训练样本量随预测一起透出。它是「train_window_hours / max_train
        # 到底喂进去多少局」的**实测值** —— 此前引擎算完即弃,运维改完窗口没有
        # 任何一处能确认它真的生效(config_center 与 predictor_bridge 的两处护栏
        # 都只是**按公式预言**,不是测量)。老 detail 无此键 → 恒 None,前端隐藏。
        _tn = (detail or {}).get("train_n")
        out["trainN"] = int(_tn) if isinstance(_tn, (int, float)) else None
    recs = await ST.db.prediction_records(room, 40)
    # s = 溯源('replay' = 事后补算);前端据此让「上局开X」徽标只认实盘判定
    out["record"] = [{"id": str(r["round_id"]), "n": r["actual_custom_id"],
                      "v": r["hit"], "s": r.get("source") or ""} for r in recs]
    window = int((settings.prediction or {}).get("accuracy_window", 100))
    out["accuracy"] = await ST.db.accuracy(room, window)
    return out


def _snap_int(snap: Dict[str, str], key: str) -> int:
    try:
        return int(snap.get(key) or 0)
    except (TypeError, ValueError):
        return 0


def _split_rooms(text: str) -> List[str]:
    """把逗号/换行/空格/分号分隔的房号串拆成列表(批量添加输入解析用)。"""
    import re as _re
    return [t for t in _re.split(r"[\s,;]+", str(text or "").strip()) if t]


async def _rooms_reply(request: Request) -> List[dict]:
    """monitor add/remove 的响应名录:登录用户回**其账号名录**(alias 口径),
    未启用登录/运维旁路回全局可见名录(旧口径)。"""
    u = _req_user(request)
    if userauth.enabled() and u is not None:
        return [str(b.get("alias") or b["room_id"])
                for b in await ST.db.user_rooms_list(u.user_id)]
    return await _visible_rooms()


# ── 路由 ─────────────────────────────────────────────────────────────────────
@app.get("/api/live-rooms")
async def live_rooms(request: Request = None):
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny                              # 4.2.0:free 档零数据
    return await _build_live_rooms(user=_req_user(request))


def _monitor_token_guard(request: Request) -> Optional[JSONResponse]:
    """可选加固(方案 §5.2):设置 STA_MONITOR_WRITE_TOKEN 后,名录写接口要求
    X-Monitor-Token 头匹配。**默认未设 = 行为不变**(观测台前端零改动兼容);
    管理台前端会自动携带该头(登录后由管理面的 session 接口附带下发)。"""
    tok = (os.environ.get("STA_MONITOR_WRITE_TOKEN") or "").strip()
    if not tok:
        return None
    if userauth.enabled() and _req_user(request) is not None:
        return None   # 3.8.0:登录用户的名录写已按账号鉴权,不再叠加运维令牌
    if request.headers.get("x-monitor-token", "") != tok:
        return JSONResponse({"ok": False, "error": "monitor_token_required",
                             "hint": "本部署已启用名录写保护,需携带 X-Monitor-Token 头"},
                            status_code=401)
    return None


async def _verify_admit(rid: str, *, timeout: Optional[float] = None,
                        subject: str = "add") -> Optional[JSONResponse]:
    """核验准入(5.0.7):后台没有该房开播记录时的第二条通道。

    放行返回 None;拒绝返回 JSONResponse。三种拒法各说各的真话:
      · not_recent_live   —— 核验通道关闭时的旧口径(逐字节向后兼容)
      · not_live_now      —— roomStatus 确证此刻未开播
      · live_unverifiable —— 上游问不到 / 该房号无主播绑定,**不改判为未开播**

    放行时同时:① 记入 PG 核验台账(grace 内再次添加免核验、worker 据此复核);
    ② 把 rooms:livestatus 置 1 —— 刚核验过的事实与探测循环同源同格式,名录绿点
    秒亮,不必等下一轮探测。两者皆失败不阻断准入(核验事实已成立)。
    """
    cfg = settings.discovery
    if not getattr(cfg, "verify_enabled", True):
        return JSONResponse(
            {"ok": False, "error": "not_recent_live",
             "message": "只允许添加近期直播过的直播间"}, status_code=400)
    _tail = ("请在主播开播时再添加" if subject == "add"
             else "请等主播开播后再进来")
    grace_ms = int(cfg.prune_grace_s) * 1000 if int(cfg.prune_grace_s) > 0 else None
    nowv = int(time.time() * 1000)
    try:
        seen = await ST.db.verified_last_live(rid)
    except Exception:
        seen = None
    if seen is not None and (grace_ms is None or seen >= nowv - grace_ms):
        return None
    try:
        st = await asyncio.wait_for(
            ST.star.live_status(rid),
            timeout=max(1.0, float(timeout if timeout is not None
                                   else settings.livestatus.request_timeout)))
    except Exception:
        st = None
    if st is None:
        # 真机复核(2026-09-06,打 service1.fanxing.kugou.com/roomcen/room/web/roomStatus)
        # 暴露的口径缺口:上游对**根本不存在的房号**也回 code=0 / liveStatus=-1 /
        # kugouId 缺省 —— 与「网络问不到」在 live_status 那一层被压成了同一个 None。
        #   room=999999999 → code=0 liveStatus=-1 kugouId=None  ← 号不存在
        #   room=321       → code=0 liveStatus=-1 kugouId=None  ← 频道房短号(真号 2678075)
        # 于是用户敲错一个房号,只会得到「暂时核实不了,请稍后再试」,然后无限重试。
        # 归一之后这两者是分得开的:真号带得出主播资料(321→2678075 有昵称与
        # kugouId),而不存在的号资料全空。资料全空 = **终态**,照实说查不到;
        # 其余仍按瞬态处置。profile 走 canon 已填的跨进程缓存,常态零额外请求。
        _blank = False
        with contextlib.suppress(Exception):
            _p = await ST.star.profile(rid)
            _blank = not (_p.get("nickname") or _p.get("avatar")
                          or int(_p.get("kugouId") or 0))
        if _blank:
            return JSONResponse(
                {"ok": False, "error": "room_unresolved",
                 "message": "查不到这个直播间 —— 请核对房号后重试"}, status_code=400)
        return JSONResponse(
            {"ok": False, "error": "live_unverifiable",
             "message": "暂时核实不了这个直播间的状态,请稍后再试"}, status_code=400)
    if st != 1:
        return JSONResponse(
            {"ok": False, "error": "not_live_now",
             "message": "这个直播间当前未开播 —— 后台也没有它的开播记录,"
                        + _tail}, status_code=400)
    with contextlib.suppress(Exception):
        await ST.db.verified_upsert(rid, nowv)
    with contextlib.suppress(Exception):
        await ST.bus.livestatus_set_bulk([(rid, 1)], ts=nowv)
    return None


@app.api_route("/api/monitor/add", methods=["GET", "POST"])
async def monitor_add(request: Request, room: str = Query("")):
    # 4.2.0:free 档不能改名录(它连数据都看不到)。运维旁路(admin/token)
    # 走 _tier→"vip" 分支,零影响。
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny
    if (deny := _monitor_token_guard(request)) is not None:
        return deny
    room = str(room).strip()
    if not room.isdigit() or len(room) < 2 or len(room) > 12:
        return JSONResponse(
            {"ok": False, "error": "bad_room",
             "message": "房号需为 2–12 位纯数字"}, status_code=400)
    _u = _req_user(request)
    rid, definitive = await ST.star.canon(room)
    # 准入限制:只允许添加**后台已存在**的房 —— 即近期(7 天回收窗口内)出现在
    # 繁星在播列表而被自动发现纳入后台的房,或已在名录的策展房。目的:用户添加的
    # 房必然「近期直播过」,不会加进一个从未开播/早已停播的死房占用抓取与展示。
    # 归一失败(繁星暂不可用/号不存在)视同无法核验,一并即时拒绝 —— 用户路径
    # 不再进挂起集;挂起机制保留给 config 注入 / seed_rooms 运维路径(由 janitor
    # 收敛,那里是运营者显式指定,信任级别不同,如需求固定房 321)。
    # 5.0.7:在播列表是**推荐流** —— 频道房(roomType=3)从不上榜、低流量房常年
    # 不上榜,这类房后台永远没有开播记录,旧实现对它们是一堵没有门的墙。现补一条
    # 核验通道(discovery.verify_enabled):后台不存在时先查核验台账(grace 内免核验),
    # 再打 roomStatus 定谳 —— 此刻在播即放行并记入台账,未开播/问不到分别明示,
    # 绝不把「问不到」说成「没开播」(与 livestatus 同一条戒律)。
    known = definitive and rid in set(await ST.bus.active_rooms())
    if not known:
        if not definitive:
            return JSONResponse(
                {"ok": False, "error": "room_unresolved",
                 "message": "查不到这个房间号 —— 请核对后重试"}, status_code=400)
        deny = await _verify_admit(rid)
        if deny is not None:
            return deny
    # 登录系统(3.8.0):按账号名额上限(与前端 MAX_ROOMS 同值,后端硬闸)。
    # 已在本账号名录的房是「切房」不是「新增」,不占名额、直接放行到绑定刷新。
    # 复查修复:①放在 canon/known **之后** —— 「号不存在/未近期开播」比「名录满」
    # 更根本,错误优先级应前者先报;②已绑判定以 (rid, room) **双键**查 —— 此前传
    # ("", room) 只能命中「存的 room_id/alias 恰等于本次输入」,若用户当初用真实号
    # 入库、满额后改用短号切回同一房,alias 分支匹配不到会被 rooms_full 误拒。
    if userauth.enabled() and _u is not None:
        try:
            _already = await ST.db.user_room_allowed(_u.user_id, rid, room)
            if not _already and await ST.db.user_rooms_count(_u.user_id) \
                    >= int(settings.userauth.room_max):
                return JSONResponse(
                    {"ok": False, "error": "rooms_full",
                     "message": f"名录已满(上限 {settings.userauth.room_max} 个直播间)"
                                f"—— 请先删除不再关注的直播间"}, status_code=400)
        except Exception:
            pass
    # 溯源(须在 discovered_remove **之前**取样):本次添加若把「自动发现房」转正,
    # 记入 user_added_rooms —— 将来该房绑定数归零时,全局监控随之退场(回到发现
    # 生命周期);登录系统启用前就存在的策展房 / config 房不在此列,任何用户删不动。
    # 5.0.7:核验准入的房同样打标 —— 它压根不在发现集里,不打标就永远撤不下来,
    # 用户删掉最后一份绑定后仍被全局抓取,是只进不出的泄漏。
    _was_discovered = False
    if userauth.enabled() and _u is not None:
        with contextlib.suppress(Exception):
            _was_discovered = (not known) or rid in set(await ST.bus.discovered_members())
    await ST.bus.pending_remove(room)          # 若此前挂起,先转正
    await ST.bus.add_room(rid, room)
    # 若此前被自动发现,转正为策展房(前端可见):清 Redis 发现集 + PG 时钟残行
    await ST.bus.discovered_remove(rid)
    with contextlib.suppress(Exception):
        await ST.db.discovered_delete_bulk([rid])
    await ST.db.upsert_room(rid, room, True)
    with contextlib.suppress(Exception):
        # 4.6.0:清掉该房的补算冷却闸 —— 再添加一个曾探查过的房 = 人类意图
        # 「现在要看它的命中率」,不该让他等满一个 replay_cooldown_s。
        # 新房本就没有闸,此调用幂等无害;失败也只是晚一个周期补算。
        await ST.bus.replay_gate_clear(rid)
        # 4.9.3:并入唤醒快道 —— worker 逐秒排水,曾监控过的房数秒内即补满
        # 「近N局」,不必等 ≤60s 的巡检。全新房数据未播种(anchor 尚空)时,
        # 排水侧会**轻探不耗闸**地放行,不会把冷却闸空耗在没数据的房上
        # (见 worker._replay_wake_drain 的纪律注释)。
        await ST.bus.replay_wake_push(rid)
    if rid != room:
        # 此前以短号挂起过的,短号行的 pending 一并清净,
        # 否则重启回灌会把它再灌回挂起集(转正/挂起双影)。
        await ST.db.upsert_room(room, room, False, pending=False)
    _hm = settings.histmode
    if _hm.enabled and getattr(_hm, "curated_idle_enabled", False):
        with contextlib.suppress(Exception):
            # curated-idle(3.7.0):再添加既有冷策展房 = 人类意图「现在要监控」——
            # 冷标当场清 + 访问戳 GT 置新(给足 idle_after 宽限),否则下方 mp@now
            # 会被迁移入口按冷房改排回轮询,违背本端点「秒级起抓」的书面契约
            # (复审 G1;非冷/新房两调皆无害幂等)。双开关门:禁用态本端点零新增
            # 命令(逐字节旧行为);关断期残留冷标对闸惰性,若日后重开而标仍在,
            # 任一次读钩子 ≤20s 自愈唤醒 —— 不必在此为关断态付常驻成本。
            await ST.bus.touch_rooms([rid], int(time.time() * 1000))
            await ST.bus.cold_clear(rid)
    # 秒级起抓:排一个即时 MainPage 任务(worker 的 janitor 也会兜底)
    from .redis_bus import task_hist, task_mainpage
    await ST.bus.schedule(task_mainpage(rid), int(time.time() * 1000))
    if settings.histmode.enabled:
        # hist-mode 转正封尾窗(3.5.0):同时排一个 hs@now —— worker 的模式退出
        # 分支会在改排 mp **之前**先做一次过闸(hist_gate 5s 幂等去重)的收尾
        # 回填,把「上次轮询→此刻」尾窗(≤interval_s 的最近局)当场补齐:添加后
        # 序列首屏即到最新,预测号也随补链立即生成(零冷启动等待)。该房既有的
        # 稳态 hs 任务稍后到期撞同一分支自灭,不留双影。
        with contextlib.suppress(Exception):
            await ST.bus.schedule(task_hist(rid), int(time.time() * 1000))
    target = rid
    # 登录系统(3.8.0):落按账号绑定(幂等;alias=用户输入号)。全局注册在上方
    # 已完成 —— 多账号绑同一房共享同一份抓取,绑定只是**可见性**归属。
    if userauth.enabled() and _u is not None:
        try:
            await ST.db.user_room_bind(_u.user_id, rid, room)
            if _was_discovered:
                await ST.db.user_added_mark(rid, _u.user_id)
        except Exception as e:
            return JSONResponse({"ok": False, "error": "bind_failed",
                                 "message": f"名录写入失败,请稍后重试({e!r})"},
                                status_code=500)
    elif userauth.enabled():
        # 复查修复:运维旁路的**显式添加** = 全局钉住 —— 若该房此前是某用户把
        # 发现房转正的(带溯源标),清标;否则该用户解绑归零时会连运维刚刚宣示的
        # 全局监控一并撤下。未启用登录时表无人写,unmark 幂等无害。
        with contextlib.suppress(Exception):
            await ST.db.user_added_unmark(rid)
    if userauth.enabled() and _u is not None:
        rooms = await _rooms_reply(request)     # 登录用户:回其账号名录(alias 口径)
    else:
        rooms = await _visible_rooms()   # 旁路/未启用:响应名录与前端展示口径一致(不含发现房)
    return {"ok": True, "room": room, "resolvedRoomId": target, "rooms": rooms}


@app.post("/api/monitor/add-bulk")
async def monitor_add_bulk(request: Request):
    """批量添加直播间(「同时添加数千房」的安全入口)。

    请求体接受三种形态(任一):
      · {"rooms": ["321", "2678075", ...]}
      · {"rooms": "321,2678075"}(逗号/换行/空格分隔)
      · 纯文本 body:逗号/换行/空格分隔的房号

    经准入控制器:去重 → 有界并发归一(过繁星令牌桶,不惊群)→ 批量落库/登记 →
    首抓错峰铺开(消除重排风暴)。归一失败的房进挂起集,由 worker janitor 自动收敛。
    与单房 /api/monitor/add 语义一致,只是把 N 房合成一次受控操作。
    """
    if (deny := _monitor_token_guard(request)) is not None:
        return deny
    # 登录系统(3.8.0):批量注入是**运维通道**(数千房准入,绕过按账号名额),
    # 启用后仅接受管理台会话 / X-Monitor-Token 旁路;普通登录用户请走单房添加。
    if userauth.enabled() and _req_user(request) is not None:
        return JSONResponse(
            {"ok": False, "error": "admin_required",
             "message": "批量添加为运维功能,请使用管理台;名录添加请走「＋ 添加直播间」"},
            status_code=403)
    rooms: List[str] = []
    try:
        body = await request.body()
        raw = body.decode("utf-8", "ignore").strip() if body else ""
    except Exception:
        raw = ""
    parsed_json = None
    if raw:
        try:
            parsed_json = json.loads(raw)
        except ValueError:
            parsed_json = None
    if isinstance(parsed_json, dict):
        val = parsed_json.get("rooms", [])
        if isinstance(val, str):
            rooms = _split_rooms(val)
        elif isinstance(val, list):
            rooms = [str(x) for x in val]
    elif isinstance(parsed_json, list):
        rooms = [str(x) for x in parsed_json]
    elif raw:
        rooms = _split_rooms(raw)

    if not rooms:
        return JSONResponse(
            {"ok": False, "error": "no_rooms",
             "message": "未解析到任何房号(以逗号 / 空格 / 换行分隔)"},
            status_code=400)

    result = await admit_rooms(rooms, bus=ST.bus, db=ST.db, star=ST.star,
                               cfg=settings.admission, do_canon=True,
                               aliases=settings.room_aliases)
    # 转正:批量添加的房若此前被自动发现,移出发现集(归策展列表,前端可见)。
    with contextlib.suppress(Exception):
        _added = result.get("added_rooms", [])
        await ST.bus.discovered_remove_bulk(_added)
        await ST.db.discovered_delete_bulk(_added)   # PG 时钟残行一并清(防回灌复活)
        # curated-idle(3.7.0):批量再添加同为「现在要监控」的人类意图 —— 既有
        # 冷房清标 + 访问戳 GT 置新,否则 admit_rooms 排的 warmup mp 会被迁移
        # 入口改排回轮询(复审 G1)。清标后,下方既有的 hs 铺开恰好兼任唤醒
        # 序列的封尾腿(退出分支收尾回填 → 改排 mp),零新增任务。双开关门:
        # 禁用态零新增命令;关断期残留标由读钩子自愈(单房 add 同款说明)。
        _hm = settings.histmode
        if _hm.enabled and getattr(_hm, "curated_idle_enabled", False):
            await ST.bus.touch_rooms(_added, int(time.time() * 1000))
            await ST.bus.cold_clear_bulk(_added)
        if settings.histmode.enabled and _added:
            # hist-mode 转正封尾(3.5.0):批量同样秒级 —— hs 任务小窗铺开触发
            # 退出分支收尾回填(封尾键=快照 histLastOkMs:轮询过的房恰一次,
            # 从未轮询过的房自跳)。默认 T=900 后,不补这一发的有机封尾要等
            # ≤T+10%(≈16.5 分钟),对"刚添加就想看"的运维批量不可接受。
            from .redis_bus import task_hist
            await ST.bus.schedule_spread(
                [task_hist(r) for r in _added],
                int(time.time() * 1000), max(2000, 80 * len(_added)))
    result["activeCount"] = len(await _visible_rooms())   # 前端口径:不含发现房
    return result


@app.api_route("/api/monitor/remove", methods=["GET", "POST"])
async def monitor_remove(request: Request, room: str = Query("")):
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny
    if (deny := _monitor_token_guard(request)) is not None:
        return deny
    room = str(room).strip()
    if not room.isdigit() or len(room) < 2 or len(room) > 12:
        return JSONResponse(
            {"ok": False, "error": "bad_room",
             "message": "房号需为 2–12 位纯数字"}, status_code=400)
    rid, definitive = await ST.star.canon(room)
    target = rid if definitive else room
    # 登录系统(3.8.0):登录用户的「删除」= 解绑自己名录(他人名录/全局数据无损)。
    # 仅当①该房是登录用户把发现房转正的(user_added_rooms 有案)、②绑定数归零、
    # ③且不是 config 声明的常驻房 —— 三条同时成立才顺带撤全局监控(落回自动发现
    # 生命周期);否则直接按账号名录返回。运维旁路/未启用登录:维持旧全局删除。
    _u = _req_user(request)
    if userauth.enabled() and _u is not None:
        await ST.db.user_room_unbind(_u.user_id, target, room)
        _refs = await ST.db.user_room_refcount(target)
        _user_added = await ST.db.user_added_check(target)
        _is_config = str(target) in {str(r) for r in (settings.rooms or [])} \
            or str(room) in {str(r) for r in (settings.rooms or [])}
        if not (_refs == 0 and _user_added and not _is_config):
            rooms = await _rooms_reply(request)
            return {"ok": True, "room": room, "resolvedRoomId": target, "rooms": rooms}
        await ST.db.user_added_unmark(target)   # 引用归零:随下方旧逻辑撤全局监控
    await ST.bus.remove_room(target)   # 内部含 pending 清理
    if target != room:
        await ST.bus.remove_room(room)  # 原号也清一遍,兼容未归一先添加的历史数据
    # 发现态一并清净(Redis 发现集 + PG last_seen 时钟):防止早年被自动发现、后转正、
    # 现被移除的房,残留的 PG 时钟在下次 worker 回灌时把它当发现房"复活"回后台。
    # (若该房仍真实在播,下一轮遍历自会重新发现 —— 那是新一次发现,非幽灵复活。)
    with contextlib.suppress(Exception):
        await ST.bus.discovered_remove_bulk([target, room])
        await ST.db.discovered_delete_bulk([target, room])
    # 5.0.7:核验台账同步清净。台账是「后台还认这房近期开过播」的凭据,运维/用户
    # 显式撤下监控后再留着它,等于让被撤的房绕过准入原地复活。若该主播仍在播,
    # 下次添加照常经 roomStatus 核验通过 —— 那是新一次核验,不是幽灵复活。
    with contextlib.suppress(Exception):
        await ST.db.verified_delete_bulk([target, room])
    await ST.db.upsert_room(target, room, False, pending=False)
    if target != room:
        await ST.db.upsert_room(room, room, False, pending=False)
    if userauth.enabled():
        # 复查修复:全局删除(运维旁路,或用户触发的三条件收敛)级联清**所有账号**
        # 对该房的绑定与转正溯源 —— 语义收敛为「全局没了 = 各家名录同步消失」,
        # 不留指向已停监控房的僵尸条目(其明细端点会因绑定尚存而放行读到死数据)。
        with contextlib.suppress(Exception):
            await ST.db.user_rooms_unbind_all(target, room)
            await ST.db.user_added_unmark(target)
    if userauth.enabled() and _u is not None:
        rooms = await _rooms_reply(request)     # 登录用户:回其账号名录(alias 口径)
    else:
        rooms = await _visible_rooms()   # 响应名录与前端展示口径一致(不含发现房)
    return {"ok": True, "room": room, "resolvedRoomId": target, "rooms": rooms}


@app.get("/api/rooms")
async def rooms_list(request: Request = None):
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny
    _u = _req_user(request)
    if userauth.enabled() and _u is not None:
        binds = await ST.db.user_rooms_list(_u.user_id)   # 3.8.0:按登录账号隔离
        rows = [{"room_id": str(b["room_id"]),
                 "alias": str(b.get("alias") or b["room_id"]),
                 "nickname": await _room_nick(str(b.get("alias") or b["room_id"]))}
                for b in binds]
        return {"ok": True, "rooms": rows}
    active = await _visible_rooms()   # 前端名录:不含自动发现房

    async def _row(r: str) -> dict:
        alias = await ST.bus.alias_of(r)
        return {"room_id": r, "alias": alias, "nickname": await _room_nick(alias)}

    # 与 _build_live_rooms 同款并发闸(复审补漏:上一轮只钳了 live-rooms,漏了这里)。
    # 每房 alias_of + profile 至少两次 Redis,N 房无上限 gather 同样能把池抽干。
    _sem = _live_rooms_sem()

    async def _gated(coro):
        async with _sem:
            return await coro

    rooms = list(await asyncio.gather(*[_gated(_row(r)) for r in active]))
    return {"ok": True, "rooms": rooms}


SWITCH_PROBE_COOLDOWN_S = 120
# 同房核验探测冷却(秒)。切房路径**会自动重复**:前端每 30s 用后端名录整体替换
# S.rooms,随后 mergeMyRooms 把 localStorage 里不在后端名录的房重新并回来,于是
# 同一个房每 30s 再发一次 profile?switch=1。探测成功的房当场自愈进名录、下一拍
# 即短路;探测失败的房不会 —— 而失败的主因常常是上游本身不好,等于在最脆弱的
# 时候按 30s×标签页数 的节奏持续加压。取 120s:比前端 30s 节拍长 4 倍,足够把
# 重复压平;又远短于用户"等一会儿再试"的心理尺度。
SWITCH_WAIT_ROUNDS, SWITCH_WAIT_STEP_S = 6, 0.2
# 输掉同房闸之后等赢家的时长:6 × 200ms = 1.2s。上界刻意小 —— 上游真出问题时
# 这 1.2s 是纯等待,而它只发生在「本就要失败」的那条路上;够不够等到赢家自愈,
# 由 rooms:active 说了算,不靠猜。
SWITCH_PROBE_TIMEOUT_S = 5.0
# 切房探测预算(秒),刻意**短于**添加路径的 livestatus.request_timeout(默认 8s)。
# 添加是一次深思熟虑的动作,等几秒天经地义;切房是高频动作,前端 loadRoom 把
# profile 与 config/history 一起塞进 Promise.all,任何一路超时都会让整次切房落进
# 退避重试。取 5s:够一次 roomStatus 往返(实测 350–800ms)留足七倍余量,又不会
# 把切房拖到前端超时线以外。


async def _switch_probe_gate(rid: str) -> bool:
    """抢同房核验闸。闸自己坏了不该挡住正常核验 —— 异常一律当抢到。"""
    try:
        return await ST.bus.verify_probe_gate(rid, SWITCH_PROBE_COOLDOWN_S)
    except Exception:
        return True


async def _selfheal_register(rid: str, alias: str) -> None:
    """把「核验确认在播、却不在后台名录」的房重新登记进来(切房自愈)。

    为什么必须登记而不能只是放行:放行只是不删这张卡,而后台没在抓它 ——
    用户进去看到的仍是一间永远空着的房。核验既然已经确认主播此刻在播,
    正确的收尾就是把抓取拉起来,让他真的看得到数据。

    逐行对齐 monitor_add 的登记序(幂等),但**刻意少做两件事**:
      · 不打 user_added_rooms 溯源标 —— 自愈是「把丢掉的东西放回去」,不是
        「创造一份新的归属」。原房若本就是运维钉住的(无标),补一个标会让它
        变成可被用户删空撤下的房,擅自改写了运维意图;原房若本有标而标也丢了,
        我们无从分辨,那就不猜。
      · 不碰名额上限 —— 调用方已确认该房本就在此人名录里(见 _switch_admit),
        名额在当初添加时就扣过了,这里再扣一次是重复计费。
    """
    from .redis_bus import task_hist, task_mainpage
    nowv = int(time.time() * 1000)
    await ST.bus.pending_remove(alias)
    await ST.bus.add_room(rid, alias)
    await ST.bus.discovered_remove(rid)
    with contextlib.suppress(Exception):
        await ST.db.discovered_delete_bulk([rid])
    await ST.db.upsert_room(rid, alias, True)
    if rid != alias:
        await ST.db.upsert_room(alias, alias, False, pending=False)
    with contextlib.suppress(Exception):
        await ST.bus.replay_gate_clear(rid)
        await ST.bus.replay_wake_push(rid)
    _hm = settings.histmode
    if _hm.enabled and getattr(_hm, "curated_idle_enabled", False):
        with contextlib.suppress(Exception):
            await ST.bus.touch_rooms([rid], nowv)
            await ST.bus.cold_clear(rid)
    await ST.bus.schedule(task_mainpage(rid), nowv)
    if _hm.enabled:
        with contextlib.suppress(Exception):
            await ST.bus.schedule(task_hist(rid), nowv)


async def _switch_admit(room: str, rid: str,
                        request: Request = None) -> Optional[JSONResponse]:
    """切房准入(5.0.7):与添加**同一条阶梯**——后台有记录直接放行;没有则先查
    核验台账(grace 内零请求),再打一次 roomStatus 定谳。

    为什么切房也要走这条阶梯:名录与后台注册表会分叉,而分叉后前端只会画一个
    **永远没有数据的空房**、不给任何解释。两条已核实的分叉路径:
      · 未启用登录时,前端 `mergeMyRooms()` 把 localStorage 里的房**无条件**并进
        名录(app.js `upsertCustomRoom`),从不与后端对账 —— 换设备/换部署/房被
        运维撤下之后,那条记录会一直留在轨道上;
      · 启用登录时,`/api/live-rooms` 直接回 `user_rooms` 绑定,同样不校验全局
        注册表。`monitor_remove` 里级联清绑定的那步裹在 suppress 里,PG 抖一下
        就会留下「绑定还在、监控没了」的永久残影(此后无任何代码路径会收敛它)。

    阶梯的价值在于**能救就救**:主播此刻确实在播,就把抓取拉起来让人看(自愈
    登记),而不是甩一句「请重新添加」把用户赶去重走一遍流程;确实不在播、或
    上游问不到,才回 400 让前端把这张死卡清掉。

    四条纪律:
      ① 命中即止。在册房只花一次 SISMEMBER(O(1)),不查台账、不打上游、不写库
         —— 切房是高频读路径,稳态下必须零额外开销。
      ② 挂起房放行。归一暂时失败的房不在 rooms:active,但前端名录里**是有卡的**
         (_build_live_rooms 给它画 pending 卡);不放行就会把「正在等归一」误杀
         成「已不监控」,用户看到自己刚添加的房凭空消失。输入号与归一号双键查。
      ③ 空名录与异常一律放行。web 的 PG→Redis 回灌裹在 except:pass 里,PG 启动
         瞬断 + Redis 空(compose 关持久化)时 rooms:active 会是空集;此刻判否的
         后果不是拒绝一次请求,而是前端把用户名录里的房**逐个删掉** —— 一次基础
         设施抖动换一片不可逆的数据丢失。故先 SCARD 确认名录本身就绪。
      ④ 无资格者**在打上游之前**就放行。自愈是一次名录写,要受名录写的全部
         保护(写令牌 + 登录态归属);而既然救不了这个房,探测就毫无意义 ——
         先判资格再核验,才不会让一个未授权的 GET 既放大上游请求、又往台账里
         塞垃圾行(worker 此后每天还要为它们各探一次)。放行后交给下游各自的
         闸去说话(登录态是 _user_room_deny 的 room_not_bound)。
    """
    try:
        if await ST.bus.is_active(rid):
            return None                                   # ①
        if await ST.bus.is_pending(str(room)) or (         # ②
                str(rid) != str(room) and await ST.bus.is_pending(str(rid))):
            return None
        if await ST.bus.active_count() <= 0:               # ③
            return None
    except Exception:
        return None                                       # ③
    # ④ 资格判定必须在**打上游之前**。复查时把顺序调过来的:原先是先核验、
    #    后判资格,于是没资格的调用方虽然登记不成,却已经先让后端打了一次
    #    roomStatus、并往 verified_rooms 落了一行 —— 一个未授权的 GET 就能既
    #    放大上游请求、又把台账撑大(worker 此后每天还要为这些垃圾行各探一次)。
    #    既然救不了这个房,探测就毫无意义:直接放行,交给下游各自的闸去说话
    #    (登录态是 _user_room_deny 的 room_not_bound;运维锁态是名录本就归运维管)。
    if not await _selfheal_allowed(request, room, rid):
        return None
    if not getattr(settings.discovery, "verify_enabled", True):
        return JSONResponse(
            {"ok": False, "error": "room_not_monitored", "room": str(room),
             "message": "该直播间已不在后台监控中 —— 请重新添加"}, status_code=400)
    # ⑤ 只给**将要打上游**的这一段限流。放在 ①②③ 之后是刻意的:名录卡在启动时
    #    会并发拉 N 张 profile,若把闸设在入口,10 房的名录一开机就先吃两发 429。
    #    走到这里说明本次注定要查库+打一次 roomStatus —— 那才是值得计费的动作。
    #    429 对前端是**瞬态**(api() 归入可重试类),卡不会被清掉。
    if (deny := await _detail_rate_guard(request)) is not None:
        return deny
    # ⑥ 同房只准一路去打上游;**输的那路等赢家的结论,而不是各自报错**。
    #    真机实测(12 路并发切同一个房)才暴露出来的:冷却闸把上游探测正确地钳到
    #    了 1 次,但另外 11 路当场吃 400。而这个并发不是假想 —— 页面启动时
    #    mergeMyRooms→upsertCustomRoom 与 loadRoom 会为同一个房**各发一次**
    #    profile?switch=1,多标签页更是叠乘。赢家通常在数百毫秒内就自愈完成,
    #    于是输家只要盯着 rooms:active 轮询一小会儿就能拿到正确结果;等不到才
    #    按「这一拍问不到」回话(绝不改判成未开播)。
    if not await _switch_probe_gate(rid):
        for _ in range(SWITCH_WAIT_ROUNDS):
            await asyncio.sleep(SWITCH_WAIT_STEP_S)
            with contextlib.suppress(Exception):
                if await ST.bus.is_active(rid):
                    return None
        return JSONResponse(
            {"ok": False, "error": "live_unverifiable",
             "message": "暂时核实不了这个直播间的状态,请稍后再试"}, status_code=400)
    deny = await _verify_admit(rid, timeout=SWITCH_PROBE_TIMEOUT_S,
                               subject="switch")
    if deny is not None:
        return deny
    with contextlib.suppress(Exception):
        await _selfheal_register(rid, str(room))
    return None


async def _selfheal_allowed(request: Request, room: str, rid: str) -> bool:
    """自愈登记的资格判定。**自愈是一次名录写**,所以它必须受名录写的全部保护。

    ① 名录写令牌(STA_MONITOR_WRITE_TOKEN)。这一条是复查时补的:令牌本是给
       add/remove 三个端点上的锁,而自愈把「登记一个房」这件事挪到了一个 GET
       上 —— 不复用同一把锁,任何人 `GET /api/live-rooms/<任意号>/profile?switch=1`
       就能让开着保护的部署凭空开抓一间房,等于给写保护开了后门。
    ② 启用登录时必须是**该账号名录里的房**,否则谁都能让后台开抓一间无主房:
       不占谁的名额、也没有溯源标,永远不会被回收。
    PG 异常时保守回 False —— 拿不准就别替人开抓。"""
    try:
        if _monitor_token_guard(request) is not None:
            return False
    except Exception:
        return False
    if not userauth.enabled():
        return True
    u = _req_user(request)
    if u is None:
        return True          # 运维旁路(admin/monitor-token):与 monitor_add 同姿态
    try:
        return bool(await ST.db.user_room_allowed(u.user_id, str(rid), str(room)))
    except Exception:
        return False


@app.get("/api/live-rooms/{room}/profile")
async def live_room_profile(room: str, request: Request = None,
                            switch: str = Query("")):
    """房间资料。`switch=1` 时**附带切房准入判定**(见 _switch_admit)。

    刻意做成显式开关而非默认行为:本端点还服务「添加前的房号预检」
    (app.js submitAddRoom),那一刻房本来就还没进后台 —— 默认拦截会把
    5.0.7 刚打通的核验准入通道当场堵死。前端只在**切房**与**名录并卡**
    两处带这个参数。
    """
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny
    if str(switch).strip() not in ("", "0"):
        rid, _definitive = await ST.star.canon(room)
        if (deny := await _switch_admit(room, rid, request)) is not None:
            return deny
    return await _build_profile(room)


# 冻结窗判定余量(3.6.0 按日回看):历史时段可获得新行的唯一通道是 GameHistory
# 回填,其页窗仅近 HIST_PAGE_ROUNDS=30 局 ≈ 25 分钟(constants 注:超出页窗
# 「数学上不可达」,/coverage 的 official_missing 语义同源)。取 1h = 2.4× 余量:
# ── curated-idle(3.7.0):用户侧访问信号 + 冷房瞬时唤醒 ────────────────────────
# 进程内 5s 节流台账(仅性能;正确性不依赖它 —— ZADD GT 本就幂等只进不退)。
_TOUCH_AT: Dict[str, float] = {}


async def _touch_room(rid: str) -> None:
    """记录一次**用户侧真实访问**并当场唤醒冷房(curated-idle,3.7.0)。

    读路径钩子统一入口:history[非 passive]/days/prediction/summary/coverage/
    SSE 连接与 20s 心跳。**不接**资料(profile)与列表端点 —— 前端启动期会为
    名录逐房回填头像(upsertCustomRoom/mergeMyRooms 实证),计入则永远无房可
    判闲;跨房补拉沿用既有 passive=1 约定豁免(app.js jfFetchCross「只读不拉起
    监控」)。稳态成本:双开关关闭时纯属性读、零 Redis(契约⑪ 姿态);开启时
    5s 节流 → ≤1 次 pipeline(ZADD GT + HGET cold)/5s/房。

    命中冷标即当场晋升 = monitor/add 转正同款序列:mp@now(秒级回实时)→
    清冷标 → hs@now(退出分支先**封尾回填**再改排 —— 把降级期间的尾窗当场补
    齐,预测号随补链立即再生,零冷启动)→ 清补算冷却闸 + 入唤醒快道(4.9.3,
    兑现 config_registry 的既有承诺;推演卡「近N局」由 worker 快道数秒内补满,
    不再撞残留冷却闸等 1h)。全程 suppress:唤醒失败不阻塞读,
    且可自愈 —— 节流窗过后任何一次访问重试;任务丢失有 janitor 缺任务自愈。
    观测:histmode_stats.cold_promote 计唤醒;冷龄 <120s 即醒再计
    cold_false_wake(疑似误降,阈值调参信号)。"""
    hm = settings.histmode
    if not (hm.enabled and getattr(hm, "curated_idle_enabled", False)):
        return
    rid = str(rid)
    if not rid.isdigit():
        return
    nowf = time.time()
    if nowf - _TOUCH_AT.get(rid, 0.0) < 5.0:
        return
    if len(_TOUCH_AT) > 4096:              # 防御:异常多房时防台账无界增长
        _TOUCH_AT.clear()
    _TOUCH_AT[rid] = nowf
    with contextlib.suppress(Exception):
        nowm = int(nowf * 1000)
        since = await ST.bus.touch_and_check_cold(rid, nowm)
        if since is None:
            return
        from .redis_bus import task_hist, task_mainpage
        await ST.bus.schedule(task_mainpage(rid), nowm)      # ① 秒级回实时
        cleared = await ST.bus.cold_clear(rid)               # ② 清标(原子 HGET+HDEL)
        with contextlib.suppress(Exception):
            await ST.bus.schedule(task_hist(rid), nowm)      # ③ 封尾窗(退出分支)
        with contextlib.suppress(Exception):
            # ④ 4.9.3:清补算冷却闸 + 入唤醒快道。config_registry 对
            # replay_cooldown_s 的承诺自 4.6.0 起就是「转正/**唤醒**会当场清掉
            # 该房的冷却」,但唤醒路径此前从未兑现 —— 冷却闸残留时,推演卡的
            # 「近N局」在整段观看期都停在缺口值,补算要等最长 1h 后的巡检才补
            # (缺陷 D2;生命周期仿真实证:访问间隔 60/68/77 分钟的房,每次打开
            # 恒见 65/55/44,连续十几次分毫不变 —— 正是工单「一直显示近44局」)。
            # 清闸使下一轮巡检(≤60s)必然探到;入快道使 worker 的逐秒排水
            # (_replay_wake_drain)数秒内即补满(节拍 ≤1s + 单房 ≈2.4s)。
            # 两者独立成功即可各自生效;
            # 均幂等,多副本并发首触无害(与上面任务同名幂等同理)。
            await ST.bus.replay_gate_clear(rid)
            await ST.bus.replay_wake_push(rid)
        if cleared is not None:
            # 恰一次计数(复审 G3):多 web 副本并发首触时,两边都可能读到冷标
            # 并各自排任务(任务同名幂等无害),但 HDEL 只有一个赢家拿到 since ——
            # 以它为门,promote/falseWake 绝不双计。
            with contextlib.suppress(Exception):
                await ST.bus.histmode_incr("cold_promote")
                if nowm - int(cleared) < 120_000:
                    await ST.bus.histmode_incr("cold_false_wake")


# 区间上界早于 now-1h 的响应内容永不再变,可打 immutable 供浏览器长缓存。
_HIST_FREEZE_LAG_MS = 3_600_000


@app.get("/api/rooms/{room}/history")
async def room_history(room: str, since: int = Query(0), limit: int = Query(80),
                       passive: str = Query(""), until: int = Query(0),
                       request: Request = None):
    rid, _ = await ST.star.canon(room)
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny                              # 4.2.0:free 档零数据
    if (deny := await _user_room_deny(request, room, rid)) is not None:
        return deny                              # 3.8.0:仅本账号名录内的房可读明细
    # ── 4.2.0 basic 档硬闸(需求:每次刷新只提供最后 N 局起累计) ──────────────
    # 关键论证:db.history 的 since 是 `round_id >= $2`(**只抬下界**)且
    # ORDER BY round_id DESC —— 唯一能把窗口往过去挪的是 until。
    # 故「禁 until + 钳 limit」后,basic 档在 API 层**物理上**取不到 N 局以前的
    # 任何数据,无论怎么构造参数、调多少次。这不是前端遮罩,是数学关得住。
    # passive=1(名录跨房预取)同样受钳 —— 否则它就是绕过口(同 3.9.1 给
    # _proof_guard 补 passive 的教训)。
    if _tier(request) == "basic":
        if int(until or 0) > 0:
            return JSONResponse({"ok": False, "error": "vip_required", "need": "vip",
                                 "message": "按日回看是九法VIP功能"}, status_code=403)
        limit = min(int(limit or 80),
                    int(settings.userauth.jf_basic_history_limit))
    # 3.9.1:执行证明闸对 history **含 passive** 生效 —— 否则 passive=1 就成了绕过证明
    #        的后门(名录预取也是明细数据)。真浏览器预取自带 X-JF-Proof(jfFetchCross
    #        走 api(),证明头统一附带);搬运器不跑 JS → 无应答 → 401 proof_required。
    if (deny := await _proof_guard(request)) is not None:
        return deny
    # 3.7.0:真实访问信号(passive=1 = 既有「只读不拉起监控」约定,跨房补拉豁免)。
    # 3.9.0:限流/活跃房租约同样**只作用于主动读** —— passive=1 是前端名录逐房预取
    #        历史(jfFetchCross「只读不拉起监控」),不是「监控本房」,若纳入租约会把
    #        名录预取误判成「盯了别的房」并触发拒绝/租约抖动,故与 _touch_room 同条豁免。
    if str(passive).strip() in ("", "0"):
        if (deny := await _detail_rate_guard(request)) is not None:
            return deny                          # 3.9.0:每账号明细读限流
        if (deny := await _active_room_guard(request, rid)) is not None:
            return deny                          # 3.9.0:每账号同时只监控 1 个房
        await _touch_room(rid)
    # until≤0 一律视同未指定(负值防呆):解析处钳位,让校验/SQL/冻结判定/回显
    # 四处消费点共享同一语义 —— 否则 since<until<0 的构造组合会绕过区间校验、
    # 被 db 层忽略上界(其启用判据为 >0),却仍命中冻结头,给"无上界的最新数据"
    # 错发 immutable(二轮复查实地复现后修复)。
    since_i, until_i = int(since or 0), max(0, int(until or 0))
    # 3.6.0:until>0 时取半开区间 [since, until)(按日回看用);缺省 0 = 旧行为。
    if until_i and until_i <= since_i:
        return JSONResponse({"ok": False, "error": "invalid_range",
                             "hint": "until 必须大于 since(半开区间 [since, until))"},
                            status_code=400)
    rows = await ST.db.history(rid, since_i, int(limit or 80), until_i)
    # 首见宽限:仅当房**在活跃名录**且库里暂无数据时,短暂等 worker 首批回填
    # (最多 6s;对齐旧版「监控刚拉起 <12s 才等」的意图 —— 未监控/不存在的房
    # 不白等,直接回空)。区间回看请求(until>0)是历史读取,等待无意义,一并绕开。
    if not rows and not str(since or "0").strip("0") and not until_i:
        if str(rid) in set(await ST.bus.active_rooms()):
            deadline = time.time() + 6.0
            while time.time() < deadline:
                await asyncio.sleep(0.25)
                rows = await ST.db.history(rid, since_i, int(limit or 80), until_i)
                if rows:
                    break
    rounds = [_round_from_row(r) for r in rows]
    resp = {"ok": True, "requestedRoomId": str(room), "roomId": str(rid),
            "since": str(since), "until": str(until_i), "rounds": rounds}
    if until_i and until_i <= int(time.time() * 1000) - _HIST_FREEZE_LAG_MS:
        # 冻结窗:内容不可再变(判据见 _HIST_FREEZE_LAG_MS 注),immutable 让同一
        # 历史日在浏览器侧 7 天零重复传输;含"现在"的窗与开区间不加任何缓存头。
        return JSONResponse(resp, headers={
            "Cache-Control": "public, max-age=604800, immutable"})
    return resp


@app.get("/api/rooms/{room}/history/days")
async def room_history_days(room: str, limit: int = Query(62),
                             request: Request = None):
    """该房现存历史的**日目录**(3.6.0 按日回看;北京起局日口径,新→旧)。

    供前端全屏序列的日导航供数与「若有」门控(目录 ≤1 天时导航整体隐藏)。
    按房号访问的只读明细类端点 —— 与 history/prediction/summary 同列,不属
    「房间集合出口」,发现房豁免规则同源(见 _visible_rooms docstring)。
    响应不设缓存头(目录随抓取/retention 清理持续变动)。"""
    rid, _ = await ST.star.canon(room)
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny
    if (deny := await _user_room_deny(request, room, rid)) is not None:
        return deny                              # 3.8.0:仅本账号名录内的房可读明细
    if _tier(request) == "basic":
        # 4.2.0:basic 档回**空目录 + vipLocked 标记**,而不是 403。
        # 前端 wvSyncEntry 本就按「目录 ≤1 天则隐藏导航」门控 —— 回空即自然收起,
        # 零渲染逻辑改动;vipLocked 让前端把「回看」按钮改成可点的 VIP 引导
        # (刻意不隐藏:隐藏等于放弃转化点,用户根本不知道自己错过了什么)。
        return {"ok": True, "requestedRoomId": str(room), "roomId": str(rid),
                "retentionDays": settings.retention.days, "days": [],
                "vipLocked": True}
    await _touch_room(rid)                       # 3.7.0:按日回看同为真实访问
    rows = await ST.db.history_days(rid, int(limit or 62))
    days = []
    for r in rows:
        day_start = int(r["day_idx"]) * 86_400_000 - 28_800_000   # 北京 00:00 毫秒
        days.append({"date": _iso(day_start)[:10],                # 'YYYY-MM-DD'
                     "dayStartMs": day_start, "n": int(r["n"]),
                     "firstMs": int(r["first_id"]), "lastMs": int(r["last_id"])})
    return {"ok": True, "requestedRoomId": str(room), "roomId": str(rid),
            "retentionDays": settings.retention.days, "days": days}


@app.get("/api/rooms/{room}/config")
async def room_config(room: str, request: Request = None):
    rid, _ = await ST.star.canon(room)
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny        # 4.2.0(config 给 basic:真实/模拟游戏都依赖法术表,
                           #        且官方概率表本就公开,不构成 VIP 价值)
    if (deny := await _user_room_deny(request, room, rid)) is not None:
        return deny                              # 3.8.0:仅本账号名录内的房可读明细
    return {"ok": True, "requestedRoomId": str(room), "roomId": str(rid),
            "spells": _spells_config(rid)}


@app.get("/api/rooms/{room}/coverage")
async def room_coverage(room: str, window: int = Query(30),
                        request: Request = None):
    """近 window 局的『格点覆盖』——让前端在不盲拉 history 的前提下判断数据是否完整,
    并区分缺口是**官方本身就没有**还是**本项目漏抓**。

    局起点是步进 50001ms 的等差格点(constants.ROUND_STEP)。给定当前最新局起点,
    「近 window 局」= 一组确定的格点。本端点回:
      · latest_start     本地已知最新局起点(算格点用)
      · local            本地库里这 window 个格点中实际持有的(集合)
      · official_missing  已确证**自动抓取链路不可再取得**的格点 —— worker 确证后写入
                          Redis(24h TTL),web 只读。三类来源:出怪兜底(RoundAward 重试耗尽
                          且 GameHistory 亦无)、漏局/哨兵补齐后仍缺(官方历史页亦无)、深度
                          停机超出官方历史页窗(近 30 局,数学上不可达)。绝大多数情形即
                          官方本身跳过了该局。
    前端据此:local 覆盖满窗口(扣掉 official_missing)→ 完整,**不拉 history**;
              缺的格点 ∈ official_missing → 官方本就缺,记住别再拉;
              其余缺口 → 本项目漏抓,拉一次 history 补上。

    web 是只读角色,不打上游(抓取/限流是 worker 的职责)。官方缺失全靠 worker 落库,
    因此本端点零上游调用、可安全高频调用。
    """
    rid, _ = await ST.star.canon(room)
    # 4.2.0:coverage 需 **VIP** —— 它的产物直接驱动前端补拉 80 局 history,
    # 对 basic 档既无意义(窗口本就被钳到 N 局)又是一个绕过口。
    if (deny := await _vip_guard(request, "vip")) is not None:
        return deny
    if (deny := await _user_room_deny(request, room, rid)) is not None:
        return deny                              # 3.8.0:仅本账号名录内的房可读明细
    if (deny := await _proof_guard(request)) is not None:
        return deny                              # 3.9.1:执行证明闸(L2;默认关)
    if (deny := await _detail_rate_guard(request)) is not None:
        return deny                              # 3.9.0:每账号明细读限流
    if (deny := await _active_room_guard(request, rid)) is not None:
        return deny                              # 3.9.0:每账号同时只监控 1 个房
    await _touch_room(rid)                       # 3.7.0:真实访问信号(开房轮询链一员)
    window = max(1, min(int(window or 30), 200))

    rows = await ST.db.history(rid, 0, window)
    if not rows:
        return {"ok": True, "roomId": str(rid), "latest_start": None,
                "window": window, "local": [], "official_missing": [],
                "complete": False, "reason": "no_local_data"}

    latest = int(rows[0]["round_id"])
    grid = [latest - i * ROUND_STEP for i in range(window)]   # 窗口:latest 往回数 window 个格点
    grid_set = set(grid)
    local = sorted(int(r["round_id"]) for r in rows if int(r["round_id"]) in grid_set)

    # worker 确证过的「官方本身缺失」格点(每房一个 Redis 集合,带 TTL)
    off_missing = await ST.bus.official_missing_in(str(rid), grid)
    off_missing = sorted(g for g in off_missing if g in grid_set)

    # 完整 = 窗口里每个格点,要么本地有,要么官方本就没有
    covered = set(local) | set(off_missing)
    complete = all(g in covered for g in grid)

    return {"ok": True, "roomId": str(rid), "latest_start": latest,
            "window": window, "local": local,
            "official_missing": off_missing, "complete": complete}


@app.get("/api/pow/mint")
async def pow_mint(request: Request = None):
    """执行证明 · 挑战签发(L2,3.9.1)。走 guard(需有效会话)→ 已带身份。
    特性关闭时回 {enabled:false},前端据此**完全不做**证明流程(零副作用)。
    开启时:按会话生成随机挑战、存 Redis(短 TTL)、回给前端;前端算 _pow_answer
    后在窗口内复用为 X-JF-Proof。Redis 异常回 enabled:false(fail-open,不阻断)。"""
    if not _pow_enabled() or _req_user(request) is None:
        return {"ok": True, "enabled": False}
    key = _pow_key(request)
    if not key:
        return {"ok": True, "enabled": False}
    ttl = int(max(10.0, float(settings.userauth.proof_challenge_ttl_s)))
    grace = int(max(0.0, float(getattr(settings.userauth, "proof_rotate_grace_s", 45.0))))
    chal = secrets.token_hex(16)
    try:
        # 4.9.0:把**旧**挑战转存宽限键再覆盖 —— 此刻仍在飞的请求(带的是旧应答)
        # 不会因为这次续铸而变成一次假失败。get 失败/键不存在都无所谓,静默跳过。
        # 宽限键是**锦上添花**,它的读写失败绝不能影响本次签发 —— 故整段自带
        # try/except。若让它冒泡到外层,一次瞬时 Redis 抖动就会让本端点回
        # enabled:false,前端据此把 POW.on 置假 = **整个会话永久关掉 L2**,
        # 代价与收益完全不成比例。
        if grace > 0:
            try:
                old = await ST.bus.r.get(key)
                if old:
                    await ST.bus.r.set(_pow_grace_key(key), old, ex=grace)
            except Exception:          # noqa: BLE001 —— 宽限失败 = 退回无宽限行为,仅此而已
                pass
        await ST.bus.r.set(key, chal, ex=ttl)
    except Exception:                  # noqa: BLE001 —— fail-open:签发失败=前端拿不到挑战
        return {"ok": True, "enabled": False}   #    → 明细端点 fail-open 放行,不锁真人
    return {"ok": True, "enabled": True, "challenge": chal, "ttl": ttl}


@app.get("/api/rooms/{room}/prediction")
async def room_prediction(room: str, request: Request = None):
    rid, _ = await ST.star.canon(room)
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny
    if (deny := await _user_room_deny(request, room, rid)) is not None:
        return deny                              # 3.8.0:仅本账号名录内的房可读明细
    if (deny := await _proof_guard(request)) is not None:
        return deny                              # 3.9.1:执行证明闸(L2;默认关)
    if (deny := await _detail_rate_guard(request)) is not None:
        return deny                              # 3.9.0:每账号明细读限流
    if (deny := await _active_room_guard(request, rid)) is not None:
        return deny                              # 3.9.0:每账号同时只监控 1 个房
    await _touch_room(rid)                       # 3.7.0:真实访问信号
    out = await _build_prediction(rid)
    # ── 4.2.0 basic 档裁剪:切分点即 VIP 的核心价值 ─────────────────────────
    # VIP 卖的是「**下一局**主2防2」(main/guard/ens/target);
    # basic 拿到的是「**历史**准不准」(record/accuracy,近 N 局)。
    # 用户能亲眼看见命中率,就是不知道下一局 —— 这是转化率最高的形态,
    # 也恰好等于需求原文的「灵机推演近 100 局的命中信息」。
    if _tier(request) == "basic":
        win = int(settings.userauth.jf_basic_pred_window)
        out["target_round_id"] = None
        out["main"] = []
        out["guard"] = []
        out["ens"] = []
        out["why"] = ""
        # trainN 是**待结算那条预测**的属性,basic 档既然连 target 都不给,
        # 留着它会自相矛盾(target=null 却透出一个训练样本数,等于承认有 pending)。
        out["trainN"] = None
        out["vipLocked"] = True
        recs = await ST.db.prediction_records(rid, win)
        out["record"] = [{"id": str(r["round_id"]), "n": r["actual_custom_id"],
                          "v": r["hit"], "s": r.get("source") or ""} for r in recs]
        out["accuracy"] = await ST.db.accuracy(rid, win)
    out["requestedRoomId"] = str(room)
    out["roomId"] = str(rid)
    return out


@app.get("/api/rooms/{room}")
async def room_summary(room: str, request: Request = None):
    rid, _ = await ST.star.canon(room)           # canon 有缓存,双调零成本
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny
    if (deny := await _user_room_deny(request, room, rid)) is not None:
        return deny                              # 3.8.0:仅本账号名录内的房可读明细
    if (deny := await _proof_guard(request)) is not None:
        return deny                              # 3.9.1:执行证明闸(L2;默认关)
    if (deny := await _detail_rate_guard(request)) is not None:
        return deny                              # 3.9.0:每账号明细读限流
    if (deny := await _active_room_guard(request, rid)) is not None:
        return deny                              # 3.9.0:每账号同时只监控 1 个房
    await _touch_room(rid)                       # 3.7.0:真实访问信号
    return await _build_summary(room)


@app.get("/api/crawler/status")
async def crawler_status(request: Request = None):
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny
    # 与前端 live-rooms 同口径:自动发现房只在后台采集,不计入前端展示的爬虫状态列表。
    discovered = await ST.bus.discovered_members()
    # 3.8.0:登录用户的逐房状态列表只含其名录内的房(算力体检等健康数字仍是
    # 全局口径 —— 那是舰队容量诊断,不含任何房号,不构成账号间信息泄漏)。
    _u = _req_user(request)
    _mine: Optional[set] = None
    if userauth.enabled() and _u is not None:
        # 复查修复:名录取失败**收口为空集**(fail-closed)。此前 suppress 后
        # _mine 留 None 会掉进「全局逐房列表」分支 —— PG 抖动瞬间登录用户能看到
        # 其他账号添加的房号,与隔离承诺矛盾。列表读挂一拍显示为空可自愈,
        # 泄漏不可回收;与 _user_room_deny(单房读,fail-open 有书面理由)刻意不同。
        _mine = set()
        with contextlib.suppress(Exception):
            _mine = {str(b["room_id"]) for b in await ST.db.user_rooms_list(_u.user_id)}
    # curated-idle(3.7.0):冷策展房集合(仍可见,仅供数节奏不同;观测/体检双用)
    _hm = settings.histmode
    _ci_on = bool(_hm.enabled and getattr(_hm, "curated_idle_enabled", False))
    cold: set = set()
    if _ci_on:
        with contextlib.suppress(Exception):
            cold = set(await ST.bus.cold_members())
    active = await _visible_rooms()
    rooms = []
    host_now = int(time.time() * 1000)
    server_now = host_now
    for rid in active:
        if _mine is not None and str(rid) not in _mine:
            continue                              # 3.8.0:按账号名录过滤
        alias = await ST.bus.alias_of(rid)
        snap = await ST.bus.get_snapshot(rid)
        latest_rid = snap.get("latestRoundId") or ""
        if not latest_rid:
            latest = await ST.db.latest_round(rid)
            latest_rid = latest["round_id"] if latest else ""
        # 外推钟(同 SSE):快照 serverNowMs 是抓取那一刻的钟,陈旧 0~50s,
        # 直接当"当前服务器时刻"下发会让状态页时间回跳。空快照按 host 钟。
        server_now = extrapolate_server_now(snap, host_now)
        rooms.append({"roomId": rid, "alias": alias,
                      "latestRoundId": str(latest_rid) if latest_rid else "",
                      "lastError": snap.get("lastError", "") or ""})
    # ── 算力体检(3.4.2 新增;附加字段,契约兼容)────────────────────────────────
    # **到期积压**是本系统最重要的健康指标,此前在任何地方都不可见 —— 于是
    # 「worker 算力不足」这种最常见的故障只表现为前端症状(出怪晚一局、预测滞后/
    # 消失),却查不到根因:数据一条不丢(coverage 仍 complete),只是**系统性地晚**。
    #   backlog      到期却还没被领取的任务数
    #   backlogLagMs 最老到期任务已经迟到多久 —— >10s 即判定算力不足
    #   suggestReplicas 按实测每副本 ≈4300 房给出的建议副本数
    health: dict = {}
    with contextlib.suppress(Exception):
        # 算力体检必须按**真实负载**计数 = 策展房 + 自动发现房(worker 两者都在抓)。
        # 这是本文件唯一一处**有意**不过 _visible_rooms 的 active_rooms 出口:
        # 只取 len() 做体检算术,**绝不把房号列表外泄给前端**(可见性守卫已收录白名单)。
        _load_rooms = await ST.bus.active_rooms()
        backlog, lag_ms = await ST.bus.sched_backlog()
        # hist-mode(3.5.0):启用时按**等效实时房数**体检 —— hist 房每 T 才一个
        # 事件,仍按实时口径算会把建议副本虚高 3 副本(体检撒谎)。禁用时
        # _eff == len(_load_rooms),行为逐字节不变。
        _eff = len(_load_rooms)
        if settings.histmode.enabled and (discovered or cold):
            # 3.7.0:冷策展房与发现房同为轮询节奏,一并入 hist 桶 —— 否则等效
            # 负载按实时口径虚高,建议副本数撒谎(与 worker 分钟脉搏同一笔账)。
            _hist_bucket = len(discovered) + len(cold)
            _eff = weighted_fleet_load(
                len(_load_rooms) - _hist_bucket, _hist_bucket,
                effective_hist_interval_ms(settings.histmode) / 1000.0)
        need = max(2, math.ceil(_eff / 4300) + 1)
        # 钟偏(worker janitor 每分钟抽样上墙):服务器钟 − 本机钟。
        # 3.4.3 起抓取已按它换算、不再因此变晚;但大钟偏说明宿主机 NTP 有问题。
        _skew = 0
        with contextlib.suppress(Exception):
            _skew = int(await ST.bus.r.hget("stats:ingest", "clock_skew_ms") or 0)
        _pg = await ST.db.pg_health_probe()
        _hard_cap = ((_pg["max_conn"] - 35) // 32) if _pg.get("max_conn", 0) > 0 else 11
        if _pg.get("saturated"):
            _note = (f"PG 连接饥饿:探针耗时 {_pg['ping_ms']}ms,连接 "
                     f"{_pg.get('used','?')}/{_pg.get('max_conn','?')}。每 worker 副本"
                     f"≈32 连接,当前 max_connections 下硬顶 {_hard_cap} 副本 —— 副本数"
                     f"超账本时任务「按时被领、执行中排队」,出怪入库会散布到局内 40~70s、"
                     f"预测出现长 null 空窗(Redis 积压恒 0,此前不可见)。请降副本"
                     f"(本舰队按算力只需 {need})或调大 max_connections。")
        elif lag_ms > 10_000:
            _note = ("worker 算力不足:抓取被整体推迟,前端会看到「出怪晚一局」"
                     "与预测滞后/消失(数据不丢,只是系统性地晚)。"
                     f"建议 --scale worker={need},或调小 discovery.prune_grace_s")
        else:
            _note = ""
        health = {
            "monitoredRooms": len(_load_rooms),           # ≠ 前端可见房数(含发现房)
            "backlog": backlog,
            "backlogLagMs": lag_ms,
            "clockSkewMs": _skew,                         # 服务器钟 − 本机钟
            "clockSynced": abs(_skew) <= 5_000,
            # ── PG 侧饥饿探针(3.4.4)────────────────────────────────────────────
            # Redis 侧 backlog=0 ≠ 健康:副本扩到连接账本外(每副本 ≈32 连接,
            # 硬顶 ⌊(max_connections−35)/32⌋)时,pool.acquire 无限期排队,任务
            # 「按时被领、执行中卡死」—— 出怪入库散布到局内 41~70s、结算→预测
            # 再拖 3~40s、/prediction 出现十几秒 null 空窗(真机实证)。
            # pgPingMs = 取连接+SELECT 的端到端耗时,即一切业务 PG 调用的入场费。
            "pgPingMs": _pg.get("ping_ms", -1),
            "pgConnections": (f"{_pg.get('used', -1)}/{_pg.get('max_conn', -1)}"
                              if _pg.get("used", -1) >= 0 else "?"),
            "pgSaturated": bool(_pg.get("saturated")),
            "healthy": lag_ms <= 10_000 and not _pg.get("saturated"),
            "suggestReplicas": need,
            "note": _note,
        }
        if settings.histmode.enabled:
            health["effectiveRooms"] = _eff   # 加权等效实时房数(体检口径)

    # 数据保留策略与最近一次清理统计(worker 写入 Redis;附加字段,契约兼容)
    retention: dict = {"days": settings.retention.days,
                       "enabled": settings.retention.days > 0}
    with contextlib.suppress(Exception):
        last = await ST.bus.retention_last()
        if last:
            retention["last"] = last
    # 直播间自动发现:开关 + 最近一轮遍历统计(附加字段,契约兼容;前端可忽略)
    discovery: dict = {"enabled": bool(settings.discovery.enabled),
                       "intervalS": settings.discovery.interval_s,
                       "discoveredCount": len(discovered)}
    with contextlib.suppress(Exception):
        dlast = await ST.bus.discovery_last()
        if dlast:
            discovery["last"] = dlast
    # 核验准入(5.0.7;附加字段,契约兼容):台账规模与最近一轮复核统计。
    # probed 长期等于 ledger = 三级供货的前两级没在供货(发现/探测都停了);
    # pruned 持续走高 = 复核周期相对 grace 太长,核验房还没轮到就被判超期。
    discovery["verify"] = {"enabled": bool(getattr(settings.discovery,
                                                   "verify_enabled", True)),
                           "intervalS": int(getattr(settings.discovery,
                                                    "verify_interval_s", 86400))}
    with contextlib.suppress(Exception):
        vlast = await ST.bus.verify_last()
        if vlast:
            discovery["verify"]["last"] = vlast
    # 主播直播状态(5.0.6;附加字段,契约兼容):最近一轮探测统计 —— 探测在不在跑、
    # 策展房里几家在播/未开播/未知。unknown 长期高企 = worker 停摆或上游探测受阻。
    livestatus: dict = {"enabled": bool(settings.livestatus.enabled),
                        "intervalS": settings.livestatus.interval_s,
                        "staleS": settings.livestatus.stale_s}
    if settings.livestatus.enabled:
        with contextlib.suppress(Exception):
            llast = await ST.bus.livestatus_last()
            if llast:
                livestatus["last"] = llast
    # hist-mode 运行观测(3.5.0;附加字段,契约兼容):
    #   oldestPollAgeMs 全舰队最老「距上次成功轮询」—— 本模式第一健康指标
    #                   (> interval×2 黄、> edge_after 红;-1 = 尚无成功记录)
    #   windowLost      越窗丢失累计(stats:histmode,7 天滚动)—— 应恒为 0,
    #                   增长 = 上游/网络长断供或 interval 配置过大
    #   shortPage       连续短页启发式计数(官方页窗缩水的预警;零星=新房噪声)
    histmode_info: dict = {"enabled": bool(settings.histmode.enabled),
                           "intervalS": settings.histmode.interval_s}
    if settings.histmode.enabled:
        with contextlib.suppress(Exception):
            histmode_info["rooms"] = len(discovered) + len(cold)   # 轮询舰队全员
            item = await ST.bus.hist_oldest()
            histmode_info["oldestPollAgeMs"] = (host_now - item[1]) if item else -1
            hstats = await ST.bus.histmode_stats()
            histmode_info["windowLost"] = int(hstats.get("window_lost", 0) or 0)
            histmode_info["shortPage"] = int(hstats.get("short_page", 0) or 0)
            histmode_info["estReqPerSec"] = round(
                (len(discovered) + len(cold))
                / max(1, settings.histmode.interval_s), 2)
            # ── curated-idle 观测(3.7.0;附加字段,读者可忽略)──────────────
            #   coldCount   当前冷房数    wouldDemote/-Sample 最近一扫的影子判定
            #   demotes/promotes/falseWake 累计(stats:histmode,7 天滚动;
            #   falseWake = 降级后 <2min 即被访问唤醒 —— 疑似误降,调参信号)
            try:
                _ws = json.loads(hstats.get("cold_would_sample") or "[]")
            except ValueError:
                _ws = []
            histmode_info["curatedIdle"] = {
                "enabled": _ci_on,
                "shadow": bool(getattr(_hm, "curated_idle_shadow", True)),
                "idleAfterS": int(getattr(_hm, "curated_idle_after_s", 1800) or 1800),
                "coldCount": len(cold),
                "wouldDemote": int(hstats.get("cold_would", 0) or 0),
                "wouldSample": _ws,
                "demotes": int(hstats.get("cold_demote", 0) or 0),
                "promotes": int(hstats.get("cold_promote", 0) or 0),
                "falseWake": int(hstats.get("cold_false_wake", 0) or 0),
            }
    return {"ok": True, "crawler": {
        "serverNowMs": server_now, "rooms": rooms, "lastError": "",
        "retention": retention, "discovery": discovery,
        "liveStatus": livestatus,
        "histMode": histmode_info, "health": health}}


@app.get("/api/discovery/status")
async def discovery_status(request: Request = None):
    # 4.2.0(复审补):方案里列了本端点要接闸,实现时漏了。discoveredCount 与
    # 最近一轮遍历统计也是"数据",free 档「不提供任何数据」应当一视同仁。
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny
    """直播间自动发现的运行观测:开关/周期 + 当前发现房数 + 最近一轮遍历统计。
    只读、附加接口(前端无需依赖;运维/调试用)。"""
    discovered = await ST.bus.discovered_members()
    out = {
        "ok": True,
        "enabled": bool(settings.discovery.enabled),
        "intervalS": settings.discovery.interval_s,
        "maxPages": settings.discovery.max_pages,
        "pruneGraceS": settings.discovery.prune_grace_s,
        "discoveredCount": len(discovered),
        "verifyEnabled": bool(getattr(settings.discovery, "verify_enabled", True)),
        "verifyIntervalS": int(getattr(settings.discovery, "verify_interval_s", 86400)),
        "last": None,
        "verifyLast": None,
    }
    with contextlib.suppress(Exception):
        out["last"] = await ST.bus.discovery_last()
    with contextlib.suppress(Exception):
        out["verifyLast"] = await ST.bus.verify_last()
    return out


# ── SSE:转发 worker 发布到 Redis 频道的换局/新出怪事件 ───────────────────────
#    契约对齐旧 server.py._sse_events(前端 EventSource 实锤):
#      · query 参数为 **roomId**(前端 api/events?roomId=${alias});
#      · event 行为自定义事件名 connected / heartbeat / room-updated
#        (前端 addEventListener('room-updated'));出怪事件带 id: round_id;
#      · 心跳 20s;心跳节拍上复查归一,短号后台归一成功即换订阅自愈。
@app.get("/api/events")
async def events(request: Request, roomId: str = Query("")):
    # 4.2.0:free 档在**建流前**拒 —— 建了再踢会让开通页出现莫名其妙的断连提示。
    # basic 档放行:SSE 推来的新局正是「30 局起累计」里"累计"的来源。
    if (deny := await _vip_guard(request, "basic")) is not None:
        return deny
    req_room = str(roomId).strip()
    # 3.8.0:登录用户只能订阅本账号名录内的房(SSE 是明细数据面;EventSource
    # 无法带自定义头,故 CSRF 头豁免,但 Cookie 会话门与按账号访问闸照过)。
    if req_room:
        _rid0, _ = await ST.star.canon(req_room)
        if (deny := await _user_room_deny(request, req_room, _rid0)) is not None:
            return deny
    # 3.8.0 复查修复:SSE 是长连 —— 建立时校验过的会话可能在流存活期间被顶下/
    # 封停/到期。捕获令牌,心跳节拍上复核(validate 走 20s 进程缓存 + kick 广播
    # 即时失效,近零成本);**确定性失效**才终止流(userdb 瞬断的 unavailable
    # 不误杀,与降级窗哲学一致)。前端收 authRevoked → 回落登录门。
    _sse_tok = request.cookies.get(userauth.UA.cfg.cookie_name, "") \
        if (userauth.enabled() and _req_user(request) is not None) else ""

    # 3.9.0:每账号「同时只监控 1 个房」租约 —— SSE 是最确定的「正在监控本房」信号,
    # 建流即抢租、20s 心跳续租、断流条件释放。仅登录启用且带身份且特性开启时生效。
    _lease_u = _req_user(request)
    _lease_on = bool(userauth.enabled() and _lease_u is not None
                     and getattr(settings.userauth, "active_room_lease", True))
    _lease_uid = int(_lease_u.user_id) if _lease_on else 0
    _lease_tab = _client_tab(request) if _lease_on else ""
    _lease_ttl_ms = int(max(5.0, float(settings.userauth.active_room_lease_ttl_s)) * 1000)

    # ── 4.2.0 复审补漏:SSE 是**推送**通道,VIP 闸只挡住了 REST 拉取 ──────────
    # worker 每局经 Redis 推 `pred-updated`,载荷 = {settled:{id,n,v}, next:{target,
    # main,guard}}。SSE 原样 `data=data` 转发 —— 于是 basic 档用户只要开着连接,
    # **下一局主2防2 就明文躺在 EventStream 里**(DevTools 一开即见;脚本客户端
    # 直接订阅即可)。这完全绕过 /api/rooms/{room}/prediction 的裁剪。
    #
    # 修法必须是外科手术式的,不能整条掐掉:
    #   · `settled`(上局命中判定)basic 档**有权**看 —— 那正是"近100局命中信息";
    #   · `next`(下一局主/防)是 VIP 的核心价值 —— 必须剥掉。
    # 剥完若 pred 变空则整条事件不发(省一次无意义的唤醒)。
    _sse_tier = _tier(request)

    async def _lease_follow(target_room: str) -> str:
        """续租本账号活跃房(renew);返回 "" = 仍在本房(放行),否则 = 应**跟随**过去的房号。
        特性关时恒 ""(放行);Redis 异常 fail-open(不因协调层抖动切断在看的实时流)。
        SSE 是「持续监控」→ 永远 renew(claim=False),绝不抢占,故不会与别的窗口抖动。"""
        if not (_lease_on and target_room):
            return ""
        try:
            ok, held = await ST.bus.active_room_acquire(
                _lease_uid, str(target_room), _lease_tab,
                int(time.time() * 1000), _lease_ttl_ms, claim=False)
            return "" if ok else str(held or "")
        except Exception:             # noqa: BLE001
            return ""

    async def _timer_payload(target: str, typ: str) -> dict:
        snap = await ST.bus.get_snapshot(target) if target else {}
        # 外推钟(host 当前 + 快照实测钟差),绝不下发快照里陈旧 0~50s 的
        # serverNowMs —— 心跳每 20s 校时一次,陈旧钟会被前端 EMA 吸收成
        # 周期性回拖锯齿(倒计时"备战归零后回溯布置期"/±10s 抖动的元凶)。
        out = {"type": typ,
               "serverNowMs": extrapolate_server_now(snap, int(time.time() * 1000))}
        if _snap_int(snap, "roundStartTimeMs"):
            out["timer"] = {
                "roundStartTimeMs": _snap_int(snap, "roundStartTimeMs"),
                "spellTimeMs": _snap_int(snap, "spellTimeMs"),
                "drawTimeMs": _snap_int(snap, "drawTimeMs"),
                "endTimeMs": _snap_int(snap, "endTimeMs"),
                "canPlay": (snap.get("canPlay") == "1"),
            }
        return out

    async def gen():
        # 4.2.0:`_sse_tier` 定义在外层 events(),而下方心跳分支会**赋值**给它 ——
        # 不声明 nonlocal 的话 Python 会把它当作 gen() 的局部变量,于是转发处的
        # 读取抛 UnboundLocalError,**整条 SSE 在第一个事件就死**(所有档位皆然,
        # 且租约随之停止续租)。这是本次复审实测抓到的真实回归,别再改回去。
        nonlocal _sse_tier
        room = req_room
        if room:
            # 握手不被归一网络拖慢:canon 限时 1.5s,超时/失败按原号先行订阅
            # (数字原号即真实号时频道已正确;短号场景由 20s 心跳节拍的
            # 漂移自愈换到真实频道)。首帧 connected 因此恒定秒回。
            try:
                rid, _ = await asyncio.wait_for(ST.star.canon(room), timeout=1.5)
                room = rid or room
            except (asyncio.TimeoutError, Exception):
                pass
        # 3.9.0/3.9.3:建流即 renew 活跃房租约。**last-wins**:若本账号活跃房已被别的
        # 窗口/设备切换,则回 follow 事件(带应跟随的房号)并收流 —— 前端据此**自动切换
        # 到最新监控的房**(不是阻断)。仍在本房则继续下发 connected。
        if room:
            _follow = await _lease_follow(room)
            if _follow:
                yield ServerSentEvent(event="follow",
                                      data=json.dumps({"ok": False,
                                                       "error": "room_switched",
                                                       "room": _follow},
                                                      ensure_ascii=False))
                return
        # 连上即校准:connected 携带该房权威计时(旧 sse_hello 同款)
        if room:
            await _touch_room(room)   # 3.7.0:SSE 连接 = 确定的实时消费者,冷房即刻唤醒
        hello = await _timer_payload(room, "connected")
        yield ServerSentEvent(event="connected", data=json.dumps(hello, ensure_ascii=False))
        if not room:
            return
        # 结构说明:redis 消息由独立 reader 任务经 pubsub.listen()(纯阻塞读)喂入
        # 本地 Queue;gen 主循环只消费队列,心跳节拍由 queue.get 超时驱动。
        # 客户端断开由 sse-starlette 自身检测并取消本生成器(finally 收尾)——
        # 这避免了在 SSE 任务组内并发 await receive()/get_message() 的执行环境
        # 交互问题(实测该交互会令 get_message 永远收不到消息)。
        # ── 连接从这里被取走 → try 必须**紧跟其后**(修复:pubsub 连接泄漏)──
        #   原实现把 pubsub()/subscribe()/create_task() 放在 try 之外,而唯一的
        #   归还点 `pubsub.aclose()` 在 finally 里。于是这一段窗口内的任何异常
        #   或取消(建流瞬间关页、subscribe 撞上池枯竭的 ConnectionError……)
        #   都会让 finally **根本没机会执行** —— 连接留在池的 in-use 账本里、
        #   TCP 还开着、Redis 侧订阅还挂着,永久失踪。redis-py 的 PubSub 没有
        #   __del__ 归还连接,GC 也救不回来。
        #   这构成正反馈螺旋:池紧张 → subscribe 抛错 → 泄漏一条 → 池更紧张。
        #   真机实证:47 条 subscribe 连接 vs web 上仅 15 条活着的浏览器 TCP
        #   连接 —— 物理上不可能,至少 29 条是孤儿。
        #   修法只是把 try 起点上提 + finally 判空,业务逻辑一行未动。
        # 取池:优先 SSE 专用池;未接线(测试直调端点 / 旧部署未跑 lifespan)时
        # **回退到共享池** —— 分舱是优化,缺了只是退回旧行为,绝不因此让流建不起来。
        _sse_r = (getattr(ST, "sse_bus", None) or ST.bus).r
        pubsub = _sse_r.pubsub()
        reader = None                    # 预置:finally 可能在 create_task 之前就跑到
        _lease_ch = ""                   # 同上
        try:
            await pubsub.subscribe(ST.bus.draw_channel(room))
            # 3.9.4:同一 pubsub 连接加订本账号的租约切换频道 —— 别的窗口显式 claim 时
            # 服务端即时得知,不再干等 20s 心跳下一拍才发现「被切走」。频道恒定(按 uid),
            # 与心跳节拍上的换订(draw 频道随归一漂移)互不相干。
            # **订阅失败降级不杀流**(与"广播 best-effort"承诺严格一致):draw 订阅已成而
            # 本订阅遇瞬时抖动时,清空 _lease_ch 退回纯心跳节拍 —— 即时性是优化,实时
            # 供数才是本体,协调层小抖动绝不切断正在看的流(fail-open 同哲学)。
            _lease_ch = ST.bus.lease_channel(_lease_uid) if _lease_on else ""
            if _lease_ch:
                try:
                    await pubsub.subscribe(_lease_ch)
                except Exception:             # noqa: BLE001
                    _lease_ch = ""
            q: asyncio.Queue = asyncio.Queue(maxsize=256)

            async def _reader():
                try:
                    async for m in pubsub.listen():
                        if m.get("type") == "message":
                            ch = m.get("channel")
                            if isinstance(ch, bytes):
                                ch = ch.decode("utf-8", "ignore")
                            with contextlib.suppress(asyncio.QueueFull):
                                q.put_nowait((str(ch or ""), m["data"]))
                except asyncio.CancelledError:
                    raise            # 我们主动取消(收流清理):正常路径,不是失联
                except BaseException:
                    # 其余异常(Redis 重启/连接被切断/协议错)一律吞掉并结束任务;
                    # 主循环靠 reader.done() 察觉失联并收流(见下方判断)。
                    pass

            reader = asyncio.create_task(_reader())
            last_beat = time.time()
            # ── 3.9.5(1.4.3 落地):独立续租节拍 —— 与数据/心跳解耦 ────────────
            # 旧实现的稳态续租只在「20s 静默心跳」分支;draw 事件恒刷新 last_beat,
            # 忙房(本游戏 ~50s/局、事件间隔 40s/10s 交替)把心跳无限后推 →
            # 续租实际 ~每局一次 > TTL(默认 40s),租约每局空窗 ~10s,
            # 「单账号单活跃房」被击穿(回归钉 test_lease_renew_cadence.py 三条,
            # 其数学钉与本式同源;此前该文件因缺 fakeredis[lua] 整体 SKIP,
            # 主干假绿 —— 1.4.3 实地核查补齐依赖后揭红,补上正文实现)。
            # 节拍 = clamp(TTL/2, 1s, 15s):每个 TTL 窗口至少续 2 次,丢一拍
            # (Redis 抖动/调度延迟)仍不空窗;下限 1s 防 TTL 误配成忙轮询。
            # 续租走 renew(claim=False)语义(_lease_follow):被切走 → 一个节拍内
            # follow 收流,绝不抢占;仍在本房 → 静默,不产事件、不碰 last_beat
            # (即时通道同款纪律:续租不得推迟心跳节拍上的会话复核/归一自愈)。
            _renew_gap = max(1.0, min(15.0, (_lease_ttl_ms / 1000.0) / 2.0)) \
                if _lease_on else 0.0
            last_renew = time.time()          # 建流处的 renew 即第 0 拍
            while True:
                try:
                    item = await asyncio.wait_for(q.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    item = None
                # ★ 修复「静默失聪」(真机实证):reader 是本流唯一的消息来源。
                #   Redis 重启 / 连接被 RST 切断时 pubsub.listen() 抛
                #   ConnectionError,reader 任务就此结束 —— 但主循环毫不知情,
                #   `q.get` 超时后照发心跳。于是客户端"连接正常、心跳不断,却
                #   永远收不到开奖",房间冻住,而且**不会重连**(流没断,
                #   EventSource 没有重连的理由)。实测:RST 后续发的两条消息
                #   全部丢失,health_check_interval 也救不回来。
                #   收流是最稳妥的修法:EventSource 自带重连,重连即建新 pubsub,
                #   并重跑鉴权/租约/归一 —— 比在流内原地重订阅更干净。
                #   放在 item is None 分支后:队列里已到的消息先发完再收流。
                if item is None and reader is not None and reader.done():
                    return
                if item is not None:
                    ch, data = item
                    if _lease_ch and ch == _lease_ch:
                        # 3.9.4:租约切换事件 —— 只当**触发器**用(不解析、不信 payload,
                        # 免疫乱序/陈旧广播):做一次权威 renew,被切走则立即 follow 收流;
                        # 仍在本房(如用户又切回来了/自家窗口的 claim)则静默续租继续。
                        # 刻意**不刷新 last_beat**:即时通道不得推迟心跳节拍上的
                        # 会话复核 / 归一漂移自愈(claim 风暴推迟安全检查 = 倒挂)。
                        _follow = await _lease_follow(room)
                        if _follow:
                            yield ServerSentEvent(
                                event="follow",
                                data=json.dumps({"ok": False, "error": "room_switched",
                                                 "room": _follow}, ensure_ascii=False))
                            return
                        last_renew = time.time()   # 3.9.5:广播触发的 renew 也算一拍
                        continue
                    if isinstance(data, bytes):
                        data = data.decode("utf-8", "ignore")
                    try:
                        ev = json.loads(data)
                    except ValueError:
                        ev = {}
                    etype = ev.get("type", "message")
                    rd = ev.get("round")
                    eid = rd.get("round_id") if isinstance(rd, dict) else None
                    # 4.2.0:basic 档剥掉推送里的「下一局主/防」(见上方 _sse_tier 注)。
                    # 防御性写法:不假设只有 pred-updated 带 pred —— 任何事件里出现
                    # `pred.next` 一律剥,将来新增事件类型也不会漏。
                    if _sse_tier == "basic" and isinstance(ev.get("pred"), dict):
                        _p = dict(ev["pred"])
                        _p.pop("next", None)
                        # ★ 刻意**不 continue**:本函数下方的「独立续租节拍」注释写明
                        #   「置于两分支汇合处……唯广播触发分支 continue 跳过」——
                        #   若剥空的事件也 continue,繁忙房里 _push_next_prediction 发出的
                        #   **只含 next** 的独立事件会被连续跳过,租约得不到续租而消失。
                        #   改为:剥空就把 pred 键整个删掉、事件照常下发(前端
                        #   applyPredPush 对 undefined 直接 return,无副作用),
                        #   控制流与 4.1.2 逐字节相同。
                        if _p:
                            ev["pred"] = _p
                        else:
                            ev.pop("pred", None)
                        ev["vipLocked"] = True
                        data = json.dumps(ev, ensure_ascii=False)
                    yield ServerSentEvent(event=etype, data=data,
                                          id=(str(eid) if eid else None))
                    last_beat = time.time()
                elif time.time() - last_beat >= 20:
                    # 归一漂移自愈:连接建立时若短号尚未归一,后台归一成功后
                    # worker 按真实号发布 —— 心跳节拍复查(限时;缓存命中零网络),
                    # 漂移即换订阅,否则本流将永远静默(对齐旧 2.9.4 修复)。
                    try:
                        cur, _ = await asyncio.wait_for(
                            ST.star.canon(req_room), timeout=1.0)
                    except (asyncio.TimeoutError, Exception):
                        cur = None
                    if cur and cur != room:
                        await pubsub.unsubscribe(ST.bus.draw_channel(room))
                        room = cur
                        await pubsub.subscribe(ST.bus.draw_channel(room))
                    await _touch_room(room)   # 3.7.0:心跳刷新访问时戳(在看的房年龄恒 <20s)
                    if _sse_tok:               # 3.8.0:会话吊销即断流(见端点头注)
                        _st, _pr, _ = await userauth.validate(_sse_tok)
                        # 4.2.0:档位随心跳跟随 —— 用户中途开通 VIP 后,
                        # refresh_tier 已清缓存,下一拍复核即拿到 vip,
                        # 本流**不必重连**就开始收到完整推送(付完钱立刻见效)。
                        if _pr is not None and jfvip.enabled():
                            _sse_tier = _pr.tier
                        if _st in ("auth_required", "kicked", "banned", "expired"):
                            yield ServerSentEvent(
                                event="authRevoked",
                                data=json.dumps({"ok": False, "error": _st}))
                            return
                    _follow = await _lease_follow(room)   # 3.9.3:心跳续租;被切走→跟随
                    if _follow:
                        yield ServerSentEvent(
                            event="follow",
                            data=json.dumps({"ok": False, "error": "room_switched",
                                             "room": _follow}, ensure_ascii=False))
                        return
                    last_renew = time.time()   # 3.9.5:心跳分支的 renew 也算一拍
                    beat = await _timer_payload(room, "heartbeat")
                    yield ServerSentEvent(event="heartbeat",
                                          data=json.dumps(beat, ensure_ascii=False))
                    last_beat = time.time()
                # ── 3.9.5:独立续租节拍(见循环入口说明)。置于两分支汇合处:
                # draw 供数、静默等待、心跳三条路径每迭代必经;唯广播触发分支
                # continue 跳过 —— 它刚亲手 renew 过,恰是应跳过的那一次。 ──
                if _lease_on and time.time() - last_renew >= _renew_gap:
                    _follow = await _lease_follow(room)
                    if _follow:
                        yield ServerSentEvent(
                            event="follow",
                            data=json.dumps({"ok": False, "error": "room_switched",
                                             "room": _follow}, ensure_ascii=False))
                        return
                    last_renew = time.time()
        finally:
            # ★ v2 修复:清理链必须逃出「取消风暴」。
            # 真机 + 真值机双重实证(FIN/RST 两种断开均 100% 复现):客户端断开
            # 后 uvicorn 取消本请求任务,sse-starlette 的 anyio 任务组随之对内层
            # **反复投递** CancelledError —— finally 进得来,但第一条 await
            # (下面的租约释放,旧代码包的是 suppress(Exception),挡不住属于
            # BaseException 的 CancelledError)当场再爆,整条清理链中止:
            # reader 成孤儿、aclose 永不执行、连接留在池的 in-use 账本 ——
            # 每关一次页稳定漏一条(线上 47 条 subscribe vs 15 条真实 TCP)。
            # 即便逐项换成 suppress(BaseException) 也不够:aclose **自身内部**
            # 的 await 同样会被再投递切断 —— 启动了却走不到归还那步。
            # 修法:清理挪进**独立新任务**(不在被取消的作用域内,天然免疫
            # 再投递);父帧罩 anyio shield 等它跑完(退出时序确定、测试可依赖;
            # shield 万一失效,suppress 兜底,清理任务仍独立跑完)。
            # 真值机对照:旧形态 lease/reader/unsub/aclose 全 False、泄漏 2 条;
            # 本形态全 True、全部归还 —— 同机同轮、单变量。
            async def _sse_cleanup() -> None:
                # 3.9.0:条件释放活跃房租约 —— 摘掉**本标签页**;仅当已无任何
                # 活页时才整把删除(房不符则完全 no-op)。失败无害(TTL 兜底)。
                if _lease_on and room:
                    with contextlib.suppress(BaseException):
                        await ST.bus.active_room_release(
                            _lease_uid, str(room), _lease_tab,
                            int(time.time() * 1000), _lease_ttl_ms)
                if reader is not None:    # 可能还没走到 create_task 就异常了
                    reader.cancel()
                    with contextlib.suppress(BaseException):
                        await reader
                with contextlib.suppress(BaseException):
                    await pubsub.unsubscribe(ST.bus.draw_channel(room))
                if _lease_ch:
                    with contextlib.suppress(BaseException):
                        await pubsub.unsubscribe(_lease_ch)
                with contextlib.suppress(BaseException):
                    await pubsub.aclose()   # 内含归还连接 —— 全链的终点
            try:
                _ct = asyncio.get_running_loop().create_task(_sse_cleanup())
            except BaseException:           # 事件循环正在关停等极端场景
                _ct = None
            if _ct is not None:
                _SSE_CLEANUPS.add(_ct)
                _ct.add_done_callback(_SSE_CLEANUPS.discard)
                # 等它跑完 —— 但**有界**。清理链有 5 个 await(租约释放 /
                # reader 归队 / 两次 unsubscribe / aclose),每个都可能撞上 Redis
                # 侧慢响应。redis-py 8.0.1 的默认 socket_timeout=5s 给了每次读一个
                # 上界(实测确认:默认值就是 5,不是无限),但**逐个累加**最坏仍是
                # 20~25s —— 无限等就等于把请求帧钉住这么久,而且 shield 屏蔽取消,
                # 期间连关停都收不回它。实测:清理卡 3s → 无限等形态帧被钉 3.20s,
                # 有界形态 0.70s 就释放。asyncio.wait 到点只是**停止等待**,
                # 不取消 _ct —— _SSE_CLEANUPS 持强引用,它继续在后台跑到底。
                with contextlib.suppress(BaseException):
                    with anyio.CancelScope(shield=True):
                        await asyncio.wait({_ct}, timeout=SSE_CLEANUP_WAIT_S)
            else:
                # create_task 都失败(事件循环关停等):就地尽力清理一次,
                # 总好过什么都不做直接把连接丢掉。
                with contextlib.suppress(BaseException):
                    await _sse_cleanup()

    return EventSourceResponse(gen())


# ══════════════════════════════════════════════════════════════════════════════
# 九法 VIP · 开通与充值(4.2.0)
# ------------------------------------------------------------------------------
# 这些端点**刻意不接 _vip_guard** —— free 档必须能下单,这是他唯一的出口。
# 但它们仍走 guard() 常规通道(有效会话 + X-JF-Auth CSRF 头),不是公开接口。
# ══════════════════════════════════════════════════════════════════════════════
_VIP_ERR = {
    "disabled":       (503, "本部署未启用九法VIP"),
    "bad_plan":       (400, "档位不存在或已下架"),
    "throttled":      (429, "操作过于频繁,请稍后再试"),
    "gateway":        (502, "支付网关暂时不可用,请稍后重试"),
    "db":             (500, "服务暂时不可用,请稍后重试"),
    "conflict":       (409, "订单冲突"),
    "not_found":      (404, "订单不存在"),
    "order_not_found": (404, "订单不存在"),
    "card_not_found": (404, "卡密不存在,请核对后重输"),
    "card_used":      (400, "该卡密已被使用"),
    "card_disabled":  (400, "该卡密已作废,请联系发卡方"),
    "card_plan_gone": (500, "该卡密对应的档位已下架,请联系管理员"),
    "card_shape":     (400, "卡密格式不正确"),
    "user_gone":      (404, "账号不存在"),
    "forbidden":      (403, "未开启模拟模式"),
    "not_simulate":   (400, "该订单不是模拟订单"),
    "expired":        (400, "订单已过期,请重新下单"),
    # 4.4.1 站点分流:本站(代理镜像站)不提供在线扫码付款,只走卡密。
    # 文案与前端提示同源一句话 —— 用户在页面上看到的、和绕过前端直调 API 时
    # 收到的,必须是同一个说法。
    "site_no_pay":    (403, "本站仅支持卡密开通,请联系客服购买"),
}


def _vip_fail(err: str, extra: Optional[dict] = None) -> JSONResponse:
    code, msg = _VIP_ERR.get(err, (400, "操作失败,请稍后重试"))
    body = {"ok": False, "error": err, "message": (extra or {}).get("message") or msg}
    return JSONResponse(body, status_code=code)


def _vip_user(request: Request):
    """VIP 端点的身份取用。None = 不可用,具体语义交 _vip_deny 判定。"""
    if not jfvip.enabled():
        return None
    return _req_user(request)


def _vip_deny(request: Request) -> JSONResponse:
    """身份取不到时的**正确**错误语义(复审补:初版一律回 503,把「未登录」
    也说成「本部署未启用」,用户会一头雾水且前端无法据此拉起登录门)。"""
    if not jfvip.enabled():
        return _vip_fail("disabled")
    return JSONResponse({"ok": False, "error": "auth_required",
                         "message": "请先登录"}, status_code=401)


@app.get("/api/vip/state")
async def vip_state_ep(request: Request):
    """当前账号的两条时间线 + 档位表 + 能力矩阵(开通页与对比层的数据源)。"""
    if not jfvip.enabled():
        return {"ok": True, "enabled": False}
    u = _req_user(request)
    if u is None:
        return JSONResponse({"ok": False, "error": "auth_required",
                             "message": "请先登录"}, status_code=401)
    st = {}
    with contextlib.suppress(Exception):
        st = await jfvip.vip_state(u.user_id)
    return {"ok": True, "enabled": True, "tier": u.tier,
            "userName": u.user_name,
            "ddDueTime": u.due_time_iso, "ddAlive": bool(u.dd_alive),
            "jfVipUntil": st.get("vipUntil", ""), "jfVipDays": st.get("vipDays"),
            "plans": jfvip.plans(), "matrix": vip_matrix(),
            # 4.4.1:与 /api/auth/session 的 jf.site **同源一份声明**(都走
            # userauth.jf_site)—— 两个端点对同一个 Host 给出不同答案是最难查的
            # 一类失真,故不给第二份实现。
            "site": userauth.jf_site(request),
            "simulate": bool(getattr(settings.userauth, "jf_pay_simulate", False))}


@app.post("/api/vip/order/create")
async def vip_order_create(request: Request):
    u = _vip_user(request)
    if u is None:
        return _vip_deny(request)
    # ── 4.4.1 站点分流闸:**全项目唯一一处**按站点拒绝的写点 ────────────────────
    # 只闸「新建订单」,刻意**不闸** order/status、order/reconcile、simulate-pay:
    #   那三条是**钱的回收路径**,不闸有两条经核查的理由:
    #   ① 闸它们**零收益** —— 镜像站上根本创建不出订单(正是被下面这道闸挡的),
    #      没有任何可被滥用的东西需要拦;
    #   ② 闸它们有**真实资损**风险,场景是**配置变更**而非跨站访问:某域名原本在
    #      直营名单里(用户在该 origin 下过单、本机存着在途单标记),之后被移出名单、
    #      或首次启用本特性时把它划进了镜像 —— 此刻那些标记仍在,boot 与 closePay
    #      都会触发 payRecover() → reconcile;若被拒,这笔已付的钱就永远停在
    #      pending、VIP 与小叮当都不到账,**且没有任何自动救回路径**
    #      (jfpay.py 安全不变量 8 说的正是这个场景)。
    #   ★ 复审更正:初版这里写的理由是「用户在直营站付了款、再打开代理给的镜像站
    #      链接,payRecover 会去 reconcile」——**那是错的**。在途单标记存在
    #      localStorage(app.js store.get,见其第 321 行),而 localStorage 按 origin
    #      隔离,镜像站根本读不到直营站的标记,那条路径不存在。结论不变,但理由
    #      必须是上面两条 —— 拿一个想当然的场景去支撑一个正确的决定,下一个人会
    #      照着那个场景做出错误的推广。
    # 顺序上放在限频之前(限频在 jfpay.create_order 内):不该为一个注定要拒的
    # 请求消耗用户的下单配额。
    _site = userauth.jf_site(request)
    if not _site.get("pay", True):
        return _vip_fail("site_no_pay")
    try:
        body = await request.json()
    except Exception:                  # noqa: BLE001
        body = {}
    if not isinstance(body, dict):     # 5.2.0:数组/字符串等合法 JSON 不再 500(与登录端点同类修复)
        body = {}
    err, out = await jfpay.create_order(u.user_id, u.user_name,
                                        str(body.get("plan") or ""),
                                        userauth.client_ip(request))
    if err:
        return _vip_fail(err, out)
    return {"ok": True, **out}


@app.get("/api/vip/order/status")
async def vip_order_status(request: Request, orderNo: str = Query("")):
    u = _vip_user(request)
    if u is None:
        return _vip_deny(request)
    err, out = await jfpay.query_and_settle(u.user_id, u.user_name, str(orderNo))
    if err:
        return _vip_fail(err, out)
    return {"ok": True, **out}


@app.post("/api/vip/order/simulate-pay")
async def vip_order_simulate(request: Request, orderNo: str = Query("")):
    u = _vip_user(request)
    if u is None:
        return _vip_deny(request)
    err, out = await jfpay.simulate_pay(u.user_id, u.user_name, str(orderNo))
    if err:
        return _vip_fail(err, out)
    return {"ok": True, **out}


@app.post("/api/vip/order/reconcile")
async def vip_order_reconcile(request: Request):
    """对账兜底:后端亲自向网关查证,救回前端轮询停掉后卡住的已付订单。

    4.2.2:本端点在 4.2.1 里**全仓库无人调用**(前端零引用、管理台零引用、无定时
    任务),于是 jfpay 的安全不变量 8 只停留在注释上 —— 用户扫码付款后关掉标签页,
    订单永远停在 pending,钱收了什么都没给。现由前端 `payRecover()` 在
    「本机有在途单标记」时触发(关支付层时 + 每次开机各一次)。

    限频是新加的:本端点单次最多向网关查 10 笔,放大倍数是下单的 10 倍。
    """
    u = _vip_user(request)
    if u is None:
        return _vip_deny(request)
    if not await jfvip.reconcile_rate_ok(u.user_id):
        return _vip_fail("throttled")
    try:
        return {"ok": True, **(await jfpay.reconcile(u.user_id, u.user_name))}
    except Exception as e:                 # noqa: BLE001
        # 4.2.2 复审补:本端点原是**唯一**既无 try 也无 suppress 的 VIP 端点
        # (create / redeem 有 try,state 有 suppress)。用户库在公网、RTT 受安全组
        # 摆布,一次抖动就是 500。本端点自 4.2.2 起是热路径(每次相关开机都打),
        # 不该因为一次库抖动就刷 500 日志。
        print(f"[九法VIP] 对账兜底异常: {e!r}")
        return _vip_fail("db")


@app.post("/api/vip/redeem")
async def vip_redeem(request: Request):
    """卡密开通。失败限频只在**失败**时计数(成功不消耗配额)。"""
    u = _vip_user(request)
    if u is None:
        return _vip_deny(request)
    try:
        body = await request.json()
    except Exception:                  # noqa: BLE001
        body = {}
    if not isinstance(body, dict):     # 5.2.0:数组/字符串等合法 JSON 不再 500(与登录端点同类修复)
        body = {}
    card = jfvip.norm_card(body.get("card"))
    if not await jfvip.redeem_fail_ok(u.user_id):
        return _vip_fail("throttled")
    if not jfvip.card_valid_shape(card):
        # 形态错在本地即拦(不打库),但仍计入失败配额 —— 否则可用畸形串免费探测。
        await jfvip.redeem_fail_bump(u.user_id)
        return _vip_fail("card_shape", {"message": jfvip.card_shape_hint(card)})
    try:
        err, out = await jfvip.grant_by_card(u.user_id, u.user_name, card)
    except Exception as e:             # noqa: BLE001
        print(f"[九法VIP] 卡密开通异常: {e!r}")
        return _vip_fail("db")
    if err:
        await jfvip.redeem_fail_bump(u.user_id)
        return _vip_fail(err)
    return {"ok": True, **out}


@app.get("/api/vip/orders")
async def vip_orders(request: Request,
                     page: int = Query(1, ge=1, le=100_000),
                     size: int = Query(20, ge=1, le=100)):
    """我的开通记录 = 订单流水 + 开通流水(卡密/管理员开通也在内,口径统一)。"""
    u = _vip_user(request)
    if u is None:
        return _vip_deny(request)
    orders = grants = {"items": [], "total": 0}
    with contextlib.suppress(Exception):
        orders = await jfvip.orders_page(page, size, uid=u.user_id)
    with contextlib.suppress(Exception):
        grants = await jfvip.grants_page(page, size, uid=u.user_id)
    return {"ok": True, "orders": orders, "grants": grants}


@app.get("/api/version")
async def version():
    return {"ok": True, "version": VERSION, "mode": "async-readonly"}


# ── 静态兜底的对外白名单(5.3.0 复查补漏)─────────────────────────────────────────
# 实测:后端 README 的裸机运行方式把 STA_STATIC_DIR 指向**仓库根**,此时兜底路由会把整个仓库当静态
# 文件对外提供 —— /backend_async/deploy/.env(全部口令与密钥)、deploy/kgdata/accounts.json(酷狗账号)、
# config.yaml 全部 200 可下载。生产镜像的静态根只有前端构建产物,不受影响;本白名单让两种情况
# 同样安全:只提供 deploy/Dockerfile 打进镜像的那份前端产物清单,其余路径一律按「不存在的路径」应答。
# (清单与 Dockerfile 的 COPY 行由 tests/test_static_allowlist.py 守着同步;admin.html 刻意不在其中。)
_PUBLIC_STATIC_FILES = frozenset({"index.html", "sw.js", "favicon.ico", "favicon.png", "manifest.webmanifest"})
_PUBLIC_STATIC_DIRS = frozenset({"assets", "jiufa", "mock", "cdn", "icons"})


def _is_public_static(base: str, candidate: str) -> bool:
    """candidate(已 realpath、已确认在 base 之内)是否属于可对外提供的前端产物。"""
    parts = os.path.relpath(candidate, base).replace(os.sep, "/").split("/")
    if any(p.startswith(".") for p in parts):          # 任何一级以点开头(.env / .git / .deploy-state)不给
        return False
    if len(parts) == 1:
        return parts[0] in _PUBLIC_STATIC_FILES
    return parts[0] in _PUBLIC_STATIC_DIRS


# ── 管理台页面(/<入口路径>,默认 /admin-xdd);必须在 _mount_static 的 catch-all 之前注册 ──
def _admin_html_path() -> Optional[str]:
    base = settings.static_dir or os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    for d in (base, os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
              os.getcwd()):
        p = os.path.join(d, "admin.html")
        if os.path.isfile(p):
            return p
    return None


def _admin_html_response(path: str, request: Request) -> Response:
    """以 no-cache 提供 admin.html,并正确处理条件请求(If-None-Match / If-Modified-Since
    → 304)。裸 FileResponse 在 Starlette 0.49 不做 304,会让这个 ~7KB 页面在 no-cache 下
    每次导航全量重传;此处复刻 StaticFiles 的 is_not_modified 语义,命中即 304、0 body,
    未命中才回全量。既保住「前端修复必达」(no-cache 强制每次 revalidate),又拿回省带宽。

    注意:FileResponse 构造时不填 ETag/Last-Modified(裸构造时在 ASGI __call__ 里 stat 后才补),
    所以这里显式先 os.stat 并把 stat_result 传给构造器 —— 构造器内部即调 set_stat_headers 预填,
    ETag 与 Starlette 正常发出的完全一致(md5(f'{mtime}-{size}')),不会因算法不一致导致
    revalidate 永不命中;同一个 stat_result 也让 __call__ 复用,消除 200 路径的 double-stat。"""
    try:
        st = os.stat(path)
    except OSError:
        # stat 失败极罕见(文件刚被删):退回裸 FileResponse,让它自己处理/报错。
        return FileResponse(path, headers={"Cache-Control": "no-cache"})
    resp = FileResponse(path, headers={"Cache-Control": "no-cache"}, stat_result=st)
    etag = resp.headers.get("etag")
    req_h = request.headers
    not_modified = False
    if (inm := req_h.get("if-none-match")) and etag:
        not_modified = etag in [t.strip(" W/") for t in inm.split(",")]
    elif ims := req_h.get("if-modified-since"):
        from email.utils import parsedate
        try:
            a, b = parsedate(ims), parsedate(resp.headers.get("last-modified", ""))
            not_modified = a is not None and b is not None and a >= b
        except (TypeError, ValueError):
            not_modified = False
    if not_modified:
        # 304 回带校验头(ETag/Last-Modified)但不带 body;沿用 no-cache。
        keep = {k: v for k in ("etag", "last-modified", "cache-control")
                if (v := resp.headers.get(k)) is not None}
        return Response(status_code=304, headers=keep)
    return resp


def _admin_page_headers(resp: Response) -> Response:
    """入口页的三枚响应头(5.3.0):
      · Referrer-Policy: strict-origin-when-cross-origin —— 跨源请求只带**源**(协议 + 域名),
        入口路径不随 Referer 流向任何第三方(人机验证脚本、页面里点开的外链)。这是现代浏览器的
        默认值,显式发出是为了不依赖浏览器版本(旧默认 no-referrer-when-downgrade 会把完整地址
        发给第三方)。刻意**不用**更严的 same-origin / no-referrer:人机验证供应商按来源域名
        校验站点密钥(reCAPTCHA 在 no-referrer 下直接报域名无效是已知事实),不给源有把挂件
        弄坏的风险,而「源」本身并不泄露入口;
      · X-Frame-Options: DENY —— 后台不允许被任何页面套进 iframe(点击劫持);
      · X-Robots-Tag —— 与页面里的 <meta robots> 双保险,入口不进搜索引擎。"""
    resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["X-Robots-Tag"] = "noindex, nofollow"
    return resp


@app.get(_ADMIN_PAGE, include_in_schema=False)
@app.get(_ADMIN_PAGE + "/", include_in_schema=False)     # 手滑多敲一个斜杠也进得来
async def admin_page(request: Request):
    if not admin_auth.enabled():
        return JSONResponse(
            {"ok": False, "error": "admin_disabled",
             "hint": "管理台未启用:设置 STA_ADMIN_PASSWORD(或 _HASH)后重启 web"},
            status_code=503)
    p = _admin_html_path()
    if not p:
        return JSONResponse(
            {"ok": False, "error": "admin_html_missing",
             "hint": "未找到 admin.html:请设置 STA_STATIC_DIR 指向前端目录"
                     "(compose 镜像内为 /app/static)"},
            status_code=404)
    return _admin_page_headers(_admin_html_response(p, request))


# ── 静态资源缓存口径 ────────────────────────────────────────────────────────
# 「代码类」= 承载逻辑、改一次必须立刻到达所有人的文件。
_NO_CACHE_EXT = frozenset({".js", ".mjs", ".css", ".html", ".htm",
                           ".json", ".webmanifest", ".map"})


def _is_code_asset(path: str) -> bool:
    return os.path.splitext(path)[1].lower() in _NO_CACHE_EXT


class _CodeNoCacheStatic(StaticFiles):
    """给静态挂载补 Cache-Control —— 与 index.html / admin.html 既有口径拉齐。

    背景(实地复现,非推断):Starlette 0.49 的 StaticFiles 只发 ETag + Last-Modified,
    **不发 Cache-Control**。按 RFC 7234,响应无显式新鲜期但有 Last-Modified 时,
    浏览器启用启发式缓存(常见实现 =(now − Last-Modified)×10%),在此期间**根本不回源
    revalidate**。实测:服务端文件换新后普通刷新仍拿旧文件、服务器零命中 —— 等于
    「前端修复对老用户不可达」。曾因此让一批毒产物(二次混淆导致 selfDefending 护甲
    自爆、整页崩溃)在修复上线后仍持续崩用户浏览器。

    口径(与 _admin_html_response 同款权衡):
      · 代码类(见 _NO_CACHE_EXT)→ no-cache:强制每次 revalidate;StaticFiles 原生
        条件请求命中即 304、0 body(NotModifiedResponse 的透传白名单含 cache-control,
        故 304 也带 no-cache)—— 修复必达,几乎不多耗带宽。
      · 其余(图片/字体/音视频)→ **不动**,维持既有行为。这些文件多为内容寻址名
        (改内容即改 URL),且 /jiufa 有 269 个文件 / 26MB,全量 no-cache 会让真机每次
        开游戏多打数百个条件请求 —— 那是拿真机性能换缓存正确性,不划算。
    """

    def file_response(self, full_path, stat_result, scope, status_code: int = 200) -> Response:
        resp = super().file_response(full_path, stat_result, scope, status_code=status_code)
        # 200 走 FileResponse、304 走 NotModifiedResponse;两者都在此补头(白名单含 cache-control)
        if _is_code_asset(str(full_path)):
            resp.headers["Cache-Control"] = "no-cache"
        return resp


# ── 静态 SPA(前端)+ 兜底 ────────────────────────────────────────────────────
def _mount_static() -> None:
    # 4.4.3:每挂一个目录就把前缀记进 _STATIC_MOUNT_PREFIXES —— 压缩缓存的作用域
    # 由**实际挂载结果**决定,不另维护一份名单(两份名单迟早打架)。目录不存在时
    # 本来就不 mount,前缀也就不会进表,缓存层自然不会碰到它。
    global _STATIC_MOUNT_PREFIXES
    mounted: list = []
    static_dir = settings.static_dir
    if not static_dir or not os.path.isdir(static_dir):
        return
    assets = os.path.join(static_dir, "assets")
    if os.path.isdir(assets):
        # _CodeNoCacheStatic:代码类补 no-cache(见其 docstring 的实地复现记录);
        # 图片/字体等维持既有行为。裸 StaticFiles 会让前端修复对老用户不可达。
        app.mount("/assets", _CodeNoCacheStatic(directory=assets, html=True), name="assets")
        mounted.append("/assets/")
    for sub in ("jiufa", "cdn", "icons", "mock"):
        d = os.path.join(static_dir, sub)
        if os.path.isdir(d):
            # html=True:目录请求(如 iframe 的 /jiufa/)返回该目录 index.html。
            # 缺此参数时 Starlette StaticFiles 对 /jiufa/ 直接 404 → 游戏 iframe 黑屏
            # (旧 stdlib http.server 目录默认返 index.html,故原项目无此问题)。
            app.mount(f"/{sub}", _CodeNoCacheStatic(directory=d, html=True), name=sub)
            mounted.append(f"/{sub}/")

    _STATIC_MOUNT_PREFIXES = tuple(mounted)

    @app.get("/{full_path:path}")
    async def spa_fallback(full_path: str, request: Request):
        # /api/* 未命中交给 FastAPI 返回 404;其余回 index.html(SPA 路由)
        if full_path.startswith("api/"):
            return JSONResponse({"ok": False, "error": "not_found"}, status_code=404)
        base = os.path.realpath(static_dir)
        candidate = os.path.realpath(os.path.join(base, full_path))
        # 路径穿越防护:realpath 后必须仍在静态根之内(拦 %2e%2e/.. 等)
        # 5.3.0:admin.html **不经静态兜底对外提供** —— 后台页面只从配置的入口路径进。
        # 实测旧行为:/admin.html 直接 200 吐出后台页面,连「后台是否启用」都不看(未启用时
        # /admin 回 503,/admin.html 照样 200)—— 入口改了名,这条旁路还在就等于没改。
        # 现在它与任何不存在的 .html 路径走同一分支(回 SPA 壳),从外面分辨不出。
        # 5.3.0 复查:再加前端产物白名单(_is_public_static)—— 静态根若是仓库根,.env 等也不会被提供。
        if (full_path and candidate.startswith(base + os.sep) and os.path.isfile(candidate)
                and os.path.basename(candidate).lower() != "admin.html"
                and _is_public_static(base, candidate)):
            # 静态根下的其余代码类(sw.js / manifest.webmanifest / 根级 js|css|json)
            # 同享 no-cache + 条件 304 —— 理由同 index.html(_admin_html_response 本就通用)。
            # **sw.js 尤其关键**:它是清退「旧缓存型 Service Worker」的清道夫(只有
            # skipWaiting+claim、无 fetch 处理器)。旧 SW 会用 CacheStorage 扣住旧文件,
            # 硬刷新与清 HTTP 缓存都穿不透(实地复现:仅无痕/注销 SW 可解)—— 清道夫若
            # 自己被启发式缓存扣住,用户就永远出不来。图片/字体仍走裸 FileResponse(行为不变)。
            if _is_code_asset(candidate):
                return _admin_html_response(candidate, request)
            return FileResponse(candidate)
        index = os.path.join(base, "index.html")
        if os.path.isfile(index):
            # 与后台入口页同款 no-cache + 条件 304(复用 _admin_html_response,函数本就通用):
            # 裸 FileResponse 无 Cache-Control → 浏览器启发式缓存旧 index(带旧 ?v= 资源
            # 链接),前端修复(如 3.3.4 判定徽标)不必达。no-cache 强制每次 revalidate,
            # 命中 ETag 即 304、0 body —— 修复必达且不多耗带宽。
            return _admin_html_response(index, request)
        return JSONResponse({"ok": False, "error": "no_static"}, status_code=404)


_mount_static()
