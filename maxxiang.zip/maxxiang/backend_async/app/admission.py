"""
admission.py — 批量准入控制器(「同时添加数千房」的削峰核心)
================================================================================
把「一次性添加 N 房」这件事从**惊群 + 重排风暴 + 逐房往返**变成一次**受控、平滑、
批量**的准入操作。被 Web 的 /api/monitor/add-bulk 与 scripts/seed_rooms 共用。

一次批量添加会经过四道闸门(逐一对应旧实现的四类隐患):

  ① 去重 + 校验          —— 输入可能有重复/非法房号;先归一化,避免重复解析/写入。
  ② 有界并发归一          —— 归一(短号→真实号)并发被 canon_concurrency 钳住,且
                            每次繁星请求还要过 fanxing 令牌桶(见 StarMeta._gate)。
                            双重约束下,数千房的归一被抹平成平滑曲线,不再惊群打爆
                            酷狗繁星(旧实现:400~1600+ req/s 无任何限流)。
  ③ 批量落库/登记        —— 房间登记(PG rooms)与名录(Redis)批量写入,单次
                            pipeline / executemany 往返,替代逐房 N 次往返。
  ④ 错峰起抓            —— 首次 MainPage 任务在 warmup_window_ms 窗口内均匀铺开,
                            不再全排同一毫秒。消除「几千任务同秒竞争令牌 → 反复
                            +1000ms 重排」的重排风暴(实测旧法排空 5000 房产生近 3 万
                            次寄生 ZADD 弹跳;铺开后为 0)。

归一失败的房**不按原号开抓**(mapi 不校验房号,按短号抓会得到另一路「凭空局」),
而是进挂起集,由 worker janitor 周期重试归一 —— 与单房 /api/monitor/add、旧
ensure_room/_resolve_loop 语义完全一致。
"""
from __future__ import annotations

import asyncio
import time
from typing import Any, Dict, List, Optional, Tuple

from .redis_bus import RedisBus, now_ms, task_mainpage
from .settings import AdmissionCfg


def _normalize(rooms: List[str]) -> List[str]:
    """去重 + 校验 + 保序:仅保留 2~12 位数字房号,去掉重复(首次出现为准)。"""
    seen = set()
    out: List[str] = []
    for raw in rooms:
        r = str(raw or "").strip()
        if not r.isdigit() or not (2 <= len(r) <= 12):
            continue
        if r in seen:
            continue
        seen.add(r)
        out.append(r)
    return out


async def _canon_bounded(star, rooms: List[str], concurrency: int, do_canon: bool
                         ) -> List[Tuple[str, str, bool]]:
    """有界并发归一。返回 [(alias, rid, definitive), ...],顺序与输入一致。
    do_canon=False 时按原号直通(definitive=True;等价旧 --no-canon)。"""
    if not do_canon:
        return [(r, r, True) for r in rooms]
    sem = asyncio.Semaphore(max(1, int(concurrency)))
    results: List[Optional[Tuple[str, str, bool]]] = [None] * len(rooms)

    async def one(idx: int, alias: str) -> None:
        async with sem:               # 并发上界(叠加 StarMeta 内的繁星令牌桶)
            try:
                rid, definitive = await star.canon(alias)
            except Exception:
                rid, definitive = alias, False
            results[idx] = (alias, rid, bool(definitive))

    await asyncio.gather(*(one(i, a) for i, a in enumerate(rooms)))
    return [r for r in results if r is not None]


async def admit_rooms(rooms: List[str], *, bus: RedisBus, db, star,
                      cfg: AdmissionCfg, do_canon: bool = True,
                      aliases: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """批量准入入口。返回结构化结果(便于 API/CLI 复用与前端展示)。"""
    t0 = time.monotonic()
    aliases = aliases or {}
    normalized = _normalize(rooms)
    requested = len(rooms)
    skipped = requested - len(normalized)

    if not normalized:
        return {"ok": True, "requested": requested, "deduped": 0, "added": 0,
                "pending": 0, "skipped": skipped, "truncated": 0, "elapsed_ms": 0,
                "warmup_window_ms": cfg.warmup_window_ms, "added_rooms": [],
                "pending_rooms": []}

    # 护栏:单次批量上限(防止误传超大列表)
    truncated = 0
    if len(normalized) > cfg.max_bulk:
        truncated = len(normalized) - cfg.max_bulk
        normalized = normalized[:cfg.max_bulk]

    # ② 有界并发归一(每请求过繁星令牌桶)
    resolved = await _canon_bounded(star, normalized, cfg.canon_concurrency, do_canon)

    # 分区:definitive(真实号,dedup —— 多个短号可能归一到同一真实房)/ pending
    definitive: Dict[str, str] = {}          # rid -> alias(首个别名为准)
    alias_of_rid: Dict[str, str] = {}
    pending: List[str] = []
    for alias, rid, ok in resolved:
        display_alias = aliases.get(alias, alias)
        if ok and str(rid).isdigit():
            if rid not in definitive:
                definitive[rid] = display_alias
                alias_of_rid[rid] = alias
        else:
            pending.append(display_alias)

    # ③ 批量落库 + 登记
    #   房间登记(PG):definitive 置为 active;pending 置为 pending。
    room_rows: List[tuple] = [(rid, al, True, False) for rid, al in definitive.items()]
    #   短号别名行(alias≠rid)清净其 pending 双影(与单房 add 一致)
    for rid, alias in alias_of_rid.items():
        if alias != rid:
            room_rows.append((alias, alias, False, False))
    for al in pending:
        room_rows.append((al, al, False, True))
    await db.upsert_rooms_bulk(room_rows, batch_size=cfg.batch_size)

    #   名录(Redis):批量入册 / 批量挂起
    await bus.add_rooms_bulk([(rid, al) for rid, al in definitive.items()])
    #   转正的原始输入别名一并清出挂起集(add_rooms_bulk 已清 rid+显示别名;此处再清
    #   原始短号,覆盖「自定义别名 + 该短号此前挂起」的边界,与单房 add 的
    #   pending_remove(room) 语义对齐)。清理幂等,与显示别名重复也无害。
    await bus.pending_remove_bulk(list(alias_of_rid.values()))
    if pending:
        await bus.pending_add_bulk(pending)

    # ④ 错峰起抓:首次 MainPage 在 warmup 窗口内均匀铺开(消除重排风暴)
    members = [task_mainpage(rid) for rid in definitive.keys()]
    await bus.schedule_spread(members, now_ms(), cfg.warmup_window_ms)

    elapsed_ms = int((time.monotonic() - t0) * 1000)
    return {
        "ok": True,
        "requested": requested,
        "deduped": len(normalized),
        "added": len(definitive),
        "pending": len(pending),
        "skipped": skipped,
        "truncated": truncated,
        "elapsed_ms": elapsed_ms,
        "warmup_window_ms": cfg.warmup_window_ms,
        "added_rooms": sorted(definitive.keys()),
        "pending_rooms": sorted(pending),
    }
