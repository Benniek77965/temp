"""
userdb_pool.py — 用户库「多网络入口」连接池路由(4.5.0)
================================================================================
定位:让 `STA_USERDB_HOST` 可以填**多个 IP**,它们是**同一台 MySQL 的多个公网
入口**(多绑弹性 IP / 多台端口转发机),用来把「单个弹性 IP 出口带宽有限」这一
物理瓶颈横向摊开;同时自动识别哪些入口此刻可用,坏了绕开、好了自动收回。

── 为什么是「客户端分流」而不是「前面架一层代理」──────────────────────────────
瓶颈在**弹性 IP 的公网出口**。若在观测台侧架 L4 代理(HAProxy/nginx stream),
代理确实能做健康检查与轮询,但它**无法做查询级重试**(一条 TCP 连接一旦选定
后端就钉死了),也拿不到「这条查询走了哪个入口、搬了多少字节」的账。若把代理
架在数据库侧,那台代理自己又只有一个出口 IP —— 瓶颈原地不动。故分流必须发生
在**客户端**,即本模块。

── 正确性的地基(务必读懂再改)────────────────────────────────────────────────
N 个入口是**同一个 mysqld**,不是主从、不是多库。由此:
  · 行锁/事务/自增/唯一键全部是全局的 —— 三处手工事务(userauth._register_tx /
    jfpay._reuse_after_dup / jfvip._grant_tx)各自从**某一个**入口的池里取一条
    连接跑完整个事务,天然不跨入口,语义与单入口时逐字节一致;
  · 不存在复制延迟,也就不存在「写完读不到」的一致性问题。
这条地基一旦不成立(有人把某个 IP 填成了从库或另一个库),会**静默**写坏会话与
订单。因此本模块把它从「假设」升级为「每轮探活都校验的不变式」:见 _identity()。

── 三层可用性判定 ──────────────────────────────────────────────────────────
  ① 主动探活:后台任务按 probe_s 逐入口跑一次身份/RTT 探测(顺带保温连接);
  ② 被动熔断:**只有传输层错误**(errno ≥ 2000 / OSError / 超时)才记在入口
     头上并触发熔断;`1040 连接数超限` `1045 口令错` `1213 死锁` 这类是**库/语句
     的事,不是入口的事** —— 若拿它们熔断,会把全部入口一起打死(它们本来就是
     同一个库,换入口也一样报),故一律不计入;
  ③ 身份校验:指纹不一致 = 这个 IP 根本不是同一个库 → **永久隔离**并醒目告警,
     绝不参与分流(重启才复活;这是「宁可少一个入口,不可写错一个库」)。

── 分流算法:P2C(随机取二择优)────────────────────────────────────────────
在健康入口里随机取两个,比 `(在飞数+1)/权重`,取小者;并列时比 EWMA RTT。
为什么不是「按字节速率配额」:带宽打满时,该入口的查询会变慢 → 连接被占更久
→ 在飞数立刻上升,**在飞数本身就是带宽压力的实时无偏指标**,而字节速率是滞后
指标。P2C 相对「每次都挑最闲的」还多一个好处:不会所有请求同时涌向同一个刚
变闲的入口(羊群)。字节计量仍然做,但只用于**观测**(见 bytes_in/out)——
那是运维验证「多入口到底有没有把带宽叠加上去」的唯一硬证据。

── 本模块修掉的三个既有隐患(均为实地核查所得,非推断)──────────────────────
  1. **没有读超时**:aiomysql 0.2.0 的 Connection 只有 `connect_timeout`,没有
     `read_timeout`(逐字核对 aiomysql/connection.py 参数表)。入口带宽打满、
     TCP 还活着但数据不走时,查询会**无限期挂住** —— 也就是说,今天根本探测不到
     「这个 IP 不可用」。本模块给每次查询套 `asyncio.wait_for`。
  2. **整池换血会被一条挂死的连接堵住**:aiomysql/pool.py 的 `wait_closed()` 要
     `await self._cond.wait()` 直到**所有在用连接归还**。旧 `_q` 在连接层报错时
     调 `close() + wait_closed()`,叠加隐患 1 就会把重建路径整个堵死。本模块改用
     `terminate()`(立刻关掉在用连接,不等归还)。
  3. **建池无锁**:旧 `_ensure_pool` 并发进入会各建一个池、最后一个覆盖前面的。
     本模块用 `asyncio.Lock` 收口。

── 超时后连接必须销毁,绝不还池 ───────────────────────────────────────────────
`wait_for` 取消一条正在读结果集的连接,协议状态就**未知**了(半个结果集还在
socket 缓冲里)。这种连接若还回池,下一个使用者会读到上一条查询的残包 —— 是最
难查的一类脏数据。故超时/传输错一律先 `conn.close()` 再 release;aiomysql 的
`Pool.release` 对 `conn.closed` 的连接只是从 _used 里摘掉、不放回 _free
(已逐行核对 pool.py:207),因此这个顺序是安全且必要的。
"""
from __future__ import annotations

import asyncio
import contextvars
import functools
import contextlib
import math
import random
import re
import time
from typing import Any, Dict, List, Optional, Sequence, Tuple

try:
    import aiomysql
except Exception:                       # noqa: BLE001 —— 未装驱动时上层整体禁用
    aiomysql = None                     # type: ignore[assignment]


# ── 配置解析 ──────────────────────────────────────────────────────────────────
# 分隔符与 userauth._HOST_SPLIT 同款(半角逗号/分号/空白 + 中文逗号与顿号):
# 运维从聊天窗口或文档粘贴时的高频差错,容忍掉比让人对着一个不报错的空列表发呆强。
_SPLIT = re.compile(r"[,\s;、，]+")
# 单个入口的写法:  IP  |  IP:PORT  |  IP*W  |  IP:PORT*W
#   ·「*W」是**相对带宽权重**(默认 1)。譬如主入口 10Mbps、备用入口 5Mbps,
#     写 `1.2.3.4*2, 5.6.7.8*1`,分流大致按 2:1。权重只影响分流比例,不影响
#     可用性判定。
#   · 选 `*` 而不是 `#`/`|`:`#` 在 .env 里是行注释起始,`|` 是 shell 管道;
#     `*` 在 docker-compose 的 env_file 与变量插值里都按字面量传递(已核查:
#     deploy-maxxiang.sh 既不 source .env、也不碰 STA_USERDB_*),不会被展开。
_ONE = re.compile(r"^(?P<host>\[[0-9A-Fa-f:]+\]|[^:*\s]+)"
                  r"(?::(?P<port>\d{1,5}))?"
                  r"(?:\*(?P<weight>\d+(?:\.\d+)?))?$")

# 传输层错误码下界:MySQL 服务端错误是 1000–1999,客户端/连接层错误是 2000+
# (pymysql/constants/CR.py:CR_CONNECTION_ERROR=2002 / CR_SERVER_GONE_ERROR=2006 /
#  CR_SERVER_LOST=2013)。这条线就是「该不该赖到这个入口头上」的分界。
_CLIENT_ERRNO_MIN = 2000

# 熔断冷却阶梯(秒):连败 1 次冷却 2s,之后翻倍,封顶 60s。刻意做成常量而非配置项
# —— 它自带指数退避,已经自适应;多一个旋钮只是多一个能被调错的地方。
_BREAK_STEPS = (2.0, 4.0, 8.0, 16.0, 32.0, 60.0)
# 空闲多久的连接在用之前要先 COM_PING 体检一下(秒)。
# 公网 NAT 掐空闲长连时**不发 FIN**,于是 aiomysql 池里的 at_eof() 检测不到,
# 这条"看着还活着"的连接会在下一次查询的第一拍炸成 2006/2013。旧代码靠"任何语句
# 都盲目重发一次"把它盖过去 —— 那在「服务端已执行、回包途中断线」的窗口会写两行。
# 现在改成:空闲超过阈值就先 ping(失败时 aiomysql 会就地重连,且**会重新下发
# autocommit / sql_mode**,已逐行核对 connection.py:544-552),于是陈旧连接变成一次
# **语句送出之前**的失败 —— 无论后面跑的是 SELECT 还是 INSERT 都可以安全重试。
# 代价:只有真正闲置超阈值的连接才多付一个 RTT;有流量时连接被频繁复用,一次都不付。
_PING_IDLE_S = 30.0
# 身份指纹的**复验周期**(秒)。指纹本身不会变,但一个 IP 会:云上换绑、转发机改后端、
# 数据库故障切换,都能让"同一个 IP"在运行期指向另一台实例。故即便入口一直健康、
# 一直有流量,也要按这个周期重新核一次"你还是不是那个库"。
_IDENT_REVERIFY_S = 300.0
# 只读语句白名单:传输层错误发生在**语句已送出之后**时,只有这类语句能安全重试
# (重发一条 SELECT 顶多多花一次往返;重发一条 INSERT 可能写两行)。
_READ_ONLY_SQL = re.compile(r"^\s*(?:/\*.*?\*/\s*)?"
                            r"(SELECT|SHOW|DESC|DESCRIBE|EXPLAIN)\b",
                            re.I | re.S)
# 身份指纹探测:一次往返取齐。用 `SHOW GLOBAL VARIABLES WHERE ...` 而不是
# `SELECT @@server_uuid` —— **实地核查**:MariaDB(项目开发/测试环境的 1:1 复刻库)
# 根本没有 server_uuid 这个变量,`SELECT @@server_uuid` 会直接报错;而 SHOW 形式
# 对不存在的变量只是不返回该行,不报错。生产的 MySQL 5.7 有 server_uuid
# (官方文档:5.7 起服务器会生成一个真 UUID,暴露为只读全局变量 server_uuid),
# 于是两边都能跑,且在 5.7 上拿到的是最强的那个指纹。
_IDENT_SQL = ("SHOW GLOBAL VARIABLES WHERE Variable_name IN "
              "('server_uuid','server_id','hostname','port','version','read_only')")


def parse_endpoints(raw: str, default_port: int) -> List[Tuple[str, int, float]]:
    """把 `STA_USERDB_HOST` 解析成 [(host, port, weight)]。

    · 单值(今天的写法)→ 恰好一个入口,行为与改造前逐字节一致;
    · 解析不了的片段**跳过并由调用方告警**,绝不静默当成主机名去连一个错的地方;
    · 同一 (host, port) 重复出现只保留一次(权重取最大)—— 粘贴重复不该变成
      两个池、两份连接预算。
    """
    out: List[Tuple[str, int, float]] = []
    seen: Dict[Tuple[str, int], int] = {}
    for tok in _SPLIT.split(str(raw or "").strip()):
        if not tok:
            continue
        m = _ONE.match(tok)
        if not m:
            continue
        host = m.group("host")
        port = int(m.group("port") or default_port)
        if not (0 < port < 65536):
            continue
        weight = float(m.group("weight") or 1.0)
        if not (weight > 0) or math.isinf(weight):
            weight = 1.0
        key = (host, port)
        if key in seen:
            i = seen[key]
            out[i] = (host, port, max(out[i][2], weight))
            continue
        seen[key] = len(out)
        out.append((host, port, weight))
    return out


def bad_tokens(raw: str) -> List[str]:
    """**有问题的片段**(供启动时告警;拼错一个 IP 不该悄无声息)。

    两类,都会被点名,但处置不同:
      · 整段无法解析 / 端口越界 → 地址本身不可用,**丢弃该入口**;
      · 只是权重写坏(`*0`、`*abc`)→ 地址是好的,**入口保留、权重按 1 计**。
        为一个权重笔误就把运维明明想要的 IP 整个扔掉,是过度惩罚。

    注意这里不只收「正则都对不上」的,还收「格式对但取值非法」的 —— 端口写成
    99999、权重写成 0 都属此类。第一版只查了正则,于是 `2.2.2.2:99999` 会被
    静默丢掉、运维对着一个少了入口的系统毫无线索(被本模块自己的测试逮到)。
    """
    out: List[str] = []
    for t in _SPLIT.split(str(raw or "").strip()):
        if not t:
            continue
        m = _ONE.match(t)
        if not m:
            out.append(t)                    # 整个片段没法解析 → 丢弃
            continue
        port = int(m.group("port") or 3306)
        w = float(m.group("weight") or 1.0)
        if not (0 < port < 65536):
            out.append(t)                    # 端口越界 → 地址不可用 → 丢弃
        elif not (w > 0) or math.isinf(w):
            out.append(t)                    # 只是权重写坏 → 入口保留,权重按 1 用
    return out


def is_transport_error(exc: BaseException) -> bool:
    """这个异常该不该记在**入口**头上?

    该:连不上 / 连接断了 / 读超时 —— 换个入口可能就好了。
    不该:口令错(1045)、连接数超限(1040)、死锁(1213)、语法错、唯一键冲突
          —— 全部入口指向同一个库,换入口结果一模一样;拿它们熔断只会把所有
          入口一起打死,把「一条语句失败」放大成「登录系统整体不可用」。
    """
    if isinstance(exc, (asyncio.TimeoutError, OSError, EOFError, ConnectionError)):
        return True
    if aiomysql is not None and isinstance(exc, aiomysql.InterfaceError):
        return True
    if aiomysql is not None and isinstance(exc, aiomysql.OperationalError):
        try:
            return int(exc.args[0]) >= _CLIENT_ERRNO_MIN
        except Exception:               # noqa: BLE001 —— 取不到错误码时保守视作传输层
            return True
    # 池已关闭后 acquire 抛 RuntimeError(aiomysql/pool.py:138)——属入口状态问题
    if isinstance(exc, RuntimeError) and "pool" in str(exc).lower():
        return True
    return False


def is_read_only_sql(sql: str) -> bool:
    return bool(_READ_ONLY_SQL.match(str(sql or "")))


class _PreSendError(Exception):
    """内部信号:失败发生在**语句送出之前**(取连接/建连阶段)。

    这个区分是重试安全性的全部依据 —— 语句根本没送到服务端,那么无论它是
    SELECT 还是 INSERT,换个入口重发都**不可能**产生第二次副作用。
    """

    def __init__(self, cause: BaseException):
        super().__init__(str(cause))
        self.cause = cause


class Endpoint:
    """一个网络入口(= 一个弹性 IP 上的 host:port),持有它自己的连接池。"""

    __slots__ = ("host", "port", "weight", "pool", "inflight", "state", "reason",
                 "fail_streak", "down_until", "last_ok", "last_err", "ewma_rtt_ms",
                 "bytes_in", "bytes_out", "q_ok", "q_err", "identity", "probes",
                 "last_ident")

    def __init__(self, host: str, port: int, weight: float):
        self.host = host
        self.port = int(port)
        self.weight = float(weight)
        self.pool = None                 # aiomysql.Pool(懒建)
        self.inflight = 0                # 路由层在飞数(可超过池 maxsize:排队中的也算)
        # up=可用 / down=熔断中 / mismatch=身份不符(永久隔离) / new=还没探过
        self.state = "new"
        self.reason = ""
        self.fail_streak = 0
        self.down_until = 0.0            # 单调钟
        self.last_ok = 0.0
        self.last_err = ""
        self.ewma_rtt_ms = 0.0
        self.bytes_in = 0                # 精确网络字节(见 Router._meter)
        self.bytes_out = 0
        self.q_ok = 0
        self.q_err = 0
        self.identity: Dict[str, str] = {}
        self.last_ident = 0.0      # 最近一次拿到身份指纹的单调钟
        self.probes = 0

    # ── 状态 ──────────────────────────────────────────────────────────────
    @property
    def name(self) -> str:
        return f"{self.host}:{self.port}"

    def usable(self, now: float) -> bool:
        """能否参与分流。`new` 视作可用 —— 首个请求不必干等探活轮次
        (探活会在几秒内把真相纠正过来;而让首个请求白等一轮是实打实的体验损失)。"""
        if self.state == "mismatch":
            return False
        if self.state == "down":
            return now >= self.down_until
        return True

    def score(self) -> Tuple[float, float]:
        """越小越优。主信号=按权重归一的排队深度,次信号=EWMA RTT。"""
        return ((self.inflight + 1) / max(0.01, self.weight), self.ewma_rtt_ms)

    def mark_ok(self, rtt_ms: float) -> None:
        self.state = "up" if self.state != "mismatch" else "mismatch"
        self.reason = "" if self.state == "up" else self.reason
        self.fail_streak = 0
        self.down_until = 0.0
        self.last_ok = time.monotonic()
        # EWMA α=0.25:够快地跟上带宽变化,又不至于被单次抖动带偏
        self.ewma_rtt_ms = rtt_ms if self.ewma_rtt_ms <= 0 else \
            0.75 * self.ewma_rtt_ms + 0.25 * rtt_ms

    def mark_fail(self, exc: BaseException) -> None:
        if self.state == "mismatch":
            return                       # 身份不符是终态,不再被普通失败改写
        self.fail_streak += 1
        self.last_err = f"{type(exc).__name__}: {exc}"
        step = _BREAK_STEPS[min(self.fail_streak - 1, len(_BREAK_STEPS) - 1)]
        self.state = "down"
        self.reason = "transport"
        self.down_until = time.monotonic() + step

    def mark_mismatch(self, reason: str) -> None:
        self.state = "mismatch"
        self.reason = reason
        self.down_until = float("inf")


# ── 管理台分析型查询的超时语义(5.4.0 复查)──────────────────────────────────────
# run() 把「已送出后的超时」判为传输错:熔断入口 + 拆池 + 只读语句换入口重发。对登录 /
# 会话这类轻查询这是对的(超时的唯一可见原因是入口带宽打满)。对管理台「登 / 注 / 值」
# 视图里的分析型查询(流水分页计数、按 IP 段聚合、营收统计)是错的:它超时只说明「这条
# 查询太重」—— 流水被灌到数百万行时,一次按 IP 筛选的 COUNT(*) 就能超过 15s。旧行为下
# 一次页面刷新 = 两次熔断 + 两次拆池(在飞的登录写语句以 2013 失败)+ 服务端白跑两遍同一
# 条重查询:运维排查攻击的动作本身把登录打挂(与旧清扫任务同一个失效模式)。
# 被 heavy_reads 标记的函数里:超时只上抛给调用方(管理台显示读取失败),不动入口状态、
# 不重发;其余传输错(连接被拒 / 被重置)照旧熔断 —— 那才真说明入口坏了。
HEAVY_READS: "contextvars.ContextVar[bool]" = contextvars.ContextVar(
    "userdb_heavy_reads", default=False)


def heavy_reads(fn):
    """装饰器:被装饰的协程函数内,所有用户库查询按「重查询」处理(语义见上)。
    用上下文变量而不改 _q 的签名:调用点零改动,测试里替换 _q 的桩照常生效。"""
    @functools.wraps(fn)
    async def wrapper(*args, **kwargs):
        token = HEAVY_READS.set(True)
        try:
            return await fn(*args, **kwargs)
        finally:
            HEAVY_READS.reset(token)
    wrapper.__heavy_reads__ = True
    return wrapper


@contextlib.contextmanager
def heavy():
    """上下文管理器版的 heavy_reads:给「管理台与用户侧**共用**」的函数,在**管理台调用处**临时开启
    重查询语义。第十轮复查:标记打在函数定义上会连用户侧路径一起改掉 —— jfvip.orders_page /
    grants_page 同时服务管理台检索与用户自己的 /api/vip/orders(按 uid 走索引的业务查询,超时
    就该熔断、只读语句就该换入口重发)。只服务管理台的函数仍用装饰器。"""
    token = HEAVY_READS.set(True)
    try:
        yield
    finally:
        HEAVY_READS.reset(token)


class Router:
    """多入口路由器:选路 → 执行 → 计量 → 熔断/恢复。"""

    def __init__(self, cfg, *, pool_max: int = 8, query_timeout_s: float = 15.0,
                 probe_s: float = 10.0, log=print):
        self.cfg = cfg
        self.log = log
        self.query_timeout_s = max(1.0, float(query_timeout_s))
        self.probe_s = max(1.0, float(probe_s))
        specs = parse_endpoints(getattr(cfg, "host", ""), int(getattr(cfg, "port", 3306)))
        self.endpoints: List[Endpoint] = [Endpoint(h, p, w) for h, p, w in specs]
        n = max(1, len(self.endpoints))
        # 每入口连接上限:把总预算摊到各入口,但**每个入口至少 2 条** —— 只给 1 条
        # 会让「一条慢查询」把该入口整个堵住(队头阻塞),分流就退化成了串行。
        # 想真正吃满多入口带宽,请把 STA_USERDB_POOL_MAX 调到「入口数 × 8」量级;
        # 默认值保持与改造前同一总量,升级不会给共享的用户库带去意外的连接压力。
        self.per_pool_max = max(2, int(math.ceil(max(1, int(pool_max)) / n)))
        self._lock = asyncio.Lock()
        self._probe_task: Optional[asyncio.Task] = None
        self._closed = False
        self.identity_ref: Dict[str, str] = {}
        self.ref_from = ""
        self.bad_tokens = bad_tokens(getattr(cfg, "host", ""))

    # ── 生命周期 ──────────────────────────────────────────────────────────
    async def start(self) -> None:
        """建各入口的池并起探活任务。

        注意:`create_pool(minsize=0)` **不会建连**(aiomysql/pool.py:26 只有
        minsize>0 才 _fill_free_pool),所以本方法不做任何网络 I/O、不会因为库
        不可达而卡住启动 —— 这与改造前一致。真正的连通性由探活任务负责。
        """
        # 告警必须**先于**任何提前返回:第一版把它放在 `not self.endpoints` 的早退
        # 之后,于是「IP 全填错」这一最需要提示的情形反而一个字都不打 —— 运维只看到
        # 莫名其妙的 503(开发期实测复现)。
        if self.bad_tokens:
            self.log(f"[登录] ⚠️ STA_USERDB_HOST 有问题的片段:"
                     f"{', '.join(self.bad_tokens)} —— 端口越界/整段无法解析的已**丢弃**,"
                     f"仅权重写坏的入口保留、权重按 1 计。")
        if aiomysql is None:
            return
        if not self.endpoints:
            self.log(f"[登录] ⛔ STA_USERDB_HOST={getattr(self.cfg, 'host', '')!r} "
                     f"解析不出**任何**可用入口 —— 登录/注册/VIP 全部会回 503。"
                     f"正确写法:`ip[:端口][*权重]`,逗号分隔(如 "
                     f"`1.2.3.4, 5.6.7.8*2`)。")
            return
        for ep in self.endpoints:
            await self._ensure_ep_pool(ep)
        self._probe_task = asyncio.create_task(self._probe_loop())

    async def close(self) -> None:
        self._closed = True
        if self._probe_task is not None:
            self._probe_task.cancel()
            with contextlib.suppress(BaseException):
                await self._probe_task
            self._probe_task = None
        # 先让被取消的探活任务把「已 shield 的取连接」跑完并归还,再拆池。
        # 不让这一步的话,孤儿连接会活到事件循环关闭之后,在 GC 里触发
        # `Connection.__del__ → RuntimeError: Event loop is closed`(测试里表现为
        # PytestUnraisableExceptionWarning)。两拍 sleep(0) 足够把已完成的回调排空。
        for _ in range(2):
            await asyncio.sleep(0)
        for ep in self.endpoints:
            await self._drop_pool(ep, wait=True)

    def terminate_sync(self) -> None:
        """同步拆除(供 `UA.pool = None` 这类测试重置路径用;不 await)。"""
        self._closed = True
        if self._probe_task is not None:
            self._probe_task.cancel()
            self._probe_task = None
        for ep in self.endpoints:
            p, ep.pool = ep.pool, None
            if p is not None:
                with contextlib.suppress(Exception):
                    p.terminate()

    async def _ensure_ep_pool(self, ep: Endpoint):
        if ep.pool is not None or self._closed:
            return ep.pool
        c = self.cfg
        async with self._lock:           # 建池收口:并发进入不再各建一个池
            if ep.pool is not None:
                return ep.pool
            ep.pool = await aiomysql.create_pool(
                host=ep.host, port=ep.port, user=c.user, password=c.password,
                db=c.db, charset=c.charset, autocommit=True,
                minsize=0, maxsize=self.per_pool_max,
                connect_timeout=8,
                pool_recycle=280)        # 公网 NAT 常掐空闲长连:5 分钟内主动换血
        return ep.pool

    async def _drop_pool(self, ep: Endpoint, wait: bool = False) -> None:
        """丢弃某入口的池。用 terminate 而非 close+wait_closed ——
        后者会等**所有在用连接归还**,而挂死的连接永远不会归还(见模块头注 2)。"""
        p, ep.pool = ep.pool, None
        if p is None:
            return
        with contextlib.suppress(Exception):
            p.terminate()
        if wait:
            with contextlib.suppress(Exception):
                await p.wait_closed()    # terminate 已关掉在用连接,这里不会挂住

    # ── 计量 ──────────────────────────────────────────────────────────────
    @staticmethod
    def _meter(conn, ep: Endpoint) -> None:
        """给连接挂上**精确**的收发字节计数。

        `Connection._read_bytes(n)` / `_write_bytes(data)` 是 aiomysql 全部网络
        读写的唯一收口(已逐行核对 connection.py:602-669),且 Connection 没有
        __slots__(实测可覆盖),故实例级包一层即可。挂钩失败一律吞掉:计量只是
        观测,绝不能因为驱动内部改名就把登录系统打挂。
        """
        try:
            if getattr(conn, "_jf_metered", False):
                return
            rb, wb = conn._read_bytes, conn._write_bytes

            async def _read(n, _rb=rb, _ep=ep):
                _ep.bytes_in += int(n)
                return await _rb(n)

            def _write(data, _wb=wb, _ep=ep):
                _ep.bytes_out += len(data)
                return _wb(data)

            conn._read_bytes = _read
            conn._write_bytes = _write
            conn._jf_metered = True
        except Exception:                # noqa: BLE001
            pass

    # ── 选路 ──────────────────────────────────────────────────────────────
    def pick(self, exclude: Sequence[Endpoint] = ()) -> Optional[Endpoint]:
        """P2C:健康入口里随机取二、择优。全挂时回 None(由调用方决定兜底)。"""
        now = time.monotonic()
        live = [e for e in self.endpoints if e.usable(now) and e not in exclude]
        if not live:
            return None
        if len(live) == 1:
            return live[0]
        a, b = random.sample(live, 2)
        return a if a.score() <= b.score() else b

    def _fallback(self, exclude: Sequence[Endpoint] = ()) -> Optional[Endpoint]:
        """全部熔断时的兜底:取「最快到期」的那个硬试一次。

        为什么不干等探活:观测台可能整分钟没有请求,探活轮次也就无从触发用户可感
        的恢复;而「下一次请求顺手试一下」正是改造前的行为(旧 `_ensure_pool` 每次
        请求都会重试建池)。保留它,升级前后在「全挂」这一态上体验一致。
        """
        cand = [e for e in self.endpoints
                if e.state != "mismatch" and e not in exclude]
        return min(cand, key=lambda e: e.down_until) if cand else None

    # ── 执行 ──────────────────────────────────────────────────────────────
    async def run(self, sql: str, args: tuple = (), fetch: str = "none",
                  idem: bool = False) -> Any:
        """执行一条 SQL。选路 → 超时保护 → 按安全性重试。

        重试规则(这是本模块最需要被读懂的一段):
          · 失败在**送出之前**(取连接/建连)→ 任何语句都可换入口重发,语句压根
            没到服务端,不可能有第二次副作用;
          · 失败在**送出之后** → 只有只读语句(或调用方显式标注 idem=True 的
            幂等写)才重发。改造前这里是「任何语句都盲目重发一次」—— 那在
            「服务端已执行、回包途中断线」的窗口里会写两行。本次一并收紧。
        """
        if aiomysql is None or not self.endpoints:
            raise ConnectionError("userdb endpoints unavailable")
        read_ok = idem or is_read_only_sql(sql)
        tried: List[Endpoint] = []
        last: Optional[BaseException] = None
        # **至少 2 次**,至多 3 次。
        #   下限 2 是硬要求:4.4.x 的 `for attempt in (0, 1)` 就是为「公网 NAT 掐了
        #   空闲长连、第一拍必炸」准备的。第一版写成 `min(3, len(endpoints))`,
        #   单入口部署(= 今天的生产配置)只剩 1 次,陈旧连接直接变成登录 503 ——
        #   实测复现:原始代码 execute 被调 2 次成功,那一版只调 1 次就抛错。
        #   上限 3 是为了不让一次请求在多个坏入口上串行耗光超时预算。
        for _ in range(max(2, min(3, len(self.endpoints)))):
            ep = self.pick(exclude=tried) or self._fallback(exclude=tried)
            if ep is None:
                # 入口都试过了但预算还有 —— 单入口部署的常态。该入口的池已在上一拍
                # 被丢弃,再来一次拿到的必然是新连接,这正是 4.4.x「整池换血后重试
                # 一次」的等价物。
                ep = self.pick() or self._fallback()
            if ep is None:
                break
            tried.append(ep)
            try:
                return await self._run_on(ep, sql, args, fetch)
            except _PreSendError as e:              # 未送出:任何语句都可再试
                last = e.cause
                if is_transport_error(e.cause):
                    ep.mark_fail(e.cause)
                    await self._drop_pool(ep)
                    continue
                raise e.cause
            except BaseException as e:              # noqa: BLE001 —— 已送出
                if not is_transport_error(e):
                    raise                           # 语义错:原样上抛,不熔断
                if isinstance(e, asyncio.TimeoutError) and HEAVY_READS.get():
                    raise                           # 重查询超时 = 查询太重,不是入口坏了(见 HEAVY_READS)
                ep.mark_fail(e)
                await self._drop_pool(ep)
                last = e
                if not read_ok:
                    raise                           # 写语句:结果未知,不敢重发
                continue
        raise last if last is not None else \
            ConnectionError("no usable userdb endpoint")

    async def run_maint(self, sql: str, args: tuple = (), fetch: str = "none",
                        timeout_s: Optional[float] = None) -> Any:
        """后台维护语句(保留期清扫 / 容量体检)专用通道:**不重试、超时不熔断、不拆池**。

        ── 为什么不能走 run()(5.4.0;真库实测,见 DATA-LIFECYCLE.md §2)────────────
        run() 把查询超时判为**传输错**:`mark_fail` 熔断入口 + `_drop_pool` 拆掉该入口
        的整个连接池。对业务查询这是对的(入口带宽打满的唯一可见面);对清扫语句是错的
        —— 它超时只说明「这一批太重」,入口本身好好的。旧 `_janitor` 用单条不分批
        DELETE 走 run(),200 万行积压实测:客户端 15.0s 超时 → 唯一入口被标 down、
        连接池被拆 → 同一刻在飞的**写语句**以 2013 Lost connection 失败(而服务端其实
        已提交,结果未知),在飞的只读查询被迫重跑(6s 的查询变 9s);服务端则把那条
        被放弃的 DELETE 继续跑了 209 秒以上。清理垃圾的任务不该有本事打断登录。

        故本通道:失败只上抛给调用方(由清扫引擎收小批量后重试),**绝不**动入口状态;
        超时照旧硬关那一条连接(协议态未知,不还池 —— 与 run() 同一条纪律)。
        写语句不重发(结果未知);清扫语句全部是幂等的「删到没有为止」,下一批自然补上。
        """
        if aiomysql is None or not self.endpoints:
            raise ConnectionError("userdb endpoints unavailable")
        ep = self.pick() or self._fallback()
        if ep is None:
            raise ConnectionError("no usable userdb endpoint")
        try:
            return await self._run_on(ep, sql, args, fetch, timeout_s=timeout_s, maint=True)
        except _PreSendError as e:
            raise e.cause

    async def _run_on(self, ep: Endpoint, sql: str, args: tuple, fetch: str,
                      timeout_s: Optional[float] = None, maint: bool = False) -> Any:
        # timeout_s / maint 仅供 run_maint(后台维护通道,5.4.0)使用;run() 的调用
        # 形态与预算一字未动。
        deadline = time.monotonic() + (self.query_timeout_s if timeout_s is None
                                       else max(1.0, float(timeout_s)))
        ep.inflight += 1
        try:
            pool = await self._ensure_ep_pool(ep)
            if pool is None:
                raise _PreSendError(ConnectionError("pool unavailable"))
            try:
                conn = await self._acquire(pool, max(0.05, deadline - time.monotonic()))
            except BaseException as e:               # noqa: BLE001
                raise _PreSendError(e)
            t0 = time.monotonic()
            try:
                self._meter(conn, ep)
                # 陈旧连接体检(见 _PING_IDLE_S 注)。失败按「语句送出之前」处理,
                # 因此任何语句都可安全换连/换入口重试。
                if (conn._loop.time() - conn.last_usage) > _PING_IDLE_S:
                    try:
                        await asyncio.wait_for(
                            conn.ping(reconnect=True),
                            max(0.05, min(8.0, deadline - time.monotonic())))
                    except BaseException as pe:      # noqa: BLE001
                        with contextlib.suppress(Exception):
                            conn.close()
                        raise _PreSendError(pe)
                async with conn.cursor(aiomysql.DictCursor) as cur:
                    left = deadline - time.monotonic()
                    if left <= 0:
                        raise asyncio.TimeoutError("userdb query budget exhausted")
                    # 缓冲游标:execute 内已把整个结果集读完,故只需保护它;
                    # 其后的 fetchone/fetchall 是纯内存操作、不再有网络等待。
                    await asyncio.wait_for(cur.execute(sql, args), left)
                    if fetch == "one":
                        out = await cur.fetchone()
                    elif fetch == "all":
                        out = await cur.fetchall()
                    else:
                        out = cur.rowcount
                ep.q_ok += 1
                if not maint:
                    # 维护语句(分批 DELETE,单批数百毫秒)不进 EWMA RTT:那是给
                    # 「业务查询的往返」用的次级选路信号,混进批量删除的耗时会失真。
                    ep.mark_ok((time.monotonic() - t0) * 1000.0)
                return out
            except _PreSendError:
                raise                       # ping 阶段失败:语句未送出,原样上抛给 run()
            except BaseException:
                # 超时/传输错 → 协议态未知 → 硬关,绝不还池(见模块头注)
                with contextlib.suppress(Exception):
                    conn.close()
                ep.q_err += 1
                raise
            finally:
                with contextlib.suppress(Exception):
                    pool.release(conn)
        finally:
            ep.inflight -= 1

    @staticmethod
    async def _acquire(pool, timeout: float):
        """带超时地取连接,且**保证不泄漏**。

        直接 `wait_for(pool.acquire(), t)` 在超时时会取消取连接的协程;若此刻
        连接已经建好、只差返回,就会变成「池里少了一条、谁也拿不回来」。故这里
        用 shield 让取连接照常跑完,超时只是让本次请求先走 —— 连接一旦到手立刻
        归还,池子保持完整。
        """
        task = asyncio.ensure_future(pool._acquire())
        try:
            return await asyncio.wait_for(asyncio.shield(task), timeout)
        except BaseException:
            def _giveback(t: asyncio.Task) -> None:
                if t.cancelled():
                    return
                if t.exception() is None:
                    with contextlib.suppress(Exception):
                        pool.release(t.result())
            task.add_done_callback(_giveback)
            raise

    # ── 探活 ──────────────────────────────────────────────────────────────
    async def _probe_loop(self) -> None:
        first = True
        while not self._closed:
            try:
                await asyncio.gather(*[self._probe_one(ep) for ep in self.endpoints],
                                     return_exceptions=True)
                self._reconcile_identity()   # 全轮探完再裁定,杜绝「谁先答谁当基准」
                if first:
                    first = False
                    self.log("[登录] 用户库入口探活:" + self.summary_line())
            except asyncio.CancelledError:
                raise
            except Exception:            # noqa: BLE001 —— 探活绝不允许打挂主进程
                pass
            try:
                await asyncio.sleep(self.probe_s)
            except asyncio.CancelledError:
                raise

    async def _probe_one(self, ep: Endpoint) -> None:
        now = time.monotonic()
        if ep.state == "mismatch":
            return                       # 终态,不再探(要复活请改配置后重启)
        if ep.state == "down" and now < ep.down_until:
            return
        # ── 什么时候可以跳过这一拍探活 ────────────────────────────────────────
        # 第一版只看"刚刚有没有成功查询"(省一次公网往返)。**实测这是个洞**:
        # 一个入口若是靠『查询成功』恢复的(而不是靠探活),在持续流量下 last_ok
        # 永远新鲜 → 这一拍永远被跳过 → 它的身份指纹**永远拿不到**、永远不参与
        # 「是不是同一个库」的投票。复现结果:异库入口 8 秒内服务了 4777 次查询,
        # probes=0、identity 为空 —— 一个填错的 IP 只要一直有流量就永不被识破。
        # 现在的条件:身份**已知**、且**未到复验期**、且最近确有成功查询,三者同时
        # 成立才跳过。省下的那点往返远不值这个风险(默认 10s 一拍、每入口一条
        # 小查询 ≈ 0.1 QPS)。
        need_ident = (not ep.identity) or (now - ep.last_ident) >= _IDENT_REVERIFY_S
        if ep.state == "up" and not need_ident and (now - ep.last_ok) < self.probe_s:
            return
        pool = await self._ensure_ep_pool(ep)
        if pool is None:
            return
        t0 = time.monotonic()
        conn = None
        try:
            conn = await self._acquire(pool, 8.0)
            self._meter(conn, ep)
            async with conn.cursor(aiomysql.DictCursor) as cur:
                await asyncio.wait_for(cur.execute(_IDENT_SQL), 8.0)
                rows = await cur.fetchall()
            ident = {str(r["Variable_name"]).lower(): str(r["Value"])
                     for r in (rows or [])}
            ep.probes += 1
            ep.mark_ok((time.monotonic() - t0) * 1000.0)
            if ident:
                ep.last_ident = time.monotonic()
            self._check_identity(ep, ident)
        except asyncio.CancelledError:
            raise
        except BaseException as e:       # noqa: BLE001
            if conn is not None:
                with contextlib.suppress(Exception):
                    conn.close()
            if is_transport_error(e):
                was = ep.state
                ep.mark_fail(e)
                await self._drop_pool(ep)
                if was != "down":
                    self.log(f"[登录] ⚠️ 用户库入口 {ep.name} 不可用,已暂时摘除"
                             f"({ep.last_err})")
            # 语义错(口令错/权限不足…)不摘入口:换入口也一样错,摘了只会全灭
        finally:
            if conn is not None and pool is not None:
                with contextlib.suppress(Exception):
                    pool.release(conn)

    def _check_identity(self, ep: Endpoint, ident: Dict[str, str]) -> None:
        """记下这个入口的身份指纹,并只发只读告警;判谁对谁错交给 _reconcile()。"""
        ep.identity = ident
        if str(ident.get("read_only", "")).upper() in ("ON", "1"):
            # 只告警不隔离:若真是全库只读,隔离所有入口会把「部分能用」变成
            # 「完全不能用」;而写失败本来就会以异常如实暴露。
            self.log(f"[登录] ⚠️ 用户库入口 {ep.name} 报 read_only=ON —— "
                     f"若它是从库,会话/订单写入将失败,请核对该 IP。")

    def _reconcile_identity(self) -> None:
        """裁定「哪些入口通向的不是同一个库」。

        ── 为什么不能「谁先答谁当基准」(第一版的写法,被自己的测试当场逮到)──
        探活是 `asyncio.gather` 并发跑的,谁先回是**竞态**。第一版拿首个应答者当
        基准,实测出现过「真正的主库因为慢了 3ms 而被判成异库、错的那个反倒成了
        基准」。基准必须是**确定性**的。

        ── 定案:多数派,平局按配置顺序 ──────────────────────────────────────
          · 三个入口里有一个填错 → 另外两个是多数派,错的那个被隔离(理想情形);
          · 两个入口互不相同 → 没有多数,取**配置里靠前**的那个当基准(运维习惯
            把主入口写在第一位),并醒目告知「无法判断谁对,请人工核对」;
          · 只有一个入口 → 无从比较,永不隔离。
        指纹取舍:MySQL 5.7 有 server_uuid(全局唯一、最强);MariaDB 没有,退回
        (server_id, hostname, version)。取不到指纹的入口**不参与投票也不被判**——
        宁可不判,也不能拿一个空指纹去误杀好入口。
        判定基于**曾经探到过的**指纹(熔断期间仍保留),因此一旦各入口都探过一轮,
        结论就是稳定的,不会随某个入口一时不可达而翻来覆去。
        """
        known = [(i, e, self._fingerprint(e.identity))
                 for i, e in enumerate(self.endpoints) if self._fingerprint(e.identity)]
        if len(known) < 2:
            return
        votes: Dict[str, List[int]] = {}
        for i, _e, fp in known:
            votes.setdefault(fp, []).append(i)
        # 多数派;票数相同时取「成员里配置位置最靠前」的那一派
        ref = min(votes, key=lambda fp: (-len(votes[fp]), min(votes[fp])))
        tie = len([fp for fp in votes if len(votes[fp]) == len(votes[ref])]) > 1
        self.identity_ref = dict(self.endpoints[votes[ref][0]].identity)
        self.ref_from = self.endpoints[votes[ref][0]].name
        for _i, e, fp in known:
            if fp == ref:
                if e.state == "mismatch":       # 上一轮误判过 → 平反
                    e.state, e.reason, e.down_until = "up", "", 0.0
                    self.log(f"[登录] 用户库入口 {e.name} 身份复核通过,已重新纳入分流")
                continue
            if e.state == "mismatch":
                continue
            e.mark_mismatch("identity")
            self.log(f"[登录] ⛔ 用户库入口 {e.name} **不是同一个库**"
                     f"(指纹 {fp} ≠ 基准 {ref}@{self.ref_from})—— 已隔离,不再分流。"
                     + ("⚠️ 只有两个入口且互不相同,**无法判断谁才是对的** —— "
                        "本次按配置顺序取了靠前的那个当基准,请务必人工核对!"
                        if tie else "多入口的前提是同一逻辑库的多网络入口;请核对该 IP。"))

    @staticmethod
    def _fingerprint(ident: Dict[str, str]) -> str:
        uuid = ident.get("server_uuid", "")
        if uuid:
            return f"uuid:{uuid}"
        sid, hn, ver = (ident.get("server_id", ""), ident.get("hostname", ""),
                        ident.get("version", ""))
        return f"sid:{sid}|host:{hn}|ver:{ver}" if (sid or hn) else ""

    # ── 观测 ──────────────────────────────────────────────────────────────
    def best_pool(self):
        """给「手工事务」用的取池口(三处 BEGIN…COMMIT 直接持连接跑)。

        事务必须整段跑在同一条连接上,而一条连接只属于一个入口 —— 因此事务
        天然不跨入口,与单入口时逐字节同语义。这里挑一个当下最闲的健康入口,
        让事务也享受到分流,并套一层薄包装(_PoolFacade)补齐三件事:
        取连接有超时上限、参与在飞计数、事务路径上的传输层故障也会标记入口。
        """
        ep = self.pick() or self._fallback()
        if ep is None or ep.pool is None:
            # 池尚未建立时不能凭空造:调用方(_ensure_pool)拿到 None 就按
            # 「用户库暂不可用」处理,与 4.4.x 一致。
            return None if ep is None else None
        return _PoolFacade(self, ep)

    def summary_line(self) -> str:
        return " · ".join(
            f"{e.name}{'' if e.weight == 1 else f'*{e.weight:g}'}"
            f"[{e.state}{'/' + e.reason if e.reason else ''}"
            f"{'' if e.ewma_rtt_ms <= 0 else f' {e.ewma_rtt_ms:.0f}ms'}]"
            for e in self.endpoints)

    def snapshot(self) -> Dict[str, Any]:
        now = time.monotonic()
        eps = []
        for e in self.endpoints:
            pool = e.pool
            eps.append({
                "host": e.host, "port": e.port, "weight": e.weight,
                "state": e.state, "reason": e.reason,
                "inflight": e.inflight,
                "poolSize": getattr(pool, "size", 0) if pool is not None else 0,
                "poolFree": getattr(pool, "freesize", 0) if pool is not None else 0,
                "poolMax": self.per_pool_max,
                "rttMs": round(e.ewma_rtt_ms, 1),
                "bytesIn": e.bytes_in, "bytesOut": e.bytes_out,
                "queriesOk": e.q_ok, "queriesErr": e.q_err,
                "failStreak": e.fail_streak,
                "downForS": (round(e.down_until - now, 1)
                             if e.state == "down" and e.down_until > now else 0),
                "lastOkAgoS": (round(now - e.last_ok, 1) if e.last_ok else None),
                "lastError": e.last_err,
                "identity": e.identity,
                "identAgeS": (round(now - e.last_ident, 1) if e.last_ident else None),
                "probes": e.probes,
            })
        return {
            "endpoints": eps,
            "queryTimeoutS": self.query_timeout_s,
            "probeS": self.probe_s,
            "perPoolMax": self.per_pool_max,
            "identityRef": self.identity_ref,
            "identityRefFrom": self.ref_from,
            "badTokens": self.bad_tokens,
            "usable": sum(1 for e in self.endpoints if e.usable(now)),
            "total": len(self.endpoints),
        }


class _Acq:
    """让 `await pool.acquire()` 与 `async with pool.acquire() as conn:` 两种写法
    都成立 —— 项目里两种都有(事务用前者、建表用后者),包装层不能只支持一种。"""

    __slots__ = ("_coro", "_facade", "_conn")

    def __init__(self, coro, facade):
        self._coro = coro
        self._facade = facade
        self._conn = None

    def __await__(self):
        return self._coro.__await__()

    async def __aenter__(self):
        self._conn = await self._coro
        return self._conn

    async def __aexit__(self, exc_type, exc, tb):
        if self._conn is not None:
            self._facade.release(self._conn)
        return False


class _PoolFacade:
    """给「手工事务」路径用的薄包装。

    三处事务(userauth._register_tx / jfpay._reuse_after_dup / jfvip._grant_tx)
    对池的使用面**只有三件事**:真值判断、`acquire()`、`release(conn)`
    (已逐函数扫描核对)。包一层就能在**完全不改动它们**的前提下补上:
      · **取连接有超时上限** —— aiomysql 的 `Pool._acquire` 在池被占满时会
        `await self._cond.wait()` **无限期排队**,没有这层就等于把「一条卡住的
        事务」放大成「后续所有事务一起卡住」;
      · **在飞计数** —— 事务也算负载,不计就会让 P2C 把新事务继续往最忙的入口塞;
      · **故障标记** —— 事务路径上的传输层错误同样应该让该入口进熔断。
    刻意不代理其它属性:用到了没代理的东西会当场 AttributeError,好过悄悄绕过。
    """

    __slots__ = ("_router", "_ep", "_pool")

    def __init__(self, router: "Router", ep: Endpoint):
        self._router = router
        self._ep = ep
        self._pool = ep.pool

    def __bool__(self) -> bool:
        return self._pool is not None

    def acquire(self):
        return _Acq(self._acquire(), self)

    async def _acquire(self):
        # 取连接时**重新解析**入口当前的池:`best_pool()` 与真正 acquire 之间可能
        # 隔着一次探活触发的换池(_drop_pool 会把 ep.pool 置空再重建)。若还抱着
        # 旧池不放,事务会撞上「Cannot acquire connection after closing pool」而
        # 假失败一次 —— 换池是常态维护动作,不该让一笔开通/注册陪葬。
        pool = await self._router._ensure_ep_pool(self._ep) or self._pool
        self._pool = pool
        self._ep.inflight += 1
        try:
            conn = await Router._acquire(pool, self._router.query_timeout_s)
        except BaseException as e:                   # noqa: BLE001
            self._ep.inflight -= 1
            if is_transport_error(e):
                self._ep.mark_fail(e)
            raise
        self._router._meter(conn, self._ep)
        return conn

    def release(self, conn):
        self._ep.inflight -= 1
        return self._pool.release(conn)
