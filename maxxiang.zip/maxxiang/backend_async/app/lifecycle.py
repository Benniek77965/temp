"""
lifecycle.py — 数据生命周期(5.4.0):全表登记 · 统一清扫引擎 · 容量观测
================================================================================
回答一个问题:**库里每一张表,为什么不会无限增长?**

在此之前,答案散落在四个地方(worker._retention / userauth._janitor / discovery 回收 /
「它本来就不大」的默契),而且有四张表根本没有答案(predictor_state / admin_audit /
guantai_jf_order 的未支付单 / rooms 的停用墓碑)。本模块把它收成三件事:

  一、全表登记(TABLES)
      PostgreSQL 与 MySQL 用户库的**每一张表**都必须在这里登记:属于哪一类、靠什么
      有界、由谁清。`tests/test_lifecycle.py` 拿它与两份建表 DDL、以及真库里实际存在
      的表做对拍 —— 新增一张表而不登记,当场变红;运行期 `/storage` 还会把
      「库里有、登记里没有」的表点名告警。从此不存在「没人想过它会不会涨」的表。

  二、统一清扫引擎(run_batched / run_tasks / run_loop)
      旧 `_janitor` 经真库实测(DATA-LIFECYCLE.md §2)有五个缺陷,引擎逐条对应:
        ① 启动后先睡 6 小时才清第一次      → 启动后 45~120s 首扫(抖动避开启动洪峰);
        ② 单条不分批 DELETE(200 万行积压:客户端 15s 超时,把唯一的库入口误判熔断、
           拆掉连接池,在飞的写语句以 2013 失败;服务端仍把这条大事务跑了 209s+)
                                          → 自适应分批(目标单批 0.5s)+ 维护通道
                                            `run_maint`(超时不熔断、不拆池);
        ③ 整轮共用一个 try:一张表失败,排在后面的表全被跳过
                                          → 逐表隔离,失败只记在自己头上;
        ④ `except Exception: pass`:失败无日志、无指标 → 每表落状态,管理台可见;
        ⑤ 只按时间不按行数:被灌时保留期内的行全留 → 行数上限(保命阀)。
      另:清不完时 60s 后续扫(不必再等 6 小时);整轮失败 10 分钟后重试。

  三、容量观测(snapshot)
      各表行数 / 字节 / 策略 / 上次清扫结果 + 库总大小 + Redis 内存,外加一组
      「会出事」的告警(保留期被关、接近行数上限、清扫报错、清扫停摆、未登记表)。
      管理台左栏「储」· 存储与保留 一屏看全,可「立即清扫」。

分工(刻意不动的部分):`rounds` / `predictions` 两张大表仍由 **worker._retention**
每小时裁剪(多副本 Redis 互斥、分批、ANALYZE,PG-INDEX-DIET.md 已实测调优);本模块
跑在 **web 进程**(单进程,见 Dockerfile CMD),负责其余全部小表 —— 因此「立即清扫」
是进程内直接调用,不需要任何跨进程信令。

依赖方向:userauth → lifecycle(引擎与状态);lifecycle 只在函数体内惰性 import
userauth / settings,避免循环依赖。
"""
from __future__ import annotations

import asyncio
import contextlib
import random
import time
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple

now_ms = lambda: int(time.time() * 1000)  # noqa: E731

# ══════════════════════════════════════════════════════════════════════════════
# 一、全表登记
# ══════════════════════════════════════════════════════════════════════════════
ROLLING = "rolling"      # 滚动流水:按时间窗(必要时叠行数上限)定时删
EXPIRING = "expiring"    # 到期即删:行自带失效时刻,过期满宽限期硬删
STATE = "state"          # 状态表:行数受「实体个数」约束;实体离场后回收
LEDGER = "ledger"        # 账本:每行对应一笔真实的钱/时长变动,永不自动删
POOL = "pool"            # 资源池:默认不排水(误删=资损),提供可选排水与手动删除
OPERATOR = "operator"    # 人工追加:只有已登录管理员的显式操作才会新增一行

KLASS_LABEL = {ROLLING: "滚动流水", EXPIRING: "到期即删", STATE: "状态表",
               LEDGER: "账本", POOL: "资源池", OPERATOR: "人工追加"}

SWEEP_WORKER = "worker · 每小时"            # worker._retention
SWEEP_WEB = "web · 每 6 小时"               # 本模块(PG 小表)/ userauth._janitor(用户库)
SWEEP_INLINE = "随业务动作"                 # 没有后台任务:写入路径自己负责收敛
SWEEP_NONE = "—"                            # 不自动删(账本 / 人工追加)


@dataclass(frozen=True)
class TablePolicy:
    store: str                  # pg / mysql
    table: str
    klass: str
    policy: str                 # 人话:怎么清
    bound: str                  # 人话:凭什么有界
    sweeper: str
    knobs: Tuple[str, ...] = ()  # 相关参数(参数中心键名)


def _t(store: str, table: str, klass: str, policy: str, bound: str,
       sweeper: str, *knobs: str) -> Tuple[str, TablePolicy]:
    return f"{store}:{table}", TablePolicy(store, table, klass, policy, bound, sweeper,
                                           tuple(knobs))


TABLES: Dict[str, TablePolicy] = dict([
    # ── PostgreSQL(观测库;建表见 db.SCHEMA) ────────────────────────────────
    _t("pg", "rounds", ROLLING,
       "只留最近 retention.days 天:按 round_id(即开局毫秒)分批 DELETE,删后 ANALYZE;"
       "发现房离线回收时连同其历史一并清掉",
       "行数 ≈ 监控房数 × 1728 局/天 × 保留天数",
       SWEEP_WORKER, "retention.days", "retention.sweep_interval_s",
       "retention.batch_rows", "retention.max_batches"),
    _t("pg", "predictions", ROLLING,
       "与 rounds 同一把尺、同一趟清理(只有策展房产生预测行)",
       "行数 ≤ 策展房数 × 1728 局/天 × 保留天数",
       SWEEP_WORKER, "retention.days"),
    _t("pg", "predictor_state", STATE,
       "每房 2 行(模型权重 + 探索态)。房间已离场(不在册)且历史已随保留期清空 → 回收;"
       "回来时按冷启动重建",
       "行数 ≤ 2 ×(在册房 + 仍有历史的房)",
       SWEEP_WEB, "retention.state_gc"),
    _t("pg", "rooms", STATE,
       "策展名录。删房只是把行标为停用;停用且无历史、无任何账号绑定的墓碑行 → 回收"
       "(全项目只读 active / pending 两类行,墓碑从不被读)",
       "行数 ≤ 在册房 + 尚有历史/绑定的停用房",
       SWEEP_WEB, "retention.state_gc"),
    _t("pg", "discovered_rooms", STATE,
       "自动发现房的 last_seen 时钟;连续 discovery.prune_grace_s 未再出现在在播列表即回收",
       "行数 ≤ 回收宽限期内出现过的在播房数",
       "worker · 每轮遍历", "discovery.prune_grace_s"),
    _t("pg", "verified_rooms", STATE,
       "核验准入台账;最近一次确认在播超过 discovery.prune_grace_s 即清出",
       "行数 ≤ 宽限期内确认在播过的核验房数",
       "worker · 复核巡检", "discovery.prune_grace_s"),
    _t("pg", "user_rooms", STATE,
       "账号 ↔ 房间绑定;用户解绑即删,运维删房级联删",
       "行数 ≤ 账号数 × userauth.room_max",
       SWEEP_INLINE, "userauth.room_max"),
    _t("pg", "user_added_rooms", STATE,
       "「由登录用户转正」的房标记;该房绑定数归零即摘除",
       "行数 ≤ user_rooms 里出现过的房数",
       SWEEP_INLINE),
    _t("pg", "user_first_login", STATE,
       "每账号恒 1 行的首登标记;刻意永存(删了会把老账号误判回首登、再塞一次预置房)",
       "行数 = 登录过的账号数,每行两个整数",
       SWEEP_NONE),
    _t("pg", "config_revisions", OPERATOR,
       "配置版本链:每次「应用 / 回滚 / 清除覆盖」追加一版,永不自动删"
       "(回滚目标与「需重启」判定都读历史版本)",
       "只有已登录管理员的显式操作才新增一行;每行是覆盖集快照,千字节量级",
       SWEEP_NONE),
    _t("pg", "admin_audit", ROLLING,
       "会话类动作(登录 / 登出 / 登录失败 / 人机验证未过)保留 retention.audit_days 天;"
       "操作类动作(改配置、发卡、删卡墓碑、开通撤销…)是证据,永久保留",
       "会话类写入有全站硬限速(默认口令错 30 次 + 人机验证未过 50 行 + 坏票据 50 行 / 10 分钟,"
       "约每天至多 1.9 万行;限速可经环境变量调)⇒ 保留期内有硬上界;"
       "操作类只随管理员与发卡接口的真实动作增长",
       SWEEP_WEB, "retention.audit_days"),
    # ── MySQL(用户库的 guantai_* 新表;建表见 userauth._SCHEMA) ──────────────
    _t("mysql", "guantai_user_session", EXPIRING,
       "过期满 7 天、或已失效(被顶 / 登出)且静默满 7 天 → 硬删;另有 100 万行上限:"
       "超过时只裁最旧的已失效会话(有效会话一律不碰)",
       "有效会话 ≤ 账号数 × 每账号会话数;已失效会话 ≈ 7 天内的登录次数,被反复登录刷表时"
       "由 100 万行上限封顶",
       SWEEP_WEB, "userauth.session_ttl_h", "userauth.jf_free_session_ttl_h"),
    _t("mysql", "guantai_sso_ticket", EXPIRING,
       "票据过期满 1 天 → 硬删(票据本身 60 秒级短命)",
       "行数 ≈ 近 1 天签发的票据数",
       SWEEP_WEB, "userauth.sso_link_ttl_s"),
    _t("mysql", "guantai_login_log", ROLLING,
       "登录流水:保留 userauth.log_retention_days 天,另有行数上限 userauth.log_max_rows"
       "(保命阀:只留最新的 N 行;低于 10 万按 10 万执行)",
       "行数 ≤ log_max_rows(默认 500 万 ≈ 1.3 GB);正常站点远够不着,被灌时也封得住",
       SWEEP_WEB, "userauth.log_retention_days", "userauth.log_max_rows"),
    _t("mysql", "guantai_reg_log", ROLLING,
       "注册流水:保留期跟随登录流水(reg_log_retention_days=-1),同一行数上限",
       "行数 ≤ log_max_rows",
       SWEEP_WEB, "userauth.reg_log_retention_days", "userauth.log_max_rows"),
    _t("mysql", "guantai_jf_order", ROLLING,
       "未支付单(pending / expired 且未入账)保留 userauth.jf_order_unpaid_retention_days 天;"
       "**已支付单是账本,永不删**",
       "未支付单受下单限频约束(每账号每小时 jf_order_rate_hourly 单)且过期即清;"
       "已支付单 = 真实收款笔数",
       SWEEP_WEB, "userauth.jf_order_unpaid_retention_days", "userauth.jf_order_rate_hourly"),
    _t("mysql", "guantai_jf_grant_log", LEDGER,
       "九法 VIP 开通流水 —— 唯一对账口径,永不删",
       "每行对应一笔真实的开通 / 兑换 / 撤销",
       SWEEP_NONE),
    _t("mysql", "guantai_jf_card", POOL,
       "卡密池:默认不自动删(仍可兑换的卡可能已在用户手里,误删即资损)。"
       "可选排水只碰终态卡:已作废卡按卡龄、已兑换卡按保留期;另有管理台手动删除",
       "只由发卡动作增长(管理台单批 ≤500;外部发卡接口有每小时限频)",
       SWEEP_WEB, "userauth.jf_card_disabled_age_days",
       "userauth.jf_card_used_retention_days", "userauth.jf_card_purge_enabled"),
    _t("mysql", "guantai_jf_vip", STATE,
       "每个开通过九法 VIP 的账号恒 1 行(到期时刻 + 累计时长)",
       "行数 ≤ 账号数",
       SWEEP_NONE),
    _t("mysql", "guantai_invite_code", OPERATOR,
       "注册邀请码:管理员生成,用完 / 过期后留作溯源,不自动删",
       "只有管理员「生成邀请码」才新增",
       SWEEP_NONE),
    _t("mysql", "guantai_user_block", OPERATOR,
       "观测台侧封禁名单:管理员封禁 / 解封(解封即删行)",
       "只有管理员操作才新增;每账号至多 1 行",
       SWEEP_NONE),
])


def tables(store: str) -> List[TablePolicy]:
    return [p for p in TABLES.values() if p.store == store]


# ── admin_audit 的动作分级 ────────────────────────────────────────────────────
# 审计表里混着两种东西,必须分开对待:
#   · 会话类:谁在什么时候进出过后台、谁猜错了口令。**会被攻击者放大**(猜口令),
#     价值随时间衰减 → 留够合规期限后滚动删;
#   · 操作类:改了什么配置、发了多少卡、删掉的卡号墓碑(那是被删卡号的**唯一**
#     存证,见 JFVIP-SYSTEM.md §6.3)、谁看过密钥明文。只随真实操作增长 → 永久保留。
# 两个集合合起来必须覆盖 admin_api.py 里出现的**全部**动作 —— 由
# tests/test_lifecycle.py::test_every_audit_action_is_classified 静态扫描守门:
# 新增一种审计动作而不表态「它算哪一类」,当场变红(不让它静默落进某个默认档)。
AUDIT_SESSION_ACTIONS: Tuple[str, ...] = (
    "login", "login_ticket", "logout",
    "login_fail", "login_captcha_fail", "login_ticket_fail",
)
AUDIT_EVIDENCE_ACTIONS: Tuple[str, ...] = (
    "apply", "rollback", "clear_override", "auth_override", "auth_verify",
    "auth_refresh_now", "kg_accounts_edit", "room_alias", "pending_abandon",
    "login_unlock", "lease_force_release", "reg_mode", "reg_breaker_clear",
    "reg_throttle_clear", "reg_invites_generate", "reg_invite_disable",
    "reg_block", "reg_unblock", "config_reveal",
    "jfvip_cards_gen", "jfvip_cards_issue", "jfvip_cards_disable",
    "jfvip_cards_purge", "jfvip_cards_note", "jfvip_grant", "jfvip_revoke",
    "storage_sweep",
)

# ── Redis 里「按实体拼接」的键族(5.4.0 复查)──────────────────────────────────
# 与 TABLES 同一个用意:Redis 配的是 maxmemory + noeviction,任何一族按房间 / 用户 / 会话 /
# IP 拼接、却既无 TTL 又无删除路径的键,都会让内存随实体数单调增长,写满后全站写入报错。
# 这里逐族声明「凭什么有界」;tests/test_lifecycle.py 静态扫描全仓的 `K_* = "...{...}..."`
# 常量模板**和**代码里用 f-string 现拼的键(第五轮复查补:此前的闸只扫常量,现拼的 31 族
# 全部绕过了登记),与本表对拍 —— 新增一族不登记,当场变红。复查时 snap:{room} 是唯一一族
# 没有答案的(已修复);其余各族的过期机制都已对着代码逐条核实。
REDIS_FAMILIES: Dict[str, str] = {
    "snap:{room}": "房间快照(≈376 字节/房):发现房回收时随之删除;另由 web 每 6 小时回收"
                   "「已不在抓取名录里」的房的快照(判与删同一段 Lua,原子)",
    "awr:{room}:{round}": "award 重试计数:原子窗口计数,300 秒 TTL;成功即删",
    "offmiss:{room}": "官方确证缺失的格点:整键 24 小时 TTL(每次登记续期)",
    "histgate:{room}": "GameHistory 冷却闸:SET NX PX,毫秒级 TTL",
    "rt:{room}": "该房的调度任务索引:任务确认即移出,集合空了 Redis 自动删键;删房 / 回收时整键删除",
    "predreplay:gate:{room}": "命中率补算的每房冷却:EX TTL",
    "verify:probe:{room}": "核验探活的每房冷却:EX TTL",
    "alr:u{uid}": "单设备观看租约:Lua 内 PEXPIRE(租约 TTL)",
    "sig:h:{sid}": "反爬画像:PEXPIRE(观察窗);全局索引 sig:z 在写入侧同管道剪除过窗项",
    "sig:r:{sid}": "反爬画像·访问过的房间:PEXPIRE(观察窗)",
    "sig:f:{sid}": "反爬画像·浏览器足迹:PEXPIRE(足迹 TTL)",
    "guantai:jf:orderrate:{uid}": "下单限频:原子窗口计数(wincount,窗口 TTL)",
    "guantai:jf:redeemfail:{uid}": "兑换失败计数:原子窗口计数(wincount,窗口 TTL)",
    "guantai:jf:reconcile:{uid}": "补单对账限频:原子窗口计数(wincount,窗口 TTL)",
    "guantai:jf:cardapi:badkey:{ip}": "外部发卡接口坏密钥计数(按 IP 段):窗口 TTL",
    "guantai:jf:cardapi:idem:{h}": "外部发卡接口幂等占位:SET NX EX(带 TTL)",
    "guantai:loginchal:{cid}": "登录加码挑战:一次性,EX TTL",
    "guantai:regchal:{cid}": "注册挑战:一次性,EX TTL",
    "powchal:{sid}": "执行证明挑战:EX TTL(另有宽限键,同样带 TTL)",
    "powchal:{sid}:{tab}": "执行证明挑战(按标签页):EX TTL",
    # ── 以下为代码里现拼的键(f-string),不是 K_* 常量 ──────────────────────────────
    "rg:{room}": "每房上游请求冷却闸:SET NX PX(毫秒级 TTL)",
    "rl:detail:u{uid}": "明细接口令牌桶(按用户):桶脚本内 EXPIRE",
    "adm:lf:dev:{did}": "管理台登录失败计数(受信设备):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键)",
    "adm:lf:ip:{bucket}": "管理台登录失败计数(按 IP 段):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键)",
    "adm:rl:{bucket}": "管理台登录请求速率(按 IP 段,每分钟):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键)",
    "adm:au:{action}:{bucket}": "管理台未鉴权失败的审计去重(每桶每窗口一行):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键)",
    "adm:au:{action}:g": "同上的全站计数(按动作,固定几类):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键)",
    "adm:tk:{jti}": "一次性登录票据防重放:SET NX EX(票据有效期 + 5 秒)",
    "adm:tf:{bucket}": "坏票据计数(按 IP 段):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键)",
    "guantai:lf:u:{name}": "登录失败计数(按同名):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键)",
    "guantai:lf:ip:{bucket}": "登录失败计数(按 IP 段):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键)",
    "guantai:lg:al:{cls}:{key}": "登录审计去重(同键同类每窗口一行):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键)",
    "guantai:lg:chal:ip:{bucket}": "登录加码挑战签发计数:原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键),10 分钟窗",
    "guantai:lg:dev:{did}": "受信设备的失败额度:原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键);管理台解锁时删除",
    "guantai:lg:gf:{minute}": "全站登录失败分钟桶(攻击态判定):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键),10 分钟窗",
    "guantai:reg:al:{cls}:{bucket}": "注册审计去重:原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键)",
    "guantai:reg:chal:ip:{bucket}": "注册挑战签发计数:原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键),10 分钟窗",
    "guantai:reg:d24:{net24}": "注册难度阶梯输入(按 /24 网段):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键),10 分钟窗",
    "guantai:reg:fp:{fp}": "注册指纹线索:原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键),10 分钟窗",
    "guantai:reg:g:h:{hour}": "全站注册每小时计数:原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键),2 小时窗",
    "guantai:reg:g:d:{day}": "全站注册每日计数:原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键),48 小时窗",
    "guantai:reg:lk:{name}": "注册同名互斥锁:SET NX EX 30 秒,完成即删",
    "guantai:reg:name:{name}": "同名注册尝试计数:原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键),10 分钟窗",
    "guantai:reg:nt:ip:{bucket}": "「名字已占用」枚举计数:原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键),1 小时窗",
    "guantai:reg:okd:ip:{bucket}": "同 IP 段每日成功注册:原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键),24 小时窗",
    "guantai:reg:try:ip:{bucket}": "同 IP 段每小时注册尝试:原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键),1 小时窗",
    "guantai:reg:tryd:ip:{bucket}": "同 IP 段每日注册尝试:原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键),24 小时窗",
    "guantai:sso:ip:{bucket}": "SSO 票据兑换限频(按 IP 段):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键)",
    "guantai:ssolink:badkey:{bucket}": "SSO 签发坏密钥计数(按 IP 段):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键)",
    "guantai:ssolink:uid:{uid}": "SSO 签发限频(按用户):原子窗口计数(wincount:Lua 一步 INCR + 补 TTL;退还时先查存在,绝不凭空造出无 TTL 的键)",
}

# ══════════════════════════════════════════════════════════════════════════════
# 二、统一清扫引擎
# ══════════════════════════════════════════════════════════════════════════════
FIRST_DELAY_S: Tuple[float, float] = (45.0, 120.0)   # 启动后首扫的抖动窗
INTERVAL_S = 6 * 3600.0          # 常态周期(与旧 _janitor 相同)
BACKLOG_DELAY_S = 60.0           # 上一轮没清完(预算用尽)→ 这么久后续扫
RETRY_DELAY_S = 600.0            # 上一轮报错 / 库未就绪 → 这么久后重试(旧:再等 6 小时)

BUDGET_S = 20.0                  # 单表单轮的时间预算:用尽即收手,余量留给续扫
STMT_TIMEOUT_S = 20.0            # 单条维护语句的超时(走 run_maint,超时不熔断)
TARGET_S = 0.5                   # 自适应目标:单批耗时 ≈ 0.5s
BATCH_START = 2000               # 起步批量(两阶段实测每批 5000 行 ≈ 90ms:选主键 ~25ms + 按主键删 ~65ms,见文档 §7 G)
BATCH_MIN = 200
BATCH_MAX = 20000
PAUSE_S = 0.05                   # 批间小憩:把连接让给业务查询
MAX_FAILS = 3                    # 同一张表连续失败这么多次即放弃本轮

# 清扫状态(进程内;web 单进程)。stores[store] = 最近一轮的结果。
STATUS: Dict[str, Any] = {"boot_ms": now_ms(), "stores": {}, "total_deleted": {}}
_sleep = asyncio.sleep           # run_loop 的等待(单列出来:测试据此核对节拍,不必真等 6 小时)
_RUNNING: set = set()            # 进程内互斥:定时清扫与「立即清扫」不并发
_LOOPS: List[asyncio.Task] = []


def _empty_result() -> Dict[str, Any]:
    # 结果字典的**全部**键都在这里(run_batched / run_once / 无事可做的任务同形),
    # 消费方(管理台、日志、测试)不必逐键判空。
    return {"deleted": 0, "batches": 0, "capped": False, "error": "", "elapsed_ms": 0,
            "batch": 0}


async def run_batched(step: Callable[[int], Awaitable[Any]], *, fixed: int = 0,
                      budget_s: Optional[float] = None,
                      pause_s: Optional[float] = None) -> Dict[str, Any]:
    """把「删到没有为止」拆成小批执行。step(limit) 执行一批并返回实删行数。

    自适应批量:单批明显快于目标 → 翻倍;明显慢 → 减半(与 pt-archiver / gh-ost 的
    节流同一思路:让**耗时**恒定,而不是让**行数**恒定 —— 公网共享库的快慢差一个量级,
    写死行数必然在某台机器上过重)。单批失败(超时 / 锁等待)→ 批量砍到 1/4 再试,
    连续 MAX_FAILS 次仍失败才放弃本轮并记下错误。

    fixed>0:批量固定在该值、不随快慢放大缩小(卡密池排水沿用 4.2.8 的 5000)。单批失败时
    与自适应模式一样按 1/4 收缩重试 —— 第九轮复查:旧语句自带字面 LIMIT,传入的批量不起作用,
    所以固定模式失败即放弃;改成两阶段后每批都按传入的批量执行,收缩才有意义,不收缩反而会在
    慢库上每轮都以同样的 5000 超时、永远前进不了。
    返回 {deleted, batches, capped, error, elapsed_ms, batch};capped=True 表示时间
    预算用尽、还有余量 —— 调用方(run_loop)据此在 BACKLOG_DELAY_S 后续扫。
    """
    budget = BUDGET_S if budget_s is None else float(budget_s)
    pause = PAUSE_S if pause_s is None else float(pause_s)
    out = _empty_result()
    n = int(fixed) if fixed else BATCH_START
    t_start = time.monotonic()
    fails = 0
    while True:
        t0 = time.monotonic()
        try:
            got = int(await step(n) or 0)
        except asyncio.CancelledError:
            raise
        except Exception as e:           # noqa: BLE001 —— 记在这张表头上,不外抛
            fails += 1
            out["error"] = f"{type(e).__name__}: {e}"[:200].rstrip(": ")
            if fails >= MAX_FAILS or n <= BATCH_MIN:
                break
            n = max(BATCH_MIN, n // 4)
            await asyncio.sleep(pause)
            continue
        fails, out["error"] = 0, ""
        dt = time.monotonic() - t0
        out["deleted"] += got
        out["batches"] += 1
        if got < n:
            break                        # 这一批没装满 = 已经删干净
        if time.monotonic() - t_start >= budget:
            out["capped"] = True
            break
        if not fixed:
            if dt < TARGET_S / 2:
                n = min(BATCH_MAX, n * 2)
            elif dt > TARGET_S * 2:
                n = max(BATCH_MIN, n // 2)
        if pause > 0:
            await asyncio.sleep(pause)
    out["elapsed_ms"] = int((time.monotonic() - t_start) * 1000)
    out["batch"] = n
    return out


async def run_once(fn: Callable[[], Awaitable[Any]]) -> Dict[str, Any]:
    """单次调用的任务(Redis 快照回收)包成与 run_batched 同款的结果。"""
    out = _empty_result()
    t0 = time.monotonic()
    out["deleted"] = int(await fn() or 0)
    out["batches"] = 1
    out["elapsed_ms"] = int((time.monotonic() - t0) * 1000)
    return out


Task = Tuple[str, str, Callable[[], Awaitable[Dict[str, Any]]]]   # (表, 规则, 协程工厂)


async def run_tasks(store: str, tasks: List[Task]) -> Dict[str, Any]:
    """顺序跑一组清扫任务,**逐表隔离**:任何一张表抛错只记在它自己头上,后面的照常跑。

    旧 `_janitor` 把五张表放在同一个 try 里 —— 登录流水那条超时,注册流水与卡密池
    排水就被整轮跳过,再等 6 小时。这里每个任务各自 try。
    结果写进 STATUS[stores][store](管理台「储」视图与告警的数据源)并打一行日志。
    """
    t0 = time.monotonic()
    res: Dict[str, Any] = {}
    for table, rule, factory in tasks:
        try:
            r = dict(await factory() or {})
        except asyncio.CancelledError:
            raise
        except Exception as e:           # noqa: BLE001
            r = _empty_result()
            r["error"] = f"{type(e).__name__}: {e}"[:200].rstrip(": ")
        for k, v in _empty_result().items():
            r.setdefault(k, v)
        r.update({"table": table, "rule": rule, "at_ms": now_ms()})
        res[f"{table}:{rule}"] = r
    deleted = sum(int(r["deleted"]) for r in res.values())
    errors = [k for k, r in res.items() if r["error"]]
    capped = [k for k, r in res.items() if r["capped"]]
    summary = {"at_ms": now_ms(), "elapsed_ms": int((time.monotonic() - t0) * 1000),
               "deleted": deleted, "capped": bool(capped), "errors": len(errors),
               "tasks": res}
    prev = STATUS["stores"].get(store) or {}
    summary["next_at_ms"] = prev.get("next_at_ms", 0)
    STATUS["stores"][store] = summary
    STATUS["total_deleted"][store] = int(STATUS["total_deleted"].get(store, 0)) + deleted
    if deleted or errors or capped:
        parts = [f"{r['table']}({r['rule']}) -{r['deleted']}"
                 + ("…未清完" if r["capped"] else "")
                 + (f" ⚠{r.get('note')}" if r.get("note") else "")
                 for r in res.values() if r["deleted"] or r["capped"]]
        line = f"[保留] {store} 清扫:共删 {deleted} 条,耗时 {summary['elapsed_ms'] / 1000:.1f}s"
        if parts:
            line += " · " + " · ".join(parts)
        print(line)
        for k in errors:
            print(f"[保留] ⚠️ {store} 清扫失败 {k}: {res[k]['error']} —— 本轮其余表不受影响,"
                  f"{int(RETRY_DELAY_S // 60)} 分钟后重试")
    return summary


async def exclusive(store: str, fn: Callable[[], Awaitable[Dict[str, Any]]]) -> Dict[str, Any]:
    """同一存储的清扫不并发(定时轮与管理台「立即清扫」撞车时,后到的直接回 busy)。
    web 单线程事件循环:判与占之间没有 await,无竞态。"""
    if store in _RUNNING:
        return {"busy": True}
    _RUNNING.add(store)
    try:
        return await fn()
    finally:
        _RUNNING.discard(store)


def _set_next(store: str, delay_s: float) -> None:
    STATUS["stores"].setdefault(store, {})["next_at_ms"] = now_ms() + int(delay_s * 1000)


async def run_loop(store: str, sweep: Callable[[], Awaitable[Dict[str, Any]]]) -> None:
    """清扫主循环。相对旧实现(`while True: sleep(6h); 清`)改了三处节拍:

      · **先短等再清**:首扫在启动后 45~120s。旧实现要先睡满 6 小时 —— 进程活不过
        6 小时(频繁发版 / 崩溃重启 / 定时重启)就永远清不到;停机几天后重新拉起,
        攒下的积压也要白等 6 小时。
      · **清不完就续扫**:任一张表预算用尽(capped)→ 60s 后接着清,不等 6 小时。
      · **失败快重试**:有表报错 / 库还没就绪 → 10 分钟后重试(旧:再等 6 小时,且无声)。
    """
    delay = random.uniform(*FIRST_DELAY_S)
    while True:
        _set_next(store, delay)
        await _sleep(delay)
        delay = INTERVAL_S
        try:
            res = await exclusive(store, sweep)
            if res.get("capped"):
                delay = BACKLOG_DELAY_S
            elif res.get("errors") or res.get("skipped") or res.get("busy"):
                delay = RETRY_DELAY_S
        except asyncio.CancelledError:
            raise
        except Exception as e:           # noqa: BLE001 —— 循环本身绝不死
            print(f"[保留] ⚠️ {store} 清扫轮异常: {e!r} —— {int(RETRY_DELAY_S // 60)} 分钟后重试")
            delay = RETRY_DELAY_S


# ── PostgreSQL 小表(web 进程;大表 rounds/predictions 归 worker._retention) ────
async def sweep_pg(db) -> Dict[str, Any]:
    from .settings import settings
    r = settings.retention
    tasks: List[Task] = []
    days = float(getattr(r, "audit_days", 0) or 0)
    if days > 0:
        cutoff = now_ms() - int(days * 86_400_000)
        tasks.append(("admin_audit", "会话类超期", lambda: run_batched(
            lambda n: db.audit_purge_batch(cutoff, AUDIT_SESSION_ACTIONS, n))))
    if bool(getattr(r, "state_gc", True)):
        tasks.append(("predictor_state", "离场房回收",
                      lambda: run_batched(db.gc_predictor_state)))
        tasks.append(("rooms", "停用墓碑回收", lambda: run_batched(db.gc_room_tombstones)))
    return await run_tasks("pg", tasks)


async def sweep_mysql() -> Dict[str, Any]:
    from . import userauth
    return await userauth.janitor_sweep()


async def sweep_redis(bus) -> Dict[str, Any]:
    """Redis:回收已离场房间的快照(见 RedisBus.gc_orphan_snapshots 与 REDIS_FAMILIES)。"""
    return await run_tasks("redis", [("snap:{room}", "离场房快照回收",
                                      lambda: run_once(bus.gc_orphan_snapshots))])


async def sweep_now(db, bus=None) -> Dict[str, Any]:
    """管理台「立即清扫」:各存储各跑一轮(进程内直接调用)。正在跑定时轮的回 busy。"""
    out = {"pg": await exclusive("pg", lambda: sweep_pg(db))}
    out["mysql"] = await exclusive("mysql", sweep_mysql)
    if bus is not None:
        out["redis"] = await exclusive("redis", lambda: sweep_redis(bus))
    invalidate_snapshot()
    return out


def start(db, bus=None) -> None:
    """web.lifespan 调用:起 PG 小表与 Redis 快照的回收循环。用户库那一路由 userauth.init 起
    (`_janitor`),登录系统未启用时它根本不存在 —— 各路互不依赖。"""
    _LOOPS.append(asyncio.create_task(run_loop("pg", lambda: sweep_pg(db))))
    if bus is not None:
        _LOOPS.append(asyncio.create_task(run_loop("redis", lambda: sweep_redis(bus))))


async def stop() -> None:
    for t in _LOOPS:
        t.cancel()
        with contextlib.suppress(BaseException):
            await t
    _LOOPS.clear()


# ══════════════════════════════════════════════════════════════════════════════
# 三、容量观测
# ══════════════════════════════════════════════════════════════════════════════
SNAPSHOT_TTL_S = 15.0            # 体检结果短缓存:连点刷新不该变成对公网用户库的连环查询
STALL_FACTOR = 2.5               # 距上次清扫超过 周期×本值 = 停摆
CAP_WARN_RATIO = 0.8             # 行数达上限的八成即告警(正常站点远够不着,够着了多半是被灌)
_SNAP: Dict[str, Any] = {"at": 0.0, "data": None}


WORKER_STALL_FACTOR = 3.0        # worker 大表清理:距上次成功超过 3 个巡检周期 = 停摆(默认 3 小时)


def worker_retention_view(last: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """把 worker 写在 Redis 的 retention:last 翻成与 run_tasks 同形的状态,让「储」视图里
    rounds / predictions(最大的两张表)也有「上次清扫」。没有记录 → {}。"""
    if not last or not last.get("ts_ms"):
        return {}
    days = last.get("days")
    rule = f"超过 {float(days):g} 天" if isinstance(days, (int, float)) else "超期"
    at, capped = int(last["ts_ms"]), bool(last.get("capped"))
    ms = int(float(last.get("elapsed_s") or 0) * 1000)

    def one(table: str) -> Dict[str, Any]:
        r = _empty_result()
        r.update({"table": table, "rule": rule, "deleted": int(last.get(table) or 0),
                  "capped": capped, "elapsed_ms": ms, "at_ms": at})
        return r
    return {"at_ms": at, "elapsed_ms": ms, "capped": capped, "errors": 0,
            "deleted": int(last.get("rounds") or 0) + int(last.get("predictions") or 0),
            "interval_s": int(last.get("interval_s") or 0),
            "tasks": {f"rounds:{rule}": one("rounds"), f"predictions:{rule}": one("predictions")}}


def worker_retention_alert(last: Optional[Dict[str, Any]],
                           now: Optional[int] = None) -> Optional[Dict[str, str]]:
    """worker 的 rounds / predictions 清理停摆了吗?(纯函数,零查询;总览与「储」共用)

    worker 每轮**成功**清理后才写 retention:last(出错只打日志),所以「记录太旧」就是
    停摆的统一症状:worker 没在跑、清理持续报错、跨副本锁卡住,都会落到这里。周期优先
    取 worker 自己记下的 interval_s;老版本 worker 没写这个字段时退回本进程配置。
    历史被设为永久保留(retention.days ≤ 0)时 worker 本就不清,不报停摆(另有黄条)。"""
    from .settings import settings
    r = settings.retention
    if float(getattr(r, "days", 0) or 0) <= 0:
        return None
    interval = max(60, int((last or {}).get("interval_s")
                           or getattr(r, "sweep_interval_s", 3600) or 3600))
    now = int(now or now_ms())
    ref = int((last or {}).get("ts_ms") or 0) or int(STATUS["boot_ms"])
    if now - ref <= interval * WORKER_STALL_FACTOR * 1000:
        return None
    return {"level": "bad",
            "text": f"出怪 / 预测历史(rounds、predictions —— 最大的两张表)的清理已有 "
                    f"{(now - ref) / 3_600_000:.1f} 小时没有成功跑过(应每 {interval // 60} 分钟一轮)"
                    f"—— 请看 worker 是否在运行、日志里有没有「retention 异常」"}


def invalidate_snapshot() -> None:
    _SNAP["at"] = 0.0


def _sweeper_now(p: TablePolicy, eff: Optional[Dict[str, Any]]) -> str:
    """「谁来清」按**当前生效配置**说实话(第十一轮):登记里写的是这张表归谁清,但对应开关关着时,
    界面不能还写「每 6 小时」—— 卡密池排水默认就是关的,旧写法让运维以为「在清、只是没东西可清」。"""
    if not eff:
        return p.sweeper
    t, off = p.table, ""
    if t in ("rounds", "predictions") and eff["retention.days"] <= 0:
        off = "已关闭(retention.days ≤ 0,永久保留)"
    elif t == "admin_audit" and eff["retention.audit_days"] <= 0:
        off = "已关闭(retention.audit_days = 0,会话类审计永久保留)"
    elif t in ("predictor_state", "rooms") and not eff["retention.state_gc"]:
        off = "已关闭(retention.state_gc 为关)"
    elif t == "guantai_login_log" and eff["userauth.log_retention_days"] <= 0 and eff["userauth.log_max_rows"] <= 0:
        off = "已关闭(保留期与行数上限都为 0)"
    elif t == "guantai_reg_log" and eff["userauth.reg_log_retention_days"] <= 0 and eff["userauth.log_max_rows"] <= 0:
        off = "已关闭(保留期与行数上限都为 0)"
    elif t == "guantai_jf_order" and eff["userauth.jf_order_unpaid_retention_days"] <= 0:
        off = "已关闭(未支付订单永久保留)"
    elif t == "guantai_jf_card" and eff["userauth.jf_card_disabled_age_days"] <= 0 \
            and eff["userauth.jf_card_used_retention_days"] <= 0:
        off = "未开启(默认关;参数中心「数据保留」可开)"
    return off or p.sweeper


def _row(p: TablePolicy, st: Optional[Dict[str, Any]],
         eff: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    st = st or {}
    return {"table": p.table, "klass": p.klass, "klassLabel": KLASS_LABEL[p.klass],
            "policy": p.policy, "bound": p.bound, "sweeper": _sweeper_now(p, eff),
            "knobs": list(p.knobs), "present": bool(st),
            "rows": st.get("rows"), "bytes": st.get("bytes"),
            "exact": bool(st.get("exact")), "oldest": st.get("oldest")}


def _effective() -> Dict[str, Any]:
    """与保留有关的**实际生效值**(界面上策略文案里的参数,此刻到底是多少)。"""
    from . import userauth
    from .settings import settings
    # 用户库各项读 **UA.cfg** —— janitor_sweep 用的就是它。生产里它与 settings.userauth
    # 是同一个对象;这里显式取它,保证「界面显示的」与「清扫执行的」永远是同一份。
    r, u = settings.retention, (getattr(userauth.UA, "cfg", None) or settings.userauth)
    days = int(getattr(u, "log_retention_days", 0) or 0)
    rdays = int(getattr(u, "reg_log_retention_days", -1))
    return {
        "retention.days": float(r.days),
        "retention.audit_days": float(getattr(r, "audit_days", 0) or 0),
        "retention.state_gc": bool(getattr(r, "state_gc", True)),
        "userauth.log_retention_days": days,
        "userauth.reg_log_retention_days": days if rdays < 0 else rdays,
        "userauth.log_max_rows": userauth.log_cap(u),                 # 已含下限
        "userauth.jf_order_unpaid_retention_days": userauth.order_unpaid_days(u),
        "userauth.jf_card_disabled_age_days": int(getattr(u, "jf_card_disabled_age_days", 0) or 0),
        "userauth.jf_card_used_retention_days":
            int(getattr(u, "jf_card_used_retention_days", 0) or 0),
    }


def _alerts(snap: Dict[str, Any]) -> List[Dict[str, str]]:
    """把「会出事」的状态翻成人话。level: bad(正在出事)/ warn(迟早出事)。"""
    eff = snap["effective"]
    out: List[Dict[str, str]] = []

    def add(level: str, text: str) -> None:
        out.append({"level": level, "text": text})

    if eff["retention.days"] <= 0:
        add("warn", "出怪 / 预测历史被设为永久保留(retention.days ≤ 0):"
                    "rounds 与 predictions 两张表会一直涨下去,磁盘迟早写满")
    my = snap["mysql"]
    if my.get("enabled"):
        if eff["userauth.log_retention_days"] <= 0 and eff["userauth.log_max_rows"] <= 0:
            add("warn", "登录流水既没有保留期也没有行数上限"
                        "(log_retention_days=0 且 log_max_rows=0):它会无限增长")
        cap = eff["userauth.log_max_rows"]
        for t in my.get("tables", []):
            if cap > 0 and t["table"] in ("guantai_login_log", "guantai_reg_log") \
                    and (t.get("rows") or 0) >= cap * CAP_WARN_RATIO:
                add("bad", f"{t['table']} 已有约 {t['rows']} 行,达到行数上限 {cap} 的 "
                           f"{int((t['rows'] or 0) * 100 / cap)}% —— 正常站点远到不了这里,"
                           f"多半正在被灌(见「登」登录风控);超过上限的最旧记录会被裁掉")
        if my.get("error"):
            add("bad", "用户库容量体检失败:" + str(my["error"]))
    for store, label in (("pg", "观测库(PostgreSQL)"), ("mysql", "用户库(MySQL)"),
                         ("redis", "Redis")):
        if store == "mysql" and not my.get("enabled"):
            continue
        if store == "redis" and store not in snap["sweeps"]["stores"]:
            continue                      # 没起 Redis 回收循环(如单测直接调用),不判停摆
        st = (snap["sweeps"]["stores"].get(store) or {})
        for k, r in (st.get("tasks") or {}).items():
            if r.get("error"):
                add("bad", f"{label} 上次清扫失败:{r['table']}({r['rule']})—— {r['error']}")
            elif r.get("note"):
                add("bad", f"{label} {r['table']}:{r['note']},本轮裁掉 {r['deleted']} 行")
        last = int(st.get("at_ms") or 0)
        ref = last or int(snap["sweeps"]["boot_ms"])
        if now_ms() - ref > INTERVAL_S * STALL_FACTOR * 1000:
            add("bad", f"{label} 的清扫已超过 {int((now_ms() - ref) / 3_600_000)} 小时没有跑过"
                       f"(应每 {int(INTERVAL_S // 3600)} 小时一轮)—— 请看 web 日志")
    if "worker_last" in snap["sweeps"]:     # 只有完整体检才带(要读 Redis);总览另行拼接
        wa = worker_retention_alert(snap["sweeps"]["worker_last"])
        if wa:
            out.append(wa)
    for name in snap["pg"].get("unregistered", []) + my.get("unregistered", []):
        add("warn", f"表 {name} 没有登记生命周期策略(app/lifecycle.py 的 TABLES)"
                    f"—— 没人声明过它凭什么不会无限增长")
    rd = snap.get("redis") or {}
    if rd.get("maxmemory") and rd.get("used", 0) >= rd["maxmemory"] * CAP_WARN_RATIO:
        add("bad", f"Redis 内存已用 {int(rd['used'] * 100 / rd['maxmemory'])}%"
                   f"(上限 {rd['maxmemory'] // (1 << 20)} MB,策略 noeviction):"
                   f"写满后所有写入都会报错,抓取与登录限流会一起停摆")
    return out


def quick_alerts() -> List[Dict[str, str]]:
    """**零查询**告警(只看进程内的清扫状态与配置):清扫报错 / 触及行数上限 / 清扫停摆 /
    保留期被关。给总览驾驶舱用 —— 它每隔几秒自动刷新,不能为此去查公网用户库;
    需要查库才知道的(行数逼近上限、未登记表、Redis 内存)留在「储」视图。"""
    from . import userauth
    return _alerts({"effective": _effective(),
                    "mysql": {"enabled": bool(userauth.enabled()), "tables": [],
                              "unregistered": [], "error": ""},
                    "pg": {"unregistered": []}, "redis": {},
                    "sweeps": {"boot_ms": STATUS["boot_ms"], "stores": STATUS["stores"]}})


async def snapshot(db, redis=None, *, fresh: bool = False) -> Dict[str, Any]:
    """一次容量体检(只读)。任何一路取数失败只让那一路降级并点名,绝不整体 500。"""
    if not fresh and _SNAP["data"] is not None \
            and time.monotonic() - _SNAP["at"] < SNAPSHOT_TTL_S:
        return _SNAP["data"]
    from . import userauth
    snap: Dict[str, Any] = {"ok": True, "now_ms": now_ms(), "effective": _effective(),
                            "intervalS": INTERVAL_S,
                            "sweeps": {"boot_ms": STATUS["boot_ms"],
                                       "stores": STATUS["stores"],
                                       "total_deleted": STATUS["total_deleted"],
                                       "running": sorted(_RUNNING)}}
    # ── PostgreSQL ──
    pg: Dict[str, Any] = {"db_bytes": None, "tables": [], "unregistered": [], "error": ""}
    try:
        st = await db.storage_stats()
        pg["db_bytes"] = st["db_bytes"]
        seen = st["tables"]
        pg["tables"] = [_row(p, seen.get(p.table), snap["effective"]) for p in tables("pg")]
        known = {p.table for p in tables("pg")}
        pg["unregistered"] = sorted(t for t in seen if t not in known)
    except Exception as e:               # noqa: BLE001
        pg["error"] = f"{type(e).__name__}: {e}"[:200]
        pg["tables"] = [_row(p, None, snap["effective"]) for p in tables("pg")]
    snap["pg"] = pg
    # ── MySQL 用户库 ──
    my: Dict[str, Any] = {"enabled": bool(userauth.enabled()), "tables": [],
                          "unregistered": [], "error": ""}
    seen_my: Dict[str, Any] = {}
    if my["enabled"]:
        try:
            seen_my = await userauth.storage_stats()
        except Exception as e:           # noqa: BLE001
            my["error"] = f"{type(e).__name__}: {e}"[:200]
        known = {p.table for p in tables("mysql")}
        my["unregistered"] = sorted(t for t in seen_my if t not in known)
    my["tables"] = [_row(p, seen_my.get(p.table), snap["effective"]) for p in tables("mysql")]
    snap["mysql"] = my
    # ── Redis ──
    rd: Dict[str, Any] = {}
    if redis is not None:
        # 只有**读成功**才判 worker 停摆:读失败(Redis 故障)时若当成「没有记录」,web 跑满
        # 3 小时后就会误报「worker 清理停摆」,把排障方向引错。坏 JSON 视同没有记录。
        try:
            from .redis_bus import K_RET_LAST
            raw = await redis.get(K_RET_LAST)
        except Exception:                # noqa: BLE001 —— Redis 那一路下面另有降级
            raw = False
        if raw is not False:
            import json as _json
            try:
                last = _json.loads(raw) if raw else None
            except (ValueError, TypeError):
                last = None
            snap["sweeps"]["worker_last"] = last
            snap["sweeps"]["worker"] = worker_retention_view(last)
        with contextlib.suppress(Exception):
            info = await redis.info("memory")
            rd = {"used": int(info.get("used_memory") or 0),
                  "maxmemory": int(info.get("maxmemory") or 0),
                  "policy": str(info.get("maxmemory_policy") or ""),
                  "keys": int(await redis.dbsize())}
    snap["redis"] = rd
    snap["alerts"] = _alerts(snap)
    _SNAP["at"], _SNAP["data"] = time.monotonic(), snap
    return snap
