"""
pred_replay.py — 灵机推演命中率的「事后补算」(4.6.0)
================================================================================
一句话:房间转正为策展房时,用**生产同一条代码路径**、按**严格因果**的时序把
最近 N 局重跑一遍,把窗口里缺失的命中判定补齐,并逐行打上 `source='replay'`。

── 为什么需要它 ──────────────────────────────────────────────────────────────
3.4.5 策展闸规定:自动发现房只抓取入库、**不跑预测引擎**(6891 房×每局 5.5ms =
预测独占 0.83 核,而产出没有任何人看得到)。代价是——用户把一个房加进名录的那
一刻,`predictions` 表里一行都没有,`accuracy` 只能回 n=0,推演卡的命中率整行
空白;要攒满默认 100 局窗口得等 100×50.001s ≈ 83 分钟。

而 `db.accuracy` 修正为按「最近 window **局**」锚定之后(见其文档),原先靠陈年
旧行凑出来的假窗口也不再成立 —— 该空的就空。补算就是把这个窗口**用合法手段**
真正填满。

── 为什么补算是合法的(而不是编数字)────────────────────────────────────────
预测引擎 `Predictor.predict()` 是 `(seq, cfg, kv)` 的**纯确定性函数**:
`spell_tamer_monitor.py` 全文件没有 `import random`,热路径不读墙钟,全部状态
(model_weights / explore_state)都可序列化。于是「用截至第 t-1 局的数据预测第 t
局」这件事,事后重跑与当时实跑是同一个函数、同一份输入。

本模块逐条复刻生产时序(worker._settle_and_predict):
  ① 新局落地 → 若手里有指向该局的预测,先按**主优先**判定命中
     (与 db.fill_prediction_outcome 逐字同规则),再 `update_after_settle` 推权重;
  ② 训练序列 = `start_ms >= now - train_window_hours` 且取最新 `max_train` 条
     (与 db.sequence 的 SQL 逐字同源);
  ③ `run_prediction` 生成**下一局**预测,kv 逐局向前传递。
任何一步都只用得到「该局及之前」的数据 —— 零前视。

── 诚实边界(三条,写进文档也写进 UI)────────────────────────────────────────
**补算是回测,不是实盘战绩。** 即便逐局全同也仍有三处不可消除的偏差:
  1. 用**今天**的 config 回放**过去**的数据。这套超参有 30 余个,若曾在同一段
     数据上调过,即为样本内偏差;
  2. 回放读的是数据库的**最终状态**,含后来被 GameHistory 补齐的局 —— 生产在
     当时未必拿得到,这是训练集层面的轻微事后信息;
  3. 生产当时的票据过期、任务迟到、妖兽未知(cid=NULL)跳过结算,补算都不会重现。
所以补算行**必须**带 `source='replay'`,`accuracy` 必须把它单独计数,前端必须
显式标注。把补算伪装成实盘是本模块唯一不可接受的用法。

── 热身长度是唯一的关键参数(实测,非估计)──────────────────────────────────
在 3 个真机房(各 1500~1800 局真实出怪 + 真机落库预测)上做的还原度实测:

  热身  30 局 → 判定逐局相同 81~84%,四码全同 42~45%,命中率最大偏差 6pp
  热身 100 局 → 判定逐局相同 89~93%,四码全同 53~67%,命中率最大偏差 5pp
  热身 200 局 → 判定逐局相同 96~99%,四码全同 79~90%,命中率偏差 ≤1pp
  热身 400 局 → 判定逐局相同 98~99%,四码全同 89~93%,命中率偏差 ≤1pp

真 Redis + 真 PG 的 worker 集成实测(窗 100 + 热身 400 + 24h 训练窗):
单房 **2.40s**、逐局判定还原 **99%**、命中率 33%/66% vs 真机 34%/66%。
(该数字曾长期被写成 1.9s —— 那是早期测量脚本只跑最后 500 局的结果,而生产实现
 当时对整个训练窗前缀也逐局空跑,真实是 6.63s。见下方 start 的注释。)

四码永远做不到 100% 复现:集成概率 `ens` 的差异普遍在 1e-3 量级,而
`explore_tie_eps` 默认 0.004 —— 差异正落在平局容差带内,会翻转近似并列的选位。
这是**结构性**的(补算无法复刻生产 kv 的完整轨迹),不是缺陷。但它在「命中率」
这个统计量上被洗掉了:100 局样本自身的 1σ 抽样噪声就有 4.7pp,远大于 ≤1pp 的
系统偏差。故默认热身取 400,并且**热身不足的目标局一行都不写**——宁可窗口不满,
不可给不可信的数。
"""
from __future__ import annotations

import bisect
import dataclasses
import hashlib
import json
import logging
from typing import Any, Dict, List, Sequence, Tuple

from .constants import ROUND_STEP

log = logging.getLogger("pred_replay")

# 训练窗时间锚:生产是「处理出怪那一刻的 now_ms()」,补算只能从落库字段重建。
# draw_ms 缺失时以起局 + AWARD_CHAIN_MS 兜底(= award 退避链 1.5+3+6+12+24s 的
# 上界,取最晚的保守估计);再加 INGEST_LAG_MS(备战后抓取入库的经验值)。
# 与 window_audit/replay_harness.py 逐值一致 —— 运维可用那个离线工具复核本模块。
# 敏感性实测:把该锚整体偏移 ±120s,1748 局里只有 3 局预测变化(99.8% 全同),
# 故此处的近似不构成风险。
AWARD_CHAIN_MS = 46_500
INGEST_LAG_MS = 1_500


def config_fingerprint(bridge: Any) -> str:
    """引擎**实际消费**的那份预测配置的稳定指纹(12 位 hex)。

    ── 为什么必须有它 ────────────────────────────────────────────────────
    全部预测超参都是热更项(config_registry 里一律 hot=HOOK/hook="bridge",
    改动即原子换桥),而 window_audit/ 这个离线调参工具的存在本身就说明
    「调超参」是预期中的运维动作。一旦调过:
      · 窗口里既有**旧配置**算出的补算行,又有**新配置**产出的实盘行;
      · 用户只看到一个命中率,分不出这是两套口径的混合。
    真机实测过这个错配的量级:用默认超参补算、拿调优超参产出的真机数据对拍,
    逐局判定还原从 97% 塌到 57%、主+防偏差 11pp —— 远超 100 局样本自身
    4.7pp 的抽样噪声。所以这不是洁癖,是会让数字失真的真问题。

    指纹取自 `bridge.pcfg`(PredictorBridge 已按 E.PredictionConfig 的字段过滤,
    正是引擎真正读到的那些键),排序后序列化再哈希 —— 必须稳定,否则补算行
    每轮都被判过期、无限重算烧 CPU。replay_* 这类**运维参数**天然不在
    dataclass 字段里,调它们不会误触发重算。
    """
    try:
        d = dataclasses.asdict(bridge.pcfg)
    except Exception:                                     # noqa: BLE001
        return ""
    # 4.9.4:**关闭状态的开关必须不进指纹**。asdict 是全字段的,新增任何一个字段都会
    # 让指纹在升级瞬间变值 —— 于是每个房窗口里的补算行**全部被判 stale、删掉重算**,
    # 而 prior_shrink=False 时新算出来的与删掉的**逐位相同**(引擎与 4.9.3 字节等价,
    # 由 tests/test_prior_shrink.py 钉守)。那是一次纯粹白烧:PG 写入尖峰、日志刷屏、
    # 前端「近 N 局」的分母在重算完成前短暂塌陷 —— 而用户盯的正是那个数。
    # 语义上也该这么做:关着的时候旧行与新行确实可比,没有任何理由判它过期。
    # (同一条教训在 _fr_key 上已犯过一次,见 spell_tamer_monitor 的 `_pri` 注释。)
    if not d.get("prior_shrink"):
        d.pop("prior_shrink", None)
        d.pop("prior_table", None)
    blob = json.dumps(d, sort_keys=True, default=str, ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:12]


def _hit_of(cid: int, main: Sequence[int], guard: Sequence[int]) -> str:
    """命中判定 —— 与 db.fill_prediction_outcome 的三元表达式逐字一致(主优先)。
    这两处**必须**同规则:分歧会让补算行与实盘行的口径不可比。"""
    return "main" if cid in main else ("guard" if cid in guard else "miss")


def replay_window(bridge: Any, cfg: Dict[str, Any], room: str,
                  rounds: List[dict], missing: Sequence[int],
                  warmup: int, now_ms_v: int = 0,
                  cfg_fp: str = "") -> List[tuple]:
    """按生产时序因果回放,返回可直接落库的补算行。

    参数
      bridge   PredictorBridge(与 worker 同一个实例;只调纯计算方法)
      cfg      settings.prediction(读 train_window_hours / max_train)
      rounds   **升序**的局(dict: round_id/custom_id/start_ms/draw_ms),
               必须已按调用方需要裁剪 —— 本函数从 rounds[0] 开始热身
      missing  窗口内缺判定的目标局(补算只写这些;其余局照跑不写,用于推进状态)
      warmup   目标局之前至少要有多少次预测才允许写(见模块头注的实测表)
    返回
      [(round_id, main_ids, guard_ids, detail, actual_cid, hit), …]

    **绝不触碰 PG 里的 predictor_state**:kv 从空字典冷启动、只在本函数内传递、
    结束即丢弃。原因有二 —— ① PG 里那份是**当前**(相对被回放区间属于未来)状态,
    注入进来就是前视污染;② 反向写回会改变实盘预测流,而 predictor_bridge.py
    头注写明「用户明确要求不改预测逻辑」。故实盘预测结果逐字节不受本模块影响。
    """
    want = set(int(x) for x in missing)
    if not rounds or not want:
        return []
    tw_h = float(cfg.get("train_window_hours", 24.0) or 0)
    tw_ms = int(tw_h * 3600 * 1000) if tw_h > 0 else 0
    max_train = int(cfg.get("max_train", 5000))
    starts = [int(r["start_ms"] or r["round_id"]) for r in rounds]
    cids = [int(r["custom_id"]) for r in rounds]

    # ── 起跑点:跳过「纯训练窗前缀」──────────────────────────────────────
    # rounds 的前一大段只是为**第一条目标**提供 24h 训练窗(plan_span 特意多取的),
    # 它们需要作为**数据**存在(下面 bisect 会回看到),但**不需要各跑一次预测**。
    # 真机实测:窗 100 + 热身 400 时 plan_span 喂进 1778 局,其中 1278 局属此列 ——
    # 逐局空跑一遍是 3.6× 的无谓开销(6.63s → 1.86s)。
    # 起跑点 = 第一条目标的生成局(它的前一局)再往前 warmup 局。
    first_t = min(want)
    j = bisect.bisect_left([int(r["round_id"]) for r in rounds], first_t)
    start = max(0, j - 1 - int(warmup))

    kv: Dict[str, str] = {}
    # target_round_id -> (models, ens, main, guard, ran, train_n)
    #   ran = 生成该条预测之前**已经跑过的预测次数** = 它真实的热身长度。
    #   刻意不用绝对下标 —— 起跑点前移后二者不再相等,用下标会让热身闸失真。
    #   4.9.5:元组末位追加 train_n —— 补算行也要能回答「这条是用多少局训练出来的」,
    #   与实盘 detail 同键(worker 两个写入点已落 train_n)。plan_span 的计数制缺陷
    #   就藏在这个量里,没有它,补算口径塌缩在库里查不出来。
    pending: Dict[int, Tuple[dict, list, list, list, int, int]] = {}
    out: List[tuple] = []
    ran = 0

    for i in range(start, len(rounds)):
        r = rounds[i]
        rid = int(r["round_id"])
        cid = cids[i]
        p = pending.pop(rid, None)
        if p is not None:
            models, ens, main, guard, warm_of, train_n = p
            hit = _hit_of(cid, main, guard)
            # 只写「窗口内缺判定」且「热身够」的局。warm_of = 生成这条预测时
            # 已经跑过的预测次数 —— 它就是该条的真实热身长度。
            if rid in want and warm_of >= warmup:
                out.append((rid, list(main), list(guard),
                            {"ens": [round(float(v), 6) for v in ens],
                             "train_n": int(train_n),
                             "replay": {"warmup": int(warm_of),
                                        "at": int(now_ms_v),
                                        "cfg": str(cfg_fp)}},
                            cid, hit))
            # 权重推进照跑(哪怕这条不写):它是后续局状态的一部分,漏掉就断链。
            kv.update(bridge.update_after_settle(
                room, {"models": models, "ens": ens}, cid, kv))

        draw = int(r["draw_ms"] or 0) or (starts[i] + AWARD_CHAIN_MS)
        now = draw + INGEST_LAG_MS
        lo = bisect.bisect_left(starts, now - tw_ms, 0, i + 1) if tw_ms > 0 else 0
        seq = cids[lo:i + 1][-max_train:]
        if not seq:
            continue
        res, dirty = bridge.run_prediction(room, seq, kv)
        kv.update(dirty)
        pending[rid + ROUND_STEP] = (res["models"], list(res["ens"]),
                                     [int(x) for x in res["main"]],
                                     [int(x) for x in res["guard"]], ran,
                                     int(res.get("train_n") or len(seq)))
        ran += 1
    return out


def plan_span(missing: Sequence[int], warmup: int,
              train_window_hours: float, max_train: int = 5000) -> int:
    """补算需要往前取多少毫秒的局(调用方据此定 rounds_since 的下界)。

    = 最早缺口 − 热身局数 − 一个完整训练窗 − 一点余量。
    宁可多取一点(多取只是多几百行 SELECT),少取会让最早的几条热身不足而被丢弃。

    **训练窗有两种制式,回取跨度必须跟着换**(4.9.5 修正):
      · `train_window_hours > 0` → 时间制,回取一个完整时间窗;
      · `train_window_hours <= 0` → **不限时间、改由 max_train 计数封顶**,
        此时时间窗为 0,若仍按 0 回取,`replay_window` 里的 `lo=0` 会让
        `seq = cids[0:i+1][-max_train:]` 只拿到本函数取回来的那一小段 ——
        塌成 `warmup+8` 局。实测:warmup=400 时回取跨度只有 408 局,
        而实盘同配置的 `db.sequence` 会取到 max_train(默认 5000)局
        ⇒ 补算与实盘**不是同一个口径**,且首条目标只剩约 8 局训练样本,
        正落在近随机带(见 constants.MIN_TRAIN_WINDOW_H 的实测表)。
        故计数制下额外回取 max_train 局。

    max_train 缺省取注册表默认值 5000,只为兼容既有位置调用;worker 侧
    **必须显式传入生效值**,否则运维调大 max_train 后补算会偷偷少喂样本。
    """
    if not missing:
        return 0
    tw_h = float(train_window_hours or 0)
    tw_ms = int(max(0.0, tw_h) * 3600 * 1000)
    extra = 0 if tw_h > 0 else max(0, int(max_train or 0)) * ROUND_STEP
    return (int(min(missing)) - (int(warmup) + 8) * ROUND_STEP - tw_ms - extra)
