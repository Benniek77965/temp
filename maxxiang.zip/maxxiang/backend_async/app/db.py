"""
db.py — PostgreSQL 异步数据层(asyncpg 连接池 + 建表 + 读写 DAO)
================================================================================
用 PostgreSQL 承接高频并发写入,替代 SQLite 的单写者锁。表结构对齐旧 SQLite
(rounds / predictions / predictor_state[=旧 kv] / rooms),但用 Postgres 原生类型
与 UPSERT,并预留 TimescaleDB 超表(可选,见 migrations 注释)。

  · rounds           每局出怪结果(抓取端幂等写入 ON CONFLICT DO NOTHING)
  · predictions      每局预测 + 结算回填(命中率来源)
  · predictor_state  预测器每房状态(model_weights / explore_state);等价旧 kv 表
  · rooms            房间登记(与 Redis 注册表互为持久化镜像)

所有方法都是 async;连接从进程级 asyncpg.Pool 借还。
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import os
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

import asyncpg

from .constants import BEIJING_TZ, ROUND_STEP

SCHEMA = """
CREATE TABLE IF NOT EXISTS rounds (
    room_id     TEXT        NOT NULL,
    round_id    BIGINT      NOT NULL,
    beast_name  TEXT        NOT NULL,
    official_id INTEGER,
    custom_id   SMALLINT,
    multiplier  INTEGER,
    start_ms    BIGINT,
    draw_ms     BIGINT,
    draw_local  TEXT,
    date_local  TEXT,
    source      TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (room_id, round_id)
);
-- ── 4.9.5 索引瘦身(真机 A/B 实测驱动;详见 PG-INDEX-DIET.md) ─────────────────
-- 本表是全库写入最热的滚动流水,每多一个索引就在**每一次 INSERT 和每一趟
-- VACUUM** 上按比例收税。实测(PG16.14 · 180 万行 · 同机同数据):
--     逐行 INSERT   2 索引 24161 行/s   vs  5 索引 15623 行/s   → 慢 1.55×
--     VACUUM(删24万) 2 索引 0.29s        vs  5 索引 0.60s        → 慢 2.07×
--     索引字节        2 索引 70MB         vs  5 索引 238MB(>堆的 231MB)
-- 被砍掉的三个,逐一给出砍的理由(全部经实地核查,不是「看着像没用」):
--   · idx_rounds_room_draw(97MB,最大的一个)—— draw_ms 在全项目的 WHERE /
--     ORDER BY 里出现 **0 次**,只在 rounds_since 的 SELECT 列表里被读出来。
--     且它是 DESC:draw_ms 随插入单调递增,DESC 序下每条新记录都落在索引最左端,
--     吃不到 btree 右端快速填充(~96% 填充率)→ 恒 50/50 页分裂。实测同数据同列
--     增量插入 DESC 2741 页 vs ASC 1544 页 = **膨胀 1.78 倍**。
--   · idx_rounds_room_start —— 两个写入点(add_round / _build_bulk_rounds_sql)
--     都写死 start_ms = round_id,全表校验 `start_ms IS DISTINCT FROM round_id`
--     = **0 行**。它就是主键的复制品。配套把 db.sequence 的谓词从 start_ms
--     改到 round_id(结果逐行比对差异 0 行,且省掉一次 116kB quicksort)。
--   · idx_rounds_room_date —— 唯一消费者 day_rows() 是死代码,全项目零调用点,
--     已随本次一并删除。date_local 是 TEXT,索引项比 bigint 更宽。
-- 砍完对项目里打在本表上的 9 条查询逐条对拍执行计划:全部不变或略快,零退化。
-- 保留清理专用:round_id 即开局毫秒时间戳,滚动裁剪按 round_id < cutoff 跨房删除,
-- 需要单列索引支撑(复合主键 (room_id, round_id) 对该谓词无能为力)。
CREATE INDEX IF NOT EXISTS idx_rounds_round ON rounds(round_id);

CREATE TABLE IF NOT EXISTS predictions (
    room_id          TEXT        NOT NULL,
    round_id         BIGINT      NOT NULL,   -- 被预测的目标局
    main_ids         JSONB,
    guard_ids        JSONB,
    detail           JSONB,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    actual_custom_id SMALLINT,
    hit              TEXT,                   -- main / guard / miss / NULL=未开
    PRIMARY KEY (room_id, round_id)
);
-- ── 4.9.5 前端热路径的**主要**修复:pending_prediction 的支撑索引 ─────────────
-- db.pending_prediction(`actual_custom_id IS NULL ORDER BY round_id DESC LIMIT 1`)
-- 是 /api/rooms/{room}/prediction 每次必打的第一条 SQL。此前**没有任何索引**能
-- 支撑 `actual_custom_id IS NULL` 这个谓词,规划器只能把该房**整段** predictions
-- 历史捞进来再筛掉 99.98%。真机实测(PG16.14):
--     Bitmap Heap Scan · Rows Removed by Filter: 5999 · Buffers 1029 · 3.04ms
-- 而 predictions 单行含 detail JSONB(pg_stats 实测 avg_width 1156B),于是每次
-- /prediction 要读掉 ~8MB 缓冲区。**代价随 retention.days 线性增长** —— 当初把
-- retention 从 1 天调到 7 天时,这条查询的成本同步涨了 7 倍,没人算过这笔账。
-- 加上本偏索引后:Index Scan · Buffers 2 · **0.040ms**(快 76 倍,缓冲区少 514 倍)。
-- 三个刻意的取舍:
--   · **偏索引**(WHERE actual_custom_id IS NULL):稳态每房只有 1 行未结算,
--     实测整库索引体积 **16 kB** —— 近乎零的写入与 VACUUM 成本。
--   · **ASC 而非 DESC**:btree 可反向扫,ASC 一样服务 `ORDER BY round_id DESC`
--     且不排序(实测 Index Scan Backward,无 Sort 节点);而 DESC 会因单调递增
--     插入恒页分裂、膨胀 1.78 倍(见 rounds 处的实测)。
--   · **不损写入**:结算 UPDATE(actual_custom_id NULL→有值)本就无法 HOT ——
--     行宽 1.2KB,页内放不下新版本。实测四组配置(含「只有主键」对照组)
--     n_tup_hot_upd 恒为 0,加本索引前后结算耗时 0.043s vs 0.047s(噪声内)。
--   · **建法**:本索引**不在 SCHEMA 里建** —— 存量库的 predictions 可达千万行,
--     普通 CREATE INDEX 会持 SHARE 锁把写入堵到建完(数十秒起)。改由
--     DB.migrate_indexes() 以 CONCURRENTLY 建(见该方法),全程不阻塞读写;
--     migrate() 末尾自动调用,所有既有调用方零改动。
-- 4.9.5:原 idx_pred_room_hit(room_id, round_id DESC) WHERE hit IS NOT NULL 已删。
--   稳态下几乎每行 hit 都非空 ⇒ 它是主键的近似复制品,却因 DESC 而实测占 827 页
--   (主键仅 465 页,同表同行 —— 1.78 倍膨胀)。砍掉后 accuracy 与 prediction_records
--   双双改走 `Index Scan Backward using predictions_pkey`,实测 0.146→0.132ms /
--   0.086→0.088ms,零退化。
CREATE INDEX IF NOT EXISTS idx_pred_round ON predictions(round_id);  -- 保留清理用
-- 4.6.0(命中率溯源):NULL = 实盘(出怪前生成、出怪后结算),'replay' = 事后补算
-- (房间转正时按生产同一条代码路径、严格因果地把历史窗补齐,见 pred_replay.py)。
-- 刻意用「NULL 即实盘」而非默认值:存量千万行零回填、零锁表,升级即生效。
ALTER TABLE predictions ADD COLUMN IF NOT EXISTS source TEXT;
-- 4.9.5:detail 是纯载荷列 —— 全项目从不以它做谓词(只有 replay_gaps 用
--   `detail->'replay'->>'cfg'`,那是取值不是选择性判据)。而它 avg_width 实测
--   1156B 且被 TOAST,ANALYZE 要把采样到的 30000 行逐行解压再算 MCV/直方图。
--   purge_before 每轮清理完必跑 ANALYZE,实测该列独占 **~47% 的 ANALYZE 耗时**
--   (全列 0.260s vs 排除 detail 0.139s),算出来的统计量一次也用不上。
--   SET STATISTICS 0 = 不为该列收集统计(列照常读写,只是规划器不再为它建直方图)。
ALTER TABLE predictions ALTER COLUMN detail SET STATISTICS 0;

CREATE TABLE IF NOT EXISTS predictor_state (
    room_id TEXT NOT NULL,
    k       TEXT NOT NULL,
    v       TEXT,
    PRIMARY KEY (room_id, k)
);

CREATE TABLE IF NOT EXISTS rooms (
    room_id  TEXT PRIMARY KEY,
    alias    TEXT,
    active   BOOLEAN     NOT NULL DEFAULT TRUE,
    pending  BOOLEAN     NOT NULL DEFAULT FALSE,  -- 待归一挂起(重启回灌用)
    added_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- 旧库升级路径:pending 列不存在则补(幂等)
ALTER TABLE rooms ADD COLUMN IF NOT EXISTS pending BOOLEAN NOT NULL DEFAULT FALSE;

-- 自动发现房的 last_seen 持久层(仅此一表;发现房**不进 rooms 表**,以维持
-- 「rooms.active = 用户策展列表 = 前端可见」的不变式)。回收 grace 默认 7 天,
-- 远超部署重启周期,且 compose 里 Redis 关持久化 —— last_seen 时钟必须落 PG,
-- 否则一次 Redis 重启会把全部离线发现房"提前清零"。worker 启动时由此回灌。
CREATE TABLE IF NOT EXISTS discovered_rooms (
    room_id      TEXT   PRIMARY KEY,
    last_seen_ms BIGINT NOT NULL           -- 最近一次出现在在播列表的毫秒时间戳
);

-- 核验台账:经 roomStatus 核验准入的房(自动发现看不见的房 —— 频道房从不上榜、
-- 低流量房常年不上榜)。它们的「在播记录」由 roomStatus 供货而非在播列表:
--   last_live_ms  最近一次确认在播(准入核验 / 直播状态观测 / 发现 last_seen / 复核)
--   next_probe_ms worker 下次复核时刻(每房独立随机相位;0 = 尚未排期)
-- 有效期与发现房同一把尺(discovery.prune_grace_s):超期即清出台账。
CREATE TABLE IF NOT EXISTS verified_rooms (
    room_id       TEXT   PRIMARY KEY,
    first_live_ms BIGINT NOT NULL,
    last_live_ms  BIGINT NOT NULL,
    next_probe_ms BIGINT NOT NULL DEFAULT 0
);

-- ── 登录系统(3.8.0):按登录账号隔离的「主播名录」绑定 ───────────────────────────
--    user_rooms:一行 = 某登录账号(MySQL tb_user.id)名录里的一个房。
--      · 前端 /api/live-rooms 只回该账号绑定的房;监控本体(worker 抓取)仍是全局的,
--        多账号绑同一房共享同一份数据(零重复抓取)。
--      · 存 alias(用户输入号,可能是靓号短号)以逐字节复刻旧前端展示口径。
--    user_added_rooms:记录「由登录用户把发现房转正」的房 —— 当该房的绑定数归零时,
--      全局监控随之退场(回到自动发现的生命周期);config 注入 / 运维批量 / 登录系统
--      启用前就存在的策展房**不在此列**,任何用户的删除都动不了它们的全局监控。
CREATE TABLE IF NOT EXISTS user_rooms (
    user_id  BIGINT NOT NULL,               -- MySQL tb_user.id(跨库外键,应用层保证)
    room_id  TEXT   NOT NULL,               -- 归一后的真实房号(与 rooms.room_id 同口径)
    alias    TEXT   NOT NULL DEFAULT '',    -- 用户输入号(展示/搜索口径)
    added_ms BIGINT NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, room_id)
);
CREATE INDEX IF NOT EXISTS idx_user_rooms_room ON user_rooms(room_id);

CREATE TABLE IF NOT EXISTS user_added_rooms (
    room_id    TEXT   PRIMARY KEY,
    first_user BIGINT NOT NULL DEFAULT 0,
    added_ms   BIGINT NOT NULL DEFAULT 0
);

--    user_first_login:账号首次登录的一次性标记(首登预置房)。标记与预置房绑定
--      在**同一事务**里落下:此后用户手动删除预置房,下次登录不会被再次塞回
--      (「首登」只发生一次)。刻意不用 MySQL 侧 guantai_login_log 判首登 ——
--      那张审计表有保留期修剪(默认 184 天),老账号会被误判回「首登」。
CREATE TABLE IF NOT EXISTS user_first_login (
    user_id  BIGINT NOT NULL PRIMARY KEY,     -- MySQL tb_user.id(跨库外键,应用层保证)
    first_ms BIGINT NOT NULL DEFAULT 0
);

-- ── 配置中枢(后台管理台):运行时覆盖的不可变版本链 + 审计 ─────────────────────
--    每次「应用」都追加一行完整快照(只增不改);回滚 = 以历史快照落新 rev。
--    敏感值(auth.ticket)在 snapshot/diff 中只存占位/指纹,真值经 Redis 内存分发。
CREATE TABLE IF NOT EXISTS config_revisions (
    rev      BIGSERIAL PRIMARY KEY,
    ts_ms    BIGINT NOT NULL,               -- 北京时间口径与全库一致(毫秒)
    author   TEXT   NOT NULL,
    note     TEXT   NOT NULL DEFAULT '',
    snapshot JSONB  NOT NULL,               -- 应用后的完整覆盖集
    diff     JSONB  NOT NULL                -- {key:{old,new,op}}
);
CREATE TABLE IF NOT EXISTS admin_audit (
    id     BIGSERIAL PRIMARY KEY,
    ts_ms  BIGINT NOT NULL,
    actor  TEXT   NOT NULL,
    action TEXT   NOT NULL,                 -- login/apply/rollback/room_alias/…
    detail JSONB  NOT NULL,
    rev    BIGINT                           -- 关联配置版本(可空)
);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON admin_audit(ts_ms DESC);

-- ── 高 churn 表的 per-table autovacuum 调优(3.4.0;真机实测驱动) ──────────────
-- rounds / predictions 是**纯滚动流水**:retention 每小时删掉一批过期行。
-- 1 万房规模实测口径:每房每天 86400/50 ≈ 1728 局 → 全库
--     写入 ≈ 1728 × 10000 × 2(rounds + predictions)= **3460 万行/天**
--     删除 ≈ 同量(retention.days=1 的稳态,进多少删多少)
-- PG 默认 autovacuum_vacuum_scale_factor = 0.2:表要**先膨胀 20%** 才触发回收。
-- rounds 稳态约 1728 万行 → 要攒够 ~350 万死元组才动手,期间磁盘与索引持续膨胀,
-- 且一次要清理的量极大(长时间占 I/O)。predictions 更糟:单行 ~1.8KB(detail JSONB),
-- 350 万死元组 ≈ **6GB** 的浪费空间。
--
-- 改为 scale_factor=0.02 + 较大 threshold:表长到 2% 死元组(rounds ≈35 万行)就回收,
-- 每次少量多次、I/O 平滑,稳态磁盘占用与索引膨胀显著收敛。
-- cost_limit 调高 = 让 autovacuum 别被默认的 I/O 限速卡住(这两张表值得优先回收)。
-- 幂等:ALTER ... SET 可重复执行;不影响既有数据。
ALTER TABLE rounds SET (
    autovacuum_vacuum_scale_factor = 0.02,
    autovacuum_vacuum_threshold    = 50000,
    autovacuum_analyze_scale_factor = 0.02,
    autovacuum_vacuum_cost_limit   = __AV_COST_LIMIT__,
    autovacuum_vacuum_cost_delay   = 2
);
ALTER TABLE predictions SET (
    autovacuum_vacuum_scale_factor = 0.02,
    autovacuum_vacuum_threshold    = 50000,
    autovacuum_analyze_scale_factor = 0.02,
    autovacuum_vacuum_cost_limit   = __AV_COST_LIMIT__,
    autovacuum_vacuum_cost_delay   = 2
);
"""

# ── 4.9.6:autovacuum 强度可配(修一个真实的运维陷阱)────────────────────────
# 上面这两条 ALTER TABLE **每次进程启动都会执行**。也就是说,运维手动跑一句
#     ALTER TABLE rounds SET (autovacuum_vacuum_cost_limit = 800);
# 调低强度,下一次 worker/web 重启就会被这里原样盖回 2000 —— 调了等于没调,
# 而且现象很隐蔽(重启前有效、重启后失效)。故改为从环境变量取值。
#
# 这个数值是什么意思:cost_limit / cost_delay 决定 autovacuum 的**瞬时强度**。
# PG 默认 200;本项目取 2000 = **10 倍**,当初是为「retention=1 天、追赶 churn」调的。
# 真机诊断显示 churn 早已不是瓶颈(rounds 死元组占比仅 0.2%,余量百倍),
# 而 10 倍强度的代价是:autovacuum 一旦启动就敞开吃满一个核 —— 正是「间歇性
# CPU 100%、持续几分钟、又自己恢复」的形态。
#
# 怎么调(改完重启 worker 即生效,也可先用 ALTER TABLE 热试再落到 env):
#   · 想要「尖峰更矮、时间更长」(前端不卡):设 600~1000
#   · 想要「尽快清完、允许尖峰」(离线时段):保持 2000
#   · 一切照 PG 默认:设 200
# 注意:降强度只是**摊平**同样的工作量,不减少总量。真正减少工作量的是
#      ①索引瘦身(已做,见上)②重建膨胀索引(scripts/pg_maintenance.sh)。
_AV_COST_LIMIT_DEFAULT = 2000       # 保持既有默认,不改变任何存量部署的行为
try:
    _av_cl = int(os.environ.get("STA_PG_AUTOVACUUM_COST_LIMIT", "")
                 or _AV_COST_LIMIT_DEFAULT)
except (TypeError, ValueError):
    _av_cl = _AV_COST_LIMIT_DEFAULT
# 钳位:PG 合法区间 1..10000;越界值会让整段 SCHEMA 报错、建表失败
_av_cl = max(1, min(10000, _av_cl))
SCHEMA = SCHEMA.replace("__AV_COST_LIMIT__", str(_av_cl))

# TimescaleDB(可选):安装扩展后可把 rounds 变超表以获得更佳的高频写入/保留策略。
#   CREATE EXTENSION IF NOT EXISTS timescaledb;
#   SELECT create_hypertable('rounds', 'created_at', if_not_exists => TRUE,
#                            migrate_data => TRUE, chunk_time_interval => INTERVAL '1 day');


def _iso(ms: int) -> str:
    """毫秒时间戳 → 北京时间 ISO 串(整项目统一北京时间,不随容器/系统时区漂移)。"""
    try:
        return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).astimezone(BEIJING_TZ).isoformat()
    except (ValueError, TypeError, OSError):
        return datetime.now(BEIJING_TZ).isoformat()


# ── 数据保留(滚动窗口)────────────────────────────────────────────────────────
_PURGE_TABLES = ("rounds", "predictions")   # 仅历史流水(按时间窗裁剪)
# predictor_state / rooms 是「当前状态」,不按时间窗裁;它们的回收规则是「房间离场且
# 历史已清空」,见本文件末尾的 gc_predictor_state / gc_room_tombstones(5.4.0)。


def retention_cutoff_ms(now_ms_v: int, days: float) -> int:
    """保留窗口起点:now - days(天)。days<=0 表示不清理(调用方自行短路)。"""
    return int(now_ms_v - float(days) * 86_400_000)


def _build_purge_sql(table: str, batch_rows: int) -> str:
    """构造分批 DELETE(纯函数,便于单测)。

    round_id 即开局毫秒时间戳 → 直接以 `round_id < $1` 裁剪(走 idx_*_round
    单列索引);经 ctid 子查询限批,避免一次删除数百万行造成长事务/锁放大/WAL 突刺。
    """
    if table not in _PURGE_TABLES:
        raise ValueError(f"不允许清理的表: {table!r}")
    limit = max(1, int(batch_rows))   # 钳位:0/负值会导致 LIMIT 0 空转或 SQL 报错
    return (f"DELETE FROM {table} WHERE ctid IN ("
            f"SELECT ctid FROM {table} WHERE round_id < $1 LIMIT {limit})")


def _build_bulk_rounds_sql(room_id: str, chunk: List[dict], draw_offset_ms: int):
    """构造多行 rounds INSERT(纯函数,便于单测)。返回 (sql, args)。
    每行 11 列:room_id, round_id, beast_name, official_id, custom_id, multiplier,
    start_ms, draw_ms, draw_local, date_local, source。ON CONFLICT DO NOTHING
    保证幂等;RETURNING round_id 让调用方得知哪些是新插入(供只结算新局)。"""
    from .predictor_bridge import ms_to_date, ms_to_local  # 复用引擎侧时间格式化
    cols = 11
    values_sql = []
    args: List[Any] = []
    for j, g in enumerate(chunk):
        rid = int(g["round_id"])
        start_ms = rid
        draw_ms = start_ms + draw_offset_ms
        base = j * cols
        values_sql.append(
            "(" + ",".join(f"${base + k + 1}" for k in range(cols)) + ")")
        args.extend([
            str(room_id), rid, g.get("beast_name") or "?", g.get("official_id"),
            g.get("custom_id"), g.get("multiplier"), start_ms, draw_ms,
            ms_to_local(draw_ms, "%Y-%m-%d %H:%M:%S"), ms_to_date(draw_ms),
            g.get("source") or "history",
        ])
    sql = ("INSERT INTO rounds (room_id, round_id, beast_name, official_id,"
           " custom_id, multiplier, start_ms, draw_ms, draw_local, date_local,"
           " source) VALUES " + ",".join(values_sql) +
           " ON CONFLICT (room_id, round_id) DO NOTHING RETURNING round_id")
    return sql, args


SRC_REPLAY = "replay"   # predictions.source 的补算标;NULL/其它 = 实盘


def _build_replay_pred_sql(room_id: str, chunk: List[tuple]):
    """构造多行补算 predictions INSERT(纯函数,便于单测)。返回 (sql, args)。

    chunk 每项 = (round_id, main_ids, guard_ids, detail, actual_cid, hit)。
    source 恒钉 SRC_REPLAY —— 这一列是「这条命中记录是不是实盘挣来的」的唯一
    真相来源,不接受调用方传值。
    """
    cols = 8
    values_sql, args = [], []
    for j, r in enumerate(chunk):
        base = j * cols
        values_sql.append(
            "(" + ",".join(f"${base + k + 1}" for k in range(cols)) + ")")
        args.extend([str(room_id), int(r[0]), list(r[1]), list(r[2]),
                     dict(r[3]), int(r[4]), str(r[5]), SRC_REPLAY])
    sql = ("INSERT INTO predictions (room_id, round_id, main_ids, guard_ids,"
           " detail, actual_custom_id, hit, source) VALUES "
           + ",".join(values_sql)
           + " ON CONFLICT (room_id, round_id) DO NOTHING RETURNING round_id")
    return sql, args


class DB:
    def __init__(self, dsn: str, pool_min: int = 2, pool_max: int = 16):
        self._dsn = dsn
        self._min = pool_min
        self._max = pool_max
        self.pool: Optional[asyncpg.Pool] = None
        # 最近一次在线索引迁移的结果(供运维/日志核对;None = 尚未跑过)
        self.last_index_migration: Optional[Dict[str, Any]] = None

    @staticmethod
    async def _init_conn(con: asyncpg.Connection) -> None:
        """注册 JSONB 编解码器:写入直接传 Python list/dict,读回即为 Python 对象
        (asyncpg 默认把 JSONB 当原始文本,会导致 list('[3, 1]') 被逐字符拆开)。"""
        await con.set_type_codec(
            "jsonb", encoder=json.dumps, decoder=json.loads, schema="pg_catalog")
        await con.set_type_codec(
            "json", encoder=json.dumps, decoder=json.loads, schema="pg_catalog")

    async def connect(self) -> None:
        self.pool = await asyncpg.create_pool(
            self._dsn, min_size=self._min, max_size=self._max, command_timeout=30,
            init=self._init_conn)

    async def close(self) -> None:
        if self.pool:
            await self.pool.close()

    async def migrate(self) -> None:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            # 多进程(uvicorn --workers / 多 worker 容器)并发首启时,
            # CREATE TABLE IF NOT EXISTS 存在已知的 pg_type 竞态;advisory lock
            # 把建表串行化,彻底消除。锁号任取,进程间约定一致即可。
            # 显式长超时:池默认 command_timeout=30s,而存量大表(数千万行)上
            # 首次建 idx_*_round 索引、或等待别的进程建完(advisory 锁排队)都远超
            # 30s —— 不加会 TimeoutError 崩溃循环。asyncpg 的 timeout=None 只是
            # 回退到 command_timeout(见 protocol._get_timeout_impl),须给数值。
            _MIGRATE_TIMEOUT = 3600.0
            await con.execute("SELECT pg_advisory_lock(770099)",
                              timeout=_MIGRATE_TIMEOUT)
            try:
                await con.execute(SCHEMA, timeout=_MIGRATE_TIMEOUT)
            finally:
                await con.execute("SELECT pg_advisory_unlock(770099)")
        # 建表完成后立刻做索引迁移(在事务外,CONCURRENTLY 不可在事务块内跑)。
        # 非致命:任何失败都只记账不抛错 —— 索引是性能问题,不是正确性问题。
        with contextlib.suppress(Exception):
            self.last_index_migration = await self.migrate_indexes()

    # ── 4.9.5 在线索引迁移(存量库瘦身;全程不阻塞读写) ─────────────────────────
    #
    #    为什么单独一个方法、而不是塞进 SCHEMA:
    #      · `DROP INDEX CONCURRENTLY` / `CREATE INDEX CONCURRENTLY` **不能在事务块内
    #        执行**,而 migrate() 的 con.execute(SCHEMA) 是一次多语句提交(隐式事务);
    #      · 存量 predictions 可达千万行,普通 CREATE INDEX 持 SHARE 锁会把写入堵到
    #        建完(数十秒起)—— 部署期的真实停写,不可接受。
    #    asyncpg 细节:execute() **不带参数**时走简单查询协议(自动提交),CONCURRENTLY
    #    才成立;一旦带参数就转扩展协议、落进隐式事务并报错。故本方法内全部 DDL
    #    都是无参字符串,索引名来自下面写死的白名单,不接受任何外部输入。
    _LEGACY_INDEXES = (
        # (索引名, 砍它的理由 —— 详见 SCHEMA 处的实测注释)
        ("idx_rounds_room_draw",  "draw_ms 全项目零谓词,且 DESC 序恒页分裂膨胀 1.78×"),
        ("idx_rounds_room_start", "start_ms 恒等于 round_id,主键的复制品"),
        ("idx_rounds_room_date",  "唯一消费者 day_rows() 已确认为死代码并删除"),
        ("idx_pred_room_hit",     "稳态近似主键副本,DESC 膨胀 1.78×;砍后走主键反向扫零退化"),
    )
    _NEW_INDEXES = (
        ("idx_pred_pending",
         "CREATE INDEX CONCURRENTLY idx_pred_pending ON predictions (room_id, round_id)"
         " WHERE actual_custom_id IS NULL"),
    )

    async def migrate_indexes(self, drop_legacy: bool = True) -> Dict[str, Any]:
        """在线索引迁移:建新的、砍旧的,全程 CONCURRENTLY,不阻塞任何读写。

        幂等:每一步先查 pg_index 再动手;已是目标形态就整段空转(稳态零成本)。
        多副本并发首启由 try-advisory-lock 互斥 —— 抢不到锁就直接返回,让抢到的
        那个副本做完即可(不等待:CONCURRENTLY 本身耗时长,排队没有意义)。

        返回 {"created": [...], "dropped": [...], "skipped": bool}。
        """
        assert self.pool is not None
        out: Dict[str, Any] = {"created": [], "dropped": [], "skipped": False}
        async with self.pool.acquire() as con:
            got = await con.fetchval("SELECT pg_try_advisory_lock(770100)")
            if not got:
                out["skipped"] = True     # 别的副本正在迁移
                return out
            try:
                # ① 先建新索引 —— 顺序要紧:必须在砍掉 idx_pred_room_hit 之前
                #    让新索引就位,否则中间会有一段「两个都没有」的窗口。
                for name, ddl in self._NEW_INDEXES:
                    valid = await con.fetchval(
                        "SELECT i.indisvalid FROM pg_class c"
                        " JOIN pg_index i ON i.indexrelid = c.oid"
                        " WHERE c.relname = $1", name)
                    if valid is True:
                        continue                      # 已存在且可用
                    if valid is False:
                        # 上次 CONCURRENTLY 建到一半失败会留下 INVALID 索引:
                        # 它不被规划器使用、却照常吃写入成本 —— 必须先清掉再重建。
                        await con.execute(
                            f"DROP INDEX CONCURRENTLY IF EXISTS {name}",
                            timeout=self._IDX_TIMEOUT)
                    await con.execute(ddl, timeout=self._IDX_TIMEOUT)
                    out["created"].append(name)
                # ② 再砍旧索引
                if drop_legacy:
                    for name, _why in self._LEGACY_INDEXES:
                        exists = await con.fetchval(
                            "SELECT 1 FROM pg_class c JOIN pg_index i"
                            " ON i.indexrelid = c.oid WHERE c.relname = $1", name)
                        if not exists:
                            continue
                        await con.execute(
                            f"DROP INDEX CONCURRENTLY IF EXISTS {name}",
                            timeout=self._IDX_TIMEOUT)
                        out["dropped"].append(name)
            finally:
                await con.execute("SELECT pg_advisory_unlock(770100)")
        return out

    # CONCURRENTLY 要等所有在飞事务落幕,存量大表上可达数分钟 —— 池默认
    # command_timeout=30s 必然中途砍断并留下 INVALID 索引,须显式给足。
    _IDX_TIMEOUT = 3600.0

    # ── rounds ────────────────────────────────────────────────────────────────
    async def add_round(self, room_id: str, round_id: int, official_id: Optional[int],
                        beast_name: str, custom_id: Optional[int],
                        multiplier: Optional[int], source: str,
                        draw_local: str, date_local: str) -> bool:
        """幂等写入;返回 True 表示这是新记录(rowcount>0)。"""
        assert self.pool is not None
        start_ms = int(round_id)
        from .constants import DRAW_OFFSET_MS
        draw_ms = start_ms + DRAW_OFFSET_MS
        async with self.pool.acquire() as con:
            res = await con.execute(
                """INSERT INTO rounds
                   (room_id, round_id, beast_name, official_id, custom_id, multiplier,
                    start_ms, draw_ms, draw_local, date_local, source)
                   VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
                   ON CONFLICT (room_id, round_id) DO NOTHING""",
                str(room_id), int(round_id), beast_name, official_id, custom_id,
                multiplier, start_ms, draw_ms, draw_local, date_local, source)
        # asyncpg 返回形如 "INSERT 0 1" / "INSERT 0 0"
        return res.endswith(" 1")

    async def add_rounds_bulk(self, room_id: str, rounds: List[dict],
                              batch_size: int = 500) -> List[int]:
        """批量幂等写入一房的多局(冷启动回填核心)。rounds 每项含键:
        round_id, official_id, beast_name, custom_id, multiplier, source。
        返回**真正新插入**的 round_id 列表(供调用方只对新局做结算)。

        旧实现逐局 `add_round`(每局一次借连接 + 一次 INSERT):5000 房 × ~40 局 ≈
        20 万次往返,全挤在 pg_pool_max 个连接上。改多行
        `INSERT ... VALUES (...),(...) ON CONFLICT DO NOTHING RETURNING`,单房回填
        从 ~40 次往返降到 ~1 次,连接争用与写入延迟同步大降。
        """
        assert self.pool is not None
        if not rounds:
            return []
        from .constants import DRAW_OFFSET_MS
        new_ids: List[int] = []
        async with self.pool.acquire() as con:
            for i in range(0, len(rounds), max(1, batch_size)):
                chunk = rounds[i:i + batch_size]
                sql, args = _build_bulk_rounds_sql(str(room_id), chunk, DRAW_OFFSET_MS)
                rows = await con.fetch(sql, *args)
                new_ids.extend(int(r["round_id"]) for r in rows)
        return new_ids

    async def oldest_round(self, room_id: str) -> Optional[int]:
        """房内最老一局的 round_id;库空回 None。哨兵「重生」判据用
        (Redis 全量丢失但 DB 幸存时,重看窗下界=库最老 —— 年轻房间的历史
        可能短于页窗,不能以页窗起点有无数据判重生)。
        (room_id, round_id) 主键前缀正向扫 1 行,O(1),每房一生一次。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            row = await con.fetchrow(
                "SELECT round_id FROM rounds WHERE room_id=$1"
                " ORDER BY round_id ASC LIMIT 1", str(room_id))
        return int(row["round_id"]) if row else None

    async def has_round(self, room_id: str, round_id: int) -> bool:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            row = await con.fetchrow(
                "SELECT 1 FROM rounds WHERE room_id=$1 AND round_id=$2",
                str(room_id), int(round_id))
        return row is not None

    async def sequence(self, room_id: str, limit: Optional[int] = None,
                       since_ms: Optional[int] = None) -> List[int]:
        """时间升序的自定义编号序列(预测训练用)。

        4.9.5:训练窗谓词由 `start_ms >= $2` 改为 `round_id >= $2`。**不是等价重写,
        是同一个值的两个名字** —— rounds 的两个写入点(add_round 与
        _build_bulk_rounds_sql)都写死 `start_ms = round_id`,全表校验
        `start_ms IS DISTINCT FROM round_id` = 0 行。改动带来两件事:

          ① 结果不变。1728 行训练序列逐行比对,差异 **0 行**。
          ② 更快。旧写法谓词打在 start_ms、排序却按 round_id,规划器只能走
             idx_rounds_room_start 再**额外排一次序**(实测 116kB quicksort);
             新写法谓词与排序同列 ⇒ 主键反向扫直接出有序结果,零排序。
             实测 0.929ms → 0.608ms。
          ③ 顺带让 idx_rounds_room_start 失去最后一个使用者,可以砍掉(见 SCHEMA)。

        本方法每局每房都跑一次(worker._settle_and_predict / _ensure_next_prediction),
        是 worker 侧最频繁的 PG 读 —— 省下的排序是**按局数**乘出去的。
        """
        assert self.pool is not None
        sql = "SELECT custom_id FROM rounds WHERE room_id=$1 AND custom_id IS NOT NULL"
        args: List[Any] = [str(room_id)]
        if since_ms:
            sql += " AND round_id >= $2"
            args.append(int(since_ms))
        sql += " ORDER BY round_id DESC"
        if limit:
            sql += f" LIMIT {int(limit)}"
        async with self.pool.acquire() as con:
            rows = await con.fetch(sql, *args)
        return [r["custom_id"] for r in reversed(rows)]

    async def history(self, room_id: str, since: int = 0, limit: int = 80,
                      until: int = 0) -> List[dict]:
        """新→旧的回合行(供 Web /history)。

        3.6.0(按日回看):until>0 时取**半开区间 [since, until)**。round_id 即
        起局毫秒(见建表注),区间查询走复合主键 (room_id, round_id) 范围扫描,
        无需任何新索引;until 缺省 0 时 SQL 与响应同旧版逐字节一致(纯增量)。"""
        assert self.pool is not None
        limit = max(1, min(5000, int(limit)))
        sql = "SELECT * FROM rounds WHERE room_id=$1 AND round_id>=$2"
        args: list = [str(room_id), int(since or 0)]
        if int(until or 0) > 0:
            sql += " AND round_id<$3"
            args.append(int(until))
        sql += f" ORDER BY round_id DESC LIMIT {limit}"
        async with self.pool.acquire() as con:
            rows = await con.fetch(sql, *args)
        return [dict(r) for r in rows]

    async def history_days(self, room_id: str, limit: int = 62) -> List[dict]:
        """按**北京起局日**聚合的日目录(3.6.0 按日回看,新→旧)。

        日桶 = (round_id + 8h) / 86400000 的 BIGINT 整除 —— round_id 即起局毫秒
        (与前端期号 dayNo 的口径逐字一致;刻意**不用** date_local,那是出怪日
        口径,跨午夜局会差一天)。聚合列(count/min/max)全部落在复合主键
        (room_id, round_id) 内 → index-only scan;retention=30 天最坏 ~5.2 万
        索引项/房,毫秒级。28800000 = constants.BEIJING_TZ 的固定 UTC+8 偏移。"""
        assert self.pool is not None
        limit = max(1, min(366, int(limit)))
        async with self.pool.acquire() as con:
            rows = await con.fetch(
                "SELECT (round_id + 28800000) / 86400000 AS day_idx,"
                "       count(*) AS n, min(round_id) AS first_id,"
                "       max(round_id) AS last_id"
                " FROM rounds WHERE room_id=$1"
                " GROUP BY 1 ORDER BY 1 DESC LIMIT $2",
                str(room_id), int(limit))
        return [dict(r) for r in rows]

    async def pg_health_probe(self, timeout_s: float = 1.5) -> dict:
        """PG 侧健康探针:量「从池里取到连接 + 跑一条平凡查询」的**端到端耗时**,
        并带回服务器连接占用。

        ── 为什么必须有它(3.4.4;真机实证的观测盲区)────────────────────────────
        worker 副本被扩到连接账本之外(如 16 副本 × 池 32 + web 32 + 预留 3 = 547 >
        max_connections 400)时,`asyncpg` 的 pool.acquire **无限期排队** —— 每个
        handler 里的每一次 PG 调用都会随机卡 2~30s。表现为:
          · 出怪入库相位散布在局内 41~70s(任务按时被领,却在 add_round 前卡住);
          · 结算 → 下局预测之间再拖 3~40s(settle 链有 4~5 次 PG 往返,逐次排队)
            → /prediction 出现十几秒的 target=null 空窗;
        而 Redis 侧的「到期积压」恒为 0 —— **此前的 health 完全看不见这类饥饿**。

        探针语义:acquire+SELECT 的耗时就是任何业务 PG 调用要先付的"入场费"。
        健康 <50ms;>1s = 池饥饿实锤。timeout 触顶时按 timeout 计(不无限等)。
        返回 {ping_ms, used, max_conn, saturated}。任何异常回 ping_ms=-1(探针
        自身绝不抛错拖垮调用方)。"""
        import time as _t
        t0 = _t.monotonic()
        try:
            async def _probe():
                assert self.pool is not None
                async with self.pool.acquire() as con:
                    return await con.fetchrow(
                        "SELECT (SELECT count(*) FROM pg_stat_activity) AS used,"
                        " current_setting('max_connections')::int AS max_conn")
            row = await asyncio.wait_for(_probe(), timeout=timeout_s)
            ping = int((_t.monotonic() - t0) * 1000)
            used, maxc = int(row["used"]), int(row["max_conn"])
            return {"ping_ms": ping, "used": used, "max_conn": maxc,
                    "saturated": ping > 1000 or used >= int(maxc * 0.92)}
        except asyncio.TimeoutError:
            return {"ping_ms": int(timeout_s * 1000), "used": -1, "max_conn": -1,
                    "saturated": True}   # 探针都排不到队 = 饥饿实锤
        except Exception:
            return {"ping_ms": -1, "used": -1, "max_conn": -1, "saturated": False}

    async def latest_round(self, room_id: str) -> Optional[dict]:
        rows = await self.history(room_id, 0, 1)
        return rows[0] if rows else None

    # ── 数据保留:滚动裁剪 cutoff 之前的历史(rounds + predictions) ───────────
    async def purge_before(self, cutoff_ms: int, batch_rows: int = 50_000,
                           max_batches: int = 400, pause_s: float = 0.05,
                           stop: Optional[Callable[[], bool]] = None
                           ) -> Dict[str, int]:
        """删除 round_id < cutoff_ms 的历史行,分批执行(每批 batch_rows 行,批间
        小憩 pause_s 秒),避免长事务/锁放大。predictor_state(模型权重)与 rooms
        (名录)是"当前状态"而非历史流水,不在清理范围。

        返回 {"rounds": n, "predictions": n, "capped": 0/1};capped=1 表示碰到
        max_batches 护栏或 stop() 信号提前收手(下个巡检周期继续,不会积压)。
        stop:可选回调,返回 True 即在**批间**立刻停手 —— 优雅停机时首轮清理
        海量存量不用跑完全部批次(单批事务本身随进程终止自动回滚,无损)。
        """
        assert self.pool is not None
        batch_rows = max(1, int(batch_rows))     # 与 _build_purge_sql 同步钳位,
        max_batches = max(1, int(max_batches))   # 防误配 0/负值造成空转或报错
        out: Dict[str, int] = {t: 0 for t in _PURGE_TABLES}
        out["capped"] = 0
        for table in _PURGE_TABLES:
            sql = _build_purge_sql(table, batch_rows)
            batches = 0
            while True:
                if stop is not None and stop():
                    out["capped"] = 1
                    return out
                async with self.pool.acquire() as con:
                    # 单批显式长超时:首轮清理存量/统计陈旧走顺扫时,单批可能超过
                    # 池默认 command_timeout=30s;600s 上限只兜极端,不影响常态。
                    tag = await con.execute(sql, int(cutoff_ms),
                                            timeout=600.0)   # 形如 "DELETE 42"
                try:
                    n = int(str(tag).split()[-1])
                except (ValueError, IndexError):
                    n = 0
                out[table] += n
                batches += 1
                if n < int(batch_rows):
                    break
                if batches >= int(max_batches):
                    out["capped"] = 1
                    break
                if pause_s > 0:
                    await asyncio.sleep(pause_s)
            if out[table]:
                # 大批量删除后立刻刷新统计:不等 autoanalyze,保证下一轮巡检的
                # 裁剪子查询稳定走 idx_*_round 索引(ANALYZE 仅采样,不阻塞读写)。
                async with self.pool.acquire() as con:
                    await con.execute(f"ANALYZE {table}", timeout=1800.0)
        return out

    # ── predictions ─────────────────────────────────────────────────────────
    async def peek_prediction(self, room_id: str,
                              round_id: int) -> Optional[Dict[str, Any]]:
        """**只读**窥视某局的预测行(detail / 号码 / 是否尚未结算)。

        用于「原子换手」(见 settle_and_save_prediction):权重更新需要 detail,
        而 detail 必须在结算**之前**读到 —— 但结算这个写动作本身要推迟到最后
        与「写入下一局预测」合成一个事务,否则会露出中间态(见下)。
        """
        assert self.pool is not None
        async with self.pool.acquire() as con:
            row = await con.fetchrow(
                "SELECT main_ids, guard_ids, detail, hit FROM predictions"
                " WHERE room_id=$1 AND round_id=$2", str(room_id), int(round_id))
        if not row:
            return None
        detail = row["detail"]
        if isinstance(detail, str):
            try:
                detail = json.loads(detail)
            except ValueError:
                detail = {}
        return {"first_time": row["hit"] is None, "detail": detail or {},
                "main_ids": list(row["main_ids"] or []),
                "guard_ids": list(row["guard_ids"] or [])}

    async def settle_and_save_prediction(
            self, room_id: str, settled_round: int, actual_cid: int,
            next_round: Optional[int] = None,
            main_ids: Optional[List[int]] = None,
            guard_ids: Optional[List[int]] = None,
            detail: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """【原子换手】同一事务里完成:**结算上一局的预测** + **写入下一局的新预测**。

        ── 为什么必须原子(真机 HAR 实证的「前端四个数字变成 -」)────────────────
        旧实现是分开的三步:
            ① fill_prediction_outcome(N)      → prediction(N) 被结算,不再是 pending
            ②   db.sequence(拉 ~1727 行) + run_prediction(跑引擎)   ← **窗口**
            ③ save_prediction(N+1)            → 新的 pending 才写进去
        ①和③之间,`predictions` 表里**一条「未结算」的行都没有** →
        `pending_prediction()` 返回 None → `/prediction` 返回
        `target_round_id: null` / `main: []` / `guard: []` → **前端四个数字显示为 `-`**。

        窗口有多长?沙箱里 ≈5.5ms;但真实部署上 PG 连接吃紧(实测 329/400)、
        6939 房同时在灌,`db.sequence` + 线程池排队可以拉到**几百毫秒**。
        而前端的 `predChase` **恰恰在出怪到达的那一刻**(局内 ~38s)去拉 /prediction ——
        **精准撞进这个窗口**。真机 HAR 实测:65 次 /prediction 里 **14 次(22%)** 命中,
        全部落在局内 39.2~49.4s(中位 40.4s),且当帧 `record` 显示本局**已结算**、
        `target` 却是 null —— 与本窗口的指纹逐项吻合。

        合成一个事务后,读者只可能看到两种状态:
            · 换手前:{ prediction(N) 未结算 }        → target=N,有号
            · 换手后:{ N 已结算, prediction(N+1) 未结算 } → target=N+1,有号
        **「两个都没有」这个中间态被彻底消除。**

        next_round 为 None 时退化为纯结算(与 fill_prediction_outcome 等价),
        供后台发现房(策展闸关掉预测)与回填路径复用。
        """
        assert self.pool is not None
        row = None
        async with self.pool.acquire() as con:
            async with con.transaction():
                row = await con.fetchrow(
                    "SELECT main_ids, guard_ids, detail, hit FROM predictions"
                    " WHERE room_id=$1 AND round_id=$2 FOR UPDATE",
                    str(room_id), int(settled_round))
                hit = first_time = None
                if row:
                    m = list(row["main_ids"] or [])
                    g = list(row["guard_ids"] or [])
                    hit = ("main" if actual_cid in m
                           else ("guard" if actual_cid in g else "miss"))
                    first_time = row["hit"] is None
                    await con.execute(
                        "UPDATE predictions SET actual_custom_id=$3, hit=$4"
                        " WHERE room_id=$1 AND round_id=$2",
                        str(room_id), int(settled_round), int(actual_cid), hit)
                # 同一事务内写入新 pending —— 换手对读者原子可见
                if next_round is not None:
                    await con.execute(
                        """INSERT INTO predictions
                             (room_id, round_id, main_ids, guard_ids, detail)
                           VALUES ($1,$2,$3,$4,$5)
                           ON CONFLICT (room_id, round_id) DO UPDATE
                             SET main_ids=EXCLUDED.main_ids,
                                 guard_ids=EXCLUDED.guard_ids,
                                 detail=EXCLUDED.detail""",
                        str(room_id), int(next_round),
                        list(main_ids or []), list(guard_ids or []),
                        dict(detail or {}))
        if not row:
            return None
        d = row["detail"]
        if isinstance(d, str):
            try:
                d = json.loads(d)
            except ValueError:
                d = {}
        return {"hit": hit, "first_time": first_time, "detail": d or {},
                "main_ids": list(row["main_ids"] or []),
                "guard_ids": list(row["guard_ids"] or [])}

    async def latest_prediction(self, room_id: str) -> Optional[dict]:
        """round_id 最大的**实盘**预测行(不论是否已结算)。读者侧「换手回退」用,见 web。

        4.6.0 复查修正:必须排掉补算行(source='replay')。本方法唯一的调用者是
        `web._build_prediction` 的换手回退分支 —— 它的语义是「最新一条预测行恰好
        就是刚结算的那一局 ⇒ 正处在原子换手的瞬间,把它当 pending 透出去」。
        而补算行**天然满足** `round_id == latest`(补算就是填到 anchor 为止),于是
        在「补算已落库、实盘链还没写出下一条 pending」的窗口里,回退会把**补算号**
        当成当前预测号发给前端。补算是回测口径,绝不能出现在「下一局主/防」的位置。
        该分支的原注释「绝不回退到更老的预测」正是同一条纪律的另一半。
        """
        assert self.pool is not None
        async with self.pool.acquire() as con:
            row = await con.fetchrow(
                "SELECT round_id, main_ids, guard_ids, detail FROM predictions"
                " WHERE room_id=$1 AND source IS DISTINCT FROM $2"
                " ORDER BY round_id DESC LIMIT 1", str(room_id), SRC_REPLAY)
        return dict(row) if row else None

    async def save_prediction(self, room_id: str, round_id: int, main_ids: List[int],
                              guard_ids: List[int], detail: Dict[str, Any]) -> None:
        """保存/更新目标局预测;保留已回填的 actual/hit(与旧 SQLite 语义一致)。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            await con.execute(
                """INSERT INTO predictions (room_id, round_id, main_ids, guard_ids, detail)
                   VALUES ($1,$2,$3,$4,$5)
                   ON CONFLICT (room_id, round_id) DO UPDATE
                     SET main_ids=EXCLUDED.main_ids,
                         guard_ids=EXCLUDED.guard_ids,
                         detail=EXCLUDED.detail""",
                str(room_id), int(round_id),
                list(main_ids), list(guard_ids), dict(detail))

    async def fill_prediction_outcome(self, room_id: str, round_id: int,
                                      actual_cid: int) -> Optional[Dict[str, Any]]:
        """出怪后回填命中;返回该预测(含 detail)供权重更新。first_time=是否首次结算。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            async with con.transaction():
                row = await con.fetchrow(
                    "SELECT main_ids, guard_ids, detail, hit FROM predictions"
                    " WHERE room_id=$1 AND round_id=$2 FOR UPDATE",
                    str(room_id), int(round_id))
                if not row:
                    return None
                main_ids = list(row["main_ids"] or [])
                guard_ids = list(row["guard_ids"] or [])
                hit = ("main" if actual_cid in main_ids
                       else ("guard" if actual_cid in guard_ids else "miss"))
                first_time = row["hit"] is None
                await con.execute(
                    "UPDATE predictions SET actual_custom_id=$3, hit=$4"
                    " WHERE room_id=$1 AND round_id=$2",
                    str(room_id), int(round_id), int(actual_cid), hit)
        detail = row["detail"]
        if isinstance(detail, str):
            try:
                detail = json.loads(detail)
            except ValueError:
                detail = {}
        return {"hit": hit, "first_time": first_time, "detail": detail or {},
                "main_ids": main_ids, "guard_ids": guard_ids}

    async def has_prediction(self, room_id: str, round_id: int) -> bool:
        """该局是否已有预测行(主键点查;预测链自愈闸的幂等判据)。

        worker._ensure_next_prediction 每次补链前先问这一句 —— 稳态(链完好)下
        它就是全部开销:一次 (room_id, round_id) 主键命中,不跑预测引擎、不读序列。
        """
        assert self.pool is not None
        async with self.pool.acquire() as con:
            row = await con.fetchval(
                "SELECT 1 FROM predictions WHERE room_id=$1 AND round_id=$2",
                str(room_id), int(round_id))
        return bool(row)

    async def pending_prediction(self, room_id: str) -> Optional[dict]:
        """actual 未回填、round_id 最大 = 「下一局」预测。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            row = await con.fetchrow(
                "SELECT round_id, main_ids, guard_ids, detail FROM predictions"
                " WHERE room_id=$1 AND actual_custom_id IS NULL"
                " ORDER BY round_id DESC LIMIT 1", str(room_id))
        return dict(row) if row else None

    async def prediction_records(self, room_id: str, limit: int = 40) -> List[dict]:
        """近 limit **局**的逐局命中记录(新→旧)。

        4.6.0 复查修正(两处,与 accuracy 同源):

        ① **按局锚定**。旧实现同样是 `DESC LIMIT`,与 accuracy 犯的是同一个错。
           而且它不是无害的重复 —— 前端 renderPredict 在 `accuracy.n === 0` 时会
           **回落**到 `p.record.slice(0, PRED_EVAL)` 自行算命中率(app.js)。若只锚定
           accuracy 而放任 record,恰恰在「窗口内无判定」这一唯一需要修的场景里,
           前端会拿几天前的旧记录算出一个「近40局 主中X」—— 修了一半等于没修。
        ② **带回 source**。调用方(web)据此让前端区分:「上局开X·主中」这枚徽标
           只认实盘判定,补算判定一律不显示(与既有「该局没有预测 ⇒ 整枚隐藏」
           同一状态,不新增第三种形态)。

        成本说明(诚实计价):本方法与 accuracy 各自取一次锚(`MAX(round_id)`),
        即每次 /prediction 多两次**主键反向 index-only scan**(亚毫秒)。刻意不
        合并成一次传参 —— 那要改这两个方法的签名,而 tests/test_web_prediction.py
        与 tests/test_jfvip_asgi.py 的 DB 桩按现签名写死;为省两次 O(1) 点查去动
        契约面,不划算。且 3.9.0 起每账号同时只有 1 个活跃房,该端点约每局一次。
        """
        assert self.pool is not None
        limit = max(1, int(limit))
        async with self.pool.acquire() as con:
            anchor = await con.fetchval(
                "SELECT MAX(round_id) FROM rounds WHERE room_id=$1", str(room_id))
            if anchor is None:
                return []
            floor = int(anchor) - (limit - 1) * ROUND_STEP
            rows = await con.fetch(
                "SELECT round_id, actual_custom_id, hit, source FROM predictions"
                " WHERE room_id=$1 AND hit IS NOT NULL AND actual_custom_id IS NOT NULL"
                "   AND round_id >= $2"
                " ORDER BY round_id DESC LIMIT $3",
                str(room_id), int(floor), limit)
        return [dict(r) for r in rows]

    async def accuracy(self, room_id: str, window: int = 100) -> Dict[str, int]:
        """近 window **局**的命中统计(4.6.0 起以最新一局为锚做区间约束)。

        ── 为什么必须锚定(修复真机可复现的口径谎报)────────────────────────────
        旧实现是 `ORDER BY round_id DESC LIMIT window`,取的是「最近 window **条**
        有判定的预测行」——**不是**「最近 window 局」。二者在预测链连续时恰好
        重合,一旦链中断过就分道扬镳:

          房间当过策展房 → 被移出名录(或降级为发现房/冷房)→ 预测停摆数日 →
          重新加入。retention 默认 7 天,`predictions` 旧行还在,于是 LIMIT 100
          原样取回**几天前**那 100 条,前端照着渲染成「近100局 主命中 25%」。
          实测:100 条只跨 1.4h,而最新一条距今 142.6h。

        现在先取该房 `MAX(round_id)`(走主键 (room_id, round_id) 反向 index-only
        scan,O(1))作锚,再以 `round_id >= anchor-(window-1)*ROUND_STEP` 约束 ——
        窗口外的陈年判定一律不计。链连续的健康房 n 恒等于 window,**逐字节无变化**;
        只有原本就在说谎的场景才会变(n 掉到真实值)。

        返回值在旧三键(n/main/cover)之外新增:
          · replay   —— 其中由「事后补算」得来的条数(source='replay';见 pred_replay.py)
          · live_main / live_cover —— **仅实盘行**(source ≠ 'replay')的命中分列。
            README §10.1 早已写明这是展示层若要重新自洽的正解字段(「让 accuracy
            增回 live_main/live_cover」);本轮兑现为后端契约:前端当前不消费
            (产品裁定命中率行合并展示、不标注),但运维/管理台/单测由此能一眼
            核对「合并数」与「实盘数」的差值是否等于 replay —— 口径自证。
          · anchor / first_id / last_id —— 锚点与实际计入区间,供前端与运维核对跨度
        锚不存在(该房一局都没有)时恒回零 —— 没有出怪就没有「近N局」可言,
        此时若还拿孤儿预测行凑一个命中率出来,正是本次要修的那种谎报。
        """
        assert self.pool is not None
        window = max(1, int(window))
        async with self.pool.acquire() as con:
            anchor = await con.fetchval(
                "SELECT MAX(round_id) FROM rounds WHERE room_id=$1", str(room_id))
            if anchor is None:
                return {"window": window, "n": 0, "main": 0, "cover": 0,
                        "replay": 0, "live_main": 0, "live_cover": 0,
                        "anchor": 0, "first_id": 0, "last_id": 0}
            floor = int(anchor) - (window - 1) * ROUND_STEP
            rows = await con.fetch(
                "SELECT hit, round_id, source FROM predictions"
                " WHERE room_id=$1 AND hit IS NOT NULL AND round_id >= $2"
                " ORDER BY round_id DESC LIMIT $3",
                str(room_id), int(floor), window)
        n = len(rows)
        main = sum(1 for r in rows if r["hit"] == "main")
        cover = sum(1 for r in rows if r["hit"] in ("main", "guard"))
        replay = sum(1 for r in rows if r["source"] == SRC_REPLAY)
        live_main = sum(1 for r in rows
                        if r["hit"] == "main" and r["source"] != SRC_REPLAY)
        live_cover = sum(1 for r in rows
                         if r["hit"] in ("main", "guard") and r["source"] != SRC_REPLAY)
        return {"window": window, "n": n, "main": main, "cover": cover,
                "replay": replay, "live_main": live_main, "live_cover": live_cover,
                "anchor": int(anchor),
                "first_id": int(rows[-1]["round_id"]) if n else 0,
                "last_id": int(rows[0]["round_id"]) if n else 0}

    # ── 命中率补算(4.6.0;计算本体在 pred_replay.py,这里只管取数与落库) ────────
    async def heal_orphan_settlements(self, room_id: str, window: int) -> int:
        """把窗口内的**铁孤儿预测行**(hit IS NULL 且其目标局早已落地、妖兽已知)
        按「主优先」规则补上判定。返回补上的行数。

        ── 为什么必须有它(4.9.3 第七轮复查) ────────────────────────────────
        孤儿行 = 实盘预测写下了、目标局也开出了,结算却被漏掉的行(成因:结算
        路径偶发异常后任务已 ack 不重入、多副本竞态窗口等)。它对命中率是**双重
        毒害**:accuracy 数不到它(hit IS NULL),而 replay_gaps 的缺口判据是
        `p.round_id IS NULL`(README §10.1 四道闸之一,刻意如此)—— 有行就不算
        缺口,补算也救不了。于是每个孤儿 = 窗口里一个**任何机制都填不上**的
        永久黑洞,「近N局」就此被静默扣减。

        ── 为什么只补账、绝不推权重 ────────────────────────────────────────
        README §10.1 写明孤儿行的正解是「补结算」而非补算硬闯,且点名硬闯的害处:
        「以过期 detail 触发 update_after_settle,把 Hedge 权重推乱」。生产的权重
        更新只在结算发生的**当下**有意义;错过那一拍,拿几小时前的 detail 现在去推
        权重,比不推更糟。故本方法是**纯账本修复**:回填 actual/hit,一个字节都
        不碰 predictor_state。判定规则(主优先三元)与 fill_prediction_outcome /
        pred_replay._hit_of 逐字同源 —— CASE 表达式即那两处的 SQL 化。

        ── 判据与竞态 ──────────────────────────────────────────────────────
        「铁孤儿」判据 = `p.round_id + ROUND_STEP <= anchor`(落后最新局一整局
        以上),与 web._build_prediction 的铁孤儿过滤、worker 的 pend 判据同一
        条纪律 —— 最新一局的行正处在原子换手/结算窗内,绝不误碰。区间钳在
        accuracy 同款窗口(anchor 往回 window 格点):更老的孤儿对「近N局」无
        影响,留给 retention 自然清理。与迟到结算(哨兵回填旧局)撞车时,双方
        按同一规则算出**同一个** hit,谁先提交都是同值覆盖;我方先提交会让
        fill_prediction_outcome 的 first_time 判否、跳过那次「过期 detail 推权重」
        —— 恰是上面文档裁定的更安全语义,不是回归。
        """
        assert self.pool is not None
        window = max(1, int(window))
        async with self.pool.acquire() as con:
            rows = await con.fetch(
                """WITH a AS (SELECT MAX(round_id) AS m FROM rounds WHERE room_id=$1),
                   tgt AS (
                     SELECT p.round_id AS rid, r.custom_id AS cid
                       FROM predictions p
                       JOIN rounds r ON r.room_id = p.room_id
                                    AND r.round_id = p.round_id
                       JOIN a ON TRUE
                      WHERE p.room_id = $1
                        AND p.hit IS NULL AND p.actual_custom_id IS NULL
                        AND r.custom_id IS NOT NULL
                        AND p.round_id >= a.m - $2::bigint
                        AND p.round_id + $3::bigint <= a.m)
                   UPDATE predictions p
                      SET actual_custom_id = t.cid,
                          hit = CASE
                                  WHEN COALESCE(p.main_ids,  '[]'::jsonb)
                                       @> to_jsonb(t.cid::int) THEN 'main'
                                  WHEN COALESCE(p.guard_ids, '[]'::jsonb)
                                       @> to_jsonb(t.cid::int) THEN 'guard'
                                  ELSE 'miss'
                                END
                     FROM tgt t
                    WHERE p.room_id = $1 AND p.round_id = t.rid
                   RETURNING p.round_id""",
                str(room_id), (window - 1) * ROUND_STEP, ROUND_STEP)
        return len(rows)

    async def drop_replay_rows(self, room_id: str, round_ids: List[int]) -> int:
        """删掉指定局的**补算行**。`source = SRC_REPLAY` 是硬闸 —— 实盘行永不可删。

        用途只有一个:预测超参热更后,旧配置算出的补算行已与当前口径不可比
        (真机实测错配可致 11pp 偏差),先删再由同一轮 sweep 用新配置重算。
        刻意用「先 DELETE 再 INSERT ... DO NOTHING」而不是把插入改成
        DO UPDATE —— 后者会削弱「补算绝不覆盖实盘行」这条最硬的保证,
        而 DELETE 带 source 谓词,其安全性是可以一眼看穿、也可以单测的。
        """
        assert self.pool is not None
        if not round_ids:
            return 0
        async with self.pool.acquire() as con:
            tag = await con.execute(
                "DELETE FROM predictions WHERE room_id=$1 AND source=$2"
                "   AND round_id = ANY($3::bigint[])",
                str(room_id), SRC_REPLAY, [int(x) for x in round_ids])
        try:
            return int(str(tag).rsplit(" ", 1)[-1])
        except ValueError:
            return 0

    async def replay_gaps(self, room_id: str, window: int,
                          cfg_fp: str = "") -> Dict[str, Any]:
        """窗口内「有出怪但没有判定」的目标局(= 补算要填的洞)。

        口径与 accuracy 严格同源:同一个 anchor、同一个区间。只把**真实存在且
        妖兽已知**的局算作应有判定 —— 官方本身缺失的局补算不出来也不该算进分母。

        4.6.0 复查修正:判据是 `p.round_id IS NULL`(压根没有预测行)而**不是**
        `p.hit IS NULL`。后者会把「已有实盘预测行、只是还没结算」的局也算成缺口:
        ① 刚落地那一局恒处于此态(结算与写下一条在同一事务里,但轮询可能撞上),
           补算算完撞 ON CONFLICT DO NOTHING,白烧一次 CPU;
        ② 更糟的是**永不结算的孤儿行**(该局结算路径漏过) —— 它会让本房每个冷却
           周期都重跑一次补算、永远失败。用 round_id IS NULL 就诚实地承认「这个洞
           补不了」,窗口短一点,但不烧 CPU。孤儿行的正解是补结算,那是
           _settle_only / 覆盖哨兵的职责,不在补算的射程内(硬闯会以过期 detail
           触发 update_after_settle,把 Hedge 权重推乱)。
        返回 {"anchor":…, "missing":[round_id…], "stale":[round_id…]}。
        missing = 压根没有预测行的局;stale = **已有补算行但配置指纹已过期**的局
        (预测超参热更后,旧配置算出的行与当前口径不可比,须删掉重算;
        cfg_fp 传空串表示不做该检查)。窗口已满且无过期行时两者皆空,
        调用方据此零成本短路(补算协程稳态下就停在这一句)。

        ── 为什么不必额外提防「补算行被当成实盘判定推给前端」──────────────────
        worker._settle_and_predict 会 peek_prediction(该局) 并把判定塞进出怪 SSE
        的 push["settled"]。若那一行是补算行,前端徽标就会把回测判定当战绩显示。
        该路径**结构上不可达**,不需要额外守卫:
          · 补算只写 `rounds` 里**已存在**的局 —— missing 取自本方法的 SELECT;
          · 而 _settle_and_predict 只在 `is_new`(该局本次才插入 rounds)时被调,
            此时它压根不在任何一次 missing 快照里。
        二者的前置条件互斥。save_replay_predictions 的 ON CONFLICT DO NOTHING
        仍作为兜底保留(代价为零),但不是靠它来堵这条路。
        """
        assert self.pool is not None
        window = max(1, int(window))
        async with self.pool.acquire() as con:
            anchor = await con.fetchval(
                "SELECT MAX(round_id) FROM rounds WHERE room_id=$1", str(room_id))
            if anchor is None:
                return {"anchor": 0, "missing": [], "stale": []}
            floor = int(anchor) - (window - 1) * ROUND_STEP
            rows = await con.fetch(
                "SELECT r.round_id FROM rounds r"
                " LEFT JOIN predictions p"
                "        ON p.room_id = r.room_id AND p.round_id = r.round_id"
                " WHERE r.room_id=$1 AND r.round_id >= $2"
                "   AND r.custom_id IS NOT NULL AND p.round_id IS NULL"
                " ORDER BY r.round_id ASC", str(room_id), int(floor))
            stale: List[int] = []
            if cfg_fp:
                srows = await con.fetch(
                    "SELECT round_id FROM predictions"
                    " WHERE room_id=$1 AND round_id >= $2 AND source=$3"
                    "   AND COALESCE(detail->'replay'->>'cfg','') <> $4"
                    " ORDER BY round_id ASC",
                    str(room_id), int(floor), SRC_REPLAY, str(cfg_fp))
                stale = [int(r["round_id"]) for r in srows]
        return {"anchor": int(anchor),
                "missing": [int(r["round_id"]) for r in rows],
                "stale": stale}

    async def rounds_since(self, room_id: str, since_round_id: int) -> List[dict]:
        """升序取 round_id ≥ 给定值、妖兽已知的局(补算的输入序列)。

        字段刻意只取补算需要的四个:round_id / custom_id / start_ms / draw_ms ——
        训练窗按起局毫秒切(与 db.sequence 的 `round_id >= since` 逐字同源;
        4.9.5 起两处统一用 round_id —— start_ms 恒等于 round_id,见 sequence 注),
        draw_ms 用来复刻生产「出怪后才跑预测」的时间锚。
        """
        assert self.pool is not None
        async with self.pool.acquire() as con:
            rows = await con.fetch(
                "SELECT round_id, custom_id, start_ms, draw_ms FROM rounds"
                " WHERE room_id=$1 AND round_id >= $2 AND custom_id IS NOT NULL"
                " ORDER BY round_id ASC", str(room_id), int(since_round_id))
        return [dict(r) for r in rows]

    async def save_replay_predictions(self, room_id: str,
                                      rows: List[tuple]) -> int:
        """落补算行。rows 每项 = (round_id, main_ids, guard_ids, detail, actual_cid, hit)。

        **ON CONFLICT DO NOTHING**(而非 save_prediction 的 DO UPDATE):补算永远
        不许覆盖实盘行。结构上二者本就不重叠(补算只写 ≤anchor 的历史局,实盘只
        写 latest+ROUND_STEP),这一句是兜住「补算跑到一半新局落地」的竞态。
        返回实际插入行数。
        """
        assert self.pool is not None
        if not rows:
            return 0
        n = 0
        async with self.pool.acquire() as con:
            for i in range(0, len(rows), 200):
                sql, args = _build_replay_pred_sql(room_id, rows[i:i + 200])
                # 与 add_rounds_bulk 同款:executemany 不回行数,而 DO NOTHING 下
                # 「发了几行」≠「插了几行」;用 RETURNING 数真实插入,不猜。
                got = await con.fetch(sql, *args)
                n += len(got)
        return n

    # ── predictor_state(= 旧 kv 表;预测器权重/探索态) ────────────────────────
    async def kv_get(self, room_id: str, k: str) -> Optional[str]:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            row = await con.fetchrow(
                "SELECT v FROM predictor_state WHERE room_id=$1 AND k=$2",
                str(room_id), k)
        return row["v"] if row else None

    async def kv_set(self, room_id: str, k: str, v: str) -> None:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            await con.execute(
                "INSERT INTO predictor_state (room_id, k, v) VALUES ($1,$2,$3)"
                " ON CONFLICT (room_id, k) DO UPDATE SET v=EXCLUDED.v",
                str(room_id), k, v)

    async def load_predictor_kv(self, room_id: str) -> Dict[str, str]:
        """一次取回该房全部预测器状态(model_weights / explore_state)。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            rows = await con.fetch(
                "SELECT k, v FROM predictor_state WHERE room_id=$1", str(room_id))
        return {r["k"]: r["v"] for r in rows}

    async def save_predictor_kv(self, room_id: str, kv: Dict[str, str]) -> None:
        if not kv:
            return
        assert self.pool is not None
        async with self.pool.acquire() as con:
            await con.executemany(
                "INSERT INTO predictor_state (room_id, k, v) VALUES ($1,$2,$3)"
                " ON CONFLICT (room_id, k) DO UPDATE SET v=EXCLUDED.v",
                [(str(room_id), k, v) for k, v in kv.items()])

    # ── rooms(持久化镜像) ────────────────────────────────────────────────────
    async def upsert_room(self, room_id: str, alias: str, active: bool = True,
                          pending: bool = False) -> None:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            await con.execute(
                "INSERT INTO rooms (room_id, alias, active, pending)"
                " VALUES ($1,$2,$3,$4)"
                " ON CONFLICT (room_id) DO UPDATE SET alias=EXCLUDED.alias,"
                " active=EXCLUDED.active, pending=EXCLUDED.pending",
                str(room_id), alias, bool(active), bool(pending))

    async def upsert_rooms_bulk(self, rows: List[tuple], batch_size: int = 500) -> None:
        """批量登记房间。rows 每项为 (room_id, alias, active, pending)。
        批量准入用:数千房一次性写库,替代逐房 upsert_room 的 N 次往返。"""
        assert self.pool is not None
        if not rows:
            return
        payload = [(str(r[0]), str(r[1]), bool(r[2]), bool(r[3])) for r in rows]
        async with self.pool.acquire() as con:
            for i in range(0, len(payload), max(1, batch_size)):
                await con.executemany(
                    "INSERT INTO rooms (room_id, alias, active, pending)"
                    " VALUES ($1,$2,$3,$4)"
                    " ON CONFLICT (room_id) DO UPDATE SET alias=EXCLUDED.alias,"
                    " active=EXCLUDED.active, pending=EXCLUDED.pending",
                    payload[i:i + batch_size])

    async def restore_rooms(self) -> Dict[str, List[dict]]:
        """PG → Redis 名录回灌(Redis 作纯运行态,重启后由此恢复;
        对齐旧版「配置持久化,重启不丢」——挂起项亦回灌)。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            act = await con.fetch(
                "SELECT room_id, alias FROM rooms WHERE active ORDER BY room_id")
            pend = await con.fetch(
                "SELECT room_id FROM rooms WHERE pending AND NOT active"
                " ORDER BY room_id")
        return {"active": [dict(r) for r in act],
                "pending": [dict(r) for r in pend]}

    async def active_rooms(self) -> List[dict]:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            rows = await con.fetch(
                "SELECT room_id, alias FROM rooms WHERE active ORDER BY room_id")
        return [dict(r) for r in rows]

    # ── 登录系统(3.8.0):按登录账号隔离的名录绑定 ─────────────────────────────
    async def user_rooms_list(self, user_id: int) -> List[dict]:
        """某登录账号名录(添加序;alias 为用户输入号,展示口径)。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            rows = await con.fetch(
                "SELECT room_id, alias, added_ms FROM user_rooms"
                " WHERE user_id=$1 ORDER BY added_ms, room_id", int(user_id))
        return [dict(r) for r in rows]

    async def user_rooms_count(self, user_id: int) -> int:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            n = await con.fetchval(
                "SELECT COUNT(*) FROM user_rooms WHERE user_id=$1", int(user_id))
        return int(n or 0)

    async def user_room_bind(self, user_id: int, room_id: str, alias: str) -> None:
        """幂等绑定;重复添加同房仅刷新 alias(用户可能改用短号重加)。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            await con.execute(
                "INSERT INTO user_rooms (user_id, room_id, alias, added_ms)"
                " VALUES ($1,$2,$3,$4) ON CONFLICT (user_id, room_id)"
                " DO UPDATE SET alias=EXCLUDED.alias",
                int(user_id), str(room_id), str(alias or room_id),
                int(time.time() * 1000))

    async def user_first_login_seed(self, user_id: int, room_id: str, alias: str,
                                    room_max: int = 0) -> bool:
        """首登预置房:同一事务内「落首登标记 + 名额闸 + 绑定预置房」。
        返回是否**确有绑定落下**;非首登(标记已存在)零写入。同账号并发登录由
        主键天然去重 —— 只有一个事务能插入成功,其余在冲突上拿到 0 行。
        名额闸(room_max>0 时):首登时名录已满(功能上线前的存量满额账号)则
        **只燃标记、不绑定**,不突破每账号名录硬上限;一次性语义不变 ——
        此后即使腾出名额,再登录也不补种。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            async with con.transaction():
                res = await con.execute(
                    "INSERT INTO user_first_login (user_id, first_ms)"
                    " VALUES ($1,$2) ON CONFLICT (user_id) DO NOTHING",
                    int(user_id), int(time.time() * 1000))
                if res.endswith(" 0"):
                    return False                      # 非首登:什么都不动
                if int(room_max) > 0:
                    n = await con.fetchval(
                        "SELECT COUNT(*) FROM user_rooms WHERE user_id=$1",
                        int(user_id))
                    if int(n or 0) >= int(room_max):
                        return False                  # 满额:标记已燃,绑定不落
                await con.execute(
                    "INSERT INTO user_rooms (user_id, room_id, alias, added_ms)"
                    " VALUES ($1,$2,$3,$4) ON CONFLICT (user_id, room_id)"
                    " DO UPDATE SET alias=EXCLUDED.alias",
                    int(user_id), str(room_id), str(alias or room_id),
                    int(time.time() * 1000))
        return True

    async def user_room_unbind(self, user_id: int, room_id: str, alias: str = "") -> bool:
        """解绑(按归一号或用户输入号,双键覆盖历史数据)。返回是否确有删除。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            res = await con.execute(
                "DELETE FROM user_rooms WHERE user_id=$1 AND"
                " (room_id=$2 OR ($3 <> '' AND (room_id=$3 OR alias=$3)))",
                int(user_id), str(room_id), str(alias or ""))
        return not res.endswith(" 0")

    async def user_room_allowed(self, user_id: int, room_id: str, alias: str = "") -> bool:
        """明细类端点(history/prediction/config/…/SSE)的按账号访问闸。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            n = await con.fetchval(
                "SELECT 1 FROM user_rooms WHERE user_id=$1 AND"
                " (room_id=$2 OR ($3 <> '' AND (room_id=$3 OR alias=$3))) LIMIT 1",
                int(user_id), str(room_id), str(alias or ""))
        return bool(n)

    async def user_room_refcount(self, room_id: str) -> int:
        """仍绑定该房的登录账号数(跨账号引用计数;归零才考虑撤全局监控)。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            n = await con.fetchval(
                "SELECT COUNT(*) FROM user_rooms WHERE room_id=$1", str(room_id))
        return int(n or 0)

    async def user_added_mark(self, room_id: str, user_id: int) -> None:
        """记录「由登录用户把发现房转正」:绑定归零时全局监控随之退场的依据。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            await con.execute(
                "INSERT INTO user_added_rooms (room_id, first_user, added_ms)"
                " VALUES ($1,$2,$3) ON CONFLICT (room_id) DO NOTHING",
                str(room_id), int(user_id), int(time.time() * 1000))

    async def user_added_check(self, room_id: str) -> bool:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            n = await con.fetchval(
                "SELECT 1 FROM user_added_rooms WHERE room_id=$1", str(room_id))
        return bool(n)

    async def user_rooms_unbind_all(self, room_id: str, alias: str = "") -> int:
        """全局删除该房的**所有账号**绑定(3.8.0 复查修复:运维删房/引用收敛后
        级联,消灭指向已停监控房的僵尸名录项)。双键覆盖历史数据。返回删除行数。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            res = await con.execute(
                "DELETE FROM user_rooms WHERE room_id=$1"
                " OR ($2 <> '' AND (room_id=$2 OR alias=$2))",
                str(room_id), str(alias or ""))
        try:
            return int(res.rsplit(" ", 1)[-1])
        except Exception:
            return 0

    async def user_added_unmark(self, room_id: str) -> None:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            await con.execute(
                "DELETE FROM user_added_rooms WHERE room_id=$1", str(room_id))

    # ── 自动发现房 last_seen 持久层(回收 grace 长达 7 天,时钟必须跨重启存续) ──
    async def discovered_upsert_bulk(self, rows: List[tuple],
                                     batch_size: int = 500) -> None:
        """批量落 (room_id, last_seen_ms)。每轮遍历后由 reconcile 调用,
        把本轮在播发现房的 last_seen 镜像进 PG(Redis 为运行态,PG 为时钟真相)。"""
        assert self.pool is not None
        if not rows:
            return
        payload = [(str(r[0]), int(r[1])) for r in rows]
        async with self.pool.acquire() as con:
            for i in range(0, len(payload), max(1, batch_size)):
                await con.executemany(
                    "INSERT INTO discovered_rooms (room_id, last_seen_ms)"
                    " VALUES ($1,$2)"
                    " ON CONFLICT (room_id) DO UPDATE SET"
                    " last_seen_ms=GREATEST(discovered_rooms.last_seen_ms,"
                    "                       EXCLUDED.last_seen_ms)",
                    payload[i:i + batch_size])

    async def discovered_all(self) -> List[dict]:
        """全部发现房及其 last_seen(worker 启动回灌 / 回收判定兜底用)。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            rows = await con.fetch(
                "SELECT room_id, last_seen_ms FROM discovered_rooms"
                " ORDER BY room_id")
        return [dict(r) for r in rows]

    async def discovered_delete_bulk(self, room_ids: List[str],
                                     batch_size: int = 500) -> None:
        """批量移除发现房 last_seen 行(离线回收 / 手动转正为策展房时)。"""
        assert self.pool is not None
        ids = [str(r) for r in room_ids if r]
        if not ids:
            return
        async with self.pool.acquire() as con:
            for i in range(0, len(ids), max(1, batch_size)):
                await con.execute(
                    "DELETE FROM discovered_rooms WHERE room_id = ANY($1::text[])",
                    ids[i:i + batch_size])

    # ── 核验台账(经 roomStatus 核验准入的房;在播记录由 roomStatus 供货) ───────
    async def verified_upsert(self, room_id: str, live_ms: int) -> None:
        """记一次确认在播:新房落 first/last 两钟,已有房只把 last_live_ms 往新推。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            await con.execute(
                "INSERT INTO verified_rooms (room_id, first_live_ms, last_live_ms)"
                " VALUES ($1,$2,$2)"
                " ON CONFLICT (room_id) DO UPDATE SET"
                " last_live_ms=GREATEST(verified_rooms.last_live_ms, EXCLUDED.last_live_ms)",
                str(room_id), int(live_ms))

    async def verified_last_live(self, room_id: str) -> Optional[int]:
        """台账里该房最近一次确认在播的时刻;不在台账回 None。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            v = await con.fetchval(
                "SELECT last_live_ms FROM verified_rooms WHERE room_id=$1", str(room_id))
        return int(v) if v is not None else None

    async def verified_all(self) -> List[dict]:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            rows = await con.fetch(
                "SELECT room_id, last_live_ms, next_probe_ms FROM verified_rooms"
                " ORDER BY room_id")
        return [dict(r) for r in rows]

    async def verified_update_bulk(self, rows: List[tuple],
                                   batch_size: int = 500) -> None:
        """批量刷新 (room_id, last_live_ms, next_probe_ms):时钟只进不退,
        复核排期取新值。行不存在(已被清出台账)则不再复活。"""
        assert self.pool is not None
        if not rows:
            return
        payload = [(str(r[0]), int(r[1]), int(r[2])) for r in rows]
        async with self.pool.acquire() as con:
            for i in range(0, len(payload), max(1, batch_size)):
                await con.executemany(
                    "UPDATE verified_rooms SET"
                    " last_live_ms=GREATEST(last_live_ms, $2), next_probe_ms=$3"
                    " WHERE room_id=$1",
                    payload[i:i + batch_size])

    async def verified_delete_bulk(self, room_ids: List[str],
                                   batch_size: int = 500) -> None:
        assert self.pool is not None
        ids = [str(r) for r in room_ids if r]
        if not ids:
            return
        async with self.pool.acquire() as con:
            for i in range(0, len(ids), max(1, batch_size)):
                await con.execute(
                    "DELETE FROM verified_rooms WHERE room_id = ANY($1::text[])",
                    ids[i:i + batch_size])

    async def purge_rooms_history(self, room_ids: List[str],
                                  room_batch: int = 100,
                                  row_batch: int = 50_000,
                                  pause_s: float = 0.05) -> Dict[str, int]:
        """按房号删除 rounds/predictions 全部历史(发现房离线回收级联清史用)。

        表范围复用 _PURGE_TABLES 白名单(predictor_state/rooms 仍不清)。两级分批:
        房号 room_batch 个/组 × 行 row_batch 行/批(ctid 子查询限批),批间小憩
        pause_s 秒 —— 与 purge_before 同款节流,避免「7 天到期潮涌」时一次回收数千房
        造成长事务/锁放大。幂等:重复调用/半途中断再补删均无害。
        返回 {"rounds": n, "predictions": n}(实际删除行数)。
        """
        assert self.pool is not None
        ids = [str(r) for r in room_ids if str(r)]
        out: Dict[str, int] = {t: 0 for t in _PURGE_TABLES}
        if not ids:
            return out
        room_batch = max(1, int(room_batch))
        row_batch = max(1, int(row_batch))
        touched = {t: False for t in _PURGE_TABLES}
        for i in range(0, len(ids), room_batch):
            chunk = ids[i:i + room_batch]
            for table in _PURGE_TABLES:
                sql = (f"DELETE FROM {table} WHERE ctid IN ("
                       f"SELECT ctid FROM {table}"
                       f" WHERE room_id = ANY($1::text[])"
                       f" LIMIT {row_batch})")
                while True:
                    async with self.pool.acquire() as con:
                        # 单批显式长超时:池默认 command_timeout=30s,回收房存量大时
                        # 单批 5 万行可能超时;600s 上限只兜极端,与 purge_before 同款。
                        tag = await con.execute(sql, chunk, timeout=600.0)
                    try:
                        n = int(str(tag).split()[-1])
                    except (ValueError, IndexError):
                        n = 0
                    out[table] += n
                    if n:
                        touched[table] = True
                    if n < row_batch:
                        break
                    await asyncio.sleep(pause_s)
        for table in _PURGE_TABLES:
            if touched[table]:
                # 大批删除后刷新统计,保证后续查询计划稳定(与 purge_before 一致)。
                async with self.pool.acquire() as con:
                    await con.execute(f"ANALYZE {table}", timeout=1800.0)
        return out

    # ── 配置中枢:版本链 + 审计(后台管理台;JSONB 经连接编解码器直传 dict) ──────
    async def cfg_latest(self):
        """最新覆盖快照。返回 (rev, snapshot dict);无任何版本时 (0, {})。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            row = await con.fetchrow(
                "SELECT rev, snapshot FROM config_revisions ORDER BY rev DESC LIMIT 1")
        if not row:
            return 0, {}
        snap = row["snapshot"]
        return int(row["rev"]), dict(snap or {})

    async def cfg_latest_rev(self) -> int:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            v = await con.fetchval("SELECT COALESCE(MAX(rev), 0) FROM config_revisions")
        return int(v or 0)

    async def cfg_insert(self, ts_ms: int, author: str, note: str,
                         snapshot: Dict[str, Any], diff: Dict[str, Any]) -> int:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            rev = await con.fetchval(
                "INSERT INTO config_revisions (ts_ms, author, note, snapshot, diff)"
                " VALUES ($1,$2,$3,$4,$5) RETURNING rev",
                int(ts_ms), str(author), str(note or ""), dict(snapshot), dict(diff))
        return int(rev)

    async def cfg_get(self, rev: int) -> Optional[Dict[str, Any]]:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            row = await con.fetchrow(
                "SELECT rev, ts_ms, author, note, snapshot, diff"
                " FROM config_revisions WHERE rev = $1", int(rev))
        return dict(row) if row else None

    async def cfg_list(self, limit: int = 50) -> List[Dict[str, Any]]:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            rows = await con.fetch(
                "SELECT rev, ts_ms, author, note, diff FROM config_revisions"
                " ORDER BY rev DESC LIMIT $1", max(1, min(int(limit), 500)))
        return [dict(r) for r in rows]

    async def cfg_diff_keys_since(self, rev: int) -> set:
        """(rev, 最新] 区间内被触碰过的配置键集合(舰队「需重启」判定用)。"""
        assert self.pool is not None
        async with self.pool.acquire() as con:
            rows = await con.fetch(
                "SELECT diff FROM config_revisions WHERE rev > $1", int(rev))
        keys: set = set()
        for r in rows:
            d = r["diff"] or {}
            if isinstance(d, dict):
                keys.update(d.keys())
        return keys

    async def audit_add(self, ts_ms: int, actor: str, action: str,
                        detail: Dict[str, Any], rev: Optional[int] = None) -> None:
        assert self.pool is not None
        async with self.pool.acquire() as con:
            await con.execute(
                "INSERT INTO admin_audit (ts_ms, actor, action, detail, rev)"
                " VALUES ($1,$2,$3,$4,$5)",
                int(ts_ms), str(actor), str(action), dict(detail or {}),
                int(rev) if rev is not None else None)

    async def audit_list(self, limit: int = 100,
                         action: Optional[str] = None) -> List[Dict[str, Any]]:
        assert self.pool is not None
        lim = max(1, min(int(limit), 1000))
        async with self.pool.acquire() as con:
            if action:
                rows = await con.fetch(
                    "SELECT id, ts_ms, actor, action, detail, rev FROM admin_audit"
                    " WHERE action = $2 ORDER BY id DESC LIMIT $1", lim, str(action))
            else:
                rows = await con.fetch(
                    "SELECT id, ts_ms, actor, action, detail, rev FROM admin_audit"
                    " ORDER BY id DESC LIMIT $1", lim)
        return [dict(r) for r in rows]

    # ── 数据生命周期(5.4.0;调度与全表登记在 lifecycle.py,这里只管 SQL) ──────────
    async def audit_purge_batch(self, cutoff_ms: int, actions, batch_rows: int) -> int:
        """删一批「会话类」审计行(ts_ms < cutoff 且 action ∈ actions)。返回实删行数。

        只删调用方点名的动作 —— 操作类证据(改配置 / 发卡 / 删卡墓碑 …)不在名单里,
        任何保留期都碰不到它们(分级见 lifecycle.AUDIT_*)。
        代价(5.4.0 复查实测,PG 16):超期段里永久保留的操作类证据行每一轮都会被扫过 ——
        100 万条旧证据行时规划器选并行顺序扫描,单次 149ms;每 6 小时一次,可以接受,
        故不为它加索引。首轮上线的积压期每批同样一次扫描,由引擎的时间预算兜住。
        """
        assert self.pool is not None
        acts = [str(a) for a in actions]
        if not acts:
            return 0
        async with self.pool.acquire() as con:
            tag = await con.execute(
                "DELETE FROM admin_audit WHERE id IN ("
                " SELECT id FROM admin_audit WHERE ts_ms < $1 AND action = ANY($2::text[])"
                " ORDER BY ts_ms LIMIT $3)",
                int(cutoff_ms), acts, max(1, int(batch_rows)), timeout=120.0)
        try:
            return int(str(tag).split()[-1])
        except (ValueError, IndexError):
            return 0

    async def gc_predictor_state(self, batch_rows: int = 2000) -> int:
        """回收**离场房**的预测器状态(一批,至多 batch_rows 行)。返回实删行数。

        分批而非一条删完:首轮上线时存量孤儿可能很多,而 asyncpg 的超时是**取消并回滚**
        (不像 MySQL 会在服务端跑完)—— 一条删不完就永远删不完。由 lifecycle.run_batched
        反复调用直到返回值小于 batch_rows。

        predictor_state 每房 2 行(model_weights / explore_state,实测稳态 1.8~17 KB),
        此前**没有任何删除路径**:房间被移出名录后,它的历史随 retention 清掉,状态行
        却永久留下 —— 用户每换一批房,就多一批再也没人读的行。

        判据(三条同时成立才删,宁可少删):
          ① 不在册:rooms 里没有它的 active / pending 行;
          ② rounds 里已没有它的任何一局;③ predictions 里也没有。
        ②③ 意味着它离场已超过保留期。此时即便日后重新加回来,训练序列也是空的,
        本来就是冷启动;留着几周前的赤字账本与节拍令牌只会让冷启动带着陈旧状态。
        仍在册的房(含空闲降级的冷房、刚加进来还没出第一局的新房)被 ① 挡住;
        降级为后台发现房但仍在供数的房被 ② 挡住。retention.days ≤ 0(历史永久保留)
        时 ② 永不成立,本回收自然静默 —— 与「永久保留」的语义自洽。
        """
        assert self.pool is not None
        async with self.pool.acquire() as con:
            tag = await con.execute(
                "DELETE FROM predictor_state WHERE ctid IN ("
                " SELECT ps.ctid FROM predictor_state ps WHERE"
                " NOT EXISTS (SELECT 1 FROM rooms r WHERE r.room_id = ps.room_id"
                "             AND (r.active OR r.pending))"
                " AND NOT EXISTS (SELECT 1 FROM rounds x WHERE x.room_id = ps.room_id)"
                " AND NOT EXISTS (SELECT 1 FROM predictions p WHERE p.room_id = ps.room_id)"
                " LIMIT $1)",
                max(1, int(batch_rows)), timeout=120.0)
        try:
            return int(str(tag).split()[-1])
        except (ValueError, IndexError):
            return 0

    async def gc_room_tombstones(self, batch_rows: int = 2000) -> int:
        """回收 rooms 表里的**停用墓碑行**(一批,至多 batch_rows 行)。返回实删行数。

        删房只是把行标成 active=false(upsert_room)。全项目对 rooms 的读只有两句:
        `WHERE active` 与 `WHERE pending AND NOT active`(restore_rooms / active_rooms)
        —— 既不 active 也不 pending 的行**从不被读**,只是占位。
        与状态回收同一把尺,只抹掉「彻底离场」的:无历史(rounds 与 predictions 都已
        清空)、无任何账号绑定(user_rooms)。房间日后重新添加走 upsert,行会原样长回来。
        """
        assert self.pool is not None
        async with self.pool.acquire() as con:
            tag = await con.execute(
                "DELETE FROM rooms WHERE ctid IN ("
                " SELECT r.ctid FROM rooms r WHERE NOT r.active AND NOT r.pending"
                " AND NOT EXISTS (SELECT 1 FROM rounds x WHERE x.room_id = r.room_id)"
                " AND NOT EXISTS (SELECT 1 FROM predictions p WHERE p.room_id = r.room_id)"
                " AND NOT EXISTS (SELECT 1 FROM user_rooms u WHERE u.room_id = r.room_id)"
                " LIMIT $1)",
                max(1, int(batch_rows)), timeout=120.0)
        try:
            return int(str(tag).split()[-1])
        except (ValueError, IndexError):
            return 0

    _STAT_EXACT_MAX_BYTES = 16 << 20     # ≤16MB 的表直接 count(*)(毫秒级,精确)

    async def storage_stats(self) -> Dict[str, Any]:
        """容量体检(只读):库总大小 + 当前 schema 下每张普通表的行数 / 字节数。

        字节 = pg_total_relation_size(堆 + 全部索引 + TOAST)。行数:小表精确 count(*);
        大表取 pg_class.reltuples(由 ANALYZE / autovacuum 维护的估计值,rounds 与
        predictions 每轮清理后都会 ANALYZE)—— 对千万行的表做 count(*) 是在用体检
        制造负载。从未 ANALYZE 过的大表(reltuples < 0)如实回 None,不猜。
        返回 {"db_bytes": int, "tables": {表名: {rows, bytes, exact}}}。
        """
        assert self.pool is not None
        async with self.pool.acquire() as con:
            db_bytes = await con.fetchval("SELECT pg_database_size(current_database())")
            rows = await con.fetch(
                "SELECT c.relname AS t, quote_ident(c.relname) AS q,"
                "       c.reltuples::bigint AS est,"
                "       pg_total_relation_size(c.oid) AS bytes"
                " FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace"
                " WHERE n.nspname = current_schema() AND c.relkind = 'r'"
                " ORDER BY c.relname")
            tables: Dict[str, Any] = {}
            for r in rows:
                size, est, exact = int(r["bytes"]), int(r["est"]), False
                n: Optional[int] = est if est >= 0 else None
                if size <= self._STAT_EXACT_MAX_BYTES:
                    n = int(await con.fetchval(f"SELECT count(*) FROM {r['q']}"))
                    exact = True
                tables[str(r["t"])] = {"rows": n, "bytes": size, "exact": exact}
        return {"db_bytes": int(db_bytes or 0), "tables": tables}
