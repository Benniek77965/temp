"""
config_registry.py — 配置注册表(唯一真相源,Schema-Driven)
================================================================================
把全项目约 95 个参数登记成一份带中文说明、类型、单位、取值范围、热更等级、
消费进程、敏感/危险标记的 Schema:

  · 管理页(入口路径见 admin.path)完全由本表驱动渲染 —— 后端登记新参数,前端零改动;
  · `tests/test_config_registry.py` 的 drift-guard 强制本表与 `settings.Settings`
    字段集合**双向一致**(含默认值一致),任何一侧演进而未同步登记即测试失败;
  · 中文说明迁移自 config.yaml / settings.py 既有注释(项目最宝贵的运维知识)。

热更等级(hot):
  HOT      🟢 原地改字段即生效(使用点即时读取,见方案 §1.5 事实 A/B);
  HOOK     🟡 需既定小钩子(令牌桶 update / 预测桥换新 / setLevel / 发现器重建);
  RESTART  🔴 构造期/进程级参数,重启进程才生效(管理页诚实标注并给出指令);
  RESERVED ⚪ 预留未接线或建议只读(如 fetch_lamp、妖兽编号表)。

readonly=True 的项**不接受运行时覆盖**(连接串/路径类部署项、名录容器等),
管理页仅展示其生效值与来源。no_reset=True 的项在覆盖被清除时**不回落基线**
(鉴权票据由 cookie 自动续期链路接管,见 worker._auth_refresher)。
"""
from __future__ import annotations

from dataclasses import dataclass, field as dc_field
from typing import Any, Dict, Optional, Tuple

from .settings import UserAuthCfg   # 4.2.0:VIP 档位表默认值单一真源

# ── 热更等级 ──────────────────────────────────────────────────────────────────
HOT = "hot"
HOOK = "hook"
RESTART = "restart"
RESERVED = "reserved"

# 敏感值在版本快照(PG JSONB)里的占位:真值只经 Redis `cfg:sensitive` 内存分发,
# 审计/版本库永不落明文票据(方案 §5.3)。
SENTINEL_REDIS = "__redis__"


@dataclass(frozen=True)
class Field:
    label: str                        # 中文名(UI 主标)
    type: str                         # int / float / bool / str / enum / csvnums / json
    default: Any                      # 必须与 Settings dataclass 默认一致(drift 测试断言)
    hot: str = HOT
    consumers: Tuple[str, ...] = ("worker",)
    section: str = ""                 # 板块(中文,UI 分组)
    desc: str = ""                    # 说明(迁移自既有注释)
    unit: str = ""
    ge: Optional[float] = None
    le: Optional[float] = None
    choices: Optional[Tuple[str, ...]] = None
    env: Optional[str] = None         # 对应 STA_ 环境变量(无则 None)
    sensitive: bool = False
    danger: bool = False              # 高危标记:管理台醒目提示,改错代价大(应用后可一键回滚)
    readonly: bool = False            # 不接受运行时覆盖
    no_reset: bool = False            # 清除覆盖不回落基线(auth 系)
    # >0 = 管理台在该密钥输入框旁给一个「🎲 生成」按钮,用 crypto.getRandomValues
    # 生成 N 字节随机值(hex)。**只给「我方自定、对方照抄」的密钥** —— auth.ticket
    # 之类是上游签发的凭据,本地随机生成一个只会把接入打挂。
    gen_bytes: int = 0
    # True = 允许管理台经 /config/reveal 取回**明文**(每次取回都落审计)。
    # 只给「我方自定、需要交付给对端」的密钥 —— 上游签发的凭据(auth.ticket)
    # 运维本来就是从对方那里拿的,本台没有交付责任,不开这个口子。
    revealable: bool = False
    depends: str = ""                 # 依赖/生效条件说明
    hook: str = ""                    # 钩子标识(config_center 按此分发)
    validator: str = ""               # 具名语义校验器(config_center.semantic_validate)


def F(**kw) -> Field:  # noqa: N802  (紧凑登记用)
    return Field(**kw)


# ── 板块顺序(UI 分组导航按此排) ───────────────────────────────────────────────
SECTIONS: Tuple[str, ...] = (
    "进程与连接", "上游抓取", "错峰调度", "分布式限流", "批量准入",
    "数据保留", "自动发现", "直播状态", "预测引擎", "鉴权票据", "登录系统", "九法VIP", "管理台", "元数据",
)

# prediction 板块的键清单(config.yaml `prediction:` 基线;drift 测试对照 yaml)。
PREDICTION_KEYS: Tuple[str, ...] = (
    "enabled", "recent_window", "ewma_half_life", "markov_shrink", "markov2_shrink",
    "omission_gamma", "hedge_eta", "hedge_mix", "max_train", "train_window_hours",
    "accuracy_window",
    "replay_enabled", "replay_warmup", "replay_interval_s", "replay_batch",
    "replay_cooldown_s",
    "freq_anchor", "anchor_window", "anchor_drift_floor",
    "anchor_drift_ref", "anchor_lambda_min", "predict_mode", "adaptive_lambda",
    "explore_every", "explore_patrol", "explore_min_z", "explore_z0", "explore_calib",
    "explore_rhythm_w", "explore_style", "explore_abstain", "explore_tie_eps",
    "seat_order", "main_swap_band", "showcase_q", "showcase_kdist", "matched_window",
    # 反固执改造(anti-stubborn;引擎 dataclass / config.yaml / 本注册表三方同值)
    "anti_stubborn", "as_alpha", "as_alpha_ord", "as_mcap_hot", "as_mcap_cold",
    "as_gamma", "as_pen_cap", "as_pen_on_hit", "as_breaker", "as_khyst",
    "as_cooldown", "as_beta", "as_agecap",
    # 冷位份额闭环·赤字调度(showcase 身份轮换;引擎/yaml/注册表三方同值)
    "showcase_rotate", "sc_eta_cold", "sc_eta_hot", "sc_floor_cold",
    "sc_floor_hot", "sc_lambda", "sc_debt_cap", "sc_repeat_cap",
    "sc_beta_off", "sc_fp_depth",
    # 冷位节拍器(cadence-governor;4.9.7 补登记 —— 此前只存在于引擎 dataclass,
    # yaml 与本表都没有它 ⇒ 静默取引擎缺省「开」,而 showcase_kdist 却停在关态刻度,
    # 构成引擎明令禁止的半状态。与 explore_style 改回 showcase 同批补齐)
    "cadence_governor", "cg_run3", "cg_run2", "cg_cap3", "cg_cap2",
    "cg_force3", "cg_force2", "cg_rfloor",
    "showcase_cold_ids",
    # 重现观察期(repeat-guard;引擎/yaml/注册表三方同值)
    "repeat_guard", "rg_theta", "rg_cap", "rg_pmax",
    "rg_seat_damp", "rg_minm", "rg_zpos",
    # 天花板前沿调度(frontier;引擎 dataclass / config.yaml / 本注册表三方同值)
    "fr_cold_min", "fr_rare_min", "fr_ret_min", "fr_share_min",
    "fr_share_max", "fr_main_share_min", "fr_replan", "fr_rare_ids", "fr_mult",
    "fr_share_floors",
    # 冷启动自适应收缩(4.9.4;引擎 dataclass / config.yaml / 本注册表三方同值)
    "prior_shrink", "prior_table",
)


def _pred(key: str, label: str, type_: str, default: Any, desc: str = "",
          **kw) -> Tuple[str, Field]:
    """预测参数统一登记:worker 侧经预测桥换新钩子(🟡),web 侧 dict 原地读即热;
    全体标 danger(改变预测口径;权重在 PG predictor_state 持久,不随参数清零)。"""
    return f"prediction.{key}", Field(
        label=label, type=type_, default=default, hot=HOOK, hook="bridge",
        consumers=("worker", "web"), section="预测引擎", danger=True,
        desc=desc or "预测引擎参数(逐字段透传原引擎,不改算法);应用后 worker 原子换新预测桥",
        **kw)


REGISTRY: Dict[str, Field] = {
    # ═══ 进程与连接(以 ENV 为主要来源;连接串/路径类为部署项,只读展示) ═══════
    "pg_dsn": F(label="PostgreSQL 连接串", type="str",
                default="postgresql://star:star@localhost:5432/spelltamer",
                hot=RESTART, consumers=("worker", "web"), section="进程与连接",
                env="STA_PG_DSN", sensitive=True, readonly=True,
                desc="含口令的部署项:仅经 ENV/YAML 配置,管理台只读展示(改此项请编辑 .env 并重建容器)"),
    "redis_url": F(label="Redis 连接串", type="str", default="redis://localhost:6379/0",
                   hot=RESTART, consumers=("worker", "web"), section="进程与连接",
                   env="STA_REDIS_URL", sensitive=True, readonly=True,
                   desc="部署项:仅经 ENV/YAML 配置,管理台只读展示"),
    "http_conn_limit": F(label="抓取连接总上限", type="int", default=500, ge=1, le=20000,
                         hot=RESTART, section="进程与连接", env="STA_HTTP_CONN_LIMIT",
                         desc="aiohttp 连接器总连接上限(单 worker);会话构造期参数,重启生效"),
    "http_conn_per_host": F(label="单主机连接上限", type="int", default=500, ge=1, le=20000,
                            hot=RESTART, section="进程与连接", env="STA_HTTP_CONN_PER_HOST",
                            desc="上游几乎单域名,通常与总上限同值;重启生效"),
    "worker_concurrency": F(label="单 worker 在飞任务上限", type="int", default=800,
                            ge=1, le=20000, hot=RESTART, section="进程与连接",
                            env="STA_WORKER_CONCURRENCY",
                            desc="consumer 协程数在 run() 一次性创建(worker.py),重启生效;"
                                 "吞吐不够优先横向扩 worker 副本"),
    "pg_pool_min": F(label="PG 连接池下限", type="int", default=4, ge=0, le=512,
                     hot=RESTART, consumers=("worker", "web"), section="进程与连接",
                     env="STA_PG_POOL_MIN", desc="每进程 asyncpg 池;重启生效"),
    "pg_pool_max": F(label="PG 连接池上限", type="int", default=32, ge=1, le=1024,
                     hot=RESTART, consumers=("worker", "web"), section="进程与连接",
                     env="STA_PG_POOL_MAX",
                     desc="受 postgres max_connections × 进程副本数约束;重启生效"),
    "starmeta_conn_limit": F(label="繁星归一连接上限", type="int", default=64, ge=1, le=2048,
                             hot=RESTART, consumers=("worker", "web"), section="进程与连接",
                             env="STA_STARMETA_CONN_LIMIT",
                             desc="连接层护栏;真正削峰靠 ratelimit.fanxing_* 令牌桶。重启生效"),
    "redis_max_connections": F(label="Redis 连接池上限", type="int", default=256, ge=8, le=65536,
                               hot=RESTART, consumers=("worker", "web"), section="进程与连接",
                               env="STA_REDIS_MAX_CONNECTIONS",
                               desc="web/seed 基线;worker 启动时按并发自动放大。重启生效"),
    "redis_pool_timeout": F(label="Redis 池等待上限(worker)", type="float", default=30.0,
                            ge=0.1, le=600, unit="s", hot=RESTART, section="进程与连接",
                            env="STA_REDIS_POOL_TIMEOUT",
                            desc="阻塞池打满时的排队等待秒数(worker 宁等勿崩);重启生效"),
    "web_pool_timeout": F(label="Redis 池等待上限(web)", type="float", default=5.0,
                          ge=0.1, le=120, unit="s", hot=RESTART, consumers=("web",),
                          section="进程与连接", env="STA_WEB_POOL_TIMEOUT",
                          desc="web 服务 HTTP 请求,池满应较快失败由客户端重连;重启生效"),
    "sse_max_connections": F(label="SSE 专用 Redis 池上限", type="int", default=4096,
                             ge=8, le=65536, hot=RESTART, consumers=("web",),
                             section="进程与连接", env="STA_SSE_MAX_CONN",
                             desc="SSE 的 pubsub 是长连接,与只读 HTTP 分池(舱壁),"
                                  "观众打满也不波及普通 API;按并发观众数设。重启生效"),
    "sse_pool_timeout": F(label="SSE 池等待上限", type="float", default=30.0,
                          ge=0.1, le=600, unit="s", hot=RESTART, consumers=("web",),
                          section="进程与连接", env="STA_SSE_POOL_TIMEOUT",
                          desc="SSE 是后台长连,池满时宁等勿断(与 web_pool_timeout 相反的取舍);重启生效"),
    "live_rooms_concurrency": F(label="live-rooms 逐房并发闸", type="int", default=32,
                                ge=1, le=512, hot=RESTART, consumers=("web",),
                                section="进程与连接", env="STA_LIVE_ROOMS_CONCURRENCY",
                                desc="单个 /api/live-rooms 请求同时拼几张卡;防一个请求吸干连接池。重启生效"),
    "upstream_thread_limit": F(label="阻塞上游线程配额", type="int", default=64,
                               ge=1, le=512, hot=RESTART, consumers=("web",),
                               section="进程与连接", env="STA_UPSTREAM_THREAD_LIMIT",
                               desc="账号/游戏接口是同步阻塞实现(直打酷狗,10~12s 超时),"
                                    "占**自己的**线程闸而非默认线程池(舱壁)。"
                                    "上游雪崩时只挤爆这一格,静态资源不受牵连。"
                                    "默认 64 = 修复前天花板(40)之上再留余量:每线程仅 ~19KB RSS,"
                                    "按 Little 定律 ≈ 上游全超时时仍扛 8 个同时扫码用户。"
                                    "按同时在线用户数上调即可,不影响静态资源。重启生效"),
    "web_thread_pool": F(label="默认线程池令牌数", type="int", default=64,
                         ge=8, le=1024, hot=RESTART, consumers=("web",),
                         section="进程与连接", env="STA_WEB_THREAD_POOL",
                         desc="anyio 默认线程池(Starlette 静态资源的 stat/open/read 走这里)。"
                              "原生默认仅 40 且与阻塞上游共享 —— 分舱后这里只剩毫秒级本地"
                              "磁盘 IO;线程按需创建、空闲 10s 回收,上调不增常驻成本。重启生效"),
    "log_level": F(label="日志级别", type="enum", default="INFO",
                   choices=("DEBUG", "INFO", "WARNING", "ERROR"),
                   hot=HOOK, hook="loglevel", consumers=("worker", "web"),
                   section="进程与连接", env="STA_LOG_LEVEL",
                   desc="经 setLevel 钩子即时生效(根 logger)"),
    "rare_log_multiplier": F(label="💎稀有出怪日志阈值", type="int", default=500,
                             ge=1, le=100000, unit="倍", section="进程与连接",
                             env="STA_RARE_LOG_MULTIPLIER",
                             desc="倍率 ≥ 此值的出怪才打 INFO(其余逐局日志为 DEBUG)。"
                                  "旧值 250 覆盖了**实测 15.0%** 的出怪(白虹骥 6.53% + "
                                  "焚天雀 4.93% + 沧溟龙 3.56%;公示口径 12% 与实盘长期不符,"
                                  "容量按实测算),1 万房下 ≈30 行/s(≈260 万行/天),"
                                  "会把 janitor/discovery/retention/WARNING 挤出日志轮转窗口。"
                                  "默认 500(仅沧溟龙,实测 3.56%)→ 万房 ≈7 行/s、可回看 ≈5 天。每局现读、即时生效"),
    "static_dir": F(label="前端静态目录", type="str", default="", hot=RESTART,
                    consumers=("web",), section="进程与连接", env="STA_STATIC_DIR",
                    readonly=True, desc="部署项:web 启动时挂载,管理台只读展示"),
    "accounts_path": F(label="账号库路径", type="str", default="accounts.json",
                       hot=RESTART, consumers=("web",), section="进程与连接",
                       env="STA_ACCOUNTS_PATH", readonly=True,
                       desc="部署项:/api/account/* 登录账号落库路径,建议指向持久卷"),
    "auth_cookie_file": F(label="续期 Cookie 文件", type="str", default="",
                          hot=HOT, consumers=("worker",), section="进程与连接",
                          env="STA_AUTH_COOKIE_FILE", readonly=True,
                          desc="部署项:login 服务写入的 spell_tamer_config.json 路径;"
                               "worker 据此热更新票据(留空=不启用自动续期)"),
    "auth_refresh_s": F(label="票据轮询间隔", type="int", default=60, ge=15, le=86400,
                        unit="s", hot=HOT, consumers=("worker",), section="进程与连接",
                        env="STA_AUTH_REFRESH_S",
                        desc="worker 读取续期 Cookie 文件的周期;循环内现读,即时生效"),
    "activity_id": F(label="活动 ID", type="int", default=2, ge=1, le=9999,
                     hot=HOT, consumers=("worker", "web"), section="进程与连接",
                     danger=True,
                     desc="上游九法活动编号 —— 改错=全量抓错活动,每任务现读、即时生效,务必确认"),

    # ═══ 上游抓取(单房行为,与旧引擎一致) ═══════════════════════════════════
    "upstream.base_url": F(label="上游 API 地址", type="str",
                           default="https://mapi.tencentmusic.com", hot=RESTART,
                           section="上游抓取",
                           desc="aiohttp 会话构造期参数;上游迁移时改此项并重启 worker"),
    "upstream.request_timeout": F(label="单请求超时", type="float", default=15.0,
                                  ge=1, le=120, unit="s", hot=RESTART, section="上游抓取",
                                  desc="会话级 ClientTimeout,构造期参数;重启生效"),
    "upstream.verify_tls": F(label="校验 TLS 证书", type="bool", default=False,
                             hot=RESTART, section="上游抓取",
                             desc="连接器构造期参数;重启生效(默认不校验)"),
    "upstream.award_after_seal": F(label="备战后取奖延迟", type="float", default=1.5,
                                   ge=0, le=15, unit="s", section="上游抓取",
                                   desc="备战(spellTime)+ 该延迟后取 RoundAward;真机实测结果备战后 ~1s 即生成,主锚点;每任务现读、即时生效",
                                   validator="award_cycle"),
    "upstream.award_delay": F(label="取奖延迟(兜底)", type="float", default=2.5, ge=0, le=30,
                              unit="s", section="上游抓取",
                              desc="兜底:MainPage 未给 spellTime 时,退回「出怪时刻(drawTime)+ 该延迟」;即时生效",
                              validator="award_cycle"),
    "upstream.award_retry_interval": F(label="取奖重试间隔", type="float", default=1.5,
                                       ge=0.2, le=30, unit="s", section="上游抓取",
                                       desc="RoundAward 未就绪的重试间隔;即时生效",
                                       validator="award_cycle"),
    "upstream.award_max_retries": F(label="取奖最大重试", type="int", default=11, ge=0, le=60,
                                    section="上游抓取",
                                    desc="RoundAward 最大重试次数;即时生效",
                                    validator="award_cycle"),
    "upstream.fetch_lamp": F(label="抓取跑马灯", type="bool", default=True,
                             hot=RESERVED, readonly=True, section="上游抓取",
                             desc="预留:upstream.lamp_list 已实现但 worker 尚未消费此开关,"
                                  "置 true/false 目前均无副作用(config.yaml 原注)"),

    # ═══ 错峰调度(削平请求毛刺) ═════════════════════════════════════════════
    "scheduler.award_jitter_ms": F(label="取奖排期抖动", type="int", default=1200,
                                   ge=0, le=60000, unit="ms", section="错峰调度",
                                   desc="RoundAward 排期随机抖动上限(±打散,错峰核心);即时生效"),
    "scheduler.mainpage_jitter_ms": F(label="MainPage 排期抖动", type="int", default=4000,
                                      ge=0, le=60000, unit="ms", section="错峰调度",
                                      desc="下一局 MainPage 排期抖动上限;即时生效"),
    "scheduler.mainpage_min_interval_ms": F(label="MainPage 最小间隔", type="int",
                                            default=8000, ge=0, le=600000, unit="ms",
                                            section="错峰调度",
                                            desc="同房两次 MainPage 的最小间隔(空转保护);即时生效"),
    "scheduler.award_backoff_ms": F(label="取奖回退步长", type="int", default=1500,
                                    ge=100, le=60000, unit="ms", section="错峰调度",
                                    desc="RoundAward 未就绪时的排期回退步长;即时生效"),
    "scheduler.claim_batch": F(label="领取批量", type="int", default=200, ge=1, le=10000,
                               section="错峰调度",
                               desc="单 worker 每次从延迟队列领取的到期任务数;循环内现读、即时生效"),
    "scheduler.janitor_interval_s": F(label="自愈巡检周期", type="int", default=30,
                                      ge=5, le=3600, unit="s", section="错峰调度",
                                      desc="janitor 补回丢失的未来任务的周期;循环内现读、下周期生效"),
    "scheduler.stale_task_grace_ms": F(label="任务卡死判定", type="int", default=30000,
                                       ge=1000, le=600000, unit="ms", section="错峰调度",
                                       desc="任务租约:超期多久判定为「卡死」可被别的副本重新领取。"
                                            "**必须 > 单任务最坏耗时**(令牌等待 8s + 上游超时 15s "
                                            "= 23s),否则慢请求会在返回的同一瞬间被重复领取、"
                                            "重复打上游。即时生效"),

    # ═══ 分布式限流(令牌桶,跨全部 worker/机器共享) ═══════════════════════════
    "ratelimit.upstream_rps": F(label="上游全局 QPS", type="float", default=0.0,
                                ge=0, le=100000, unit="req/s", hot=HOOK,
                                hook="rl_upstream", section="分布式限流",
                                desc="对上游游戏 API(mapi)的全局每秒请求上限;"
                                     "**0 = 不限制**(令牌桶退化为始终放行)。钩子即时生效"),
    "ratelimit.burst": F(label="上游令牌桶容量", type="float", default=600.0, ge=1,
                         le=1000000, hot=HOOK, hook="rl_upstream", section="分布式限流",
                         depends="仅当 upstream_rps > 0 时生效", validator="burst_dep",
                         desc="允许的突发量;钩子即时生效"),
    "ratelimit.per_room_min_interval_ms": F(label="单房最小请求间隔", type="int",
                                            default=0, ge=0, le=600000, unit="ms",
                                            section="分布式限流",
                                            desc="防单房异常自旋的安全网;**0 = 关闭**。"
                                                 "每任务现读、即时生效"),
    "ratelimit.fanxing_rps": F(label="繁星归一 QPS", type="float", default=0.0,
                               ge=0, le=100000, unit="req/s", hot=HOOK,
                               hook="rl_fanxing", consumers=("worker", "web"),
                               section="分布式限流",
                               desc="房号归一(fanxing/service.kugou.com)专用令牌桶,与游戏 API "
                                    "独立;**0 = 不限制**。归一被封 IP 时设正值(如 120)。钩子即时生效"),
    "ratelimit.fanxing_burst": F(label="繁星令牌桶容量", type="float", default=240.0,
                                 ge=1, le=1000000, hot=HOOK, hook="rl_fanxing",
                                 consumers=("worker", "web"), section="分布式限流",
                                 depends="仅当 fanxing_rps > 0 时生效",
                                 validator="fanxing_burst_dep", desc="钩子即时生效"),

    # ═══ 批量准入(bulk-add 削峰核心) ═════════════════════════════════════════
    "admission.canon_concurrency": F(label="归一并发上限", type="int", default=32,
                                     ge=1, le=1024, consumers=("worker", "web"),
                                     section="批量准入",
                                     desc="归一阶段最大并发(叠加繁星令牌桶双重约束);"
                                          "每次批量调用现读、即时生效"),
    "admission.warmup_window_ms": F(label="首抓错峰窗口", type="int", default=60000,
                                    ge=0, le=600000, unit="ms",
                                    consumers=("worker", "web"), section="批量准入",
                                    desc="首次起抓在此窗口内均匀铺开(消除重排风暴)。1 万房冷启动时"
                                         "每房首抓还连带一次 GameHistory 回填,20s 窗口 ≈1000 rps "
                                         "瞬时洪峰,60s 降到 ≈333 rps(3.4.8:重启回灌若 PG 已有数据"
                                         "则播种免打,该场景趋近 ×1);即时生效"),
    "admission.batch_size": F(label="批量写入单批行数", type="int", default=500,
                              ge=1, le=10000, consumers=("worker", "web"),
                              section="批量准入", desc="库/名录批量写入单批行数;即时生效"),
    "admission.max_bulk": F(label="单次批量添加护栏", type="int", default=20000,
                            ge=1, le=100000, consumers=("web",), section="批量准入",
                            validator="max_bulk_cap",
                            desc="单次批量添加的房数上限;硬顶 100000。即时生效"),

    # ═══ 数据保留(每房历史滚动窗口;北京时间口径) ═════════════════════════════
    "retention.days": F(label="保留天数", type="float", default=1.0, ge=-1, le=3650,
                        unit="天", consumers=("worker", "web"), section="数据保留",
                        danger=True, validator="retention_vs_train",
                        env="STA_RETENTION_DAYS",
                        desc="每房出怪/预测历史滚动保留 N 天;**≤0 = 永久保留(关闭清理)**。"
                             "⚠ 调小将于下一清理周期起**不可逆删除**超窗历史数据;"
                             "循环内现读、即时生效(关↔开 亦热切换)"),
    "retention.sweep_interval_s": F(label="清理巡检周期", type="int", default=3600,
                                    ge=60, le=86400, unit="s", section="数据保留",
                                    env="STA_RETENTION_SWEEP_S",
                                    desc="兼作跨进程互斥锁 TTL;循环内现读、下周期生效"),
    "retention.batch_rows": F(label="单批删除行数", type="int", default=50000,
                              ge=100, le=1000000, section="数据保留",
                              env="STA_RETENTION_BATCH_ROWS",
                              desc="分批 DELETE,避免长事务/锁放大;即时生效"),
    "retention.max_batches": F(label="单次巡检批数护栏", type="int", default=400,
                               ge=1, le=100000, section="数据保留",
                               desc="超出的余量留给下个周期继续;即时生效"),
    # ── 5.4.0 数据生命周期:小表保留策略(web 进程每 6 小时清扫;全表清单与现状见
    #    管理台左栏「储」· 存储与保留,原理见 DATA-LIFECYCLE.md)────────────────────
    "retention.audit_days": F(label="管理审计保留(会话类)", type="int", default=184,
                              ge=0, le=3650, unit="天", hot=RESTART, readonly=True,
                              consumers=("web",),
                              section="数据保留", env="STA_RETENTION_AUDIT_DAYS",
                              desc="审计日志里**会话类**动作(登录/登出/登录失败/人机验证未过)"
                                   "的保留天数;0=不清。**操作类**动作(改配置、发卡、删卡墓碑、"
                                   "开通撤销…)是证据,永久保留,不受本项影响。会删除安全审计,故只能在服务器"
                                   "上改(管理台只读,与登录流水保留同一口径)"),
    "retention.state_gc": F(label="离场房状态回收", type="bool", default=True,
                            consumers=("web",), section="数据保留",
                            env="STA_RETENTION_STATE_GC",
                            desc="房间已离场(不在册)且历史已随保留期清空 → 回收它的预测器状态"
                                 "与名录墓碑行(此前这两类行只增不减)。仍在册、或仍有历史的房"
                                 "一律不碰;日后重新加回按冷启动重建。关闭=退回旧行为"),

    # ═══ 自动发现(遍历繁星在播列表,自动纳入后台抓取;前端不显示) ═══════════════
    "discovery.enabled": F(label="自动发现总开关", type="bool", default=True,
                           consumers=("worker", "web"), section="自动发现", danger=True,
                           env="STA_DISCOVERY_ENABLED",
                           desc="false = worker 不跑发现循环(存量发现房停止回收判定,"
                                "已在抓的照常抓)。循环内现读、即时生效"),
    "discovery.interval_s": F(label="遍历周期", type="int", default=60, ge=5, le=86400,
                              unit="s", consumers=("worker", "web"), section="自动发现",
                              env="STA_DISCOVERY_INTERVAL_S", validator="disc_interval",
                              desc="兼作跨副本互斥锁 TTL;循环内现读、下周期生效"),
    "discovery.max_pages": F(label="单轮分页护栏", type="int", default=400, ge=1, le=5000,
                             hot=HOOK, hook="disc_rebuild", consumers=("worker", "web"),
                             section="自动发现", env="STA_DISCOVERY_MAX_PAGES",
                             desc="实测在播列表 ~49 房/页 → 1 万房 ≈204 页。旧默认 200 恰好卡在"
                                  "1 万房门槛(≈9800 房)会**静默截断**;400 ≈2 万房留一倍余量。"
                                  "护栏只防异常无限翻页,取大不产生额外请求;发现器重建钩子,下轮生效"),
    "discovery.page_concurrency": F(label="波次并发翻页", type="int", default=8, ge=1, le=64,
                                    hot=HOOK, hook="disc_rebuild",
                                    consumers=("worker", "web"), section="自动发现",
                                    env="STA_DISCOVERY_PAGE_CONC",
                                    desc="每波并发取几页。**串行翻页在 1 万房(204 页 × RTT 390ms "
                                         "≈99s)会超过发现锁 TTL(=遍历周期 60s),导致多副本并发"
                                         "重复遍历、把繁星打成惊群**;并发 8 → ≈12s。发现器重建钩子"),
    "discovery.request_timeout": F(label="单页请求超时", type="float", default=10.0,
                                   ge=1, le=120, unit="s", hot=HOOK, hook="disc_rebuild",
                                   section="自动发现", desc="发现器重建钩子,下轮生效"),
    "discovery.page_delay_ms": F(label="波次间礼貌间隔", type="int", default=0, ge=0,
                                 le=60000, unit="ms", hot=HOOK, hook="disc_rebuild",
                                 section="自动发现",
                                 desc="相邻两**波**(每波 page_concurrency 页)之间的停顿;**0 = 不停顿**。发现器重建钩子"),
    "discovery.warmup_window_ms": F(label="新发现房首抓窗口", type="int", default=60000,
                                    ge=0, le=600000, unit="ms", section="自动发现",
                                    env="STA_DISCOVERY_WARMUP_MS",
                                    desc="新发现房首次起抓错峰铺开(消除惊群);逐轮携入、即时生效"),
    "discovery.conn_limit": F(label="发现器连接上限", type="int", default=32, ge=1, le=512,
                              hot=HOOK, hook="disc_rebuild", section="自动发现",
                              desc="发现器 aiohttp 连接器并发上限;发现器重建钩子"),
    "discovery.batch_size": F(label="last_seen 单批行数", type="int", default=500,
                              ge=1, le=10000, section="自动发现",
                              desc="last_seen 落 PG(discovered_rooms)批量 upsert 单批;即时生效"),
    "discovery.prune_grace_s": F(label="离线回收 grace", type="int", default=604800,
                                 ge=-1, le=31536000, unit="s", section="自动发现",
                                 env="STA_DISCOVERY_PRUNE_GRACE_S",
                                 desc="发现房连续这么久未再出现在在播列表才回收(在播列表是"
                                      "推荐流,数日未上榜≠停播,故默认 7 天);**≤0 = 永不回收**。"
                                      "同时是核验台账(verified_rooms)的有效期:核验房最近一次"
                                      "确认在播距今超过它即清出台账,再添加须在开播时核验。"
                                      "逐轮携入、即时生效"),
    "discovery.verify_enabled": F(label="核验准入", type="bool", default=True,
                                  consumers=("worker", "web"), section="自动发现",
                                  env="STA_DISCOVERY_VERIFY_ENABLED",
                                  desc="在播列表是推荐流:频道房(roomType=3)从不上榜、低流量房"
                                       "常年不上榜,这类房后台没有开播记录,添加时会被拒。开启后"
                                       "「添加直播间」对后台不存在的房改经 roomStatus 核验:此刻"
                                       "在播即放行并记入核验台账;未开播/问不到分别明示。false = "
                                       "回到只允许添加后台已存在的房。即时生效"),
    "discovery.verify_interval_s": F(label="核验房复核周期", type="int", default=86400,
                                     ge=600, le=2592000, unit="s",
                                     consumers=("worker", "web"), section="自动发现",
                                     env="STA_DISCOVERY_VERIFY_INTERVAL_S",
                                     validator="verify_interval",
                                     desc="worker 按此周期复核台账里核验房的在播状态、刷新台账"
                                          "时钟(每房独立随机相位 0.75–1.25 倍)。策展态核验房"
                                          "直接复用直播状态探测的观测、发现态复用 last_seen,"
                                          "都不发请求;只有解绑后仍在台账里的房才真正探。取"
                                          "86400 = 每天一次:对每晚只播 3 小时的主播,7 天内"
                                          "至少命中一次的概率约 61%,漏判的后果仅是超期后要"
                                          "在开播时再添加;要更稳可调到 21600(每 6 小时)。"
                                          "循环内现读、下一拍生效"),
    "discovery.list_url": F(label="在播列表接口", type="str", default="", hot=HOOK,
                            hook="disc_rebuild", section="自动发现",
                            desc="覆盖列表接口地址(通常留空=用内置默认;上游变更时再改)"),
    "discovery.params": F(label="列表查询参数覆盖", type="json", default={}, hot=HOOK,
                          hook="disc_rebuild", section="自动发现",
                          desc="合并进默认查询参数的 JSON 对象(高级项,通常留空)"),

    # ═══ 直播状态(5.0.6:名录绿点 = 主播此刻是否在播;判据推导见 settings.LiveStatusCfg) ═══
    "livestatus.enabled": F(label="直播状态总开关", type="bool", default=True,
                            consumers=("worker", "web"), section="直播状态",
                            env="STA_LIVESTATUS_ENABLED",
                            desc="false = worker 不探测、web 不下发 live 字段(前端一律画"
                                 "「未知」灰环,绝不谎报未开播)。循环内现读、即时生效"),
    "livestatus.interval_s": F(label="探测周期", type="int", default=60, ge=5, le=3600,
                               unit="s", consumers=("worker", "web"), section="直播状态",
                               env="STA_LIVESTATUS_INTERVAL_S",
                               desc="兼作跨副本互斥锁 TTL;循环内现读、下周期生效"),
    "livestatus.fresh_s": F(label="观测保鲜期", type="int", default=90, ge=5, le=86400,
                            unit="s", section="直播状态",
                            desc="观测年龄超过它才值得再探。默认 90s = 在播列表遍历周期 60s "
                                 "+ 余量 —— 常驻在播列表的房恒由遍历顺手记录,永不消耗探测预算"),
    "livestatus.stale_s": F(label="观测有效期", type="int", default=600, ge=10, le=86400,
                            unit="s", consumers=("worker", "web"), section="直播状态",
                            desc="web 只在观测年龄 ≤ 它时下发 true/false,超出即 null(前端画"
                                 "「未知」)。worker 停摆/上游长断时**宁可说不知道,不谎报未开播**"),
    "livestatus.max_probe": F(label="单轮探测房数硬闸", type="int", default=300, ge=1,
                              le=5000, section="直播状态",
                              env="STA_LIVESTATUS_MAX_PROBE",
                              desc="每轮最多探这么多房(最旧优先轮转)。策展房超过它时分轮覆盖,"
                                   "代价是观测变陈 —— 陈过有效期即降为未知,不会撒谎"),
    "livestatus.concurrency": F(label="探测并发", type="int", default=16, ge=1, le=64,
                                section="直播状态",
                                desc="逐房 roomStatus 的并发上限(实测 16 并发探 60 房 ≈3.2s)。"
                                     "另经繁星令牌桶,与归一/遍历共用同一路礼貌闸"),
    "livestatus.request_timeout": F(label="单房探测超时", type="float", default=8.0, ge=1,
                                    le=60, unit="s", section="直播状态",
                                    desc="单房探测的**外层**天花板(繁星令牌桶等待 + HTTP 全算)。注意 HTTP 那一段另受 StarMeta 会话超时(6s)先兜住,故本项调到 6s 以下才会真正夹住 HTTP;超时按「问不到」处置:保留上次观测,绝不改判。它同时决定上游不可达时一轮的最坏耗时 = ⌈max_probe/concurrency⌉ × 本值(探测锁有续租心跳兜住)"),

    # ═══ hist-mode(3.5.0:后台发现房 GameHistory 轮询;仅影响发现房) ═══════════
    "histmode.enabled": F(label="后台轮询模式(hist-mode)", type="bool", default=False,
                          consumers=("worker", "web"), section="自动发现", danger=True,
                          env="STA_HISTMODE_ENABLED",
                          desc="true = 自动发现房退出实时管线(不再打 MainPage/RoundAward),"
                               "改为每 interval_s 一次 GameHistory 整页(近 30 局)批量入库:"
                               "万房稳态 430 → 默认 T=900 ≈11 req/s(T=300 ≈33)。策展房零改动。热更即时、迁移有机:"
                               "开=各房下一拍 mp(≤50s)原地改排轮询;关=下一拍轮询收尾回填后切回(最迟一个周期)"
                               "实时。danger:改变发现房数据到达节奏(≤interval_s 延迟)"),
    "histmode.interval_s": F(label="轮询周期", type="int", default=900, ge=60, le=1300,
                             unit="s", consumers=("worker", "web"), section="自动发现",
                             env="STA_HISTMODE_INTERVAL_S", validator="histmode",
                             desc="两次 GameHistory 之间的目标间隔。**硬约束:官方页窗固定"
                                  "近 30 局 ≈1500s,成功间隔一旦超过它,滑出页窗的局永久"
                                  "不可再取得**(仿真反例 T=1800s → 42 洞)。推荐 120–900;"
                                  "代码侧钳到 [60, 1300](scheduler.effective_hist_interval_ms,"
                                  "同 claim_grace 先例:打破不变量的配置不许借任何通道生效)。"
                                  "轮询任务逐拍现读:改动于各房**下一拍**生效(已排的到期时间不重排,"
                                  "最迟等一个旧周期;改小不会立即提前存量任务)"),
    "histmode.retry_base_s": F(label="失败退避基步", type="int", default=90, ge=10, le=600,
                               unit="s", section="自动发现", validator="histmode",
                               desc="轮询失败后 base×2ⁿ 退避的起步(90→180→cap 封顶)。"
                                    "票据过期(401)同走此阶梯 —— 不沿用任务层 +5s 重排"
                                    "(万房 401 期那是 2000 rps 锤击)"),
    "histmode.retry_cap_s": F(label="失败退避封顶", type="int", default=300, ge=30, le=900,
                              unit="s", section="自动发现", validator="histmode",
                              desc="退避阶梯的封顶值;与前瞻投影共同保证退避不会一跳越过"
                                   "抢救区(见 edge_after_s)"),
    "histmode.edge_after_s": F(label="越窗抢救线", type="int", default=1200, ge=300, le=1450,
                               unit="s", section="自动发现", validator="histmode",
                               desc="距上次**成功**轮询超过它 = 距页窗越界(≈1500s)仅"
                                    "~2 局:失败重试改用抢救节拍(edge_retry_s)密集尝试。"
                                    "**前瞻投影**:普通退避若会把年龄推过本线,提前切换 ——"
                                    "否则阶梯最后一跳(+300s)会直接跳出页窗、把本可挽回"
                                    "的数据推成永久丢失(复查修正 B 的实证算术)"),
    "histmode.edge_retry_s": F(label="抢救节拍", type="int", default=45, ge=15, le=120,
                               unit="s", section="自动发现", validator="histmode",
                               desc="进入抢救线后的重试间隔(±1/3 抖动去同步):越窗前"
                                    "恒有 ~6 次机会。真越窗后逐格登记「官方缺失」止损并"
                                    "计入 stats:histmode.window_lost(状态页可见,绝不静默)"),

    # ── curated-idle(3.7.0:空闲策展房降级;shadow 先行。不挂 histmode 语义
    #    校验器 —— 四键与页窗算术无交叉约束,判闲阈值/批量各自 ge/le 已足) ──
    "histmode.curated_idle_enabled": F(
        label="空闲策展房降级", type="bool", default=False,
        consumers=("worker", "web"), section="自动发现", danger=True,
        env="STA_HISTMODE_CURATED_IDLE", depends="histmode.enabled=true 时生效",
        desc="true = 名录里**近期无人访问**的策展房也降级为 GameHistory 轮询。"
             "判闲=最近访问年龄≥curated_idle_after_s 且该房 SSE 零订阅(观众一票"
             "否决;年龄未知只播种不判闲)。冷房仍在名录/前端可见,预测暂停(权重"
             "冻结不损坏);任意一次真实访问(history 非 passive/days/prediction/"
             "summary/coverage/SSE)当场唤醒:清标+mp@now+hs 封尾,预测号随补链"
             "立即再生(monitor/add 转正同款)。danger:降级期间该房数据到达延迟"
             "≤interval_s、预测记录出现空窗"),
    "histmode.curated_idle_shadow": F(
        label="降级影子模式", type="bool", default=True,
        consumers=("worker", "web"), section="自动发现",
        depends="curated_idle_enabled=true 时生效",
        desc="true = 只观测不动作:把「本会降级的房集」写进 stats:histmode"
             "(cold_would/cold_would_sample)与 /api/crawler/status 的"
             "histMode.curatedIdle 块,供核对是否吻合运维直觉;false = 真正执行"
             "降级(enforce)。灰度纪律:先 shadow 跑一阵,确认 wouldDemote 全是"
             "真僵尸、falseWake 恒 0 后再翻"),
    "histmode.curated_idle_after_s": F(
        label="判闲阈值", type="int", default=1800, ge=300, le=86400, unit="s",
        section="自动发现", depends="curated_idle_enabled=true 时生效",
        desc="策展房最近一次真实访问距今 ≥ 该值才成为降级候选。SSE 心跳每 20s"
             "刷新访问时戳 —— 开着直播视图的房年龄恒 <20s,永不达阈。保守起步"
             "1800(30 分钟):误降代价(回来那一拍最多看到 interval_s 陈旧)"
             "远大于多跑半小时实时的代价"),
    "histmode.curated_idle_batch": F(
        label="单扫降级上限", type="int", default=200, ge=1, le=5000,
        section="自动发现", depends="curated_idle_enabled=true 时生效",
        desc="每次扫描(全舰队锁内 ≤1 次/分钟)最多标记的房数 —— 「整夜集体"
             "空闲」的削峰护栏。标记后各房于**自己的下一拍 mp**(≤50s,相位"
             "天然铺开)经既有 3.5.0 迁移入口改走轮询,首拍再叠 U(0,T) 满窗"
             "抖动 —— 结构上无风暴,batch 只是额外保险"),

    # ═══ 预测引擎(原引擎 PredictionConfig 逐字段透传,不改算法;下方循环登记) ═══
}

# 预测参数逐项登记(紧凑写法:统一经 _pred 构造)。
for _k, _f in (
    _pred("enabled", "启用预测", "bool", True, "false = 不生成预测(抓取照常入库)"),
    _pred("recent_window", "近窗长度", "int", 60, ge=1, le=5000, unit="局"),
    _pred("ewma_half_life", "EWMA 半衰期", "float", 30.0, ge=0.1, le=10000),
    _pred("markov_shrink", "一阶马尔可夫收缩", "float", 6.0, ge=0, le=1000),
    _pred("markov2_shrink", "二阶马尔可夫收缩", "float", 4.0, ge=0, le=1000),
    _pred("omission_gamma", "未出场项 γ", "float", 0.5, ge=0, le=10),
    _pred("hedge_eta", "Hedge η", "float", 0.15, ge=0, le=10),
    _pred("hedge_mix", "Hedge 混合", "float", 0.02, ge=0, le=1),
    _pred("max_train", "训练样本上限", "int", 5000, ge=10, le=1000000, unit="局",
          validator="retention_vs_train",
          desc="与 train_window_hours **串联**:取数先按时间窗切,再被 seq[-max_train:] "
               "截尾。小于窗口局数(≈train_window_hours×72)时窗口被**静默截短**,"
               "改了窗口等于没改。24h≈1728 局,故默认 5000 从未生效;窗口一旦越过 "
               "69.4h 它就开始截。管理台保存时会就此告警,worker 启动/热更时亦有同款护栏。"
               "「从未生效」已由逐局比对钉死(4.9.5 审计,自带三房库 12,064 局):"
               "max_train=5000 / 1728 / 10^7 三档在 24h 窗下**逐局记录 0 差异**。"
               "另:tw=0(不限时间)+ max_train=N 与 tw=N/72 小时 + max_train=∞ 亦"
               "**逐局 0 差异**(连续数据上二者是同一件事的两个名字);断流场景下"
               "前者保住满训练集、后者会塌到断流后的新局数 —— 需要抗断流时用前者"),
    _pred("train_window_hours", "训练时间窗", "float", 24.0, ge=0.0, le=8760, unit="h",
          validator="retention_vs_train",
          desc="训练序列只取近 N 小时。**0 = 不限时间**,退回 max_train 计数窗"
               "(这正是 max_train 告警里推荐的表达方式;4.9.5 前注册表下限写成 0.1,"
               "告警教的路管理台自己堵死,现已放开)。0 与 (0,3) 是两回事:"
               "**(0,3) 区间被语义校验拒绝** —— 3h≈216 局,而 frontier 的 LP 概率口径"
               "要 400~864 局才收敛,窗口再短等于让引擎在近均匀先验上解方案。"
               "真机实测(三房 36,278 局、公平域配对 McNemar):0.1h=49.03%、"
               "0.2h=45.69%(四选九随机基线 44.44%)、1h=50.80%;"
               "3~48h 之间任意取值与 24h **统计不可区分**(12h p=0.826、6h p=0.220、"
               "48h p=0.305),72h(p=0.050)与不限时间(p=0.027)**显著更差**。"
               "即 24h 落在一段宽平台的中部,不是唯一最优点,但有充分余量 ——"
               "缩短只省 CPU(单局 3.46ms→2.01ms@12h)、同时按比例削掉抗断流余量,"
               "无准确率收益(分房与时间二分复核中符号翻转,属噪声)。"
               "【4.9.9 在现行 4.9.8 刻度下重扫,候选补到 168h】上面那组数字测于旧刻度"
               "(fr_share_floors 非空),现行公平域基线是 54.95%,旧值只能当历史读。"
               "11 个候选窗 × 三房全量回放(公平域 n=20,720)对 24h 的净差:3h -0.07 / "
               "6h -0.40 / 12h -0.45 / 48h -1.03 / 72h -1.64 / 96h -0.63 / 120h -0.83 / "
               "144h -0.54 / 168h 与不限时间 -0.29(pp)—— **十个候选全部为负,无一能改进 "
               "24h**;但 10 次比较的 Bonferroni 阈 α=0.005 下只有 72h 过线,且改用「200 局"
               "一块」的整块配对检验(纠正 LP 每 fr_replan=200 局才重解带来的序列相关)后,"
               "连 72h 的符号检验也只有 p=0.024 ⇒ 诚实说法是「无一候选能改进 24h」,"
               "不是「24h 显著最优」。96h 以上另有两条硬约束:①自带库跨度 167.98h,"
               "168h 窗与不限时间**逐局 0 差异**(36,182 局),在本数据上不可测;"
               "②生产 max_train=5000≈69.4h 会把它们静默截短 —— tw=168h/mt=5000 与 "
               "tw=0/mt=5000 逐局 0 差异,而同窗 mt=5000 vs ∞ 差 46.73% 的局"),
    _pred("accuracy_window", "命中率统计窗", "int", 100, ge=1, le=100000, unit="局",
          desc="近 N 局命中率的窗口。4.6.0 起该窗以**最新一局**为锚做区间约束"
               "(旧实现是『最近 N 条判定行』,预测链中断过就会把几天前的旧行"
               "当成近 N 局展示);同时它也是补算要填满的窗口"),
    _pred("replay_enabled", "命中率补算", "bool", True,
          desc="房间转正为策展房时,用生产同一条代码路径、严格因果地把窗口内缺的"
               "命中判定补齐(source='replay',单独计数、前端显式标注)。"
               "关掉 = 只有实盘攒出来的判定,新房命中率从空白起步、约 83 分钟才满窗"),
    _pred("replay_warmup", "补算热身", "int", 400, ge=0, le=5000, unit="局",
          desc="目标局之前至少要有这么多次预测才允许写补算行,不足则整条丢弃。"
               "真机实测还原度:热身30局→判定81~84%还原、命中率偏差达6pp;"
               "100局→89~93%/5pp;200局→96~99%/≤1pp;400局→98~99%/≤1pp。"
               "调小=窗口填得快但数不可信,不建议低于 200"),
    _pred("replay_interval_s", "补算巡检周期", "int", 60, ge=5, le=3600, unit="s",
          desc="补算协程多久扫一轮(兼跨副本互斥锁 TTL,全舰队每周期恰一个副本在算)。"
               "新加的房最迟这么久后开始补算"),
    _pred("replay_batch", "补算每轮房数", "int", 8, ge=1, le=200, unit="房",
          desc="每个巡检周期最多为几个房跑补算 —— CPU 闸门。单房约 2.4s"
               "(热身400+窗100+24h训练窗,真机实测),默认 8/60s ≈ 32% 单核峰值,"
               "且只在房间新入名录时发生。另有墙钟闸兜住:逼近跨副本锁到期即收手"
               "批量加数千房时调大可加快回填,代价是抢 worker 的执行力"),
    _pred("replay_cooldown_s", "补算每房冷却", "int", 3600, ge=60, le=86400, unit="s",
          desc="同一房两次补算探查的最小间隔。稳态下全部房都在冷却中 ⇒ 巡检开销"
               "收敛为一次 SMEMBERS + 零 SQL。转正/唤醒会当场清掉该房的冷却"
               "(4.9.3 起并走秒级唤醒快道:打开冷房数秒内补满 —— 排水节拍 ≤1s + 单房补算 ≈2.4s,24h 满窗真机实测 ≈5s;不再等巡检);"
               "补算异常走 5 分钟短退避而非吞掉整段冷却"),
    _pred("freq_anchor", "频率锚定", "bool", True),
    _pred("anchor_window", "锚定窗口", "int", 80, ge=1, le=100000),
    _pred("anchor_drift_floor", "锚定漂移下限", "float", 0.15, ge=0, le=1),
    _pred("anchor_drift_ref", "锚定漂移参考", "float", 0.3, ge=0, le=1),
    _pred("anchor_lambda_min", "锚定 λ 下限", "float", 0.05, ge=0, le=1),
    _pred("predict_mode", "预测模式", "str", "adaptive",
          "已知取值:adaptive / ceiling(自由串透传原引擎)"),
    _pred("adaptive_lambda", "自适应 λ", "float", 0.3, ge=0, le=1),
    _pred("explore_every", "巡逻步频", "int", 6, ge=1, le=1000),
    _pred("explore_patrol", "巡逻窗口", "int", 35, ge=1, le=100000),
    _pred("explore_min_z", "巡逻最小 z", "float", 0.5, ge=0, le=100),
    _pred("explore_z0", "巡逻 z0", "float", 0.8, ge=0, le=100),
    _pred("explore_calib", "巡逻标定窗", "int", 240, ge=1, le=1000000),
    _pred("explore_rhythm_w", "节奏权重", "float", 0.2, ge=0, le=10),
    _pred("explore_style", "巡逻风格", "enum", "frontier",   # 4.9.8 由 "showcase" 改
          "budget / norm_cold / matched / showcase / ceiling_adaptive(引擎既有五式;"
          "ceiling_adaptive = 引擎 dataclass 默认值,实现即 predict() 的最终 else 分支)"
          "+ frontier(天花板前沿调度,4.8.0 新增)。"
          "⚠ 引擎对未知取值是**静默兜底**(落到通用冷门探索分支)而不是报错,"
          "所以这里必须是 enum、且新增风格必须同批登记,否则运维会以为改生效了其实没有。",
          choices=("budget", "norm_cold", "matched", "showcase",
                   "ceiling_adaptive", "frontier")),
    # ── 天花板前沿调度(frontier)刻度;机制与实测依据见 config.yaml 同名段 ──
    # ⚠⚠ 4.9.8:下面三条由 0.0 改为 0.116633 / 0.01683 / 8.358387,同批 fr_share_floors
    #   由出厂地板串改为空串 —— 三层(引擎 dataclass / config.yaml / 本表)必须同值,
    #   由 tests/test_config_registry.py 的
    #   test_registry_defaults_match_config_yaml_for_all_prediction_keys 钉守。
    #   刻度来源不是拍脑袋:先用 δ=0(下限=切换前 showcase 实测值)跑一遍量欠达比
    #   (迭代两步),再按欠达比反解;定稿依据是严格样本外协议。依据与实测见 config.yaml 同名段。
    # ⚠ 下面三条 4.9.7 曾由 0.1232 / 0.0180 / 8.624 对齐为 0.0 —— 引擎 dataclass 与
    #   config.yaml 从 4.9.0 起就是 0.0(改由 fr_share_floors 逐号钉份额),只有本表
    #   停在 4.8.9 旧值,**三层各持一值**。注册表 default 是「重置/回落基线」的取值
    #   来源(config_center.apply_snapshot 的 `b.get(key, f.default)`),漂了会让管理台
    #   上「默」印所示与实际生效值不是一回事,并可能把休眠的聚合下限重新激活。
    _pred("fr_cold_min", "前沿·冷门命中下限", "float", 0.116633, ge=0, le=1,
          desc="冷门(showcase_cold_ids)命中率下限。4.9.8 启用(0.0→0.116633):清空 "
               "fr_share_floors 后改回聚合下限口径。取值 = 欠达比反解迭代两步 + 严格样本外协议选定"
               "(前2/3选优→后1/3验证,20 候选里唯一两段都满足四项全不劣的)。"
               "历史:4.9.0~4.9.7 置 0(改由逐号地板钉);4.8.9 旧值 0.1232"),
    _pred("fr_rare_min", "前沿·稀有命中下限", "float", 0.01683, ge=0, le=1,
          desc="稀有(fr_rare_ids)命中率下限。4.9.8 启用(0.0→0.01683),同 fr_cold_min 同批定标。"
               "历史:4.9.0~4.9.7 置 0;4.8.9 旧值 0.0180"),
    _pred("fr_ret_min", "前沿·每注回报下限", "float", 8.358387, ge=0, le=1000,
          desc="每注回报下限。4.9.8 启用(0.0→8.358387),同 fr_cold_min 同批定标。"
               "⚠ 本组最敏感的一条:同房只把它从 8.2769 挪到 8.35,总命中就掉 1.0pp "
               "(54.750→53.722)—— 改它必须三房全量重跑,不许只看单房单点。"
               "历史:4.9.0~4.9.7 置 0(实测它只由 6/7/8 号顶掉,且恰是把稀有钉死的那根钉子);"
               "4.8.9 旧值 8.624"),
    _pred("fr_share_min", "前沿·每号份额下限", "float", 0.08, ge=0, le=0.25,
          desc="每个号至少要占多少比例的四码。**不要设 0** —— 设 0 时 LP 会让不在\n          当前方案里的号连续几百上千局不出现(实测号9 最长 4273 局≈59 小时),\n          与它最近开没开出无关。0.05 即可把最长连续不推压到 39 局且四项指标不劣"),
    _pred("fr_share_max", "前沿·每号份额上限", "float", 0.8, ge=0.45, le=1,
          desc="数学下界 4/9≈0.4444(每局用掉 4 个号 ⇒ 九号份额之和恒为 4);"
               "配到该值以下必然不可行,规划器会自动放宽并在 why 落款里记录"),
    _pred("fr_main_share_min", "前沿·主位份额下限", "float", 0.08, ge=0, le=0.25,
          desc="0=主位恒取四码中 p̂ 最高的两只(低频号 3/4/9 会**永远进不了主位**,真机实测主位饥饿达全程 4273 局);>0 启用主位赤字轮转,代价是主中率下降"),
    _pred("fr_replan", "前沿·重规划周期", "int", 200, ge=0, le=1000000, unit="局"),
    _pred("fr_rare_ids", "前沿·稀有池", "str", "3,9",
          "逗号分隔的 2 个自定义编号;非法值回落 3,9"),
    _pred("fr_mult", "前沿·号位倍率表", "str", "",
          "形如 1:10,2:50,…;留空由妖兽表推导。改过 custom_beast_ids 必须同批显式填写"),
    _pred("explore_abstain", "巡逻弃权阈", "float", 0.12, ge=0, le=1),
    _pred("explore_tie_eps", "并列容差", "float", 0.004, ge=0, le=1),
    _pred("seat_order", "座次口径", "str", "recency", "已知取值:recency 等(自由串透传)"),
    _pred("main_swap_band", "主推互换带", "float", 0.02, ge=0, le=1),
    _pred("fr_share_floors", "逐号份额地板", "str", "",   # 4.9.8 清空(原 "3:0.40,9:0.30,4:0.20,5:0.20,6:0.20")
          "格式 \"号:份额,…\"(份额 0~1)。聚合下限(冷门/稀有/回报)总被最便宜的成员满足、"
          "钉不住具体号 —— 三房 36,278 局实测:只加 ret>=8.624 时 s3=s9=0.08;"
          "fr_cold_min 的 81% 由 5/6 号贡献。要保某号露面只能直接钉它自己的份额。"
          "地板不含 p-hat,份额是保证值而非估计值。空串=与 4.8.9 逐局字节级等价。"
          "⚠ 4.9.8 出厂清空:出厂地板硬钉号9(实测 p=3.561%,九号最低)进 30% 的局、"
          "号3 进 40%,把 LP 自由度吃光 —— 这正是 4.9.7 判 frontier 落败的真因。"
          "清空后露面下限由 fr_share_min=0.08 兜底,实测逐号最长不进四码 30 局,"
          "优于 showcase 的 46 局。要恢复地板必须同批把三条聚合下限清回 0(否则是混合态)。"),
    _pred("prior_shrink", "冷启动自适应收缩", "bool", False,
          "只作用于 explore_style=frontier 的概率口径。关=逐局字节级退回 4.9.3 "
          "(概率 = 归一化(计数+2.0),即 18 局的**均匀分布**先验)。真机三房 36,278 局"
          "实测:均匀先验在房间刚起抓时(n≈30~200)占 10%~37% 权重,把 p-hat 拽向 "
          "11.11%/号,LP 落到错误顶点且被 fr_replan 拖住 200 局 —— 冷启动期望命中 "
          "49.30%(本身就在 50% 以下),要到第 400~450 局(约 6 小时)才回稳态 53.00%。"
          "开启后 n=10 即贴天花板(仿真 150x:-4.305pp → +0.000pp)。"
          "⚠ 出厂缺省 False。4.9.4 给的理由是「实测 +0.03/-0.27/-0.62pp 三房同向偏负,"
          "与期望命中口径(+2.53pp 冷启动)打架,现有样本判不出孰真」。"
          "【4.9.9 在现行 4.9.8 刻度下用四张先验表重测,那个「打架」已消失 —— 两个口径"
          "同向为负】三房 36,182 局全量回放,合计净差:出厂表(样本内)-0.420pp(p=0.200)、"
          "留一房表 -0.685pp(p=0.037)、本房前 72h 拟合 -0.213pp(p=0.513)、"
          "官方公示表 -1.097pp(p=0.0002);限定在真正样本外的域(elapsed>=72h)四张表仍全负。"
          "分段看:冷启动 30~450 局 +2.78/+0.64pp 但 p=0.12/0.75 **不显著**且分房符号翻转,"
          "稳态 idx>=1728 则 -0.634pp(p=0.073)/ -0.849pp(p=0.017)。"
          "机理见 prior_table 说明:lambda 在稳态并不退场 ⇒ 收益上限只覆盖 3.5% 的局,"
          "代价覆盖 100% 的局。**净负是结构性的,不是样本不够** —— 维持关闭。"),
    _pred("prior_table", "先验概率表", "str",
          "1:0.183748,2:0.156955,3:0.049286,4:0.065246,5:0.093307,"
          "6:0.096725,7:0.157203,8:0.161916,9:0.035614",
          "格式 \"号:概率,…\",九项须全为正且和在 [0.98,1.02];不合格=静默关闭收缩"
          "(热更写坏只让优化失效,不让 predict 崩)。默认值=真机三房 7 天 36,278 局"
          "**实盘**频率,不是官方公示表 —— 二者 chi2=726.6 p~0(9号 500x 实盘 3.56% "
          "vs 公示 2.00% z=+21.2)。收缩权重 lambda 由数据自解:先验对则 lambda→1,"
          "先验错则数据一撑起来 lambda 自动塌向 0。"
          "⚠【4.9.9 更正】原文接着写的「n→∞ 时 lambda→0」**是错的**:n→∞ 的极限取决于"
          "先验对不对 —— p0=真分布时分母期望恰好趋近分子 ⇒ **lambda→1,收缩永不退场**;"
          "只有 p0 错时分母才随 n 线性发散 ⇒ lambda→0。数值实证(数据由 p 生成、p0=p):"
          "n=10^3/10^4/10^5/10^6 的 lambda 中位数恒为 1.000、均值 0.85~0.94;"
          "换成官方公示表当 p0 时 n=10^3/10^4/10^5 才依次给出 0.542/0.104/0.011。"
          "真机三房逐局实测(24h 窗)中位数 1.000、全期均值 0.82~0.86、lambda=1.0 占 45~58%。"
          "⇒ 本项不是「冷启动收缩」,是**全程生效的固定表覆盖**;这半句错话会让人"
          "误判稳态无风险,而实测代价恰恰全在稳态段。"),
    _pred("showcase_q", "showcase 分位", "float", 0.78, ge=0, le=1,
          desc="⚠【当前无任何消费方,改它不会有任何效果】引擎 PredictionConfig **没有**"
               "这个字段,桥构造那句 `if k in pc_fields` 会把它整个滤掉;全仓 grep 只剩"
               "本注册表 / config.yaml / 两个引擎 JSON / 测试夹具里的赋值。属存量遗留,"
               "由 tests/test_config_registry.py::"
               "test_every_registered_prediction_key_has_a_consumer 显式登记在案,"
               "计划单独一轮从 PREDICTION_KEYS 与 config.yaml 同批删除。"
               "(历史语义:showcase 冷位入选的分位阈值)"),
    _pred("showcase_kdist", "showcase K 分布", "csvnums", "35,40,15",
          "**恰好**带 1/2/3 只冷门的目标份额(%),逗号分隔;引擎实际使用的是 cums "
          "= k≥1/k≥2/k=3(本值 90/55/15,达成份额实测逐位跟踪)。⚠ 4.9.10 语义"
          "澄清:历史描述「k>=1/k>=2/k>=3 的目标份额」指的是 cums,三个原始数是"
          "恰好档。取值史:45,30,15 → 4.9.7 45,31.5,13.5(自然份额中性点,为让"
          "节拍器不夹带份额变更)→ 4.9.10 本值。改值依据:十一档全量扫描(三房 "
          "34,982 成熟配对局,生产代码路径逐局因果回放)证明 kdist 是「命中↔回报」"
          "单调权衡曲线上的取点、旧默认非任何指标最优;本值以四码命中 −1.12pp"
          "(53.73→52.61%, McNemar p=1e-4)换 回报/注 +2.7%(8.230→8.449)、"
          "冷门中 +1.09pp、稀有中 +0.20pp;满足产品 4.9.8 三条下限(冷门≥11.66%/"
          "稀有≥1.68%/回报≥8.358)的共五档(本值/40,35,20/30,38,27/25,40,30/"
          "0,0,95),本值是其中四码命中最高的一档(=下限约束下的命中最优),6/6 "
          "时间×房间切片同号。全表与复跑脚本见 window_audit/AUDIT-4.9.10-showcase-kdist-"
          "全档扫描.md。⚠ 本键在节拍器**关态也读**(决定 k 的判定阈值),开态"
          "令牌桶滴水速率就是它的 cums ⇒ 完整回滚到原版必须两键同批:"
          "cadence_governor→false 且本键→45,30,15(引擎解析失败的静默兜底也是"
          "这组关态刻度,刻意不随默认值走)。仅在 explore_style=\"showcase\" 域内"
          "生效;当前默认风格 frontier 下本键休眠"),
    _pred("matched_window", "matched 窗口", "int", 30, ge=1, le=100000),
    # ── 反固执改造(《灵机推演反固执优化方案.md》;真机全量因果回放定稿刻度)──
    _pred("anti_stubborn", "反固执总开关", "bool", True,
          "false = 与旧引擎逐局字节级等价(改造期全量回放已验);true = 启用连败压力/"
          "在位惯性/熔断换血/k 死区/冷位老化五机制。回滚只需关此开关,状态新字段留存无害"),
    _pred("as_alpha", "连败压力·集合", "float", 0.08,
          "集合选择端压力强度(exp(-α·pen),受 mcap 封顶 ⇒ EV 有界)", ge=0, le=2),
    _pred("as_alpha_ord", "连败压力·座次", "float", 0.14,
          "座次排序端压力强度:只轮转主/防标签,不动四码集合,零 EV 成本", ge=0, le=2),
    _pred("as_mcap_hot", "热池削发上限", "float", 0.12,
          "热池号集合分被压的最大比例;0.12 保号 1 恒驻四码(防 v1 式 EV 塌方)", ge=0, le=1),
    _pred("as_mcap_cold", "冷池削发上限", "float", 0.18,
          "冷池号集合分被压的最大比例(0.30 曾在验证房过拟合 −1.7pp)", ge=0, le=1),
    _pred("as_gamma", "在位惯性", "float", 0.15,
          "上局四码成员加成(赢家恒推·抑制 A→B→A 回摆)", ge=0, le=1),
    _pred("as_pen_cap", "压力封顶", "int", 8, ge=1, le=64),
    _pred("as_pen_on_hit", "命中局也累积", "bool", False,
          "false = 只在四码整体未中时累积压力(赢局不摇席;定稿语义)"),
    _pred("as_breaker", "连败熔断阈", "int", 3,
          "同四码连败达阈值即强制换血一席(0=关)⇒ 同四码原地连败硬上限", ge=0, le=32),
    _pred("as_khyst", "k 分位死区", "float", 0.05,
          "冷位数 k 的判定滞回带,抑制逐局重估抖动", ge=0, le=0.5),
    _pred("as_cooldown", "熔断再入冷却", "int", 0,
          "熔断换出号的再入冷却局数(实测负收益,默认 0=关;留作应急开关)", ge=0, le=64),
    _pred("as_beta", "冷位老化", "float", 0.3,
          "冷位久未入选的老化加成(打破 5/6 垄断,受 agecap 有界)", ge=0, le=4),
    _pred("as_agecap", "老化封顶", "int", 24, ge=1, le=1000, unit="局"),
    # ── 冷位份额闭环·赤字调度(《灵机推演冷位垄断优化方案.md》;真机全量回放定稿)──
    _pred("showcase_rotate", "冷位份额轮换", "bool", True,
          "false = 与改造前逐局字节级等价(改造期全量回放已验);true = 给「带哪几只冷门」"
          "加份额闭环(目标份额 ∝ p^eta,赤字账本驱动)+ 同四码连推硬帽。"
          "回滚只需关此开关,状态新字段(dbt/rep)留存无害"),
    _pred("sc_eta_cold", "冷池份额指数", "float", 1.0,
          "冷池目标份额 ∝ p^eta:1=按真实概率分配(定稿)、0=五个冷号均分、"
          "<0=向高倍率号倾斜、>=8≈退回原版 argmax。实测 η≤0.5 命中率显著下滑",
          ge=-4, le=32),
    _pred("sc_eta_hot", "热池份额指数", "float", 20.0,
          "热池同构指数;20≈冻结热位(=保持现行行为,定稿)。调低即让号1 让出首位:"
          "实测 η=2 号1 占比 100%→88.9%(单号最长连续 1365→346 局,−1.63pp 命中, "
          "p=0.070)、η=0 →62.8%(单号最长 17 局,−2.13pp, p=0.030, 四码回报 "
          "31.12→33.55u)—— 属产品取舍,默认不动",
          ge=-4, le=32),
    _pred("sc_floor_cold", "冷号份额下限", "float", 0.08,
          "每个冷号在冷位里的份额下限,防某号因概率过低被永久挤出(超过 1/5 自动收敛到 1/5)",
          ge=0, le=0.2),
    _pred("sc_floor_hot", "热号份额下限", "float", 0.0,
          "热池同义下限(超过 1/4 自动收敛到 1/4);热池冻结时无实际作用", ge=0, le=0.25),
    _pred("sc_lambda", "赤字强度", "float", 0.6,
          "赤字→打分的乘性强度 exp(λ·debt)。实测 0.3 欠调(邻局全同 9.0%)、"
          "1.2 过调(−1.99pp 命中);0.6 为定稿。0 = 只保留连推硬帽", ge=0, le=4),
    _pred("sc_debt_cap", "赤字截断", "float", 4.0,
          "赤字绝对值上限,同时是账本本身的抗积分饱和钳位 ⇒ EV 失真解析上界 "
          "exp(λ·cap);0.6×4 ≈ 11×,足以翻转冷池内最大 3.9× 的概率差而不至于失控。"
          "不钳位时不可满足的目标份额会让赤字线性发散(真机 1,700 局实测号1 +2453)",
          ge=0, le=32),
    _pred("sc_repeat_cap", "连推硬帽", "int", 3,
          "同一四码集合连推达此局数即强制换血一位(与 as_breaker「连败才换」互补:"
          "这条是「连推就换」,不看输赢)。同池无可换对象时跨池换血。0=关。"
          "实测 2 与 5 均劣于 3", ge=0, le=32),
    _pred("sc_beta_off", "轮换时关老化", "bool", True,
          "true = showcase_rotate 开启时把 as_beta(冷位老化)置零 —— 它与赤字账本"
          "功能重叠,同开等于双重加权。改 false 可两者同开(实测差异在噪声带内)"),
    _pred("sc_fp_depth", "预测指纹深度", "int", 12,
          "predict() 幂等指纹取序列末 N 局。原版 N=3 不是局唯一:末 3 局同号且训练窗"
          "长度不变即整局复用上一局输出并跳过状态推进(真机回放实测存在过碰撞并因"
          "状态发散波及后续局)。N=12 后碰撞概率 →0。<=3 即原版行为", ge=3, le=64),
    # ── 冷位节拍器(4.9.7 补登记;域判定 = 开关 且 explore_style == "showcase")──
    _pred("cadence_governor", "冷位节拍器", "bool", True,
          "false = 与未改造的 showcase 逐局字节级等价(12,064/12,064 已实测);"
          "true = 用令牌桶把冷位数 k 的**时间结构**摊平。病灶:k 由近窗热度自参照"
          "分位判定,而热度是长记忆量(M2 窗 60 局 / EWMA 半衰 30 局),叠加 as_khyst "
          "的双边死区 ⇒ 边际份额达标但成串。三房 36,182 局实测(开 vs 关):k=3 逐局"
          "黏滞率 40.54%→0.02%(独立期望 13.4%)、k>=3 最长连串 29→2 局、20 局窗内"
          "最大三冷 20→4;总命中 −0.10pp、倍率加权/注 +0.0086。滴水速率**就是** "
          "showcase_kdist 的 cums ⇒ 边际份额守恒,对命中率期望零影响。"
          "⚠ 与 showcase_kdist 必须成对:开=35,40,15(4.9.10 起;4.9.7~4.9.9 为 "
          "45,31.5,13.5),关=45,30,15;只翻开关不翻刻度是未经部署审计的中间态"
          "(4.9.7 实测,当时开态刻度 45,31.5,13.5:只关开关与改造前基线仅 "
          "5,162/12,064 局相同)。上面那组开关 A/B 为**各自配对刻度**下的实测"
          "(开=45,31.5,13.5 / 关=45,30,15);节拍器机理(滴水速率=cums ⇒ 边际"
          "份额守恒)与刻度无关。4.9.10 审计对帽约束的复核在极端刻度 0,0,95 上"
          "做出:达成份额被 cg_run2/cg_run3 精确钉在 k≥2=6/7=85.7%、k=3=4/7="
          "57.1%(帽算术逐位吻合);新默认 35,40,15 的 k=3 目标 15% 距帽甚远,"
          "硬帽率实测 0.00%,机制零打架"),
    _pred("cg_run3", "三冷最长连串", "int", 2,
          "k>=3 允许的最长连续局数(硬不变量,由令牌桶守恒保证)", ge=1, le=64, unit="局"),
    _pred("cg_run2", "双冷最长连串", "int", 6,
          "k>=2 允许的最长连续局数", ge=1, le=64, unit="局"),
    _pred("cg_cap3", "三冷桶容量", "float", 1.9,
          "三冷令牌桶容量 ⇒ 任意 W 局内 k=3 的局数 <= rate3*W + cap3(与数据无关的上界)",
          ge=0, le=32),
    _pred("cg_cap2", "双冷桶容量", "float", 3.2,
          "双冷令牌桶容量 ⇒ 任意 W 局内 k>=2 的局数 <= rate2*W + cap2", ge=0, le=32),
    _pred("cg_force3", "三冷软促发阈", "float", 1.5,
          "三冷桶攒到此值即主动推一次三冷(防止冷门旱段过长)", ge=0, le=32),
    _pred("cg_force2", "双冷软促发阈", "float", 1.8,
          "双冷桶的同义阈值", ge=0, le=32),
    _pred("cg_rfloor", "硬保底余量", "float", 0.30,
          "硬保底触发的「距桶满余量」(阈 = cap - rfloor,并不低于 force)。"
          "⚠ 该键语义在本包内为**推断**:原方案文档缺失,tests/test_cadence_governor.py "
          "对它零断言;其余四个机制均有钉守。找回文档后请优先以文档为准复核",
          ge=0, le=32),
    _pred("showcase_cold_ids", "冷池成员编号", "csvnums", "3,4,5,6,9",
          "冷池的自定义编号(恰好 5 个 1~9 的不重复号),热池=其余 4 个。原引擎把它硬编码"
          "在 showcase/matched/熔断三处,与可配置的 custom_beast_ids 脱钩 —— 换编号映射"
          "即整套冷热判定错位。改 custom_beast_ids 必须同批改这里:它须等于该映射下"
          "倍率最高的 5 只妖兽编号(有 CI 钉守)。非法值回落 3,4,5,6,9"),
    # ── 重现观察期(《灵机推演重现观察期优化方案.md》;三房 7 天 36,278 局定稿)──
    _pred("repeat_guard", "重现观察期", "bool", True,
          "false = 与原版逐局字节级等价(三房 36,188/36,188 已验);true = 「当下稀有」"
          "的号(24h 滑窗频率 ≤ rg_pmax)刚开出后的 ceil(θ/p̂) 局内(封顶 rg_cap)不再"
          "自由入选/升主位。实地核查 36,278 局证明九兽危险率对间隔全平坦,刚出后的"
          "M2/M3 概率飙升没有预测力 ⇒ 推迟统计等价、观感不再「刚开完 500x 立刻又推它」"
          "(34,982 局配对:刚出仍带 3/4/9 号 498/749/291→16/93/0、主位 628→67,命中"
          "+0.04pp p=0.833 纯噪声)。份额由赤字账本照常补发,保底不受约束;回滚只需"
          "关此开关,无新增状态字段"),
    _pred("rg_theta", "观察期系数", "float", 0.35,
          "观察期长度 = ceil(θ/p̂) 局(θ 为该号典型回归间隔 1/p̂ 的占比)。"
          "实测 0.25/0.35/0.50 命中差在噪声带内,0.35 为定稿", ge=0, le=2),
    _pred("rg_cap", "观察期封顶", "int", 20,
          "观察期硬上限;当前频率下 L(9)=ceil(0.35/0.036)≈10 已低于封顶,cap 是"
          "频率骤降时防观察期失控的安全阀", ge=1, le=200, unit="局"),
    _pred("rg_pmax", "受约束频率上限", "float", 0.075,
          "「当下稀有档」:24h 滑窗频率 ≤ 此值的号才受观察期约束。330x/500x(频带"
          "3.1~6.3%/2.7~4.7%)全时段在罩内;4/5/6 号(频带 5.0~8.3%/7.4~11.7%/"
          "6.5~12.7%)按实时稀有度自适应进出。九兽危险率全平坦 ⇒ 罩谁都零 EV 成本。"
          "历史注:旧样本(已退役)曾为 4 号真扎堆把默认定过 0.05 豁开,7 天大样本"
          "不复现(紧随 6.63%≈基率 6.52%,z+0.2,N=2367),时段性扎堆改由四关豁免"
          "按窗放行,默认收敛为 0.075", ge=0, le=0.25),
    _pred("rg_seat_damp", "观察期座次降权", "float", 0.25,
          "期内被迫在册(保底/换血回退)时的座次乘子,把它沉入防区 —— 只轮转主/防"
          "标签,零 EV 成本", ge=0, le=1),
    _pred("rg_minm", "豁免样本下限", "int", 30,
          "房间自证豁免的紧随样本下限;与 k≥4、复现率≥1.6×基率、z≥rg_zpos 四关合一,"
          "只有真扎堆能自证放行(放行局 why 落款「随势跟进」;新样本实测:3746870 房"
          "3 号的真扎堆段被如约放行 15 次,其余全程零误放)", ge=1, le=100000),
    _pred("rg_zpos", "豁免 z 门槛", "float", 2.5,
          "紧随重复显著性门槛。z≥2.0 单关在滑窗多重比较下实测可占 13.8% 时点"
          "(3746870 房 3 号,峰值 3.29)—— 必须四关合一(压到其真扎堆段 4.5%)"
          "才谈得上证据", ge=0, le=16),
):
    REGISTRY[_k] = _f

REGISTRY.update({
    # ═══ 鉴权票据(上游登录态;运行期通常由 login 服务 cookie 自动续期接管) ═════
    "auth.app_id": F(label="App ID", type="str", default="1000756", hot=HOOK,
                     hook="auth", consumers=("worker",), section="鉴权票据",
                     no_reset=True, desc="x-auth-app-id;经 update_auth 钩子即时生效"),
    "auth.uid": F(label="登录 UID", type="str", default="88267254", hot=HOOK,
                  hook="auth", consumers=("worker",), section="鉴权票据",
                  danger=True, no_reset=True, env="STA_AUTH_UID",
                  desc="x-auth-uid;运行期由 cookie 续期链路维护 —— 手动覆盖仅救急,"
                       "login 服务下轮刷新将盖回"),
    "auth.ticket": F(label="登录票据", type="str", default="PUT_YOUR_FRESH_X_AUTH_TICKET_HERE",
                     hot=HOOK, hook="auth", consumers=("worker",), section="鉴权票据",
                     sensitive=True, danger=True, no_reset=True, env="STA_AUTH_TICKET",
                     desc="x-auth-ticket(敏感:版本库/审计只存指纹,真值经 Redis 内存分发);"
                          "运行期由 cookie 续期链路维护,手动覆盖仅救急"),
    "auth.token_type": F(label="票据类型", type="str", default="1010", hot=HOOK,
                         hook="auth", consumers=("worker",), section="鉴权票据",
                         no_reset=True, desc="x-auth-token-type;经 update_auth 钩子即时生效"),

    # ═══ 登录系统(3.8.0:外部 MySQL 用户库鉴权;全部为部署项,只读展示) ═════════
    #     · host 留空 = 登录系统整体关闭(3.7.0 原行为);凭据类只走 deploy/.env。
    #     · 对既有 tb_user 绝对只读;新建表全部 guantai_ 前缀(幂等)。
    "userauth.host": F(label="用户库主机", type="str", default="", hot=RESTART,
                       consumers=("web",), section="登录系统", env="STA_USERDB_HOST",
                       readonly=True,
                       desc="MySQL 5.7 用户库主机;留空=登录系统整体关闭(旧行为)"),
    "userauth.port": F(label="用户库端口", type="int", default=3306, ge=1, le=65535,
                       hot=RESTART, consumers=("web",), section="登录系统",
                       env="STA_USERDB_PORT", readonly=True, desc="MySQL 端口"),
    "userauth.db": F(label="用户库库名", type="str", default="", hot=RESTART,
                     consumers=("web",), section="登录系统", env="STA_USERDB_NAME",
                     readonly=True, desc="如 fanxing_changkong_user_db"),
    "userauth.user": F(label="用户库账号", type="str", default="", hot=RESTART,
                       consumers=("web",), section="登录系统", env="STA_USERDB_USER",
                       readonly=True, desc="需 SELECT(tb_user)+ 建表/增删改(guantai_*)权限"),
    "userauth.password": F(label="用户库密码", type="str", default="", hot=RESTART,
                           consumers=("web",), section="登录系统", env="STA_USERDB_PASSWORD",
                           readonly=True, sensitive=True,
                           desc="敏感:只走 deploy/.env,不入版本库/审计"),
    "userauth.charset": F(label="连接字符集", type="str", default="gbk", hot=RESTART,
                          consumers=("web",), section="登录系统", env="STA_USERDB_CHARSET",
                          readonly=True,
                          desc="现有库默认 gbk 且 user_name 列 gbk_bin —— 保持 gbk,"
                               "中文用户名才不乱码(gbk_bin 亦意味用户名大小写敏感)"),
    "userauth.user_table": F(label="用户识别表", type="str", default="tb_user",
                             hot=RESTART, consumers=("web",), section="登录系统",
                             env="STA_USERDB_TABLE", readonly=True,
                             desc="登录识别只读此表(id/user_name/pass_word/due_time/is_off)"),
    # ── 多网络入口(4.5.0):host 可填一组「同一逻辑库的入口」,分摊弹性 IP 带宽 ──
    "userauth.pool_max": F(label="用户库连接总预算", type="int", default=8,
                           ge=1, le=256, unit="连接", hot=RESTART,
                           consumers=("web",), section="登录系统",
                           env="STA_USERDB_POOL_MAX", readonly=True,
                           desc="**全部入口合计**的连接上限(每入口至少 2 条)。"
                                "想吃满多入口带宽请调到「入口数 × 8」量级;"
                                "默认与单入口时代同值,升级零意外压力"),
    "userauth.query_timeout_s": F(label="用户库查询超时", type="float", default=15.0,
                                  ge=1, le=300, unit="秒", hot=RESTART,
                                  consumers=("web",), section="登录系统",
                                  env="STA_USERDB_QUERY_TIMEOUT_S", readonly=True,
                                  desc="单条查询总预算(取连接+执行)。aiomysql 只有 "
                                       "connect_timeout 没有 read_timeout —— 无此闸时"
                                       "入口带宽打满会无限期挂住,坏 IP 根本探测不出来"),
    "userauth.probe_s": F(label="用户库入口探活间隔", type="float", default=10.0,
                          ge=1, le=600, unit="秒", hot=RESTART,
                          consumers=("web",), section="登录系统",
                          env="STA_USERDB_PROBE_S", readonly=True,
                          desc="逐入口测 RTT + 校验「是不是同一个库」+ 保温连接;"
                               "熔断入口按指数退避在此节拍上尝试恢复"),
    "userauth.session_ttl_h": F(label="会话绝对有效期", type="float", default=720.0,
                                ge=1, le=8760, unit="小时", hot=RESTART,
                                consumers=("web",), section="登录系统",
                                env="STA_USER_SESSION_TTL_H", readonly=True,
                                desc="默认 30 天;到期须重新登录"),
    "userauth.idle_ttl_h": F(label="会话空闲有效期", type="float", default=168.0,
                             ge=0, le=8760, unit="小时", hot=RESTART,
                             consumers=("web",), section="登录系统",
                             env="STA_USER_IDLE_TTL_H", readonly=True,
                             desc="默认 7 天未活动需重登;0=不启用空闲判定"),
    "userauth.single_device": F(label="单设备互顶", type="bool", default=True,
                                hot=RESTART, consumers=("web",), section="登录系统",
                                env="STA_USER_SINGLE_DEVICE", readonly=True,
                                desc="开=新登录踢旧会话(与同库既有业务惯例一致);"
                                     "关=并发会话上限见 max_sessions"),
    "userauth.max_sessions": F(label="并发会话上限", type="int", default=3, ge=1, le=50,
                               hot=RESTART, consumers=("web",), section="登录系统",
                               env="STA_USER_MAX_SESSIONS", readonly=True,
                               desc="仅 single_device=关 时生效;超限踢最旧"),
    "userauth.cache_ttl_s": F(label="会话缓存时长", type="float", default=20.0,
                              ge=0, le=600, unit="秒", hot=RESTART,
                              consumers=("web",), section="登录系统",
                              env="STA_USER_CACHE_TTL_S", readonly=True,
                              desc="进程内会话缓存;用户库在公网,逐请求回源不可接受。"
                                   "互顶/登出经 Redis 广播即时失效,不受此值影响"),
    "userauth.outage_grace_s": F(label="故障降级窗", type="float", default=600.0,
                                 ge=0, le=86400, unit="秒", hot=RESTART,
                                 consumers=("web",), section="登录系统",
                                 env="STA_USER_OUTAGE_GRACE_S", readonly=True,
                                 desc="用户库瞬断时,已验证会话继续放行的窗口"
                                      "(新登录不受理);0=关"),
    "userauth.room_max": F(label="每账号名录上限", type="int", default=50, ge=1, le=500,
                           hot=RESTART, consumers=("web",), section="登录系统",
                           env="STA_USER_ROOM_MAX", readonly=True,
                           desc="按登录账号的名录硬闸;须与前端 MAX_ROOMS 同值"
                                "(tests/test_frontend_backend_limits.py 钉住)"),
    "userauth.active_room_lease": F(label="单账号单活跃房", type="bool", default=True,
                                    hot=RESTART, consumers=("web",), section="登录系统",
                                    env="STA_USER_ACTIVE_ROOM_LEASE", readonly=True,
                                    desc="每账号同一时间只放行 1 个活跃监控房(多标签页/多设备);"
                                         "与 room_max 正交,同标签页换房/同房多视图不受限"),
    "userauth.active_room_lease_ttl_s": F(label="活跃房租约TTL", type="float", default=40.0,
                                          ge=5.0, le=3600.0, hot=RESTART, consumers=("web",),
                                          section="登录系统", env="STA_USER_ACTIVE_ROOM_LEASE_TTL_S",
                                          readonly=True,
                                          desc="租约有效期(秒);SSE 心跳/明细轮询续租,须 > 心跳周期"
                                               "(20s),标签页关闭停续即到期释放"),
    "userauth.detail_rate_rps": F(label="明细读限流QPS", type="float", default=4.0,
                                  ge=0.0, le=1000.0, hot=RESTART, consumers=("web",),
                                  section="登录系统", env="STA_USER_DETAIL_RATE_RPS",
                                  readonly=True,
                                  desc="每账号明细端点(prediction/summary/coverage/history"
                                       "[非 passive];**不含 SSE**)平均 QPS;0=不限流。fail-open"),
    "userauth.detail_rate_burst": F(label="明细读突发容量", type="float", default=40.0,
                                    ge=0.0, le=100000.0, hot=RESTART, consumers=("web",),
                                    section="登录系统", env="STA_USER_DETAIL_RATE_BURST",
                                    readonly=True,
                                    desc="每账号明细读令牌桶突发容量;宜 ≥ 单页首屏并发轮询数"),
    "userauth.proof_of_browser": F(label="执行证明闸", type="bool", default=True,
                                   hot=RESTART, consumers=("web",), section="登录系统",
                                   env="STA_USER_PROOF_OF_BROWSER", readonly=True,
                                   desc="L2(3.9.1):明细端点要求 X-JF-Proof 执行证明头,挡住"
                                        "不跑 JS 的纯 API 搬运器。**3.9.2 默认开**;fail-open。"
                                        "无头浏览器/逆向者仍可过。升级后已打开的老页面需刷新"),
    "userauth.proof_challenge_ttl_s": F(label="证明挑战有效期", type="float", default=180.0,
                                        ge=10.0, le=3600.0, hot=RESTART, consumers=("web",),
                                        section="登录系统", env="STA_USER_PROOF_CHALLENGE_TTL_S",
                                        readonly=True,
                                        desc="挑战有效期(秒);前端在 0.75×本值处主动续铸(4.9.0),"
                                             "不再等 401 被动重铸 —— 后者曾让真人每 3 分钟稳吃一次 pow_fail"),
    "userauth.proof_rotate_grace_s": F(label="证明挑战轮转宽限(秒)", type="float", default=45.0,
                                       ge=0.0, le=600.0, hot=RESTART, consumers=("web",),
                                       section="登录系统", env="STA_USER_PROOF_ROTATE_GRACE_S",
                                       readonly=True,
                                       desc="4.9.0:每次 mint 把旧挑战转存短活键,宽限期内仍认 —— "
                                            "多标签页/在飞请求不再变成假失败。0=关闭(退回 3.9.x)"),
    "userauth.signal_footprint_ttl_s": F(label="浏览器足迹保留期(秒)", type="float", default=86400.0,
                                         ge=0.0, le=604800.0, hot=RESTART, consumers=("web",),
                                         section="登录系统",
                                         env="STA_USER_SIGNAL_FOOTPRINT_TTL_S", readonly=True,
                                         desc="4.9.0:见过 html/asset 即置长效足迹键。评分据此判断"
                                              "「本会话有无真浏览器开过页面」,不再被锁屏超窗后的"
                                              "画像重建误判成「从不加载页面」。0=关闭"),
    "userauth.signal_scoring": F(label="疑似脚本来源遥测", type="bool", default=True,
                                 hot=RESTART, consumers=("web",), section="登录系统",
                                 env="STA_USER_SIGNAL_SCORING", readonly=True,
                                 desc="L4(3.9.2):按会话累积行为画像,管理台呈现疑似脚本来源供人工"
                                      "研判。**纯遥测/绝不自动封禁**;fail-safe。默认开(廉价只读)"),
    "userauth.signal_window_s": F(label="画像滚动窗口(秒)", type="float", default=1800.0,
                                  ge=60.0, le=86400.0, hot=RESTART, consumers=("web",),
                                  section="登录系统", env="STA_USER_SIGNAL_WINDOW_S",
                                  readonly=True,
                                  desc="行为画像键的 TTL 与面板观察窗口;过窗会话自动蒸发"),
    "userauth.first_login_room": F(label="首登预置房", type="str", default="2678075:321",
                                   hot=RESTART, consumers=("web",), section="登录系统",
                                   env="STA_USER_FIRST_LOGIN_ROOM", readonly=True,
                                   desc="账号首次登录时自动写入其名录的房「真实号:展示短号」;"
                                        "默认即需求固定房 321(真实号 2678075,与 rooms 种子"
                                        "/room_aliases 呼应)。yaml 置空=关闭;环境变量侧用"
                                        " off/none/0(空串视作未设置)"),
    "userauth.login_fail_user": F(label="失败上限/用户名", type="int", default=10,
                                  ge=1, le=1000, hot=RESTART, consumers=("web",),
                                  section="登录系统", env="STA_USER_LOGIN_FAIL_USER",
                                  readonly=True, desc="窗口内同用户名失败次数上限"),
    "userauth.login_fail_ip": F(label="失败上限/IP", type="int", default=30,
                                ge=1, le=5000, hot=RESTART, consumers=("web",),
                                section="登录系统", env="STA_USER_LOGIN_FAIL_IP",
                                readonly=True, desc="窗口内同来源 IP 失败次数上限"),
    "userauth.login_fail_window_s": F(label="失败计数窗口", type="int", default=600,
                                      ge=10, le=86400, unit="秒", hot=RESTART,
                                      consumers=("web",), section="登录系统",
                                      env="STA_USER_LOGIN_FAIL_WINDOW_S", readonly=True),
    "userauth.login_lock_s": F(label="触限锁定时长", type="int", default=600,
                               ge=10, le=86400, unit="秒", hot=RESTART,
                               consumers=("web",), section="登录系统",
                               env="STA_USER_LOGIN_LOCK_S", readonly=True),
    # ── 5.2.0 登录防爆破(先占后验 · 分级加码 · 设备信任 · 全局攻击态;LOGIN-SYSTEM.md §4.5)──
    "userauth.login_stepup_user": F(label="加码阈值/用户名", type="int", default=-1,
                                    ge=-1, le=1000, hot=HOT, consumers=("web",),
                                    section="登录系统", env="STA_USER_LOGIN_STEPUP_USER",
                                    desc="窗口内同用户名失败达此值起要求加码(本站 PoW;开了"
                                         "登录人机验证再叠验证码)。-1=自动(硬上限 1/3 且≥3),0=关"),
    "userauth.login_stepup_ip": F(label="加码阈值/IP", type="int", default=-1,
                                  ge=-1, le=5000, hot=HOT, consumers=("web",),
                                  section="登录系统", env="STA_USER_LOGIN_STEPUP_IP",
                                  desc="窗口内同 IP 段(IPv6 按 /64)失败达此值起要求加码;"
                                       "-1=自动,0=关"),
    "userauth.login_pow_bits": F(label="登录加码 PoW 难度", type="int", default=16,
                                 ge=8, le=22, unit="位", hot=HOT, consumers=("web",),
                                 section="登录系统", env="STA_USER_LOGIN_POW_BITS",
                                 desc="SHA-256 前导零位;接近硬上限时 +2、全局攻击态再 +2,硬顶 22。"
                                      "只有被要求加码的请求才算,正常登录零成本"),
    "userauth.login_chal_ip_10m": F(label="加码挑战/IP·10分钟", type="int", default=30,
                                    ge=1, le=1000, hot=HOT, consumers=("web",),
                                    section="登录系统", env="STA_USER_LOGIN_CHAL_IP_10M",
                                    desc="每 IP 段 10 分钟内可领取的加码挑战数,超出回 429"),
    "userauth.login_device_ttl_d": F(label="设备信任有效期", type="int", default=90,
                                     ge=0, le=3650, unit="天", hot=HOT, consumers=("web",),
                                     section="登录系统", env="STA_USER_LOGIN_DEVICE_TTL_D",
                                     desc="曾在本浏览器成功登录的账号不受同名锁/IP 锁牵连"
                                          "(按设备单独计数):攻击者锁不住真主人。0=关闭"),
    "userauth.login_attack_5m": F(label="全局攻击态阈值", type="int", default=50,
                                  ge=0, le=100000, hot=HOT, consumers=("web",),
                                  section="登录系统", env="STA_USER_LOGIN_ATTACK_5M",
                                  desc="近 5 分钟全站登录失败达此值 → 未受信设备一律加码"
                                       "(防撒网/撞库:每个用户名只试一两次,单键阈值摸不到)。0=关"),
    # ── 人机验证(5.2.0 起注册与登录共用一套):供应商 → 登录时机 → 凭据,六项紧挨着 ──────────
    # 运维反馈:此前「人机验证供应商」埋在注册项中间、「登录人机验证」又隔着四项凭据,
    # 看不出是一套。键名不动(兼容既有覆盖与 .env),只调顺序与标签;管理台按本表顺序渲染。
    "userauth.reg_captcha": F(label="人机验证 · 供应商(注册与登录共用)", type="enum", default="off",
                              choices=("off", "tencent", "geetest", "turnstile"),
                              hot=HOT, consumers=("web",), section="登录系统",
                              env="STA_USER_REG_CAPTCHA",
                              desc="全站只配一套。注册要不要过由「人机验证 · 注册时也要」决定(默认要),"
                                   "登录何时要过由「人机验证 · 登录时机」决定。大陆选腾讯云/极验;Cloudflare "
                                   "官方声明 Turnstile 不支持中国大陆,仅海外用。注册侧校验网络异常 "
                                   "→ 503 fail-closed,登录侧自动降级为本站 PoW;凭据只走环境变量"),
    "userauth.reg_captcha_required": F(label="人机验证 · 注册时也要", type="bool", default=True,
                                       hot=HOT, consumers=("web",), section="登录系统",
                                       env="STA_USER_REG_CAPTCHA_REQUIRED",
                                       desc="开(默认)= 选了供应商后注册一律要过人机验证;关 = 注册不要,"
                                            "供应商只给登录用(配合下一项「登录时机」)。供应商为 off 时"
                                            "本项不生效(5.2.0)"),
    "userauth.login_captcha": F(label="人机验证 · 登录时机", type="enum", default="off",
                                choices=("off", "risk", "always"), hot=HOT, consumers=("web",),
                                section="登录系统", env="STA_USER_LOGIN_CAPTCHA",
                                desc="登录时何时要过人机验证(供应商与凭据用同组那套):off=不用 / "
                                     "risk=只在可疑时(达加码阈值或全局攻击态,推荐)/ always=每次登录。"
                                     "供应商为 off 时本项不生效(5.2.0)"),
    "userauth.reg_captcha_id": F(label="人机验证 · AppId / sitekey", type="str", default="",
                                 hot=RESTART, consumers=("web",), section="登录系统",
                                 env="STA_USER_REG_CAPTCHA_ID", readonly=True,
                                 desc="tencent=CaptchaAppId / geetest=captcha_id / "
                                      "turnstile=sitekey(会下发前端,非机密)"),
    "userauth.reg_captcha_key": F(label="人机验证 · 密钥", type="str", default="",
                                  hot=RESTART, consumers=("web",), section="登录系统",
                                  env="STA_USER_REG_CAPTCHA_KEY", readonly=True,
                                  sensitive=True,
                                  desc="tencent=AppSecretKey / geetest=captcha_key / "
                                       "turnstile=secret;仅环境变量,管理台打码只读"),
    "userauth.reg_captcha_secret_id": F(label="人机验证 · 腾讯云 SecretId", type="str", default="",
                                        hot=RESTART, consumers=("web",), section="登录系统",
                                        env="STA_USER_REG_CAPTCHA_SECRET_ID", readonly=True,
                                        sensitive=True,
                                        desc="仅 tencent 需要(DescribeCaptchaResult 的 "
                                             "TC3 签名);其余供应商留空"),
    "userauth.reg_captcha_secret_key": F(label="人机验证 · 腾讯云 SecretKey", type="str", default="",
                                         hot=RESTART, consumers=("web",), section="登录系统",
                                         env="STA_USER_REG_CAPTCHA_SECRET_KEY", readonly=True,
                                         sensitive=True,
                                         desc="仅 tencent 需要;其余供应商留空"),
    "userauth.trusted_proxies": F(label="可信代理", type="str", default="loopback,private",
                                  hot=RESTART, consumers=("web",), section="登录系统",
                                  env="STA_TRUSTED_PROXIES", readonly=True,
                                  desc="只有直连对端属于这些网段时才采信 X-Forwarded-For"
                                       "(用户登录/注册/管理台白名单共用)。直连部署保持默认即"
                                       "免疫伪造;前面加了 CDN/异机反代须把它的出口网段写进来。"
                                       "环境变量 > config.yaml > 默认"),
    "userauth.banned_values": F(label="封停取值", type="str", default="1", hot=RESTART,
                                consumers=("web",), section="登录系统",
                                env="STA_USER_BANNED_VALUES", readonly=True,
                                desc="tb_user.is_off 视为封停的取值(逗号分隔)"),
    "userauth.cookie_name": F(label="会话 Cookie 名", type="str", default="jf_user_sid",
                              hot=RESTART, consumers=("web",), section="登录系统",
                              readonly=True, desc="HttpOnly + SameSite=Lax"),
    "userauth.cookie_secure": F(label="Cookie Secure", type="enum", default="auto",
                                choices=("auto", "on", "off"), hot=RESTART,
                                consumers=("web",), section="登录系统",
                                env="STA_USER_COOKIE_SECURE", readonly=True,
                                desc="auto=按请求协议(经 x-forwarded-proto 感知反代)"),
    "userauth.log_retention_days": F(label="登录流水保留", type="int", default=184,
                                     ge=0, le=3650, unit="天", hot=RESTART,
                                     consumers=("web",), section="数据保留",
                                     env="STA_USER_LOG_RETENTION_DAYS", readonly=True,
                                     desc="guantai_login_log 保留天数;0=永久(此时只剩行数上限"
                                          "兜底)。默认 184 = 任意连续六个自然月的最长天数:"
                                          "《网络安全法》第二十三条第(三)项要求网络日志留存"
                                          "不少于六个月"),
    "userauth.log_max_rows": F(label="流水行数上限", type="int", default=5000000,
                               ge=0, le=2000000000, unit="行", hot=RESTART, readonly=True,
                               consumers=("web",),
                               section="数据保留", env="STA_USER_LOG_MAX_ROWS",
                               desc="登录流水与注册流水各自的行数上限(保命阀);0=不设。"
                                    "只按时间保留时,一轮撞库能把流水灌到任意大;超过上限即"
                                    "裁掉最旧的行。默认 500 万行 ≈1.3 GB(实测 268 字节/行),"
                                    "正常站点永远摸不到;摸到时「储」视图标红。低于 10 万按 10 万执行(防少打"
                                    "几个 0)。会删除登录证据,故只能在服务器上改(管理台只读)"),
    "userauth.trust_forwarded_for": F(label="信任 XFF 头", type="bool", default=True,
                                      hot=RESTART, consumers=("web",), section="登录系统",
                                      env="STA_USER_TRUST_XFF", readonly=True,
                                      desc="节流分桶 IP 来源:开=仅当直连对端属可信代理"
                                           "(STA_TRUSTED_PROXIES)时采信 XFF(5.2.0,直连部署"
                                           "天然免疫伪造);关=只认直连地址"),

    # ═══ 注册系统(4.0.0:前端自助注册 · 防恶意注册纵深 R0–R8;详见
    #     REGISTER-SYSTEM.md)。**不配置即不存在**:reg_mode=off(默认)时注册
    #     端点回 503、前端零入口,全项目行为与 3.9.5 一致。═══════════════════════
    "userauth.reg_mode": F(label="注册模式", type="enum", default="off",
                           choices=("off", "invite", "open"), hot=HOT, danger=True,
                           consumers=("web",), section="登录系统", env="STA_USER_REG_MODE",
                           depends="需登录系统已启用且 reg_pass_shape 已配,否则强制视作 off",
                           desc="off=关闭(回 3.9.5)/ invite=邀请码注册(推荐起步)/ "
                                "open=开放注册(吃满 R1–R6 全栈)。即时热更;熔断器只会"
                                "把生效档位压得更严(open→invite→off),恢复须管理台显式点击"),
    "userauth.reg_pass_shape": F(label="注册口令入库形态", type="enum", default="",
                                 choices=("", "plain", "md5", "sha1", "sha256"),
                                 hot=HOT, danger=True, consumers=("web",),
                                 section="登录系统",
                                 env="STA_USER_REG_PASS_SHAPE",
                                 desc="空=注册不启用。**必须与外部续费系统登录校验兼容**"
                                      "(跨系统契约)——预检工具按库里多数派给建议值;"
                                      "sha256 需 pass_word 真实列长 ≥64(运行期实测把关)。"
                                      "摘要取口令 UTF-8 字节,与登录侧 verify_password 同口径。"
                                      "🟢 即时热更:_reg_shape() 每次注册现读,改完立刻对"
                                      "**新注册**生效(存量用户口令不受影响)"),
    "userauth.reg_trial_days": F(label="open 注册赠送天数", type="int", default=0,
                                 ge=0, le=365, unit="天", hot=HOT, consumers=("web",),
                                 section="登录系统", env="STA_USER_REG_TRIAL_DAYS",
                                 desc="due_time=NOW()+N。默认 0(R0 经济闸:空壳号连登录都"
                                      "过不去,攻击产出≈0);改 >0 前先接验证码并复核熔断阈。"
                                      "invite 模式忽略(赠送随邀请码)"),
    "userauth.reg_extra_cols": F(label="tb_user 额外必填列", type="str", default="",
                                 hot=HOT, consumers=("web",), section="登录系统",
                                 env="STA_USER_REG_EXTRA_COLS",
                                 desc="JSON 映射(如 {\"create_time\":\"$now\",\"qq\":\"\"}):"
                                      "真实表存在 NOT NULL 且无默认的其它列时,照抄 "
                                      "--reg-preflight 输出。列名白名单校验,值参数化,"
                                      "$now 展开为 NOW()"),
    "userauth.reg_pow_bits": F(label="PoW 基础难度", type="int", default=17,
                               ge=8, le=25, unit="位", hot=HOT, consumers=("web",),
                               section="登录系统", env="STA_USER_REG_POW_BITS",
                               desc="SHA-256 前导零位。自适应只升不降(同 /24 高频 +2/+4、"
                                    "全局水位 +2、同指纹超限 +4),硬顶 25;主流手机纯 JS "
                                    "≈0.3–1.5s(以真机实测为准,低端机偏慢可下调)"),
    "userauth.reg_chal_ttl_s": F(label="注册挑战有效期", type="int", default=600,
                                 ge=60, le=3600, unit="秒", hot=HOT, consumers=("web",),
                                 section="登录系统", env="STA_USER_REG_CHAL_TTL_S",
                                 desc="挑战单次性、按 IP 段绑定;亦是最长填表时长"
                                      "(前端过期自动重取重试一次)"),
    "userauth.reg_min_fill_s": F(label="最短填表时长", type="int", default=3,
                                 ge=0, le=60, unit="秒", hot=HOT, consumers=("web",),
                                 section="登录系统", env="STA_USER_REG_MIN_FILL_S",
                                 desc="挑战签发→提交的最短间隔;秒提交是脚本铁证(R4)。"
                                      "前端在打开注册表单时即取挑战,真人填表天然 >3s"),
    "userauth.reg_ip_hourly": F(label="注册尝试上限/IP·时", type="int", default=5,
                                ge=1, le=1000, hot=HOT, consumers=("web",),
                                section="登录系统", env="STA_USER_REG_IP_HOURLY",
                                desc="R1:含一切失败(重名/口令不合规/PoW 错);触限 429 "
                                     "+ Retry-After。Redis 抖动退化进程内计数,不放开"),
    "userauth.reg_ip_daily": F(label="注册尝试上限/IP·日", type="int", default=10,
                               ge=1, le=5000, hot=HOT, consumers=("web",),
                               section="登录系统", env="STA_USER_REG_IP_DAILY",
                               desc="R1 双窗之二:防慢速滴灌"),
    "userauth.reg_ip_ok_daily": F(label="成功注册上限/IP·日", type="int", default=2,
                                  ge=1, le=100, hot=HOT, consumers=("web",),
                                  section="登录系统", env="STA_USER_REG_IP_OK_DAILY",
                                  desc="真人极少一天注册第 3 个号"),
    "userauth.reg_chal_ip_10m": F(label="挑战签发上限/IP·10 分", type="int", default=10,
                                  ge=1, le=1000, hot=HOT, consumers=("web",),
                                  section="登录系统", env="STA_USER_REG_CHAL_IP_10M",
                                  desc="挑战是廉价 Redis 写,先钳签发"),
    "userauth.reg_name_10m": F(label="同名尝试上限/10 分", type="int", default=3,
                               ge=1, le=100, hot=HOT, consumers=("web",),
                               section="登录系统", env="STA_USER_REG_NAME_10M",
                               desc="钳单名爆破/占坑拉锯(键=用户名 md5 前 16)"),
    "userauth.reg_global_hourly": F(label="熔断阈:小时成功注册", type="int", default=30,
                                    ge=1, le=100000, hot=HOT, consumers=("web",),
                                    section="登录系统", env="STA_USER_REG_GLOBAL_HOURLY",
                                    desc="R6:open 模式越顶 → 自动降档 invite(管理台横幅"
                                         "+审计);**不自动回升**,恢复须「注」视图显式点击"),
    "userauth.reg_global_daily": F(label="熔断阈:日成功注册(open)", type="int",
                                   default=200, ge=1, le=1000000, hot=HOT,
                                   consumers=("web",), section="登录系统",
                                   env="STA_USER_REG_GLOBAL_DAILY",
                                   desc="R6:open 模式日成功越顶 → 关闸 off(损失有上界)"),
    "userauth.reg_global_daily_invite": F(label="熔断阈:日成功注册(invite)", type="int",
                                          default=500, ge=1, le=1000000, hot=HOT,
                                          consumers=("web",), section="登录系统",
                                          env="STA_USER_REG_GLOBAL_DAILY_INVITE",
                                          desc="R6:invite 模式日成功越顶 → 关闸 off"),
    "userauth.reg_reserved": F(label="追加保留用户名", type="str", default="",
                               hot=HOT, consumers=("web",), section="登录系统",
                               env="STA_USER_REG_RESERVED",
                               desc="逗号分隔;内置名单(admin/root/test/guest 等)"
                                    "恒生效。仅约束新增注册,不追溯存量。"
                                    "⚠️ 4.0.6 起用户名字符集收窄为 [A-Za-z0-9],"
                                    "非字母数字的条目(中文名等)会被字符集闸先行"
                                    "拦下(回 name_invalid 而非 name_reserved),"
                                    "填了不报错但不生效;内置中文条目保留不删,"
                                    "字符集若放宽即刻重新生效"),
    "userauth.reg_success_hint": F(label="零赠送开通指引", type="str",
                                   default="注册成功!请联系管理员开通使用时长后登录。",
                                   hot=HOT, consumers=("web",), section="登录系统",
                                   env="STA_USER_REG_SUCCESS_HINT",
                                   desc="赠送天数=0 的注册成功卡文案(该账号需外部系统"
                                        "开通时长后方可登录)"),
    "userauth.reg_log_retention_days": F(label="注册流水保留", type="int", default=-1,
                                         ge=-1, le=3650, unit="天", hot=HOT,
                                         consumers=("web",), section="数据保留",
                                         env="STA_USER_REG_LOG_RETENTION_DAYS",
                                         desc="guantai_reg_log 保留天数:-1=跟随登录审计"
                                              "保留期;0=永久;并入既有每日清扫任务"),
    # ── 链接快速登录(4.1.0 消费 + 4.3.0 签发)。4.3.0 复审修正:此前整族标
    #    hot=RESTART/readonly=True(跟随登录系统部署项的姿态),但**实地核查证明标错了**——
    #    sso_enabled()/sso_max_age_s/sso_link_* 的六个使用点全部是**调用时**读
    #    UA.cfg,而 UA.cfg 就是 settings.userauth 本身(web.py 的
    #    `userauth.init(settings.userauth, ...)` 传的是同一对象引用),config_center
    #    的原地 setattr 立即可见。按注册表自己的定义(HOT=原地改字段即生效),
    #    这六项就是 HOT。改标并放开后台可改 —— 运营方明确要求,且「出事能一键关掉、
    #    不用重建容器」比只读更安全(与 reg_mode 同一姿态)。
    #    两枚特性开关与密钥标 danger(应用前须键入参数名确认,防手滑);
    #    密钥另标 sensitive(真值只经 Redis 内存分发,绝不落 PG 版本快照 ——
    #    与既有可编辑敏感项 auth.ticket 同款待遇)。
    #    ⚠️ 一经后台覆盖,该键的 .env 值即被盖过(冷启动是「文件/ENV 基线 → 叠加 PG
    #    覆盖」),要回到 .env 语义须在管理页「清除覆盖」。已写进 SSO-LOGIN.md §8。
    "userauth.sso_enabled": F(label="SSO 快速登录(消费)", type="bool", default=False,
                              hot=HOT, consumers=("web",), section="登录系统",
                              env="STA_USER_SSO", danger=True,
                              desc="环境变量 STA_USER_SSO。开启 /api/auth/sso —— "
                                   "同库其它项目签发一次性票据,观测台凭票换会话;"
                                   "默认关(不配置即不存在)。接入见 SSO-LOGIN.md"),
    "userauth.sso_max_age_s": F(label="SSO 票据年龄硬顶", type="int", default=300,
                                ge=5, le=86400, unit="s", hot=HOT,
                                consumers=("web",), section="登录系统",
                                env="STA_USER_SSO_MAX_AGE_S", danger=True,
                                desc="消费侧对票据自 created_at 起的寿命上界 —— "
                                     "即便签发方误写超长 expires_at 也一律拒收"
                                     "(纵深防御,钟差不入判定:统一走库 NOW())。"
                                     "调大=削弱该道防线,故标危险"),
    # ── 账密签发通道(4.3.0):POST /api/auth/sso/link ──────────────────────────
    "userauth.sso_link_enabled": F(label="账密换链接(SSO签发)", type="bool",
                                   default=False, hot=HOT, consumers=("web",),
                                   section="登录系统", env="STA_USER_SSO_LINK",
                                   danger=True,
                                   depends="需同时开启上方「SSO 快速登录(消费)」——"
                                           "签得出票却无处兑换是纯误配",
                                   desc="环境变量 STA_USER_SSO_LINK(注意不是 "
                                        "STA_USER_SSO)。开启 POST /api/auth/sso/link:"
                                        "验账密→吐一次性快速登录链接。口令校验与 "
                                        "/api/auth/login 同一实现、同一失败节流桶,"
                                        "不额外放大爆破面。见 SSO-LOGIN.md §2.6/§7"),
    "userauth.sso_link_ttl_s": F(label="签发票据寿命", type="int", default=60,
                                 ge=10, le=300, unit="s", hot=HOT,
                                 consumers=("web",), section="登录系统",
                                 env="STA_USER_SSO_LINK_TTL_S",
                                 depends="仅「账密换链接」开启时生效",
                                 desc="环境变量 STA_USER_SSO_LINK_TTL_S。本通道签发"
                                      "票据的 expires_at 由观测台自己写(调用方不得"
                                      "指定),代码内另钳 [10,300] 硬顶"),
    "userauth.sso_link_base": F(label="观测台公网 origin", type="str", default="",
                                hot=HOT, consumers=("web",), section="登录系统",
                                env="STA_USER_SSO_LINK_BASE",
                                depends="仅「账密换链接」开启时生效",
                                desc="环境变量 STA_USER_SSO_LINK_BASE。拼返回 url 用,"
                                     "须以 http:// 或 https:// 开头(否则视同未配);"
                                     "留空=只回 ticket。刻意不从 Host 头推导。"
                                     "⚠ **本部署有多个公网 origin(直营主站 + 代理镜像站)时请留空**:"
                                     "票据本身不绑定域名(guantai_sso_ticket 无 host 列),同一张票在本"
                                     "部署任何 origin 都能核销;而本项是单值,填了就等于把**所有**调用方"
                                     "(含代理镜像站)的用户都送去这一个站。留空后由各调用方用自己的 origin "
                                     "拼 `<自己的origin>/#sso=<ticket>` 即可,是一行字符串拼接"),
    "userauth.sso_link_key": F(label="签发通道密钥", type="str", default="",
                               hot=HOT, consumers=("web",), section="登录系统",
                               env="STA_USER_SSO_LINK_KEY",
                               sensitive=True, danger=True,
                               depends="仅「账密换链接」开启时生效",
                               desc="环境变量 STA_USER_SSO_LINK_KEY。配了则请求须带 "
                                    "`Authorization: Bearer <key>`(常数时间比较);"
                                    "留空=不校验(此时能力与已公开的 /api/auth/login "
                                    "等价)。生成:openssl rand -hex 32。⚠ 管理台保存的明文"
                                    "只存 Redis 内存,Redis 重启即丢、web 再重启就回落到 .env"
                                    "(没写 = 不校验);要持久请写 .env 的 STA_USER_SSO_LINK_KEY"),

    # ═══ 九法VIP(4.2.0:分层收费。不配置即不存在 —— jf_vip_enabled=False 时
    #     档位判定/VIP闸/充值端点全部退场,逐字节维持 4.1.2 行为)═══════════════
    "userauth.jf_vip_enabled": F(label="九法VIP体系", type="bool", default=False,
                                 hot=RESTART, consumers=("web",), section="九法VIP",
                                 env="STA_JF_VIP", danger=True,
                                 depends="须先启用登录系统(身份是档位的载体)",
                                 desc="总开关。开启后:①小叮当到期不再拒绝登录,降级为 free 档"
                                      "(可建会话但零数据);②数据端点按 free/basic/vip 三档分层;"
                                      "③开通VIP时对 tb_user.due_time 做全项目唯一一条 UPDATE(赠送小叮当)。"
                                      "关闭即完全退场"),
    "userauth.jf_vip_plans": F(label="VIP档位表", type="json",
                               default=UserAuthCfg().jf_vip_plans,
                               hot=HOT, consumers=("web",), section="九法VIP",
                               env="STA_JF_VIP_PLANS", validator="jf_plans",
                               desc="JSON 数组:code/name/price/jfHours/ddHours/tag。"
                                    "jfHours=九法VIP增量,ddHours=赠送小叮当增量。"
                                    "m1/m3 默认对齐小叮当月卡744h/季卡2232h。"
                                    "⚠ code 一经售出不可删除(历史订单靠它解释),只能改价/停售"),
    "userauth.jf_basic_history_limit": F(label="basic档历史硬顶", type="int", default=30,
                                         ge=1, le=1800, unit="局", hot=HOT,
                                         consumers=("web",), section="九法VIP",
                                         env="STA_JF_BASIC_HIST",
                                         desc="九法非VIP+小叮当有效的用户,每次 history 最多回这么多局。"
                                              "配合『禁用 until』形成硬闸:since 只抬下界且 ORDER BY DESC,"
                                              "禁 until 后无论怎么构造参数都取不到 N 局以前的数据"),
    "userauth.jf_basic_pred_window": F(label="basic档命中窗口", type="int", default=100,
                                       ge=1, le=1000, unit="局", hot=HOT,
                                       consumers=("web",), section="九法VIP",
                                       env="STA_JF_BASIC_PRED_WIN",
                                       desc="basic 档『灵机推演』只给近 N 局的命中率与命中串,"
                                            "不给下一局主/防号位(那是VIP的核心价值)"),
    "userauth.jf_basic_online_h": F(label="basic档在线累计窗", type="float", default=24.0,
                                    ge=0, le=168, unit="h", hot=HOT,
                                    consumers=("web",), section="九法VIP",
                                    env="STA_JF_BASIC_ONLINE_H",
                                    desc="basic 档用户**在线期间实际读到过**的局,允许在本机留存并在刷新后回灌,"
                                         "上限为本窗时长。0=关闭=逐字节回到 4.3.x(刷新即清零)。"
                                         "⚠ 这不是安全闸而是 UX 口径:服务端 history 仍钳 basic档历史硬顶 且禁 until,"
                                         "本项不多给 basic 档一个字节新数据,只是不再把他自己看过的东西在刷新时丢掉。"
                                         "调小=缩短可留存窗口(如 6);调 0=完全撤回。"
                                         "改后前端下次取 /api/auth/session 即跟随,无需重建前端"),
    "userauth.jf_free_session_ttl_h": F(label="free档会话有效期", type="float", default=24.0,
                                        ge=0, le=720, unit="h", hot=HOT,
                                        consumers=("web",), section="九法VIP",
                                        env="STA_JF_FREE_SESSION_TTL_H",
                                        desc="零数据档位的会话 TTL,短一些控制会话表膨胀。0=跟随 session_ttl_h"),
    "userauth.jf_pay_base": F(label="支付网关基址", type="str",
                              default="https://pay.lonlonsoft.com", hot=HOT,
                              consumers=("web",), section="九法VIP",
                              env="STA_JF_PAY_BASE",
                              desc="POST {base}/api/order/create · GET {base}/api/order/status。"
                                   "jfpay._base() 每次调用现读配置,故为热更"
                                   "(复审修正:初版误标须重启,会让运维白重启一次)"),
    "userauth.jf_pay_type": F(label="网关口径type", type="str", default="tulong",
                              hot=HOT, consumers=("web",), section="九法VIP",
                              env="STA_JF_PAY_TYPE", danger=True,
                              desc="九法用 tulong。⚠ 绝不可改成繁星代理余额的 proxy —— "
                                   "那会让两个系统的账目在网关侧混流"),
    "userauth.jf_pay_timeout_s": F(label="网关调用超时", type="float", default=10.0,
                                   ge=1, le=60, unit="s", hot=HOT,
                                   consumers=("web",), section="九法VIP",
                                   env="STA_JF_PAY_TIMEOUT"),
    "userauth.jf_pay_simulate": F(label="支付模拟模式", type="bool", default=False,
                                  hot=HOT, consumers=("web",), section="九法VIP",
                                  env="STA_JF_PAY_SIMULATE", danger=True,
                                  desc="不调真实网关,本地生成占位二维码。仅此开关开启时"
                                       "『模拟支付成功』端点才会真开通。**生产必须关闭** —— "
                                       "否则任何登录用户都能凭空给自己开VIP"),
    "userauth.jf_pay_simulate_ttl_s": F(label="模拟订单有效期", type="int", default=300,
                                        ge=30, le=3600, unit="s", hot=HOT,
                                        consumers=("web",), section="九法VIP",
                                        env="STA_JF_PAY_SIMULATE_TTL"),
    "userauth.jf_settle_grace_s": F(label="结算宽限期", type="int", default=90,
                                    ge=0, le=600, unit="s", hot=HOT,
                                    consumers=("web",), section="九法VIP",
                                    env="STA_JF_SETTLE_GRACE",
                                    desc="订单本地到期后仍在此窗内的查单继续向网关查证,"
                                         "防『扫码已付、网关确认慢几秒』被误判过期。"
                                         "须显著大于前端宽限轮询时长(60s)"),
    "userauth.jf_recover_window_s": F(label="过期订单复查窗", type="int", default=3600,
                                      ge=0, le=86400, unit="s", hot=HOT,
                                      consumers=("web",), section="九法VIP",
                                      env="STA_JF_RECOVER_WINDOW",
                                      desc="已标过期的订单在 expire_time+本值 内仍给一次网关复查,捞回漏账"),
    "userauth.jf_reconcile_lookback_s": F(label="对账回溯窗", type="int", default=86400,
                                          ge=60, le=604800, unit="s", hot=HOT,
                                          consumers=("web",), section="九法VIP",
                                          env="STA_JF_RECONCILE_LOOKBACK"),
    "userauth.jf_reconcile_max": F(label="单次对账笔数", type="int", default=10,
                                   ge=1, le=100, unit="笔", hot=HOT,
                                   consumers=("web",), section="九法VIP",
                                   env="STA_JF_RECONCILE_MAX"),
    "userauth.jf_reconcile_timeout_s": F(label="对账查单超时", type="float", default=6.0,
                                         ge=1, le=30, unit="s", hot=HOT,
                                         consumers=("web",), section="九法VIP",
                                         env="STA_JF_RECONCILE_TIMEOUT"),
    "userauth.jf_reconcile_rate_hourly": F(label="对账兜底限频", type="int", default=12,
                                           ge=0, le=500, unit="次/时", hot=HOT,
                                           consumers=("web",), section="九法VIP",
                                           env="STA_JF_RECONCILE_RATE_HOURLY",
                                           desc="每账号每小时对账兜底上限。对账单次最多向网关查"
                                                "「单次对账笔数」笔,放大倍数是下单的 10 倍,"
                                                "不限频即白刷网关的杠杆。0=不限"),
    "userauth.jf_order_rate_hourly": F(label="下单限频", type="int", default=20,
                                       ge=1, le=500, unit="次/时", hot=HOT,
                                       consumers=("web",), section="九法VIP",
                                       env="STA_JF_ORDER_RATE_HOURLY",
                                       desc="每账号每小时下单上限。九法面向任意注册用户(含free档),"
                                            "不限频=替人白刷网关"),
    "userauth.jf_redeem_fail_hourly": F(label="卡密失败限频", type="int", default=10,
                                        ge=1, le=200, unit="次/时", hot=HOT,
                                        consumers=("web",), section="九法VIP",
                                        env="STA_JF_REDEEM_FAIL_HOURLY",
                                        desc="每账号每小时卡密兑换失败上限。卡号空间 6.4e10 本不可爆破,仍封顶"),
    "userauth.jf_card_purge_enabled": F(label="卡密删除", type="bool", default=False,
                                        hot=HOT, consumers=("web",), section="九法VIP",
                                        env="STA_JF_CARD_PURGE_ENABLED", danger=True,
                                        desc="开启后管理台出现「删除选中」。**勾中即删、无需先作废**:"
                                             "未使用/已作废/已兑换三类一并删除,含仍可兑换的卡"
                                             "(若已发到用户手里,删后兑换会失败且无补救)。"
                                             "删除不可撤销,故默认关;要可撤回的下架请用「作废」"),
    "userauth.jf_card_disabled_age_days": F(
        label="作废卡清扫(按卡龄)", type="int", default=0, ge=0, le=3650, unit="天",
        hot=HOT, consumers=("web",), section="九法VIP",
        env="STA_JF_CARD_DISABLED_AGE_DAYS", danger=True,
        desc="把「已作废且未使用」且**发卡**超过 N 天的卡硬删。0=不清扫。"
             "⚠ 按卡龄(created_at)计,**不是**按作废时长 —— 表无 disabled_at 列"
             "且禁止 ALTER,无从得知何时被作废。故一张两年前发的卡在作废一分钟后"
             "即满足条件。**这不是召回窗**;若你依赖「作废后还能恢复」,请保持 0"),
    "userauth.jf_card_used_retention_days": F(
        label="已兑换卡保留期", type="int", default=0, ge=0, le=3650, unit="天",
        hot=HOT, consumers=("web",), section="九法VIP",
        env="STA_JF_CARD_USED_RETENTION_DAYS", danger=True,
        desc="超期的已兑换卡由每日清扫硬删。0=不清扫。真账在 guantai_jf_grant_log,"
             "删卡行不影响对账口径,只是给资源池排水"),
    "userauth.jf_order_unpaid_retention_days": F(
        label="未支付订单保留", type="int", default=184, ge=0, le=3650, unit="天",
        hot=HOT, consumers=("web",), section="数据保留",
        env="STA_JF_ORDER_UNPAID_RETENTION_DAYS",
        desc="没付款的订单(pending / expired 且未入账)下单超过 N 天即清;0=永久保留。"
             "**已支付订单是账本,任何取值都不会删**。实际执行不低于 7 天(远大于对账"
             "回看与过期恢复窗)。下一轮清扫生效"),

    # ═══ 外部发卡 API(4.2.9:机器对机器,只认 API Key)══════════════════════════
    # 开关默认关 + 密钥默认空,**两道都得显式配上**才可能发出一张卡。这是
    # 「不配置即不存在」在危险方向上的取向 —— 本端点是纯价值创造,一次调用凭空
    # 多出 N 张可兑换 VIP 时长,没有 sso_link 那条「不配密钥也不构成新增敞口」的退路。
    "userauth.jf_card_api_enabled": F(
        label="外部发卡API", type="bool", default=False,
        hot=HOT, consumers=("web",), section="九法VIP",
        env="STA_JF_CARD_API", danger=True,
        depends="须先启用九法VIP体系,且必须同时设置「外部发卡API密钥」",
        desc="开启后 POST /api/admin/jfvip/cards/issue 可凭 API Key 直接生成"
             "**指定时长**的卡密(小时为单位,单次 ≤500 张)。与管理台会话物理隔离。"
             "⚠ 这是唯一一条能凭密钥凭空造出可兑换时长的通路;密钥未设置或短于 24 "
             "字符时端点仍整体 503(开了也不生效,启动横幅会告诉你卡在哪)"),
    "userauth.jf_card_api_key": F(
        label="外部发卡API密钥", type="str", default="",
        hot=HOT, consumers=("web",), section="九法VIP",
        env="STA_JF_CARD_API_KEY", sensitive=True, danger=True,
        gen_bytes=32,                       # 管理台给「🎲 生成」按钮(32B = 64 hex)
        revealable=True,                    # 管理台可随时揭示明文(每次落审计)
        depends="仅「外部发卡API」开启时生效",
        desc="调用方须带 `Authorization: Bearer <key>`(常数时间比较)。"
             "**留空 = 端点整体 503**,不是「不校验」—— 与账密换链接的密钥语义相反,"
             "因为本端点没有任何已公开端点与之等价。长度须 ≥24 字符(短密钥可离线"
             "爆破,而这里发出的每张卡都是真金白银)。生成:openssl rand -hex 32。"
             "⚠ 管理台保存的明文只存 Redis 内存(不落库、不写文件),Redis 重启即丢、web 再重启"
             "就回落到 .env;要持久请写 .env 的 STA_JF_CARD_API_KEY"),
    "userauth.jf_card_api_rate_hourly": F(
        label="外部发卡限频", type="int", default=60, ge=0, le=10000, unit="次/时",
        hot=HOT, consumers=("web",), section="九法VIP",
        env="STA_JF_CARD_API_RATE_HOURLY",
        depends="仅「外部发卡API」开启时生效",
        desc="每小时发卡调用上限,**全局按密钥**而非按来源 IP —— 密钥泄漏后攻击者"
             "从任意 IP 打过来,按 IP 分桶等于给他每个 IP 一份配额。0=不限。"
             "默认 60:单次最多 500 张 ⇒ 理论上限 3 万张/时"),
    "userauth.jf_card_api_ip_allow": F(
        label="外部发卡IP白名单", type="str", default="",
        hot=HOT, consumers=("web",), section="九法VIP",
        env="STA_JF_CARD_API_IP_ALLOW", danger=True,
        depends="仅「外部发卡API」开启时生效",
        desc="逗号分隔 CIDR(如 203.0.113.7/32,198.51.100.0/24)。留空=不限,仅凭密钥。"
             "发卡平台出口 IP 通常固定,写死可让一次密钥泄漏不至于立刻变成无限发卡。"
             "⚠ 配了却一条合法 CIDR 都没有时 **fail-closed**(全部拒绝)——"
             "白名单配错的正确表现是把自己关在门外,而不是悄悄敞开"),

    # ═══ 站点分流:直营主站 vs 代理镜像站(4.4.1)════════════════════════════════
    # 同一套后端同时服务多个域名时,按请求 Host 决定该站是否提供在线扫码付款。
    # **留空 = 特性整体关闭 = 逐字节旧行为**;非空 ⇒ 只有名单内是直营,其余按镜像。
    "userauth.jf_direct_hosts": F(
        label="直营主站域名", type="str", default="",
        hot=HOT, consumers=("web",), section="九法VIP",
        env="STA_JF_DIRECT_HOSTS", danger=True,
        depends="须先启用九法VIP体系",
        desc="逗号分隔(也认空格/分号/中文逗号)。**留空=关闭本特性**,全部域名一律按"
             "直营(逐字节旧行为)。一旦非空:**只有名单内的 Host 是直营主站**"
             "(显示「立即开通」在线扫码 + 档位价格卡),其余 Host 一律按**代理镜像站**"
             "(隐藏在线扫码与档位卡,只留「我有卡密」+「联系客服购买」文字提示,"
             "后端 /api/vip/order/create 一并拒单)。"
             "⚠ 三个必知的坑:① 精确匹配,**不支持通配符**;"
             "② `example.com` 与 `www.example.com` 是两个 Host,两个都用就两个都写,"
             "漏写那个会变成镜像站(主站就没有在线支付了);"
             "③ 用 IP:端口 直连自测(如 http://1.2.3.4:5173)也不在名单内 ⇒ 按镜像站,"
             "要自测在线支付请把该 IP 也写进来。"
             "改完立即生效(每次请求现读),生效值见 web 启动横幅与 /api/auth/session 的 jf.site"),
    "userauth.jf_direct_trust_xfh": F(
        label="站点分流信任 XFH 头", type="bool", default=False,
        hot=HOT, consumers=("web",), section="九法VIP",
        env="STA_JF_DIRECT_TRUST_XFH", danger=True,
        depends="仅「直营主站域名」非空时生效",
        desc="关(默认)=只认 `Host` 头 —— nginx `proxy_set_header Host $host`、Caddy 默认"
             "都会透传原始 Host,这条路是对的。"
             "开=优先取 `X-Forwarded-Host` 的**首跳**,缺失才回落 Host;"
             "仅当你的反代把 Host 改写成了上游名(此时后端看到的所有站点是同一个 Host,"
             "分流会整体失灵)才需要开。"
             "⚠ 头由谁写谁才可信:直连暴露公网时开启它等于让任何人自选站点身份"),

    # ═══ 客服联系方式(4.4.2)══════════════════════════════════════════════════
    # 「联系客服购买」这句提示自 4.4.1 起就在,但**只是一句话**。本组四项给它配上
    # 真正的联系方式,并把它做成前端可复用的一块数据(不只服务于开通门)。
    #
    # 三条纪律,与本表既有项一脉相承:
    #   ① **不配置即不存在** —— 「客服号码/账号」与「在线客服链接」两项都留空时,
    #      整块不下发、页面逐字节维持 4.4.1;不另设总开关(同 jf_direct_hosts);
    #   ② **只对直营主站下发** —— 镜像站的 /api/auth/session 响应体里根本没有这几个
    #      字段。代理的客户该找的是代理,而平台的客服号出现在代理站上就是在撬他的单;
    #   ③ **链接只放行 http/https** —— 见各项 desc。
    "userauth.jf_cs_label": F(
        label="客服渠道名", type="str", default="",
        hot=HOT, consumers=("web",), section="九法VIP",
        env="STA_JF_CS_LABEL",
        depends="仅「客服号码/账号」或「在线客服链接」非空时才会展示",
        desc="展示在联系方式前面的短标签,如「客服QQ」「售后微信」「官方群」。"
             "留空 = 前端按「客服」兜底。上限 16 字符(开通门在 320px 机型上"
             "只有一行的预算,超长会把复制按钮挤下去)"),
    "userauth.jf_cs_value": F(
        label="客服号码/账号", type="str", default="",
        hot=HOT, consumers=("web",), section="九法VIP",
        env="STA_JF_CS_VALUE", validator="jf_cs",
        depends="须先启用九法VIP体系(开通门是当前唯一展示位)",
        desc="QQ 号 / 微信号 / 群号等,**原样展示并提供「复制」按钮**。"
             "与「在线客服链接」两项都留空 = 本特性整体不存在(逐字节 4.4.1 行为)。"
             "⚠ 只对**直营主站**下发:配了站点分流后,代理镜像站的 "
             "/api/auth/session 响应里根本不会出现这个值(不是前端藏起来)。"
             "⚠ 刻意**不做字符纠错**(同卡密 norm_card):粘进来的全角数字/多余空格"
             "会原样展示,保存时会告警但不替你改 —— 猜错一个字符就是把用户送去"
             "别人的号。上限 64 字符"),
    "userauth.jf_cs_url": F(
        label="在线客服链接", type="str", default="",
        hot=HOT, consumers=("web",), section="九法VIP",
        # 刻意**不标 danger**(自审后改的):danger 的成本是「应用前键入参数名」,
        # 而这一项的真实风险是**打错一个字符**(把付费用户送去陌生人那里)——
        # 键入参数名对这种错零帮助。真正管用的是 jf_cs 校验器在保存时把
        # **收敛后的生效值**原样回显出来,让运维核对的是用户将看到的那一串。
        # 同一取向见 jf_vip_plans:直接涉钱,同样只挂校验器而不标 danger。
        env="STA_JF_CS_URL", validator="jf_cs",
        depends="仅「客服号码/账号」或本项非空时生效",
        desc="点得动的去处(网页客服、QQ 群邀请页等),新窗打开且带 "
             "rel=noopener。**只放行 http/https 绝对 URL**,其余一律**静默丢弃**:"
             "① `javascript:` / `data:` 是注入面,HTML 转义**不能**中和 href 里的它们;"
             "② `mqqwpa://` / `tencent://` / `weixin://` 在桌面浏览器点了毫无反应,"
             "那是本项目一贯拒绝的死控件。留空 = 不渲染链接,只留「展示 + 复制」"
             "(微信号本来也没有可用深链)。上限 256 字符"),
    "userauth.jf_cs_note": F(
        label="客服备注", type="str", default="",
        hot=HOT, consumers=("web",), section="九法VIP",
        env="STA_JF_CS_NOTE",
        depends="仅「客服号码/账号」或「在线客服链接」非空时才会展示",
        desc="联系方式下面的一行小字,如「服务时间 09:00–24:00」。"
             "留空即完全不占高度 —— 开通门的首屏预算按 320×568 算过,"
             "多一行就少一行别的。上限 48 字符"),

    # ═══ 元数据(游戏静态元数据与名录种子:建议只读/走名录面板) ═════════════════
    "custom_beast_ids": F(label="妖兽自定义编号", type="json",
                          default={"镇岳甲": 1, "苍梧魔": 2, "焚天雀": 3, "白虹骥": 4,
                                   "玄兵猿": 5, "金羽皇": 6, "踏荒牛": 7, "青鸾凤": 8,
                                   "沧溟龙": 9},
                          hot=RESERVED, readonly=True, consumers=("worker", "web"),
                          section="元数据",
                          desc="游戏静态元数据(九法阵对齐);web 在 import 期构建元表,"
                               "改动需编辑 config.yaml 并重启 —— 管理台只读保护"),
    "rooms": F(label="初始监控房间(首启种子)", type="json", default=[],
               hot=RESERVED, readonly=True, consumers=("worker", "web"), section="元数据",
               desc="config.yaml 声明的房间仅作首启种子;日常增删请走「名录」面板"
                    "(/api/monitor/*),与 README「生产可留空」建议一致"),
    "room_aliases": F(label="房号短号别名", type="json", default={},
                      hot=RESERVED, readonly=True, consumers=("worker", "web"),
                      section="元数据",
                      desc="真实号 → 展示短号;在线编辑请走「名录」面板(落 Redis meta + "
                           "PG rooms.alias),此处为 config.yaml 种子层"),
})

# ═══ 管理台入口(5.3.0;部署项:只读展示,改动走 config.yaml 的 admin: 段或 .env) ═══════
# 刻意全部 readonly:入口路径是构造期参数(路由在进程启动时挂载),账号与人机验证档位是
# 「进门的规则」—— 都不该能从门里面(一个已登录的会话)改掉。
REGISTRY.update({
    "admin.username": F(label="管理台登录账号", type="str", default="",
                        hot=RESTART, consumers=("web",), section="管理台",
                        env="STA_ADMIN_USERNAME", readonly=True, sensitive=True,
                        desc="账号是凭据,**只走 deploy/.env 的 STA_ADMIN_USERNAME**(与口令 "
                             "STA_ADMIN_PASSWORD 成对,不进 config.yaml、不随代码分发)。留空=只验口令;"
                             "设置后登录须同时给对账号与口令,任一项错回同一个错误且同样计入失败额度。"
                             "比对时全角转半角、去首尾空白、不分大小写"),
    "admin.path": F(label="管理台入口路径", type="str", default="admin-xdd",
                    hot=RESTART, consumers=("web",), section="管理台",
                    env="STA_ADMIN_PATH", readonly=True,
                    desc="后台页面 = /<本值>,管理 API = /api/<本值>/*(前端自动跟随)。单段:字母/数字/"
                         "连字符/下划线,1–64 位,且不能与站点已有路径同名(如 auth / monitor / rooms);非法值启动告警并回落默认。"
                         "改动位置:config.yaml 的 "
                         "admin.path(重建 web),或 deploy/.env 的 STA_ADMIN_PATH(重启 web,升级不丢)。"
                         "旧地址 /admin、/admin.html、/api/admin/* 按不存在的路径应答;外部发卡接口 "
                         "POST /api/admin/jfvip/cards/issue 是机器契约,地址恒定不随本值变"),
    "admin.login_captcha": F(label="管理台登录人机验证", type="enum", default="auto",
                             choices=("auto", "always", "off"),
                             hot=RESTART, consumers=("web",), section="管理台",
                             env="STA_ADMIN_LOGIN_CAPTCHA", readonly=True,
                             depends="供应商与凭据和注册共用:userauth.reg_captcha*(STA_USER_REG_CAPTCHA*)",
                             desc="auto=站点配好了人机验证供应商就每次登录都要过(没配则没有这道闸);"
                                  "always=必须过,供应商没配好时拒绝网页登录;off=不要。供应商不可达时"
                                  "一律拒绝登录(不降级放行),应急走服务器上生成的一次性登录链接"
                                  "(deploy-maxxiang.sh admin-link)"),
})


# ── 部署层(只读呈现;不属于 Settings,改动指向文件) ──────────────────────────
DEPLOY_ITEMS = (
    {"key": "WEB_PORT", "label": "Web 端口", "where": "deploy/.env → docker-compose",
     "desc": "默认 5173;改后 docker compose up -d 重建 web"},
    {"key": "POSTGRES_USER/PASSWORD/DB", "label": "PG 账号库名", "where": "deploy/.env",
     "desc": "compose 级;改后重建 postgres/worker/web"},
    {"key": "worker --scale", "label": "worker 副本数", "where": "docker compose up -d --scale worker=N",
     "desc": "默认 4(1 万房真机实测 = 每局 11.2ms CPU × 200 局/s = 2.2 核);按需 ≈⌈总房数/4300⌉+1,硬顶 11(README §5.1/§5.3)"},
    {"key": "postgres command flags", "label": "PG 调优", "where": "docker-compose.yml postgres.command",
     "desc": "max_connections=400 · shared_buffers=2GB(<8G 内存机请调回 1GB) · effective_cache_size=6GB · maintenance_work_mem=512MB(autovacuum_work_mem=256MB 另钳) · random_page_cost=1.1(SSD;机械盘改回 4.0) · synchronous_commit=off(崩溃至多丢 ~0.6s,漏局自动补齐) · max_wal_size=4GB · autovacuum 4 workers/15s · timezone=Asia/Shanghai"},
    {"key": "redis command flags", "label": "Redis 调优", "where": "docker-compose.yml redis.command",
     "desc": "maxclients=20000(账本:4 副本最坏 ≈4×928 + web 256 ≈ 3968,5 倍余量;实测万房 Redis 仅 ~28MB) · maxmemory=1gb(noeviction:超限写报错不驱逐) · 无持久化(状态可由 PG/janitor 回灌)"},
    {"key": "logging 50m×5", "label": "容器日志轮转", "where": "docker-compose.yml x-logging",
     "desc": "每服务至多 250MB,足够回看数小时"},
    {"key": "KG_REFRESH_DAYS / KG_RETRY_MINUTES / KG_CHECK_MINUTES", "label": "登录刷新周期",
     "where": "docker-compose.yml login.environment",
     "desc": "兜底强刷 25 天 / 全败重试 120 分 / 有效性探测 1 分;改后 restart login"},
    {"key": "KG_DATA_DIR", "label": "登录数据目录", "where": "deploy/.env",
     "desc": "默认 ./kgdata;login 写、worker/web 只读挂载"},
    {"key": "STA_ENGINE_DIR", "label": "预测引擎目录", "where": ".env / 镜像 /app/engine",
     "desc": "predictor_bridge 导入 spell_tamer_monitor.py 的位置"},
    {"key": "TZ", "label": "容器时区", "where": "镜像内置 Asia/Shanghai",
     "desc": "关键字段另在代码内钉死 UTC+8,不随其漂移"},
    {"key": "STA_ADMIN_PASSWORD(_HASH) / STA_ADMIN_SECRET / STA_ADMIN_IP_ALLOW",
     "label": "管理台鉴权", "where": "deploy/.env",
     "desc": "未设密码=管理台整体关闭(503);SECRET 未设则由密码派生(多 uvicorn worker 一致)。"
             "登录账号 STA_ADMIN_USERNAME 与密码成对,见参数中心「管理台」板块的「管理台登录账号」。"
             "入口路径 / 人机验证档位同在该板块(config.yaml 的 admin: 段)"},
    {"key": "STA_ADMIN_LOGIN_RATE_PER_MIN / STA_ADMIN_LOGIN_FAIL_IP / _GLOBAL / _WINDOW_S / STA_ADMIN_LOGIN_LOCK_S",
     "label": "管理台登录防爆破", "where": "deploy/.env",
     "desc": "每 IP 段每分钟至多 20 次登录请求;失败额度每 IP 段 10 次、全站 30 次 / 10 分钟,触顶锁 10 分钟。"
             "Redis 不可用时退化进程内计数:既不放开,也不把管理员自己锁在外面"},
    {"key": "STA_MONITOR_WRITE_TOKEN", "label": "名录写接口加固(可选)", "where": "deploy/.env",
     "desc": "设置后 /api/monitor/add|remove|add-bulk 要求 X-Monitor-Token 头;默认关、行为不变"},
    {"key": "STA_MAX_REQUEST_BYTES", "label": "请求体大小上限(默认 8 MiB)", "where": "deploy/.env",
     "desc": "超限请求在一切鉴权 / 解析之前直接 413;防未鉴权端点被超大请求体撑爆进程。合法请求最大的是"
             "名录批量添加(数千房也只有几十 KB),一般无需调整。构造期读取,改后重启 web"},
    {"key": "STA_API_DOCS", "label": "API 交互式文档(默认关)", "where": "deploy/.env",
     "desc": "FastAPI 的 /docs /redoc /openapi.json —— 4.2.4 起**默认关闭**。"
             "它们匿名可读,会把全部路径(含整个管理面及其**入口路径**)的参数 schema 公开出去;"
             "web 就绪探针走 /api/version,不受影响。排障时设 1 临时打开,排完请删掉并重建 web"},
)


# ── 工具:路径读写 / 类型收敛 / 展平 ──────────────────────────────────────────
_SUBSECTIONS = ("upstream", "scheduler", "ratelimit", "admission",
                "retention", "discovery", "auth")


def get_path(settings, key: str):
    """按点分路径读取 settings 当前值(prediction.* 读 dict;缺失回注册表默认)。"""
    if "." in key:
        head, _, rest = key.partition(".")
        if head == "prediction":
            return (settings.prediction or {}).get(rest, REGISTRY[key].default)
        return getattr(getattr(settings, head), rest)
    return getattr(settings, key)


def set_path(settings, key: str, value) -> None:
    """按点分路径**原地**写入(铁律一:子配置对象逐字段 setattr,绝不整体替换;
    prediction 为 dict 原地赋键 —— worker/web 各处持有的引用即刻可见)。"""
    if "." in key:
        head, _, rest = key.partition(".")
        if head == "prediction":
            settings.prediction[rest] = value
            return
        setattr(getattr(settings, head), rest, value)
        return
    setattr(settings, key, value)


_TRUE = ("1", "true", "yes", "on")
_FALSE = ("0", "false", "no", "off")


def coerce(f: Field, value):
    """把外部值(JSONB/表单串)收敛为字段类型;失败抛 ValueError。"""
    t = f.type
    if t == "bool":
        if isinstance(value, bool):
            v = value
        else:
            s = str(value).strip().lower()
            if s in _TRUE:
                v = True
            elif s in _FALSE:
                v = False
            else:
                raise ValueError(f"非法布尔值: {value!r}")
    elif t == "int":
        v = int(str(value).strip())
    elif t == "float":
        v = float(str(value).strip())
    elif t in ("str", "enum", "csvnums"):
        v = str(value)
        if t == "csvnums":
            parts = [p.strip() for p in v.split(",") if p.strip()]
            if not parts:
                raise ValueError("不能为空:需逗号分隔数值串,如 45,30,15")
            for p in parts:
                float(p)  # 非数值抛 ValueError
            v = ",".join(parts)
    elif t == "json":
        if isinstance(value, (dict, list)):
            v = value
        else:
            import json as _json
            v = _json.loads(str(value))
    else:  # pragma: no cover
        raise ValueError(f"未知类型 {t}")
    err = check_range(f, v)
    if err:
        raise ValueError(err)
    return v


def check_range(f: Field, v) -> str:
    """范围/枚举检查;返回错误串(空=通过)。"""
    if f.choices is not None and str(v) not in f.choices:
        return f"取值须为 {' / '.join(f.choices)} 之一"
    if isinstance(v, bool):
        return ""
    if f.ge is not None and isinstance(v, (int, float)) and v < f.ge:
        return f"不得小于 {f.ge:g}"
    if f.le is not None and isinstance(v, (int, float)) and v > f.le:
        return f"不得大于 {f.le:g}"
    return ""


def flatten_effective(settings) -> Dict[str, Any]:
    """当前 settings 的全键展平(注册表口径)。用于捕获 ENV/YAML/默认合并基线。"""
    return {k: get_path(settings, k) for k in REGISTRY}


def mask(f: Field, v) -> Any:
    """敏感值掩码(前 8 后 4;短值全遮)。非敏感原样返回。
    1.4.3:实现自 config_center 迁入本表 —— public_schema 也要用同一把尺:
    default 此前经 schema 裸奔下发,与 /config/effective 的四层全掩码口径
    正面相撞(审计 A2:页面「默认」栏明文渲染含口令的 DSN)。center 侧的
    mask 保留同名薄委托,既有调用方(describe/_ticket_fp 等)零改动。"""
    if not f.sensitive or v is None:
        return v
    s = str(v)
    return f"{s[:8]}…{s[-4:]}" if len(s) > 14 else "···"


def public_schema() -> Dict[str, Any]:
    """交给前端的 Schema(剔除服务端专属字段)。
    1.4.3:敏感项的 default 亦掩码下发(与 effective 各层同一口径)——
    旧注释「不含任何值」名不副实:default 本身就是值,且可能含凭据。"""
    out = {}
    for k, f in REGISTRY.items():
        out[k] = {
            "label": f.label, "type": f.type, "default": mask(f, f.default), "hot": f.hot,
            "consumers": list(f.consumers), "section": f.section, "desc": f.desc,
            "unit": f.unit, "ge": f.ge, "le": f.le,
            "choices": list(f.choices) if f.choices else None, "env": f.env,
            "sensitive": f.sensitive, "danger": f.danger, "readonly": f.readonly,
            "no_reset": f.no_reset, "depends": f.depends,
            "genBytes": f.gen_bytes, "revealable": f.revealable,
        }
    return {"sections": list(SECTIONS), "fields": out,
            "deploy": [dict(d) for d in DEPLOY_ITEMS]}
