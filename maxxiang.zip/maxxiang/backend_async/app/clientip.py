"""
clientip.py — 统一的「来源 IP」判定(5.2.0)
================================================================================
为什么必须有它(实地复现,不是推断):
  · 用户侧 `userauth.client_ip` 原先默认信任 X-Forwarded-For **首跳**,管理台
    `admin_auth.client_ip` 则**无条件**信任首跳。而本项目官方编排是**直连**
    (compose 的 web 服务直接发布端口,前面没有反代)—— 于是任何人在请求里
    加一行 `X-Forwarded-For: 10.1.2.3`,就能:
      ① 绕过 STA_ADMIN_IP_ALLOW 管理台 IP 白名单(实证:公网对端 + 伪造内网 XFF
         → ip_allowed() 返回 True);
      ② 每个请求换一个假 IP,把按 IP 的登录 / 注册 / 管理台登录节流全部稀释掉。
  · 即便前面有反代,「首跳」在**追加式**反代(nginx `$proxy_add_x_forwarded_for`)
    后面也是客户端可控的:客户端自带的 XFF 会原样排在最左边。

判定规则(业界通行的「可信代理」算法,与 uvicorn forwarded_allow_ips、
Rails RemoteIp、Express trust proxy 同一思路):
  ① 直连对端(request.client.host)**不是**可信代理 → 一律用直连地址,XFF 忽略;
  ② 对端是可信代理 → 从 XFF **最右**往左走,跳过同样属于可信代理的跳,第一个
     非可信代理的合法 IP 即客户端;遇到非法串立即停止并回落直连地址;
  ③ 全部都是可信代理 → 取最左一跳。

可信代理集合 = 环境变量 STA_TRUSTED_PROXIES(逗号分隔):
  · loopback —— 127.0.0.0/8、::1
  · private  —— 10/8、172.16/12、192.168/16、169.254/16、fc00::/7、fe80::/10
  · 任意 CIDR(如 203.0.113.0/24)
  · none     —— 谁都不信(等价于全局关闭 XFF)
  · * / any  —— 全信(旧行为,**不推荐**:直连部署下等于把 IP 交给攻击者填)
默认 "loopback,private":直连部署(对端是公网客户端)天然免疫伪造;同机或同
Docker 网络里的反代(对端是环回/内网地址)照常生效 —— 零配置两种拓扑都对。

诚实边界:
  · Windows/macOS 的 Docker Desktop 会把所有外部访客显示成同一个内网网关地址。
    这种环境下「对端是内网」不再意味着「对端是你的反代」—— 请把
    STA_TRUSTED_PROXIES 设为 none(或你真实反代的地址)。
  · 将来若在前面加 CDN/反代(对端是公网地址),请把它的出口网段写进
    STA_TRUSTED_PROXIES,否则所有访客会被看成那几个出口 IP。
"""
from __future__ import annotations

import ipaddress
import os
from typing import Any, Optional, Tuple

ENV_NAME = "STA_TRUSTED_PROXIES"
DEFAULT = "loopback,private"

_GROUPS = {
    "loopback": ("127.0.0.0/8", "::1/128"),
    "private": ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "169.254.0.0/16",
                "fc00::/7", "fe80::/10"),
}
_ALL = ("*", "any", "all")
_NONE = ("none", "off", "0", "false", "no")

# 按原串缓存解析结果(配置极少变化;每请求只做一次 dict 查)
_cache: dict = {"raw": None, "nets": (), "all": False}
# 由 settings 推入的值(config.yaml 的 userauth.trusted_proxies 走这条路);环境变量仍最优先
_configured: dict = {"raw": None}


def configure(raw: Any) -> None:
    """web 启动时由 userauth.init 推入 settings 里的值。优先级与全项目一致:
    环境变量 > config.yaml > 默认 —— 每次判定时先看环境变量,因此运维改了环境变量
    (以及测试里 monkeypatch 环境变量)总是立即生效。"""
    t = str(raw).strip() if raw is not None else ""
    _configured["raw"] = t or None


def _parse(raw: str) -> Tuple[tuple, bool]:
    nets = []
    for part in str(raw or "").replace(";", ",").split(","):
        p = part.strip().lower()
        if not p:
            continue
        if p in _ALL:
            return (), True
        if p in _NONE:
            continue
        for cidr in _GROUPS.get(p, (p,)):
            try:
                nets.append(ipaddress.ip_network(cidr, strict=False))
            except ValueError:
                print(f"[来源IP] ⚠️ STA_TRUSTED_PROXIES 含无法识别的项 {part.strip()!r},已忽略")
    return tuple(nets), False


def _conf() -> Tuple[tuple, bool]:
    raw = os.environ.get(ENV_NAME)
    if raw is None or not str(raw).strip():
        raw = _configured["raw"] or DEFAULT
    if _cache["raw"] != raw:
        nets, everyone = _parse(raw)
        _cache.update(raw=raw, nets=nets, all=everyone)
    return _cache["nets"], _cache["all"]


def norm_ip(s: Any) -> Optional[str]:
    """把一跳归一成规范 IP 字符串;非法 → None。兼容 `1.2.3.4:5678`、
    `[2001:db8::1]:443` 两种带端口写法,以及 IPv4 映射的 IPv6(::ffff:a.b.c.d)。"""
    t = str(s or "").strip().strip('"')
    if not t:
        return None
    if t.startswith("["):
        end = t.find("]")
        if end <= 0:
            return None
        t = t[1:end]
    elif t.count(":") == 1:          # IPv4:port(纯 IPv6 至少两个冒号)
        t = t.split(":", 1)[0]
    try:
        ip = ipaddress.ip_address(t)
    except ValueError:
        return None
    mapped = getattr(ip, "ipv4_mapped", None)
    return str(mapped or ip)


def is_trusted(ip: Any) -> bool:
    nets, everyone = _conf()
    if everyone:
        return True
    n = norm_ip(ip)
    if n is None:
        return False
    addr = ipaddress.ip_address(n)
    return any(addr.version == net.version and addr in net for net in nets)


def resolve(peer: Any, xff: Any, trust_xff: bool = True) -> str:
    """直连对端 + XFF 原串 → 客户端 IP(见模块头的三条规则)。"""
    peer_s = str(peer or "").strip()
    peer_n = norm_ip(peer_s) or peer_s
    if not trust_xff or not str(xff or "").strip() or not is_trusted(peer_n):
        return peer_n
    hops = [h.strip() for h in str(xff).split(",") if h.strip()]
    for h in reversed(hops):
        n = norm_ip(h)
        if n is None:
            return peer_n            # 链上出现非法串:整条链不可信,回落直连地址
        if not is_trusted(n):
            return n
    return norm_ip(hops[0]) or peer_n


def from_request(request: Any, trust_xff: bool = True) -> str:
    try:
        peer = request.client.host if getattr(request, "client", None) else ""
    except Exception:                # noqa: BLE001
        peer = ""
    try:
        xff = request.headers.get("x-forwarded-for", "") or ""
    except Exception:                # noqa: BLE001
        xff = ""
    return resolve(peer, xff, trust_xff)


def bucket(ip: Any) -> str:
    """限流分桶:IPv4 原址、IPv6 按 /64(一台机器通常独占一个 /64,换末位地址不能换额度)。
    登录、注册、SSO、管理台登录共用 —— 曾经各写各的,管理台与 SSO 漏了 /64。"""
    s = str(ip or "").strip()
    if not s:
        return "unknown"
    n = norm_ip(s)                  # 先规范化:IPv4 映射地址(::ffff:a.b.c.d)按 IPv4 计,
    if n is None:                   # 否则会被当成 IPv6 一律落进 ::/64 —— 全体 IPv4 访客共用一桶
        return s[:45]
    if ":" in n:
        return str(ipaddress.ip_network(f"{n}/64", strict=False))
    return n


def describe(trust_xff: bool = True) -> str:
    """启动横幅 / 管理台用的一句话口径。"""
    if not trust_xff:
        return "只认直连地址(XFF 全部忽略)"
    nets, everyone = _conf()
    if everyone:
        return "⚠ 无条件采信 XFF(STA_TRUSTED_PROXIES=*;直连部署下可被伪造)"
    if not nets:
        return "只认直连地址(STA_TRUSTED_PROXIES=none)"
    return f"直连地址;仅当对端属可信代理({_cache['raw']})时采信 XFF"
