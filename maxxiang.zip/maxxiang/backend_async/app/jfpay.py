"""
jfpay.py — 九法 VIP 在线充值(4.2.0)· 支付网关交互层
================================================================================
整体移植自 `fanxing-admin/backend/app/services/recharge_service.py`,改三处、
**逐条继承其余全部安全不变量**(那些不变量都是繁星踩过的真实坑,不是理论洁癖):

  改动三处
    ① HTTP 客户端 urllib(同步)→ aiohttp(异步)—— 九法全事件循环,
       同步 urllib 会阻塞整个 web 进程。
    ② 网关口径 type: proxy → **tulong**(与繁星代理余额充值物理隔离,账目不串)。
    ③ 到账动作:给 sys_account.balance 加钱 → 调 jfvip.grant_by_order()
       (九法VIP续期 + 赠送小叮当,单事务)。

  逐条继承的安全不变量
    1. **金额单一真源**:订单 amount 一律取网关响应的 `price`,缺失/非法/越界
       一律 502 拒绝下单,**绝不回退到用户请求金额**。回退即"凭空入账"漏洞:
       gw price < 请求价 → 用户少付我们多记(可被薅);gw price > 请求价 →
       用户多付我们少记(差额无据可查)。两者都直接破坏
       「用户付了多少 = 到账多少」的会计恒等式。
    2. **到账只由后端向网关查证**:绝不凭前端一句"已支付"。
    3. **时间单位自适应**:实测网关 currentTime/expireTime 有时秒有时毫秒
       (>=1e12 视作毫秒),且网关钟与本机钟不保证一致 —— 故**只取窗口长度**
       (expire-current)落到本地 TTL。这是繁星修过的"倒计时几千万分钟 /
       到期算到 2082 年"的根因。
    4. **1062 = 复用而非报错**:网关对"同账号+同金额+短时间"返回**同一个**
       orderNo(其自带幂等去重),我们的 uk_order 必然冲突。六分支复用逻辑见
       `_reuse_after_dup`,且**必须在 FOR UPDATE 行锁下判定**,否则会把并发
       已结算成 paid 的订单翻回 pending。
    5. **查单顺序:先问网关,再判本地过期**。旧实现先按本地时钟标 expired,
       会把"扫码已付、网关已认、只是确认慢几秒"的订单误判为过期。
    6. `_mark_expired` 用**条件 UPDATE**(WHERE status='pending'),
       防止把并发已结算的 paid 覆盖成 expired。
    7. **过期恢复窗**:expire_time + recover_window 内仍给一次网关复查,捞回漏账。
    8. **对账兜底** reconcile:前端轮询停了(关弹窗/切页/最后一次请求失败)时,
       由后端亲自向网关查证把卡住的订单救回来。
    9. **网络调用一律在事务之外**(持锁期间零 HTTP)。

  新增护栏(繁星没有、九法需要)
    · 下单限频:繁星面向可信代理,九法面向**任意注册用户(含 free 档)**,
      不限频等于替人白刷网关(jfvip.order_rate_ok)。
    · 档位快照落单:订单行冗余 jf_hours/dd_hours,改价不影响在途单。
"""
from __future__ import annotations

import contextlib
import json
import secrets
import time
from datetime import datetime, timedelta
from typing import Any, Dict, Optional, Tuple

import aiohttp

try:
    import pymysql.err as _pymysql_err     # 唯一键冲突的类型判定(1062)
except Exception:                          # noqa: BLE001
    _pymysql_err = None                     # 未装驱动:退化为错误码/文案判定

from . import jfvip, userauth

# 繁星测试模式用的 1×1 透明 PNG(base64,无 data: 前缀)。
# 模拟模式下作占位二维码,让前端弹窗与真实流程完全一致。
_PLACEHOLDER_QR = (
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA"
    "60e6kgAAAABJRU5ErkJggg==")

_session: Optional[aiohttp.ClientSession] = None


def _timeout(override: Optional[float] = None) -> aiohttp.ClientTimeout:
    """按**当前**配置产出超时。

    ⚠ 复审修正:初版把 ClientTimeout 绑在 ClientSession 上,而 session 长驻到
    进程退出 —— `jf_pay_timeout_s` 在注册表里标着 🟢 HOT(原地即生效),实际
    改了**永远不会生效**。注册表是运维判断的唯一依据,标错等于给假信息。
    现改为**每请求**传当前值(aiohttp 支持 per-request timeout),声明与行为一致。
    """
    v = float(override if override else
              getattr(userauth.UA.cfg, "jf_pay_timeout_s", 10.0))
    return aiohttp.ClientTimeout(total=max(1.0, v))


async def _get_session() -> aiohttp.ClientSession:
    global _session
    if _session is None or _session.closed:
        # 刻意**不**在 session 上绑 timeout —— 见 _timeout() 注:那会让热更失效。
        _session = aiohttp.ClientSession(
            connector=aiohttp.TCPConnector(limit=16, ttl_dns_cache=300))
    return _session


async def close() -> None:
    global _session
    if _session is not None and not _session.closed:
        with contextlib.suppress(Exception):
            await _session.close()
    _session = None


def _base() -> str:
    return str(getattr(userauth.UA.cfg, "jf_pay_base", "")).rstrip("/")


def _type() -> str:
    return str(getattr(userauth.UA.cfg, "jf_pay_type", "tulong"))


def _simulate() -> bool:
    return bool(getattr(userauth.UA.cfg, "jf_pay_simulate", False))


# ── 网关 HTTP ────────────────────────────────────────────────────────────────
async def _gw_post(path: str, payload: dict, query: Optional[dict] = None
                   ) -> Tuple[str, dict]:
    """POST 网关。返回 (错误码|'', 响应)。所有 /api/order/* 统一带 type=<口径>。"""
    q = {"type": _type()}
    if query:
        q.update(query)
    sess = await _get_session()
    # ★ ensure_ascii=False + UTF-8 字节:网关明确要求文本字段直接收 UTF-8,
    #   而非 json.dumps 默认的 \uXXXX 转义(那是 UCS-2 转义形式,对网关是另一种字符流)。
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    try:
        async with sess.post(_base() + path, params=q, data=body,
                             timeout=_timeout(),
                             headers={"Content-Type": "application/json; charset=utf-8"}
                             ) as resp:
            text = await resp.text()
            if resp.status >= 400:
                try:
                    err = json.loads(text)
                    msg = err.get("error") or err.get("detail") or f"HTTP {resp.status}"
                except Exception:      # noqa: BLE001
                    msg = f"支付网关返回 HTTP {resp.status}"
                return "gateway_error", {"message": str(msg)[:200]}
            try:
                return "", json.loads(text)
            except Exception:          # noqa: BLE001
                return "gateway_error", {"message": "支付网关返回非 JSON"}
    except Exception as e:             # noqa: BLE001
        print(f"[九法VIP] 网关下单失败: {e!r}")
        return "gateway_error", {"message": "无法连接支付网关,请稍后重试"}


async def _gw_get(path: str, params: dict, timeout: Optional[float] = None
                  ) -> Tuple[str, dict]:
    q = {"type": _type()}
    q.update(params or {})
    sess = await _get_session()
    try:
        async with sess.get(_base() + path, params=q,
                            timeout=_timeout(timeout)) as resp:
            text = await resp.text()
            try:
                return "", json.loads(text)
            except Exception:          # noqa: BLE001
                return "gateway_error", {"message": "支付网关返回非 JSON"}
    except Exception as e:             # noqa: BLE001
        # 查单失败不该让前端中断轮询 —— 视作"暂未确认",下次再查
        print(f"[九法VIP] 网关查单失败: {e!r}")
        return "gateway_error", {"message": "查询支付状态失败"}


def _to_unix_s(v: Any) -> Optional[int]:
    """网关时间值归一为 unix 秒。>=1e12 视作毫秒(≈2001 年的毫秒时间戳)。"""
    if v is None:
        return None
    try:
        x = int(v)
    except (TypeError, ValueError):
        return None
    return x // 1000 if x >= 1_000_000_000_000 else x


def _ttl_from(resp: dict) -> int:
    """只取**窗口长度**落到本地 TTL —— 不依赖网关钟与本机钟一致。
    合理窗口 1s ≤ w ≤ 24h,越界走兜底(与繁星 300s 默认一致)。"""
    fallback = int(getattr(userauth.UA.cfg, "jf_pay_simulate_ttl_s", 300))
    cur, exp = _to_unix_s(resp.get("currentTime")), _to_unix_s(resp.get("expireTime"))
    if cur is not None and exp is not None:
        w = exp - cur
        if 1 <= w <= 24 * 3600:
            return int(w)
    return fallback


# ── 下单 ─────────────────────────────────────────────────────────────────────
async def create_order(uid: int, user_name: str, plan_code: str, ip: str
                       ) -> Tuple[str, dict]:
    """发起充值。返回 (错误码|'', {orderNo,qrCode,amount,expireTime,...})。"""
    if not jfvip.enabled():
        return "disabled", {}
    plan = jfvip.plan_of(plan_code)
    if plan is None:
        return "bad_plan", {}
    if not await jfvip.order_rate_ok(uid):
        return "throttled", {}

    now = datetime.now()
    if _simulate():
        # 模拟模式:本地生成订单与占位二维码,不调网关。
        # 无网关 ⇒ 无 price 协商,档位价即实际金额(设计本意:无外网时验证完整链路)。
        order_no = "SIM" + secrets.token_hex(10)
        qr = _PLACEHOLDER_QR
        ttl = int(getattr(userauth.UA.cfg, "jf_pay_simulate_ttl_s", 300))
        is_sim, amount = 1, float(plan["price"])
    else:
        err, resp = await _gw_post("/api/order/create", {
            "product": f"九法VIP·{plan['name']}",
            "days": max(1, int(plan["jfHours"]) // 24),
            "account": str(user_name),
            "price": float(plan["price"]),
        }, query={"price": float(plan["price"])})
        if err:
            return "gateway", resp
        if not resp.get("success") or not resp.get("orderNo") or not resp.get("qrCode"):
            return "gateway", {"message": str(resp.get("error")
                                              or "支付网关未返回有效订单")[:200]}
        order_no, qr = str(resp["orderNo"]), str(resp["qrCode"])

        # ★★★ 实际付款金额以网关 price 为**单一真源** ★★★
        # 用户提议的价只用于:①调网关时透传;②边界预检。绝不作为入账依据。
        raw = resp.get("price")
        if raw is None:
            return "gateway", {"message": "支付网关响应缺少 price 字段,无法确定实际付款金额"}
        try:
            amount = round(float(raw), 2)
        except (TypeError, ValueError):
            return "gateway", {"message": f"支付网关返回的 price 格式不正确:{raw!r}"}
        # 防御性边界:即使网关返回 0 / 负数 / 天文数字也不放行。
        # 上界取档位价 ×3(留活动/汇率余量),下界 0.01。
        if amount <= 0 or amount > max(1.0, float(plan["price"])) * 3:
            return "gateway", {"message": f"支付网关返回的金额 ¥{amount} 越界,疑似网关数据异常"}
        ttl, is_sim = _ttl_from(resp), 0

    expire_at = now + timedelta(seconds=int(ttl))     # 仅用于回给前端展示
    try:
        # ★ expire_time 用**库钟**写(DATE_ADD(NOW(), …)),与同行的 create_time 同源。
        #   复审修正:初版把 create_time 交给 NOW()、expire_time 却写 Python 的
        #   datetime.now() —— 同一行的两个时间戳来自两个钟。而 reconcile 又拿
        #   **库钟**去比 expire_time(WHERE expire_time >= DATE_SUB(NOW(), …)),
        #   web 与 DB 一有时钟偏差,对账窗口就是错的(偏差多大窗口就错多少)。
        #   项目对此有明确纪律:「到期判定用**数据库的钟**,不受 web 机时区影响」
        #   (LOGIN-SYSTEM.md §3)。这里对齐同一纪律。
        await userauth._q(
            "INSERT INTO guantai_jf_order (gateway_order_no, user_id, user_name, "
            "plan_code, jf_hours, dd_hours, amount, status, credited, is_simulate, "
            "ip, create_time, expire_time) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s,'pending',0,%s,%s,NOW(),"
            "        DATE_ADD(NOW(), INTERVAL %s SECOND))",
            (order_no, int(uid), str(user_name)[:50], plan["code"],
             int(plan["jfHours"]), int(plan["ddHours"]), amount, int(is_sim),
             str(ip)[:45], int(ttl)))
    except Exception as e:             # noqa: BLE001
        # 1062:网关对同账号+同金额短时间内的重复请求返回**同一 orderNo**
        # (其自带幂等去重)。这是设计本意,不是错误条件 —— 复用本地已有订单。
        # 判定用「异常类型 ∪ 错误码 ∪ 文案」三重兜底:单靠字符串匹配会被
        # 驱动版本/语言环境的文案差异绕过,那时会退化成 500 而不是复用,
        # 用户表现为"点两次充值第二次报错"。
        _dup = isinstance(e, getattr(_pymysql_err, "IntegrityError", ()))
        _code = (e.args[0] if getattr(e, "args", None) else None)
        if _dup or _code == 1062 or "1062" in str(e) or "Duplicate" in str(e):
            return await _reuse_after_dup(uid, order_no, qr, amount, expire_at,
                                          is_sim, int(ttl))
        print(f"[九法VIP] 落单失败: {e!r}")
        return "db", {"message": "创建订单失败,请稍后重试"}

    return "", {"orderNo": order_no, "qrCode": qr, "amount": amount,
                "currentTime": int(now.timestamp() * 1000),
                "expireTime": int(expire_at.timestamp()),
                "simulate": bool(is_sim), "plan": plan["code"],
                "planName": plan["name"]}


async def _reuse_after_dup(uid: int, order_no: str, qr: str, amount: float,
                           expire_at: datetime, is_sim: int, ttl: int = 300
                           ) -> Tuple[str, dict]:
    """处理"网关返回同 orderNo"造成的本地 1062。六分支,**全部在行锁下判定**。

    并发安全:以 FOR UPDATE 读取已存在订单,使状态判断与翻转严格串行于结算路径
    (_grant_tx 也对同一行加 FOR UPDATE)。杜绝"把刚被并发结算成 paid 的订单
    又无条件翻回 pending"的竞态。
    """
    pool = await userauth._ensure_pool()
    if pool is None:
        return "db", {"message": "用户库暂时不可用"}
    import aiomysql as _my
    conn = await pool.acquire()
    try:
        await conn.begin()
        try:
            async with conn.cursor(_my.DictCursor) as cur:
                await cur.execute(
                    "SELECT id, user_id, amount, status, expire_time, is_simulate "
                    "FROM guantai_jf_order WHERE gateway_order_no=%s FOR UPDATE",
                    (order_no,))
                row = await cur.fetchone()
                if row is None:        # ① UNIQUE 说重了却查不到 = DB 异常
                    await conn.rollback()
                    return "db", {"message": "订单唯一键冲突但未找到已存在订单,请重试"}
                if int(row["user_id"]) != int(uid):   # ② 跨账号:绝不暴露他人订单
                    await conn.rollback()
                    return "conflict", {"message": "支付网关订单号冲突,请稍后重试"}
                if abs(float(row["amount"]) - float(amount)) > 0.005:  # ③ 同号不同价
                    await conn.rollback()
                    return "conflict", {"message": "网关订单号冲突且金额不一致,请稍后重试"}
                if row["status"] == "paid":           # ④ 已支付:告知,不再弹码
                    await conn.rollback()
                    return "conflict", {"message": f"该笔(¥{float(row['amount']):.2f})"
                                                   f"已支付到账,无需重复发起"}
                if row["status"] == "expired":        # ⑤ 本地过期但 gw 仍返同号
                    # ★★ 4.2.3 修正:原先这里写的是 Python 的 expire_at(**web 机钟**),
                    #    而 create_order 的 INSERT 用的是 DATE_ADD(NOW(),…)(**库钟**)。
                    #    同一张表同一列两条写路径两把钟,而 _own_order 的
                    #    past_expire / past_grace / in_recover 与 reconcile 的回溯窗
                    #    **全部拿库钟去比这一列**。实测(库钟拨快 8h):库钟写法
                    #    past_grace=0 / in_recover=1 / 在回溯窗内;web 钟写法
                    #    past_grace=1 / in_recover=0 / 出回溯窗 —— 这笔单落库那一刻
                    #    就已"过了宽限期、出了恢复窗、出了对账窗",用户此时付款
                    #    没有任何自动路径能救回。现与兄弟分支同源。
                    await cur.execute(
                        "UPDATE guantai_jf_order SET status='pending', "
                        "expire_time=DATE_ADD(NOW(), INTERVAL %s SECOND) "
                        "WHERE id=%s AND status='expired'", (int(ttl), row["id"]))
            await conn.commit()
            # ⑥ pending(或刚翻回 pending):复用,把本次现拉的二维码回给前端
            # ★ 4.2.3:回给前端的 expireTime 必须是 **web 机钟** —— 前端拿它与
            #   Date.now() 相减做倒计时。这与上面"落库用库钟"不矛盾:两个值
            #   两个用途、两个参照系,原先用 max() 把它们混在一起比大小才是错的。
            return "", {"orderNo": order_no, "qrCode": qr, "amount": float(row["amount"]),
                        "currentTime": int(time.time() * 1000),
                        "expireTime": int(expire_at.timestamp()),
                        "simulate": bool(int(row["is_simulate"])), "reused": True}
        except BaseException:
            with contextlib.suppress(Exception):
                await conn.rollback()
            raise
    finally:
        pool.release(conn)


# ── 查单 + 结算 ──────────────────────────────────────────────────────────────
async def _mark_expired(order_no: str) -> None:
    """条件 UPDATE 翻过期。**必须带 WHERE status='pending'** ——
    无条件写会把并发已结算的 paid 覆盖成 expired(漏账 + 状态错乱)。"""
    with contextlib.suppress(Exception):
        await userauth._q("UPDATE guantai_jf_order SET status='expired' "
                          "WHERE gateway_order_no=%s AND status='pending'", (order_no,))


async def _own_order(uid: int, order_no: str) -> Optional[dict]:
    """取本人订单,并**由数据库**顺带算好三个时间判定 —— 全程库钟,不掺 web 机时钟。
      · past_expire  : 是否已过 expire_time
      · past_grace   : 是否已过 expire_time + 结算宽限期
      · in_recover   : 是否仍在 expire_time + 复查窗内
    """
    c = userauth.UA.cfg
    grace = int(getattr(c, "jf_settle_grace_s", 90))
    rec = int(getattr(c, "jf_recover_window_s", 3600))
    return await userauth._q(
        "SELECT *, "
        " (expire_time IS NOT NULL AND NOW() > expire_time) AS past_expire, "
        " (expire_time IS NOT NULL AND "
        "  NOW() > DATE_ADD(expire_time, INTERVAL %s SECOND)) AS past_grace, "
        " (NOW() <= DATE_ADD(IFNULL(expire_time, create_time), "
        "                    INTERVAL %s SECOND)) AS in_recover "
        " FROM guantai_jf_order WHERE gateway_order_no=%s AND user_id=%s",
        (grace, rec, str(order_no), int(uid)), fetch="one")


def _in_recover_window(row: dict) -> bool:
    """已过期订单是否仍在"可向网关复查恢复"的窗内(模拟单不涉网关,永不复查)。
    判定值由 _own_order 在**库钟**下算好,这里只读结果。"""
    if int(row.get("is_simulate") or 0):
        return False
    return bool(int(row.get("in_recover") or 0))


async def query_and_settle(uid: int, user_name: str, order_no: str) -> Tuple[str, dict]:
    """查单 + 必要时开通。网络调用在事务外;确认已支付才进 _grant_tx 的事务。"""
    if not jfvip.enabled():
        return "disabled", {}
    row = await _own_order(uid, order_no)
    if row is None:
        return "not_found", {}

    if row["status"] == "paid":
        st = await jfvip.vip_state(uid)
        return "", {"paid": True, "expired": False, "amount": float(row["amount"]),
                    "vipUntil": st.get("vipUntil", "")}

    if row["status"] == "expired":
        # 漏账兜底:过期订单在恢复窗内仍给一次网关复查 —— 用户确实付了
        # (网关晚到确认、或"查单那刻网关尚未反映付款、我们标了过期、随后到账")
        # 就必须入账,绝不因本地曾标过期而漏账。
        if _in_recover_window(row):
            err, resp = await _gw_get("/api/order/status", {"orderNo": order_no})
            if not err and resp.get("success") and resp.get("paid"):
                gerr, out = await jfvip.grant_by_order(uid, user_name, order_no)
                if not gerr:
                    return "", {"paid": True, "expired": False,
                                "amount": float(row["amount"]),
                                "vipUntil": out.get("vipUntil", ""),
                                "dueTime": out.get("dueTime", "")}
        return "", {"paid": False, "expired": True, "amount": float(row["amount"])}

    # 模拟订单不走网关,只能由 simulate_pay 推进;本地到期即视作过期
    if int(row["is_simulate"] or 0):
        if int(row.get("past_expire") or 0):        # 库钟判定
            await _mark_expired(order_no)
            return "", {"paid": False, "expired": True, "amount": float(row["amount"])}
        return "", {"paid": False, "expired": False, "amount": float(row["amount"])}

    # 正式订单仍 pending:★ 先向网关查证真实状态,再决定是否按本地时钟判过期 ★
    # 旧实现把"本地是否过期"排在网关查证之前 —— 一次落在本地到期时刻之后的查单,
    # 会抢在问网关前就标 expired,哪怕这笔其实已支付、网关也认了。
    err, resp = await _gw_get("/api/order/status", {"orderNo": order_no})
    if not err and resp.get("success") and resp.get("paid"):
        gerr, out = await jfvip.grant_by_order(uid, user_name, order_no)
        if gerr:
            print(f"[九法VIP] 已确认支付但开通失败({gerr}),订单 {order_no} —— "
                  f"下次查单/对账会重试(幂等)")
            return "", {"paid": False, "expired": False, "amount": float(row["amount"]),
                        "settling": True}
        return "", {"paid": True, "expired": False, "amount": float(row["amount"]),
                    "vipUntil": out.get("vipUntil", ""), "dueTime": out.get("dueTime", "")}
    if not err and resp.get("success") and resp.get("expired"):
        await _mark_expired(order_no)
        return "", {"paid": False, "expired": True, "amount": float(row["amount"])}

    # 网关既未确认已付、也未说过期:本地已过期**且超出结算宽限期**才判过期。
    # 宽限期内保持 pending,给网关异步确认留时间(前端此时继续宽限轮询)。
    if int(row.get("past_grace") or 0):             # 库钟判定:已过 expire_time + 宽限期
        await _mark_expired(order_no)
        return "", {"paid": False, "expired": True, "amount": float(row["amount"])}
    return "", {"paid": False, "expired": False, "amount": float(row["amount"])}


async def simulate_pay(uid: int, user_name: str, order_no: str) -> Tuple[str, dict]:
    """模拟支付成功 —— 仅 jf_pay_simulate=true 时可用,且只对模拟订单生效。
    走与真实支付**完全相同**的开通事务,因此同样幂等、同样落流水。"""
    if not _simulate():
        return "forbidden", {}
    row = await _own_order(uid, order_no)
    if row is None:
        return "not_found", {}
    if not int(row["is_simulate"] or 0):
        return "not_simulate", {}
    if int(row.get("past_expire") or 0) and row["status"] == "pending":
        await _mark_expired(order_no)
        return "expired", {}
    gerr, out = await jfvip.grant_by_order(uid, user_name, order_no)
    if gerr:
        return gerr, {}
    return "", {"paid": True, "expired": False, "amount": float(row["amount"]),
                "vipUntil": out.get("vipUntil", ""), "dueTime": out.get("dueTime", "")}


async def reconcile(uid: int, user_name: str) -> dict:
    """对账兜底:重查本人最近的 pending / 恢复窗内 expired 订单,救回已付的。

    动机:到账翻转只发生在 query_and_settle(前端轮询触发)。若前端在"网关确认
    支付"之前就停了轮询(本地倒计时到期、关弹窗、切走页面、最后一次轮询失败),
    这笔其实已付的订单会一直卡住。本函数让"打开开通记录"或点"对账"时,由
    **后端亲自向网关查证**把它们找回 —— 安全不变量不变(绝不凭前端断言入账)。
    """
    if not jfvip.enabled():
        return {"checked": 0, "recovered": 0, "expired": 0}
    c = userauth.UA.cfg
    look = int(getattr(c, "jf_reconcile_lookback_s", 86400))
    rec = int(getattr(c, "jf_recover_window_s", 3600))
    cap = int(getattr(c, "jf_reconcile_max", 10))
    to = float(getattr(c, "jf_reconcile_timeout_s", 6.0))
    rows = await userauth._q(
        "SELECT gateway_order_no FROM guantai_jf_order "
        "WHERE user_id=%s AND is_simulate=0 AND ("
        "  (status='pending' AND create_time >= DATE_SUB(NOW(), INTERVAL %s SECOND)) "
        "  OR (status='expired' AND expire_time IS NOT NULL "
        "      AND expire_time >= DATE_SUB(NOW(), INTERVAL %s SECOND))) "
        "ORDER BY id DESC LIMIT %s", (int(uid), look, rec, cap), fetch="all") or []
    # candidates = 库里**确实存在**的待救回订单数(4.2.2 复审补)。
    # 前端据此区分两种 checked=0:「没有单可救」(标记已陈旧,应清掉)与
    # 「有单但网关全查失败」(标记必须留着下次再试)。少了它,一个陈旧标记会
    # 让每次开机都白发一次 POST,连发 24 小时,还会吃掉 reconcile 的限频配额。
    candidates = len(rows)
    checked = recovered = expired = 0
    for r in rows:
        no = str(r["gateway_order_no"])
        err, resp = await _gw_get("/api/order/status", {"orderNo": no}, timeout=to)
        if err:                        # 单笔失败不拖垮整轮
            continue
        checked += 1
        try:
            if resp.get("success") and resp.get("paid"):
                gerr, _ = await jfvip.grant_by_order(uid, user_name, no)
                if not gerr:
                    recovered += 1
            elif resp.get("success") and resp.get("expired"):
                await _mark_expired(no)
                expired += 1
        except Exception:              # noqa: BLE001
            continue
    return {"candidates": candidates, "checked": checked,
            "recovered": recovered, "expired": expired}
