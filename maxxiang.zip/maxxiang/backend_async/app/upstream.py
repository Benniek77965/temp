"""
upstream.py — 上游九法接口的异步客户端(aiohttp)
================================================================================
用一个 aiohttp.ClientSession(带连接池上限)替代旧引擎里每房一个的
requests.Session。单会话即可承载数千并发 POST,复用连接、复用 DNS,
内存与调度开销比「一房一线程 + 阻塞 requests」低几个数量级。

行为与旧 SpellTamerClient._post 对齐:
  · 相同请求头(浏览器指纹头 + x-auth-*);
  · 读 X-Error-Code / X-Error-Message 头做业务错误日志;
  · 200 才解析 JSON;非 200 里若含「本局刚结束」衔接窗口错误码则安静返回 None;
  · 401/403 视为票据过期,记 error(上层可触发换票据流程)。

注:酷狗游戏数据接口(MainPage/RoundAward/…)对标准客户端可用;个别**登录态**
接口才会因 TLS 指纹拦截非浏览器客户端(见 README「TLS 指纹」)。若上游未来对
数据接口也加指纹校验,可把 connector 换成 curl_cffi 的异步实现,其余不动。
"""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

import aiohttp

from .constants import (DEFAULT_BROWSER_HEADERS, EP_GAME_HISTORY, EP_LAMP_LIST,
                        EP_MAIN_PAGE, EP_POP_LIST, EP_ROUND_AWARD)

log = logging.getLogger("upstream")


class AuthExpired(Exception):
    """上游返回 401/403:票据可能过期(上层据此告警/换票据)。"""


class Upstream:
    def __init__(self, base_url: str, headers: Dict[str, str],
                 timeout: float = 15.0, verify_tls: bool = False,
                 conn_limit: int = 500, conn_per_host: int = 500):
        self._base = base_url.rstrip("/")
        self._timeout = aiohttp.ClientTimeout(total=timeout)
        self._verify = verify_tls
        self._conn_limit = conn_limit
        self._conn_per_host = conn_per_host
        self._base_headers = dict(DEFAULT_BROWSER_HEADERS)
        self._base_headers.update(headers or {})
        self._session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self) -> "Upstream":
        await self.start()
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()

    async def start(self) -> None:
        connector = aiohttp.TCPConnector(
            limit=self._conn_limit, limit_per_host=self._conn_per_host,
            ttl_dns_cache=300, ssl=None if self._verify else False)
        self._session = aiohttp.ClientSession(
            connector=connector, timeout=self._timeout, headers=self._base_headers)

    async def close(self) -> None:
        if self._session:
            await self._session.close()
            self._session = None

    def update_auth(self, headers: Dict[str, str]) -> None:
        """热更新鉴权头(换票据时用);对新建 session 生效,当前 session 逐请求带头亦可。"""
        self._base_headers.update(headers or {})
        if self._session:
            self._session.headers.update(headers or {})

    async def _post(self, endpoint: str, payload: Dict[str, Any]
                    ) -> Optional[Dict[str, Any]]:
        assert self._session is not None, "Upstream 未 start()"
        name = endpoint.rsplit("/", 1)[-1]
        body = json.dumps(payload, separators=(",", ":"))
        try:
            async with self._session.post(self._base + endpoint, data=body) as resp:
                text = await resp.text()
                status = resp.status
                err_code = resp.headers.get("X-Error-Code") or resp.headers.get("x-error-code")
                err_msg = (resp.headers.get("X-Error-Message")
                           or resp.headers.get("X-Error-Msg")
                           or resp.headers.get("x-error-message"))
        except aiohttp.ClientError as e:
            log.error("[%s] 请求异常: %r", name, e)
            return None
        except Exception as e:  # asyncio.TimeoutError 等
            log.error("[%s] 请求异常: %r", name, e)
            return None

        if err_code and err_code not in ("0", ""):
            log.warning("[%s] 业务错误 code=%s msg=%s", name, err_code, err_msg)

        if status != 200:
            snippet = text[:200]
            if '"code":100005' in snippet or "本局已结束" in snippet:
                log.info("[%s] 本局刚结束(衔接窗口),稍后重试", name)
                return None
            log.warning("[%s] HTTP %s: %s", name, status, snippet)
            if status in (401, 403):
                log.error("⚠️  x-auth-ticket 可能已过期,请更新票据")
                raise AuthExpired(f"{name} HTTP {status}")
            return None

        if not text.strip():
            return {}
        try:
            return json.loads(text)
        except ValueError:
            log.debug("[%s] 非 JSON 响应: %s", name, text[:200])
            return {"_raw": text}

    # ── 各端点(参数与旧引擎一致) ──────────────────────────────────────────────
    async def main_page(self, activity_id: int, room_id: str):
        return await self._post(EP_MAIN_PAGE,
                                {"activityId": activity_id, "roomId": str(room_id)})

    async def game_history(self, activity_id: int, room_id: str):
        return await self._post(EP_GAME_HISTORY,
                                {"activityId": activity_id, "roomId": str(room_id)})

    async def round_award(self, activity_id: int, room_id: str, round_id: str):
        return await self._post(EP_ROUND_AWARD,
                                {"activityId": activity_id, "roundId": str(round_id),
                                 "roomId": str(room_id)})

    async def pop_list(self, activity_id: int):
        return await self._post(EP_POP_LIST, {"activityId": activity_id})

    async def lamp_list(self, activity_id: int, room_id: str):
        return await self._post(EP_LAMP_LIST,
                                {"activityId": activity_id, "roomId": str(room_id)})
