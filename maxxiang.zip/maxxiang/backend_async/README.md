# 九法观测台 · 异步后端（backend_async）

> **5.3.0 起后台入口可配**:页面在 `/{入口}`、管理接口在 `/api/{入口}/*`,`{入口}` = `config.yaml` 的 `admin.path`(默认 `admin-xdd`,`.env` 的 `STA_ADMIN_PATH` 可覆盖)。本文中的 `{入口}` 均指它;旧地址 `/admin`、`/admin.html`、`/api/admin/*` 按不存在的路径应答。唯一例外:外部发卡接口 `POST /api/admin/jfvip/cards/issue` 是机器契约,地址恒定。详见根 `README.md`「管理后台:入口、账号与人机验证」。

把「小叮当数据 / 九法观测台」的直播抓取从**一房一线程 + SQLite + ThreadingHTTPServer**
重构为面向 **5000+ 主播并发**的异步架构。核心目标：抛弃线程模型、抓取与服务分离、
承接高频写入、削平请求毛刺 —— 预测**算法**原样复用、零改动（仅把引擎的
时间口径钉死为北京时间 UTC+8）。

---

## 1. 为什么重构

旧架构的瓶颈（`server.py` + `jiufa_backend.py` + `jiufa_data/spell_tamer_monitor.py`）：

| 维度 | 旧实现 | 5000 房时的问题 |
|---|---|---|
| 并发模型 | 每房一条常驻线程 `sleep→抓取→sleep` | 5000 线程 ≈ 数 GB 栈内存 + GIL 下调度抖动 |
| 抓取/服务 | 同进程 `ThreadingHTTPServer` 兼做抓取与 Web | 抓取洪峰拖垮页面响应,无法独立扩容 |
| 存储 | SQLite（单写者锁） | 高频并发写入锁争用,写入排队 |
| 请求节奏 | 各房独立定时,易在出怪秒对齐 | 数千请求同秒打向上游,毛刺触发限流/封禁 |

新架构用**四根支柱**逐一解决:

```
                    ┌─────────────────────────────────────────────┐
                    │                   Redis                      │
   ┌────────┐       │  延迟队列(ZSET) · 分布式令牌桶 · 房间名录     │       ┌──────────┐
   │ worker │◄─────►│  快照(snap:{room}) · 出怪频道(draws:{room}) │◄─────►│   web    │
   │ (N 个) │ 领任务 │                                              │ 读快照 │ FastAPI  │
   └───┬────┘ 限流   └───────────────────┬─────────────────────────┘  订阅  │ 只读+SSE │
       │ 抓取                            │                                 └────┬─────┘
       ▼                                 ▼ 高频写入                             │ 读历史/预测
  ┌─────────┐                     ┌─────────────┐                              │
  │ 上游游戏 │                     │ PostgreSQL  │◄─────────────────────────────┘
  │  API    │                     │ (asyncpg)   │
  └─────────┘                     └─────────────┘
```

1. **asyncio + aiohttp 单事件循环**替代一房一线程。每房的下一步(刷 MainPage 或抓某局
   RoundAward)是一个**到期任务**,worker 只在到期时取出、跑一小段异步 I/O、再排下一步。
   任意时刻真正「在飞」的只有少量任务,内存/调度开销比线程模型低几个数量级。
2. **Redis** 做任务分发(延迟队列 ZSET + 租约式原子领取,多 worker 去重、崩溃自动重投)、
   **分布式令牌桶限流**(把对上游的全局 QPS 钳在上限)、房间名录、实时快照与 SSE pub/sub。
3. **PostgreSQL(asyncpg)** 承接高频并发写入,替代 SQLite 单写者锁。
4. **错峰调度**:每房的抓取排在**它自己的出怪节奏**上并叠加随机抖动。即便许多房出怪
   时刻相近,请求也被抹开成一个窗口,配合全局令牌桶把毛刺削平成平滑曲线。

抓取(worker)与服务(web)彻底分离:worker 只写、web 只读,两者都能独立水平扩展。

---

## 2. 目录结构

```
backend_async/
├── app/                    （21 个模块，下表为全量）
│   ├── settings.py        配置加载(env > config.yaml > 默认)
│   ├── config_registry.py 配置注册表(唯一真相源,Schema-Driven)
│   ├── config_center.py   配置中枢(运行时覆盖层 + 热更协议)
│   ├── constants.py       上游端点 / 时序常量 / 9 只妖兽·法术元数据
│   ├── ratelimit.py       分布式令牌桶(Redis Lua 原子;削峰核心之一)
│   ├── admission.py       批量准入控制器(「同时添加数千房」的削峰核心)
│   ├── redis_bus.py       延迟队列 / 租约领取 / 名录 / 快照 / SSE 频道
│   ├── db.py              PostgreSQL 数据层(连接池 + 建表 + 读写 DAO)
│   ├── upstream.py        aiohttp 单会话上游客户端(替代 per-room requests.Session)
│   ├── predictor_bridge.py【复用】旧预测引擎的适配层 —— 预测逻辑零改动
│   ├── scheduler.py       错峰调度的纯计算(可单测)
│   ├── worker.py          异步抓取 worker(claimer + consumers + janitor + discovery)
│   ├── discovery.py       直播间自动发现(遍历繁星在播列表,严格JSON+正则兜底解析)
│   ├── starmeta.py        繁星资料 / 房号归一(异步,尽力而为,失败优雅降级)
│   ├── web.py             FastAPI 只读服务(复刻旧 /api/* 契约 + SSE + SPA 兜底)
│   ├── userauth.py        登录系统:外部 MySQL 用户库(tb_user)识别 + 服务端会话;
│   │                        注册系统与链接快速登录(SSO)亦在此实现
│   ├── powproof.py        执行证明变换 T(L2 proof-of-browser 的单一真相源)
│   ├── jfvip.py           九法 VIP 分层与开通(唯一一处 tb_user UPDATE 在此)
│   ├── jfpay.py           九法 VIP 在线充值 · 支付网关交互层
│   ├── admin_api.py       管理台 API(/api/{入口}/*;外部发卡接口另以 /api/admin/jfvip/cards/issue 恒定地址挂载)
│   └── admin_auth.py      管理台鉴权(纯标准库 hmac/hashlib/secrets,零新依赖)
├── scripts/                （19 个,以下为常用节选）
│   ├── seed_rooms.py      批量注入监控房间(Redis 名录 + PG)
│   ├── smoke_e2e.py       Web 层端到端冒烟(ASGI,验证读写契约)
│   ├── smoke_worker.py    worker 抓取编排链集成冒烟(假上游驱动完整周期)
│   ├── smoke_auth.py      登录/注册/SSO 对真库(或 1:1 复刻库)的全流程烟测
│   ├── userdb_check.py    用户库体检(版本/字符集/权限/口令形态;--init 建表,
│   │                        --reg-preflight / --jfvip-preflight 上线前必跑)
│   ├── init_userdb.sql    guantai_* 新表的等价 DDL
│   ├── probe_award_path.py 出怪来源探针(实时抓取 vs GameHistory 回填口径)
│   ├── sim_hist_mode.py   hist-mode 的 H 矩阵仿真
│   └── *_jsdom.js         前端整机冒烟(交付版 index.html + app.js 在 jsdom 真 DOM 跑)
├── tests/                  （60 个 test_*.py;覆盖面见第 6 节)
├── deploy/
│   ├── Dockerfile         多阶段:精简 worker 镜像 + 带前端的 web 镜像
│   ├── docker-compose.yml postgres + redis + worker(可扩) + web + login
│   ├── web-entrypoint.sh  web 容器入口
│   └── login-entrypoint.sh login 容器入口(酷狗票据自动续期)
├── config.yaml            运行配置
├── deploy/.env.example    环境变量样例(STA_ 前缀;5.2.0 起与 deploy/.env 同目录)
├── requirements.txt       依赖(实测锁定版本)
└── README.md              本文
```

## 3. 新旧映射（前端零改动）

Web 层逐字段复刻旧 `jiufa_backend.handle_api` 的 JSON 契约,前端 SPA **无需修改**:

| 端点 | 旧来源 | 新来源 |
|---|---|---|
| `GET /api/live-rooms` | `build_live_rooms`（内存计时） | Redis 快照 + PG 兜底(**自动发现房不在此列**,见第 10 节) |
| `GET /api/rooms/{room}/history` | `db_history`（SQLite） | PostgreSQL（支持 `until` 半开区间参数 `[since, until)`,供按日回看;区间上界早于 now−1h 的冻结窗响应附 `immutable` 缓存头） |
| `GET /api/rooms/{room}/history/days` | *(旧版无)* | **按日回看**日目录（北京**起局日**口径 `(round_id+8h)/86400000`,与前端期号 dayNo 逐字一致;走 `(room_id, round_id)` 主键 index-only 聚合,零新索引;前端以「目录内除今天外是否有日」做导航门控 —— retention=1 时自动隐形） |
| `GET /api/rooms/{room}/prediction` | `db_prediction`（SQLite） | PostgreSQL(pending/record/accuracy) |
| `GET /api/rooms/{room}/config` | `spells_config`（读 room-321-config.json） | 同一模板,PG 无关 |
| `GET /api/rooms/{room}` | `build_summary` | PG latest |
| `GET /api/live-rooms/{room}/profile` | `build_profile`（繁星） | `starmeta` 异步繁星 |
| `POST /api/monitor/add|remove` | `MANAGER.add_room/remove_room` | 写 Redis 名录 + PG;**add 有准入限制**:仅允许后台已存在(近期直播过)的房,否则 400 提示(见 §10.1) |
| `POST /api/monitor/add-bulk` | *(旧版无)* | **批量准入**:去重+有界并发归一+批量写+首抓错峰(见第 9 节) |
| `GET /api/crawler/status` | `MANAGER` 内存态 | Redis 快照(附 retention/discovery 观测) |
| `GET /api/discovery/status` | *(旧版无)* | **自动发现**观测:开关/周期/发现房数/最近一轮统计(见第 10 节) |
| `GET /api/events`（SSE） | 进程内 EventBus | Redis pub/sub(`draws:{room}`)转发 |

回合对象(`round_from_row`)、九法阵配置、倍率/编号/法术名等字段与旧版**逐字段一致**,
妖兽元数据同源于引擎的 `BEASTS_BASE` + `DEFAULT_CUSTOM_IDS`。

---

## 4. 预测逻辑复用（不改一行算法）

用户要求「不改预测逻辑」。`app/predictor_bridge.py` **不重写**任何算法,而是直接
`import spell_tamer_monitor`,复用其 `Predictor`（6 模型 M1–M6 的 Hedge 加权）、
`BeastCatalog`、`PredictionConfig`,只做一件事:把预测器的每房状态
（`model_weights` / `explore_state`,原存旧 SQLite 的 `kv` 表）接到 PostgreSQL 上。

关键设计 —— **让预测器每次调用无状态**,从而可在多 worker 间安全流转:

```
处理某局出怪:
  ① 从 PG 读该房 predictor_state(kv)  →  播种进内存 KvStoreShim
  ② run_in_executor(结算上一局 → Hedge 更新权重)     # 纯计算,放线程池,不阻塞事件循环
  ③ run_in_executor(基于编号序列生成下一局预测)
  ④ 把 kv 的变更批量刷回 PG
```

`predict()` 是纯函数（编号序列 → 预测 dict），因此不依赖某个 worker 常驻内存,
天然适配水平扩展。回归测试 `test_predictor_bridge.py` 锁定了这条「读 PG 播种 → 计算 →
刷回 PG」链路可复现、权重能持续推进。

---

## 5. 运行

### 5.1 Docker Compose（推荐）

```bash
cd backend_async/deploy
cp .env.example .env             # 按需改：STA_AUTH_TICKET / 数据库密码 等
docker compose up -d --build     # 起 postgres + redis + worker + web

# 注入要监控的房间（短号会自动归一到真实房号）
docker compose run --rm seed 321 2678075

# 观测台
open http://localhost:5173
```

抓取吞吐不够时，**横向扩 worker**（共享 Redis 队列，自动去重 / 负载均衡 / 崩溃重投；
直接 `docker compose up` 时生效值是 `docker-compose.yml` 里的 `replicas: 10`；
改用一键部署脚本时，它每次 `up` 都按 `--workers`（默认 3）显式 `--scale` 覆盖之。
真机实测账本：1 万房 = 2.2 CPU 核，更大按下方公式加副本）：

```bash
docker compose up -d --build --scale worker=6   # --build:代码有改动时顺带重建镜像
docker compose up -d --scale worker=6           # 镜像没变时,免构建直接扩
```

**副本数怎么定(真机实测的 CPU 账本,不是闭眼值)**

真机模拟(真 Redis + 真 PostgreSQL + 未改动的 `app.worker` 进程 + 假上游;每房预填
一天历史以复现 `train_window_hours=24` 的稳态序列长度;retention≥1 天时序列长由训练窗决定,与保留天数无关)实测:

| 实测项 | 值 |
|---|---|
| **每局 worker CPU** | **11.2 ms**(其中预测引擎 2.9ms —— 序列 1728 条时) |
| 每局 PostgreSQL CPU | 2.7 ms |
| 每局 Redis CPU | 0.5 ms |
| 每房 Redis 内存 | ~2.8 KB |
| 每房每天磁盘 | ~3.78 MB(rounds 0.58 + predictions 3.20;后者 detail JSONB 占大头) |

于是 **1 万房 = 10000/50s = 200 局/s**:

    worker CPU = 200 × 11.2ms = **2.2 核**(全舰队)
    PG CPU     = 200 × 2.7ms  = 0.54 核
    Redis      = 0.1 核

worker 是单进程 Python(GIL),**单副本可用算力 ≈ 1 核**,故:

| 总房数(策展 + 自动发现留存) | worker 副本 | 说明 |
|---|---|---|
| ≤ 4000 | 2 | 1 个够跑,2 个是为了崩溃自愈零等待 |
| **~10000** | **4** | 负载 2.2 核 → 1.8 倍余量;挂 1 个仍有 1.4 倍。**注意:这是「监控房数=1 万」时的值,不是默认值** |
| ~20000 | 6 | |
| ~50000 | 13 | 此时先调 PG `max_connections`(见下方硬顶) |

即 **`副本数 ≈ ⌈总房数 / 4300⌉ + 1`**(4300 = 1 核 ÷ 11.2ms × 50s 的可承载房数)。

> ⚠️ **compose 默认是 10,不是 4** —— 因为默认 `discovery.enabled: true` +
> `prune_grace_s = 7 天`,实际监控的是**7 天并集**(常是瞬时在播峰值的数倍,3~5 万很常见),
> 而不是「瞬时在播 1 万」。10 副本 = 4.3 万房容量。
> **别按瞬时在播数定副本** —— 一条命令查真实值:
> ```bash
> curl -s http://<host>:5173/api/crawler/status | jq .crawler.health
> ```
> 它直接给出 `monitoredRooms` / `backlog` / `backlogLagMs` / `healthy` / `suggestReplicas`。
> 其中还包含 **`pgPingMs` / `pgConnections` / `pgSaturated`** —— 副本一旦超过连接账本硬顶
> (⌊(max_connections−35)/32⌋,默认 11),任务会「按时被领、在 PG 排队执行」:出怪入库散布局内
> 40~70s、预测长 null,而 Redis 积压恒 0;此字段专治这类**旧 health 看不见**的饥饿。
> **`healthy: false` = 算力不足**:抓取被整体推迟,前端会看到「出怪倒计时结束、下一局都
> 开跑了才显示上一局」+ 预测滞后/消失 —— **数据不丢(coverage 仍报 complete),只是系统性
> 地晚**,所以只查数据完整性是查不出来的。

> ⚠️ **总房数 ≠ 瞬时在播数**。开启自动发现(§10)时,后台实际监控的是
> **7 天留存窗口内出现过的所有房**,可能是瞬时在播峰值的数倍 —— 请按
> `GET /api/discovery/status` 的 `discoveredCount` + 手动房数**实测值**套公式。
> 另经实地核查:上游 `mapi` **不校验房号**,离线房照常返回完整出怪流
> (连不存在的 `99999999` 都有 30 局历史)—— 所以**留存的离线房与在播房开销完全相同**,
> `discovery.prune_grace_s` 是舰队规模的头号驱动因素。

**为什么 compose 默认给到 10**:不能按「上游最多 1 万房」去定 —— 开着自动发现时舰队 =
7 天并集,远大于瞬时在播数;4 副本(1.72 万房容量)一超就**持续积压**,数据系统性晚一局。
10 副本 = 4.3 万房容量。若你确实只监控少量策展房(`discovery.enabled: false`),
再按公式调小到 4 甚至 2 —— 以 `health.suggestReplicas` 的实测值为准。

**硬顶**:副本共享同一 PG —— `max_connections=400` 减 web 池 32、超级用户预留 3 后
÷ 每副本 `pg_pool_max=32` ≈ **11 副本硬顶**;再往上先调 PG `max_connections`。
Redis `maxclients=20000` 不构成约束(实测单 worker 峰值 ~190 连接)。

**建议机器配置(按上表实测 CPU/磁盘核算)**

| 监控规模 | 建议配置 | 依据(实测外推) |
|---|---|---|
| ≤ 5000 房 | 4 核 / 8G / 60G SSD | CPU ≈1.5 核(worker 1.1 + PG 0.3);磁盘 ≈19G |
| **~1 万房(默认档)** | **8 核 / 16G / 200G SSD** | CPU ≈**2.9 核**稳态(worker 2.2 + PG 0.54 + Redis 0.1)+ retention/discovery 突发余量;磁盘 **≈50G 常驻**(rounds 实测 278B/行 ×1728 局 ≈0.48MB/房·天,含删除稳态膨胀 ×1.5 ≈0.72MB × 1 万 × retention 7 天;predictions 经策展闸仅策展房产生,3 房 ≈9MB/天可忽略;3.78MB/房·天 是无策展闸、全房跑预测时的上界)+ WAL |
| ~2 万房 | 16 核 / 32G / 400G SSD | `shared_buffers` 调到 4GB |
| ~5 万房(副本硬顶附近) | 32 核 / 64G / 1T NVMe | PG 先于副本吃紧,需调 `max_connections` |

> ⚠️ 「≤1 万房 → 4 核 / 8G」这一档**偏紧,不要照用**:实测稳态就要 2.9 核,4 核只剩
> 1.1 核给 retention 每小时的百万行删除、discovery 遍历与冷启动回填,没有故障余量。

**磁盘的大头是 `predictions.detail`**(实测 1852 B/行 vs rounds 335 B/行,占 ~85%):
它是 6 个模型 × 9 只妖兽的完整概率表(17 位有效数字的浮点文本),供 Hedge 权重结算用。
已实测确认 PG 无法压缩它(行 ~1.5KB < TOAST 阈值 2032B,`toast_tuple_target` /
`STORAGE MAIN` / `lz4` 均无效),而降低浮点精度会**改变预测算法的数值行为** ——
与「预测逻辑零改动」的硬约束冲突,故**不动**。磁盘按 **0.72 MB/房·天**(rounds 实测含稳态膨胀;策展闸后 predictions 可忽略)× `retention.days` 规划即可;若日后关闭策展闸(全房跑预测),按闸前上界 3.78 MB/房·天 复核。

磁盘按 **~5–7MB/房** 估算:rounds 表+索引 0.45MB/房·天 + predictions(detail
JSONB)2.9MB/房·天(保留 1 天,实测口径),再留 MVCC 膨胀与 WAL 余量。
`shared_buffers=2GB` 的取值依据:独占罩住 5 千房读热集,叠加 OS 页缓存稳吃万房;
内存 <8G 的机器请调回 1GB/512MB,否则有 OOM 风险。PG 另默认
`synchronous_commit=off`(高频短事务解耦 fsync;PG 崩溃至多丢最近 ~0.6s 已确认写入
且不损坏 —— 漏局由 GameHistory 校验自动补齐、权重增量自愈,本负载可承受)与
`max_wal_size=2GB`(2 万房+ 写量下避免密集 checkpoint);Redis 默认
`maxmemory=1gb`(实测万房常驻 <150MB,上限防意外增长拖垮宿主机,noeviction 下超限
写入显式报错)。各 `.env` 模板的 `STA_PG_POOL_MIN/MAX` 已与代码默认对齐为 **4/32**
—— 旧模板钉 2/16 会把连接池静默压回小值,既造成 800 consumer 挤 16 连接的排队,
也与本节"每副本 32"的连接账本冲突。
扩容后按 **§5.3 的三步体检**确认副本是否吃满/充足(到期积压=0 · 全副本合计局/s ≈ 活跃房数/50 · CPU 未顶格)。

Web 是只读的，也可多副本；`uvicorn --workers` 已在镜像内按 CPU 起多进程。

### 5.2 本地开发

```bash
# 依赖
pip install -r requirements.txt          # 生产可加 --break-system-packages 视环境而定

# 起 Redis 与 PostgreSQL（本机或容器），建库建角色
#   createuser star; createdb spelltamer -O star

export STA_PG_DSN="postgresql://star:star@127.0.0.1:5432/spelltamer"
export STA_REDIS_URL="redis://127.0.0.1:6379/0"
export STA_ENGINE_DIR="$(pwd)/../jiufa_data"     # 预测引擎位置
export STA_STATIC_DIR="$(pwd)/.."                # 前端 SPA 位置（含 index.html/assets/jiufa）
# ↑ 指向仓库根也安全：静态兜底只对外提供前端产物（index.html / sw.js / favicon / manifest 与
#   assets、jiufa、mock、cdn、icons 目录），仓库里的 .env、config.yaml、源码等一律当作不存在的路径
export STA_AUTH_TICKET="<你的新鲜票据>"           # 见 §7

# 抓取 worker（可开多个进程）
python -m app.worker

# 只读 Web（另一个终端）
uvicorn app.web:app --host 0.0.0.0 --port 5173 --workers 4

# 注入房间
python -m scripts.seed_rooms 321
```

### 5.3 验证 worker 副本是否充足（三步体检）

副本够不够不用猜,三条硬指标全绿即充足,与房间规模无关:

**① 到期积压（最直接）** —— 延迟队列里「已到期却还没被任何副本领走」的任务数:

```bash
cd backend_async/deploy && docker compose exec redis \
  redis-cli ZCOUNT sched -inf $(($(date +%s%N)/1000000))
# 不在 deploy 目录 / 项目名不确定时,用容器名直连(docker ps 里形如 <项目名>-redis-1):
docker exec <redis容器名> redis-cli ZCOUNT sched -inf $(($(date +%s%N)/1000000))
```

判读:**0 或个位数 = 充足**(claimer 每 ~0.1s 领一批 200,健康态积压瞬时清零);
持续几百上千且随时间增长 = 领取/消费跟不上。正在执行中的任务因租约顺延不计入,
这个数字就是纯粹的「欠账」。

**② 吞吐对账（janitor 分钟统计行）** —— 每个副本每 60s 各打一行:

```bash
docker compose logs --since 5m worker | grep 统计
#   统计:近 60s 入库 N 局(≈R 局/s)· 活跃 M 房
```

判读:「活跃 M 房」是全局值,入库局数各报各的 —— **把所有副本的 R(局/s)加总,
应 ≈ M / 50**(每房 ~50s 一局)。合计明显偏低且 ① 同步增长 = 抓取跟不上;
合计达标 = 吃满且健康。

**③ CPU 顶格检查**:

```bash
docker stats --no-stream | grep worker
```

判读:worker 是单进程 Python(GIL),单副本可用算力 ≈ 1 核。某副本长期贴着
**100%** = CPU 瓶颈(结算+预测是纯 Python 计算),加副本立竿见影;若 CPU 远低于
100% 而 ① 仍在增长,先查上游延迟/票据/网络,而不是加副本。

**症状鉴别**:副本不足是**所有房普遍且随时间加剧**的滞后(① 增长 + ② 偏低 + ③ 顶格
三者同现)。**单房偶发**晚 ~20s 出数据不是副本问题 —— 那是 RoundAward 未就绪走满
重试梯(1.5/3/4.5/6/7.5s)后 GameHistory 兜底的内建路径,worker 日志出现
`多次为空,GameHistory 兜底` 即坐实;管理台把「取奖最大重试」「取奖回退步长」调小可
提前兜底,加副本无效。三项全绿 = 当前副本数对当前房数就是够的;要预估规模上限,按
每副本 ≈**4300 房**(实测每局 11.2ms CPU;§5.1 的公式与表)与 §11 的机器/PG 前提推算。

---

## 6. 测试与冒烟

```bash
# 单元 + 集成单测（令牌桶需 Redis，缺则自动跳过）
export STA_TEST_REDIS_URL="redis://127.0.0.1:6379/15"
python -m pytest -v
#   test_scheduler ........  错峰纯函数（含 5000 房削峰验证）
#   test_ratelimit ...       令牌桶：突发放行→拒绝、按时补充、并发不超发
#   test_discovery ....      在播列表解析/遍历:规范+非法JSON正则兜底、翻页终止/去重/护栏(不触网)
#   test_discovery_reconcile . 发现闭环:登记+隐藏、幂等、转正(含 janitor)、7 天回收、重启回灌不清零计时(需 Redis)
#   test_web_visibility ...  前端可见性契约守卫:任何房间集合/计数出口必须过滤发现房(静态,零依赖)
#   test_timing ....         服务器钟外推 + 倒计时回溯缺陷的症状级回归(纯函数,零依赖)
#   test_predictor_bridge .. 预测引擎复用回归（妖兽解析 / kv 无状态往返）
#   test_admission ....      批量准入端到端(3500 房去重/归一分区/首抓铺开/并发上限;需 Redis)
#   test_redis_bus_index ..  房→任务反向索引(删房 O(1) / janitor 不扫全队列;需 Redis)
#   test_starmeta_gate ..    繁星令牌桶限流 + 跨进程归一缓存命中(需 Redis)
#   test_db_bulk ...         批量 rounds INSERT 构造(纯函数,与实时写路径逐字节一致)
#   test_retention ...       保留清理:cutoff 数学 / 分批 DELETE SQL / 表白名单 / 北京时间钉死

# Web 层端到端冒烟（需 Redis + PG；不接真实上游）
python scripts/smoke_e2e.py
#   经 ASGI 打 FastAPI，验证 monitor/add → 写库 → history/prediction/config/... 全契约

# worker 抓取编排链集成冒烟（假上游驱动完整周期；需 Redis + PG）
python scripts/smoke_worker.py
#   MainPage→回填历史→RoundAward 入库→复用引擎生成下一局预测→快照→推送 SSE

# 前端真 DOM 行为冒烟(项目根 `npm i jsdom`;不触网,只桩后端)
node backend_async/scripts/frontend_switch_admit_jsdom.js
#   切房准入(5.0.7):switch=1 旗、超时预算、终态清卡 / 瞬态留卡、添加被拒不落盘
node backend_async/scripts/frontend_switch_autobind_jsdom.js
#   切换即添加(5.0.8):搜索框敲号 / 残影卡 / 分享链接 ?room= 的自动补绑、未开播/问不到/满额/
#   未登录/非显式路径各自的边界(38 项断言;无 index.html 时按 cacheDom 生成骨架页)
```

> 本仓库已在 Python 3.12 + 真实 Redis + 真实 PostgreSQL 16 上跑通全部三类冒烟。

---

## 7. TLS 指纹与登录票据

抓取走**上游游戏 API**（`mapi.tencentmusic.com`），需要 `x-auth-*` 票据（见
`config.yaml` 的 `auth` 块 / `.env` 的 `STA_AUTH_TICKET`）。票据会过期，`Upstream`
在收到 401/403 时抛 `AuthExpired`，worker 会把该任务稍后重排（并预留了接换票流程的钩子）。

**TLS 指纹**：酷狗个别登录态对「非浏览器 TLS 指纹」的客户端会有差异（旧 `server.py`
用可选依赖 `curl_cffi` 来模拟浏览器指纹以稳住登录态）。异步抓取默认用 aiohttp，对
公开的 SpellTamer 端点通常足够；若你的票据链路对指纹敏感、出现「对浏览器正常、对本
客户端异常」的扣票，请：

1. 取新鲜票据（浏览器登录后从请求头取 `x-auth-ticket` / `x-auth-uid` 等）填入 `.env`；
2. 如仍受指纹影响，可在 `app/upstream.py` 的会话层引入指纹模拟（`curl_cffi` 已在
   `requirements.txt` 注释中预留），或在浏览器侧维持登录态由独立取票服务下发票据。

抓取所需的浏览器请求头（UA / Origin / Referer 等）已在 `constants.DEFAULT_BROWSER_HEADERS`
中对齐旧引擎。

---

## 8. 房号归一（短号 / 靓号 → 真实房号）

观众输入的「房号」可能是**短号 / 靓号**（例：`321`）。繁星页
`fanxing.kugou.com/321` 会 302 到 `/channel/2678075`（或 `/{真实房号}`），落点页面里的
`roomId` 才是**真实房号**。上游 `mapi` 不校验房号，按短号抓取会抓到「凭空局」，因此
**抓取 / 入库 / 订阅一律必须先归一到真实房号**。

`app/starmeta.py` 把旧 `server.py` 的多层解析（页面解析 → `roomStatus` 兜底 `kugouId`
→ `getStarInfo` 补昵称/头像）搬到异步，并做缓存 + 限流两件事：

- **跨进程 canon 缓存**（Redis `canon:{短号}`）：短号 → 真实房号的**权威**映射写进
  Redis（7 天 TTL），web / worker / seed **多进程共享** —— 数千房只需被**任一**进程
  全局解析一次,其余进程直接命中,不重复打繁星。失败不缓存(下次仍会重试归一)。
- **进程内 profile 缓存**：房号 → 昵称/头像。命中 600s,失败 60s(展示资料无需跨进程)。
- **繁星专用令牌桶**（Redis `rl:fanxing`,与游戏 API 的 `rl:upstream` **相互独立**）：
  每一次打向繁星的请求(页面解析 / `roomStatus` / `getStarInfo`)都可先申领令牌。繁星是
  普通网页,**没有游戏 API 那样的官方配额**,一旦被数千并发归一打成几百~上千 req/s 有
  触发反爬封 IP 的风险,连带打挂所有房归一。此桶把这一路的全局速率钳在
  `ratelimit.fanxing_rps` 内。**默认不限制(`fanxing_rps: 0`)** —— 令牌桶在 rate≤0 时
  退化为始终放行;若归一被封 IP,把 `fanxing_rps` 设为正值(如 `120`)即可启用。
  即便不限流,批量准入仍有 `canon_concurrency` 并发上限 + 跨进程归一缓存兜底,连接器
  并发上限 `STA_STARMETA_CONN_LIMIT` 是最外层护栏。

任何一步失败都**优雅退回**：归一失败按原号(只读查询按原号最多得到空结果,无害;
但**抓取绝不按原号进行** —— 见下节准入,失败房进挂起由 janitor 重试)；
资料失败回退占位「房间 {号}」。核心抓取链路不依赖本模块可用性。

> 展示资料按「用户输入的号」解析更稳（短号频道页 `kugouId` 稳定，不随登台主播漂移），
> 抓取则用真实号 —— 二者分离，与旧版观感一致。

---

## 9. 批量添加与冷启动削峰（同时上千房）

单房 `POST /api/monitor/add` 一次只归一 + 登记一房。**同时添加数千房**若各自走单房路径,
会同时引发三类洪峰,故新增一条**批量准入**路径统一削峰:

- **`POST /api/monitor/add-bulk`** — body 接受 `{"rooms":[...]}` / `{"rooms":"321,654\n..."}`
  / 纯文本(逗号/换行/空格分隔)。
- **`python -m scripts.seed_rooms --file rooms.txt`**(或位置参数)—— CLI 走同一套准入。

两者都进 `app/admission.py` 的 `admit_rooms()`,一次受控完成:

1. **去重 + 合法性过滤**:先按输入去重(2~12 位数字);归一后再**按真实房号去重**
   —— 多个短号/靓号映射到同一真实房只登记一次一个抓取任务(不重复抓同一房)。
2. **有界并发归一**:归一并发被 `admission.canon_concurrency`(默认 32)钳住,**叠加**繁星
   令牌桶(上节)—— 双重约束,数千房归一不再把繁星打成惊群。归一失败的房进**挂起集**
   (不按原号开抓),由 worker janitor 周期重试,成功即自动转正开抓 —— 与单房 add 语义一致。
3. **批量落库 / 登记**:`upsert_rooms_bulk` + `add_rooms_bulk` 一次多行写,替代逐房 N 次往返。
4. **首抓错峰铺开**:所有新房的第一次 MainPage 用 `schedule_spread` **均匀铺开在
   `admission.warmup_window_ms`(默认 60s)窗口内**,而非全部排在同一毫秒。

**为什么第 4 步是关键**:即便 QPS 不限流,5000 房首抓若全排在同一毫秒,也会对上游形成
一次巨大的**瞬时尖峰**;铺开到 20s 窗口后变成约 250 req/s 的平滑流(该实验时窗口为 20s;现默认 60s,同规模再降至 ~83 req/s)。而**一旦你启用上游
限流**(`upstream_rps` 设正值),不铺开还会引发重排风暴:约定容量下大量任务第一轮拿不到
令牌 →`+1s` 重排 → 在延迟队列与 consumer 间反复弹跳。实测(真实 Redis + 令牌桶设
300 rps)排空 5000 房会产生 **约 2.5~3 万次寄生 ZADD 弹跳**;改错峰铺开后**降为 0 次**(实测时窗口为 20s;现默认 60s,削峰只增不减)。
所以无论是否限流,首抓错峰都必要。返回体给出结构化摘要
(requested / deduped / added / pending / skipped / truncated / elapsed_ms)。

> 单次上限 `admission.max_bulk`(默认 20000)防误传超大批;超出部分截断并在摘要里标注。

---

## 10. 直播间自动发现（遍历在播列表 · 自动纳管 · 前端隐藏）

除了「用户显式添加房间」这条入口,worker 还内置一条**自动发现**循环:每
`discovery.interval_s`(默认 **60s**)遍历一次繁星**在播房间列表**(CDN 分页接口
`fx1.service.kugou.com/mfanxing-home/h5/cdn/room/index/list`),把当前在播的房间**自动
纳入后台抓取并统计数据**,无需人工逐个添加。

### 10.1 数据流与「前端不显示」

列表接口返回的 `roomId` 就是**真实房号**(与观众手输的短号/靓号不同,**无需归一**,
可直接抓取)。发现房与「用户手动添加的策展房」在存储上刻意分离:

| | 手动添加的房(策展) | 自动发现的房 |
|---|---|---|
| 名录持久层 | **PG `rooms` 表 + Redis** | Redis 运行态(**不落 PG `rooms`**);仅 last_seen 时钟另存 PG `discovered_rooms` 表 |
| 被 worker 抓取 | 是 | 是 —— 出怪/预测数据照常进 PG(即「自动统计数据」) |
| 前端 `/api/live-rooms` | **显示** | **不显示**(被 `rooms:discovered` 过滤掉) |
| 何时移除 | 仅用户显式 remove | 连续 **≥7 天**(`prune_grace_s`)未再出现在在播列表 |
| 重启恢复 | PG `rooms` → Redis 回灌 | PG `discovered_rooms` 时钟 → Redis 回灌(**7 天计时不因重启清零**;在播房亦被下一轮遍历重建) |

于是**前端只显示用户显式添加的房**(符合「前端无需显示,前端只有添加直播间后才会
显示」);而所有在播房的数据仍在后台被采集进 PG,供统计/分析。

**添加直播间的准入限制**:`/api/monitor/add` 首选放行**后台已存在**的房 ——
即近期(7 天回收窗口内)出现在在播列表而被自动发现的房,或已在名录的策展房。
config 注入 / `seed_rooms` / add-bulk 属**运维路径,不受此限**(运营者显式指定,
信任级别不同 —— 如需求固定房 `321`:见 `config.yaml` 的 rooms 注释,短号准入时
归一为真实号 2678075,策展房永不因离线回收)。

**核验准入(5.0.7)—— 后台不存在时的第二条通道**。在播列表是**推荐流**,有两类
房结构上永远进不了发现集:频道房(`roomType=3`,本项目固定房 321→2678075 即是)
**从不上榜**;低流量房常年不上榜(45s 两轮实测掉榜的 17 房里 6 房仍在直播)。
对它们而言旧实现是一堵没有门的墙。现在 `discovery.verify_enabled=true`(默认)时,
后台没有开播记录的房改走核验:

1. 先查**核验台账**(PG `verified_rooms`):`prune_grace_s` 之内确认过在播的房直接
   放行,零上游请求;
2. 否则打一次 `roomStatus` 定谳 —— `liveStatus=1` 即放行,并把该房记入台账、
   同时把 `rooms:livestatus` 置 1(名录绿点秒亮,不必等下一轮探测)。

三种拒绝各说各的真话,不再一律笼统回「只允许添加近期直播过的直播间」:

| error | 含义 | 前端处置 |
|---|---|---|
| `room_unresolved` | 归一失败,或**归一后资料全空**(号不存在) | 终态:清卡 |
| `not_live_now` | `liveStatus=0`,确证此刻未开播,且后台无开播记录 | 终态:清卡 |
| `live_unverifiable` | 上游这一拍问不到 —— **不改判为未开播** | 瞬态:留卡重试 |
| `not_recent_live` | 仅在 `verify_enabled=false` 时出现(旧口径,逐字节兼容) | 终态 |

**「不存在」与「问不到」必须分开**(2026-09-06 打真上游复核出来的口径缺口)。
`service1.fanxing.kugou.com/roomcen/room/web/roomStatus` 对**根本不存在的房号**也回
`code=0 / liveStatus=-1 / kugouId` 缺省,与频道房短号的签名一模一样:

```
room=321        code=0 liveStatus=-1 kugouId=None    ← 频道房短号(真号 2678075)
room=999999999  code=0 liveStatus=-1 kugouId=None    ← 号根本不存在
room=2678075    code=0 liveStatus=1  kugouId=472123830
```

`live_status` 把这两者压成同一个 `None`,于是用户敲错一个房号只会得到「暂时核实
不了,请稍后再试」,然后无限重试。**归一之后它们是分得开的**:真号带得出主播资料
(`canon('321') → ('2678075', True)`,昵称「321音乐频道」、kugouId 1192670741),
不存在的号资料全空。故 `live_status` 回 `None` 时补一次 `profile(rid)`(走 canon
已填的跨进程缓存,常态零额外请求):资料全空即判 `room_unresolved` 终态,其余仍按
瞬态处置。真机端到端实测:`321 → 200 自愈入册`、`999999999 → 400 room_unresolved`、
`2678075 → 200`。

核验房打 `user_added_rooms` 溯源标:绑定数归零时与发现房转正同样退场,不会
只进不出。`/api/monitor/remove` 同步清台账 —— 显式撤下的房不该绕过准入原地复活。

**核验房的日常复核(worker `_verify_sweep`)**。核验房的「在播记录」由 roomStatus
供货而非在播列表,台账时钟得有人刷。巡检每 60s 醒一次(Redis `SET NX EX` 跨副本
互斥),但**每房各有各的到期时刻** `next_probe_ms = now + verify_interval_s × U(0.75,1.25)`
—— 刻意不用统一时刻:「每天 04:00 齐探」对固定晚上开播的主播是**确定性漏判**,
一年都判不出它在播;随机相位把系统性盲区摊成概率问题。三级供货,请求只花在最后一级:

1. 该房仍在发现集 → 直接取 `rooms:discovered` 的 last_seen(零请求);
2. 该房仍是策展房 → 直接取 `rooms:livestatus` 的观测(零请求 —— 它本就每
   `livestatus.fresh_s` 被探一次,再探一遍纯属重复劳动);
3. 其余(用户已删光绑定的孤儿)→ 到期才真打 roomStatus。

未开播/问不到都只把下次复核排出去、**时钟不动**(GREATEST 保证只进不退);够不够
格留在台账由 `prune_grace_s` 说了算,不由单次探测定生死 —— 与发现房「缺席不算
下播」同一条戒律。超期即清出台账。观测见 `/api/crawler/status` 的
`discovery.verify` 与 `/api/discovery/status` 的 `verifyLast`。

`verify_interval_s` 默认 86400(每天一次):对每晚只播 3 小时的主播,7 天 grace 内
至少命中一次的概率约 61%;漏判的后果**只是超期后要在开播时再添加一次**,不丢数据。
要更稳可调到 21600(每 6 小时)。管理台保存时有一条交叉校验:
`verify_interval_s × 2 > prune_grace_s` 会给出警告(核验房还没轮到复核就被判超期)。

注意:若关闭自动发现(`discovery.enabled=false`)**且**关闭核验(`verify_enabled=false`),
用户将只能添加已在名录的房 —— 新增房需走运维路径。

**切房准入(5.0.7)—— 同一条阶梯也管「换主播」**。名录与后台注册表会分叉,而分叉后
前端只会画一个**永远没有数据的空房**、不给任何解释。两条已核实的分叉路径:

* 未启用登录时,前端 `mergeMyRooms()` 把 localStorage 里的房**无条件**并进名录
  (`app.js upsertCustomRoom`),从不与后端对账 —— 换设备 / 换部署 / 房被运维撤下
  之后,那条记录会一直留在轨道上;
* 启用登录时,`/api/live-rooms` 直接回 `user_rooms` 绑定,同样不校验全局注册表;
  而 `monitor_remove` 里级联清绑定的那步裹在 `suppress` 里,PG 抖一下就会留下
  「绑定还在、监控没了」的永久残影,此后无任何代码路径会收敛它。

故 `/api/live-rooms/{room}/profile` 增加 `switch=1` 参数,带上它即走**与添加完全
相同的三级阶梯**:

| 级 | 判据 | 代价 | 结果 |
|---|---|---|---|
| ① | `rooms:active` 有它(`bus.is_active`) | 一次 `SISMEMBER` | 放行,命中即止 |
| ② | PG 核验台账 `verified_rooms` 在 grace 内 | 一次 PG 点查,**零上游请求** | 放行 + 自愈登记 |
| ③ | 打一次 `roomStatus` 定谳 | 一次上游往返(预算 5s) | 在播→放行 + 自愈登记;`liveStatus=0`→`not_live_now`;问不到→`live_unverifiable` |

**放行不等于结束:②③ 命中后必须把抓取拉起来**(`_selfheal_register`,逐行对齐
`monitor_add` 的登记序)。只放行不登记等于让人进一间后台没在抓的空房 —— 阶梯的
价值就在于「能救就救」:主播此刻确实在播,就把监控恢复了让他看,而不是甩一句
「请重新添加」把用户赶去重走一遍流程。

自愈刻意**少做两件事**:不打 `user_added_rooms` 溯源标(自愈是把丢掉的东西放回去,
不是创造一份新归属 —— 原房若本是运维钉住的,补标会让它变成可被用户删空撤下的房;
原房若本有标而标也丢了,我们无从分辨,那就不猜);不碰名额上限(该房本就在此人
名录里,名额在当初添加时已扣过)。

四条纪律:

1. **命中即止**。在册房只花一次 `SISMEMBER`(O(1)),不查台账、不打上游、不写库
   —— 切房是高频读路径,稳态下必须零额外开销(ASGI 实测:在册房零写、零探测)。
2. **挂起房放行**。归一暂时失败的房不在 `rooms:active`,但前端名录里**是有卡的**
   (`_build_live_rooms` 给它画 pending 卡);不放行就会把「正在等归一」误杀成
   「已不监控」,用户看到自己刚添加的房凭空消失。输入号与归一号双键查。
3. **空名录与异常一律放行**。web 的 PG→Redis 回灌裹在 `except: pass` 里,PG 启动
   瞬断 + Redis 空(compose 关持久化)时 `rooms:active` 会是空集;此刻判否的后果
   不是拒绝一次请求,而是前端把用户名录里的房**逐个删掉** —— 一次基础设施抖动
   换一片不可逆的数据丢失。故先 `SCARD` 确认名录本身就绪,0 房即放行。
4. **无资格者在打上游之前就放行**。自愈是一次**名录写**,故要受名录写的全部
   保护:① 名录写令牌 `STA_MONITOR_WRITE_TOKEN`(复查补 —— 不复用同一把锁的话,
   `GET /profile?switch=1` 就是写保护的后门,任何人都能让开着保护的部署凭空开抓
   一间房);② 启用登录时必须确认该房确实在此人名录里(`user_room_allowed`),
   否则谁都能让后台开抓一间无主房:既不占名额、也没有溯源标,永远不会被回收。
   资格判定**排在核验之前**:既然救不了这个房,探测就毫无意义 —— 否则一个未授权
   的 GET 既放大上游请求,又往 `verified_rooms` 塞垃圾行(worker 此后每天还要为
   它们各探一次)。无资格即放行,交给下游各自的闸说话(`room_not_bound`)。
5. **只给昂贵分支限流**。走到"注定要查库 + 打一次 roomStatus"这一步才过
   `_detail_rate_guard`。闸若设在入口,名录卡启动时并发拉 N 张 profile,10 房的
   名录一开机就先吃两发 429;而 429 对前端是瞬态,卡不会被清掉。

**切换即添加(5.0.8)—— 登录态下"不在名录"不再是死胡同**。纪律 4 把未绑定的房
放行给下游,于是登录态下切到一个**不在本账号名录**的房(搜索框敲号、点 localStorage
并回来的残影卡、分享链接 `?room=`)的结局是:profile 通过、config/history 403
`room_not_bound`、前端 toast「不在你的名录中,请先添加」—— 而这条路上**没有任何人
查过主播是否在播**,主播开着播也照样被拒;"添加"走的又恰恰是「查在册 → 查台账 →
打 roomStatus → 在播即绑定」。前端现在把这一步替用户走完(后端零改动,准入阶梯、
名额闸、VIP 闸、写令牌、溯源标全部复用 `/api/monitor/add`):

* `doSearch`:登录态下敲的号不在名录 → `addAndOpenRoom`(先加后看);未启用登录时
  维持「看而不加」(5.0.3 注)—— 那里本就没有 `room_not_bound` 这道门;
* `loadRoom` 的 catch:**显式**切房撞到 `room_not_bound` → 打一次 `/api/monitor/add`
  → 成功即落盘、入名录、重载(顺带重新抢占租约);`not_live_now` / `room_unresolved`
  且它是名录卡或当前房 → 按终态清退(残影卡就此消失);其余(名录满 / 问不到 /
  写令牌拒绝)只用后端原话提示,不删卡。

三条纪律:① 只在**显式**动作上做,跟随 / 存储恢复 / 退避重试 / 每 30s 的 mergeMyRooms
一律不做 —— `/api/monitor/add` 没有同房冷却(见 `test_add_path_is_not_throttled_by_the_switch_cooldown`),
自动路径会按 30s×标签页数打上游;② 每次切房只补绑一次(`bindTry` 预算,与 `claimTry`
同款);③ 补绑失败**不进退避重试**(那是 explicit=false 的静默路,只会重复同一个 403),
用户再点一次即新的一次尝试。取舍:满额不自动挤掉旧房(硬上限只提示);自动入名录一律
toast 告知(它占名额、可删);未开播不加。`room_not_bound` 的文案去掉了「左侧」方位词
(与 5.0.2 定案同口径),它现在只在自动补绑不适用的路径上直显。

worker 的巡检节拍是 **300s**(不是 60s):每一轮都要读一遍台账 + 策展名录 +
livestatus 全表,而 `_livestatus` 循环本就每 60s 做同量级的事,没必要再叠一份
同频扫描;到期后 ≤5 分钟被处理,对 24 小时的周期完全无感。互斥锁 TTL **不取
节拍**,而是按「⌈max_probe/concurrency⌉ × request_timeout × 1.2」算出的最坏
一轮耗时(默认 ⌈300/16⌉×8 ≈ 152s → 取 300s):discovery 与 livestatus 都踩过
「锁在轮次途中过期、别的副本插队开第二轮」这个坑,它们靠续租心跳解决;本循环
不同 —— 节拍不由锁承担(每房到期时刻存在 PG 的 `next_probe_ms` 里),所以锁
可以直接放长,持锁者崩溃最多让别的副本空等一个 TTL,排期是持久化的,零数据损失。

台账时钟设**刷新地板** = 复核周期的四分之一(默认 6h):时钟只需落在 grace 之内,
精确到分钟毫无意义。不设地板的话 ①② 每一轮都会给几乎每一行发一条 UPDATE ——
发现房的 `last_seen` 每 60s 就变,万行台账 = 每 300s 一万条 UPDATE(还要连带 WAL)。
设地板后每行每天至多 4 次写,而时钟最陈也只差 6h,相对 7 天的 grace 有 28 倍余量。
**地板之下仍然 `continue`** —— 跳过的是写入,不是判定;否则该行会掉进 ③ 被白探一次。

新落台账的行 `next_probe_ms` 取默认 0,worker 见到它**只排期、不探测**:它的
`last_live_ms` 就是刚核验的那一刻,再探一次纯属重复(复查实测:不这么做的话,
每一次核验准入都会在 60s 内换来一发多余的 roomStatus —— 复用观测的那条分支因
`ts > last` 取严格大于,恰好接不住两边同为 `nowv` 的新行)。

**同房探测冷却 `SWITCH_PROBE_COOLDOWN_S = 120s`**(只作用于切房)。切房路径
**会自动重复**:前端 `refreshLiveRooms` 每 30s 用后端名录整体替换 `S.rooms`,
随后 `mergeMyRooms()` 把 localStorage 里不在后端名录的房重新并回来 —— 于是同一个
房每 30s 就再发一次 `profile?switch=1`。探测**成功**的房当场自愈进名录、下一拍即
短路;探测**失败**的不会,它会一直重来 —— 而失败最常见的原因恰恰是上游本身不好,
等于在最脆弱的时候按 `30s × 标签页数` 的节奏持续加压。冷却把同房重探钳到 120s
一次(抢不到闸即按「这一拍问不到」处置,与超时同口径,绝不改判成未开播)。
添加路径**不抢**这把闸:那是用户一次性的深思熟虑动作,不该因为别人刚探过同一个
房就被拒(「我明明看着他在播」)。

**输掉闸的那一路等赢家,而不是各自报错**(真机 12 路并发实测才暴露的):闸把上游
探测正确地钳到 1 次,但另外 11 路当场吃 400 —— 而这个并发不是假想,页面启动时
`mergeMyRooms()→upsertCustomRoom` 与 `loadRoom` 会为同一个房**各发一次**
`profile?switch=1`,多标签页更是叠乘。赢家通常在数百毫秒内自愈完成,故输家盯着
`rooms:active` 轮询 6×200ms;等到了就照常放行,等不到才按「这一拍问不到」回话。
实测:12 路并发切一个在播的陈房 → **全部 200、上游只被打 1 次、总耗时 0.26s**;
在册房单发 2ms(零额外开销);主播确实没开播时赢家回 `not_live_now`、输家回
`live_unverifiable`(1.21s),两者都不会被误判成「未开播」。

探测预算 `SWITCH_PROBE_TIMEOUT_S = 5s`,刻意**短于**添加路径的
`livestatus.request_timeout`(默认 8s):添加是一次深思熟虑的动作,等几秒天经地义;
切房被前端塞进 `Promise.all`,任何一路超时都会让整次切房落进退避重试。前端两处
`switch=1` 调用的超时同步提到 12s,给后端预算留足余量。

前端对三种拒绝的处置**不对称**:`room_not_monitored` / `not_live_now` /
`room_unresolved` 是终态 → 清卡 + 优雅回退(否则退避重试会每 3~30s 重试一个后端
已经明确说了「没有」的房,把用户钉在空白页上);而 `live_unverifiable` 是「上游
问不到」,**不是「这房没了」** —— 卡留着,落进通用失败分支提示 + 退避重试,上游
一恢复就自己回来(与后端「问不到 ≠ 没开播」同一条戒律)。

参数刻意做成**显式开关而非默认行为**:本端点还服务「添加前的房号预检」
(`app.js submitAddRoom`),那一刻房本来就还没进后台,默认拦截会把核验准入通道
当场堵死。前端只在**切房**(`loadRoom`)与**名录并卡**(`upsertCustomRoom`)两处带它。

### 10.2 一轮遍历做什么(worker `_discover_once`)

1. **分页遍历**:从 page=1 逐页拉取,直到 `hasNextPage==0` / 空页 / 触达 `max_pages`
   护栏。上游偶发**非法 JSON**(昵称/标签里落单反斜杠)会让标准解析抛错,故解析走
   「严格 JSON 主路径 + 正则兜底」——只需 `roomId`/`hasNextPage` 两个**数值字段**,
   不受字符串转义影响,个别坏页不中断整轮。翻页请求也过**繁星令牌桶**(与房号归一
   同一路,见 §8),遍历本身不会惊群打爆繁星。
2. **登记新房 + 错峰起抓**:把「在播且尚未活跃」的新房批量入 Redis 名录,并在
   `discovery.warmup_window_ms`(默认 60s)窗口内**均匀铺开**首次 MainPage(与冷启动
   削峰同理,见 §9),避免数千房首抓惊群。
3. **刷新 last_seen**:记录每个在播发现房本轮出现的时刻(Redis + **镜像进 PG
   `discovered_rooms` 表**)。回收 grace 长达 7 天,而 compose 里 Redis 关持久化 ——
   时钟必须落 PG,否则一次 Redis/容器重启就把所有当时离线的发现房"提前清零"。
4. **离线回收**:加入后台后,连续 `discovery.prune_grace_s`(默认 **7 天**)未再
   出现在在播列表、且非策展房的发现房,才判定长期停播并从后台移除(从名录/调度/
   发现集/PG 时钟彻底清净;**并级联清空该房已采集的 rounds/predictions 全部历史**
   (回收即清史;策展房与未回收发现房的历史仍按 retention 滚动清理)。
   在播列表是**推荐流**,数日未上榜≠停播(间歇开播的主播可能没被带出);且这 7 天里
   该房照常被**直抓**(直抓不依赖列表在不在榜),一旦真实开播,数据一局不漏 —— 这正是
   grace 取 7 天而非几分钟的意义。`prune_grace_s<=0` 可关闭回收(只增不减,不建议
   长跑实例关闭)。**仅在遍历成功且非空时才回收**,一次网络失败/空响应不会误伤全量
   发现房。

多 worker 副本经 Redis `SET NX EX=遍历周期` 互斥:**锁即节拍**,同一周期全局只遍历
一轮(与 retention 同款)。

> **遍历耗时(实地核查)**:「单轮约 10s 内完成」只在低谷时段成立。
> 实测在播列表 **~49 房/页**、单页 RTT **~390ms**,逐页串行时:
>
> | 在播房数 | 页数 | 串行遍历 | vs 发现锁 TTL(= `interval_s` = 60s) |
> |---|---|---|---|
> | ~1000(凌晨低谷,实测) | 20 | ~10s | ✅ |
> | **10000(上游天花板)** | **204** | **~99s** | ❌ **锁在遍历途中过期** |
>
> 锁一过期,别的副本立刻抢锁开**第二轮并发遍历**,副本越多叠得越狠 —— 把繁星打成惊群,
> 正是本设计要避免的事,却**在上游达到 1 万房时必然发生**。已修:
> ① `discovery.page_concurrency`(默认 8)**波次并发翻页** → 204 页实测 ≈12–38s;
> ② worker 侧**锁续租心跳**(compare-and-expire,只续自己的锁)兜住网络劣化的残余风险;
> ③ `max_pages` 200 → 400(旧值 ×49 ≈ 9800 房,**一到 1 万房就静默截断**)。
**worker 启动时**先按 PG 时钟回灌运行态(`restore_discovered`):未超 grace 的发现房
恢复名录/发现集/抓取且 last_seen 原样保留(HSETNX,运行态更新者恒胜,多副本并发安全);
超 grace 的直接清理;已转正的跳过 —— 重启不清零 7 天计时。

### 10.3 开关与观测

- **开关**:`discovery.enabled`(默认 `true`)/ 环境变量 `STA_DISCOVERY_ENABLED=false`
  可整体关闭自动发现,仅保留手动添加。
- **观测**:`GET /api/discovery/status` 返回开关/周期/当前发现房数 + 最近一轮遍历统计
  (页数 / 在播房数 / 新增 / 回收 / 耗时 …);`GET /api/crawler/status` 的 `discovery`
  字段同源(附加字段,契约兼容,前端可忽略)。
- **负载提示**:在播列表约数十页(瞬时 ~2000 房);但 grace=7 天意味着**一周内出现过
  的所有房**都保持在抓(离线房也占常规抓取预算,直到 7 天到期),留存规模可达瞬时
  在播数的数倍。系统按真机实测账本设计(每局 11.2ms CPU → 每副本 ≈4300 房;错峰抖动 + 令牌桶 + 首抓铺开),超出时**首选
  横向扩 worker**(副本共享 Redis 延迟队列,自动去重/负载均衡;发现/回收/清理循环经
  Redis 锁互斥,多副本安全):

  ```bash
  docker compose up -d --build --scale worker=3   # 默认 3;按需 ≈⌈总房数/4300⌉+1,硬顶 11(见 §5.1)
  ```

  并按需给 `ratelimit.upstream_rps` 设正值(见 §11 配置表)、或调低 `prune_grace_s`
  收紧留存窗口。

### 10.4 hist-mode:发现房的 GameHistory 轮询(默认关)

**动机(实地核查账本)**:舰队主体是 7 天并集的发现房,它们此前走与策展房完全
相同的实时管线(每局 1 MainPage + ~1 RoundAward),而这些实时产出**没有任何
实时消费者**——前端恒过滤发现房(`web._visible_rooms`)、SSE 每连接单房零订阅、
预测已被策展闸停掉。`histmode.enabled: true` 后,发现房退出实时管线,
改为每 `interval_s` 一次 GameHistory 整页(近 30 局)批量入库:

| 口径(1 万发现房) | 实时管线 | hist-mode(默认 T=900s) |
|---|---|---|
| 稳态请求 | ≈430 req/s | **≈11 req/s(1/39;T=300 时 ≈33)** |
| 其中 RoundAward | ≈200 req/s | ≈1 req/s(仅策展房) |
| 故障风暴上限 | ≈2800 req/s | **≤222 req/s(抢救节拍决定,与 T 无关)** |
| 数据完整性 | 逐局实时 | 零缺口(页页重叠),延迟 ≤T(默认 ≤15 分钟) |

策展房(名录里用户真正在看的房)管线**零改动**;`config.yaml` 金表
(`scripts/sim_history_gap` S0–S11)在模式关闭时与改动前**逐字一致**(实证)。

**硬约束(信息论,不可谈判)**:官方页窗固定近 30 局 ≈1500s——两次**成功**
轮询间隔一旦超过它,滑出页窗的局**永久不可再取得**(仿真反例 T=1800s → 42 洞)。
因此周期代码侧钳到 `[60, 1300]s`(`scheduler.effective_hist_interval_ms`,
claim_grace 先例);失败退避(90→180→300s 封顶)带**前瞻投影**——若
「距上次成功 + 本次退避」会越过 `edge_after_s`(默认 1200s),改用
`edge_retry_s`(45s)抢救节拍,越窗前恒有 ~6 次机会;真越窗后逐格登记
「官方缺失」止损并计入 `stats:histmode.window_lost`,绝不静默。

**双向有机迁移(热更即时,无风暴)**:开 = 各发现房下一拍 mp 原地改排轮询任务
(首拍满窗 U(0,T) 铺开消梳齿;存量 aw 跑完,一局内完成);关/转正 = 下一拍轮询
先做**收尾回填**把「上次轮询→此刻」尾窗封死,再切回实时管线(转正后序列首屏
即到最新、预测号随补链立即生成)。`/api/monitor/add` 会同时排 `hs@now` 触发
秒级封尾。

**覆盖语义同源**:轮询成功后的审计维护与实时哨兵**同一** `covWm` 水位——页窗内
缺格 = 官方缺失(与 MainPage 漏局分支同判据),页窗外缺格 = 越窗丢失(与既有
S6「页窗外免打直登」同语义 + 计数告警);转正后实时哨兵无缝接管同一水位。
`/coverage` 契约不变。

**观测**:`/api/crawler/status` 新增 `histMode` 块(`oldestPollAgeMs` 为第一
健康指标:> interval×2 黄、> edge_after 红;`windowLost` 应恒 0;`estReqPerSec`
请求预算);分钟统计行启用时追加「hist轮询 N 房(回填入库 M 局,最老成功 Xs 前)」
段;算力体检(`suggestReplicas`)按**等效实时房数**折算
(`scheduler.weighted_fleet_load`,成本系数 1.5 暂为保守估计,待微基准钉死)。
`scripts/probe_award_path.py` 已把 hist-mode 房单列,防「N% 靠回填」误读复活。

**验证**:`python -m scripts.sim_hist_mode`(H0 稳态账本 / H1 失败链 / H2
断供 10·20·30min 矩阵 / H4 双向迁移 / H5 页内官方缺 / H6 双副本互斥,全断言);
`tests/test_histmode.py`(钳位/投影退避/加权容量纯函数 + 处理器行为件 + H 矩阵
托管)。

### 10.5 curated-idle:空闲策展房降级(默认关;依赖 hist-mode)

**动机(把既有两条原则补完整)**:策展闸停掉了发现房的预测、hist-mode 让发现房
退出实时管线,依据都是同一条不变量——**实时资源只服务有实时消费者的房**。但
「策展房」的判据一直是「**曾经**被 monitor/add 加进名录」,而名录**永不自动退出**:
「加过就忘」的僵尸房照付全额实时管线(≈0.043 req/s/房)+ **预测引擎**
(策展闸之下,策展房是唯一还跑预测的角色,5.5ms/局)。本子模式把判据从
「在名录里」收紧为「**近期真被访问过**」。

冷房**仍在名录、前端照常可见**(`_visible_rooms` 只按发现集过滤,冷标与发现集
**分离**),只是暂以 GameHistory 轮询供数、预测暂停——**权重只冻结不损坏**
(存量 pending 结清后停推;唤醒后带着训练充分的权重醒来,严格优于发现房转正)。

**非对称铁律(与 `is_discovered`「判不出按策展走」同源)**:

| | 降级(慢、保守、可逆) | 唤醒(瞬时、激进) |
|---|---|---|
| 触发 | janitor 扫描(`SET NX EX=60` 跨副本互斥 → 全舰队 ≤1 扫/分钟) | 任意一次**用户侧真实访问** |
| 判据 | 访问年龄 ≥ `curated_idle_after_s`(默认 1800s)**且** `draws:{room}` **零订阅** | 无条件 |
| 守卫 | 年龄未知只 `ZADD NX` 播种、**绝不判闲**;NUMSUB 查询失败 → 视同有人在看,**整轮放弃** | — |
| 动作 | **只打冷标**,迁移交给该房**下一拍 mp**(≤50s)撞既有 hist-mode 迁移入口有机改排 | 清标 + `mp@now` + `hs@now` 封尾 |

**为什么降级只打标、不排任务**:复用 hist-mode 迁移入口整套机器(改排 / 满窗 U(0,T)
抖动 / 存量 aw 收尾)——**零新迁移机器**;各房 mp 相位天然铺开,结构上无风暴
(`curated_idle_batch` 只是「整夜集体空闲」的额外削峰保险)。

**唤醒 = `monitor/add` 转正同款序列**:`mp@now`(秒级回实时)→ 清冷标 →
`hs@now`(退出分支**先收尾回填**再改排 mp,把降级期间的尾窗当场补齐)——
序列首屏即到最新,**预测号随补链立即再生,零冷启动**。**再添加也唤醒**:
`monitor/add`、`add-bulk` 与挂起归一转正对既有冷房同样清标 + 访问戳置新
(人类意图 =「现在要监控」,「秒级起抓」契约必须兑现);**config 种子/boot
回灌故意不唤醒**(幂等入册 ≠ 有人在看,否则每次重启清空全部空闲态)。

**什么算「真实访问」**(实地核查前端后钉死):`/history`(**非** `passive=1`)、
`/history/days`、`/prediction`、`/coverage`、`/api/rooms/{room}`、SSE 连接与 20s
心跳。**`profile` 与列表端点不算**——前端启动期会为名录**逐房**回填头像
(`app.js` `upsertCustomRoom`/`mergeMyRooms` 实证),计入则永远无房可判闲;跨房
补拉沿用既有 `passive=1`「只读不拉起监控」约定。SSE 心跳每 20s 刷新时戳 ⇒
**开着直播视图的房年龄恒 <20s,永不达阈**。

**灰度纪律(shadow 先行)**:`curated_idle_shadow: true`(默认)时只把「本会降级的
房集」写进 `stats:histmode` 与状态页 `histMode.curatedIdle` 块(`wouldDemote` /
`wouldSample`),**不动作**;核对确认全是真僵尸、`falseWake` 恒 0 后再翻 enforce。

**默认关时逐字节零扰动(实证)**:闸的短路序为 `is_discovered` **先判** ⇒ 发现房
主体零新增命令;冷标只在 `histmode.enabled ∧ curated_idle_enabled` **双开**时才查。
真 Redis 命令计数实测:

| 档位 | 发现房 | 冷策展房 | 普通策展房 | web 读钩子 |
|---|---|---|---|---|
| **默认(双关)** | 1 HEXISTS | 1 HEXISTS(冷标**完全惰性**) | 1 HEXISTS | **0 条** |
| hist 开 / ci 关 | 1 HEXISTS | 1 HEXISTS(仍惰性) | 1 HEXISTS | 0 条 |
| 双开 | 1 HEXISTS(**短路**) | 2 | 2 | ≤1 pipeline/5s/房 |

即:默认档与旧 `is_discovered` **逐命令等价**;功能关闭后残留冷标对所有闸惰性,
其 hs 任务下一拍撞退出分支自行封尾切回实时(四路清标皆幂等)。

**收益诚实说**:常态名录 1~50 房时,省下的算力是**噪声级**——真正的价值是
**不变量诚实**(实时 ⟺ 有消费者)、治僵尸名录、消灭预测引擎最后一处浪费、上游
卫生;名录被 seed 到成百上千时收益才线性放大。**风险压在作者钉死「绝不能碰」的
策展主路**,故默认关 + shadow 先行 + 观众一票否决三重保守。

**观测**:`/api/crawler/status` 的 `histMode.curatedIdle` 块
(`coldCount`/`wouldDemote`/`wouldSample`/`demotes`/`promotes`/`falseWake`);
`falseWake`(降级后 <2min 即被唤醒)是「阈值调得太激进」的直接信号,应恒 0。
冷房与发现房同入加权负载 hist 桶(`weighted_fleet_load`),体检不撒谎。

**验证**:`tests/test_curated_idle.py`(纯函数分支 + fakeredis 往返 + 删房不变量 +
异常回退 + `_dormant` 布尔矩阵 + 有机改排 + 退出分支清标 + 扫描 enforce/否决/
shadow/自愈 + **真 janitor 单遍接线** + web 唤醒/passive 豁免/节流/双关零写)。

---

## 10.1 命中率补算（灵机推演的「近 N 局命中率」为什么会空，以及怎么填）

> **4.9.x 补充（冷位份额闭环上线后）**：`prediction.showcase_rotate` 引入的赤字账本是
> **路径依赖累加器**，而补算是冷启动重放 —— 账本从 0 起算，轮换的**相位**必然与实盘
> 不同。真机三房实测（热身 400 局 / 目标窗 400 局）：逐局判定还原 96.2% → **81.3%**
> （加长热身不收敛），但**命中率偏差 +0.08pp → −0.83pp，仍远在 ±3pp 契约内**。
> 补算的产品承诺本就是「回测不是实盘战绩、还原的是命中率统计」，故按该口径立钉
> （`tests/test_pred_replay.py::test_replay_fidelity_under_share_rotation`）。
> 逐局判定还原率在轮换口径下不再是可守的不变量 —— 任何打破冷位垄断的轮换调度都有
> 任意相位，属机制固有属性。完整说明见仓库根《灵机推演冷位垄断优化方案.md》§7。

### 病灶一：口径谎报（已修）

`db.accuracy` 旧实现是 `ORDER BY round_id DESC LIMIT window` —— 取的是「最近
window **条**有判定的预测行」，**不是**「最近 window **局**」。预测链连续时二者
重合，一旦中断过就分道扬镳：

> 房间当过策展房 → 被移出名录（或降级为发现房 / curated-idle 冷房）→ 预测停摆
> 数日 → 重新加入。retention 默认 7 天，`predictions` 旧行还在，于是 `LIMIT 100`
> 原样取回**几天前**那 100 条，前端照着渲染成「近100局 主命中 25%」。
> 实测：那 100 条只跨 1.4h，而最新一条距今 **142.6h**。

现在先取该房 `MAX(round_id)` 作锚（走主键 `(room_id, round_id)` 反向 index-only
scan，O(1)），再以 `round_id >= anchor-(window-1)*ROUND_STEP` 约束。**链连续的
健康房 n 恒等于 window，逐字节无变化**；只有原本就在说谎的场景才会变。

### 病灶二：新房命中率空白（本节的补算）

3.4.5 策展闸规定发现房只抓取入库、不跑预测引擎。代价是房间刚加进名录时
`predictions` 一行都没有，命中率整行空白，要攒满 100 局窗得等
100×50.001s ≈ **83 分钟**。修掉病灶一之后，靠陈年旧行凑出来的假窗口也不再成立。

**补算**（`app/pred_replay.py`）用**生产同一条代码路径**、按**严格因果**的时序把
窗口内缺的判定重跑补齐：每一局只用「该局及之前」的数据训练→预测→比对，
逐行打 `source='replay'`。它成立的根据是引擎 `Predictor.predict()` 是
`(seq, cfg, kv)` 的**纯确定性函数**——全文件无 `import random`、热路径不读墙钟、
状态全部可序列化（实测：同输入两次逐局全同；时间锚整体偏移 ±120s，1748 局里
只有 3 局变化）。

### 还原度（真机实测，非估计）

在仓库自带 `jiufa_data/spell_tamer_data.db` 的 3 个房（各 1500+ 局真实出怪与真机
落库预测）上测得：

| 热身 | 逐局判定还原 | 四码全同 | 命中率偏差 | 单房耗时 |
|---|---|---|---|---|
| 30 局 | 81–84% | 42–45% | 最大 6pp | 0.4s |
| 100 局 | 89–93% | 53–67% | 最大 5pp | 0.7s |
| **200 局** | **96–99%** | 79–90% | **≤1pp** | 1.1s |
| **400 局（默认）** | **98–99%** | 89–93% | **≤1pp** | 1.9s |

四码永远做不到 100% 复现：`ens` 差异普遍在 1e-3 量级，而 `explore_tie_eps`
默认 0.004，差异正落在平局容差带内会翻转近似并列的选位。这是**结构性**的，
但它在命中率这个统计量上被洗掉了——100 局样本自身的 1σ 抽样噪声就有 4.7pp，
远大于 ≤1pp 的系统偏差。故**默认热身 400，且热身不足的目标局一行都不写**。

⚠️ **`plan_span` 是保真的前提**：取数下界必须含「热身局数 **+ 一个完整训练窗**」。
只按热身长度切会把 24h 训练窗截短，实测还原率直接从 98% 掉到 **69%**
（`tests/test_pred_replay.py` 里有这条用例守着）。

### 诚实边界（写进文档也写进 UI）

**补算是回测，不是实盘战绩。** 即便逐局全同，仍有三处不可消除的偏差：

1. 用**今天**的 config 回放**过去**的数据。这套超参有 30 余个，若曾在同一段数据
   上调过即为样本内偏差；
2. 回放读的是数据库**最终状态**，含后来被 GameHistory 补齐的局——生产当时未必
   拿得到，属训练集层面的轻微事后信息；
3. 生产当时的票据过期、任务迟到、妖兽未知（`cid=NULL`）跳过结算，补算不会重现。

所以补算行**必须**带 `source='replay'`、`accuracy` **必须**单独计数
（返回 `replay` 字段）、`prediction_records` **必须**回 `source`。这三条是后端契约，
`tests/test_pred_replay.py` 与本节下方的四道闸各自守着，任何时候都不得撤。

**4.7.5 变更（前端展示层）**：推演卡与随身面板此前会在命中率行追加一个回测条数
角标，该角标已按产品要求移除，命中率行现恒为 `近N局 主中X · 防中Y`（= 4.4.x 文案）。
移除的**只是前端这一层展示**——上面三条后端契约一字未动，运维、管理台与单测的
溯源能力分毫未减；要恢复角标只需在 `assets/app.js` 的 `predStatText` /
`predStatTitle` 里重新读 `acc.replay`，无需碰后端一行。

⚠️ 随之而来的一条必须写明白：**命中率行现在把补算局与实盘局合在一个数里，
且不再声明**。「上局开X·主中」徽标的实盘过滤（`r.s !== 'replay'`）**仍在**，
那道更硬的保证没动——补算判定永远不会被显示成战绩。但若日后要让展示层本身
也重新自洽，正解不是把角标加回来，而是让 `accuracy` 增回 `live_main` /
`live_cover`、前端只显示实盘口径：文案同样清爽，数字本身即实盘，角标从此没有
存在必要。把补算伪装成实盘仍然是唯一不可接受的用法。

### 复查轮补上的四道闸（补算行绝不可冒充实盘）

首版只改了 `accuracy`，复查发现**修了一半**，四处已补：

| 缺口 | 后果 | 修法 |
|---|---|---|
| `latest_prediction` 未排补算行 | 补算恒填到 anchor ⇒ 必然满足换手回退的 `lp.round_id == latest`；在「补算已落库、实盘链未写出新 pending」的窗口里，前端**下一局主/防会显示补算号** | SQL 加 `source IS DISTINCT FROM 'replay'` |
| `prediction_records` 未按局锚定 | 前端在 `accuracy.n === 0` 时会回落到 `record` 自行算率（`app.js` 的 `PRED_EVAL` 分支）——**恰在唯一需要修的场景里**用几天前的旧记录算出假的「近40局」 | 与 `accuracy` 同源锚定 |
| 命中串未带溯源 | 「上局开X·主中」徽标会把补算判定当战绩显示 | 返回 `source`，前端徽标只认实盘（落回既有「无预测⇒整枚隐藏」态，不新增第三形态） |
| `replay_gaps` 用 `p.hit IS NULL` | 把「有实盘行、只是没结算」也当缺口：刚落地那局白烧 CPU；**永不结算的孤儿行**会让该房每个冷却周期都重跑补算、永远失败 | 改 `p.round_id IS NULL`（孤儿行的正解是补结算，那是 `_settle_only` 的职责，硬闯会以过期 detail 推乱 Hedge 权重） |

同类问题普查：`db.py` 里全部 `DESC LIMIT` 写法逐条核过，只有 `prediction_records`
与 `accuracy` 属「取近 N 条 ≠ 近 N 局」这一类；`pending_prediction` 因过滤
`actual_custom_id IS NULL` 而**结构上免疫**（补算行恒带 actual）；`history` /
`history_days` 的 LIMIT 是分页语义，不是同类问题。

### 第三轮复查:真机 PostgreSQL 端到端 + 并发 + 墙钟

前两轮的 DAO 层只有推理和假连接测试，这轮起了真实 PostgreSQL 16 全链路打过（29 项全绿），其中三项是**只能靠真库才验得了**的：

- **存量库升级路径**：先造一张没有 `source` 列的旧 `predictions` 表并塞入数据，跑 `migrate()` → 列补出、存量行 `source` 为 NULL（即实盘，零回填零锁表）、其余字段完好，且 `migrate()` 可重复执行。
- **JSONB 多行 VALUES 的参数类型推断**：`_build_replay_pred_sql` 一次写 100 行 × 8 参数，asyncpg 按目标列类型推断 jsonb 正常往返。
- **`ON CONFLICT DO NOTHING` 真的不覆盖实盘行**：构造实盘行后用补算行撞同一主键，实盘的 `main_ids`/`hit`/`source` 逐字不变。

**并发安全**：补算跑在线程池，与主循环的实盘预测共用同一个 `bridge` 实例。核查 `PredictorBridge._make_predictor` 每次调用都**新建** `Predictor` + kv 影子，实例上只有不可变的 `pcfg`/`catalog`；再以三线程并发 vs 串行结果对拍实证（逐条全同）。

**本轮修掉的缺陷 —— 墙钟越界**：跨副本锁的 TTL = 巡检周期（默认 60s），而 `replay_batch` 上限 200 × 单房约 1.9s ≈ 380s。锁一中途过期，别的副本就会并发开跑，协程头注承诺的「全舰队同一周期恰好一个副本在算」当场失效（每房冷却闸只防重复房，不防并发烧 CPU）。而配置说明恰恰在鼓励调大 batch（「批量加数千房时调大可加快回填」）—— 文档与代码互相打架。现加墙钟闸：逼近锁到期即收手，余下交下一轮；默认配置（8×2.4s≈19s）永不触发。

顺带删掉 `replay_window` 的 `yield_every`/`on_slice` 两个死参数（全项目零调用，留着会让人以为存在分片让渡机制）。

### 第四轮复查:配置漂移自愈 + 真 Redis/PG 集成 + 前端真 DOM

**本轮修掉的缺陷 —— 预测超参热更后无自愈。** 全部预测超参都是热更项
（`config_registry` 里一律 `hot=HOOK / hook="bridge"`，改动即原子换桥），而
`window_audit/` 这个离线调参工具的存在本身就说明「调超参」是预期中的运维动作。
调过之后，命中率窗口里会**同时**存在旧配置算出的补算行与新配置产出的实盘行，
而用户只看到一个数、分不出这是两套口径的混合。

这个问题是被一个**测试 bug** 炸出来的：集成测试第一版忘了装载 `config.yaml`
（裸 `Settings().prediction` 是空字典，真正的装填在 settings 的加载函数里），
补算于是用 `E.PredictionConfig` 的默认超参跑，而真机数据是用调优超参产出的 ——
逐局判定还原从 **97% 塌到 57%**、主+防偏差 **11pp**。测试是错的，但这个数字恰好
把「配置漂移」这条一直只能定性描述的诚实边界量化了，且远超 100 局样本自身
4.7pp 的抽样噪声。

自愈机制：
1. `pred_replay.config_fingerprint(bridge)` 取 `bridge.pcfg` 的稳定指纹（12 位 hex）。
   取 `pcfg` 而非原始 dict 是刻意的 —— 它已被 `PredictorBridge` 按
   `E.PredictionConfig` 的字段过滤，正是引擎真读的那些键；`replay_*` 这类**运维参数**
   天然不在其中，调它们不会误触发全窗重算。指纹必须稳定（排序后序列化再哈希），
   否则补算行每轮都被判过期、无限重算烧 CPU。
2. 每条补算行把指纹写进 `detail.replay.cfg`。
3. `replay_gaps(room, window, cfg_fp)` 除 `missing`（压根没有预测行）外，另返回
   `stale`（已有补算行但指纹已过期）。`cfg_fp` 传空串则不做该检查（向后兼容）。
4. `_replay_room` **先定向 DELETE 再重算**：`drop_replay_rows` 自带
   `source = 'replay'` 谓词，实盘行永不可删。刻意**不**把 INSERT 改成
   `ON CONFLICT DO UPDATE` —— 那会削弱「补算绝不覆盖实盘行」这条最硬的保证，
   而 DELETE 带谓词的安全性是可以一眼看穿、也可以单测的。

真库验过：把实盘行一并塞进删除列表，它删不掉。

**本轮补上的两层验证**（前三轮从未执行过）：

| 链路 | 此前状态 | 现在 |
|---|---|---|
| 真 PG DAO 全链路 | 只有推理 + 假连接 | 37 项全绿，含存量库升级路径、JSONB 多行 VALUES 参数推断、`ON CONFLICT DO NOTHING` 真的不覆盖实盘行 |
| 真 Redis + 真 PG worker 集成 | 两半各测各的，从未合起来 | 15 项全绿；灌入 1778 局真机出怪 + 空 predictions 表，补出 33%/66% vs 真机 34%/66%，还原 97% |
| 前端 | **只做静态源码扫描** | `frontend_replay_jsdom.js` 真 DOM 执行，16 项全绿（见 JFVIP-SYSTEM.md §9.6） |

顺带核实并排除的两处疑虑：`sw.js` 是空壳（无 fetch 拦截、无缓存），不会绕过
`?v=` 缓存击穿；局号格点假设在真机三房 7 天 36,278 局上实测成立（每房单一同余类、零非整倍
间隔），`accuracy` 的 `floor = anchor-(window-1)*ROUND_STEP` 算术安全。

### 第五轮复查:混淆产物验收 + 桥/指纹同源

**本轮最重要的一条 —— 前四轮验的都是源码,而用户拿到的是混淆产物。**
`build-deploy.mjs` 的混淆选项含 `renameGlobals: true`(顶层函数一律改名,只有
`JiufaShared`/`JiufaSim`/`JiufaDev`/`RoundEngine`/`RealGameBridge` 等跨文件契约在
`reservedNames` 白名单里)与字符串数组 base64+RC4 编码。原先那份冒烟按函数名
调用 `renderPredict()`,在产物上必然 `ReferenceError` —— 等于产物根本没验过。

已把 `frontend_replay_jsdom.js` 改成**只桩网络、走真实启动链路**
(`boot → dataBoot → loadRoom → predChase → refreshPrediction → renderPredict`),
同一份断言对源码与产物皆成立。实跑真实构建后:

| 目标 | 结果 |
|---|---|
| 仓库源码 | **16 项全绿** |
| 混淆产物(`dist/`,900 KB,控制流平坦 + 字符串数组) | **16 项全绿** |

顺带核实 `?v=4.6.0` 经 html-minifier 压缩后原样幸存。

**本轮修掉的缺陷 —— 桥被读了两次。** `_replay_room` 里 `self.bridge` 取了两次
(算配置指纹一次、丢进线程池一次),中间隔着几个 `await`。配置热更恰好插在中间时,
补算行会被盖上**旧指纹**却是用**新桥**算出的。虽然下一轮会判过期重算(自愈),
但那是白烧一整轮、且期间那个戳在撒谎。现改为取一次快照贯穿全函数;训练窗与
`max_train` 也一并从**同一份** `bridge.pcfg` 取(二者本就是 `E.PredictionConfig`
的字段,与指纹同源),不再从热更 dict 另取而与指纹脱钩。

**顺带补上的一处运维陷阱。** `window_audit/replay_harness.py` 是补算的审计参照物,
但它 `first_pred_idx=30` 而生产 `replay_warmup=400`。运维拿它复核会得到四码全同
约 88%、判定还原 81~84%,极易误判成「补算坏了」。已在该工具头部写明口径差异,
并指向真正的复核入口(`test_replay_reproduces_live_hit_rate_on_real_data`)。

另核实并排除两处:retention 清理判据是 `round_id < cutoff`,补算行只覆盖最近
`accuracy_window` 局(≈83 分钟),永不靠近截止线;过期检查那条新 SQL 的执行计划是
`Index Scan using predictions_pkey`(区间扫 + 过滤 ≤100 行),没有退化成全表扫。

### 第六轮复查:一个我写错了五轮的数字

**发现**：`replay_window` 的主循环对**喂进来的每一局**都跑一次引擎，包括那些
只为第一条目标提供 24h 训练窗的局。真机实测：窗 100 + 热身 400 时 `plan_span`
喂进 1778 局，其中 **1278 局属此列** —— 它们需要作为**数据**存在（bisect 会回看到），
但不需要各跑一次预测。

**后果不只是慢。** 我在配置说明、README、补丁说明里一直写「单房约 1.9s、
默认 8/60s ≈ 27% 单核」；真实是 **6.63s**、按 batch=8 算 **88% 单核** ——
给出的 CPU 预算是错的，而墙钟闸（0.8×60s=48s）在默认配置下会**几乎每轮触发**，
实际每周期只做得完 7 个房。

**根因**：第一轮做还原度测量的脚本用了 `start_idx` 只跑最后 500 局，而生产实现
没有 —— 两边的数字从一开始就不是一回事，我五轮都没对上账。

**修法**：主循环从「第一条目标的生成局再往前 `warmup` 局」起跑，前缀只作训练窗
数据。同时把 `detail.replay.warmup` 的口径从**绝对下标**改为**真实预测次数**
（起跑点前移后二者不再相等，用下标会让热身闸与审计戳一起失真）。

| | 修前 | 修后 |
|---|---|---|
| 单房耗时（真机集成） | 6.77s | **2.40s** |
| 逐局判定还原 | 97% | **99%** |
| batch=8 时的单核占用 | ≈88% | **≈32%** |

还原度不降反升 —— 因为热身从「plan_span 给多少算多少」变成了恰好 400 局，
而 400 正是实测的收敛点（800 局反而略降，见上表）。

新增两条回归钉：`test_pure_training_prefix_is_not_re_predicted`（喂 1000 局、
热身 50，断言引擎调用 ≤60 次）与 `test_warmup_stamp_is_true_prediction_count_not_index`。

### 第七轮复查:把剩下四处「从没执行过」的都跑一遍

第六轮的教训是「我引用的数字来自一个和生产不一样的脚本」，第五轮是「我验的代码
不是用户拿到的那份」。两次同源：**以为测的是那个东西，其实不是**。所以这一轮不再
重读代码，而是把清单上剩余的「从没真正执行过」的面逐个跑掉。

| 面 | 此前状态 | 本轮 |
|---|---|---|
| 管理台配置项 | 加了 5 个字段，从没看过管理台怎么渲染 | `reg.public_schema()` 实查：5 项类型/默认值/danger/热更等级/板块/说明齐备；既有 `admin_jfvip_jsdom.js` 57/0 |
| 真实 HTTP 端点 | 只经桩 DB 验过 `_build_prediction` | 真 ASGI + 真 PG + 真 Redis 打 `/api/rooms/{room}/prediction`，**24 项全绿**，坐实线上 JSON 含 `accuracy.replay` 与 `record[].s` |
| `_pred_replay()` 协程本体 | 只直接调过 `_replay_sweep`，循环从没跑过 | 新增 4 条：双闸关闭时零 Redis 零扫房、锁 TTL 随周期正确下传、停机 <2s（睡眠分步）、热开关关掉即停/打开即恢复 |
| retention 与补算行 | 只推理过 | 实跑 `purge_before`：30 天前的补算行随其局一起被清、窗口内的不受影响、判据是 `round_id` 与 `source` 无关 |

另核实：`deploy-maxxiang.sh` 的 `verify_markers` 只校验 4 个文件存在（均未改动），
`extract_zip` 兼容交付包多包一层 `maxxiang/` 的布局；`Dockerfile` 的
`COPY backend_async/app` 与 `COPY backend_async/scripts` 覆盖了本次全部新增文件，
`window_audit/` 不入镜像（那里的改动是纯开发期提示）。

**本轮没有发现新缺陷。** 两条失败都出在测试本身：协程对巡检周期有
`max(5, …)` 下限钳位（注册表亦 `ge=5`），而我的等待只给了 2.6s —— 按真实节拍
改到 6.2s 即通过。

### 工程约束（为什么是后台协程而不是任务）

最初设计是排一个 `rp|room` 延迟任务，**实地核查后否决**：`bus.scheduled_rooms()`
读反向索引 `sched:rooms`，janitor 用 `missing = active - scheduled` 自愈 MainPage
排程——一个只排着 `rp` 的房会被误判「已在排」，从而**永久失去 mp 自愈**。
现改为独立后台协程 `Worker._pred_replay()`，与延迟队列零交集，跨副本互斥与节拍
沿用 retention 同款 `SET NX EX=巡检周期`。

CPU 闸门三层：① 跨副本锁（全舰队每周期只有一个副本在算）；② `replay_batch`
（默认 8 房/周期，单房 ≈2.4s 真机实测 ⇒ 峰值 ≈32% 单核）；③ 每房冷却闸（默认 1h，
抢到才值得查 PG）。**稳态开销收敛为「一次 SMEMBERS + 零 SQL」**——窗口填满后
`replay_gaps` 恒回空，引擎一次都不跑。

**绝不触碰 `predictor_state`**：补算的 kv 从空冷启动、只在函数内传递、结束即丢弃。
PG 里那份是**当前**（相对被回放区间属于未来）状态，注入即前视污染；反向写回则
会改变实盘预测流，而 `predictor_bridge.py` 头注写明「用户明确要求不改预测逻辑」。
**实盘预测结果逐字节不受本功能影响。**

### 配置与关停

`config.yaml` 的 `prediction:` 段（管理台「预测引擎」板块可热改，全部标 danger）：

| 键 | 默认 | 说明 |
|---|---|---|
| `replay_enabled` | `true` | 关掉 = 只统计实盘攒出来的判定，新房从空白起步 |
| `replay_warmup` | `400` | 热身不足即整条丢弃；不建议低于 200 |
| `replay_interval_s` | `60` | 巡检周期，兼跨副本锁 TTL；新房最迟这么久后开始补算 |
| `replay_batch` | `8` | 每周期至多几个房 —— CPU 闸门 |
| `replay_cooldown_s` | `3600` | 每房探查最小间隔；`monitor/add` 与冷房唤醒会当场清掉该房的闸并走秒级快道（4.9.3）；补算异常落 5 分钟短退避而非吞整段冷却 |

关掉 `replay_enabled` 后本功能**完全退场**（协程 idle continue，零 Redis 零 SQL）；
已落库的补算行不受影响，仍带 `source='replay'` 被单独计数与标注。

### 第七轮复查（4.9.3）：「一直显示近44局」工单 —— 唤醒清闸兑现 + 秒级快道

**工单**：部分持续监控、近 24h 出怪序列全满的房，推演卡恒显「近44局 主中16 ·
防中10」，多日不变。**全链路实证复现成功**（真 PG + 真 Redis + 本仓库真实代码 +
`jiufa_data` 真机 1795 局数据做生命周期仿真，非推断）：

> 周期访问的房（每次看 10s，热尾 30min，其余冷段），访问间隔 C 决定每次打开
> 瞬间的 n：**C=60min 恒见 65、C=68 恒见 55、C=77 恒见 44、C=90 恒见 29** ——
> 连续十几次打开分毫不变，与工单逐字吻合。24h 序列由 hist 翻页补齐所以恒满，
> 但冷段没有预测判定；补算总是在用户看不见的热尾里才把窗补满，打开瞬间永远是
> 缺口值。雪上加霜的是**冷却闸残留**：上次热尾里的探查把 1h 冷却闸落下，唤醒
> 路径又从未清闸（见下），于是打开后的补算还要再等最长 1h。

本轮定位并修复的缺陷（编号沿用排查记录）：

| # | 缺陷 | 实证 | 修复 |
|---|---|---|---|
| D2 | 注册表自 4.6.0 承诺「转正/**唤醒**会当场清掉该房的冷却」，但 `replay_gate_clear` 全仓库只有 `monitor/add` 一处调用，`_touch_room`（唤醒）没有 | 仿真：C=60/68/77 恒见 65/55/44 | `_touch_room` 唤醒序列第④步：清闸 + 入唤醒快道；`worker._pred_replay` 睡眠循环逐秒 `SPOP` 排水（`_replay_wake_drain`），打开数秒内补满（节拍 ≤1s + 单房 ≈2.4s；24h 满窗真机实测 ≈5s，0→100） |
| D3 | 热身闸数学：史短房 n = H−401 恒成立 | 真机数据 H=445 → n=44（主中18 防中7，与工单同量级）；H=501 → 100 | 属设计内诚实边界（热身<400 的判定不可信）；由 D8 的可见注脚解释 |
| D4 | 格点洞后一局补算 pending 链断，永久不可补，且每个冷却周期都为它空烧一整轮引擎（≈2.4s）0 行落库 | rig：missing=1、saved=0、每轮 path=ran；真机样本库 1275859 房 3 洞/1 洞后局、3746870 房 4 洞/2 洞后局 | **不桥接**（桥接会判到实盘没判的局、kv 偏离生产路径，违背「生产同一条代码路径」）；改为 `_replay_room` 结构性可行性裁剪：全不可补时短路不跑引擎（判据与 `replay_window` 写出条件逐条对齐；传引擎仍是完整 missing，输出零漂移） |
| D5 | 孤儿行（实盘预测在、目标局开了、结算漏拍）：accuracy 数不到，`replay_gaps` 判据 `p.round_id IS NULL` 也不当缺口 —— 窗口里任何机制都填不上的黑洞 | 真 PG 制造 3 条孤儿 → 修复前 n 永久 −3 | `db.heal_orphan_settlements`：纯 SQL 账本修复（主优先 CASE 与 `fill_prediction_outcome` 逐字同源；铁孤儿判据 `+STEP<=anchor`），**绝不推权重**（本节早已裁定：过期 detail 推 Hedge 比不推更糟）；`_replay_room` 头部先补账再看窗 |
| D6 | 巡检 `sorted(active)` = 字典序严格优先级：吞吐 480 房/时（batch 8×60 轮）与 1h 冷却同拍，有缺口热房 >480 时尾部房**零份额**饿死 | 数学推演（每小时处理序列从同一批字典序头部重启） | 候选随机洗牌，期望份额均匀 |
| D7 | `_replay_room` 异常时冷却闸已按整段 1h 消耗 —— 一次 PG 瞬断让该房多等 1h | 代码路径 | 异常改写为 `REPLAY_FAIL_BACKOFF_S=300` 短退避（快道与巡检同款） |
| D8 | 「窗口 X 局，其余局无判定」只写在 predStats 的 title 悬浮里，手机（主场）无 hover 等于没写 —— 工单困惑的直接来源 | 4.3.7 轮已确立的结论 | 前端 4.9.3：`#predGap` 可见注脚「窗口100局 · N局暂无判定」，随身面板同步；`predStatText/Title` 一个字节未动（4.7.5 收束不变式） |

配套：`accuracy` 兑现本节早前预留的 `live_main/live_cover` 实盘分列（合并数 −
实盘数 ≡ replay，口径自证，前端不消费）；补算补满后经 SSE `pred-updated` 携
`{pred:{acc:1}}` 通知，前端新增监听器权威拉取（推送保鲜、拉取定真；旧前端本就
不监听该事件，零风险）。快道纪律：`_dormant` 同判据、每房仍走 `replay_gate`、
**anchor 为 0 的新房轻探不耗闸**（否则 add 后闸被空耗，真数据到位反要再等一个
冷却周期）、≤2 房/s/副本。

**验证**：`tests/test_replay_wake_fastlane.py` 13 项（快道五情形/退避/短路/补账
SQL 形状/分列/唤醒接线源码钉）；`test_pred_replay.py` 44 项全绿（`_FakeDB` 增
heal 桩，accuracy 断言并入新键）；真机端到端 rig：唤醒残留闸场景一次排水 n
0→100、孤儿 3 条全回填且 `predictor_state` 哈希前后一致、挖洞第二轮短路 <0.1s、
C=68 周期打开数秒内恒满窗。既有失败仅 `test_hot_rotate` 5 项与
`test_official_probability` 收集错（发货 zip 既有，与本轮无关，引擎不可改）。

---

## 11. 配置参考（`config.yaml` / `.env`）

优先级：**环境变量（`STA_` 前缀）> `config.yaml` > 代码默认**。常用项：

| 项 | 说明 | 默认 |
|---|---|---|
| `STA_PG_DSN` | PostgreSQL 连接串 | `postgresql://star:star@localhost:5432/spelltamer` |
| `STA_REDIS_URL` | Redis 连接串 | `redis://localhost:6379/0` |
| `STA_ENGINE_DIR` | 预测引擎（`spell_tamer_monitor.py`）目录 | 仓库同级 `jiufa_data/` |
| `STA_STATIC_DIR` | 前端 SPA 目录（web 用） | 空（不挂静态） |
| `STA_WORKER_CONCURRENCY` | 单 worker 的 consumer 协程数 | 800 |
| `STA_REDIS_MAX_CONN` | Redis 连接池上限(web/seed 基线;**worker 自动放大到
  `worker_concurrency+128`**,否则数百 consumer 并发打 Redis 会撞默认 100 上限) | 128 |
| `pg_pool_min` / `pg_pool_max` | asyncpg 连接池(应与 `worker_concurrency` 匹配:
  800 consumer 挤 16 连接会严重排队,已放大默认) | 4 / 32 |
| `STA_HTTP_CONN_LIMIT` / `_PER_HOST` | aiohttp 连接池上限 | 500 / 500 |
| `STA_STARMETA_CONN_LIMIT` | 繁星归一 aiohttp 连接器并发上限(第二层护栏) | 64 |
| `STA_AUTH_TICKET` / `_UID` | 上游登录票据 | 见 `.env.example` |
| `ratelimit.upstream_rps` / `burst` | 游戏 API 全局令牌桶速率 / 容量(**`rps=0` 不限制**;
  设正值启用限流,burst 随之生效) | 0 / 600 |
| `ratelimit.fanxing_rps` / `fanxing_burst` | **繁星归一**专用令牌桶(独立于游戏 API,
  防归一惊群封 IP;**`rps=0` 不限制**,被封时设正值启用) | 0 / 240 |
| `ratelimit.per_room_min_interval_ms` | 单房最小请求间隔(防自旋安全网;`0` 关闭) | 0 |
| `admission.canon_concurrency` | 批量准入的归一并发上限 | 32 |
| `admission.warmup_window_ms` | 批量首抓错峰铺开窗口(冷启动削峰 —— 1 万房冷启动含回填 1000 rps → 333 rps) | 60000 |
| `admission.batch_size` / `max_bulk` | 批量写库分块 / 单次添加上限 | 500 / 20000 |
| `scheduler.award_jitter_ms` / `mainpage_jitter_ms` | 错峰抖动上限 | 1200 / 4000 |
| `scheduler.mainpage_min_interval_ms` | MainPage 最小间隔（空转保护） | 8000 |
| `scheduler.stale_task_grace_ms` | 任务租约(必须 > 令牌等待 8s + 上游超时 15s = 23s,否则慢请求被重复领取;代码另有下限钳) | 30000 |
| `rare_log_multiplier` / `STA_RARE_LOG_MULTIPLIER` | 💎稀有出怪 INFO 阈值(旧 250 覆盖 12% 出怪 = 万房 24 行/s;500 仅沧溟龙 2%) | 500 |
| `prediction.*` | 逐字段透传给复用的预测引擎 | 见 `config.yaml` |
| `discovery.enabled` / `STA_DISCOVERY_ENABLED` | **自动发现**总开关(遍历在播列表自动纳管;见 §10) | true |
| `discovery.interval_s` / `STA_DISCOVERY_INTERVAL_S` | 遍历周期(秒);兼作跨副本互斥锁 TTL(持锁遍历期间有续租心跳) | 60 |
| `discovery.max_pages` / `STA_DISCOVERY_MAX_PAGES` | 单轮分页护栏(实测 ~49 房/页 → 1 万房 ≈204 页;旧 200 恰卡门槛会静默截断) | 400 |
| `discovery.page_concurrency` / `STA_DISCOVERY_PAGE_CONC` | 波次并发翻页(串行 204 页 ≈99s > 60s 锁 TTL → 多副本重复遍历;并发 8 → ≈12s) | 8 |
| `discovery.warmup_window_ms` / `STA_DISCOVERY_WARMUP_MS` | 新发现房首抓错峰窗口(消除惊群) | 60000 |
| `discovery.prune_grace_s` / `STA_DISCOVERY_PRUNE_GRACE_S` | 移除阈值(秒):加入后台后连续这么久未再出现在在播列表才移除;时钟存 PG,跨重启不清零;**`<=0` 永不回收** | 604800(7 天) |
| `discovery.request_timeout` / `page_delay_ms` / `conn_limit` | 单页超时(s)/ **波次间**礼貌间隔(ms)/ 连接器并发上限 | 10.0 / 0 / 32 |

**容量估算（稳态）**：5000 房、每房约每 50s 一局，稳态对上游的请求约
`5000 房 ×（1 次 MainPage + 1 次 RoundAward）/ 50s ≈ 200 req/s`；错峰抖动把这 200 req/s
抹平,避免出怪秒的尖峰。**QPS 默认不限流**(`upstream_rps: 0`);若要给上游设全局上限
(例如上游有配额或你想更保守),把 `upstream_rps` 设为正值(如 `300`)即可。需要更大
吞吐时**横向扩 worker 即可持续放大**(副本共享 Redis 延迟队列,自动去重/负载均衡;
迁移建表 `pg_advisory_lock` 串行、发现/回收/清理循环 Redis 锁互斥,多副本安全):
`docker compose up -d --build --scale worker=3`(默认 3),按需 ≈ ⌈总房数/4300⌉+1,硬顶 11(详见 §5.1)。

**冷启动 / 批量添加(瞬时洪峰)**：稳态没问题不代表「同时添加 5000 房」的**瞬间**没问题 ——
后者会同时引发归一惊群、首抓重排风暴、冷启动回填的连接争用。这三类洪峰由**第 9 节的批量
准入路径**统一削峰(繁星令牌桶 + 有界并发归一 + 60s 首抓铺开 + 批量写库),并配合本节的
连接池配比(Redis 池随 worker 并发放大、pg_pool 与 worker_concurrency 匹配)。**因此:
请走 `/api/monitor/add-bulk` 或 `seed_rooms` 批量添加,不要并发发起数千个单房 `add`。**

---

## 12. 运维要点

- **崩溃自愈**：任务用「租约式领取」（到期取出即把可见时间顺延一个 grace）。worker 崩溃
  未 ack 的任务会在 grace 后被别的 worker 重新领取,不丢局。
- **janitor**：每 30s 给「活跃但队列里没有任何未来任务」的房补一个 MainPage 起点,
  兜住冷启动 / 异常空档。
- **日志与规模**:万房规模稳态 ≈ 200 局/s。逐局「出怪」日志为 **DEBUG** 级(默认不出),
  稳态高层日志只有 janitor 的**分钟级聚合统计行**(`统计:近 60s 入库 N 局 · 活跃 M 房`)
  与 discovery/retention 的周期行。
  **稀有倍率日志的阈值(实地核查官方概率后定的)**:「稀有倍率保留 INFO 就等于低频」
  并不成立 —— 倍率 ≥250 的妖兽 = 白虹骥(6.5%)+ 焚天雀(3.5%)+
  沧溟龙(2.0%)= **12% 的出怪**,万房下 = **24 行 INFO/s ≈ 200 万行/天**,会把
  janitor/discovery/retention/WARNING 等真正有用的高层日志挤出 json-file 轮转窗口
  (50MB×5 下只剩 ~1.5 天可回看)。故阈值可配 `rare_log_multiplier`(默认 **500**,
  仅沧溟龙 2.0% → 万房 ≈4 行/s,回看窗口 ~9 天);设成 250 即回到「≥250 也打 INFO」。
  排障需逐局明细时 `STA_LOG_LEVEL=DEBUG`
  (万房下 ≈ 2-3 GB/天,短开即关)。compose 已给全部服务配 **json-file 轮转
  (50MB×5/服务)**:即便 DEBUG 或上游故障风暴期(每个失败请求一条 WARNING,
  万房全灭时可达数百条/s),日志也只会滚动覆盖,不会写满磁盘或反压容器 stdout
  管道卡住事件循环。
- **retention**：每房历史（`rounds`/`predictions`）默认滚动保留 **7 天**（为训练窗口裁决攒证据，工具见 `window_audit/`）
  （`retention.days` / `STA_RETENTION_DAYS`，`≤0`=永久保留）。worker 每分钟经
  Redis `SET NX EX=巡检周期` 抢锁——**锁即节拍**，多副本下同一周期全局恰好清一次；
  删除按 `round_id < cutoff`（round_id 即开局毫秒，北京时间口径）经 `ctid` 子查询
  **分批**执行（默认 5 万行/批、批间小憩、批数护栏），删后即时 `ANALYZE` 保证
  下一轮稳定走 `idx_*_round` 索引；`predictor_state`（模型权重）与 `rooms`
  （名录）是当前状态，永不清理。最近一次清理统计写入 Redis，
  `GET /api/crawler/status` 的 `retention` 字段可观测。
  **存量大表升级注意**：首次启动 `migrate()` 会建上述两个索引（`IF NOT EXISTS`，
  advisory 锁全进程串行化，且已显式放宽超时至 1h）——数千万行老库构建期间
  **写入阻塞、读取正常**；零停机做法是升级前先手工
  `CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_rounds_round ON rounds(round_id);`
  与 `idx_pred_round ON predictions(round_id);`。首轮清理会分多个周期消化存量
  （批数护栏 + `capped` 标记续删），且优雅停机可在批间即时中断。
- **幂等写入**：`rounds` 主键 `(room_id, round_id)` + `ON CONFLICT DO NOTHING`,
  多 worker 或重试重复抓同一局不会写重。
- **时钟域**：上游返回服务器时钟；调度队列用本机 wall-clock；转换只用「服务器此刻到
  目标时刻的相对差」加到本机此刻,天然免时钟漂移。
- **TimescaleDB（可选）**：`db.py` 注释中给出把 `rounds` 变超表的 SQL,便于更佳的
  高频写入与保留策略。

---

## 13. 已知差异与迁移边界（复查审计结论）

本节诚实记录与旧后端的**有意差异**,以及经逐字段比对后确认一致的关键契约,
供上线评估。

**两处曾被当成"数据不对"的坑,现行机制如下**

- **SSE 校时下发陈旧钟(倒计时回溯/±10s 抖动/「剩 20s 出数据」三症同源)**:
  **快照里的 `serverNowMs` 不是「当前服务器时刻」**(它是抓取那一刻的钟,陈旧
  0~50s;出怪推送恒陈旧 ~42s)。若把它直接下发,前端 calibrate() 以 EMA(α=0.2)
  吸收每拍钟差,单拍即回拖 ~8.5s —— 恰把相位从「出怪」拖回「备战/布置」,与出数据
  同一瞬间发生;**与房间数量、QPS 无关**(单房必现,机制确定)。故三处下发点
  (SSE hello/heartbeat、出怪推送、crawler/status)一律走
  `redis_bus.extrapolate_server_now`(host 当前时刻 + 快照实测钟差);
  `tests/test_timing.py` 以真实相位常量把「裸用快照钟必现回溯、外推钟恒贴真值」
  写成症状级回归断言,并经真 uvicorn SSE 实测首帧钟为外推值。

- **繁星归一「自回显」漂移(上游行为,已缓解)**:实测线上归一对短号**偶发**
  返回 `roomId=短号本身` 且判权威(如 321→321),并被 7 天正缓存放大 —— 短号
  一旦被当真实号开抓,mapi 不校验房号会抓到「凭空局」(§8 的警告成真)。缓解:
  ① 需求固定房一律在 config 里**钉真实号**(如 2678075)并经 `room_aliases`
  展示短号,零依赖归一;② 用户添加路径有准入限制兜底 —— 自回显的短号不在
  后台名录(名录只收在播列表的真实 roomId),会被直接拒绝,不会入册开抓。
  若发现某房数据可疑,可 `redis-cli DEL canon:<短号>` 清污染缓存后重试。

**已逐字段对齐（实地核对旧源码 + 前端调用点后修正/确认）**

- 上游请求：payload 键名（`activityId`/`roomId`/`roundId`）、紧凑 JSON body、
  浏览器头 + `x-auth-*`、`X-Error-Code` 处理、`100005/本局已结束` 静默重试
  —— 与旧 `SpellTamerClient._post` 一致；401/403 由「仅告警」升级为抛
  `AuthExpired`（worker 捕获后延时重排,为换票流程留钩子）。
- SSE：query 参数 **`roomId`**;event 行为自定义事件名
  `connected / heartbeat / room-updated`,出怪事件带 `id: round_id`;出怪载荷附**可选** `pred` 字段(`settled`=上局判定 {id,n,v}、`next`=新局推演 {target,main,guard};旧前端自然忽略);心跳 20s;
  心跳节拍上做**归一漂移自愈**（短号后台归一成功即换订阅）。
- 事件负载：`round` 含 `spell_key / spell_name / captured_at`
  （对齐旧 `round_from_cid`）;两类事件的 `timer` 均含 `canPlay`。
- 时间串：整项目统一**北京时间** —— `_iso` 与引擎 `ms_to_local`/`ms_to_date` 在
  代码内钉死 UTC+8（`BEIJING_TZ`），不随容器/系统时区漂移；镜像另内置
  `TZ=Asia/Shanghai`（含 tzdata），使日志与 `time.localtime` 同样落在北京时间。
- 房号硬性约束：**九法数据只允许按真实房号抓取**。归一暂不可用时绝不按原号
  开抓,而是进 `rooms:pending` 挂起（名录/live-rooms 占位可见）,由 worker
  janitor 周期重试归一,成功即自动转正开抓 —— 复刻旧
  `ensure_room + _resolve_loop` 语义（`/api/monitor/add`、`config.yaml` 注入、
  `seed_rooms` 三条入口一致执行;`--no-canon` 为显式旁路）。
- 繁星解析：`getStarInfo` 为路径式端点
  `fx{1,2}.service.kugou.com/room/aggregation/getStarInfo/{kid}/`;
  `roomStatus` 仅 `code==0` 采信;头像三条归一规则
  （`//`→https、`p{N}.fx.kgimg` 域改写、http→https）同旧 `_relay_logo`,
  前端直用外链,无需中继端点（前端未使用旧 `/fxav`）。

**有意的行为差异**

- SSE 握手限时：`/api/events` 建流时的房号归一限时 **1.5s**（超时按原号先行订阅，
  由 20s 心跳节拍的漂移自愈换到真实频道）——首帧 `connected` 恒定秒回，
  不被繁星网络拖慢；`lifespan` 冷启动注入配置房同样限时（超时转挂起）。
- 名录持久化：Redis 作**纯运行态**（compose 中 `--save "" --appendonly no`），
  名录/挂起集的持久层在 **PG rooms 表**（含 `pending` 列）；worker 启动时
  自动回灌 PG → Redis —— 对齐旧版「配置持久化，重启不丢」，且多副本回灌幂等。
- 挂起超龄放弃：待归一房 **>24h** 仍归一不成（多为无效房号）由 janitor 自动
  放弃并清净（旧版会无限挂起）；日志给出告警便于人工复核。
- 回填/校验对齐旧引擎：GameHistory 回填对**未知妖兽照常入库**（cid=NULL
  不参与编号统计）；回填覆盖到带 pending 预测的局时执行「仅结算」
  （= 旧 `announce=False` 语义：命中回填 + 权重推进，不生成新预测）；
  换局步进 >1 局触发**漏局补齐**；补漏校验由**缺口驱动的覆盖哨兵**
  （`worker._coverage_check`，无开关、恒开）承担：维护快照水位线 `covWm`
  （本地入库 ∪ 官方缺失 连续覆盖到的格点），顺序出怪时纯 Redis 步进（零 DB
  零上游），只审计已出静默区（head−2 局）的格点，检出「真漏抓」（库里无且未
  确证官方缺失）才过冷却闸调 GameHistory 一次定案；缺口已出官方历史页窗
  （近 30 局）的免打上游、直接确证登记——**数据完整时 GameHistory 零调用**；
  补不回的格点登记「官方缺失」（offmiss），同一格点绝不反复打。
  （旧「每 `history_every_rounds` 局盲扫」机制已在 9 场景真机仿真 + 契约测试
  验证后移除，`scripts/sim_history_gap.py` 保留其行为仿真器作基线对照。）
- 读接口不再惰性拉起监控：旧版访问 `history/profile` 会 `ensure_room`;
  新架构读写分离,监控只经 `monitor/add` / 配置 / seed 显式进入
  （`add` 已排即时任务,秒级起抓）。`passive=1` 参数保留兼容,新版语义下
  等价（读永远无副作用）。
- `history` 首见宽限（≤6s 等首批回填）仅对**活跃名录中的房**生效;
  未监控/不存在的房立即返回空,不再白等。
- 多副本 `migrate` 以 `pg_advisory_lock` 串行化,消除并发建表竞态。
- 静态兜底带路径穿越防护（realpath 前缀校验）。

**未迁移子系统（超出本次抓取链路重构范围）**

- `/api/account/*`（繁星扫码登录 + 账号库,旧 `accounts_backend.py`）与
  `/api/game/*`（模拟游戏,旧 `game_backend.py`）前端有入口但未在新 Web 中
  实现。共存方案：这两块与九法抓取完全解耦,可让旧 `server.py` 以独立端口
  继续承载,由反向代理把 `/api/account`、`/api/game` 路由过去;或后续按同样
  模式异步化。观测台核心（序列/战况/预测/倒计时/名录）不受影响。

## 14. 管理台（`/{入口}`，默认 `/admin-xdd` · 配置中枢）

`web` 进程内置全参数管理后台，入口 `http://<host>:5173/admin-xdd`（可配，见文首说明；登录 = 账号 + 密码 + 人机验证）。安全默认关：未设
`STA_ADMIN_PASSWORD`（或 `STA_ADMIN_PASSWORD_HASH`，生成：`python -m app.admin_auth
hash <口令>`）时，`/{入口}` 与全部 `/api/{入口}/*` 一律 503。鉴权细节见
`app/admin_auth.py` 头注释（HMAC 无状态会话 · 头 + cookie 双通道 · CSRF 双提交 ·
登录防爆破：令牌桶 + 失败额度先占后验 + 设备信任，5.2.0 · 可选 `STA_ADMIN_IP_ALLOW` 白名单）；端点清单与写路径守卫见
`app/admin_api.py`。能力：全参数检索（⌘K）/ 校验 / 热更 / 不可变 revision 链 /
一键回滚 / 实例收敛可视化 / 审计日志 / 名录管理 / 票据健康与酷狗账号库编辑 /
YAML·.env 导出。使用向导与安全说明见仓库根 README「管理后台」一节。


## 15. 登录系统（可选 · MySQL 用户库鉴权）

以外部 MySQL 5.7 用户库（`tb_user`：`user_name`/`pass_word`/`due_time` 到期/
`is_off` 封停）做登录识别；启用后前端必须登录才能用，**主播名录**与**酷狗账号库**
按登录账号隔离（监控本体仍全局共享，多账号同房零重复抓取；删除按引用计数收敛）。
**安全默认关**：不设 `STA_USERDB_HOST` 即整体关闭，一切行为与未启用登录时逐字节一致
——本仓库全部既有测试在“关闭态”下照跑照绿。

要点速览（完整方案/配置表/行为矩阵/FAQ 见仓库根 **`LOGIN-SYSTEM.md`**）：

* **用户库纪律**：对 `tb_user` 绝对只读；新建表仅 `guantai_user_session` /
  `guantai_login_log`（幂等 `CREATE TABLE IF NOT EXISTS`，首启自动）；
  gbk 连接（`user_name` 列 `gbk_bin`，中文用户名不乱码、大小写敏感）；
  存量口令形态自适应（明文/MD5/SHA1/SHA256，常数时间比较）。
* **会话**：HttpOnly Cookie（`jf_user_sid`），库存 SHA-256；30 天绝对 + 7 天
  空闲；单设备互顶默认开（Redis `guantai:user:kick` 广播即时失效多进程缓存）；
  逐次复核封停/到期（外部停号最迟一个缓存周期内全网下线）。
* **首登预置房**：账号首次登录自动把需求固定房（默认短号 `321`，真实号
  `2678075`）写进其名录，可删、删后不复种（PG `user_first_login` 标记与绑定
  同事务；首登已满额的存量账号只燃标记不塞房）；预置随手做同款幂等全局登记
  （运维钉住语义）；`STA_USER_FIRST_LOGIN_ROOM` 可换房或关闭（`off`）。
* **防护**：登录节流（用户名/IP 双维度，Redis 计数 + 进程内兜底）；CSRF 自定义头
  `X-JF-Auth`（SSE 与 `<img>` 头像两个只读端点豁免头、Cookie 门照过）；
  用户库瞬断时已验证会话有 10 分钟降级窗，观测台不熄火。
* **多网络入口（4.5.0）**：`STA_USERDB_HOST` 可填**一组**「同一逻辑库的网络入口」
  （`ip[:端口][*权重]`，逗号分隔），用于把「单个弹性 IP 出口带宽有限」横向摊开；
  坏入口自动摘除、恢复自动收回，填成别的库会被身份指纹当场识破并隔离。
  单值 = 与 4.4.x 逐字节同行为。上线前跑 `scripts/userdb_check.py --endpoints`
  与 `--bandwidth`；运行期看 `GET /api/{入口}/userdb/endpoints`（含每入口精确字节账）。
  完整设计见根 `LOGIN-SYSTEM.md` §5.5。
* **启用**：`deploy/.env` 填 `STA_USERDB_HOST/PORT/NAME/USER/PASSWORD` 五行 →
  `docker compose up -d --build web`。启用前建议在部署机跑
  `python3 scripts/userdb_check.py`（连通/字符集/权限/口令形态/时区一键体检，
  `--init` 可手动建表，`--probe-user/--probe-pass` 实测真实账号）。
* **复查加固**（同版本）：管理台 Cookie 旁路仅认 POST（封 GET+Lax 的 CSRF 面）；
  SSE 心跳节拍复核会话，被顶/封停/到期 `authRevoked` 断流；运维显式添加=清用户
  转正溯源（钉住）、运维全局删除=级联清各账号绑定；官方皮肤 iframe 模拟存档
  （`jf3:sim`）按账号命名空间；账号库诊断快照（/diag）按账号隔离；名额闸双键判已绑、爬虫状态取名录失败收口为空（fail-closed）。细节见根 `LOGIN-SYSTEM.md` §2/§4。
* **代码地图**：`app/userauth.py`（鉴权/会话/节流/中间件与 `/api/auth/*`）、
  `app/db.py` 的 `user_rooms`/`user_added_rooms`/`user_first_login`（按账号名录绑定与首登标记，存本地 PG）、
  `app/accounts/accounts_backend.py` 的 realm 机制（账号库按用户分文件
  `accounts-u<id>.json`，contextvars 随线程池传递）、`app/web.py` 各端点的
  按账号分支；端到端冒烟 `scripts/smoke_auth.py`，测试 `tests/test_userauth.py`。

## 15.1 注册系统（可选 · 前端自助注册）

给登录门加**前端自助注册**，写入与登录同一份 `tb_user`，并以**九层纵深
（R0–R8）**把恶意批量注册的产出压到 ≈0、速率压到有界、总量压到有顶。
**不配置即不存在**：`STA_USER_REG_MODE=off`（默认）时端点回 503、前端零入口，
行为与未引入注册功能前一致。完整方案见仓库根 **`REGISTER-SYSTEM.md`**。

* **用户库纪律（红线重画）**：`tb_user` **旧行绝对零改动** —— 全项目永远没有
  UPDATE / DELETE / ALTER / TRUNCATE 触及该表；仅注册启用时存在**恰好一条**
  INSERT（新行）。`tests/test_register.py::test_tb_user_sql_discipline` 静态扫描
  全部源码钉死此纪律。观测台侧封禁走自建 `guantai_user_block`，`is_off` 的写权
  仍完全属于外部续费系统。新表三张，全部 `guantai_` 前缀、幂等自建。
* **三档模式**（管理台「注」视图热切换）：`off` 关闭 / `invite` 邀请码（**推荐
  起步**，无码寸步难行，码带配额·有效期·赠送天数·可禁用）/ `open` 开放注册。
* **R0 经济闸（核心）**：默认**零赠送**（`due_time=NOW()`）——注册出来的空壳号
  连登录都过不去（既有 403 `expired` 硬闸），攻击产出 ≈0。赠送 >0 时才有“战利品”，
  由 R1/R2/R3/R6 联合定价。
* **R2 双证明**：`powAnswer`（混淆 JS 执行证明，与 L2 同一变换）⊕ SHA-256 前导零
  PoW（内联 Worker 纯 JS 实现，**刻意不依赖** `crypto.subtle` —— 内网 http 部署
  下安全上下文不可用）。难度自适应只升不降（同 /24 高频、全局水位、同指纹超限），
  硬顶 25 位；服务端验证恒 O(1)。
* **R1/R6**：限流按 IP·时/日、成功数/日、同名/10 分钟、挑战签发/10 分钟；
  Redis 抖动**退化为进程内计数而非放开**（与明细读路径的 fail-open 刻意相反）。
  熔断**达到即降档**（open→invite→off），损失有硬上界；**不自动回升**，恢复须
  管理台显式点击（自动恢复会被脉冲攻击当节拍器玩弄）。
* **口令规则**：**5–16 位字符，无字符组合限制**（不强制大小写/数字/符号搭配，
  纯数字亦可）。技术性底线仅两条：禁控制字符；`plain` 形态须 gbk 可编码。
  入库形态 `STA_USER_REG_PASS_SHAPE`（plain/md5/sha1/sha256）**必须与外部续费
  系统的校验兼容** —— 跨系统契约，预检工具按库里多数派给建议值。
* **启用前必跑**：`python3 scripts/userdb_check.py --reg-preflight` —— 实测
  tb_user 全列（点名 NOT NULL 且无默认者并生成 `EXTRA_COLS` 建议 JSON）、
  `pass_word` 真实列长（裁决 sha256 是否可选）、`user_name` 唯一键存在性、
  INSERT 权限（事务内 ROLLBACK，零数据副作用）。
* **管理台「注」视图**：模式热切换（危级二次确认）、熔断状态与手动恢复、
  今日/7 日曲线与 PoW 难度水位、邀请码批量生成/禁用、注册流水分页与筛选、
  观测台侧封禁/解封。全部写操作经既有管理审计通道落盘。
* **代码地图**：`app/userauth.py`（注册路由/校验/`_register_tx` 事务/挑战与限流/
  邀请码与封禁 DAO/熔断）、`app/powproof.py`（执行证明变换单一真相源，L2 与
  注册共用）、`app/admin_api.py` 的 `/api/{入口}/reg/*`、`scripts/userdb_check.py
  --reg-preflight`、`index.html` + `assets/app.js`（注册态 UI 与求解 Worker）、
  `assets/admin.js` 的「注」视图；测试 `tests/test_register.py`（含 tb_user 纪律
  静态钉、JS↔Python 活体对拍、并发抢注原子性），前端整机冒烟
  `scripts/frontend_reg_jsdom.js`（源码与**混淆产物**两种形态各跑一遍）。


## 排障:前端反复轮询 /history 才等到上一局出怪(施法期倒计时 ~28s 现象)

**症状**:偶发某局,前端在施法期反复访问 `/history` 直到撞见上一局出怪;多数局则秒达。
本质=该局 **SSE 推送丢失**(数据其实早已 36.5s 准点落库),前端只剩轮询兜底。

**三条丢推通路(已修)**:
1. 结算异常连坐 —— 旧序 settle→publish 且任务已 ack:settle 偶发异常 → 任务重排 →
   重入被入口 has_round 短路 → 永不推送。现:推送先于结算且解耦,settle 异常仅告警、
   不重排(缺口由下一局 pending 自然顶替自愈)。
2. 未知妖兽(cid=NULL)局 —— 旧 `is_new and cid` 整体挡掉推送。现:照推(带
   `unknownBeast: true`),前端即刻渲染原名、停止空转轮询;结算/预测仍仅在 cid 已知时进行。
3. history 抢先入库(哨兵/漏局/升级顺带页) —— aw 到点走入口短路,旧版无推送。
   现:短路路径按 `latestRoundId` 落后即补发轻量 `roundsTouched`(前端按既有行为拉一次
   /history 增量即秒达),幂等。

**指纹分诊 SQL**(判断某历史时段属于哪条通路 / 是否上游就绪晚):
```sql
SELECT round_id, source,
       extract(epoch FROM created_at)*1000 - round_id AS lateness_ms
FROM rounds WHERE room_id = :room
ORDER BY round_id DESC LIMIT 300;
```
lateness ≈ 36500~38000 = 正常首取;38~62k 且 source=award = 就绪晚经退避阶梯命中
(谷段密化:锚 +18/21/24 及末锚 26.5 复拍,award 命中可延至 ≈61.7k);
≈62k 且 source=history = 空奖升级兜底(与末锚 award 同区间,以 source 字段分诊);
≥100k = 哨兵补漏。若 lateness 正常而前端仍晚 → 即上面三通路的丢推
(修复后由契约⑱钉死:tests/test_industrial.py::test_draw_push_never_lost)。

**前端配套建议**:出怪等待期优先消费 SSE(room-updated / roundsTouched);/history
轮询加退避(0.8s→3s 封顶)仅作 SSE 断线兜底。

---

## 数据生命周期(5.4.0)

「库里每一张表凭什么不会无限增长」现在有单一真源:`app/lifecycle.py` 的 `TABLES` 登记了两个库的
全部 21 张表(类别 / 怎么清 / 凭什么有界 / 谁来清),并由 `tests/test_lifecycle.py` 与建表 DDL、
真库实际存在的表对拍 —— **新增一张表而不登记,CI 当场变红**。

- `rounds` / `predictions`:仍由 worker `_retention` 每小时裁剪(本节未动);
- 其余小表:web 进程统一清扫(启动后 1~2 分钟首扫 → 每 6 小时;积压 60s 续扫;失败 10 分钟重试),
  自适应分批、逐表隔离、失败可见;用户库语句走维护通道 `run_maint`(超时不熔断入口);
- 管理台左栏「储」:各表大小、策略、上次清扫结果与告警,可「立即清扫」。

新增表时:① 在 `db.SCHEMA` 或 `userauth._SCHEMA` 建表;② 在 `lifecycle.TABLES` 登记它属于哪一类;
③ 若是滚动流水,给它写清扫任务(用户库表写在 `userauth.janitor_sweep`,PG 表写在 `lifecycle.sweep_pg`)。
新增审计动作时:在 `lifecycle.AUDIT_SESSION_ACTIONS` / `AUDIT_EVIDENCE_ACTIONS` 里表态。

Redis 里按房间 / 用户 / 会话 / IP 拼接的键模板同样有单一真源:`lifecycle.REDIS_FAMILIES`(机器闸同上,
新增一族不声明「凭什么有界」即红);离场房的快照由 web 每 6 小时回收。管理台的分析型查询(流水分页、
风控聚合、营收统计)用 `userdb_pool.heavy_reads` 标记:超时只报给管理台,不熔断用户库入口;
与用户侧共用的检索函数(订单 / 开通流水,也服务 `/api/vip/orders`)不在定义处标记,改在管理台调用处用
`userdb_pool.heavy()` 临时开启 —— 用户侧的业务查询超时照常熔断。

实测数据、参数表与已知边界见仓库根 **`DATA-LIFECYCLE.md`**。

