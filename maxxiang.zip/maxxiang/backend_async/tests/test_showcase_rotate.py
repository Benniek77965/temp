# -*- coding: utf-8 -*-
"""
test_showcase_rotate.py — 冷位份额闭环·赤字调度(《灵机推演冷位垄断优化方案.md》)回归钉
================================================================================
背景:showcase 对「本局带几只冷门」(k)有份额闭环(showcase_kdist 的 _kd 分位控制器),
对「带哪几只」没有 —— 冷位是对固定冷池 (3,4,5,6,9) 做 argmax(融合概率),而冷池内的
概率序在千局尺度上几乎不翻转,于是冷位退化成常数。真机三房 7 天 34,988 成熟局
实测(关轮换、其余生产口径):号5/号6 进四码 61.9%/67.0%、号3 5.2%、号9 3.2%(几乎
全靠 patrol 保底露面,保底率 3.04%);相邻局四码集合全同 35.1%、同四码最长连推 14 局、
单号最长连续在册 410 局、组合熵仅 4.44 bit。

改造以 showcase_rotate 总开关收束三机制:
  ① 目标份额 ∝ p^eta(可设下限)—— 与 k 的份额闭环同构;
  ② 赤字账本(Deficit Round-Robin)驱动身份选择,确定性、零随机源、EV 失真有解析上界;
  ③ 同四码集合连推硬帽(与 as_breaker「连败才换」互补:这条「连推就换」)。
开关关闭时与改造前**逐局字节级等价**(改造期全量回放逐局全同,离线门禁见
window_audit/analyze_rotate.py --gate)。

本文件是可长期跑的仓内钉(不依赖 PG/Redis/真机 DB):
  ① 配置三方一致:引擎 dataclass ⇄ config.yaml ⇄ config_registry 同键同值;
  ② 开关关 = 全刻度失效(as_* 式等价门禁的仓内代理),且非 showcase 风格恒惰性;
  ③ 连推硬帽是**硬不变量**:同四码集合连推 ≤ sc_repeat_cap,且 why 落款「硬帽」;
  ④ 份额收敛:长驱动后每个冷号都拿到份额,且赫芬达尔指数显著低于原版;
  ⑤ 状态往返 + 向后兼容:dbt/rep 经 kv JSON 逐字段还原;旧状态(无新字段)直接可用;
  ⑥ 指纹深度:末 3 局同号不再触发整局复用(原版 seq[-3:] 的碰撞面)。
"""
from __future__ import annotations

import json
import math
import os
import random
import sys
from collections import Counter
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "backend_async"))
os.environ.setdefault("STA_ENGINE_DIR", str(ROOT / "jiufa_data"))

from app.predictor_bridge import PredictorBridge  # noqa: E402
import spell_tamer_monitor as E  # noqa: E402
from app import config_registry as reg  # noqa: E402
import yaml  # noqa: E402

COLD5 = (3, 4, 5, 6, 9)
HOT4 = (1, 2, 7, 8)

# 定稿刻度(与 config.yaml / config_registry 同源)。引擎 dataclass 的 showcase_rotate
# 缺省特意为 0 —— 裸引擎嵌入方拿到的是「未开刀」姿态,由部署配置显式开启;
# sc_fp_depth 同理缺省 3(= 原版行为)。
FINAL_DIALS = {
    "sc_eta_cold": 1.0, "sc_eta_hot": 20.0, "sc_floor_cold": 0.08,
    "sc_floor_hot": 0.0, "sc_lambda": 0.6, "sc_debt_cap": 4.0,
    "sc_repeat_cap": 3,
}
BOOL_DIALS = {"sc_beta_off": 1}
YAML_ONLY = {"showcase_rotate": True, "sc_fp_depth": 12}
STR_DIALS = {"showcase_cold_ids": "3,4,5,6,9"}
SC_KEYS = (("showcase_rotate",) + tuple(FINAL_DIALS) + tuple(BOOL_DIALS)
           + ("sc_fp_depth",) + tuple(STR_DIALS))

BASE_CFG = {
    "predict_mode": "adaptive", "adaptive_lambda": 0.3,
    "explore_style": "showcase", "explore_patrol": 35,
    "showcase_q": 0.78, "showcase_kdist": "45,30,15",
    "seat_order": "recency", "hedge_eta": 0.15, "hedge_mix": 0.02,
    "anti_stubborn": 1, "as_alpha": 0.08, "as_alpha_ord": 0.14,
    "as_mcap_hot": 0.12, "as_mcap_cold": 0.18, "as_gamma": 0.15,
    "as_pen_cap": 8, "as_pen_on_hit": 0, "as_breaker": 3, "as_khyst": 0.05,
    "as_cooldown": 0, "as_beta": 0.3, "as_agecap": 24,
}
ON = {"showcase_rotate": 1, "sc_fp_depth": 12, **FINAL_DIALS, **BOOL_DIALS}

# 真机口径的出怪频率(三房合并实测,单位 %);用固定种子生成可复现的驱动序列。
REAL_W = {1: 21.3, 2: 16.6, 3: 3.7, 4: 5.7, 5: 8.9, 6: 8.2, 7: 17.2, 8: 16.2, 9: 2.1}


def _seq(n: int, seed: int = 20260731):
    rnd = random.Random(seed)
    ids, w = list(REAL_W), [REAL_W[c] for c in REAL_W]
    return rnd.choices(ids, weights=w, k=n)


def _drive(cfg_extra, n_rounds=260, warm=520, seed=20260731):
    """因果驱动器:predict → 按真机频率抽下一局 → 结算 → 再 predict。
    kv 逐局经 bridge 往返(与 worker._settle_and_predict 同语义)。"""
    bridge = PredictorBridge({**BASE_CFG, **cfg_extra}, {})
    full = _seq(warm + n_rounds, seed)
    kv, recs = {}, []
    prev = None
    for i in range(n_rounds):
        seq = full[:warm + i]
        res, dirty = bridge.run_prediction("t", seq, kv)
        kv.update(dirty)
        four = tuple(res["main"]) + tuple(res["guard"])
        nxt = full[warm + i]
        recs.append({"four": four, "actual": nxt,
                     "why": ((res.get("explore") or {}).get("why") or ""),
                     "st": json.loads(kv.get("explore_state") or "{}")})
        if prev is not None:
            kv.update(bridge.update_after_settle(
                "t", {"models": prev["models"], "ens": prev["ens"]}, nxt, kv))
        prev = res
    return recs, kv, bridge


def _maxrun(recs):
    b = cur = 1
    for i in range(1, len(recs)):
        cur = cur + 1 if set(recs[i]["four"]) == set(recs[i - 1]["four"]) else 1
        b = max(b, cur)
    return b


def _hhi(recs):
    sel = Counter()
    for r in recs:
        for c in r["four"]:
            if c in COLD5:
                sel[c] += 1
    tot = sum(sel.values()) or 1
    return sum((sel.get(c, 0) / tot) ** 2 for c in COLD5), sel, tot


# ── ① 配置三方一致 ────────────────────────────────────────────────────────────
def test_config_three_way_consistency():
    fields = E.PredictionConfig.__dataclass_fields__
    for k in SC_KEYS:
        assert k in fields, f"引擎缺字段 {k}"
    c = E.PredictionConfig()
    # 4.9.7 起翻面:裸引擎缺省由 0(未开刀姿态)改为 1(默认开启份额闭环)。
    # 放弃的纪律要写明白 —— 此前「裸引擎 = 改造前逐字节等价」这条不再成立,
    # 任何直接 E.PredictionConfig() 构造(不经 config.yaml)的调用方,行为都随之改变;
    # window_audit/ 下的诊断器若依赖「缺省即原版」需显式传 showcase_rotate=0。
    # 原版姿态仍可完整复现:显式置 0 即可(test_off_switch_makes_all_dials_inert 守着)。
    assert int(c.showcase_rotate) == 1, "裸引擎缺省必须是开(4.9.7 起)"
    # 4.9.7 与 showcase_rotate 同批翻面:轮换开则指纹深度必须是 12。深度 3 的碰撞
    # 会跳过赤字推进,而赤字账本就是轮换的心脏 —— 二者成对,不许单独翻其中一个。
    assert int(c.sc_fp_depth) >= 12, "轮换缺省为开时,指纹深度缺省必须 >=12(成对约束)"
    for k, v in FINAL_DIALS.items():
        assert float(getattr(c, k)) == pytest.approx(float(v)), f"引擎缺省 {k} 偏离定稿刻度"
    for k, v in BOOL_DIALS.items():
        assert int(getattr(c, k)) == int(v), f"引擎缺省 {k} 偏离定稿刻度"

    raw = yaml.safe_load(open(ROOT / "backend_async" / "config.yaml", encoding="utf-8"))
    pred = raw["prediction"]
    assert bool(pred["showcase_rotate"]) is True, "部署配置应显式开启份额轮换"
    assert int(pred["sc_fp_depth"]) >= 12, "部署配置应打开指纹碰撞修复"
    for k, v in FINAL_DIALS.items():
        assert float(pred[k]) == pytest.approx(float(v)), f"config.yaml {k} 偏离定稿刻度"
    for k, v in BOOL_DIALS.items():
        assert int(bool(pred[k])) == int(v), f"config.yaml {k} 偏离定稿刻度"
    for k, v in STR_DIALS.items():
        assert str(getattr(c, k)) == v, f"引擎缺省 {k} 偏离定稿刻度"
        assert str(pred[k]) == v, f"config.yaml {k} 偏离定稿刻度"

    for k in SC_KEYS:
        assert k in reg.PREDICTION_KEYS, f"注册表 PREDICTION_KEYS 缺 {k}"
        f = reg.REGISTRY[f"prediction.{k}"]
        assert f.danger and f.hook == "bridge"
        assert f.default == pred[k], f"注册表默认 {k} 与 config.yaml 漂移"


# ── ② 开关关 = 全刻度失效 + 非 showcase 风格恒惰性 ────────────────────────────
def test_off_switch_makes_all_dials_inert():
    wild = {"sc_eta_cold": -3.0, "sc_eta_hot": 0.0, "sc_floor_cold": 0.2,
            "sc_floor_hot": 0.25, "sc_lambda": 3.5, "sc_debt_cap": 12.0,
            "sc_repeat_cap": 1, "sc_beta_off": 1}
    a, _, _ = _drive({"showcase_rotate": 0})
    b, _, _ = _drive({"showcase_rotate": 0, **wild})
    assert [r["four"] for r in a] == [r["four"] for r in b], \
        "showcase_rotate=0 时任何 sc_* 刻度都不得改变输出"
    # 确定性:同配置再跑一遍逐局全同(含 why)
    c, _, _ = _drive({"showcase_rotate": 0})
    assert [(r["four"], r["why"]) for r in a] == [(r["four"], r["why"]) for r in c]
    d1, _, _ = _drive(ON)
    d2, _, _ = _drive(ON)
    assert [(r["four"], r["why"]) for r in d1] == [(r["four"], r["why"]) for r in d2], \
        "开态也必须逐局确定(补算/回测自还原的前提)"


@pytest.mark.parametrize("style", ["budget", "norm_cold", "matched", "ceiling_adaptive"])
def test_non_showcase_styles_untouched(style):
    """新刻度全拨极端,非 showcase 风格必须与关态逐局全同。"""
    wild = {"showcase_rotate": 1, "sc_eta_cold": -3.0, "sc_eta_hot": 0.0,
            "sc_floor_cold": 0.2, "sc_floor_hot": 0.25, "sc_lambda": 3.5,
            "sc_debt_cap": 12.0, "sc_repeat_cap": 1, "sc_beta_off": 1}
    a, _, _ = _drive({"explore_style": style, "showcase_rotate": 0}, n_rounds=120)
    b, _, _ = _drive({"explore_style": style, **wild}, n_rounds=120)
    assert [r["four"] for r in a] == [r["four"] for r in b], \
        f"{style} 风格不得受 showcase 轮换刻度影响"


# ── ③ 连推硬帽是硬不变量 ─────────────────────────────────────────────────────
@pytest.mark.parametrize("cap", [2, 3, 5])
def test_repeat_cap_is_a_hard_invariant(cap):
    """硬不变量:同四码集合连推局数恒 <= sc_repeat_cap。
    (第 cap+1 次复现时 rep 达阈值 → 当场换血,故可见连推段最长恰为 cap。)"""
    recs, _, _ = _drive({**ON, "sc_repeat_cap": cap}, n_rounds=300)
    run = _maxrun(recs)
    assert run <= cap, f"同四码集合连推 {run} 局 > 硬帽 {cap}"


def test_repeat_cap_actually_fires_and_is_labelled():
    """把份额轮换关掉(λ=0)→ 集合选择退回 argmax、黏性与原版同级,硬帽必被触发;
    触发局必须落款「硬帽」以便逐局审计,且硬不变量仍成立。"""
    recs, _, _ = _drive({**ON, "sc_lambda": 0.0, "sc_repeat_cap": 2}, n_rounds=300)
    fired = [r for r in recs if "硬帽" in r["why"]]
    assert fired, "λ=0 下 300 局竟无一次硬帽触发 —— 机制未接上"
    assert _maxrun(recs) <= 2
    assert all("撤下" in r["why"] and "换入" in r["why"] for r in fired), \
        "硬帽落款必须写清撤下/换入哪一号"


def test_repeat_cap_off_means_no_cap():
    """cap=0 时不得有硬帽落款(确认该机制确实由 cap 控制,而非别处副作用)。"""
    recs, _, _ = _drive({**ON, "sc_repeat_cap": 0}, n_rounds=200)
    assert not any("硬帽" in r["why"] for r in recs)


# ── ④ 份额收敛:每个冷号都必须拿到份额,且集中度显著下降 ──────────────────────
def test_share_convergence_breaks_cold_monopoly():
    off, _, _ = _drive({"showcase_rotate": 0}, n_rounds=400)
    on, _, _ = _drive(ON, n_rounds=400)
    h_off, sel_off, tot_off = _hhi(off)
    h_on, sel_on, tot_on = _hhi(on)
    assert h_on < h_off - 0.08, (
        f"冷位集中度未显著下降: 关={h_off:.3f} 开={h_on:.3f} "
        f"关分布={dict(sel_off)} 开分布={dict(sel_on)}")
    assert h_on <= 0.30, f"冷位赫芬达尔指数 {h_on:.3f} 仍偏高(均分=0.20)"
    for c in COLD5:
        share = sel_on.get(c, 0) / max(1, tot_on)
        assert share >= 0.05, (
            f"号{c} 只拿到 {share*100:.1f}% 冷位份额 —— 份额下限失效。"
            f"开态分布={dict(sel_on)}")
    # 单号连续在四码里的最长段必须被打断
    def streak(recs, c):
        b = cur = 0
        for r in recs:
            cur = cur + 1 if c in r["four"] else 0
            b = max(b, cur)
        return b
    assert max(streak(on, c) for c in COLD5) < max(streak(off, c) for c in COLD5), \
        "开态的冷号最长连续在册段未短于关态"


def test_eta_monotonically_controls_concentration():
    """eta 是集中度旋钮:eta 越大越向高概率冷号集中,越小越均匀。"""
    hi, _, _ = _drive({**ON, "sc_eta_cold": 8.0}, n_rounds=260)
    lo, _, _ = _drive({**ON, "sc_eta_cold": 0.0}, n_rounds=260)
    assert _hhi(lo)[0] < _hhi(hi)[0], (
        f"eta 越小冷位应越均匀: eta=8 HHI={_hhi(hi)[0]:.3f} "
        f"eta=0 HHI={_hhi(lo)[0]:.3f}")


def test_deficit_ledger_is_bounded_anti_windup():
    """抗积分饱和:目标份额不可满足时(热池 eta 很大 ⇒ 号1 每局应得 ~2.5 槽却最多
    只能占 1 槽),赤字会线性发散。真机 1,700 局实测未钳位时号1 累计 +2453、
    号2/7/8 −400~−976 —— 后果是状态无界增长,且改 sc_eta_hot 后要上千局才生效。
    账本必须恒被钳在 ±sc_debt_cap。"""
    cap = 4.0
    recs, kv, _ = _drive({**ON, "sc_debt_cap": cap, "sc_eta_hot": 20.0}, n_rounds=400)
    for r in recs:
        dbt = (r["st"].get("dbt") or {})
        for c, v in dbt.items():
            assert abs(float(v)) <= cap + 1e-6, \
                f"赤字账本越界:号{c} = {v}(上限 ±{cap})—— 积分饱和未被钳住"
    # cap 变小时账本随之变紧(确认钳位真的走的是 sc_debt_cap)
    r2, _, _ = _drive({**ON, "sc_debt_cap": 1.5, "sc_eta_hot": 20.0}, n_rounds=200)
    mx = max(abs(float(v)) for r in r2 for v in (r["st"].get("dbt") or {}).values())
    assert mx <= 1.5 + 1e-6, f"sc_debt_cap=1.5 时仍出现 |dbt|={mx}"


def test_extreme_dials_do_not_crash_predict():
    """config.yaml 是手改文件、不过注册表 ge/le —— 越界刻度不得把 predict()
    打成 OverflowError(exp 已额外钳到 ±60)。"""
    for wild in ({"sc_lambda": 1e4}, {"sc_debt_cap": 1e6}, {"sc_lambda": 1e4,
                 "sc_debt_cap": 1e6}, {"sc_eta_cold": 300.0}, {"sc_eta_cold": -300.0}):
        recs, _, _ = _drive({**ON, **wild}, n_rounds=40)
        assert all(len(set(r["four"])) == 4 for r in recs), f"越界刻度 {wild} 产出异常四码"


# ── ⑤ 状态往返 + 向后兼容 ────────────────────────────────────────────────────
def test_state_roundtrip_and_backward_compat():
    recs, kv, bridge = _drive(ON, n_rounds=120)
    st = json.loads(kv["explore_state"])
    assert "dbt" in st and "rep" in st, "赤字账本/连推计数未落进 explore_state"
    assert isinstance(st["rep"], int)
    assert all(isinstance(v, (int, float)) for v in st["dbt"].values())
    # 往返:用该状态再跑一局,必须能读回并继续(不抛、不清零)
    seq = _seq(700)[:640]
    res, dirty = bridge.run_prediction("t", seq, kv)
    st2 = json.loads(dirty["explore_state"])
    assert "dbt" in st2 and "rep" in st2
    # 向后兼容:剔掉新字段的旧状态必须直接可用
    old = {k: v for k, v in st.items() if k not in ("dbt", "rep")}
    kv_old = dict(kv, explore_state=json.dumps(old))
    res2, dirty2 = bridge.run_prediction("t", seq, kv_old)
    assert len(set(res2["main"] + res2["guard"])) == 4
    assert json.loads(dirty2["explore_state"])["rep"] == 0


# ── ⑥ 指纹深度:末 3 局同号不再整局复用 ──────────────────────────────────────
def test_fingerprint_depth_kills_the_collision():
    """构造「窗口长度不变 + 末 3 局同号」的相邻两局:
    原版深度(3)会把第二局的输出整局复用上一局(且跳过 miss4/赤字推进);
    深度 12 后两局各自独立推进。"""
    warm = _seq(600)
    base = warm[:-4] + [7, 7, 7, 7]            # 末四局同号 → 相邻两窗末三局皆 (7,7,7)
    a = base[:-1]                               # 窗 A:...7,7,7
    b = base[1:]                                # 窗 B:长度相同,末三局仍 7,7,7

    def _two(depth):
        br = PredictorBridge({**BASE_CFG, **ON, "sc_fp_depth": depth}, {})
        kv = {}
        r1, d1 = br.run_prediction("t", a, kv); kv.update(d1)
        m1 = json.loads(kv["explore_state"])["miss4"]
        r2, d2 = br.run_prediction("t", b, kv); kv.update(d2)
        m2 = json.loads(kv["explore_state"])["miss4"]
        return (tuple(r1["main"]) + tuple(r1["guard"]),
                tuple(r2["main"]) + tuple(r2["guard"]), m1, m2)

    f1_3, f2_3, m1_3, m2_3 = _two(3)
    f1_d, f2_d, m1_d, m2_d = _two(12)
    assert f1_3 == f1_d, "首局不应受指纹深度影响"
    assert m1_3 == m2_3, "原版深度下第二局应命中指纹复用 → 状态不推进"
    assert m1_d != m2_d, "深度 12 下第二局必须独立推进状态(碰撞已消除)"


# ── ⑦ 去硬编码后的守卫:冷池成员 ⇄ custom_beast_ids 倍率排序 ──────────────────
def test_cold_pool_matches_multiplier_ranking():
    """showcase_cold_ids 必须等于本部署 custom_beast_ids 下**倍率最高的 5 只**妖兽的
    编号。原引擎把 (3,4,5,6,9) 硬编码在 showcase/matched/熔断三处,与可配置的编号
    映射脱钩 —— 改映射而不改这里,整套冷热判定会静默错位。此钉把两者绑死。"""
    raw = yaml.safe_load(open(ROOT / "backend_async" / "config.yaml", encoding="utf-8"))
    ids = dict(raw["custom_beast_ids"])
    mult = {b[1]: b[3] for b in E.BEASTS_BASE}
    ranked = sorted(ids, key=lambda n: (-mult[n], ids[n]))
    expect = tuple(sorted(ids[n] for n in ranked[:5]))
    got, hot = E.Predictor._pools(raw["prediction"]["showcase_cold_ids"])
    assert got == expect, (f"冷池 {got} 与倍率排序推导 {expect} 不一致 —— "
                           f"custom_beast_ids 改过却没同步 showcase_cold_ids")
    assert tuple(sorted(got + hot)) == tuple(range(1, 10)), "冷热池未覆盖 1~9 且不重叠"


@pytest.mark.parametrize("raw,expect", [
    ("3,4,5,6,9", (3, 4, 5, 6, 9)), (" 9 , 3 ,4, 5,6 ", (3, 4, 5, 6, 9)),
    ("1,2,3,4,5", (1, 2, 3, 4, 5)), ("3,4,5,6", (3, 4, 5, 6, 9)),
    ("3,4,5,6,9,1", (3, 4, 5, 6, 9)), ("3,4,5,6,99", (3, 4, 5, 6, 9)),
    ("x,y", (3, 4, 5, 6, 9)), ("", (3, 4, 5, 6, 9)), (None, (3, 4, 5, 6, 9)),
])
def test_pool_parser_is_total(raw, expect):
    """解析器必须是全函数:任何输入都给出合法冷热池,绝不抛异常。"""
    cold, hot = E.Predictor._pools(raw)
    assert cold == expect
    assert tuple(sorted(cold + hot)) == tuple(range(1, 10))


def test_custom_pool_actually_takes_effect():
    """改冷池配置必须真的改变输出(证明三处硬编码确已解除)。"""
    a, _, _ = _drive(ON, n_rounds=120)
    b, _, _ = _drive({**ON, "showcase_cold_ids": "1,2,3,4,5"}, n_rounds=120)
    assert [r["four"] for r in a] != [r["four"] for r in b], "换冷池配置竟不改变输出"


def test_target_share_floor_gives_every_cold_number_a_slot():
    """下限顶到 1/5 时,冷池五号必须都拿到份额(份额构造的数值性质)。"""
    recs, _, _ = _drive({**ON, "sc_eta_cold": 4.0, "sc_floor_cold": 0.2}, n_rounds=200)
    sel = Counter()
    for r in recs:
        for c in r["four"]:
            if c in COLD5:
                sel[c] += 1
    for c in COLD5:
        assert sel.get(c, 0) > 0, f"floor=1/5 下号{c} 仍零份额;分布={dict(sel)}"
