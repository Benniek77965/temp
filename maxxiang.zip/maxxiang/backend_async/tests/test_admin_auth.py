"""
test_admin_auth.py — 管理台鉴权单元测试(纯标准库路径,零外部依赖)
================================================================================
覆盖:pbkdf2 散列往返、明文/散列两种口令模式、HMAC 会话签发/验签/篡改/过期、
多进程一致的密钥派生、IP 白名单 CIDR 匹配、安全默认关。
"""
from __future__ import annotations

import base64
import json
import time

import pytest

from app import admin_auth as aa


@pytest.fixture(autouse=True)
def _clean(monkeypatch):
    for k in ("STA_ADMIN_PASSWORD", "STA_ADMIN_PASSWORD_HASH",
              "STA_ADMIN_SECRET", "STA_ADMIN_IP_ALLOW",
              "STA_ADMIN_SESSION_TTL_S"):
        monkeypatch.delenv(k, raising=False)
    aa._reset_for_tests()
    yield
    aa._reset_for_tests()


def test_disabled_by_default():
    assert not aa.enabled()
    assert not aa.verify_password("anything")


def test_plain_password_mode(monkeypatch):
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "s3cret")
    aa._reset_for_tests()
    assert aa.enabled()
    assert aa.verify_password("s3cret") and not aa.verify_password("nope")


def test_hash_password_roundtrip(monkeypatch):
    h = aa.hash_password("枢-pass-123", iterations=1000)
    assert h.startswith("pbkdf2_sha256$1000$")
    monkeypatch.setenv("STA_ADMIN_PASSWORD_HASH", h)
    aa._reset_for_tests()
    assert aa.verify_password("枢-pass-123")
    assert not aa.verify_password("枢-pass-124")
    assert not aa.verify_password("")


def test_session_sign_verify_and_tamper(monkeypatch):
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "pw")
    aa._reset_for_tests()
    tok, csrf = aa.issue_session()
    payload = aa.parse_session(tok)
    assert payload and payload["csrf"] == csrf and payload["sub"] == "admin"
    # cookie 值不含 '='(无 padding),不会被加双引号
    assert "=" not in tok
    # 篡改 payload(把 exp 拉长)必须验签失败
    p64, sig = tok.split(".", 1)
    body = json.loads(aa._b64url_decode(p64))
    body["exp"] += 999999
    forged = aa._b64url_encode(
        json.dumps(body, separators=(",", ":")).encode())
    assert aa.parse_session(f"{forged}.{sig}") is None
    assert aa.parse_session("garbage") is None
    assert aa.parse_session("") is None
    # 防御性容错:包裹引号 / 末尾多余 padding 不影响验签
    assert aa.parse_session('"' + tok + '"') is not None
    assert aa.parse_session(tok.split(".")[0] + "==." + tok.split(".")[1]) is not None


def test_session_expiry(monkeypatch):
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "pw")
    aa._reset_for_tests()
    tok, _ = aa.issue_session(ttl_s=-1)
    assert aa.parse_session(tok) is None


def test_secret_derivation_stable_across_processes(monkeypatch):
    """多 uvicorn worker 语义:同口令材料 → 派生密钥一致,会话跨进程有效。"""
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "pw-material")
    aa._reset_for_tests()
    tok, _ = aa.issue_session()
    aa._reset_for_tests()                     # 模拟另一个进程重新派生
    assert aa.parse_session(tok) is not None
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "another")
    aa._reset_for_tests()
    assert aa.parse_session(tok) is None      # 口令换 → 旧会话失效


def test_ip_allowlist(monkeypatch):
    assert aa.ip_allowed("203.0.113.9")       # 未配置 = 放行
    monkeypatch.setenv("STA_ADMIN_IP_ALLOW", "10.0.0.0/8, 127.0.0.1/32")
    assert aa.ip_allowed("10.3.4.5") and aa.ip_allowed("127.0.0.1")
    assert not aa.ip_allowed("192.168.1.1")
    assert not aa.ip_allowed("not-an-ip")


# ── 会话有效期:默认 30 天 + 环境变量覆盖(惰性求值,导入后注入也生效)──────────
def test_session_ttl_defaults_to_30_days():
    assert aa.session_ttl_s() == 30 * 24 * 3600


def test_issued_session_expires_in_30_days(monkeypatch):
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "pw")
    aa._reset_for_tests()
    tok, _ = aa.issue_session()
    payload = aa.parse_session(tok)
    assert payload is not None
    left = payload["exp"] - time.time()
    assert 30 * 86400 - 5 <= left <= 30 * 86400 + 5


def test_session_ttl_env_override_after_import(monkeypatch):
    """惰性求值的意义:模块早就 import 完了,此刻注入环境变量仍必须生效。
    (写成模块级常量 SESSION_TTL_S = ... 时本用例会失败。)"""
    monkeypatch.setenv("STA_ADMIN_SESSION_TTL_S", "3600")
    aa._reset_for_tests()
    assert aa.session_ttl_s() == 3600
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "pw")
    aa._reset_for_tests()
    tok, _ = aa.issue_session()
    assert abs(aa.parse_session(tok)["exp"] - time.time() - 3600) <= 5


@pytest.mark.parametrize("raw", ["0", "-1", "abc", "", "  "])
def test_session_ttl_bad_env_falls_back_to_default(monkeypatch, raw):
    monkeypatch.setenv("STA_ADMIN_SESSION_TTL_S", raw)
    aa._reset_for_tests()
    assert aa.session_ttl_s() == 30 * 24 * 3600


def test_session_ttl_cached_within_process(monkeypatch):
    monkeypatch.setenv("STA_ADMIN_SESSION_TTL_S", "3600")
    aa._reset_for_tests()
    assert aa.session_ttl_s() == 3600
    monkeypatch.setenv("STA_ADMIN_SESSION_TTL_S", "7200")   # 不 reset → 仍读缓存
    assert aa.session_ttl_s() == 3600


def test_explicit_ttl_still_wins(monkeypatch):
    """issue_session(ttl_s=...) 显式传参必须压过环境变量与默认值(既有用例依赖 -1)。"""
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "pw")
    monkeypatch.setenv("STA_ADMIN_SESSION_TTL_S", "3600")
    aa._reset_for_tests()
    tok, _ = aa.issue_session(ttl_s=-1)
    assert aa.parse_session(tok) is None                    # 已过期
