"""
test_room_scope_labels.py — 房间归属标注(4.8.0)

背景(随包真实数据实证)
------------------------
出怪按 `(room_id, round_id)` 主键逐房入库,各房出怪彼此独立 —— jiufa_data 随包
3 房 7 天 36,278 局实测:跨房同刻同号位 13.8%,与「各房独立」的理论基准
Σp²=13.5% 一致(而非「全站统一」的 100%)。误站到别的房时,连看 1 局就有 86.2%
概率对不上,3 局内 99.7%。

而 4.7.7 之前,房号在界面上**只出现一处**:顶栏 11.5px 灰字 `№321`。全屏序列会把
顶栏整个盖掉、标签页标题不带房号、游戏坞在「真实×官方」象限把同步条整条清空 ——
于是在别的直播间看盘的用户面对的是一份没有署名的序列,自然当成全站统一的出怪,
一对不上就判定成数据错误。

本钉锁住 4.8.0 的修法:凡能看到出怪的地方都带房间归属,且**不得**用新增角标去实现。

为什么「不得新增角标」要写成钉子
--------------------------------
驾驶舱下 `.panel-head` 是 `position:absolute` 浮在内容之上、`h2/.panel-sub` 恒
`display:none`(app.css)。往里塞角标 = 复刻 4.3.3 修过整整一轮的缺陷(vip-note
压住战况/出怪规律表头),还要连带改 computeLayout 的 NOTE_H 预算。故归属一律写进
**既有文本节点**,零新增 DOM。

顶栏同理:`body[data-layout="cockpit"] .topbar{height:52px}` 是定高,且
`L.mainH = h - 52 - …` 把 52 硬编码进主区高度算式 —— 房号提级只许改字重与颜色,
一旦加上内距/边框/字号就会把顶栏顶溢出去盖住 .deck(4.3.7 已就用户名折行踩过)。
"""
from __future__ import annotations

import re
from pathlib import Path

from tests._srcscan import css_code, js_code

ROOT = Path(__file__).resolve().parents[2]
INDEX = ROOT / "index.html"
APP_JS = ROOT / "assets" / "app.js"
APP_CSS = ROOT / "assets" / "app.css"


def _idx() -> str:
    return INDEX.read_text(encoding="utf-8")


def _seg(src: str, start: str, end: str) -> str:
    i = src.index(start)
    j = src.index(end, i + len(start))
    return src[i:j]


def test_scope_anchors_exist_in_html():
    """三个归属标注位必须在 index.html 里,且是既有文本节点而非新增角标。"""
    idx = _idx()
    for el in ('id="roadSub"', 'id="trendSub"', 'id="wideTitle"'):
        assert el in idx, f"缺少归属标注位 {el}"
    # 4.2.0 的三枚 VIP 角标数目不得被本轮改动波及(test_jfvip_contract 同钉)
    assert idx.count('<button type="button" class="vip-note"') == 3
    # 归属不得走「再加一枚面板角标」的老路
    assert "room-note" not in idx, "归属改用了新增角标 —— 见本文件 docstring 的驾驶舱几何约束"


def test_front_cache_version_bumped():
    """前端有实质改动 ⇒ 必须 bump ?v=,否则带缓存/经 CDN 的老客户端跑旧包。"""
    vs = set(re.findall(r"app\.(?:js|css)\?v=([0-9.]+)", _idx()))
    assert len(vs) == 1, f"js/css 版本不一致:{vs}"
    assert tuple(int(x) for x in vs.pop().split(".")) >= (4, 8, 0)


def test_room_scope_is_written_by_one_place():
    """归属只有一处真源(syncRoomScope),并由 renderIdentity 驱动。"""
    js = js_code(APP_JS)
    assert "function syncRoomScope()" in js and "function roomTag()" in js
    ident = _seg(js, "function renderIdentity()", "\nfunction ")
    assert "syncRoomScope()" in ident, "renderIdentity 未驱动归属刷新 —— 切房不会更新"
    scope = _seg(js, "function syncRoomScope()", "\n}\n")
    for ref in ("D.roadSub", "D.trendSub", "D.wideTitle", "D.anchorAlias"):
        assert ref in scope, f"syncRoomScope 漏了 {ref}"
    for el in ("'roadSub'", "'trendSub'", "'wideTitle'"):
        assert el in js, f"cacheDom 未登记 {el}"


def test_census_and_title_carry_room():
    """出怪规律副题每次整条覆写、标签页标题每秒重算 —— 两处只能就地带房号。"""
    js = js_code(APP_JS)
    census = _seg(js, "function renderCensus()", "\n  if (!st.total)")
    assert "roomTag()" in census, "出怪规律副题未带房号"
    title = _seg(js, "const title = `${secs}s", "document.title = title")
    assert "roomTag()" in title, "标签页标题未带房号(多标签盯不同房时无从区分)"


def test_game_dock_shows_room_in_every_quadrant():
    """真实游戏施法走官方 preOrder(带 roomId + toUid=主播)—— 扣的是真星币、
    打赏的是那个房的主播。房号是扣款前唯一常驻的归属凭证,四象限一个都不能缺。
    4.7.7 的「真实×官方」分支把同步条整条清空,恰恰清掉了最该有房号的那一格。"""
    js = js_code(APP_JS)
    sync = _seg(js, "function renderJiufaSync(", "\n}\n")
    assert "js-room" in sync, "同步条未显示房号"
    assert "D.jiufaSync.innerHTML = '';" not in sync, \
        "真实×官方象限仍在清空整条同步条 —— 真金支付前失去房间归属"
    assert "`${S.alias}|" in sync, "重绘键未含房号 —— 切房后同步条不会刷新"
    assert ".jiufa-sync .js-room" in css_code(APP_CSS), "房号无样式"


def test_room_intro_is_once_per_user_and_not_contended():
    """一次性说明:按用户记忆、永不复弹;且与 4.3.3 的 basic 档说明互斥
    (toast 是单管线,后到者覆盖先到者 —— 同时弹等于其中一条从未存在)。"""
    js = js_code(APP_JS)
    assert "get roomIntro()" in js, "缺一次性标记键"
    assert "S._bootToast = true" in js, "缺与 jfIntro 的互斥占位"
    seg = _seg(js, "if (!store.get(KEY.roomIntro)", "loadRoom(alias")
    assert "!S._bootToast" in seg, "未做互斥判定"
    assert "各直播间各出各的怪" in seg, "说明未点破房间独立这一核心口径"


def test_topbar_room_number_does_not_grow_the_bar():
    """顶栏房号提级只许动字重与颜色。驾驶舱 .topbar 定高 52px,且
    computeLayout 的 `L.mainH = h - 52 - …` 硬编码了这个 52。"""
    css = css_code(APP_CSS)
    rule = _seg(css, ".anchor-meta em{", "}")
    assert "font-weight:700" in rule and "var(--brand)" in rule, "房号未提级"
    assert "font-size:11.5px" in rule, "改了字号 —— 会改变行盒高度"
    for banned in ("padding", "border", "line-height"):
        assert banned not in rule, f"房号规则引入了 {banned},可能把定高顶栏撑溢出"
    assert "L.mainH  = h - 52" in js_code(APP_JS), "mainH 的 52 硬编码前提已变,请复核本钉"
