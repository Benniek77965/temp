"""
test_coverage_sentinel.py — 覆盖哨兵(缺口驱动补漏校验;无开关恒开)的语义级回归
================================================================================
固化仿真台(scripts/sim_history_gap)验证过的十一条契约(3.4.8 增四例守卫:
⑨-b 播种 DB 兜底的失败回退、⑨-c 重生停机空洞全愈合(含停机 0 局的静默区
最坏情形)、janitor 补排窗公式,共十五例):
  ① 数据完整 → GameHistory **零调用**(仅播种一次),且哨兵走纯 Redis 快路径
     —— 除 award 幂等检查外零 DB 触达;
  ② award 任务丢失(MainPage 步进恒 1、漏局分支不触发的盲区)→ 哨兵 ≤2 局内
     检出并一次 GameHistory 补齐;
  ③ 官方本身缺失的局:确证一次登记 offmiss 后,同一格点**绝不复打**;
  ④ 冷却闸(hist_gate)对并发触发去重;
  ⑤ 旧「每 N 局盲扫」旋钮与分支已彻底移除,哨兵为唯一且恒开的补漏校验;
  ⑥ 哨兵永不抛错(DB 异常静默,由下一事件重审);
  ⑦ 停机深洞已出官方历史页窗(近 30 局)→ 免打上游、分窗直接确证登记,
     零无效请求(删房重加/长期下播复播同走此路);
  ⑧ GameHistory 失败不构成「官方缺失」证据 —— 恢复瞬间连败也绝不误登记,
     页窗内停机局由重试链全部补回(S9 缺陷修复的钉子);
  ⑨ Redis 全量掉电重挂(DB 幸存=重生):**免重播种**(3.4.8 播种 DB 兜底 ——
     库最老一局存在即置位 seeded,万房重启省 1 万次上游调用与 INSERT 空转;
     兜底探测异常时退回播种,行为保守收敛)、水位重建、义务窗完整、页窗内
     官方缺点与停机漏局由哨兵重生审计一次确证/补齐(登记闭环不因掉电而破,
     且免播种分支不占 hist_gate,闸留给哨兵当场定案)、无风暴;
  ⑩ 上游 MainPage 断供:失败重试指数退避 30s 封顶(3 分钟断供 ≤10 次调用,
     不锤击上游不烧令牌),成功即复位、恢复后无残留退避;
  ⑪ 稳态每事件 Redis 命令数 ≤16(实测 ≈12.0)—— 最低资源占用的量化底线。
真机性:与仿真台同一套真实 Worker + fakeredis 真实调度,零网络零 PG。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

pytest.importorskip("fakeredis")

from app import redis_bus as rb  # noqa: E402
from app import worker as wk  # noqa: E402
from app.constants import ROUND_STEP  # noqa: E402
from scripts.sim_history_gap import (AWARD_READY_OFFSET, ROOM,  # noqa: E402
                                     build_world, make_task_loser, pump)

STEP = ROUND_STEP


async def _boot(mode: str):
    w, up, db, clock = build_world(mode)
    await w.bus.add_room(ROOM)
    await w.bus.schedule(rb.task_mainpage(ROOM), clock.t)
    return w, up, db, clock, up.cur_round()


def _count_has_round(db):
    """给 FakeDB.has_round 包一层调用计数(区分哨兵是否额外触 DB)。"""
    orig, box = db.has_round, {"n": 0}

    async def counted(room, rid):
        box["n"] += 1
        return await orig(room, rid)

    db.has_round = counted
    return box


@pytest.mark.asyncio
async def test_complete_data_zero_history_and_zero_extra_db():
    """契约①:30 局顺序出怪 —— GameHistory 仅播种 1 次;哨兵稳态纯 Redis,
    has_round 调用数恰等于 award 幂等检查数(哨兵 0 额外 DB)。"""
    w, up, db, clock, start = await _boot("gap_only")
    box = _count_has_round(db)
    await pump(w, clock, start + 30 * STEP + 45_000)
    assert up.calls["hist"] == 1                       # 仅播种
    aw_inserted = sum(1 for r in db.rounds if r >= start)
    assert aw_inserted >= 29
    # 每局 award 入口一次幂等 has_round;哨兵稳态走纯 Redis 快路径。一次性
    # 成本仅在水位起步那一拍:重生判据(oldest_round)一次 + 初始化回看审计
    # 逐格 has_round(≤ min(页窗, 房龄) 次;本例=播种页格数 + 暖机 1 格)。
    # 30 局总量 ≤ award 数 + 页窗 + 2 —— 上界与局数无关(跑 50 局仍同一
    # 常数),证明非逐局触 DB;此一次性代价换得 Redis 掉电后登记闭环不破
    # (契约⑨,fuzz 种子 1005/1010 双实证)。
    assert box["n"] <= up.calls["aw"] + wk.COV_HIST_PAGE_ROUNDS + 2
    snap = await w.bus.get_snapshot(ROOM)
    assert int(snap["covWm"]) >= start + 27 * STEP     # 水位贴住最新局(滞后≤2)


@pytest.mark.asyncio
async def test_lost_award_task_detected_and_healed():
    """契约②:aw 任务被无声蒸发(Redis 掉数据窗口)→ 哨兵 ≤2 局检出,
    一次 GameHistory 补齐,offmiss 不误登记。"""
    w, up, db, clock, start = await _boot("gap_only")
    hole = start + 8 * STEP
    await pump(w, clock, start + 25 * STEP + 45_000,
               injectors=[make_task_loser({hole})])
    assert hole in db.rounds                           # 已补回
    assert db.rounds[hole]["source"] == "history"
    heal = db.first_insert_at[hole] - (hole + AWARD_READY_OFFSET)
    assert heal <= int(2.5 * STEP)                     # ≤2.5 局内自愈
    assert up.calls["hist"] == 2                       # 播种 + 精准补漏各一次
    assert await w.bus.r.zcard(rb.K_OFF_MISSING.format(room=ROOM)) == 0


@pytest.mark.asyncio
async def test_official_missing_certified_once_never_reprobed():
    """契约③:官方缺失局确证一次(award 兜底或哨兵)登记后,后续几十局
    GameHistory 调用数不再增长 —— 同一格点绝不复打。"""
    w, up, db, clock, start = await _boot("gap_only")
    up.official_missing.add(start + 5 * STEP)
    await pump(w, clock, start + 20 * STEP + 45_000)
    calls_mid = up.calls["hist"]
    offmiss = {int(x) for x in await w.bus.r.zrange(
        rb.K_OFF_MISSING.format(room=ROOM), 0, -1)}
    assert start + 5 * STEP in offmiss
    await pump(w, clock, start + 55 * STEP + 45_000)   # 再跑 35 局
    assert up.calls["hist"] == calls_mid               # 零新增
    snap = await w.bus.get_snapshot(ROOM)
    assert int(snap["covWm"]) >= start + 52 * STEP     # 水位越过缺口继续贴头


@pytest.mark.asyncio
async def test_hist_gate_dedups_concurrent_triggers():
    """契约④:冷却闸 SET NX PX —— 并发第二次拿闸失败;过期后放行。"""
    w, _up, _db, _clock, _start = await _boot("gap_only")
    assert await w.bus.hist_gate(ROOM, 5_000) is True
    assert await w.bus.hist_gate(ROOM, 5_000) is False
    await w.bus.r.delete(rb.K_HIST_GATE.format(room=ROOM))   # 模拟 PX 到期
    assert await w.bus.hist_gate(ROOM, 5_000) is True
    assert await w.bus.hist_gate(ROOM, 0) is True             # 0=不启用闸


def test_blind_scan_knobs_fully_removed():
    """契约⑤(改):旧「每 N 局盲扫」机制已整体移除 —— Settings/注册表不再含
    history_mode 与 history_every_rounds,worker 生产码中无 histCount 盲扫分支;
    哨兵为唯一补漏校验机制(恒开,无开关)。防止旋钮/分支被无意回加。"""
    import inspect
    from app.settings import Settings
    from app.config_registry import REGISTRY
    s = Settings()
    assert not hasattr(s.upstream, "history_mode")
    assert not hasattr(s.upstream, "history_every_rounds")
    assert "upstream.history_mode" not in REGISTRY
    assert "upstream.history_every_rounds" not in REGISTRY
    src = inspect.getsource(wk)
    assert "histCount" not in src        # 盲扫分支未回潮
    assert "_coverage_check" in src      # 哨兵在位


@pytest.mark.asyncio
async def test_page_window_skip_deep_stall_zero_futile_calls():
    """契约⑦:停机 210 局(> mp 漏局分支 200 登记护栏,迫使哨兵独立处置深洞;
    且 > 官方历史页窗 30)—— 缺口在页窗外数学上不可达:哨兵**免打上游**、
    直接分窗确证登记,全程 GameHistory 仅 播种 + mp漏局分支 = 2 次;
    洞全部登记 offmiss、水位追平(删房重加/长期下播复播同走此零调用路)。"""
    w, up, db, clock, start = await _boot("gap_only")
    await pump(w, clock, start + 10 * STEP + 45_000)   # 先正常跑 10 局
    clock.t += 210 * STEP                              # 停机:时钟走,任务不动
    await pump(w, clock, start + 240 * STEP + 45_000)  # 复播续跑
    assert up.calls["hist"] == 2                       # seed + mp漏局分支;哨兵 0 实弹
    offmiss = {int(x) for x in await w.bus.r.zrange(
        rb.K_OFF_MISSING.format(room=ROOM), 0, -1)}
    holes = {r for r in range(start, up.cur_round(), STEP)
             if r not in db.rounds and r not in up.official_missing}
    assert holes and holes <= offmiss                  # 深洞全部「确证不可再取得」
    snap = await w.bus.get_snapshot(ROOM)
    assert int(snap["covWm"]) >= up.cur_round() - 3 * STEP   # 水位追平


@pytest.mark.asyncio
async def test_backfill_failure_never_falsely_certifies():
    """契约⑧:恢复瞬间 GameHistory 连败(mp 漏局分支首拉 + 哨兵接力各败一次)
    —— 失败不构成「官方缺失」证据:绝不误登记、页窗内的停机局由后续事件
    重试链全部补回(真机仿真 S9 曾以此打出既有分支「失败仍标记」缺陷)。"""
    w, up, db, clock, start = await _boot("gap_only")
    up.hist_fail_calls = {2, 3}                        # 恢复时刻两连败
    await pump(w, clock, start + 15 * STEP + 45_000)
    clock.t += 5 * STEP                                # 停机 5 局(页窗内,必须可救)
    await pump(w, clock, start + 40 * STEP + 45_000)
    stalled = {start + k * STEP for k in range(16, 20)}
    assert stalled <= set(db.rounds)                   # 全部补回
    assert await w.bus.r.zcard(rb.K_OFF_MISSING.format(room=ROOM)) == 0  # 零误登记
    assert up.calls["hist"] == 4                       # seed+败+败+成,不风暴


@pytest.mark.asyncio
async def test_redis_wipe_rebirth_no_reseed_no_storm():
    """契约⑨:Redis 全量掉电(快照/调度/名录尽失,DB 完好)后重挂 —— **免重播种**
    (3.4.8 播种 DB 兜底:oldest_round 命中即置位 seeded,零上游调用;hist 总计
    =初播+哨兵对页窗缺口一次确证=2)、水位重建、重生页窗义务全满足、零误登记、
    无风暴。停机漏局与官方缺点同页定案:上游有的补回入库、没有的登记 offmiss。"""
    w, up, db, clock, start = await _boot("gap_only")
    up.official_missing.add(start + 21 * STEP)         # 官方缺点恰落在掉电窗内
    await pump(w, clock, start + 20 * STEP + 45_000)
    await w.bus.r.flushall()                           # 掉电
    clock.t += 2 * STEP                                # 运维重挂间隔
    await w.bus.add_room(ROOM)
    await w.bus.schedule(rb.task_mainpage(ROOM), clock.t + 500)
    oblig = up.cur_round() - 29 * STEP                 # 新义务窗 = 重生页窗
    await pump(w, clock, start + 45 * STEP + 45_000)
    assert up.calls["hist"] == 2                       # 初播+哨兵确证一次(重播已免)
    snap_seed = await w.bus.get_snapshot(ROOM)
    assert snap_seed.get("seeded") == "1"              # 兜底置位,后续事件不再探测
    last = up.cur_round() - 2 * STEP
    missing = [r for r in range(oblig, last + 1, STEP)
               if r not in db.rounds and r not in up.official_missing]
    assert not missing                                 # 义务窗内完整
    offmiss = {int(x) for x in await w.bus.r.zrange(
        rb.K_OFF_MISSING.format(room=ROOM), 0, -1)}
    # 掉电抹掉一切登记后,重生页窗内的官方缺点被回看审计重新确证
    # (fuzz 1005 缺口的钉子);且无任何误登记。
    assert offmiss == {start + 21 * STEP}
    snap = await w.bus.get_snapshot(ROOM)
    assert int(snap["covWm"]) >= up.cur_round() - 3 * STEP   # 水位重建并追平


@pytest.mark.asyncio
async def test_seed_db_probe_failure_falls_back_to_backfill():
    """契约⑨-b(3.4.8 兜底的兜底):播种 DB 探测(oldest_round)抛异常时**必须**
    退回原播种路径 —— hist 照打、seeded 照置、数据照全。行为保守收敛:PG 抖动
    绝不能让房间既不播种又标 seeded(那会把首屏序列与播种页义务一起丢掉)。"""
    w, up, db, clock, start = await _boot("gap_only")

    async def boom(_room):                             # 模拟 PG 抖动
        raise RuntimeError("pg down")

    db.oldest_round = boom
    await pump(w, clock, start + 3 * STEP + 45_000)
    assert up.calls["hist"] == 1                       # 探测失败 → 播种照打
    snap = await w.bus.get_snapshot(ROOM)
    assert snap.get("seeded") == "1"                   # 且置位,不反复重试探测
    assert any(r >= start - 5 * STEP for r in db.rounds)   # 播种页已入库


@pytest.mark.asyncio
async def test_rebirth_downtime_gap_fully_healed_no_hole():
    """契约⑨-c(3.4.8 播种免打的必要保障;生产实证重启高频):Redis 全量掉电
    + 停机期真实空洞(空洞局在上游存在、非官方缺失)+ 老房 —— 旧行为靠播种回填
    **当场**补上整段空洞,新行为播种免打、把空洞交给哨兵。本例钉死:哨兵把停机
    空洞**全部**补回(含最近一局 = 静默区 head-1 最终愈合),零永久暗区、
    空洞局绝不被误标 official_missing、恢复后 GameHistory 不风暴(播种免打 →
    恢复期 hist 全部来自哨兵补漏,数量有界)。这是"旧代码 seeding 当场补、新代码
    推迟给哨兵"这一行为差异下**数据完整性不回归**的直接证据。"""
    w, up, db, clock, start = await _boot("gap_only")
    await pump(w, clock, start + 20 * STEP + 45_000)   # 正常跑:DB 有 start..start+20
    pre = {r for r in db.rounds if r >= start}
    assert start + 18 * STEP in pre and len(pre) >= 18  # 掉电前确有连续数据
    hist_before = up.calls["hist"]                     # 含初次播种回填

    await w.bus.r.flushall()                           # 全量掉电(Redis 尽失,DB 幸存)
    clock.t += 5 * STEP                                # 停机 5 局 → 空洞 start+21..24,+25=当前
    await w.bus.add_room(ROOM)                         # 运维重挂:名录重建(等效 boot 回灌)
    await w.bus.schedule(rb.task_mainpage(ROOM), clock.t + 500)
    await pump(w, clock, clock.t + 8 * STEP + 45_000)  # 恢复后再跑 8 局

    # ① 停机空洞全部补回(含最近一局 start+24 与当前 start+25)—— 零永久暗区
    for k in range(21, 26):
        assert start + k * STEP in db.rounds, f"停机局 start+{k}*STEP 未补回(永久暗区!)"
    # ② 播种免打:恢复期 hist 调用全来自哨兵补漏,数量有界(整页 30 局一次补齐,不风暴)
    assert up.calls["hist"] - hist_before <= 3, "恢复期 GameHistory 调用超界(疑重播种风暴)"
    # ③ 空洞局在上游存在 → 绝不能被误登记为官方缺失
    off = {int(x) for x in await w.bus.r.zrange(rb.K_OFF_MISSING.format(room=ROOM), 0, -1)}
    assert not (off & {start + k * STEP for k in range(21, 26)}), "上游存在的空洞局被误标 offmiss"
    # ④ 兜底置位(免打路径确实生效,而非退回真播种)
    assert (await w.bus.get_snapshot(ROOM)).get("seeded") == "1"


@pytest.mark.asyncio
async def test_rebirth_zero_downtime_silent_zone_heals_no_hole():
    """契约⑨-c 边界(停机=0 局):Redis 掉电但**无**停机空洞(掉电瞬间无新局)——
    此时哨兵审计范围内无缺口 → 不触发整页回填,静默区最近一局(head-1,其 award
    任务已随 Redis 蒸发)得不到"整页副作用愈合"。钉死这条最不利路径:head-1 仍在
    随后 1-2 个事件内经哨兵审计愈合(head 前进即出静默区),不留永久暗区。这是
    3.4.8 文档"静默区 ≤2 局延迟"承诺的**最坏情形**实测。"""
    w, up, db, clock, start = await _boot("gap_only")
    await pump(w, clock, start + 15 * STEP + 45_000)   # 正常跑,DB 连续
    head_at_wipe = up.cur_round()
    assert head_at_wipe - STEP in db.rounds             # 掉电前 head-1 在库
    hist_before = up.calls["hist"]

    await w.bus.r.flushall()                            # 掉电,不推进时钟(停机 0 局)
    await w.bus.add_room(ROOM)
    await w.bus.schedule(rb.task_mainpage(ROOM), clock.t + 500)
    await pump(w, clock, clock.t + 6 * STEP + 45_000)   # 恢复后再跑 6 局

    # head-1(其 award 已蒸发)必须最终愈合 —— 经哨兵接力而非 award 主路
    assert head_at_wipe - STEP in db.rounds, "静默区 head-1 永久丢失!"
    assert head_at_wipe in db.rounds                    # 当前局经新 award 任务愈合
    assert up.calls["hist"] - hist_before <= 3          # 免播种,不风暴
    off = {int(x) for x in await w.bus.r.zrange(rb.K_OFF_MISSING.format(room=ROOM), 0, -1)}
    assert head_at_wipe - STEP not in off               # 存在的局绝不误标 offmiss
    assert (await w.bus.get_snapshot(ROOM)).get("seeded") == "1"


def test_janitor_spread_window_contract():
    """janitor 补排窗公式契约(3.4.8):n≤120 与旧式 `(i*25)%3000` 逐毫秒等价
    (小规模补排行为零变化);大面积丢失线性铺宽、warmup_window_ms 封顶 ——
    防未来把 min/max 改错或去掉封顶,重新引入 3s 环形风暴。"""
    warm = 60_000
    for n in (1, 3, 7, 120):                           # 常态零星补排
        span = wk.janitor_spread_window(n, warm)
        assert span == n * 25 <= 3000
        for i in range(n):                             # schedule_spread 的铺点
            old = (i * 25) % 3000                      # 旧式到期偏移
            new = i * span // n if n > 1 else 0
            assert new == old                          # 逐毫秒等价
    assert wk.janitor_spread_window(1_000, warm) == 25_000   # 线性铺宽
    assert wk.janitor_spread_window(10_000, warm) == warm    # 万房封顶=准入口径
    assert wk.janitor_spread_window(0, warm) == 0


@pytest.mark.asyncio
async def test_mainpage_outage_backoff_bounded():
    """契约⑩:上游 MainPage 断供 —— 失败重试指数退避 30s 封顶,3 分钟断供
    单房调用 ≤10(扁平 1.5s 会打 ~120 次并白烧全局令牌);恢复后无残留退避
    (后续每局恰一拍)、mpFails 复位 0、漏局分支一次补齐无洞。"""
    w, up, db, clock, start = await _boot("gap_only")
    await pump(w, clock, start + 8 * STEP + 45_000)
    mp0 = up.calls["mp"]
    up.mp_outage = (clock.t, clock.t + 180_000)        # 断供 3 分钟
    await pump(w, clock, clock.t + 180_000)
    assert up.calls["mp"] - mp0 <= 10                  # 退避有界,不锤击
    mp1 = up.calls["mp"]
    await pump(w, clock, up.cur_round() + 5 * STEP + 45_000)
    snap = await w.bus.get_snapshot(ROOM)
    assert snap.get("mpFails") in ("0", 0)             # 成功即复位
    assert up.calls["mp"] - mp1 <= 8                   # 恢复后无残留退避(~6拍)
    last = up.cur_round() - 2 * STEP
    holes = [r for r in range(start, last + 1, STEP) if r not in db.rounds]
    assert not holes and up.calls["hist"] == 2         # 恢复即一次补齐


@pytest.mark.asyncio
async def test_steady_state_redis_ops_bounded():
    """契约⑪:稳态每事件 Redis 命令数有界(实测 ≈12.0,上界 16 留抖动余量)——
    防未来改动无意引入 O(n) 或环路查询,守住「最低资源占用」的量化底线。"""
    w, up, db, clock, start = await _boot("gap_only")
    r, box = w.bus.r, {"n": 0}
    orig_exec = r.execute_command
    async def cexec(*a, **k):
        box["n"] += 1
        return await orig_exec(*a, **k)
    r.execute_command = cexec
    orig_pipe = r.pipeline
    def cpipe(*a, **k):
        p = orig_pipe(*a, **k)
        orig_pe = p.execute
        async def pe(*aa, **kk):
            box["n"] += len(p.command_stack)
            return await orig_pe(*aa, **kk)
        p.execute = pe
        return p
    r.pipeline = cpipe
    await pump(w, clock, start + 5 * STEP + 45_000)    # 暖机(播种/水位起步)
    box["n"] = 0
    mp0, aw0 = up.calls["mp"], up.calls["aw"]
    await pump(w, clock, start + 30 * STEP + 45_000)
    events = (up.calls["mp"] - mp0) + (up.calls["aw"] - aw0)
    assert events >= 40
    assert box["n"] / events <= 16.0


@pytest.mark.asyncio
async def test_sentinel_never_raises_on_db_failure():
    """契约⑥:审计中 DB 抛错 → 哨兵静默(不抛、不推水位),主链路不受扰。"""
    w, _up, db, clock, start = await _boot("gap_only")
    await pump(w, clock, start + 6 * STEP + 45_000)    # 先建立水位
    snap0 = await w.bus.get_snapshot(ROOM)
    wm0 = snap0.get("covWm")

    async def boom(_room, _rid):
        raise RuntimeError("pg down")

    db.has_round = boom
    # 直接驱动一次慢路径(head 前跳 3 局强制审计);不得抛出
    await w._coverage_check(ROOM, int(snap0["roundStartTimeMs"]) + 3 * STEP)
    snap1 = await w.bus.get_snapshot(ROOM)
    assert snap1.get("covWm") == wm0                   # 水位原地不动,等下一事件
