"""
test_jfvip_db.py — 九法VIP 真库联测(4.2.0)
================================================================================
**为什么必须有这一份**:钱路径(`_grant_tx` 与那 4 张表的 DDL)在前三轮里
从头到尾**没在真库上跑过一次**。纯静态断言证明不了:
  · DDL 能不能被 MySQL/MariaDB 真正执行(gbk 表 + DECIMAL + 复合索引);
  · `GREATEST(NOW(), …) + INTERVAL n HOUR` 的续期口径是否真如预期;
  · `FOR UPDATE` + `ON DUPLICATE KEY UPDATE` 在**并发**下是否真的恰一次入账;
  · gbk_bin 列上的**中文用户名**能否走通(项目反复强调这条,却从未在本链路验过)。

沿用本仓库既有范式:本地 1:1 复刻库不可达时**整层 skip**,不阻断主干。
起一个可用实例(任选其一):
    docker run -d --name jftest -p 3307:3306 -e MARIADB_ALLOW_EMPTY_ROOT_PASSWORD=1 mariadb:10.11
    # 或裸机:mariadbd --datadir=/tmp/mydb --port=3307 --socket=/tmp/my.sock
库名/账号可用 STA_TEST_* 覆盖(见下)。测试自建 schema、自清数据,不碰任何既有库。
"""
from __future__ import annotations

import asyncio
import datetime
import os
import socket

import pytest

from app import jfvip, userauth
from app.settings import UserAuthCfg

_HOST = os.environ.get("STA_TEST_USERDB_HOST", "127.0.0.1")
_PORT = int(os.environ.get("STA_TEST_USERDB_PORT", "3307"))
_USER = os.environ.get("STA_TEST_USERDB_USER", "root")
_PASS = os.environ.get("STA_TEST_USERDB_PASSWORD", "")
_DB = os.environ.get("STA_TEST_USERDB_NAME", "fx_jfvip_test")


def _reachable() -> bool:
    try:
        with socket.create_connection((_HOST, _PORT), timeout=0.6):
            return True
    except OSError:
        return False


needs_db = pytest.mark.skipif(
    not _reachable(),
    reason=f"需要本地用户库 {_HOST}:{_PORT}(MariaDB/MySQL 1:1 复刻)")

# 1:1 复刻线上 tb_user 的关键形态:user_name 列 gbk_bin(大小写敏感 + 中文)
_BASE_DDL = [
    f"CREATE DATABASE IF NOT EXISTS `{_DB}` DEFAULT CHARSET=gbk",
    """CREATE TABLE IF NOT EXISTS tb_user (
         id BIGINT NOT NULL AUTO_INCREMENT,
         user_name VARCHAR(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL,
         pass_word VARCHAR(50) NOT NULL,
         email_account VARCHAR(320) NOT NULL DEFAULT '',
         email_bind_time BIGINT NOT NULL DEFAULT 0,
         register_time DATETIME NOT NULL,
         due_time DATETIME NOT NULL,
         is_off VARCHAR(1) NOT NULL DEFAULT '0',
         PRIMARY KEY(id), UNIQUE KEY uk_name (user_name)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk""",
]


def _cfg() -> UserAuthCfg:
    return UserAuthCfg(host=_HOST, port=_PORT, db=_DB, user=_USER, password=_PASS,
                       charset="gbk", jf_vip_enabled=True, cache_ttl_s=0.0)


async def _prepare():
    """建库建表(含被测的 4 张 guantai_jf_*,直接取自 userauth._SCHEMA —— 单一真源:
    测试跑的就是生产会跑的那份 DDL,不存在手抄漂移)。"""
    import aiomysql
    conn = await aiomysql.connect(host=_HOST, port=_PORT, user=_USER,
                                  password=_PASS, charset="gbk", autocommit=True)
    async with conn.cursor() as cur:
        await cur.execute(_BASE_DDL[0])
        await cur.execute(f"USE `{_DB}`")
        await cur.execute(_BASE_DDL[1])
    conn.close()
    userauth.UA.cfg = _cfg()
    userauth.UA.pool = None
    userauth.UA.schema_ok = False
    userauth.UA.schema_lock = asyncio.Lock()
    assert await userauth._ensure_schema(), "guantai_* 建表失败(DDL 无法执行)"


async def _mk_user(name: str, days_from_now: int) -> int:
    """造一个用户。days_from_now<0 = 小叮当已过期。"""
    await userauth._q("DELETE FROM guantai_jf_vip WHERE user_id IN "
                      f"(SELECT id FROM `{userauth.UA.cfg.user_table}` WHERE user_name=%s)",
                      (name,))
    await userauth._q(f"DELETE FROM `{userauth.UA.cfg.user_table}` WHERE user_name=%s", (name,))
    await userauth._q(
        f"INSERT INTO `{userauth.UA.cfg.user_table}` "
        f"(user_name, pass_word, register_time, due_time, is_off) "
        f"VALUES (%s,'x',NOW(),DATE_ADD(NOW(), INTERVAL %s DAY),'0')",
        (name, int(days_from_now)))
    row = await userauth._q(f"SELECT id FROM `{userauth.UA.cfg.user_table}` "
                            f"WHERE user_name=%s", (name,), fetch="one")
    return int(row["id"])


async def _mk_order(no: str, uid: int, name: str, plan_code: str,
                    jf_h: int = -1, dd_h: int = -1):
    p = jfvip.plan_of(plan_code) or {"jfHours": 0, "ddHours": 0, "price": 0}
    await userauth._q("DELETE FROM guantai_jf_order WHERE gateway_order_no=%s", (no,))
    # ★ 必须连流水一起清:否则跨轮累积会把「恰一次入账」的断言误判成产品 bug
    #   (本轮实测踩过:D-C1 累了 3 条,一度以为并发失控)。
    await userauth._q("DELETE FROM guantai_jf_grant_log WHERE ref=%s", (no,))
    await userauth._q(
        "INSERT INTO guantai_jf_order (gateway_order_no,user_id,user_name,plan_code,"
        "jf_hours,dd_hours,amount,status,credited,is_simulate,create_time) "
        "VALUES (%s,%s,%s,%s,%s,%s,%s,'pending',0,0,NOW())",
        (no, uid, name, plan_code,
         p["jfHours"] if jf_h < 0 else jf_h,
         p["ddHours"] if dd_h < 0 else dd_h, p["price"]))


@needs_db
@pytest.mark.asyncio
async def test_ddl_executes_on_real_db():
    """4 张 guantai_jf_* 的 DDL 必须能被真库执行 —— 静态检查证明不了这一条。"""
    await _prepare()
    # ⚠ _q 的 args 默认是 ()(非 None),aiomysql 会执行 `query % args` ——
    #   SQL 里的裸 % 必须写成 %% 才不会被当成格式占位符。
    rows = await userauth._q("SHOW TABLES LIKE 'guantai\\_jf\\_%%'", fetch="all") or []
    have = {list(r.values())[0] for r in rows}
    assert {"guantai_jf_vip", "guantai_jf_order",
            "guantai_jf_card", "guantai_jf_grant_log"} <= have, have
    await userauth.close()


@needs_db
@pytest.mark.asyncio
async def test_expired_account_starts_from_now():
    """小叮当已过期 → 两条时间线都**从此刻起算**(不是从过去的到期点)。"""
    await _prepare()
    uid = await _mk_user("t_exp", -5)
    await _mk_order("D-A1", uid, "t_exp", "m1")
    err, _ = await jfvip.grant_by_order(uid, "t_exp", "D-A1")
    assert err == "", err
    now = datetime.datetime.now()
    due = (await userauth._q(f"SELECT due_time FROM `{userauth.UA.cfg.user_table}` "
                             f"WHERE id=%s", (uid,), fetch="one"))["due_time"]
    vip = (await userauth._q("SELECT vip_until FROM guantai_jf_vip WHERE user_id=%s",
                             (uid,), fetch="one"))["vip_until"]
    assert 30 <= (due - now).days <= 31, f"小叮当 {due}"
    assert 30 <= (vip - now).days <= 31, f"九法VIP {vip}"
    await userauth.close()


@needs_db
@pytest.mark.asyncio
async def test_unexpired_renewal_does_not_lose_time():
    """未过期续期从**原到期点**顺延 —— 续期不亏时长(与线上软件同口径)。"""
    await _prepare()
    uid = await _mk_user("t_ren", 10)
    await _mk_order("D-B1", uid, "t_ren", "d3")
    await jfvip.grant_by_order(uid, "t_ren", "D-B1")
    v1 = (await userauth._q("SELECT vip_until FROM guantai_jf_vip WHERE user_id=%s",
                            (uid,), fetch="one"))["vip_until"]
    d1 = (await userauth._q(f"SELECT due_time FROM `{userauth.UA.cfg.user_table}` "
                            f"WHERE id=%s", (uid,), fetch="one"))["due_time"]
    await _mk_order("D-B2", uid, "t_ren", "d3")
    await jfvip.grant_by_order(uid, "t_ren", "D-B2")
    v2 = (await userauth._q("SELECT vip_until FROM guantai_jf_vip WHERE user_id=%s",
                            (uid,), fetch="one"))["vip_until"]
    d2 = (await userauth._q(f"SELECT due_time FROM `{userauth.UA.cfg.user_table}` "
                            f"WHERE id=%s", (uid,), fetch="one"))["due_time"]
    assert abs((v2 - v1).total_seconds() / 3600 - 72) < 0.05, f"{v1}→{v2}"
    assert abs((d2 - d1).total_seconds() / 3600 - 72) < 0.05, f"{d1}→{d2}"
    await userauth.close()


@needs_db
@pytest.mark.asyncio
async def test_concurrent_order_settle_credits_exactly_once():
    """★ 8 路并发结算同一订单 —— 必须**恰一次**入账。
    这是整套系统最贵的一条不变量:错了就是重复发货 / 少发货。"""
    await _prepare()
    uid = await _mk_user("t_cc", 1)
    await _mk_order("D-C1", uid, "t_cc", "d3")
    res = await asyncio.gather(*[jfvip.grant_by_order(uid, "t_cc", "D-C1")
                                 for _ in range(8)], return_exceptions=True)
    assert not [r for r in res if isinstance(r, Exception)], res
    v = await userauth._q("SELECT total_hours FROM guantai_jf_vip WHERE user_id=%s",
                          (uid,), fetch="one")
    assert int(v["total_hours"]) == 72, f"累计 {v['total_hours']}h,应为 72"
    n = await userauth._q("SELECT COUNT(*) c FROM guantai_jf_grant_log WHERE ref='D-C1'",
                          fetch="one")
    assert int(n["c"]) == 1, f"流水 {n['c']} 条,应为 1"
    await userauth.close()


@needs_db
@pytest.mark.asyncio
async def test_concurrent_card_redeem_exactly_one_winner():
    """★ 6 路并发兑换同一张卡 —— 恰一名赢家,其余 card_used。"""
    await _prepare()
    uid = await _mk_user("t_card", 1)
    card = "JFZZZZZZ987654"
    await userauth._q("DELETE FROM guantai_jf_card WHERE card=%s", (card,))
    await userauth._q("DELETE FROM guantai_jf_grant_log WHERE ref=%s", (card,))
    await userauth._q("INSERT INTO guantai_jf_card (card,plan_code,batch,note,"
                      "created_by,created_at) VALUES (%s,'d3','T','','t',NOW())", (card,))
    res = await asyncio.gather(*[jfvip.grant_by_card(uid, "t_card", card)
                                 for _ in range(6)], return_exceptions=True)
    errs = [r[0] for r in res if isinstance(r, tuple)]
    assert errs.count("") == 1, f"成功 {errs.count('')} 次,应为 1:{errs}"
    assert all(e in ("", "card_used") for e in errs), errs
    v = await userauth._q("SELECT total_hours FROM guantai_jf_vip WHERE user_id=%s",
                          (uid,), fetch="one")
    assert int(v["total_hours"]) == 72
    await userauth.close()


@needs_db
@pytest.mark.asyncio
async def test_zero_hours_order_fails_closed():
    """★ 时长快照为 0 的订单必须**拒绝开通且不标 paid** ——
    否则用户付了钱什么都没得到,且因幂等哨兵永远无法重试(资损)。"""
    await _prepare()
    uid = await _mk_user("t_zero", 1)
    await _mk_order("D-Z1", uid, "t_zero", "m1", jf_h=0, dd_h=0)
    err, _ = await jfvip.grant_by_order(uid, "t_zero", "D-Z1")
    assert err == "order_hours_invalid", err
    o = await userauth._q("SELECT status,credited FROM guantai_jf_order "
                          "WHERE gateway_order_no='D-Z1'", fetch="one")
    assert o["status"] == "pending" and int(o["credited"]) == 0, dict(o)
    await userauth.close()


@needs_db
@pytest.mark.asyncio
async def test_chinese_username_through_grant_path():
    """★ gbk_bin 列上的**中文用户名**必须走通开通链路。
    项目反复强调 gbk 连接与中文用户名,但此前从未在本链路验证过 ——
    一旦编码出错,中文名用户会在付款后开通失败(最坏的失败时机)。"""
    await _prepare()
    name = "测试用户小叮当"
    uid = await _mk_user(name, -1)
    await _mk_order("D-CN1", uid, name, "d3")
    err, out = await jfvip.grant_by_order(uid, name, "D-CN1")
    assert err == "", err
    g = await userauth._q("SELECT user_name FROM guantai_jf_grant_log WHERE ref='D-CN1'",
                          fetch="one")
    assert g["user_name"] == name, f"流水里用户名乱码:{g['user_name']!r}"
    st = await jfvip.vip_state(uid)
    assert st["alive"] is True
    await userauth.close()


@needs_db
@pytest.mark.asyncio
async def test_gen_cards_batched_and_unique():
    """批量发卡:数量正确、全局唯一、且不含易混字符 0/1/I/O。"""
    await _prepare()
    await userauth._q("DELETE FROM guantai_jf_card WHERE batch='T-BATCH'")
    err, out = await jfvip.gen_cards(200, "m1", "T-BATCH", "联测", "admin")
    assert err == "" and out["count"] == 200, (err, out)
    n = await userauth._q("SELECT COUNT(DISTINCT card) c FROM guantai_jf_card "
                          "WHERE batch='T-BATCH'", fetch="one")
    assert int(n["c"]) == 200, f"唯一卡号 {n['c']} 张"
    bad = await userauth._q(
        "SELECT COUNT(*) c FROM guantai_jf_card WHERE batch='T-BATCH' AND "
        "(card LIKE '%%0%%' OR card LIKE '%%1%%' OR card LIKE '%%I%%' OR card LIKE '%%O%%')",
        fetch="one")
    assert int(bad["c"]) == 0, f"{bad['c']} 张含易混字符"
    await userauth.close()


@needs_db
@pytest.mark.asyncio
async def test_revoke_does_not_touch_xiaodingdang():
    """撤销只扣九法VIP,**不回收已赠送的小叮当时长**(那部分已进父项目的账)。"""
    await _prepare()
    uid = await _mk_user("t_rev", 1)
    await userauth._q("DELETE FROM guantai_jf_grant_log WHERE source='revoke'")
    await _mk_order("D-R1", uid, "t_rev", "m1")
    await jfvip.grant_by_order(uid, "t_rev", "D-R1")
    due_b = (await userauth._q(f"SELECT due_time FROM `{userauth.UA.cfg.user_table}` "
                               f"WHERE id=%s", (uid,), fetch="one"))["due_time"]
    err, _ = await jfvip.revoke_by_admin(uid, "t_rev", 24, "admin", "联测")
    assert err == "", err
    due_a = (await userauth._q(f"SELECT due_time FROM `{userauth.UA.cfg.user_table}` "
                               f"WHERE id=%s", (uid,), fetch="one"))["due_time"]
    assert due_a == due_b, "撤销误动了小叮当到期时间"
    g = await userauth._q("SELECT jf_hours,dd_hours FROM guantai_jf_grant_log "
                          "WHERE source='revoke' ORDER BY id DESC LIMIT 1", fetch="one")
    assert int(g["jf_hours"]) == -24 and int(g["dd_hours"]) == 0, dict(g)
    await userauth.close()
