"""
test_sso.py — 链接快速登录(4.1.0,SSO)
================================================================================
分层(与登录/注册测试同构):
  · 纯单元(恒跑,零外部依赖):票据形态归一、每 IP 限频(进程内兜底档)、
    功能开关默认关、超限后的 429 短路(不触 DB)。
  · 静态契约钉(恒跑):guantai_sso_ticket DDL 同时存在于 _SCHEMA 与
    init_userdb.sql(两处建表通道不许漂移);前端 app.js 的兑换链
    (#sso= 片段消费 / replaceState 清参 / /api/auth/sso / switch_confirm 确认)
    与后端端点同在;SSO-LOGIN.md 接入文档在册;运维脚本(smoke_auth /
    userdb_check)的表清单已含新表。
  · tb_user SQL 纪律无需在此重复 —— test_register.py::test_tb_user_sql_discipline
    对全部 app/*.py 恒扫,SSO 新增代码自动在其辖区内(仅 SELECT/JOIN,恒绿)。
  · 联测(真库全流程:签发→兑换→单次核销→互顶)走 scripts/smoke_auth.py 的
    HTTP 面,与登录/注册同一套烟囱;本文件不连库,CI/无库环境零误伤。

默认部署(未设 STA_USER_SSO)下 sso_enabled 恒 False —— 端点回 503、前端
片段缺席时零行为,其余测试文件不感知本模块存在。
"""
from __future__ import annotations

import asyncio
import os
import re
import secrets
import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import userauth  # noqa: E402
from app.settings import UserAuthCfg  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
APP_JS = ROOT / "assets" / "app.js"
INIT_SQL = Path(__file__).resolve().parents[1] / "scripts" / "init_userdb.sql"
SMOKE = Path(__file__).resolve().parents[1] / "scripts" / "smoke_auth.py"
CHECK = Path(__file__).resolve().parents[1] / "scripts" / "userdb_check.py"
SSO_DOC = ROOT / "SSO-LOGIN.md"


# ══ 纯单元 ════════════════════════════════════════════════════════════════════
def test_sso_ticket_norm():
    t = "a1" * 32
    assert userauth.sso_ticket_norm(t) == t
    assert userauth.sso_ticket_norm("  " + t.upper() + "\n") == t   # 去空白 + 小写归一
    assert userauth.sso_ticket_norm(t[:-1]) == ""                    # 63 位
    assert userauth.sso_ticket_norm(t + "0") == ""                   # 65 位
    assert userauth.sso_ticket_norm(t[:-1] + "g") == ""              # 非 hex
    assert userauth.sso_ticket_norm("") == ""
    assert userauth.sso_ticket_norm(None) == ""
    assert userauth.sso_ticket_norm(12345) == ""                     # 非字符串容错


def test_sso_enabled_default_off():
    """默认关(不配置即不存在):cfg 缺席 / 显式 False / 仅登录启用都不算开。"""
    old = userauth.UA.cfg
    try:
        userauth.UA.cfg = None
        assert not userauth.sso_enabled()
        userauth.UA.cfg = UserAuthCfg(host="x", db="x", user="x")
        assert UserAuthCfg().sso_enabled is False                   # dataclass 默认值钉
        # enabled() 还取决于 aiomysql 可用性,这里只断言开关本身不放行
        assert getattr(userauth.UA.cfg, "sso_enabled", False) is False
    finally:
        userauth.UA.cfg = old


async def test_sso_throttle_mem_fallback(monkeypatch):
    """Redis 缺席 → 进程内兜底计数:第 _SSO_IP_10M+1 次起返回剩余秒数,
    换 IP 互不串桶;计数器有界清理不炸。"""
    old_redis, old_mem = userauth.UA.redis, userauth.UA.mem_sso
    try:
        userauth.UA.redis = None
        userauth.UA.mem_sso = {}
        for _ in range(userauth._SSO_IP_10M):
            assert await userauth._sso_throttled("9.9.9.9") is None
        lock = await userauth._sso_throttled("9.9.9.9")
        assert isinstance(lock, int) and 1 <= lock <= userauth._SSO_WIN_S
        assert await userauth._sso_throttled("8.8.8.8") is None      # 异 IP 不受累
    finally:
        userauth.UA.redis, userauth.UA.mem_sso = old_redis, old_mem


async def test_sso_exchange_throttled_short_circuit():
    """超限后 sso_exchange 立刻 429(**先限频后一切**),不触 DB、不触 schema。
    schema_ok=False 时 _log_login 为 no-op,故本用例零外部依赖可跑。"""
    old = (userauth.UA.cfg, userauth.UA.redis, userauth.UA.mem_sso,
           userauth.UA.schema_ok)
    try:
        userauth.UA.cfg = UserAuthCfg(host="x", db="x", user="x", sso_enabled=True)
        userauth.UA.redis = None
        userauth.UA.schema_ok = False
        key = "guantai:sso:ip:7.7.7.7"
        userauth.UA.mem_sso = {key: (userauth._SSO_IP_10M + 5,
                                     time.monotonic() + 500)}
        status, payload, token = await userauth.sso_exchange(
            "f" * 64, False, "", "7.7.7.7", "ua")
        assert status == 429 and payload["error"] == "throttled" and token is None
        assert int(payload.get("retryAfter") or 0) >= 1
    finally:
        (userauth.UA.cfg, userauth.UA.redis, userauth.UA.mem_sso,
         userauth.UA.schema_ok) = old


# ══ 静态契约钉 ════════════════════════════════════════════════════════════════
def test_sso_ddl_in_both_schema_channels():
    """建表双通道(代码 _SCHEMA / 手动 init_userdb.sql)都必须含 guantai_sso_ticket,
    且关键列/唯一键同在 —— 两处漂移是「手动预建后代码建不同表」的事故温床。"""
    ddl_code = [s for s in userauth._SCHEMA if "guantai_sso_ticket" in s]
    assert len(ddl_code) == 1, "代码 _SCHEMA 应恰含一条 guantai_sso_ticket DDL"
    sql = INIT_SQL.read_text(encoding="utf-8")
    assert "guantai_sso_ticket" in sql, "init_userdb.sql 缺 guantai_sso_ticket"
    for frag in ("token_hash", "CHAR(64)", "UNIQUE KEY uk_token", "expires_at",
                 "used", "CHARSET=gbk"):
        assert frag in ddl_code[0], f"_SCHEMA DDL 缺 {frag}"
        assert frag in sql, f"init_userdb.sql DDL 缺 {frag}"


def test_sso_frontend_backend_contract():
    """前后端契约:端点路径、片段参数名、64hex 位数、只消费一次(replaceState)、
    换号确认(switch_confirm/allowSwitch)四端同值钉住。"""
    js = APP_JS.read_text(encoding="utf-8")
    py = (Path(__file__).resolve().parents[1] / "app" / "userauth.py"
          ).read_text(encoding="utf-8")
    assert "/api/auth/sso" in js and '"/api/auth/sso"' in py
    assert re.search(r"sso=\(\[0-9a-fA-F\]\{64\}\)", js), "前端片段正则应钉 64 hex"
    assert "history.replaceState" in js.split("async function ssoConsume", 1)[1] \
        .split("async function", 1)[0], "ssoConsume 必须先清片段(只消费一次)"
    for kw in ("switch_confirm", "allowSwitch"):
        assert kw in js and kw in py, f"换号确认契约缺 {kw}"
    assert "ssoConsume()" in js.split("async function boot", 1)[1] \
        .split("authInit()", 1)[0], "boot 必须在 authInit 之前兑换票据"


def test_sso_ops_files_updated():
    """运维配套不许漏:接入文档在册;smoke_auth 的建表断言与 DROP 清单、
    userdb_check 的 need 集合都已含新表(否则烟囱/体检对真库假红)。"""
    assert SSO_DOC.exists(), "SSO-LOGIN.md 接入文档缺席"
    doc = SSO_DOC.read_text(encoding="utf-8")
    for kw in ("guantai_sso_ticket", "INSERT", "#sso=", "STA_USER_SSO"):
        assert kw in doc, f"SSO-LOGIN.md 缺关键内容 {kw}"
    smoke = SMOKE.read_text(encoding="utf-8")
    assert smoke.count("guantai_sso_ticket") >= 2, \
        "smoke_auth.py 的 DROP 清单与期望表断言都应含 guantai_sso_ticket"
    assert "guantai_sso_ticket" in CHECK.read_text(encoding="utf-8"), \
        "userdb_check.py 的 need 表集合应含 guantai_sso_ticket"


# ══ 联测(本地 1:1 复刻用户库;不可达整层 skip;与 test_userauth 同款夹具)═════
import hashlib as _hl  # noqa: E402
import socket as _sk  # noqa: E402

import pymysql  # noqa: E402
import pytest_asyncio  # noqa: E402

_HOST, _PORT = "127.0.0.1", int(os.environ.get("STA_TEST_USERDB_PORT", "3307"))


def _db_reachable() -> bool:
    try:
        with _sk.create_connection((_HOST, _PORT), timeout=0.6):
            return True
    except OSError:
        return False


needs_db = pytest.mark.skipif(not _db_reachable(),
                              reason=f"需要本地用户库 {_HOST}:{_PORT}(MariaDB 1:1 复刻)")


def _cfg(**kw) -> UserAuthCfg:
    base = dict(host=_HOST, port=_PORT, db="fanxing_changkong_user_db",
                user="fanxing_admin", password="fanxing_admin,.", charset="gbk",
                cache_ttl_s=0.0, sso_enabled=True,
                login_fail_user=1000, login_fail_ip=1000)
    base.update(kw)
    return UserAuthCfg(**base)


@pytest_asyncio.fixture()
async def sso_env():
    async def _setup(cfg: UserAuthCfg):
        await userauth.init(cfg, None)     # redis=None:限频走进程内兜底
        assert userauth.UA.schema_ok or await userauth._ensure_schema()
        userauth.UA.mem_sso = {}           # 每用例干净的限频兜底桶
    yield _setup
    await userauth.close()
    userauth.UA.cfg = None
    userauth.UA.cache = {}
    userauth.UA.schema_ok = False


def _conn():
    return pymysql.connect(host=_HOST, port=_PORT, user="fanxing_admin",
                           password="fanxing_admin,.", charset="gbk",
                           database="fanxing_changkong_user_db", autocommit=True)


def _uid_of(name: str) -> int:
    with _conn() as c, c.cursor() as cur:
        cur.execute("SELECT id FROM tb_user WHERE user_name=%s", (name,))
        return int(cur.fetchone()[0])


def _mint(uid: int, ttl_s: int = 60, age_s: int = 0) -> str:
    """扮演签发方(其它项目):按 SSO-LOGIN.md 契约 INSERT 一枚票据。
    age_s>0 = 把 created_at 拨旧,模拟「签发方误写超长有效期」的年龄硬顶场景。"""
    ticket = secrets.token_hex(32)
    th = _hl.sha256(ticket.encode()).hexdigest()
    with _conn() as c, c.cursor() as cur:
        cur.execute("INSERT INTO guantai_sso_ticket (user_id, token_hash, created_at, "
                    "expires_at, note) VALUES (%s, %s, DATE_SUB(NOW(), INTERVAL %s SECOND), "
                    "DATE_ADD(NOW(), INTERVAL %s SECOND), 'pytest')",
                    (uid, th, int(age_s), int(ttl_s)))
    return ticket


def _ticket_row(ticket: str) -> tuple:
    th = _hl.sha256(ticket.encode()).hexdigest()
    with _conn() as c, c.cursor() as cur:
        cur.execute("SELECT used, used_ip FROM guantai_sso_ticket WHERE token_hash=%s", (th,))
        return cur.fetchone()


def _last_log_reason(uid: int) -> str:
    with _conn() as c, c.cursor() as cur:
        cur.execute("SELECT reason FROM guantai_login_log WHERE user_id=%s "
                    "ORDER BY id DESC LIMIT 1", (uid,))
        r = cur.fetchone()
        return r[0] if r else ""


@needs_db
async def test_sso_full_flow_single_use(sso_env):
    """快乐路径:签发方 INSERT → 兑换 200(会话可校验、审计 reason=sso、
    票据核销落 used/used_ip)→ 同票重放 401(单次有效)。大写票据输入照样命中
    (消费侧小写归一 —— 跨端契约的另一半)。"""
    await sso_env(_cfg())
    uid = _uid_of("测试用户A")
    ticket = _mint(uid)
    st, body, tok = await userauth.sso_exchange(ticket.upper(), False, "", "10.0.0.1", "pytest")
    assert st == 200 and tok and body["user"]["userName"] == "测试用户A"
    assert body["switched"] is False
    state, pr, _ = await userauth.validate(tok)
    assert state == "ok" and pr.user_id == uid
    assert _last_log_reason(uid) == "sso"
    used, used_ip = _ticket_row(ticket)
    assert int(used) == 1 and used_ip == "10.0.0.1"
    # 重放 → 统一 bad_ticket
    st2, body2, tok2 = await userauth.sso_exchange(ticket, False, "", "10.0.0.2", "pytest")
    assert (st2, body2["error"], tok2) == (401, "bad_ticket", None)
    await userauth.logout(tok)


@needs_db
async def test_sso_expiry_and_age_clamp(sso_env):
    """签发方 TTL 到点 → 401;签发方误写超长 expires_at 时,消费侧 created_at
    年龄硬顶(sso_max_age_s)照样拒收 —— 票据寿命上界不受签发方 bug 摆布。"""
    await sso_env(_cfg(sso_max_age_s=300))
    uid = _uid_of("测试用户A")
    st, body, _ = await userauth.sso_exchange(_mint(uid, ttl_s=-5), False, "",
                                              "10.0.1.1", "pytest")
    assert (st, body["error"]) == (401, "bad_ticket")
    # created_at 十分钟前、expires_at 还有十分钟(签发方 bug)→ 年龄硬顶拒收
    st, body, _ = await userauth.sso_exchange(_mint(uid, ttl_s=600, age_s=600), False, "",
                                              "10.0.1.2", "pytest")
    assert (st, body["error"]) == (401, "bad_ticket")
    # 幽灵 user_id → 同一 bad_ticket(不泄露「票据存在但用户没了」)
    st, body, _ = await userauth.sso_exchange(_mint(99999999), False, "",
                                              "10.0.1.3", "pytest")
    assert (st, body["error"]) == (401, "bad_ticket")


@needs_db
async def test_sso_user_state_mirrors_login(sso_env):
    """封停/到期语义与账密登录同口径(403 banned / 403 expired+dueTime);
    状态拒绝发生在核销**之前** —— 票据不被白白消费(续费后同链重点可用,
    若仍在 60s 窗内)。"""
    await sso_env(_cfg())
    t_ban = _mint(_uid_of("banneduser"))
    st, body, _ = await userauth.sso_exchange(t_ban, False, "", "10.0.2.1", "pytest")
    assert (st, body["error"]) == (403, "banned")
    assert int(_ticket_row(t_ban)[0]) == 0            # 未核销
    t_exp = _mint(_uid_of("expireduser"))
    st, body, _ = await userauth.sso_exchange(t_exp, False, "", "10.0.2.2", "pytest")
    assert (st, body["error"]) == (403, "expired") and body.get("dueTime")
    assert int(_ticket_row(t_exp)[0]) == 0


@needs_db
async def test_sso_switch_confirm_flow(sso_env):
    """已登录 A、拿 B 的票据:未确认 → 409(票据不消费);确认(allowSwitch)
    → 200 switched=True 且身份换成 B。已登录**同一账号**再兑换 → 直接 200
    不弹确认(switched=False)。"""
    await sso_env(_cfg())
    st, body, tok_a = await userauth.login("测试用户A", "pw123456", "10.0.3.1", "pytest")
    assert st == 200
    uid_b = _uid_of("plainuser")
    t_b = _mint(uid_b)
    st, body, tok = await userauth.sso_exchange(t_b, False, tok_a, "10.0.3.1", "pytest")
    assert (st, body["error"], tok) == (409, "switch_confirm", None)
    assert body["current"] == "测试用户A" and body["target"] == "plainuser"
    assert int(_ticket_row(t_b)[0]) == 0              # 409 不消费
    st, body, tok_b = await userauth.sso_exchange(t_b, True, tok_a, "10.0.3.1", "pytest")
    assert st == 200 and body["switched"] is True and body["user"]["userName"] == "plainuser"
    # 已登录同号:新票直接换,不需要确认
    t_b2 = _mint(uid_b)
    st, body, tok_b2 = await userauth.sso_exchange(t_b2, False, tok_b, "10.0.3.1", "pytest")
    assert st == 200 and body["switched"] is False
    await userauth.logout(tok_b2)


@needs_db
async def test_sso_concurrent_consume_exactly_once(sso_env):
    """并发竞速:同一票据 6 路同时兑换 → 恰一名赢家(DB 单语句原子核销),
    其余统一 bad_ticket;赢家会话可校验。多标签页/预览抓取/恶意重放的现实形态。"""
    await sso_env(_cfg())
    uid = _uid_of("sha1user")
    ticket = _mint(uid)
    outs = await asyncio.gather(*[
        userauth.sso_exchange(ticket, False, "", f"10.0.4.{i}", "pytest")
        for i in range(6)])
    wins = [o for o in outs if o[0] == 200]
    fails = [o for o in outs if o[0] == 401]
    assert len(wins) == 1 and len(fails) == 5
    state, pr, _ = await userauth.validate(wins[0][2])
    assert state == "ok" and pr.user_id == uid
    await userauth.logout(wins[0][2])


@needs_db
async def test_sso_disabled_and_throttle_live(sso_env):
    """开关纪律:sso_enabled=False 时 sso_enabled() 恒 False(端点层 503);
    限频真值:同 IP 连打 31 发坏票 → 第 31 发 429(前 30 发统一 bad_ticket)。"""
    await sso_env(_cfg(sso_enabled=False))
    assert not userauth.sso_enabled()
    userauth.UA.cfg.sso_enabled = True
    assert userauth.sso_enabled()
    bad = "e" * 64
    last = None
    for i in range(userauth._SSO_IP_10M + 1):
        last = await userauth.sso_exchange(bad, False, "", "10.0.5.9", "pytest")
        if i < userauth._SSO_IP_10M:
            assert last[0] == 401
    assert last[0] == 429 and last[1]["error"] == "throttled"


# ══ HTTP 路由层联测(httpx ASGITransport 直插 FastAPI;真库,同款 skip)═══════
# sso_exchange 内核已被上组联测覆盖;本组补齐**路由壳**从未执行过的部分:
# 503 开关语义 / 400 载荷闸 / Set-Cookie 落头 / 409→allowSwitch 的真实 Cookie
# 往返 / 429 的 Retry-After 头 / on_login_ok 首登回调触发。
import httpx  # noqa: E402
from fastapi import FastAPI  # noqa: E402


def _mini_app() -> FastAPI:
    a = FastAPI()
    a.include_router(userauth.router)
    return a


def _client(app: FastAPI) -> httpx.AsyncClient:
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=app),
                             base_url="http://testserver")


@needs_db
async def test_sso_http_gate_semantics(sso_env):
    """路由壳:SSO 关 → 503 sso_disabled;开 → 非 JSON 载荷 400 bad_request。"""
    await sso_env(_cfg(sso_enabled=False))
    app = _mini_app()
    async with _client(app) as cl:
        r = await cl.post("/api/auth/sso", json={"ticket": "f" * 64})
        assert r.status_code == 503 and r.json()["error"] == "sso_disabled"
        userauth.UA.cfg.sso_enabled = True
        r = await cl.post("/api/auth/sso", content=b"not json",
                          headers={"content-type": "application/json"})
        assert r.status_code == 400 and r.json()["error"] == "bad_request"
        r = await cl.post("/api/auth/sso", json=["not", "dict"])
        assert r.status_code == 400


@needs_db
async def test_sso_http_full_cookie_and_switch(sso_env):
    """全链路过 HTTP:兑换 200 落 Set-Cookie + on_login_ok 回调;同票重放 401;
    已登录 A 的真实 Cookie 携带下换 B 票 → 409 → allowSwitch → 200 switched,
    Cookie 换新。"""
    await sso_env(_cfg())
    calls = []

    async def _rec(uid: int):
        calls.append(uid)

    old_cb = userauth.on_login_ok
    userauth.on_login_ok = _rec
    try:
        app = _mini_app()
        uid_a, uid_b = _uid_of("测试用户A"), _uid_of("plainuser")
        async with _client(app) as cl:
            t1 = _mint(uid_a)
            r = await cl.post("/api/auth/sso", json={"ticket": t1},
                              headers={"x-forwarded-for": "10.8.0.1"})
            assert r.status_code == 200 and r.json()["user"]["userName"] == "测试用户A"
            ck = r.headers.get("set-cookie", "")
            assert userauth.UA.cfg.cookie_name in ck and "HttpOnly" in ck
            assert calls == [uid_a]                       # 首登回调恰一次
            r2 = await cl.post("/api/auth/sso", json={"ticket": t1},
                               headers={"x-forwarded-for": "10.8.0.2"})
            assert r2.status_code == 401                  # 重放
            # httpx 已存下会话 Cookie → 换 B 票走真实「已登录他号」路径
            t2 = _mint(uid_b)
            r3 = await cl.post("/api/auth/sso", json={"ticket": t2},
                               headers={"x-forwarded-for": "10.8.0.3"})
            assert r3.status_code == 409 and r3.json()["error"] == "switch_confirm"
            assert r3.json()["current"] == "测试用户A" and r3.json()["target"] == "plainuser"
            r4 = await cl.post("/api/auth/sso",
                               json={"ticket": t2, "allowSwitch": True},
                               headers={"x-forwarded-for": "10.8.0.4"})
            assert r4.status_code == 200 and r4.json()["switched"] is True
            assert r4.json()["user"]["userName"] == "plainuser"
            assert userauth.UA.cfg.cookie_name in r4.headers.get("set-cookie", "")
            assert calls == [uid_a, uid_b]
    finally:
        userauth.on_login_ok = old_cb


@needs_db
async def test_sso_http_throttle_retry_after(sso_env):
    """429 路径过 HTTP:预灌满该 IP 的兜底计数桶 → 429 且带 Retry-After 头。"""
    await sso_env(_cfg())
    userauth.UA.mem_sso = {"guantai:sso:ip:10.8.9.9":
                           (userauth._SSO_IP_10M + 1, time.monotonic() + 400)}
    app = _mini_app()
    async with _client(app) as cl:
        r = await cl.post("/api/auth/sso", json={"ticket": "f" * 64},
                          headers={"x-forwarded-for": "10.8.9.9"})
        assert r.status_code == 429 and r.json()["error"] == "throttled"
        assert int(r.headers.get("retry-after", "0")) >= 1


@needs_db
async def test_sso_throttle_redis_branch(sso_env):
    """限频的 Redis 主通道(联测此前只走了 mem 兜底):fakeredis 上 31 发 →
    第 31 发 429;mem 兜底桶保持零污染(证明确实走的 Redis 分支)。"""
    import fakeredis.aioredis as far
    await sso_env(_cfg())
    userauth.UA.redis = far.FakeRedis()
    try:
        last = None
        for i in range(userauth._SSO_IP_10M + 1):
            last = await userauth._sso_throttled("10.8.7.7")
        assert isinstance(last, int) and last >= 1
        assert userauth.UA.mem_sso == {}                 # Redis 分支未落兜底桶
    finally:
        await userauth.UA.redis.aclose()
        userauth.UA.redis = None
