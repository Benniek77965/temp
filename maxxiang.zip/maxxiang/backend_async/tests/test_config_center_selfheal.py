"""
test_config_center_selfheal.py — 敏感值读取失败的自愈语义(4.7.7 事故钉)
================================================================================
事故现场(真机):管理台总览上 `worker-<host>-1` 长期显示

    套用异常
    userauth.jf_card_api_key: 敏感值读取失败 network:TimeoutError

三条独立缺陷叠在一起才有这个结果,本文件逐条钉死:

  ① **错误粘滞、永不自愈** —— `_pull_apply` 出错后照样把 `applied_rev` 推到
     目标 rev,而心跳对账的条件是 `cur > applied_rev`。两者一相等,补拉条件
     永远不成立:一次 5 秒的 Redis 读超时,就把那行红字焊死到进程重启为止,
     `fleet.converged` 也永远是 False(顶栏「已收敛」被一次抖动永久污染)。
  ② **worker 在套用它永远用不到的密钥** —— `userauth.jf_card_api_key` 登记的是
     `consumers=("web",)`,报错的却是 worker。`apply_snapshot` 只过滤了
     readonly / RESERVED,没按角色过滤 consumers(而 `fleet()` 算 needs_restart
     时早就是按 consumers 过滤的 —— 同一份口径,漏在了套用路径上)。
  ③ **错误文本被 repr 吞干净** —— redis-py 8.x 给 RedisError 定义了
     `__repr__ = f"{error_type.value}:{ClassName}"`,`{e!r}` 出来只剩
     `network:TimeoutError`,「哪台 Redis、什么操作超时」全丢了。

刻意**不**用真 Redis:这几条全是纯逻辑,用假 bus 就能钉死,任何环境都能跑。
"""
from __future__ import annotations

import asyncio

import pytest

from app import config_center as cc
from app import config_registry as reg
from app.settings import Settings

try:                                   # 用真的 redis 异常类型,才能钉住 ③
    from redis.exceptions import TimeoutError as RedisTimeoutError
except Exception:                      # pragma: no cover — 没装 redis 也要能跑
    class RedisTimeoutError(Exception):
        def __repr__(self):            # 复刻 redis-py 8.x 的吞信息 repr
            return "network:TimeoutError"


WEB_KEY = "userauth.jf_card_api_key"   # sensitive · consumers=("web",)
WORKER_KEY = "auth.ticket"             # sensitive · consumers=("worker",)


# ── 假 Redis / 假 bus / 假 PG ────────────────────────────────────────────────
class _FakeRedis:
    """hgetall(cfg:sensitive) 前 `fail_times` 次抛读超时,之后正常返回。"""

    def __init__(self, fail_times: int = 0, payload: dict | None = None):
        self.fail_left = fail_times
        self.payload = payload or {}
        self.sens_reads = 0            # 对 cfg:sensitive 的实际请求次数
        self.hb: dict = {}

    async def hgetall(self, key):
        if key != cc.K_SENSITIVE:
            return {}
        self.sens_reads += 1
        if self.fail_left > 0:
            self.fail_left -= 1
            raise RedisTimeoutError("Timeout reading from redis:6379")
        return dict(self.payload)

    async def hset(self, key, mapping=None):
        self.hb[key] = dict(mapping or {})

    async def expire(self, key, ttl):
        pass

    def pubsub(self):
        return _FakePubSub()


class _FakePubSub:
    async def subscribe(self, *a):
        pass

    async def get_message(self, **kw):
        await asyncio.sleep(kw.get("timeout", 0.01))
        return None

    async def aclose(self):
        pass


class _Bus:
    def __init__(self, r):
        self.r = r


class _DB:
    """只有一版 rev 的内存 PG —— 「运维此后再没改过任何参数」正是常态。"""

    def __init__(self, snap, rev: int = 7):
        self.snap, self.rev = snap, rev

    async def cfg_latest(self):
        return self.rev, dict(self.snap)

    async def cfg_latest_rev(self):
        return self.rev


@pytest.fixture()
def s(monkeypatch):
    cc._reset_base_for_tests()
    st = Settings()
    cc.capture_base(st)
    monkeypatch.setattr(cc, "SENS_READ_BACKOFF_S", 0.0)   # 重试退避在测试里清零
    yield st
    cc._reset_base_for_tests()


# ── ① 粘滞:一次抖动不得变成永久红 ───────────────────────────────────────────
async def test_transient_failure_sets_retry_pending_and_heals(s):
    r = _FakeRedis(fail_times=cc.SENS_READ_ATTEMPTS,        # 恰好耗尽第一轮重试
                   payload={WORKER_KEY: "fresh-ticket-xyz"})
    bus, db = _Bus(r), _DB({WORKER_KEY: reg.SENTINEL_REDIS})
    state = cc.CenterState(role="worker")

    await cc._pull_apply(s, bus, db, {}, state)
    assert state.errors, "读超时必须如实报错"
    assert state.retry_pending is True, "基础设施故障必须标记为待重试"
    assert state.applied_rev == 7
    assert reg.get_path(s, WORKER_KEY) != "fresh-ticket-xyz", "这一轮不该拿到真值"

    # 心跳对账:版本号并没有落后(cur == applied_rev),旧代码在这里就永远卡住了
    cur = await db.cfg_latest_rev()
    assert cur == state.applied_rev
    assert cur > state.applied_rev or state.retry_pending, \
        "run_agent 的补拉条件必须能靠 retry_pending 成立,否则一次抖动永久红"

    await cc._pull_apply(s, bus, db, {}, state)            # 下一个心跳周期
    assert state.errors == [], "Redis 恢复后错误必须自行消失"
    assert state.retry_pending is False
    assert reg.get_path(s, WORKER_KEY) == "fresh-ticket-xyz", "真值必须补上"


async def test_read_is_retried_within_one_apply(s):
    """一次套用内部就先重试若干次 —— 毫秒级抖动根本不该惊动管理台。"""
    r = _FakeRedis(fail_times=cc.SENS_READ_ATTEMPTS - 1,
                   payload={WORKER_KEY: "t2"})
    state = cc.CenterState(role="worker")
    await cc._pull_apply(s, _Bus(r), _DB({WORKER_KEY: reg.SENTINEL_REDIS}), {}, state)
    assert r.sens_reads == cc.SENS_READ_ATTEMPTS, "应在单轮内重试到成功"
    assert state.errors == [] and reg.get_path(s, WORKER_KEY) == "t2"


# ── ② consumers:worker 不该为 web 独有的密钥打 Redis ────────────────────────
async def test_worker_skips_web_only_sensitive_key(s):
    r = _FakeRedis(fail_times=99)          # 只要读一次就必炸
    state = cc.CenterState(role="worker")
    await cc._pull_apply(s, _Bus(r), _DB({WEB_KEY: reg.SENTINEL_REDIS}), {}, state)
    assert r.sens_reads == 0, "worker 不消费该密钥,连读都不该读"
    assert state.errors == [] and state.retry_pending is False


async def test_web_still_applies_its_own_sensitive_key(s):
    r = _FakeRedis(payload={WEB_KEY: "K" * 40})
    state = cc.CenterState(role="web")
    await cc._pull_apply(s, _Bus(r), _DB({WEB_KEY: reg.SENTINEL_REDIS}), {}, state)
    assert r.sens_reads == 1
    assert reg.get_path(s, WEB_KEY) == "K" * 40


async def test_unknown_role_is_not_filtered(s):
    """自定义角色(测试/脚本)保持老行为全量套用 —— 新逻辑不得把它们静默架空。"""
    r = _FakeRedis(payload={WEB_KEY: "K" * 40})
    state = cc.CenterState(role="test")
    await cc._pull_apply(s, _Bus(r), _DB({WEB_KEY: reg.SENTINEL_REDIS}), {}, state)
    assert r.sens_reads == 1 and reg.get_path(s, WEB_KEY) == "K" * 40


# ── ③ 错误文本:不许再是一句没有下文的 `network:TimeoutError` ────────────────
async def test_error_text_keeps_diagnostics(s):
    r = _FakeRedis(fail_times=99)
    state = cc.CenterState(role="worker")
    await cc._pull_apply(s, _Bus(r), _DB({WORKER_KEY: reg.SENTINEL_REDIS}), {}, state)
    assert len(state.errors) == 1
    msg = state.errors[0]
    assert msg.startswith(f"{WORKER_KEY}: 敏感值读取失败 ")
    assert "TimeoutError" in msg
    assert "redis:6379" in msg, "必须保留「哪台 Redis 超时」——repr() 会把它吞掉"
    assert repr(RedisTimeoutError("x")) not in msg or "6379" in msg


# ── 心跳/舰队视图:字段贯通 ─────────────────────────────────────────────────
async def test_heartbeat_carries_retry_pending(s):
    r = _FakeRedis(fail_times=99)
    bus = _Bus(r)
    state = cc.CenterState(role="worker")
    await cc._pull_apply(s, bus, _DB({WORKER_KEY: reg.SENTINEL_REDIS}), {}, state)
    await cc._beat(bus, state)
    hb = r.hb[cc.K_HB_PREFIX + state.instance]
    assert int(hb["retry_pending"]) == 1
    assert "敏感值读取失败" in hb["errors"]


# ── run_agent 端到端:抖动过去后必须自己好起来 ───────────────────────────────
async def test_run_agent_self_heals_without_new_rev(s, monkeypatch):
    monkeypatch.setattr(cc, "HB_INTERVAL_S", 0)      # 心跳节拍压到最小
    r = _FakeRedis(fail_times=cc.SENS_READ_ATTEMPTS,
                   payload={WORKER_KEY: "healed-ticket"})
    bus, db = _Bus(r), _DB({WORKER_KEY: reg.SENTINEL_REDIS})
    state = cc.CenterState(role="worker")
    running = [True]
    task = asyncio.create_task(cc.run_agent(
        settings=s, role="worker", bus=bus, db=db, hooks={}, state=state,
        running=lambda: running[0]))
    try:
        for _ in range(60):
            if reg.get_path(s, WORKER_KEY) == "healed-ticket":
                break
            await asyncio.sleep(0.05)
        assert reg.get_path(s, WORKER_KEY) == "healed-ticket", \
            "没有任何新 rev,进程也必须靠心跳把上一轮没落全的配置补上"
        assert state.errors == [] and state.retry_pending is False
    finally:
        running[0] = False
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task


# ── ③ 5.2.0 复查:无自愈链路的敏感项在 Redis 里丢了,必须如实上报 ────────────────
async def test_lost_web_secret_is_reported_not_silent(s, monkeypatch):
    """外部发卡 API 密钥只存 Redis 内存(compose 的 Redis 不落盘)。Redis 重启后快照里还是
    占位 __redis__,真值却没了 —— web 一重启就悄悄回落到 .env/默认(端点整体 503)。
    旧行为:静默「保持现值」,管理台一片绿。现:值照旧不动,但上报到实例收敛。"""
    monkeypatch.delenv("STA_JF_CARD_API_KEY", raising=False)
    state = cc.CenterState(role="web")
    await cc._pull_apply(s, _Bus(_FakeRedis(payload={})), _DB({WEB_KEY: reg.SENTINEL_REDIS}), {}, state)
    assert reg.get_path(s, WEB_KEY) == ""                       # 值不动(回落即现状)
    assert len(state.errors) == 1 and "不在 Redis" not in state.errors[0]
    assert "已丢失" in state.errors[0] and "STA_JF_CARD_API_KEY" in state.errors[0]
    assert state.retry_pending is False                        # 不是基础设施抖动,重试也没用


async def test_lost_secret_while_process_still_holds_old_value(s):
    """只重启了 Redis、web 还活着:进程内存里仍是旧值(还能用),但下次重启就没了 —— 提前说清。"""
    reg.set_path(s, WEB_KEY, "K" * 40)
    state = cc.CenterState(role="web")
    await cc._pull_apply(s, _Bus(_FakeRedis(payload={})), _DB({WEB_KEY: reg.SENTINEL_REDIS}), {}, state)
    assert reg.get_path(s, WEB_KEY) == "K" * 40
    assert len(state.errors) == 1 and "下次重启" in state.errors[0]


async def test_lost_ticket_stays_silent_because_cookie_renewal_heals_it(s):
    state = cc.CenterState(role="worker")
    await cc._pull_apply(s, _Bus(_FakeRedis(payload={})), _DB({WORKER_KEY: reg.SENTINEL_REDIS}), {}, state)
    assert state.errors == []

