"""
test_config_center.py — 配置中枢单元测试(纯内存,零外部依赖)
================================================================================
覆盖方案的关键承诺:
  · 四层来源判定(default/yaml/env/runtime + auth 的 cookie 例外);
  · set_path **原地**写:子配置对象 identity 不变(铁律一,事实 B 的守卫);
  · apply_snapshot:仅变更项落地、钩子去重、readonly/RESERVED 跳过、
    🔴 hot 模式跳过仅计 needs_restart 而 boot 模式落地(铁律四)、
    no_reset 项清除覆盖不回落、坏值记错不中断其余项(铁律三);
  · 语义校验各规则边界;导出 yaml/env;回滚快照的敏感净化。
"""
from __future__ import annotations

import asyncio
import os

import pytest

from app import config_center as cc
from app import config_registry as reg
from app.settings import Settings


@pytest.fixture()
def s(monkeypatch):
    """干净 Settings + 干净基线(每例独立,不受进程级单例影响)。"""
    cc._reset_base_for_tests()
    st = Settings()
    st.prediction = {"train_window_hours": 24.0, "accuracy_window": 100}
    cc.capture_base(st)
    yield st
    cc._reset_base_for_tests()


async def _apply(st, snap, hooks=None, mode="hot"):
    state = cc.CenterState(role="test")
    res = await cc.apply_snapshot(st, snap, hooks=hooks or {}, mode=mode, state=state)
    return res, state


# ── 原地写:铁律一 ─────────────────────────────────────────────────────────────
def test_set_path_mutates_in_place(s):
    ret_before = s.retention                    # 模拟循环持有的对象引用
    pred_before = s.prediction
    reg.set_path(s, "retention.days", 3.0)
    reg.set_path(s, "prediction.accuracy_window", 55)
    assert s.retention is ret_before and ret_before.days == 3.0
    assert s.prediction is pred_before and pred_before["accuracy_window"] == 55


# ── apply:变更项/钩子/跳过语义 ────────────────────────────────────────────────
async def test_apply_changes_and_hook_dedup(s):
    fired = []
    hooks = {"rl_upstream": lambda: fired.append("rl")}
    (changed, restart, errs), _ = await _apply(
        s, {"ratelimit.upstream_rps": 300, "ratelimit.burst": 900,
            "scheduler.award_jitter_ms": 2000}, hooks)
    assert set(changed) == {"ratelimit.upstream_rps", "ratelimit.burst",
                            "scheduler.award_jitter_ms"}
    assert fired == ["rl"], "同钩子两项变更应只触发一次"
    assert not restart and not errs
    assert s.ratelimit.upstream_rps == 300.0 and s.scheduler.award_jitter_ms == 2000
    # 幂等:再次套用同快照 → 零变更、钩子不再触发
    (changed2, _, _), _ = await _apply(
        s, {"ratelimit.upstream_rps": 300, "ratelimit.burst": 900,
            "scheduler.award_jitter_ms": 2000}, hooks)
    assert changed2 == [] and fired == ["rl"]


async def test_apply_reset_to_base_on_removed_key(s):
    await _apply(s, {"scheduler.claim_batch": 500})
    assert s.scheduler.claim_batch == 500
    (changed, _, _), _ = await _apply(s, {})          # 覆盖被清除 → 回落基线
    assert "scheduler.claim_batch" in changed and s.scheduler.claim_batch == 200


async def test_apply_skips_readonly_and_reserved(s):
    (changed, restart, errs), _ = await _apply(
        s, {"pg_dsn": "postgresql://x", "upstream.fetch_lamp": False})
    assert changed == [] and restart == [] and errs == []
    assert s.pg_dsn.startswith("postgresql://star")     # 未被触碰


async def test_restart_key_hot_skipped_boot_applied(s):
    (changed, restart, _), _ = await _apply(s, {"worker_concurrency": 1200}, mode="hot")
    assert changed == [] and restart == ["worker_concurrency"]
    assert s.worker_concurrency == 800                   # 铁律四:hot 不动
    (changed2, restart2, _), _ = await _apply(s, {"worker_concurrency": 1200}, mode="boot")
    assert changed2 == ["worker_concurrency"] and restart2 == []
    assert s.worker_concurrency == 1200                  # boot 落地 → 重启即生效


async def test_no_reset_keeps_current_when_override_absent(s):
    s.auth.ticket = "runtime-fresh-ticket-from-cookie"   # 模拟续期链路写入
    (changed, _, _), _ = await _apply(s, {})
    assert "auth.ticket" not in changed
    assert s.auth.ticket == "runtime-fresh-ticket-from-cookie"


async def test_bad_value_recorded_not_fatal(s):
    (changed, _, errs), _ = await _apply(
        s, {"scheduler.claim_batch": "not-a-number",
            "scheduler.award_jitter_ms": 1500})
    assert "scheduler.award_jitter_ms" in changed        # 铁律三:其余项照常
    assert any("claim_batch" in e for e in errs)
    assert s.scheduler.claim_batch == 200


async def test_sensitive_sentinel_skipped_in_boot(s):
    (changed, _, errs), _ = await _apply(
        s, {"auth.ticket": reg.SENTINEL_REDIS}, mode="boot")
    assert changed == [] and errs == []                  # 启动期无 Redis 真值:跳过


# ── coerce / 范围 ─────────────────────────────────────────────────────────────
def test_coerce_matrix():
    f = reg.REGISTRY
    assert reg.coerce(f["discovery.enabled"], "off") is False
    assert reg.coerce(f["retention.days"], "0") == 0.0
    assert reg.coerce(f["prediction.showcase_kdist"], " 45, 30 ,15 ") == "45,30,15"
    assert reg.coerce(f["discovery.params"], '{"a": "1"}') == {"a": "1"}
    with pytest.raises(ValueError):
        reg.coerce(f["prediction.explore_style"], "wild")     # 枚举外
    with pytest.raises(ValueError):
        reg.coerce(f["scheduler.claim_batch"], 0)             # ge=1
    with pytest.raises(ValueError):
        reg.coerce(f["prediction.showcase_kdist"], "45,,x")


# ── 来源判定(describe) ───────────────────────────────────────────────────────
def test_describe_source_chain(s, monkeypatch):
    monkeypatch.setenv("STA_RETENTION_DAYS", "14")
    items = {it["key"]: it for it in cc.describe(s, {"scheduler.claim_batch": 400})}
    assert items["scheduler.claim_batch"]["source"] == "runtime"
    assert items["retention.days"]["source"] == "env"
    assert items["retention.days"]["layers"]["env_set"] is True
    assert items["activity_id"]["source"] in ("yaml", "default")
    # auth 的 cookie 例外
    s.auth_cookie_file = "/kg/spell_tamer_config.json"
    items2 = {it["key"]: it for it in cc.describe(s, {})}
    assert items2["auth.ticket"]["source"] == "cookie"
    # 敏感值全链路掩码:完整明文绝不出现(掩码按设计保留前 8 后 4)
    assert "PUT_YOUR_FRESH_X_AUTH_TICKET_HERE" not in str(items2["auth.ticket"])
    assert "…" in items2["auth.ticket"]["effective"]


# ── 语义校验 ──────────────────────────────────────────────────────────────────
def test_semantic_rules():
    e, w = cc.semantic_validate({"retention.days": 0.5,
                                 "prediction.train_window_hours": 24.0})
    assert not e and any("训练窗口" in x for x in w)
    e, w = cc.semantic_validate({"ratelimit.upstream_rps": 0,
                                 "ratelimit.burst": 900})
    assert any("仅当 upstream_rps" in x for x in w)
    e, _ = cc.semantic_validate({"admission.max_bulk": 200000})
    assert any("硬顶" in x for x in e)
    _, w = cc.semantic_validate({"upstream.award_delay": 5,
                                 "upstream.award_max_retries": 10,
                                 "upstream.award_retry_interval": 6})
    assert any("跨局" in x for x in w)
    _, w = cc.semantic_validate({"discovery.interval_s": 6})
    assert any("追尾" in x for x in w)


def test_check_changes_rejects_unknown_and_readonly():
    co, errs = cc.check_changes({"nope.key": 1, "redis_url": "x",
                                 "scheduler.claim_batch": "300"})
    assert co == {"scheduler.claim_batch": 300}
    assert any("未登记" in e for e in errs) and any("只读" in e for e in errs)


# ── 导出与回滚净化 ────────────────────────────────────────────────────────────
def test_export_yaml_and_env():
    snap = {"scheduler.award_jitter_ms": 2500, "retention.days": 3,
            "auth.ticket": reg.SENTINEL_REDIS}
    y = cc.export_snapshot(snap, "yaml")
    assert "award_jitter_ms: 2500" in y and "auth" not in y   # 敏感不出仓
    env = cc.export_snapshot(snap, "env")
    assert "STA_RETENTION_DAYS=3" in env
    assert "award_jitter_ms=2500" in env and env.count("#") >= 2  # 无 env 名的注释化
    assert "敏感值" in env


def test_rollback_snapshot_strips_sensitive():
    clean, skipped = cc.rollback_snapshot(
        {"auth.ticket": reg.SENTINEL_REDIS, "retention.days": 5})
    assert clean == {"retention.days": 5} and skipped == ["auth.ticket"]


def test_mask_and_fingerprint():
    f = reg.REGISTRY["auth.ticket"]
    assert cc.mask(f, "abcdefghijklmnop1234") == "abcdefgh…1234"
    assert cc.mask(f, "short") == "···"
    assert cc.fingerprint("x") == cc.fingerprint("x") != cc.fingerprint("y")
    assert cc.fingerprint("x").startswith("sha256:")
