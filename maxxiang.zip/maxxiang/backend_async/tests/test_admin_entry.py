"""
test_admin_entry.py — 管理台入口 / 账号 + 口令 / 人机验证 / 应急登录(5.3.0)
================================================================================
每一组都对应一条**实跑确认过**的改造前事实(基线实例 + 真 Redis/PG/复刻库):
  · 入口:只挪页面没用 —— POST /api/admin/login 可绕过页面直接打(错口令 401);/admin.html
    经静态兜底直接 200 吐出后台页,连后台是否启用都不看;登录系统开启时未知 /api/x 回 401、
    /api/admin/x 却回 404(守卫对该前缀硬编码豁免,前缀可被一眼认出);
  · 账号:只有一个口令,没有账号这一项;
  · 人机验证:管理台登录没有(注册与用户登录有);
  · 限速:停掉 Redis 后用**正确口令**登录,3.17s 后 429 —— Redis 一挂管理员自己也进不去。

外部发卡接口 POST /api/admin/jfvip/cards/issue 是机器契约:地址、闸序、返回体保持原样
(其行为细节由 test_jfvip_hours_card.py 的既有用例继续钉住,那批用例一字未改地址)。

零外部依赖:ASGI 直连;人机验证走本地模拟的 Cloudflare siteverify。
"""
from __future__ import annotations

import asyncio
import collections
import os
import re
import subprocess
import sys
import time
from types import SimpleNamespace as NS

import httpx
import pytest
from fastapi import FastAPI

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import admin_api, admin_auth as aa, clientip, userauth, wincount  # noqa: E402
from app.settings import UserAuthCfg, get_settings, settings  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
PW, USER = "adm-pass-530", "13268237005"
AP = "/api/ops-entry"            # 自建应用的挂载点:故意不用默认值,证明代码里没有写死任何一个路径


@pytest.fixture(autouse=True)
def _clean(monkeypatch):
    for k in ("STA_ADMIN_PASSWORD_HASH", "STA_ADMIN_SECRET", "STA_ADMIN_IP_ALLOW",
              "STA_ADMIN_SESSION_TTL_S", "STA_TRUSTED_PROXIES", "STA_ADMIN_LOGIN_FAIL_IP",
              "STA_ADMIN_LOGIN_FAIL_GLOBAL", "STA_ADMIN_LOGIN_FAIL_WINDOW_S",
              "STA_ADMIN_LOGIN_LOCK_S", "STA_ADMIN_LOGIN_RATE_PER_MIN", "STA_ADMIN_DEVICE_TTL_D"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("STA_ADMIN_PASSWORD", PW)
    monkeypatch.setenv("STA_USER_DEVICE_KEY", "k" * 40)
    saved = (userauth.UA.cfg, userauth.UA.redis, userauth.UA.dev_key, userauth.UA.dev_key_src)
    userauth.UA.dev_key, userauth.UA.dev_key_src = b"", ""
    monkeypatch.setattr(admin_api, "_ST", None, raising=False)
    wincount.STATE["lua"] = None
    clientip.configure(None)
    aa._reset_for_tests()
    yield
    userauth.UA.cfg, userauth.UA.redis, userauth.UA.dev_key, userauth.UA.dev_key_src = saved
    wincount.STATE["lua"] = None
    clientip.configure(None)
    aa._reset_for_tests()


def _app(prefix: str = AP) -> FastAPI:
    a = FastAPI()
    a.include_router(admin_api.router, prefix=prefix)
    return a


def _client(app, **kw):
    tr = httpx.ASGITransport(app=app, client=("127.0.0.1", 5000))     # 同机反代:XFF 可信
    return httpx.AsyncClient(transport=tr, base_url="http://adm.example", **kw)


def _xff(ip: str) -> dict:
    return {"X-Forwarded-For": ip}


# ══ A. 配置:发货配置钉住入口与账号;环境变量优先于文件 ═══════════════════════════
def test_shipping_config_pins_entry_and_captcha_but_not_account(monkeypatch):
    """★ 需求原文:入口 admin → admin-xdd;账号 13268237005;人机验证与注册一样每次都要。
    用**全新装载**的 Settings 断言(不看进程里那个被测试夹具复位过的单例)。
    账号刻意**不**在 config.yaml:它是凭据,只认 STA_ADMIN_USERNAME(与口令同处 .env)。"""
    for k in ("STA_ADMIN_PATH", "STA_ADMIN_USERNAME", "STA_ADMIN_LOGIN_CAPTCHA", "STA_CONFIG"):
        monkeypatch.delenv(k, raising=False)
    s = get_settings()
    why = ("这是「发货默认」的回执钉:改了 backend_async/config.yaml 的 admin: 段就同步改这里 —— "
           "它防的是「以为改了、其实没生效」,不是限制你改。")
    assert s.admin.path == "admin-xdd", why
    assert s.admin.login_captcha == "auto", why     # 站点配了供应商 → 每次登录必过
    # ★ 账号是凭据,不在 config.yaml:没有 STA_ADMIN_USERNAME 时就是「未设置」(只验口令)。
    #   需求里的账号 13268237005 由 deploy/.env 的 STA_ADMIN_USERNAME 提供(与口令成对),
    #   本用例特意清掉该环境变量,断言默认即为空 —— 账号没有混进代码库。
    assert s.admin.username == "", "账号不该来自 config.yaml;它只认 STA_ADMIN_USERNAME"
    monkeypatch.setenv("STA_ADMIN_USERNAME", "13268237005")
    assert get_settings().admin.username == "13268237005"
    monkeypatch.setenv("STA_ADMIN_USERNAME", "off")       # off/none = 显式不要账号
    assert get_settings().admin.username == ""


def test_env_beats_yaml_and_yaml_int_is_coerced(monkeypatch, tmp_path):
    cfg = tmp_path / "c.yaml"
    # config.yaml 只认 path / login_captcha;即便写了 username 也不生效(账号只走 env)。
    cfg.write_text("admin:\n  path: yaml-entry\n  username: 13800138000\n  login_captcha: always\n",
                   encoding="utf-8")
    monkeypatch.setenv("STA_CONFIG", str(cfg))
    for k in ("STA_ADMIN_PATH", "STA_ADMIN_USERNAME", "STA_ADMIN_LOGIN_CAPTCHA"):
        monkeypatch.delenv(k, raising=False)
    s = get_settings()
    assert (s.admin.path, s.admin.login_captcha) == ("yaml-entry", "always")   # 这两项来自 yaml
    assert s.admin.username == ""                                              # yaml 里的 username 被无视
    monkeypatch.setenv("STA_ADMIN_PATH", "env-entry")          # .env 入口覆盖 yaml
    monkeypatch.setenv("STA_ADMIN_USERNAME", "  Boss  ")       # 账号只此一个来源,去首尾空白
    monkeypatch.setenv("STA_ADMIN_LOGIN_CAPTCHA", "OFF")
    s = get_settings()
    assert (s.admin.path, s.admin.username, s.admin.login_captcha) == ("env-entry", "Boss", "off")
    monkeypatch.setenv("STA_ADMIN_USERNAME", "off")            # off/none = 显式不要账号
    assert get_settings().admin.username == ""


@pytest.mark.parametrize("raw,want", [
    ("admin-xdd", "admin-xdd"), ("/ops_1/", "ops_1"), ("A", "A"), ("x" * 64, "x" * 64), ("admin", "admin"),
    ("", aa.DEFAULT_PATH), ("a/b", aa.DEFAULT_PATH), ("x.html", aa.DEFAULT_PATH), ("-x", aa.DEFAULT_PATH),
    ("x" * 65, aa.DEFAULT_PATH), ("管理", aa.DEFAULT_PATH), ("a b", aa.DEFAULT_PATH), ("../etc", aa.DEFAULT_PATH),
    ("api", aa.DEFAULT_PATH), ("Assets", aa.DEFAULT_PATH), ("jiufa", aa.DEFAULT_PATH), (None, aa.DEFAULT_PATH),
    # /api/ 下既有首段:配成它们会让管理接口与既有接口互相遮蔽(实测 auth → 观测台用户登录失效)
    ("auth", aa.DEFAULT_PATH), ("monitor", aa.DEFAULT_PATH), ("Version", aa.DEFAULT_PATH),
    ("live-rooms", aa.DEFAULT_PATH), ("vip", aa.DEFAULT_PATH), ("admin", "admin"),
])
def test_entry_path_validation_falls_back_loudly(monkeypatch, capsys, raw, want):
    """非法入口(多段 / 带点 / 与静态挂载同名 …)→ 回落默认并喊一声;绝不让整站起不来,
    也绝不悄悄用一个运维没写过的值。"""
    monkeypatch.setattr(settings.admin, "path", raw)
    assert aa.entry() == want
    assert aa.page_path() == "/" + want and aa.api_prefix() == "/api/" + want
    out = capsys.readouterr().out
    assert ("已回落" in out) == (want == aa.DEFAULT_PATH and str(raw or "").strip("/") != aa.DEFAULT_PATH)


def _walk_routes(routes, prefix=""):
    """展开整站路由表(兼容 FastAPI 新版把 include 的路由器保留为 _IncludedRouter 的形态)。"""
    for r in routes:
        n = type(r).__name__
        if n == "_IncludedRouter":
            yield from _walk_routes(r.original_router.routes, prefix + (r.include_context.prefix or ""))
        elif hasattr(r, "original_router"):
            yield from _walk_routes(r.original_router.routes, prefix)
        else:
            yield prefix + getattr(r, "path", "")


def test_reserved_entry_names_cover_every_existing_route():
    """★ 守卫:入口禁止名单必须覆盖实际路由表里**所有**非管理面的首段(顶层 + /api/ 下)。
    新增一个顶层路由或 /api/ 下新前缀而漏登记 → 这里红,避免有人把入口配成它而互相遮蔽。"""
    from app import web
    paths = list(_walk_routes(web.app.routes))
    assert aa.api_prefix() + "/login" in paths, "路由表展开失效(没看到管理台登录接口)"
    top, api = set(), set()
    for p in paths:
        if p in (aa.page_path(), aa.CARD_ISSUE_PATH) or p.startswith(aa.page_path() + "/") \
                or p.startswith(aa.api_prefix() + "/"):
            continue
        segs = [s for s in p.split("/") if s]
        if not segs or "{" in segs[0]:
            continue
        if segs[0] != "api":
            top.add(segs[0].lower())
        elif len(segs) > 1 and "{" not in segs[1]:
            api.add(segs[1].lower())
    assert {"auth", "monitor"} <= api      # 展开结果的健全性(静态挂载随 STA_STATIC_DIR 而定,不在此断言)
    missing = sorted((top | api) - aa._PATH_RESERVED)
    assert not missing, f"这些既有路由首段未进 admin_auth._PATH_RESERVED,入口配成它们会互相遮蔽:{missing}"


def test_deploy_scripts_reserved_lists_match_backend():
    """两份部署脚本复刻了入口校验(用于打印后台地址),禁止名单必须与后端逐项一致。"""
    sh, ps = _read("deploy-maxxiang.sh"), _read("deploy-maxxiang.ps1")
    m = re.search(r'case "\$\{v,,\}" in ([a-z|-]+)\) v="admin-xdd";; esac', sh)
    assert m, "deploy-maxxiang.sh 里没找到入口禁止名单"
    assert set(m.group(1).split("|")) == set(aa._PATH_RESERVED)
    m = re.search(r"\$reserved = @\(([^)]*)\)", ps)
    assert m, "deploy-maxxiang.ps1 里没找到入口禁止名单"
    assert set(re.findall(r"'([a-z-]+)'", m.group(1))) == set(aa._PATH_RESERVED)


# ══ B. 整站路由:新入口可达;旧地址与任何未知路径不可区分;发卡接口原址保留 ═══════════
def _site():
    from app import web
    return web.app


# 整站应用在导入时按配置挂载;下面一律取**当前生效**的入口,不写字面量 ——
# 以后改了 config.yaml 的 admin.path,这一节的用例照样成立。
PAGE, API = aa.page_path(), aa.api_prefix()


async def _sig(c, method, path, **kw):
    r = await c.request(method, path, **kw)
    return r.status_code, r.headers.get("content-type"), r.content


_OLD_API_PROBES = [("GET", "/login"), ("POST", "/login"), ("POST", "/login/ticket"), ("GET", "/session"),
                   ("POST", "/logout"), ("GET", "/schema"), ("POST", "/config/apply"), ("GET", ""),
                   ("GET", "/jfvip/cards"), ("GET", "/audit")]


async def test_old_paths_look_exactly_like_unknown_paths():
    """★ 旧入口 /admin、旁路 /admin.html、旧前缀 /api/admin/* 的应答(状态码 + 类型 + 正文)
    必须与同形态的随机未知路径逐字节相同 —— 从外面分辨不出这里曾经有过后台。"""
    if aa.entry() == "admin":
        pytest.skip("入口被配回了 admin:不存在「旧地址」一说")
    async with _client(_site()) as c:
        assert await _sig(c, "GET", "/admin") == await _sig(c, "GET", "/zq-none")
        assert await _sig(c, "GET", "/admin/") == await _sig(c, "GET", "/zq-none/")
        assert await _sig(c, "GET", "/admin.html") == await _sig(c, "GET", "/zq-none.html")
        assert await _sig(c, "GET", "/ADMIN.HTML") == await _sig(c, "GET", "/ZQ-NONE.HTML")
        for m, tail in _OLD_API_PROBES:
            kw = {"json": {"password": PW}} if m == "POST" else {}
            old, unk = await _sig(c, m, "/api/admin" + tail, **kw), await _sig(c, m, "/api/zq-none" + tail, **kw)
            assert old == unk, (m, tail, old[0], unk[0])
        # 新入口:页面 + 管理接口
        r = await c.get(PAGE)
        assert r.status_code == 200 and "九法配置中枢" in r.text and 'id="loginForm"' in r.text
        # 跨源只带源、不带路径(入口不外泄),同时不妨碍人机验证供应商按来源域名校验站点密钥
        assert r.headers["referrer-policy"] == "strict-origin-when-cross-origin"
        assert r.headers["x-frame-options"] == "DENY"
        assert "noindex" in r.headers["x-robots-tag"] and r.headers["cache-control"] == "no-cache"
        assert (await c.get(PAGE + "/")).status_code == 200            # 多敲一个斜杠也进得来
        j = (await c.get(API + "/login")).json()
        assert j["ok"] is True and j["account"] is False                  # 夹具把账号复位了
        assert (await c.get(API + "/session")).status_code == 401


async def test_old_prefix_is_not_exempt_from_user_guard_but_new_one_is(monkeypatch):
    """★ 登录系统开启时:旧前缀不再享受守卫豁免(与未知 /api/x 同样先撞会话闸 → 401),
    新前缀照常自鉴权;外部发卡接口按精确路径豁免(机器调用方没有用户会话)。"""
    monkeypatch.setattr(userauth.UA, "cfg", UserAuthCfg(host="h", port=3306, db="d", user="u",
                                                        password="p", charset="gbk"), raising=False)
    monkeypatch.setattr(userauth.UA, "pool", object(), raising=False)
    monkeypatch.setattr(userauth.UA, "redis", None, raising=False)
    assert userauth.enabled()
    async with _client(_site()) as c:
        for m, tail in _OLD_API_PROBES:
            kw = {"json": {"password": PW}} if m == "POST" else {}
            old, unk = await _sig(c, m, "/api/admin" + tail, **kw), await _sig(c, m, "/api/zq-none" + tail, **kw)
            assert old == unk and old[0] == 401, (m, tail, old[0], unk[0])
        assert (await c.get(API + "/login")).status_code == 200       # 新前缀:豁免 → 自鉴权
        assert (await c.get(API + "/session")).json()["error"] == "unauthorized"
        r = await c.post(aa.CARD_ISSUE_PATH, json={"hours": 24})              # 原址:过守卫,进发卡闸
        assert r.status_code == 503 and r.json()["error"] == "api_disabled"
    # 纯函数口径:豁免跟着入口走,不残留任何 /api/admin 前缀口子
    monkeypatch.setattr(settings.admin, "path", "ops9")
    assert userauth._exempt("/api/ops9") and userauth._exempt("/api/ops9/login")
    assert not userauth._exempt("/api/ops99/login") and not userauth._exempt(API + "/login")
    assert not userauth._exempt("/api/admin") and not userauth._exempt("/api/admin/login")
    assert userauth._exempt(aa.CARD_ISSUE_PATH) and not userauth._exempt(aa.CARD_ISSUE_PATH + "/x")
    assert not userauth._exempt("/api/admin/jfvip/cards") and userauth._exempt("/api/auth/login")


async def test_card_issue_contract_stays_at_its_original_address():
    """★ 外部发卡:原地址仍在,且与新前缀下的同一处理函数应答逐字节相同(不是另写的一份)。"""
    assert aa.CARD_ISSUE_PATH == "/api/admin/jfvip/cards/issue"
    async with _client(_site()) as c:
        a = await _sig(c, "POST", "/api/admin/jfvip/cards/issue", json={"hours": 24})
        b = await _sig(c, "POST", API + "/jfvip/cards/issue", json={"hours": 24})
        assert a == b and a[0] == 503 and b'"api_disabled"' in a[2]
        # 原址只挂了 POST(契约即如此);它「存在」这件事本身是公开文档写明的,不属于要隐藏的后台入口
        assert (await c.get("/api/admin/jfvip/cards/issue")).status_code == 405
        assert (await c.get("/api/admin/jfvip/cards")).status_code \
            == (await c.get("/api/zq-none/jfvip/cards")).status_code             # 同目录的管理端点并没有跟着留下


async def test_admin_page_disabled_is_503_and_static_bypass_is_gone(monkeypatch):
    monkeypatch.delenv("STA_ADMIN_PASSWORD", raising=False)
    aa._reset_for_tests()
    async with _client(_site()) as c:
        r = await c.get(PAGE)
        assert r.status_code == 503 and r.json()["error"] == "admin_disabled"
        assert await _sig(c, "GET", "/admin.html") == await _sig(c, "GET", "/zq-none.html")
        assert (await c.get(API + "/login")).status_code == 503
        assert (await c.post(API + "/login", json={"password": "x"})).status_code == 503


# ══ C. 账号 + 口令 ══════════════════════════════════════════════════════════════
async def test_account_and_password_are_both_required(monkeypatch):
    monkeypatch.setattr(settings.admin, "username", USER)
    async with _client(_app()) as c:
        assert (await c.get(AP + "/login")).json() == {"ok": True, "account": True, "captcha": None}
        bodies = set()
        for i, body in enumerate(({"password": PW}, {"username": "", "password": PW},
                                  {"username": "13268237006", "password": PW},
                                  {"username": USER, "password": "nope"}, {"username": USER},
                                  {"username": "x" * 5000, "password": PW})):
            r = await c.post(AP + "/login", json=body, headers=_xff(f"198.51.100.{i + 1}"))
            assert r.status_code == 401 and aa.COOKIE not in r.cookies, body
            assert r.headers["cache-control"] == "no-store"
            bodies.add(r.content)
        assert bodies == {b'{"ok":false,"error":"bad_credentials"}'}      # 哪一项错都是同一个应答
        r = await c.post(AP + "/login", json={"username": USER, "password": PW})
        j = r.json()
        assert r.status_code == 200 and j["ok"] and j["csrf"] and r.cookies.get(aa.COOKIE) == j["token"]
        assert aa.parse_session(j["token"])["sub"] == "admin"
        r2 = await c.get(AP + "/schema", headers={"X-Admin-Session": j["token"]})
        assert r2.status_code == 200


@pytest.mark.parametrize("typed", [USER, f"  {USER}  ", "１３２６８２３７００５", f"\t{USER}\n"])
async def test_account_match_is_forgiving_about_width_and_whitespace(monkeypatch, typed):
    monkeypatch.setattr(settings.admin, "username", USER)
    async with _client(_app()) as c:
        assert (await c.post(AP + "/login", json={"username": typed, "password": PW})).status_code == 200


async def test_account_match_ignores_case_but_not_content(monkeypatch):
    monkeypatch.setattr(settings.admin, "username", "Ops-Admin")
    async with _client(_app()) as c:
        for typed, code in (("ops-admin", 200), ("OPS-ADMIN", 200), ("Ops-Admin", 200),
                            ("ops_admin", 401), ("ops-admi", 401), ("ops-adminn", 401)):
            r = await c.post(AP + "/login", json={"username": typed, "password": PW}, headers=_xff("198.51.100.9"))
            assert r.status_code == code, typed


async def test_wrong_account_with_right_password_still_burns_the_failure_budget(monkeypatch):
    """猜账号也是猜:账号错 + 口令对 同样计一次失败,到上限照锁 —— 否则「口令先撞对、
    再慢慢试账号」就成了一条不设防的路。"""
    monkeypatch.setenv("STA_ADMIN_LOGIN_FAIL_IP", "3")
    monkeypatch.setattr(settings.admin, "username", USER)
    async with _client(_app()) as c:
        h = _xff("203.0.113.40")
        for i in range(3):
            assert (await c.post(AP + "/login", json={"username": f"1326823700{i}", "password": PW},
                                 headers=h)).status_code == 401
        r = await c.post(AP + "/login", json={"username": USER, "password": PW}, headers=h)
        assert r.status_code == 429 and int(r.headers["retry-after"]) > 0   # 账号口令全对也得等
        assert (await c.post(AP + "/login", json={"username": USER, "password": PW},
                             headers=_xff("203.0.113.41"))).status_code == 200


async def test_password_only_mode_when_account_not_configured():
    """未设账号 = 5.2.0 及更早的行为:只验口令,多给的 username 被忽略,登录页不显示账号框。"""
    async with _client(_app()) as c:
        assert (await c.get(AP + "/login")).json()["account"] is False
        assert (await c.post(AP + "/login", json={"password": PW})).status_code == 200
        assert (await c.post(AP + "/login", json={"username": "whoever", "password": PW})).status_code == 200
        assert (await c.post(AP + "/login", json={"username": USER, "password": "x"})).status_code == 401


def test_verify_login_always_evaluates_both_factors(monkeypatch):
    """账号错时不得跳过口令校验(否则响应耗时泄露「账号对不对」)。"""
    monkeypatch.setattr(settings.admin, "username", USER)
    seen = []
    real = aa.verify_password
    monkeypatch.setattr(aa, "verify_password", lambda p: (seen.append(p), real(p))[1])
    assert aa.verify_login("nobody", PW) is False and seen == [PW]
    assert aa.verify_login(USER, PW) is True and aa.verify_login(USER, "") is False


# ══ D. 人机验证:每次必过 · 排在验口令之前 · 不可达即拒绝 ═══════════════════════════
async def _start_siteverify():
    """本地模拟 Cloudflare siteverify(语义按官方文档:success / error-codes / action;令牌一次性)。"""
    from aiohttp import web
    seen: list = []
    used: set = set()

    async def h(req):
        f = await req.post()
        tok = str(f.get("response") or "")
        seen.append(tok)
        if f.get("secret") != "sk-test":
            return web.json_response({"success": False, "error-codes": ["invalid-input-secret"]})
        m = re.fullmatch(r"tok-([a-z]+)(?:-\w+)?", tok)
        if not m:
            return web.json_response({"success": False, "error-codes": ["invalid-input-response"]})
        if tok in used:
            return web.json_response({"success": False, "error-codes": ["timeout-or-duplicate"]})
        used.add(tok)
        return web.json_response({"success": True, "hostname": "obs.example",
                                  "action": "" if m.group(1) == "noact" else m.group(1)})
    app = web.Application()
    app.router.add_post("/siteverify", h)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]
    return runner, f"http://127.0.0.1:{port}/siteverify", seen


@pytest.fixture()
async def cap(monkeypatch):
    """站点已配 Turnstile(与注册共用)+ 管理台账号;siteverify 指向本地模拟。"""
    runner, url, seen = await _start_siteverify()
    monkeypatch.setattr(userauth, "_TURNSTILE_VERIFY_URL", url)
    userauth.UA.cfg = UserAuthCfg(reg_captcha="turnstile", reg_captcha_id="site-key",
                                  reg_captcha_key="sk-test")
    monkeypatch.setattr(settings.admin, "username", USER)
    monkeypatch.setenv("STA_ADMIN_LOGIN_RATE_PER_MIN", "1000")
    state = NS(runner=runner, url=url, seen=seen, stopped=False)
    yield state
    if not state.stopped:
        await runner.cleanup()


GOOD = {"username": USER, "password": PW}


async def test_captcha_is_required_on_every_login_even_from_a_trusted_browser(cap):
    """★「和注册一样每次都要」:第一次过了、拿到了设备信任 Cookie,第二次照样要新令牌。"""
    async with _client(_app()) as c:
        assert (await c.get(AP + "/login")).json() == {
            "ok": True, "account": True,
            "captcha": {"provider": "turnstile", "appId": "site-key", "action": "admin"}}
        r = await c.post(AP + "/login", json=GOOD)                         # 账号口令全对,没带令牌
        assert r.status_code == 400 and r.json()["error"] == "captcha_failed" and aa.COOKIE not in r.cookies
        r = await c.post(AP + "/login", json={**GOOD, "captchaToken": "tok-admin-1"})
        assert r.status_code == 200 and aa.ADM_DEV_COOKIE in r.cookies     # 成为受信设备
        r = await c.post(AP + "/login", json=GOOD)                         # 受信设备:仍然要
        assert r.status_code == 400 and r.json()["error"] == "captcha_failed"
        r = await c.post(AP + "/login", json={**GOOD, "captchaToken": "tok-admin-1"})   # 旧令牌重放
        assert r.status_code == 400
        r = await c.post(AP + "/login", json={**GOOD, "captchaToken": "tok-admin-2"})
        assert r.status_code == 200


async def test_captcha_gate_sits_in_front_of_the_password_check(cap, monkeypatch):
    """没过验证的请求连口令都碰不到:不回 401(不给「口令对不对」的信号)、不消耗失败额度。"""
    monkeypatch.setenv("STA_ADMIN_LOGIN_FAIL_IP", "3")
    calls = []
    real = aa.verify_login
    monkeypatch.setattr(aa, "verify_login", lambda u, p: (calls.append(1), real(u, p))[1])
    async with _client(_app()) as c:
        h = _xff("203.0.113.60")
        for i in range(12):                                   # 远超失败上限 3
            body = {"username": USER, "password": "wrong", "captchaToken": "" if i % 2 else "junk"}
            r = await c.post(AP + "/login", json=body, headers=h)
            assert r.status_code == 400 and r.json()["error"] == "captcha_failed"
        assert calls == []                                    # 口令一次都没验
        r = await c.post(AP + "/login", json={**GOOD, "captchaToken": "tok-admin-a"}, headers=h)
        assert r.status_code == 200                           # 额度一点没被那 12 次吃掉
        c.cookies.clear()      # 丢掉刚拿到的设备信任 Cookie:下面按「陌生浏览器」验 IP 段额度
        # 过了验证再猜错:才算失败,到 3 次照锁
        for i in range(3):
            r = await c.post(AP + "/login", json={"username": USER, "password": "wrong",
                                                  "captchaToken": f"tok-admin-b{i}"}, headers=_xff("203.0.113.61"))
            assert r.status_code == 401
        r = await c.post(AP + "/login", json={**GOOD, "captchaToken": "tok-admin-c"}, headers=_xff("203.0.113.61"))
        assert r.status_code == 429


@pytest.mark.parametrize("tok", ["tok-login", "tok-register", "tok-noact"])
async def test_tokens_minted_for_other_purposes_are_refused(cap, tok):
    """观测台注册 / 用户登录用的是同一个站点密钥;那两处的令牌(以及不带 action 的令牌)
    拿到管理台一律不认 —— 三种用途各标各的 action。"""
    async with _client(_app()) as c:
        r = await c.post(AP + "/login", json={**GOOD, "captchaToken": tok})
        assert r.status_code == 400 and r.json()["error"] == "captcha_failed"
        assert (await c.post(AP + "/login", json={**GOOD, "captchaToken": "tok-admin"})).status_code == 200


async def test_provider_unreachable_fails_closed_and_is_not_counted(cap, monkeypatch):
    """★ 验证服务不可达:拒绝登录(503),绝不降级放行 —— 哪怕账号口令全对、令牌看着也像真的;
    同时不计失败(不是管理员的错),恢复后立刻能登。"""
    monkeypatch.setenv("STA_ADMIN_LOGIN_FAIL_IP", "2")
    await cap.runner.cleanup()
    cap.stopped = True
    async with _client(_app()) as c:
        for _ in range(5):
            r = await c.post(AP + "/login", json={**GOOD, "captchaToken": "tok-admin"})
            j = r.json()
            assert r.status_code == 503 and j["error"] == "captcha_unavailable" and "应急" in j["hint"]
            assert aa.COOKIE not in r.cookies and r.headers["cache-control"] == "no-store"
        runner, url, _seen = await _start_siteverify()
        monkeypatch.setattr(userauth, "_TURNSTILE_VERIFY_URL", url)
        try:
            assert (await c.post(AP + "/login", json={**GOOD, "captchaToken": "tok-admin"})).status_code == 200
        finally:
            await runner.cleanup()


async def test_wrong_provider_secret_is_unavailable_not_user_error(cap):
    userauth.UA.cfg.reg_captcha_key = "wrong-secret"           # 运维配错:不是用户没过验证
    async with _client(_app()) as c:
        r = await c.post(AP + "/login", json={**GOOD, "captchaToken": "tok-admin"})
        assert r.status_code == 503 and r.json()["error"] == "captcha_unavailable"


async def test_captcha_modes_auto_always_off(cap, monkeypatch):
    async with _client(_app()) as c:
        # off:明确不要
        monkeypatch.setattr(settings.admin, "login_captcha", "off")
        assert (await c.get(AP + "/login")).json()["captcha"] is None
        assert (await c.post(AP + "/login", json=GOOD)).status_code == 200
        assert cap.seen == []                                          # 一次都没问过供应商
        # auto + 供应商凭据不全:不拦人(启动横幅告警),登录只验账号口令
        monkeypatch.setattr(settings.admin, "login_captcha", "auto")
        userauth.UA.cfg.reg_captcha_key = ""
        assert (await c.get(AP + "/login")).json()["captcha"] is None
        assert (await c.post(AP + "/login", json=GOOD)).status_code == 200
        # always + 没配好:拒绝网页登录(只能走应急链接),登录页被明确告知
        monkeypatch.setattr(settings.admin, "login_captcha", "always")
        assert (await c.get(AP + "/login")).json()["captcha"] == {
            "provider": "", "appId": "", "action": "admin", "unavailable": True}
        r = await c.post(AP + "/login", json={**GOOD, "captchaToken": "tok-admin"})
        assert r.status_code == 503 and r.json()["error"] == "captcha_unavailable"
        userauth.UA.cfg.reg_captcha = "off"
        assert (await c.post(AP + "/login", json=GOOD)).status_code == 503
        # 未知档位按 auto
        monkeypatch.setattr(settings.admin, "login_captcha", "whatever")
        assert aa.captcha_mode() == "auto"


async def test_registration_switch_does_not_turn_admin_captcha_off(cap):
    """STA_USER_REG_CAPTCHA_REQUIRED=0(注册不要验证码)只管注册;供应商还在,管理台照样要。"""
    userauth.UA.cfg.reg_captcha_required = False
    assert userauth._cap_conf("reg")["provider"] == "off"
    async with _client(_app()) as c:
        assert (await c.get(AP + "/login")).json()["captcha"]["provider"] == "turnstile"
        assert (await c.post(AP + "/login", json=GOOD)).status_code == 400


async def test_admin_captcha_works_without_the_login_system_initialised(monkeypatch):
    """登录系统没初始化(UA.cfg 为空)时,管理台的人机验证配置直接取全局 settings.userauth。"""
    userauth.UA.cfg = None
    assert userauth._cap_conf("login")["provider"] == "off"            # 既有口径不变
    monkeypatch.setattr(settings.userauth, "reg_captcha", "turnstile")
    monkeypatch.setattr(settings.userauth, "reg_captcha_id", "sk-global")
    monkeypatch.setattr(settings.userauth, "reg_captcha_key", "secret")
    assert userauth._cap_conf("admin") == {"provider": "turnstile", "id": "sk-global", "key": "secret",
                                           "secret_id": "", "secret_key": ""}
    assert admin_api._adm_cap()["need"] is True


async def test_captcha_failures_are_audited_once_per_source_not_per_request(cap, monkeypatch):
    rows = []

    class _DB:
        async def audit_add(self, ts, actor, action, detail, rev):
            rows.append((actor, action))
    monkeypatch.setattr(admin_api, "_ST", NS(db=_DB()), raising=False)
    async with _client(_app()) as c:
        for _ in range(8):
            await c.post(AP + "/login", json={**GOOD, "captchaToken": "junk"}, headers=_xff("203.0.113.80"))
        await c.post(AP + "/login", json={**GOOD, "captchaToken": "junk"}, headers=_xff("203.0.113.81"))
    assert collections.Counter(a for _x, a in rows) == {"login_captcha_fail": 2}


# ══ E. 应急登录票据:服务器签发 · 短时 · 一次性 ═══════════════════════════════════
async def test_ticket_login_is_the_way_in_when_captcha_is_down(cap):
    """★ 验证服务挂了,网页登录被拒(fail-closed)—— 应急票据照常进门,发的是正常会话。"""
    await cap.runner.cleanup()
    cap.stopped = True
    async with _client(_app()) as c:
        assert (await c.post(AP + "/login", json={**GOOD, "captchaToken": "tok-admin"})).status_code == 503
        t = aa.issue_ticket()
        r = await c.post(AP + "/login/ticket", json={"ticket": t})
        j = r.json()
        assert r.status_code == 200 and j["ok"] and r.cookies.get(aa.COOKIE) == j["token"]
        assert r.headers["cache-control"] == "no-store"
        assert aa.parse_session(j["token"])["exp"] - time.time() > 29 * 86400     # 与正常登录同寿命
        assert (await c.get(AP + "/session", headers={"X-Admin-Session": j["token"]})).status_code == 200
        r = await c.post(AP + "/login/ticket", json={"ticket": t})                # 重放:一次性
        assert r.status_code == 401 and r.json()["error"] == "bad_ticket"


async def test_bad_tickets_are_rejected_and_only_charged_to_their_own_source(monkeypatch):
    monkeypatch.setenv("STA_ADMIN_LOGIN_FAIL_IP", "4")
    monkeypatch.setenv("STA_ADMIN_LOGIN_FAIL_GLOBAL", "3")
    sess, _csrf = aa.issue_session()
    good = aa.issue_ticket()
    p64, sig = good.split(".", 1)
    forged = p64 + "." + sig[:-1] + ("0" if sig[-1] != "0" else "1")       # 签名被改
    async with _client(_app()) as c:
        h = _xff("203.0.113.90")
        for bad in ("", "garbage", sess,                          # 会话令牌不能当票据用
                    aa.issue_ticket(-5)):                         # 已过期
            r = await c.post(AP + "/login/ticket", json={"ticket": bad}, headers=h)
            assert r.status_code == 401 and r.json()["error"] == "bad_ticket", bad[:12]
        r = await c.post(AP + "/login/ticket", json={"ticket": forged}, headers=h)
        assert r.status_code == 429 and int(r.headers["retry-after"]) > 0     # 该来源坏票据到上限
        # 坏票据只记在递它的来源头上:别的来源、以及口令登录的全站额度(3)都没被它吃掉
        for i in range(6):
            r = await c.post(AP + "/login/ticket", json={"ticket": forged}, headers=_xff(f"198.51.100.{i + 1}"))
            assert r.status_code == 401
        for i in range(3):
            assert (await c.post(AP + "/login", json={"password": "x"},
                                 headers=_xff(f"192.0.2.{i + 1}"))).status_code == 401
        assert (await c.post(AP + "/login", json={"password": "x"}, headers=_xff("192.0.2.9"))).status_code == 429
        c.cookies.clear()
        # ★ 此刻:全站失败额度已顶满(陌生设备口令登录一律 429),203.0.113.90 自己的坏票据也到了上限 ——
        #   握着**有效**票据的管理员照样进得来(应急通道不能被「把额度顶满」这一招堵死)
        assert (await c.post(AP + "/login", json={"password": PW}, headers=h)).status_code == 429
        r = await c.post(AP + "/login/ticket", json={"ticket": good}, headers=h)
        assert r.status_code == 200 and r.json()["token"]
        r = await c.post(AP + "/login/ticket", json={"ticket": good}, headers=_xff("198.51.100.77"))
        assert r.status_code == 401 and r.json()["error"] == "bad_ticket"     # 用过即作废
    assert aa.parse_session(good) is None                         # 票据不能当会话用
    assert aa.parse_ticket(sess) is None
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "another-pw")        # 换了口令:旧票据一并作废
    aa._reset_for_tests()
    assert aa.parse_ticket(aa.issue_ticket()) is not None and aa.parse_ticket(good) is None


async def test_ticket_failures_are_audited_but_bounded(monkeypatch):
    monkeypatch.setenv("STA_ADMIN_LOGIN_FAIL_IP", "3")
    rows = []

    class _DB:
        async def audit_add(self, ts, actor, action, detail, rev):
            rows.append((action, detail.get("why")))
    monkeypatch.setattr(admin_api, "_ST", NS(db=_DB()), raising=False)
    t = aa.issue_ticket()
    async with _client(_app()) as c:
        assert (await c.post(AP + "/login/ticket", json={"ticket": t})).status_code == 200
        for _ in range(9):
            await c.post(AP + "/login/ticket", json={"ticket": t}, headers=_xff("203.0.113.95"))
        await c.post(AP + "/login/ticket", json={"ticket": "junk"}, headers=_xff("203.0.113.96"))
    # 每来源每窗口只落 1 行(坏票据不占全站失败额度 —— 若逐条落库,分布式请求就能把审计表写爆)
    assert collections.Counter(rows) == {("login_ticket", None): 1, ("login_ticket_fail", "replayed"): 1,
                                         ("login_ticket_fail", "invalid"): 1}


async def test_unauthenticated_audit_rows_are_capped_globally(cap, monkeypatch):
    """★ 人机验证未过 / 坏票据都不消耗全站失败额度;来自大量不同来源时,审计行数也必须封顶。"""
    rows = []

    class _DB:
        async def audit_add(self, ts, actor, action, detail, rev):
            rows.append(action)
    monkeypatch.setattr(admin_api, "_ST", NS(db=_DB()), raising=False)
    monkeypatch.setattr(admin_api, "_ADM_AUDIT_CAP_G", 3)
    async with _client(_app()) as c:
        for i in range(8):
            h = _xff(f"198.51.{100 + i}.7")                      # 8 个不同的 IP 段
            await c.post(AP + "/login", json={**GOOD, "captchaToken": "junk"}, headers=h)
            await c.post(AP + "/login/ticket", json={"ticket": "junk"}, headers=h)
    assert collections.Counter(rows) == {"login_captcha_fail": 3, "login_ticket_fail": 3}


def test_admin_surface_is_not_listed_in_openapi():
    """★ 运维打开 STA_API_DOCS 时,/openapi.json 不得列出后台入口与管理接口(否则入口改名白做);
    外部发卡接口是公开契约,照常在文档里。"""
    from app import web
    paths = set(web.app.openapi()["paths"])
    assert not [p for p in paths if p == aa.page_path() or p.startswith(aa.page_path() + "/")
                or p.startswith(aa.api_prefix() + "/")], sorted(paths)[:5]
    assert aa.CARD_ISSUE_PATH in paths


async def test_ticket_ttl_is_short_and_capped():
    now = time.time()
    assert 590 <= aa.parse_ticket(aa.issue_ticket())["exp"] - now <= 601          # 默认 10 分钟
    assert aa.parse_ticket(aa.issue_ticket(10 ** 9))["exp"] - now <= aa.TICKET_MAX_TTL_S + 1


def test_cli_prints_entry_path_and_a_working_link(monkeypatch):
    """`python -m app.admin_auth link` —— 部署脚本的 admin-link 子命令就是包了它一层。"""
    env = {**os.environ, "STA_ADMIN_PASSWORD": PW, "PYTHONIOENCODING": "utf-8"}
    for k in ("STA_ADMIN_PATH", "STA_ADMIN_USERNAME", "STA_CONFIG", "STA_ADMIN_PASSWORD_HASH", "STA_ADMIN_SECRET"):
        env.pop(k, None)
    for k in ("STA_ADMIN_PATH", "STA_ADMIN_USERNAME", "STA_CONFIG"):
        monkeypatch.delenv(k, raising=False)
    cwd = os.path.join(ROOT, "backend_async")
    run = lambda *a, e=env: subprocess.run([sys.executable, "-m", "app.admin_auth", *a], cwd=cwd, env=e,  # noqa: E731
                                           capture_output=True, text=True, encoding="utf-8", timeout=60)
    entry = get_settings().admin.path           # 当前发货配置里的入口(同一份 config.yaml)
    assert run("path").stdout.strip() == "/" + entry
    p = run("link", "--base", "http://203.0.113.7:5173/", "--minutes", "5")
    url = p.stdout.strip()
    assert p.returncode == 0 and "\n" not in url and "只能使用一次" in p.stderr
    m = re.fullmatch(r"http://203\.0\.113\.7:5173/" + re.escape(entry) + r"#t=([A-Za-z0-9_.-]+)", url)
    assert m, url
    t = aa.parse_ticket(m.group(1))                               # 同一口令材料 → 本进程验得过
    assert t and 290 <= t["exp"] - time.time() <= 301
    assert aa.parse_ticket(run("ticket").stdout.strip()) is not None
    e2 = dict(env)
    e2.pop("STA_ADMIN_PASSWORD")
    p = run("link", e=e2)
    assert p.returncode == 2 and p.stdout.strip() == "" and "未启用" in p.stderr
    assert run("hash", "x").stdout.startswith("pbkdf2_sha256$")


# ══ F. 限速与 Redis 故障:不放开,也不锁人 ══════════════════════════════════════════
async def test_request_rate_cap_holds_without_redis(monkeypatch):
    monkeypatch.setenv("STA_ADMIN_LOGIN_RATE_PER_MIN", "4")
    monkeypatch.setenv("STA_ADMIN_LOGIN_FAIL_IP", "1000")
    monkeypatch.setenv("STA_ADMIN_LOGIN_FAIL_GLOBAL", "1000")
    async with _client(_app()) as c:
        h = _xff("203.0.113.100")
        st = [(await c.post(AP + "/login", json={"password": "x"}, headers=h)) for _ in range(7)]
        assert [r.status_code for r in st] == [401] * 4 + [429] * 3
        j = st[-1].json()
        assert j["error"] == "rate_limited" and 0 < int(st[-1].headers["retry-after"]) <= 60 and j["retryAfter"] > 0
        assert (await c.post(AP + "/login", json={"password": PW}, headers=h)).status_code == 429   # 对的也得等
        assert (await c.post(AP + "/login", json={"password": PW},
                             headers=_xff("203.0.113.101"))).status_code == 200                   # 按 IP 段分桶
        assert (await c.get(AP + "/login", headers=h)).status_code == 200                         # 只限登录请求


class _DeadRedis:
    """连不上的 Redis:任何命令都抛连接错误(等价于基线实测里被停掉的那台)。"""
    def __getattr__(self, name):
        async def _boom(*a, **k):
            from redis.exceptions import ConnectionError as RCE
            raise RCE("Error 111 connecting to 127.0.0.1:6380. Connection refused.")
        return _boom


async def test_redis_outage_neither_locks_the_admin_out_nor_opens_the_gate(monkeypatch):
    """★ 基线实测:停掉 Redis 后用正确口令登录 → 3.17s 后 429(管理员自己也进不去)。
    现在:Redis 不可用退化进程内计数 —— 正确口令照常秒进;失败上限照常生效(绝不放开)。"""
    monkeypatch.setattr(admin_api, "_ST", NS(bus=NS(r=_DeadRedis()), db=None), raising=False)
    monkeypatch.setenv("STA_ADMIN_LOGIN_FAIL_IP", "5")
    async with _client(_app()) as c:
        t0 = time.monotonic()
        r = await c.post(AP + "/login", json={"password": PW})
        assert r.status_code == 200 and time.monotonic() - t0 < 1.0
        c.cookies.clear()      # 以陌生浏览器的身份验失败上限(受信设备另有一份自己的额度)
        h = _xff("203.0.113.110")
        rs = await asyncio.gather(*[c.post(AP + "/login", json={"password": f"x{i}"}, headers=h) for i in range(12)])
        assert collections.Counter(x.status_code for x in rs) == {401: 5, 429: 7}
        assert (await c.post(AP + "/login", json={"password": PW}, headers=h)).status_code == 429
        t = aa.issue_ticket()                                    # 票据一次性在 Redis 不可用时同样成立
        assert (await c.post(AP + "/login/ticket", json={"ticket": t})).status_code == 200
        assert (await c.post(AP + "/login/ticket", json={"ticket": t})).status_code == 401


# ══ G. 请求形态:同源 + 只收 JSON;设备 Cookie 作用域跟随挂载点 ═════════════════════
async def test_login_rejects_cross_origin_and_non_json_posts():
    async with _client(_app()) as c:
        r = await c.post(AP + "/login", json={"password": PW}, headers={"Origin": "https://evil.example"})
        assert r.status_code == 403 and r.json()["error"] == "bad_origin"
        r = await c.post(AP + "/login", content='{"password":"%s"}' % PW, headers={"Content-Type": "text/plain"})
        assert r.status_code == 415
        r = await c.post(AP + "/login/ticket", content='{"ticket":"x"}', headers={"Content-Type": "text/plain"})
        assert r.status_code == 415
        assert (await c.post(AP + "/login", json={"password": PW},
                             headers={"Origin": "http://adm.example"})).status_code == 200        # 同源照常
        assert (await c.post(AP + "/login", json=[PW])).status_code == 401                        # 非对象体:不 500


@pytest.mark.parametrize("prefix", ["/api/admin", "/api/admin-xdd", "/api/Ops_9"])
async def test_device_cookie_scope_follows_the_mount_point(prefix):
    async with _client(_app(prefix)) as c:
        r = await c.post(prefix + "/login", json={"password": PW})
        dev = [x for x in r.headers.get_list("set-cookie") if x.startswith(aa.ADM_DEV_COOKIE + "=")]
        assert r.status_code == 200 and dev and f"path={prefix}/;".lower() in dev[0].lower() + ";"
        r = await c.post(prefix + "/login/ticket", json={"ticket": aa.issue_ticket()})
        dev = [x for x in r.headers.get_list("set-cookie") if x.startswith(aa.ADM_DEV_COOKIE + "=")]
        assert r.status_code == 200 and f"path={prefix}/;".lower() in dev[0].lower() + ";"


async def test_ip_allowlist_still_guards_every_login_surface(monkeypatch):
    monkeypatch.setenv("STA_ADMIN_IP_ALLOW", "10.0.0.0/8")
    async with _client(_app()) as c:
        h = _xff("203.0.113.5")
        assert (await c.get(AP + "/login", headers=h)).status_code == 403
        assert (await c.post(AP + "/login", json={"password": PW}, headers=h)).status_code == 403
        assert (await c.post(AP + "/login/ticket", json={"ticket": aa.issue_ticket()}, headers=h)).status_code == 403
        assert (await c.post(AP + "/login", json={"password": PW}, headers=_xff("10.9.8.7"))).status_code == 200


# ══ H. 前端与文档的静态守卫 ═════════════════════════════════════════════════════
def _read(rel: str) -> str:
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()


def test_frontend_derives_api_prefix_from_page_address_and_leaks_no_path():
    """admin.js 是公开可取的静态资源:里面不能有任何一份后台路径(旧的、新的都不行),
    API 前缀只能从页面自己的地址推出。"""
    js, html = _read("assets/admin.js"), _read("admin.html")
    for needle in ("/api/admin", "admin-xdd", USER):
        assert needle not in js, f"admin.js 里出现了 {needle!r}"
        assert needle not in html, f"admin.html 里出现了 {needle!r}"
    assert "location.pathname" in js and "const API_BASE" in js
    assert js.count("fetch(API_BASE") >= 5                       # api() / 导出 / 登录信息 / 登录 / 应急票据
    assert "fetch('/api/" not in js.replace("fetch('/api/monitor", "")   # 名录接口不属管理面,保留
    for frag in ('id="loginForm"', 'id="un"', 'autocomplete="username"', 'id="pw"',
                 'autocomplete="current-password"', 'id="capBox"', 'id="loginBtn"', 'id="loginMsg"'):
        assert frag in html, frag
    assert html.index('id="un"') < html.index('id="pw"') < html.index('id="capBox"') < html.index('id="loginBtn"')
    assert f"admin.js?v={admin_api.ADMIN_VERSION}" in html and f"admin.css?v={admin_api.ADMIN_VERSION}" in html
    for frag in ("action: conf.action || 'admin'", "'/login/ticket'", "#t=", "capReset()"):
        assert frag in js, frag


def test_account_is_not_baked_into_config_yaml():
    """账号是凭据,不该出现在随代码分发的 config.yaml 里(入口 path 可以,它不是秘密)。"""
    import pathlib
    import re
    y = (pathlib.Path(__file__).resolve().parent.parent / "config.yaml").read_text(encoding="utf-8")
    assert not re.search(r"^\s*username:", y, re.M), "config.yaml 不应含 admin.username 键 —— 账号只走 STA_ADMIN_USERNAME"
    assert "13268237005" not in y             # 账号值不随代码分发
    assert 'path: "admin-xdd"' in y           # 入口留在 config.yaml 是刻意的(它是访问拓扑,不是秘密)


def test_static_fallback_never_serves_admin_html_and_guard_has_no_hardcoded_prefix():
    web_src, ua_src = _read("backend_async/app/web.py"), _read("backend_async/app/userauth.py")
    assert 'os.path.basename(candidate).lower() != "admin.html"' in web_src
    assert "include_router(admin_api.router, prefix=_ADMIN_API, include_in_schema=False)" in web_src
    assert '@app.get("/admin")' not in web_src
    assert '"/api/admin/"' not in ua_src and '"/api/admin"' not in ua_src
    api_src = _read("backend_async/app/admin_api.py")
    assert "router = APIRouter()" in api_src and 'APIRouter(prefix=' not in api_src
    assert "TokenBucket" not in api_src.split('"""', 2)[2].replace("TokenBucket 对连接错误", "")
