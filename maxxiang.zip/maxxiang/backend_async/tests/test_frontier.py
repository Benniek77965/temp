"""
test_frontier.py — 天花板前沿调度(explore_style="frontier")的契约与不变量
================================================================================
守的是四类东西：
  ① **关闭时零影响**：不改 explore_style 时，引擎行为与本次改造前逐字节等价；
  ② **规划器正确性**：纯 Python 单纯形解出的 LP 必须真的满足约束，且不可行时
     按既定顺序自动放宽而不是抛异常把 predict() 打崩；
  ③ **调度器硬不变量**：确定性（同输入同输出）、份额跟踪误差 < 1 局、
     状态可往返序列化 —— 这三条是"可回测/可对拍"的地基；
  ④ **倍率推导一致性**：fr_mult 留空时由妖兽表推导；部署若改过 custom_beast_ids
     而没同批显式填 fr_mult，这里当场红 —— 与 test_showcase_rotate 的同名纪律一致。

另外钉一条**诚实性守卫**：frontier 的 why 落款里不得出现任何暗示择时能力的措辞。
数据实测证明该过程与 i.i.d. 不可区分（21 项规律检验 p<0.05 者 0 项），任何
"信号超门槛/间隔命中率"式的文案在这里都是**事实性错误**，不是风格问题。
"""
from __future__ import annotations

import json
import os
import random
import sys

import pytest
import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ENGINE = os.path.join(ROOT, "jiufa_data")
if ENGINE not in sys.path:
    sys.path.insert(0, ENGINE)
os.environ.setdefault("STA_ENGINE_DIR", ENGINE)

frontier_planner = pytest.importorskip("frontier_planner")
import spell_tamer_monitor as E                       # noqa: E402

from app.predictor_bridge import PredictorBridge      # noqa: E402

FP = frontier_planner
MULT = {1: 10, 2: 50, 3: 330, 4: 250, 5: 100, 6: 100, 7: 50, 8: 50, 9: 500}
# 真机实测边缘分布（三房 7 天 36,278 局）——用作规划器的固定测试输入
P_REAL = [0.18375, 0.15695, 0.04929, 0.06525, 0.09331,
          0.09673, 0.15720, 0.16192, 0.03561]


def _cfg(**over):
    with open(os.path.join(ROOT, "backend_async", "config.yaml"), encoding="utf-8") as f:
        c = dict(yaml.safe_load(f)["prediction"])
    c.update(over)
    return c


def _seq(n=2500, seed=7):
    rng = random.Random(seed)
    return [rng.choices(range(1, 10), weights=[p * 1000 for p in P_REAL])[0]
            for _ in range(n)]


# ═══════════ ① 关闭时零影响 ═══════════

def test_default_style_is_the_audited_choice():
    """默认 explore_style 必须等于**经真机 A/B 审计定下的那个值**，改动需连带改本测试。

    4.9.7 起默认改回 "showcase"。

    先纠正 4.9.0 那次改动写在这里的依据 —— 它把两件事混用了：55.13% 是**线性规划
    天花板**（在 showcase 自身的冷门/稀有/回报约束水平下求解），不是出厂 frontier
    的实测值；而 53.67% 那一档对应的是 4.8.9 的聚合下限口径
    （fr_cold_min/fr_rare_min/fr_ret_min），不是 4.9.0 落地的逐号份额地板口径。
    按出厂刻度 fr_share_floors="3:0.40,9:0.30,4:0.20,5:0.20,6:0.20" 复测，
    三房 36,182 配对局：frontier 总命中 53.15% vs showcase 53.71%
    〔**4.9.7 复查更正**：本句原续写「McNemar b/c=7539/6292，p=3.2e-26，showcase 更优」——
      该对数字**与本句自己的命中率算术矛盾**：命中率差 0.56pp × 36,182 = 202 局，
      而配对检验里 b−c 必须**等于**这个差值，7539−6292=1247 差了 6 倍。
      用生产代码路径三房全量独立复跑（window_audit 口径，脚本见本轮复查记录）：
          showcase  总命中 53.74%  主中 30.22%  冷门 11.50%  稀有 1.625%  回报 8.2365
          frontier  总命中 53.15%  主中 32.25%  冷门  8.44%  稀有 3.118%  回报 8.9743
          McNemar   b=7146 c=6934  z=+1.79  **p=0.074 —— 总命中无显著差异**
      口径说明：回报 = 每局 (命中时 倍率[实际]/4，未命中 0) 的均值，与 config.yaml
      `fr_ret_min` 的 Σp·倍率/4 同量纲。**复核可信度**：frontier 一侧的
      总命中 53.15% / 稀有 3.118% / 回报 8.9743 三项与本仓库既有记录**逐位吻合**，
      showcase 一侧各项差 0.03~0.09pp（该侧含 4.9.7 新开的冷位节拍器，原记录不含）。
      两侧命中率均复现，b−c=212 与命中率差 213 局自洽 ⇒ 对不上的是原文那对 b/c。
      **诚实结论**：showcase 在总命中上只是 +0.59pp 的点估计，**统计上分辨不出**；
      真正的差别在次要指标，且是**双向**的 —— showcase 冷门 +3.06pp，
      frontier 主中 +2.03pp、稀有 +1.49pp、四码回报 +9.0%。
      ⚠ 其中**主中率是前端唯一渲染的两个指标之一**（config.yaml 有据），
      即切到 showcase 会让用户可见的主中率下降约 2pp —— 这条代价不得隐去。
      那么为什么默认仍取 showcase？依据不再是「总命中更优」（那条不成立），
      而是下面 ① ② 两条**结构性**理由，外加引擎 dataclass 出厂即 showcase。
      若产品口径更看重主中率/稀有/回报，改回 "frontier" 是有据可依的选择，
      改时同批把本断言与 config.yaml explore_style 段一并改回。〕
    即出厂 frontier 并未帕累托支配 showcase（这一条仍成立：冷门一项 showcase 更好）。

    改回的另外两条依据：
      ① frontier 下 anti_stubborn / showcase_rotate / repeat_guard 及 as_*/sc_*/rg_*
         全组硬失效（见 predictor_bridge._DEAD_SWITCH_KEYS），可调面从数十个塌成
         5 个 fr_*；
      ② 行为多样性 showcase 121 组合 / 5.56 bit / 同四码 7.2%，
         frontier 34 组合 / 3.96 bit / 2.9%。

    代价（诚实记录，不粉饰）：稀有命中 3.118→1.669%、四码倍率加权回报
    8.974→8.292（−7.6%）。frontier 的这部分优势全部来自 3 号(+18.5pp) 与
    9 号(+13.4pp)，代价付在 1 号(−15.8pp) 与 7 号(−7.7pp)；5/6 两号两者统计上
    无差异（p=0.553 / 0.471）。

    回滚 = config.yaml 改回 "showcase" 且 fr_share_floors 改回出厂串。
    〔**4.9.8 更正**：默认改为 "frontier"，但与 4.9.0 那次**不是同一个东西** ——
      本次同批把 fr_share_floors 清空、改用三条聚合下限。上面那组 53.15% vs 53.71%
      是**带出厂逐号地板**测的（该地板硬钉号9 进 30%、号3 进 40%），不适用于本配置。
      清空地板后三房 36,182 配对局实测（vs 切换前 showcase）：
          总命中 53.737 → 54.746（**+1.009pp**，McNemar p=0.0020，时间二分 6/6 段全正，
                                  段级 t=+3.82 —— 全程唯一又大又稳的一项）
          主中   30.222 → 31.911（+1.689pp，段级 t=+19.3）
          冷门   11.497 → 11.644（+0.147pp，6 段中 3 段为正，t=+0.85 —— 最脆的一项）
          稀有    1.625 →  1.805（+0.180pp，段级 t=+2.06）
          回报   8.2365 → 8.3985（+1.97%）
      ⇒ 五项无一为负，符合 config.yaml fr_* 段既有的定标判据「四项全不劣于现行 showcase」。

      ★ 定稿的决定性依据是**严格样本外协议**（前 2/3 选优 → 后 1/3 验证，20 个候选刻度）。
        验证段（n=12,062，选优时从未看过）只有本刻度仍满足四项全不劣：
            本刻度 0.116633/0.01683/8.358387  命中+1.086 冷门+0.091 稀有+0.108 回报+0.71%  ✔
            0.1191/0.01849/8.46125（一步反解） 命中+0.075 冷门−0.041 回报−0.76%           ✘
            δ=0 0.11613/0.01732/8.2769（训练段第一名） 命中+0.000 冷门−0.531 回报−5.21%   ✘
        20 个候选按命中的训练段/验证段排名 Kendall tau 仅 +0.400 ⇒ 多数候选符号翻转。
        **不做样本外就选，选到的必然是训练段噪声高点** —— δ=0 就是活例：训练段命中
        +1.393pp 排第一，验证段归零、冷门 −0.531pp、回报 −5.21%。

      泄漏检查：只用训练段 2/3 重算反解刻度得 0.115154/0.016436/8.272775，与本刻度
      相差 −1.0%~−2.3% ⇒ 本刻度可在不触碰验证段的前提下复现，选择偏差不实质影响结论。

      诚实边界：逐房×逐段 6 格中 4 格过「四项全不劣」，两处不过都出在房 2678075 的冷门
      （训练 −0.062pp / 验证 −0.423pp）。可主张「不劣」，不可宣传「更准」。
      迭代不收敛：第 3 步反解会漂到 0.115166/0.015155/8.203207（ret 已低于基线 8.2365）——
      LP 会在顶点间跳，target→realized 不是压缩映射，「精确不动点」不存在。

      邻域稳健性：fr_ret_min 在 8.150~8.400 全区间总命中均高于 showcase
      （+0.937/+0.929/+0.412pp）⇒ 本组刻度不是噪声尖峰。〕
    """
    assert _cfg()["explore_style"] == "frontier"


def test_showcase_is_still_reachable_and_untouched_by_frontier_fields():
    """showcase 分支必须仍可用，且 fr_* 字段存在与否都不影响它的输出。

    注意显式钉死 explore_style="showcase" —— 原版依赖"默认就是 showcase"，
    4.9.0 翻默认后那种写法会静默变成在测 frontier（本测试因此曾误红）。
    """
    seq = _seq()
    a = PredictorBridge(_cfg(explore_style="showcase"), {}).run_prediction("r", seq, {})[0]
    stripped = {k: v for k, v in _cfg(explore_style="showcase").items()
                if not k.startswith("fr_")}
    b = PredictorBridge(stripped, {}).run_prediction("r", seq, {})[0]
    assert a["main"] + a["guard"] == b["main"] + b["guard"]


# ═══════════ ② 规划器正确性 ═══════════

@pytest.mark.parametrize("kw", [
    {},
    {"cold_min": 0.1232},
    {"cold_min": 0.1232, "rare_min": 0.0180, "ret_min": 8.624},
    {"rare_min": 0.035, "share_min": 0.08},
    {"cold_min": 0.15, "ret_min": 7.5},
])
def test_plan_satisfies_its_own_constraints(kw):
    mix, diag = FP.plan(P_REAL, MULT, (3, 4, 5, 6, 9), (3, 9), relax=False, **kw)
    assert abs(sum(mix.values()) - 1.0) < 1e-9
    assert all(v >= 0 for v in mix.values())
    if "cold_min" in kw:
        assert diag["cold"] >= kw["cold_min"] - 1e-9
    if "rare_min" in kw:
        assert diag["rare"] >= kw["rare_min"] - 1e-9
    if "ret_min" in kw:
        assert diag["ret"] >= kw["ret_min"] - 1e-6


def test_plan_unconstrained_is_the_frequency_top4():
    """无约束时最优必然是频率最高的四只 —— 这是天花板的锚点，锚错则整套失真。"""
    mix, diag = FP.plan(P_REAL, MULT, (3, 4, 5, 6, 9), (3, 9))
    assert list(mix) == [(1, 2, 7, 8)]
    assert abs(diag["hit"] - sum(sorted(P_REAL)[-4:])) < 1e-9


def test_plan_relaxes_instead_of_crashing():
    """约束越界（手改 config.yaml 完全可能）必须自动放宽而不是把 predict() 打崩。"""
    mix, diag = FP.plan(P_REAL, MULT, (3, 4, 5, 6, 9), (3, 9),
                        cold_min=0.9, rare_min=0.9, ret_min=999.0)
    assert diag["relaxed"], "应记录被放宽的约束"
    assert abs(sum(mix.values()) - 1.0) < 1e-9


def test_plan_mixture_beats_best_single_set():
    """混合相对最优单集合的增量是调度器存在的**唯一**理由；退化了就该删掉它。"""
    cov, cld, rar, ev = FP.set_metrics(P_REAL, MULT, (3, 4, 5, 6, 9), (3, 9))
    mix, diag = FP.plan(P_REAL, MULT, (3, 4, 5, 6, 9), (3, 9),
                        cold_min=0.1232, rare_min=0.0180, ret_min=8.624)
    ok = [cov[i] for i in range(len(FP.ALL_SETS))
          if cld[i] >= 0.1232 - 1e-12 and rar[i] >= 0.0180 - 1e-12
          and ev[i] >= 8.624 - 1e-9]
    best_single = max(ok) if ok else 0.0
    assert diag["hit"] > best_single + 0.02, (
        f"混合 {diag['hit']:.4f} 对最优单集合 {best_single:.4f} 的增量不足 2pp，"
        "调度器已无存在价值")


def test_simplex_matches_textbook_optima():
    """自带单纯形的两条独立校验（含需要两阶段法的负 b）。"""
    x = FP._simplex([3, 2], [[1, 1], [1, 3], [1, 0]], [4, 6, 3])
    assert abs(3 * x[0] + 2 * x[1] - 11.0) < 1e-9
    x = FP._simplex([1, 1], [[-1, -1], [1, 0], [0, 1]], [-2, 3, 3])
    assert abs(x[0] + x[1] - 6.0) < 1e-9


# ═══════════ ③ 调度器硬不变量 ═══════════

def _mix():
    return FP.plan(P_REAL, MULT, (3, 4, 5, 6, 9), (3, 9),
                   cold_min=0.1232, rare_min=0.0180, ret_min=8.624)[0]


def test_scheduler_is_deterministic():
    m = _mix()
    a = [FP.Scheduler(m).next() for _ in range(1)]        # 同起点
    s1, s2 = FP.Scheduler(m), FP.Scheduler(m)
    assert [s1.next() for _ in range(5000)] == [s2.next() for _ in range(5000)]
    assert a


def test_scheduler_share_tracking_within_one_round():
    """Bresenham 不变量：任一成分的实际份额与目标份额偏差恒 < 1 局。"""
    m = _mix()
    s = FP.Scheduler(m)
    n = 20000
    picks = [s.next() for _ in range(n)]
    for k, w in m.items():
        assert abs(picks.count(k) - w * n) < 1.0 + 1e-6, (k, w)


def test_scheduler_state_roundtrip():
    m = _mix()
    s = FP.Scheduler(m)
    for _ in range(37):
        s.next()
    back = FP.Scheduler.load(s.dump())
    assert set(back) == set(s.debt)
    assert all(abs(back[k] - s.debt[k]) < 1e-5 for k in s.debt)


def test_scheduler_never_repeats_forever():
    """必须真的轮换 —— 这是本次改造的产品诉求（原 showcase 曾连推同四码 14 局）。"""
    m = _mix()
    s = FP.Scheduler(m)
    picks = [s.next() for _ in range(5000)]
    run = mx = 1
    for a, b in zip(picks[:-1], picks[1:]):
        run = run + 1 if a == b else 1
        mx = max(mx, run)
    assert mx <= 5, f"同四码连推 {mx} 局"
    assert len(set(picks)) >= 2


# ═══════════ ④ 倍率推导一致性 ═══════════

def test_multiplier_table_matches_deployment_beast_ids():
    """fr_mult 留空时由妖兽表推导；部署改过 custom_beast_ids 就必须同批显式填。"""
    with open(os.path.join(ROOT, "backend_async", "config.yaml"), encoding="utf-8") as f:
        full = yaml.safe_load(f)
    ids = full.get("custom_beast_ids") or {}
    name2mult = {b[1]: b[3] for b in E.BEASTS_BASE}
    expect = {int(c): int(name2mult[n]) for n, c in ids.items()} if ids else None
    pred = E.Predictor(E.PredictionConfig(**{k: v for k, v in _cfg().items()
                                             if k in E.PredictionConfig.__dataclass_fields__}),
                       None, "r", __import__("logging").getLogger("t"), persistent=False)
    got = pred._fr_multipliers()
    assert sorted(got) == list(range(1, 10))
    if expect:
        assert got == expect, (
            "config.yaml 的 custom_beast_ids 与 frontier 用的倍率表已分叉："
            "请在 prediction.fr_mult 里显式写出本部署的号位→倍率表")


def test_cold_pool_is_the_five_highest_multipliers():
    """冷池必须等于倍率最高的 5 只 —— 与 test_showcase_rotate 同一条纪律。"""
    got = E.Predictor._pools(_cfg()["showcase_cold_ids"])[0]
    pred_mult = {int(c): int({b[1]: b[3] for b in E.BEASTS_BASE}[n])
                 for n, c in E.DEFAULT_CUSTOM_IDS.items()}
    top5 = tuple(sorted(sorted(pred_mult, key=lambda c: -pred_mult[c])[:5]))
    assert got == top5


def test_rare_pool_is_the_two_highest_multipliers():
    got = E.Predictor._pools_n(_cfg()["fr_rare_ids"], 2, (3, 9))
    pred_mult = {int(c): int({b[1]: b[3] for b in E.BEASTS_BASE}[n])
                 for n, c in E.DEFAULT_CUSTOM_IDS.items()}
    top2 = tuple(sorted(sorted(pred_mult, key=lambda c: -pred_mult[c])[:2]))
    assert got == top2


# ═══════════ ⑤ 端到端 + 诚实性守卫 ═══════════

def test_frontier_end_to_end_and_rotates():
    seq = _seq(2500)
    b = PredictorBridge(_cfg(explore_style="frontier"), {})
    kv, picks = {}, []
    for i in range(1800, 2500):
        r, d = b.run_prediction("r", seq[:i], kv)
        kv.update(d)
        four = list(r["main"]) + list(r["guard"])
        assert len(set(four)) == 4 and all(1 <= c <= 9 for c in four)
        picks.append(tuple(sorted(four)))
    assert len(set(picks)) >= 3, "frontier 必须真的轮换"
    run = mx = 1
    for a, c in zip(picks[:-1], picks[1:]):
        run = run + 1 if a == c else 1
        mx = max(mx, run)
    assert mx <= 5


def test_frontier_seats_by_probability():
    """主 2 必须是四码中频率最高的两只（口径公开、可核对）。"""
    seq = _seq(2500)
    r = PredictorBridge(_cfg(explore_style="frontier"), {}).run_prediction("r", seq, {})[0]
    ens = r["ens"]
    assert min(ens[c - 1] for c in r["main"]) >= max(ens[c - 1] for c in r["guard"]) - 1e-12


@pytest.mark.parametrize("bad", [
    {"fr_cold_min": 0.99}, {"fr_rare_min": 0.99, "fr_ret_min": 999.0},
    {"fr_share_min": 0.6}, {"fr_mult": "乱写"}, {"fr_rare_ids": "99"},
    {"fr_replan": 0}, {"fr_share_max": 0.25},
])
def test_frontier_survives_hand_edited_config(bad):
    """config.yaml 是手改文件、不过注册表校验 —— 越界刻度不得把 predict() 打崩。"""
    r = PredictorBridge(_cfg(explore_style="frontier", **bad), {}
                        ).run_prediction("r", _seq(1200), {})[0]
    assert len(set(list(r["main"]) + list(r["guard"]))) == 4


_FORBIDDEN = ("门槛", "z=", "z+", "信号", "择时", "规律", "预判", "间隔节律", "热度")


def test_why_text_makes_no_timing_claim():
    """诚实性守卫：数据与 i.i.d. 不可区分 ⇒ 任何暗示择时能力的落款都是事实性错误。"""
    r = PredictorBridge(_cfg(explore_style="frontier"), {}).run_prediction("r", _seq(2000), {})[0]
    why = (r.get("explore") or {}).get("why", "")
    assert why, "frontier 必须给出落款"
    for w in _FORBIDDEN:
        assert w not in why, f"frontier 落款出现暗示择时能力的措辞：{w!r} in {why!r}"


# ═══════════ ⑥ 交付链守卫（本轮复查新增） ═══════════
#
# 病灶原貌：4.8.0 首版把 frontier_planner.py 放进 jiufa_data/，但
# backend_async/deploy/Dockerfile 只 `COPY jiufa_data/spell_tamer_monitor.py`。
# 引擎那句 import 带 try/except ⇒ 镜像里缺文件时 explore_style="frontier"
# **一声不吭地跑成通用兜底分支**，运维看到"改了配置没反应"却查不到任何日志。
# 这正是本仓库 hot_rotate 的同款病。以下两条把它钉死。

def _engine_dir():
    return os.path.join(ROOT, "jiufa_data")


def _engine_local_imports():
    """扫 jiufa_data/spell_tamer_monitor.py 里所有 import 的**同目录**模块。"""
    import ast
    src = open(os.path.join(_engine_dir(), "spell_tamer_monitor.py"),
               encoding="utf-8").read()
    local = set()
    for node in ast.walk(ast.parse(src)):
        names = []
        if isinstance(node, ast.Import):
            names = [a.name.split(".")[0] for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            names = [node.module.split(".")[0]]
        for n in names:
            if os.path.isfile(os.path.join(_engine_dir(), n + ".py")):
                local.add(n)
    return local


def test_dockerfile_copies_every_engine_module():
    """引擎目录里被 import 的每个模块，都必须出现在 Dockerfile 的 COPY 里。
    漏一个 = 该特性在生产静默失效（且无任何日志）。"""
    dockerfile = os.path.join(ROOT, "backend_async", "deploy", "Dockerfile")
    if not os.path.isfile(dockerfile):
        pytest.skip("缺 deploy/Dockerfile（仅后端包）")
    text = open(dockerfile, encoding="utf-8").read()
    missing = [m for m in sorted(_engine_local_imports())
               if f"jiufa_data/{m}.py" not in text]
    assert not missing, (
        f"Dockerfile 没把这些引擎模块投进镜像：{missing}。"
        "引擎的 import 带 try/except，漏拷不会报错，只会让对应风格静默失效 —— "
        "必须在 deploy/Dockerfile 里补 COPY。")


def test_frontier_without_planner_is_loud_not_silent(monkeypatch, caplog):
    """规划器缺失时必须 ERROR，而不是安静地跑成别的风格。

    4.9.0 起该告警改用模块级节流表 `_STYLE_WARNED`（原实例级标志在桥模式下每局
    归零、形同虚设，实测 200 局刷 200 条）。节流表跨用例存活 ⇒ 本测试必须先清表，
    否则会被前面的用例"预支"掉这一条而假红 —— 与 test_dirty_sequence_warning_is_
    throttled 清 `_DIRTY_SEQ_WARNED` 同一纪律。
    """
    import logging
    E._STYLE_WARNED.clear()
    monkeypatch.setattr(E, "_fr_plan", None, raising=False)
    monkeypatch.setattr(E, "_FrSched", None, raising=False)
    cfg = E.PredictionConfig(**{k: v for k, v in _cfg(explore_style="frontier").items()
                                if k in E.PredictionConfig.__dataclass_fields__})
    log = logging.getLogger("test-frontier-loud")
    with caplog.at_level(logging.ERROR, logger="test-frontier-loud"):
        E.Predictor(cfg, None, "r", log, persistent=False).predict(_seq(600))
    assert any("frontier_planner" in r.getMessage() for r in caplog.records), \
        "规划器缺失时没有任何 ERROR 日志 —— 这就是静默失效"


def test_style_warnings_are_throttled():
    """「未实现风格」「缺 frontier_planner.py」两条告警必须节流。

    4.9.0 第五轮复查实测：桥模式下 Predictor **每局重建**，原来的实例级去重标志
    每局归零 —— 200 局刷 200 条，折算 1 万房 ≈ 200 行/s ≈ 1728 万行/天，比
    RARE_LOG_MULTIPLIER_THRESHOLD 当初要治的 200 万行/天还严重 8.6 倍。
    节流键不含 room_id（配置级问题一万房会同时命中），但换一个不同的错值必须重新喊。
    """
    import logging
    E._STYLE_WARNED.clear()
    seq = _seq(600)
    log = logging.getLogger("style-throttle-probe")
    hits = []
    log.warning = lambda *a, **k: hits.append(a)          # type: ignore[assignment]

    def run(style, n):
        cfg = E.PredictionConfig(**{k: v for k, v in _cfg(explore_style=style).items()
                                    if k in E.PredictionConfig.__dataclass_fields__})
        for _ in range(n):
            E.Predictor(cfg, None, "room-x", log, persistent=False).predict(list(seq))

    run("这不是一个风格", 20)
    assert len(hits) == 1, f"20 局刷了 {len(hits)} 条 —— 节流失效"
    run("这不是一个风格", 20)
    assert len(hits) == 1, "同一个错值在窗口内不该重复喊"
    run("换一个错值", 20)
    assert len(hits) == 2, "换了不同的错值必须重新喊一条"


def test_implemented_styles_match_registry_enum():
    """引擎实现的风格集合必须与注册表 enum 的 choices 一致。
    两边任一改了另一边没跟上，运维就会配一个'看着生效其实没生效'的值。"""
    from app import config_registry as reg
    fld = reg.REGISTRY.get("prediction.explore_style")
    if fld is None or not getattr(fld, "choices", None):
        pytest.skip("注册表未登记 explore_style choices")
    assert set(fld.choices) == set(E.Predictor.IMPLEMENTED_STYLES), (
        f"引擎实现 {sorted(E.Predictor.IMPLEMENTED_STYLES)} vs "
        f"注册表 {sorted(fld.choices)}")


# ═══════════ ⑦ 桥模式下的状态持久化（本轮复查新增） ═══════════
#
# 病灶原貌：PredictorBridge 每次调用都**新建** Predictor（无状态设计，为多 worker
# 流转服务），所有跨局状态只能靠 explore_state 往返。4.8.0 首版没把 LP 混合方案
# 落盘 ⇒ `self._fr_mix is None` 恒成立 ⇒ **fr_replan 完全不生效**（实测：
# fr_replan=200 时 100 局解了 100 次 LP），既白烧 CPU，又让参数变成装饰品。

def test_fr_replan_actually_takes_effect_through_bridge():
    seq = _seq(1800)
    calls = []
    real = frontier_planner.plan

    def counting(*a, **k):
        calls.append(1)
        return real(*a, **k)

    E._fr_plan = counting
    try:
        b = PredictorBridge(_cfg(explore_style="frontier", fr_replan=200), {})
        kv = {}
        for i in range(1700, 1800):
            _, d = b.run_prediction("r", seq[:i], kv)
            kv.update(d)
    finally:
        E._fr_plan = real
    assert len(calls) == 1, (
        f"fr_replan=200 时 100 局解了 {len(calls)} 次 LP —— 混合方案没经 "
        "explore_state 往返，参数不生效")


def test_config_change_forces_immediate_replan():
    """fr_* 在注册表里标 hot=HOOK，运维改完期望立刻生效，不能被 fr_replan 节拍拖住。"""
    seq = _seq(1800)
    b = PredictorBridge(_cfg(explore_style="frontier", fr_replan=100000), {})
    kv = {}
    for i in range(1700, 1720):
        _, d = b.run_prediction("r", seq[:i], kv)
        kv.update(d)
    calls = []
    real = frontier_planner.plan
    E._fr_plan = lambda *a, **k: (calls.append(1), real(*a, **k))[1]
    try:
        b2 = PredictorBridge(_cfg(explore_style="frontier", fr_replan=100000,
                                  fr_cold_min=0.15), {})
        b2.run_prediction("r", seq[:1720], kv)
    finally:
        E._fr_plan = real
    assert len(calls) == 1, "改了 fr_cold_min 却没重解 LP —— 配置指纹失效"


def test_state_survives_worker_handoff():
    """状态必须能在两个「不同 worker」之间无缝流转：只带 kv，不带内存。"""
    seq = _seq(1900)
    kv = {}
    a_picks = []
    b = PredictorBridge(_cfg(explore_style="frontier"), {})
    for i in range(1700, 1780):
        r, d = b.run_prediction("r", seq[:i], kv)
        kv.update(d)
        a_picks.append(tuple(sorted(list(r["main"]) + list(r["guard"]))))
    # 换一个"进程"：全新 bridge，只继承 kv
    kv2 = dict(kv)
    b2 = PredictorBridge(_cfg(explore_style="frontier"), {})
    r2, _ = b2.run_prediction("r", seq[:1780], kv2)
    b3 = PredictorBridge(_cfg(explore_style="frontier"), {})
    r3, _ = b3.run_prediction("r", seq[:1780], dict(kv))
    assert (r2["main"], r2["guard"]) == (r3["main"], r3["guard"]), \
        "同一 kv 起点产出不同 —— 状态往返有丢失"
    assert len(set(a_picks)) >= 2


def test_explore_state_stays_small():
    """explore_state 落 PG 的 predictor_state.v(TEXT)，每房一行、每局重写 —— 别让它膨胀。"""
    seq = _seq(1800)
    b = PredictorBridge(_cfg(explore_style="frontier"), {})
    kv = {}
    for i in range(1700, 1760):
        _, d = b.run_prediction("r", seq[:i], kv)
        kv.update(d)
    size = len(kv.get("explore_state", ""))
    assert size < 8000, f"explore_state 膨胀到 {size} 字节"


def test_rebuild_weights_clears_every_cross_round_state():
    """rebuild_weights 是"错乱数据后的最终自愈"，必须把**全部**跨局状态归零。
    复查发现：showcase_rotate 的赤字账本 _dbt、repeat_guard 的 _rep、k 分位历史
    _kd 上线时没跟进这条纪律 —— 陈年赤字会渗进修正后的时间线。本用例把它钉住，
    以后再加新状态字段忘了跟进就当场红。"""
    import logging

    class _Store:
        def kv_get(self, r, k):
            return None

        def kv_set(self, r, k, v):
            pass

        def settled_predictions(self, r):
            return []

    p = E.Predictor(E.PredictionConfig(), _Store(), "r", logging.getLogger("t"))
    p._dbt = {c: 3.3 for c in range(1, 10)}
    p._rep = 7
    p._kd[0].append(1.5)
    p._pen = {c: 5 for c in range(1, 10)}
    p._fr_mix = {(1, 2, 7, 8): 1.0}
    p._fr_debt = {(1, 2, 7, 8): 0.5}
    p._fr_plan_age = 42
    p._fr_key = "x"
    p._last_seat = {"swap": [1, 2]}
    p.rebuild_weights()
    assert all(v == 0.0 for v in p._dbt.values()), "赤字账本未清零"
    assert p._rep == 0 and not any(len(d) for d in p._kd), "连推计数 / k 分位历史未清零"
    assert all(v == 0 for v in p._pen.values())
    assert p._fr_mix is None and not p._fr_debt and p._fr_plan_age == 0 and not p._fr_key
    assert p._last_seat is None


# ═══════════ ⑧ 规划器数值鲁棒性（第四轮复查新增） ═══════════
#
# 病灶原貌：前三轮只用「真机 p̂ + 8 组约束」对拍过 scipy，全绿就收了。第四轮换成
# **随机 p̂ × 随机约束**的模糊对拍，当场炸出 300 例中 8 例**假不可行**：
# p 里出现 1e-10 量级分量时，约束矩阵动态范围到 1e9，退化基上 Bland / Dantzig
# 两条主元规则都会停滞（顶满迭代上限），而停滞被当成了"无解"。
# 后果不是崩，是**悄悄劣化**：plan(relax=True) 会以为约束不可行而把冷门/稀有
# 下限一条条丢掉，用户拿到的是一个"约束被偷偷放宽过"的方案。
# 修复三件套：① p 输入下限钳位（治因）② Bland 停滞 → Dantzig 兜底
#            ③ 出解后逐条复核约束（数值算法必须自证）。
# 生产域**逐字节不受影响**：p1 带 Laplace +2，1727 局窗实测 min(p)≈0.026。

def _fuzz_case(rng, i):
    m = i % 5
    raw = ([rng.random() for _ in range(9)] if m == 0 else
           [rng.random() ** 4 for _ in range(9)] if m == 1 else
           [1.0] * 9 if m == 2 else
           [1e-6] * 8 + [1.0] if m == 3 else
           [rng.choice([1e-9, 0.5, 1.0]) for _ in range(9)])
    s = sum(raw) or 1.0
    p = [max(v / s, 1e-12) for v in raw]
    kw = dict(cold_min=rng.choice([None, 0.05, 0.15, 0.30]),
              rare_min=rng.choice([None, 0.01, 0.05]),
              ret_min=rng.choice([None, 5.0, 9.0, 14.0]),
              share_min=rng.choice([0.0, 0.05, 0.15]),
              share_max=rng.choice([1.0, 0.9, 0.6, 0.5]))
    return p, kw


def test_planner_never_stalls_or_lies_under_fuzz():
    """随机 p̂ × 随机约束：既不能抛非预期异常，出解也必须真满足约束。
    （与 scipy 的最优值对拍在开发机上跑；这里是**不依赖 scipy** 的自证版本，
    因为生产 requirements 里没有 numpy/scipy，CI 也不该为一个测试装它们。）"""
    rng = random.Random(20260802)
    for i in range(220):
        p, kw = _fuzz_case(rng, i)
        try:
            mix, diag = frontier_planner.plan(
                P_REAL if False else p, MULT, (3, 4, 5, 6, 9), (3, 9), relax=False, **kw)
        except frontier_planner.LPInfeasible:
            continue                      # 真不可行是合法结果
        except Exception as e:            # noqa: BLE001
            pytest.fail(f"第 {i} 例抛非预期异常 {type(e).__name__}: {e}；约束={kw}")
        assert abs(sum(mix.values()) - 1.0) < 1e-6, f"第 {i} 例：份额不归一"
        for key, name in (("cold_min", "cold"), ("rare_min", "rare"), ("ret_min", "ret")):
            if kw[key] is not None:
                assert diag[name] >= kw[key] - 1e-6, (
                    f"第 {i} 例：出解未满足 {key}（{diag[name]} < {kw[key]}）；"
                    "数值算法'解出来了'不等于'真满足'")


def test_planner_relax_never_raises_under_fuzz():
    """relax=True 是 predict() 的实际调用形态：任何越界配置都不得把它打崩。"""
    rng = random.Random(1234)
    for i in range(220):
        p, kw = _fuzz_case(rng, i)
        frontier_planner.plan(p, MULT, (3, 4, 5, 6, 9), (3, 9), **kw)


def test_production_plan_is_unchanged_by_the_numeric_fixes():
    """生产口径的解必须**逐字节**不受数值修复影响 —— 修 bug 不许顺手改结果。
    下面这组是修复前后完全一致的实测值（真机三房 36,278 局的 p̂）。"""
    mix, diag = frontier_planner.plan(
        P_REAL, MULT, (3, 4, 5, 6, 9), (3, 9),
        cold_min=0.1232, rare_min=0.0180, ret_min=8.624)
    got = {"".join(map(str, k)): round(v, 6) for k, v in mix.items()}
    assert got == {"3678": 0.365186, "1678": 0.364287,
                   "2678": 0.179754, "5678": 0.090773}, got
    assert round(diag["hit"], 6) == 0.537470
    assert round(diag["cold"], 6) == 0.123200
    assert round(diag["rare"], 6) == 0.018000
    assert round(diag["ret"], 6) == 8.624000


def test_p_floor_does_not_touch_production_scale():
    """输入钳位（1e-6）在生产 p̂ 上不得触发 —— 触发了就说明它改了结果。"""
    assert min(P_REAL) > 1e-6 * 100
    a = frontier_planner.plan(P_REAL, MULT, (3, 4, 5, 6, 9), (3, 9), cold_min=0.1232)[0]
    scaled = [v for v in P_REAL]
    b = frontier_planner.plan(scaled, MULT, (3, 4, 5, 6, 9), (3, 9), cold_min=0.1232)[0]
    assert a == b


# ═══════════ ⑩ 「长期不推某个号」守卫（第八轮，由用户提问暴露） ═══════════
#
# 病灶原貌（我引入的、且首版默认值配错）：LP 解出的混合方案在一个规划周期内只含
# 3~5 个四码集合，不在里面的号会**连续几百上千局不出现**，且与它最近开没开出无关
# （LP 只看 24h 窗口的 p̂）。真机 2678075 房 6273 局实测最长连续不进四码：
#     showcase(现行)          max=  46 局
#     frontier share_min=0    max=4273 局（号9≈59 小时；号2 800 局≈11 小时）
#     frontier share_min=0.05 max=  39 局   ← 定稿，且四项指标里三项反而更好
# showcase 之所以没这毛病靠的是 sc_floor_cold 那套份额地板 + 赤字账本；
# frontier 换成 LP 调度后，这层保护必须由 fr_share_min 补回来。

def test_share_floor_is_not_zero_by_default():
    """默认份额地板不得为 0 —— 设 0 就会出现「最近老出 2、它就是不推 2」。"""
    assert float(_cfg()["fr_share_min"]) >= 0.03, (
        "fr_share_min 回到 0（或过小）了：LP 会把不在当前方案里的号饿死几百上千局")


def test_main_seat_floor_is_not_zero_by_default():
    """主位份额下限不得为 0。frontier 的主位规则是「四码中 p̂ 最高的两只」，
    低频号永远排不进前二 —— 真机实测 main_min=0 时号3/4/9 的主位份额恒为
    0.0%、主位饥饿 = 全程 4273 局（≈59 小时一次没当过主推）。
    main_min=0.08 把它压到 171 局（优于 showcase 的 311），代价仅主中率 −0.51pp。

    4.9.0 复查再次验证：置 0 可拿回 0.91pp 主中率（31.65→32.56%，p=2.9e-17，
    四码逐局全同），但 test_every_number_reaches_the_main_seat 当场红 ——
    号 3/4/5/7/9 在 1400 局内一次都没进过主位。**不要为那 0.91pp 调它。**"""
    assert float(_cfg()["fr_main_share_min"]) >= 0.03


def test_main_seat_rotation_does_not_change_the_four_codes():
    """主位轮转只重排四码**内部**顺序，不得改动四码集合本身 ——
    否则命中/冷门/回报四项都会跟着变，代价就不再是"只掉 0.51pp 主中率"。"""
    seq = _seq(3000)
    sets = []
    for mm in (0.0, 0.08):
        b = PredictorBridge(_cfg(explore_style="frontier", fr_main_share_min=mm), {})
        kv, out = {}, []
        for i in range(2600, 2900):
            r, d = b.run_prediction("r", seq[:i], kv)
            kv.update(d)
            out.append(frozenset(r["main"]) | frozenset(r["guard"]))
        sets.append(out)
    assert sets[0] == sets[1], "开启主位轮转后四码集合变了 —— 它只该动座次"


def test_every_number_reaches_the_main_seat():
    """任一号进入主位的间隔必须有界（合成序列给足余量取 600 局）。"""
    seq = _seq(3400)
    b = PredictorBridge(_cfg(explore_style="frontier"), {})
    kv, mains = {}, []
    for i in range(2000, 3400):
        r, d = b.run_prediction("r", seq[:i], kv)
        kv.update(d)
        mains.append(set(r["main"]))
    worst = {}
    for c in range(1, 10):
        mx = run = 0
        for m in mains:
            run = 0 if c in m else run + 1
            mx = max(mx, run)
        worst[c] = mx
    bad = {c: g for c, g in worst.items() if g > 600}
    assert not bad, f"这些号长期进不了主位（局数）：{bad}"


def test_every_number_appears_within_a_bounded_gap():
    """任一号连续不进四码的局数必须有界。合成序列上给足余量取 120 局，
    真机同口径实测是 39 局（showcase 对照 46 局）。"""
    seq = _seq(3200)
    b = PredictorBridge(_cfg(explore_style="frontier"), {})
    kv, picks = {}, []
    for i in range(2000, 3200):
        r, d = b.run_prediction("r", seq[:i], kv)
        kv.update(d)
        picks.append(set(r["main"]) | set(r["guard"]))
    worst = {}
    for c in range(1, 10):
        mx = run = 0
        for f in picks:
            run = 0 if c in f else run + 1
            mx = max(mx, run)
        worst[c] = mx
    bad = {c: g for c, g in worst.items() if g > 120}
    assert not bad, f"这些号被饿死太久（局数）：{bad}"


# ═══════════ ⑪ 脏数据 / 脏状态韧性（第十轮，用户视角场景电池） ═══════════
#
# 电池实测（真机 + 合成，两风格）查出的两处崩溃，都已修：
#   E1/E2/E4 seq 混入 0 / 10 / -1 / None / 超大整数 → 原本 IndexError / TypeError，
#            **showcase 与 frontier 都崩**（既有缺陷，非本次引入）；
#   E7       explore_state 里的 frm 被写坏 → 解析成空 dict 而非 None ⇒
#            _FrSched({}) 的 max() 炸（**我引入的**）。

@pytest.mark.parametrize("bad", [0, 10, -1, None, 999999, True, "x", 1.5])
def test_dirty_sequence_does_not_crash(bad):
    """seq 里混进非 1~9 的值不得把 predict() 打崩 —— 调用方只有 try/except 兜底，
    崩了就表现为"这一局没有预测"，查不出原因。"""
    seq = _seq(1400)
    seq[700] = bad
    for style in ("showcase", "frontier"):
        r = PredictorBridge(_cfg(explore_style=style), {}).run_prediction("r", seq, {})[0]
        four = list(r["main"]) + list(r["guard"])
        assert len(set(four)) == 4 and all(1 <= c <= 9 for c in four)


def test_dirty_sequence_warning_is_throttled():
    """脏序列告警必须节流。桥模式下 Predictor 每局重建，不节流就会每局每房刷一条 ——
    日志刷屏本身就是新的故障模式。"""
    E._DIRTY_SEQ_WARNED.clear()
    seq = _seq(1400)
    seq[700] = 99
    import logging
    log = logging.getLogger("throttle-probe")
    cfg = E.PredictionConfig(**{k: v for k, v in _cfg().items()
                                if k in E.PredictionConfig.__dataclass_fields__})
    hits = []
    log.warning = lambda *a, **k: hits.append(a)          # type: ignore[assignment]
    for _ in range(20):
        E.Predictor(cfg, None, "room-x", log, persistent=False).predict(list(seq))
    assert len(hits) == 1, f"20 局刷了 {len(hits)} 条告警 —— 节流失效"


def test_corrupt_frontier_state_does_not_crash():
    """explore_state 里的 frm/frd 被写坏（并发写、DB 损坏、手改）不得崩。"""
    seq = _seq(2400)
    b = PredictorBridge(_cfg(explore_style="frontier"), {})
    kv = {}
    for i in range(2200, 2210):
        _, d = b.run_prediction("r", seq[:i], kv)
        kv.update(d)
    st = json.loads(kv["explore_state"])
    for mut in ({"frm": [[1, 2, "x"], [9]]}, {"frm": []}, {"frm": "nonsense"},
                {"frd": {"1,2,7,8": -999, "9,9,9,9": 5}}, {"frk": 12345}):
        bad_kv = dict(kv)
        bad_kv["explore_state"] = json.dumps({**st, **mut})
        r = PredictorBridge(_cfg(explore_style="frontier"), {}
                            ).run_prediction("r", seq[:2210], bad_kv)[0]
        four = list(r["main"]) + list(r["guard"])
        assert len(set(four)) == 4, f"{mut} → {four}"
