"""
test_jfvip_cs.py — 客服联系方式(4.4.2)的机器保证
================================================================================
「联系客服购买」自 4.4.1 起只是一句纯提示;4.4.2 给它配上真正可用的联系方式,
并把它做成前端可复用的一块数据。本文件钉死五类不变量:

  A. **不配置即不存在**:号码与链接都空 ⇒ cs_info() 回 {} ⇒ /api/auth/session
     里**连 contact 键都不出现**(不是一个空对象)。旧前端零影响,页面逐字节
     维持 4.4.1。

  B. **站点裁剪在服务端**(最重要的一条):非直营主站一律回 {} —— 镜像站的响应
     体里根本没有平台客服号。这不是"前端藏起来":藏起来的话 F12 一开就能把它从
     代理站页面里挖出去,而那正是 JFVIP-SYSTEM.md §12.3 点名要挡的一步可达绕过。

  C. **链接白名单**:只放行 http/https 绝对 URL。`javascript:` / `data:` /
     `//host` / 带前导空白的变体一律回 ""。
     ⚠ 这道闸**必须**在 cs_info 这个下发边界上,而不是在管理台校验里 ——
     config_center.semantic_validate 只在 /api/admin/config/{validate,apply}
     那条路上跑,ENV(STA_JF_CS_*)与 config.yaml **绕过它直接进 Settings**。
     用例 C4 就是拿"直接改 cfg"(等价于 ENV 灌入)的方式打这条路。

  D. **字符收敛**:折叠空白、剥零宽/双向控制符、按字符截断;但**不做字符纠错**
     (全角数字原样保留)—— 猜错一个字符就是把付费用户送去别人那里。

  E. **管理台/横幅回显的是收敛后的生效值**,不是配置原串;链接被丢弃时另有
     醒目告警(页面上只是少一个链接、不会报错,这是唯一能提前发现它的地方)。

纯静态 + 纯内存,零外部依赖(不需要 MySQL / Redis / PG)。
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

from app import config_center, jfvip, userauth
from app.settings import UserAuthCfg
from tests import _srcscan

ROOT = Path(__file__).resolve().parents[2]
APP_JS = ROOT / "assets" / "app.js"
INDEX = ROOT / "index.html"


class _Req:
    """最小 Request 替身 —— 站点判定只读 headers,不碰其余任何字段。"""

    def __init__(self, headers=None):
        self.headers = headers or {}


@pytest.fixture(autouse=True)
def _cfg(monkeypatch):
    """每个用例一份干净配置;默认「未配置客服」+「未启用站点分流」。"""
    cfg = UserAuthCfg(host="h", db="d", user="u", jf_vip_enabled=True)
    monkeypatch.setattr(userauth.UA, "cfg", cfg, raising=False)
    return cfg


# ══════════════════════════════════════════════════════════════════════════════
# A. 不配置即不存在
# ══════════════════════════════════════════════════════════════════════════════
def test_unconfigured_returns_empty(_cfg):
    assert userauth.cs_info(_Req({"host": "a.example"})) == {}


def test_label_and_note_alone_do_not_enable_it(_cfg):
    """只填标签/备注而没有号码也没有链接 ⇒ 整块不存在。

    开关就是「号码或链接」这两项本身(同 jf_direct_hosts 留空=关闭),
    不另设总开关 —— 多一个开关就多一种「开了但没配」的中间态。
    """
    _cfg.jf_cs_label = "客服QQ"
    _cfg.jf_cs_note = "服务时间 09:00-24:00"
    assert userauth.cs_info(_Req({"host": "a.example"})) == {}


def test_empty_keys_are_omitted_not_blank(_cfg):
    """有才给,不给空串。

    响应体里出现一个半空的 contact 段,会让排查的人以为「特性已生效只是值没填」,
    而真相可能是站点被判成了镜像。没有就是没有,不留半个影子。
    """
    _cfg.jf_cs_value = "800123456"
    out = userauth.cs_info(_Req({"host": "a.example"}))
    assert out == {"value": "800123456"}
    assert "label" not in out and "url" not in out and "note" not in out


def test_cfg_none_is_fail_closed(monkeypatch):
    """登录系统尚未初始化(UA.cfg is None)⇒ 宁可不给,不得抛。"""
    monkeypatch.setattr(userauth.UA, "cfg", None, raising=False)
    assert userauth.cs_info(_Req({"host": "a.example"})) == {}
    assert userauth.cs_info(None) == {}


# ══════════════════════════════════════════════════════════════════════════════
# B. 站点裁剪(核心)
# ══════════════════════════════════════════════════════════════════════════════
def test_mirror_site_gets_nothing(_cfg):
    """★ 最硬的一条:代理镜像站的下发结果里搜不到那串号码。"""
    _cfg.jf_cs_label = "客服QQ"
    _cfg.jf_cs_value = "800123456"
    _cfg.jf_cs_url = "https://kf.example.com/chat"
    _cfg.jf_cs_note = "09:00-24:00"
    _cfg.jf_direct_hosts = "jiufa.example.com,www.jiufa.example.com"
    mirror = userauth.cs_info(_Req({"host": "a.agent.example"}))
    assert mirror == {}, "镜像站不得拿到平台客服"
    assert "800123456" not in repr(mirror)
    # 同一份配置在直营站必须照常给出 —— 否则上面的 {} 可能是"根本没生效"
    direct = userauth.cs_info(_Req({"host": "jiufa.example.com"}))
    assert direct["value"] == "800123456", "反向自证:直营站必须拿得到"


def test_unenforced_means_every_host_is_direct(_cfg):
    """未配置直营名单 ⇒ 特性关闭 ⇒ 全部按直营(与 jf_site 同一条惯例)。"""
    _cfg.jf_cs_value = "800123456"
    assert userauth.cs_info(_Req({"host": "whatever.example"}))["value"] == "800123456"


def test_site_gate_follows_jf_site_exactly(_cfg):
    """站点判据必须与 jf_site() 同源,不得另造一份(两边打架是最难查的失真)。"""
    _cfg.jf_cs_value = "800123456"
    _cfg.jf_direct_hosts = "jiufa.example.com"
    for host in ("jiufa.example.com", "JIUFA.example.com:8443",
                 "a.agent.example", "203.0.113.7", ""):
        req = _Req({"host": host})
        want = userauth.jf_site(req)["direct"]
        got = bool(userauth.cs_info(req))
        assert got == want, f"{host!r}: cs_info={got} 与 jf_site.direct={want} 不一致"


def test_xfh_trust_is_honoured(_cfg):
    """开了信任 XFH,客服的站点判定必须跟着走(否则会出现"支付按直营、客服按镜像")。"""
    _cfg.jf_cs_value = "800123456"
    _cfg.jf_direct_hosts = "jiufa.example.com"
    _cfg.jf_direct_trust_xfh = True
    req = _Req({"host": "upstream.internal", "x-forwarded-host": "jiufa.example.com, lb"})
    assert userauth.cs_info(req)["value"] == "800123456"


# ══════════════════════════════════════════════════════════════════════════════
# C. 链接白名单
# ══════════════════════════════════════════════════════════════════════════════
@pytest.mark.parametrize("bad", [
    "javascript:alert(1)",
    "JaVaScRiPt:alert(1)",
    "  javascript:alert(1)",          # 前导空白(strip 后仍非 http/https)
    "java\tscript:alert(1)",          # 折叠空白后变 "java script:..." 仍非法
    "data:text/html;base64,PHNjcmlwdD4=",
    "vbscript:msgbox(1)",
    "//evil.example.com",             # 协议相对:继承本页协议直指外站
    "mqqwpa://im/chat?chat_type=wpa&uin=800123456",
    "tencent://message/?uin=800123456",
    "weixin://dl/chat",
    "/kf/chat",                       # 相对路径:本站没有这个页面
    "kf.example.com",                 # 裸域名:不是绝对 URL
    "https://",                       # 空主机
    "https:///path",                  # 空主机
    "",
    None,
])
def test_bad_urls_are_dropped(bad):
    assert userauth.cs_url(bad) == "", f"{bad!r} 不该被放行"


@pytest.mark.parametrize("good", [
    "https://kf.example.com/chat",
    "http://kf.example.com",
    "HTTPS://KF.example.com/a?b=1#c",
    "https://qm.qq.com/cgi-bin/qm/qr?k=abcdef",
])
def test_good_urls_pass_through_verbatim(good):
    """放行的必须**原样**回(含大小写与查询串)—— 链接被"整理"过就可能失效。"""
    assert userauth.cs_url(good) == good.strip()


def test_bad_url_does_not_suppress_the_number(_cfg):
    """链接非法只丢链接,号码照常下发 —— 一处配错不该把整块能力打掉。"""
    _cfg.jf_cs_value = "800123456"
    _cfg.jf_cs_url = "javascript:alert(1)"
    out = userauth.cs_info(_Req({"host": "a.example"}))
    assert out == {"value": "800123456"}


def test_env_path_bypasses_admin_validation_so_runtime_gate_is_mandatory(_cfg):
    """★ C4:直接改 cfg(等价于 ENV / config.yaml 灌入)绕过 semantic_validate,
    运行期这道闸必须仍然生效。

    这不是假想:settings.load 读 STA_JF_CS_URL 时**只做 strip**,而
    config_center.semantic_validate 只在管理台 validate/apply 那条路上跑。
    如果白名单只落在管理台,「运维改 .env 就能把 javascript: 送进 href」这条路
    就是敞开的。
    """
    _cfg.jf_cs_value = "800123456"
    _cfg.jf_cs_url = "javascript:void(0)"
    assert "url" not in userauth.cs_info(_Req({"host": "a.example"}))


def test_url_gate_is_a_whitelist_in_source():
    """白名单而非黑名单 —— 源码里必须是"以 http/https 开头才放行"的形态。

    黑名单在这里必输:每一种变体都得想到才挡得住。这条钉的是**写法**,
    因为一旦有人"顺手"改成 `if 'javascript:' in s: return ''`,上面那些
    parametrize 用例仍会绿(它们只覆盖已知变体),而新的变体会一路放行。
    """
    src = (Path(__file__).resolve().parents[1] / "app" / "userauth.py").read_text(
        encoding="utf-8")
    m = re.search(r"def cs_url\(.*?\n(.*?)\n\ndef ", src, re.S)
    assert m, "未找到 cs_url"
    body = m.group(1)
    assert 'startswith("http://")' in body and 'startswith("https://")' in body, \
        "cs_url 必须以 http/https 前缀白名单判定"


# ══════════════════════════════════════════════════════════════════════════════
# D. 字符收敛(但不纠错)
# ══════════════════════════════════════════════════════════════════════════════
def test_whitespace_is_folded_to_single_line():
    assert userauth.cs_text("  客服\n QQ\t800 ", 64) == "客服 QQ 800"


@pytest.mark.parametrize("ch", ["\u200b", "\ufeff", "\u202e", "\u2066", "\u200e"])
def test_invisible_and_bidi_chars_are_stripped(ch):
    """零宽/双向控制符必须剥掉:前者能在展示串里藏东西让肉眼核对失效,
    后者能把号码渲染成看起来是别的顺序 —— 而这串是要用户照着抄的。"""
    assert userauth.cs_text(f"800{ch}123456", 64) == "800123456"


def test_zwj_survives_for_emoji_sequences():
    """★ 刻意**不**按 unicodedata 的 Cf 类整类剥:ZWJ(U+200D)是 emoji 组合
    序列的连接符,整类剥会把渠道名里的「👨‍💼」拆成两个字符。"""
    assert "\u200d" in userauth.cs_text("👨\u200d💼客服", 16)


def test_control_chars_are_stripped():
    assert userauth.cs_text("800\x01123\x7f456", 64) == "800123456"


def test_装饰性字段超长走截断():
    """label / note 是装饰性的:截短仍认得出来,也没人会去复制它。"""
    assert userauth.cs_text("九" * 100, 16) == "九" * 16
    assert len(userauth.cs_text("x" * 500, 64)) == 64


def test_actionable_fields_are_fail_closed_on_overlength():
    """★ 自审新增:value / url 超长必须**整条丢弃**,绝不截断。

    截断一个号码 = 用户照着抄却永远打不通;截断一个 URL 更恶劣 —— 它会**通过**
    http/https 白名单,变成一条看不出任何异常、却指向别处或 404 的坏链。
    与本仓库既有取向一字不差(jfvip 定制时长卡):「截断会让用户拿到一张与卡面
    不符的卡,而 fail-closed 只是让他去找客服」。
    """
    assert userauth.cs_text("9" * 65, 64, drop_if_over=True) == ""
    assert userauth.cs_text("9" * 64, 64, drop_if_over=True) == "9" * 64   # 边界:等于上限放行
    assert userauth.cs_url("https://" + "a" * 300 + ".com") == ""


def test_overlong_value_is_dropped_end_to_end(_cfg):
    """走完整下发链路,不只是单测那个函数。"""
    _cfg.jf_cs_value = "9" * 200
    assert userauth.cs_info(_Req({"host": "a.example"})) == {}, \
        "超长号码必须整条丢弃,且不得留下半个 contact 段"


@pytest.mark.parametrize("bad", [
    "https:///path",      # 空主机
    "https://:80/",       # 只有端口没有主机
    "https://?x=1",       # scheme 之后直接是 query
    "https://#frag",
])
def test_scheme_without_host_is_rejected(bad):
    """★ 自审新增:「有 scheme 没主机」前缀判定放得过去,浏览器却无处可去 ——
    又一个死控件。必须连主机名一起验。"""
    assert userauth.cs_url(bad) == ""


def test_dropped_fields_are_never_silent(_cfg, capsys):
    """★ fail-closed 的前提是**说出来**。丢弃而不告知 = 运维对着空位反复怀疑
    是不是没生效,那比截断还难查。两条成因必须分别点名。"""
    _cfg.jf_cs_value = "9" * 200
    _cfg.jf_cs_url = "https://" + "a" * 300
    jfvip.startup_report()
    out = capsys.readouterr().out
    assert "客服号码/账号超过" in out and "整条丢弃" in out
    assert "在线客服链接" in out and "字符上限" in out


def test_full_width_digits_are_kept_verbatim():
    """★ 刻意不做字符纠错(同 norm_card / norm_host):猜错一个字符就是把付费
    用户送去别人的号。管理台会告警,但系统绝不替运维改。"""
    assert userauth.cs_text("８００１２３", 64) == "８００１２３"


def test_limits_are_declared_once_and_used_everywhere():
    """长度上界是**一份声明**:注册表 desc、管理台、横幅、校验器都读它。"""
    assert set(userauth._CS_LIMITS) == {"label", "value", "url", "note"}
    assert userauth._CS_LIMITS["value"] == 64 and userauth._CS_LIMITS["url"] == 256


# ══════════════════════════════════════════════════════════════════════════════
# E. 可见性:注册表 / 校验器 / 横幅 / 概览
# ══════════════════════════════════════════════════════════════════════════════
def test_registered_in_schema_so_admin_renders_it():
    """管理页完全由注册表驱动 —— 登记了就自动有卡片,没登记就永远配不了。"""
    from app import config_registry as reg
    for k in ("label", "value", "url", "note"):
        f = reg.REGISTRY[f"userauth.jf_cs_{k}"]
        assert f.section == "九法VIP" and f.type == "str"
        assert f.hot == reg.HOT, "客服是热更项:改完前端下次取 session 即跟随"
        assert f.consumers == ("web",)
        assert f.env == f"STA_JF_CS_{k.upper()}"
        assert f.default == "", "默认必须空 —— 不配置即不存在"


def test_semantic_validate_echoes_the_resolved_value():
    """本组最重要的告警:回显**用户将看到的那一串**。

    这一项的真实错误形态是「打错一个字符」,而 danger 的「键入参数名确认」对
    这种错零帮助 —— 让运维核对生效值才有用。同一取向见 jf_vip_plans。
    """
    cand = {"userauth.jf_cs_value": "800123456", "userauth.jf_cs_label": "客服QQ"}
    errs, warns = config_center.semantic_validate(
        cand, changed={"userauth.jf_cs_value"})
    assert not errs
    assert any("800123456" in w and "核对" in w for w in warns), warns


def test_semantic_validate_rejects_bad_url_loudly():
    errs, _ = config_center.semantic_validate(
        {"userauth.jf_cs_url": "javascript:alert(1)"},
        changed={"userauth.jf_cs_url"})
    assert any("jf_cs_url" in e and "丢弃" in e for e in errs), errs


def test_semantic_validate_rejects_overlong():
    errs, _ = config_center.semantic_validate(
        {"userauth.jf_cs_value": "9" * 200}, changed={"userauth.jf_cs_value"})
    assert any("上限" in e for e in errs), errs


def test_semantic_validate_warns_on_full_width():
    _, warns = config_center.semantic_validate(
        {"userauth.jf_cs_value": "８００１２３"}, changed={"userauth.jf_cs_value"})
    assert any("全角" in w for w in warns), warns


def test_semantic_validate_warns_about_mirror_invisibility():
    """配了客服 + 配了分流 ⇒ 必须说清「镜像站看不到是预期行为」——
    这是本组配置唯一会让人怀疑"是不是没生效"的场景。"""
    _, warns = config_center.semantic_validate(
        {"userauth.jf_cs_value": "800123456",
         "userauth.jf_direct_hosts": "jiufa.example.com"},
        changed={"userauth.jf_cs_value"})
    assert any("直营主站" in w and "镜像" in w for w in warns), warns


def test_mirror_warning_fires_even_when_only_the_cs_key_changed():
    """★ 这条是上一条的关键补充,也是本轮自查抓到的一处真实缺陷:

    告警最初写在「站点分流」那一段里,而那一段的 _touched 只认 jf_direct_hosts。
    于是运维**只改客服号码**(最常见的一次操作)时,恰恰收不到「镜像站看不到是
    预期行为」这句话 —— 而那正是他最可能去自测、然后怀疑没生效的时刻。
    告警必须挂在**触发它的那组键**上。
    """
    _, warns = config_center.semantic_validate(
        {"userauth.jf_cs_value": "800123456",
         "userauth.jf_direct_hosts": "jiufa.example.com"},
        changed={"userauth.jf_cs_label"})
    assert any("镜像" in w for w in warns), warns


def test_semantic_validate_is_silent_when_untouched():
    """未触及本组键时一个字都不该说 —— 否则每次改别的参数都要被刷屏。"""
    _, warns = config_center.semantic_validate(
        {"userauth.jf_cs_value": "800123456"}, changed={"retention.days"})
    assert not any("客服" in w for w in warns), warns


def test_startup_banner_reports_effective_value(_cfg, capsys):
    """配错时页面不会报错,横幅是运维在用户找上门之前唯一能发现它的地方。"""
    _cfg.jf_cs_label, _cfg.jf_cs_value = "客服QQ", "800123456"
    _cfg.jf_cs_url = "mqqwpa://im/chat?uin=800123456"      # 会被丢弃
    jfvip.startup_report()
    out = capsys.readouterr().out
    assert "800123456" in out and "[客服]" in out
    assert "丢弃" in out, "被白名单丢弃的链接必须醒目告警"


def test_startup_banner_silent_when_unconfigured(_cfg, capsys):
    jfvip.startup_report()
    assert "[客服]" not in capsys.readouterr().out


# ══════════════════════════════════════════════════════════════════════════════
# F. 前端契约(静态钉:注入面与旧行为)
# ══════════════════════════════════════════════════════════════════════════════
def _app_js() -> str:
    """**剥掉注释**的 app.js。

    不剥就是假阳性:本次几条钉要判「代码里有没有 innerHTML / display:none」,
    而解释为什么**不能**用它们的注释里原样引用了这些词。这是 _srcscan 开篇
    记录的同一类问题,项目里已有多处先例(test_frontend_js_scope 等)。
    """
    if not APP_JS.is_file():
        pytest.skip("前端不在本仓")
    return _srcscan.js_code(APP_JS)


def _app_js_raw() -> str:
    """未剥注释的原文 —— 只给「首句字面量」这类需要看字符串常量的用例。"""
    if not APP_JS.is_file():
        pytest.skip("前端不在本仓")
    return APP_JS.read_text(encoding="utf-8")


def test_frontend_never_uses_innerhtml_for_the_cs_hint():
    """★ 回归钉。4.4.1 在那一行留过原话:「将来若要把文案改成可配置项,这一行
    必须同步改回 textContent + esc()」。现在文案含配置值,`vipCsHint.innerHTML`
    就是一条注入面 —— 一旦有人"顺手"改回去,这条当场变红。"""
    js = _app_js()
    assert not re.search(r"vipCsHint\s*\.\s*innerHTML", js), \
        "vipCsHint 不得再用 innerHTML(文案已含可配置值)"
    assert "csAppendTo(D.vipCsHint)" in js, "客服渲染入口丢失"


def test_frontend_builds_contact_nodes_not_strings():
    """渲染必须逐节点 createElement + textContent。"""
    js = _app_js()
    m = re.search(r"function csAppendTo\(host\)\{(.*?)\n\}", js, re.S)
    assert m, "未找到 csAppendTo"
    body = m.group(1)
    assert "innerHTML" not in body, "csAppendTo 内不得出现 innerHTML"
    assert "textContent" in body and "createElement" in body


def test_frontend_revalidates_url_scheme():
    """纵深防御:后端是真闸,前端这一道防的是"本模块被接到另一个数据源上"。
    `href="javascript:…"` 里没有任何需要 HTML 转义的字符,esc() 挡不住它。"""
    js = _app_js()
    assert "CS_URL_OK" in js and re.search(r"CS_URL_OK\s*=\s*/\^https\?", js), \
        "前端缺 http/https 白名单"
    assert "noopener" in js, "新窗链接必须带 rel=noopener"


def test_frontend_first_sentence_is_byte_identical():
    """两句首句逐字未动 —— 既有 jsdom 冒烟按字面钉着它们。"""
    js = _app_js_raw()
    assert "'没有卡密?可'" in js and "'本站仅支持卡密开通 · 请'" in js
    assert "'联系客服购买'" in js


def test_copy_has_an_execcommand_fallback():
    """兜底是**必需项不是加固**:本项目 cookie_secure 默认 auto、部署形态明确
    包含 http,而 navigator.clipboard 在非安全上下文根本不存在。"""
    js = _app_js()
    m = re.search(r"async function copyText\(txt\)\{(.*?)\n\}", js, re.S)
    assert m, "未找到 copyText"
    body = m.group(1)
    assert "navigator.clipboard" in body and "execCommand" in body
    assert "display:none" not in body, \
        "藏 textarea 不能用 display:none —— 那样 select() 是空操作,复制必失败"


def test_frontend_cache_version_bumped():
    """app.js/app.css 改了就必须 bump ?v,否则老页面继续跑旧包、等于没部署。"""
    if not INDEX.is_file():
        pytest.skip("前端不在本仓")
    idx = INDEX.read_text(encoding="utf-8")
    for stale in ("4.9.6",):
        assert f"app.js?v={stale}" not in idx and f"app.css?v={stale}" not in idx, \
            f"app.js/app.css 已改(客服联系方式)却仍挂 ?v={stale}"
    vs = set(re.findall(r"app\.(?:js|css)\?v=([0-9.]+)", idx))
    assert len(vs) == 1, f"index.html 里 js/css 版本不一致:{vs}"


# ══════════════════════════════════════════════════════════════════════════════
# G. 单一真源(自审事故的回归钉)
# ══════════════════════════════════════════════════════════════════════════════
def test_banner_overview_and_delivery_never_disagree(_cfg, capsys):
    """★ 回归钉,来自一次真实的自审事故。

    收敛逻辑原本在 cs_info / startup_report / overview 三处各写了一遍,而横幅
    那份**漏传了 drop_if_over** —— 于是一个已被 fail-closed 丢弃的号码,在启动
    日志里被显示成「联系方式已配置 · 客服QQ 999…」。横幅的全部价值就是让运维在
    用户找上门之前看到真相;它一旦和真相不一致,比没有横幅更坏。

    本钉不扫源码(那只能证明"长得像"),而是让三条路**对同一份配置各说一次**,
    逐项比对。任何一处再分叉,这里当场变红。
    """
    cases = [
        {"jf_cs_value": "800123456", "jf_cs_label": "客服QQ"},
        {"jf_cs_value": "9" * 200},                       # 超长 ⇒ fail-closed
        {"jf_cs_url": "https://" + "a" * 300},            # 超长链接 ⇒ fail-closed
        {"jf_cs_url": "mqqwpa://im/chat"},                # 非白名单 ⇒ 丢弃
        {"jf_cs_label": "客服", "jf_cs_note": "09:00"},   # 只有装饰项 ⇒ 整块不存在
        {"jf_cs_value": " 800 123 ", "jf_cs_url": "https://kf.example.com"},
    ]
    for kw in cases:
        for k in ("jf_cs_label", "jf_cs_value", "jf_cs_url", "jf_cs_note"):
            setattr(_cfg, k, kw.get(k, ""))
        delivered = userauth.cs_info(_Req({"host": "a.example"}))   # 用户真正拿到的
        resolved = userauth.cs_resolve()                            # 横幅/概览读的
        assert delivered == resolved, f"{kw}: 下发={delivered} 概览={resolved}"
        # 横幅要么不提,要么提的就是 resolved 里的那个值 —— 不许显示第三种东西
        capsys.readouterr()
        jfvip.startup_report()
        out = capsys.readouterr().out
        raw_v = str(kw.get("jf_cs_value", "")).strip()
        if raw_v and not resolved.get("value"):
            assert "整条丢弃" in out, f"{kw}: 号码被丢弃却没告知"
            assert raw_v not in out.split("⚠️")[0], f"{kw}: 横幅仍在宣传已丢弃的号码"
        if resolved.get("value"):
            assert resolved["value"] in out, f"{kw}: 横幅漏报生效号码"


def test_resolve_has_no_site_gate_but_info_does(_cfg):
    """两者的**唯一**区别就是站点闸 —— 管理台看配置解析结果,用户看下发结果。"""
    _cfg.jf_cs_value = "800123456"
    _cfg.jf_direct_hosts = "jiufa.example.com"
    assert userauth.cs_resolve()["value"] == "800123456", "概览不该被站点闸挡住"
    assert userauth.cs_info(_Req({"host": "a.agent.example"})) == {}
    assert userauth.cs_info(_Req({"host": "jiufa.example.com"})) == userauth.cs_resolve()


# ══════════════════════════════════════════════════════════════════════════════
# H. 对比度(自审改正的回归钉)
# ══════════════════════════════════════════════════════════════════════════════
def _contrast(hex_a: str, hex_b: str = "ffffff") -> float:
    """WCAG 2.x 相对亮度对比。本文件既有注释自称 #64756b=4.89、#8f6a09=4.96,
    本实现对这两个基准算出同值 —— 口径与项目一致,不是另一套算法。"""
    def lum(h):
        h = h.lstrip("#")
        cs = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
        f = lambda v: v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
        r, g, b = map(f, cs)
        return 0.2126 * r + 0.7152 * g + 0.0722 * b
    la, lb = lum(hex_a), lum(hex_b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def test_contrast_method_matches_project_baseline():
    """先自证算法口径:对项目注释里已实算过的两个色,必须算出同一个数。"""
    assert round(_contrast("#64756b"), 2) == 4.89
    assert round(_contrast("#8f6a09"), 2) == 4.96


def test_cs_colours_meet_wcag():
    """★ 自审改正的回归钉。初版两处不达标,而**页面上看不出来**:
      · .vip-cs-note 用 #7d8d84 = 3.49:1,达不到 AA 正文的 4.5(11.5px 远够不上
        "大字例外"的 18.66px 粗体 / 24px);
      · .vip-cs-copy 描边 #cfdad4 = 1.44:1。这颗按钮刻意是「描边而非填色」的弱
        视觉,于是**描边就是它作为控件的唯一可见标识** —— WCAG 2.1 §1.4.11
        非文本对比要求 ≥3:1,1.44 等于把"这是个按钮"这件事藏起来了。
    颜色改回归是最容易发生、也最不容易被发现的一类,故钉住实算值而非色号。
    """
    css = (ROOT / "assets" / "app.css").read_text(encoding="utf-8")
    if ".vip-cs-copy" not in css:
        pytest.skip("前端不在本仓")
    import re as _re

    def colour_of(sel: str, prop: str) -> str:
        m = _re.search(_re.escape(sel) + r"\{(.*?)\}", css, _re.S)
        assert m, f"未找到 {sel}"
        body = _re.sub(r"/\*.*?\*/", "", m.group(1), flags=_re.S)   # 剥注释:里面写着旧色号
        c = _re.search(prop + r"\s*:\s*(?:[^;]*?)(#[0-9a-fA-F]{6})", body)
        assert c, f"{sel} 的 {prop} 未取到色值:{body!r}"
        return c.group(1)

    note = colour_of(".vip-cs-note", "color")
    assert _contrast(note) >= 4.5, f".vip-cs-note {note} = {_contrast(note):.2f}:1 < 4.5(AA 正文)"
    txt = colour_of(".vip-cs-copy", "color")
    assert _contrast(txt) >= 4.5, f".vip-cs-copy 文字 {txt} = {_contrast(txt):.2f}:1 < 4.5"
    border = colour_of(".vip-cs-copy", "border")
    assert _contrast(border) >= 3.0, \
        f".vip-cs-copy 描边 {border} = {_contrast(border):.2f}:1 < 3.0(WCAG 1.4.11 非文本对比)"


# ══════════════════════════════════════════════════════════════════════════════
# I. ASGI 端到端(第四轮自审补的覆盖缺口)
# ------------------------------------------------------------------------------
# ★ 此前本文件全部在直调 cs_info(),**三条 return 路径的接线一次都没被验证过**。
#   那意味着:键名写错、`if _cs:` 放错分支、漏了某一条 return —— 上面 69 条钉
#   会全部照绿。接线恰恰是最容易出错的一层(同 test_jfvip_asgi.py 开篇的原话)。
# 零外部依赖:会话校验打桩,不连任何真实服务。
# ══════════════════════════════════════════════════════════════════════════════
import httpx                                              # noqa: E402
import app.web as web                                     # noqa: E402


@pytest.fixture
def asgi_cfg(monkeypatch):
    cfg = UserAuthCfg(host="h", port=3306, db="d", user="u", password="p",
                      charset="gbk", jf_vip_enabled=True, cache_ttl_s=0.0)
    cfg.jf_cs_label, cfg.jf_cs_value = "客服QQ", "800123456"
    cfg.jf_cs_url, cfg.jf_cs_note = "https://kf.example.com/chat", "09:00-24:00"
    monkeypatch.setattr(userauth.UA, "cfg", cfg, raising=False)
    monkeypatch.setattr(userauth.UA, "pool", object(), raising=False)

    async def _validate(token):
        return ("auth_required", None, {}) if not token else \
            ("ok", userauth.Principal(
                user_id=7, user_name="u7", session_id=1, token_hash="h",
                due_time_iso="2027-01-01T00:00:00", dd_alive=True,
                jf_vip_until_iso="2026-12-01T00:00:00", jf_alive=True), {})
    monkeypatch.setattr(userauth, "validate", _validate)
    return cfg


def _cli():
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=web.app),
                             base_url="http://t")


async def _session(host: str, cookie: str = "") -> dict:
    async with _cli() as c:
        h = {"Host": host}
        if cookie:
            h["Cookie"] = f"jf_user_sid={cookie}"
        r = await c.get("/api/auth/session", headers=h)
        assert r.status_code == 200, r.text
        return r.json()


@pytest.mark.asyncio
async def test_asgi_contact_present_when_authed(asgi_cfg):
    """已登录路径(三条 return 之一)。"""
    body = await _session("jiufa.example.com", cookie="tok")
    assert body["authed"] is True
    assert body["contact"] == {"label": "客服QQ", "value": "800123456",
                               "url": "https://kf.example.com/chat",
                               "note": "09:00-24:00"}


@pytest.mark.asyncio
async def test_asgi_contact_present_when_not_authed(asgi_cfg):
    """★ 未登录路径也必须带 —— 客服将来要用在**登录门**上(「账号已到期」),
    那正是按定义没有会话的时刻。漏这一条,未来的复用点会静默拿不到值。"""
    body = await _session("jiufa.example.com")
    assert body["authed"] is False
    assert body["contact"]["value"] == "800123456"


@pytest.mark.asyncio
async def test_asgi_contact_present_when_login_system_disabled(asgi_cfg, monkeypatch):
    """★ 第三条 return(登录系统未启用的早返回)。这条最容易被漏掉,
    而漏了的表现是「某些部署下客服栏莫名其妙不出现」—— 最难查的一类。"""
    asgi_cfg.host = ""                       # enabled() 转假
    body = await _session("jiufa.example.com")
    assert body["enabled"] is False
    assert body["contact"]["value"] == "800123456"


@pytest.mark.asyncio
async def test_asgi_mirror_host_response_body_has_no_contact(asgi_cfg):
    """★★ 最硬的一条:镜像站的**响应报文原文**里搜不到那串号码。

    前面所有断言都可以靠"前端不渲染"绕过去,只有这一条能证明它压根没被下发。
    """
    asgi_cfg.jf_direct_hosts = "jiufa.example.com"
    async with _cli() as c:
        r = await c.get("/api/auth/session", headers={"Host": "a.agent.example"})
        assert "contact" not in r.json(), r.json()
        assert "800123456" not in r.text, "镜像站响应报文里出现了平台客服号"
        assert "kf.example.com" not in r.text
        # 反向自证:同一份配置在直营站必须拿得到,否则上面的"没有"可能只是没生效
        r2 = await c.get("/api/auth/session", headers={"Host": "jiufa.example.com"})
        assert "800123456" in r2.text


@pytest.mark.asyncio
async def test_asgi_unconfigured_omits_the_key_entirely(asgi_cfg):
    """未配置 ⇒ 连 contact 键都不出现(不是空对象)——旧前端零影响。"""
    asgi_cfg.jf_cs_value = asgi_cfg.jf_cs_url = ""
    body = await _session("jiufa.example.com", cookie="tok")
    assert "contact" not in body


@pytest.mark.asyncio
async def test_asgi_bad_url_is_dropped_over_the_wire(asgi_cfg):
    """白名单在**下发边界**上生效:报文里不得出现 javascript:。"""
    asgi_cfg.jf_cs_url = "javascript:alert(1)"
    async with _cli() as c:
        r = await c.get("/api/auth/session", headers={"Host": "t"})
        assert "javascript" not in r.text.lower()
        assert r.json()["contact"] == {"label": "客服QQ", "value": "800123456",
                                       "note": "09:00-24:00"}


@pytest.mark.asyncio
async def test_asgi_session_is_never_cacheable(asgi_cfg):
    """★ 第四轮自审补的加固。依据是 RFC 9111 / MDN 的明文,不是保守习惯:

      · 共享缓存「不得存储」的豁免**只绑定 Authorization 请求头** —— 本项目走
        Cookie,不在豁免内。没有显式指令时,中间缓存**可以合法地**存下本响应
        并拿去满足别人的请求;
      · RFC 9111 安全考量一节专门点名 `Set-Cookie` **不抑制缓存**。
        「这条路在登录后面」不是任何一条被承认的缓存指令。

    而本响应是全站个人化最强的一个,4.4.2 起还带**按 Host 裁剪**的客服联系方式
    —— 一个忽略 Host 的错配缓存会把直营站的响应回给镜像站。
    三条 return 路径都必须带,故逐条验。
    """
    async with _cli() as c:
        for kw in ({}, {"Cookie": "jf_user_sid=tok"}):
            r = await c.get("/api/auth/session", headers={"Host": "t", **kw})
            cc = r.headers.get("cache-control", "")
            assert "no-store" in cc and "private" in cc, f"{kw}: Cache-Control={cc!r}"
    asgi_cfg.host = ""                       # 第三条:登录系统未启用的早返回
    async with _cli() as c:
        r = await c.get("/api/auth/session", headers={"Host": "t"})
        assert r.json()["enabled"] is False
        assert "no-store" in r.headers.get("cache-control", "")


def test_no_blanket_no_store_middleware():
    """★ 配套约束:**刻意不**给全部 /api/* 一刀切加 no-store。

    实地核查:`/api/rooms/{room}/history` 在冻结窗上有意下发
    `public, max-age=604800, immutable`(仅 VIP 可达 —— basic 带 until 会先被 403;
    内容是按 URI 定键的整房历史,不含个人数据)。一刀切会把那处「同一历史日
    7 天零重复传输」的优化白白打掉。本钉防的是将来有人"顺手"加中间件。
    """
    src = (Path(__file__).resolve().parents[1] / "app" / "web.py").read_text(encoding="utf-8")
    assert "public, max-age=604800, immutable" in src, \
        "history 冻结窗的 immutable 缓存不见了 —— 若确系有意移除,请同步删掉本钉"
