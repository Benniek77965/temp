"""
test_jfvip_sse.py — SSE 推送通道的档位裁剪(4.2.0 复审补)
================================================================================
背景(必读,别再踩):首版实现只给 **REST 拉取**接了 VIP 闸,漏了 **SSE 推送**。
worker 每局经 Redis 推 `pred-updated`,载荷 = {settled:{id,n,v}, next:{target,
main,guard}};SSE 用 `data=data` **原样转发** —— basic 档用户只要开着连接,
下一局主2防2 就明文躺在 EventStream 里(DevTools 一开即见,脚本客户端直接订阅)。

修复时又踩到第二个坑:`_sse_tier` 定义在外层 events(),而心跳分支要**赋值**给它,
不声明 `nonlocal` 就会被 Python 当成 gen() 的局部变量 → 转发处读取抛
UnboundLocalError → **整条 SSE 在第一个事件就死**(所有档位皆然,租约随之停摆)。

本文件把这两条都钉死。
"""
from __future__ import annotations

import ast
import json
import re
from pathlib import Path

from tests._srcscan import js_code, py_code

APP = Path(__file__).resolve().parent.parent / "app"


def _gen_source() -> str:
    """取出 events() 内嵌 gen() 的源码。"""
    src = (APP / "web.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    ev = next((n for n in ast.walk(tree)
               if isinstance(n, ast.AsyncFunctionDef) and n.name == "events"), None)
    assert ev is not None, "web.events 丢失"
    gen = next((n for n in ast.walk(ev)
                if isinstance(n, ast.AsyncFunctionDef) and n.name == "gen"), None)
    assert gen is not None, "events 内的 gen() 丢失"
    seg = ast.get_source_segment(src, gen) or ""
    # ★ 一律剥掉整行注释再交给用例。本轮已被同一类假阳性咬过三次:
    #   解释性注释里出现 "UPDATE tb_user" / "_vip_guard" / "continue" 等字样,
    #   被朴素字符串扫描判成违规。注释不会执行,把它算进代码是**假阳性**。
    return "\n".join("" if ln.lstrip().startswith("#") else ln
                      for ln in seg.split("\n"))


def test_sse_strips_prediction_for_basic():
    """转发处必须按档位剥掉 pred.next。"""
    g = _gen_source()
    assert '_sse_tier == "basic"' in g, "SSE 转发处缺档位判定 —— 主防号位会明文外泄"
    assert 'pop("next"' in g, "SSE 未剥掉 pred.next"


def test_sse_keeps_settled_for_basic():
    """**只**剥 next,不能连 settled 一起掐 —— 那是 basic 档有权看的命中判定
    (需求原文:『灵机推演近 100 局的命中信息』)。整条掐掉会让 basic 档的
    命中串停止更新,是把功能做残。"""
    g = _gen_source()
    assert 'pop("settled"' not in g, "不该剥 settled(basic 档有权看命中判定)"


def test_sse_tier_declared_nonlocal():
    """★ 回归钉:gen() 内赋值 _sse_tier 必须先 nonlocal,否则 UnboundLocalError
    会让**整条 SSE 在第一个事件就死**(所有档位),且租约停止续租。
    这个 bug 靠 `import OK` 和纯 JSON 自证都测不出来 —— 只在嵌套生成器运行时暴露。"""
    g = _gen_source()
    assigns = re.search(r"^\s*_sse_tier\s*=", g, re.M)
    if assigns:
        assert re.search(r"^\s*nonlocal\s+.*\b_sse_tier\b", g, re.M), (
            "gen() 内对 _sse_tier 有赋值却未声明 nonlocal —— "
            "会抛 UnboundLocalError 打死整条 SSE")


def test_sse_strip_never_uses_continue():
    """★ 回归钉:剥离分支**绝不可** continue。

    web.py 的「独立续租节拍」原注释写明:它置于两分支汇合处,
    「唯广播触发分支 continue 跳过 —— 它刚亲手 renew 过」。
    若剥空的事件也 continue,繁忙房里 _push_next_prediction 发出的
    **只含 next** 的独立事件会被连续跳过 → 租约得不到续租 → TTL 到期消失。
    正解:剥空就删掉 pred 键、事件照常下发(前端 applyPredPush 对 undefined
    直接 return),控制流与 4.1.2 逐字节相同。
    """
    g = _gen_source()
    m = re.search(r'if _sse_tier == "basic".*?data = json\.dumps\(ev', g, re.S)
    assert m, "未找到 SSE 档位剥离分支"
    assert "continue" not in m.group(0), (
        "剥离分支里出现 continue —— 会跳过独立续租节拍,繁忙房租约会消失")


def test_pred_payload_shape_documented():
    """worker 侧推送体结构若变(比如把 main 挪进 settled),本文件的剥离逻辑会失效。
    这里钉住 worker 的载荷形状,变了就红,提醒同步改 SSE 裁剪。"""
    w = py_code(APP / "worker.py")
    assert '"pred": pred_push' in w or '"pred": {"next": nxt}' in w, \
        "worker 推送体结构变了 —— 请同步核对 SSE 的档位裁剪逻辑"


def test_strip_logic_behaviour():
    """纯逻辑自证:同一份载荷,vip 全量 / basic 只剩 settled。"""
    ev = {"type": "pred-updated", "roomId": "321", "roundId": "1",
          "pred": {"settled": {"id": "1", "n": 3, "v": "main"},
                   "next": {"target": "2", "main": [3, 7], "guard": [1, 9]}}}

    def strip(e, tier):
        e = json.loads(json.dumps(e))
        if tier == "basic" and isinstance(e.get("pred"), dict):
            p = dict(e["pred"])
            p.pop("next", None)
            if not p:
                return None
            e["pred"] = p
            e["vipLocked"] = True
        return e

    assert strip(ev, "vip")["pred"]["next"]["main"] == [3, 7]
    b = strip(ev, "basic")
    assert "next" not in b["pred"], "basic 档仍能拿到下一局号位"
    assert b["pred"]["settled"]["v"] == "main", "basic 档的命中判定被误伤"
    assert b["vipLocked"] is True
    # 只有 next 的载荷 → 剥空
    assert strip({"type": "pred-updated", "pred": {"next": {"main": [1]}}}, "basic") is None
