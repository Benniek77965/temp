"""
test_predictor_bridge.py — 预测引擎复用回归测试(不依赖 Redis/PG/网络)
================================================================================
用户要求「不改预测逻辑」。本测试锁定桥接层对旧引擎的复用契约:
  · 妖兽解析 (official_id, name) → (oid, name, custom_id, multiplier) 正确;
  · run_prediction 产出结构完整(main/guard/models/ens),编号落在 1..9;
  · kv 无状态往返:处理某局把权重变更吐回 dirty,喂回下一次调用后权重继续推进
    (即「读 PG 播种 → 计算 → 刷回 PG」链路可复现,不依赖常驻内存);
  · update_after_settle 会产生权重变更(Hedge 步进生效)。

若旧引擎目录缺失(STA_ENGINE_DIR 未设且默认路径不存在),整文件跳过。
"""
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

_ENGINE = os.environ.get("STA_ENGINE_DIR") or str(
    Path(__file__).resolve().parent.parent.parent / "jiufa_data")
pytestmark = pytest.mark.skipif(
    not (Path(_ENGINE) / "spell_tamer_monitor.py").exists(),
    reason="旧预测引擎不可用(STA_ENGINE_DIR 未设或默认路径无 spell_tamer_monitor.py)")


@pytest.fixture
def bridge():
    from app.predictor_bridge import PredictorBridge
    cfg = {"enabled": True, "main_k": 2, "guard_k": 2}
    return PredictorBridge(cfg, {})


def test_resolve_beast_by_official_id(bridge):
    oid, name, cid, mult = bridge.resolve_beast(3, "沧溟龙")
    assert oid == 3 and name == "沧溟龙"
    assert cid == 9          # DEFAULT_CUSTOM_IDS: 沧溟龙 = 9
    assert mult == 500


def test_resolve_beast_by_name_only(bridge):
    oid, name, cid, mult = bridge.resolve_beast(None, "金羽皇")
    assert name == "金羽皇" and cid == 6 and mult == 100


def test_run_prediction_shape_and_range(bridge):
    seq = [1, 2, 3, 4, 5, 6, 7, 8, 9] * 6  # 54 局历史
    result, dirty = bridge.run_prediction("room-x", seq, {})
    assert set(["main", "guard"]).issubset(result.keys())
    for k in ("main", "guard"):
        assert isinstance(result[k], list) and result[k]
        assert all(1 <= n <= 9 for n in result[k])
    # 主/护不重叠
    assert not (set(result["main"]) & set(result["guard"]))


def test_kv_roundtrip_advances_weights(bridge):
    """无状态往返:第一次结算吐回权重变更,喂回后第二次结算应基于新权重继续推进。"""
    seq = [1, 2, 3, 4, 5, 6, 7, 8, 9] * 4
    r1, _ = bridge.run_prediction("room-y", seq, {})
    detail = {"models": r1.get("models", {}), "ens": r1.get("ens", [])}

    kv: dict[str, str] = {}
    d1 = bridge.update_after_settle("room-y", detail, actual_cid=3, kv_in=kv)
    assert d1, "首次结算应产生权重/探索态变更"
    kv.update(d1)

    # 用推进后的 kv 再算一次预测,应正常产出(链路可复现)
    r2, dirty2 = bridge.run_prediction("room-y", seq + [3], kv)
    assert r2["main"] and all(1 <= n <= 9 for n in r2["main"])

    # 再结算一次,仍应能推进(权重键持续存在)
    d2 = bridge.update_after_settle("room-y", detail, actual_cid=5, kv_in=kv)
    assert d2


def test_empty_sequence_is_safe(bridge):
    result, _ = bridge.run_prediction("room-z", [], {})
    assert "main" in result and "guard" in result
