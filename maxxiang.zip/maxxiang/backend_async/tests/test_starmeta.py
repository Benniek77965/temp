"""starmeta 纯函数单测:头像归一三规则 + 页面解析(锁定与旧 server.py 的行为对齐)。"""
from app.starmeta import _parse_page, _relay_logo


# ── _relay_logo:对齐旧 server.py 的三条规则 ─────────────────────────────────
def test_relay_logo_protocol_relative():
    # 与旧 server.py 逐字节对拍:// 先补 https:,kgimg 去点规则只匹配 http://,
    # 故协议相对的 kgimg 链接保留点号。
    assert _relay_logo("//p3.fx.kgimg.com/v2/fxuserlogo/abc.jpg") == \
        "https://p3.fx.kgimg.com/v2/fxuserlogo/abc.jpg"


def test_relay_logo_kgimg_domain_rewrite():
    # http://p{N}.fx.kgimg.com/... → https://p{N}fx.kgimg.com/...(去点并升 https)
    assert _relay_logo("http://p2.fx.kgimg.com/x/y.png") == \
        "https://p2fx.kgimg.com/x/y.png"


def test_relay_logo_plain_http_to_https():
    assert _relay_logo("http://img.example.com/a.jpg") == \
        "https://img.example.com/a.jpg"


def test_relay_logo_passthrough_and_empty():
    assert _relay_logo("https://ok.example.com/a.jpg") == "https://ok.example.com/a.jpg"
    assert _relay_logo("") == ""


# ── _parse_page:普通直播页 ───────────────────────────────────────────────────
NORMAL_PAGE = """
<html><head><title>小明 | 繁星直播</title></head>
<body>
<script>var cfg={"roomId":2678075};</script>
<a _userkugouid="880001">小明</a>
<img src="//p3.fx.kgimg.com/v2/fxuserlogo/aaa.jpg_100x100.jpg">
</body></html>
"""


def test_parse_normal_page():
    out = _parse_page(NORMAL_PAGE)
    assert out["roomId"] == "2678075"
    assert out["kugouId"] == 880001
    assert out["nickname"] == "小明"
    assert out["channel"] is False
    assert out["logoUrl"].startswith("https://")
    assert "fxuserlogo/aaa" in out["logoUrl"]


# ── _parse_page:官方频道页(短号 302 目标;isChannelRoom) ───────────────────
CHANNEL_PAGE = """
<html><body><script>
window.__DATA__ = { isChannelRoom : true, roomStarId : '990077',
                    roomId : '2678075' };
</script></body></html>
"""


def test_parse_channel_page():
    out = _parse_page(CHANNEL_PAGE)
    assert out["channel"] is True
    assert out["roomId"] == "2678075"
    assert out["kugouId"] == 990077


def test_parse_empty_page_yields_nothing():
    out = _parse_page("<html><title>繁星</title></html>")
    assert out["roomId"] == "" and out["kugouId"] == 0 and out["nickname"] == ""
