"""
test_admin_kg_accounts.py — 酷狗账号库编辑端点(/api/admin/auth/accounts)
================================================================================
覆盖:GET 掩码(明文永不出网)· PUT 留空沿用旧密 / 改密 / 新增缺密校验 ·
顶层 '_' 模板注释键写回保留 · env:VAR 展示 · 只读落盘失败 409。
ASGI 直连,STA_KG_ACCOUNTS 指向 tmp_path,零外部依赖。
"""
import json
import os

import httpx
import pytest
from fastapi import FastAPI

from app import admin_api
from app import admin_auth as aa

SEED = {
    "_说明": "模板注释应被保留",
    "sync_target": "cos://backup",   # 用户自定义非下划线顶层键,同样须幸存
    "accounts": [
        {"username": "u1", "password": "p1", "mid": "a" * 32,
         "note": "主", "enabled": True},
        {"username": "u2", "password": "env:KG_PWD_2", "mid": "",
         "note": "备", "enabled": False},
    ],
}


@pytest.fixture()
def env(monkeypatch, tmp_path):
    acc = tmp_path / "accounts.json"
    acc.write_text(json.dumps(SEED, ensure_ascii=False), encoding="utf-8")
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "pw-kg")
    monkeypatch.setenv("STA_KG_ACCOUNTS", str(acc))
    monkeypatch.delenv("STA_ADMIN_IP_ALLOW", raising=False)
    aa._reset_for_tests()
    app = FastAPI()
    app.include_router(admin_api.router, prefix="/api/admin")   # 5.3.0:前缀在挂载时给
    yield app, acc
    aa._reset_for_tests()


async def _login(c):
    j = (await c.post("/api/admin/login", json={"password": "pw-kg"})).json()
    return {"X-Admin-Session": j["token"], "X-Admin-CSRF": j["csrf"]}


def _client(app):
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=app),
                             base_url="http://t")


async def test_get_masks_passwords(env):
    app, _ = env
    async with _client(app) as c:
        hdr = await _login(c)
        r = await c.get("/api/admin/auth/accounts", headers=hdr)
        assert r.status_code == 200
        j = r.json()
        assert j["exists"] and j["writable"]
        assert "p1" not in r.text                      # 明文绝不出网
        a1, a2 = j["accounts"]
        assert a1 == {"username": "u1", "mid": "a" * 32, "note": "主",
                      "enabled": True, "password_set": True, "password_env": ""}
        assert a2["password_env"] == "KG_PWD_2" and a2["enabled"] is False


async def test_put_keep_change_add_remove_and_preserve_meta(env):
    app, acc = env
    async with _client(app) as c:
        hdr = await _login(c)
        body = {"accounts": [
            {"username": "u1", "password": "", "mid": "b" * 32,
             "note": "改备注", "enabled": True},                  # 留空沿用 p1
            {"username": "u3", "password": "p3", "mid": "",
             "note": "", "enabled": True},                        # 新增(u2 被删)
        ]}
        r = await c.put("/api/admin/auth/accounts", headers=hdr, json=body)
        assert r.status_code == 200, r.text
        j = r.json()
        assert j["added"] == ["u3"] and j["removed"] == ["u2"]
        assert j["pwd_changed"] == [] and j["total"] == 2
        disk = json.loads(acc.read_text(encoding="utf-8"))
        assert disk["_说明"] == "模板注释应被保留"                 # 顶层注释键不丢
        assert disk["sync_target"] == "cos://backup"              # 自定义顶层键不丢
        by = {a["username"]: a for a in disk["accounts"]}
        assert by["u1"]["password"] == "p1"                       # 沿用成功
        assert by["u1"]["mid"] == "b" * 32 and by["u1"]["note"] == "改备注"
        assert by["u3"]["password"] == "p3" and "u2" not in by


async def test_put_change_password_audited_by_name_only(env):
    app, acc = env
    async with _client(app) as c:
        hdr = await _login(c)
        body = {"accounts": [{"username": "u1", "password": "newpw",
                              "mid": "", "note": "", "enabled": True}]}
        r = await c.put("/api/admin/auth/accounts", headers=hdr, json=body)
        j = r.json()
        assert j["pwd_changed"] == ["u1"] and "newpw" not in json.dumps(
            {k: j[k] for k in ("added", "removed", "pwd_changed", "total")})
        assert json.loads(acc.read_text(encoding="utf-8"))[
            "accounts"][0]["password"] == "newpw"


async def test_put_validation_errors(env):
    app, _ = env
    async with _client(app) as c:
        hdr = await _login(c)
        r = await c.put("/api/admin/auth/accounts", headers=hdr, json={
            "accounts": [{"username": "brand-new", "password": ""}]})
        assert r.status_code == 400 and "必须填写密码" in r.text
        r2 = await c.put("/api/admin/auth/accounts", headers=hdr, json={
            "accounts": [{"username": "u1", "password": ""},
                         {"username": "u1", "password": "x"}]})
        assert r2.status_code == 400 and "重复" in r2.text


async def test_put_mid_soft_warning_not_blocking(env):
    app, acc = env
    async with _client(app) as c:
        hdr = await _login(c)
        r = await c.put("/api/admin/auth/accounts", headers=hdr, json={
            "accounts": [{"username": "u1", "password": "",
                          "mid": "不是hex", "note": "", "enabled": True}]})
        assert r.status_code == 200                           # 软校验:放行
        j = r.json()
        assert j["warnings"] and "32 位十六进制" in j["warnings"][0]
        assert json.loads(acc.read_text(encoding="utf-8"))[
            "accounts"][0]["mid"] == "不是hex"                # 尊重用户输入,照写


async def test_refresh_now_writes_trigger(env):
    app, acc = env
    trigger = os.path.join(os.path.dirname(str(acc)), "refresh_now")
    async with _client(app) as c:
        hdr = await _login(c)
        r = await c.post("/api/admin/auth/refresh_now", headers=hdr, json={})
        assert r.status_code == 200 and r.json()["ok"] is True
        assert os.path.isfile(trigger)                        # 触发文件已落盘
        assert "admin@" in open(trigger, encoding="utf-8").read()
        r2 = await c.post("/api/admin/auth/refresh_now", headers=hdr, json={})
        assert r2.status_code == 200 and r2.json().get("pending") is True  # 防连点
        os.unlink(trigger)                                # 模拟 login 已消费
        r3 = await c.post("/api/admin/auth/refresh_now", headers=hdr, json={})
        assert r3.status_code == 200 and os.path.isfile(trigger)  # 可再次触发
        no_csrf = {"X-Admin-Session": hdr["X-Admin-Session"]}
        assert (await c.post("/api/admin/auth/refresh_now", headers=no_csrf,
                             json={})).status_code == 403


async def test_refresh_now_readonly_409(env, monkeypatch):
    app, _ = env
    import builtins
    real_open = builtins.open
    def deny(path, *a, **k):
        if str(path).endswith("refresh_now"):
            raise PermissionError(30, "Read-only file system")
        return real_open(path, *a, **k)
    monkeypatch.setattr(builtins, "open", deny)
    async with _client(app) as c:
        hdr = await _login(c)
        r = await c.post("/api/admin/auth/refresh_now", headers=hdr, json={})
        assert r.status_code == 409 and r.json()["error"] == "not_writable"


async def test_put_readonly_maps_409(env, monkeypatch):
    app, _ = env
    def boom(*a, **k):
        raise PermissionError(13, "Read-only file system")
    monkeypatch.setattr(os, "replace", boom)
    async with _client(app) as c:
        hdr = await _login(c)
        r = await c.put("/api/admin/auth/accounts", headers=hdr, json={
            "accounts": [{"username": "u1", "password": ""}]})
        assert r.status_code == 409 and r.json()["error"] == "not_writable"


async def test_requires_session_and_csrf(env):
    app, _ = env
    async with _client(app) as c:
        assert (await c.get("/api/admin/auth/accounts")).status_code == 401
        hdr = await _login(c)
        no_csrf = {"X-Admin-Session": hdr["X-Admin-Session"]}
        r = await c.put("/api/admin/auth/accounts", headers=no_csrf,
                        json={"accounts": []})
        assert r.status_code == 403
