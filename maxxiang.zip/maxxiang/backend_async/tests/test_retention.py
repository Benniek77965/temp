"""数据保留(retention)与北京时间口径的单元测试(纯函数,无需 PG/Redis)。"""
from __future__ import annotations

import pytest

from app.constants import BEIJING_TZ
from app.db import _build_purge_sql, _iso, retention_cutoff_ms
from app.settings import RetentionCfg


# ── 保留窗口起点 ─────────────────────────────────────────────────────────────
def test_retention_cutoff_ms_seven_days():
    now = 1_700_000_000_000
    assert retention_cutoff_ms(now, 7) == now - 7 * 86_400_000


def test_retention_cutoff_ms_fractional_days():
    now = 1_700_000_000_000
    assert retention_cutoff_ms(now, 0.5) == now - 43_200_000


# ── 分批 DELETE SQL 构造 ──────────────────────────────────────────────────────
def test_build_purge_sql_shape():
    sql = _build_purge_sql("rounds", 50_000)
    assert sql.startswith("DELETE FROM rounds")
    assert "round_id < $1" in sql          # 以毫秒时间戳裁剪
    assert "LIMIT 50000" in sql            # 分批
    assert "ctid" in sql                   # ctid 限批(Postgres DELETE 无 LIMIT)


def test_build_purge_sql_predictions():
    sql = _build_purge_sql("predictions", 123)
    assert "DELETE FROM predictions" in sql and "LIMIT 123" in sql


def test_build_purge_sql_rejects_unknown_table():
    with pytest.raises(ValueError):
        _build_purge_sql("rooms", 10)      # 名录/状态表绝不允许被清理


# ── 配置默认值(每房默认保留 1 天) ─────────────────────────────────────────────
def test_retention_cfg_defaults():
    cfg = RetentionCfg()
    assert cfg.days == 1.0
    assert cfg.sweep_interval_s == 3600
    assert cfg.batch_rows == 50_000
    assert cfg.max_batches == 400


# ── 北京时间口径 ─────────────────────────────────────────────────────────────
def test_iso_pinned_to_beijing():
    # 2024-01-01 00:00:00 UTC == 2024-01-01 08:00:00 +08:00
    assert _iso(1_704_067_200_000) == "2024-01-01T08:00:00+08:00"


def test_engine_time_helpers_pinned_to_beijing():
    import importlib.util
    import os
    eng_path = os.path.join(os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__)))), "jiufa_data",
        "spell_tamer_monitor.py")
    spec = importlib.util.spec_from_file_location("_st_engine_tz_test", eng_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)                       # type: ignore[union-attr]
    ms = 1_704_067_200_000                             # 2024-01-01 00:00 UTC
    assert mod.ms_to_date(ms) == "2024-01-01"          # 北京 08:00,仍是 1 月 1 日
    assert mod.ms_to_local(ms, "%H:%M:%S") == "08:00:00"
    # 北京日界:2024-01-01 的 [00:00, 24:00) 应从 2023-12-31T16:00Z 起
    d0, d1 = mod.day_bounds_ms("2024-01-01")
    assert d0 == 1_704_038_400_000 and d1 - d0 == 86_400_000
    assert mod.BEIJING_TZ.utcoffset(None).total_seconds() == 8 * 3600
    assert BEIJING_TZ.utcoffset(None) == mod.BEIJING_TZ.utcoffset(None)
