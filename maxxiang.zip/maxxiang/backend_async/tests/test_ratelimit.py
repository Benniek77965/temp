"""
test_ratelimit.py — 分布式令牌桶集成测试
================================================================================
需要一个可用的 Redis(默认 redis://localhost:6379/15,用 15 号库避免污染业务库;
可用 STA_TEST_REDIS_URL 覆盖)。无 Redis 时整文件跳过。

核对:
  · 冷启动桶满 → 连续申领 burst 枚均成功,第 burst+1 枚失败且给出正的建议等待;
  · 等待一段时间后按 rate 线性补充,可再申领;
  · 不超发:并发申领的成功数不超过桶容量。
"""
import asyncio
import os
import time

import pytest

REDIS_URL = os.environ.get("STA_TEST_REDIS_URL", "redis://localhost:6379/15")


async def _make_redis():
    try:
        import redis.asyncio as aioredis
    except Exception:
        return None
    try:
        r = aioredis.from_url(REDIS_URL, encoding="utf-8", decode_responses=True)
        await asyncio.wait_for(r.ping(), timeout=1.0)
        return r
    except Exception:
        return None


@pytest.fixture
async def redis_client():
    r = await _make_redis()
    if r is None:
        pytest.skip(f"Redis 不可用({REDIS_URL}) — 跳过令牌桶集成测试")
    yield r
    await r.aclose()


@pytest.mark.asyncio
async def test_burst_then_deny(redis_client):
    from app.ratelimit import TokenBucket
    key = f"rl:test:{time.time_ns()}"
    await redis_client.delete(key)
    tb = TokenBucket(redis_client, key=key, rate=10.0, burst=5.0)

    ok_count = 0
    for _ in range(5):
        ok, _wait = await tb.try_acquire(1)
        ok_count += int(ok)
    assert ok_count == 5, "冷启动桶满应放行 burst 枚"

    ok, wait_ms = await tb.try_acquire(1)
    assert not ok and wait_ms > 0, "超出桶容量应被拒并给出建议等待"
    await redis_client.delete(key)


@pytest.mark.asyncio
async def test_refill_over_time(redis_client):
    from app.ratelimit import TokenBucket
    key = f"rl:test:{time.time_ns()}"
    await redis_client.delete(key)
    tb = TokenBucket(redis_client, key=key, rate=50.0, burst=2.0)

    assert (await tb.try_acquire(1))[0]
    assert (await tb.try_acquire(1))[0]
    assert not (await tb.try_acquire(1))[0]

    await asyncio.sleep(0.1)  # 50/s * 0.1s ≈ 5 枚补充,取回至少 1 枚
    assert (await tb.try_acquire(1))[0], "补充后应可再申领"
    await redis_client.delete(key)


@pytest.mark.asyncio
async def test_no_oversell_under_concurrency(redis_client):
    from app.ratelimit import TokenBucket
    key = f"rl:test:{time.time_ns()}"
    await redis_client.delete(key)
    tb = TokenBucket(redis_client, key=key, rate=1.0, burst=10.0)  # rate 极低,窗口内几乎不补充

    results = await asyncio.gather(*[tb.try_acquire(1) for _ in range(50)])
    granted = sum(1 for ok, _ in results if ok)
    # 并发 50 枚申领,桶容量 10 + 窗口内极少补充 → 成功数应 ~10,严格不超发太多
    assert granted <= 12, f"不应超发:granted={granted}"
    assert granted >= 10
    await redis_client.delete(key)


@pytest.mark.asyncio
async def test_rate_zero_means_unlimited(redis_client):
    """rate<=0 = 不限流(默认配置):始终立即放行,且不写 Redis(桶键不存在)。"""
    from app.ratelimit import TokenBucket
    key = f"rl:test:{time.time_ns()}"
    await redis_client.delete(key)
    tb = TokenBucket(redis_client, key=key, rate=0.0, burst=600.0)

    # 远超任何 burst 的连续/并发申领,全部放行
    for _ in range(1000):
        ok, wait_ms = await tb.try_acquire(1)
        assert ok and wait_ms == 0
    results = await asyncio.gather(*[tb.try_acquire(1) for _ in range(500)])
    assert all(ok for ok, _ in results)
    # acquire() 也应立即返回(不阻塞)
    assert await tb.acquire()
    # 不限流路径不触碰 Redis:桶键从未被创建
    assert await redis_client.exists(key) == 0
    # 负数同样视为不限流
    tb_neg = TokenBucket(redis_client, key=key + ":neg", rate=-1.0, burst=1.0)
    assert (await tb_neg.try_acquire(1)) == (True, 0)
