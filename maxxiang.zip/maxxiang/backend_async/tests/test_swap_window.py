"""test_swap_window.py — 「结算换手窗口」守卫(3.4.6):前端四个数字变成 `-` 的根因

用户症状:**偶尔前端的预测 4 个数字显示成符号 `-`**。
真机 HAR 实证:65 次 /prediction 里 **14 次(22%)** 返回 `target_round_id: null` +
`main: []` / `guard: []`,且**全部**落在局内 39.2~49.4s(中位 40.4s)——
正是「出怪入库(≈38s)之后、_settle_and_predict 正在跑」的那一瞬;当帧 `record`
显示本局**已结算**,`target` 却是 null。

根因:旧实现把「结算旧的」与「写入新的」分成两步,中间隔着慢操作:
    ① fill_prediction_outcome(N)                 → prediction(N) 不再是 pending
    ②   db.sequence(拉 ~1727 行) + run_prediction  ← **窗口**(真实部署可达数百 ms)
    ③ save_prediction(N+1)                        → 新的 pending 才写进去
①③ 之间 `predictions` 表里**一条未结算的行都没有** → `pending_prediction()` → None
→ web 返回 null → **前端四个 `-`**。前端 predChase 恰在出怪到达那一刻拉取,精准撞窗。

两道修复:
  · **写者**:`db.settle_and_save_prediction()` —— 同一事务里结算旧的 + 写入新的,
    读者只可能看到 {旧未结算} 或 {旧已结算+新未结算},**绝无「两个都没有」**;
  · **读者**:`web` 在 pending 为空时做**有界回退** —— 仅当「最新预测行恰好就是刚结算
    的那一局」(= 确实在换手瞬间)才回退,覆盖回填/哨兵等其余路径。
"""
import os
import sys
import time

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.constants import ROUND_STEP  # noqa: E402

_PG = os.environ.get("STA_PG_DSN", "")
_needs = pytest.mark.skipif(not _PG, reason="需要 PostgreSQL")


async def _fresh(db, room):
    async with db.pool.acquire() as c:
        for t in ("rounds", "predictions", "predictor_state"):
            await c.execute(f"DELETE FROM {t} WHERE room_id=$1", room)


@_needs
@pytest.mark.asyncio
async def test_atomic_swap_never_exposes_empty_pending():
    """【写者】settle_and_save_prediction 必须原子:结算 N 的同时写入 N+1。
    事务提交后,pending 恰好是 N+1 —— 绝不存在「N 已结算、N+1 未写入」的可见中间态。"""
    from app.db import DB
    db = DB(_PG, 2, 4)
    await db.connect()
    await db.migrate()
    room = "test_swap_9101"
    await _fresh(db, room)
    try:
        now = int(time.time() * 1000)
        base = (now - 5 * ROUND_STEP) // ROUND_STEP * ROUND_STEP
        for i in range(5):
            rid = base + i * ROUND_STEP
            await db.add_round(room, rid, (i % 9) + 1, "妖", (i % 9) + 1, 50,
                               "award", "2026", "2026")
        n = base + 4 * ROUND_STEP
        await db.save_prediction(room, n, [1, 7], [8, 5],
                                 {"models": [], "ens": [0.1] * 9})

        # 换手前:pending = N(未结算)
        pend = await db.pending_prediction(room)
        assert pend and int(pend["round_id"]) == n

        # 只读窥视不得改变状态(权重更新要用 detail,但结算必须推迟到事务里)
        prev = await db.peek_prediction(room, n)
        assert prev and prev["first_time"] is True
        assert (await db.pending_prediction(room)) is not None   # 仍未结算 ✅

        # 原子换手
        out = await db.settle_and_save_prediction(
            room, n, 7, next_round=n + ROUND_STEP, main_ids=[2, 3],
            guard_ids=[4, 5], detail={"models": [], "ens": [0.1] * 9})
        assert out and out["first_time"] is True and out["hit"] == "main"

        # 换手后:pending 恰好是 N+1(而不是 None)
        pend = await db.pending_prediction(room)
        assert pend is not None, "换手后 pending 为空 —— 前端会显示四个 `-`"
        assert int(pend["round_id"]) == n + ROUND_STEP
        assert list(pend["main_ids"]) == [2, 3]

        # 幂等:重复换手不得再次计为「首次结算」(权重不能被推两次)
        again = await db.settle_and_save_prediction(
            room, n, 7, next_round=n + ROUND_STEP, main_ids=[2, 3],
            guard_ids=[4, 5], detail={})
        assert again["first_time"] is False
    finally:
        await _fresh(db, room)
        await db.close()


@_needs
@pytest.mark.asyncio
async def test_reader_bounded_fallback_covers_the_window():
    """【读者】pending 为空(换手瞬间)时的回退必须**有界**:
       · 最新预测行 == 刚结算的那一局 → 回退(前端有号,不再是 `-`);
       · 最新预测行远远落后 latest_round(真·断链)→ **不回退**(绝不把陈旧号当当前号)。"""
    from app.db import DB
    db = DB(_PG, 2, 4)
    await db.connect()
    room = "test_swap_9102"
    await _fresh(db, room)
    try:
        now = int(time.time() * 1000)
        base = (now - 10 * ROUND_STEP) // ROUND_STEP * ROUND_STEP
        for i in range(10):
            rid = base + i * ROUND_STEP
            cid = (i % 9) + 1
            await db.add_round(room, rid, cid, "妖", cid, 50, "award", "2026", "2026")
            await db.save_prediction(room, rid, [1, 7], [8, 5], {"ens": [0.1] * 9})
            await db.fill_prediction_outcome(room, rid, cid)      # 全部结算
        latest = base + 9 * ROUND_STEP

        # 这正是换手窗口的库状态:N 已结算、N+1 尚未写入
        assert await db.pending_prediction(room) is None          # ← 旧读者在此返回 null

        lp = await db.latest_prediction(room)
        assert lp and int(lp["round_id"]) == latest               # 回退启用条件成立
        assert list(lp["main_ids"]) == [1, 7]                     # 前端拿得到号 ✅

        # 有界性:把预测删到只剩很老的一条(真·断链)→ 回退条件不成立
        async with db.pool.acquire() as c:
            await c.execute(
                "DELETE FROM predictions WHERE room_id=$1 AND round_id > $2",
                room, base + 3 * ROUND_STEP)
        lp2 = await db.latest_prediction(room)
        assert lp2 and int(lp2["round_id"]) != latest, (
            "断链时若仍回退,会把几百局前的陈旧号当成当前预测显示")
    finally:
        await _fresh(db, room)
        await db.close()
