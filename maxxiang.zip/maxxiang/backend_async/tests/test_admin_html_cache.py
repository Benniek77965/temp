"""admin.html 缓存语义回归:no-cache + 条件请求 304(第四轮复查修复)。

裸 FileResponse 在 Starlette 0.49 不处理 If-None-Match,会让 ~7KB 的 admin.html 在
no-cache 下每次导航全量重传。web._admin_html_response 复刻 StaticFiles 的 304 语义:
命中 ETag → 304 空 body;ETag 过期 → 200 全量(改动必达);始终带 no-cache 强制 revalidate。
"""
import os
import pytest
from starlette.requests import Request


def _make_request(headers: dict) -> Request:
    raw = [(k.lower().encode(), v.encode()) for k, v in headers.items()]
    return Request({"type": "http", "method": "GET", "headers": raw, "query_string": b"",
                    "path": "/admin", "scheme": "http", "server": ("t", 80)})


def _admin_html_path(tmp_path) -> str:
    p = tmp_path / "admin.html"
    p.write_text("<!doctype html><title>x</title>", encoding="utf-8")
    return str(p)


def test_admin_html_no_cache_and_304(tmp_path, monkeypatch):
    # 指向临时 static_dir,避免依赖仓库布局
    monkeypatch.setenv("STA_STATIC_DIR", str(tmp_path))
    from app import web
    path = _admin_html_path(tmp_path)

    # 首请求:200 + no-cache + ETag
    r0 = web._admin_html_response(path, _make_request({}))
    assert r0.status_code == 200
    assert r0.headers.get("cache-control") == "no-cache"
    etag = r0.headers.get("etag")
    assert etag, "必须带 ETag 才能条件请求"

    # 带正确 ETag:304 且沿用 no-cache 且回带 ETag
    r1 = web._admin_html_response(path, _make_request({"if-none-match": etag}))
    assert r1.status_code == 304
    assert r1.headers.get("cache-control") == "no-cache"
    assert r1.headers.get("etag") == etag

    # 带过期 ETag:200 全量(内容变更必达)
    r2 = web._admin_html_response(path, _make_request({"if-none-match": '"stale"'}))
    assert r2.status_code == 200

    # If-Modified-Since 用响应的 Last-Modified:304
    lm = r0.headers.get("last-modified")
    assert lm
    r3 = web._admin_html_response(path, _make_request({"if-modified-since": lm}))
    assert r3.status_code == 304


def test_admin_html_etag_matches_starlette(tmp_path, monkeypatch):
    """helper 的 ETag 必须与 Starlette 标准算法一致,否则跨路径(/assets)revalidate 不一致。"""
    monkeypatch.setenv("STA_STATIC_DIR", str(tmp_path))
    import hashlib
    from app import web
    path = _admin_html_path(tmp_path)
    st = os.stat(path)
    expect = f'"{hashlib.md5((str(st.st_mtime) + "-" + str(st.st_size)).encode(), usedforsecurity=False).hexdigest()}"'
    got = web._admin_html_response(path, _make_request({})).headers.get("etag")
    assert got == expect


def test_admin_html_conditional_edges(tmp_path, monkeypatch):
    """条件请求边界(第五轮复查):Range+INM 优先级、畸形 IMS 健壮、弱 ETag、多 ETag 列表。"""
    monkeypatch.setenv("STA_STATIC_DIR", str(tmp_path))
    from app import web
    p = tmp_path / "admin.html"
    p.write_text("<!doctype html>" + "x" * 500, encoding="utf-8")
    path = str(p)
    et = web._admin_html_response(path, _make_request({})).headers.get("etag")

    # Range + 正确 INM → 304(INM 优先于 Range,RFC 9110 §13.1.3)
    r = web._admin_html_response(path, _make_request(
        {"range": "bytes=0-9", "if-none-match": et}))
    assert r.status_code == 304

    # 畸形 If-Modified-Since → 不崩,回 200
    r = web._admin_html_response(path, _make_request({"if-modified-since": "garbage!!!"}))
    assert r.status_code == 200

    # 空 If-None-Match → 200
    r = web._admin_html_response(path, _make_request({"if-none-match": ""}))
    assert r.status_code == 200

    # 多 ETag 列表含匹配 → 304
    r = web._admin_html_response(path, _make_request(
        {"if-none-match": f'"other", {et}, "more"'}))
    assert r.status_code == 304

    # 弱 ETag(W/ 前缀)→ 304
    r = web._admin_html_response(path, _make_request({"if-none-match": "W/" + et}))
    assert r.status_code == 304


def test_admin_html_304_no_content_length(tmp_path, monkeypatch):
    """RFC 7232 §4.1:304 最好省略 Content-Length(不得为非 200-body-长度的值)。
    确认我们的 304 不带 Content-Length。"""
    monkeypatch.setenv("STA_STATIC_DIR", str(tmp_path))
    from app import web
    p = tmp_path / "admin.html"
    p.write_text("<!doctype html>", encoding="utf-8")
    et = web._admin_html_response(str(p), _make_request({})).headers.get("etag")
    r = web._admin_html_response(str(p), _make_request({"if-none-match": et}))
    assert r.status_code == 304
    assert "content-length" not in {k.lower() for k in r.headers.keys()}


def test_admin_asset_version_pin():
    """**4.0.3 版本钉**(补齐 4.0.2 复查记录在案的覆盖缺口):admin.html 的两个
    ?v 必须等于 admin_api.ADMIN_VERSION —— 单一事实源,bump 常量与 html 任一
    而漏另一即红;禁旧版残留用词边界正则(与 index 侧 4.0.2 钉同款,防未来
    1.4.10 假红)。"""
    import re
    from pathlib import Path

    from app.admin_api import ADMIN_VERSION

    html_path = Path(__file__).resolve().parents[2] / "admin.html"
    if not html_path.is_file():
        pytest.skip("前端不在本仓")
    html = html_path.read_text(encoding="utf-8")
    assert f"admin.css?v={ADMIN_VERSION}" in html, \
        f"admin.css 版本参 ≠ ADMIN_VERSION({ADMIN_VERSION})"
    assert f"admin.js?v={ADMIN_VERSION}" in html, \
        f"admin.js 版本参 ≠ ADMIN_VERSION({ADMIN_VERSION})"
    assert re.search(r"\?v=1\.4\.0\b", html) is None, "禁 1.4.0 旧版残留"
