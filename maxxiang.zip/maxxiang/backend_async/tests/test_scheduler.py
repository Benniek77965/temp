"""
test_scheduler.py — 错峰调度纯函数单测(不依赖 Redis/PG/网络)
================================================================================
核对四件事:
  · 抖动落在 [0, upper] 且 upper<=0 时恒为 0;
  · award/mainpage 的到期时刻正确把「服务器时钟差」折算成本机 wall-clock;
  · mainpage 的 min_interval 空转保护;
  · retry 的指数退避带上限。
并用一个「上千房挤在同一出怪秒」的场景验证抖动确实把请求抹开成窗口(削峰)。
"""
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.scheduler import (award_due_wall, jitter_ms, next_mainpage_due_wall,  # noqa: E402
                           retry_due_wall)


def test_jitter_bounds():
    rnd = random.Random(42)
    for _ in range(1000):
        j = jitter_ms(1200, rnd)
        assert 0 <= j <= 1200
    assert jitter_ms(0) == 0
    assert jitter_ms(-5) == 0


def test_award_due_folds_server_clock():
    # 服务器此刻 1_000_000;本局出怪在 1_040_000;award_delay=2500 → 目标服务器时刻 1_042_500
    # 本机此刻 500_000。相对差 = 42_500 → 到期 = 542_500(+抖动)
    due = award_due_wall(now_wall=500_000, server_now=1_000_000, anchor_time=1_040_000,
                         award_delay_ms=2500, jitter_upper=0)
    assert due == 542_500


def test_award_due_never_negative_wait():
    # 出怪时刻已过(delta<0)→ wait 夹到 0,立即到期(仅本机此刻 + 抖动)
    due = award_due_wall(now_wall=800_000, server_now=2_000_000, anchor_time=1_000_000,
                         award_delay_ms=0, jitter_upper=0)
    assert due == 800_000


def test_seal_anchor_fires_earlier_than_draw_anchor():
    """真机实测:结果备战(spellTime,局内35s)后 ~1s 即生成,不必等 drawTime(40s)。
    同一局,盯备战 + 1.5s 应比盯出怪 + 2.5s 早约 4 秒去取。"""
    now_wall, server_now = 0, 1_000_000
    rid = 1_000_000                       # 令 server_now 恰在局起点
    spell_t = rid + 35_000                # 备战
    draw_t = rid + 40_000                 # 出怪
    seal_due = award_due_wall(now_wall, server_now, spell_t, 1500, jitter_upper=0)
    draw_due = award_due_wall(now_wall, server_now, draw_t, 2500, jitter_upper=0)
    assert seal_due == 36_500             # 备战35s + 1.5s
    assert draw_due == 42_500             # 出怪40s + 2.5s
    assert draw_due - seal_due == 6_000   # 提前 6 秒


def test_seal_anchor_delay_tunable():
    """award_after_seal 直接决定备战后多久去取:0.5s vs 1.5s 差 1 秒。"""
    rid = 1_000_000
    spell_t = rid + 35_000
    fast = award_due_wall(0, rid, spell_t, 500, jitter_upper=0)
    slow = award_due_wall(0, rid, spell_t, 1500, jitter_upper=0)
    assert slow - fast == 1_000
    assert fast == 35_500 and slow == 36_500


def test_mainpage_uses_end_plus_tail():
    # 本局结束 1_050_000 + tail 800 = 1_050_800;相对差 50_800 → 到期 550_800
    due = next_mainpage_due_wall(now_wall=500_000, server_now=1_000_000, end_time=1_050_000,
                                 min_interval_ms=8000, jitter_upper=0, tail_ms=800)
    assert due == 550_800


def test_mainpage_min_interval_guard():
    # 本局马上结束(end 相对差极小)→ 不早于 min_interval,避免空转猛刷
    due = next_mainpage_due_wall(now_wall=500_000, server_now=1_000_000, end_time=1_000_100,
                                 min_interval_ms=8000, jitter_upper=0, tail_ms=0)
    assert due == 500_000 + 8000


def test_mainpage_no_end_falls_back_to_min_interval():
    due = next_mainpage_due_wall(now_wall=0, server_now=0, end_time=0,
                                 min_interval_ms=8000, jitter_upper=0)
    assert due == 8000


def test_retry_backoff_exponential_and_capped():
    assert retry_due_wall(0, 1500, attempt=1, jitter_upper=0) == 1500
    assert retry_due_wall(0, 1500, attempt=3, jitter_upper=0) == 4500
    # 第 100 次:1500*100=150000 被 cap 到 15000
    assert retry_due_wall(0, 1500, attempt=100, jitter_upper=0, cap_ms=15000) == 15000


def test_peak_shaving_spreads_requests():
    """5000 房挤在同一出怪秒:叠加抖动后,到期时刻应被抹成一个宽窗口而非同一点。"""
    rnd = random.Random(7)
    now_wall, server_now, draw = 0, 1_000_000, 1_040_000
    jitter_upper = 1200
    dues = [award_due_wall(now_wall, server_now, draw, 2500, jitter_upper, rnd)
            for _ in range(5000)]
    base = 42_500  # 无抖动时的公共到期
    spread = max(dues) - min(dues)
    # 抖动区间 [0,1200] → 展宽应接近 1200,且没有任何一毫秒堆积超过 ~5%
    assert spread >= 1000
    from collections import Counter
    hottest = Counter(dues).most_common(1)[0][1]
    assert hottest < 5000 * 0.05
    assert all(base <= d <= base + jitter_upper for d in dues)
