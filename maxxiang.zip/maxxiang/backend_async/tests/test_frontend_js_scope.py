"""
test_frontend_js_scope.py — 前端「未声明标识符 / 误粘贴」回归钉(4.7.7 事故)
================================================================================
事故:`const purgeOn = !!ov.purgeEnabled;` 连同上方三行注释,被从「值」视图
误粘贴进「注」视图的 doExportInvites / drawRegLog / drawBlocks 三个函数。
那三处拿不到 `ov`,而 admin.js 是 `type="module"`(严格模式)—— 读未声明标识符
直接 ReferenceError。drawRegLog 在写 innerHTML **之前**抛错,于是注册流水停在
骨架的「加载中…」;异常又外溢出只有 try/finally 的 draw(),把排在后面的
drawBlocks() 整个吃掉,观测台封禁也一起变砖。

为什么仓库既有的前端检查抓不到:tests/ 里扫 admin.js 的用例全是**字符串扫描**
(_srcscan.js_code 剥注释后 grep)。那类手段结构上不可能发现这种错 —— 被粘贴的
文本本身完全合法,错的是它待的地方。

本文件三道钉,粗细互补:
  ① 事故钉(零依赖,必跑):renderReg 内不得再出现「值」视图专属的 purgeOn;
  ② 复制粘贴钉(零依赖,必跑):同一段多行注释不得在文件里重复出现 ——
     本次事故的物证就是同一段三行注释出现了四次;
  ③ 作用域钉(需 node + acorn,缺则 skip):真正的 AST 作用域解析,一次抓一整类。
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

from tests import _srcscan

ROOT = Path(__file__).resolve().parents[2]
ADMIN_JS = ROOT / "assets" / "admin.js"
SCANNER = ROOT / "backend_async" / "scripts" / "js_scope_scan.mjs"


def _admin_js_raw() -> str:
    if not ADMIN_JS.is_file():
        pytest.skip("前端不在本仓")
    return ADMIN_JS.read_text(encoding="utf-8")


def _admin_js_code() -> str:
    """**剥掉注释**的 admin.js,行号与原文对齐。

    必须剥:本文件的钉子要判「代码里有没有 purgeOn」,而修复时新写的解释性
    注释里原样引用了出事的那一行 —— 不剥就是假阳性(_srcscan 开篇记录的
    同一类问题)。行号又必须保住,否则断言报不出位置。
    """
    _admin_js_raw()                       # 复用 skip 判定
    return _srcscan.js_code_keep_lines(ADMIN_JS)


def _render_reg_range(lines: list[str]) -> tuple[int, int]:
    """renderReg 的行区间(半开)。定位靠函数声明与下一个视图的分节横幅,
    两者都是本文件里独一无二的字符串;真要被改动,这里红了也该红。"""
    starts = [i for i, ln in enumerate(lines) if ln.startswith("async function renderReg()")]
    assert len(starts) == 1, "renderReg 声明应恰好一处"
    s = starts[0]
    ends = [i for i, ln in enumerate(lines) if i > s and ln.startswith("/* ═══════════ 「值」")]
    assert ends, "找不到「值」视图分节横幅 —— 区间定位失效,请修本测试而不是绕过它"
    return s, ends[0]


# ── ① 事故钉 ────────────────────────────────────────────────────────────────
def test_reg_view_has_no_card_purge_leftovers():
    # 区间定位用**原文**(分节横幅本身是注释,剥掉就没了);内容判定用**剥注释版**。
    # 两者行数一一对应(js_code_keep_lines 的契约),所以行号可以互用。
    s, e = _render_reg_range(_admin_js_raw().split("\n"))
    lines = _admin_js_code().split("\n")
    hits = [(s + 1 + i, ln.strip())
            for i, ln in enumerate(lines[s:e])
            if "purgeOn" in ln or "purgeEnabled" in ln]
    assert not hits, (
        "「注」视图里不该有卡密删除总开关(userauth.jf_card_purge_enabled)的任何痕迹 —— "
        f"/reg/overview 根本不返回 purgeEnabled,这是从「值」视图误粘贴的。命中:{hits}")


def test_purge_flag_only_lives_in_jfvip_view():
    """purgeOn 的声明与使用必须全部在「值」视图内(renderReg 之后)。"""
    s, e = _render_reg_range(_admin_js_raw().split("\n"))
    lines = _admin_js_code().split("\n")
    used = [i + 1 for i, ln in enumerate(lines) if "purgeOn" in ln]
    assert used, "purgeOn 应仍在「值」视图里正常使用(若已删除请同步改本钉)"
    assert all(n > e for n in used), f"purgeOn 出现在「值」视图之外:{[n for n in used if n <= e]}"


# ── ② 复制粘贴钉 ────────────────────────────────────────────────────────────
def test_no_duplicated_multiline_comment_block():
    """同一段 ≥3 行的块注释不得在文件里出现两次。

    本次事故的物证正是这个形状:一段三行注释连同它下面那行代码,被整块复制到了
    三个不该去的地方。注释是给人读的,同一段话原样出现多次,要么是漏改,要么就是
    误粘贴 —— 两种都值得在合并前被拦一次。
    """
    src = _admin_js_raw()          # 这一钉恰恰要看注释本身
    blocks: dict[str, int] = {}
    for m in re.finditer(r"/\*.*?\*/", src, re.S):
        body = m.group(0)
        if body.count("\n") < 2:            # 只管 ≥3 行的段落注释
            continue
        key = re.sub(r"\s+", " ", body).strip()
        blocks[key] = blocks.get(key, 0) + 1
    dup = {k[:90] + "…": v for k, v in blocks.items() if v > 1}
    assert not dup, f"发现重复的多行块注释(疑似整块复制粘贴):{dup}"


# ── ③ 作用域钉(需 node + acorn;缺则 skip)───────────────────────────────────
def _node_scan_available() -> bool:
    if not SCANNER.is_file() or shutil.which("node") is None:
        return False
    for dep in ("acorn", "eslint-scope"):
        if not (ROOT / "node_modules" / dep).is_dir():
            return False
    return True


@pytest.mark.skipif(not _node_scan_available(),
                    reason="需 node 与 acorn/eslint-scope:项目根执行 "
                           "`npm i --no-save acorn eslint-scope`(务必带 --no-save)")
def test_frontend_js_has_no_unresolved_identifier():
    r = subprocess.run(["node", str(SCANNER)], cwd=str(ROOT),
                       capture_output=True, text=True, timeout=180,
                       env={**os.environ, "NODE_OPTIONS": ""})
    assert r.returncode == 0, (
        "前端存在未声明标识符(严格模式下 = 运行期 ReferenceError):\n"
        + r.stdout + r.stderr)
