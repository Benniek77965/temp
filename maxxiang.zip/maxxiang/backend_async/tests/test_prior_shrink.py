"""test_prior_shrink.py — 冷启动自适应收缩(4.9.4)的三道守卫
================================================================================
本文件守的东西和 test_official_probability.py 是一类:**静默失真**。收缩写错了
不会报错、不会白屏,只会让新加的房在头几小时给出一串看起来很正常、实际比现行
还差的号 —— 而这恰恰是最难被肉眼发现的失效形态。

三道守卫:
一、**回滚字节级等价**:prior_shrink=False 时 _p_frontier 必须与 _m1_global 逐位
    相同。这是本次改造对外承诺的回滚保证,一旦破了,"改回 false 即可"就是句空话。
二、**退化边界**:该收缩式直接吃裸频率时,n=2 且两局同兽会让
    1-Σp̂²=0 ⇒ λ=0 ⇒ 输出 one-hot 概率,LP 会把该号当成必出。实现改为架在 Laplace
    之上正是为了堵这个洞 —— 这里对 n=0..6 的**全部**同兽/异兽组合穷举。
三、**方向性**:先验对时收缩必须真的把冷启动估计拉近真值;先验被数据否定时
    λ 必须塌回 0(否则就退化成一个固定 κ,而固定 κ 在错配场景实测比现行差 5 倍)。

另附两条契约:配置三方同值(引擎 dataclass / config.yaml / config_registry)、
以及 prior_table 写坏时**静默降级不抛异常**(热更改错不该崩 predict)。
"""
from __future__ import annotations

import itertools
import logging
import os
from pathlib import Path

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[2]
os.environ.setdefault("STA_ENGINE_DIR", str(ROOT / "jiufa_data"))

from app import predictor_bridge as PB          # noqa: E402
E = PB.E                                        # 引擎模块(spell_tamer_monitor)

CONFIG_YAML = ROOT / "backend_async" / "config.yaml"


def _load_yaml_pred() -> dict:
    return yaml.safe_load(CONFIG_YAML.read_text(encoding="utf-8"))["prediction"]


def _predictor(**over):
    """构造一个**不落库**的 Predictor:本文件只测纯函数 _p_frontier / _prior_vec,
    不碰 store。persistent=False + store=None 是引擎自身支持的无状态用法。"""
    base = dict(_load_yaml_pred())
    base.update(over)
    fields = set(E.PredictionConfig.__dataclass_fields__)
    cfg = E.PredictionConfig(**{k: v for k, v in base.items() if k in fields})
    return E.Predictor(cfg, None, "test", logging.getLogger("test"),
                       persistent=False)


# ───────────────────────── 守卫一:回滚字节级等价 ─────────────────────────
@pytest.mark.parametrize("seq", [
    [],
    [1],
    [5, 5],
    [1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1] * 50 + [9] * 7,
    [(i % 9) + 1 for i in range(1728)],
])
def test_shrink_off_is_bitwise_identical_to_m1(seq):
    """prior_shrink=False ⇒ _p_frontier 与 _m1_global 逐位相同(回滚保证)。"""
    p = _predictor(prior_shrink=False)
    assert p._p_frontier(list(seq)) == p._m1_global(list(seq))


def test_empty_prior_table_also_falls_back():
    """prior_table 留空 = 关闭收缩,同样逐位退回现行值。"""
    p = _predictor(prior_shrink=True, prior_table="")
    seq = [1, 1, 2, 3, 9, 9, 5]
    assert p._p_frontier(seq) == p._m1_global(seq)


@pytest.mark.parametrize("bad, why", [
    ("1:0.5,2:0.5", "缺 3~9 号(缺项号先验概率会变 0,LP 会永久判它不可能出)"),
    ("1:0.9,2:0.9,3:0.9,4:0.9,5:0.9,6:0.9,7:0.9,8:0.9,9:0.9", "合计 8.1,远离 1"),
    ("1:0.2,2:0.2,3:0.2,4:0.2,5:0.2,6:0,7:0.1,8:0.05,9:0.05", "6 号为 0"),
    ("完全不是键值对", "解析不出任何一项"),
    ("1:abc,2:0.1", "值非数字"),
])
def test_malformed_prior_table_degrades_silently(bad, why):
    """写坏的先验表**静默降级**,既不抛异常也不改行为 —— 热更改错不该崩 predict。"""
    p = _predictor(prior_shrink=True, prior_table=bad)
    seq = [1, 2, 3, 1, 1, 8, 7]
    assert p._p_frontier(seq) == p._m1_global(seq), why


def test_shipped_default_is_off_and_bitwise_identical():
    """**出厂缺省必须是关闭态** —— 这一条守的是本次改造的对外承诺。

    三房全量实测命中率 +0.03/-0.27/-0.62pp(三房同向偏负,z≈-1.1)与期望命中口径
    (+2.53pp 冷启动)打架,现有样本判不出孰真,故定为出厂关闭、由部署方自行 A/B。
    这个决定必须被测试钉住:哪天有人顺手把缺省改回 True 而没有补上 A/B 证据,
    这一条会当场红 —— 那正是它存在的意义。
    """
    assert E.PredictionConfig.__dataclass_fields__["prior_shrink"].default is False
    assert _load_yaml_pred()["prior_shrink"] is False
    p = _predictor()                       # 完全按出厂配置构造,不加任何覆写
    for seq in ([], [7], [3, 3], [1, 5, 9] * 400):
        assert p._p_frontier(list(seq)) == p._m1_global(list(seq))


# ───────────────────────── 守卫二:退化边界穷举 ─────────────────────────
def test_no_degenerate_output_on_tiny_samples():
    """n=0..6 的全部组合:输出恒为合法概率向量,且**没有任何一项塌到 0**。

    塌到 0 正是该收缩式直接吃裸频率时的病(n=2 同兽 ⇒ one-hot)。
    """
    p = _predictor(prior_shrink=True)
    for n in range(0, 7):
        for combo in itertools.combinations_with_replacement(range(1, 10), n):
            out = p._p_frontier(list(combo))
            assert len(out) == 9
            assert abs(sum(out) - 1.0) < 1e-9, (n, combo, sum(out))
            assert all(v > 1e-6 for v in out), (n, combo, out)
            assert all(v == v and abs(v) != float("inf") for v in out), (n, combo)


def test_two_identical_draws_do_not_become_one_hot():
    """把病灶本身单列一条:两局同兽绝不能让该号概率逼近 1。"""
    p = _predictor(prior_shrink=True)
    out = p._p_frontier([5, 5])
    assert out[4] < 0.30, out          # 裸 FH 在这里会给出 1.0


# ───────────────────────── 守卫三:方向性 ─────────────────────────
def _l1(a, b):
    return sum(abs(x - y) for x, y in zip(a, b))


def test_shrink_helps_when_prior_is_right():
    """先验对时,小样本下收缩估计必须显著比现行更接近真值。"""
    p = _predictor(prior_shrink=True)
    prior = p._prior_vec()
    assert prior is not None
    # 用先验本身当"真值"造一段小样本:按四舍五入的期望计数铺开(确定性,不用随机源)
    n = 60
    seq = []
    for c in range(1, 10):
        seq += [c] * round(prior[c - 1] * n)
    assert 55 <= len(seq) <= 65
    d_now = _l1(p._m1_global(seq), prior)
    d_new = _l1(p._p_frontier(seq), prior)
    assert d_new < d_now * 0.5, (d_now, d_new)


def test_lambda_collapses_when_data_contradicts_prior():
    """数据足够否定先验时,收缩必须让路 —— 否则就退化成一个危险的固定 κ。

    构造:一段 9 号占压倒多数的长序列(先验里 9 号只有 3.56%)。
    """
    p = _predictor(prior_shrink=True)
    seq = [9] * 1500 + [1] * 200
    now, new = p._m1_global(seq), p._p_frontier(seq)
    # 与"完全不收缩"的距离,必须远小于与先验的距离
    assert _l1(new, now) < _l1(new, p._prior_vec()), (new, now)
    assert new[8] > 0.70, new          # 9 号该被数据顶起来,而不是被先验按住


#: 4.9.9 新增的两条守卫 —— 它们守的是同一件事的两面:
#:   一面是**行为**(先验正确时收缩不会随 n 退场),一面是**文案**(不许再写反)。
#: 起因:引擎 dataclass / config.yaml / config_registry 三处都写着「n→∞ → λ→0」,
#: 而那是错的 —— λ 的 n→∞ 极限取决于先验对不对:p0=真分布时分母
#: (n−1)·Σ(p̂−p0)² 的期望恰好趋近分子 (1−Σp̂²) ⇒ λ→1,收缩**永不退场**;
#: 只有 p0 错时分母才随 n 线性发散 ⇒ λ→0。
#: 这不是文字洁癖:那句错话会让人以为「稳态无风险,顶多冷启动帮点忙」,
#: 而 4.9.9 三房 36,182 局全量回放实测,代价恰恰全在稳态段
#: (idx>=1728:出厂表 −0.634pp p=0.073、留一房表 −0.849pp p=0.017),
#: 冷启动那点收益既不显著(p=0.12/0.75)又只覆盖 3.5% 的局。
#: 上一条 test_lambda_collapses_when_data_contradicts_prior 只测了「先验被数据
#: 否定」那半边,于是错话在三处文件里活了整整五个小版本没人抓。


@pytest.mark.parametrize("n", [200, 2000, 20000])
def test_lambda_does_not_vanish_when_the_prior_is_exact(n):
    """先验正确时,收缩必须**随 n 增大依然生效**,而不是退场。

    构造:按先验比例铺一段确定性序列(零随机源),它的经验分布就是先验本身。
    断言:收缩输出**逐位等于先验**(λ 被钳到 1),而同一段序列的纯数据估计
    (_m1_global,即 prior_shrink=False 的口径)与先验有可测差距 ——
    两者不同,恰恰说明收缩在 n=20000 时仍然在起作用。
    实测 ‖纯数据估计 − 先验‖₁ = 0.0385 / 0.0039 / 0.00038(n=200/2000/20000)。
    """
    p = _predictor(prior_shrink=True)
    prior = p._prior_vec()
    assert prior is not None
    seq = []
    for c in range(1, 10):
        seq += [c] * round(prior[c - 1] * n)
    out, m1 = p._p_frontier(seq), p._m1_global(seq)
    assert _l1(out, prior) < 1e-9, (
        f"n={len(seq)} 时收缩输出已偏离先验 —— 若这里开始变大,说明 λ 真的会随 n 塌掉,"
        "那三处文案里那句「n→∞ → λ→0」反而是对的,请连同本测试一起复核")
    assert _l1(m1, prior) > 1e-6, (
        "构造的序列让纯数据估计恰好等于先验了,本测试失去区分力,请换构造")


#: 允许出现该错句的**唯一**情形:那一行是在引用它并当场更正。
#: 同款放行机制见 test_config_yaml_uses_no_bare_line_number_citations。
_LAMBDA_CLAIM_FILES = [
    "jiufa_data/spell_tamer_monitor.py",
    "backend_async/config.yaml",
    "backend_async/app/config_registry.py",
]


def test_docs_do_not_claim_lambda_vanishes_as_n_grows():
    """三处文案不得再无条件断言「n→∞ 时 λ→0」。

    注释骗人不报错 —— 这是本仓库反复吃过的亏(行号腐烂那条守卫同理)。
    这一条把「已经改对的三处」钉住,防止后续 merge/回滚把错话带回来。
    """
    import re as _re

    pat = _re.compile(r"n\s*→\s*∞[^\n]{0,10}?(λ|lambda)\s*→\s*0")
    bad = []
    for rel in _LAMBDA_CLAIM_FILES:
        for i, ln in enumerate((ROOT / rel).read_text(encoding="utf-8").splitlines(), 1):
            if pat.search(ln) and not any(k in ln for k in ("更正", "是错的", "原文")):
                bad.append(f"{rel} 第 {i} 行:{ln.strip()[:80]}")
    assert not bad, (
        "又出现无条件的「n→∞ → λ→0」断言。λ 的极限取决于先验对不对:先验对则 λ→1、"
        "收缩永不退场(见 test_lambda_does_not_vanish_when_the_prior_is_exact)。"
        "确需引用这句错话时,请在同一行写明「更正/是错的/原文」:\n  " + "\n  ".join(bad))


def test_shrink_is_deterministic():
    """零随机源:同输入必同输出(本项目对可回放性的硬要求)。"""
    p = _predictor(prior_shrink=True)
    seq = [1, 3, 9, 5, 5, 2, 8, 8, 7, 4] * 17
    assert p._p_frontier(seq) == p._p_frontier(seq)
    assert _predictor(prior_shrink=True)._p_frontier(seq) == p._p_frontier(seq)


# ───────────────────────── 契约:三方同值 ─────────────────────────
@pytest.mark.parametrize("key", ["prior_shrink", "prior_table"])
def test_config_triplet_agrees(key):
    """引擎 dataclass 缺省 / config.yaml 现值 / 注册表登记 —— 三处必须同值。

    本仓库既有的 as_*/sc_*/rg_*/fr_* 都受同款约束(见 config_registry 注释);
    漏登记的后果是管理台改不动、校验放行任意值,而 config.yaml 上看不出来。
    """
    from app.config_registry import REGISTRY

    dc_default = E.PredictionConfig.__dataclass_fields__[key].default
    yaml_value = _load_yaml_pred()[key]
    field = REGISTRY[f"prediction.{key}"]

    assert yaml_value == dc_default, "config.yaml 与引擎 dataclass 缺省不一致"
    assert field.default == dc_default, "注册表 default 与引擎 dataclass 缺省不一致"


def test_prior_table_sums_to_one_and_covers_nine():
    """出厂先验表自身必须合法(九项俱全、和为 1)—— 否则默认就是关闭状态。"""
    p = _predictor(prior_shrink=True)
    vec = p._prior_vec()
    assert vec is not None, "出厂 prior_table 竟解析失败,收缩默认不生效"
    assert len(vec) == 9 and all(v > 0 for v in vec)
    assert abs(sum(vec) - 1.0) < 1e-9


# ───────── 守卫六:升级零扰动 —— 4.9.3 时代的快照套上来不得产生任何变更 ─────────
def test_upgrading_from_a_493_snapshot_causes_no_churn():
    """拿一份**不含新键**的 4.9.3 时代快照做 boot 套用,`changed` 必须是空的。

    这是「关着的开关不得驱动状态变更」这条判据的第三个落点(前两个是
    `_fr_key` 与补算指纹 `cfg_fp`,都曾各犯过一次)。这里盯的是配置中枢:
    新登记的注册表键在升级首启时若被判成「变更」,会白触发一次 bridge 钩子、
    在管理台留下一条无中生有的变更记录,并让运维以为有人动过预测配置。

    机制上靠 apply_snapshot 的 `if cur == target: continue` —— 快照缺键时回落
    base 默认值,与 config.yaml 里的现值相同就跳过。本测试把它钉住,免得哪天
    有人把新键的注册表 default 与 config.yaml 写成两个值(那会**每次启动**都
    判一次变更,而且看起来一切正常)。
    """
    import asyncio

    import yaml as _yaml

    from app import config_center as cc
    from app.settings import Settings

    raw = _yaml.safe_load(CONFIG_YAML.read_text(encoding="utf-8"))
    st_obj = Settings()
    st_obj.prediction = dict(raw["prediction"])
    cc.capture_base(st_obj)

    # 4.9.3 时代能落库的预测覆盖:有几个老键,**没有** prior_*
    # 注:explore_style 取 config.yaml 现值。本测试守的是「新登记的键在升级首启
    # 不得被判成变更」,快照里放一个与现值**不同**的值只会测出「我改过默认值」这件
    # 已知的事,把真正要守的信号淹掉。
    # 运维须知(4.9.7):存量部署的 config_revisions.snapshot 若含
    # prediction.explore_style 的旧值(如 "frontier"),它会**盖掉 config.yaml**
    # —— 这是设计如此(快照优先),不是 bug;换默认风格时必须同批清理该快照键,
    # 否则改动静默不生效。
    snapshot = {"prediction.train_window_hours": 24.0,
                "prediction.max_train": 5000,
                "prediction.explore_style": _yaml.safe_load(
                    CONFIG_YAML.read_text(encoding="utf-8"))["prediction"]["explore_style"]}
    fired = []
    state = cc.CenterState(role="worker")
    changed, _restart, errors = asyncio.run(cc.apply_snapshot(
        st_obj, snapshot, hooks={"bridge": lambda: fired.append("bridge")},
        mode="boot", state=state, bus=None))

    assert not errors, errors
    assert [k for k in changed if "prior" in k] == [], (
        f"升级首启把新键判成了变更:{changed} —— 检查 config_registry 的 default "
        "是否与 config.yaml 的现值写成了两个不同的值")
    assert changed == [], f"升级首启产生了变更:{changed}"
    assert fired == [], "升级首启白触发了 bridge 钩子"

    # 幂等自愈:再套一次仍不该有任何变更
    changed2, _r2, _e2 = asyncio.run(cc.apply_snapshot(
        st_obj, snapshot, hooks={"bridge": lambda: fired.append("bridge")},
        mode="boot", state=state, bus=None))
    assert changed2 == [] and fired == [], (changed2, fired)


# ───────── 守卫五:补算指纹 cfg_fp —— 关闭态不得触发全库补算行重算 ─────────
def _cfg_fp(**over):
    from app.pred_replay import config_fingerprint

    cfg = dict(_load_yaml_pred())
    cfg.update(over)
    return config_fingerprint(PB.PredictorBridge(cfg, {}))


def test_replay_fingerprint_ignores_prior_keys_when_shrink_off():
    """关闭态下,`prior_*` **不得进补算指纹** —— 否则升级即触发全库补算行重算。

    链条:worker 每轮取 `pred_cfg_fingerprint(bridge)` 去比 `db.replay_gaps` 的
    `stale`(= 已有补算行但配置指纹已过期),比不上就 `drop_replay_rows` **全删重算**。
    而 config_fingerprint 是 `dataclasses.asdict(pcfg)` 全字段的 —— 新增任何一个字段
    都会让指纹在升级瞬间变值。于是每个房窗口里的补算行全部被判过期删掉,
    重算出来的却与删掉的**逐位相同**(prior_shrink=False 时引擎与 4.9.3 字节等价)。
    那是一次纯粹白烧:PG 写入尖峰、日志刷屏、前端「近 N 局」的分母在重算完成前
    短暂塌陷 —— 而用户盯的正是那个数。

    这是 `_fr_key` 那条教训的**第二个实例**:凡是「关着的开关」,都不该进任何
    会驱动状态变更的指纹。
    """
    off = _cfg_fp(prior_shrink=False)
    # 关闭态指纹必须与「压根没有这两个字段」时一致 —— 即与 4.9.3 同值
    import dataclasses as _dc

    cfg = dict(_load_yaml_pred())
    cfg["prior_shrink"] = False
    bridge = PB.PredictorBridge(cfg, {})
    d = _dc.asdict(bridge.pcfg)
    assert "prior_shrink" in d and "prior_table" in d, "字段没进 dataclass,本测试失去意义"
    assert off, "指纹算不出来了"
    # 关着时改先验表,指纹不许动(它对输出零影响,重算是白烧)
    assert off == _cfg_fp(prior_shrink=False,
                          prior_table="1:0.2,2:0.1,3:0.1,4:0.1,5:0.1,"
                                      "6:0.1,7:0.1,8:0.1,9:0.1")


def test_replay_fingerprint_does_change_when_shrink_on():
    """开启态必须换指纹 —— 口径真变了,旧补算行与新实盘行**不可比**。

    原文实测过错配量级:逐局判定还原从 97% 塌到 57%、主+防偏差 11pp,
    远超 100 局样本自身 4.7pp 的抽样噪声。所以该重算的时候必须重算。
    """
    off = _cfg_fp(prior_shrink=False)
    on = _cfg_fp(prior_shrink=True)
    assert on != off, "开启收缩后补算指纹没变 —— 旧口径的补算行会被当成同口径混进命中率"
    on2 = _cfg_fp(prior_shrink=True,
                  prior_table="1:0.2,2:0.1,3:0.1,4:0.1,5:0.1,6:0.1,7:0.1,8:0.1,9:0.1")
    assert on2 != on, "开着改先验表指纹没变 —— 换了先验的补算行会与旧行混在一起"


# ──────────── 守卫四:持久化指纹 frk —— 关闭态必须与 4.9.3 逐字节相同 ────────────
def _frk(**over):
    """跑一局,取回写进 PG kv 的 explore_state 里那个 frk(LP 重规划指纹)。"""
    import json as _json
    # 显式钉死 explore_style="frontier" —— frk 是 frontier 规划器专属的 LP 重规划
    # 指纹,其余风格下恒为空串。原写法依赖「config.yaml 默认就是 frontier」,4.9.7
    # 把默认改回 showcase 后会静默变成在比两个空串(第三档 must_differ=False 因此
    # 会「碰巧通过」,另两档误红)。这与 test_frontier.py 中
    # test_showcase_is_still_reachable_and_untouched_by_frontier_fields 的
    # 「显式钉死风格」是同一条纪律的镜像。
    cfg = dict(_load_yaml_pred())
    cfg["explore_style"] = "frontier"
    cfg.update(over)
    bridge = PB.PredictorBridge(cfg, {})
    _res, dirty = bridge.run_prediction("R", [(i % 9) + 1 for i in range(1728)], {})
    return _json.loads(dirty["explore_state"])["frk"]


def test_frk_format_unchanged_when_shrink_off():
    """**关闭态的 frk 不得含 prior_* 段** —— 这一条守的是「实盘升级零扰动」。

    `_fr_key` 会落库持久化(_dump_state 的 "frk")。若无条件改变它的格式,升级那一刻
    每个存量房的 frk 都对不上 ⇒ 首局被强制**离期重解 LP**(旧代码本该等到
    _fr_plan_age >= fr_replan),重解还会顺带按新 mix 修剪赤字账本 _fr_debt
    ⇒ 关闭态下也会出现最多 fr_replan 局的四码分歧。
    「出厂字节等价」若只在冷回放成立、带持久化状态的升级不成立,那句承诺就是空的。
    """
    off = _frk(prior_shrink=False)
    # 4.9.3 的 frk 以 fr_cold_min 打头(第一段是那个 float 的字符串形式)
    assert off.split("|")[0] == str(_load_yaml_pred()["fr_cold_min"]), off[:80]
    assert "prior" not in off and "0.183748" not in off, off[:80]


@pytest.mark.parametrize("a, b, must_differ, why", [
    (dict(prior_shrink=False), dict(prior_shrink=True), True, "关→开:口径变了,必须重解"),
    (dict(prior_shrink=True), dict(prior_shrink=True, prior_table="1:0.2,2:0.1,3:0.1,"
                                   "4:0.1,5:0.1,6:0.1,7:0.1,8:0.1,9:0.1"),
     True, "开着改表:口径变了,必须重解"),
    (dict(prior_shrink=False), dict(prior_shrink=False, prior_table="1:0.2,2:0.1,3:0.1,"
                                    "4:0.1,5:0.1,6:0.1,7:0.1,8:0.1,9:0.1"),
     False, "关着改表:对输出零影响,不该白重解一次 LP"),
])
def test_frk_covers_every_prior_transition(a, b, must_differ, why):
    assert (_frk(**a) != _frk(**b)) is must_differ, why


# ────────── 契约:训练窗↔局数换算的三处实现不得分叉 + 桥文件不得相对 import ──────────
def _audit_sh_formula():
    """从 window_audit/audit-maxxiang.sh **抠出**它自己那份换算源码并可执行化。

    ⚠ 刻意不复制粘贴公式 —— 那正是 test_official_probability.py 顶部点名的反模式:
    「抠源码而非复制粘贴 —— 复制粘贴会让本测试对着自己的副本自证」。
    手抄一份进测试,脚本改了本测试照样绿,分歧就没人知道了。
    """
    import re

    src = (ROOT / "window_audit" / "audit-maxxiang.sh").read_text(encoding="utf-8")
    # ⚠ 该脚本里有**不止一处** STEP 定义(实测 2 处:cmd_config 的配置体检块、
    #   随机抽房块;后者行尾带注释)。只 re.search 取第一处等于只钉一半 ——
    #   另一处被改时脚本内部先自相矛盾,而本测试照样绿。故 finditer 全取,并允许行尾注释。
    steps = [(int(m.group(1)), src[:m.start()].count("\n") + 1)
             for m in re.finditer(r"^STEP\s*=\s*(\d+)\s*(?:#.*)?$", src, re.M)]
    m_need = re.search(r"^need\s*=\s*(.+?)\s*$", src, re.M)
    assert len(steps) >= 2 and m_need, (
        f"audit-maxxiang.sh 里 STEP 定义数={len(steps)}(预期≥2)或找不到 need —— 脚本结构变了,"
        "请同步本测试的抠取规则,别让它退化成只钉一半")
    assert len({v for v, _ in steps}) == 1, (
        f"audit-maxxiang.sh **自身**的多处 STEP 已分叉:{steps}")
    step = steps[0][0]
    expr = m_need.group(1)                       # 例:int(twh*3600*1000/STEP) + 1 if twh > 0 else 0

    def _calc(hours: float) -> int:
        return eval(expr, {"__builtins__": {"int": int}},  # noqa: S307 受控表达式
                    {"twh": float(hours), "STEP": step})

    return step, _calc


def test_rounds_for_hours_agrees_across_all_implementations():
    """训练窗↔局数换算有三处独立实现,必须同规则 —— 分歧会让运维在一处看到 ✘、
    另一处没动静,而两边都言之凿凿。

      · app/constants.rounds_for_hours        管理台语义校验直接用它(单一真源)
      · PredictorBridge._rounds_for_hours     worker 护栏(**不能** import constants,见下条)
      · window_audit/audit-maxxiang.sh        离线体检 —— 本测试**从脚本源码里抠**,不手抄

    第四、五份副本在 assets/app.js(`T.ROUND`)与 audit-maxxiang.sh 的第二个内嵌
    Python 块里 —— 见 test_round_step_never_drifts_across_the_whole_repo。
    """
    from app.constants import ROUND_STEP, rounds_for_hours

    sh_step, sh_calc = _audit_sh_formula()
    assert ROUND_STEP == E.ROUND_STEP == sh_step, (
        f"局步长三处分叉:constants={ROUND_STEP} 引擎={E.ROUND_STEP} "
        f"audit-maxxiang.sh={sh_step};三处换算会同时错开,而配置文件上一个字看不出来")
    for h in (0.1, 0.5, 1, 24, 72, 100, 168, 500, 1000, 8760):
        a = rounds_for_hours(h)
        b = PB.PredictorBridge._rounds_for_hours(h)
        c = sh_calc(h)
        assert a == b == c, (h, a, b, c)


def test_round_step_never_drifts_across_the_whole_repo():
    """局步长 50001 在全仓库有**五份独立副本**,一份都不许漂。

      1. app/constants.ROUND_STEP                  后端权威
      2. jiufa_data/spell_tamer_monitor.ROUND_STEP  引擎
      3. window_audit/audit-maxxiang.sh 第 1 处     配置耦合体检
      4. window_audit/audit-maxxiang.sh 第 2 处     随机抽房的密度判据(行尾带注释)
      5. assets/app.js 的 `T.ROUND`                 前端期号栅格

    第 5 份服务的是**另一件事**(期号 = floor((局起点−北京零点)/T.ROUND)+1),
    但它注释里自己写着「项目 B ROUND_STEP,相邻局 round_id 实测差」—— 是同一个物理常量。
    它漂了不会报错,只会让前端期号与后端错位,而且要跨多局才看得出来。
    这五份此前**一份都没被钉过**;本条不是 4.9.4 引入的债,是 4.9.4 顺手补的。
    """
    import re as _re

    from app.constants import ROUND_STEP

    found = {"app/constants.py": ROUND_STEP, "engine": int(E.ROUND_STEP)}
    sh = (ROOT / "window_audit" / "audit-maxxiang.sh").read_text(encoding="utf-8")
    for i, m in enumerate(_re.finditer(r"^STEP\s*=\s*(\d+)\s*(?:#.*)?$", sh, _re.M), 1):
        found[f"audit-maxxiang.sh#{i}"] = int(m.group(1))
    js = (ROOT / "assets" / "app.js").read_text(encoding="utf-8")
    m_js = _re.search(r"\bROUND\s*:\s*(\d+)", js)
    assert m_js, "assets/app.js 里找不到 T.ROUND —— 前端常量定义变了,请同步本测试"
    found["assets/app.js T.ROUND"] = int(m_js.group(1))

    assert len(found) >= 5, f"副本数={len(found)},少于预期 5 处:{found}"
    assert len(set(found.values())) == 1, f"局步长已在多处分叉:{found}"


#: config.yaml 的注释里引来当**锚点**的代码原文 —— (文件, 片段, 期望出现次数)。
#: 4.9.4 第八轮复查把注释里的「第 N 行」全部换成了这些锚点,原因是行号会被任何一次
#: 插入静默作废:实测 4.9.0 写下的「第 1403/1434/1677/1901/1942 行」**在 4.9.3 原包里
#: 就已经差了 21~44 行**(真值 1424/1455/1721/1945/1986),而 4.9.4 又整体下移约 90 行。
#: 锚点比行号耐用,但它自己也会被重构掉 —— 所以要有这条测试。
CONFIG_ANCHORS = [
    ("jiufa_data/spell_tamer_monitor.py", "fp = [len(seq)] + list(seq[-_fd:])", 1),
    ("jiufa_data/spell_tamer_monitor.py", "fp == self._last_fp", 1),
    ("jiufa_data/spell_tamer_monitor.py", "four = list(self._last_four)", 1),
    ("jiufa_data/spell_tamer_monitor.py",
     "final = self._norm([lam * p1[i] + (1.0 - lam) * ens[i] for i in range(9)])", 2),
    # 4.9.7:由 5 → 6。冷位节拍器的域判定 `_cg_on` 新增一处
    # (`cadence_governor` 与 showcase_rotate 同为 showcase 风格域内生效)。
    ("jiufa_data/spell_tamer_monitor.py", 'explore_style == "showcase"', 6),
    ("jiufa_data/spell_tamer_monitor.py", "if (_ao and not _is_fr) else 0", 1),
    ("jiufa_data/spell_tamer_monitor.py", "final = list(_pfr)", 1),
]


@pytest.mark.parametrize("path, snippet, times", CONFIG_ANCHORS)
def test_code_anchors_quoted_in_config_still_exist(path, snippet, times):
    """config.yaml 注释里引的每一段代码原文,必须在源码里真的存在且出现次数如注所述。

    注释骗人不报错。这个仓库最贵的东西恰恰是那些注释 —— 一条指向不存在代码的注释,
    会让后来人以为某个机制还在,而它可能早被重构掉了。
    """
    src = (ROOT / path).read_text(encoding="utf-8")
    got = src.count(snippet)
    assert got == times, (
        f"{path} 里 `{snippet}` 出现 {got} 次,config.yaml 的注释按 {times} 次写的 —— "
        "代码被重构了就同步改注释,别留一条指向空气的锚点")
    assert snippet in CONFIG_YAML.read_text(encoding="utf-8"), (
        f"config.yaml 已经不再引用 `{snippet}` 了,请从 CONFIG_ANCHORS 里删掉它")


def test_config_yaml_uses_no_bare_line_number_citations():
    """config.yaml 不得再出现**裸的**「第 N 行」引用(指向引擎源码的那种)。

    这是结构性防回退:行号引用一旦写下就开始腐烂,而且腐烂时**完全静默**。
    带「真值/核准/原注/已差」等字样的行是复查留痕(专门在讲某条行号如何失准),放行。
    """
    import re as _re

    bad = [ln.strip() for ln in CONFIG_YAML.read_text(encoding="utf-8").splitlines()
           if _re.search(r"第 \d+ 行", ln)
           and not any(k in ln for k in ("真值", "核准", "原注", "已经差了", "已差"))]
    assert not bad, "config.yaml 出现裸行号引用,请改引代码原文当锚点:\n  " + "\n  ".join(bad)


def test_predictor_bridge_has_no_relative_imports():
    """`app/predictor_bridge.py` **不得出现任何相对 import** —— 这是承重不变量。

    window_audit/replay_harness.py 用 spec_from_file_location 把该文件当**顶层模块**
    单独加载(名字就叫 "predictor_bridge",没有包上下文)。一行 `from .x import y`
    就会 `ImportError: attempted relative import with no known parent package`,
    把 replay_harness / window_judge / analyze_* / frontier_audit 整套审计工具全灭 ——
    而 CI 里没有任何别的测试会跑那套工具,所以这个洞只会在有人手动做窗口审计时炸。
    (已实测:临时插入一行相对 import,replay_harness 当场 ImportError。)
    """
    import ast as _ast

    src = (ROOT / "backend_async" / "app" / "predictor_bridge.py").read_text(encoding="utf-8")
    bad = [f"第 {n.lineno} 行: from {'.' * n.level}{n.module or ''} import ..."
           for n in _ast.walk(_ast.parse(src))
           if isinstance(n, _ast.ImportFrom) and (n.level or 0) > 0]
    assert not bad, (
        "predictor_bridge.py 出现相对 import,会把 window_audit 整套工具打死:\n  "
        + "\n  ".join(bad))


def test_config_center_does_not_drag_in_the_engine():
    """管理台配置校验路径**不得**把预测引擎拉进来。

    config_center 至今只依赖 stdlib + yaml + config_registry(+constants);
    而 web.py 根本不 import predictor_bridge。若为了「复用换算函数」在这里
    import 它,等于把 spell_tamer_monitor(含 requests、含 sys.path 改写)拉进
    web 容器的 HTTP 校验路径,且失败时会静默回落到复制的公式 —— 复活它要消灭的重复。
    """
    import subprocess
    import sys as _sys

    code = ("import sys; sys.path.insert(0, %r); "
            "from app import config_center; "
            "print('spell_tamer_monitor' in sys.modules)"
            % str(ROOT / "backend_async"))
    out = subprocess.run([_sys.executable, "-c", code],
                         capture_output=True, text=True, cwd=str(ROOT / "backend_async"))
    assert out.returncode == 0, out.stderr[-800:]
    assert out.stdout.strip().endswith("False"), (
        "import config_center 时预测引擎被拉起了 —— 检查是否有人在里面 import 了 "
        "predictor_bridge")


# ────────────────── 契约:先验表 × custom_beast_ids 不得分叉 ──────────────────
#: 「按妖兽名」的实盘频率 —— 本文件对 prior_table 的**唯一真源**。
#: 出处:真机三房(1275859/2678075/3746870)7 天 36,278 局,jiufa_data/
#: spell_tamer_data.db 的 rounds 表逐兽计数 / 总局数。
#: prior_table 是按**自定义编号**索引的,而编号由 custom_beast_ids 决定 ——
#: 与 fr_mult / showcase_cold_ids / fr_rare_ids 同一条纪律:改了映射不同批改表,
#: 整张先验会错位而**不报任何错**(沧溟龙的 3.56% 被安到别的兽头上)。
MEASURED_BY_BEAST = {
    "镇岳甲": 0.183748, "苍梧魔": 0.156955, "焚天雀": 0.049286,
    "白虹骥": 0.065246, "玄兵猿": 0.093307, "金羽皇": 0.096725,
    "踏荒牛": 0.157203, "青鸾凤": 0.161916, "沧溟龙": 0.035614,
}


def _parse_prior(raw: str) -> dict:
    out = {}
    for kv in str(raw or "").split(","):
        if ":" in kv:
            c, v = kv.split(":", 1)
            out[int(c.strip())] = float(v)
    return out


def test_measured_table_is_itself_a_distribution():
    """真源自身必须是概率分布 —— 它错了,下面那条对拍就变成自证。"""
    assert set(MEASURED_BY_BEAST) == set(E.DEFAULT_CUSTOM_IDS)
    assert abs(sum(MEASURED_BY_BEAST.values()) - 1.0) < 1e-6


def test_prior_table_matches_deployment_beast_ids():
    """config.yaml 的 custom_beast_ids 与 prior_table 不得分叉。

    改过号位映射就必须同批改先验表,否则先验会**静默错位**:这类失真不报错、
    不白屏,只会让新房头几小时按另一只兽的概率去选号。
    """
    full = yaml.safe_load(CONFIG_YAML.read_text(encoding="utf-8"))
    ids = full.get("custom_beast_ids") or dict(E.DEFAULT_CUSTOM_IDS)
    expect = {int(c): MEASURED_BY_BEAST[n] for n, c in ids.items()}
    got = _parse_prior(full["prediction"]["prior_table"])
    assert sorted(got) == list(range(1, 10)), "prior_table 必须覆盖 1~9 全部号位"
    for c in range(1, 10):
        assert abs(got[c] - expect[c]) < 5e-6, (
            f"号位 {c} 的先验概率与 custom_beast_ids 推出的值分叉:"
            f"表里 {got[c]}, 按映射应为 {expect[c]}。"
            "改过 custom_beast_ids 就必须同批重写 prediction.prior_table")


def test_prior_table_survives_a_remapped_deployment():
    """换一套编号映射时,**未同步**的旧表必然被上面那条抓到(反向自检)。

    没有这条,上面那条测试在\"两边都没改\"时会永远绿,守不住任何东西。
    """
    swapped = dict(E.DEFAULT_CUSTOM_IDS)
    swapped["镇岳甲"], swapped["沧溟龙"] = swapped["沧溟龙"], swapped["镇岳甲"]
    expect = {int(c): MEASURED_BY_BEAST[n] for n, c in swapped.items()}
    shipped = _parse_prior(
        yaml.safe_load(CONFIG_YAML.read_text(encoding="utf-8"))["prediction"]["prior_table"])
    assert any(abs(shipped[c] - expect[c]) > 5e-6 for c in range(1, 10)), (
        "映射换掉两只兽后,出厂先验表竟仍然\"匹配\" —— 说明上面那条对拍是自证的")


# ───────────────────────── 连带:max_train 截短告警 ─────────────────────────
@pytest.mark.parametrize("tw, mt, should_warn", [
    (24.0, 5000, False), (72.0, 5000, True), (0.0, 5000, False),
    (24.0, 0, False), (168.0, 20000, False),
])
def test_admin_panel_also_warns_on_truncation(tw, mt, should_warn):
    """管理台保存时也必须就此告警 —— **运维改这两个值的地方是管理台,不是日志。**

    训练窗有两条被静默截短的路:retention.days(4.x 起 semantic_validate 已拦)与
    max_train(4.9.4 补齐,此前管理台一句话都不说)。判据与
    predictor_bridge._warn_train_window_truncated / audit-maxxiang.sh 同源。
    """
    from app import config_center as cc
    cand = {"prediction.train_window_hours": tw, "prediction.max_train": mt}
    _errs, warns = cc.semantic_validate(cand, set(cand))
    hit = any("静默截短" in w and "max_train" in w for w in warns)
    assert hit is should_warn, (tw, mt, warns)


@pytest.mark.parametrize("tw, mt, should_warn", [
    (24.0, 5000, False),      # 现行:24h≈1728 局 << 5000,不该喊
    (72.0, 5000, True),       # 72h≈5184 局 > 5000,被静默截短
    (0.0, 5000, False),       # 窗口不限时 ⇒ 无串联可言
    (24.0, 0, False),         # 计数不设上限
    (168.0, 20000, False),    # 已按窗口配足
])
def test_train_window_truncation_warning(caplog, tw, mt, should_warn):
    cfg = dict(_load_yaml_pred())
    cfg.update(train_window_hours=tw, max_train=mt)
    with caplog.at_level("WARNING"):
        PB.PredictorBridge(cfg, {})
    hit = any("静默截短" in r.getMessage() for r in caplog.records)
    assert hit is should_warn, (tw, mt, [r.getMessage() for r in caplog.records])


#: window_audit/audit-maxxiang.sh 里引用源码位置的**行号**——(被引文件, 行号, 该行必含的片段)。
#: 4.9.7 复查实测:该脚本有 6 处行号引用,其中 **3 处已腐烂**且完全静默——
#:   · `spell_tamer_monitor.py:1070 seq = seq[-self.cfg.max_train:]` 真值 1491(差 421 行)
#:   · `settings.py:497 的优先级链`                                   真值 829
#:   · `replay_harness.py:32 用 setdefault`                          真值 51
#: 三处已就地改成代码锚点。config.yaml 早在 4.9.4 就立了「行号引用不可信」的纪律并配了
#: test_config_yaml_uses_no_bare_line_number_citations,但那条**只看 config.yaml** ——
#: 于是同一种腐烂在运维面对的诊断脚本里继续长了三处没人发现。本表把剩下那几处纳入监视。
_AUDIT_SH_LINE_CITATIONS = [
    ("backend_async/app/predictor_bridge.py", 20, "from __future__ import annotations"),
    ("jiufa_data/spell_tamer_monitor.py", 20, "dataclasses"),
    ("window_audit/analyze_extra.py", 80, "comb"),
]


@pytest.mark.parametrize("path, lineno, snippet", _AUDIT_SH_LINE_CITATIONS)
def test_audit_script_line_citations_still_point_at_the_right_line(path, lineno, snippet):
    """`audit-maxxiang.sh` 里残留的行号引用必须仍指向它声称的那行代码。

    这些引用是运维排障时的**跳转坐标**,指错了会把人带到完全无关的代码上
    (实测那三处腐烂的其中一处,第 1070 行是 `self._fr_mix = {...}`,与 max_train 毫无关系)。
    留着行号而不是全改锚点,是因为这三条都在文件**头部**(第 20/80 行,import 区),
    位置稳定且「第几行」本身就是它要表达的信息(Python 版本门槛来自哪一行 import)。
    但稳定 ≠ 不会变 —— 所以给它们配一道钉。哪天真漂了,改锚点或改行号,别装看不见。
    """
    lines = (ROOT / path).read_text(encoding="utf-8").split("\n")
    assert lineno <= len(lines), f"{path} 只有 {len(lines)} 行,引用的第 {lineno} 行不存在"
    got = lines[lineno - 1]
    assert snippet in got, (
        f"audit-maxxiang.sh 引用 {path}:{lineno} 说该行含 `{snippet}`,"
        f"实际是 `{got.strip()[:70]}` —— 行号已腐烂,请改引代码原文当锚点")


def test_audit_script_has_no_stale_engine_line_citations():
    """审计脚本不得再新增指向引擎/后端**函数体内部**的裸行号引用。

    头部 import 区(<=100 行)的引用按上一条钉住;更深的位置一律要求用代码锚点 ——
    实测正是那三处深位引用(1070/497/32 行)全烂了,而头部那三处至今准确。
    """
    import re as _re
    sh = (ROOT / "window_audit" / "audit-maxxiang.sh").read_text(encoding="utf-8")
    deep = [m.group(0) for m in _re.finditer(r"[\w/.]+\.py:(\d+)", sh)
            if int(m.group(1)) > 100]
    assert not deep, (
        "审计脚本出现指向文件深处的裸行号引用,请改引代码原文当锚点"
        f"(深位行号会被任何一次插入静默作废,实测已烂过三处): {deep}")


#: 全仓「文件:行号」形式的源码引用**清单**。4.9.7 复查全仓普查实测:35 处引用里,
#: 可在仓内核验的 11 处**烂了 10 处** —— 最离谱的 `app.js:2715`(声称是
#: markBoardPrediction,真值 5062)与 `config_center.py:174`(声称是「启动期敏感真值
#: 不可得:跳过」,真值 261)。它们散落在 JFVIP/SSO/REGISTER/PG-INDEX 四份文档、
#: assets/{app,admin}.js 与两个测试里,**与本次改动无关**,故按仓库自己的纪律
#: (「混在一起会让回滚面变大」)不在本次交付里改,而是登记成**可见的债**。
#:
#: 本守卫不判对错(引用方声称什么无法自动判定),只钉**清单不得增长**:
#: 谁新写一条行号引用就会红,届时要么改引代码原文当锚点(4.9.4 定的纪律),
#: 要么显式登记进来并写明为什么非用行号不可。存量债修掉一条就从表里删一条。
_KNOWN_LINE_CITATIONS = {
    # ── 已实地核验为**准确**的(仍建议改锚点,但不阻塞)──────────────────────
    ("backend_async/app/userauth.py", "tests/test_jfvip_asgi.py:118"),
    ("window_audit/audit-maxxiang.sh", "app/predictor_bridge.py:20"),
    ("window_audit/audit-maxxiang.sh", "jiufa_data/spell_tamer_monitor.py:20"),
    ("window_audit/audit-maxxiang.sh", "window_audit/analyze_extra.py:80"),
    # ── 已实地核验为**腐烂**的存量债(真值见括号)────────────────────────────
    ("assets/app.js", "userauth.py:1171"),          # 声称「注册上限 20 字」,该行是代理/镜像站注释
    ("assets/app.js", "web.py:1099"),               # 声称「round_id ≡ start_ms 明述」,真值 1459+
    ("assets/admin.js", "admin_api.py:1233"),       # 声称 GET 端点回 ok:false,该行是 _guard_write
    ("JFVIP-SYSTEM.md", "app.js:2715"),             # 声称 markBoardPrediction,真值 5062
    ("JFVIP-SYSTEM.md", "web.py:1099"),             # 同上 round_id,真值 1459+
    ("PG-INDEX-DIET.md", "worker.py:1212"),         # 声称 has_round 的 N+1,真值 661/720/818/839
    ("REGISTER-SYSTEM.md", "app/web.py:656"),       # 声称 _pow_answer,真值 72/1211+
    ("REGISTER-SYSTEM.md", "assets/app.js:551"),    # 声称 powAnswer,真值 69/70/83/1008
    ("REGISTER-SYSTEM.md", "index.html:396"),       # 未逐字核验(HTML 无稳定锚点),一并登记
    ("SSO-LOGIN.md", "app/config_center.py:174"),   # 声称「启动期敏感真值不可得」,真值 261
    ("LOGIN-SYSTEM.md", "connection.py:544"),       # 指向 aiomysql 内部,仓外不可核验
    ("backend_async/tests/test_sso_link.py", "userauth.py:2755"),        # 该行是 `},`
    ("backend_async/tests/test_jfvip_admin_realdb.py", "web.py:290"),    # 声称中间件,真值 468/476
    ("backend_async/scripts/toast_contention_probe.js", "admin.js:274"),
    ("backend_async/scripts/frontend_replay_jsdom.js", "frontend_jfvip_jsdom.js:138"),
    # ── window_audit/AUDIT-4.9.5 报告里的 4 处,已实地核验**当前准确**
    #    (该文档较新,尚未腐烂;仍属债 —— 只要被引文件插几行就会静默失准)
    ('window_audit/AUDIT-4.9.5-#U8bad#U7ec3#U7a97#U4e0e#U6837#U672c#U4e0a#U9650.md', "app/config_center.py:41"),      # from .constants import (ROUND_STEP…
    ('window_audit/AUDIT-4.9.5-#U8bad#U7ec3#U7a97#U4e0e#U6837#U672c#U4e0a#U9650.md', "app/worker.py:527"),            # return await self.bus.is_cold(room)
    ('window_audit/AUDIT-4.9.5-#U8bad#U7ec3#U7a97#U4e0e#U6837#U672c#U4e0a#U9650.md', "worker.py:263"),                # self.bridge = PredictorBridge(…)
    ('window_audit/AUDIT-4.9.5-#U8bad#U7ec3#U7a97#U4e0e#U6837#U672c#U4e0a#U9650.md', "window_judge.py:46"),           # async def _go()(无稳定锚点可验)
    # ↓ 5.2.0:同一份审计文档在发布包里有两份 —— 上面那份是 Info-ZIP 转义名(#Uxxxx,
    #   在不支持 Unicode 文件名的解压器下产生),这份是正常中文名;内容逐字节相同、
    #   引用同理(原文锚点见上)。只登记了转义名那份时,中文名副本让本用例基线即红。
    ('window_audit/AUDIT-4.9.5-训练窗与样本上限.md', "app/config_center.py:41"),      # from .constants import (ROUND_STEP…
    ('window_audit/AUDIT-4.9.5-训练窗与样本上限.md', "app/worker.py:527"),            # return await self.bus.is_cold(room)
    ('window_audit/AUDIT-4.9.5-训练窗与样本上限.md', "worker.py:263"),                # self.bridge = PredictorBridge(…)
    ('window_audit/AUDIT-4.9.5-训练窗与样本上限.md', "window_judge.py:46"),           # async def _go()(无稳定锚点可验)
}
#: 指向**第三方库**内部的引用(aiomysql 等),仓内无从核验,整文件豁免。
_LINE_CITATION_EXEMPT_FILES = {"backend_async/app/userdb_pool.py"}


def test_repo_wide_line_citations_do_not_grow():
    """全仓行号引用清单不得增长 —— 新写的一律改引代码原文当锚点。

    4.9.4 在 config.yaml 上立过这条纪律并配了守卫,但那条**只看 config.yaml**,
    于是同一种腐烂在别处继续长:4.9.7 全仓普查实测 11 处可核验引用**烂了 10 处**,
    其中三处在运维/开发每天要读的 `audit-maxxiang.sh` 里(已就地改锚点)。
    行号引用的坏处不是"会错",是**错了完全静默** —— 读的人会照它跳到一段毫不相干
    的代码上,然后基于那段代码做判断。
    """
    import re as _re
    pat = _re.compile(r"([A-Za-z_][A-Za-z0-9_/.-]*\.(?:py|js|mjs|sh|yaml|html)):(\d{2,})")
    found = set()
    for sub in ("", "backend_async", "window_audit", "assets", "jiufa_data"):
        base = ROOT / sub if sub else ROOT
        for ext in ("*.py", "*.sh", "*.md", "*.js", "*.mjs", "*.yaml"):
            for p in base.glob(ext):
                rel = str(p.relative_to(ROOT))
                if rel in _LINE_CITATION_EXEMPT_FILES:
                    continue
                try:
                    txt = p.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue
                for m in pat.finditer(txt):
                    found.add((rel, m.group(0)))
    for sub in ("backend_async/app", "backend_async/tests", "backend_async/scripts"):
        for p in (ROOT / sub).glob("*.py"):
            rel = str(p.relative_to(ROOT))
            if rel in _LINE_CITATION_EXEMPT_FILES:
                continue
            txt = p.read_text(encoding="utf-8", errors="replace")
            for m in pat.finditer(txt):
                found.add((rel, m.group(0)))
    # 本文件自身在讲这些引用,不算引用
    found = {x for x in found if not x[0].endswith("test_prior_shrink.py")}
    new = sorted(found - _KNOWN_LINE_CITATIONS)
    assert not new, (
        "出现未登记的行号引用。行号会被任何一次插入静默作废(全仓实测 11 处已烂 10 处)"
        " —— 请改引代码原文当锚点;确有理由必须用行号的,登记进 _KNOWN_LINE_CITATIONS "
        f"并写明理由: {new}")
