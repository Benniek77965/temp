"""
test_lease_renew_cadence.py — 3.9.5:SSE 活跃房租约的**独立续租节拍**(消除 flapping)
================================================================================
背景(实地复核出的真实缝隙,本用例即其回归钉)
------------------------------------------------------------------------------
旧实现里,一条常开 SSE 的稳态续租**只发生在「20s 静默心跳」分支**;而 draw 事件会
刷新 `last_beat`,把心跳无限后推。结合本游戏的局节奏:

    ROUND_STEP ≈ 50s/局;每局 MainPage@起点 + RoundAward@+40s
    → 事件静默间隔呈 40s / 10s 交替,仅那个 40s 空档能触发一次心跳

于是**续租实际间隔 ≈ 每局一次(~50s)> 租约 TTL(默认 40s)** —— 一条一直在正常供数的
SSE,其租约会**周期性空窗 ~10s/局**。空窗里别的房(乃至跨设备)可挂上第二条 SSE
(建流期 `_lease_follow` 见「空租约 → 授予」),"同一时间只监控 1 个房"被击穿。

3.9.5 修复:在主循环里加一条**与数据/心跳解耦的固定续租节拍**(≤TTL/2 且 ≤15s),
不受 draw 推迟。

本用例钉住的契约
------------------------------------------------------------------------------
  · 繁忙房(持续 draw、心跳永不触发)下,租约 ts 仍被**按节拍**推进 → 永不空窗;
  · 续租走 renew(claim=False):被别处切走时,即便正忙也会 follow 收流(不抢占、不抖动);
  · 节拍 = clamp(TTL/2, 3s, 15s) —— 与 TTL 的数学关系钉死(改坏即红)。

零外部依赖:fakeredis + 桩,模式与 test_lease_switch_broadcast.py 同源。
"""
import asyncio
import contextlib
import json
import sys
import time
import types
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app.web as web                           # noqa: E402
from app.redis_bus import RedisBus              # noqa: E402

UID = 7


def _bus():
    import fakeredis.aioredis
    bus = RedisBus.__new__(RedisBus)
    bus.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    bus._lease_acq_sha = None
    bus._lease_rel_sha = None
    return bus


def _lua_ok() -> bool:
    try:
        import fakeredis
        fakeredis.FakeStrictRedis().eval("return 1", 0)
        return True
    except Exception:
        return False


pytestmark = pytest.mark.skipif(not _lua_ok(), reason="fakeredis 无 Lua 支持(pip install lupa)")


class _User:
    def __init__(self, uid=UID):
        self.user_id = uid


class _SseReq:
    headers = {}
    cookies = {}
    query_params = {"tab": "W1"}
    state = types.SimpleNamespace(user=_User())
    client = types.SimpleNamespace(host="1.1.1.1")


def _wire(monkeypatch, bus, ttl_s):
    """把 events() 的外部依赖全部桩掉,只留租约链路真实(fakeredis + 真 Lua)。"""
    async def _validate(tok):
        return "ok", None, {}
    monkeypatch.setattr(web, "userauth", types.SimpleNamespace(
        enabled=lambda: True,
        UA=types.SimpleNamespace(cfg=types.SimpleNamespace(cookie_name="jf_s")),
        validate=_validate))
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.ST, "db", types.SimpleNamespace(), raising=False)  # roster fail-open
    monkeypatch.setattr(web.settings.userauth, "active_room_lease", True, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease_ttl_s", ttl_s, raising=False)

    async def _canon(r):
        return str(r), True
    monkeypatch.setattr(web.ST, "star", types.SimpleNamespace(canon=_canon), raising=False)

    async def _noop(*a, **k):
        return None
    monkeypatch.setattr(web, "_touch_room", _noop)

    async def _snap(*a, **k):
        return {}
    monkeypatch.setattr(web.ST.bus, "get_snapshot", _snap, raising=False)


async def _drain(it, stop_evt, seen):
    """持续消费 SSE 事件直到收流/被取消(模拟一个真实在看的客户端)。"""
    try:
        while not stop_evt.is_set():
            ev = await it.__anext__()
            seen.append(getattr(ev, "event", ""))
    except (StopAsyncIteration, asyncio.CancelledError):
        pass
    except Exception:
        pass


@pytest.mark.asyncio
async def test_renew_cadence_is_ttl_half_clamped(monkeypatch):
    """节拍 = clamp(TTL/2, 1s, 15s) —— 与 TTL 的数学关系钉死。
    这是「续租间隔恒 ≤ TTL/2」这一安全不变量的**唯一来源**,故单独钉一条。
    (TTL 下限 5s 由端点内 max(5.0, ...) 保证 → 节拍最小 2.5s,不会退化成忙轮询。)

    历史教训(本断言的由来):首版写成 `max(3.0, min(15.0, TTL/2))`,TTL=5s 时得 3.0s
    > TTL/2=2.5s —— 虽仍 <TTL 不至立刻空窗,但一个 TTL 窗口内只续得 1 次,丢一拍
    (Redis 抖动/调度延迟)即空窗。下限钳**绝不允许上抬到超过 TTL/2**。"""
    def cadence(ttl_s):
        ttl_ms = int(max(5.0, float(ttl_s)) * 1000)
        return max(1.0, min(15.0, (ttl_ms / 1000.0) / 2.0))

    assert cadence(40.0) == 15.0        # 默认 TTL:15s 封顶(仍 ≪ 40s,且 <20s 心跳)
    assert cadence(20.0) == 10.0        # TTL/2
    assert cadence(8.0) == 4.0          # TTL/2
    assert cadence(5.0) == 2.5          # TTL/2(下限钳 1.0 不触发)
    assert cadence(1.0) == 2.5          # TTL 被 max(5.0) 抬到 5 → 2.5
    assert cadence(600.0) == 15.0       # 上限钳
    # 不变量:任何 TTL 下,节拍恒 ≤ TTL/2 → 每个 TTL 窗口至少续 2 次,丢一次仍不空窗
    for ttl in (5.0, 8.0, 20.0, 40.0, 120.0, 600.0):
        assert cadence(ttl) <= max(5.0, ttl) / 2.0 + 1e-9
    # 且恒 ≥1s:不会因 TTL 配得极小而退化成忙轮询(打爆 Redis)
    for ttl in (5.0, 40.0, 600.0):
        assert cadence(ttl) >= 1.0


@pytest.mark.asyncio
async def test_busy_room_lease_never_expires(monkeypatch):
    """**核心回归钉**:繁忙房(持续 draw → 心跳永不触发)下,租约 ts 仍被按节拍推进。

    构造:TTL=6s → 续租节拍 3s;每 1s 灌一个 draw(旧实现里这会把 20s 心跳无限后推,
    使 6s 的租约在 ~6s 后过期 → 空窗)。观察 ~7s(>TTL),断言全程租约存活且 ts 前进。
    旧实现下本用例必红(租约会消失/ts 停滞在建流那一刻)。
    """
    bus = _bus()
    _wire(monkeypatch, bus, ttl_s=6.0)          # → 节拍 = max(3, min(15, 3)) = 3s

    resp = await web.events(_SseReq(), roomId="321")
    it = resp.body_iterator
    ev1 = await asyncio.wait_for(it.__anext__(), timeout=3)
    assert getattr(ev1, "event", "") == "connected"

    ts0 = int(await bus.r.hget("alr:u7", "ts"))
    assert await bus.r.hget("alr:u7", "room") == "321"

    stop = asyncio.Event()
    seen = []
    drainer = asyncio.create_task(_drain(it, stop, seen))

    # 持续灌 draw:模拟繁忙房。每 1s 一个 → last_beat 恒被刷新 → 心跳分支永不触发。
    async def _pump():
        for i in range(7):
            await bus.r.publish(bus.draw_channel("321"),
                                json.dumps({"type": "round", "round": {"round_id": i}}))
            await asyncio.sleep(1.0)
    pump = asyncio.create_task(_pump())

    # 观察窗 7.5s > TTL(6s):若续租依赖心跳,租约早已过期消失。
    await asyncio.sleep(7.5)

    room_now = await bus.r.hget("alr:u7", "room")
    assert room_now == "321", "繁忙房下租约不得空窗/消失(旧实现在此必红)"
    ts_now = int(await bus.r.hget("alr:u7", "ts"))
    assert ts_now > ts0, "租约 ts 应被独立节拍持续推进(不被 draw 推迟)"
    # 存活余量:距上次续租远小于 TTL(证明是"续住"而非"恰好卡在过期边缘")
    assert (int(time.time() * 1000) - ts_now) < 6_000

    # 心跳确实没被触发过(证明本用例打的正是"draw 推迟心跳"这条路径)
    assert "heartbeat" not in seen, "本用例前提:繁忙房下心跳不触发"

    stop.set()
    pump.cancel()
    drainer.cancel()
    for t in (pump, drainer):
        with contextlib.suppress(BaseException):
            await t
    with contextlib.suppress(BaseException):
        await asyncio.wait_for(it.aclose(), timeout=3)


@pytest.mark.asyncio
async def test_busy_room_still_follows_when_preempted(monkeypatch):
    """繁忙房下被别处显式切走 → 仍在**一个节拍内**follow 收流(不抢占、不抖动)。
    证明新增节拍走的是 renew(claim=False) 语义,而非把租约抢回来。"""
    bus = _bus()
    _wire(monkeypatch, bus, ttl_s=6.0)          # 节拍 3s

    resp = await web.events(_SseReq(), roomId="321")
    it = resp.body_iterator
    ev1 = await asyncio.wait_for(it.__anext__(), timeout=3)
    assert getattr(ev1, "event", "") == "connected"

    # 持续灌 draw(繁忙房);注意**不发**租约广播 —— 只靠新增的续租节拍发现"被切走"。
    async def _pump():
        for i in range(12):
            await bus.r.publish(bus.draw_channel("321"),
                                json.dumps({"type": "round", "round": {"round_id": i}}))
            await asyncio.sleep(0.5)
    pump = asyncio.create_task(_pump())

    await asyncio.sleep(0.3)
    # 别的窗口显式 claim 走 654(真实时钟,避免被判整把过期)
    ok, held = await bus.active_room_acquire(UID, "654", "C",
                                             int(time.time() * 1000), 6_000, claim=True)
    assert (ok, held) == (True, "654")

    # 无广播,纯靠节拍(≤3s)发现;放宽到 6s 硬顶,超时即说明节拍失效
    ev = None
    deadline = time.time() + 6.0
    while time.time() < deadline:
        nxt = await asyncio.wait_for(it.__anext__(), timeout=6.0)
        if getattr(nxt, "event", "") == "follow":
            ev = nxt
            break
    assert ev is not None, "被切走后应在一个续租节拍内 follow"
    assert json.loads(getattr(ev, "data", "{}"))["room"] == "654"
    # 且**没有**把租约抢回本房(renew 永不抢占 —— 否则两窗互抢会抖动)
    assert await bus.r.hget("alr:u7", "room") == "654"

    with pytest.raises(StopAsyncIteration):
        await asyncio.wait_for(it.__anext__(), timeout=3)

    pump.cancel()
    with contextlib.suppress(BaseException):
        await pump
