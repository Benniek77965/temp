"""
test_active_room_lease.py — 安全加固 3.9.0:每账号「同时只监控 1 个活跃房」租约
                            + 每账号明细读限流(零外部依赖:fakeredis + 桩)
================================================================================
钉住的契约(逐条对应实现里的判据,改坏任一条本用例即红):

一、租约 Lua 决策表(**last-wins**,3.9.3 —— 以最后一次切换的直播间为准):
  · 无持租 / 持租过期(now-ts>ttl)        → 授予
  · claim=1(用户**显式切房**)            → 授予(无条件抢占;其余窗口随后跟随)
  · 持租房 == 请求房                      → 授予(同房多视图 / 心跳续租)
  · 其余(renew 时已被别处切走)           → {0, 活跃房} → 前端**自动跟随**过去
  · renew 对异房**永不抢占**(否则两窗心跳互抢 → 抖动);跟随后不续旧房 → 收敛
  · t: 集合两道剪枝:陈旧项 + 超 CAP=32 的最旧活项(tab 攻击者可控且 SSE 无限流)
  · 条件释放:仅当持租正是 (room, tab) 才删(多页并存不误删他人租约)

二、web 层三闸的「不误伤」姿态(与 _user_room_deny 同款):
  · 登录系统未启用 → 恒放行;· 无登录身份(运维旁路 / 测试直调)→ 恒放行;
  · 特性开关关闭   → 恒放行;· Redis / 限流器异常 → **fail-open** 放行。
  只有「确定性的越界」才拒:超配额 → 429 rate_limited。异房**不再是拒绝**,而是
  409 room_switched + 应跟随的房号(last-wins:自动切换,不阻断任何窗口)。
"""
import sys
import json
import time
import types
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app.redis_bus as rb                      # noqa: E402
import app.web as web                           # noqa: E402
from app.redis_bus import RedisBus              # noqa: E402

TTL_MS = 40_000
NOW = 1_700_000_000_000
UID = 7


def _bus():
    import fakeredis.aioredis
    bus = RedisBus.__new__(RedisBus)
    bus.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    bus._lease_acq_sha = None
    bus._lease_rel_sha = None
    return bus


def _lua_ok() -> bool:
    """fakeredis 需装 lupa 才能跑 EVAL;缺则跳过(CI 无 lupa 时不误报红)。"""
    try:
        import fakeredis
        fakeredis.FakeStrictRedis().eval("return 1", 0)
        return True
    except Exception:
        return False


pytestmark = pytest.mark.skipif(not _lua_ok(), reason="fakeredis 无 Lua 支持(pip install lupa)")


# ══ 一、租约 Lua 决策表 ═══════════════════════════════════════════════════════
@pytest.mark.asyncio
async def test_lease_grant_same_room_multiview_and_claim_switch():
    """last-wins 下的授予路径:首次抢租 / 同房多视图·续租 / **显式 claim 换房**(抢占)/
    整把过期后重授。**独苗规则已移除** —— 换房不再靠「是不是唯一活页」,而靠 claim。"""
    bus = _bus()
    ok, held = await bus.active_room_acquire(UID, "A", "tabA", NOW, TTL_MS)
    assert (ok, held) == (True, "A")                      # 首次
    ok, _ = await bus.active_room_acquire(UID, "A", "tabA", NOW + 1_000, TTL_MS)
    assert ok is True                                     # 同页同房:续租
    ok, _ = await bus.active_room_acquire(UID, "A", "tabB", NOW + 2_000, TTL_MS)
    assert ok is True                                     # 异页**同房**:多视图放行
    # renew 想换到别的房(仍有别的活页在 A)→ 不抢占,回跟随目标 A
    ok, held = await bus.active_room_acquire(UID, "B", "tabB", NOW + 3_000, TTL_MS)
    assert (ok, held) == (False, "A")
    # **显式 claim** 换到 B → 无条件抢占(这才是 last-wins 的换房路径,与是否独苗无关)
    ok, held = await bus.active_room_acquire(UID, "B", "tabB", NOW + 3_100, TTL_MS,
                                             claim=True)
    assert (ok, held) == (True, "B")
    assert await bus.r.hget("alr:u7", "room") == "B"
    # 整把租约过期后,即便只是 renew 新房也重授(空/过期分支,与独苗无关)
    b2 = _bus()
    await b2.active_room_acquire(UID, "A", "tabA", NOW, TTL_MS)
    ok, held = await b2.active_room_acquire(UID, "C", "tabZ", NOW + TTL_MS + 1, TTL_MS)
    assert (ok, held) == (True, "C"), "整把过期 → renew 也重授(非独苗规则)"


@pytest.mark.asyncio
async def test_release_no_phantom_lease_after_preempt():
    """**回归钉子**(审计发现的真 bug):last-wins 下 claim 抢占**不 DEL**旧 tab 项。
    旧 REL 实现一上来就按房号匹配、不符即整个 no-op —— 于是被抢占窗口关页时,它用的
    是**旧房号**,自己的 t: 项**永久残留**;最后一个真实观看者关窗时 alive 把残留项
    算作活页 → 整把租约不删 → **幽灵租约**(无人观看却仍指向某房)→ 新窗口被要求
    跟随到没人看的房。修法:摘 tab 与房号**解耦**(我要走了就该退场,只动我自己的
    字段天然安全);**整把删除**才需房号匹配(房不符=别人已 claim 走,绝不能删)。"""
    bus = _bus()
    await bus.active_room_acquire(UID, "321", "A", NOW, TTL_MS)
    await bus.active_room_acquire(UID, "654", "B", NOW + 1, TTL_MS, claim=True)
    # A 被抢占后**未跟随就关窗**:release 用的是旧房 321
    await bus.active_room_release(UID, "321", "A", NOW + 2, TTL_MS)
    h = await bus.r.hgetall("alr:u7")
    assert "t:A" not in h, "本页 t: 必须被摘除(否则形成幽灵租约)"
    assert h.get("room") == "654" and "t:B" in h, "绝不能误删 B 刚抢下的租约"
    # B 关窗 → 已无活页 → 整把删除(零等待换房的基础)
    await bus.active_room_release(UID, "654", "B", NOW + 3, TTL_MS)
    assert await bus.r.hgetall("alr:u7") == {}, "最后一页关窗后租约必须整把清空"
    # 新窗口开 321 → 必须正常拿到 321(不被拽到无人观看的 654)
    ok, held = await bus.active_room_acquire(UID, "321", "C", NOW + 4, TTL_MS)
    assert (ok, held) == (True, "321"), "无幽灵残留时新窗口应正常拿到自己点的房"


@pytest.mark.asyncio
async def test_release_never_misdeletes_others_lease():
    """释放的安全边界(改摘-tab 解耦后必须仍成立):房不符 → 绝不整把删除。"""
    bus = _bus()
    # 同页换房:老流 finally 用旧房迟到 release,不得删掉本页刚 claim 的新租约
    await bus.active_room_acquire(UID, "321", "A", NOW, TTL_MS)
    await bus.active_room_acquire(UID, "654", "A", NOW + 1, TTL_MS, claim=True)
    await bus.active_room_release(UID, "321", "A", NOW + 2, TTL_MS)
    assert (await bus.r.hgetall("alr:u7")).get("room") == "654", \
        "旧房 release 不得删掉本页刚 claim 的新租约"
    # 同房多视图:A 关窗,B 还在看 → 租约留任
    b2 = _bus()
    await b2.active_room_acquire(UID, "654", "A", NOW, TTL_MS)
    await b2.active_room_acquire(UID, "654", "B", NOW, TTL_MS)
    await b2.active_room_release(UID, "654", "A", NOW + 1, TTL_MS)
    h = await b2.r.hgetall("alr:u7")
    assert h.get("room") == "654" and "t:B" in h and "t:A" not in h


@pytest.mark.asyncio
async def test_lease_tab_set_bounded_against_random_tabs():
    """**回归钉子**(审计发现):tab 由客户端头 `X-JF-Tab` / 查询串 `?tab=` 提供 ——
    **攻击者可控**;而 SSE 建流路径**无限流兜底**,同房 renew 会 HSET t:{tab}。
    若不封顶,随机 tab 可按**连接速率**把租约 hash 撑大(实测 3000 次 → 3000 条目/64KB,
    单账号)。Lua 现按 CAP=32 淘汰最旧活项(稳态 33 = 32 + 本次自己)。
    安全性:last-wins 下 t: 集合只用于「剪陈旧」与 REL 的「还有没有活页」,无决策依赖
    条目数;误淘活页时它下一拍 renew 会重新 HSET,行为无损。"""
    bus = _bus()
    for i in range(3000):
        await bus.active_room_acquire(UID, "321", f"sse-tab-{i:08d}", NOW, TTL_MS)
    h = await bus.r.hgetall("alr:u7")
    tabs = [k for k in h if k.startswith("t:")]
    assert len(tabs) <= 33, f"tab 集合必须封顶(稳态 ≤33),得 {len(tabs)}"
    # 真实用户的小量 tab 完全不受影响
    b2 = _bus()
    for tb in ("A", "B", "C"):
        await b2.active_room_acquire(UID, "321", tb, NOW, TTL_MS)
    assert len([k for k in (await b2.r.hgetall("alr:u7")) if k.startswith("t:")]) == 3
    # 淘汰的是**最旧**的(保留最新)
    b3 = _bus()
    for i in range(50):
        await b3.active_room_acquire(UID, "321", f"tab{i:03d}", NOW + i, TTL_MS)
    keys = [k for k in (await b3.r.hgetall("alr:u7")) if k.startswith("t:")]
    assert "t:tab049" in keys and "t:tab000" not in keys, "必须淘汰最旧、保留最新"


@pytest.mark.asyncio
async def test_lease_no_permanent_lockout_when_holder_dies():
    """回归钉子(实测发现的真 bug)+ last-wins:持租页崩溃/未释放,另一页持续看**同一房**
    把整把租约续新。按活标签页集合:崩溃页 ≤ttl 即陈旧被剪。而在 last-wins 下,任何**显式
    切房(claim)一律抢占**,因此**根本不存在锁死** —— 幸存页 claim 别的房必然成功。"""
    bus = _bus()
    await bus.active_room_acquire(UID, "A", "dead", NOW, TTL_MS)      # dead 页持租
    t = NOW
    for _ in range(4):                                                # alive 页持续看同一房
        t += TTL_MS // 2                                              # (不断把 ts 续新)
        ok, _ = await bus.active_room_acquire(UID, "A", "alive", t, TTL_MS)
        assert ok is True
    # last-wins:幸存页**显式切房**(claim)到 B → 无条件抢占,必放行(永不锁死)
    ok, held = await bus.active_room_acquire(UID, "B", "alive", t, TTL_MS, claim=True)
    assert (ok, held) == (True, "B")
    assert await bus.r.hget("alr:u7", "room") == "B"


@pytest.mark.asyncio
async def test_lease_renew_other_room_returns_follow_target():
    """last-wins:renew 到异房 → 不抢占,回「当前活跃房」作为**跟随目标**(租约不篡改)。
    (返回形态 (False, held) 与旧 incumbent 的「拒绝」相同,但语义是跟随而非阻断。)"""
    bus = _bus()
    await bus.active_room_acquire(UID, "A", "tabA", NOW, TTL_MS)
    ok, held = await bus.active_room_acquire(UID, "B", "tabB", NOW + 1_000, TTL_MS)
    assert ok is False and held == "A"                    # 跟随目标 = 当前活跃房 A
    assert await bus.r.hget("alr:u7", "room") == "A"      # renew 不篡改租约


@pytest.mark.asyncio
async def test_lease_no_tab_id_pins_to_first_room():
    """无标签页标识(纯 API 搬运器不会带 X-JF-Tab/tab=)= 从严:
    第一个房占住租约,再拉**别的**房一律被拒 —— 正是「一账号只能盯 1 房」。"""
    bus = _bus()
    ok, _ = await bus.active_room_acquire(UID, "A", "", NOW, TTL_MS)
    assert ok is True
    ok, held = await bus.active_room_acquire(UID, "B", "", NOW + 100, TTL_MS)
    assert ok is False and held == "A"


@pytest.mark.asyncio
async def test_lease_expires_and_ttl_is_set():
    """租约靠续租存活:超过 TTL 未续 → 任何人可抢(标签页关闭即自动让位)。
    同时钉住 PEXPIRE 真的设上了(键本身也会到期,不留垃圾)。"""
    bus = _bus()
    await bus.active_room_acquire(UID, "A", "tabA", NOW, TTL_MS)
    assert 0 < await bus.r.pttl("alr:u7") <= TTL_MS
    ok, held = await bus.active_room_acquire(UID, "C", "tabZ", NOW + TTL_MS + 1, TTL_MS)
    assert (ok, held) == (True, "C")                      # 陈旧租约不挡路


@pytest.mark.asyncio
async def test_lease_release_is_conditional():
    """条件释放:房不符 → 完全 no-op;仍有别的活页 → 只摘本页、租约留任;
    最后一页离开 → 整把删除(关页后立刻换房零等待)。"""
    bus = _bus()
    await bus.active_room_acquire(UID, "A", "tabA", NOW, TTL_MS)
    await bus.active_room_acquire(UID, "A", "tabB", NOW, TTL_MS)      # 同房两页
    await bus.active_room_release(UID, "B", "tabA", NOW, TTL_MS)      # 房不对 → no-op
    assert await bus.r.hget("alr:u7", "room") == "A"
    await bus.active_room_release(UID, "A", "tabA", NOW, TTL_MS)      # 摘掉 tabA
    assert await bus.r.hget("alr:u7", "room") == "A"                  # tabB 还在看 → 留任
    assert await bus.r.hexists("alr:u7", "t:tabA") == 0
    await bus.active_room_release(UID, "A", "tabB", NOW, TTL_MS)      # 最后一页离开
    assert await bus.r.exists("alr:u7") == 0


@pytest.mark.asyncio
async def test_lease_prunes_stale_tabs():
    """陈旧标签页字段在扫描时顺手清除 —— 长期只看一个房也不会无界堆积 t:* 字段
    (随机 tab 的搬运器同样撑不大这把 hash)。"""
    bus = _bus()
    for i in range(5):
        await bus.active_room_acquire(UID, "A", f"tab{i}", NOW, TTL_MS)
    assert len(await bus.r.hkeys("alr:u7")) == 2 + 5                  # room+ts+5 页
    await bus.active_room_acquire(UID, "A", "fresh", NOW + TTL_MS + 1, TTL_MS)
    keys = await bus.r.hkeys("alr:u7")
    assert sorted(k for k in keys if k.startswith("t:")) == ["t:fresh"]


@pytest.mark.asyncio
async def test_lease_isolated_per_user():
    """租约按账号隔离:A 账号占住不影响 B 账号(每账号一把,不是全局锁)。"""
    bus = _bus()
    await bus.active_room_acquire(1, "A", "t1", NOW, TTL_MS)
    ok, held = await bus.active_room_acquire(2, "B", "t2", NOW, TTL_MS)
    assert (ok, held) == (True, "B")


# ══ 二、web 层三闸姿态 ════════════════════════════════════════════════════════
class _Req:
    """最小 Request 桩:只需 headers / query_params / state.user。"""
    def __init__(self, user=None, tab_hdr="", tab_q=""):
        self.headers = {"x-jf-tab": tab_hdr} if tab_hdr else {}
        self.query_params = {"tab": tab_q} if tab_q else {}
        self.state = type("S", (), {"user": user})()


class _User:
    def __init__(self, uid=UID):
        self.user_id = uid


def _enable_auth(monkeypatch, on=True):
    monkeypatch.setattr(web.userauth, "enabled", lambda: on)


def test_client_tab_reads_header_then_query():
    """标签页标识:fetch 走 X-JF-Tab 头;EventSource 带不了头 → 走 ?tab=。"""
    assert web._client_tab(_Req(tab_hdr="H1")) == "H1"
    assert web._client_tab(_Req(tab_q="Q1")) == "Q1"       # 头缺失 → 回退 query
    assert web._client_tab(_Req()) == ""                   # 都没有 → 空(从严)
    assert web._client_tab(None) == ""                     # 测试直调:不炸


@pytest.mark.asyncio
async def test_guards_noop_when_login_disabled(monkeypatch):
    """登录系统未启用 → 三闸恒放行(3.7.0 逐字节旧行为)。"""
    _enable_auth(monkeypatch, False)
    assert await web._active_room_guard(_Req(), "321") is None
    assert await web._detail_rate_guard(_Req()) is None


@pytest.mark.asyncio
async def test_guards_noop_without_principal(monkeypatch):
    """无登录身份(运维旁路 admin/X-Monitor-Token,或测试直调 request=None)
    → 放行,走全局旧语义。"""
    _enable_auth(monkeypatch, True)
    assert await web._active_room_guard(_Req(user=None), "321") is None
    assert await web._active_room_guard(None, "321") is None
    assert await web._detail_rate_guard(None) is None


@pytest.mark.asyncio
async def test_active_room_guard_allows_then_denies(monkeypatch):
    """端到端 last-wins:明细/SSE 走 renew —— 同账号异页在异房时回 409 **room_switched**
    (带应跟随的房号,前端据此自动切换,不是阻断);显式切房需先 claim 抢占,之后 renew 命中。"""
    _enable_auth(monkeypatch, True)
    bus = _bus()
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease", True, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease_ttl_s", 40.0, raising=False)
    u = _User()
    # tabA 在 321(renew 空租约 → 成为活跃房)
    assert await web._active_room_guard(_Req(u, tab_hdr="tabA"), "321") is None
    # tabB 想看 654(renew,异房)→ 409 room_switched + 应跟随的房 321(而非阻断)
    resp = await web._active_room_guard(_Req(u, tab_hdr="tabB"), "654")
    assert resp is not None and resp.status_code == 409
    assert b"room_switched" in resp.body
    import json as _json
    assert _json.loads(resp.body)["room"] == "321"      # 让 tabB 跟随到 321
    assert await bus.r.hget("alr:u7", "room") == "321"   # renew 不篡改租约
    # 显式切房:tabA claim 654(抢占)→ 之后 renew 654 命中放行
    await bus.active_room_acquire(u.user_id, "654", "tabA", NOW, TTL_MS, claim=True)
    assert await web._active_room_guard(_Req(u, tab_hdr="tabA"), "654") is None


@pytest.mark.asyncio
async def test_last_wins_claim_preempts_and_others_follow(monkeypatch):
    """last-wins 核心:显式 claim 抢占;其它窗口 renew 时收到「跟随目标」并收敛,**不抖动**。"""
    bus = _bus()
    # A 在 321,B 在 321(同房多视图,都放行)
    assert (await bus.active_room_acquire(UID, "321", "A", NOW, TTL_MS))[0] is True
    assert (await bus.active_room_acquire(UID, "321", "B", NOW, TTL_MS))[0] is True
    # C 显式 claim 654 → 抢占
    ok, held = await bus.active_room_acquire(UID, "654", "C", NOW + 1, TTL_MS, claim=True)
    assert (ok, held) == (True, "654")
    # A、B renew 321 → 发现被切走,返回跟随目标 654(租约不变)
    for tab in ("A", "B"):
        ok, held = await bus.active_room_acquire(UID, "321", tab, NOW + 2, TTL_MS)
        assert ok is False and held == "654"
    # A、B 跟随到 654 → 命中收敛;之后各续 10 轮,活跃房恒 654(无抖动)
    rooms = set()
    for _ in range(10):
        await bus.active_room_acquire(UID, "654", "A", NOW + 3, TTL_MS)
        await bus.active_room_acquire(UID, "654", "B", NOW + 3, TTL_MS)
        await bus.active_room_acquire(UID, "654", "C", NOW + 3, TTL_MS)
        rooms.add(await bus.r.hget("alr:u7", "room"))
    assert rooms == {"654"}, f"活跃房应恒 654(无抖动),得 {rooms}"


@pytest.mark.asyncio
async def test_claim_endpoint_preempts(monkeypatch):
    """POST /api/active-room/claim:显式切房抢占租约(其它窗口随后跟随)。fail-open。"""
    _enable_auth(monkeypatch, True)
    bus = _bus()
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease", True, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease_ttl_s", 40.0, raising=False)

    async def _canon(r):
        return str(r), True
    monkeypatch.setattr(web.ST, "star", types.SimpleNamespace(canon=_canon), raising=False)

    class _Req2:
        headers = {"x-jf-tab": "T1"}
        cookies = {}
        query_params = {}
        state = types.SimpleNamespace(user=_User())
        client = types.SimpleNamespace(host="1.1.1.1")

    # 先让别的 tab 占住 321
    await bus.active_room_acquire(UID, "321", "other", NOW, TTL_MS)
    # claim 654 → 抢占
    r = await web.active_room_claim_ep(_Req2(), roomId="654", tab="T1")
    body = json.loads(r.body)
    assert body["ok"] is True and body["room"] == "654"
    assert await bus.r.hget("alr:u7", "room") == "654"


@pytest.mark.asyncio
async def test_active_room_guard_off_switch(monkeypatch):
    """特性开关关闭 → 恒放行(出问题可一键退回旧行为)。"""
    _enable_auth(monkeypatch, True)
    bus = _bus()
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease", False, raising=False)
    u = _User()
    assert await web._active_room_guard(_Req(u, tab_hdr="tabA"), "321") is None
    assert await web._active_room_guard(_Req(u, tab_hdr="tabB"), "654") is None


@pytest.mark.asyncio
async def test_active_room_guard_fail_open_on_redis_error(monkeypatch):
    """Redis 抖动 → **放行**(读路径不因协调层故障误伤真人;与 is_cold 同哲学)。"""
    _enable_auth(monkeypatch, True)

    class _Boom:
        async def active_room_acquire(self, *a, **k):
            raise RuntimeError("redis down")

    monkeypatch.setattr(web.ST, "bus", _Boom(), raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease", True, raising=False)
    assert await web._active_room_guard(_Req(_User(), tab_hdr="tabA"), "321") is None


@pytest.mark.asyncio
async def test_detail_rate_guard_limits_then_fail_open(monkeypatch):
    """明细读限流:超配额 → 429 + Retry-After;限流器异常 → fail-open 放行。"""
    _enable_auth(monkeypatch, True)

    class _Bucket:
        def __init__(self, ok):
            self._ok = ok
        async def try_acquire_key(self, key, cost=1.0):
            assert key == f"rl:detail:u{UID}"          # 按账号分桶(不串桶)
            return (True, 0) if self._ok else (False, 2500)

    monkeypatch.setattr(web.ST, "detail_bucket", _Bucket(True), raising=False)
    assert await web._detail_rate_guard(_Req(_User())) is None

    monkeypatch.setattr(web.ST, "detail_bucket", _Bucket(False), raising=False)
    resp = await web._detail_rate_guard(_Req(_User()))
    assert resp is not None and resp.status_code == 429
    assert resp.headers.get("Retry-After") == "2"
    assert b"rate_limited" in resp.body

    class _BoomBucket:
        async def try_acquire_key(self, *a, **k):
            raise RuntimeError("redis down")

    monkeypatch.setattr(web.ST, "detail_bucket", _BoomBucket(), raising=False)
    assert await web._detail_rate_guard(_Req(_User())) is None    # fail-open


@pytest.mark.asyncio
async def test_detail_rate_guard_no_bucket(monkeypatch):
    """桶未就绪(lifespan 未跑,如单测直调)→ 放行,不炸。"""
    _enable_auth(monkeypatch, True)
    if hasattr(web.ST, "detail_bucket"):
        monkeypatch.delattr(web.ST, "detail_bucket", raising=False)
    assert await web._detail_rate_guard(_Req(_User())) is None


# ══ 3.9.3:主动释放端点(关页 sendBeacon)══════════════════════════════════════
@pytest.mark.asyncio
async def test_release_endpoint_frees_lease_and_is_idempotent(monkeypatch):
    """POST /api/active-room/release:关页时 sendBeacon 显式交还租约 —— 让另一窗口
    **零等待**换房(不必干等 40s TTL)。必须:①真的释放 ②幂等 ③不误删他人房。"""
    bus = _bus()
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.userauth, "enabled", lambda: True)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease", True, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease_ttl_s", 40.0,
                        raising=False)

    class _U:
        user_id = 7
        user_name = "alice"

    class _Req:
        headers = {"x-jf-tab": "T1"}
        cookies = {}
        query_params = {}
        state = types.SimpleNamespace(user=_U())
        client = types.SimpleNamespace(host="1.1.1.1")

    async def _canon(r):
        return str(r), True
    monkeypatch.setattr(web.ST, "star", types.SimpleNamespace(canon=_canon),
                        raising=False)

    now = int(time.time() * 1000)
    ok, _ = await bus.active_room_acquire(7, "321", "T1", now, 40000)
    assert ok
    assert (await bus.r.hgetall("alr:u7")).get("room") == "321"

    # ① 真的释放
    r = await web.active_room_release_ep(_Req(), roomId="321", tab="T1")
    assert json.loads(r.body)["ok"] is True
    assert await bus.r.hgetall("alr:u7") == {}, "release 后租约必须已清空"

    # ② 幂等:再调一次不炸
    r2 = await web.active_room_release_ep(_Req(), roomId="321", tab="T1")
    assert json.loads(r2.body)["ok"] is True

    # ③ 不误删他人房:持房 654 时 release 321 应 no-op
    await bus.active_room_acquire(7, "654", "T2", now, 40000)
    await web.active_room_release_ep(_Req(), roomId="321", tab="T2")
    assert (await bus.r.hgetall("alr:u7")).get("room") == "654", \
        "release 别的房号必须是 no-op,不得误删现有租约"


@pytest.mark.asyncio
async def test_release_endpoint_failsafe(monkeypatch):
    """release 是尽力而为的清理信标:Redis 抛错 / 无身份 / 特性关 一律回 ok,绝不抛。"""
    monkeypatch.setattr(web.userauth, "enabled", lambda: True)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease", True, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease_ttl_s", 40.0,
                        raising=False)

    class _Boom:
        async def active_room_release(self, *a, **k):
            raise RuntimeError("redis down")
    monkeypatch.setattr(web.ST, "bus", _Boom(), raising=False)

    async def _canon(r):
        return str(r), True
    monkeypatch.setattr(web.ST, "star", types.SimpleNamespace(canon=_canon),
                        raising=False)

    class _U:
        user_id = 7
        user_name = "alice"

    class _Req:
        headers = {"x-jf-tab": "T1"}
        cookies = {}
        query_params = {}
        state = types.SimpleNamespace(user=_U())
        client = types.SimpleNamespace(host="1.1.1.1")

    r = await web.active_room_release_ep(_Req(), roomId="321", tab="T1")
    assert json.loads(r.body)["ok"] is True     # Redis 挂了也回 ok

    # 无身份 → 直接 ok(不抛)
    class _Anon:
        headers = {}
        cookies = {}
        query_params = {}
        state = types.SimpleNamespace(user=None)
        client = types.SimpleNamespace(host="1.1.1.1")
    r2 = await web.active_room_release_ep(_Anon(), roomId="321", tab="")
    assert json.loads(r2.body)["ok"] is True


@pytest.mark.asyncio
async def test_claim_roster_gated_and_failopen(monkeypatch):
    """**回归钉子**(审计发现):claim 必须只抢占**本账号名录内**的房 —— 否则用户能把
    活跃房租约指向自己读不了的房,其它窗口 follow 过去后连续 403。被拒时**不报错**、
    只是不抢占(claim 全程 fail-open,绝不阻断切房)。名录判定异常(PG 挂)→ 仍抢占。"""
    _enable_auth(monkeypatch, True)
    bus = _bus()
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease", True, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease_ttl_s", 40.0,
                        raising=False)

    async def _canon(r):
        return str(r), True
    monkeypatch.setattr(web.ST, "star", types.SimpleNamespace(canon=_canon),
                        raising=False)

    class _Req2:
        headers = {"x-jf-tab": "T1"}
        cookies = {}
        query_params = {}
        state = types.SimpleNamespace(user=_User())
        client = types.SimpleNamespace(host="1.1.1.1")

    class _DB:
        async def user_room_allowed(self, uid, rid, room):
            return str(rid) in ("321", "654")
    monkeypatch.setattr(web.ST, "db", _DB(), raising=False)

    # 名录内 → 抢占
    r = await web.active_room_claim_ep(_Req2(), roomId="654", tab="T1")
    assert json.loads(r.body)["room"] == "654"
    assert await bus.r.hget("alr:u7", "room") == "654"
    # 名录外 → 不抢占、不报错,租约不被污染
    r2 = await web.active_room_claim_ep(_Req2(), roomId="999999", tab="T1")
    assert json.loads(r2.body)["ok"] is True
    assert await bus.r.hget("alr:u7", "room") == "654", "名录外的房绝不能污染租约"

    # PG 异常 → fail-open,仍抢占(协调层故障不阻断切房)
    class _Boom:
        async def user_room_allowed(self, *a, **k):
            raise RuntimeError("pg down")
    monkeypatch.setattr(web.ST, "db", _Boom(), raising=False)
    await web.active_room_claim_ep(_Req2(), roomId="321", tab="T1")
    assert await bus.r.hget("alr:u7", "room") == "321"


@pytest.mark.asyncio
async def test_deleting_current_room_needs_claim_to_repoint_lease(monkeypatch):
    """**回归钉子**(审计发现的真回归):删除**当前**房时租约仍指向已删房 —— 若回退首房
    只 renew,会被回 room_switched **指回已删房**,跟随加载必 403 → 页面卡死无实时。
    前端删房回退已改 explicit(claim);此测试钉住「claim 能把租约从已删房重新指向首房」。"""
    _enable_auth(monkeypatch, True)
    bus = _bus()
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease", True, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease_ttl_s", 40.0,
                        raising=False)

    async def _canon(r):
        return str(r), True
    monkeypatch.setattr(web.ST, "star", types.SimpleNamespace(canon=_canon),
                        raising=False)
    roster = {"321", "654"}

    class _DB:
        async def user_room_allowed(self, uid, rid, room):
            return str(rid) in roster
    monkeypatch.setattr(web.ST, "db", _DB(), raising=False)

    class _Req2:
        headers = {"x-jf-tab": "T1"}
        cookies = {}
        query_params = {}
        state = types.SimpleNamespace(user=_User())
        client = types.SimpleNamespace(host="1.1.1.1")

    # 页面在看 321(租约=321);用户删掉 321
    assert await web._active_room_guard(_Req2(), "321") is None
    roster.discard("321")
    # 只 renew 首房 654 → 被指回**已删房** 321(这正是卡死的起点)
    deny = await web._active_room_guard(_Req2(), "654")
    assert deny is not None and json.loads(deny.body)["room"] == "321"
    # claim 首房 654 → 租约重新指向 654,renew 随即放行(页面恢复)
    await web.active_room_claim_ep(_Req2(), roomId="654", tab="T1")
    assert await bus.r.hget("alr:u7", "room") == "654"
    assert await web._active_room_guard(_Req2(), "654") is None


@pytest.mark.asyncio
async def test_lease_all_paths_fail_open_when_redis_dead(monkeypatch):
    """**回归钉子**:Redis 完全不可达时,last-wins 的**全部**路径都必须 fail-open ——
    租约闸放行、claim/release 回 ok 不抛。协调层故障绝不能阻断真人读数据/切房。
    (last-wins 新增了 claim/release 两条路径,此测试把该性质在新链路上重新钉住。)"""
    class _Dead:
        async def active_room_acquire(self, *a, **k):
            raise RuntimeError("redis down")

        async def active_room_release(self, *a, **k):
            raise RuntimeError("redis down")
    _enable_auth(monkeypatch, True)
    monkeypatch.setattr(web.ST, "bus", _Dead(), raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease", True, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease_ttl_s", 40.0,
                        raising=False)

    async def _canon(r):
        return str(r), True
    monkeypatch.setattr(web.ST, "star", types.SimpleNamespace(canon=_canon),
                        raising=False)

    class _DB:
        async def user_room_allowed(self, *a, **k):
            return True
    monkeypatch.setattr(web.ST, "db", _DB(), raising=False)

    class _Req2:
        headers = {"x-jf-tab": "T1"}
        cookies = {}
        query_params = {}
        state = types.SimpleNamespace(user=_User())
        client = types.SimpleNamespace(host="1.1.1.1")

    assert await web._active_room_guard(_Req2(), "321") is None, "Redis 挂必须放行读"
    r = await web.active_room_claim_ep(_Req2(), roomId="321", tab="T1")
    assert json.loads(r.body)["ok"] is True, "claim 在 Redis 挂时必须回 ok 不抛"
    r2 = await web.active_room_release_ep(_Req2(), roomId="321", tab="T1")
    assert json.loads(r2.body)["ok"] is True, "release 在 Redis 挂时必须回 ok 不抛"
