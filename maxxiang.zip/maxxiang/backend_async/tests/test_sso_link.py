"""
test_sso_link.py — 账密签发通道(4.3.0,POST /api/auth/sso/link)
================================================================================
覆盖三层:
  ① 纯函数(零依赖恒跑):TTL 钳位、url 拼装只认配置、Bearer 常数时间比较、
     开关默认关且串联 sso_enabled;
  ② 静态纪律钉(零依赖恒跑,本通道的**命门**,复制实现/走样即当场变红):
     · 绝不 Set-Cookie —— 会话的唯一出生地仍是 _issue_session();
     · 口令校验必须走 _authenticate() —— 与 /api/auth/login 共用节流桶,
       这是「不额外放大口令爆破面」的根据;
     · 签发哈希必须用 _hash_token() —— 与消费侧同一个函数,契约不可能对不上;
     · 零 DDL 变更 —— 不新增列、不出现 ALTER TABLE guantai_sso_ticket;
     · 链接绝不从 Host / X-Forwarded-Host 推导;
     · 运维配套(文档/compose/.env 样例)在册。
  ③ 联测(本地 1:1 复刻用户库,不可达整层 skip;与 test_sso.py 同款夹具):
     全链路 签发 → 兑换 → 会话可用、单次有效、状态闸与登录同口径、
     **失败节流桶与 /api/auth/login 共用**(活体证明)、每账号签发限频、
     密钥闸、TTL 真实落库。
"""
from __future__ import annotations

import asyncio
import os
import re
import secrets
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import userauth  # noqa: E402
from app.settings import UserAuthCfg  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
SRC_PATH = Path(__file__).resolve().parents[1] / "app" / "userauth.py"
SRC = SRC_PATH.read_text(encoding="utf-8")
SSO_DOC = ROOT / "SSO-LOGIN.md"
LOGIN_DOC = ROOT / "LOGIN-SYSTEM.md"
COMPOSE = Path(__file__).resolve().parents[1] / "deploy" / "docker-compose.yml"

# 本通道的函数名单(4.3.0 新增)。静态钉只对这些函数的**可执行代码**取证 ——
# 经 AST 还原、剥掉文档字符串,注释天然不在其中。
#
# 为什么不做正则扫源码:项目自己在 test_register.py::test_tb_user_sql_discipline
# 里踩过这个坑并留了注脚 —— 「注释不会执行,把它算进写操作是**假阳性**」。
# 本文件的钉子说的都是「代码里不许出现 X」,而这些函数的注释里恰恰要**讨论** X
# (例如「绝不从 Host 头推导」),用正则扫就必然自伤。AST 是唯一正确的取证口径。
_LINK_FUNCS = ("sso_link_enabled", "sso_link_ttl_s", "sso_link_url", "sso_link_key_ok",
               "_sso_link_throttled", "_mint_sso_ticket", "sso_link", "auth_sso_link")


def _code_of(*names: str) -> str:
    """取指定函数的可执行代码文本(AST 还原,剥文档字符串,零注释)。"""
    import ast as _ast
    tree = _ast.parse(SRC)
    want, out = set(names), []
    for node in tree.body:
        if isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef)) and node.name in want:
            body = list(node.body)
            if (body and isinstance(body[0], _ast.Expr)
                    and isinstance(body[0].value, _ast.Constant)
                    and isinstance(body[0].value.value, str)):
                body = body[1:]              # 剥文档字符串
            node.body = body or [_ast.Pass()]
            out.append(_ast.unparse(node))
    missing = want - {n for n in want if any(f"def {n}(" in c for c in out)}
    assert not missing, f"源码里找不到本通道函数: {sorted(missing)}"
    return "\n".join(out)


_SECTION = _code_of(*_LINK_FUNCS)


# ══ ① 纯函数 ══════════════════════════════════════════════════════════════════
def _with_cfg(**kw):
    """临时装一份 cfg 给纯函数用(用完还原,绝不污染其它用例)。"""
    old = userauth.UA.cfg
    userauth.UA.cfg = UserAuthCfg(host="h", db="d", user="u", **kw)
    return old


def test_link_ttl_clamped():
    """TTL 钳在 [10,300]:调用方不能指定,配置也不能把票据养长。"""
    old = _with_cfg(sso_link_ttl_s=60)
    try:
        assert userauth.sso_link_ttl_s() == 60
        userauth.UA.cfg.sso_link_ttl_s = 5
        assert userauth.sso_link_ttl_s() == 10          # 下限
        userauth.UA.cfg.sso_link_ttl_s = 99999
        assert userauth.sso_link_ttl_s() == 300         # 硬顶
        userauth.UA.cfg.sso_link_ttl_s = 0              # 空/0 → 回默认再钳
        assert 10 <= userauth.sso_link_ttl_s() <= 300
    finally:
        userauth.UA.cfg = old


def test_link_url_only_from_config():
    """url 只由配置的 origin 拼;未配 → 空串(端点据此不回 url 字段)。
    片段形态必须是 `/#sso=` —— 与 4.1.0 逐字符一致,前端 ssoConsume() 零改动。"""
    old = _with_cfg(sso_link_base="https://guantai.example.com/")
    try:
        u = userauth.sso_link_url("a" * 64)
        assert u == "https://guantai.example.com/#sso=" + "a" * 64
        userauth.UA.cfg.sso_link_base = ""
        assert userauth.sso_link_url("a" * 64) == ""
        # 形态守卫:本项自 4.3.0 起后台可热改,乱填的值必须降级为「未配」而非产出废链接
        for bad in ("guantai.example.com", "ftp://x.com", "javascript:alert(1)",
                    "  ", "//x.com", "你的观测台域名"):
            userauth.UA.cfg.sso_link_base = bad
            assert userauth.sso_link_url("a" * 64) == "", f"非法 origin 未被拦:{bad!r}"
        userauth.UA.cfg.sso_link_base = "http://10.0.0.5:5173"      # 内网 http 合法
        assert userauth.sso_link_url("a" * 64).startswith("http://10.0.0.5:5173/#sso=")
    finally:
        userauth.UA.cfg = old


def test_link_key_gate():
    """未配密钥 → 恒放行;配了 → 只认 `Bearer <key>`(也接受裸 key),错一位即拒。"""
    old = _with_cfg(sso_link_key="")
    try:
        assert userauth.sso_link_key_ok("") is True
        assert userauth.sso_link_key_ok("Bearer 随便") is True
        userauth.UA.cfg.sso_link_key = "K" * 32
        assert userauth.sso_link_key_ok("Bearer " + "K" * 32) is True
        assert userauth.sso_link_key_ok("bearer " + "K" * 32) is True   # 大小写不敏感
        assert userauth.sso_link_key_ok("K" * 32) is True               # 裸 key 亦可
        assert userauth.sso_link_key_ok("Bearer " + "K" * 31 + "X") is False
        assert userauth.sso_link_key_ok("") is False
    finally:
        userauth.UA.cfg = old


def test_link_note_gbk_safe():
    """note 清洗:票据表是 CHARSET=gbk,emoji/假名等表示不了的字符必须被替换,
    否则 INSERT 抛 UnicodeEncodeError,被兜底 except 当成「用户库不可用」回 503 ——
    彻头彻尾的误导(库好好的,只是备注里有个表情)。实地复现过的缺陷,此处钉死。"""
    out = userauth.sso_link_note("续费🎉系统")
    assert out and "🎉" not in out
    out.encode("gbk")                              # 能编码进 gbk 才算安全
    assert userauth.sso_link_note(None) == ""
    assert len(userauth.sso_link_note("あ" * 200)) <= 50
    userauth.sso_link_note("あ" * 200).encode("gbk")
    assert userauth.sso_link_note("续费系统") == "续费系统"   # 正常中文不受损


def test_link_disabled_by_default_and_requires_sso():
    """不配置即不存在;且**串联** sso_enabled —— 签得出票却没有消费端点是误配。"""
    old = _with_cfg()
    try:
        assert userauth.UA.cfg.sso_link_enabled is False
        userauth.UA.cfg.sso_link_enabled = True
        userauth.UA.cfg.sso_enabled = False
        assert userauth.sso_link_enabled() is False      # 消费端没开 → 签发也不开
    finally:
        userauth.UA.cfg = old


# ══ ② 静态纪律钉 ══════════════════════════════════════════════════════════════
def test_link_never_issues_session():
    """**命门一**:签发端点绝不 Set-Cookie / 绝不建会话。
    会话的唯一出生地是 _issue_session(),由消费端点在用户真正到达时调用。"""
    for forbidden in ("set_session_cookie", "_issue_session"):
        assert forbidden not in _SECTION, \
            f"账密签发通道内出现 {forbidden} —— 签发不得产生会话"


def test_link_shares_authenticate_not_a_copy():
    """**命门二**:口令校验必须调 _authenticate(),不得自己再写一份。
    共用实现 ⇒ 共用失败节流桶 ⇒ 不额外放大口令爆破面。"""
    assert "await _authenticate(" in _SECTION, "sso_link 必须复用 _authenticate()"
    # 精确到「调用形式」而非裸名字 —— 本通道自有的 `await _sso_link_throttled(`
    # (每账号签发上限,与登录节流是两回事)不该被误伤。
    for copied in ("await _throttled(", "await _fail_bump(", "verify_password("):
        assert copied not in _SECTION, \
            f"账密签发通道内自行实现了 {copied} —— 必须走 _authenticate() 共用"


def test_link_hash_uses_same_function_as_consumer():
    """**命门三**:签发的 token_hash 必须用 _hash_token() —— 与消费侧
    sso_exchange 同一个函数。同一个函数调两次,跨端哈希契约物理上不可能对不上。"""
    mint = _code_of("_mint_sso_ticket")
    assert "_hash_token(ticket)" in mint, "签发必须用 _hash_token() 求摘要"
    assert "hashlib." not in mint, "签发不得另起炉灶算摘要"
    assert "SHA2(" not in mint.upper(), "不得用 SQL 的 SHA2():明文票据会进 binlog/慢日志"


def test_link_zero_ddl_change():
    """**命门四**:零 DDL 变更 —— 复用既有 note 列,不加列、不改表。
    (CREATE TABLE IF NOT EXISTS 对已存在的线上表不补列,加列必须另写幂等迁移。)"""
    assert len([s for s in userauth._SCHEMA if "guantai_sso_ticket" in s]) == 1
    assert not re.search(r"ALTER\s+TABLE\s+`?guantai_sso_ticket", SRC, re.I), \
        "不得对 guantai_sso_ticket 做 ALTER"
    assert "note" in _SECTION, "签发方标识应写入既有 note 列"


def test_link_url_never_from_request_headers():
    """**命门五**:链接绝不从 Host / X-Forwarded-Host 推导(调用方可控输入)。"""
    fn = _code_of("sso_link_url").lower()
    for header in ("host", "x-forwarded-host", "request", "header"):
        assert header not in fn, f"sso_link_url 不得触碰 {header}"
    assert "sso_link_base" in fn, "sso_link_url 必须且只从配置取 origin"


def test_link_ops_files_updated():
    """运维配套不许漏:接入文档、API 面清单、compose 环境变量、.env 样例。"""
    doc = SSO_DOC.read_text(encoding="utf-8")
    for kw in ("/api/auth/sso/link", "STA_USER_SSO_LINK", "STA_USER_SSO_LINK_BASE"):
        assert kw in doc, f"SSO-LOGIN.md 缺关键内容 {kw}"
    assert "/api/auth/sso/link" in LOGIN_DOC.read_text(encoding="utf-8"), \
        "LOGIN-SYSTEM.md §6 API 面应列出新端点"
    comp = COMPOSE.read_text(encoding="utf-8")
    for kw in ("STA_USER_SSO_LINK", "STA_USER_SSO_LINK_TTL_S",
               "STA_USER_SSO_LINK_BASE", "STA_USER_SSO_LINK_KEY"):
        assert kw in comp, f"docker-compose.yml 缺环境变量 {kw}"


_SSO_KEYS = ("sso_enabled", "sso_max_age_s", "sso_link_enabled",
             "sso_link_ttl_s", "sso_link_base", "sso_link_key")


def test_sso_family_registered_and_hot_editable():
    """SSO 全族六项必须在注册表登记,且**可在管理页热改**(4.3.0 起)。

    此前整族标 hot=RESTART/readonly=True,但那是标错的 —— 六个使用点全部是
    调用时读 UA.cfg(见 test_sso_family_hot_change_takes_effect 的活体证明)。
    本用例钉住修正后的契约:谁把它们改回 readonly,管理页就又改不了了。"""
    from app import config_registry as reg
    for k in _SSO_KEYS:
        f = reg.REGISTRY.get(f"userauth.{k}")
        assert f is not None, f"注册表缺 userauth.{k}"
        assert f.hot == reg.HOT, f"userauth.{k} 应为 HOT(使用点即时读取)"
        assert not f.readonly, f"userauth.{k} 应可在管理页覆盖"
        assert f.env, f"userauth.{k} 应声明对应 ENV"
    R = reg.REGISTRY
    # 两枚特性开关 + 安全钳 + 密钥:改错代价大,须键入参数名确认(同 reg_mode / auth.ticket)
    for k in ("sso_enabled", "sso_link_enabled", "sso_max_age_s", "sso_link_key"):
        assert R[f"userauth.{k}"].danger, f"userauth.{k} 应标 danger"
    assert R["userauth.sso_link_key"].sensitive, \
        "密钥必须标 sensitive(真值只经 Redis 分发,不落 PG 版本快照)"
    # 标签消歧:两个开关的 ENV 名不同(STA_USER_SSO vs STA_USER_SSO_LINK),
    # 说明文字必须各自点名,否则运营者会照着标签去设错变量(实地踩过)。
    assert "STA_USER_SSO_LINK" in R["userauth.sso_link_enabled"].desc
    assert "SSO签发" in R["userauth.sso_link_enabled"].label
    assert "消费" in R["userauth.sso_enabled"].label


# ══ ③ 联测(本地 1:1 复刻用户库;不可达整层 skip)════════════════════════════════
import hashlib as _hl  # noqa: E402
import socket as _sk  # noqa: E402

import pymysql  # noqa: E402
import pytest_asyncio  # noqa: E402

_HOST, _PORT = "127.0.0.1", int(os.environ.get("STA_TEST_USERDB_PORT", "3307"))


def _db_reachable() -> bool:
    try:
        with _sk.create_connection((_HOST, _PORT), timeout=0.6):
            return True
    except OSError:
        return False


needs_db = pytest.mark.skipif(not _db_reachable(),
                              reason=f"需要本地用户库 {_HOST}:{_PORT}(MariaDB 1:1 复刻)")


def _cfg(**kw) -> UserAuthCfg:
    base = dict(host=_HOST, port=_PORT, db="fanxing_changkong_user_db",
                user="fanxing_admin", password="fanxing_admin,.", charset="gbk",
                cache_ttl_s=0.0, sso_enabled=True, sso_link_enabled=True,
                login_fail_user=1000, login_fail_ip=1000)
    base.update(kw)
    return UserAuthCfg(**base)


@pytest_asyncio.fixture()
async def link_env():
    async def _setup(cfg: UserAuthCfg):
        await userauth.init(cfg, None)     # redis=None:限频走进程内兜底
        assert userauth.UA.schema_ok or await userauth._ensure_schema()
        userauth.UA.mem_sso = {}           # 每用例干净的限频兜底桶
        userauth.UA.mem_fail = {}
    yield _setup
    await userauth.close()
    userauth.UA.cfg = None
    userauth.UA.cache = {}
    userauth.UA.mem_sso = {}
    userauth.UA.mem_fail = {}
    userauth.UA.schema_ok = False


def _conn():
    return pymysql.connect(host=_HOST, port=_PORT, user="fanxing_admin",
                           password="fanxing_admin,.", charset="gbk",
                           database="fanxing_changkong_user_db", autocommit=True)


def _uid_of(name: str) -> int:
    with _conn() as c, c.cursor() as cur:
        cur.execute("SELECT id FROM tb_user WHERE user_name=%s", (name,))
        return int(cur.fetchone()[0])


def _ticket_row(ticket: str):
    th = _hl.sha256(ticket.encode()).hexdigest()
    with _conn() as c, c.cursor() as cur:
        cur.execute("SELECT user_id, used, note, "
                    "TIMESTAMPDIFF(SECOND, created_at, expires_at) ttl "
                    "FROM guantai_sso_ticket WHERE token_hash=%s", (th,))
        return cur.fetchone()


def _last_log_reason(uid: int) -> str:
    with _conn() as c, c.cursor() as cur:
        cur.execute("SELECT reason FROM guantai_login_log WHERE user_id=%s "
                    "ORDER BY id DESC LIMIT 1", (uid,))
        r = cur.fetchone()
        return r[0] if r else ""


@needs_db
async def test_link_full_flow_then_exchange(link_env):
    """快乐路径:账密 → 200(带 ticket/url/user)→ 票据真实落库(TTL/note 正确)
    → 交给消费端点 /api/auth/sso 兑换成功 → 会话可校验 → 同票重放 401(单次有效)。
    审计成功行 reason='sso_link',**且失败时不双写**(见下一用例)。"""
    await link_env(_cfg(sso_link_base="https://gt.example.com"))
    uid = _uid_of("测试用户A")

    st, body = await userauth.sso_link(
        {"userName": "测试用户A", "password": "pw123456", "note": "续费系统"},
        "", "10.9.0.1", "pytest")
    assert st == 200 and body["ok"] is True
    ticket = body["ticket"]
    assert re.fullmatch(r"[0-9a-f]{64}", ticket), "票据须为 64 位小写 hex"
    assert body["url"] == f"https://gt.example.com/#sso={ticket}"
    assert body["user"]["id"] == uid and body["user"]["userName"] == "测试用户A"
    assert body["expiresIn"] == 60
    assert "singleDevice" not in body and "token" not in body   # 签发不产会话

    row = _ticket_row(ticket)
    assert row is not None, "票据应已落库"
    assert row[0] == uid and int(row[1]) == 0 and row[2] == "续费系统"
    assert int(row[3]) == 60, "expires_at 应由观测台按 TTL 用库钟写死"
    assert _last_log_reason(uid) == "sso_link"

    # 交给既有消费端点 —— 与 4.1.0 的 INSERT 通道**完全同一条兑换路径**
    st2, body2, tok = await userauth.sso_exchange(ticket, False, "", "10.9.0.2", "pytest")
    assert st2 == 200 and tok, f"兑换应成功: {body2}"
    state, pr, _ = await userauth.validate(tok)
    assert state == "ok" and pr.user_id == uid

    st3, body3, tok3 = await userauth.sso_exchange(ticket, False, "", "10.9.0.3", "pytest")
    assert (st3, body3["error"], tok3) == (401, "bad_ticket", None), "单次有效"


@needs_db
async def test_link_shares_login_throttle_bucket(link_env):
    """★ 本通道的**安全地基**:失败节流桶与 /api/auth/login 共用。

    用 login() 打满「同用户名」失败计数(login_fail_user=3),随后从**另一个 IP**
    带**正确口令**调 sso_link → 必须 429。若谁把口令校验复制成第二份实现,
    计数就不再共用,此处当场变红。"""
    await link_env(_cfg(login_fail_user=3, login_fail_ip=100000))
    for i in range(3):
        st, _, _ = await userauth.login("plainuser", "wrong-pw", f"10.8.0.{i}", "t")
        assert st == 401
    st, body = await userauth.sso_link(
        {"userName": "plainuser", "password": "plain#pw"}, "", "10.8.9.9", "t")
    assert (st, body["error"]) == (429, "throttled"), \
        "签发端点必须共用登录的失败节流桶(否则等于凭空多给攻击者一份配额)"
    assert int(body.get("retryAfter") or 0) >= 1


@needs_db
async def test_link_failure_semantics_mirror_login(link_env):
    """失败语义与账密登录逐字节同口径:密码错 401 bad_credentials(不泄露用户
    存在性)、封停 403 banned、到期 403 banned/expired(按 VIP 体系开关)。
    且失败**不产生票据**。"""
    await link_env(_cfg())
    st, body = await userauth.sso_link(
        {"userName": "测试用户A", "password": "wrong"}, "", "10.7.0.1", "t")
    assert (st, body["error"]) == (401, "bad_credentials") and "ticket" not in body
    st, body = await userauth.sso_link(
        {"userName": "查无此人", "password": "whatever"}, "", "10.7.0.2", "t")
    assert (st, body["error"]) == (401, "bad_credentials")     # 同一词表,防枚举
    st, body = await userauth.sso_link(
        {"userName": "banneduser", "password": "pw123456"}, "", "10.7.0.3", "t")
    assert (st, body["error"]) == (403, "banned") and "ticket" not in body
    st, body = await userauth.sso_link(
        {"userName": "expireduser", "password": "pw123456"}, "", "10.7.0.4", "t")
    assert (st, body["error"]) == (403, "expired") and body.get("dueTime")
    st, body = await userauth.sso_link({"userName": "", "password": ""}, "", "10.7.0.5", "t")
    assert (st, body["error"]) == (400, "missing_fields")


@needs_db
async def test_link_key_gate_live(link_env):
    """密钥闸:配了 key 就必须带对;带错 → 401 bad_key,且**不消耗**口令节流配额
    (密钥闸在 _authenticate 之前),审计落 sso_link_bad。"""
    await link_env(_cfg(sso_link_key="S" * 40))
    st, body = await userauth.sso_link(
        {"userName": "测试用户A", "password": "pw123456"}, "Bearer wrong", "10.6.0.1", "t")
    assert (st, body["error"]) == (401, "bad_key")
    st, body = await userauth.sso_link(
        {"userName": "测试用户A", "password": "pw123456"},
        "Bearer " + "S" * 40, "10.6.0.2", "t")
    assert st == 200 and body["ticket"]


@needs_db
async def test_link_per_uid_mint_rate(link_env):
    """每账号签发限频:口令正确也不许无限往票据表灌行(第 11 发起 429)。"""
    await link_env(_cfg())
    ok = 0
    for _ in range(userauth._SSO_LINK_UID_PER_MIN):
        st, _b = await userauth.sso_link(
            {"userName": "sha1user", "password": "pw123456"}, "", "10.5.0.1", "t")
        ok += int(st == 200)
    assert ok == userauth._SSO_LINK_UID_PER_MIN
    st, body = await userauth.sso_link(
        {"userName": "sha1user", "password": "pw123456"}, "", "10.5.0.1", "t")
    assert (st, body["error"]) == (429, "throttled")


@needs_db
async def test_link_no_url_when_base_unset(link_env):
    """未配公网 origin → 只回 ticket,**不回 url**(拒绝从请求头推导域名)。"""
    await link_env(_cfg(sso_link_base=""))
    st, body = await userauth.sso_link(
        {"userName": "plainuser", "password": "plain#pw"}, "", "10.4.0.1", "t")
    assert st == 200 and body["ticket"] and "url" not in body


@needs_db
async def test_link_ttl_clamp_is_real(link_env):
    """TTL 硬顶落到真实 SQL:配 99999 秒也只写 300 秒(库钟计算,无钟差)。"""
    await link_env(_cfg(sso_link_ttl_s=99999))
    st, body = await userauth.sso_link(
        {"userName": "plainuser", "password": "plain#pw"}, "", "10.3.0.1", "t")
    assert st == 200 and body["expiresIn"] == 300
    assert int(_ticket_row(body["ticket"])[3]) == 300


# ══ ④ HTTP / ASGI 层(端点真实可达性、路由不冲突、头部语义)══════════════════════
import httpx  # noqa: E402
from fastapi import FastAPI  # noqa: E402


def _mini_app() -> FastAPI:
    a = FastAPI()
    a.include_router(userauth.router)
    return a


def _client(app: FastAPI) -> httpx.AsyncClient:
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=app),
                             base_url="http://testserver")


@needs_db
async def test_link_http_end_to_end_and_no_cookie(link_env):
    """★ 端到端走真实 ASGI:POST /api/auth/sso/link 拿票 → POST /api/auth/sso 兑换。

    同时钉死两件只有在 HTTP 层才看得见的事:
      · 签发响应**没有** Set-Cookie(静态钉管代码,本用例管实际报文);
      · 两条路由 /api/auth/sso 与 /api/auth/sso/link **不冲突**,且后者签的票
        能被前者原样消费 —— 证明本通道与 4.1.0 的 INSERT 通道同一条兑换路径。"""
    await link_env(_cfg(sso_link_base="https://gt.example.com"))
    app = _mini_app()
    async with _client(app) as c:
        r = await c.post("/api/auth/sso/link",
                         json={"userName": "plainuser", "password": "plain#pw"})
        assert r.status_code == 200, r.text
        assert "set-cookie" not in {k.lower() for k in r.headers}, \
            "签发端点绝不下发会话 Cookie"
        d = r.json()
        assert d["url"] == f"https://gt.example.com/#sso={d['ticket']}"
        r2 = await c.post("/api/auth/sso", json={"ticket": d["ticket"]})
        assert r2.status_code == 200, r2.text
        assert "set-cookie" in {k.lower() for k in r2.headers}, \
            "会话只在消费端点产生"


@needs_db
async def test_link_http_switch_gates_report_which_knob(link_env):
    """开关关闭时**分开报**:漏配 STA_USER_SSO → sso_disabled;
    漏配 STA_USER_SSO_LINK → sso_link_disabled。合并成一个码会让运营者
    一直去查 _LINK 而漏掉真正没开的那个总开关(排错误导)。"""
    await link_env(_cfg(sso_link_enabled=False))
    async with _client(_mini_app()) as c:
        r = await c.post("/api/auth/sso/link", json={"userName": "x", "password": "y"})
        assert (r.status_code, r.json()["error"]) == (503, "sso_link_disabled")
    userauth.UA.cfg.sso_link_enabled, userauth.UA.cfg.sso_enabled = True, False
    async with _client(_mini_app()) as c:
        r = await c.post("/api/auth/sso/link", json={"userName": "x", "password": "y"})
        assert (r.status_code, r.json()["error"]) == (503, "sso_disabled")


@needs_db
async def test_link_http_badkey_is_throttled(link_env):
    """★ 密钥错误必须有闸。实地复现过的缺陷:原本 40 发错误密钥全 401,
    **每发都往生产共享库 guantai_login_log 写一行**(日志放大 + 协程占用)。
    修复后:前 N 发 401,触限后 429 且**静默**(锁定期内不再写审计)。
    正常调用方永不发错密钥,故此闸对它零影响(只对失败计数)。"""
    await link_env(_cfg(sso_link_key="S" * 40))
    async with _client(_mini_app()) as c:
        codes = []
        for _ in range(userauth._SSO_LINK_BADKEY_10M + 5):
            r = await c.post("/api/auth/sso/link",
                             json={"userName": "plainuser", "password": "plain#pw"},
                             headers={"Authorization": "Bearer wrong"})
            codes.append(r.status_code)
        assert 429 in codes, "密钥错误必须触发限频,否则等于给攻击者一支写日志的笔"
        assert codes.count(401) <= userauth._SSO_LINK_BADKEY_10M
        assert codes[-1] == 429 and r.headers.get("retry-after")
    # 成功不计数:换一个干净 IP 语义(限频按 IP,此处同 IP 仍在锁中 → 换桶验证)
    userauth.UA.mem_sso = {}
    st, body = await userauth.sso_link(
        {"userName": "plainuser", "password": "plain#pw"},
        "Bearer " + "S" * 40, "10.2.0.1", "t")
    assert st == 200


@needs_db
async def test_link_http_emoji_note_does_not_500(link_env):
    """note 带 emoji 不得把签发打成 503。(gbk 库 + 未清洗 note 的实地缺陷回归钉。)"""
    await link_env(_cfg())
    async with _client(_mini_app()) as c:
        r = await c.post("/api/auth/sso/link",
                         json={"userName": "plainuser", "password": "plain#pw",
                               "note": "续费🎉系统"})
        assert r.status_code == 200, r.text
        assert r.json()["ticket"]


# ══ ⑤ 复审补齐:此前零覆盖的四条路径 ═══════════════════════════════════════════
#   这一组是第二轮实地复审时发现「探针跑过、测试没有」的路径。探针会随手删掉,
#   常驻用例才拦得住回归 —— 尤其 Redis 主通道:前面所有联测的 fixture 都传
#   redis=None(只跑进程内兜底),两个新闸的 Redis 分支此前**一行都没被执行过**。
@needs_db
async def test_link_throttles_redis_branch(link_env):
    """两个新限频闸的 **Redis 主通道**(与 test_sso.py::test_sso_throttle_redis_branch
    同款手法):fakeredis 上跑,并断言进程内兜底桶保持零污染 —— 证明确实走了 Redis
    而不是悄悄退化到 mem(退化了也能过的用例等于没测)。"""
    import fakeredis.aioredis as far
    r = far.FakeRedis(decode_responses=True)
    await link_env(_cfg(sso_link_key="S" * 40))
    userauth.UA.redis = r
    try:
        codes = []
        for _ in range(userauth._SSO_LINK_BADKEY_10M + 5):
            st, _b = await userauth.sso_link(
                {"userName": "plainuser", "password": "plain#pw"},
                "Bearer wrong", "10.21.0.1", "t")
            codes.append(st)
        assert codes.count(401) == userauth._SSO_LINK_BADKEY_10M and codes[-1] == 429
        assert userauth.UA.mem_sso == {}, "兜底桶被写 = 实际没走 Redis 分支"

        ok = 0
        for _ in range(userauth._SSO_LINK_UID_PER_MIN + 3):
            st, _b = await userauth.sso_link(
                {"userName": "sha1user", "password": "pw123456"},
                "Bearer " + "S" * 40, "10.21.0.2", "t")
            ok += int(st == 200)
        assert ok == userauth._SSO_LINK_UID_PER_MIN
        assert userauth.UA.mem_sso == {}
    finally:
        userauth.UA.redis = None


@needs_db
async def test_link_vip_free_tier_path(link_env):
    """VIP 体系开启时的 free 档:到期用户**不再**被签发闸挡住(200 + ddAlive=False),
    票据可正常兑换出 free 会话 —— 否则「刚在续费系统里的到期用户」永远看不到开通页,
    而那正是最该被引导的一批人(userauth.py:2755 的注释即为此)。
    VIP 关闭时必须**逐字节维持旧行为**:403 expired。"""
    await link_env(_cfg(jf_vip_enabled=True))
    st, body = await userauth.sso_link(
        {"userName": "expireduser", "password": "pw123456"}, "", "10.22.0.1", "t")
    assert st == 200 and body["user"]["ddAlive"] is False
    st2, _b2, tok = await userauth.sso_exchange(body["ticket"], False, "", "10.22.0.2", "t")
    assert st2 == 200 and tok, "free 档票据必须能兑换出会话(否则收银台无路可达)"

    userauth.UA.cfg.jf_vip_enabled = False
    st3, body3 = await userauth.sso_link(
        {"userName": "expireduser", "password": "pw123456"}, "", "10.22.0.3", "t")
    assert (st3, body3["error"]) == (403, "expired"), "VIP 关闭时必须维持旧行为"


@needs_db
async def test_link_respects_guantai_user_block(link_env):
    """观测台侧封禁表(guantai_user_block)与 tb_user.is_off **同一 banned 语义**。
    此前只测了 is_off,这条补上另一半 —— 两条封禁路径漏任何一条,
    被封用户都能从签发通道绕进来。"""
    await link_env(_cfg())
    uid = _uid_of("plainuser")
    with _conn() as c, c.cursor() as cur:
        cur.execute("INSERT IGNORE INTO guantai_user_block (user_id, reason, note, "
                    "created_at) VALUES (%s,'manual','pytest',NOW())", (uid,))
    try:
        st, body = await userauth.sso_link(
            {"userName": "plainuser", "password": "plain#pw"}, "", "10.23.0.1", "t")
        assert (st, body["error"]) == (403, "banned") and "ticket" not in body
    finally:
        with _conn() as c, c.cursor() as cur:
            cur.execute("DELETE FROM guantai_user_block WHERE user_id=%s", (uid,))


@needs_db
async def test_link_concurrent_mint_respects_cap(link_env):
    """并发下每账号签发上限不漏:30 并发恰好 10 成功,且票据两两不同。
    (mem 兜底的计数段无 await,asyncio 单线程下天然原子;Redis 分支走 INCR。
    这条钉住的是「以后有人往计数段中间插了个 await」这类改动。)"""
    await link_env(_cfg())
    res = await asyncio.gather(*[
        userauth.sso_link({"userName": "sha1user", "password": "pw123456"},
                          "", "10.24.0.1", "t")
        for _ in range(30)])
    oks = [b for st, b in res if st == 200]
    assert len(oks) == userauth._SSO_LINK_UID_PER_MIN, \
        f"并发下签发闸失守:放过了 {len(oks)} 发"
    tickets = [b["ticket"] for b in oks]
    assert len(set(tickets)) == len(tickets), "票据必须两两不同"


def test_sso_family_hot_change_takes_effect():
    """★ 活体证明「HOT」名副其实:原地 setattr 后,六个使用点**不重启**即刻看到新值。

    这条是把 4.3.0 复审的实地核查固化下来 —— 当时发现整族被标成 RESTART,
    而 web.py 传给 userauth.init() 的就是 settings.userauth **本身**
    (同一对象引用),config_center 的原地写入立即可见。谁哪天把某个读取点
    改成「启动时快照一份」,本用例当场变红。"""
    from app import config_registry as reg
    from app.settings import Settings
    st = Settings()
    st.userauth = UserAuthCfg(host="h", db="d", user="u", sso_enabled=True)
    old = userauth.UA.cfg
    userauth.UA.cfg = st.userauth          # 复刻 web.py 的接线:同一对象引用
    try:
        assert userauth.UA.cfg is st.userauth
        assert userauth.sso_link_enabled() is False
        reg.set_path(st, "userauth.sso_link_enabled", True)
        assert userauth.sso_link_enabled() is True, "sso_link_enabled 未即时生效"
        reg.set_path(st, "userauth.sso_link_ttl_s", 240)
        assert userauth.sso_link_ttl_s() == 240, "sso_link_ttl_s 未即时生效"
        reg.set_path(st, "userauth.sso_link_base", "https://x.example.com")
        assert userauth.sso_link_url("a" * 64).startswith("https://x.example.com/#sso=")
        reg.set_path(st, "userauth.sso_link_key", "K" * 32)
        assert userauth.sso_link_key_ok("Bearer " + "K" * 32) is True
        assert userauth.sso_link_key_ok("Bearer nope") is False
        reg.set_path(st, "userauth.sso_enabled", False)
        assert userauth.sso_link_enabled() is False, "总开关关闭应即刻串联生效"
    finally:
        userauth.UA.cfg = old


def test_link_ttl_guard_covers_both_paths():
    """★ 范围把关的**两条路径**行为不同,都要钉住(第七轮实地核查修正过一次错误认知)。

      · 管理页 → config_registry.coerce() 按 ge/le 校验 → 越界直接 ValueError;
      · .env   → settings._env_int() **只做整数转换,无范围校验** → 越界值会进
                 settings,唯一挡得住的是 sso_link_ttl_s() 内的 max/min 硬钳。

    所以守卫必须留在**使用点**,不能因为「coerce 已经校验过了」就把它删掉 ——
    删了之后 .env 里写 99999 就真的会签出 99999 秒的票据。"""
    from app import config_registry as reg
    fld = reg.REGISTRY["userauth.sso_link_ttl_s"]
    # 路径一:管理页 —— coerce 拒绝越界
    for bad in (99999, 301, 9, 0, -5):
        with pytest.raises(ValueError):
            reg.coerce(fld, bad)
    assert reg.coerce(fld, "120") == 120        # 合法值照收(含字符串形态)
    # 路径二:.env 绕过 coerce —— 只有使用点硬钳挡得住
    old = _with_cfg(sso_link_ttl_s=99999)       # 模拟 _env_int 写进来的越界值
    try:
        assert userauth.UA.cfg.sso_link_ttl_s == 99999      # settings 里确实是越界值
        assert userauth.sso_link_ttl_s() == 300             # 使用点兜住
    finally:
        userauth.UA.cfg = old


def test_link_base_guard_covers_both_paths():
    """同上:coerce 对 type="str" **不做形态校验**(实测传 123 会被转成 '123' 通过),
    所以 http/https 形态守卫必须留在 sso_link_url() 里。"""
    from app import config_registry as reg
    fld = reg.REGISTRY["userauth.sso_link_base"]
    assert reg.coerce(fld, 123) == "123", "coerce 不校验形态 —— 这正是使用点守卫的理由"
    assert reg.coerce(fld, "guantai.example.com") == "guantai.example.com"
    old = _with_cfg(sso_link_base="guantai.example.com")     # 缺协议,coerce 放行
    try:
        assert userauth.sso_link_url("a" * 64) == "", "使用点守卫必须拦住缺协议的 origin"
    finally:
        userauth.UA.cfg = old
