"""test_clock_domain.py — 跨时钟域调度的契约守卫(3.4.3)

用户症状:**「出怪倒计时结束、下一轮都开始了,才显示上一轮的出怪数据」**,且
数据一条不丢(`/coverage` 恒报 `complete: true`)、与房间数/算力无关。

根因(真机实证):
    `round_id` 是**游戏服务器**的毫秒时间戳(局起点),而延迟队列的到期判定
    (`redis_bus.claim_due` → `ZRANGEBYSCORE sched -inf now_ms()`)用的是
    **worker 本机钟**。出怪重试阶梯却写成:

        due = round_id + spell_off + anchor_ms     # ← 服务器钟域的值
        await bus.schedule(member, due)            # ← 当成本机钟域的 ZSET 分数

    两钟只要不同步,整条阶梯就整体偏移。而**首拍(备战+1.5s)必然落空**
    (实地核查:真实上游备战+2.2s 才就绪,连测 4 局 = +2.0/+2.4/+2.2/+2.1s),
    于是**每一局都会走到重试拍** —— 无一幸免,表现为**系统性**滞后:
        本机钟慢 N 秒  →  每局出怪晚 N 秒。

真机实测(本机钟故意调成落后上游 40s):
    修复前:出怪入库落在**局内 77.5s**(倒计时 40s 就结束、下一局 50s 就开跑)
    修复后:局内 **37.5s** ✅ —— 提前 40.0s,正好是钟偏,被完全吸收。

系统其实**早就测出了钟差**并存进快照(`serverOffsetMs = server_now - host_now`,
每局 MainPage 刷新),只是这两处没用上。
"""
from __future__ import annotations

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.constants import DRAW_OFFSET_MS, ROUND_STEP, SPELL_OFFSET_MS  # noqa: E402
from app.worker import (AWARD_LADDER_MS, CLOCK_SKEW_WARN_MS,           # noqa: E402
                        _snap_server_offset, _snap_spell_offset)


# ── 钟差读取:符号、缺失回退、脏值护栏 ────────────────────────────────────────
def test_snap_server_offset_semantics():
    """serverOffsetMs = 服务器钟 − 本机钟(见 _handle_mainpage: offset = server_now - noww)。"""
    assert _snap_server_offset({"serverOffsetMs": 40_000}) == 40_000    # 服务器快于本机
    assert _snap_server_offset({"serverOffsetMs": -7_500}) == -7_500    # 本机快于服务器
    # 缺失/脏值 → 0(= 假设同步,与旧行为一致,绝不放大故障)
    assert _snap_server_offset({}) == 0
    assert _snap_server_offset({"serverOffsetMs": ""}) == 0
    assert _snap_server_offset({"serverOffsetMs": "abc"}) == 0
    assert _snap_server_offset(None) == 0                               # type: ignore[arg-type]
    # 护栏:荒谬的钟差(>10 分钟)按 0,靠告警暴露,不据此把任务排到天荒地老
    assert _snap_server_offset({"serverOffsetMs": 3_600_000}) == 0


# ── 核心契约:重试拍点必须落在【本机钟域】────────────────────────────────────
def _retry_due_host(round_id: int, attempt: int, snap: dict) -> int:
    """复刻 worker._handle_award 重试分支的到期计算(不含随机抖动)。"""
    spell_off = _snap_spell_offset(snap)
    srv_off = _snap_server_offset(snap)
    anchor = AWARD_LADDER_MS[min(attempt, len(AWARD_LADDER_MS)) - 1]
    return round_id + spell_off + anchor - srv_off


@pytest.mark.parametrize("skew_ms", [0, 40_000, -40_000, 3_000, -3_000])
def test_retry_due_lands_at_correct_in_round_phase_under_any_skew(skew_ms):
    """无论本机钟偏多少,重试拍在【服务器钟】上都必须落在同一个局内相位。

    这正是修复的本质:到期时刻存的是**本机钟**分数(claim_due 拿 now_ms() 比),
    所以必须把服务器钟域的目标时刻减去钟差。
    """
    round_id = 1_783_800_000_000 - (1_783_800_000_000 % ROUND_STEP)
    snap = {"serverOffsetMs": skew_ms,
            "roundStartTimeMs": round_id,
            "spellTimeMs": round_id + SPELL_OFFSET_MS}

    for attempt in range(1, len(AWARD_LADDER_MS) + 1):
        due_host = _retry_due_host(round_id, attempt, snap)
        # 本机钟到达 due_host 的那一刻,服务器钟是 due_host + skew
        due_server = due_host + skew_ms
        phase_s = (due_server - round_id) / 1000.0
        expect_s = (SPELL_OFFSET_MS + AWARD_LADDER_MS[attempt - 1]) / 1000.0
        assert abs(phase_s - expect_s) < 0.001, (
            f"钟偏 {skew_ms}ms 下第 {attempt} 拍落在局内 {phase_s:.1f}s,"
            f"应为 {expect_s:.1f}s —— 跨钟域换算错了,出怪会系统性晚 {skew_ms/1000:.0f}s")


def test_first_retry_beats_the_countdown_even_with_skew():
    """第 1 个重试拍必须赶在**倒计时结束(drawTime = 局内 40s)之前**落地 ——
    否则用户就会看到「倒计时都结束了才显示出怪」。

    首拍(备战+1.5s = 局内 36.5s)**必然落空**(上游备战+2.2s 才就绪),
    所以真正决定「用户能否在倒计时内看到出怪」的是**第 1 个重试拍**。
    """
    round_id = 1_783_800_000_000 - (1_783_800_000_000 % ROUND_STEP)
    for skew in (0, 40_000, -40_000):
        snap = {"serverOffsetMs": skew,
                "roundStartTimeMs": round_id,
                "spellTimeMs": round_id + SPELL_OFFSET_MS}
        due_server = _retry_due_host(round_id, 1, snap) + skew
        phase_ms = due_server - round_id
        assert phase_ms < DRAW_OFFSET_MS, (
            f"钟偏 {skew}ms:第 1 个重试拍落在局内 {phase_ms/1000:.1f}s,"
            f"晚于倒计时结束({DRAW_OFFSET_MS/1000:.0f}s)")
        assert phase_ms < ROUND_STEP, "拍点绝不能落到下一局"


def test_final_probe_due_also_clock_corrected():
    """终拍(备战+43s)同样是服务器钟域的值,必须一并换算。"""
    round_id = 1_783_800_000_000 - (1_783_800_000_000 % ROUND_STEP)
    skew = 40_000
    snap = {"serverOffsetMs": skew, "roundStartTimeMs": round_id,
            "spellTimeMs": round_id + SPELL_OFFSET_MS}
    spell_off = _snap_spell_offset(snap)
    srv_off = _snap_server_offset(snap)
    due_host = round_id + spell_off + 43_000 - srv_off
    phase_s = (due_host + skew - round_id) / 1000.0
    assert abs(phase_s - (SPELL_OFFSET_MS + 43_000) / 1000.0) < 0.001


def test_zero_skew_is_byte_identical_to_old_behavior():
    """钟同步时(绝大多数部署),换算后的拍点必须与旧实现**逐字节一致** ——
    这条保证修复对健康部署零影响。"""
    round_id = 1_783_800_000_000 - (1_783_800_000_000 % ROUND_STEP)
    snap = {"serverOffsetMs": 0, "roundStartTimeMs": round_id,
            "spellTimeMs": round_id + SPELL_OFFSET_MS}
    for attempt in range(1, len(AWARD_LADDER_MS) + 1):
        old = round_id + _snap_spell_offset(snap) + AWARD_LADDER_MS[attempt - 1]
        assert _retry_due_host(round_id, attempt, snap) == old


def test_clock_skew_warn_threshold_is_sane():
    """钟偏告警阈值要足够小,才能在钟偏害人之前喊出来;又不能小到被网络抖动误触。"""
    assert 1_000 <= CLOCK_SKEW_WARN_MS <= 10_000
