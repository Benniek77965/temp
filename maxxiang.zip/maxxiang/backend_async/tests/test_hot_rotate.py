"""契约(观感档 hot_rotate):桥接层黑盒验证四条铁律
================================================================================
  ① 结构:main/guard 恒各 2、互斥、∈1..9;why 恒非空且以 续值/轮值 开头;
  ② 退位不离场:每局融合概率第一的"支配号"(ens argmax)必在 main∪guard —
     让位只换主/防座次,绝不把支配号挤出四强;
  ③ 总开关:rotate_q=0 时全程零"轮值"(即使 rotate_cap 调小逼近放宽路径),
     支配号恒在 main —— 纯命中形态;
  ④ 幂等:同序列重放 predict(fp 守卫),main/guard/why 逐字节一致。

合成序列由固定 LCG 按真实房分布(1≈21%,7/2/8≈16~17%,冷门≈29%)生成,
无外部随机源,逐次运行完全可复现。
"""

import pytest

# ── 4.8.0 交付守卫 ──────────────────────────────────────────────────────────
# 实证：本仓库随附的引擎 PredictionConfig **没有** rotate_value_beta / rotate_q，
# 且 predict() 对未知 explore_style 是**静默兜底**——
#   PredictorBridge({"explore_style":"hot_rotate"})、{"explore_style":"ceiling_adaptive"}
#   与任意乱写串，三者四码输出逐字节相同。
# 也就是说：不加这道 skip，本文件会**全绿通过，但测的是通用兜底分支**，
# 恰好就是它自己声称要守的那类"静默失真"。宁可显式 skip，也不要假绿。
import os as _os
import sys as _sys

_ENGINE = _os.path.join(_os.path.dirname(_os.path.dirname(
    _os.path.dirname(_os.path.abspath(__file__)))), "jiufa_data")
if _ENGINE not in _sys.path:
    _sys.path.insert(0, _ENGINE)
try:
    import spell_tamer_monitor as _E
    _MISSING = [k for k in ("rotate_value_beta", "rotate_q")
                if k not in _E.PredictionConfig.__dataclass_fields__]
except Exception as _e:                                   # pragma: no cover
    _MISSING = [f"引擎导入失败:{_e!r}"]

_SKIP_NO_FEATURE = pytest.mark.skipif(
    bool(_MISSING),
    reason=("引擎不含 hot_rotate 观感档字段 %s；explore_style 对未知取值静默兜底，"
            "继续跑只会测到通用分支（本包实测直接 5 红）。"
            "多样性诉求请测 test_frontier.py" % _MISSING))

import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

_ENGINE = os.environ.get("STA_ENGINE_DIR") or str(
    Path(__file__).resolve().parents[2] / "jiufa_data")
pytestmark = [
    pytest.mark.skipif(
        not (Path(_ENGINE) / "spell_tamer_monitor.py").exists(),
        reason="旧预测引擎不可用(STA_ENGINE_DIR 未设或默认路径无 spell_tamer_monitor.py)"),
    _SKIP_NO_FEATURE,          # ← 4.8.0：特性缺失时整体跳过，见文件顶部守卫
]

_CDF = ((1, .213), (7, .386), (2, .552), (8, .713),
        (5, .803), (6, .884), (4, .941), (3, .978), (9, 1.0))
_MULT = (10, 50, 330, 250, 100, 100, 50, 50, 500)   # 与引擎默认倍率表一致
_BETA = 0.45                                        # 与引擎默认 β 一致
_GAMMA = 0.35                                       # 与引擎默认 γ 一致


def _seq(n: int = 420, seed: int = 9):
    x, out = seed, []
    for _ in range(n):
        x = (1103515245 * x + 12345) % (2 ** 31)
        u = x / 2 ** 31
        out.append(next(c for c, p in _CDF if u < p))
    return out


def _replay(cfg_over: dict, seq):
    from app.predictor_bridge import PredictorBridge
    b = PredictorBridge({"explore_style": "hot_rotate", **cfg_over}, {})
    kv, rows = {}, []
    for i in range(30, len(seq)):
        r, d = b.run_prediction("t", seq[:i], kv)
        kv.update(d)
        rows.append(r)
        d2 = b.update_after_settle("t", {"models": r["models"]}, seq[i], kv)
        kv.update(d2)
    return rows


def _score(r, beta, gamma=_GAMMA):  # 席位分数,与引擎逐式一致
    ens = r["ens"]
    fmax = max(ens) or 1e-9
    vmax = max((_MULT[j] ** (1 - gamma)) * ens[j] for j in range(9)) or 1e-9
    return [(1 - beta) * ens[j] / fmax
            + beta * (_MULT[j] ** (1 - gamma)) * ens[j] / vmax
            for j in range(9)]


def _top4(r, beta=_BETA):
    sc = _score(r, beta)
    return {1 + j for j in sorted(range(9), key=lambda j: -sc[j])[:4]}


def _dom(r, beta=_BETA):           # 支配号 = 席位分数第一
    sc = _score(r, beta)
    return 1 + max(range(9), key=lambda j: sc[j])


def test_shape_why_and_dom_never_leaves_four():
    rows = _replay({}, _seq())
    for r in rows:
        m, g = r["main"], r["guard"]
        assert len(m) == 2 and len(g) == 2 and not set(m) & set(g)
        assert all(1 <= c <= 9 for c in m + g)
        why = (r.get("explore") or {}).get("why", "")
        assert why and (why.startswith("续值") or why.startswith("轮值"))
        assert _dom(r) in m + g, "退位不离场被破坏:支配号被挤出四强"
    late = rows[80:]                # 60 局自校准热身后
    assert any((r.get("explore") or {}).get("why", "").startswith("轮值")
               for r in late), "默认档长序列上从未轮值 —— 观感档成了摆设"


def test_master_switch_rotate_q_zero_means_never():
    rows = _replay({"rotate_q": 0.0, "rotate_cap": 3}, _seq())
    for r in rows:
        why = (r.get("explore") or {}).get("why", "")
        assert not why.startswith("轮值"), \
            "rotate_q=0 仍发生轮值(连坐放宽路径未被总开关关死)"
        assert _dom(r) in r["main"], "总开关关闭下支配号必须恒在主位"


def test_cold_display_guard2_only_with_cadence():
    """契约⑤(机制精确·β版):主位恒 ⊆ 当期**席位分数** top4(分数=(1-β)·概率
    +β·EV);防2展示=把分数 5~9 位的号请进 four[3],按节拍受控出现。"""
    rows = _replay({}, _seq())
    for r in rows:
        assert set(r["main"]) <= _top4(r), "主位含当期top4之外的号(结构违约)"
    stable = rows[100:]

    def _note(r):
        why = (r.get("explore") or {}).get("why", "")
        return why.split("·防区展示冷门", 1)[1] if "·防区展示冷门" in why else ""

    # 默认档=天花板档(every=1·prob):展示事件应近乎每局(允许极少数无冷可展)
    with_cold = [r for r in stable if _note(r)]
    share = len(with_cold) / len(stable)
    assert 0.80 <= share <= 1.0, f"天花板默认档展示占比异常: {share:.2%}"
    assert any("、" in _note(r) for r in stable), "双席默认下从未出现双冷"
    for r in stable:                        # 主位铁律逐行复核
        assert set(r["main"]) <= _top4(r), "主位混入分数top4之外"


def test_cold_off_pure_hot_four():
    """契约⑥(机制精确·β版):rotate_cold_every=0 → 四强逐局精确等于当期
    席位分数 top4(零换席)。"""
    rows = _replay({"rotate_cold_every": 0}, _seq())
    for r in rows:
        assert set(r["main"] + r["guard"]) == _top4(r),             "关闭展示后四强 ≠ 当期概率top4"


def test_beta_zero_degenerates_to_pure_probability():
    """契约⑦:β=0 → 分数恒等概率,主位 ⊆ 概率top4、支配号=概率第一。"""
    rows = _replay({"rotate_value_beta": 0.0}, _seq())
    for r in rows:
        assert set(r["main"]) <= _top4(r, 0.0)
        assert _dom(r, 0.0) in r["main"] + r["guard"]


def test_bad_multipliers_degrade_and_gamma_one_purifies():
    """契约⑧:倍率串坏格式 → β 安全降级(席位=纯概率序);γ=1 → 分数逐比特
    退化为纯概率(β 失效)。两种情形主位均 ⊆ 概率 top4。"""
    for over in ({"rotate_value_multipliers": "not,valid"},
                 {"rotate_value_gamma": 1.0}):
        rows = _replay(over, _seq())
        for r in rows:
            assert set(r["main"]) <= _top4(r, 0.0), over


def test_cold_slots_one_caps_single_swap():
    """契约⑨:rotate_cold_slots=1 → 任何一局防区最多一席为分数5~9位。"""
    rows = _replay({"rotate_cold_slots": 1}, _seq())
    for r in rows[100:]:
        sc = _score(r, _BETA)
        rk = lambda c: 1 + sorted(range(9), key=lambda j: -sc[j]).index(c - 1)
        assert sum(1 for c in r["guard"] if rk(c) >= 5) <= 1, "单席配置出现双冷"


def test_idempotent_same_fingerprint_including_why():
    from app.predictor_bridge import PredictorBridge
    b = PredictorBridge({"explore_style": "hot_rotate"}, {})
    seq, kv = _seq(200), {}
    r1, d = b.run_prediction("t2", seq, kv)
    kv.update(d)
    r2, _ = b.run_prediction("t2", seq, kv)
    k = lambda r: (r["main"], r["guard"], (r.get("explore") or {}).get("why"))  # noqa: E731
    assert k(r1) == k(r2), "同指纹重放不幂等(fp 守卫失效)"


def _cold_note(r):
    """从 why 提取防区展示段(引擎权威自陈),返回该段文本('' 表示本局未展示)。"""
    why = (r.get("explore") or {}).get("why", "")
    marker = "·防区展示冷门"
    return why.split(marker, 1)[1] if marker in why else ""


def test_ceiling_pick_prob_every_round_and_double():
    """契约⑩(天花板档 prob·1/2 的定义性承诺,锚定引擎 why 自陈):
    ①每局都有展示事件(every=1);②长序列上出现双席(同帧双冷);
    ③展示进防区的每个号都必是当期席位分数 5~9 位(不污染四强价值序);
    ④展示号确实落在 guard 席内(why 与结构一致,非空口标注)。"""
    rows = _replay({"rotate_cold_every": 1, "rotate_cold_slots": 2,
                    "rotate_cold_pick": "prob"}, _seq())
    stable = rows[100:]
    shown = [r for r in stable if _cold_note(r)]
    assert len(shown) >= int(0.9 * len(stable)), \
        f"天花板档 every=1 却非每局展示: {len(shown)}/{len(stable)}"
    doubles = [r for r in stable if "、" in _cold_note(r)]
    assert doubles, "天花板档 slots=2 长序列上从未出现双席"
    for r in stable:
        sc = _score(r, _BETA)
        rk = lambda c: 1 + sorted(range(9), key=lambda j: -sc[j]).index(c - 1)
        note = _cold_note(r)
        for c in r["guard"]:
            # guard 里被 why 点名为"展示冷门"的号 → 必是分数 5~9 位
            if f"{c}号(z" in note:
                assert rk(c) >= 5, f"{c}号被当冷门展示却在分数top4"
