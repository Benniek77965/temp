# -*- coding: utf-8 -*-
"""4.9.3 第七轮复查的落地测试:唤醒秒级快道 / 失败短退避 / 结构性缺口短路 /
孤儿补结算 / accuracy 实盘分列 / 唤醒路径接线。

背景(生命周期仿真实证,详见 README §10.1 第七轮):config_registry 自 4.6.0
起承诺「转正/唤醒会当场清掉该房的冷却」,但唤醒路径(web._touch_room)从未
兑现 —— 周期访问的房每次打开推演卡都恒见同一个缺口值(访问间隔 60/68/77
分钟 ⇒ 恒见 65/55/44,连续十几次分毫不变),正是「一直显示近44局」工单。
本文件钉死修复后的每一环,并以源码扫描钉住 web 侧接线不被顺手回退。
"""
import asyncio
import re
import sys
from pathlib import Path

import pytest

_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "backend_async"))

from app.constants import ROUND_STEP                      # noqa: E402
from app.worker import REPLAY_FAIL_BACKOFF_S              # noqa: E402

# 复用补算主测试的 harness(_FakeDB/_SpyBridge/_mk_worker/_mk_rounds):
# 它们就是为 worker 编排层测试而设,签名被那边的钉子看守,这里不再复制一份。
from tests.test_pred_replay import (_FakeDB, _mk_rounds,  # noqa: E402
                                    _mk_worker)


class _AnchorDB(_FakeDB):
    """给 _FakeDB 补上快道轻探需要的 anchor 语义(默认 anchor=0 = 尚无数据)。"""

    def __init__(self, gaps, rounds, stale=None, anchors=None):
        super().__init__(gaps, rounds, stale)
        self.anchors = anchors or {}

    async def replay_gaps(self, room, window, cfg_fp=""):
        g = await super().replay_gaps(room, window, cfg_fp)
        g["anchor"] = int(self.anchors.get(room, 0))
        return g


class _BoomDB(_AnchorDB):
    """指定房间的 replay_gaps 恒抛错 —— 触发失败退避路径。"""

    def __init__(self, *a, boom=(), **kw):
        super().__init__(*a, **kw)
        self.boom = set(boom)

    async def replay_gaps(self, room, window, cfg_fp=""):
        if room in self.boom:
            raise RuntimeError("pg 抖动")
        return await super().replay_gaps(room, window, cfg_fp)


async def _gate_ttl(w, room):
    return await w.bus.r.ttl(f"predreplay:gate:{room}")


# ═════════════ A. 唤醒快道:bus 原语与 worker 排水 ═══════════════════════════
@pytest.mark.asyncio
async def test_wake_push_pop_roundtrip_and_dedup():
    """SADD 幂等去重;SPOP count 原子取走;空集回 []。"""
    w = await _mk_worker(["1"], gaps={}, rounds={})
    await w.bus.replay_wake_push("321")
    await w.bus.replay_wake_push("321")          # 去重
    await w.bus.replay_wake_push("654")
    got = set(await w.bus.replay_wake_pop(8))
    assert got == {"321", "654"}
    assert await w.bus.replay_wake_pop(8) == []
    await w.bus.r.aclose()


@pytest.mark.asyncio
async def test_drain_no_anchor_costs_no_gate():
    """刚 add 的房数据未播种(anchor=0):轻探直接放行且**不消耗冷却闸** ——
    否则闸被空耗,真数据到位后反要再等一个冷却周期(add 路径的既有坑)。"""
    rooms = ["701"]
    w = await _mk_worker(rooms, gaps={"701": [1]}, rounds={"701": []})
    w.db = _AnchorDB({"701": [1]}, {"701": []}, anchors={})   # anchor 缺省 0
    await w.bus.replay_wake_push("701")
    await w._replay_wake_drain(w.s.prediction)
    assert await _gate_ttl(w, "701") < 0, "无数据的房不该被落闸"
    assert w.bridge.seqs == [], "无数据的房不该跑引擎"
    await w.bus.r.aclose()


@pytest.mark.asyncio
async def test_drain_full_window_sets_gate_without_engine():
    """窗口已满:落闸即入稳态(与巡检零缺口短路同效),不跑引擎。"""
    rs = {"702": _mk_rounds(40)}
    w = await _mk_worker(["702"], gaps={"702": []}, rounds=rs)
    w.db = _AnchorDB({"702": []}, rs, anchors={"702": rs["702"][-1]["round_id"]})
    await w.bus.replay_wake_push("702")
    await w._replay_wake_drain(w.s.prediction)
    assert await _gate_ttl(w, "702") > 0, "满窗的房应落闸进入稳态"
    assert w.bridge.seqs == []
    await w.bus.r.aclose()


@pytest.mark.asyncio
async def test_drain_fills_gaps_immediately():
    """有缺口的唤醒房:一次排水即补齐(这就是「打开 ~1-2s 补满」的机制本体)。"""
    rs = {"703": _mk_rounds(40)}
    gaps = {"703": [r["round_id"] for r in rs["703"][-3:]]}
    w = await _mk_worker(["703"], gaps=gaps, rounds=rs)
    w.db = _AnchorDB(gaps, rs, anchors={"703": rs["703"][-1]["round_id"]})
    await w.bus.replay_wake_push("703")
    await w._replay_wake_drain(w.s.prediction)
    assert "703" in w.db.saved and len(w.db.saved["703"]) == 3
    assert await _gate_ttl(w, "703") > REPLAY_FAIL_BACKOFF_S, "成功补算应落整段冷却闸"
    await w.bus.r.aclose()


@pytest.mark.asyncio
async def test_drain_skips_dormant_room():
    """冷房/发现房不走快道(判据与巡检 _dormant 同源 —— 没有实时消费者)。"""
    rs = {"704": _mk_rounds(40)}
    gaps = {"704": [rs["704"][-1]["round_id"]]}
    w = await _mk_worker(["704"], gaps=gaps, rounds=rs)
    w.s.histmode.enabled = True                 # _dormant 的 cold 支路是双开关门
    w.s.histmode.curated_idle_enabled = True    # (生产 config.yaml 即双开)
    await w.bus.mark_cold_bulk(["704"], 0)      # 打冷标(harness 的 cold= 参数
    #                                              走的是不存在的 bus.cold_mark,
    #                                              见 test_pred_replay 附注)
    w.db = _AnchorDB(gaps, rs, anchors={"704": rs["704"][-1]["round_id"]})
    await w.bus.replay_wake_push("704")
    await w._replay_wake_drain(w.s.prediction)
    assert "704" not in w.db.saved and w.bridge.seqs == []
    await w.bus.r.aclose()


@pytest.mark.asyncio
async def test_drain_exception_sets_short_backoff():
    """快道异常:落短退避闸(REPLAY_FAIL_BACKOFF_S),不是整段冷却。"""
    rs = {"705": _mk_rounds(40)}
    gaps = {"705": [rs["705"][-1]["round_id"]]}
    w = await _mk_worker(["705"], gaps=gaps, rounds=rs)
    w.db = _BoomDB(gaps, rs, anchors={"705": rs["705"][-1]["round_id"]},
                   boom={"705"})
    await w.bus.replay_wake_push("705")
    await w._replay_wake_drain(w.s.prediction)
    ttl = await _gate_ttl(w, "705")
    assert 0 < ttl <= REPLAY_FAIL_BACKOFF_S, f"异常应落短退避,实得 ttl={ttl}"
    await w.bus.r.aclose()


# ═════════════ B. 巡检:异常短退避(不再吞整段冷却) ═══════════════════════════
@pytest.mark.asyncio
async def test_sweep_exception_backoff_not_full_cooldown():
    rs = {"801": _mk_rounds(40)}
    gaps = {"801": [rs["801"][-1]["round_id"]]}
    w = await _mk_worker(["801"], gaps=gaps, rounds=rs)
    w.db = _BoomDB(gaps, rs, anchors={"801": rs["801"][-1]["round_id"]},
                   boom={"801"})
    await w._replay_sweep(w.s.prediction)
    ttl = await _gate_ttl(w, "801")
    cooldown = int(w.s.prediction.get("replay_cooldown_s", 3600))
    assert 0 < ttl <= REPLAY_FAIL_BACKOFF_S < cooldown, \
        f"巡检异常应短退避({REPLAY_FAIL_BACKOFF_S}s),实得 {ttl}"
    await w.bus.r.aclose()


# ═════════════ C. 结构性缺口短路(洞后局 / 热身不足) ═══════════════════════════
@pytest.mark.asyncio
async def test_all_unfillable_skips_engine():
    """窗口内只剩「洞后一局」这种结构性不可补缺口 ⇒ 不跑引擎(旧行为:每个
    冷却周期空烧一整轮热身,真机 ≈2.4s,0 行落库)。返回 False 不占 batch。"""
    rows = _mk_rounds(40)
    hole = rows[30]["round_id"]
    rows = [r for r in rows if r["round_id"] != hole]     # 挖洞
    follower = hole + ROUND_STEP
    rs = {"901": rows}
    w = await _mk_worker(["901"], gaps={"901": [follower]}, rounds=rs)
    ran = await w._replay_room("901", 100, 5, w.s.prediction)
    assert ran is False, "全不可补应短路(不计入 batch)"
    assert w.bridge.seqs == [], "短路时不得跑引擎"
    assert "901" not in w.db.saved
    await w.bus.r.aclose()


@pytest.mark.asyncio
async def test_mixed_gaps_run_engine_and_skip_follower():
    """混合缺口:可补的照补,洞后局天然写不出(判据与 replay_window 写出条件
    逐条对齐 —— 传引擎的仍是完整 missing,输出不因裁剪而变)。"""
    rows = _mk_rounds(40)
    hole = rows[30]["round_id"]
    rows = [r for r in rows if r["round_id"] != hole]
    follower = hole + ROUND_STEP
    normal = rows[-1]["round_id"]                          # 链完好的正常缺口
    rs = {"902": rows}
    w = await _mk_worker(["902"], gaps={"902": [follower, normal]}, rounds=rs)
    ran = await w._replay_room("902", 100, 5, w.s.prediction)
    assert ran is True
    saved = {r[0] for r in w.db.saved.get("902", [])}   # 行首元 = round_id
    assert normal in saved and follower not in saved
    await w.bus.r.aclose()


# ═════════════ D. 孤儿补结算:SQL 形状 + worker 接线 ═══════════════════════════
@pytest.mark.asyncio
async def test_heal_orphans_sql_shape():
    """纯账本修复的 SQL 纪律:铁孤儿判据(p.round_id+STEP<=anchor)、主优先
    CASE、COALESCE 兜 NULL 数组、绝不触碰 source/predictor_state。"""
    from app.db import DB
    from tests.test_pred_replay import _FakeCon, _FakePool
    con = _FakeCon(None, [])
    db = DB.__new__(DB)
    db.pool = _FakePool(con)
    n = await db.heal_orphan_settlements("321", 100)
    assert n == 0
    sql, args = con.seen[0]
    assert "hit IS NULL" in sql and "actual_custom_id IS NULL" in sql
    assert "MAX(round_id)" in sql
    assert re.search(r"round_id \+ \$3::bigint <= a\.m", sql), "缺铁孤儿判据"
    assert "WHEN COALESCE(p.main_ids" in sql and "'main'" in sql, "缺主优先 CASE"
    assert "predictor_state" not in sql, "补结算绝不推权重/碰引擎状态"
    assert "SET actual_custom_id" in sql and "source" not in sql.split("SET", 1)[1].split("FROM")[0], \
        "补结算不得改写 source(实盘行保持实盘口径)"
    assert args == ("321", 99 * ROUND_STEP, ROUND_STEP)


@pytest.mark.asyncio
async def test_replay_room_calls_heal_first():
    """_replay_room 头部必须先补账再看窗(口径自洽:孤儿补上判定后,
    accuracy 与缺口判定用的是同一本账)。"""
    rs = {"903": _mk_rounds(40)}
    w = await _mk_worker(["903"], gaps={"903": []}, rounds=rs)
    await w._replay_room("903", 100, 5, w.s.prediction)
    assert w.db.healed_calls == [("903", 100)]
    await w.bus.r.aclose()


# ═════════════ E. accuracy 实盘分列(README §10.1 预留正解的兑现) ═══════════════
@pytest.mark.asyncio
async def test_accuracy_live_split_adds_up():
    """合并数 − 实盘数 恒等于 replay(口径自证);零锚分支同样携带新键。"""
    from app.db import DB, SRC_REPLAY
    from tests.test_pred_replay import _FakeCon, _FakePool
    anchor = 1_700_000_000_000
    rows = [{"hit": "main", "round_id": anchor, "source": None},
            {"hit": "main", "round_id": anchor - ROUND_STEP, "source": SRC_REPLAY},
            {"hit": "guard", "round_id": anchor - 2 * ROUND_STEP, "source": None},
            {"hit": "miss", "round_id": anchor - 3 * ROUND_STEP, "source": SRC_REPLAY}]
    db = DB.__new__(DB)
    db.pool = _FakePool(_FakeCon(anchor, rows))
    acc = await db.accuracy("321", 100)
    assert (acc["live_main"], acc["live_cover"]) == (1, 2)
    assert acc["main"] - acc["live_main"] == 1            # 差值即补算主中
    assert acc["cover"] - acc["live_cover"] == 1
    db2 = DB.__new__(DB)
    db2.pool = _FakePool(_FakeCon(None, []))
    acc0 = await db2.accuracy("321", 100)
    assert acc0["live_main"] == 0 and acc0["live_cover"] == 0


# ═════════════ F. web 侧接线的源码钉(防「顺手回退」) ═══════════════════════════
def test_touch_room_wires_gate_clear_and_wake_push():
    """唤醒序列必须包含 清补算冷却闸 + 入唤醒快道 —— config_registry 的书面
    承诺「转正/唤醒会当场清掉该房的冷却」自 4.9.3 起才真正成立,谁删谁回退。"""
    src = (_ROOT / "backend_async" / "app" / "web.py").read_text(encoding="utf-8")
    body = re.search(r"async def _touch_room\(.*?\n(async def|@app)", src, re.S)
    assert body, "_touch_room 不见了?"
    seg = body.group(0)
    assert "replay_gate_clear" in seg, "唤醒未清补算冷却闸(D2 回归)"
    assert "replay_wake_push" in seg, "唤醒未入快道(秒级补满失效)"
    add = re.search(r'async def monitor_add.*?\n@app', src, re.S) or \
        re.search(r'"/api/monitor/add".*?\n@app', src, re.S)
    assert add and "replay_wake_push" in add.group(0), "转正路径未入快道"
