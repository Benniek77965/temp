"""
test_industrial.py — 工业级维度契约(顺序事件泵测不到的四个方向)
================================================================================
  ⑫ 真并发原子性:双副本对同一到期任务批真并发争抢(claim_due 为 Lua 原子
     顺延租约),零双取零双打 —— 上游调用数恰等于理论事件数,数据完整;
  ⑬ 租约重投(at-least-once):副本 claim 后崩溃(不处理不 ack),租约
     (stale_task_grace_ms=15s)到期任务自动重投递,另一副本接手完成;
     ack 后绝不再投;
  ⑭ 毒丸任务韧性:DB 对特定局连续抛错 —— 消费护栏语义(异常重排 +3s)下
     循环不死、其他任务照常、毒丸自愈后该局最终入库,全程零丢失;
  ⑮ 时钟偏移容忍:本地钟相对服务器 ±30s —— 领先由 award 退避链吸收
     (1.5+3+6+12+24=46.5s > 30s),滞后仅等效延迟;两向数据完整零洞;
  ⑯ janitor 复活:MainPage 排程链彻底断裂(任何成因)—— 差集巡检把房补排
     回来,漏局分支一次补齐停摆窗,哨兵/租约之外的最后防线闭合;
  ⑰ 多房错峰与隔离:批量准入经 schedule_spread 均匀铺开(无同毫秒风暴);
     定向故障只伤目标房,其余房 GameHistory 恒 1、零登记、数据完整,
     逐房调用计数与全局自洽;
  ⑱ 出怪推送三通路防丢:结算异常不连坐、未知妖兽也推、history 抢先入库时
     aw 入口短路轻量补发(latestRoundId 追平);
  ⑲ 空奖重试阶梯早段密化:就绪晚 2.5s 落库 ≤4.9s、晚 5s ≤11.3s、晚 10s ≤15.6s(HAR 尾巴档),正常局
     ≤2.2s 恰 1 拍;官方缺升级视界 [备战+20,+26]s 护栏不动。
真机性:与仿真台同一套真实 Worker + fakeredis(lua) 真实 Lua 脚本,零网络零 PG。
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts.sim_history_gap import (  # noqa: E402
    ROOM, STEP, build_world, pump,
)
import app.redis_bus as rb  # noqa: E402
import app.worker as wk  # noqa: E402

GRACE = 15_000                                     # 生产 stale_task_grace_ms


def _twin(w):
    """第二副本:共享同一 Redis/DB/上游/时钟(同 S7 接线)。"""
    w2 = wk.Worker(w.s)
    w2.bus.r, w2.up, w2.db = w.bus.r, w.up, w.db
    return w2


@pytest.mark.asyncio
async def test_concurrent_claim_no_double_handling():
    """契约⑫:两副本每拍**真并发**(asyncio.gather)争抢同一批到期任务。
    claim_due 的 Lua 原子性保证同一任务只落一家;断言上游调用总数
    恰等于单副本世界的理论值(mp=局数+1、aw=局数+1),零双打、数据完整。"""
    w, up, db, clock = build_world("gap_only")
    w2 = _twin(w)
    await w.bus.add_room(ROOM)
    await w.bus.schedule(rb.task_mainpage(ROOM), clock.t)
    start = up.cur_round()
    end = start + 40 * STEP + 45_000

    async def race_once():
        a, b = await asyncio.gather(w.bus.claim_due(10, GRACE),
                                    w2.bus.claim_due(10, GRACE))
        assert not (set(a) & set(b)), "同一任务被双副本同时取走"
        await asyncio.gather(*[w._handle(m) for m in a],
                             *[w2._handle(m) for m in b])
        return len(a) + len(b)

    while clock.t < end:
        n = await race_once()
        if n:
            continue
        due = await w.bus.r.zrange(rb.K_SCHED, 0, 0, withscores=True)
        if not due:
            break
        clock.t = max(clock.t + 1, int(due[0][1]))
    # 第 40 局 award(due=+40局+36.5s)已落在主循环窗内,无需收尾追跑。
    ticks = 41                                     # 40 局窗内 41 拍
    assert up.calls["mp"] == ticks                 # 零双打(双副本≠双调用)
    assert up.calls["aw"] == ticks
    assert up.calls["hist"] == 1                   # 仅播种
    last = up.cur_round() - 2 * STEP
    holes = [r for r in range(start, last + 1, STEP) if r not in db.rounds]
    assert not holes


@pytest.mark.asyncio
async def test_lease_redelivery_after_crash():
    """契约⑬:副本 A claim 到 award 任务后崩溃(不处理不 ack)。租约到期
    (15s)后任务自动重投,副本 B 接手完成;上游 award 恰 1 次(A 未打),
    该局入库;B ack 之后再过 2×租约,任务绝不再现(零幽灵重投)。"""
    w, up, db, clock = build_world("gap_only")
    w2 = _twin(w)
    await w.bus.add_room(ROOM)
    rid = up.cur_round() - 3 * STEP                # 一个已就绪的历史格点
    member = rb.task_award(ROOM, rid)
    await w.bus.schedule(member, clock.t)

    got_a = await w.bus.claim_due(10, GRACE)
    assert member in got_a                         # A 取到 → 随即"崩溃"
    assert not await w2.bus.claim_due(10, GRACE)   # 租约内 B 取不到

    clock.t += GRACE + 1_000                       # 租约到期
    got_b = await w2.bus.claim_due(10, GRACE)
    assert member in got_b                         # 自动重投递给 B
    await w2._handle(member)                       # B 正常处理(内部 ack)
    assert rid in db.rounds
    assert up.calls["aw"] == 1                     # A 崩溃未打上游,总计恰 1

    clock.t += 2 * GRACE
    assert not await w.bus.claim_due(10, GRACE)    # ack 后零幽灵重投


@pytest.mark.asyncio
async def test_poison_task_does_not_kill_loop():
    """契约⑭:DB 对某一局连续抛错 3 次(毒丸)。按消费护栏语义(异常→重排
    +3s)复刻消费循环:毒丸期间其他局照常入库,毒丸自愈后该局补入,
    全程零丢失、循环不死。"""
    w, up, db, clock = build_world("gap_only")
    await w.bus.add_room(ROOM)
    await w.bus.schedule(rb.task_mainpage(ROOM), clock.t)
    start = up.cur_round()
    poison = start + 5 * STEP
    left = {"n": 3}
    orig_add = db.add_round

    async def add(room, rid, *a, **k):
        if rid == poison and left["n"] > 0:
            left["n"] -= 1
            raise RuntimeError("db poison")
        return await orig_add(room, rid, *a, **k)
    db.add_round = add

    end = start + 12 * STEP + 45_000
    while clock.t < end:                           # 复刻 _consumer 四行语义
        for m in await w.bus.claim_due(50, GRACE):
            try:
                await w._handle(m)
            except Exception:
                await w.bus.schedule(m, wk.now_ms() + 3_000)
        due = await w.bus.r.zrange(rb.K_SCHED, 0, 0, withscores=True)
        if not due:
            break
        clock.t = max(clock.t + 1, int(due[0][1]))

    assert left["n"] == 0                          # 毒丸吐净(3 次都被吞下重试)
    last = up.cur_round() - 2 * STEP
    holes = [r for r in range(start, last + 1, STEP) if r not in db.rounds]
    assert not holes                               # 毒丸局最终入库,其余零伤


@pytest.mark.asyncio
async def test_janitor_resurrects_orphaned_room():
    """契约⑯:mp 排程链断裂(唯一 mp 任务被吞,任何成因的抽象)——
    janitor 差集巡检(active−scheduled)补排,房复活;漏局分支一次
    补齐停摆窗,数据完整;巡检对健康房零动作。"""
    w, up, db, clock = build_world("gap_only")
    await w.bus.add_room(ROOM)
    await w.bus.schedule(rb.task_mainpage(ROOM), clock.t)
    start = up.cur_round()
    await pump(w, clock, start + 10 * STEP + 45_000)
    await w.bus.ack(rb.task_mainpage(ROOM))        # 断链:mp 任务人间蒸发
    assert ROOM in set(await w.bus.active_rooms())
    assert ROOM not in await w.bus.scheduled_rooms()
    clock.t += 4 * STEP                            # 停摆 4 局后 janitor 巡检
    active = set(await w.bus.active_rooms())
    missing = active - await w.bus.scheduled_rooms()
    assert missing == {ROOM}
    await w.bus.schedule_many({                    # 复刻 janitor 核心补排
        rb.task_mainpage(r): wk.now_ms() + (i * 25) % 3000
        for i, r in enumerate(sorted(missing))})
    assert ROOM in await w.bus.scheduled_rooms()
    await pump(w, clock, start + 22 * STEP + 45_000)
    last = up.cur_round() - 2 * STEP
    holes = [r for r in range(start, last + 1, STEP) if r not in db.rounds]
    assert not holes                               # 停摆窗被漏局分支补齐
    assert up.calls["hist"] == 2                   # 播种 + 复活补齐,零风暴
    # 健康态下巡检零动作
    assert not (set(await w.bus.active_rooms())
                - await w.bus.scheduled_rooms())


@pytest.mark.asyncio
async def test_multiroom_spread_and_isolation():
    """契约⑰:6 房批量准入走 schedule_spread(5s 窗)——首拍错峰无同毫秒
    风暴;定向故障(丢任务×2 + 官方缺×1)只作用于 ROOM:其余 5 房
    GameHistory 恒 1、零 offmiss、数据完整;逐房计数与全局自洽。"""
    w, up, db, clock = build_world("gap_only")
    rooms = [ROOM] + [f"90000{i}" for i in range(2, 7)]
    for r in rooms:
        await w.bus.add_room(r)
    await w.bus.schedule_spread([rb.task_mainpage(r) for r in rooms],
                                clock.t, 5_000)
    dues = [int(await w.bus.r.zscore(rb.K_SCHED, rb.task_mainpage(r)))
            for r in rooms]
    assert len(set(dues)) == len(rooms)            # 零同毫秒
    assert max(dues) - min(dues) >= 2_500          # 真铺开(≥半窗)
    start = up.cur_round()
    lost = {start + 6 * STEP, start + 14 * STEP}   # 定向 ROOM(member 含房号)
    from scripts.sim_history_gap import make_task_loser
    up.official_missing.add((ROOM, start + 10 * STEP))
    await pump(w, clock, start + 25 * STEP + 50_000, [make_task_loser(lost)])

    last = up.cur_round() - 2 * STEP
    for r in rooms[1:]:                            # 5 个旁观房:纯净
        assert up.calls_by_room[("hist", r)] == 1
        assert await w.bus.r.zcard(
            rb.K_OFF_MISSING.format(room=r)) == 0
        holes = [g for g in range(start, last + 1, STEP)
                 if g not in db.by_room[r]]
        assert not holes
    # ROOM 的 GameHistory 调用账:
    #   seed(1) + 丢任务哨兵×2(2) + 官方缺那一局:早探(1) + 升级(1) + 终拍(1) = 6
    # 3.4.1「早探 GameHistory」把兜底数据源从阶梯**末尾**(备战+26.9s)提到**第 3 拍**
    # (备战+5.7s)—— 修复「倒计时结束、下一局都开跑了才显示上一局出怪」。代价精确可控:
    #   · **只有慢局/缺局**多打 1 次 hist(此处即 official_missing 那一局:5 → 6);
    #   · **健康房零额外调用** —— 上面 5 个旁观房仍恒 `hist == 1`(仅 seed),已断言;
    #   · 官方缺失的判定语义**一字未改**:仍需升级 + 终拍的**双重** GameHistory 验证
    #     (offm 断言在下方,内容不变)。
    assert up.calls_by_room[("hist", ROOM)] == 6
    offm = {int(x) for x in await w.bus.r.zrange(
        rb.K_OFF_MISSING.format(room=ROOM), 0, -1)}
    assert offm == {start + 10 * STEP}
    holes = [g for g in range(start, last + 1, STEP)
             if g not in db.by_room[ROOM] and g != start + 10 * STEP]
    assert not holes
    # 逐房计数与全局自洽
    for kind in ("mp", "aw", "hist"):
        assert sum(v for (k, _r), v in up.calls_by_room.items()
                   if k == kind) == up.calls[kind]


@pytest.mark.asyncio
async def test_draw_push_never_lost():
    """契约⑱:出怪 SSE 三通路防丢 ——
    a) 结算异常:推送先于结算且解耦,该局恰 1 次 room-updated、任务不重入;
    b) 未知妖兽(cid=None):同样推送(unknownBeast 标),前端不再空转轮询;
    c) history 抢先入库:aw 入口短路走轻量补发(roundsTouched),
       latestRoundId 追平 —— 彻底封死「库里有、前端等」。
    (真机症状:施法期倒计时 ~28s 前端才靠反复 /history 撞见上一局。)"""
    w, up, db, clock = build_world("gap_only")
    pushes = []
    orig_pub = w.bus.publish_draw
    async def pub(room, payload):
        pushes.append(payload)
        return await orig_pub(room, payload)
    w.bus.publish_draw = pub
    await w.bus.add_room(ROOM)
    await w.bus.schedule(rb.task_mainpage(ROOM), clock.t)
    start = up.cur_round()

    # a) 第 3 局结算抛错一次
    boom = {"left": 1}
    orig_settle = w._settle_and_predict
    async def settle(room, rid, cid):
        if rid == start + 3 * STEP and boom["left"]:
            boom["left"] -= 1
            raise RuntimeError("settle boom")
        return await orig_settle(room, rid, cid)
    w._settle_and_predict = settle
    # b) 第 5 局未知妖兽(上游名不在映射表)
    orig_beast = up._beast
    def beast(rid):
        if rid == start + 5 * STEP:                # 上游名不在本地映射表
            return {"beastId": 999999, "beastName": "神秘妖兽"}
        return orig_beast(rid)
    up._beast = beast

    await pump(w, clock, start + 8 * STEP + 45_000)
    r3 = [p for p in pushes if p.get("round", {}).get("round_id") == str(start + 3 * STEP)
          or p.get("roundId") == str(start + 3 * STEP)]
    assert len([p for p in r3 if p.get("type") == "room-updated"]) == 1
    assert boom["left"] == 0                       # 异常确实发生过且未重入
    r5 = [p for p in pushes if p.get("type") == "room-updated"
          and p.get("round", {}).get("round_id") == str(start + 5 * STEP)]
    assert len(r5) == 1 and r5[0].get("unknownBeast") is True

    # c) history 抢先:第 10 局先由 backfill 入库,aw 到点走短路补发
    rid10 = start + 10 * STEP
    await pump(w, clock, rid10 + 20_000)           # 本局进行中(aw 未到点)
    await w._backfill_history(ROOM)                # 不会含未出怪的 rid10
    await db.add_round(ROOM, rid10, "o", "虎", 3, 2, "history", "x", "y")
    n_before = len(pushes)
    await pump(w, clock, rid10 + 45_000)           # aw 到点 → 入口短路
    lite = [p for p in pushes[n_before:]
            if p.get("type") == "room-updated" and "round" not in p]
    assert len(lite) == 1                          # 恰一次轻量补发
    snap = await w.bus.get_snapshot(ROOM)
    assert int(snap["latestRoundId"]) == rid10     # 追平


@pytest.mark.asyncio
async def test_award_late_ready_dense_ladder():
    """契约⑲:空奖重试阶梯早段密化 —— 上游就绪晚的落库延迟帕累托:
    就绪正常(备战+1s)→ ≤2.2s 恰 1 拍;晚 2.5s → ≤4.9s ≤4 拍;
    晚 5s → ≤8.6s ≤5 拍;官方缺升级视界 ∈ [备战+20s, +26s] 护栏不动
    (防"就绪特别晚"被误判官方缺的窗口不因密化而塌)。
    (真机指纹:旧线性阶梯下前端 ~1s 轮询 /history 连续 5 次才拿到。)"""
    w, up, db, clock = build_world("gap_only")
    w.s.scheduler.award_jitter_ms = 1200
    marks = []
    orig_mark = w.bus.official_missing_mark
    async def mark(room, g):
        marks.append((g, clock.t))
        return await orig_mark(room, g)
    w.bus.official_missing_mark = mark
    await w.bus.add_room(ROOM)
    await w.bus.schedule(rb.task_mainpage(ROOM), clock.t)
    start = up.cur_round()
    SPELL = 35_000
    r_norm, r_25, r_50, r_10s = (start + k * STEP for k in (3, 5, 7, 11))
    up.ready_extra[r_25] = 2_500
    up.ready_extra[r_50] = 5_000
    up.ready_extra[r_10s] = 10_000                 # HAR 实证:临近局末才出数
    r_off = start + 9 * STEP
    up.official_missing.add(r_off)
    await pump(w, clock, start + 13 * STEP + 45_000)

    def land(rid):
        return db.first_insert_at[rid] - (rid + SPELL)
    assert land(r_norm) <= 2_200
    assert land(r_25) <= 6_100                     # try4@备战+5.7 锚定(+0.3 微抖)
    assert land(r_50) <= 12_500                    # 谷段按次峰档兜(HAR 占比≈0)
    assert land(r_10s) <= 12_500                   # 次峰锚 try5@备战+12.0 钉死
    esc = [t - (g + SPELL) for g, t in marks if g == r_off]
    assert len(esc) == 1 and 42_000 <= esc[0] <= 46_500   # 终拍锚 备战+43 双验后登记
    assert not any(g == r_10s for g, _t in marks)  # 尾巴局绝不误判官方缺


@pytest.mark.asyncio
@pytest.mark.parametrize("skew", [+30_000, -30_000])
async def test_clock_skew_absorbed(skew):
    """契约⑮:本地钟相对服务器 ±30s。领先(+):award 提前打→未就绪→退避链
    (Σ=46.5s)吸收;滞后(−):等效延迟。两向数据完整零洞、无异常调用风暴。"""
    w, up, db, clock = build_world("gap_only")
    real_now = wk.now_ms
    wk.now_ms = lambda: clock.t + skew             # 全系统本地钟偏移
    rb.now_ms = wk.now_ms
    try:
        await w.bus.add_room(ROOM)
        await w.bus.schedule(rb.task_mainpage(ROOM), clock.t + skew)
        start = up.cur_round()
        end = start + 25 * STEP + 45_000 + abs(skew)
        while clock.t < end:                       # 自带推钟:due 是本地钟值,
            for m in await w.bus.claim_due(50, GRACE):   # 减 skew 还原服务器钟,
                await w._handle(m)                       # 免负偏移毫秒爬行
            due = await w.bus.r.zrange(rb.K_SCHED, 0, 0, withscores=True)
            if not due:
                break
            clock.t = max(clock.t + 1, int(due[0][1]) - skew)
        last = up.cur_round() - 2 * STEP
        holes = [r for r in range(start, last + 1, STEP)
                 if r not in db.rounds]
        assert not holes
        assert up.calls["hist"] == 1               # 偏移不触发任何补漏
        assert up.calls["aw"] <= 26 * 6            # 退避链上界内,无风暴
    finally:
        wk.now_ms = real_now
        rb.now_ms = real_now
