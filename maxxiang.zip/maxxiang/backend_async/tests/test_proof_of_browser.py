"""
test_proof_of_browser.py — 安全加固 3.9.1:执行证明闸(L2)
================================================================================
钉住三件事:

一、**跨语言逐位一致(本文件的头号契约)**
    后端 `app/web.py::_pow_answer` 与前端 `assets/app.js::powAnswer` 必须对**任意**
    输入产出同一串。任何一侧被改而另一侧没跟上 → **全体已登录用户被 401 锁死**
    (开启该特性时)。这是本项目最脆的耦合点,故用两道守卫:
      · 黄金向量(恒跑,零依赖):从两实现对拍确认过的固定用例;
      · 活体对拍(装了 node 才跑):**直接从 app.js 源码抠出 powAnswer** 丢给 node
        执行,与 Python 逐条比对 —— 改了 JS 忘了 Python(或反之)当场红。
    注:部署时 app.js 会被 javascript-obfuscator 混淆;混淆是**语义保持**的
    (已实测混淆产物对 1000 组随机输入与 Python 逐位一致),故对拍源码即足够。

二、**闸的姿态**:特性关 / 无身份 / Redis 异常 → 一律放行(fail-open);
    仅「开启 + 有身份 + 应答缺失或不符」才 401 proof_required。

三、**挑战签发**:开启时回 {enabled:true, challenge, ttl} 并落 Redis(带 TTL);
    关闭或签发失败 → {enabled:false}(前端据此完全不做证明流程)。
"""
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app.web as web  # noqa: E402

APP_JS = Path(__file__).resolve().parents[2] / "assets" / "app.js"

# 黄金向量:由「Python 实现」与「JS 实现」独立对拍确认(含中文/符号/空串/长串)。
# 若某天两侧同时被改,本表会把「行为变了」这件事显式暴露出来(而不是静默漂移)。
GOLDEN = {
    "": "a61db31c673ee3ef",
    "a": "167f02cdf450135d",
    "deadbeef": "469217a5a2bc6efb",
    "0123456789abcdef0123456789abcdef": "e069a6c69df047d7",
    "中文测试": "78365e94fcdcd22b",
    "!@#%^&*()_+-=": "fb7ecd947b393bce",
}


def test_pow_answer_shape():
    """输出恒为 16 位小写十六进制(两个 32 位累加器的十六进制拼接)。"""
    for s in ["", "a", "deadbeef", "中文", "x" * 200]:
        out = web._pow_answer(s)
        assert len(out) == 16
        assert all(c in "0123456789abcdef" for c in out)


def test_pow_answer_is_sensitive():
    """雪崩性:输入差一位 → 输出必不同(挑战随机,应答不可猜)。"""
    assert web._pow_answer("abc") != web._pow_answer("abd")
    assert web._pow_answer("abc") != web._pow_answer("acb")
    assert web._pow_answer("a" * 10) != web._pow_answer("a" * 11)


def _node() -> str | None:
    return shutil.which("node")


def _extract_js_pow() -> str:
    """从 app.js 源码里抠出 powAnswer 函数体(逐字,不复制粘贴 —— 复制粘贴会让
    本测试对着自己的副本自证,失去守卫意义)。"""
    src = APP_JS.read_text(encoding="utf-8")
    i = src.find("function powAnswer(")
    assert i >= 0, "assets/app.js 里找不到 function powAnswer( —— L2 前端实现丢失?"
    # 从函数起始处做花括号配平,取出完整函数
    j = src.find("{", i)
    depth, k = 0, j
    while k < len(src):
        if src[k] == "{":
            depth += 1
        elif src[k] == "}":
            depth -= 1
            if depth == 0:
                return src[i:k + 1]
        k += 1
    raise AssertionError("powAnswer 花括号未配平")


@pytest.mark.skipif(not APP_JS.is_file(), reason="缺 assets/app.js(仅后端包)")
def test_js_impl_exists_and_matches_golden_shape():
    """前端实现必须在,且是 Math.imul 版(32 位乘法语义,与 Python 的 & 0xFFFFFFFF 对应)。"""
    js = _extract_js_pow()
    assert "Math.imul" in js and ">>> 0" in js


@pytest.mark.skipif(not APP_JS.is_file() or _node() is None,
                    reason="需要 node 才能做 JS↔Python 活体对拍")
def test_js_python_parity_live():
    """**头号守卫**:直接执行 app.js 里的 powAnswer,与 Python 逐条比对。
    覆盖 ASCII / 中文 / 符号 / 空串 / 长串 / 边界码点。"""
    cases = ["", "a", "ab", "deadbeef", "0123456789abcdef" * 2, "中文测试符号",
             "!@#%^&*()_+-=", "x" * 129, "\u0000\u007f\uffff", "Ω≈ç√∫˜µ",
             "9f8e7d6c5b4a39281706", "tab-" + "z" * 40]
    js = _extract_js_pow()
    prog = js + "\nconst cases = " + json.dumps(cases) + ";\n" \
        "console.log(JSON.stringify(cases.map(c => powAnswer(c))));\n"
    with tempfile.NamedTemporaryFile("w", suffix=".mjs", delete=False,
                                     encoding="utf-8") as f:
        f.write(prog)
        path = f.name
    try:
        out = subprocess.run([_node(), path], capture_output=True, text=True,
                             timeout=30, check=True)
        got = json.loads(out.stdout.strip())
    finally:
        Path(path).unlink(missing_ok=True)
    exp = [web._pow_answer(c) for c in cases]
    assert got == exp, ("前后端执行证明实现已漂移!开启 STA_USER_PROOF_OF_BROWSER 会把"
                        "全体已登录用户 401 锁死。逐例:"
                        + repr([(c, g, e) for c, g, e in zip(cases, got, exp) if g != e]))


@pytest.mark.skipif(not APP_JS.is_file() or _node() is None, reason="需要 node")
def test_golden_vectors_match_both_impls():
    """黄金向量:Python 侧恒验;JS 侧在有 node 时一并验(两侧都不许静默漂移)。"""
    for c, want in GOLDEN.items():
        assert web._pow_answer(c) == want, f"Python 侧漂移:{c!r}"
    js = _extract_js_pow()
    keys = list(GOLDEN)
    prog = js + "\nconst ks = " + json.dumps(keys) + ";\n" \
        "console.log(JSON.stringify(ks.map(c => powAnswer(c))));\n"
    with tempfile.NamedTemporaryFile("w", suffix=".mjs", delete=False,
                                     encoding="utf-8") as f:
        f.write(prog)
        path = f.name
    try:
        out = subprocess.run([_node(), path], capture_output=True, text=True,
                             timeout=30, check=True)
        got = json.loads(out.stdout.strip())
    finally:
        Path(path).unlink(missing_ok=True)
    assert got == [GOLDEN[k] for k in keys], "JS 侧漂移"


# ══ 闸的姿态 ══════════════════════════════════════════════════════════════════
class _Req:
    def __init__(self, user=None, proof=None, cookie="sess-abc"):
        self.headers = {"x-jf-proof": proof} if proof else {}
        self.cookies = {"jf_sess": cookie} if cookie else {}
        self.query_params = {}
        self.state = type("S", (), {"user": user})()


class _User:
    user_id = 7


def _bus_with(chal):
    class _R:
        async def get(self, k):
            return chal
        async def set(self, k, v, ex=None):
            return True
    return type("B", (), {"r": _R()})()


def _setup(monkeypatch, on=True, chal="CHAL", auth=True):
    monkeypatch.setattr(web.userauth, "enabled", lambda: auth)
    monkeypatch.setattr(web.settings.userauth, "proof_of_browser", on, raising=False)
    monkeypatch.setattr(web.settings.userauth, "proof_challenge_ttl_s", 180.0, raising=False)
    monkeypatch.setattr(web.ST, "bus", _bus_with(chal), raising=False)

    class _Cfg:
        cookie_name = "jf_sess"
    monkeypatch.setattr(web.userauth.UA, "cfg", _Cfg(), raising=False)


@pytest.mark.asyncio
async def test_proof_guard_off_is_noop(monkeypatch):
    """特性关 → 恒放行(默认姿态:不影响任何现网行为)。"""
    _setup(monkeypatch, on=False)
    assert await web._proof_guard(_Req(_User())) is None


@pytest.mark.asyncio
async def test_proof_guard_noop_without_login_or_user(monkeypatch):
    """登录系统未启用 / 无身份(运维旁路)→ 放行。"""
    _setup(monkeypatch, on=True, auth=False)
    assert await web._proof_guard(_Req(_User())) is None
    _setup(monkeypatch, on=True, auth=True)
    assert await web._proof_guard(_Req(user=None)) is None


@pytest.mark.asyncio
async def test_proof_guard_denies_without_proof(monkeypatch):
    """开启 + 有身份 + **无应答头**(纯 API 搬运器的典型形态)→ 401 proof_required。"""
    _setup(monkeypatch, on=True, chal="CHAL")
    r = await web._proof_guard(_Req(_User(), proof=None))
    assert r is not None and r.status_code == 401 and b"proof_required" in r.body


@pytest.mark.asyncio
async def test_proof_guard_denies_wrong_proof(monkeypatch):
    """应答不符(乱填/抄别的会话的)→ 401。"""
    _setup(monkeypatch, on=True, chal="CHAL")
    r = await web._proof_guard(_Req(_User(), proof="deadbeefdeadbeef"))
    assert r is not None and r.status_code == 401


@pytest.mark.asyncio
async def test_proof_guard_allows_correct_proof(monkeypatch):
    """应答 == _pow_answer(该会话挑战) → 放行(真浏览器跑完 JS 的形态)。"""
    _setup(monkeypatch, on=True, chal="CHAL")
    good = web._pow_answer("CHAL")
    assert await web._proof_guard(_Req(_User(), proof=good)) is None


@pytest.mark.asyncio
async def test_proof_guard_denies_when_challenge_expired(monkeypatch):
    """挑战过期(Redis 无键)→ 401,前端据此重铸并重试一次。"""
    _setup(monkeypatch, on=True, chal=None)
    r = await web._proof_guard(_Req(_User(), proof="whatever"))
    assert r is not None and r.status_code == 401


@pytest.mark.asyncio
async def test_proof_guard_fail_open_on_redis_error(monkeypatch):
    """Redis 抖动 → **放行**(绝不因协调层故障把真人锁在门外)。"""
    _setup(monkeypatch, on=True)

    class _Boom:
        class r:
            @staticmethod
            async def get(k):
                raise RuntimeError("redis down")
    monkeypatch.setattr(web.ST, "bus", _Boom(), raising=False)
    assert await web._proof_guard(_Req(_User(), proof="x")) is None


@pytest.mark.asyncio
async def test_pow_mint_enabled_and_disabled(monkeypatch):
    """签发:开启 → {enabled:true, challenge, ttl};关闭 → {enabled:false}。"""
    _setup(monkeypatch, on=True)
    out = await web.pow_mint(_Req(_User()))
    assert out["enabled"] is True and len(out["challenge"]) == 32 and out["ttl"] == 180
    _setup(monkeypatch, on=False)
    assert (await web.pow_mint(_Req(_User())))["enabled"] is False


@pytest.mark.asyncio
async def test_pow_mint_fail_open_on_redis_error(monkeypatch):
    """签发落库失败 → enabled:false(前端不做证明;闸侧亦 fail-open)→ 不锁真人。"""
    _setup(monkeypatch, on=True)

    class _Boom:
        class r:
            @staticmethod
            async def set(k, v, ex=None):
                raise RuntimeError("redis down")
    monkeypatch.setattr(web.ST, "bus", _Boom(), raising=False)
    assert (await web.pow_mint(_Req(_User())))["enabled"] is False
