"""test_prediction_chain.py — 前端两症状的根因守卫(3.4.1)

用户实测症状(真机 HAR + 全栈 E2E 双证):
  ① **前端预测数据不显示**  —— /prediction 连续返回 main=[] / target_round_id=null,
     而 record(判定记录)一直在推进 = 结算正常、**只是下一局预测没生成**。
  ② **出怪倒计时结束、下一局都开跑了,才显示上一局出怪** —— 数据落在局内 ~62s
     (倒计时 drawTime 在 40s 就结束、下一局 50s 就开始)。

同一根因链:**生成下一局预测只发生在 `_settle_and_predict`,而它只在
「RoundAward 拿到已知妖兽」这条主路上被调用**。三条路径插入新局却不生成预测:
    ① GameHistory 回填(`_backfill_history` → `_settle_only`:只结算不预测)
       —— 出怪兜底升级、漏局补齐、覆盖哨兵、**首见播种**全走这条;
    ② 妖兽未知(cid=NULL):`if is_new and cid:` 直接跳过;
    ③ 首见播种:回填 30 局后一条预测都没有。
链一断,`pending_prediction` 取不到下一局预测 → 被 `_build_prediction` 的孤儿过滤
(pend + ROUND_STEP <= latest)滤成 null → **前端预测号消失**。

而症状②的根因:award 连空时要烧满 11 拍阶梯(备战+26.9s)才降级查 GameHistory,
可实地核查(真实房 321)**GameHistory 在备战后 ~2.3s 就已含当前局** —— 白等 24 秒。
"""
from __future__ import annotations

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.constants import ROUND_STEP, SPELL_OFFSET_MS, DRAW_OFFSET_MS  # noqa: E402
from app.worker import AWARD_LADDER_MS, EARLY_HIST_ATTEMPT             # noqa: E402


# ── 症状② 的时序契约:早探必须赶在「倒计时结束」之前 ──────────────────────────
def test_early_hist_probe_lands_before_countdown_ends():
    """早探 GameHistory 的拍点,必须让数据在**倒计时(drawTime)结束前**落地 ——
    否则用户仍会看到「下一局都开跑了才显示上一局出怪」。

    局内时间轴:备战 35s → 倒计时结束(drawTime)40s → 本局结束/下一局开始 50s。
    旧实现只在阶梯**末拍**(attempt == award_max_retries ≈ 备战+26.9s = 局内 61.9s)
    才降级查 GameHistory —— 比倒计时结束晚 **21.9s**,已经是下一局的中段。
    """
    early_anchor = AWARD_LADDER_MS[EARLY_HIST_ATTEMPT - 1]       # 相对备战的 ms
    in_round_ms = SPELL_OFFSET_MS + early_anchor                 # 局内绝对时刻

    assert in_round_ms <= DRAW_OFFSET_MS + 1000, (
        f"早探落在局内 {in_round_ms/1000:.1f}s,晚于倒计时结束"
        f"({DRAW_OFFSET_MS/1000:.0f}s):用户仍会看到出怪晚一拍")
    assert in_round_ms < ROUND_STEP, "早探不得落到下一局"

    # 旧行为(末拍才查)作为对照:必须显著更晚 —— 这正是本次修复的价值
    old_anchor = AWARD_LADDER_MS[-1]
    old_in_round = SPELL_OFFSET_MS + old_anchor
    assert old_in_round > DRAW_OFFSET_MS + 15_000
    assert in_round_ms < old_in_round - 15_000, "早探至少要比旧的末拍兜底提早 15s"


def test_early_hist_probe_only_fires_on_slow_rounds():
    """早探必须发生在 award **已连空数拍**之后 —— 稳态(首拍即中,实测 aw≈0.96 次/局)
    绝不触发,不给上游增加任何调用。"""
    assert EARLY_HIST_ATTEMPT >= 3, (
        "早探拍点过早:award 还没连空几次就去打 GameHistory,"
        "会给正常局凭空增加上游调用")
    assert EARLY_HIST_ATTEMPT < len(AWARD_LADDER_MS), "早探必须在阶梯内(不能等到末拍)"


# ── 症状① 的核心契约:预测链自愈 ───────────────────────────────────────────────
_REDIS_URL = os.environ.get("STA_TEST_REDIS_URL", "")
_PG = os.environ.get("STA_PG_DSN", "")
_needs = pytest.mark.skipif(not (_REDIS_URL and _PG),
                            reason="需要 Redis + PostgreSQL")


@_needs
@pytest.mark.asyncio
async def test_ensure_next_prediction_repairs_broken_chain():
    """`_ensure_next_prediction` 必须能补齐被打断的预测链,且**幂等 + 稳态零开销**。

    这是「前端预测号消失」的直接修复点。
    """
    from app.db import DB
    from app.settings import get_settings

    db = DB(_PG, 2, 4)
    await db.connect()
    await db.migrate()
    room = "test_chain_9001"
    async with db.pool.acquire() as con:
        for t in ("rounds", "predictions", "predictor_state"):
            await con.execute(f"DELETE FROM {t} WHERE room_id=$1", room)

    # 基点必须落在**训练窗内**(prediction.train_window_hours=24h):db.sequence()
    # 按 start_ms >= now-24h 过滤,用固定的历史时间戳会取不到任何序列。
    import time as _t
    now = int(_t.time() * 1000)
    base = (now - 40 * ROUND_STEP) // ROUND_STEP * ROUND_STEP
    # 铺 40 局真实历史(有兽),但**一条预测都不写** —— 精确复刻「GameHistory 首见
    # 播种」后的库状态:局有了,预测链是空的。
    for i in range(40):
        rid = base + i * ROUND_STEP
        cid = (i % 9) + 1
        await db.add_round(room, rid, cid, f"妖{cid}", cid, 50, "history",
                           "2026-07-12 10:00:00", "2026-07-12")

    latest = base + 39 * ROUND_STEP
    nxt = latest + ROUND_STEP
    assert not await db.has_prediction(room, nxt)        # 链是断的
    assert await db.pending_prediction(room) is None     # 前端此时 main=[] / target=null

    # 用真实 worker 的补链逻辑(不 mock 预测引擎)
    from app.predictor_bridge import PredictorBridge
    from app.worker import Worker

    class _CuratedBus:                                    # 3.4.5 策展闸:测试房均为策展房
        async def is_discovered(self, room):
            return False

        # 3.7.0 冷房闸:`worker._dormant` 在 histmode.enabled **且**
        # curated_idle_enabled 双开时会再问一次 is_cold —— 而现行 config.yaml
        # 两者皆为 true(本测试刻意用真实 config.yaml 的预测配置)。
        # 4.9.5 补:此前这里缺该方法,`_dormant` 直接 AttributeError,本文件两条
        # 用例**必挂**。它们又都带 skipif(需 Redis+PG),没有这两样时整条被跳过 ⇒
        # 缺口在无依赖的环境里完全不可见。已实测:补上后两条恢复通过。
        # 测试房是「活跃策展房」,故恒 False(与 is_discovered 同义:不休眠)。
        async def is_cold(self, room):
            return False

    s = get_settings()                                    # 真实 config.yaml 的预测配置
    w = Worker.__new__(Worker)                            # 只装配补链所需的依赖
    w.s = s
    w.db = db
    w.bus = _CuratedBus()                                 # type: ignore[assignment]
    w.bridge = PredictorBridge(s.prediction, s.custom_beast_ids)
    import collections
    import asyncio as _aio
    w._room_locks = collections.defaultdict(_aio.Lock)

    out = await w._ensure_next_prediction(room)
    assert out is not None, "链断了却没补上 —— 前端预测号会一直不显示"
    assert out["target"] == str(nxt)
    assert len(out["main"]) > 0, "补出来的预测必须有主选号"

    # 前端现在能拿到号了(pending 非空且 target 就是下一局,不会被孤儿过滤)
    pend = await db.pending_prediction(room)
    assert pend is not None and int(pend["round_id"]) == nxt
    assert int(pend["round_id"]) + ROUND_STEP > latest, "不得被孤儿过滤(否则仍显示 null)"

    # 幂等 + 稳态零开销:链完好时再调一次,不写新行、不跑引擎
    again = await w._ensure_next_prediction(room)
    assert again is None
    async with db.pool.acquire() as con:
        n = await con.fetchval(
            "SELECT count(*) FROM predictions WHERE room_id=$1", room)
    assert n == 1, "幂等被破坏:重复补链写了多行"

    async with db.pool.acquire() as con:
        for t in ("rounds", "predictions", "predictor_state"):
            await con.execute(f"DELETE FROM {t} WHERE room_id=$1", room)
    await db.close()


@_needs
@pytest.mark.asyncio
async def test_unknown_beast_round_does_not_break_chain():
    """妖兽未知(cid=NULL)的局**不得**打断预测链。

    旧实现 `if is_new and cid:` 在 cid=NULL 时连结算带预测一起跳过 → 下一局没有
    预测 → pending 停在旧的未结算预测上 → 被孤儿过滤 → 前端号消失。
    修复后:cid=NULL 仍走补链(预测本就不需要本局的兽 —— db.sequence 只取
    custom_id 非空的局,预测语义与旧版逐字一致)。
    """
    import asyncio as _aio
    import collections

    from app.db import DB
    from app.predictor_bridge import PredictorBridge
    from app.settings import get_settings
    from app.worker import Worker

    db = DB(_PG, 2, 4)
    await db.connect()
    room = "test_chain_9002"
    async with db.pool.acquire() as con:
        for t in ("rounds", "predictions", "predictor_state"):
            await con.execute(f"DELETE FROM {t} WHERE room_id=$1", room)

    import time as _t
    now = int(_t.time() * 1000)
    base = (now - 31 * ROUND_STEP) // ROUND_STEP * ROUND_STEP
    for i in range(30):                                   # 30 局正常历史
        rid = base + i * ROUND_STEP
        cid = (i % 9) + 1
        await db.add_round(room, rid, cid, f"妖{cid}", cid, 50, "award",
                           "2026", "2026")
    # 末局妖兽未知(cid=NULL)—— 上游偶发不返回 beastId
    orphan = base + 30 * ROUND_STEP
    await db.add_round(room, orphan, None, "未知兽", None, None, "award",
                       "2026", "2026")

    class _CuratedBus:                                    # 3.4.5 策展闸:测试房为策展房
        async def is_discovered(self, room):
            return False

        async def is_cold(self, room):                    # 见上一条同名替身的说明
            return False

    s = get_settings()
    w = Worker.__new__(Worker)
    w.s = s
    w.db = db
    w.bus = _CuratedBus()                                 # type: ignore[assignment]
    w.bridge = PredictorBridge(s.prediction, s.custom_beast_ids)
    w._room_locks = collections.defaultdict(_aio.Lock)

    out = await w._ensure_next_prediction(room)
    assert out is not None, "cid=NULL 的局把预测链打断了 —— 前端号会消失"
    assert out["target"] == str(orphan + ROUND_STEP)

    pend = await db.pending_prediction(room)
    assert pend and int(pend["round_id"]) == orphan + ROUND_STEP
    # 关键:pending 是「最新局+1」,绝不会被 web._build_prediction 的孤儿过滤滤掉
    lr = await db.latest_round(room)
    assert int(pend["round_id"]) + ROUND_STEP > int(lr["round_id"])

    async with db.pool.acquire() as con:
        for t in ("rounds", "predictions", "predictor_state"):
            await con.execute(f"DELETE FROM {t} WHERE room_id=$1", room)
    await db.close()
