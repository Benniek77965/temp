"""
test_histmode_janitor.py — janitor 启用态分支的**单遍真实执行**(第八轮闭环)
================================================================================
第七轮如实标注了两处"启用态零执行"残余:janitor 的 missing 分流(发现房补 hs、
策展房补 mp)与挂起归一转正的封尾 hs@now。本文件用"熄火式睡眠夹具"让真实
`_janitor` 协程恰好执行一遍主体后自然退出 —— 不抽取、不复刻逻辑,跑的就是
生产代码本体:
    fake sleep 第 1 次放行(跳过秒级步进),之后把 _running 熄火,
    循环顶部的逐秒检查随即令协程 return。
stats 段有 elapsed≥60 门槛,单遍内自然跳过(_emit 已由 test_histmode_web
直调覆盖);db/star 用宽假件旁路(非被测对象),bus 为 fakeredis 真件。
"""
from __future__ import annotations

import pytest

import app.redis_bus as rb
import app.worker as wk
from app.redis_bus import task_hist, task_mainpage
from tests.test_histmode import _mini_world
from tests.test_histmode_web import _Star, _WideDB


@pytest.mark.asyncio
async def test_janitor_one_pass_enabled_split_and_pending_seal(monkeypatch):
    w, up, db, clock, s = _mini_world(enabled=True, interval_s=900)
    w.db = _WideDB()

    class _StarTo9500(_Star):
        async def canon(self, room):
            return "9500", True
    w.star = _StarTo9500()
    s.scheduler.janitor_interval_s = 2               # 两步睡眠:熄火发生在 for 内
                                                     # 第二步,for 耗尽→while 条件
                                                     # False→主体**恰 1 遍**(=1 时
                                                     # 存活检查先于睡眠,会跑 2 遍,
                                                     # 第九轮打点实证后修正)

    calls = {"n": 0}
    real_sleep = wk.asyncio.sleep

    async def fake_sleep(sec):
        calls["n"] += 1
        if calls["n"] > 1:                           # 第二遍睡眠 = 主体已跑完:熄火
            w._running = False
        await real_sleep(0)
    monkeypatch.setattr(wk.asyncio, "sleep", fake_sleep)

    # 「恰一遍」不作旁白作断言:主体每遍恰调一次 active_rooms,计数直证。
    body = {"n": 0}
    _orig_active = w.bus.active_rooms
    async def _counted():
        body["n"] += 1
        return await _orig_active()
    w.bus.active_rooms = _counted

    # 预置:两房都"名录幸存、调度丢失"(missing);9401 为发现房、9402 为策展房;
    # 挂起短号 77 → canon 归一为 9500(不在 active,由 pending 段现场转正)。
    await w.bus.add_rooms_bulk([("9401", "9401"), ("9402", "9402")])
    await w.bus.r.hset(rb.K_ROOMS_DISCOVERED, "9401", "1")
    await w.bus.r.hset(rb.K_ROOMS_PENDING, "77", str(clock.t))

    w._running = True
    await w._janitor()                               # 真协程,单遍后自然退出

    z = dict(await w.bus.r.zrange(rb.K_SCHED, 0, -1, withscores=True))
    # ① missing 分流:发现房自愈起点是 hs(满窗铺开),策展房仍是 mp
    assert task_hist("9401") in z and task_mainpage("9401") not in z
    assert task_mainpage("9402") in z and task_hist("9402") not in z
    hs_due = int(z[task_hist("9401")])
    assert 0 <= hs_due - clock.t <= 900_000          # 铺开落在一个周期窗内
    # ② 挂起归一转正:mp@now + 封尾 hs@now 双排;pending 清净;已入 active
    assert task_mainpage("9500") in z and task_hist("9500") in z
    assert int(z[task_hist("9500")]) - clock.t <= 1000
    assert not await w.bus.r.hexists(rb.K_ROOMS_PENDING, "77")
    assert "9500" in set(await _orig_active())       # 走原函数,不污染主体计数
    assert body["n"] == 1, body                      # 主体恰 1 遍(计数直证)
    assert calls["n"] == 2                           # 两步睡眠即熄火
