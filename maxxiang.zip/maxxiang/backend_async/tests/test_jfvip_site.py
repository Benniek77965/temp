"""
test_jfvip_site.py — 站点分流(4.4.1)的机器保证
================================================================================
「直营主站 vs 代理镜像站」按请求 Host 分流。本文件钉死四类不变量:

  A. **归一化**:norm_host 只做无歧义变换(去 scheme/路径/端口/尾点 + 转小写),
     不做任何猜测;归一失败一律回 "" ⇒ 按"不在名单内"处理(fail-closed)。

  B. **不配置即不存在**:名单为空 ⇒ enforced=False 且 pay 恒 True(逐字节旧行为)。
     一旦非空 ⇒ **只有名单内是直营**,其余(含 www/裸域之差、IP 直连)一律镜像。

  C. **XFH 默认不信任**:jf_direct_trust_xfh=False 时只认 Host 头;开启后取首跳,
     缺失回落 Host。

  D. **只闸下单**(最重要的一条):web.py 里按站点拒绝的判定**恰好一处**,且必须
     落在 vip_order_create 函数体内。order/status、order/reconcile、simulate-pay
     是**钱的回收路径**,不闸有两条理由:① 闸它们零收益 —— 镜像站上根本创建不出
     订单;② 闸它们有真实资损风险,场景是**配置变更**:某域名原本在直营名单里
     (用户在该 origin 下过单、本机 localStorage 存着在途单标记),之后被移出名单
     或首次启用本特性把它划成镜像 —— 此刻标记仍在,payRecover() → reconcile 若被拒,
     这笔钱永远停在 pending 且无自动救回路径(jfpay.py 安全不变量 8)。
     (复审更正:初版写的是「直营站付款后打开镜像站」,那是错的 —— localStorage
      按 origin 隔离,镜像站读不到直营站的标记。结论不变,理由已订正。)

纯静态 + 纯内存,零外部依赖(不需要 MySQL / Redis)。
"""
from __future__ import annotations

import ast
import re
from pathlib import Path

import pytest

from app import userauth, web
from app.settings import UserAuthCfg

APP_DIR = Path(__file__).resolve().parent.parent / "app"


class _Req:
    """最小 Request 替身 —— 站点判定只读 headers,不碰其余任何字段。"""

    def __init__(self, headers=None):
        self.headers = headers or {}


@pytest.fixture(autouse=True)
def _cfg(monkeypatch):
    """每个用例一份干净配置;默认「未配置」= 特性关闭。"""
    cfg = UserAuthCfg(host="h", db="d", user="u", jf_vip_enabled=True)
    monkeypatch.setattr(userauth.UA, "cfg", cfg, raising=False)
    return cfg


# ══════════════════════════════════════════════════════════════════════════════
# A. 归一化
# ══════════════════════════════════════════════════════════════════════════════
@pytest.mark.parametrize("raw,want", [
    ("Example.COM", "example.com"),                      # 大小写
    ("example.com:5173", "example.com"),                 # 端口
    ("example.com.", "example.com"),                     # FQDN 尾随点
    ("https://Example.com:8443/path?x=1", "example.com"),  # 整条 URL 粘贴
    ("http://example.com", "example.com"),
    ("  example.com  ", "example.com"),                  # 首尾空白
    ("[::1]:5173", "[::1]"),                             # IPv6 字面量保留方括号
    ("[2001:db8::1]", "[2001:db8::1]"),
    ("203.0.113.7:5173", "203.0.113.7"),                 # IP 直连
    ("", ""),
    (None, ""),
    ("   ", ""),
    ("https://", ""),                                    # 只有 scheme ⇒ 空
    ("/path/only", ""),                                  # 无主机名 ⇒ 空
])
def test_norm_host_table(raw, want):
    assert userauth.norm_host(raw) == want


def test_norm_host_strips_any_scheme():
    """剥任意 scheme 而不只剥 http/https —— 只剥两个的话 `ftp://example.com` 会在
    「去端口」一步被切成无意义的 `ftp`(本测试首轮实测抓到),运维在启动横幅里
    看到那个残片也猜不出发生了什么。"""
    assert userauth.norm_host("ftp://example.com") == "example.com"
    assert userauth.norm_host("//example.com") == "example.com"


def test_norm_host_does_not_guess():
    """真正畸形的值原样留着,自然匹配不上(fail-closed),而不是被"纠正"成
    某个可能属于别人的域名 —— 与 jfvip.norm_card「刻意不做字符纠错」同一纪律。"""
    assert userauth.norm_host("example.com evil.com") == "example.com evil.com"
    assert userauth.norm_host("exa mple.com") == "exa mple.com"


# ══════════════════════════════════════════════════════════════════════════════
# B. 名单解析 / 分流判定
# ══════════════════════════════════════════════════════════════════════════════
def test_hosts_split_tolerates_paste_noise(_cfg):
    """分隔符认半角逗号/分号/空白,外加中文逗号与顿号 —— 从聊天窗口或文档粘贴
    是高频路径,与 jfvip 卡密归一化容忍粘贴噪音同一取向。"""
    _cfg.jf_direct_hosts = "A.com, b.com;  https://C.com:443/ 、d.com，e.com."
    assert userauth.jf_direct_host_set() == frozenset(
        {"a.com", "b.com", "c.com", "d.com", "e.com"})


def test_empty_means_absent(_cfg):
    """不配置即不存在:任何 Host 都是直营,且 enforced=False。"""
    for h in ("example.com", "a.agent.example", "", "1.2.3.4:5173"):
        st = userauth.jf_site(_Req({"host": h}))
        assert st["enforced"] is False
        assert st["pay"] is True and st["direct"] is True

    _cfg.jf_direct_hosts = "  ,, 、 ，  "        # 全是分隔符 ⇒ 归一化后空集
    st = userauth.jf_site(_Req({"host": "a.agent.example"}))
    assert st["enforced"] is False and st["pay"] is True


def test_direct_whitelist_exact_match(_cfg):
    _cfg.jf_direct_hosts = "jiufa.example.com, www.jiufa.example.com"
    ok = userauth.jf_site(_Req({"host": "JIUFA.example.com:443"}))
    assert ok["enforced"] is True and ok["direct"] is True and ok["pay"] is True
    assert ok["host"] == "jiufa.example.com"      # 回显归一化后的判定用值

    for bad in ("a.agent.example", "jiufa.example.com.evil.com",
                "sub.jiufa.example.com", "1.2.3.4"):
        st = userauth.jf_site(_Req({"host": bad}))
        assert st["direct"] is False and st["pay"] is False, bad


def test_no_wildcard_semantics(_cfg):
    """刻意不支持通配符:`*.example.com` 会连带命中代理自建的 agent.example.com,
    而那正是要防的那一类漏配。配了通配符 ⇒ 它只会作为一个匹配不上的字面量存在。"""
    _cfg.jf_direct_hosts = "*.example.com"
    assert userauth.jf_site(_Req({"host": "www.example.com"}))["pay"] is False


def test_bare_and_www_are_two_hosts(_cfg):
    """最容易踩的坑,必须有钉:只写裸域时 www 子域会被判成镜像站。"""
    _cfg.jf_direct_hosts = "example.com"
    assert userauth.jf_site(_Req({"host": "example.com"}))["pay"] is True
    assert userauth.jf_site(_Req({"host": "www.example.com"}))["pay"] is False


def test_missing_host_header_is_mirror(_cfg):
    """取不到 Host(畸形请求)⇒ 不在名单内 ⇒ 按镜像站(fail-closed)。"""
    _cfg.jf_direct_hosts = "example.com"
    assert userauth.jf_site(_Req({}))["pay"] is False
    assert userauth.jf_site(None)["pay"] is False


# ══════════════════════════════════════════════════════════════════════════════
# C. X-Forwarded-Host 信任开关
# ══════════════════════════════════════════════════════════════════════════════
def test_xfh_not_trusted_by_default(_cfg):
    _cfg.jf_direct_hosts = "example.com"
    req = _Req({"host": "a.agent.example", "x-forwarded-host": "example.com"})
    assert userauth.jf_site(req)["pay"] is False, "默认不得信任 XFH"


def test_xfh_trusted_takes_first_hop(_cfg):
    _cfg.jf_direct_hosts = "example.com"
    _cfg.jf_direct_trust_xfh = True
    req = _Req({"host": "upstream-pool",
                "x-forwarded-host": "example.com, edge-1.internal"})
    assert userauth.jf_site(req)["pay"] is True


def test_xfh_trusted_falls_back_to_host(_cfg):
    """开了信任但该头缺失/为空 ⇒ 回落 Host,而不是判成空主机名。"""
    _cfg.jf_direct_hosts = "example.com"
    _cfg.jf_direct_trust_xfh = True
    assert userauth.jf_site(_Req({"host": "example.com"}))["pay"] is True
    assert userauth.jf_site(
        _Req({"host": "example.com", "x-forwarded-host": "  "}))["pay"] is True


# ══════════════════════════════════════════════════════════════════════════════
# D. 下发契约与「只闸下单」纪律
# ══════════════════════════════════════════════════════════════════════════════
def test_session_payload_carries_site(_cfg):
    """未启用 VIP 时逐字节旧载荷;启用时必须带 site 段(前端唯一的信息来源)。"""
    _cfg.jf_vip_enabled = False
    assert userauth.jf_session_info(None) == {"enabled": False}

    _cfg.jf_vip_enabled = True
    _cfg.jf_direct_hosts = "example.com"
    out = userauth.jf_session_info(None, _Req({"host": "a.agent.example"}))
    assert out["enabled"] is True
    assert out["site"]["pay"] is False and out["site"]["enforced"] is True


def test_site_no_pay_error_is_403(_cfg):
    code, msg = web._VIP_ERR["site_no_pay"]
    assert code == 403
    # 页面上看到的、和绕过前端直调 API 收到的,必须是同一个说法
    assert "卡密" in msg and "客服" in msg


def _func_span(src: str, name: str):
    tree = ast.parse(src)
    for node in ast.walk(tree):
        if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)) and node.name == name:
            return node.lineno, node.end_lineno
    return None


def test_site_gate_lives_only_in_order_create():
    """★ 本文件最硬的一条:web.py 里对 jf_site 的调用**恰好一处**,且必须落在
    vip_order_create 体内。

    做法与 test_jfvip_discipline 的 tb_user 写点定位同款(AST 取函数行区间 +
    全文件正则),改名/挪位/复制到别的端点都会被当场抓到。

    为什么这条不能松:把站点闸抄到 reconcile / order/status 上,会让"直营站付了
    钱、镜像站打开页面"的用户彻底失去自动救回路径 —— 那是资损,不是体验问题。
    """
    src = (APP_DIR / "web.py").read_text(encoding="utf-8")
    span = _func_span(src, "vip_order_create")
    assert span is not None, "web.vip_order_create 丢失或改名 —— 站点闸的锚点没了"

    # 扫描类断言必须先剥注释(JFVIP-SYSTEM.md §9.6 附):注释里正当地提到了
    # 其余端点为何**不**接这道闸,不剥就会把说明文字误判成第二处调用。
    stripped = "\n".join(
        "" if ln.lstrip().startswith("#") else ln for ln in src.split("\n"))
    pat = re.compile(r"\buserauth\.jf_site\s*\(")
    hits = [i + 1 for i, ln in enumerate(stripped.split("\n")) if pat.search(ln)]

    # /api/vip/state 的同源回显不是「闸」,它只读不拒 —— 单列白名单并断言其位置,
    # 免得将来有人在那儿悄悄加上 return。
    state_span = _func_span(src, "vip_state_ep")
    inside_gate = [n for n in hits if span[0] <= n <= span[1]]
    inside_state = [n for n in hits if state_span and state_span[0] <= n <= state_span[1]]
    assert len(inside_gate) == 1, f"vip_order_create 内的站点判定应恰好 1 处,实为 {inside_gate}"
    assert sorted(inside_gate + inside_state) == hits, (
        f"web.py 出现了 order_create / vip_state 之外的站点判定: {hits} —— "
        f"若是给 reconcile/status 加闸,请先读本测试的 docstring")

    # 回收路径必须一个字都不带站点判定
    for fn in ("vip_order_status", "vip_order_reconcile", "vip_order_simulate"):
        fs = _func_span(src, fn)
        assert fs is not None, f"web.{fn} 丢失或改名"
        assert not [n for n in hits if fs[0] <= n <= fs[1]], (
            f"{fn} 是钱的回收路径,**不得**接站点闸(见本测试 docstring)")


# ══════════════════════════════════════════════════════════════════════════════
# E. 与「账密换链接」的交叉配置(单值 origin × 多 origin 部署)
# ══════════════════════════════════════════════════════════════════════════════
def _warns(**over):
    """跑一遍 semantic_validate,回 (errors, warnings)。"""
    from app import config_center as cfgc
    base = {"userauth.sso_link_base": "", "userauth.sso_link_enabled": False,
            "userauth.jf_direct_hosts": "", "userauth.jf_vip_enabled": True,
            "userauth.jf_direct_trust_xfh": False}
    base.update(over)
    return cfgc.semantic_validate(base, set(base))


def _hit(ws):
    return [w for w in ws if "sso_link_base" in w and "镜像" in w]


def test_single_origin_link_base_warns_under_site_split():
    """★ 两项分属不同 section,各自单看都完全正常 —— **只有合在一起才是错的**:
    单值 origin 会把所有调用方(含代理镜像站)的用户都送去同一个站,
    把 §12 好不容易做出的站点隔离在这一环上整个漏掉。"""
    _, ws = _warns(**{"userauth.sso_link_base": "https://gt.example.com",
                      "userauth.sso_link_enabled": True,
                      "userauth.jf_direct_hosts": "gt.example.com"})
    assert _hit(ws), f"三者同时成立必须告警,实得: {ws}"


@pytest.mark.parametrize("over", [
    # 清空 origin(本次推荐做法)⇒ 不该再吵
    {"userauth.sso_link_base": "", "userauth.sso_link_enabled": True,
     "userauth.jf_direct_hosts": "gt.example.com"},
    # 未启用站点分流 ⇒ 只有一个 origin,单值本就是对的
    {"userauth.sso_link_base": "https://gt.example.com",
     "userauth.sso_link_enabled": True, "userauth.jf_direct_hosts": ""},
    # 「账密换链接」没开 ⇒ 本项完全不生效,不制造噪音
    {"userauth.sso_link_base": "https://gt.example.com",
     "userauth.sso_link_enabled": False, "userauth.jf_direct_hosts": "gt.example.com"},
])
def test_no_false_alarm(over):
    """告警必须精准:多余的告警会被运维学会无视,那等于没有告警。"""
    _, ws = _warns(**over)
    assert not _hit(ws), f"不该告警却告警了: {ws}"


def test_site_split_warning_shows_normalized_hosts():
    """★ 专门覆盖 semantic_validate 里那个 try/except 包着的 norm_host **惰性导入**。

    那个 except 是为「校验器自身绝不可拖垮保存」而设的,代价是:导入一旦坏掉,
    它会被**静默吞掉** —— 告警凭空消失,而在此之前没有任何测试会因此变红。
    断言「归一化后的生效值出现在告警文本里」等于把那条导入路径钉死:
    只要 norm_host 没被真正调用,这条就过不去。
    """
    _, ws = _warns(**{"userauth.jf_direct_hosts":
                      "HTTPS://Jiufa.Example.COM:443/ , www.jiufa.example.com"})
    hit = [w for w in ws if "站点分流已启用" in w]
    assert hit, f"配了直营名单必须告警,实得: {ws}"
    assert "jiufa.example.com" in hit[0] and "www.jiufa.example.com" in hit[0], \
        f"告警须显示**归一化后**的生效值(证明 norm_host 确被调用): {hit[0]}"


def test_wildcard_is_a_hard_error_not_a_warning():
    """文档与配置描述都承诺「配了通配符会被直接报错」—— 兑现它。
    静默失配是这里最坏的结局:运维以为 *.example.com 生效了,实际全站按镜像。"""
    errs, _ = _warns(**{"userauth.jf_direct_hosts": "*.example.com"})
    assert any("通配符" in e for e in errs), f"通配符必须是 error 而非 warning: {errs}"
