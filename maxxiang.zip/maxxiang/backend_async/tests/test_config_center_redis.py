"""
test_config_center_redis.py — 热更协议集成测试(需 Redis;缺则整文件跳过)
================================================================================
端到端核对方案 §3.4 协议(PG 以内存 FakeDB 顶替,聚焦 Redis 分发面):
  · commit → PUBLISH cfg:events → run_agent 拉取套用 → settings 生效 + 钩子触发;
  · 心跳回执:cfg:hb:{instance} 携 applied_rev(管理页收敛数据源);
  · 对账自愈:不发广播只落版本,下一心跳周期实例自拉补齐(丢消息兜底);
  · 敏感分发:快照存占位 __redis__,真值走 cfg:sensitive,套用后进程拿到明文;
  · TokenBucket.update:限流参数热更即刻生效(P0 微改)。
"""
from __future__ import annotations

import asyncio
import json
import os

import pytest

from app import config_center as cc
from app import config_registry as reg
from app.ratelimit import TokenBucket
from app.settings import Settings

REDIS_URL = os.environ.get("STA_TEST_REDIS_URL", "redis://localhost:6379/15")


async def _make_redis():
    try:
        import redis.asyncio as aioredis
    except Exception:
        return None
    try:
        r = aioredis.from_url(REDIS_URL, encoding="utf-8", decode_responses=True)
        await asyncio.wait_for(r.ping(), timeout=1.0)
        return r
    except Exception:
        return None


class _Bus:                       # run_agent 只依赖 .r
    def __init__(self, r):
        self.r = r


class FakeDB:
    """内存版 config_revisions(接口与 db.DB 对齐,聚焦 Redis 分发面)。"""

    def __init__(self):
        self.rows = []            # [(rev, snapshot, diff)]

    async def cfg_latest(self):
        if not self.rows:
            return 0, {}
        rev, snap, _ = self.rows[-1]
        return rev, dict(snap)

    async def cfg_latest_rev(self):
        return self.rows[-1][0] if self.rows else 0

    async def cfg_insert(self, ts_ms, author, note, snapshot, diff):
        rev = (self.rows[-1][0] + 1) if self.rows else 1
        self.rows.append((rev, dict(snapshot), dict(diff)))
        return rev

    async def cfg_get(self, rev):
        for r, s, d in self.rows:
            if r == rev:
                return {"rev": r, "snapshot": s, "diff": d}
        return None

    async def cfg_diff_keys_since(self, rev):
        keys = set()
        for r, _s, d in self.rows:
            if r > rev:
                keys.update(d.keys())
        return keys


@pytest.fixture
async def redis_client():
    r = await _make_redis()
    if r is None:
        pytest.skip(f"Redis 不可用({REDIS_URL}) — 跳过配置中枢集成测试")
    yield r
    for pat in ("cfg:hb:*",):
        keys = await r.keys(pat)
        if keys:
            await r.delete(*keys)
    await r.delete(cc.K_SENSITIVE, "rl:test:cc")
    await r.aclose()


@pytest.fixture
def sset():
    cc._reset_base_for_tests()
    st = Settings()
    st.prediction = {"train_window_hours": 24.0}
    cc.capture_base(st)
    yield st
    cc._reset_base_for_tests()


async def test_publish_apply_heartbeat_and_sensitive(redis_client, sset, monkeypatch):
    monkeypatch.setattr(cc, "HB_INTERVAL_S", 1)
    bus, db = _Bus(redis_client), FakeDB()
    fired = []
    hooks = {"rl_upstream": lambda: fired.append("rl"),
             "auth": lambda: fired.append("auth")}
    state = cc.CenterState(role="test")
    running = [True]
    agent = asyncio.create_task(cc.run_agent(
        settings=sset, role="test", bus=bus, db=db, hooks=hooks, state=state,
        running=lambda: running[0]))
    try:
        await asyncio.sleep(0.3)              # 让订阅就绪
        # ① 普通项 + 敏感项一并 commit(敏感真值应走 Redis,快照只存占位)
        rev = await cc.commit(db, bus,
                              changes={"ratelimit.upstream_rps": 250,
                                       "auth.ticket": "fresh-plain-ticket-xyz"},
                              author="t", note="集成")
        assert rev == 1
        _r, snap = await db.cfg_latest()
        assert snap["auth.ticket"] == reg.SENTINEL_REDIS
        assert await redis_client.hget(cc.K_SENSITIVE, "auth.ticket") \
            == "fresh-plain-ticket-xyz"
        # ② 广播 → 套用 → 心跳回执(秒级)
        for _ in range(40):
            if state.applied_rev >= 1 and sset.ratelimit.upstream_rps == 250:
                break
            await asyncio.sleep(0.1)
        assert sset.ratelimit.upstream_rps == 250.0
        assert sset.auth.ticket == "fresh-plain-ticket-xyz"      # 敏感明文到进程
        assert "rl" in fired and "auth" in fired
        hb = await redis_client.hgetall(cc.K_HB_PREFIX + state.instance)
        assert int(hb["applied_rev"]) == 1 and hb["role"] == "test"
        # ③ 对账自愈:只落版本、**不**发广播 → 心跳周期内自拉补齐
        await db.cfg_insert(0, "t", "silent",
                            {"ratelimit.upstream_rps": 250,
                             "auth.ticket": reg.SENTINEL_REDIS,
                             "scheduler.claim_batch": 321}, {"scheduler.claim_batch": {}})
        for _ in range(40):
            if state.applied_rev >= 2:
                break
            await asyncio.sleep(0.1)
        assert state.applied_rev == 2 and sset.scheduler.claim_batch == 321
    finally:
        running[0] = False
        agent.cancel()
        with pytest.raises(asyncio.CancelledError):
            await agent


async def test_token_bucket_update_takes_effect(redis_client):
    tb = TokenBucket(redis_client, "rl:test:cc", rate=0.0, burst=1.0)
    ok, _ = await tb.try_acquire()
    assert ok, "rate<=0 应始终放行"
    tb.update(1.0, 1.0)                        # 热更:1 QPS · 桶容量 1
    ok1, _ = await tb.try_acquire()
    ok2, wait = await tb.try_acquire()
    assert ok1 and not ok2 and wait > 0, "热更后应立即按新参数限流"
    tb.update(0.0, 1.0)
    ok3, _ = await tb.try_acquire()
    assert ok3, "回到 0 应恢复不限流"
