# -*- coding: utf-8 -*-
"""
test_cadence_governor.py — 冷位节拍器(《灵机推演冷位节拍器优化方案.md》)回归钉
================================================================================
背景:showcase 风格的冷位数 k 逐局由「近窗热度」自参照分位判定,信号长记忆
(M2 窗 60 局 / EWMA 半衰 30 局)+ 慢阈值 + khyst 单边死区 ⇒ **边际份额达标但
时间结构成串**。真机三房 5,008 已结算局实测:k=3 逐局黏滞率 50~63%(独立假设
下应 ≈15%)、k≥3 最长连串 21/23/**60** 局、任意 20 局窗内三冷可占满 20 局、
同一冷门组合最长复读 25 局 —— 即用户投诉的「一直推 3 个冷门,久推不放」。

节拍器只后置整形**展示的 k**(信号/阈值学习一律不动,`_kd` 照常吃原始 exc),
以 cadence_governor 总开关收束五机制(预算桶/连串封顶/软促发/硬保底/khyst
单边化),关闭时与现行 showcase **逐局字节级等价**(改造期全量回放逐字段全同,
离线门禁见 window_audit/replay_harness.py)。

本文件是可长期跑的仓内钉(不依赖 PG/Redis/真机 DB):
  ① 配置三方一致:引擎 dataclass ⇄ config.yaml ⇄ config_registry 同键同值;
  ② 开关关 = 全刻度失效(cg_* 拨到极端也不改变输出)—— 等价门禁的仓内代理;
  ③ 硬不变量:令牌桶守恒给出的三条**与数据无关**的上界(连串/窗密度/旱段),
     外加「桶恒 ≥ 0」这一守恒前提本身,以及热身门(无阈值历史时不促发);
  ④ 状态往返 + 向后兼容:cgb3/cgb2/cgr3/cgr2 经 kv JSON 逐字段还原;旧状态
     (无新字段)直接可用;
  ⑤ 指纹复用:同一 seq 重复 predict 不重复扣预算(web 侧按需重算安全)。
"""
from __future__ import annotations

import json
import math
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "backend_async"))
os.environ.setdefault("STA_ENGINE_DIR", str(ROOT / "jiufa_data"))

from app.predictor_bridge import PredictorBridge  # noqa: E402
import spell_tamer_monitor as E  # noqa: E402
from app import config_registry as reg  # noqa: E402

# ── 交付守卫(体例同 tests/test_hot_rotate.py)────────────────────────────────
# ⚠ 4.9.7 复查更正:本段原写「实证:本仓库随附的引擎 PredictionConfig **没有**
#   cadence_governor 及任何 cg_* 字段……冷位节拍器这套特性并未落进引擎」——
#   **该前提已不成立**。实测本包引擎 dataclass 含 cadence_governor(缺省 1)与全部
#   7 个 cg_*,explore_state 也确实落盘 cgb3/cgb2/cgr3/cgr2,下方硬不变量钉全部通过。
#   即这道 skip 当前**恒不触发**,保留它只为「特性被回退时不刷假红」。
# 原始理由(仍适用于特性缺席的分发包):缺字段时本文件会直接 5 红,而红的原因是
# "特性不存在"不是"实现有回归";红灯一多就会被当成噪声整体忽略,连带淹掉真正的
# 回归信号。与 test_hot_rotate.py 同一判断:宁可显式 skip,也不要用假红或假绿掩盖事实。
# 一旦节拍器落进引擎,本 skip 自动失效,全部钉子照常生效。
_CG_MISSING = [k for k in ("cadence_governor",)
               if k not in E.PredictionConfig.__dataclass_fields__]
pytestmark = pytest.mark.skipif(
    bool(_CG_MISSING),
    reason=("引擎不含冷位节拍器字段 %s;继续跑只会测到未改造的 showcase 分支"
            "(本包实测直接 5 红)。特性落地后本 skip 自动失效。" % _CG_MISSING))
import yaml  # noqa: E402

# 回放定稿刻度(与引擎 dataclass / config.yaml / config_registry 四方同源)。
# ⚠ 4.9.7 复查更正:此处原注写「cadence_governor 引擎缺省**特意为 0**,裸引擎嵌入方
#   拿到的是『未开刀』的安全姿态,由部署配置显式开启」—— 该说法与下方
#   test_config_three_way_consistency 里 `assert int(c.cadence_governor) == 1
#   「裸引擎缺省必须是开」` **直接矛盾**,且与实际引擎(dataclass 缺省 = 1)不符。
#   4.9.7 起本键与 anti_stubborn / showcase_rotate / repeat_guard 同批翻面,统一取
#   「裸引擎缺省 == 部署刻度」这条可验证的不变量。原版姿态仍可完整复现:三层同批置 0
#   **且 showcase_kdist 同批改回 "45,30,15"**(见 test_off_switch_makes_all_dials_inert
#   与 predictor_bridge._warn_cadence_pairing_mismatch)。
FINAL_DIALS = {
    "cg_run3": 2, "cg_run2": 6, "cg_cap3": 1.9, "cg_cap2": 3.2,
    "cg_force3": 1.5, "cg_force2": 1.8, "cg_rfloor": 0.30,
}
CG_KEYS = ("cadence_governor",) + tuple(FINAL_DIALS)

BASE_CFG = {  # 生产口径(config.yaml prediction 段的引擎相关子集)
    "predict_mode": "adaptive", "adaptive_lambda": 0.3,
    "explore_style": "showcase", "explore_patrol": 35,
    "showcase_q": 0.78, "showcase_kdist": "45,30,15",
    "seat_order": "recency", "hedge_eta": 0.15, "hedge_mix": 0.02,
    "anti_stubborn": 1, "as_khyst": 0.05,
}
COLD5 = (3, 4, 5, 6, 9)
# 阈值历史 _kd 攒满 60 条所需的局数(= 引擎里 `len(hh) >= 60` 那道门)。
# 之前的局数走 fallback 阈值,节拍器按设计只治理不促发 —— 见 ③(h)。
WARM_ROUNDS = 60

# 冷门爆发序列:5/6 高频复现(真机里正是它们持续喂养 M2/M3 热度信号,
# 把引擎按在高 k 上不放)。周期长度与 3 互质,避免与任何 3 拍结构共振。
BURST = (5, 6, 5, 3, 5, 6, 9, 5, 6, 4, 5, 6, 5, 1, 6, 5, 3, 6, 5, 7)
WARM = ([1, 2, 7, 8, 5, 6, 2, 7, 5, 8, 6, 1, 5, 6, 8, 5, 3, 6, 5, 9] * 4)[:72]


def _drive(cfg_extra, n_rounds=160):
    """微型因果驱动器:predict → 按冷门爆发序列落地出怪 → 结算 → 再 predict。
    kv 逐局经 bridge 往返(与 worker._settle_and_predict 同语义,零随机源)。"""
    bridge = PredictorBridge({**BASE_CFG, **cfg_extra}, {})
    kv, seq, recs = {}, list(WARM), []
    prev = None
    for i in range(n_rounds):
        res, dirty = bridge.run_prediction("t", seq, kv)
        kv.update(dirty)
        four = tuple(res["main"]) + tuple(res["guard"])
        st = json.loads(kv.get("explore_state") or "{}")
        recs.append({"four": four, "k": sum(1 for c in four if c in COLD5),
                     "why": ((res.get("explore") or {}).get("why") or ""), "st": st})
        nxt = BURST[i % len(BURST)]
        if prev is not None:
            kv.update(bridge.update_after_settle(
                "t", {"models": prev["models"], "ens": prev["ens"]}, nxt, kv))
        prev = res
        seq.append(nxt)
    return recs, kv, bridge


def _maxrun(ks, lo):
    best = cur = 0
    for k in ks:
        cur = cur + 1 if k >= lo else 0
        best = max(best, cur)
    return best


def _maxwin(ks, W, lo):
    best = s = 0
    for i, k in enumerate(ks):
        s += 1 if k >= lo else 0
        if i >= W:
            s -= 1 if ks[i - W] >= lo else 0
        best = max(best, s)
    return best


def _maxgap(ks, lo):
    best = cur = 0
    for k in ks:
        cur = 0 if k >= lo else cur + 1
        best = max(best, cur)
    return best


# ── ① 配置三方一致 ────────────────────────────────────────────────────────────
def test_config_three_way_consistency():
    fields = E.PredictionConfig.__dataclass_fields__
    for k in CG_KEYS:
        assert k in fields, f"引擎缺字段 {k}"
    c = E.PredictionConfig()
    # 4.9.7 翻面,与 anti_stubborn / showcase_rotate / repeat_guard 同一口径:
    # 裸引擎缺省 == config.yaml 部署刻度。此前那条「裸引擎缺省=改造前逐字节等价」
    # 的纪律,在 explore_style 缺省由 ceiling_adaptive 改为 showcase 时就已不可能
    # 成立(实测只回退开关、风格仍 showcase 时,与真原版仅 28/300 局相同),
    # 故统一取「等于部署刻度」这条可验证的不变量,由 tests/test_config_registry.py::
    # test_prediction_defaults_match_engine_dataclass_except_documented_tiering 钉守。
    # 原版姿态仍可完整复现:显式置 0 即可(test_off_switch_makes_all_dials_inert 守着)。
    assert int(c.cadence_governor) == 1, "裸引擎缺省必须是开(4.9.7 起,与部署刻度一致)"
    for k, v in FINAL_DIALS.items():
        assert float(getattr(c, k)) == pytest.approx(float(v)), f"引擎缺省 {k} 偏离定稿刻度"

    raw = yaml.safe_load(open(ROOT / "backend_async" / "config.yaml", encoding="utf-8"))
    pred = raw["prediction"]
    # 4.9.7 定稿:部署侧已确认默认开启,本断言恢复为真契约。
    # 依据(三房 36,182 已结算局,开 vs 关):k=3 黏滞率 40.54% → 0.02%、
    # k>=3 最长连串 29 → 2 局、20 局窗最大三冷 20 → 4;总命中 −0.10pp、
    # 倍率加权/注 +0.0086。即节奏问题彻底解决而代价可忽略。
    # 回滚 = 三层(引擎缺省 / 注册表 / config.yaml)同批改回 false/0 并回改本断言;
    # 关态与未改造的 showcase 逐局四码 12064/12064 全同(已实测)。
    # ⚠ 仍需知悉:cg_rfloor 一键的语义在本包内为**推断**(原方案文档
    #   《灵机推演冷位节拍器优化方案.md》缺失、本文件对该键零断言)。其余四个机制
    #   均由本文件直接或间接钉死。若日后找回该文档,请优先以它为准核对硬保底那段。
    assert bool(pred["cadence_governor"]) is True, "部署配置应显式开启冷位节拍器"
    for k, v in FINAL_DIALS.items():
        assert float(pred[k]) == pytest.approx(float(v)), f"config.yaml {k} 偏离定稿刻度"

    for k in CG_KEYS:
        assert k in reg.PREDICTION_KEYS
        f = reg.REGISTRY[f"prediction.{k}"]
        assert f.danger and f.hook == "bridge", f"{k} 须与其余 prediction 键同热更语义"
        if k in FINAL_DIALS:
            assert float(f.default) == pytest.approx(float(FINAL_DIALS[k])), \
                f"注册表默认 {k} 偏离定稿刻度"

    # ── 4.9.7 补:showcase_kdist 与本开关是**成对**的,三层必须同值 ──────────────
    # 引擎注释的纪律要点(措辞随 4.9.10 微调,数字为 4.9.7 当时刻度 45,31.5,13.5 实测):
    # 回滚需两键同批,「只关开关」中间态与改造前基线仅 5,162/12,064 局相同,
    # 两键同批改回才是 12,064/12,064 全同。开态刻度由三层 + 桥护栏共四处持有,
    # 任一处漂了就会让 predictor_bridge._warn_cadence_pairing_mismatch 误报或漏报。
    from app.predictor_bridge import PredictorBridge as _PB
    kd_engine = str(getattr(c, "showcase_kdist", ""))
    kd_reg = str(reg.REGISTRY["prediction.showcase_kdist"].default)
    kd_yaml = str(pred["showcase_kdist"])
    assert kd_engine == kd_reg == kd_yaml, (
        f"showcase_kdist 三层漂移: 引擎={kd_engine!r} 注册表={kd_reg!r} yaml={kd_yaml!r}")
    assert _PB._effective_kdist(_PB._CADENCE_KDIST_ON)[0] == \
        _PB._effective_kdist(kd_yaml)[0], (
        f"桥护栏的 ON 侧常量 {_PB._CADENCE_KDIST_ON!r} 与现行三层值 {kd_yaml!r} 不符 —— "
        "改了 kdist 必须同批改 predictor_bridge._CADENCE_KDIST_ON,否则配对护栏会误报")
    assert _PB._effective_kdist(_PB._CADENCE_KDIST_OFF)[0] != \
        _PB._effective_kdist(kd_yaml)[0], \
        "ON/OFF 两侧刻度不得相同,否则配对护栏永远判不出中间态"
    # 4.9.7 复查(输入模糊测试打出的洞):引擎对写坏的 kdist 是**静默兜底到 45,30,15**
    # —— 恰好是关态刻度。护栏必须比对**生效值**,否则「开 + 写坏的 kdist」会绕过它。
    for bad in (None, "", "abc", "45", "45,30", "45,,15", [45, 30, 15], 45):
        eff, fell = _PB._effective_kdist(bad)
        assert fell and eff == "45,30,15", (
            f"kdist={bad!r} 的兜底判定与引擎不一致(引擎实测回落到 45,30,15,"
            f"本处得到 {eff!r} fellback={fell}) —— 两处兜底必须同语义")
    assert _PB._effective_kdist("45, 31.5 , 13.5") == ("45,31.5,13.5", False), \
        "带空格的合法写法不得被判成兜底"


# ── ② 开关关 = 全刻度失效(等价门禁的仓内代理) ───────────────────────────────
def test_off_switch_makes_all_dials_inert():
    wild = {"cg_run3": 1, "cg_run2": 1, "cg_cap3": 9.0, "cg_cap2": 9.0,
            "cg_force3": 0.0, "cg_force2": 0.0, "cg_rfloor": 1.0}
    a, _, _ = _drive({"cadence_governor": 0}, n_rounds=80)
    b, _, _ = _drive({"cadence_governor": 0, **wild}, n_rounds=80)
    assert [(r["four"], r["why"]) for r in a] == [(r["four"], r["why"]) for r in b], \
        "cadence_governor=0 时任何 cg_* 刻度都不得改变输出(含 why 落款)"
    # 且确定性:开/关两态同配置再跑一遍逐局全同 —— 多 worker 流转 / 补算的前提。
    c, _, _ = _drive({"cadence_governor": 0}, n_rounds=80)
    assert [(r["four"], r["why"]) for r in a] == [(r["four"], r["why"]) for r in c]
    d1, _, _ = _drive({"cadence_governor": 1}, n_rounds=80)
    d2, _, _ = _drive({"cadence_governor": 1}, n_rounds=80)
    assert [(r["four"], r["why"]) for r in d1] == [(r["four"], r["why"]) for r in d2]
    # 开态必须**真的**改变了节奏(否则本钉会因"两边都没治理"而假绿)
    assert [r["four"] for r in a] != [r["four"] for r in d1], \
        "冷门爆发序列上,节拍器开/关必须产生可见差异"


# ── ③ 硬不变量:令牌桶守恒给出的与数据无关的上界 ─────────────────────────────
def test_hard_invariants_on_cold_burst():
    run3, run2 = 2, 6
    cap3, cap2 = 1.9, 3.2
    rate3, rate2 = 0.15, 0.45          # = showcase_kdist 的 cums[2] / cums[1]
    recs, _, _ = _drive({"cadence_governor": 1, "cg_run3": run3, "cg_run2": run2,
                         "cg_cap3": cap3, "cg_cap2": cap2}, n_rounds=200)
    ks = [r["k"] for r in recs]
    assert max(ks) >= 3 and ks.count(3) > 0, "冷门爆发序列上必须出现三冷局(否则本钉空转)"

    # (a) 连串封顶 —— 用户投诉的直接指标
    assert _maxrun(ks, 3) <= run3, f"三冷连串越顶: {_maxrun(ks, 3)} > {run3}"
    assert _maxrun(ks, 2) <= run2, f"双冷连串越顶: {_maxrun(ks, 2)} > {run2}"

    # (b) 局部密度:任意连续 W 局内 k=3 局数 ≤ rate3·W + cap3(桶守恒直接给出)
    for W in (10, 20, 50, 100):
        assert _maxwin(ks, W, 3) <= math.floor(rate3 * W + cap3), \
            f"{W} 局窗三冷密度越顶: {_maxwin(ks, W, 3)} > {math.floor(rate3 * W + cap3)}"
        assert _maxwin(ks, W, 2) <= math.floor(rate2 * W + cap2), \
            f"{W} 局窗双冷密度越顶: {_maxwin(ks, W, 2)} > {math.floor(rate2 * W + cap2)}"

    # (c) 旱段(份额守恒的另一端)。可证上界 = 桶蓄满所需局数
    #     ⌈cap3/rate3⌉ + 硬兜底被 k≥2 档阻塞的最坏延迟(_b2 回到 1.0 需 ⌈1/rate2⌉ 局,
    #     _ok2 因 cg_run2 封顶失效至多 1 局)。**不是** ⌈cap3/rate3⌉ —— 那个数
    #     忽略了 k=3 促发额外要求 _b2≥1.0 且 _ok2,会做出一个偶发假红的钉子。
    #     只在**转正后**成立:热身期(阈值历史 <60 局)按设计不促发,见 (h)。
    gap_bound = math.ceil(cap3 / rate3) + math.ceil(1.0 / rate2) + 1
    assert _maxgap(ks[WARM_ROUNDS:], 3) <= gap_bound, \
        f"转正后三冷旱段越顶: {_maxgap(ks[WARM_ROUNDS:], 3)} > {gap_bound}"

    # (d) 守恒前提本身:两只桶逐局恒在 [0, cap] 内(负桶=份额被透支,上界失效)
    for i, r in enumerate(recs):
        st = r["st"]
        if "cgb3" not in st:
            continue
        assert -1e-9 <= st["cgb3"] <= cap3 + 1e-9, f"idx={i} 三冷桶越界: {st['cgb3']}"
        assert -1e-9 <= st["cgb2"] <= cap2 + 1e-9, f"idx={i} 双冷桶越界: {st['cgb2']}"
        assert 0 <= st["cgr3"] <= run3 and 0 <= st["cgr2"] <= run2

    # (e) 诚实自解释:治理动作必须落款进 why(推演卡可见),不冒充"信号占优"
    assert any("节奏治理" in r["why"] or "节奏排播" in r["why"] for r in recs), \
        "治理动作必须在 why 留下落款"

    # (f) cg_run3=1(更保守档)照样成立 —— 旋钮不是摆设
    recs1, _, _ = _drive({"cadence_governor": 1, "cg_run3": 1}, n_rounds=160)
    assert _maxrun([r["k"] for r in recs1], 3) <= 1, "cg_run3=1 必须做到绝不连推三冷"

    # (g) 非空转自证:同一序列**关闭**治理时必须至少越一条界。否则说明该序列
    #     根本没把引擎逼进成串态,上面所有上界都是废话 —— 这条对照把它钉死。
    off_recs, _, _ = _drive({"cadence_governor": 0}, n_rounds=200)
    off = [r["k"] for r in off_recs]
    assert (_maxwin(off, 20, 3) > math.floor(rate3 * 20 + cap3)
            or _maxrun(off, 2) > run2
            or _maxgap(off[WARM_ROUNDS:], 3) > gap_bound), \
        "关闭治理时应至少越一条上界,否则本钉在当前序列上空转"

    # (h) 热身门:阈值历史攒够 60 局前只治理、不促发 —— 引擎自带的热身 fallback
    #     阈值(0/0.35/0.75)本就刻意保守,无证据时不该由预算硬推冷门上台。
    #     促发两路都要求 `_r* is not None` ⇔ len(_kd) ≥ 60,故这是机制保证。
    #     (真机实测:不设此门时热身 60 局命中率 70.0%→59.4%。)
    assert not any("节奏排播" in r["why"] for r in recs[:WARM_ROUNDS]), \
        "热身期不得出现促发排播(硬兜底同样受热身门约束)"
    assert max(ks[:WARM_ROUNDS]) <= max(off[:WARM_ROUNDS]), \
        "热身期治理只许压低 k,不许抬高"


# ── ③b cg_rfloor 必须是**活**刻度(4.9.7 新增钉子)────────────────────────────
def test_rfloor_is_a_live_dial_and_monotone():
    """cg_rfloor 拨动必须真的改变输出,且方向单调(越大越保守)。

    为什么要专门钉这一条:本文件对 cg_rfloor **零断言**,方案文档
    《灵机推演冷位节拍器优化方案.md》又不在本包内。4.9.7 首版按「硬保底触发阈」
    实现它,结果实测是**死参数**(0.0→2.0 逐局四码 0/3970 不同)—— 与本仓库反复
    警告的 hot_rotate / showcase_q 同款病,只是换了个入口。现行实现改作
    「动用预算须保留的储备」(花 1 个令牌要求桶里先有 1.0 + rfloor)。

    本钉子守两件事:①它不许再退化成死参数;②方向必须是「越大越保守」。
    若日后找回方案文档并按原义重写 cg_rfloor,本测试会立刻红 —— 那正是它的用处:
    让这处**已知偏离**在改动时无法被静默略过,而不是埋在注释里等人翻。
    """
    def _k3rate(rf):
        recs, _, _ = _drive({"cadence_governor": 1, "cg_rfloor": rf}, n_rounds=200)
        ks = [r["k"] for r in recs]
        return sum(1 for k in ks if k >= 3) / len(ks), [r["four"] for r in recs]

    r0, f0 = _k3rate(0.0)
    r3, f3 = _k3rate(0.3)
    r9, f9 = _k3rate(0.9)
    assert f0 != f3, "cg_rfloor 0.0 vs 0.3 输出全同 —— 它退化成死参数了"
    assert f3 != f9, "cg_rfloor 0.3 vs 0.9 输出全同 —— 它退化成死参数了"
    assert r0 >= r3 >= r9, (
        f"cg_rfloor 必须单调收紧(越大越保守),实测 k>=3 占比 "
        f"{r0:.4f} / {r3:.4f} / {r9:.4f}")


# ── ④ 状态往返 + 向后兼容 ────────────────────────────────────────────────────
def test_state_roundtrip_and_backward_compat():
    recs, kv, _ = _drive({"cadence_governor": 1}, n_rounds=60)
    st = recs[-1]["st"]
    for k in ("cgb3", "cgb2", "cgr3", "cgr2"):
        assert k in st, f"explore_state 缺 {k}"
    assert json.loads(json.dumps(st))["cgb3"] == st["cgb3"], "cgb3 经 JSON 往返逐字段还原"
    assert isinstance(st["cgr3"], int) and isinstance(st["cgr2"], int)

    seq = list(WARM) + [BURST[i % len(BURST)] for i in range(len(recs))]
    # 旧状态(剥掉新字段)→ 新引擎:开关关时与未剥离输出全同(向后兼容)
    stripped = {k: v for k, v in st.items() if k not in ("cgb3", "cgb2", "cgr3", "cgr2")}
    kv_old = dict(kv)
    kv_old["explore_state"] = json.dumps(stripped)
    off = PredictorBridge({**BASE_CFG, "cadence_governor": 0}, {})
    r_new, _ = off.run_prediction("t", seq, dict(kv))
    r_old, _ = off.run_prediction("t", seq, kv_old)
    assert (r_new["main"], r_new["guard"]) == (r_old["main"], r_old["guard"]), \
        "开关关时,新旧两种状态形态必须给出同一预测"
    on = PredictorBridge({**BASE_CFG, "cadence_governor": 1}, {})
    r_on, _ = on.run_prediction("t", seq, kv_old)
    assert len(set(list(r_on["main"]) + list(r_on["guard"]))) == 4, \
        "旧状态喂开着的新引擎必须正常出四码(缺失字段走缺省 1.0/0)"
    # 状态确实在 kv 里逐局流转(多 worker 无常驻内存的前提)
    st2 = json.loads(off.run_prediction("t", seq + [5], dict(kv))[1]["explore_state"])
    assert "cgb3" in st2


# ── ⑤ 指纹复用:同 seq 重复 predict 不重复扣预算 ──────────────────────────────
def test_same_seq_repredict_does_not_double_spend():
    recs, kv, bridge = _drive({"cadence_governor": 1}, n_rounds=40)
    seq = list(WARM) + [BURST[i % len(BURST)] for i in range(len(recs))]
    shim_kv = dict(kv)
    r1, d1 = bridge.run_prediction("t", seq, shim_kv)
    shim_kv.update(d1)
    st1 = json.loads(shim_kv["explore_state"])
    r2, d2 = bridge.run_prediction("t", seq, shim_kv)      # 同一局按需重算
    shim_kv.update(d2)
    st2 = json.loads(shim_kv["explore_state"])
    assert (r1["main"], r1["guard"]) == (r2["main"], r2["guard"]), "同局重算必须同答案"
    assert (st1["cgb3"], st1["cgb2"], st1["cgr3"], st1["cgr2"]) == \
           (st2["cgb3"], st2["cgb2"], st2["cgr3"], st2["cgr2"]), \
        "同局重算不得重复扣预算/重复计连串(指纹复用生效)"


# ── ⑥ 持久化体积上界(4.9.7 复查新增)──────────────────────────────────────────
def test_explore_state_is_bounded_and_within_capacity_budget():
    """showcase 稳态下 explore_state 必须**有界**,且不超过容量预算写下的上限。

    4.9.7 复查发现的记录缺口:默认风格由 frontier 改回 showcase,把每房持久化状态
    从 1,593 B 抬到 **17.3 KB(×10.9)** —— 每局全量写回 ⇒ PG 写入同比放大约 11 倍
    (8600 房 / 50.001s 外推 ≈3.0 MB/s,原 0.27 MB/s)。这条代价此前**任何文档都没写**,
    根 README 甚至记着不可复现的「showcase 3804 B」(实测那是约 40~50 局的未到平台值,
    取样过早)。容量规划照它做会低估 4.5 倍。

    大头是 `zh`(≈10.3 KB)与 `kd`(≈5.8 KB),二者都是
    `deque(maxlen = max(60, explore_calib))` ⇒ 有界。本钉守两件事:
      ① **有界**:跑满 2×calib 局后体积不再增长(deque 被换成 list 之类的回归会当场红);
      ② **预算**:平台值 <= 24 KB。该上限按 explore_calib=240 的解析上界留约 1.4× 余量
         (9 条 zh + 3 条 kd,每条 240 个 round(x,4) 的浮点串)。谁把 explore_calib 调大、
         或给状态加新的按局累加字段,都会在这里被拦下来 —— 那正是要人**先算一遍容量**
         再改的时刻,而不是上线后在 PG 写入曲线上发现。
    """
    import json as _json
    cal = max(60, int(BASE_CFG.get("explore_calib", 240)))
    recs_a, kv_a, _ = _drive({}, n_rounds=cal + 20)
    recs_b, kv_b, _ = _drive({}, n_rounds=2 * cal + 20)
    sa, sb = len(kv_a.get("explore_state", "")), len(kv_b.get("explore_state", ""))
    assert sb <= sa * 1.10 + 512, (
        f"explore_state 仍在增长:{cal + 20} 局 {sa} B → {2 * cal + 20} 局 {sb} B。"
        "按局累加的字段必须有 maxlen 上界,否则每房状态会无限膨胀")
    assert sb <= 24 * 1024, (
        f"explore_state 稳态 {sb} B 超出容量预算 24 KB(explore_calib={cal})。"
        "改大 explore_calib 或新增按局累加字段前,请先按 8600 房重算 PG 写入量"
        "并同批更新 config.yaml explore_style 段的代价表")
    st = _json.loads(kv_b["explore_state"])
    big = sorted(((len(_json.dumps(v, ensure_ascii=False)), k) for k, v in st.items()),
                 reverse=True)[:2]
    assert {k for _, k in big} <= {"zh", "kd"}, (
        f"体积大头已不是 zh/kd 而是 {[k for _, k in big]} —— 状态结构变了,"
        "请复核上面那份代价表是否仍成立")
