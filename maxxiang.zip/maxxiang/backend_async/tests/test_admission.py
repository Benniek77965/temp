"""
test_admission.py — 批量准入控制器集成测试(真实 Redis;mock 归一/库)
================================================================================
验证「同时添加数千房」这条路径的正确性与削峰性质:
  · 去重 + 非法过滤;短号→真实号后按真实号去重(多短号映射同房只算一次);
  · definitive 入名录 + 起抓任务铺开;pending 进挂起集,不开抓;
  · 首抓任务在 warmup 窗口内均匀铺开(而非全排同一毫秒)——消除重排风暴;
  · 房→任务反向索引随之建立(scheduled_rooms 与入册房一致)。

Redis 用 STA_TEST_REDIS_URL(默认 redis://127.0.0.1:6379/15);缺失则跳过。
"""
import asyncio
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.admission import admit_rooms, _normalize            # noqa: E402
from app.redis_bus import K_SCHED, RedisBus, task_mainpage    # noqa: E402
from app.settings import AdmissionCfg                         # noqa: E402

REDIS_URL = os.environ.get("STA_TEST_REDIS_URL", "redis://127.0.0.1:6379/15")


def _redis_available() -> bool:
    try:
        import redis
        redis.from_url(REDIS_URL).ping()
        return True
    except Exception:
        return False


pytestmark = pytest.mark.skipif(not _redis_available(),
                                reason="需要 Redis(设 STA_TEST_REDIS_URL)")


class MockStar:
    """可控归一:mapping 命中→真实号(definitive);否则 pending。带一点延迟模拟网络。"""
    def __init__(self, mapping, pending=frozenset(), latency=0.0):
        self.mapping = mapping
        self.pending = set(pending)
        self.latency = latency
        self.calls = 0
        self.peak = 0
        self._inflight = 0

    async def canon(self, alias):
        self.calls += 1
        self._inflight += 1
        self.peak = max(self.peak, self._inflight)
        if self.latency:
            await asyncio.sleep(self.latency)
        self._inflight -= 1
        if alias in self.pending:
            return alias, False
        return self.mapping.get(alias, alias), True


class MockDB:
    def __init__(self):
        self.room_rows = []
    async def upsert_rooms_bulk(self, rows, batch_size=500):
        self.room_rows.extend(rows)


def _cfg(**kw):
    c = AdmissionCfg()
    for k, v in kw.items():
        setattr(c, k, v)
    return c


def test_normalize_dedup_and_filter():
    got = _normalize(["321", " 321 ", "abc", "1", "2678075", "2678075", "99999999999999"])
    # 去重(321 一次)、去非法(abc、1 太短、超 12 位)、保序
    assert got == ["321", "2678075"]


@pytest.mark.asyncio
async def test_bulk_admit_end_to_end():
    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()
    db = MockDB()
    # 3000 短号 → 各自真实号;另 500 个注定归一失败(pending);再混入 200 个重复
    mapping = {str(1000 + i): str(9000000 + i) for i in range(3000)}
    pending = {str(1000 + i) for i in range(3000, 3500)}   # 这 500 个走 pending
    star = MockStar(mapping | {p: p for p in pending}, pending=pending, latency=0.002)
    rooms = [str(1000 + i) for i in range(3500)]           # 3000 definitive + 500 pending
    rooms += rooms[:200]                                    # 200 重复
    cfg = _cfg(canon_concurrency=64, warmup_window_ms=20000, batch_size=500)

    res = await admit_rooms(rooms, bus=bus, db=db, star=star, cfg=cfg, do_canon=True)

    assert res["requested"] == 3700
    assert res["deduped"] == 3500          # 去重后 3500 个唯一房号
    assert res["added"] == 3000            # definitive
    assert res["pending"] == 500
    # 名录:入册房数 == added
    active = await bus.active_rooms()
    assert len(active) == 3000
    # 挂起集:pending 数正确
    assert len(await bus.pending_rooms()) == 500
    # 起抓任务:每个入册房一个 mp 任务,且铺开在 warmup 窗口内(非全同一毫秒)
    assert await bus.r.zcard(K_SCHED) == 3000
    sched_rooms = await bus.scheduled_rooms()
    assert sched_rooms == set(active)      # 反向索引与名录一致
    scores = await bus.r.zrange(K_SCHED, 0, -1, withscores=True)
    span = max(s for _, s in scores) - min(s for _, s in scores)
    assert span >= cfg.warmup_window_ms * 0.9   # 确实铺开
    # 无任何毫秒堆积过半
    from collections import Counter
    hottest = Counter(int(s) for _, s in scores).most_common(1)[0][1]
    assert hottest < 3000 * 0.1
    # 库写入:definitive(active) + pending(pending) 都落库
    active_rows = [r for r in db.room_rows if r[2] is True]
    pending_rows = [r for r in db.room_rows if r[3] is True]
    assert len(active_rows) == 3000
    assert len(pending_rows) == 500
    await bus.close()


@pytest.mark.asyncio
async def test_short_numbers_mapping_same_room_dedup():
    """多个短号归一到同一真实房 → 只入册一次一个起抓任务(不重复抓同一房)。"""
    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()
    db = MockDB()
    # 321 与 654 都映射到真实房 2678075
    star = MockStar({"321": "2678075", "654": "2678075", "111": "111"})
    res = await admit_rooms(["321", "654", "111"], bus=bus, db=db, star=star,
                            cfg=_cfg(), do_canon=True)
    assert res["added"] == 2                      # {2678075, 111}
    assert set(res["added_rooms"]) == {"2678075", "111"}
    assert await bus.r.zcard(K_SCHED) == 2        # 每真实房仅一个 mp 任务
    assert task_mainpage("2678075") in set(await bus.r.zrange(K_SCHED, 0, -1))
    await bus.close()


@pytest.mark.asyncio
async def test_bounded_concurrency_caps_canon_inflight():
    """归一并发受 canon_concurrency 钳制(叠加繁星令牌桶是双重约束)。"""
    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()
    star = MockStar({str(i): str(i) for i in range(500)}, latency=0.01)
    await admit_rooms([str(i) for i in range(500)], bus=bus, db=MockDB(),
                      star=star, cfg=_cfg(canon_concurrency=16), do_canon=True)
    assert star.peak <= 16, f"归一峰值并发 {star.peak} 超过上限 16"
    await bus.close()
