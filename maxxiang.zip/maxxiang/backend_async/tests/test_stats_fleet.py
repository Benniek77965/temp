"""test_stats_fleet.py — stats:ingest 的口径守卫(3.4.7)

背景(AUDIT §18):`stats:ingest` 的 per_min/rate 是**本副本进程内计数**,多副本
用普通 HSET 覆盖写同一 hash → 读者只能看到"最后写入的那个副本"。10 副本产线上
这把全舰队入库率读低了一个数量级(10.3 vs ~103 局/s),直接酿成「92.6% 的局靠
GameHistory 回填」的误判。本文件钉死修复后的双口径:

  · legacy 字段(per_min/rate)语义**保持不变** = 最后写入副本的本地值
    (显式断言这一点,防止有人"顺手"把它改成全舰队而破坏既有读者的心智模型);
  · 新增 fleet_per_min / fleet_rate / replicas_reporting = 各副本子哈希按
    ts 新鲜度聚合之和 —— 这才是可以拿去和「房数/50s」对账的数。

真机 2 副本受控实验实证:全舰队 PG 真值 ÷ legacy rate = 2.00×。
"""
from __future__ import annotations

import copy
import json
import os
import sys
import time

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.worker import Worker, aggregate_fleet_ingest  # noqa: E402
from app.settings import settings as _S  # noqa: E402

REDIS_URL = os.environ.get("STA_TEST_REDIS_URL", "redis://localhost:6379/15")


# ── 纯函数:聚合语义 ─────────────────────────────────────────────────────────
def _ent(ts_ms: int, per_min: float, rate: float) -> str:
    return json.dumps({"ts_ms": ts_ms, "per_min": per_min, "rate": rate})


def test_aggregate_sums_fresh_replicas():
    now = 1_000_000_000_000
    fleet, stale = aggregate_fleet_ingest(
        {"aa": _ent(now - 5_000, 30, 0.5), "bb": _ent(now - 59_000, 50, 0.833)},
        now)
    assert fleet == {"fleet_per_min": 80.0, "fleet_rate": 1.333,
                     "replicas_reporting": 2}
    assert stale == []


def test_aggregate_drops_and_returns_stale_and_junk():
    now = 1_000_000_000_000
    entries = {
        "live": _ent(now - 1_000, 10, 0.167),
        "dead": _ent(now - 181_000, 999, 99.0),   # 超 180s 新鲜窗 → 死副本
        "junk": "{not json",                       # 脏数据 → 清
    }
    fleet, stale = aggregate_fleet_ingest(entries, now)
    assert fleet["fleet_per_min"] == 10.0
    assert fleet["fleet_rate"] == 0.167
    assert fleet["replicas_reporting"] == 1
    assert sorted(stale) == ["dead", "junk"]


def test_aggregate_empty():
    fleet, stale = aggregate_fleet_ingest({}, 1)
    assert fleet == {"fleet_per_min": 0.0, "fleet_rate": 0.0,
                     "replicas_reporting": 0}
    assert stale == []


# ── 集成:两个真 Worker 副本共写同一 Redis(db15),口径对账 ───────────────────
@pytest.mark.asyncio
async def test_two_replicas_emit_fleet_scope_real_redis():
    s = copy.deepcopy(_S)
    s.redis_url = REDIS_URL
    w1 = Worker(s)
    w2 = Worker(s)
    try:
        await w1.bus.r.flushdb()
        # 预埋:一个死副本 + 一条脏 JSON,聚合应剔除并顺手 HDEL
        await w1.bus.r.hset("stats:ingest:replicas", "deadbe",
                            _ent(int(time.time() * 1000) - 400_000, 777, 12.9))
        await w1.bus.r.hset("stats:ingest:replicas", "junkjk", "{oops")

        await w1._emit_ingest_stats(n=30, elapsed=60.0, active=set())
        await w2._emit_ingest_stats(n=50, elapsed=60.0, active=set())

        st = await w1.bus.r.hgetall("stats:ingest")
        # ① legacy 语义不变:= 最后写入副本(w2)的本地值 —— 这是历史误判的根源,
        #    显式钉住,防止读者再把它当全舰队用,也防止有人悄悄改其含义。
        assert float(st["rate"]) == round(50 / 60.0, 3)
        assert int(st["per_min"]) == 50
        # ② fleet_* = 两副本之和(全舰队口径,可与 房数/50s 直接对账)
        assert float(st["fleet_per_min"]) == 80.0
        assert float(st["fleet_rate"]) == round(30 / 60.0, 3) + round(50 / 60.0, 3)
        assert int(st["replicas_reporting"]) == 2
        # ③ 失真倍数 = 副本数(真机 2 副本实证 2.00×;10 副本产线即 ~10×)
        assert abs(float(st["fleet_per_min"]) / float(st["per_min"]) - 1.6) < 1e-9
        # ④ 死副本/脏字段已被顺手清出子哈希,只剩两个活副本
        sub = await w1.bus.r.hgetall("stats:ingest:replicas")
        assert set(sub.keys()) == {w1._stats_wid, w2._stats_wid}
    finally:
        await w1.bus.r.flushdb()
        for w in (w1, w2):
            try:
                await w.bus.close()
            except Exception:
                pass
