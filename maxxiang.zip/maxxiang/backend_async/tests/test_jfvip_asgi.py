"""
test_jfvip_asgi.py — 九法VIP 路由层端到端(4.2.1)
================================================================================
**为什么必须有这一份**:此前 VIP 的验证是分层的 —— jfvip/jfpay 的函数直调、
前端 jsdom、真库事务,唯独**没有一次经过真实 ASGI 栈**:
    中间件 guard() → CSRF 头闸 → _req_user 注入 → _vip_guard → 端点 → JSON 序列化

而"接线"恰恰是最容易出错的一层:端点写对了但闸没接、闸接了但顺序不对、
free 档能不能过 guard、`/api/vip/*` 会不会被自己的闸挡住(购买死锁)……
这些只有打真实 HTTP 才看得出来。谱系同 `test_rail_status::test_live_rooms_route_asgi_e2e`。

零外部依赖:登录系统用桩身份(monkeypatch `userauth.validate`),
DB/Redis 用宽桩,不连任何真实服务。
"""
from __future__ import annotations

from types import SimpleNamespace

import httpx
import pytest

import app.jfvip as jfvip
import app.userauth as userauth
import app.web as web
from app.settings import UserAuthCfg

CSRF = {"X-JF-Auth": "1"}


class _WideDB:
    """宽桩:本文件只关心**路由与闸**,不关心数据内容。

    但有几个方法的**返回类型**会影响闸的走向,必须显式给对(否则测出来的
    403/500 是桩的锅,不是接线的锅 —— 那种假阳性比不测还糟):
      · user_room_allowed → 必须 True,否则先被 3.8.0 的名录闸挡掉,
        根本走不到 VIP 闸,本文件就什么也没验到;
      · history / prediction_records → 列表;accuracy → dict;
      · latest_round / pending_prediction / latest_prediction → None(允许)。
    """

    async def user_room_allowed(self, *a, **k):
        return True

    async def user_rooms_list(self, *a, **k):
        return [{"room_id": "321", "alias": "321"}]

    async def accuracy(self, room, window=100):
        return {"window": window, "n": 0, "main": 0, "cover": 0}

    async def latest_round(self, *a, **k):
        return None

    async def pending_prediction(self, *a, **k):
        return None

    async def latest_prediction(self, *a, **k):
        return None

    def __getattr__(self, _name):
        async def _any(*a, **k):
            return []
        return _any


class _Star:
    async def canon(self, room):
        return str(room), str(room)

    async def profile(self, room):
        return {}


class _Bus:
    """同 _WideDB:集合类必须回可迭代对象,否则 _visible_rooms 之流会 TypeError,
    测出来的 500 是桩的锅而不是接线的锅。"""

    r = SimpleNamespace()

    async def active_rooms(self, *a, **k):
        return ["321"]

    async def discovered_members(self, *a, **k):
        return set()

    async def get_snapshot(self, *a, **k):
        return {}

    async def official_missing_in(self, *a, **k):
        return []

    async def active_room_acquire(self, *a, **k):
        return True, ""

    def __getattr__(self, _name):
        # 兜底一律回**空列表**而不是 None:调用方多是 set(...)/for 迭代,
        # 回 None 会炸成 TypeError,让人误以为是接线问题(实为桩不完整)。
        async def _any(*a, **k):
            return []
        return _any


def _principal(tier: str) -> userauth.Principal:
    """造一个指定档位的身份(与 login/validate 产出的形态一致)。"""
    return userauth.Principal(
        user_id=7, user_name="u7", session_id=1, token_hash="h",
        due_time_iso="2027-01-01T00:00:00",
        dd_alive=(tier != "free"),
        jf_vip_until_iso=("2026-12-01T00:00:00" if tier == "vip" else ""),
        jf_alive=(tier == "vip"))


@pytest.fixture
def wired(monkeypatch):
    """启用登录系统 + VIP 体系,并把会话校验替换成桩(按 cookie 值决定档位)。"""
    cfg = UserAuthCfg(host="h", port=3306, db="d", user="u", password="p",
                      charset="gbk", jf_vip_enabled=True, cache_ttl_s=0.0)
    monkeypatch.setattr(userauth.UA, "cfg", cfg, raising=False)
    monkeypatch.setattr(userauth.UA, "pool", object(), raising=False)   # 让 enabled() 成立
    monkeypatch.setattr(web.ST, "db", _WideDB(), raising=False)
    monkeypatch.setattr(web.ST, "star", _Star(), raising=False)
    monkeypatch.setattr(web.ST, "bus", _Bus(), raising=False)

    async def _validate(token):
        if not token:
            return "auth_required", None, {}
        return "ok", _principal(token), {}

    monkeypatch.setattr(userauth, "validate", _validate)
    # 档位表用默认三档;不触网关
    monkeypatch.setattr(jfvip, "plans", lambda: [
        {"code": "d3", "name": "3 天", "price": 18, "jfHours": 72,
         "ddHours": 72, "tag": ""},
    ])
    yield


def _client() -> httpx.AsyncClient:
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=web.app),
                             base_url="http://t")


# ══ 一、三档 × 数据端点:闸是否真的在中间件栈里生效 ═══════════════════════════
@pytest.mark.asyncio
@pytest.mark.parametrize("tier,want", [("free", 403), ("basic", 200), ("vip", 200)])
async def test_live_rooms_gated_by_tier(wired, tier, want):
    async with _client() as c:
        r = await c.get("/api/live-rooms", headers=CSRF, cookies={"jf_user_sid": tier})
    assert r.status_code == want, r.text
    if want == 403:
        assert r.json().get("error") == "vip_required", r.text


@pytest.mark.asyncio
@pytest.mark.parametrize("tier,want", [("free", 403), ("basic", 403), ("vip", 200)])
async def test_coverage_needs_vip(wired, tier, want):
    """coverage 是 VIP 专属(它会驱动前端补拉 80 局,是 basic 档的绕过口)。"""
    async with _client() as c:
        r = await c.get("/api/rooms/321/coverage", headers=CSRF,
                        cookies={"jf_user_sid": tier})
    assert r.status_code == want, r.text


@pytest.mark.asyncio
async def test_history_clamped_for_basic_via_http(wired, monkeypatch):
    """★ 经真实 HTTP 验证 30 局硬顶:basic 档请求 limit=1800 必须被钳到 30,
    且 `until`(按日回看)必须直接 403 —— 这两条合起来才是「取不到历史」的闸。"""
    seen = {}

    class _DB(_WideDB):
        async def history(self, room, since=0, limit=80, until=0):
            seen["limit"] = limit
            seen["until"] = until
            return []

    monkeypatch.setattr(web.ST, "db", _DB(), raising=False)
    async with _client() as c:
        r = await c.get("/api/rooms/321/history?limit=1800", headers=CSRF,
                        cookies={"jf_user_sid": "basic"})
        assert r.status_code == 200, r.text
        assert seen["limit"] == 30, f"basic 档 limit 未被钳制,实得 {seen.get('limit')}"

        r2 = await c.get("/api/rooms/321/history?limit=1800", headers=CSRF,
                         cookies={"jf_user_sid": "vip"})
        assert r2.status_code == 200
        assert seen["limit"] == 1800, "VIP 档不该被钳"

        r3 = await c.get("/api/rooms/321/history?since=1&until=999999999999",
                         headers=CSRF, cookies={"jf_user_sid": "basic"})
        assert r3.status_code == 403 and r3.json()["need"] == "vip", r3.text


@pytest.mark.asyncio
async def test_history_clamp_applies_to_passive_prefetch(wired, monkeypatch):
    """★ passive=1(名录跨房预取)同样受钳 —— 否则它就是绕过口
    (同 3.9.1 给 _proof_guard 补 passive 的教训)。"""
    seen = {}

    class _DB(_WideDB):
        async def history(self, room, since=0, limit=80, until=0):
            seen["limit"] = limit
            return []

    monkeypatch.setattr(web.ST, "db", _DB(), raising=False)
    async with _client() as c:
        r = await c.get("/api/rooms/321/history?limit=200&passive=1", headers=CSRF,
                        cookies={"jf_user_sid": "basic"})
    assert r.status_code == 200, r.text
    assert seen["limit"] == 30, f"passive 预取未受钳(绕过口),实得 {seen.get('limit')}"


@pytest.mark.asyncio
async def test_prediction_trimmed_for_basic_via_http(wired, monkeypatch):
    """★ 经真实 HTTP 验证裁剪:basic 档拿不到 main/guard/ens/target,
    但**必须**拿得到 record/accuracy(那正是需求的「近 100 局命中信息」)。"""
    async def _build(room):
        return {"ok": True, "target_round_id": "123", "main": [3, 7],
                "guard": [1, 9], "ens": [0.1] * 9, "record": [], "accuracy": None}

    monkeypatch.setattr(web, "_build_prediction", _build)

    class _DB(_WideDB):
        async def prediction_records(self, room, limit=40):
            assert limit == 100, f"basic 档命中窗口应为 100,实得 {limit}"
            return [{"round_id": 1, "actual_custom_id": 3, "hit": "main"}]

        async def accuracy(self, room, window=100):
            return {"window": window, "n": 100, "main": 30, "cover": 55}

    monkeypatch.setattr(web.ST, "db", _DB(), raising=False)
    async with _client() as c:
        rb = await c.get("/api/rooms/321/prediction", headers=CSRF,
                         cookies={"jf_user_sid": "basic"})
        rv = await c.get("/api/rooms/321/prediction", headers=CSRF,
                         cookies={"jf_user_sid": "vip"})
    b, v = rb.json(), rv.json()
    assert b["main"] == [] and b["guard"] == [] and b["ens"] == [], "basic 仍拿到预测号"
    assert b["target_round_id"] is None and b["vipLocked"] is True
    assert b["accuracy"]["n"] == 100 and b["record"], "basic 的命中信息被误伤"
    assert v["main"] == [3, 7] and v["target_round_id"] == "123", "VIP 档被误裁"


# ══ 二、/api/vip/*:必须能被 free 档访问(否则购买死锁)═══════════════════════
@pytest.mark.asyncio
@pytest.mark.parametrize("tier", ["free", "basic", "vip"])
async def test_vip_state_reachable_by_every_tier(wired, tier):
    """★ 购买死锁防线:`/api/vip/*` 绝不能接 _vip_guard ——
    没 VIP 不能买、买了才有 VIP,那是死循环。free 档尤其必须能进。"""
    async with _client() as c:
        r = await c.get("/api/vip/state", headers=CSRF, cookies={"jf_user_sid": tier})
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["enabled"] is True and j["tier"] == tier
    assert j["plans"], "档位表未回传(前端渲染不出价格卡)"
    assert isinstance(j.get("matrix"), list) and j["matrix"], "能力矩阵未回传"


@pytest.mark.asyncio
async def test_vip_endpoints_require_session(wired):
    """未登录访问 VIP 端点 → 401(而不是 503「本部署未启用」);
    这条是复审修过的错误语义,用真实 HTTP 再钉一次。"""
    async with _client() as c:
        r = await c.get("/api/vip/state", headers=CSRF)      # 无 cookie
    assert r.status_code == 401, r.text


@pytest.mark.asyncio
async def test_vip_write_endpoints_need_csrf_header(wired):
    """写端点必须带 X-JF-Auth(CSRF 纪律)—— 缺头即 403 bad_origin。"""
    async with _client() as c:
        r = await c.post("/api/vip/redeem", json={"card": "JFAAAAAA234567"},
                         cookies={"jf_user_sid": "basic"})     # 刻意不带头
    assert r.status_code == 403 and r.json().get("error") == "bad_origin", r.text


@pytest.mark.asyncio
async def test_redeem_bad_shape_gives_actionable_hint(wired, monkeypatch):
    """卡密形态错时要给**可操作**提示(而不是笼统失败),且不打库。"""
    async def _never(*a, **k):
        raise AssertionError("形态非法时不应打库")

    monkeypatch.setattr(jfvip, "grant_by_card", _never)
    monkeypatch.setattr(jfvip, "redeem_fail_ok", lambda uid: _true())
    monkeypatch.setattr(jfvip, "redeem_fail_bump", lambda uid: _none())
    async with _client() as c:
        r = await c.post("/api/vip/redeem", json={"card": "JF0BCDEF234567"},
                         headers=CSRF, cookies={"jf_user_sid": "free"})
    assert r.status_code == 400, r.text
    assert "0" in r.json()["message"] and "I" in r.json()["message"], r.text


async def _true():
    return True


async def _none():
    return None


# ══ 三、SSE:free 档建流前就拒 ═══════════════════════════════════════════════
@pytest.mark.asyncio
async def test_sse_denied_for_free_before_stream(wired):
    """free 档必须在**建流前**被拒 —— 建了再踢会让开通页出现莫名其妙的断连提示。
    (SSE 天然带不了自定义头,故此处不带 CSRF —— 那是 _NO_HEADER_OK 的既有豁免。)"""
    async with _client() as c:
        r = await c.get("/api/events?roomId=321", cookies={"jf_user_sid": "free"})
    assert r.status_code == 403 and r.json().get("error") == "vip_required", r.text


# ══ 六、对账兜底端点的真实接线(4.2.2 新增)══════════════════════════════════
# §9.15 的教训:接线只有打真实 HTTP 才看得出来。4.2.2 给本端点加了限频、
# 加了异常兜底,而它此前**一条 ASGI 用例都没有** —— 补上。
@pytest.mark.asyncio
@pytest.mark.parametrize("tier", ["free", "basic", "vip"])
async def test_reconcile_reachable_by_every_tier(wired, monkeypatch, tier):
    """对账兜底也属 /api/vip/*:三档皆可达(free 档尤其 —— 付了钱掉线的
    多半正是他)。并且必须把 candidates 原样透出给前端识别陈旧标记。"""
    import app.jfpay as jfpay

    async def _rec(uid, name):
        return {"candidates": 2, "checked": 2, "recovered": 1, "expired": 0}

    monkeypatch.setattr(jfpay, "reconcile", _rec)
    monkeypatch.setattr(jfvip, "reconcile_rate_ok", lambda uid: _true())
    async with _client() as c:
        r = await c.post("/api/vip/order/reconcile", json={},
                         headers=CSRF, cookies={"jf_user_sid": tier})
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["candidates"] == 2 and j["recovered"] == 1, r.text


@pytest.mark.asyncio
async def test_reconcile_is_throttled_before_touching_gateway(wired, monkeypatch):
    """限频必须在真正打网关之前生效 —— 本端点单次最多查 10 笔,
    放大倍数是下单的 10 倍,是最值钱的一把闸。"""
    import app.jfpay as jfpay

    async def _never(uid, name):
        raise AssertionError("限频未拦住,已经打到网关层了")

    monkeypatch.setattr(jfpay, "reconcile", _never)
    monkeypatch.setattr(jfvip, "reconcile_rate_ok", lambda uid: _false())
    async with _client() as c:
        r = await c.post("/api/vip/order/reconcile", json={},
                         headers=CSRF, cookies={"jf_user_sid": "free"})
    assert r.status_code == 429 and r.json()["error"] == "throttled", r.text


@pytest.mark.asyncio
async def test_reconcile_survives_userdb_hiccup(wired, monkeypatch):
    """★ 用户库在公网(RTT 受安全组摆布),一次抖动不该变成 500。

    4.2.2 之前本端点是**唯一**既无 try 也无 suppress 的 VIP 端点
    (create / redeem 有 try,state 有 suppress);而它自 4.2.2 起是热路径
    (每次相关开机都打),不兜底就会持续刷 500 日志。"""
    import app.jfpay as jfpay

    async def _boom(uid, name):
        raise RuntimeError("(2003, \"Can't connect to MySQL server\")")

    monkeypatch.setattr(jfpay, "reconcile", _boom)
    monkeypatch.setattr(jfvip, "reconcile_rate_ok", lambda uid: _true())
    async with _client() as c:
        r = await c.post("/api/vip/order/reconcile", json={},
                         headers=CSRF, cookies={"jf_user_sid": "basic"})
    assert r.status_code == 500 and r.json()["error"] == "db", r.text
    assert r.json()["ok"] is False, "库抖动应回结构化错误,而不是未捕获异常"


async def _false():
    return False


@pytest.mark.asyncio
async def test_vip_write_endpoints_survive_non_object_json(wired, monkeypatch):
    """5.2.0 同类修复回归:合法但非对象的 JSON(数组 / 字符串)旧版在 body.get 处抛 500。"""
    async def _never(*a, **k):
        raise AssertionError("非对象请求体不应打库")

    monkeypatch.setattr(jfvip, "grant_by_card", _never)
    monkeypatch.setattr(jfvip, "redeem_fail_ok", lambda uid: _true())
    monkeypatch.setattr(jfvip, "redeem_fail_bump", lambda uid: _none())
    async with _client() as c:
        r = await c.post("/api/vip/redeem", json=[1, 2], headers=CSRF,
                         cookies={"jf_user_sid": "free"})
        assert r.status_code == 400 and r.json().get("error") == "card_shape", r.text
        r2 = await c.post("/api/vip/order/create", json="d3", headers=CSRF,
                          cookies={"jf_user_sid": "free"})
        assert r2.status_code < 500, r2.text

