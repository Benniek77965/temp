"""test_pg_probe.py — PG 侧饥饿探针的契约守卫(3.4.4)

真机现场(用户 VPS,16 副本):副本数超 PG 连接账本(16×32+35=547 > max_connections
400)时,pool.acquire 无限期排队 —— 任务「按时被领、执行中卡死」,出怪入库散布局内
41~70s、结算→预测再拖 3~40s、/prediction 出现十几秒 null;而 Redis 到期积压恒 0,
旧 health 完全看不见。探针语义:**取连接+SELECT 的端到端耗时 = 一切业务 PG 调用的
入场费**;排不到队(超时)本身就是饥饿实锤。
"""
import asyncio
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

_PG = os.environ.get("STA_PG_DSN", "")
_needs_pg = pytest.mark.skipif(not _PG, reason="需要 PostgreSQL(设 STA_PG_DSN)")


@_needs_pg
@pytest.mark.asyncio
async def test_probe_healthy_pool_reports_fast_and_unsaturated():
    from app.db import DB
    db = DB(_PG, 2, 4)
    await db.connect()
    try:
        out = await db.pg_health_probe()
        assert out["ping_ms"] >= 0 and out["ping_ms"] < 1500
        assert out["used"] >= 1 and out["max_conn"] >= out["used"]
        assert out["saturated"] is False
    finally:
        await db.close()


@pytest.mark.asyncio
async def test_probe_starved_pool_times_out_as_saturated():
    """acquire 排不到队 = 饥饿实锤:探针必须在 timeout 内返回 saturated=True,
    绝不无限等、绝不抛错拖垮调用方(janitor / /api/crawler/status)。"""
    from app.db import DB

    class _StuckPool:                       # acquire 永远给不出连接(模拟账本被击穿)
        def acquire(self):
            class _Ctx:
                async def __aenter__(self):
                    await asyncio.sleep(3600)
                async def __aexit__(self, *a):
                    return False
            return _Ctx()

    db = DB.__new__(DB)
    db.pool = _StuckPool()                  # type: ignore[assignment]
    out = await db.pg_health_probe(timeout_s=0.3)
    assert out["saturated"] is True
    assert out["ping_ms"] == 300            # 按 timeout 计,不无限等
    assert out["used"] == -1 and out["max_conn"] == -1
