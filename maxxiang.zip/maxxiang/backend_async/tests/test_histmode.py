"""
test_histmode.py — hist-mode(3.5.0)单元/行为测试
================================================================================
分两层:
  · 纯函数:周期钳位(effective_hist_interval_ms)、前瞻投影退避
    (hist_retry_delay_ms,复查修正 B 的边界算术)、加权容量(weighted_fleet_load);
  · 处理器行为(fakeredis,不跑完整仿真泵):迁移入口的满窗抖动、退出分支的
    「恰一次收尾」幂等键、审计的官方缺/越窗丢二分、短页启发式的计数门槛。
全链路端到端(账本/断供矩阵/双向迁移/多副本)在 scripts/sim_hist_mode.py,
CI 由 test_industrial 同款方式驱动(见 test_histmode_sim_matrix)。
"""
from __future__ import annotations

import asyncio
import random

import pytest

from app.scheduler import (HIST_INTERVAL_MAX_MS, HIST_INTERVAL_MIN_MS,
                           effective_hist_interval_ms, hist_retry_delay_ms,
                           weighted_fleet_load)
from app.settings import HistModeCfg


# ── 纯函数:周期钳位 ──────────────────────────────────────────────────────────
def test_interval_clamp():
    assert effective_hist_interval_ms(HistModeCfg(interval_s=300)) == 300_000
    # 下钳:防误配秒级 → 万房自伤风暴
    assert effective_hist_interval_ms(HistModeCfg(interval_s=1)) == HIST_INTERVAL_MIN_MS
    # 上钳:页窗 − 4 局 ≈1300s,越窗值不允许借任何通道生效(claim_grace 先例)
    assert effective_hist_interval_ms(HistModeCfg(interval_s=2000)) == HIST_INTERVAL_MAX_MS
    assert HIST_INTERVAL_MAX_MS == 26 * 50001
    # 坏输入回系统默认(900s)再钳 —— 兜底必须与 dataclass/REGISTRY 默认一致,
    # 否则"坏配置时的行为"与文档陈述的默认相矛盾
    class Broken:
        interval_s = "not-a-number"
    assert effective_hist_interval_ms(Broken()) == 900_000


# ── 纯函数:退避 + 前瞻投影(复查修正 B 的实证算术) ─────────────────────────────
def test_retry_ladder_and_projection():
    kw = dict(base_ms=90_000, cap_ms=300_000,
              edge_after_ms=1_200_000, edge_retry_ms=45_000,
              rnd=random.Random(1))
    # 阶梯:90 → 180 → 300 封顶(允许 +1/6 抖动)
    d1 = hist_retry_delay_ms(1, age_ms=300_000, **kw)
    d2 = hist_retry_delay_ms(2, age_ms=390_000, **kw)
    d3 = hist_retry_delay_ms(3, age_ms=570_000, **kw)
    assert 90_000 <= d1 <= 105_000
    assert 180_000 <= d2 <= 210_000
    assert 300_000 <= d3 <= 350_000
    # 前瞻投影:age=1170s 时普通阶梯的 +300s 会把年龄推到 1470>1200 —— 必须
    # 切 45s 抢救节拍(否则下一跳 1770s 已越 1500s 页窗,数据丢失不可逆)
    dproj = hist_retry_delay_ms(5, age_ms=1_170_000, **kw)
    assert 30_000 <= dproj <= 60_000, dproj
    # 深入抢救区:恒为抢救节拍(±1/3)
    dedge = hist_retry_delay_ms(9, age_ms=1_350_000, **kw)
    assert 30_000 <= dedge <= 60_000
    # 从未成功过(age=0):无页窗时钟可保,不投影、按普通阶梯
    dnew = hist_retry_delay_ms(5, age_ms=0, **kw)
    assert 300_000 <= dnew <= 350_000
    # fails 高位不溢出(<<6 封顶后仍受 cap)
    assert hist_retry_delay_ms(40, age_ms=0, **kw) <= 350_000
    # 【变异测试补锁 ①】age>0 守卫在合法参数域内**可达**:edge_after 取注册表
    # 下限 300s、cap 取上限 900s 时,age=0 的大步长若无守卫会被误投影进抢救带
    # (第十轮变异 m3 存活暴露的向量缺口)。守卫语义:从未成功过=没有页窗时钟
    # 可保,永远按普通阶梯。
    kw2 = dict(base_ms=200_000, cap_ms=900_000, edge_after_ms=300_000,
               edge_retry_ms=45_000, rnd=random.Random(2))
    d_noclock = hist_retry_delay_ms(3, age_ms=0, **kw2)
    assert 800_000 <= d_noclock <= 934_000, d_noclock       # 普通阶梯,绝非 45s 带
    # 【变异测试补锁 ②】投影边界语义钉死为严格大于:age+step **恰等于**
    # edge_after 时仍走普通阶梯(恰触线安全 —— 线到页窗还有 300s 余量,下一次
    # 失败 age 已在线上、必进抢救;变异 m5 的 >= 会把这一拍误切 45s 带)。
    d_edge_eq = hist_retry_delay_ms(5, age_ms=900_000, **kw)  # 900k+300k == 1200k
    assert 300_000 <= d_edge_eq <= 350_000, d_edge_eq


# ── 纯函数:加权容量 ──────────────────────────────────────────────────────────
def test_weighted_fleet_load():
    # 万房纯 hist,T=300:等效 ≈ 10000×(50.001/300)×1.5 = 2501(向上取整)
    assert weighted_fleet_load(0, 10_000, 300) == 2501
    assert weighted_fleet_load(50, 10_000, 300) == 2551
    assert weighted_fleet_load(50, 0, 300) == 50          # 无 hist 房 = 原口径
    assert weighted_fleet_load(50, 100, 0) == 150         # interval<=0 = 未启用口径
    assert weighted_fleet_load(-3, -5, 300) == 0          # 防御负值


# ── 处理器行为件(fakeredis;直接驱动 Worker 单事件,不跑泵) ────────────────────
def _mini_world(enabled=True, interval_s=300):
    import fakeredis.aioredis
    from app import worker as wk
    from app.settings import Settings
    from scripts.sim_history_gap import FakeDB, SimUpstream, VClock, T0, STEP

    clock = VClock(T0 + 10 * STEP + 2_000)
    import app.redis_bus as rb
    rb.now_ms = clock
    wk.now_ms = clock
    s = Settings()
    s.prediction = {"enabled": False}
    s.histmode.enabled = enabled
    s.histmode.interval_s = interval_s
    w = wk.Worker(s)
    w.bus.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    up = SimUpstream(clock)
    db = FakeDB(); db._clock = clock
    w.up, w.db = up, db
    return w, up, db, clock, s


@pytest.mark.asyncio
async def test_migration_entry_full_window_jitter():
    """mp 迁移拍:改排 hs 的首拍必须落在满窗 U(0,T) 内(复查修正 D:相位
    平移会造出每 T 一次的 50s 梳齿),且不打上游 MainPage。"""
    import app.redis_bus as rb
    from app.redis_bus import task_hist, task_mainpage
    w, up, db, clock, s = _mini_world()
    room = "2678075"
    await w.bus.add_rooms_bulk([(room, room)])
    await w.bus.r.hset(rb.K_ROOMS_DISCOVERED, room, str(clock.t))
    random.seed(3)
    await w.bus.schedule(task_mainpage(room), clock.t)
    for m in await w.bus.claim_due(10, 10 ** 12):
        await w._handle(m)
    assert up.calls["mp"] == 0                       # 短路于 _handle_mainpage 之前
    z = dict(await w.bus.r.zrange(rb.K_SCHED, 0, -1, withscores=True))
    assert task_hist(room) in z and task_mainpage(room) not in z
    delta = int(z[task_hist(room)]) - clock.t
    assert 0 <= delta <= 300_000 * 1.0 + 1           # 满窗铺开(≤T)


@pytest.mark.asyncio
async def test_exit_branch_exactly_once_seal():
    """退出分支:封尾幂等键 = 快照 histLastOkMs(成功即消费置 0)——特意与
    lastok zset 解耦:后者是健康指标,转正统一出口(discovered_remove 族)
    先行清它;若用它做键,封尾会被静默跳过(复查抓出的自伤回归,此测锁死)。
    首发:收尾回填 + 消费键 + 清 lastok + 改排 mp;病理性第二发跳过自灭。"""
    import app.redis_bus as rb
    from app.redis_bus import task_hist, task_mainpage
    w, up, db, clock, s = _mini_world(enabled=True)
    room = "2678075"
    await w.bus.add_rooms_bulk([(room, room)])
    # 已转正(不在发现集)+ 轮询过的痕迹:快照键在,而 lastok 已被转正出口清掉
    await w.bus.set_snapshot(room, {"histLastOkMs": clock.t - 60_000})
    await w._handle_hist(room, task_hist(room))
    assert up.calls["hist"] == 1                     # 封尾恰一次
    assert await w.bus.r.zcard(rb.K_HIST_LASTOK) == 0
    snap = await w.bus.get_snapshot(room)
    assert snap.get("histLastOkMs") in ("0", 0)      # 键已消费
    assert int(snap.get("latestRoundId") or 0) > 0   # 页头口径跟上
    z = dict(await w.bus.r.zrange(rb.K_SCHED, 0, -1, withscores=True))
    assert task_mainpage(room) in z
    # 病理性第二发:键已消费 → 跳过回填
    await w._handle_hist(room, task_hist(room))
    assert up.calls["hist"] == 1


@pytest.mark.asyncio
async def test_audit_first_poll_and_split():
    """审计二分:首拍只立水位;页窗内缺格=官方缺失(不计 window_lost);
    页窗外缺格=越窗丢失(登记 + 计数)。直接喂 _hist_audit,格点手工构造。"""
    from scripts.sim_history_gap import STEP
    w, up, db, clock, s = _mini_world()
    room = "2678075"
    head = clock.t - (clock.t % STEP)
    # 首拍:covWm 空 → 立到 head,不产生任何登记
    await w._hist_audit(room, head)
    snap = await w.bus.get_snapshot(room)
    assert int(snap["covWm"]) == head
    st = await w.bus.histmode_stats()
    assert int(st.get("window_lost", 0) or 0) == 0
    # 推老水位到 40 局前:窗外 11 格(40-29)、窗内 29 格;库里只放部分点 →
    # 窗内缺 = 官方缺;窗外缺 = 越窗丢
    old_wm = head - 40 * STEP
    await w.bus.set_snapshot(room, {"covWm": old_wm})
    for k in range(1, 41):                            # 库里放偶数格,奇数格缺
        g = old_wm + k * STEP
        if k % 2 == 0:
            db.rounds[g] = {"round_id": g}
    await w._hist_audit(room, head)
    st = await w.bus.histmode_stats()
    lost = int(st.get("window_lost", 0) or 0)
    win_start = head - 29 * STEP
    expect_lost = len([k for k in range(1, 41)
                       if k % 2 and old_wm + k * STEP < win_start])
    assert lost == expect_lost and lost > 0
    # 全部缺格(窗内+窗外)都已登记官方缺失,水位推到 head
    miss = [old_wm + k * STEP for k in range(1, 41) if k % 2]
    marked = set(await w.bus.official_missing_in(room, miss))
    assert marked == set(miss)
    snap = await w.bus.get_snapshot(room)
    assert int(snap["covWm"]) == head


@pytest.mark.asyncio
async def test_short_page_heuristic_gate():
    """短页启发式:仅「非首拍 + 页连续无洞 + 长度<30」计数;首拍(lastok 空)
    与页内有洞(官方缺失谱系)不计。经真实 _handle_hist 驱动。"""
    import app.redis_bus as rb
    from app.redis_bus import task_hist
    from scripts.sim_history_gap import STEP
    w, up, db, clock, s = _mini_world()
    room = "2678075"
    await w.bus.add_rooms_bulk([(room, room)])
    await w.bus.r.hset(rb.K_ROOMS_DISCOVERED, room, str(clock.t))
    # 上游只给 8 局连续短页(monkeypatch)
    async def short_page(aid, r):
        up.calls["hist"] += 1
        head = clock.t - (clock.t % STEP) - 2 * STEP
        return {"gameList": [{"roundId": head - i * STEP,
                              "beastInfo": {"beastId": 43, "beastName": "夜煞"}}
                             for i in range(8)]}
    up.game_history = short_page
    await w._handle_hist(room, task_hist(room))       # 首拍:不计
    st = await w.bus.histmode_stats()
    assert int(st.get("short_page", 0) or 0) == 0
    clock.t += 300_000
    await w._handle_hist(room, task_hist(room))       # 非首拍连续短页:计 1
    st = await w.bus.histmode_stats()
    assert int(st.get("short_page", 0) or 0) == 1


@pytest.mark.asyncio
async def test_lastok_subset_discovered_invariant():
    """不变量 lastok ⊆ discovered:退出发现集的**每一个**出口都同步清健康项 ——
    否则僵尸项把「最老轮询年龄」(本模式第一健康指标)撒谎成无限大。
    覆盖:转正单删 / 转正批删 / 回收批删 / 删房 / 批量删房 五路。"""
    import fakeredis.aioredis
    import app.redis_bus as rb
    bus = rb.RedisBus("redis://x")
    bus.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    rooms = [f"90{i}" for i in range(5)]
    await bus.add_rooms_bulk([(r, r) for r in rooms])
    for r in rooms:
        await bus.r.hset(rb.K_ROOMS_DISCOVERED, r, "1")
        await bus.hist_mark_ok(r, 1_000)
    assert await bus.r.zcard(rb.K_HIST_LASTOK) == 5
    await bus.discovered_remove(rooms[0])                 # 转正单删
    await bus.discovered_remove_bulk([rooms[1]])          # 泄漏自愈/批量转正
    await bus.discovered_prune_bulk([rooms[2]])           # 离线回收
    await bus.remove_room(rooms[3])                       # 删房
    await bus.remove_rooms_bulk([rooms[4]])               # 批量删房
    assert await bus.r.zcard(rb.K_HIST_LASTOK) == 0,         await bus.r.zrange(rb.K_HIST_LASTOK, 0, -1)


def test_hist_ladder_properties_fuzz():
    """性质模糊(第十轮):在注册表 ge/le 合法域内 4000 例随机,锁四条不变量 ——
    ① 恒正;② age≥edge_after(已越抢救线)⇒ 恒落抢救带 [edge−⌊edge/3⌋, edge+⌊edge/3⌋]
       (下限另受 1s 地板);③ age>0 且 age+普通步会越线 ⇒ 同②(前瞻投影);
    ④ 否则 ⇒ 普通带 [step, step+⌊step/6⌋]。任何一例破约即缺陷。"""
    rnd = random.Random(20260713)
    for _ in range(4000):
        base = rnd.randint(10, 600) * 1000
        cap = rnd.randint(max(30, base // 1000), 900) * 1000
        edge_after = rnd.randint(300, 1450) * 1000
        edge_retry = rnd.randint(15, 120) * 1000
        fails = rnd.randint(1, 50)
        age = rnd.choice([0, rnd.randint(1, 1_600_000)])
        d = hist_retry_delay_ms(fails, age, base, cap, edge_after, edge_retry,
                                rnd=random.Random(rnd.random()))
        assert d > 0
        step = min(cap, base << max(0, min(fails - 1, 6)))
        in_edge_band = (max(1000, edge_retry - edge_retry // 3)
                        <= d <= edge_retry + edge_retry // 3)
        if age > 0 and age + step > edge_after:
            assert in_edge_band, (d, fails, age, base, cap, edge_after, edge_retry)
        else:
            assert step <= d <= step + step // 6 + 1, (d, step)
    # 钳位幂等 + 域封闭
    for _ in range(400):
        v = rnd.randint(-5, 5000)
        e = effective_hist_interval_ms(HistModeCfg(interval_s=v))
        assert HIST_INTERVAL_MIN_MS <= e <= HIST_INTERVAL_MAX_MS
        # round-trip 幂等只能在**秒粒度**上陈述:上钳点 = 26×50001 = 1_300_026ms
        # 带 26ms 尾数,e//1000 必然截掉(配置以秒为单位,函数以毫秒钳位)——
        # 首跑破约例即此,系性质公式错非函数错,如实修正为同秒等价。
        e2 = effective_hist_interval_ms(HistModeCfg(interval_s=e // 1000))
        assert abs(e2 - e) < 1000 and HIST_INTERVAL_MIN_MS <= e2 <= HIST_INTERVAL_MAX_MS
    # 加权:≥策展基数且对 hist 房数单调
    prev = 0
    for h in range(0, 5000, 250):
        w = weighted_fleet_load(37, h, 900)
        assert w >= 37 and w >= prev
        prev = w


def test_histmode_sim_matrix():
    """端到端矩阵托管:与 test_industrial 驱动 sim_history_gap 同款,把
    scripts/sim_hist_mode 的 H0–H6 全场景纳入 pytest 门禁。"""
    from scripts import sim_hist_mode as sim
    rc = asyncio.run(sim.main([]))                 # 显式空参=全场景(argv 隔离,
    assert rc == 0                                 # 防 pytest 参数把场景集滤空)
