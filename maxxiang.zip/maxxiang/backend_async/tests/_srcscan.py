"""
_srcscan.py — 源码扫描助手(4.2.0)
================================================================================
本轮开发被**同一类假阳性/假阴性**咬了三次:解释性注释里出现
"UPDATE tb_user" / "_vip_guard" / "continue" 等字样,被朴素字符串扫描判成
「代码里有这个」。两个方向都错:

  · 假阳性:注释在说「刻意不这么做」,却被判成违规 → 无谓变红,浪费排查;
  · 假阴性:注释里提了某标识,而代码里其实**没写**,测试却绿 → 真问题溜过去。

注释不会执行。凡是「扫源码判断代码里有没有某写法」的测试,都必须先剥注释。
本模块统一提供该能力,禁止各测试再各写一份。
"""
from __future__ import annotations

import re
from pathlib import Path

_JS_BLOCK = re.compile(r"/\*.*?\*/", re.S)


def strip_py_comments(text: str) -> str:
    """剥掉 Python 的整行 # 注释。

    只剥「整行注释」——行尾注释与字符串字面量原样保留,保证真正的 SQL / 代码
    一个不漏(宁可多留,不可少扫)。docstring 是三引号字符串,若其中某行以 #
    开头也会被剥,那正合本意(docstring 也是注释)。
    """
    return "\n".join("" if ln.lstrip().startswith("#") else ln
                     for ln in text.split("\n"))


def strip_js_comments(text: str) -> str:
    """剥掉 JS 的 /* 块注释 */ 与整行 // 注释。

    刻意**不**剥行尾 // ——那需要真正的词法分析才能避开字符串里的 "//"
    (如 URL "https://…"),得不偿失;整行注释已覆盖本项目全部大段说明。
    """
    text = _JS_BLOCK.sub("", text)
    return "\n".join("" if ln.lstrip().startswith("//") else ln
                     for ln in text.split("\n"))


def py_code(path: Path) -> str:
    """读 .py 并剥注释 —— 扫描类断言一律用它,别用裸 read_text。"""
    return strip_py_comments(Path(path).read_text(encoding="utf-8"))


def js_code(path: Path) -> str:
    """读 .js 并剥注释。"""
    return strip_js_comments(Path(path).read_text(encoding="utf-8"))


def strip_css_comments(text: str) -> str:
    """剥掉 CSS 的 /* 块注释 */(CSS 只有这一种注释形态)。

    4.2.2 补:本轮又被同一类假阳性咬了一次 —— 新写的 CSS 注释里解释
    「原先是 place-items:center,这是错的」,朴素扫描把注释里的字样当成
    「代码里还有这个写法」,钉子无谓变红。对策与 py/js 一致:扫描前先剥。
    """
    return _JS_BLOCK.sub("", text)


def strip_js_comments_keep_lines(text: str) -> str:
    """剥 JS 注释,但**保留行数**(块注释按其跨行数换成等量空行)。

    4.7.7 补:扫描类测试若还要报「第几行」,就不能用 strip_js_comments ——
    它把多行块注释整段删掉,行号随之错位。而报不出行号的断言,运维拿到只能
    全文件搜,等于把定位成本转嫁出去。本函数让「剥注释」与「行号可信」两件事
    同时成立。

    (本轮的直接诱因:新写的解释性注释里原样引用了出事的那行代码,朴素扫描
    把注释当代码判成违规 —— 正是本模块开篇记录的同一类假阳性,第四次撞上。)
    """
    def _blank(m: re.Match) -> str:
        return "\n" * m.group(0).count("\n")
    text = _JS_BLOCK.sub(_blank, text)
    return "\n".join("" if ln.lstrip().startswith("//") else ln
                      for ln in text.split("\n"))


def js_code_keep_lines(path: Path) -> str:
    """读 .js 并剥注释,行号与原文一一对应 —— 需要报行号的扫描用它。"""
    return strip_js_comments_keep_lines(Path(path).read_text(encoding="utf-8"))


def css_code(path: Path) -> str:
    """读 .css 并剥注释 —— 扫描类断言一律用它,别用裸 read_text。"""
    return strip_css_comments(Path(path).read_text(encoding="utf-8"))
