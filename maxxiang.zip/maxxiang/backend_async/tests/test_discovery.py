"""
test_discovery.py — 直播间自动发现解析/遍历单测(不触网,不依赖 Redis/PG)
================================================================================
核对三件事:
  · parse_page 在规范 JSON 上正确抠 roomId + hasNextPage;
  · parse_page 在**非法 JSON**(昵称/标签落单反斜杠)上走正则兜底,仍能抠出
    roomId + hasNextPage(个别坏页不中断整轮遍历);
  · Discovery.sweep 的分页终止/去重/护栏:hasNextPage==0 停、空页停、跨页去重、
    max_pages 护栏、取页失败(None)即止并标 stopped_by="error"。
遍历测试用 monkeypatch 替换 _fetch_page 返回预制页,完全不触网。
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.discovery import Discovery, parse_page  # noqa: E402


# ── parse_page ────────────────────────────────────────────────────────────────
def _page_json(room_ids, has_next):
    return json.dumps({
        "code": 0,
        "data": {"hasNextPage": has_next,
                 "list": [{"roomId": r, "nickName": f"nick{r}"} for r in room_ids]},
        "msg": "",
    })


def test_parse_wellformed_json():
    rooms, hnp = parse_page(_page_json([51053698, 51046284, 50952138], 1))
    assert rooms == ["51053698", "51046284", "50952138"]
    assert hnp == 1


def test_parse_hasnextpage_zero():
    rooms, hnp = parse_page(_page_json([], 0))
    assert rooms == []
    assert hnp == 0


def test_parse_dedup_within_page():
    # 同一页内重复 roomId 只保留一次(保序)
    rooms, hnp = parse_page(_page_json([111, 222, 111, 333, 222], 1))
    assert rooms == ["111", "222", "333"]


def test_parse_skips_missing_or_bad_roomid():
    raw = json.dumps({"data": {"hasNextPage": 1, "list": [
        {"roomId": 51053698}, {"roomId": 0}, {"nickName": "no room"},
        {"roomId": "abc"}, {"roomId": 51046284}]}})
    rooms, hnp = parse_page(raw)
    assert rooms == ["51053698", "51046284"]   # 0 / 缺失 / 非数字被剔除


def test_parse_malformed_json_falls_back_to_regex():
    # 上游偶发非法 JSON:标签里落单反斜杠 `\(` 让 json.loads 抛错。
    # 只要 roomId / hasNextPage 两个数值字段可被正则抠出即可(不受字符串转义影响)。
    bad = ('{"code":0,"data":{"hasNextPage":1,"list":['
           '{"roomId":51053698,"label":"hi*\\(x)"},'          # 非法转义 \( → JSON 解析失败
           '{"roomId":51046284,"label":"ok"}]}}')
    # 先确认标准解析确实失败(否则本用例失去意义)
    try:
        json.loads(bad)
        raised = False
    except ValueError:
        raised = True
    assert raised, "构造的样本应当是非法 JSON"
    rooms, hnp = parse_page(bad)
    assert rooms == ["51053698", "51046284"]
    assert hnp == 1


def test_parse_regex_ignores_recomjson_inner_ids():
    # recomJson 是被转义的 JSON 字符串,内部是 starKugouId 等(带 \" ),不应被误当作 roomId。
    bad = ('{"data":{"hasNextPage":1,"list":['
           '{"roomId":51053698,"recomJson":"{\\"starKugouId\\":\\"2514826252\\",'
           '\\"order_id\\":\\"62\\"}","label":"x\\(y"}]}}')   # \( 触发兜底
    rooms, hnp = parse_page(bad)
    assert rooms == ["51053698"]   # 只有顶层 roomId,recomJson 内的 id 不误命中
    assert hnp == 1


# ── Discovery.sweep(monkeypatch _fetch_page,不触网) ──────────────────────────
def _install_pages(disc, pages):
    """pages: dict[int -> raw_text | None]。缺失页返回 None(模拟取页失败/到底)。"""
    async def fake_fetch(page):
        return pages.get(page)
    disc._fetch_page = fake_fetch   # type: ignore[assignment]


async def test_sweep_terminates_on_hasnextpage_zero():
    disc = Discovery(max_pages=50)
    _install_pages(disc, {
        1: _page_json([101, 102], 1),
        2: _page_json([103, 104], 1),
        3: _page_json([105], 0),          # hasNextPage=0 → 到此为止
        4: _page_json([999], 1),          # 不应被读到
    })
    res = await disc.sweep()
    assert res["rooms"] == ["101", "102", "103", "104", "105"]
    assert res["pages"] == 3
    assert res["stopped_by"] == "hasNextPage"
    assert res["truncated"] is False


async def test_sweep_terminates_on_empty_page():
    disc = Discovery(max_pages=50)
    _install_pages(disc, {
        1: _page_json([201, 202], 1),
        2: _page_json([], 1),             # 空 list → 到底(即便 hasNextPage=1)
    })
    res = await disc.sweep()
    assert res["rooms"] == ["201", "202"]
    assert res["stopped_by"] == "empty"


async def test_sweep_dedup_across_pages():
    disc = Discovery(max_pages=50)
    _install_pages(disc, {
        1: _page_json([301, 302], 1),
        2: _page_json([302, 303], 0),     # 302 跨页重复,应去重
    })
    res = await disc.sweep()
    assert res["rooms"] == ["301", "302", "303"]
    assert res["unique"] == 3
    assert res["fetched"] == 4            # 去重前累计条目数


async def test_sweep_max_pages_guard():
    disc = Discovery(max_pages=2)          # 护栏:最多 2 页
    _install_pages(disc, {
        1: _page_json([401], 1),
        2: _page_json([402], 1),           # 仍 hasNextPage=1,但触达护栏即止
        3: _page_json([403], 1),
    })
    res = await disc.sweep()
    assert res["rooms"] == ["401", "402"]
    assert res["pages"] == 2
    assert res["stopped_by"] == "max_pages"
    assert res["truncated"] is True


async def test_sweep_stops_on_fetch_error():
    disc = Discovery(max_pages=50)
    _install_pages(disc, {
        1: _page_json([501, 502], 1),
        # 第 2 页取页失败(None)→ 结束本轮,标 error(下一轮再来)
    })
    res = await disc.sweep()
    assert res["rooms"] == ["501", "502"]
    assert res["stopped_by"] == "error"
    assert res["truncated"] is False
