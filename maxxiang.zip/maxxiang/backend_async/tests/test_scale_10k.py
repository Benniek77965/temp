"""test_scale_10k.py — 「1 万房天花板」的契约守卫(3.4.0 真机审计的三项修复)

本文件把审计中**实地测出来的三个缺陷**钉成回归断言,防止改回去:

  ① 发现遍历必须能覆盖 1 万房,且**不得超过发现锁 TTL**
     实测:在播列表 ~49 房/页、单页 RTT ~390ms → 1 万房 ≈ 204 页。
       · 旧 max_pages=200 → 200×49 ≈ 9800 房,**一到 1 万房就静默截断**;
       · 旧串行翻页 204 页 ≈ 99s > 锁 TTL(=interval_s=60s)→ 锁在遍历途中过期,
         别的副本插队开第二轮并发遍历,把繁星打成惊群。
     守卫:max_pages 足以覆盖 1 万房;sweep 真的并发(用"同时在飞"计数证明,而非计时)。

  ② 并发翻页与串行**逐字段等价**(终止页之后的房绝不采纳)。

  ③ 任务租约必须 > 单任务最坏耗时(令牌等待 + 上游超时),否则慢请求会在返回的
     同一瞬间被别的副本重复领取、**重复打上游**。
"""
from __future__ import annotations

import asyncio
import json
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.discovery import Discovery                      # noqa: E402
from app.settings import Settings                        # noqa: E402
from app.worker import RL_MAX_WAIT_S                     # noqa: E402

# 实地核查所得的上游事实(2026-07,真实遍历 fx1.service.kugou.com 全量分页)
ROOMS_PER_PAGE = 49          # 实测均值(首页 51,末页残页,其余恒 50)
UPSTREAM_CEILING_ROOMS = 10_000


def _page_json(rooms, has_next):
    return json.dumps({"data": {"list": [{"roomId": int(r)} for r in rooms],
                                "hasNextPage": has_next}})


# ── ① 护栏必须够得着 1 万房 ────────────────────────────────────────────────────
def test_max_pages_covers_upstream_ceiling():
    """max_pages × 每页房数 必须覆盖上游 1 万房的天花板,且留有余量。

    旧默认 200 × 49 ≈ 9800 < 10000 —— 恰好卡在门槛上,上游一到 1 万房,
    尾部的房就再也发现不到(stopped_by='max_pages',静默截断)。
    """
    s = Settings()
    reach = s.discovery.max_pages * ROOMS_PER_PAGE
    assert reach >= UPSTREAM_CEILING_ROOMS, (
        f"max_pages={s.discovery.max_pages} 只够 {reach} 房,"
        f"覆盖不到上游 {UPSTREAM_CEILING_ROOMS} 房的天花板")
    assert reach >= UPSTREAM_CEILING_ROOMS * 1.5, "应留 ≥50% 余量,防上游规模上浮即截断"


# ── ① 遍历必须是并发的(否则 204 页 ≈99s > 60s 锁 TTL) ────────────────────────
@pytest.mark.asyncio
async def test_sweep_fetches_pages_concurrently():
    """用「同时在飞的页请求数」证明并发(与机器快慢无关,比计时稳)。

    串行实现的在飞峰值恒为 1;并发实现应达到 page_concurrency。
    """
    disc = Discovery(max_pages=400, page_concurrency=8)
    inflight = 0
    peak = 0

    async def fake_fetch(page):
        nonlocal inflight, peak
        inflight += 1
        peak = max(peak, inflight)
        try:
            await asyncio.sleep(0.01)          # 模拟 RTT
            return _page_json([1000 + page], 1 if page < 40 else 0)
        finally:
            inflight -= 1

    disc._fetch_page = fake_fetch              # type: ignore[assignment]
    res = await disc.sweep()
    assert res["stopped_by"] == "hasNextPage"
    assert peak >= 8, f"翻页仍是串行的(在飞峰值={peak}),1 万房下会超过发现锁 TTL"


@pytest.mark.asyncio
async def test_sweep_concurrency_respects_conn_limit():
    """并发度不得超过连接器上限(否则并发被连接池吞掉,徒增复杂度)。"""
    disc = Discovery(max_pages=100, page_concurrency=64, conn_limit=4)
    assert disc._page_conc == 4


# ── ② 并发翻页与串行逐字段等价:终止页之后的房绝不采纳 ─────────────────────────
@pytest.mark.asyncio
async def test_concurrent_sweep_never_admits_rooms_past_terminator():
    """同一波里,hasNextPage=0 之**后**的页即便已取回,其房也必须被丢弃 ——
    否则并发会引入串行版本绝不会有的"越界房"。"""
    disc = Discovery(max_pages=50, page_concurrency=8)
    pages = {
        1: _page_json([101, 102], 1),
        2: _page_json([103], 0),        # ← 终止页
        3: _page_json([9001], 1),       # 同一波里已被取回,但**不得**采纳
        4: _page_json([9002], 1),
    }

    async def fake(page):
        return pages.get(page)

    disc._fetch_page = fake              # type: ignore[assignment]
    res = await disc.sweep()
    assert res["rooms"] == ["101", "102", "103"]
    # 第 2 页即终止页(hasNextPage=0),故只计 2 页 —— 与串行实现逐字段一致
    assert res["pages"] == 2
    assert res["stopped_by"] == "hasNextPage"
    assert "9001" not in res["rooms"] and "9002" not in res["rooms"]


@pytest.mark.asyncio
async def test_concurrent_sweep_error_stops_and_keeps_prior_rooms():
    """取页失败 → stopped_by='error'(reconcile 据此**跳过离线回收**,
    避免一次网络抖动误伤全量发现房);已采纳的房保留。"""
    disc = Discovery(max_pages=50, page_concurrency=8)
    pages = {1: _page_json([501, 502], 1)}    # 第 2 页起返回 None

    async def fake(page):
        return pages.get(page)

    disc._fetch_page = fake              # type: ignore[assignment]
    res = await disc.sweep()
    assert res["rooms"] == ["501", "502"]
    assert res["stopped_by"] == "error"
    assert res["truncated"] is False


# ── ③ 任务租约 > 单任务最坏耗时 ───────────────────────────────────────────────
def test_task_lease_exceeds_worst_case_task_duration():
    """租约(stale_task_grace_ms)必须 > 令牌等待 + 上游请求超时。

    旧值 15000ms **恰好等于** upstream.request_timeout(15s):一个刚好跑满超时的
    慢请求,租约在它返回的同一瞬间到期 → 任务被别的副本重复领取 → 对同一个房
    **重复打上游**,而这恰恰发生在上游已经很慢的时候(雪上加霜)。
    """
    s = Settings()
    lease_s = s.scheduler.stale_task_grace_ms / 1000.0
    worst_s = RL_MAX_WAIT_S + s.upstream.request_timeout
    assert lease_s > worst_s, (
        f"租约 {lease_s}s ≤ 单任务最坏耗时 {worst_s}s"
        f"(令牌等待 {RL_MAX_WAIT_S}s + 上游超时 {s.upstream.request_timeout}s)"
        f":慢请求会被重复领取、重复打上游")


def test_mainpage_failure_backoff_not_faster_than_healthy_cadence():
    """上游故障中的房,**不应比健康房被打得更勤**。

    一局 = 50s,健康房的 MainPage 节奏就是 ~50s/次。旧的失败退避封顶 30s 意味着
    故障房每 30s 被打一次 —— 比健康房还勤,方向反了(故障时刻恰恰最该收敛请求)。
    """
    from app.constants import END_OFFSET_MS
    from app.worker import MP_FAIL_BACKOFF_CAP_MS
    assert MP_FAIL_BACKOFF_CAP_MS >= END_OFFSET_MS, (
        f"MainPage 失败退避封顶 {MP_FAIL_BACKOFF_CAP_MS}ms < 一局 {END_OFFSET_MS}ms:"
        f"上游故障时反而比健康房打得更勤")


# ── ③ 💎稀有日志必须是真·低频(否则万房下淹没高层日志) ─────────────────────────
def test_rare_log_threshold_is_actually_rare():
    """官方概率实测:倍率 ≥250 的妖兽合计 **12%** 的出怪(白虹骥 6.5 + 焚天雀 3.5
    + 沧溟龙 2.0)。1 万房 ≈200 局/s → 24 行 INFO/s ≈ 200 万行/天,与「稳态日志量与
    房间数解耦」的设计声明矛盾,还会把 janitor/discovery/retention/WARNING 挤出
    json-file 轮转窗口。阈值须使 INFO 占比 ≤5%。"""
    official_prob = {10: 20.0, 50: 16.0 + 16.0 + 16.0, 100: 10.0 + 10.0,
                     250: 6.5, 330: 3.5, 500: 2.0}
    s = Settings()
    rate = sum(p for mult, p in official_prob.items()
               if mult >= s.rare_log_multiplier)
    assert rate <= 5.0, (
        f"rare_log_multiplier={s.rare_log_multiplier} 会让 {rate}% 的出怪打 INFO"
        f"(1 万房 ≈{200 * rate / 100:.0f} 行/s),称不上「稀有」")


# ── ③b 租约下限钳:历史配置版本(config_revisions boot 覆盖)灌回旧值也打不破不变量 ──
def test_claim_grace_floor_clamps_stored_old_values():
    """配置中枢的历史持久快照可能存着 3.4.0 之前的旧租约 15000 并在 boot 时覆盖默认。
    若按字面生效,就把已修复的 P0(租约 ≤ 上游超时 → 慢请求被重复领取、重复打上游)
    原样灌回来 —— 管理台校验只拦新写入,拦不住历史版本,故代码侧钳底
    (与 upstream.award_max_retries 的 eff_max 钳同一先例)。"""
    from app.worker import effective_claim_grace_ms
    s = Settings()
    assert effective_claim_grace_ms(s) == 30000            # 默认值:高于下限,原样生效

    s.scheduler.stale_task_grace_ms = 15000                # 模拟历史 revision 灌回旧值
    floor = int((RL_MAX_WAIT_S + s.upstream.request_timeout) * 1000) + 2000
    assert effective_claim_grace_ms(s) == floor >= 25000   # 被钳到下限,不变量守住

    s.upstream.request_timeout = 30.0                      # 运维调大超时 → 下限自动跟着抬
    assert effective_claim_grace_ms(s) == int((RL_MAX_WAIT_S + 30.0) * 1000) + 2000

    s.scheduler.stale_task_grace_ms = 120_000              # 往大调不受限(只影响崩溃重投延迟)
    assert effective_claim_grace_ms(s) == 120_000


# ── ④ 大批量 Redis 写路径分块后语义不变(1 万房冷启动的整体停顿摊平) ──────────────
import os as _os

_REDIS_URL = _os.environ.get("STA_TEST_REDIS_URL", "")
_needs_redis = pytest.mark.skipif(not _REDIS_URL,
                                  reason="需要 Redis(设 STA_TEST_REDIS_URL)")


@_needs_redis
@pytest.mark.asyncio
async def test_bulk_registry_and_spread_chunked_semantics():
    """add_rooms_bulk / schedule_many 分块(3.4.0)后,跨块语义必须与旧的单事务
    版本一致:全量入册、别名保留、挂起清净、spread 铺满窗口、反向索引完整。
    2500 项 > 分块 1000 → 恰好跨 3 个块,覆盖块边界。"""
    from app.redis_bus import (RedisBus, K_ROOMS_PENDING, K_SCHED_ROOMS,
                               task_mainpage)
    bus = RedisBus(_REDIS_URL)
    await bus.r.flushdb()

    rooms = [str(60_000_000 + i) for i in range(2500)]
    # 预置一部分挂起(验证跨块 HDEL 清净)
    await bus.pending_add_bulk(rooms[::7])

    await bus.add_rooms_bulk([(r, "别名" + r) for r in rooms])
    assert set(await bus.active_rooms()) == set(rooms)          # 全量入册
    assert await bus.alias_of(rooms[0]) == "别名" + rooms[0]     # 首块 meta
    assert await bus.alias_of(rooms[-1]) == "别名" + rooms[-1]   # 末块 meta
    assert await bus.r.hlen(K_ROOMS_PENDING) == 0               # 挂起全清(跨块)

    await bus.schedule_spread([task_mainpage(r) for r in rooms], 1_000_000, 60_000)
    assert await bus.r.zcard("sched") == 2500                   # 任务齐
    assert await bus.r.scard(K_SCHED_ROOMS) == 2500             # 反向索引齐(跨块)
    scores = await bus.r.zrange("sched", 0, -1, withscores=True)
    span = max(sc for _, sc in scores) - min(sc for _, sc in scores)
    assert span >= 60_000 * 0.9                                 # 铺满窗口(错峰不因分块折损)
    assert min(sc for _, sc in scores) >= 1_000_000

    await bus.close()
