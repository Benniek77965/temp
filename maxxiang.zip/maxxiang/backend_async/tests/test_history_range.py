"""
test_history_range.py — /api/rooms/{room}/history 的 3.6.0 区间语义回归守卫
================================================================================
背景:web.room_history 的 until 区间路径(半开区间 [since, until)、invalid_range
400、负值防呆、冻结窗 immutable 缓存头)此前**没有任何自动化测试**——其中
「since<until<0 组合绕过区间校验、却给无上界的最新数据错发 immutable」是行内注
自述"二轮复查实地复现后修复"的真实缺陷,修完一直裸奔。本文件逐条钉死:

  · until ≤ since(均正)→ 400 invalid_range,**不触 DB**;
  · 负 since / 负 until → until 视同未指定:DB 收到 until=0(其启用判据 >0),
    响应为**普通 dict**(无任何缓存头对象)—— 负值组合绝不能再命中冻结头;
  · 区间上界早于 now−1h(冻结窗)→ JSONResponse 且
    Cache-Control: public, max-age=604800, immutable;
  · 区间含"现在"→ 普通 dict(不加缓存头);until=0 旧行为同样普通 dict;
  · since / until / limit 原样透传 DB(半开区间语义由 db.history 落地,
    本层只负责解析/校验/回显 —— 透传即契约)。

夹具风格与 test_curated_idle 的 Web 层同款:monkeypatch web.ST + 直调端点函数,
passive="1" 走既有「只读不拉起监控」豁免,避免 _touch_room 依赖 bus。
DB 为捕参假件且恒回非空行 —— 绕开 room_history 的「首见宽限」6s 等待
(rows 非空即跳过,该等待逻辑不在本文件被测范围)。
"""
from __future__ import annotations

import json
import time

import pytest

from starlette.responses import JSONResponse


class _CapDb:
    """捕参假件:history 记录 (room_id, since, limit, until) 并回一条合法行。"""

    def __init__(self):
        self.calls: list[tuple] = []

    async def history(self, room_id, since=0, limit=80, until=0):
        self.calls.append((str(room_id), int(since), int(limit), int(until)))
        # round_id 取 1h 前:字段齐全即可,_round_from_row 只需 round_id 必填
        return [{"round_id": int(time.time() * 1000) - 3_600_000,
                 "custom_id": 5, "official_id": None, "beast_name": "玄兵猿",
                 "multiplier": 100, "draw_ms": None, "source": "test"}]


class _Star:
    async def canon(self, room):
        return str(room), True


@pytest.fixture()
def hist_wired(monkeypatch):
    import app.web as web
    st = type("ST", (), {})()
    st.db, st.star = _CapDb(), _Star()
    monkeypatch.setattr(web, "ST", st)
    return web, st.db


async def _call(web, room="321", **kw):
    kw.setdefault("passive", "1")          # 豁免 _touch_room(bus 未挂,亦非被测)
    kw.setdefault("limit", 80)             # 直调端点函数:绕开 FastAPI Query 默认对象
    return await web.room_history(room, **kw)


@pytest.mark.asyncio
async def test_until_le_since_rejected_400_without_db(hist_wired):
    web, db = hist_wired
    resp = await _call(web, since=100, until=50)
    assert isinstance(resp, JSONResponse) and resp.status_code == 400
    assert b"invalid_range" in resp.body
    resp2 = await _call(web, since=100, until=100)     # 相等同样非法(半开区间空集)
    assert isinstance(resp2, JSONResponse) and resp2.status_code == 400
    assert db.calls == []                              # 校验失败不触 DB


@pytest.mark.asyncio
async def test_negative_until_is_unspecified_and_never_immutable(hist_wired):
    """二轮复查缺陷的回归钉:since<until<0 组合曾绕过校验、被 db 忽略上界,
    却命中冻结头 —— 给"无上界的最新数据"错发 immutable。现负 until 一律
    钳 0(视同未指定):普通 dict 响应、DB 收 until=0、区间校验不误伤。"""
    web, db = hist_wired
    resp = await _call(web, since=-5, until=-1)
    assert isinstance(resp, dict) and resp["ok"] is True      # dict = 无任何缓存头
    assert resp["until"] == "0"                               # 回显同为"未指定"
    assert db.calls[-1][3] == 0                               # DB 收到 until=0
    # 单独的负 until(since=0)同语义
    resp2 = await _call(web, since=0, until=-7)
    assert isinstance(resp2, dict) and db.calls[-1][3] == 0


@pytest.mark.asyncio
async def test_frozen_window_gets_immutable_header(hist_wired):
    web, _ = hist_wired
    now = int(time.time() * 1000)
    until = now - 2 * 3_600_000                     # 上界早于 now−1h → 冻结窗
    resp = await _call(web, since=until - 500_000, until=until)
    assert isinstance(resp, JSONResponse) and resp.status_code == 200
    cc = resp.headers.get("cache-control", "")
    assert "immutable" in cc and "max-age=604800" in cc and "public" in cc


@pytest.mark.asyncio
async def test_live_window_and_legacy_have_no_cache_header(hist_wired):
    web, db = hist_wired
    now = int(time.time() * 1000)
    resp = await _call(web, since=0, until=now + 50_001)      # 含"现在"的窗
    assert isinstance(resp, dict)                             # dict = 不加缓存头
    resp2 = await _call(web, since=0, until=0)                # until 缺省旧行为
    assert isinstance(resp2, dict)
    assert db.calls[-1][3] == 0


@pytest.mark.asyncio
async def test_params_pass_through_to_db_verbatim(hist_wired):
    """since/until/limit 原样透传(半开区间由 db.history 落地);回显字符串化。"""
    web, db = hist_wired
    now = int(time.time() * 1000)
    since, until, limit = now - 9 * 50_001, now - 3 * 50_001, 7
    resp = await _call(web, since=since, until=until, limit=limit)
    assert db.calls[-1] == ("321", since, limit, until)
    body = resp.body if isinstance(resp, JSONResponse) else None
    if body is not None:                                       # 冻结与否取决于时刻,两态皆合法
        assert str(since).encode() in body and str(until).encode() in body
    else:
        assert resp["since"] == str(since) and resp["until"] == str(until)
    assert len((resp if isinstance(resp, dict) else json.loads(body))["rounds"]) == 1
