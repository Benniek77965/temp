"""
test_config_registry.py — 注册表 drift-guard(方案 §3.3 配套纪律其二)
================================================================================
强制 `config_registry.REGISTRY` 与 `settings.Settings` 字段集合**双向一致**:
任何一侧新增/删除参数而未同步登记即失败;并断言注册表 default 与 dataclass
默认逐项相等(prediction/容器项除外,其默认列自 config.yaml 基线)。
纯静态,零外部依赖。
"""
from __future__ import annotations

import dataclasses
import os

import yaml

from app import config_registry as reg
from app.settings import (AdminCfg, AdmissionCfg, AuthCfg, DiscoveryCfg, HistModeCfg,
                          LiveStatusCfg, RateLimitCfg, RetentionCfg,
                          SchedulerCfg, Settings, UpstreamCfg, UserAuthCfg)

_SUBS = {"upstream": UpstreamCfg, "scheduler": SchedulerCfg,
         "ratelimit": RateLimitCfg, "admission": AdmissionCfg,
         "retention": RetentionCfg, "discovery": DiscoveryCfg,
         "livestatus": LiveStatusCfg,
         "histmode": HistModeCfg, "auth": AuthCfg, "userauth": UserAuthCfg,
         "admin": AdminCfg}                      # 5.3.0:管理台入口(部署项,只读)
_CONTAINERS = {"prediction", "custom_beast_ids", "rooms", "room_aliases"}


def _settings_paths() -> set:
    """展平 Settings 字段为点分路径(prediction 展开为注册表既定 32 键)。"""
    out = set()
    for f in dataclasses.fields(Settings):
        if f.name in _SUBS:
            for sf in dataclasses.fields(_SUBS[f.name]):
                out.add(f"{f.name}.{sf.name}")
        elif f.name == "prediction":
            out.update(f"prediction.{k}" for k in reg.PREDICTION_KEYS)
        else:
            out.add(f.name)
    return out


def test_registry_covers_all_settings_fields():
    missing = _settings_paths() - set(reg.REGISTRY)
    assert not missing, f"Settings 有字段未登记进注册表: {sorted(missing)}"


def test_registry_has_no_orphan_keys():
    orphans = set(reg.REGISTRY) - _settings_paths()
    assert not orphans, f"注册表存在 Settings 之外的键: {sorted(orphans)}"


def test_registry_defaults_match_dataclass_defaults():
    """default 列必须与代码默认逐项一致 —— 保证「默」印所示即事实。"""
    s = Settings()
    bad = []
    for key, f in reg.REGISTRY.items():
        head = key.split(".", 1)[0]
        if head in _CONTAINERS or key in _CONTAINERS:
            continue
        cur = reg.get_path(s, key) if "." not in key else \
            getattr(getattr(s, head), key.split(".", 1)[1])
        if cur != f.default:
            bad.append((key, cur, f.default))
    assert not bad, f"注册表默认值与 dataclass 漂移: {bad}"


def test_registry_defaults_match_config_yaml_for_all_prediction_keys():
    """注册表 default 必须与 config.yaml prediction 现值**逐项**一致。

    此前只有 tests/test_showcase_rotate.py::test_config_three_way_consistency
    对 `sc_*` 全组钉了这条，其余预测键裸奔 —— 实测 4.9.6 时
    fr_cold_min / fr_rare_min / fr_ret_min 三项已漂（注册表 0.1232/0.018/8.624
    对 config.yaml 的 0.0/0.0/0.0）。

    为什么必须一致：注册表 default 是「重置/回落基线」的取值来源
    （config_center.apply_snapshot 的 `b.get(key, f.default)`、
    config_registry.get_path 的 `(settings.prediction or {}).get(rest, default)`）。
    漂了以后，管理台上「默」印所示与实际生效值不是一回事 —— 正是本仓库反复
    警告的「运维以为改生效了其实没有」同款病，只是方向相反。
    """
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "config.yaml")
    pred = (yaml.safe_load(open(path, encoding="utf-8")) or {}).get("prediction") or {}
    bad = []
    for k in reg.PREDICTION_KEYS:
        d = reg.REGISTRY[f"prediction.{k}"].default
        y = pred[k]
        if isinstance(d, bool) or isinstance(y, bool):
            same = int(bool(d)) == int(bool(y))
        elif isinstance(d, (int, float)) and isinstance(y, (int, float)):
            same = abs(float(d) - float(y)) < 1e-9
        else:
            same = str(d) == str(y)
        if not same:
            bad.append((k, d, y))
    assert not bad, ("注册表 default 与 config.yaml 漂移(键, 注册表default, yaml值): "
                     f"{bad}")


#: 引擎 dataclass 缺省**故意**不等于部署刻度的键 —— 每一项都必须在这里写明理由。
#: 不在此表的预测键,三层(引擎缺省 / 注册表 default / config.yaml)必须同值。
_INTENTIONAL_ENGINE_TIERING = {
    # 4.9.7:anti_stubborn / repeat_guard 已随 showcase_rotate 同批翻面(三者是
    # predictor_bridge._DEAD_SWITCH_KEYS 同一组,必须同进同退),不再是分层项。
    # 现在只剩这一项 —— 裸引擎缺省与部署刻度的差异面收敛到单键。
    # 4.9.8:fr_share_floors 已从本表移除 —— 部署侧同批把逐号地板清空,与引擎缺省
    # (空串)重新一致,不再构成分层。本表现在为空,即**三层完全对齐、零例外**。
    # (本测试的第二条断言 `assert not stale` 会在还留着已对齐的键时变红,
    #  所以这里必须删,不能只把它注释掉留在 dict 里。)
}


def test_prediction_defaults_match_engine_dataclass_except_documented_tiering():
    """预测段的注册表 default 必须等于引擎 dataclass 缺省,例外须登记在案。

    补的是 test_registry_defaults_match_dataclass_defaults 的盲区:那条把
    `prediction` 整个放进 _CONTAINERS 跳过了(Settings.prediction 是 dict,取不到
    引擎字段),于是预测段的三层一致性从来没人查。4.9.7 复查实测后果:
    fr_cold_min / fr_rare_min / fr_ret_min 曾**三层各持一值**
    (引擎 0.1232/0.018/8.624、config.yaml 与注册表 0.0/0.0/0.0)。

    「引擎缺省 ≠ 部署刻度」这种分层本身是本仓库的既有设计(引擎出厂即原版姿态,
    部署侧显式开启),不该一律禁止 —— 但必须**显式登记**,否则漂移与设计
    长得一模一样,复查时分不出哪个是有意的。
    """
    import spell_tamer_monitor as _E
    fields = _E.PredictionConfig.__dataclass_fields__
    bad, stale = [], []
    for k in reg.PREDICTION_KEYS:
        if k not in fields:
            continue                     # 后端消费的键(replay_* 等)不在引擎里,正常
        d = reg.REGISTRY[f"prediction.{k}"].default
        e = getattr(_E.PredictionConfig(), k)
        if isinstance(d, bool) or isinstance(e, bool):
            same = int(bool(d)) == int(bool(e))
        elif isinstance(d, (int, float)) and isinstance(e, (int, float)):
            same = abs(float(d) - float(e)) < 1e-9
        else:
            same = str(d) == str(e)
        if same and k in _INTENTIONAL_ENGINE_TIERING:
            stale.append(k)
        elif not same and k not in _INTENTIONAL_ENGINE_TIERING:
            bad.append((k, e, d))
    assert not bad, ("预测键三层漂移(键, 引擎缺省, 注册表default);若为有意分层,"
                     f"请登记进 _INTENTIONAL_ENGINE_TIERING 并写明理由: {bad}")
    assert not stale, (f"这些键已不再分层,请从 _INTENTIONAL_ENGINE_TIERING 移除: {stale}")


#: 后端消费、引擎 dataclass 里**本就没有**的预测键 —— 每一项都要写明谁在消费它。
#: 不在此表、又不是引擎字段的键 = **幽灵键**:管理台照常渲染、运维照常改,
#: 而没有任何代码会读它(桥构造那句 `if k in pc_fields` 会当场滤掉)。
#: 值为 (消费方说明, 期望在 app/ 下被引用) —— 由下面的测试实地核验,写错会红。
#: 〔4.9.7 复查更正:replay_warmup 原写「消费方 app/pred_replay.py」是错的,
#:   实测 app/ 下只有 worker.py 读它(2075/2095 两处),pred_replay 是被传参。
#:   归属写错本身不致命,但这张表的价值就在于"写明谁在消费",错了等于没写。〕
_NON_ENGINE_PREDICTION_KEYS = {
    "replay_enabled": ("命中率补算总开关;消费方 app/worker.py::_pred_replay", True),
    "replay_warmup": ("补算热身局数;app/worker.py 读出后传给 pred_replay.replay_window", True),
    "replay_interval_s": ("补算扫描周期;消费方 app/worker.py::_pred_replay", True),
    "replay_batch": ("单轮补算房间数;消费方 app/worker.py::_replay_sweep", True),
    "replay_cooldown_s": ("同房补算冷却;消费方 app/worker.py::_replay_sweep", True),
    # ⚠ 4.9.7 复查实地核查发现的**存量幽灵键**(非本次引入,故只登记不删除):
    #   全仓 grep 只剩 config.yaml / 本注册表 / 两个引擎 JSON / 测试夹具里的赋值,
    #   以及 spell_tamer_monitor.py 一句「hot_rotate / showcase_q 同款病,故推翻重做」
    #   的注释 —— 引擎 PredictionConfig **没有这个字段**,app/ 下也**零引用**(已实测)。
    #   即:管理台上这个旋钮改了完全没效果,正是本仓库反复警告的那个病。
    #   本轮不动它的理由:删键要同批改 config.yaml + 注册表 + 两个 JSON + 4 个测试
    #   夹具,与「把默认改回 showcase」是两件事,混在一起会让回滚面变大。
    #   处置建议(下一轮单独做):从 PREDICTION_KEYS 与 config.yaml 同批删除。
    "showcase_q": ("【幽灵键】引擎无此字段、app/ 下零引用;存量遗留,待单独一轮清理", False),
}


def test_every_registered_prediction_key_has_a_consumer():
    """登记的预测键必须**要么是引擎字段,要么在 _NON_ENGINE_PREDICTION_KEYS 里写明消费方**。

    补的是 test_prediction_defaults_match_engine_dataclass_except_documented_tiering
    的第二个盲区:那条对「引擎里没有的键」是 `if k not in fields: continue` —— 静默跳过。
    于是「后端消费的 replay_*」和「谁都不消费的幽灵键」在它眼里长得一模一样,
    showcase_q 就是这样活下来的(实测:全仓零消费点)。

    幽灵键的危害与本仓库反复点名的 hot_rotate 完全同款:管理台照常渲染、`danger` 印
    照常亮、运维照常改,而没有任何代码读它 —— 只是方向相反(不是「改了不生效」,
    是「这个旋钮压根没接线」)。把静默跳过换成显式登记,新增幽灵键当场红。
    """
    import spell_tamer_monitor as _E
    fields = set(_E.PredictionConfig.__dataclass_fields__)
    ghosts = [k for k in reg.PREDICTION_KEYS
              if k not in fields and k not in _NON_ENGINE_PREDICTION_KEYS]
    assert not ghosts, (
        "这些预测键既不是引擎字段,也没在 _NON_ENGINE_PREDICTION_KEYS 里写明消费方 "
        f"—— 管理台会渲染一个没接线的旋钮: {ghosts}")
    stale = [k for k in _NON_ENGINE_PREDICTION_KEYS
             if k in fields or k not in reg.PREDICTION_KEYS]
    assert not stale, (
        f"这些键已不再是「引擎外的键」(已进引擎或已下线),请从表里移除: {stale}")

    # ── 实地核验「消费方」这一栏不是空口白话 ────────────────────────────────────
    # 4.9.7 复查时本表的 replay_warmup 一栏写的是「消费方 app/pred_replay.py」,
    # 实测 app/ 下只有 worker.py 读它 —— 归属写错,而这张表的全部价值就在这一栏。
    # 所以这里真的去 app/ 里搜一遍:声称有消费方的必须搜得到,声称是幽灵的必须搜不到。
    import glob
    import re as _re
    app_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "app")
    src = ""
    for p in glob.glob(os.path.join(app_dir, "**", "*.py"), recursive=True):
        if os.path.basename(p) == "config_registry.py":
            continue                     # 注册表自身的登记不算消费
        src += open(p, encoding="utf-8").read()
    wrong = []
    for k, (why, expect_used) in _NON_ENGINE_PREDICTION_KEYS.items():
        used = bool(_re.search(r"[\"']%s[\"']" % _re.escape(k), src))
        if used != expect_used:
            wrong.append((k, "app/ 下有引用" if used else "app/ 下零引用", why))
    assert not wrong, (
        "消费方声明与实地核查不符(键, 实测, 表里写的);声称有消费方却搜不到 = 归属写错"
        "或该键已变成幽灵,声称是幽灵却搜得到 = 已接线,请从幽灵登记里移除: "
        f"{wrong}")


def test_prediction_keys_match_config_yaml_baseline():
    """PREDICTION_KEYS 必须与 config.yaml prediction: 板块键集合一致。"""
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "config.yaml")
    raw = yaml.safe_load(open(path, encoding="utf-8")) or {}
    yaml_keys = set((raw.get("prediction") or {}).keys())
    assert yaml_keys == set(reg.PREDICTION_KEYS), (
        f"config.yaml prediction 键与注册表漂移: "
        f"仅 yaml={sorted(yaml_keys - set(reg.PREDICTION_KEYS))} "
        f"仅注册表={sorted(set(reg.PREDICTION_KEYS) - yaml_keys)}")


def test_flags_sanity():
    """标记体检:敏感/危险/只读/预留 的关键项不因手滑丢标。"""
    R = reg.REGISTRY
    assert R["auth.ticket"].sensitive and R["auth.ticket"].danger
    assert R["auth.ticket"].no_reset and R["auth.uid"].no_reset
    assert R["retention.days"].danger
    assert R["activity_id"].danger
    assert R["discovery.enabled"].danger
    assert all(R[f"prediction.{k}"].danger for k in reg.PREDICTION_KEYS)
    for k in ("pg_dsn", "redis_url", "static_dir", "accounts_path",
              "auth_cookie_file", "custom_beast_ids", "rooms", "room_aliases"):
        assert R[k].readonly, f"{k} 应为只读(不接受运行时覆盖)"
    assert R["upstream.fetch_lamp"].hot == reg.RESERVED
    # 每项都归属既定板块
    assert {f.section for f in R.values()} == set(reg.SECTIONS)


def test_env_mapping_matches_settings_reads():
    """ENV 映射双向一致:settings.py 实际读取的 STA_ 变量 ⇄ 注册表 env 声明。
    (「环」印所示即事实;新增 env 覆盖而漏登记、或登记幽灵变量,皆在此拦下。)"""
    import re
    src_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "app", "settings.py")
    src = open(src_path, encoding="utf-8").read()
    # 4.0.0:注册系统引入含数字的变量名(STA_USER_REG_CHAL_IP_10M / _NAME_10M,
    # 命名随 REGISTER-SYSTEM.md 配置表)—— 扫描正则放宽到 [A-Z0-9_],
    # 否则数字处截断会造成「声明了却扫不到」的假红。
    read_by_settings = set(re.findall(r'"(STA_[A-Z][A-Z0-9_]*)"', src)) \
        - {"STA_CONFIG", "STA_REDIS_MAX_CONN"}   # 路径参数与历史别名单列
    # 5.2.0 预览版的登录验证码写法:只在启动时折算进共用那组(STA_USER_REG_CAPTCHA*),
    # 不是独立参数 —— 同属「历史别名」,不进参数中心(进了反而又是两组并列、易配串)。
    read_by_settings -= {"STA_USER_LOGIN_CAPTCHA_MODE", "STA_USER_LOGIN_CAPTCHA_ID",
                         "STA_USER_LOGIN_CAPTCHA_KEY", "STA_USER_LOGIN_CAPTCHA_SECRET_ID",
                         "STA_USER_LOGIN_CAPTCHA_SECRET_KEY"}
    declared = {f.env for f in reg.REGISTRY.values() if f.env}
    assert read_by_settings == declared, (
        f"仅 settings 读={sorted(read_by_settings - declared)} "
        f"仅注册表声明={sorted(declared - read_by_settings)}")


def test_hooks_declared_for_hook_level():
    """HOOK 级别的项必须声明钩子标识;HOT 级不得挂钩子外的重活。"""
    for key, f in reg.REGISTRY.items():
        if f.hot == reg.HOOK:
            assert f.hook, f"{key} 标为 HOOK 但未声明 hook 标识"
