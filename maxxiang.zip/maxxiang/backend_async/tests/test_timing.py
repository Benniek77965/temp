"""
test_timing.py — 服务器钟外推与「倒计时回溯」缺陷的症状级回归(纯函数,零依赖)
================================================================================
背景(用户实测症状,三症同源):
  · 观测台与游戏差 ±10s;
  · 游戏备战倒计时归零后,观测台突然回溯到「布置法术」倒计时;
  · 倒计时还剩 ~20s 就出了出怪数据。

根因:后端曾把**快照里的 serverNowMs(抓取那一刻的钟,陈旧 0~50s)**当作
「当前服务器时刻」经 SSE(connected/heartbeat)与出怪推送下发;前端 calibrate()
把每拍 serverNowMs−Date.now() 以 EMA(α=0.2)融入校时 —— 出怪推送的钟恒定陈旧
~42.5s(快照钟=本局起点抓 MainPage 时刻),单拍即把前端时钟回拖 ~8.5s,恰好把
相位从「出怪」拖回「备战/布置」,与出数据同一瞬间发生。与房间数量、QPS 无关。

修复:redis_bus.extrapolate_server_now(snap, host_now) = host_now + 实测钟差,
三个消费点(SSE hello/heartbeat、出怪推送、crawler/status)统一改用。本文件:
  ① 外推函数的行为契约;② 用真实相位常量把「旧行为必现回溯、新行为不回溯」
     写成断言 —— 症状级防回归。
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.constants import DRAW_OFFSET_MS, SPELL_OFFSET_MS  # noqa: E402
from app.redis_bus import extrapolate_server_now  # noqa: E402


# ── ① 外推函数契约 ────────────────────────────────────────────────────────────
def test_extrapolate_uses_offset_not_stale_clock():
    host = 1_800_000_042_500
    snap = {"serverNowMs": str(host - 42_500),   # 抓取时刻的陈旧钟(本局起点)
            "serverOffsetMs": "123"}             # 实测钟差(快照按字符串存)
    assert extrapolate_server_now(snap, host) == host + 123   # 用钟差,不用陈旧钟


def test_extrapolate_negative_offset_and_defaults():
    host = 1_800_000_000_000
    assert extrapolate_server_now({"serverOffsetMs": -250}, host) == host - 250
    # 空快照 / 缺字段 / 脏值:钟差按 0(host 钟),永不抛错、永不用陈旧值
    assert extrapolate_server_now({}, host) == host
    assert extrapolate_server_now({"serverNowMs": host - 40_000}, host) == host
    assert extrapolate_server_now({"serverOffsetMs": "abc"}, host) == host
    assert extrapolate_server_now(None, host) == host


# ── ② 症状级回归:出怪瞬间的相位不得回溯 ──────────────────────────────────────
def _phase(t_in_round_ms: int) -> str:
    """前端相位模型(assets/app.js tick 同式):<35s 布置,35~40s 备战,≥40s 出怪。"""
    if t_in_round_ms < SPELL_OFFSET_MS:
        return "cast"
    if t_in_round_ms < DRAW_OFFSET_MS:
        return "seal"
    return "draw"


def _ema(prev_offset: float, server_now: int, wall_now: int, a: float = 0.2) -> float:
    """前端 calibrate() 同式:clockOffset = 0.8*prev + 0.2*(serverNowMs - Date.now())。"""
    raw = server_now - wall_now
    return prev_offset * 0.8 + raw * a


def test_draw_push_does_not_rewind_phase():
    start = 1_800_000_000_000                    # 本局起点(=roundId)
    true_offset = 0                              # 设主机钟与服务器钟同步(不失一般性)
    wall_draw = start + DRAW_OFFSET_MS + 2_500   # 出怪推送抵达时刻(draw+抓取延迟)
    snap = {"serverNowMs": start,                # 快照钟=起点抓 MainPage 那一刻
            "serverOffsetMs": true_offset}

    # 旧行为:下发陈旧快照钟 → 一拍 EMA 把前端时钟回拖 ~8.5s → 相位从 draw 回溯 seal
    off_old = _ema(true_offset, int(snap["serverNowMs"]), wall_draw)
    t_old = (wall_draw + off_old) - start
    assert _phase(t_old) != "draw", "旧行为应必现回溯(本断言钉住缺陷可复现的前提)"
    assert _phase(t_old) in ("seal", "cast")     # 正是用户看到的「回溯到备战/布置」

    # 新行为:下发外推钟 → EMA 输入≈真实钟差 → 相位保持 draw,不回溯
    off_new = _ema(true_offset, extrapolate_server_now(snap, wall_draw), wall_draw)
    t_new = (wall_draw + off_new) - start
    assert _phase(t_new) == "draw"
    assert abs(off_new - true_offset) < 1        # 校时误差 <1ms(数学恒等)


def test_heartbeat_sawtooth_eliminated():
    """心跳(20s 一拍)吃陈旧钟会形成累积回拖;外推钟下多拍后偏移仍钉在真值。"""
    start = 1_800_000_000_000
    snap = {"serverNowMs": start, "serverOffsetMs": 0}
    off_old = off_new = 0.0
    for beat in (20_000, 40_000):                # 本局内两拍心跳(t=20s / 40s)
        wall = start + beat
        off_old = _ema(off_old, int(snap["serverNowMs"]), wall)      # 旧:陈旧钟
        off_new = _ema(off_new, extrapolate_server_now(snap, wall), wall)  # 新:外推
    assert off_old < -10_000        # 旧行为:两拍即被回拖 >10s(±10s 抖动的来源)
    assert abs(off_new) < 1         # 新行为:恒贴真值
