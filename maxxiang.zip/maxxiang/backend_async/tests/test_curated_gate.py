"""test_curated_gate.py — 预测管线的「策展闸」(3.4.5)

真机现场:自动发现带来 6891 个后台房,**前端一个都不展示**(_visible_rooms 恒过滤),
但 worker 为**每一个**房、**每一局**都跑完整集成预测:
    db.sequence(拉 ~1727 行序列) 1.8ms + run_prediction(纯 CPU,持 GIL) 3.7ms ≈ 5.5ms
6891 房 = 138 局/s → **预测独占 0.83 CPU 核 + 给 PG 灌 23.8 万行/s**,挤掉 consumer
的执行力 → 到期任务领不完(现场:12098 个任务里 10121 个到期未领、最老迟到 79.7s)
→ 出怪与预测**系统性晚一整局**。而这些算力产出的预测**没有任何人看得到**。

闸的语义:发现房只做「抓取+入库」(history/coverage 照常);用户一旦把它加进名录
(monitor/add → discovered_remove),下一局起自动恢复完整预测。
"""
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

_REDIS = os.environ.get("STA_TEST_REDIS_URL", "")
_needs = pytest.mark.skipif(not _REDIS, reason="需要 Redis")


@_needs
@pytest.mark.asyncio
async def test_is_discovered_is_o1_and_correct():
    from app.redis_bus import RedisBus
    bus = RedisBus(_REDIS)
    await bus.r.flushdb()

    await bus.add_rooms_bulk([("321", "321"), ("50000001", "50000001")])
    await bus.discovered_seen_bulk(["50000001"])         # 只有它是"发现房"

    assert await bus.is_discovered("50000001") is True   # 后台房 → 不跑预测
    assert await bus.is_discovered("321") is False       # 策展房 → 照常预测
    assert await bus.is_discovered("99999999") is False  # 不存在 → 按策展房(宁可多算)

    # 转正:用户把它加进名录 → 闸自动放行
    await bus.discovered_remove_bulk(["50000001"])
    assert await bus.is_discovered("50000001") is False

    await bus.close()


@_needs
@pytest.mark.asyncio
async def test_is_discovered_never_raises():
    """判不出来(Redis 抖动)必须回 False = 按策展房走 —— 宁可多算一次预测,
    绝不能因为一次 Redis 异常就把用户在看的房的预测停掉。"""
    from app.redis_bus import RedisBus

    class _Boom:
        async def hexists(self, *a):
            raise RuntimeError("redis down")

    bus = RedisBus.__new__(RedisBus)
    bus.r = _Boom()                                      # type: ignore[assignment]
    assert await bus.is_discovered("321") is False
