"""
test_db_bulk.py — 批量 rounds INSERT 构造(纯函数,无需 PG)
================================================================================
`_build_bulk_rounds_sql` 是冷启动回填从『逐局 INSERT』改『单房一次多行 INSERT』
的核心。纯函数化便于在无 PG 环境断言:
  · 占位符 $1..$N 连续且 N = 11 × 行数;args 展平顺序与列对齐;
  · start_ms == round_id、draw_ms == round_id + DRAW_OFFSET_MS(与旧 add_round 同);
  · draw_local/date_local 用与实时 award 路径完全相同的格式化(同局两路写出一致);
  · ON CONFLICT (room_id, round_id) DO NOTHING RETURNING round_id(幂等 + 得知新插入);
  · None 字段(official_id/custom_id/multiplier)原样入 args(不被填充成默认)。
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.constants import DRAW_OFFSET_MS                       # noqa: E402
from app.db import _build_bulk_rounds_sql                      # noqa: E402
from app.predictor_bridge import ms_to_date, ms_to_local      # noqa: E402

COLS = 11


def test_placeholders_and_arg_count():
    chunk = [
        {"round_id": 1000, "official_id": 3, "beast_name": "青龙",
         "custom_id": 1, "multiplier": 7, "source": "history"},
        {"round_id": 1001, "official_id": None, "beast_name": "?",
         "custom_id": None, "multiplier": None, "source": "history"},
        {"round_id": 1002, "official_id": 9, "beast_name": "白虎",
         "custom_id": 9, "multiplier": 45, "source": "history"},
    ]
    sql, args = _build_bulk_rounds_sql("321", chunk, DRAW_OFFSET_MS)
    # 占位符总数 = 11 × 行数,且 1..N 连续
    assert len(args) == COLS * len(chunk)
    for k in range(1, COLS * len(chunk) + 1):
        assert f"${k}" in sql
    assert f"${COLS * len(chunk) + 1}" not in sql
    # 每行一个 VALUES 组
    assert sql.count("(") >= len(chunk)
    assert "ON CONFLICT (room_id, round_id) DO NOTHING RETURNING round_id" in sql


def test_time_fields_match_realtime_path():
    rid = 1_700_000_000_000
    chunk = [{"round_id": rid, "official_id": 5, "beast_name": "朱雀",
              "custom_id": 5, "multiplier": 12, "source": "history"}]
    _, args = _build_bulk_rounds_sql("2678075", chunk, DRAW_OFFSET_MS)
    # 列序:room_id, round_id, beast_name, official_id, custom_id, multiplier,
    #       start_ms, draw_ms, draw_local, date_local, source
    (room_id, round_id, beast_name, official_id, custom_id, multiplier,
     start_ms, draw_ms, draw_local, date_local, source) = args
    assert room_id == "2678075"
    assert round_id == rid
    assert start_ms == rid                       # start_ms == round_id
    assert draw_ms == rid + DRAW_OFFSET_MS        # 与旧 add_round 同
    # draw_local/date_local 必须与实时 award 路径逐字节一致
    assert draw_local == ms_to_local(draw_ms, "%Y-%m-%d %H:%M:%S")
    assert date_local == ms_to_date(draw_ms)
    assert beast_name == "朱雀" and official_id == 5 and custom_id == 5


def test_none_fields_preserved_and_name_fallback():
    chunk = [{"round_id": 42, "official_id": None, "beast_name": "",
              "custom_id": None, "multiplier": None, "source": None}]
    _, args = _build_bulk_rounds_sql("100", chunk, DRAW_OFFSET_MS)
    assert args[3] is None      # official_id
    assert args[4] is None      # custom_id
    assert args[5] is None      # multiplier
    assert args[2] == "?"       # 空名兜底 "?"(与旧行为一致)
    assert args[10] == "history"  # source 兜底 "history"
