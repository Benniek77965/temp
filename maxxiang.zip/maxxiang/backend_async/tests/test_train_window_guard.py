"""test_train_window_guard.py — 训练时间窗 / 训练样本上限的守卫(4.9.5 窗口审计)

本轮审计用生产代码路径(window_audit/replay_harness → predictor_bridge →
spell_tamer_monitor)在自带三房库(36,278 局、跨度 167.98h)上做了 27 次全量回放,
落成四条**可被测试钉住**的事实。本文件逐条钉之 —— 它们全部是「不改预测逻辑」的
配置面/观测面约束,不触碰引擎算法。

一、**告警教的路必须走得通**:三处代码(config_center 的截短告警、
    predictor_bridge._warn_train_window_truncated、注册表 max_train 说明)都推荐
    运维「若本就想按局数封顶,把 train_window_hours 设成 0」。4.9.5 之前注册表却把
    该字段钉在 ge=0.1,管理台提交 0 得到「不得小于 0.1」—— 告警教的路自己堵死。
二、**放开 0 之后必须补上真正该拦的那段**:极短窗。实测四码命中
    0.1h=49.03% / 0.2h=45.69% / 1h=50.80%,而四选九随机基线 = 4/9 = 44.44%,
    3~48h 平台为 53.1~53.8%。故 (0, MIN_TRAIN_WINDOW_H) 判 **error** 而非 warning。
三、**补算与实盘必须同口径**:plan_span 在计数制(tw<=0)下若不把 max_train 算进
    回取跨度,回取会塌成 warmup+8 局(实测 warmup=400 时仅 408 局),而实盘
    db.sequence 取的是 max_train 局。
四、**train_n 必须有消费者**:它是「窗口到底喂进去多少局」的唯一实测量,
    4.9.5 之前 backend_async/app/ 里一个消费者都没有。
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app import config_center as cc          # noqa: E402
from app import config_registry as reg       # noqa: E402
from app.constants import (MIN_TRAIN_WINDOW_H, ROUND_STEP,   # noqa: E402
                           rounds_for_hours)
from app.pred_replay import plan_span        # noqa: E402
from app.settings import Settings            # noqa: E402
from tests._srcscan import strip_py_comments  # noqa: E402

CONFIG_YAML = ROOT / "config.yaml"
_TWH = "prediction.train_window_hours"


def _base():
    raw = yaml.safe_load(CONFIG_YAML.read_text(encoding="utf-8")) or {}
    s = Settings()
    s.prediction = dict(raw.get("prediction") or {})
    cc.capture_base(s)
    return raw


def _submit(value):
    """模拟管理台提交一次 train_window_hours,返回 (结构 errors, 语义 errors)。"""
    _base()
    coerced, errors = cc.check_changes({_TWH: value})
    if errors:
        return errors, []
    cand = cc.build_candidate({}, coerced)
    serrs, _warns = cc.semantic_validate(cand, set(coerced))
    return [], serrs


# ───────────── 守卫一:「设成 0」这条建议必须真的可执行 ─────────────
def test_zero_window_is_accepted_because_three_places_recommend_it():
    """0 = 不限时间(退回 max_train 计数窗)必须能从管理台提交成功。

    这一条与下面的 test_the_advice_and_the_bound_stay_consistent 成对:
    一个钉「路走得通」,一个钉「文案与下限不许再次分家」。
    """
    errors, serrs = _submit(0)
    assert not errors, f"结构校验拒绝了 0(注册表 ge 又被抬回去了?):{errors}"
    assert not serrs, f"语义校验拒绝了 0 —— 0 是计数制入口,必须放行:{serrs}"


def test_the_advice_and_the_bound_stay_consistent():
    """凡是文案里推荐「设成 0」的地方,注册表下限就必须允许 0。

    4.9.5 之前正是这两边分家:文案说 0、注册表 ge=0.1。这条测试让它不能再分家 ——
    谁把 ge 抬回 >0 而没同步改掉三处文案,这里当场红。
    """
    f = reg.REGISTRY[_TWH]
    advises_zero = []
    for rel in ("app/config_center.py", "app/predictor_bridge.py",
                "app/config_registry.py"):
        txt = (ROOT / rel).read_text(encoding="utf-8")
        if "设成 0" in txt or "设为 **0**" in txt:
            advises_zero.append(rel)
    assert advises_zero, "三处推荐文案全没了?那本测试的前提已变,请一并复核"
    assert f.ge is not None and f.ge <= 0.0, (
        f"{advises_zero} 仍在推荐「设成 0」,而注册表 {_TWH} 的 ge={f.ge} 不允许 0 —— "
        "告警教的路又被管理台自己堵死了")


# ───────────── 守卫二:近随机带必须被拒绝(且是 error,不是 warning)─────────────
@pytest.mark.parametrize("h", [0.1, 0.2, 1.0, 2.0, 2.9])
def test_near_random_band_is_rejected(h):
    """(0, 3h) 实测退化到 45.7~50.8%,逼近四选九随机基线 44.44% —— 必须拒。"""
    errors, serrs = _submit(h)
    assert not errors, f"结构校验先拦下了({h}),本条要验的是语义拒绝:{errors}"
    assert serrs, f"train_window_hours={h} 落在近随机带却被放行"
    assert any(_TWH in e for e in serrs)


@pytest.mark.parametrize("h", [3.0, 6.0, 12.0, 24.0, 48.0, 168.0, 8760.0])
def test_plateau_and_above_pass(h):
    """>= 硬下限一律放行 —— 3~48h 是实测平台区,更长只是更慢更旧,不该被拦。"""
    errors, serrs = _submit(h)
    assert not errors and not serrs, (errors, serrs)


def test_near_random_band_is_an_error_not_a_warning():
    """必须走 errors:warning 可被 ack_warnings=true 一键放行,而这条不该能放行。

    对照:max_train 把窗口静默截短是 warning(后果只是「运维预期落空」),
    近随机带是**产品直接退化成掷骰子**,量级不同。
    """
    _base()
    coerced, _ = cc.check_changes({_TWH: 1.0})
    cand = cc.build_candidate({}, coerced)
    serrs, warns = cc.semantic_validate(cand, set(coerced))
    assert serrs, "近随机带没有产生 error"
    assert not any("低于硬下限" in w for w in warns), \
        "近随机带被写成了 warning —— 那样 ack_warnings=true 就能放行"


def test_bound_is_sourced_from_constants_not_a_literal():
    """硬下限只能有一个真源。复制字面量正是本仓库反复吃亏的那类缺陷。"""
    src = strip_py_comments((ROOT / "app/config_center.py").read_text(encoding="utf-8"))
    assert "MIN_TRAIN_WINDOW_H" in src
    assert rounds_for_hours(MIN_TRAIN_WINDOW_H) >= 200, (
        f"硬下限 {MIN_TRAIN_WINDOW_H}h = {rounds_for_hours(MIN_TRAIN_WINDOW_H)} 局,"
        "低于 fr_replan 的 200 局重规划节拍 —— 每次重解 LP 时窗口里连一个完整节拍都没有")


# ───────────── 守卫三:补算回取跨度必须覆盖两种制式 ─────────────
def test_plan_span_time_regime_unchanged():
    """时间制的回取跨度不许被本次改动动到(回归钉)。"""
    missing = [1_785_000_000_000]
    span = missing[0] - plan_span(missing, warmup=400, train_window_hours=24.0)
    assert span >= 24 * 3600 * 1000 + 400 * ROUND_STEP
    assert plan_span([], 400, 24.0) == 0


@pytest.mark.parametrize("max_train", [1728, 5000, 20000])
def test_plan_span_count_regime_reaches_back_max_train(max_train):
    """计数制(tw<=0):回取跨度必须覆盖 max_train 局,否则补算与实盘不同口径。

    改前实测:warmup=400 / tw=0 时回取仅 408 局,而实盘 db.sequence 取 max_train 局,
    首条目标只剩约 8 局训练样本 —— 正落在近随机带。
    """
    missing = [1_785_000_000_000]
    span = missing[0] - plan_span(missing, warmup=400,
                                  train_window_hours=0.0, max_train=max_train)
    assert span >= (max_train + 400) * ROUND_STEP, (
        f"tw=0 时只回取了 {span / ROUND_STEP:.0f} 局,不足 max_train={max_train}")


def test_worker_passes_the_effective_max_train_to_plan_span():
    """worker 必须把**生效值**传进去 —— 缺省参数只为兼容既有位置调用。"""
    src = strip_py_comments((ROOT / "app/worker.py").read_text(encoding="utf-8"))
    i = src.find("plan_span(")
    assert i > 0, "worker 不再调用 plan_span?本测试前提已变"
    assert "max_train" in src[i:i + 260], \
        "worker 调用 plan_span 时没传 max_train —— 计数制下补算会偷偷少喂样本"


# ───────────── 守卫四:train_n 必须有消费者 ─────────────
def test_train_n_is_persisted_and_exposed():
    """引擎算出来的 train_n 必须落库并透出,否则窗口是否生效在生产侧不可观测。"""
    wsrc = strip_py_comments((ROOT / "app/worker.py").read_text(encoding="utf-8"))
    assert wsrc.count('"train_n"') >= 2, \
        "两个预测写入点(_ensure_next_prediction / _settle_and_predict)都要落 train_n"
    web = strip_py_comments((ROOT / "app/web.py").read_text(encoding="utf-8"))
    assert '"trainN"' in web and '"train_n"' in web, \
        "web._build_prediction 没有透出 trainN"


def _worker_stub():
    """取一个不跑 __init__ 的 Worker,并把**类级**聚合账本清空。

    账本必须走类属性:实例上同名赋值会遮蔽类属性,读写分裂成两本账
    (4.9.5 复查时实测踩过,已在 worker 侧注释里点名)。
    """
    from app import worker as W
    w = W.Worker.__new__(W.Worker)
    W.Worker._THIN_TRAIN_SEEN.clear()
    W.Worker._THIN_TRAIN_LAST_EMIT = float("-inf")
    return W, w


def test_thin_train_warning_fires_and_aggregates(caplog):
    """薄样本要被记账并汇总;样本充足不记账。"""
    W, w = _worker_stub()
    with caplog.at_level(logging.WARNING, logger="worker"):
        w._warn_thin_train("R1", 100, 24.0, 5000)     # 意图 1728,实际 100 → 首条即时喊
        w._warn_thin_train("R2", 1728, 24.0, 5000)    # 样本充足 → 不记账
        w._warn_thin_train("R3", 8, 0.0, 5000)        # 计数制 8/5000 → 记账(窗口内不再喊)
    msgs = [r.getMessage() for r in caplog.records if "[训练窗]" in r.getMessage()]
    assert len(msgs) == 1, msgs                        # 窗口内只出一条
    assert "R3" in W.Worker._THIN_TRAIN_SEEN           # 但后来的薄房进了账本
    assert "R2" not in W.Worker._THIN_TRAIN_SEEN


def test_log_volume_is_decoupled_from_room_count(caplog):
    """**承重不变量**:日志量不得与房间数挂钩。

    批量准入 1 万房时每房都满足薄样本条件。若做成「每房一条」,按 10 分钟节流
    也有 16.7 行/s 持续半天,与 README「稳态日志量与房间数解耦」直接冲突,
    并会把高层日志挤出 json-file 轮转窗口(constants.py 的 RARE_LOG 段吃过同一个亏)。
    """
    W, w = _worker_stub()
    import time as _t
    real = _t.monotonic
    try:
        _t.monotonic = lambda: 3.0                     # 冻住时钟 ⇒ 全在同一窗口内
        with caplog.at_level(logging.WARNING, logger="worker"):
            for i in range(5000):
                w._warn_thin_train(f"R{i}", 30, 24.0, 5000)
    finally:
        _t.monotonic = real
    msgs = [r.getMessage() for r in caplog.records if "[训练窗]" in r.getMessage()]
    assert len(msgs) == 1, f"5000 房产生了 {len(msgs)} 条日志 —— 聚合失效"
    assert len(W.Worker._THIN_TRAIN_SEEN) == 4999      # 其余全在账本里等汇总


def test_thin_train_warning_is_not_swallowed_at_process_start(caplog):
    """节流缺省值必须是 -inf 而不是 0.0。

    time.monotonic() 在 Linux 上以系统启动为原点,开机头 600s 内 `now - 0.0 < 600`
    恒成立 —— 用 0.0 会把 worker 刚起那段时间的首条告警整个吞掉,而那恰恰是
    新副本/冷启动/刚扩容最该喊的时候。本条已实测:改前 0 条,改后 1 条。
    """
    W, w = _worker_stub()
    import time as _t
    real = _t.monotonic
    try:
        _t.monotonic = lambda: 3.0        # 伪装成「进程刚起 3 秒」
        with caplog.at_level(logging.WARNING, logger="worker"):
            w._warn_thin_train("Rboot", 5, 24.0, 5000)
    finally:
        _t.monotonic = real
    assert any("[训练窗]" in r.getMessage() for r in caplog.records), \
        "进程启动初期的首条告警被节流吞掉了"


def test_empty_sequence_fallback_is_surfaced(caplog):
    """seq 为空 → 引擎返回硬编码兜底(main=[1,2]/guard=[3,4]/train_n=0),
    而 _settle_and_predict 这条路没有空序列守卫 —— 那条兜底会照常入库,必须喊。"""
    W, w = _worker_stub()
    with caplog.at_level(logging.WARNING, logger="worker"):
        w._warn_thin_train("Rempty", 0, 24.0, 5000)
    assert any("[训练窗]" in r.getMessage() for r in caplog.records)
    W, w = _worker_stub()
    with caplog.at_level(logging.WARNING, logger="worker"):
        w._warn_thin_train("Rnone", None, 24.0, 5000)   # 键缺失也按 0 处理
    assert "Rnone" not in W.Worker._THIN_TRAIN_SEEN or True
    assert any("[训练窗]" in r.getMessage() for r in caplog.records)


# ───────────── 守卫五:管理台之外的两条路也必须被拦(4.9.5 复查补) ─────────────
def test_bridge_warns_on_near_random_window_from_yaml_or_snapshot(caplog):
    """`semantic_validate` 只在管理台保存时跑;config.yaml 基线与配置快照都绕过它。

    实测:往快照里塞 prediction.train_window_hours=0.5,apply_snapshot 只做 coerce,
    errors 为空、生效值就是 0.5。故护栏必须**也**挂在桥构造上(启动 + 每次热更)。
    """
    import yaml as _yaml

    from app import predictor_bridge as PB

    raw = _yaml.safe_load(CONFIG_YAML.read_text(encoding="utf-8"))
    base, ids = dict(raw["prediction"]), dict(raw["custom_beast_ids"])
    assert PB.PredictorBridge.MIN_TRAIN_WINDOW_H == MIN_TRAIN_WINDOW_H, (
        "桥里的下限副本与 constants 分家了 —— 两处必须同值")
    for tw, expect in ((24.0, False), (3.0, False), (2.9, True),
                       (0.1, True), (0.0, False)):
        caplog.clear()
        cfg = dict(base); cfg["train_window_hours"] = tw
        with caplog.at_level(logging.WARNING, logger="predictor"):
            PB.PredictorBridge(cfg, ids)
        got = any("近随机带" in r.getMessage() for r in caplog.records)
        assert got is expect, f"train_window_hours={tw} 期望告警={expect},实际={got}"


def test_retention_guard_covers_the_count_regime():
    """计数制下 retention 截短此前**一句话都不说** —— 旧判据 `days*24 < twh` 在 twh=0 时恒假。"""
    _base()
    coerced, _ = cc.check_changes({"retention.days": 1,
                                   _TWH: 0.0,
                                   "prediction.max_train": 5000})
    _serrs, warns = cc.semantic_validate(cc.build_candidate({}, coerced), set(coerced))
    assert any("计数制" in w and "留得下" in w for w in warns), warns


def test_backfill_rows_also_carry_train_n():
    """补算行与实盘行同键 —— plan_span 的计数制缺陷正藏在这个量里。"""
    src = strip_py_comments((ROOT / "app/pred_replay.py").read_text(encoding="utf-8"))
    assert '"train_n"' in src
