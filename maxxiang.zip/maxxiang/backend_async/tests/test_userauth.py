"""
test_userauth.py — 登录系统(3.8.0)
================================================================================
两层:
  · 纯单元(恒跑,零外部依赖):口令形态自适应校验 / 封停取值 / 剩余天数换算。
  · 联测(需本地 MySQL 兼容库,127.0.0.1:3307;开发容器里由 MariaDB 1:1 复刻
    线上 fanxing_changkong_user_db —— 同库名/同账号/同 gbk/同 tb_user 结构与
    多形态测试用户):登录全流程(成功/密错/过期/封停)、会话校验、单设备互顶、
    登出。不可达则整层 skip(CI/无库环境不误伤)。

默认部署(未配置 STA_USERDB_HOST)下登录系统关闭 —— 其余全部测试文件不感知
本模块存在,3.7.0 行为契约由既有套件继续钉住。
"""
from __future__ import annotations

import datetime as dt
import os
import socket
import sys

import pytest
import pytest_asyncio

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import userauth  # noqa: E402
from app.settings import UserAuthCfg  # noqa: E402

# ── 纯单元 ────────────────────────────────────────────────────────────────────
import hashlib  # noqa: E402


def test_verify_password_shapes():
    md5 = hashlib.md5(b"pw123456").hexdigest()
    sha1 = hashlib.sha1(b"pw123456").hexdigest()
    sha256 = hashlib.sha256(b"pw123456").hexdigest()
    assert userauth.verify_password("pw123456", md5)
    assert userauth.verify_password("pw123456", md5.upper())      # 存量大写 hex 也认
    assert userauth.verify_password("pw123456", sha1)
    assert userauth.verify_password("pw123456", sha256)
    assert userauth.verify_password("plain#pw", "plain#pw")       # 明文逐字节
    assert not userauth.verify_password("wrong", md5)
    assert not userauth.verify_password("", md5)
    assert not userauth.verify_password("pw123456", "")
    # 口令本身长得像 32hex 且明文入库:明文路径必须仍然命中(双通道)
    hexlike = "a" * 32
    assert userauth.verify_password(hexlike, hexlike)
    # 中文口令(utf-8 摘要口径)
    assert userauth.verify_password("口令测试", hashlib.md5("口令测试".encode()).hexdigest())


def test_is_banned_configurable():
    userauth.UA.cfg = UserAuthCfg(banned_values="1")
    assert userauth._is_banned("1")
    assert not userauth._is_banned("0")
    assert not userauth._is_banned("")
    userauth.UA.cfg = UserAuthCfg(banned_values="1,Y, x ")
    assert userauth._is_banned("Y") and userauth._is_banned("x")
    assert not userauth._is_banned("y")            # 取值逐字节;大小写按业务原样


def test_parse_first_login_room():
    # 「真实号:展示短号」双段;省略短号 = 展示同真实号
    assert userauth.parse_first_login_room("2678075:321") == ("2678075", "321")
    assert userauth.parse_first_login_room(" 2678075 : 321 ") == ("2678075", "321")
    assert userauth.parse_first_login_room("2678075") == ("2678075", "2678075")
    # 空/关闭/畸形 → None(关闭语义;web 层直接跳过预置)
    assert userauth.parse_first_login_room("") is None
    assert userauth.parse_first_login_room(None) is None
    assert userauth.parse_first_login_room("off") is None            # env 关闭哨兵值兜底
    assert userauth.parse_first_login_room("321:") == ("321", "321")  # 尾冒号 = 省略短号
    assert userauth.parse_first_login_room("abc:321") is None
    assert userauth.parse_first_login_room("2678075:32x") is None
    # 位数与 /api/monitor/add 同口径:2–12 位纯数字
    assert userauth.parse_first_login_room("1") is None
    assert userauth.parse_first_login_room("1234567890123") is None
    assert userauth.parse_first_login_room("12:123456789012") == ("12", "123456789012")


def test_due_days():
    soon = (dt.datetime.now() + dt.timedelta(days=2, hours=1)).isoformat(timespec="seconds")
    past = (dt.datetime.now() - dt.timedelta(days=3)).isoformat(timespec="seconds")
    assert userauth._due_days(soon) == 2
    assert userauth._due_days(past) == 0            # 过期钳 0(权威判定在 SQL)
    assert userauth._due_days("not-a-date") is None


def test_client_ip_trust_xff_toggle():
    """复查加固回归:trust_forwarded_for 决定节流分桶 IP 来源。
    关=直连地址(防伪造 XFF 稀释按 IP 节流);开=**仅当直连对端是可信代理**时采信 XFF
    (5.2.0「可信代理」口径;旧口径「开=无条件取首跳」在直连部署下可被任意伪造)。"""
    from types import SimpleNamespace as NS
    via_proxy = NS(headers={"x-forwarded-for": "1.2.3.4, 10.0.0.1"},
                   client=NS(host="10.0.0.2"))           # 对端是同网段反代
    direct = NS(headers={"x-forwarded-for": "1.2.3.4, 10.0.0.1"},
                client=NS(host="203.0.113.9"))            # 对端就是公网客户端
    prev = userauth.UA.cfg
    try:
        userauth.UA.cfg = UserAuthCfg(trust_forwarded_for=True)
        assert userauth.client_ip(via_proxy) == "1.2.3.4"   # 反代:最右非代理跳
        assert userauth.client_ip(direct) == "203.0.113.9"  # 直连:伪造 XFF 一律忽略
        userauth.UA.cfg = UserAuthCfg(trust_forwarded_for=False)
        assert userauth.client_ip(via_proxy) == "10.0.0.2"  # 关:只认直连地址
        assert userauth.client_ip(direct) == "203.0.113.9"
        # 无 XFF 时两态都回落直连
        req2 = NS(headers={}, client=NS(host="198.51.100.7"))
        assert userauth.client_ip(req2) == "198.51.100.7"
    finally:
        userauth.UA.cfg = prev


def test_diag_snapshots_isolated_per_realm(tmp_path):
    """复查修复回归:账号库诊断快照(轮询/userinfo/检测)按 Realm 隔离 ——
    此前是模块级全局,A 扫码的票据线索会被 B 的 /api/account/*/diag 读到。"""
    from app.accounts import accounts_backend as ab
    ab.init(str(tmp_path / "accounts.json"))
    rA, rB = ab.get_realm("u1"), ab.get_realm("u2")
    assert rA.qr.last_poll is not rB.qr.last_poll
    rA.qr.last_poll["raw"] = "A_SECRET_TICKET"
    rA.qr.last_userinfo["coin"] = 999
    rA.qr.last_check["kugouId"] = "A_KID"
    assert rB.qr.last_poll["raw"] == "" and rB.qr.last_userinfo["coin"] is None
    _, outA = ab.handle_api("/api/account/qr/diag", {}, realm=rA)
    _, outB = ab.handle_api("/api/account/qr/diag", {}, realm=rB)
    assert outA["lastPoll"]["raw"] == "A_SECRET_TICKET"
    assert outB["lastPoll"]["raw"] == ""              # ← 修复点:B 看不到 A
    _, outD = ab.handle_api("/api/account/userinfo/diag", {}, realm=ab.get_realm(None))
    assert outD["lastUserInfo"]["coin"] is None       # 默认领域亦独立


def test_admin_bypass_cookie_post_only(monkeypatch):
    """复查修复回归:管理台 Cookie 旁路仅认 POST(封 GET+SameSite=Lax 的 CSRF);
    X-Monitor-Token 头分支不限 method(跨站设不了自定义头,天然免疫)。"""
    from types import SimpleNamespace as NS
    from app import admin_auth
    monkeypatch.setenv("STA_MONITOR_WRITE_TOKEN", "")
    monkeypatch.setattr(admin_auth, "enabled", lambda: True)
    monkeypatch.setattr(admin_auth, "parse_session", lambda v: {"u": "admin"} if v else None)
    req = lambda method, cookie=True, tok="": NS(  # noqa: E731
        method=method,
        cookies={admin_auth.COOKIE: "sess"} if cookie else {},
        headers={"x-monitor-token": tok} if tok else {})
    assert userauth._admin_bypass(req("POST")) is True
    assert userauth._admin_bypass(req("GET")) is False          # ← 修复点
    assert userauth._admin_bypass(req("GET", cookie=False)) is False
    monkeypatch.setenv("STA_MONITOR_WRITE_TOKEN", "opstok")
    assert userauth._admin_bypass(req("GET", cookie=False, tok="opstok")) is True
    assert userauth._admin_bypass(req("GET", cookie=False, tok="wrong")) is False


# ── 联测(本地 1:1 复刻用户库;不可达整层 skip) ─────────────────────────────────
_HOST, _PORT = "127.0.0.1", int(os.environ.get("STA_TEST_USERDB_PORT", "3307"))


def _db_reachable() -> bool:
    try:
        with socket.create_connection((_HOST, _PORT), timeout=0.6):
            return True
    except OSError:
        return False


needs_db = pytest.mark.skipif(not _db_reachable(),
                              reason=f"需要本地用户库 {_HOST}:{_PORT}(MariaDB 1:1 复刻)")


def _cfg(**kw) -> UserAuthCfg:
    base = dict(host=_HOST, port=_PORT, db="fanxing_changkong_user_db",
                user="fanxing_admin", password="fanxing_admin,.", charset="gbk",
                cache_ttl_s=0.0,          # 测试逐次过库,不吃缓存
                login_fail_user=1000, login_fail_ip=1000)   # 联测不触节流
    base.update(kw)
    return UserAuthCfg(**base)


@pytest_asyncio.fixture()
async def ua_env():
    """初始化 → 用例 → 收尾(复查修复:异步 fixture,与用例**同一事件循环**内
    close —— aiomysql 连接池绑定其创建 loop,跨 loop 关闭属未定义行为)。"""
    async def _setup(cfg: UserAuthCfg):
        await userauth.init(cfg, None)     # redis=None:节流走进程内兜底
        assert userauth.UA.schema_ok or await userauth._ensure_schema()
    yield _setup
    await userauth.close()
    userauth.UA.cfg = None
    userauth.UA.cache = {}
    userauth.UA.schema_ok = False


@needs_db
@pytest.mark.asyncio
async def test_login_flow_and_validate(ua_env):
    await ua_env(_cfg())
    # 密错 → 401(统一 bad_credentials,不泄露用户存在性)
    st, body, tok = await userauth.login("测试用户A", "wrong", "1.2.3.4", "pytest")
    assert (st, body["error"], tok) == (401, "bad_credentials", None)
    st, body, tok = await userauth.login("不存在的用户", "whatever", "1.2.3.4", "pytest")
    assert (st, body["error"]) == (401, "bad_credentials")
    # 过期 → 403 expired(口令正确后才揭示)
    st, body, _ = await userauth.login("expireduser", "pw123456", "1.2.3.4", "pytest")
    assert (st, body["error"]) == (403, "expired") and body.get("dueTime")
    # 封停 → 403 banned
    st, body, _ = await userauth.login("banneduser", "pw123456", "1.2.3.4", "pytest")
    assert (st, body["error"]) == (403, "banned")
    # 成功(中文用户名 + MD5 存量)→ 200 + 会话可校验
    st, body, tok = await userauth.login("测试用户A", "pw123456", "1.2.3.4", "pytest")
    assert st == 200 and tok and body["user"]["userName"] == "测试用户A"
    state, pr, _ = await userauth.validate(tok)
    assert state == "ok" and pr.user_name == "测试用户A" and pr.user_id == body["user"]["id"]
    # 明文存量 + SHA1 存量同样可登录
    for name, pw in (("plainuser", "plain#pw"), ("sha1user", "pw123456")):
        st, _, t2 = await userauth.login(name, pw, "1.2.3.4", "pytest")
        assert st == 200 and t2
    # 登出 → 该会话立即失效
    await userauth.logout(tok)
    state, pr, _ = await userauth.validate(tok)
    assert state == "auth_required" and pr is None


@needs_db
@pytest.mark.asyncio
async def test_single_device_kick(ua_env):
    await ua_env(_cfg(single_device=True))
    _, _, t1 = await userauth.login("测试用户A", "pw123456", "1.1.1.1", "devA")
    _, _, t2 = await userauth.login("测试用户A", "pw123456", "2.2.2.2", "devB")
    assert t1 and t2 and t1 != t2
    s1, _, _ = await userauth.validate(t1)
    s2, p2, _ = await userauth.validate(t2)
    assert s1 == "kicked"                    # 旧设备被顶下,语义化可提示
    assert s2 == "ok" and p2 is not None     # 新设备正常
    await userauth.logout(t2)


@needs_db
@pytest.mark.asyncio
async def test_multi_session_cap(ua_env):
    await ua_env(_cfg(single_device=False, max_sessions=2))
    toks = []
    for i in range(3):
        _, _, t = await userauth.login("plainuser", "plain#pw", f"9.9.9.{i}", "dev")
        toks.append(t)
    states = [(await userauth.validate(t))[0] for t in toks]
    assert states[0] == "kicked" and states[1] == "ok" and states[2] == "ok"
    for t in toks[1:]:
        await userauth.logout(t)


@needs_db
@pytest.mark.asyncio
async def test_throttle_memory_fallback(ua_env):
    """redis=None 时进程内兜底:同名失败 3 次即锁,窗口内恒 429。"""
    await ua_env(_cfg(login_fail_user=3, login_fail_ip=1000,
                      login_fail_window_s=60, login_lock_s=60))
    for _ in range(3):
        st, _, _ = await userauth.login("测试用户A", "bad", "8.8.8.8", "t")
        assert st == 401
    st, body, _ = await userauth.login("测试用户A", "bad", "8.8.8.8", "t")
    assert st == 429 and body["error"] == "throttled" and body["retryAfter"] >= 1
    # 正确口令同样被锁(节流在口令校验之前 —— 不给爆破者「locked 即差最后一步」的信号)
    st, _, _ = await userauth.login("测试用户A", "pw123456", "8.8.8.8", "t")
    assert st == 429
