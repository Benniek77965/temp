"""
test_login_guard.py — 登录防爆破 + 统一来源 IP(5.2.0)
================================================================================
每一条都对应一个**实证过的**旧缺陷(复现数字见 LOGIN-SYSTEM.md §4.5):
  · 来源 IP:直连部署下伪造 X-Forwarded-For 可稀释按 IP 节流、可绕过管理台白名单;
  · 先查后加竞态:60 个并发错口令全部进入验密(上限 10);
  · 锁人:同名锁让真主人也进不来;
  · 锁定期审计写放大、IPv6 不按 /64 分桶、INCR/EXPIRE 非原子留下永久键;
  · 撒网/撞库无全局视角;登录端点接受跨源 text/plain、数组请求体 500。
外加本轮新增能力的契约:分级加码(PoW / 人机验证)、设备信任、全局攻击态、
登录人机验证开关(Turnstile 校验走本地模拟的 siteverify,覆盖成功 / 失败 /
action 挪用 / 密钥错 / 供应商不可达→降级 PoW)、账密签发通道的加码语义。

两层:纯单元恒跑;联测需本地 1:1 复刻用户库(127.0.0.1:3307,不可达整层 skip)
+ fakeredis[lua](与 test_register 同一跑道)。
"""
from __future__ import annotations

import asyncio
import collections
import hashlib
import os
import socket
import sys
import time
from types import SimpleNamespace as NS

import pytest
import pytest_asyncio

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import admin_api, admin_auth, clientip, userauth, wincount  # noqa: E402
from app.settings import UserAuthCfg  # noqa: E402

try:
    import fakeredis.aioredis as _fakered
    _HAVE_FAKEREDIS = True
except Exception:                                   # noqa: BLE001
    _HAVE_FAKEREDIS = False

_HOST, _PORT = "127.0.0.1", int(os.environ.get("STA_TEST_USERDB_PORT", "3307"))


def _db_reachable() -> bool:
    try:
        with socket.create_connection((_HOST, _PORT), timeout=0.6):
            return True
    except OSError:
        return False


needs_db = pytest.mark.skipif(not _db_reachable(),
                              reason=f"需要本地用户库 {_HOST}:{_PORT}(MariaDB 1:1 复刻)")
needs_redis = pytest.mark.skipif(not _HAVE_FAKEREDIS, reason="需要 fakeredis[lua]")


@pytest.fixture(autouse=True)
def _clean_guard_state(monkeypatch):
    """进程级状态逐用例归零(本文件的每条用例都不该看见上一条留下的计数/熔断/密钥)。"""
    monkeypatch.delenv("STA_TRUSTED_PROXIES", raising=False)
    monkeypatch.setenv("STA_USER_DEVICE_KEY", "k" * 40)
    saved = (userauth.UA.cfg, userauth.UA.redis, userauth.UA.schema_ok)
    userauth.UA.mem_fail, userauth.UA.mem_reg = {}, {}
    userauth.UA.lg_attack, userauth.UA.cap_down_until = (), 0.0
    userauth.UA.dev_key, userauth.UA.dev_key_src = b"", ""
    userauth.UA.risk_cache = ()
    wincount.STATE["lua"] = None
    clientip.configure(None)
    admin_auth._ADM_FAIL_MEM.clear()
    yield
    if userauth.UA.cfg is not saved[0]:
        # 用例换过配置(如 host 指向一个连不上的库):它若顺手建了连接池,还原 cfg 之前先拆池 ——
        # 否则模块级隔离夹具看到 cfg「没变」就不会拆,坏池漏进下一个模块(全套跑时 test_register
        # 撞上过,单独跑必过)。与 conftest._isolate_userauth_state_per_module 同一手法。
        if userauth.UA.router is not None:
            try:
                userauth.UA.pool = None
            except Exception:           # noqa: BLE001
                userauth.UA.router = None
        userauth.UA.cache = {}
    userauth.UA.cfg, userauth.UA.redis, userauth.UA.schema_ok = saved
    userauth.UA.mem_fail, userauth.UA.mem_reg = {}, {}
    userauth.UA.lg_attack, userauth.UA.cap_down_until = (), 0.0
    userauth.UA.dev_key, userauth.UA.dev_key_src = b"", ""
    userauth.UA.risk_cache = ()
    wincount.STATE["lua"] = None
    clientip.configure(None)
    admin_auth._ADM_FAIL_MEM.clear()


# ══ 纯单元:来源 IP ════════════════════════════════════════════════════════════
def test_clientip_direct_public_peer_ignores_forged_xff():
    """直连部署(对端就是公网客户端):XFF 一律不采信 —— 每请求换假 IP 再无收益。"""
    assert clientip.resolve("203.0.113.9", "10.1.2.3") == "203.0.113.9"
    assert clientip.resolve("203.0.113.9", "1.2.3.4, 5.6.7.8") == "203.0.113.9"
    assert clientip.resolve("2001:db8::9", "10.1.2.3") == "2001:db8::9"


def test_clientip_behind_trusted_proxy_takes_rightmost_untrusted_hop():
    """对端是同机/内网反代:从最右往左取第一个非代理跳。追加式反代
    ($proxy_add_x_forwarded_for)把客户端自带的伪造值留在最左,首跳口径会上当。"""
    assert clientip.resolve("127.0.0.1", "198.51.100.7") == "198.51.100.7"
    assert clientip.resolve("10.0.0.2", "1.2.3.4, 198.51.100.7") == "198.51.100.7"
    assert clientip.resolve("172.18.0.3", "1.2.3.4, 198.51.100.7, 10.0.0.9") == "198.51.100.7"
    # 链上全是代理 → 最左一跳
    assert clientip.resolve("10.0.0.2", "10.9.9.9, 192.168.1.1") == "10.9.9.9"
    # 非法串:整条链不可信,回落直连地址(不让攻击者往节流键里塞任意文本)
    assert clientip.resolve("127.0.0.1", "not-an-ip") == "127.0.0.1"
    assert clientip.resolve("127.0.0.1", "1.2.3.4, evil") == "127.0.0.1"


def test_clientip_hop_formats_and_env_switches(monkeypatch):
    assert clientip.norm_ip("1.2.3.4:5678") == "1.2.3.4"
    assert clientip.norm_ip("[2001:db8::1]:443") == "2001:db8::1"
    assert clientip.norm_ip("::ffff:10.0.0.1") == "10.0.0.1"
    assert clientip.norm_ip("") is None and clientip.norm_ip("x.y") is None
    monkeypatch.setenv("STA_TRUSTED_PROXIES", "none")
    assert clientip.resolve("127.0.0.1", "198.51.100.7") == "127.0.0.1"
    monkeypatch.setenv("STA_TRUSTED_PROXIES", "203.0.113.0/24")
    assert clientip.resolve("203.0.113.5", "198.51.100.7") == "198.51.100.7"
    assert clientip.resolve("127.0.0.1", "198.51.100.7") == "127.0.0.1"
    monkeypatch.setenv("STA_TRUSTED_PROXIES", "*")          # 旧行为(不推荐)仍可显式选
    assert clientip.resolve("203.0.113.9", "10.1.2.3") == "10.1.2.3"
    assert clientip.resolve("10.0.0.2", "x", trust_xff=False) == "10.0.0.2"


def test_admin_ip_whitelist_cannot_be_bypassed_with_forged_xff(monkeypatch):
    """★ 实证缺陷回归:旧 admin_auth.client_ip 无条件取 XFF 首跳 —— 直连部署下
    `X-Forwarded-For: 10.1.2.3` 即可通过 STA_ADMIN_IP_ALLOW=10.0.0.0/8。"""
    monkeypatch.setenv("STA_ADMIN_IP_ALLOW", "10.0.0.0/8")
    forged = NS(headers={"x-forwarded-for": "10.1.2.3"}, client=NS(host="8.8.4.4"))
    assert admin_auth.client_ip(forged) == "8.8.4.4"
    assert admin_auth.ip_allowed(admin_auth.client_ip(forged)) is False
    via_proxy = NS(headers={"x-forwarded-for": "10.1.2.3"}, client=NS(host="127.0.0.1"))
    assert admin_auth.ip_allowed(admin_auth.client_ip(via_proxy)) is True
    no_client = NS(headers={}, client=None)
    assert admin_auth.client_ip(no_client) == "?"


# ══ 纯单元:阈值、设备 Cookie、人机验证配置 ═══════════════════════════════════
def test_soft_threshold_rules():
    s = userauth._lg_soft
    assert s(10, -1) == 4 and s(30, -1) == 10          # 默认:硬上限 1/3 向上取整
    assert s(3, -1) == 3 and s(5, -1) == 3             # 至少 3(手滑两次是常态)
    assert s(2, -1) == 2                               # 但不超过硬上限
    assert s(10, 0) == 0                               # 0 = 关
    assert s(10, 7) == 7 and s(10, 99) == 10           # 显式值钳到硬上限内
    assert s(10, "x") == 4                             # 脏值按自动处理


@pytest.mark.asyncio
async def test_device_cookie_binds_user_and_resists_tampering(monkeypatch):
    userauth.UA.cfg, userauth.UA.redis = UserAuthCfg(), None
    v = await userauth.device_cookie_value("plainuser")
    did = await userauth._device_for(v, "plainuser")
    assert did and len(did) == 16
    assert await userauth._device_for(v, "  plainuser  ".strip()) == did
    assert await userauth._device_for(v, "otheruser") == ""        # 只对本账号有效
    assert await userauth._device_for(v[:-1] + ("0" if v[-1] != "0" else "1"), "plainuser") == ""
    assert await userauth._device_for("garbage", "plainuser") == ""
    real = time.time
    monkeypatch.setattr(userauth.time, "time", lambda: real() + 91 * 86400)
    assert await userauth._device_for(v, "plainuser") == ""        # 过期(默认 90 天)
    monkeypatch.setattr(userauth.time, "time", real)
    userauth.UA.cfg = UserAuthCfg(login_device_ttl_d=0)              # 0 = 设备信任关闭
    assert await userauth._device_for(v, "plainuser") == ""


def test_captcha_config_is_shared_and_login_only_picks_timing():
    """注册与登录共用一套供应商与凭据(运维反馈:两组同名项并列极易配串);登录只选时机。"""
    c = UserAuthCfg(reg_captcha="turnstile", reg_captcha_id="site-1", reg_captcha_key="sec-1")
    userauth.UA.cfg = c
    assert userauth._cap_conf("login") == userauth._cap_conf("reg")
    assert userauth.login_session_info() == {}                 # 登录时机默认 off
    c.login_captcha = "risk"
    info = userauth.login_session_info()
    assert info["captcha"] == {"provider": "turnstile", "appId": "site-1", "action": "login"}
    assert info["captchaMode"] == "risk"
    c.login_captcha = "always"
    assert userauth.login_session_info()["captchaMode"] == "always"
    c.login_captcha = "bogus"
    assert userauth.login_session_info() == {}
    c.login_captcha, c.reg_captcha = "risk", "off"               # 没选供应商:时机设了也不生效
    assert userauth.login_session_info() == {}


def test_preview_style_login_captcha_env_is_folded_into_shared(monkeypatch):
    """兼容 5.2.0 预览写法:STA_USER_LOGIN_CAPTCHA=供应商名 + _MODE/_ID/_KEY 自动折算进共用那组。"""
    from app import settings as st
    for k in ("STA_USER_REG_CAPTCHA", "STA_USER_REG_CAPTCHA_ID", "STA_USER_REG_CAPTCHA_KEY"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("STA_USER_LOGIN_CAPTCHA", "turnstile")
    monkeypatch.setenv("STA_USER_LOGIN_CAPTCHA_MODE", "always")
    monkeypatch.setenv("STA_USER_LOGIN_CAPTCHA_ID", "s1")
    monkeypatch.setenv("STA_USER_LOGIN_CAPTCHA_KEY", "k1")
    ua = st.get_settings().userauth
    assert (ua.reg_captcha, ua.reg_captcha_id, ua.reg_captcha_key, ua.login_captcha) \
        == ("turnstile", "s1", "k1", "always")
    monkeypatch.setenv("STA_USER_REG_CAPTCHA", "tencent")         # 共用项已有值:以共用项为准
    monkeypatch.setenv("STA_USER_REG_CAPTCHA_ID", "app-9")
    ua = st.get_settings().userauth
    assert (ua.reg_captcha, ua.reg_captcha_id, ua.login_captcha) == ("tencent", "app-9", "always")
    assert ua.reg_captcha_key == ""                              # 异家供应商的私钥绝不折算进来
    monkeypatch.setenv("STA_USER_LOGIN_CAPTCHA", "risk")
    monkeypatch.delenv("STA_USER_LOGIN_CAPTCHA_MODE")
    assert st.get_settings().userauth.login_captcha == "risk"


def test_captcha_check_reports_missing_credentials_before_token():
    """凭据不全是运维问题:先报「暂不可用」,不报「用户没过验证」(登录侧据此降级为 PoW)。"""
    userauth.UA.cfg = UserAuthCfg(reg_captcha="turnstile", login_captcha="always")
    return_code = asyncio.run(userauth._captcha_check("", "1.2.3.4", scope="login"))[1]
    assert return_code == "captcha_unavailable"


def test_clientip_configured_value_and_env_precedence(monkeypatch):
    """config.yaml 的 trusted_proxies 经 configure() 生效;环境变量始终优先。"""
    clientip.configure("none")
    assert clientip.resolve("127.0.0.1", "198.51.100.7") == "127.0.0.1"
    monkeypatch.setenv("STA_TRUSTED_PROXIES", "loopback")
    assert clientip.resolve("127.0.0.1", "198.51.100.7") == "198.51.100.7"
    monkeypatch.delenv("STA_TRUSTED_PROXIES")
    clientip.configure(None)
    assert clientip.resolve("127.0.0.1", "198.51.100.7") == "198.51.100.7"
    assert clientip.bucket("2001:db8:1:2::9") == clientip.bucket("2001:db8:1:2:ffff::1") == "2001:db8:1:2::/64"
    assert clientip.bucket("") == "unknown" and clientip.bucket("1.2.3.4") == "1.2.3.4"
    # IPv4 映射地址按 IPv4 计 —— 否则全体 IPv4 访客会落进同一个 ::/64 桶
    assert clientip.bucket("::ffff:203.0.113.7") == "203.0.113.7" != clientip.bucket("::ffff:203.0.113.8")


def test_no_raw_incr_left_outside_wincount():
    """同类模式钉死:「INCR 后仅 n==1 时 EXPIRE」曾散落 7 处,EXPIRE 抖一次即留下永久键。
    现一律走 app/wincount.py;app/ 下再出现裸 .incr( 即红。"""
    import pathlib
    import re
    app = pathlib.Path(__file__).resolve().parent.parent / "app"
    bad = []
    for f in app.rglob("*.py"):
        if f.name == "wincount.py":
            continue
        for n, line in enumerate(f.read_text(encoding="utf-8").splitlines(), 1):
            code = line.split("#", 1)[0]
            if re.search(r"(?<!wincount)\.incr\(", code):
                bad.append(f"{f.name}:{n}")
    assert not bad, f"请改用 wincount.incr/incr_redis: {bad}"


# ══ 纯单元:窗口计数原语(fakeredis) ════════════════════════════════════════════
@needs_redis
@pytest.mark.asyncio
async def test_win_incr_is_atomic_under_concurrency():
    r = _fakered.FakeRedis()
    userauth.UA.cfg, userauth.UA.redis = UserAuthCfg(), r
    res = await asyncio.gather(*[userauth._win_incr("t:atomic", 60, {}) for _ in range(200)])
    assert sorted(n for n, _ in res) == list(range(1, 201))
    assert 0 < await r.ttl("t:atomic") <= 60


@needs_redis
@pytest.mark.asyncio
async def test_win_incr_without_eval_self_heals_missing_ttl(monkeypatch):
    """禁用脚本的托管 Redis:退化为「INCR + 每次补 TTL」。即便某次 EXPIRE 抖掉,
    下一次计数也会把 TTL 补上 —— 旧写法(仅 n==1 时 EXPIRE)会永久无 TTL(实证 -1)。"""
    import redis.exceptions as rexc
    r = _fakered.FakeRedis()
    userauth.UA.cfg, userauth.UA.redis = UserAuthCfg(), r

    async def no_eval(*a, **k):
        raise rexc.ResponseError("unknown command 'EVAL'")
    monkeypatch.setattr(r, "eval", no_eval)
    real_expire, calls = r.expire, {"n": 0}

    async def flaky_expire(*a, **k):
        calls["n"] += 1
        if calls["n"] == 1:
            raise rexc.ConnectionError("blip")
        return await real_expire(*a, **k)
    monkeypatch.setattr(r, "expire", flaky_expire)
    await userauth._win_incr("t:heal", 60, {})      # EXPIRE 抖掉 → 本次落进程内兜底
    n, _ = await userauth._win_incr("t:heal", 60, {})
    assert n == 2 and 0 < await r.ttl("t:heal") <= 60
    assert wincount.STATE["lua"] is False


@needs_redis
@pytest.mark.asyncio
async def test_win_decr_never_creates_ttl_less_keys():
    r = _fakered.FakeRedis()
    userauth.UA.cfg, userauth.UA.redis = UserAuthCfg(), r
    await userauth._win_decr("t:gone", {})
    assert not await r.exists("t:gone")             # 旧 _reg_decr 会留下一个无 TTL 的 0
    await userauth._win_incr("t:x", 60, {})
    await userauth._win_decr("t:x", {})
    await userauth._win_decr("t:x", {})
    assert int(await r.get("t:x")) == 0 and await r.ttl("t:x") > 0


# ══ 纯单元:Turnstile 校验(本地模拟 siteverify) ═══════════════════════════════
async def _start_siteverify():
    """本地模拟 Cloudflare siteverify:语义按官方文档(success/error-codes/action)。"""
    from aiohttp import web

    async def h(req):
        f = await req.post()
        if f.get("secret") != "sk-test":
            return web.json_response({"success": False, "error-codes": ["invalid-input-secret"]})
        tok = str(f.get("response") or "")
        if tok.startswith("tok-"):
            act = tok[4:]
            return web.json_response({"success": True, "hostname": "obs.example",
                                      "action": "" if act == "noact" else act})
        return web.json_response({"success": False, "error-codes": ["invalid-input-response"]})
    app = web.Application()
    app.router.add_post("/siteverify", h)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]
    return runner, f"http://127.0.0.1:{port}/siteverify"


@pytest.mark.asyncio
async def test_turnstile_check_semantics(monkeypatch):
    runner, url = await _start_siteverify()
    try:
        monkeypatch.setattr(userauth, "_TURNSTILE_VERIFY_URL", url)
        userauth.UA.cfg = UserAuthCfg(reg_captcha="turnstile", reg_captcha_id="site",
                                      reg_captcha_key="sk-test", login_captcha="risk")
        chk = userauth._captcha_check
        assert (await chk("tok-login", "1.2.3.4", scope="login"))[0] is True
        assert (await chk("tok-noact", "1.2.3.4", scope="login"))[0] is True     # 旧前端令牌
        assert (await chk("tok-register", "1.2.3.4", scope="login"))[1] == "captcha_failed"
        assert (await chk("junk", "1.2.3.4", scope="login"))[1] == "captcha_failed"
        assert (await chk("", "1.2.3.4", scope="login"))[1] == "captcha_failed"
        userauth.UA.cfg.reg_captcha_key = "wrong-secret"             # 运维配错:不是用户的错
        assert (await chk("tok-login", "1.2.3.4", scope="login"))[1] == "captcha_unavailable"
    finally:
        await runner.cleanup()
    monkeypatch.setattr(userauth, "_TURNSTILE_VERIFY_URL", url)      # 已关停:网络不可达
    userauth.UA.cfg.reg_captcha_key = "sk-test"
    assert (await userauth._captcha_check("tok-login", "1.2.3.4", scope="login"))[1] \
        == "captcha_unavailable"


# ══ 联测(复刻用户库 + fakeredis) ═════════════════════════════════════════════
def _cfg(**kw) -> UserAuthCfg:
    base = dict(host=_HOST, port=_PORT, db="fanxing_changkong_user_db",
                user="fanxing_admin", password="fanxing_admin,.", charset="gbk",
                cache_ttl_s=0.0, login_pow_bits=8, login_attack_5m=0)
    base.update(kw)
    return UserAuthCfg(**base)


@pytest_asyncio.fixture()
async def lg_env():
    """init → 用例 → 收尾;每次一个全新的 fakeredis(计数零串味)。"""
    async def _setup(cfg: UserAuthCfg, redis: bool = True):
        r = _fakered.FakeRedis() if (redis and _HAVE_FAKEREDIS) else None
        await userauth.init(cfg, r)
        assert userauth.UA.schema_ok or await userauth._ensure_schema()
        return r
    yield _setup
    await userauth.close()
    userauth.UA.cfg = None
    userauth.UA.cache = {}
    userauth.UA.schema_ok = False
    userauth.UA.redis = None


def _solve(salt: str, bits: int) -> str:
    prefix = userauth._reg_pow_transform(salt)
    for i in range(1 << 24):
        if userauth._lead_zero_bits(hashlib.sha256(f"{prefix}:{i}".encode()).digest()) >= bits:
            return str(i)
    raise AssertionError("solve failed")


def _proof(body: dict) -> dict:
    ch = body["challenge"]
    return {"challengeId": ch["challengeId"], "nonce": _solve(ch["salt"], ch["bits"])}


async def _login(name, pw, ip, **kw):
    return await userauth.login(name, pw, ip, "pytest-guard", **kw)


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_concurrent_burst_cannot_exceed_hard_limit(lg_env):
    """★ 竞态回归:旧实现 60 个并发错口令**全部**进入验密(上限 10)。
    先占后验后:进入验密的次数恰等于上限,其余 429。"""
    await lg_env(_cfg(login_fail_user=10, login_fail_ip=100000,
                      login_stepup_user=0, login_stepup_ip=0))
    res = await asyncio.gather(*[_login("测试用户A", "bad", f"7.7.{i // 250}.{i % 250}")
                                 for i in range(60)])
    st = collections.Counter(x[0] for x in res)
    assert st[401] == 10 and st[429] == 50, st


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_concurrent_burst_with_default_stepup(lg_env):
    await lg_env(_cfg(login_fail_user=10, login_fail_ip=100000))
    res = await asyncio.gather(*[_login("测试用户A", "bad", f"7.8.{i // 250}.{i % 250}")
                                 for i in range(60)])
    st = collections.Counter(x[0] for x in res)
    assert st[401] <= 4 and set(st) <= {401, 428, 429}, st


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_stepup_pow_flow_and_refund(lg_env):
    """软阈值(默认 4)后要求加码;解题重提可登录;428 本身不计失败;挑战单次有效。"""
    r = await lg_env(_cfg(login_fail_user=10, login_fail_ip=100000))
    for i in range(4):
        st, _, _ = await _login("plainuser", "wrong", f"6.1.0.{i}")
        assert st == 401
    ku, _ = userauth._thr_keys("plainuser", "")
    assert int(await r.get(ku)) == 4
    st, body, tok = await _login("plainuser", "plain#pw", "6.1.0.9")
    assert st == 428 and body["error"] == "challenge_required" and tok is None
    assert body["reason"] == "risk" and "captcha" not in body
    assert int(await r.get(ku)) == 4                  # 没验密 → 不计失败
    bad = {"challengeId": body["challenge"]["challengeId"], "nonce": "0"}
    st, b2, _ = await _login("plainuser", "plain#pw", "6.1.0.9", proof=bad)
    if st == 428:                                     # nonce=0 极小概率恰好过题
        assert b2["reason"] == "pow_failed"
    st, b3, _ = await _login("plainuser", "plain#pw", "6.1.0.9", proof=bad)
    assert st == 428 and b3["reason"] == "expired"     # 单次性:同一挑战不能复用
    st, body, tok = await _login("plainuser", "plain#pw", "6.1.0.9", proof=_proof(b3))
    assert st == 200 and tok
    assert not await r.exists(ku)                     # 未受信设备成功 → 同名计数归零(旧语义)
    await userauth.logout(tok)


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_attacker_cannot_lock_out_owner_on_trusted_device(lg_env):
    """★ 锁人回归:旧实现里攻击者连错 10 次,真主人输对口令也 429。
    设备信任后:真主人在常用浏览器照常登录;陌生设备仍被锁;真主人的成功
    **不**替攻击者把同名计数归零。"""
    r = await lg_env(_cfg(login_fail_user=5, login_fail_ip=100000,
                          login_stepup_user=0, login_stepup_ip=0))
    dev = await userauth.device_cookie_value("plainuser")
    for i in range(5):
        assert (await _login("plainuser", "wrong", "5.5.5.5"))[0] == 401
    assert (await _login("plainuser", "wrong", "5.5.5.5"))[0] == 429
    st, _, _ = await _login("plainuser", "plain#pw", "6.6.6.6")
    assert st == 429                                  # 陌生设备:锁照旧生效
    st, body, tok = await _login("plainuser", "plain#pw", "6.6.6.6", device=dev)
    assert st == 200 and tok and "_dev" not in body   # 受信设备:照常进门;内部字段不外泄
    assert (await _login("plainuser", "wrong", "5.5.5.5"))[0] == 429    # 攻击者仍被锁
    ku, _ = userauth._thr_keys("plainuser", "")
    assert await r.exists(ku)
    await userauth.logout(tok)


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_trusted_device_has_its_own_budget(lg_env):
    """受信设备不是免死金牌:设备自身失败用尽额度后,按未受信处理。"""
    await lg_env(_cfg(login_fail_user=3, login_fail_ip=100000,
                      login_stepup_user=0, login_stepup_ip=0))
    dev = await userauth.device_cookie_value("plainuser")
    for _ in range(3):
        assert (await _login("plainuser", "wrong", "6.2.0.1", device=dev))[0] == 401
    ku, _ = userauth._thr_keys("plainuser", "")
    assert await userauth._win_peek(ku, userauth.UA.mem_fail) == 0   # 设备失败不进同名桶
    for _ in range(3):                                # 设备额度尽 → 改记同名桶
        assert (await _login("plainuser", "wrong", "6.2.0.1", device=dev))[0] == 401
    assert (await _login("plainuser", "plain#pw", "6.2.0.1", device=dev))[0] == 429


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_ipv6_same_64_shares_ip_budget(lg_env):
    """★ IPv6 回归:旧实现同一 /64 内换末位地址即绕过按 IP 上限(40 次全验密)。"""
    await lg_env(_cfg(login_fail_user=100000, login_fail_ip=30,
                      login_stepup_user=0, login_stepup_ip=0))
    sts = [(await _login(f"nouser{i}", "bad", f"2001:db8:1:2::{i + 1:x}"))[0] for i in range(40)]
    assert sts.count(401) == 30 and sts.count(429) == 10


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_throttled_audit_rows_are_bounded(lg_env):
    """★ 写放大回归:旧实现锁定期每次请求写一行审计(100 次 = 100 行)。
    现按「锁的是谁」去重:多 IP 轮番撞同一个被锁账号,每窗口只记一行。"""
    await lg_env(_cfg(login_fail_user=3, login_fail_ip=100000,
                      login_stepup_user=0, login_stepup_ip=0))
    name = "audittarget"
    await userauth._q("DELETE FROM guantai_login_log WHERE user_name=%s", (name,))
    for i in range(3):
        await _login(name, "bad", f"6.3.0.{i}")
    for i in range(50):
        assert (await _login(name, "bad", f"6.4.{i}.1"))[0] == 429
    row = await userauth._q("SELECT COUNT(*) AS n FROM guantai_login_log "
                            "WHERE user_name=%s AND reason='throttled'", (name,), fetch="one")
    assert int(row["n"]) == 1


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_global_attack_mode_catches_spraying(lg_env):
    """★ 撒网回归:每个用户名、每个 IP 只试一次,单键阈值永远摸不到。全局攻击态后,
    陌生设备一律加码;受信设备不受影响。"""
    await lg_env(_cfg(login_fail_user=10, login_fail_ip=30, login_attack_5m=10))
    for i in range(10):
        assert (await _login(f"spray{i}", "123456", f"9.{i}.1.1"))[0] == 401
    userauth.UA.lg_attack = ()                        # 跳过 5s 缓存,立即重算
    st, body, _ = await _login("spray99", "123456", "9.99.1.1")
    assert st == 428 and body["reason"] == "risk" and body["challenge"]["bits"] >= 10
    dev = await userauth.device_cookie_value("plainuser")
    st, _, tok = await _login("plainuser", "plain#pw", "9.98.1.1", device=dev)
    assert st == 200 and tok
    await userauth.logout(tok)


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_login_captcha_always_and_degrade(lg_env, monkeypatch):
    """登录 Turnstile 开关(always 档):无令牌 → 428 要验证码;有效令牌 → 登录;
    坏令牌 → 428 captcha_failed;供应商不可达 → 熔断,降级为本站 PoW 仍能登录。"""
    runner, url = await _start_siteverify()
    monkeypatch.setattr(userauth, "_TURNSTILE_VERIFY_URL", url)
    try:
        await lg_env(_cfg(reg_captcha="turnstile", reg_captcha_id="site-key",
                          reg_captcha_key="sk-test", login_captcha="always"))
        assert userauth.login_session_info()["captchaMode"] == "always"
        st, body, _ = await _login("plainuser", "plain#pw", "6.5.0.1")
        assert st == 428 and body["captcha"]["provider"] == "turnstile" \
            and body["captcha"]["appId"] == "site-key" and "challenge" not in body
        st, body, _ = await _login("plainuser", "plain#pw", "6.5.0.1", proof={"captchaToken": "junk"})
        assert st == 428 and body["reason"] == "captcha_failed"
        st, _, tok = await _login("plainuser", "plain#pw", "6.5.0.1",
                                  proof={"captchaToken": "tok-login"})
        assert st == 200 and tok
        await userauth.logout(tok)
    finally:
        await runner.cleanup()
    st, body, _ = await _login("plainuser", "plain#pw", "6.5.0.2", proof={"captchaToken": "tok-login"})
    assert st == 428 and body["reason"] == "captcha_degraded" and "challenge" in body
    st, _, tok = await _login("plainuser", "plain#pw", "6.5.0.2", proof=_proof(body))
    assert st == 200 and tok                          # 熔断期:PoW 即可,不再要令牌
    await userauth.logout(tok)


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_login_captcha_risk_mode_only_when_suspicious(lg_env, monkeypatch):
    runner, url = await _start_siteverify()
    monkeypatch.setattr(userauth, "_TURNSTILE_VERIFY_URL", url)
    try:
        await lg_env(_cfg(login_fail_user=10, login_fail_ip=100000, reg_captcha="turnstile",
                          reg_captcha_id="site-key", reg_captcha_key="sk-test", login_captcha="risk"))
        st, _, tok = await _login("plainuser", "plain#pw", "6.6.0.1")
        assert st == 200 and tok                      # 正常用户:零打扰
        await userauth.logout(tok)
        for i in range(4):
            await _login("plainuser", "wrong", f"6.6.1.{i}")
        st, body, _ = await _login("plainuser", "plain#pw", "6.6.0.2")
        assert st == 428 and "captcha" in body and "challenge" in body
        pr = _proof(body)
        pr["captchaToken"] = "tok-login"
        st, _, tok = await _login("plainuser", "plain#pw", "6.6.0.2", proof=pr)
        assert st == 200 and tok
        await userauth.logout(tok)
    finally:
        await runner.cleanup()


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_challenge_issuance_is_rate_limited(lg_env):
    await lg_env(_cfg(login_fail_user=10, login_fail_ip=100000, login_chal_ip_10m=2))
    for i in range(4):
        await _login("plainuser", "wrong", f"6.7.1.{i}")
    assert (await _login("plainuser", "x", "6.7.0.1"))[0] == 428
    assert (await _login("plainuser", "x", "6.7.0.1"))[0] == 428
    st, body, _ = await _login("plainuser", "x", "6.7.0.1")
    assert st == 429 and body["retryAfter"] > 0


@needs_db
@pytest.mark.asyncio
async def test_without_redis_hard_limits_still_hold(lg_env):
    """协调层不可用:加码 PoW 暂停(挑战无处存放),硬上限照常生效(进程内计数)——
    风控组件故障**不放开**爆破。旧版进程内兜底的 IP 阈值错用也一并验掉。"""
    await lg_env(_cfg(login_fail_user=6, login_fail_ip=5, login_fail_window_s=60,
                      login_lock_s=600), redis=False)
    sts = [(await _login(f"memu{i}", "bad", "4.4.4.4"))[0] for i in range(6)]
    assert sts == [401] * 5 + [429]
    ki = userauth._thr_keys("x", "4.4.4.4")[1]
    left = userauth.UA.mem_fail[ki][1] - time.monotonic()
    assert 500 < left <= 600                           # 恰达 IP 上限才抬成锁定期


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_sso_link_channel_stepup_semantics(lg_env):
    """账密签发通道(服务端对服务端,解不了题):需要加码时,没配密钥 → 429(否则它
    就是绕开加码/人机验证的后门);配了密钥 → 视为受托方已把关,照常验密。"""
    await lg_env(_cfg(login_fail_user=10, login_fail_ip=100000, sso_enabled=True,
                      sso_link_enabled=True))
    for i in range(4):
        await _login("plainuser", "wrong", f"6.8.1.{i}")
    st, body = await userauth.sso_link({"userName": "plainuser", "password": "plain#pw"},
                                       "", "6.8.0.1", "t")
    assert st == 429 and "STA_USER_SSO_LINK_KEY" in body["message"]
    userauth.UA.cfg.sso_link_key = "k-123"
    st, body = await userauth.sso_link({"userName": "plainuser", "password": "plain#pw"},
                                       "Bearer k-123", "6.8.0.1", "t")
    assert st == 200 and body.get("ticket")


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_login_endpoint_http_contract(lg_env):
    """HTTP 层:只收 JSON 对象、同源校验、设备 Cookie 属性、Retry-After、no-store。"""
    import httpx
    from fastapi import FastAPI
    await lg_env(_cfg(login_fail_user=3, login_fail_ip=100000,
                      login_stepup_user=0, login_stepup_ip=0))
    app = FastAPI()
    app.include_router(userauth.router)
    tr = httpx.ASGITransport(app=app, client=("203.0.113.5", 4321))
    async with httpx.AsyncClient(transport=tr, base_url="http://obs.example") as c:
        assert (await c.post("/api/auth/login", json=[1, 2])).status_code == 400
        r = await c.post("/api/auth/login", content='{"userName":"plainuser","password":"plain#pw"}',
                         headers={"Content-Type": "text/plain"})
        assert r.status_code == 415 and "set-cookie" not in r.headers
        r = await c.post("/api/auth/login", json={"userName": "plainuser", "password": "plain#pw"},
                         headers={"Origin": "https://evil.example"})
        assert r.status_code == 403 and r.json()["error"] == "bad_origin"
        r = await c.post("/api/auth/login", json={"userName": "plainuser", "password": "plain#pw"},
                         headers={"Origin": "http://obs.example",
                                  "X-Forwarded-For": "10.9.9.9"})     # 公网对端的 XFF 不采信
        assert r.status_code == 200
        cookies = r.headers.get_list("set-cookie")
        dev = [x for x in cookies if x.startswith("jf_dev=")]
        assert any(x.startswith("jf_user_sid=") for x in cookies) and dev
        low = dev[0].lower()
        assert "httponly" in low and "path=/api/auth/" in low and "samesite=lax" in low
        row = await userauth._q("SELECT ip FROM guantai_user_session WHERE user_name=%s "
                                "ORDER BY id DESC LIMIT 1", ("plainuser",), fetch="one")
        assert row["ip"] == "203.0.113.5"
        for _ in range(3):
            await c.post("/api/auth/login", json={"userName": "nobody-x", "password": "bad"})
        r = await c.post("/api/auth/login", json={"userName": "nobody-x", "password": "bad"})
        assert r.status_code == 429 and int(r.headers["retry-after"]) > 0
        assert r.headers.get("cache-control") == "no-store"
        # 登出同样校验来源(同类模式):跨站 → 403 且不下发清 Cookie;同源 → 200
        r = await c.post("/api/auth/logout", headers={"Origin": "https://evil.example"})
        assert r.status_code == 403 and "set-cookie" not in r.headers
        r = await c.post("/api/auth/logout", headers={"Origin": "http://obs.example"})
        assert r.status_code == 200


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_captcha_misconfig_degrades_to_pow_instead_of_locking_users_out(lg_env):
    """★ 复查补漏:开了登录人机验证却没填共用凭据 —— 旧写法照样要求验证码,前端拿空 sitekey
    渲染必失败,用户卡死。现按本站 PoW 加码,登录不中断。"""
    await lg_env(_cfg(reg_captcha="turnstile", login_captcha="always"))
    assert userauth.login_session_info() == {}            # 前端不会去挂一个注定失败的挂件
    st, body, _ = await _login("plainuser", "plain#pw", "6.9.0.1")
    assert st == 428 and "challenge" in body and "captcha" not in body
    st, _, tok = await _login("plainuser", "plain#pw", "6.9.0.1", proof=_proof(body))
    assert st == 200 and tok
    await userauth.logout(tok)


@needs_redis
@pytest.mark.asyncio
async def test_sso_limiters_are_atomic_and_bucket_ipv6():
    """同类模式:SSO 兑换限频旧写法非原子、按原始 IPv6 分桶(换末位即绕过)。"""
    r = _fakered.FakeRedis()
    userauth.UA.cfg, userauth.UA.redis = UserAuthCfg(), r
    userauth.UA.mem_sso = {}
    res = [await userauth._sso_throttled(f"2001:db8:5:6::{i + 1:x}") for i in range(userauth._SSO_IP_10M + 1)]
    assert all(x is None for x in res[:-1]) and res[-1] and res[-1] > 0
    key = "guantai:sso:ip:2001:db8:5:6::/64"
    assert 0 < await r.ttl(key) <= userauth._SSO_WIN_S
    for _ in range(userauth._SSO_LINK_BADKEY_10M):
        await userauth._sso_link_badkey("2001:db8:7:8::1", bump=True)
    assert await userauth._sso_link_badkey("2001:db8:7:8::ffff", bump=False)    # 同 /64 共享额度


# ══ 管理台登录防爆破(5.2.0)═══════════════════════════════════════════════════
def _admin_app(monkeypatch, **env):
    from fastapi import FastAPI
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "adm-pass-410")
    monkeypatch.delenv("STA_ADMIN_IP_ALLOW", raising=False)
    for k, v in env.items():
        monkeypatch.setenv(k, str(v))
    admin_auth._reset_for_tests()
    a = FastAPI()
    a.include_router(admin_api.router, prefix="/api/admin")   # 5.3.0:前缀在挂载时给
    return a


def _admin_client(app, cookies=None):
    import httpx
    tr = httpx.ASGITransport(app=app, client=("127.0.0.1", 5000))    # 同机反代:XFF 可信
    return httpx.AsyncClient(transport=tr, base_url="http://adm.example", cookies=cookies)


@pytest.mark.asyncio
async def test_admin_login_failures_are_capped_even_when_concurrent(monkeypatch):
    """★ 旧版:每 IP 每小时 720 次;Redis 抖动时 0 限制。现:每 IP 段 10 次失败即锁,并发也穿不透。"""
    app = _admin_app(monkeypatch)
    async with _admin_client(app) as c:
        rs = await asyncio.gather(*[c.post("/api/admin/login", json={"password": f"x{i}"},
                                           headers={"X-Forwarded-For": "198.51.100.20"})
                                    for i in range(25)])
        st = collections.Counter(r.status_code for r in rs)
        assert st[401] == 10 and st[429] == 15, st
        r = await c.post("/api/admin/login", json={"password": "adm-pass-410"},
                         headers={"X-Forwarded-For": "198.51.100.20"})
        assert r.status_code == 429 and int(r.headers["retry-after"]) > 0


@pytest.mark.asyncio
async def test_admin_global_cap_spares_trusted_browser(monkeypatch):
    """多 IP 分布式猜管理台口令 → 全站上限封顶;曾登录成功的浏览器凭设备信任照常进门。"""
    app = _admin_app(monkeypatch, STA_ADMIN_LOGIN_FAIL_IP=100, STA_ADMIN_LOGIN_FAIL_GLOBAL=5)
    async with _admin_client(app) as owner:
        r = await owner.post("/api/admin/login", json={"password": "adm-pass-410"})
        assert r.status_code == 200
        dev = [x for x in r.headers.get_list("set-cookie") if x.startswith("jf_adm_dev=")]
        assert dev and "httponly" in dev[0].lower() and "path=/api/admin/" in dev[0].lower()
        async with _admin_client(app) as atk:
            for i in range(5):
                r = await atk.post("/api/admin/login", json={"password": "nope"},
                                   headers={"X-Forwarded-For": f"203.0.113.{i + 1}"})
                assert r.status_code == 401
            r = await atk.post("/api/admin/login", json={"password": "nope"},
                               headers={"X-Forwarded-For": "203.0.113.99"})
            assert r.status_code == 429
            r = await atk.post("/api/admin/login", json={"password": "adm-pass-410"},
                               headers={"X-Forwarded-For": "203.0.113.100"})
            assert r.status_code == 429                      # 陌生浏览器:锁照旧生效
        r = await owner.post("/api/admin/login", json={"password": "adm-pass-410"},
                             headers={"X-Forwarded-For": "198.51.100.77"})
        assert r.status_code == 200                          # 常用浏览器:不受全站锁牵连


@pytest.mark.asyncio
async def test_admin_login_buckets_ipv6_by_64(monkeypatch):
    app = _admin_app(monkeypatch, STA_ADMIN_LOGIN_FAIL_IP=3, STA_ADMIN_LOGIN_FAIL_GLOBAL=100)
    async with _admin_client(app) as c:
        for i in range(3):
            r = await c.post("/api/admin/login", json={"password": "nope"},
                             headers={"X-Forwarded-For": f"2001:db8:9:9::{i + 1:x}"})
            assert r.status_code == 401
        r = await c.post("/api/admin/login", json={"password": "nope"},
                         headers={"X-Forwarded-For": "2001:db8:9:9::abcd"})
        assert r.status_code == 429


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_rejected_attempts_do_not_burn_other_counters(lg_env):
    """★ 复查补漏:被拒(429)的尝试没验密,两份额度都要退还。否则共享出口被 IP 锁时,
    真人反复点登录会把自己的同名计数顶满 —— 一次口令都没验就把账号锁了。"""
    await lg_env(_cfg(login_fail_user=3, login_fail_ip=3, login_stepup_user=0, login_stepup_ip=0))
    for i in range(3):
        assert (await _login(f"natuser{i}", "bad", "100.64.0.1"))[0] == 401
    for _ in range(6):
        assert (await _login("plainuser", "plain#pw", "100.64.0.1"))[0] == 429     # 出口被锁
    ku, _ki = userauth._thr_keys("plainuser", "100.64.0.1")
    assert await userauth._win_peek(ku, userauth.UA.mem_fail) == 0
    st, _, tok = await _login("plainuser", "plain#pw", "198.51.100.8")            # 换个出口即正常
    assert st == 200 and tok
    await userauth.logout(tok)


@pytest.mark.asyncio
async def test_admin_rejected_attempts_do_not_inflate_global_counter(monkeypatch):
    """★ 复查补漏:已被锁的 IP 狂刷,不能把全站额度顶满、连带锁死所有陌生来源。"""
    app = _admin_app(monkeypatch, STA_ADMIN_LOGIN_FAIL_IP=2, STA_ADMIN_LOGIN_FAIL_GLOBAL=5)
    async with _admin_client(app) as c:
        hdr = {"X-Forwarded-For": "203.0.113.50"}
        for _ in range(2):
            assert (await c.post("/api/admin/login", json={"password": "nope"}, headers=hdr)).status_code == 401
        for _ in range(10):
            assert (await c.post("/api/admin/login", json={"password": "nope"}, headers=hdr)).status_code == 429
        for i in range(3):                       # 全站额度还剩 3,没被那 10 次被拒请求吃掉
            r = await c.post("/api/admin/login", json={"password": "nope"},
                             headers={"X-Forwarded-For": f"203.0.113.{60 + i}"})
            assert r.status_code == 401
        r = await c.post("/api/admin/login", json={"password": "nope"},
                         headers={"X-Forwarded-For": "203.0.113.70"})
        assert r.status_code == 429              # 第 6 次失败才触全站上限


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_lock_duration_counts_from_trigger_even_when_shorter_than_window(lg_env):
    """★ 复查推翻初稿:锁定时长从触限那一刻起算(与 3.8.0 起线上 Redis 路径 `EXPIRE key lock`
    逐字一致)。初稿「只延长不缩短」在 锁定 < 窗口 时会把锁拖到窗口结束(此例 600s 而非 60s)。"""
    r = await lg_env(_cfg(login_fail_user=3, login_fail_ip=100000, login_fail_window_s=600,
                          login_lock_s=60, login_stepup_user=0, login_stepup_ip=0))
    for i in range(3):
        assert (await _login("plainuser", "wrong", f"6.10.0.{i}"))[0] == 401
    ku, _ = userauth._thr_keys("plainuser", "")
    assert 0 < await r.ttl(ku) <= 60
    st, body, _ = await _login("plainuser", "plain#pw", "6.10.0.9")
    assert st == 429 and body["retryAfter"] <= 60


@needs_db
@pytest.mark.asyncio
async def test_lock_duration_same_semantics_in_memory_fallback(lg_env):
    await lg_env(_cfg(login_fail_user=3, login_fail_ip=100000, login_fail_window_s=600,
                      login_lock_s=60, login_stepup_user=0, login_stepup_ip=0), redis=False)
    for i in range(3):
        assert (await _login("plainuser", "wrong", f"6.11.0.{i}"))[0] == 401
    ku, _ = userauth._thr_keys("plainuser", "")
    left = userauth.UA.mem_fail[ku][1] - time.monotonic()
    assert 0 < left <= 60


# ══ 人机验证供应商分支(本地模拟服务;5.2.0 复查补齐 —— 极验 / 腾讯云分支此前零覆盖)══════
async def _start_mock(handler):
    from aiohttp import web
    app = web.Application()
    app.router.add_post("/{tail:.*}", handler)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    return runner, f"http://127.0.0.1:{site._server.sockets[0].getsockname()[1]}"


@pytest.mark.asyncio
async def test_oversized_token_is_rejected_without_calling_provider(monkeypatch):
    """★ 复查补漏:超长 / 畸形令牌若打到供应商,可能换来 4xx 或解析失败,被误判成「暂不可用」
    → 登录侧全站降级为 PoW。现超长令牌直接判「未通过」,供应商一次都不打。"""
    from aiohttp import web
    hits = {"n": 0}

    async def h(req):
        hits["n"] += 1
        return web.json_response({"success": True, "action": "login"})
    runner, base = await _start_mock(h)
    try:
        monkeypatch.setattr(userauth, "_TURNSTILE_VERIFY_URL", base + "/siteverify")
        userauth.UA.cfg = UserAuthCfg(reg_captcha="turnstile", reg_captcha_id="site",
                                      reg_captcha_key="sk", login_captcha="always")
        ok, err, _ = await userauth._captcha_check("x" * 5000, "1.2.3.4", scope="login")
        assert (ok, err, hits["n"]) == (False, "captcha_failed", 0)
        ok, err, _ = await userauth._captcha_check("x" * 100, "1.2.3.4", scope="login")
        assert ok and hits["n"] == 1
    finally:
        await runner.cleanup()


@pytest.mark.asyncio
async def test_tencent_branch_classifies_errors_by_who_caused_them(monkeypatch):
    """腾讯云:CaptchaCode=1 通过;其余判未通过;参数类 Error(可能由客户端票据引起)判未通过,
    鉴权 / 内部类 Error(服务端侧)才判「暂不可用」。请求须带 TC3 签名头。"""
    import json as _json
    from aiohttp import web
    seen = []

    async def h(req):
        seen.append(dict(req.headers))
        body = _json.loads(await req.read())
        t = body.get("Ticket")
        if t == "ok":
            return web.json_response({"Response": {"CaptchaCode": 1, "RequestId": "r"}})
        if t == "inv":
            return web.json_response({"Response": {"Error": {"Code": "InvalidParameterValue", "Message": "x"}}})
        if t == "auth":
            return web.json_response({"Response": {"Error": {"Code": "AuthFailure.SignatureFailure", "Message": "x"}}})
        return web.json_response({"Response": {"CaptchaCode": 9, "RequestId": "r"}})
    runner, base = await _start_mock(h)
    try:
        monkeypatch.setattr(userauth, "_TENCENT_CAPTCHA_URL", base + "/")
        userauth.UA.cfg = UserAuthCfg(reg_captcha="tencent", reg_captcha_id="2000000000",
                                      reg_captcha_key="appsecret", reg_captcha_secret_id="sid",
                                      reg_captcha_secret_key="skey", login_captcha="risk")
        tk = lambda t: _json.dumps({"ticket": t, "randstr": "@abc"})
        chk = userauth._captcha_check
        assert (await chk(tk("ok"), "1.2.3.4", scope="login"))[0] is True
        assert (await chk(tk("nope"), "1.2.3.4", scope="login"))[1] == "captcha_failed"
        assert (await chk(tk("inv"), "1.2.3.4", scope="login"))[1] == "captcha_failed"
        assert (await chk(tk("auth"), "1.2.3.4", scope="login"))[1] == "captcha_unavailable"
        assert (await chk("not-json", "1.2.3.4", scope="login"))[1] == "captcha_failed"
        h0 = seen[0]
        assert h0.get("Authorization", "").startswith("TC3-HMAC-SHA256 ")
        assert h0.get("X-TC-Action") == "DescribeCaptchaResult"
        userauth.UA.cfg.reg_captcha_secret_key = ""                     # 云 API 密钥缺:服务端侧
        assert (await chk(tk("ok"), "1.2.3.4", scope="login"))[1] == "captcha_unavailable"
    finally:
        await runner.cleanup()


@pytest.mark.asyncio
async def test_geetest_branch_signs_and_never_degrades_on_client_caused_errors(monkeypatch):
    """极验 v4:sign_token = HMAC-SHA256(captcha_key, lot_number);result=success 才通过。
    status=error 可能由伪造的 gen_time 等字段引起(官方示例即「illegal gen_time」)→ 判未通过,
    不触发登录侧降级。"""
    import hmac as _hmac
    import json as _json
    from aiohttp import web

    async def h(req):
        f = await req.post()
        if f.get("gen_time") == "bad":
            return web.json_response({"status": "error", "code": "-50005", "msg": "illegal gen_time"})
        want = _hmac.new(b"gt-key", str(f.get("lot_number")).encode(), hashlib.sha256).hexdigest()
        ok = f.get("sign_token") == want and req.query.get("captcha_id") == "gt-id"
        return web.json_response({"status": "success", "result": "success" if ok else "fail", "reason": ""})
    runner, base = await _start_mock(h)
    try:
        monkeypatch.setattr(userauth, "_GEETEST_VERIFY_URL", base + "/validate")
        userauth.UA.cfg = UserAuthCfg(reg_captcha="geetest", reg_captcha_id="gt-id",
                                      reg_captcha_key="gt-key", login_captcha="risk")
        tk = lambda g: _json.dumps({"lot_number": "lot1", "captcha_output": "o", "pass_token": "p", "gen_time": g})
        assert (await userauth._captcha_check(tk("1700000000"), "1.2.3.4", scope="login"))[0] is True
        assert (await userauth._captcha_check(tk("bad"), "1.2.3.4", scope="login"))[1] == "captcha_failed"
        userauth.UA.cfg.reg_captcha_key = "wrong-key"
        assert (await userauth._captcha_check(tk("1700000000"), "1.2.3.4", scope="login"))[1] == "captcha_failed"
    finally:
        await runner.cleanup()


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_malformed_token_cannot_force_global_captcha_degrade(lg_env, monkeypatch):
    """★ 端到端:always 档下攻击者狂发超长令牌 —— 只得到 428 captcha_failed,供应商不被标记为
    「不可用」,其余用户仍须过人机验证(不会被降级成只要 PoW)。"""
    runner, url = await _start_siteverify()
    monkeypatch.setattr(userauth, "_TURNSTILE_VERIFY_URL", url)
    try:
        await lg_env(_cfg(reg_captcha="turnstile", reg_captcha_id="site-key",
                          reg_captcha_key="sk-test", login_captcha="always"))
        for _ in range(5):
            st, body, _ = await _login("plainuser", "plain#pw", "6.12.0.1", proof={"captchaToken": "A" * 9000})
            assert st == 428 and body["reason"] == "captcha_failed"
        assert userauth._cap_down() is False
        st, body, _ = await _login("plainuser", "plain#pw", "6.12.0.2")
        assert st == 428 and "captcha" in body                  # 其他人依旧要过人机验证
    finally:
        await runner.cleanup()


def test_captcha_settings_sit_together_as_one_group():
    """运维反馈:「人机验证供应商」埋在注册项中间,「登录人机验证」又隔着四项凭据,在管理台里
    看不出是一套。现六项以「人机验证 · 」开头,按「供应商 → 登录时机 → 凭据」紧挨着排在
    登录防爆破之后(管理台按登记顺序渲染)。键名不变,兼容既有覆盖与 .env。"""
    from app import config_registry as reg
    keys = [k for k, f in reg.REGISTRY.items() if f.section == "登录系统"]
    grp = ["userauth.reg_captcha", "userauth.reg_captcha_required", "userauth.login_captcha",
           "userauth.reg_captcha_id", "userauth.reg_captcha_key", "userauth.reg_captcha_secret_id",
           "userauth.reg_captcha_secret_key"]
    i = keys.index(grp[0])
    assert keys[i:i + len(grp)] == grp
    assert keys[i - 1] == "userauth.login_attack_5m"
    assert all(reg.REGISTRY[k].label.startswith("人机验证 · ") for k in grp)
    # 5.3.0:管理台板块另有一项「管理台登录人机验证」(只决定管理台登录要不要过,供应商与凭据
    # 仍是上面这一套)—— 本钉守的是「登录系统板块里的人机验证项集中成一段」,故按板块计数。
    assert sum(1 for f in reg.REGISTRY.values()
               if f.section == "登录系统" and "人机验证" in f.label) == len(grp)
    assert [k for k, f in reg.REGISTRY.items() if f.section != "登录系统" and "人机验证" in f.label] \
        == ["admin.login_captcha"]
    import pathlib
    env = (pathlib.Path(__file__).resolve().parent.parent / "deploy" / ".env.example").read_text(encoding="utf-8")
    pos = [env.index(n) for n in ("#STA_USER_REG_CAPTCHA=", "#STA_USER_REG_CAPTCHA_SECRET_KEY=",
                                  "#STA_USER_REG_CAPTCHA_REQUIRED=", "#STA_USER_LOGIN_CAPTCHA=")]
    assert pos == sorted(pos) and pos[-1] - pos[0] < 1500        # 样例里同样集中成一段


# ══ 管理台「登」登录风控(5.2.0)════════════════════════════════════════════════════
@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_login_risk_overview_unlock_and_log(lg_env):
    """概览:被锁账号(由近期失败的用户名反查散列计数键)、被锁 IP 段(扫计数键)、可疑来源按
    IP 段合并(IPv6 /64)、被针对账号、原因分布、攻击态读数;解锁后立即可登录;流水可筛。"""
    await lg_env(_cfg(login_fail_user=3, login_fail_ip=5, login_stepup_user=0, login_stepup_ip=0,
                      login_attack_5m=1000))
    await userauth._q("DELETE FROM guantai_login_log")
    for i in range(3):
        await _login("plainuser", "wrong", f"6.20.0.{i}")                 # 账号锁
    for i in range(5):
        await _login(f"sprayx{i}", "bad", "6.21.0.9")                      # IP 锁
    for i in range(2):
        await _login("v6victim", "bad", f"2001:db8:77:1::{i + 1:x}")        # 同一 /64
    ov = await userauth.login_risk_overview(24, 20)
    assert [u["name"] for u in ov["locked"]["users"]] == ["plainuser"]
    assert ov["locked"]["users"][0]["leftS"] > 0
    assert [x["bucket"] for x in ov["locked"]["ips"]] == ["6.21.0.9"]
    v6 = next(x for x in ov["topIps"] if x["bucket"] == "2001:db8:77:1::/64")
    assert (v6["n"], v6["ips"], v6["approx"]) == (2, 2, True)
    tu = {u["name"]: u for u in ov["topUsers"]}
    assert tu["plainuser"]["n"] == 3 and tu["plainuser"]["locked"] is True
    assert ov["byReason"]["bad_credentials"] == 10
    assert ov["attack"] == {"on": False, "fails5m": 10, "threshold": 1000}
    assert (await userauth.login_risk_unlock("user", "plainuser"))["existed"] is True
    st, _, tok = await _login("plainuser", "plain#pw", "6.22.0.1")
    assert st == 200 and tok
    await userauth.logout(tok)
    assert (await userauth.login_risk_unlock("ip", "6.21.0.9"))["existed"] is True
    assert (await _login("sprayz", "bad", "6.21.0.9"))[0] == 401
    d = await userauth.login_log_page(1, 50, q_reason="suspect")
    assert d["total"] == 11 and all(x["ok"] == 0 for x in d["items"])
    d = await userauth.login_log_page(1, 50, q_ok="1")
    assert d["total"] == 1 and d["items"][0]["user_name"] == "plainuser"
    assert (await userauth.login_log_page(1, 50, q_ip="6.21.0.9"))["total"] == 6
    assert (await userauth.login_log_page(1, 50, q_name="v6victim"))["total"] == 2
    assert (await userauth.login_log_page(1, 50, q_name="含😀表情"))["total"] == 0     # 不可表示 ⇒ 零行,不 500


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_admin_userlogin_endpoints_guarded_and_csrf(lg_env, monkeypatch):
    await lg_env(_cfg(login_fail_user=3, login_fail_ip=100000, login_stepup_user=0, login_stepup_ip=0))
    for i in range(3):
        await _login("plainuser", "wrong", f"6.23.0.{i}")
    app = _admin_app(monkeypatch)
    async with _admin_client(app) as c:
        assert (await c.get("/api/admin/userlogin/risk")).status_code in (401, 403)
        r = await c.post("/api/admin/login", json={"password": "adm-pass-410"})
        tok, csrf = r.json()["token"], r.json()["csrf"]
        h = {"X-Admin-Session": tok}
        d = (await c.get("/api/admin/userlogin/risk", headers=h)).json()
        assert d["ok"] and d["enabled"] and [u["name"] for u in d["locked"]["users"]] == ["plainuser"]
        d = (await c.get("/api/admin/userlogin/log?reason=suspect", headers=h)).json()
        assert d["ok"] and d["total"] >= 3
        r = await c.post("/api/admin/userlogin/unlock", json={"kind": "user", "value": "plainuser"}, headers=h)
        assert r.status_code == 403                                    # 写操作须 CSRF 双提交
        hw = {**h, "X-Admin-CSRF": csrf}
        assert (await c.post("/api/admin/userlogin/unlock", json={"kind": "bogus", "value": "x"},
                             headers=hw)).status_code == 400
        r = await c.post("/api/admin/userlogin/unlock", json={"kind": "user", "value": "plainuser"}, headers=hw)
        assert r.status_code == 200 and r.json()["existed"] is True
        d = (await c.get("/api/admin/userlogin/risk", headers=h)).json()
        assert d["locked"]["users"] == []                              # 解锁即清缓存,立刻反映


def test_registration_captcha_can_be_off_while_login_keeps_it(monkeypatch):
    """5.2.0 复查(源自运维的真实 .env):想要「注册不加验证框、登录可疑时弹验证码」——
    旧设计里「设了供应商 = 注册一律要过」表达不了。现由「人机验证 · 注册时也要」单独控制。"""
    c = UserAuthCfg(reg_captcha="turnstile", reg_captcha_id="0x4AAA-site", reg_captcha_key="sk",
                    login_captcha="risk", reg_captcha_required=False, reg_mode="open")
    userauth.UA.cfg = c
    assert userauth._cap_conf("reg")["provider"] == "off"
    assert userauth._cap_conf("login")["provider"] == "turnstile"
    assert asyncio.run(userauth._captcha_check("", "1.2.3.4", scope="reg"))[0] is True   # 注册不再要令牌
    assert userauth.login_session_info()["captcha"]["provider"] == "turnstile"
    c.reg_captcha_required = True                                       # 默认:与旧行为一致
    assert userauth._cap_conf("reg")["provider"] == "turnstile"
    assert asyncio.run(userauth._captcha_check("", "1.2.3.4", scope="reg"))[1] == "captcha_failed"
    from app import settings as st
    monkeypatch.setenv("STA_USER_REG_CAPTCHA_REQUIRED", "0")
    assert st.get_settings().userauth.reg_captcha_required is False
    monkeypatch.setenv("STA_USER_REG_CAPTCHA_REQUIRED", "1")
    assert st.get_settings().userauth.reg_captcha_required is True


def test_memory_fallback_is_hard_capped():
    """Redis 长时间不可用 + 海量不同键:进程内兜底不得无界增长(旧实现只清已过期项)。
    超过硬上限按「最先到期」淘汰一半,且刚计的那一笔绝不被淘汰。"""
    mem = {}
    t = [1000.0]
    clock = lambda: t[0]
    n = wincount._MEM_HARD + 1000
    for i in range(n):
        wincount.incr_mem(mem, f"k{i}", 3600, clock)
        t[0] += 0.01                                    # 每个键到期时刻不同,全部未过期
    assert len(mem) <= wincount._MEM_HARD
    assert mem[f"k{n - 1}"][0] == 1                      # 最新一笔保留
    assert "k0" not in mem                               # 最先到期的被淘汰
    # 清理节流:软上限之上、5 秒内再次计数不得触发全表扫描(旧写法每次都扫)
    calls = {"n": 0}
    real_sorted = sorted

    class Spy(dict):
        def items(self):
            calls["n"] += 1
            return super().items()
    m2 = Spy({f"x{i}": (1, 9e9) for i in range(wincount._MEM_SOFT + 5)})
    wincount._PRUNE_AT.pop(id(m2), None)
    for i in range(50):
        wincount.incr_mem(m2, f"y{i}", 600, lambda: 1000.0)
    assert calls["n"] <= 2 and real_sorted is sorted



# ══ 覆盖率复查补齐(5.2.0 从零复查):此前从未被测试执行过的生产路径 ══════════════════
@pytest.mark.asyncio
async def test_device_key_file_path_is_created_once_and_shared(tmp_path, monkeypatch):
    """生产走的是这条路径(compose 的 web 设了 STA_ACCOUNTS_PATH=/data/accounts.json),此前零覆盖。"""
    import stat
    monkeypatch.delenv("STA_USER_DEVICE_KEY", raising=False)
    monkeypatch.setenv("STA_ACCOUNTS_PATH", str(tmp_path / "accounts.json"))
    userauth.UA.cfg, userauth.UA.redis = UserAuthCfg(), None
    userauth.UA.dev_key, userauth.UA.dev_key_src = b"", ""
    k1 = await userauth._dev_key()
    f = tmp_path / ".login_device.key"
    assert userauth.UA.dev_key_src == "file" and f.exists()
    assert stat.S_IMODE(f.stat().st_mode) == 0o600 and len(f.read_text().strip()) == 64
    userauth.UA.dev_key, userauth.UA.dev_key_src = b"", ""          # 模拟另一个进程 / 重启
    assert await userauth._dev_key() == k1


@pytest.mark.asyncio
async def test_device_key_file_race_waits_for_content(tmp_path, monkeypatch):
    """★ 复查补漏:另一进程刚建好文件、还没写入内容 —— 旧实现立刻读到空串并永久改用别的密钥。"""
    monkeypatch.delenv("STA_USER_DEVICE_KEY", raising=False)
    monkeypatch.setenv("STA_ACCOUNTS_PATH", str(tmp_path / "accounts.json"))
    userauth.UA.cfg, userauth.UA.redis = UserAuthCfg(), _fakered.FakeRedis()
    userauth.UA.dev_key, userauth.UA.dev_key_src = b"", ""
    f = tmp_path / ".login_device.key"
    f.write_text("")                                                   # 对方已建文件,内容未写
    want = "ab" * 32

    async def writer():
        await asyncio.sleep(0.15)
        f.write_text(want)
    t = asyncio.ensure_future(writer())
    k = await userauth._dev_key()
    await t
    assert userauth.UA.dev_key_src == "file" and k == bytes.fromhex(want)


@pytest.mark.asyncio
async def test_device_key_corrupt_file_falls_back_to_redis(tmp_path, monkeypatch):
    monkeypatch.delenv("STA_USER_DEVICE_KEY", raising=False)
    monkeypatch.setenv("STA_ACCOUNTS_PATH", str(tmp_path / "accounts.json"))
    (tmp_path / ".login_device.key").write_text("not-hex")
    userauth.UA.cfg, userauth.UA.redis = UserAuthCfg(), _fakered.FakeRedis()
    userauth.UA.dev_key, userauth.UA.dev_key_src = b"", ""
    monkeypatch.setattr(asyncio, "sleep", _instant_sleep)
    await userauth._dev_key()
    assert userauth.UA.dev_key_src == "redis"


_real_sleep = asyncio.sleep


async def _instant_sleep(_s, *a, **k):
    await _real_sleep(0)


@pytest.mark.asyncio
async def test_wincount_decr_without_lua_never_goes_negative_or_creates_keys():
    """禁用脚本的 Redis(托管 / 代理):decr 走 EXISTS+DECR,负数归零且保留 TTL,缺键不新建。"""
    r = _fakered.FakeRedis()

    async def no_eval(*a, **k):
        raise Exception("ERR unknown command 'EVAL'")
    r.eval = no_eval
    wincount.STATE["lua"] = None
    await wincount.decr_redis(r, "k:missing")
    assert await r.exists("k:missing") == 0
    await r.set("k:x", 0, ex=100)
    await wincount.decr_redis(r, "k:x")
    assert int(await r.get("k:x")) == 0 and 0 < await r.ttl("k:x") <= 100
    assert wincount.STATE["lua"] is False


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_userdb_outage_is_503_and_never_counts_as_failure(lg_env, monkeypatch):
    """用户库不可达:503,且这次尝试的额度全数退还 —— 库抖一下不能把所有人锁掉。"""
    await lg_env(_cfg(login_fail_user=3, login_fail_ip=3, login_stepup_user=0, login_stepup_ip=0))

    async def boom(*a, **k):
        raise RuntimeError("userdb down")
    monkeypatch.setattr(userauth, "_q", boom)
    for _ in range(5):
        st, body, _ = await userauth.login("plainuser", "whatever", "6.30.0.1", "UA")
        assert st == 503 and body["error"] == "userdb_unavailable"
    ku, ki = userauth._thr_keys("plainuser", "6.30.0.1")
    assert await userauth._win_peek(ku, userauth.UA.mem_fail) == 0
    assert await userauth._win_peek(ki, userauth.UA.mem_fail) == 0


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_risk_overview_cache_mem_fallback_and_log_filters(lg_env, monkeypatch):
    await lg_env(_cfg(login_fail_user=10, login_fail_ip=100000, login_stepup_user=2, login_stepup_ip=0,
                      login_pow_bits=8))
    await userauth._q("DELETE FROM guantai_login_log")
    for i in range(3):
        await _login("plainuser", "wrong", f"6.31.0.{i}")               # 第 3 次 → 要求加码(落 challenge:risk)
    a = await userauth.login_risk_overview(24, 20)
    assert await userauth.login_risk_overview(24, 20) is a              # 10 秒内命中缓存
    d = await userauth.login_log_page(1, 50, q_reason="challenge")
    assert d["total"] >= 1 and all(x["reason"].startswith("challenge:") for x in d["items"])
    d = await userauth.login_log_page(1, 50, q_reason="bad_credentials")
    assert d["total"] == 2                                              # 要求加码的那次没验密,不算口令错
    userauth.UA.redis, userauth.UA.risk_cache = None, ()                # Redis 不可用:读进程内兜底
    ov = await userauth.login_risk_overview(24, 20)
    assert ov["locked"]["ips"] == [] and "dbError" not in ov
    monkeypatch.setattr(userauth, "_ensure_schema", _false)
    userauth.UA.risk_cache = ()
    ov = await userauth.login_risk_overview(24, 20)
    assert ov["dbError"] == "userdb_unavailable" and ov["topIps"] == []


async def _false(*a, **k):
    return False


@pytest.mark.asyncio
async def test_admin_trusted_device_budget_exhausted_falls_back_to_ip_limits(monkeypatch):
    """受信设备自己的额度用尽 → 按陌生设备处理(受 IP / 全站额度约束),不能成为无限猜的通道。"""
    app = _admin_app(monkeypatch, STA_ADMIN_LOGIN_FAIL_IP=3, STA_ADMIN_LOGIN_FAIL_GLOBAL=100)
    async with _admin_client(app) as c:
        assert (await c.post("/api/admin/login", json={"password": "adm-pass-410"})).status_code == 200
        for _ in range(3):                                              # 设备额度(=IP 上限 3)耗尽
            assert (await c.post("/api/admin/login", json={"password": "x"},
                                 headers={"X-Forwarded-For": "198.51.100.90"})).status_code == 401
        for i in range(3):                                              # 改按 IP:同 IP 再错 3 次即锁
            r = await c.post("/api/admin/login", json={"password": "x"},
                             headers={"X-Forwarded-For": "198.51.100.91"})
            assert r.status_code == 401, (i, r.status_code)
        r = await c.post("/api/admin/login", json={"password": "x"}, headers={"X-Forwarded-For": "198.51.100.91"})
        assert r.status_code == 429


def test_guard_report_warns_on_every_misconfiguration(capsys, monkeypatch):
    c = UserAuthCfg(reg_captcha="turnstle", login_captcha="risk")
    userauth.UA.cfg = c
    userauth._login_guard_report()
    out = capsys.readouterr().out
    assert "无法识别" in out and "还没选人机验证供应商" in out
    c.reg_captcha, c.login_captcha, c.sso_link_enabled = "turnstile", "always", True
    c._login_captcha_legacy = True
    monkeypatch.setattr(userauth, "sso_link_enabled", lambda: True)
    userauth._login_guard_report()
    out = capsys.readouterr().out
    assert "预览版写法" in out and "账密签发通道未配密钥" in out and "不支持中国大陆" in out


def test_clientip_describe_and_bad_items(capsys):
    for raw, want in (("none", "只认直连"), ("*", "无条件采信"), ("loopback", "可信代理")):
        clientip.configure(raw)
        assert want in clientip.describe(), (raw, clientip.describe())
    clientip.configure("loopback,not-a-net")
    clientip.is_trusted("127.0.0.1")
    assert "无法识别的项" in capsys.readouterr().out
    clientip.configure(None)


def test_effective_stepup_display_matches_behaviour(capsys):
    """软阈值 ≥ 硬上限时永远先撞硬锁、从不加码 —— 横幅与风控概览如实显示「关」。"""
    assert userauth._lg_soft_eff(3, -1) == 0 and userauth._lg_soft_eff(3, 4) == 0
    assert userauth._lg_soft_eff(10, -1) == 4 and userauth._lg_soft_eff(10, 0) == 0
    userauth.UA.cfg = UserAuthCfg(login_fail_user=3, login_fail_ip=30)
    userauth._login_guard_report()
    assert "加码 同名(关) / 同IP≥10" in capsys.readouterr().out



# ══ 改动行覆盖率复查补齐(5.2.0 从零复查第二轮):全量测试下仍未执行到的改动 ══════════════
@pytest.mark.asyncio
async def test_reg_session_info_respects_registration_switch(monkeypatch):
    """注册表单拿到的验证码配置(/api/auth/session 的 reg 段)必须尊重「注册时也要」开关。"""
    userauth.UA.cfg = UserAuthCfg(reg_mode="open", reg_pass_shape="md5", reg_captcha="turnstile",
                                  reg_captcha_id="0x4AAA-site", reg_captcha_key="sk", reg_captcha_required=True)
    userauth.UA.redis = None
    monkeypatch.setattr(userauth, "enabled", lambda: True)          # 注册的前置条件:登录系统已启用
    info = await userauth.reg_session_info()
    assert info["mode"] == "open" and info["captcha"] == {"provider": "turnstile", "appId": "0x4AAA-site"}
    userauth.UA.cfg.reg_captcha_required = False
    info = await userauth.reg_session_info()
    assert info["mode"] == "open" and "captcha" not in info


@pytest.mark.asyncio
async def test_register_endpoint_autologin_also_issues_device_cookie(monkeypatch):
    """注册即登录:与登录 200 同款,除会话 Cookie 外也下发设备信任 Cookie(此前该分支零执行)。"""
    from fastapi import FastAPI
    import httpx
    userauth.UA.cfg, userauth.UA.redis = UserAuthCfg(host="db.example", reg_mode="open"), None

    async def fake_register(body, ip, ua):
        return 200, {"ok": True, "user": {"id": 7, "userName": "newbie"}}, "tok-new"
    monkeypatch.setattr(userauth, "register", fake_register)
    monkeypatch.setattr(userauth, "enabled", lambda: True)
    monkeypatch.setattr(userauth, "on_login_ok", None)
    app = FastAPI()
    app.include_router(userauth.router)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app, client=("203.0.113.9", 1)),
                                 base_url="http://obs.example") as c:
        r = await c.post("/api/auth/register", json={"userName": "newbie"})
    cookies = r.headers.get_list("set-cookie")
    assert r.status_code == 200
    assert any(x.startswith(userauth.UA.cfg.cookie_name + "=") for x in cookies)
    dev = [x for x in cookies if x.startswith("jf_dev=")]
    assert dev and "httponly" in dev[0].lower() and "path=/api/auth/" in dev[0].lower()


@pytest.mark.asyncio
async def test_origin_check_accepts_ipv6_literal_host(monkeypatch):
    """同源校验里 [::1]:5173 这类 IPv6 字面量 Host 的修正(此前零执行)。"""
    from fastapi import FastAPI
    import httpx
    userauth.UA.cfg, userauth.UA.redis = UserAuthCfg(host="db.example"), None
    monkeypatch.setattr(userauth, "enabled", lambda: True)
    app = FastAPI()
    app.include_router(userauth.router)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://[::1]:5173") as c:
        ok = await c.post("/api/auth/logout", headers={"Origin": "http://[::1]:5173"})
        bad = await c.post("/api/auth/logout", headers={"Origin": "http://[::2]:5173"})
    assert ok.status_code == 200 and bad.status_code == 403


@pytest.mark.asyncio
async def test_card_api_badkey_redis_path_is_atomic_and_buckets_ipv6():
    """外部发卡密钥错误闸的 Redis 路径(改为 wincount 原子计数后此前零执行)。"""
    from app import jfvip
    r = _fakered.FakeRedis()
    userauth.UA.cfg, userauth.UA.redis = UserAuthCfg(), r
    lim = jfvip._CARD_API_BADKEY_10M
    res = [await jfvip.card_api_badkey(f"2001:db8:aa:1::{i + 1:x}", bump=True) for i in range(lim)]
    assert all(x is None for x in res[:-1]) and res[-1] == jfvip._CARD_API_BADKEY_WIN_S
    assert await jfvip.card_api_badkey("2001:db8:aa:1::ffff", bump=False)          # 同 /64 共享额度
    assert await jfvip.card_api_badkey("2001:db8:aa:2::1", bump=False) is None      # 别的 /64 不受牵连
    keys = [k async for k in r.scan_iter(match="*")]
    ttls = [await r.ttl(k) for k in keys]
    assert keys and all(0 < t <= jfvip._CARD_API_BADKEY_WIN_S for t in ttls)


@pytest.mark.asyncio
async def test_logout_without_session_cookie_touches_nothing(monkeypatch):
    """没带会话的登出不打共享库、不广播(旧写法按空串散列 UPDATE 一次)。"""
    calls = []

    async def spy_q(*a, **k):
        calls.append(a)
    monkeypatch.setattr(userauth, "_q", spy_q)
    await userauth.logout("")
    assert calls == []

