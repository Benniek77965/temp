"""
test_discovery_reconcile.py — 发现循环的登记/隐藏/转正/回收/回灌(真实 Redis)
================================================================================
直接跑 worker 的**真实** `_discover_once` 编排与 `restore_discovered` 回灌
(用假 sweep + 假 PG 驱动,Redis 用真库),核对整条发现→纳管闭环:

  1) 首轮:新发现房入 active 名录 + 标 discovered + 排首抓;策展房(PG active)不被
     标记;前端可见集 = active − discovered = 仅策展房(即「前端只显示手动添加的房」);
     且 last_seen 时钟同步镜像进 PG(7 天回收计时跨重启存续的基础)。
  2) 转正:手动添加某发现房(discovered_remove)后,该房移出发现集 → 前端可见。
  3) 回收:发现房连续 grace 未再出现且非策展 → 从 active/发现集/调度彻底回收
     (meta 删净,不留 active:False 残影),PG 时钟行同删。
  4) 回灌:worker 重启后按 PG 时钟恢复运行态 —— 未超 grace 的恢复(HSETNX,运行态
     更新者胜)、超 grace 的清理、已转正的跳过;重启不清零 7 天计时。

只测 Redis/编排层;抓取/预测另有各自单测。无 Redis 时自动跳过。
"""
import os
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.discovery import restore_discovered  # noqa: E402
from app.redis_bus import K_ROOMS_DISCOVERED, RedisBus, now_ms  # noqa: E402
from app.settings import DiscoveryCfg        # noqa: E402
from app.worker import Worker                # noqa: E402

REDIS_URL = os.environ.get("STA_TEST_REDIS_URL", "redis://127.0.0.1:6379/15")


def _redis_available() -> bool:
    try:
        import redis
        redis.from_url(REDIS_URL).ping()
        return True
    except Exception:
        return False


pytestmark = pytest.mark.skipif(not _redis_available(),
                                reason="需要 Redis(设 STA_TEST_REDIS_URL)")

M1 = "70000001"   # 用户手动添加的策展房(PG active)
D1 = "51000001"   # 自动发现房
D2 = "51000002"   # 自动发现房


class _FakeDisc:
    """假发现器:sweep() 返回预置结果(与 Discovery.sweep 输出同形)。"""
    def __init__(self):
        self.result = None

    async def sweep(self):
        return self.result


class _FakeDB:
    """假 PG:active_rooms() 返回策展房列表(发现房不落 PG rooms,故只含手动添加房);
    discovered 字典模拟 discovered_rooms 时钟表(room_id -> last_seen_ms),
    upsert 与真实 SQL 同为 GREATEST 语义(旧写者绝不回拨新时钟)。"""
    def __init__(self, rooms, discovered=None):
        self._rooms = list(rooms)
        self.discovered = dict(discovered or {})
        self.purged_history = []          # 记录被级联清史的房号(离线回收验证用)

    async def active_rooms(self):
        return [{"room_id": r, "alias": r} for r in self._rooms]

    async def discovered_upsert_bulk(self, rows, batch_size=500):
        for rid, ts in rows:
            rid = str(rid)
            self.discovered[rid] = max(int(ts), self.discovered.get(rid, 0))

    async def discovered_all(self):
        return [{"room_id": r, "last_seen_ms": t}
                for r, t in sorted(self.discovered.items())]

    async def discovered_delete_bulk(self, room_ids, batch_size=500):
        for rid in room_ids:
            self.discovered.pop(str(rid), None)

    async def purge_rooms_history(self, room_ids, **kw):
        """记录被级联清史的房号(离线回收 / 回灌期回收触发)。"""
        for rid in room_ids:
            self.purged_history.append(str(rid))
        return {"rounds": 10 * len(room_ids), "predictions": 3 * len(room_ids)}


def _sweep(rooms, stopped_by="empty"):
    return {"rooms": list(rooms), "pages": 1, "fetched": len(rooms),
            "unique": len(rooms), "truncated": False, "stopped_by": stopped_by}


@pytest.mark.asyncio
async def test_discover_once_admit_hide_promote_prune():
    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()
    cfg = DiscoveryCfg(warmup_window_ms=1000, prune_grace_s=600)

    fdisc = _FakeDisc()
    fdb = _FakeDB([M1])                      # 起始:仅策展房 M1
    me = SimpleNamespace(disc=fdisc, db=fdb, bus=bus)

    # 策展房 M1 已在名录(经 /api/monitor/add 之类)
    await bus.add_room(M1, M1)

    # ── 首轮:live = M1 + D1 + D2 ────────────────────────────────────────────
    fdisc.result = _sweep([M1, D1, D2])
    await Worker._discover_once(me, cfg)

    active = set(await bus.active_rooms())
    discovered = await bus.discovered_members()
    visible = active - discovered            # 前端展示集
    assert active == {M1, D1, D2}            # 发现房入 active 名录
    assert discovered == {D1, D2}            # 只有发现房被标记
    assert visible == {M1}                   # 前端只显示手动添加的房
    # 新发现房已排首抓(策展房 M1 非本轮新增,不由发现器排程)
    sched = await bus.scheduled_rooms()
    assert D1 in sched and D2 in sched
    # 最近一轮统计已写入
    last = await bus.discovery_last()
    assert last and last["new_admitted"] == 2 and last["unique"] == 3
    # last_seen 时钟已镜像进 PG(7 天计时跨重启存续的基础);策展房不进时钟表
    assert set(fdb.discovered) == {D1, D2}
    assert fdb.discovered[D1] == last["ts_ms"]

    # ── 幂等:再来一轮相同 live,不重复登记、不误标策展房 ──────────────────────
    fdisc.result = _sweep([M1, D1, D2])
    await Worker._discover_once(me, cfg)
    assert set(await bus.active_rooms()) == {M1, D1, D2}
    assert await bus.discovered_members() == {D1, D2}
    last = await bus.discovery_last()
    assert last["new_admitted"] == 0         # 无新增
    assert fdb.discovered[D1] == last["ts_ms"]   # 时钟随轮次前滚(GREATEST)

    # ── 转正:手动添加发现房 D1 → 前端可见(与 web 转正路径一致:
    #    移出 Redis 发现集 + 清 PG 时钟残行 + 落 PG rooms 策展列表)──────────────
    await bus.discovered_remove(D1)
    await fdb.discovered_delete_bulk([D1])
    fdb._rooms.append(D1)                     # D1 现属策展列表
    active = set(await bus.active_rooms())
    discovered = await bus.discovered_members()
    assert discovered == {D2}
    assert (active - discovered) == {M1, D1}  # D1 转正后前端可见

    # ── 回收:令 D2 陈旧,且下一轮 live 不含 D2 → 回收 D2 ──────────────────────
    await bus.discovered_seen_bulk([D2], ts=now_ms() - 700 * 1000)  # 早于 600s grace
    fdisc.result = _sweep([M1, D1])           # D2 不再在播
    await Worker._discover_once(me, cfg)

    assert await bus.discovered_members() == set()      # D2 已移出发现集
    assert set(await bus.active_rooms()) == {M1, D1}    # D2 已移出 active 名录
    assert D2 not in await bus.scheduled_rooms()        # D2 调度任务清净
    assert await bus.r.hget("rooms", D2) is None        # D2 meta 删净(不留 active:False)
    assert D2 not in fdb.discovered                     # PG 时钟行同删(回灌不复活)
    assert fdb.purged_history == [D2]                    # 回收即清史:D2 历史被清空
    assert D1 not in fdb.purged_history                  # 转正房 D1 的历史绝不清
    last = await bus.discovery_last()
    assert last["pruned"] == 1
    assert last["purged_rounds"] == 10 and last["purged_predictions"] == 3

    await bus.close()


@pytest.mark.asyncio
async def test_discover_once_no_prune_on_failed_sweep():
    """遍历失败(stopped_by=error)或空结果时不回收 —— 避免网络抖动误伤全量发现房。"""
    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()
    cfg = DiscoveryCfg(warmup_window_ms=1000, prune_grace_s=600)
    fdisc = _FakeDisc()
    me = SimpleNamespace(disc=fdisc, db=_FakeDB([]), bus=bus)

    # 先正常纳入 D1、D2,并把它们的 last_seen 置为很旧(已过 grace)
    fdisc.result = _sweep([D1, D2])
    await Worker._discover_once(me, cfg)
    await bus.discovered_seen_bulk([D1, D2], ts=now_ms() - 700 * 1000)

    # 遍历失败(error)且返回空 → 绝不因此回收(否则一次网络失败清空全部发现房)
    fdisc.result = {"rooms": [], "pages": 0, "fetched": 0, "unique": 0,
                    "truncated": False, "stopped_by": "error"}
    await Worker._discover_once(me, cfg)
    assert await bus.discovered_members() == {D1, D2}   # 仍在,未被误回收
    assert set(await bus.active_rooms()) == {D1, D2}

    await bus.close()


@pytest.mark.asyncio
async def test_discover_once_self_heals_leaked_curated():
    """自愈不变式:策展房(PG active)若因竞态/漏转正泄漏进发现集,下一轮遍历即移出,
    保证策展房绝不被前端过滤掉(至多隐藏一个周期即恢复可见)。"""
    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()
    cfg = DiscoveryCfg(warmup_window_ms=1000, prune_grace_s=600)
    fdisc = _FakeDisc()
    fdb = _FakeDB([M1])                       # M1 是策展房(PG active)
    me = SimpleNamespace(disc=fdisc, db=fdb, bus=bus)

    # 构造泄漏:M1 既是策展房,又被误标进发现集(模拟漏转正/重启回灌竞态)
    await bus.add_room(M1, M1)
    await bus.discovered_seen_bulk([M1], ts=now_ms())
    await fdb.discovered_upsert_bulk([(M1, now_ms())])   # PG 时钟也有残行
    assert M1 in await bus.discovered_members()          # 泄漏态:M1 暂被隐藏

    # 跑一轮(M1 仍在播)→ reconcile 自愈,把 M1 移出发现集
    fdisc.result = _sweep([M1])
    await Worker._discover_once(me, cfg)

    active = set(await bus.active_rooms())
    discovered = await bus.discovered_members()
    assert M1 not in discovered                          # 已自愈:移出发现集
    assert M1 in (active - discovered)                   # 策展房恢复前端可见
    assert M1 not in fdb.discovered                      # PG 时钟残行同清(回灌不再复活)

    await bus.close()


# ── restore_discovered:worker 重启回灌(7 天计时跨重启存续) ─────────────────────
@pytest.mark.asyncio
async def test_restore_after_redis_wipe_keeps_grace_clock():
    """模拟 Redis 被清(compose 里 Redis 关持久化)后 worker 重启:
    PG 时钟里未超 grace 的发现房恢复运行态(名录 + 发现集 + 起抓),且 last_seen
    **原样保留**(不是重置为 now)—— 否则每次重启都会把 7 天计时清零;
    超 grace 的直接清理;已转正(现属策展)的跳过并清 PG 残行。"""
    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()                                # Redis 全清(重启/丢库)
    cfg = DiscoveryCfg(warmup_window_ms=1000, prune_grace_s=7 * 24 * 3600)
    nowv = now_ms()
    ts_fresh = nowv - 3 * 24 * 3600 * 1000               # 3 天前:未超 7 天 grace
    ts_old = nowv - 8 * 24 * 3600 * 1000                 # 8 天前:已超 grace
    fdb = _FakeDB([M1], discovered={D1: ts_fresh, D2: ts_old, M1: ts_fresh})

    rec = await restore_discovered(bus, fdb, cfg)
    assert rec == {"restored": 1, "admitted": 1, "expired": 1, "promoted": 1}

    # D1(3 天前见过):恢复为发现房 —— 隐藏于前端、在名录、已排抓取,时钟原样
    assert await bus.discovered_members() == {D1}
    assert set(await bus.active_rooms()) == {D1}
    assert D1 in await bus.scheduled_rooms()
    assert int(await bus.r.hget(K_ROOMS_DISCOVERED, D1)) == ts_fresh
    # D2(8 天前):等价回收 —— 不恢复,PG 行清掉;M1(已转正):跳过,PG 残行清掉
    assert set(fdb.discovered) == {D1}

    # 幂等 & 竞态安全:先有更新的运行态时钟,再次回灌绝不回拨(HSETNX)
    newer = nowv - 1000
    await bus.discovered_seen_bulk([D1], ts=newer)
    rec2 = await restore_discovered(bus, fdb, cfg)
    assert rec2["restored"] == 1 and rec2["admitted"] == 0   # 已在名录,不重复登记
    assert int(await bus.r.hget(K_ROOMS_DISCOVERED, D1)) == newer

    await bus.close()


@pytest.mark.asyncio
async def test_restore_survives_pg_outage():
    """回灌读 PG 失败时优雅跳过(不崩 worker 发现循环):在播房由随后的遍历自行重建。"""
    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()

    class _DeadDB(_FakeDB):
        async def discovered_all(self):
            raise RuntimeError("pg down")

    rec = await restore_discovered(bus, _DeadDB([]), DiscoveryCfg())
    assert rec == {"restored": 0, "admitted": 0, "expired": 0, "promoted": 0}
    assert await bus.discovered_members() == set()
    await bus.close()


# ── janitor 挂起转正:第 5 条转正入口同样清净发现态 ─────────────────────────────
@pytest.mark.asyncio
async def test_janitor_promotion_clears_discovered():
    """场景:用户添加短号 → 归一暂时失败进挂起;该短号对应的真实号恰是当前
    被自动发现的在播房。janitor 归一成功转正时,必须**当场**清净该房的发现态
    (Redis 发现集 + PG 时钟行),使其立即前端可见 —— 与 web add / add-bulk /
    config / seed_rooms 四条入口同一不变式,不等 reconcile 自愈(那最长要一个周期)。
    直接跑 worker 的真实 `_janitor`(canon 打桩、PG 打桩,Redis 用真库)。"""
    import asyncio
    import copy

    from app.settings import settings as _settings

    s2 = copy.deepcopy(_settings)
    s2.redis_url = REDIS_URL
    s2.scheduler.janitor_interval_s = 1        # 秒级节拍,测试无需久等
    s2.discovery.enabled = False               # 不构造发现器(本测只测 janitor)

    w = Worker(s2)
    await w.bus.r.flushdb()

    ALIAS, REAL = "777", "51009999"
    await w.bus.discovered_seen_bulk([REAL])   # 真实号正被自动发现(前端隐藏中)
    await w.bus.add_room(REAL, REAL)           # 且已在名录后台在抓
    await w.bus.pending_add(ALIAS)             # 用户短号挂起,待 janitor 归一

    async def fake_canon(a: str):
        return (REAL, True) if a == ALIAS else (str(a), False)
    w.star.canon = fake_canon                  # 打桩:不触网

    class _JDB:                                # 打桩 PG:只记调用
        def __init__(self):
            self.deleted, self.upserts = [], []

        async def upsert_room(self, rid, alias, active, pending=False):
            self.upserts.append((rid, alias, active, pending))

        async def discovered_delete_bulk(self, ids, batch_size=500):
            self.deleted.extend(str(r) for r in ids)
    w.db = _JDB()

    async def _stop():
        await asyncio.sleep(2.5)               # 覆盖 ≥1 个 janitor 周期
        w._running = False
    await asyncio.gather(w._janitor(), _stop())

    assert ALIAS not in await w.bus.pending_rooms()          # 已转正出挂起集
    assert REAL in set(await w.bus.active_rooms())           # 名录在
    assert REAL not in await w.bus.discovered_members()      # 发现集当场清净 → 前端可见
    assert REAL in w.db.deleted                              # PG 时钟残行同删(回灌不复活)
    assert (REAL, ALIAS, True, False) in w.db.upserts        # 落 PG 策展列表
    await w.bus.close()


# ── 到期潮涌:一次回收上千发现房(分块)必须彻底且不留残影 ─────────────────────
@pytest.mark.asyncio
async def test_prune_expiry_wave_chunked():
    """7 天 grace 存在「到期潮涌」(节假日后大批同时过期)。构造 1200 发现房
    (含调度任务与任务索引),一次 reconcile 全量回收 —— 跨多个 500 房分块,
    断言五处状态(active/名录meta/发现集/ZSET调度/任务索引/sched:rooms)
    全部清净、PG 时钟行同删,且耗时在秒级内(分块摊平,不长挂 Redis)。"""
    import time as _t

    from app.redis_bus import (K_ROOM_TASKS, K_ROOMS, K_SCHED, K_SCHED_ROOMS,
                               task_mainpage)

    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()
    cfg = DiscoveryCfg(warmup_window_ms=1000, prune_grace_s=600, batch_size=500)
    fdisc = _FakeDisc()
    fdb = _FakeDB([])
    me = SimpleNamespace(disc=fdisc, db=fdb, bus=bus)

    wave = [str(52_000_000 + i) for i in range(1200)]        # 3 个分块的量级
    fdisc.result = _sweep(wave)
    await Worker._discover_once(me, cfg)                     # 全部纳入(登记+排抓+PG镜像)
    assert len(await bus.discovered_members()) == 1200
    assert len(fdb.discovered) == 1200
    # 任务索引确在(抽查),回收必须经索引清 ZSET,不残留幽灵任务
    assert await bus.r.scard(K_ROOM_TASKS.format(room=wave[0])) >= 1

    # 令全量过期,下一轮 live 为空集?不行 —— 空遍历不回收(防误伤)。
    # 用「有别的房在播」的成功遍历触发潮涌回收。
    await bus.discovered_seen_bulk(wave, ts=now_ms() - 700 * 1000)
    OTHER = "52999999"
    fdisc.result = _sweep([OTHER])
    t0 = _t.monotonic()
    await Worker._discover_once(me, cfg)
    dt = _t.monotonic() - t0

    assert (await bus.discovery_last())["pruned"] == 1200
    assert await bus.discovered_members() == {OTHER}
    assert set(await bus.active_rooms()) == {OTHER}
    assert set(fdb.discovered) == {OTHER}                    # PG 时钟行同删
    # 五处运行态残影逐项为零(抽查首/中/尾各块的房)
    for r in (wave[0], wave[600], wave[-1]):
        assert await bus.r.hget(K_ROOMS, r) is None
        assert await bus.r.exists(K_ROOM_TASKS.format(room=r)) == 0
        assert not await bus.r.sismember(K_SCHED_ROOMS, r)
    assert await bus.r.zcard(K_SCHED) <= 1                   # 只剩 OTHER 的首抓
    assert dt < 5.0, f"潮涌回收应秒级完成,实测 {dt:.2f}s"
    await bus.close()
