"""conftest.py — 测试进程级隔离(消除跨模块的全局补丁泄漏)

背景(实测复现的顺序依赖 bug)
------------------------------
`scripts/sim_history_gap.py::build_world()` 为了做确定性仿真,把**虚拟时钟**直接
补丁进模块全局:

    rb.now_ms = clock        # redis_bus.now_ms
    wk.now_ms = clock        # worker.now_ms

而这个补丁**从不还原**。pytest 全套在**同一进程**里跑,于是任何一个导入并运行
仿真器的模块(`test_industrial.py` / `test_coverage_sentinel.py`)一旦跑过,
`redis_bus.now_ms` 就永久变成虚拟钟(T0 = 1_800_000_000_000 ms,比真实时钟**超前
约 555 天**)。

后果是**真实的、可复现的**:`discovery.reconcile_discovered` / `restore_discovered`
在**函数体内**做 `from .redis_bus import now_ms`(调用期查找),因此会读到被污染的
未来钟;`tests/test_discovery_reconcile.py::test_restore_after_redis_wipe_keeps_grace_clock`
里 3 天前(真实钟)的发现房,相对未来钟已"超 7 天 grace" → 被误判回收
(expired=2 而非 1),该用例**在全套里必挂、单独跑必过**。

对策
----
autouse fixture 在每个用例前后快照/还原这两个模块级符号。仿真器的补丁语义不变
(用例内照常生效),但**绝不越过用例边界**。这样测试顺序、`-p randomly`、并行
分片都不会再改变结果 —— 严格测试的前提是结果可复现。

注:生产代码路径从不 import `scripts.sim_history_gap`,故此泄漏只影响测试。
"""
from __future__ import annotations

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@pytest.fixture(autouse=True)
def _isolate_global_clock_patches():
    """还原仿真器对 now_ms 的模块级补丁(见模块头注释)。"""
    from app import redis_bus as rb
    from app import worker as wk

    saved = (rb.now_ms, wk.now_ms)
    try:
        yield
    finally:
        rb.now_ms, wk.now_ms = saved


@pytest.fixture(autouse=True)
def _isolate_admin_entry_cfg():
    """管理台入口配置逐用例隔离(5.3.0)。

    管理台账号来自环境变量 STA_ADMIN_USERNAME(settings.admin.username,进程级单例在导入时读入)。
    单元测试不该依赖某套环境:默认把账号复位成「未设置」(= 只验口令的模式,5.2.0 及更早的全部
    既有用例都按这个模式写),需要账号模式的用例自己设 settings.admin.username;用例对
    settings.admin 的任何改动都在用例结束时还原,不越过用例边界。
    「发货默认:config.yaml 只给入口、账号不在 config.yaml」另由 test_admin_entry.py 断言。"""
    import dataclasses
    from app.settings import settings as _s
    saved = dataclasses.replace(_s.admin)
    _s.admin.username = ""
    try:
        yield
    finally:
        for f in dataclasses.fields(saved):
            setattr(_s.admin, f.name, getattr(saved, f.name))


@pytest.fixture(autouse=True, scope="module")
def _isolate_userauth_state_per_module():
    """还原登录系统的进程级状态(5.2.0 补;**按模块**还原,不干扰模块内的有意共享)。

    实测复现的顺序依赖:真库联测(test_jfvip_db / test_jfvip_admin_realdb /
    test_jfvip_audit_4_3 / test_jfvip_hours_card)在 `_prepare()` 里直接
    `userauth.UA.cfg = <已启用的配置>`,收尾只 `close()` 不还原 cfg。只要本机连得上
    复刻库(这些用例才真跑),此后所有模块看到的都是「登录系统已启用」——
    `test_livestatus` / `test_rail_status` 的 `test_live_rooms_route_asgi_e2e`
    于是在全套里必挂(401 / 缺 rooms 键),单独跑必过。CI 上没有复刻库时这批用例
    整层 skip,泄漏不发生,所以一直没暴露。
    与上面的时钟隔离同一思路:被测代码不变,只保证全局状态不越过模块边界。"""
    from app import userauth as _ua
    st = _ua.UA
    saved = (st.cfg, st.redis, st.schema_ok)
    yield
    if st.cfg is not saved[0]:
        if st.router is not None:
            try:
                st.pool = None          # 真路由:同步拆池(见 _State.pool 的 setter)
            except Exception:           # noqa: BLE001
                st.router = None
        st.cfg, st.schema_ok, st.cache = saved[0], saved[2], {}
    st.redis = saved[1]
