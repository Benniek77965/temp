"""
test_lease_switch_broadcast.py — 3.9.4:租约切换广播 + 管理台租约可见性
================================================================================
钉住的契约(零外部依赖:fakeredis + 桩,模式与 test_active_room_lease.py 同源):

一、广播(把「被切走」的发现延迟从「≤20s 心跳下一拍」压到亚秒):
  · 频道名 alr:evt:u{uid};载荷 {"type":"lease-switch","room":<归一房号>}
  · POST /api/active-room/claim 抢占**成功**后广播一次(带 canon 后的房号)
  · roster 闸拒绝(fail-open 不抢占)时**不广播** —— 没抢到就没有"切换"可言
  · SSE 端到端:窗口 A 持流看 321,别处 claim 654 并广播 → A 在**亚秒~秒级**
    收到 follow(room=654)并收流(不等 20s 心跳)。消息只是触发器,决策以
    权威 renew 为准 —— 陈旧/乱序广播不产生错误跟随。

二、管理台可见性(此前租约状态对运维完全不可见):
  · bus.active_room_leases():SCAN alr:u* 只读清单(uid/room/ts/活页数,新→旧;
    非法键面 alr:uX 跳过)
  · bus.active_room_lease_force_release():整把 DEL,幂等(二次 False)
  · GET /api/admin/leases 携带 uname/alias/stale;POST /api/admin/leases/{uid}/release
    走会话+CSRF,释放后清单为空
"""
import asyncio
import contextlib
import json
import sys
import time
import types
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app.redis_bus as rb                      # noqa: E402
import app.web as web                           # noqa: E402
from app.redis_bus import RedisBus              # noqa: E402

TTL_MS = 40_000
NOW = 1_700_000_000_000
UID = 7


def _bus():
    import fakeredis.aioredis
    bus = RedisBus.__new__(RedisBus)
    bus.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    bus._lease_acq_sha = None
    bus._lease_rel_sha = None
    return bus


def _lua_ok() -> bool:
    try:
        import fakeredis
        fakeredis.FakeStrictRedis().eval("return 1", 0)
        return True
    except Exception:
        return False


pytestmark = pytest.mark.skipif(not _lua_ok(), reason="fakeredis 无 Lua 支持(pip install lupa)")


class _User:
    def __init__(self, uid=UID):
        self.user_id = uid


def _enable_auth(monkeypatch, on=True):
    monkeypatch.setattr(web.userauth, "enabled", lambda: on)


# ═══════════ 一、广播:总线层 wire 格式 ═══════════

@pytest.mark.asyncio
async def test_publish_lease_switch_wire_format():
    """频道名与载荷钉死:alr:evt:u{uid} · {"type":"lease-switch","room":...}。
    真订阅真发布(fakeredis pub/sub),不是打桩自证。"""
    bus = _bus()
    assert bus.lease_channel(UID) == "alr:evt:u7"
    ps = bus.r.pubsub()
    await ps.subscribe(bus.lease_channel(UID))
    # 吃掉订阅确认帧
    for _ in range(10):
        m = await ps.get_message(timeout=0.5)
        if m and m.get("type") == "subscribe":
            break
    await bus.publish_lease_switch(UID, "2066666")
    got = None
    for _ in range(20):
        m = await ps.get_message(timeout=0.5)
        if m and m.get("type") == "message":
            got = m
            break
        await asyncio.sleep(0.05)
    assert got is not None, "订阅端应收到广播"
    assert str(got["channel"]) == "alr:evt:u7"
    assert json.loads(got["data"]) == {"type": "lease-switch", "room": "2066666"}
    await ps.aclose()


# ═══════════ 一、广播:claim 端点触发面 ═══════════

class _Req:
    headers = {"x-jf-tab": "T1"}
    cookies = {}
    query_params = {}
    state = types.SimpleNamespace(user=_User())
    client = types.SimpleNamespace(host="1.1.1.1")


def _wire_claim_env(monkeypatch, bus):
    _enable_auth(monkeypatch, True)
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease", True, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease_ttl_s", 40.0, raising=False)

    async def _canon(r):
        # 模拟短号归一:654 → 2066666(claim 端点先 canon 再抢/播,广播必须带归一号)
        return ("2066666" if str(r) == "654" else str(r)), True
    monkeypatch.setattr(web.ST, "star", types.SimpleNamespace(canon=_canon), raising=False)


@pytest.mark.asyncio
async def test_claim_endpoint_broadcasts_canon_room(monkeypatch):
    """抢占成功 → 恰好广播一次,且房号是 **canon 归一号**(前端 followTarget 依赖)。"""
    bus = _bus()
    _wire_claim_env(monkeypatch, bus)
    calls = []
    _real = bus.publish_lease_switch

    async def _spy(uid, room):
        calls.append((int(uid), str(room)))
        await _real(uid, room)                      # 仍走真实发布(wire 由上一用例钉)
    monkeypatch.setattr(bus, "publish_lease_switch", _spy)

    r = await web.active_room_claim_ep(_Req(), roomId="654", tab="T1")
    body = json.loads(r.body)
    assert body["ok"] is True and body["room"] == "2066666"
    assert calls == [(UID, "2066666")]
    assert await bus.r.hget("alr:u7", "room") == "2066666"


@pytest.mark.asyncio
async def test_claim_endpoint_no_broadcast_when_roster_denied(monkeypatch):
    """roster 闸拒绝(claim fail-open 不抢占、回 room:"")→ **不广播**:
    没有发生切换,广播会让别的窗口白做一次 renew,还可能被误读成状态变更。"""
    bus = _bus()
    _wire_claim_env(monkeypatch, bus)

    async def _deny(request, room, rid):
        from fastapi.responses import JSONResponse
        return JSONResponse({"ok": False}, status_code=403)
    monkeypatch.setattr(web, "_user_room_deny", _deny)

    calls = []

    async def _spy(uid, room):
        calls.append((uid, room))
    monkeypatch.setattr(bus, "publish_lease_switch", _spy)

    r = await web.active_room_claim_ep(_Req(), roomId="654", tab="T1")
    body = json.loads(r.body)
    assert body["ok"] is True and body["room"] == ""
    assert calls == []
    assert await bus.r.hgetall("alr:u7") == {}      # 确实没抢占


# ═══════════ 一、广播:SSE 端到端亚秒跟随 ═══════════

@pytest.mark.asyncio
async def test_sse_follows_within_seconds_after_broadcast(monkeypatch):
    """端到端(真实 events() 生成器,非复刻):窗口 A 建流看 321(connected 秒回);
    "另一窗口" claim 654 + 广播 → A 的下一个事件是 follow(room=654) 且**秒级到达**
    (asyncio.wait_for 3s 硬顶 —— 若退化回 20s 心跳节拍,本用例必然超时红)。
    随后生成器收流(StopAsyncIteration),finally 的条件释放不炸。"""
    bus = _bus()
    _enable_auth(monkeypatch, True)
    # events() 里 `_sse_tok` 分支要碰 userauth.UA.cfg.cookie_name —— 给足形状;
    # validate 仅心跳节拍才会用到(本用例 3s 内收流,永远走不到),给个安全桩。
    async def _validate(tok):
        return "ok", None, {}
    monkeypatch.setattr(web, "userauth", types.SimpleNamespace(
        enabled=lambda: True,
        UA=types.SimpleNamespace(cfg=types.SimpleNamespace(cookie_name="jf_s")),
        validate=_validate))
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.ST, "db", types.SimpleNamespace(), raising=False)  # roster 闸 fail-open
    monkeypatch.setattr(web.settings.userauth, "active_room_lease", True, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease_ttl_s", 40.0, raising=False)

    async def _canon(r):
        return str(r), True
    monkeypatch.setattr(web.ST, "star", types.SimpleNamespace(canon=_canon), raising=False)

    async def _noop(*a, **k):
        return None
    monkeypatch.setattr(web, "_touch_room", _noop)

    class _SseReq:
        headers = {}
        cookies = {}
        query_params = {"tab": "W1"}
        state = types.SimpleNamespace(user=_User())
        client = types.SimpleNamespace(host="1.1.1.1")

    resp = await web.events(_SseReq(), roomId="321")
    it = resp.body_iterator                       # sse_starlette:content 原样存放
    ev1 = await asyncio.wait_for(it.__anext__(), timeout=3)
    assert getattr(ev1, "event", "") == "connected"
    assert await bus.r.hget("alr:u7", "room") == "321"   # 建流已 renew 授予

    task = asyncio.create_task(it.__anext__())    # 让 gen 前进到订阅 + 主循环
    await asyncio.sleep(0.3)
    # 必须用**真实时钟** claim:SSE 分支收到广播后做的是真实 now 的权威 renew,
    # 若此处用测试常量 NOW(2023)当 ts,租约会被判「整把过期」→ renew 重新授予本房
    # → 正确地**不**跟随(这正是防陈旧广播的设计;首版测试踩中,留此注释钉住教训)。
    ok, held = await bus.active_room_acquire(UID, "654", "C",
                                             int(time.time() * 1000), TTL_MS, claim=True)
    assert (ok, held) == (True, "654")
    await bus.publish_lease_switch(UID, "654")
    if not task.done():                           # 防极端调度竞态:再补一枪(重复无害)
        await asyncio.sleep(0.5)
        if not task.done():
            await bus.publish_lease_switch(UID, "654")
    ev2 = await asyncio.wait_for(task, timeout=3)
    assert getattr(ev2, "event", "") == "follow"
    assert json.loads(getattr(ev2, "data", "{}"))["room"] == "654"
    with pytest.raises(StopAsyncIteration):       # follow 后收流(前端将换房重建 SSE)
        await asyncio.wait_for(it.__anext__(), timeout=3)


@pytest.mark.asyncio
async def test_sse_ignores_stale_broadcast_for_own_room(monkeypatch):
    """广播只是触发器:若事件到达时活跃房仍是本房(如对端又切了回来 / 自家窗口的
    claim),权威 renew 返回"仍在本房" → **不 follow、不收流**,继续正常心跳供数。"""
    bus = _bus()
    _enable_auth(monkeypatch, True)

    async def _validate(tok):
        return "ok", None, {}
    monkeypatch.setattr(web, "userauth", types.SimpleNamespace(
        enabled=lambda: True,
        UA=types.SimpleNamespace(cfg=types.SimpleNamespace(cookie_name="jf_s")),
        validate=_validate))
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.ST, "db", types.SimpleNamespace(), raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease", True, raising=False)
    monkeypatch.setattr(web.settings.userauth, "active_room_lease_ttl_s", 40.0, raising=False)

    async def _canon(r):
        return str(r), True
    monkeypatch.setattr(web.ST, "star", types.SimpleNamespace(canon=_canon), raising=False)

    async def _noop(*a, **k):
        return None
    monkeypatch.setattr(web, "_touch_room", _noop)

    class _SseReq:
        headers = {}
        cookies = {}
        query_params = {"tab": "W1"}
        state = types.SimpleNamespace(user=_User())
        client = types.SimpleNamespace(host="1.1.1.1")

    resp = await web.events(_SseReq(), roomId="321")
    it = resp.body_iterator
    ev1 = await asyncio.wait_for(it.__anext__(), timeout=3)
    assert getattr(ev1, "event", "") == "connected"

    task = asyncio.create_task(it.__anext__())
    await asyncio.sleep(0.3)
    await bus.publish_lease_switch(UID, "321")    # 陈旧/同房广播:renew 命中本房
    # 不应因此收流:给 1.2s 观察窗,task 仍应挂起等待(下一个真实事件/心跳)
    await asyncio.sleep(1.2)
    assert not task.done(), "同房广播不得触发 follow/收流"
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await task                                 # 收尾:取消挂起的迭代
    with contextlib.suppress(BaseException):       # 触发 gen finally(reader 收摊/条件释放)
        await asyncio.wait_for(it.aclose(), timeout=3)


# ═══════════ 二、管理台可见性:总线层 ═══════════

@pytest.mark.asyncio
async def test_active_room_leases_scan_and_force_release():
    bus = _bus()
    await bus.active_room_acquire(7, "321", "A", NOW, TTL_MS)
    await bus.active_room_acquire(7, "321", "B", NOW + 5, TTL_MS)       # 同房第二页
    await bus.active_room_acquire(8, "654", "X", NOW + 9, TTL_MS)
    await bus.r.hset("alr:uX", mapping={"room": "999", "ts": NOW})      # 非法键面:跳过
    rows = await bus.active_room_leases()
    assert [r["uid"] for r in rows] == [8, 7]                           # ts 新→旧
    by = {r["uid"]: r for r in rows}
    assert by[7]["room"] == "321" and by[7]["tabs"] == 2
    assert by[8]["room"] == "654" and by[8]["tabs"] == 1
    assert await bus.active_room_lease_force_release(7) is True
    assert await bus.r.hgetall("alr:u7") == {}
    assert await bus.active_room_lease_force_release(7) is False        # 幂等:二次 False
    assert [r["uid"] for r in await bus.active_room_leases()] == [8]


# ═══════════ 二、管理台可见性:HTTP 端点(真会话真 CSRF) ═══════════

@pytest.mark.asyncio
async def test_admin_leases_endpoints(monkeypatch, tmp_path):
    import httpx
    from fastapi import FastAPI
    from app import admin_api
    from app import admin_auth as aa
    import app.userauth as ua

    monkeypatch.setenv("STA_ADMIN_PASSWORD", "pw-lease")
    monkeypatch.delenv("STA_ADMIN_IP_ALLOW", raising=False)
    aa._reset_for_tests()
    # 复审加固:init 会永久替换 admin_api 模块级 _ST/_HOOKS —— 本用例是全库唯一
    # 调用者,固定序下无后继消费者只是侥幸;随机序/未来新增 admin 测试都可能吃到
    # 本桩。保存/恢复,不赌调用图(与 conftest 还原 now_ms 同一纪律)。
    _prev_st, _prev_hooks = admin_api._ST, dict(admin_api._HOOKS)
    try:
        bus = _bus()
        _fresh = int(time.time() * 1000)          # stale 判定用真实 now_ms:必须真实时钟
        await bus.active_room_acquire(7, "2066666", "A", _fresh, TTL_MS)
        await bus.active_room_acquire(9, "321", "Z", NOW, TTL_MS)   # 2023 旧戳 → 必 stale
        admin_api.init(types.SimpleNamespace(bus=bus, db=types.SimpleNamespace()), {})
        monkeypatch.setattr(ua, "enabled", lambda: True)

        async def _names(uids):
            return {7: "张三"}
        monkeypatch.setattr(ua, "user_names", _names)
        monkeypatch.setattr(web.settings.userauth, "active_room_lease_ttl_s", 40.0,
                            raising=False)

        app = FastAPI()
        app.include_router(admin_api.router, prefix="/api/admin")   # 5.3.0:前缀在挂载时给
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),
                                     base_url="http://t") as c:
            j = (await c.post("/api/admin/login", json={"password": "pw-lease"})).json()
            hdr = {"X-Admin-Session": j["token"], "X-Admin-CSRF": j["csrf"]}
            d = (await c.get("/api/admin/leases", headers=hdr)).json()
            assert d["ok"] and d["enabled"] and d["count"] == 2
            by = {r["uid"]: r for r in d["leases"]}
            assert by[7]["room"] == "2066666" and by[7]["uname"] == "张三"
            assert by[7]["tabs"] == 1 and by[7]["stale"] is False
            assert by[9]["stale"] is True                    # 2023 旧戳:超 TTL 待剪
            # 无 CSRF 的写被拒(守卫来自 _guard_write,不是本端点自造)
            r403 = await c.post("/api/admin/leases/7/release",
                                headers={"X-Admin-Session": j["token"]})
            assert r403.status_code == 403
            r = (await c.post("/api/admin/leases/7/release", headers=hdr)).json()
            assert r["ok"] and r["freed"] is True
            d2 = (await c.get("/api/admin/leases", headers=hdr)).json()
            assert d2["count"] == 1 and d2["leases"][0]["uid"] == 9
            r2 = (await c.post("/api/admin/leases/7/release", headers=hdr)).json()
            assert r2["freed"] is False                      # 幂等
    finally:
        admin_api.init(_prev_st, _prev_hooks)   # 还原模块级注入,消除跨用例污染面
        aa._reset_for_tests()
