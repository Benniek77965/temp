"""
test_jfvip_contract.py — 九法VIP 前后端契约(4.2.0)
================================================================================
钉死「后端声明」与「前端消费」的一致性。这类漂移在运行期表现为**沉默的错误**:
界面说能用、点下去 403;或界面显示 30 局、后端其实钳的是别的数。
故一律用静态断言在 CI 期拦下(与既有 test_frontend_backend_limits.py 同款)。
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from tests._srcscan import css_code, js_code, py_code

from app import userauth, web
from app.settings import UserAuthCfg

ROOT = Path(__file__).resolve().parent.parent.parent   # maxxiang/
APP = Path(__file__).resolve().parent.parent / "app"
APPJS = ROOT / "assets" / "app.js"
INDEX = ROOT / "index.html"


def test_matrix_needs_are_valid():
    """能力矩阵的 need 只能是 basic/vip —— 拼错会让 _vip_guard 静默放行。"""
    for r in web.VIP_MATRIX:
        assert r["need"] in ("basic", "vip"), f"{r['key']}: need={r['need']!r} 非法"
        for k in ("key", "label", "basic", "vip"):
            assert k in r, f"{r.get('key')}: 缺字段 {k}"


def test_matrix_covers_vip_only_features():
    """三项 VIP 专属能力必须在矩阵里出现 —— 否则对比表会漏掉卖点。"""
    needs = {r["key"]: r["need"] for r in web.VIP_MATRIX}
    for k in ("pred", "replay", "wide"):
        assert needs.get(k) == "vip", f"{k} 应标记为 VIP 专属"
    for k in ("game", "roster"):
        assert needs.get(k) == "basic", f"{k} 应对 basic 档开放(需求明示)"


def test_matrix_has_single_unambiguous_prediction_row():
    """★ 真机反馈:原先「灵机推演」在对比表里占**两行**(一行命中率 ✓✓、
    一行下一局 🔒✓),用户分不清到底锁的是什么。合并为一行后语义唯一。"""
    rows = [r for r in web.VIP_MATRIX if "灵机推演" in r["label"]]
    assert len(rows) == 1, f"灵机推演应恰占一行,实得 {len(rows)}:{[r['label'] for r in rows]}"
    assert rows[0]["need"] == "vip", "唯一那行必须是 VIP 专属(锁的就是下一局的号)"


def test_matrix_copy_avoids_ambiguous_shorthand():
    """★ 真机反馈:「主2防2」是自创简写,小白会读成「推荐数字 2」。
    必须用项目**原生**说法「主 2 码 / 防 2 码」——`码` 字消除歧义,
    且与 index.html 推演卡 VIP 锁态条(#predVipBar:「主 2 码 · 防 2 码」)一致。
    注:4.3.7 前该措辞另有一份在 #predictCard 的整卡 title 里,该轮已随
    「免责声明改常驻角标」一并移除,锁态条是现存的唯一同源出处。"""
    blob = " ".join(f"{r['label']} {r['basic']} {r['vip']}" for r in web.VIP_MATRIX)
    assert "主2防2" not in blob, "对比表仍在用会被误读的简写"
    assert "码" in blob, "未采用项目原生的「码」表述"
    # 能力名必须体现「参考」性质 —— 付费页最不该给人"买了就有准号"的错觉,
    # 且项目自己一直写「预测仅供参考」。具体给什么由 vip 列的「主 2 码 + 防 2 码」承担。
    pred = next(r for r in web.VIP_MATRIX if r["key"] == "pred")
    assert "参考" in pred["label"], f"推演能力名未体现参考性质:{pred['label']}"
    assert "预测" in pred["label"], "应沿用项目自己的词「预测」(预测引擎/集成预测/预测仅供参考)"
    assert "码" in pred["vip"], f"VIP 列未说明具体给什么:{pred['vip']}"


def test_purchase_page_states_expectation():
    """★ 付费页必须写明「仅供参考、不保证命中」—— 掏钱那一步的期望管理。
    沿用项目既有口径(推演卡角标 .predict-ref 与命中率 tooltip 都写「仅供参考」;
    4.3.7 前角标那份在整卡 title 里,改为常驻是因为触屏没有 hover)。"""
    idx = (APP.parent.parent / "index.html").read_text(encoding="utf-8")
    assert "vip-disclaim" in idx, "付费页缺期望说明"
    i = idx.index("vip-disclaim")
    seg = idx[i:i + 200]
    assert "仅供参考" in seg and "不保证命中" in seg, seg[:120]


def test_default_plans_align_with_xiaodingdang_card_types():
    """档位默认时长必须对齐小叮当既有卡类型(运营已拍板):
       月卡 744h / 季卡 2232h;3 天档无对应卡类型,取自然 72h。
       改这里等于改钱 —— 必须有测试盯着。"""
    plans = {p["code"]: p for p in json.loads(UserAuthCfg().jf_vip_plans)}
    assert set(plans) == {"d3", "m1", "m3"}
    assert plans["d3"]["jfHours"] == 72 and plans["d3"]["ddHours"] == 72
    assert plans["m1"]["jfHours"] == 744 and plans["m1"]["ddHours"] == 744
    assert plans["m3"]["jfHours"] == 2232 and plans["m3"]["ddHours"] == 2232
    assert (plans["d3"]["price"], plans["m1"]["price"], plans["m3"]["price"]) \
        == (18, 88, 188)


def test_gateway_type_is_tulong_not_proxy():
    """网关口径必须是 tulong。误用繁星的 proxy 会让两个系统的账目在网关侧混流 ——
    这是**资损级**配置错误,值得一条独立的钉子。"""
    c = UserAuthCfg()
    assert c.jf_pay_type == "tulong"
    assert c.jf_pay_type != "proxy"


def test_pay_simulate_off_by_default():
    """模拟支付开关默认必须关 —— 开着等于任何登录用户都能凭空给自己开 VIP。"""
    assert UserAuthCfg().jf_pay_simulate is False


def test_vip_disabled_by_default():
    """总开关默认关 —— 「不配置即不存在」,旧部署升级后行为零变化。"""
    assert UserAuthCfg().jf_vip_enabled is False


def test_frontend_default_tier_is_vip():
    """前端 tier 默认 'vip'(全功能)—— 旧后端/未启用时逐字节维持 4.1.2 行为。
    若默认写成 'free',升级瞬间所有用户都会被挡在开通页外,是灾难性回归。"""
    src = js_code(APPJS)
    m = re.search(r"const JF = \{[^}]*tier:\s*'([a-z]+)'", src, re.S)
    assert m, "app.js 未找到 JF 状态初始化"
    assert m.group(1) == "vip", f"前端默认 tier 应为 'vip',实为 {m.group(1)!r}"


def test_frontend_snapshot_gated_by_window():
    """4.4.0:快照不再按「是不是 basic」一刀切,而是按**后端下发的在线累计窗**。

    4.2.0 的原钉是「basic 档必须短路快照」——那条纪律的**目的**从来不是
    「basic 不许留存」,而是「**掉档后的 VIP 满窗不许被 basic 回灌**」。
    4.4.0 允许 basic 留存他自己在线看到的局(服务端 history 的 limit/until 硬闸
    逐字节未动),于是本钉改指真正的不变量,而不是拔掉:

      ① 两个函数都必须过 snapOn()(窗=0 时行为与 4.2.0 逐字节相同);
      ② hydrateSnapshot 必须校验快照的 **tier 戳** —— 这是唯一真实的绕过向量;
      ③ pruneAllSnaps 仍须存在(档位变化时清场,第二道)。
    """
    src = js_code(APPJS)
    save = re.search(r"function saveSnapshot\(\)\{(.*?)\n\}", src, re.S)
    hyd = re.search(r"function hydrateSnapshot\(alias\)\{(.*?)\n\}", src, re.S)
    assert save and "snapOn()" in save.group(1), "saveSnapshot 缺在线累计窗闸"
    assert hyd and "snapOn()" in hyd.group(1), "hydrateSnapshot 缺在线累计窗闸"
    assert hyd and "snap.tier" in hyd.group(1), \
        "hydrateSnapshot 缺 tier 戳校验(掉档后 VIP 满窗会被 basic 回灌)"
    assert "function pruneAllSnaps" in src, "缺档位变化清快照(第二道)"


def test_frontend_online_window_defaults_off():
    """前端 JF.onlineH 默认必须是 0 —— 旧后端不下发 basicOnlineH 时,前端不得
    擅自替后端放开限制。默认值的方向必须偏保守(与 tier 默认 'vip' 是同一条
    原则的**反向**应用:那里保守=全给,这里保守=不给)。"""
    src = js_code(APPJS)
    m = re.search(r"const JF = \{.*?onlineH:\s*(\d+)", src, re.S)
    assert m, "app.js 未找到 JF.onlineH 初始化"
    assert m.group(1) == "0", f"JF.onlineH 默认应为 0,实为 {m.group(1)}"
    assert re.search(r"JF\.onlineH\s*=\s*Math\.max\(0,\s*Number\(jf\.basicOnlineH\)\s*\|\|\s*0\)", src), \
        "basicOnlineH 落地缺 `|| 0` 保守缺省"


def test_streaks_and_gap_stats_stop_at_discontinuity():
    """4.4.0 复审自查钉:凡「连续性断言」都不许跨断口。

    本项目有两处在数**连续**的东西:deriveStats 的连空 / renderStreaks 的连开。
    4.4.0 首轮只改了前者,复审时发现后者是**同类失真且更严重** —— 「连开 × 5」
    宣称刚刚接连开出,而其中两颗之间可能隔着十几局没观测过的出怪(真机构造实测:
    旧口径报 5,实际连续观测只有 2)。两处都必须以格点距离判断断口并停住。
    本钉防的是「以后新增第三处连续性统计时又忘了断口」。"""
    src = js_code(APPJS)
    for fn in ("deriveStats", "renderStreaks"):
        m = re.search(rf"function {fn}\(\)\{{(.*?)\n\}}", src, re.S)
        assert m, f"未找到 {fn}"
        body = m.group(1)
        assert "T.ROUND" in body, f"{fn} 未按格点距离判断断口(仍在数记录条数?)"


def test_hydrated_history_survives_loadroom():
    """五轮复审钉(最严重的一条):回灌的历史必须**活过 loadRoom**。

    applyRoomData 是「换房重锤」,整体替换 S.hist。basic 档 history 只回 N 局,
    若不把回灌的历史并回来,满窗会在一个 RTT 后被整段冲掉,紧接着 saveSnapshot()
    还会用这 N 局覆盖本机快照 —— 特性不生效且自毁(实测:6 局 → 2 局,
    磁盘 '111111' → '11')。前四轮复审没抓到,因为整机断言在 hydrate 那一刻取证。
    """
    src = js_code(APPJS)
    hyd = re.search(r"function hydrateSnapshot\(alias\)\{(.*?)\n\}", src, re.S)
    assert hyd and "snapSeed" in hyd.group(1), "hydrateSnapshot 未留种子供 loadRoom 并回"
    lr = re.search(r"async function loadRoom\(alias,.*?\n\}", src, re.S)
    assert lr, "未找到 loadRoom"
    body = lr.group(0)
    i_seed, i_save = body.find("S.snapSeed"), body.find("saveSnapshot()")
    assert i_seed >= 0, "loadRoom 未并回回灌种子"
    assert i_save >= 0 and i_seed < i_save, \
        "并回必须在 saveSnapshot 之前 —— 否则先用少量新局覆盖了本机快照"


def test_snapshot_write_is_monotonic():
    """落盘必须单调不减:多标签页下覆盖式写盘会让陈旧页抹掉另一页积累的满窗。"""
    src = js_code(APPJS)
    assert "function mergeEnc" in src and "function clampEnc" in src, "缺并集/裁窗函数"
    save = re.search(r"function saveSnapshot\(\)\{(.*?)\n\}", src, re.S)
    assert save and "mergeEnc" in save.group(1), "saveSnapshot 未与盘上已有取并集"


def test_snapshot_cycle_fuzz_has_two_models():
    """七轮复审钉:落盘**闭环**对拍必须存在,且必须有**两个模型**。

    只有单页模型是不够的 —— 单页流程里 S.hist 已含回灌种子,`mergeEnc` 是冗余的,
    把它退化成覆盖式,单页模型照样全绿(实测)。必须再有一个双页模型
    (A 长期在线 / B 中途开后被冻结 / B 关闭时落盘)才测得出并集的作用。
    一个测不出组件缺失的测试,不算覆盖了那个组件。
    """
    f = ROOT / "backend_async" / "scripts" / "frontend_snapshot_cycle_fuzz.js"
    assert f.is_file(), "落盘闭环对拍脚本缺失"
    src = f.read_text(encoding="utf-8")
    assert "双页" in src and "单页" in src, "闭环对拍缺少两个模型之一"
    # 双页模型的判据是「A 在窗内的观测被 B 抹掉」—— 这句在,模型才真的在
    assert "被 B 抹掉" in src, "双页模型缺少并集失效的判据(mergeEnc 将无人验证)"
    for inv in ("无中生有", "窗内丢失", "越界"):
        assert inv in src, f"闭环对拍缺不变量:{inv}"


def test_gapstats_fuzz_harness_parses_rendered_text():
    """四轮复审钉:连空对拍脚本必须存在,且判据必须**从渲染文本反解**。

    初版判据读的是 st.gapOpen / st.gapMin 这些内部标志位 —— 做反向自检(故意打坏
    gapText)时脚本照样全绿:它验的是数据,而用户看的是渲染。一个打不红的测试等于
    没有测试。本钉防的就是有人把判据改回读标志位。
    """
    f = ROOT / "backend_async" / "scripts" / "frontend_gapstats_fuzz.js"
    assert f.is_file(), "连空对拍脚本缺失"
    src = f.read_text(encoding="utf-8")
    assert "exec(txt)" in src, "对拍判据未从渲染文本(txt)反解"
    # 判据区一旦按下标读内部标志位,就说明又退回「验数据不验渲染」的老路。
    # 只认代码形态 `st.gapOpen[` —— 注释里复述这段历史是允许的(且应当保留)。
    assert "st.gapOpen[" not in src, "对拍判据疑似又读回内部标志位(st.gapOpen[…])"
    assert "form = 'open'" in src and "form = 'range'" in src and "form = 'exact'" in src, \
        "对拍未覆盖三种展示形态"


def test_gap_display_has_three_forms():
    """连空展示必须保有三形态。少一种就意味着某类不确定性被当成确定的摆出去:
    缺 `≥` → 从未出现的号位被显示成精确值;缺 `~` → 跨断口的不确定被抹平。"""
    src = js_code(APPJS)
    m = re.search(r"function gapText\(st, n\)\{(.*?)\n\}", src, re.S)
    assert m, "未找到 gapText"
    body = m.group(1)
    assert "≥" in body, "缺开区间形态(窗内从未出现 → 上不封顶)"
    assert "~" in body, "缺区间形态(跨断口 → 真值只知落在区间内)"


def test_all_bead_renderers_compute_gaps():
    """4.4.0 三轮复审钉:凡把 S.hist 画成一串珠的地方,都必须算断口。

    首轮只改了主序列;二轮复审补了 renderStreaks;三轮复审又查出**两处遗漏** ——
    `renderWideDay`(按日回看)与 `rgRoadHtml`(真实游戏面板战况)仍在裸画,
    把不连续的一段画成连续的。三次都是同一个疏漏模式:改了一处,忘了同源的其它处。

    本钉遍历全部画珠函数,要求它们要么走 beadsHtml(内建断口计算),要么自己
    出现 T.ROUND(自算格点距离)。新增第四处画珠路径而不算断口 → 本用例失败。
    """
    src = js_code(APPJS)
    for fn in ("renderRoad", "renderWideDay", "rgRoadHtml", "tryAppendRoad"):
        m = re.search(rf"function {fn}\([^)]*\)\{{(.*?)\n\}}", src, re.S)
        assert m, f"未找到画珠函数 {fn}"
        body = m.group(1)
        assert ("beadsHtml" in body) or ("T.ROUND" in body), \
            f"{fn} 既不走 beadsHtml 也不自算格点距离 —— 断口会被抹平"


def test_snapshot_encode_refuses_partial_write():
    """encodeHist 遇到落不到格点上的局必须**整份放弃**,不许静默丢局 ——
    存一份缺了一半的快照,回灌时用户会看到一个假的「断口密布」序列,
    而他根本没离线过。这比不存严重得多。"""
    src = js_code(APPJS)
    m = re.search(r"function encodeHist\(hist\)\{(.*?)\n\}", src, re.S)
    assert m, "未找到 encodeHist"
    assert "return null" in m.group(1), "encodeHist 缺「对不齐即整份放弃」的出口"


def test_hydrate_clamps_by_current_window():
    """回灌必须按**当前**窗口再钳一次内容 —— 窗口是热更项,
    存的时候是 24h 的旧快照若整份放行,等于运维调窗没落地。"""
    src = js_code(APPJS)
    m = re.search(r"function hydrateSnapshot\(alias\)\{(.*?)\n\}", src, re.S)
    assert m and "snapWindowH()" in m.group(1), "hydrateSnapshot 缺按当前窗口钳内容"
    assert "filter" in m.group(1), "hydrateSnapshot 未对回灌内容做窗口过滤"


def test_backend_matrix_copy_follows_live_config():
    """能力矩阵的 road 行文案必须随生效配置渲染 —— jf_basic_online_h 是热更项,
    写死会在运维调窗/关窗后让对比表撒谎,而该表的立身之本正是「永不出现
    界面说能用、实际不能用」。"""
    from app import web  # noqa: PLC0415
    from app.settings import settings as _s  # noqa: PLC0415
    old = _s.userauth.jf_basic_online_h
    try:
        _s.userauth.jf_basic_online_h = 0
        row = next(r for r in web.vip_matrix() if r["key"] == "road")
        assert "局起累计" in row["basic"], row["basic"]
        _s.userauth.jf_basic_online_h = 6
        row = next(r for r in web.vip_matrix() if r["key"] == "road")
        assert "6 小时" in row["basic"] and "在线累计" in row["basic"], row["basic"]
        # 必须是深拷贝:绝不能把模块级常量改脏
        assert next(r for r in web.VIP_MATRIX if r["key"] == "road")["basic"] \
            == "本次 30 局起累计"
    finally:
        _s.userauth.jf_basic_online_h = old


def test_frontend_free_tier_sends_no_data_request():
    """free 档必须在 dataBoot 最开头 return —— 一个数据请求都不发。"""
    src = js_code(APPJS)
    m = re.search(r"async function dataBoot\(\)\{(.*?)\n\}", src, re.S)
    assert m, "未找到 dataBoot"
    head = m.group(1)[:600]
    assert "isFree()" in head and "showVipGate('free')" in head, \
        "dataBoot 开头缺 free 档短路"
    # 短路必须在第一次 api( 调用之前
    i_free, i_api = head.find("isFree()"), m.group(1).find("api(")
    assert i_api < 0 or i_free < i_api, "free 档短路应先于任何 api() 调用"


def test_frontend_ids_exist_in_html():
    """app.js 缓存的 VIP DOM id 必须在 index.html 里真实存在。"""
    js = js_code(APPJS)
    html = INDEX.read_text(encoding="utf-8")
    # 锚点必须落在**代码**上:注释已被 js_code 剥掉,拿注释当锚必然失配。
    m = re.search(r"'ucVip'\s*,(.*?)\];", js, re.S)
    assert m, "app.js 未找到 4.2.0 DOM id 清单(锚点 'ucVip')"
    ids = ["ucVip"] + re.findall(r"'([A-Za-z][A-Za-z0-9]*)'", m.group(1))
    missing = [i for i in ids if f'id="{i}"' not in html]
    assert not missing, f"index.html 缺少这些元素:{missing}"


def test_backend_history_clamp_uses_config():
    """history 的钳制必须读配置项,不能硬编码 30 —— 否则管理台热更不生效。"""
    src = py_code(APP / "web.py")
    assert "jf_basic_history_limit" in src, "history 钳制未读配置"
    assert "jf_basic_pred_window" in src, "prediction 窗口未读配置"


def test_vip_endpoints_not_behind_vip_guard():
    """/api/vip/* 绝不能接 _vip_guard —— free 档必须能下单,那是他唯一的出口。
    接了就是死锁:没 VIP 不能买,买了才有 VIP。"""
    src = py_code(APP / "web.py")
    i = src.index('@app.get("/api/vip/state")')      # 锚定代码,不锚注释
    j = src.index('@app.get("/api/version")')
    seg = src[i:j]        # py_code 已剥注释
    assert "_vip_guard" not in seg, "/api/vip/* 段落里出现了 _vip_guard —— 会造成购买死锁"


def test_gen_cards_is_batched_not_n_plus_one():
    """★ 发卡必须批量。用户库**在公网**(项目自述 RTT 数十毫秒级),
    初版每张卡一次 SELECT + 一次 INSERT —— 500 张 = 1000 次往返 ≈ 50 秒,
    管理台请求会直接超时。现要求稳态 ≤3 个往返点(查重 + 落库 + 余量)。

    4.2.9:批量实现已收敛进 `_gen_cards_code`(按配置档位发卡与按指定时长发卡
    共用同一条落库路径),锚点随之下移。**同时加强**:断言两个对外入口都只是
    向它分派 —— 否则将来任一条发卡路径私自复制一份实现出来、再悄悄退回 N+1,
    只钉住其中一个函数是钉不住的。
    """
    import ast
    src = py_code(APP / "jfvip.py")
    tree = ast.parse(src)
    fns = {n.name: n for n in ast.walk(tree)
           if isinstance(n, ast.AsyncFunctionDef)}
    core = fns.get("_gen_cards_code")
    assert core is not None, "_gen_cards_code 丢失或改名 —— 批量发卡的锚点没了"
    body = ast.get_source_segment(src, core) or ""
    assert body.count("await userauth._q") <= 3, (
        f"_gen_cards_code 有 {body.count('await userauth._q')} 个往返点 —— 疑似退回 N+1")
    assert "IN (" in body, "查重未用批量 IN(...)"
    assert "VALUES {vals}" in body or "vals" in body, "落库未用多值 INSERT"

    # 两个对外入口:自身零往返(只做参数解析),且必须委托给同一个核心。
    for name in ("gen_cards", "gen_cards_hours", "gen_cards_by_code"):
        fn = fns.get(name)
        assert fn is not None, f"{name} 丢失 —— 发卡入口不该消失"
        seg = ast.get_source_segment(src, fn) or ""
        assert "_gen_cards_code" in seg, (
            f"{name} 未委托给 _gen_cards_code —— 两条发卡路径一旦各写一份实现,"
            f"查重逻辑或 INSERT 列迟早在某次维护里悄悄分家")
        assert "await userauth._q" not in seg, (
            f"{name} 里出现了直接的库往返 —— 落库应当只在 _gen_cards_code 里发生")


def test_jfpay_session_closed_on_shutdown():
    """aiohttp 会话必须在 lifespan 收尾释放,否则关停时泄漏 connector 并打警告。"""
    src = py_code(APP / "web.py")
    assert "await jfpay.close()" in src, "lifespan 未释放 jfpay 的 aiohttp 会话"


def test_vip_endpoints_distinguish_401_from_503():
    """未登录应回 401(前端据此拉登录门),而不是 503「本部署未启用」——
    初版一律回 503,用户一头雾水且前端无法正确分流。"""
    src = py_code(APP / "web.py")
    assert "_vip_deny" in src, "缺少区分未登录/未启用的错误分流"
    assert 'status_code=401' in src[src.index("def _vip_deny"):src.index("def _vip_deny") + 600]


def test_env_example_documents_jf_vars():
    """.env.example 必须记录 STA_JF_* —— 运维是照它抄的,漏了就没人知道怎么开。"""
    env = (APP.parent / "deploy" / ".env.example").read_text(encoding="utf-8")
    for k in ("STA_JF_VIP", "STA_JF_PAY_TYPE", "STA_JF_BASIC_HIST",
              "STA_JF_ORDER_RATE_HOURLY", "jfvip-preflight"):
        assert k in env, f".env.example 缺 {k}"


# ── 网关契约(真机联调实测锁定,2026-07 对 type=tulong)──────────────────────
def test_qr_mime_is_sniffed_not_hardcoded():
    """★ 真机联调实测:网关回的二维码是 **JPEG**(base64 前缀 `/9j/`,魔数 ff d8 ff),
    不是 PNG。前端若硬编码 `data:image/png;base64,` 就是错的 MIME ——
    浏览器多半会嗅探真实类型而容忍,但那是运气不是契约(严格 CSP / 个别内核会拒渲染)。
    必须按 base64 魔数判定。"""
    js = js_code(APPJS)
    assert "function qrDataUrl" in js, "缺少二维码 MIME 嗅探函数"
    assert "'/9j/'" in js and "image/jpeg" in js, "未识别 JPEG(网关实际返回的格式)"
    assert "iVBORw0KGgo" in js and "image/png" in js, "未识别 PNG(模拟模式占位图)"
    # 不得再有硬编码的 png 拼接
    assert "'data:image/png;base64,' +" not in js, "仍存在硬编码 png 拼接"


def test_gateway_amount_uses_response_price_only():
    """★ 真机联调实测:请求 price=18,网关返回 **17.99**(它按自家策略定价)。
    若按请求金额入账,用户付 17.99 我们记 18 —— 就是「凭空入账」漏洞。
    故订单 amount 必须**只**取网关响应的 price,且缺失/越界一律拒绝下单。"""
    src = py_code(APP / "jfpay.py")
    assert 'raw = resp.get("price")' in src, "未取网关响应的 price"
    assert "if raw is None:" in src, "price 缺失时未拒绝"
    # 绝不能出现「回退到请求金额」的写法
    assert "amount = float(plan[\"price\"])" not in src.split("if _simulate():")[-1].split("else:")[-1], \
        "正式模式疑似回退到档位价"


def test_order_no_is_deterministic_so_dup_path_is_hot():
    """★ 真机联调实测:同账号+同金额,网关返回**同一个 orderNo**(md5 形态,
    两次调用完全一致);不同账号则不同。⇒ 用户点两次充值就会撞本地 uk_order,
    1062 复用路径是**热路径**而非理论分支,必须存在且在行锁下判定。"""
    src = py_code(APP / "jfpay.py")
    assert "_reuse_after_dup" in src, "缺少 1062 复用路径"
    seg = src[src.index("async def _reuse_after_dup"):]
    assert "FOR UPDATE" in seg, "复用判定未在行锁下进行(会把并发已结算的订单翻回 pending)"


# ── 构建清单纪律(2026-07 真机部署事故的回归钉)────────────────────────────────
def test_package_manifest_has_no_test_only_deps():
    """★ 部署事故回归钉。

    背景(真机 deploy 日志实证):开发期为跑 jsdom 冒烟执行了 `npm i jsdom`,
    它**写进了 package.json**;打包时只删了 node_modules 与 package-lock.json,
    于是目标机 `npm ci` 撞上
        「package.json and package-lock.json are not in sync / Missing: jsdom」
    → **fe-build 阶段直接失败,整个镜像重建中断**。

    纪律:
      · package.json 只允许出现构建器真正需要的四个 devDependencies;
      · **不得有 dependencies 段**(本项目前端不打包运行时依赖);
      · jsdom 等测试工具一律 `npm i --no-save jsdom` 临时装(既有 jsdom 脚本
        的头注释本就是这么写的),绝不入清单。
    """
    import json
    root = APP.parent.parent
    pkg = json.loads((root / "package.json").read_text(encoding="utf-8"))
    assert "dependencies" not in pkg, (
        f"package.json 出现 dependencies 段:{pkg.get('dependencies')} —— "
        f"会让目标机 npm ci 与 lock 不同步而构建失败")
    dev = set((pkg.get("devDependencies") or {}).keys())
    assert dev == {"terser", "javascript-obfuscator", "html-minifier-terser", "csso"}, (
        f"devDependencies 被改动:{sorted(dev)} —— 构建器依赖是契约,"
        f"新增任何一项都必须同步 package-lock.json 并复测 fe-build")
    for bad in ("jsdom", "puppeteer", "playwright", "pytest"):
        assert bad not in dev, f"测试工具 {bad} 混进了构建清单"


def test_package_lock_exists_and_in_sync():
    """★ package-lock.json 必须存在且与 package.json 同步 ——
    Dockerfile 的 `COPY package.json package-lock.json ./` + `npm ci` 硬依赖它。
    本轮事故里它被误删,目标机拿到的是旧 lock,直接不同步。"""
    import json
    root = APP.parent.parent
    lock_path = root / "package-lock.json"
    assert lock_path.is_file(), "package-lock.json 缺失 —— Dockerfile COPY 会失败"
    lock = json.loads(lock_path.read_text(encoding="utf-8"))
    pkg = json.loads((root / "package.json").read_text(encoding="utf-8"))
    # lock 的根包记录必须与 package.json 的依赖声明一致(npm ci 的同步判据)
    root_entry = (lock.get("packages") or {}).get("", {})
    assert (root_entry.get("devDependencies") or {}) == (pkg.get("devDependencies") or {}), \
        "package-lock.json 的 devDependencies 与 package.json 不一致 —— npm ci 会拒绝"
    assert (root_entry.get("dependencies") or {}) == (pkg.get("dependencies") or {}), \
        "package-lock.json 的 dependencies 与 package.json 不一致 —— npm ci 会拒绝"


# ── 生效链路的可观测性(2026-07 真机「设了没反应」反馈的回归钉)──────────────
def test_frontend_cache_version_bumped():
    """★ 前端改了就必须 bump `?v=` —— 项目既有约定(见 LOGIN-SYSTEM.md §6.6:
    「index.html 已 bump ?v,新开页自动取新包」)。漏 bump 时,带缓存/经 CDN 或
    反代的客户端会继续跑旧包 —— 后端明明生效了,用户端却"毫无变化",
    而且**重启服务器也不会好**(那是浏览器/中间层的缓存)。"""
    root = APP.parent.parent
    idx = (root / "index.html").read_text(encoding="utf-8")
    adm = (root / "admin.html").read_text(encoding="utf-8")
    assert "app.js?v=4.1.2" not in idx and "app.css?v=4.1.2" not in idx, \
        "index.html 的 ?v 仍是 4.1.2(改了前端却没 bump,老客户端会一直跑旧包)"
    assert "admin.js?v=1.4.3" not in adm and "admin.css?v=1.4.3" not in adm, \
        "admin.html 的 ?v 仍是 1.4.3(「值」视图对老客户端不可见)"
    # 同一文件里 js 与 css 的版本必须一致,避免半新半旧
    import re
    for name, doc in (("index.html", idx), ("admin.html", adm)):
        vs = set(re.findall(r"\?v=([0-9.]+)", doc))
        assert len(vs) == 1, f"{name} 存在不一致的 ?v:{sorted(vs)}"


def test_status_reports_actionable_reason():
    """★ 「设了没反应」的根治:失效必须给出**可操作**的原因,而不是静默 False。"""
    from app import jfvip
    old = userauth.UA.cfg
    try:
        # 用元组列表而非 dict —— @dataclass 生成 __eq__ 会把 __hash__ 置 None,
        # UserAuthCfg 不可哈希,拿它当 dict 键会 TypeError。
        cases = [
            (None, "not_inited"),
            (UserAuthCfg(), "switch_off"),
            (UserAuthCfg(jf_vip_enabled=True), "login_off"),
            (UserAuthCfg(host="h", db="d", user="u", jf_vip_enabled=True), "ok"),
        ]
        for cfg, want in cases:
            userauth.UA.cfg = cfg
            st = jfvip.status()
            assert st["reason"] == want, f"{want} 场景实得 {st['reason']}"
            assert st["message"], "原因必须带可读说明"
        # login_off 的说明必须点破「设了也没用」,否则运维还是会反复试
        userauth.UA.cfg = UserAuthCfg(jf_vip_enabled=True)
        assert "不会有任何效果" in jfvip.status()["message"]
    finally:
        userauth.UA.cfg = old


def test_restart_level_param_warns_on_save():
    """★ 保存时就要提示「需重启」与「依赖登录系统」,而不是让运维重启完才发现没反应。"""
    from app import config_center as cc
    _, warns = cc.semantic_validate(
        {"userauth.jf_vip_enabled": True, "userauth.host": "",
         "userauth.db": "", "userauth.user": ""},
        {"userauth.jf_vip_enabled"})
    joined = " ".join(warns)
    assert "必须重启" in joined, "未提示重启级参数"
    assert "登录系统未配置" in joined, "未提示依赖登录系统"
    # 模拟支付也必须有生产警告
    _, w2 = cc.semantic_validate({"userauth.jf_pay_simulate": True},
                                 {"userauth.jf_pay_simulate"})
    assert any("生产环境必须关闭" in x for x in w2)


def test_startup_banner_exists():
    """★ 启动日志必须有 VIP 横幅 —— 运维排查「到底开没开」的第一落点。"""
    src = py_code(APP / "web.py")
    assert "jfvip.startup_report()" in src, "web 启动未打 VIP 横幅"
    j = py_code(APP / "jfvip.py")
    assert "def startup_report" in j
    assert "[九法VIP] 已启用" in j and "未生效" in j


def test_vip_user_has_renewal_entry():
    """★ 真机反馈:已开通 VIP 的用户**找不到续费入口**。

    成因:「开通」按钮的显示条件写成了 `tier !== 'vip'`,而 predVipBar 也只在
    basic 档出现 —— 于是已付费用户没有任何路径能打开付费页,想续费也没门。
    这是直接损失续费收入的功能缺口。

    纪律:按钮在 VIP 体系开启时**常驻**,只换文案(开通/续费);
    且付费页对已是 VIP 的用户必须以「续费」形态呈现 —— 对已付费用户说
    「开通」是错的。
    """
    js = js_code(APPJS)
    assert "!(JF.on && JF.tier !== 'vip')" not in js, \
        "续费入口仍对 VIP 用户隐藏 —— 已付费用户无法续费"
    assert "D.ucBuy.hidden = !JF.on" in js, "按钮未做成常驻"
    assert "'续费'" in js, "缺少续费文案"
    assert "showVipGate('renew')" in js or "mode = 'renew'" in js, "缺少续费形态"
    # 已是 VIP 时任何入口都要转成 renew
    assert "if (mode !== 'free' && JF.tier === 'vip') mode = 'renew'" in js, \
        "VIP 用户点开付费页仍可能显示「开通/升级」"


def test_renew_copy_states_rollover_truth():
    """★ 续费页必须讲明「从当前到期日顺延」—— 这不是营销话术,是 _grant_tx 的
    真实口径(GREATEST(NOW(), vip_until) + N 小时),提早续一天都不会亏。
    不说清楚,用户会为了不浪费而拖到最后一天,反而容易断档。"""
    js = js_code(APPJS)
    assert "顺延" in js, "续费页未说明顺延口径"
    grant = py_code(APP / "jfvip.py")
    assert "GREATEST(NOW(), vip_until)" in grant, "后端续期口径与前端文案不符"


def test_card_placeholder_has_no_format_noise():
    """卡密输入框不写格式细节 —— 用户多是复制粘贴,格式提示是噪音;
    真填错时由 card_shape_hint 给出**针对性**提示(那才是有用的时机)。"""
    idx = (APP.parent.parent / "index.html").read_text(encoding="utf-8")
    assert 'placeholder="请输入卡密"' in idx, "卡密 placeholder 未精简"
    assert "JF 开头 14 位" not in idx, "placeholder 仍残留格式噪音"
    # 但错误提示必须保留(那是可操作的)
    j = py_code(APP / "jfvip.py")
    assert "def card_shape_hint" in j and "不含数字 0 和 1" in j


def test_free_tier_is_not_a_dead_end():
    """★ 真机反馈:小叮当到期且无 VIP 的用户**登录后无法退出**。

    成因:free 档整个壳被 `pointer-events:none` 禁用(见 app.css
    `body[data-vip-gate="free"] .shell`),顶栏那个「退出」按钮点不到;
    而开通门内原先没有任何退出路径 —— 用错账号登进来的人被彻底锁死在本页,
    连换个有 VIP 的账号都做不到。

    纪律:free 档的门内**必须**有退出出口(upsell/续费态不需要,那两种可以
    关掉门用顶栏退出)。
    """
    idx = (APP.parent.parent / "index.html").read_text(encoding="utf-8")
    assert 'id="vipLogout"' in idx, "开通门内没有退出出口 —— free 档用户会被锁死"
    js = js_code(APPJS)
    assert "D.vipLogout.addEventListener('click', doLogout)" in js, "退出出口未绑定登出"
    assert "D.vipLogout.hidden = !free" in js, "退出出口的显隐未按 free 档 gate"
    css = css_code(APP.parent.parent / "assets" / "app.css")   # 必须剥注释,见 _srcscan
    assert ".vip-logout" in css, "退出出口无样式(会挤在弹层里看不见)"


def test_limit_badges_are_actionable():
    """★ 真机反馈:basic 档充值入口不够直观。

    原先三处面板角标是死 `<span>` —— 用户看到「VIP 看满 24 小时」却不知道
    从哪开通。改成可点按钮:**在哪看到限制就能在哪行动**,零新增 UI 面积,
    不加横幅、不弹窗(那才叫突兀)。
    """
    idx = (APP.parent.parent / "index.html").read_text(encoding="utf-8")
    assert idx.count('<button type="button" class="vip-note"') == 3, \
        "三处面板角标应全部可点"
    assert '<span class="vip-note"' not in idx, "仍有死文字角标"
    js = js_code(APPJS)
    assert "el.tagName === 'BUTTON'" in js and "showVipGate('upsell')" in js, \
        "角标未绑定到升级页"
    assert "el.dataset.bound" in js, "角标绑定缺幂等守卫(重复渲染会叠加监听)"


def test_decision_facts_are_above_the_fold():
    """★ 真机反馈:#vipFoot 不够直观。

    到期日 / 为什么看不到数据 —— 这些是用户**做决定要用**的事实,原先埋在
    页脚 11.5px 灰字里,那个位置用户不会看。现移到标题正下方的状态条。
    """
    idx = (APP.parent.parent / "index.html").read_text(encoding="utf-8")
    assert 'id="vipStatus"' in idx, "缺状态条"
    # 状态条必须在 lede 之后、档位卡之前(即"标题正下方",不是页脚)
    i_lede, i_status, i_plans = (idx.index('id="vipLede"'), idx.index('id="vipStatus"'),
                                 idx.index('id="vipPlans"'))
    assert i_lede < i_status < i_plans, "状态条位置不对(应在副标题与档位卡之间)"
    js = js_code(APPJS)
    assert "function renderVipStatus" in js
    # 续费态必须给出剩余天数与到期日;free 态必须说清"为什么看不到"
    seg = js[js.index("function renderVipStatus"):]
    seg = seg[:seg.index("\n}\n")]
    assert "到期" in seg and "剩 " in seg, "续费态未给出到期信息"
    assert "小叮当" in seg, "free 态未说明为什么看不到数据"


def test_admin_jfvip_view_uses_shared_error_text():
    """★【4.2.5 实测复现】「值」视图曾是全站唯一不走 errText() 的视图。

    api() 抛的是 `{status, data}` **纯对象**,没有 .message —— 而该视图 8 处
    catch 全写成 `String(e.message || e)`,于是 `String({...})` ⇒ 屏幕上
    **一律显示 `[object Object]`**:查无此用户、档位表配坏、接口 503、
    422 带着后端精心写的中文 hint……运维看到的全是同一句机器乱码。

    真 DOM 实测(jsdom,交付版 admin.html + assets/admin.js):
        HTTP 404 {"error":"user_not_found"}  → 「[object Object]」
        HTTP 503 {"error":"disabled"}        → 「[object Object]」
        HTTP 400 {"error":"bad_plan"}        → Toast「[object Object]」

    纪律:管理台任何视图的错误分支都必须走 errText(e, 回退文案) —— 它才认识
    e.data.message / e.data.hint / ERRTXT[e.data.error] 这三层。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    assert "e.message" not in seg, \
        "「值」视图仍在读 e.message —— api() 抛的对象没有该字段,必渲染成 [object Object]"
    assert seg.count("errText(") >= 8, \
        f"「值」视图 errText 调用仅 {seg.count('errText(')} 处,错误分支未全部接入共享文案管道"
    # 后端会回的错误码必须在 ERRTXT 里有中文对照,否则运维看到的是裸英文码
    for code in ("disabled", "bad_plan", "bad_hours", "collision",
                 "db", "user_not_found", "card_used", "card_plan_gone"):
        assert f"{code}:" in js, f"ERRTXT 缺 {code} 的中文文案"


def test_admin_ask_dialog_passes_placeholder_not_input_string():
    """★【4.2.5 实测复现】ask() 的 `input` 只作**布尔**用(`i.hidden = !o.input`),
    提示文案走的是 `o.placeholder`。而手动开通/撤销这两个最高危操作传的却是
    `input: '请输入操作原因(必填…)'` —— 该串**从未进入 DOM**,jsdom 实测
    placeholder 为空串:运维面对的是一个**无标签空白输入框**。

    同时钉住 maxlength:后端 `str(note)[:64]` 会静默截断,不设上限的话运维
    写满一段话、以为流水里留全了,实际只留前 64 字(审计侧却是全文,两边打架)。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    import re
    for m in re.finditer(r"input:\s*([^,\n]+)", seg):
        assert m.group(1).strip() == "true", \
            f"ask() 的 input 传了非布尔值 {m.group(1)!r} —— 该串不会显示,提示文案须走 placeholder"
    assert seg.count("placeholder: '操作原因") == 2, "两处高危弹窗未给出输入提示"
    assert seg.count("maxlength: 64") == 2, "操作原因未与后端 ref[:64] 对齐"


def test_jfvip_admin_list_endpoints_are_503_when_disabled():
    """★【4.2.5】关闭态下,列表类 GET 必须回 503,不能回 HTTP 200 + ok:false。

    原先 4 个 GET 回 200,而**同功能的 4 个 POST 回 503** —— 同一状态两种码。
    后果实测:前端 api() 因 r.ok 为真而不抛,把失败当成功渲染成
    「共 undefined 张 · 第 undefined 页」;健康探针/反代/日志同样把故障读成正常。

    ⚠ /jfvip/overview **刻意豁免**:前端要读它的 reason/message 渲染「未启用」
      的可操作指引页(4.2.1 的核心),改 503 会让那套诊断信息全部失效。
    """
    src = py_code(APP / "admin_api.py")
    seg = src[src.index('@router.get("/jfvip/overview")'):]
    seg = seg[:seg.index("# ═") if "# ═" in seg[10:] else len(seg)]
    import re
    # 逐个端点切片,检查 disabled 分支的回法
    parts = re.split(r'@router\.(get|post)\("(/jfvip/[a-z/]+)"\)', seg)
    for i in range(1, len(parts) - 2, 3):
        path, code = parts[i + 1], parts[i + 2]
        if "jfvip.enabled()" not in code:
            continue
        if path == "/jfvip/overview":
            assert "status_code=503" not in code, \
                "overview 不得改 503 —— 前端靠它的 reason 渲染未启用指引页"
            continue
        assert "status_code=503" in code, \
            f"{path} 在关闭态仍回 HTTP 200 + ok:false(前端会渲染成 undefined)"


def test_jfvip_overview_reports_degraded_stats():
    """★【4.2.5 实测复现】概览的每段统计原先都裸裹 contextlib.suppress ——
    查询挂了对应 key 直接缺席,而前端写的是 `?? 0`,于是屏幕渲染出
    **「今日金额 ¥0.00」**。这与"今天真的一分没卖出去"在屏幕上一模一样:
    一次用户库故障会被运维读成一天零收入。经营看板上的静默归零比报错危险。

    纪律:允许单点故障不拖垮整个概览,但**必须留痕** —— 失败键名进 degraded[],
    前端据此把该格显示成「?」并挂降级横幅。键名两侧须同步。
    """
    src = py_code(APP / "jfvip.py")
    seg = src[src.index("async def overview()"):src.index("async def resolve_user")]
    assert "degraded" in seg, "overview() 未上报降级项,统计失败仍会静默归零"
    assert 'out["degraded"] = degraded' in seg, "degraded 未随响应回前端"
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    assert "ov.degraded" in js, "前端未消费 degraded"
    for key in ("vipAlive", "today", "week", "byPlan", "freeVisits7d", "cardsUnused"):
        assert f'"{key}"' in seg, f"统计键 {key} 未纳入 degraded 记账"


def test_admin_csv_export_is_escaped_and_covers_all_rows():
    """★【4.2.5 实测复现】导出两宗罪:

    ① 按钮写「导出本批 CSV」,实际只导**当前页 50 条**。发卡单批上限 500,
       运维把 50 条当整批交给渠道 —— 静默少 450 张,文件里毫无迹象。
    ② 零转义:批次名「渠道A,华南」或用户名「李雷,Lily」直接 join(',') ⇒
       **整行错列**(实测表头 7 列 / 数据行 8 列)。对账文件错列比没有文件更危险。
       另:以 = + - @ 开头的单元格会被 Excel/WPS 当公式执行(CSV injection)。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    assert "function jvCsvCell" in js and "function jvCsv" in js, "CSV 未走统一转义函数"
    assert 'replace(/"/g, \'""\')' in js, "CSV 未按 RFC4180 双写引号"
    assert "/^[=+\\-@\\t\\r]/" in js, "CSV 未防公式注入"
    assert "function jvFetchAll" in js, "导出未分页拉取全部命中行"
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    assert "导出本批" not in seg, "按钮文案仍称「本批」而实际范围是全部命中行"
    assert "是否模拟" in seg, "订单导出缺 simulate 列 —— 模拟单与真实付款单在对账文件里无从分辨"


def test_admin_card_disable_exposes_undo():
    """★【4.2.5 实测复现】作废弹窗白纸黑字写着「此操作可用同一入口恢复」,
    而前端**从未发送 undo,也没有任何恢复按钮** —— 后端 cards_disable(undo=)
    早已实现,能力躺在那里没接出来。对不可逆的破坏性操作谎称可逆,是最坏的一种。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    assert "jvCardRestore" in seg, "缺「恢复整批」入口"
    assert "undo" in seg, "前端从未发送 undo 标志"
    src = py_code(APP / "jfvip.py")
    assert "undo: bool = False" in src, "后端 undo 能力被移除,前端按钮会失效"


def test_admin_csv_does_not_neutralize_numbers():
    """★【复审自查】CSV 的公式注入防护**不得误伤纯数值**。

    撤销走 `_grant_tx(..., -abs(hours), ...)`,guantai_jf_grant_log.jf_hours
    落库即为**负数**。初版防护对 `-` 开头一律前置单引号 ⇒ `-240` 变 `'-240`,
    Excel/WPS 当文本 —— 运维在**唯一对账口径**上做 SUM 会把全部撤销行悄悄漏掉。
    `-240` / `+18` 交给 Excel 求值就是它本身,放行零风险。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("function jvCsvCell"):js.index("function jvCsv(")]
    assert "isNum" in seg, "jvCsvCell 未豁免纯数值,负数会被钝化成文本"
    assert "!isNum &&" in seg, "数值豁免未参与钝化判据"
    # ★ 第二轮收窄:豁免只给负号。本表所有数值字段都不会产出 `+` 前缀
    #   (String(744)==='744'、String(-240)==='-240'),而 `+8613800138000`
    #   这种手机号型用户名真实存在 —— 放行会被 Excel 求值、吃掉那个加号。
    assert "/^-?(" in seg, "数值豁免仍含 `+` 开头,手机号型用户名会被 Excel 吃掉加号"
    assert "/^[+-]?(" not in seg, "数值豁免过宽(+ 开头不应豁免)"


def test_admin_download_mime_follows_extension():
    """★【复审自查】jvDownload 同时服务发卡 .txt 与流水 .csv,MIME 不能写死。"""
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("function jvDownload"):]
    seg = seg[:seg.index("\n}")]
    assert "text/csv" in seg and "text/plain" in seg, "MIME 未按扩展名区分"
    assert "/\\.csv$/i.test(name)" in seg, "未按文件名判定 MIME"


def test_admin_jfvip_tablist_implements_keyboard_pattern():
    """★【复审自查】声明 role=tab 却不实现键盘模式,**比用朴素 button 更糟** ——
    读屏会播报「选项卡 1/5,可用方向键切换」,而方向键按了没反应。

    WAI-ARIA APG 的 tablist 模式要求:← → 循环移动、Home/End 跳首尾、
    roving tabindex(仅选中项 tabindex=0,让 Tab 键一次跳过整组)、
    tab 与 panel 用 aria-controls / aria-labelledby 互指。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    assert 'role="tablist"' in seg and 'role="tab"' in seg
    for k in ("ArrowRight", "ArrowLeft", "Home", "End"):
        assert k in seg, f"tablist 缺 {k} 键盘处理"
    assert 'tabindex="${on ? 0 : -1}"' in seg, "缺 roving tabindex(仅选中项可 Tab 聚焦)"
    assert "aria-controls=" in seg and "aria-labelledby=" in seg, "tab 与 panel 未互指"
    # ★ 真实 Chromium 实测发现:只 focus() 再 click() 是**假的可用** ——
    #   click 触发 renderJfvip(),整段 innerHTML 重写把刚聚焦的按钮销毁,
    #   焦点掉回 document,后续方向键全部失灵。必须在重绘后把焦点还回去。
    #   (jsdom 测不出;按 textContent 包含判断更是必然假阳性。)
    assert "JV._refocus" in seg, "键盘切换后未把焦点还给新渲染的页签,方向键按一次就失焦"
    assert "cur.focus()" in seg, "缺焦点归还动作"


def test_admin_jfvip_refresh_timer_not_accumulated():
    """★【复审自查】概览页 30 秒自动刷新,每次重绘都 push 一个 id 进 S.timers
    而只 clearInterval 不出队 ⇒ 数组只增不减(一小时 120 条)。
    clearInterval 对陈旧 id 无害,但该清的就得清。"""
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("async function renderJfvip"):js.index("function jvPager")]
    assert "S.timers.filter(t => t !== JV._timer)" in seg, \
        "renderJfvip 未把旧计时器移出 S.timers,数组会无限增长"


def test_admin_export_dedupes_across_pages():
    """★【复审自查】后端一律 ORDER BY id DESC。导出要翻好几页,期间若有人发新卡/
    下新单,新行占据 page 1、其后整体下移 ⇒ **页边界那条会被取两遍**。
    导给渠道的卡密表里出现重复行,是会真的多发货的。按 id 去重兜底。"""
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("async function jvFetchAll"):js.index("function jvEmptyRow")]
    assert "new Set()" in seg and "seen.has" in seg, "jvFetchAll 未对跨页结果去重"


def test_admin_user_panel_uses_dedicated_live_region():
    """★【复审自查】aria-live 不该挂在整块结果面板上 —— 一次查询,读屏会把
    五行表格连同四个按钮和整段说明全念一遍。live region 是给**状态短句**用的。

    另:sr-only 必须用 clip-path,不能用 display:none / visibility:hidden ——
    后两者会把元素从无障碍树里整个摘掉,live region 也就不播报了。"""
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    assert 'id="jvUStatus"' in seg and 'aria-live="polite"' in seg, "缺独立状态播报区"
    assert 'id="jvUBox" style="margin-top:12px"></div>' in seg, \
        "结果面板仍挂着 aria-live,读屏会整段朗读"
    css = css_code(APP.parent.parent / "assets" / "admin.css")
    assert ".sr-only{" in css, "缺 sr-only 样式"
    sr = css[css.index(".sr-only{"):css.index("}", css.index(".sr-only{"))]
    assert "clip-path" in sr, "sr-only 未用 clip-path"
    assert "display:none" not in sr and "visibility:hidden" not in sr, \
        "sr-only 用了 display:none/visibility:hidden,会让 live region 失声"


def test_admin_js_survives_production_obfuscation():
    """★【第三轮复审】交付给用户的是**混淆产物**,不是仓库源码。
    build-deploy.mjs 对 assets/admin.js 走 `renameGlobals:true` +
    `controlFlowFlattening` + `stringArray(base64/rc4)` + `splitStrings`
    + `selfDefending` 的重度混淆 —— 项目自己已有多次「源码能跑、产物崩掉」的前科
    (jf-fix.js 的 this 绑定、mock 层的 fetch 拦截,均记录在 build-deploy.mjs 注释里)。

    因此「值」视图**不得依赖任何会被混淆改写的东西**:
      · 不得靠顶层标识符名(renameGlobals 会改)—— 交互一律走 DOM 事件绑定;
      · 不得靠内联事件属性(CSP + module 作用域双杀);
      · 跨文件契约名须进 RESERVED_NAMES 白名单 —— 本视图全部为模块内部,无需豁免。

    本钉做静态守门;运行时验收见 scripts/admin_jfvip_jsdom.js --js <混淆产物>,
    已实跑通过(30/30)。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    assert "onclick=" not in seg and "onchange=" not in seg, "出现内联事件属性"
    # 不得用 eval / new Function 反射内部名(混淆后必 ReferenceError)
    assert "eval(" not in seg and "new Function" not in seg, \
        "「值」视图出现 eval/new Function —— 混淆重命名后必炸"
    # 白名单核对:本视图新增的顶层标识符都应是模块内部,不该出现在跨文件契约里
    build = (APP.parent.parent / "build-deploy.mjs").read_text(encoding="utf-8")
    assert "'assets/admin.js'" in build, "admin.js 不在重度混淆清单里(交付形态与预期不符)"


def test_docs_describe_the_admin_view_that_actually_ships():
    """★【第六轮复审】文档撒谎和代码有 bug 一样有害。

    实测发现:`JFVIP-SYSTEM.md` 与 `admin.html` 帮助都只写「整批召回」,
    **只字未提新加的「恢复整批」** —— 而让运维知道作废可撤回,正是那次修复的
    全部意义;运维读了文档仍会以为作废不可逆。另有一处已成假话:
    「整机验证…**25 项全通过**」,而脚本实际是 30 项。

    本钉把「界面上真有的关键能力」与「两份文档」绑在一起,防止再次腐化。
    """
    root = APP.parent.parent
    js = js_code(root / "assets" / "admin.js")
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    doc = (root / "JFVIP-SYSTEM.md").read_text(encoding="utf-8")
    adm = (root / "admin.html").read_text(encoding="utf-8")

    # 界面上真有 → 两份文档都必须提到
    if "jvCardRestore" in seg:
        assert "恢复整批" in doc, "JFVIP-SYSTEM.md 未提「恢复整批」,运维会以为作废不可逆"
        assert "恢复整批" in adm, "admin.html 帮助未提「恢复整批」"
    if "jvCardPlan" in seg:
        assert "档位" in doc[doc.index("| **卡密**"):doc.index("| **订单**")], \
            "文档未提卡密页的档位筛选"
    if "jvFetchAll" in seg:
        assert "全部命中" in doc or "非当前页" in doc, "文档未澄清导出范围已是全部命中行"
    if "degraded" in js:
        assert "degraded" in doc or "降级" in doc, "文档未提统计降级标记"

    # 冒烟项数不得停留在旧值(第六轮实测:文档写 25,脚本实际 30)
    assert "**25 项全通过**" not in doc, "文档里的冒烟项数已过时(实际 30 项)"


def test_admin_pager_has_no_inline_handlers():
    """★ 第四轮复审实证发现:初版分页器把翻页回调**字符串化**塞进内联 `onclick`
    (`(${go})(${n})`)—— 闭包在字符串化时就丢了,而 admin.js 是
    `<script type="module">`,顶层的 JV / renderJfvip 并不在全局作用域,
    点击必 `ReferenceError: JV is not defined`。

    **任何超过一页的列表都翻不动**(发卡单批 500、订单/流水积累后必然触发),
    而此前从未被测到 —— jsdom fixture 只有 2 条数据,`pages<=1` 直接返空串。
    内联事件属性在收紧 CSP 后也会被直接拦掉。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    assert "onclick=" not in js, "admin.js 出现内联 onclick(module 下失效 + CSP 会拦)"
    assert "function jvBindPager" in js, "分页回调未改为 addEventListener 绑定"
    assert "data-jvp" in js, "分页按钮缺可绑定的标记"


def test_game_entries_toggle_is_symmetric():
    """★ 第四轮复审发现:free 档把两个游戏入口 `hidden=true` 了,而全局**只有
    置 true、没有置 false** —— free 用户开通成功后 onVipGranted → dataBoot
    再走一遍,入口不会恢复:**刚付完钱的用户反而看不到「真实游戏 / 模拟游戏」**。

    纪律:显隐必须走同一个成对函数,杜绝"只藏不显"。
    """
    js = js_code(APPJS)
    assert "function setGameEntriesVisible" in js, "游戏入口显隐未收敛到单一出入口"
    # 散点检查:把成对函数**自身的实现**排除掉,只看函数体之外还有没有直接赋值
    import re
    i = js.index("function setGameEntriesVisible")
    body_end = js.index("\n}", i) + 2
    outside = js[:i] + js[body_end:]
    stray = re.findall(r"D\.(?:realGameOpen|jiufaOpen)\.hidden\s*=", outside)
    assert not stray, f"成对函数之外仍有散落的显隐赋值:{stray}(会再次出现只藏不显)"
    assert "setGameEntriesVisible(false)" in js and "setGameEntriesVisible(true)" in js, \
        "成对函数未被成对调用(只藏不显)"


def test_vip_modals_reuse_project_focus_helpers():
    """★ 弹层必须复用项目现成的 openModal / closeModal —— 它们带「焦点归还到
    屏外元素」的门卫(见 onScreen 注:归还到屏外 = 焦点环不可见 + Shift+Tab
    在闭合抽屉的屏外条目间隐形游走)。项目对此有明确契约,既有
    frontend_it_jsdom.js 就在断言「Esc 关层 + 焦点归还开启处」。
    自己另造一套 hidden=true/false 会丢掉这些既有的无障碍保证。
    """
    js = js_code(APPJS)
    seg = js[js.index("function showVipGate"):js.index("function hideVipGate")]
    assert "openModal(" in seg, "showVipGate 未用 openModal(无焦点落位)"
    seg2 = js[js.index("function hideVipGate"):]
    seg2 = seg2[:seg2.index("\n}\n")]
    assert "closeModal(" in seg2, "hideVipGate 未用 closeModal(焦点不归还)"


def test_jsdom_scripts_do_not_eval_internal_identifiers():
    """★ 自研 jsdom 脚本**不得**用 `w.eval("内部函数名(...)")` 驱动 ——
    混淆产物会重命名顶层标识符,那样写只能验源码版,一跑产物就
    `ReferenceError`。本轮已踩两次(管理台的 switchView、前端的 JF)。
    正解:走 UI 点击或另起一个对应档位的实例。

    交付前两版都要跑:**源码能跑不等于产物能跑,而用户拿到的是产物。**
    """
    import re
    from pathlib import Path
    root = APP.parent / "scripts"
    for name in ("frontend_jfvip_jsdom.js", "admin_jfvip_jsdom.js"):
        src = js_code(root / name)
        bad = re.findall(r"\bw\.eval\(", src)
        assert not bad, f"{name} 仍用 w.eval 驱动内部标识符(产物版必红)"


def test_order_lifecycle_uses_db_clock_only():
    """★ 第五轮复审发现:订单同一行的两个时间戳来自**两个钟** ——
    `create_time` 交给 SQL `NOW()`(库钟),`expire_time` 却写 Python 的
    `datetime.now()`(web 机钟);而 `reconcile` 又拿**库钟**去比 `expire_time`
    (`WHERE expire_time >= DATE_SUB(NOW(), …)`)。web 与 DB 时钟一有偏差,
    对账窗口就错多少 —— 而这是**钱路径**。

    项目对此有明确纪律:「到期判定用**数据库的钟**,不受 web 机时区影响」
    (LOGIN-SYSTEM.md §3,登录系统的 due_time 判定同源)。本条钉住同一纪律。
    """
    src = py_code(APP / "jfpay.py")
    assert "DATE_ADD(NOW(), INTERVAL %s SECOND))" in src, \
        "expire_time 未用库钟写入"
    # 过期/宽限/复查窗三个判定必须由 SQL 算,而不是 Python 比 datetime
    assert "past_expire" in src and "past_grace" in src and "in_recover" in src, \
        "三个时间判定未下沉到 SQL"
    import re
    # 仅允许「回给前端展示」那一处 now = datetime.now()
    uses = re.findall(r"datetime\.now\(\)", src)
    assert len(uses) <= 1, f"仍有 {len(uses)} 处 Python 时钟(应只剩展示用的那一处)"


def test_registry_hot_flags_match_actual_behaviour():
    """★ 注册表是运维判断「改完要不要重启」的唯一依据,标错就是给假信息。

    第五轮复审实测发现两处不符:
      · `jf_pay_timeout_s` 标 HOT,但初版把 ClientTimeout 绑在长驻 session 上
        ⇒ 改了**永远不生效**(运维以为生效了,其实没有);
      · `jf_pay_base` 标 RESTART,但 `_base()` 每次调用现读配置
        ⇒ **本来就是热更的**(害运维白重启一次)。
    修法是**让代码兑现声明**(timeout 改为每请求现读),而不是把 HOT 降级 ——
    超时本就该能热调。
    """
    from app import config_registry as reg
    src = py_code(APP / "jfpay.py")
    # HOT 的项必须"每次调用现读",不能在长驻对象构造期固化
    assert "def _timeout(" in src, "timeout 未做成每请求现读"
    assert "timeout=_timeout()" in src, "POST 未带 per-request timeout"
    assert "aiohttp.ClientSession(\n            connector=" in src \
        or "timeout=aiohttp.ClientTimeout" not in src.split("_get_session")[1][:400], \
        "session 上仍绑定 timeout(会让热更失效)"
    assert reg.REGISTRY["userauth.jf_pay_base"].hot == reg.HOT, \
        "jf_pay_base 实际是热更的(_base 现读),不应标 RESTART"
    assert reg.REGISTRY["userauth.jf_pay_timeout_s"].hot == reg.HOT


def test_gift_duration_uses_card_type_anchors():
    """★ 赠送时长必须说「1 个月 / 3 个月」,不是「31 天 / 93 天」。

    744h / 2232h **就是小叮当月卡 / 季卡的定义值**(tb_user_recharge_type.
    recharge_length),说月份是准确的,不是把 31 天四舍五入;而零碎天数会让
    用户对不上"我买的是月卡"。前端与管理台各有一份格式化函数,必须同口径。
    """
    js = js_code(APPJS)
    assert "function durText" in js, "前端缺时长格式化函数"
    assert "Math.round(Number(p.ddHours) / 24)" not in js, "档位卡仍在裸除 24"
    assert "Math.round(plan.ddHours / 24)" not in js, "支付弹层仍在裸除 24"
    adm = js_code(APP.parent.parent / "assets" / "admin.js")
    assert "function jvDur" in adm, "管理台缺时长格式化函数"
    # 两份实现的锚点必须一致(改一处忘另一处 = 两个界面说法打架)
    for anchor in ("8928", "4464", "744"):
        assert anchor in js and anchor in adm, f"锚点 {anchor} 两侧不一致"


# ══════════════════════════════════════════════════════════════════════════════
# 4.2.2 复审补丁的回归钉
# 三条都来自**实机量取/全仓库检索**,不是纸面推演;每条都做过反向自证。
# ══════════════════════════════════════════════════════════════════════════════
def test_modal_overflow_top_is_reachable():
    """★【实机量取】弹层内容超高时,顶部必须滚得到。

    4.2.1 的 `.vip-gate` 是 `align-items:center` + `overflow:auto` —— 经典的
    **flex 居中裁顶**:溢出被均分到上下两端,而 scrollTop 不能为负,于是上半截
    物理上滚不到。Chromium 实测(scrollTop 已强推到 -99999,即最顶):

        390×844 升级页 → 标题 top=-128px    390×844 free 门 → -41px
        360×640 free 门 → -143px           1440×700 升级页 → -16px

    被吃掉的正是印章 + 标题 + §9.12③ 特意从页脚搬到标题正下方的**状态条**
    (free 档「为什么什么都看不到」、续费档「剩 N 天 / 到期日」)。
    注意 `test_decision_facts_are_above_the_fold` 断言的是 **DOM 顺序** ——
    顺序对不等于像素可见,故它测不出本缺陷,本钉补的正是这一层。

    修法用 `flex-start` + 子项 `margin:auto`(装得下仍居中,装不下贴顶),
    **刻意不用 `align-items:safe center`** —— 那要 Safari 18(2024)才支持,
    而本产品面向的手机上有大量旧内核。
    """
    css = css_code(APP.parent.parent / "assets" / "app.css")   # 必须剥注释,见 _srcscan
    for sel in (".vip-gate", ".pay-modal"):
        i = css.index(sel + "{")
        block = css[i:css.index("}", i)]
        assert "align-items:center" not in block.replace(" ", ""), \
            f"{sel} 仍是 flex 居中 —— 内容超高时顶部滚不到(标题与状态条被吃掉)"
        assert "flex-start" in block, f"{sel} 未改为 flex-start"
        assert "overflow:auto" in block.replace(" ", ""), \
            f"{sel} 缺 overflow:auto(溢出时完全无法滚动,比裁顶更糟)"
    for sel in (".vip-card", ".pay-card"):
        i = css.index(sel + "{")
        block = css[i:css.index("}", i)]
        assert "margin:auto" in block.replace(" ", ""), \
            f"{sel} 缺 margin:auto —— 与 flex-start 配对才能保住「装得下时仍居中」"


def test_reconcile_is_actually_wired():
    """★【全仓库检索】对账兜底不许再空转。

    `jfpay.py` 的安全不变量 8 写着「前端轮询停了时由后端亲自向网关查证救回」,
    但在 4.2.1 里 `POST /api/vip/order/reconcile` **全仓库无人调用** ——
    前端零引用、管理台零引用、无定时任务。于是用户扫码付款后关掉标签页 /
    手机切后台被杀,订单永远停在 pending:钱收了,九法VIP 与小叮当都不到账,
    且没有任何自动救回路径。这是资损级空转,不是体验问题。

    触发点纪律:必须由**本机在途单标记**驱动,不许无脑每次开机就调 ——
    被遗弃的 pending 单不会自动转 expired(`_mark_expired` 只由
    query_and_settle / reconcile 调用),会挂满整个 24h 回溯窗;而 reconcile
    单次最多查 10 笔网关。无脑调 = 替人白刷网关。
    """
    js = js_code(APPJS)
    assert "/api/vip/order/reconcile" in js, \
        "前端仍未调用对账兜底端点 —— 关掉标签页的已付订单永远无人救回"
    assert "function payRecover" in js, "缺对账兜底的统一触发函数"
    seg = js[js.index("async function payRecover"):]
    seg = seg[:seg.index("\n}\n")]
    assert "KEY.payPend" in seg, "对账兜底未由本机在途单标记驱动(会变成无脑轮询)"
    assert "payPendClear()" in seg, "救回/无可救回后未清标记(会永远重试)"
    # 打标记与清标记必须成对存在,且打标记发生在下单成功之后
    assert "payPendMark(" in js and "function payPendClear" in js, "标记未成对"
    # payExpired **不得**清标记:它也会被本地宽限计时器触发,而「已付、网关确认
    # 晚到几秒」恰恰长这样 —— 那时清掉标记等于把唯一的救回机会一起清掉。
    seg_exp = js[js.index("function payExpired"):]
    seg_exp = seg_exp[:seg_exp.index("\n}\n")]
    assert "payPendClear" not in seg_exp, \
        "payExpired 清了在途单标记 —— 本地宽限到点即放弃救回,会吞掉晚到的付款"


def test_reconcile_endpoint_is_rate_limited():
    """★ 对账端点必须限频:单次最多向网关查 jf_reconcile_max(默认 10)笔,
    **放大倍数是下单的 10 倍**。不限频等于给任意注册用户(含 free 档)一个
    白刷网关的杠杆 —— 与 `order_rate_ok` 当初的设立理由同源,只是杠杆更长。
    前端的本机标记挡不住手搓客户端,服务端这一道才是底线。"""
    from app import jfvip as _jfvip
    assert hasattr(_jfvip, "reconcile_rate_ok"), "jfvip 缺对账限频判定"
    src = py_code(APP / "web.py")
    seg = src[src.index('@app.post("/api/vip/order/reconcile")'):]
    seg = seg[:seg.index("@app.", 10)]
    assert "reconcile_rate_ok" in seg, "对账端点未接限频"
    assert seg.index("reconcile_rate_ok") < seg.index("jfpay.reconcile"), \
        "限频必须在真正打网关之前判定"


def test_plan_price_is_not_rounded_to_integer():
    """★ 档位卡不得把价格四舍五入成整数。

    后端 `jfvip.plans()` 是 `round(price, 2)`,即**允许两位小数**;而 4.2.1 的
    档位卡写死 `toFixed(0)` —— 运营配 39.9 时,档位卡显示 ¥40,支付弹层
    (`toFixed(2)`)与管理台(`jvMoney`)都显示 ¥39.90。同一档位两个界面两个价,
    用户第一反应是「被多收了」。
    """
    js = js_code(APPJS)
    assert "Number(p.price).toFixed(0)" not in js, "档位卡仍在把价格四舍五入成整数"
    assert "function priceText" in js, "缺价格格式化函数"
    seg = js[js.index("function priceText"):]
    seg = seg[:seg.index("\n}\n")]
    assert "toFixed(2)" in seg and "isInteger" in seg, \
        "priceText 应做到:整数价按整数显示,带小数才给两位"


def test_user_can_see_own_grant_records():
    """★ 用户必须能查到自己的开通记录。

    `/api/vip/orders` 在 4.2.0 就实现了(orders + grants,与管理台「开通流水」
    同一口径),但前端**零引用** —— 付了钱的用户查不到自己买过什么、到期到哪天,
    更无法自查「我付了钱怎么没开通」。对收费产品这是基础信任设施。

    必须同时取两张表:grants 是唯一对账口径(含卡密与管理员开通),
    orders 额外给出**没到账**的单 —— 那正是用户最需要看见的一类。
    """
    js = js_code(APPJS)
    assert "/api/vip/orders" in js, "前端仍未消费开通记录端点"
    idx = INDEX.read_text(encoding="utf-8")
    assert 'id="vipRecBtn"' in idx and 'id="vipRecords"' in idx, "开通记录 DOM 缺失"
    seg = js[js.index("async function loadVipRecords"):]
    seg = seg[:seg.index("\n}\n")]
    assert "grants" in seg and "orders" in seg, "只取了一张表(未到账的单看不见)"
    assert "credited" in seg, "未把「未到账」的订单单独呈现给用户自查"


def test_compare_lock_is_not_emoji():
    """对比表的锁形改用内联 SVG:emoji 🔒 在不同平台/字体下会渲染成彩色、单色、
    不同字重的三种样子,与同一行的 ✓、与整卡的自绘印章(法)都不同源。
    `currentColor` 保证永远与文字同色同重。类名 `.vc-lock` 保持不变
    (jsdom 断言与样式都以它为锚)。"""
    js = js_code(APPJS)
    assert "🔒" not in js, "对比表仍在用 emoji 锁形"
    assert "vc-lock" in js, "锁形类名丢失(jsdom 与样式都以它为锚)"
    assert "currentColor" in js, "SVG 未用 currentColor(无法与文字同色)"


def test_unknown_vip_days_is_not_treated_as_expired():
    """★【实机复验暴露】`Number(null) === 0` 且 `Number.isFinite(0) === true` ——
    于是「剩余天数未知」被当成「剩 0 天」,三处一起出错:身份牌显示「九法VIP 剩 0 天」
    并转警示色、状态条显示「今日到期」并转红、临期提醒弹「今日到期 · 去续费」。

    最糟的触发点是**刚付完钱**:`onVipGranted` 里 `/api/vip/state` 若失败
    (付款后网络抖一下就够),`JF.vipDays` 保持开通前的 null —— 用户付完 ¥88,
    立刻被告知「今日到期,去续费」。未知 ≠ 到期,必须区分。
    """
    js = js_code(APPJS)
    assert "function vipDaysNum" in js, "缺 null/数值 的统一判定"
    for fn, why in (("function renderAuthChip", "身份牌"),
                    ("function vipExpiryNudge", "临期提醒")):
        seg = js[js.index(fn):]
        seg = seg[:seg.index("\n}\n")]
        assert "Number(JF.vipDays)" not in seg, f"{why}仍在裸 Number(JF.vipDays)(null 会变 0)"
        assert "vipDaysNum()" in seg, f"{why}未走 vipDaysNum"
    seg = js[js.index("function renderVipStatus"):]
    seg = seg[:seg.index("\n}\n")]
    assert "Number(JF.vipDays)" not in seg and "vipDaysNum()" in seg, \
        "状态条仍把未知当作今日到期"


# ══════════════════════════════════════════════════════════════════════════════
# 第八轮复审(自审 4.2.2 的改动 + 找同类问题)的回归钉
# ══════════════════════════════════════════════════════════════════════════════
def test_all_fixed_overlays_can_scroll_their_overflow():
    """★【实机量取·同类问题】所有承载**可交互内容**的固定层,溢出部分必须滚得到。

    上一轮只修了 `.vip-gate`。本轮回头把全站固定层扫了一遍,发现登录/注册门
    `.auth-gate` 是同一家族的另一种死法:它用 grid(Chrome 下不裁顶),但
    `position:fixed` + `overflow:visible` ⇒ **溢出到视口下方的部分永远滚不到**
    —— 固定层自身不能滚,滚文档也带不动它。实测(穷尽 scrollTop / scrollTo /
    滚轮 / scrollIntoView,并用 Playwright 真点击验证):

        844×390 横屏 → 「注册账号」不可达(Playwright 报 outside of viewport)
        740×360 横屏 → 「注册账号」不可达
        568×320 横屏 → **「登录」按钮本身不可达**(等于根本没法登录)
        360×380 竖屏软键盘弹起 → 「注册账号」不可达

    卡高 397px,视口净高 < 437px 即触发 —— 横屏、以及"点了输入框键盘顶上来"
    都在此列。这是 VIP 漏斗的**大门**:进不来就谈不上充值。
    `.modal`(添加直播间/账号)同构,一并加固(实测当前不溢出,属防御)。
    """
    css = css_code(APP.parent.parent / "assets" / "app.css")   # 必须剥注释,见 _srcscan
    for sel in (".vip-gate", ".pay-modal", ".auth-gate", ".modal"):
        i = css.index(sel + "{")
        b = css[i:css.index("}", i)].replace(" ", "").replace("\n", "")
        assert "overflow:auto" in b, f"{sel} 缺 overflow:auto —— 溢出内容将永远滚不到"
        assert "align-items:center" not in b and "place-items:center" not in b, \
            f"{sel} 仍是居中对齐 + 可滚容器,超高时顶部会被裁掉且滚不上去"
    for sel in (".vip-card", ".pay-card", ".auth-card", ".modal-card"):
        i = css.index(sel + "{")
        b = css[i:css.index("}", i)].replace(" ", "").replace("\n", "")
        assert "margin:auto" in b, f"{sel} 缺 margin:auto(装得下时不再居中)"


def test_revoked_grant_rows_show_a_minus_not_a_plus():
    """★【自审】`revoke_by_admin` 往开通流水里写的是 **-abs(hours)**,而 `durText`
    对 h<=0 恒回空串 —— 直接拼会把撤销记录渲染成「九法VIP +」(断句),
    还给撤销标了个「+」号,语义正好相反。时长必须带符号。"""
    js = js_code(APPJS)
    seg = js[js.index("async function loadVipRecords"):]
    seg = seg[:seg.index("\n}\n")]
    assert "signed(" in seg, "开通记录未对时长带符号处理(撤销会显示成 +)"
    assert "九法VIP +" not in seg, "仍在硬拼 + 号"
    src = py_code(APP / "jfvip.py")
    assert "-abs(int(hours))" in src, "撤销写负时长的前提变了,本钉需重新评估"


def test_record_panel_invalidates_after_grant():
    """★【自审】记录区是「首次展开才拉」的。用户开通**前**看过一次记录、开通后
    再展开,若不失效就还是那份旧列表(没有这次开通)—— 看起来像"没买成"。"""
    js = js_code(APPJS)
    seg = js[js.index("async function onVipGranted"):]
    seg = seg[:seg.index("\n}\n")]
    assert "VIP_REC_LOADED = false" in seg, "开通后未让开通记录失效重取"


def test_pay_recover_has_inflight_guard():
    """★【自审】payRecover 有两个触发点(开机 / 关支付层),且单次最长 30s。
    开机那次尚在飞行中时用户开了支付层又关掉 —— 无守卫就会并发打两次网关,
    并可能重入 onVipGranted。"""
    js = js_code(APPJS)
    assert "_payRecovering" in js, "payRecover 缺并发守卫"
    seg = js[js.index("async function payRecover"):]
    seg = seg[:seg.index("\n}\n")]
    assert "if (_payRecovering) return;" in seg, "守卫未置于入口"
    assert "finally { _payRecovering = false; }" in seg, "守卫未在 finally 里复位(异常后会永久卡死)"


# ══════════════════════════════════════════════════════════════════════════════
# 第九轮复审(继续自审 + 边界配置)的回归钉
# ══════════════════════════════════════════════════════════════════════════════
def test_stale_pay_marker_is_cleared():
    """★【自审】本机在途单标记必须能被识别为「陈旧」并清掉。

    典型成因:另一个标签页把这笔单轮询结算掉了,而本标签页的标记还在。
    不清的话它会让**每次开机都白发一次 POST**、连发 24 小时,还会吃掉
    reconcile 的 12 次/时限频配额 —— 掩盖后续真正需要的救回。

    判据必须是 `candidates`(库里确实存在的待救回笔数)而**不是** `checked`:
    checked=0 也可能是「有单但网关全查失败」,那种情况标记必须留着下次再试。
    实测:candidates=0 → 第二次开机零调用;candidates=1 → 标记保留、继续重试。
    """
    js = js_code(APPJS)
    seg = js[js.index("async function payRecover"):]
    seg = seg[:seg.index("\n}\n")]
    assert "Number(r.candidates) === 0" in seg, \
        "未按 candidates 识别陈旧标记(用 checked 会把「网关查失败」误清)"
    src = py_code(APP / "jfpay.py")
    assert '"candidates": candidates' in src, "reconcile 未回报候选笔数"
    assert "candidates = len(rows)" in src, "candidates 不是库里实际命中的行数"


def test_zero_gift_plan_renders_no_dangling_text():
    """★【边界配置】后端 `plans()` 只过滤 `price>0` 与 `jfHours>0` ——
    **`ddHours=0` 是合法配置**(运营随时可以停掉赠送)。而 `durText(0)` 回空串,
    原先三处无条件拼接全部出错(实机复现):

        档位卡   → 「1 个月 ¥88 送小叮当」        (断句)
        支付弹层 → 「九法VIP · 1 个月(送小叮当 )」(空括号)
        总说明   → 「开通即赠送同时长小叮当会员」 (**这是假话**)

    付费页上说假话是最不能忍的一类。逐档是否赠送,档位卡自己已经写了。
    """
    js = js_code(APPJS)
    assert "const gift = durText(p.ddHours);" in js, "档位卡未先判断有无赠送"
    assert "送小叮当 ${esc(durText(p.ddHours))}" not in js, "档位卡仍在无条件拼赠送"
    seg = js[js.index("async function openPay"):]
    seg = seg[:seg.index("\n}\n")]
    assert "g ? `九法VIP" in seg, "支付弹层仍会留下空括号"
    seg2 = js[js.index("function showVipGate"):js.index("function hideVipGate")]
    assert "Number(p.ddHours) > 0" in seg2, "赠送总说明未按实际档位显隐(可能说假话)"


def test_honeypot_survives_new_scroll_container():
    """★【自审·副作用】给 `.auth-gate` 加 `overflow:auto` 会把它变成滚动容器,
    而注册表单的 R4 蜜罐是 `position:absolute; left:-4000px`,其包含块正是
    `.auth-gate`(`.auth-card` 没有 `position:relative`)。

    实测(390/844/1440 三种宽度):`scrollWidth === clientWidth`,**未产生横向
    滚动条**(符合规范:行首方向的溢出不计入可滚区域),且 `#regContact`
    仍在 DOM 中可读写 —— 蜜罐功能不受影响。本钉钉住这两个前提别被改坏。
    """
    css = css_code(APP.parent.parent / "assets" / "app.css")
    i = css.index(".hp-field{")
    assert "left:-4000px" in css[i:css.index("}", i)], "蜜罐定位变了,本钉需重新评估"
    i2 = css.index(".auth-card{")
    assert "position:relative" not in css[i2:css.index("}", i2)], \
        "auth-card 若变成定位元素,蜜罐的包含块会改变,需重测横向溢出"
    idx = INDEX.read_text(encoding="utf-8")
    assert 'id="regContact"' in idx and 'class="hp-field"' in idx, "蜜罐被移除了"


# ══════════════════════════════════════════════════════════════════════════════
# 第十轮复审(产物计算值 / 无障碍 / 升级迁移)的回归钉
# ══════════════════════════════════════════════════════════════════════════════
def test_scrollable_record_panel_is_keyboard_focusable():
    """★【无障碍·Safari】可滚区域必须能被键盘聚焦(WCAG 2.1.1 Level A)。

    Chrome 130+ / Firefox 会自动让可滚容器可聚焦,**Safari 不会**(Apple 开发者
    论坛明确要求 `tabindex="0"` 或含可聚焦子元素)。而 `#vipRecords` 里全是纯文本行,
    没有任何可聚焦子元素 —— 不加 tabindex,Safari 键盘用户根本滚不动它。

    其余四个弹层(vipGate / payModal / authGate / modal)因含按钮/输入框而天然满足,
    这也是为什么只有本区需要显式补。
    """
    idx = INDEX.read_text(encoding="utf-8")
    i = idx.index('id="vipRecords"')
    tag = idx[idx.rindex("<", 0, i):idx.index(">", i) + 1]
    assert 'tabindex="0"' in tag, f"可滚的开通记录区缺 tabindex=0(Safari 键盘用户滚不动):{tag}"
    assert 'role="region"' in tag and "aria-label" in tag, "可聚焦区域缺可访问名称"
    css = css_code(APP.parent.parent / "assets" / "app.css")
    i2 = css.index(".vip-records{")
    assert "overflow-y:auto" in css[i2:css.index("}", i2)].replace(" ", ""), \
        "本钉的前提是该区可滚;若不再可滚,tabindex 反而是多余的 tab 停靠点"


def test_recover_never_fires_without_a_local_marker():
    """★【纪律保护·本轮踩过的坑】对账兜底必须**严格由本机在途单标记驱动**。

    本轮曾试过加「每台设备一次性补扫」以覆盖升级前的存量在途单 ——
    jsdom 的「free 档零数据请求(最硬的一条)」当场变红(实际发了 1 个
    `/api/vip/order/reconcile`)。而收益近乎为零:§10.6 记载真实支付回调
    **从未跑通过**,也就不存在"升级前已付未到账"的存量。用永久的客户端代价
    换一个空集合是坏交易,已撤回。

    本钉的职责是不让这个想法再回来:payRecover 必须在读不到标记时立即 return,
    且函数体内不得出现任何"无标记也要发一次"的旁路。
    """
    js = js_code(APPJS)
    assert "KEY.paySweep" not in js, "补扫旁路又回来了 —— 它会打破 free 档零数据请求"
    seg = js[js.index("async function payRecover"):]
    seg = seg[:seg.index("\n}\n")]
    assert "if (!mark || !mark.t) return;" in seg, "无标记时未立即返回"
    # 早退必须发生在任何网络调用之前
    assert seg.index("if (!mark || !mark.t) return;") < seg.index("api("), \
        "无标记的早退晚于网络调用 —— free 档会白发请求"


def test_reconcile_endpoint_has_exception_fallback():
    """★ 用户库在公网、RTT 受安全组摆布。对账兜底自 4.2.2 起是热路径
    (每次相关开机都打),却曾是**唯一**既无 try 也无 suppress 的 VIP 端点。"""
    src = py_code(APP / "web.py")
    seg = src[src.index('@app.post("/api/vip/order/reconcile")'):]
    seg = seg[:seg.index("@app.", 10)]
    assert "try:" in seg and "except Exception" in seg, "对账端点仍无异常兜底(库抖动即 500)"
    assert seg.index("reconcile_rate_ok") < seg.index("try:"), "限频应在 try 之外先判"


# ══════════════════════════════════════════════════════════════════════════════
# 4.2.6 ·「值」订单页检索与分页
# ══════════════════════════════════════════════════════════════════════════════
def test_admin_order_filters_are_wired_end_to_end():
    """前端摆出来的每个筛选控件,后端都得真收得到。

    起因是实测到的一处**能力被埋**:`orders_page()` 从 4.2.0 起就带 uid 参数,
    `admin_api.jfvip_orders` 也接了 —— 而前端从头到尾只拼 `status=`,
    那条通路等于不存在。界面上摆着、后端接不到,是最沉默的一类漂移:
    点下去有反应、结果却不对,没人会怀疑到参数没送。故三层一起钉。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    api = py_code(APP / "admin_api.py")
    core = py_code(APP / "jfvip.py")

    # ① 前端:控件 id 必须是**字面量**(见 test_admin_reg_view_ids_exist 的守门)
    for eid in ("jvOrdNo", "jvOrdUser", "jvOrdPlan", "jvOrdFrom", "jvOrdTo",
                "jvOrdAmin", "jvOrdAmax", "jvOrdSim", "jvOrdCred",
                "jvFlt", "jvFltGo", "jvFltReset"):
        assert f'id="{eid}"' in seg, f"订单检索缺控件 {eid}(或用模板变量拼了 id)"
    # ② 前端 → URL:每个条件都要真进请求串
    for q in ("orderNo", "userName", "plan", "dateFrom", "dateTo",
              "amtMin", "amtMax", "simulate", "credited", "status"):
        assert f"{q}:" in seg, f"筛选项 {q} 没进请求串(界面摆设)"
    # ③ URL → 端点签名
    for q in ("orderNo", "userName", "plan", "dateFrom", "dateTo",
              "amtMin", "amtMax", "simulate", "credited"):
        assert f"{q}: str = Query(" in api, f"/jfvip/orders 未接收 {q}"
    # ④ 端点 → 业务层
    for kw in ("order_no=", "user_name=", "plan_code=", "date_from=", "date_to=",
               "amt_min=", "amt_max=", "simulate=", "credited="):
        assert kw in api, f"端点未把 {kw} 透传给 orders_page"
    for kw in ("order_no:", "user_name:", "plan_code:", "date_from:", "date_to:"):
        assert kw in core, f"orders_page 缺形参 {kw}"


def test_admin_order_search_predicates_fit_existing_indexes():
    """谓词形态必须迁就**现有**索引 —— 本项目禁止对用户库 ALTER。

    真库实测(40 万行,Handler_read_* 数真实扫描行数):
      · 订单号中缀 LIKE '%x%' 扫 200,048 行,前缀 LIKE 'x%' 只扫 24 行;
      · 裸 `user_name=` 扫 400,000 行(该列无索引),先解析成 uid 只扫 9 行。
    这两条一旦被"顺手改得更好用"(改成中缀、或图省事直接查 user_name),
    性能会在**没有任何报错**的情况下塌掉一个数量级。故钉死。
    """
    core = py_code(APP / "jfvip.py")
    seg = core[core.index("async def orders_page"):core.index("async def overview")]
    assert 'args.append(esc + "%")' in seg, "订单号未按前缀匹配"
    assert '"%" + ' not in seg and "'%' + " not in seg, \
        "订单号退化成中缀 LIKE —— 真库实测会从 24 行涨到 200,048 行"
    assert "await resolve_user(" in seg, \
        "用户名未先解析成 uid —— 裸 user_name= 实测扫 400,000 行"
    # LIKE 元字符必须转义,否则搜一个含 % 的串会静默变成全表扫
    assert 'replace("%", "\\\\%")' in seg, "LIKE 元字符 % 未转义"
    assert 'replace("_", "\\\\_")' in seg, "LIKE 元字符 _ 未转义"


def test_list_count_is_capped_and_page_has_an_upper_bound():
    """三个列表页都不许再出现裸 COUNT(*),页码必须有上界。

    真库实测:裸 COUNT(*) 无筛选扫 400,000 行,且**第 1 页就要付**
    (不是深翻页才有);导出走 jvFetchAll 逐页取满,一次要付 10 次。
    另:page 原先只有 `max(1, …)` 下界钳制,`?page=99999999` 可以直接
    让库倒扫整棵主键(末页实测 399,999 行)。
    """
    core = py_code(APP / "jfvip.py")
    assert "async def _count_capped" in core and "def _clamp_page" in core
    for fn, nxt in (("async def cards_page", "async def cards_disable"),
                    ("async def grants_page", "async def orders_page"),
                    ("async def orders_page", "async def overview")):
        seg = core[core.index(fn):core.index(nxt)]
        assert "SELECT COUNT(*) AS n FROM guantai" not in seg, \
            f"{fn} 仍在裸 COUNT(*) —— 每翻一页都与表规模同阶"
        assert "_count_capped(" in seg, f"{fn} 未接入封顶计数"
        assert "_clamp_page(" in seg, f"{fn} 未夹紧页码"
    api = py_code(APP / "admin_api.py")
    # ★ 复审补:三个兄弟端点**一起**钉。初版只钉了 orders —— 而 cards/grants
    #   当时还是裸 `page: int = 1`,同一片视图、同一类参数却两套校验强度。
    #   只钉一个的测试,恰恰会让人以为另两个是"有意为之"。
    for name, nxt in (("cards", '@router.post("/jfvip/cards/generate")'),
                      ("orders", '@router.get("/jfvip/grants")'),
                      ("grants", '@router.get("/jfvip/user")')):
        seg = api[api.index(f'@router.get("/jfvip/{name}")'):api.index(nxt)]
        assert "page: int = Query(1, ge=1, le=" in seg, f"/jfvip/{name} 的 page 缺形态闸"
        assert "size: int = Query(50, ge=1, le=500)" in seg, f"/jfvip/{name} 的 size 缺形态闸"
    # 用户侧端点同样要有 —— 它比管理台更该有,因为任何登录用户都够得着
    web_src = py_code(APP / "web.py")
    wseg = web_src[web_src.index('async def vip_orders'):]
    wseg = wseg[:wseg.index("\n@app.")]
    assert "ge=1, le=" in wseg, "/api/vip/orders 的 page/size 缺上界(公开面更需要)"
    # 封顶要如实告诉前端,不能假装是精确值
    assert '"totalCapped"' in core, "封顶后未回 totalCapped,前端会把 50000 当精确总数"
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    assert "totalCapped" in js, "前端未消费 totalCapped"


def test_pager_always_renders_and_is_four_way():
    """分页条不许在单页时消失,且必须四向可达。

    旧版第一行是 `if (pages <= 1) return ''` —— jsdom 实测 total=30 时整条
    分页器**凭空消失**,页面上只剩一行灰字。日常量不大时运维打开就是
    「什么都没有」,「订单没有分页功能」这个印象正是这么来的。
    这与 jvEmptyRow 要解决的是同一个病(「真没有」与「没查对」不可区分),
    不该只治表格不治分页条。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("function jvPager"):js.index("function jvDownload")]
    assert "if (pages <= 1) return ''" not in seg, "单页时分页条又被藏掉了"
    assert 'data-jvp="${act}"' in seg, "分页按钮缺可绑定的 data-jvp 标记"
    # 渲染端与绑定端必须用**同一组**动作名。只测其中一端是测不出 `btn('frist')`
    # 这类拼写漂移的:渲染照样出按钮,绑定却落进 else 分支静默跳回第 1 页。
    for act in ("first", "prev", "next", "last"):
        assert f"btn('{act}'" in seg, f"分页条没渲染 {act} 按钮"
        assert f"'{act}'" in seg, f"jvBindPager 未处理 {act}"
    assert "data-jvps" in seg, "分页条缺每页条数选择器"
    # 既有冒烟脚本按 .jv-pager / data-jvp 断言,重做不得把别人的钉子拔了
    assert "jv-pager" in seg and 'class="pager jv-pager"' in seg, \
        "分页条丢了 .jv-pager 钩子或没复用既有 .pager 样式"
    # 翻页会整段重绘并销毁刚点的按钮,焦点必须还回去(与 tablist 那处同源的坑)
    assert "JV._refocusPager" in seg, "翻页后未归还焦点,键盘用户按一次就出不来"
    assert "function jvRestorePagerFocus" in js


def test_jfvip_toolbar_layout_classes_actually_exist():
    """`.row` / `.spacer` 必须有**全局**规则,不能只有后代选择器。

    把 admin.css 真注入 jsdom 后 getComputedStyle 实测:`.row.jv-tabs` 的
    display 是 **block** —— 全站只有 `.seal-pop .row` 和 `.topbar .spacer`
    两条后代规则,而「值」视图六条工具条写的都是裸 `class="row"`。
    于是内联的 gap / flex-wrap / align-items 全部失效,`.spacer` 的 flex:1
    更是毫无作用:「导出 CSV」按钮从来就没被推到右边过。
    这类"样式写了但没生效"看源码永远发现不了,只有真跑计算样式才逮得到。
    """
    css = css_code(APP.parent.parent / "assets" / "admin.css")
    assert re.search(r"(^|[;}\s])\.row\{[^}]*display:flex", css), \
        ".row 缺全局 display:flex —— 「值」视图六条工具条不是 flex 容器"
    assert re.search(r"(^|[;}\s])\.spacer\{[^}]*flex:1", css), \
        ".spacer 缺全局 flex:1 —— 右推占位无效,导出按钮推不到右边"
    for cls in (".jv-filters{", ".jv-f{", ".jv-pjump", ".jv-psize"):
        assert cls in css, f"订单检索条缺样式 {cls}"


def test_visible_labels_are_not_overridden_by_aria_label():
    """有可见 <label> 时不得再写 aria-label —— 它会**覆盖**可见文字。

    WCAG 2.5.3(Label in Name)要求无障碍名必须包含可见标签文字。本轮初版
    实测有 5 处不合规:可见「下单起」/ 无障碍名「下单日期起(含当天)」、
    可见「金额 ≥」/ 无障碍名「金额下限」…… 语音控制用户念屏幕上看得见的
    那几个字,点不中。补充说明该挂 title=(它进的是描述,不参与该判据)。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("const ordFilters"):js.index("const anyFilter")]
    assert "aria-label=" not in seg, \
        "筛选条又出现 aria-label —— 会盖掉可见 label,违反 WCAG 2.5.3"
    # 可见标签必须真的存在(否则"没有 aria-label"就成了压根没名字)
    for lab in ("订单号", "用户名", "状态", "档位", "下单起", "下单止",
                "金额 ≥", "金额 ≤", "是否模拟", "是否入账"):
        assert f"fld('{lab}'" in seg, f"筛选条缺可见标签「{lab}」"


def test_all_three_list_tabs_consume_total_capped():
    """三个列表页签都必须消费 totalCapped,不能有一个把封顶值当精确数显示。

    后端已给 cards/orders/grants 统一封顶。本轮初版只在 orders/grants 分支
    加了「+」后缀与提示条,**卡密页漏了** —— 于是它会把 50000 渲染成
    「共 50000 张」。这正是分页器注释里写过的「谎报一个精确总数比显示
    50000+ 危险得多」,却在三个页签里漏了一个。
    单批发卡上限 500,一百个批次就够到上限,并非够不着的极端值。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    cards = seg[seg.index("if (JV.tab === 'cards')"):seg.index("if (JV.tab === 'orders'")]
    assert "totalCapped" in cards, "卡密页未消费 totalCapped(会把封顶值当精确总数)"
    assert "cCapped ? '+' : ''" in cards, "卡密页封顶时未加「+」后缀"
    lists = seg[seg.index("if (JV.tab === 'orders'"):]
    assert "totalCapped" in lists, "订单/流水页未消费 totalCapped"


def test_pager_focus_flag_is_always_consumed():
    """`JV._refocusPager` 在**每条**渲染路径上都得被消费掉。

    实测:翻页失败(网络抖动)时错误分支直接 return,而 jvRestorePagerFocus()
    在其后 —— 标志留着,下一次成功渲染(切页签回来、点查询)会莫名把焦点
    抢到分页器上。项目自己在 tablist 那处就吃过焦点被打飞的亏,同类不能再犯。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    # 每个 return 掉的错误分支都要显式清标志
    n_clear = seg.count("JV._refocusPager = ''")
    assert n_clear >= 2, f"错误分支未清 _refocusPager(仅 {n_clear} 处清理)"
    assert seg.count("jvRestorePagerFocus(") >= 2, "成功路径未归还焦点"


def test_export_freezes_filters_at_start():
    """导出必须在开始时**冻结**筛选条件,不能读活状态。

    第五轮真浏览器实测复现(**原始版即有**,本轮把触发面从 3 个条件扩到 10 个):
    jvFetchAll 逐页取满(单次上限 5000 行 = 10 个来回),而 URL 构造器闭包读的是
    状态**对象本身**、doQuery() 又是就地改它 —— 期间改筛选点「查询」,后半段就用
    新条件取数。实测第 1 页无筛选、第 2/3 页带 userName=bob,CSV 成了两套条件的
    混合物,而文件名与行数**全都看不出异常**。对账文件出这种事比没有文件更危险
    (项目在 CSV 转义那处写过同一句话)。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    # 构造器必须参数化(能被喂快照),而不是直接闭包活状态
    assert "const mkCardsUrl = c =>" in seg, "卡密 URL 构造器未参数化"
    assert "const mkListUrl = o =>" in seg, "订单/流水 URL 构造器未参数化"
    # 两处导出都必须先冻结再传
    assert seg.count("Object.assign({}, JV.cards)") == 1, "卡密导出未冻结筛选快照"
    assert seg.count("Object.assign({}, st)") == 1, "订单/流水导出未冻结筛选快照"
    assert "jvFetchAll(mkCardsUrl(snap)" in seg, "卡密导出仍在用活引用取数"
    assert "jvFetchAll(mkListUrl(snap)" in seg, "订单/流水导出仍在用活引用取数"
    # 文件名同样要用快照 —— 否则导完会落到别的页签/批次名下
    assert "jfvip-${tab}-" in seg, "导出文件名读的是活 JV.tab"
    assert "jfvip-cards-${snap.batch" in seg, "卡密导出文件名读的是活 JV.cards.batch"


def test_non_gbk_user_name_is_treated_as_absent_not_a_crash():
    """用户名含 GBK 表示不了的字符时,必须按「查无此人」处理,不能把异常抛出去。

    真库实测:resolve_user() 自己吞掉 UnicodeEncodeError 回 None,而快照回退把
    **同一个串**再塞进 user_name=%s —— 那条查询没人接,异常一路穿到 FastAPI
    ⇒ 管理台 500。搜 "user🐟emoji" 必崩。
    项目对此早有定论(登录侧 C8、resolve_user 自身注释):
    「gbk 表示不了的用户名 ≡ 查无此人」。
    """
    core = py_code(APP / "jfvip.py")
    seg = core[core.index("async def orders_page"):core.index("async def overview")]
    assert "UnicodeEncodeError" in seg, "订单检索未处理 gbk 不可编码的用户名(会 500)"
    assert 'where.append("1=0")' in seg, "未按「查无此人」闭合,而是继续拿原串打库"


# ══════════════════════════════════════════════════════════════════════════════
# 4.2.6 第六轮 ·「三个列表页签结构等价」的机器检查
# ══════════════════════════════════════════════════════════════════════════════
# 起因:同一个缺陷在本轮被**漏改了两次**,两次都是「订单改了、卡密忘了」——
#   · 第三轮:卡密页没消费 totalCapped,把封顶值当精确总数渲染;
#   · 第五轮:卡密导出与订单导出一样读活状态,CSV 会混两套筛选条件。
# 单点钉子(「卡密页要有 X」)只能防住**已经犯过**的那一个;下一个能力加进来时,
# 漏改依然发生。故改为**枚举三个页签 × 若干必备性质**的矩阵断言:
# 新增页签或新增性质时,遗漏会自动变红,不再依赖人眼逐个比对。
LIST_TABS = ["cards", "orders", "grants"]

# (性质名, 在 jfvip.py 该函数体内必须出现的片段)
BACKEND_INVARIANTS = [
    ("封顶计数(不得裸 COUNT)", "_count_capped("),
    ("页码按总数夹紧", "_clamp_page("),
    ("如实上报是否封顶", '"totalCapped"'),
]
BACKEND_FN = {"cards": ("async def cards_page", "async def cards_disable"),
              "orders": ("async def orders_page", "async def overview"),
              "grants": ("async def grants_page", "async def orders_page")}


def test_all_list_pages_share_the_same_backend_invariants():
    core = py_code(APP / "jfvip.py")
    missing = []
    for tab in LIST_TABS:
        a, b = BACKEND_FN[tab]
        seg = core[core.index(a):core.index(b)]
        assert "SELECT COUNT(*) AS n FROM guantai" not in seg, \
            f"{tab}_page 仍在裸 COUNT(*)(与表规模同阶,每翻一页都要付)"
        for name, frag in BACKEND_INVARIANTS:
            if frag not in seg:
                missing.append(f"{tab}:{name}")
    assert not missing, "列表页后端性质不齐:" + "、".join(missing)


def test_all_list_endpoints_share_the_same_query_gates():
    """三个端点的形态闸强度必须一致 —— 只给其中一个上闸,反而会让人以为另两个是有意为之。"""
    api = py_code(APP / "admin_api.py")
    nxt = {"cards": '@router.post("/jfvip/cards/generate")',
           "orders": '@router.get("/jfvip/grants")',
           "grants": '@router.get("/jfvip/user")'}
    for tab in LIST_TABS:
        seg = api[api.index(f'@router.get("/jfvip/{tab}")'):api.index(nxt[tab])]
        assert "page: int = Query(1, ge=1, le=" in seg, f"/jfvip/{tab} 的 page 缺形态闸"
        assert "size: int = Query(50, ge=1, le=500)" in seg, f"/jfvip/{tab} 的 size 缺形态闸"


def test_all_list_pages_share_the_same_frontend_invariants():
    """前端三处必备性质:消费封顶标记、导出前冻结快照、渲染分页条。

    「订单/流水」在源码里是同一段分支(isOrd 二选一),故按**渲染分支**切片:
    cards 分支一段、orders/grants 合用一段 —— 两段都必须齐全。
    """
    js = js_code(APP.parent.parent / "assets" / "admin.js")
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    cards = seg[seg.index("if (JV.tab === 'cards')"):seg.index("if (JV.tab === 'orders'")]
    lists = seg[seg.index("if (JV.tab === 'orders'"):seg.index("body.innerHTML = `\n    <div class=\"card\">\n      <h3>用户 VIP 状态</h3>")]
    for label, part in (("卡密", cards), ("订单/流水", lists)):
        assert "totalCapped" in part, f"{label}页未消费 totalCapped(会把封顶值当精确总数)"
        assert "Object.assign({}," in part, f"{label}页导出未冻结筛选快照(CSV 会混两套条件)"
        assert "jvPager(d)" in part, f"{label}页未渲染分页条"
        assert "jvBindPager(" in part, f"{label}页未绑定翻页回调"
        assert "jvRestorePagerFocus(" in part, f"{label}页翻页后未归还焦点"
        assert "JV._refocusPager = ''" in part, f"{label}页错误分支未清焦点标志"


# ══════════════════════════════════════════════════════════════════════════════
# 4.2.7 · 卡密前缀 JF → TL
# ══════════════════════════════════════════════════════════════════════════════
def test_card_prefix_is_tl_and_legacy_jf_still_redeemable():
    """新卡发 TL,**JF 存量卡仍可兑换**。

    改前缀时库里已有 JF 卡,**已经发到渠道和用户手上的未兑换卡更是收不回来**。
    若把形态闸收紧成只认 TL,这些卡会在下一次兑换时被当场拒掉 —— 用户拿着花钱
    买的卡兑不了,是资损与客诉,且没有任何补救手段(卡已经发出去了)。
    这条钉子防的正是「后人看到 CARD_PREFIX_LEGACY 觉得多余、顺手删掉」。
    """
    from app import jfvip as j
    assert j.CARD_PREFIX == "TL", "新发卡前缀应为 TL"
    assert "JF" in j.CARD_PREFIX_LEGACY, "删掉 JF 历史前缀会让存量卡全部作废"
    # 生成侧:只出 TL
    assert all(j.gen_card_no().startswith("TL") for _ in range(50))
    # 兑换侧:两种都认
    assert j.card_valid_shape("TLABCDEF234567")
    assert j.card_valid_shape("JFABCDEF234567"), "存量 JF 卡被形态闸拒掉 = 资损"
    # 其它前缀仍须拒绝(别把闸开成谁都能进)
    assert not j.card_valid_shape("XYABCDEF234567")
    assert not j.card_valid_shape("ABCDEF234567")
    # 排除字符集不受前缀改动影响
    assert not j.card_valid_shape("TLABCDEI234567"), "字母 I 应被排除"
    assert not j.card_valid_shape("TLABCDEF234560"), "数字 0 应被排除"
    # 提示只报新前缀 —— 不该再教用户去输历史前缀
    assert j.card_shape_hint("XYABCDEF234567") == "卡密应以 TL 开头,请核对"


def test_card_regex_is_derived_from_constants_not_hardcoded():
    """正则必须由常量拼出,不能再手写一遍字面量。

    原实现把前缀与字符集在正则里硬编码了第二遍(`^JF[ABC…]{6}[23…]{6}$`),
    改前缀时极易只改 CARD_PREFIX、正则忘了改 —— 于是「生成 TL、校验只认 JF」,
    新发的卡当场全部兑不了,而单元测试若只测生成侧还查不出来。
    """
    src = py_code(APP / "jfvip.py")
    assert 'r"^JF[' not in src and 'r"^TL[' not in src, "正则里又出现硬编码字面量"
    assert '"|".join(_CARD_PREFIXES)' in src, "正则未从前缀常量拼出"
    assert "CARD_ALPHABET, CARD_ALPHA_N" in src, "正则未从字符集常量拼出"


def test_docs_and_ddl_follow_the_new_card_prefix():
    """DDL 注释与文档必须跟着改 —— 文档撒谎和代码有 bug 一样有害。

    建表语句在 userauth.py 与 scripts/init_userdb.sql **各有一份**,
    只改一处会让两边说法不一致。
    """
    root = APP.parent.parent
    for f in (APP / "userauth.py", APP.parent / "scripts" / "init_userdb.sql"):
        t = f.read_text(encoding="utf-8")
        assert "TL+6字母+6数字" in t, f"{f.name} 的 card 列注释仍写着旧前缀"
        assert "JF 为历史前缀" in t, f"{f.name} 未说明 JF 仍可兑换"
    doc = (root / "JFVIP-SYSTEM.md").read_text(encoding="utf-8")
    assert "格式 `TL` + 6 大写字母" in doc, "文档仍写着旧前缀"
    assert "仍可兑换" in doc, "文档未说明存量 JF 卡的处置"
