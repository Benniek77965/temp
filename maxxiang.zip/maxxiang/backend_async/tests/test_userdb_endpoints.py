"""
test_userdb_endpoints.py — 用户库多网络入口(4.5.0)
================================================================================
两层,与 test_userauth.py 同款姿态:
  · **纯单元(恒跑,零外部依赖)**:入口串解析 / 错误归类 / 只读语句判定 /
    连接预算摊分 / P2C 选路 —— 这几条是「不会把好入口误杀、不会把坏入口留下、
    不会把写语句重发两次」的全部依据,必须在任何环境下都被钉住。
  · **联测(需本地用户库 127.0.0.1:3307)**:同一实例的多个**回环别名**
    (127.0.0.1 / 127.0.0.2 / 127.0.0.3)天然构成「同一逻辑库的多网络入口」,
    与生产「一台 MySQL 绑多个弹性 IP」拓扑同构。据此实测:分流是否真的铺开、
    坏入口能否自动摘除、恢复后能否自动收回、身份不符能否当场识破。

不可达则整层 skip(CI/无库环境不误伤)。默认部署(未配 STA_USERDB_HOST)下登录
系统关闭,本模块的联测层与生产行为无关。
"""
from __future__ import annotations

import asyncio
import os
import socket
import sys

import pytest
import pytest_asyncio

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import userauth, userdb_pool  # noqa: E402
from app.settings import UserAuthCfg   # noqa: E402

_HOST = os.environ.get("STA_TEST_USERDB_HOST", "127.0.0.1")
_PORT = int(os.environ.get("STA_TEST_USERDB_PORT", "3307"))
_DB = "fanxing_changkong_user_db"
_USER, _PASS = "fanxing_admin", "fanxing_admin,."
# 第二实例(server_id 不同)用于「身份不符必须被识破」那条;缺席则该条 skip。
_ALT_PORT = int(os.environ.get("STA_TEST_USERDB_ALT_PORT", "3308"))


def _up(host: str, port: int) -> bool:
    try:
        with socket.create_connection((host, port), timeout=0.6):
            return True
    except OSError:
        return False


needs_db = pytest.mark.skipif(not _up(_HOST, _PORT),
                              reason=f"需要本地用户库 {_HOST}:{_PORT}")
needs_alt = pytest.mark.skipif(not _up(_HOST, _ALT_PORT),
                               reason=f"需要第二实例 {_HOST}:{_ALT_PORT}(身份不符用例)")


# ══ 纯单元 ════════════════════════════════════════════════════════════════════
def test_parse_single_value_is_exactly_one_endpoint():
    """单值 = 恰好一个入口 —— 这是「升级零行为变化」的字面依据。"""
    assert userdb_pool.parse_endpoints("120.79.26.174", 3306) == \
        [("120.79.26.174", 3306, 1.0)]
    assert userdb_pool.parse_endpoints("  120.79.26.174  ", 3306) == \
        [("120.79.26.174", 3306, 1.0)]


def test_parse_list_port_and_weight():
    got = userdb_pool.parse_endpoints("1.1.1.1, 2.2.2.2:3307*2 ;3.3.3.3*0.5", 3306)
    assert got == [("1.1.1.1", 3306, 1.0), ("2.2.2.2", 3307, 2.0), ("3.3.3.3", 3306, 0.5)]


def test_parse_tolerates_chinese_separators_and_dedups():
    """中文逗号/顿号是从文档粘贴时的高频差错;重复入口不该变成两个池。"""
    got = userdb_pool.parse_endpoints("1.1.1.1，2.2.2.2、1.1.1.1*3", 3306)
    assert got == [("1.1.1.1", 3306, 3.0), ("2.2.2.2", 3306, 1.0)]


def test_parse_reports_bad_tokens_instead_of_swallowing():
    """**没变成入口的片段必须被点名** —— 静默跳过等于让运维对着一个少了入口的
    系统毫无线索。包括「格式对但取值非法」的(端口越界、权重为 0)。"""
    raw = "1.1.1.1, 2.2.2.2:99999, 3.3.3.3*0, 4.4.4.4:3307*2"
    # 端口越界 → 地址不可用,丢弃;权重写坏 → 地址是好的,入口保留、权重按 1 计
    # (为一个权重笔误就把运维明明想要的 IP 整个扔掉,是过度惩罚)
    assert userdb_pool.parse_endpoints(raw, 3306) == \
        [("1.1.1.1", 3306, 1.0), ("3.3.3.3", 3306, 1.0), ("4.4.4.4", 3307, 2.0)]
    # 两类都必须被点名,不许静默
    assert sorted(userdb_pool.bad_tokens(raw)) == ["2.2.2.2:99999", "3.3.3.3*0"]


def test_ipv6_bracket_form():
    assert userdb_pool.parse_endpoints("[2001:db8::1]:3307", 3306) == \
        [("[2001:db8::1]", 3307, 1.0)]


def test_transport_vs_server_error_classification():
    """**最要命的一条**:服务端错(errno<2000)绝不能拿来熔断入口。

    所有入口指向同一个库 —— 拿「口令错 1045 / 连接数超限 1040 / 死锁 1213」
    去熔断,会把全部入口一起打死,把「一条语句失败」放大成「登录系统整体不可用」。
    """
    import aiomysql
    assert userdb_pool.is_transport_error(aiomysql.OperationalError(2006, "gone away"))
    assert userdb_pool.is_transport_error(aiomysql.OperationalError(2013, "lost"))
    assert userdb_pool.is_transport_error(aiomysql.OperationalError(2003, "can't connect"))
    assert userdb_pool.is_transport_error(asyncio.TimeoutError())
    assert userdb_pool.is_transport_error(OSError("unreachable"))
    assert userdb_pool.is_transport_error(aiomysql.InterfaceError("closed"))
    # —— 以下一律不算入口的错 ——
    assert not userdb_pool.is_transport_error(aiomysql.OperationalError(1045, "denied"))
    assert not userdb_pool.is_transport_error(aiomysql.OperationalError(1040, "too many"))
    assert not userdb_pool.is_transport_error(aiomysql.OperationalError(1213, "deadlock"))
    assert not userdb_pool.is_transport_error(aiomysql.ProgrammingError(1064, "syntax"))
    assert not userdb_pool.is_transport_error(aiomysql.IntegrityError(1062, "dup"))


def test_read_only_sql_detection_gates_retry():
    """已送出的语句只有只读的才敢重发(重发 INSERT 可能写两行)。"""
    assert userdb_pool.is_read_only_sql("SELECT 1")
    assert userdb_pool.is_read_only_sql("  \n select a from b")
    assert userdb_pool.is_read_only_sql("SHOW FULL COLUMNS FROM `tb_user`")
    assert userdb_pool.is_read_only_sql("/* hint */ SELECT 1")
    assert not userdb_pool.is_read_only_sql("INSERT INTO t VALUES (1)")
    assert not userdb_pool.is_read_only_sql("UPDATE t SET a=1")
    assert not userdb_pool.is_read_only_sql("DELETE FROM t")
    # 「SELECT … FOR UPDATE」仍是读,但它只出现在手工事务里(不走 _q),
    # 这里只需确认判定本身不会把 UPDATE 误判成读。
    assert not userdb_pool.is_read_only_sql("update t set a=1 where b='select'")


def test_connection_budget_is_split_not_multiplied():
    """总连接预算摊到各入口,且每入口至少 2 条(1 条会被一条慢查询队头阻塞)。"""
    mk = lambda host, mx: userdb_pool.Router(  # noqa: E731
        UserAuthCfg(host=host, db="d", user="u"), pool_max=mx, log=lambda *a: None)
    assert mk("1.1.1.1", 8).per_pool_max == 8                     # 单入口:原样
    assert mk("1.1.1.1,2.2.2.2", 8).per_pool_max == 4
    assert mk("1.1.1.1,2.2.2.2,3.3.3.3", 8).per_pool_max == 3     # ceil(8/3)
    assert mk("1.1.1.1,2.2.2.2,3.3.3.3,4.4.4.4,5.5.5.5", 8).per_pool_max == 2
    assert mk("1.1.1.1,2.2.2.2", 64).per_pool_max == 32


def test_p2c_prefers_less_loaded_and_respects_weight():
    r = userdb_pool.Router(UserAuthCfg(host="1.1.1.1,2.2.2.2", db="d", user="u"),
                           log=lambda *a: None)
    a, b = r.endpoints
    a.state = b.state = "up"
    a.inflight, b.inflight = 10, 0
    assert all(r.pick() is b for _ in range(20))       # 只有两个入口 → 必取更闲的
    # 权重:在飞数相同时,权重大的分数更低(更优)
    a.inflight = b.inflight = 4
    a.weight, b.weight = 4.0, 1.0
    assert a.score() < b.score()


def test_quarantined_endpoint_is_excluded_and_mismatch_is_permanent():
    import time as _t
    r = userdb_pool.Router(UserAuthCfg(host="1.1.1.1,2.2.2.2", db="d", user="u"),
                           log=lambda *a: None)
    a, b = r.endpoints
    a.state = b.state = "up"
    a.mark_fail(OSError("boom"))
    assert a.state == "down" and a.down_until > _t.monotonic()
    assert all(r.pick() is b for _ in range(10))       # 熔断入口不参与分流
    # 身份不符 = 终态:普通失败/成功都不该把它改回来
    b.mark_mismatch("identity")
    b.mark_ok(1.0)
    assert b.state == "mismatch"
    assert not b.usable(_t.monotonic())
    assert r.pick() is None                            # 全不可用 → 由调用方兜底
    assert r._fallback() is a                          # 兜底只在非 mismatch 里挑


def test_backoff_is_bounded():
    """连败退避有上界 —— 坏入口不会被无限期放逐到「永不重试」。"""
    r = userdb_pool.Router(UserAuthCfg(host="1.1.1.1", db="d", user="u"),
                           log=lambda *a: None)
    ep = r.endpoints[0]
    import time as _t
    for _ in range(30):
        ep.mark_fail(OSError("x"))
    assert ep.down_until - _t.monotonic() <= max(userdb_pool._BREAK_STEPS) + 1


# ══ 联测(真库)══════════════════════════════════════════════════════════════
def _cfg(host: str, **kw) -> UserAuthCfg:
    base = dict(host=host, port=_PORT, db=_DB, user=_USER, password=_PASS,
                charset="gbk", cache_ttl_s=0.0, probe_s=1.0,
                login_fail_user=10000, login_fail_ip=10000)
    base.update(kw)
    return UserAuthCfg(**base)


@pytest_asyncio.fixture()
async def ua_env():
    async def _setup(cfg: UserAuthCfg):
        await userauth.init(cfg, None)
        assert userauth.UA.schema_ok or await userauth._ensure_schema()
    yield _setup
    await userauth.close()
    userauth.UA.cfg = None
    userauth.UA.cache = {}
    userauth.UA.schema_ok = False


@needs_db
@pytest.mark.asyncio
async def test_single_endpoint_behaves_exactly_as_before(ua_env):
    """单值配置:一个入口、查询照常、快照如实 —— 升级零行为变化的实证。"""
    await ua_env(_cfg(_HOST))
    r = userauth.UA.router
    assert len(r.endpoints) == 1 and r.per_pool_max == 8
    assert (await userauth._q("SELECT 1 AS x", fetch="one"))["x"] == 1
    snap = r.snapshot()
    assert snap["total"] == 1 and snap["usable"] == 1
    assert snap["endpoints"][0]["queriesOk"] >= 1


@needs_db
@pytest.mark.asyncio
async def test_multi_endpoint_spreads_queries_and_meters_bytes(ua_env):
    """三个回环别名 = 同一实例的三个网络入口:并发查询必须**真的铺开**,
    且每入口的收发字节都被如实计到(这是验证带宽是否叠加的唯一硬证据)。"""
    await ua_env(_cfg(f"{_HOST},127.0.0.2,127.0.0.3"))
    r = userauth.UA.router
    assert len(r.endpoints) == 3 and r.per_pool_max == 3
    await asyncio.gather(*[userauth._q("SELECT REPEAT('x', 4096) AS b", fetch="one")
                           for _ in range(60)])
    used = [e for e in r.endpoints if e.q_ok > 0]
    assert len(used) == 3, f"查询没有铺开:{[(e.name, e.q_ok) for e in r.endpoints]}"
    assert all(e.bytes_in > 4096 and e.bytes_out > 0 for e in used), \
        "字节计量没生效(驱动收发收口可能改名了)"
    assert all(e.inflight == 0 for e in r.endpoints), "在飞计数没有归零(泄漏)"


@needs_db
@pytest.mark.asyncio
async def test_dead_endpoint_is_detected_and_traffic_keeps_flowing(ua_env):
    """混入一个死入口:查询**一条都不能失败**(自动绕开),且它会被摘除。"""
    await ua_env(_cfg(f"{_HOST},127.0.0.9:1,127.0.0.2"))
    r = userauth.UA.router
    for _ in range(30):
        assert (await userauth._q("SELECT 1 AS x", fetch="one"))["x"] == 1
    dead = [e for e in r.endpoints if e.port == 1][0]
    assert dead.state == "down" and dead.q_ok == 0
    alive = [e for e in r.endpoints if e.port == _PORT]
    assert sum(e.q_ok for e in alive) >= 30


@needs_db
@pytest.mark.asyncio
async def test_endpoint_recovers_automatically_after_probe(ua_env):
    """人为熔断一个入口 → 探活在冷却到期后应把它自动收回(无需重启)。"""
    await ua_env(_cfg(f"{_HOST},127.0.0.2", probe_s=0.5))
    r = userauth.UA.router
    ep = r.endpoints[1]
    ep.mark_fail(OSError("模拟公网瞬断"))
    assert ep.state == "down"
    ep.down_until = 0.0                       # 冷却立即到期,等探活那一拍
    for _ in range(40):
        await asyncio.sleep(0.25)
        if ep.state == "up":
            break
    assert ep.state == "up", "熔断入口没有被探活自动收回"
    assert ep.identity.get("hostname") is not None or ep.probes > 0


@needs_db
@pytest.mark.asyncio
async def test_query_timeout_does_not_poison_the_pool(ua_env):
    """超时的连接必须被销毁而不是还池 —— 否则下一个使用者会读到上一条查询的
    残包(半个结果集还在 socket 缓冲里),是最难查的一类脏数据。"""
    await ua_env(_cfg(_HOST, query_timeout_s=1.0))
    with pytest.raises(Exception):
        await userauth._q("SELECT SLEEP(5)", fetch="one")
    # 池没被污染:紧接着的查询必须拿到**自己**的结果
    for _ in range(5):
        assert (await userauth._q("SELECT 42 AS x", fetch="one"))["x"] == 42
    ep = userauth.UA.router.endpoints[0]
    assert ep.inflight == 0


@needs_db
@pytest.mark.asyncio
async def test_server_side_error_never_quarantines_endpoints(ua_env):
    """语法错这类服务端错误:原样上抛,且**一个入口都不许被摘**。"""
    await ua_env(_cfg(f"{_HOST},127.0.0.2"))
    r = userauth.UA.router
    with pytest.raises(Exception):
        await userauth._q("SELECT * FROM 这张表不存在", fetch="one")
    assert all(e.state != "down" for e in r.endpoints), \
        "服务端错误把入口熔断了 —— 会把所有入口一起打死"


@needs_db
@needs_alt
@pytest.mark.asyncio
async def test_identity_mismatch_endpoint_is_quarantined(ua_env):
    """**多入口正确性的地基**:某个 IP 若通向另一个库,必须当场识破并永久隔离。

    不隔离的后果是静默写坏:会话写到 A 库、复核查 B 库,用户表现为「刚登录就掉线」,
    而订单/开通更会直接对不上账。
    """
    # 配置顺序即优先级:主入口写在第一位。两个入口互不相同时没有多数派,
    # 按「配置靠前者为基准」裁定 —— 这条必须是确定性的,不能是「谁先答谁赢」。
    await ua_env(_cfg(f"{_HOST},{_HOST}:{_ALT_PORT}", probe_s=0.5))
    r = userauth.UA.router
    alt = [e for e in r.endpoints if e.port == _ALT_PORT][0]
    for _ in range(40):
        await asyncio.sleep(0.25)
        if alt.state == "mismatch":
            break
    assert alt.state == "mismatch" and alt.reason == "identity", \
        f"异库入口没被识破:state={alt.state} identity={alt.identity}"
    # 隔离之后,查询仍必须能跑(走剩下的正确入口)
    for _ in range(10):
        assert (await userauth._q("SELECT 1 AS x", fetch="one"))["x"] == 1
    assert alt.q_ok == 0


def test_identity_reconcile_is_majority_then_config_order():
    """身份基准的裁定必须**确定性**:多数派优先,平局按配置顺序。

    第一版写的是「谁先答谁当基准」,而探活是并发的 —— 实测出现过「真正的主库
    因为慢了几毫秒被判成异库、错的那个反倒成了基准」。这条用例就是那次的回归钉。
    """
    mk = lambda hosts: userdb_pool.Router(  # noqa: E731
        UserAuthCfg(host=hosts, db="d", user="u"), log=lambda *a: None)
    good = {"server_id": "1", "hostname": "db-a", "version": "5.7.44"}
    bad = {"server_id": "9", "hostname": "db-b", "version": "5.7.44"}

    # ① 三入口、一个填错 → 多数派胜,不管探测顺序如何
    r = mk("1.1.1.1,2.2.2.2,3.3.3.3")
    r.endpoints[0].identity = bad          # 错的那个恰好排第一、也先答
    r.endpoints[1].identity = good
    r.endpoints[2].identity = good
    r._reconcile_identity()
    assert [e.state for e in r.endpoints] == ["mismatch", "new", "new"]
    assert r.ref_from == "2.2.2.2:3306"

    # ② 两入口互不相同 → 无多数派,取配置靠前者为基准(确定性)
    r = mk("1.1.1.1,2.2.2.2")
    r.endpoints[0].identity = good
    r.endpoints[1].identity = bad
    r._reconcile_identity()
    assert r.endpoints[0].state != "mismatch" and r.endpoints[1].state == "mismatch"

    # ③ 单入口 → 无从比较,永不隔离
    r = mk("1.1.1.1")
    r.endpoints[0].identity = bad
    r._reconcile_identity()
    assert r.endpoints[0].state != "mismatch"

    # ④ 误判可平反:指纹与多数派一致的入口会被重新纳入分流
    r = mk("1.1.1.1,2.2.2.2,3.3.3.3")
    for e in r.endpoints:
        e.identity = good
    r.endpoints[0].mark_mismatch("identity")
    r._reconcile_identity()
    assert r.endpoints[0].state == "up"


# ══ 回归钉:4.5.0 开发期实际踩到的两个坑 ═══════════════════════════════════════
@needs_db
@pytest.mark.asyncio
async def test_stale_connection_is_still_rescued_on_single_endpoint(ua_env):
    """**单入口时,第一拍炸掉的查询必须仍被自动救回。**

    4.4.x 的 `for attempt in (0, 1)` 就是为「公网 NAT 掐了空闲长连、第一拍必炸」
    准备的。4.5.0 第一版把重试预算写成 `min(3, 入口数)`,单入口(= 今天的生产
    配置)只剩 1 次 —— 实测:原始代码 execute 被调 2 次并成功,那一版只调 1 次
    就抛错,等于把「一次公网瞬断」变成「一次登录 503」。这条用例把它钉死。
    """
    import aiomysql
    await ua_env(_cfg(_HOST))
    assert len(userauth.UA.router.endpoints) == 1
    calls = {"n": 0}
    real = aiomysql.cursors.DictCursor.execute

    async def flaky(self, sql, args=None):
        calls["n"] += 1
        if calls["n"] == 1:
            raise aiomysql.OperationalError(2006, "MySQL server has gone away")
        return await real(self, sql, args)

    aiomysql.cursors.DictCursor.execute = flaky
    try:
        assert (await userauth._q("SELECT 1 AS x", fetch="one"))["x"] == 1
        assert calls["n"] == 2, "没有重试 —— 陈旧连接会直接变成登录 503"
    finally:
        aiomysql.cursors.DictCursor.execute = real


@needs_db
@pytest.mark.asyncio
async def test_transaction_pool_facade_supports_both_acquire_styles(ua_env):
    """`_ensure_pool()` 回的包装必须同时支持两种写法 —— 三处事务用
    `await pool.acquire()`,而 `_ensure_schema` 用 `async with pool.acquire()`。
    只支持一种会让建表或事务当场炸,且只在真库路径上才暴露。"""
    await ua_env(_cfg(f"{_HOST},127.0.0.2"))
    pool = await userauth._ensure_pool()
    assert pool
    conn = await pool.acquire()                 # 形态一:事务用
    try:
        async with conn.cursor() as cur:
            await cur.execute("SELECT 1")
            assert (await cur.fetchone())[0] == 1
    finally:
        pool.release(conn)
    pool2 = await userauth._ensure_pool()
    async with pool2.acquire() as conn2:        # 形态二:建表用
        async with conn2.cursor() as cur:
            await cur.execute("SELECT 2")
            assert (await cur.fetchone())[0] == 2
    assert all(e.inflight == 0 for e in userauth.UA.router.endpoints), \
        "包装层的在飞计数没有配平(泄漏)"


def test_pool_facade_only_proxies_what_transactions_actually_use():
    """包装层刻意不做万能代理:用到没代理的属性应当当场炸,而不是悄悄绕过。"""
    r = userdb_pool.Router(UserAuthCfg(host="1.1.1.1", db="d", user="u"),
                           log=lambda *a: None)
    ep = r.endpoints[0]
    ep.pool = object()
    f = userdb_pool._PoolFacade(r, ep)
    assert bool(f) and hasattr(f, "acquire") and hasattr(f, "release")
    with pytest.raises(AttributeError):
        _ = f.maxsize


def test_all_bad_tokens_never_fails_silently():
    """**IP 全填错时必须大声报错。**

    第一版把「无法解析的片段」告警放在 `not self.endpoints` 的早退之后,于是这个
    最需要提示的情形反而一个字都不打 —— 横幅还照样说「连接池就绪(入口 0 个)」,
    运维只看到莫名其妙的 503(开发期实测复现)。
    """
    said = []
    r = userdb_pool.Router(
        UserAuthCfg(host="1.2.3.4:99999, 5.6.7.8:88888", db="d", user="u"),
        log=said.append)
    assert r.endpoints == []
    asyncio.get_event_loop_policy().new_event_loop().run_until_complete(r.start())
    joined = "\n".join(said)
    assert "1.2.3.4:99999" in joined and "5.6.7.8:88888" in joined, "坏片段没被点名"
    assert "任何" in joined or "⛔" in joined, "0 入口没有大声报错"


def test_snapshot_is_json_serializable_even_when_quarantined():
    """管理台端点直接把 snapshot() 塞进 JSONResponse —— 里面若混进 inf/NaN,
    产出的就是**非法 JSON**(json.dumps 会写 Infinity),前端解析当场炸。
    mark_mismatch 把 down_until 设成 inf,这条专门盯住它不要漏出去。"""
    import json
    import math
    r = userdb_pool.Router(UserAuthCfg(host="1.1.1.1,2.2.2.2", db="d", user="u"),
                           log=lambda *a: None)
    r.endpoints[0].mark_mismatch("identity")
    r.endpoints[1].mark_fail(OSError("x"))
    snap = r.snapshot()
    text = json.dumps(snap, allow_nan=False)          # allow_nan=False:有 inf 就抛
    assert "Infinity" not in text and "NaN" not in text
    for ep in snap["endpoints"]:
        for k, v in ep.items():
            assert not (isinstance(v, float) and (math.isinf(v) or math.isnan(v))), k


@needs_db
@needs_alt
@pytest.mark.asyncio
async def test_identity_is_verified_even_under_constant_load(ua_env):
    """**持续流量下,入口也必须被身份校验。**

    第一版探活里有一句"健康且刚刚有过成功查询就跳过,省一次公网往返"。实测这是个洞:
    一个入口若是靠『查询成功』恢复的(而不是靠探活),持续流量下 last_ok 永远新鲜,
    这一拍就永远被跳过 → 身份指纹永远拿不到 → 永远不参与「是不是同一个库」的投票。
    复现结果:异库入口 8 秒内服务了 4777 次查询、probes=0、identity 为空 ——
    一个填错的 IP 只要一直有流量就永不被识破。这条用例把修复钉死。
    """
    await ua_env(_cfg(f"{_HOST},{_HOST}:{_ALT_PORT}", probe_s=0.5))
    r = userauth.UA.router
    bad = [e for e in r.endpoints if e.port == _ALT_PORT][0]
    # 人为造出「靠查询恢复、身份未知」的状态
    bad.state, bad.identity, bad.probes, bad.last_ident = "up", {}, 0, 0.0
    bad.down_until = 0.0
    r.identity_ref, r.ref_from = {}, ""

    stop = False

    async def load():
        while not stop:
            with contextlib_suppress():
                await userauth._q("SELECT 1 AS x", fetch="one")
            await asyncio.sleep(0.005)

    tasks = [asyncio.create_task(load()) for _ in range(8)]
    try:
        for _ in range(40):
            await asyncio.sleep(0.25)
            if bad.state == "mismatch":
                break
    finally:
        stop = True
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
    assert bad.identity, "持续流量下入口的身份指纹从未被取到"
    assert bad.state == "mismatch", "异库入口在持续流量下没被识破"


class contextlib_suppress:
    """本文件内的小工具:吞掉负载协程里的任何异常(它们不是被测对象)。"""

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return True


def test_probe_skip_requires_known_and_fresh_identity():
    """跳过探活的条件必须是「身份已知 且 未到复验期 且 最近有成功查询」三者同时成立。"""
    import time as _t
    r = userdb_pool.Router(UserAuthCfg(host="1.1.1.1", db="d", user="u"),
                           log=lambda *a: None)
    ep = r.endpoints[0]
    now = _t.monotonic()
    ep.state, ep.last_ok = "up", now

    def skips():
        need = (not ep.identity) or (now - ep.last_ident) >= userdb_pool._IDENT_REVERIFY_S
        return ep.state == "up" and not need and (now - ep.last_ok) < r.probe_s

    ep.identity, ep.last_ident = {}, 0.0
    assert not skips(), "身份未知时不得跳过探活(这正是那个洞)"
    ep.identity, ep.last_ident = {"server_id": "1"}, now
    assert skips(), "身份已知且新鲜、又刚用过 → 应当跳过,省一次公网往返"
    ep.last_ident = now - userdb_pool._IDENT_REVERIFY_S - 1
    assert not skips(), "到了复验期必须重新核身份(IP 可能已被换绑到别的实例)"
