"""
test_static_allowlist.py — 静态兜底只对外提供前端构建产物(5.3.0 复查补漏)
================================================================================
实测:后端 README 的裸机运行方式把 STA_STATIC_DIR 指向仓库根,此时 /backend_async/deploy/.env
(全部口令与密钥)、deploy/kgdata/accounts.json、config.yaml 全部 200 可下载。
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import web  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BACKEND = os.path.join(ROOT, "backend_async")


def test_public_static_predicate(tmp_path):
    base = str(tmp_path)
    ok = ["index.html", "sw.js", "favicon.ico", "favicon.png", "manifest.webmanifest",
          "assets/app.js", "jiufa/index.html", "mock/a/b.json", "cdn/x.js", "icons/i.png"]
    bad = ["admin.html", "README.md", "backend_async/config.yaml", "backend_async/deploy/.env",
           "backend_async/deploy/kgdata/accounts.json", ".env", ".git/config", "assets/.hidden",
           "jiufa_data/spell_tamer_monitor.py", "deploy-maxxiang.sh", "package.json", "x/index.html"]
    for rel in ok:
        assert web._is_public_static(base, os.path.join(base, rel)), rel
    for rel in bad:
        assert not web._is_public_static(base, os.path.join(base, rel)), rel


def test_allowlist_matches_what_the_dockerfile_ships():
    """白名单必须与 deploy/Dockerfile 前端构建阶段打进镜像的清单一致(admin.html 除外:它只从入口路径进)。"""
    df = open(os.path.join(BACKEND, "deploy", "Dockerfile"), encoding="utf-8").read()
    stage = df.split("AS fe-build", 1)[1].split("\nFROM ", 1)[0]
    files = set()
    for m in re.finditer(r"^COPY ([^\n]+) \./\s*$", stage, re.M):
        files |= {f for f in m.group(1).split() if "." in f and not f.endswith(".json") and not f.endswith(".mjs")}
    dirs = set(re.findall(r"^COPY (\w+) +\./\1\s*$", stage, re.M))
    assert files - {"admin.html"} == set(web._PUBLIC_STATIC_FILES), files
    assert dirs == set(web._PUBLIC_STATIC_DIRS), dirs


_PROBE = r"""
import asyncio, json, os, sys
sys.path.insert(0, os.getcwd())
import httpx
from app import web
async def main():
    out = {}
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=web.app), base_url="http://t") as c:
        for p in sys.argv[1:]:
            r = await c.get(p)
            out[p] = [r.status_code, r.headers.get("content-type", ""), r.text]
    print(json.dumps(out))
asyncio.run(main())
"""


def test_repo_shaped_static_root_leaks_nothing(tmp_path):
    """★ 静态根 = 仓库形态(README 的裸机运行方式):敏感文件与不存在的路径应答逐字节相同,前端产物照常可取。"""
    root = tmp_path / "repo"
    files = {
        "index.html": "<!doctype html><title>SPA-SHELL</title>", "sw.js": "self.x=1", "favicon.png": "PNG",
        "manifest.webmanifest": "{}", "assets/app.js": "console.log(1)",
        "backend_async/deploy/.env": "STA_ADMIN_PASSWORD=TOP-SECRET", "backend_async/config.yaml": "admin:\n  path: SECRET-ENTRY\n",
        "backend_async/deploy/kgdata/accounts.json": '{"secret": "KG-SECRET"}', ".git/config": "[core] GIT-SECRET",
        "README.md": "README-TEXT", "jiufa_data/spell_tamer_monitor.py": "ENGINE-SOURCE",
    }
    for rel, body in files.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(body, encoding="utf-8")
    env = {k: v for k, v in os.environ.items() if not k.startswith("STA_")}
    env.update({"STA_STATIC_DIR": str(root), "STA_ADMIN_PASSWORD": "pw", "PYTHONIOENCODING": "utf-8"})
    probes = ["/backend_async/deploy/.env", "/backend_async/config.yaml", "/backend_async/deploy/kgdata/accounts.json",
              "/.git/config", "/README.md", "/jiufa_data/spell_tamer_monitor.py", "/zq-none.txt",
              "/index.html", "/sw.js", "/favicon.png", "/manifest.webmanifest", "/assets/app.js"]
    p = subprocess.run([sys.executable, "-c", _PROBE, *probes], cwd=BACKEND, env=env,
                       capture_output=True, text=True, encoding="utf-8", timeout=120)
    assert p.returncode == 0, p.stderr[-2000:]
    out = json.loads(p.stdout.strip().splitlines()[-1])
    unknown = out["/zq-none.txt"]
    assert "SPA-SHELL" in unknown[2]
    for path in probes[:6]:
        assert out[path] == unknown, (path, out[path][0], out[path][2][:60])
    blob = json.dumps(out)
    for secret in ("TOP-SECRET", "SECRET-ENTRY", "KG-SECRET", "GIT-SECRET", "README-TEXT", "ENGINE-SOURCE"):
        assert secret not in blob, secret
    assert out["/sw.js"][2] == "self.x=1" and out["/favicon.png"][2] == "PNG"
    assert out["/manifest.webmanifest"][2] == "{}" and out["/assets/app.js"][2] == "console.log(1)"
