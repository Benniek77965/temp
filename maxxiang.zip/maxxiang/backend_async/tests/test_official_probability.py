"""
test_official_probability.py — 官方出怪概率基线的前后端契约
================================================================================
本文件守的是一个**静默失真**:它不报错、不缺图、不白屏,只会让观测台给出一个
看起来很专业的错误结论。所以只能靠测试钉住,靠肉眼是发现不了的。

── 缺陷原貌(4.x 前)────────────────────────────────────────────────────────
`web._load_spells_template()` 读不到 mock/data/room-321-config.json 时走妖兽表
兜底,而妖兽表里**没有概率**,于是兜底把 `probability` 填成空串 `""`。
前端 `assets/app.js::officialProb()` 对解不出的值回落均匀 `100/9 ≈ 11.11%`,
而真实概率极不均匀(20/16/16/16/10/10/6.5/3.5/2),后果是:

  ① 出怪司历「官方」列显 11.1%、「偏差」= 实际占比 − 11.1,再按
     σ=√(p(1−p)/N) 做 2σ 着色。24h 满窗(N≈1727)下 **九个号里有七个**被判
     "显著":号位1 恒 +8.9pp 判偏热、号位9 恒 −9.1pp 判偏冷 —— 全是基线错,
     与盘面无关;
  ② 九法阵出怪规律态 `stateOf` 的周期 cycle=round(100/p) 从 5 变 9:号位1 连空
     13 局本该「极冷」,却要拖到 23 局才变色。

── 三道守卫 ────────────────────────────────────────────────────────────────
一、**唯一真源对拍**:constants.OFFICIAL_PROBABILITY 必须与
    mock/data/room-321-config.json 逐项相等。两处任一被改而另一处没跟上当场红。
二、**兜底路径信息完整**:两条加载路径产出的 probability 都必须"前端能解出数"。
    这是缺陷本身的形状 —— 后端认为"有值"而前端解不出。
三、**跨语言活体对拍**(装了 node 才跑):直接从 app.js 抠出 officialProb 执行,
    喂后端**真实**的兜底产物,断言它解出真概率、且**不等于** 100/9。
    抠源码而非复制粘贴 —— 复制粘贴会让本测试对着自己的副本自证。
"""
from __future__ import annotations

import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

# 导入方式与本目录既有测试(test_jfvip_contract / _discipline / _sse)保持一致:
# **不自己插 sys.path**，靠 conftest.py 已插入的 backend_async，用包限定名导入。
# 初版写成 `sys.path.insert(0, tests目录)` + 裸 `import _srcscan`，实测两个坏处:
#   ① 屏蔽:tests/ 一旦进 sys.path[0]，此后任何 `tests/x.py` 都会顶掉同名标准库
#      模块，且影响**整个测试会话**(已实证:加一个 tests/wave.py，`import wave`
#      就解析到它而不是 stdlib) —— 这类故障远看根本联想不到是某个测试干的;
#   ② 双实例:`_srcscan` 与 `tests._srcscan` 会同时存在于 sys.modules 且
#      `is` 为 False。本模块无状态所以眼下无害，但这正是以后出怪事的种子。
from tests._srcscan import strip_js_comments   # 仓库统一的「扫源码前先剥注释」助手

from app.constants import (BEASTS_BASE, OFFICIAL_PROBABILITY,
                           build_beast_meta, fmt_probability)

ROOT = Path(__file__).resolve().parents[2]          # backend_async/tests → 仓库根
CONFIG_JSON = ROOT / "mock" / "data" / "room-321-config.json"
APP_JS = ROOT / "assets" / "app.js"
UNIFORM = 100 / 9                                   # 前端旧兜底基线(本测试要防的就是它)


def _node() -> str | None:
    return shutil.which("node")


# ═══════════ 一、唯一真源对拍 ═══════════

@pytest.mark.skipif(not CONFIG_JSON.is_file(), reason="缺 mock/data(仅后端包)")
def test_constants_match_shipped_config():
    """妖兽表里的概率必须与随前端下发的 room-321-config.json 逐项相等。
    这两份数据描述的是同一个游戏静态事实,分叉即错。"""
    spells = json.loads(CONFIG_JSON.read_text(encoding="utf-8"))["spells"]
    from_cfg = {int(s["beast_id"]): float(str(s["probability"]).rstrip("%"))
                for s in spells}
    assert from_cfg == OFFICIAL_PROBABILITY, (
        "constants.OFFICIAL_PROBABILITY 与 mock/data/room-321-config.json 已分叉:"
        + repr({k: (from_cfg.get(k), OFFICIAL_PROBABILITY.get(k))
                for k in set(from_cfg) | set(OFFICIAL_PROBABILITY)
                if from_cfg.get(k) != OFFICIAL_PROBABILITY.get(k)}))


def test_probabilities_are_self_consistent():
    """两条自洽性:合计恒 100%;Σ(概率×倍率)=83.8% RTP —— 任一项串位 RTP 立刻离谱,
    所以 RTP 是"概率↔倍率配对没搞错"的廉价校验。"""
    assert round(sum(OFFICIAL_PROBABILITY.values()), 6) == 100.0
    mult = {oid: m for oid, _n, _s, m in BEASTS_BASE}
    rtp = sum(OFFICIAL_PROBABILITY[oid] * mult[oid] / 100 for oid in mult)
    assert round(rtp, 2) == 83.80, f"RTP={rtp} —— 概率与倍率的配对疑似串位"


def test_probability_follows_beast_not_seat():
    """概率必须按**官方 beast_id** 走。display_number 可被 settings.custom_beast_ids
    覆盖,若按号位键入,改一次自定义编号就全体串位(而且照样不报错)。"""
    _, by_cid = build_beast_meta({"镇岳甲": 9, "沧溟龙": 1})
    assert by_cid[9]["beast_name"] == "镇岳甲" and by_cid[9]["probability"] == "20.00%"
    assert by_cid[1]["beast_name"] == "沧溟龙" and by_cid[1]["probability"] == "2.00%"


def test_fmt_matches_config_spelling():
    """兜底串的写法必须与配置逐字符一致(20.00% 而非 20% / 20.0%),
    这样"读到配置"与"走兜底"两条路径给前端的字段没有任何差异。"""
    assert fmt_probability(20.0) == "20.00%"
    assert fmt_probability(3.5) == "3.50%"
    assert fmt_probability(2.0) == "2.00%"


# ═══════════ 二、两条加载路径都必须"前端能解出数" ═══════════

def _parse_pct(v) -> float:
    """把规范形态的百分串("20.00%")解成数。**只用于本文件对规范值的断言** ——
    真正与 JS parseFloat 对齐的实现是 web._js_parse_float,由下方活体对拍守卫。"""
    try:
        return float(str(v).replace("%", "").strip())
    except Exception:
        return math.nan


def test_table_check_survives_python_dash_O():
    """概率表的自洽校验必须是真 raise,不能是 assert —— `python -O` / PYTHONOPTIMIZE
    会把 assert 整条剥掉,那样一张 179% 的表能静默 import 成功(已实测)。
    一个专治静默失真的补丁,自己不能留静默口子。

    验证方式是**行为**而非扫源码字符串:真的起一个 `python -O` 子进程,把表改坏,
    看校验函数是否仍然炸。(初版用 `"assert " not in src` 扫描,结果被本函数
    docstring 里的"assert"二字自己绊倒 —— 扫文本判实现,本身就是坏判据。)"""
    code = (
        "import sys; sys.path.insert(0, %r)\n"
        "import app.constants as C\n"
        "C.OFFICIAL_PROBABILITY[5] = 99.0\n"
        "try:\n"
        "    C._check_probability_table()\n"
        "except ValueError:\n"
        "    print('RAISED')\n"
        "else:\n"
        "    print('SILENT')\n"
    ) % str(Path(__file__).resolve().parents[1])
    out = subprocess.run([sys.executable, "-O", "-c", code],
                         capture_output=True, text=True, timeout=60)
    assert out.stdout.strip() == "RAISED", (
        "-O 下概率表校验被跳过了 —— 校验必须用 raise 而非 assert。"
        f"stdout={out.stdout!r} stderr={out.stderr[-400:]!r}")


@pytest.mark.parametrize("v,ok", [
    ("20.00%", True), ("20%", True), ("3.50%", True), ("100%", True), (".5%", True),
    ("", False), (None, False), ("N/A", False), ("%", False), ("  ", False),
    ("0%", False),          # stateOf 的 `100/(prob||10)` 会把 0 悄悄换成 10% —— 同源病
    ("-5%", False), ("100.001%", False),
    ("Infinity", False),    # JS parseFloat 解得出,但「官方」列会显 Infinity%
    ("inf", False),         # ← 危险方向:朴素 float() 认它、JS 不认
    ("２０%", False),        # ← 危险方向:全角数字,朴素 float() 认它、JS 不认
])
def test_probability_ok_boundaries(v, ok):
    """判据必须"既前端解得出、又说得通"。带 ← 标记的两例正是朴素 `float()` 实现
    会放行、而前端解不出的**危险方向** —— 后端以为没事,前端照旧回落 11.11%。"""
    from app import web
    assert web._probability_ok(v) is ok, f"{v!r} 判据不符预期"


@pytest.mark.skipif(_node() is None, reason="需要 node 才能做 JS↔Python 活体对拍")
def test_js_parse_float_parity_live():
    """**头号契约**:web._js_parse_float 必须与 JS `parseFloat` 逐例一致。
    后端认为"有值"而前端解不出,正是本文件所治那个 bug 的形状 —— 判据一旦分叉,
    回填就会漏掉真正该填的条目。语料 = 手挑边界 + 600 条随机串。
    (同款守卫见 tests/test_proof_of_browser.py 的跨语言对拍。)"""
    import random
    from app import web

    cases = ["20.00%", "20%", "20", " 20 ", "", "N/A", None, "20abc", "abc20", "%",
             "0%", "-5%", "1e2%", "Infinity", "-Infinity", "inf", "NaN", "nan", "0x14",
             "20.00.00", "  ", "１２", "+20%", ".5%", "20 %", "２０%", "1e", "1e+", "1E5",
             "..5", ".", "+.5", "- 5", "\u00a05", "\ufeff7", "\u30003", "1_000", "1,5",
             "5%%", "%20", "1e999", "1e-999", ".0e1", "0.0", "100", "100.001", "1e2e2"]
    rnd = random.Random(20260724)                       # 定种:失败可复现
    alpha = "0123456789.eE+-% \t\u3000Ω１２x"
    cases += ["".join(rnd.choice(alpha) for _ in range(rnd.randint(0, 7)))
              for _ in range(600)]

    prog = ("const cs=" + json.dumps(cases, ensure_ascii=False) + ";\n"
            "console.log(JSON.stringify(cs.map(v=>{const r=parseFloat(String(v));"
            "return Number.isNaN(r)?'NaN':(r===Infinity?'Inf':(r===-Infinity?'-Inf':r));})));")
    with tempfile.NamedTemporaryFile("w", suffix=".mjs", delete=False,
                                     encoding="utf-8") as f:
        f.write(prog)
        path = f.name
    try:
        got = json.loads(subprocess.run([_node(), path], capture_output=True, text=True,
                                        timeout=60, check=True).stdout.strip())
    finally:
        Path(path).unlink(missing_ok=True)

    def tag(x: float):
        if math.isnan(x):
            return "NaN"
        if x == math.inf:
            return "Inf"
        if x == -math.inf:
            return "-Inf"
        return round(x, 12)

    bad = [(c, j, tag(web._js_parse_float(c)))
           for c, j in zip(cases, got)
           if (j if isinstance(j, str) else round(j, 12)) != tag(web._js_parse_float(c))]
    assert not bad, f"_js_parse_float 与 JS parseFloat 分歧 {len(bad)} 例(前 10):{bad[:10]}"


@pytest.mark.skipif(not APP_JS.is_file() or _node() is None,
                    reason="需要 node 才能做 JS↔Python 活体对拍")
def test_js_officialprob_predicate_parity_live():
    """**头号契约之二**:前端 officialProb 的"这个值能不能用"判据,必须与后端
    web._probability_ok **逐例一致**。

    两侧口径一旦分叉就会出现新的静默失真:后端认为可用不回填、前端却判 NaN 显
    「待基线」(用户看到一片"—"却没有任何告警),或反过来后端回填了、前端本来
    也能用(白白覆盖配置值)。初版只对齐了"解得出/解不出",漏了"解得出但不是
    概率"(0% / 负 / >100 / Infinity)—— 那一类照样能算出满屏红蓝的假结论。"""
    from app import web
    cases = ["20.00%", "3.50%", "100%", ".5%", "1e1%", " 20 %", "+20%",
             "0%", "0.00%", "-5%", "150%", "100.001%", "Infinity", "-Infinity",
             "", "   ", "N/A", "%", None, "２０%", "inf", "NaN", "0x14", "20abc"]
    prog = ("const S={spellByN:{}};\n" + _extract_js("officialProb") + "\n"
            + "const cs=" + json.dumps(cases, ensure_ascii=False) + ";\n"
            + "console.log(JSON.stringify(cs.map(v=>{S.spellByN[1]={probability:v};"
              "return !Number.isNaN(officialProb(1));})));\n")
    with tempfile.NamedTemporaryFile("w", suffix=".mjs", delete=False,
                                     encoding="utf-8") as f:
        f.write(prog)
        path = f.name
    try:
        got = json.loads(subprocess.run([_node(), path], capture_output=True, text=True,
                                        timeout=60, check=True).stdout.strip())
    finally:
        Path(path).unlink(missing_ok=True)
    exp = [web._probability_ok(c) for c in cases]
    bad = [(c, g, e) for c, g, e in zip(cases, got, exp) if g != e]
    assert not bad, ("前端 officialProb 与后端 _probability_ok 判据分叉(值, 前端可用?, "
                     f"后端可用?):{bad}")


ROUND_ENGINE_JS = ROOT / "assets" / "round-engine.js"
MOCK_DIR = ROOT / "mock" / "data"

# round-engine.js 装载期只碰 window 与 XMLHttpRequest(已核实),故纯 node 即可跑,
# 不必给项目引入 jsdom 依赖 —— 与 test_proof_of_browser 一样只要求 `node` 在。
_RE_HARNESS = """
const fs = require('fs'), path = require('path');
const DIR = __DIR__, MUT = __MUT__;
const files = {};
for (const n of fs.readdirSync(DIR)) if (n.endsWith('.json'))
  files[n] = JSON.parse(fs.readFileSync(path.join(DIR, n), 'utf8'));
const sp = files['room-321-config.json'].spells.slice().sort((a,b)=>a.display_number-b.display_number);
if (MUT.all !== undefined) sp.forEach(s => s.probability = MUT.all);
if (MUT.one !== undefined) sp[MUT.at || 0].probability = MUT.one;
if (MUT.scale !== undefined) sp.forEach(s => s.probability =
  (parseFloat(String(s.probability).replace('%','')) * MUT.scale).toFixed(4) + '%');
global.window = {};
global.XMLHttpRequest = class {
  open(m, u) { this._n = String(u).split('/').pop(); }
  send() { this.status = files[this._n] ? 200 : 404;
           this.responseText = JSON.stringify(files[this._n] || {}); }
};
let err = null;
try { eval(fs.readFileSync(__RE__, 'utf8')); } catch (e) { err = String(e && e.message || e); }
console.log(JSON.stringify({ ready: !!global.window.RoundEngine, err }));
"""


def _run_round_engine(mutation: dict) -> dict:
    """把 assets/round-engine.js 在**纯 node**里装起来(只需 window + XMLHttpRequest,
    不引 jsdom,与 test_proof_of_browser 一样只依赖 `node` 在不在),按 mutation 改写
    room-321-config.json 的 probability,回报引擎是否就绪 / 抛了什么。"""
    prog = _RE_HARNESS.replace("__DIR__", json.dumps(str(MOCK_DIR))) \
                      .replace("__MUT__", json.dumps(mutation)) \
                      .replace("__RE__", json.dumps(str(ROUND_ENGINE_JS)))
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as f:
        f.write(prog)
        p = f.name
    try:
        out = subprocess.run([_node(), p], capture_output=True, text=True, timeout=120, check=True)
        return json.loads(out.stdout.strip().splitlines()[-1])
    finally:
        Path(p).unlink(missing_ok=True)


@pytest.mark.skipif(not ROUND_ENGINE_JS.is_file() or not MOCK_DIR.is_dir() or _node() is None,
                    reason="需要 node + assets/round-engine.js + mock/data")
def test_round_engine_loads_with_shipped_config():
    """正常配置下引擎必须照常就绪 —— 校验不能误伤happy path。"""
    r = _run_round_engine({})
    assert r["ready"] and r["err"] is None, r


@pytest.mark.skipif(not ROUND_ENGINE_JS.is_file() or not MOCK_DIR.is_dir() or _node() is None,
                    reason="需要 node + assets/round-engine.js + mock/data")
@pytest.mark.parametrize("mut,why", [
    ({"one": ""},            "只坏一项(空串)"),
    ({"one": "２０%"},        "只坏一项(全角,JS parseFloat 解不出)"),
    ({"one": "0%"},          "只坏一项(0%)"),
    ({"one": "-5%"},         "只坏一项(负数)"),
    ({"all": ""},            "九项全坏"),
    ({"scale": 0.5},         "各项合法但合计仅 50%"),
    ({"scale": 2.0},         "各项超界且合计 200%"),
])
def test_round_engine_rejects_unusable_probability(mut, why):
    """**关键守卫**:round-engine 的 probability 是**出怪抽样的权重**,不是展示字段。

    实测(jsdom 装载真实文件、注入坏配置)原版行为:
      · 九项里**只坏一项** → NaN 污染 pickAt 的 acc,`r < acc` 恒假,1728 局
        **100% 开出号位9 沧溟龙(×500)**,全程不抛错;
      · 各项合法但合计仅 50% → 号位9 从 2.0% 静默抬到 **50.9%**(无 NaN、无报错,
        纯隐形偏置 —— 这一类比 NaN 更难发现)。
    修复后一律 throw,由 jiufa/jf-boot.js 的「死端 D」守卫接管(掐断请求泄漏、
    有界重试、交父页失败提示)。本用例钉住"坏数据必须炸,而不是静默换个盘面"。"""
    r = _run_round_engine(mut)
    assert not r["ready"], f"{why}:引擎仍然就绪 —— 坏概率被放行了,出怪抽样已失真"
    assert r["err"] and "round-engine" in r["err"], f"{why}:未给出可诊断的报错,err={r['err']!r}"


def _beasts_base_of(rel: str):
    """用 AST 取出某文件里的 BEASTS_BASE 字面量(不 import,避免拖进无关依赖)。"""
    import ast
    tree = ast.parse((ROOT / rel).read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            tgt = node.targets[0] if isinstance(node, ast.Assign) else node.target
            if isinstance(tgt, ast.Name) and tgt.id == "BEASTS_BASE":
                return ast.literal_eval(node.value)
    return None


@pytest.mark.parametrize("rel", [
    "backend_async/app/accounts/game_backend.py",     # 官方真实游戏后端(自包含副本)
    "jiufa_data/spell_tamer_monitor.py",              # 旧预测引擎(单文件自包含,刻意逐字复用)
])
def test_beast_tables_never_drift(rel):
    """全仓有**三份** BEASTS_BASE 副本。这份重复是刻意的(预测引擎按单文件自包含
    的方式复用、game_backend 是自包含模块),不该为了去重去动那两个文件 ——
    但也不能任其漂移:倍率/名称一旦分叉,出怪展示、结算与预测会各说各话,且同样
    不报错。故不重构、只钉住。(概率不在此表内,按官方 id 单列于
    constants.OFFICIAL_PROBABILITY,见本文件顶部。)"""
    if not (ROOT / rel).is_file():
        pytest.skip(f"缺 {rel}(仅后端包)")
    other = _beasts_base_of(rel)
    assert other is not None, f"{rel} 里找不到 BEASTS_BASE —— 改名了?"
    assert other == BEASTS_BASE, (
        f"{rel} 的妖兽表与 app/constants.py 已漂移:"
        + repr([(a, b) for a, b in zip(BEASTS_BASE, other) if a != b]))


@pytest.mark.parametrize("mut,why", [
    ("one100",  "把号位1 写成 100%(逐项合法、合计 180%)"),
    ("half",    "全体折半(逐项合法、合计 50%)"),
    ("double",  "全体加倍(合计 200%)"),
])
def test_loader_resets_when_probability_sum_wrong(tmp_path, monkeypatch, mut, why):
    """**逐项合法 ≠ 整体成立**。逐项判据放行"每项都在 (0,100]"的表,但九项加起来
    未必是 100%:实测把号位1 改成 100.00% → 后端原样下发、合计 180%,出怪司历
    拿它当基线算出 −80pp 的「偏差」并照常 2σ 着色,全程无告警。

    assets/round-engine.js 已对同一份文件做合计校验(它的 p 是出怪抽样权重),
    后端作为**司历基线的权威来源**没有理由更宽松 —— 两个消费方对同一份数据口径
    不一致,本身就是下一个 bug 的温床。本用例钉住:合计不对 → 整体重置为权威值。"""
    from app import web
    from app.settings import settings

    cfg = json.loads(CONFIG_JSON.read_text(encoding="utf-8")) if CONFIG_JSON.is_file() else None
    if cfg is None:
        _, by_cid = build_beast_meta(None)
        cfg = {"spells": [dict(by_cid[c], display_number=c) for c in range(1, 10)]}
    sp = sorted(cfg["spells"], key=lambda x: x["display_number"])
    if mut == "one100":
        sp[0]["probability"] = "100.00%"
    else:
        k = 0.5 if mut == "half" else 2.0
        for s in sp:
            s["probability"] = f'{float(str(s["probability"]).rstrip("%")) * k:.2f}%'

    d = tmp_path / "static"
    (d / "mock" / "data").mkdir(parents=True)
    (d / "mock" / "data" / "room-321-config.json").write_text(
        json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
    monkeypatch.setattr(settings, "static_dir", str(d))

    out = web._load_spells_template()
    total = sum(_parse_pct(s["probability"]) for s in out)
    assert abs(total - 100.0) <= 0.01, f"{why}:合计仍为 {total}%"
    for s in out:
        assert _parse_pct(s["probability"]) == OFFICIAL_PROBABILITY[int(s["beast_id"])], why


def test_loader_degrades_on_malformed_spells(tmp_path, monkeypatch):
    """spells 写成对象而非数组时必须**加载期**降级到权威兜底。
    这是与概率同源的既有缺陷(原版实测同样崩溃,非本次引入):原版只判 `if sp:`,
    dict 是真值 → 原样返回 → 直到**请求期**才在 _spells_config 里 TypeError。
    把崩溃从"每一次 /api/rooms/*/config"提前到"启动时一条告警"。"""
    from app import web
    from app.settings import settings
    d = tmp_path / "static"
    (d / "mock" / "data").mkdir(parents=True)
    (d / "mock" / "data" / "room-321-config.json").write_text(
        json.dumps({"spells": {"a": {"display_number": 1}}}), encoding="utf-8")
    monkeypatch.setattr(settings, "static_dir", str(d))

    out = web._load_spells_template()
    assert isinstance(out, list) and len(out) == 9, f"未降级为九条兜底:{out!r}"
    for s in out:
        assert _parse_pct(s["probability"]) == OFFICIAL_PROBABILITY[int(s["beast_id"])]
    web.ST.spells_template = out
    web._spells_config("321")            # 请求期不得再炸


@pytest.mark.parametrize("rel,name", [
    ("jiufa_data/value_grid.py",                  "MULT"),
    ("jiufa_data/validate_hot_rotate.py",         "MULT"),
    ("backend_async/tests/test_hot_rotate.py",    "_MULT"),
    ("backend_async/tests/test_frontier.py",      "MULT"),
])
def test_seat_keyed_multiplier_tables_never_drift(rel, name):
    """除三份 BEASTS_BASE 外,仓库还有**三份按号位键入的倍率表**
    (10,50,330,250,100,100,50,50,500)。它们是 BEASTS_BASE ⋈ DEFAULT_CUSTOM_IDS
    的派生结果 —— 派生值抄成字面量,就有漂移空间:改了自定义编号或倍率而这三处不改,
    价值/回报类分析会拿错倍率算出"看起来合理"的结论,同样不报错。

    与妖兽表同一处置:不去重(这些是自包含的分析脚本/测试),只钉住。"""
    import ast
    p = ROOT / rel
    if not p.is_file():
        pytest.skip(f"缺 {rel}(仅后端包)")
    tree = ast.parse(p.read_text(encoding="utf-8"))
    val = None
    for node in ast.walk(tree):
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            tgt = node.targets[0] if isinstance(node, ast.Assign) else node.target
            if isinstance(tgt, ast.Name) and tgt.id == name:
                val = ast.literal_eval(node.value)
                break
    assert val is not None, f"{rel} 里找不到 {name} —— 改名了?"
    seq = tuple(val[i] for i in range(1, 10)) if isinstance(val, dict) else tuple(val)

    from app.constants import DEFAULT_CUSTOM_IDS
    mult_by_name = {n: m for _o, n, _s, m in BEASTS_BASE}
    derived = tuple(mult_by_name[n]
                    for n, _cid in sorted(DEFAULT_CUSTOM_IDS.items(), key=lambda kv: kv[1]))
    assert seq == derived, (
        f"{rel}:{name} 与 constants(BEASTS_BASE ⋈ DEFAULT_CUSTOM_IDS)推导已分叉:"
        f"{seq} vs {derived}")


def test_fallback_template_probability_is_parseable():
    """**头号守卫**:妖兽表兜底出来的九条,probability 必须条条能解出数,
    且等于真概率。回到 "" 的那一刻本用例即红。"""
    _, by_cid = build_beast_meta(None)
    for cid in range(1, 10):
        m = by_cid[cid]
        p = _parse_pct(m["probability"])
        assert not math.isnan(p), (
            f"号位{cid}/{m['beast_name']} 的 probability={m['probability']!r} 前端解不出 —— "
            f"会静默回落均匀 {UNIFORM:.2f}%,出怪司历「官方/偏差」与九法阵出怪规律态全部算错")
        assert p == OFFICIAL_PROBABILITY[m["beast_id"]]


def test_loader_fallback_when_config_missing(tmp_path, monkeypatch):
    """**头号守卫之二**:配置完全读不到时,加载器兜底出来的九条 probability
    也必须条条可解析。回到 `"probability": ""` 的那一刻本用例即红。

    注:`_load_spells_template` 有三个候选目录(settings.static_dir、模块文件推出的
    仓库根、cwd),仓库根那一条是硬编码的,在仓库里跑测试永远能读到 mock/data ——
    所以必须把三条**全部**指开,否则这条兜底分支根本测不到(它平时不走,正是它
    能带着 `""` 长期潜伏的原因)。"""
    from app import web
    from app.settings import settings

    empty = tmp_path / "empty"
    (empty / "app").mkdir(parents=True)
    monkeypatch.setattr(settings, "static_dir", str(empty))
    monkeypatch.setattr(web, "__file__", str(empty / "app" / "web.py"))
    monkeypatch.chdir(empty)

    spells = web._load_spells_template()
    assert len(spells) == 9
    for sp in spells:
        p = _parse_pct(sp["probability"])
        assert not math.isnan(p), (
            f"兜底模板里 {sp['display_number']}号的 probability={sp['probability']!r} "
            f"前端解不出 —— 会静默回落均匀 {UNIFORM:.2f}%,出怪司历「官方/偏差」两列"
            f"与九法阵出怪规律态全部按错误基线计算(号位1 恒 +8.9pp 并被 2σ 判为显著偏热)")
        assert p == OFFICIAL_PROBABILITY[int(sp["beast_id"])]


def test_loader_backfills_broken_config(tmp_path, monkeypatch):
    """配置在、但个别条目的 probability 缺失/写坏时,加载器必须按妖兽表回填。
    (缺陷不只在"读不到配置"那一条路径上 —— 配置部分损坏是同一个静默失真。)"""
    from app import web
    from app.settings import settings

    cfg = json.loads(CONFIG_JSON.read_text(encoding="utf-8")) if CONFIG_JSON.is_file() else None
    if cfg is None:                                   # 仅后端包:自造一份等价配置
        _, by_cid = build_beast_meta(None)
        cfg = {"spells": [dict(by_cid[c], display_number=c, beast_icon="x") for c in range(1, 10)]}
    cfg["spells"][0]["probability"] = ""              # 空串(缺陷原貌)
    cfg["spells"][2].pop("probability", None)         # 字段整个没了
    cfg["spells"][8]["probability"] = "N/A"           # 解不出的脏值

    d = tmp_path / "static"
    (d / "mock" / "data").mkdir(parents=True)
    (d / "mock" / "data" / "room-321-config.json").write_text(
        json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
    monkeypatch.setattr(settings, "static_dir", str(d))

    for sp in web._load_spells_template():
        p = _parse_pct(sp["probability"])
        assert not math.isnan(p), f"{sp['display_number']}号回填失败:{sp['probability']!r}"
        assert p == OFFICIAL_PROBABILITY[int(sp["beast_id"])]


# ═══════════ 三、跨语言活体对拍 ═══════════

def _extract_js(fn_name: str) -> str:
    """从 app.js 里按花括号配平抠出整个函数(逐字,不复制粘贴)。

    **先剥注释再配平**,两个理由:
      ① 扫描类断言必须剥注释 —— 这是本仓库明文约定(见 tests/_srcscan.py 的模块
         docstring:"凡是「扫源码判断代码里有没有某写法」的测试,都必须先剥注释",
         且"禁止各测试再各写一份")。本轮开发我自己也栽过同一个跟头:另一条用例
         曾用 `"assert " not in src` 扫源码,结果被它自己 docstring 里的 "assert"
         二字绊倒;
      ② 花括号配平在**含注释的原文**上做是脆的 —— 注释里出现一个 `{` 或 `}`
         就会让抽取错位,而且错得无声无息(抽出半个函数照样能跑)。
    """
    src = strip_js_comments(APP_JS.read_text(encoding="utf-8"))
    i = src.find(f"function {fn_name}(")
    assert i >= 0, f"assets/app.js 里找不到 function {fn_name}( —— 前端实现丢失/改名?"
    depth, k = 0, src.find("{", i)
    while k < len(src):
        if src[k] == "{":
            depth += 1
        elif src[k] == "}":
            depth -= 1
            if depth == 0:
                return src[i:k + 1]
        k += 1
    raise AssertionError(f"{fn_name} 花括号未配平")


@pytest.mark.skipif(not APP_JS.is_file(), reason="缺 assets/app.js(仅后端包)")
def test_js_officialprob_no_longer_fabricates_baseline():
    """前端 officialProb 不得再把"不知道"就地变成 100/9 —— 那正是静默失真的源头。
    未知时应返回 NaN,由调用方显式降级(「待基线」/「—」),与 3.8.2「零数据不出
    伪统计」同口径。"""
    js = _extract_js("officialProb")     # 已剥注释,不会被解释性文字绊倒
    # 字符串扫描是**廉价烟测**(node 缺席时的唯一守卫);真正的守卫是下面的
    # test_js_officialprob_predicate_parity_live —— 它比行为,不比字面量。
    assert "100/9" not in js.replace(" ", ""), (
        "officialProb 又把未知基线兜底成均匀 11.11% 了 —— 出怪司历会重新开始"
        "自信地报错值(号位1 恒 +8.9pp 判偏热)。请让它返回 NaN 并在调用方降级。")


@pytest.mark.skipif(not APP_JS.is_file() or _node() is None,
                    reason="需要 node 才能做 JS↔Python 活体对拍")
def test_js_python_parity_live():
    """**头号守卫**:把后端**真实**的兜底产物喂给 app.js 里真实的 officialProb,
    断言它解出真概率、且不等于均匀基线。前后端任一侧改坏当场红。"""
    _, by_cid = build_beast_meta(None)
    spells = [{"display_number": c, "probability": by_cid[c]["probability"]}
              for c in range(1, 10)]
    prog = ("const S = {spellByN: {}};\n"
            + "for (const sp of " + json.dumps(spells, ensure_ascii=False)
            + ") S.spellByN[sp.display_number] = sp;\n"
            + _extract_js("officialProb") + "\n"
            + "console.log(JSON.stringify([1,2,3,4,5,6,7,8,9].map(officialProb)));\n")
    with tempfile.NamedTemporaryFile("w", suffix=".mjs", delete=False,
                                     encoding="utf-8") as f:
        f.write(prog)
        path = f.name
    try:
        out = subprocess.run([_node(), path], capture_output=True, text=True,
                             timeout=30, check=True)
        got = json.loads(out.stdout.strip())
    finally:
        Path(path).unlink(missing_ok=True)

    exp = [OFFICIAL_PROBABILITY[by_cid[c]["beast_id"]] for c in range(1, 10)]
    assert got == exp, ("前端解出的官方概率与后端下发的不一致:" + repr(list(zip(got, exp))))
    assert all(v is not None and abs(v - UNIFORM) > 1e-9 for v in got[:1] + got[2:]), (
        "前端仍在回落均匀 11.11% —— 出怪司历「官方/偏差」与九法阵出怪规律态会静默算错")
