"""
test_rail_status.py — 名录速览角标诚实化(3.9.5)全链回归
================================================================================
背景(实地核查实证的四处失真,详见 web._live_room_card / app.js railChip 注):
  ① curated-idle 降级后 `_handle_hist` 只写 histLastOkMs,卡片 lastOkAt 冻结 →
     前端 10 分钟阈值一到,非活跃房**永久**挂「休(可能已下播)」—— 而数据每 T
     都在成功入库、零缺口,且九法 24h 连续出怪,"下播"与数据有无无关;
  ② 快照缺失时旧卡片 `lastOkAt: _iso(... or srv)` 把「从未抓过」伪装成「刚抓过」,
     死房反而显示正常倒计时(反向撒谎);
  ③ lastError 有田无人耕:worker 失败路径从不写入(只有成功清空),票据过期这类
     最该报警的场景无从诊断;
  ④ 前端失联判据用 now−okAt:后台标签回前台的补拉窗内高估数据年龄,连当前正看
     的房都闪"休"。
本文件分三层钉死修复(谱系对齐 test_histmode_web / test_curated_idle):
  · Web(monkeypatch web.ST + 直调):卡片 mode/dataOkAt/lastOkAt 语义、冷标
    双开关 gate(契约⑪:关闭态残留冷标惰性、零误标)、histIntervalS 下发;
  · Worker(_mini_world 直驱单事件):mp/hist 失败串首拍写 lastError、成功清空、
    AuthExpired 不再逃逸到 consumer 的 +5s 平拍(改走标准退避,对齐 hist 侧
    「复查修正 C」裁决);
  · 前端静态守卫(test_frontend_backend_limits 同款零依赖):误导文案清除、
    新判据/新字段在位、visibilitychange 补拉、CSS 两态、版本参数已 bump。
"""
from __future__ import annotations

import re
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app.redis_bus as rb
import app.web as web
from app.redis_bus import RedisBus, task_hist, task_mainpage

ROOT = Path(__file__).resolve().parents[2]
APP_JS = ROOT / "assets" / "app.js"
APP_CSS = ROOT / "assets" / "app.css"
INDEX = ROOT / "index.html"
WEB_SRC = (Path(__file__).resolve().parent.parent / "app" / "web.py") \
    .read_text(encoding="utf-8")


# ══ 共用假件(test_histmode_web 同款轻模式) ═══════════════════════════════════
class _WideDB:
    """宽假件:任何方法都可 await,返回中性值(db 不是被测对象)。"""
    def __getattr__(self, name):
        async def _f(*a, **k):
            return None
        return _f


class _Star:
    async def canon(self, room):
        return str(room), True

    async def profile(self, room):
        return {}


def _bus():
    import fakeredis.aioredis
    b = RedisBus("redis://x")
    b.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    return b


@pytest.fixture()
def wired(monkeypatch):
    """挂真 bus/宽 db/star;测试后还原 settings.histmode(模块级单例,无自动还原)。"""
    b = _bus()
    monkeypatch.setattr(web.ST, "bus", b, raising=False)
    monkeypatch.setattr(web.ST, "db", _WideDB(), raising=False)
    monkeypatch.setattr(web.ST, "star", _Star(), raising=False)
    hm = web.settings.histmode
    saved = (hm.enabled, hm.interval_s,
             getattr(hm, "curated_idle_enabled", False))
    yield b
    (hm.enabled, hm.interval_s, hm.curated_idle_enabled) = saved


# ══ 一、Web:卡片语义(诚实化三字段) ═══════════════════════════════════════════
@pytest.mark.asyncio
async def test_card_idle_room_dataokat_from_hist(wired):
    """冷房实况复刻:lastOkAt 冻结、histLastOkMs 新鲜 —— dataOkAt 必须取 hist
    (①的根因修复);lastOkAt 仍如实回冻结值(实时管线口径不混淆)。"""
    b = wired
    now = int(time.time() * 1000)
    frozen, fresh = now - 3_600_000, now - 60_000
    await b.set_snapshot("9501", {"roundStartTimeMs": now - (now % 50_001),
                                  "lastOkAt": frozen, "histLastOkMs": fresh})
    c = await web._live_room_card("9501", now, cold=True)
    assert c["mode"] == "idle"
    assert c["dataOkAt"] and c["lastOkAt"]
    from app.db import _iso
    assert c["dataOkAt"] == _iso(fresh)          # 两管线取新者
    assert c["lastOkAt"] == _iso(frozen)         # 实时口径如实,不伪装
    # 实时管线更新后(唤醒),dataOkAt 跟随较新的 lastOkAt
    await b.set_snapshot("9501", {"lastOkAt": now - 1_000})
    c2 = await web._live_room_card("9501", now, cold=False)
    assert c2["mode"] == "realtime" and c2["dataOkAt"] == _iso(now - 1_000)


@pytest.mark.asyncio
async def test_card_empty_snapshot_no_fake_fresh(wired):
    """②的修复:快照缺失 → lastOkAt/dataOkAt 双空串,绝不伪装成"现在"。
    (旧式 `or srv` 会让从未抓过数据的房在前端显示正常倒计时。)"""
    now = int(time.time() * 1000)
    c = await web._live_room_card("9502", now)
    assert c["lastOkAt"] == "" and c["dataOkAt"] == ""
    assert c["mode"] == "realtime" and c["lastError"] == ""
    p = await web._live_room_card("9503", now, pending=True)
    assert p["mode"] == "pending" and p["dataOkAt"] == ""


@pytest.mark.asyncio
async def test_build_live_rooms_cold_gate_and_interval(wired):
    """冷标消费的双开关 gate(契约⑪ 姿态,与 worker._dormant 判据同源):
      · 任一开关关闭 → 残留冷标**惰性**,卡片恒 realtime、零误标;
      · 双开 → 冷房标 idle,非冷房 realtime;
      · histIntervalS:histmode 关闭回 0(前端取缺省),开启回生效秒值。"""
    b = wired
    hm = web.settings.histmode
    rooms = ["9601", "9602"]
    await b.add_rooms_bulk([(r, r) for r in rooms])
    await b.mark_cold_bulk(["9601"], int(time.time() * 1000))   # 冷标在位

    hm.enabled, hm.curated_idle_enabled = False, True           # 开关半开=关闭
    out = await web._build_live_rooms()
    by = {c["roomId"]: c for c in out["rooms"]}
    assert by["9601"]["mode"] == "realtime"                     # 残标惰性
    assert out["histIntervalS"] == 0

    hm.enabled, hm.curated_idle_enabled = True, False
    out = await web._build_live_rooms()
    assert {c["mode"] for c in out["rooms"]} == {"realtime"}

    hm.enabled, hm.curated_idle_enabled = True, True
    hm.interval_s = 900
    out = await web._build_live_rooms()
    by = {c["roomId"]: c for c in out["rooms"]}
    assert by["9601"]["mode"] == "idle" and by["9602"]["mode"] == "realtime"
    assert out["histIntervalS"] == 900                          # 生效值(钳内原样)


@pytest.mark.asyncio
async def test_build_live_rooms_auth_path_cold_and_alias(wired, monkeypatch):
    """登录名录路径(user 非空)同机制覆盖:冷标 → mode=idle、alias 覆写为用户
    输入号(卡片先建后覆写,mode 判定不受影响)、pending 绑定 → mode=pending、
    顶层 histIntervalS 同样下发。此前只有 no-auth 路径有执行覆盖。"""
    b = wired
    hm = web.settings.histmode
    hm.enabled, hm.curated_idle_enabled, hm.interval_s = True, True, 900

    class _DB(_WideDB):
        async def user_rooms_list(self, uid):
            return [{"room_id": "9701", "alias": "321"},
                    {"room_id": "97999", "alias": "97999"}]
    monkeypatch.setattr(web.ST, "db", _DB(), raising=False)
    await b.mark_cold_bulk(["9701"], int(time.time() * 1000))
    await b.r.hset(rb.K_ROOMS_PENDING, "97999", "1")     # 待归一绑定(hash: alias→ms)
    out = await web._build_live_rooms(SimpleNamespace(user_id=7))
    assert out["histIntervalS"] == 900
    by = {c["alias"]: c for c in out["rooms"]}
    assert by["321"]["roomId"] == "9701" and by["321"]["mode"] == "idle"
    assert by["97999"]["mode"] == "pending"


# ══ 二、Worker:lastError 落写 / AuthExpired 退避 ═══════════════════════════════
def _mp_world():
    from tests.test_histmode import _mini_world
    return _mini_world(enabled=False, interval_s=300)   # 实时管线世界


async def _drive_due(w):
    for m in await w.bus.claim_due(10, 10 ** 12):
        await w._handle(m)


@pytest.mark.asyncio
async def test_mp_fail_writes_lasterror_once_success_clears():
    """mp 连败串:首拍写 lastError,后续拍不重写(万房断供零写风暴);
    成功即清空 + mpFails 复位(既有语义)+ lastOkAt 落新。"""
    w, up, db, clock, s = _mp_world()
    room = "2678075"
    await w.bus.add_rooms_bulk([(room, room)])
    up.mp_outage = (clock.t, clock.t + 10 ** 9)
    await w.bus.schedule(task_mainpage(room), clock.t)
    await _drive_due(w)
    snap = await w.bus.get_snapshot(room)
    assert snap.get("mpFails") == "1" and "MainPage" in snap.get("lastError", "")
    # 串中第二拍:mpFails 前进、lastError 不重写(用哨兵值证明)
    await w.bus.set_snapshot(room, {"lastError": "哨兵"})
    clock.t += 60_000
    await _drive_due(w)
    snap = await w.bus.get_snapshot(room)
    assert snap.get("mpFails") == "2" and snap.get("lastError") == "哨兵"
    # 断供解除 → 成功拍:清空 + 复位 + lastOkAt 新鲜
    up.mp_outage = None
    clock.t += 60_000
    await _drive_due(w)
    snap = await w.bus.get_snapshot(room)
    assert snap.get("lastError") == "" and snap.get("mpFails") == "0"
    assert int(snap.get("lastOkAt") or 0) == clock.t


@pytest.mark.asyncio
async def test_mp_authexpired_backoff_not_consumer_flat():
    """票据过期:_handle 内消化(不逃逸 = 直调不抛)、lastError 记「票据」真因、
    重排走 _mp_fail_due 标准退避(首拍 delay ∈ [base, base+jitter],与 consumer
    的 +5s 平拍解耦 —— 对齐 hist 侧「复查修正 C」裁决,防万房 401 风暴)。"""
    from app.upstream import AuthExpired
    w, up, db, clock, s = _mp_world()
    room = "2678075"
    await w.bus.add_rooms_bulk([(room, room)])

    async def _boom(_aid, _room):
        raise AuthExpired("mp HTTP 401")
    w.up = SimpleNamespace(main_page=_boom)
    await w.bus.schedule(task_mainpage(room), clock.t)
    await _drive_due(w)                                  # 不抛 = 已在 handler 内消化
    snap = await w.bus.get_snapshot(room)
    assert "票据" in snap.get("lastError", "") and snap.get("mpFails") == "1"
    z = dict(await w.bus.r.zrange(rb.K_SCHED, 0, -1, withscores=True))
    delay = int(z[task_mainpage(room)]) - clock.t
    base = int(s.upstream.award_retry_interval * 1000)
    jit = int(s.scheduler.mainpage_jitter_ms)
    assert base <= delay <= base + jit + 1, delay        # 退避首拍,非 +5s 平拍


@pytest.mark.asyncio
async def test_hist_fail_writes_lasterror_success_clears():
    """hist(冷/发现房低频轮询):失败串首拍写 lastError,成功清空 —— 冷房
    真失联时名录『断』角标能报出真因,而不是笼统一个"休"。"""
    from tests.test_histmode import _mini_world
    w, up, db, clock, s = _mini_world(enabled=True, interval_s=300)
    room = "2678075"
    await w.bus.add_rooms_bulk([(room, room)])
    await w.bus.r.hset(rb.K_ROOMS_DISCOVERED, room, str(clock.t))  # 保持 dormant
    up.hist_fail_calls = {1}                             # 第 1 次轮询失败
    await w._handle_hist(room, task_hist(room))
    snap = await w.bus.get_snapshot(room)
    assert snap.get("histFails") == "1"
    assert "GameHistory" in snap.get("lastError", "")
    await w._handle_hist(room, task_hist(room))          # 第 2 次成功
    snap = await w.bus.get_snapshot(room)
    assert snap.get("lastError") == "" and snap.get("histFails") == "0"
    assert int(snap.get("histLastOkMs") or 0) > 0


@pytest.mark.asyncio
async def test_award_authexpired_flat60_no_attempt():
    """award 票据过期(3.9.5 同类同修):就地消化(直调不抛)、60s 平拍重排
    (≈MP_FAIL_BACKOFF_CAP_MS + 抖动,非 consumer +5s)、attempt **零消耗**
    (auth 失败不构成官方缺失证据)、不 ack(任务保留续走)。"""
    from app.upstream import AuthExpired
    from app.worker import MP_FAIL_BACKOFF_CAP_MS
    from app.redis_bus import task_award
    w, up, db, clock, s = _mp_world()
    room, rid = "2678075", 1_800_000_000_000 + 50_001 * 3
    await w.bus.add_rooms_bulk([(room, room)])

    async def _boom(_aid, _room, _rid):
        raise AuthExpired("aw HTTP 403")
    w.up = SimpleNamespace(round_award=_boom)
    member = task_award(room, rid)
    await w.bus.schedule(member, clock.t)
    await _drive_due(w)                                  # 不抛 = handler 内消化
    z = dict(await w.bus.r.zrange(rb.K_SCHED, 0, -1, withscores=True))
    assert member in z                                   # 未 ack,任务保留
    delay = int(z[member]) - clock.t
    jit = int(s.scheduler.mainpage_jitter_ms)
    assert MP_FAIL_BACKOFF_CAP_MS <= delay <= MP_FAIL_BACKOFF_CAP_MS + jit + 1
    assert await w.bus.award_attempt_incr(room, rid) == 1   # 首增返回 1 ⇒ auth 路径此前零消耗 attempt


@pytest.mark.asyncio
async def test_live_rooms_route_asgi_e2e(wired):
    """路由层端到端(httpx ASGITransport):中间件 → /api/live-rooms 路由 →
    _req_user(登录关闭=None)→ _build_live_rooms → JSON 序列化,新字段
    (mode/dataOkAt/histIntervalS)过线;此前只有函数直调覆盖。"""
    import httpx
    b = wired
    hm = web.settings.histmode
    hm.enabled, hm.curated_idle_enabled, hm.interval_s = True, True, 900
    now = int(time.time() * 1000)
    await b.add_rooms_bulk([("9801", "9801")])
    await b.mark_cold_bulk(["9801"], now)
    await b.set_snapshot("9801", {"roundStartTimeMs": now - (now % 50_001),
                                  "histLastOkMs": now - 30_000})
    tr = httpx.ASGITransport(app=web.app)
    async with httpx.AsyncClient(transport=tr, base_url="http://t") as c:
        r = await c.get("/api/live-rooms")
    assert r.status_code == 200
    j = r.json()
    assert j["ok"] is True and j["histIntervalS"] == 900
    card = next(x for x in j["rooms"] if x["roomId"] == "9801")
    assert card["mode"] == "idle" and card["dataOkAt"] and card["lastOkAt"] == ""


# ══ 三、前端/源码静态守卫(零依赖,test_frontend_backend_limits 谱系) ═══════════
def _seg(src: str, anchor: str, upto: str = "\nfunction ") -> str:
    seg = src.split(anchor, 1)
    assert len(seg) == 2, f"找不到锚点 {anchor!r}(重命名请同步本守卫)"
    return seg[1].split(upto, 1)[0]


def test_frontend_railchip_honest():
    src = APP_JS.read_text(encoding="utf-8")
    chip = _seg(src, "function railChip")
    # 误导文案清除:不再把"我方停抓"归因为"主播下播";不再使用含混的"休"字
    assert "可能已下播" not in chip and "'休'" not in chip
    # 新判据/新字段在位:dataOkAt 优先、快照时点判据、idle 阈值自适应
    for kw in ("dataOkAt", "roomsFetchedAt", "histStaleMs",
               "RAIL_LIVE_STALE_MS", "mode"):
        assert kw in chip, f"railChip 缺少 {kw}"
    # 澄清语义:失联提示必须点明 24h 连续出怪、与开播无关,并透出 lastError
    # (4.x 用词对齐官方盘面:出怪→出怪,见仓库根 README「用词口径」)
    assert "24 小时连续出怪" in chip and "lastError" in chip
    # 阈值常量取值钉死(与后端 MainPage 节拍/退避的推导一致,见常量注)
    m = re.search(r"^const\s+RAIL_LIVE_STALE_MS\s*=\s*(\d+)\s*;", src, re.M)
    assert m and int(m.group(1)) == 600000
    m = re.search(r"^const\s+RAIL_IDLE_STALE_DEF\s*=\s*(\d+)\s*;", src, re.M)
    assert m and int(m.group(1)) == 1920000
    # noteRoomsFetched:idle 阈随后端 histIntervalS 自适应(2×T+余量)
    note = _seg(src, "function noteRoomsFetched")
    assert "histIntervalS" in note and "roomsFetchedAt" in note


def test_frontend_resume_paths_refresh_roster():
    """回前台/断网恢复必须补拉名录(此前只补主舞台不补侧栏 —— ④的成因之二);
    loadRoom 成功路径带唤醒补拉(冷房角标秒级跟上)。"""
    src = APP_JS.read_text(encoding="utf-8")
    vis = src.split("visibilitychange', () => {", 2)[-1].split("});", 1)[0]
    assert "refreshLiveRooms()" in vis
    onl = _seg(src, "addEventListener('online'", "});")
    assert "refreshLiveRooms()" in onl
    assert "S.roomWakeT = setTimeout(refreshLiveRooms" in src


def test_frontend_css_and_cache_bust():
    css = APP_CSS.read_text(encoding="utf-8")
    assert ".ri-tick.slow" in css and ".ri-tick.lost" in css
    html = INDEX.read_text(encoding="utf-8")
    # 4.0.0(注册系统):新增注册态 UI 与求解 Worker → 必须 bump ?v 强刷,
    # 否则老页面拿不到 doRegister/Worker,点注册即失灵。
    # 4.0.2 修正:4.0.1 发版把 index.html bump 到 ?v=4.0.1 却忘了同步本钉
    # (本测试当时未入 4.0.1 的 49 项复验清单)→ 交付树里此测试红着。
    # 本钉的职责本就是「发版者不许忘记 bump」,它自己漏更是同一失败的镜像;
    # 现随 4.0.2(app.css 门内描边对比度)一并对齐,并把「禁旧版残留」扩到 4.0.x。
    # 4.1.0(链接快速登录 SSO):app.js 新增 ssoConsume/boot 兑换链 → 必须 bump
    # 强刷,否则老页面点 #sso= 链接零反应;本钉随之对齐,禁残留扩到 4.0.2。
    # 1.4.3 勘误:index.html 实际已推进到 4.1.2,本钉停在 4.1.0 —— 钉子落后于
    # 代码,主干长期假红(实地核查确证存量,原始包同红)。钉子的职责是"版本
    # 必须随功能 bump",不是冻结在史前值;对齐现值,禁残留口径不变。
    # 4.2.1(九法VIP 分层收费):app.js 新增 JF 档位状态 / 开通门 / 支付弹层 /
    # 面板角标 / 推演锁态,index.html 新增开通门与支付弹层 DOM → **必须 bump**,
    # 否则带缓存或经 CDN/反代的老客户端继续跑旧包:后端明明生效了,用户端
    # "毫无变化",且**重启服务器也不会好**(那是客户端侧的缓存)。
    # 真机反馈「设为 true 后保存/重启都没生效」即含此因,本钉随功能对齐。
    # 4.2.2(本轮):app.css 修 flex 居中裁顶、app.js 新增 payRecover 对账兜底 /
    # 开通记录 / priceText —— 前端有实质改动,按既有约定必须 bump 并同步本钉。
    # 4.2.5(本轮 VIP 复审):app.css 改了金调/灰阶/窄屏档位卡布局、app.js 改了
    # openModal 焦点(preventScroll)、开通门 scrollTop 复位、支付层 inert、
    # 对比表补「未开通」、以及 Tab 焦点收容纳入 VIP 两层 —— 前端有实质改动,
    # 按本钉既定职责(「发版者不许忘记 bump」)必须 bump 并同步本钉。
    # 不 bump 的后果与 4.2.1 那次记录的完全一样:带缓存/经 CDN 的老客户端
    # 继续跑旧包,后端生效了但用户端"毫无变化",且重启服务器也不会好。
    # 4.2.9(付费页可用性复审):app.js 修「立即开通」连点导致的计时器泄漏与
    # 焦点错乱、新增 settling 分支(已付款者不再被误告过期)、空档位禁用 CTA、
    # openModal 不覆盖开启者;app.css 新增小节标题/支付层说明/触控目标补到 44;
    # index.html 重排开通门(行动区上移到首屏)。前端有实质改动 ⇒ 必须 bump。
    # 4.3.0(第十九轮·付费页复审,真 Chromium 逐条复现后修):app.js
    # ①payExpired 的匿名 setTimeout(closePay,3000) 纳入 PAY.closeT ——
    #   它是 4.2.9 漏掉的第四枚计时器,红字「请重新发起」诱导的 3s 内重开
    #   会被它无声关掉新支付层;②openModal 开启者改逐层 WeakMap + 显式
    #   opener 参数(单槽位在门→支付嵌套时丢外层;真实二连击穿透
    #   pointer-events:none 把焦点打到 BODY);③三处可操作 toast 补 ms:8000
    #   (对齐「切回」先例与 toastAction 自身注释);④续费态主 CTA
    #   「立即开通」→「立即续费」(9.10 原则的最后一处)。app.css 未动,
    #   但本钉既有约定是 js/css 版本参**同文件内一致**,故一并推进。
    # 4.3.1(第二十轮·对 4.3.0 自审 + 同族扫尾):app.js ⑤成功 toast 分
    #   续费/开通措辞,且「已赠送小叮当」只在本单 ddHours>0 时才说(这是
    #   test_zero_gift_plan… 判据「三处无条件拼接说假话」漏网的第四处;真源:
    #   卡密响应自带 ddHours,订单路径用下单时记的 PAY.ddHours);⑥onVipGranted
    #   关门改走 closeModal(直接 hidden=true 跳过焦点契约,付完款焦点掉 body);
    #   ⑦卡密失败后焦点还给输入框(disabled 置忙的点击路径失焦);⑧加账号
    #   弹层 700ms 自动关入册 ACCT.closeT 双向清(4.3.0 ① 的 700ms 同族)。
    # 4.3.2(第廿一轮·对 4.3.1 自审):⑤′赠送真源收紧 —— 订单两条到账路径
    #   (轮询 paid / 模拟支付)由**确知本单**的调用方显式携带 PAY.ddHours,
    #   onVipGranted 不再兜底:payRecover→onVipGranted({}) 不确知救回的是哪张
    #   单,跨单救回(A 弃 dd=0、B 弃 dd>0、A 晚到账)会拿错单的值谎称赠送。
    #   真话边界=谁确知订单归属谁携带;真源缺失即省略,永不说过头话。
    # 4.3.3(第廿二轮·≤640 顶栏与出怪规律/战况头部几何):app.css ①basic 档
    #   出怪规律行 vip-note 由 absolute 改入流 static,连带镜像的战况头同修
    #   (角标遮挡战况/出怪规律头的同族缺陷);②≤640 两条状态行让位后,顶栏
    #   唯一常驻引导「开通」补宾语 → 「开通VIP」(孤词对小白零信息量,
    #   360 宽实测不折行);app.js ③首入 basic 一次性 toastAction 说明
    #   「从最近 N 局起累计」口径(此前只散在 11px 角标与踩锁 toast,
    #   小白全靠碰壁式发现);④启动序 dataBoot 补 applyLayout(档位落地
    #   晚于首屏布局,NOTE_H 预算有 27px 裁表窗口);⑤basic→vip 翻转
    #   applyLayout 免 renderAll(付款成功路径零额外重绘)。
    #   —— 本轮五处已随包发布,但 ?v 与本钉双双停在 4.3.2(即
    #   JFVIP-SYSTEM.md §9.8 第三条失效路径「前端缓存版本没 bump」的
    #   现行实例:带缓存/经 CDN 客户端会继续跑旧包)。4.3.3 补齐对账。
    # 4.3.4(注册系统 4.0.2 复查轮):app.js ①用户名代理区(emoji)就地预检
    #   ②jfInviteNorm 邀请码格式镜像预检(含 O/I/L 宽恕对拍)+ 格式拦截时后台
    #   刷新挑战自愈 invite→open 热切。app.css 未动 —— 按 4.3.0 既裁先例
    #   (「js/css 版本参同文件内一致,故一并推进」)双双 bump;首版误只 bump
    #   app.js,被本钉与 jfvip_contract 的一致性钉当场拦下(A/B 原始树双绿
    #   定责),本条即该次自查的对账记录。
    # 4.3.5(本轮,SSO 仅片段变化路径):app.js 新增 bindSsoHashChange() —— 补上
    # 「目标 URL 与当前文档只有 # 后不同时浏览器不重载」那条路(真实反馈:
    # 已停在登录门时粘贴 #sso= 链接回车零反应)。前端有实质改动,按既有约定
    # 必须 bump 并同步本钉 —— 漏 bump 则老页面拿不到监听,修了等于没修。
    # 4.3.6(移动端可用性轮,三处实测驱动):app.css ①星币色 #a8781f→#8a6114
    #   (实测 3.83:1 → 5.41:1,该行显示的是用户星币余额,11.5px 正文级需 AA 4.5:1)
    #   ②账号行 ⟳/× 命中区 22×22→34×44(原尺寸连 WCAG 2.2 AA 的 24×24 下限都不够,
    #   且「刷新」紧邻「删除账号」,中心距仅 24px;改后 36px)③<1024 断点下输入控件
    #   统一 16px —— iOS Safari 聚焦 <16px 控件即整页放大且不回缩(本站 viewport
    #   正确地未写 maximum-scale,故该行为必然发生);实测越阈控件:#roomSearch 15px、
    #   .density select 13.5px、#wvDay 12.5px、游戏面板 select 10.5px。
    #   app.js ④paintConnTruth():**半开连接**(TCP 活着但对端不再下发字节 ——
    #   反代挂死/中间盒静默丢流)下 onerror 永不触发,徽章会永久假显「实时」。
    #   实测(SSE 建连 8s 后转静默、socket 保持打开):原版 t=10~95s 全程「实时」
    #   且此后不变;补后 t=60s 起转「轮询中」(=SSE_SILENT_MS 45s + tick 节拍)。
    #   注:**真断连不在此列** —— 已核实端口不可达后重测,原版 onerror 15s 内即
    #   正确切「轮询中」,那条无需修(首轮曾用 set_offline / fuser -k 复现出相反
    #   结论,二者分别因「不拆已建立的 localhost 连接」与「静默失败没杀掉进程」
    #   而无效 —— 复现本缺口必须用半开,勿再走那两条弯路)。
    #   两文件均有实质改动,按 4.3.0 既裁先例双双 bump。
    # 4.3.7(灵机推演免责声明可见性轮):index.html ①移除 #predictCard 的整卡 title
    #   悬浮提示 —— 触屏无 hover,写在 title 里的「预测仅供参考」在手机上等于没写,
    #   而手机是本产品主场;且整卡挂 title 会让鼠标掠过卡面任意处都弹出一大段文字
    #   盖住号位本身。②同处新增常驻角标 .predict-ref「仅供参考」,落在 .predict-head
    #   内 —— 该 head 在「等待数据 / VIP 锁态 / 常态」三种渲染分支下恒在,而
    #   .predict-foot 在无命中率时整行为空,免责声明不能有分支能把它吃掉。
    #   app.css ③新增 .predict-ref(取现成 --gilt/--gilt-soft,实算对比度 4.59:1,
    #   过 AA 4.5 门槛,与既有 VIP 锁态条 4.61 同档)+ 驾驶舱形态尺寸覆写
    #   ④.predict-title 补 flex-wrap:wrap,超窄视口宁可折行不许溢出卡面。
    #   index.html 与 app.css 均有实质改动;按 4.3.0 既裁先例(「js/css 版本参
    #   同文件内一致,故一并推进」)双双 bump —— app.js 本轮未动亦须同步,
    #   漏 bump 则经 CDN/带缓存的老客户端会拿到「新 HTML + 旧 CSS」的半新半旧
    #   状态,角标以裸文字出现,比全旧更糟。
    # 4.4.0(basic 在线累计窗):app.js 改了快照格式(v2→v3)、断档处置、连空口径、
    # 序列断口标记;app.css 新增 .bead[data-gap] 断口样式 —— 前端有实质改动,
    # 按既有约定必须 bump 并同步本钉。**尤其是快照升版**:老页面若继续跑旧包,
    # 会拿 v2 快照喂 v3 解码路径(hydrate 直接判否,序列空着等首拉),
    # 表现为"刷新后序列短暂空白",而重启服务器同样不会好(客户端侧缓存)。
    # 4.6.0(命中率口径修正 + 补算):app.js 新增 predStatText/predStatTitle
    # (回测溯源标注)与「徽标只认实盘判定」的过滤 —— 老页面继续跑旧包时,
    # 后端补算照常落库、accuracy 照常回 replay 字段,而用户端**完全看不到**这两处
    # 诚实化:命中率里混着回测数却不标注、「上局开X·主中」把补算判定当战绩显示。
    # 这正是本钉要防的「后端生效了、用户端毫无变化」,且重启服务器不会好。
    #
    # ★ 4.7.5 债务清理:本钉自 4.6.0 起就**没再跟着 bump**,而 index.html 一路
    #   走到 4.7.4(4.7.0 移动端战况 / 4.7.1 占位珠 / 4.7.2 贴底守卫 /
    #   4.7.3 序列夹紧 / 4.7.4 行轨道塌陷,每一轮 app.js 都有实质改动)。
    #   于是本用例在 4.7.5 动工**之前就已经是红的** —— 实跑确证:本文件
    #   12 passed / 1 failed,失败的正是这一条。这类「钉子自己锈死」比没有钉子
    #   更坏:红灯变成常态,真正的漏 bump 就淹没在噪声里。
    #   对策不是把它再钉死到 4.7.5(下一轮又锈),而是改成**下界式**断言:
    #   只要求 js/css 同版本、且不低于本轮基线 —— 往后正常 bump 一律自动放行,
    #   唯独「app.js 改了却不 bump」会红。既有的历史残值禁令原样保留。
    # 4.7.5(灵机推演命中率行文案收束):移除回测溯源角标 —— 老页面继续跑旧包时
    #   照旧看得见角标,本轮改动等于没部署,且重启服务器不会好。
    # 4.7.7(注册用户名字符集收窄为 [A-Za-z0-9]):app.js 的 doRegister 换了字段级
    #   校验、index.html 换了 placeholder —— 老页面继续跑旧包时,中文用户名在前端
    #   照旧放行,用户白付一次 PoW(0.3-1.5s)并烧掉一次 R1 配额(默认 5 次/时)
    #   才被后端打回,正是「前后端漂移」本身;且重启服务器不会好。
    _vs = set(re.findall(r"app\.(?:js|css)\?v=([0-9.]+)", html))
    assert len(_vs) == 1, f"index.html 里 js/css 版本不一致:{_vs}"
    _cur = tuple(int(x) for x in _vs.pop().split("."))
    assert _cur >= (4, 7, 7), \
        f"app.js/app.css 的 ?v= 停在 {_cur},低于 4.7.7 基线 —— 前端改了却没 bump"
    assert "?v=4.4.0" not in html
    assert "?v=3.9.5" not in html and "?v=3.9.4" not in html
    # 词边界禁令:裸子串 `"?v=4.0.1" not in html` 会在未来 ?v=4.0.10 上假红
    # (与 test_config_registry 曾修的 STA_[A-Z_]+ 正则截断同类)。\b 只认
    # 完整的 4.0.0/4.0.1/4.0.2 残留 —— 4.0.10 的下一字符是数字,词边界不成立。
    assert re.search(r"\?v=4\.0\.(0|1|2)\b", html) is None
    assert re.search(r"\?v=4\.1\.[0-2]\b", html) is None   # 4.2.1 起禁 4.1.x 残留
    assert re.search(r"\?v=4\.2\.\d+\b", html) is None   # 4.3.0 起禁 4.2.x 全系残留(\d+ 整段吃数字,无 4.0.10 式截断假红)
    assert re.search(r"\?v=4\.3\.0\b", html) is None   # 4.3.1 起禁 4.3.0 残留
    assert re.search(r"\?v=4\.3\.1\b", html) is None   # 4.3.2 起禁 4.3.1 残留
    assert re.search(r"\?v=4\.3\.2\b", html) is None   # 4.3.3 起禁 4.3.2 残留(漏 bump 补齐轮)
    assert re.search(r"\?v=4\.3\.3\b", html) is None   # 4.3.4 起禁 4.3.3 残留
    assert re.search(r"\?v=4\.3\.[45]\b", html) is None   # 4.3.6 起禁 4.3.4/4.3.5 残留
    assert re.search(r"\?v=4\.3\.[0-9]+\b", html) is None   # 4.4.0 起禁 4.3.x 残留


def test_web_card_contract_guard():
    """web.py 源码契约:卡片不得回退出「伪装新鲜」的 lastOkAt(旧式 `or srv`);
    dataOkAt/mode 必须在卡片输出中;冷标消费必须经双开关 gate 的批取助手。"""
    card = _seg(WEB_SRC, "async def _live_room_card", "\nasync def ")
    assert '_iso(_snap_int(snap, "lastOkAt") or srv)' not in card
    for kw in ('"dataOkAt"', '"mode"', "histLastOkMs"):
        assert kw in card, f"_live_room_card 缺少 {kw}"
    helper = _seg(WEB_SRC, "async def _cold_room_set", "\ndef ")
    assert "curated_idle_enabled" in helper and "cold_members" in helper
    build = _seg(WEB_SRC, "async def _build_live_rooms", "\nasync def ")
    assert "_cold_room_set()" in build and "histIntervalS" in build
