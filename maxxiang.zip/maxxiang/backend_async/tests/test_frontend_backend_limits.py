"""
test_frontend_backend_limits.py — 前后端常量一致性守卫(零依赖)
================================================================================
账号上限有两处:后端 `AccountStore.MAX_ACCOUNTS`(硬限,upsert 新增分支直接拒)
与前端 `assets/app.js` 的 `MAX_ACCOUNTS`(闸在扫码之前,免得白扫一次码)。
两者必须同值 —— 否则要么前端提前拦住合法的第 10 个账号,要么放人扫完码才被后端打脸。

直播间上限 `MAX_ROOMS`:3.7.0 及未启用登录时是纯前端闸(后端 /api/monitor/add
无对应限制);3.8.0 登录系统启用后,后端按账号名额闸 `userauth.room_max` 与之
对应 —— 两值必须同值,否则前端放行的第 50 房会被后端 rooms_full 打脸(或反之
前端提前拦住合法额度)。这里同时钉住取值与两侧一致性。
"""
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.accounts.accounts_backend import AccountStore  # noqa: E402

APP_JS = Path(__file__).resolve().parents[2] / "assets" / "app.js"


def _js_const(name: str) -> int:
    """从 app.js 里抠出 `const NAME = <int>;`(注释与空白无关)。"""
    src = APP_JS.read_text(encoding="utf-8")
    m = re.search(rf"^const\s+{re.escape(name)}\s*=\s*(\d+)\s*;", src, re.M)
    assert m, f"assets/app.js 里找不到 `const {name} = <数字>;`"
    return int(m.group(1))


def test_app_js_exists():
    assert APP_JS.is_file(), f"预期的前端入口不存在:{APP_JS}"


def test_account_limit_matches_backend():
    """前端闸必须与后端硬限同值。改一处忘另一处 → 本用例失败。"""
    assert _js_const("MAX_ACCOUNTS") == AccountStore.MAX_ACCOUNTS == 10


def test_room_limit_is_fifty():
    assert _js_const("MAX_ROOMS") == 50


def test_room_limit_matches_login_quota():
    """3.8.0:登录态后端名额闸(userauth.room_max 默认值)必须与前端 MAX_ROOMS 同值。"""
    from app.settings import UserAuthCfg  # noqa: PLC0415
    assert UserAuthCfg().room_max == _js_const("MAX_ROOMS")


def _norm(src: str) -> str:
    """剥掉块注释与行注释 + 折叠空白:断言不被换行/缩进/注释改动误伤,
    但仍能捕获真代码被删。
    · 行注释必须剥 —— 否则 `if (roomsFull())` 与它后面那段中文注释黏在一起,
      断言就得跟着注释走,一改注释就假红。
    · 块注释也必须剥 —— 源码里有好几处 /* */ 在追述「旧的 setInterval(pollNew, 8000)」,
      不剥的话「定频轮询已拆除」这条断言会被自己的注释误伤(实测假红)。"""
    src = re.sub(r"/\*.*?\*/", "", src, flags=re.S)
    src = re.sub(r"//[^\n]*", "", src)
    return re.sub(r"\s+", " ", src)


# 每个 entry point 一条:闸被删 / 被改名 / 调用点被注释掉 → 对应断言失败。
# 这是**接线冒烟检查**,不是行为测试(行为由浏览器端到端覆盖);
# 但它必须能抓住「删掉调用点」——曾经写成 `"roomsFull()" in src` 的版本抓不住,
# 因为别处还有同名调用,字符串照样在文件里,测试假绿。
GATE_SITES = [
    # ① 「＋ 添加直播间」入口:满了不开弹窗
    "if (roomsFull()) return toast(ROOMS_FULL_TIP);",
    # ② 提交时:已在名录的房号只切房、不占名额,故只拦新增
    "if (!exists && roomsFull()) return void (D.addRoomMsg.textContent = ROOMS_FULL_TIP);",
    # ③ 房号预校验有数秒 await,落库前复查(与 ② 只差 `!exists &&`,不会互相顶替)
    "if (roomsFull()) return void (D.addRoomMsg.textContent = ROOMS_FULL_TIP);",
    # ④ 扫码弹窗:满了不生成二维码
    "if (acctsFull()){ toast(ACCTS_FULL_TIP); return; }",
    # ⑤ 「刷新二维码」同样过闸
    "if (acctsFull()){",
]


@pytest.mark.parametrize("site", GATE_SITES)
def test_gate_wired_at_each_entry_point(site):
    assert _norm(site) in _norm(APP_JS.read_text(encoding="utf-8")), \
        f"容量闸的这个调用点不见了:{site}"


def test_gate_call_sites_counted():
    """再钉一道:数调用次数。改名/删点会让计数掉下来。"""
    src = APP_JS.read_text(encoding="utf-8")
    assert len(re.findall(r"\broomsFull\(\)", src)) >= 5   # 定义 1 + 调用 4
    assert len(re.findall(r"\bacctsFull\(\)", src)) >= 4   # 定义 1 + 调用 3


# ── 3.2.0 自适应拉取:两处自学习都必须是 AIMD,不能退回「成功就加余量」的 EMA ──
def test_no_fixed_interval_polling():
    """定频轮询必须已拆除:setInterval(pollNew, ...) 不复存在。
    注意必须走 _norm() 剥掉注释 —— 源码里有好几处注释在追述「旧的
    setInterval(pollNew, 8000)」,直接对原文做正则会被自己的注释误伤。"""
    src = _norm(APP_JS.read_text(encoding="utf-8"))
    assert not re.search(r"setInterval\s*\(\s*pollNew", src), "8s 定频轮询又回来了"
    assert "schedulePolls" in src and "isBehind" in src


def test_aimd_not_ema():
    """learnLag / predChase 的自学习必须有『下降压力』(首拉即中就往前探)。
    写成「成功就 EMA(耗时)+ 固定余量」会单调爬到上限,稳态退化成每局固定几枪 ——
    实现时真的栽过一次(同局重试间隔 2.14→3.82→5.90s 一路爬满)。"""
    src = _norm(APP_JS.read_text(encoding="utf-8"))
    for probe in ("S.lagMs - LAG_PROBE_MS", "S.predSettleMs - PRED_PROBE_MS"):
        assert probe in src, f"自学习少了加性递减(往前探)这一半:{probe}"
    # 上下界必须夹住,否则学歪了会跑飞
    for guard in ("clampN(LAG_MIN_MS", "clampN(PRED_SETTLE_MIN"):
        assert guard in src, f"自学习没有夹上下界:{guard}"


def test_wall_clock_jump_detected_with_monotonic_clock():
    """系统时间往回跳是 isBehind() 唯一的死锁模式,必须主动探测,
    且时基必须是单调钟(performance.now()),不能用 Date.now() 自己去测自己。"""
    src = _norm(APP_JS.read_text(encoding="utf-8"))
    assert "Date.now() - performance.now()" in src
    assert "detectWallJump" in src
    assert "S.lastDataPerf = performance.now()" in src   # 保险丝也走单调钟


def test_hidden_tab_is_silent():
    """后台标签页不得继续拉取(浏览器的定时器节流是策略性的,不能指望)。"""
    src = _norm(APP_JS.read_text(encoding="utf-8"))
    assert "if (!S.alias || S.offline || document.hidden) return;" in src


def test_pending_bead_never_renders_seal_glyph():
    """出怪序列 / 近24h战况 的末位悬挂珠:施法期与备战期连续读秒,不得再出现「封」字。
    三处渲染点(tick / aideTick / rgUpdateRound)都不该把 '封' 写进 textContent。"""
    src = APP_JS.read_text(encoding="utf-8")
    # 只看代码行,注释里出现「备战」是正常的
    code = "\n".join(
        line.split("//")[0] for line in src.splitlines()
        if not line.lstrip().startswith(("*", "/*", "//"))
    )
    for pat in (r"pendTxt\s*=\s*[^;]*'封'", r"textContent\s*=\s*[^;]*'封'"):
        assert not re.search(pat, code), f"悬挂珠仍会显示「封」:{pat}"
