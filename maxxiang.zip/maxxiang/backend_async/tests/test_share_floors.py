#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
test_share_floors.py — 逐号份额地板（fr_share_floors）的守卫

守什么（每条都对应一个已被实地核查坐实的结论，改坏了 CI 直接红）：
  1. 不配置 fr_share_floors 时，与改造前**逐位同解** —— 回滚安全。
  2. 配置后，每个被钉号的目标份额**必须**达到其地板 —— 这是本组刻度的全部承诺。
  3. 地板约束**不含 p̂** ⇒ 对任意概率估计都成立（这正是它优于聚合下限的地方：
     聚合下限 Σp̂_i s_i ≥ L 会被 p̂ 的估计噪声骗过去，实测达标率仅 29.5%）。
  4. 聚合约束会被**最便宜的成员**满足 —— 这条是本次改造的立论，用反例钉死：
     只给"稀有命中率≥3%"而不给逐号地板时，号9 会趴在下界不动。
  5. 地板之和 + 其余号的 share_min 不得超过 4（Σs=4 是硬预算），越界必须
     走放宽路径而不是抛异常把 predict() 打崩。
  5b.**放宽时不得把 fr_share_min 这层保底一起冲掉**。这是 4.9.0 复查抓到的真缺陷：
     单个写过头的地板（如 "3:1.5" 而 fr_share_max=0.8）会让 LP 不可行，而原放宽
     顺序把 share_min 排在 share_floors 之前 —— 结果一个 typo 就落进项目明令防范的
     "号饿死几百上千局"配置。已双管齐下：解析时把每个地板钳到 share_max，
     且放宽顺序改成 share_floors 先于 share_min。
  （why 落款的诚实性守卫不在此重复 —— test_frontier.py 已有行为级版本。）
"""
import itertools
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))


def _find_root(start):
    """向上找到含 jiufa_data/ 的仓库根 —— 不假设本文件被放在哪一层。"""
    d = start
    for _ in range(6):
        if os.path.isdir(os.path.join(d, "jiufa_data")):
            return d
        nd = os.path.dirname(d)
        if nd == d:
            break
        d = nd
    return start


ROOT = _find_root(HERE)
for cand in (os.environ.get("STA_ENGINE_DIR", ""), os.path.join(ROOT, "jiufa_data")):
    if cand and cand not in sys.path and os.path.isdir(cand):
        sys.path.insert(0, cand)

import frontier_planner as FP  # noqa: E402

ALL_SETS = list(itertools.combinations(range(1, 10), 4))
MULT = {1: 10, 2: 50, 3: 330, 4: 250, 5: 100, 6: 100, 7: 50, 8: 50, 9: 500}
COLD = (3, 4, 5, 6, 9)
RARE = (3, 9)
# 三房 7 天 36,278 局实测频率（window_audit/prob_drift.py 可复跑）
P_REAL = [0.18375, 0.15695, 0.04929, 0.06525, 0.09331, 0.09673, 0.15720, 0.16192, 0.03561]
P_REAL = [v / sum(P_REAL) for v in P_REAL]


def shares(mix):
    s = [0.0] * 9
    for S, w in mix.items():
        for c in S:
            s[c - 1] += w
    return s


def test_no_floors_is_byte_equivalent_to_legacy():
    """1. 不传 share_floors ⇒ 与原版同解（回滚路径）。"""
    kw = dict(cold_min=0.1232, rare_min=0.0180, ret_min=8.624,
              share_min=0.08, share_max=0.8)
    mix, diag = FP.plan(P_REAL, MULT, COLD, RARE, **kw)
    assert abs(diag["hit"] - 0.5315504) < 1e-6, diag["hit"]
    assert not diag["relaxed"]
    s = shares(mix)
    assert abs(sum(s) - 4.0) < 1e-9


@pytest.mark.parametrize("floors", [
    {3: 0.40, 9: 0.30, 4: 0.20, 5: 0.20, 6: 0.20},          # H1 定稿刻度
    {3: 0.30, 9: 0.20, 4: 0.15},
    {9: 0.50},
])
def test_floors_are_actually_met(floors):
    """2. 每个被钉号的份额必须达到地板（这是本组刻度的全部承诺）。"""
    mix, diag = FP.plan(P_REAL, MULT, COLD, RARE, cold_min=None, rare_min=None,
                        ret_min=None, share_min=0.08, share_max=0.8,
                        share_floors=floors)
    assert not diag["relaxed"], diag["relaxed"]
    s = shares(mix)
    for c, fl in floors.items():
        assert s[c - 1] >= fl - 1e-6, f"号{c} 份额 {s[c-1]:.4f} < 地板 {fl}"


@pytest.mark.parametrize("scale", [0.5, 0.8, 1.0, 1.3, 2.0])
def test_floors_hold_under_any_probability_estimate(scale):
    """3. 地板不含 p̂ ⇒ 概率怎么漂都必须成立。这正是它优于聚合下限之处。"""
    p = [v ** scale for v in P_REAL]
    p = [v / sum(p) for v in p]
    floors = {3: 0.40, 9: 0.30, 4: 0.20, 5: 0.20, 6: 0.20}
    mix, diag = FP.plan(p, MULT, COLD, RARE, cold_min=None, rare_min=None,
                        ret_min=None, share_min=0.08, share_max=0.8,
                        share_floors=floors)
    s = shares(mix)
    for c, fl in floors.items():
        assert s[c - 1] >= fl - 1e-6, f"scale={scale} 号{c} 份额 {s[c-1]:.4f} < {fl}"


def test_aggregate_constraint_is_satisfied_by_cheapest_member():
    """4. 立论反例：聚合"稀有≥3%"不逼号9 出场 —— 它全由号3 顶掉。
    这条红了就说明"聚合下限够用、逐号地板多余"，本次改造的前提被推翻。"""
    mix, _ = FP.plan(P_REAL, MULT, COLD, RARE, cold_min=None, rare_min=0.030,
                     ret_min=None, share_min=0.08, share_max=0.8)
    s = shares(mix)
    assert s[8] < 0.15, f"号9 份额 {s[8]:.4f} —— 若已 >0.15 说明聚合下限已能带动号9"
    assert s[2] > 0.40, f"号3 份额 {s[2]:.4f} —— 聚合下限应由最便宜成员(号3)顶掉"


def test_over_budget_floors_relax_instead_of_crash():
    """5. 地板之和越过 Σs=4 的硬预算时必须走放宽路径，不得抛异常。"""
    mix, diag = FP.plan(P_REAL, MULT, COLD, RARE, cold_min=None, rare_min=None,
                        ret_min=None, share_min=0.08, share_max=0.8,
                        share_floors={c: 0.95 for c in range(1, 10)})
    assert mix, "越界配置不得产出空方案"
    assert abs(sum(shares(mix)) - 4.0) < 1e-6
    assert "share_floors" in (diag["relaxed"] or []) or diag["relaxed"]


def test_config_registry_and_yaml_agree():
    """6. 三方同值：引擎 dataclass / config.yaml / 注册表。"""
    import spell_tamer_monitor as E
    assert "fr_share_floors" in E.PredictionConfig.__dataclass_fields__
    y = os.path.join(ROOT, "backend_async", "config.yaml")
    if os.path.exists(y):
        import yaml
        cfg = yaml.safe_load(open(y, encoding="utf-8"))["prediction"]
        raw = str(cfg.get("fr_share_floors", "") or "")
        for kv in [x for x in raw.split(",") if ":" in x]:
            c, v = kv.split(":", 1)
            assert 1 <= int(c) <= 9 and 0 < float(v) <= 1.0, kv


@pytest.mark.parametrize("floors,share_max", [
    ({3: 1.5}, 0.8),                              # 单值越界（钳位前会让 LP 不可行）
    ({c: 0.95 for c in range(1, 10)}, 0.8),       # 全员越预算
    ({3: 0.9, 4: 0.9, 5: 0.9, 6: 0.9, 9: 0.9}, 0.8),
])
def test_bad_floors_never_wipe_out_the_share_min_safety_net(floors, share_max):
    """5b. 越界/越预算的地板配置必须退回 share_min 保底，而不是把保底也冲掉。

    反例价值：改回"share_min 先于 share_floors 放宽"或去掉解析钳位，本测试必红。
    """
    mix, _diag = FP.plan(P_REAL, MULT, COLD, RARE, cold_min=None, rare_min=None,
                         ret_min=None, share_min=0.08, share_max=share_max,
                         share_floors={c: min(share_max, v) for c, v in floors.items()})
    s = shares(mix)
    assert abs(sum(s) - 4.0) < 1e-6
    assert min(s) >= 0.08 - 1e-6, (
        f"最小份额 {min(s):.4f} < share_min 0.08 —— 保底被放宽链冲掉了，"
        "这正是 4.9.0 复查修掉的缺陷")


def test_relax_order_drops_floors_before_share_min():
    """放宽顺序的直接断言（顺序写反时上一条也会红，这条给出更清晰的失败信息）。"""
    import inspect
    src = inspect.getsource(FP.plan)
    i_fl = src.find('"share_floors"')
    i_sm = src.find('("share_min"')
    assert i_fl > 0 and i_sm > 0
    assert i_fl < i_sm, "share_floors 必须排在 share_min 之前被放宽（见 5b）"


def _live_cfg(**over):
    import yaml
    y = os.path.join(ROOT, "backend_async", "config.yaml")
    cfg = dict(yaml.safe_load(open(y, encoding="utf-8"))["prediction"])
    cfg.update(over)
    return cfg


def _bridge(cfg):
    import importlib.util
    sp = importlib.util.spec_from_file_location(
        "pb", os.path.join(ROOT, "backend_async", "app", "predictor_bridge.py"))
    pb = importlib.util.module_from_spec(sp)
    sp.loader.exec_module(pb)
    import yaml
    ids = dict(yaml.safe_load(open(os.path.join(ROOT, "backend_async", "config.yaml"),
                                   encoding="utf-8"))["custom_beast_ids"])
    return pb.PredictorBridge(cfg, ids)


def _seq(n=2500):
    import random
    r = random.Random(7)
    return [r.choice([1, 1, 2, 2, 3, 4, 5, 6, 7, 7, 8, 8, 9]) for _ in range(n)]


def test_changing_floors_forces_immediate_replan():
    """热改 fr_share_floors 必须当场重解 LP，不得被 fr_replan 的节拍拖住。

    配置指纹 `_key` 漏掉 _fl 时本测试红（运维改完期望的是「立刻生效」）。
    """
    seq = _seq()
    a = _bridge(_live_cfg(explore_style="frontier", fr_replan=100000,
                          fr_share_floors="9:0.60")).run_prediction("r", seq, {})[0]
    b = _bridge(_live_cfg(explore_style="frontier", fr_replan=100000,
                          fr_share_floors="3:0.60")).run_prediction("r", seq, {})[0]
    ka, kb = {}, {}
    sa = sb = 0
    ba = _bridge(_live_cfg(explore_style="frontier", fr_replan=100000,
                           fr_share_floors="9:0.60"))
    bb = _bridge(_live_cfg(explore_style="frontier", fr_replan=100000,
                           fr_share_floors="3:0.60"))
    for i in range(2300, 2400):
        ra, da = ba.run_prediction("r", seq[:i], ka); ka.update(da)
        rb, db = bb.run_prediction("r", seq[:i], kb); kb.update(db)
        sa += 9 in (tuple(ra["main"]) + tuple(ra["guard"]))
        sb += 3 in (tuple(rb["main"]) + tuple(rb["guard"]))
    assert sa >= 50 and sb >= 50, f"地板未生效：号9 出场 {sa}/100、号3 出场 {sb}/100"
    assert (a["main"], a["guard"]) is not None and (b["main"], b["guard"]) is not None


def test_dead_switches_under_non_showcase_style_are_loud():
    """切到非 showcase 风格时，若 anti_stubborn/showcase_rotate/repeat_guard 还开着，
    引擎必须 WARNING —— 否则运维照着 config.yaml 的长篇说明调 as_*/sc_*/rg_*，
    一个字也不会生效却查不到原因（本仓库 hot_rotate 的同款病）。

    4.9.7:判定由「文案含『不生效』」收紧为「文案点名了哪几个开关」。
    原写法是子串匹配,而同一批新增了**反方向**告警(非 frontier 风格下 fr_* 惰性,
    见 predictor_bridge._warn_inert_frontier_keys),两条文案都含「不生效」⇒
    原断言会把反向告警误判成「showcase 下误报」。两条告警各自守各自的键集,
    这里按键名区分,顺带把反向告警也钉住。
    """
    import io
    import logging
    buf = io.StringIO()
    h = logging.StreamHandler(buf)
    lg = logging.getLogger("predictor")
    lg.addHandler(h)
    lg.setLevel(logging.WARNING)
    _SW = ("anti_stubborn", "showcase_rotate", "repeat_guard")
    try:
        cfg = _live_cfg(explore_style="frontier", anti_stubborn=True,
                        showcase_rotate=True, repeat_guard=True)
        _bridge(cfg).run_prediction("r", _seq(), {})
        got = buf.getvalue()
        assert "不生效" in got and all(k in got for k in _SW), f"死开关无告警:{got[:200]}"
        buf.truncate(0); buf.seek(0)
        _bridge(_live_cfg(explore_style="showcase")).run_prediction("r", _seq(), {})
        got = buf.getvalue()
        # ① 三个总开关在 showcase 下是**真生效**的,不得被点名为失效
        for k in _SW:
            assert k not in got, f"showcase 下误报 {k}:{got[:200]}"
        # ② 反向:fr_* 在 showcase 下确实惰性,必须喊。
        # 〔4.9.8 修正〕原断言写死 `"fr_share_floors" in got`,隐含「config.yaml 里
        #   fr_share_floors 非空」这个前提 —— 4.9.8 把它清空、改用三条聚合下限后,
        #   告警文案只会点名**实际配置了的**那些键,该断言当场变红。这是断言与配置
        #   耦合过紧,不是告警坏了。改成「至少点名一个 fr_* 键」,对两种配置都成立。
        _FR_ANY = ("fr_share_floors", "fr_cold_min", "fr_rare_min", "fr_ret_min",
                   "fr_share_min", "fr_share_max", "fr_main_share_min")
        assert "不生效" in got and any(k in got for k in _FR_ANY), (
            f"非 frontier 风格下 fr_* 惰性未告警:{got[:200]}")
    finally:
        lg.removeHandler(h)


def test_dead_switches_really_are_dead_under_frontier():
    """上一条的立论：frontier 下开/关这三个总开关，四码必须逐字节相同。
    若哪天它们在 frontier 域内也生效了，本测试会红 —— 届时告警文案必须同步改。"""
    seq = _seq()
    on = _bridge(_live_cfg(explore_style="frontier", anti_stubborn=True,
                           showcase_rotate=True, repeat_guard=True)
                 ).run_prediction("r", seq, {})[0]
    off = _bridge(_live_cfg(explore_style="frontier", anti_stubborn=False,
                            showcase_rotate=False, repeat_guard=False)
                  ).run_prediction("r", seq, {})[0]
    assert (on["main"], on["guard"]) == (off["main"], off["guard"])


def test_infeasible_floor_config_is_loud_at_bridge_construction():
    """露面配额本身超预算 / 高于上限 / 上限过小时，桥构造期必须 WARNING。

    背景（4.9.0 第五轮复查的可观测性缺口）：plan() 在约束不可行时会**静默放宽**，
    而放宽记录只出现在 explore.why（前端 4.9.6 起不再渲染）与 explore_state.frq
    （无任何 admin/API 出口）。于是「配置写错 → 引擎换了套约束在跑」完全查不到。
    这里把**与 p̂ 无关**的那部分在启动时就喊出来。
    """
    import io
    import logging
    lg = logging.getLogger("predictor")
    lg.setLevel(logging.WARNING)

    def warns(**over):
        buf = io.StringIO()
        h = logging.StreamHandler(buf)
        lg.addHandler(h)
        try:
            _bridge(_live_cfg(explore_style="frontier", **over))
        finally:
            lg.removeHandler(h)
        return [x for x in buf.getvalue().split("\n") if x.strip() and "不生效" not in x]

    assert not warns(), "定稿配置不该报可行性告警"
    assert any("钳平" in w for w in warns(fr_share_floors="3:1.5")), "地板越上限未告警"
    over = warns(fr_share_floors=",".join(f"{c}:0.95" for c in range(1, 10)))
    assert any("份额之和" in w for w in over), "地板超 Σs=4 预算未告警"
    assert any("太小" in w for w in warns(fr_share_max=0.3)), "share_max 过小未告警"


def test_mixed_constraint_regimes_are_loud():
    """逐号地板与旧聚合下限同时生效时必须提示 —— 配置中枢陈旧覆盖的典型症状。

    背景（4.9.0 第六轮复查）：`config_revisions.snapshot` 是**累积继承**的，运维
    改过的键会永久留在快照里并在每次启动/热更盖掉 config.yaml；而 `fr_share_floors`
    是新键、不在旧快照里 ⇒ 从 yaml 生效。混合态不崩，但静默变成另一套配置
    （实测总命中 53.08%→50.48%），config.yaml 上一个字都看不出来。
    """
    import io
    import logging
    lg = logging.getLogger("predictor")
    lg.setLevel(logging.WARNING)

    def hit(**over):
        buf = io.StringIO()
        h = logging.StreamHandler(buf)
        lg.addHandler(h)
        try:
            _bridge(_live_cfg(**over))
        finally:
            lg.removeHandler(h)
        return sum(1 for x in buf.getvalue().split("\n") if "同时生效" in x)

    # 〔4.9.8 修正〕下面两条原写成 hit(explore_style="frontier", fr_cold_min=…),
    #   隐含「config.yaml 的 fr_share_floors 非空」这个前提。4.9.8 定稿把地板清空
    #   (改用三条聚合下限)后,只加一个聚合下限**不构成混合态**,原断言当场变红。
    #   混合态的定义是「地板 + 聚合下限同时在」⇒ 必须把地板显式传进来才测得到它,
    #   这样对 yaml 里地板空/非空两种情形都成立,断言不再与配置耦合。
    _FLOORS = "3:0.40,9:0.30,4:0.20,5:0.20,6:0.20"        # 4.9.0~4.9.7 的出厂地板
    assert hit(explore_style="frontier") == 0, "定稿配置不该报混合态"
    assert hit(explore_style="frontier", fr_share_floors=_FLOORS,
               fr_cold_min=0.1232) == 1, "混合态未告警"
    assert hit(explore_style="frontier", fr_share_floors=_FLOORS,
               fr_ret_min=8.624) == 1, "混合态未告警"
    assert hit(explore_style="frontier", fr_share_floors="", fr_cold_min=0.1232) == 0
    assert hit(explore_style="showcase", fr_cold_min=0.1232) == 0
    # 4.9.8 定稿本身(地板空 + 三条聚合下限全 >0)必须判为**非**混合态
    assert hit(explore_style="frontier", fr_share_floors="", fr_cold_min=0.116633,
               fr_rare_min=0.01683, fr_ret_min=8.358387) == 0, "定稿被误判为混合态"
