"""
test_pred_replay.py — 命中率补算(4.6.0)的机器保证
================================================================================
钉死五类不变量:

  A. **零前视**:补算第 t 局时,喂给引擎的训练序列绝不含第 t 局及之后的数据。
     用一个记账假桥把每次 run_prediction 的入参截下来逐条核验。
  B. **热身闸**:gen_idx < replay_warmup 的目标局一行都不写(实测热身不足时
     命中率偏差可达 6pp,而 100 局样本 1σ 才 4.7pp —— 宁缺毋滥)。
  C. **判定同规则**:_hit_of 与 db.fill_prediction_outcome 的三元表达式逐字一致
     (主优先)。两处分歧会让补算行与实盘行口径不可比。
  D. **落库语义**:补算 SQL 恒 ON CONFLICT DO NOTHING(绝不覆盖实盘行)、
     source 恒钉 'replay'(不接受调用方传值)、RETURNING 用于真实计数。
  E. **窗口锚定**:db.accuracy 必须带 round_id 区间谓词,且下界恰为
     anchor-(window-1)*ROUND_STEP —— 这是本次修复的核心,退化即变红。

另有一条**真机还原度验收**(F):仓库自带的 jiufa_data/spell_tamer_data.db 里有
三个房各 1500+ 局真实出怪与真机落库预测。用补算把最后 100 局重跑一遍,断言
逐局判定还原率与命中率偏差落在实测区间内。数据库不在时自动跳过。
"""
from __future__ import annotations

import json
import os
import sqlite3
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.constants import ROUND_STEP                      # noqa: E402
from app.db import SRC_REPLAY, _build_replay_pred_sql     # noqa: E402
from app.pred_replay import _hit_of, plan_span, replay_window  # noqa: E402

_ROOT = Path(__file__).resolve().parents[2]
_DB = _ROOT / "jiufa_data" / "spell_tamer_data.db"
_needs_db = pytest.mark.skipif(not _DB.exists(), reason="需要仓库自带真机数据库")


# ══════════════════════════════════════════════════════════════════════════
# 假桥:记账每次 run_prediction 的入参,并给出确定性的假预测
# ══════════════════════════════════════════════════════════════════════════
class _PCfg:
    """替身的 pcfg。真 PredictorBridge 的 pcfg 是 E.PredictionConfig 实例;
    worker._replay_room 从**这一份**取训练窗与 max_train(与配置指纹同源,
    见其行内注),替身必须同形,否则测的就不是生产走的那条路。"""

    def __init__(self, tw=0.0, mt=5000):
        self.train_window_hours = tw
        self.max_train = mt


class _SpyBridge:
    def __init__(self, tw=0.0, mt=5000):
        self.pcfg = _PCfg(tw, mt)
        self.seqs = []          # 每次 run_prediction 收到的训练序列
        self.settles = []       # 每次 update_after_settle 收到的 (detail, cid)

    def run_prediction(self, room, seq, kv):
        self.seqs.append(list(seq))
        n = len(seq)
        return ({"main": [1, 2], "guard": [3, 4],
                 "ens": [0.1] * 9, "models": {"M1": [0.1] * 9},
                 "weights": {}, "train_n": n},
                {"model_weights": json.dumps({"M1": 1.0})})

    def update_after_settle(self, room, detail, actual_cid, kv):
        self.settles.append((detail, actual_cid))
        return {}


def _mk_rounds(n, first=1_700_000_000_000, cids=None):
    """造 n 局连续出怪(round_id 即起局毫秒,步进 ROUND_STEP)。"""
    return [{"round_id": first + i * ROUND_STEP,
             "custom_id": (cids[i] if cids else (i % 9) + 1),
             "start_ms": first + i * ROUND_STEP,
             "draw_ms": first + i * ROUND_STEP + 40_000} for i in range(n)]


# ══════════════════════════════ A. 零前视 ══════════════════════════════════
def test_no_lookahead_in_training_sequence():
    """第 i 局处生成的预测,训练序列必须恰好是 rounds[..i] 的编号 —— 一个未来
    编号都不能进去。这是「补算合法」的全部根据,退化即造假。"""
    rounds = _mk_rounds(60)
    cids = [r["custom_id"] for r in rounds]
    br = _SpyBridge()
    replay_window(br, {"train_window_hours": 0, "max_train": 5000},
                  "321", rounds, [r["round_id"] for r in rounds], warmup=0)
    assert len(br.seqs) == len(rounds)
    for i, seq in enumerate(br.seqs):
        assert seq == cids[:i + 1], f"第 {i} 次预测的序列越界(含未来局)"


def test_training_window_cuts_by_start_ms():
    """train_window_hours 生效:窗外的老局被切掉,与 db.sequence 的
    `start_ms >= since` 同源。窗设 1h ⇒ 每次最多回看 72 局(3600s/50.001s)。"""
    rounds = _mk_rounds(200)
    br = _SpyBridge()
    replay_window(br, {"train_window_hours": 1.0, "max_train": 5000},
                  "321", rounds, [rounds[-1]["round_id"]], warmup=0)
    assert max(len(s) for s in br.seqs) <= 74, "训练窗未按 start_ms 收口"


def test_max_train_caps_sequence():
    rounds = _mk_rounds(120)
    br = _SpyBridge()
    replay_window(br, {"train_window_hours": 0, "max_train": 30},
                  "321", rounds, [rounds[-1]["round_id"]], warmup=0)
    assert max(len(s) for s in br.seqs) == 30


# ══════════════════════════════ B. 热身闸 ══════════════════════════════════
@pytest.mark.parametrize("warmup,expect", [(0, 49), (10, 39), (48, 1), (49, 0)])
def test_warmup_gate_drops_untrusted_rows(warmup, expect):
    """50 局 ⇒ 最多 49 个可结算目标(第 i 局的预测指向第 i+1 局);
    热身 w 时只保留 gen_idx ≥ w 的那些。热身超过可用长度 ⇒ 一行都不写。"""
    rounds = _mk_rounds(50)
    targets = [r["round_id"] for r in rounds]
    out = replay_window(_SpyBridge(), {"train_window_hours": 0, "max_train": 5000},
                        "321", rounds, targets, warmup=warmup)
    assert len(out) == expect


def test_warmup_recorded_in_detail():
    rounds = _mk_rounds(40)
    out = replay_window(_SpyBridge(), {"train_window_hours": 0, "max_train": 5000},
                        "321", rounds, [r["round_id"] for r in rounds],
                        warmup=10, now_ms_v=12345)
    assert out, "应有补算行"
    for rid, _m, _g, detail, _cid, _hit in out:
        assert detail["replay"]["warmup"] >= 10
        assert detail["replay"]["at"] == 12345
        assert len(detail["ens"]) == 9


def test_only_missing_targets_written_but_state_still_advances():
    """在**回放区间内**,不属于 missing 的局也要照跑(推进 Hedge 权重),
    只是不写 —— 漏跑会断链。区间起点由 warmup 决定(见下一条)。"""
    rounds = _mk_rounds(40)
    want = [rounds[-1]["round_id"]]
    br = _SpyBridge()
    out = replay_window(br, {"train_window_hours": 0, "max_train": 5000},
                        "321", rounds, want, warmup=20)
    assert [r[0] for r in out] == want
    # 起点 = 目标的生成局(下标 38)再往前 20 局 = 18 ⇒ 跑 18..39 共 22 局,
    # 其中 21 局有 pending 可结算。全部照跑,不因"不写"而跳过。
    assert len(br.seqs) == 22, f"回放区间长度不对:{len(br.seqs)}"
    assert len(br.settles) == 21, "区间内的结算必须每局照跑"


def test_pure_training_prefix_is_not_re_predicted():
    """★ 五轮复查:主循环**不得**对「纯训练窗前缀」逐局空跑预测。

    plan_span 会特意往前多取一个完整训练窗,那些局需要作为**数据**存在
    (bisect 会回看到),但不需要各跑一次预测。真机实测:窗 100 + 热身 400 时
    喂进 1778 局、其中 1278 局属此列 —— 逐局空跑是 3.6× 的无谓开销
    (6.63s → 2.26s),而按 replay_batch=8 算,那意味着 88% 单核而不是文档
    宣称的 27%。本钉防止它退化回去。
    """
    rounds = _mk_rounds(1000)
    want = [rounds[-1]["round_id"]]
    br = _SpyBridge()
    replay_window(br, {"train_window_hours": 0, "max_train": 5000},
                  "321", rounds, want, warmup=50)
    assert len(br.seqs) <= 60, \
        f"对全部 1000 局都跑了预测({len(br.seqs)} 次),纯训练窗前缀未跳过"
    assert len(br.seqs) >= 50, "热身长度不足,保真会掉"


def test_warmup_stamp_is_true_prediction_count_not_index():
    """起跑点前移后,绝对下标 ≠ 真实热身长度。detail.replay.warmup 必须记
    「生成该条预测之前已经跑过多少次预测」,否则热身闸与审计戳都会失真。"""
    rounds = _mk_rounds(500)
    want = [rounds[-1]["round_id"]]
    out = replay_window(_SpyBridge(), {"train_window_hours": 0, "max_train": 5000},
                        "321", rounds, want, warmup=30)
    assert len(out) == 1
    assert out[0][3]["replay"]["warmup"] == 30, out[0][3]["replay"]


def test_empty_inputs_are_noop():
    assert replay_window(_SpyBridge(), {}, "321", [], [1], 0) == []
    assert replay_window(_SpyBridge(), {}, "321", _mk_rounds(5), [], 0) == []


# ══════════════════════════ C. 判定同规则 ══════════════════════════════════
def test_hit_rule_is_main_first_and_matches_db():
    assert _hit_of(1, [1, 2], [1, 3]) == "main"      # 同时在主与防 → 主优先
    assert _hit_of(3, [1, 2], [3, 4]) == "guard"
    assert _hit_of(9, [1, 2], [3, 4]) == "miss"
    src = (_ROOT / "backend_async" / "app" / "db.py").read_text(encoding="utf-8")
    assert src.count('"main" if actual_cid in main_ids') == 1, \
        "db 侧判定表达式变了,_hit_of 必须同步"


def test_plan_span_reaches_back_far_enough():
    missing = [1_700_000_000_000]
    span = plan_span(missing, warmup=400, train_window_hours=24.0)
    assert missing[0] - span >= 400 * ROUND_STEP + 24 * 3600 * 1000
    assert plan_span([], 400, 24.0) == 0


# ══════════════════════════ D. 落库语义 ════════════════════════════════════
def test_replay_sql_never_overwrites_and_pins_source():
    rows = [(1_700_000_000_000, [1, 2], [3, 4], {"ens": []}, 7, "miss"),
            (1_700_000_050_001, [5, 6], [7, 8], {"ens": []}, 5, "main")]
    sql, args = _build_replay_pred_sql("321", rows)
    assert "ON CONFLICT (room_id, round_id) DO NOTHING" in sql, \
        "补算绝不许覆盖实盘行"
    assert "DO UPDATE" not in sql
    assert "RETURNING round_id" in sql, "需 RETURNING 才能数出真实插入行数"
    assert len(args) == 8 * len(rows)
    assert args[7] == SRC_REPLAY and args[15] == SRC_REPLAY
    assert args.count(SRC_REPLAY) == len(rows), "source 恒钉,不接受外部传值"


# ══════════════════════════ E. 窗口锚定 ════════════════════════════════════
class _FakeCon:
    def __init__(self, anchor, rows):
        self.anchor, self.rows, self.seen = anchor, rows, []

    async def fetchval(self, sql, *a):
        self.seen.append((sql, a))
        return self.anchor

    async def fetch(self, sql, *a):
        self.seen.append((sql, a))
        return self.rows

    async def fetchrow(self, sql, *a):
        self.seen.append((sql, a))
        return self.rows[0] if self.rows else None


class _FakePool:
    def __init__(self, con):
        self.con = con

    def acquire(self):
        con = self.con

        class _Ctx:
            async def __aenter__(self):
                return con

            async def __aexit__(self, *a):
                return False
        return _Ctx()


@pytest.mark.asyncio
async def test_accuracy_anchors_window_by_round_id():
    """本次修复的核心:accuracy 必须按「最近 window 局」取数,而不是
    「最近 window 条判定行」。下界须恰为 anchor-(window-1)*ROUND_STEP。"""
    from app.db import DB
    anchor = 1_700_000_000_000
    rows = [{"hit": "main", "round_id": anchor, "source": None},
            {"hit": "guard", "round_id": anchor - ROUND_STEP, "source": SRC_REPLAY},
            {"hit": "miss", "round_id": anchor - 2 * ROUND_STEP, "source": SRC_REPLAY}]
    con = _FakeCon(anchor, rows)
    db = DB.__new__(DB)
    db.pool = _FakePool(con)
    acc = await db.accuracy("321", 100)
    pred_sql, pred_args = con.seen[1]
    assert "round_id >= $2" in pred_sql, "缺区间谓词 = 回到「最近N条」的旧谎报"
    assert pred_args[1] == anchor - 99 * ROUND_STEP
    # 4.9.3:live_main/live_cover 是 README §10.1 预留的「实盘分列」正解字段,
    # 本轮兑现 —— 合并数 − 实盘数 必须恰等于 replay,口径自证。
    assert acc == {"window": 100, "n": 3, "main": 1, "cover": 2, "replay": 2,
                   "live_main": 1, "live_cover": 1,
                   "anchor": anchor, "first_id": anchor - 2 * ROUND_STEP,
                   "last_id": anchor}


@pytest.mark.asyncio
async def test_accuracy_zero_when_no_rounds():
    """一局出怪都没有 ⇒ 没有「近N局」可言,恒回零。此时若还拿孤儿预测行凑一个
    命中率,正是本次要修的谎报。"""
    from app.db import DB
    db = DB.__new__(DB)
    db.pool = _FakePool(_FakeCon(None, []))
    acc = await db.accuracy("321", 100)
    assert acc["n"] == 0 and acc["anchor"] == 0 and acc["replay"] == 0


# ═════════════════ F. 真机还原度验收(用仓库自带数据库) ══════════════════════
@_needs_db
@pytest.mark.parametrize("room", ["1275859", "2678075", "3746870"])
def test_replay_reproduces_live_hit_rate_on_real_data(room):
    """补算 vs 真机落库:热身 400 局时,逐局判定还原 ≥95%、命中率偏差 ≤3pp。

    阈值取自实测(判定 98~99%、偏差 ≤1pp)并留出余量 —— 它守的是「补算仍在
    可用区间」这条线,而不是复刻某个具体数字。四码**不**要求全同:ens 差异
    在 1e-3 量级而 explore_tie_eps=0.004,近似平局会翻位,这是结构性的。
    """
    import yaml
    os.environ.setdefault("STA_ENGINE_DIR", str(_ROOT / "jiufa_data"))
    from app.predictor_bridge import PredictorBridge
    cfg_all = yaml.safe_load(
        (_ROOT / "backend_async" / "config.yaml").read_text(encoding="utf-8"))
    cfg = dict(cfg_all["prediction"])
    # 反固执改造(anti_stubborn)上线后的口径钉:本用例对账的是**自带数据库里的
    # 历史落库行** —— 它们全部产生于改造上线之前(旧引擎行为)。补算保真度守的是
    # 「补算机制能还原生成那些行的当时口径」,故此处按历史口径关断开关;开关关时
    # 新引擎与旧引擎逐局字节级等价(改造期全量回放全同,见 test_anti_stubborn ②与
    # 交付物 replay_lab.py 的离线门禁)。今日口径(开关开)下补算的自还原性由
    # test_anti_stubborn 的确定性钉覆盖 —— 机制与刻度在此解耦,各守各线。
    cfg["anti_stubborn"] = 0
    # 冷位份额闭环(showcase_rotate)同理:自带库的历史落库行同样产生于该改造之前,
    # 故一并按历史口径关断(含指纹深度回到原版 3)。关态下新引擎与改造前逐局字节级
    # 等价(改造期全量回放全同,见 test_showcase_rotate ②与 window_audit/analyze_rotate.py
    # --gate --baseline)。今日口径下补算的自还原性由 test_showcase_rotate 的确定性钉覆盖。
    cfg["showcase_rotate"] = 0
    cfg["sc_fp_depth"] = 3
    con = sqlite3.connect(f"file:{_DB}?mode=ro", uri=True)
    rounds = [{"round_id": r[0], "custom_id": r[1], "start_ms": r[2], "draw_ms": r[3]}
              for r in con.execute(
                  "SELECT round_id,custom_id,start_ms,draw_ms FROM rounds"
                  " WHERE room_id=? AND custom_id IS NOT NULL ORDER BY round_id",
                  (room,))]
    live = {r[0]: r[1] for r in con.execute(
        "SELECT round_id,hit FROM predictions WHERE room_id=? AND hit IS NOT NULL",
        (room,))}
    con.close()
    if len(live) < 90:
        pytest.skip("自带库为纯 rounds 导出(无历史落库预测) —— 本对账钉无的放矢;"
                    "对账能力由监控器原生库触发,补算自还原性另由确定性钉覆盖")
    warmup = 400
    tail = [r["round_id"] for r in rounds[-100:]]
    # 必须走 plan_span 定下界 —— 它把「热身局数 + 一个完整训练窗」都算了进去。
    # 若只按热身长度切(如 rounds[-540:]),24h 训练窗会被截成 540 局,喂进引擎的
    # 序列与生产不同 ⇒ 还原率实测直接掉到 69%。这一步是补算保真的前提条件。
    since = plan_span(tail, warmup, cfg.get("train_window_hours", 24.0))
    feed = [r for r in rounds if r["round_id"] >= since]
    assert len(feed) > warmup + 100, "自带数据库历史不足以支撑本用例"
    got = replay_window(PredictorBridge(cfg, dict(cfg_all["custom_beast_ids"])),
                        cfg, room, feed, tail, warmup)
    rep = {r[0]: r[5] for r in got}
    both = [t for t in tail if t in live and t in rep]
    assert len(both) >= 90, f"可对账局数过少:{len(both)}"
    agree = sum(1 for t in both if live[t] == rep[t]) / len(both)

    def rate(d):
        m = sum(1 for t in both if d[t] == "main")
        c = sum(1 for t in both if d[t] in ("main", "guard"))
        return 100 * m / len(both), 100 * c / len(both)

    lm, lc = rate(live)
    rm, rc = rate(rep)
    assert agree >= 0.95, f"逐局判定还原率 {agree:.1%} 低于 95%"
    assert abs(lm - rm) <= 3.0, f"主命中率偏差 {abs(lm - rm):.1f}pp > 3pp"
    assert abs(lc - rc) <= 3.0, f"主+防命中率偏差 {abs(lc - rc):.1f}pp > 3pp"


# ═════════════ G. worker 编排:候选筛选 / batch 闸 / 冷却闸 / 零缺口短路 ═══════
class _FakeDB:
    """只实现补算路径用到的四个方法(4.9.3 起 _replay_room 头部另调
    heal_orphan_settlements 做孤儿补结算 —— 桩恒回 0,不模拟账本修复)。"""

    def __init__(self, gaps, rounds, stale=None):
        self.gaps, self.rounds, self.saved = gaps, rounds, {}
        self.stale = stale or {}
        self.dropped = {}
        self.healed_calls = []

    async def heal_orphan_settlements(self, room, window):
        self.healed_calls.append((room, window))
        return 0

    async def replay_gaps(self, room, window, cfg_fp=""):
        return {"anchor": 0, "missing": list(self.gaps.get(room, [])),
                "stale": list(self.stale.get(room, []))}

    async def drop_replay_rows(self, room, round_ids):
        self.dropped[room] = list(round_ids)
        return len(round_ids)

    async def rounds_since(self, room, since):
        return [r for r in self.rounds.get(room, []) if r["round_id"] >= since]

    async def save_replay_predictions(self, room, rows):
        self.saved[room] = rows
        return len(rows)


async def _mk_worker(rooms, discovered=(), cold=(), gaps=None, rounds=None,
                     stale=None):
    import fakeredis.aioredis
    import app.worker as wk
    from app.settings import Settings
    s = Settings()
    s.prediction = dict(s.prediction or {})
    s.prediction.update({"enabled": True, "replay_enabled": True,
                         "accuracy_window": 100, "replay_warmup": 5,
                         "replay_batch": 2, "replay_cooldown_s": 3600,
                         "train_window_hours": 0, "max_train": 5000})
    w = wk.Worker(s)
    w.bus.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    await w.bus.add_rooms_bulk([(r, r) for r in rooms])
    if discovered:
        await w.bus.discovered_seen_bulk(list(discovered))
    for c in cold:
        await w.bus.cold_mark(c, 0)
    w.db = _FakeDB(gaps or {}, rounds or {}, stale or {})
    w.bridge = _SpyBridge()
    return w


@pytest.mark.asyncio
async def test_sweep_skips_discovered_and_respects_batch():
    """发现房不补算(与 3.4.5 策展闸同源:它们没有实时消费者);
    每轮至多 replay_batch 个房 —— CPU 闸门不许被绕开。"""
    rooms = ["101", "102", "103", "104"]
    rs = {r: _mk_rounds(40) for r in rooms}
    gaps = {r: [x["round_id"] for x in rs[r][-3:]] for r in rooms}
    w = await _mk_worker(rooms, discovered=["104"], gaps=gaps, rounds=rs)
    await w._replay_sweep(w.s.prediction)
    assert "104" not in w.db.saved, "发现房不该被补算"
    assert len(w.db.saved) == 2, f"batch=2 未生效,实得 {len(w.db.saved)}"
    await w.bus.r.aclose()


@pytest.mark.asyncio
async def test_gate_blocks_second_sweep_and_zero_gap_costs_no_engine():
    """① 冷却闸:同一轮之后再扫,被闸住的房零 SQL 零 CPU;
       ② 零缺口短路:窗口已满的房不跑引擎(稳态开销就是这一句)。"""
    rs = {"201": _mk_rounds(40)}
    w = await _mk_worker(["201"], gaps={"201": [rs["201"][-1]["round_id"]]},
                         rounds=rs)
    await w._replay_sweep(w.s.prediction)
    assert "201" in w.db.saved
    calls = len(w.bridge.seqs)
    await w._replay_sweep(w.s.prediction)          # 闸未过期 → 应完全跳过
    assert len(w.bridge.seqs) == calls, "冷却闸失效,重复烧 CPU"
    await w.bus.replay_gate_clear("201")
    w.db.gaps = {"201": []}                        # 窗口已满
    await w._replay_sweep(w.s.prediction)
    assert len(w.bridge.seqs) == calls, "零缺口时不该跑引擎"
    await w.bus.r.aclose()


@pytest.mark.asyncio
async def test_history_shorter_than_warmup_writes_nothing():
    """历史不足以支撑热身 ⇒ 一行都不写(宁可窗口空着,不给不可信的数)。"""
    rs = {"301": _mk_rounds(4)}
    w = await _mk_worker(["301"], gaps={"301": [rs["301"][-1]["round_id"]]},
                         rounds=rs)
    await w._replay_sweep(w.s.prediction)
    assert not w.db.saved, "热身不足却写了补算行"
    await w.bus.r.aclose()


# ═══════ H. 复查轮(4.6.0):补算行绝不可冒充实盘的四条闸 ═══════════════════
@pytest.mark.asyncio
async def test_latest_prediction_excludes_replay_rows():
    """换手回退绝不能拿到补算行。

    补算**天然**填到 anchor 为止 ⇒ 恒满足回退分支的 `lp.round_id == latest`。
    若不排掉,在「补算已落库、实盘链还没写出下一条 pending」的窗口里,前端的
    「下一局主/防」会显示补算号 —— 回测口径冒充实盘预测,是本轮修复的反面。
    """
    from app.db import DB
    con = _FakeCon(None, [{"round_id": 1, "main_ids": [1], "guard_ids": [2],
                           "detail": {}}])
    db = DB.__new__(DB)
    db.pool = _FakePool(con)
    await db.latest_prediction("321")
    sql, args = con.seen[0]
    assert "source IS DISTINCT FROM" in sql, "换手回退未排除补算行"
    assert SRC_REPLAY in args


@pytest.mark.asyncio
async def test_prediction_records_anchored_and_carries_source():
    """命中串必须与 accuracy 同源按局锚定 —— 否则前端在 accuracy.n==0 时会回落到
    record 自行算率(app.js 的 PRED_EVAL 分支),用几天前的旧记录算出一个假的
    「近40局」,等于这次修复只做了一半。同时须带回 source 供徽标区分。"""
    from app.db import DB
    anchor = 1_700_000_000_000
    rows = [{"round_id": anchor, "actual_custom_id": 5, "hit": "main",
             "source": None}]
    con = _FakeCon(anchor, rows)
    db = DB.__new__(DB)
    db.pool = _FakePool(con)
    out = await db.prediction_records("321", 40)
    sql, args = con.seen[1]
    assert "round_id >= $2" in sql, "命中串未按局锚定"
    assert args[1] == anchor - 39 * ROUND_STEP
    assert "source" in sql and "source" in out[0], "命中串未带回溯源"


@pytest.mark.asyncio
async def test_prediction_records_empty_without_rounds():
    from app.db import DB
    db = DB.__new__(DB)
    db.pool = _FakePool(_FakeCon(None, []))
    assert await db.prediction_records("321", 40) == []


def test_replay_gaps_uses_missing_row_not_unsettled_row():
    """缺口判据必须是「压根没有预测行」。用 `p.hit IS NULL` 会把「有实盘行、
    只是没结算」也当缺口:刚落地那一局恒处于此态(白烧 CPU),而**永不结算的
    孤儿行**会让该房每个冷却周期都重跑一次补算、永远失败。"""
    import ast
    tree = ast.parse((_ROOT / "backend_async" / "app" / "db.py")
                     .read_text(encoding="utf-8"))
    fn = next(n for n in ast.walk(tree)
              if isinstance(n, ast.AsyncFunctionDef) and n.name == "replay_gaps")
    # 只看**真正拼进 SQL 的**字符串字面量 —— 文档字符串里为解释病因原样引用了
    # 旧判据,按整段扫会假红(_srcscan 头注说的正是这类陷阱)。按**节点身份**
    # 剔除 docstring:ast.get_docstring 返回的是清洗过的文本,与原始 Constant
    # 的 value 并不逐字相等,拿它做值比较照样漏。
    doc_node = (fn.body[0].value
                if fn.body and isinstance(fn.body[0], ast.Expr)
                and isinstance(fn.body[0].value, ast.Constant) else None)
    lits = [n.value for n in ast.walk(fn)
            if isinstance(n, ast.Constant) and isinstance(n.value, str)
            and n is not doc_node]
    sql = " ".join(lits)
    assert "p.round_id IS NULL" in sql
    assert "p.hit IS NULL" not in sql, "缺口判据退化回 hit IS NULL"


@pytest.mark.asyncio
async def test_warmup_precheck_skips_engine_when_gap_too_early():
    """训练窗把 rounds 撑得很长、但缺口本身太靠前 ⇒ 一条也写不出来。
    旧判据 len(rounds)<=warmup 会放行并白跑一次引擎,且每个冷却周期重复一次。"""
    rs = {"401": _mk_rounds(60)}
    w = await _mk_worker(["401"], gaps={"401": [rs["401"][3]["round_id"]]},
                         rounds=rs)
    w.s.prediction["replay_warmup"] = 20        # 缺口前只有 3 局,远不够
    await w._replay_sweep(w.s.prediction)
    assert not w.bridge.seqs, "热身预检失效,白烧了一次引擎"
    assert not w.db.saved
    await w.bus.r.aclose()


def test_frontend_badge_ignores_replay_records():
    """「上局开X·主中」是战绩展示,只认实盘判定。剥注释后扫真代码。

    4.7.5:命中率行的回测溯源角标已移除,本钉的**后半段随之反向** ——
    由「必须有标注」改为「必须没有标注」。前半段(徽标过滤)一个字未动:
    角标是文案取舍,徽标过滤是「不冒领战绩」的硬约束,两者正交。
    这两条刻意留在同一个用例里,就是为了让任何试图「顺手把 4.6.0 整体回退」
    的改动同时撞上两个方向相反的断言,回退不掉。
    """
    from tests._srcscan import js_code
    code = js_code(_ROOT / "assets" / "app.js")
    assert "r.s !== 'replay'" in code, "徽标未排除补算判定"
    assert "含补算" not in code, "命中率行又出现了回测溯源角标(4.7.5 已移除)"
    # 更严:渲染函数本体不得再读 accuracy.replay —— 换个词照样拼角标也算回退。
    import re
    body = re.search(r"function predStatText\(acc\)\{.*?\n\}", code, re.S)
    assert body, "predStatText 不见了(渲染入口被改名/删除?)"
    assert "replay" not in body.group(0), "predStatText 又依赖 accuracy.replay 了"
    title = re.search(r"function predStatTitle\(acc\)\{.*?\n\}", code, re.S)
    assert title, "predStatTitle 不见了"
    assert "replay" not in title.group(0), "predStatTitle 又依赖 accuracy.replay 了"


# ═══ I. 三轮复查:墙钟闸 / 并发安全 / 死参数 ═══════════════════════════════
@pytest.mark.asyncio
async def test_sweep_stops_before_cross_replica_lock_expires():
    """跨副本锁 TTL = 巡检周期,而 replay_batch 上限 200 × 单房约 1.9s ≈ 380s。
    没有墙钟闸时锁会中途过期,别的副本并发开跑,协程头注承诺的「全舰队同一周期
    恰好一个副本在算」就成了空话(每房冷却闸只防重复房,不防并发烧 CPU)。"""
    import time as _t
    rooms = [str(500 + i) for i in range(8)]
    w = await _mk_worker(rooms, gaps={}, rounds={})
    w.s.prediction["replay_batch"] = 200          # batch 闸门形同虚设
    seen = []

    async def _slow(room, window, warmup, pcfg):   # 单房 0.35s(真机约 1.9s)
        seen.append(room)
        _t.sleep(0.35)
        return True

    w._replay_room = _slow
    await w._replay_sweep(w.s.prediction, interval_s=1)   # 墙钟 = max(1.0, 0.8) = 1.0s
    assert 0 < len(seen) < len(rooms), f"墙钟闸未生效(跑了 {len(seen)}/{len(rooms)} 房)"
    await w.bus.r.aclose()


def test_replay_window_has_no_dead_parameters():
    """死参数会误导后来者以为存在分片让渡机制。全项目零调用即应删除。"""
    import inspect
    from app import pred_replay
    params = set(inspect.signature(pred_replay.replay_window).parameters)
    assert params == {"bridge", "cfg", "room", "rounds", "missing",
                      "warmup", "now_ms_v", "cfg_fp"}, params


@_needs_db
def test_bridge_is_concurrency_safe():
    """补算跑在线程池里,与主循环的实盘预测共用同一个 bridge 实例。
    PredictorBridge 每次调用都新建 Predictor + kv 影子(_make_predictor),
    实例上只有不可变的 pcfg/catalog —— 此处以并发/串行结果对拍实证。"""
    import sqlite3
    from concurrent.futures import ThreadPoolExecutor
    import yaml
    os.environ.setdefault("STA_ENGINE_DIR", str(_ROOT / "jiufa_data"))
    from app.predictor_bridge import PredictorBridge
    y = yaml.safe_load(
        (_ROOT / "backend_async" / "config.yaml").read_text(encoding="utf-8"))
    cfg = dict(y["prediction"])
    bridge = PredictorBridge(cfg, dict(y["custom_beast_ids"]))
    con = sqlite3.connect(f"file:{_DB}?mode=ro", uri=True)
    rooms = ["2678075", "1275859"]
    data = {}
    for r in rooms:
        rs = [{"round_id": x[0], "custom_id": x[1], "start_ms": x[2], "draw_ms": x[3]}
              for x in con.execute(
                  "SELECT round_id,custom_id,start_ms,draw_ms FROM rounds"
                  " WHERE room_id=? AND custom_id IS NOT NULL ORDER BY round_id", (r,))]
        data[r] = (rs[-500:], [x["round_id"] for x in rs[-40:]])
    con.close()

    def run(r):
        return [(x[0], tuple(x[1]), x[5])
                for x in replay_window(bridge, cfg, r, data[r][0], data[r][1], 200)]

    seq = {r: run(r) for r in rooms}
    with ThreadPoolExecutor(max_workers=2) as ex:
        par = dict(zip(rooms, ex.map(run, rooms)))
    for r in rooms:
        assert seq[r] and seq[r] == par[r], f"房 {r} 并发结果与串行不一致"


def test_frontend_cache_version_bumped_for_replay_change():
    """改了 app.js 就必须 bump index.html 的 `?v=` —— 否则带缓存/经 CDN 的客户端
    继续跑旧包,且**重启服务器也不会好**(那是浏览器/中间层的缓存)。

    4.7.5 起本钉守的是移除方向:老页面继续跑旧包时,用户端照旧看得见那个
    回测溯源角标 —— 本轮改动等于没部署。

    ★ 原实现有个自毁开关:`if "含补算" not in js: pytest.skip(...)`。
      角标一被移除它就整条 skip 掉,钉子在最需要它的那一刻自己拔了。
      现改为**无条件执行**,并把「角标确已从源码消失」本身也纳入断言 ——
      钉子不该有「本特性不存在时就不检查」这种后门。
    与 test_jfvip_contract.test_frontend_cache_version_bumped 同款回归钉。"""
    idx = (_ROOT / "index.html").read_text(encoding="utf-8")
    js = (_ROOT / "assets" / "app.js").read_text(encoding="utf-8")
    assert "含补算" not in js, "app.js 里又出现了回测溯源角标(4.7.5 已移除)"
    for stale in ("4.4.0", "4.6.0", "4.7.4"):
        assert f"app.js?v={stale}" not in idx and f"app.css?v={stale}" not in idx, \
            f"app.js 已改(移除溯源角标)却仍挂 ?v={stale},老客户端会一直跑旧包"
    import re
    vs = set(re.findall(r"app\.(?:js|css)\?v=([0-9.]+)", idx))
    assert len(vs) == 1, f"index.html 里 js/css 版本不一致:{vs}"


# ═══ J. 四轮复查:预测超参热更后的自愈 ═══════════════════════════════════
def test_config_fingerprint_is_stable_and_field_scoped():
    """指纹必须①稳定(否则每轮判过期、无限重算烧 CPU)②只覆盖引擎真读的字段
    (replay_* 是运维参数,调它们不该触发全窗重算)。"""
    import yaml
    os.environ.setdefault("STA_ENGINE_DIR", str(_ROOT / "jiufa_data"))
    from app.pred_replay import config_fingerprint
    from app.predictor_bridge import PredictorBridge
    y = yaml.safe_load(
        (_ROOT / "backend_async" / "config.yaml").read_text(encoding="utf-8"))
    base = dict(y["prediction"])
    be = dict(y["custom_beast_ids"])
    fp = config_fingerprint(PredictorBridge(base, be))
    assert len(fp) == 12 and fp == config_fingerprint(PredictorBridge(base, be)), \
        "指纹不稳定 ⇒ 补算行会被无限重算"
    ops = dict(base, replay_batch=99, replay_warmup=123, replay_cooldown_s=7)
    assert config_fingerprint(PredictorBridge(ops, be)) == fp, \
        "运维参数不该改变指纹"
    tuned = dict(base, hedge_eta=float(base["hedge_eta"]) + 0.05)
    assert config_fingerprint(PredictorBridge(tuned, be)) != fp, \
        "超参变了指纹必须变(否则旧口径的补算行永远不会被重算)"


def test_replay_stamps_config_fingerprint():
    rounds = _mk_rounds(40)
    out = replay_window(_SpyBridge(), {"train_window_hours": 0, "max_train": 5000},
                        "321", rounds, [r["round_id"] for r in rounds],
                        warmup=5, cfg_fp="deadbeef1234")
    assert out and all(r[3]["replay"]["cfg"] == "deadbeef1234" for r in out)


@pytest.mark.asyncio
async def test_stale_rows_are_dropped_then_recomputed():
    """超参热更后:过期补算行先被**定向删除**(DELETE 带 source='replay' 谓词,
    实盘行碰不到),再与真缺口合并重算 —— 而不是把 INSERT 改成 DO UPDATE
    (那会削弱「补算绝不覆盖实盘行」这条最硬的保证)。"""
    rs = {"601": _mk_rounds(60)}
    ids = [r["round_id"] for r in rs["601"]]
    w = await _mk_worker(["601"], gaps={"601": [ids[-1]]},
                         stale={"601": [ids[-2], ids[-3]]}, rounds=rs)
    await w._replay_sweep(w.s.prediction)
    assert w.db.dropped.get("601") == [ids[-2], ids[-3]], "过期行未被删"
    wrote = {r[0] for r in w.db.saved.get("601", [])}
    assert {ids[-1], ids[-2], ids[-3]} <= wrote, "缺口与过期行未合并重算"
    await w.bus.r.aclose()


def test_drop_replay_rows_sql_is_scoped_to_replay():
    """删除语句必须带 source 谓词 —— 这是「实盘行永不可删」的唯一保证。"""
    import ast
    tree = ast.parse((_ROOT / "backend_async" / "app" / "db.py")
                     .read_text(encoding="utf-8"))
    fn = next(n for n in ast.walk(tree)
              if isinstance(n, ast.AsyncFunctionDef) and n.name == "drop_replay_rows")
    doc_node = (fn.body[0].value if fn.body and isinstance(fn.body[0], ast.Expr)
                and isinstance(fn.body[0].value, ast.Constant) else None)
    sql = " ".join(n.value for n in ast.walk(fn)
                   if isinstance(n, ast.Constant) and isinstance(n.value, str)
                   and n is not doc_node)
    assert "DELETE FROM predictions" in sql and "source=$2" in sql


# ═══ K. 五轮复查:桥/指纹/训练窗必须同源 ═══════════════════════════════════
def test_replay_room_reads_bridge_exactly_once():
    """`self.bridge` 在 _replay_room 里只能取一次。

    此前取两次(算指纹一次、丢进线程池一次),中间隔着几个 await —— 配置热更
    恰好插在中间时,行会被盖上**旧指纹**却是用**新桥**算出的。下一轮虽会判过期
    重算(自愈),但那是白烧一整轮,且期间那个戳在撒谎。
    """
    import ast
    src = (_ROOT / "backend_async" / "app" / "worker.py").read_text(encoding="utf-8")
    fn = next(n for n in ast.walk(ast.parse(src))
              if isinstance(n, ast.AsyncFunctionDef) and n.name == "_replay_room")
    hits = [n for n in ast.walk(fn)
            if isinstance(n, ast.Attribute) and n.attr == "bridge"
            and isinstance(n.value, ast.Name) and n.value.id == "self"]
    assert len(hits) == 1, f"self.bridge 被读了 {len(hits)} 次,必须只取一次快照"


def test_replay_training_window_comes_from_the_same_bridge():
    """训练窗与 max_train 必须取自**同一份** bridge.pcfg —— 它们都是
    E.PredictionConfig 的字段,与配置指纹同源;若从 self.s.prediction 另取,
    会在热更瞬间与指纹脱钩,重新引入上面刚根除的那类不一致。"""
    import ast
    src = (_ROOT / "backend_async" / "app" / "worker.py").read_text(encoding="utf-8")
    fn = next(n for n in ast.walk(ast.parse(src))
              if isinstance(n, ast.AsyncFunctionDef) and n.name == "_replay_room")
    body = ast.unparse(fn)
    assert "bridge.pcfg" in body
    assert "pcfg.get('train_window_hours'" not in body \
        and 'pcfg.get("train_window_hours"' not in body, \
        "训练窗仍从热更 dict 取,会与指纹脱钩"


def test_audit_harness_documents_the_warmup_gap():
    """window_audit/replay_harness.py 的热身是 30 局、生产是 400 —— 运维拿它
    复核补算会得到 88% 而不是 98%,极易误判成故障。必须在工具里写明。"""
    t = (_ROOT / "window_audit" / "replay_harness.py").read_text(encoding="utf-8")
    assert "replay_warmup" in t and "pred_replay.py" in t, "审计工具未标注口径差异"


# ═══ L. 七轮复查:协程本体(此前只直接调过 _replay_sweep,循环从没跑过)═════
@pytest.mark.asyncio
async def test_coroutine_double_gate_costs_nothing_when_off():
    """双闸关闭时必须**完全退场**:不抢锁、不碰 Redis、不扫房。
    此前只验过「判据为关」,没验过协程真跑起来是否零开销。"""
    import asyncio
    w = await _mk_worker(["701"], gaps={}, rounds={})
    # 协程对周期有 max(5, …) 下限钳位(注册表亦 ge=5),等待时长须按真实节拍
    w.s.prediction.update({"replay_interval_s": 5, "replay_enabled": False})
    swept = []
    w._replay_sweep = lambda *a, **k: swept.append(1)
    w._running = True
    t = asyncio.create_task(w._pred_replay())
    await asyncio.sleep(6.2)
    before = await w.bus.r.exists("predreplay:sweep")
    w._running = False
    await asyncio.wait_for(t, timeout=3)
    assert swept == [], "开关关闭却仍在扫房"
    assert before == 0, "开关关闭却抢了跨副本锁"
    await w.bus.r.aclose()


@pytest.mark.asyncio
async def test_coroutine_sweeps_and_holds_cross_replica_lock():
    import asyncio
    w = await _mk_worker(["702"], gaps={}, rounds={})
    w.s.prediction.update({"replay_interval_s": 5, "replay_enabled": True})
    calls = []

    async def _sweep(pcfg, interval_s=60):
        calls.append(interval_s)

    w._replay_sweep = _sweep
    w._running = True
    t = asyncio.create_task(w._pred_replay())
    await asyncio.sleep(6.2)
    held = await w.bus.r.exists("predreplay:sweep")
    w._running = False
    await asyncio.wait_for(t, timeout=3)
    assert calls, "协程没有触发巡检"
    assert all(x == 5 for x in calls), f"锁 TTL 未随周期下传:{calls}"
    assert held == 1, "跨副本锁未被持有"
    await w.bus.r.aclose()


@pytest.mark.asyncio
async def test_coroutine_stops_promptly_on_shutdown():
    """睡眠按 1s 分步并逐拍检查 _running —— 即便周期配成 3600s,
    停机也必须在 ~1s 内退出,不能把优雅关闭拖成一小时。"""
    import asyncio, time as _t
    w = await _mk_worker(["703"], gaps={}, rounds={})
    w.s.prediction.update({"replay_interval_s": 3600, "replay_enabled": True})
    w._running = True
    t = asyncio.create_task(w._pred_replay())
    await asyncio.sleep(0.2)
    t0 = _t.monotonic()
    w._running = False
    await asyncio.wait_for(t, timeout=5)
    assert _t.monotonic() - t0 < 2.0, "停机耗时过长,睡眠未分步"
    await w.bus.r.aclose()


@pytest.mark.asyncio
async def test_coroutine_honours_hot_toggle():
    """开关是热更项 —— 跑起来之后关掉,下一周期就该停;再打开又该恢复。"""
    import asyncio
    w = await _mk_worker(["704"], gaps={}, rounds={})
    w.s.prediction.update({"replay_interval_s": 5, "replay_enabled": True})
    n = []

    async def _sweep(pcfg, interval_s=60):
        n.append(1)

    w._replay_sweep = _sweep
    w._running = True
    t = asyncio.create_task(w._pred_replay())
    await asyncio.sleep(6.2)
    a = len(n)
    w.s.prediction["replay_enabled"] = False
    await w.bus.r.delete("predreplay:sweep")
    await asyncio.sleep(6.2)
    b = len(n)
    w.s.prediction["replay_enabled"] = True
    await w.bus.r.delete("predreplay:sweep")
    await asyncio.sleep(6.2)
    c = len(n)
    w._running = False
    await asyncio.wait_for(t, timeout=3)
    assert a > 0 and b == a, f"关掉后仍在扫({a}→{b})"
    assert c > b, f"重新打开后没有恢复({b}→{c})"
    await w.bus.r.aclose()


# ── 轮换口径下的补算保真度(冷位份额闭环上线后新增的钉) ────────────────────────
@pytest.mark.parametrize("room", ["1275859", "2678075", "3746870"])
def test_replay_fidelity_under_share_rotation(room):
    """冷位份额闭环(showcase_rotate)把「赤字账本」这种**路径依赖累加器**引进了状态,
    而补算是冷启动重放 —— 账本从 0 起算,轮换的**相位**必然与实盘不同。

    真机三房实测(热身 400 局、目标窗 400 局):
      · 逐局判定还原  关=96.2%  →  开=81.3%   ← 相位差导致,加长热身不收敛
        (热身 200 vs 400 实测四码全同 15.8% vs 15.0%,说明不是热身不够)
      · 命中率偏差    关=+0.08pp →  开=−0.83pp ← 长期份额一致,**统计口径不受影响**

    所以本钉守的是**产品真正承诺的那条线**:补算是「回测不是实盘战绩」
    (backend_async/README.md §10.1),它要还原的是命中率统计,不是逐局号码。
    逐局判定还原率在轮换口径下不再是可守的不变量 —— 任何打破冷位垄断的轮换调度
    都有任意相位,这是机制固有属性,不是缺陷。

    ── 4.9.7 改口径:单窗口 → **多窗口均值 + t 检验**(不是放宽,是改对) ──────────
    背景:explore_style 默认由 "frontier" 改回 "showcase" 后,本钉在 2678075 房红了
    (单窗口偏差 −4.25pp)。逐条查下来,红的原因**不是**补算坏了,而是本钉原来的
    统计形式在 showcase 口径下站不住:

      ① frontier 域内 anti_stubborn / showcase_rotate / repeat_guard / cadence_governor
         **全组硬失效**(见 predictor_bridge._DEAD_SWITCH_KEYS),路径依赖累加器整组
         不参与 ⇒ 逐局还原 86~94%,单窗口方差小,±3pp 这道硬门恰好扛得住。
         也就是说 4.9.0~4.9.6 期间本钉虽然全绿,测的却是 frontier 的补算,
         与它 docstring 里写的「轮换口径」根本不是一回事(开头那句
         `assert bool(cfg.get("showcase_rotate"))` 只查了开关值,没查它是否真生效)。
      ② 切回 showcase 后四组累加器(连败压力 _pen / 赤字账本 _dbt / k 分位历史 _kd /
         节拍器令牌桶 _cgb3/_cgb2)全部复活,逐局还原掉到 64~70%,单窗口 σ 随之变大。

    实地核查(三房 × 9 个互不重叠 400 局窗 = 27 窗,热身 400,方法同 config.yaml
    replay_warmup 段的「11 个互不重叠窗口」口径):

        口径                     偏差均值   σ      t       超±3pp 的窗   逐局还原
        showcase 节拍器开(现行)  −0.19pp  2.43  −0.42    **8/27**      64~70%
        showcase 节拍器关         +0.19pp  1.87  +0.51      3/27        83~88%

    两点结论,都得连着看:
      · **偏差无系统性**:两个口径 t 值均在 ±1 内 ⇒ 补算既不系统性抬高也不压低
        命中率,产品承诺的那条线**守住了**;
      · 但 ±3pp 的**单窗口**硬门不是可守的不变量 —— 即便节拍器关着也有 3/27 窗
        越线,现行口径下更是 8/27(≈30%)。它此前不红,靠的是恰好选中了
        [1000,1400) 这一个窗。换个窗就是掷硬币。

    ⚠ 加长热身**不收敛**(2678075 实测:热身 400/600/800/1000 → 偏差
      −4.25/−1.00/−2.50/−3.25pp,逐局还原恒在 63~66%)。令牌桶的滴水速率由目标
      份额决定、与数据无关,冷启动的桶相位**永远**不会与实盘重新对齐 —— 这与
      赤字账本是同一类问题,不是「热身不够」。故不能靠调 replay_warmup 解决。

    ⇒ 改成对**多个互不重叠窗口的偏差均值**设 ±3pp,并对单窗口保留一道
      ±8pp(≈3.3σ)的粗门兜住真回归。前者才是「命中率统计可比」这条产品承诺的
      正确形式,后者防止有人把补算彻底改坏而均值恰好抵消。
    回滚/收紧:把 _NWIN 调回 1 即退化为原来的单窗口口径。
    """
    import bisect
    import yaml
    os.environ.setdefault("STA_ENGINE_DIR", str(_ROOT / "jiufa_data"))
    from app.predictor_bridge import PredictorBridge
    cfg = dict(yaml.safe_load(
        (_ROOT / "backend_async" / "config.yaml").read_text(encoding="utf-8"))["prediction"])
    beasts = dict(yaml.safe_load(
        (_ROOT / "backend_async" / "config.yaml").read_text(encoding="utf-8"))["custom_beast_ids"])
    assert bool(cfg.get("showcase_rotate")), "本钉针对轮换口径;开关已关则应删除此钉"

    con = sqlite3.connect(f"file:{_DB}?mode=ro", uri=True)
    rows = con.execute("SELECT round_id,custom_id,start_ms,draw_ms FROM rounds"
                       " WHERE room_id=? AND custom_id IS NOT NULL ORDER BY round_id",
                       (room,)).fetchall()
    con.close()
    starts = [r[2] for r in rows]
    cids = [r[1] for r in rows]
    tw = int(float(cfg.get("train_window_hours", 24.0)) * 3600 * 1000)
    mx = int(cfg.get("max_train", 5000))

    def run(first, stop):
        br = PredictorBridge(cfg, beasts)
        kv, pend, verdict = {}, {}, {}
        for i, (rid, cid, sms, dms) in enumerate(rows):
            if i > stop:
                break
            q = pend.pop(rid, None)
            if q is not None:
                verdict[q[2]] = ("main" if cid in q[3][:2]
                                 else ("guard" if cid in q[3][2:] else "miss"))
                kv.update(br.update_after_settle(
                    room, {"models": q[0], "ens": q[1]}, cid, kv))
            if i < first:
                continue
            now = (dms or sms + 46500) + 1500
            lo = bisect.bisect_left(starts, now - tw, 0, i + 1)
            res, dirty = br.run_prediction(room, cids[lo:i + 1][-mx:], kv)
            kv.update(dirty)
            four = list(res["main"]) + list(res["guard"])
            pend[rid + ROUND_STEP] = (res["models"], res["ens"], i, four)
        return verdict

    warm = int(cfg.get("replay_warmup", 400))
    _W, _NWIN = 400, 9                  # 窗长 / 互不重叠窗数(_NWIN=1 即退回旧口径)
    last = 1000 + _W * _NWIN
    live = run(30, last + 5)            # 实盘:状态连续推进,一次跑到底
    devs = []
    for w in range(_NWIN):
        s, e = 1000 + w * _W, 1000 + (w + 1) * _W
        back = run(max(0, s - warm), e + 5)   # 补算:冷启动 + 生产热身长度
        tgt = [i for i in range(s, e) if i in live and i in back]
        if len(tgt) < 300:
            continue                    # 数据不够长的尾窗直接弃用,不凑数
        hl = sum(1 for i in tgt if live[i] != "miss") / len(tgt) * 100
        hb = sum(1 for i in tgt if back[i] != "miss") / len(tgt) * 100
        devs.append(hb - hl)
    assert len(devs) >= 5, f"[{room}] 可用窗数不足: {len(devs)}"
    mean = sum(devs) / len(devs)
    # ① 主契约:多窗口偏差**均值** —— 补算不得系统性抬高或压低命中率统计
    assert abs(mean) <= 3.0, (
        f"[{room}] 补算命中率偏差均值 {mean:+.2f}pp 超出生产契约 ±3pp "
        f"({len(devs)} 个互不重叠 {_W} 局窗,逐窗 "
        f"{', '.join(f'{d:+.2f}' for d in devs)})")
    # ② 粗门:单窗口 ±8pp(≈3.3σ,实测 σ≈2.4pp)—— 均值抵消掩盖不了真回归
    worst = max(devs, key=abs)
    assert abs(worst) <= 8.0, (
        f"[{room}] 存在单窗口偏差 {worst:+.2f}pp 超出 ±8pp 粗门 —— "
        f"均值虽为 {mean:+.2f}pp,但补算已在某些窗口严重失真")
