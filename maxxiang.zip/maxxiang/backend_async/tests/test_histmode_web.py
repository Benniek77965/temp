"""
test_histmode_web.py — hist-mode 启用态的 web 端点 / worker 统计**真实执行**覆盖
================================================================================
第七轮审计补缺:此前 crawler_status 的 histMode 块、monitor_add 的封尾触发、
_emit_ingest_stats 的启用分支只被"读代码 + py_compile"审过,**从未在启用态
执行过一次**(既有 250 项全部默认关闭;sims 不跑 web/janitor)。NameError/
字段名笔误这类错误编译期查不出、还会被 suppress 吞成静默降级 —— 本文件用
项目既定轻模式(monkeypatch web.ST + 直调端点函数,见 test_web_prediction)
把这些真代码路径各跑一遍。bus 用 fakeredis 真件(被测的正是 bus 调用链);
db/star 用宽假件旁路(它们不是被测对象)。
"""
from __future__ import annotations

import asyncio
import math
from types import SimpleNamespace

import pytest

import app.redis_bus as rb
import app.web as web
from app.redis_bus import RedisBus, task_hist, task_mainpage
from app.scheduler import effective_hist_interval_ms, weighted_fleet_load


class _WideDB:
    """宽假件:任何方法都可 await,返回中性值(db 不是被测对象)。"""
    def __getattr__(self, name):
        async def _f(*a, **k):
            if name == "pg_health_probe":
                return {}
            return None
        return _f


class _Star:
    async def canon(self, room):
        return str(room), True


def _bus():
    import fakeredis.aioredis
    b = RedisBus("redis://x")
    b.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    return b


class _Req:
    headers: dict = {}


@pytest.fixture()
def wired(monkeypatch):
    """挂真 bus/宽 db/star;测试后还原 settings.histmode(模块级单例,无自动还原)。"""
    b = _bus()
    monkeypatch.setattr(web.ST, "bus", b, raising=False)
    monkeypatch.setattr(web.ST, "db", _WideDB(), raising=False)
    monkeypatch.setattr(web.ST, "star", _Star(), raising=False)
    hm = web.settings.histmode
    saved = (hm.enabled, hm.interval_s)
    yield b
    hm.enabled, hm.interval_s = saved


@pytest.mark.asyncio
async def test_status_disabled_shape(wired):
    """禁用态:histMode 块只含 {enabled, intervalS};health 无 effectiveRooms
    (「禁用 JSON 逐字节不变」承诺的键集断言)。"""
    web.settings.histmode.enabled = False
    out = await web.crawler_status()
    hm = out["crawler"]["histMode"]
    assert hm == {"enabled": False, "intervalS": web.settings.histmode.interval_s}
    assert "effectiveRooms" not in out["crawler"]["health"]


@pytest.mark.asyncio
async def test_status_enabled_block_and_weighted_health(wired):
    """启用态:histMode 观测块逐字段执行 + health 加权口径。此前这段真代码
    (hist_oldest / histmode_stats / weighted 需求)零执行覆盖。"""
    b = wired
    web.settings.histmode.enabled = True
    web.settings.histmode.interval_s = 900
    rooms = ["9001", "9002", "9003"]
    await b.add_rooms_bulk([(r, r) for r in rooms])
    for r in rooms:
        await b.r.hset(rb.K_ROOMS_DISCOVERED, r, "1")
    await b.hist_mark_ok("9001", 1_000)              # 最老成功项
    await b.histmode_set({"window_lost": 2, "short_page": 1})
    out = await web.crawler_status()
    hm = out["crawler"]["histMode"]
    assert hm["enabled"] is True and hm["rooms"] == 3
    assert hm["oldestPollAgeMs"] > 0                 # host_now − 1000ms
    assert hm["windowLost"] == 2 and hm["shortPage"] == 1
    assert hm["estReqPerSec"] == round(3 / 900, 2)
    health = out["crawler"]["health"]
    eff = weighted_fleet_load(0, 3, effective_hist_interval_ms(
        web.settings.histmode) / 1000.0)             # 3 房全 hist、零策展
    assert health["effectiveRooms"] == eff
    assert health["suggestReplicas"] == max(2, math.ceil(eff / 4300) + 1)


@pytest.mark.asyncio
async def test_monitor_add_schedules_seal_when_enabled(wired):
    """monitor_add 启用态:除 mp@now 外必须同时排 hs@now(封尾触发);
    禁用态只排 mp(对照)。执行的是端点真函数(guard/canon/known 全链)。"""
    b = wired
    for enabled, expect_hs in ((False, False), (True, True)):
        web.settings.histmode.enabled = enabled
        rid = "9100" if enabled else "9200"
        await b.add_rooms_bulk([(rid, rid)])         # known 判定要求已在后台
        await b.r.hset(rb.K_ROOMS_DISCOVERED, rid, "1")
        resp = await web.monitor_add(_Req(), room=rid)
        assert not isinstance(resp, web.JSONResponse) or resp.status_code == 200, resp
        z = dict(await b.r.zrange(rb.K_SCHED, 0, -1, withscores=True))
        assert task_mainpage(rid) in z
        assert (task_hist(rid) in z) is expect_hs
        assert not await b.r.hexists(rb.K_ROOMS_DISCOVERED, rid)   # 转正已清发现集


@pytest.mark.asyncio
async def test_emit_ingest_stats_enabled_path():
    """worker._emit_ingest_stats 启用分支直调(此前零执行):加权 need、
    hist_rooms/hist_per_min/effective_rooms 字段、最老成功日志段 —— 不抛且落库。"""
    from tests.test_histmode import _mini_world
    w, up, db, clock, s = _mini_world(enabled=True, interval_s=900)
    rooms = ["9301", "9302"]
    await w.bus.add_rooms_bulk([(r, r) for r in rooms])
    for r in rooms:
        await w.bus.r.hset(rb.K_ROOMS_DISCOVERED, r, "1")
    await w.bus.hist_mark_ok("9301", clock.t - 30_000)
    await w._emit_ingest_stats(n=0, elapsed=60.0,
                               active=set(rooms), hist_ins=5)
    st = await w.bus.r.hgetall("stats:ingest")
    assert st.get("hist_rooms") == "2" and st.get("hist_per_min") == "5"
    assert int(st["effective_rooms"]) == weighted_fleet_load(0, 2, 900.0)
