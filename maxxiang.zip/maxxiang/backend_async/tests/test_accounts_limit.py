"""
test_accounts_limit.py — 账号数量上限(最多 10 个)的存储层硬限(零网络)
================================================================================
限制落在 AccountStore.upsert 的**新增分支**:任何新增路径都无法绕过;
已有账号重新扫码登录 = 更新,不受限(addedAt 首登时间保留)。
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.accounts.accounts_backend import AccountStore  # noqa: E402


def _acct(i: int) -> dict:
    return {"kugouId": str(1000 + i), "nickName": f"号{i}", "token": "t",
            "addedAt": 100 + i, "lastRefreshAt": 100 + i}


def test_limit_ten_accounts(tmp_path):
    store = AccountStore(str(tmp_path / "accounts.json"))
    assert AccountStore.MAX_ACCOUNTS == 10

    for i in range(10):                          # 前 10 个:入库成功
        assert store.upsert(_acct(i)) is True
    assert store.count() == 10

    assert store.upsert(_acct(99)) is False      # 第 11 个(新增):硬拒
    assert store.count() == 10
    assert store.get("1099") is None

    upd = _acct(3); upd["nickName"] = "改名"; upd["addedAt"] = 999
    assert store.upsert(upd) is True             # 已有账号:更新不受限
    assert store.count() == 10
    got = store.get("1003")
    assert got["nickName"] == "改名"
    assert got["addedAt"] == 103                 # 首登时间保留,不被覆盖

    # 移除一个后,新增恢复可用;且持久化重载后限额状态一致
    store.remove("1000")
    assert store.count() == 9
    assert store.upsert(_acct(99)) is True
    store2 = AccountStore(str(tmp_path / "accounts.json"))
    assert store2.count() == 10
    assert store2.upsert(_acct(77)) is False     # 重载后依旧顶格


def test_upsert_rejects_empty_kugou_id(tmp_path):
    store = AccountStore(str(tmp_path / "a.json"))
    assert store.upsert({"kugouId": ""}) is False
    assert store.count() == 0
