"""test_jfvip_admin_realdb.py — 「值」视图改动的**真库**验证(4.2.5 第五轮复审)

前四轮对本轮改动的验证止步于:源码扫描、jsdom 桩、进程内 mock、真实浏览器。
唯独**真数据库**始终缺席 —— 而 `overview()` 是本轮唯一改了 SQL 执行结构的函数,
`cards_disable(undo=)` 是本轮新接出来的 UI 能力,负数 jf_hours 是 CSV 缺陷的根。
这三条在真库上一次都没跑过。本文件补齐。

前置(与 test_jfvip_db.py 同款,不可达则整层 skip,不阻断主干):
    docker run -d --name jftest -p 3307:3306 \
      -e MARIADB_ALLOW_EMPTY_ROOT_PASSWORD=1 mariadb:10.11
"""
from __future__ import annotations

import asyncio
import os
import socket

import pytest

import app.jfvip as jfvip
import app.userauth as userauth
from app.settings import UserAuthCfg

pytestmark = pytest.mark.asyncio

_HOST = os.environ.get("STA_TEST_USERDB_HOST", "127.0.0.1")
_PORT = int(os.environ.get("STA_TEST_USERDB_PORT", "3307"))
_USER = os.environ.get("STA_TEST_USERDB_USER", "root")
_PASS = os.environ.get("STA_TEST_USERDB_PASSWORD", "")
_DB = os.environ.get("STA_TEST_USERDB_NAME", "fx_jfvip_test")


# 5.3.0:管理面挂在配置的入口路径下(默认 /api/admin-xdd);整站 web.app 的用例取其实际前缀。
# 外部发卡接口 /api/admin/jfvip/cards/issue 是恒定地址,仍按字面量写。
from app import admin_auth as _admin_auth  # noqa: E402
_ADM = _admin_auth.api_prefix()


def _reachable() -> bool:
    try:
        with socket.create_connection((_HOST, _PORT), timeout=0.6):
            return True
    except OSError:
        return False


needs_db = pytest.mark.skipif(
    not _reachable(),
    reason=f"需要本地用户库 {_HOST}:{_PORT}(MariaDB/MySQL 1:1 复刻)")

PLANS = [{"code": "d3", "name": "3 天", "price": 18.0,
          "jfHours": 72, "ddHours": 72, "tag": ""},
         {"code": "m1", "name": "1 个月", "price": 88.0,
          "jfHours": 744, "ddHours": 744, "tag": ""}]

_DDL_USER = """CREATE TABLE IF NOT EXISTS tb_user (
     id INT UNSIGNED NOT NULL AUTO_INCREMENT,
     user_name VARCHAR(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL,
     pass_word VARCHAR(64) NOT NULL DEFAULT '',
     register_time DATETIME NULL, due_time DATETIME NULL,
     is_off CHAR(1) NOT NULL DEFAULT '0',
     PRIMARY KEY(id), UNIQUE KEY uk_name (user_name)
   ) ENGINE=InnoDB DEFAULT CHARSET=gbk"""


async def _prepare(monkeypatch):
    """建库建表 + 拨通配置。与 test_jfvip_db.py 同款范式:直调而非 async fixture ——
    后者在本仓的 pytest-asyncio 配置下会留下 "Event loop is closed" 噪声。"""
    import aiomysql
    conn = await aiomysql.connect(host=_HOST, port=_PORT, user=_USER,
                                  password=_PASS, charset="gbk", autocommit=True)
    async with conn.cursor() as cur:
        await cur.execute(f"CREATE DATABASE IF NOT EXISTS `{_DB}` DEFAULT CHARSET=gbk")
        await cur.execute(f"USE `{_DB}`")
        await cur.execute(_DDL_USER)
    conn.close()
    userauth.UA.cfg = UserAuthCfg(host=_HOST, port=_PORT, db=_DB, user=_USER,
                                  password=_PASS, charset="gbk",
                                  jf_vip_enabled=True, cache_ttl_s=0.0)
    userauth.UA.pool = None
    userauth.UA.schema_ok = False
    userauth.UA.schema_lock = asyncio.Lock()
    assert await userauth._ensure_schema(), "guantai_* 建表失败"
    # ⚠ 必须走 monkeypatch,不能裸赋值 —— 裸赋值会把档位替身**泄漏到同会话的
    #   其它测试**(pytest 单进程串行,后面的 test_* 会拿到本文件的两档)。
    monkeypatch.setattr(jfvip, "plans", lambda: PLANS)
    await _wipe()


async def _wipe():
    """清空三张聚合表。overview() 是**全库聚合**,不清就会把上一支测试的行
    算进「今日开通」—— 项目自己在 _mk_order 的注释里记着同一个坑:
    「跨轮累积会把断言误判成产品 bug(本轮实测踩过)」。"""
    for t in ("guantai_jf_grant_log", "guantai_jf_vip", "guantai_jf_card"):
        await userauth._q(f"DELETE FROM {t}")


async def _mk_user(name: str, days: int) -> int:
    t = userauth.UA.cfg.user_table
    await userauth._q("DELETE FROM guantai_jf_vip WHERE user_id IN "
                      f"(SELECT id FROM `{t}` WHERE user_name=%s)", (name,))
    await userauth._q("DELETE FROM guantai_jf_grant_log WHERE user_name=%s", (name,))
    await userauth._q(f"DELETE FROM `{t}` WHERE user_name=%s", (name,))
    await userauth._q(
        f"INSERT INTO `{t}` (user_name,pass_word,register_time,due_time,is_off) "
        f"VALUES (%s,'x',NOW(),DATE_ADD(NOW(), INTERVAL %s DAY),'0')", (name, days))
    row = await userauth._q(f"SELECT id FROM `{t}` WHERE user_name=%s",
                            (name,), fetch="one")
    return int(row["id"])


# ══════════════════════════════════════════════════════════════════════════════
# 一、overview() —— 本轮唯一改了 SQL 执行结构的函数
# ══════════════════════════════════════════════════════════════════════════════
@needs_db
@pytest.mark.asyncio
async def test_overview_numbers_are_right_on_real_db(monkeypatch):
    """★ 重构成 `_stat()` 闭包后,六段统计的**数值**必须仍然正确。

    进程内 mock 只能证明"调用了、没抛",证明不了 SQL 本身还对不对
    (CURDATE()/DATE_SUB/GROUP BY 都是库侧语义)。这里在真库上落真数据再核对。
    """
    await _prepare(monkeypatch)
    uid = await _mk_user("ovuser", 30)
    # 两笔付费开通(order + card),金额 18 + 88
    await userauth._q("DELETE FROM guantai_jf_grant_log WHERE user_id=%s", (uid,))
    for src, code, amt, h in (("order", "d3", 18.0, 72), ("card", "m1", 88.0, 744)):
        await userauth._q(
            "INSERT INTO guantai_jf_grant_log (user_id,user_name,source,ref,plan_code,"
            "amount,jf_hours,dd_hours,operator,created_at) "
            "VALUES (%s,'ovuser',%s,'r',%s,%s,%s,%s,'',NOW())",
            (uid, src, code, amt, h, h))
    # 一笔手动开通:**不计入**今日/7日金额(口径只认 order/card)
    await userauth._q(
        "INSERT INTO guantai_jf_grant_log (user_id,user_name,source,ref,plan_code,"
        "amount,jf_hours,dd_hours,operator,created_at) "
        "VALUES (%s,'ovuser','admin','客服补偿','m1',0,744,744,'admin',NOW())", (uid,))
    # 在期 VIP 一条
    await userauth._q(
        "INSERT INTO guantai_jf_vip (user_id,vip_until,first_at,total_hours,updated_at) "
        "VALUES (%s, DATE_ADD(NOW(), INTERVAL 10 DAY), NOW(), 744, NOW()) "
        "ON DUPLICATE KEY UPDATE vip_until=DATE_ADD(NOW(), INTERVAL 10 DAY)", (uid,))
    # 未使用卡密两张
    err, out = await jfvip.gen_cards(2, "d3", "OVBATCH", "", "tester")
    assert not err, err

    ov = await jfvip.overview()

    assert ov["degraded"] == [], f"真库健康时不该有降级项:{ov['degraded']}"
    assert ov["vipAlive"] >= 1
    assert ov["today"]["grants"] == 2, "今日开通应只数 order+card,不含 admin"
    assert abs(ov["today"]["amount"] - 106.0) < 0.01, ov["today"]["amount"]
    assert ov["week"]["grants"] == 2 and abs(ov["week"]["amount"] - 106.0) < 0.01
    assert ov["byPlan"] == {"d3": 1, "m1": 1}, ov["byPlan"]
    assert ov["cardsUnused"] >= 2
    assert "freeVisits7d" in ov, "登录日志表缺失时也该出数(表由 _ensure_schema 建)"


@needs_db
@pytest.mark.asyncio
async def test_overview_degraded_on_real_db_when_table_dropped(monkeypatch):
    """★ 在**真库**上制造一段取数失败:把卡密表临时改名。

    进程内 mock 抛的是我自己造的异常;这里抛的是 aiomysql 真实的
    ProgrammingError(1146 表不存在)—— 证明 `_stat` 的 `except Exception`
    确实兜得住驱动层异常,而不只是兜得住我写的 RuntimeError。
    """
    await _prepare(monkeypatch)
    await userauth._q("RENAME TABLE guantai_jf_card TO guantai_jf_card_bak")
    try:
        ov = await jfvip.overview()
    finally:
        await userauth._q("RENAME TABLE guantai_jf_card_bak TO guantai_jf_card")
    assert ov["degraded"] == ["cardsUnused"], ov["degraded"]
    assert "cardsUnused" not in ov, "失败的键仍留了值,前端会把它当真数显示"
    # 其余统计一个不少 —— 单点故障不许拖垮整页
    for k in ("vipAlive", "today", "week", "byPlan", "freeVisits7d"):
        assert k in ov, f"{k} 被无关故障带塌了"


# ══════════════════════════════════════════════════════════════════════════════
# 二、cards_disable(undo=) —— 本轮新接出来的「恢复整批」
# ══════════════════════════════════════════════════════════════════════════════
@needs_db
@pytest.mark.asyncio
async def test_card_disable_then_undo_round_trip(monkeypatch):
    """★ 作废弹窗原先白纸黑字写着「可用同一入口恢复」,而前端从未发过 undo。
    本轮把后端早已实现的能力接了出来 —— 这里在真库上验证整个来回真的成立。
    """
    await _prepare(monkeypatch)
    err, out = await jfvip.gen_cards(5, "d3", "UNDOB", "回归批", "tester")
    assert not err, err

    async def _cnt(**w):
        cond = " AND ".join(f"{k}={v}" for k, v in w.items())
        r = await userauth._q(f"SELECT COUNT(*) AS n FROM guantai_jf_card "
                              f"WHERE batch='UNDOB' AND {cond}", fetch="one")
        return int(r["n"])

    assert await _cnt(disabled=0) == 5
    n = await jfvip.cards_disable(batch="UNDOB")
    assert n == 5 and await _cnt(disabled=1) == 5, "作废未生效"
    n = await jfvip.cards_disable(batch="UNDOB", undo=True)
    assert n == 5 and await _cnt(disabled=0) == 5, "恢复未生效 —— 弹窗承诺就成了谎话"


@needs_db
@pytest.mark.asyncio
async def test_disable_never_touches_used_cards(monkeypatch):
    """★ 已兑换的卡不得被作废/恢复动到 —— 时长已经发出去了,改状态会让
    流水与卡状态自相矛盾。这条是后端既有纪律,本轮把 UI 接出来后更需钉住。"""
    await _prepare(monkeypatch)
    uid = await _mk_user("carduser", 30)
    err, out = await jfvip.gen_cards(3, "d3", "USEDB", "", "tester")
    assert not err
    card = out["cards"][0]
    err, _ = await jfvip.grant_by_card(uid, "carduser", card)
    assert not err, err

    await jfvip.cards_disable(batch="USEDB")
    r = await userauth._q("SELECT disabled, used_by FROM guantai_jf_card "
                          "WHERE card=%s", (card,), fetch="one")
    assert int(r["used_by"]) == uid and int(r["disabled"]) == 0, \
        "已兑换的卡被作废了(会造成流水与卡状态互相打架)"
    # 未使用的两张应已作废
    r = await userauth._q("SELECT COUNT(*) AS n FROM guantai_jf_card "
                          "WHERE batch='USEDB' AND disabled=1", fetch="one")
    assert int(r["n"]) == 2


# ══════════════════════════════════════════════════════════════════════════════
# 三、负数 jf_hours 的真库往返 —— CSV 钝化缺陷的根
# ══════════════════════════════════════════════════════════════════════════════
@needs_db
@pytest.mark.asyncio
async def test_revoke_writes_negative_hours_and_survives_paging(monkeypatch):
    """★ 这条是 CSV 缺陷的**根因验证**。

    我曾把公式注入防护写成「`-` 开头一律前置单引号」,于是 `-240` 变 `'-240`,
    Excel 当文本 —— 运维在**唯一对账口径**上做 SUM 会把撤销行整体漏掉。
    前提是「撤销真的会往库里写负数」。此前只读过代码,这里在真库上坐实,
    并确认它原样穿过 grants_page() 到达前端。
    """
    await _prepare(monkeypatch)
    uid = await _mk_user("revuser", 30)
    err, _ = await jfvip.grant_by_admin(uid, "revuser", "m1", "admin", "先开通")
    assert not err, err
    err, _ = await jfvip.revoke_by_admin(uid, "revuser", 240, "admin", "误开通回滚")
    assert not err, err

    row = await userauth._q(
        "SELECT jf_hours FROM guantai_jf_grant_log WHERE user_id=%s AND source='revoke' "
        "ORDER BY id DESC LIMIT 1", (uid,), fetch="one")
    assert int(row["jf_hours"]) == -240, f"撤销未写负数,实际 {row['jf_hours']}"

    page = await jfvip.grants_page(1, 50, uid=uid, source="revoke")
    assert page["items"], "撤销流水未出现在分页里"
    assert page["items"][0]["jfHours"] == -240, "负数在分页序列化时被改写了"
    assert page["items"][0]["ddHours"] == 0, "撤销不该回收小叮当时长"


@needs_db
@pytest.mark.asyncio
async def test_revoke_never_pushes_expiry_into_the_past(monkeypatch):
    """★ 撤销口径是 `GREATEST(NOW(), vip_until - N)` —— 扣到底也不制造
    「过去的到期时间」这种脏态。管理台弹窗的到期预览按同一公式本地算,
    少一个 GREATEST 就会把「其实已经归零」说成「还剩几天」。"""
    await _prepare(monkeypatch)
    uid = await _mk_user("revuser2", 30)
    err, _ = await jfvip.grant_by_admin(uid, "revuser2", "d3", "admin", "开 72 小时")
    assert not err
    # 扣掉远超已开通的时长
    err, _ = await jfvip.revoke_by_admin(uid, "revuser2", 8928, "admin", "扣到底")
    assert not err
    r = await userauth._q("SELECT vip_until, vip_until <= NOW() AS past, "
                          "TIMESTAMPDIFF(SECOND, NOW(), vip_until) AS diff "
                          "FROM guantai_jf_vip WHERE user_id=%s", (uid,), fetch="one")
    assert abs(int(r["diff"])) <= 5, f"到期被推到了过去/未来:diff={r['diff']}s"


# ══════════════════════════════════════════════════════════════════════════════
# 四、cards_page 的 plan 过滤 —— 本轮新加的 UI 下拉,后端参数此前无人调用
# ══════════════════════════════════════════════════════════════════════════════
@needs_db
@pytest.mark.asyncio
async def test_cards_page_plan_filter_actually_filters(monkeypatch):
    """★ `JV.cards.plan` 早就在前端状态里,却**没有任何 UI 能设置它** ——
    本轮补了档位下拉。既然真被调用了,就得确认后端这个参数是有效的。"""
    await _prepare(monkeypatch)
    await userauth._q("DELETE FROM guantai_jf_card WHERE batch IN ('PF_A','PF_B')")
    await jfvip.gen_cards(3, "d3", "PF_A", "", "t")
    await jfvip.gen_cards(2, "m1", "PF_B", "", "t")

    d3 = await jfvip.cards_page(1, 50, plan_code="d3")
    m1 = await jfvip.cards_page(1, 50, plan_code="m1")
    assert all(i["plan"] == "d3" for i in d3["items"]), "plan 过滤没生效"
    assert all(i["plan"] == "m1" for i in m1["items"])
    assert d3["total"] >= 3 and m1["total"] >= 2

    # 档位 + 状态 组合过滤(前端两个下拉可以同时用)
    await jfvip.cards_disable(batch="PF_A")
    both = await jfvip.cards_page(1, 50, status="disabled", plan_code="d3")
    assert both["total"] >= 3 and all(i["disabled"] for i in both["items"])
    unused_d3 = await jfvip.cards_page(1, 50, status="unused", plan_code="d3")
    assert all(not i["disabled"] and not i["used"] for i in unused_d3["items"])


# ══════════════════════════════════════════════════════════════════════════════
# 五、导出分页去重的真库前提 —— 后端确实按 id DESC 排,页边界确实会重叠
# ══════════════════════════════════════════════════════════════════════════════
@needs_db
@pytest.mark.asyncio
async def test_paging_overlaps_when_rows_inserted_midway(monkeypatch):
    """★ 前端 `jvFetchAll` 加了按 id 去重。理由是「取数期间有人发新卡,
    ORDER BY id DESC 会让后续页整体下移、页边界那条被取两遍」。

    这个前提此前是**推演**。这里在真库上坐实:取完第 1 页后插入新行,
    再取第 2 页,确认确实出现重复 id —— 去重不是多余的保险。
    """
    await _prepare(monkeypatch)
    await userauth._q("DELETE FROM guantai_jf_card WHERE batch='OVERLAP'")
    await jfvip.gen_cards(6, "d3", "OVERLAP", "", "t")

    p1 = await jfvip.cards_page(1, 3, batch="OVERLAP")
    assert len(p1["items"]) == 3
    # 模拟「取数中途有人发卡」
    await jfvip.gen_cards(1, "d3", "OVERLAP", "", "t")
    p2 = await jfvip.cards_page(2, 3, batch="OVERLAP")

    ids1 = [i["id"] for i in p1["items"]]
    ids2 = [i["id"] for i in p2["items"]]
    assert set(ids1) & set(ids2), \
        "本轮预期的页边界重叠未复现 —— 若排序口径已改,前端去重的理由需重新论证"
    # 去重后条数正确(与前端 jvFetchAll 同一算法)
    merged, seen = [], set()
    for r in ids1 + ids2:
        if r not in seen:
            seen.add(r)
            merged.append(r)
    assert len(merged) == len(set(ids1 + ids2)) < len(ids1 + ids2), "去重未起作用"


# ══════════════════════════════════════════════════════════════════════════════
# 五、订单检索(4.2.6)—— 十项谓词、封顶计数、页码夹紧
# ══════════════════════════════════════════════════════════════════════════════
# 本轮改动全部落在 SQL 拼装上,而 SQL 拼装恰恰是「进程内 mock 测不出、源码
# 扫描也测不出」的那一类:谓词写错(比如 amount>=%s 写成 amount>%s)、
# 参数顺序错位、LIKE 元字符没转义 —— 三者在纸面上都长得对。必须真库跑。
async def _mk_order(no: str, uid: int, name: str, plan: str, amount: float,
                    status: str, *, sim: int = 0, cred: int = 0,
                    days_ago: int = 0) -> None:
    await userauth._q(
        "INSERT INTO guantai_jf_order (gateway_order_no,user_id,user_name,plan_code,"
        "jf_hours,dd_hours,amount,status,credited,is_simulate,ip,create_time) "
        "VALUES (%s,%s,%s,%s,0,0,%s,%s,%s,%s,'',DATE_SUB(NOW(), INTERVAL %s DAY))",
        (no, uid, name, plan, amount, status, cred, sim, days_ago))


async def _seed_orders(monkeypatch) -> int:
    await _prepare(monkeypatch)
    await userauth._q("DELETE FROM guantai_jf_order")
    uid = await _mk_user("ordman", 30)
    await _mk_order("GWAAA001", uid, "ordman", "d3", 18.0, "paid", cred=1, days_ago=0)
    await _mk_order("GWAAA002", uid, "ordman", "m1", 88.0, "pending", days_ago=1)
    await _mk_order("GWBBB003", uid, "ordman", "m1", 88.0, "paid", sim=1, cred=1, days_ago=2)
    await _mk_order("GWBBB004", 999999, "ghostuser", "d3", 18.0, "expired", days_ago=9)
    return uid


@needs_db
@pytest.mark.asyncio
async def test_order_search_each_predicate_actually_filters(monkeypatch):
    """十项谓词逐条验证 —— 每条都必须真的收窄结果,不能是界面上的摆设。"""
    uid = await _seed_orders(monkeypatch)
    nos = lambda d: sorted(i["orderNo"] for i in d["items"])

    # 订单号:**前缀**匹配(中缀在真库实测要扫 200,048 行,故刻意不支持)
    assert nos(await jfvip.orders_page(1, 50, order_no="GWAAA")) == ["GWAAA001", "GWAAA002"]
    # 中缀不该命中 —— 若哪天有人手贱改成 '%'+x+'%',这条会立刻变红
    assert (await jfvip.orders_page(1, 50, order_no="AAA"))["total"] == 0

    # 用户名:解析成 uid 后按 user_id 查(裸 user_name= 实测 400,000 行)
    d = await jfvip.orders_page(1, 50, user_name="ordman")
    assert d["total"] == 3 and not d["userNotFound"]
    # 用户已注销:解析不到 → 回退历史快照名,**仍须查得到**(那正是要查它的时候)
    d = await jfvip.orders_page(1, 50, user_name="ghostuser")
    assert d["total"] == 1 and d["userNotFound"] is True
    assert nos(d) == ["GWBBB004"]

    assert (await jfvip.orders_page(1, 50, uid=uid))["total"] == 3
    assert (await jfvip.orders_page(1, 50, status="paid"))["total"] == 2
    assert (await jfvip.orders_page(1, 50, plan_code="m1"))["total"] == 2
    assert (await jfvip.orders_page(1, 50, simulate="1"))["total"] == 1
    assert (await jfvip.orders_page(1, 50, credited="0"))["total"] == 2

    # 金额:边界必须是**闭区间** —— 写成 > / < 会把恰好等于边界的单悄悄漏掉
    assert (await jfvip.orders_page(1, 50, amt_min=18, amt_max=18))["total"] == 2
    assert (await jfvip.orders_page(1, 50, amt_min=88))["total"] == 2
    # 上下限填反了要自动调过来,而不是回空表让人以为没数据
    assert (await jfvip.orders_page(1, 50, amt_min=200, amt_max=10))["total"] == 4

    # 组合条件按 AND 收窄
    assert (await jfvip.orders_page(1, 50, status="paid", plan_code="m1"))["total"] == 1


@needs_db
@pytest.mark.asyncio
async def test_order_date_range_includes_both_endpoints(monkeypatch):
    """只给日期时,终点必须补到 23:59:59。

    补成 00:00:00 会把终点当天**整天漏掉** —— 「查 1 号到 3 号」少一天,
    对账对不上却毫无提示,是最难查的一类账务 bug。
    """
    await _seed_orders(monkeypatch)
    import datetime as _dt
    # 5.2.0 复查:「今天」必须取**库钟**的日期 —— _norm_dt 明文约定全链路用库钟本地时刻,种子
    # 订单也用 NOW()。旧写法取宿主机本地日期:宿主时区与库时区不一致时(如宿主 UTC、库 +08:00),
    # 每天有 8 小时两者跨日,本用例随时段红绿(实测北京时间 01:06 复现),与被测代码无关。
    row = await userauth._q("SELECT CURDATE() AS d", fetch="one")
    today = row["d"] if isinstance(row["d"], _dt.date) else _dt.date.fromisoformat(str(row["d"])[:10])
    d = await jfvip.orders_page(1, 50, date_from=str(today), date_to=str(today))
    assert d["total"] == 1, "今天下的单没被含进 [今天, 今天] 区间(终点没补到当天末尾)"
    d = await jfvip.orders_page(1, 50, date_from=str(today - _dt.timedelta(days=2)),
                                date_to=str(today))
    assert d["total"] == 3
    # 非法日期 → 条件失效,而不是塞进 SQL 让库隐式转 0000-00-00 后静默查空
    assert (await jfvip.orders_page(1, 50, date_from="2026-13-45"))["total"] == 4
    assert (await jfvip.orders_page(1, 50, date_from="'; DROP TABLE x--"))["total"] == 4


@needs_db
@pytest.mark.asyncio
async def test_order_like_metachars_are_escaped(monkeypatch):
    """订单号里粘进 % 或 _ 不得退化成通配。

    不转义的话,运维搜一个含 % 的串会变成**全表扫**,而屏幕上完全看不出
    发生了什么 —— 结果多得离谱,却没人知道为什么。
    """
    await _seed_orders(monkeypatch)
    assert (await jfvip.orders_page(1, 50, order_no="%"))["total"] == 0
    assert (await jfvip.orders_page(1, 50, order_no="GWAAA00_"))["total"] == 0


@needs_db
@pytest.mark.asyncio
async def test_count_is_capped_and_page_is_clamped(monkeypatch):
    """封顶计数 + 页码夹紧。

    真库实测:裸 COUNT(*) 无筛选在 40 万行上扫 400,000 行,且**第 1 页就要付**;
    封顶后缩放律 ≈2×cap,与表总量脱钩。此处用小 cap 验证语义(行为等价)。
    """
    await _seed_orders(monkeypatch)
    n, capped = await jfvip._count_capped("guantai_jf_order", "1=1", (), cap=2)
    assert (n, capped) == (2, True), "命中数超过 cap 时应回 (cap, True)"
    n, capped = await jfvip._count_capped("guantai_jf_order", "1=1", (), cap=99)
    assert (n, capped) == (4, False), "未超上限时必须回精确值"

    # 越界页码要落到末页,而不是让库倒扫整棵主键后回一页空
    d = await jfvip.orders_page(99999999, 2)
    assert d["page"] == 2 and len(d["items"]) == 2, "越界页码未被夹到末页"
    # 空结果集恒回第 1 页(空表不该显示「第 3 页」)
    d = await jfvip.orders_page(7, 50, status="nosuchstatus")
    assert d["page"] == 1 and d["total"] == 0


@needs_db
@pytest.mark.asyncio
async def test_calendar_invalid_dates_are_rejected_not_guessed(monkeypatch):
    """日历上不存在的日期必须**条件失效**,不能塞给库去猜。

    真库实测:`create_time >= '2026-02-30'` MariaDB **既不报错也不返空**,
    而是把这个根本不存在的日期当成 2 月 29 与 3 月 1 之间的一个点来比较,
    回了 138,332 行。运维拿到一份边界说不清的对账数据却毫无察觉 ——
    比直接报错危险得多。只判「1<=月<=12 且 1<=日<=31」是拦不住的。
    """
    await _seed_orders(monkeypatch)
    total = (await jfvip.orders_page(1, 50))["total"]
    for bad in ("2026-02-30", "2026-04-31", "2026-02-29", "2026-00-10", "2026-01-00"):
        d = await jfvip.orders_page(1, 50, date_from=bad)
        assert d["total"] == total, f"{bad} 未被挡下,被当成了真实边界"
    # 真闰日必须放行 —— 校验不能宽到把合法输入也吃掉
    assert jfvip._norm_dt("2024-02-29") == "2024-02-29 00:00:00"


@needs_db
@pytest.mark.asyncio
async def test_user_not_found_flag_never_lies_on_db_hiccup(monkeypatch):
    """`userNotFound` 只在**真的查无此人**时置位。

    解析用户名要打 tb_user;库瞬时抖动时同样会走「快照名」兜底路径,但此时
    **不能**告诉运维「该用户不存在」—— 那是一句假话,会把一次瞬时故障误导成
    「这人已注销」,据此做的封禁/退款判断全是错的。
    """
    await _seed_orders(monkeypatch)

    async def _boom(_name):
        raise ConnectionError("userdb down")

    monkeypatch.setattr(jfvip, "resolve_user", _boom)
    d = await jfvip.orders_page(1, 50, user_name="ordman")
    assert d["userNotFound"] is False, "库抖动被误报成「用户不存在」"
    assert d["total"] == 3, "抖动时未回退到快照名匹配,历史订单查不出来了"


@needs_db
@pytest.mark.asyncio
async def test_non_gbk_user_name_does_not_explode(monkeypatch):
    """gbk 表示不了的用户名(emoji 等)必须回空结果,而不是抛 UnicodeEncodeError。

    真库实测原缺陷:resolve_user() 吞掉异常回 None → 快照回退把同一个串塞进
    user_name=%s → aiomysql 以 gbk 编码参数时抛异常 → 一路穿到 FastAPI = 管理台 500。
    """
    await _seed_orders(monkeypatch)
    for name in ("user\U0001f41femoji", "\U0001f389", "\U0001f600ab"):
        d = await jfvip.orders_page(1, 10, user_name=name)
        assert d["total"] == 0 and d["items"] == []
        assert d["userNotFound"] is True, "应按「查无此人」呈现"
    # 正常的中文名仍要能查(校验不能宽到把合法输入也吃掉)
    d = await jfvip.orders_page(1, 10, user_name="ordman")
    assert d["total"] == 3


# ══════════════════════════════════════════════════════════════════════════════
# 六、端到端:HTTP 查询参数 → FastAPI → orders_page → SQL(4.2.6 第六轮)
# ══════════════════════════════════════════════════════════════════════════════
# 前五轮把这条链路**拆成三段分别验**:jsdom 验前端发出了 `orderNo=`、契约测试验
# 端点签名里有 `orderNo`、真库测试验 `orders_page(order_no=...)` 能筛。
# 三段各自绿,**接缝却没人验过** —— 端点里写成 `order_no=orderNo` 还是
# `order_no=userName`,三段测试全都发现不了:参数被静默丢弃或接错,界面照常
# 返回一页数据,只是筛选悄悄失效。这类「每段都对、连起来错」正是本项目
# test_jfvip_contract 开篇说的**沉默的漂移**。本节走真实 ASGI 栈 + 真库补上。
@needs_db
@pytest.mark.asyncio
async def test_every_filter_survives_the_http_hop(monkeypatch):
    import httpx
    import app.admin_api as admin_api
    import app.web as web

    uid = await _seed_orders(monkeypatch)
    monkeypatch.setattr(admin_api, "_guard", lambda request: {"csrf": "c", "sub": "admin"})

    async def get(**kw):
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=web.app),
                                     base_url="http://t") as c:
            r = await c.get(_ADM + "/jfvip/orders", params=kw)
        assert r.status_code == 200, f"{kw} → HTTP {r.status_code}: {r.text[:200]}"
        return r.json()

    base = await get()
    assert base["total"] == 4, "夹具未就绪"

    # 每个参数单独走一遍 HTTP:命中数必须与直调 orders_page 完全一致
    cases = [
        ({"orderNo": "GWAAA"}, 2),
        ({"userName": "ordman"}, 3),
        ({"uid": uid}, 3),
        ({"status": "paid"}, 2),
        ({"plan": "m1"}, 2),
        ({"amtMin": "88"}, 2),
        ({"amtMax": "18"}, 2),
        ({"simulate": "1"}, 1),
        ({"credited": "0"}, 2),
        ({"status": "paid", "plan": "m1"}, 1),
    ]
    for params, want in cases:
        d = await get(**params)
        assert d["total"] == want, f"{params} 经 HTTP 后命中 {d['total']},应为 {want} —— 参数在接缝处丢了或接错了"

    # 参数**确实生效**,而不是碰巧等于全集
    assert (await get(orderNo="GWAAA"))["total"] != base["total"]
    assert (await get(simulate="1"))["total"] != base["total"]

    # 形态闸:越界值由 FastAPI 直接 422,不进业务层
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=web.app),
                                 base_url="http://t") as c:
        assert (await c.get(_ADM + "/jfvip/orders", params={"size": 9999})).status_code == 422
        assert (await c.get(_ADM + "/jfvip/orders", params={"page": 0})).status_code == 422
        assert (await c.get(_ADM + "/jfvip/orders", params={"page": -1})).status_code == 422
        # 日期非法 → 条件失效(不是 422,也不是崩)
        r = await c.get(_ADM + "/jfvip/orders", params={"dateFrom": "2026-02-30"})
        assert r.status_code == 200 and r.json()["total"] == 4


@needs_db
@pytest.mark.asyncio
async def test_user_facing_orders_endpoint_still_works(monkeypatch):
    """`/api/vip/orders` 也调 orders_page —— 本轮改了签名与返回,必须真跑一遍。

    它是**用户侧**端点(任何登录用户都够得着),前五轮只做过静态核对。
    """
    import httpx
    import app.web as web

    uid = await _seed_orders(monkeypatch)

    # ⚠ 认证必须桩在 `userauth.validate` 上,不能桩 `web._vip_user` ——
    #   项目有一道全局中间件 `_user_auth_middleware`(web.py:290)在**路由之前**
    #   调 `userauth.guard()`,取不到会话直接回 401,端点根本不会被执行。
    #   初版桩错层,实测 `_vip_user` 调用次数为 0、响应 401,险些被读成产品缺陷。
    #   此处沿用 test_jfvip_asgi.py::wired 的既有写法,不另立门户。
    class _P:
        user_id = uid
        user_name = "ordman"
        tier = "vip"
        due_time_iso = ""
        dd_alive = True

    async def _validate(token):
        return ("ok", _P(), {}) if token else ("auth_required", None, {})

    monkeypatch.setattr(userauth, "validate", _validate)
    # 来源校验头同样是中间件层要求(缺了回 bad_origin),沿用 test_jfvip_asgi 的 CSRF 常量
    ck, hd = {"jf_user_sid": "vip"}, {"X-JF-Auth": "1"}
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=web.app),
                                 base_url="http://t", cookies=ck, headers=hd) as c:
        r = await c.get("/api/vip/orders")
        assert r.status_code == 200, r.text
        j = r.json()
        assert j["ok"] and j["orders"]["total"] == 3, j
        # 深页码不再由参数决定 OFFSET —— 被 _clamp_page 夹到末页
        r2 = await c.get("/api/vip/orders", params={"page": 99999, "size": 2})
        assert r2.status_code == 200
        assert r2.json()["orders"]["page"] == 2, "越界页码未被夹紧"
        # 形态闸生效
        assert (await c.get("/api/vip/orders", params={"size": 9999})).status_code == 422


# ══════════════════════════════════════════════════════════════════════════════
# 七、卡密前缀 JF → TL(4.2.7)—— 真库端到端
# ══════════════════════════════════════════════════════════════════════════════
@needs_db
@pytest.mark.asyncio
async def test_new_cards_are_tl_and_legacy_jf_cards_still_redeem(monkeypatch):
    """发卡落库为 TL;而**手工塞一张 JF 存量卡进去,仍要能兑换成功**。

    形态闸只是第一道；真正决定成败的是「兑换事务能不能认这张卡」。
    只测 card_valid_shape 不够 —— 那是纯函数,测不出落库/查卡/开通这条链路。
    """
    await _prepare(monkeypatch)
    await userauth._q("DELETE FROM guantai_jf_card")
    uid = await _mk_user("cardman", 30)

    err, out = await jfvip.gen_cards(5, "d3", "TLBATCH", "", "admin")
    assert err == "", err
    assert all(c.startswith("TL") for c in out["cards"]), out["cards"]
    rows = await userauth._q("SELECT card FROM guantai_jf_card", fetch="all")
    assert all(r["card"].startswith("TL") for r in rows), "落库的卡不是 TL 前缀"

    # 手工造一张历史 JF 卡(模拟改前缀之前就发出去、尚未兑换的那些)
    legacy = "JFZZZZZZ987654"
    await userauth._q(
        "INSERT INTO guantai_jf_card (card, plan_code, batch, note, created_at) "
        "VALUES (%s,'d3','LEGACY','改前缀前发出的存量卡', NOW())", (legacy,))
    assert jfvip.card_valid_shape(legacy), "存量卡过不了形态闸"
    err, res = await jfvip.grant_by_card(uid, "cardman", legacy)
    assert err == "", f"存量 JF 卡兑换失败({err}) —— 这就是资损"
    used = await userauth._q("SELECT used_by FROM guantai_jf_card WHERE card=%s",
                             (legacy,), fetch="one")
    assert int(used["used_by"]) == uid, "存量卡未被正确标记为已使用"

    # 新卡同样能兑换(别修好老的、弄坏新的)
    err2, _ = await jfvip.grant_by_card(uid, "cardman", out["cards"][0])
    assert err2 == "", err2
