"""test_jfvip_admin_runtime.py — 「值」视图后端的**真执行**验证(4.2.5 第四轮复审)

前三轮的验证有一个共同盲区:`degraded` 与 503 两条改动,一直只做**源码扫描**
(assert 某字符串在文件里)与**前端桩**(手工构造响应)。源码里写着 ≠ 运行时真这样。

本文件补的正是这一层:
  · overview() 在取数抛异常时,是否真的把键名收进 degraded[],且不拖垮其余统计;
  · 4 个列表类 GET 在关闭态,经**真实 ASGI 栈**是否真回 503(而非 200 + ok:false);
  · /jfvip/overview 是否**真的**豁免在外(前端靠它的 reason 渲染指引页)。
"""
from __future__ import annotations

import httpx
import pytest

import app.admin_api as admin_api
import app.jfvip as jfvip
import app.userauth as userauth
import app.web as web
from app.settings import UserAuthCfg

pytestmark = pytest.mark.asyncio


# ══════════════════════════════════════════════════════════════════════════════
# 一、overview() 的降级上报 —— 真跑,不扫源码
# ══════════════════════════════════════════════════════════════════════════════
# 5.3.0:管理面挂在配置的入口路径下(默认 /api/admin-xdd);整站 web.app 的用例取其实际前缀。
# 外部发卡接口 /api/admin/jfvip/cards/issue 是恒定地址,仍按字面量写。
from app import admin_auth as _admin_auth  # noqa: E402
_ADM = _admin_auth.api_prefix()


@pytest.fixture()
def vip_on(monkeypatch):
    """把九法VIP 拨到「已启用」,但不连任何真库。"""
    # cfg.enabled 是由 host/db/user 算出的 property(无 setter),须按既有约定构造 ——
    # 与 test_jfvip_asgi.py 的 wired fixture 同款,不另立门户。
    cfg = UserAuthCfg(host="h", port=3306, db="d", user="u", password="p",
                      charset="gbk", jf_vip_enabled=True, cache_ttl_s=0.0)
    monkeypatch.setattr(userauth.UA, "cfg", cfg, raising=False)
    monkeypatch.setattr(userauth.UA, "pool", object(), raising=False)
    monkeypatch.setattr(jfvip, "plans", lambda: [
        {"code": "m1", "name": "1 个月", "price": 88.0,
         "jfHours": 744, "ddHours": 744, "tag": ""}])
    return cfg


def _q_router(rules):
    """按 SQL 里的**特征片段**派发(不能只认表名 —— grant_log 上有三段查询,
    其中 byPlan 走 fetch="all" 要列表,today/week 走 fetch="one" 要字典,
    回错形态会伪造出与产品无关的失败)。值为 Exception 则抛,否则原样回。"""
    async def _q(sql, args=(), fetch=None):
        for key, val in rules.items():
            if key in sql:
                if isinstance(val, Exception):
                    raise val
                return val
        raise AssertionError(f"测试桩未覆盖的 SQL,请补规则:{sql[:120]}")
    return _q


# overview() 实际发出的六段查询,各取一段**唯一**特征
SQL_VIP_ALIVE = "FROM guantai_jf_vip WHERE vip_until > NOW()"
SQL_TODAY = "created_at >= CURDATE()"
# ⚠ 特征必须**无歧义**:freeVisits7d 的 SQL 同样含 "INTERVAL 7 DAY",
#   只截那一段会把两条查询混为一谈(第一版就栽在这)。
SQL_WEEK = ("FROM guantai_jf_grant_log WHERE source IN ('order','card') "
            "AND created_at >= DATE_SUB")
SQL_BY_PLAN = "GROUP BY plan_code"
SQL_FREE = "FROM guantai_login_log"
SQL_CARDS = "FROM guantai_jf_card WHERE used_by=0"


async def test_overview_reports_each_failed_stat(vip_on, monkeypatch, capsys):
    """★ 单点取数失败必须**留痕**,而不是静默缺席。

    这正是原缺陷的要害:前端对缺席的键写 `?? 0`,于是屏幕渲染出
    「今日金额 ¥0.00」——**与"今天真的一分没卖出去"一模一样**。
    一次用户库故障会被运维读成一天零收入。
    """
    boom = RuntimeError("userdb gone")
    monkeypatch.setattr(userauth, "_q", _q_router({
        SQL_VIP_ALIVE: {"n": 12},                 # 正常
        SQL_TODAY: boom, SQL_WEEK: boom, SQL_BY_PLAN: boom,   # 流水表整段挂掉
        SQL_FREE: {"n": 47},                      # 正常
        SQL_CARDS: boom,                          # cardsUnused 失败
    }))
    out = await jfvip.overview()

    assert set(out["degraded"]) == {"today", "week", "byPlan", "cardsUnused"}, out["degraded"]
    # 失败的键**不得**留下一个假的 0 —— 必须整个缺席,由前端渲染成「?」
    for k in ("today", "week", "byPlan", "cardsUnused"):
        assert k not in out, f"{k} 取数失败却仍留了值,前端会把它当真数显示"
    # 未失败的统计照常出数 —— 单点故障不许拖垮整页
    assert out["vipAlive"] == 12
    assert out["freeVisits7d"] == 47
    assert out["enabled"] is True and out["plans"]
    # 必须打日志,否则运维事后无从追溯是哪一段挂了
    assert "概览统计" in capsys.readouterr().out


async def test_overview_degraded_empty_when_all_ok(vip_on, monkeypatch):
    """全绿时 degraded 必须是空列表(而非缺席)—— 前端 `ov.degraded || []`
    虽能兜底,但契约该给就得给,否则老前端与新前端行为不一致。"""
    monkeypatch.setattr(userauth, "_q", _q_router({
        SQL_VIP_ALIVE: {"n": 3},
        SQL_TODAY: {"n": 1, "amt": 88}, SQL_WEEK: {"n": 4, "amt": 352},
        SQL_BY_PLAN: [{"plan_code": "m1", "n": 4}],          # fetch="all" ⇒ 必须是列表
        SQL_FREE: {"n": 5}, SQL_CARDS: {"n": 9},
    }))
    out = await jfvip.overview()
    assert out["degraded"] == []
    assert out["today"]["amount"] == 88.0
    assert out["week"]["grants"] == 4
    assert out["byPlan"] == {"m1": 4}
    assert out["cardsUnused"] == 9


async def test_overview_survives_total_db_outage(vip_on, monkeypatch):
    """整库不可用时,概览仍须返回(带满员 degraded),而不是抛 500 ——
    否则「值」视图整页打不开,运维连"哪里坏了"都看不到。"""
    async def _boom(*a, **k):
        raise ConnectionError("pool dead")
    monkeypatch.setattr(userauth, "_q", _boom)
    out = await jfvip.overview()
    assert set(out["degraded"]) == {"vipAlive", "today", "week",
                                    "byPlan", "freeVisits7d", "cardsUnused"}
    assert out["enabled"] is True          # 开关状态不依赖库,必须仍然可读


# ══════════════════════════════════════════════════════════════════════════════
# 二、关闭态状态码 —— 经真实 ASGI 栈,不扫源码
# ══════════════════════════════════════════════════════════════════════════════
@pytest.fixture()
def admin_wired(monkeypatch):
    """放行管理台鉴权,并把九法VIP 拨到「关闭」。"""
    monkeypatch.setattr(admin_api, "_guard",
                        lambda request: {"csrf": "c", "sub": "admin"})
    monkeypatch.setattr(admin_api, "_guard_write",
                        lambda request: {"csrf": "c", "sub": "admin"})
    monkeypatch.setattr(jfvip, "enabled", lambda: False)
    monkeypatch.setattr(jfvip, "status", lambda: {
        "enabled": False, "reason": "switch_off",
        "message": "总开关 userauth.jf_vip_enabled 为关。"})


def _client() -> httpx.AsyncClient:
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=web.app),
                             base_url="http://t")


LIST_GETS = [_ADM + "/jfvip/cards", _ADM + "/jfvip/orders",
             _ADM + "/jfvip/grants", _ADM + "/jfvip/user?userName=x"]


@pytest.mark.parametrize("path", LIST_GETS)
async def test_list_gets_return_503_when_disabled(admin_wired, path):
    """★ 原缺陷:这 4 个 GET 回 **HTTP 200 + ok:false**,而同功能的 4 个 POST 回 503。

    前端 api() 判据是 `r.ok`,200 不抛 ⇒ 把失败当成功渲染成
    「共 undefined 张 · 第 undefined 页」(jsdom 实测复现)。
    健康探针 / 反代 / 日志同样会把故障读成正常。
    """
    async with _client() as c:
        r = await c.get(path)
    assert r.status_code == 503, f"{path} 仍回 {r.status_code}(前端会渲染成 undefined)"
    assert r.json().get("error") == "disabled", r.text


async def test_overview_stays_200_when_disabled(admin_wired):
    """★ /jfvip/overview **刻意豁免**,必须保持 200。

    前端要读它的 reason/message 才能渲染「未启用」的可操作指引页
    (开关没开?没重启?登录系统没配?)—— 那是 4.2.1 的核心。
    改成 503 会让整套诊断信息失效,只剩一句干巴巴的「载入失败」。
    这条钉子存在的意义,是防止后人「顺手把状态码统一了」。
    """
    async with _client() as c:
        r = await c.get(_ADM + "/jfvip/overview")
    assert r.status_code == 200, "overview 不得改 503 —— 前端靠它渲染未启用指引页"
    j = r.json()
    assert j["ok"] is True and j["enabled"] is False
    assert j["reason"] == "switch_off" and j["message"], "诊断信息缺失"


@pytest.mark.parametrize("path", [_ADM + "/jfvip/cards/generate",
                                  _ADM + "/jfvip/cards/disable",
                                  _ADM + "/jfvip/grant",
                                  _ADM + "/jfvip/revoke"])
async def test_write_posts_stay_503_when_disabled(admin_wired, path):
    """四个写入 POST 本来就是 503 —— 一并钉住,保证 GET/POST 口径不再分叉。"""
    async with _client() as c:
        r = await c.post(path, json={})
    assert r.status_code == 503, r.text
    assert r.json().get("error") == "disabled", r.text
