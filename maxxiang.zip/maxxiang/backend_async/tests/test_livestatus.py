"""
test_livestatus.py — 主播直播状态(5.0.6:名录 .ri-live 由装饰位改为状态位)全链回归
================================================================================
背景(实地核查实证,2026-08-12 真机实测;判据推导见 settings.LiveStatusCfg):
  ① 在播列表(discovery.sweep)是**推荐流**,不是在播全集:45s 两轮 A=1373/B=1387,
     A∖B 的 17 房逐个复核 roomStatus,**6 房(35%)仍在直播** —— 只看列表会让绿点
     无规律闪灭;
  ② 频道房(roomType=3)**从不上榜**:本项目固定房 321→2678075 实测 roomStatus
     liveStatus=1 却始终不在列表里 —— 只看列表等于对每个新用户的第一个房永久
     谎报「未开播」;
  ③ 反向地,在册是极可靠的**正**信号:在册房 2 分钟后复核 60 房,59 房仍在播 ——
     故遍历顺手记一笔即可,零请求;
  ④ roomStatus 取值域:code!=0 → 无此房;liveStatus=-1 且 kugouId=0 → 房号无主播
     绑定(短号)= **不可判**;0=未开播;1=直播中。
本文件按 test_rail_status 的三层谱系钉死:
  · Redis/Worker:观测只由**成功**探测改判、表随策展名录对齐、最旧优先轮转;
  · Web:卡片 live 三态(true/false/**null**)、过期即未知、开关关闭零命令;
  · 前端/源码静态守卫:三态在位、隐藏语义只对「未开播」、版本已 bump。
"""
from __future__ import annotations

import sys
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app.web as web
from app.redis_bus import RedisBus

ROOT = Path(__file__).resolve().parents[2]
APP_JS = ROOT / "assets" / "app.js"
APP_CSS = ROOT / "assets" / "app.css"
INDEX = ROOT / "index.html"
WEB_SRC = (Path(__file__).resolve().parent.parent / "app" / "web.py") \
    .read_text(encoding="utf-8")
WORKER_SRC = (Path(__file__).resolve().parent.parent / "app" / "worker.py") \
    .read_text(encoding="utf-8")
DISC_SRC = (Path(__file__).resolve().parent.parent / "app" / "discovery.py") \
    .read_text(encoding="utf-8")


class _WideDB:
    def __getattr__(self, name):
        async def _f(*a, **k):
            return None
        return _f


class _Star:
    async def canon(self, room):
        return str(room), True

    async def profile(self, room):
        return {}


def _bus():
    import fakeredis.aioredis
    b = RedisBus("redis://x")
    b.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    return b


@pytest.fixture()
def wired(monkeypatch):
    b = _bus()
    monkeypatch.setattr(web.ST, "bus", b, raising=False)
    monkeypatch.setattr(web.ST, "db", _WideDB(), raising=False)
    monkeypatch.setattr(web.ST, "star", _Star(), raising=False)
    ls = web.settings.livestatus
    saved = (ls.enabled, ls.stale_s)
    yield b
    (ls.enabled, ls.stale_s) = saved


# ══ 一、Redis 观测表语义 ══════════════════════════════════════════════════════
@pytest.mark.asyncio
async def test_bus_roundtrip_and_drop(wired):
    b = wired
    now = int(time.time() * 1000)
    await b.livestatus_set_bulk([("7001", 1), ("7002", 0)], ts=now)
    m = await b.livestatus_map()
    assert m["7001"] == (1, now) and m["7002"] == (0, now)
    assert await b.livestatus_get_many(["7001", "7999"]) == {"7001": (1, now)}
    await b.livestatus_drop_bulk(["7002"])
    assert "7002" not in await b.livestatus_map()
    # 脏值(旧格式/截断)按未知丢弃,绝不当成一句话讲出去
    await b.r.hset("rooms:livestatus", mapping={"7003": "x", "7004": "1"})
    m = await b.livestatus_map()
    assert "7003" not in m and "7004" not in m


# ══ 二、Web:卡片三态 + 过期 + 开关 ═══════════════════════════════════════════
@pytest.mark.asyncio
async def test_card_live_tristate(wired):
    b = wired
    now = int(time.time() * 1000)
    web.settings.livestatus.enabled = True
    c = await web._live_room_card("8001", now, live=(1, now))
    assert c["live"] is True and c["liveAt"]
    c = await web._live_room_card("8001", now, live=(0, now))
    assert c["live"] is False
    c = await web._live_room_card("8001", now)              # 无观测 = 未知
    assert c["live"] is None and c["liveAt"] == ""


@pytest.mark.asyncio
async def test_build_live_rooms_stale_becomes_unknown(wired):
    """观测过期必须降为 null(未知),**不得**压成 false ——
    worker 停摆恰恰是最该被识破的失效,而停摆的 worker 不会给自己的旧观测盖过期章。"""
    b = wired
    ls = web.settings.livestatus
    ls.enabled, ls.stale_s = True, 600
    now = int(time.time() * 1000)
    await b.add_rooms_bulk([("8101", "8101"), ("8102", "8102")])
    await b.livestatus_set_bulk([("8101", 1)], ts=now)
    await b.livestatus_set_bulk([("8102", 1)], ts=now - 601_000)   # 已过 stale_s
    by = {c["roomId"]: c for c in (await web._build_live_rooms())["rooms"]}
    assert by["8101"]["live"] is True
    assert by["8102"]["live"] is None, "过期观测必须回落未知,不许继续声称在播"


@pytest.mark.asyncio
async def test_switch_off_means_unknown_not_offline(wired):
    b = wired
    ls = web.settings.livestatus
    ls.enabled = False
    await b.add_rooms_bulk([("8201", "8201")])
    await b.livestatus_set_bulk([("8201", 1)])
    card = (await web._build_live_rooms())["rooms"][0]
    assert card["live"] is None and card["liveAt"] == ""


@pytest.mark.asyncio
async def test_auth_path_and_pending_room(wired, monkeypatch):
    """登录名录路径同样下发 live;待归一房(无真实房号)恒为未知。"""
    b = wired
    web.settings.livestatus.enabled = True

    class _DB(_WideDB):
        async def user_rooms_list(self, uid):
            return [{"room_id": "8301", "alias": "321"},
                    {"room_id": "8302", "alias": "8302"}]
    monkeypatch.setattr(web.ST, "db", _DB(), raising=False)
    await b.livestatus_set_bulk([("8301", 1), ("8302", 0)])
    by = {c["alias"]: c for c in
          (await web._build_live_rooms(SimpleNamespace(user_id=7)))["rooms"]}
    assert by["321"]["live"] is True and by["8302"]["live"] is False
    p = await web._live_room_card("8401", int(time.time() * 1000), pending=True)
    assert p["mode"] == "pending" and p["live"] is None


@pytest.mark.asyncio
async def test_live_rooms_route_asgi_e2e(wired):
    """路由层端到端:新字段过线且 null 如实序列化(不是被丢字段)。"""
    import httpx
    b = wired
    web.settings.livestatus.enabled = True
    await b.add_rooms_bulk([("8501", "8501"), ("8502", "8502")])
    await b.livestatus_set_bulk([("8501", 0)])
    tr = httpx.ASGITransport(app=web.app)
    async with httpx.AsyncClient(transport=tr, base_url="http://t") as c:
        r = await c.get("/api/live-rooms")
    by = {x["roomId"]: x for x in r.json()["rooms"]}
    assert by["8501"]["live"] is False
    assert "live" in by["8502"] and by["8502"]["live"] is None


# ══ 三、Worker:只由成功探测改判 / 表对齐 / 最旧优先 ═══════════════════════════
def _mini_worker(bus, curated, probe):
    """极简 worker 外壳:只装 _livestatus_once 需要的四件(bus/db/star/settings)。"""
    from app.worker import Worker
    w = Worker.__new__(Worker)
    w.bus = bus
    w.db = SimpleNamespace(active_rooms=lambda: _rooms(curated))
    w.star = SimpleNamespace(live_status=probe)
    w.s = SimpleNamespace(livestatus=SimpleNamespace(
        enabled=True, interval_s=60, fresh_s=90, stale_s=600,
        max_probe=300, concurrency=8, request_timeout=8.0))
    return w


async def _rooms(ids):
    return [{"room_id": r} for r in ids]


@pytest.mark.asyncio
async def test_probe_failure_never_flips_state():
    """探测失败(网络/上游/超时)一律不写 —— 旧观测保留,绝不改判成「未开播」。
    这是本特性的核心纪律:问不到 ≠ 没开播。"""
    b = _bus()
    now = int(time.time() * 1000)
    await b.livestatus_set_bulk([("9001", 1)], ts=now - 200_000)   # 已过保鲜期

    async def _fail(rid):
        raise RuntimeError("上游炸了")
    w = _mini_worker(b, ["9001"], _fail)
    await w._livestatus_once(w.s.livestatus)
    assert (await b.livestatus_map())["9001"][0] == 1, "失败不得改判"
    # 换成「问得到但不可判」(短号 liveStatus=-1 → live_status 回 None)同样不改判

    async def _unknown(rid):
        return None
    w = _mini_worker(b, ["9001"], _unknown)
    await w._livestatus_once(w.s.livestatus)
    assert (await b.livestatus_map())["9001"][0] == 1


@pytest.mark.asyncio
async def test_fresh_skip_and_table_alignment():
    """① 保鲜期内的房不消耗探测预算(常驻在播列表的房恒由遍历供货,零请求);
       ② 不再是策展房的观测项当轮删除,防表无界增长。"""
    b = _bus()
    now = int(time.time() * 1000)
    await b.livestatus_set_bulk([("9101", 1)], ts=now)              # 新鲜
    await b.livestatus_set_bulk([("9102", 1)], ts=now - 200_000)    # 过期
    await b.livestatus_set_bulk([("9199", 1)], ts=now)              # 已非策展房
    seen = []

    async def _probe(rid):
        seen.append(rid)
        return 0
    w = _mini_worker(b, ["9101", "9102"], _probe)
    await w._livestatus_once(w.s.livestatus)
    assert seen == ["9102"], f"只该探过期房,实际探了 {seen}"
    m = await b.livestatus_map()
    assert m["9102"][0] == 0 and "9199" not in m


@pytest.mark.asyncio
async def test_max_probe_oldest_first():
    """策展房超过 max_probe 时按**最旧优先**分轮覆盖(而非随机/字典序),
    保证每一房的观测年龄有界。"""
    b = _bus()
    now = int(time.time() * 1000)
    for i, age in enumerate([500_000, 300_000, 400_000]):
        await b.livestatus_set_bulk([(f"920{i}", 1)], ts=now - age)
    seen = []

    async def _probe(rid):
        seen.append(rid)
        return 1
    w = _mini_worker(b, ["9200", "9201", "9202"], _probe)
    w.s.livestatus.max_probe = 2
    await w._livestatus_once(w.s.livestatus)
    assert seen == ["9200", "9202"], f"应最旧优先,实际 {seen}"
    last = await b.livestatus_last()
    assert last and last["probed"] == 2 and last["probeOk"] == 2


# ══ 四、源码契约守卫 ══════════════════════════════════════════════════════════
def _seg(src: str, anchor: str, upto: str = "\nasync def ") -> str:
    seg = src.split(anchor, 1)
    assert len(seg) == 2, f"找不到锚点 {anchor!r}(重命名请同步本守卫)"
    return seg[1].split(upto, 1)[0]


def test_backend_contract_guard():
    card = _seg(WEB_SRC, "async def _live_room_card")
    assert '"live"' in card and '"liveAt"' in card
    helper = _seg(WEB_SRC, "async def _live_status_map", "\ndef ")
    assert "livestatus.enabled" in helper and "stale_s" in helper
    # 遍历顺手记的是**策展房 ∩ 在播列表**,且只记正信号(缺席不判)
    rec = _seg(DISC_SRC, "async def reconcile_discovered")
    assert "livestatus_set_bulk" in rec and "r in manual" in rec
    # worker:失败不写(只把 st is not None 的项落库)
    once = _seg(WORKER_SRC, "async def _livestatus_once")
    assert "st is not None" in once and "livestatus_drop_bulk" in once
    assert "asyncio.create_task(self._livestatus())" in WORKER_SRC


def test_frontend_tristate_guard():
    import re
    src = APP_JS.read_text(encoding="utf-8")
    chip = _seg(src, "function railLiveChip", "\nfunction ")
    assert "is-live" in chip and "is-unknown" in chip
    assert "r.live === true" in chip and "r.live === false" in chip
    # 未知态文案必须点明「不代表未开播」——否则灰环与隐藏在用户眼里没差别
    assert "不代表" in chip
    paint = _seg(src, "function railTickPaint", "\nasync function ")
    assert "railLiveChip" in paint and "dataset.la" in paint
    assert 'data-la="${esc(r.alias)}"' in src
    # 模板默认 hidden:首帧到数据落地之间不许先亮一颗无依据的绿点
    assert ('<i class="ri-live" data-la="${esc(r.alias)}" role="img" '
            'aria-label="" hidden></i>') in src
    # CSS 断言前先剥注释 —— 本轮的删除理由就写在注释里,不剥会自己命中自己
    css = re.sub(r"/\*.*?\*/", "", APP_CSS.read_text(encoding="utf-8"), flags=re.S)
    assert ".ri-live.is-live" in css and ".ri-live.is-unknown" in css
    assert ".room-item .ri-live[hidden]{display:none}" in css
    # 选中房的朱砂覆写必须删除:它会让「绿=在播」在当前正看的那一行失效
    assert ".room-item.is-on .ri-live" not in css
    # 携带信息的元素在 reduce 下必须仍可读(退为静态色块)。文件里有多个同名
    # 媒体块,逐块取出再判 —— 只要有一块把本类降为 animation:none 即可。
    blocks = re.findall(r"@media \(prefers-reduced-motion:reduce\)\s*\{(.*?)\n\}",
                        css, re.S)
    assert any(".ri-live.is-live" in b and "animation:none" in b for b in blocks)


def test_frontend_version_bumped():
    import re
    html = INDEX.read_text(encoding="utf-8")
    vs = set(re.findall(r"app\.(?:js|css)\?v=([0-9.]+)", html))
    assert len(vs) == 1, f"index.html 里 js/css 版本不一致:{vs}"
    cur = tuple(int(x) for x in vs.pop().split("."))
    assert cur >= (5, 0, 6), \
        f"app.js/app.css 的 ?v= 停在 {cur} —— 5.0.6 改了名录渲染却没 bump,"
    "带缓存/经 CDN 的老客户端会继续跑旧包(绿点恒亮),且重启服务器不会好"


# ══ 五、复查轮补钉(第二轮实地核查抓出的两处) ═══════════════════════════════
def test_probe_lock_has_renewal_heartbeat():
    """探测锁**必须**有续租心跳。首版按「常态一轮 ≈8s 远短于 60s 周期」省掉了它 ——
    那是拿成功路径的 RTT(0.4s)冒充最坏耗时。上游不可达时每发探测耗满
    request_timeout,同式变成 ⌈max_probe/concurrency⌉ × 8s ≈ 152s > 锁 TTL,
    锁在轮次途中过期 → 别的副本插队开第二轮,恰在上游已出问题时叠加请求。"""
    assert "livestatus_renew_lock" in WORKER_SRC
    assert "_live_lock_heartbeat" in WORKER_SRC
    hb = _seg(WORKER_SRC, "async def _live_lock_heartbeat", "\n    async def ")
    assert "livestatus_renew_lock" in hb and "ttl_s) / 3.0" in hb
    once = _seg(WORKER_SRC, "async def _livestatus(self)", "\n    async def ")
    assert "hb.cancel()" in once, "轮次结束必须停心跳,让锁自然到期(锁即节拍)"


def test_fresh_s_validator_benchmarks_sweep_cadence():
    """fresh_s 的对标物是**在播列表遍历周期**,不是 livestatus 自己的探测周期 ——
    首版拿后者比,两者默认都是 60 才碰巧对上;把 discovery.interval_s 调到 300 时
    零成本正信号已经形同虚设,旧逻辑却一声不吭。"""
    from app.config_center import semantic_validate
    base = {"livestatus.interval_s": 60, "livestatus.stale_s": 600,
            "livestatus.fresh_s": 90, "discovery.enabled": True}
    _, w = semantic_validate({**base, "discovery.interval_s": 300},
                             changed={"discovery.interval_s"})
    assert any("fresh_s" in x for x in w), "遍历周期拉大到 300 必须提示"
    _, w2 = semantic_validate({**base, "discovery.interval_s": 60},
                              changed={"discovery.interval_s"})
    assert not [x for x in w2 if "fresh_s" in x], "默认组合不得误报"
    # discovery 关闭时本就没有零成本供货,全量探测是预期行为,不提示
    _, w3 = semantic_validate({**base, "discovery.interval_s": 300,
                               "discovery.enabled": False},
                              changed={"discovery.interval_s"})
    assert not [x for x in w3 if "fresh_s" in x]
    # stale_s 不足两轮 = 静默失效区,必须是 error 而非 warning
    e, _ = semantic_validate({**base, "livestatus.interval_s": 3600,
                              "discovery.interval_s": 60},
                             changed={"livestatus.interval_s"})
    assert any("stale_s" in x for x in e)


def test_unknown_ring_is_actually_visible():
    """未知态必须**看得见**,否则它与「未开播」(隐藏)在用户眼里没有区别,
    三态设计的唯一理由当场作废。首版用 --line 描边,真 Chromium 实测在侧栏轨底上
    只有 **1.08:1**(WCAG 1.4.11 非文本门槛 3:1),等于画了个隐形的态。
    现用 --mute(实测 5.04:1 / 6.00:1)。逐色量测脚本:
    backend_async/scripts/frontend_rilive_probe.mjs(需 playwright,零依赖时本钉
    退化为源码断言 —— 它守的是"别再退回低对比度令牌")。"""
    import re
    css = re.sub(r"/\*.*?\*/", "", APP_CSS.read_text(encoding="utf-8"), flags=re.S)
    m = re.search(r"\.room-item \.ri-live\.is-unknown\{([^}]*)\}", css)
    assert m, "找不到 .ri-live.is-unknown 规则"
    body = m.group(1)
    assert "var(--mute)" in body, "未知态描边必须用已过对比度门槛的 --mute"
    assert "var(--line)" not in body, "--line 在轨底实测仅 1.08:1,不得用于状态位"
    assert "opacity" not in body, "opacity 会把刚挣来的对比度再打折"


# ══ 六、循环本体端到端(第三轮补:此前只驱动过 _livestatus_once,循环从未被执行过)══
_REDIS_URL = __import__("os").environ.get("STA_TEST_REDIS_URL",
                                          "redis://127.0.0.1:6379/15")


def _real_redis_ok() -> bool:
    try:
        import redis
        redis.from_url(_REDIS_URL).ping()
        return True
    except Exception:
        return False


@pytest.mark.skipif(not _real_redis_ok(),
                    reason="需要真 Redis(锁续租走 Lua EVAL,fakeredis 无 SCRIPT)")
@pytest.mark.asyncio
async def test_loop_runs_a_round_and_is_mutually_exclusive():
    """真 Redis 驱动**循环本体**:开关门控 → 抢锁 → 心跳 → 跑一轮 → 停心跳。
    并发第二个副本必须抢不到锁(跨副本互斥),锁到期后才轮到它。"""
    import asyncio as _a
    from app.redis_bus import RedisBus, K_LIVE_LOCK
    b = RedisBus(_REDIS_URL)
    await b.r.delete(K_LIVE_LOCK, "rooms:livestatus", "livestatus:last")
    seen = []

    async def _probe(rid):
        seen.append(rid)
        return 1
    w = _mini_worker(b, ["6001", "6002"], _probe)
    w._running = True
    w.s.livestatus.interval_s = 5          # 循环内 max(5, …) 的下限,测试跑得动
    task = _a.create_task(w._livestatus())
    await _a.sleep(7)                      # 够走完一次 sleep(5)+抢锁+一轮
    assert sorted(seen) == ["6001", "6002"], f"循环没跑成一轮:{seen}"
    assert await b.r.get(K_LIVE_LOCK), "轮次期间锁必须在手"
    last = await b.livestatus_last()
    assert last and last["curated"] == 2 and last["live"] == 2

    # 跨副本互斥:锁仍在手时,第二个副本抢不到
    assert await b.livestatus_try_lock(5) is None
    w._running = False
    task.cancel()
    # CancelledError 在 3.8+ 继承 BaseException —— suppress(Exception) 抓不到它
    # (生产侧 worker._livestatus 的 finally 里两者都列了,这里对齐)
    with __import__("contextlib").suppress(_a.CancelledError, Exception):
        await task
    await b.r.delete(K_LIVE_LOCK, "rooms:livestatus", "livestatus:last")
    await b.close()


@pytest.mark.skipif(not _real_redis_ok(), reason="需要真 Redis(Lua EVAL)")
@pytest.mark.asyncio
async def test_renew_lock_only_renews_its_own_token():
    """续租必须是 compare-and-expire:只续自己的锁,令牌不符一律 False ——
    否则两个副本会互相把对方的锁续下去,互斥形同虚设。"""
    from app.redis_bus import RedisBus, K_LIVE_LOCK
    b = RedisBus(_REDIS_URL)
    await b.r.delete(K_LIVE_LOCK)
    tok = await b.livestatus_try_lock(30)
    assert tok
    assert await b.livestatus_renew_lock(tok, 60) is True
    assert await b.r.ttl(K_LIVE_LOCK) > 30
    assert await b.livestatus_renew_lock("别人的令牌", 60) is False
    assert await b.livestatus_renew_lock("", 60) is False
    await b.r.delete(K_LIVE_LOCK)
    await b.close()


def test_state_is_exposed_to_assistive_tech_not_only_title():
    """状态必须**双写**:title 给鼠标,aria-label 给读屏。

    真 Chromium CDP 实测(backend_async/scripts/frontend_rilive_a11y.mjs)推翻了
    「去掉 aria-hidden 后 title 会进祖先按钮 computed name」这个想当然的判断 ——
    只挂 title 时按钮名是 `主播A № 321 开 12s ×`,**一个字都没有**;换成
    role="img"+aria-label 才变成 `… × 直播中`(未开播时元素 hidden,自动不计)。
    叠加既有事实「全站 title 在触屏一律不渲染」,只写 title = 对读屏用户与
    触屏用户同时失声,而这是个**状态位**不是装饰。"""
    src = APP_JS.read_text(encoding="utf-8")
    assert 'role="img" aria-label=""' in src, "模板须预留 aria 位(值逐拍写)"
    chip = _seg(src, "function railLiveChip", "\nfunction ")
    assert "aria: '直播中'" in chip and "aria: '直播状态未知'" in chip
    paint = _seg(src, "function railTickPaint", "\nasync function ")
    assert "setAttribute('aria-label', c.aria)" in paint


# ══ 七、视觉语言不撞车 + 同族排查(第四轮:两处「上报未改」项已改) ══════════════
def test_nudge_badge_does_not_impersonate_live_dot():
    """☰ 新手徽点原文「逐字节承接 .ri-live(7px brand 圆点 + pulse)」——那是在
    .ri-live 还是无意义装饰的前提下做的承接。5.0.6 起绿色脉冲圆点 =「主播在播」,
    承接即撞车。真 Chromium 实测:iPad 驾驶舱触屏下 #railOpen 为 display:grid,
    与名录**同屏**;而 data-nudge 的触发条件是「名录只有 1 房」= 每个新用户的默认
    状态 —— 新手第一屏会看到两颗一模一样的绿点,一颗意思是「在播」,一颗意思是
    「你还能加房」。复跑:backend_async/scripts/frontend_nudge_badge.mjs"""
    import re
    css = re.sub(r"/\*.*?\*/", "", APP_CSS.read_text(encoding="utf-8"), flags=re.S)
    m = re.search(r"body\[data-nudge\] #railOpen::after\{([^}]*)\}", css)
    assert m, "找不到新手徽点规则"
    body = m.group(1)
    assert "var(--brand)" not in body, "徽点不得再用 brand 绿 —— 那是「直播中」的专用色"
    assert "var(--gilt)" in body and "border-radius:50%" not in body, \
        "色相 + 形状双双区分(色觉障碍下靠形状仍分得开)"
    assert "pulse-gilt" in body, "扩散环须同步金调,不复用绿调关键帧"
    assert "@keyframes pulse-gilt" in css


def test_no_invisible_state_borders_left_in_the_row():
    """同族排查:名录同一行里**携带状态**的元素不得再用 --line 描边。
    真 Chromium 逐色实测 --line 在名录底上仅 1.08:1(WCAG 1.4.11 门槛 3:1)——
    对 .ri-tick.slow 尤其致命:.slow 排在 .hot/.next **之前**,底色被后者覆盖,
    那道虚线是「省流」与常态的**唯一**区别,1.08:1 等于该状态根本没被标注。
    改用 --mute 后实测 5.04:1(.lost 的朱砂 4.30:1 原样保留,按色相区分告警)。"""
    import re
    css = re.sub(r"/\*.*?\*/", "", APP_CSS.read_text(encoding="utf-8"), flags=re.S)
    for cls in (".ri-tick.slow", ".ri-tick.idle", ".ri-live.is-unknown"):
        m = re.search(re.escape(".room-item " + cls) + r"\{([^}]*)\}", css)
        assert m, f"找不到 {cls}"
        assert "var(--line)" not in m.group(1), \
            f"{cls} 是状态位,不得用 --line 描边(实测 1.08:1,画了等于没画)"


def test_slow_marker_survives_the_filled_states():
    """`.slow`(闲置省流)的虚线是它与常态的唯一区别,而 `.hot`/`.next` 排在它**之后**
    会把底色改掉 —— 描边颜色必须**按底色分两套**,否则最该看见的时候看不见。

    二修记录:首版只把 --line 换成 --mute 就以为修好了,真 alpha 合成后实测
    `hot slow` 的描边仍是 **1.17:1**(--mute 是给浅底调的,而 .hot 是朱砂实底);
    补 `.slow.hot` 近白描边后 4.39:1。而「出怪窗内的省流房」恰是这条组合态最常
    出现的时刻。复跑:backend_async/scripts/frontend_dot_language.mjs"""
    import re
    css = re.sub(r"/\*.*?\*/", "", APP_CSS.read_text(encoding="utf-8"), flags=re.S)
    assert re.search(r"\.room-item \.ri-tick\.slow\.hot\{[^}]*border-color", css), \
        "朱砂实底上的省流描边必须单独给色(--mute 在其上仅 1.17:1)"


def test_contrast_probe_composites_alpha():
    """量测脚本自身的钉:半透明底必须做**真 alpha 合成**再算对比度。
    上一轮的旧脚本把 rgba(0,0,0,.035) 当纯黑,把 .ri-tick.next 误报成 3.42:1
    「文字不达标」——真值 4.67:1,是**达标的**。错误的量测比不量测更坏:
    它会把人引去改一个本来没病的地方。"""
    src = (Path(__file__).resolve().parents[1] / "scripts"
           / "frontend_dot_language.mjs").read_text(encoding="utf-8")
    assert "const over = (f, bk)" in src and "solidBehind" in src
    assert "f.a + bk.r * (1 - f.a)" in src.replace("f.r * ", ""), "须是真正的 over 合成"


# ══ 八、第五轮复查补钉 ═══════════════════════════════════════════════════════
def test_lost_chip_text_uses_deep_seal():
    """「断」是全名录唯一的告警字,不该是看不清的那一个。真 alpha 合成实测
    --seal 在名录底(#e2ebe6)上仅 **4.30:1**,差 0.2 够不着 WCAG AA 正文 4.5
    (本字号 10.5px,不适用大字例外)。改用色板里现成的 --seal-deep 后 **5.65:1**。
    **不动全站 --seal 令牌**,只换这一处字色 —— 做法与 4.3.6 星币色
    #a8781f→#8a6114 同源;虚线仍留 --seal(边框门槛 3:1,4.30 已过),保留深字浅边的
    层次。复跑:backend_async/scripts/frontend_dot_language.mjs"""
    import re
    css = re.sub(r"/\*.*?\*/", "", APP_CSS.read_text(encoding="utf-8"), flags=re.S)
    m = re.search(r"\.room-item \.ri-tick\.lost\{([^}]*)\}", css)
    assert m, "找不到 .ri-tick.lost"
    body = m.group(1)
    assert "color:var(--seal-deep)" in body, "告警字色须用 --seal-deep(--seal 仅 4.30:1)"
    assert "dashed var(--seal)" in body, "虚线保留 --seal(3:1 门槛已过,维持深字浅边)"


@pytest.mark.asyncio
async def test_stats_do_not_count_rooms_already_dropped():
    """统计口径:已移出策展集的房必须同时从**本地快照**剔除,否则那一行统计是假的。

    首版只从 Redis 删(livestatus_drop_bulk),本地 snap 仍留着它们 ——
    live/offline 会把已经删掉的房算进去、超过 curated 总数,unknown 被 max(0,…)
    夹成 0,运维看到「策展 1 房 · 在播 3 · 未知 0」这种自相矛盾的行。"""
    b = _bus()
    now = int(time.time() * 1000)
    # 三房有观测,但当前策展集只剩一房 → 另两房应被剔除且不计入统计
    await b.livestatus_set_bulk([("9301", 1), ("9302", 1), ("9303", 1)], ts=now)

    async def _probe(rid):
        return 1
    w = _mini_worker(b, ["9301"], _probe)
    await w._livestatus_once(w.s.livestatus)
    last = await b.livestatus_last()
    assert last["curated"] == 1
    assert last["live"] == 1, f"已删房不得计入在播,实测 {last}"
    assert last["live"] + last["offline"] + last["unknown"] == last["curated"]
    assert set((await b.livestatus_map()).keys()) == {"9301"}


# ══ 九、第六轮:真栈实证的两条(此前只有假 sweep / 假 bus 覆盖) ═══════════════
def test_free_signal_branch_is_reachable_from_a_real_sweep():
    """「在册即在播」这条零成本分支的源码契约。

    真栈实证(2026-08-12,打真繁星):一轮真 sweep 取回 151 房,把其中一个**真在播
    且在册**的房登记为策展房后跑 reconcile —— 该房观测当场变成 (1, ts),**零探测
    请求**;紧接着的探测轮里 `probed=1`,被探的偏偏是频道房 2678075(它从不上榜)。
    统计 curated=2 / live=2 / offline=0 / unknown=0 / probeOk=1,恒等式
    live+offline+unknown == curated 成立。这正是两级判据设计的分工本身。
    此前该分支只被喂过**假 sweep 结果**的单测覆盖过。"""
    rec = _seg(DISC_SRC, "async def reconcile_discovered")
    assert "live_manual = [r for r in live if r in manual]" in rec
    assert "livestatus_set_bulk([(r, 1) for r in live_manual]" in rec
    # 开关关闭时一条 Redis 命令都不许多花
    assert 'getattr(_ls, "enabled", False)' in rec


def test_admin_console_can_render_the_new_section():
    """管理台「参数中心」按注册表渲染 —— 新板块必须真的出现在 public_schema()
    的板块序里,且每个字段带齐 UI 需要的元数据(label/type/default/section/hot)。
    真栈实测:13 个板块含「直播状态」,7 个字段全部 hot(即时热更)。"""
    from app.config_registry import public_schema
    sc = public_schema()
    assert "直播状态" in sc["sections"]
    keys = [k for k in sc["fields"] if k.startswith("livestatus.")]
    assert len(keys) == 7, keys
    for k in keys:
        f = sc["fields"][k]
        for need in ("label", "type", "default", "section"):
            assert need in f and f[need] not in (None, ""), f"{k} 缺 {need}"
        assert f["section"] == "直播状态"
