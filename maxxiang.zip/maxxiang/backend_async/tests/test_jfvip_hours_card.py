"""
test_jfvip_hours_card.py — 指定时长卡密与外部发卡 API(4.2.9)
================================================================================
本文件钉死五类不变量:

  A. **内联码语法**:round-trip、边界、拒绝面(bool / 浮点 / 超限 / 空串)。
  B. **命名空间两端保留**:配置档位无法占用内联语法;内联码不被配置遮蔽。
     —— 这是全套里最重要的一条:只做一端会留下「日后新增一个叫 @H720 的配置
     档位就静默改写所有已发出的 @H720 卡」的坑,而卡已经在用户手里。
  C. **外部发卡 API 的四道闸**:总开关/密钥体检、密钥比对、IP 白名单、限频。
     尤其钉死「密钥为空 ⇒ 端点整体关闭」——它与 sso_link_key_ok 的「未配置恒
     True」**语义相反**,是本轮唯一一条反直觉取向,最容易在后续维护里被"顺手
     统一"掉。
  D. **前后端契约**:admin.js 里的 @H 语法与上限必须与后端同值(两边各写一份
     解析,漂了就会把定制卡渲染成「该档位已不在配置表中」——那是一句假话)。
  E. **真库端到端**:发一张 @H720D720 → 兑换 → 两条时间线各进 720h、流水四个
     时间戳齐全、amount=0。本地 1:1 复刻库不可达时**整层 skip**(沿用本仓既有
     范式,不阻断主干)。

A–D 纯静态/纯内存,零外部依赖。
"""
from __future__ import annotations

import ast
import asyncio
import os
import re
import socket
import sys
from pathlib import Path

import pytest

from tests._srcscan import js_code, py_code

from app import jfvip, userauth
from app.settings import UserAuthCfg

APP = Path(__file__).resolve().parent.parent / "app"
ROOT = Path(__file__).resolve().parents[2]
ADMIN_JS = ROOT / "assets" / "admin.js"


# 5.3.0:管理面挂在配置的入口路径下(默认 /api/admin-xdd);整站 web.app 的用例取其实际前缀。
# 外部发卡接口 /api/admin/jfvip/cards/issue 是恒定地址,仍按字面量写。
from app import admin_auth as _admin_auth  # noqa: E402
_ADM = _admin_auth.api_prefix()


@pytest.fixture(autouse=True)
def _clean_cfg(monkeypatch):
    """每个用例一份干净配置 + 清空档位缓存。

    _plans_cache 是**模块级**的,按 raw 串命中。不清的话,前一个用例塞进去的
    档位表会在下一个用例里以缓存形式复活 —— 那类跨用例污染正是 conftest 顶部
    记载的同一类顺序依赖 bug。
    """
    monkeypatch.setattr(userauth.UA, "cfg",
                        UserAuthCfg(host="h", db="d", user="u", jf_vip_enabled=True),
                        raising=False)
    monkeypatch.setattr(userauth.UA, "redis", None, raising=False)
    jfvip._plans_cache["raw"] = None
    jfvip._plans_cache["val"] = []
    jfvip._mem_rate.clear()
    yield
    jfvip._plans_cache["raw"] = None
    jfvip._plans_cache["val"] = []
    jfvip._mem_rate.clear()


# ══════════════════════════════════════════════════════════════════════════════
# A. 内联码语法
# ══════════════════════════════════════════════════════════════════════════════
@pytest.mark.parametrize("jf,dd", [(1, 0), (72, 72), (720, 168), (2232, 0),
                                   (jfvip.INLINE_MAX_HOURS, jfvip.INLINE_MAX_HOURS)])
def test_inline_code_round_trips(jf, dd):
    """inline_code 与 parse_inline 必须互为逆 —— 编码/解码分家就会发出一批
    「卡面写 30 天、兑出来 3 天」的卡,且事后无法分辨哪批是错的。"""
    code = jfvip.inline_code(jf, dd)
    p = jfvip.parse_inline(code)
    assert p is not None, f"{code} 解析失败"
    assert (p["jfHours"], p["ddHours"]) == (jf, dd)
    assert p["code"] == code, "解析结果的 code 与输入不一致(归一化不幂等)"


def test_inline_code_omits_zero_dd_segment():
    """dd=0 时不写 D 段 —— 让人一眼看出「这张卡不送小叮当」,而不是去数 D0。"""
    assert jfvip.inline_code(720, 0) == "@H720"
    assert jfvip.inline_code(720, 720) == "@H720D720"


def test_inline_code_fits_plan_code_column():
    """★ 最长内联码必须装进 `plan_code VARCHAR(16)`。

    这条不是洁癖:gbk 表在非 STRICT 模式下**截断不报错**,`@H100000D100000`
    被截成 `@H100000D10000` 就是一张时长完全不同、且看起来完全正常的卡。
    调大 INLINE_MAX_HOURS 时本用例会当场告诉你不能再调了。
    """
    longest = jfvip.inline_code(jfvip.INLINE_MAX_HOURS, jfvip.INLINE_MAX_HOURS)
    assert len(longest) <= 16, f"最长内联码 {longest} 为 {len(longest)} 字符,超出 VARCHAR(16)"
    # 且必须仍能被解析回来(截断到 16 也解析得通的话这条断言就没意义了)
    assert jfvip.parse_inline(longest) is not None


@pytest.mark.parametrize("bad", [
    "", "  ", "d3", "m1", "@", "@H", "@H0", "@HD", "@H-1", "@Habc",
    "@h720",                       # 小写:不认(大小写混淆是卡号差错的老来源)
    "@H720D", "@H720X720", "H720", "@H720D720D720",
    "@H0D720",                     # jf=0:VIP 零时长的卡毫无意义
    f"@H{jfvip.INLINE_MAX_HOURS + 1}",
    f"@H720D{jfvip.INLINE_MAX_HOURS + 1}",
    "@H9999999",                   # 7 位:超出正则的 {1,6}
    None, 720, [], {},
])
def test_parse_inline_rejects(bad):
    assert jfvip.parse_inline(bad) is None, f"{bad!r} 不该被解析成合法内联档位"


def test_parse_inline_is_fail_closed_above_cap():
    """超限**拒绝解析**而不是截断到上限。

    截断会让用户拿到一张与卡面不符的卡;fail-closed 只是让他去找客服。
    上限必须在**解析侧**也钳一次 —— 库里可能已有一张手工改库塞进去的
    @H999999,生成侧的校验对它毫无约束力。
    """
    assert jfvip.parse_inline("@H999999") is None
    over = f"@H{jfvip.INLINE_MAX_HOURS + 1}"
    assert jfvip.is_inline_code(over), "形态上仍属内联命名空间(所以不会去查配置)"
    assert jfvip.parse_inline(over) is None, "但拒绝给出时长 ⇒ 兑换时 card_plan_gone"


def test_inline_name_matches_frontend_jvdur_buckets():
    """★ 人话名字的分档必须与前端 jvDur() **逐档**一致。

    这不是洁癖 —— 实测抓到过一次真实分歧:本函数初版漏了 8928h / 4464h 两个
    特例,于是同一张年卡在管理台卡密页显示「定制 1 年」、在开通流水里显示
    「定制 12 个月」。同一张卡两个说法,运维只会怀疑数据本身。而 8928h 恰恰是
    做年卡最可能填的数,不是够不着的边界。

    判据**不手抄前端的分档表**,而是从 admin.js 里把 jvDur 的分支实抠出来比对 ——
    手抄一份就等于又造了第三处真源,下次改前端时这里照样发现不了。
    """
    js = js_code(ADMIN_JS)
    seg = js[js.index("function jvDur(hours)"):]
    seg = seg[:seg.index("\n}") + 2]
    # 从 jvDur 里抠出「特例小时数 → 文案」与「整除因子 → 单位」
    specials = dict((int(h), t) for h, t in
                    re.findall(r"if\s*\(h\s*===\s*(\d+)\)\s*return\s*'([^']+)'", seg))
    assert specials, "没从 admin.js 的 jvDur 里抠到任何特例分档 —— 扫描式失效了"
    divisors = [(int(d), u) for d, u in
                # ⚠ `\}` 之后**不能**再写 \s* —— 那会把模板里的空格吃掉,重建出
                # 「定制 1个月」而真实前端是「定制 1 个月」,于是全表假红(实测踩过)。
                re.findall(r"if\s*\(h\s*%\s*(\d+)\s*===\s*0\)\s*return\s*`\$\{h\s*/\s*\d+\}([^`]+)`", seg)]
    assert divisors, "没从 admin.js 的 jvDur 里抠到整除分档"

    def _front(h: int) -> str:
        if h in specials:
            return f"定制 {specials[h]}"
        for d, unit in divisors:
            if h % d == 0:
                return f"定制 {h // d}{unit}"
        return f"定制 {h} 小时"

    probes = sorted(set(list(specials) + [d for d, _ in divisors]
                        + [1, 7, 72, 720, 744, 1488, 2232, 8760,
                           jfvip.INLINE_MAX_HOURS]))
    bad = [(h, jfvip._inline_name(h), _front(h))
           for h in probes if jfvip._inline_name(h) != _front(h)]
    assert not bad, (
        "后端 _inline_name 与前端 jvDur 分档不一致(小时, 后端, 前端): " + repr(bad))
    # 顺带钉住几条肉眼可读的样本,免得上面全靠扫描而扫描本身悄悄失效
    assert jfvip._inline_name(8928) == "定制 1 年"
    assert jfvip._inline_name(4464) == "定制 半年"
    assert jfvip._inline_name(744) == "定制 1 个月"
    assert jfvip._inline_name(720) == "定制 30 天"
    assert jfvip._inline_name(7) == "定制 7 小时"


# ── 整数净化(norm_hours / norm_count 共用内核) ──────────────────────────────
@pytest.mark.parametrize("raw", [True, False, 72.9, 72.0, "abc", "", "  ",
                                 None, [], {}, "7e2", "0x48"])
def test_norm_hours_rejects_junk(raw):
    """★ bool 与浮点必须先挡。

    True 是 int 的子类:`{"hours": true}` 会被裸 int() 收成 1 —— **静默发出一张
    1 小时的卡**是最坏的结果(调用方本意多半是别的东西,而卡已经发出去了)。
    `int(72.9)` 静默变 72 同理:JSON 里写 72.9 的人显然不想要 72。
    """
    assert jfvip.norm_hours(raw) is None, f"{raw!r} 不该被当成合法小时数"


def test_norm_hours_boundaries():
    assert jfvip.norm_hours(1) == 1
    assert jfvip.norm_hours(" 720 ") == 720               # 字符串数字照收(表单/JSON 都可能)
    assert jfvip.norm_hours(jfvip.INLINE_MAX_HOURS) == jfvip.INLINE_MAX_HOURS
    assert jfvip.norm_hours(jfvip.INLINE_MAX_HOURS + 1) is None
    assert jfvip.norm_hours(0) is None                    # 默认下界 1
    assert jfvip.norm_hours(0, allow_zero=True) == 0      # ddHours 允许 0
    assert jfvip.norm_hours(-1) is None
    assert jfvip.norm_hours(-1, allow_zero=True) is None


def test_norm_count_boundaries():
    """张数与发卡上限同值,且**越界拒绝而非截断** —— 与 ids_overflow 同一条理由:
    截断会让「请求 N 张、实发 M 张」这个差异消失在净化环节。"""
    assert jfvip.norm_count(1) == 1
    assert jfvip.norm_count(jfvip._MAX_CARDS_PER_BATCH) == jfvip._MAX_CARDS_PER_BATCH
    assert jfvip.norm_count(jfvip._MAX_CARDS_PER_BATCH + 1) is None
    assert jfvip.norm_count(0) is None
    assert jfvip.norm_count(True) is None


# ══════════════════════════════════════════════════════════════════════════════
# B. 命名空间两端保留 —— 本文件最要紧的一组
# ══════════════════════════════════════════════════════════════════════════════
def test_configured_plan_cannot_occupy_inline_namespace(capsys):
    """★ 配置档位**不能**占用内联语法,且剔除必须大声告警。

    只做「解析侧优先内联」而不做这一端的话,运维日后新增一个恰好叫 @H720 的
    配置档位,就会静默改写所有已发出的 @H720 卡的时长 —— 卡已经在用户手里,
    这种改写没有任何补救手段。
    静默丢档位同样不行:运维会看到前台少一张价格卡却无从知道为什么。
    """
    userauth.UA.cfg.jf_vip_plans = (
        '[{"code":"@H720","name":"冒名档位","price":1,"jfHours":1,"ddHours":0},'
        '{"code":"m1","name":"1 个月","price":88,"jfHours":744,"ddHours":744}]')
    codes = [p["code"] for p in jfvip.plans()]
    assert codes == ["m1"], f"内联语法的配置档位未被剔除:{codes}"
    assert "@H720" in capsys.readouterr().out, "剔除档位时没有任何告警输出"


def test_non_inline_at_prefixed_code_survives():
    """判据是「形态命中」而非「以 @ 开头」—— 命名空间保留得越窄,升级时误伤
    存量配置的面就越小。@vip 不是时长码,不该被剔除。"""
    userauth.UA.cfg.jf_vip_plans = (
        '[{"code":"@vip","name":"内部","price":1,"jfHours":24,"ddHours":0}]')
    assert [p["code"] for p in jfvip.plans()] == ["@vip"]
    assert jfvip.is_inline_code("@vip") is False


def test_resolve_plan_is_the_single_entry_and_prefers_inline():
    """resolve_plan 认两种档位;plan_of 只认配置档位(前台价格卡的数据源)。"""
    userauth.UA.cfg.jf_vip_plans = (
        '[{"code":"m1","name":"1 个月","price":88,"jfHours":744,"ddHours":744}]')
    assert jfvip.plan_of("m1")["jfHours"] == 744
    assert jfvip.plan_of("@H720") is None, "内联档位绝不该出现在配置档位查询里"
    assert jfvip.resolve_plan("m1")["jfHours"] == 744
    inl = jfvip.resolve_plan("@H720D168")
    assert (inl["jfHours"], inl["ddHours"], inl["price"]) == (720, 168, 0.0)
    assert inl["inline"] is True


def test_inline_plans_never_reach_the_public_price_list():
    """内联档位是运营侧的东西,不该出现在用户能选的商品列表里。
    (web.py 的 /api/vip/state 回的是 plans(),jfpay 下单查的也是 plan_of。)"""
    userauth.UA.cfg.jf_vip_plans = (
        '[{"code":"m1","name":"1 个月","price":88,"jfHours":744,"ddHours":744}]')
    assert all(not p.get("inline") for p in jfvip.plans())
    assert all(not jfvip.is_inline_code(p["code"]) for p in jfvip.plans())


def test_inline_card_amount_is_zero_never_caller_supplied():
    """★ 定制卡 amount 恒 0,且代码里没有任何「从入参取金额」的通路。

    这与 jfpay 的头号不变量「金额单一真源:绝不回退到用户请求金额,回退即凭空
    入账漏洞」是同一条,只是换了个入口。amount 是经营看板的数据源,外部 API
    能写它就等于能往看板里注水。
    """
    assert jfvip.parse_inline("@H720D720")["price"] == 0.0
    src = py_code(APP / "admin_api.py")
    seg = src[src.index("async def _issue_cards"):]
    seg = seg[:seg.index("\n@router") if "\n@router" in seg else len(seg)]
    for bad in ('body.get("amount"', 'body.get("price"', "body['amount']", "body['price']"):
        assert bad not in seg, f"外部发卡入参解析里出现了金额字段 {bad} —— 凭空入账通路"


def test_grant_tx_resolves_via_resolve_plan():
    """兑换路径必须走 resolve_plan 而不是 plan_of —— 走后者的话内联卡一律
    card_plan_gone(用户拿着买来的卡兑不了),而这条错误在静态检查里看不出来。"""
    src = py_code(APP / "jfvip.py")
    tree = ast.parse(src)
    fn = next((n for n in ast.walk(tree)
               if isinstance(n, ast.AsyncFunctionDef) and n.name == "_grant_tx"), None)
    assert fn is not None
    body = ast.get_source_segment(src, fn) or ""
    assert "resolve_plan(" in body, "_grant_tx 未经 resolve_plan 解析时长"
    assert "plan_of(" not in body, "_grant_tx 仍在直接调 plan_of —— 内联卡会兑不了"


def test_grant_tx_gains_no_round_trip_from_inline():
    """★ 内联解析必须是**纯 CPU**:行锁持有期内不许因此多一次库往返。

    这是「不加列、不建表」那条论证的兑现处 —— 建新表的方案会在这里多一次查询,
    而 _grant_tx 持有的是 tb_user 的行锁,公网库上每多一次往返都是几十毫秒的
    锁扩张。

    数字 13 不是拍的:对 4.2.8 原始文件与本轮改后文件各跑一次同样的 AST 计数,
    两边都是 13 —— 本轮**逐次相等**。写成 == 而不是 <=,是因为这里要钉的不是
    「别太多」而是「一次都没多」;将来谁在事务里加查询,都得先在这里说明理由。
    """
    src = py_code(APP / "jfvip.py")
    tree = ast.parse(src)
    fn = next(n for n in ast.walk(tree)
              if isinstance(n, ast.AsyncFunctionDef) and n.name == "_grant_tx")
    body = ast.get_source_segment(src, fn) or ""
    assert body.count("await cur.execute") == 13, (
        f"_grant_tx 有 {body.count('await cur.execute')} 个库往返点(4.2.8 基线为 13)"
        f" —— 内联时长解析应当是纯 CPU,不该引入任何新查询")
    assert "userauth._q" not in body, "_grant_tx 体内不该出现事务外的查询助手"


# ══════════════════════════════════════════════════════════════════════════════
# C. 外部发卡 API 的四道闸
# ══════════════════════════════════════════════════════════════════════════════
_GOOD_KEY = "k" * 64


def test_api_disabled_by_default():
    """「不配置即不存在」:VIP 体系开着,发卡 API 仍默认关。"""
    assert jfvip.enabled() is True
    st = jfvip.card_api_status()
    assert st["enabled"] is False and st["reason"] == "api_off"


def test_empty_key_closes_the_endpoint_entirely():
    """★★ 本轮唯一一条**反直觉**取向,最容易在后续维护里被"顺手统一"掉。

    userauth.sso_link_key_ok 的口径是「未配置密钥 → 恒 True」,论证是:不配密钥
    时该端点的能力**不超过**已经公开的 /api/auth/login(5.2.0 起共用同一套计数与
    加码判定),故不构成新增敞口。

    本端点**没有这条退路** —— 它是纯粹的价值创造:调一次就凭空多出 N 张可兑换
    的 VIP 时长,没有任何已公开端点与之等价。故密钥为空 ⇒ 整体关闭,而不是放行。
    """
    userauth.UA.cfg.jf_card_api_enabled = True
    userauth.UA.cfg.jf_card_api_key = ""
    st = jfvip.card_api_status()
    assert st["enabled"] is False and st["reason"] == "no_key"
    # 闸本身也必须自身闭合,不能指望"上面那个人记得先判一下"
    assert jfvip.card_api_key_ok("Bearer ") is False
    assert jfvip.card_api_key_ok("") is False


def test_short_key_is_rejected_as_weak():
    """短密钥可离线爆破,而这里发出的每张卡都是真金白银。"""
    userauth.UA.cfg.jf_card_api_enabled = True
    userauth.UA.cfg.jf_card_api_key = "short"
    st = jfvip.card_api_status()
    assert st["enabled"] is False and st["reason"] == "weak_key"
    assert jfvip.card_api_key_ok("Bearer short") is False, "弱密钥即便对上也不放行"


def test_key_gate_accepts_only_exact_match():
    userauth.UA.cfg.jf_card_api_enabled = True
    userauth.UA.cfg.jf_card_api_key = _GOOD_KEY
    assert jfvip.card_api_status()["enabled"] is True
    assert jfvip.card_api_key_ok(f"Bearer {_GOOD_KEY}") is True
    assert jfvip.card_api_key_ok(f"bearer {_GOOD_KEY}") is True   # 方案名大小写不敏感
    assert jfvip.card_api_key_ok(_GOOD_KEY) is True               # 裸密钥也收(容错)
    assert jfvip.card_api_key_ok(f"Bearer {_GOOD_KEY}x") is False
    assert jfvip.card_api_key_ok(f"Bearer {_GOOD_KEY[:-1]}") is False
    assert jfvip.card_api_key_ok("Bearer ") is False


def test_key_gate_uses_constant_time_compare():
    """短路比较会泄漏"前几个字符对了"这条时序侧信道。

    ★ 本用例初版把 `got[:7].lower() == "bearer "`(比对**方案名**,与密钥无关)
      误判成短路比较 —— 假阳性。判据必须精确到「拿密钥本身做了 ==」,
      而不是"函数里出现了 =="。这与 _srcscan 顶部记载的是同一类教训。
    """
    src = py_code(APP / "jfvip.py")
    seg = src[src.index("def card_api_key_ok"):]
    seg = seg[:seg.index("\ndef ")]
    assert "hmac.compare_digest" in seg, "密钥比对未用常数时间比较"
    for bad in ("got == want", "want == got", "got != want", "want != got",
                'want == str', "got.strip() == want"):
        assert bad not in seg, f"密钥比对出现短路写法 {bad!r} —— 时序侧信道"
    # compare_digest 的两个实参必须就是 got/want,而不是拿它们的摘要/切片去比
    m = re.search(r"hmac\.compare_digest\((.*?)\)\s*$", seg.replace("\n", " "))
    assert m and "got" in m.group(1) and "want" in m.group(1), \
        "compare_digest 的实参不是密钥本身"


@pytest.mark.parametrize("allow,ip,want", [
    ("", "203.0.113.7", True),                       # 未配 = 不限
    ("203.0.113.7/32", "203.0.113.7", True),
    ("203.0.113.7/32", "203.0.113.8", False),
    ("198.51.100.0/24", "198.51.100.42", True),
    ("198.51.100.0/24,203.0.113.7/32", "203.0.113.7", True),
    ("203.0.113.7/32", "", False),                   # 取不到 IP:不放行
    ("203.0.113.7/32", "not-an-ip", False),
    ("垃圾,更多垃圾", "203.0.113.7", False),           # ★ 配错 = fail-closed
    ("垃圾,203.0.113.7/32", "203.0.113.7", True),     # 单条写错跳过,其余仍生效
])
def test_ip_allowlist(allow, ip, want):
    """★ 配了却一条合法 CIDR 都没有时 **fail-closed**。

    白名单是安全设施,配错的正确表现是把自己关在门外,而不是悄悄敞开 ——
    后者会让运维以为白名单在生效。
    """
    userauth.UA.cfg.jf_card_api_ip_allow = allow
    assert jfvip.card_api_ip_ok(ip) is want


def test_rate_limit_is_keyed_globally_not_per_ip():
    """★ 限频按密钥全局分桶,**不按 IP**。

    本端点是服务端对服务端,正常调用方就那么一两个出口 IP;按 IP 分桶等于按
    调用方分桶。而密钥泄漏后攻击者从任意 IP 打过来,按 IP 分桶给他的是**每个 IP
    一份配额** —— 等于没限。
    """
    assert "{ip}" not in jfvip.K_CARD_API_RATE, "限频键含 IP 占位 —— 泄漏后等于没限"
    userauth.UA.cfg.jf_card_api_rate_hourly = 3

    async def _run():
        return [await jfvip.card_api_rate_ok() for _ in range(5)]

    assert asyncio.run(_run()) == [True, True, True, False, False]


def test_rate_limit_zero_means_unlimited():
    userauth.UA.cfg.jf_card_api_rate_hourly = 0

    async def _run():
        return all([await jfvip.card_api_rate_ok() for _ in range(50)])

    assert asyncio.run(_run()) is True


def test_badkey_counts_failures_only_and_locks():
    """只对**失败**计数:正常调用方永远不会发错密钥,故对它零影响;
    对爆破者却是硬闸,同时压掉「每发一次错误密钥写一行日志」的日志放大。"""
    async def _run():
        ip = "203.0.113.9"
        assert await jfvip.card_api_badkey(ip, bump=False) is None
        for _ in range(jfvip._CARD_API_BADKEY_10M - 1):
            assert await jfvip.card_api_badkey(ip, bump=True) is None
        lock = await jfvip.card_api_badkey(ip, bump=True)         # 第 20 发触限
        assert lock and lock > 0, "达到上限却没有返回锁定秒数"
        assert await jfvip.card_api_badkey(ip, bump=False), "只读探测应报告仍在锁定期"
        # 另一个 IP 不受牵连(按 IP 分桶,不是全局)
        assert await jfvip.card_api_badkey("203.0.113.10", bump=False) is None

    asyncio.run(_run())


def test_issue_endpoint_is_registered_and_not_behind_session_guard():
    """端点必须挂在 /api/admin/ 前缀下(该前缀已在 userauth.guard 的豁免表里),
    且**不得**走 _guard/_guard_write —— 那两个要求管理台会话 + CSRF 双提交,
    机器调用方没有浏览器也没有 cookie。"""
    src = py_code(APP / "admin_api.py")
    i = src.index('@router.post("/jfvip/cards/issue")')
    seg = src[i:src.index("@router.post(\"/jfvip/cards/disable\")")]
    assert "_guard_write(request)" not in seg, "外部 API 误接了管理台会话闸"
    assert "card_api_key_ok" in seg, "外部 API 没有密钥闸"
    assert "card_api_rate_ok" in seg, "外部 API 没有限频"
    assert "card_api_badkey" in seg, "外部 API 没有密钥错误计数"
    assert "card_api_ip_ok" in seg, "外部 API 没有专属 IP 白名单"


def test_issue_endpoint_still_respects_admin_ip_allowlist():
    """★ 运维设了 STA_ADMIN_IP_ALLOW 就有权认为「整个 /api/admin/* 只对内网
    开放」。绝不在他背后把这个前提捅破 —— 被它挡下时回**专属错误码**并点名旋钮,
    而不是让集成方对着一个笼统的 403 猜半天。"""
    src = py_code(APP / "admin_api.py")
    i = src.index('@router.post("/jfvip/cards/issue")')
    seg = src[i:src.index("@router.post(\"/jfvip/cards/disable\")")]
    assert "admin_auth.ip_allowed" in seg, "外部 API 绕开了管理台 IP 白名单"
    assert "ip_forbidden_admin" in seg, "被管理台白名单挡下时没有专属错误码"


def test_issue_endpoint_does_not_write_card_numbers_to_audit():
    """★ 与 cards_purge 的墓碑**刻意相反**:那边是删除,卡号删完就没了;
    这边卡号还在 guantai_jf_card 里躺着,复制 500 个可兑换卡号进另一个库
    纯属白白多一份可被拖走的资产。"""
    src = py_code(APP / "admin_api.py")
    i = src.index('@router.post("/jfvip/cards/issue")')
    seg = src[i:src.index("@router.post(\"/jfvip/cards/disable\")")]
    j = seg.index("audit_add")
    audit_call = seg[j:j + 700]
    assert '"cards"' not in audit_call and "out[\"cards\"]" not in audit_call, \
        "外部发卡审计里出现了卡号 —— 白白扩大暴露面"
    assert '"batch"' in audit_call and '"count"' in audit_call, \
        "审计缺少批次/张数 —— 事后无从还原「谁发了多少」"


def test_plan_and_hours_are_mutually_exclusive():
    """两个都给时**显式拒绝**,绝不替他挑一个。发卡不可撤销,
    「你以为发的是 m1、实际发的是 @H24」没有任何补救手段。"""
    src = py_code(APP / "admin_api.py")
    seg = src[src.index("async def _issue_cards"):]
    assert "both_plan_and_hours" in seg
    assert "missing_plan_or_hours" in seg


def test_both_entry_points_share_one_param_parser():
    """管理台端点与外部 API 端点必须共用 _issue_cards —— 两个入口发出来的是
    **同一张表里同样可兑换的卡**,判据分家等于同一件事有两套规则。"""
    src = py_code(APP / "admin_api.py")
    assert src.count("await _issue_cards(") == 2, \
        "发卡参数解析不是被两个入口共用(或有第三个入口没接上)"


# ══════════════════════════════════════════════════════════════════════════════
# D. 前后端契约
# ══════════════════════════════════════════════════════════════════════════════
def test_frontend_inline_syntax_matches_backend():
    """★ admin.js 里有第二份内联码解析(前端要把 @H720D720 渲染成人话)。
    两边漂了的后果很具体:管理台会把每一张定制卡显示成
    「@H720D720(该档位已不在配置表中)」—— 那是一句**假话**,档位没丢,
    是它压根就不该在配置表里。谎报比不报危险。"""
    js = js_code(ADMIN_JS)
    m = re.search(r"const JV_INLINE_MAX_HOURS\s*=\s*(\d+)\s*;", js)
    assert m, "admin.js 里找不到 const JV_INLINE_MAX_HOURS = <数字>;"
    assert int(m.group(1)) == jfvip.INLINE_MAX_HOURS, (
        f"前端上限 {m.group(1)} ≠ 后端 INLINE_MAX_HOURS {jfvip.INLINE_MAX_HOURS}")
    m2 = re.search(r"const JV_INLINE_RE\s*=\s*/(.+?)/;", js)
    assert m2, "admin.js 里找不到 const JV_INLINE_RE = /…/;"
    # 后端正则去掉 Python 的转义差异后应逐字符相同
    assert m2.group(1) == jfvip._INLINE_RE.pattern, (
        f"前后端内联码正则不一致:\n  前端 {m2.group(1)}\n  后端 {jfvip._INLINE_RE.pattern}")


def test_frontend_exposes_hours_mode_and_custom_filter():
    """面板与筛选两处都得有 —— 只做发卡不做筛选的话,定制卡发得出去却
    在档位下拉里一个选项都没有(下拉数据源是 plans(),内联档位刻意不在其中),
    与本项目为 orphan 第四态写下的「不可见的数据黑洞」是同一类问题。"""
    js = js_code(ADMIN_JS)
    assert "__hours__" in js, "发卡面板没有「指定时长」模式"
    assert "jvGenHours" in js and "jvGenDdSame" in js, "缺少小时数输入或赠送勾选"
    assert "jvGenCode" in js, "没有实时展示最终落库的档位码"
    assert re.search(r"value=\"@\"", js), "档位筛选下拉缺少「定制时长(全部)」选项"


def test_frontend_audit_dict_covers_issue_action():
    """审计筛选下拉由 Object.keys(AUDIT_ACT) 生成 —— 没登记就**无法筛选**,
    而「这批卡是人在后台点的还是发卡平台调的」是事后追查的第一个问题。"""
    js = js_code(ADMIN_JS)
    seg = js[js.index("const AUDIT_ACT = {"):js.index("const ACTIONS =")]
    assert "jfvip_cards_issue" in seg, "审计字典未登记 jfvip_cards_issue"


def test_audit_dict_covers_audit_add_form_too():
    """★ 补强既有守卫的盲区:它只扫 `_audit(_actor(payload), "…")` 这一种写法,
    而 cards_purge 与 cards_issue 走的是 `_ST.db.audit_add(…, "…", …)` —— 后者
    完全在扫描面之外。本用例把两种写法一起收进来,让这类漏项彻底不可能发生。"""
    api = py_code(APP / "admin_api.py")
    back = set(re.findall(r'audit_add\(\s*now_ms\(\),\s*[\w()\[\]"\'@. ]+?,\s*"([a-z_]+)"',
                          api))
    assert back, "没扫到任何 audit_add 形式的审计动作 —— 扫描式失效了"
    js = js_code(ADMIN_JS)
    seg = js[js.index("const AUDIT_ACT = {"):js.index("const ACTIONS =")]
    front = set(re.findall(r"([a-z_]+):\s*'", seg))
    missing = sorted(back - front)
    assert not missing, f"审计字典缺失(audit_add 写法)动作 {missing}"


def test_docs_and_env_example_document_the_api():
    """文档撒谎和代码有 bug 一样有害(项目原话)。"""
    doc = (ROOT / "JFVIP-SYSTEM.md").read_text(encoding="utf-8")
    env = (APP.parent / "deploy" / ".env.example").read_text(encoding="utf-8")
    for token in ("/api/admin/jfvip/cards/issue", "@H", "STA_JF_CARD_API_KEY"):
        assert token in doc, f"JFVIP-SYSTEM.md 未记载 {token}"
        assert token in env or token.startswith("@"), f".env.example 未记载 {token}"
    # 那条反直觉的取向必须写进文档,否则后人只会看到"和 sso_link 不一致"
    assert "留空 = 端点整体 503" in doc or "留空 = 端点整体 503" in doc.replace(" ", ""), \
        "文档未说明「密钥为空 = 端点关闭」这条与 sso_link 相反的取向"


# ══════════════════════════════════════════════════════════════════════════════
# E. 真库端到端(本地 1:1 复刻库不可达时整层 skip)
# ══════════════════════════════════════════════════════════════════════════════
_HOST = os.environ.get("STA_TEST_USERDB_HOST", "127.0.0.1")
_PORT = int(os.environ.get("STA_TEST_USERDB_PORT", "3307"))
_USER = os.environ.get("STA_TEST_USERDB_USER", "root")
_PASS = os.environ.get("STA_TEST_USERDB_PASSWORD", "")
_DB = os.environ.get("STA_TEST_USERDB_NAME", "fx_jfhours_test")


def _reachable() -> bool:
    try:
        with socket.create_connection((_HOST, _PORT), timeout=0.6):
            return True
    except OSError:
        return False


needs_db = pytest.mark.skipif(
    not _reachable(),
    reason=f"需要本地用户库 {_HOST}:{_PORT}(MariaDB/MySQL 1:1 复刻)")

_BASE_DDL = [
    f"CREATE DATABASE IF NOT EXISTS `{_DB}` DEFAULT CHARSET=gbk",
    """CREATE TABLE IF NOT EXISTS tb_user (
         id BIGINT NOT NULL AUTO_INCREMENT,
         user_name VARCHAR(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL,
         pass_word VARCHAR(50) NOT NULL,
         email_account VARCHAR(320) NOT NULL DEFAULT '',
         email_bind_time BIGINT NOT NULL DEFAULT 0,
         register_time DATETIME NOT NULL,
         due_time DATETIME NOT NULL,
         is_off VARCHAR(1) NOT NULL DEFAULT '0',
         PRIMARY KEY(id), UNIQUE KEY uk_name (user_name)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk""",
]


def _db_cfg() -> UserAuthCfg:
    return UserAuthCfg(host=_HOST, port=_PORT, db=_DB, user=_USER, password=_PASS,
                       charset="gbk", jf_vip_enabled=True, cache_ttl_s=0.0)


async def _prepare():
    """建库建表。guantai_jf_* 四张直接取自 userauth._SCHEMA —— 单一真源:
    测试跑的就是生产会跑的那份 DDL,不存在手抄漂移。"""
    import aiomysql
    conn = await aiomysql.connect(host=_HOST, port=_PORT, user=_USER,
                                  password=_PASS, charset="gbk", autocommit=True)
    async with conn.cursor() as cur:
        await cur.execute(_BASE_DDL[0])
        await cur.execute(f"USE `{_DB}`")
        await cur.execute(_BASE_DDL[1])
    conn.close()
    userauth.UA.cfg = _db_cfg()
    userauth.UA.pool = None
    userauth.UA.schema_ok = False
    # schema_lock 由 userauth.init() 建;这里不跑 init(不需要 kick 订阅与清扫任务),
    # 故手动补一把 —— 与 tests/test_jfvip_db.py::_prepare 同款姿势。
    userauth.UA.schema_lock = asyncio.Lock()
    assert await userauth._ensure_schema(), "guantai_* 建表失败(DDL 无法执行)"
    # 档位缓存按 raw 串命中,而 _db_cfg() 换了一份 cfg 对象 —— 不清的话上一个
    # 用例塞的档位表会以缓存形式复活。
    jfvip._plans_cache["raw"] = None


async def _mk_user(name: str, due_days: int) -> int:
    await userauth._q(f"DELETE FROM guantai_jf_vip WHERE user_id IN "
                      f"(SELECT id FROM tb_user WHERE user_name=%s)", (name,))
    await userauth._q("DELETE FROM tb_user WHERE user_name=%s", (name,))
    await userauth._q(
        "INSERT INTO tb_user (user_name, pass_word, register_time, due_time) "
        "VALUES (%s, 'x', NOW(), DATE_ADD(NOW(), INTERVAL %s DAY))", (name, due_days))
    row = await userauth._q("SELECT id FROM tb_user WHERE user_name=%s", (name,),
                            fetch="one")
    return int(row["id"])


@needs_db
def test_realdb_inline_card_end_to_end():
    """★ 全链路实测:发一张 @H720D720 → 兑换 → 两条时间线各进 720 小时。

    这是「不加列」方案的最终验收 —— 前面所有静态断言都证明不了 MySQL 真的会
    按预期把这张卡兑出 720 小时。
    """
    async def _run():
        try:
            await _prepare()
            uid = await _mk_user("定制卡用户", 10)

            err, out = await jfvip.gen_cards_hours(3, 720, 720, "BHOURS", "端到端",
                                                   "cardapi@test")
            assert err == "", f"发卡失败:{err} {out}"
            assert out["count"] == 3 and out["plan"] == "@H720D720"
            assert out["jfHours"] == 720 and out["ddHours"] == 720
            assert out["inline"] is True and out["planName"] == "定制 30 天"
            card = out["cards"][0]

            # 卡真的落进了库,且 plan_code 完整没被截断
            row = await userauth._q(
                "SELECT plan_code, batch, created_by FROM guantai_jf_card WHERE card=%s",
                (card,), fetch="one")
            assert row["plan_code"] == "@H720D720", f"档位码被截断/篡改:{row['plan_code']!r}"
            assert row["batch"] == "BHOURS" and row["created_by"] == "cardapi@test"

            before = await userauth._q(
                "SELECT due_time, DATE_ADD(due_time, INTERVAL 720 HOUR) AS want "
                "FROM tb_user WHERE id=%s", (uid,), fetch="one")

            err, res = await jfvip.grant_by_card(uid, "定制卡用户", card)
            assert err == "", f"兑换失败:{err}"
            assert res["jfHours"] == 720 and res["ddHours"] == 720
            assert res["planCode"] == "@H720D720"

            # ① 九法VIP:从无到有 ⇒ NOW()+720h(库钟)
            v = await userauth._q(
                "SELECT vip_until, total_hours, "
                "  ABS(TIMESTAMPDIFF(SECOND, vip_until, DATE_ADD(NOW(), INTERVAL 720 HOUR))) AS drift "
                "FROM guantai_jf_vip WHERE user_id=%s", (uid,), fetch="one")
            assert int(v["total_hours"]) == 720
            assert int(v["drift"]) <= 5, f"VIP 到期与 NOW()+720h 偏差 {v['drift']}s"

            # ② 小叮当:未过期 ⇒ 从原到期点顺延(不亏时长)
            u = await userauth._q(
                "SELECT due_time, ABS(TIMESTAMPDIFF(SECOND, due_time, %s)) AS drift "
                "FROM tb_user WHERE id=%s", (before["want"], uid), fetch="one")
            assert int(u["drift"]) <= 5, (
                f"小叮当续期口径不符:原 {before['due_time']} 期望 {before['want']} "
                f"实得 {u['due_time']}")

            # ③ 流水:四个时间戳齐全、amount 恒 0、ref=卡号
            g = await userauth._q(
                "SELECT * FROM guantai_jf_grant_log WHERE user_id=%s AND source='card' "
                "ORDER BY id DESC LIMIT 1", (uid,), fetch="one")
            assert g["plan_code"] == "@H720D720" and g["ref"] == card
            assert float(g["amount"]) == 0.0, "定制卡不该往经营看板注入金额"
            assert int(g["jf_hours"]) == 720 and int(g["dd_hours"]) == 720
            assert g["vip_before"] is None and g["vip_after"] is not None
            assert g["due_before"] is not None and g["due_after"] is not None

            # ④ 幂等:同一张卡再兑一次必须失败,且不产生第二笔时长
            err2, _ = await jfvip.grant_by_card(uid, "定制卡用户", card)
            assert err2 == "card_used", f"重复兑换未被拒:{err2!r}"
            v2 = await userauth._q("SELECT total_hours FROM guantai_jf_vip WHERE user_id=%s",
                                   (uid,), fetch="one")
            assert int(v2["total_hours"]) == 720, "重复兑换加了第二笔时长"
        finally:
            await userauth.close()

    asyncio.run(_run())


@needs_db
def test_realdb_no_dd_card_leaves_tb_user_untouched():
    """★ ddHours=0 的卡**绝不能碰 tb_user** —— 那是全项目唯一一条对该表的写,
    默认不赠送这条取向必须在真库上得到证实,而不是只在注释里。"""
    async def _run():
        try:
            await _prepare()
            uid = await _mk_user("不赠小叮当", 10)
            err, out = await jfvip.gen_cards_hours(1, 168, 0, "BNODD", "", "t")
            assert err == "" and out["plan"] == "@H168"
            due0 = (await userauth._q("SELECT due_time FROM tb_user WHERE id=%s", (uid,),
                                      fetch="one"))["due_time"]
            err, res = await jfvip.grant_by_card(uid, "不赠小叮当", out["cards"][0])
            assert err == "" and res["ddHours"] == 0
            due1 = (await userauth._q("SELECT due_time FROM tb_user WHERE id=%s", (uid,),
                                      fetch="one"))["due_time"]
            assert due0 == due1, f"ddHours=0 却动了 tb_user.due_time:{due0} → {due1}"
            v = await userauth._q("SELECT total_hours FROM guantai_jf_vip WHERE user_id=%s",
                                  (uid,), fetch="one")
            assert int(v["total_hours"]) == 168, "VIP 时长没进账"
        finally:
            await userauth.close()

    asyncio.run(_run())


@needs_db
def test_realdb_malformed_inline_card_is_fail_closed():
    """手工改库塞进一张超限的 @H999999 卡 —— 必须 fail-closed 拒兑,
    而不是截断到上限发出去。这是「上限在解析侧也钳一次」的真库验收。"""
    async def _run():
        try:
            await _prepare()
            uid = await _mk_user("畸形卡", 10)
            bad = "TLZZZZZZ999999"
            await userauth._q("DELETE FROM guantai_jf_card WHERE card=%s", (bad,))
            await userauth._q(
                "INSERT INTO guantai_jf_card (card, plan_code, batch, note, created_by, "
                "created_at) VALUES (%s,'@H999999','BBAD','手工改库','t',NOW())", (bad,))
            err, _ = await jfvip.grant_by_card(uid, "畸形卡", bad)
            assert err == "card_plan_gone", f"畸形内联码未被 fail-closed:{err!r}"
            v = await userauth._q("SELECT vip_until FROM guantai_jf_vip WHERE user_id=%s",
                                  (uid,), fetch="one")
            assert v is None, "拒兑却仍然写了 VIP 行"
        finally:
            await userauth.close()

    asyncio.run(_run())


@needs_db
def test_realdb_custom_cards_are_filterable():
    """定制卡必须筛得出来 —— 发得出去却查不到是「不可见的数据黑洞」。"""
    async def _run():
        try:
            await _prepare()
            await userauth._q("DELETE FROM guantai_jf_card WHERE batch IN ('BF1','BF2')")
            userauth.UA.cfg.jf_vip_plans = (
                '[{"code":"m1","name":"1 个月","price":88,"jfHours":744,"ddHours":744}]')
            jfvip._plans_cache["raw"] = None
            await jfvip.gen_cards_hours(4, 24, 0, "BF1", "", "t")
            await jfvip.gen_cards(2, "m1", "BF2", "", "t")

            allc = await jfvip.cards_page(1, 100, batch="", plan_code=jfvip.INLINE_PREFIX)
            got = {i["card"] for i in allc["items"]}
            assert allc["total"] >= 4
            assert all(i["plan"].startswith("@") for i in allc["items"]), \
                "'@' 筛选漏进了非定制卡"
            m1 = await jfvip.cards_page(1, 100, plan_code="m1")
            assert m1["total"] == 2
            assert not ({i["card"] for i in m1["items"]} & got), "两类卡互相串了"
        finally:
            await userauth.close()

    asyncio.run(_run())


# ══════════════════════════════════════════════════════════════════════════════
# F. 真实 ASGI 端到端 —— 打一次真的 HTTP,验证"接线"
# ------------------------------------------------------------------------------
# 谱系同 test_jfvip_asgi.py:端点写对了但闸没接、闸接了但顺序不对、中间件会不会
# 把机器调用当成"未登录"挡掉 —— 这些只有打真实 HTTP 才看得出来。
# 这里同时是**唯一**一处验证 /api/admin/ 前缀确实让本端点免于用户会话闸的地方。
# ══════════════════════════════════════════════════════════════════════════════
import httpx  # noqa: E402


@pytest.fixture
def api_wired(monkeypatch):
    """启用 VIP + 外部发卡 API,把落库替换成内存桩(本节只关心闸与接线)。"""
    from app import admin_api
    from app import web

    cfg = UserAuthCfg(host="h", port=3306, db="d", user="u", password="p",
                      charset="gbk", jf_vip_enabled=True, cache_ttl_s=0.0,
                      jf_card_api_enabled=True, jf_card_api_key=_GOOD_KEY,
                      jf_card_api_rate_hourly=0)
    monkeypatch.setattr(userauth.UA, "cfg", cfg, raising=False)
    monkeypatch.setattr(userauth.UA, "pool", object(), raising=False)
    monkeypatch.setattr(userauth.UA, "redis", None, raising=False)
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "pw-for-tests")
    monkeypatch.delenv("STA_ADMIN_IP_ALLOW", raising=False)
    jfvip._mem_rate.clear()

    made: list = []

    async def _fake_code(count, plan_code, batch, note, operator):
        plan = jfvip.resolve_plan(plan_code)
        if plan is None:
            return "bad_plan", {}
        cards = [f"TLAAAAAA{i:06d}" for i in range(count)]
        made.append({"plan": plan_code, "count": count, "operator": operator,
                     "batch": batch})
        return "", {"cards": cards, "batch": batch or "BAUTO", "plan": plan["code"],
                    "planName": plan["name"], "jfHours": int(plan["jfHours"]),
                    "ddHours": int(plan["ddHours"]),
                    "inline": bool(plan.get("inline")), "count": len(cards)}

    monkeypatch.setattr(jfvip, "_gen_cards_code", _fake_code)

    class _AuditDB:
        rows: list = []

        async def audit_add(self, ts, actor, action, detail, rev):
            self.rows.append((actor, action, detail))

    adb = _AuditDB()
    adb.rows = []
    monkeypatch.setattr(admin_api, "_ST", type("S", (), {"db": adb})(), raising=False)
    yield {"made": made, "audit": adb, "app": web.app}


def _api_client(app):
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=app),
                             base_url="http://t")


@pytest.mark.asyncio
async def test_asgi_issue_happy_path(api_wired):
    """★ 一次真的 HTTP:外部机器凭 API Key 直接拿到 10 张 720 小时的卡。

    注意请求里**不带任何 cookie、不带 X-JF-Auth、不带 X-Admin-CSRF** —— 这正是
    机器调用方的真实形态。能过,说明 /api/admin/ 前缀的豁免与本端点的密钥闸
    确实接对了。
    """
    async with _api_client(api_wired["app"]) as c:
        r = await c.post("/api/admin/jfvip/cards/issue",
                         headers={"Authorization": f"Bearer {_GOOD_KEY}"},
                         json={"hours": 720, "ddHours": 720, "count": 10,
                               "batch": "渠道A", "note": "618活动"})
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["ok"] is True and d["count"] == 10 and len(d["cards"]) == 10
    assert d["plan"] == "@H720D720" and d["planName"] == "定制 30 天"
    assert d["jfHours"] == 720 and d["ddHours"] == 720 and d["inline"] is True
    # created_by 记录调用方来源 —— 事后追查的第一个锚点
    assert api_wired["made"][0]["operator"].startswith("cardapi@")
    # 审计落了,且**不含卡号**
    actor, action, detail = api_wired["audit"].rows[-1]
    assert action == "jfvip_cards_issue" and actor.startswith("cardapi@")
    assert "cards" not in detail and detail["count"] == 10
    assert detail["jfHours"] == 720 and detail["batch"] == "渠道A"


@pytest.mark.asyncio
async def test_asgi_issue_rejects_bad_and_missing_key(api_wired):
    async with _api_client(api_wired["app"]) as c:
        r1 = await c.post("/api/admin/jfvip/cards/issue",
                          headers={"Authorization": "Bearer wrong-key-wrong-key-wrong"},
                          json={"hours": 24})
        r2 = await c.post("/api/admin/jfvip/cards/issue", json={"hours": 24})
    assert r1.status_code == 401 and r1.json()["error"] == "bad_key", r1.text
    assert r2.status_code == 401 and r2.json()["error"] == "bad_key", r2.text
    assert not api_wired["made"], "密钥不对却发出了卡"


@pytest.mark.asyncio
async def test_asgi_issue_closed_when_key_unset(api_wired, monkeypatch):
    """★ 密钥为空 ⇒ 503,而不是放行。这条与 sso_link 相反,且 reason 必须说清楚。"""
    monkeypatch.setattr(userauth.UA.cfg, "jf_card_api_key", "", raising=False)
    async with _api_client(api_wired["app"]) as c:
        r = await c.post("/api/admin/jfvip/cards/issue",
                         headers={"Authorization": f"Bearer {_GOOD_KEY}"},
                         json={"hours": 24})
    assert r.status_code == 503, r.text
    assert r.json()["error"] == "api_disabled" and r.json()["reason"] == "no_key"
    assert not api_wired["made"]


@pytest.mark.asyncio
@pytest.mark.parametrize("body,want", [
    ({}, "missing_plan_or_hours"),
    ({"plan": "m1", "hours": 24}, "both_plan_and_hours"),
    ({"hours": 0}, "bad_hours"),
    ({"hours": True}, "bad_hours"),
    ({"hours": 24.5}, "bad_hours"),
    ({"hours": jfvip.INLINE_MAX_HOURS + 1}, "bad_hours"),
    ({"hours": 24, "ddHours": -1}, "bad_dd_hours"),
    ({"hours": 24, "count": 0}, "bad_count"),
    ({"hours": 24, "count": 501}, "bad_count"),
    ({"hours": 24, "count": "abc"}, "bad_count"),
])
async def test_asgi_issue_param_gauntlet(api_wired, body, want):
    """边界一律 400 + 具名错误码,且**一张卡都不发**。

    `hours: true` 与 `hours: 24.5` 这两条尤其要紧:裸 int() 会把它们静默收成
    1 和 24 —— 发出一批时长完全不是调用方本意的卡,而卡已经发出去了。
    """
    async with _api_client(api_wired["app"]) as c:
        r = await c.post("/api/admin/jfvip/cards/issue",
                         headers={"Authorization": f"Bearer {_GOOD_KEY}"}, json=body)
    assert r.status_code == 400, r.text
    assert r.json()["error"] == want, r.text
    assert not api_wired["made"], f"{body} 被拒却仍发出了卡"


@pytest.mark.asyncio
async def test_asgi_issue_respects_rate_limit(api_wired, monkeypatch):
    monkeypatch.setattr(userauth.UA.cfg, "jf_card_api_rate_hourly", 2, raising=False)
    codes = []
    async with _api_client(api_wired["app"]) as c:
        for _ in range(4):
            r = await c.post("/api/admin/jfvip/cards/issue",
                             headers={"Authorization": f"Bearer {_GOOD_KEY}"},
                             json={"hours": 24})
            codes.append(r.status_code)
            if r.status_code == 429:
                assert r.headers.get("Retry-After"), "429 缺少 Retry-After 头"
    assert codes == [200, 200, 429, 429], codes
    assert len(api_wired["made"]) == 2


@pytest.mark.asyncio
async def test_asgi_issue_blocked_by_admin_ip_allowlist(api_wired, monkeypatch):
    """★ 绝不在运维背后捅破 STA_ADMIN_IP_ALLOW 这道既有边界,
    且被它挡下时必须**点名旋钮**,而不是让集成方对着笼统 403 猜。"""
    monkeypatch.setenv("STA_ADMIN_IP_ALLOW", "10.0.0.0/8")
    async with _api_client(api_wired["app"]) as c:
        r = await c.post("/api/admin/jfvip/cards/issue",
                         headers={"Authorization": f"Bearer {_GOOD_KEY}"},
                         json={"hours": 24})
    assert r.status_code == 403, r.text
    assert r.json()["error"] == "ip_forbidden_admin"
    assert "STA_ADMIN_IP_ALLOW" in r.json()["message"], "没有点名是哪个旋钮"
    assert not api_wired["made"]


@pytest.mark.asyncio
async def test_asgi_issue_blocked_by_own_ip_allowlist(api_wired, monkeypatch):
    monkeypatch.setattr(userauth.UA.cfg, "jf_card_api_ip_allow",
                        "203.0.113.7/32", raising=False)
    async with _api_client(api_wired["app"]) as c:
        r = await c.post("/api/admin/jfvip/cards/issue",
                         headers={"Authorization": f"Bearer {_GOOD_KEY}"},
                         json={"hours": 24})
    assert r.status_code == 403 and r.json()["error"] == "ip_forbidden", r.text
    assert not api_wired["made"]


@pytest.mark.asyncio
async def test_asgi_issue_by_configured_plan_still_works(api_wired, monkeypatch):
    """外部 API 也能按配置档位发卡 —— 一个端点覆盖分销方的两种需求。"""
    monkeypatch.setattr(userauth.UA.cfg, "jf_vip_plans",
                        '[{"code":"m1","name":"1 个月","price":88,'
                        '"jfHours":744,"ddHours":744}]', raising=False)
    jfvip._plans_cache["raw"] = None
    async with _api_client(api_wired["app"]) as c:
        r = await c.post("/api/admin/jfvip/cards/issue",
                         headers={"Authorization": f"Bearer {_GOOD_KEY}"},
                         json={"plan": "m1", "count": 2})
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["plan"] == "m1" and d["jfHours"] == 744 and d["inline"] is False


# ══════════════════════════════════════════════════════════════════════════════
# G. 字符集安全化 —— 本轮审计实地复现的一整族缺陷
# ------------------------------------------------------------------------------
# 用户库全表 CHARSET=gbk,aiomysql 以 charset=gbk 建连;含 emoji 的参数在**编码
# SQL 时**就抛 UnicodeEncodeError,语句根本没发出去。项目对此早有定论,但升级前
# **只在一处**落实(sso_link_note 与 orders_page 的 user_name 分支)。真库逐条实测,
# 同族另外十处全部裸奔:读/筛选侧异常逃逸 ⇒ 管理台 HTTP 500(admin_api 零
# try/except);写侧被兜底 except 吞成 "db" ⇒ **外部发卡 API 回 503「库不可用」**,
# 而库好好的,只是渠道名里有个表情符号。
#
# 本节是**元测试**:不修某几条,而是让「新增一个进 gbk 表的自由文本参数却忘了
# 过闸」这一整类漏项从此不可能发生。
# ══════════════════════════════════════════════════════════════════════════════
_EMOJI = "🎉"


def test_gbk_text_sanitizes_for_write():
    """写入侧:不可表示字符换 '?',绝不让操作失败(沿用 sso_link_note 的裁决)。"""
    assert jfvip.gbk_text("渠道A" + _EMOJI, 32) == "渠道A?"
    assert jfvip.gbk_text(None, 32) == ""
    assert jfvip.gbk_text("x" * 200, 32) == "x" * 32
    # 替换后必须仍能被 gbk 编码 —— 这才是这个函数存在的全部意义
    jfvip.gbk_text("a" + _EMOJI + "b", 100).encode("gbk")


def test_gbk_ok_is_the_filter_side_predicate():
    """筛选侧:可表示 → True;不可表示 → False(调用方据此补 1=0)。

    ★ 筛选侧**绝不能**换 '?' —— 那会静默去查一个**不同的串**,屏幕上显示
      「没有记录」,而人只会以为这批卡不存在。这与本项目在 CSV 导出与 norm_ids
      两处反复写过的「静默差异」是同一条。
    """
    assert jfvip.gbk_ok("渠道A") is True
    assert jfvip.gbk_ok("キャンペーン") is True        # gbk 覆盖片假名,不该误伤
    assert jfvip.gbk_ok("") is True
    assert jfvip.gbk_ok(None) is True
    assert jfvip.gbk_ok("渠道A" + _EMOJI) is False


def test_gbk_write_and_filter_are_mutually_consistent():
    """两套口径必须自洽:写入侧已把 emoji 换成 '?',故库里不可能存在含 emoji 的值,
    筛选侧「查不到」是**事实**而不是妥协。"""
    stored = jfvip.gbk_text("渠道A" + _EMOJI, 32)
    assert jfvip.gbk_ok(stored) is True, "写入侧产物必须能被筛选侧查询"


def test_every_free_text_param_passes_a_gbk_gate():
    """★ 元测试:凡是把**自由文本**拼进 SQL 参数的函数,都必须过闸。

    判据是扫源码而不是列清单 —— 列清单的话,下次谁加第十二个参数照样漏。
    """
    src = py_code(APP / "jfvip.py")
    tree = ast.parse(src)
    fns = {n.name: n for n in ast.walk(tree)
           if isinstance(n, (ast.AsyncFunctionDef, ast.FunctionDef))}
    # (函数名, 闸, **该函数有几个自由文本参数**)
    # ★ 计数是刻意的:初版只断言「闸出现过」,于是把三个参数里的两个退回不清洗,
    #   测试照样绿(实测坐实)—— 因为剩下那一个还在调闸。那种断言给的是虚假的
    #   安全感,比不测更糟。数字即该函数的自由文本参数个数,新增参数时必须同步 +1,
    #   而那正是提醒你「这个新参数也得过闸」的时刻。
    must = {
        "_gen_cards_code": ("gbk_text", 3),   # batch / note / operator
        "cards_page": ("gbk_ok", 3),          # batch / card / plan_code
        "cards_batch_stat": ("gbk_ok", 1),    # batch
        "cards_disable": ("gbk_ok", 1),       # batch
        "cards_set_note": ("gbk_text", 1),    # note
        "orders_page": ("gbk_ok", 3),         # order_no / plan_code / status
        "grants_page": ("gbk_ok", 1),         # source
    }
    bad = []
    for name, (gate, n) in must.items():
        fn = fns.get(name)
        assert fn is not None, f"{name} 丢失或改名 —— gbk 闸的锚点没了"
        body = ast.get_source_segment(src, fn) or ""
        got = body.count(gate + "(")
        if got < n:
            bad.append((name, gate, f"需 {n} 处,实得 {got}"))
    assert not bad, (
        f"以下函数的自由文本参数没有全部过闸 {bad} —— "
        f"读侧会让管理台 500,写侧会被兜底 except 吞成「库不可用」")
    # user_name 那条是项目升级前**唯一**落实过的,必须仍在(别把老的修复改没了)
    ordp = ast.get_source_segment(src, fns["orders_page"]) or ""
    assert "charset" in ordp or ordp.count("gbk_ok(") >= 4, \
        "orders_page 丢失了 user_name 的既有字符集判断"


def test_admin_api_card_endpoints_have_no_bare_500_path():
    """admin_api 的三个列表端点**零 try/except**(实地核查确认),故防线只能在
    jfvip 侧。本用例钉住这个前提:哪天有人在 admin_api 加了兜底,那也不该成为
    把 jfvip 侧的闸拆掉的理由 —— 兜底把 500 变成 503,同样是在撒谎。"""
    api = py_code(APP / "admin_api.py")
    i = api.index('@router.get("/jfvip/cards")')
    seg = api[i:api.index('@router.post("/jfvip/cards/generate")')]
    assert "except" not in seg, (
        "jfvip_cards 出现了兜底 except —— 若是为了盖住 UnicodeEncodeError,"
        "正解是在 jfvip.cards_page 里过 gbk 闸(回空结果),而不是把它变成 503")


def test_overview_buckets_inline_codes():
    """★ byPlan 必须把内联码聚合成一桶,两个理由缺一不可:
       ① 有界 —— 内联码由运营任意指定,组数无上限,原样回传会让概览响应随
          定制次数无限膨胀;
       ② 可见 —— 前端「档位与销量」表是 plans.map(...) 渲染的,只遍历配置档位,
          内联码即便回传了也一行都不显示。"""
    src = py_code(APP / "jfvip.py")
    seg = src[src.index("async def _by_plan"):]
    seg = seg[:seg.index("\n    async def ")]
    assert "is_inline_code" in seg, "byPlan 未把内联码单独归桶"
    assert "customGrants" in seg, "未回报定制卡合计 —— 前端无从显示"
    js = js_code(ADMIN_JS)
    assert "customGrants" in js, "前端未消费 customGrants —— 定制卡销量仍不可见"


def test_frontend_banner_no_longer_lies_about_empty_plan_table():
    """★ 文档撒谎和代码有 bug 一样有害(项目原话)。

    档位表为空时的警告横幅原文是「此时发卡与手动开通都会失败」—— 4.2.9 之后
    这句话**不再为真**:「⏱ 指定时长」发卡不查档位表,照发不误。是我的改动让
    这句既有文案变成了谎话,必须同步修。
    """
    js = ADMIN_JS.read_text(encoding="utf-8")
    i = js.index("<b>档位表为空</b>")
    seg = js[i:i + 700]
    assert "按档位发卡" in seg, "横幅仍笼统说「发卡会失败」—— 指定时长发卡并不会"
    assert "指定时长" in seg, "横幅没告诉运维还有一条不受影响的发卡路径"


def test_csv_export_carries_readable_duration():
    """定制卡的档位码是 @H720D720,渠道对账时人不该被迫去心算。
    「时长」是**新增列**而不是替换「档位」—— 档位列是库里 plan_code 的原值,
    对账必须逐字可回溯;时长列是给人看的派生值。两者都要。"""
    js = js_code(ADMIN_JS)
    i = js.index("jvCsv(['卡密'")
    seg = js[i:i + 400]
    assert "'时长'" in seg, "卡密 CSV 缺可读时长列"
    assert "c.plan" in seg, "卡密 CSV 丢了 plan_code 原值 —— 对账无法逐字回溯"
    assert "jvPlanDur" in seg


@needs_db
def test_realdb_emoji_in_batch_and_note_does_not_500(capsys):
    """★ 真库复现 + 回归钉:外部发卡 API 的 batch/note 是**调用方自由文本**,
    渠道名叫「渠道A🎉」是完全正常的事。修前:UnicodeEncodeError 被兜底吞成
    "db" ⇒ HTTP 503「库暂时不可用」—— 调用方会去查数据库,而库好好的。"""
    async def _run():
        try:
            await _prepare()
            err, out = await jfvip.gen_cards_hours(
                2, 24, 0, "渠道A" + _EMOJI, "618活动" + _EMOJI, "cardapi@1.2.3.4")
            assert err == "", f"含 emoji 的批次/备注仍然发卡失败:{err!r}"
            row = await userauth._q(
                "SELECT batch, note FROM guantai_jf_card WHERE card=%s",
                (out["cards"][0],), fetch="one")
            assert row["batch"] == "渠道A?" and row["note"] == "618活动?", row
            # 且**存进去的值必须能被查回来** —— 两套口径自洽的活体验证
            page = await jfvip.cards_page(1, 10, batch=row["batch"])
            assert page["total"] >= 2, "写进去的批次查不回来 —— 两套口径不自洽"
            # 而用原始（含 emoji）的串去查:走 1=0,回空结果而不是 500
            page2 = await jfvip.cards_page(1, 10, batch="渠道A" + _EMOJI)
            assert page2["total"] == 0 and page2["items"] == []
        finally:
            await userauth.close()

    asyncio.run(_run())


@needs_db
def test_realdb_xff_cannot_break_issuance():
    """★ created_by 由 client_ip() 拼出,而 client_ip 取的是**调用方可控的**
    X-Forwarded-For 首跳 —— 那是一条自由文本通道。持有效密钥者发一个
    `X-Forwarded-For: 🎉` 就能让每一次发卡都 503(自伤,但仍是可用性缺口)。"""
    async def _run():
        try:
            await _prepare()
            err, out = await jfvip.gen_cards_hours(1, 24, 0, "BXFF", "", "cardapi@" + _EMOJI)
            assert err == "", f"污染的 XFF 让发卡失败:{err!r}"
            row = await userauth._q("SELECT created_by FROM guantai_jf_card WHERE card=%s",
                                    (out["cards"][0],), fetch="one")
            assert row["created_by"] == "cardapi@?", row
        finally:
            await userauth.close()

    asyncio.run(_run())


# ══════════════════════════════════════════════════════════════════════════════
# H. 幂等 —— 网络重试不得重复发卡(4.2.9 审计补)
# ------------------------------------------------------------------------------
# ★ 本轮审计实地复现:完全相同的请求体连调两次 → 库里 10 张卡,卡号不重叠。
#   触发路径不是恶意,是最普通的网络抖动:请求已到达、卡已落库,响应在回程丢了,
#   平台按常规重试。多出来的卡同样可兑换 ⇒ 直接资损,且事后无法分辨哪一批是重复的。
#   项目对此早有标准(guantai_jf_order 的「幂等的物理底线」),而发卡 API 一条都没有。
# ══════════════════════════════════════════════════════════════════════════════
def test_idem_key_norm():
    assert jfvip.idem_key_norm(" po-2026-001 ") == "po-2026-001"
    assert jfvip.idem_key_norm("k" + _EMOJI) == "k"      # 非 ASCII 剔除
    assert jfvip.idem_key_norm("x" * 200) == "x" * 64
    assert jfvip.idem_key_norm(None) == "" and jfvip.idem_key_norm("") == ""


def test_idem_slot_is_deterministic_and_bounded():
    a, b = jfvip._idem_slot("po-1"), jfvip._idem_slot("po-1")
    assert a == b, "同键必须落同一槽位,否则幂等根本不成立"
    assert a != jfvip._idem_slot("po-2")
    assert len(a) < 120, "Redis 键名应有界"


def test_idem_unavailable_without_redis(monkeypatch):
    """★ Redis 不可用 ⇒ unavailable,**不是**静默放行。

    别处的风控组件在 Redis 抖动时退化为进程内计数(「风控组件故障不放开」),
    这里不能照抄:web 是多 worker 进程,重试极可能落到**另一个进程**,进程内
    兜底对幂等毫无作用。调用方既然显式给了键就是在依赖这个保证 ——
    悄悄不提供是最坏的:他会放心地重试。
    """
    monkeypatch.setattr(userauth.UA, "redis", None, raising=False)
    assert asyncio.run(jfvip.idem_begin("po-x", "fp"))[0] == "unavailable"
    assert asyncio.run(jfvip.idem_peek("po-x", "fp"))[0] == "unavailable", \
        "只读探针同样必须报 unavailable —— 它排在限频之前,静默放行等于没有幂等"


def _fake_redis():
    fr = pytest.importorskip("fakeredis.aioredis")
    return fr.FakeRedis(decode_responses=True)


def test_idem_lifecycle(monkeypatch):
    """new → in_flight → done,以及 abort 释放占位。"""
    monkeypatch.setattr(userauth.UA, "redis", _fake_redis(), raising=False)

    FP = "abc123"

    async def _run():
        assert (await jfvip.idem_peek("po-A", FP))[0] == "miss", "未占位时探针应回 miss"
        st, slot = await jfvip.idem_begin("po-A", FP)
        assert st == "new"
        assert (await jfvip.idem_begin("po-A", FP))[0] == "in_flight", \
            "占位期间的重放必须可辨,不能当成首次"
        # 占位期间**换参数**同样要能辨出来(指纹写在 PENDING 值里)
        assert (await jfvip.idem_peek("po-A", "other"))[0] == "conflict"
        await jfvip.idem_finish(slot, jfvip.idem_stamp(
            {"ok": True, "cards": ["TLAAAAAA111111"]}, FP))
        st3, data = await jfvip.idem_peek("po-A", FP)
        assert st3 == "done" and data["cards"] == ["TLAAAAAA111111"]
        assert (await jfvip.idem_peek("po-A", "other"))[0] == "conflict", \
            "完成后换参数仍须报 conflict —— 否则调用方的键复用 bug 被掩盖"
        # abort 让同一个键可以重来 —— 否则一次参数写错就把键烧掉 24 小时
        st4, slot4 = await jfvip.idem_begin("po-B", FP)
        assert st4 == "new"
        await jfvip.idem_abort(slot4)
        assert (await jfvip.idem_begin("po-B", FP))[0] == "new", "abort 后同键应能重新占位"

    asyncio.run(_run())


@pytest.mark.asyncio
async def test_asgi_idempotent_retry_does_not_double_issue(api_wired, monkeypatch):
    """★ 端到端:同一幂等键重放**回上次那一批卡号**,而不是发新的。"""
    monkeypatch.setattr(userauth.UA, "redis", _fake_redis(), raising=False)
    body = {"hours": 720, "count": 5, "batch": "R1", "idempotencyKey": "po-001"}
    async with _api_client(api_wired["app"]) as c:
        r1 = await c.post("/api/admin/jfvip/cards/issue",
                          headers={"Authorization": f"Bearer {_GOOD_KEY}"}, json=body)
        r2 = await c.post("/api/admin/jfvip/cards/issue",
                          headers={"Authorization": f"Bearer {_GOOD_KEY}"}, json=body)
    assert r1.status_code == r2.status_code == 200
    assert r1.json()["cards"] == r2.json()["cards"], "重放发出了**不同的**卡 —— 幂等失效"
    assert r1.json().get("idempotent") is None and r2.json()["idempotent"] is True
    assert len(api_wired["made"]) == 1, f"实际发卡 {len(api_wired['made'])} 次,应为 1"


@pytest.mark.asyncio
async def test_asgi_idempotency_fails_closed_without_redis(api_wired, monkeypatch):
    monkeypatch.setattr(userauth.UA, "redis", None, raising=False)
    async with _api_client(api_wired["app"]) as c:
        r = await c.post("/api/admin/jfvip/cards/issue",
                         headers={"Authorization": f"Bearer {_GOOD_KEY}"},
                         json={"hours": 24, "idempotencyKey": "po-z"})
        r2 = await c.post("/api/admin/jfvip/cards/issue",
                          headers={"Authorization": f"Bearer {_GOOD_KEY}"},
                          json={"hours": 24})
    assert r.status_code == 503 and r.json()["error"] == "idempotency_unavailable"
    assert r2.status_code == 200, "不给幂等键的调用方不该被牵连"
    # 恰好一次发卡 —— 且必须是**不给键的那一次**。写成 `not made` 是错的
    # (本用例故意发了两个请求),初版就是这么写的,被自己的用例当场抓到。
    assert len(api_wired["made"]) == 1, (
        f"发卡 {len(api_wired['made'])} 次:给了幂等键而 Redis 不可用时仍发了卡")


@pytest.mark.asyncio
async def test_asgi_failed_request_releases_the_slot(api_wired, monkeypatch):
    """参数写错必须释放占位 —— 否则一次手滑就把这个键烧掉 24 小时。"""
    monkeypatch.setattr(userauth.UA, "redis", _fake_redis(), raising=False)
    H = {"Authorization": f"Bearer {_GOOD_KEY}"}
    async with _api_client(api_wired["app"]) as c:
        bad = await c.post("/api/admin/jfvip/cards/issue", headers=H,
                           json={"hours": 0, "idempotencyKey": "po-fix"})
        good = await c.post("/api/admin/jfvip/cards/issue", headers=H,
                            json={"hours": 24, "idempotencyKey": "po-fix"})
    assert bad.status_code == 400 and good.status_code == 200, (bad.text, good.text)
    assert good.json().get("idempotent") is None


def test_idempotency_is_documented_and_gated_in_endpoint():
    src = py_code(APP / "admin_api.py")
    i = src.index('@router.post("/jfvip/cards/issue")')
    seg = src[i:src.index('@router.post("/jfvip/cards/disable")')]
    assert "idem_begin" in seg and "idem_finish" in seg and "idem_abort" in seg
    assert "idempotency_unavailable" in seg, "缺 fail-closed 分支"
    assert "idempotency_in_flight" in seg, "缺在途分支(否则并发重放会被当成首次)"
    # idem_finish 必须在审计之后、返回之前 —— 任一步失败都不该留下"已完成"记录
    assert seg.index("idem_finish") > seg.index("audit_add"), \
        "幂等结果写在审计之前 —— 中途失败会留下一个调用方其实没收到的卡号清单"
    doc = (ROOT / "JFVIP-SYSTEM.md").read_text(encoding="utf-8")
    assert "idempotencyKey" in doc, "文档未记载幂等键"


# ══════════════════════════════════════════════════════════════════════════════
# I. 幂等加固 + 密钥生成按钮(第三轮审计)
# ══════════════════════════════════════════════════════════════════════════════
def test_idem_fingerprint_covers_every_issuing_param():
    """指纹必须覆盖**所有决定发出什么卡**的字段 —— 漏一个就等于那个字段可以
    在同键下被悄悄改掉。"""
    base = {"hours": 24, "ddHours": 0, "count": 1, "batch": "B", "note": "n"}
    fp0 = jfvip.idem_fingerprint(base)
    for k, v in [("hours", 720), ("ddHours", 24), ("count", 2),
                 ("batch", "C"), ("note", "m"), ("plan", "m1")]:
        assert jfvip.idem_fingerprint({**base, k: v}) != fp0, f"指纹漏了字段 {k}"
    assert jfvip.idem_fingerprint(dict(base)) == fp0, "指纹不稳定(同输入不同输出)"
    # 无关字段不该改变指纹(否则调用方多带一个字段就被判成 key_reused)
    assert jfvip.idem_fingerprint({**base, "idempotencyKey": "x"}) == fp0


@pytest.mark.asyncio
async def test_asgi_same_key_different_params_is_rejected(api_wired, monkeypatch):
    """★ 同键配不同参数 ⇒ **调用方有 bug**,必须当场报错。

    原实现静默回第一次的结果:他发 hours=8760/count=500 却拿到 24h×1 张、HTTP 200,
    以为 500 张年卡发出去了,实际一张都没发。静默的错误答案比报错危险得多。
    """
    monkeypatch.setattr(userauth.UA, "redis", _fake_redis(), raising=False)
    H = {"Authorization": f"Bearer {_GOOD_KEY}"}
    async with _api_client(api_wired["app"]) as c:
        a = await c.post("/api/admin/jfvip/cards/issue", headers=H,
                         json={"hours": 24, "count": 1, "idempotencyKey": "same"})
        b = await c.post("/api/admin/jfvip/cards/issue", headers=H,
                         json={"hours": 8760, "count": 500, "idempotencyKey": "same"})
    assert a.status_code == 200
    assert b.status_code == 409 and b.json()["error"] == "idempotency_key_reused", b.text
    assert len(api_wired["made"]) == 1, "同键异参却又发了一批卡"


@pytest.mark.asyncio
async def test_asgi_replay_does_not_burn_rate_quota(api_wired, monkeypatch):
    """★ 重放**没创造任何价值**,不该消耗发卡配额。

    实测(修前):cap=3 时连续 4 次重放得到 [200,429,429,429] —— 平台对 20 笔订单
    各重试 3 次即打满默认 cap(60)。故幂等**只读探针**必须排在限频之前;
    而原子占位仍排在限频之后,否则限频拒绝会留下 PENDING 占位,该键此后 24 小时
    一直回 409(用一个更难查的故障换掉一个好查的)。
    """
    monkeypatch.setattr(userauth.UA, "redis", _fake_redis(), raising=False)
    monkeypatch.setattr(userauth.UA.cfg, "jf_card_api_rate_hourly", 2, raising=False)
    H = {"Authorization": f"Bearer {_GOOD_KEY}"}
    body = {"hours": 24, "count": 1, "idempotencyKey": "rep"}
    async with _api_client(api_wired["app"]) as c:
        codes = [(await c.post("/api/admin/jfvip/cards/issue", headers=H,
                               json=body)).status_code for _ in range(6)]
    assert codes == [200] * 6, f"重放被限频挡下:{codes}"
    assert len(api_wired["made"]) == 1


@pytest.mark.asyncio
async def test_asgi_throttle_leaves_no_stuck_idem_slot(api_wired, monkeypatch):
    """限频拒绝后,同一个键必须还能用 —— 否则一次限流就把键烧掉 24 小时。"""
    monkeypatch.setattr(userauth.UA, "redis", _fake_redis(), raising=False)
    monkeypatch.setattr(userauth.UA.cfg, "jf_card_api_rate_hourly", 1, raising=False)
    H = {"Authorization": f"Bearer {_GOOD_KEY}"}
    async with _api_client(api_wired["app"]) as c:
        await c.post("/api/admin/jfvip/cards/issue", headers=H, json={"hours": 24})
        r1 = await c.post("/api/admin/jfvip/cards/issue", headers=H,
                          json={"hours": 24, "idempotencyKey": "k1"})
        monkeypatch.setattr(userauth.UA.cfg, "jf_card_api_rate_hourly", 0, raising=False)
        r2 = await c.post("/api/admin/jfvip/cards/issue", headers=H,
                          json={"hours": 24, "idempotencyKey": "k1"})
    assert r1.status_code == 429
    assert r2.status_code == 200, f"限频后该键被卡死:{r2.text}"


def test_replay_response_hides_internal_fingerprint():
    """重放返回体不该漏出内部字段 _fp —— 调用方会把它当契约的一部分。"""
    src = py_code(APP / "admin_api.py")
    i = src.index('@router.post("/jfvip/cards/issue")')
    seg = src[i:src.index('@router.post("/jfvip/cards/disable")')]
    assert seg.count('k != "_fp"') >= 2, "重放分支未剔除内部指纹字段"


def test_idem_probe_precedes_rate_limit_in_source():
    """闸序是本设计的核心,用静态钉锁住:探针 < 限频 < 占位。"""
    src = py_code(APP / "admin_api.py")
    i = src.index('@router.post("/jfvip/cards/issue")')
    seg = src[i:src.index('@router.post("/jfvip/cards/disable")')]
    peek, rate, begin = (seg.index("idem_peek"), seg.index("card_api_rate_ok"),
                         seg.index("idem_begin"))
    assert peek < rate < begin, (
        f"闸序错(peek={peek} rate={rate} begin={begin})—— 探针必须在限频前"
        f"(重放不耗配额),占位必须在限频后(限频拒绝不留死占位)")


# ── 密钥生成按钮 ─────────────────────────────────────────────────────────────
def test_secret_generator_never_uses_math_random():
    """★★ 红线:密钥生成**只能**用 crypto.getRandomValues。

    Math.random 在 V8 里是 xorshift128+ —— 观察若干输出即可反推内部状态。
    拿它生成的「密钥」等于没有密钥,而这把密钥的唯一作用是凭空造出可兑换的
    VIP 时长。本用例扫 genSecret 函数体,出现 Math.random 即红。
    """
    js = js_code(ADMIN_JS)
    i = js.index("async function genSecret(")
    seg = js[i:js.index("\ndocument.addEventListener('click'", i)]
    assert "crypto.getRandomValues" in seg, "密钥生成未用 CSPRNG"
    assert "Math.random" not in seg, "密钥生成出现 Math.random —— 可预测,等于没有密钥"
    # 安全上下文不可用时必须**拒绝**,不能回退到别的随机源
    assert "window.crypto && window.crypto.getRandomValues" in seg, "缺可用性检查"


def test_secret_generator_shows_the_key_once_and_offers_copy():
    """密钥要交给发卡平台,而 sensitive 输入框是 type=password 且不回显 ——
    只填进框里的话,点完「应用」就再也看不到它了。"""
    js = js_code(ADMIN_JS)
    i = js.index("async function genSecret(")
    seg = js[i:js.index("\ndocument.addEventListener('click'", i)]
    assert "gsOut" in seg and "gsCopy" in seg, "缺一次性展示或复制按钮"
    assert "execCommand" in seg, "缺剪贴板兜底(非安全上下文下 navigator.clipboard 不可用)"
    assert "旧密钥立即失效" in ADMIN_JS.read_text(encoding="utf-8"), \
        "没有警告「应用后旧密钥立即失效」—— 在用旧密钥的调用方会当场全挂"


def test_generator_button_only_for_self_issued_secrets():
    """★ 只给**我方自定、对方照抄**的密钥,不是所有 sensitive 都给。

    auth.ticket 之类是**上游签发**的凭据,本地随机生成一个只会把接入打挂。
    判据是注册表的 gen_bytes,而不是 sensitive 标记。
    """
    from app import config_registry as reg
    gens = {k for k, f in reg.REGISTRY.items() if getattr(f, "gen_bytes", 0) > 0}
    assert gens == {"userauth.jf_card_api_key"}, f"生成按钮的授予面漂了:{gens}"
    assert reg.REGISTRY["auth.ticket"].gen_bytes == 0, "上游签发的凭据不该给生成按钮"
    f = reg.REGISTRY["userauth.jf_card_api_key"]
    assert f.gen_bytes * 2 >= jfvip._CARD_API_KEY_MIN, (
        f"生成 {f.gen_bytes} 字节 = {f.gen_bytes*2} hex 字符,"
        f"低于后端密钥长度下限 {jfvip._CARD_API_KEY_MIN} —— 按钮生成出来的密钥会被自己拒绝")
    js = js_code(ADMIN_JS)
    assert "f.genBytes" in js, "前端未按 genBytes 决定是否渲染按钮"


# ══════════════════════════════════════════════════════════════════════════════
# J. 第四轮审计:并发、指纹语义、生成按钮的 DOM 结构
# ══════════════════════════════════════════════════════════════════════════════
@pytest.mark.parametrize("a,b", [
    ({"hours": 24}, {"hours": 24, "count": 1}),          # count 默认就是 1
    ({"hours": 24}, {"hours": 24, "ddHours": 0}),        # ddHours 默认就是 0
    ({"hours": 24, "batch": ""}, {"hours": 24}),         # 空批次 ≡ 不给
    ({"hours": 24}, {"hours": "24"}),                    # 数字 / 字符串
    ({"plan": "m1"}, {"plan": "m1", "count": 1}),
])
def test_fingerprint_is_semantic_not_literal(a, b):
    """★ 指纹必须取**规范化后**的参数,不能取原始请求体。

    实测缺陷:原实现取原始 body,于是 `{"hours":24}` 与 `{"hours":24,"count":1}`
    语义完全相同(count 默认就是 1)却指纹不同 —— 调用方的 HTTP 客户端在重试时
    多序列化了一个默认字段,就会收到一个**假的** 409,他会去查自己根本不存在的
    键复用 bug。假阳性比不检查更浪费人。
    """
    assert jfvip.idem_fingerprint(a) == jfvip.idem_fingerprint(b), \
        f"语义等价的两个请求体指纹不同 —— 会误报 idempotency_key_reused"


@pytest.mark.parametrize("a,b", [
    ({"hours": 24}, {"hours": 720}),
    ({"hours": 24, "count": 1}, {"hours": 24, "count": 2}),
    ({"hours": 24}, {"hours": 24, "ddHours": 24}),
    ({"hours": 24, "batch": "A"}, {"hours": 24, "batch": "B"}),
    ({"hours": 24, "note": "x"}, {"hours": 24, "note": "y"}),
    ({"plan": "m1"}, {"hours": 744}),                    # 两种写法不该被当成同一个
])
def test_fingerprint_still_separates_real_differences(a, b):
    """规范化不能把真正不同的请求抹平 —— 那会让键复用检测失效。"""
    assert jfvip.idem_fingerprint(a) != jfvip.idem_fingerprint(b)


def test_fingerprint_and_issuing_share_one_parser():
    """★ 指纹与真正的发卡必须走**同一个解析器**。两处各写一份,
    「count 默认几」「空 batch 算不算给了」这类判断迟早分歧。"""
    src = py_code(APP / "jfvip.py")
    tree = ast.parse(src)
    fns = {n.name: n for n in ast.walk(tree)
           if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    fp = ast.get_source_segment(src, fns["idem_fingerprint"]) or ""
    assert "normalize_issue" in fp, "指纹没走规范化解析器"
    api = py_code(APP / "admin_api.py")
    seg = api[api.index("async def _issue_cards"):]
    seg = seg[:seg.index("\n@router") if "\n@router" in seg else len(seg)]
    assert "jfvip.normalize_issue" in seg, "发卡路径没走同一个解析器"
    # 解析逻辑不该在 admin_api 里再写一遍
    for dup in ('body.get("count"', 'norm_count(', 'norm_hours('):
        assert dup not in seg, f"发卡入口重复实现了参数解析:{dup}"


def test_normalize_issue_is_pure_and_leaves_batch_untouched():
    """★ 规范化只做「语义等价的收敛」,**不做「填默认值产生新信息」**。

    batch 为空时绝不能在这里补自动批次号 —— 自动批次号含时间戳,补了以后同一个
    请求隔几秒重试就变成"不同请求",幂等当场失效。
    """
    err, a = jfvip.normalize_issue({"hours": 24})
    err2, b = jfvip.normalize_issue({"hours": 24})
    assert err == err2 == "" and a == b, "规范化不是纯函数(同输入不同输出)"
    assert a["batch"] == "", "规范化替 batch 填了值 —— 会让幂等随时间失效"
    assert a["plan"] == "@H24" and a["count"] == 1
    # 错误分支
    assert jfvip.normalize_issue({})[0] == "missing_plan_or_hours"
    assert jfvip.normalize_issue({"plan": "m1", "hours": 24})[0] == "both_plan_and_hours"
    assert jfvip.normalize_issue({"hours": 0})[0] == "bad_hours"
    assert jfvip.normalize_issue({"hours": 24, "count": 0})[0] == "bad_count"


def test_generator_button_is_a_flex_sibling_not_a_wrapper():
    """★ 实地核查的视觉回归:`.pctl` 是 display:flex,输入框靠
    `.pctl input[type=password]{flex:1;min-width:0}` 撑开。

    初版把 input 包进了 `<span class="sec-wrap">` —— 选择器仍命中(后代选择器),
    但 flex:1 相对的是那个非 flex 的 span,等于失效,输入框当场变窄错位。
    bool 分支(toggle+span)与数值分支(input+.unit)都是并列兄弟,必须照它们来。
    """
    js = js_code(ADMIN_JS)
    i = js.index("if (f.sensitive) {")
    seg = js[i:i + 1400]
    assert "sec-wrap" not in seg, "密钥输入框被包进了额外容器 —— flex:1 会失效"
    assert "sec-gen" in seg
    css = (ROOT / "assets" / "admin.css").read_text(encoding="utf-8")
    flat = css.replace(" ", "")
    assert ".sec-gen" in flat and "flex:none" in flat, \
        "生成按钮缺 flex:none —— 会被 input 的 flex:1 压成一条(同 .pctl .unit)"
    # 两个按钮共用同一条规则,任一漏掉都会被压扁
    rule = flat[flat.index(".pctl.sec-gen"):flat.index("}", flat.index(".pctl.sec-gen"))]
    assert ".sec-rev" in rule and "flex:none" in rule, f"揭示按钮未纳入同一条规则:{rule}"


@pytest.mark.asyncio
async def test_asgi_concurrent_same_key_issues_exactly_one_batch(api_wired, monkeypatch):
    """★ 并发实测(真 ASGI + asyncio.gather):20 路并发同一幂等键。

    这是三轮里我承诺过两次却没做的验证。「探 → 限频 → 占位」跨三步,
    逻辑推演证明不了并发下的实际行为。实测:1 路 200 + 19 路 409,恰好一批。

    ⚠ **本用例证明不了原子性,必须写明**:单进程 asyncio + fakeredis 下,
      `await r.get()` 与 `await r.set()` 之间不会让出给其它协程 —— 实测把
      SET NX 换成「先读后写」的非原子实现,50 路并发**仍然**只有 1 路拿到 new。
      也就是说本用例在非原子实现下同样会绿。真正的保护是下面那条静态钉:
      生产是真 Redis + 多 uvicorn worker,那里「先读后写」必然race。
    """
    monkeypatch.setattr(userauth.UA, "redis", _fake_redis(), raising=False)
    H = {"Authorization": f"Bearer {_GOOD_KEY}"}
    body = {"hours": 24, "count": 5, "batch": "RACE", "idempotencyKey": "race-1"}
    async with _api_client(api_wired["app"]) as c:
        rs = await asyncio.gather(*[
            c.post("/api/admin/jfvip/cards/issue", headers=H, json=body)
            for _ in range(20)])
    ok = [r for r in rs if r.status_code == 200]
    assert len(api_wired["made"]) == 1, (
        f"20 路并发发了 {len(api_wired['made'])} 批 —— 幂等在并发下失效")
    assert len(ok) >= 1
    assert all(r.status_code in (200, 409) for r in rs), \
        [r.status_code for r in rs]


def test_idem_claim_uses_the_atomic_primitive():
    """★ 占位**必须**用 `SET ... NX`(单条原子命令),不能是「先 GET 再 SET」。

    为什么要一条静态钉而不是只靠并发用例:上面那条并发用例在单进程 asyncio +
    fakeredis 下**证明不了原子性**(实测:换成非原子实现,50 路并发仍只有 1 路
    拿到 new —— get 与 set 之间不让出)。而生产是**真 Redis + 多 uvicorn worker**,
    那里「先读后写」必然 race:两个进程同时读到空,都判定自己是首次,都去发卡。
    幂等的全部价值在这一条命令上,故直接钉死这个原语。
    """
    src = py_code(APP / "jfvip.py")
    tree = ast.parse(src)
    fn = next(n for n in ast.walk(tree)
              if isinstance(n, ast.AsyncFunctionDef) and n.name == "idem_begin")
    body = ast.get_source_segment(src, fn) or ""
    assert "nx=True" in body, (
        "idem_begin 未用 SET NX —— 多进程下「先读后写」必然重复发卡")
    # 且 NX 那句必须带过期,否则一次崩溃就把键永久烧掉
    assert "ex=_IDEM_TTL_S" in body, "占位未设 TTL —— 进程崩溃后该键永久卡死"
    # 占位之前不得有对同一 slot 的 GET(那就是「先读后写」的形态)
    i = body.index("nx=True")
    assert "r.get(slot)" not in body[:i], \
        "占位前出现了对同一 slot 的 GET —— 这正是非原子的「先读后写」形态"


# ══════════════════════════════════════════════════════════════════════════════
# K. 第五轮:plan 语义收口 + 密钥「随时可见」
# ══════════════════════════════════════════════════════════════════════════════
def test_plan_field_rejects_inline_codes():
    """★ 第四轮把发卡入口收敛到 resolve_plan 之后,`plan` 字段**悄悄开始接受
    内联码** —— 而公开函数 gen_cards() 用的仍是 plan_of,对同一个串回 None。
    同一个 "plan" 在代码库里有了两种含义,正是本项目最反对的那类不一致。
    一件事只留一种写法:指定时长走 hours,plan 只认配置档位码。
    """
    for bad in ("@H720", "@H720D24", "@H1"):
        err, out = jfvip.normalize_issue({"plan": bad})
        assert err == "plan_is_inline", f"plan={bad} 未被收口:{err!r}"
        assert "hours" in out.get("hint", "")
    # 配置档位码照常
    assert jfvip.normalize_issue({"plan": "m1"})[0] == ""
    # 而 hours 通道产出的正是同一个内联码 —— 两条路的**结果**一致,入口只留一个
    assert jfvip.normalize_issue({"hours": 720})[1]["plan"] == "@H720"
    # plan_of 与 normalize_issue 对内联码的态度必须一致(都不认)
    assert jfvip.plan_of("@H720") is None


@pytest.mark.asyncio
async def test_asgi_plan_inline_is_rejected(api_wired):
    async with _api_client(api_wired["app"]) as c:
        r = await c.post("/api/admin/jfvip/cards/issue",
                         headers={"Authorization": f"Bearer {_GOOD_KEY}"},
                         json={"plan": "@H720", "count": 1})
    assert r.status_code == 400 and r.json()["error"] == "plan_is_inline", r.text
    assert not api_wired["made"]


def test_reveal_is_gated_by_registry_not_by_sensitive_alone():
    """★ 授予面必须是 `revealable`,**不是**所有 sensitive 都给。

    auth.ticket 之类是**上游签发**的凭据 —— 运维本来就是从对方那里拿的,本台没有
    交付责任,不该多开一个读取口子。而发卡密钥是我方自定、需要交付给对端的,
    没存好就再也拿不回来,只能重新生成一把再改一遍对方的配置。
    """
    from app import config_registry as reg
    revealable = {k for k, f in reg.REGISTRY.items()
                  if getattr(f, "revealable", False)}
    assert revealable == {"userauth.jf_card_api_key"}, f"揭示授予面漂了:{revealable}"
    assert reg.REGISTRY["auth.ticket"].revealable is False
    # revealable 必须蕴含 sensitive(非敏感项本来就明文可见,标它没有意义且会误导)
    for k in revealable:
        assert reg.REGISTRY[k].sensitive, f"{k} 标了 revealable 却不是 sensitive"


def test_reveal_endpoint_has_all_four_gates():
    """会话 + CSRF + 授予面 + 审计,一个都不能少。"""
    src = py_code(APP / "admin_api.py")
    i = src.index('@router.post("/config/reveal")')
    seg = src[i:src.index('@router.get("/jfvip/overview")')]
    assert "_guard_write(request)" in seg, "揭示端点缺会话/CSRF 闸"
    assert "revealable" in seg, "缺授予面判断"
    assert "not_revealable" in seg
    assert "audit_add" in seg and "config_reveal" in seg, "揭示未落审计"
    # ★ 审计里只能有指纹,**绝不能有明文** —— 那等于把密钥又抄进另一个库
    j = seg.index("audit_add")
    call = seg[j:j + 300]
    assert "fingerprint(val)" in call, "审计未用指纹"
    assert '"value": val' not in call and "val}" not in call, "审计里出现了明文"
    # 审计必须在返回之前(这是「谁看过」的唯一记录)
    assert seg.index("audit_add") < seg.rindex("return {\"ok\": True"), \
        "审计写在返回之后 —— 提前 return 的分支会漏记"


def test_reveal_does_not_leak_via_the_normal_config_channels():
    """★ 揭示是**独立通道**。常规的 schema / values 拉取必须仍然掩码 ——
    否则「按需揭示」就成了摆设,密钥照样随每一次配置页拉取走一遍网络。"""
    src = py_code(APP / "config_registry.py")
    i = src.index("def public_schema")
    seg = src[i:i + 1600]
    assert "mask(f, f.default)" in seg, "schema 的 default 未走掩码"
    # reveal_sensitive 只能被揭示端点调用,不能混进常规读取路径
    api = py_code(APP / "admin_api.py")
    assert api.count("reveal_sensitive") == 1, \
        "reveal_sensitive 出现在不止一处 —— 明文可能混进了常规通道"


def test_frontend_reveal_never_caches_the_plaintext():
    """每次都打后端,不缓存 —— 缓存等于把明文留在前端内存里,
    而这个功能的全部意义就是「要看的时候才有」。"""
    js = js_code(ADMIN_JS)
    i = js.index("async function revealSecret(")
    seg = js[i:i + 2000]
    assert "'/config/reveal'" in seg, "前端未走揭示端点"
    assert "本次查看已记入审计" in seg, "没告诉运维这次查看会被记录"
    assert "rvCopy" in seg and "execCommand" in seg, "缺复制或兜底"
    # 值为 None 时必须诚实说明,而不是显示空串让人以为密钥是空的
    assert "d.value == null" in seg, "未处理「本台没有明文」的情形"
    # 不得把明文塞进 window/localStorage 之类
    for bad in ("localStorage", "sessionStorage", "window._", "globalThis"):
        assert bad not in seg, f"揭示实现里出现了持久化痕迹 {bad}"


# ── 揭示端点的**行为**测试 ───────────────────────────────────────────────────
# ★ 为什么必须有这一组:第五轮变异验证实测发现,纯静态的
#   `assert "revealable" in seg` / `assert "audit_add" in seg` **抓不住**把闸包进
#   `if False:` 的变异 —— 死代码里的字符串照样命中。闸是不是真的在起作用,
#   只有打真实 HTTP 才知道。(同一教训在本文件 §G 的 gbk 元测试上也出现过。)
@pytest.fixture
def reveal_wired(monkeypatch):
    from app import admin_api, admin_auth, config_center as cfgc
    from app import web
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "pw-for-tests")
    monkeypatch.delenv("STA_ADMIN_IP_ALLOW", raising=False)
    admin_auth._reset_for_tests()
    r = _fake_redis()

    class _DB:
        rows: list = []

        async def audit_add(self, ts, actor, action, detail, rev):
            self.rows.append((actor, action, detail))

    db = _DB()
    db.rows = []
    monkeypatch.setattr(admin_api, "_ST",
                        type("S", (), {"db": db,
                                       "bus": type("B", (), {"r": r})()})(),
                        raising=False)
    cookie, csrf = admin_auth.issue_session()
    yield {"app": web.app, "db": db, "redis": r, "K": cfgc.K_SENSITIVE,
           "H": {"X-Admin-Session": cookie, "X-Admin-CSRF": csrf},
           "H_nocsrf": {"X-Admin-Session": cookie}}
    admin_auth._reset_for_tests()


@pytest.mark.asyncio
async def test_asgi_reveal_returns_plaintext_and_audits_without_it(reveal_wired):
    """明文回给调用者,但**审计里只留指纹** —— 审计是另一个库、长期保存,
    把密钥抄进去等于多一份可被拖走的资产。"""
    secret = "0f3a" * 16
    await reveal_wired["redis"].hset(reveal_wired["K"],
                                     mapping={"userauth.jf_card_api_key": secret})
    async with _api_client(reveal_wired["app"]) as c:
        r = await c.post(_ADM + "/config/reveal", headers=reveal_wired["H"],
                         json={"key": "userauth.jf_card_api_key"})
    assert r.status_code == 200 and r.json()["value"] == secret, r.text
    assert r.json()["auditOk"] is True
    rows = reveal_wired["db"].rows
    assert len(rows) == 1 and rows[0][1] == "config_reveal", rows
    assert secret not in str(rows[0][2]), "审计里出现了明文"
    assert "fp" in rows[0][2], "审计里没有指纹 —— 无从核对看到的是哪一把"


@pytest.mark.asyncio
async def test_asgi_reveal_refuses_non_revealable_secrets(reveal_wired):
    """★ 授予面必须真的生效。auth.ticket 是 sensitive 但**不是** revealable ——
    上游签发的凭据,本台没有交付责任,不该多开一个读取口子。"""
    await reveal_wired["redis"].hset(reveal_wired["K"],
                                     mapping={"auth.ticket": "upstream-secret"})
    async with _api_client(reveal_wired["app"]) as c:
        a = await c.post(_ADM + "/config/reveal", headers=reveal_wired["H"],
                         json={"key": "auth.ticket"})
        b = await c.post(_ADM + "/config/reveal", headers=reveal_wired["H"],
                         json={"key": "userauth.jf_order_rate_hourly"})
        d = await c.post(_ADM + "/config/reveal", headers=reveal_wired["H"],
                         json={"key": "no.such.key"})
    assert a.status_code == 403 and a.json()["error"] == "not_revealable", a.text
    assert "upstream-secret" not in a.text, "被拒的响应里泄漏了明文"
    assert b.status_code == 403, "非敏感项也不该走这条通道"
    assert d.status_code == 400 and d.json()["error"] == "unknown_key"
    assert not reveal_wired["db"].rows, "被拒的请求不该产生审计噪音"


@pytest.mark.asyncio
async def test_asgi_reveal_needs_session_and_csrf(reveal_wired):
    await reveal_wired["redis"].hset(reveal_wired["K"],
                                     mapping={"userauth.jf_card_api_key": "x" * 64})
    async with _api_client(reveal_wired["app"]) as c:
        a = await c.post(_ADM + "/config/reveal", json={"key": "userauth.jf_card_api_key"})
        b = await c.post(_ADM + "/config/reveal", headers=reveal_wired["H_nocsrf"],
                         json={"key": "userauth.jf_card_api_key"})
    assert a.status_code == 401, a.text
    assert b.status_code == 403 and b.json()["error"] == "csrf", b.text
    assert "xxxx" not in a.text and "xxxx" not in b.text


@pytest.mark.asyncio
async def test_asgi_reveal_is_honest_when_it_has_no_plaintext(reveal_wired):
    """Redis 重启会丢真值(敏感值刻意不落 PG)。此时必须**说清楚**,
    而不是回一个空串让运维以为「密钥是空的」——那会让他去重设一把。"""
    async with _api_client(reveal_wired["app"]) as c:
        r = await c.post(_ADM + "/config/reveal", headers=reveal_wired["H"],
                         json={"key": "userauth.jf_card_api_key"})
    assert r.status_code == 200 and r.json()["value"] is None
    assert "环境变量" in r.json().get("message", ""), "没有告诉运维去哪里找"


# ══════════════════════════════════════════════════════════════════════════════
# L. 第六轮:前端测试基础设施(五轮里最严重的一次遗漏)
# ------------------------------------------------------------------------------
# ★ 项目**自带**一整套前端验证:四个 jsdom 脚本 + 一个真实 Chromium 布局脚本
#   (admin_jfvip_browser.py,其 docstring 原话:「jsdom 不做布局…是唯一一块始终
#   验不到的盲区」)。我连改五轮 admin.js,**一次都没跑过**。
#
#   补上之后立刻抓到一个**只有真实浏览器测得出来**的缺陷:genSecret 派发的是
#   `input` 事件,而参数卡的暂存监听的是 `change` —— 生成的密钥根本没进暂存。
#   运维会:生成 → 看到值 → 点「应用」→ 什么也没发生 → 拿这把密钥去配发卡平台
#   → 每次调用 401,而管理台屏幕上零迹象。
#   jsdom 用例当时只断言 inp.value 被写入 ⇒ 绿;静态扫描更看不到。
# ══════════════════════════════════════════════════════════════════════════════
SCRIPTS = APP.parent / "scripts"


def test_frontend_verification_scripts_exist():
    """项目既有的前端脚本一个都不能丢,新增的两个也必须在。"""
    for f in ("admin_jfvip_jsdom.js", "admin_reg_jsdom.js", "frontend_it_jsdom.js",
              "frontend_jfvip_jsdom.js", "frontend_reg_jsdom.js", "frontend_sso_jsdom.js",
              "admin_jfvip_browser.py",
              "admin_secret_jsdom.js", "admin_secret_browser.py"):
        assert (SCRIPTS / f).is_file(), f"前端验证脚本缺失:{f}"


def test_generated_secret_is_staged_via_change_event():
    """★ 必须派发 **change**。参数卡的暂存逻辑监听的是 change
    (`el.addEventListener('change', …)`),派发 input 等于没暂存 —— 而输入框里
    看得见值、弹窗里看得见明文,屏幕上零迹象。

    这条在 Python 侧也钉一份:jsdom / 浏览器脚本不进 pytest,而这个缺陷的代价
    (运维配了一把从未生效的密钥,发卡平台全线 401)值得多一道守卫。
    """
    js = js_code(ADMIN_JS)
    i = js.index("async function genSecret(")
    seg = js[i:js.index("\ndocument.addEventListener('click'", i)]
    assert "new Event('change'" in seg, "生成后未派发 change —— 密钥不会进入暂存"
    assert "new Event('input'" not in seg, (
        "仍在派发 input —— 参数卡监听的是 change,input 不触发暂存")
    # 参数卡那一侧确实监听 change(判据的另一半,防将来那边改了这边没跟)
    assert "el.addEventListener('change'" in js, \
        "参数输入框不再监听 change —— genSecret 的事件类型需同步复核"


def test_secret_browser_script_checks_layout_not_just_behavior():
    """真实浏览器脚本必须验**布局**(jsdom 验不到的那一块),而不只是重复行为断言。"""
    src = (SCRIPTS / "admin_secret_browser.py").read_text(encoding="utf-8")
    for token in ("bounding_box", "scrollWidth", "未被按钮挤塌", "未掉行",
                  "触控目标", "pcard.staged"):
        assert token in src, f"浏览器脚本缺少布局判据:{token}"
    # 多视口:单一视口测不出「某个宽度带上掉行」这类失效带
    assert src.count("(") and "390" in src and "1440" in src, "未覆盖多视口"


def test_every_frontend_script_is_registered_in_the_docs():
    """★ 元测试:`scripts/` 下每一个前端验证脚本都必须出现在 JFVIP-SYSTEM.md 的
    「整机验证轨道」表里。

    第六轮的教训不是"我懒得跑",而是**我不知道它们存在** —— 项目自带六个 jsdom
    脚本和一个真实 Chromium 脚本,我改了五轮 admin.js 一次都没跑。第七轮我又
    新增了两个;如果不登记,下一个人会重蹈覆辙。
    「有覆盖却没人跑」与「没有覆盖」在后果上等价,而前者更有欺骗性。
    """
    # ★ 扫**全部**根级文档,而不是手列三份。初版只列了 JFVIP/REGISTER/SSO 三份,
    #   而 frontend_it_jsdom.js 属登录系统、登记在 LOGIN-SYSTEM.md —— 扫描面不全
    #   等于断言不成立(它会把一个已登记的脚本报成未登记,或反过来漏掉真的没登记的)。
    #   这与本文件多次记下的教训同源:判据要覆盖全集,不能手列。
    known = "".join(f.read_text(encoding="utf-8") for f in sorted(ROOT.glob("*.md")))
    miss = []
    for f in sorted(SCRIPTS.glob("*jsdom.js")) + sorted(SCRIPTS.glob("*browser.py")):
        if f.name not in known:
            miss.append(f.name)
    assert not miss, (
        f"以下前端验证脚本在任何文档里都没登记,等于没人会跑:{miss}")


def test_obfuscated_build_is_covered_by_the_same_scripts():
    """★ 「源码全绿 ≠ 产物全绿」。build-deploy.mjs 对此有前科
    (splitStrings/numbersToExpressions 改坏过 fetch 拦截 + 正则路由)。

    两个新脚本必须都支持对混淆产物再跑一遍,否则交付形态是零覆盖的。
    """
    js = (SCRIPTS / "admin_secret_jsdom.js").read_text(encoding="utf-8")
    assert "--js" in js and "--html" in js, "jsdom 脚本不支持指向混淆产物"
    py = (SCRIPTS / "admin_secret_browser.py").read_text(encoding="utf-8")
    assert "--root" in py, "浏览器脚本不支持 --root dist"
    doc = (ROOT / "JFVIP-SYSTEM.md").read_text(encoding="utf-8")
    assert "源码全绿 ≠ 产物全绿" in doc or "源码全绿" in doc, \
        "文档未提醒对混淆产物再跑一遍"


def test_npm_no_save_discipline_is_written_where_people_will_read_it():
    """裸 `npm i jsdom` 会让目标机 `npm ci` 失败、整个镜像重建中断(真实事故)。
    纪律必须写在**运行脚本的人会看到的地方**,而不只是在那条回归钉的 docstring 里
    —— 4.2.9 开发期我就是没读到而复犯了一次。"""
    js = (SCRIPTS / "admin_secret_jsdom.js").read_text(encoding="utf-8")
    assert "--no-save" in js, "新脚本头注释未写明 --no-save"
    doc = (ROOT / "JFVIP-SYSTEM.md").read_text(encoding="utf-8")
    assert "--no-save" in doc, "文档验收表未写明 --no-save"


# ══════════════════════════════════════════════════════════════════════════════
# M. 第八轮:跨进程幂等原子性(推诿了四轮的那一项)
# ══════════════════════════════════════════════════════════════════════════════
_REDIS_URL = os.environ.get("STA_TEST_REDIS_URL", "redis://127.0.0.1:6380/0")


def _redis_up() -> bool:
    try:
        import redis
        redis.from_url(_REDIS_URL, socket_connect_timeout=1).ping()
        return True
    except Exception:                       # noqa: BLE001
        return False


needs_redis = pytest.mark.skipif(
    not _redis_up(), reason=f"需要真 Redis({_REDIS_URL});跨进程原子性验证需要它")


@needs_redis
def test_idem_is_atomic_across_processes():
    """★ 推诿了四轮的验证,第八轮兑现。

    第四轮实测:单进程 asyncio + fakeredis **证明不了**原子性 —— 把 SET NX 换成
    「先 GET 再 SET」,50 路并发仍只有 1 路拿到 new(await 之间不让出)。当时只能补
    静态钉,并如实写明「多进程行为仍是逻辑推演」。

    本用例跑 `scripts/idem_multiprocess.py --mutate`:N 个**独立解释器进程**
    (不是 fork —— fork 会继承事件循环与连接池,那测的仍是一个进程内的事)各自连
    真 Redis 抢同一个幂等键,并对**非原子实现**跑同样一轮做反证。

    真机实测(8 进程 × 25 协程 = 200 路):
        SET NX          → new = 1
        先 GET 再 SET    → new = 25~69   ⇒ 会发出那么多**批**重复卡密
    """
    import subprocess
    r = subprocess.run(
        [sys.executable, str(SCRIPTS / "idem_multiprocess.py"), "--mutate",
         "--url", _REDIS_URL, "--procs", "6", "--coros", "20"],
        capture_output=True, text=True, timeout=300)
    assert r.returncode == 0, f"跨进程原子性验证失败:\n{r.stdout}\n{r.stderr}"
    assert "现行实现(SET NX):new=1" in r.stdout, r.stdout
    # 反证必须真的测出差异 —— 否则上面那条「通过」只是并发压力不够
    import re as _re
    m = _re.search(r"反证\(先 GET 再 SET\):new=(\d+)", r.stdout)
    assert m and int(m.group(1)) > 1, (
        f"反证没测出差异,说明并发压力不足,上面那条「通过」不可信:\n{r.stdout}")


def test_multiprocess_script_is_registered_and_skips_gracefully():
    """脚本必须被文档登记(第七轮的教训),且无 Redis 时优雅跳过、不阻断主干
    (与本仓既有的真库/真 Redis 用例同款约定)。"""
    src = (SCRIPTS / "idem_multiprocess.py").read_text(encoding="utf-8")
    assert "[跳过]" in src and "_reachable" in src, "缺少「不可达即跳过」的约定"
    assert "--mutate" in src, "没有反证开关 —— 断言不做变异验证等于没断言"
    assert "fork" in src, "未说明为何用独立解释器而不是 fork"
    known = "".join(f.read_text(encoding="utf-8") for f in sorted(ROOT.glob("*.md")))
    assert "idem_multiprocess.py" in known, \
        "跨进程验证脚本没在任何文档登记 —— 等于没人会跑(第七轮同款漏项)"


def test_multiworker_script_refuses_to_run_on_a_busy_port():
    """★ 本脚本自身的缺陷回归钉(第九轮实测踩到)。

    端口若被**上一轮残留**的服务占着,新 uvicorn 绑定失败,而健康检查会从那个
    陈旧服务拿到 200 ⇒ 脚本把测试打在了一个**用着别的配置**的进程上。
    我就是这样得出过一条「限频完全失效」的**假结论**(实为在 rate=0 的残留服务上
    测 cap=5)。测试工具产出假结论,比没有测试更糟。
    """
    src = (SCRIPTS / "multiworker_http.py").read_text(encoding="utf-8")
    assert "端口" in src and "已被占用" in src, "缺少端口占用前置检查"
    assert "p.poll() is not None" in src, "未检测子进程提前退出(绑定失败会空等 60s)"
    assert "假结论" in src, "没把这次踩坑记在脚本里 —— 下一个人会再踩一次"
    known = "".join(f.read_text(encoding="utf-8") for f in sorted(ROOT.glob("*.md")))
    assert "multiworker_http.py" in known, "多 worker 脚本没在任何文档登记"
