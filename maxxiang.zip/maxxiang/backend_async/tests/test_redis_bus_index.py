"""
test_redis_bus_index.py — 房→任务反向索引正确性(真实 Redis)
================================================================================
索引(rt:{room} + sched:rooms)是「删房 O(1) / janitor 自愈不扫全队列」的基础,
必须在任务生命周期各阶段保持一致。本测试覆盖易错分支:
  · schedule 建立索引;ack 部分任务时房仍在索引;ack 最后一个任务时房自动移出;
  · 租约式 claim(ZADD 续租)**不破坏**索引(成员仍在,语义正确);
  · remove_room / remove_rooms_bulk 经索引清净;schedule_spread 铺开且建索引。
"""
import os
import sys
from collections import Counter
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.redis_bus import (K_ROOM_TASKS, K_SCHED, K_SCHED_ROOMS, RedisBus,  # noqa: E402
                           task_award, task_mainpage)

REDIS_URL = os.environ.get("STA_TEST_REDIS_URL", "redis://127.0.0.1:6379/15")


def _redis_available() -> bool:
    try:
        import redis
        redis.from_url(REDIS_URL).ping()
        return True
    except Exception:
        return False


pytestmark = pytest.mark.skipif(not _redis_available(),
                                reason="需要 Redis(设 STA_TEST_REDIS_URL)")


@pytest.mark.asyncio
async def test_schedule_and_ack_maintain_index():
    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()
    await bus.schedule(task_mainpage("100"), 1000)
    await bus.schedule(task_award("100", 5), 1200)
    await bus.schedule(task_mainpage("200"), 1100)

    assert await bus.scheduled_rooms() == {"100", "200"}
    assert set(await bus.r.smembers(K_ROOM_TASKS.format(room="100"))) == {"mp|100", "aw|100|5"}
    assert await bus.r.zcard(K_SCHED) == 3

    # ack 部分任务:房仍在索引
    await bus.ack(task_mainpage("100"))
    assert await bus.scheduled_rooms() == {"100", "200"}
    assert set(await bus.r.smembers(K_ROOM_TASKS.format(room="100"))) == {"aw|100|5"}

    # ack 最后一个任务:房自动移出,rt 键清空
    await bus.ack(task_award("100", 5))
    assert await bus.scheduled_rooms() == {"200"}
    assert await bus.r.scard(K_ROOM_TASKS.format(room="100")) == 0
    assert not await bus.r.sismember(K_SCHED_ROOMS, "100")
    await bus.close()


@pytest.mark.asyncio
async def test_lease_claim_does_not_break_index():
    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()
    await bus.schedule(task_mainpage("200"), 0)   # 立即到期
    claimed = await bus.claim_due(10, 15000)
    assert task_mainpage("200") in claimed
    # 租约续租未 ack → 成员仍在,索引不变
    assert await bus.scheduled_rooms() == {"200"}
    assert set(await bus.r.smembers(K_ROOM_TASKS.format(room="200"))) == {"mp|200"}
    await bus.close()


@pytest.mark.asyncio
async def test_remove_room_uses_index():
    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()
    await bus.add_room("200", "200")
    await bus.schedule(task_mainpage("200"), 1)
    await bus.schedule(task_award("200", 9), 2)
    await bus.remove_room("200")
    assert await bus.r.zcard(K_SCHED) == 0
    assert await bus.scheduled_rooms() == set()
    assert await bus.r.scard(K_ROOM_TASKS.format(room="200")) == 0
    await bus.close()


@pytest.mark.asyncio
async def test_remove_rooms_bulk():
    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()
    rids = [str(500 + i) for i in range(100)]
    await bus.add_rooms_bulk([(r, r) for r in rids])
    for r in rids:
        await bus.schedule(task_mainpage(r), 1)
    assert await bus.r.zcard(K_SCHED) == 100
    await bus.remove_rooms_bulk(rids)
    assert await bus.r.zcard(K_SCHED) == 0
    assert await bus.scheduled_rooms() == set()
    assert len(await bus.active_rooms()) == 0
    await bus.close()


@pytest.mark.asyncio
async def test_schedule_spread_window_and_index():
    bus = RedisBus(REDIS_URL)
    await bus.r.flushdb()
    base = 10_000_000
    members = [task_mainpage(str(300000 + i)) for i in range(5000)]
    await bus.schedule_spread(members, base, 20000)
    assert await bus.r.zcard(K_SCHED) == 5000
    assert len(await bus.scheduled_rooms()) == 5000
    scores = await bus.r.zrange(K_SCHED, 0, -1, withscores=True)
    lo = min(s for _, s in scores)
    hi = max(s for _, s in scores)
    assert lo == base
    assert 19000 <= (hi - lo) <= 20000
    # 无单毫秒堆积过 5%
    hottest = Counter(int(s) for _, s in scores).most_common(1)[0][1]
    assert hottest < 5000 * 0.05
    await bus.close()
