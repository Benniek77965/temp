"""
test_curated_idle.py — curated-idle(3.7.0)空闲策展房降级:单元/行为测试
================================================================================
分四层(与 test_histmode / test_histmode_janitor / test_histmode_web 同谱系):
  · 纯函数:curated_idle_split 的播种/判闲/冷跳过/边界/确定序;
  · RedisBus(fakeredis 真件):访问戳 GT 只进不退、NX 播种不覆盖、冷标往返、
    「冷标 ⊆ 活跃名录」删房不变量、观众守卫 NUMSUB、扫描锁节拍、异常回退语义;
  · Worker(直接驱动单事件,不跑泵):四闸统一判据 _dormant 的布尔矩阵、冷房 mp
    有机改排 hs(零上游调用)、开关关闭时冷标**惰性**、退出分支清冷标、
    _curated_idle_sweep 的 enforce / 观众否决 / shadow / 关闭自愈 / 锁节拍;
  · janitor 真协程单遍(熄火式睡眠夹具,test_histmode_janitor 同款):证明**接线**
    —— 真 janitor 确实调用了扫描,且冷房丢任务时自愈起点是 hs 而非 mp;
  · Web(monkeypatch web.ST + 直调端点):真实访问唤醒冷房(monitor/add 转正同款
    序列)、passive=1 与 profile **不算访问**(前端启动期头像回填实证)、5s 节流、
    双开关关闭时读路径零 Redis 写(契约⑪ 姿态)、误降计数(falseWake)。
被测对象全部走真实 RedisBus 类 —— 新增 bus 方法对 sims/其余测试自动可用。
"""
from __future__ import annotations

import random
import time

import pytest

from app.scheduler import curated_idle_split


# ══ 一、纯函数:降级判定前半(年龄切分;观众守卫在调用方) ═══════════════════════
def test_split_seed_and_candidates():
    now = 10_000_000
    rooms = ["30", "10", "20", "40", "50"]
    la = {"10": now - 1_800_000,     # 恰达阈 → 候选(≥ 语义,与注册表闭区间一致)
          "20": now - 1_799_999,     # 差 1ms → 不候选
          "30": now - 3_600_000,     # 深度空闲 → 候选
          "50": "not-a-number"}      # 坏时戳 → 按「年龄未知」,只播种
    cold = {"40"}                    # 已冷 → 任何输出都不出现(已在目标态)
    to_seed, cands = curated_idle_split(now, rooms, la, cold, 1_800_000)
    assert to_seed == ["50"]                       # "40" 已冷,不播种
    assert cands == ["10", "30"]                   # 排序确定(batch 截断可复现)
    # 无访问记录 → 只播种、**绝不判闲**(年龄未知不降级);空输入安全
    assert curated_idle_split(now, ["7"], {}, set(), 1_800_000) == (["7"], [])
    assert curated_idle_split(now, [], None, None, 1_800_000) == ([], [])


def test_split_after_clamp_and_purity():
    """坏输入不崩溃、语义单调;纯函数不碰 Redis(观众守卫留在调用方)。"""
    now = 1_000_000
    _, cands = curated_idle_split(now, ["1"], {"1": now}, set(), -5)
    assert cands == ["1"]                          # after 负值钳 0 → 立即候选
    # 全冷时无候选、无播种
    assert curated_idle_split(now, ["1", "2"], {}, {"1", "2"}, 0) == ([], [])


# ══ 二、RedisBus 行为(fakeredis 真件) ══════════════════════════════════════
def _bus():
    import fakeredis.aioredis
    from app.redis_bus import RedisBus
    b = RedisBus("redis://x")
    b.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    return b


@pytest.mark.asyncio
async def test_bus_touch_gt_and_seed_nx():
    import app.redis_bus as rb
    bus = _bus()
    assert rb.K_ROOMS_COLD == "rooms:cold"          # 键名钉死(运维/观测口径)
    assert rb.K_LAST_ACCESS == "rooms:lastaccess"
    # GT:只进不退 —— 迟到的旧访问绝不回拨时戳(否则活跃房会被误判成空闲)
    assert await bus.touch_and_check_cold("1", 1000) is None
    await bus.touch_and_check_cold("1", 500)
    assert (await bus.last_access_map(["1"]))["1"] == 1000
    await bus.touch_and_check_cold("1", 2000)
    assert (await bus.last_access_map(["1"]))["1"] == 2000
    # NX 播种:绝不覆盖真实访问;只给「从无记录」的房落当下
    await bus.touch_rooms_nx(["1", "2"], 50)
    assert await bus.last_access_map(["1", "2", "3"]) == {"1": 2000, "2": 50}
    # 冷标往返:mark → touch 顺带取 since → clear 返回 since 且幂等
    await bus.mark_cold_bulk(["2"], 7777)
    assert await bus.is_cold("2") is True
    assert await bus.touch_and_check_cold("2", 3000) == 7777
    assert await bus.cold_clear("2") == 7777
    assert await bus.cold_clear("2") is None
    assert await bus.is_cold("2") is False
    # HSETNX:已冷房 since 不回拨(冷龄只增不减 → falseWake 判定不撒谎)
    await bus.mark_cold_bulk(["9"], 100)
    await bus.mark_cold_bulk(["9"], 999)
    assert await bus.cold_clear("9") == 100
    await bus.mark_cold_bulk(["8"], 1)
    await bus.cold_clear_bulk(["8", "absent"])      # 批量清含不存在项:安全
    assert await bus.cold_members() == set()


@pytest.mark.asyncio
async def test_bus_remove_room_clears_cold_invariant():
    """不变量:冷标/访问戳 ⊆ 活跃名录 —— 删房(单删/批删)即清,防僵尸标撒谎
    (hist:lastok 的同款纪律;僵尸冷标会让状态页 coldCount 永久虚高)。"""
    import app.redis_bus as rb
    bus = _bus()
    await bus.add_rooms_bulk([("1", "1"), ("2", "2")])
    await bus.mark_cold_bulk(["1", "2"], 42)
    await bus.touch_rooms_nx(["1", "2"], 42)
    await bus.remove_room("1")
    assert await bus.is_cold("1") is False
    assert await bus.last_access_map(["1"]) == {}
    await bus.remove_rooms_bulk(["2"])
    assert await bus.cold_members() == set()
    assert int(await bus.r.zcard(rb.K_LAST_ACCESS) or 0) == 0


@pytest.mark.asyncio
async def test_bus_draw_subscribers_and_sweep_lock():
    """观众守卫的数据源:draws:{room} 订阅数(全库唯一订阅方是 web SSE 转发,
    信号纯净);扫描锁 SET NX EX = 跨副本互斥兼节拍。"""
    bus = _bus()
    ps = bus.r.pubsub()
    await ps.subscribe(bus.draw_channel("321"))
    assert await bus.draw_subscribers(["321", "654"]) == {"321": 1, "654": 0}
    assert await bus.draw_subscribers([]) == {}
    await ps.aclose()
    assert await bus.cold_sweep_try_lock(60) is True
    assert await bus.cold_sweep_try_lock(60) is False    # 锁存续:同分钟第二扫免谈


@pytest.mark.asyncio
async def test_is_cold_never_raises():
    """判不出来必须回 False = 按**活跃策展房**走 —— 与 is_discovered 同一铁律:
    绝不因一次 Redis 抖动把用户正在看的房降级 / 停掉它的预测。"""
    from app.redis_bus import RedisBus

    class _Boom:
        async def hexists(self, *a):
            raise RuntimeError("redis down")

    bus = RedisBus.__new__(RedisBus)
    bus.r = _Boom()                                  # type: ignore[assignment]
    assert await bus.is_cold("321") is False
    assert await bus.cold_members() == set()         # hkeys 亦炸 → 空集(视同无冷房)


# ══ 三、Worker 行为(fakeredis;直接驱动单事件,不跑泵) ══════════════════════
def _world(ci_enabled=True, shadow=False, hist_enabled=True, after_s=1800):
    import fakeredis.aioredis
    from app import worker as wk
    from app.settings import Settings
    from scripts.sim_history_gap import STEP, T0, FakeDB, SimUpstream, VClock

    clock = VClock(T0 + 10 * STEP + 2_000)
    import app.redis_bus as rb
    rb.now_ms = clock                                # conftest autouse 负责还原
    wk.now_ms = clock
    s = Settings()
    s.prediction = {"enabled": False}
    s.histmode.enabled = hist_enabled
    s.histmode.interval_s = 300
    s.histmode.curated_idle_enabled = ci_enabled
    s.histmode.curated_idle_shadow = shadow
    s.histmode.curated_idle_after_s = after_s
    w = wk.Worker(s)
    w.bus.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    up = SimUpstream(clock)
    db = FakeDB(); db._clock = clock
    w.up, w.db = up, db
    return w, up, db, clock, s


@pytest.mark.asyncio
async def test_dormant_matrix():
    """四闸统一判据的布尔矩阵:发现房恒 True(3.4.5 与 histmode 无关);冷标**仅
    在双开时**生效 —— 任一开关关闭即完全惰性(契约⑪:与旧 is_discovered 逐命令
    等价,残留冷标不影响任何闸)。"""
    import app.redis_bus as rb
    w, _up, _db, clock, s = _world(ci_enabled=True)
    disc, coldr, plain = "111", "222", "333"
    await w.bus.r.hset(rb.K_ROOMS_DISCOVERED, disc, str(clock.t))
    await w.bus.mark_cold_bulk([coldr], clock.t)
    assert await w._dormant(disc) is True
    assert await w._dormant(coldr) is True
    assert await w._dormant(plain) is False
    s.histmode.curated_idle_enabled = False          # 关子开关 → 冷标惰性
    assert await w._dormant(coldr) is False
    s.histmode.curated_idle_enabled = True
    s.histmode.enabled = False                       # 关总开关 → 同样惰性
    assert await w._dormant(coldr) is False
    assert await w._dormant(disc) is True            # 发现闸不受 histmode 开关影响


@pytest.mark.asyncio
async def test_cold_room_mp_migrates_organically():
    """冷策展房复用 3.5.0 迁移入口:mp 拍改排 hs(满窗 U(0,T) 抖动),**不打上游**
    —— 降级不需要任何新迁移机器,janitor 只打标。子开关关闭时冷标惰性,mp 照旧
    直通实时管线(逐字节旧行为)。"""
    import app.redis_bus as rb
    from app.redis_bus import task_hist, task_mainpage
    w, up, _db, clock, _s = _world(ci_enabled=True)
    room = "2678075"
    await w.bus.add_rooms_bulk([(room, room)])
    await w.bus.mark_cold_bulk([room], clock.t)
    random.seed(3)
    await w.bus.schedule(task_mainpage(room), clock.t)
    for m in await w.bus.claim_due(10, 10 ** 12):
        await w._handle(m)
    assert up.calls["mp"] == 0                       # 短路于 _handle_mainpage 之前
    z = dict(await w.bus.r.zrange(rb.K_SCHED, 0, -1, withscores=True))
    assert task_hist(room) in z and task_mainpage(room) not in z
    assert 0 <= int(z[task_hist(room)]) - clock.t <= 300_000 + 1   # 满窗铺开

    # 子开关关闭:同样的冷标,mp 直通实时管线(上游 MainPage 被真打一次)
    w2, up2, _db2, clock2, _s2 = _world(ci_enabled=False)
    await w2.bus.add_rooms_bulk([(room, room)])
    await w2.bus.mark_cold_bulk([room], clock2.t)
    await w2.bus.schedule(task_mainpage(room), clock2.t)
    for m in await w2.bus.claim_due(10, 10 ** 12):
        await w2._handle(m)
    assert up2.calls["mp"] == 1


@pytest.mark.asyncio
async def test_hist_exit_branch_clears_cold():
    """唤醒 / 回滚殊途同归:hs 撞退出分支(_dormant=False)必清冷标 + 改排 mp
    —— 覆盖「唤醒清标那一步恰逢 Redis 抖动」「开关被运维关掉」的残留路径。"""
    import app.redis_bus as rb
    from app.redis_bus import task_hist, task_mainpage
    w, _up, _db, clock, _s = _world(ci_enabled=False)     # 子开关已关 → 冷标惰性
    room = "2678075"
    await w.bus.add_rooms_bulk([(room, room)])
    await w.bus.mark_cold_bulk([room], clock.t - 60_000)
    await w._handle_hist(room, task_hist(room))
    assert await w.bus.r.hexists(rb.K_ROOMS_COLD, room) == 0        # 冷标已清
    z = dict(await w.bus.r.zrange(rb.K_SCHED, 0, -1, withscores=True))
    assert task_mainpage(room) in z                                 # 有机回实时


@pytest.mark.asyncio
async def test_sweep_enforce_seeds_and_lock_beat():
    """enforce:空闲房降级、新房只播种、活跃房不动;锁节拍 = 同分钟内第二扫免谈。"""
    import app.redis_bus as rb
    w, _up, _db, clock, _s = _world(ci_enabled=True, shadow=False, after_s=300)
    idle, fresh, unknown = "1001", "1002", "1003"
    await w.bus.add_rooms_bulk([(r, r) for r in (idle, fresh, unknown)])
    await w.bus.r.zadd(rb.K_LAST_ACCESS, {idle: clock.t - 400_000,
                                          fresh: clock.t - 10_000})
    await w._curated_idle_sweep({idle, fresh, unknown})
    assert await w.bus.is_cold(idle) is True
    assert await w.bus.is_cold(fresh) is False                 # 未达龄
    assert await w.bus.is_cold(unknown) is False               # 年龄未知:只播种
    assert unknown in await w.bus.last_access_map([unknown])   # NX 播种落账
    st = await w.bus.histmode_stats()
    assert int(st["cold_would"]) == 1 and int(st["cold_demote"]) == 1
    # 锁未过期 → 第二扫直接返回:新变空闲的房本轮不被处理(全舰队 ≤1 扫/分钟)
    await w.bus.r.zadd(rb.K_LAST_ACCESS, {fresh: clock.t - 900_000})
    await w._curated_idle_sweep({idle, fresh, unknown})
    assert await w.bus.is_cold(fresh) is False


@pytest.mark.asyncio
async def test_sweep_audience_veto():
    """观众守卫:draws:{room} 有订阅(有人开着直播视图)→ 一票否决,连
    wouldDemote 都不记 —— 影子期的 gauge 也不该把在看的房算进去。"""
    import app.redis_bus as rb
    w, _up, _db, clock, _s = _world(ci_enabled=True, shadow=False, after_s=300)
    watched = "2001"
    await w.bus.add_rooms_bulk([(watched, watched)])
    await w.bus.r.zadd(rb.K_LAST_ACCESS, {watched: clock.t - 999_000})
    ps = w.bus.r.pubsub()
    await ps.subscribe(w.bus.draw_channel(watched))
    await w._curated_idle_sweep({watched})
    assert await w.bus.is_cold(watched) is False
    st = await w.bus.histmode_stats()
    assert int(st.get("cold_would", 0) or 0) == 0
    await ps.aclose()


@pytest.mark.asyncio
async def test_sweep_shadow_only_gauges():
    """shadow(灰度第一档):只把「本会降级的房集」写进 stats,绝不动作。"""
    w, _up, _db, clock, _s = _world(ci_enabled=True, shadow=True, after_s=300)
    import app.redis_bus as rb
    ghost = "3001"
    await w.bus.add_rooms_bulk([(ghost, ghost)])
    await w.bus.r.zadd(rb.K_LAST_ACCESS, {ghost: clock.t - 999_000})
    await w._curated_idle_sweep({ghost})
    assert await w.bus.is_cold(ghost) is False
    st = await w.bus.histmode_stats()
    assert int(st["cold_would"]) == 1 and "3001" in st["cold_would_sample"]
    assert int(st.get("cold_demote", 0) or 0) == 0


@pytest.mark.asyncio
async def test_sweep_disabled_selfheal_and_zero_touch():
    """关闭语义:见过开启的副本在锁内清残留冷标(其 hs 任务下一拍撞退出分支
    自行封尾切回);从未开启过的副本第一步即返回 —— 不拿锁、不碰任何冷标。"""
    w, _up, _db, clock, _s = _world(ci_enabled=False)
    w._ci_was_on = True                              # 模拟「运维刚把开关关掉」
    stale = "4001"
    await w.bus.add_rooms_bulk([(stale, stale)])
    await w.bus.mark_cold_bulk([stale], clock.t)
    await w.bus.histmode_set({"cold_would": 7, "cold_would_sample": '["x"]'})
    await w._curated_idle_sweep({stale})
    assert await w.bus.cold_members() == set()
    assert w._ci_was_on is False                     # 清完即熄:后续拍零开销
    st = await w.bus.histmode_stats()                # 复审 j:关断即 gauge 归零,
    assert int(st["cold_would"]) == 0                # 状态页不挂陈旧影子判定
    assert st["cold_would_sample"] == "[]"

    w2, _u2, _d2, clock2, _s2 = _world(ci_enabled=False)   # 从未开启
    await w2.bus.mark_cold_bulk(["5001"], clock2.t)
    await w2._curated_idle_sweep({"5001"})
    assert await w2.bus.is_cold("5001") is True      # 未触碰(惰性残留,对闸无害)


# ══ 四、janitor 真协程单遍(熄火式睡眠夹具;证明**接线**而非复刻逻辑) ═════════
@pytest.mark.asyncio
async def test_janitor_wires_sweep_and_cold_hs_selfheal(monkeypatch):
    """真 _janitor 跑恰一遍(test_histmode_janitor 同款夹具):
      ① 冷房「名录幸存、调度丢失」的自愈起点是 **hs**(补 mp 会让迁移入口多绕
         一圈,并把首拍相位挤回 3s 窗);普通策展房仍是 mp;
      ② janitor 确实调用了 _curated_idle_sweep —— 空闲房在同一遍里被打上冷标。
    降级挂 janitor(无条件运行)而非 discovery.reconcile:后者在
    discovery.enabled=false(纯策展部署,README 明示存在)时整条不跑。"""
    import app.redis_bus as rb
    import app.worker as wk
    from app.redis_bus import task_hist, task_mainpage
    from tests.test_histmode_web import _Star, _WideDB

    w, _up, _db, clock, s = _world(ci_enabled=True, shadow=False, after_s=300)
    w.db, w.star = _WideDB(), _Star()
    s.scheduler.janitor_interval_s = 2               # 两步睡眠 → 主体恰 1 遍

    calls = {"n": 0}
    real_sleep = wk.asyncio.sleep

    async def fake_sleep(sec):
        calls["n"] += 1
        if calls["n"] > 1:
            w._running = False
        await real_sleep(0)
    monkeypatch.setattr(wk.asyncio, "sleep", fake_sleep)

    coldr, idle = "9401", "9402"
    await w.bus.add_rooms_bulk([(coldr, coldr), (idle, idle)])
    await w.bus.mark_cold_bulk([coldr], clock.t)                  # 已冷 + 丢任务
    await w.bus.r.zadd(rb.K_LAST_ACCESS, {idle: clock.t - 400_000})   # 空闲 + 丢任务

    w._running = True
    await w._janitor()                               # 真协程,单遍后自然退出

    z = dict(await w.bus.r.zrange(rb.K_SCHED, 0, -1, withscores=True))
    # ① 分流:冷房补 hs(满窗铺开),普通策展房补 mp
    assert task_hist(coldr) in z and task_mainpage(coldr) not in z
    assert 0 <= int(z[task_hist(coldr)]) - clock.t <= 300_000
    assert task_mainpage(idle) in z and task_hist(idle) not in z
    # ② 扫描确实被 janitor 调用:空闲房本遍即被降级(其下一拍 mp 有机改排 hs)
    assert await w.bus.is_cold(idle) is True
    assert int((await w.bus.histmode_stats())["cold_demote"]) == 1
    assert calls["n"] == 2                           # 两步睡眠即熄火(恰 1 遍)


# ══ 五、Web 行为(monkeypatch web.ST + 直调端点;test_histmode_web 同款轻模式) ══
class _CIDb:
    """宽假件:history 回一条合法行 —— 避开 room_history 的「首见宽限」6s 等待
    (rows 非空即跳过);其余方法回中性值。db 不是被测对象。"""
    def __getattr__(self, name):
        async def _f(*a, **k):
            if name == "history":
                return [{"round_id": 1_800_000_000_000}]
            if name in ("history_days", "prediction_records"):
                return []
            if name == "pg_health_probe":
                return {}
            return None
        return _f


class _CIStar:
    async def canon(self, room):
        return str(room), True

    async def profile(self, room):
        return {"nickname": "n", "avatar": ""}


@pytest.fixture()
def ci_wired(monkeypatch):
    """挂真 bus / 宽 db / star;测后还原 settings.histmode(模块级单例,无自动
    还原)与进程内节流台账。"""
    import app.web as web
    from app.settings import settings as live
    b = _bus()
    st = type("ST", (), {})()
    st.bus, st.db, st.star = b, _CIDb(), _CIStar()
    monkeypatch.setattr(web, "ST", st)
    saved = (live.histmode.enabled, live.histmode.curated_idle_enabled,
             live.histmode.curated_idle_shadow, live.histmode.curated_idle_after_s)
    live.histmode.enabled = True
    live.histmode.curated_idle_enabled = True
    web._TOUCH_AT.clear()
    yield web, b, live
    (live.histmode.enabled, live.histmode.curated_idle_enabled,
     live.histmode.curated_idle_shadow, live.histmode.curated_idle_after_s) = saved
    web._TOUCH_AT.clear()


@pytest.mark.asyncio
async def test_web_real_access_wakes_cold_room(ci_wired):
    """真实访问 = monitor/add 转正同款唤醒序列:清冷标 + mp@now + hs@now(退出
    分支先封尾回填再改排 → 预测号随补链立即再生,零冷启动)。passive=1(既有
    「只读不拉起监控」约定)与 profile(启动期名录头像回填会打全量房)**不算访问**。"""
    import app.redis_bus as rb
    from app.redis_bus import task_hist, task_mainpage
    web, b, _live = ci_wired
    room = "2678075"
    now_ms = int(time.time() * 1000)
    await b.add_rooms_bulk([(room, room)])
    await b.mark_cold_bulk([room], now_ms - 30_000)        # 冷龄 30s

    # passive=1:跨房补拉 —— 不触碰(仍冷、无访问戳)
    await web.room_history(room, since=0, limit=3, passive="1", until=0)
    assert await b.is_cold(room) is True
    assert await b.last_access_map([room]) == {}
    # profile:不触碰(否则前端启动期回填头像会把整个名录唤醒 → 永远无房可判闲)
    await web.live_room_profile(room)
    assert await b.is_cold(room) is True
    assert await b.last_access_map([room]) == {}

    # 正常读:当场唤醒
    await web.room_history(room, since=0, limit=3, passive="", until=0)
    assert await b.is_cold(room) is False
    assert room in await b.last_access_map([room])
    z = dict(await b.r.zrange(rb.K_SCHED, 0, -1, withscores=True))
    assert task_mainpage(room) in z and task_hist(room) in z
    st = await b.histmode_stats()
    assert int(st["cold_promote"]) == 1
    assert int(st["cold_false_wake"]) == 1                 # 冷龄 30s < 120s:疑似误降

    # 5s 节流:窗内第二读不再打 Redis(正确性不依赖它 —— ZADD GT 本就幂等)
    hits = {"n": 0}
    orig = b.touch_and_check_cold

    async def _counted(rid, ts):
        hits["n"] += 1
        return await orig(rid, ts)
    b.touch_and_check_cold = _counted                      # type: ignore[assignment]
    await web.room_history(room, since=0, limit=3, passive="", until=0)
    assert hits["n"] == 0
    b.touch_and_check_cold = orig                          # type: ignore[assignment]


@pytest.mark.asyncio
async def test_web_other_hooks_and_deep_cold_no_false_wake(ci_wired):
    """其余读钩子(days / prediction / summary)同为真实访问;深度冷房醒来
    **不**计 falseWake(该计数是「阈值调得太激进」的信号,不该被正常唤醒污染)。"""
    web, b, _live = ci_wired
    now_ms = int(time.time() * 1000)
    for room, cold_since in (("801", now_ms - 600_000),     # 冷龄 10min:正常唤醒
                             ("802", now_ms - 600_000),
                             ("803", now_ms - 600_000)):
        await b.add_rooms_bulk([(room, room)])
        await b.mark_cold_bulk([room], cold_since)
    await web.room_history_days("801", limit=62)
    await web.room_prediction("802")
    await web.room_summary("803")
    assert await b.cold_members() == set()                  # 三个钩子各唤醒一个
    st = await b.histmode_stats()
    assert int(st["cold_promote"]) == 3
    assert int(st.get("cold_false_wake", 0) or 0) == 0      # 深度冷 → 非误降


@pytest.mark.asyncio
async def test_web_touch_noop_when_disabled(ci_wired):
    """双开关关闭:读路径**零 Redis 写**(契约⑪ 姿态)—— 冷标保持、无访问戳、
    不排任何任务。功能关掉后残留冷标对 web 完全惰性。"""
    import app.redis_bus as rb
    web, b, live = ci_wired
    live.histmode.curated_idle_enabled = False
    room = "2678075"
    await b.add_rooms_bulk([(room, room)])
    await b.mark_cold_bulk([room], 1_000)
    await web.room_history(room, since=0, limit=3, passive="", until=0)
    await web.room_prediction(room)
    await web.room_summary(room)
    assert await b.is_cold(room) is True
    assert await b.last_access_map([room]) == {}
    assert int(await b.r.zcard(rb.K_SCHED) or 0) == 0
    # 复审 F 补锁:ci 关时 monitor_add 也不写访问戳/不清冷标(禁用态零新增命令;
    # 残留标对闸惰性,重开后由读钩子 ≤20s 自愈 —— 语义见端点内注释)。

    class _Rq:
        headers: dict = {}

    resp = await web.monitor_add(_Rq(), room=room)
    assert not isinstance(resp, web.JSONResponse) or resp.status_code == 200, resp
    assert await b.is_cold(room) is True               # 标未被触碰
    assert await b.last_access_map([room]) == {}       # 戳未被写


# ══ 六、复审补锁(G1–G3 / H1–H2:全量自审发现的缺口,各配专用向量) ═══════════
@pytest.mark.asyncio
async def test_bus_prune_clears_lastaccess_and_touch_rooms_gt():
    """G2:回收发现房必清访问戳(用户直连看过的发现房 → 僵尸 zset 项纪律);
    冷标 hdel 纯防御对称。附 touch_rooms(GT 批量)语义:只进不退。"""
    import app.redis_bus as rb
    bus = _bus()
    await bus.add_rooms_bulk([("7001", "7001")])
    await bus.r.hset(rb.K_ROOMS_DISCOVERED, "7001", "1")
    await bus.touch_and_check_cold("7001", 5_000)          # 用户直连看过它
    await bus.discovered_prune_bulk(["7001"])
    assert await bus.last_access_map(["7001"]) == {}       # 回收即清
    assert int(await bus.r.zcard(rb.K_LAST_ACCESS) or 0) == 0
    # touch_rooms:GT 批量 —— 旧值不回拨、新值抬升、缺失即建
    await bus.touch_rooms(["a", "b"], 100)
    await bus.touch_rooms(["a"], 50)
    await bus.touch_rooms(["b", "c"], 200)
    assert await bus.last_access_map(["a", "b", "c"]) == \
        {"a": 100, "b": 200, "c": 200}


@pytest.mark.asyncio
async def test_monitor_add_wakes_cold_room(ci_wired, monkeypatch):
    """G1(单房):再添加既有冷策展房 = 「秒级起抓」契约必须兑现 —— 冷标清、
    访问戳置新、mp 不被迁移入口改排回轮询。执行端点真函数(guard/canon/known)。"""
    import app.redis_bus as rb
    web, b, live = ci_wired
    monkeypatch.delenv("STA_MONITOR_WRITE_TOKEN", raising=False)

    class _Req:
        headers: dict = {}

    room = "9310"
    await b.add_rooms_bulk([(room, room)])                 # known 判定要求已在后台
    await b.mark_cold_bulk([room], 1_000)
    resp = await web.monitor_add(_Req(), room=room)
    assert not isinstance(resp, web.JSONResponse) or resp.status_code == 200, resp
    assert await b.is_cold(room) is False                  # 冷标已清
    la = await b.last_access_map([room])
    assert room in la and la[room] > 1_000                 # 访问戳 GT 置新(宽限重置)
    from app.redis_bus import task_hist, task_mainpage
    z = dict(await b.r.zrange(rb.K_SCHED, 0, -1, withscores=True))
    assert task_mainpage(room) in z and task_hist(room) in z   # mp@now + 封尾


@pytest.mark.asyncio
async def test_add_bulk_wakes_cold_rooms(ci_wired, monkeypatch):
    """G1(批量):add-bulk 对既有冷房同样唤醒 —— admit_rooms 排的 warmup mp
    不再被闸改排;既有 hs 铺开兼任封尾腿。canon 走 _CIStar(定值直返)。"""
    import json as _json

    import app.redis_bus as rb
    web, b, live = ci_wired
    monkeypatch.delenv("STA_MONITOR_WRITE_TOKEN", raising=False)

    class _Req:
        headers: dict = {}

        async def body(self):
            return _json.dumps({"rooms": ["9410", "9420"]}).encode()

    for r in ("9410", "9420"):
        await b.add_rooms_bulk([(r, r)])
        await b.mark_cold_bulk([r], 1_000)
    result = await web.monitor_add_bulk(_Req())
    assert result.get("ok") is True, result
    assert await b.cold_members() == set()                 # 两房冷标皆清
    la = await b.last_access_map(["9410", "9420"])
    assert la["9410"] > 1_000 and la["9420"] > 1_000       # GT 置新


@pytest.mark.asyncio
async def test_touch_room_exactly_once_counter(ci_wired):
    """G3:多副本并发首触 —— HDEL 只有一个赢家拿到 since;输家(cold_clear
    返回 None,本测直接注入该态)排任务但**绝不计数**,promote/falseWake 恰一次。"""
    web, b, _live = ci_wired
    room = "9510"
    await b.add_rooms_bulk([(room, room)])
    await b.mark_cold_bulk([room], 1_000)

    orig_clear = b.cold_clear

    async def _loser_clear(rid):
        await orig_clear(rid)                              # 真清(模拟别的副本已赢)
        return None                                        # 但本副本拿不到 since
    b.cold_clear = _loser_clear                            # type: ignore[assignment]
    await web.room_history(room, since=0, limit=3, passive="", until=0)
    b.cold_clear = orig_clear                              # type: ignore[assignment]
    st = await b.histmode_stats()
    assert int(st.get("cold_promote", 0) or 0) == 0        # 输家不计数
    assert int(st.get("cold_false_wake", 0) or 0) == 0
    assert await b.is_cold(room) is False                  # 唤醒本身仍完成


@pytest.mark.asyncio
async def test_sweep_hygiene_prune_and_stray_heal():
    """H1+H2:扫描锁内的台账卫生 —— ① 访问戳残项(不在活跃全集)修剪;
    ② 脱册冷标(理论不可达)自愈清除,且不影响正常房的判定。"""
    import app.redis_bus as rb
    w, _up, _db, clock, _s = _world(ci_enabled=True, shadow=True, after_s=300)
    live_room, ghost_la, ghost_cold = "8001", "8002", "8003"
    await w.bus.add_rooms_bulk([(live_room, live_room)])
    await w.bus.r.zadd(rb.K_LAST_ACCESS, {live_room: clock.t - 10_000,
                                          ghost_la: clock.t - 10_000})
    await w.bus.mark_cold_bulk([ghost_cold], clock.t)      # 冷标却不在名录
    await w._curated_idle_sweep({live_room})
    assert await w.bus.last_access_map([ghost_la]) == {}   # 残项已修剪
    assert (await w.bus.last_access_map([live_room]))[live_room] \
        == clock.t - 10_000                                # 在册项原样保留
    assert await w.bus.cold_members() == set()             # 脱册冷标已自愈
