"""test_jfvip_audit_4_3.py — 4.3.x 实地核查所修缺陷的回归钉(真库)

为什么必须补这一组:4.3.0~4.3.2 三轮改动全部落在 `_grant_tx` / `grants_page` /
`orders_page` 这条**只有真库才跑得到**的路径上,而既有用例**一条都不覆盖新行为** ——
`pytest` 全绿只能证明「没弄坏既有契约」,证明不了「新行为是对的」。
没有这一组,下一个人把守卫删掉、把日期纠偏删掉,测试照样全绿。

前置与 tests/test_jfvip_db.py 完全同款(不可达则整层 skip,不阻断主干):
    docker run -d --name jftest -p 3307:3306 \
      -e MARIADB_ALLOW_EMPTY_ROOT_PASSWORD=1 mariadb:10.11
"""
from __future__ import annotations

import asyncio
import os
import socket

import pytest

from app import jfvip, userauth
from app.settings import UserAuthCfg

_HOST = os.environ.get("STA_TEST_USERDB_HOST", "127.0.0.1")
_PORT = int(os.environ.get("STA_TEST_USERDB_PORT", "3307"))
_USER = os.environ.get("STA_TEST_USERDB_USER", "root")
_PASS = os.environ.get("STA_TEST_USERDB_PASSWORD", "")
_DB = os.environ.get("STA_TEST_AUDIT_DB_NAME", "fx_jfvip_audit43")


def _reachable() -> bool:
    try:
        with socket.create_connection((_HOST, _PORT), timeout=0.6):
            return True
    except OSError:
        return False


needs_db = pytest.mark.skipif(
    not _reachable(),
    reason=f"需要本地用户库 {_HOST}:{_PORT}(MariaDB/MySQL 1:1 复刻)")

_BASE_DDL = [
    f"CREATE DATABASE IF NOT EXISTS `{_DB}` DEFAULT CHARSET=gbk",
    """CREATE TABLE IF NOT EXISTS tb_user (
         id BIGINT NOT NULL AUTO_INCREMENT,
         user_name VARCHAR(50) NOT NULL,
         pass_word VARCHAR(100) NOT NULL DEFAULT '',
         email_account VARCHAR(320) NOT NULL DEFAULT '',
         email_bind_time BIGINT NOT NULL DEFAULT 0,
         register_time DATETIME NOT NULL,
         due_time DATETIME NOT NULL,
         is_off VARCHAR(1) NOT NULL DEFAULT '0',
         PRIMARY KEY(id), UNIQUE KEY uk_name (user_name)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk""",
]


async def _prepare():
    """建库建表。guantai_jf_* 四张表直接走 userauth._SCHEMA —— 单一真源,
    测试跑的就是生产会跑的那份 DDL。"""
    import aiomysql
    conn = await aiomysql.connect(host=_HOST, port=_PORT, user=_USER,
                                  password=_PASS, charset="gbk", autocommit=True)
    async with conn.cursor() as cur:
        await cur.execute(_BASE_DDL[0])
        await cur.execute(f"USE `{_DB}`")
        await cur.execute(_BASE_DDL[1])
    conn.close()
    userauth.UA.cfg = UserAuthCfg(host=_HOST, port=_PORT, db=_DB, user=_USER,
                                  password=_PASS, charset="gbk",
                                  jf_vip_enabled=True, cache_ttl_s=0.0)
    userauth.UA.pool = None
    userauth.UA.schema_ok = False
    userauth.UA.schema_lock = asyncio.Lock()
    assert await userauth._ensure_schema(), "guantai_* 建表失败"


async def _mk_user(name: str) -> int:
    await userauth._q("DELETE FROM guantai_jf_vip WHERE user_id IN "
                      "(SELECT id FROM tb_user WHERE user_name=%s)", (name,))
    await userauth._q("DELETE FROM tb_user WHERE user_name=%s", (name,))
    await userauth._q(
        "INSERT INTO tb_user (user_name, pass_word, register_time, due_time, is_off) "
        "VALUES (%s,'x',NOW(),DATE_ADD(NOW(), INTERVAL 30 DAY),'0')", (name,))
    row = await userauth._q("SELECT id FROM tb_user WHERE user_name=%s",
                            (name,), fetch="one")
    return int(row["id"])


async def _log_n() -> int:
    r = await userauth._q("SELECT COUNT(*) AS n FROM guantai_jf_grant_log", fetch="one")
    return int(r["n"])


# ══════════════════════════════════════════════════════════════════════════════
# C1 · 撤销守卫
# ══════════════════════════════════════════════════════════════════════════════
@needs_db
@pytest.mark.asyncio
async def test_revoke_on_user_without_vip_row_writes_no_ledger_row():
    """★ 4.3.0 修复的缺陷:用户从未开通过 VIP 时,`UPDATE guantai_jf_vip … WHERE
    user_id=%s` 影响 0 行(什么都没撤),但第 ⑦ 步照旧 INSERT 一条 jf_hours=-N
    的流水,函数回 err='',管理台弹绿色「已撤销」。

    `guantai_jf_grant_log` 是本项目宣告的**唯一对账口径**,而前端导出 CSV 时
    刻意放行负数正是为了让运维对 jf_hours 做 SUM —— 一条对应不到任何真实变更的
    -N 会永久让这个和偏掉,且事后无从分辨哪几条是幽灵。更直接的伤害是屏幕上
    说「已撤销」而实际什么也没发生。

    判据必须是 `vrow is None` 而不是 cur.rowcount:MySQL 未开 CLIENT_FOUND_ROWS
    时 affected_rows 是「实际改变的行数」,一次值恰好未变的**合法**撤销同样回 0。
    """
    await _prepare()
    uid = await _mk_user("a43_novip")
    n0 = await _log_n()
    err, _ = await jfvip.revoke_by_admin(uid, "a43_novip", 240, "admin(t)", "回归")
    assert err == "no_vip_row", f"应 fail-closed,实得 {err!r}"
    assert await _log_n() == n0, "★ 往唯一对账口径里写了一条对应不到任何变更的流水"
    v = await userauth._q("SELECT COUNT(*) AS n FROM guantai_jf_vip WHERE user_id=%s",
                          (uid,), fetch="one")
    assert int(v["n"]) == 0, "撤销不该凭空建出一行 VIP 记录"


@needs_db
@pytest.mark.asyncio
async def test_revoke_on_user_with_vip_row_still_works():
    """守卫**只能**拦住无行的那种。正常撤销必须逐字节照旧 ——
    这条钉的是「别把守卫写成把所有撤销都拦了」。"""
    await _prepare()
    uid = await _mk_user("a43_hasvip")
    err, _ = await jfvip.grant_by_admin(uid, "a43_hasvip", "m1", "admin(t)", "前置")
    assert err == "", f"前置开通失败:{err!r}"
    before = await userauth._q("SELECT vip_until FROM guantai_jf_vip WHERE user_id=%s",
                               (uid,), fetch="one")
    n0 = await _log_n()
    err, _ = await jfvip.revoke_by_admin(uid, "a43_hasvip", 240, "admin(t)", "回归")
    assert err == "", f"正常撤销被误拦:{err!r}"
    assert await _log_n() == n0 + 1, "正常撤销必须落一条流水"
    after = await userauth._q("SELECT vip_until FROM guantai_jf_vip WHERE user_id=%s",
                              (uid,), fetch="one")
    assert after["vip_until"] < before["vip_until"], "到期时间没有真的往回走"
    row = await userauth._q("SELECT jf_hours, source FROM guantai_jf_grant_log "
                            "ORDER BY id DESC LIMIT 1", fetch="one")
    assert int(row["jf_hours"]) == -240 and row["source"] == "revoke"


# ══════════════════════════════════════════════════════════════════════════════
# C2 / F5 · 开通流水的时间区间与「填反归一」
# ══════════════════════════════════════════════════════════════════════════════
async def _seed_grants(uid: int):
    await userauth._q("DELETE FROM guantai_jf_grant_log")
    rows = [("2026-07-01 12:00:00", "card"), ("2026-07-02 12:00:00", "order"),
            ("2026-07-03 12:00:00", "order"),
            ("2026-07-03 23:59:00", "card"),      # 边界:验「含当天全天」
            ("2026-07-10 12:00:00", "card")]
    for ts, src in rows:
        await userauth._q(
            "INSERT INTO guantai_jf_grant_log (user_id,user_name,source,ref,plan_code,"
            "amount,jf_hours,dd_hours,operator,created_at) "
            "VALUES (%s,'a43_g',%s,'r','m1',88,744,744,'',%s)", (uid, src, ts))


@needs_db
@pytest.mark.asyncio
async def test_grants_page_date_range_covers_whole_end_day():
    """★ 4.3.0 补的能力:唯一对账口径此前**查不了时间**(只有 uid / source),
    而项目自己在 orders_page 写过「运维按月对账是刚需」。
    建表时就留了 idx_time / idx_source(source, created_at),索引一直闲置。

    终点必须**含当天全天**:23:59 那条必须命中,否则按月对账每次都少最后一天。
    """
    await _prepare()
    uid = await _mk_user("a43_g")
    await _seed_grants(uid)
    d = await jfvip.grants_page(1, 50, date_from="2026-07-01", date_to="2026-07-03")
    assert d["total"] == 4, f"应含 07-03 全天(4 条),实得 {d['total']}"
    one = await jfvip.grants_page(1, 50, date_from="2026-07-03", date_to="2026-07-03")
    assert one["total"] == 2, f"单日应含 12:00 与 23:59 两条,实得 {one['total']}"
    allrows = await jfvip.grants_page(1, 50)
    assert allrows["total"] == 5, "不给区间应为全量"


@needs_db
@pytest.mark.asyncio
async def test_grants_page_swaps_reversed_date_range():
    """★ 4.3.1 修的不对称:**金额**区间填反会被交换(「别回空表让人以为没数据」),
    **日期**区间填反却不交换 —— 两个谓词互斥、回 0 行、屏幕零提示。
    对账场景下这个误读的代价比金额填反更大。

    必须交换**原始入参后重新规范化**:「起点补 00:00:00 / 终点补 23:59:59」的
    语义绑在**位置**上而非值上,直接交换 df/dt 会少算或多算一整天。
    """
    await _prepare()
    uid = await _mk_user("a43_g")
    await _seed_grants(uid)
    fwd = await jfvip.grants_page(1, 50, date_from="2026-07-01", date_to="2026-07-03")
    rev = await jfvip.grants_page(1, 50, date_from="2026-07-03", date_to="2026-07-01")
    assert rev["total"] == fwd["total"], "填反后结果条数不一致"
    assert [r["id"] for r in rev["items"]] == [r["id"] for r in fwd["items"]], \
        "填反后命中的行不一致 —— 说明只交换了值、没有重算日界"


@needs_db
@pytest.mark.asyncio
async def test_grants_page_bad_calendar_date_disables_only_that_predicate():
    """非法日历(2026-02-30 / 非闰年 2-29)必须让**该条件失效**,
    绝不把半截串塞进 SQL 让库去猜 —— 真库实测 MariaDB 对 '2026-02-30' 既不报错
    也不返空,而是当成 2/29 与 3/1 之间的一个点来比较。"""
    await _prepare()
    uid = await _mk_user("a43_g")
    await _seed_grants(uid)
    d = await jfvip.grants_page(1, 50, date_from="2026-02-30", date_to="2026-07-03")
    assert d["total"] == 4, f"起点应失效、终点仍生效,实得 {d['total']}"


@needs_db
@pytest.mark.asyncio
async def test_grants_page_source_and_date_combine():
    """来源 + 区间必须能叠加 —— 这正是 idx_source(source, created_at) 存在的理由。"""
    await _prepare()
    uid = await _mk_user("a43_g")
    await _seed_grants(uid)
    d = await jfvip.grants_page(1, 50, source="order",
                                date_from="2026-07-01", date_to="2026-07-03")
    assert d["total"] == 2, f"order 在区间内应为 2 条,实得 {d['total']}"


@needs_db
@pytest.mark.asyncio
async def test_orders_page_also_swaps_reversed_date_range():
    """F5 是**两处一起**修的。只修 grants 会让同一个界面上两张表行为不一致,
    而那种不一致最容易在后续维护里被当成「另有深意」。"""
    await _prepare()
    uid = await _mk_user("a43_o")
    for i, day in enumerate(("2026-07-01", "2026-07-05", "2026-07-09")):
        await userauth._q("DELETE FROM guantai_jf_order WHERE gateway_order_no=%s",
                          (f"A43O{i}",))
        await userauth._q(
            "INSERT INTO guantai_jf_order (gateway_order_no,user_id,user_name,plan_code,"
            "amount,jf_hours,dd_hours,status,credited,is_simulate,create_time) "
            "VALUES (%s,%s,'a43_o','m1',88,744,744,'paid',1,0,%s)",
            (f"A43O{i}", uid, day + " 10:00:00"))
    fwd = await jfvip.orders_page(1, 50, date_from="2026-07-01", date_to="2026-07-05")
    rev = await jfvip.orders_page(1, 50, date_from="2026-07-05", date_to="2026-07-01")
    assert fwd["total"] == rev["total"] == 2, \
        f"订单页填反未归一:正序 {fwd['total']} / 填反 {rev['total']}"
