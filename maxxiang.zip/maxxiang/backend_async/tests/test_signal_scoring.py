"""
test_signal_scoring.py — 安全加固 3.9.2:疑似脚本来源行为遥测(L4)
================================================================================
L4 是**纯遥测**层:为每个会话累积一份滚动行为画像,在管理台按可解释因子打分呈现,
供人工研判。它**绝不**自动封禁 —— 自动动作只由确定性事件(L1 租约违规 / L2 证明缺失)
触发。本套件钉住四件事:

一、**存储正确 + 自清理 + fail-safe**:sig_record 累进、sig_top 读回并按窗剪除过期
    会话;Redis 抖动时 sig_record **绝不抛错**(遥测失败不得影响任何请求)。

二、**评分可解释且方向正确**:纯 API 搬运器画像 → 高分且给出「从不加载页面 / 证明失败」
    等依据;真浏览器画像 → 0 分;含**缓存告诫**的次要信号权重低。

三、**归类正确 + 不越界**:中间件把请求分为 html/asset/detail/sse 四类,其余不触 Redis;
    明细端点被 401 挡下也照记(挡住的搬运器正是信号);无会话 Cookie / 特性关 → 不记;
    观测器**绝不抛错**。

四、**管理端点行为**:未开启 → enabled:false + 空表;开启 → 按分降序 + min_score 过滤;
    无管理身份 → 401(读也要鉴权)。
"""
import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import fakeredis.aioredis  # noqa: E402

import app.web as web            # noqa: E402
import app.admin_api as admin_api  # noqa: E402
from app.redis_bus import RedisBus  # noqa: E402


def _bus():
    b = RedisBus.__new__(RedisBus)
    b.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    return b


# ══ 一、存储层 ════════════════════════════════════════════════════════════════
@pytest.mark.asyncio
async def test_sig_record_and_top_roundtrip():
    b = _bus()
    now = 1_000_000
    await b.sig_record("sidA", kind="html", now_ms=now, uid=7, uname="alice",
                       ip="1.2.3.4", ua="Mozilla/5.0")
    await b.sig_record("sidA", kind="detail", now_ms=now + 10, room="321")
    await b.sig_record("sidA", kind="detail_ok", now_ms=now + 11)
    await b.sig_record("sidA", kind="detail", now_ms=now + 12, room="654")
    await b.sig_record("sidA", kind="detail", now_ms=now + 13, room="321")  # 重复房
    top = await b.sig_top(now_ms=now + 20, window_ms=1_800_000)
    assert len(top) == 1
    r = top[0]
    assert r["sid"] == "sidA" and str(r["uid"]) == "7" and r["uname"] == "alice"
    assert r["ip"] == "1.2.3.4"
    assert r["html"] == 1 and r["detail"] == 3 and r["detail_ok"] == 1
    assert r["rooms"] == 2                       # 321 / 654 去重


@pytest.mark.asyncio
async def test_room_cardinality_uses_hll_bounded():
    """**回归钉子**(审计发现):room 在中间件按请求路径记入,**被 401/429 挡下也记**。
    若用普通 SET,一个已登录攻击者能用海量垃圾房号(全 429)按请求速率把单会话集合
    无界撑大(实测 5000 请求→5000 成员)。改用 HyperLogLog:真 Redis 上固定 ~12KB 封顶,
    且小基数**精确**(评分只看「≥6」、面板只显计数)。此测试钉住:计数正确 + 攻击场景可用。"""
    b = _bus()
    for rid in ["321", "654", "999", "321", "654"]:      # 3 个不同
        await b.sig_record("s1", kind="detail", room=rid, ttl_ms=1_800_000)
    assert (await b.sig_top())[0]["rooms"] == 3, "小基数必须精确(评分阈值靠它)"
    # 攻击场景:5000 垃圾房仍给出可用估计(真 Redis 上该键 ≤12KB,不随请求数膨胀)
    b2 = _bus()
    for i in range(5000):
        await b2.sig_record("atk", kind="detail", room=f"G{i}", ttl_ms=1_800_000)
    est = (await b2.sig_top())[0]["rooms"]
    assert est >= 4500, f"5000 垃圾房的基数估计应接近真值,得 {est}"


@pytest.mark.asyncio
async def test_sig_index_bounded_without_any_read():
    """**回归钉子**(审计发现):sig:z 是全局键、无 TTL。若只在读时剪枝,那么
    「从没人打开管理台」的部署里它会随会话数无界增长(画像本体已随 TTL 蒸发,
    只剩指向空 hash 的死 sid)。故必须在**写入侧**同管道剪枝。"""
    b = _bus()
    now = 10_000_000
    for i in range(50):                     # 50 个早已过窗的老会话,全程不读
        await b.sig_record(f"old{i}", kind="detail", now_ms=now - 5_000_000,
                           ttl_ms=1_800_000)
    assert await b.r.zcard("sig:z") == 50
    await b.sig_record("fresh", kind="detail", now_ms=now, ttl_ms=1_800_000)
    assert await b.r.zcard("sig:z") == 1, "写入侧必须剪除过窗索引项,否则内存无界"
    assert await b.r.zrange("sig:z", 0, -1) == ["fresh"]


@pytest.mark.asyncio
async def test_sig_top_prunes_expired_sessions():
    b = _bus()
    now = 5_000_000
    await b.sig_record("stale", kind="detail", now_ms=now - 2_000_000)
    await b.sig_record("fresh", kind="detail", now_ms=now)
    top = await b.sig_top(now_ms=now, window_ms=1_000_000)   # 窗口 1000s
    sids = {r["sid"] for r in top}
    assert "fresh" in sids and "stale" not in sids


@pytest.mark.asyncio
async def test_sig_record_never_throws_on_redis_error():
    """遥测是尽力而为:底层 Redis 抛错时 sig_record 必须静默吞掉,绝不冒泡。"""
    b = RedisBus.__new__(RedisBus)

    class _Boom:
        def pipeline(self, *a, **k):
            raise RuntimeError("redis down")
    b.r = _Boom()
    await b.sig_record("x", kind="html", now_ms=1)   # 不抛即通过


@pytest.mark.asyncio
async def test_sig_top_returns_empty_on_redis_error():
    b = RedisBus.__new__(RedisBus)

    class _Boom:
        async def zremrangebyscore(self, *a, **k):
            raise RuntimeError("down")
    b.r = _Boom()
    assert await b.sig_top(now_ms=1) == []


# ══ 二、评分 ══════════════════════════════════════════════════════════════════
def test_score_scraper_profile_is_high():
    """拿 Cookie 用 curl 直拉(L2 开)的典型画像:从不加载页面、证明全失败、轮转多房。"""
    r = {"html": 0, "asset": 0, "detail": 20, "detail_ok": 0,
         "pow_ok": 0, "pow_fail": 20, "rooms": 9, "ua": "python-requests/2.31"}
    s = admin_api._sig_score(r)
    assert s["score"] >= 80
    assert any("从未加载页面" in x for x in s["reasons"])
    assert any("执行证明失败" in x for x in s["reasons"])


def test_score_browser_profile_is_zero():
    """真浏览器:加载过页面 + 取静态 + 证明通过 + 单房 → 0 分、无依据。"""
    r = {"html": 3, "asset": 25, "detail": 40, "detail_ok": 40,
         "pow_ok": 40, "pow_fail": 0, "rooms": 1, "ua": "Mozilla/5.0 (Chrome)"}
    s = admin_api._sig_score(r)
    assert s["score"] == 0 and s["reasons"] == []


def test_score_caching_caveat_is_mild_and_labeled():
    """加载了页面但不取静态(热缓存回访也会这样)→ 仅 +15,且依据文案带缓存告诫。

    **4.9.0 语义修订(刻意改动,非回归)**:该因子在有**执行证明实证**(pow_ok>0)时
    整条抑制。原用例的画像带 pow_ok=30 —— 那是「对方确实执行了本站混淆 JS」的铁证,
    再给它 15 分就是纯误报(热缓存回访的真人天然 asset=0)。故本用例拆成两条:
    有实证 → 0 分;无实证 → 维持 +15 且文案仍带缓存告诫。"""
    # ① 有执行证明实证 → 抑制(修订点)
    r = {"html": 2, "asset": 0, "detail": 30, "detail_ok": 30,
         "pow_ok": 30, "pow_fail": 0, "rooms": 1, "ua": "Mozilla/5.0"}
    s = admin_api._sig_score(r)
    assert s["score"] == 0, "有执行证明实证时,「不取静态」是热缓存回访的常态,不得计分"
    assert any("执行证明通过" in x for x in s["notes"]), "无罪信号必须呈现给研判者"
    # ② 无执行证明实证(L2 关或对方从未通过)→ 维持 3.9.x 的 +15 与缓存告诫文案
    r2 = dict(r, pow_ok=0)
    s2 = admin_api._sig_score(r2)
    assert s2["score"] == 15
    assert any("热缓存" in x for x in s2["reasons"])


def test_score_caps_at_100_and_ua_weakest():
    r = {"html": 0, "asset": 0, "detail": 50, "detail_ok": 0,
         "pow_ok": 0, "pow_fail": 50, "rooms": 20, "ua": "curl/8.0"}
    s = admin_api._sig_score(r)
    assert s["score"] == 100            # 45+35+15+10 = 105 → 截到 100
    assert admin_api._looks_like_browser("Mozilla/5.0 (Windows) Chrome/120") is True
    assert admin_api._looks_like_browser("python-requests/2.31") is False


# ══ 二·补 4.9.0 误报回归钉子 ═════════════════════════════════════════════════
#   下面每一条都对应一次**实地复现**的真人误判(见 repro_signal_fp.py /
#   verify_claims.py 的实测输出),而不是设想出来的场景。
def test_real_user_after_screen_lock_is_not_flagged():
    """**回归钉子(核心)**:真人锁屏 35 分钟 → 画像 Hash 超窗自然过期 → 回前台第一拍
    打明细,画像**以 html=0 重建**。旧版:45(从不加载页面)+20(证明失败 10 次)=**65**,
    与用户实际看到的分数与两条依据逐字吻合。新版必须 0 分 —— 因为 pow_ok/foot 都在证明
    「这是个浏览器」。"""
    prof = {"html": 0, "asset": 0, "detail": 68, "detail_ok": 58,
            "pow_ok": 58, "pow_fail": 10, "rooms": 1, "foot": True,
            "first": 1_000_000, "last": 1_000_000 + 30 * 60_000,
            "ua": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5) Safari/605.1.15"}
    s = admin_api._sig_score(prof)
    assert s["score"] == 0, f"锁屏复苏的真人不得被判为脚本,得 {s['score']}:{s['reasons']}"
    assert s["reasons"] == []


def test_challenge_expiry_fails_are_rate_gated():
    """**回归钉子**:挑战 TTL 180s + 前端不主动续铸 ⇒ 真人 30 分钟窗口稳产 10 次失败
    (≈0.33 次/分)。旧版 `elif pow_fail >= 10` 直接 +20;新版按速率判,真人够不着。"""
    span = {"first": 0, "last": 30 * 60_000}
    human = dict(span, html=1, asset=6, detail=70, detail_ok=60,
                 pow_ok=60, pow_fail=10, rooms=1, ua="Mozilla/5.0")
    assert admin_api._sig_score(human)["score"] == 0
    # 同样 10 次失败,但压在 1 分钟内且从未成功 = 真信号,照旧要判高
    burst = {"first": 0, "last": 60_000, "html": 0, "asset": 0, "detail": 40,
             "detail_ok": 0, "pow_ok": 0, "pow_fail": 10, "rooms": 1,
             "ua": "python-requests/2.31"}
    assert admin_api._sig_score(burst)["score"] >= 80


def test_blocked_request_is_not_double_counted():
    """**回归钉子**:一次被拒的明细请求会同时进 pow_fail 与 detail(实测确证)。
    旧阈值 `detail + pow_fail >= 8` 等于门槛只有 4 次;新版只看 detail。"""
    rec = {"html": 0, "asset": 0, "detail": 4, "detail_ok": 0,
           "pow_ok": 0, "pow_fail": 4, "rooms": 1, "ua": "Mozilla/5.0"}
    assert not any("从未加载页面" in x for x in admin_api._sig_score(rec)["reasons"])
    rec8 = dict(rec, detail=8)
    assert any("从未加载页面" in x for x in admin_api._sig_score(rec8)["reasons"])


def test_browser_footprint_downgrades_instead_of_max_factor():
    """**回归钉子**:L2 关闭(pow_ok 恒 0)时,靠长效足迹把最强因子降级为中等 ——
    既不误伤锁屏回来的真人(20 < 面板默认阈值 50),又不对偷 Cookie 的搬运器全盲。"""
    resumed = {"html": 0, "asset": 0, "detail": 30, "detail_ok": 30, "pow_ok": 0,
               "pow_fail": 0, "rooms": 1, "foot": True,
               "first": 0, "last": 20 * 60_000, "ua": "Mozilla/5.0"}
    s = admin_api._sig_score(resumed)
    assert s["score"] == 20 and any("疑度已下调" in x for x in s["reasons"])
    no_foot = dict(resumed, foot=False)
    assert admin_api._sig_score(no_foot)["score"] == 45


def test_pow_stale_never_scores():
    """**回归钉子**:pow_stale = 「客户端带了应答,但服务端这把挑战已过期/被轮转」——
    那是服务端的过期,不是客户端的失败,恒不计疑度,只作为 notes 呈现。"""
    rec = {"html": 1, "asset": 3, "detail": 40, "detail_ok": 40, "pow_ok": 5,
           "pow_fail": 0, "pow_stale": 99, "rooms": 1, "ua": "Mozilla/5.0",
           "first": 0, "last": 30 * 60_000}
    s = admin_api._sig_score(rec)
    assert s["score"] == 0
    assert any("挑战过期" in x for x in s["notes"])


def test_room_rotation_uses_rate_not_count():
    """**回归钉子**:真人半小时里陆续看 8 个房 ≈0.27 个/分,不该判「短时轮转」;
    采集器 2 分钟扫 9 个 ≈4.5 个/分,照旧要判。"""
    human = {"html": 2, "asset": 9, "detail": 40, "detail_ok": 40, "pow_ok": 40,
             "pow_fail": 0, "rooms": 8, "foot": True, "ua": "Mozilla/5.0",
             "first": 0, "last": 30 * 60_000}
    assert admin_api._sig_score(human)["score"] == 0
    bot = {"html": 0, "asset": 0, "detail": 40, "detail_ok": 40, "pow_ok": 0,
           "pow_fail": 0, "rooms": 9, "ua": "curl/8.0", "first": 0, "last": 120_000}
    assert any("短时访问" in x for x in admin_api._sig_score(bot)["reasons"])


def test_score_tolerates_legacy_records_without_new_fields():
    """**兼容钉子**:老画像(无 first/last/foot/pow_stale)必须按「计数即速率」退化,
    与 3.9.x 同量级 —— 升级瞬间在窗的老会话不得因为缺字段而崩或漏判。"""
    legacy = {"html": 0, "asset": 0, "detail": 20, "detail_ok": 0,
              "pow_ok": 0, "pow_fail": 20, "rooms": 9, "ua": "python-requests/2.31"}
    s = admin_api._sig_score(legacy)
    assert s["score"] >= 80 and s["span_min"] == 1.0


# ══ 三、观测器归类 ════════════════════════════════════════════════════════════
class _Resp:
    def __init__(self, status=200, ctype="application/json"):
        self.status_code = status
        self.headers = {"content-type": ctype}


class _Req:
    def __init__(self, path, cookie="sess-1", ua="Mozilla/5.0", user=None):
        self.url = type("U", (), {"path": path})()
        self.headers = {"user-agent": ua}
        self.cookies = {"jf_sess": cookie} if cookie else {}
        self.client = type("C", (), {"host": "9.9.9.9"})()
        self.state = type("S", (), {"user": user})()


class _User:
    user_id = 7
    user_name = "alice"


def _obs_setup(monkeypatch, on=True):
    monkeypatch.setattr(web.userauth, "enabled", lambda: True)
    monkeypatch.setattr(web.settings.userauth, "signal_scoring", on, raising=False)
    monkeypatch.setattr(web.settings.userauth, "signal_window_s", 1800.0, raising=False)

    class _Cfg:
        cookie_name = "jf_sess"
    monkeypatch.setattr(web.userauth.UA, "cfg", _Cfg(), raising=False)


@pytest.mark.asyncio
async def test_observe_classifies_all_kinds(monkeypatch):
    _obs_setup(monkeypatch)
    b = _bus()
    monkeypatch.setattr(web.ST, "bus", b, raising=False)
    await web._sig_observe(_Req("/", user=_User()),
                           _Resp(200, "text/html; charset=utf-8"))          # html
    await web._sig_observe(_Req("/assets/app.js", user=_User()),
                           _Resp(200, "application/javascript"))            # asset
    await web._sig_observe(_Req("/api/rooms/321/prediction", user=_User()),
                           _Resp(200))                                      # detail ok
    await web._sig_observe(_Req("/api/rooms/654", user=_User()),
                           _Resp(401))                          # detail(裸 summary)被挡
    await web._sig_observe(_Req("/api/events", user=_User()),
                           _Resp(200, "text/event-stream"))                # sse
    await web._sig_observe(_Req("/api/auth/session", user=_User()),
                           _Resp(200))                                      # other → ignored
    top = await b.sig_top(now_ms=int(time.time() * 1000) + 1000)
    assert len(top) == 1
    r = top[0]
    assert r["html"] == 1 and r["asset"] == 1
    assert r["detail"] == 2 and r["detail_ok"] == 1      # 401 计 detail、不计 detail_ok
    assert r["sse"] == 1 and r["rooms"] == 2
    assert str(r["uid"]) == "7"                          # 归属到账号


@pytest.mark.asyncio
async def test_observe_counts_html_on_304_revalidation(monkeypatch):
    """**回归钉子**(审计发现的真实缺陷):SPA 文档是 no-cache,回访浏览器走条件请求得
    **304**(无 text/html 头)。若只认 200+text/html,热缓存回访的真人会 html=0,
    正好踩中最强因子(+45「从不加载页面」)→ 真人被误判为搬运器。304 必须计入。"""
    _obs_setup(monkeypatch)
    b = _bus()
    monkeypatch.setattr(web.ST, "bus", b, raising=False)
    await web._sig_observe(_Req("/", user=_User()), _Resp(200, "text/html; charset=utf-8"))
    await web._sig_observe(_Req("/", user=_User()), _Resp(304, ""))          # 回访 304
    await web._sig_observe(_Req("/", user=_User()), _Resp(304, ""))
    top = await b.sig_top(now_ms=int(time.time() * 1000) + 1000)
    assert top[0]["html"] == 3, "304 条件请求必须计入 html,否则误伤热缓存回访真人"


@pytest.mark.asyncio
async def test_observe_detail_scope_matches_backend_guards(monkeypatch):
    """**回归钉子**:遥测的「明细」范围必须与后端**实际加了证明闸的 4 个端点**一致 ——
    summary 是**裸** /api/rooms/{room}(非 /summary);/history/days 与 /config
    后端未设闸、前端也不附证明,不得计为明细拉取。"""
    _obs_setup(monkeypatch)
    b = _bus()
    monkeypatch.setattr(web.ST, "bus", b, raising=False)
    for p in ("/api/rooms/1",                 # 裸 summary → 明细
              "/api/rooms/1/prediction",
              "/api/rooms/1/coverage",
              "/api/rooms/1/history"):
        await web._sig_observe(_Req(p, user=_User()), _Resp(200))
    for p in ("/api/rooms/1/history/days",    # 元数据 → 非明细
              "/api/rooms/1/config",
              "/api/rooms"):                  # 名录列表 → 非明细
        await web._sig_observe(_Req(p, user=_User()), _Resp(200))
    top = await b.sig_top(now_ms=int(time.time() * 1000) + 1000)
    assert top[0]["detail"] == 4, "明细计数应恰为 4 个受闸端点"


@pytest.mark.asyncio
async def test_observe_noop_when_disabled(monkeypatch):
    _obs_setup(monkeypatch, on=False)
    b = _bus()
    monkeypatch.setattr(web.ST, "bus", b, raising=False)
    await web._sig_observe(_Req("/", user=_User()), _Resp(200, "text/html"))
    assert await b.sig_top() == []


@pytest.mark.asyncio
async def test_observe_noop_without_cookie(monkeypatch):
    """无会话 Cookie → 无法归属账号 → 不记录(避免把匿名/登录前流量误算)。"""
    _obs_setup(monkeypatch)
    b = _bus()
    monkeypatch.setattr(web.ST, "bus", b, raising=False)
    await web._sig_observe(_Req("/api/rooms/321/prediction", cookie=None, user=_User()),
                           _Resp(200))
    assert await b.sig_top() == []


@pytest.mark.asyncio
async def test_observe_never_throws(monkeypatch):
    _obs_setup(monkeypatch)

    class _Boom:
        async def sig_record(self, *a, **k):
            raise RuntimeError("boom")
    monkeypatch.setattr(web.ST, "bus", _Boom(), raising=False)
    await web._sig_observe(_Req("/api/rooms/321/prediction", user=_User()), _Resp(200))


@pytest.mark.asyncio
async def test_proof_guard_records_pow_signals(monkeypatch):
    """_proof_guard 通过时记 pow_ok、拒绝时记 pow_fail(L2 与 L4 的接缝)。"""
    _obs_setup(monkeypatch)
    b = _bus()
    monkeypatch.setattr(web.ST, "bus", b, raising=False)
    await web._sig_pow(_Req("/api/rooms/1/prediction", user=_User()), ok=True)
    await web._sig_pow(_Req("/api/rooms/1/prediction", user=_User()), ok=False)
    await web._sig_pow(_Req("/api/rooms/1/prediction", user=_User()), ok=False)
    top = await b.sig_top(now_ms=int(time.time() * 1000) + 1000)
    assert len(top) == 1 and top[0]["pow_ok"] == 1 and top[0]["pow_fail"] == 2


# ══ 四、管理端点 ══════════════════════════════════════════════════════════════
class _AdminReq:
    def __init__(self, tok="tok"):
        self.headers = {"x-admin-session": tok} if tok else {}
        self.cookies = {}
        self.url = type("U", (), {"scheme": "http"})()
        self.client = type("C", (), {"host": "1.1.1.1"})()
        self.query_params = {}


def _admin_ok(monkeypatch):
    monkeypatch.setattr(admin_api.admin_auth, "enabled", lambda: True)
    monkeypatch.setattr(admin_api.admin_auth, "ip_allowed", lambda ip: True)
    monkeypatch.setattr(admin_api.admin_auth, "client_ip", lambda r: "1.1.1.1")
    monkeypatch.setattr(admin_api.admin_auth, "parse_session",
                        lambda t: ({"sub": "admin", "csrf": "c"} if t else None))


@pytest.mark.asyncio
async def test_signals_endpoint_unauthorized(monkeypatch):
    _admin_ok(monkeypatch)
    from fastapi.responses import JSONResponse
    r = await admin_api.signals(_AdminReq(tok=""), limit=100, min_score=0)
    assert isinstance(r, JSONResponse) and r.status_code == 401


@pytest.mark.asyncio
async def test_signals_endpoint_feature_off(monkeypatch):
    _admin_ok(monkeypatch)
    import types
    monkeypatch.setattr(admin_api.settings, "userauth",
                        types.SimpleNamespace(enabled=True, signal_scoring=False,
                                              signal_window_s=1800.0))
    out = await admin_api.signals(_AdminReq(), limit=100, min_score=0)
    assert out["ok"] is True and out["enabled"] is False and out["sources"] == []


@pytest.mark.asyncio
async def test_signals_endpoint_scored_sorted_filtered(monkeypatch):
    _admin_ok(monkeypatch)
    import types
    monkeypatch.setattr(admin_api.settings, "userauth",
                        types.SimpleNamespace(enabled=True, signal_scoring=True,
                                              signal_window_s=1800.0))
    b = _bus()
    admin_api._ST = type("ST", (), {"bus": b})()
    now = int(time.time() * 1000)
    # 一个强搬运器(高分)
    for _ in range(20):
        await b.sig_record("scraper", kind="detail", now_ms=now, room="1")
    for _ in range(20):
        await b.sig_record("scraper", kind="pow_fail", now_ms=now)
    for rid in range(9):
        await b.sig_record("scraper", kind="detail", now_ms=now, room=str(100 + rid))
    # 一个真浏览器(低分)
    await b.sig_record("human", kind="html", now_ms=now, ua="Mozilla/5.0")
    for _ in range(5):
        await b.sig_record("human", kind="asset", now_ms=now)
    await b.sig_record("human", kind="pow_ok", now_ms=now)

    out = await admin_api.signals(_AdminReq(), limit=100, min_score=0)
    assert out["enabled"] is True
    sids = [s["sid"] for s in out["sources"]]
    assert sids[0] == "scraper"                       # 高分排前
    assert out["sources"][0]["score"] >= 80
    # min_score 过滤:门槛 50 时,真浏览器(0 分)被滤掉
    out2 = await admin_api.signals(_AdminReq(), limit=100, min_score=50)
    sids2 = [s["sid"] for s in out2["sources"]]
    assert "scraper" in sids2 and "human" not in sids2
