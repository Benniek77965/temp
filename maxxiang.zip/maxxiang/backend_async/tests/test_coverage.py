"""
test_coverage.py — 近30局完整性 /coverage 端点(零 Redis/PG,假桩驱动)
================================================================================
验证前端「按需 history」的后端判据:
  · 本地格点齐 → complete=True,前端据此不拉 history
  · 缺口 ∈ 官方缺失 → 也算 complete(那格永远不会有,别拉)
  · 缺口 ∉ 官方缺失 → complete=False(本项目漏抓,前端拉一次补)
局起点是步进 50001ms 的等差格点;窗口 = 最新局往回数 window 个格点。

同时验证 RedisBus 的 official_missing 读写(用真实的 fakeredis 若可用,否则跳过)。
"""
import asyncio
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import web  # noqa: E402
from app.constants import ROUND_STEP  # noqa: E402


class _FakeDB:
    def __init__(self, round_ids):
        # 新→旧
        self._rows = [{"round_id": r} for r in sorted(round_ids, reverse=True)]

    async def history(self, room_id, since=0, limit=80):
        return self._rows[:limit]


class _FakeBus:
    def __init__(self, off_missing=()):
        self._off = set(int(x) for x in off_missing)

    async def official_missing_in(self, room, grid):
        gset = set(int(g) for g in grid)
        return sorted(self._off & gset)


class _FakeStar:
    async def canon(self, room):
        return str(room), True


class _FakeST:
    def __init__(self, round_ids, off_missing=()):
        self.db = _FakeDB(round_ids)
        self.bus = _FakeBus(off_missing)
        self.star = _FakeStar()


def _run(coro):
    return asyncio.run(coro)


def _install(monkeypatch, round_ids, off_missing=()):
    monkeypatch.setattr(web, "ST", _FakeST(round_ids, off_missing))


BASE = 1_783_351_925_595   # 取 HAR 里的一个真实局起点当基准


def _grid(n):
    """最新局 BASE 往回 n 个连续格点(旧→新)。"""
    return [BASE - i * ROUND_STEP for i in range(n)]


def test_full_window_is_complete(monkeypatch):
    _install(monkeypatch, _grid(30))
    d = _run(web.room_coverage("2678075", window=30))
    assert d["complete"] is True
    assert d["latest_start"] == BASE
    assert len(d["local"]) == 30
    assert d["official_missing"] == []


def test_local_gap_is_incomplete(monkeypatch):
    # 缺中间一格(既非官方缺失)→ 本项目漏抓
    ids = _grid(30)
    hole = ids[10]
    ids.remove(hole)
    _install(monkeypatch, ids)
    d = _run(web.room_coverage("2678075", window=30))
    assert d["complete"] is False
    assert hole not in d["local"]
    assert d["official_missing"] == []


def test_gap_covered_by_official_missing_is_complete(monkeypatch):
    # 同一个洞,但它被登记为「官方本身缺失」→ 判定完整(那格永远不会有)
    ids = _grid(30)
    hole = ids[10]
    ids.remove(hole)
    _install(monkeypatch, ids, off_missing=[hole])
    d = _run(web.room_coverage("2678075", window=30))
    assert d["complete"] is True
    assert hole in d["official_missing"]


def test_mixed_gaps(monkeypatch):
    # 两个洞:一个官方缺、一个本项目漏 → 整体不完整,但官方缺的那个被正确标出
    ids = _grid(30)
    off_hole = ids[5]
    proj_hole = ids[20]
    ids.remove(off_hole)
    ids.remove(proj_hole)
    _install(monkeypatch, ids, off_missing=[off_hole])
    d = _run(web.room_coverage("2678075", window=30))
    assert d["complete"] is False
    assert off_hole in d["official_missing"]
    assert proj_hole not in d["official_missing"]
    assert proj_hole not in d["local"]


def test_no_local_data(monkeypatch):
    _install(monkeypatch, [])
    d = _run(web.room_coverage("2678075", window=30))
    assert d["complete"] is False
    assert d["latest_start"] is None
    assert d.get("reason") == "no_local_data"


def test_window_clamped(monkeypatch):
    _install(monkeypatch, _grid(30))
    d = _run(web.room_coverage("2678075", window=9999))
    assert d["window"] <= 200


def test_official_missing_outside_window_ignored(monkeypatch):
    # 官方缺失格点若不在当前窗口,不应影响判定
    ids = _grid(30)
    far = BASE - 100 * ROUND_STEP        # 窗口外
    _install(monkeypatch, ids, off_missing=[far])
    d = _run(web.room_coverage("2678075", window=30))
    assert d["complete"] is True
    assert far not in d["official_missing"]


# ── RedisBus official_missing 读写(fakeredis 有则测,无则跳过)──────────────
try:
    import fakeredis.aioredis as _fakeaio
    _HAS_FAKE = True
except Exception:
    _HAS_FAKE = False


@pytest.mark.skipif(not _HAS_FAKE, reason="需要 fakeredis")
def test_redis_official_missing_roundtrip(monkeypatch):
    from app.redis_bus import RedisBus, K_OFF_MISSING

    async def go():
        bus = RedisBus.__new__(RedisBus)         # 不走 __init__(免真实连接)
        bus.r = _fakeaio.FakeRedis(decode_responses=True)
        room = "321"
        g = _grid(5)
        # 标记其中两个
        await bus.official_missing_mark(room, g[1])
        await bus.official_missing_mark(room, g[3])
        got = await bus.official_missing_in(room, g)
        assert set(got) == {g[1], g[3]}
        # 窗口外查询不返回
        assert await bus.official_missing_in(room, [BASE - 100 * ROUND_STEP]) == []
        # TTL 已设(24h 量级)
        ttl = await bus.r.ttl(K_OFF_MISSING.format(room=room))
        assert ttl > 0

    asyncio.run(go())
