"""
test_admin_session_channel.py — 会话凭据双通道(X-Admin-Session 头 / cookie)
================================================================================
根因回归:登录 200 但后续请求 401(cookie 未回传)导致「页面没反应」。
修复后令牌经响应体下发、请求头回传,不依赖 cookie 机制;cookie 保留兜底。
零外部依赖:直接构造轻量 Request 桩喂 _session_token / _guard。
"""
from types import SimpleNamespace

import pytest

from app import admin_auth as aa
from app import admin_api


class _Req:
    """最小 Request 桩:headers 大小写不敏感、cookies 为普通 dict。"""
    def __init__(self, headers=None, cookies=None, host="127.0.0.1"):
        h = {k.lower(): v for k, v in (headers or {}).items()}
        self.headers = SimpleNamespace(get=lambda k, d="": h.get(k.lower(), d))
        self.cookies = cookies or {}
        self.client = SimpleNamespace(host=host)


@pytest.fixture(autouse=True)
def _enable_admin(monkeypatch):
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "pw-for-channel-tests")
    monkeypatch.delenv("STA_ADMIN_IP_ALLOW", raising=False)
    aa._reset_for_tests()
    yield
    aa._reset_for_tests()


def test_header_channel_authenticates_without_cookie():
    """cookie 全灭(反代剥离/浏览器拒收)时,头通道独立完成鉴权。"""
    tok, csrf = aa.issue_session()
    req = _Req(headers={"X-Admin-Session": tok})          # 无任何 cookie
    payload = admin_api._guard(req)
    assert isinstance(payload, dict) and payload.get("csrf") == csrf


def test_cookie_fallback_still_works():
    tok, csrf = aa.issue_session()
    req = _Req(cookies={aa.COOKIE: tok})                  # 无自定义头
    payload = admin_api._guard(req)
    assert isinstance(payload, dict) and payload.get("csrf") == csrf


def test_header_takes_precedence_over_stale_cookie():
    """同名旧 cookie(换密码前签发/其它实例签发)不再劫持会话:头优先。"""
    good, csrf = aa.issue_session()
    stale = good[:-4] + "beef"                            # 篡改签名 → 验签必败
    req = _Req(headers={"X-Admin-Session": good}, cookies={aa.COOKIE: stale})
    payload = admin_api._guard(req)
    assert isinstance(payload, dict) and payload.get("csrf") == csrf


def test_invalid_header_rejected_even_with_valid_cookie():
    """头显式提供即为唯一凭据来源(优先且不回落),坏头 = 401。"""
    good, _ = aa.issue_session()
    req = _Req(headers={"X-Admin-Session": "not-a-token"},
               cookies={aa.COOKIE: good})
    resp = admin_api._guard(req)
    assert not isinstance(resp, dict) and resp.status_code == 401


def test_no_credentials_is_401():
    resp = admin_api._guard(_Req())
    assert not isinstance(resp, dict) and resp.status_code == 401


def test_write_guard_requires_csrf_on_header_channel():
    """写守卫沿用 CSRF 双提交(与凭据通道无关),头通道亦须携带。"""
    tok, csrf = aa.issue_session()
    ok = admin_api._guard_write(_Req(headers={"X-Admin-Session": tok,
                                              "X-Admin-CSRF": csrf}))
    assert isinstance(ok, dict)
    bad = admin_api._guard_write(_Req(headers={"X-Admin-Session": tok}))
    assert not isinstance(bad, dict) and bad.status_code == 403
