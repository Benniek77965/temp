"""
test_admin_login_http.py — 管理台登录 HTTP 集成(ASGI 直连,不起真实服务)
================================================================================
线级回归三件套:
  1. /login 响应体含 token,且与 Set-Cookie 值一致(前端头通道的凭据来源);
  2. 仅带 X-Admin-Session 头(零 cookie)可访问受保护端点 —— cookie 全灭免疫;
  3. 无任何凭据 = 401。
说明:admin_api 的登录限流与审计均以 suppress 包裹,_ST 未注入时自然跳过,
故可用 httpx.ASGITransport 直打路由,零外部依赖(Redis/PG 不需要)。
"""
import httpx
import pytest
from fastapi import FastAPI

from app import admin_api
from app import admin_auth as aa


@pytest.fixture()
def app(monkeypatch):
    monkeypatch.setenv("STA_ADMIN_PASSWORD", "pw-http-it")
    monkeypatch.delenv("STA_ADMIN_IP_ALLOW", raising=False)
    aa._reset_for_tests()
    a = FastAPI()
    a.include_router(admin_api.router, prefix="/api/admin")   # 5.3.0:前缀在挂载时给
    yield a
    aa._reset_for_tests()


def _client(app):
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=app),
                             base_url="http://t")


async def test_login_body_token_matches_cookie(app):
    async with _client(app) as c:
        r = await c.post("/api/admin/login", json={"password": "pw-http-it"})
        assert r.status_code == 200
        j = r.json()
        assert j["ok"] is True and j["csrf"] and j["token"]
        assert r.cookies.get(aa.COOKIE) == j["token"]      # 体内 token ≡ cookie 值
        assert aa.parse_session(j["token"])["csrf"] == j["csrf"]


async def test_header_only_access_end_to_end(app):
    async with _client(app) as c:
        tok = (await c.post("/api/admin/login",
                            json={"password": "pw-http-it"})).json()["token"]
        c.cookies.clear()                                   # 模拟 cookie 全灭
        r = await c.get("/api/admin/schema",
                        headers={"X-Admin-Session": tok})
        assert r.status_code == 200 and r.json().get("ok") is True
        r2 = await c.get("/api/admin/session",
                         headers={"X-Admin-Session": tok})
        assert r2.status_code == 200 and r2.json().get("ok") is True


async def test_no_credentials_401(app):
    async with _client(app) as c:
        assert (await c.get("/api/admin/schema")).status_code == 401


async def test_wrong_password_401_no_cookie(app):
    async with _client(app) as c:
        r = await c.post("/api/admin/login", json={"password": "nope"})
        assert r.status_code == 401
        assert aa.COOKIE not in r.cookies
