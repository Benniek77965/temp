"""
test_jfvip_discipline.py — 九法 VIP(4.2.0)的机器保证
================================================================================
本文件钉死三类不变量,任何一条被破坏都当场变红:

  A. **写纪律**:对 tb_user 的 UPDATE 全项目恰好一处,且必须在 jfvip._grant_tx()
     体内;DELETE/ALTER/TRUNCATE/DROP 恒为零。
     (test_register.py 的同名测试负责"计数",本文件负责"定位到函数体内"。)

  B. **档位判定**真值表 —— 含「VIP 有效但小叮当到期」这一反直觉组合。

  C. **开关关闭 = 完全退场**:jf_vip_enabled=False 时 enabled() 恒 False,
     _tier() 恒 "vip"(全功能放行),逐字节维持 4.1.2 行为。

纯静态 + 纯内存,零外部依赖(不需要 MySQL / Redis)。
"""
from __future__ import annotations

import ast
import json
import re
from pathlib import Path

from tests._srcscan import js_code, py_code

import pytest

from app import jfvip, userauth, web
from app.settings import UserAuthCfg

APP_DIR = Path(__file__).resolve().parent.parent / "app"


# ══════════════════════════════════════════════════════════════════════════════
# A. 写纪律
# ══════════════════════════════════════════════════════════════════════════════
def _strip_line_comments(text: str) -> str:
    return "\n".join("" if ln.lstrip().startswith("#") else ln
                     for ln in text.split("\n"))


def test_tb_user_update_lives_only_in_grant_tx():
    """唯一那条 tb_user UPDATE 必须落在 _grant_tx 函数体内 —— 不能漂到别处。

    做法:AST 定位 _grant_tx 的行区间,再对全文件做正则,断言每一处命中都落在
    该区间内。比"在源码里找函数名"更硬:改名/挪位都会被抓到。
    """
    src = (APP_DIR / "jfvip.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    span = None
    for node in ast.walk(tree):
        if isinstance(node, ast.AsyncFunctionDef) and node.name == "_grant_tx":
            span = (node.lineno, node.end_lineno)
            break
    assert span is not None, "jfvip._grant_tx 丢失或改名 —— 写纪律的锚点没了"

    stripped = _strip_line_comments(src)
    tbl = r"(?:`?tb_user`?|`?\{[a-zA-Z_.]*user_table[^}]*\}`?)"
    pat = re.compile(r"\bUPDATE\s+" + tbl, re.I)
    hits = []
    for m in pat.finditer(stripped):
        hits.append(stripped[:m.start()].count("\n") + 1)
    assert len(hits) == 1, f"jfvip.py 内对 tb_user 的 UPDATE 应恰好 1 处,实得 {len(hits)}"
    assert span[0] <= hits[0] <= span[1], (
        f"tb_user 的 UPDATE 在第 {hits[0]} 行,不在 _grant_tx "
        f"({span[0]}–{span[1]}) 体内 —— 写纪律失守")


def test_no_forbidden_verbs_on_tb_user_anywhere():
    """DELETE / ALTER / TRUNCATE / REPLACE / DROP 对 tb_user 恒为零(含 jfvip)。"""
    tbl = r"(?:`?tb_user`?|`?\{[a-zA-Z_.]*user_table[^}]*\}`?)"
    bad = re.compile(
        r"\b(?:DELETE\s+FROM|ALTER\s+TABLE|TRUNCATE(?:\s+TABLE)?|"
        r"REPLACE\s+INTO|DROP\s+TABLE(?:\s+IF\s+EXISTS)?)\s+" + tbl, re.I)
    for path in sorted(APP_DIR.rglob("*.py")):
        src = _strip_line_comments(path.read_text(encoding="utf-8"))
        m = bad.search(src)
        assert m is None, f"{path.name}: 对 tb_user 的禁用动词 {m.group(0)!r}"


def test_grant_tx_has_no_network_call():
    """开通事务体内**零网络调用** —— 持锁期间发 HTTP 是把公网 RTT 焊进行锁,
    公网库(RTT 数十毫秒且受安全组摆布)下会把 tb_user 行锁一压好几秒。"""
    src = (APP_DIR / "jfvip.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    fn = next((n for n in ast.walk(tree)
               if isinstance(n, ast.AsyncFunctionDef) and n.name == "_grant_tx"), None)
    assert fn is not None
    # 只看**可执行代码**:剥掉 docstring 与整行注释 —— 文档里作交叉引用提到
    # "见 jfpay.py" 是好事,不该被判成网络调用(那是假阳性)。
    body_nodes = fn.body[1:] if (fn.body and isinstance(fn.body[0], ast.Expr)
                                 and isinstance(fn.body[0].value, ast.Constant)
                                 and isinstance(fn.body[0].value.value, str)) else fn.body
    code = _strip_line_comments(
        "\n".join((ast.get_source_segment(src, n) or "") for n in body_nodes))
    for bad in ("aiohttp", "urllib", "requests", "_gw_get", "_gw_post", "jfpay"):
        assert bad not in code, f"_grant_tx 可执行代码内出现网络调用痕迹:{bad}"


def test_new_tables_all_guantai_prefixed():
    """新表必须全部 guantai_ 前缀且 CREATE TABLE IF NOT EXISTS(幂等、零触碰旧表)。"""
    src = _strip_line_comments((APP_DIR / "userauth.py").read_text(encoding="utf-8"))
    # 只认「反引号/字母开头」的真表名 —— 中文注释里的 "CREATE TABLE IF NOT EXISTS
    # 在表已存在时…" 会被朴素 \w+ 命中(\w 含中日韩字符),那是假阳性。
    created = re.findall(r"CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+([A-Za-z_][A-Za-z0-9_]*)",
                         src, re.I)
    assert created, "未找到任何建表语句"
    for t in created:
        assert t.startswith("guantai_"), f"新建表 {t} 未用 guantai_ 前缀"
    for t in ("guantai_jf_vip", "guantai_jf_order",
              "guantai_jf_card", "guantai_jf_grant_log"):
        assert t in created, f"缺少 4.2.0 新表 {t}"
    # 除 CREATE TABLE IF NOT EXISTS 外不得有任何其它 DDL 动词
    assert not re.search(r"\bALTER\s+TABLE\b", src, re.I), "userauth 出现 ALTER TABLE"


# ══════════════════════════════════════════════════════════════════════════════
# B. 档位判定真值表
# ══════════════════════════════════════════════════════════════════════════════
@pytest.mark.parametrize("dd_alive,jf_alive,want", [
    (True,  False, "basic"),   # 小叮当有效、无 VIP —— 最常见的付费转化目标
    (True,  True,  "vip"),     # 都有效
    (False, False, "free"),    # 都无效 —— 只见开通页
    (False, True,  "vip"),     # ★ 反直觉但必须支持:运营手动开 VIP 而不赠送、
                               #   或小叮当侧被手工改小 due_time。
                               #   判定顺序让 jf 优先 ⇒ 绝不会「付了钱反而没数据」
])
def test_tier_truth_table(dd_alive, jf_alive, want):
    pr = userauth.Principal(user_id=1, user_name="u", session_id=1, token_hash="h",
                            dd_alive=dd_alive, jf_alive=jf_alive)
    assert pr.tier == want


def test_principal_public_exposes_two_timelines():
    """顶栏身份牌要分两行显示 —— 否则用户看到「剩30天」却被限制会判定是 bug。"""
    pr = userauth.Principal(user_id=7, user_name="u", session_id=1, token_hash="h",
                            due_time_iso="2026-09-01T00:00:00",
                            jf_vip_until_iso="2026-08-01T00:00:00",
                            dd_alive=True, jf_alive=True)
    pub = pr.public()
    for k in ("tier", "ddAlive", "jfVipUntil", "jfVipDays", "dueTime", "dueDays"):
        assert k in pub, f"public() 缺字段 {k}"
    assert pub["tier"] == "vip"


# ══════════════════════════════════════════════════════════════════════════════
# C. 开关关闭 = 完全退场
# ══════════════════════════════════════════════════════════════════════════════
def test_disabled_means_absent(monkeypatch):
    monkeypatch.setattr(userauth.UA, "cfg", UserAuthCfg(), raising=False)
    assert jfvip.enabled() is False
    assert userauth.jf_session_info(None) == {"enabled": False}


def test_disabled_tier_is_full_access(monkeypatch):
    """VIP 体系关闭时 _tier() 恒 'vip' —— 全功能放行,旧部署零影响。"""
    monkeypatch.setattr(userauth.UA, "cfg", UserAuthCfg(), raising=False)

    class _Req:
        class state:
            user = None
    assert web._tier(_Req()) == "vip"


def test_enabled_requires_login_system(monkeypatch):
    """VIP 体系必须先有登录系统 —— 身份是档位的载体,没有身份谈不上分档。"""
    # 只开 jf_vip_enabled 但没配用户库 → 仍然不生效
    monkeypatch.setattr(userauth.UA, "cfg",
                        UserAuthCfg(jf_vip_enabled=True), raising=False)
    assert jfvip.enabled() is False
    # 配齐用户库才真正生效
    monkeypatch.setattr(userauth.UA, "cfg",
                        UserAuthCfg(host="h", db="d", user="u", jf_vip_enabled=True),
                        raising=False)
    assert jfvip.enabled() is True


def test_three_expiry_gates_all_switch_on_jf_enabled():
    """★ 复查发现的漏项回归钉:到期闸有**三**处(login / validate / sso_exchange),
    三处必须同款分流。漏掉 SSO 那处的话,从续费系统点「进入观测台」快速登录的
    到期用户依旧被 403 挡在门外 —— 而那正是最该被引导去开通的一批人。"""
    src = py_code(APP_DIR / "userauth.py")
    n = len(re.findall(r"if not dd_alive and not c\.jf_enabled:", src))
    assert n == 3, (
        f"到期闸分流点应恰好 3 处(login / validate / sso_exchange),实得 {n} —— "
        f"少一处就有一条登录路径把 free 档用户挡在开通页之外")


def test_tier_is_defensive_against_non_principal():
    """★ _tier() 在**每个数据请求**上都要跑,抛异常就是 500(SSE 里更会打死整条流)。
    _req_user 返回的是「request.state.user 里的任何东西」——必须容错。
    取不到/取到非法 tier 时按最宽松的 'vip' 放行:宁可少收一次钱,
    也绝不让付费用户看到 500。"""
    import types
    from app import web
    from app.settings import UserAuthCfg
    old = userauth.UA.cfg
    try:
        userauth.UA.cfg = UserAuthCfg(host="h", db="d", user="u", jf_vip_enabled=True)

        class _Stub:            # 没有 .tier(项目既有测试的身份桩就是这形态)
            user_id = 7

        class _Bad:             # 有 .tier 但值非法
            tier = "hacked"

        for obj, want in ((_Stub(), "vip"), (_Bad(), "vip")):
            req = types.SimpleNamespace(state=types.SimpleNamespace(user=obj))
            assert web._tier(req) == want, f"{type(obj).__name__} 未安全回落"
        # 真 Principal 仍按实际档位
        pr = userauth.Principal(1, "u", 1, "h", dd_alive=True, jf_alive=False)
        req = types.SimpleNamespace(state=types.SimpleNamespace(user=pr))
        assert web._tier(req) == "basic"
    finally:
        userauth.UA.cfg = old
