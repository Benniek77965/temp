# -*- coding: utf-8 -*-
"""
test_repeat_guard.py — 重现观察期(《灵机推演重现观察期优化方案.md》)回归钉
================================================================================
病灶:稀有冷号(如 9 号 500x)刚开出的下一局,M2/M3 近因模型把其短窗概率抬高
3~5 倍,叠加轮换赤字(常年顶着 ±cap)的 e^{λ·debt}≈11× 加成,乘积峰值恰落在
「刚开出之后」—— 生产口径回放(1275859/2678075/3746870 三房 7 天 34,982 成熟
局):上局出稀有 → 本局四码仍带 = 3/4/9 号各 498/749/291 次,其中 628 次还借
85 分位 z 升进主位,即用户投诉的「上一回合刚出 9,这回合的灵机推演又推 9」。

实地核查(36,278 真机局)证明**九兽危险率对间隔全平坦**(|z|≤1.8;9 号紧随再出
3.02% ≈ 基率 3.56%,z−1.1,N=1292;9×9 转移 χ²=67.0/df64 与独立不可区分)⇒
刚出后的概率飙升没有预测力;把该号份额推迟到间隔更大的时刻统计等价、观感更优
(34,982 局配对实测:缺陷 →16/93/0、主位 →67,命中 +0.04pp p=0.833 纯噪声)。
「当下稀有档」由 rg_pmax=0.075 按 24h 滑窗频率动态圈定;真·时段性扎堆(历史上
旧样本的 4 号、新样本 3746870 房的 3 号)由「房间自证豁免」四关(m≥rg_minm /
k≥4 / 复现率≥1.6×基率 / z≥rg_zpos)在证据充分时按窗放行(落款「随势跟进」)。

观察期只整形「何时带」:份额闭环(赤字账本)照常累积、期满优先补发;保底
(patrol)不受约束(饿死保护优先);被迫在册(保底/换血回退)时座次降权沉入防区。
开关关闭时与现行引擎**逐局字节级等价**(三房 36,188/36,188 逐字段全同,离线
门禁见 window_audit/analyze_repeat.py --gate)。

本文件是可长期跑的仓内钉(不依赖 PG/Redis/真机 DB):
  ① 配置三方一致:引擎 dataclass ⇄ config.yaml ⇄ config_registry 同键同值;
  ② 开关关 = 全刻度失效(等价门禁的仓内代理),且非 showcase 风格恒惰性;
  ③ 硬不变量:上局刚出的受罩稀有号,本局不再入选(保底/换血回退除外,且均有
     落款);即便被迫在册也绝不占主位(座次降权);
  ④ 保底优先:观察期不得饿死任何号 —— patrol 保底照常把它抬回;
  ⑤ 房间自证豁免:窗内紧随复现四关齐备时放行,且落款「随势跟进」自解释;
  ⑥ 状态零增量:未新增任何 kv 字段,explore_state 键集与关态逐字段同构;
  ⑦ 极端刻度不崩:θ/cap/pmax 拨到边界 predict() 不得抛异常。
"""
from __future__ import annotations

import json
import os
import random
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "backend_async"))
os.environ.setdefault("STA_ENGINE_DIR", str(ROOT / "jiufa_data"))

from app.predictor_bridge import PredictorBridge  # noqa: E402
import spell_tamer_monitor as E  # noqa: E402
from app import config_registry as reg  # noqa: E402
import yaml  # noqa: E402

COLD5 = (3, 4, 5, 6, 9)

# 定稿刻度(与 config.yaml / config_registry 同源)。引擎 dataclass 的 repeat_guard
# 缺省特意为 0 —— 裸引擎嵌入方拿到的是「未开刀」姿态,由部署配置显式开启。
FINAL_DIALS = {
    "rg_theta": 0.35, "rg_cap": 20, "rg_pmax": 0.075,
    "rg_seat_damp": 0.25, "rg_minm": 30, "rg_zpos": 2.5,
}
RG_KEYS = ("repeat_guard",) + tuple(FINAL_DIALS)

BASE_CFG = {  # 生产口径(config.yaml prediction 段的引擎相关子集)
    "predict_mode": "adaptive", "adaptive_lambda": 0.3,
    "explore_style": "showcase", "explore_patrol": 35,
    "showcase_q": 0.78, "showcase_kdist": "45,30,15",
    "seat_order": "recency", "hedge_eta": 0.15, "hedge_mix": 0.02,
    "anti_stubborn": 1, "as_alpha": 0.08, "as_alpha_ord": 0.14,
    "as_mcap_hot": 0.12, "as_mcap_cold": 0.18, "as_gamma": 0.15,
    "as_pen_cap": 8, "as_pen_on_hit": 0, "as_breaker": 3, "as_khyst": 0.05,
    "as_cooldown": 0, "as_beta": 0.3, "as_agecap": 24,
    "showcase_rotate": 1, "sc_fp_depth": 12, "sc_eta_cold": 1.0,
    "sc_eta_hot": 20.0, "sc_floor_cold": 0.08, "sc_floor_hot": 0.0,
    "sc_lambda": 0.6, "sc_debt_cap": 4.0, "sc_repeat_cap": 3, "sc_beta_off": 1,
}
ON = {"repeat_guard": 1, **FINAL_DIALS}

# 真机口径的出怪频率(1275859/2678075/3746870 三房 7 天合并实测,单位 %);
# 固定种子 ⇒ 驱动序列可复现。
REAL_W = {1: 18.37, 2: 15.70, 3: 4.93, 4: 6.52, 5: 9.33,
          6: 9.67, 7: 15.72, 8: 16.19, 9: 3.56}


def _seq(n: int, seed: int = 20260801):
    rnd = random.Random(seed)
    ids, w = list(REAL_W), [REAL_W[c] for c in REAL_W]
    return rnd.choices(ids, weights=w, k=n)


def _drive(cfg_extra, outcomes=None, n_rounds=320, warm=520, seed=20260801):
    """因果驱动器:predict → 落地下一局出怪 → 结算 → 再 predict。
    kv 逐局经 bridge 往返(与 worker._settle_and_predict 同语义)。"""
    bridge = PredictorBridge({**BASE_CFG, **cfg_extra}, {})
    full = list(outcomes) if outcomes is not None else _seq(warm + n_rounds, seed)
    n_rounds = len(full) - warm
    kv, recs = {}, []
    prev = None
    for i in range(n_rounds):
        seq = full[:warm + i]
        res, dirty = bridge.run_prediction("t", seq, kv)
        kv.update(dirty)
        four = tuple(res["main"]) + tuple(res["guard"])
        nxt = full[warm + i]
        recs.append({"four": four, "prev": seq[-1], "actual": nxt,
                     "why": ((res.get("explore") or {}).get("why") or ""),
                     "st": json.loads(kv.get("explore_state") or "{}")})
        if prev is not None:
            kv.update(bridge.update_after_settle(
                "t", {"models": prev["models"], "ens": prev["ens"]}, nxt, kv))
        prev = res
    return recs, kv, bridge


def _gap0_carries(recs, cid):
    """上局刚出 cid、本局四码仍带 cid 的记录(用户投诉的原型场景)。"""
    return [r for r in recs if r["prev"] == cid and cid in r["four"]]


# ── ① 配置三方一致 ────────────────────────────────────────────────────────────
def test_config_three_way_consistency():
    fields = E.PredictionConfig.__dataclass_fields__
    for k in RG_KEYS:
        assert k in fields, f"引擎缺字段 {k}"
    c = E.PredictionConfig()
    # 4.9.7 翻面:三大总开关(anti_stubborn / showcase_rotate / repeat_guard,
    # 即 predictor_bridge._DEAD_SWITCH_KEYS)同批由 0 改为 1,裸引擎缺省
    # == config.yaml 部署刻度(实测逐局四码 300/300 全同)。
    # 放弃的旧纪律要写明白:此前「裸引擎缺省 = 改造前逐字节等价」不再成立。
    # 但那条纪律在 explore_style 缺省由 ceiling_adaptive 改为 showcase 时
    # 就已不可能成立 —— 实测只回退这三个开关、风格仍 showcase 时,与真原版
    # 仅 28/300 局相同。故改取「等于部署刻度」这条可验证的不变量。
    # 原版姿态仍可完整复现:显式置 0 即可(off_switch 系列测试守着)。
    assert int(c.repeat_guard) == 1, "裸引擎缺省必须是开(4.9.7 起,与部署刻度一致)"
    for k, v in FINAL_DIALS.items():
        assert float(getattr(c, k)) == pytest.approx(float(v)), \
            f"引擎缺省 {k} 偏离定稿刻度"

    raw = yaml.safe_load(open(ROOT / "backend_async" / "config.yaml", encoding="utf-8"))
    pred = raw["prediction"]
    assert bool(pred["repeat_guard"]) is True, "部署配置应显式开启重现观察期"
    for k, v in FINAL_DIALS.items():
        assert float(pred[k]) == pytest.approx(float(v)), \
            f"config.yaml {k} 偏离定稿刻度"

    for k in RG_KEYS:
        assert k in reg.PREDICTION_KEYS, f"注册表 PREDICTION_KEYS 缺 {k}"
        f = reg.REGISTRY[f"prediction.{k}"]
        assert f.danger and f.hook == "bridge"
        assert f.default == pred[k], f"注册表默认 {k} 与 config.yaml 漂移"


# ── ② 开关关 = 全刻度失效 + 非 showcase 风格恒惰性 ────────────────────────────
def test_off_switch_makes_all_dials_inert():
    wild = {"rg_theta": 2.0, "rg_cap": 200, "rg_pmax": 0.25,
            "rg_seat_damp": 0.0, "rg_minm": 1, "rg_zpos": 0.0}
    a, _, _ = _drive({"repeat_guard": 0})
    b, _, _ = _drive({"repeat_guard": 0, **wild})
    assert [r["four"] for r in a] == [r["four"] for r in b], \
        "repeat_guard=0 时任何 rg_* 刻度都不得改变输出"
    # 确定性:同配置再跑一遍逐局全同(含 why)
    c, _, _ = _drive({"repeat_guard": 0})
    assert [(r["four"], r["why"]) for r in a] == [(r["four"], r["why"]) for r in c]
    d1, _, _ = _drive(ON)
    d2, _, _ = _drive(ON)
    assert [(r["four"], r["why"]) for r in d1] == [(r["four"], r["why"]) for r in d2], \
        "开态也必须逐局确定(补算/回测自还原的前提)"


@pytest.mark.parametrize("style", ["budget", "norm_cold", "matched", "ceiling_adaptive"])
def test_non_showcase_styles_untouched(style):
    """新刻度全拨极端,非 showcase 风格必须与关态逐局全同。"""
    wild = {"repeat_guard": 1, "rg_theta": 2.0, "rg_cap": 200, "rg_pmax": 0.25,
            "rg_seat_damp": 0.0, "rg_minm": 1, "rg_zpos": 0.0}
    a, _, _ = _drive({"explore_style": style, "repeat_guard": 0}, n_rounds=140)
    b, _, _ = _drive({"explore_style": style, **wild}, n_rounds=140)
    assert [r["four"] for r in a] == [r["four"] for r in b], \
        f"{style} 风格不得受重现观察期刻度影响"


# ── ③ 硬不变量:刚出的受罩稀有号不再入选;被迫在册也不占主位 ──────────────────
def _burst_tail(n=340, seed=20260801):
    """按真机频率抽样,并周期性强插 9(让「刚出 9」的机会足够多、且 9 的赤字
    常态偏高) —— 复刻用户投诉场景的确定性驱动。"""
    full = _seq(520 + n, seed)
    for j in range(520 + 12, 520 + n, 24):
        full[j] = 9
    return full


def test_gap0_rare_never_reenters_discretionarily():
    full = _burst_tail()
    on, _, _ = _drive(ON, outcomes=full)
    off, _, _ = _drive({"repeat_guard": 0}, outcomes=full)
    # 关态:病灶必须可复现(机制不咬人 = 测试对象不存在)
    assert _gap0_carries(off, 9), "关态驱动竟无一次「刚出9仍带9」—— 驱动序列失效"
    # 开态:除保底/换血回退(均有落款)外,一次都不允许
    bad = [r for r in _gap0_carries(on, 9)
           if "保底9号" not in r["why"] and "换血" not in r["why"]]
    assert not bad, (
        f"观察期内 9 号仍被自由带回 {len(bad)} 次,首例 why={bad[0]['why']!r}")
    # 主位铁律:哪怕被保底/换血抬回,也必须沉在防区(座次降权)
    seats = [r for r in _gap0_carries(on, 9) if 9 in r["four"][:2]]
    assert not seats, f"刚出的 9 号进了主位: {[r['four'] for r in seats]}"


def test_expiry_note_labels_the_comeback():
    """期满回归的冷门牵头局,why 应落款「距上次开出 N 局」(观感的可见凭据)。"""
    recs, _, _ = _drive(ON, outcomes=_burst_tail(n=420))
    noted = [r for r in recs if "距上次开出" in r["why"]]
    assert noted, "长驱动后竟无一次「距上次开出N局」落款 —— 期满文案未接上"


# ── ④ 保底优先:观察期不得饿死任何号 ─────────────────────────────────────────
def test_patrol_floor_overrides_guard():
    """把 patrol 压到 4(pending 阈 = 4+11 = 15 局)、观察期封顶拉到 30 局,并把
    9 号钉成全场唯一一枚(热身末局开出 ⇒ 驱动段 gap=0 起步、p̂ 极小 ⇒ 观察期
    顶满 30 局):保底必须在观察期内把它抬回,且落款「保底9号」。"""
    full = _seq(520 + 60, seed=7)
    for j in range(len(full)):          # 清场:9 仅在热身末局出现一次
        if full[j] == 9:
            full[j] = 1
    full[519] = 9
    cfg = {**ON, "explore_patrol": 4, "rg_cap": 30}
    recs, _, _ = _drive(cfg, outcomes=full)
    forced = [r for r in recs if 9 in r["four"] and "保底9号" in r["why"]]
    assert forced, "patrol 保底未能穿透观察期 —— 饿死保护被破坏"
    assert all(9 not in r["four"][:2] for r in forced), \
        "保底抬回的观察期号必须沉在防区,不得占主位"


# ── ⑤ 房间自证豁免:证据充分时放行,且落款自解释 ──────────────────────────────
def test_evidence_waiver_lets_true_streaks_through():
    """构造「稀有但真扎堆」的 9 号窗:总频率钉在 pmax 门内(p̂≈4.7%≤7.5%),
    紧随复现 k=5、复现率≈15%(≥1.6×基率)、z≈+3.2(≥2.5)——
    豁免应放行「刚出 9 → 仍带 9」,且至少一局落款「随势跟进」。"""
    rnd = random.Random(11)
    full = _seq(520 + 300, seed=11)
    for j in range(len(full)):          # 先清场:9 的出现完全由下方脚本控制
        if full[j] == 9:
            full[j] = rnd.choice((1, 7))
    pos, placed, pairs = 24, 0, 0
    while pos < len(full) - 2:          # 每 ~24 局一枚 9;每第 5 枚成对(紧随复现)
        full[pos] = 9
        placed += 1
        if placed % 5 == 0 and pairs < 6:
            full[pos + 1] = 9           # 约 4 对落在热身段筑证据,≥2 对落在驱动段
            pairs += 1
        pos += 24 + rnd.randint(0, 3)
    # 驱动自检:总频率钉在 pmax 门内,而豁免四关(m/k/率/z)在窗内齐备
    assert pairs >= 5 and (full.count(9) + 2) / (len(full) + 18) <= 0.075
    recs, _, _ = _drive(ON, outcomes=full)
    waived = [r for r in _gap0_carries(recs, 9)
              if "保底" not in r["why"] and "换血" not in r["why"]]
    assert waived, "强扎堆证据下豁免未放行 —— 自适应通道未接上"
    assert any("随势跟进" in r["why"] for r in recs), \
        "豁免放行局未见「随势跟进」落款 —— 证据未自解释"


# ── ⑥ 状态零增量:未新增任何 kv 字段 ─────────────────────────────────────────
def test_state_is_zero_delta():
    a, kva, _ = _drive({"repeat_guard": 0}, n_rounds=160)
    b, kvb, _ = _drive(ON, n_rounds=160)
    ka = set(json.loads(kva["explore_state"]))
    kb = set(json.loads(kvb["explore_state"]))
    assert ka == kb, f"观察期不得新增/删减状态字段: 仅关态={ka-kb} 仅开态={kb-ka}"
    # 旧状态(关态产出)直接喂给开态引擎,predict 必须照常工作
    bridge = PredictorBridge({**BASE_CFG, **ON}, {})
    res, _ = bridge.run_prediction("t", _seq(560), dict(kva))
    assert len(set(res["main"] + res["guard"])) == 4


# ── ⑦ 极端刻度不崩 ───────────────────────────────────────────────────────────
@pytest.mark.parametrize("wild", [
    {"rg_theta": 0.0}, {"rg_theta": 2.0, "rg_cap": 1},
    {"rg_cap": 200}, {"rg_pmax": 0.0}, {"rg_pmax": 0.25},
    {"rg_seat_damp": 0.0}, {"rg_seat_damp": 1.0},
    {"rg_minm": 1, "rg_zpos": 0.0}, {"rg_zpos": 16.0},
])
def test_extreme_dials_do_not_crash_predict(wild):
    recs, _, _ = _drive({**ON, **wild}, n_rounds=90)
    assert all(len(set(r["four"])) == 4 for r in recs)
