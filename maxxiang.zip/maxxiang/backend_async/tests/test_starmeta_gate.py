"""
test_starmeta_gate.py — 繁星限流闸门 + 跨进程归一缓存(真实 Redis)
================================================================================
证明批量归一不再惊群打爆繁星:
  · StarMeta 每次繁星请求前过令牌桶(_gate);拿真实 TokenBucket 驱动,统计
    实际打向『繁星』的速率被钳在配置上限内(而非旧实现的数百~上千 req/s)。
  · 跨进程归一缓存:一处解析写入 Redis 后,另一『进程』(第二个 StarMeta 实例)
    读缓存命中,零繁星请求。
用一个替身 session 记录繁星侧请求次数与时间(不发真实网络)。
"""
import asyncio
import os
import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.ratelimit import TokenBucket   # noqa: E402
from app.starmeta import StarMeta       # noqa: E402

REDIS_URL = os.environ.get("STA_TEST_REDIS_URL", "redis://127.0.0.1:6379/15")


def _redis_available() -> bool:
    try:
        import redis
        redis.from_url(REDIS_URL).ping()
        return True
    except Exception:
        return False


pytestmark = pytest.mark.skipif(not _redis_available(),
                                reason="需要 Redis(设 STA_TEST_REDIS_URL)")


class _Resp:
    def __init__(self, text, status=200):
        self._text = text
        self.status = status
        self.headers = {}
    async def __aenter__(self):
        return self
    async def __aexit__(self, *a):
        return False
    async def text(self, errors="ignore"):
        return self._text
    async def json(self, content_type=None):
        return {}


class _FakeSession:
    """替身 aiohttp 会话:记录每次『繁星』请求的时刻;页面解析返回一个含 roomId 的
    页面(让 canon 成功),其余端点返回空。closed=False。"""
    def __init__(self, counter):
        self.counter = counter
        self.closed = False
    def get(self, url, allow_redirects=True):
        self.counter.append(time.monotonic())
        # 完整页面:含 roomId + kugouId + 昵称 + 头像 → _resolve 解析后短路
        # (kugouId>0 且 logo/昵称齐 → 跳过 roomStatus 与 getStarInfo),每次恰好 1 请求
        return _Resp(
            'roomId=2678075 _userkugouid="12345">主播昵称<'
            'https://p1.fx.kgimg.com/fxuserlogo/abc.jpg')
    async def close(self):
        self.closed = True


import redis.asyncio as aioredis  # noqa: E402


async def _mk_redis():
    # 池给足:测试要并发数百次 acquire(),默认 100 会自撞 MaxConnectionsError
    r = aioredis.from_url(REDIS_URL, encoding="utf-8", decode_responses=True,
                          max_connections=600)
    await r.flushdb()
    return r


@pytest.mark.asyncio
async def test_fanxing_bucket_throttles_rate():
    """限流证明:桶把繁星请求钳在配置速率 —— 用『注入的耗时下界』直接验证。
    N 个请求、突发 burst、速率 rps → 至少需 (N-burst)/rps 秒才能全部放行。
    对照:无桶时替身瞬间返回,同样 N 个请求 < 0.1s。"""
    r = await _mk_redis()
    rps, burst, N = 200.0, 40.0, 400
    bucket = TokenBucket(r, "rl:fanxing", rps, burst)
    hits: list[float] = []
    star = StarMeta(bucket=bucket, redis=r)
    star._session = _FakeSession(hits)

    t0 = time.monotonic()
    await asyncio.gather(*(star.canon(str(200000 + i)) for i in range(N)))
    elapsed = time.monotonic() - t0

    assert len(hits) == N
    lower = (N - burst) / rps          # 理论最短放行时间 = 1.8s
    assert elapsed >= lower * 0.85, (
        f"耗时 {elapsed:.2f}s < 限流下界 {lower:.2f}s 的 85% —— 桶未生效")
    # 实测平均速率也应贴近 rps(而非旧实现的数千 req/s)
    rate = N / elapsed
    assert rate <= rps * 1.5, f"繁星速率 {rate:.0f} rps 超过桶上限 {rps} 的 1.5 倍"

    # 对照组:无桶,替身瞬间返回,N 个请求应 < 0.2s(凸显限流确实在起作用)
    r2 = await _mk_redis()
    hits2: list[float] = []
    star2 = StarMeta(redis=r2)           # 不传 bucket
    star2._session = _FakeSession(hits2)
    t1 = time.monotonic()
    await asyncio.gather(*(star2.canon(str(300000 + i)) for i in range(N)))
    nogate = time.monotonic() - t1
    assert len(hits2) == N
    assert nogate < elapsed, "无桶应显著快于有桶(限流引入了真实延迟)"
    await r.aclose()
    await r2.aclose()


@pytest.mark.asyncio
async def test_cross_process_canon_cache_hit():
    r = await _mk_redis()
    hits_a: list[float] = []
    star_a = StarMeta(redis=r)
    star_a._session = _FakeSession(hits_a)
    rid, ok = await star_a.canon("321")
    assert ok and rid == "2678075"
    assert len(hits_a) == 1   # 首次解析打了一次繁星

    # 第二个『进程』的 StarMeta 实例:读跨进程缓存命中,零繁星请求
    hits_b: list[float] = []
    star_b = StarMeta(redis=r)
    star_b._session = _FakeSession(hits_b)
    rid2, ok2 = await star_b.canon("321")
    assert ok2 and rid2 == "2678075"
    assert len(hits_b) == 0, "跨进程缓存未命中,重复打了繁星"
    await r.aclose()
