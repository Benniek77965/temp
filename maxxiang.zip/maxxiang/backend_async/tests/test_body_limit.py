"""
test_body_limit.py — 请求体大小上限(5.3.0 复查补漏)
================================================================================
复查实况:全站没有请求体上限,web 直接监听 0.0.0.0 且前面没有反代;登录 / 注册 / 管理台登录这些
未鉴权端点用 request.json() 一口气读完整个请求体 —— 超大请求体可把(钉死单进程的)web 撑爆。
"""
from __future__ import annotations

import os
import sys

import httpx
from fastapi import FastAPI, Request

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import web  # noqa: E402
from app.web import BodySizeLimitMiddleware  # noqa: E402

CALLS: list = []


def _inner() -> FastAPI:
    a = FastAPI()

    @a.post("/echo")
    async def echo(request: Request):
        b = await request.body()
        CALLS.append(len(b))
        return {"n": len(b)}

    @a.get("/echo")
    async def echo_get():
        CALLS.append("get")
        return {"ok": True}
    return a


async def _raw(app, method: str, headers: list, chunks: list):
    """直接走 ASGI,可以模拟「不带 Content-Length 的分块传输」。"""
    msgs = [{"type": "http.request", "body": c, "more_body": i < len(chunks) - 1} for i, c in enumerate(chunks)]
    sent = []

    async def receive():
        return msgs.pop(0) if msgs else {"type": "http.disconnect"}

    async def send(m):
        sent.append(m)
    scope = {"type": "http", "method": method, "path": "/echo", "raw_path": b"/echo", "headers": headers,
             "query_string": b"", "root_path": "", "scheme": "http", "server": ("t", 80),
             "client": ("203.0.113.1", 1), "http_version": "1.1", "asgi": {"version": "3.0"}}
    await app(scope, receive, send)
    status = next(m["status"] for m in sent if m["type"] == "http.response.start")
    body = b"".join(m.get("body", b"") for m in sent if m["type"] == "http.response.body")
    return status, body


async def test_declared_length_over_limit_is_rejected_before_the_app_runs():
    CALLS.clear()
    app = BodySizeLimitMiddleware(_inner(), max_bytes=100)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t") as c:
        r = await c.post("/echo", content=b"x" * 101)
        assert r.status_code == 413 and r.json()["error"] == "payload_too_large"
        assert CALLS == []                                   # 应用一行都没跑
        r = await c.post("/echo", content=b"x" * 100)        # 恰好等于上限:放行,请求体完整
        assert r.status_code == 200 and r.json() == {"n": 100}
        r = await c.get("/echo")                             # GET 不受影响
        assert r.status_code == 200
    assert CALLS == [100, "get"]


async def test_chunked_body_is_counted_and_replayed_intact():
    CALLS.clear()
    app = BodySizeLimitMiddleware(_inner(), max_bytes=100)
    st, body = await _raw(app, "POST", [], [b"a" * 60, b"b" * 60])          # 未声明长度,累计 120
    assert st == 413 and b"payload_too_large" in body and CALLS == []
    st, body = await _raw(app, "POST", [], [b"a" * 30, b"b" * 30, b"c" * 30])   # 累计 90:原样回放
    assert st == 200 and body == b'{"n":90}' and CALLS == [90]
    st, _ = await _raw(app, "POST", [(b"content-length", b"oops")], [b"a" * 10])  # 非法长度 → 按未声明处理
    assert st == 200


def test_limit_comes_from_env_with_a_safe_default(monkeypatch):
    monkeypatch.delenv("STA_MAX_REQUEST_BYTES", raising=False)
    assert web._max_request_bytes() == 8 * 1024 * 1024
    for raw, want in (("1048576", 1048576), ("0", 8 * 1024 * 1024), ("-5", 8 * 1024 * 1024),
                      ("abc", 8 * 1024 * 1024)):
        monkeypatch.setenv("STA_MAX_REQUEST_BYTES", raw)
        assert web._max_request_bytes() == want, raw


async def test_site_app_has_the_limit_as_the_outermost_layer():
    """整站装配:最后注册 = 最外层(超限请求在一切鉴权 / 解析之前就被挡下)。"""
    first = web.app.user_middleware[0]
    assert first.cls is BodySizeLimitMiddleware
    assert first.kwargs.get("max_bytes") == web._max_request_bytes()
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=web.app), base_url="http://t") as c:
        big = b'{"password":"' + b"x" * (web._max_request_bytes() + 1) + b'"}'
        r = await c.post("/api/auth/login", content=big, headers={"Content-Type": "application/json"})
        assert r.status_code == 413
