"""
test_probability_drift.py — 「官方公示概率表」与实盘出怪频率的漂移守卫
================================================================================
为什么要单独一个文件：仓库里已有的 `test_official_probability.py` 守的是
「表与表之间一致」（constants ↔ mock/data/room-321-config.json ↔ 前端解析），
**守不住「表与现实一致」**。而 4.8.0 的实地核查发现的正是后者：

    仓库自带真机库（三房 7 天 36,278 局，capture 完整度 12,092/12,095，单一
    source、无选择偏差）与 room-321-config.json 的公示概率**系统性不符**：

        号9(沧溟龙 500x)  表内 2.00%  实测 3.561%   z = +21.2
        号3(焚天雀 330x)  表内 3.50%  实测 4.929%   z = +14.8
        号1(镇岳甲  10x)  表内 20.00% 实测 18.375%  z = − 7.7
        拟合优度 χ² = 726.6 (df=8)，p ≈ 1.4e-151，**逐日复现**
        （7 天里号9 的单日 z 落在 +7.1 ~ +8.8），非过期快照、非分房差异
        （房间×号位齐性检验 p=0.441，三房同分布）。

这不是"哪个数字写错了"，而是**公示表与实际发生器不是同一回事**。而这张表是
前端「官方」列、「偏差」2σ 着色、九法阵 `stateOf` 周期 `round(100/p)` 的**唯一
真源** —— 它错，观测台就会给出一个看起来很专业的错误结论，且不报错、不白屏。

── 本文件的处置口径（重要，勿改成"自动纠正"）─────────────────────────────────
**不**用实测频率去覆盖公示表。公示值是游戏方对外声明的事实，观测台的实测频率
是我们自己的估计；用后者冒充前者，等于把估计包装成官方口径 —— 那是另一种失真。
正确做法是：把"已知偏离"钉成机器可校验的常量。于是有两种红：

  ① 偏离**变了**（游戏方改了概率 / 我们换了数据源）→ 本用例红，逼人来看一眼；
  ② 有人把公示表改成实测值（"顺手修一下"）→ 同样红，因为偏离消失了。

任一情况都需要人做一次显式决定，而不是让它继续静默漂着。
"""
from __future__ import annotations

import json
import math
import os
import sqlite3
from collections import Counter

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DB = os.path.join(ROOT, "jiufa_data", "spell_tamer_data.db")
CFG = os.path.join(ROOT, "mock", "data", "room-321-config.json")

# ── 4.8.0 实地核查结论：已知偏离（display_number → 实测占比 %）───────────────
# 复跑：python3 window_audit/prob_drift.py
OBSERVED_PCT = {1: 18.375, 2: 15.695, 3: 4.929, 4: 6.525, 5: 9.331,
                6: 9.673, 7: 15.720, 8: 16.192, 9: 3.561}
OBSERVED_N = 36278
TOL_PP = 0.30          # 允许的复现误差（pp）；实测三房逐房极差 < 0.25pp


def _shipped_table():
    """按 display_number 键入的公示概率（%）。"""
    with open(CFG, encoding="utf-8") as f:
        spells = json.load(f)["spells"]
    return {int(s["display_number"]): float(str(s["probability"]).rstrip("%"))
            for s in spells}


def _observed():
    con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    try:
        rows = con.execute("SELECT custom_id FROM rounds WHERE custom_id IS NOT NULL")
        cnt = Counter(c for (c,) in rows)
    finally:
        con.close()
    n = sum(cnt.values())
    return {c: cnt[c] / n * 100 for c in range(1, 10)}, n


needs_db = pytest.mark.skipif(not os.path.isfile(DB), reason="需要仓库自带真机库")


@needs_db
def test_bundled_db_is_readable_at_all():
    """自带库必须能读 —— 4.8.0 之前它带着一份**陈旧且损坏的 -wal**
    （主库头部写版本=1 即 rollback-journal 模式，却躺着一个 ckpt 序号=9 的 WAL；
    SQLite 套用后 b-tree 直接坏：`invalid page number 218103808`），
    导致 `rounds` 整表不可读、test_pred_replay 六个真机钉全红。
    处置：删掉 -wal / -shm 两个陈旧边车（主库自身 integrity_check = ok，
    36,278 行一行不少）。本用例防止它们被误再次带回来。"""
    con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    try:
        assert con.execute("PRAGMA quick_check").fetchone()[0] == "ok"
        assert con.execute("SELECT count(*) FROM rounds").fetchone()[0] > 0
    finally:
        con.close()
    for side in (DB + "-wal", DB + "-shm"):
        assert not os.path.isfile(side), (
            f"{os.path.basename(side)} 又回来了 —— 它是陈旧边车，会把主库读成 malformed")


@needs_db
def test_observed_frequencies_still_reproduce():
    """实测频率必须与登记值一致；不一致 = 数据源换了或游戏方改了概率，需人工判读。"""
    obs, n = _observed()
    assert n == OBSERVED_N, f"自带库局数变了：{n} vs 登记 {OBSERVED_N}"
    bad = {c: (round(obs[c], 3), OBSERVED_PCT[c])
           for c in range(1, 10) if abs(obs[c] - OBSERVED_PCT[c]) > TOL_PP}
    assert not bad, f"实测频率与登记值偏离 > {TOL_PP}pp：{bad}"


@needs_db
def test_known_divergence_between_shipped_table_and_reality_is_still_there():
    """把"公示表 ≠ 实盘"这件事钉住。
    它红只有两种可能：偏离变了，或有人把公示表改成了实测值 —— 两种都要人来看。"""
    table = _shipped_table()
    obs, n = _observed()
    chi = 0.0
    z = {}
    for c in range(1, 10):
        p0 = table[c] / 100.0
        k = obs[c] / 100.0 * n
        exp = n * p0
        chi += (k - exp) ** 2 / exp
        z[c] = (k - exp) / math.sqrt(n * p0 * (1 - p0))
    # 已知形态：整体极显著，且 9 号 / 3 号是主要贡献者，方向为正
    assert chi > 300, (
        f"公示表与实盘的拟合优度 χ²={chi:.1f} 已回落到不显著 —— "
        "要么游戏方改了概率，要么有人把公示表改成了实测值。"
        "**不要**直接改表让本用例变绿：请先确认新表的来源，再同步更新 OBSERVED_PCT。")
    assert z[9] > 15 and z[3] > 10, (
        f"主要偏离方向变了（z9={z[9]:.1f}, z3={z[3]:.1f}）—— 需重新核查")


@needs_db
def test_frontend_deviation_baseline_is_documented_not_silently_wrong():
    """前端「偏差」列 = 实际占比 − 公示概率，2σ 着色。在当前偏离下，满窗
    （24h ≈ 1727 局）时 9 号会**恒定**被判"偏热"、1 号恒定"偏冷"——
    与盘面无关，纯粹是基线错。本用例把这个后果量化出来，别让它继续隐形。"""
    table = _shipped_table()
    obs, _ = _observed()
    N24 = 1727
    stuck = []
    for c in range(1, 10):
        p0 = table[c] / 100.0
        sigma = math.sqrt(p0 * (1 - p0) / N24) * 100
        if abs(obs[c] - table[c]) > 2 * sigma:
            stuck.append((c, round(obs[c] - table[c], 2), round(2 * sigma, 2)))
    assert stuck, "偏离已消失（见上一条用例的说明）"
    # 记录当前受影响的号位数量，变化即需复核
    assert len(stuck) >= 2, f"受影响号位数变了：{stuck}"
