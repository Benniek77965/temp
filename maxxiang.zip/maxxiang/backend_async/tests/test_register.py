"""
test_register.py — 注册系统(4.0.0)· 防恶意注册纵深 R0–R8
================================================================================
分层(与登录测试同构):
  · 纯单元(恒跑,零外部依赖):账号形态闸 R5、PoW 校验 R2、邀请码归一、
    IP 分桶、EXTRA_COLS 解析、口令编码/形态。
  · 静态纪律钉 T5(恒跑):扫描全部 Python 源,断言对 tb_user 的 SQL 动词仅
    SELECT 与**恰一处** INSERT;任何 UPDATE/DELETE/ALTER/TRUNCATE 命中即红。
    ——把 §2「旧行绝对零改动、仅 INSERT 新行」新纪律写进测试,不是口头承诺。
  · 活体对拍 T3(装了 node 才跑):从 app.js 抠出注册版 SHA-256 求解 Worker 交
    node 执行,产出的 nonce 交 Python 校验器互证(复用 test_proof_of_browser 手法)。
  · 前后端契约 T4(恒跑):口令长度/蜜罐字段名/Worker 标记等前后端同值钉住。
  · 联测 T2/T6(需本地 1:1 MariaDB,127.0.0.1:3307):三模式全流程、quota=1 并发
    抢注恰 1 成、重名回滚占坑回吐、autoLogin 二分、封禁命中登录 banned。不可达整层 skip。

默认部署(未配置 STA_USERDB_HOST / 未设 PASS_SHAPE)下 reg_mode 恒 off ——
其余测试文件不感知本模块存在,3.9.5 行为契约由既有套件继续钉住。
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import pytest
import pytest_asyncio

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import userauth  # noqa: E402
from app.settings import UserAuthCfg  # noqa: E402

APP_JS = Path(__file__).resolve().parents[2] / "assets" / "app.js"
ADMIN_JS = Path(__file__).resolve().parents[2] / "assets" / "admin.js"
INDEX_HTML = Path(__file__).resolve().parents[2] / "index.html"
ADMIN_HTML = Path(__file__).resolve().parents[2] / "admin.html"
APP_DIR = Path(__file__).resolve().parents[1] / "app"


# ══ 纯单元:账号形态闸 R5 ══════════════════════════════════════════════════════
def _cfg_bare(**kw) -> UserAuthCfg:
    base = dict(host="x", db="x", user="x", reg_pass_shape="md5", reg_mode="open")
    base.update(kw)
    return UserAuthCfg(**base)


def test_username_rules():
    """4.0.6:字符集收窄为 [A-Za-z0-9](运营拍板,**纯数字放行**)。
    只约束新增注册,不追溯存量 —— 存量口径由 test_username_rule_is_registration_only 钉。"""
    userauth.UA.cfg = _cfg_bare()
    # 放行面:纯字母 / 纯数字 / 混合 / 大小写混排
    for n in ("abc", "12", "a1b2", "MixedCase99", "0", "x" * 20):
        got, err, _ = userauth.validate_reg_username(n)
        if len(n) >= 2:
            assert got == n and not err, (n, err)
    # 长度边界(闸序:长度在字符集之前,空串也走长度提示)
    assert userauth.validate_reg_username("a")[1] == "name_invalid"
    assert userauth.validate_reg_username("x" * 21)[1] == "name_invalid"
    assert userauth.validate_reg_username("ab")[0] == "ab"
    assert userauth.validate_reg_username("x" * 20)[0] == "x" * 20
    for empty in ("", None, "   "):
        got, err, msg = userauth.validate_reg_username(empty)
        assert got is None and err == "name_invalid" and "字符" in msg, empty
    # strip 后合法(登录侧同口径)
    assert userauth.validate_reg_username(" ab ")[0] == "ab"
    # 拒绝面:中文 / 空白 / 控制符 / emoji / 全角字母(同形字仿冒)/ 常见符号
    for n in ("正常名", "小明", "a b", "a\tb", "名字😀", "한글이름",
              "ＡＢＣ", "ab-cd", "ab_cd", "ab.cd", "a@b", "用户1"):
        got, err, msg = userauth.validate_reg_username(n)
        assert got is None and err == "name_invalid", (n, got, err)
        assert msg == "用户名只能包含英文字母和数字", (n, msg)
    # 保留名(内置 + 大小写折叠):ASCII 条目照旧回 name_reserved
    for n in ("admin", "Admin", "ADMIN", "root", "test", "guest"):
        assert userauth.validate_reg_username(n)[1] == "name_reserved", n
    # 中文保留名此后由**字符集闸先行拦下**,错误码降为 name_invalid ——
    # 这是刻意的:对中文输入者「只能包含英文字母和数字」远比「该用户名不可用」有用。
    # 名单里的中文条目**保留不删**,字符集一旦放宽即刻重新生效(下方 reg_reserved 同理)。
    for n in ("管理员", "客服", "官方", "超管"):
        assert userauth.validate_reg_username(n)[1] == "name_invalid", n
    assert set(("管理员", "客服", "官方")) <= userauth._RESERVED_BUILTIN, \
        "内置保留名里的中文条目不得因 4.0.6 被删除(字符集放宽后需立即重新生效)"
    # 追加保留名:ASCII 生效;中文条目被字符集闸前置拦下(配置本身仍合法)
    userauth.UA.cfg = _cfg_bare(reg_reserved="张三,special")
    assert userauth.validate_reg_username("张三")[1] == "name_invalid"
    assert userauth.validate_reg_username("SPECIAL")[1] == "name_reserved"
    assert "张三" in userauth._reserved_names()


def test_username_rule_is_registration_only():
    """★ 4.0.6 最要紧的一条:字符集**只约束新增注册**,存量账号绝不受影响。

    存量库里既有中文用户名,也有外部续费系统建的手机号型名(`+8613800138000`
    这类,`assets/admin.js` 的 CSV 公式注入注释里有实据)。登录若跟着收窄,这些人
    第二天全部登不进 —— 本用例静态钉死登录闸内不含任何字符集校验。
    """
    src = (APP_DIR / "userauth.py").read_text(encoding="utf-8")
    body = src.split("async def _authenticate(", 1)[1].split("\nasync def ", 1)[0]
    assert "_REG_USER_RE" not in body, \
        "登录闸 _authenticate 里出现了注册用的字符集正则 —— 存量中文/手机号型用户名会被锁在门外"
    # 正向:注册闸拒绝的名字,登录闸的长度/空值前置检查依然放行(不在此拦)
    assert "len(user_name) > 50" in body, "登录闸的长度前置检查不见了"


def test_username_charset_constant_is_hardcoded_not_hot_config():
    """字符集**刻意写死**:一旦挪进参数中心,前端拿不到热改值,必然出现
    「后端已收窄、前端还在放行」的漂移(用户白付一次 PoW 才被打脸)。
    与 _REG_PASS_MIN/MAX 的既有姿态一致。

    注:初版把筛选写成 `"user" in k.rsplit(".",1)[-1]`,而注册族的键尾是
    `reg_reserved` / `reg_name_10m` 这类,**永远筛不出东西**,断言恒真、形同虚设
    (自查时实测:加一个假的 `userauth.reg_name_charset` 进注册表,测试照样绿)。
    现改为「键尾同时含 name/user 语义词 **与** charset/pattern/regex/rule 语义词」,
    并由 test_charset_nail_actually_fires 以变异测试证明它真的会红。
    """
    from app import config_registry  # noqa: PLC0415
    bad = _charset_keys_in_registry(config_registry.REGISTRY)
    assert not bad, f"用户名字符集不应出现在参数中心(会造成前后端漂移):{bad}"
    assert userauth._REG_USER_RE.pattern == r"^[A-Za-z0-9]+$"


def _charset_keys_in_registry(registry) -> list:
    """注册表里「疑似在配置用户名字符集」的键。抽成函数是为了让变异测试能直接喂假数据。"""
    out = []
    for k in registry:
        tail = k.rsplit(".", 1)[-1].lower()
        if re.search(r"name|user", tail) and re.search(r"charset|pattern|regex|_re$|rule", tail):
            out.append(k)
    return out


def test_charset_nail_actually_fires():
    """变异测试:给注册表塞一个假的字符集键,上一根钉必须能抓出来。
    没有这一步,「断言恒真」的虚设钉子会一直装作绿色(本项目已栽过一次,见上)。"""
    fake = {"userauth.reg_mode": 1, "userauth.reg_name_10m": 1,   # 正常键:不得误报
            "userauth.reg_reserved": 1}
    assert _charset_keys_in_registry(fake) == [], "误报:正常的注册参数被当成字符集键"
    for mutant in ("userauth.reg_name_charset", "userauth.user_name_pattern",
                   "userauth.reg_username_regex", "userauth.reg_name_rule"):
        assert _charset_keys_in_registry({**fake, mutant: 1}) == [mutant], \
            f"漏报:把 {mutant} 塞进参数中心时,钉子没有变红"


def test_password_rules_5_to_16_no_composition():
    """运营拍板:5–16 位字符,**无字符组合限制**(纯数字/纯字母/任意搭配都行)。"""
    userauth.UA.cfg = _cfg_bare()
    for shape in ("plain", "md5", "sha1", "sha256"):
        assert userauth.validate_reg_password("12345", shape)[0], f"纯数字5位@{shape}"
        assert userauth.validate_reg_password("aaaaaa", shape)[0], "纯小写"
        assert userauth.validate_reg_password("ABCDEF", shape)[0], "纯大写"
        assert userauth.validate_reg_password("你好世界密码", shape)[0] or shape != "plain"
        assert userauth.validate_reg_password("p@ss w0rd!", shape)[0], "含空格/符号"
        assert userauth.validate_reg_password("x" * 16, shape)[0], "16位上界"
        # 长度越界
        assert not userauth.validate_reg_password("1234", shape)[0], "4位太短"
        assert not userauth.validate_reg_password("x" * 17, shape)[0], "17位太长"
        assert not userauth.validate_reg_password("", shape)[0]
        # 控制字符恒拒
        assert not userauth.validate_reg_password("ab\x00cd", shape)[0]


def test_password_plain_gbk_only():
    """plain 形态须 gbk 可编码(列物理约束);摘要形态存 hex,无此限制。"""
    userauth.UA.cfg = _cfg_bare()
    assert not userauth.validate_reg_password("emoji😀pw", "plain")[0]
    assert userauth.validate_reg_password("emoji😀pw", "md5")[0]     # 摘要不受限


def test_password_encoding_matches_login_verify():
    """注册编码 ⇄ 登录 verify_password 必须互通(否则观测台注册的用户登不进)。"""
    pw = "MyPass123"
    for shape in ("plain", "md5", "sha1", "sha256"):
        stored = userauth.encode_reg_password(pw, shape)
        assert userauth.verify_password(pw, stored), f"{shape} 编码后 verify 失败"
    # 中文口令(UTF-8 字节口径)
    stored = userauth.encode_reg_password("中文口令", "md5")
    assert stored == hashlib.md5("中文口令".encode()).hexdigest()
    assert userauth.verify_password("中文口令", stored)


# ══ 纯单元:R2 PoW ═════════════════════════════════════════════════════════════
def test_pow_check_and_transform():
    userauth.UA.cfg = _cfg_bare()
    # 暴力找一个满足 8 位前导零的 nonce,校验器须认;改 salt 则不认
    salt = "deadbeefdeadbeef"
    prefix = userauth._reg_pow_transform(salt)
    nonce = None
    for i in range(1 << 20):
        d = hashlib.sha256(f"{prefix}:{i}".encode()).digest()
        if userauth._lead_zero_bits(d) >= 8:
            nonce = str(i)
            break
    assert nonce is not None
    assert userauth.reg_pow_check(salt, nonce, 8)
    assert not userauth.reg_pow_check(salt, nonce, 30)         # 位数要求生效
    assert not userauth.reg_pow_check("otherotherother0", nonce, 8)  # salt 绑定
    assert not userauth.reg_pow_check(salt, "!!bad!!", 8)      # nonce 形态校验


def test_lead_zero_bits():
    assert userauth._lead_zero_bits(bytes([0x00, 0x00, 0xFF])) == 16
    assert userauth._lead_zero_bits(bytes([0x0F, 0xFF])) == 4
    assert userauth._lead_zero_bits(bytes([0x80])) == 0
    assert userauth._lead_zero_bits(bytes([0x01])) == 7


def test_reg_transform_is_pow_answer():
    """注册 R2 的执行证明变换与 L2 的 _pow_answer 同源(黄金向量互证)。"""
    from app import web
    for s in ("", "a", "中文测试", "!@#%^&*()_+-="):
        assert userauth._reg_pow_transform(s) == web._pow_answer(s)


# ══ 纯单元:邀请码 / IP 分桶 / EXTRA_COLS ══════════════════════════════════════
def test_invite_code_norm():
    c = userauth.gen_invite_code()
    assert len(c) == 16 and all(ch in userauth._CROCK for ch in c)
    # 分段展示 ⇄ 归一往返
    disp = userauth.fmt_invite_code(c)
    assert disp.count("-") == 3 and userauth.norm_invite_code(disp) == c
    # 手滑宽恕:O→0 / I→1 / L→1、小写、空格
    assert userauth.norm_invite_code(c.lower()) == c
    raw = c.replace("0", "O").replace("1", "I")
    assert userauth.norm_invite_code(raw) == c
    # 非法
    assert userauth.norm_invite_code("short") == ""
    assert userauth.norm_invite_code("U" * 16) == ""          # U 不在字母表


def test_ip_bucket_ipv6_64():
    assert userauth._ip_bucket("1.2.3.4") == "1.2.3.4"
    b = userauth._ip_bucket("2001:db8:abcd:1234:5678::1")
    assert b == "2001:db8:abcd:1234::/64"
    # 同 /64 归一为同桶
    assert userauth._ip_bucket("2001:db8:abcd:1234:ffff::9") == b
    assert userauth._net24("10.0.0.99") == "10.0.0.0/24"


def test_extra_cols_parse():
    userauth._REG_RT["extra_raw"] = None                       # 清缓存
    userauth.UA.cfg = _cfg_bare(reg_extra_cols='{"create_time":"$now","qq":""}')
    assert userauth.reg_extra_cols() == {"create_time": "$now", "qq": ""}
    userauth._REG_RT["extra_raw"] = None
    userauth.UA.cfg = _cfg_bare(reg_extra_cols="")
    assert userauth.reg_extra_cols() == {}
    # 非法列名 / 覆盖基础列 / 非法 JSON → None(fail-closed)
    for bad in ('{"drop table":"x"}', '{"user_name":"y"}', 'not-json', '[1,2]'):
        userauth._REG_RT["extra_raw"] = None
        userauth.UA.cfg = _cfg_bare(reg_extra_cols=bad)
        assert userauth.reg_extra_cols() is None, bad


def test_mode_gating():
    # PASS_SHAPE 未配 → 强制 off(即便 reg_mode=open 且登录已启用)
    userauth.UA.cfg = _cfg_bare(reg_pass_shape="", reg_mode="open")
    assert userauth.reg_mode_configured() == "off"
    userauth.UA.cfg = _cfg_bare(reg_pass_shape="bogus", reg_mode="invite")
    assert userauth.reg_mode_configured() == "off"
    # 登录未启用 → off
    userauth.UA.cfg = UserAuthCfg(reg_pass_shape="md5", reg_mode="open")   # host 空
    assert userauth.reg_mode_configured() == "off"
    # 齐备 → 生效
    userauth.UA.cfg = _cfg_bare(reg_pass_shape="md5", reg_mode="invite")
    assert userauth.reg_mode_configured() == "invite"


# ══ T5:静态纪律钉 —— tb_user 只读 + 恰一处 INSERT ═════════════════════════════
def _iter_py_sources():
    for p in sorted(APP_DIR.rglob("*.py")):
        if "__pycache__" in p.parts:
            continue
        yield p


def test_tb_user_sql_discipline():
    """扫描全部 app/*.py:对 tb_user(或 user_table 变量指代的表)的**直接** SQL
    操作,动词允许清单如下,越界即红 —— §2 纪律的机器保证。

    ┌ 4.2.0 修订(九法 VIP)────────────────────────────────────────────────┐
    │ 原纪律是「UPDATE 恒为零」。VIP 体系要「开通即赠送同时长小叮当」,      │
    │ 必须写 tb_user.due_time —— 这是产品需求与既有纪律的正面冲突,         │
    │ **显式松绑、不偷偷绕过**:                                            │
    │   · UPDATE  恰好 1 处,且必须在 jfvip.py 的 _grant_tx() 内            │
    │   · INSERT  恰好 1 处,且必须在 userauth.py 的 _register_tx() 内(旧)  │
    │   · DELETE / ALTER / TRUNCATE / REPLACE / DROP  仍恒为零             │
    │ 位置约束由 test_jfvip_discipline.py 与 test_register_tx_is_only_     │
    │ insert_site 分别钉死。                                               │
    └──────────────────────────────────────────────────────────────────────┘

    「直接操作」= 危险动词紧邻 tb_user 目标;仅在注释/无关 PG 建表串里出现
    "tb_user" 字样不算。tb_user 的写法含字面量与 `{...user_table}` 反引号插值。
    """
    tbl = r"(?:`?tb_user`?|`?\{[a-zA-Z_.]*user_table[^}]*\}`?)"
    # 恒为零的危险动词(UPDATE 已移出,单独按白名单计数)
    danger = re.compile(
        r"\b(?:DELETE\s+FROM|ALTER\s+TABLE|TRUNCATE(?:\s+TABLE)?|"
        r"REPLACE\s+INTO|DROP\s+TABLE(?:\s+IF\s+EXISTS)?)\s+" + tbl, re.I)
    ins_re = re.compile(r"\bINSERT\s+(?:IGNORE\s+)?INTO\s+" + tbl, re.I)
    upd_re = re.compile(r"\bUPDATE\s+" + tbl, re.I)

    def _strip_line_comments(text: str) -> str:
        """剥掉整行 # 注释再扫 —— 注释不会执行,把它算进「写操作」是**假阳性**。
        (4.2.0 实测触发:jfvip 的说明性注释里出现「UPDATE」与表名邻接即被误判。)
        只剥「整行注释」,行尾注释与字符串内容原样保留 —— 保证真正的 SQL 一个不漏。"""
        return "\n".join("" if ln.lstrip().startswith("#") else ln
                          for ln in text.split("\n"))

    insert_hits, update_hits = [], []
    for path in _iter_py_sources():
        src = _strip_line_comments(path.read_text(encoding="utf-8"))
        for m in danger.finditer(src):
            raise AssertionError(
                f"{path.name}: 对 tb_user 的禁用写操作!片段: "
                f"{src[max(0, m.start()-20):m.end()+40]!r}")
        for m in ins_re.finditer(src):
            insert_hits.append((path.name, src[m.start():m.end() + 60]))
        for m in upd_re.finditer(src):
            update_hits.append((path.name, src[m.start():m.end() + 60]))

    assert len(insert_hits) == 1, (
        f"对 tb_user 的 INSERT 应恰好一处(§2:仅注册新增一行),实得 "
        f"{len(insert_hits)}:\n" + "\n".join(f"  {f}: {s}" for f, s in insert_hits))
    assert insert_hits[0][0] == "userauth.py", (
        f"唯一的 tb_user INSERT 应在 userauth.py(_register_tx),实为 "
        f"{insert_hits[0][0]}")
    assert len(update_hits) == 1, (
        f"对 tb_user 的 UPDATE 应恰好一处(4.2.0:仅九法VIP开通时赠送小叮当时长),"
        f"实得 {len(update_hits)}:\n"
        + "\n".join(f"  {f}: {s}" for f, s in update_hits))
    assert update_hits[0][0] == "jfvip.py", (
        f"唯一的 tb_user UPDATE 应在 jfvip.py(_grant_tx),实为 {update_hits[0][0]}")


def test_register_tx_is_only_insert_site():
    """加固:唯一 INSERT 必须位于 _register_tx 函数体内。"""
    src = (APP_DIR / "userauth.py").read_text(encoding="utf-8")
    i = src.find("async def _register_tx(")
    assert i >= 0, "_register_tx 丢失"
    # 下一个顶层 def / 分隔线视作函数结束
    j = src.find("\nasync def ", i + 10)
    k = src.find("\ndef ", i + 10)
    end = min(x for x in (j, k, len(src)) if x > 0)
    body = src[i:end]
    assert re.search(r"INSERT\s+INTO\s+`?\{[^}]*user_table", body, re.I), (
        "_register_tx 内应含 tb_user 的 INSERT")
    # 函数体外不应再有第二处 tb_user INSERT
    outside = src[:i] + src[end:]
    assert not re.search(r"INSERT\s+INTO\s+`?(\{[^}]*user_table[^}]*\}|tb_user)",
                         outside, re.I), "函数体外不得有第二处 tb_user INSERT"


def test_no_block_table_writes_touch_tb_user():
    """封禁走 guantai_user_block —— 断言封禁 DAO 不含 tb_user 写。"""
    src = (APP_DIR / "userauth.py").read_text(encoding="utf-8")
    i = src.find("async def blocks_set(")
    j = src.find("\nasync def ", i + 10)
    body = src[i:j if j > 0 else len(src)]
    assert "guantai_user_block" in body
    assert "tb_user" not in body and "user_table" not in body


# ══ T4:前后端契约 ════════════════════════════════════════════════════════════
def test_frontend_backend_password_bounds():
    """口令 5–16 位:后端常量 ⇄ app.js 即时校验同值;maxlength 须**严格大于**上限。

    4.0.1 修订:旧不变式要求 maxlength==16(与规则同宽)。实测这是个陷阱 ——
    浏览器把 21 位粘贴静默截成前 16 位,两框同截恰好一致 → 校验通过 → 注册成功,
    但用户拿完整口令登录必败。新不变式:maxlength 必须 > _REG_PASS_MAX(超长原样
    入框,由 JS/后端可见地拦下),两框同宽(不同宽会让"两次不一致"误报),并与
    登录框(authPass)同宽(病态长粘贴的兜底口径全站一致)。"""
    assert (userauth._REG_PASS_MIN, userauth._REG_PASS_MAX) == (5, 16)
    if INDEX_HTML.is_file():
        html = INDEX_HTML.read_text(encoding="utf-8")
        reg_ml = [int(m.group(1)) for m in
                  re.finditer(r'id="regPass2?"[^>]*maxlength="(\d+)"', html)]
        assert len(reg_ml) == 2, "index.html 应恰有 regPass/regPass2 两只口令框"
        assert reg_ml[0] == reg_ml[1], "两只注册口令框 maxlength 应同宽"
        assert reg_ml[0] > userauth._REG_PASS_MAX, \
            "注册口令 maxlength 必须大于规则上限,否则超长粘贴被静默截进合规区(4.0.1)"
        auth_ml = re.search(r'id="authPass"[^>]*maxlength="(\d+)"', html)
        if auth_ml:
            assert reg_ml[0] == int(auth_ml.group(1)), "注册与登录口令框 maxlength 应同宽"
        # 4.0.1 复查补:用户名同一陷阱结构 —— maxlength 若等于规则上限(20),
        # 21+ 字符会被静默截进合规区注册成功,完整用户名登录必败。
        name_ml = re.search(r'id="regUser"[^>]*maxlength="(\d+)"', html)
        assert name_ml is not None, "index.html 应有 regUser maxlength"
        assert int(name_ml.group(1)) > userauth._REG_USER_MAX, \
            "注册用户名 maxlength 必须大于规则上限,否则超长输入被静默截进合规区(4.0.1)"
        auth_user_ml = re.search(r'id="authUser"[^>]*maxlength="(\d+)"', html)
        if auth_user_ml:
            assert int(name_ml.group(1)) == int(auth_user_ml.group(1)), \
                "注册与登录用户名框 maxlength 应同宽"
    if APP_JS.is_file():
        js = APP_JS.read_text(encoding="utf-8")
        assert "pw.length < 5 || pw.length > 16" in js, \
            "app.js 注册密码即时校验应为 5–16 位"


def test_frontend_backend_username_charset():
    """★ 4.0.6 契约钉:用户名字符集在**三处**必须逐字同规则 ——
    后端 `_REG_USER_RE`、`app.js` 的即时校验正则、以及两侧的提示文案。

    为什么必须对拍而不是各写各的:前端只做体验、后端才是闸,但两者一旦漂移,
    症状是**单向且昂贵**的 —— 前端比后端松,用户白算 0.3–1.5s 的 PoW、白烧一次
    R1 配额(默认 5 次/时)才被打脸;前端比后端严,合法用户被前端挡死、后端永远
    等不到这次请求。口令长度早有同款钉(test_frontend_backend_password_bounds),
    本用例把用户名补齐。
    """
    assert userauth._REG_USER_RE.pattern == r"^[A-Za-z0-9]+$"
    assert (userauth._REG_USER_MIN, userauth._REG_USER_MAX) == (2, 20)
    if APP_JS.is_file():
        js = APP_JS.read_text(encoding="utf-8")
        assert "if (!/^[A-Za-z0-9]+$/.test(name)){ setRegMsg('用户名只能包含英文字母和数字'); return; }" in js, \
            "app.js 的用户名字符集即时校验缺失或与后端 _REG_USER_RE 不同规则"
        # 旧的空格闸与 emoji 代理对预检已被字符集闸取代,不得残留(残留=双重文案、
        # 且代理对闸会抢在字符集闸之前给出「无法保存」这种过时提示)
        assert "if (/\\s/.test(name)){ setRegMsg('用户名不能包含空格'); return; }" not in js, \
            "app.js 仍残留已被字符集闸取代的空格闸"
        assert "if (/[\\uD800-\\uDFFF]/.test(name))" not in js, \
            "app.js 仍残留已被字符集闸取代的 emoji 代理对预检"
    if INDEX_HTML.is_file():
        html = INDEX_HTML.read_text(encoding="utf-8")
        m = re.search(r'id="regUser"[^>]*placeholder="([^"]*)"', html)
        assert m, "index.html 找不到 regUser 的 placeholder"
        assert "英文" in m.group(1) and "数字" in m.group(1), \
            f"用户名输入框应在输入前就告知字符集规则,当前:{m.group(1)!r}"


def test_reg_log_writes_are_charset_sanitized():
    """★ 4.0.6 防回退钉:`_log_reg` 的四个文本字段必须走 `gbk_text()`,不得用裸切片。

    实地复现的缺陷(非推断):连接字符集是 gbk,裸串里只要有 gbk 表示不了的字符
    (emoji / 韩文 / 越南文 / 土耳其文 / CJK 扩展区…),pymysql 编码整条 SQL 时抛
    UnicodeEncodeError;`_q` 只对连接层异常重试,该异常原样上抛后被 `_log_reg` 自己的
    `contextlib.suppress` 吃掉 —— **整行审计静默消失,连日志都没有**。
    其中 `ua` 是客户端完全可控的 User-Agent,于是 `User-Agent: 😀` 即可让该来源的
    全部失败注册在「注」视图查无此事,R7 同源聚类随之失明。
    同文件 `_log_login` 一直是 gbk_text 四件套,`_log_reg` 是唯一漏网者。
    """
    src = (APP_DIR / "userauth.py").read_text(encoding="utf-8")
    body = src.split("async def _log_reg(", 1)[1].split("\n\n\n", 1)[0]
    assert "guantai_reg_log" in body, "抠错了函数体"
    for bad in ('str(name or "")[:50]', 'str(ip or "")[:45]',
                'str(ua or "")[:200]', 'str(fp or "")[:16]'):
        assert bad not in body, f"_log_reg 又用回裸切片 {bad} —— 含非 gbk 字符时整行审计会静默丢失"
    for good in ("gbk_text(name, 50)", "gbk_text(ip, 45)",
                 "gbk_text(ua, 200)", "gbk_text(fp, 16)"):
        assert good in body, f"_log_reg 缺少 {good}"
    # 实证 gbk_text 确实把不可编码字符钝化成可写入的串(而非抛错)
    userauth.UA.cfg = _cfg_bare()
    for probe in ("😀", "한글", "ệ", "𠀀"):
        out = userauth.gbk_text(probe, 50)
        out.encode("gbk")             # 不抛 = 这行审计写得进去


def test_reg_log_filter_has_charset_guard():
    """★ 4.0.6 补漏钉:`reg_log_page` 的筛选参数必须过 `gbk_ok`。

    本文件「字符集安全化」段(4.2.9)立的规矩是两套口径:**写**换 '?'(gbk_text)、
    **筛选**命中零行(gbk_ok)。全量审计发现 `reg_log_page` 是 userauth.py +
    jfvip.py 里**唯一**漏掉筛选侧那道闸的分页器 —— jfvip 的 cards_page /
    grants_page / orders_page 三处早已就位。

    不加时:UnicodeEncodeError 在编码 SQL 时抛出(语句根本没发出去),穿到
    `/reg/log` 端点被兜成 503 `userdb_unavailable` —— 库好好的,却报「用户库不可用」,
    把运维引向一个不存在的故障。真库实测:「按用户名精确筛」里输入含 emoji 的名字即复现。
    """
    src = (APP_DIR / "userauth.py").read_text(encoding="utf-8")
    body = src.split("async def reg_log_page(", 1)[1].split("\nasync def ", 1)[0]
    assert "gbk_ok" in body, "reg_log_page 的筛选参数没有编码闸 —— 管理台会报假的「用户库不可用」"
    assert '"1=0"' in body, "筛选侧应以「命中零行」收敛,不得改用 gbk_text 换 '?'(会去查一个不同的串)"
    # 反向:筛选侧绝不能用写入侧的口径
    assert "gbk_text(q_name" not in body and "gbk_text(q_ip" not in body, \
        "筛选侧误用了写入侧口径(gbk_text)—— 会静默去查一个不同的串"


def test_gate_input_border_contrast_and_focus_cascade():
    """**4.0.2 回归钉**:门内输入描边对卡底的 WCAG 对比度 ≥3.0(1.4.11 非文本
    组件线),从 app.css 源码解算真实比值 —— 数字写死会在改色时变成假绿。

    背景(实测,非推断):默认 --line-strong #bccec5 对 --card #fbfdfc 仅
    1.61:1,且输入框底色与卡底同值,描边是未聚焦时唯一的组件边界。4.0.2 在门内
    (仅门内,与 16px 同一取舍)以 .auth-card .modal-form input 覆写描边色。

    第二条断言钉住一个级联陷阱:该选择器与既有 .modal-form input:focus 特异性
    同为 (0,2,1),门内节在文件更后 —— 若不显式重申 focus 描边,聚焦态的品牌绿
    会被平票后到者静默吃掉(去掉重申规则本测试必须变红,经变异测试验证)。"""
    app_css = Path(__file__).resolve().parents[2] / "assets" / "app.css"
    if not app_css.is_file():
        pytest.skip("前端不在本仓")
    css = app_css.read_text(encoding="utf-8")

    def _hex(pat: str) -> str:
        m = re.search(pat, css)
        assert m, f"app.css 缺少匹配: {pat}"
        return m.group(1)

    card = _hex(r"--card:\s*#([0-9a-fA-F]{6})")
    border = _hex(r"\.auth-card \.modal-form input\{border-color:#([0-9a-fA-F]{6})\}")

    def _lum(h: str) -> float:
        def f(v: float) -> float:
            v /= 255.0
            return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
        r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
        return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)

    hi, lo = sorted((_lum(card), _lum(border)), reverse=True)
    ratio = (hi + 0.05) / (lo + 0.05)
    assert ratio >= 3.0, (
        f"门内输入描边 #{border} 对卡底 #{card} 实算 {ratio:.2f}:1 < 3.0 —— "
        f"低于 WCAG 1.4.11;改色请保持 ≥3.0(建议留 ≥0.2 冗余抗抗锯齿减淡)")
    assert re.search(r"\.auth-card \.modal-form input:focus\{border-color:"
                     r"var\(--brand\)\}", css), (
        "缺少 .auth-card .modal-form input:focus 的描边重申 —— 与既有 "
        ".modal-form input:focus 特异性平票、门内规则在文件更后,不重申会把"
        "聚焦态品牌绿描边静默吃掉(4.0.2)")


def test_frontend_honeypot_field_name_matches():
    """蜜罐字段名前后端同值(改一处忘另一处 → 蜜罐失效或误伤)。"""
    assert userauth._REG_HP_FIELD == "contact"
    if INDEX_HTML.is_file():
        html = INDEX_HTML.read_text(encoding="utf-8")
        assert 'id="regContact" name="contact"' in html


def test_worker_markers_present():
    """求解 Worker 源码的对拍标记必须在(T3 活体对拍靠它抠源码)。"""
    if APP_JS.is_file():
        js = APP_JS.read_text(encoding="utf-8")
        assert "__JF_REG_WORKER_BEGIN__" in js and "__JF_REG_WORKER_END__" in js


def test_admin_js_write_bodies_are_serialized():
    """**防复发钉**:`assets/admin.js` 的 `api()` 与 `assets/app.js` 的 `api()` 契约
    **相反** —— 前者把 opt 原样透传给 fetch(**不** JSON.stringify),后者会自动
    序列化。因此管理台一切写请求的 `body` 必须自行传字符串;传裸对象会让 fetch
    发出 `[object Object]`,服务端 `await request.json()` 失败 → 400,而**前端只
    弹一句「失败」**,极难定位(4.0.0 复查实测:「注」视图 6 个写操作全中招)。

    本测试扫描 admin.js 全部非 GET 的 api() 调用,要求 body 是
    JSON.stringify(...) 或字符串字面量。新增管理台写操作时若忘了序列化,当场变红。
    """
    if not ADMIN_JS.is_file():
        pytest.skip("assets/admin.js 不在预期路径")
    src = ADMIN_JS.read_text(encoding="utf-8")
    bad = []
    for m in re.finditer(r"api\(\s*([^,]+),\s*\{(.*?)\}\s*\)", src, re.S):
        opt = m.group(2)
        if "method" not in opt:
            continue                      # GET(无 method)不带 body
        if re.search(r"method:\s*'GET'", opt):
            continue
        bm = re.search(r"body:\s*(.+?)(?:,\s*[a-zA-Z_]+:|$)", opt, re.S)
        if not bm:
            continue                      # 无 body 的写请求(服务端 _body() 容忍)
        val = bm.group(1).strip().rstrip(",")
        if not val.startswith(("JSON.stringify", "'", '"', "`")):
            line = src[:m.start()].count("\n") + 1
            bad.append(f"L{line}: api({m.group(1).strip()[:40]}…) body={val[:60]}")
    assert not bad, (
        "admin.js 的 api() 不做 JSON.stringify —— 以下写请求传了裸对象,"
        "线上必然 400:\n  " + "\n  ".join(bad))


def test_admin_reg_view_ids_exist():
    """「注」视图引用的每个 DOM id,要么由它自己渲染、要么是 admin.html 常驻。
    (4.0.0 复查发现过:邀请码弹窗读 #giCount 等元素,而 ask() 用 textContent
    渲染 body 根本不会创建它们 → 点「批量生成」即 TypeError。)"""
    if not (ADMIN_JS.is_file() and ADMIN_HTML.is_file()):
        pytest.skip("管理台资源不在预期路径")
    src = ADMIN_JS.read_text(encoding="utf-8")
    i = src.find("async function renderReg()")
    assert i >= 0, "renderReg 丢失"
    j = src.find("\nfunction renderDeploy", i)
    body = src[i:j if j > 0 else len(src)]
    refd = set(re.findall(r"\$\('#([A-Za-z0-9_]+)'\)", body))
    made = set(re.findall(r"id=\\?[\"']([A-Za-z0-9_]+)\\?[\"']", body))
    static = set(re.findall(r'id="([A-Za-z0-9_]+)"',
                            ADMIN_HTML.read_text(encoding="utf-8")))
    missing = sorted(refd - made - static)
    assert not missing, f"「注」视图引用了不存在的元素 id:{missing}"


def test_reg_params_are_hot_not_restart():
    """**防复发钉**:注册相关参数必须是 🟢 即时热更,不许标 🔴 需重启。

    4.0.0 线上反馈逼出来的 bug:`reg_pass_shape` / `reg_extra_cols` / `reg_captcha`
    当初误标 `RESTART`。而 `apply_snapshot(mode="hot")` 对 RESTART 项**直接跳过
    set_path**,于是管理台改完:值只进 PG 版本库、**不进运行中的 settings** ——
    ① 卡片回读仍是旧值(用户看到「选了却显示未选择」);
    ② `_reg_shape()` 读到空 → `reg_mode_configured()` 强制 off → **注册入口永不出现**,
       哪怕 reg_mode 已经是 open(mode 是 hot、其前置 shape 是 restart,组合致命)。

    这三项运行期全是现读的(`_reg_shape()`/`reg_extra_cols()` 按原串比对缓存/
    `_captcha_check` 现读 provider),技术上根本不需要重启。
    """
    from app import config_registry as reg
    bad = []
    for key, f in reg.REGISTRY.items():
        if not key.startswith("userauth.reg_"):
            continue
        if f.readonly or f.hot == reg.RESERVED:
            continue                      # 凭据类只读项不参与
        if f.hot == reg.RESTART:
            bad.append(key)
    assert not bad, (
        "注册参数被标为 🔴 需重启 —— 管理台改完不会进运行时,"
        f"会重演「选了却显示未选择 + 注册入口出不来」:{bad}")


def test_reg_pass_shape_gates_effective_mode():
    """`reg_pass_shape` 是 `reg_mode` 的前置条件:shape 空 → 生效档强制 off。
    钉住这条因果,顺带说明为什么 shape 必须与 mode 同为热更等级(否则 mode 改了
    也会被空 shape 压回 off)。"""
    from app import userauth as _ua
    from app.settings import UserAuthCfg
    saved = _ua.UA.cfg
    try:
        _ua.UA.cfg = UserAuthCfg(host="h", db="d", user="u", password="p",
                                 reg_mode="open", reg_pass_shape="")
        assert _ua.reg_mode_configured() == "off", "shape 空时必须强制 off"
        _ua.UA.cfg.reg_pass_shape = "md5"
        assert _ua.reg_mode_configured() == "open", "shape 配好后 open 才生效"
        # 两者热更等级必须一致,否则「改了 mode 却被旧 shape 压回 off」
        from app import config_registry as reg
        assert (reg.REGISTRY["userauth.reg_mode"].hot
                == reg.REGISTRY["userauth.reg_pass_shape"].hot), \
            "reg_mode 与其前置 reg_pass_shape 的热更等级必须一致"
    finally:
        _ua.UA.cfg = saved


def test_tc3_signature_golden_vector():
    """腾讯云 TC3-HMAC-SHA256 签名(`_tc3_auth`)的黄金向量 + 自洽性钉。

    验证码 tencent 路径在测试里从不真正发网,签名一旦悄悄漂移(改了 canonical
    串顺序、SignedHeaders、派生密钥链任一环)线上会 100% 签名不一致而全灭。这里:
    ① 用固定输入锁死签名输出(防未来编辑漂移);
    ② 独立按腾讯官方 2-header 规范重算一遍,证明实现本身正确(不是把 bug 钉住)。
    """
    import hashlib as _h
    import hmac as _hm
    import time as _t
    from app.userauth import _tc3_auth

    payload = (b'{"CaptchaType": 9, "Ticket": "tkt", "Randstr": "rnd", '
               b'"UserIp": "1.2.3.4", "CaptchaAppId": 100, "AppSecretKey": "sk"}')
    auth = _tc3_auth("AKIDfixed123", "secretfixed456",
                     "captcha.tencentcloudapi.com", "captcha", payload, 1700000000)
    sig = re.search(r"Signature=([0-9a-f]+)", auth).group(1)
    # ① 黄金向量(固定输入 → 固定签名)
    assert sig == "3872068875616a5fa027dedf35fd6483c4116a3ac56eb742ec86801754bebe96", \
        f"TC3 签名漂移:{sig}"
    # ② 独立按官方 2-header 规范重算,证明算法正确(与官方 SDK 同一步骤)
    date = _t.strftime("%Y-%m-%d", _t.gmtime(1700000000))
    canonical = ("POST\n/\n\ncontent-type:application/json; charset=utf-8\n"
                 "host:captcha.tencentcloudapi.com\n\ncontent-type;host\n"
                 + _h.sha256(payload).hexdigest())
    scope = f"{date}/captcha/tc3_request"
    sts = ("TC3-HMAC-SHA256\n1700000000\n" + scope + "\n"
           + _h.sha256(canonical.encode()).hexdigest())
    kd = _hm.new(b"TC3secretfixed456", date.encode(), _h.sha256).digest()
    ks = _hm.new(kd, b"captcha", _h.sha256).digest()
    ksign = _hm.new(ks, b"tc3_request", _h.sha256).digest()
    indep = _hm.new(ksign, sts.encode(), _h.sha256).hexdigest()
    assert sig == indep, "TC3 实现与官方规范独立重算不一致"
    # 报文格式:Credential 含 scope、SignedHeaders 固定
    assert f"Credential=AKIDfixed123/{scope}" in auth
    assert "SignedHeaders=content-type;host," in auth


# ══ T3:活体对拍(node)—— JS 求解器 ⇄ Python 校验器 ═══════════════════════════
def _node():
    return shutil.which("node")


def _extract_worker_src() -> str:
    js = APP_JS.read_text(encoding="utf-8")
    m = re.search(r"/\*__JF_REG_WORKER_BEGIN__\*/`(.*?)`/\*__JF_REG_WORKER_END__\*/",
                  js, re.S)
    assert m, "app.js 里找不到注册 Worker 源码标记"
    return m.group(1)


@pytest.mark.skipif(not APP_JS.is_file() or _node() is None,
                    reason="需要 node 才能做注册求解器 JS↔Python 活体对拍")
def test_js_solver_python_verifier_parity():
    """**头号守卫**:从 app.js 抠出**生产链路的两段真源码** —— powAnswer(主线程
    执行证明变换)与求解 Worker(纯 JS SHA-256 + 前导零穷举)—— 在 node 里按
    doRegister 的**同一分工**跑:prefix = powAnswer(salt) → worker 对 prefix 穷举
    nonce;产出的 nonce 交 Python 的 reg_pow_check(salt, nonce, bits) 校验。
    任何一侧漂移(变换改了 / 拼接格式改了 / 分工改了)当场红,而不是上线后
    「所有人都注册不了」。附带核对 Worker 的 SHA-256 与 hashlib 逐例一致。"""
    worker = _extract_worker_src()
    js = APP_JS.read_text(encoding="utf-8")
    i = js.find("function powAnswer(")
    assert i >= 0, "app.js 里找不到 powAnswer —— 注册执行证明前端实现丢失?"
    j = js.find("{", i)
    depth, k = 0, j
    while k < len(js):
        if js[k] == "{":
            depth += 1
        elif js[k] == "}":
            depth -= 1
            if depth == 0:
                break
        k += 1
    pow_fn = js[i:k + 1]

    salts = ["deadbeef", "", "中文salt测试abcd", "ffffffffffffffff",
             "0123456789abcdef0123456789abcdef"]
    bits = [12, 13, 10, 12, 11]
    sha_cases = ["abc", "中文测试", "x" * 200, ""]
    harness = (
        "var self = {};\n"
        + worker + "\n"
        + pow_fn + "\n"
        + "var out = { solve: [], sha: [], prefix: [] };\n"
        + "var _handler = self.onmessage;\n"
        + "self.postMessage = function(d){ if(d.nonce!=null) out.solve.push(d.nonce);"
        + " if(d.hex!=null) out.sha.push(d.hex); };\n"
        + "var salts = " + json.dumps(salts) + ";\n"
        + "var bits = " + json.dumps(bits) + ";\n"
        + "var shaCases = " + json.dumps(sha_cases) + ";\n"
        # ← 与 app.js doRegister 完全同一分工:主线程算 powAnswer,worker 收 prefix
        + "for (var i=0;i<salts.length;i++){ var p = powAnswer(salts[i]);"
        + " out.prefix.push(p); _handler({data:{type:'solve',id:1,prefix:p,bits:bits[i]}}); }\n"
        + "for (var j=0;j<shaCases.length;j++) _handler({data:{type:'sha256',id:2,"
        + "text:shaCases[j]}});\n"
        + "console.log(JSON.stringify(out));\n")
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False,
                                     encoding="utf-8") as f:
        f.write(harness)
        path = f.name
    try:
        r = subprocess.run([_node(), path], capture_output=True, text=True,
                           timeout=120, check=True)
        got = json.loads(r.stdout.strip())
    finally:
        Path(path).unlink(missing_ok=True)
    # ① JS 的 powAnswer 与 Python 的变换逐例一致(前缀就是两侧的接缝)
    for salt, pfx in zip(salts, got["prefix"]):
        assert pfx == userauth._reg_pow_transform(salt), \
            f"powAnswer 漂移:salt={salt!r} JS={pfx} PY={userauth._reg_pow_transform(salt)}"
    # ② JS 求得的 nonce 必过 Python 校验器(整条链闭合)
    for salt, b, nonce in zip(salts, bits, got["solve"]):
        assert userauth.reg_pow_check(salt, nonce, b), \
            f"JS 求得 nonce={nonce} 未通过 Python 校验(salt={salt!r} bits={b})"
    # ③ Worker 的 SHA-256 实现 ⇄ hashlib 逐例一致
    for s, hx in zip(sha_cases, got["sha"]):
        assert hx == hashlib.sha256(s.encode()).hexdigest(), f"Worker SHA-256 漂移: {s!r}"


# ══ 联测(本地 1:1 复刻用户库;不可达整层 skip)══════════════════════════════════
_HOST, _PORT = "127.0.0.1", int(os.environ.get("STA_TEST_USERDB_PORT", "3307"))


def _db_reachable() -> bool:
    try:
        with socket.create_connection((_HOST, _PORT), timeout=0.6):
            return True
    except OSError:
        return False


needs_db = pytest.mark.skipif(not _db_reachable(),
                              reason=f"需要本地用户库 {_HOST}:{_PORT}(MariaDB 1:1 复刻)")


def _cfg(**kw) -> UserAuthCfg:
    base = dict(host=_HOST, port=_PORT, db="fanxing_changkong_user_db",
                user="fanxing_admin", password="fanxing_admin,.", charset="gbk",
                cache_ttl_s=0.0, reg_pass_shape="md5", reg_mode="open",
                reg_pow_bits=8,               # 联测用最低难度,穷举快
                reg_ip_hourly=10000, reg_ip_daily=10000, reg_ip_ok_daily=10000,
                reg_chal_ip_10m=10000, reg_name_10m=10000,
                reg_min_fill_s=0)      # 联测免等填表时长;R4 秒提交另有专测
    base.update(kw)
    return UserAuthCfg(**base)


try:
    import fakeredis.aioredis as _fakered
    _HAVE_FAKEREDIS = True
except Exception:
    _HAVE_FAKEREDIS = False

needs_redis = pytest.mark.skipif(not _HAVE_FAKEREDIS,
                                 reason="需要 fakeredis 提供注册限流/挑战存储")


async def _solve(salt: str, bits: int) -> str:
    for i in range(1 << 22):
        prefix = userauth._reg_pow_transform(salt)
        d = hashlib.sha256(f"{prefix}:{i}".encode()).digest()
        if userauth._lead_zero_bits(d) >= bits:
            return str(i)
    raise AssertionError("solve failed")


@pytest_asyncio.fixture()
async def reg_env():
    """初始化(含 fakeredis)→ 用例 → 收尾。每次清空注册相关表,用例间零串味。"""
    async def _setup(cfg: UserAuthCfg):
        r = _fakered.FakeRedis(decode_responses=False) if _HAVE_FAKEREDIS else None
        await userauth.init(cfg, r)
        assert userauth.UA.schema_ok or await userauth._ensure_schema()
        # 清注册表(不动 tb_user 的既有 5 行;只删本套注册出来的)。
        # LIKE 的 % 必须走参数化 —— 直接写进 SQL 会被 aiomysql 当格式占位符。
        await userauth._q("DELETE FROM guantai_invite_code")
        await userauth._q("DELETE FROM guantai_reg_log")
        await userauth._q("DELETE FROM guantai_user_block")
        # 4.0.6:账号名随字符集收窄改为纯字母数字(regtest*),故模式由 `regtest\_%`
        # 放宽为 `regtest%`;复刻库的 5 行种子(测试用户A/plainuser/expireduser/
        # banneduser/sha1user)无一以 regtest 开头,不会被误删。`2026013800` 是
        # test_username_charset_end_to_end 的纯数字用例账号;`注册\_%` 为 4.0.6 前
        # 的遗留名,保留一行以清掉开发机上长期存活的旧行。
        for pat in ("regtest%", "2026013800", "注册\\_%"):
            await userauth._q("DELETE FROM tb_user WHERE user_name LIKE %s", (pat,))
        userauth._REG_RT["pwcol_ok"] = None
        userauth._REG_RT["extra_raw"] = None
        return r
    yield _setup
    with _noraise():
        for pat in ("regtest%", "2026013800", "注册\\_%"):
            await userauth._q("DELETE FROM tb_user WHERE user_name LIKE %s", (pat,))
    await userauth.close()
    userauth.UA.cfg = None
    userauth.UA.cache = {}
    userauth.UA.schema_ok = False


class _noraise:
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return True


async def _register(name, pw, **extra):
    """走一次完整 register()(自动取挑战 + 解 PoW)。→ (status, body, token)。"""
    st, chal = await userauth.reg_challenge("9.9.9.9", "")
    assert st == 200, chal
    nonce = await _solve(chal["salt"], chal["bits"])
    body = {"userName": name, "password": pw, "challengeId": chal["challengeId"],
            "nonce": nonce}
    body.update(extra)
    return await userauth.register(body, "9.9.9.9", "pytest")


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_open_register_zero_gift_no_autologin(reg_env):
    """open + 赠送 0 天(R0):注册成功但 autoLogin=False,且该账号登录被 expired 挡下。"""
    await reg_env(_cfg(reg_trial_days=0))
    st, body, tok = await _register("regtestzero", "pw123")
    assert st == 200 and body["ok"] and body["autoLogin"] is False and tok is None
    # R0 硬闸:零赠送 = due_time=NOW() = 登录即过期
    lst, lbody, ltok = await userauth.login("regtestzero", "pw123", "1.1.1.1", "t")
    assert lst == 403 and lbody["error"] == "expired"


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_username_charset_end_to_end(reg_env):
    """★ 4.0.6 端到端:字符集闸在真实注册链上的三条性质。

    ① 中文名 → 400 name_invalid,且**在 PoW 之前**就被拒(校验顺序「廉价→昂贵」
       的既有纪律:R5 形态闸排在 R2 挑战核销之前)。以「挑战未被核销、可原样复用」
       反证之 —— 若顺序被改成先核销后校验,用户每试错一个名字就白烧一枚挑战。
    ② 纯数字名放行(4.0.6 运营明确要求),且能正常登录 —— 证明它不是「校验放过、
       入库或登录再挂掉」的半吊子放行。
    ③ 全角字母 ＡＢＣ 被拒:同形字仿冒面在闸内闭合(gbk 能编码它,旧规则会放行)。
    """
    await reg_env(_cfg(reg_trial_days=3))
    st, chal = await userauth.reg_challenge("9.9.9.9", "")
    assert st == 200, chal
    for bad in ("中文名字", "ＡＢＣ", "ab-cd", "小明"):
        st, body, _ = await userauth.register(
            {"userName": bad, "password": "pw123",
             "challengeId": chal["challengeId"], "nonce": "0"}, "9.9.9.9", "pytest")
        assert st == 400 and body["error"] == "name_invalid", (bad, st, body)
        assert body["message"] == "用户名只能包含英文字母和数字", (bad, body)
    # ① 反证:上面四次全被形态闸拦下,挑战**从未被核销** —— 同一枚挑战配上正确 nonce
    #    此刻仍能完成一次真实注册。若哪天有人把校验挪到核销之后,这一步必 400。
    nonce = await _solve(chal["salt"], chal["bits"])
    st, body, tok = await userauth.register(
        {"userName": "2026013800", "password": "pw123",
         "challengeId": chal["challengeId"], "nonce": nonce}, "9.9.9.9", "pytest")
    assert st == 200 and body["ok"] is True, body
    # ② 纯数字名登得进(不是半吊子放行)
    lst, _, ltok = await userauth.login("2026013800", "pw123", "1.1.1.1", "t")
    assert lst == 200 and ltok, lst
    state, pr, _ = await userauth.validate(ltok)
    assert state == "ok" and pr.user_name == "2026013800"


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_open_register_with_gift_autologin(reg_env):
    """open + 赠送 3 天:注册即登录(autoLogin=True + 会话可校验)。"""
    await reg_env(_cfg(reg_trial_days=3))
    st, body, tok = await _register("regtestgift", "pw123")
    assert st == 200 and body["autoLogin"] is True and tok
    state, pr, _ = await userauth.validate(tok)
    assert state == "ok" and pr.user_name == "regtestgift"
    assert 2 <= (body["user"]["dueDays"] or 0) <= 3
    # 且用注册口令能正常登录(编码 ⇄ 校验闭环)
    lst, _, _ = await userauth.login("regtestgift", "pw123", "1.1.1.1", "t")
    assert lst == 200


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_password_5_to_16_accepted_end_to_end(reg_env):
    """5–16 位任意字符口令都能注册并登录(无组合限制,端到端验证)。"""
    await reg_env(_cfg(reg_trial_days=3))
    for i, pw in enumerate(["12345", "純數字都行", "p@ss w0rd!", "x" * 16]):
        name = f"regtestpw{i}"
        st, _, _ = await _register(name, pw)
        assert st == 200, f"{pw!r} 注册失败"
        lst, _, _ = await userauth.login(name, pw, "1.1.1.1", "t")
        assert lst == 200, f"{pw!r} 登录失败"


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_invite_mode_flow(reg_env):
    """invite:无码寸步难行;有效码赠送随码;配额耗尽后拒。"""
    await reg_env(_cfg(reg_mode="invite"))
    # 无码 → invite_required
    st, chal = await userauth.reg_challenge("9.9.9.9", "")
    nonce = await _solve(chal["salt"], chal["bits"])
    st, body, _ = await userauth.register(
        {"userName": "regtestnoinv", "password": "pw123",
         "challengeId": chal["challengeId"], "nonce": nonce}, "9.9.9.9", "t")
    assert st == 400 and body["error"] == "invite_required"
    # 造 quota=1 赠 2 天的码
    codes = await userauth.invites_generate(1, 1, 2, 0, "test")
    code = codes[0]
    st, body, tok = await _register("regtestinv1", "pw123", inviteCode=code)
    assert st == 200 and body["autoLogin"] is True and (body["user"]["dueDays"] or 0) >= 1
    # 该码已耗尽 → 第二次 invite_exhausted
    st, body, _ = await _register("regtestinv2", "pw123", inviteCode=code)
    assert st == 400 and body["error"] == "invite_exhausted"


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_invite_quota1_concurrent_exactly_one(reg_env):
    """T2 并发原子:quota=1 的码被 10 路并发抢注 → 恰 1 成,used_count=1。"""
    import asyncio
    await reg_env(_cfg(reg_mode="invite"))
    codes = await userauth.invites_generate(1, 1, 2, 0, "race")
    code = codes[0]

    async def one(i):
        st, chal = await userauth.reg_challenge(f"9.9.9.{i}", "")
        nonce = await _solve(chal["salt"], chal["bits"])
        return await userauth.register(
            {"userName": f"regtestrace{i}", "password": "pw123",
             "challengeId": chal["challengeId"], "nonce": nonce,
             "inviteCode": code}, f"9.9.9.{i}", "t")

    results = await asyncio.gather(*[one(i) for i in range(10)])
    wins = [r for r in results if r[0] == 200]
    assert len(wins) == 1, f"quota=1 应恰 1 成,实得 {len(wins)}"
    inv = await userauth.invite_lookup(code)
    assert int(inv["used_count"]) == 1                        # 占坑精确,无超发


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_duplicate_name_rejected_and_quota_refunded(reg_env):
    """重名:第二次注册回 name_taken;若带码,占坑回吐(used_count 不因失败前进)。"""
    await reg_env(_cfg(reg_mode="invite"))
    codes = await userauth.invites_generate(1, 5, 2, 0, "dup")   # quota 5 够两次
    code = codes[0]
    st, _, _ = await _register("regtestdup", "pw123", inviteCode=code)
    assert st == 200
    used_after_1 = int((await userauth.invite_lookup(code))["used_count"])
    assert used_after_1 == 1
    # 同名再注册 → name_taken;used_count 必须仍是 1(事务回滚 → 占坑回吐)
    st, body, _ = await _register("regtestdup", "pw456", inviteCode=code)
    assert st == 400 and body["error"] == "name_taken"
    assert int((await userauth.invite_lookup(code))["used_count"]) == 1


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_honeypot_and_fast_submit_generic_reason(reg_env):
    """R4:蜜罐命中与秒提交都回通用 bad_request(不教学),审计留真实 reason。"""
    await reg_env(_cfg(reg_min_fill_s=3))
    # ① 蜜罐有值 → bad_request(reason=honeypot;蜜罐在挑战核销之前拦下)
    st, chal = await userauth.reg_challenge("9.9.9.9", "")
    nonce = await _solve(chal["salt"], chal["bits"])
    st, body, _ = await userauth.register(
        {"userName": "regtesthp", "password": "pw123",
         "challengeId": chal["challengeId"], "nonce": nonce,
         "contact": "bot-filled"}, "9.9.9.9", "t")
    assert st == 400 and body["error"] == "bad_request"
    row = await userauth._q("SELECT reason FROM guantai_reg_log WHERE reason='honeypot' "
                            "ORDER BY id DESC LIMIT 1", fetch="one")
    assert row and row["reason"] == "honeypot"
    # ② 秒提交(挑战签发后 <3s 即交)→ 同样通用 bad_request,审计 reason=too_fast
    st, chal = await userauth.reg_challenge("9.9.9.9", "")
    nonce = await _solve(chal["salt"], chal["bits"])
    st, body, _ = await userauth.register(
        {"userName": "regtestfast", "password": "pw123",
         "challengeId": chal["challengeId"], "nonce": nonce}, "9.9.9.9", "t")
    assert st == 400 and body["error"] == "bad_request", "秒提交应被 R4 拦下"
    row = await userauth._q("SELECT reason FROM guantai_reg_log WHERE reason='too_fast' "
                            "ORDER BY id DESC LIMIT 1", fetch="one")
    assert row and row["reason"] == "too_fast"
    # ③ 等过最短填表时长后,同样的表单可以注册成功(证明闸只挡快、不挡人)
    import asyncio as _aio
    st, chal = await userauth.reg_challenge("9.9.9.9", "")
    nonce = await _solve(chal["salt"], chal["bits"])
    await _aio.sleep(3.2)
    st, body, _ = await userauth.register(
        {"userName": "regtestslow", "password": "pw123",
         "challengeId": chal["challengeId"], "nonce": nonce}, "9.9.9.9", "t")
    assert st == 200, f"正常填表节奏应成功,实得 {body}"


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_pow_wrong_rejected(reg_env):
    """错误 nonce → pow_failed;挑战单次性:同 cid 二次提交视作过期。
    4.0.2:提交前先经 reg_pow_check 反验「确非真解」再选 nonce —— 联测难度
    bits=8 下固定 nonce '0' 有 1/256 概率恰为真解(几何分布),曾致本测概率性
    假红(注册成功 200 ≠ 期望 400)。反验构造后假阳概率为零,断言随之收紧为
    严格 pow_failed(挑战新鲜、字段合法、min_fill=0,别无它路)。"""
    await reg_env(_cfg())
    st, chal = await userauth.reg_challenge("9.9.9.9", "")
    bad = next(str(n) for n in range(1000)
               if not userauth.reg_pow_check(chal["salt"], str(n), chal["bits"]))
    st, body, _ = await userauth.register(
        {"userName": "regtestbadpow", "password": "pw123",
         "challengeId": chal["challengeId"], "nonce": bad}, "9.9.9.9", "t")
    assert st == 400 and body["error"] == "pow_failed"
    # cid 已被核销 → 再用必过期
    st, body, _ = await userauth.register(
        {"userName": "regtestbadpow", "password": "pw123",
         "challengeId": chal["challengeId"], "nonce": "1"}, "9.9.9.9", "t")
    assert st == 400 and body["error"] == "challenge_expired"


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_register_tx_invite_reason_precise(reg_env):
    """4.0.2:占坑失败(rowcount≠1)后事务内诊断读把真实死因说准 —— 预检↔事务
    的竞态窗口里,刚被禁用/过期/删除的码此前一律回「已用尽」。直接打 _register_tx
    (绕过 register() 预检)即是把窗口内状态摆到台面上;顺带钉住诊断路径零副作用
    (不占坑、不建号)。"""
    await reg_env(_cfg(reg_mode="invite"))
    await userauth._q(
        "INSERT INTO guantai_invite_code (code, days_granted, quota, used_count,"
        " expires_at, disabled, note, created_at) VALUES"
        " ('DISABLEDCODE0001', 1, 1, 0, NULL, 1, 't', NOW()),"
        " ('USEDUPCODE000001', 1, 1, 1, NULL, 0, 't', NOW())")
    await userauth._q(
        "INSERT INTO guantai_invite_code (code, days_granted, quota, used_count,"
        " expires_at, disabled, note, created_at) VALUES"
        " ('EXPIREDCODE00001', 1, 1, 0, DATE_SUB(NOW(), INTERVAL 1 DAY), 0, 't', NOW())")
    stored = userauth.encode_reg_password("pw123", "md5")
    for code, want in (("DISABLEDCODE0001", "invite_invalid"),
                       ("EXPIREDCODE00001", "invite_expired"),
                       ("USEDUPCODE000001", "invite_exhausted"),
                       ("NOSUCHCODE000001", "invite_invalid")):
        err, _info = await userauth._register_tx(
            "regtesttxdiag", stored, 0, code, {}, "9.9.9.9", "t", "")
        assert err == want, f"{code}: got {err!r}, want {want!r}"
    row = await userauth._q("SELECT SUM(used_count) AS s FROM guantai_invite_code",
                            fetch="one")
    assert int(row["s"] or 0) == 1        # 仅 USEDUP 那枚的预置 1:四次失败零占坑
    row = await userauth._q("SELECT COUNT(*) AS c FROM tb_user WHERE user_name=%s",
                            ("regtesttxdiag",), fetch="one")
    assert int(row["c"]) == 0             # 亦零建号


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_ip_rate_limit(reg_env):
    """R1:每 IP 尝试上限触发后回 429(fail-closed 精神:限流命中不放行)。"""
    await reg_env(_cfg(reg_ip_hourly=2, reg_ip_daily=100))
    seen_429 = False
    for i in range(5):
        st, chal = await userauth.reg_challenge("5.5.5.5", "")
        if st == 429:
            seen_429 = True
            break
        nonce = await _solve(chal["salt"], chal["bits"]) if st == 200 else "0"
        st, body, _ = await userauth.register(
            {"userName": f"regtestrl{i}", "password": "pw123",
             "challengeId": chal.get("challengeId", ""), "nonce": nonce},
            "5.5.5.5", "t")
        if st == 429:
            seen_429 = True
            break
    assert seen_429, "连续注册未触发 IP 限流"


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_block_hit_login_banned(reg_env):
    """R7:观测台封禁写 guantai_user_block → 该账号登录回 banned(不碰 tb_user)。"""
    await reg_env(_cfg(reg_trial_days=3))
    st, body, tok = await _register("regtestblk", "pw123")
    assert st == 200
    uid = int(body["user"]["id"])
    # 未封禁:登录正常
    lst, _, _ = await userauth.login("regtestblk", "pw123", "1.1.1.1", "t")
    assert lst == 200
    # 封禁 → banned(且 tb_user.is_off 未被改动)
    n = await userauth.blocks_set([uid], "test", unblock=False)
    assert n == 1
    lst, lbody, _ = await userauth.login("regtestblk", "pw123", "1.1.1.1", "t")
    assert lst == 403 and lbody["error"] == "banned"
    off = await userauth._q("SELECT is_off FROM tb_user WHERE id=%s", (uid,),
                            fetch="one")
    assert str(off["is_off"]) == "0"                          # 封禁不碰 tb_user
    # 解封 → 恢复
    await userauth.blocks_set([uid], "", unblock=True)
    lst, _, _ = await userauth.login("regtestblk", "pw123", "1.1.1.1", "t")
    assert lst == 200


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_breaker_daily_closes(reg_env):
    """R6:日成功注册越顶 → 自动关闸 off,后续注册回 register_closed。"""
    await reg_env(_cfg(reg_trial_days=3, reg_global_daily=2))
    for i in range(2):
        st, _, _ = await _register(f"regtestcb{i}", "pw123")
        assert st == 200
    # 阈值语义为「达到即关闸」→ 第 2 个成功(达上限 2)后即置位;硬上界 = 阈值本身
    eff, br = await userauth.reg_state()
    assert eff == "off" and br.get("mode") == "off"
    st, chal = await userauth.reg_challenge("9.9.9.9", "")
    assert st == 403 and chal["error"] == "register_closed"
    # 管理台恢复
    await userauth.breaker_clear()
    eff, _ = await userauth.reg_state()
    assert eff == "open"


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_reg_throttle_clear_scope_unlock_and_admin_route(reg_env, monkeypatch):
    """**4.0.3 管理台「清空全部注册限流」**:作用域 + 真实解锁闭环 + 路由,一测三钉。

    ① 作用域即语义:guantai:reg:* 全清(Redis 与 mem_reg 兜底双清),但刻意排除
       K_REG_CB 熔断态(专属手动恢复路径,清限流不改注册生效模式)、
       guantai:regchal:* 挑战载荷、guantai:lf:* 登录失败锁 —— 任一排除项被
       误删本测试必须红(K_REG_CB 排除经变异测试验证)。
    ② 真实闭环:R1 日窗打满 → register 429 throttled → 清空 → 同链重试 200,
       复刻线上「retryAfter 五位数」事故的完整救援路径。
    ③ 路由:无 CSRF 的写被拒;带全鉴权 → 200 + 计数回执 + 审计落 reg_throttle_clear。"""
    r = await reg_env(_cfg(reg_trial_days=3, reg_ip_daily=10))
    # ── 布景:限流计数(Redis) + 进程内兜底(排除类哨兵在 ② 前半之后落位:
    #    熔断哨兵若此刻就位,reg_state 生效档即 off,第一步就被 register_closed 挡下)──
    for k, v in ((b"guantai:reg:tryd:ip:9.9.9.9", 10),
                 (b"guantai:reg:try:ip:9.9.9.9", 3),
                 (b"guantai:reg:name:deadbeefdeadbeef", 2),
                 (b"guantai:reg:al:thr:9.9.9.9", 1),
                 (b"guantai:reg:g:d:20260718", 5),
                 (b"guantai:reg:lk:regtestthr", 1)):
        await r.set(k, v)
        await r.expire(k, 3600)
    userauth.UA.mem_reg["guantai:reg:try:ip:membox"] = (3, time.monotonic() + 99)
    userauth.UA.mem_reg["guantai:lf:u:membox"] = (2, time.monotonic() + 99)
    # ── ② 前半:日窗已满(10/10),真实 register 第 11 次 → 429 throttled ──
    st, body, _ = await _register("regtestthr", "pw123")
    assert st == 429 and body["error"] == "throttled" and body["retryAfter"] > 0
    # 三类排除哨兵此刻落位(熔断态放最后,专验「清限流不碰熔断」)
    await r.set(userauth.K_REG_CB.encode(), b'{"mode":"off","why":"t"}')
    await r.set(b"guantai:regchal:e2e-keep", b"{}")
    await r.set(b"guantai:lf:ip:9.9.9.9", 4)
    # ── 清空 ──
    out = await userauth.reg_throttle_clear()
    assert out["redis_ok"] is True and out["mem"] == 1 and out["redis"] >= 7, out
    # 限流键全灭(含 register 刚自增的 try/tryd 与挑战签发计数)
    for k in (b"guantai:reg:tryd:ip:9.9.9.9", b"guantai:reg:try:ip:9.9.9.9",
              b"guantai:reg:name:deadbeefdeadbeef", b"guantai:reg:al:thr:9.9.9.9",
              b"guantai:reg:g:d:20260718", b"guantai:reg:lk:regtestthr"):
        assert not await r.exists(k), k
    # 三排除项原封不动
    assert await r.exists(userauth.K_REG_CB.encode()), "熔断态被误删 —— 作用域越界"
    assert await r.exists(b"guantai:regchal:e2e-keep"), "挑战载荷被误删"
    assert await r.exists(b"guantai:lf:ip:9.9.9.9"), "登录失败锁被误删"
    assert "guantai:reg:try:ip:membox" not in userauth.UA.mem_reg
    assert "guantai:lf:u:membox" in userauth.UA.mem_reg
    del userauth.UA.mem_reg["guantai:lf:u:membox"]
    # 熔断态是布景数据,清掉免得影响 ② 后半(它不属于限流,须走专属路径)
    assert await userauth.breaker_clear()
    # ── ② 后半:同链重试立即恢复 → 200 ──
    st2, body2, _ = await _register("regtestthr", "pw123")
    assert st2 == 200 and body2["ok"] is True, body2
    # ── ③ 管理台路由(直调,与 test_admin_session_channel 同款 _Req 桩) ──
    from types import SimpleNamespace as _NS
    from app import admin_auth as _aa
    from app import admin_api as _api

    class _Req:
        def __init__(self, headers=None):
            h = {k.lower(): v for k, v in (headers or {}).items()}
            self.headers = _NS(get=lambda k, d="": h.get(k.lower(), d))
            self.cookies = {}
            self.client = _NS(host="127.0.0.1")

    monkeypatch.setenv("STA_ADMIN_PASSWORD", "pw-thr-clear")
    _aa._reset_for_tests()
    try:
        rows = []

        class _DB:
            async def audit_add(self, *a, **kw):
                rows.append(a)

        monkeypatch.setattr(_api, "_ST", _NS(db=_DB(), cfg_state=None))
        tok, csrf = _aa.issue_session()
        resp = await _api.reg_throttle_clear(_Req({"X-Admin-Session": tok}))
        assert getattr(resp, "status_code", 0) == 403, "无 CSRF 的写必须被拒"
        await r.set(b"guantai:reg:try:ip:8.8.8.8", 5)
        ok = await _api.reg_throttle_clear(
            _Req({"X-Admin-Session": tok, "X-Admin-CSRF": csrf}))
        assert ok["ok"] is True and ok["cleared"]["redis"] >= 1
        assert not await r.exists(b"guantai:reg:try:ip:8.8.8.8")
        assert any(row[2] == "reg_throttle_clear" for row in rows), "审计未落行"
    finally:
        _aa._reset_for_tests()


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_sha256_shape_rejected_on_short_column(reg_env):
    """C7 把关:pass_word=varchar(50) 时 sha256 形态放不下 → 注册 fail-closed 503。"""
    await reg_env(_cfg(reg_pass_shape="sha256", reg_trial_days=3))
    st, body, _ = await _register("regtestsha", "pw123")
    assert st == 503 and body["error"] == "register_unavailable"


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_name_taken_refunds_quota_and_difficulty(reg_env):
    """**重名不该被当成恶意尝试**(4.0.0 线上反馈)。

    重名是真人最常见的正常探索(常用名多半被占)。原实现在 register() 开头无条件
    +1 主配额,重名照扣 —— 默认 5 次/时,试 5 个名字就锁一小时;更糟的是重名还推高
    `d24` 难度阶梯,PoW 从 13 万次涨到 70 万次以上,越试越慢直到彻底被锁死
    (用户截图:「安全校验中… 74 万」+「操作过于频繁,约 60 分钟后可再试」)。

    现改为走 `_name_taken()` 统一出口:退还 R1 时/日主配额、难度阶梯、挑战签发计数
    (挑战单次性,换名必须重取,不该为此付费),改记独立且宽松的重名计数器。
    """
    await reg_env(_cfg(reg_ip_hourly=5, reg_ip_daily=10, reg_chal_ip_10m=10))
    ip = "198.51.100.9"
    for i in range(6):
        with _noraise():
            await userauth._q(
                "INSERT INTO tb_user (user_name,pass_word,due_time,is_off) "
                "VALUES (%s,%s,DATE_ADD(NOW(),INTERVAL 30 DAY),'0')",
                (f"regtestnt{i}", "x"))

    async def attempt(name):
        st, ch = await userauth.reg_challenge(ip, "")
        assert st == 200, f"挑战被拒:{ch}"
        nonce = await _solve(ch["salt"], ch["bits"])
        return await userauth.register(
            {"userName": name, "password": "pw12345",
             "challengeId": ch["challengeId"], "nonce": nonce}, ip, "pytest")

    for i in range(6):
        st, body, _ = await attempt(f"regtestnt{i}")
        assert st == 400 and body["error"] == "name_taken", \
            f"第 {i + 1} 次重名被误判为限流:{st} {body.get('error')}"

    bucket = userauth._ip_bucket(ip)
    used = await userauth._reg_peek(f"guantai:reg:try:ip:{bucket}")
    nt = await userauth._reg_peek(f"guantai:reg:nt:ip:{bucket}")
    d24 = await userauth._reg_peek(f"guantai:reg:d24:{userauth._net24(ip)}")
    assert used == 0, f"重名不该消耗 R1 主配额(实 {used})"
    assert nt == 6, f"重名应记入独立计数器(实 {nt})"
    assert d24 == 0, f"重名不该推高自适应难度(实 {d24})"

    st, body, _ = await attempt("regtestntok")
    assert st == 200, f"试过多个重名后仍应能正常注册(实 {st} {body.get('error')})"


@needs_db
@needs_redis
@pytest.mark.asyncio
async def test_name_taken_enumeration_still_capped(reg_env):
    """退还配额 ≠ 放开:重名次数仍由独立计数器封顶,用户名枚举防护未削弱。"""
    await reg_env(_cfg())
    ip = "198.51.100.44"
    with _noraise():
        await userauth._q(
            "INSERT INTO tb_user (user_name,pass_word,due_time,is_off) "
            "VALUES (%s,%s,DATE_ADD(NOW(),INTERVAL 30 DAY),'0')", ("regtestenum", "x"))
    bucket = userauth._ip_bucket(ip)
    for _ in range(userauth._NT_HOURLY):          # 直接顶满,免去逐次 PoW 的耗时
        await userauth._reg_incr(f"guantai:reg:nt:ip:{bucket}", 3600)
    st, ch = await userauth.reg_challenge(ip, "")
    nonce = await _solve(ch["salt"], ch["bits"])
    st, body, _ = await userauth.register(
        {"userName": "regtestenum", "password": "pw12345",
         "challengeId": ch["challengeId"], "nonce": nonce}, ip, "pytest")
    assert st == 429 and body["error"] == "throttled", \
        f"超过重名独立上限应 429(实 {st} {body.get('error')})"
    assert "换名" in body.get("message", ""), \
        f"429 应来自重名上限而非主配额/挑战限流(实 {body.get('message')!r})"


def test_pow_progress_reports_percentage_not_raw_count():
    """PoW 进度必须报**百分比**,不许报原始尝试次数。

    线上反馈:按钮显示「安全校验中… 74 万」—— 用户无从判断 74 万是多是少、还要
    等多久(PoW 是几何分布,没有确定总数)。现按期望值 2^bits 折算并封顶 99%;
    Worker 上报间隔随难度自适应(约 25 次)并带出 expect。
    """
    if not APP_JS.is_file():
        pytest.skip("assets/app.js 不在预期路径")
    src = APP_JS.read_text(encoding="utf-8")
    a = src.find("/*__JF_REG_WORKER_BEGIN__*/`")
    b = src.find("`/*__JF_REG_WORKER_END__*/")
    assert a > 0 and b > a, "Worker 源码标记丢失"
    worker = src[a:b]
    assert "expect: expect" in worker, "Worker 未随进度带出期望值"
    assert "tried % 100000" not in worker, "仍在用固定 10 万次的粗粒度上报"
    assert "Math.pow(2, bits)" in worker, "未按 2^bits 计算期望次数"
    i = src.find("async function doRegister")
    j = src.find("/* ───────── 回合归一化", i)
    body = src[i:j if j > 0 else i + 8000]
    assert "+ '%'" in body, "进度未显示百分比"
    assert "' 万'" not in body, "仍在显示「N 万」原始次数"
    assert "Math.min(99" in body, "百分比未封顶 99%(PoW 可能超过期望值)"
