"""
test_verify_admission.py — 核验准入(5.0.7)与工作台去仪式化(admin 1.8.0)守卫
================================================================================
两组改动各自的**契约**在此钉死,防止后来者顺手改回去:

  ① 核验准入:在播列表是推荐流,频道房从不上榜 —— 后台没有开播记录的房必须
     还有第二条通道(roomStatus 核验),且三种拒绝各说各的真话,尤其
     **「问不到」绝不能被写成「未开播」**(与 livestatus 同一条戒律)。
  ② 工作台:`need_confirm` / `ack_warnings` 两道仪式性闸门已下线,而
     **硬错(errors)必须仍然拦得住** —— 去掉的是抄写,不是护栏。

绝大多数用例是纯静态源码/注册表断言(零外部依赖);涉及 _verify_admit 与
worker 相位算术的用例用轻量假对象直驱,不触网、不连 PG/Redis。
"""
from __future__ import annotations

import random
import re
import sys
import types
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

WEB_SRC = (ROOT / "app" / "web.py").read_text(encoding="utf-8")
WORKER_SRC = (ROOT / "app" / "worker.py").read_text(encoding="utf-8")
ADMIN_SRC = (ROOT / "app" / "admin_api.py").read_text(encoding="utf-8")
ADMIN_JS = ROOT.parent / "assets" / "admin.js"
APP_JS = ROOT.parent / "assets" / "app.js"


# ══ ① 注册表 / 配置三方一致 ══════════════════════════════════════════════════
def test_verify_keys_registered_with_env_and_section():
    from app import config_registry as reg
    for k, env in (("discovery.verify_enabled", "STA_DISCOVERY_VERIFY_ENABLED"),
                   ("discovery.verify_interval_s", "STA_DISCOVERY_VERIFY_INTERVAL_S")):
        f = reg.REGISTRY.get(k)
        assert f is not None, f"注册表缺 {k}"
        assert f.env == env, f"{k} 的 ENV 声明与 settings 读取不一致"
        assert f.section == "自动发现"
        assert f.hot == reg.HOT, f"{k} 应为 HOT(循环内现读)"
        assert not f.readonly


def test_verify_defaults_match_config_yaml():
    """注册表 default ⇄ config.yaml 现值:「默」印所示即事实。"""
    import yaml
    from app import config_registry as reg
    disc = (yaml.safe_load((ROOT / "config.yaml").read_text(encoding="utf-8"))
            or {}).get("discovery") or {}
    assert disc.get("verify_enabled") is reg.REGISTRY["discovery.verify_enabled"].default
    assert int(disc.get("verify_interval_s")) == \
        reg.REGISTRY["discovery.verify_interval_s"].default


def test_verify_interval_bounds_allow_hourly_but_not_absurd():
    """区间必须容得下运维真会用的刻度(6 小时),又挡住把复核变成探测风暴的值。"""
    from app import config_registry as reg
    f = reg.REGISTRY["discovery.verify_interval_s"]
    assert f.ge <= 21600 <= f.le
    assert f.ge >= 600, "低于 10 分钟的复核周期对一整张台账就是探测风暴"


# ══ ② 语义校验:周期相对 grace 过大要出声 ══════════════════════════════════
def test_semantic_warns_when_interval_too_close_to_grace():
    from app import config_center as cfgc
    from app import config_registry as reg
    base = {k: f.default for k, f in reg.REGISTRY.items()}
    base["discovery.verify_interval_s"] = 604800 // 2 + 1     # ×2 > grace
    errs, warns = cfgc.semantic_validate(base, {"discovery.verify_interval_s"})
    assert not errs, "这是提醒不是硬错 —— 不该拦住保存"
    assert any("verify_interval_s" in w for w in warns), \
        "复核周期逼近台账有效期时必须给警告,否则核验房会静默地还没复核就被清出"


def test_semantic_silent_on_sane_defaults():
    from app import config_center as cfgc
    from app import config_registry as reg
    base = {k: f.default for k, f in reg.REGISTRY.items()}
    errs, warns = cfgc.semantic_validate(base, {"discovery.verify_interval_s"})
    assert not errs and not any("verify_interval_s" in w for w in warns), \
        "默认刻度(1 天 vs 7 天)不该报警 —— 假警报会把真警报一起淹掉"


# ══ ③ _verify_admit:三种拒绝各说各的真话 ══════════════════════════════════
class _FakeStar:
    def __init__(self, status):
        self._status = status

    async def live_status(self, room):
        if isinstance(self._status, Exception):
            raise self._status
        return self._status


class _FakeDB:
    def __init__(self, last_live=None):
        self._last = last_live
        self.upserted = []

    async def verified_last_live(self, rid):
        return self._last

    async def verified_upsert(self, rid, ms):
        self.upserted.append((rid, ms))


class _FakeBus:
    def __init__(self):
        self.live_writes = []

    async def livestatus_set_bulk(self, items, ts=None):
        self.live_writes.append((items, ts))


async def _admit(monkeypatch, *, status=None, last_live=None, enabled=True):
    from app import web
    monkeypatch.setattr(web.settings.discovery, "verify_enabled", enabled,
                        raising=False)
    monkeypatch.setattr(web.settings.discovery, "prune_grace_s", 604800,
                        raising=False)
    db, bus = _FakeDB(last_live), _FakeBus()
    monkeypatch.setattr(web.ST, "db", db, raising=False)
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.ST, "star", _FakeStar(status), raising=False)
    return await web._verify_admit("2678075"), db, bus


async def test_admit_passes_when_live_now(monkeypatch):
    resp, db, bus = await _admit(monkeypatch, status=1)
    assert resp is None, "roomStatus 说在播就必须放行 —— 这正是本通道存在的理由"
    assert db.upserted, "放行必须记台账,否则下次添加又要碰运气撞开播"
    assert bus.live_writes, "刚核验过的事实应同步进 livestatus,名录绿点秒亮"


async def test_admit_rejects_not_live_now(monkeypatch):
    resp, _db, _bus = await _admit(monkeypatch, status=0)
    assert resp is not None and resp.status_code == 400
    assert b"not_live_now" in bytes(resp.body)


async def test_admit_never_calls_unknown_offline(monkeypatch):
    """**最重要的一条**:问不到 ≠ 没开播。上游抖动时必须回 live_unverifiable,
    绝不能把「我不知道」说成「他没播」—— 那会让用户以为主播下播了。"""
    for status in (None, RuntimeError("上游超时")):
        resp, _db, _bus = await _admit(monkeypatch, status=status)
        body = bytes(resp.body)
        assert b"live_unverifiable" in body
        assert b"not_live_now" not in body


async def test_admit_uses_ledger_without_touching_upstream(monkeypatch):
    """grace 内的台账房免核验:上游一次都不该被打扰。"""
    import time
    fresh = int(time.time() * 1000) - 3600_000
    resp, db, _bus = await _admit(
        monkeypatch, status=RuntimeError("这次绝不该被调用"), last_live=fresh)
    assert resp is None
    assert not db.upserted, "免核验路径不该改写时钟(添加意图不是在播证据)"


async def test_admit_falls_back_to_legacy_error_when_disabled(monkeypatch):
    resp, _db, _bus = await _admit(monkeypatch, status=1, enabled=False)
    assert resp is not None and b"not_recent_live" in bytes(resp.body)


# ══ ④ 源码契约:漏一处就前功尽弃的几条 ════════════════════════════════════
def test_verified_room_gets_provenance_mark():
    """核验房必须打 user_added_rooms 溯源标 —— 它压根不在发现集里,不打标就
    永远撤不下来,用户删掉最后一份绑定后仍被全局抓取,是只进不出的泄漏。"""
    body = WEB_SRC.split("async def monitor_add", 1)[1].split("\n@app.", 1)[0]
    line = [ln for ln in body.split("\n") if "_was_discovered = (" in ln
            or ("_was_discovered =" in ln and "False" not in ln)]
    assert line and "not known" in line[0], \
        "溯源取样漏了核验房(应为 `(not known) or rid in 发现集`)"


def test_remove_cleans_verified_ledger():
    body = WEB_SRC.split("def monitor_remove", 1)[1].split("\n@app.", 1)[0]
    assert "verified_delete_bulk" in body, \
        "显式撤下监控却留着台账 = 被撤的房能绕过准入原地复活"


def test_profile_emits_exists_tristate():
    """exists 必须是**三态**:说不准时给 None,绝不误判成不存在。"""
    body = WEB_SRC.split("async def _build_profile", 1)[1].split("\nasync def ", 1)[0]
    assert '"exists"' in body
    assert "None" in body, "exists 必须能表达「说不准」,否则上游抖动会误清退用户的房"
    assert APP_JS.read_text(encoding="utf-8").count("exists === false") >= 3


async def test_canon_stays_definitive_when_upstream_is_down():
    """**把实测钉住,防止未来有人高估 exists**:StarMeta._resolve 一开始就把
    prof["roomId"] 播种为入参房号,而入参恒是 2–12 位数字 —— 于是上游全灭时
    canon 依旧回 definitive=True。这条一旦变了(比如有人改成失败即 False),
    `_build_profile` 的 exists 会突然开始对**上游抖动**回 False,前端那三处
    清退分支就会把用户的房删掉。谁改这条语义,请连带重估 exists 与 room_unresolved。"""
    from app.starmeta import StarMeta

    class _Dead:
        closed = False

        def get(self, *a, **k):
            raise RuntimeError("upstream down")

        async def close(self):
            pass

    sm = StarMeta()
    await sm.start()
    try:
        sm._session = _Dead()
        assert await sm.canon("321") == ("321", True)
        assert await sm.canon("abc") == ("abc", False)   # 非法号才是 False
    finally:
        await sm.close()


def test_worker_verify_probe_is_last_resort():
    """三级供货:发现集 → livestatus 观测 → 才轮到真探。少任何一级都会让
    每天一轮变成对整张台账的无差别探测。"""
    body = WORKER_SRC.split("async def _verify_sweep_once", 1)[1] \
        .split("\n    async def ", 1)[0]
    for token in ("discovered_map", "livestatus_map", "next_probe_ms"):
        assert token in body, f"复核少了 {token} 这一级(会退化成无差别探测)"
    assert "max_probe" in body, "单轮探测必须有硬闸"


def test_worker_verify_phase_is_randomised():
    """固定时刻齐探对「每晚固定时段开播」的主播是确定性漏判 —— 一年都判不出
    它在播。相位必须随机化。"""
    from app.worker import Worker
    fn = Worker._verify_next_ms
    random.seed(20260906)
    vals = {fn(None, 0, 86400) for _ in range(200)}
    assert len(vals) > 100, "相位没有随机化"
    assert min(vals) >= int(86400 * 1000 * 0.75)
    assert max(vals) <= int(86400 * 1000 * 1.25)


def test_verify_sweep_is_registered_as_a_worker_task():
    assert "self._verify_sweep()" in WORKER_SRC, \
        "循环写了却没挂进 run() 的 task 列表 = 一行都不会跑"


def test_probe_failure_does_not_move_the_clock():
    """未开播/问不到只把下次复核排出去,时钟不动 —— 够不够格留在台账由 grace
    说了算,不由单次探测定生死(与发现房「缺席不算下播」同一条戒律)。"""
    body = WORKER_SRC.split("async def _verify_sweep_once", 1)[1] \
        .split("\n    async def ", 1)[0]
    assert "refreshed.append((rid, 0, nxt))" in body


# ══ ⑤ 工作台去仪式化:去掉抄写,但护栏一根不少 ════════════════════════════
def test_backend_confirm_and_ack_gates_are_gone():
    assert "need_confirm" not in ADMIN_SRC, "键名确认闸未清干净"
    assert "ack_warnings" not in ADMIN_SRC.replace(
        "# 「ack_warnings 二次提交」。它们拦不住真正的错(打对一个键名不代表填对了值),",
        ""), "警告阻断闸未清干净"


def test_hard_errors_still_block_apply():
    """去掉的是抄写,不是护栏:结构错与语义错必须仍然 422 硬拦。"""
    seg = ADMIN_SRC.split("async def _do_apply", 1)[1].split("\n@router.", 1)[0]
    assert seg.count("status_code=422") >= 3
    assert "semantic_validate" in seg and "check_changes" in seg


def test_warnings_and_danger_go_to_audit():
    """警告不再拦人,于是必须留痕 —— 否则「提醒过什么」这件事就此消失。"""
    seg = ADMIN_SRC.split("async def _do_apply", 1)[1].split("\n@router.", 1)[0]
    assert 'detail["warnings"]' in seg
    assert 'detail["danger_keys"]' in seg


def test_danger_flag_survives_as_a_marker():
    """`danger` 从闸门降级为标记 —— 字段与既有标注一个都不能丢,否则运维再也
    看不出哪些参数改错代价大(注册表侧的 test_flags_sanity 同样依赖它)。"""
    from app import config_registry as reg
    assert reg.REGISTRY["retention.days"].danger
    assert reg.REGISTRY["discovery.enabled"].danger
    assert '"danger": f.danger' in \
        (ROOT / "app" / "config_registry.py").read_text(encoding="utf-8")


@pytest.mark.skipif(not ADMIN_JS.is_file(), reason="前端不在本仓")
def test_admin_js_has_no_typed_confirmation_left():
    src = ADMIN_JS.read_text(encoding="utf-8")
    code = "\n".join(
        "" if ln.lstrip().startswith(("//", "*", "/*")) else ln
        for ln in src.split("\n"))
    for dead in ("data-cf", "confirm-box", "cf-msg", "D.confirms", "dAck"):
        assert dead not in code, f"admin.js 仍残留键名确认交互: {dead}"
    assert "id=\"dVal\"" not in code, "「校验」按钮应已下线(改为自动预检)"
    assert "scheduleValidate" in code, "自动预检没接上 —— 那就成了盲改"
    assert re.search(r"userauth\.reg_mode\s*确认", code) is None, \
        "注册模式仍在要求键入参数名"


@pytest.mark.skipif(not APP_JS.is_file(), reason="前端不在本仓")
def test_app_js_persists_room_only_after_backend_accepts():
    """旧序「先落盘再问后端」在被拒时会留下一个删不掉的幽灵房(mergeMyRooms
    每 30s 把它塞回名录)。核验准入让 400 变得常见,这个序必须掉个个儿。"""
    src = APP_JS.read_text(encoding="utf-8")
    body = src.split("async function submitAddRoom", 1)[1].split("\nfunction ", 1)[0]
    assert body.index("/api/monitor/add") < body.index("saveMyRooms("), \
        "saveMyRooms 仍早于后端应答 —— 被拒的房会残留在本地存储里复活"


@pytest.mark.skipif(not APP_JS.is_file(), reason="前端不在本仓")
def test_app_js_timeout_covers_upstream_verification():
    """核验要打一次 roomStatus(外层天花板 8s);前端 5s 会先抛超时并落进
    「网络瞬断照常入名录」分支,而后端可能正要拒 —— 前后端说法当场分叉。"""
    src = APP_JS.read_text(encoding="utf-8")
    m = re.search(r"/api/monitor/add\?room=\$\{encodeURIComponent\(alias\)\}`,"
                  r"\s*\{\s*timeout:\s*(\d+)\s*\}", src)
    assert m, "找不到 monitor/add 的超时设置(重构请同步本守卫)"
    assert int(m.group(1)) >= 12000, "超时必须覆盖上游核验(≥12s)"


# ══ ⑥ 切房准入(5.0.7):与添加同一条阶梯,但不许误伤 ═══════════════════════
class _SwitchBus:
    def __init__(self, active=(), pending=()):
        self._a = active if isinstance(active, Exception) else set(active)
        self._p = set(pending)
        self.calls = []
        self.registered = []
        self.live_writes = []
        self.scheduled = []

    async def is_active(self, room):
        self.calls.append(("is_active", str(room)))
        if isinstance(self._a, Exception):
            raise self._a
        return str(room) in self._a

    async def is_pending(self, alias):
        self.calls.append(("is_pending", str(alias)))
        return str(alias) in self._p

    async def active_count(self):
        self.calls.append(("active_count", ""))
        return len(self._a) if not isinstance(self._a, Exception) else 0

    # 自愈登记用到的写面(全部记账,便于断言"到底动了什么")
    async def pending_remove(self, a): self.registered.append(("pending_remove", a))
    async def add_room(self, rid, alias): self.registered.append(("add_room", rid, alias))
    async def discovered_remove(self, rid): self.registered.append(("discovered_remove", rid))
    async def replay_gate_clear(self, rid): self.registered.append(("replay_gate_clear", rid))
    async def replay_wake_push(self, rid): self.registered.append(("replay_wake_push", rid))
    async def touch_rooms(self, rooms, ts): self.registered.append(("touch_rooms", tuple(rooms)))
    async def cold_clear(self, rid): self.registered.append(("cold_clear", rid))
    async def schedule(self, member, due): self.scheduled.append(member)
    async def livestatus_set_bulk(self, items, ts=None): self.live_writes.append(items)


class _SwitchDB:
    def __init__(self, last_live=None, bound=True):
        self._last, self._bound = last_live, bound
        self.upserts = []
        self.verified = []

    async def verified_last_live(self, rid): return self._last
    async def verified_upsert(self, rid, ms): self.verified.append((rid, ms))
    async def upsert_room(self, rid, alias, active, pending=False):
        self.upserts.append((rid, alias, active, pending))
    async def discovered_delete_bulk(self, ids): pass
    async def user_room_allowed(self, uid, rid, alias): return self._bound


class _Req:
    """最小请求替身:只需 .state.user 能被 web._req_user 读到。"""
    def __init__(self, user=None):
        self.state = types.SimpleNamespace(user=user)


async def _switch(monkeypatch, *, active=(), pending=(), room="321", rid="2678075",
                  status=None, last_live=None, bound=True, verify=True,
                  login=False, request=None):
    from app import web
    bus, db = _SwitchBus(active, pending), _SwitchDB(last_live, bound)
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.ST, "db", db, raising=False)
    monkeypatch.setattr(web.ST, "star", _FakeStar(status), raising=False)
    monkeypatch.setattr(web.settings.discovery, "verify_enabled", verify,
                        raising=False)
    monkeypatch.setattr(web.settings.discovery, "prune_grace_s", 604800,
                        raising=False)
    monkeypatch.setattr(web.userauth, "enabled", lambda: login)
    return await web._switch_admit(room, rid, request), bus, db


async def test_switch_passes_for_monitored_room(monkeypatch):
    resp, bus, db = await _switch(monkeypatch, active={"2678075"})
    assert resp is None
    assert bus.calls == [("is_active", "2678075")], \
        "在册房必须一次 SISMEMBER 命中即止 —— 不查台账、不打上游、不写库"
    assert not bus.registered and not db.verified


async def test_switch_uses_ledger_before_touching_upstream(monkeypatch):
    """第二级:grace 内的核验台账直接放行,上游一次都不该被打扰。"""
    import time
    fresh = int(time.time() * 1000) - 3600_000
    resp, bus, db = await _switch(
        monkeypatch, active={"999"}, last_live=fresh,
        status=RuntimeError("这次绝不该被调用"))
    assert resp is None
    assert not db.verified, "免核验路径不该改写时钟(切房意图不是在播证据)"
    assert bus.registered, "台账放行后仍须把抓取拉起来,否则进去还是空房"


async def test_switch_probes_and_selfheals_when_live(monkeypatch):
    """第三级:台账没有 → roomStatus 定谳 → 在播则自愈登记。
    只放行不登记等于让人进一间后台没在抓的空房 —— 阶梯的价值就在于能救就救。"""
    resp, bus, db = await _switch(monkeypatch, active={"999"}, status=1)
    assert resp is None
    assert db.verified, "核验通过必须记台账"
    assert ("add_room", "2678075", "321") in bus.registered
    assert ("2678075", "321", True, False) in db.upserts
    assert any(m.startswith("mp:") or "2678075" in m for m in bus.scheduled), \
        "自愈登记后必须排一拍抓取,否则房是空的"


async def test_switch_rejects_when_not_live(monkeypatch):
    resp, bus, _db = await _switch(monkeypatch, active={"999"}, status=0)
    assert resp is not None and b"not_live_now" in bytes(resp.body)
    assert not bus.registered, "确证未开播还去登记 = 给后台塞一间死房"


async def test_switch_reports_unverifiable_without_lying(monkeypatch):
    """问不到 ≠ 没开播。前端据此**不清卡**(见 app.js 终态集不含它)。"""
    for status in (None, RuntimeError("上游超时")):
        resp, bus, _db = await _switch(monkeypatch, active={"999"}, status=status)
        body = bytes(resp.body)
        assert b"live_unverifiable" in body and b"not_live_now" not in body
        assert not bus.registered


async def test_switch_spares_pending_rooms(monkeypatch):
    """挂起房(归一暂时失败、janitor 周期重试)前端名录里是有卡的,只是还没进
    rooms:active。误杀它 = 用户刚添加的房凭空消失。输入号与归一号双键都要认。"""
    for pend in ({"321"}, {"2678075"}):
        resp, bus, _db = await _switch(
            monkeypatch, active={"999"}, pending=pend,
            status=RuntimeError("挂起房不该走到探测"))
        assert resp is None, f"挂起房被切房闸误杀({pend})"
        assert not bus.registered


async def test_switch_fails_open_on_infra_error(monkeypatch):
    from app import web
    bus = _SwitchBus(active=RuntimeError("redis down"))
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    assert await web._switch_admit("321", "2678075", None) is None


async def test_switch_fails_open_when_registry_is_empty(monkeypatch):
    """web 的 PG→Redis 回灌裹在 except:pass 里:PG 启动瞬断 + Redis 空(compose
    关持久化)会让 rooms:active 是空集。此刻判否的后果不是拒一次请求,而是前端把
    用户名录里的房**逐个删掉** —— 一次抖动换一片不可逆的数据丢失。"""
    resp, bus, _db = await _switch(monkeypatch, active=set(),
                                   status=RuntimeError("空名录不该走到探测"))
    assert resp is None
    assert ("active_count", "") in bus.calls


async def test_switch_selfheal_requires_entitlement(monkeypatch):
    """启用登录时,自愈只给**该账号名录里的房**。否则任何人都能凭一个房号让后台
    开抓一间无主房:不占谁的名额、也没有溯源标,永远不会被回收。"""
    who = _Req(types.SimpleNamespace(user_id=7))
    resp, bus, db = await _switch(monkeypatch, active={"999"}, status=1,
                                  login=True, bound=False, request=who)
    assert resp is None, "未绑定不该拦 —— 交给下游 _user_room_deny 用准确措辞去说"
    assert not bus.registered, "未绑定却替他把房登记进后台 = 无主房泄漏"
    assert not db.verified, "救不了的房还去探上游 = 纯放大,一次都不该打"
    resp, bus, _db = await _switch(monkeypatch, active={"999"}, status=1,
                                   login=True, bound=True, request=who)
    assert resp is None and bus.registered, "本人名录里的房必须能自愈"
    # 运维旁路(无登录身份但已过中间件)与 monitor_add 同姿态:放行并登记
    resp, bus, _db = await _switch(monkeypatch, active={"999"}, status=1,
                                   login=True, bound=False, request=None)
    assert resp is None and bus.registered


async def test_switch_falls_back_when_verify_disabled(monkeypatch):
    resp, bus, _db = await _switch(monkeypatch, active={"999"}, verify=False,
                                   status=RuntimeError("关闭核验不该探测"))
    assert resp is not None and b"room_not_monitored" in bytes(resp.body)
    assert not bus.registered


def test_selfheal_does_not_forge_provenance_or_charge_quota():
    """自愈是「把丢掉的东西放回去」,不是「创造一份新归属」:补溯源标会把运维
    钉住的房变成可被用户删空撤下的房;再扣一次名额是重复计费。"""
    body = WEB_SRC.split("async def _selfheal_register", 1)[1] \
        .split("\nasync def ", 1)[0]
    assert "user_added_mark" not in body
    assert "room_max" not in body and "user_rooms_count" not in body


def test_switch_probe_budget_is_shorter_than_add():
    """添加是深思熟虑的动作,等几秒天经地义;切房被塞进 Promise.all,任一路超时
    都会把整次切房推进退避重试。故切房预算必须短于 livestatus.request_timeout,
    且前端 profile 超时必须留出余量。"""
    from app import web
    assert web.SWITCH_PROBE_TIMEOUT_S < web.settings.livestatus.request_timeout
    src = APP_JS.read_text(encoding="utf-8")
    for m in re.finditer(r"/profile\?switch=1`,\s*\{\s*timeout:\s*(\d+)\s*\}", src):
        assert int(m.group(1)) >= int(web.SWITCH_PROBE_TIMEOUT_S * 1000) + 5000


def test_switch_gate_is_opt_in_so_add_precheck_still_works():
    """本闸绝不能默认开:profile 还服务「添加前的房号预检」,那一刻房本就不在
    后台 —— 默认拦截会把核验准入通道当场堵死。"""
    body = WEB_SRC.split("async def live_room_profile", 1)[1].split("\n@app.", 1)[0]
    assert 'switch: str = Query("")' in body
    assert '_switch_admit' in body
    src = APP_JS.read_text(encoding="utf-8")
    pre = src.split("async function submitAddRoom", 1)[1].split("\nfunction ", 1)[0]
    assert "/profile`, { timeout: 6000 }" in pre, \
        "添加前预检不得带 switch=1(否则新房永远过不了预检)"


@pytest.mark.skipif(not APP_JS.is_file(), reason="前端不在本仓")
def test_frontend_switch_paths_send_the_flag_and_handle_rejection():
    src = APP_JS.read_text(encoding="utf-8")
    assert src.count("/profile?switch=1") == 2, \
        "切房与名录并卡两处都要带 switch=1(且仅此两处)"
    body = src.split("async function loadRoom", 1)[1].split("\nfunction ", 1)[0]
    term = body.split("].includes((e && e.data && e.data.error)", 1)[0]
    for code in ("room_not_monitored", "not_live_now", "room_unresolved"):
        assert code in term, f"切房终态 {code} 没接住 —— 会落进退避重试空转"
    assert "'live_unverifiable'" not in term, \
        "问不到 ≠ 这房没了 —— 据此清卡会在上游抖动时删掉用户的房"
    assert body.index("room_not_monitored") < body.index("room_switched"), \
        "终态错误必须先于 room_switched/退避分支判定"


async def test_switch_selfheal_obeys_monitor_write_token(monkeypatch):
    """自愈是一次名录写,必须受名录写令牌保护。不复用同一把锁的话,
    `GET /profile?switch=1` 就是写保护的后门。"""
    from app import web
    monkeypatch.setenv("STA_MONITOR_WRITE_TOKEN", "s3cr3t")
    resp, bus, _db = await _switch(monkeypatch, active={"999"}, status=1,
                                   request=_Req(None))
    assert resp is None, "令牌缺失不该拦读 —— 只拦写"
    assert not bus.registered, "开着名录写保护却让 GET 把房登记进后台 = 写保护形同虚设"
    assert not _db.verified, "无资格却已经打了上游并往台账落行 —— 放大 + 撑表"


async def test_switch_rate_limits_only_the_expensive_branch(monkeypatch):
    """名录卡启动时会并发拉 N 张 profile。闸若设在入口,10 房的名录一开机就先
    吃两发 429;设在「注定要打上游」之后才对。"""
    from app import web
    hits = []

    async def _guard(request):
        hits.append(1)
        return None
    monkeypatch.setattr(web, "_detail_rate_guard", _guard)
    await _switch(monkeypatch, active={"2678075"})          # ① 命中即止
    assert not hits, "在册房不该经过限流闸"
    await _switch(monkeypatch, active={"999"}, status=1)    # 走到探测
    assert hits, "昂贵分支必须计费"


def test_verify_sweep_schedules_new_ledger_rows_without_reprobing():
    """_verify_admit 落台账时 next_probe_ms 取默认 0。若把 0 当「已到期」,
    每一次核验准入都会在 60s 内换来一发多余的 roomStatus —— ② 那条复用观测的
    分支因 ts>last 取严格大于恰好接不住它(两边都是同一个 nowv)。"""
    body = WORKER_SRC.split("async def _verify_sweep_once", 1)[1] \
        .split("\n    async def ", 1)[0]
    assert "nxt_at <= 0" in body and "elif nxt_at <= nowv" in body


def test_verify_lock_ttl_covers_the_worst_round():
    """discovery 与 livestatus 都踩过同一个坑并各自写了长篇注释:上游不可达时
    一轮最坏 = ⌈max_probe/concurrency⌉ × request_timeout,锁若在途中过期,别的
    副本就插队开第二轮 —— 恰在上游已经出问题时叠加请求。本循环的节拍不由锁
    承担(排期存 PG),所以锁 TTL 必须放长到覆盖最坏耗时。"""
    import math as _m
    from app.settings import get_settings
    from app.worker import Worker, _VERIFY_TICK_S
    w = Worker.__new__(Worker)
    w.s = get_settings()
    for max_probe, conc, to in ((300, 16, 8.0), (5000, 16, 8.0), (10, 16, 60.0)):
        w.s.livestatus.max_probe, w.s.livestatus.concurrency = max_probe, conc
        w.s.livestatus.request_timeout = to
        worst = _m.ceil(max_probe / conc) * to
        assert w._verify_lock_ttl() >= worst, \
            f"锁 TTL 覆盖不住最坏一轮({max_probe}/{conc}×{to}s = {worst}s)"
        assert w._verify_lock_ttl() >= _VERIFY_TICK_S


@pytest.mark.skipif(not ADMIN_JS.is_file(), reason="前端不在本仓")
def test_drawer_result_is_rendered_separately_from_the_note():
    """预检是异步的:回来时若整块 innerHTML 重建,用户正在输入的备注框会连同
    焦点与光标位置一起被销毁重建。故结论必须渲染进独立的 #dResult 容器,
    #dNote 永远不在重建范围内。"""
    src = ADMIN_JS.read_text(encoding="utf-8")
    assert "renderDrawerResult" in src and 'id="dResult"' in src
    body = src.split("function renderDrawerResult(", 1)[1].split("\nfunction ", 1)[0]
    assert "dNote" not in body, "结论层碰了备注框 —— 焦点会被夺走"
    val = src.split("async function doValidate(", 1)[1].split("\nasync function ", 1)[0]
    assert "renderDrawerBody" not in val, \
        "预检完成后整块重建 = 输一半的备注光标跳回开头"


async def test_switch_probe_has_a_per_room_cooldown(monkeypatch):
    """切房路径**会自动重复**:前端每 30s 用后端名录整体替换 S.rooms,随后
    mergeMyRooms 把 localStorage 里不在后端名录的房重新并回来 —— 同一个房每 30s
    再发一次 profile?switch=1。成功的房当场自愈进名录、下一拍即短路;失败的不会,
    而失败主因常常是上游本身不好 = 在最脆弱的时候按 30s×标签页数 持续加压。"""
    from app import web
    gates = {}

    class _GateBus(_SwitchBus):
        async def verify_probe_gate(self, room, ttl_s):
            hit = str(room) not in gates
            gates[str(room)] = 1
            return hit
    bus, db = _GateBus({"999"}), _SwitchDB()
    star = _FakeStar(None)                       # 探测恒失败(上游不好)
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.ST, "db", db, raising=False)
    monkeypatch.setattr(web.ST, "star", star, raising=False)
    monkeypatch.setattr(web.userauth, "enabled", lambda: False)
    monkeypatch.setattr(web.settings.discovery, "verify_enabled", True, raising=False)
    calls = []
    orig = star.live_status

    async def _counted(r):
        calls.append(r)
        return await orig(r)
    star.live_status = _counted
    monkeypatch.setattr(web, "SWITCH_WAIT_STEP_S", 0.001)
    for _ in range(5):                           # 模拟 5 拍 30s 轮询
        resp = await web._switch_admit("321", "2678075", None)
        assert b"live_unverifiable" in bytes(resp.body)
    assert len(calls) == 1, f"同房重复探测没有被冷却钳住:打了 {len(calls)} 次"


async def test_gate_loser_waits_for_the_winner(monkeypatch):
    """真机 12 路并发实测才暴露的:冷却把上游探测正确钳到 1 次,但另外 11 路当场
    吃 400。而这个并发不是假想 —— 启动时 mergeMyRooms→upsertCustomRoom 与
    loadRoom 会为同一个房各发一次 profile?switch=1,多标签页更是叠乘。
    赢家通常数百毫秒内就自愈完成,输家盯着 rooms:active 等一小会儿即可。"""
    from app import web

    class _LoserBus(_SwitchBus):
        def __init__(self, *a, **k):
            super().__init__(*a, **k)
            self.polls = 0

        async def verify_probe_gate(self, room, ttl_s):
            return False                       # 恒定输掉闸

        async def is_active(self, room):
            self.polls += 1
            if self.polls > 3:                 # 第 3 拍后赢家自愈完成
                self._a.add(str(room))
            return str(room) in self._a
    bus = _LoserBus({"999"})
    monkeypatch.setattr(web.ST, "bus", bus, raising=False)
    monkeypatch.setattr(web.ST, "db", _SwitchDB(), raising=False)
    monkeypatch.setattr(web.ST, "star", _FakeStar(RuntimeError("输家不该打上游")),
                        raising=False)
    monkeypatch.setattr(web.userauth, "enabled", lambda: False)
    monkeypatch.setattr(web.settings.discovery, "verify_enabled", True, raising=False)
    monkeypatch.setattr(web, "SWITCH_WAIT_STEP_S", 0.001)
    assert await web._switch_admit("321", "2678075", None) is None, \
        "赢家已经自愈,输家却还在报错"


def test_gate_wait_is_bounded():
    """输家的等待只发生在「本就要失败」的那条路上,上界必须小。"""
    from app import web
    assert web.SWITCH_WAIT_ROUNDS * web.SWITCH_WAIT_STEP_S <= 2.0


def test_add_path_is_not_throttled_by_the_switch_cooldown():
    """添加是用户一次性的深思熟虑动作,不该因为别人刚探过同一个房就被拒
    (「我明明看着他在播」)。冷却参数只由切房路径传。"""
    body = WEB_SRC.split("async def monitor_add", 1)[1].split("\n@app.", 1)[0]
    assert "probe_gate" not in body, "添加路径被切房冷却波及了"
    sw = WEB_SRC.split("async def _switch_admit", 1)[1].split("\nasync def ", 1)[0]
    assert "_switch_probe_gate(rid)" in sw, "切房路径没抢同房闸"


def test_sweep_does_not_rewrite_the_clock_every_round():
    """台账时钟只需落在 grace 之内,精确到分钟毫无意义。不设地板的话 ①② 每轮都会
    给几乎每一行发一条 UPDATE —— 发现房 last_seen 每 60s 就变,万行台账 = 每轮
    一万条 UPDATE(还要连带 WAL)。"""
    body = WORKER_SRC.split("async def _verify_sweep_once", 1)[1] \
        .split("\n    async def ", 1)[0]
    assert "refresh_floor" in body
    assert "int(interval_s) * 1000 // 4" in body, "地板应随复核周期缩放"
    # 地板之下必须仍然 continue —— 否则跳过写入的行会掉进 ③ 被白探一次
    seg = body.split("seen is not None", 1)[1].split("if rid in curated", 1)[0]
    assert "continue" in seg, "①未命中地板时漏了 continue,该行会被白探一次"
    seg2 = body.split("if rid in curated", 1)[1].split("nxt_at =", 1)[0]
    assert "continue" in seg2, "②未命中地板时漏了 continue,该行会被白探一次"


async def test_nonexistent_room_is_terminal_not_transient(monkeypatch):
    """真机复核(2026-09-06,打 roomStatus)暴露的口径缺口:上游对**根本不存在的
    房号**也回 code=0 / liveStatus=-1 / kugouId 缺省,与「网络问不到」在
    live_status 那层被压成同一个 None。于是敲错房号只会得到「暂时核实不了,
    请稍后再试」然后无限重试。归一之后两者分得开:真号带得出主播资料
    (321→2678075 有昵称与 kugouId),不存在的号资料全空。"""
    from app import web

    class _Blank:
        async def live_status(self, r): return None
        async def profile(self, r): return {"nickname": "", "avatar": "", "kugouId": 0}

    class _Known:
        async def live_status(self, r): return None
        async def profile(self, r): return {"nickname": "321音乐频道", "avatar": "",
                                            "kugouId": 1192670741}
    monkeypatch.setattr(web.settings.discovery, "verify_enabled", True, raising=False)
    monkeypatch.setattr(web.settings.discovery, "prune_grace_s", 604800, raising=False)
    monkeypatch.setattr(web.ST, "db", _FakeDB(None), raising=False)
    monkeypatch.setattr(web.ST, "bus", _FakeBus(), raising=False)

    monkeypatch.setattr(web.ST, "star", _Blank(), raising=False)
    body = bytes((await web._verify_admit("999999999")).body)
    assert b"room_unresolved" in body, "不存在的房号仍被说成「暂时」—— 用户会无限重试"

    monkeypatch.setattr(web.ST, "star", _Known(), raising=False)
    body = bytes((await web._verify_admit("2678075")).body)
    assert b"live_unverifiable" in body, \
        "真号只是这一拍问不到,不能被改判成「查不到这个直播间」"


@pytest.mark.skipif(not APP_JS.is_file(), reason="前端不在本仓")
def test_room_unresolved_is_in_the_frontend_terminal_set():
    """新口径要真正止损,前端必须把它当终态清卡;否则只是换了句文案,
    用户照样每 3~30s 重试一个后端已经说了「查不到」的房。"""
    src = APP_JS.read_text(encoding="utf-8")
    body = src.split("async function loadRoom", 1)[1].split("\nfunction ", 1)[0]
    term = body.split("].includes((e && e.data && e.data.error)", 1)[0]
    assert "room_unresolved" in term
    up = src.split("function upsertCustomRoom", 1)[1].split("\nfunction ", 1)[0]
    assert "room_unresolved" in up


# ══ ⑦ 切换即添加(5.0.8):登录态下 room_not_bound 不再是死胡同,但不许变成自动打上游 ══
def _fn_body(src: str, head: str) -> str:
    """取某个 JS 顶层函数的正文(到下一个顶层 `function ` / `async function ` 为止)。"""
    tail = src.split(head, 1)[1]
    cut = len(tail)
    for m in re.finditer(r"\n(?:async )?function ", tail):
        cut = m.start()
        break
    return tail[:cut]


@pytest.mark.skipif(not APP_JS.is_file(), reason="前端不在本仓")
def test_switch_autobind_only_on_explicit_actions():
    """撞到 room_not_bound 才补绑,且只在显式动作上做:跟随 / 存储恢复 / 退避重试都是
    explicit=false 的路,一旦也补绑,残影卡会按 30s×标签页数的节奏打上游
    (monitor/add 没有同房冷却)。每次切房只补一次(bindTry),失败不进退避。"""
    src = APP_JS.read_text(encoding="utf-8")
    body = _fn_body(src, "async function loadRoom")
    assert "bindTry = 0" in body.split("{", 1)[0] + "{" + body.split("{", 1)[1][:200], \
        "loadRoom 没有 bindTry 预算(补绑必须有上限)"
    i = body.index("=== 'room_not_bound'")
    gate = body[max(0, i - 200):i]
    assert "explicit && AUTH.enabled && bindTry < 1" in gate, \
        "补绑分支必须同时受 explicit / AUTH.enabled / bindTry 三重门"
    branch = body[i:body.index("// 3.9.3 last-wins", i)]
    assert "/api/monitor/add?room=${encodeURIComponent(alias)}`, { timeout: 15000 }" in branch, \
        "补绑必须走 /api/monitor/add 且超时覆盖上游核验(≥12s)"
    assert branch.index("/api/monitor/add") < branch.index("saveMyRooms("), \
        "落盘必须在后端应答之后(被拒的房不得残留在 localStorage)"
    assert "bindTry: bindTry + 1" in branch, "重载没带 bindTry+1 —— 绑定已落却仍 403 时会打转"
    assert "S.roomRetryT = setTimeout" not in branch, "补绑失败不得进退避重试(只会重复同一个 403)"
    assert "removeCustomRoom(alias, { message: msg })" in branch, "终态(未开播/号不存在)的残影卡要清退"
    for code in ("not_live_now", "room_unresolved"):
        assert code in branch, f"终态 {code} 没接住"
    assert "'live_unverifiable'" not in branch, "问不到是瞬态 —— 不得据此清卡"


@pytest.mark.skipif(not APP_JS.is_file(), reason="前端不在本仓")
def test_search_box_adds_then_opens_only_when_login_enabled():
    """搜索框敲号:登录态下不在名录 → 先加后看;未启用登录维持「看而不加」(5.0.3)。
    名额先拦、落盘在后端应答之后、网络失败不做乐观入名录。"""
    src = APP_JS.read_text(encoding="utf-8")
    ds = src.split("const doSearch = () => {", 1)[1].split("\n  };", 1)[0]
    assert "if (!hit && AUTH.enabled) return addAndOpenRoom(alias);" in ds
    assert ds.index("addAndOpenRoom(alias)") < ds.index("loadRoom(alias, { explicit: true })"), \
        "未登录/命中名录的旧路径必须保留在自动添加之后"
    fn = _fn_body(src, "async function addAndOpenRoom")
    assert fn.index("roomsFull()") < fn.index("/api/monitor/add"), "满额应在打上游之前拦下"
    assert "/api/monitor/add?room=${encodeURIComponent(alias)}`, { timeout: 15000 }" in fn
    assert fn.index("/api/monitor/add") < fn.index("saveMyRooms("), "落盘必须在后端应答之后"
    assert "bindTry: 1" in fn, "添加后打开须带 bindTry=1,防同房再补绑"
    assert "upsertCustomRoom(alias)" in fn and "toast(" in fn, "自动入名录必须告知用户"
    # 自动路径绝不能碰 monitor/add:并卡(每 30s)与晚到回填都是无人触发的循环
    for head in ("function upsertCustomRoom", "function mergeMyRooms", "function lateFillProfile",
                 "async function refreshLiveRooms"):
        assert "api(`/api/monitor/add" not in _fn_body(src, head), f"{head} 不得自动打 monitor/add"
    # 切房与名录并卡仍是仅有的两处 switch=1(添加路径不带旗:预检房本就不在后台)
    assert src.count("/profile?switch=1") == 2


def test_room_not_bound_message_has_no_positional_wording():
    """5.0.2 定案:提示只述状态、零方位依赖 —— 图标轨下左侧只有裸「＋」,手机上侧栏
    是收起的抽屉。room_not_bound 的文案此前是漏网的一处。"""
    body = WEB_SRC.split("async def _user_room_deny", 1)[1].split("\n\n\n", 1)[0]
    assert "room_not_bound" in body
    msg = re.search(r'"message":\s*"([^"]*)"', body.split("room_not_bound", 1)[1]).group(1)
    assert "左侧" not in msg, f"room_not_bound 文案仍带方位词: {msg}"
