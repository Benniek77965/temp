"""
test_lifecycle.py — 数据生命周期(5.4.0)的机器保证
================================================================================
回答「库里每一张表凭什么不会无限增长」不能靠文档自觉。本文件钉四类不变量:

  A. **没有漏网的表**:两份建表 DDL 里的每张表都登记了生命周期策略(静态);
     真库里实际存在的表也逐张对得上(联测)。新增一张表而不登记 → 当场变红。
  B. **没有漏网的审计动作**:admin_api 里出现的每个审计动作都被显式归类为
     「会话类(滚动删)」或「操作类(永久)」—— 不让新动作静默落进某个默认档。
  C. **清扫引擎的行为**:分批、自适应、逐表隔离、节拍(启动即扫 / 积压续扫 /
     失败快重试)、维护通道超时不熔断入口。旧 `_janitor` 的五个缺陷各有一条钉。
  D. **真库端到端**:只删该删的 —— 已支付订单、有效会话、未过期流水、操作类审计、
     在册房的状态,一行不少。

三层,与项目既有测试同款姿态:
  · 纯单元 / 静态(恒跑,零外部依赖);
  · MySQL 联测(需本地用户库 127.0.0.1:3307;不可达整层 skip);
  · PostgreSQL 联测(需 STA_PG_DSN;未设整层 skip)。
联测各自使用独立的库 / 带前缀的行,不碰其它测试的数据。
"""
from __future__ import annotations

import asyncio
import contextlib
import calendar
import os
import re
import socket
import sys
import time
import warnings
from pathlib import Path

import pytest
import pytest_asyncio

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import admin_api, config_registry as reg, db as dbmod, jfvip, lifecycle, userauth, userdb_pool  # noqa: E402
from app.settings import RetentionCfg, UserAuthCfg, settings  # noqa: E402
from tests._srcscan import js_code, py_code  # noqa: E402

APP = Path(__file__).resolve().parent.parent / "app"
ROOT = Path(__file__).resolve().parents[2]


def _fn_body(src: str, head: str) -> str:
    """切出从 head(如 "async def storage_sweep")到下一个顶层定义之前的完整函数体。
    静态检查一律按函数体判断,不用「开头往后 N 个字符」这种固定窗口 —— 第四轮复查:
    说明文字多写一行,守卫调用就被挤出窗口,测试误报失败(反过来也可能误报通过)。"""
    i = src.index(head)
    indent = len(head) - len(head.lstrip(" "))          # 方法按自身缩进判结束,不一路切到类末尾
    m = re.compile(r"\n {0,%d}(?:async def |def |class |@|function |async function |const [A-Za-z_]+ = )"
                   % indent).search(src, i + len(head))
    return src[i:m.start() if m else len(src)]


# ══════════════════════════════════════════════════════════════════════════════
# A. 全表登记:没有漏网的表
# ══════════════════════════════════════════════════════════════════════════════
def _ddl_tables(sql: str) -> set:
    return set(re.findall(r"CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+([A-Za-z_][A-Za-z0-9_]*)", sql, re.I))


def test_every_pg_table_in_schema_is_registered():
    """db.SCHEMA 里建的每张表都必须登记;登记里也不许有 SCHEMA 之外的幽灵表。"""
    ddl = _ddl_tables(dbmod.SCHEMA)
    assert len(ddl) >= 11, f"扫描式失效:只扫到 {sorted(ddl)}"
    regd = {p.table for p in lifecycle.tables("pg")}
    assert ddl - regd == set(), f"这些 PG 表没有登记生命周期策略: {sorted(ddl - regd)}"
    assert regd - ddl == set(), f"登记了并不存在的 PG 表: {sorted(regd - ddl)}"


def test_every_mysql_table_in_schema_is_registered():
    ddl = _ddl_tables("\n".join(userauth._SCHEMA))
    assert len(ddl) >= 10, f"扫描式失效:只扫到 {sorted(ddl)}"
    regd = {p.table for p in lifecycle.tables("mysql")}
    assert ddl - regd == set(), f"这些用户库表没有登记生命周期策略: {sorted(ddl - regd)}"
    assert regd - ddl == set(), f"登记了并不存在的用户库表: {sorted(regd - ddl)}"


def test_registry_entries_are_complete_and_point_at_real_knobs():
    """每条登记都得把话说全(怎么清 / 凭什么有界 / 谁来清),引用的参数必须真实存在 ——
    管理台「储」视图把这些文字原样给运维看,写一个不存在的参数名等于指错路。"""
    for key, p in lifecycle.TABLES.items():
        assert key == f"{p.store}:{p.table}"
        assert p.klass in lifecycle.KLASS_LABEL, key
        assert len(p.policy) >= 8 and len(p.bound) >= 6 and p.sweeper, key
        for k in p.knobs:
            assert k in reg.REGISTRY, f"{key} 引用了不存在的参数 {k}"
    # 「不自动删」只允许出现在三类上:账本 / 人工追加 / 行数受实体数约束的状态表
    for key, p in lifecycle.TABLES.items():
        if p.sweeper == lifecycle.SWEEP_NONE:
            assert p.klass in (lifecycle.LEDGER, lifecycle.OPERATOR, lifecycle.STATE), \
                f"{key} 既不清理、又不属于账本/人工追加/状态表 —— 它凭什么有界?"
    # 滚动流水与到期即删必须有人清
    for key, p in lifecycle.TABLES.items():
        if p.klass in (lifecycle.ROLLING, lifecycle.EXPIRING):
            assert p.sweeper not in (lifecycle.SWEEP_NONE, lifecycle.SWEEP_INLINE), key


# ══════════════════════════════════════════════════════════════════════════════
# B. 审计动作分级:没有漏网的动作
# ══════════════════════════════════════════════════════════════════════════════
def _backend_audit_actions() -> set:
    api = py_code(APP / "admin_api.py")
    acts = set(re.findall(r'_audit\([^,\n]+,\s*"([a-z_]+)"', api))
    acts |= set(re.findall(r'audit_add\(now_ms\(\),\s*[^,\n]+,\s*"([a-z_]+)"', api))
    acts |= set(re.findall(r'_adm_audit_capped\([^,\n]+,\s*[^,\n]+,\s*"([a-z_]+)"', api))
    acts |= set(re.findall(r'\baction\s*(?::\s*str\s*)?=\s*"([a-z_]+)"', api))        # action = "login" / action: str = "apply"
    for a, b in re.findall(r'"([a-z_]+)"\s+if\s+\w+\s+else\s+"([a-z_]+)"', api):       # 三元:reg_unblock / reg_block
        if a.startswith(("reg_", "jfvip_", "login")) or b.startswith(("reg_", "jfvip_", "login")):
            acts |= {a, b}
    return acts


def test_every_audit_action_is_classified():
    """admin_audit 的保留策略按动作分级:会话类滚动删、操作类永久。两个名单必须
    **恰好**覆盖后端实际写出的全部动作 —— 新增动作不表态就红;名单里留着后端
    已不存在的动作(幽灵)也红。"""
    back = _backend_audit_actions()
    assert len(back) >= 25, f"扫描式失效:只扫到 {sorted(back)}"
    sess, evid = set(lifecycle.AUDIT_SESSION_ACTIONS), set(lifecycle.AUDIT_EVIDENCE_ACTIONS)
    assert sess & evid == set(), f"同一动作被归进两类: {sorted(sess & evid)}"
    assert back - (sess | evid) == set(), (
        f"审计动作 {sorted(back - (sess | evid))} 没有归类 —— 请在 lifecycle.AUDIT_SESSION_ACTIONS"
        f"(会被攻击放大、留够合规期后滚动删)或 AUDIT_EVIDENCE_ACTIONS(操作证据、永久)里表态")
    assert (sess | evid) - back == set(), f"名单里有后端已不存在的动作: {sorted((sess | evid) - back)}"
    # 删卡墓碑是被删卡号的唯一存证(JFVIP-SYSTEM.md §6.3),必须在「永久」一侧
    for must in ("jfvip_cards_purge", "jfvip_grant", "jfvip_revoke", "jfvip_cards_issue",
                 "apply", "rollback", "config_reveal"):
        assert must in evid, f"{must} 必须永久保留"
    # 会被未鉴权请求放大的那几类必须在「滚动删」一侧,否则审计表无上界
    for must in ("login_fail", "login_captcha_fail", "login_ticket_fail"):
        assert must in sess, f"{must} 会被攻击放大,必须滚动删"


def test_retention_defaults_cover_six_calendar_months():
    """默认 184 天的来历:任意连续六个自然月的最长天数。写 180 会在含大月的半年里
    少留 1~4 天,不满足「留存不少于六个月」(《网络安全法》第二十三条第(三)项)。"""
    longest = 0
    for year in (2026, 2027, 2028):                 # 含闰年
        for m0 in range(1, 13):
            days = 0
            for k in range(6):
                y, m = year + (m0 - 1 + k) // 12, (m0 - 1 + k) % 12 + 1
                days += calendar.monthrange(y, m)[1]
            longest = max(longest, days)
    assert longest == 184
    assert UserAuthCfg().log_retention_days == 184
    assert RetentionCfg().audit_days == 184
    assert UserAuthCfg().jf_order_unpaid_retention_days == 184
    assert UserAuthCfg().reg_log_retention_days == -1          # 跟随登录流水
    assert UserAuthCfg().log_max_rows == 5_000_000
    assert RetentionCfg().state_gc is True
    # 卡密池排水仍默认关(「不配置即不存在」;误删=资损)—— 本轮没有动它
    assert UserAuthCfg().jf_card_disabled_age_days == 0
    assert UserAuthCfg().jf_card_used_retention_days == 0


# ══════════════════════════════════════════════════════════════════════════════
# C. 清扫引擎
# ══════════════════════════════════════════════════════════════════════════════
@pytest.mark.asyncio
async def test_run_batched_drains_and_grows_batch(monkeypatch):
    """快批 → 批量翻倍;装不满的一批 = 删干净,立即收手。"""
    monkeypatch.setattr(lifecycle, "PAUSE_S", 0.0)
    left, seen = [50_000], []

    async def step(n):
        seen.append(n)
        k = min(n, left[0]); left[0] -= k
        return k
    r = await lifecycle.run_batched(step)
    assert r["deleted"] == 50_000 and left[0] == 0 and not r["capped"] and r["error"] == ""
    assert seen[0] == lifecycle.BATCH_START and max(seen) > seen[0], seen     # 自适应放大
    assert max(seen) <= lifecycle.BATCH_MAX
    assert set(r) == set(lifecycle._empty_result()), "结果字典键集合必须恒定(消费方不逐键判空)"


@pytest.mark.asyncio
async def test_run_batched_shrinks_on_failure_then_gives_up(monkeypatch):
    """单批失败(超时/锁等待)→ 批量砍到 1/4 再试;连续失败 MAX_FAILS 次才放弃并留下错误。"""
    monkeypatch.setattr(lifecycle, "PAUSE_S", 0.0)
    seen = []

    async def heavy(n):                       # 只有 ≤500 行的批才扛得住
        seen.append(n)
        if n > 500:
            raise asyncio.TimeoutError()
        return 0
    r = await lifecycle.run_batched(heavy)
    assert seen == [2000, 500] and r["error"] == "" and r["deleted"] == 0     # 收小后成功

    async def dead(n):
        seen.append(n)
        raise ConnectionError("userdb down")
    seen.clear()
    r = await lifecycle.run_batched(dead)
    assert len(seen) == lifecycle.MAX_FAILS and "ConnectionError" in r["error"]
    assert seen == sorted(seen, reverse=True) and seen[-1] < seen[0]


@pytest.mark.asyncio
async def test_run_batched_budget_caps_and_fixed_limit(monkeypatch):
    """时间预算用尽 → capped(余量留给 60s 后的续扫);fixed 模式批量恒定。"""
    monkeypatch.setattr(lifecycle, "PAUSE_S", 0.0)
    calls = []

    async def endless(n):
        calls.append(n)
        return n
    r = await lifecycle.run_batched(endless, budget_s=0.0)
    assert r["capped"] and r["batches"] == 1 and r["deleted"] == lifecycle.BATCH_START
    calls.clear()
    left = [12_000]

    async def fixed(n):
        calls.append(n)
        k = min(5000, left[0]); left[0] -= k
        return k
    r = await lifecycle.run_batched(fixed, fixed=5000)
    assert calls == [5000, 5000, 5000] and r["deleted"] == 12_000 and r["batch"] == 5000


@pytest.mark.asyncio
async def test_run_batched_fixed_mode_shrinks_on_failure(monkeypatch):
    """第九轮:固定批量模式(卡密池排水的 5000)单批失败时也要收缩重试 —— 两阶段之后每批都按
    传入的批量执行;旧版固定模式失败即放弃,慢库上会每轮以同样的 5000 超时、永远前进不了。"""
    monkeypatch.setattr(lifecycle, "PAUSE_S", 0.0)
    seen, left = [], [3000]

    async def step(n):
        seen.append(n)
        if n > 1500:
            raise asyncio.TimeoutError()        # 5000 一批太重
        k = min(n, left[0]); left[0] -= k
        return k
    r = await lifecycle.run_batched(step, fixed=5000)
    assert seen[:2] == [5000, 1250], seen        # 失败后收缩到 1/4,之后批量固定、不再放大
    assert all(x == 1250 for x in seen[1:]) and r["deleted"] == 3000 and r["error"] == ""


@pytest.mark.asyncio
async def test_run_tasks_isolates_a_failing_table(capsys):
    """★ 旧 _janitor 的缺陷③:五张表共用一个 try,一张失败后面的全被跳过。"""
    ran = []

    async def ok(name, n):
        ran.append(name)
        return {"deleted": n}

    async def boom():
        ran.append("boom")
        raise RuntimeError("lock wait timeout")
    res = await lifecycle.run_tasks("unit", [
        ("t1", "a", lambda: ok("t1", 3)), ("t2", "b", boom), ("t3", "c", lambda: ok("t3", 4))])
    assert ran == ["t1", "boom", "t3"], "失败的表之后的任务必须照常执行"
    assert res["deleted"] == 7 and res["errors"] == 1 and not res["capped"]
    assert "lock wait timeout" in res["tasks"]["t2:b"]["error"]
    assert lifecycle.STATUS["stores"]["unit"]["tasks"]["t3:c"]["deleted"] == 4
    out = capsys.readouterr().out
    assert "清扫失败 t2:b" in out, "★ 缺陷④:失败必须有日志,不许静默"
    lifecycle.STATUS["stores"].pop("unit", None)
    lifecycle.STATUS["total_deleted"].pop("unit", None)


@pytest.mark.asyncio
async def test_run_loop_cadence(monkeypatch):
    """★ 缺陷①(先睡 6 小时)与两条新节拍:首扫在启动后 45~120s;没清完 60s 续扫;
    报错/库未就绪 10 分钟重试;一切正常才是 6 小时。"""
    delays, results = [], [{"capped": True}, {"errors": 1}, {"skipped": True}, {"deleted": 0}]

    class _Stop(Exception):
        pass

    async def fake_sleep(d):
        delays.append(d)
        if len(delays) > len(results):
            raise _Stop()
    n = [0]

    async def sweep():
        n[0] += 1
        return results[n[0] - 1]
    monkeypatch.setattr(lifecycle, "_sleep", fake_sleep)
    with pytest.raises(_Stop):
        await lifecycle.run_loop("unit_loop", sweep)
    lo, hi = lifecycle.FIRST_DELAY_S
    assert lo <= delays[0] <= hi <= 300, f"首扫必须在启动后几分钟内,实得 {delays[0]}s"
    assert delays[1:] == [lifecycle.BACKLOG_DELAY_S, lifecycle.RETRY_DELAY_S,
                          lifecycle.RETRY_DELAY_S, lifecycle.INTERVAL_S]
    assert lifecycle.BACKLOG_DELAY_S <= 120 and lifecycle.RETRY_DELAY_S <= 900
    lifecycle.STATUS["stores"].pop("unit_loop", None)


@pytest.mark.asyncio
async def test_exclusive_rejects_concurrent_sweep_of_same_store():
    gate = asyncio.Event()

    async def slow():
        await gate.wait()
        return {"deleted": 1}
    t = asyncio.create_task(lifecycle.exclusive("unit_x", slow))
    await asyncio.sleep(0)
    assert (await lifecycle.exclusive("unit_x", slow)) == {"busy": True}
    gate.set()
    assert (await t) == {"deleted": 1}
    assert "unit_x" not in lifecycle._RUNNING


def _janitor_segment() -> str:
    src = py_code(APP / "userauth.py")
    return src[src.index("async def _janitor"):src.index("async def _authenticate")]


def test_janitor_old_pitfalls_are_gone():
    """旧实现的四个形态一个都不许回来(静态钉;行为由下方联测兜)。"""
    seg = _janitor_segment()
    assert "6 * 3600" not in seg and "sleep(" not in seg, "清扫节拍必须交给 lifecycle.run_loop"
    assert not re.search(r"except Exception:\s*(#[^\n]*)?\n\s*pass", seg), "不许静默吞异常"
    assert "_q_maint(" in seg, "清扫语句必须走维护通道"
    assert not re.search(r"(?<![A-Za-z_])_q\(", seg), "清扫语句不许走业务通道 _q(超时会熔断入口)"
    dels = [m.start() for m in re.finditer(r'f?"DELETE (?:t )?FROM', seg)]    # 只认字符串字面量里的语句,说明文字不算
    assert len(dels) >= 2
    assert "_jn_delete(" not in seg.replace("_jn_delete_2p(", ""), "不许再有单阶段删除"
    for i in dels:          # 全部删除都是两阶段:按「先选出的主键清单」删、强制走主键、不带 LIMIT
        stmt = seg[i:seg.find(")", seg.find("id IN (", i) + 8) + 220] if "id IN (" in seg[i:i + 200] else seg[i:i + 200]
        assert "id IN (" in stmt, f"存在不是按主键清单的 DELETE: {seg[i:i + 90]!r}"
        assert "FORCE INDEX (PRIMARY)" in stmt, f"按主键清单删除必须强制走主键: {seg[i:i + 120]!r}"
        assert "LIMIT" not in seg[i:i + 160], \
            f"DELETE 不许带 LIMIT(语句格式 binlog 下不安全、主从可能不一致): {seg[i:i + 120]!r}"
    # 流水表 / 票据表的第一阶段必须按与条件对齐的索引列取主键(ORDER BY id 在没有过期行时会扫全表)
    assert seg.count('order="created_at"') >= 1 and 'order="expires_at"' in seg
    # 已支付订单是账本:订单清理的条件必须带 credited=0 与未支付状态,且全段不出现对开通流水的删除
    m = re.search(r'_jn_delete(?:_2p)?\(\s*"guantai_jf_order",\s*"([^"]*)"', seg)
    assert m and "credited=0" in m.group(1) and "'pending','expired'" in m.group(1), "订单清理条件不对"
    assert "DELETE FROM guantai_jf_grant_log" not in seg
    assert not re.search(r'_jn_delete(?:_2p)?\(\s*"guantai_jf_grant_log"', seg)
    # 扫描范围里混着不该删的行的三张表必须走两阶段(第七轮复查:单条 DELETE 会锁住它们)
    for t in ("guantai_user_session", "guantai_jf_order", "guantai_jf_card", "guantai_sso_ticket"):
        assert re.search(r'_jn_delete_2p\(\s*"' + t + '"', seg), f"{t} 的清扫必须走两阶段删除"
    for m in re.finditer(r"ORDER BY id LIMIT", seg):            # 只允许:按主键截断 / 两阶段的选主键快照读
        ctx = seg[max(0, m.start() - 120):m.start()]
        assert "id <= %s" in ctx or "revoked=1" in ctx or "SELECT id FROM" in ctx, \
            f"按时间删的语句不许 ORDER BY id(实测会对全部命中行 filesort): {ctx!r}"


def test_ledger_tables_are_never_deleted_by_app_code():
    """账本(开通流水)在 app/ 下不存在任何 DELETE;订单表的 DELETE 恰好一处且带 credited=0。"""
    hits = []
    for path in sorted(APP.rglob("*.py")):
        src = py_code(path)
        assert "DELETE FROM guantai_jf_grant_log" not in src, f"{path.name} 删了对账流水"
        assert not re.search(r'_jn_delete(?:_2p)?\(\s*"guantai_jf_grant_log"', src), f"{path.name} 删了对账流水"
        hits += [(path.name, m.start()) for m in re.finditer(
            r'DELETE FROM guantai_jf_order|_jn_delete(?:_2p)?\(\s*"guantai_jf_order"', src)]
    assert [h[0] for h in hits] == ["userauth.py"], f"订单表的删除应恰好一处: {hits}"


@pytest.mark.asyncio
async def test_run_maint_timeout_does_not_trip_breaker():
    """★ 缺陷②的另一半:维护通道超时**不**熔断入口、不拆池;业务通道 run() 的行为一字未动。"""
    r = userdb_pool.Router(UserAuthCfg(host="10.255.255.1", db="d", user="u"), query_timeout_s=1.0)
    ep = r.endpoints[0]
    ep.pool, seen = object(), {}

    async def slow(ep_, sql, args, fetch, timeout_s=None, maint=False):
        seen.update(timeout_s=timeout_s, maint=maint)
        raise asyncio.TimeoutError()
    r._run_on = slow                                             # type: ignore[assignment]
    with pytest.raises(asyncio.TimeoutError):
        await r.run_maint("DELETE FROM guantai_login_log LIMIT 1", timeout_s=7.0)
    assert seen == {"timeout_s": 7.0, "maint": True}
    assert ep.state != "down" and ep.fail_streak == 0 and ep.pool is not None

    async def slow_biz(ep_, sql, args, fetch):                   # run() 仍按 4 个位置参数调用
        raise asyncio.TimeoutError()
    r._run_on = slow_biz                                         # type: ignore[assignment]

    async def _noop(ep_, wait=False):
        ep_.pool = None
    r._drop_pool = _noop                                         # type: ignore[assignment]
    with pytest.raises(asyncio.TimeoutError):
        await r.run("DELETE FROM guantai_login_log LIMIT 1")
    assert ep.state == "down" and ep.fail_streak >= 1 and ep.pool is None, "业务通道的熔断语义不许变"


def test_quick_alerts_flag_dangerous_config(monkeypatch):
    """保留期被关掉 = 迟早写满磁盘:必须有人话告警(总览首屏与「储」视图共用)。"""
    monkeypatch.setattr(settings.retention, "days", 0.0)
    texts = " | ".join(a["text"] for a in lifecycle.quick_alerts())
    assert "永久保留" in texts and "rounds" in texts
    monkeypatch.setattr(settings.retention, "days", 7.0)
    monkeypatch.setitem(lifecycle.STATUS["stores"], "pg", {
        "at_ms": lifecycle.now_ms(), "tasks": {"admin_audit:x": {
            "table": "admin_audit", "rule": "x", "error": "TimeoutError", "deleted": 0}}})
    bad = [a for a in lifecycle.quick_alerts() if a["level"] == "bad"]
    assert bad and "admin_audit" in bad[0]["text"] and "TimeoutError" in bad[0]["text"]
    # 清扫停摆:上次清扫是很久以前
    monkeypatch.setitem(lifecycle.STATUS["stores"], "pg", {
        "at_ms": lifecycle.now_ms() - int(lifecycle.INTERVAL_S * 3 * 1000), "tasks": {}})
    assert any("没有跑过" in a["text"] for a in lifecycle.quick_alerts())


# ── 管理接口:守卫 / 接线 / 前端 ────────────────────────────────────────────────
def _req(method="GET", headers=None):
    from starlette.requests import Request
    hs = [(k.lower().encode(), v.encode()) for k, v in (headers or {}).items()]
    return Request({"type": "http", "method": method, "path": "/", "query_string": b"",
                    "headers": hs, "client": ("203.0.113.9", 1), "scheme": "http",
                    "server": ("t", 80)})


@pytest.mark.asyncio
async def test_storage_endpoints_are_guarded(monkeypatch):
    """读要会话,「立即清扫」另要 CSRF 双提交 —— 与全部既有写端点同一道闸。"""
    from app import admin_auth
    monkeypatch.setattr(admin_auth, "enabled", lambda: False)
    assert (await admin_api.storage(_req(), fresh=0)).status_code == 503
    monkeypatch.setattr(admin_auth, "enabled", lambda: True)
    monkeypatch.setattr(admin_auth, "ip_allowed", lambda ip: True)
    monkeypatch.setattr(admin_auth, "parse_session", lambda v: None)
    assert (await admin_api.storage(_req(), fresh=0)).status_code == 401
    assert (await admin_api.storage_sweep(_req("POST"))).status_code == 401
    monkeypatch.setattr(admin_auth, "parse_session", lambda v: {"csrf": "tok"})
    r = await admin_api.storage_sweep(_req("POST", {"x-admin-csrf": "wrong"}))
    assert r.status_code == 403, "缺 CSRF 的清扫请求必须被拒"
    api = py_code(APP / "admin_api.py")
    body = _fn_body(api, "async def storage_sweep")
    assert "_guard_write(request)" in body and '"storage_sweep"' in body, "立即清扫必须走写守卫并落审计"
    assert body.index("_guard_write(request)") < body.index("lifecycle.sweep_now("), "必须先过守卫再动手"


def test_frontend_storage_view_is_wired():
    html = (ROOT / "admin.html").read_text(encoding="utf-8")
    if not html:
        pytest.skip("前端不在本仓")
    js = js_code(ROOT / "assets" / "admin.js")
    assert 'data-view="storage"' in html and "存储与保留" in html
    assert len(re.findall(r'class="nav-item"', html)) == 12 and "十二枚印" in html and "十一枚" not in html
    assert "storage: '存储与保留'" in js and "storage: renderStorage" in js
    assert "async function renderStorage()" in js and "'/storage/sweep'" in js
    assert "o.storage_alerts" in js, "存储告警必须上总览首屏(不点进「储」也看得见)"
    assert "sw.redis" in js and "['pg', 'mysql', 'redis']" in js, "Redis 快照回收要在「储」里看得见"
    assert "存储体检读取失败" in _fn_body(js, "async function renderStorage()"), "读取失败必须诚实报错,不许伪装成空态"


def test_docs_cover_every_registered_table():
    """DATA-LIFECYCLE.md 是给人看的同一份登记:每张表都要出现;并且不许再留着那句
    已被证伪的「卡密表是唯一没有保留策略的表」。"""
    doc = (ROOT / "DATA-LIFECYCLE.md").read_text(encoding="utf-8")
    for p in lifecycle.TABLES.values():
        assert f"`{p.table}`" in doc, f"DATA-LIFECYCLE.md 没提到表 {p.table}"
    for tpl in lifecycle.REDIS_FAMILIES:
        assert f"`{tpl}`" in doc, f"DATA-LIFECYCLE.md 没提到 Redis 键族 {tpl}"
    for kw in ("184", "log_max_rows", "run_maint", "第二十三条", "账本", "heavy_reads", "5.7.42"):
        assert kw in doc, f"DATA-LIFECYCLE.md 缺关键内容 {kw!r}"
    jf = (ROOT / "JFVIP-SYSTEM.md").read_text(encoding="utf-8")
    assert "DATA-LIFECYCLE.md" in jf, "JFVIP-SYSTEM.md §6.3 应指向全表登记"


# ══════════════════════════════════════════════════════════════════════════════
# D1. MySQL 联测(本地用户库;不可达整层 skip)
# ══════════════════════════════════════════════════════════════════════════════
_HOST = os.environ.get("STA_TEST_USERDB_HOST", "127.0.0.1")
_PORT = int(os.environ.get("STA_TEST_USERDB_PORT", "3307"))
_USER = os.environ.get("STA_TEST_USERDB_USER", "root")
_PASS = os.environ.get("STA_TEST_USERDB_PASSWORD", "")
_DB = os.environ.get("STA_TEST_LIFECYCLE_DB", "fx_lifecycle_test")
_TB_USER = """CREATE TABLE IF NOT EXISTS tb_user (
  id BIGINT NOT NULL AUTO_INCREMENT,
  user_name VARCHAR(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL,
  pass_word VARCHAR(50) NOT NULL, register_time DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  due_time DATETIME NOT NULL, is_off VARCHAR(1) NOT NULL DEFAULT '0',
  PRIMARY KEY(id), UNIQUE KEY uk_name (user_name)) ENGINE=InnoDB DEFAULT CHARSET=gbk"""


def _reachable() -> bool:
    try:
        with socket.create_connection((_HOST, _PORT), timeout=0.6):
            return True
    except OSError:
        return False


needs_db = pytest.mark.skipif(not _reachable(),
                              reason=f"需要本地用户库 {_HOST}:{_PORT}(MariaDB/MySQL 1:1 复刻)")


class _My:
    def __init__(self, conn):
        self.conn = conn

    async def x(self, sql, args=None):
        async with self.conn.cursor() as cur:
            await cur.execute(sql, args)
            return await cur.fetchall()

    async def many(self, sql, rows):
        async with self.conn.cursor() as cur:
            await cur.executemany(sql, rows)

    async def n(self, where_sql):
        return int((await self.x("SELECT COUNT(*) FROM " + where_sql))[0][0])


@pytest_asyncio.fixture()
async def my():
    import aiomysql
    conn = await aiomysql.connect(host=_HOST, port=_PORT, user=_USER, password=_PASS,
                                  charset="gbk", autocommit=True)
    m = _My(conn)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        await m.x(f"DROP DATABASE IF EXISTS `{_DB}`")
    await m.x(f"CREATE DATABASE `{_DB}` DEFAULT CHARSET=gbk")
    await m.x(f"USE `{_DB}`")
    await m.x(_TB_USER)
    saved = (userauth.UA.cfg, userauth.UA.schema_ok)
    userauth.UA.pool = None
    userauth.UA.schema_ok = False          # 进程级标志:换库必须重建表(否则沿用别的库的「已就绪」)
    cfg = UserAuthCfg(host=_HOST, port=_PORT, db=_DB, user=_USER, password=_PASS,
                      charset="gbk", cache_ttl_s=0.0)
    await userauth.init(cfg, None)
    assert userauth.UA.schema_ok, "guantai_* 建表失败"
    m.cfg = cfg
    try:
        yield m
    finally:
        await userauth.close()
        userauth.UA.cfg, userauth.UA.schema_ok, userauth.UA.cache = saved[0], saved[1], {}
        lifecycle.STATUS["stores"].pop("mysql", None)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            await m.x(f"DROP DATABASE IF EXISTS `{_DB}`")
        conn.close()


_LOG = ("INSERT INTO guantai_login_log (user_id,user_name,ip,ua,ok,reason,created_at) "
        "VALUES (%s,%s,'1.2.3.4','pytest',%s,%s,DATE_SUB(NOW(), INTERVAL %s DAY))")
_REG = ("INSERT INTO guantai_reg_log (user_id,user_name,ip,ua,fp,invite_id,ok,reason,created_at) "
        "VALUES (0,%s,'1.2.3.4','pytest','',0,0,'throttled',DATE_SUB(NOW(), INTERVAL %s DAY))")
_ORD = ("INSERT INTO guantai_jf_order (gateway_order_no,user_id,user_name,plan_code,amount,status,"
        "credited,create_time) VALUES (%s,1,'u','m1',30,%s,%s,DATE_SUB(NOW(), INTERVAL %s DAY))")
_SES = ("INSERT INTO guantai_user_session (user_id,user_name,token_hash,created_at,last_seen_at,"
        "expires_at,revoked) VALUES (1,'u',SHA2(%s,256),NOW(),DATE_SUB(NOW(), INTERVAL %s DAY),"
        "DATE_ADD(NOW(), INTERVAL %s DAY),%s)")
_SSO = ("INSERT INTO guantai_sso_ticket (user_id,token_hash,created_at,expires_at) "
        "VALUES (1,SHA2(%s,256),NOW(),DATE_ADD(NOW(), INTERVAL %s HOUR))")
_CARD = ("INSERT INTO guantai_jf_card (card,plan_code,disabled,used_by,used_at,created_at) "
         "VALUES (%s,'m1',%s,%s,%s,DATE_SUB(NOW(), INTERVAL %s DAY))")


@needs_db
@pytest.mark.asyncio
async def test_registry_matches_real_user_db(my):
    """真库里实际建出来的 guantai_* 表,与登记逐张相等(防 DDL 与登记各走各的)。"""
    real = {r[0] for r in await my.x("SHOW TABLES LIKE 'guantai\\_%%'")}
    assert real == {p.table for p in lifecycle.tables("mysql")}


@needs_db
@pytest.mark.asyncio
async def test_sweep_deletes_only_what_it_should(my):
    """端到端:默认配置跑一轮清扫,**逐表核对幸存者**。"""
    await my.many(_LOG, [(1, f"old{i}", 0, "bad_credentials", 185 + i % 30) for i in range(300)]
                  + [(1, f"new{i}", 1, "ok", i % 180) for i in range(120)])       # 0~179 天:不该删
    await my.many(_REG, [(f"r{i}", 200) for i in range(40)] + [(f"k{i}", 30) for i in range(25)])
    await my.many(_ORD, [(f"PAID{i}", "paid", 1, 900) for i in range(7)]          # 账本:再老也不删
                  + [(f"OLDP{i}", "pending", 0, 200) for i in range(11)]
                  + [(f"OLDE{i}", "expired", 0, 200) for i in range(13)]
                  + [(f"NEWE{i}", "expired", 0, 100) for i in range(5)]           # 未满 184 天
                  + [(f"ODD{i}", "expired", 1, 400) for i in range(2)])           # 已入账却标 expired:仍是账
    await my.many(_SES, [(f"dead{i}", 0, -9, 0) for i in range(20)]               # 过期 9 天
                  + [(f"kick{i}", 9, 20, 1) for i in range(15)]                   # 被顶且静默 9 天
                  + [(f"kicknew{i}", 2, 20, 1) for i in range(4)]                 # 被顶但才 2 天:留(旧设备还要看到 kicked)
                  + [(f"live{i}", 0, 20, 0) for i in range(6)]
                  + [(f"justexp{i}", 0, -3, 0) for i in range(3)])                # 过期才 3 天:留
    await my.many(_SSO, [(f"s{i}", -30) for i in range(10)] + [(f"f{i}", -2) for i in range(4)]
                  + [(f"v{i}", 1) for i in range(3)])
    await my.many(_CARD, [(f"TLLIVE{i:06d}", 0, 0, None, 900) for i in range(5)]  # 仍可兑换:永不自动删
                  + [(f"TLDEAD{i:06d}", 1, 0, None, 900) for i in range(5)]
                  + [(f"TLUSED{i:06d}", 0, 7, "2020-01-01 00:00:00", 900) for i in range(5)])
    res = await userauth.janitor_sweep()
    assert res["errors"] == 0 and not res["capped"], res
    assert await my.n("guantai_login_log") == 120
    assert await my.n("guantai_login_log WHERE created_at < DATE_SUB(NOW(), INTERVAL 184 DAY)") == 0
    assert await my.n("guantai_reg_log") == 25, "注册流水保留期 -1 = 跟随登录流水(184 天)"
    assert await my.n("guantai_jf_order WHERE credited=1") == 9, "★ 已入账订单是账本,一笔都不许少"
    assert await my.n("guantai_jf_order WHERE credited=0") == 5, "只剩未满保留期的未支付单"
    assert await my.n("guantai_user_session") == 13
    assert await my.n("guantai_user_session WHERE revoked=0 AND expires_at > NOW()") == 6
    assert await my.n("guantai_sso_ticket") == 7
    assert await my.n("guantai_jf_card") == 15, "卡密池排水默认关:15 张卡原样"
    t = res["tasks"]
    assert t["guantai_login_log:超过 184 天"]["deleted"] == 300
    assert t["guantai_jf_order:未支付单超过 184 天"]["deleted"] == 24
    assert lifecycle.STATUS["stores"]["mysql"]["deleted"] == res["deleted"] == 300 + 40 + 24 + 35 + 10
    # 幂等:再扫一遍什么都不该动
    again = await userauth.janitor_sweep()
    assert again["deleted"] == 0 and again["errors"] == 0


@needs_db
@pytest.mark.asyncio
async def test_card_pool_drain_semantics_unchanged(my):
    """卡密池排水(4.2.8)的语义不因换引擎而变:两项显式开启后,只碰终态卡。"""
    await my.many(_CARD, [(f"TLLIVE{i:06d}", 0, 0, None, 900) for i in range(5)]
                  + [(f"TLDEAD{i:06d}", 1, 0, None, 900) for i in range(4)]
                  + [(f"TLDEADNEW{i:03d}", 1, 0, None, 3) for i in range(2)]
                  + [(f"TLUSED{i:06d}", 0, 7, "2020-01-01 00:00:00", 900) for i in range(3)]
                  + [(f"TLUSEDNEW{i:03d}", 0, 7, time.strftime("%Y-%m-%d %H:%M:%S"), 900) for i in range(2)])
    my.cfg.jf_card_disabled_age_days, my.cfg.jf_card_used_retention_days = 30, 30
    res = await userauth.janitor_sweep()
    assert res["errors"] == 0
    assert await my.n("guantai_jf_card WHERE used_by=0 AND disabled=0") == 5, "★ 仍可兑换的卡一张不少"
    assert await my.n("guantai_jf_card WHERE used_by=0 AND disabled=1") == 2
    assert await my.n("guantai_jf_card WHERE used_by<>0") == 2


@needs_db
@pytest.mark.asyncio
async def test_row_cap_keeps_only_newest_rows(my, monkeypatch):
    """★ 缺陷⑤:只按时间保留时,保留期内的行再多也不删。行数上限(保命阀)只留最新 N 行,
    并在结果与告警里留下「疑似被灌」的痕迹 —— 不许静默丢历史。"""
    monkeypatch.setattr(userauth, "_LOG_CAP_MIN", 1)     # 下限另有专测;这里用小上限看裁剪行为
    for i in range(200):                       # 逐行插:自增 id 稠密(真实流水的形态)
        await my.x(_LOG, (0, f"spray{i}", 0, "bad_credentials", 0))
    my.cfg.log_max_rows = 50
    res = await userauth.janitor_sweep()
    r = res["tasks"]["guantai_login_log:行数上限"]
    assert r["deleted"] == 150 and "行数上限" in r["note"]
    assert await my.n("guantai_login_log") == 50
    lo = int((await my.x("SELECT MIN(id), MAX(id) FROM guantai_login_log"))[0][0])
    hi = int((await my.x("SELECT MIN(id), MAX(id) FROM guantai_login_log"))[0][1])
    assert hi - lo + 1 == 50 and hi == 200, "留下的必须是最新的 50 行"
    assert any("行数上限" in a["text"] and a["level"] == "bad" for a in lifecycle.quick_alerts())
    my.cfg.log_max_rows = 0                    # 0 = 不设上限:不产生该任务
    res = await userauth.janitor_sweep()
    assert not any(k in res["tasks"] for k in ("guantai_login_log:行数上限", "guantai_reg_log:行数上限"))


@pytest.mark.asyncio
async def test_row_cap_scales_with_auto_increment_step(monkeypatch):
    """自增步长 >1(双主 / Galera 的常见配置)时 id 是稀疏的:若按 `MAX(id) - cap` 截,
    实际只留 cap/步长 行 —— 保命阀会在**正常运行**时偷删历史。截断点必须按步长放大。"""
    seen = {}

    async def fake_q(sql, args=(), fetch="none", timeout_s=None):
        if sql.startswith("SELECT MAX(id)"):
            assert "@@auto_increment_increment" in sql
            return {"hi": 1_000_000, "inc": 5}
        seen["sql"], seen["args"] = sql, args
        return 0
    monkeypatch.setattr(userauth, "_q_maint", fake_q)
    await userauth._jn_cap("guantai_login_log", 1000)
    assert seen["args"][0] == 1_000_000 - 1000 * 5 and "ORDER BY id LIMIT" in seen["sql"]
    seen.clear()

    async def fake_q1(sql, args=(), fetch="none", timeout_s=None):
        if sql.startswith("SELECT MAX(id)"):
            return {"hi": 900, "inc": 1}
        seen["sql"] = sql
        return 0
    monkeypatch.setattr(userauth, "_q_maint", fake_q1)
    r = await userauth._jn_cap("guantai_login_log", 1000)
    assert "sql" not in seen and r["deleted"] == 0, "没超上限就不该发任何 DELETE"


@needs_db
@pytest.mark.asyncio
async def test_unpaid_order_retention_has_a_floor_and_an_off_switch(my):
    await my.many(_ORD, [(f"D3-{i}", "expired", 0, 3) for i in range(4)]
                  + [(f"D9-{i}", "expired", 0, 9) for i in range(6)])
    my.cfg.jf_order_unpaid_retention_days = 1          # 配得再小,也按 7 天执行
    await userauth.janitor_sweep()
    assert await my.n("guantai_jf_order") == 4, "3 天前的未支付单还在对账回看的量级内,不许删"
    my.cfg.jf_order_unpaid_retention_days = 0          # 0 = 永久保留
    res = await userauth.janitor_sweep()
    assert not any(k.startswith("guantai_jf_order") for k in res["tasks"])


@needs_db
@pytest.mark.asyncio
async def test_failing_table_does_not_starve_the_rest_on_real_db(my, monkeypatch):
    """真库版缺陷③:登录流水那条任务出错,排在它后面的注册流水 / 订单照常清。"""
    await my.many(_LOG, [(0, f"o{i}", 0, "x", 300) for i in range(5)])
    await my.many(_REG, [(f"r{i}", 300) for i in range(6)])
    await my.many(_ORD, [(f"X{i}", "expired", 0, 300) for i in range(3)])
    real = userauth._jn_delete_2p

    async def flaky(table, where, args=(), fixed=0, order=None):
        if table == "guantai_login_log":
            raise asyncio.TimeoutError()
        return await real(table, where, args, fixed, order)
    monkeypatch.setattr(userauth, "_jn_delete_2p", flaky)
    res = await userauth.janitor_sweep()
    assert res["errors"] >= 1 and "TimeoutError" in res["tasks"]["guantai_login_log:超过 184 天"]["error"]
    assert await my.n("guantai_reg_log") == 0 and await my.n("guantai_jf_order") == 0
    assert await my.n("guantai_login_log") == 5


@needs_db
@pytest.mark.asyncio
async def test_slow_maintenance_statement_leaves_endpoint_healthy(my):
    """真库版缺陷②:维护语句超时,入口不熔断、连接池不拆、业务查询照常;
    同一条慢语句若走业务通道,入口当场被标 down(旧 _janitor 走的正是这条路)。"""
    ep = userauth.UA.router.endpoints[0]
    await userauth._q("SELECT 1", fetch="one")
    pool = ep.pool
    with pytest.raises(asyncio.TimeoutError):
        await userauth._q_maint("SELECT SLEEP(3)", fetch="one", timeout_s=1.0)
    assert ep.state == "up" and ep.fail_streak == 0 and ep.pool is pool
    assert (await userauth._q("SELECT 7 AS v", fetch="one"))["v"] == 7
    await my.many(_SSO, [("slow1", 1), ("slow2", 1)])      # 要有行,WHERE 里的 SLEEP 才会被逐行求值
    userauth.UA.router.query_timeout_s = 1.0
    with pytest.raises(asyncio.TimeoutError):
        await userauth._q("DELETE FROM guantai_sso_ticket WHERE SLEEP(2)=0")
    assert ep.state == "down" and ep.pool is not pool, "对照组:业务通道超时会熔断入口并拆池"


@needs_db
@pytest.mark.asyncio
async def test_storage_stats_and_snapshot_on_real_user_db(my, monkeypatch):
    monkeypatch.setattr(userauth, "_LOG_CAP_MIN", 1)
    for i in range(30):
        await my.x(_LOG, (0, f"u{i}", 0, "bad_credentials", i))
    st = await userauth.storage_stats()
    assert set(st) == {p.table for p in lifecycle.tables("mysql")}
    assert st["guantai_login_log"]["rows"] == 30 and st["guantai_login_log"]["oldest"]
    assert st["guantai_jf_order"] == {"rows": 0, "bytes": st["guantai_jf_order"]["bytes"],
                                      "exact": True, "oldest": None}

    class _NoPg:
        async def storage_stats(self):
            raise ConnectionError("pg down")
    snap = await lifecycle.snapshot(_NoPg(), None, fresh=True)        # PG 取数失败只降级那一路
    assert snap["pg"]["error"] and len(snap["pg"]["tables"]) == len(lifecycle.tables("pg"))
    rows = {t["table"]: t for t in snap["mysql"]["tables"]}
    assert snap["mysql"]["enabled"] and rows["guantai_login_log"]["rows"] == 30
    assert rows["guantai_jf_grant_log"]["klassLabel"] == "账本"
    assert "未开启" in rows["guantai_jf_card"]["sweeper"], "卡密池排水默认关:「谁来清」不能写成每 6 小时(第十一轮)"
    my.cfg.log_max_rows = 32                                           # 30/32 ≥ 80% → 逼近上限告警
    snap = await lifecycle.snapshot(_NoPg(), None, fresh=True)
    assert any("行数上限" in a["text"] for a in snap["alerts"])


# ══════════════════════════════════════════════════════════════════════════════
# D2. PostgreSQL 联测(需 STA_PG_DSN;未设整层 skip)
# ══════════════════════════════════════════════════════════════════════════════
_PG = os.environ.get("STA_PG_DSN", "")
needs_pg = pytest.mark.skipif(not _PG, reason="需要 PostgreSQL(设 STA_PG_DSN)")
_ACTOR = "lifecycle-test@pytest"
_RP = "lc9"                                   # 本文件专用房号前缀


@pytest_asyncio.fixture()
async def pg():
    d = dbmod.DB(_PG, 1, 4)
    await d.connect()
    await d.migrate()

    async def clean():
        async with d.pool.acquire() as con:
            await con.execute("DELETE FROM admin_audit WHERE actor = $1", _ACTOR)
            for t in ("predictor_state", "rooms", "rounds", "predictions", "user_rooms"):
                await con.execute(f"DELETE FROM {t} WHERE room_id LIKE $1", _RP + "%")
    await clean()
    try:
        yield d
    finally:
        await clean()
        lifecycle.STATUS["stores"].pop("pg", None)
        await d.close()


@needs_pg
@pytest.mark.asyncio
async def test_registry_matches_real_pg(pg):
    """真库里实际存在的表与登记逐张相等;storage_stats 给得出每张表的大小。"""
    st = await pg.storage_stats()
    assert st["db_bytes"] > 0
    assert set(st["tables"]) == {p.table for p in lifecycle.tables("pg")}, \
        "PG 里的表与 lifecycle.TABLES 对不上(有人加了表没登记,或登记了不存在的表)"
    snap = await lifecycle.snapshot(pg, None, fresh=True)
    assert snap["pg"]["unregistered"] == [] and snap["pg"]["error"] == ""
    assert all(t["present"] for t in snap["pg"]["tables"])


@needs_pg
@pytest.mark.asyncio
async def test_audit_retention_keeps_evidence_forever(pg, monkeypatch):
    """会话类超期即删;操作类(含删卡墓碑)再老也留;没超期的一条不动。"""
    now = lifecycle.now_ms()
    old, fresh = now - 400 * 86_400_000, now - 10 * 86_400_000
    for i in range(30):
        await pg.audit_add(old + i, _ACTOR, "login_fail", {"i": i})
    for a in ("login", "logout", "login_captcha_fail", "login_ticket", "login_ticket_fail"):
        await pg.audit_add(old, _ACTOR, a, {})
    for a in ("jfvip_cards_purge", "jfvip_grant", "apply", "config_reveal", "jfvip_cards_issue"):
        await pg.audit_add(old, _ACTOR, a, {"cards": ["TLAAAAAA111111"]})
    for a in ("login", "login_fail"):
        await pg.audit_add(fresh, _ACTOR, a, {})
    monkeypatch.setattr(settings.retention, "audit_days", 184)
    monkeypatch.setattr(settings.retention, "state_gc", False)
    res = await lifecycle.sweep_pg(pg)
    assert res["errors"] == 0 and res["tasks"]["admin_audit:会话类超期"]["deleted"] >= 35
    async with pg.pool.acquire() as con:
        left = [r["action"] for r in await con.fetch(
            "SELECT action FROM admin_audit WHERE actor=$1 ORDER BY id", _ACTOR)]
    assert sorted(left) == sorted(["jfvip_cards_purge", "jfvip_grant", "apply", "config_reveal",
                                   "jfvip_cards_issue", "login", "login_fail"])
    monkeypatch.setattr(settings.retention, "audit_days", 0)           # 0 = 不清:不产生该任务
    res = await lifecycle.sweep_pg(pg)
    assert res["tasks"] == {}


@needs_pg
@pytest.mark.asyncio
async def test_state_gc_only_touches_rooms_that_are_truly_gone(pg, monkeypatch):
    """predictor_state / rooms 墓碑的回收判据:不在册 **且** 历史已清空。逐种情形核对。"""
    R = lambda s: f"{_RP}{s}"                                          # noqa: E731
    kv = {"model_weights": "{}", "explore_state": "x" * 2000}
    for name in ("active", "pending", "hist", "pred", "gone", "norow", "bound"):
        await pg.save_predictor_kv(R(name), kv)
    await pg.upsert_room(R("active"), R("active"), active=True)        # 在册:留
    await pg.upsert_room(R("pending"), R("pending"), active=False, pending=True)   # 挂起待归一:留
    await pg.upsert_room(R("hist"), R("hist"), active=False)           # 已停用但历史还在:留
    await pg.add_round(R("hist"), 1_700_000_000_000, 1, "x", 1, 5, "t", "d", "d")
    await pg.upsert_room(R("pred"), R("pred"), active=False)           # 只剩预测行:留
    await pg.save_prediction(R("pred"), 1_700_000_000_000, [1], [2], {})
    await pg.upsert_room(R("gone"), R("gone"), active=False)           # 彻底离场:状态与墓碑都收
    #   "norow":rooms 里压根没有它(曾是策展房、行已被回收):状态收
    await pg.upsert_room(R("bound"), R("bound"), active=False)         # 仍有账号绑定:墓碑留
    await pg.user_room_bind(424242, R("bound"), R("bound"))
    monkeypatch.setattr(settings.retention, "audit_days", 0)
    monkeypatch.setattr(settings.retention, "state_gc", False)
    assert (await lifecycle.sweep_pg(pg))["tasks"] == {}, "state_gc=False 即退回旧行为(只增不减)"
    monkeypatch.setattr(settings.retention, "state_gc", True)
    res = await lifecycle.sweep_pg(pg)
    assert res["errors"] == 0
    async with pg.pool.acquire() as con:
        st = {r["room_id"][len(_RP):] for r in await con.fetch(
            "SELECT DISTINCT room_id FROM predictor_state WHERE room_id LIKE $1", _RP + "%")}
        rm = {r["room_id"][len(_RP):] for r in await con.fetch(
            "SELECT room_id FROM rooms WHERE room_id LIKE $1", _RP + "%")}
    assert st == {"active", "pending", "hist", "pred"}, f"状态回收判据不对: {sorted(st)}"
    assert rm == {"active", "pending", "hist", "pred", "bound"}, f"墓碑回收判据不对: {sorted(rm)}"
    assert res["tasks"]["predictor_state:离场房回收"]["deleted"] >= 6      # 3 房 × 2 行
    # 分批:存量孤儿很多时一条删不完(PG 超时即回滚 → 永远删不完),故每批有上限、由引擎循环
    for i in range(7):
        await pg.save_predictor_kv(R(f"bulk{i}"), {"model_weights": "{}"})
    assert await pg.gc_predictor_state(3) == 3 and await pg.gc_predictor_state(3) == 3
    assert await pg.gc_predictor_state(3) == 1 and await pg.gc_predictor_state(3) == 0
    # 回收后重新加回来:行原样长回,走冷启动(状态为空)
    await pg.upsert_room(R("gone"), R("gone"), active=True)
    assert await pg.load_predictor_kv(R("gone")) == {}
    assert R("gone") in {r["room_id"] for r in await pg.active_rooms()}


# ══════════════════════════════════════════════════════════════════════════════
# E. 第二轮复查新增(关联调用链与同类模式)
# ══════════════════════════════════════════════════════════════════════════════
def test_floors_and_effective_values(monkeypatch):
    """⑩:清扫执行的值 = 界面显示的值(两者共用 log_cap / order_unpaid_days)。"""
    c = UserAuthCfg()
    assert userauth.log_cap(c) == 5_000_000
    c.log_max_rows = 5000
    assert userauth.log_cap(c) == userauth._LOG_CAP_MIN == 100_000, "少打几个 0 不许把流水裁到几千行"
    c.log_max_rows = 0
    assert userauth.log_cap(c) == 0
    c.jf_order_unpaid_retention_days = 1
    assert userauth.order_unpaid_days(c) == 7
    c.jf_order_unpaid_retention_days = 0
    assert userauth.order_unpaid_days(c) == 0
    c.log_max_rows, c.jf_order_unpaid_retention_days = 5000, 2
    monkeypatch.setattr(userauth.UA, "cfg", c)
    eff = lifecycle._effective()
    assert eff["userauth.log_max_rows"] == 100_000 and eff["userauth.jf_order_unpaid_retention_days"] == 7


def test_evidence_destroying_knobs_are_server_side_only():
    """⑨:会删除审计证据的保留参数不许在管理台覆盖(拿到管理台会话的人不能顺手抹痕迹)。"""
    for k in ("userauth.log_retention_days", "userauth.log_max_rows", "retention.audit_days"):
        assert reg.REGISTRY[k].readonly, f"{k} 会删除审计证据,必须只读"


def test_admin_analytics_are_marked_heavy():
    """⑦:管理台的分析型查询都要标记 heavy_reads(超时不熔断入口);业务路径一个都不许标。"""
    for mod, names in ((userauth, ("login_risk_overview", "login_log_page", "invites_page", "reg_log_page",
                                   "reg_stats")),
                       (jfvip, ("cards_page", "cards_batches", "cards_batch_stat", "overview"))):
        for n in names:
            assert getattr(getattr(mod, n), "__heavy_reads__", False), f"{mod.__name__}.{n} 未标记 heavy_reads"
    # 业务路径(登录 / 会话校验 / 注册 / SSO / 开通入账)一个都不许标:它们的超时就该熔断。
    # 名字直接 getattr —— 写错会当场 AttributeError,不许像旧写法那样 `or None` 静默跳过
    # (第四轮复查:旧清单里 validate_session / redeem_card 两个名字根本不存在,一直在跳过)。
    # 第十轮:管理台与用户侧 /api/vip/orders 共用的检索函数也不许在定义处标记(会连用户侧一起改掉),
    # 改由管理台调用处用 userdb_pool.heavy() 临时开启 —— 见下一条测试的运行时验证
    for mod, names in ((userauth, ("login", "_authenticate", "validate", "logout", "register",
                                   "sso_exchange", "sso_link")),
                       (jfvip, ("_grant_tx", "grant_by_order", "grant_by_card", "grant_by_admin",
                                "orders_page", "grants_page", "_count_capped"))):
        for n in names:
            assert not getattr(getattr(mod, n), "__heavy_reads__", False), f"业务路径 {n} 不许标 heavy_reads"


# 长得像「命名空间:…{占位符}」、但**不是** Redis 键的 f-string。每条写明理由;
# 新增一个这样的串而不表态(登记为键族,或在这里说明它不是键),闸当场变红。
_NOT_REDIS_FSTRINGS = {
    "challenge:{}": "登录流水的失败原因串(写进 guantai_login_log.reason)",
    "probe_unreadable:{}": "注册预检的原因串",
    "probe_exception:{}": "注册预检的原因串",
    "u:{}": "传给 _lg_audit_once 的子标签,真正的键是 guantai:lg:al:{cls}:{key}",
    "ip:{}": "同上",
    "path:{}": "admin_auth 的进程内告警限频标签(内容是配置值,不随请求增长)",
    "uuid:{}": "用户库入口的身份串(判断两个入口是否同一实例)",
    "sid:{}|host:{}|ver:{}": "同上",
    "rounds:{}": "lifecycle.worker_retention_view 的任务名",
    "predictions:{}": "同上",
}
_URL_SCHEMES = {"http", "https", "redis", "rediss", "postgres", "postgresql", "mysql", "ws", "wss",
                "file", "data", "mailto"}
_norm_tpl = lambda s: re.sub(r"\{[^}]*\}", "{}", s)              # noqa: E731


def _redis_key_templates():
    """全仓的按实体键模板:`K_* = "...{...}..."` 常量,加上 f-string 现拼的「命名空间:…{…}」。
    第五轮复查:旧闸只扫常量,代码里现拼的 31 族全部绕过了登记 —— 两种写法都要扫。"""
    found = {}
    for path in sorted(APP.rglob("*.py")):
        src = path.read_text(encoding="utf-8")
        for m in re.finditer(r'^(K_[A-Z0-9_]+)\s*=\s*"([^"]*\{[^"]*)"', src, re.M):
            found.setdefault(_norm_tpl(m.group(2)), f"{path.name}:{m.group(1)}")
        for m in re.finditer(r'\b(?:rf|fr|f)(["\'])([a-z][a-z0-9_]*:(?:(?!\1).)*?\{(?:(?!\1).)*)\1', src):
            lit = m.group(2)
            text = re.sub(r"\{[^}]*\}", "", lit)      # 只看占位符以外的字面:占位符里的表达式可以有空格
            if lit.split(":", 1)[0] in _URL_SCHEMES or " " in text or "/" in text:
                continue
            found.setdefault(_norm_tpl(lit), f"{path.name}:{src[:m.start()].count(chr(10)) + 1}")
    return found


@pytest.mark.asyncio
async def test_shared_search_is_heavy_only_when_admin_calls_it(monkeypatch):
    """第十轮 ㉓:orders_page / grants_page 同时服务管理台检索与用户自己的 /api/vip/orders。
    用户侧调用时每条查询都**不是**重查询(超时照常熔断);管理台调用处开启后,每条都是。"""
    seen = []

    async def spy(sql, args=(), fetch="none", idem=False):
        seen.append(userdb_pool.HEAVY_READS.get())
        return {"n": 0} if fetch == "one" else ([] if fetch == "all" else 0)
    monkeypatch.setattr(userauth, "_q", spy)
    for fn in (jfvip.orders_page, jfvip.grants_page):
        seen.clear()
        await fn(1, 20, uid=7)                      # 用户侧:/api/vip/orders 的调用形态
        assert seen and not any(seen), f"{fn.__name__} 在用户侧被当成了重查询"
        seen.clear()
        with userdb_pool.heavy():                   # 管理台调用处
            await fn(1, 20)
        assert seen and all(seen), f"{fn.__name__} 在管理台没有按重查询处理"
    assert userdb_pool.HEAVY_READS.get() is False, "开关只在 with 块内生效"
    api = py_code(APP / "admin_api.py")
    for fn in ("orders_page", "grants_page"):
        assert re.search(r"with _heavy_reads\(\):[^\n]*\n\s+data = await jfvip\." + fn + r"\(", api), \
            f"管理台调用 jfvip.{fn} 必须包在 _heavy_reads() 里"


def test_every_per_entity_redis_key_is_registered():
    """⑥ 的机器闸:按房间 / 用户 / 会话 / IP 拼接的 Redis 键,不论写成常量还是现拼,都必须
    逐族登记「凭什么有界」;不是键的同形串必须在白名单里写明理由;两边都不许有幽灵条目。"""
    found = _redis_key_templates()
    assert len(found) >= 50, f"扫描式失效:只扫到 {len(found)} 族"
    regd = {_norm_tpl(k) for k in lifecycle.REDIS_FAMILIES}
    assert len(regd) == len(lifecycle.REDIS_FAMILIES), "登记里有归一后重复的模板"
    ok = regd | set(_NOT_REDIS_FSTRINGS)
    miss = {t: where for t, where in found.items() if t not in ok}
    assert not miss, f"按实体拼接的 Redis 键没有登记生命周期(或没在非键白名单里说明): {miss}"
    assert regd - set(found) == set(), f"登记了不存在的键模板: {sorted(regd - set(found))}"
    assert set(_NOT_REDIS_FSTRINGS) - set(found) == set(), \
        f"非键白名单里有代码中已不存在的条目: {sorted(set(_NOT_REDIS_FSTRINGS) - set(found))}"
    assert all(len(v) >= 8 for v in lifecycle.REDIS_FAMILIES.values())


@needs_db
@pytest.mark.asyncio
async def test_heavy_read_timeout_leaves_endpoint_healthy(my):
    """⑦ 真库:被标记的分析型查询超时 → 只报给调用方,入口不熔断、不拆池、不重发;
    同一条查询不带标记 → 熔断 + 拆池(对照组,旧行为)。"""
    ep = userauth.UA.router.endpoints[0]
    await userauth._q("SELECT 1", fetch="one")
    pool = ep.pool
    userauth.UA.router.query_timeout_s = 1.0

    @userdb_pool.heavy_reads
    async def analytics():
        return await userauth._q("SELECT SLEEP(3) AS s", fetch="one")
    t0 = time.monotonic()
    with pytest.raises(asyncio.TimeoutError):
        await analytics()
    assert time.monotonic() - t0 < 1.8, "重查询超时不许换入口重发(旧行为会把同一条重查询跑两遍)"
    assert ep.state == "up" and ep.fail_streak == 0 and ep.pool is pool
    assert (await userauth._q("SELECT 7 AS v", fetch="one"))["v"] == 7
    assert userdb_pool.HEAVY_READS.get() is False, "标记只在被装饰函数内生效"
    with pytest.raises(asyncio.TimeoutError):
        await userauth._q("SELECT SLEEP(3) AS s", fetch="one")
    assert ep.state == "down" and ep.pool is not pool, "对照组:业务通道超时会熔断入口并拆池"


@needs_db
@pytest.mark.asyncio
async def test_session_cap_trims_oldest_revoked_only(my, monkeypatch):
    """⑧ 真库:会话表超过上限 → 只裁最旧的已失效行,有效会话一个不碰。"""
    await my.many(_SES, [(f"rv{i}", 1, 20, 1) for i in range(30)]        # 被顶、静默 1 天(常规规则不删)
                  + [(f"lv{i}", 0, 20, 0) for i in range(10)])            # 有效
    lo = int((await my.x("SELECT MIN(id) FROM guantai_user_session WHERE revoked=1"))[0][0])
    monkeypatch.setattr(userauth, "_SESSION_ROWS_CAP", 25)
    res = await userauth.janitor_sweep()
    r = res["tasks"]["guantai_user_session:行数上限"]
    assert r["deleted"] == 15 and "行数上限" in r["note"] and res["errors"] == 0
    assert await my.n("guantai_user_session WHERE revoked=0") == 10, "有效会话一个都不许动"
    assert int((await my.x("SELECT MIN(id) FROM guantai_user_session WHERE revoked=1"))[0][0]) == lo + 15, \
        "裁掉的必须是最旧的已失效行"
    monkeypatch.setattr(userauth, "_SESSION_ROWS_CAP", 5)     # 已失效行不够:删光已失效,有效会话超限也不碰
    await userauth.janitor_sweep()
    assert await my.n("guantai_user_session WHERE revoked=1") == 0
    assert await my.n("guantai_user_session WHERE revoked=0") == 10
    monkeypatch.setattr(userauth, "_SESSION_ROWS_CAP", 1_000_000)
    again = await userauth.janitor_sweep()
    assert again["tasks"]["guantai_user_session:行数上限"]["deleted"] == 0


_RURL = os.environ.get("STA_TEST_REDIS_URL", "")
needs_redis = pytest.mark.skipif(not _RURL, reason="需要 Redis(设 STA_TEST_REDIS_URL)")


@needs_redis
@pytest.mark.asyncio
async def test_orphan_snapshot_gc_on_real_redis():
    """⑥ 真 Redis:不在抓取名录里的房的快照被回收,在册的一个不碰;名录为空时一个都不删;
    发现房回收时快照随之删除;引擎接线把结果落进 STATUS。本测试独占 db 12。"""
    from app.redis_bus import K_ROOMS_ACTIVE, RedisBus
    bus = RedisBus(_RURL.rsplit("/", 1)[0] + "/12")
    r = bus.r
    await r.flushdb()
    try:
        for i in range(8):
            await bus.set_snapshot(f"9000{i}", {"latestRoundId": i, "covWm": i})
        assert await bus.gc_orphan_snapshots() == 0, "名录为空不是正常运行态:一个都不许删"
        await r.sadd(K_ROOMS_ACTIVE, "90000", "90001", "90002")
        assert await bus.gc_orphan_snapshots(scan_count=2, batch=2) == 5     # 跨多批也要对
        assert sorted([k async for k in r.scan_iter(match="snap:*")]) == ["snap:90000", "snap:90001", "snap:90002"]
        assert await bus.gc_orphan_snapshots() == 0                           # 幂等
        await r.sadd(K_ROOMS_ACTIVE, "91000")
        await bus.set_snapshot("91000", {"latestRoundId": 1})
        await bus.discovered_prune_bulk(["91000"])
        assert not await r.exists("snap:91000"), "发现房回收必须连快照一起删"
        await bus.set_snapshot("93000", {"latestRoundId": 1})                # 不在名录
        res = await lifecycle.sweep_redis(bus)
        assert res["deleted"] == 1 and res["errors"] == 0
        assert lifecycle.STATUS["stores"]["redis"]["tasks"]["snap:{room}:离场房快照回收"]["deleted"] == 1
        assert await r.exists("snap:90000") and not await r.exists("snap:93000")
        # worker 侧大表清理的状态:体检从 Redis 读 retention:last,翻成「储」视图里的上次清扫
        import json as _json
        await r.set("retention:last", _json.dumps({"ts_ms": lifecycle.now_ms(), "days": 7, "rounds": 9,
                                                   "predictions": 1, "capped": 0, "elapsed_s": 0.1,
                                                   "interval_s": 3600}))

        class _NoPg:
            async def storage_stats(self):
                raise ConnectionError("pg down")
        snap = await lifecycle.snapshot(_NoPg(), r, fresh=True)
        assert snap["sweeps"]["worker"]["tasks"]["rounds:超过 7 天"]["deleted"] == 9
        assert not any("rounds、predictions" in a["text"] for a in snap["alerts"]), "刚清过,不许报停摆"
        lifecycle.invalidate_snapshot()
    finally:
        await r.flushdb()
        lifecycle.STATUS["stores"].pop("redis", None)
        with contextlib.suppress(Exception):
            await r.aclose()


def test_worker_retention_view_and_stall_alert(monkeypatch):
    """⑬:worker 侧 rounds / predictions(最大的两张表)的清理在「储」里可见,停摆报红。
    worker 只在**成功**清理后写 retention:last ⇒「记录太旧」是停摆的统一症状。"""
    monkeypatch.setattr(settings.retention, "days", 7.0)
    now = lifecycle.now_ms()
    last = {"ts_ms": now - 600_000, "days": 7.0, "rounds": 1234, "predictions": 56, "capped": 0,
            "elapsed_s": 1.5, "interval_s": 3600}
    v = lifecycle.worker_retention_view(last)
    assert v["tasks"]["rounds:超过 7 天"]["deleted"] == 1234 and v["tasks"]["predictions:超过 7 天"]["deleted"] == 56
    assert set(v["tasks"]["rounds:超过 7 天"]) >= set(lifecycle._empty_result())
    assert lifecycle.worker_retention_alert(last, now=now) is None
    stale = dict(last, ts_ms=now - 4 * 3_600_000)
    a = lifecycle.worker_retention_alert(stale, now=now)
    assert a and a["level"] == "bad" and "rounds" in a["text"] and "4.0 小时" in a["text"]
    assert lifecycle.worker_retention_alert(dict(stale, interval_s=7200), now=now) is None, \
        "按 worker 自己生效的周期判,不按 web 进程那份配置"
    monkeypatch.setitem(lifecycle.STATUS, "boot_ms", now - 600_000)
    assert lifecycle.worker_retention_alert(None, now=now) is None, "刚启动、worker 还没清过:不报"
    monkeypatch.setitem(lifecycle.STATUS, "boot_ms", now - 4 * 3_600_000)
    assert lifecycle.worker_retention_alert(None, now=now) is not None, "一直没有记录 = worker 没在清"
    monkeypatch.setattr(settings.retention, "days", 0.0)
    assert lifecycle.worker_retention_alert(stale, now=now) is None, "永久保留时 worker 本就不清(另有黄条)"
    assert lifecycle.worker_retention_view(None) == {}
    src = py_code(APP / "worker.py")
    assert '"interval_s": interval' in _fn_body(src, "    async def _retention"), "worker 必须记下自己生效的巡检周期"
    api = py_code(APP / "admin_api.py")
    assert 'lifecycle.worker_retention_alert(out["retention_last"])' in api, "总览首屏要带 worker 停摆告警"
    assert 'if "retention_last" in out else None' in api, "读 Redis 失败时不许臆断停摆"


# ══════════════════════════════════════════════════════════════════════════════
# F. 第七轮复查:清扫不许锁住业务正在用的行(可重复读下单条 DELETE 会锁住扫描过的每一行)
# ══════════════════════════════════════════════════════════════════════════════
async def _holder():
    import aiomysql
    return await aiomysql.connect(host=_HOST, port=_PORT, user=_USER, password=_PASS, charset="gbk",
                                  autocommit=False, db=_DB)


@needs_db
@pytest.mark.asyncio
async def test_card_drain_does_not_lock_redeemable_cards(my):
    """⑳ 真库:兑换事务正锁着一张可兑换的卡、另一笔兑换已改写未提交 —— 两项排水必须照常
    完成,不能卡在锁等待上。旧写法(单条 DELETE … LIMIT)扫 used_by=0 段时要等第一把锁,
    扫 used_by>0 段时要等第二笔兑换刚写入的索引项(实测:兑换被排水卡住最长 141ms)。"""
    await my.many(_CARD, [(f"TLLIVE{i:06d}", 0, 0, None, 900) for i in range(50)]
                  + [(f"TLDEAD{i:06d}", 1, 0, None, 900) for i in range(30)]
                  + [(f"TLUSED{i:06d}", 0, 7, "2020-01-01 00:00:00", 900) for i in range(20)])
    my.cfg.jf_card_disabled_age_days, my.cfg.jf_card_used_retention_days = 30, 30
    holder = await _holder()
    try:
        hc = await holder.cursor()
        await hc.execute("SELECT id FROM guantai_jf_card WHERE card=%s FOR UPDATE", ("TLLIVE000025",))
        await hc.execute("UPDATE guantai_jf_card SET used_by=999, used_name='u', used_at=NOW() "
                         "WHERE card=%s", ("TLLIVE000040",))               # 兑换已写、未提交
        t0 = time.monotonic()
        res = await asyncio.wait_for(userauth.janitor_sweep(), timeout=15)
        assert time.monotonic() - t0 < 5, "排水不该等兑换事务的锁"
        assert res["errors"] == 0, res
        assert await my.n("guantai_jf_card WHERE disabled=1") == 0, "作废卡应清完"
        assert await my.n("guantai_jf_card WHERE used_by<>0") == 0, "老的已兑换卡应清完"
        assert await my.n("guantai_jf_card WHERE card LIKE 'TLLIVE%%'") == 50, "可兑换的卡一张都不许动"
    finally:
        await holder.rollback()
        holder.close()


@needs_db
@pytest.mark.asyncio
async def test_session_cleanup_does_not_lock_live_sessions(my):
    """⑳ 真库:一次会话续期 / 互顶正锁着一个在用会话 —— 过期会话清扫必须照常完成。会话表没有
    时间索引,旧写法是全表扫描的单条 DELETE,在可重复读下会等这把锁(登录与续期跟着等)。"""
    await my.many(_SES, [(f"dead{i}", 0, -9, 0) for i in range(20)] + [(f"live{i}", 0, 20, 0) for i in range(10)])
    holder = await _holder()
    try:
        hc = await holder.cursor()
        await hc.execute("SELECT id FROM guantai_user_session WHERE token_hash=SHA2(%s,256) FOR UPDATE", ("live5",))
        t0 = time.monotonic()
        res = await asyncio.wait_for(userauth.janitor_sweep(), timeout=15)
        assert time.monotonic() - t0 < 5, "会话清扫不该等在用会话的锁"
        assert res["errors"] == 0, res
        assert await my.n("guantai_user_session") == 10, "过期的 20 个应清完,在用的 10 个一个不动"
    finally:
        await holder.rollback()
        holder.close()


# ══════════════════════════════════════════════════════════════════════════════
# G. 第十轮复查:跨模块关联点
# ══════════════════════════════════════════════════════════════════════════════
@pytest.mark.asyncio
async def test_hot_override_reaches_janitor_and_storage_view(monkeypatch):
    """热更参数在管理台改了,清扫实际执行的值与「储」视图显示的值都必须立刻跟上:配置中枢走
    set_path 原地 setattr(铁律一),web.lifespan 传给 userauth.init 的就是 settings.userauth 这个
    对象本身。会删除审计证据的只读参数,运行时覆盖一律被 apply_snapshot 跳过。"""
    from app import config_center as cfgc
    keys = ("userauth.jf_order_unpaid_retention_days", "userauth.log_max_rows", "retention.audit_days")
    keep = {k: reg.get_path(settings, k) for k in keys}
    monkeypatch.setattr(userauth.UA, "cfg", settings.userauth)          # 与 web.lifespan 相同的同一对象引用
    fresh_base = cfgc._BASE is None
    cfgc.capture_base(settings)                                         # 与 web 启动时相同:先记基线再套快照
    try:
        changed, _restart, errors = await cfgc.apply_snapshot(
            settings, {"userauth.jf_order_unpaid_retention_days": 30, "userauth.log_max_rows": 123456,
                       "retention.audit_days": 1},
            hooks={}, mode="hot", state=cfgc.CenterState(role="web"))
        assert "userauth.jf_order_unpaid_retention_days" in changed and not errors, (changed, errors)
        assert userauth.order_unpaid_days(userauth.UA.cfg) == 30, "清扫执行的值没跟上热更"
        eff = lifecycle._effective()
        assert eff["userauth.jf_order_unpaid_retention_days"] == 30, "「储」视图显示的值没跟上热更"
        assert reg.get_path(settings, "userauth.log_max_rows") == keep["userauth.log_max_rows"], "只读项不许被运行时覆盖"
        assert reg.get_path(settings, "retention.audit_days") == keep["retention.audit_days"], "只读项不许被运行时覆盖"
        assert eff["retention.audit_days"] == keep["retention.audit_days"]
    finally:
        for k, v in keep.items():
            reg.set_path(settings, k, v)
        if fresh_base:
            cfgc._reset_base_for_tests()                                # 不把基线状态带给其他测试


def test_sweeper_text_follows_effective_config():
    """第十一轮:「储」视图的「谁来清」按当前生效配置说实话 —— 卡密池排水默认关,不能还写「每 6 小时」;
    任何一项保留被关掉时同样要显示「已关闭」。"""
    eff = lifecycle._effective()
    card = lifecycle.TABLES["mysql:guantai_jf_card"]
    assert "未开启" in lifecycle._row(card, None, dict(eff, **{"userauth.jf_card_disabled_age_days": 0,
                                                            "userauth.jf_card_used_retention_days": 0}))["sweeper"]
    assert lifecycle._row(card, None, dict(eff, **{"userauth.jf_card_disabled_age_days": 30}))["sweeper"] \
        == lifecycle.SWEEP_WEB
    for key, tab, val in (("retention.audit_days", "pg:admin_audit", 0.0), ("retention.days", "pg:rounds", 0.0),
                          ("retention.state_gc", "pg:predictor_state", False),
                          ("userauth.jf_order_unpaid_retention_days", "mysql:guantai_jf_order", 0)):
        assert "已关闭" in lifecycle._row(lifecycle.TABLES[tab], None, dict(eff, **{key: val}))["sweeper"], key
    log = lifecycle.TABLES["mysql:guantai_login_log"]
    assert lifecycle._row(log, None, dict(eff, **{"userauth.log_retention_days": 0}))["sweeper"] \
        == lifecycle.SWEEP_WEB, "保留期关了但行数上限还在 —— 仍然在清"
    assert "已关闭" in lifecycle._row(log, None, dict(eff, **{"userauth.log_retention_days": 0,
                                                           "userauth.log_max_rows": 0}))["sweeper"]


@pytest.mark.asyncio
async def test_registry_and_sweep_tasks_agree(monkeypatch):
    """第十一轮:登记说「web 每 6 小时清」的表,清扫任务里必须真有它;有清扫任务的表,登记里也必须
    写的是 web 清扫 —— 防止删了任务忘改登记(或加了任务忘登记)。全部开关打开后截下实际任务清单。"""
    cfg = UserAuthCfg()
    cfg.jf_card_disabled_age_days = cfg.jf_card_used_retention_days = 30
    monkeypatch.setattr(userauth.UA, "cfg", cfg)
    monkeypatch.setattr(userauth.UA, "schema_ok", True)
    monkeypatch.setattr(userauth, "enabled", lambda: True)
    got = {}

    async def fake_run_tasks(store, tasks):
        got[store] = {t for t, _rule, _factory in tasks}
        return {}
    monkeypatch.setattr(lifecycle, "run_tasks", fake_run_tasks)
    await userauth.janitor_sweep()
    await lifecycle.sweep_pg(object())               # 任务工厂惰性求值,不会碰 db
    for p in lifecycle.TABLES.values():
        if p.sweeper == lifecycle.SWEEP_WEB:
            assert p.table in got[p.store], f"{p.store}:{p.table} 登记为 web 清扫,但清扫任务里没有它"
    for store in ("pg", "mysql"):
        for t in got[store]:
            assert lifecycle.TABLES[f"{store}:{t}"].sweeper == lifecycle.SWEEP_WEB, \
                f"{store}:{t} 有清扫任务,但登记里不是 web 清扫"

