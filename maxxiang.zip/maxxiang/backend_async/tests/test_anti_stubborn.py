# -*- coding: utf-8 -*-
"""
test_anti_stubborn.py — 反固执改造(《灵机推演反固执优化方案.md》)回归钉
================================================================================
背景:showcase 风格的集合选择/座次/冷位在旧引擎里对「连败」零敏感,真机三房
4,901 已结算局实测:同一四码原地连败最长 4~5 局、A→B→A 回摆 ~15%、连败 3+ 仍
不换码占 ~30%。改造以 anti_stubborn 总开关收束五机制(连败压力/在位惯性/熔断
换血/k 分位死区/冷位老化),开关关闭时与旧引擎**逐局字节级等价**(改造期全量回放
局全同,离线门禁见交付物 replay_lab.py)。

本文件是可长期跑的仓内钉(不依赖 PG/Redis/真机 DB):
  ① 配置三方一致:引擎 dataclass ⇄ config.yaml ⇄ config_registry 同键同值;
  ② 开关关 = 全刻度失效(as_* 拨到极端也不改变输出)—— 等价门禁的仓内代理;
  ③ 熔断硬不变量:同四码原地连败 ≤ as_breaker,且 why 落款「连败换血」;
  ④ 状态往返 + 向后兼容:pen/cstk/pk 经 kv JSON 逐字段还原;旧状态(无新字段)
     直接可用;
  ⑤ 指纹复用:同一 seq 重复 predict 不重复累积压力(web 侧按需重算安全)。
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "backend_async"))
os.environ.setdefault("STA_ENGINE_DIR", str(ROOT / "jiufa_data"))

from app.predictor_bridge import PredictorBridge, KvStoreShim  # noqa: E402
import spell_tamer_monitor as E  # noqa: E402
from app import config_registry as reg  # noqa: E402
import yaml  # noqa: E402

# 回测定稿刻度(与 config.yaml / config_registry 同源;anti_stubborn 引擎缺省
# 特意为 0 —— 裸引擎嵌入方拿到的是"未开刀"的安全姿态,由部署配置显式开启)。
FINAL_DIALS = {
    "as_alpha": 0.08, "as_alpha_ord": 0.14, "as_mcap_hot": 0.12,
    "as_mcap_cold": 0.18, "as_gamma": 0.15, "as_pen_cap": 8,
    "as_pen_on_hit": 0, "as_breaker": 3, "as_khyst": 0.05,
    "as_cooldown": 0, "as_beta": 0.3, "as_agecap": 24,
}
AS_KEYS = ("anti_stubborn",) + tuple(FINAL_DIALS)

BASE_CFG = {  # 生产口径(config.yaml prediction 段的引擎相关子集)
    "predict_mode": "adaptive", "adaptive_lambda": 0.3,
    "explore_style": "showcase", "explore_patrol": 35,
    "showcase_q": 0.78, "showcase_kdist": "45,30,15",
    "seat_order": "recency", "hedge_eta": 0.15, "hedge_mix": 0.02,
}

WARM = ([1, 2, 7, 8, 1, 5, 2, 7, 1, 8, 6, 1, 2, 7, 8, 5, 1, 2, 1, 7] * 4)[:72]


def _drive(cfg_extra, n_rounds=48, adversarial=True):
    """微型因果驱动器:predict → 取「必不在四码里」的号当出怪 → 结算 → 再 predict。
    kv 逐局经 bridge 往返(与 worker._settle_and_predict 同语义)。"""
    bridge = PredictorBridge({**BASE_CFG, **cfg_extra}, {})
    kv, seq, recs = {}, list(WARM), []
    prev = None
    for _ in range(n_rounds):
        res, dirty = bridge.run_prediction("t", seq, kv)
        kv.update(dirty)
        four = tuple(res["main"]) + tuple(res["guard"])
        recs.append({"four": four, "why": ((res.get("explore") or {}).get("why") or ""),
                     "st": json.loads(kv.get("explore_state") or "{}")})
        if adversarial:
            nxt = next(c for c in range(1, 10) if c not in four)   # 永远打不中
        else:
            nxt = four[0]                                          # 永远主中
        if prev is not None:
            kv.update(bridge.update_after_settle(
                "t", {"models": prev["models"], "ens": prev["ens"]}, nxt, kv))
        prev = res
        seq.append(nxt)
    return recs, kv, bridge


# ── ① 配置三方一致 ────────────────────────────────────────────────────────────
def test_config_three_way_consistency():
    fields = E.PredictionConfig.__dataclass_fields__
    for k in AS_KEYS:
        assert k in fields, f"引擎缺字段 {k}"
    c = E.PredictionConfig()
    # 4.9.7 翻面:三大总开关(anti_stubborn / showcase_rotate / repeat_guard,
    # 即 predictor_bridge._DEAD_SWITCH_KEYS)同批由 0 改为 1,裸引擎缺省
    # == config.yaml 部署刻度(实测逐局四码 300/300 全同)。
    # 放弃的旧纪律要写明白:此前「裸引擎缺省 = 改造前逐字节等价」不再成立。
    # 但那条纪律在 explore_style 缺省由 ceiling_adaptive 改为 showcase 时
    # 就已不可能成立 —— 实测只回退这三个开关、风格仍 showcase 时,与真原版
    # 仅 28/300 局相同。故改取「等于部署刻度」这条可验证的不变量。
    # 原版姿态仍可完整复现:显式置 0 即可(off_switch 系列测试守着)。
    assert int(c.anti_stubborn) == 1, "裸引擎缺省必须是开(4.9.7 起,与部署刻度一致)"
    for k, v in FINAL_DIALS.items():
        assert float(getattr(c, k)) == pytest.approx(float(v)), f"引擎缺省 {k} 偏离定稿刻度"

    raw = yaml.safe_load(open(ROOT / "backend_async" / "config.yaml", encoding="utf-8"))
    pred = raw["prediction"]
    assert bool(pred["anti_stubborn"]) is True, "部署配置应显式开启反固执"
    for k, v in FINAL_DIALS.items():
        assert float(pred[k]) == pytest.approx(float(v)), f"config.yaml {k} 偏离定稿刻度"

    for k in AS_KEYS:
        assert k in reg.PREDICTION_KEYS
        f = reg.REGISTRY[f"prediction.{k}"]
        assert f.danger and f.hook == "bridge"
        if k in FINAL_DIALS:
            assert float(f.default) == pytest.approx(float(FINAL_DIALS[k])), \
                f"注册表默认 {k} 偏离定稿刻度"


# ── ② 开关关 = 全刻度失效(等价门禁的仓内代理) ───────────────────────────────
def test_off_switch_makes_all_dials_inert():
    wild = {"as_alpha": 1.7, "as_alpha_ord": 1.9, "as_gamma": 0.9, "as_beta": 3.5,
            "as_mcap_hot": 0.9, "as_mcap_cold": 0.9, "as_breaker": 1,
            "as_khyst": 0.4, "as_cooldown": 30, "as_pen_on_hit": 1, "as_agecap": 2}
    a, _, _ = _drive({"anti_stubborn": 0})
    b, _, _ = _drive({"anti_stubborn": 0, **wild})
    assert [r["four"] for r in a] == [r["four"] for r in b], \
        "anti_stubborn=0 时任何 as_* 刻度都不得改变输出"
    # 且确定性:同配置再跑一遍逐局全同(含 why)—— 开/关两态都钉。
    # 开态确定性即「今日口径下补算自还原」的前瞻保证(pred_replay 机制的
    # 保真线与刻度解耦:历史行按历史口径对账,见 test_pred_replay 的口径钉)。
    c, _, _ = _drive({"anti_stubborn": 0})
    assert [(r["four"], r["why"]) for r in a] == [(r["four"], r["why"]) for r in c]
    d1, _, _ = _drive({"anti_stubborn": 1})
    d2, _, _ = _drive({"anti_stubborn": 1})
    assert [(r["four"], r["why"]) for r in d1] == [(r["four"], r["why"]) for r in d2]


# ── ③ 熔断硬不变量:同四码原地连败 ≤ breaker,why 落款 ─────────────────────────
def test_breaker_hard_cap_and_why():
    R = 3
    recs, _, _ = _drive({"anti_stubborn": 1, "as_breaker": R}, n_rounds=60)
    run = worst = 0
    for i in range(1, len(recs)):
        run = run + 1 if recs[i]["four"] == recs[i - 1]["four"] else 0
        worst = max(worst, run)   # 对抗序列局局未中 ⇒ 同四码连推段 = 同四码连败段
    assert worst < R + 1, f"同四码原地连败越顶:{worst + 1} > {R}"
    hits = [r for r in recs if "连败换血" in r["why"]]
    assert hits, "对抗序列上熔断必须触发且 why 落款「连败换血」"
    assert all(f"已{R}局未中" in r["why"] for r in hits)


# ── ④ 状态往返 + 向后兼容 ────────────────────────────────────────────────────
def test_state_roundtrip_and_backward_compat():
    recs, kv, bridge = _drive({"anti_stubborn": 1}, n_rounds=24)
    st = recs[-1]["st"]
    for k in ("pen", "cstk", "pk"):
        assert k in st, f"explore_state 缺 {k}"
    assert set(st["pen"].keys()) == {str(c) for c in range(1, 10)}, "pen 必须字符串键 1..9"
    assert json.loads(json.dumps(st))["pen"] == st["pen"], "pen 经 JSON 往返逐字段还原"
    assert any(v > 0 for v in st["pen"].values()) and st["cstk"] >= 0

    # 旧状态(剥掉新字段)→ 新引擎:predict 正常;开关关时与未剥离输出全同
    stripped = dict(st)
    for k in ("pen", "cstk", "pk", "cool"):
        stripped.pop(k, None)
    kv_old = dict(kv); kv_old["explore_state"] = json.dumps(stripped)
    seq = list(WARM) + [next(c for c in range(1, 10) if c not in r["four"])
                        for r in recs]
    off = PredictorBridge({**BASE_CFG, "anti_stubborn": 0}, {})
    r_new, _ = off.run_prediction("t", seq, dict(kv))
    r_old, _ = off.run_prediction("t", seq, kv_old)
    assert (r_new["main"], r_new["guard"]) == (r_old["main"], r_old["guard"]), \
        "开关关时,新旧两种状态形态必须给出同一预测(向后兼容)"
    on = PredictorBridge({**BASE_CFG, "anti_stubborn": 1}, {})
    r_on, _ = on.run_prediction("t", seq, kv_old)
    assert len(set(list(r_on["main"]) + list(r_on["guard"]))) == 4, \
        "旧状态喂开着的新引擎必须正常出四码(缺失字段走默认)"


# ── ⑤ 指纹复用:同 seq 重复 predict 不重复累积压力 ───────────────────────────
def test_same_seq_repredict_does_not_double_count():
    recs, kv, bridge = _drive({"anti_stubborn": 1}, n_rounds=12)
    seq = list(WARM) + [next(c for c in range(1, 10) if c not in r["four"])
                        for r in recs]
    shim_kv = dict(kv)
    r1, d1 = bridge.run_prediction("t", seq, shim_kv)
    shim_kv.update(d1)
    pen1 = json.loads(shim_kv["explore_state"])["pen"]
    r2, d2 = bridge.run_prediction("t", seq, shim_kv)    # 同一局按需重算
    shim_kv.update(d2)
    pen2 = json.loads(shim_kv["explore_state"])["pen"]
    assert (r1["main"], r1["guard"]) == (r2["main"], r2["guard"]), "同局重算必须同答案"
    assert pen1 == pen2, "同局重算不得重复累积连败压力(指纹复用生效)"
