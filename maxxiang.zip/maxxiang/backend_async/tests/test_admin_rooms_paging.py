"""
test_admin_rooms_paging.py — 名录管理分页(零 Redis / 零网络)
================================================================================
覆盖两件事:
① `_paginate` 的切片与**页码夹紧**(删掉末页最后一行后不会掉进空页);
② `/api/admin/rooms` 端点:一次 HGETALL 取代 N+1 HGET、搜索、来源筛选、
   越界页码回执、挂起表独立分页。

端点用一个假 bus(记录调用次数)驱动,不依赖 Redis。
"""
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import admin_api  # noqa: E402
from app.redis_bus import K_ROOMS  # noqa: E402


# ── ① 纯函数:_paginate ──────────────────────────────────────────────────────
def test_paginate_slices_and_clamps():
    seq = list(range(0, 125))

    p = admin_api._paginate(seq, 1, 50)
    assert p["slice"] == seq[0:50] and p["page"] == 1 and p["pages"] == 3
    assert p["total"] == 125 and p["page_size"] == 50

    p = admin_api._paginate(seq, 3, 50)
    assert p["slice"] == seq[100:125]              # 末页只剩 25 条

    p = admin_api._paginate(seq, 99, 50)           # 越界 → 夹到末页
    assert p["page"] == 3 and p["slice"] == seq[100:125]

    p = admin_api._paginate(seq, 0, 50)            # 页码 <1 → 夹到首页
    assert p["page"] == 1

    p = admin_api._paginate([], 1, 50)             # 空表:1 页 0 条,不是 0 页
    assert p["pages"] == 1 and p["total"] == 0 and p["slice"] == []

    p = admin_api._paginate(seq, 1, 9999)          # 每页条数封顶
    assert p["page_size"] == admin_api.ROOMS_PAGE_SIZE_MAX


def test_paginate_clamp_after_deleting_last_row_of_last_page():
    """真实场景:停在第 3 页(共 101 条),移除最后一条 → 只剩 100 条 / 2 页。
    再拉第 3 页必须回执第 2 页,而不是给一个空页。"""
    p = admin_api._paginate(list(range(100)), 3, 50)
    assert p["page"] == 2 and len(p["slice"]) == 50


# ── ② 端点:假 bus ───────────────────────────────────────────────────────────
class _FakeRedis:
    def __init__(self, metas):
        self._metas = metas
        self.hgetall_calls = 0
        self.hget_calls = 0

    async def hgetall(self, key):
        assert key == K_ROOMS
        self.hgetall_calls += 1
        return dict(self._metas)

    async def hget(self, key, field):              # 若还有人走 N+1 就会计数
        self.hget_calls += 1
        return self._metas.get(field)


class _FakeBus:
    def __init__(self, rooms, discovered, pending):
        self._rooms = rooms
        self._disc = discovered
        self._pend = pending
        self.r = _FakeRedis({rid: json.dumps({"alias": a, "added_at": t})
                             for rid, (a, t) in rooms.items()})
        self.room_meta_calls = 0

    async def active_rooms(self):
        return sorted(self._rooms)

    async def discovered_members(self):
        return set(self._disc)

    async def pending_items(self):
        return dict(self._pend)

    async def room_meta(self, room):               # 旧 N+1 路径:这里应当零调用
        self.room_meta_calls += 1
        return {}


class _FakeST:
    def __init__(self, bus):
        self.bus = bus


class _FakeReq:
    """_guard 只读 headers/cookies/client;此处直接把 _guard 打桩掉,故留空壳。"""
    headers = {}
    cookies = {}
    client = None


@pytest.fixture
def st(monkeypatch):
    rooms = {}
    for i in range(125):                            # 100 策展 + 25 自动发现
        rid = str(200000 + i)
        rooms[rid] = (f"主播{i:03d}" if i % 5 else f"vip{i:03d}", 1_700_000_000_000 + i)
    discovered = {str(200000 + i) for i in range(100, 125)}
    pending = {"abc": 111, "bcd": 222, "cde": 333}
    bus = _FakeBus(rooms, discovered, pending)
    monkeypatch.setattr(admin_api, "_ST", _FakeST(bus))
    monkeypatch.setattr(admin_api, "_guard", lambda req: {"ip": "1.1.1.1", "csrf": "x"})
    return bus


async def _call(**kw):
    kw.setdefault("page", 1)
    kw.setdefault("page_size", admin_api.ROOMS_PAGE_SIZE_DEFAULT)
    kw.setdefault("q", "")
    kw.setdefault("src", "all")
    kw.setdefault("ppage", 1)
    kw.setdefault("ppage_size", admin_api.ROOMS_PAGE_SIZE_DEFAULT)
    return await admin_api.rooms(_FakeReq(), **kw)


async def test_no_n_plus_one(st):
    d = await _call()
    assert st.r.hgetall_calls == 1                  # 整张哈希一次取回
    assert st.r.hget_calls == 0 and st.room_meta_calls == 0   # 不再逐房往返
    assert len(d["items"]) == 50                    # 只回一页
    assert d["total"] == 125 and d["pages"] == 3
    assert d["active_total"] == 125 and d["manual_total"] == 100
    assert d["discovered_total"] == 25


async def test_pages_cover_everything_without_overlap(st):
    seen = []
    for p in (1, 2, 3):
        d = await _call(page=p)
        assert d["page"] == p
        seen += [it["room"] for it in d["items"]]
    assert len(seen) == 125 and len(set(seen)) == 125     # 无重无漏
    assert seen == sorted(seen)                            # 顺序与 active_rooms 一致


async def test_out_of_range_page_is_clamped(st):
    d = await _call(page=99)
    assert d["page"] == 3 and len(d["items"]) == 25


async def test_src_filter(st):
    d = await _call(src="manual", page_size=200)
    assert d["total"] == 100 and all(not it["discovered"] for it in d["items"])
    d = await _call(src="discovered", page_size=200)
    assert d["total"] == 25 and all(it["discovered"] for it in d["items"])
    # 筛选不影响全局计数(徽记仍显示整体规模)
    assert d["active_total"] == 125 and d["manual_total"] == 100


async def test_search_matches_room_and_alias(st):
    d = await _call(q="vip", page_size=200)
    assert d["total"] == 25 and all(it["alias"].startswith("vip") for it in d["items"])

    d = await _call(q="200003")                     # 按房号子串
    assert d["total"] == 1 and d["items"][0]["room"] == "200003"

    d = await _call(q="不存在的关键词")
    assert d["total"] == 0 and d["items"] == [] and d["pages"] == 1


async def test_search_is_case_insensitive_and_trimmed(st):
    a = await _call(q="  VIP ", page_size=200)
    b = await _call(q="vip", page_size=200)
    assert a["total"] == b["total"] == 25 and a["q"] == "vip"


async def test_pending_paginated_independently(st):
    d = await _call(ppage_size=2)
    assert d["pending_total"] == 3 and d["pending_pages"] == 2
    assert [p["alias"] for p in d["pending"]] == ["abc", "bcd"]
    d = await _call(ppage=2, ppage_size=2)
    assert [p["alias"] for p in d["pending"]] == ["cde"]


async def test_search_does_not_touch_pending(st):
    """搜索框长在「活跃名录」卡片里 —— 不该顺手筛掉下面另一张卡的挂起项。"""
    d = await _call(q="不存在的关键词")
    assert d["total"] == 0                       # 活跃名录被筛空
    assert d["pending_total"] == 3               # 挂起表岿然不动
    assert [p["alias"] for p in d["pending"]] == ["abc", "bcd", "cde"]


async def test_bad_src_falls_back_to_all(st):
    d = await _call(src="乱写")
    assert d["src"] == "all" and d["total"] == 125


async def test_corrupt_meta_does_not_break_row(st):
    st.r._metas["200007"] = "{ 这不是 json"
    d = await _call(q="200007")
    assert d["total"] == 1
    row = d["items"][0]
    assert row["room"] == "200007" and row["alias"] == "200007"   # 别名回落到房号
    assert row["added_at"] is None


@pytest.mark.parametrize("raw,expect_alias", [
    ('123', "200007"),                    # 合法 JSON 但不是对象 → meta.get 会 AttributeError
    ('[]', "200007"),                     # 同上
    ('null', "200007"),
    ('{"alias": 42}', "42"),              # alias 是数字 → 下游 .lower() 会 AttributeError
    ('{"alias": null}', "200007"),
    ('{"alias": ""}', "200007"),          # 空别名回落到房号
    ('{}', "200007"),
])
async def test_meta_shape_robustness(st, raw, expect_alias):
    """rooms 哈希里的脏值不得让整个名录接口 500 —— 逐行降级到房号即可。"""
    st.r._metas["200007"] = raw
    d = await _call(page_size=200)                    # 不带 q:顺便验证搜索路径外也不炸
    row = next(i for i in d["items"] if i["room"] == "200007")
    assert row["alias"] == expect_alias
    # 搜索路径会对 alias 调 .lower(),单独再走一遍
    d2 = await _call(q="200007")
    assert d2["total"] == 1
