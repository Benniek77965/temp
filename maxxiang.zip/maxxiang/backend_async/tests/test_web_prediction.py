"""契约⑳:/prediction 仅过滤"落后一整局以上"的铁孤儿(真机 HAR 实证:4.5h 孤儿
在「结算后→新预测生成前」窗口反复闪现远古 target)。桩测 _build_prediction
纯逻辑:目标局 ≤ 最新已出怪局的 pending 视同无;新鲜 pending 正常透出。"""
import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app.web as web  # noqa: E402

STEP = 50_001
LATEST = 1_800_000_000_000 + 40 * STEP


class _DB:
    def __init__(self, pend):
        self._p = pend
    async def pending_prediction(self, room):
        return self._p
    async def prediction_records(self, room, limit=40):
        return []
    async def accuracy(self, room, window):
        return None
    async def latest_round(self, room):
        return {"round_id": LATEST}


class _Bus:
    async def get_snapshot(self, room):
        return {"latestRoundId": str(LATEST)}


@pytest.mark.asyncio
@pytest.mark.parametrize("pend,expect", [
    ({"round_id": LATEST - 320 * STEP, "main_ids": [1, 8],
      "guard_ids": [], "detail": "{}"}, None),          # 4.5h 孤儿 → 滤
    ({"round_id": LATEST, "main_ids": [2],
      "guard_ids": [], "detail": "{}"}, str(LATEST)),   # 恰=最新(结算窗)→ 必须透出
    ({"round_id": LATEST + STEP, "main_ids": [1, 7],
      "guard_ids": [], "detail": "{}"}, str(LATEST + STEP)),  # 新鲜 → 透出
])
async def test_stale_pending_filtered(monkeypatch, pend, expect):
    monkeypatch.setattr(web.ST, "db", _DB(pend), raising=False)
    monkeypatch.setattr(web.ST, "bus", _Bus(), raising=False)
    out = await web._build_prediction("321")
    assert out["target_round_id"] == expect
    if expect:
        assert out["main"] == pend["main_ids"]
