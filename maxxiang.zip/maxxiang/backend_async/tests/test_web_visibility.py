"""
test_web_visibility.py — 前端可见性契约守卫(静态,零依赖)
================================================================================
背景:自动发现房只在后台采集,**不得**出现在任何面向前端的房间集合/计数里。
曾出现过的缺陷类:端点直接返回 `ST.bus.active_rooms()`(后台抓取全集,含发现房),
导致 /api/rooms、monitor add/remove 响应、add-bulk 计数泄漏发现房。

修复后所有集合出口统一经 `web._visible_rooms()`(活跃 − 发现集)。本测试以
**源码契约**方式钉住该约定 —— 不 import web(避免拉起 fastapi 等重依赖),
直接读源码断言:`ST.bus.active_rooms()` 只允许出现在两处白名单上下文:

  1) `_visible_rooms()` 帮助函数内部(它就是过滤的实现);
  2) history 端点的按房号取数校验(数据读取而非列表展示 —— 发现房的数据
     本就应可按房号查询,这正是「自动采集统计」的消费方式);
  3) monitor_add 的准入成员校验(判断待添加房是否「后台已存在」= 近期直播过;
     校验用途,结果不进任何返回给前端的集合)。

新增端点若再直接用 active_rooms 返回集合,本测试立即失败并指路 _visible_rooms。
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

WEB_SRC = (Path(__file__).resolve().parent.parent / "app" / "web.py") \
    .read_text(encoding="utf-8")


def _occurrences(pattern: str):
    """返回 [(行号, 该行内容)],便于失败信息可读。"""
    out = []
    for i, line in enumerate(WEB_SRC.splitlines(), 1):
        if re.search(pattern, line):
            out.append((i, line.strip()))
    return out


def test_active_rooms_only_in_whitelisted_contexts():
    hits = [h for h in _occurrences(r"ST\.bus\.active_rooms\(\)")
            if not h[1].startswith("#") and "禁止直接返回" not in h[1]]
    # 白名单 1:_visible_rooms 实现体(赋值给 active 后做集合差)
    # 白名单 2:history 的活跃集校验(if ... in set(...))
    # 白名单 3:monitor_add 的准入成员校验(known = ...)
    # 白名单 4(3.4.2):/api/crawler/status 的**算力体检** —— 必须按真实负载计数
    #   (策展房 + 自动发现房,worker 两者都在抓),否则 suggestReplicas 会严重低估、
    #   把「算力不足」这个最常见的故障继续藏起来。只取 len() 做算术,**不外泄房号**。
    allowed = [h for h in hits
               if h[1].startswith("active = await ST.bus.active_rooms()")
               or h[1].startswith("if str(rid) in set(await ST.bus.active_rooms())")
               or h[1].startswith("known = definitive and rid in set(await ST.bus.active_rooms())")
               or h[1].startswith("_load_rooms = await ST.bus.active_rooms()")]
    offenders = [h for h in hits if h not in allowed]
    assert not offenders, (
        "web.py 出现未经 _visible_rooms 过滤的 active_rooms 集合出口(会把自动发现房"
        "泄漏给前端),违例行: %r —— 面向前端的房间集合/计数请一律改走 _visible_rooms()"
        % offenders)
    # 且白名单本身仍然在位(防止有人连帮助函数一起删了绕过守卫)
    assert len(allowed) == 4, "白名单上下文数变化(%r),请同步审查本守卫" % allowed


def test_visible_helper_exists_and_filters():
    assert "async def _visible_rooms" in WEB_SRC
    assert "discovered_members" in WEB_SRC.split("async def _visible_rooms", 1)[1] \
        .split("async def ", 1)[0], "_visible_rooms 必须以发现集做过滤"


def test_frontend_collection_endpoints_use_helper():
    """逐个端点钉住:凡返回房间列表/计数的,都调用了 _visible_rooms。"""
    for anchor in ("def rooms_list", "def monitor_add", "def monitor_remove",
                   "def monitor_add_bulk", "def crawler_status",
                   "def _build_live_rooms"):
        seg = WEB_SRC.split(anchor, 1)
        assert len(seg) == 2, "找不到端点 %s(重命名请同步本守卫)" % anchor
        body = seg[1].split("\n@app.", 1)[0]
        assert "_visible_rooms()" in body, (
            "%s 未经 _visible_rooms 过滤 —— 会把自动发现房泄漏给前端" % anchor)
