"""
test_jfvip_cards_purge.py — 卡密删除与清理(4.2.8)的机器保证
================================================================================
本轮补的是一整片**从未被任何测试覆盖**的空白:核查时既有 102 项契约/纪律测试
全绿,而下面每一条钉死的缺陷当时都真实存在。测试全绿本身即是结论的一部分 ——
它们是盲区,不是已知待办。

钉死五类不变量:

  A. **删除口径**(4.2.9 变更)—— 「勾中即删,无需先作废」。4.2.8 曾在 SQL 的
     WHERE 里钉死「永不删除一张仍可兑换的卡」,运营要求取消该阶梯。本组用例
     反过来钉死新口径:DELETE 的筛选条件只有 id 清单,不得夹带状态判据;
     同时「仍可兑换」这一判据不得消失 —— 它改当**墓碑的分类器**,由库侧在
     取证 SELECT 里判定。拦不住的东西,至少要数得清。

  B. **ids 净化** —— `cards_disable(ids=)` 原先直接 `[int(i) for i in ids]`,
     `ids:["a"]` 即 ValueError ⇒ HTTP 500;传字符串会被逐字符展开;长度无上限。
     三条都只因「前端从不发送 ids」而未被触发,是被前端缺陷偶然掩盖的后端缺陷。

  C. **能力必须接出来** —— 后端实现而前端不可达,视同未实现。本项目当年已在
     `test_admin_card_disable_exposes_undo` 里为 undo 立过同款钉子,而同一函数
     同一行的 ids 被漏掉且无人守门。本文件一并补上。

  D. **审计字典全覆盖(元测试)** —— 不修某一个漏项,而是让这一整类漏项从此
     不可能发生:扫出后端写入的每一个动作,断言前端字典全部认得。

  E. **保留期清扫** —— 卡密池必须能排水,且默认关(不配置即不存在)。

纯静态 + 纯内存,零外部依赖(不需要 MySQL / Redis)。
"""
from __future__ import annotations

import ast
import re
from pathlib import Path

import pytest

from tests._srcscan import js_code, py_code

from app import jfvip
from app.settings import UserAuthCfg

APP = Path(__file__).resolve().parent.parent / "app"
ROOT = APP.parent.parent
ADMIN_JS = ROOT / "assets" / "admin.js"


def _cards_seg(js: str) -> str:
    """卡密渲染分支(与既有契约测试同一切法)。"""
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    return seg[seg.index("if (JV.tab === 'cards')"):seg.index("if (JV.tab === 'orders'")]


# ══════════════════════════════════════════════════════════════════════════════
# A. 删除的安全不变量
# ══════════════════════════════════════════════════════════════════════════════
def test_purge_deletes_by_id_without_requiring_disable_first():
    """★ 4.2.9 行为变更(运营要求):「删除选中」**勾中即删,不再要求先作废**。

    4.2.8 曾在 SQL 的 WHERE 里钉死 `NOT (used_by=0 AND disabled=0)`,于是未使用卡
    必须先走一遍作废才删得掉。本条把新口径反过来钉死:DELETE 的筛选条件**只有
    id 清单**,不得再夹带任何状态判据 —— 否则就是悄悄把阶梯加了回来,而管理台
    的文案却在承诺直删,那种不一致比任何一种取舍都糟。

    注:这不是「保护没了」。保护挪到了另外四层(总开关默认关、只收显式 id 清单、
    键入 DELETE 确认、完整墓碑),它们各有独立测试守着,见本文件其余用例。
    """
    src = py_code(APP / "jfvip.py")
    assert "_CARD_DELETABLE" not in src, \
        "可删判据常量残留 —— 前置已取消,留着它迟早有人把它接回 WHERE"
    raw = (APP / "jfvip.py").read_text(encoding="utf-8")
    tree = ast.parse(raw)
    fn = next((n for n in ast.walk(tree)
               if isinstance(n, ast.AsyncFunctionDef) and n.name == "cards_purge"), None)
    assert fn is not None, "cards_purge 丢失或改名"
    body = "\n".join((ast.get_source_segment(raw, n) or "") for n in fn.body)
    assert "DELETE FROM guantai_jf_card" in body, "cards_purge 没有真的删"
    dele = body[body.index("DELETE FROM guantai_jf_card"):]
    stmt = dele[:dele.index('"', dele.index("WHERE"))]
    assert "WHERE id IN" in stmt, "DELETE 不再按 id 清单删?"
    for banned in ("used_by", "disabled", "_CARD_LIVE", " AND "):
        assert banned not in stmt, \
            f"DELETE 的 WHERE 又夹带了状态判据「{banned}」—— 直删口径被悄悄推翻"


def test_live_predicate_survives_as_the_tombstone_classifier():
    """判据本身不能删掉,它改当**分类器**:拦不住的东西至少要数得清。

    取消阶梯后,「仍可兑换」成为唯一会造成资损的一类。它必须在快照里可辨、
    在墓碑里单独可数 —— 事后追责时「删了 3 张已作废」和「删了 3 张还能兑的」
    是完全不同的两件事,混在一起等于让审计说不出真话。

    且判据仍**只写一处**:由库在读出该行的同一条 SELECT 里判定(`AS live`),
    而不是拿回 Python 再推一遍 —— 墓碑要的是库侧事实,不是应用层的复述。
    """
    assert jfvip._CARD_LIVE.replace(" ", "") == "(used_by=0ANDdisabled=0)", \
        f"存活态判据被改动:{jfvip._CARD_LIVE}"
    seg = _exec_body(APP / "jfvip.py", "cards_purge")
    assert "_CARD_LIVE" in seg and "AS live" in seg, \
        "存活态未随快照取证 —— 无法分辨被删的是不是还能兑的卡"
    assert '"unused"' in seg, "三态分类缺 unused(仍可兑换)"
    api = py_code(APP / "admin_api.py")
    aseg = api[api.index('@router.post("/jfvip/cards/purge")'):
               api.index('@router.get("/jfvip/cards/batches")')]
    assert '"unused"' in aseg, "墓碑 byState 未把「仍可兑换」单独计数"
    # 前端必须在**按下确认之前**把这一类摊开 —— 它以前根本删不掉,现在能删了
    p = _purge_handler(js_code(ADMIN_JS))
    assert "live.length" in p, "确认框未统计仍可兑换的张数"
    assert "作废选中" in p, "未给出可撤回的替代手段"


def test_purge_takes_ids_only_never_a_batch():
    """删除**不得**提供按批次整批删。

    删除不可撤销,而批次是自由文本输入框 —— 把破坏性操作押在「运维不打错字」
    上是不可接受的。批量清理走保留期自动清扫,那条路径有明确的时间判据。
    """
    import inspect
    sig = inspect.signature(jfvip.cards_purge)
    assert "batch" not in sig.parameters, \
        "cards_purge 出现 batch 形参 —— 按批次整批删是不可接受的破坏性入口"
    assert list(sig.parameters) == ["ids"], f"cards_purge 形参应只有 ids,实得 {list(sig.parameters)}"


def test_purge_snapshots_before_delete_for_the_tombstone():
    """删之前必须先 SELECT 快照 —— 删完再想知道删了什么就晚了。

    快照同时走两条路:随 HTTP 响应回前端(前端据此在**发起删除前**强制下载
    CSV 存档),以及写进 admin_audit。_audit 内部是 suppress(Exception),
    审计写失败时证据仍在运维手里,这份冗余是刻意的。
    """
    src = py_code(APP / "jfvip.py")
    seg = src[src.index("async def cards_purge"):src.index("async def cards_batches")]
    si, di = seg.index("SELECT id, card"), seg.index("DELETE FROM guantai_jf_card")
    assert si < di, "快照 SELECT 必须在 DELETE 之前"
    assert '"cards": snap' in seg, "快照未随响应回前端"
    api = py_code(APP / "admin_api.py")
    aseg = api[api.index('@router.post("/jfvip/cards/purge")'):
               api.index('@router.get("/jfvip/cards/batches")')]
    assert '"jfvip_cards_purge"' in aseg, "删除未落审计"
    assert '"cards"' in aseg and '"requested"' in aseg and '"affected"' in aseg, \
        "审计墓碑缺卡号或请求/生效数"


def test_purge_reports_requested_and_affected_separately():
    """请求数与生效数必须分别回报。

    静默的数量差异比报错危险得多(项目在 _count_capped / CSV 导出 / 概览降级
    三处写过同一条原则)。运维选了 20 张、实删 17 张时,必须看得见那 3 张去哪了。
    """
    src = py_code(APP / "jfvip.py")
    seg = src[src.index("async def cards_purge"):src.index("async def cards_batches")]
    for k in ('"requested"', '"affected"', '"skipped"'):
        assert k in seg, f"cards_purge 返回体缺 {k}"
    js = _cards_seg(js_code(ADMIN_JS))
    assert "r.skipped" in js, "前端未消费 skipped —— 数量差异会被静默吞掉"


def test_purge_is_off_by_default():
    """总开关默认关 = 旧部署逐字节无感(「不配置即不存在」)。"""
    assert UserAuthCfg().jf_card_purge_enabled is False, "删除能力默认应为关"
    src = py_code(APP / "jfvip.py")
    seg = src[src.index("async def cards_purge"):src.index("async def cards_batches")]
    assert "jf_card_purge_enabled" in seg, \
        "开关判定不在 cards_purge 体内 —— 放在端点里会被后来新增的调用方绕开"
    assert "purge_disabled" in seg


# ══════════════════════════════════════════════════════════════════════════════
# B. ids 净化(实机复现过的 500 通道)
# ══════════════════════════════════════════════════════════════════════════════
@pytest.mark.parametrize("bad", [
    ["a"], ["1", "x"], [None], [{}], [[]], "abc", "123", 5, None, {}, [True, False],
    [1.5, "2.7"], ["-1"], [0], [-3], object(),
])
def test_norm_ids_never_raises(bad):
    """任何输入都不得抛异常 —— 这是管理台端点,一个手滑的 payload 不该变成 500。

    ★ 实机复现过的原缺陷:`ids:["a"]` → int("a") 抛 ValueError → FastAPI
      未捕获 → HTTP 500。
    """
    out = jfvip.norm_ids(bad)
    assert isinstance(out, list)
    assert all(isinstance(v, int) and v > 0 for v in out)


def test_norm_ids_rejects_string_iteration():
    """传字符串而非数组时不得被逐字符展开。

    ★ 原缺陷:`ids:"abc"` → len() 得 3 → 拼出 3 个占位符,**把字符当成了 id**。
    """
    assert jfvip.norm_ids("123") == [], "字符串被当成了 id 序列"
    assert jfvip.norm_ids("abc") == []


def test_overlimit_is_rejected_not_truncated():
    """★ 复审自查揪出的**自引入**缺陷:norm_ids 对超限输入是静默截断。

    前端选择集跨页保留(按 id 存),第 1 页选 500 + 第 2 页选 500 = 1000 轻易可达。
    截断后 cards_purge 回报的 requested 是**砍完之后**的 500,skipped 恒为 0,
    前端弹「已永久删除 500 张」—— 另外 500 张原封不动,屏幕上零迹象。
    这正是项目在 CSV 导出那处写过的「静默少 450 张,文件里毫无迹象」。
    """
    assert jfvip.ids_overflow(list(range(1, 502))) is True
    assert jfvip.ids_overflow(list(range(1, 501))) is False
    assert jfvip.ids_overflow("x" * 9999) is False          # 字符串不算超限,走 bad_ids
    assert jfvip.ids_overflow(None) is False
    src = py_code(APP / "jfvip.py")
    seg = src[src.index("async def cards_purge"):src.index("async def cards_batch_stat")]
    assert "ids_overflow(" in seg and '"too_many"' in seg, \
        "cards_purge 未对超限显式拒绝 —— 静默截断会让少删多少这个差异消失"
    api = py_code(APP / "admin_api.py")
    assert '"too_many"' in api, "端点未把 too_many 转成可读错误"
    js = js_code(ADMIN_JS)
    assert "JV_SEL_CAP = 500" in js, "前端缺选择上限常量"
    assert jfvip._MAX_IDS_PER_CALL == 500, "前后端上限必须同值"


def test_batch_stat_is_single_batch_not_full_scan():
    """★ 复审自查揪出的**自引入**性能缺陷。

    真库实测(MariaDB 10.11 / 本文件 DDL 1:1 / 40 万行 / 800 批次 /
    FLUSH STATUS + Handler_read_* 数真实扫描行数):

        初版 GROUP BY batch + 三个 SUM  ……… 扫 400,000 行(全表)
        DISTINCT batch LIMIT 200        ……… 扫 100,000 行
        递归 CTE 索引跳跃法              ……… 扫 320,000,000 行(优化器不下推)
        WHERE batch=?(现方案)          ………       500 行

    而初版是**每次渲染卡密页都调**,含每一次翻页 —— 与项目设立 _count_capped
    要避免的是同一件事。
    """
    # 用可执行代码而非原文 —— docstring 里引述了旧写法「GROUP BY batch」,
    # 朴素扫描会把它判成「代码里还有这个」(本文件已被同一类假阳性咬过两次)
    seg = _exec_body(APP / "jfvip.py", "cards_batch_stat")
    assert "WHERE batch=%s" in seg, "单批统计未走 idx_batch 直击"
    assert "GROUP BY" not in seg, "单批统计不该有 GROUP BY"
    lst = _exec_body(APP / "jfvip.py", "cards_batches")
    assert "SUM(" not in lst, "批次名清单不该带 SUM(那会强制读全部行)"
    assert "DISTINCT batch" in lst
    js = js_code(ADMIN_JS)
    seg2 = js[js.index("if (JV.tab === 'cards')"):js.index("if (JV.tab === 'orders'")]
    assert "JV.cards._batches" in seg2, "批次清单未缓存"
    assert 'id="jvCardBatchLoad"' in seg2, "批次清单未做成惰性载入"
    assert "cards/batches?batch=" in seg2, "未按单批取统计"


def test_purge_archive_covers_every_selected_row_not_just_this_page():
    """★ 复审自查揪出的**自引入**缺陷:初版删除时

        ids  = [...sel]                          ← 跨页全部
        rows = items.filter(c => sel.has(c.id))  ← **仅当前页**

    于是确认框里的数字、以及删除前强制下载的存档 CSV 都只覆盖当前页,
    实际删除的却是跨页全部。存档与实删范围不一致 —— 而存档的全部意义
    就是覆盖被删的那些行。
    """
    js = js_code(ADMIN_JS)
    seg = js[js.index("if (JV.tab === 'cards')"):js.index("if (JV.tab === 'orders'")]
    assert "selMeta" in seg, "缺 id→行数据 映射,跨页选择拿不到完整数据"
    p = seg[seg.index("$('#jvSelPurge')"):]
    assert "items.filter" not in p[:900], "删除路径仍在用只含当前页的 items"
    assert "selMeta.get" in p, "删除路径未从 selMeta 取行数据"
    assert "rows.length !== ids.length" in p, "缺「存不全就不删」的兜底"
    # 选择集变动时必须同步维护 selMeta,否则会留下悬空条目
    assert "selMeta.set(" in seg and "selMeta.delete(" in seg and "selMeta.clear()" in seg


def test_grants_uid_filter_is_visible_and_clearable():
    """★ 复审自查缺陷:卡密页「使用者」链接设上 JV.grants.uid 把流水收窄到某人,
    而流水页既不显示这个筛选、也没有清除入口 —— 运维会看到一个「为什么流水
    这么少」的页面且无从下手。静默状态比报错危险。
    """
    js = js_code(ADMIN_JS)
    seg = js[js.index("const JV = {"):js.index("function renderDeploy")]
    g = seg[seg.index("if (JV.tab === 'orders'"):]
    assert "uidChip" in g, "流水页未显示 uid 收窄状态"
    assert 'id="jvGrantUidClear"' in g, "缺清除 uid 筛选的入口"
    assert "JV.grants.uid = 0" in g, "清除按钮没有真的清掉 uid"
    assert "st.source || st.uid" in g, "空态判据未把 uid 算作筛选条件"


def test_norm_ids_is_bounded_deduped_and_sorted():
    """长度必须有上限;去重 + 定序让 SQL 形态稳定,便于复现与审计。

    ★ 原缺陷:长度无上限,10 万个 id 会拼出 10 万占位符的 SQL,
      撑爆 max_allowed_packet 或事务内存。
    """
    out = jfvip.norm_ids(list(range(1, 100000)))
    assert len(out) <= jfvip._MAX_IDS_PER_CALL, "ids 长度无上限"
    assert jfvip.norm_ids([3, 1, 2, 1, 3]) == [1, 2, 3], "未去重或未定序"
    # 与发卡上限、列表页 size 上限三者同值:「全选本页」与「一次能提交」严丝合缝
    assert jfvip._MAX_IDS_PER_CALL == jfvip._MAX_CARDS_PER_BATCH == 500


def test_norm_ids_rejects_bool():
    """bool 是 int 的子类 —— True 会悄悄变成 id=1,删掉别人的卡。"""
    assert jfvip.norm_ids([True, True]) == []


def _exec_body(path: Path, fname: str) -> str:
    """取某函数的**可执行代码**(剥掉 docstring 与整行注释)。

    ★ 本测试写就时当场被咬了一次:`norm_ids` 的 docstring 里引述了旧缺陷的写法
      `[int(i) for i in ids]`,朴素扫描把它判成「代码里还有这个」而变红。
      注释不会执行 —— 这正是本项目 _srcscan 模块存在的理由,只是它剥不掉
      三引号 docstring,故此处用 AST 再剥一层。
    """
    src = path.read_text(encoding="utf-8")
    fn = next((n for n in ast.walk(ast.parse(src))
               if isinstance(n, (ast.AsyncFunctionDef, ast.FunctionDef))
               and n.name == fname), None)
    assert fn is not None, f"{fname} 丢失或改名"
    nodes = fn.body[1:] if (fn.body and isinstance(fn.body[0], ast.Expr)
                            and isinstance(fn.body[0].value, ast.Constant)
                            and isinstance(fn.body[0].value.value, str)) else fn.body
    code = "\n".join((ast.get_source_segment(src, n) or "") for n in nodes)
    return "\n".join("" if ln.lstrip().startswith("#") else ln
                     for ln in code.split("\n"))


def test_all_id_taking_paths_go_through_norm_ids():
    """凡是接收 ids 的函数都必须过 norm_ids,可执行代码里不许再有裸 int() 推导。"""
    for fname in ("cards_disable", "cards_purge", "cards_set_note"):
        body = _exec_body(APP / "jfvip.py", fname)
        assert "[int(i) for i in ids]" not in body, \
            f"{fname} 仍有未净化的裸 int() 推导"
        assert "norm_ids(" in body, f"{fname} 未接入 norm_ids"


# ══════════════════════════════════════════════════════════════════════════════
# C. 能力必须接出来(后端实现而前端不可达 = 未实现)
# ══════════════════════════════════════════════════════════════════════════════
def test_admin_card_table_exposes_row_selection():
    """★ 核查实测:后端 cards_disable(ids=) 早已实现、admin_api 也一直在透传,
    而前端**从来没有勾选框**,那条通路等于不存在 —— 运维只能「按批次全作废」。

    这与本项目当年抓到并修掉的 undo 缺陷是**同一函数同一行**的同类问题。
    当时为 undo 立了钉子,ids 被漏掉且无人守门。
    """
    seg = _cards_seg(js_code(ADMIN_JS))
    assert 'id="jvSelAll"' in seg, "缺全选框"
    assert 'class="jv-ck"' in seg, "缺行选框"
    assert re.search(r"\bids\b", seg), "前端从未发送 ids"
    for eid in ("jvSelDisable", "jvSelRestore", "jvSelPurge", "jvSelClear", "jvSelNote"):
        assert f'id="{eid}"' in seg, f"缺选中操作入口 {eid}(或用模板变量拼了 id)"


def test_admin_card_search_is_wired_end_to_end():
    """按卡号搜索:控件 → 请求串 → 端点签名 → 业务层形参,四层一起钉。

    界面上摆着、后端接不到,是最沉默的一类漂移:点下去有反应、结果却不对,
    没人会怀疑到参数没送。
    """
    seg = _cards_seg(js_code(ADMIN_JS))
    assert 'id="jvCardNo"' in seg, "缺卡号搜索框"
    assert "&card=" in seg, "卡号没进请求串(界面摆设)"
    api = py_code(APP / "admin_api.py")
    assert "card: str = Query(" in api, "/jfvip/cards 未接收 card"
    core = py_code(APP / "jfvip.py")
    seg2 = core[core.index("async def cards_page"):core.index("async def cards_disable")]
    assert "card: str" in seg2, "cards_page 缺 card 形参"
    # 与 orders_page 的 order_no 同款:只做前缀 + 转义 LIKE 元字符
    assert "card LIKE %s" in seg2, "卡号搜索未走 LIKE"
    assert 'replace("%", "\\\\%")' in seg2, "LIKE 元字符 % 未转义(会静默变成全表扫)"
    assert 'esc + "%"' in seg2, "卡号搜索不是前缀匹配(中缀 LIKE 无法走 uk_card)"


def test_card_list_exposes_used_uid():
    """列表必须回 uid —— 用户名可重名、可变更,当不了跳转锚点。

    ★ 核查实测:SQL 一直取着 used_by,返回体却只映射成布尔的 `used`,
      uid 被丢掉,从「卡」到「人」的链路在此断开。
    """
    core = py_code(APP / "jfvip.py")
    seg = core[core.index("async def cards_page"):core.index("async def cards_disable")]
    assert '"usedBy"' in seg, "cards_page 返回体缺 usedBy"
    seg2 = _cards_seg(js_code(ADMIN_JS))
    assert "c.usedBy" in seg2, "前端未渲染 usedBy"
    # 跳转目标要真的能按 uid 收窄 —— 否则点了等于没点
    js = js_code(ADMIN_JS)
    assert "&uid=" in js[js.index("const mkListUrl") if "const mkListUrl" in js else 0:] \
        or "uid=${encodeURIComponent(o.uid)}" in js, \
        "流水页 URL 未带 uid —— 从卡跳到人会落到全量列表上"


def test_orphan_state_is_reachable_from_ui():
    """`disabled=1 AND used_by<>0` 必须可筛。

    正常流程产生不了它(_grant_tx 对 disabled 卡直接回 card_disabled),但手工
    改库/历史脏数据会。原来三个筛选值互斥且**不覆盖**这一态 —— 它在任何筛选
    下都查不出来,是一个不可见的数据黑洞。平时恒为 0;一旦非 0 就是有人绕过
    应用层动过库的信号。
    """
    core = py_code(APP / "jfvip.py")
    seg = core[core.index("async def cards_page"):core.index("async def cards_disable")]
    assert 'status == "orphan"' in seg, "后端缺孤儿态判据"
    assert "disabled=1 AND used_by<>0" in seg
    assert "'orphan'" in _cards_seg(js_code(ADMIN_JS)), "前端筛选缺孤儿态选项"


def test_batch_enumeration_replaces_blind_typing():
    """批次必须可枚举 —— 「作废整批未用卡」是破坏性操作,而批次原先是自由文本框,
    等于把安全性押在运维不打错字上。"""
    core = py_code(APP / "jfvip.py")
    assert "async def cards_batches" in core
    api = py_code(APP / "admin_api.py")
    assert '@router.get("/jfvip/cards/batches")' in api
    seg = _cards_seg(js_code(ADMIN_JS))
    assert 'id="jvBatchList"' in seg and "list=\"jvBatchList\"" in seg, \
        "批次输入框未接上可选清单"


def _purge_handler(js: str) -> str:
    """精确切出删除的**点击处理器**。

    ★ 写这条测试时被自己咬了一次:朴素地找 `$('#jvSelPurge')` 会命中 syncSel 里
      那处按钮禁用判定(它在源码里更靠前),切出来的片段于是把发卡 txt 下载、
      导出 CSV 下载都圈了进去,断言「删除路径不该有 jvDownload」当场假红。
      锚点必须是 addEventListener 那一处。
    """
    seg = _cards_seg(js)
    i = seg.index("$('#jvSelPurge').addEventListener")
    return seg[i:seg.index("\n    });", i)]


def test_purge_requires_typed_confirmation():
    """删除前必须键入确认。

    注:删除前的强制 CSV 存档已按需求移除,审计因此成为**唯一**证据路径 ——
    对应地,墓碑不得截断(见下条),且审计写失败必须可见(再下一条)。
    """
    p = _purge_handler(js_code(ADMIN_JS))
    assert "'DELETE'" in p, "删除缺键入确认"
    assert "jvDownload(" not in p, "删除路径不应再有自动下载(已按需求移除)"
    assert "自动下载" not in p and "CSV 存档" not in p, \
        "确认框仍在承诺一份不会发生的存档 —— 对不可逆操作谎称有存档是最坏的一种"
    assert "rows.length !== ids.length" in p, "跨页数据完整性兜底丢了"


def test_tombstone_is_never_truncated():
    """★ 复审自查:墓碑此前写 `[:200]`,而单次可删 500 张 —— 最多 300 个被删卡号
    不进审计且无任何标记。这与本轮修掉的 ids 静默截断是同一类错误,我在墓碑上
    又犯了一次。

    CSV 存档移除后审计是唯一证据路径,截断变成不可接受。
    500 个卡号 ≈ 8.9 KB,PostgreSQL JSONB 单值上限 255 MB,截断毫无必要。
    """
    api = py_code(APP / "admin_api.py")
    seg = api[api.index('@router.post("/jfvip/cards/purge")'):
              api.index('@router.get("/jfvip/cards/batches")')]
    assert "[:200]" not in seg, "墓碑仍在截断卡号"
    assert '"cards": [c["card"] for c in out["cards"]]' in seg, "墓碑未完整记录卡号"
    # 另两处同类
    assert "[:200]" not in api, "admin_api 仍有其它 200 截断"


def test_purge_audit_failure_is_visible_not_suppressed():
    """★ 复审自查:项目通用的 _audit 是 contextlib.suppress(Exception) —— 写失败
    静默吞掉。CSV 存档移除后审计成为唯一证据路径,不可逆操作不能这样。

    故 purge 不走 _audit,直接写并如实回报;失败时前端把卡号摊开让运维人工留痕。
    (删除已提交、无法回滚,能做的是绝不假装它被记录了。)
    """
    api = py_code(APP / "admin_api.py")
    seg = api[api.index('@router.post("/jfvip/cards/purge")'):
              api.index('@router.get("/jfvip/cards/batches")')]
    assert "_ST.db.audit_add(" in seg, "purge 未直接写审计(走 _audit 会静默吞掉失败)"
    assert "audit_ok" in seg and '"auditOk"' in seg, "审计结果未回报前端"
    p = _purge_handler(js_code(ADMIN_JS))
    assert "auditOk === false" in p, "前端未处理审计失败"
    # 失败分支必须用 ask(需人确认)而非 toast(2.6 秒自动消失,而这可能是唯一的证据)
    fail = p[p.index("auditOk === false"):]
    fail = fail[:fail.index("} else {")]
    assert "await ask(" in fail, "审计失败未用需确认的弹窗"
    assert "toast(" not in fail, "审计失败仅用 toast —— 2.6 秒就消失"


def test_purge_button_reflects_the_switch():
    """★ 复审自查缺陷:前端此前无从得知删除开关状态,而它**默认关** —— 于是默认
    体验是「选中 → 点删除 → 键入 DELETE → 最后被 403 打回」。

    不仅难用,更糟的是它训练运维养成条件反射式键入 DELETE 的习惯,
    而那正是二次确认存在的意义所在。
    """
    core = py_code(APP / "jfvip.py")
    seg = core[core.index("async def overview"):]
    assert '"purgeEnabled"' in seg, "overview 未下发删除开关状态"
    js = _cards_seg(js_code(ADMIN_JS))
    assert "ov.purgeEnabled" in js, "前端未读开关状态"
    assert "purgeOn" in js
    assert "jf_card_purge_enabled" in js, "未启用时未给出可操作的开启指引"


def test_card_numbers_are_shown_in_full():
    """卡号在列表页**完整明文**显示(按需求移除掩码)。

    权衡:未使用卡的卡号即不记名兑换凭证,投屏/截图会暴露。但管理台本就只对
    已鉴权管理员开放,且掩码会让日常核对多一步 —— 取舍由使用者决定。
    这与原始版行为一致(原本就是全量明文),故不构成相对原项目的回退。
    """
    seg = _cards_seg(js_code(ADMIN_JS))
    assert "maskCard" not in seg, "掩码残留"
    assert "jvCardReveal" not in seg, "「显示完整卡号」开关残留"
    assert "JV.cards.reveal" not in seg, "reveal 状态残留"
    assert '<td class="mono">${esc(c.card)}</td>' in seg, "卡号未按明文渲染"
    js = js_code(ADMIN_JS)
    assert "_revealTimer" not in js, "复位定时器残留(会留下悬空 timer)"


# ══════════════════════════════════════════════════════════════════════════════
# D. 审计字典全覆盖(元测试:不修一个漏项,而是让这一类漏项不可能发生)
# ══════════════════════════════════════════════════════════════════════════════
def test_audit_dict_covers_all_backend_actions():
    """★ 核查实测:jfvip_cards_gen / jfvip_cards_disable / jfvip_grant /
    jfvip_revoke 四个动作后端一直在写,前端字典**一个都没有**。后果两层:

      ① 表格走 `AUDIT_ACT[a.action] || a.action`,显示成生硬的英文码;
      ② 更严重:筛选下拉是 `['', ...Object.keys(AUDIT_ACT)]` ——
         发卡与作废这两个直接对应真金白银的动作**根本无法筛选**。

    本测试不修某个具体漏项,它让这一整类漏项从此不可能发生。
    """
    api = py_code(APP / "admin_api.py")
    back = set(re.findall(r'_audit\(_actor\(payload\),\s*"([a-z_]+)"', api))
    # 三元写法(reg_block/reg_unblock 那种)也要收进来
    back |= set(re.findall(r'_audit\(_actor\(payload\),\s*"([a-z_]+)"\s+if\s', api))
    back |= set(re.findall(r'"([a-z_]+)"\s+if\s+\w+\s+else\s+"([a-z_]+)"', api) and
                [x for pair in re.findall(r'"([a-z_]+)"\s+if\s+\w+\s+else\s+"([a-z_]+)"', api)
                 for x in pair])
    assert back, "没扫到任何后端审计动作 —— 扫描式失效了"
    js = js_code(ADMIN_JS)
    seg = js[js.index("const AUDIT_ACT = {"):js.index("const ACTIONS =")]
    front = set(re.findall(r"([a-z_]+):\s*'", seg))
    missing = sorted(back - front)
    assert not missing, (
        f"审计字典缺失动作 {missing} —— 这些动作在审计页既无中文名、"
        f"也**无法被筛选**(下拉项由 Object.keys(AUDIT_ACT) 生成)")


def test_new_card_actions_are_all_audited():
    """三个新写端点必须各自落审计 —— 尤其是不可逆的删除。"""
    api = py_code(APP / "admin_api.py")
    for act in ("jfvip_cards_purge", "jfvip_cards_note"):
        assert f'"{act}"' in api, f"端点未落审计动作 {act}"


# ══════════════════════════════════════════════════════════════════════════════
# E. 保留期清扫(卡密池排水)
# ══════════════════════════════════════════════════════════════════════════════
def test_janitor_drains_the_card_pool():
    """guantai_jf_card 此前是全项目**唯一一张只增不减、无保留策略**的业务表。

    它与订单表/流水表性质不同:后两者是账本(永不可删是对的),卡密表是资源池
    —— 池子必须能排水,否则 _COUNT_CAP=50000 触顶后精确计数永久丢失
    (单批 500 张,100 个批次即到顶)。
    """
    src = py_code(APP / "userauth.py")
    seg = src[src.index("async def _janitor"):src.index("async def _authenticate")]
    # 5.4.0 起卡密池排水走两阶段删除(userauth._jn_delete_2p:快照读选主键 → 强制主键删除,
    # 不再锁住仍可兑换的卡 —— 单条 DELETE 写法实测会把并发兑换卡住 141ms)。语句不再以字面量
    # 「DELETE FROM guantai_jf_card … LIMIT 5000」出现,以下按新结构检查**同样的**五条约束。
    calls = []
    for m in re.finditer(r'_jn_delete(?:_2p)?\(\s*"guantai_jf_card",\s*"([^"]*)"', seg):
        fixed = re.search(r"fixed=(\d+)", seg[m.end():m.end() + 120])
        calls.append((m.group(1), fixed.group(1) if fixed else None))
    assert calls, "清扫未覆盖卡密池"
    wheres = [w for w, _ in calls]
    # 只碰终态卡 —— 绝不碰仍可兑换的卡(那类卡可能已发到用户手里)
    assert any("used_by=0 AND disabled=1" in w for w in wheres), "作废卡清扫判据不对"
    assert any("used_by<>0" in w for w in wheres), "已兑换卡清扫判据不对"
    assert all(b == "5000" for _, b in calls), "清扫未分批(一次删几十万行会把行锁压在兑换路径上)"
    assert not any("disabled=0" in w for w in wheres), "清扫竟会删掉仍可兑换的卡 —— 资损"


def test_card_retention_is_off_by_default():
    """两项保留期默认 0(不清扫),严格遵循「不配置即不存在」。"""
    c = UserAuthCfg()
    assert c.jf_card_disabled_age_days == 0
    assert c.jf_card_used_retention_days == 0


def test_disabled_cleanup_is_named_by_age_not_retention():
    """★ 复审自查:自动清扫的作废卡判据是 `created_at`(**卡龄**),而参数原名叫
    「保留期」—— 这暗示「作废后 N 天内还能恢复」的召回窗,而它根本不存在。

    真库实测:设定 365 天,一张 730 天前发的卡在**作废一分钟后**即被删除。
    根因与我在手动路径上删掉冷却期时是同一条:表**没有 disabled_at 列**,
    且禁止 ALTER,无从得知何时被作废。我在手动路径上修了,却把同样的假语义
    留在了**自动路径**上 —— 那里更糟:无人在环、不可逆。

    无法正确实现,就必须让名字说实话。
    """
    from app.settings import UserAuthCfg as U
    assert hasattr(U(), "jf_card_disabled_age_days"), "参数未改名"
    assert not hasattr(U(), "jf_card_disabled_retention_days"), \
        "旧名残留 —— 「保留期」会让人以为买到了召回窗"
    from app import config_registry as reg
    f = reg.REGISTRY["userauth.jf_card_disabled_age_days"]
    assert "卡龄" in f.label, "标签未点明按卡龄"
    assert "不是" in f.desc and "disabled_at" in f.desc, \
        "说明未讲清它不是按作废时长、以及为什么做不到"
    # 已兑换卡那条判据是对的:used_at 就是状态跃迁时刻,按它算保留期名副其实
    src = py_code(APP / "userauth.py")
    seg = src[src.index("async def _janitor"):src.index("async def _authenticate")]
    assert "used_at < DATE_SUB" in seg, "已兑换卡应按 used_at 计(那才是真的状态时刻)"


def test_ask_dialog_can_hold_long_evidence():
    """★ 复审自查:审计失败时弹窗要列出最多 500 个卡号(≈9000px 高),而
    `#ask` 是 position:fixed 不滚动、`.box` 无 max-height、`.b` 无 overflow ——
    按钮会落在视口外约 4400px 处**点不到**,而那个弹窗恰恰是唯一的证据。

    Esc 能关,但一关证据就没了。
    """
    from tests._srcscan import css_code
    css = css_code(APP.parent.parent / "assets" / "admin.css")
    i = css.index("#ask .b{")
    rule = css[i:css.index("}", i)]
    assert "max-height" in rule and "overflow:auto" in rule, \
        "长内容弹窗仍会溢出视口,按钮点不到"
    # 控制台兜底:弹窗可能被误关,证据不该只挂在一个模态框上
    js = js_code(ADMIN_JS)
    p = _purge_handler(js)
    assert "console.error(" in p, "审计失败缺控制台兜底"


def test_every_jf_env_var_is_documented():
    """★ 复审自查:我连改四轮,**一个字的文档都没动过**。

    实证:既有每个 `STA_JF_*` 变量都在 **2 处**登记(JFVIP-SYSTEM.md 的环境变量表
    + backend_async/deploy/.env.example),而本轮新增的三个在 **0 处**。

    本项目对此早有明文纪律 —— test_docs_and_ddl_follow_the_new_card_prefix 的
    原话是「文档撒谎和代码有 bug 一样有害」。

    本测试是**元测试**:它不补某几条,而是让「加了 STA_JF_ 变量却不写文档」
    这一整类漏项从此不可能发生。
    """
    from app import config_registry as reg
    envs = {f.env for k, f in reg.REGISTRY.items()
            if k.startswith("userauth.jf_") and f.env}
    assert envs, "扫不到任何 jf 环境变量 —— 扫描式失效了"
    doc = (ROOT / "JFVIP-SYSTEM.md").read_text(encoding="utf-8")
    env_example = (APP.parent / "deploy" / ".env.example").read_text(encoding="utf-8")
    miss_doc = sorted(e for e in envs if e not in doc)
    miss_env = sorted(e for e in envs if e not in env_example)
    assert not miss_doc, f"JFVIP-SYSTEM.md 未登记: {miss_doc}"
    assert not miss_env, f".env.example 未登记: {miss_env}"


def test_card_tab_docs_match_actual_capabilities():
    """卡密页的能力描述必须跟上代码 —— 文档写着「只能整批召回」而实际能删卡,
    会让运维对一个不可逆操作毫无预期。admin.html 的帮助面板同理(那是新人
    唯一会读的地方)。
    """
    doc = (ROOT / "JFVIP-SYSTEM.md").read_text(encoding="utf-8")
    html = (ROOT / "admin.html").read_text(encoding="utf-8")
    for kw in ("永久删除", "卡号"):
        assert kw in doc, f"JFVIP-SYSTEM.md 卡密章节未提及「{kw}」"
        assert kw in html, f"admin.html 帮助未提及「{kw}」"
    # ★ 4.2.9:文档必须跟上「勾中即删」的新口径。旧版这里断言的是安全不变量
    #   NOT (used_by = 0 AND disabled = 0);前置取消后再断言它,等于逼着文档
    #   继续承诺一条已经不存在的保护 —— 那正是本用例要防的「文档撒谎」。
    assert "无需先作废" in doc and "无需先作废" in html, \
        "文档/帮助未写明删除已不需要先作废 —— 运维会以为还有那道拦截"
    # 唯一的资损面必须被显式警示,不能只说「能删了」
    assert "仍可兑换" in doc and "仍可兑换" in html, \
        "文档/帮助未警示「仍可兑换的卡也会被删」这一资损面"
    # 按卡龄这条反直觉语义必须显式警示,否则等于文档在撒谎
    assert "不是" in doc and "disabled_at" in doc, "文档未讲清作废卡清扫是按卡龄"


def test_no_alter_table_was_introduced():
    """★ 回归钉:本轮全部能力**零 DDL**。

    用户库禁 ALTER(test_jfvip_discipline 钉死),且建表是 CREATE TABLE
    IF NOT EXISTS —— 改 DDL 对**存量部署毫无作用**(老库永远不会长出新列,
    代码却会开始读它)。任何「顺手加一列」的改动都会在这里变红。
    """
    for name in ("userauth.py", "jfvip.py", "admin_api.py"):
        src = py_code(APP / name)
        assert not re.search(r"\bALTER\s+TABLE\b", src, re.I), f"{name} 出现 ALTER TABLE"
    ddl = py_code(APP / "userauth.py")
    ddl = ddl[ddl.index("guantai_jf_card"):]
    ddl = ddl[:ddl.index("guantai_jf_grant_log")]
    for col in ("disabled_at", "expire_at", "deleted_at"):
        assert col not in ddl, f"卡密表被加了新列 {col} —— 存量库不会有它,代码却会读它"


def test_discipline_still_holds_after_purge_landed():
    """回归:对 tb_user 的写纪律不受本轮影响 —— UPDATE 仍恰好 1 处且在
    _grant_tx 内,对 tb_user 的 DELETE 仍为 0。删卡只碰 guantai_jf_card。"""
    src = py_code(APP / "jfvip.py")
    tbl = r"(?:`?tb_user`?|`?\{[a-zA-Z_.]*user_table[^}]*\}`?)"
    assert len(re.findall(r"\bUPDATE\s+" + tbl, src, re.I)) == 1
    for verb in (r"DELETE\s+FROM", r"TRUNCATE", r"DROP\s+TABLE"):
        assert not re.search(r"\b" + verb + r"\s+" + tbl, src, re.I), \
            f"jfvip.py 对 tb_user 出现禁用动词"
