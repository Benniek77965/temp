#!/bin/bash
# probe_award_path.sh — 在部署机上一键判定「回填占比 / RoundAward 主路健康」
# 用法:cd deploy && bash ../backend_async/scripts/probe_award_path.sh [窗口分钟=30]
# 只读探针,零代码改动;经 stdin 喂进 worker 容器 → **旧镜像同样可跑,无需重建**。
set -e
WIN_MIN="${1:-30}"
HERE="$(cd "$(dirname "$0")" && pwd)"

docker compose exec -T worker python - "$WIN_MIN" < "$HERE/probe_award_path.py"

echo
echo "════ D. 日志归因(近 ${WIN_MIN}m;history 行分别由哪条触发路径产生)════"
docker compose logs --since "${WIN_MIN}m" worker 2>&1 \
  | grep -aoE "早探 GameHistory 命中|多次为空,GameHistory 兜底|终拍仍空|\[漏局\]|官方缺失|AuthExpired|票据|429|403" \
  | sort | uniq -c | sort -rn || true
echo "  (无输出 = 近 ${WIN_MIN}m 没有任何兜底/限流迹象,history 行全为首见/补录)"
