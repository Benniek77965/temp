/* 真 Chromium 实测:.ri-live 三态在两种侧栏形态下的**计算样式与几何**。
   只加载 app.css + 复刻 renderRail 的条目 DOM(不跑整站 app.js,避免登录门/网络依赖),
   逐条断言"我在注释里声称的效果"是否真的发生 —— 而不是靠读 CSS 推理。*/
import { chromium } from 'playwright';
import { readFileSync } from 'fs';

const CSS = readFileSync('/home/claude/work/proj/maxxiang/assets/app.css', 'utf8');

const ROW = (alias, cls, hidden) => `
  <button type="button" class="room-item ${cls.on ? 'is-on' : ''}" data-alias="${alias}">
    <img src="" alt="" onerror="this.style.visibility='hidden'">
    <span class="ri-meta"><b>主播${alias}</b><span class="ri-sub"><span class="ri-no">№ ${alias}</span><span class="ri-tick">开 12s</span></span></span>
    <i class="ri-del">×</i>
    <i class="${cls.live}" data-la="${alias}" ${hidden ? 'hidden' : ''} title="t"></i>
  </button>`;

const mkHTML = (rail) => `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<style>${CSS}</style></head>
<body data-layout="cockpit" ${rail}>
  <aside class="rail"><div class="room-list" id="rl">
    ${ROW('1001', { live: 'ri-live is-live', on: false }, false)}
    ${ROW('1002', { live: 'ri-live', on: false }, true)}
    ${ROW('1003', { live: 'ri-live is-unknown', on: false }, false)}
    ${ROW('1004', { live: 'ri-live is-live', on: true }, false)}
  </div></aside>
</body></html>`;

const probe = () => {
  const out = {};
  for (const el of document.querySelectorAll('.room-item')) {
    const dot = el.querySelector('.ri-live');
    const cs = getComputedStyle(dot);
    const r = dot.getBoundingClientRect();
    out[el.dataset.alias] = {
      display: cs.display,
      bg: cs.backgroundColor,
      border: cs.borderTopWidth + ' ' + cs.borderTopColor,
      anim: cs.animationName,
      w: Math.round(r.width * 100) / 100,
      h: Math.round(r.height * 100) / 100,
      x: Math.round(r.x * 100) / 100,
      rowH: Math.round(el.getBoundingClientRect().height * 100) / 100,
      pos: cs.position,
    };
  }
  // 实测对比度:取圆点所在处的实际背景(逐级向上找首个非透明祖先背景)
  const bgOf = (el) => {
    for (let n = el.parentElement; n; n = n.parentElement) {
      const c = getComputedStyle(n).backgroundColor;
      if (c && c !== 'rgba(0, 0, 0, 0)' && c !== 'transparent') return c;
    }
    return getComputedStyle(document.body).backgroundColor || 'rgb(255,255,255)';
  };
  const px = (c) => c.match(/[\d.]+/g).slice(0, 3).map(Number);
  const lum = (c) => { const [r, g, b] = px(c).map(v => { v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
  const ratio = (a, b) => { const L1 = lum(a), L2 = lum(b);
    return Math.round(((Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05)) * 100) / 100; };
  for (const [k, v] of Object.entries(out)) {
    const dot = document.querySelector(`.room-item[data-alias="${k}"] .ri-live`);
    const back = bgOf(dot);
    const fore = v.bg !== 'rgba(0, 0, 0, 0)' ? v.bg : getComputedStyle(dot).borderTopColor;
    v.backdrop = back;
    v.contrast = ratio(fore, back);
  }
  return out;
};

const run = async (label, opts) => {
  const b = await chromium.launch();
  const ctx = await b.newContext(opts);
  const p = await ctx.newPage();
  await p.setContent(mkHTML(opts.__rail ?? 'data-rail="full"'), { waitUntil: 'load' });
  const res = await p.evaluate(probe);
  console.log('\n== ' + label + ' ==');
  for (const [k, v] of Object.entries(res)) console.log('  ' + k, JSON.stringify(v));
  await b.close();
  return res;
};

const A = await run('常规侧栏 1920×1080', { viewport: { width: 1920, height: 1080 } });
const B = await run('驾驶舱收起图标轨(无 data-rail) 1400×900',
  { viewport: { width: 1400, height: 900 }, __rail: '' });
const C = await run('reduce 动效 1920×1080', {
  viewport: { width: 1920, height: 1080 }, reducedMotion: 'reduce' });

let bad = 0;
const chk = (c, m) => { if (!c) { console.log('  [✗] ' + m); bad++; } else console.log('  [✓] ' + m); };
console.log('\n== 断言 ==');
chk(A['1001'].display !== 'none' && A['1001'].anim === 'pulse', '直播中 = 可见且脉冲');
chk(A['1001'].bg === 'rgb(15, 111, 92)', '直播中 = brand 绿(实测 ' + A['1001'].bg + ')');
chk(A['1002'].display === 'none', '未开播 = [hidden] 真正 display:none');
chk(A['1003'].display !== 'none' && A['1003'].anim === 'none', '未知 = 可见且静态');
chk(A['1003'].bg === 'rgba(0, 0, 0, 0)' && parseFloat(A['1003'].border) > 0, '未知 = 空心描边环');
chk(A['1004'].bg === A['1001'].bg, '选中行的绿点仍是绿(朱砂覆写已删除)');
chk(A['1001'].rowH === A['1002'].rowH && A['1002'].rowH === A['1003'].rowH,
    '三态条目高度一致 = 隐藏不改几何(实测 ' + A['1001'].rowH + 'px)');
chk(B['1001'].pos === 'absolute', '收起态规则确已生效(position:absolute,实测 ' + B['1001'].pos + ')');
chk(B['1002'].display === 'none', '收起图标轨下 [hidden] 压过 position:absolute');
chk(B['1001'].display !== 'none', '收起图标轨下直播中仍可见');
console.log('\n== 非文本对比度(WCAG 1.4.11 门槛 3:1)==');
for (const [k, v] of Object.entries(A))
  console.log('  ' + k + ' 前景/底=' + v.contrast + ':1  底色=' + v.backdrop);
chk(A['1001'].contrast >= 3, '直播中绿点对比度 ≥3:1(实测 ' + A['1001'].contrast + ')');
chk(A['1003'].contrast >= 3, '未知灰环对比度 ≥3:1(实测 ' + A['1003'].contrast + ')');
chk(C['1001'].anim === 'none', 'reduce 下脉冲退为静态');
chk(C['1001'].bg === 'rgb(15, 111, 92)', 'reduce 下仍保留绿色填充(信息不丢)');
chk(C['1003'].bg === 'rgba(0, 0, 0, 0)', 'reduce 下未知仍是空心 = 与直播中可区分');
console.log(bad ? '\nFAILED ' + bad : '\nALL OK');
process.exit(bad ? 1 : 0);
