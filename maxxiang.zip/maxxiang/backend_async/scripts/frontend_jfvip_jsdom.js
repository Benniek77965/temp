/* frontend_jfvip_jsdom.js — 九法VIP 前端整机冒烟(4.2.0)
   用法:项目根 `npm i jsdom` 后 `node backend_async/scripts/frontend_jfvip_jsdom.js`

   为什么必须有这一份:前面几轮只做了**语法检查**(new Function 解析)与纯逻辑自证,
   那两样都测不出运行时错误 —— SSE 的 UnboundLocalError 就是靠真跑才逮到的,
   前端同理。本脚本让交付版 index.html + app.js 在**真 DOM** 里原样执行,只桩网络。

   覆盖:
     · free 档:开通门出场 / 游戏入口隐藏 / **零数据请求**(最硬的一条)
     · basic 档:面板角标出场 / 推演锁态 / 命中率照常 / **掉档 VIP 快照必被拒**
       / 窗=0 时逐字节旧行为(不落地)/ 窗>0 时同档快照可回灌(4.4.0)
     · vip 档:一切照旧,无角标无锁态
     · 未启用(旧后端无 jf 字段):逐字节旧行为,tier 默认 vip
     · 档位卡与对比表按后端 plans/matrix 渲染
     · 全程零未捕获异常
*/
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
/* --js / --html:指向**混淆产物**做验收(与 frontend_reg_jsdom.js 同款约定)。
   缺省读仓库源码。部署前建议两者都跑一遍 —— 用户最终拿到的是产物,
   源码能跑不等于产物能跑(混淆器会重写标识符与字符串)。 */
const _ARGJ = process.argv.indexOf('--js');
const _ARGH = process.argv.indexOf('--html');
const html = fs.readFileSync(_ARGH > 0 ? process.argv[_ARGH + 1] : ROOT + '/index.html', 'utf8');
const _jsPath = _ARGJ > 0 ? process.argv[_ARGJ + 1] : ROOT + '/assets/app.js';
/* ★ 陈旧产物护栏(4.4.0):混淆构建**静默失败**时,--js 指向的产物仍是上一次的,
   本套件会照常跑完并给出一个看起来正常的数字 —— 实测在一次复审里连着骗过两次,
   其中一次差点让「特性不生效」的修复被判成"产物已验收"。
   产物比源码旧 = 构建没成功,直接拒跑。**一个测不出真相的验收比不验收更危险。** */
if (_ARGJ > 0) {
  const tp = fs.statSync(_jsPath).mtimeMs;
  const ts = fs.statSync(ROOT + '/assets/app.js').mtimeMs;
  if (tp < ts) {
    console.error(`✗ 产物 ${_jsPath} 比 assets/app.js 旧 ` +
                  `(${Math.round((ts - tp) / 1000)}s)—— 构建未成功或未重跑。`);
    console.error('  拒绝在陈旧产物上出具验收结论;请先重新构建。');
    process.exit(3);
  }
}
const appjs = fs.readFileSync(_jsPath, 'utf8');


let PASS = 0, FAIL = 0;
const A = (n, c, extra) => {
  console.log(`  [${c ? '✓' : '✗'}] ${n}${c ? '' : (extra ? '  → ' + extra : '')}`);
  if (c) PASS++; else { FAIL++; process.exitCode = 1; }
};
const sleep = ms => new Promise(r => setTimeout(r, ms));
/* seedSnap 与 history 桩共用同一格点基准 —— 两者必须落在同一条 50001ms 等差网格上,
   否则合并出来的是两段互不相干的历史,测不出真实行为。 */
const SEED_BASE = Math.round((Date.now() - 20 * 60 * 1000) / 50001) * 50001;

const PLANS = [
  { code: 'd3', name: '3 天', price: 18, jfHours: 72, ddHours: 72, tag: '' },
  { code: 'm1', name: '1 个月', price: 88, jfHours: 744, ddHours: 744, tag: '最多人选' },
  { code: 'm3', name: '3 个月', price: 188, jfHours: 2232, ddHours: 2232, tag: '最划算' },
];
const MATRIX = [
  { key: 'road', label: '出怪序列 / 战况 / 出怪规律', need: 'basic', basic: '本次 30 局起累计', vip: '满 24 小时' },
  // 4.4.0:窗>0 时后端 vip_matrix() 会把 road.basic 渲染成「在线累计,最长 H 小时」
  { key: 'pred', label: '灵机推演 · 下一局预测参考', need: 'vip', basic: '', vip: '主 2 码 + 防 2 码' },
  { key: 'game', label: '真实游戏 / 模拟游戏', need: 'basic', basic: '✓', vip: '✓' },
];

/* 起一个环境。jf=null 表示后端未启用 VIP 体系(旧后端形态)。 */
async function boot({ jf, seedSnap = false, contact = null }) {
  const errs = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => errs.push(String(e && e.message || e)));
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
                                url: 'http://localhost/', virtualConsole: vc });
  const w = dom.window;
  const NET = { urls: [], data: 0 };

  /* 预置"上一次是 **VIP** 时存下的满窗快照"。4.4.0 起这是本套件最硬的一条:
     basic 档必须拒绝它 —— 掉档回灌是唯一真实的绕过向量。
     用 v3 + tier:'vip' 才有意义:v2 会因版本不符被拒,那样测不出 tier 闸。
     另置一份 seedTier='basic' 形态(seedSnap==='basic')验证同档可回灌。 */
  /*  seedSnap 三形态,分别打三条不同的闸:
       true      掉档:快照 tier=vip,本机记录的上次档位=vip,当前 basic
                 → 第一道 pruneAllSnaps(档位变了)必须把它清掉
       'forged'  伪造:同样 tier=vip,但把本机 jfTier 改成 basic 骗过第一道
                 → 第二道 hydrate 的 tier 戳校验必须拒(并顺手删)
       'basic'   同档:tier=basic + 上次档位 basic
                 → 窗>0 时必须成功回灌;窗=0 时必须不回灌  */
  if (seedSnap) {
    const snapTier = seedSnap === 'basic' ? 'basic' : 'vip';
    const lastTier = (seedSnap === 'forged' || seedSnap === 'basic') ? 'basic' : 'vip';
    const base = SEED_BASE;                    // 20 分钟前起,落在任何窗内
    w.localStorage.setItem('jf2:jfTier@u7', lastTier);
    w.localStorage.setItem('jf2:snapIdx@u7', JSON.stringify({ '321': Date.now() }));
    w.localStorage.setItem('jf2:snap@u7:321', JSON.stringify({
      v: 3, t: Date.now(), tier: snapTier, profile: { alias: '321' },
      spells: [{ display_number: 1, spell_key: '土', spell_name: '御土术',
                 beast_name: '镇岳甲', multiplier: 10 }],
      b: base, r: '111111',
    }));
  }

  w.fetch = async (input, opt = {}) => {
    const url = typeof input === 'string' ? input : input.url;
    NET.urls.push(url);
    let body;
    if (url.startsWith('/api/auth/session')) {
      body = { ok: true, enabled: true, authed: true, pow: { enabled: false },
               user: { id: 7, userName: 'u7', dueTime: '2027-01-01T00:00:00', dueDays: 165,
                       tier: jf ? jf.tier : 'vip' },
               ...(jf ? { jf } : {}),
               /* 4.4.2 客服联系方式:**顶层 contact 段**,不在 jf 下面。
                  contact=null 即模拟「未配置 / 旧后端 / 本次请求不是直营主站」
                  —— 后端 cs_info() 在这三种情形下都不下发这个键。 */
               ...(contact ? { contact } : {}) };
    } else {
      // 除 /api/auth/* 外一律计为「数据请求」—— free 档必须为 0
      if (!url.startsWith('/api/auth/')) NET.data++;
      // 预置了快照就必须回一个同名房 —— 否则 dataBoot 在 alias 为空处提前 return,
      // 根本走不到 hydrateSnapshot,四条 4.4.0 断言会全部"假绿"(实测踩到)。
      if (url.startsWith('/api/live-rooms'))
        body = { ok: true, rooms: seedSnap ? [{ alias: '321', room_id: '321' }] : [] };
      else if (url.startsWith('/api/vip/')) body = { ok: true };
      else if (/\/api\/rooms\/[^/]+\/history/.test(url)) {
        /* 与真实后端同形:basic 档 history 被硬闸钳到少量局。
           本桩只回**最新 2 局**(落在 seedSnap 的同一格点上,构成真实的"新数据"),
           用来验证「回灌的历史会不会被这 2 局整段冲掉」。 */
        const base = SEED_BASE, R = 50001;
        body = { ok: true, rounds: [4, 5].map(i => ({
          round_id: base + i * R, display_number: 1, spell_key: '土',
          spell_name: '御土术', beast_name: '镇岳甲', multiplier: 10,
          start_time_ms: base + i * R, draw_time_ms: base + i * R + 40000 })) };
      }
      else body = { ok: true };
    }
    return { ok: true, status: 200, headers: { get: () => null },
             json: async () => body, text: async () => JSON.stringify(body) };
  };
  w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){} };
  w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
  w.PerformanceObserver = class { observe(){} disconnect(){} };
  w.matchMedia = q => ({ matches: false, media: q, addEventListener(){}, removeEventListener(){},
                         addListener(){}, removeListener(){} });
  w.scrollTo = () => {};
  w.Worker = class { postMessage(){} terminate(){} };
  w.navigator.sendBeacon = () => true;
  w.addEventListener('error', e => errs.push('window.error: ' + (e.message || '')));
  w.addEventListener('unhandledrejection', e => errs.push('unhandled: ' + (e.reason || '')));

  const sc = w.document.createElement('script');
  sc.textContent = appjs.replace(/^\s*export\s+/gm, '');
  w.document.body.appendChild(sc);
  await sleep(260);
  return { w, d: w.document, NET, errs };
}

(async () => {
  console.log('\n九法VIP 前端整机冒烟(真 DOM 执行)\n' + '─'.repeat(58));

  // ── free 档 ────────────────────────────────────────────────────────────
  {
    const { w, d, NET, errs } = await boot({
      jf: { enabled: true, tier: 'free', plans: PLANS, matrix: MATRIX,
            basicHistoryLimit: 30, basicPredWindow: 100, ddAlive: false } });
    console.log('\n[free 档]');
    const gate = d.getElementById('vipGate');
    A('开通门出场', gate && !gate.hidden);
    A('开通门为 free 模式(不可关)', gate && gate.dataset.mode === 'free');
    A('关闭按钮隐藏', d.getElementById('vipClose').hidden === true);
    A('**零数据请求**(最硬的一条)', NET.data === 0, `实际发了 ${NET.data} 个:` +
      NET.urls.filter(u => !u.startsWith('/api/auth/')).join(','));
    A('游戏入口已隐藏(真实)', d.getElementById('realGameOpen').hidden === true);
    A('游戏入口已隐藏(模拟)', d.getElementById('jiufaOpen').hidden === true);
    A('档位卡渲染 3 张', d.querySelectorAll('#vipPlans .vp').length === 3);
    /* ★ 赠送时长要说"1 个月 / 3 个月",不是"31 天 / 93 天" ——
       744h / 2232h 就是小叮当月卡/季卡的**定义值**,说月份是准确的,
       而零碎天数会让用户对不上"我买的是月卡"。 */
    const gifts = [...d.querySelectorAll('#vipPlans .vp-gift')].map(x => x.textContent);
    A('赠送时长用月份而非零碎天数',
      gifts.some(g => /1 个月/.test(g)) && gifts.some(g => /3 个月/.test(g)),
      gifts.join(' | '));
    A('不出现 31 天 / 93 天', !gifts.some(g => /31 天|93 天/.test(g)), gifts.join(' | '));
    A('3 天档仍按天显示', gifts.some(g => /3 天/.test(g)), gifts.join(' | '));
    A('卡密输入框无格式噪音',
      d.getElementById('vipCardInput').placeholder === '请输入卡密',
      d.getElementById('vipCardInput').placeholder);
    A('中间档默认选中', !!d.querySelector('#vipPlans .vp.is-on'));
    A('对比表在 free 档不显示(还没有"当前"可比)',
      d.getElementById('vipCompare').hidden === true);
    const dis = d.querySelector('.vip-disclaim');
    A('付费页写明仅供参考 / 不保证命中', !!dis && /仅供参考/.test(dis.textContent)
      && /不保证命中/.test(dis.textContent), dis ? dis.textContent : '缺该元素');
    A('body 标记 free', d.body.dataset.vipGate === 'free');
    /* ★ 4.4.1 直营基线:后端**没下发** jf.site(旧后端形态)时,在线扫码整条链
       必须逐字节维持旧行为 —— 这是本特性最重要的一条向后兼容断言。 */
    A('未下发 site 时「立即开通」照常在场(逐字节旧行为)',
      d.getElementById('vipBuyBtn').hidden === false);
    A('未下发 site 时档位卡照常在场', d.getElementById('vipPlans').hidden === false);
    const cs0 = d.getElementById('vipCsHint');
    /* ★ 新契约:客服提示**跟随卡密表单的展开态**。有档位可选时表单默认收起,
       这一句也随之收起 —— 用户还没表示要用卡密,不替他假设「没有卡密?」这个问题。
       内容仍然是**写好的**(只是不可见),点开即在,不重算。 */
    A('有第二条路时客服提示随表单收起', !!cs0 && cs0.hidden === true,
      cs0 ? 'hidden=' + cs0.hidden : '元素缺失');
    A('收起态下内容已就位(点开即在,不重算)',
      !!cs0 && /联系客服购买/.test(cs0.textContent), cs0 ? cs0.textContent : '元素缺失');
    A('直营站文案不谎称「仅支持卡密」', !!cs0 && !/仅支持卡密/.test(cs0.textContent),
      cs0 ? cs0.textContent : '');
    /* 点「我有卡密」⇒ 表单与提示同开(同开同收是本次契约的核心) */
    d.getElementById('vipCardBtn').click();
    A('展开后客服提示同步出场', cs0.hidden === false, 'hidden=' + cs0.hidden);
    A('再点收起 ⇒ 提示同步收起',
      (d.getElementById('vipCardBtn').click(), cs0.hidden === true), 'hidden=' + cs0.hidden);
    /* ★ 有档位可选时卡密表单必须**仍然收起**(逐字节旧行为)—— 与「立即开通」
       并列时默认展开会把主 CTA 往下挤,320×568 的首屏预算经不起。 */
    A('有第二条路时卡密表单仍收起', d.getElementById('vipCardForm').hidden === true);
    A('收起态 aria-expanded=false',
      d.getElementById('vipCardBtn').getAttribute('aria-expanded') === 'false');
    // ★ 4.2.1:free 档整个壳被 pointer-events:none 禁用,顶栏「退出」点不到 ——
    //   门内**必须**有退出出口,否则用错账号登进来的人被彻底锁死在本页。
    const lo = d.getElementById('vipLogout');
    A('门内有退出出口(free 档唯一出路)', !!lo && lo.hidden === false,
      lo ? 'hidden=' + lo.hidden : '元素缺失');
    A('退出出口文案含「换个账号」', !!lo && /换个账号/.test(lo.textContent));
    const st = d.getElementById('vipStatus');
    A('状态条出场并说明「为什么看不到数据」', !!st && st.hidden === false
      && /小叮当/.test(st.textContent), st ? st.textContent : '缺失');
    /* ★ free 档把两个游戏入口 hidden=true 了。开通成功后 onVipGranted → dataBoot
       会再走一遍 —— 若没人把它们置回 false,**刚付完钱的用户反而看不到
       「真实游戏 / 模拟游戏」**(原先只有置 true 没有置 false)。 */
    /* 不用 w.eval 调内部标识符 —— 混淆产物会重命名,那样只能验源码版
       (上一轮管理台已踩过同一个坑)。改为**走真实路径**:另起一个 vip 档
       实例,验证同一份 DOM 在 vip 档下入口是可见的 —— 等价于"升级后恢复",
       且源码/产物两版都成立。 */
    const up = await boot({ jf: { enabled: true, tier: 'vip', plans: PLANS, matrix: MATRIX,
                                  basicHistoryLimit: 30, basicPredWindow: 100, ddAlive: true,
                                  jfVipUntil: '2026-12-01T00:00:00', jfVipDays: 132 } });
    A('升级后游戏入口恢复(真实)', up.d.getElementById('realGameOpen').hidden === false);
    A('升级后游戏入口恢复(模拟)', up.d.getElementById('jiufaOpen').hidden === false);
    up.w.close();
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }

  // ── basic 档 ───────────────────────────────────────────────────────────
  {
    const { w, d, NET, errs } = await boot({
      jf: { enabled: true, tier: 'basic', plans: PLANS, matrix: MATRIX,
            basicHistoryLimit: 30, basicPredWindow: 100, ddAlive: true },
      seedSnap: true });
    console.log('\n[basic 档]');
    A('开通门不拦截(应用照常可用)', d.getElementById('vipGate').hidden === true);
    A('身份牌第二行出场', d.getElementById('ucVip').hidden === false);
    A('第二行文案=未开通', /未开通/.test(d.getElementById('ucVip').textContent));
    A('小叮当行明确标注归属', /小叮当/.test(d.getElementById('ucDue').textContent),
      d.getElementById('ucDue').textContent);
    A('顶栏「开通」按钮出场', d.getElementById('ucBuy').hidden === false);
    const note = d.getElementById('vipNote-road');
    A('序列角标出场', note && note.hidden === false);
    // 本块的 jf 不含 basicOnlineH ⇒ JF.onlineH=0 ⇒ 4.4.0 特性整体不生效,
    // 一切必须与 4.3.x **逐字节相同**。这条是「新特性默认不打扰旧部署」的守卫。
    A('窗未下发时角标仍是 30 局口径(旧行为)',
      note && /30/.test(note.textContent), note && note.textContent);
    // ★ 4.2.1:角标做成可点 —— 用户在哪看到限制就能在哪行动(零新增 UI 面积的可发现性)
    A('角标是可点按钮(不是死文字)', note && note.tagName === 'BUTTON', note && note.tagName);
    note.click(); await sleep(80);
    A('点角标即进升级页', d.getElementById('vipGate').hidden === false
      && d.getElementById('vipGate').dataset.mode === 'upsell');
    d.getElementById('vipClose').click(); await sleep(40);
    A('出怪规律角标出场', d.getElementById('vipNote-census').hidden === false);
    A('推演锁态条出场', d.getElementById('predVipBar').hidden === false);
    A('**掉档已清快照**(否则 VIP 满窗会被 basic 回灌)',
      w.localStorage.getItem('jf2:snap@u7:321') === null);
    A('游戏入口保留(basic 档明示权益)', d.getElementById('realGameOpen').hidden === false);
    // 主动点开升级页 → 对比表应出现
    d.getElementById('ucBuy').click();
    await sleep(60);
    A('点开通 → 升级页(可关)', d.getElementById('vipGate').dataset.mode === 'upsell');
    A('对比表出场', d.getElementById('vipCompare').hidden === false);
    A('对比表行数=矩阵条目数',
      d.querySelectorAll('#vipCompareBody .vc-row').length === MATRIX.length);
    A('VIP 专属项显示锁', /vc-lock/.test(d.getElementById('vipCompareBody').innerHTML));
    const cmp = d.getElementById('vipCompareBody').textContent;
    A('推演行文案无歧义(不出现「主2防2」)', !cmp.includes('主2防2'), cmp.slice(0, 80));
    A('推演行用项目原生「码」表述', cmp.includes('码'), cmp.slice(0, 80));
    A('推演能力名体现「预测参考」性质(不说成确定的号)', cmp.includes('预测参考'), cmp.slice(0, 80));
    A('对比表里灵机推演只占一行',
      (cmp.match(/灵机推演/g) || []).length === 1,
      String((cmp.match(/灵机推演/g) || []).length));
    d.getElementById('vipClose').click();
    await sleep(40);
    A('升级页可关闭', d.getElementById('vipGate').hidden === true);
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }


  // ── 4.4.0:basic 档「在线累计窗」三道闸 ────────────────────────────────
  {
    const JFB = h => ({ enabled: true, tier: 'basic', plans: PLANS, matrix: MATRIX,
                        basicHistoryLimit: 30, basicPredWindow: 100, ddAlive: true,
                        basicOnlineH: h });
    console.log('\n[4.4.0 · basic 在线累计窗]');

    // ① 窗=0(显式关闭)→ 与旧行为逐字节相同:同档快照也不回灌
    {
      const { w, d, errs } = await boot({ jf: JFB(0), seedSnap: 'basic' });
      A('窗=0:同档快照也不回灌(逐字节旧行为)',
        !w.__jfHydrated, String(w.__jfHydrated));
      const note = d.getElementById('vipNote-road');
      A('窗=0:角标维持「本次从 N 局起累计」',
        note && /本次从/.test(note.textContent), note && note.textContent);
      A('窗=0:零未捕获异常', errs.length === 0, errs.join(' | '));
      w.close();
    }

    // ② 窗>0 + 同档快照 → 必须回灌(本特性的正面用例)
    {
      const { w, d, errs } = await boot({ jf: JFB(24), seedSnap: 'basic' });
      A('窗>0:同档快照成功回灌(刷新不再清零)',
        w.__jfHydrated === 6, '回灌局数=' + w.__jfHydrated);
      const note = d.getElementById('vipNote-road');
      A('窗>0:角标改口径为「在线累计」',
        note && /在线累计/.test(note.textContent), note && note.textContent);
      A('窗>0:角标写明窗口时长', note && /24/.test(note.textContent), note && note.textContent);
      A('窗>0:零未捕获异常', errs.length === 0, errs.join(' | '));
      w.close();
    }

    // ②a ★ 回灌的历史必须**活过 loadRoom**。applyRoomData 是「换房重锤」,
    //     它整体替换 S.hist;若不并回,回灌成果会在一个 RTT 后被 history 的
    //     少量局整段冲掉,紧接着 saveSnapshot() 还会用这几局覆盖本机满窗快照 ——
    //     特性不但不生效,还会自毁。本用例在 loadRoom **完成之后**取证。
    {
      const { w, errs } = await boot({ jf: JFB(24), seedSnap: 'basic' });
      await sleep(320);                       // 等 loadRoom 的三个并发请求全部落地
      const n = w.__jf && w.__jf.S ? w.__jf.S.hist.length : -1;
      A('★回灌历史活过 loadRoom(与新数据取并集,而非被冲掉)',
        n >= 6, 'loadRoom 后 S.hist=' + n + ' 局(种子 6 + 新 2,并集应 ≥6)');
      const snap = JSON.parse(w.localStorage.getItem('jf2:snap@u7:321') || 'null');
      A('★落地快照未被少量新局覆盖',
        snap && typeof snap.r === 'string' && snap.r.replace(/0/g, '').length >= 6,
        '快照号位串=' + (snap && snap.r));
      A('活过 loadRoom:零未捕获异常', errs.length === 0, errs.join(' | '));
      w.close();
    }

    // ②c 角标必须随**已累计量**切换口径:对已攒满的用户说「VIP 直接满 24 小时」
    //     几乎等于没说,而他此刻真正缺的是「下一局预测 / 按日回看」。
    //     用极小窗(0.01h=36s)让 seedSnap 的 6 局(跨 250s)立刻算作"已近满"。
    {
      const { w, d, errs } = await boot({ jf: JFB(0.01), seedSnap: 'basic' });
      await sleep(320);
      const note = d.getElementById('vipNote-road');
      A('★已近满窗时角标改述「仍然缺什么」(不再空谈满 24 小时)',
        note && /下一局预测/.test(note.textContent) && !/直接满/.test(note.textContent),
        note && note.textContent);
      A('近满:零未捕获异常', errs.length === 0, errs.join(' | '));
      w.close();
    }

    // ②b 窗被**调小**后,旧快照内容必须按**当前**窗口再钳一次
    //     (窗口是热更项;不钳等于运维调窗没落地,旧值继续生效)
    {
      const { w, errs } = await boot({ jf: JFB(0.01), seedSnap: 'basic' });  // 36s 窗
      A('★调小窗口后旧快照按新窗钳制(不是整份放行)',
        w.__jfHydrated > 0 && w.__jfHydrated < 6, '回灌局数=' + w.__jfHydrated);
      A('调窗:零未捕获异常', errs.length === 0, errs.join(' | '));
      w.close();
    }

    // ③ 窗>0 + **掉档**快照(tier=vip)→ 第一道 pruneAllSnaps 清场
    {
      const { w, errs } = await boot({ jf: JFB(24), seedSnap: true });
      await sleep(320);
      /* 判据不是「键为 null」—— 清场后 loadRoom 会**合法地**写一份新的 basic 档
         快照(那是本次会话自己看到的 2 局)。真正的不变量是:**VIP 期的内容
         一个字节都不许留下**。故验 tier 戳与局数,而不是键的有无。
         (初版写成 key===null,在 history 桩回真数据后立刻变假红 —— 说明它
          此前一直是在「后端不回数据」的失真环境里空转。) */
      const snap = JSON.parse(w.localStorage.getItem('jf2:snap@u7:321') || 'null');
      A('★掉档:VIP 满窗内容零残留(第一道清场)',
        !snap || (snap.tier === 'basic' && snap.r.replace(/0/g, '').length <= 2),
        snap ? `tier=${snap.tier} 串=${snap.r}` : '(已清空)');
      A('掉档:未发生回灌', !w.__jfHydrated, String(w.__jfHydrated));
      A('掉档:零未捕获异常', errs.length === 0, errs.join(' | '));
      w.close();
    }

    // ④ 窗>0 + 伪造(手改 jfTier 骗过第一道)→ 第二道 tier 戳必须拒
    {
      const { w, errs } = await boot({ jf: JFB(24), seedSnap: 'forged' });
      await sleep(320);
      A('★伪造 jfTier 绕过第一道后,tier 戳仍拒(第二道)',
        !w.__jfHydrated, String(w.__jfHydrated));
      const fsnap = JSON.parse(w.localStorage.getItem('jf2:snap@u7:321') || 'null');
      A('伪造:VIP 期内容零残留(被拒即删,后续只落本次会话自己的局)',
        !fsnap || (fsnap.tier === 'basic' && fsnap.r.replace(/0/g, '').length <= 2),
        fsnap ? `tier=${fsnap.tier} 串=${fsnap.r}` : '(已清空)');
      A('伪造:零未捕获异常', errs.length === 0, errs.join(' | '));
      w.close();
    }
  }

  // ── vip 档 ─────────────────────────────────────────────────────────────
  {
    const { w, d, errs } = await boot({
      jf: { enabled: true, tier: 'vip', plans: PLANS, matrix: MATRIX,
            basicHistoryLimit: 30, basicPredWindow: 100, ddAlive: true,
            jfVipUntil: '2026-12-01T00:00:00', jfVipDays: 132 } });
    console.log('\n[vip 档]');
    A('无开通门', d.getElementById('vipGate').hidden === true);
    A('身份牌显示 VIP 剩余天数', /剩 132 天/.test(d.getElementById('ucVip').textContent),
      d.getElementById('ucVip').textContent);
    // ★ 4.2.1:VIP 用户必须**有**续费入口(此前是隐藏的 —— 已付费用户想续费没门)
    const buy = d.getElementById('ucBuy');
    A('续费入口可见(不是隐藏)', buy.hidden === false);
    A('按钮文案=续费(对已付费用户说「开通」是错的)', buy.textContent === '续费',
      buy.textContent);
    buy.click(); await sleep(80);
    A('点开进入「续费」形态', d.getElementById('vipGate').dataset.mode === 'renew',
      d.getElementById('vipGate').dataset.mode);
    A('标题=续费九法VIP', d.getElementById('vipTitle').textContent.includes('续费'));
    A('讲明从到期日顺延', /顺延/.test(d.getElementById('vipLede').textContent),
      d.getElementById('vipLede').textContent);
    A('续费页不显示对比表(已全有,无信息量)',
      d.getElementById('vipCompare').hidden === true);
    // ★ 4.2.1:到期日是续费决策的唯一依据,必须在**标题正下方**的状态条里,
    //   而不是埋在页脚 11.5px 灰字(那个位置用户不会看)
    const vs = d.getElementById('vipStatus');
    A('状态条出场(标题正下方)', !!vs && vs.hidden === false);
    A('状态条显示剩余天数', !!vs && /剩 \d+ 天|今日到期/.test(vs.textContent),
      vs ? vs.textContent : '缺失');
    A('状态条显示到期日', !!vs && /到期 \d{4}-/.test(vs.textContent),
      vs ? vs.textContent : '缺失');
    A('页脚只留账号(到期信息不与状态条重复)',
      /当前账号/.test(d.getElementById('vipFoot').textContent)
      && !/剩 \d+ 天/.test(d.getElementById('vipFoot').textContent),
      d.getElementById('vipFoot').textContent);
    d.getElementById('vipClose').click(); await sleep(40);
    A('无序列角标', d.getElementById('vipNote-road').hidden === true);
    A('无推演锁态条', d.getElementById('predVipBar').hidden === true);
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }

  // ── 4.4.1 代理镜像站(jf.site.pay=false)────────────────────────────────
  {
    const { w, d, errs } = await boot({
      jf: { enabled: true, tier: 'free', plans: PLANS, matrix: MATRIX,
            basicHistoryLimit: 30, basicPredWindow: 100, ddAlive: false,
            site: { host: 'a.agent.example', direct: false, pay: false, enforced: true } } });
    console.log('\n[代理镜像站 · 隐藏在线扫码]');
    const gate = d.getElementById('vipGate');
    A('开通门照常出场', gate && !gate.hidden);
    A('「立即开通」已退场', d.getElementById('vipBuyBtn').hidden === true);
    A('档位价格卡已退场', d.getElementById('vipPlans').hidden === true);
    A('档位卡不留死 DOM', d.querySelectorAll('#vipPlans .vp').length === 0);
    A('「我有卡密」仍在场(镜像站唯一开通路径)',
      d.getElementById('vipCardBtn').hidden === false);
    const cs = d.getElementById('vipCsHint');
    A('「联系客服购买」提示出场', !!cs && cs.hidden === false
      && /联系客服购买/.test(cs.textContent), cs ? 'hidden=' + cs.hidden : '元素缺失');
    A('如实交代本站仅支持卡密', !!cs && /仅支持卡密/.test(cs.textContent),
      cs ? cs.textContent : '');
    /* ★ 支付弹层必须**够不到**:主 CTA 已退场 ⇒ openPay 无 UI 触发者。
       (真闸在后端 /api/vip/order/create,前端只负责不摆入口。) */
    A('支付弹层未被拉起', d.getElementById('payModal').hidden === true);
    /* ★ 这是全项目**第一个**「弹层内隐藏的可聚焦按钮」。openModal 只对 disabled
       做了回落,对 hidden 元素调 focus() 是静默空操作 —— 若 showVipGate 忘了换
       落焦点目标,整层开起来没有焦点,键盘用户无处着手且不会有任何报错。 */
    /* ★ 只剩卡密一条路 ⇒ 输入框默认就该在场,不该再要一次点击 */
    A('卡密表单默认展开', d.getElementById('vipCardForm').hidden === false);
    A('展开态 aria-expanded=true(读屏契约)',
      d.getElementById('vipCardBtn').getAttribute('aria-expanded') === 'true');
    A('输入框可及名称不靠 placeholder',
      d.getElementById('vipCardInput').getAttribute('aria-label') === '卡密');
    /* 焦点**不落输入框**:free 档的门是自动弹出的,落输入框会顶起安卓软键盘 */
    A('落焦点交给「我有卡密」而非已退场的「立即开通」',
      d.activeElement === d.getElementById('vipCardBtn'),
      d.activeElement ? (d.activeElement.id || d.activeElement.tagName) : 'null');
    /* 免责声明是关于产品本身的真话,与用哪条路开通无关 —— 不得随扫码一起消失 */
    const dis2 = d.querySelector('.vip-disclaim');
    A('免责声明保留(与支付方式无关的真话)',
      !!dis2 && dis2.hidden === false && /仅供参考/.test(dis2.textContent));
    A('能力对照仍在场(讲清买到什么)',
      d.querySelector('.vip-feats') && d.querySelectorAll('.vip-feats .vf').length === 4);
    /* ★ 4.9.9:客服提示改为随卡密表单同开同收,而**这里是唯一例外**。
       镜像站的「立即开通」与档位卡都已退场,这一句既是唯一的购买去处,也是
       「为什么这里没有立即开通」的唯一交代。若让它跟着折叠一起消失,用户点一下
       「我有卡密」就会拿到一个没有任何去处、也不解释缺口的门 —— 那正是 §12.6
       立这句话时点名要避免的「让用户对着一个缺口发懵」。
       本钉挡的就是把 setVipCardOpen 里那句 `|| vipCardOnly()` 顺手简化掉。
       (放在全部落焦点断言**之后**:click 会移动 activeElement。) */
    d.getElementById('vipCardBtn').click();
    A('收起卡密表单后客服提示**仍在**(唯一去处不随折叠消失)',
      cs.hidden === false, 'hidden=' + cs.hidden);
    A('收起后仍如实交代仅支持卡密', /仅支持卡密/.test(cs.textContent), cs.textContent);
    A('按钮自身的折叠态照常同步',
      d.getElementById('vipCardForm').hidden === true
      && d.getElementById('vipCardBtn').getAttribute('aria-expanded') === 'false');
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }

  // ── 4.4.1 直营站但**档位表为空**:能走通的同样只剩卡密 ────────────────────
  {
    const { w, d, errs } = await boot({
      jf: { enabled: true, tier: 'free', plans: [], matrix: MATRIX,
            basicHistoryLimit: 30, basicPredWindow: 100, ddAlive: false } });
    console.log('\n[直营站 · 档位表为空]');
    A('开通门照常出场', !d.getElementById('vipGate').hidden);
    /* 「立即开通」在直营站是**置灰而非退场**(它是站点能力的如实反映:
       在线支付这条路本身还在,只是没档位可买)—— 与镜像站的"整个退场"不同。 */
    A('「立即开通」置灰而非退场',
      d.getElementById('vipBuyBtn').hidden === false
      && d.getElementById('vipBuyBtn').disabled === true);
    A('档位区如实说明未配置',
      /档位暂未配置/.test(d.getElementById('vipPlans').textContent));
    A('卡密表单默认展开(唯一能走通的路)',
      d.getElementById('vipCardForm').hidden === false);
    A('展开态 aria-expanded=true',
      d.getElementById('vipCardBtn').getAttribute('aria-expanded') === 'true');
    /* 此情形下在线支付名义上仍在(只是没档位),故文案不该改口说「本站仅支持卡密」 */
    const cs2 = d.getElementById('vipCsHint');
    A('客服提示出场', !!cs2 && cs2.hidden === false && /联系客服购买/.test(cs2.textContent));
    A('不谎称「本站仅支持卡密」', !!cs2 && !/仅支持卡密/.test(cs2.textContent),
      cs2 ? cs2.textContent : '');
    /* ★「立即开通」在本情形下是 disabled,openModal 的 disabled 回落会去
       layer.querySelector(...) 抓层内第一个可聚焦元素 —— 而表单现在**可见**了,
       若回落抓到输入框,自动弹出的门会在安卓上直接顶起软键盘。必须显式钉住。 */
    A('落焦点显式交给「我有卡密」(不靠回落选择器的文档顺序)',
      d.activeElement === d.getElementById('vipCardBtn'),
      d.activeElement ? (d.activeElement.id || d.activeElement.tagName) : 'null');
    A('落焦点不在卡密输入框(免自动弹门顶起软键盘)',
      d.activeElement !== d.getElementById('vipCardInput'),
      d.activeElement ? (d.activeElement.id || d.activeElement.tagName) : 'null');
    /* ★ 4.9.9:同镜像站那条 —— 此刻「立即开通」是 disabled、档位区只有一句
       「档位暂未配置」,能走通的只剩卡密,客服提示同样是唯一去处,不得随折叠消失。 */
    d.getElementById('vipCardBtn').click();
    A('收起卡密表单后客服提示**仍在**(唯一去处不随折叠消失)',
      cs2.hidden === false, 'hidden=' + cs2.hidden);
    A('收起后仍不谎称「本站仅支持卡密」', !/仅支持卡密/.test(cs2.textContent), cs2.textContent);
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }

  // ── 未启用(旧后端形态)────────────────────────────────────────────────
  {
    const { w, d, errs } = await boot({ jf: null });
    console.log('\n[VIP 体系未启用 / 旧后端]');
    A('无开通门', d.getElementById('vipGate').hidden === true);
    A('身份牌第二行恒隐藏', d.getElementById('ucVip').hidden === true);
    A('无「开通」按钮', d.getElementById('ucBuy').hidden === true);
    A('无角标', d.getElementById('vipNote-road').hidden === true);
    A('小叮当行**不加**前缀(逐字节旧文案)',
      !/小叮当/.test(d.getElementById('ucDue').textContent),
      d.getElementById('ucDue').textContent);
    A('游戏入口正常', d.getElementById('realGameOpen').hidden === false);
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }

  // ── 4.4.2 客服联系方式(直营主站 · 号码 + 合法链接)────────────────────────
  {
    const { w, d, errs } = await boot({
      jf: { enabled: true, tier: 'free', plans: PLANS, matrix: MATRIX,
            basicHistoryLimit: 30, basicPredWindow: 100, ddAlive: false },
      contact: { label: '客服QQ', value: '800123456',
                 url: 'https://kf.example.com/chat', note: '服务时间 09:00-24:00' } });
    console.log('\n[4.4.2 客服联系方式 · 直营主站]');
    /* ★ 落焦点断言考察的是**开层瞬间**的状态,必须在任何交互之前取样 ——
       下面为了看客服提示要点开「我有卡密」(它会把焦点移进卡密输入框),
       先把开层落点记下来,断言仍按原意校验 showVipGate 的落焦点。 */
    const focus0 = d.activeElement;
    /* 新契约:提示跟随卡密表单展开态 ⇒ 断言前先点开「我有卡密」。
       (本组用例都是直营站 + 有档位 ⇒ 默认收起) */
    d.getElementById('vipCardBtn').click();
    const cs = d.getElementById('vipCsHint');
    A('客服提示出场', !!cs && cs.hidden === false);
    /* ★ 首句必须逐字未动 —— 本套件其它用例按字面钉着它,联系方式是**追加**不是改写 */
    A('首句逐字保留', /没有卡密\?可联系客服购买/.test(cs.textContent), cs.textContent);
    A('不谎称「本站仅支持卡密」', !/仅支持卡密/.test(cs.textContent));
    A('渠道名出场', /客服QQ/.test(cs.textContent), cs.textContent);
    A('号码出场', /800123456/.test(cs.textContent), cs.textContent);
    A('备注出场', /09:00-24:00/.test(cs.textContent), cs.textContent);
    const btn = cs.querySelector('.vip-cs-copy');
    A('复制按钮是真 <button>(键盘可达)', !!btn && btn.tagName === 'BUTTON');
    A('复制按钮 type=button(不会误提交卡密表单)', !!btn && btn.type === 'button');
    A('复制按钮可及名称自带上下文(不是光秃秃一个「复制」)',
      !!btn && /800123456/.test(btn.getAttribute('aria-label') || ''),
      btn ? btn.getAttribute('aria-label') : '缺按钮');
    const a = cs.querySelector('.vip-cs-link');
    A('合法 https 链接渲染成 <a>', !!a && a.getAttribute('href') === 'https://kf.example.com/chat');
    A('新窗链接带 rel=noopener', !!a && /noopener/.test(a.getAttribute('rel') || ''),
      a ? a.getAttribute('rel') : '缺链接');
    /* ★ 本块给弹层新增了一个可聚焦按钮(复制)。落焦点必须**仍然**由 showVipGate
       显式指定,不能漂到新按钮上 —— 这里 plans 非空且 payOn ⇒ cardOnly=false
       ⇒ 主 CTA 是「立即开通」。若哪天有人把落焦点改成靠 openModal 的选择器回落,
       复制按钮就会把焦点抢走(它在 DOM 里排在更后面但可聚焦),这条当场变红。 */
    A('落焦点仍是主 CTA「立即开通」',
      focus0 === d.getElementById('vipBuyBtn'),
      focus0 ? (focus0.id || focus0.className) : 'null');
    A('落焦点没被新增的复制按钮抢走', focus0 !== btn,
      focus0 ? (focus0.id || focus0.className) : 'null');
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }

  // ── 4.4.2 未配置 / 镜像站不下发 ⇒ 逐字节 4.4.1 ────────────────────────────
  {
    const { w, d, errs } = await boot({
      jf: { enabled: true, tier: 'free', plans: PLANS, matrix: MATRIX,
            basicHistoryLimit: 30, basicPredWindow: 100, ddAlive: false } });
    console.log('\n[4.4.2 未下发 contact · 逐字节旧行为]');
    /* 新契约:提示跟随卡密表单展开态 ⇒ 断言前先点开「我有卡密」。
       (本组用例都是直营站 + 有档位 ⇒ 默认收起) */
    d.getElementById('vipCardBtn').click();
    const cs = d.getElementById('vipCsHint');
    A('提示照常出场', !!cs && cs.hidden === false && /联系客服购买/.test(cs.textContent));
    A('不出现联系方式行', !cs.querySelector('.vip-cs-line'));
    A('不出现复制按钮', !cs.querySelector('.vip-cs-copy'));
    A('不出现链接', !cs.querySelector('a'));
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }

  // ── 4.4.2 注入面:配置值一律落 textContent,且 href 过白名单 ────────────────
  {
    const evil = '<img src=x onerror="window.__pwned=1">';
    const { w, d, errs } = await boot({
      jf: { enabled: true, tier: 'free', plans: PLANS, matrix: MATRIX,
            basicHistoryLimit: 30, basicPredWindow: 100, ddAlive: false },
      contact: { label: evil, value: '"><script>window.__pwned=1</script>',
                 url: 'javascript:window.__pwned=1', note: evil } });
    console.log('\n[4.4.2 注入面 · 配置值不得成为标记]');
    /* 新契约:提示跟随卡密表单展开态 ⇒ 断言前先点开「我有卡密」。
       (本组用例都是直营站 + 有档位 ⇒ 默认收起) */
    d.getElementById('vipCardBtn').click();
    const cs = d.getElementById('vipCsHint');
    /* ★ 4.4.1 在那一行留过原话:「将来若要把文案改成可配置项,这一行必须同步改回
       textContent + esc()」。这三条就是那句话的机器保证。 */
    A('没有被注入的元素(img/script 一个都没有)',
      cs.querySelectorAll('img,script,iframe').length === 0,
      cs.innerHTML.slice(0, 160));
    A('注入串原样落在文本里(证明走的是 textContent)',
      cs.textContent.indexOf('<img src=x') >= 0, cs.textContent.slice(0, 120));
    A('全局未被污染', w.__pwned === undefined);
    /* ★ href="javascript:…" 里没有任何需要 HTML 转义的字符 —— esc() 挡不住它,
       只有白名单挡得住。后端已经丢了一次,前端这一道是纵深。 */
    A('javascript: 链接不得渲染成 <a>', !cs.querySelector('a'),
      cs.querySelector('a') ? cs.querySelector('a').getAttribute('href') : '');
    A('首句仍然完好', /没有卡密\?可联系客服购买/.test(cs.textContent));
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }

  // ── 4.4.2 只有链接、没有号码:链接文本用渠道名,且不出现空的复制按钮 ────────
  {
    const { w, d, errs } = await boot({
      jf: { enabled: true, tier: 'free', plans: PLANS, matrix: MATRIX,
            basicHistoryLimit: 30, basicPredWindow: 100, ddAlive: false },
      contact: { label: '在线客服', url: 'https://kf.example.com/chat' } });
    console.log('\n[4.4.2 只配链接]');
    /* 新契约:提示跟随卡密表单展开态 ⇒ 断言前先点开「我有卡密」。
       (本组用例都是直营站 + 有档位 ⇒ 默认收起) */
    d.getElementById('vipCardBtn').click();
    const cs = d.getElementById('vipCsHint');
    A('不出现复制按钮(没有可复制的东西 ⇒ 不摆死控件)', !cs.querySelector('.vip-cs-copy'));
    const a = cs.querySelector('.vip-cs-link');
    A('链接在场且用渠道名', !!a && a.textContent === '在线客服', a ? a.textContent : '缺链接');
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }

  console.log('\n' + '─'.repeat(58));
  console.log(`九法VIP 前端冒烟:${PASS} 通过 / ${FAIL} 失败`);
  if (!FAIL) console.log('✓ 三档行为在真 DOM 中整机成立,且未启用时逐字节旧行为');
})();
