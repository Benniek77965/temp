/* 用法:项目根 `npm i jsdom` 后 `node backend_async/scripts/frontend_reg_jsdom.js`(Node ≥20)。

   注册系统(4.0.0)前端整机集成冒烟:交付版 index.html + app.js 在 jsdom 真 DOM
   中原样执行,仅桩网络。覆盖:
     · 入口可见性(session.reg.mode 驱动;off / 旧后端无字段 → 恒隐藏)
     · 登录态 ⇄ 注册态切换、invite 模式的邀请码字段显隐
     · 字段级即时校验(用户名长度与字符集、口令 5–16 位无组合限制、两次不一致;
       4.0.6:用户名字符集 [A-Za-z0-9] —— 中文/emoji/全角字母/连字符就地拦下、
       纯数字放行;格式必败邀请码亦就地拦下,均不发请求、不烧
       PoW 与 R1 配额,且格式拦截自愈 invite→open 热切;另含 jfInviteNorm 源码级规格对拍,硬失败不计入计数)
     · **完整提交链**:取挑战 → powAnswer(主线程)→ Worker 纯 JS SHA-256 穷举
       → POST /api/auth/register(校验载荷里 nonce 真能过服务端同款校验)
     · 蜜罐字段随载荷提交且真人路径恒空
     · autoLogin 二分:true → reload;false → 成功卡 + 开通指引
     · 错误呈现(name_taken / throttled 带分钟数)

   注:jsdom 无 Worker 实现 —— 用一枚**真跑同一段 Worker 源码**的替身(从 app.js
   抠出的字符串在同进程 eval),既验证了 Worker 源码本身可执行,又能同步驱动。 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
const html = fs.readFileSync(ROOT + '/index.html', 'utf8');
const JS_ARG = process.argv.indexOf('--js');
const JS_PATH = JS_ARG > 0 ? process.argv[JS_ARG + 1] : ROOT + '/assets/app.js';
const appjs = fs.readFileSync(JS_PATH, 'utf8');
const IS_OB = JS_ARG > 0;   // 混淆产物:标记注释已被剥,Worker 源码改从运行期取

let PASS = 0, FAIL = 0;
const A = (n, c) => { console.log(`  [${c ? '✓' : '✗'}] ${n}`); if (c) PASS++; else { FAIL++; process.exitCode = 1; } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* 服务端同款校验(与 app/userauth.py::reg_pow_check 同口径),用于验证前端交上来的
   nonce 是**真解**而不是糊弄 —— 前后端在这里必须严丝合缝。 */
function leadZeroBits(buf) {
  let n = 0;
  for (const b of buf) { if (b === 0) { n += 8; continue; }
    let x = b; while (!(x & 0x80)) { n++; x = (x << 1) & 255; } return n; }
  return n;
}
function powAnswerPy(challenge) {   // = _pow_answer / powAnswer
  const M = 0xFFFFFFFF;
  let h1 = 0x811c9dc5 >>> 0, h2 = 0x1000193 >>> 0;
  for (let i = 0; i < challenge.length; i++) {
    const c = challenge.charCodeAt(i) >>> 0;
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h1 = ((h1 << 13) | (h1 >>> 19)) >>> 0;
    h2 = Math.imul((h2 + c + i) >>> 0, 0x85ebca6b) >>> 0;
    h2 = (h2 ^ (h2 >>> 15)) >>> 0;
    h1 = (h1 + h2) >>> 0;
  }
  h1 = (h1 ^ (h1 >>> 16)) >>> 0; h1 = Math.imul(h1, 0x7feb352d) >>> 0; h1 = (h1 ^ (h1 >>> 15)) >>> 0;
  h2 = (h2 ^ (h2 >>> 13)) >>> 0; h2 = Math.imul(h2, 0x846ca68b) >>> 0; h2 = (h2 ^ (h2 >>> 16)) >>> 0;
  const hx = x => (x >>> 0).toString(16).padStart(8, '0');
  return hx(h1) + hx(h2);
}
function verifyPow(salt, nonce, bits) {
  const d = crypto.createHash('sha256').update(powAnswerPy(salt) + ':' + nonce).digest();
  return leadZeroBits(d) >= bits;
}

/* ── 网络桩 ───────────────────────────────────────────────────────────────── */
const NET = { regMode: 'invite', challenges: {}, lastRegister: null, nextRegisterResp: null,
              chalCount: 0 };
function routeApi(url, opt) {
  if (url.startsWith('/api/auth/session'))
    return { ok: true, enabled: true, authed: false, state: 'auth_required',
             pow: { enabled: false },
             reg: NET.regMode === null ? undefined : { mode: NET.regMode } };
  if (url.startsWith('/api/auth/register/challenge')) {
    NET.chalCount++;
    const cid = 'a'.repeat(32 - String(NET.chalCount).length) + NET.chalCount;
    const salt = crypto.randomBytes(16).toString('hex');
    NET.challenges[cid] = { salt, bits: 12 };
    return { ok: true, challengeId: cid, salt, bits: 12, ttl: 600, minFillS: 0,
             mode: NET.regMode };
  }
  if (url.startsWith('/api/auth/register')) {
    const body = JSON.parse(opt.body);
    NET.lastRegister = body;
    if (NET.nextRegisterResp) { const r = NET.nextRegisterResp; NET.nextRegisterResp = null; return r; }
    const ch = NET.challenges[body.challengeId];
    if (!ch) return { __status: 400, ok: false, error: 'challenge_expired', message: '安全校验已过期,请重试' };
    delete NET.challenges[body.challengeId];             // 单次性
    if (!verifyPow(ch.salt, body.nonce, ch.bits))
      return { __status: 400, ok: false, error: 'pow_failed', message: '安全校验未通过,请重试' };
    return { ok: true, user: { id: 1234, userName: body.userName, dueTime: '2026-08-01T00:00:00', dueDays: 3 },
             autoLogin: true };
  }
  if (url.startsWith('/api/live-rooms')) return { ok: true, rooms: [] };
  if (url.startsWith('/api/spells')) return { ok: true, spells: [] };
  return { ok: true };
}

(async () => {
  console.log('注册系统(4.0.0)前端整机冒烟 —— 交付版 index.html + app.js @ jsdom\n');
  // jsdom 的 window.location 不可替换 —— location.reload() 会以 jsdomError
  // 「navigation to another Document」冒出来。捕获它即是「确实触发了 reload」的
  // 可观测证据(比替换 location 更贴近真实:走的是产品代码原样的那一行)。
  let reloadSignals = 0;
  const vc = new VirtualConsole();
  // 5.2.0:jsdom 新版把同一事件的文案改成「navigation (except hash changes)」—— 两种都认,
  // 否则换个 jsdom 版本本断言就假红(实测 jsdom@26 下改前改后同样 1 条假失败)。
  vc.on('jsdomError', e => { if (/navigation (to another Document|\(except hash changes\))/i.test(e.message)) reloadSignals++; });
  vc.on('error', () => {}); vc.on('warn', () => {}); vc.on('info', () => {}); vc.on('log', () => {});
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
                                url: 'http://localhost/', virtualConsole: vc });
  const w = dom.window;
  w.fetch = async (input, opt = {}) => {
    const url = typeof input === 'string' ? input : input.url;
    const body = routeApi(url, opt);
    const status = body.__status || 200;
    return { ok: status < 400, status, headers: { get: () => null },
             json: async () => body, text: async () => JSON.stringify(body) };
  };
  w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){} };
  w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
  w.PerformanceObserver = class { observe(){} disconnect(){} };
  w.matchMedia = q => ({ matches: false, media: q, addEventListener(){}, removeEventListener(){},
                         addListener(){}, removeListener(){} });
  w.scrollTo = () => {};

  /* Worker 替身:抠出 app.js 里的 Worker 源码,在本进程真执行(同步驱动)。
     这同时证明「那段字符串是可执行的合法 JS」——混淆前的源码级保证。 */
  if (!IS_OB) {
    const m = appjs.match(/\/\*__JF_REG_WORKER_BEGIN__\*\/`([\s\S]*?)`\/\*__JF_REG_WORKER_END__\*\//);
    if (!m) { console.log('  [✗] 源码里找不到 Worker 标记'); process.exit(1); }
    /* 4.0.2:邀请码归一镜像的源码级硬对拍(与 Worker 标记同款先例:源码态强制,
       混淆产物剥注释后自动跳过)—— 抠出 jfInviteNorm,按后端 norm_invite_code
       规格向量逐例互证:分隔剥离(含全角)/ OIL 双大小写宽恕 / 长度闸 / U 非法。
       不计入 A() 计数;漂移即整场红灯。 */
    const im = appjs.match(/\/\*__JF_INVITE_NORM_BEGIN__\*\/([\s\S]*?)\/\*__JF_INVITE_NORM_END__\*\//);
    if (!im) { console.log('  [✗] 源码里找不到 jfInviteNorm 标记'); process.exit(1); }
    const jfInviteNorm = new Function(im[1] + '\nreturn jfInviteNorm;')();
    const VEC = [
      ['abcd-efgh-jkmn-pqrs', 'ABCDEFGHJKMNPQRS'],
      ['OIL0 oil1-2345-6789', '0110011123456789'],
      ['ABCD—EFGH—JKMN—PQRS', 'ABCDEFGHJKMNPQRS'],   // 全角 em dash 分隔
      ['ABCD-EFGH-JKMN-PQR', ''],                     // 15 位
      ['UUUU-UUUU-UUUU-UUUU', ''],                    // U 不在 Crockford32
    ];
    for (const [inp, want] of VEC) {
      if (jfInviteNorm(inp) !== want) {
        console.log(`  [✗] jfInviteNorm 与后端规格漂移: ${JSON.stringify(inp)} → ` +
                    `${JSON.stringify(jfInviteNorm(inp))},期望 ${JSON.stringify(want)}`);
        process.exit(1);
      }
    }
  }
  w.Blob = class { constructor(parts){ this.parts = parts; } };
  w.URL = w.URL || {};
  w.URL.createObjectURL = b => b;
  w.Worker = class {
    constructor(blob) {
      const self = { postMessage: d => { if (this.onmessage) this.onmessage({ data: d }); } };
      const TextEncoderRef = TextEncoder;
      // 在本进程 eval 同一段源码;TextEncoder 走 node 内建
      const fn = new Function('self', 'TextEncoder', blob.parts[0] + '\nreturn self;');
      this._self = fn(self, TextEncoderRef);
      this.onmessage = null;
    }
    postMessage(d) { this._self.onmessage({ data: d }); }
  };

  const sc = w.document.createElement('script');
  sc.textContent = appjs;
  w.document.body.appendChild(sc);
  await sleep(400);

  const $ = s => w.document.querySelector(s);
  const click = el => el.dispatchEvent(new w.Event('click', { bubbles: true }));
  const submit = el => el.dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
  const setVal = (el, v) => { el.value = v; };

  // ── ① 入口可见性 ────────────────────────────────────────────────────────
  A('登录门已拉起(未登录 + 登录系统启用)', $('#authGate').hidden === false);
  A('注册入口可见(session.reg.mode=invite)', $('#authToReg').hidden === false);
  A('注册态默认隐藏', $('#regForm').hidden === true && $('#authForm').hidden === false);

  // ── ② 切换到注册态 ──────────────────────────────────────────────────────
  click($('#authToReg')); await sleep(120);
  A('切到注册态:注册表单显示、登录表单隐藏',
    $('#regForm').hidden === false && $('#authForm').hidden === true);
  A('invite 模式:邀请码字段可见', $('#regInviteWrap').hidden === false);
  A('标题切为「注册账号」', $('#authTitle').textContent.includes('注册'));
  A('打开表单即预取挑战(R4 填表时长自签发起算)', NET.chalCount >= 1);
  A('蜜罐字段在 DOM 中且初值为空', $('#regContact') && $('#regContact').value === '');

  // ── ③ 字段级即时校验(5–16 位,无组合限制)────────────────────────────
  setVal($('#regUser'), 'a'); setVal($('#regPass'), 'pw123'); setVal($('#regPass2'), 'pw123');
  setVal($('#regInvite'), 'ABCD-EFGH-JKMN-PQRS');
  submit($('#regForm')); await sleep(60);
  A('用户名过短 → 就地提示', /2–20/.test($('#regMsg').textContent));
  // 4.0.6:字符集闸([A-Za-z0-9])。它取代了 4.0.2 的 emoji 代理对预检 —— 中文、
  // emoji、全角字母(同形字仿冒)、连字符全部落在同一条闸下,文案统一;仍是就地拦,
  // 免让真人白付一次 PoW 并消耗一次 R1 尝试配额,此刻不应发出任何注册请求。
  for (const bad of ['小白😀', '张三', 'ＡＢＣ', 'ab-cd', 'a b']){
    setVal($('#regUser'), bad); setVal($('#regPass'), 'pw123'); setVal($('#regPass2'), 'pw123');
    submit($('#regForm')); await sleep(60);
    A('用户名「' + bad + '」→ 就地提示字符集且未发注册请求',
      /只能包含英文字母和数字/.test($('#regMsg').textContent) && NET.lastRegister === null);
  }
  // 纯数字用户名必须被放行(4.0.6 运营明确要求)。刻意让它止步在**后一道**闸
  // (两次口令不一致)上:doRegister 的闸序是 长度 → 字符集 → 口令长度 → 两次一致,
  // 能走到"不一致"就证明字符集闸放行了纯数字;同时不会真发一次注册请求去污染
  // 下方 ③ 的载荷断言(初版直接提交,PoW 还在解就被后续用例撞上,实测三条假红)。
  setVal($('#regUser'), '2026013800');
  setVal($('#regPass'), 'pw123'); setVal($('#regPass2'), 'pw999');
  submit($('#regForm')); await sleep(60);
  A('纯数字用户名放行(止步于后一道口令闸,非字符集闸)',
    /不一致/.test($('#regMsg').textContent) && NET.lastRegister === null);
  setVal($('#regUser'), 'newuser');
  setVal($('#regPass'), '1234'); setVal($('#regPass2'), '1234');
  submit($('#regForm')); await sleep(60);
  A('口令 4 位 → 提示 5–16 位', /5–16/.test($('#regMsg').textContent));
  setVal($('#regPass'), 'x'.repeat(17)); setVal($('#regPass2'), 'x'.repeat(17));
  submit($('#regForm')); await sleep(60);
  A('口令 17 位 → 提示 5–16 位', /5–16/.test($('#regMsg').textContent));
  setVal($('#regPass'), '12345'); setVal($('#regPass2'), '54321');
  submit($('#regForm')); await sleep(60);
  A('两次不一致 → 提示', /不一致/.test($('#regMsg').textContent));

  // 纯数字 5 位必须被放行(无字符组合限制)——不该在前端被拦
  setVal($('#regPass'), '12345'); setVal($('#regPass2'), '12345');
  const before = NET.chalCount;
  submit($('#regForm'));
  await sleep(1500);           // 解 12 位 PoW
  A('纯数字 5 位口令被放行(无组合限制)且真的发出了注册请求',
    NET.lastRegister && NET.lastRegister.userName === 'newuser');
  A('提交载荷含 challengeId + nonce',
    !!(NET.lastRegister.challengeId && NET.lastRegister.nonce));
  A('提交载荷含邀请码(invite 模式)', NET.lastRegister.inviteCode === 'ABCD-EFGH-JKMN-PQRS');
  A('蜜罐字段随载荷提交且为空(真人路径)', NET.lastRegister.contact === '');
  A('口令原样提交(编码在服务端做)', NET.lastRegister.password === '12345');
  A('autoLogin=true → 触发 reload 收束(产品代码原样调用 location.reload)',
    reloadSignals >= 1);
  A('成功后表单已清空(4.0.1:旧值不残留,口令不滞留 DOM)',
    $('#regUser').value === '' && $('#regPass').value === '' &&
    $('#regPass2').value === '' && $('#regInvite').value === '');

  // 4.0.2:格式必败邀请码就地拦(镜像 norm,详见 doRegister 注)—— 不发请求、
  // 不烧 PoW 与配额;随后验证被拦时的模式自愈:运营 invite→open 热切后,拦截
  // 分支后台刷新的挑战回包把本页拨到 open(邀请码框收起),不再卡死在陈旧模式。
  // 刻意置于 ③ 的载荷断言之后:此后 ④⑤ 在 open 下继续,其断言本就模式无关;
  // ⑥ 各自独立开机,亦不受影响 —— 单向拨动即可收,不必戳内部符号拨回。
  setVal($('#regUser'), 'newuser');
  setVal($('#regPass'), '12345'); setVal($('#regPass2'), '12345');
  setVal($('#regInvite'), 'ABCD');
  const lrBeforeBlock = NET.lastRegister;
  submit($('#regForm')); await sleep(60);
  A('邀请码格式非法 → 就地提示且未发注册请求',
    /邀请码无效/.test($('#regMsg').textContent) && NET.lastRegister === lrBeforeBlock);
  NET.regMode = 'open';
  setVal($('#regInvite'), '!!!!');
  submit($('#regForm')); await sleep(160);
  A('格式拦截触发模式刷新:invite→open 热切后邀请码框收起',
    $('#regInviteWrap').hidden === true && NET.lastRegister === lrBeforeBlock);

  // ── ④ 服务端拒绝的呈现(4.0.1 起成功即清空,故此段如真人般重新填表)────
  const reloadsAfterSuccess = reloadSignals;
  NET.nextRegisterResp = { __status: 400, ok: false, error: 'name_taken',
                           message: '该用户名已被使用,请更换' };
  setVal($('#regUser'), 'dupname');
  setVal($('#regPass'), '12345'); setVal($('#regPass2'), '12345');
  setVal($('#regInvite'), 'ABCD-EFGH-JKMN-PQRS');
  submit($('#regForm')); await sleep(1500);
  A('重名 → 就地呈现服务端文案', /已被使用/.test($('#regMsg').textContent));
  A('失败不 reload', reloadSignals === reloadsAfterSuccess);

  NET.nextRegisterResp = { __status: 429, ok: false, error: 'throttled', retryAfter: 1800,
                           message: '操作过于频繁,请稍后再试' };
  submit($('#regForm')); await sleep(1500);
  A('429 → 呈现文案且附可再试分钟数',
    /过于频繁/.test($('#regMsg').textContent) && /30 分钟/.test($('#regMsg').textContent));

  // ── ⑤ autoLogin=false → 成功卡 + 开通指引 ─────────────────────────────
  NET.nextRegisterResp = { ok: true, user: { id: 9, userName: 'zerogift', dueTime: '', dueDays: 0 },
                           autoLogin: false, hint: '注册成功!请联系管理员开通使用时长后登录。' };
  setVal($('#regUser'), 'zerogift');
  submit($('#regForm')); await sleep(1500);
  A('零赠送 → 成功卡出现并展示开通指引',
    $('#regDone').hidden === false && /联系管理员/.test($('#regDoneText').textContent));
  A('零赠送不 reload(账号还不能登录)', reloadSignals === reloadsAfterSuccess);
  A('零赠送成功后表单亦已清空(4.0.1)',
    $('#regUser').value === '' && $('#regPass').value === '');

  // ── 4.0.1:口令可见性切换(眼睛)冒烟 ─────────────────────────────────
  {
    const eye = $('#regForm .pw-wrap .pw-eye');
    click(eye); await sleep(30);
    A('眼睛切换:点按后口令明文可见且 aria-pressed=true',
      $('#regPass').type === 'text' && eye.getAttribute('aria-pressed') === 'true');
    click(eye); await sleep(30);
    A('眼睛切换:再点按回到密文且 aria-pressed=false',
      $('#regPass').type === 'password' && eye.getAttribute('aria-pressed') === 'false');
  }

  click($('#regDoneBack')); await sleep(60);
  A('「返回登录」回到登录态',
    $('#authForm').hidden === false && $('#regForm').hidden === true && $('#regDone').hidden === true);

  // ── ⑥ 模式驱动的入口可见性(黑盒:各自开机一次,只看用户能看见什么)──────
  //    刻意不戳内部符号 —— 混淆产物里全局名会被 renameGlobals 改掉,而**产品
  //    行为**(session.reg.mode 决定入口显隐)在两种形态下都必须一致。
  for (const [mode, want, why] of [['off', true, 'off → 注册入口隐藏'],
                                   [null, true, '旧后端无 reg 字段 → 入口恒隐藏(兼容矩阵)'],
                                   ['open', false, 'open → 入口可见'],
                                   ['invite', false, 'invite → 入口可见']]) {
    const st = await boot(mode);
    A(why, st.entryHidden === want);
    if (mode === 'open') A('open 模式:邀请码字段隐藏', st.inviteHidden === true);
    if (mode === 'invite') A('invite 模式:邀请码字段可见', st.inviteHidden === false);
  }

  console.log(`\n注册前端冒烟(${IS_OB ? '混淆部署产物' : '仓库源码'}):${PASS} 通过 / ${FAIL} 失败`);
  if (FAIL) process.exit(1);
})().catch(e => { console.error('冒烟异常:', e); process.exit(1); });

/* 黑盒开机:按给定 reg.mode 起一份全新 DOM,回报「用户能看见什么」。 */
async function boot(mode) {
  const saved = NET.regMode;
  NET.regMode = mode;
  const vc2 = new VirtualConsole();
  vc2.on('jsdomError', () => {}); vc2.on('error', () => {}); vc2.on('warn', () => {});
  const d2 = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
                               url: 'http://localhost/', virtualConsole: vc2 });
  const x = d2.window;
  x.fetch = async (input, opt = {}) => {
    const url = typeof input === 'string' ? input : input.url;
    const b = routeApi(url, opt);
    return { ok: !(b.__status >= 400), status: b.__status || 200,
             headers: { get: () => null }, json: async () => b,
             text: async () => JSON.stringify(b) };
  };
  x.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){} };
  x.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
  x.PerformanceObserver = class { observe(){} disconnect(){} };
  x.matchMedia = q => ({ matches: false, media: q, addEventListener(){}, removeEventListener(){},
                         addListener(){}, removeListener(){} });
  x.scrollTo = () => {};
  x.Blob = class { constructor(parts){ this.parts = parts; } };
  x.URL = x.URL || {}; x.URL.createObjectURL = b => b;
  x.Worker = class { constructor(){} postMessage(){} };
  const s2 = x.document.createElement('script');
  s2.textContent = appjs;
  x.document.body.appendChild(s2);
  await sleep(350);
  // 非 off 时点一下入口,才能观察邀请码字段(它随注册态渲染)
  const entry = x.document.querySelector('#authToReg');
  const entryHidden = entry ? entry.hidden : true;      // ← 必须在点击前取:
  if (entry && !entryHidden)                            //   regShow() 会把入口自身收起
    entry.dispatchEvent(new x.Event('click', { bubbles: true }));
  await sleep(120);
  const out = { entryHidden,
                inviteHidden: x.document.querySelector('#regInviteWrap').hidden };
  NET.regMode = saved;
  d2.window.close();
  return out;
}
