"""
sim_history_gap.py — GameHistory 触发策略的「真机模拟」对照台
================================================================================
目的:量化回答「history_every_rounds 定期盲扫 vs 缺口驱动(gap_only)」两种策略在
     GameHistory 调用量 / 数据完整性 / 官方缺失识别 / 自愈时延 上的差异。

真机性:不重写任何抓取逻辑 —— 直接驱动 **真实 Worker 的处理器**
  (app.worker._handle → _handle_mainpage/_handle_award/_backfill_history/哨兵),
  调度走 **真实 RedisBus**(fakeredis 承载,Lua claim/ack 原样执行),
  仅把三样外设换成可控仿真件:
    · 时钟   → 虚拟毫秒钟(patch redis_bus.now_ms / worker.now_ms)
    · 上游   → SimUpstream(按 50001ms 格点滴答的官方模型 + 故障注入)
    · PG     → FakeDB(内存 rounds 表,幂等语义与真库一致)

场景矩阵(每场景两种模式各跑一遍):
  S0 完整链路无故障          —— 「数据完整时」的调用量对照(核心问题)
  S1 出怪瞬时未就绪(重试吸收) —— 正常退避不应触发 history
  S2 award 任务丢失 ×3       —— 「真漏抓」:哨兵事件检出 vs 周期扫兜底
  S3 官方本身缺一局          —— 「官方缺」:确证一次后不得再打
  S4 停机跨 5 局后恢复       —— 漏局分支补齐
  S5 200 局马拉松混合故障     —— 长跑总量对照
  S6 史诗停机 260 局          —— 越过护栏(200)与官方历史页窗(30):页窗外数据
                                信息论上双模式都救不回,考核「确证不可再取得
                                后是否止损」(登记 offmiss、水位越过、不复打)
  S7 双 worker 副本并发同房   —— 冷却闸跨副本去重 + 水位良性竞态
  S8 GameHistory 上游抖动     —— 哨兵补漏前两次失败:水位原地不动,后续事件
                                自动重试直至成功(不丢补漏、不风暴)
  S9 恢复瞬间上游连败         —— 停机复播那一拍 mp 漏局分支首拉失败(不占礼让闸)
                                → 同事件哨兵接力亦失败 → 水位原地 → 后续事件成功
                                自愈(礼让闸失败不占用、失败链自恢复的联动验证)
  S10 Redis 全量掉电重挂      —— 快照/调度/名录尽失(DB 完好):重播种一次、水位
                                重建、页窗内补齐;界外历史不追认(与新房一致,可用
                                旧引擎 cmd_repair 手动追认)——考核「无风暴重生」
  (另:--fuzz N 随机对抗 / --soak 1500局长跑 / --mass N 万房同时,
   万房实测:播种 10000/10000、hist 精确=n+300+100、洞 0、键=2n+4、910事件/s)
  S11 上游 MainPage 断供10分钟 —— 失败重试指数退避 30s 封顶:断供窗内单房调用
                                ~23 次(扁平 1.5s 重试为 ~390 次,正常节奏 33 倍并
                                白烧全局令牌);恢复后漏局分支一次补齐、计数复位

用法:
  python -m scripts.sim_history_gap                 # 全场景 × 两模式
  python -m scripts.sim_history_gap --mode gap_only --scenario S2
"""
from __future__ import annotations

import argparse
import random
import asyncio
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, List, Optional, Set

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import fakeredis.aioredis  # noqa: E402
# fakeredis 加速猴补(仅 harness 域,零语义差):ExpiringMembersSet._expire_members
# 对**每条 set 命令**全量扫成员过期;本仿真从不使用成员级过期(全部 expiry=None,
# 判 (None or now+1)<now 恒 False = 纯白扫),而万房下 sched:rooms 万成员使其
# 变 O(N)/命令 —— cProfile 实测占 11% 且为超线性源。no-op 后语义逐位不变。
from fakeredis.model import _expiring_members_set as _ems  # noqa: E402
_ems.ExpiringMembersSet._expire_members = lambda self: None  # noqa: E731
# 同类第二刀:ClientInfo.items/as_bytes 每条命令各调一次、纯为 CLIENT INFO
# 文本输出服务(本仿真从不调用该命令),cProfile 实测合计 ~9% tottime;短路为
# 空产出,消费方(字符串拼接/遍历)得空值,语义零差。
from fakeredis.model import _client_info as _ci  # noqa: E402
_ci.ClientInfo.items = lambda self: ()           # noqa: E731
_ci.ClientInfo.as_bytes = lambda self: b""       # noqa: E731

from app import redis_bus as rb  # noqa: E402
from app import worker as wk  # noqa: E402
from app.constants import BEASTS_BASE, ROUND_STEP  # noqa: E402
from app.settings import Settings  # noqa: E402

STEP = ROUND_STEP
AWARD_READY_OFFSET = 36_000          # 真机实测:备战(+35s)后 ~1s 结果即生成
T0 = 1_800_000_000_000               # 对齐格点的仿真纪元(rid 即起点毫秒)
ROOM = "2678075"


# ── 虚拟时钟(整个 worker/redis_bus 的 now_ms 都走它) ─────────────────────────
class VClock:
    def __init__(self, t: int):
        self.t = int(t)

    def __call__(self) -> int:
        return self.t


# ── 官方上游模型(格点滴答 + 故障注入 + 调用计数) ─────────────────────────────
class SimUpstream:
    """行为契约与真上游对齐:
       · MainPage 回当前局权威计时(serverTime=服务器此刻);
       · RoundAward 在 rid+36s 前为空(未就绪),之后回 beastInfo;支持按局附加
         额外延迟(ready_extra)与「官方缺失」(award 与 history 都永远无此局);
       · GameHistory 固定只回最近 30 局(旧引擎注释与 --repair 双证的接口事实),
         新→旧排列,不含官方缺失局。"""

    def __init__(self, clock: VClock):
        self.clock = clock
        self.calls: Counter = Counter()
        self.official_missing: Set[int] = set()
        self.ready_extra: Dict[int, int] = {}
        self.hist_window = 30
        self.hist_fail_calls: Set[int] = set()
        self.mp_outage = None                        # (start_ms, end_ms) MainPage 断供窗
        self.mp_outage_room = None                   # 断供只作用于此房(None=全局)
        self.calls_by_room: Dict[tuple, int] = {}    # (kind, room) -> 次数(多房隔离审计)
        self.t_hist: List[int] = []                  # 每次 hist 调用的虚拟时刻(惊群分析)

    def _cnt(self, kind: str, room: str) -> None:
        self.calls_by_room[(kind, room)] = self.calls_by_room.get((kind, room), 0) + 1

    def _off(self, room: str, rid: int) -> bool:
        """官方缺判定:裸 rid(单房场景沿用) 或 (room, rid) 元组(多房定向注入)。"""
        return rid in self.official_missing or (room, rid) in self.official_missing

    def _extra(self, room: str, rid: int) -> int:
        return self.ready_extra.get((room, rid), self.ready_extra.get(rid, 0))   # 第 N 次 GameHistory 调用返回 None(网络抖动)

    # 格点工具
    def cur_round(self) -> int:
        return T0 + ((self.clock.t - T0) // STEP) * STEP

    def _beast(self, rid: int) -> dict:
        oid, name, _spell, _mult = BEASTS_BASE[(rid // STEP) % len(BEASTS_BASE)]
        return {"beastId": oid, "beastName": name}

    def _ready(self, rid: int, room: str = ROOM) -> bool:
        return self.clock.t >= rid + AWARD_READY_OFFSET + self._extra(room, rid)

    # ── 与 Upstream 同名同参的三个端点 ──
    async def main_page(self, _aid: int, room: str):
        self.calls["mp"] += 1
        self._cnt("mp", room)
        if (self.mp_outage and (self.mp_outage_room in (None, room))
                and self.mp_outage[0] <= self.clock.t < self.mp_outage[1]):
            return None                              # 上游 MainPage 断供窗口
        rid = self.cur_round()
        return {"roundId": rid, "serverTime": self.clock.t, "canPlay": True,
                "spellTime": rid + 35_000, "drawTime": rid + 40_000,
                "endTime": rid + 50_000}

    async def round_award(self, _aid: int, room: str, round_id: str):
        self.calls["aw"] += 1
        self._cnt("aw", room)
        rid = int(round_id)
        if self._off(room, rid) or not self._ready(rid, room):
            return {}
        return {"beastInfo": self._beast(rid)}

    async def game_history(self, _aid: int, room: str):
        self.calls["hist"] += 1
        self._cnt("hist", room)
        self.t_hist.append(self.clock.t)
        if self.calls["hist"] in self.hist_fail_calls:
            return None                              # 模拟上游/网络失败
        newest = self.cur_round()
        while newest >= T0 and not self._ready(newest, room):
            newest -= STEP
        out = []
        g = newest
        while g >= T0 and len(out) < self.hist_window:
            if not self._off(room, g):
                out.append({"roundId": g, "beastInfo": self._beast(g)})
            g -= STEP
        return {"gameList": out}


# ── 内存 PG(幂等语义与 db.DB 一致;只实现 worker 热路径触到的方法) ────────────
class FakeDB:
    def __init__(self):
        self.by_room: Dict[str, Dict[int, dict]] = {ROOM: {}}
        self.first_insert_at: Dict[int, int] = {}   # ROOM 的 rid->入库时刻(测自愈时延)
        self._clock: Optional[VClock] = None

    @property
    def rounds(self) -> Dict[int, dict]:
        """兼容层:历史单房套件把 rounds 当 ROOM 的 rid→行 字典用,
        返回 by_room[ROOM] 的**真实引用**(读/写/取值全兼容)。"""
        return self.by_room.setdefault(ROOM, {})

    def _t(self, room: str) -> Dict[int, dict]:
        return self.by_room.setdefault(str(room), {})

    async def oldest_round(self, room):
        t = self._t(room)
        return min(t) if t else None

    async def has_round(self, room, rid: int) -> bool:
        return int(rid) in self._t(room)

    async def add_round(self, room, rid: int, oid, name, cid, mult, source,
                        _draw_local, _date_local) -> bool:
        rid = int(rid); t = self._t(room)
        if rid in t:
            return False
        t[rid] = {"official_id": oid, "beast_name": name,
                  "custom_id": cid, "multiplier": mult, "source": source}
        if self._clock and str(room) == ROOM:
            self.first_insert_at[rid] = self._clock.t
        return True

    async def add_rounds_bulk(self, room, rounds: List[dict], batch_size=500):
        t = self._t(room)
        new_ids = []
        for g in rounds:
            rid = int(g["round_id"])
            if rid in t:
                continue
            t[rid] = {k: g.get(k) for k in
                      ("official_id", "beast_name", "custom_id",
                       "multiplier", "source")}
            if self._clock and str(room) == ROOM:
                self.first_insert_at[rid] = self._clock.t
            new_ids.append(rid)
        return new_ids

    # 预测链路桩(仿真关闭预测;这些只被无害触达)
    async def fill_prediction_outcome(self, *_a, **_k):
        return None

    async def load_predictor_kv(self, _room):
        return {}

    async def save_predictor_kv(self, _room, _kv):
        pass

    async def sequence(self, *_a, **_k):
        return []

    async def save_prediction(self, *_a, **_k):
        pass


# ── 组装:真实 Worker + fakeredis + 仿真外设 ──────────────────────────────────
def _legacy_blind_scan(w, db):
    """旧「每 5 局盲扫」行为仿真器 —— 生产分支已移除,此处在 harness 层逐字节
    复刻删除前的 worker 分支(= 旧引擎 _cycle):成功路径每有一局新入库(is_new,
    以调用前后 has_round 对照探测,与原分支 add_round 返回值同构),共享 Redis
    计数器 histCount 步进,满 5 清零并无条件 backfill 一次。共享计数器保证
    多副本(S7)语义与原分支一致。仅供对照表 periodic 基线,不进生产路径。"""
    orig = w._handle_award

    async def _noop_sentinel(*_a, **_kw):
        return None

    # 复刻「旧行为」= 盲扫开 + 哨兵不存在。生产码中哨兵已恒开(无旋钮),
    # 此处压制之,periodic 列才是纯旧行为、可与历史基线逐字节对账。
    w._coverage_check = _noop_sentinel

    async def wrapped(room, round_id, member):
        before = await db.has_round(room, round_id)
        await orig(room, round_id, member)
        if not before and await db.has_round(room, round_id):
            if (await w.bus.snap_incr(room, "histCount")) >= 5:
                await w.bus.set_snapshot(room, {"histCount": 0})
                await w._backfill_history(room)

    w._handle_award = wrapped


def build_world(mode: str):
    clock = VClock(T0 + 10 * STEP + 2_000)          # 从第 10 局局内 2s 处起监控
    rb.now_ms = clock                                # 补丁进 redis_bus 命名空间
    wk.now_ms = clock                                # worker 的 from-import 同步补丁

    s = Settings()
    s.prediction = {"enabled": False}                # 仿真聚焦抓取链路
    s.scheduler.award_jitter_ms = 0                  # 抖动清零 → 完全确定性
    s.scheduler.mainpage_jitter_ms = 0

    w = wk.Worker(s)
    w.bus.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    up = SimUpstream(clock)
    db = FakeDB()
    db._clock = clock
    w.up, w.db = up, db
    if mode == "periodic":                           # 生产分支已删,基线走行为仿真器
        _legacy_blind_scan(w, db)
    return w, up, db, clock


async def pump(w, clock, until_ms: int, injectors=None, batch: int = 500):
    """事件泵:领取到期任务→交真实 _handle;队列空则把虚拟钟跳到下一到期点。
    w 可为单个 Worker 或 Worker 列表(多副本并发同房:任务轮转分发,共享同一
    Redis/DB/上游 —— 与生产多进程瓜分同一延迟队列同构)。"""
    workers = w if isinstance(w, (list, tuple)) else [w]
    bus = workers[0].bus
    injectors = injectors or []
    rr = 0
    while True:
        for inj in injectors:
            await inj(bus, clock)
        members = await bus.claim_due(batch, 10 ** 12)
        if members:
            for m in members:
                await workers[rr % len(workers)]._handle(m)
                rr += 1
            continue
        z = await bus.r.zrange(rb.K_SCHED, 0, 0, withscores=True)
        if not z:
            return
        nxt = int(z[0][1])
        if nxt > until_ms:
            return
        jump = max(1, nxt - clock.t)
        clock.t = clock.t + jump
        # fakeredis 的 PX 过期走真实时钟,而世界跑在虚拟时钟上 —— 这里把
        # 「虚拟时间已流逝 ≥ 冷却时长」翻译成删除冷却键,对齐真实 Redis 语义
        # (生产上 5s 冷却 ≪ 事件间隔,下一事件必然重审成功)。
        if jump >= wk.COV_HIST_COOLDOWN_MS:
            await bus.r.delete(rb.K_HIST_GATE.format(room=ROOM))


# ── 注入器工厂 ────────────────────────────────────────────────────────────────
def make_task_loser(targets: Set[int]):
    """模拟「award 任务彻底丢失」:目标局的 aw 任务一入队即被无声蒸发
    (等价 Redis 掉数据/崩溃窗口)。MainPage 照常滴答 —— 正是盲扫存在的理由场景。"""
    async def inj(bus, _clock):
        if not targets:
            return
        for rid in list(targets):
            member = rb.task_award(ROOM, rid)
            if await bus.r.zscore(rb.K_SCHED, member) is not None:
                await bus.ack(member)
                targets.discard(rid)
    return inj


async def run_scenario(name: str, mode: str, verbose: bool = False) -> dict:
    w, up, db, clock = build_world(mode)
    await w.bus.add_room(ROOM)
    await w.bus.schedule(rb.task_mainpage(ROOM), clock.t)
    start_rid = up.cur_round()
    horizon = 60                                     # 默认监控 60 局
    injectors, lost_targets = [], set()
    stall_plan = None                                # (在第几局后停机, 停几局)

    if name == "S1":                                 # 瞬时未就绪:3 局各多等 4s → 退避吸收
        for k in (15, 30, 45):
            up.ready_extra[start_rid + k * STEP] = 4_000
    elif name == "S2":                               # award 任务丢失 ×3(孤立分布)
        lost_targets = {start_rid + k * STEP for k in (12, 27, 44)}
        injectors.append(make_task_loser(lost_targets))
    elif name == "S3":                               # 官方本身缺一局
        up.official_missing.add(start_rid + 20 * STEP)
    elif name == "S4":                               # 停机跨 5 局
        stall_plan = (18, 5)
    elif name == "S5":                               # 200 局马拉松混合
        horizon = 200
        lost_targets = {start_rid + k * STEP for k in (40, 95)}
        injectors.append(make_task_loser(lost_targets))
        up.official_missing.add(start_rid + 70 * STEP)
        up.ready_extra[start_rid + 120 * STEP] = 4_000
        stall_plan = (150, 3)
    elif name == "S6":                               # 史诗停机 260 局(>护栏200 且 >历史页30)
        horizon = 320                                #   页窗外数据信息论上救不回(双模式同):
        stall_plan = (20, 260)                       #   考核「确证不可再取得后是否止损」
    elif name == "S7":                               # 双 worker 副本并发同房 + 丢任务
        lost_targets = {start_rid + 14 * STEP}
        injectors.append(make_task_loser(lost_targets))
        w2 = wk.Worker(w.s)                          # 第二副本:共享同一 Redis/DB/上游/时钟
        w2.bus.r, w2.up, w2.db = w.bus.r, up, db
        if mode == "periodic":
            _legacy_blind_scan(w2, db)               # 共享 histCount → 与原分支同语义
        w = [w, w2]
    elif name == "S8":                               # 上游 GameHistory 抖动:哨兵补漏前两次失败
        lost_targets = {start_rid + 10 * STEP}
        injectors.append(make_task_loser(lost_targets))
        up.hist_fail_calls = {2, 3}                  # 第1次=播种成功;第2/3次(哨兵)失败
    elif name == "S9":                               # 停机恢复瞬间上游连败:mp漏局分支首拉失败
        stall_plan = (15, 5)                         #   → 无礼让闸 → 同事件哨兵接力亦失败
        up.hist_fail_calls = {2, 3}                  #   → 水位原地 → 后续事件第4次成功自愈
    elif name == "S10":                              # Redis 全量掉电(快照/调度/名录尽失)后重挂:
        pass                                         #   重播种一次、水位重建、页窗内补齐,
                                                     #   界外历史不追认(与新房一致)——无风暴
    elif name == "S11":                              # 上游 MainPage 断供 10 分钟:失败重试
        pass                                         #   指数退避 30s 封顶(不锤击不烧令牌),
                                                     #   恢复后漏局分支一次补齐、成功复位
    end_ms = start_rid + horizon * STEP + 45_000
    oblig_start = start_rid                          # 完整性义务窗起点(S10 掉电后重置)
    if name == "S11":
        mid = start_rid + 15 * STEP + 45_000
        await pump(w, clock, mid, injectors)
        up.mp_outage = (clock.t, clock.t + 600_000)  # 断供 10 分钟(时钟照走)
        await pump(w, clock, end_ms, injectors)
    elif name == "S10":
        mid = start_rid + 20 * STEP + 45_000
        await pump(w, clock, mid, injectors)
        await w.bus.r.flushall()                     # 掉电:Redis 全量丢失(DB 完好)
        clock.t += 2 * STEP                          # 运维发现+重挂间隔:2 局
        await w.bus.add_room(ROOM)
        await w.bus.schedule(rb.task_mainpage(ROOM), clock.t + 500)
        oblig_start = up.cur_round() - 29 * STEP     # 重播种页窗即新义务窗(界外=播种界外)
        await pump(w, clock, end_ms, injectors)
    elif stall_plan:
        at, n = stall_plan
        mid = start_rid + at * STEP + 45_000
        await pump(w, clock, mid, injectors)
        clock.t += n * STEP                          # 停机:时钟走,任务不处理
        await pump(w, clock, end_ms, injectors)
    else:
        await pump(w, clock, end_ms, injectors)
    if isinstance(w, list):
        w = w[0]                                     # 体检读共享态,任一副本皆可

    # ── 体检:完整性 / 官方缺失登记 / 自愈时延 ──
    last_done = up.cur_round()
    while not up._ready(last_done):
        last_done -= STEP
    expected = {r for r in range(oblig_start, last_done + 1, STEP)
                if r not in up.official_missing}
    have = set(db.rounds)
    holes = sorted(expected - have)
    offmiss = {int(x) for x in await w.bus.r.zrange(
        rb.K_OFF_MISSING.format(room=ROOM), 0, -1)}
    heal_ms = None
    if name in ("S2", "S5", "S7", "S8", "S9"):
        lost0 = sorted({start_rid + k * STEP for k in
                        {"S2": (12, 27, 44), "S5": (40, 95), "S7": (14,),
                         "S8": (10,), "S9": (15, 16, 17, 18, 19)}[name]})
        lat = [db.first_insert_at[r] - (r + AWARD_READY_OFFSET)
               for r in lost0 if r in db.first_insert_at]
        heal_ms = max(lat) if lat else -1

    snap = await w.bus.get_snapshot(ROOM)
    res = {"scenario": name, "mode": mode, "rounds": horizon,
           "hist_calls": up.calls["hist"], "aw_calls": up.calls["aw"],
           "mp_calls": up.calls["mp"], "complete": not holes,
           "holes": len(holes),
           # 残洞是否已全部「确证不可再取得」(登记 offmiss):史诗停机场景中
           # 30 局页窗外的数据双模式都救不回(信息论下界),合格判据是止损 ——
           # 确证后水位越过、不再为其反复打 history/被前端徒劳拉取。
           "holes_certified": (not holes) or all(g in offmiss for g in holes),
           "offmiss_ok": offmiss >= up.official_missing,
           "heal_ms": heal_ms, "covWm_lag": (
               (last_done - int(snap.get("covWm") or 0)) // STEP
               if snap.get("covWm") else None)}
    if verbose:
        print(f"    快照={ {k: snap.get(k) for k in ('covWm', 'histCount', 'seeded')} } "
              f"官方缺登记={sorted(offmiss)} 洞={holes[:5]}")
    return res



# ════════════════════════════════════════════════════════════════════════════
# Fuzz 战役:随机化对抗仿真 —— 不对表,验不变量。每个种子随机生成一个世界
# (局数/调度抖动/丢任务/官方缺/就绪延迟/上游连败/停机或掉电/单双副本),
# 跑完后体检五条不变量:
#   I1 义务窗内:洞 ⊆ 已确证(offmiss) 且 洞 ⊆ 不可救集(可救者必救,绝不弃);
#   I2 官方缺失(窗内)全部确证登记;
#   I3 误判死刑=0:offmiss 里不在库的点 ⊆ 不可救集(失败绝不构成证据);
#   I4 水位收敛:covWm 距头 ≤3 局;
#   I5 无故障种子:GameHistory 恰 1 次(播种)且零洞零登记;
#   I6/I7/I8 资源预算:MainPage ≤ 局数+退避份额、RoundAward ≤ 局数+重试份额、
#      GameHistory ≤ 故障可解释份额 —— 任何超预算调用即失败(反滥用硬闸)。
# 不可救集 = 官方缺 ∪ 停机/掉电阴影中已出重挂页窗(近30局)的点;掉电后义务窗
# 重置为重播种页窗(播种界外与新房同义,不追认)。阴影起点留 60s 容差吞在飞边界。
# ════════════════════════════════════════════════════════════════════════════
async def fuzz_run(seed: int, verbose: bool = False) -> dict:
    rng = random.Random(seed)
    random.seed(seed)                            # worker 调度抖动可复现
    w, up, db, clock = build_world("gap_only")
    w.s.scheduler.award_jitter_ms = rng.choice([0, 300, 600])
    w.s.scheduler.mainpage_jitter_ms = rng.choice([0, 400, 700])
    horizon = rng.randint(70, 140)
    start = up.cur_round()
    grid = [start + k * STEP for k in range(horizon)]
    lost = {g for g in grid[3:-4] if rng.random() < 0.04}
    official = {g for g in grid[5:-5] if g not in lost and rng.random() < 0.02}
    up.official_missing |= official
    delayed = 0
    for g in grid:
        if g not in lost and g not in official and rng.random() < 0.05:
            up.ready_extra[g] = rng.randint(2_000, 8_000); delayed += 1
    kind = rng.choices(["none", "stall", "flush", "mpfail"],
                       weights=[50, 20, 15, 15])[0]
    o_at = rng.randint(12, horizon - 30) if kind != "none" else 0
    o_len = (rng.choice([3, 7, 40, 80, 260]) if kind == "stall"
             else rng.choice([1, 3, 35]) if kind == "flush"
             else rng.choice([2, 5, 8]) if kind == "mpfail" else 0)
    hf: Set[int] = set()
    if rng.random() < 0.35:
        a = rng.randint(2, 8)
        hf = {a} | ({a + 1} if rng.random() < 0.5 else set())
    up.hist_fail_calls = hf
    dual = rng.random() < 0.30
    workers = w
    if dual:
        w2 = wk.Worker(w.s)
        w2.bus.r, w2.up, w2.db = w.bus.r, up, db
        workers = [w, w2]
    inj = [make_task_loser(set(lost))]
    await w.bus.add_room(ROOM)
    await w.bus.schedule(rb.task_mainpage(ROOM), clock.t)
    end = start + horizon * STEP + 45_000
    outage = None                                # (start_wall, end_wall, resume_head)
    if kind == "none":
        await pump(workers, clock, end, inj)
    else:
        await pump(workers, clock, start + o_at * STEP + 45_000, inj)
        o_wall = clock.t
        if kind == "mpfail":                         # 断供:时钟照走,mp 全 None
            up.mp_outage = (clock.t, clock.t + o_len * STEP)
            outage = (o_wall, clock.t + o_len * STEP, None)
            await pump(workers, clock, end, inj)
            outage = (o_wall, outage[1], up.cur_round())
        else:
            if kind == "flush":
                await w.bus.r.flushall()
            clock.t += o_len * STEP
            resume_head = up.cur_round()
            if kind == "flush":
                await w.bus.add_room(ROOM)
                await w.bus.schedule(rb.task_mainpage(ROOM), clock.t + 500)
            outage = (o_wall, clock.t, resume_head)
            await pump(workers, clock, end, inj)
    await pump(workers, clock, up.cur_round() + 3 * STEP + 45_000, inj)  # 尾部结清
    wchk = workers[0] if isinstance(workers, list) else workers

    last = up.cur_round()
    while not up._ready(last):
        last -= STEP
    # 体检网格必须覆盖真实日历(停机/掉电把世界拉长到 horizon 之外,首轮 fuzz
    # 曾因 grid 截断把系统的正确免打直登误报成 I3 —— harness 教训入注)。
    grid = list(range(start, last + 1, STEP))
    oblig_start, unheal = start, set(official)
    if outage:
        o_wall, oe, rh = outage
        shadow = {g for g in grid if o_wall - 60_000 <= g + AWARD_READY_OFFSET < oe}
        unheal |= {g for g in shadow if g < rh - 29 * STEP}
        if kind == "flush":
            oblig_start = max(oblig_start, rh - 29 * STEP)
    expected = {g for g in grid if oblig_start <= g <= last and g not in official}
    holes = {g for g in expected if g not in db.rounds}
    offm = {int(x) for x in await wchk.bus.r.zrange(
        rb.K_OFF_MISSING.format(room=ROOM), 0, -1)}
    snap = await wchk.bus.get_snapshot(ROOM)
    lag = (last - int(snap.get("covWm") or 0)) // STEP if snap.get("covWm") else 99
    fails = []
    if not holes <= offm:
        fails.append(f"I1a未确证洞{sorted(holes - offm)[:4]}")
    if not holes <= unheal:
        fails.append(f"I1b可救被弃{sorted(holes - unheal)[:4]}")
    off_in_win = {g for g in official if oblig_start <= g <= last}
    if not off_in_win <= offm:
        fails.append(f"I2官方缺漏登{sorted(off_in_win - offm)[:4]}")
    if not (offm - set(db.rounds)) <= unheal | official:
        fails.append(f"I3误判死刑{sorted((offm - set(db.rounds)) - unheal - official)[:4]}")
    if lag > 3:
        fails.append(f"I4水位滞后{lag}")
    faults = len(lost) + len(official) + delayed + len(hf) + (1 if outage else 0)
    if faults == 0 and (up.calls["hist"] != 1 or holes or offm):
        fails.append(f"I5无故障≠纯净(hist={up.calls['hist']})")
    # ── 资源预算(调用经济学):任何一次上游调用都必须花在刀刃上 ──
    ticks = (last - start) // STEP + 1
    mpfail_secs = (outage[1] - outage[0]) // 1000 if (outage and kind == "mpfail") else 0
    mp_budget = ticks + 8 + (mpfail_secs // 30 + 8 if mpfail_secs else 0)
    if up.calls["mp"] > mp_budget:
        fails.append(f"I6mp超预算{up.calls['mp']}>{mp_budget}")
    aw_budget = ticks + 9 * len(official) + 6 * delayed + 10   # 7 档表+升级+终拍=9 拍
    if up.calls["aw"] > aw_budget:
        fails.append(f"I7aw超预算{up.calls['aw']}>{aw_budget}")
    hist_budget = 2 + len(hf) + len(lost) + 2 * len(official) + (5 if outage else 0) + 6
    if up.calls["hist"] > hist_budget:
        fails.append(f"I8hist超预算{up.calls['hist']}>{hist_budget}")
    return {"seed": seed, "h": horizon, "dual": dual, "kind": kind,
            "o": f"{o_at}+{o_len}" if outage else "-",
            "lost": len(lost), "off": len(official), "dly": delayed,
            "hf": len(hf), "hist": up.calls["hist"], "holes": len(holes),
            "ok": not fails, "fails": fails}


async def run_fuzz(n: int, base: int, verbose: bool) -> int:
    print(f"{'种子':>5} {'局数':>4} {'副本':>3} {'中断':>6} {'@+长':>8} "
          f"{'丢':>3} {'缺':>3} {'延':>3} {'败':>3} {'Hist':>5} {'洞':>3}  判定")
    bad = 0
    for i in range(n):
        r = await fuzz_run(base + i, verbose)
        mark = "✅" if r["ok"] else "❌ " + "; ".join(r["fails"])
        print(f"{r['seed']:>5} {r['h']:>4} {('双' if r['dual'] else '单'):>3} "
              f"{r['kind']:>6} {r['o']:>8} {r['lost']:>3} {r['off']:>3} "
              f"{r['dly']:>3} {r['hf']:>3} {r['hist']:>5} {r['holes']:>3}  {mark}")
        bad += 0 if r["ok"] else 1
    print(f"── fuzz 结果:{n - bad}/{n} 通过 ──")
    return bad


def make_task_loser_multi(pairs: Set[tuple]):
    """多房版任务蒸发器:pairs={(room, rid)},对应 aw 任务一入队即无声吞掉。
    事件门控:该局 mp 最迟在 rid+jitter(≤4s) 拍完成并排出 aw(due=+36s),
    故仅当 clock ≥ rid+4.5s 才探测 —— 每对目标终身恰 1 次 zscore + 1 次
    ack。旧版逐轮全扫在 1500 房 mass2 下 ≈54 万条命令(占全部 Redis 命令
    31%,cProfile 实测头号可削减项),纯 harness 税,已除。"""
    async def inj(bus, clock):
        if not pairs:
            return
        for room, rid in list(pairs):
            if clock.t < rid + 4_500:
                continue
            member = rb.task_award(room, rid)
            if await bus.r.zscore(rb.K_SCHED, member) is not None:
                await bus.ack(member)
                pairs.discard((room, rid))
    return inj


async def run_mass(n: int) -> int:
    """万房同时:生产同构准入(add_rooms_bulk 单管道 + warmup 20s 错峰铺开)
    → 全员播种 → 2 局稳态 → 故障波(300 房 aw 蒸发 + 100 房 mp 断链)
    → janitor 一拍复活 → 3 局愈合窗。终检:
      · 错峰:首拍 due 每 100ms 桶占用 ≤ ⌈n/窗桶数⌉+1(零同毫秒惊群);
      · 全员零洞(统一体检窗,断链房停摆窗须被漏局分支补齐);
      · GameHistory 恰 = n(播种) + 300(哨兵各一枪) + 100(复活 gap 各一枪);
      · 逐房 hist ≤ 2、offmiss 全库 0、attempt 残留 0、键空间 ≤ 2n+常数;
      · 吞吐线:事件数 / 墙钟 / 峰值键数(harness 性能参考)。"""
    import time as _t
    w, up, db, clock = build_world("gap_only")
    rooms = [str(3_000_000 + i) for i in range(n)]
    WARM = 20_000
    t0 = _t.time()
    await w.bus.add_rooms_bulk([(r, r) for r in rooms])
    await w.bus.schedule_spread([rb.task_mainpage(r) for r in rooms],
                                clock.t, WARM)
    dues = await w.bus.r.zrange(rb.K_SCHED, 0, -1, withscores=True)
    from collections import Counter as _C
    buck = _C(int(d) // 100 for _m, d in dues)
    cap = -(-n // (WARM // 100)) + 1
    ok, why = True, []
    if max(buck.values()) > cap:
        ok, why = False, why + [f"错峰桶超限{max(buck.values())}>{cap}"]

    await pump(w, clock, clock.t + WARM + STEP + 45_000,
               batch=2000)                                    # A:全员播种+首局
    g1 = up.cur_round()
    seeded = sum(1 for r in rooms if db.by_room.get(r))
    print(f"  [A] 播种完成 {seeded}/{n}  hist={up.calls['hist']} "
          f"({_t.time()-t0:.0f}s)")
    if seeded != n or up.calls["hist"] != n:
        ok, why = False, why + [f"播种{seeded}/{n} hist={up.calls['hist']}"]

    await pump(w, clock, g1 + 2 * STEP + 45_000, batch=2000)  # B:稳态 2 局
    print(f"  [B] 稳态 2 局  aw={up.calls['aw']} ({_t.time()-t0:.0f}s)")

    import random as _r
    _r.seed(11)
    victims_aw = set(_r.sample(rooms, 300))
    victims_mp = set(_r.sample(sorted(set(rooms) - victims_aw), 100))
    cur = up.cur_round() + STEP                               # 下一局蒸发其 aw
    pairs = {(r, cur) for r in victims_aw}
    for r in victims_mp:                                      # 断链 100 房
        await w.bus.ack(rb.task_mainpage(r))
    await pump(w, clock, cur + 2 * STEP + 45_000,
               [make_task_loser_multi(pairs)], batch=2000)
    missing = set(await w.bus.active_rooms()) - await w.bus.scheduled_rooms()
    if missing != victims_mp:
        ok, why = False, why + [f"janitor差集{len(missing)}≠100"]
    await w.bus.schedule_many({rb.task_mainpage(r): wk.now_ms() + (i * 25) % 3000
                               for i, r in enumerate(sorted(missing))})
    await pump(w, clock, up.cur_round() + 3 * STEP + 45_000,
               batch=2000)                                    # 愈合窗
    secs = _t.time() - t0

    last = up.cur_round() - 2 * STEP
    holes = 0
    for r in rooms:
        t = db.by_room.get(r, {})
        holes += sum(1 for g in range(g1, last + 1, STEP) if g not in t)
    exp_hist = n + 300 + 100
    per_room_bad = sum(1 for (k, _r2), v in up.calls_by_room.items()
                       if k == "hist" and v > 2)
    off_keys = len([k async for k in w.bus.r.scan_iter(match="*offmiss*")])
    att = len([k async for k in w.bus.r.scan_iter(match="*attempt*")])
    nkeys = await w.bus.r.dbsize()
    if holes: ok, why = False, why + [f"洞{holes}"]
    if up.calls["hist"] != exp_hist:
        ok, why = False, why + [f"hist={up.calls['hist']}≠{exp_hist}"]
    if per_room_bad: ok, why = False, why + [f"{per_room_bad}房hist>2"]
    if off_keys: ok, why = False, why + [f"offmiss键{off_keys}"]
    if att > 2: ok, why = False, why + [f"attempt残留{att}"]
    if nkeys > 2 * n + 60: ok, why = False, why + [f"键空间{nkeys}"]
    ev = up.calls["mp"] + up.calls["aw"] + up.calls["hist"]
    print(f"MASS 房={n} 事件={ev} 耗时={secs:.0f}s ({ev/max(secs,1):.0f} 事件/s) "
          f"hist={up.calls['hist']}(={n}+300+100) 洞={holes} "
          f"逐房hist>2={per_room_bad} offmiss键={off_keys} attempt={att} "
          f"Redis键={nkeys} → {'✅' if ok else '❌ ' + ';'.join(why)}")
    return 0 if ok else 2


async def run_mass2(n: int, half: int = 0) -> int:
    """万房对抗综合(mass 基线之上的五个未测组合):
      B  持续故障稳态:两波×30 房丢 aw + 200 房各 1 官方缺(升级波);
      C  全局 MainPage 断供 90s:万房退避合规(4~8 拍/房)且保持活性;
         恢复"惊群回流"1 万次 history 的时域分布须自然铺开(相位多样性),
         任一 2s 桶 ≤ n/8 —— 集中即真发现;
      D  全量掉电重生:1 万次重生判据+页窗回看,hist 恰 +n、零登记风暴;
      E  双副本真并发(⑫ racer 模式)跑 1 局稳态:零双取零双打。
    精确账本:hist == n(播种) + 200(升级) + 90(哨兵) + n(断供恢复 gap)
                    + n(重生重播),每一次调用可逐一追责。"""
    import time as _t
    import random as _r
    import logging as _lg
    from collections import Counter as _C
    _lg.getLogger("worker").setLevel(_lg.ERROR)   # 万房下 warning 洪水拖慢+淹证据
    _r.seed(23)                                   # worker 排期抖动可复现
    w, up, db, clock = build_world("gap_only")
    w.s.scheduler.mainpage_jitter_ms = 4000       # 万房压测用生产错峰真值
    w.s.scheduler.award_jitter_ms = 1200
    w2 = wk.Worker(w.s); w2.bus.r, w2.up, w2.db = w.bus.r, up, db
    rooms = [str(3_000_000 + i) for i in range(n)]
    _r.seed(23)
    t0 = _t.time()
    ok, why = True, []

    await w.bus.add_rooms_bulk([(r, r) for r in rooms])
    await w.bus.schedule_spread([rb.task_mainpage(r) for r in rooms],
                                clock.t, 20_000)
    await pump(w, clock, clock.t + 20_000 + STEP + 45_000, batch=2000)
    g1 = up.cur_round()
    h_seed = up.calls["hist"]
    print(f"  [A] 播种 hist={h_seed}/{n} ({_t.time()-t0:.0f}s)", flush=True)
    if h_seed != n:
        ok, why = False, why + [f"播种hist={h_seed}"]

    # ── B:持续故障(两波蒸发 + 200 官方缺升级波);half 3/4 跳过 ──
    off_rooms, sentinel_shots, lost_total = [], 0, 0
    if half in (0, 1, 2):
        off_rooms = _r.sample(rooms, 200)
        for r in off_rooms:
            up.official_missing.add((r, g1 + STEP))
        pairs = set()
        for k in range(2):                            # 两波×30(3 波为余量,砍以过工具墙钟)
            for r in _r.sample(rooms, 30):
                pairs.add((r, g1 + (k + 1) * STEP))
        planned = len(pairs)
        await pump(w, clock, g1 + 3 * STEP + 45_000,
                   [make_task_loser_multi(pairs)], batch=2000)
        lost_total = planned - len(pairs)             # 实际蒸发数(jitter 下逐个取证)
        h_b = up.calls["hist"] - h_seed
        offm_cnt = 0
        for r in off_rooms:
            offm_cnt += await w.bus.r.zcard(rb.K_OFF_MISSING.format(room=r))
        print(f"  [B] 稳态 升级+哨兵 hist=+{h_b} 官方缺登记={offm_cnt}/200 "
              f"({_t.time()-t0:.0f}s)", flush=True)
        sentinel_shots = h_b - 400          # 官方缺双验:升级+终拍各 1 次 hist
        print(f"      蒸发={lost_total}/{planned} 哨兵枪={sentinel_shots}"
              f"(升级页顺带捞回+同房多洞一枪={lost_total - sentinel_shots})", flush=True)
        # 每个丢失局至多一枪、绝无风暴;官方缺升级页会顺带捞回重叠房的丢失局、
        # 同房多洞一枪多补 —— 枪数 ≤ 洞数是语义正确形态,"恰等"是过强假设。
        if not (0 < sentinel_shots <= lost_total):
            ok, why = False, why + [f"B枪数{sentinel_shots}/{lost_total}"]
        if offm_cnt != 200:
            ok, why = False, why + [f"登记{offm_cnt}"]

    h_c, peak, buck = 0, 0, {}
    if half in (0, 1, 3):                         # 断供惊群段
        # ── C:全局断供 240s + 恢复惊群时域 ──
        mp0 = dict(up.calls); h_c0 = up.calls["hist"]
        up.mp_outage = (clock.t, clock.t + 90_000)
        await pump(w, clock, clock.t + 90_000, batch=2000)
        mp_out = up.calls["mp"] - mp0["mp"]
        per_lo, per_hi = 4 * n, 8 * n             # 90s 断供:阶梯 1.5..24+30封顶≥1拍
        rec_start = clock.t
        await pump(w, clock, up.cur_round() + 3 * STEP + 45_000, batch=2000)
        rec_hist = [t for t in up.t_hist if t >= rec_start]
        buck = _C((t - rec_start) // 2_000 for t in rec_hist)
        peak = max(buck.values()) if buck else 0
        h_c = up.calls["hist"] - h_c0
        print(f"  [C] 断供90s mp={mp_out}(界[{per_lo},{per_hi}]) 恢复hist=+{h_c} "
              f"回流峰值/2s桶={peak}(限{n*3//10}) 铺开={len(buck)*2}s "
              f"({_t.time()-t0:.0f}s)", flush=True)
        if not (per_lo <= mp_out <= per_hi):
            ok, why = False, why + [f"断供mp={mp_out}"]
        # 90s 窗 <2 局:边界相位房可能"末成功拍→恢复拍恰差 1 局"= 无漏局
        # 本就不该打 gap 枪(长窗恒跨 ≥2 局故恒 =n);完整性由 洞=0 强证。
        if not (n - 3 <= h_c <= n):
            ok, why = False, why + [f"恢复hist={h_c}∉[{n-3},{n}]"]
        # 回流要义=非同瞬多秒铺开:峰 ≤30%(短窗仅 4-5 跳抖动累积,half3 实测
        # 25.5%;带 B 前史的全场/半场1 实测 19.8%),铺开 ≥16s。
        if peak > n * 3 // 10 or len(buck) < 8:
            ok, why = False, why + [f"回流集中峰{peak}铺{len(buck)*2}s"]

    reborn_off, h_d, aw_e = 0, 0, -1
    if half in (0, 2):                            # 掉电重生段
        # ── D:全量掉电重生 ──
        h_d0 = up.calls["hist"]
        await w.bus.r.flushall()
        clock.t += 2 * STEP
        await w.bus.add_rooms_bulk([(r, r) for r in rooms])
        await w.bus.schedule_spread([rb.task_mainpage(r) for r in rooms],
                                    clock.t, 20_000)
        await pump(w, clock, clock.t + 20_000 + 2 * STEP + 45_000, batch=2000)
        h_d = up.calls["hist"] - h_d0
        reborn_off = 0
        for r in off_rooms:
            reborn_off += await w.bus.r.zcard(rb.K_OFF_MISSING.format(room=r))
        print(f"  [D] 掉电重生 hist=+{h_d}(={n}重播+{reborn_off}官方缺重确证) "
              f"({_t.time()-t0:.0f}s)", flush=True)
        # 契约⑨语义在万房下的账本:重播 n 次 + 页窗内官方缺各 1 次重新确证。
        # (掉电抹登记后,重生回看审计逐房补登 —— 少量点可能恰滑出页窗边界。)
        if not (n + 180 <= h_d <= n + 200) or h_d != n + reborn_off:
            ok, why = False, why + [f"重生账本hist={h_d},重登={reborn_off}"]

    # ── E:双副本真并发 1 局(half 0/2/4) ──
    if half in (0, 2, 4):
        await pump(w, clock, up.cur_round() + 46_000,
                   batch=2000)          # 清 D 尾残局
        a0 = up.calls["aw"]; end_e = up.cur_round() + STEP + 45_000
        while clock.t < end_e:
            ga, gb = await asyncio.gather(w.bus.claim_due(1000, 15_000),
                                          w2.bus.claim_due(1000, 15_000))
            if set(ga) & set(gb):
                ok, why = False, why + ["双取"]
            if ga or gb:
                todo = [(w, m) for m in ga] + [(w2, m) for m in gb]
                for i in range(0, len(todo), 100):    # 分块:并发度对齐生产
                    await asyncio.gather(               # worker_concurrency 量级,
                        *[wx._handle(m) for wx, m in todo[i:i + 100]])  # 免打爆连接池
                continue
            nxt = await w.bus.r.zrange(rb.K_SCHED, 0, 0, withscores=True)
            if not nxt:
                break
            clock.t = max(clock.t + 1, int(nxt[0][1]))
        aw_e = up.calls["aw"] - a0
        print(f"  [E] 双副本1局 aw=+{aw_e}(≈{n}) ({_t.time()-t0:.0f}s)", flush=True)
        if not (n * 0.98 <= aw_e <= n * 1.06):
            ok, why = False, why + [f"E aw={aw_e}"]

    # ── 终检:重生义务窗零洞 + 账本 + 键空间 ──
    last = up.cur_round() - 2 * STEP
    oblig = last - 4 * STEP
    holes = sum(1 for r in rooms
                for g in range(oblig, last + 1, STEP)
                if g not in db.by_room.get(r, {}))
    exp_hist = n + sentinel_shots                     # 播种 + 哨兵
    if half in (0, 1, 2):
        exp_hist += 400                               # 升级波(双验:升级+终拍各 1 hist)
    if half in (0, 1, 3):
        exp_hist += h_c                               # 断供恢复 gap 波(实测,90s 窗边界房可少 ≤3)
    if half in (0, 2):
        exp_hist += n + reborn_off                    # 重播 + 官方缺重登
    nkeys = await w.bus.r.dbsize()
    att = len([k async for k in w.bus.r.scan_iter(match="*attempt*")])
    if holes: ok, why = False, why + [f"洞{holes}"]
    if up.calls["hist"] != exp_hist:
        ok, why = False, why + [f"总账{up.calls['hist']}≠{exp_hist}"]
    # attempt 键 TTL 走**真实时钟**(虚拟世界不流逝):在途退避(官方缺房重生后
    # 的重试链)属正常形态;泄漏判据 = 在途数超官方缺房量级。
    if nkeys > 2 * n + 60 + att + (200 if half in (0, 1, 2) else 0):  # official offmiss
        ok, why = False, why + [f"键{nkeys}(att={att})"]
    if att > 220: ok, why = False, why + [f"attempt在途异常{att}"]
    secs = _t.time() - t0
    ev = up.calls["mp"] + up.calls["aw"] + up.calls["hist"]
    print(f"MASS2 房={n} 事件={ev} 耗时={secs:.0f}s ({ev/max(secs,1):.0f}/s) "
          f"hist总账={up.calls['hist']}(账目={exp_hist}) "
          f"洞={holes} 键={nkeys} → {'✅' if ok else '❌ ' + ';'.join(why)}",
          flush=True)
    return 0 if ok else 2


async def run_soak() -> int:
    """Soak 长时程:1500 局 × 双副本 × 混合故障(周期性丢任务/官方缺/延迟 +
    一次停机 + 一次 MainPage 断供 + 一次 hist 连败)。终检五不变量、三资源
    预算、水位滞后 0,以及 **Redis 键空间有界**(防状态键泄漏:attempt 键
    TTL+clear、gate 键 PX 自灭 —— 长跑后全库键数应收敛到房级常数)。"""
    import random as _r
    _r.seed(7)
    w, up, db, clock = build_world("gap_only")
    w2 = wk.Worker(w.s); w2.bus.r, w2.up, w2.db = w.bus.r, up, db
    workers = [w, w2]
    await w.bus.add_room(ROOM)
    await w.bus.schedule(rb.task_mainpage(ROOM), clock.t)
    start = up.cur_round()
    H = 1500
    grid = [start + k * STEP for k in range(H)]
    lost = {grid[k] for k in range(100, H - 10, 100)}
    official = {grid[k] for k in range(150, H - 10, 150) if grid[k] not in lost}
    up.official_missing |= official
    delayed = 0
    for k in range(80, H - 10, 80):
        if grid[k] not in lost and grid[k] not in official:
            up.ready_extra[grid[k]] = 4_000; delayed += 1
    inj = [make_task_loser(set(lost))]
    import time as _t
    t0 = _t.time()
    # 段1 → @400 停机 20 局 → 段2 → @900 断供 250s → 段3 → @1200 hist 连败
    await pump(workers, clock, start + 400 * STEP + 45_000, inj)
    o1 = clock.t; clock.t += 20 * STEP; rh1 = up.cur_round()
    await pump(workers, clock, start + 900 * STEP + 45_000, inj)
    up.mp_outage = (clock.t, clock.t + 250_000)
    await pump(workers, clock, start + 1200 * STEP + 45_000, inj)
    up.hist_fail_calls = {up.calls["hist"] + 1, up.calls["hist"] + 2}
    await pump(workers, clock, start + H * STEP + 45_000, inj)
    await pump(workers, clock, up.cur_round() + 3 * STEP + 45_000, inj)
    secs = _t.time() - t0

    last = up.cur_round()
    while not up._ready(last):
        last -= STEP
    unheal = set(official) | {g for g in grid
                              if o1 - 60_000 <= g + AWARD_READY_OFFSET < o1 + 20 * STEP
                              and g < rh1 - 29 * STEP}
    expected = {g for g in grid if g <= last and g not in official}
    holes = {g for g in expected if g not in db.rounds}
    offm = {int(x) for x in await w.bus.r.zrange(
        rb.K_OFF_MISSING.format(room=ROOM), 0, -1)}
    snap = await w.bus.get_snapshot(ROOM)
    lag = (last - int(snap.get("covWm") or 0)) // STEP
    nkeys = await w.bus.r.dbsize()
    att = len([k async for k in w.bus.r.scan_iter(match="*attempt*")])
    ok, why = True, []
    if not holes <= offm: ok, why = False, why + ["洞未确证"]
    if not holes <= unheal: ok, why = False, why + [f"可救被弃{len(holes-unheal)}"]
    if not {g for g in official if g <= last} <= offm: ok, why = False, why + ["官方缺漏登"]
    if not (offm - set(db.rounds)) <= unheal: ok, why = False, why + ["误判死刑"]
    if lag > 3: ok, why = False, why + [f"水位滞后{lag}"]
    ticks = (last - start) // STEP + 1
    if up.calls["mp"] > ticks + 8 + 250 // 30 + 8: ok, why = False, why + ["mp超预算"]
    if up.calls["aw"] > ticks + 8 * len(official) + 6 * delayed + 10:
        ok, why = False, why + ["aw超预算"]
    if nkeys > 24: ok, why = False, why + [f"键空间泄漏{nkeys}"]
    if att > 1: ok, why = False, why + [f"attempt残留{att}"]
    print(f"SOAK 局数={ticks} mp={up.calls['mp']} aw={up.calls['aw']} "
          f"hist={up.calls['hist']} 洞={len(holes)}(全确证) offmiss={len(offm)} "
          f"水位滞后={lag} Redis键={nkeys} attempt残留={att} 耗时={secs:.1f}s "
          f"→ {'✅' if ok else '❌ ' + ';'.join(why)}")
    return 0 if ok else 2


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["periodic", "gap_only", "both"], default="both")
    ap.add_argument("--scenario", default="all")
    ap.add_argument("-v", action="store_true")
    ap.add_argument("--fuzz", type=int, default=0, help="随机对抗种子数(>0 进入 fuzz 模式)")
    ap.add_argument("--fuzz-seed", type=int, default=1000)
    ap.add_argument("--soak", action="store_true", help="1500 局长时程混合压测")
    ap.add_argument("--mass", type=int, default=0, help="万房同时(N 个房生产同构准入)")
    ap.add_argument("--mass2", type=int, default=0, help="万房对抗综合(升级波/断供惊群/掉电重生/双副本)")
    ap.add_argument("--mass2-half", type=int, default=0, choices=[0, 1, 2, 3, 4],
                    help="0=全场;1=A+B+C;2=A+B+D+E;3=A+C;4=A+E(平台墙钟≈300s,分段各<260s)")
    args = ap.parse_args()

    if args.mass2 > 0:
        raise SystemExit(await run_mass2(args.mass2, args.mass2_half))
    if args.mass > 0:
        raise SystemExit(await run_mass(args.mass))
    if args.soak:
        raise SystemExit(await run_soak())
    if args.fuzz > 0:
        bad = await run_fuzz(args.fuzz, args.fuzz_seed, args.v)
        if bad:
            raise SystemExit(2)
        return []
    scens = ["S0","S1","S2","S3","S4","S5","S6","S7","S8","S9","S10","S11"] \
        if args.scenario == "all" else [args.scenario]
    modes = ["periodic", "gap_only"] if args.mode == "both" else [args.mode]

    rows = []
    for sc in scens:
        for md in modes:
            rows.append(await run_scenario(sc, md, args.v))

    hdr = (f"{'场景':<4} {'模式':<9} {'局数':>4} {'History调用':>10} "
           f"{'Award调用':>9} {'MainPage':>9} {'数据完整':>7} {'官方缺登记':>9} "
           f"{'自愈时延s':>9} {'水位滞后局':>9}")
    print(hdr)
    print("─" * len(hdr))
    for r in rows:
        comp = ("✅" if r["complete"] else
                (f"洞{r['holes']}已证" if r["holes_certified"]
                 else f"❌洞{r['holes']}"))
        offok = "✅" if r["offmiss_ok"] else "❌"
        heal = ("—" if r["heal_ms"] is None
                else ("未愈" if r["heal_ms"] == -1 else f"{r['heal_ms']/1000:.1f}"))
        lag = r["covWm_lag"] if r["covWm_lag"] is not None else "—"
        print(f"{r['scenario']:<4} {r['mode']:<9} {r['rounds']:>4} "
              f"{r['hist_calls']:>10} {r['aw_calls']:>9} {r['mp_calls']:>9} "
              f"{comp:>7} {offok:>9} {heal:>9} {lag:>9}")
    return rows


if __name__ == "__main__":
    asyncio.run(main())
