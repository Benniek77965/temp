/* 用法:项目根 `npm i --no-save jsdom` 后 `node backend_async/scripts/admin_signals_jsdom.js`(Node ≥20)。

   管理台「疑」视图(疑似脚本来源)整机冒烟。**补的是一个真实存在的覆盖缺口**:
   4.9.0 把该视图的渲染大改(新增 研判辅助 notes / 过期 pow_stale 独立列 / 失败速率 /
   浏览器足迹徽标 / 观察跨度),而这个视图此前**没有任何测试覆盖** —— 后端 API 测得到
   分数,测不到这一层模板。本套件专钉三件事:

     一、新字段都真的渲染出来了(不是写了模板却没进 DOM);
     二、**老后端响应**(没有 notes/pow_stale/fail_rate/span_min/foot 的旧信封)不得
         把 undefined / NaN 漏进页面 —— 升级期新前端配旧后端是必然出现的组合;
     三、渲染全程零未捕获异常,且阈值下拉、空表、未启用三条分支都不炸。
*/
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
const html = fs.readFileSync(ROOT + '/admin.html', 'utf8');
const JS_ARG = process.argv.indexOf('--js');
const adminjs = fs.readFileSync(JS_ARG > 0 ? process.argv[JS_ARG + 1] : ROOT + '/assets/admin.js', 'utf8');

let PASS = 0, FAIL = 0;
const A = (n, c, x) => { console.log(`  [${c ? '✓' : '✗'}] ${n}${x ? '  → ' + x : ''}`);
                         if (c) PASS++; else { FAIL++; process.exitCode = 1; } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* 两种信封:MODERN = 4.9.0 后端;LEGACY = 旧后端(新字段一个都没有) */
const MODERN = { ok: true, enabled: true, now_ms: Date.now(), window_s: 1800, count: 2,
  sources: [
    { sid: 'scraper0001aaaa', uid: 11, uname: 'bot', ip: '9.9.9.9', ua: 'python-requests/2.31',
      first: 0, last: 60000, html: 0, asset: 0, detail: 40, detail_ok: 0,
      pow_ok: 0, pow_fail: 20, pow_stale: 0, sse: 0, rooms: 9, foot: false,
      score: 95, reasons: ['从未加载页面(HTML)、也无任何浏览器足迹,却在访问明细端点',
                           '执行证明失败 20 次、从未通过(疑似不执行 JS)'],
      notes: ['明细请求成功率 0/40'], span_min: 1.0, fail_rate: 20.0, room_rate: 9.0 },
    { sid: 'human0002bbbb', uid: 7, uname: '真人', ip: '1.2.3.4', ua: 'Mozilla/5.0 Safari',
      first: 0, last: 1800000, html: 0, asset: 0, detail: 68, detail_ok: 58,
      pow_ok: 58, pow_fail: 0, pow_stale: 3, sse: 2, rooms: 1, foot: true,
      score: 0, reasons: [],
      notes: ['执行证明通过 58 次 —— 对方确实在执行本站 JS',
              '同一会话此前加载过页面/静态资源(长效足迹仍在)',
              '3 次证明因**服务端挑战过期/轮转**未命中(良性,不计疑度)',
              '持有 2 次 SSE 实时流(浏览器长连形态)',
              '明细请求成功率 58/68', '观察跨度 ≈30 分钟'],
      span_min: 30.0, fail_rate: 0.0, room_rate: 0.03 }] };

const LEGACY = { ok: true, enabled: true, now_ms: Date.now(), window_s: 1800, count: 1,
  sources: [
    { sid: 'legacy0003cccc', uid: 3, uname: 'old', ip: '5.5.5.5', ua: 'curl/8.0',
      first: 0, last: 0, html: 0, asset: 0, detail: 20, detail_ok: 0,
      pow_ok: 0, pow_fail: 20, sse: 0, rooms: 9,
      score: 100, reasons: ['从未加载页面(HTML)却在访问明细端点'] }] };
/*      ↑ 刻意不带 notes / pow_stale / fail_rate / span_min / foot */

let SIG = MODERN;
function route(url) {
  if (url.endsWith('/login')) return { ok: true, token: 'tok', csrf: 'csrf', version: '1.7.4' };
  if (url.includes('/signals')) return SIG;
  if (url.includes('/leases')) return { ok: true, enabled: true, now_ms: Date.now(),
                                        ttl_ms: 40000, count: 0, leases: [] };
  if (url.includes('/overview')) return { ok: true };
  return { ok: true };
}

(async () => {
  console.log('管理台「疑」视图整机冒烟 —— 交付版 admin.html + admin.js @ jsdom\n');
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => { if (!/Not implemented/.test(e.message)) console.log('  · jsdomError:', e.message.slice(0, 90)); });
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
                                url: 'http://localhost/', virtualConsole: vc });
  const w = dom.window;
  const jsErrs = [];
  w.addEventListener('error', e => jsErrs.push(e.message || String(e.error)));
  w.fetch = async (input) => {
    const url = typeof input === 'string' ? input : input.url;
    const b = route(url);
    return { ok: true, status: 200, headers: { get: () => null },
             json: async () => b, text: async () => JSON.stringify(b) };
  };
  w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){} };
  w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
  w.matchMedia = q => ({ matches: false, media: q, addEventListener(){}, removeEventListener(){},
                         addListener(){}, removeListener(){} });
  w.scrollTo = () => {};
  const _ls = {};
  Object.defineProperty(w, 'localStorage', { value: {
    getItem: k => (k in _ls ? _ls[k] : null), setItem: (k, v) => { _ls[k] = String(v); },
    removeItem: k => { delete _ls[k]; }, clear: () => { for (const k in _ls) delete _ls[k]; } },
    configurable: true });

  const sc = w.document.createElement('script');
  sc.textContent = adminjs;
  w.document.body.appendChild(sc);
  await sleep(150);

  const $ = s => w.document.querySelector(s);
  const $$ = s => [...w.document.querySelectorAll(s)];
  const click = el => el && el.dispatchEvent(new w.Event('click', { bubbles: true }));

  $('#pw').value = 'x'; click($('#loginBtn')); await sleep(200);
  A('管理台登录后进入 shell', $('#shell').classList.contains('on'));

  const nav = $$('.nav-item').find(b => b.dataset.view === 'signals');
  A('左栏存在「疑」导航项', !!nav);
  click(nav); await sleep(300);

  console.log('\n── 一、4.9.0 新字段确实进了 DOM ──────────────────────────────');
  let t = $('#main').textContent;
  A('视图标题渲染', /疑似脚本来源/.test(t));
  A('说明里点明「速率制 + 无罪证据」的新口径', /速率制/.test(t) && /无罪证据/.test(t));
  A('表头改为「研判依据 / 辅助」', /研判依据 \/ 辅助/.test(t));
  A('研判辅助(notes)渲染出来', /辅助:/.test(t) && /执行证明通过 58 次/.test(t));
  A('「过期」独立列渲染(pow_stale 不再混进证明✗)', /过期/.test(t));
  A('失败速率随证明✗ 一并显示', /20\/分/.test(t), (t.match(/[\d.]+\/分/) || [])[0]);
  const counts0 = $$('.sig-counts').map(e => e.textContent).join(' ');
  A('浏览器足迹徽标只在有足迹的行出现',
    (counts0.match(/浏览器足迹 ✓/g) || []).length === 1, counts0.slice(0, 80));
  A('观察跨度显示在计数格', /跨度 30 分/.test(counts0));
  A('真人行分数为 0 且无依据', /无明显特征/.test(t));

  console.log('\n── 二、老后端信封:不得漏 undefined / NaN ─────────────────────');
  SIG = LEGACY;
  const sel = $('#sgThr');
  A('阈值下拉存在', !!sel);
  sel.value = '0'; sel.dispatchEvent(new w.Event('change', { bubbles: true }));
  await sleep(300);
  t = $('#main').textContent;
  A('老信封仍能渲染出行', /legacy0003/.test(t) || /old/.test(t));
  A('页面里没有 undefined', !/undefined/.test(t), (t.match(/.{0,18}undefined.{0,18}/) || [''])[0]);
  A('页面里没有 NaN', !/NaN/.test(t), (t.match(/.{0,18}NaN.{0,18}/) || [''])[0]);
  A('缺 fail_rate 时不硬塞「/分」后缀', !/undefined\/分/.test(t) && !/NaN\/分/.test(t));
  /* 断言必须收窄到**表格计数格**:视图说明(.view-sub)里本就写着「浏览器足迹」
     「观察跨度」这两个词(那是给运营者看的口径说明),拿整个 #main 去判会假红。 */
  const counts = () => $$('.sig-counts').map(e => e.textContent).join(' ');
  A('缺 foot 时不显示足迹徽标', !/浏览器足迹/.test(counts()), counts().slice(0, 70));
  A('缺 span_min 时不显示跨度', !/跨度/.test(counts()));
  A('缺 notes 时不留空的「辅助:」', !/辅助:\s*<\/div>/.test($('#main').innerHTML));

  console.log('\n── 三、其余分支不炸 ─────────────────────────────────────────');
  SIG = { ok: true, enabled: true, now_ms: Date.now(), window_s: 1800, count: 0, sources: [] };
  sel.value = '70'; $('#sgThr').dispatchEvent(new w.Event('change', { bubbles: true }));
  await sleep(300);
  A('空表分支给出「这通常是好事」的说明', /这通常是好事/.test($('#main').textContent));

  SIG = { ok: true, enabled: false, sources: [], now_ms: Date.now() };
  $('#sgThr') && $('#sgThr').dispatchEvent(new w.Event('change', { bubbles: true }));
  await sleep(300);
  A('未启用遥测分支给出开关提示', /STA_USER_SIGNAL_SCORING/.test($('#main').textContent));

  A('全程零未捕获异常', jsErrs.length === 0, jsErrs.join(' | ').slice(0, 120));

  console.log('\n' + '─'.repeat(52));
  console.log(`管理台「疑」视图冒烟:${PASS} 通过 / ${FAIL} 失败`);
})();
