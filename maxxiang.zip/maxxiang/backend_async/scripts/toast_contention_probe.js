/* TOAST 争用实测:载入交付版 index.html + app.js,在真 DOM 上驱动 toast 管线。
   用法:项目根 `node backend_async/scripts/toast_contention_probe.js` */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(__dirname, '..', '..');
const html = fs.readFileSync(ROOT + '/index.html', 'utf8');
const appjs = fs.readFileSync(ROOT + '/assets/app.js', 'utf8');
const adminjs = fs.readFileSync(ROOT + '/assets/admin.js', 'utf8');
const admincss = fs.readFileSync(ROOT + '/assets/admin.css', 'utf8');

const dom = new JSDOM(html, { url: 'http://localhost/', pretendToBeVisual: true,
                              runScripts: 'dangerously' });
const w = dom.window;
w.fetch = async () => ({ ok: true, status: 200, headers: { get: () => null },
                         json: async () => ({ ok: true }) });
w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){} };
w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
w.PerformanceObserver = class { observe(){} disconnect(){} };
w.matchMedia = w.matchMedia || (q => ({ matches:false, media:q, addEventListener(){},
                                        removeEventListener(){}, addListener(){}, removeListener(){} }));
w.scrollTo = () => {};

const sleep = ms => new Promise(r => setTimeout(r, ms));
const $ = s => w.document.querySelector(s);
let bad = 0;
const A = (n, c, extra) => { console.log(`  [${c ? '✓' : '✗'}] ${n}${extra ? '  → ' + extra : ''}`);
                             if (!c) { bad++; process.exitCode = 1; } };

(async () => {
  w.innerWidth = 1280; w.innerHeight = 900;
  const sc = w.document.createElement('script');
  sc.textContent = appjs;
  w.document.body.appendChild(sc);
  await sleep(200);

  const T = $('#toast');
  console.log('\n══ 一、动作型 toast 被信息型 toast 无声抢占 ══════════════════════');
  w.eval(`toastAction('已跟随到 999 —— 由另一窗口/设备切换',
           { label:'切回 888', ms:8000, onClick:()=>{ window.__CLICKED = true; } })`);
  const btn0 = T.querySelector('.toast-act');
  A('toastAction 建出「切回」按钮', !!btn0, btn0 && btn0.textContent);
  console.log('     [模拟 followRoom 的下一行:loadRoom() 链路里的普通 toast]');
  w.eval(`toast('正在观测 999 房')`);
  const btn1 = T.querySelector('.toast-act');
  A('普通 toast 之后「切回」按钮已被抹除', btn1 === null,
    '距按钮出现仅 ~0ms,承诺展示 8000ms');
  A('文案也被换成了信息型内容', T.textContent === '正在观测 999 房', T.textContent);
  A('用户已无法再触发 onClick(动作永久丢失)', w.__CLICKED !== true);

  console.log('\n══ 二、8000ms 承诺被 2400ms 计时器接管(提前 5.6s 消失)══════════');
  // 直接观察 timer:再摆一次 8s 动作 toast,然后普通 toast,量它实际何时 hidden
  w.eval(`toastAction('A', { label:'X', ms:600, onClick:()=>{} })`);
  await sleep(50);
  w.eval(`toast('B')`);          // 普通 toast 把 timer 重置为 2400
  await sleep(700);              // 已超过 600ms 承诺
  A('后到的 2400ms 计时器接管了先前的短计时(单管线последний-wins)',
    T.hidden === false, 'hidden=' + T.hidden);
  T.hidden = true;

  console.log('\n══ 三、已显示态下换文案:无任何视觉线索(rise 动画不重放)══════════');
  const cssText = fs.readFileSync(ROOT + '/assets/app.css', 'utf8');
  const m = cssText.match(/\.toast\{[^}]*\}/);
  A('.toast 的出现动画仅绑定在元素本身(靠 hidden 翻转触发)',
    /animation:\s*rise/.test(m ? m[0] : ''), (m ? m[0] : '').match(/animation:[^;]*/));
  w.eval(`toast('第一条重要提示')`);
  const h1 = T.hidden;
  w.eval(`toast('第二条完全不同的提示')`);
  A('第二条到达时元素从未回到 hidden(动画不会重放)', h1 === false && T.hidden === false,
    '连续提示只换字,不闪不动 → 用户会直接错过');

  console.log('\n══ 四、jfToast 的 4s 去抖跨内容、跨管线不对称 ═════════════════════');
  T.hidden = true;
  w.eval(`_jfToastAt = 0`);
  w.eval(`jfToast('同一账号同一时间只能监控 1 个直播间')`);
  const first = T.textContent;
  w.eval(`jfToast('另一条完全不同的重要提示')`);
  A('4s 内不同内容的 jfToast 被整条丢弃', T.textContent === first, '仍是:' + T.textContent);
  w.eval(`toast('普通 toast 不更新 _jfToastAt')`);
  const gapBefore = w.eval('_jfToastAt');
  A('toast() 不参与 jfToast 的节流账本(两条管线互不感知)',
    w.eval('_jfToastAt') === gapBefore);

  console.log('\n══ 五、admin.js 的 toast:淡出后留下隐形点击拦截条 ════════════════');
  const dom2 = new JSDOM('<!doctype html><html><body><div id="main"></div></body></html>',
                         { url: 'http://localhost/admin', pretendToBeVisual: true,
                           runScripts: 'dangerously' });
  const w2 = dom2.window;
  A('admin.css 中完全没有 #toast / .toast 规则',
    !/#toast|\.toast/.test(admincss), '样式全部内联在 JS 里');
  // 复刻 admin.js:274 的 toast 实现(逐行取自源码)
  const src = adminjs.split('\n').slice(273, 284).join('\n');   // admin.js:274-284 = toast() 实现
  A('实现里出现 opacity 淡出', /opacity\s*=\s*'1'/.test(src) && /opacity\s*=\s*'0'/.test(src));
  A('实现里从不设置 hidden / display:none',
    !/\.hidden\s*=\s*true/.test(src) && !/display\s*:\s*none/.test(src));
  A('内联样式里没有 pointer-events:none', !/pointer-events/.test(src));
  A('内联样式里没有 role/aria-live(读屏不播报)', !/aria-live|role=/.test(src));
  console.log('     [该元素残留后的几何]:',
    ['position:fixed','bottom:26px','left:50%','z-index:99','max-width:86vw']
      .filter(k => src.includes(k)).join(' / '));
  // 真 DOM 复现:在 admin 文档里跑一遍这段实现,量淡出后元素是否仍在命中测试面上
  const s2 = w2.document.createElement('script');
  s2.textContent = 'var $ = s => document.querySelector(s);\n' + src + "\ntoast('保存成功');";
  w2.document.body.appendChild(s2);
  const el2 = w2.document.querySelector('#toast');
  await sleep(60);
  el2.style.opacity = '0';                       // 等价于 2600ms 后计时器所做的唯一动作
  const cs = w2.getComputedStyle(el2);
  A('淡出后元素仍在 DOM 内、display 非 none、pointer-events 非 none',
    !!el2.parentNode && cs.display !== 'none' && cs.pointerEvents !== 'none',
    `display=${cs.display} pointerEvents=${cs.pointerEvents || '(默认 auto)'} opacity=${cs.opacity}`);
  A('结论:首次 toast 后底部中央永久驻留一条不可见但吃点击的横条',
    !!el2.parentNode && cs.display !== 'none' && cs.pointerEvents !== 'none');

  console.log('\n══ 六、jiufa 子页 / round-engine 是否另有 toast 管线 ═══════════════');
  const others = ['jiufa/sim-hud.js','jiufa/jf-boot.js','jiufa/jf-fix.js','jiufa/jf-coin.js',
                  'jiufa/jf-num.js','jiufa/bridge.js','jiufa/sim-engine.js',
                  'assets/round-engine.js'];
  let anyToast = false;
  for (const f of others) {
    const p = path.join(ROOT, f);
    if (!fs.existsSync(p)) continue;
    if (/toast/i.test(fs.readFileSync(p, 'utf8'))) { anyToast = true; console.log('     有 toast:', f); }
  }
  A('iframe 子页与引擎层零 toast(无跨文档争用面)', !anyToast);

  console.log('\n' + '='.repeat(70));
  console.log(bad === 0 ? 'TOAST 实测:全部断言成立(问题均已复现)' : `有 ${bad} 条断言不成立`);
})();
