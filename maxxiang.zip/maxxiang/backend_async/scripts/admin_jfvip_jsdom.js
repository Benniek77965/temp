/* admin_jfvip_jsdom.js — 管理台「值」视图整机冒烟(4.2.0)
   用法:项目根 `npm i jsdom` 后 `node backend_async/scripts/admin_jfvip_jsdom.js`

   为什么必须真跑:上一轮的教训 —— `new Function` 语法检查测不出运行时错误
   (SSE 的 UnboundLocalError、前端的 DOM 缺位都是靠真跑才逮到的)。
   本脚本让交付版 admin.html + admin.js 在真 DOM 里执行,只桩网络。 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
/* --js / --html:指向**混淆产物**做验收(与 frontend_reg_jsdom.js 同款约定)。
   缺省读仓库源码。部署前建议两者都跑一遍 —— 用户最终拿到的是产物,
   源码能跑不等于产物能跑(混淆器会重写标识符与字符串)。 */
const _ARGJ = process.argv.indexOf('--js');
const _ARGH = process.argv.indexOf('--html');
const html = fs.readFileSync(_ARGH > 0 ? process.argv[_ARGH + 1] : ROOT + '/admin.html', 'utf8');
const js = fs.readFileSync(_ARGJ > 0 ? process.argv[_ARGJ + 1] : ROOT + '/assets/admin.js', 'utf8');


let PASS = 0, FAIL = 0;
const A = (n, c, e) => { console.log(`  [${c ? '✓' : '✗'}] ${n}${c ? '' : '  → ' + (e || '')}`);
                         if (c) PASS++; else { FAIL++; process.exitCode = 1; } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

const PLANS = [{code:'d3',name:'3 天',price:18,jfHours:72,ddHours:72,tag:''},
               {code:'m1',name:'1 个月',price:88,jfHours:744,ddHours:744,tag:'最多人选'},
               {code:'m3',name:'3 个月',price:188,jfHours:2232,ddHours:2232,tag:'最划算'}];

/* 4.2.5:新增 fail 参数 —— 本脚本此前**每一条桩都回 {ok:true, status:200}**,
   零个错误路径断言。正因如此,「值」视图 8 处错误分支全部把 api() 抛出的
   {status,data} 当成 Error 读 .message,一律渲染成 `[object Object]`,
   却能一路绿到交付。happy path 全绿 ≠ 没问题。 */
async function boot(enabled = true, fail = null) {
  const errs = [], calls = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => errs.push(String(e && e.message || e)));
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
                                url: 'http://localhost/admin#/jfvip', virtualConsole: vc });
  const w = dom.window;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({matches:false, media:q, addEventListener(){}, removeEventListener(){},
                        addListener(){}, removeListener(){}});
  w.ResizeObserver = class { observe(){} disconnect(){} unobserve(){} };
  w.fetch = async (url, opt = {}) => {
    calls.push({url: String(url), method: (opt && opt.method) || 'GET'});
    let b = {ok: true};
    const u = String(url);
    if (fail && u.includes(fail.match)) {          // 错误路径注入
      return {ok: fail.status < 400, status: fail.status, json: async () => fail.body};
    }
    if (u.includes('/admin/session')) b = {ok:true, authed:true, csrf:'c', rev:1};
    else if (u.includes('/admin/schema')) b = {ok:true, fields:{}, sections:[]};
    else if (u.includes('/jfvip/overview')) b = enabled
      ? {ok:true, enabled:true, plans:PLANS, vipAlive:12,
         today:{grants:3, amount:264}, week:{grants:9, amount:792},
         byPlan:{d3:2,m1:6,m3:1}, freeVisits7d:47, cardsUnused:38,
         site:{directHosts:['jiufa.example.com','www.jiufa.example.com'], trustXfh:false}}
      : {ok:true, enabled:false};
    else if (u.includes('/jfvip/cards')) b = {ok:true, total:137, page:1, size:50, items:[
        {id:1, card:'TLAAAAAA234567', plan:'m1', batch:'B1', note:'', disabled:false,
         used:false, usedName:'', usedAt:'', createdBy:'admin', createdAt:'2026-07-22T00:00:00'},
        {id:2, card:'JFBBBBBB345678', plan:'d3', batch:'B1', note:'历史前缀卡', disabled:false,
         used:true, usedName:'u7', usedAt:'2026-07-22T01:00:00', createdBy:'admin', createdAt:''}]};
    else if (u.includes('/jfvip/orders')) b = {ok:true, total:1, page:1, size:50, items:[
        {id:1, orderNo:'ff2f1a41', userId:7, userName:'u7', plan:'d3', amount:17.99,
         status:'paid', credited:true, simulate:false,
         createTime:'2026-07-22T00:00:00', payTime:'2026-07-22T00:01:00'}]};
    else if (u.includes('/jfvip/grants')) b = {ok:true, total:1, page:1, size:50, items:[
        {id:1, userId:7, userName:'u7', source:'order', ref:'ff2f1a41', plan:'d3',
         amount:17.99, jfHours:72, ddHours:72, vipBefore:'', vipAfter:'2026-07-25T00:00:00',
         dueBefore:'', dueAfter:'2026-07-25T00:00:00', operator:'',
         createdAt:'2026-07-22T00:01:00'}]};
    else if (u.includes('/jfvip/user')) b = {ok:true, userId:7, userName:'u7',
         ddDueTime:'2026-08-01 00:00:00', ddAlive:true, vipUntil:'2026-07-25T00:00:00',
         vipDays:3, alive:true, totalHours:72};
    return {ok:true, status:200, json: async () => b, text: async () => JSON.stringify(b)};
  };
  const sc = w.document.createElement('script');
  sc.textContent = js.replace(/^\s*export\s+/gm, '');
  w.document.body.appendChild(sc);
  await sleep(300);
  return {w, d: w.document, errs, calls};
}

(async () => {
  console.log('\n管理台「值」视图冒烟(真 DOM)\n' + '─'.repeat(52));
  {
    const {w, d, errs, calls} = await boot(true);
    console.log('\n[启用态]');
    A('左栏有「值」印章', !!d.querySelector('[data-view="jfvip"]'));
    // 直接切到该视图
    d.querySelector('[data-view="jfvip"]').click(); await sleep(260);   // 走 UI 点击而非 eval 内部函数名:混淆产物会重命名顶层函数
    A('面包屑=九法VIP与充值', d.getElementById('crumb').textContent.includes('九法VIP'),
      d.getElementById('crumb').textContent);
    A('调了 /jfvip/overview', calls.some(c => c.url.includes('/jfvip/overview')));
    const t = d.getElementById('main').textContent;
    A('概览显示在期人数', t.includes('12'));
    A('概览显示今日金额', t.includes('264'));
    A('概览显示 free 档到访(转化漏斗)', t.includes('47'));
    A('档位表三档齐全', t.includes('3 天') && t.includes('1 个月') && t.includes('3 个月'));
    A('档位表显示赠送时长', t.includes('744h') && t.includes('2232h'));
    /* ★ 4.4.1 站点分流读数:显示的必须是**服务端解析后的生效值**。
       启动横幅只在开机时打一次,而本项可热改 —— 改完之后这里是唯一的运行时读数,
       运维要靠它复核有没有漏写 www。(初版把 site 加进了 overview() 载荷却没人渲染,
       等于白加 —— 本条断言就是为了不让那种死负载再次出现。) */
    A('概览显示站点分流生效值', t.includes('jiufa.example.com')
      && t.includes('www.jiufa.example.com'), '未渲染 directHosts');
    A('说明其余域名按镜像站', t.includes('代理镜像站'));
    A('说明站点身份取自哪个头', t.includes('Host 头'));
    A('五个页签渲染', d.querySelectorAll('[data-jv]').length === 5);
    // 卡密页
    d.querySelector('[data-jv="cards"]').click(); await sleep(220);
    const t2 = d.getElementById('main').textContent;
    A('卡密页出场', t2.includes('发卡'), t2.slice(0, 60));
    A('卡密列表渲染(新前缀 TL)', t2.includes('TLAAAAAA234567'));
    A('历史前缀 JF 卡仍照常列出', t2.includes('JFBBBBBB345678'));
    A('状态区分未使用/已使用', t2.includes('未使用') && t2.includes('已使用'));
    A('单批上限提示', t2.includes('500'));
    /* ★ 分页器此前从未被测过(fixture 只有 2 条,pages<=1 直接返空串)。
       初版把回调**字符串化**塞进内联 onclick,而 admin.js 是 module ——
       顶层的 JV / renderJfvip 不在全局,点击必 ReferenceError,
       任何超过一页的列表都翻不动(发卡单批 500,必然触发)。 */
    const pager = d.querySelector('.jv-pager');
    A('分页器出场(total=137 / size=50 → 3 页)', !!pager);
    A('分页器无内联 onclick(module 下必失效 + CSP 会拦)',
      !!pager && ![...pager.querySelectorAll('button')].some(b => b.hasAttribute('onclick')));
    const next = pager && pager.querySelector('[data-jvp="next"]');
    A('「下一页」可点(未被 disabled)', !!next && !next.disabled);
    let pagerErr = null;
    w.addEventListener('error', e => { pagerErr = e.message; });
    try { next.click(); } catch (e) { pagerErr = e.message; }
    await sleep(200);
    A('点下一页不报错(闭包保留)', !pagerErr, pagerErr || '');
    A('确实翻到了第 2 页',
      calls.some(c => /jfvip\/cards\?page=2/.test(c.url)),
      calls.filter(c => c.url.includes('/jfvip/cards')).map(c => c.url).join(' | '));
    // 订单页
    d.querySelector('[data-jv="orders"]').click(); await sleep(220);
    const t3 = d.getElementById('main').textContent;
    A('订单页出场', t3.includes('在线充值订单'));
    A('金额按网关真实值显示(17.99)', t3.includes('17.99'));
    /* ★ 4.2.6:此前「订单」页只有一个状态下拉 + 上/下页两颗按钮,而后端
       orders_page 早就支持 uid、前端从未传过。运维要找一笔单只能一页页翻。
       本轮补齐十项检索,并把每个字段钉在这里 —— 少一个都算功能退化。 */
    for (const [id, name] of [['jvOrdNo', '订单号'], ['jvOrdUser', '用户名'],
                              ['jvFlt', '状态'], ['jvOrdPlan', '档位'],
                              ['jvOrdFrom', '下单起'], ['jvOrdTo', '下单止'],
                              ['jvOrdAmin', '金额下限'], ['jvOrdAmax', '金额上限'],
                              ['jvOrdSim', '是否模拟'], ['jvOrdCred', '是否入账']])
      A(`订单检索有「${name}」(#${id})`, !!d.getElementById(id));
    A('订单表新增「入账」列(此前只藏在 CSV 里)', t3.includes('入账'));
    A('有「重置」一键清空全部条件', !!d.getElementById('jvFltReset'));
    // 填一组条件按查询,断言真的进了请求串(而不是只在界面上摆着)
    d.getElementById('jvOrdNo').value = 'ff2f';
    d.getElementById('jvOrdUser').value = 'u7';
    d.getElementById('jvOrdAmin').value = '10';
    d.getElementById('jvFlt').value = 'paid';
    d.getElementById('jvFltGo').click(); await sleep(240);
    const q = calls.filter(c => c.url.includes('/jfvip/orders')).pop().url;
    A('订单号进了请求串', /orderNo=ff2f/.test(q), q);
    A('用户名进了请求串', /userName=u7/.test(q), q);
    A('金额下限进了请求串', /amtMin=10/.test(q), q);
    A('状态进了请求串', /status=paid/.test(q), q);
    // 「重置」必须把条件从请求串里真的拿掉,而不只是清空输入框
    d.getElementById('jvFltReset').click(); await sleep(240);
    const q2 = calls.filter(c => c.url.includes('/jfvip/orders')).pop().url;
    A('重置后条件真的从请求串消失', !/orderNo=|userName=|amtMin=|status=/.test(q2), q2);
    A('无筛选时请求串不带多余的 &', !/&\s*$/.test(q2), q2);
    /* ★ 分页器:旧版第一行是 `if (pages<=1) return ''` —— 单页时整条凭空消失,
       运维只会以为"这页没有分页功能"(这正是本轮的起因)。现在必须常驻。 */
    const opg = d.querySelector('.jv-pager');
    A('单页也渲染分页条(不再凭空消失)', !!opg, '单页时分页器缺席');
    A('单页时四向按钮全禁用', !!opg
      && [...opg.querySelectorAll('[data-jvp]')].every(b => b.disabled));
    A('分页条显示总条数', !!opg && /共\s*1\s*条/.test(opg.textContent), opg && opg.textContent);
    A('有每页条数选择器', !!opg && !!opg.querySelector('[data-jvps]'));
    /* 四向按钮必须**渲染出真实的动作名** —— 契约测试只能看到 `data-jvp="${act}"`
       这个模板,拼错动作名(btn('frist'))在源码扫描里是看不出来的:
       按钮照样出,绑定端却落进 else 分支静默跳回第 1 页。这里看真 DOM。 */
    for (const a of ['first', 'prev', 'next', 'last'])
      A(`分页条渲染出 data-jvp="${a}"`, !!opg && !!opg.querySelector(`[data-jvp="${a}"]`));
    // 流水页
    d.querySelector('[data-jv="grants"]').click(); await sleep(220);
    const t4 = d.getElementById('main').textContent;
    A('流水页出场', t4.includes('开通流水'));
    A('明示唯一对账口径与边界', t4.includes('对账'));
    // 用户页
    d.querySelector('[data-jv="user"]').click(); await sleep(220);
    d.getElementById('jvUName').value = 'u7';
    d.getElementById('jvUGo').click(); await sleep(240);
    const t5 = d.getElementById('main').textContent;
    A('用户查询出结果', t5.includes('u7'));
    A('显示两条独立时间线', t5.includes('小叮当到期') && t5.includes('九法VIP到期'));
    A('显示当前档位', /vip|basic|free/.test(t5));
    A('撤销说明了不回收小叮当', t5.includes('不回收'));
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }
  {
    const {w, d, errs} = await boot(false);
    console.log('\n[未启用态]');
    d.querySelector('[data-view="jfvip"]').click(); await sleep(260);   // 走 UI 点击而非 eval 内部函数名:混淆产物会重命名顶层函数
    const t = d.getElementById('main').textContent;
    A('提示未启用', t.includes('未启用'));
    A('给出预检命令(开启前必跑)', t.includes('jfvip-preflight'));
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }
  console.log('\n' + '─'.repeat(52));
  console.log(`管理台「值」冒烟:${PASS} 通过 / ${FAIL} 失败`);
})();
