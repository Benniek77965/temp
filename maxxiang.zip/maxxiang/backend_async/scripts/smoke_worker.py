#!/usr/bin/env python3
"""
smoke_worker.py — worker 抓取编排链集成冒烟(假上游,真 Redis + 真 PG)
================================================================================
不接真实游戏服务器,用 FakeUpstream 返回预制的 MainPage / GameHistory / RoundAward,
驱动 worker 跑一个完整周期,验证整条编排链:

  MainPage(拿本局计时 + 首见回填历史)
    → 排 award(构造成「出怪已过」→ 立即到期)
    → RoundAward 入库(幂等)
    → 结算上一局(无 pending 时跳过)+ 生成下一局预测(复用旧引擎)
    → 写快照 latestRoundId + 向 Redis 频道推「新出怪」SSE

断言(全部在真实 PG/Redis 上核验):
  1) 目标局落入 rounds 表;
  2) 首见回填的历史局也在 rounds 表(≥10 局);
  3) predictions 表出现「下一局(round+步进)」的预测,main/guard 非空且编号 1..9;
  4) 快照 latestRoundId 已更新;
  5) draws:{room} 频道确有一条「新出怪」事件被发布(用独立订阅者接住)。
"""
import asyncio
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

os.environ.setdefault("STA_PG_DSN", "postgresql://star:star@127.0.0.1:5432/spelltamer")
os.environ.setdefault("STA_REDIS_URL", "redis://127.0.0.1:6379/0")
os.environ["STA_WORKER_CONCURRENCY"] = "4"   # 测试不必开 800 个 consumer

from app.constants import ROUND_STEP, DRAW_OFFSET_MS, END_OFFSET_MS, SPELL_OFFSET_MS  # noqa: E402
from app.redis_bus import RedisBus, task_mainpage  # noqa: E402
from app.settings import settings  # noqa: E402
from app.worker import Worker  # noqa: E402

ROOM = "9000001"
# 妖兽官方 id → 名称(与引擎一致),用于构造历史/出怪
BEAST_SEQ = [1, 2, 3, 4, 5, 6, 7, 8, 9]  # official ids
BEAST_NAME = {1: "金羽皇", 2: "苍梧魔", 3: "沧溟龙", 4: "焚天雀", 5: "镇岳甲",
              6: "白虹骥", 7: "踏荒牛", 8: "青鸾凤", 9: "玄兵猿"}


class FakeUpstream:
    """按 worker 期望的形状返回预制数据。构造成:本局出怪已过 → award 立即到期。"""

    def __init__(self):
        now = int(time.time() * 1000)
        # 让「本局」的出怪时刻落在 5 秒前,award 排程即刻到期
        self.start_ms = now - 45_000
        self.award_oid = 3          # 沧溟龙 → custom_id 9
        self.calls = {"main_page": 0, "round_award": 0, "game_history": 0}

    async def start(self): ...
    async def close(self): ...

    async def main_page(self, activity_id, room_id):
        self.calls["main_page"] += 1
        s = self.start_ms
        return {"roundId": s, "serverTime": s + 45_000,
                "spellTime": s + SPELL_OFFSET_MS, "drawTime": s + DRAW_OFFSET_MS,
                "endTime": s + END_OFFSET_MS, "canPlay": True}

    async def round_award(self, activity_id, room_id, round_id):
        self.calls["round_award"] += 1
        return {"beastInfo": {"beastId": self.award_oid,
                              "beastName": BEAST_NAME[self.award_oid]}}

    async def game_history(self, activity_id, room_id):
        self.calls["game_history"] += 1
        games = []
        for k in range(1, 21):  # 20 局历史(比目标局更早)
            rid = self.start_ms - k * ROUND_STEP
            oid = BEAST_SEQ[(k) % 9]
            games.append({"roundId": rid,
                          "beastInfo": {"beastId": oid, "beastName": BEAST_NAME[oid]}})
        return {"gameList": games}

    async def pop_list(self, activity_id): return {}
    async def lamp_list(self, activity_id, room_id): return {}


async def _subscriber(bus: RedisBus, room: str, sink: list, stop: asyncio.Event):
    ps = bus.r.pubsub()
    await ps.subscribe(bus.draw_channel(room))
    try:
        while not stop.is_set():
            msg = await ps.get_message(ignore_subscribe_messages=True, timeout=0.5)
            if msg and msg.get("type") == "message":
                data = msg["data"]
                if isinstance(data, bytes):
                    data = data.decode()
                sink.append(json.loads(data))
    finally:
        await ps.unsubscribe(bus.draw_channel(room))
        await ps.aclose()


async def main():
    # 预清理
    bus0 = RedisBus(settings.redis_url)
    await bus0.remove_room(ROOM)
    await bus0.r.delete(f"snap:{ROOM}")
    await bus0.close()
    import asyncpg
    con = await asyncpg.connect(settings.pg_dsn)
    await con.execute("DELETE FROM rounds WHERE room_id=$1", ROOM)
    await con.execute("DELETE FROM predictions WHERE room_id=$1", ROOM)
    await con.execute("DELETE FROM predictor_state WHERE room_id=$1", ROOM)
    await con.close()

    settings.scheduler.janitor_interval_s = 1     # 冒烟:janitor 秒级节拍
    w = Worker(settings)
    fake = FakeUpstream()
    w.up = fake  # 注入假上游(替代真实 aiohttp 会话)

    # 回灌场景预置:PG 里放一行 active、一行 pending,start() 应回灌进 Redis
    RESTORE_A, RESTORE_P = "9000777", "9000888"
    con2 = await asyncpg.connect(settings.pg_dsn)
    await con2.execute(
        "INSERT INTO rooms(room_id,alias,active,pending) VALUES($1,$1,TRUE,FALSE)"
        " ON CONFLICT (room_id) DO UPDATE SET active=TRUE,pending=FALSE", RESTORE_A)
    await con2.execute(
        "INSERT INTO rooms(room_id,alias,active,pending) VALUES($1,$1,FALSE,TRUE)"
        " ON CONFLICT (room_id) DO UPDATE SET active=FALSE,pending=TRUE", RESTORE_P)
    await con2.close()

    # 确定性加固:worker 起跑**之前**装惰性归一桩(恒「不权威」)。否则打桩前的
    # 窗口期里,janitor 会对回灌进来的挂起房走**真实繁星** canon —— 上游对合成号
    # (9000xxx)偶发「自回显」判权威(见 README §13),一旦提前转正,后续
    # (a)/(b) 场景的断言被搅,冒烟呈概率性 13~15/16。真实 canon 不是本冒烟的
    # 受测对象(starmeta 有专属单测),此处应恒为受控桩;(b) 场景再换定向桩。
    async def idle_canon(alias: str):
        return (str(alias), False)
    w.star.canon = idle_canon

    await w.start()
    # 注册房间 + 排一个即时 MainPage 任务
    await w.bus.add_room(ROOM, ROOM)
    await w.db.upsert_room(ROOM, ROOM, True)
    await w.bus.schedule(task_mainpage(ROOM), int(time.time() * 1000))

    # 独立订阅者接住 SSE 推送
    events: list = []
    stop = asyncio.Event()
    sub_task = asyncio.create_task(_subscriber(w.bus, ROOM, events, stop))

    # 起 worker 后台协程(有限并发)
    consumers = [asyncio.create_task(w._consumer(i)) for i in range(w.s.worker_concurrency)]
    loops = [asyncio.create_task(w._claimer()), asyncio.create_task(w._janitor()), *consumers]

    target = fake.start_ms                 # 目标局 = 本局起点
    next_rid = target + ROUND_STEP
    # 轮询等待目标局入库 + 下一局预测出现(最多 20s)
    deadline = time.time() + 20
    round_ok = pred = None
    while time.time() < deadline:
        await asyncio.sleep(0.5)
        round_ok = await w.db.has_round(ROOM, target)
        pred = await w.db.pending_prediction(ROOM)
        if round_ok and pred:
            break

    # ── janitor 场景(先撤 consumers,保证 fake 计数与 sched 断言稳定) ──
    for t in consumers:
        t.cancel()
    await asyncio.gather(*consumers, return_exceptions=True)

    jan_checks = []
    # (a) 回灌断言:start() 已把 PG 行灌回 Redis
    jan_checks.append(("回灌:PG active 行进 Redis 名录",
                       RESTORE_A in set(await w.bus.active_rooms())))
    jan_checks.append(("回灌:PG pending 行进 Redis 挂起集",
                       RESTORE_P in set(await w.bus.pending_rooms())))

    # (b) 挂起转正:打桩 canon,janitor 应在 ~2s 内转正并排即时 MainPage
    PEND, REAL = "321", "9000321"

    async def fake_canon(alias: str):
        return (REAL, True) if alias == PEND else (str(alias), False)

    w.star.canon = fake_canon
    await w.bus.pending_add(PEND)
    okc = False
    for _ in range(12):
        await asyncio.sleep(0.5)
        if (REAL in set(await w.bus.active_rooms())
                and PEND not in set(await w.bus.pending_rooms())):
            okc = True
            break
    jan_checks.append(("janitor:挂起房归一转正", okc))
    jan_checks.append(("janitor:转正后排了即时 MainPage",
                       REAL in set(await w.bus.scheduled_rooms())))
    rowr = None
    conj = await asyncpg.connect(settings.pg_dsn)
    rowr = await conj.fetchrow("SELECT active,pending FROM rooms WHERE room_id=$1", REAL)
    jan_checks.append(("janitor:转正落 PG(active=TRUE)",
                       bool(rowr and rowr["active"] and not rowr["pending"])))

    # (c) 超龄清理:pending 写 25h 前的时间戳,janitor 应放弃并清净
    OLDP = "654"
    await w.bus.r.hset("rooms:pending", OLDP,
                       int(time.time() * 1000) - 25 * 3600 * 1000)
    oks = False
    for _ in range(10):
        await asyncio.sleep(0.5)
        if OLDP not in set(await w.bus.pending_rooms()):
            oks = True
            break
    jan_checks.append(("janitor:超龄挂起自动放弃清净", oks))
    await conj.close()

    # 收尾
    w.stop()
    stop.set()
    for t in loops:
        t.cancel()
    await asyncio.gather(*loops, return_exceptions=True)
    await asyncio.gather(sub_task, return_exceptions=True)

    # ── 断言 ──
    checks = []

    def ok(name, cond, extra=""):
        checks.append((name, cond))
        print(f"  [{'✓' if cond else '✗'}] {name}{(' — ' + extra) if extra else ''}")

    for name, cond in jan_checks:
        ok(name, cond)

    hist = await w.db.history(ROOM, 0, 100)
    ok("目标局入库(RoundAward)", bool(round_ok),
       f"round={target} 出【{BEAST_NAME[fake.award_oid]}】")
    ok("历史回填入库 ≥10 局", len(hist) >= 10, f"rounds 表共 {len(hist)} 局")
    ok("生成下一局预测", pred is not None and str(pred.get("round_id")) == str(next_rid),
       f"target={pred.get('round_id') if pred else None} 期望={next_rid}")
    if pred:
        main_ids = list(pred.get("main_ids") or [])
        guard_ids = list(pred.get("guard_ids") or [])
        ok("预测 main/guard 非空且编号1..9",
           bool(main_ids) and all(1 <= n <= 9 for n in main_ids + guard_ids),
           f"main={main_ids} guard={guard_ids}")
    snap = await w.bus.get_snapshot(ROOM)
    ok("快照 latestRoundId 更新", str(snap.get("latestRoundId") or "") == str(target),
       f"latestRoundId={snap.get('latestRoundId')}")
    draw_evts = [e for e in events if e.get("roundsTouched")]
    ok("推送『新出怪』SSE", len(draw_evts) >= 1,
       f"收到 {len(events)} 条事件,其中出怪 {len(draw_evts)} 条")
    if draw_evts:
        ev = draw_evts[0]
        rd = ev.get("round") or {}
        ok("出怪事件 round 契约(spell_key/spell_name/captured_at)",
           rd.get("spell_key") == "水" and rd.get("spell_name") == "御水术"
           and bool(rd.get("captured_at")),
           f"spell_key={rd.get('spell_key')} captured_at={rd.get('captured_at')}")
        tm = ev.get("timer") or {}
        ok("出怪事件 timer 含 canPlay", "canPlay" in tm, f"timer keys={sorted(tm)}")
    chg_evts = [e for e in events if e.get("roundsTouched") is False]
    if chg_evts:
        ok("换局事件 timer 含 canPlay", "canPlay" in (chg_evts[0].get("timer") or {}))
    ok("上游被调用(main_page/round_award/game_history)",
       fake.calls["main_page"] >= 1 and fake.calls["round_award"] >= 1
       and fake.calls["game_history"] >= 1, f"calls={fake.calls}")

    await w.close()

    passed = sum(1 for _, c in checks if c)
    total = len(checks)
    print(f"\n==== worker 集成冒烟:{passed}/{total} 通过 ====")
    if passed != total:
        print("失败项:", [n for n, c in checks if not c])
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
