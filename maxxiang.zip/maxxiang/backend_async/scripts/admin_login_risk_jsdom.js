/* admin_login_risk_jsdom.js —— 管理台「登」登录风控视图(5.2.0)整机冒烟
   交付版 admin.html + admin.js 在 jsdom 真 DOM 中跑通:
     ① 左栏多出第 11 枚印「登」(5.4.0 新增「储」后全栏共 12 枚),帮助里有对应条目;
     ② 态势卡片(攻击态 / 近 24 小时各类计数)、当前被锁(账号 + IP 段)、可疑来源(IPv6 合并带 ≈)、
        被针对的账号、登录流水默认「只看可疑」;
     ③ 「看流水」把 IP / 账号带进筛选;「解锁」二次确认 → POST /userlogin/unlock(kind/value 正确)
        → 概览重取;
     ④ 分区容错:概览接口 503 时四个概览区都写明「渲染失败」,登录流水照常渲染。
   用法:node admin_login_risk_jsdom.js [--js 混淆后的 admin.js 路径];依赖 jsdom(NODE_PATH)。 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
const html = fs.readFileSync(ROOT + '/admin.html', 'utf8');
const JS_ARG = process.argv.indexOf('--js');
const adminjs = fs.readFileSync(JS_ARG > 0 ? process.argv[JS_ARG + 1] : ROOT + '/assets/admin.js', 'utf8');

let PASS = 0, FAIL = 0;
const A = (n, c) => { console.log(`  [${c ? '✓' : '✗'}] ${n}`); if (c) PASS++; else { FAIL++; process.exitCode = 1; } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

const NET = { calls: [], logQ: [], unlock: null, riskDown: false, bigLog: false, disabled: false };
const RISK = {
  ok: true, enabled: true, hours: 24,
  attack: { on: true, fails5m: 77, threshold: 50 },
  limits: { user: 10, ip: 30, windowS: 600, lockS: 600, stepupUser: 4, stepupIp: 10,
            captcha: 'tencent', captchaMode: 'risk' },
  byReason: { bad_credentials: 120, throttled: 33, 'challenge:risk': 9, ok: 40, ok_free: 2 },
  topIps: [{ bucket: '2001:db8:9:9::/64', n: 60, users: 14, ips: 3, approx: true, sample: '2001:db8:9:9::5',
             last: '2026-11-18T03:00:00', locked: true, leftS: 420 },
           { bucket: '198.51.100.7', n: 21, users: 21, ips: 1, approx: false, sample: '198.51.100.7',
             last: '2026-11-18T02:59:00', locked: false, leftS: 0 }],
  topUsers: [{ name: 'plainuser', n: 12, ips: 6, last: '2026-11-18T03:01:00', locked: true, leftS: 300 }],
  locked: { users: [{ name: 'plainuser', fails: 10, leftS: 300 }],
            ips: [{ bucket: '2001:db8:9:9::/64', fails: 30, leftS: 420 }] },
};
function route(url, opt) {
  const m = (opt && opt.method) || 'GET';
  const body = opt && opt.body ? JSON.parse(opt.body) : {};
  NET.calls.push(m + ' ' + url);
  if (url.endsWith('/login')) return { ok: true, token: 'tok', csrf: 'csrf', version: '1.9.0' };
  if (url.includes('/userlogin/risk')) return NET.disabled ? { ok: true, enabled: false }
    : NET.riskDown ? { __status: 503, ok: false, error: 'userdb_unavailable' } : RISK;
  if (url.includes('/userlogin/log')) {
    const q = Object.fromEntries(new URLSearchParams(url.split('?')[1] || ''));
    NET.logQ.push(q);
    if (NET.disabled) return { ok: true, enabled: false, items: [], total: 0 };
    return { ok: true, enabled: true, total: NET.bigLog ? 70 : 2, page: +(q.page || 1), size: 30, hours: 168, items: [
      { id: 2, user_id: 0, user_name: 'plainuser', ip: '2001:db8:9:9::5', ua: 'UA-x', ok: 0,
        reason: 'bad_credentials', created_at: '2026-11-18T03:01:00' },
      { id: 1, user_id: 0, user_name: 'sprayx', ip: '198.51.100.7', ua: 'UA-y', ok: 0,
        reason: 'challenge:risk', created_at: '2026-11-18T02:59:00' }] };
  }
  if (url.includes('/userlogin/unlock')) { NET.unlock = body; return { ok: true, key: 'k', existed: true }; }
  if (url.includes('/audit')) return { ok: true, total: 0, page: 1, size: 50, items: [] };
  if (url.includes('/state') || url.includes('/effective')) return { ok: true, rev: 1, settings: {}, effective: {} };
  return { ok: true };
}

(async () => {
  console.log('管理台「登」登录风控视图(5.2.0)整机冒烟 —— 交付版 admin.html + admin.js @ jsdom\n');
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => { if (!/Not implemented/.test(e.message)) console.log('  · jsdomError:', e.message.slice(0, 90)); });
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
                                url: 'http://localhost/', virtualConsole: vc });
  const w = dom.window;
  const jsErrs = [];
  w.addEventListener('error', e => jsErrs.push(e.message || String(e.error)));
  w.fetch = async (input, opt = {}) => {
    const url = typeof input === 'string' ? input : input.url;
    const b = route(url, opt);
    const status = b.__status || 200;
    return { ok: status < 400, status, headers: { get: () => null },
             json: async () => b, text: async () => JSON.stringify(b) };
  };
  w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){} };
  w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
  w.matchMedia = q => ({ matches: false, media: q, addEventListener(){}, removeEventListener(){},
                         addListener(){}, removeListener(){} });
  w.scrollTo = () => {};
  w.HTMLElement.prototype.scrollIntoView = function () {};
  const _ls = {};
  Object.defineProperty(w, 'localStorage', { value: {
    getItem: k => (k in _ls ? _ls[k] : null), setItem: (k, v) => { _ls[k] = String(v); },
    removeItem: k => { delete _ls[k]; }, clear: () => { for (const k in _ls) delete _ls[k]; } },
    configurable: true });
  const sc = w.document.createElement('script');
  sc.textContent = adminjs;
  w.document.body.appendChild(sc);
  await sleep(150);

  const $ = s => w.document.querySelector(s);
  const $$ = s => [...w.document.querySelectorAll(s)];
  const click = el => el && el.dispatchEvent(new w.Event('click', { bubbles: true }));
  const txt = s => ($(s) ? $(s).textContent : '');

  $('#pw').value = 'x';
  click($('#loginBtn'));
  await sleep(200);
  A('管理台登录后进入 shell', $('#shell').classList.contains('on'));
  const navs = $$('.nav-item');
  A('左栏共 12 枚印,含「登」', navs.length === 12 && navs.some(b => b.dataset.view === 'userlogin' && /登/.test(b.textContent)));
  A('帮助里有「登录风控」条目', /登录风控\(「登」\)/.test($('#help').textContent) && /十二枚印/.test($('#help').textContent));

  click(navs.find(b => b.dataset.view === 'userlogin'));
  await sleep(300);
  A('视图标题渲染', /登录风控/.test(txt('#main')));
  A('态势卡片:攻击态 + 77/50', /攻击态/.test(txt('#ulTop')) && /77/.test(txt('#ulTop')) && /50/.test(txt('#ulTop')));
  A('近 24 小时计数(口令错 120 / 被拒 33 / 加码 9 / 成功 42)',
    ['120', '33', '9', '42'].every(n => txt('#ulTop').includes(n)));
  A('阈值与登录人机验证口径显示', /同名 10/.test(txt('#ulTop')) && /tencent/.test(txt('#ulTop')) && /仅可疑时/.test(txt('#ulTop')));
  A('当前被锁:账号 + IP 段各一行', $$('#ulLocked tr').length === 3 && /plainuser/.test(txt('#ulLocked'))
    && /2001:db8:9:9::\/64/.test(txt('#ulLocked')) && /5 分 0 秒/.test(txt('#ulLocked')));
  A('可疑来源:IPv6 合并段带 ≈,锁定中标签', /≈14/.test(txt('#ulIps')) && /锁定中/.test(txt('#ulIps')));
  A('被针对的账号', /plainuser/.test(txt('#ulUsers')) && /12/.test(txt('#ulUsers')));
  A('登录流水默认「只看可疑」', NET.logQ[0] && NET.logQ[0].reason === 'suspect' && NET.logQ[0].hours === '168');
  A('流水原因显示中文', /口令错/.test(txt('#ulTbl')) && /要求加码/.test(txt('#ulTbl')));

  click($('#ulIps [data-fip]'));
  await sleep(150);
  const lq = NET.logQ[NET.logQ.length - 1] || {};
  A('「看流水」把 IP 带进筛选并切到全部', lq.ip === '2001:db8:9:9::5' && !lq.reason && $('#ulIp').value === '2001:db8:9:9::5');

  const nRisk = NET.calls.filter(c => c.includes('/userlogin/risk')).length;
  click($('#ulLocked [data-unlock="user"]'));
  await sleep(150);
  A('解锁先弹二次确认', $('#ask').classList.contains('open') || getComputedStyle($('#ask')).display !== 'none');
  click($('#askYes'));
  await sleep(200);
  A('确认后 POST 解锁(kind=user, value=plainuser)', NET.unlock && NET.unlock.kind === 'user' && NET.unlock.value === 'plainuser');
  A('解锁后概览重取', NET.calls.filter(c => c.includes('/userlogin/risk')).length > nRisk);

  // 筛选 / 翻页 / 看账号流水(此前零覆盖的交互分支)
  const lastQ = () => NET.logQ[NET.logQ.length - 1] || {};
  $('#ulRes').value = 'r:throttled'; $('#ulRes').dispatchEvent(new w.Event('change')); await sleep(120);
  A('按具体原因筛:reason=throttled', lastQ().reason === 'throttled' && !lastQ().ok);
  $('#ulRes').value = 'ok0'; $('#ulRes').dispatchEvent(new w.Event('change')); await sleep(120);
  A('仅失败:ok=0 且不带 reason', lastQ().ok === '0' && !lastQ().reason);
  click($('#ulUsers [data-fname]')); await sleep(120);
  A('「看流水」把账号带进筛选', lastQ().name === 'plainuser' && $('#ulName').value === 'plainuser');
  NET.bigLog = true;
  click($('#ulReset')); await sleep(150);
  A('重置回到「只看可疑」第 1 页', lastQ().reason === 'suspect' && lastQ().page === '1' && $('#ulRes').value === 'suspect');
  click($('#ulNext')); await sleep(150);
  A('翻到第 2 页', lastQ().page === '2' && /第 2 \/ 3 页/.test(txt('#ulTbl')));
  click($('#ulPrev')); await sleep(150);
  A('翻回第 1 页', lastQ().page === '1');
  NET.bigLog = false;
  NET.disabled = true;
  click($('#ulRefresh')); await sleep(200);
  A('登录系统未启用:概览与流水都如实说明', /未启用/.test(txt('#ulTop')) && /未启用/.test(txt('#ulTbl')));
  NET.disabled = false;

  NET.riskDown = true;
  click($('#ulRefresh'));
  await sleep(250);
  A('概览接口 503:四个概览区都写明渲染失败', ['#ulTop', '#ulLocked', '#ulIps', '#ulUsers'].every(z => /渲染失败/.test(txt(z))));
  A('同时登录流水照常渲染(分区容错)', /plainuser/.test(txt('#ulTbl')) && !/渲染失败/.test(txt('#ulTbl')));
  A('全程零未捕获异常', jsErrs.length === 0);

  console.log(`\n合计:${PASS} 通过 / ${FAIL} 失败`);
  process.exit(FAIL ? 1 : 0);
})().catch(e => { console.error('冒烟异常:', e); process.exit(1); });
