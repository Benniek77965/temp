"""admin_secret_browser.py — 参数中心「敏感项」的**真实浏览器**布局核查(4.2.9)

为什么必须有这个脚本:jsdom **不做布局**。4.2.9 在密钥项旁加了两颗按钮
(🎲 生成 / 👁 查看),而这一行是个 flex 容器 —— 按钮会不会把输入框挤没、
会不会掉行留空、触控目标够不够大,`admin_secret_jsdom.js` 一条都验不到。

本轮就是靠它坐实了一个**看源码发现不了**的缺陷:初版把输入框包进了
`<span class="sec-wrap">`,`.pctl input[type=password]{flex:1}` 的选择器仍然命中
(后代选择器),但 flex:1 相对的是那个非 flex 的 span —— 输入框在真实渲染里
塌到内容宽度。jsdom 的父子关系断言能抓到"包了一层",但抓不到"塌了多宽"。

用法(需要 playwright,未装则整个脚本跳过,不阻断主干):
    pip install playwright && python3 -m playwright install --with-deps chromium
    python3 backend_async/scripts/admin_secret_browser.py
"""
import functools
import http.server
import json
import os
import socketserver
import sys
import threading

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("[跳过] 未安装 playwright —— 真实浏览器核查需要它;"
          "jsdom 冒烟(admin_secret_jsdom.js)仍覆盖行为层。")
    sys.exit(0)

_REPO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ROOT = (sys.argv[sys.argv.index("--root") + 1] if "--root" in sys.argv else _REPO)
if not os.path.isabs(ROOT):
    ROOT = os.path.join(_REPO, ROOT)
PORT = 8733
PASS = FAIL = 0


def A(name, ok, extra=""):
    global PASS, FAIL
    print(f"  [{'✓' if ok else '✗'}] {name}" + ("" if ok else f"  → {extra}"))
    if ok:
        PASS += 1
    else:
        FAIL += 1


class Q(socketserver.ThreadingTCPServer):
    allow_reuse_address = True


def serve():
    h = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT)
    h.log_message = lambda *a, **k: None
    srv = Q(("127.0.0.1", PORT), h)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def _field(label, key, section, **kw):
    d = {"label": label, "type": "str", "default": "", "hot": "hot",
         "consumers": ["web"], "section": section, "desc": "说明文字", "unit": "",
         "ge": None, "le": None, "choices": None, "env": "STA_X",
         "sensitive": False, "danger": False, "readonly": False,
         "no_reset": False, "depends": "", "genBytes": 0, "revealable": False}
    d.update(kw)
    return d


FIELDS = {
    "userauth.jf_card_api_key": _field(
        "外部发卡API密钥", "k", "九法VIP", sensitive=True, danger=True,
        genBytes=32, revealable=True,
        desc="调用方须带 Authorization: Bearer <key>。留空 = 端点整体 503,须 ≥24 字符"),
    "auth.ticket": _field("上游票据", "t", "接入凭据", sensitive=True, danger=True),
    "userauth.jf_order_rate_hourly": _field(
        "下单限频", "r", "九法VIP", type="int", default=20, unit="次/时", ge=1, le=500),
}


def _item(k, eff):
    return {"key": k, "effective": eff, "source": "default",
            "layers": {"default": eff, "yaml": None, "yaml_set": False,
                       "env": None, "env_set": False,
                       "runtime": None, "runtime_set": False},
            "base": eff}


def route(page):
    """只桩网络,页面跑的是**交付版**的 admin.html + admin.js + admin.css。"""
    def h(r):
        u = r.request.url
        if "/admin/session" in u:
            b = {"ok": True, "authed": True, "csrf": "c", "rev": 1}
        elif "/admin/schema" in u:
            b = {"ok": True, "fields": FIELDS,
                 "sections": ["九法VIP", "接入凭据"], "deploy": []}
        elif "/config/effective" in u:
            b = {"ok": True, "rev": 1, "applied_rev": 1, "items": [
                _item("userauth.jf_card_api_key", "0f3a…ab12"),
                _item("auth.ticket", "abcd…0011"),
                _item("userauth.jf_order_rate_hourly", 20)]}
        elif "/config/reveal" in u:
            b = {"ok": True, "key": "userauth.jf_card_api_key",
                 "value": "d" * 64, "auditOk": True}
        elif "/fleet" in u:
            b = {"ok": True, "target_rev": 1, "converged": True, "instances": []}
        else:
            b = {"ok": True, "items": []}
        r.fulfill(status=200, content_type="application/json",
                  body=json.dumps(b, ensure_ascii=False))
    page.route("**/api/**", h)


KEY_SEL = 'input[data-k="userauth.jf_card_api_key"]'


def check(page, w, h, label):
    print(f"\n[{label}  {w}×{h}]")
    errs = []
    page.on("pageerror", lambda e: errs.append(str(e)))
    page.set_viewport_size({"width": w, "height": h})
    route(page)
    page.goto(f"http://127.0.0.1:{PORT}/admin.html#/params", wait_until="networkidle")
    page.wait_for_selector(KEY_SEL, timeout=8000)

    inp = page.locator(KEY_SEL)
    gen = page.locator(".sec-gen")
    rev = page.locator(".sec-rev")
    A("零页面异常", not errs, errs[:1])
    A("密钥行三件套都可见",
      inp.is_visible() and gen.is_visible() and rev.is_visible())

    bi, bg, br = inp.bounding_box(), gen.bounding_box(), rev.bounding_box()
    row = page.locator(f'{KEY_SEL} >> xpath=..').bounding_box()

    # ① 输入框不能被两颗按钮挤塌 —— 这正是「包一层 span」缺陷的真实症状。
    #    判据:输入框至少占本行可用宽度的一半(按钮共约 150px,行宽 ≥300px 时成立)。
    A(f"输入框未被按钮挤塌(占行宽 {bi['width'] / row['width']:.0%})",
      bi["width"] >= row["width"] * 0.45,
      f"input={bi['width']:.0f} row={row['width']:.0f}")

    # ② 三者同一行(不掉行)。同行判据:垂直中心差 < 半个按钮高。
    cy = lambda b: b["y"] + b["height"] / 2
    A("输入框与两颗按钮在同一行(未掉行)",
      abs(cy(bi) - cy(bg)) < bg["height"] / 2 and abs(cy(bi) - cy(br)) < br["height"] / 2,
      f"y: inp={cy(bi):.0f} gen={cy(bg):.0f} rev={cy(br):.0f}")

    # ③ 触控目标(WCAG 2.5.8 最小 24×24)
    A("两颗按钮触控目标 ≥24×24",
      min(bg["width"], bg["height"], br["width"], br["height"]) >= 24,
      f"gen={bg['width']:.0f}×{bg['height']:.0f} rev={br['width']:.0f}×{br['height']:.0f}")

    # ④ 不横向溢出
    ov = page.evaluate("() => document.documentElement.scrollWidth "
                       "- document.documentElement.clientWidth")
    A("页面无横向滚动", ov <= 1, f"溢出 {ov}px")

    # ⑤ 不可揭示的敏感项**不能**长出按钮(授予面在真实渲染里也成立)
    tk = page.locator('input[data-k="auth.ticket"]')
    sib = page.evaluate("""() => {
        const i = document.querySelector('input[data-k="auth.ticket"]');
        if (!i) return -1;
        return i.parentElement.querySelectorAll('.sec-gen,.sec-rev').length; }""")
    A("auth.ticket 那一行没有任何按钮", tk.is_visible() and sib == 0, f"实得 {sib} 颗")

    # ⑥ 👁 查看:真实点击 → 明文渲染出来且可读(不是 0 宽度/被遮挡)
    rev.click()
    page.wait_for_selector("#rvOut", timeout=5000)
    out = page.locator("#rvOut")
    bo = out.bounding_box()
    A("明文文本框可见且有实际尺寸",
      out.is_visible() and bo["width"] > 100 and bo["height"] > 20,
      f"{bo['width']:.0f}×{bo['height']:.0f}")
    A("明文内容正确", out.input_value() == "d" * 64)
    A("弹窗内无横向溢出", page.evaluate(
        "() => { const b = document.querySelector('#ask .box');"
        " return b ? b.scrollWidth - b.clientWidth : 0; }") <= 1)
    page.locator("#askYes").click()

    # ⑦ 🎲 生成:真实点击 → 值进输入框 + 明文弹窗可读
    gen.click()
    page.wait_for_selector("#gsOut", timeout=5000)
    gv = page.locator("#gsOut").input_value()
    A("生成的密钥是 64 位 hex", len(gv) == 64 and all(c in "0123456789abcdef" for c in gv),
      gv[:20])
    A("生成值已写进输入框", page.locator(KEY_SEL).input_value() == gv)
    page.locator("#askYes").click()
    page.wait_for_timeout(120)
    # 生成后卡片应进入 staged 态(否则运维以为没暂存,会再点一次)
    A("生成后参数卡进入暂存态", page.evaluate(
        """() => { const i = document.querySelector('%s');
             return !!i && !!i.closest('.pcard.staged'); }""" % KEY_SEL))


def main():
    srv = serve()
    try:
        with sync_playwright() as p:
            b = p.chromium.launch()
            for w, h, label in ((1440, 900, "桌面宽"), (1024, 800, "桌面窄"),
                                (768, 900, "平板"), (390, 844, "手机")):
                pg = b.new_page()
                check(pg, w, h, label)
                pg.close()
            b.close()
    finally:
        srv.shutdown()
    print("\n" + "─" * 54)
    print(f"参数中心敏感项 · 真实浏览器核查:{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
