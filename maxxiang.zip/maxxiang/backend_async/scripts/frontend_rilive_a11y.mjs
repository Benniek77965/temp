/* 两件事都必须**量**,不许推理:
   ① 去掉 aria-hidden 后,名录按钮的**无障碍名**到底变成什么(我在注释里断言过它会
      带上「直播中」——用 Chromium 的 a11y 快照验);
   ② 同类排查:同一行里其它**携带状态**的元素(.ri-tick 五态)对比度够不够 ——
      .ri-live 的未知环栽在 --line(1.08:1)上,同一个令牌在别处是否重演。*/
import { chromium } from 'playwright';
import { readFileSync } from 'fs';
const CSS = readFileSync('assets/app.css', 'utf8');

const ROW = (alias, live, hidden, tick, tickCls) => `
  <button type="button" class="room-item" data-alias="${alias}" title="主播${alias}">
    <img src="" alt="">
    <span class="ri-meta"><b>主播${alias}</b><span class="ri-sub"><span class="ri-no">№ ${alias}</span><span class="ri-tick ${tickCls}">${tick}</span></span></span>
    <i class="ri-del" title="删除该直播间并停止监控">×</i>
    <i class="${live}" data-la="${alias}" role="img" aria-label="${hidden ? '' : (live.includes('is-live') ? '直播中' : '直播状态未知')}" ${hidden ? 'hidden' : ''} title="${hidden ? '' : (live.includes('is-live') ? '直播中 · 主播此刻正在开播' : '直播状态未知(未取到状态,不代表未开播)')}"></i>
  </button>`;

const HTML = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><style>${CSS}</style></head>
<body><aside class="rail"><div class="room-list">
  ${ROW('1001', 'ri-live is-live', false, '开 12s', 'hot')}
  ${ROW('1002', 'ri-live', true, '下 33s', 'next')}
  ${ROW('1003', 'ri-live is-unknown', false, '待', 'idle')}
  ${ROW('1004', 'ri-live is-unknown', false, '断', 'lost')}
  ${ROW('1005', 'ri-live is-live', false, '开 9s', 'hot slow')}
</div></aside></body></html>`;

const b = await chromium.launch();
const p = await (await b.newContext({ viewport: { width: 1920, height: 1080 } })).newPage();
await p.setContent(HTML, { waitUntil: 'load' });

console.log('== ① 名录按钮的无障碍名(Chromium a11y 快照)==');
// playwright 新版移除了 page.accessibility;改用 CDP 的 Accessibility 域直接取
// Chromium 自己算出的 computed name(比任何第三方 AccName 实现都权威)。
const cdp = await p.context().newCDPSession(p);
await cdp.send('Accessibility.enable');
const { nodes } = await cdp.send('Accessibility.getFullAXTree');
const btns = nodes.filter(n => n.role && n.role.value === 'button');
btns.forEach((n, i) => console.log(
  `  按钮${i + 1}: name=${JSON.stringify(n.name && n.name.value)}` +
  `  来源=${(n.name && n.name.sources || []).filter(s => s.value)
      .map(s => s.type + (s.attribute ? '(' + s.attribute + ')' : '')).join('+')}`));

console.log('\n== ② 同行状态元素对比度实测(WCAG 1.4.11 门槛 3:1)==');
const res = await p.evaluate(() => {
  const lum = c => { const [r, g, bl] = c.match(/[\d.]+/g).slice(0, 3).map(Number)
    .map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
    return 0.2126 * r + 0.7152 * g + 0.0722 * bl; };
  const ratio = (a, bb) => { const L1 = lum(a), L2 = lum(bb);
    return Math.round(((Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05)) * 100) / 100; };
  const bgOf = el => { for (let n = el.parentElement; n; n = n.parentElement) {
      const c = getComputedStyle(n).backgroundColor;
      if (c && c !== 'rgba(0, 0, 0, 0)') return c; } return 'rgb(255,255,255)'; };
  const out = [];
  for (const el of document.querySelectorAll('.room-item')) {
    const alias = el.dataset.alias;
    const dot = el.querySelector('.ri-live');
    const dcs = getComputedStyle(dot);
    const dfore = dcs.backgroundColor !== 'rgba(0, 0, 0, 0)' ? dcs.backgroundColor : dcs.borderTopColor;
    out.push({ 元素: `.ri-live[${alias}]`, 类: dot.className,
      可见: dcs.display !== 'none',
      对比度: dcs.display === 'none' ? '-' : ratio(dfore, bgOf(dot)) });
    const t = el.querySelector('.ri-tick');
    const tcs = getComputedStyle(t);
    const back = tcs.backgroundColor !== 'rgba(0, 0, 0, 0)' ? tcs.backgroundColor : bgOf(t);
    out.push({ 元素: `.ri-tick[${alias}]`, 类: t.className,
      可见: true, 文字对比度: ratio(tcs.color, back),
      描边: tcs.borderTopWidth === '0px' ? '无' : tcs.borderTopWidth + ' ' + tcs.borderTopColor,
      描边对比度: tcs.borderTopWidth === '0px' ? '-' : ratio(tcs.borderTopColor, bgOf(t)) });
  }
  return out;
});
res.forEach(r => console.log('  ' + JSON.stringify(r)));
await b.close();
