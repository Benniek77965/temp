#!/usr/bin/env python3
"""
discover_rooms.py — 手动跑一轮「直播间自动发现」(遍历繁星在播列表)
================================================================================
worker 已内置每 30s 的自动发现循环(见 app/worker.py 的 _discovery)。本脚本供
**手动触发 / 排查 / 冷启动预热**用,和 worker 走**同一套** reconcile 逻辑
(app.discovery.reconcile_discovered),行为完全一致。

两种模式:
  · 默认 **dry-run**:只遍历在播列表并打印统计(页数/在播房数/其中多少是全新房),
    不写任何名录、不起抓 —— 安全预览。
  · **--commit**:真正并入运行态(登记新发现房 + 错峰起抓 + 刷 last_seen + 离线回收),
    等价于 worker 自动发现循环跑一轮。

用法:
    python -m scripts.discover_rooms                 # dry-run:看看在播列表有多少房
    python -m scripts.discover_rooms --commit        # 实际纳入后台抓取(与 worker 一轮等价)
    python -m scripts.discover_rooms --pages 10      # 限制单轮最多翻 10 页(调试)
    python -m scripts.discover_rooms --commit --pages 5

说明:发现房**只进运行态(Redis),不落 PG rooms**,由每轮遍历重建;前端不显示
发现房(只显示用户经 /api/monitor/add 显式添加的房)。发现房照常被 worker 抓取,
其出怪/预测数据进 PG。故 --commit 后仍需 worker 在跑,才能真正采集这些房的数据。
"""
from __future__ import annotations

import argparse
import asyncio
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.db import DB                               # noqa: E402
from app.discovery import Discovery, reconcile_discovered  # noqa: E402
from app.ratelimit import TokenBucket              # noqa: E402
from app.redis_bus import RedisBus                 # noqa: E402
from app.settings import settings                   # noqa: E402


async def _run(commit: bool, pages: int) -> None:
    cfg = settings.discovery
    max_pages = pages if pages and pages > 0 else cfg.max_pages
    bus = RedisBus(settings.redis_url, max_connections=32,
                   pool_timeout=settings.redis_pool_timeout)
    db = DB(settings.pg_dsn, settings.pg_pool_min, settings.pg_pool_max)
    # 翻页过繁星令牌桶(与 worker/归一同一路,跨进程共享),不惊群打爆繁星。
    fx_rl = TokenBucket(bus.r, "rl:fanxing",
                        settings.ratelimit.fanxing_rps, settings.ratelimit.fanxing_burst)
    disc = Discovery(list_url=cfg.list_url or None, params=cfg.params,
                     timeout=cfg.request_timeout, conn_limit=cfg.conn_limit,
                     bucket=fx_rl, max_pages=max_pages, page_delay_ms=cfg.page_delay_ms,
                     page_concurrency=cfg.page_concurrency)  # 3.4.0:与 worker 同参(波次并发翻页)
    await db.connect()
    await db.migrate()      # 幂等建表(含 discovered_rooms 时钟表;可独立于 web/worker 先跑)
    await disc.start()
    await bus.ping()
    try:
        print("遍历繁星在播列表%s(单轮最多 %d 页)..."
              % ("(仅预览,不写入)" if not commit else "并纳入后台抓取", max_pages))
        t0 = time.monotonic()
        swept = await disc.sweep()
        dt = time.monotonic() - t0
        live = swept["rooms"]
        print("\n遍历完成(用时 %.1fs,%d 页,结束原因=%s%s):"
              % (dt, swept["pages"], swept["stopped_by"],
                 " ⚠️触达页数护栏" if swept["truncated"] else ""))
        print("  在播房间(去重后)= %d · 遇到条目 = %d" % (swept["unique"], swept["fetched"]))

        active = set(await bus.active_rooms())
        discovered = await bus.discovered_members()
        try:
            manual = {str(r["room_id"]) for r in await db.active_rooms()}
        except Exception:
            manual = set()
        would_new = [r for r in live if r not in active and r not in manual]
        print("  当前活跃名录 = %d(其中策展房 = %d,发现房 = %d)"
              % (len(active), len(manual), len(discovered)))
        print("  本轮全新(尚未纳入)房 = %d" % len(would_new))
        if would_new[:10]:
            print("    例:", ", ".join(would_new[:10]),
                  "…" if len(would_new) > 10 else "")

        if commit:
            rec = await reconcile_discovered(bus, db, swept, cfg)
            print("\n已并入运行态:新增纳入 %d 房 · 离线回收 %d 房 · 发现房共 %d · 活跃共 %d"
                  % (rec["new_admitted"], rec["pruned"],
                     len(await bus.discovered_members()), len(await bus.active_rooms())))
            print("(发现房已进 Redis 名录并排了错峰起抓任务;需 worker 在跑才会真正抓取采集。)")
        else:
            print("\n[dry-run] 未写入任何名录。加 --commit 实际纳入后台抓取。")
    finally:
        await disc.close()
        await bus.close()
        await db.close()


def main() -> None:
    ap = argparse.ArgumentParser(
        description="手动跑一轮直播间自动发现(遍历繁星在播列表;与 worker 同一逻辑)")
    ap.add_argument("--commit", action="store_true",
                    help="真正并入运行态(默认 dry-run,只预览不写入)")
    ap.add_argument("--pages", type=int, default=0,
                    help="限制单轮最多翻页数(默认取 config 的 discovery.max_pages)")
    args = ap.parse_args()
    asyncio.run(_run(commit=args.commit, pages=args.pages))


if __name__ == "__main__":
    main()
