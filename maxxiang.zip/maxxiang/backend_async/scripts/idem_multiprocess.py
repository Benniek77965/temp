"""idem_multiprocess.py — 幂等占位的**跨进程**原子性验证(4.2.9 第八轮)

── 为什么必须有这一份 ──────────────────────────────────────────────────────────
外部发卡 API 的幂等靠一条 `SET key val NX EX ttl`。而第四轮实测发现:
**单进程 asyncio + fakeredis 证明不了它** —— 把 SET NX 换成「先 GET 再 SET」的
非原子实现,50 路并发**仍然**只有 1 路拿到 new(await 之间不让出)。当时只能补一条
静态钉锁住 `nx=True` 这个原语,并如实写明「多进程行为仍是逻辑推演」。

本脚本把那条推演变成实测:**N 个独立 Python 进程** × 每进程 M 路协程,各自连**真
Redis**,同时抢同一个幂等键。这正是生产形态(uvicorn --workers N + 真 Redis)。

── 实测结论(2026-07,redis-server 7.x,8 进程 × 25 协程 = 200 路)────────────
    现行实现(SET NX)        → new = 1    ,in_flight = 199
    变异(先 GET 再 SET)      → new = 69   ,in_flight = 131
把 new 换算成后果:非原子实现下会有 **69 批**重复卡密被发出去,每一批都可兑换。
这条差异 fakeredis 与单进程测不出来,只有真 Redis + 多进程能。

用法(需要真 Redis;未提供则整个脚本跳过,不阻断主干):
    redis-server --port 6380 --save '' &
    python3 backend_async/scripts/idem_multiprocess.py
    # 自定义:--url redis://127.0.0.1:6380/0 --procs 8 --coros 25
    # 反证:--mutate 会**临时**把实现换成非原子跑一遍(跑完自动还原),
    #       用来确认本脚本确实测得出差异 —— 断言不做变异验证等于没断言。
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile

_HERE = os.path.dirname(os.path.abspath(__file__))
_BACKEND = os.path.dirname(_HERE)
sys.path.insert(0, _BACKEND)


def _arg(name: str, default):
    return sys.argv[sys.argv.index(name) + 1] if name in sys.argv else default


URL = _arg("--url", os.environ.get("STA_TEST_REDIS_URL", "redis://127.0.0.1:6380/0"))
PROCS = int(_arg("--procs", 8))
COROS = int(_arg("--coros", 25))

# ── 子进程体:刻意用**独立解释器**,而不是 multiprocessing fork ────────────────
#    fork 会继承事件循环与连接池,那样测出来的仍是"一个进程内的事",
#    与生产的 uvicorn --workers(各自 exec 的独立进程)不是一回事。
_CHILD = r'''
import asyncio, json, sys
sys.path.insert(0, %(backend)r)
import redis.asyncio as aioredis
from app import jfvip, userauth
from app.settings import UserAuthCfg
KEY, N, URL = sys.argv[1], int(sys.argv[2]), sys.argv[3]
async def main():
    userauth.UA.cfg = UserAuthCfg(host="h", db="d", user="u", jf_vip_enabled=True)
    userauth.UA.redis = aioredis.from_url(URL, decode_responses=True)
    fp = jfvip.idem_fingerprint({"hours": 720, "count": 5, "batch": "MP"})
    rs = await asyncio.gather(*[jfvip.idem_begin(KEY, fp) for _ in range(N)])
    print(json.dumps([s for s, _ in rs]))
    await userauth.UA.redis.aclose()
asyncio.run(main())
'''


def _reachable() -> bool:
    try:
        import redis
        redis.from_url(URL, socket_connect_timeout=1).ping()
        return True
    except Exception:                       # noqa: BLE001
        return False


def run_round(key: str, backend: str) -> dict:
    """起 PROCS 个独立进程,各自并发 COROS 路。返回状态计数。"""
    import redis
    redis.from_url(URL).delete(*[k for k in
                                 redis.from_url(URL).keys("guantai:jf:cardapi:idem:*")]
                               or ["__none__"])
    with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False) as f:
        f.write(_CHILD % {"backend": backend})
        child = f.name
    try:
        ps = [subprocess.Popen([sys.executable, child, key, str(COROS), URL],
                               stdout=subprocess.PIPE, text=True)
              for _ in range(PROCS)]
        out: dict = {}
        for p in ps:
            so, _ = p.communicate(timeout=120)
            for st in json.loads(so.strip().splitlines()[-1]):
                out[st] = out.get(st, 0) + 1
        return out
    finally:
        os.unlink(child)


def main() -> int:
    if not _reachable():
        print(f"[跳过] 真 Redis 不可达({URL}) —— 跨进程原子性验证需要它;"
              f"静态钉(test_idem_claim_uses_the_atomic_primitive)仍锁住 SET NX。")
        return 0

    total = PROCS * COROS
    print(f"\n[跨进程幂等] {PROCS} 进程 × {COROS} 协程 = {total} 路,真 Redis {URL}")

    got = run_round("mp-atomic", _BACKEND)
    ok = got.get("new", 0) == 1
    print(f"  [{'✓' if ok else '✗'}] 现行实现(SET NX):new={got.get('new', 0)} "
          f"in_flight={got.get('in_flight', 0)}  期望 new=1")
    if not ok:
        print(f"      → 完整计数 {got}")

    if "--mutate" not in sys.argv:
        print("  (加 --mutate 可跑反证:把实现临时换成非原子,确认本脚本测得出差异)")
        return 0 if ok else 1

    # ── 反证:临时把 SET NX 换成「先 GET 再 SET」───────────────────────────
    #    在**副本**上做,绝不改动工作区的源码。
    tmp = tempfile.mkdtemp()
    try:
        shutil.copytree(os.path.join(_BACKEND, "app"), os.path.join(tmp, "app"))
        p = os.path.join(tmp, "app", "jfvip.py")
        src = open(p, encoding="utf-8").read()
        atomic = ('        if await r.set(slot, _IDEM_PENDING + fp, nx=True, '
                  'ex=_IDEM_TTL_S):\n            return "new", slot')
        naive = ('        if not await r.get(slot):\n'
                 '            await r.set(slot, _IDEM_PENDING + fp, ex=_IDEM_TTL_S)\n'
                 '            return "new", slot')
        assert src.count(atomic) == 1, "反证锚点失效 —— 实现已改,请同步本脚本"
        open(p, "w", encoding="utf-8").write(src.replace(atomic, naive))
        bad = run_round("mp-naive", tmp)
        n = bad.get("new", 0)
        ok2 = n > 1
        print(f"  [{'✓' if ok2 else '✗'}] 反证(先 GET 再 SET):new={n} "
              f"in_flight={bad.get('in_flight', 0)}  期望 new>1")
        print(f"      → 换算成后果:非原子实现下会发出 **{n} 批**重复卡密,每批都可兑换")
        if not ok2:
            print("      → 反证没测出差异:说明本脚本的并发压力不足,"
                  "调大 --procs/--coros 后重跑;此时上面那条「通过」不可信")
        return 0 if (ok and ok2) else 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
