/* frontend_login_guard_jsdom.js —— 登录防爆破(5.2.0)前端整机冒烟
   交付版 index.html + app.js 在 jsdom 真 DOM 中跑通「登录加码」全链路:
     ① 未触发加码:一次提交即登录(与旧版逐字节同行为,零额外请求);
     ② 后端回 428 challenge_required(仅 PoW)→ powAnswer(主线程)→ 注册那枚内联
        Worker 真跑同一段源码穷举 → 自动重提;**服务端同款校验**核对 nonce 是真解;
     ③ 登录人机验证 always 档:开门即挂 Turnstile(action=login,挂在 #authCaptchaBox),
        提交带令牌;
     ④ risk 档:428 同时要求验证码 + PoW → 挂件出令牌 + 解题 → 重提;
     ⑤ 验证码脚本加载失败(大陆网络访问 Cloudflare 受限的真实形态)→ 明确提示,按钮复位;
     ⑥ 429 throttled → 文案带「尝试过于频繁」,按钮复位。
   用法:node frontend_login_guard_jsdom.js [--js 混淆后的 app.js 路径]
   依赖:jsdom(NODE_PATH 指到含 jsdom 的 node_modules 即可)。
   注:jsdom 无 Worker / 不加载外链脚本 —— Worker 用「真跑同一段源码」的替身,
   外链脚本在 appendChild 处拦截并按场景触发 onload/onerror(与真实浏览器同一回调路径)。 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '../..');
const html = fs.readFileSync(ROOT + '/index.html', 'utf8');
const JS_ARG = process.argv.indexOf('--js');
const JS_PATH = JS_ARG > 0 ? process.argv[JS_ARG + 1] : ROOT + '/assets/app.js';
const appjs = fs.readFileSync(JS_PATH, 'utf8');

let PASS = 0, FAIL = 0;
const A = (n, c) => { console.log(`  [${c ? '✓' : '✗'}] ${n}`); if (c) PASS++; else { FAIL++; process.exitCode = 1; } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* 服务端同款校验(= app/userauth.py reg_pow_check 与 app/powproof.py pow_answer)。 */
function leadZeroBits(buf) {
  let n = 0;
  for (const b of buf) { if (b === 0) { n += 8; continue; }
    let x = b; while (!(x & 0x80)) { n++; x = (x << 1) & 255; } return n; }
  return n;
}
function powAnswerPy(challenge) {
  let h1 = 0x811c9dc5 >>> 0, h2 = 0x1000193 >>> 0;
  for (let i = 0; i < challenge.length; i++) {
    const c = challenge.charCodeAt(i) >>> 0;
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h1 = ((h1 << 13) | (h1 >>> 19)) >>> 0;
    h2 = Math.imul((h2 + c + i) >>> 0, 0x85ebca6b) >>> 0;
    h2 = (h2 ^ (h2 >>> 15)) >>> 0;
    h1 = (h1 + h2) >>> 0;
  }
  h1 = (h1 ^ (h1 >>> 16)) >>> 0; h1 = Math.imul(h1, 0x7feb352d) >>> 0; h1 = (h1 ^ (h1 >>> 15)) >>> 0;
  h2 = (h2 ^ (h2 >>> 13)) >>> 0; h2 = Math.imul(h2, 0x846ca68b) >>> 0; h2 = (h2 ^ (h2 >>> 16)) >>> 0;
  const hx = x => (x >>> 0).toString(16).padStart(8, '0');
  return hx(h1) + hx(h2);
}
function verifyPow(salt, nonce, bits) {
  const d = crypto.createHash('sha256').update(powAnswerPy(salt) + ':' + nonce).digest();
  return leadZeroBits(d) >= bits;
}

const TS_SITEKEY = '1x00000000000000000000AA';        // Cloudflare 官方「恒通过」测试站点密钥
const TS_TOKEN = 'XXXX.DUMMY.TOKEN.XXXX';              // 测试站点密钥产出的固定假令牌

/* 起一个全新页面。sc = 场景:{ session, onLogin(body, n) → 响应体, scriptFail } */
async function boot(sc) {
  const net = { logins: [], renders: [], resets: 0, scripts: [], gtInits: [], gtResets: 0, tcInits: [] };
  let reloads = 0;
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => { if (/navigation (to another Document|\(except hash changes\))/i.test(e.message)) reloads++; });
  for (const ev of ['error', 'warn', 'info', 'log']) vc.on(ev, () => {});
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
                                url: 'http://localhost/', virtualConsole: vc });
  const w = dom.window;
  w.fetch = async (input, opt = {}) => {
    const url = typeof input === 'string' ? input : input.url;
    let body = { ok: true };
    if (url.startsWith('/api/auth/session')) body = sc.session;
    else if (url.startsWith('/api/auth/login')) {
      const req = JSON.parse(opt.body || '{}');
      net.logins.push({ req, headers: opt.headers || {} });
      body = sc.onLogin(req, net.logins.length);
    }
    const status = body.__status || 200;
    return { ok: status < 400, status, headers: { get: () => null },
             json: async () => body, text: async () => JSON.stringify(body) };
  };
  w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){} };
  w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
  w.PerformanceObserver = class { observe(){} disconnect(){} };
  w.matchMedia = q => ({ matches: false, media: q, addEventListener(){}, removeEventListener(){},
                         addListener(){}, removeListener(){} });
  w.scrollTo = () => {};
  w.Blob = class { constructor(parts){ this.parts = parts; } };
  w.URL = w.URL || {};
  w.URL.createObjectURL = b => b;
  w.Worker = class {                     // 真跑 app.js 里同一段 Worker 源码
    constructor(blob) {
      const self = { postMessage: d => { if (this.onmessage) this.onmessage({ data: d }); } };
      const fn = new Function('self', 'TextEncoder', blob.parts[0] + '\nreturn self;');
      this._self = fn(self, TextEncoder);
      this.onmessage = null;
    }
    postMessage(d) { this._self.onmessage({ data: d }); }
  };
  // 外链脚本拦截:Turnstile 按场景成功(注入 window.turnstile 桩)或失败
  const realAppend = w.document.head.appendChild.bind(w.document.head);
  w.document.head.appendChild = el => {
    if (el && el.tagName === 'SCRIPT' && el.src) {
      net.scripts.push(el.src);
      setTimeout(() => {
        if (sc.scriptFail) { el.onerror && el.onerror(new Error('blocked')); return; }
        if (/challenges\.cloudflare\.com\/turnstile/.test(el.src)) {
          let lastOpts = null;
          w.turnstile = {
            render(box, opts) {
              net.renders.push({ box: box && box.id, opts });
              lastOpts = opts;
              setTimeout(() => {
                if (sc.tsError) { opts['error-callback'] && opts['error-callback']('300030'); return; }
                opts.callback && opts.callback(TS_TOKEN);
              }, 30);
              return 'wid-' + net.renders.length;
            },
            reset(id) {                  // 真 Turnstile:reset 后重新出题,通过即再回调一枚新令牌
              net.resets++; net.lastResetId = id;
              if (sc.tsReissue && lastOpts) setTimeout(() => lastOpts.callback(TS_TOKEN + '-' + net.resets), 30);
            },
          };
        } else if (/static\.geetest\.com\/v4\/gt4\.js/.test(el.src)) {
          w.initGeetest4 = (cfg, cb) => {
            net.gtInits.push(cfg);
            const obj = {
              appendTo(box) { net.gtBox = box && box.id; return obj; },
              onSuccess(fn) { setTimeout(fn, 40); return obj; },
              onError(fn) { obj._err = fn; return obj; },
              getValidate() { return { lot_number: 'L1', captcha_output: 'O', pass_token: 'P', gen_time: '1700000000' }; },
              reset() { net.gtResets++; },
            };
            cb(obj);
          };
        } else if (/turing\.captcha\.qcloud\.com\/TCaptcha\.js/.test(el.src)) {
          w.TencentCaptcha = class {
            constructor(appId, cb) { this.cb = cb; net.tcInits.push(appId); }
            show() { setTimeout(() => this.cb(sc.tcCancel ? { ret: 2 } : { ret: 0, ticket: 'TK', randstr: 'RS' }), 30); }
          };
        }
        el.onload && el.onload();
      }, sc.scriptDelay || 10);
      return el;
    }
    return realAppend(el);
  };
  const s = w.document.createElement('script');
  s.textContent = appjs;
  w.document.body.appendChild(s);
  await sleep(400);
  const $ = q => w.document.querySelector(q);
  const login = async (u, p, waitMs = 2500) => {
    $('#authUser').value = u;
    $('#authPass').value = p;
    $('#authForm').dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
    const t0 = Date.now();
    while (Date.now() - t0 < waitMs) {
      await sleep(40);
      if (reloads > 0 || (!$('#authSubmit').disabled && net.logins.length)) break;
    }
    await sleep(320);                    // 让成功分支的 reload 计时器走完
  };
  return { w, $, net, login, reloads: () => reloads };
}

const SESSION_BASE = { ok: true, enabled: true, authed: false, state: 'auth_required',
                       pow: { enabled: false }, reg: { mode: 'off' } };

(async () => {
  console.log('登录防爆破(5.2.0)前端整机冒烟 —— 交付版 index.html + app.js @ jsdom\n');

  // ① 未触发加码:一次提交,零附加字段
  {
    const p = await boot({ session: { ...SESSION_BASE, login: {} },
                           onLogin: () => ({ ok: true, user: { id: 2 } }) });
    A('① 门已拉起,验证码位默认隐藏', !p.$('#authGate').hidden && p.$('#authCaptchaBox').hidden);
    await p.login('plainuser', 'plain#pw');
    const req = p.net.logins[0] && p.net.logins[0].req;
    A('① 只发一次登录请求', p.net.logins.length === 1);
    A('① 载荷与旧版一致(无 challengeId/nonce/captchaToken)',
      req && !('challengeId' in req) && !('nonce' in req) && !('captchaToken' in req));
    A('① 登录成功触发 reload 收束', p.reloads() === 1);
  }

  // ② 428 仅 PoW → 自动解题重提;服务端同款校验 nonce
  {
    const salt = crypto.randomBytes(16).toString('hex');
    let verified = false;
    const p = await boot({ session: { ...SESSION_BASE, login: {} }, onLogin: (b, n) => {
      if (n === 1) return { __status: 428, ok: false, error: 'challenge_required', reason: 'risk',
                            message: '需要完成安全校验,请刷新页面后重试',
                            challenge: { challengeId: 'c'.repeat(32), salt, bits: 10, ttl: 300 } };
      verified = b.challengeId === 'c'.repeat(32) && verifyPow(salt, b.nonce, 10);
      return verified ? { ok: true, user: { id: 2 } } : { __status: 428, ok: false, error: 'challenge_required' };
    } });
    await p.login('plainuser', 'plain#pw', 6000);
    A('② 428 后自动重提(共 2 次请求)', p.net.logins.length === 2);
    A('② 重提的 nonce 过服务端同款校验(真解,非糊弄)', verified);
    A('② 重提仍带原用户名/口令', p.net.logins[1] && p.net.logins[1].req.userName === 'plainuser'
      && p.net.logins[1].req.password === 'plain#pw');
    A('② 解题后登录成功并 reload', p.reloads() === 1);
    A('② 未出现「请刷新页面」这类写给旧页面的文案', !/刷新/.test(p.$('#authMsg').textContent));
  }

  // ③ always 档:开门即挂 Turnstile(action=login),提交带令牌
  {
    const cap = { provider: 'turnstile', appId: TS_SITEKEY, action: 'login' };
    const p = await boot({ session: { ...SESSION_BASE, login: { captcha: cap, captchaMode: 'always' } },
                           onLogin: b => (b.captchaToken === TS_TOKEN ? { ok: true, user: { id: 2 } }
                             : { __status: 428, ok: false, error: 'challenge_required', captcha: cap }) });
    await sleep(200);
    const r0 = p.net.renders[0];
    A('③ 开门即挂挂件(未提交前已渲染)', p.net.renders.length === 1 && p.net.logins.length === 0);
    A('③ 挂件挂在登录门 #authCaptchaBox,sitekey 正确,action=login',
      r0 && r0.box === 'authCaptchaBox' && r0.opts.sitekey === TS_SITEKEY && r0.opts.action === 'login');
    A('③ 验证码位已显示', !p.$('#authCaptchaBox').hidden);
    await p.login('plainuser', 'plain#pw', 3000);
    A('③ 首次提交即携带令牌并登录成功', p.net.logins.length === 1
      && p.net.logins[0].req.captchaToken === TS_TOKEN && p.reloads() === 1);
  }

  // ④ risk 档:428 同时要验证码 + PoW → 令牌 + 真解 → 重提
  {
    const cap = { provider: 'turnstile', appId: TS_SITEKEY, action: 'login' };
    const salt = crypto.randomBytes(16).toString('hex');
    let ok2 = false;
    const p = await boot({ session: { ...SESSION_BASE, login: { captcha: cap, captchaMode: 'risk' } },
      onLogin: (b, n) => {
        if (n === 1) return { __status: 428, ok: false, error: 'challenge_required', reason: 'risk',
                              captcha: cap, challenge: { challengeId: 'd'.repeat(32), salt, bits: 9, ttl: 300 } };
        ok2 = b.captchaToken === TS_TOKEN && verifyPow(salt, b.nonce, 9);
        return ok2 ? { ok: true, user: { id: 2 } } : { __status: 400, ok: false, error: 'pow_failed' };
      } });
    A('④ risk 档开门不挂挂件(正常用户零打扰)', p.net.renders.length === 0);
    await p.login('plainuser', 'plain#pw', 6000);
    A('④ 428 后按需挂件', p.net.renders.length === 1 && p.net.renders[0].opts.action === 'login');
    A('④ 重提同时带令牌与真解', ok2 && p.net.logins.length === 2);
    A('④ 登录成功', p.reloads() === 1);
  }

  // ⑤ 验证码脚本加载失败 → 明确提示、按钮复位、不发无令牌请求
  {
    const cap = { provider: 'turnstile', appId: TS_SITEKEY, action: 'login' };
    const p = await boot({ scriptFail: true,
      session: { ...SESSION_BASE, login: { captcha: cap, captchaMode: 'always' } },
      onLogin: () => ({ ok: true }) });
    await p.login('plainuser', 'plain#pw', 3000);
    A('⑤ 不发登录请求(令牌拿不到就不硬闯)', p.net.logins.length === 0);
    A('⑤ 文案明确「人机验证加载失败」', /人机验证加载失败/.test(p.$('#authMsg').textContent));
    A('⑤ 按钮复位可再试', !p.$('#authSubmit').disabled && /登\s*录/.test(p.$('#authSubmit').textContent));
  }

  // ⑥ 429 throttled
  {
    const p = await boot({ session: { ...SESSION_BASE, login: {} },
      onLogin: () => ({ __status: 429, ok: false, error: 'throttled', retryAfter: 540,
                        message: '尝试过于频繁,请 9 分钟后再试' }) });
    await p.login('plainuser', 'wrong');
    A('⑥ 429 文案如实', /尝试过于频繁/.test(p.$('#authMsg').textContent));
    A('⑥ 按钮复位', !p.$('#authSubmit').disabled);
  }

  // ⑦ 注册与登录共用 Turnstile:api.js 只加载一次,两枚挂件各标各的 action
  {
    const cap = { provider: 'turnstile', appId: TS_SITEKEY, action: 'login' };
    const p = await boot({ session: { ...SESSION_BASE, reg: { mode: 'open', captcha: { provider: 'turnstile', appId: TS_SITEKEY } },
                                      login: { captcha: cap, captchaMode: 'always' } },
                           onLogin: () => ({ ok: true }) });
    await sleep(200);
    p.$('#authToReg').click();
    await sleep(400);
    const ts = p.net.scripts.filter(u => /challenges\.cloudflare\.com\/turnstile/.test(u));
    A('⑦ 注册与登录同用 Turnstile:api.js 只加载一次', ts.length === 1);
    A('⑦ 两枚挂件各自渲染,action 分别为 login / register',
      p.net.renders.length === 2 && p.net.renders.some(r => r.opts.action === 'login')
      && p.net.renders.some(r => r.opts.action === 'register'));
  }

  // ⑧ always 档:脚本还在加载时用户就点了登录 → 只渲染一枚挂件,首次提交即带令牌
  {
    const cap = { provider: 'turnstile', appId: TS_SITEKEY, action: 'login' };
    const p = await boot({ scriptDelay: 900, session: { ...SESSION_BASE, login: { captcha: cap, captchaMode: 'always' } },
                           onLogin: b => (b.captchaToken === TS_TOKEN ? { ok: true, user: { id: 2 } }
                             : { __status: 428, ok: false, error: 'challenge_required', captcha: cap }) });
    await p.login('plainuser', 'plain#pw', 3000);
    A('⑧ 预挂与提交并发:同一容器只渲染一枚挂件', p.net.renders.length === 1);
    A('⑧ 首次提交即带令牌并登录成功', p.net.logins.length === 1 && p.net.logins[0].req.captchaToken === TS_TOKEN && p.reloads() === 1);
  }

  // ⑨ 注册卡片来回切换过快:注册挂件同样只渲染一枚
  {
    const p = await boot({ scriptDelay: 700, session: { ...SESSION_BASE, login: {},
                           reg: { mode: 'open', captcha: { provider: 'turnstile', appId: TS_SITEKEY } } },
                           onLogin: () => ({ ok: true }) });
    p.$('#authToReg').click(); await sleep(60);
    if (p.$('#regBack')) p.$('#regBack').click();
    await sleep(60);
    p.$('#authToReg').click();
    await sleep(1200);
    const regRenders = p.net.renders.filter(r => r.opts.action === 'register');
    A('⑨ 切卡片过快:注册挂件只渲染一枚', regRenders.length === 1);
  }

  // ⑩ always 档口令错:用过的令牌作废 → 挂件 reset 重新出题 → 第二次提交带的是新令牌
  {
    const cap = { provider: 'turnstile', appId: TS_SITEKEY, action: 'login' };
    const p = await boot({ tsReissue: true, session: { ...SESSION_BASE, login: { captcha: cap, captchaMode: 'always' } },
      onLogin: (b, n) => n === 1 ? { __status: 401, ok: false, error: 'bad_credentials', message: '用户名或密码错误' }
                                 : { ok: true, user: { id: 2 } } });
    await p.login('plainuser', 'bad');
    A('⑩ 口令错后挂件被 reset(令牌单次有效)', p.net.resets === 1 && p.net.lastResetId === 'wid-1');
    A('⑩ 错误文案如实、按钮复位', /用户名或密码错误/.test(p.$('#authMsg').textContent) && !p.$('#authSubmit').disabled);
    await sleep(120);
    await p.login('plainuser', 'plain#pw');
    A('⑩ 第二次提交带新令牌并登录成功', p.net.logins.length === 2 && p.net.logins[1].req.captchaToken === TS_TOKEN + '-1'
      && p.reloads() === 1);
  }

  // ⑪ 极验 v4(risk 档):428 要验证码 → initGeetest4 挂件 → onSuccess → getValidate() 作令牌
  {
    const cap = { provider: 'geetest', appId: 'gt-id-1', action: 'login' };
    const p = await boot({ session: { ...SESSION_BASE, login: { captcha: cap, captchaMode: 'risk' } },
      onLogin: b => b.captchaToken ? { ok: true, user: { id: 2 } }
                                   : { __status: 428, ok: false, error: 'challenge_required', reason: 'risk', captcha: cap } });
    await p.login('plainuser', 'plain#pw', 4000);
    const tok = (() => { try { return JSON.parse(p.net.logins[1].req.captchaToken); } catch { return {}; } })();
    A('⑪ 极验按 captchaId + float 初始化并挂进登录容器', p.net.gtInits.length === 1 && p.net.gtInits[0].captchaId === 'gt-id-1'
      && p.net.gtInits[0].product === 'float' && p.net.gtBox === 'authCaptchaBox');
    A('⑪ 重提的令牌即 getValidate() 四字段', tok.lot_number === 'L1' && tok.pass_token === 'P' && tok.gen_time === '1700000000');
    A('⑪ 登录成功', p.reloads() === 1);
  }

  // ⑫ 腾讯云(risk 档):弹窗式 —— 成功取 ticket/randstr;用户关掉弹窗则明确提示、不再重提
  {
    const cap = { provider: 'tencent', appId: '2000000000', action: 'login' };
    const p = await boot({ session: { ...SESSION_BASE, login: { captcha: cap, captchaMode: 'risk' } },
      onLogin: b => b.captchaToken ? { ok: true, user: { id: 2 } }
                                   : { __status: 428, ok: false, error: 'challenge_required', reason: 'risk', captcha: cap } });
    await p.login('plainuser', 'plain#pw', 4000);
    const tok = (() => { try { return JSON.parse(p.net.logins[1].req.captchaToken); } catch { return {}; } })();
    A('⑫ 腾讯云按 CaptchaAppId 唤起并回 ticket/randstr', p.net.tcInits[0] === '2000000000' && tok.ticket === 'TK' && tok.randstr === 'RS');
    A('⑫ 登录成功', p.reloads() === 1);
    const q = await boot({ tcCancel: true, session: { ...SESSION_BASE, login: { captcha: cap, captchaMode: 'risk' } },
      onLogin: () => ({ __status: 428, ok: false, error: 'challenge_required', reason: 'risk', captcha: cap }) });
    await q.login('plainuser', 'plain#pw', 3000);
    A('⑫ 关掉弹窗:提示已取消、只发过一次请求、按钮复位', /已取消人机验证/.test(q.$('#authMsg').textContent)
      && q.net.logins.length === 1 && !q.$('#authSubmit').disabled);
  }

  // ⑬ Turnstile 挂件自报错误(error-callback):等令牌的请求被明确拒绝,不发无令牌请求
  {
    const cap = { provider: 'turnstile', appId: TS_SITEKEY, action: 'login' };
    const p = await boot({ tsError: true, session: { ...SESSION_BASE, login: { captcha: cap, captchaMode: 'risk' } },
      onLogin: () => ({ __status: 428, ok: false, error: 'challenge_required', reason: 'risk', captcha: cap }) });
    await p.login('plainuser', 'plain#pw', 3000);
    A('⑬ 挂件报错 → 提示加载失败、只发过一次请求、按钮复位', /人机验证加载失败/.test(p.$('#authMsg').textContent)
      && p.net.logins.length === 1 && !p.$('#authSubmit').disabled);
  }

  console.log(`\n合计:${PASS} 通过 / ${FAIL} 失败`);
  if (FAIL) process.exit(1);
  process.exit(0);
})().catch(e => { console.error('冒烟异常:', e); process.exit(1); });
