#!/usr/bin/env bash
# =============================================================================
# pg_diagnose.sh —— 一次性定位 PostgreSQL 的间歇性高 CPU（4.9.5）
#
# 为什么需要它：本项目的 PG 负载里，会「突然出现 → 持续一段 → 自己恢复」的
# 只有**周期性批量作业**（结构性慢查询是恒定开销，不会自愈）。候选就四个，
# 本脚本逐个取证，不猜：
#     ① 每小时的 retention 清理（sweep_interval_s=3600）及其引发的 autovacuum
#     ② 反回卷 autovacuum（anti-wraparound）—— 不可跳过、全表全索引扫，最像「突然」
#     ③ 配置热更触发的全舰队命中率补算重跑
#     ④ 连接池饥饿（worker 副本数超出 max_connections 账本）
#
# 用法：
#     bash pg_diagnose.sh                      # 自动从 compose 读连接信息
#     PGC=<容器名> PGU=star PGD=spelltamer bash pg_diagnose.sh
#
# 高 CPU **正在发生时**跑一次，恢复正常后再跑一次，对比 §1/§3/§5 即可定案。
# =============================================================================
set -uo pipefail

PGC="${PGC:-$(docker ps --format '{{.Names}}' 2>/dev/null | grep -i postgres | head -1)}"
PGU="${PGU:-star}"
PGD="${PGD:-spelltamer}"

if [ -z "$PGC" ]; then
  echo "找不到 postgres 容器。请显式指定：PGC=<容器名> bash $0" >&2; exit 1
fi
Q () { docker exec -i "$PGC" psql -U "$PGU" -d "$PGD" -X -q "$@"; }

echo "════════════════════════════════════════════════════════════════"
echo " PG 诊断 · 容器=$PGC · $(date '+%F %T')"
echo "════════════════════════════════════════════════════════════════"

echo
echo "── §1 此刻在跑什么（高 CPU 时这里就是答案）──────────────────────"
echo "   看 backend_type：autovacuum worker = 是 vacuum 在烧；client backend = 是业务 SQL"
Q -c "
SELECT pid, backend_type, state, wait_event_type||'/'||COALESCE(wait_event,'-') AS 等待,
       date_trunc('second', now()-query_start) AS 已跑,
       left(regexp_replace(query,'\s+',' ','g'), 90) AS 语句
  FROM pg_stat_activity
 WHERE backend_type <> 'client backend' OR state <> 'idle'
 ORDER BY query_start NULLS LAST;"

echo "── §2 索引使用率与膨胀（本项目最容易出问题的一节）────────────────"
echo "   累计被扫=0 ⇒ 该索引自统计重置以来一次都没被读过（可考虑删）"
Q -c "
WITH ix AS (
  SELECT s.relname AS tbl, s.indexrelname AS idx, s.idx_scan AS scans,
         pg_relation_size(s.indexrelid) AS bytes, c.reltuples::bigint AS rows
    FROM pg_stat_user_indexes s JOIN pg_class c ON c.oid = s.relid
   WHERE s.schemaname = 'public')
SELECT tbl AS 表, idx AS 索引, scans AS 累计被扫,
       pg_size_pretty(bytes) AS 体积, rows AS 表行数,
       ROUND(bytes / GREATEST(GREATEST(rows,1)*32/0.9, 1), 1) AS 膨胀比,
       CASE WHEN scans = 0 THEN '← 零使用'
            WHEN bytes / GREATEST(GREATEST(rows,1)*32/0.9, 1) > 3
             AND bytes > 50*1024*1024 THEN '← 严重膨胀,跑 pg_maintenance.sh'
            ELSE '' END AS 判定
  FROM ix ORDER BY bytes DESC;
SELECT COALESCE(stats_reset::text,'从未重置 ⇒ 上面的「累计被扫」是建库以来的总量,'
       ||'反映历史而非当前行为') AS 统计重置于
  FROM pg_stat_database WHERE datname = current_database();"
echo "   膨胀比 = 当前体积 ÷ 理论体积(每行 ~32B、90% 填充)。>3 且 >50MB 即需 REINDEX ——"
echo "   B-tree 删除后不把空间还给 OS,而 VACUUM **每趟都要完整扫一遍索引**,"
echo "   空壳索引 = 每次 autovacuum 白读的字节数。"
echo "   若「统计重置于」为空,建议跑一次 pg_stat_reset() 后隔天再看,才能读出当前使用率。"

echo "── §3 死元组与 autovacuum 节拍（候选①）────────────────────────────"
echo "   retention 每小时删一批 → 死元组暴涨 → autovacuum 追着清 → CPU 满 → 清完恢复"
Q -c "
SELECT relname AS 表, n_live_tup AS 活元组, n_dead_tup AS 死元组,
       ROUND(100.0*n_dead_tup/GREATEST(n_live_tup,1),1) AS 死占比,
       autovacuum_count AS auto_vac次数,
       date_trunc('second', now()-last_autovacuum) AS 距上次auto_vac,
       date_trunc('second', now()-last_analyze)    AS 距上次手动analyze,
       date_trunc('second', now()-last_autoanalyze) AS 距上次auto_analyze
  FROM pg_stat_user_tables
 WHERE relname IN ('rounds','predictions','predictor_state','admin_audit') ORDER BY n_dead_tup DESC;"
echo "   注:purge_before 每轮清理完会显式跑 ANALYZE(手动),它会重置计数器,"
echo "      于是 auto_analyze 长期不触发 —— 「距上次 auto_analyze 很久」是正常的,"
echo "      要看的是「距上次手动 analyze」。统计并不陈旧。"

echo "── §4 反回卷距离（候选②：最像「突然来、跑很久、又好了」）──────────"
echo "   剩余XID < 2000万 ⇒ 随时可能触发全表反回卷 vacuum，届时必然长时间满核"
Q -c "
SELECT c.relname AS 表, age(c.relfrozenxid) AS XID年龄,
       current_setting('autovacuum_freeze_max_age')::bigint AS 触发阈值,
       current_setting('autovacuum_freeze_max_age')::bigint - age(c.relfrozenxid) AS 剩余XID,
       ROUND(100.0*age(c.relfrozenxid)/current_setting('autovacuum_freeze_max_age')::bigint,1) AS 已用百分比
  FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
 WHERE n.nspname='public' AND c.relkind='r'
 ORDER BY age(c.relfrozenxid) DESC LIMIT 6;"

echo "── §5 连接占用（候选④：池饥饿会让每次 PG 调用先排队）──────────────"
Q -c "
SELECT count(*) AS 当前连接,
       current_setting('max_connections')::int AS 上限,
       ROUND(100.0*count(*)/current_setting('max_connections')::int,1) AS 占用率,
       count(*) FILTER (WHERE state='active') AS 活跃,
       count(*) FILTER (WHERE state='idle in transaction') AS 事务中空闲
  FROM pg_stat_activity;"

echo "── §6 缓存命中率（<99% ⇒ shared_buffers 相对数据量偏小，转成磁盘读）──"
Q -c "
SELECT relname AS 表,
       ROUND(100.0*heap_blks_hit/GREATEST(heap_blks_hit+heap_blks_read,1),2) AS 堆命中率,
       ROUND(100.0*idx_blks_hit /GREATEST(idx_blks_hit +idx_blks_read ,1),2) AS 索引命中率
  FROM pg_statio_user_tables WHERE relname IN ('rounds','predictions','predictor_state','admin_audit');"

echo "── §7 表与索引体积（4.9.5 前索引通常大于堆；瘦身后应显著小于堆）────"
Q -c "
SELECT relname AS 表, pg_size_pretty(pg_relation_size(oid)) AS 堆,
       pg_size_pretty(pg_indexes_size(oid)) AS 索引,
       pg_size_pretty(pg_total_relation_size(oid)) AS 合计
  FROM pg_class WHERE relname IN ('rounds','predictions','predictor_state','admin_audit');"

echo "── §8 索引迁移是否已生效 ─────────────────────────────────────────"
Q -c "
SELECT
  CASE WHEN EXISTS (SELECT 1 FROM pg_class WHERE relname='idx_pred_pending')
       THEN '✔ idx_pred_pending 已就位' ELSE '✘ idx_pred_pending 缺失（前端 /prediction 仍在扫全房）' END
UNION ALL SELECT
  CASE WHEN EXISTS (SELECT 1 FROM pg_class WHERE relname IN
        ('idx_rounds_room_draw','idx_rounds_room_start','idx_rounds_room_date','idx_pred_room_hit'))
       THEN '✘ 仍有旧索引残留（重启一次 worker 会自动迁移）' ELSE '✔ 旧索引已全部清除' END
UNION ALL SELECT
  CASE WHEN EXISTS (SELECT 1 FROM pg_index i JOIN pg_class c ON c.oid=i.indexrelid
                     WHERE NOT i.indisvalid)
       THEN '✘ 存在 INVALID 索引（CONCURRENTLY 建到一半失败，重启 worker 会自动清理重建）'
       ELSE '✔ 无 INVALID 索引' END;"

echo "── §9 清理周期 × VACUUM 的关联（间歇性 CPU 的主因判据）─────────────"
echo "   retention 每小时删一批 → 死元组累积过阈 → autovacuum 全量扫索引 → CPU 尖峰 → 恢复"
Q -c "
SELECT c.relname AS 表,
       pg_size_pretty(pg_indexes_size(c.oid)) AS 每趟vacuum要扫的索引量,
       (50000 + 0.02 * s.n_live_tup)::bigint  AS 触发vacuum的死元组阈值,
       s.n_dead_tup AS 当前死元组,
       ROUND(100.0*s.n_dead_tup/GREATEST((50000+0.02*s.n_live_tup),1),1) AS 距触发百分比
  FROM pg_class c JOIN pg_stat_user_tables s ON s.relid = c.oid
 WHERE c.relname IN ('rounds','predictions','predictor_state','admin_audit');"
echo "   把「每趟要扫的索引量」乘以 vacuum 频率,就是这台机器周期性烧掉的 I/O+CPU。"
echo "   降它有两条路:① pg_maintenance.sh 重建膨胀索引(减少扫描量);"
echo "                 ② 调低 per-table autovacuum_vacuum_cost_limit(降低瞬时强度)。"

echo
echo "════════════════════════════════════════════════════════════════"
echo " 怎么读："
echo "   §1 出现 'autovacuum: VACUUM public.rounds' ⇒ 候选①或② 成立"
echo "      → 再看 §4：已用百分比 >90% 就是②反回卷；否则是①清理引发的常规 vacuum"
echo "   §1 出现业务 SQL 长时间 active   ⇒ 抓那条语句单独 EXPLAIN ANALYZE"
echo "   §1 大量 wait_event_type=Lock    ⇒ 锁竞争，看谁持锁"
echo "   §5 占用率 >90% 或事务中空闲多   ⇒ 候选④池饥饿，减 worker 副本或加 max_connections"
echo "   §3 死占比长期 >20%              ⇒ autovacuum 追不上，需要再调 per-table 参数"
echo "   §2 膨胀比 >3 且 >50MB           ⇒ 空壳索引，跑 pg_maintenance.sh --reindex"
echo "   §9 每趟要扫的索引量 远大于堆    ⇒ 同上；这是周期性 CPU 尖峰的直接燃料"
echo "════════════════════════════════════════════════════════════════"
