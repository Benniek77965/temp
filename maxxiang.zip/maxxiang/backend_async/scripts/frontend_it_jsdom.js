/* 用法:项目根 `npm i jsdom` 后 `node backend_async/scripts/frontend_it_jsdom.js`(需 Node ≥20)。 */
/* 整机集成冒烟:交付版 index.html + app.js 在 jsdom 真 DOM 中原样执行,
   仅桩网络(fetch/EventSource)与个别浏览器观测器。断言覆盖 boot→入口→
   回看直达→翻日→回实时→守卫隔离→Esc 焦点契约 的完整用户链路。 */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const path = require('path');
const ROOT = path.resolve(__dirname, '..', '..');   // backend_async/scripts → 项目根
const html = fs.readFileSync(ROOT + '/index.html', 'utf8');
const appjs = fs.readFileSync(ROOT + '/assets/app.js', 'utf8');

const DAY = 86400000, BJ = 8 * 3600 * 1000;
const bjMid = ms => { const t = ms + BJ; return t - (t % DAY) - BJ; };
const iso = ms => new Date(ms + BJ).toISOString().slice(0, 10);
const today0 = bjMid(Date.now());
const yd = today0 - DAY, ereyd = today0 - 2 * DAY;
const STEP = 50001;
const mkRound = (start, n) => ({
  round_id: String(start), beast_id: n, beast_name: '兽' + n,
  spell_key: '法' + n, spell_name: '御法' + n, display_number: n,
  multiplier: n * 10, start_time_ms: start, spell_time_ms: start + 35000,
  draw_time_ms: start + 40000, end_time_ms: start + 50000,
  source: 'GameHistory', captured_at: '',
});
const todayRounds = [1, 2, 3, 4, 5].map((n, i) => mkRound(today0 + 3600e3 + i * STEP, n)); // 今晨 5 局
const ydRounds = [7, 8, 9].map((n, i) => mkRound(yd + 3600e3 + i * STEP, n));              // 昨天 3 局
const ereRounds = [4, 6].map((n, i) => mkRound(ereyd + 3600e3 + i * STEP, n));             // 前天 2 局
const spells = [1,2,3,4,5,6,7,8,9].map(n => ({ display_number: n, spell_key: '法'+n,
  spell_name: '御法'+n, beast_name: '兽'+n, beast_id: n, multiplier: n*10,
  probability: '11.1%', room_id: '888' }));

function routeApi(url) {
  const u = new URL(url, 'http://t/');
  const p = u.pathname, q = u.searchParams;
  if (p === '/api/live-rooms') return { ok: true, rooms: [{ alias: '888', roomId: '888',
    nickname: '测试房', avatar: '', canPlay: '1', serverNowMs: Date.now(), serverOffsetMs: 0 }] };
  if (p === '/api/live-rooms/888/profile') return { ok: true, profile: { alias: '888',
    roomId: '888', nickname: '测试房', avatar: '' } };
  if (p === '/api/rooms/888/config') return { ok: true, roomId: '888', spells };
  if (p === '/api/rooms/888/history/days') return { ok: true, roomId: '888', retentionDays: 3,
    days: [
      { date: iso(today0), dayStartMs: today0, n: todayRounds.length, firstMs: 0, lastMs: 0 },
      { date: iso(yd), dayStartMs: yd, n: ydRounds.length, firstMs: 0, lastMs: 0 },
      { date: iso(ereyd), dayStartMs: ereyd, n: ereRounds.length, firstMs: 0, lastMs: 0 },
    ] };
  if (p === '/api/rooms/888/history') {
    const since = Number(q.get('since') || 0), until = Number(q.get('until') || 0);
    let rows = [...todayRounds, ...ydRounds, ...ereRounds];
    rows = rows.filter(r => r.start_time_ms >= since && (!until || r.start_time_ms < until));
    rows.sort((a, b) => b.start_time_ms - a.start_time_ms);
    return { ok: true, roomId: '888', since: String(since), until: String(until), rounds: rows };
  }
  if (p === '/api/rooms/888/prediction') return { ok: true, roomId: '888', target_round_id: null,
    main: [], guard: [], record: [], ens: [], accuracy: null, serverNowMs: Date.now() };
  if (p.startsWith('/api/rooms/888/coverage')) return { ok: true, roomId: '888', missing: [] };
  return { ok: true };
}

const dom = new JSDOM(html, { url: 'http://localhost/', pretendToBeVisual: true, runScripts: 'dangerously' });
const w = dom.window;
w.fetch = async (input) => {
  const url = typeof input === 'string' ? input : input.url;
  const body = routeApi(url);
  return { ok: true, status: 200, headers: { get: () => null },
    json: async () => body, text: async () => JSON.stringify(body) };
};
w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){ this.readyState = 2; } };
w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
w.PerformanceObserver = class { observe(){} disconnect(){} };
w.matchMedia = w.matchMedia || (q => ({ matches: false, media: q, addEventListener(){}, removeEventListener(){}, addListener(){}, removeListener(){} }));
w.scrollTo = () => {};
// 尺寸改在注入前设置(见下)

const errs = [];
w.addEventListener('error', e => errs.push('winerr:' + (e.message || e.error)));

const A = (n, c) => { console.log(`  [${c ? '✓' : '✗'}] ${n}`); if (!c) process.exitCode = 1; };
const $ = sel => w.document.querySelector(sel);
const beads = el => el.querySelectorAll('.bead').length;
const click = el => el.dispatchEvent(new w.Event('click', { bubbles: true }));
const key = (k) => w.document.dispatchEvent(new w.KeyboardEvent('keydown', { key: k, bubbles: true }));
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  w.innerWidth = 1680; w.innerHeight = 960;   // runScripts 域内可见
  // jsdom 无布局:offsetParent 恒 null 会让 onScreen/Tab 收容误判"不可见"——垫真值
  Object.defineProperty(w.HTMLElement.prototype, 'offsetParent',
    { get(){ let n = this; while (n){ if (n.hidden) return null; n = n.parentElement; }
             return this.parentElement; }, configurable: true });   // 尊重 [hidden] 祖先,贴近真布局语义
  const _rect = w.Element.prototype.getBoundingClientRect;
  w.Element.prototype.getBoundingClientRect = function(){   // onScreen 还查非零矩形(app.js L2686)——给未隐藏元素一个真实盒
    let n=this; while(n){ if(n.hidden) return _rect.call(this); n=n.parentElement; }
    return { width:10, height:10, left:1, right:11, top:1, bottom:11, x:1, y:1 };
  };
  try {
    const sc = w.document.createElement('script');
    sc.textContent = appjs;
    w.document.body.appendChild(sc);           // 经 jsdom 正门执行,作用域链完整
  } catch (e) { console.log('  [✗] app.js 顶层执行:', e.message); process.exit(1); }
  await sleep(400);   // boot:live-rooms→loadRoom(三连)→renderAll→wvLoadDays

  const S = w.__jf.S;
  /* ★ 5.0.5 订正(实测定案):此处原写 `=== 10`,那是 **3.8.2 之前**的期望 ——
     本 mock 的 10 局刻意跨三天(今晨 5 / 昨天 3 / 前天 2)以喂饱按日回看,而 3.8.2
     起 S.hist 被 pruneHistWindow 钉真到「最新一局 − 24h」锚定窗,昨天/前天那 5 局
     必然出窗。实测:真珠 5、占位 0。断言随已发布语义改为 5,并把口径写进名字里,
     免得下次又有人按「10 局」去猜。同一根因级联到下方三条(全屏 live 珠数),一并订正。 */
  A('整机 boot:进房 + 序列落满 24h 锚定窗(今日 5 局;昨/前天已出窗)',
    S.alias === '888' && beads($('#roadGrid')) === 5);
  A('入口:「回看」按钮可见 · 「全屏」带回看提示(驾驶舱态)',
    $('#roadReplay').hidden === false && /回看/.test($('#roadExpand').title));

  $('#roadReplay').focus(); click($('#roadReplay')); await sleep(80);
  A('直达:全屏开+落最近回放日(昨天)+3 珠+无悬挂珠',
    $('#wideView').hidden === false && w.eval('WV.mode') === 'day'
    && $('#wvDay').value === iso(yd) && beads($('#wideGrid')) === 3
    && !$('#wideGrid .bead-pending'));
  A('九宫简报可见且含首局时刻', $('#wvCensus').hidden === false && /首局/.test($('#wvCensus').textContent));
  A('日导航行可见 · 「回到实时」出现', $('#wideNav').hidden === false && $('#wvLiveBtn').hidden === false);

  key('ArrowLeft'); await sleep(80);
  A('← 翻至前天:value/珠数同步', $('#wvDay').value === iso(ereyd) && beads($('#wideGrid')) === 2);

  key('ArrowRight'); await sleep(30);
  key('ArrowRight'); await sleep(30);
  A('→×2 越过最新回放日=回实时(悬挂珠回归)',
    w.eval('WV.mode') === 'live' && !!$('#wideGrid .bead-pending') && beads($('#wideGrid')) === 5);

  click($('#roadReplay')); await sleep(60);   // 再入昨天(缓存命中)
  const wideBefore = beads($('#wideGrid'));
  w.__jf.ingest(mkRound(todayRounds[4].start_time_ms + STEP, 6));   // 实时新局到账
  await sleep(30);
  A('守卫:回看态下实时 ingest 不扰全屏(珠数不变),主盘 +1',
    beads($('#wideGrid')) === wideBefore && beads($('#roadGrid')) === 6);

  click($('#wvLiveBtn')); await sleep(30);
  A('「回到实时」:全屏立现新珠(6)+悬挂珠',
    beads($('#wideGrid')) === 6 && !!$('#wideGrid .bead-pending'));

  key('Escape'); await sleep(20);   // 收掉长流程遗留的层(其 opener 已被中途 reopen 覆写,不作焦点断言)
  $('#roadReplay').focus(); click($('#roadReplay')); await sleep(60);   // 干净场景:opener=roadReplay
  key('Escape'); await sleep(20);
  const ae = w.document.activeElement;
  console.log('   [诊断] wideView.hidden=', $('#wideView').hidden,
    '| opener.id=', w.eval('S._wideOpener && S._wideOpener.id'),
    '| activeElement=', ae && (ae.id || ae.tagName));
  A('Esc:关层+焦点归还开启处(roadReplay,2.6.4 契约在 3.6.0 入口上成立)',
    $('#wideView').hidden === true && ae === $('#roadReplay'));

  A('零未捕获异常(__errlog 空)', (w.__errlog || []).length === 0 && errs.length === 0);
  if ((w.__errlog||[]).length) console.log('   errlog:', JSON.stringify(w.__errlog.slice(0,3)));
  process.exit(process.exitCode || 0);
})();
