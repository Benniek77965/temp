#!/usr/bin/env python3
"""
smoke_auth.py — 登录系统(3.8.0)端到端冒烟
================================================================================
以 httpx ASGITransport 直插 FastAPI 应用(真实 lifespan:连 PG/Redis/用户库、
自动建 guantai_ 新表、起 kick 订阅),逐条走真实 HTTP 面:

  门与豁免      /api/version 免登录;/api/live-rooms 未登录 401;静态壳放行
  登录语义      密错 401 / 过期 403 expired / 封停 403 banned / 成功 200+Cookie
  CSRF 防线     带 Cookie 不带 X-JF-Auth 头 → 403 bad_origin;SSE 豁免头
  按账号隔离    A 添加房 → A 可见/可读明细;B 登录 → 名录空、读 A 的房 403
                room_not_bound、SSE 订阅同样 403;B 自添同房 → 共享全局监控
  引用计数删除  A 删房(B 仍绑)→ 全局监控保留;B 再删 → 用户转正房全局退场
  互顶          同账号二次登录 → 旧会话 401 kicked
  登出          登出后旧 Cookie 一律 401
  首登预置房    首次登录自动入名录(alias=短号);未在监控则防御性全局登记;
                与自添同权可删;删后再登录**不复种**(user_first_login 一次性标记)

上游归一(star.canon)与在播判定按「测试替身」注入 —— 不打酷狗;其余全部真实。
用法(需本地 PG/Redis/用户库三件套;开发容器口令见 tests/test_userauth.py):
    cd backend_async && python3 scripts/smoke_auth.py
"""
from __future__ import annotations

import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 环境必须先于 app 导入(settings 是 import 期单例)
os.environ.setdefault("STA_PG_DSN", "postgresql://star:star@127.0.0.1:5432/spelltamer")
os.environ.setdefault("STA_REDIS_URL", "redis://127.0.0.1:6379/0")
os.environ.setdefault("STA_USERDB_HOST", "127.0.0.1")
os.environ.setdefault("STA_USERDB_PORT", "3307")
os.environ.setdefault("STA_USERDB_NAME", "fanxing_changkong_user_db")
os.environ.setdefault("STA_USERDB_USER", "fanxing_admin")
os.environ.setdefault("STA_USERDB_PASSWORD", "fanxing_admin,.")
os.environ.setdefault("STA_USER_CACHE_TTL_S", "0")      # 冒烟逐次过库,互顶即刻可见
os.environ.setdefault("STA_MONITOR_WRITE_TOKEN", "smoketok")   # 运维旁路回归用
os.environ.setdefault("STA_USER_FIRST_LOGIN_ROOM", "off")      # 基线段名录从空开始;首登预置在下方专段单测

import httpx  # noqa: E402
import pymysql  # noqa: E402

PASS = 0


def ok(cond: bool, what: str, extra: str = ""):
    global PASS
    mark = "✓" if cond else "✗"
    print(f"  {mark} {what}" + (f" · {extra}" if extra else ""))
    if not cond:
        raise SystemExit(f"冒烟失败:{what}")
    PASS += 1


def drop_guantai():
    """先删新表:证明 web 首启的自动幂等建表真实生效。"""
    conn = pymysql.connect(host="127.0.0.1", port=int(os.environ["STA_USERDB_PORT"]),
                           user=os.environ["STA_USERDB_USER"],
                           password=os.environ["STA_USERDB_PASSWORD"],
                           database=os.environ["STA_USERDB_NAME"], charset="gbk",
                           autocommit=True)
    with conn.cursor() as cur:
        cur.execute("DROP TABLE IF EXISTS guantai_user_session, guantai_login_log, "
                    "guantai_invite_code, guantai_reg_log, guantai_user_block, "
                    "guantai_sso_ticket")
    conn.close()


async def main() -> None:
    drop_guantai()
    from app import web  # noqa: PLC0415 —— env 就绪后再导入

    ROOM, ROOM_PIN, ROOM_CAS, ROOM_SSE = "654321", "654322", "654323", "654324"
    ROOM_QT_REAL, ROOM_QT_ALIAS = "654325", "888325"   # 配额双键回归:真号/短号映射对
    SEED_REAL, SEED_ALIAS = "654399", "888399"          # 首登预置房专用测试对

    _ALIAS_MAP = {ROOM_QT_ALIAS: ROOM_QT_REAL,
                  SEED_ALIAS: SEED_REAL}     # 短号→真号(其余恒等)
    async def fake_canon(room: str):          # 上游替身:恒可归一、恒 definitive
        r = str(room)
        return _ALIAS_MAP.get(r, r), True
    async def fake_profile(room: str):        # 展示资料替身:名录卡片不出网
        return {"nickname": "", "avatar": ""}

    async with web.app.router.lifespan_context(web.app):
        web.ST.star.canon = fake_canon
        web.ST.star.profile = fake_profile   # 首登预置段会渲染**非空**名录卡片
        for _r in (ROOM, ROOM_PIN, ROOM_CAS, ROOM_SSE, ROOM_QT_REAL):   # 播种五间发现房
            await web.ST.bus.add_room(_r, _r)
            await web.ST.bus.discovered_seen_bulk([_r])
        # 清理可能的既往绑定(幂等冒烟)
        async with web.ST.db.pool.acquire() as con:
            await con.execute("DELETE FROM user_rooms WHERE room_id = ANY($1::text[])",
                              [ROOM, ROOM_PIN, ROOM_CAS, ROOM_SSE,
                               ROOM_QT_REAL, ROOM_QT_ALIAS, SEED_REAL, SEED_ALIAS])
            await con.execute("DELETE FROM user_added_rooms WHERE room_id = ANY($1::text[])",
                              [ROOM, ROOM_PIN, ROOM_CAS, ROOM_SSE,
                               ROOM_QT_REAL, ROOM_QT_ALIAS, SEED_REAL, SEED_ALIAS])

        t = httpx.ASGITransport(app=web.app)
        H = {"X-JF-Auth": "1"}
        async with httpx.AsyncClient(transport=t, base_url="http://t") as A, \
                   httpx.AsyncClient(transport=t, base_url="http://t") as B, \
                   httpx.AsyncClient(transport=t, base_url="http://t") as OPSC:
            # OPSC:无任何用户 Cookie 的「运维」客户端 —— 已登录浏览器带运维令牌
            # **不构成**旁路(guard 先认用户会话 → 端点走按账号路径),这是刻意
            # 语义:防止登录用户误点运维链接做出全局操作。旁路必须干净身份。

            print("── 门与豁免 ──")
            r = await A.get("/api/version")
            ok(r.status_code == 200 and r.json().get("version", "").startswith("3.8"),
               "/api/version 免登录(部署健康探针)", r.json().get("version", ""))
            r = await A.get("/api/live-rooms", headers=H)
            ok(r.status_code == 401 and r.json()["error"] == "auth_required",
               "未登录取名录 → 401 auth_required")
            r = await A.get("/api/auth/session")
            ok(r.json() == {"ok": True, "enabled": True, "authed": False,
                            "state": "auth_required"},
               "session:enabled=true / authed=false")

            print("── 登录语义 ──")
            r = await A.post("/api/auth/login", json={"userName": "测试用户A",
                                                      "password": "wrong"})
            ok(r.status_code == 401 and r.json()["error"] == "bad_credentials",
               "密错 → 401 bad_credentials")
            r = await A.post("/api/auth/login", json={"userName": "expireduser",
                                                      "password": "pw123456"})
            ok(r.status_code == 403 and r.json()["error"] == "expired"
               and r.json().get("dueTime"), "过期账号 → 403 expired(带 dueTime)")
            r = await A.post("/api/auth/login", json={"userName": "banneduser",
                                                      "password": "pw123456"})
            ok(r.status_code == 403 and r.json()["error"] == "banned",
               "封停账号 → 403 banned")
            r = await A.post("/api/auth/login", json={"userName": "测试用户A",
                                                      "password": "pw123456"})
            ok(r.status_code == 200 and r.json()["user"]["userName"] == "测试用户A"
               and "jf_user_sid" in r.headers.get("set-cookie", ""),
               "登录成功 → 200 + HttpOnly 会话 Cookie", f"uid={r.json()['user']['id']}")

            print("── CSRF 防线 ──")
            r = await A.get("/api/live-rooms")             # 有 Cookie、无自定义头
            ok(r.status_code == 403 and r.json()["error"] == "bad_origin",
               "带 Cookie 不带 X-JF-Auth → 403 bad_origin")
            r = await A.get("/api/live-rooms", headers=H)
            ok(r.status_code == 200 and r.json()["rooms"] == [],
               "带头放行;新账号名录为空(按账号隔离的起点)")

            print("── 按账号隔离:A 添加 → A 可见 / B 不可见不可读 ──")
            r = await A.post(f"/api/monitor/add?room={ROOM}", headers=H)
            ok(r.status_code == 200 and r.json()["rooms"] == [ROOM],
               "A 添加发现房 → 转正 + 绑定,响应回 A 的名录")
            r = await A.get(f"/api/rooms/{ROOM}/history?limit=5", headers=H)
            ok(r.status_code == 200, "A 读己房 history → 200")
            r = await A.get("/api/rooms", headers=H)
            ok([x["room_id"] for x in r.json()["rooms"]] == [ROOM], "A /api/rooms 只见己房")

            r = await B.post("/api/auth/login", json={"userName": "plainuser",
                                                      "password": "plain#pw"})
            ok(r.status_code == 200, "B(明文口令存量)登录成功")
            r = await B.get("/api/live-rooms", headers=H)
            ok(r.json()["rooms"] == [], "B 名录为空(看不到 A 的房)")
            r = await B.get(f"/api/rooms/{ROOM}/history?limit=5", headers=H)
            ok(r.status_code == 403 and r.json()["error"] == "room_not_bound",
               "B 读 A 的房明细 → 403 room_not_bound")
            r = await B.get(f"/api/rooms/{ROOM}/prediction", headers=H)
            ok(r.status_code == 403, "B 读 A 的房预测 → 403")
            r = await B.get(f"/api/events?roomId={ROOM}")   # SSE:无头(EventSource 语义)
            ok(r.status_code == 403 and r.json()["error"] == "room_not_bound",
               "B 订阅 A 的房 SSE → 403(Cookie 门照过,头豁免仍拦归属)")

            print("── 共享监控 + 引用计数删除 ──")
            r = await B.post(f"/api/monitor/add?room={ROOM}", headers=H)
            ok(r.status_code == 200 and r.json()["rooms"] == [ROOM],
               "B 自添同一房 → 共享同一份全局监控")
            r = await A.post(f"/api/monitor/remove?room={ROOM}", headers=H)
            ok(r.status_code == 200 and r.json()["rooms"] == [],
               "A 删房 → 仅解绑自己")
            ok(ROOM in set(await web.ST.bus.active_rooms()),
               "B 仍绑定 → 全局监控保留(引用计数 > 0)")
            r = await B.get(f"/api/rooms/{ROOM}/history?limit=5", headers=H)
            ok(r.status_code == 200, "B 读数不受 A 删除影响")
            r = await B.post(f"/api/monitor/remove?room={ROOM}", headers=H)
            ok(r.status_code == 200 and r.json()["rooms"] == [],
               "B 也删 → 绑定归零")
            ok(ROOM not in set(await web.ST.bus.active_rooms()),
               "用户转正房绑定归零 → 全局监控退场(回自动发现生命周期)")

            print("── 复查修复回归:满额时按短号切回已绑房不误拒(配额双键) ──")
            from app import web as _w
            _qt_saved = _w.settings.userauth.room_max
            _w.settings.userauth.room_max = 1            # 名额压到 1,专测边缘
            try:
                async with httpx.AsyncClient(transport=t, base_url="http://t") as C:
                    r = await C.post("/api/auth/login",
                                     json={"userName": "sha1user", "password": "pw123456"})
                    ok(r.status_code == 200, "C(SHA1 口令存量)登录成功")
                    r = await C.post(f"/api/monitor/add?room={ROOM_QT_REAL}", headers=H)
                    ok(r.status_code == 200, "C 以真实号绑定,名录 1/1 已满")
                    r = await C.post(f"/api/monitor/add?room={ROOM_QT_ALIAS}", headers=H)
                    ok(r.status_code == 200
                       and r.json().get("error") != "rooms_full"
                       and len(r.json()["rooms"]) == 1,
                       "满额下以短号切回同一房 → 200(修复点:此前误报 rooms_full)")
                    r = await C.post(f"/api/monitor/add?room={ROOM_PIN}", headers=H)
                    ok(r.status_code == 400 and r.json()["error"] == "rooms_full",
                       "加另一间 → rooms_full(名额闸本身仍生效)")
                    r = await C.post(f"/api/monitor/remove?room={ROOM_QT_ALIAS}",
                                     headers=H)
                    ok(r.status_code == 200 and r.json()["rooms"] == [],
                       "清场:短号删除同样双键命中")
            finally:
                _w.settings.userauth.room_max = _qt_saved

            print("── 复查修复回归:运维显式添加=全局钉住 ──")
            OPS = {"X-Monitor-Token": "smoketok"}
            r = await A.post(f"/api/monitor/add?room={ROOM_PIN}", headers=H)
            ok(r.status_code == 200, "A 把发现房转正(带溯源标)")
            r = await OPSC.post(f"/api/monitor/add?room={ROOM_PIN}", headers=OPS)
            ok(r.status_code == 200, "运维旁路显式添加同一房(应清溯源标=钉住)")
            r = await A.post(f"/api/monitor/remove?room={ROOM_PIN}", headers=H)
            ok(r.status_code == 200 and ROOM_PIN not in r.json()["rooms"],
               "A 解绑(引用归零)")
            ok(ROOM_PIN in set(await web.ST.bus.active_rooms()),
               "溯源已被运维清除 → 全局监控保留(钉住生效)")
            r = await OPSC.post(f"/api/monitor/remove?room={ROOM_PIN}", headers=OPS)
            ok(r.status_code == 200, "清场:运维删除钉住房")

            print("── 复查修复回归:运维全局删除级联清各账号绑定 ──")
            for cli in (A, B):
                r = await cli.post(f"/api/monitor/add?room={ROOM_CAS}", headers=H)
                ok(r.status_code == 200, "A/B 各自绑定同一房"[:14] if cli is A else "…B 亦绑定")
            r = await OPSC.post(f"/api/monitor/remove?room={ROOM_CAS}", headers=OPS)
            ok(r.status_code == 200 and ROOM_CAS not in set(await web.ST.bus.active_rooms()),
               "运维全局删除 → 监控退场")
            for cli, name in ((A, "A"), (B, "B")):
                r = await cli.get("/api/live-rooms", headers=H)
                ok(all(x.get("alias") != ROOM_CAS and x.get("roomId") != ROOM_CAS
                       for x in r.json()["rooms"]),
                   f"{name} 名录同步消失(级联解绑,无僵尸条目)")
            r = await A.get(f"/api/rooms/{ROOM_CAS}/history?limit=1", headers=H)
            ok(r.status_code == 403, "级联后读明细 → 403(绑定确已清除)")

            print("── 复查修复回归:SSE 会话吊销即断流(心跳节拍复核) ──")
            r = await A.post(f"/api/monitor/add?room={ROOM_SSE}", headers=H)
            ok(r.status_code == 200, "A 绑定本段专用房(前段已清空 A 名录,自足播种)")
            async def _kick_soon():
                await asyncio.sleep(1.0)
                rr = await B.post("/api/auth/login",
                                  json={"userName": "测试用户A", "password": "pw123456"})
                assert rr.status_code == 200
            # 注意:httpx ASGITransport 对流式响应是**聚合语义** —— __aenter__ 会
            # 驱动服务端生成器直到 return 才交付响应。因此顶号任务必须先于进入
            # stream 并发起跑;服务端 1s 后被顶、下个 20s 心跳复核检出吊销 →
            # yield authRevoked 后 return → 聚合完成,这里一次性读到全部事件行。
            # (真部署走 uvicorn 为真流式,前端 EventSource 会在心跳节拍上即时
            #  收到该事件 —— 服务端行为两者同一,聚合只是本测试运输层的差异。)
            revoked = False
            kicker = asyncio.create_task(_kick_soon())
            try:
                async with asyncio.timeout(40):
                    async with A.stream("GET", f"/api/events?roomId={ROOM_SSE}",
                                        timeout=45.0) as resp:
                        ok(resp.status_code == 200, "A 建立 SSE 流(自己名录内的房)")
                        async for line in resp.aiter_lines():
                            if line.strip() == "event: authRevoked":
                                revoked = True
                                break
            finally:
                kicker.cancel()
                with __import__("contextlib").suppress(BaseException):
                    await kicker
            ok(revoked, "顶号后 ≤ 一个心跳周期收到 authRevoked,流终止")

            print("── 互顶与登出 ──")
            # (同账号在 B 处的二次登录已在上一段 SSE 回归里完成)
            r = await A.get("/api/live-rooms", headers=H)
            ok(r.status_code == 401 and r.json()["error"] == "kicked",
               "A 的旧会话 → 401 kicked(单设备互顶)")
            r = await B.post("/api/auth/logout", headers=H)
            ok(r.status_code == 200, "登出 → 200")
            r = await B.get("/api/live-rooms", headers=H)
            ok(r.status_code == 401, "登出后旧 Cookie → 401")

            print("── 首登预置房(需求固定房 321 语义)──")
            _flr_saved = web.settings.userauth.first_login_room
            web.settings.userauth.first_login_room = f"{SEED_REAL}:{SEED_ALIAS}"
            try:
                async with httpx.AsyncClient(transport=t, base_url="http://t") as Dc:
                    r = await Dc.post("/api/auth/login", json={"userName": "plainuser",
                                                               "password": "plain#pw"})
                    ok(r.status_code == 200, "D 先登录取 uid(幂等冒烟:随后清首登标记)")
                    uid_d = int(r.json()["user"]["id"])
                    async with web.ST.db.pool.acquire() as con:
                        await con.execute(
                            "DELETE FROM user_first_login WHERE user_id=$1", uid_d)
                        await con.execute(
                            "DELETE FROM user_rooms WHERE user_id=$1 AND room_id=$2",
                            uid_d, SEED_REAL)
                    r = await Dc.post("/api/auth/login", json={"userName": "plainuser",
                                                               "password": "plain#pw"})
                    ok(r.status_code == 200, "视同首次登录 → 200")
                    r = await Dc.get("/api/live-rooms", headers=H)
                    _cards = r.json()["rooms"]
                    ok(r.status_code == 200
                       and [x.get("alias") for x in _cards] == [SEED_ALIAS]
                       and [x.get("roomId") for x in _cards] == [SEED_REAL],
                       "首登名录自动含预置房(展示=短号,抓取=真实号)")
                    ok(SEED_REAL in set(await web.ST.bus.active_rooms()),
                       "预置房原不在监控 → 随预置当场全局登记(转正/钉住语义)")
                    r = await Dc.post(f"/api/monitor/remove?room={SEED_ALIAS}", headers=H)
                    ok(r.status_code == 200 and r.json()["rooms"] == [],
                       "用户删除预置房(与自添同权,短号双键命中)")
                    r = await Dc.post("/api/auth/login", json={"userName": "plainuser",
                                                               "password": "plain#pw"})
                    ok(r.status_code == 200, "删除后再次登录 → 200")
                    r = await Dc.get("/api/live-rooms", headers=H)
                    ok(r.status_code == 200 and r.json()["rooms"] == [],
                       "再登录不复种(「首登」只此一次,标记独立于审计修剪)")

                    # —— 名额闸:功能上线前已满额的存量账号,首登只燃标记不塞房 ——
                    _rm_saved = web.settings.userauth.room_max
                    web.settings.userauth.room_max = 1
                    try:
                        async with web.ST.db.pool.acquire() as con:
                            await con.execute(
                                "DELETE FROM user_first_login WHERE user_id=$1", uid_d)
                        await web.ST.db.user_room_bind(uid_d, ROOM, ROOM)  # 直写 PG:模拟存量满额 1/1
                        r = await Dc.post("/api/auth/login", json={"userName": "plainuser",
                                                                   "password": "plain#pw"})
                        ok(r.status_code == 200, "满额存量账号「首登」→ 200")
                        r = await Dc.get("/api/live-rooms", headers=H)
                        ok([x.get("alias") for x in r.json()["rooms"]] == [ROOM],
                           "名录仍只有原有房(不突破 room_max 硬上限,预置未塞入)")
                        async with web.ST.db.pool.acquire() as con:
                            n = await con.fetchval(
                                "SELECT COUNT(*) FROM user_first_login WHERE user_id=$1", uid_d)
                        ok(int(n or 0) == 1, "标记照燃(此后腾出名额再登录也不补种)")
                        r = await Dc.post(f"/api/monitor/remove?room={ROOM}", headers=H)
                        ok(r.status_code == 200, "清场:解绑占位房")
                    finally:
                        web.settings.userauth.room_max = _rm_saved
            finally:
                web.settings.userauth.first_login_room = _flr_saved
            r = await OPSC.post(f"/api/monitor/remove?room={SEED_REAL}", headers=OPS)
            ok(r.status_code == 200, "清场:运维撤下预置房的全局登记")

        # ── 注册系统(4.0.0)关闭态契约:默认 reg_mode=off,行为与 3.9.5 一致 ──
        print("\n【注册系统 · 关闭态契约(默认)】")
        r = await C.get("/api/auth/session")
        ok(r.json().get("reg", {}).get("mode") == "off",
           "session 回包 reg.mode=off(前端据此**不渲染**任何注册入口)")
        r = await C.get("/api/auth/register/challenge")
        ok(r.status_code == 503 and r.json()["error"] == "register_disabled",
           "挑战端点 503 register_disabled")
        r = await C.post("/api/auth/register", json={"userName": "x", "password": "y"})
        ok(r.status_code == 503 and r.json()["error"] == "register_disabled",
           "注册端点 503 register_disabled(未配置即不存在)")
        n_before = 0
        conn0 = pymysql.connect(host="127.0.0.1", port=int(os.environ["STA_USERDB_PORT"]),
                                user=os.environ["STA_USERDB_USER"],
                                password=os.environ["STA_USERDB_PASSWORD"],
                                database=os.environ["STA_USERDB_NAME"], charset="gbk")
        with conn0.cursor() as cur0:
            cur0.execute("SELECT COUNT(*) FROM tb_user")
            n_before = cur0.fetchone()[0]
        conn0.close()
        ok(n_before >= 0, f"关闭态下 tb_user 行数未被触碰({n_before} 行)")

        # 自动建表证据(脚本开头刚删过)
        conn = pymysql.connect(host="127.0.0.1", port=int(os.environ["STA_USERDB_PORT"]),
                               user=os.environ["STA_USERDB_USER"],
                               password=os.environ["STA_USERDB_PASSWORD"],
                               database=os.environ["STA_USERDB_NAME"], charset="gbk")
        with conn.cursor() as cur:
            cur.execute("SHOW TABLES LIKE 'guantai\\_%'")
            tables = sorted(t[0] for t in cur.fetchall())
        conn.close()
        ok(tables == ["guantai_invite_code", "guantai_login_log", "guantai_reg_log",
                      "guantai_sso_ticket", "guantai_user_block",
                      "guantai_user_session"],
           "web 首启自动幂等建表(6 张:登录 2 + 注册 3 + SSO 1;脚本开头已删,现已重建)",
           ",".join(tables))

    print("═" * 62)
    print(f"端到端冒烟全部通过:{PASS} 项 ✓")


if __name__ == "__main__":
    asyncio.run(main())
