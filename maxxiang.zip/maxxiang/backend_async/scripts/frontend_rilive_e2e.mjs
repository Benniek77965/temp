/* 端到端:**跑真 app.js**(不是手搭 DOM)验证名录直播状态三态 —— 真 web(FastAPI)
   + 真 PG + 真 Redis + 真浏览器,逐态改后端观测再整页重载,断言 DOM 真的跟着变。

   ★ 实测记录(2026-08-12,勿再走弯路):
     · 仓库自带的浏览器内模拟层(round-engine.js + mock/mock-api.js)**驱动不动**当前
       启动链 —— index.html 自 2.8.0 起就不再装载它,4.x 启动序要 /api/auth/session、
       /api/vip/* 等端点,mock 对未知 /api/* 一律回 404,页面停在「读取九法数据中」的
       遮罩上;手工补了 session/vip 两个门之后仍停在同一处。复活那套模拟层是另一件
       独立工程,不在 5.0.6 射程内。**别在那条路上再花时间**。
     · 可行的路是起真栈:scripts/e2e_stage_livestatus.py(带双闸,只对 localhost 生效)。
     · 未开播态的圆点本就 hidden,waitForSelector 必须用 state:'attached',
       等 visible 会永远超时(首版就栽在这)。
   用法:
     MAXX_E2E_STAGE=1 python3 scripts/e2e_stage_livestatus.py &      # 起台
     PROBE_BASE=http://127.0.0.1:5199 \
       PROBE_STAGE=scripts/e2e_stage_livestatus.py node scripts/frontend_rilive_e2e.mjs
   没有 PROBE_BASE 时**明确跳过**,绝不假绿。静态形态/样式/无障碍另由
   frontend_rilive_probe.mjs、frontend_rilive_a11y.mjs、frontend_dot_language.mjs 承担。*/
import { chromium } from 'playwright';
import { execFileSync } from 'child_process';

const BASE = process.env.PROBE_BASE;
if (!BASE) {
  console.log('[skip] 未设 PROBE_BASE —— 本钉需要一个真实起着的部署(见文件头)。');
  process.exit(0);
}
const STAGE = process.env.PROBE_STAGE;          // 可选:切换后端观测的辅助脚本
const setLive = v => { if (STAGE) execFileSync('python3', [STAGE, 'live', v]); };

const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1920, height: 1080 } });
const p = await ctx.newPage();
const errs = [];
p.on('pageerror', e => errs.push(String(e)));
/* 只收**页面自身**的错误。头像等外链走 CDN,本机沙箱无对应根证书时会报
   ERR_CERT_AUTHORITY_INVALID —— 那是环境噪声,不是本页的缺陷,滤掉。 */
p.on('console', m => { const t = m.text();
  if (m.type() === 'error' && !/ERR_CERT|ERR_NAME_NOT_RESOLVED|ERR_INTERNET/.test(t))
    errs.push('console: ' + t); });

const load = async () => {
  await p.goto(BASE + '/', { waitUntil: 'load' });
  await p.waitForSelector('.room-item .ri-live', { state: 'attached', timeout: 20000 });  // 未开播态本就 hidden,不能等 visible
  await p.waitForTimeout(1400);                 // 至少走过一拍 railTickPaint
  return p.evaluate(() => {
    const el = document.querySelector('.room-item .ri-live');
    const cs = getComputedStyle(el);
    return { cls: el.className, hidden: el.hidden, display: cs.display,
             aria: el.getAttribute('aria-label'), bg: cs.backgroundColor,
             live: (window.__jf.S.rooms[0] || {}).live };
  });
};

let bad = 0;
const chk = (c, m) => { console.log((c ? '  [\u2713] ' : '  [\u2717] ') + m); if (!c) bad++; };
console.log('== 真 web + 真 PG/Redis + 真 app.js:名录直播状态端到端 ==');

setLive('1');
const a = await load();
console.log('  后端 live=true  →', JSON.stringify(a));
chk(a.live === true, '前端确实收到 live:true(字段过线)');
chk(a.cls.includes('is-live') && !a.hidden, '→ is-live 且可见');
chk(a.bg === 'rgb(15, 111, 92)', '→ 绿点已上色');
chk(a.aria === '直播中', '→ aria-label 已写(实测 ' + JSON.stringify(a.aria) + ')');

setLive('0');
const c2 = await load();
console.log('  后端 live=false →', JSON.stringify(c2));
chk(c2.live === false, '前端确实收到 live:false');
chk(c2.hidden && c2.display === 'none', '→ 整枚隐藏');

setLive('none');
const c3 = await load();
console.log('  后端无观测      →', JSON.stringify(c3));
chk(c3.live === null || c3.live === undefined, '前端收到 live:null(未知)');
chk(c3.cls.includes('is-unknown') && !c3.hidden, '→ 未知灰环');
chk(c3.aria === '直播状态未知', '→ 未知态 aria-label 已写');

chk(errs.length === 0, '零未捕获异常' + (errs.length ? ' —— ' + errs[0] : ''));
console.log(bad ? '\nFAILED ' + bad : '\nALL OK');
await b.close();
process.exit(bad ? 1 : 0);
