/* frontend_predgap_jsdom.js — 窗口缺口注脚 · 前端真 DOM 冒烟(4.9.3)
   用法:`npm i jsdom` 后
       node backend_async/scripts/frontend_predgap_jsdom.js                 # 验源码
       node backend_async/scripts/frontend_predgap_jsdom.js \
            --js dist/assets/app.js --html dist/index.html                  # 验混淆产物

   守什么:#predGap 是 4.9.3 为「一直显示近44局」工单加的**可见**解释 ——
   n < window 时显示「窗口W局 · X局暂无判定」,其余一切形态恒隐藏。
   它必须:
     · 只在 acc.n < acc.window 时可见,文案分毫不差;
     · 满窗(n == window)/无 accuracy/等待数据三态恒 hidden;
     · **绝不**改变 predStats 正文与 title 的既有字节(4.7.5 收束不变式 ——
       与 frontend_replay_jsdom.js 的钉互为犄角:那边证明命中率行没变,
       这边证明注脚在该出现时真的出现);
     · 文案不含「补算」「回测」(溯源角标 4.7.5 已裁,注脚只述事实)。
   走真实启动链路的理由与 frontend_replay_jsdom.js 头注同一段:混淆产物
   renameGlobals,按函数名直调必然 ReferenceError,只有让 boot → loadRoom →
   predChase → refreshPrediction → renderPredict 自己跑完再读 DOM,同一份
   断言才对源码与产物皆成立。 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
const _AJ = process.argv.indexOf('--js');
const _AH = process.argv.indexOf('--html');
const JS_PATH = _AJ > 0 ? path.resolve(process.argv[_AJ + 1]) : ROOT + '/assets/app.js';
const HTML_PATH = _AH > 0 ? path.resolve(process.argv[_AH + 1]) : ROOT + '/index.html';
if (_AJ > 0) {
  const tp = fs.statSync(JS_PATH).mtimeMs;
  const ts = fs.statSync(ROOT + '/assets/app.js').mtimeMs;
  if (tp < ts) {
    console.error(`✗ 产物 ${JS_PATH} 比 assets/app.js 旧 —— 构建未成功或未重跑。`);
    process.exit(3);
  }
}
const html = fs.readFileSync(HTML_PATH, 'utf8');
const js = fs.readFileSync(JS_PATH, 'utf8');
const MODE = _AJ > 0 ? '混淆产物' : '仓库源码';

const STEP = 50001;
const R0 = 1800000000000 - (1800000000000 % STEP);

let pass = 0, fail = 0;
const ok = (name, cond, got) => {
  if (cond) { pass++; console.log('  [✓] ' + name); }
  else { fail++; console.log('  [✗] ' + name + (got !== undefined ? `  ← 实得:${JSON.stringify(got)}` : '')); }
};
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function run(pred){
  const errs = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => errs.push(String((e && e.message) || e)));
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
                                url: 'http://localhost/', virtualConsole: vc });
  const w = dom.window;
  w.matchMedia = q => ({ matches: false, media: q, addEventListener(){},
                         removeEventListener(){}, addListener(){}, removeListener(){} });
  w.scrollTo = () => {};
  w.requestIdleCallback = w.requestIdleCallback || (f => setTimeout(f, 0));
  w.EventSource = function(){ this.close = () => {}; this.addEventListener = () => {}; };

  const spells = [];
  for (let n = 1; n <= 9; n++)
    spells.push({ display_number: n, spell_key: '土', spell_name: '御土术',
                  beast_name: '兽' + n, beast_id: n, multiplier: 10,
                  probability: '11.1%', beast_icon: '' });
  const rounds = [];
  for (let i = 0; i < 30; i++){
    const start = R0 - (29 - i) * STEP;
    rounds.push({ round_id: start, display_number: (i % 9) + 1, spell_key: '土',
                  spell_name: '御土术', beast_name: '兽', multiplier: 10,
                  start_time_ms: start, draw_time_ms: start + 40000 });
  }

  w.fetch = async (input) => {
    const url = typeof input === 'string' ? input : input.url;
    let body = { ok: true };
    if (url.startsWith('/api/auth/session')) body = { ok: true, enabled: false };
    else if (/\/api\/live-rooms\/[^/]+\/profile/.test(url))
      body = { ok: true, profile: { alias: '321', nickname: '房', avatar: '' } };
    else if (url.startsWith('/api/live-rooms'))
      body = { ok: true, rooms: [{ alias: '321', roomId: '321', nickname: '房' }] };
    else if (/\/api\/rooms\/[^/]+\/config/.test(url)) body = { ok: true, spells };
    else if (/\/api\/rooms\/[^/]+\/history\/days/.test(url)) body = { ok: true, days: [] };
    else if (/\/api\/rooms\/[^/]+\/history/.test(url)) body = { ok: true, rounds };
    else if (/\/api\/rooms\/[^/]+\/prediction/.test(url)) body = Object.assign({ ok: true }, pred);
    else if (/\/api\/rooms\/[^/]+\/coverage/.test(url))
      body = { ok: true, complete: true, official_missing: [] };
    return { ok: true, status: 200, headers: { get: () => null },
             json: async () => body };
  };

  const el = w.document.createElement('script');
  el.textContent = js;
  w.document.body.appendChild(el);
  for (let i = 0; i < 80; i++){
    await sleep(50);
    const r = w.document.getElementById('predRound');
    if (r && /№/.test(r.textContent || '')) break;
  }
  await sleep(150);
  const st = w.document.getElementById('predStats');
  const g = w.document.getElementById('predGap');
  return { stats: st.textContent, title: st.title,
           gapHidden: g ? g.hidden : null, gap: g ? g.textContent : null, errs };
}

const base = { target_round_id: String(R0 + STEP), main: [1, 2], guard: [3, 4],
               ens: [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.2] };

(async () => {
  console.log(`\n══ 窗口缺口注脚 · 前端真 DOM 冒烟(4.9.3 · ${MODE})══`);
  console.log(`   js=${path.relative(ROOT, JS_PATH)}  html=${path.relative(ROOT, HTML_PATH)}\n`);

  console.log('[① 窗口未满 —— 注脚必须可见且逐字正确(工单场景:近44局/窗100)]');
  {
    const r = await run(Object.assign({}, base, { record: [],
      accuracy: { window: 100, n: 44, main: 16, cover: 26, replay: 0 } }));
    ok('注脚可见', r.gapHidden === false, r.gapHidden);
    ok('注脚文案 = 窗口100局 · 56局暂无判定',
       r.gap === '窗口100局 · 56局暂无判定', r.gap);
    ok('命中率正文不受影响(4.7.5 收束不变式)',
       r.stats === '近44局 主中16 · 防中10', r.stats);
    ok('title 仍保留既有「窗口 100 局」说明', /窗口 100 局/.test(r.title), r.title);
    ok('注脚不含「补算」「回测」', !/补算|回测/.test(r.gap), r.gap);
    ok('零未捕获异常', r.errs.length === 0, r.errs);
  }

  console.log('\n[② 满窗 —— 注脚恒隐藏,一个像素不多]');
  {
    const r = await run(Object.assign({}, base, { record: [],
      accuracy: { window: 100, n: 100, main: 34, cover: 66, replay: 0 } }));
    ok('注脚隐藏', r.gapHidden === true, r.gapHidden);
    ok('正文与 4.4.x 逐字节相同', r.stats === '近100局 主中34 · 防中32', r.stats);
    ok('零未捕获异常', r.errs.length === 0, r.errs);
  }

  console.log('\n[③ 后端未回窗口字段(旧后端)—— 缺 window 不猜,恒隐藏]');
  {
    const r = await run(Object.assign({}, base, { record: [],
      accuracy: { n: 60, main: 20, cover: 40, replay: 0 } }));
    ok('注脚隐藏(窗口未知)', r.gapHidden === true, r.gapHidden);
    ok('正文照常', r.stats === '近60局 主中20 · 防中20', r.stats);
    ok('零未捕获异常', r.errs.length === 0, r.errs);
  }

  console.log('\n[④ 无 accuracy —— 空态注脚恒隐藏]');
  {
    const r = await run(Object.assign({}, base, { record: [], accuracy: null }));
    ok('注脚隐藏', r.gapHidden === true, r.gapHidden);
    ok('命中率整行空白(既有空态)', r.stats === '', r.stats);
    ok('零未捕获异常', r.errs.length === 0, r.errs);
  }

  console.log('\n──────────────────────────────────────────────────────────');
  console.log(`窗口缺口注脚前端冒烟(${MODE}):${pass} 通过 / ${fail} 失败`);
  if (fail === 0)
    console.log('✓ 注脚仅在 n<window 时出现且逐字正确,命中率行本体分毫未动');
  process.exit(fail ? 1 : 0);
})();
