"""
sim_hist_mode_proto.py — 「后台房 GameHistory 轮询模式」方案原型仿真
================================================================================
复用 sim_history_gap 的真机仿真件(SimUpstream 官方模型 / FakeDB / fakeredis /
虚拟时钟),但抓取侧改为方案设想:后台房**不打 MainPage、不打 RoundAward**,
只按周期 T 调 GameHistory(走真实 Worker._backfill_history,一行未改)。

验证四件事:
  P0  稳态调用量:T 分钟轮询 vs 现行 2 req/局 的精确对比
  P1  数据完整性:页窗 30 局(1500s)内轮询,零洞
  P2  容错边界:连续 K 次轮询失败仍不丢数据的 T 上限(重试走 1.5x 退避)
  P3  越窗致损:轮询间隔 > 页窗时,数据不可逆丢失(反面证明 T 的硬上限)
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import fakeredis.aioredis  # noqa: E402
from fakeredis.model import _expiring_members_set as _ems  # noqa: E402
_ems.ExpiringMembersSet._expire_members = lambda self: None  # noqa: E731
from fakeredis.model import _client_info as _ci  # noqa: E402
_ci.ClientInfo.items = lambda self: ()           # noqa: E731
_ci.ClientInfo.as_bytes = lambda self: b""       # noqa: E731

from app import redis_bus as rb  # noqa: E402
from app import worker as wk  # noqa: E402
from app.constants import ROUND_STEP  # noqa: E402
from scripts.sim_history_gap import (FakeDB, SimUpstream, VClock, T0,  # noqa: E402
                                     ROOM, AWARD_READY_OFFSET)

STEP = ROUND_STEP


def build_world():
    clock = VClock(T0 + 10 * STEP + 2_000)
    rb.now_ms = clock
    wk.now_ms = clock
    from app.settings import Settings
    s = Settings()
    s.prediction = {"enabled": False}
    s.scheduler.award_jitter_ms = 0
    s.scheduler.mainpage_jitter_ms = 0
    w = wk.Worker(s)
    w.bus.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    up = SimUpstream(clock)
    db = FakeDB()
    db._clock = clock
    w.up, w.db = up, db
    return w, up, db, clock


async def run_hist_mode(poll_s: int, horizon_rounds: int,
                        fail_calls: set[int] | None = None,
                        retry_s: float = 90.0, label: str = "") -> dict:
    """后台房 history-mode:每 poll_s 秒调一次真实 _backfill_history;
    失败按 retry_s 重试(演示退避语义;真实实现可用指数退避)。"""
    w, up, db, clock = build_world()
    await w.bus.add_room(ROOM)
    up.hist_fail_calls = fail_calls or set()
    start_rid = up.cur_round()
    end_ms = start_rid + horizon_rounds * STEP + 45_000

    next_poll = clock.t + 1_000
    lost_window = []          # 越窗丢失审计:两次“成功”轮询间隔 > 页窗
    last_ok_head = None
    while clock.t < end_ms:
        clock.t = max(clock.t + 1, int(next_poll))
        ok = await w._backfill_history(ROOM)     # ← 真实 worker 代码,一行未改
        if ok:
            newest = up.cur_round()
            while newest >= T0 and not up._ready(newest):
                newest -= STEP
            if last_ok_head is not None and newest - last_ok_head > 30 * STEP:
                lost_window.append((last_ok_head, newest))
            last_ok_head = newest
            next_poll = clock.t + poll_s * 1000
        else:
            next_poll = clock.t + retry_s * 1000

    # 体检:义务窗 = 首次成功轮询页窗起点 → 最后已就绪局
    last_done = up.cur_round()
    while not up._ready(last_done):
        last_done -= STEP
    oldest_have = min(db.rounds) if db.rounds else None
    expected = ({r for r in range(oldest_have, last_done + 1, STEP)}
                if oldest_have else set())
    holes = sorted(expected - set(db.rounds))
    return {"label": label or f"T={poll_s}s", "poll_s": poll_s,
            "rounds": horizon_rounds,
            "hist": up.calls["hist"], "aw": up.calls["aw"], "mp": up.calls["mp"],
            "holes": len(holes), "lost_windows": len(lost_window)}


async def main():
    horizon = 240   # 240 局 = 200 分钟,足以覆盖多个轮询周期
    rows = []
    # P0/P1:三档轮询周期,零故障
    for t in (300, 600, 1200):
        rows.append(await run_hist_mode(t, horizon))
    # P2:T=600s,注入连续 2 次轮询失败(第 8/9 次调用),90s 重试
    rows.append(await run_hist_mode(600, horizon, fail_calls={8, 9},
                                    label="T=600s+连败2次(90s重试)"))
    # P3:反面 —— T=1800s(36 局)> 页窗 30 局,必然越窗丢数据
    rows.append(await run_hist_mode(1800, horizon, label="T=1800s(越窗反例)"))

    base_req = horizon * 2   # 现行架构同窗口调用量(S0 实证:恰 2 req/局)
    print(f"\n{'模式':<26}{'Hist':>6}{'Award':>7}{'MP':>5}{'总请求':>7}"
          f"{'vs现行':>10}{'洞':>4}{'越窗':>5}")
    print("─" * 78)
    print(f"{'现行(mp+aw, S0 实证)':<26}{1:>6}{horizon+1:>7}{horizon+1:>5}"
          f"{base_req + 3:>7}{'1.0x':>9}{0:>4}{0:>5}")
    for r in rows:
        total = r["hist"] + r["aw"] + r["mp"]
        ratio = (base_req + 3) / max(total, 1)
        print(f"{r['label']:<26}{r['hist']:>6}{r['aw']:>7}{r['mp']:>5}"
              f"{total:>7}{f'1/{ratio:.1f}':>9}{r['holes']:>4}"
              f"{r['lost_windows']:>5}")


if __name__ == "__main__":
    asyncio.run(main())
