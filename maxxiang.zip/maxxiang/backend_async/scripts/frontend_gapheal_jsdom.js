/* frontend_gapheal_jsdom.js — 「出怪序列缺局自愈」前端真 DOM 回归钉(5.0.5)
   用法:`npm i jsdom` 后
       node backend_async/scripts/frontend_gapheal_jsdom.js            # 全跑(约 4 分钟)
       node backend_async/scripts/frontend_gapheal_jsdom.js away basic # 只跑指定用例
       node backend_async/scripts/frontend_gapheal_jsdom.js --list
       node backend_async/scripts/frontend_gapheal_jsdom.js \
            --js dist/assets/app.js --html dist/index.html             # 验混淆产物

   ── 为什么必须有这一份 ────────────────────────────────────────────────────
   5.0.4/5.0.5 修的是「序列缺局占位不自愈」。那轮开发暴露的**方法论问题**比任何
   单个 bug 都值钱:只跑修后版本通过是**不够的** —— 开发中至少三次出现「声称修了
   X、实则没修 / 修的价值被高估」,每一次都是靠「同一场景跑修前+修后两版、比对
   行为差异」才揪出来的。本文件把那批场景钉住,让任何一条退回去都当场红。

   每个用例都标注了**它守的是哪一条、退回去会怎样**(EXPECT 里的 why),那不是
   注释而是取证记录:那些数字全部是 jsdom 实机跑出来的,不是推出来的。

   ── 为什么走真实启动链路而不是直调函数 ──────────────────────────────────
   与 frontend_replay_jsdom.js / frontend_predgap_jsdom.js 同一理由:混淆产物
   renameGlobals,按函数名直调必然 ReferenceError。让 boot → dataBoot → loadRoom
   → startRealtime 自己跑完,再从 **DOM 珠数 + 网络流水** 两个可观测面断言,
   同一份用例对源码与产物皆成立(实测产物全绿)。

   ── 时间口径 ──────────────────────────────────────────────────────────────
   一局 50001ms。前端两个节流常量决定用例的最小节拍:
     GAP_RESYNC_COOLDOWN_MS = 8s  (断层补齐)
     COVERAGE_COOLDOWN_MS   = 15s (完整性自愈,自适应翻倍)
   故只验补齐的用例用 9s/局,需要 coverage 参与的用 17s/局 —— 这是本钉总时长的
   下界,别为了跑快去调小它,那等于把被测的节流逻辑一起改掉。
*/
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
const _AJ = process.argv.indexOf('--js');
const _AH = process.argv.indexOf('--html');
const JS_PATH = _AJ > 0 ? path.resolve(process.argv[_AJ + 1]) : ROOT + '/assets/app.js';
const HTML_PATH = _AH > 0 ? path.resolve(process.argv[_AH + 1]) : ROOT + '/index.html';
if (_AJ > 0) {
  const tp = fs.statSync(JS_PATH).mtimeMs, ts = fs.statSync(ROOT + '/assets/app.js').mtimeMs;
  if (tp < ts) { console.error(`✗ 产物 ${JS_PATH} 比 assets/app.js 旧 —— 构建未成功或未重跑。`); process.exit(3); }
}
const HTML = fs.readFileSync(HTML_PATH, 'utf8');
const APPJS = fs.readFileSync(JS_PATH, 'utf8');
const MODE = _AJ > 0 ? '混淆产物' : '仓库源码';

const STEP = 50001;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const mkRound = (s, n) => ({
  round_id: String(s), display_number: n, spell_key: '土', spell_name: '御土术',
  beast_name: '兽' + n, beast_id: n, multiplier: 10,
  start_time_ms: s, draw_time_ms: s + 40000,
});

let pass = 0, fail = 0;
const A = (name, cond, got) => {
  if (cond) { pass++; console.log('  [✓] ' + name); }
  else { fail++; console.log('  [✗] ' + name + (got !== undefined ? `  ← 实得:${JSON.stringify(got)}` : '')); }
};

/* ═══════════ 通用世界:一个可变的后端 + 可控 SSE + 真实启动链路 ═══════════ */
async function world(opt) {
  const {
    tier = 'vip', total = 60, holes = [], covComplete = false, offMissHoles = [],
    offMissAuto = false, rooms = ['321'], alias = '321',
  } = opt;
  const errs = [], net = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => errs.push(String((e && e.message) || e)));

  const t = Date.now();
  const W = { latest: t - (t % STEP) - STEP, shift: 0, db: {}, holeTs: [], slowGapMs: 0 };
  for (const r of rooms) {
    const m = new Map();
    for (let i = 0; i < total; i++) {
      const s = W.latest - i * STEP;
      if (r === alias && holes.includes(i)) continue;
      m.set(s, mkRound(s, (i % 9) + 1));
    }
    W.db[r] = m;
  }
  W.holeTs = holes.map(i => W.latest - i * STEP);

  const dom = new JSDOM(HTML, { runScripts: 'dangerously', pretendToBeVisual: true,
                                url: 'http://localhost/', virtualConsole: vc });
  const w = dom.window;
  w.matchMedia = q => ({ matches: false, media: q, addEventListener(){}, removeEventListener(){},
                         addListener(){}, removeListener(){} });
  w.scrollTo = () => {};
  w.requestIdleCallback = w.requestIdleCallback || (f => setTimeout(() => f({ timeRemaining: () => 5 }), 0));
  w.cancelIdleCallback = w.cancelIdleCallback || (id => clearTimeout(id));
  let hidden = false;
  Object.defineProperty(w.document, 'hidden', { get: () => hidden, configurable: true });
  const realNow = Date.now;
  w.Date.now = () => realNow() + W.shift;

  const buses = [];
  w.EventSource = function () {
    const s = this; s.readyState = 1; s.listeners = {};
    s.addEventListener = (tp, f) => { (s.listeners[tp] = s.listeners[tp] || []).push(f); };
    s.close = () => { s.readyState = 2; const i = buses.indexOf(s); if (i >= 0) buses.splice(i, 1); };
    buses.push(s);
    setTimeout(() => s.emit('connected', { serverNowMs: w.Date.now(), timer: { roundStartTimeMs: W.latest } }), 20);
  };
  w.EventSource.prototype.emit = function (tp, p) {
    for (const f of (this.listeners[tp] || [])) { try { f({ data: JSON.stringify(p), type: tp }); } catch (e) { errs.push(String(e)); } }
  };

  const spells = [];
  for (let n = 1; n <= 9; n++) spells.push({ display_number: n, spell_key: '土', spell_name: '御土术',
    beast_name: '兽' + n, beast_id: n, multiplier: 10, probability: '11.1%', beast_icon: '' });

  const T0 = Date.now();
  w.fetch = async (input) => {
    const url = typeof input === 'string' ? input : input.url;
    const u = new URL(url, 'http://localhost');
    const p = u.pathname;
    let body = { ok: true };
    if (p.startsWith('/api/auth/session'))
      body = { ok: true, enabled: false, authed: false,
               jf: { enabled: true, tier, plans: [], matrix: [], basicHistoryLimit: 30,
                     basicPredWindow: 100, basicOnlineH: tier === 'basic' ? 24 : 0 } };
    else if (/^\/api\/live-rooms\/[^/]+\/profile$/.test(p)) {
      const a = p.split('/')[3];
      body = { ok: true, profile: { alias: a, nickname: '房' + a, avatar: '', exists: true } };
    }
    else if (p === '/api/live-rooms')
      body = { ok: true, rooms: rooms.map(r => ({ alias: r, roomId: r, nickname: '房' + r,
                                                  roundStartTimeMs: W.latest, serverOffsetMs: 0 })) };
    else if (/\/config$/.test(p)) body = { ok: true, spells };
    else if (/\/history\/days$/.test(p)) body = { ok: true, days: [] };
    else if (/\/history$/.test(p)) {
      const room = p.split('/')[3];
      const since = Number(u.searchParams.get('since') || 0);
      const until = Number(u.searchParams.get('until') || 0);
      const reqLim = Number(u.searchParams.get('limit') || 80);   // ★ 分类必须看**请求原值**
      let lim = reqLim;
      const passive = u.searchParams.get('passive') === '1';
      // 后端 basic 硬闸:禁 until + 钳 limit(web.py room_history)
      if (tier === 'basic') {
        if (until > 0) { net.push({ kind: 'deny', room, note: '403 vip_required(until)' });
                         return { ok: false, status: 403, headers: { get: () => null },
                                  json: async () => ({ ok: false, error: 'vip_required' }) }; }
        lim = Math.min(lim, 30);
      }
      let all = [...(W.db[room] || new Map()).values()].filter(r => r.start_time_ms >= since);
      if (until > 0) all = all.filter(r => r.start_time_ms < until);
      all = all.sort((a, b) => b.start_time_ms - a.start_time_ms).slice(0, lim);   // ★ 与 db.history 同款 DESC+LIMIT
      /* 按**请求原值**分类(不能看钳位后的值:basic 档 pollNew 的 200 会被钳成 30,
         与 resyncGap 的小 limit 混作一谈)。四条取数路的请求原值互不相同:
           1800 = loadRoom 首装 / 按日回看   200 = pollNew 增量
             80 = checkCoverage 定向补齐      其余 = resyncGap(min(1800, span+8))
         resyncGap 的 span+8 理论上可能撞上 80/200(span=72/192),本钉的用例里
         实际取值为 308 / 10~20,不会撞;若将来新增用例撞上,改这里而不是改被测码。 */
      const kind = passive ? 'passive'
                 : reqLim === 1800 ? 'full'
                 : reqLim === 200 ? 'poll'
                 : reqLim === 80 ? 'covfill'
                 : 'gapfill';
      const isGap = kind === 'gapfill' || kind === 'covfill';
      net.push({ kind, room, since, until, limit: reqLim, eff: lim, n: all.length, t: Date.now() - T0 });
      if (isGap && W.slowGapMs) { const d = W.slowGapMs; W.slowGapMs = 0; await sleep(d); }
      body = { ok: true, rounds: all };
    }
    else if (/\/coverage$/.test(p)) {
      net.push({ kind: 'coverage', t: Date.now() - T0 });
      if (offMissAuto) {
        /* 自洽口径:与 web.py room_coverage 同构 —— 窗口 = latest 往回 window 个格点,
           库里没有的一律登记为「官方本身缺失」,complete = 每个格点要么在库要么已登记。
           ★ 别写成「complete:true + 空 official_missing」那种自相矛盾的应答:前端据此
             什么都记不住,反而会让本用例假红(本钉初版就栽在这)。 */
        const win = Number(u.searchParams.get('window') || 30);
        const grid = []; for (let i = 0; i < win; i++) grid.push(W.latest - i * STEP);
        const off = grid.filter(g => !(W.db[alias] || new Map()).has(g));
        body = { ok: true, latest_start: W.latest, window: win,
                 local: grid.filter(g => W.db[alias].has(g)),
                 official_missing: off.map(String), complete: true };
      } else {
        body = { ok: true, complete: covComplete,
                 official_missing: offMissHoles.map(i => String(W.holeTs[holes.indexOf(i)])) };
      }
    }
    else if (/\/prediction$/.test(p))
      body = { ok: true, target_round_id: String(W.latest + STEP), main: [1, 2], guard: [3, 4],
               ens: [.1,.1,.1,.1,.1,.1,.1,.1,.2], record: [],
               accuracy: { window: 100, n: 100, main: 30, cover: 40, replay: 0 } };
    else if (p.startsWith('/api/accounts')) body = { ok: true, accounts: [] };
    return { ok: true, status: 200, headers: { get: () => null }, json: async () => body };
  };

  const el = w.document.createElement('script');
  el.textContent = APPJS;
  w.document.body.appendChild(el);
  for (let i = 0; i < 140; i++) {
    await sleep(50);
    const g = w.document.getElementById('roadGrid');
    if (g && g.querySelectorAll('.bead[data-n]').length > 3) break;
  }
  await sleep(1200);

  const grid = () => w.document.getElementById('roadGrid');
  const api = {
    w, dom, net, errs, W, buses,
    real: () => grid().querySelectorAll('.bead[data-n]').length,
    voids: () => grid().querySelectorAll('.bead.is-void').length,
    count: kind => net.filter(x => x.kind === kind).length,
    /* 推进一局(带 SSE 推送);skip=true 则**跳过一局**制造断层 */
    async round({ skip = false, gapMs = 0, n = 1 } = {}) {
      if (gapMs) W.slowGapMs = gapMs;
      if (skip) { W.shift += STEP; W.latest += STEP; W.db[alias].delete(W.latest); }
      W.shift += STEP; W.latest += STEP;
      for (const r of rooms) W.db[r].set(W.latest, mkRound(W.latest, n));
      for (const b of buses.slice())
        b.emit('room-updated', { serverNowMs: w.Date.now(), timer: { roundStartTimeMs: W.latest },
                                 round: W.db[alias].get(W.latest) });
      await sleep(1500);
    },
    backfill(i) { const s = W.holeTs[holes.indexOf(i)]; W.db[alias].set(s, mkRound(s, 7)); },
    backfillAt(ms) { const s = ms; W.db[alias].set(s, mkRound(s, 7)); },
    close() { dom.window.close(); },
  };
  return api;
}

/* ═══════════ 用例 ═══════════ */
const CASES = {};

/* ① pollNew 自己造洞 —— 5.0.4 的主病灶。
   守什么:pollNew 按 since=最新+1&limit=200 拉,而 db.history 是 DESC+LIMIT ——
   离开超过 200 局时这一枪只回**最新 200 局**,中间那段直接成洞,且洞落在
   COVERAGE_WINDOW(30) 之外,checkCoverage 连查都不会查。
   退回去会怎样:实测挂后台 300 局回前台 → 当场 100 颗占位珠,再过 5 局仍是 100,
   coverage 零调用;挂一夜(≈576 局)≈376 颗,占整条 24h 序列的 22%。 */
CASES.away = { label: '① 长时间离开(300 局)回前台 · 断层必须被补齐', ms: 30000, run: async () => {
  const h = await world({ tier: 'vip', total: 400 });
  A('离开前无洞', h.voids() === 0, { voids: h.voids() });
  h.W.__hidden = true;
  Object.defineProperty(h.w.document, 'hidden', { get: () => true, configurable: true });
  h.w.document.dispatchEvent(new h.w.Event('visibilitychange'));
  await sleep(200);
  h.W.shift += 300 * STEP;
  for (let i = 1; i <= 300; i++) { h.W.latest += STEP; for (const k of Object.keys(h.W.db)) h.W.db[k].set(h.W.latest, mkRound(h.W.latest, (i % 9) + 1)); }
  Object.defineProperty(h.w.document, 'hidden', { get: () => false, configurable: true });
  h.w.document.dispatchEvent(new h.w.Event('visibilitychange'));
  await sleep(5000);
  A('回前台后占位珠归零(断层被 resyncGap 一枪补齐)', h.voids() === 0, { voids: h.voids(), real: h.real() });
  const gf = h.net.filter(x => x.kind === 'gapfill');
  A('补齐只发一枪,且 limit 按 span 给足(>300)', gf.length === 1 && gf[0].limit > 300, gf.map(x => x.limit));
  A('零未捕获异常', h.errs.length === 0, h.errs.slice(0, 2));
  h.close();
}};

/* ② basic 档必须能自愈(5.0.4 之前一行 `if (isBasic()) return` 全关)。
   /coverage 需 VIP(403),但 /history 本身 basic 可读:since 只抬下界 ⇒ 结果恒
   ⊆「最新 N 局」,与直接 /history?limit=N 同一批数据,**不构成绕过**。 */
CASES.basic = { label: '② basic 档洞在硬闸窗内 · 后端补齐后必须自愈', ms: 45000, run: async () => {
  const h = await world({ tier: 'basic', total: 40, holes: [3] });
  A('首屏有 1 颗占位珠', h.voids() === 1, { voids: h.voids() });
  h.backfill(3);
  await h.round();
  await sleep(1500);
  A('下一局落地即自愈(不必刷新页面)', h.voids() === 0, { voids: h.voids() });
  A('basic 全程零 coverage 调用(该端点对 basic 恒 403)', h.count('coverage') === 0);
  const gf = h.net.filter(x => x.kind === 'gapfill');
  A('补齐 limit 按格点精确给足(不是固定值)', gf.length >= 1 && gf[0].limit < 30, gf.map(x => x.limit));
  A('零未捕获异常', h.errs.length === 0, h.errs.slice(0, 2));
  h.close();
}};

/* ③ 止损:后端永远拿不到时,必须恰好 GAP_RESYNC_TRY_MAX(=4)枪后停死。
   退回去会怎样:初版按 span 计数 + markGap 合并不重置,会出现「4 枪一轮、
   轮轮不停」的空转环(预算耗尽 → gapSpan 置空 → 下一局重新登记 → 计数归零)。 */
CASES.giveup = { label: '③ 洞永不可得 · 必须恰好 4 枪后止损', ms: 80000, run: async () => {
  const h = await world({ tier: 'basic', total: 40, holes: [3] });
  for (let k = 0; k < 7; k++) await h.round({ n: k + 1 }), await sleep(7600);
  const gf = h.net.filter(x => x.kind === 'gapfill');
  A('补齐枪数 === GAP_RESYNC_TRY_MAX(4),第 5 局起彻底停止', gf.length === 4, gf.length);
  A('占位珠如实保留(不可得就不假装补上)', h.voids() === 1, { voids: h.voids() });
  A('零未捕获异常', h.errs.length === 0, h.errs.slice(0, 2));
  h.close();
}};

/* ④ coverage 判「官方缺失」后必须立刻收手 —— 守 miss 口径要刨掉 S.offMissing。
   退回去会怎样:用 missingSlots 全量数时,coverage 第 0 局就已定案,resyncGap
   仍要白烧满 4 枪(实测 4 枪 vs 1 枪)。 */
CASES.official = { label: '④ coverage 判官方缺失 · resyncGap 必须立刻收手', ms: 90000, run: async () => {
  const h = await world({ tier: 'vip', total: 60, offMissAuto: true });
  await h.round({ skip: true, n: 9 });      // 制造断层;coverage 会如实报成「官方缺失」
  for (let k = 0; k < 3; k++) await h.round({ n: k + 1 }), await sleep(16000);
  const gf = h.net.filter(x => x.kind === 'gapfill');
  A('resyncGap 枪 ≤1(官方缺失一经定案即不再烧预算)', gf.length <= 1, gf.map(x => x.limit));
  A('coverage 只查一次(offMissing 记住后 localGridGaps 即跳过)', h.count('coverage') === 1, h.count('coverage'));
  A('占位珠如实保留', h.voids() === 1, { voids: h.voids() });
  A('零未捕获异常', h.errs.length === 0, h.errs.slice(0, 2));
  h.close();
}};

/* ⑤ 决定性对拍用例:断层 A 的 span **仍活着**时产生断层 B。
   守什么:预算必须**按格点各自计**。按 span 计时 markGap 的合并分支不重置计数,
   B 并进一段只剩 1 次预算的活 span 会当场被判死、并连同写进 gapDead ⇒ 后端随后
   补上 B 也再没人去取。实测:按 span 末态 2 颗占位珠,按格点 1 颗。 */
CASES.twogaps = { label: '⑤ 老断层活着时新断层并入 · 新断层必须有独立预算', ms: 110000, run: async () => {
  const h = await world({ tier: 'vip', total: 60 });
  const b0 = h.W.latest;
  await h.round({ skip: true, n: 9 });                 // 断层 A:后端永远没有
  await sleep(7600); await h.round({ n: 2 }); await sleep(7600);
  const b1 = h.W.latest;
  await h.round({ skip: true, n: 3 });                 // 断层 B(此时 A 的 span 仍活着)
  const missedB = b1 + STEP;
  /* B 在 **A 判死之后、B 自己的预算用尽之前** 才被后端补上 —— 这个窗口就是本用例的
     全部要害。周期 ≈9.1s(round 内含 1.5s + 7.6s sleep):A 在 B 出现后约 1 个周期
     判死,B 的第 4 枪在约 3 个周期。12s 稳落在窗口内;调这个数前先看清楚这两条边界。 */
  setTimeout(() => h.backfillAt(missedB), 12000);
  for (let k = 0; k < 5; k++) await h.round({ n: k + 4 }), await sleep(7600);
  A('末态只剩 1 颗占位珠(A 不可得;B 用自己的预算补回)', h.voids() === 1,
    { voids: h.voids(), real: h.real() });
  A('零未捕获异常', h.errs.length === 0, h.errs.slice(0, 2));
  h.close();
}};

/* ⑥ 跨房补拉(RoundEngine.resultFor → jfFetchCross)。
   守什么:同一条 DESC+LIMIT 坑的**同族**。原写死 limit=3 只取回「≥since 的最新
   3 局」,目标局早于最新 3 局就永远拿不回来 —— sim-engine 的结算主路拿不到即
   挂单永不结算,而 handle() 每次都会重催 ⇒ 持续空拉(JFX.busy 只挡并发)。
   实测:修前 12 次调用 = 12 次空拉且恒 null;修后 1 次即命中。
   ★ 混淆产物上跑通同时证明 RoundEngine 契约名没被 renameGlobals 吃掉。 */
CASES.cross = { label: '⑥ 跨房补拉某旧局 · 必须一枪命中且不空转', ms: 20000, run: async () => {
  const h = await world({ tier: 'vip', total: 200, rooms: ['321', '654'] });
  const target = h.W.latest - 40 * STEP;
  let got = null;
  for (let k = 0; k < 8; k++) { got = h.w.RoundEngine.resultFor('654', target); await sleep(350); }
  const ps = h.net.filter(x => x.kind === 'passive');
  A('resultFor 命中(不再恒 null)', !!got, got);
  A('8 次调用只发 1 枪(不空转)', ps.length === 1, ps.length);
  A('VIP 走 until 精确取那一局(只回 1 行)', ps.length === 1 && ps[0].until > 0 && ps[0].n === 1, ps[0]);
  A('零未捕获异常', h.errs.length === 0, h.errs.slice(0, 2));
  h.close();
}};

/* ⑦ 跨房补拉失败必须退避 —— 403/500/超时都走 .catch,而 handle() 每次都会重催,
   不压节奏就是按 RTT 持续重打。实测:后端恒 403 时修前 12 枪、修后 1 枪。 */
CASES.crosserr = { label: '⑦ 跨房补拉后端恒 403 · 必须退避而非连打', ms: 20000, run: async () => {
  const h = await world({ tier: 'vip', total: 200, rooms: ['321', '654'] });
  const of = h.w.fetch;
  h.w.fetch = async (input) => {
    const url = typeof input === 'string' ? input : input.url;
    if (/passive=1/.test(url)) { h.net.push({ kind: 'passive', t: 0 });
      return { ok: false, status: 403, headers: { get: () => null },
               json: async () => ({ ok: false, error: 'vip_required' }) }; }
    return of(input);
  };
  h.net.length = 0;
  for (let k = 0; k < 10; k++) { h.w.RoundEngine.resultFor('654', h.W.latest - 40 * STEP); await sleep(350); }
  A('10 次调用只发 1 枪(失败也压节奏)', h.net.filter(x => x.kind === 'passive').length === 1,
    h.net.filter(x => x.kind === 'passive').length);
  h.close();
}};

/* ⑧ 换房竞态:陈旧一枪落地时不得动新房的节流位。
   守什么:resyncGap 的 finally 原来无条件给 S.gapAt 打戳 —— 换房后回来的陈旧
   一枪会盖掉 applyRoomData 刚清零的节流位,新房紧接着产生的断层被节流拦掉。
   实测(basic 无 coverage 兜底):修前 13s 窗口内**一枪都发不出**;修后当场发出。
   反向的另一半同样重要:gapBusy 必须**无条件释放**(它是自持互斥位,漏放会把
   整个会话的补齐锁死)—— 别把这两半写成同一种守卫。 */
CASES.race = { label: '⑧ 补齐在飞时换房 · 新房断层必须照常补齐', ms: 40000, run: async () => {
  const h = await world({ tier: 'basic', total: 60, holes: [3], rooms: ['321', '654'] });
  await h.round({ gapMs: 3000, n: 5 });                       // 这一枪被拖慢 3s
  await sleep(600);
  const btnB = [...h.w.document.querySelectorAll('.room-item')].find(x => x.dataset.alias === '654');
  A('名录里能点到另一个房', !!btnB);
  if (btnB) btnB.dispatchEvent(new h.w.MouseEvent('click', { bubbles: true }));
  await sleep(3600);                                          // 等陈旧那枪落地
  h.net.length = 0;
  const b0 = h.W.latest;
  h.W.shift += 2 * STEP; h.W.latest += 2 * STEP;              // 房B 跳一局 = 新断层
  h.W.db['654'].delete(b0 + STEP);
  h.W.db['654'].set(h.W.latest, mkRound(h.W.latest, 8));
  for (const b of h.buses.slice())
    b.emit('room-updated', { serverNowMs: h.w.Date.now(), timer: { roundStartTimeMs: h.W.latest },
                             round: h.W.db['654'].get(h.W.latest) });
  await sleep(6000);
  A('新房的断层补齐枪当场发出(未被陈旧 gapAt 拦住)',
    h.net.filter(x => x.kind === 'gapfill' && x.room === '654').length >= 1,
    h.net.filter(x => x.kind === 'gapfill'));
  A('零未捕获异常', h.errs.length === 0, h.errs.slice(0, 2));
  h.close();
}};

/* ⑨ 健康路径零回归 —— 稳态下自愈机制必须**一枪都不发**。
   这条是前面八条的对照组:任何「为了补洞而变勤快」的改动,先在这里红。 */
CASES.healthy = { label: '⑨ 全程无洞 · 自愈必须零额外请求', ms: 45000, run: async () => {
  for (const tier of ['vip', 'basic']) {
    const h = await world({ tier, total: tier === 'basic' ? 40 : 60 });
    h.net.length = 0;
    for (let k = 0; k < 3; k++) await h.round({ n: k + 1 }), await sleep(7600);
    A(`${tier} 档:零断层补齐请求`, h.count('gapfill') === 0, h.net.filter(x => x.kind === 'gapfill'));
    A(`${tier} 档:零 coverage 请求(本地完整则不查)`, h.count('coverage') === 0, h.count('coverage'));
    A(`${tier} 档:占位珠恒为 0`, h.voids() === 0, { voids: h.voids() });
    h.close();
  }
}};

/* ═══════════ 跑 ═══════════ */
(async () => {
  const args = process.argv.slice(2).filter(a => !a.startsWith('--')
    && !['--js', '--html'].includes(process.argv[process.argv.indexOf(a) - 1]));
  if (process.argv.includes('--list')) {
    console.log('可选用例:'); for (const k of Object.keys(CASES))
      console.log(`  ${k.padEnd(10)} ${CASES[k].label}  (~${Math.round(CASES[k].ms / 1000)}s)`);
    return;
  }
  const pick = args.length ? args.filter(a => CASES[a]) : Object.keys(CASES);
  if (!pick.length) { console.error('✗ 无匹配用例,--list 看清单'); process.exit(1); }
  console.log(`\n══ 出怪序列缺局自愈 · 前端真 DOM 回归钉(5.0.5 · ${MODE})══`);
  console.log(`   js=${path.relative(ROOT, JS_PATH)}  html=${path.relative(ROOT, HTML_PATH)}`);
  console.log(`   用例:${pick.join(', ')}\n`);
  for (const k of pick) {
    console.log(`[${CASES[k].label}]`);
    try { await CASES[k].run(); }
    catch (e) { fail++; console.log('  [✗] 用例本身抛错:', (e && e.stack) || e); }
    console.log('');
  }
  console.log('──────────────────────────────────────────────────────────');
  console.log(`缺局自愈回归钉(${MODE}):${pass} 通过 / ${fail} 失败`);
  if (!fail) console.log('✓ 断层补齐、止损、按格点预算、跨房补拉、换房竞态、健康路径零打扰,全部成立');
  process.exit(fail ? 2 : 0);
})();
