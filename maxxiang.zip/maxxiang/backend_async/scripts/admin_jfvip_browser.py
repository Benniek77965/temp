"""admin_jfvip_browser.py — 「值」订单页的**真实浏览器**核查(4.2.6 第四轮)

为什么必须有这个脚本:jsdom **不做布局**。三轮复审下来,盒模型、溢出、
触控目标尺寸、flex 换行、`<input type=date>` 的实际渲染,是唯一一块
始终验不到的盲区 —— 而本轮就是在真 Chromium 里量出了两个失效带:
  · 761–779px:提示文字在 ~779px 就挤不下,而媒体查询断点写的是 760px,
    中间 20px 里「导出」按钮掉到第二行左侧,右边空着 431px;
  · <420px:三颗按钮排不下,同样掉行留空 137px。
两条都是**看源码永远发现不了**的,断点也是逐档扫出来的、不是拍的。

用法(需要 playwright,未装则整个脚本跳过,不阻断主干):
    pip install playwright && python3 -m playwright install --with-deps chromium
    python3 backend_async/scripts/admin_jfvip_browser.py
"""
import http.server, json, socketserver, threading, functools, sys, os

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("[跳过] 未安装 playwright —— 真实浏览器核查需要它;"
          "jsdom 冒烟(admin_jfvip_jsdom.js)仍覆盖行为层。")
    sys.exit(0)

_REPO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# --root dist:对**混淆产物**做同一套布局核查。源码能跑 ≠ 产物能跑,
# 本项目对此有前科(见 build-deploy.mjs 注释),布局层同样不该只信源码。
ROOT = (sys.argv[sys.argv.index("--root") + 1]
        if "--root" in sys.argv else _REPO)
if not os.path.isabs(ROOT):
    ROOT = os.path.join(_REPO, ROOT)
PORT = 8731
PASS = FAIL = 0


def A(name, ok, extra=""):
    global PASS, FAIL
    print(f"  [{'✓' if ok else '✗'}] {name}" + ("" if ok else f"  → {extra}"))
    if ok:
        PASS += 1
    else:
        FAIL += 1


class Q(socketserver.ThreadingTCPServer):
    allow_reuse_address = True


def serve():
    h = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT)
    h.log_message = lambda *a, **k: None
    srv = Q(("127.0.0.1", PORT), h)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


PLANS = [{"code": "d3", "name": "3 天", "price": 18, "jfHours": 72, "ddHours": 72, "tag": ""},
         {"code": "m1", "name": "1 个月", "price": 88, "jfHours": 744, "ddHours": 744, "tag": ""},
         {"code": "m3", "name": "3 个月", "price": 188, "jfHours": 2232, "ddHours": 2232, "tag": ""}]


_TOTAL = [137]          # 可调总数:竞态用例要多页导出才有并发窗口


def orders(total=None, page=1, size=50):
    total = _TOTAL[0] if total is None else total
    items = []
    for i in range(min(size, max(0, total - (page - 1) * size))):
        n = total - ((page - 1) * size + i)
        items.append({"id": n, "orderNo": f"GW2026072500{n:06d}", "userId": 90000 + n,
                      "userName": f"用户名较长的账号{n}", "plan": "m1", "amount": 88.0,
                      "status": "paid", "credited": True, "simulate": n % 7 == 0,
                      "createTime": "2026-07-25T10:00:00", "payTime": "2026-07-25T10:01:00"})
    return {"ok": True, "total": total, "totalCapped": False, "page": page,
            "size": size, "userNotFound": False, "items": items}


def route(r):
    u = r.request.url
    if "/admin/session" in u:
        b = {"ok": True, "authed": True, "csrf": "c", "rev": 1}
    elif "/admin/schema" in u:
        b = {"ok": True, "fields": {}, "sections": []}
    elif "/jfvip/overview" in u:
        b = {"ok": True, "enabled": True, "plans": PLANS, "vipAlive": 12,
             "today": {"grants": 3, "amount": 264}, "week": {"grants": 9, "amount": 792},
             "byPlan": {}, "freeVisits7d": 47, "cardsUnused": 38}
    elif "/jfvip/orders" in u:
        import re
        pg = int((re.search(r"page=(\d+)", u) or [0, 1])[1])
        sz = int((re.search(r"size=(\d+)", u) or [0, 50])[1])
        b = orders(None, pg, sz)
    elif "/jfvip/" in u:
        b = {"ok": True, "total": 0, "totalCapped": False, "page": 1, "size": 50, "items": []}
    else:
        b = {"ok": True}
    r.fulfill(status=200, content_type="application/json", body=json.dumps(b))


def overflows(page, sel):
    """元素是否横向溢出其**滚动祖先**(而不是简单比宽度)。"""
    return page.eval_on_selector(sel, """el => {
        const r = el.getBoundingClientRect();
        let p = el.parentElement, box = null;
        while (p) { const cs = getComputedStyle(p);
          if (cs.overflowX === 'auto' || cs.overflowX === 'scroll' || p === document.body) { box = p; break; }
          p = p.parentElement; }
        if (!box) return false;
        const b = box.getBoundingClientRect();
        return r.right > b.right + 1 || r.left < b.left - 1;
    }""")


def run(pw, width, height, label):
    global PASS, FAIL
    br = pw.chromium.launch(args=["--no-sandbox"])
    ctx = br.new_context(viewport={"width": width, "height": height})
    pg = ctx.new_page()
    errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
    pg.route("**/api/**", route)
    pg.add_init_script("localStorage.setItem('sta_admin_exp', String(Date.now()+600000))")
    pg.goto(f"http://127.0.0.1:{PORT}/admin.html#/jfvip", wait_until="networkidle")
    pg.click('[data-view="jfvip"]')
    pg.wait_for_timeout(500)
    pg.click('[data-jv="orders"]')
    pg.wait_for_selector("#jvOrdNo", timeout=5000)
    pg.wait_for_timeout(300)

    print(f"\n[{label}  {width}×{height}]")
    A("零页面异常", not errs, " | ".join(errs[:2]))

    # ① 触控目标 ≥24×24(WCAG 2.5.8 —— 项目 admin.css 里明确为此改过 min-height)
    small = pg.eval_on_selector_all(
        "#jvBody input, #jvBody select, #jvBody button",
        """els => els.filter(e => { const r = e.getBoundingClientRect();
             return r.width > 0 && (r.height < 24 || r.width < 24); })
             .map(e => (e.id||e.tagName) + ' ' + Math.round(e.getBoundingClientRect().width)
                  + 'x' + Math.round(e.getBoundingClientRect().height))""")
    A("所有控件触控目标 ≥24×24 (WCAG 2.5.8)", not small, "; ".join(small[:6]))

    # ② 筛选条每一格都不得溢出
    bad = []
    for eid in ["jvOrdNo", "jvOrdUser", "jvFlt", "jvOrdPlan", "jvOrdFrom", "jvOrdTo",
                "jvOrdAmin", "jvOrdAmax", "jvOrdSim", "jvOrdCred"]:
        if overflows(pg, f"#{eid}"):
            bad.append(eid)
    A("筛选条无横向溢出", not bad, ",".join(bad))

    # ③ 网格真的换行了(而不是挤成一行压扁)
    rows = pg.eval_on_selector_all(".jv-filters > .jv-f",
                                   "els => [...new Set(els.map(e => Math.round(e.getBoundingClientRect().top)))].length")
    A(f"筛选网格按宽度自然分行(实测 {rows} 行)", rows >= 1)

    # ④ date 控件真的是日期控件(jsdom 里 type=date 只是普通 input)
    t = pg.eval_on_selector("#jvOrdFrom", "e => e.type")
    A("下单起是真 date 控件", t == "date", t)

    # ⑤ 分页器四向按钮 + 每页条数都在视口内可点
    pgr = pg.eval_on_selector_all(".jv-pager [data-jvp], .jv-pager [data-jvps]",
        """els => els.map(e => { const r = e.getBoundingClientRect();
             return {k: e.dataset.jvp || 'size', w: Math.round(r.width), h: Math.round(r.height),
                     vis: r.width > 0 && r.height > 0}; })""")
    A(f"分页器控件全部可见可点(共 {len(pgr)} 个)", pgr and all(x["vis"] for x in pgr),
      json.dumps(pgr, ensure_ascii=False))

    # ⑥ 宽表在窄屏必须由卡片横向滚动兜住,不能把版面撑破
    body_of = pg.evaluate("() => document.documentElement.scrollWidth > window.innerWidth + 1")
    A("页面整体无横向滚动(宽表由卡片自身滚动)", not body_of,
      f"scrollWidth={pg.evaluate('document.documentElement.scrollWidth')} vw={width}")

    # ⑦ 焦点环可见(:focus-visible 有 outline)
    pg.focus("#jvOrdNo")
    ol = pg.eval_on_selector("#jvOrdNo", "e => getComputedStyle(e).outlineStyle")
    A("输入框聚焦有可见焦点环", ol not in ("none", ""), ol)

    # ⑧ 「导出」按钮:要么与「查询」同行且贴右,要么整行铺满 —— 不许出现
    #    「挤到第二行、左对齐、右边空一大片」这种看着像坏了的中间态。
    #    (这条 CSS 三轮前实测是**死的**:.spacer 根本没生效。)
    m = pg.evaluate("""() => { const R = x => x.getBoundingClientRect();
        const q = R(document.getElementById('jvFltGo')),
              e = R(document.getElementById('jvExp')),
              row = R(document.querySelector('.jv-acts'));
        return {same: Math.abs(q.top - e.top) < 4, gap: Math.round(row.right - e.right),
                full: Math.abs(e.width - row.width) < 4}; }""")
    A("导出按钮无孤儿态(同行贴右 或 整行铺满)",
      m["gap"] < 24 and (m["same"] or m["full"]),
      f"同行={m['same']} 铺满={m['full']} 距右={m['gap']}px")

    ctx.close()
    br.close()



def race(pw):
    """导出与筛选的竞态(第五轮实测复现,**原始版即有**)。

    jvFetchAll 逐页取满(单次上限 5000 行 = 10 个来回),而 URL 构造器闭包读的是
    状态**对象本身**、doQuery() 又是就地改它 —— 期间改筛选点「查询」,后半段
    就用新条件取数,CSV 变成两套条件的混合物,文件名与行数全看不出异常。

    ⚠ 造并发有两个坑,都踩过:
      · 在 route 处理器里 time.sleep 会把 Playwright 驱动线程一起卡住,
        导出全跑完才轮到点击 —— 并发根本没造出来(第一次实测假通过);
      · 只记 size=500 的请求,分不清「没竞态」和「没触发」。
    故:延迟注入到**浏览器内部**,且记录全部请求。
    """
    br = pw.chromium.launch(args=["--no-sandbox"])
    ctx = br.new_context(viewport={"width": 1440, "height": 900})
    p = ctx.new_page()
    seen = []
    p.route("**/api/**", lambda r: (seen.append(r.request.url), route(r))[-1])
    p.add_init_script("""
      localStorage.setItem('sta_admin_exp', String(Date.now()+600000));
      const _f = window.fetch;
      window.fetch = async (u, o) => {
        if (String(u).includes('size=500')) await new Promise(r => setTimeout(r, 600));
        return _f(u, o); };
    """)
    p.goto(f"http://127.0.0.1:{PORT}/admin.html#/jfvip", wait_until="networkidle")
    p.click('[data-view="jfvip"]'); p.wait_for_timeout(400)
    p.click('[data-jv="orders"]'); p.wait_for_selector("#jvOrdNo"); p.wait_for_timeout(250)
    p.evaluate("() => { const a = document.createElement;"
               " document.createElement = function(t){ const e = a.call(document,t);"
               " if (t === 'a') e.click = () => {}; return e; }; }")
    seen.clear()
    _TOTAL[0] = 1500                     # 1500/500 = 3 页,足够开出并发窗口
    p.click("#jvExp")
    p.wait_for_timeout(500)
    p.fill("#jvOrdUser", "bob"); p.select_option("#jvFlt", "pending"); p.click("#jvFltGo")
    p.wait_for_timeout(2600)
    exp = [u for u in seen if "size=500" in u]
    fired = any("size=50&" in u and "userName=bob" in u for u in seen)
    conds = {("userName=bob" in u) for u in exp}
    print("\n[导出竞态]")
    A("测试确实制造了并发(导出在途时「查询」已触发)", fired and len(exp) >= 2,
      f"导出请求 {len(exp)} 个 / 查询已触发={fired}")
    A("导出全程使用同一套筛选条件(快照未被中途改写)", len(conds) == 1,
      f"实际出现 {len(conds)} 套:{exp}")
    _TOTAL[0] = 137
    ctx.close(); br.close()


with sync_playwright() as pw:
    srv = serve()
    try:
        print("真实 Chromium 布局核查\n" + "─" * 54)
        run(pw, 1440, 900, "桌面")
        run(pw, 390, 844, "手机")
        run(pw, 768, 900, "平板")
        race(pw)
    finally:
        srv.shutdown()
print("\n" + "─" * 54)
print(f"真实浏览器核查:{PASS} 通过 / {FAIL} 失败")
sys.exit(1 if FAIL else 0)
