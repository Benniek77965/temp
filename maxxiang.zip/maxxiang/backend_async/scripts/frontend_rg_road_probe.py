# -*- coding: utf-8 -*-
"""5.0.8 DIY「近24小时战况」增高 + 5.0.9 高度档(常规/加高)—— 可复跑量测探针(真 Chromium)。

量什么:10 视口(4 桌面停靠 / 1 剧场触屏 / 5 手机真触屏仿真)逐容器高度、
战况可用高与行数;外加三组专项断言:
  ① 触屏纪律:hover/pointer 媒体门 + html[data-input="touch"] 运行时收敛 ——
     触屏场景推演带不许单行合并、统计行不许被省略号截断;
  ② 官方象限免疫:realPane 挂 hidden 后,C1 头部压缩全部回退(padding 8px、
     同步条成员复显)—— 官方象限零改动是本批的作用域红线;
  ③ 4.9.3 缺口期长文案:桌面 A 档 / 触屏一律折行全量可见,桌面 B/C 档单行
     省略(title 兜底);任何场景不许横向溢出。
不变式:命中脉冲环 --rg-hit 必须小于格缝 --rg-gap(5.0.7 教训);
rgFitRoad 底部留白从 app.js 实文解析(单一事实源),且必须大于盘面底衬。

5.0.9 追加断言(每视口):① 常规档 avail 与 5.0.8 基线逐像素相同(钉零回归 ——
  加高钮/隐「位数」二字不许改变常规档一像素);② 加高档 avail − 常规档 ≥ 90px
  (十视口实测最小增量 106px@320,余量 16);③ 倍率徽记全档零截断、盘面零横向
  溢出、战况头恒单行(headH ≤ 44);④ 横幅在场(RG.award 常驻口径)同样成立。

跑法:python3 frontend_rg_road_probe.py [覆盖CSS文件|-] [--baseline]
  无参 = 量当前 assets/app.css;--baseline 只出表不作断言(供改前对照)。
依赖:pip install playwright && playwright install chromium
"""
import json, re, sys
from pathlib import Path

from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
URL = (HERE / "frontend_rg_road_fixture.html").as_uri()
LONG = "灵机推演 · 近44局 主中11 · 防中9 · 窗口100局 · 56局暂无判定 · 仅供参考"

overlay = ""
args = [a for a in sys.argv[1:] if a != "--baseline"]
ASSERT = "--baseline" not in sys.argv
if args and args[0] != "-":
    overlay = Path(args[0]).read_text(encoding="utf-8")

# rgFitRoad 的底部留白:从 app.js 实文解析,不许在此另写一份数字
appjs = (ROOT / "assets/app.js").read_text(encoding="utf-8")
m = re.search(r"bodyBottom - roadTop - (\d+)", appjs)
assert m, "app.js 里找不到 rgFitRoad 的留白表达式"
SLACK = int(m.group(1))
padb = re.search(r"\.rg-body\{gap:\d+px;padding:\d+px 11px (\d+)px\}",
                 (ROOT / "assets/app.css").read_text(encoding="utf-8"))
if ASSERT:
    assert padb, "app.css 里找不到 5.0.8 的 .rg-body 底衬规则(正则失配 —— 若重排过该行,同步更新此正则)"
    assert SLACK > int(padb.group(1)), f"留白 {SLACK} 未大于盘面底衬 {padb.group(1)},盘面会冒滚动条"

SCENES = [
    (1024, 768, False, "D-1024×768(坞392·A档)"), (1280, 800, False, "D-1280×800(坞435·B档)"),
    (1440, 900, False, "D-1440×900(坞490·B档)"), (1920, 1080, False, "D-1920×1080(坞560·B档)"),
    (820, 1180, True, "T-820×1180(剧场·C档·触屏)"), (320, 568, True, "M-320×568(SE1)"),
    (360, 800, True, "M-360×800"), (375, 667, True, "M-375×667(SE2)"),
    (390, 844, True, "M-390×844"), (430, 932, True, "M-430×932"),
]
EXTRA = """() => { const st = document.querySelector('.rg-pred-stat');
  return { hoverFine: matchMedia('(hover:hover) and (pointer:fine)').matches,
    merged: getComputedStyle(document.querySelector('.rg-pred')).display === 'flex',
    statClip: st ? +(st.scrollWidth - st.clientWidth).toFixed(1) : 0,
    hit: getComputedStyle(document.querySelector('.rg-cell[data-no="3"]')).getPropertyValue('--rg-hit').trim() || '(默认6px)',
    gap: getComputedStyle(document.querySelector('.rg-grid')).getPropertyValue('--rg-gap').trim() }; }"""

# 5.0.8 基线(--baseline 口径,真 Chromium 十视口实测):常规档 avail 逐像素钉死。
BASE_AVAIL = {"D-1024×768(坞392·A档)": 204, "D-1280×800(坞435·B档)": 245,
              "D-1440×900(坞490·B档)": 345, "D-1920×1080(坞560·B档)": 525,
              "T-820×1180(剧场·C档·触屏)": 573, "M-320×568(SE1)": -37, "M-360×800": 195,
              "M-375×667(SE2)": 62, "M-390×844": 266, "M-430×932": 345}

out, fails = [], []
with sync_playwright() as p:
    b = p.chromium.launch()
    for w, h, touch, tag in SCENES:
        ctx = b.new_context(viewport={"width": w, "height": h}, is_mobile=touch, has_touch=touch)
        pg = ctx.new_page(); pg.goto(URL, wait_until="networkidle")
        if overlay: pg.evaluate("c => window.APPLY(c)", overlay)
        m = pg.evaluate(f"window.MEASURE({SLACK})"); m.update(pg.evaluate(EXTRA)); m["scen"] = tag
        # 5.0.9:加高档 + 横幅在场(实况)两个口径同批量测
        pg.evaluate("() => window.SETSIZE('tall')")
        t = pg.evaluate(f"window.MEASURE({SLACK})")
        ta = pg.evaluate(f"window.MEASURE({SLACK}, true)")
        pg.evaluate("() => window.SETSIZE('normal')")
        na = pg.evaluate(f"window.MEASURE({SLACK}, true)")
        pg.evaluate(f"window.MEASURE({SLACK})")   # 复位到常规无横幅,后续专项断言沿用 5.0.8 语境
        m["tallAvail"], m["tallRows"], m["tallGrid"] = t["avail"], t["rows"], t["grid"]
        m["awardH"], m["tallAwardAvail"] = na["award"], ta["avail"]
        out.append(m)
        if not ASSERT: ctx.close(); continue
        # —— 5.0.9 断言 ——
        if tag in BASE_AVAIL and m["avail"] != BASE_AVAIL[tag]:
            fails.append((tag, "常规档回归(≠5.0.8 基线)", m["avail"], BASE_AVAIL[tag]))
        if t["avail"] - m["avail"] < 90: fails.append((tag, "加高增量不足 90px", m["avail"], t["avail"]))
        for lab, mm in (("常规", m), ("加高", t), ("加高+横幅", ta), ("常规+横幅", na)):
            if mm.get("multClip", 0) > 0: fails.append((tag, f"{lab}:倍率徽记截断", mm["multClip"]))
            if mm.get("gridOvfX", 0) > 1: fails.append((tag, f"{lab}:盘面横向溢出", mm["gridOvfX"]))
            if mm.get("headH", 0) > 44: fails.append((tag, f"{lab}:战况头折行", mm["headH"]))
        if touch and (m["hoverFine"] or m["merged"]): fails.append((tag, "触屏被合并/媒体误判"))
        if not touch and m["bodyW"] >= 408 and not m["merged"]: fails.append((tag, "桌面B/C档未合并"))
        if not touch and m["bodyW"] < 408 and m["merged"]: fails.append((tag, "A档不该合并"))
        if any(v > 1 for v in m["ovf"].values()) or m["predRowWrapped"] or m["selWrapped"]:
            fails.append((tag, "溢出/折行", m["ovf"], m["predRowWrapped"], m["selWrapped"]))
        if touch and m["statClip"] > 0: fails.append((tag, "触屏统计行被截断", m["statClip"]))
        hv = 6.0 if "默认" in m["hit"] else float(m["hit"].replace("px", ""))
        if hv >= float(m["gap"].replace("px", "")): fails.append((tag, "脉冲环≥格缝", m["hit"], m["gap"]))
        ctx.close()

    if ASSERT:
        # ① 桌面 1440:data-input=touch 运行时收敛(设→撤→设 mouse)
        pg = b.new_page(viewport={"width": 1440, "height": 900}); pg.goto(URL, wait_until="networkidle")
        if overlay: pg.evaluate("c => window.APPLY(c)", overlay)
        pg.evaluate(f"window.MEASURE({SLACK})")
        t = pg.evaluate("""() => { const g = () => getComputedStyle(document.querySelector('.rg-pred')).display;
          const a = g(); document.documentElement.setAttribute('data-input','touch'); const bd = g();
          document.documentElement.setAttribute('data-input','mouse'); const c = g();
          document.documentElement.removeAttribute('data-input'); return {before:a, touch:bd, mouse:c}; }""")
        if not (t["before"] == "flex" and t["touch"] == "block" and t["mouse"] == "flex"):
            fails.append(("1440", "data-input 收敛失效", t))
        # ② 官方象限免疫:realPane 挂 hidden(夹具无 simPane,即官方态)—— C1 全回退。
        #    注:.jiufa-sync b 是行内元素被弹性容器块化,恢复后的计算值就是 block。
        imm = pg.evaluate("""() => { const s = () => ({
            headPad: getComputedStyle(document.querySelector('.jiufa-head')).paddingTop,
            syncB: getComputedStyle(document.querySelector('.jiufa-sync b')).display });
          const on = s(); document.getElementById('realPane').hidden = true; const off = s();
          document.getElementById('realPane').hidden = false; return {on, off}; }""")
        if not (imm["on"]["syncB"] == "none" and imm["off"]["headPad"] == "8px" and imm["off"]["syncB"] == "block"):
            fails.append(("1440", "官方象限免疫失败", imm))
        pg.close()
        # ③ 4.9.3 缺口期长文案:桌面A档/触屏折行全见,桌面B/C档单行省略,均不许横向溢出
        for w, h, touch, tag in [(1024, 768, False, "长文案·桌面A档"), (1440, 900, False, "长文案·桌面B档"), (390, 844, True, "长文案·触屏390")]:
            ctx = b.new_context(viewport={"width": w, "height": h}, is_mobile=touch, has_touch=touch)
            pg = ctx.new_page(); pg.goto(URL, wait_until="networkidle")
            if overlay: pg.evaluate("c => window.APPLY(c)", overlay)
            pg.evaluate(f"window.MEASURE({SLACK})")
            r = pg.evaluate("""(txt) => { const st = document.querySelector('.rg-pred-stat'); st.textContent = txt;
              const pr = document.querySelector('.rg-pred');
              return { merged: getComputedStyle(pr).display === 'flex',
                statClip: +(st.scrollWidth - st.clientWidth).toFixed(1),
                predOvfX: +(pr.scrollWidth - pr.clientWidth).toFixed(1) }; }""", LONG)
            if r["predOvfX"] > 1 or (not r["merged"] and r["statClip"] > 1):
                fails.append((tag, "长文案处置越轨", r))
            ctx.close()
    b.close()

hdr = ["scen", "dockW", "icon", "head", "acct", "round", "nav", "grid", "pred", "castbar", "roadHead", "avail", "rows", "cols", "beads", "merged",
       "tallGrid", "tallAvail", "tallRows", "awardH", "tallAwardAvail"]
print(f"══ 战况增高量测(slack={SLACK}{',基线口径' if not ASSERT else ''})══")
print(" | ".join(hdr))
for r in out: print(" | ".join(str(r.get(k)) for k in hdr))
print("断言:", "全部通过 ✓" if not fails else "FAIL → " + repr(fails))
sys.exit(0 if not fails else 1)
