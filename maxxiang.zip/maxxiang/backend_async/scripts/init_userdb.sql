-- ═══ 登录系统(3.8.0):用户库新表手动初始化(可选)═══════════════════════════
-- web 服务首次启动会自动执行等价的 CREATE TABLE IF NOT EXISTS(见 app/userauth.py
-- 的 _SCHEMA);本文件供「想在启用前手动建好 / 账号只授予了运行期最小权限」的场景。
--
-- 用法(任一 MySQL 客户端;注意 --default-character-set 按你的终端编码来):
--   mysql -h120.79.26.174 -P3306 -ufanxing_admin -p fanxing_changkong_user_db \
--         --default-character-set=utf8mb4 < init_userdb.sql
--
-- 纪律:只建 guantai_ 前缀的**新表**;对既有 tb_user / sys_* 绝对零触碰。
-- 幂等:重复执行安全(IF NOT EXISTS)。

CREATE TABLE IF NOT EXISTS guantai_user_session (
  id            BIGINT       NOT NULL AUTO_INCREMENT,
  user_id       BIGINT       NOT NULL COMMENT '关联 tb_user.id',
  user_name     VARCHAR(50)  NOT NULL DEFAULT '' COMMENT '冗余用户名(审计可读)',
  token_hash    CHAR(64)     NOT NULL COMMENT '会话令牌的 SHA-256(令牌本身不落库)',
  created_at    DATETIME     NOT NULL,
  last_seen_at  DATETIME     NOT NULL,
  expires_at    DATETIME     NOT NULL,
  ip            VARCHAR(45)  NOT NULL DEFAULT '',
  ua            VARCHAR(200) NOT NULL DEFAULT '',
  revoked       TINYINT      NOT NULL DEFAULT 0 COMMENT '1=已失效',
  revoke_reason VARCHAR(20)  NOT NULL DEFAULT '' COMMENT 'kicked/logout/evicted/admin',
  PRIMARY KEY (id),
  UNIQUE KEY uk_token (token_hash),
  KEY idx_user (user_id, revoked)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台登录会话(登录系统 3.8.0 新建)';

CREATE TABLE IF NOT EXISTS guantai_login_log (
  id         BIGINT       NOT NULL AUTO_INCREMENT,
  user_id    BIGINT       NOT NULL DEFAULT 0,
  user_name  VARCHAR(50)  NOT NULL DEFAULT '',
  ip         VARCHAR(45)  NOT NULL DEFAULT '',
  ua         VARCHAR(200) NOT NULL DEFAULT '',
  ok         TINYINT      NOT NULL DEFAULT 0,
  reason     VARCHAR(30)  NOT NULL DEFAULT '' COMMENT 'ok/bad_credentials/banned/expired/throttled',
  created_at DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY idx_name_time (user_name, created_at),
  KEY idx_time (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台登录审计(登录系统 3.8.0 新建)';

-- ═══ 注册系统(4.0.0):再建三张 guantai_ 新表(同样幂等、零触碰旧表)═══════════
-- web 首启会自动执行等价 CREATE(app/userauth.py 的 _SCHEMA);本段供手动预建。
CREATE TABLE IF NOT EXISTS guantai_invite_code (
  id           BIGINT       NOT NULL AUTO_INCREMENT,
  code         VARCHAR(20)  NOT NULL COMMENT 'Crockford Base32,存大写去分隔',
  days_granted INT          NOT NULL DEFAULT 0 COMMENT '注册成功赠送天数(0=不赠)',
  quota        INT          NOT NULL DEFAULT 1 COMMENT '可用次数',
  used_count   INT          NOT NULL DEFAULT 0,
  expires_at   DATETIME     NULL     COMMENT 'NULL=不过期',
  disabled     TINYINT      NOT NULL DEFAULT 0,
  note         VARCHAR(100) NOT NULL DEFAULT '',
  created_at   DATETIME     NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台注册邀请码(4.0.0 新建)';

CREATE TABLE IF NOT EXISTS guantai_reg_log (
  id         BIGINT       NOT NULL AUTO_INCREMENT,
  user_id    BIGINT       NOT NULL DEFAULT 0 COMMENT '成功时=新 tb_user.id',
  user_name  VARCHAR(50)  NOT NULL DEFAULT '',
  ip         VARCHAR(45)  NOT NULL DEFAULT '',
  ua         VARCHAR(200) NOT NULL DEFAULT '',
  fp         CHAR(16)     NOT NULL DEFAULT '' COMMENT '设备指纹摘要(前16hex,可空)',
  invite_id  BIGINT       NOT NULL DEFAULT 0,
  ok         TINYINT      NOT NULL DEFAULT 0,
  reason     VARCHAR(30)  NOT NULL DEFAULT '' COMMENT 'ok/name_taken/pow_failed/…',
  created_at DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY idx_ip_time (ip, created_at),
  KEY idx_time (created_at),
  KEY idx_fp (fp),
  KEY idx_name (user_name)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台注册审计(4.0.0 新建；并入每日清扫)';
-- 4.0.7:idx_name 补齐 —— 管理台流水四个筛选维度里唯一没索引的一个。
-- 存量库手动补:ALTER TABLE guantai_reg_log ADD KEY idx_name (user_name);

CREATE TABLE IF NOT EXISTS guantai_user_block (
  user_id    BIGINT       NOT NULL COMMENT '关联 tb_user.id',
  reason     VARCHAR(30)  NOT NULL DEFAULT '' COMMENT 'malicious_reg/manual/…',
  note       VARCHAR(100) NOT NULL DEFAULT '',
  created_at DATETIME     NOT NULL,
  PRIMARY KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台侧封禁(4.0.0 新建；不触碰 tb_user.is_off)';

-- ═══ 链接快速登录(4.1.0):一张 guantai_ 新表(同样幂等、零触碰旧表)═══════════
-- 签发方 = 同库其它项目(续费/管理系统):INSERT 一行即完成签发(见 SSO-LOGIN.md);
-- 观测台只 SELECT + 单语句原子核销 UPDATE(used 0→1)。web 首启自动建等价表。
CREATE TABLE IF NOT EXISTS guantai_sso_ticket (
  id         BIGINT      NOT NULL AUTO_INCREMENT,
  user_id    BIGINT      NOT NULL COMMENT '关联 tb_user.id(签发方写)',
  token_hash CHAR(64)    NOT NULL COMMENT '票据的 SHA-256(票据本身不落库)',
  created_at DATETIME    NOT NULL COMMENT '签发时刻(签发方写 NOW())',
  expires_at DATETIME    NOT NULL COMMENT '签发方定的失效时刻(建议 NOW()+60s)',
  used       TINYINT     NOT NULL DEFAULT 0 COMMENT '1=已核销(单次有效)',
  used_at    DATETIME    NULL,
  used_ip    VARCHAR(45) NOT NULL DEFAULT '',
  note       VARCHAR(50) NOT NULL DEFAULT '' COMMENT '签发方备注(审计可读,可空)',
  PRIMARY KEY (id),
  UNIQUE KEY uk_token (token_hash),
  KEY idx_exp (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='跨项目链接快速登录票据(4.1.0 新建;签发方=同库其它项目)';

-- ═══════════════════════════════════════════════════════════════════════════
-- 九法 VIP 分层与收费(4.2.0)· 四张新表
-- ---------------------------------------------------------------------------
-- 与上方既有 guantai_* 表同一纪律:guantai_ 前缀、CREATE TABLE IF NOT EXISTS
-- 幂等、对 tb_user / sys_* 等一切已存在表**零触碰**。
-- web 首启会自动幂等建表(app/userauth.py 的 _SCHEMA);本文件供手动预建/审阅,
-- 内容与代码中的 DDL **逐字一致**(由 tests/test_jfvip_discipline 之外的
-- scripts/userdb_check.py --jfvip-preflight 实机比对)。
--
-- 唯一会写既有表的地方:开通 VIP 时对 tb_user.due_time 的那一条 UPDATE
-- (赠送小叮当时长),位于 app/jfvip.py::_grant_tx。除此之外全项目对 tb_user
-- 仍是只读。故本库账号需要的权限是:
--   tb_user      : SELECT + UPDATE(仅 due_time)
--   guantai_*    : CREATE / SELECT / INSERT / UPDATE
-- ═══════════════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS guantai_jf_vip (
         user_id     BIGINT   NOT NULL COMMENT '关联 tb_user.id',
         vip_until   DATETIME NOT NULL COMMENT '九法VIP到期(一律由库钟判定)',
         first_at    DATETIME NOT NULL COMMENT '首次开通时刻(留存分析)',
         total_hours INT      NOT NULL DEFAULT 0 COMMENT '累计开通小时数',
         updated_at  DATETIME NOT NULL,
         PRIMARY KEY (user_id),
         KEY idx_until (vip_until)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='九法VIP到期(4.2.0 新建)';
CREATE TABLE IF NOT EXISTS guantai_jf_order (
         id               BIGINT        NOT NULL AUTO_INCREMENT,
         gateway_order_no VARCHAR(64)   NOT NULL COMMENT '网关订单号(幂等的物理底线)',
         user_id          BIGINT        NOT NULL,
         user_name        VARCHAR(50)   NOT NULL DEFAULT '',
         plan_code        VARCHAR(16)   NOT NULL COMMENT 'd3/m1/m3',
         jf_hours         INT           NOT NULL DEFAULT 0 COMMENT '下单时的档位快照(改价不影响在途单)',
         dd_hours         INT           NOT NULL DEFAULT 0 COMMENT '同上:赠送小叮当时长快照',
         amount           DECIMAL(10,2) NOT NULL COMMENT '网关 price(单一真源,非用户请求金额)',
         status           VARCHAR(16)   NOT NULL DEFAULT 'pending' COMMENT 'pending/paid/expired',
         credited         TINYINT       NOT NULL DEFAULT 0 COMMENT '1=已开通(幂等哨兵)',
         is_simulate      TINYINT       NOT NULL DEFAULT 0,
         ip               VARCHAR(45)   NOT NULL DEFAULT '',
         create_time      DATETIME      NOT NULL,
         expire_time      DATETIME      NULL,
         pay_time         DATETIME      NULL,
         PRIMARY KEY (id),
         UNIQUE KEY uk_order (gateway_order_no),
         KEY idx_user (user_id, id),
         KEY idx_status_time (status, create_time)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='九法VIP在线充值订单(4.2.0 新建)';
CREATE TABLE IF NOT EXISTS guantai_jf_card (
         id         BIGINT       NOT NULL AUTO_INCREMENT,
         card       VARCHAR(32)  NOT NULL COMMENT 'TL+6字母+6数字(排除 I/O/0/1);JF 为历史前缀,仍可兑换',
         plan_code  VARCHAR(16)  NOT NULL,
         batch      VARCHAR(32)  NOT NULL DEFAULT '' COMMENT '批次号(发卡/召回按批)',
         note       VARCHAR(100) NOT NULL DEFAULT '',
         disabled   TINYINT      NOT NULL DEFAULT 0 COMMENT '1=作废(仅未使用卡可召回)',
         used_by    BIGINT       NOT NULL DEFAULT 0 COMMENT '0=未使用;否则 tb_user.id',
         used_name  VARCHAR(50)  NOT NULL DEFAULT '',
         used_at    DATETIME     NULL,
         created_by VARCHAR(32)  NOT NULL DEFAULT '',
         created_at DATETIME     NOT NULL,
         PRIMARY KEY (id),
         UNIQUE KEY uk_card (card),
         KEY idx_batch (batch),
         KEY idx_used (used_by, used_at)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='九法VIP卡密池(4.2.0 新建)';
CREATE TABLE IF NOT EXISTS guantai_jf_grant_log (
         id         BIGINT        NOT NULL AUTO_INCREMENT,
         user_id    BIGINT        NOT NULL,
         user_name  VARCHAR(50)   NOT NULL DEFAULT '',
         source     VARCHAR(16)   NOT NULL COMMENT 'order/card/admin/revoke',
         ref        VARCHAR(64)   NOT NULL DEFAULT '' COMMENT '订单号/卡号',
         plan_code  VARCHAR(16)   NOT NULL DEFAULT '',
         amount     DECIMAL(10,2) NOT NULL DEFAULT 0,
         jf_hours   INT           NOT NULL DEFAULT 0 COMMENT '本次九法VIP增量(负=撤销)',
         dd_hours   INT           NOT NULL DEFAULT 0 COMMENT '本次赠送小叮当增量',
         vip_before DATETIME      NULL,
         vip_after  DATETIME      NULL,
         due_before DATETIME      NULL,
         due_after  DATETIME      NULL,
         operator   VARCHAR(32)   NOT NULL DEFAULT '',
         created_at DATETIME      NOT NULL,
         PRIMARY KEY (id),
         KEY idx_user (user_id, id),
         KEY idx_time (created_at),
         KEY idx_source (source, created_at)
       ) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='九法VIP开通流水(唯一对账口径;4.2.0 新建)';
