#!/usr/bin/env python3
"""sim_hist_mode.py — hist-mode(3.5.0)全量验证仿真台
================================================================================
与 sim_history_gap 同基座(SimUpstream / FakeDB / VClock / pump 逐件复用,虚拟
时钟直逼真实 Worker._handle),但被试对象是 **hist-mode 状态机本体**:后台发现房
经 `hs|room` 轮询任务走 `_handle_hist` 的完整链路 —— 领取/租约/重排、页解析、
批量入库、覆盖审计(covWm)、退避/抢救、双向有机迁移、多副本互斥。

原型(sim_hist_mode_proto.py)只回答"直接调用 _backfill_history 的请求账本";
本台回答"**真实任务循环里的状态机**是否兑现方案的每一条承诺"。

场景矩阵(全部断言式,任何一条不满足即非零退出):
  H0  稳态账本      240 局窗口:请求数 ≈ 窗口/T(±1),aw/mp 恒 0,数据零洞,
                    水位滞后 ≤ 页深,lastok 新鲜
  H1  轮询失败链    第 3/4 次调用失败:退避后照常收敛,histFails 复位,零洞
  H2  断供矩阵      10/20 分钟断供 → 恢复零洞(20 分钟已进抢救节拍);
                    30 分钟断供 → 越窗:洞全部被登记「官方缺失」(止损可见),
                    window_lost 计数 >0,水位照常推进(绝不静默、绝不卡死)
  H4  双向迁移      实时→轮询(mp 原地改排,aw 停增)→ 转正(收尾回填封尾窗,
                    mp 恢复,lastok 清净);回滚(关开关)同理
  H5  页内官方缺    整页在手仍缺的格点 = 登记官方缺失,不计 window_lost
  H6  多副本同房    两副本共享同一队列:租约互斥,无重复轮询,账本精确

用法:python -m scripts.sim_hist_mode            # 全场景
      python -m scripts.sim_hist_mode H2         # 单场景
"""
from __future__ import annotations

import asyncio
import random
import sys

sys.path.insert(0, __file__.rsplit("/scripts/", 1)[0])

from scripts.sim_history_gap import (  # noqa: E402  基座逐件复用
    STEP, T0, FakeDB, SimUpstream, VClock, pump)
from app import redis_bus as rb        # noqa: E402
from app import worker as wk           # noqa: E402
from app.redis_bus import task_hist, task_mainpage  # noqa: E402
from app.settings import Settings      # noqa: E402
from app.scheduler import effective_hist_interval_ms  # noqa: E402

import fakeredis.aioredis              # noqa: E402

ROOM = "2678075"
T_POLL_S = 300                          # H0–H6 固定 300 档(机制验证密拍更严苛);
                                        # 生产默认 900 档的边际实证见 H7


def build_world(*, enabled: bool = True, interval_s: int = T_POLL_S,
                seed: int = 7, replicas: int = 1):
    """hist-mode 世界:发现房 + hs 轮询任务起步(replicas>1 时共享总线/上游/库)。"""
    clock = VClock(T0 + 10 * STEP + 2_000)
    rb.now_ms = clock
    wk.now_ms = clock
    random.seed(seed)                                # 抖动确定性(账本可 ±1 断言)

    s = Settings()
    s.prediction = {"enabled": False}
    s.scheduler.award_jitter_ms = 0
    s.scheduler.mainpage_jitter_ms = 0
    s.histmode.enabled = enabled
    s.histmode.interval_s = interval_s

    r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    up, db = None, FakeDB()
    workers = []
    for _ in range(max(1, replicas)):
        w = wk.Worker(s)
        w.bus.r = r
        if up is None:
            up = SimUpstream(clock)
        db._clock = clock
        w.up, w.db = up, db
        workers.append(w)
    return (workers if replicas > 1 else workers[0]), up, db, clock, s


async def _mark_discovered(bus, room: str, ts: int) -> None:
    await bus.r.hset(rb.K_ROOMS_DISCOVERED, room, str(ts))


async def _boot_hist(*, interval_s: int = T_POLL_S, seed: int = 7,
                     replicas: int = 1):
    """发现房已登记 + 首个 hs 任务在排(相位=起点,便于账本推算)。"""
    w, up, db, clock, s = build_world(enabled=True, interval_s=interval_s,
                                      seed=seed, replicas=replicas)
    bus = (w[0] if isinstance(w, list) else w).bus
    await bus.add_rooms_bulk([(ROOM, ROOM)])
    await _mark_discovered(bus, ROOM, clock.t)
    await bus.schedule(task_hist(ROOM), clock.t)
    return w, up, db, clock, s


def _holes(db, start: int, end: int):
    return [g for g in range(start, end + 1, STEP) if g not in db.rounds]


async def _offmiss(bus, grid):
    return set(await bus.official_missing_in(ROOM, list(grid)))


# ── H0 稳态账本 ────────────────────────────────────────────────────────────────
async def h0() -> dict:
    w, up, db, clock, s = await _boot_hist()
    horizon = 240 * STEP
    await pump(w, clock, T0 + 10 * STEP + horizon)
    t_ms = effective_hist_interval_ms(s.histmode)
    # 抖动 +0..T/10 → 周期均值 1.05T;请求数 ∈ [窗/1.1T, 窗/T]+首拍
    lo = int(horizon / (t_ms * 1.1))
    hi = int(horizon / t_ms) + 1
    assert lo <= up.calls["hist"] <= hi, (up.calls, lo, hi)
    assert up.calls["mp"] == 0 and up.calls["aw"] == 0, up.calls
    head = max(db.rounds)
    hs = _holes(db, min(db.rounds), head)
    assert not hs, f"稳态出现数据洞: {hs[:5]}"
    snap = await w.bus.get_snapshot(ROOM)
    wm = int(snap.get("covWm") or 0)
    assert head - wm <= (30 - 1) * STEP, ("水位滞后超页深", head - wm)
    item = await w.bus.hist_oldest()
    assert item and item[0] == ROOM and clock.t - item[1] <= t_ms * 1.1 + 1000
    return {"hist": up.calls["hist"], "mp": up.calls["mp"],
            "aw": up.calls["aw"], "holes": 0,
            "wm_lag_rounds": (head - wm) // STEP}


# ── H1 轮询失败链 ─────────────────────────────────────────────────────────────
async def h1() -> dict:
    w, up, db, clock, s = await _boot_hist()
    up.hist_fail_calls = {3, 4}                     # 第 3/4 次调用失败
    horizon = 120 * STEP
    await pump(w, clock, T0 + 10 * STEP + horizon)
    head = max(db.rounds)
    assert not _holes(db, min(db.rounds), head)
    snap = await w.bus.get_snapshot(ROOM)
    assert (snap.get("histFails") or "0") in ("0", 0), snap.get("histFails")
    base = int(horizon / (effective_hist_interval_ms(s.histmode) * 1.1))
    assert up.calls["hist"] >= base + 2             # 失败重试计入调用账本
    return {"hist": up.calls["hist"], "holes": 0}


# ── H2 断供矩阵(10/20/30 分钟) ───────────────────────────────────────────────
async def _outage(minutes: int) -> dict:
    w, up, db, clock, s = await _boot_hist()
    warm = 40 * STEP
    await pump(w, clock, T0 + 10 * STEP + warm)     # 暖机:有 lastok 基线
    calls_before = up.calls["hist"]
    t_start = clock.t
    t_end = t_start + minutes * 60_000
    orig = up.game_history

    async def gated(aid, room):                     # 时窗内上游整体失败
        if t_start <= clock.t < t_end:
            up.calls["hist"] += 1
            return None
        return await orig(aid, room)
    up.game_history = gated
    await pump(w, clock, t_end + 20 * STEP)         # 断供 + 恢复余量
    up.game_history = orig
    await pump(w, clock, clock.t + 40 * STEP)       # 再走两页窗,深洞接力审计收尾

    head = max(db.rounds)
    hs = _holes(db, min(db.rounds), head - 2 * STEP)
    off = await _offmiss(w.bus, hs)
    unexplained = [g for g in hs if g not in off]
    stats = await w.bus.histmode_stats()
    lost = int(stats.get("window_lost", 0) or 0)
    snap = await w.bus.get_snapshot(ROOM)
    wm = int(snap.get("covWm") or 0)
    outage_calls = up.calls["hist"] - calls_before
    assert not unexplained, f"存在未解释的数据洞: {unexplained[:5]}"
    if minutes * 60 < 30 * STEP // 1000:            # 页窗(1500s)内断供
        assert not hs and lost == 0, (minutes, hs[:3], lost)
    else:                                           # 越窗:丢失必须登记且计数
        assert hs and lost >= len(hs) > 0, (minutes, len(hs), lost)
    assert head - wm <= (30 - 1) * STEP             # 水位照常推进(止损不卡死)
    return {"outage_min": minutes, "holes": len(hs), "all_offmiss": True,
            "window_lost": lost, "calls_in_outage≈": outage_calls}


async def h2() -> list:
    return [await _outage(10), await _outage(20), await _outage(30)]


# ── H4 双向有机迁移 ───────────────────────────────────────────────────────────
async def h4_enable_then_promote() -> dict:
    # 起点:模式关闭,发现房走实时管线
    w, up, db, clock, s = build_world(enabled=False)
    await w.bus.add_rooms_bulk([(ROOM, ROOM)])
    await _mark_discovered(w.bus, ROOM, clock.t)
    await w.bus.schedule(task_mainpage(ROOM), clock.t)
    await pump(w, clock, clock.t + 5 * STEP)        # 实时 5 局
    mp0, aw0, hs0 = up.calls["mp"], up.calls["aw"], up.calls["hist"]
    assert mp0 >= 5 and aw0 >= 4

    s.histmode.enabled = True                       # ── 开:下一拍 mp 原地改排 ──
    await pump(w, clock, clock.t + 24 * STEP)       # 20 分钟(≥ 首拍满窗 T+T/10)
    assert up.calls["mp"] == mp0                    # 迁移拍在 _handle_mainpage 之前
                                                    # 短路 —— 不打上游,mp 恒不再增
    assert up.calls["aw"] <= aw0 + 1                # 存量 aw 跑完,不再新增
    assert up.calls["hist"] > hs0                   # 轮询已接管
    holes = _holes(db, min(db.rounds), max(db.rounds))
    assert not holes, holes[:5]

    hist_before = up.calls["hist"]
    await w.bus.discovered_remove(ROOM)             # ── 转正(web add 语义:──
    await w.bus.schedule(task_mainpage(ROOM), clock.t)   #  mp@now 秒级起抓
    await w.bus.schedule(task_hist(ROOM), clock.t)       #  + hs@now 封尾窗)
    await pump(w, clock, clock.t + 6 * STEP)
    # 收尾回填恰 1 次;本房经历过实时管线(prev roundStartTimeMs 有值),转正
    # 首拍 mp 的「漏局」自愈会再补 1 发幂等 GameHistory(实证判据:worker
    # _handle_mainpage 以 roundStartTimeMs 为锚)。纯 hs 谱系(发现即轮询,
    # 生产常态)prev 为空 → 恰 1 次;两种谱系此处都必须收敛在 ≤2。
    assert hist_before + 1 <= up.calls["hist"] <= hist_before + 2, up.calls
    snap = await w.bus.get_snapshot(ROOM)
    assert snap.get("histLastOkMs") in ("0", 0)     # 封尾键已消费=封尾确实发生
    assert up.calls["mp"] > mp0 + 1                 # 实时管线恢复
    assert await w.bus.r.zcard(rb.K_HIST_LASTOK) == 0   # 健康项清净
    head = max(db.rounds)
    assert not _holes(db, min(db.rounds), head - 2 * STEP)   # 尾窗零洞
    return {"promote_hist_calls": up.calls["hist"] - hist_before,
            "lastok_clean": True, "holes": 0}


async def h4_rollback() -> dict:
    w, up, db, clock, s = await _boot_hist()
    await pump(w, clock, clock.t + 30 * STEP)       # 轮询稳态
    s.histmode.enabled = False                      # ── 关:回滚 ──
    hist_before = up.calls["hist"]
    # 转换点 = 既有稳态 hs 的到期时刻(最迟 ~T+T/10 后);先推进到转换完成:
    await pump(w, clock, clock.t + 8 * STEP)
    assert up.calls["hist"] == hist_before + 1      # 收尾回填恰一次
    assert await w.bus.r.zcard(rb.K_HIST_LASTOK) == 0
    snap = await w.bus.get_snapshot(ROOM)
    assert snap.get("histLastOkMs") in ("0", 0)     # 封尾键已消费
    mp_now = up.calls["mp"]                         # 转换后横断面
    await pump(w, clock, clock.t + 6 * STEP)        # 再走 ~5 局
    assert up.calls["mp"] - mp_now >= 4             # 实时管线逐拍接管
    assert not _holes(db, min(db.rounds), max(db.rounds) - 2 * STEP)
    return {"rollback_tailfill": 1,
            "mp_resumed_per_5rounds": up.calls["mp"] - mp_now, "holes": 0}


# ── H5 页内官方缺失 ───────────────────────────────────────────────────────────
async def h5() -> dict:
    w, up, db, clock, s = await _boot_hist()
    gap = T0 + 30 * STEP                            # 未来某局:官方跳过
    up.official_missing.add(gap)
    await pump(w, clock, T0 + 10 * STEP + 60 * STEP)
    assert gap not in db.rounds
    off = await _offmiss(w.bus, [gap])
    assert gap in off, "页内官方缺失未被登记"
    stats = await w.bus.histmode_stats()
    assert int(stats.get("window_lost", 0) or 0) == 0   # 官方缺 ≠ 越窗丢
    holes = [g for g in _holes(db, min(db.rounds), max(db.rounds)) if g != gap]
    assert not holes
    return {"offmiss_marked": True, "window_lost": 0, "holes_besides_gap": 0}


# ── H6 多副本同房 ─────────────────────────────────────────────────────────────
async def h6() -> dict:
    ws, up, db, clock, s = await _boot_hist(replicas=2)
    horizon = 120 * STEP
    await pump(ws, clock, T0 + 10 * STEP + horizon)
    t_ms = effective_hist_interval_ms(s.histmode)
    lo = int(horizon / (t_ms * 1.1))
    hi = int(horizon / t_ms) + 1
    assert lo <= up.calls["hist"] <= hi, ("双副本重复轮询?", up.calls, lo, hi)
    assert not _holes(db, min(db.rounds), max(db.rounds))
    return {"replicas": 2, "hist": up.calls["hist"],
            "expected": f"[{lo},{hi}]", "holes": 0}


# ── H7 默认周期 T=900 专项(3.5.0 默认改 900 后的边际实证) ─────────────────────
async def h7() -> dict:
    out = {}
    # a. 稳态账本:240 局窗口 ≈ 12–14 次轮询,零洞,水位零滞后
    w, up, db, clock, s = await _boot_hist(interval_s=900)
    await pump(w, clock, T0 + 10 * STEP + 240 * STEP)
    assert 12 <= up.calls["hist"] <= 14 and not _holes(db, min(db.rounds), max(db.rounds))
    snap = await w.bus.get_snapshot(ROOM)
    assert (max(db.rounds) - int(snap["covWm"])) // STEP == 0
    out["steady_hist"] = up.calls["hist"]
    # b. 首拍后连败 3 次(第 2 拍 ~945s 起):退避+前瞻投影贴抢救线走,零洞零丢
    w, up, db, clock, s = await _boot_hist(interval_s=900)
    up.hist_fail_calls = {2, 3, 4}
    await pump(w, clock, T0 + 10 * STEP + 120 * STEP)
    assert not _holes(db, min(db.rounds), max(db.rounds))
    assert int((await w.bus.histmode_stats()).get("window_lost", 0) or 0) == 0
    out["failchain"] = "0洞"
    # c. 断供三点:20min(1200s,贴页窗)恢复零洞;28min(1680s)越窗但全登记
    for minutes in (20, 28):
        w, up, db, clock, s = await _boot_hist(interval_s=900)
        await pump(w, clock, T0 + 10 * STEP + 40 * STEP)     # 泵停在成功轮询上(pinned)
        t0, t1 = clock.t, clock.t + minutes * 60_000
        orig = up.game_history
        async def gated(aid, room, _t0=t0, _t1=t1, _orig=orig):
            if _t0 <= clock.t < _t1:
                up.calls["hist"] += 1
                return None
            return await _orig(aid, room)
        up.game_history = gated
        await pump(w, clock, t1 + 20 * STEP)
        up.game_history = orig
        await pump(w, clock, clock.t + 40 * STEP)
        holes = _holes(db, min(db.rounds), max(db.rounds) - 2 * STEP)
        off = await _offmiss(w.bus, holes)
        lost = int((await w.bus.histmode_stats()).get("window_lost", 0) or 0)
        assert not [g for g in holes if g not in off]
        if minutes * 60 < 1500:
            assert not holes and lost == 0, (minutes, len(holes), lost)
            out[f"outage{minutes}m"] = "0洞"
        else:
            assert holes and lost >= len(holes) > 0
            out[f"outage{minutes}m"] = f"{len(holes)}洞全登记(lost={lost})"
    return out


SCENARIOS = {"H0": h0, "H1": h1, "H2": h2,
             "H4a": h4_enable_then_promote, "H4b": h4_rollback,
             "H5": h5, "H6": h6, "H7": h7}


async def main(argv=None) -> int:
    args = sys.argv[1:] if argv is None else list(argv)
    only = {a.upper() for a in args} or set(SCENARIOS)
    unknown = only - set(SCENARIOS)
    if unknown:                                    # pytest 参数误入等场景:显式拒绝,
        print(f"未知场景: {sorted(unknown)}")       # 绝不静默空跑装通过
        return 2
    print("hist-mode 状态机验证(真实 _handle_hist × 真实任务循环 × 虚拟钟)")
    print("─" * 78)
    failed = []
    for name, fn in SCENARIOS.items():
        if name not in only:
            continue
        try:
            out = await fn()
            print(f"{name:<4} ✅ {out}")
        except AssertionError as e:
            failed.append(name)
            print(f"{name:<4} ❌ {e}")
    print("─" * 78)
    if failed:
        print(f"未通过: {failed}")
        return 1
    print("全部场景通过:请求账本、零洞承诺、越窗止损、双向迁移、多副本互斥 —— 兑现。")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
