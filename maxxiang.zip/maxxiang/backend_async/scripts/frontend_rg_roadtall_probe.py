# -*- coding: utf-8 -*-
"""5.0.9 DIY「近24小时战况」窄屏加高至整屏 —— 可复跑量测探针(真 Chromium)。

与 5.0.8 探针(frontend_rg_road_probe.py)分工:那支继续钉「默认态压缩后的
溢出/折行/触屏纪律」,本支钉三件新事:

  ① 默认态锁值:十视口 avail 与 5.0.8 出厂值**逐整数一致**(基线首次入册锁死,
     防未来任何改动让默认视图悄悄漂移);加高钮桌面恒 display:none、
     窄屏 32px 高(WCAG 2.5.8);320 视口头部加钮后零横向溢出(标题省略规则生效)。
  ② 加高态(窄屏六景,真实珠量 1728):
     · fill 锁值 = clientHeight − padB − 战况头(offsetHeight+margin) 的出厂整数;
     · 行高 == fill(±0.6)、行底距滚动口底 == padB(±1)、外层贴末端、待开珠可见;
     · 粘性战况头钉住贴盒顶(≤0.5px)、顶衬条被头盖住(elementFromPoint 实证)、
       翻到最旧时首珠从头之下露出且头仍钉住 —— 两个滚动极端都成立;
     · 行数 ≥ 锁值下限(30/40/31/41/41/33),且严格多于默认态。
  ③ 桌面免疫:1024/1440 停靠列即使强走加高口(MEASURE_TALL),同构门(JF_DOCK_MQ
     反向)也把它退回常规 fit —— avail 仍等于 ① 的锁值、--rg-fill-padt 不落地。
     另作两条文本钉:app.js 必含 `RG.roadTall && !JF_DOCK_MQ.matches`(JS 侧门),
     app.css 的粘头规则必在 max-width:1023.98px 媒体门内且引用 --rg-fill-padt
     (padT 7/8 两档单一事实源:由 rgFitRoad 量得写入,任何地方不许另抄数字)。

跑法:python3 frontend_rg_roadtall_probe.py
依赖:pip install playwright && playwright install chromium
"""
import re, sys
from pathlib import Path

from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
URL = (HERE / "frontend_rg_road_fixture.html").as_uri()

appjs = (ROOT / "assets/app.js").read_text(encoding="utf-8")
appcss = (ROOT / "assets/app.css").read_text(encoding="utf-8")
m = re.search(r"bodyBottom - roadTop - (\d+)", appjs)
assert m, "app.js 里找不到 rgFitRoad 的留白表达式"
SLACK = int(m.group(1))

fails = []
# —— 文本钉(双保险的存在性,与 5.0.8 探针解析 slack 同法) ——
if "RG.roadTall && !JF_DOCK_MQ.matches" not in appjs:
    fails.append(("app.js", "加高分支缺 JF_DOCK_MQ 反向门"))
mcss = re.search(r"@media \(max-width:1023\.98px\)\{[^\0]*?\.rg-body \.rg-road\[data-fill\] \.rg-road-head\{[^}]*--rg-fill-padt", appcss)
if not mcss:
    fails.append(("app.css", "粘头规则不在窄屏媒体门内或未引用 --rg-fill-padt"))

# —— ① 默认态锁值(5.0.8 出厂 avail,整数,真 Chromium 同口径首测入册) ——
BASE = [
    (1024, 768, False, "D-1024×768(坞392·A档)", 204), (1280, 800, False, "D-1280×800(坞435·B档)", 245),
    (1440, 900, False, "D-1440×900(坞490·B档)", 345), (1920, 1080, False, "D-1920×1080(坞560·B档)", 525),
    (820, 1180, True, "T-820×1180(剧场·C档·触屏)", 573), (320, 568, True, "M-320×568(SE1)", -37),
    (360, 800, True, "M-360×800", 195), (375, 667, True, "M-375×667(SE2)", 62),
    (390, 844, True, "M-390×844", 266), (430, 932, True, "M-430×932", 345),
]
BTN_JS = """() => { const b = document.querySelector('.rg-road-tall');
  return { disp: b ? getComputedStyle(b).display : null,
           h: b ? +b.getBoundingClientRect().height.toFixed(1) : null }; }"""

# —— ② 加高态锁值(fill 整数 + 行数下限;窄屏六景) ——
TALL = [
    (320, 568, 456, 30), (360, 800, 688, 40), (375, 667, 555, 31),
    (390, 844, 759, 41), (430, 932, 847, 41), (820, 1180, 1093, 33),
]

out_base, out_tall = [], []
with sync_playwright() as p:
    b = p.chromium.launch()
    for w, h, touch, tag, want in BASE:
        ctx = b.new_context(viewport={"width": w, "height": h}, is_mobile=touch, has_touch=touch)
        pg = ctx.new_page(); pg.goto(URL, wait_until="networkidle")
        m0 = pg.evaluate(f"window.MEASURE({SLACK})"); btn = pg.evaluate(BTN_JS)
        out_base.append((tag, m0["avail"], btn["disp"], btn["h"], m0["ovf"]))
        if m0["avail"] != want: fails.append((tag, "默认态 avail 漂移", m0["avail"], "≠锁值", want))
        if any(v > 1 for v in m0["ovf"].values()): fails.append((tag, "默认态溢出", m0["ovf"]))
        if touch or w < 1024:
            if btn["disp"] not in ("flex", "inline-flex") or not btn["h"] or abs(btn["h"] - 32) > 0.5:   # flex 项被规范块化:inline-flex → flex
                fails.append((tag, "窄屏加高钮形制不符", btn))
        else:
            if btn["disp"] != "none": fails.append((tag, "桌面加高钮未隐", btn))
        ctx.close()

    for w, h, fill_want, rows_min in TALL:
        ctx = b.new_context(viewport={"width": w, "height": h}, is_mobile=True, has_touch=True)
        pg = ctx.new_page(); pg.goto(URL, wait_until="networkidle")
        t = pg.evaluate(f"window.MEASURE_TALL({SLACK})")
        st = pg.evaluate("""() => getComputedStyle(document.querySelector('.rg-road-head')).top""")
        out_tall.append((f"{w}×{h}", t, st))
        if t["mode"] != "tall": fails.append((w, "窄屏未进加高分支", t["mode"]))
        if t["fill"] != fill_want: fails.append((w, "fill 漂移", t["fill"], "≠锁值", fill_want))
        if abs(t["roadH"] - t["fill"]) > 0.6: fails.append((w, "行高≠fill", t["roadH"], t["fill"]))
        if abs(t["roadBottomGap"] - t["padB"]) > 1: fails.append((w, "行底未按 padB 收口", t["roadBottomGap"], t["padB"]))
        if t["headPinGap"] > 0.5: fails.append((w, "粘头未贴盒顶", t["headPinGap"]))
        if not t["stripCovered"]: fails.append((w, "顶衬条透珠(未被头盖住)",))
        if not t["outerAtEnd"]: fails.append((w, "外层未贴末端",))
        if not t["pendVisible"]: fails.append((w, "待开珠不可见",))
        if t["innerScrollable"] <= 0: fails.append((w, "内滚消失(内容未超 fill?)", t["innerScrollable"]))
        if t["rows"] is None or t["rows"] < rows_min: fails.append((w, "行数低于锁值下限", t["rows"], rows_min))
        if t["rows"] is not None and t["avail"] >= 88 and t["rows"] * t["pitch"] <= t["avail"]:
            fails.append((w, "加高未带来净增益", t["rows"], t["avail"]))
        if not t["oldestBelowHead"] or not t["oldestVisible"]: fails.append((w, "翻到最旧:首珠被头压住或不可见", t["oldestBelowHead"], t["oldestVisible"]))
        if t["headStillPinned"] > 0.5: fails.append((w, "翻到最旧:粘头脱钉", t["headStillPinned"]))
        if t["headOvf"] > 1 or t["bodyOvf"] > 1 or t["headWrapped"]: fails.append((w, "加高态头部溢出/折行", t["headOvf"], t["bodyOvf"], t["headWrapped"]))
        padt = t.get("padT") if isinstance(t, dict) else None
        # padT 单一事实源:计算后的 sticky top 必须等于 −padT(7/8 两档均由 JS 写入变量)
        exp_top = f"-{int(pg.evaluate('parseFloat(getComputedStyle(document.getElementById(\"realBody\")).paddingTop)'))}px"
        if st != exp_top: fails.append((w, "粘头 top ≠ −padT(变量未落地)", st, exp_top))
        ctx.close()

    # —— ③ 桌面免疫:停靠列强走加高口也必须退回常规 ——
    for w, h, tag, want in [(1024, 768, "D-1024", 204), (1440, 900, "D-1440", 345)]:
        pg = b.new_page(viewport={"width": w, "height": h}); pg.goto(URL, wait_until="networkidle")
        t = pg.evaluate(f"window.MEASURE_TALL({SLACK})")
        vv = pg.evaluate("""() => document.querySelector('.rg-road').style.getPropertyValue('--rg-fill-padt')""")
        if t["mode"] != "dock": fails.append((tag, "停靠列误进加高分支", t["mode"]))
        if t["avail"] != want: fails.append((tag, "停靠列 avail 漂移", t["avail"], want))
        if vv: fails.append((tag, "停靠列 --rg-fill-padt 不该落地", vv))
        if t["btnDisplay"] != "none": fails.append((tag, "停靠列加高钮未隐", t["btnDisplay"]))
        pg.close()
    b.close()

print(f"══ 战况加高量测(slack={SLACK})══")
print("① 默认态锁值 | scen | avail | 钮display | 钮高")
for tag, av, dp, bh, _ in out_base: print(f"  {tag} | {av} | {dp} | {bh}")
print("② 加高态 | 视口 | fill | 行数 | 行底距 | 粘头贴顶 | 顶衬盖住 | 最旧可读 | sticky-top")
for tag, t, st in out_tall:
    print(f"  {tag} | {t['fill']} | {t['rows']} | {t['roadBottomGap']} | {t['headPinGap']} | {t['stripCovered']} | {t['oldestBelowHead'] and t['oldestVisible']} | {st}")
print("断言:", "全部通过 ✓" if not fails else "FAIL → " + repr(fails))
sys.exit(0 if not fails else 1)
