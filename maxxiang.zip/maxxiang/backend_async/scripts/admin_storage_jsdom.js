/* admin_storage_jsdom.js —— 管理台「储」存储与保留视图(管理台 1.11.0 / 后端 5.4.0)整机冒烟
   交付版 admin.html + admin.js 在 jsdom 真 DOM 中跑通:
     ① 左栏第 12 枚印「储」,帮助里有对应条目;
     ② 告警分级(红 = 正在出事 / 黄 = 迟早出事)、容量卡片、两个库的全表清单;
        行数「约」= 估计值、「—」= 表不存在;上次清扫逐规则呈现,失败标红且原文挂 title;
     ③ 「立即清扫」:二次确认 → POST /storage/sweep(带 CSRF)→ 提示 → 以 fresh=1 重取;
     ④ 诚实失败:/storage 500 时写明「读取失败」,不伪装成空态;未启用登录系统时用户库区明说;
     ⑤ 总览首屏出现存储告警条,并能跳到「储」;
     ⑥ 后端回来的任何文本都按文本渲染(报错原文里的 HTML 不得变成元素)。
   用法:node admin_storage_jsdom.js [--js 混淆后的 admin.js] [--html 构建后的 admin.html]
                                    [--snap 真后端 /storage 的 JSON]
   源码全绿 ≠ 产物全绿:交付前请对 dist/ 再跑一遍(--js dist/assets/admin.js --html dist/admin.html)。
   依赖 jsdom(NODE_PATH;按项目纪律用 `npm i --no-save jsdom` 临时装,不进 package.json)。 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
const arg = n => { const i = process.argv.indexOf(n); return i > 0 ? process.argv[i + 1] : null; };
const html = fs.readFileSync(arg('--html') || ROOT + '/admin.html', 'utf8');
const adminjs = fs.readFileSync(arg('--js') || ROOT + '/assets/admin.js', 'utf8');

let PASS = 0, FAIL = 0;
const A = (n, c) => { console.log(`  [${c ? '✓' : '✗'}] ${n}`); if (c) PASS++; else { FAIL++; process.exitCode = 1; } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

const now = Date.now();
const row = (table, klass, klassLabel, rows, bytes, exact, extra) => Object.assign({
  table, klass, klassLabel, policy: '策略:' + table, bound: '有界:' + table, sweeper: 'web · 每 6 小时',
  knobs: [], present: rows !== undefined, rows: rows === undefined ? null : rows,
  bytes: rows === undefined ? null : bytes, exact: !!exact, oldest: null }, extra || {});
const FIX = {
  ok: true, now_ms: now, intervalS: 21600,
  effective: { 'retention.days': 7, 'retention.audit_days': 184, 'retention.state_gc': true,
               'userauth.log_retention_days': 184, 'userauth.reg_log_retention_days': 184,
               'userauth.log_max_rows': 5000000, 'userauth.jf_order_unpaid_retention_days': 184,
               'userauth.jf_card_disabled_age_days': 0, 'userauth.jf_card_used_retention_days': 0 },
  sweeps: { boot_ms: now - 3600e3, total_deleted: { pg: 12, mysql: 4300, redis: 37 }, running: [],
    worker: { at_ms: now - 300e3, elapsed_ms: 900, capped: false, errors: 0, deleted: 1290, interval_s: 3600, tasks: {
      'rounds:超过 7 天': { table: 'rounds', rule: '超过 7 天', deleted: 1234, capped: false, error: '', at_ms: now - 300e3 },
      'predictions:超过 7 天': { table: 'predictions', rule: '超过 7 天', deleted: 56, capped: false, error: '', at_ms: now - 300e3 } } },
    stores: {
    redis: { at_ms: now - 60e3, elapsed_ms: 12, deleted: 37, capped: false, errors: 0, tasks: {
      'snap:{room}:离场房快照回收': { table: 'snap:{room}', rule: '离场房快照回收', deleted: 37, capped: false, error: '', at_ms: now - 60e3 } } },
    pg: { at_ms: now - 120e3, elapsed_ms: 40, deleted: 12, capped: false, errors: 0, tasks: {
      'admin_audit:会话类超期': { table: 'admin_audit', rule: '会话类超期', deleted: 12, capped: false, error: '', at_ms: now - 120e3 },
      'predictor_state:离场房回收': { table: 'predictor_state', rule: '离场房回收', deleted: 0, capped: false, error: '', at_ms: now - 120e3 } } },
    mysql: { at_ms: now - 90e3, elapsed_ms: 20400, deleted: 4300, capped: true, errors: 1, tasks: {
      'guantai_login_log:超过 184 天': { table: 'guantai_login_log', rule: '超过 184 天', deleted: 4300, capped: true, error: '', at_ms: now - 90e3 },
      'guantai_login_log:行数上限': { table: 'guantai_login_log', rule: '行数上限', deleted: 0, capped: false, error: '', at_ms: now - 90e3 },
      'guantai_reg_log:超过 184 天': { table: 'guantai_reg_log', rule: '超过 184 天', deleted: 0, capped: false,
        error: 'OperationalError: (1205, "<b id=xss>Lock wait</b> timeout")', at_ms: now - 90e3 } } } } },
  pg: { db_bytes: 53687091200, error: '', unregistered: [], tables: [
    row('rounds', 'rolling', '滚动流水', 120960000, 33715322880, false),
    row('predictions', 'rolling', '滚动流水', 36288, 67108864, false),
    row('predictor_state', 'state', '状态表', 6, 57344, true),
    row('rooms', 'state', '状态表', 3, 16384, true),
    row('config_revisions', 'operator', '人工追加', 41, 180224, true),
    row('admin_audit', 'rolling', '滚动流水', 1830, 1048576, true) ] },
  mysql: { enabled: true, error: '', unregistered: [], tables: [
    row('guantai_login_log', 'rolling', '滚动流水', 4200000, 1125899264, false, { oldest: '2026-05-20T08:00:00' }),
    row('guantai_reg_log', 'rolling', '滚动流水', 812, 262144, false),
    row('guantai_jf_order', 'rolling', '滚动流水', 96, 114688, true),
    row('guantai_jf_grant_log', 'ledger', '账本', 57, 65536, true),
    row('guantai_jf_card', 'pool', '资源池', 500, 131072, true),
    row('guantai_user_block', 'operator', '人工追加') ] },
  redis: { used: 29360128, maxmemory: 1073741824, policy: 'noeviction', keys: 51234 },
  alerts: [
    { level: 'bad', text: 'guantai_login_log 已有约 4200000 行,达到行数上限 5000000 的 84% —— 多半正在被灌' },
    { level: 'bad', text: '用户库(MySQL) 上次清扫失败:guantai_reg_log(超过 184 天)—— OperationalError' },
    { level: 'warn', text: '表 mystery_tbl 没有登记生命周期策略' } ],
};
const SNAP = arg('--snap') ? JSON.parse(fs.readFileSync(arg('--snap'), 'utf8')) : null;
const NET = { calls: [], sweep: null, sweepHdr: null, down: false, disabled: false, running: false, snap: FIX };
function route(url, opt) {
  const m = (opt && opt.method) || 'GET';
  NET.calls.push(m + ' ' + url);
  if (url.endsWith('/login')) return { ok: true, token: 'tok', csrf: 'csrf-9', version: '1.11.0' };
  if (url.includes('/storage/sweep')) {
    NET.sweep = opt.body; NET.sweepHdr = (opt.headers || {})['X-Admin-CSRF'];
    return NET.running ? { ok: true, running: true }
      : { ok: true, running: false, result: { pg: { deleted: 12, errors: 0, capped: false },
                                              mysql: { deleted: 4300, errors: 0, capped: false },
                                              redis: { deleted: 37, errors: 0, capped: false } } };
  }
  if (url.includes('/storage')) {
    if (NET.down) return { __status: 500, ok: false, error: 'boom', hint: 'pg pool closed' };
    return NET.disabled ? Object.assign({}, NET.snap, { alerts: [],
      mysql: { enabled: false, error: '', unregistered: [], tables: NET.snap.mysql.tables.map(t => Object.assign({}, t, { present: false, rows: null, bytes: null })) } })
      : NET.snap;
  }
  if (url.includes('/overview')) return { ok: true, now_ms: now, rooms: { manual: 3, discovered: 9, active_total: 12 },
    pending: 0, queue_depth: 5, storage_alerts: [{ level: 'bad', text: '用户库(MySQL) guantai_login_log:触及行数上限 5000000(疑似被灌),本轮裁掉 900 行' },
                                                 { level: 'warn', text: '出怪 / 预测历史被设为永久保留' }] };
  if (url.includes('/fleet')) return { ok: true, target_rev: 1, instances: [], converged: false };
  if (url.includes('/state') || url.includes('/effective')) return { ok: true, rev: 1, settings: {}, effective: {} };
  return { ok: true };
}

(async () => {
  console.log('管理台「储」存储与保留视图(1.11.0)整机冒烟 —— 交付版 admin.html + admin.js @ jsdom\n');
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => { if (!/Not implemented/.test(e.message)) console.log('  · jsdomError:', e.message.slice(0, 120)); });
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true, url: 'http://localhost/', virtualConsole: vc });
  const w = dom.window;
  const jsErrs = [];
  w.addEventListener('error', e => jsErrs.push(e.message || String(e.error)));
  w.addEventListener('unhandledrejection', e => jsErrs.push('unhandledrejection: ' + String(e.reason && e.reason.message || e.reason)));
  w.fetch = async (input, opt = {}) => {
    const url = typeof input === 'string' ? input : input.url;
    const b = route(url, opt);
    const status = b.__status || 200;
    return { ok: status < 400, status, headers: { get: () => null }, json: async () => b, text: async () => JSON.stringify(b) };
  };
  w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){} };
  w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
  w.matchMedia = q => ({ matches: false, media: q, addEventListener(){}, removeEventListener(){}, addListener(){}, removeListener(){} });
  w.scrollTo = () => {};
  w.HTMLElement.prototype.scrollIntoView = function () {};
  const _ls = {};
  Object.defineProperty(w, 'localStorage', { value: {
    getItem: k => (k in _ls ? _ls[k] : null), setItem: (k, v) => { _ls[k] = String(v); },
    removeItem: k => { delete _ls[k]; }, clear: () => { for (const k in _ls) delete _ls[k]; } }, configurable: true });
  const sc = w.document.createElement('script');
  sc.textContent = adminjs;
  w.document.body.appendChild(sc);
  await sleep(150);

  const $ = s => w.document.querySelector(s);
  const $$ = s => [...w.document.querySelectorAll(s)];
  const click = el => el && el.dispatchEvent(new w.Event('click', { bubbles: true }));
  const txt = s => ($(s) ? $(s).textContent : '');

  $('#pw').value = 'x';
  click($('#loginBtn'));
  await sleep(250);
  A('管理台登录后进入 shell', $('#shell').classList.contains('on'));
  const navs = $$('.nav-item');
  A('左栏共 12 枚印,含「储」且排在「署」之前', navs.length === 12
    && navs.findIndex(b => b.dataset.view === 'storage') === navs.findIndex(b => b.dataset.view === 'deploy') - 1
    && /储/.test(navs.find(b => b.dataset.view === 'storage').textContent));
  A('帮助里有「存储与保留」条目与十二枚印', /存储与保留\(「储」\)/.test($('#help').textContent) && /十二枚印/.test($('#help').textContent));
  click(navs.find(b => b.dataset.view === 'overview'));      // 显式进总览(本桩的 /schema 是空壳,不依赖开机默认视图)
  await sleep(300);
  A('总览首屏出现存储告警(红 + 黄)并能跳到「储」', $$('#main .err-line').some(e => /行数上限/.test(e.textContent))
    && $$('#main .warn-line').some(e => /永久保留/.test(e.textContent)) && !!$('#main a[href="#/storage"]'));

  click(navs.find(b => b.dataset.view === 'storage'));
  await sleep(300);
  A('视图标题与面包屑', /存储与保留/.test(txt('#main .view-title')) && /存储与保留/.test(txt('#crumb')));
  A('告警分级:2 红 1 黄', $$('#stBody > .err-line').length === 2 && $$('#stBody > .warn-line').length === 1 && !$('#stBody .st-ok'));
  const kp = $$('#stBody .kpi').map(k => k.textContent);
  A('容量卡片:观测库 50.0 GB / 用户库合计 / Redis 28.0 MB / 1.0 GB', kp.some(t => /50\.0 GB/.test(t))
    && kp.some(t => /1\.0 GB/.test(t) && /28\.0 MB/.test(t)) && kp.some(t => /用户库/.test(t) && /GB/.test(t)));
  A('Redis 离场房快照:上次回收时间与数量', kp.some(t => /Redis 离场房快照/.test(t) && /−37/.test(t)));
  const tbls = $$('#stBody table.st-tbl');
  A('两张清单:观测库 6 行 / 用户库 6 行(行数由后端登记决定)', tbls.length === 2
    && tbls[0].querySelectorAll('tr').length === 7 && tbls[1].querySelectorAll('tr').length === 7);
  const cell = (t, name, i) => { const tr = [...t.querySelectorAll('tr')].find(r => r.cells[0] && r.cells[0].textContent === name); return tr ? tr.cells[i] : null; };
  A('估计值带「约」并千分位;精确值不带', cell(tbls[0], 'rounds', 2).textContent === '约 120,960,000' && cell(tbls[0], 'rooms', 2).textContent === '3');
  A('占用按单位折算', cell(tbls[0], 'rounds', 3).textContent === '31.4 GB' && cell(tbls[1], 'guantai_login_log', 3).textContent === '1.0 GB');
  A('不存在的表显示「—」', cell(tbls[1], 'guantai_user_block', 2).textContent === '—' && cell(tbls[1], 'guantai_user_block', 3).textContent === '—');
  A('类别徽标带 data-k(账本 / 资源池 / 滚动流水各自着色)', cell(tbls[1], 'guantai_jf_grant_log', 1).querySelector('.st-k[data-k="ledger"]')
    && cell(tbls[1], 'guantai_jf_card', 1).querySelector('.st-k[data-k="pool"]') && cell(tbls[0], 'rounds', 1).querySelector('.st-k[data-k="rolling"]'));
  A('策略 + 有界依据 + 最旧一行', /策略:guantai_login_log/.test(cell(tbls[1], 'guantai_login_log', 4).textContent)
    && /有界依据:有界:guantai_login_log/.test(cell(tbls[1], 'guantai_login_log', 4).textContent) && /最旧一行 2026-05-20 08:00:00/.test(cell(tbls[1], 'guantai_login_log', 4).textContent));
  const last = cell(tbls[1], 'guantai_login_log', 6).textContent;
  A('上次清扫逐规则:删了多少 / 未清完 / 无可清', /超过 184 天:−4,300\(未清完,续扫中\)/.test(last) && /行数上限:无可清/.test(last));
  const bad = cell(tbls[1], 'guantai_reg_log', 6).querySelector('.bad');
  A('清扫失败标红,报错原文挂 title', !!bad && /失败/.test(bad.textContent) && /1205/.test(bad.getAttribute('title')));
  A('报错原文里的 HTML 不变成元素(转义)', !w.document.getElementById('xss'));
  A('没清扫过的表显示「—」', cell(tbls[0], 'config_revisions', 6).textContent === '—');
  A('worker 侧大表:rounds 行显示上次清理', /超过 7 天:−1,234/.test(cell(tbls[0], 'rounds', 6).textContent)
    && /超过 7 天:−56/.test(cell(tbls[0], 'predictions', 6).textContent));
  A('KPI:出怪/预测历史(worker)上次清理', kp.some(t => /出怪\/预测历史/.test(t)));
  A('当前生效一行写明三项只读、需改服务器 .env', /管理台只读/.test(txt('#stBody .st-eff')) && /\.env/.test(txt('#stBody .st-eff')));
  A('当前生效参数一行:184 天 / 5,000,000 / 回收 开', /登录流水 184 天/.test(txt('#stBody .st-eff')) && /5,000,000/.test(txt('#stBody .st-eff')) && /离场房回收 开/.test(txt('#stBody .st-eff')));

  // ③ 立即清扫
  const before = NET.calls.length;
  click($('#stSweep'));
  await sleep(60);
  A('点「立即清扫」先弹二次确认(未确认前不发请求)', $('#ask').classList.contains('open') && !NET.calls.slice(before).some(c => /sweep/.test(c)) && /不可恢复/.test(txt('#askB')));
  click($('#askNo'));
  await sleep(60);
  A('取消 → 不发请求', !NET.calls.slice(before).some(c => /sweep/.test(c)));
  click($('#stSweep'));
  await sleep(60);
  click($('#askYes'));
  await sleep(350);
  A('确认 → POST /storage/sweep,带 CSRF 头', NET.calls.some(c => c === 'POST /api/admin/storage/sweep') && NET.sweepHdr === 'csrf-9');
  A('完成提示:三个存储合计共删除 4,349 条', /共删除 4,349 条/.test(txt('#toast')));
  A('随后以 fresh=1 重取体检', NET.calls.slice(before).some(c => /GET .*\/storage\?fresh=1/.test(c)));
  NET.running = true;
  click($('#stSweep')); await sleep(60); click($('#askYes')); await sleep(350);
  A('积压大时后端转后台 → 如实提示「已转入后台」', /转入后台/.test(txt('#toast')));
  NET.running = false;

  // ④ 诚实失败与未启用
  NET.down = true;
  click($('#stRefresh')); await sleep(300);
  A('/storage 500:写明「读取失败」并带后端 hint,不伪装成空态', /存储体检读取失败/.test(txt('#stBody')) && /pg pool closed/.test(txt('#stBody')) && !$('#stBody table'));
  NET.down = false; NET.disabled = true;
  click(navs.find(b => b.dataset.view === 'overview')); await sleep(200);
  click(navs.find(b => b.dataset.view === 'storage')); await sleep(300);
  A('未启用登录系统:用户库区明说、无告警时给出「全部登记」的平静提示', /未启用登录系统/.test(txt('#stBody')) && !!$('#stBody .st-ok') && $$('#stBody table.st-tbl').length === 1);
  NET.disabled = false;

  // 真后端快照(可选):同一份前端代码吃真数据
  if (SNAP) {
    NET.snap = SNAP;
    click($('#stRefresh')); await sleep(300);
    const t2 = $$('#stBody table.st-tbl');
    const names = [...t2].flatMap(t => [...t.querySelectorAll('td.st-name')].map(td => td.textContent));
    A(`真后端快照:${SNAP.pg.tables.length} + ${SNAP.mysql.tables.length} 张表全部渲染`, names.length === SNAP.pg.tables.length + (SNAP.mysql.enabled ? SNAP.mysql.tables.length : 0)
      && SNAP.pg.tables.every(t => names.includes(t.table)));
    A('真后端快照:无 undefined / NaN / [object Object]', !/undefined|NaN|\[object Object\]/.test(txt('#stBody')));
  }
  A('全程零未捕获异常', jsErrs.length === 0);
  if (jsErrs.length) console.log('   ', jsErrs.slice(0, 3));

  console.log(`\n合计:${PASS} 通过 / ${FAIL} 失败`);
  process.exit(FAIL ? 1 : 0);
})().catch(e => { console.error('冒烟异常:', e); process.exit(1); });
