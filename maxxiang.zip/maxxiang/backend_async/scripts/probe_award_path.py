#!/usr/bin/env python3
"""probe_award_path.py — 「回填占比 / RoundAward 主路健康」判定探针(只读,零改动)

回答三个问题(对应 AUDIT §18 对「92.6% 靠回填」推断链的复核):
  A. 稳态下,多大比例的局是靠 GameHistory 先落库的?其中多少是"晚兜底"、
     多少是 3.4.1 早探的"准点救起"、多少是漏局/重启补录?
  B. 「大多数房的主路是失败的」是否成立?(房级:窗内 ≥3 局却 0 局走 award 的房)
  C. stats:ingest 的 legacy rate(单副本口径)与 PG 全舰队真值差几倍?
     (= 副本数;这正是把 7.4% 误读出来的失真源)

原理:rounds 表天然带地面真值 —— source 列记录**哪条路先落的这一行**
(ON CONFLICT DO NOTHING),created_at 记录入库时刻;二者组合可把每一局
无歧义地归类,无需任何间接推算。本探针在真值已知的受控实验中标定过:
注入 40% 死奖房 → 量得 39.6%,按房类纯度 3/3 全 100%(见 AUDIT §18)。

用法(通常经 probe_award_path.sh 从宿主机喂进容器):
  python probe_award_path.py [窗口分钟=30] [稳态门槛分钟=30] [尾部回缩秒=90]
  · 窗口:统计 round_id 落在 (now-窗口-回缩, now-回缩] 的局
  · 稳态门槛:排除"该房首条入库后 N 分钟内起跑的局"(冷启动首见回填不算兜底)
  · 尾部回缩:最迟的合法路径(终拍 ≈ 局内 78s)也已定局才计入,防骑线误判
"""
import asyncio
import json
import os
import statistics
import sys

import asyncpg

try:
    import redis.asyncio as aioredis
except Exception:  # pragma: no cover
    aioredis = None

WIN_MIN = float(sys.argv[1]) if len(sys.argv) > 1 else 30.0
STEADY_MIN = float(sys.argv[2]) if len(sys.argv) > 2 else 30.0
TAIL_S = float(sys.argv[3]) if len(sys.argv) > 3 else 90.0

PG = os.environ.get("STA_PG_DSN", "postgresql://star:star@localhost:5432/spelltamer")
RD = os.environ.get("STA_REDIS_URL", "redis://localhost:6379/0")

# 机制分桶边界(局内秒;由代码路径与真机标定推得,见 AUDIT §18 表):
#   award 主路      ≈ 37–45s(备战+2.3 起的阶梯早段)
#   history <45s    = 3.4.1 早探救起 —— 主路空了 3 拍,但数据**准点**到手
#   history 45–90s  = 阶梯末升级 / 终拍兜底 —— 主路整段失败,数据**晚** 12–38s
#   history >90s    = 漏局补齐 / 重启回填 —— 与上游 award 健康与否无关
B_EARLY, B_LATE = 45_000, 90_000


def _pct(v, q):
    if not v:
        return float("nan")
    v = sorted(v)
    i = max(0, min(len(v) - 1, int(round(q * (len(v) - 1)))))
    return v[i]


async def main():
    con = await asyncpg.connect(PG)
    ok = await con.fetchval(
        "SELECT count(*) FROM information_schema.columns WHERE table_name='rounds'"
        " AND column_name IN ('source','created_at')")
    if ok < 2:
        print("✗ rounds 表缺 source/created_at 列(库早于本代码基建表)——"
              "无法做地面真值分类;请先滚动重建或忽略本探针。")
        await con.close()
        return

    skew = 0
    st = {}
    hist_rooms: set = set()          # hist-mode(3.5.0)下的发现房:100% history
    hist_on = False                  # 是设计而非「主路失败」,份额/判定须单列
    if aioredis is not None:
        try:
            r = aioredis.from_url(RD, decode_responses=True)
            st = await r.hgetall("stats:ingest") or {}
            skew = int(st.get("clock_skew_ms") or 0)
            hist_rooms = set(await r.hkeys("rooms:discovered") or [])
            # curated-idle(3.7.0):冷策展房同为轮询节奏 —— 不并入会把它们的
            # 100% history 占比误读成「主路失败」(与发现房同一 §18 误判形状)。
            hist_rooms |= set(await r.hkeys("rooms:cold") or [])
            hm = await r.hgetall("stats:histmode") or {}
            hist_on = bool(int(st.get("hist_rooms") or 0)) or bool(hm)
            await r.aclose()
        except Exception:
            pass

    win_ms = int(WIN_MIN * 60_000)
    tail_ms = int(TAIL_S * 1000)
    rows = await con.fetch(
        """
        WITH nowms AS (SELECT (extract(epoch FROM now())*1000)::bigint v),
        frst AS (SELECT room_id, min(created_at) fs FROM rounds GROUP BY room_id)
        SELECT r.room_id, r.source,
               (extract(epoch FROM r.created_at)*1000 - r.round_id + $3)::bigint lat
        FROM rounds r JOIN frst f USING(room_id), nowms
        WHERE r.round_id >  nowms.v - $1 - $2
          AND r.round_id <= nowms.v - $2
          AND to_timestamp(r.round_id/1000.0) > f.fs + ($4 * interval '1 minute')
        """, win_ms, tail_ms, skew, STEADY_MIN)

    hist_mode_rows = [x for x in rows if hist_on and x["room_id"] in hist_rooms]
    if hist_mode_rows:
        # hist-mode 房按设计只走 GameHistory(整页轮询),它们的 history 占比是
        # 模式本身而非主路健康信号 —— 从 A/B 口径中摘出单列,防把 3.4.x 时代
        # 「92.6% 靠回填」式的误读在新模式下复活(AUDIT §18/§20)。
        rows = [x for x in rows if x["room_id"] not in hist_rooms]
    n = len(rows)
    print(f"════ A. 稳态份额与机制分桶 ════  窗口 {WIN_MIN:g}min(尾缩 {TAIL_S:g}s)"
          f"· 稳态门槛 {STEADY_MIN:g}min · 钟偏校正 {skew}ms · 共 {n} 局")
    if hist_mode_rows:
        print(f"  (另有 hist-mode 轮询房 {len({x['room_id'] for x in hist_mode_rows})} 房"
              f" / {len(hist_mode_rows)} 局按设计 100% history,已单列,不入下表)")
    if not n:
        print("  (窗内无稳态局 —— 系统刚启动/窗口太小?)")
    else:
        aw = [x["lat"] for x in rows if x["source"] == "award"]
        hi = [x["lat"] for x in rows if x["source"] == "history"]
        early = [x for x in hi if x < B_EARLY]
        late = [x for x in hi if B_EARLY <= x < B_LATE]
        fill = [x for x in hi if x >= B_LATE]
        f = 100.0 / n
        print(f"  award   主路先落 : {len(aw):6d}({len(aw)*f:5.1f}%)"
              f"  p50={_pct(aw,.5)/1e3:6.1f}s  p95={_pct(aw,.95)/1e3:6.1f}s")
        print(f"  history 先落合计 : {len(hi):6d}({len(hi)*f:5.1f}%)")
        print(f"    ├ 早探准点救起(<{B_EARLY//1000}s)    : {len(early):6d}"
              f"({len(early)*f:5.1f}%)  p50={_pct(early,.5)/1e3:6.1f}s"
              f"   ← 主路慢/空,但数据不晚")
        print(f"    ├ 阶梯末·终拍晚兜底({B_EARLY//1000}–{B_LATE//1000}s): "
              f"{len(late):6d}({len(late)*f:5.1f}%)  p50={_pct(late,.5)/1e3:6.1f}s"
              f"   ← 真正的「主路失败、数据晚」")
        print(f"    └ 漏局/重启补录(≥{B_LATE//1000}s)     : {len(fill):6d}"
              f"({len(fill)*f:5.1f}%)  p50={_pct(fill,.5)/1e3:6.1f}s"
              f"   ← 与上游 award 健康无关")

        by_room = {}
        for x in rows:
            a, t, lats = by_room.get(x["room_id"], (0, 0, []))
            lats.append(x["lat"])
            by_room[x["room_id"]] = (a + (x["source"] == "award"), t + 1, lats)
        judged = {k: v for k, v in by_room.items() if v[1] >= 3}
        dead = {k: v for k, v in judged.items() if v[0] == 0}
        print(f"\n════ B. 房级判定(窗内 ≥3 局的 {len(judged)} 房"
              f"{';已排除 hist-mode 轮询房' if hist_mode_rows else ''})════")
        if judged:
            print(f"  主路全败房(0 局走 award): {len(dead)} / {len(judged)}"
                  f" = {100.0*len(dead)/len(judged):5.1f}%"
                  f"   → 「大多数房主路失败」{'成立' if len(dead) > len(judged)/2 else '不成立'}")
            for k, (a, t, lats) in sorted(dead.items())[:8]:
                med = statistics.median(lats) / 1e3
                kind = ("早探救起·数据准点" if med < B_EARLY / 1e3 else
                        "晚兜底·数据晚" if med < B_LATE / 1e3 else "补录为主")
                print(f"    · room={k:<10} {t} 局全 history,lat_p50={med:6.1f}s ({kind})")

    q = await con.fetchrow(
        "SELECT count(*) FILTER (WHERE source='award') aw, count(*) tot,"
        "       count(DISTINCT room_id) FILTER (WHERE round_id >"
        "         (extract(epoch FROM now())*1000)::bigint - 150000) live"
        " FROM rounds WHERE created_at > now() - interval '300 seconds'")
    await con.close()

    print(f"\n════ C. 口径对账(近 5 分钟,PG 真值)════")
    fleet_aw, fleet_tot = q["aw"] / 300.0, q["tot"] / 300.0
    print(f"  全舰队 award 主路入库率 : {fleet_aw:7.2f} 局/s")
    print(f"  全舰队 总入库率(含回填): {fleet_tot:7.2f} 局/s")
    print(f"  近 150s 有局的房(理论 ÷50s): {q['live']} 房 → {q['live']/50.001:7.2f} 局/s")
    if st:
        legacy = float(st.get("rate") or 0)
        print(f"  stats:ingest legacy rate : {legacy:7.2f} 局/s  ← 单副本口径!")
        if legacy > 0:
            print(f"    失真倍数(全舰队÷legacy)≈ {fleet_aw/legacy:4.1f}×  ≈ 副本数")
        if "fleet_rate" in st:
            print(f"  stats:ingest fleet_rate  : {float(st['fleet_rate']):7.2f} 局/s"
                  f"({st.get('replicas_reporting','?')} 副本上报,3.4.7 全舰队口径)")
        else:
            print("  (无 fleet_rate 字段 → 镜像早于 3.4.7;--build 重建后自带全舰队口径)")


if __name__ == "__main__":
    asyncio.run(main())
