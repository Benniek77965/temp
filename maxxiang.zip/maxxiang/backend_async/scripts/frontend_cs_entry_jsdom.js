/* frontend_cs_entry_jsdom.js — 客服渠道(4.9.8)整机冒烟
   用法:项目根 `npm i jsdom` 后 `node backend_async/scripts/frontend_cs_entry_jsdom.js`

   4.9.8 在首页新增顶栏「客服」入口 + 「联系客服」弹层(#csOpen / #csModal),
   数据与渲染全部复用 4.4.2 的 CS 管线(csLand / csOn / csAppendTo)。本脚本
   与 frontend_jfvip_jsdom.js 同款做法:交付版 index.html + app.js 在真 DOM 里
   原样执行,只桩网络。钉住的行为:

     · 配置了联系方式(直营主站形态)⇒ 入口现身;点击开层;层内渠道名/号码/
       复制按钮/白名单链接/备注逐项在场;重复开合**不叠行**(幂等重建);
       [data-close] 与 Esc 两条关闭路径都走 closeModal
     · 未启用登录系统(enabled:false 早返回)但带 contact ⇒ 入口同样现身
       (4.4.2 明言这条路上客服照发,漏掉就是「某些部署下客服栏莫名不出现」)
     · 未下发 contact ⇒ 入口保持 hidden(不摆死控件),openCsModal 被硬闸挡住
     · 注入面:恶意 label/value 原样落在文本里,层内不得出现被注入的元素
     · 全程零未捕获异常
*/
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
/* --js / --html:指向混淆产物做验收(与 frontend_jfvip_jsdom.js 同款约定,
   含同一道「产物比源码旧 = 构建没成功,拒跑」护栏)。缺省读仓库源码。 */
const _ARGJ = process.argv.indexOf('--js');
const _ARGH = process.argv.indexOf('--html');
const html = fs.readFileSync(_ARGH > 0 ? process.argv[_ARGH + 1] : ROOT + '/index.html', 'utf8');
const _jsPath = _ARGJ > 0 ? process.argv[_ARGJ + 1] : ROOT + '/assets/app.js';
if (_ARGJ > 0) {
  const tp = fs.statSync(_jsPath).mtimeMs;
  const ts = fs.statSync(ROOT + '/assets/app.js').mtimeMs;
  if (tp < ts) {
    console.error(`✗ 产物 ${_jsPath} 比 assets/app.js 旧(${Math.round((ts - tp) / 1000)}s)—— 构建未成功或未重跑。`);
    process.exit(3);
  }
}
const appjs = fs.readFileSync(_jsPath, 'utf8');

let PASS = 0, FAIL = 0;
const A = (n, c, extra) => {
  console.log(`  [${c ? '✓' : '✗'}] ${n}${c ? '' : (extra ? '  → ' + extra : '')}`);
  if (c) PASS++; else { FAIL++; process.exitCode = 1; }
};
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* 起一个环境。session = /api/auth/session 的完整回包(本探针要覆盖
   enabled:false 早返回那条路,故整包由用例给,不在这里拼) */
async function boot(session) {
  const errs = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => errs.push(String(e && e.message || e)));
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
                                url: 'http://localhost/', virtualConsole: vc });
  const w = dom.window;
  w.fetch = async (input) => {
    const url = typeof input === 'string' ? input : input.url;
    let body;
    if (url.startsWith('/api/auth/session')) body = session;
    else if (url.startsWith('/api/live-rooms')) body = { ok: true, rooms: [] };
    else body = { ok: true };
    return { ok: true, status: 200, headers: { get: () => null },
             json: async () => body, text: async () => JSON.stringify(body) };
  };
  w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){} };
  w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
  w.PerformanceObserver = class { observe(){} disconnect(){} };
  w.matchMedia = q => ({ matches: false, media: q, addEventListener(){}, removeEventListener(){},
                         addListener(){}, removeListener(){} });
  w.scrollTo = () => {};
  w.Worker = class { postMessage(){} terminate(){} };
  w.navigator.sendBeacon = () => true;
  w.addEventListener('error', e => errs.push('window.error: ' + (e.message || '')));
  w.addEventListener('unhandledrejection', e => errs.push('unhandled: ' + (e.reason || '')));

  const sc = w.document.createElement('script');
  sc.textContent = appjs.replace(/^\s*export\s+/gm, '');
  w.document.body.appendChild(sc);
  await sleep(260);
  return { w, d: w.document, errs };
}

const CONTACT = { label: '客服QQ', value: '800123456',
                  url: 'https://kf.example.com/chat', note: '服务时间 09:00–24:00' };
const SESSION_ON = c => ({ ok: true, enabled: true, authed: true, pow: { enabled: false },
  user: { id: 7, userName: 'u7', dueTime: '2027-01-01T00:00:00', dueDays: 165, tier: 'vip' },
  jf: { enabled: true, tier: 'vip', plans: [], matrix: [] },
  ...(c ? { contact: c } : {}) });

(async () => {
  console.log('\n客服渠道(4.9.8)前端整机冒烟(真 DOM 执行)\n' + '─'.repeat(58));

  // ── 配置了联系方式:入口 → 弹层 → 内容 → 幂等 → 两条关闭路径 ─────────────
  {
    const { w, d, errs } = await boot(SESSION_ON(CONTACT));
    console.log('\n[已配置联系方式 · 登录态]');
    const btn = d.getElementById('csOpen');
    A('顶栏入口现身', !!btn && btn.hidden === false, btn ? 'hidden=' + btn.hidden : '元素缺失');
    A('入口可及名称恒为全称', btn && btn.getAttribute('aria-label') === '联系客服');
    const modal = d.getElementById('csModal');
    A('弹层初始隐藏', !!modal && modal.hidden === true);
    btn.click();
    A('点击入口即开层', modal.hidden === false);
    const body = d.getElementById('csBody');
    A('渠道名出场', !!body.querySelector('.vip-cs-label')
      && body.querySelector('.vip-cs-label').textContent === '客服QQ');
    A('号码出场', !!body.querySelector('.vip-cs-value')
      && body.querySelector('.vip-cs-value').textContent === '800123456');
    const copy = body.querySelector('.vip-cs-copy');
    A('复制按钮是真 <button> 且 type=button', !!copy && copy.tagName === 'BUTTON'
      && copy.type === 'button');
    A('复制按钮可及名称自带上下文', !!copy && /客服QQ/.test(copy.getAttribute('aria-label') || '')
      && /800123456/.test(copy.getAttribute('aria-label') || ''));
    const a = body.querySelector('.vip-cs-link');
    A('白名单链接渲染成 <a> 且带 noopener', !!a && a.getAttribute('href') === CONTACT.url
      && /noopener/.test(a.rel));
    A('备注出场', !!body.querySelector('.vip-cs-note')
      && /09:00–24:00/.test(body.querySelector('.vip-cs-note').textContent));
    A('开层落焦点在复制按钮(openModal 回落链)', d.activeElement === copy,
      '实际:' + (d.activeElement && (d.activeElement.id || d.activeElement.className)));
    // 幂等:关(data-close)→ 再开 → 行数仍是 1
    modal.querySelector('[data-close]').click();
    A('点「×」([data-close])即关层', modal.hidden === true);
    btn.click(); btn.click();   // 连开两次(第二次对已开层是重入)
    A('重复开合不叠行(幂等重建)', body.querySelectorAll('.vip-cs-line').length === 1,
      '实际 ' + body.querySelectorAll('.vip-cs-line').length + ' 行');
    /* Esc 关闭:走文档级 keydown 的 .modal **逐层**关闭分支。
       ★ 5.0.5 订正(实测定案):原写「按一次 Esc 即关 csModal」,那是 5.0.2「空名录
         自动弹 #addRoomModal 引导层」**引入之前**的期望 —— 跑到这里时 csModal 之上
         还压着那一层,而 Esc 的分支是 `$$('.modal').find(l => !l.hidden)`,按文档序
         取最上层,第 1 次关 addRoomModal、第 2 次才轮到 csModal。逐层关闭是设计行为,
         不是缺陷;假红的是断言。
         现改为钉住**逐层语义本身**:按当前可见层数依次按 Esc,必须全部关净且 csModal
         在其中。将来引导层增减都不会再让这条假红,而「Esc 只关一层、不越级」这个
         真正的契约反而被钉住了(层数不足则关不净,当场红)。 */
    const visibleModals = () => [...d.querySelectorAll('.modal')].filter(l => !l.hidden);
    const layers = visibleModals().length;
    A('Esc 前 csModal 在可见层内', visibleModals().includes(modal),
      '可见层:' + visibleModals().map(l => l.id).join(','));
    for (let i = 0; i < layers; i++)
      d.dispatchEvent(new (d.defaultView.KeyboardEvent)('keydown', { key: 'Escape', bubbles: true }));
    A('Esc 逐层关闭:' + layers + ' 次按键把 ' + layers + ' 层全部关净(含 csModal)',
      modal.hidden === true && visibleModals().length === 0,
      '剩余:' + visibleModals().map(l => l.id).join(','));
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }

  // ── 未启用登录系统(enabled:false 早返回)但带 contact ────────────────────
  {
    const { w, d, errs } = await boot({ ok: true, enabled: false, authed: false, contact: CONTACT });
    console.log('\n[未启用登录系统 · 带 contact(4.4.2 那条早返回路)]');
    const btn = d.getElementById('csOpen');
    A('入口同样现身', !!btn && btn.hidden === false, btn ? 'hidden=' + btn.hidden : '元素缺失');
    btn.click();
    A('开层且号码在场', d.getElementById('csModal').hidden === false
      && !!d.querySelector('#csBody .vip-cs-value'));
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }

  // ── 未下发 contact:入口恒隐藏,硬闸挡住开层 ─────────────────────────────
  {
    const { w, d, errs } = await boot(SESSION_ON(null));
    console.log('\n[未下发 contact · 不摆死控件]');
    const btn = d.getElementById('csOpen');
    A('入口保持 hidden', !!btn && btn.hidden === true, btn ? 'hidden=' + btn.hidden : '元素缺失');
    /* [hidden] 有 display:none!important,真实用户点不到;这里**故意**程序化触发,
       验证 openCsModal 自己的 csOn() 硬闸 —— 防御「谁改坏了显隐同步」的那一天。 */
    btn.click();
    A('即便被程序化点击也不开层(csOn() 硬闸)', d.getElementById('csModal').hidden === true);
    A('层内无任何联系方式残渣', !d.querySelector('#csBody .vip-cs-line'));
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }

  // ── 注入面:配置值不得成为标记(与 4.4.2 同一条纪律,对新调用方复验) ──────
  {
    const evil = '<img src=x onerror=window.__pwned=1>';
    const { w, d, errs } = await boot(SESSION_ON({
      label: evil, value: '"><script>window.__pwned=1</script>',
      url: 'javascript:window.__pwned=1', note: evil }));
    console.log('\n[注入面 · 新调用方复验]');
    const btn = d.getElementById('csOpen');
    btn.click();
    const body = d.getElementById('csBody');
    A('层内没有被注入的元素', !body.querySelector('img') && !body.querySelector('script'));
    A('注入串原样落在文本里(textContent 证据)', body.textContent.includes(evil));
    A('javascript: 链接不得渲染成 <a>', !body.querySelector('a'));
    A('全局未被污染', !w.__pwned);
    A('零未捕获异常', errs.length === 0, errs.join(' | '));
    w.close();
  }

  console.log('\n' + '─'.repeat(58));
  console.log(`客服渠道前端冒烟:${PASS} 通过 / ${FAIL} 失败`);
  if (!FAIL) console.log('✓ 入口门控 / 开层渲染 / 幂等 / 关闭路径 / 注入面在真 DOM 中整机成立');
  process.exit(FAIL ? 1 : 0);   // 双保险:即便某窗口的定时器泄漏也不挂死 CI
})();
