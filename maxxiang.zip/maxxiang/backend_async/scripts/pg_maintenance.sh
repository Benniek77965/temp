#!/usr/bin/env bash
# =============================================================================
# pg_maintenance.sh —— 索引膨胀检测 + 在线 REINDEX（4.9.6）
#
# 【为什么需要它】
# B-tree 索引在大量删除后**不会把空间还给操作系统**：VACUUM 只把空页标记为
# 「可在本索引内部复用」，文件大小原地不动。堆会收缩（VACUUM 能截断尾部空页），
# 索引不会。于是一张「曾经很大、现在很小」的表，会留下一个巨大的空壳索引。
#
# 实测复现（PG16.14，同表同数据）：
#     灌 120 万行            堆 721 MB   pkey 36 MB    round索引 9544 kB
#     删到 1.5 万行 + VACUUM 堆 9232 kB  pkey 36 MB    round索引 9544 kB  ← 索引纹丝不动
#     REINDEX CONCURRENTLY   堆 9232 kB  pkey 480 kB   round索引 192 kB   ← 回收 98.7%
#
# 危害不只是占磁盘：**VACUUM 每一趟都要完整扫一遍索引**（btree bulkdelete 是
# 全索引扫描，与死元组多少无关）。一个 881MB 的空壳索引，就是每次 autovacuum
# 白读 881MB —— 这正是「间歇性 CPU 打满、持续几分钟、又恢复」的主要成因之一。
#
# 【用法】
#     bash pg_maintenance.sh                # 只体检，不动手（默认）
#     bash pg_maintenance.sh --reindex      # 执行在线 REINDEX
#     PGC=<容器名> bash pg_maintenance.sh --reindex
#
# 【安全性】
#   · 全部走 REINDEX INDEX CONCURRENTLY —— 不持排他锁，读写照常。
#   · 需要临时磁盘空间 ≈ 被重建索引的**目标大小**（不是当前膨胀后的大小）。
#   · 失败会留下 _ccnew 后缀的 INVALID 索引，脚本会检测并给出清理命令。
#   · 逐个索引串行执行，可随时 Ctrl-C（已完成的不受影响）。
#   · **不碰数据**，只重建索引结构。
# =============================================================================
set -uo pipefail

PGC="${PGC:-$(docker ps --format '{{.Names}}' 2>/dev/null | grep -i postgres | head -1)}"
PGU="${PGU:-star}"
PGD="${PGD:-spelltamer}"
DO_REINDEX=0
[ "${1:-}" = "--reindex" ] && DO_REINDEX=1

[ -z "$PGC" ] && { echo "找不到 postgres 容器；请指定 PGC=<容器名>" >&2; exit 1; }
Q () { docker exec -i "$PGC" psql -U "$PGU" -d "$PGD" -X -q "$@"; }

echo "════════════════════════════════════════════════════════════════"
echo " 索引膨胀体检 · 容器=$PGC · $(date '+%F %T')"
echo "════════════════════════════════════════════════════════════════"
echo
echo "── ⚠ 残留的 INVALID 索引（最高优先级，先看这里）──────────────────"
echo "   CONCURRENTLY 建/重建失败会留下带 _ccnew / _ccold 后缀的失效索引。"
echo "   危害取决于「参与写入维护」这一列（实测，非文档推断）："
echo "     · 参与写入维护 = f（体积通常为 0）：构建阶段就失败，不吃写入、VACUUM 也不扫，只占目录项。"
echo "     · 参与写入维护 = t（已完整建好）：**规划器不用它，但每次 INSERT 要维护它、"
echo "       每趟 VACUUM 要完整扫它** —— 纯成本零收益，必须立刻删。"
echo "       实测 VACUUM VERBOSE 会把它与正常索引一样逐个处理。"
Q -c "
SELECT c.relname AS 索引, i.indisready AS 参与写入维护,
       pg_size_pretty(pg_relation_size(c.oid)) AS 体积,
       CASE WHEN i.indisready THEN '⚠ 正在吃写入+VACUUM，立刻删'
            ELSE '仅占目录项，可从容删' END AS 危害,
       'DROP INDEX CONCURRENTLY '||c.relname||';' AS 清理命令
  FROM pg_index i JOIN pg_class c ON c.oid = i.indexrelid
 WHERE NOT i.indisvalid;"

echo "── 膨胀估算 ─────────────────────────────────────────────────────"
echo "   理论体积按「每行 ~32 字节索引项、90% 填充」估；膨胀比 >3 即值得重建。"
Q -c "
WITH ix AS (
  SELECT s.relname AS tbl, s.indexrelname AS idx,
         pg_relation_size(s.indexrelid) AS bytes,
         c.reltuples::bigint AS rows
    FROM pg_stat_user_indexes s
    JOIN pg_class c ON c.oid = s.relid
   WHERE s.schemaname = 'public')
SELECT tbl AS 表, idx AS 索引,
       CASE WHEN rows < 0 THEN NULL ELSE rows END AS 表行数,
       pg_size_pretty(bytes) AS 当前体积,
       CASE WHEN rows < 0 THEN NULL
            ELSE pg_size_pretty((GREATEST(rows,1) * 32 / 0.9)::bigint) END AS 理论体积,
       -- 膨胀比只在「索引 >1MB 且表已被 ANALYZE 过」时才有意义:
       --   · 索引 <1MB 恒被最小分配(16kB 起)撑出巨大假比值;
       --   · reltuples = -1 表示该表从未 ANALYZE,除出来是垃圾。
       CASE WHEN bytes >= 1024*1024 AND rows >= 0
            THEN ROUND(bytes / GREATEST(GREATEST(rows,1) * 32 / 0.9, 1), 1)
            END AS 膨胀比,
       CASE WHEN rows < 0 THEN '(表未 ANALYZE,不估)'
            WHEN bytes < 1024*1024 THEN '(索引过小,不估)'
            WHEN bytes / GREATEST(GREATEST(rows,1)*32/0.9, 1) > 3
             AND bytes > 50*1024*1024 THEN '← 本脚本会重建'
            WHEN bytes / GREATEST(GREATEST(rows,1)*32/0.9, 1) > 1.8
             AND bytes > 500*1024*1024 THEN '← 轻度膨胀,见下方提示'
            ELSE '' END AS 判定
  FROM ix ORDER BY bytes DESC;"

echo "── 轻度膨胀(1.8~3 倍)的大索引:重建收益有限但仍可观,需你自行决定 ────"
echo "   典型是 rounds_pkey —— 它是滚动流水的主键,持续增删下会稳定停在 ~2 倍。"
echo "   重建它需要 ≈理论体积 的临时空间且耗时较长,收益是每趟 VACUUM 少扫这部分。"
Q -c "
WITH ix AS (
  SELECT s.indexrelname AS idx, pg_relation_size(s.indexrelid) AS bytes,
         c.reltuples::bigint AS rows
    FROM pg_stat_user_indexes s JOIN pg_class c ON c.oid = s.relid
   WHERE s.schemaname = 'public')
SELECT idx AS 索引, pg_size_pretty(bytes) AS 当前,
       pg_size_pretty((bytes - GREATEST(rows,1)*32/0.9)::bigint) AS 可回收,
       'REINDEX INDEX CONCURRENTLY '||idx||';' AS 手动命令
  FROM ix
 WHERE bytes > 500*1024*1024 AND rows >= 0
   AND bytes / GREATEST(GREATEST(rows,1)*32/0.9, 1) BETWEEN 1.8 AND 3;"

echo "── 磁盘余量（REINDEX 需要临时空间）────────────────────────────"
docker exec -i "$PGC" df -h /var/lib/postgresql/data 2>/dev/null | tail -2

echo "── 只增不删的表（无 retention，需人工关注）──────────────────────"
echo "   retention 只清 rounds / predictions（db.py:_PURGE_TABLES）。以下表永不自动清理："
echo "   · predictor_state —— 每房的模型权重。发现房被 7 天回收后其权重**仍留在库里**"
echo "     （purge_rooms_history 注释明说「predictor_state/rooms 仍不清」）。"
echo "     这是刻意的设计（权重是「当前状态」不是「历史流水」），但代价是无界增长。"
echo "   · admin_audit / config_revisions —— 后台审计与配置版本链，只增不改。"
Q -c "
SELECT relname AS 表, n_live_tup AS 行数,
       pg_size_pretty(pg_total_relation_size(relid)) AS 合计体积
  FROM pg_stat_user_tables
 WHERE relname IN ('predictor_state','admin_audit','config_revisions',
                   'rooms','discovered_rooms','user_rooms')
 ORDER BY pg_total_relation_size(relid) DESC;"
echo "   predictor_state 里已无人监控的「孤儿房」（房号既不在 rooms 也不在 discovered_rooms）："
Q -c "
SELECT count(DISTINCT ps.room_id) AS 孤儿房数,
       count(*)                   AS 孤儿行数,
       pg_size_pretty(SUM(pg_column_size(ps.v))::bigint) AS 权重占用
  FROM predictor_state ps
 WHERE NOT EXISTS (SELECT 1 FROM rooms r WHERE r.room_id = ps.room_id)
   AND NOT EXISTS (SELECT 1 FROM discovered_rooms d WHERE d.room_id = ps.room_id);"
echo "   （本脚本**不会**自动删它 —— 删掉等于丢弃模型权重，属产品决策。"
echo "     确需清理时：DELETE FROM predictor_state ps WHERE NOT EXISTS"
echo "     (SELECT 1 FROM rooms r WHERE r.room_id=ps.room_id) AND NOT EXISTS"
echo "     (SELECT 1 FROM discovered_rooms d WHERE d.room_id=ps.room_id);）"



if [ "$DO_REINDEX" -eq 0 ]; then
  echo
  echo "════════════════════════════════════════════════════════════════"
  echo " 以上仅为体检。确认磁盘余量充足后，执行："
  echo "     bash \$0 --reindex"
  echo " 建议在业务低峰期跑（虽然不锁表，但会占用 I/O 与一个 CPU 核）。"
  echo "════════════════════════════════════════════════════════════════"
  exit 0
fi

echo
echo "════════════════════════════════════════════════════════════════"
echo " 开始在线 REINDEX（不锁表，可 Ctrl-C 中断）"
echo "════════════════════════════════════════════════════════════════"

# 开工前先把上一次留下的失效索引清掉 —— 否则新一轮 REINDEX 会在它们之上再叠一层,
# 而「已建好但失效」的那种是**实测会吃写入与 VACUUM** 的,留着纯亏。
LEFTOVER=$(Q -t -A -c "SELECT c.relname FROM pg_index i JOIN pg_class c ON c.oid=i.indexrelid
                        WHERE NOT i.indisvalid;")
if [ -n "$LEFTOVER" ]; then
  echo
  echo "  ⚠ 检测到上次遗留的失效索引，先清理："
  for L in $LEFTOVER; do
    echo -n "    DROP $L … "
    Q -c "DROP INDEX CONCURRENTLY IF EXISTS $L;" >/dev/null 2>&1 && echo "✔" || echo "✘（请手动处理）"
  done
fi

# 只重建「膨胀比 >3 且 >50MB」的；小索引重建没意义
TARGETS=$(Q -t -A -c "
WITH ix AS (
  SELECT s.indexrelname AS idx, pg_relation_size(s.indexrelid) AS bytes,
         c.reltuples::bigint AS rows
    FROM pg_stat_user_indexes s JOIN pg_class c ON c.oid = s.relid
   WHERE s.schemaname = 'public')
SELECT idx FROM ix
 WHERE bytes > 50*1024*1024 AND rows >= 0
   AND bytes / GREATEST(GREATEST(rows,1)*32/0.9, 1) > 3
 ORDER BY bytes DESC;")

if [ -z "$TARGETS" ]; then
  echo "  没有需要重建的索引 —— 全部处于健康状态。"
  exit 0
fi

for IDX in $TARGETS; do
  BEFORE=$(Q -t -A -c "SELECT pg_size_pretty(pg_relation_size('$IDX'))")
  echo
  echo "  ▶ REINDEX $IDX  （当前 $BEFORE）…"
  S=$(date +%s)
  if Q -c "REINDEX INDEX CONCURRENTLY $IDX;"; then
    AFTER=$(Q -t -A -c "SELECT pg_size_pretty(pg_relation_size('$IDX'))")
    echo "    ✔ 完成：$BEFORE → $AFTER  （耗时 $(( $(date +%s) - S ))s）"
    # 立刻自检:REINDEX CONCURRENTLY 即便返回成功,也可能留下 _ccnew/_ccold。
    # 「已建好但失效」的那种会持续吃写入与 VACUUM —— 不能等到下次体检才发现。
    RESID=$(Q -t -A -c "SELECT c.relname FROM pg_index i JOIN pg_class c ON c.oid=i.indexrelid
                         WHERE NOT i.indisvalid;")
    if [ -n "$RESID" ]; then
      for R in $RESID; do
        echo -n "      ⚠ 遗留失效索引 $R，清理中 … "
        Q -c "DROP INDEX CONCURRENTLY IF EXISTS $R;" >/dev/null 2>&1 && echo "✔" || echo "✘（请手动 DROP）"
      done
    fi
  else
    echo "    ✘ 失败。检查是否留下 _ccnew 索引："
    Q -c "SELECT c.relname FROM pg_index i JOIN pg_class c ON c.oid=i.indexrelid
           WHERE NOT i.indisvalid;"
  fi
done

echo
echo "── 重建后体积 ───────────────────────────────────────────────────"
Q -c "
SELECT relname AS 表, pg_size_pretty(pg_relation_size(oid)) AS 堆,
       pg_size_pretty(pg_indexes_size(oid)) AS 索引,
       pg_size_pretty(pg_total_relation_size(oid)) AS 合计
  FROM pg_class WHERE relkind='r' AND relnamespace='public'::regnamespace;"
echo
echo "── 收尾自检：确认没有失效索引残留 ───────────────────────────────"
Q -c "
SELECT CASE WHEN count(*) = 0 THEN '✔ 无失效索引残留'
            ELSE '✘ 仍有 '||count(*)||' 个失效索引，请手动 DROP INDEX CONCURRENTLY' END AS 结果
  FROM pg_index WHERE NOT indisvalid;"
echo
echo "完成。建议接着把统计计数器清零，以便后续能看到**当前**的索引使用率："
echo "    docker exec -i $PGC psql -U $PGU -d $PGD -c \"SELECT pg_stat_reset();\""
