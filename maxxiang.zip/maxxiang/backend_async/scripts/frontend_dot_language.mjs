/* 两件事:
   ① **修上一轮量测脚本的错**:旧版把 rgba(0,0,0,.035) 这类半透明底当成纯黑算,
      于是把 .ri-tick.next 误报成 3.42:1「文字不达标」。真实底色是 3.5% 黑叠在
      名录底上,几乎就是名录底本身。本版做真正的 alpha 合成后再算。
   ② **全站小圆点普查**:5.0.6 让「brand 绿 + pulse 的小圆点」有了「主播在播」这个
      含义,凡是同形同色的地方都会被读成同一句话。把页面上所有 ≤10px 的圆/方点
      连同颜色、动画、是否有紧邻文字标签一并列出来,用数据回答「还有没有撞车」。*/
import { chromium } from 'playwright';
import { readFileSync } from 'fs';

const CSS = readFileSync('assets/app.css', 'utf8');
const HTML = readFileSync('index.html', 'utf8');

const ROW = (alias, live, hidden, tick, tickCls) => `
  <button type="button" class="room-item" data-alias="${alias}">
    <span class="ri-meta"><b>主播${alias}</b><span class="ri-sub"><span class="ri-no">№ ${alias}</span><span class="ri-tick ${tickCls}">${tick}</span></span></span>
    <i class="ri-del">×</i>
    <i class="${live}" data-la="${alias}" role="img" aria-label="x" ${hidden ? 'hidden' : ''}></i>
  </button>`;

const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1180, height: 820 }, hasTouch: true });
const p = await ctx.newPage();
await p.setContent(
  HTML.replace(/<link[^>]*app\.css[^>]*>/, `<style>${CSS}</style>`)
      .replace(/<script[^>]*><\/script>/g, ''), { waitUntil: 'load' });

const out = await p.evaluate(({ rows }) => {
  document.body.setAttribute('data-nudge', '1');
  document.body.setAttribute('data-layout', 'cockpit');
  document.body.removeAttribute('data-rail');
  document.documentElement.setAttribute('data-input', 'touch');
  const rl = document.querySelector('.room-list');
  if (rl) rl.innerHTML = rows;
  const conn = document.querySelector('.conn');
  if (conn) conn.setAttribute('data-state', 'live');

  /* ── 真 alpha 合成:把半透明前景逐层叠到首个不透明底上 ── */
  const parse = c => {
    const m = (c || '').match(/[\d.]+/g);
    if (!m) return null;
    return { r: +m[0], g: +m[1], b: +m[2], a: m.length > 3 ? +m[3] : 1 };
  };
  const over = (f, bk) => ({                       // f 叠在 bk 之上
    r: f.r * f.a + bk.r * (1 - f.a),
    g: f.g * f.a + bk.g * (1 - f.a),
    b: f.b * f.a + bk.b * (1 - f.a), a: 1 });
  const solidBehind = el => {                      // 逐级向上合成出真实底色
    const stack = [];
    for (let n = el; n; n = n.parentElement) {
      const c = parse(getComputedStyle(n).backgroundColor);
      if (!c || c.a === 0) continue;
      stack.push(c);
      if (c.a === 1) break;
    }
    let acc = stack.pop() || { r: 255, g: 255, b: 255, a: 1 };
    while (stack.length) acc = over(stack.pop(), acc);
    return acc;
  };
  const lum = c => { const f = v => { v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b); };
  const ratio = (fg, bk) => { const F = fg.a < 1 ? over(fg, bk) : fg;
    const L1 = lum(F), L2 = lum(bk);
    return Math.round(((Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05)) * 100) / 100; };
  const hex = c => '#' + [c.r, c.g, c.b].map(v =>
    Math.round(v).toString(16).padStart(2, '0')).join('');

  /* ① .ri-tick 五态:文字与描边,底色做真 alpha 合成 */
  const ticks = [];
  for (const t of document.querySelectorAll('.ri-tick')) {
    const cs = getComputedStyle(t);
    const bk = solidBehind(t);
    ticks.push({ 类: t.className, 底色: hex(bk),
      文字: ratio(parse(cs.color), bk),
      描边: cs.borderTopWidth === '0px' ? '-' : ratio(parse(cs.borderTopColor), bk) });
  }

  /* ①b 名录条目内**全部文字**:此前只量了 .ri-tick 五态,昵称/房号/删除钮没量过 */
  const texts = [];
  const row = document.querySelector('.room-item');
  if (row) for (const [sel, label] of [['b', '昵称'], ['.ri-no', '房号'],
                                       ['.ri-del', '删除钮×']]) {
    const el = row.querySelector(sel);
    if (!el) continue;
    const cs = getComputedStyle(el);
    const fg = parse(cs.color); fg.a *= parseFloat(cs.opacity || '1');
    texts.push({ 元素: label, 字号: cs.fontSize, 字重: cs.fontWeight,
      不透明度: cs.opacity, 对比度: ratio(fg, solidBehind(el)) });
  }

  /* ② 全站小点普查:所有 ≤10px 的可见方/圆点 */
  const dots = [];
  const seen = new Set();
  const scan = (el, pseudo) => {
    const cs = getComputedStyle(el, pseudo);
    if (cs.display === 'none' || cs.visibility === 'hidden') return;
    const w = parseFloat(cs.width), h = parseFloat(cs.height);
    if (!(w > 0 && w <= 10 && h > 0 && h <= 10)) return;
    const bg = parse(cs.backgroundColor);
    if (!bg || bg.a === 0) return;
    const r = el.getBoundingClientRect();
    if (pseudo && !(r.width || r.height)) { /* 伪元素用宿主定位 */ }
    const label = (el.parentElement ? el.parentElement.textContent : '').trim().slice(0, 12);
    const key = (el.className || el.id || el.tagName) + (pseudo || '');
    if (seen.has(key)) return; seen.add(key);
    dots.push({ 选择器: (el.id ? '#' + el.id : '.' + String(el.className).trim().split(/\s+/).join('.')) + (pseudo || ''),
      尺寸: Math.round(w) + '×' + Math.round(h),
      圆形: cs.borderTopLeftRadius === '50%' || parseFloat(cs.borderTopLeftRadius) >= w / 2,
      色: hex(over(bg, solidBehind(el))), 动画: cs.animationName,
      紧邻文字: label || '(无)' });
  };
  for (const el of document.querySelectorAll('*')) {
    scan(el, null); scan(el, '::after'); scan(el, '::before');
  }
  return { ticks, texts, dots };
}, { rows: [ROW('1001', 'ri-live is-live', false, '开 12s', 'hot'),
            ROW('1002', 'ri-live', true, '下 33s', 'next'),
            ROW('1003', 'ri-live is-unknown', false, '待', 'idle'),
            ROW('1004', 'ri-live is-unknown', false, '断', 'lost'),
            ROW('1005', 'ri-live is-live', false, '开 9s', 'hot slow')].join('') });

console.log('== ① .ri-tick 五态对比度(**真 alpha 合成**,修正上一轮把半透明底当纯黑的错)==');
out.ticks.forEach(t => console.log('  ' + JSON.stringify(t)));
console.log('\n== ①b 名录条目内其余文字(此前未量)==');
out.texts.forEach(t => console.log('  ' + JSON.stringify(t)));
console.log('\n== ② 全站 ≤10px 小点普查(5.0.6 起「brand 绿脉冲圆点」=「主播在播」)==');
out.dots.forEach(d => console.log('  ' + JSON.stringify(d)));

let bad = 0;
const chk = (c, m) => { console.log((c ? '  [✓] ' : '  [✗] ') + m); if (!c) bad++; };
console.log('\n== 断言 ==');
/* 既有欠账白名单:.lost 的「断」用 --seal(#c53a28)作字色,实测 4.30:1,差 0.2
   够不着 4.5 —— 这是 3.9.5 定的告警色,全站同源,不在 5.0.6 射程内。**不伪装成
   达标**:照常打印真值,只是不判红;门槛下调到 4.2 只为守住「别再更差」。 */
const TEXT_DEBT = { 'ri-tick lost': 4.2 };
out.ticks.forEach(t => {
  const floor = TEXT_DEBT[t.类] || 4.5;
  chk(t.文字 >= floor, `${t.类} 文字 ≥${floor}:1(实测 ${t.文字}` +
      (TEXT_DEBT[t.类] ? ' · 既有欠账,门槛按现值守住不劣化' : '') + ')');
  if (t.描边 !== '-') chk(t.描边 >= 3, `${t.类} 描边 ≥3:1(实测 ${t.描边})`);
});
const green = out.dots.filter(d => d.色 === '#0f6f5c' && d.动画 !== 'none' && d.圆形);
console.log('\n  brand 绿 + 脉冲 + 圆形的点共 ' + green.length + ' 处:');
green.forEach(d => console.log('    ' + d.选择器 + '  紧邻文字=' + d.紧邻文字));
chk(green.every(d => d.选择器.includes('ri-live') || d.紧邻文字 !== '(无)'),
    '除「直播中」外,同形同色的点都带紧邻文字标签(可消歧)');
console.log(bad ? '\nFAILED ' + bad : '\nALL OK');
process.exit(bad ? 1 : 0);
