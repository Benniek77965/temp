/* 用法:项目根 `npm i jsdom` 后 `node backend_async/scripts/frontend_switch_admit_jsdom.js`(Node ≥20)。 */
/* 切房准入(5.0.7)的前端行为冒烟:交付版 index.html + app.js 在 jsdom 真 DOM 中
   原样执行,仅桩网络。此前对 app.js 这几处改动只有**源码文本断言**,从未真跑过。
   覆盖:
     ① loadRoom 带 switch=1 且超时 ≥12s(后端核验预算 5s,默认 8s 会先抛)
     ② 终态三错(room_not_monitored / not_live_now / room_unresolved)→ 清卡 + 优雅回退,
        且**不落进退避重试**
     ③ live_unverifiable 是瞬态 → **留卡**(上游一抖就删房是最坏结果)
     ④ 添加路径:后端 400 时房号**不得**残留在 localStorage(旧序先落盘后问后端,
        被拒即 return,残留房号会被 mergeMyRooms 每 30s 复活成一张永远空白的卡) */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const path = require('path');
const ROOT = path.resolve(__dirname, '..', '..');
const html = fs.readFileSync(ROOT + '/index.html', 'utf8');

const CALLS = [];
let SEED_KEY = 'jf2:myRooms';
let PROFILE_REPLY = null;      // 非 null 时 profile 端点按它回错
let ADD_REPLY = null;          // 非 null 时 monitor/add 按它回错

function routeApi(url) {
  const u = new URL(url, 'http://t/');
  const p = u.pathname, q = u.searchParams;
  CALLS.push({ p, switch: q.get('switch') });
  if (p === '/api/live-rooms') return { ok: true, rooms: [{ alias: '888', roomId: '888',
    nickname: '测试房', avatar: '', canPlay: '1', serverNowMs: Date.now(), serverOffsetMs: 0 }] };
  if (/^\/api\/live-rooms\/.+\/profile$/.test(p)) {
    const alias = p.split('/')[3];
    if (PROFILE_REPLY && alias !== '888') return { __err: 400, body: PROFILE_REPLY };
    return { ok: true, profile: { alias, roomId: alias, nickname: '房 ' + alias, avatar: '', exists: true } };
  }
  if (p === '/api/monitor/add') {
    if (ADD_REPLY) return { __err: 400, body: ADD_REPLY };
    return { ok: true };
  }
  if (p === '/api/monitor/remove') return { ok: true };
  if (/\/config$/.test(p)) return { ok: true, roomId: p.split('/')[3], spells: [] };
  if (/\/history\/days$/.test(p)) return { ok: true, retentionDays: 1, days: [] };
  if (/\/history$/.test(p)) return { ok: true, roomId: p.split('/')[3], rounds: [] };
  if (/\/prediction$/.test(p)) return { ok: true, main: [], guard: [], record: [], ens: [],
    accuracy: null, target_round_id: null, serverNowMs: Date.now() };
  if (/\/coverage/.test(p)) return { ok: true, missing: [] };
  return { ok: true };
}

const dom = new JSDOM(html, { url: 'http://localhost/', pretendToBeVisual: true, runScripts: 'dangerously' });
const w = dom.window;
const TIMEOUTS = [];
w.fetch = async (input, init) => {
  const url = typeof input === 'string' ? input : input.url;
  const body = routeApi(url);
  if (body && body.__err)
    return { ok: false, status: body.__err, headers: { get: () => null },
      json: async () => body.body, text: async () => JSON.stringify(body.body) };
  return { ok: true, status: 200, headers: { get: () => null },
    json: async () => body, text: async () => JSON.stringify(body) };
};
w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){ this.readyState = 2; } };
w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
w.PerformanceObserver = class { observe(){} disconnect(){} };
w.matchMedia = w.matchMedia || (q => ({ matches: false, media: q, addEventListener(){},
  removeEventListener(){}, addListener(){}, removeListener(){} }));
w.scrollTo = () => {};

const A = (n, c, extra) => { console.log(`  [${c ? '✓' : '✗'}] ${n}${extra ? '  ' + extra : ''}`);
  if (!c) process.exitCode = 1; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
/* 名录持久化键是 KEY.myRooms = 'jf2:myRooms' + KEY_NS.v(带用户命名空间后缀),
   **不是**固定串 —— 硬写一个猜的键名会让断言恒真、绿得毫无意义(初版就踩了)。
   故按前缀扫描真实 storage。 */
const myRoomsKey = (win) => {
  for (let i = 0; i < win.localStorage.length; i++) {
    const k = win.localStorage.key(i);
    if (k && k.startsWith('jf2:myRooms')) return k;
  }
  return null;
};
const readRooms = (win) => {
  const k = myRoomsKey(win);
  if (!k) return { key: null, list: [] };
  try { return { key: k, list: JSON.parse(win.localStorage.getItem(k) || '[]') }; }
  catch { return { key: k, list: [] }; }
};
const LS = () => readRooms(w).list;

(async () => {
  w.innerWidth = 1680; w.innerHeight = 960;
  Object.defineProperty(w.HTMLElement.prototype, 'offsetParent',
    { get(){ let n = this; while (n){ if (n.hidden) return null; n = n.parentElement; }
             return this.parentElement; }, configurable: true });
  const _rect = w.Element.prototype.getBoundingClientRect;
  w.Element.prototype.getBoundingClientRect = function(){
    let n = this; while (n){ if (n.hidden) return _rect.call(this); n = n.parentElement; }
    return { width:10, height:10, left:1, right:11, top:1, bottom:11, x:1, y:1 };
  };
  // app.js 的 api() 用 AbortController + setTimeout(不是 AbortSignal.timeout),
  // 故钩 setTimeout 记录超时值;只记 api() 那一档量级(>1s),避免被动画计时器淹没。
  const _sto = w.setTimeout;
  w.setTimeout = function (fn, ms, ...rest) {
    if (typeof ms === 'number' && ms >= 1000) TIMEOUTS.push(ms);
    return _sto.call(w, fn, ms, ...rest);
  };

  const appjs = fs.readFileSync(ROOT + '/assets/app.js', 'utf8');
  const s = w.document.createElement('script');
  s.textContent = appjs;
  w.document.body.appendChild(s);
  await sleep(400);

  console.log('切房准入 · 前端行为(真 DOM 执行)');

  // ── ① 切房调用带 switch=1,且超时留足后端核验预算 ──────────────────────────
  const sw = CALLS.filter(c => c.p.endsWith('/profile'));
  A('profile 调用带 switch=1', sw.some(c => c.switch === '1'),
    `(共 ${sw.length} 次,带旗 ${sw.filter(c => c.switch === '1').length} 次)`);
  const big = TIMEOUTS.filter(t => t >= 12000);
  A('切房 profile 超时 ≥12s(后端核验预算 5s)', big.length > 0,
    `(记录到的超时值:${[...new Set(TIMEOUTS)].sort((a,b)=>a-b).join('/')})`);

  // ── ④ 添加被拒:房号不得残留在 localStorage ────────────────────────────────
  ADD_REPLY = { ok: false, error: 'not_live_now', message: '这个直播间当前未开播' };
  const before = LS().length;
  // 直接驱动提交路径:填号 + 触发确认按钮(与真实用户同一条路)
  const open = w.document.querySelector('#addRoomOpen');
  if (open) open.dispatchEvent(new w.Event('click', { bubbles: true }));
  await sleep(150);
  const inp = w.document.querySelector('#addRoomInput');
  const form = w.document.querySelector('#addRoomForm');
  let drove = false;
  if (inp && form) {
    inp.value = '654321';
    inp.dispatchEvent(new w.Event('input', { bubbles: true }));
    form.dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
    await sleep(1200);
    drove = true;
  }
  const msg = w.document.querySelector('#addRoomMsg');
  A('被拒时弹窗给出后端文案(不静默吞掉)',
    drove && !!(msg && msg.textContent && msg.textContent.trim()),
    drove ? `(文案=${JSON.stringify((msg && msg.textContent || '').trim())})` : '');
  A('添加被 400 拒后 localStorage 无残留房号',
    LS().indexOf('654321') === -1,
    drove ? `(存储=${JSON.stringify(LS())})` : '(未找到添加控件,退化为存储不变检查)');
  A('被拒不改变已存房数', LS().length === before);
  ADD_REPLY = null;

  console.log('  · fetch 命中端点:', [...new Set(CALLS.map(c => c.p))].join(' , '));

  // 先从已启动的这一份实例里取出**运行时真实键名**(含用户命名空间后缀)
  SEED_KEY = myRoomsKey(w) || 'jf2:myRooms';
  console.log('  · 名录持久化键 =', SEED_KEY);

  // ── ②③ 陈房入名录时后端拒绝:终态清卡 / 瞬态留卡 ─────────────────────────
  //    这是**最坏结果**所在:上游一抖就把用户名录里的房删掉,不可逆。
  for (const [err, shouldKeep, note] of [
    ['room_not_monitored', false, '终态:后台已不监控'],
    ['not_live_now',       false, '终态:确证未开播'],
    ['room_unresolved',    false, '终态:号不存在'],
    ['live_unverifiable',  true,  '瞬态:上游问不到 —— 必须留卡'],
  ]) {
    const left = await runStaleRoomCase(err);
    A(`${note} → localStorage ${shouldKeep ? '保留' : '清退'}`,
      shouldKeep ? left.includes('654321') : !left.includes('654321'),
      `(存储=${JSON.stringify(left)})`);
  }
})().catch(e => { console.error('harness 异常:', e); process.exitCode = 1; });

/* 每个场景开一个干净的 jsdom:localStorage 预置一个「后端名录里没有」的陈房,
   boot 时 mergeMyRooms→upsertCustomRoom 会为它发 profile?switch=1 并吃到 400。 */
async function runStaleRoomCase(err) {
  const d2 = new JSDOM(html, { url: 'http://localhost/', pretendToBeVisual: true,
                               runScripts: 'dangerously' });
  const x = d2.window;
  // 键名必须与 app.js 运行时一致:先空跑一次拿到真实键,再种子。
  x.localStorage.setItem(SEED_KEY, JSON.stringify(['654321']));
  x.fetch = async (input) => {
    const url = typeof input === 'string' ? input : input.url;
    const u = new URL(url, 'http://t/');
    if (/^\/api\/live-rooms\/654321\/profile$/.test(u.pathname)) {
      const b = { ok: false, error: err, message: '桩:' + err };
      return { ok: false, status: 400, headers: { get: () => null },
        json: async () => b, text: async () => JSON.stringify(b) };
    }
    const body = routeApi(url);
    if (body && body.__err)
      return { ok: false, status: body.__err, headers: { get: () => null },
        json: async () => body.body, text: async () => JSON.stringify(body.body) };
    return { ok: true, status: 200, headers: { get: () => null },
      json: async () => body, text: async () => JSON.stringify(body) };
  };
  x.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){} };
  x.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
  x.PerformanceObserver = class { observe(){} disconnect(){} };
  x.matchMedia = x.matchMedia || (q => ({ matches: false, media: q, addEventListener(){},
    removeEventListener(){}, addListener(){}, removeListener(){} }));
  x.scrollTo = () => {};
  x.innerWidth = 1680; x.innerHeight = 960;
  Object.defineProperty(x.HTMLElement.prototype, 'offsetParent',
    { get(){ let n = this; while (n){ if (n.hidden) return null; n = n.parentElement; }
             return this.parentElement; }, configurable: true });
  const sc = x.document.createElement('script');
  sc.textContent = fs.readFileSync(ROOT + '/assets/app.js', 'utf8');
  x.document.body.appendChild(sc);
  await sleep(900);
  const out = readRooms(x).list;
  d2.window.close();
  return out;
}
