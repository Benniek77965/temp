/* TOAST 管线验收(4.9.0):载入交付版 index.html + app.js,在真 DOM 上钉死
   「动作型提示不可被抢占 / 一次性提示确实出场后才落盘 / 去抖按内容分桶 /
     出场必重放动画 / admin 气泡不吃点击」这五件事。
   用法:项目根 `npm i jsdom` 后 `node backend_async/scripts/toast_pipeline_jsdom.js` */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(__dirname, '..', '..');
const html = fs.readFileSync(ROOT + '/index.html', 'utf8');
const appjs = fs.readFileSync(ROOT + '/assets/app.js', 'utf8');
const adminjs = fs.readFileSync(ROOT + '/assets/admin.js', 'utf8');

const dom = new JSDOM(html, { url: 'http://localhost/', pretendToBeVisual: true,
                              runScripts: 'dangerously' });
const w = dom.window;
w.fetch = async () => ({ ok: true, status: 200, headers: { get: () => null },
                         json: async () => ({ ok: true }) });
w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){} };
w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
w.PerformanceObserver = class { observe(){} disconnect(){} };
w.matchMedia = w.matchMedia || (q => ({ matches:false, media:q, addEventListener(){},
                                        removeEventListener(){}, addListener(){}, removeListener(){} }));
w.scrollTo = () => {};

const sleep = ms => new Promise(r => setTimeout(r, ms));
const $ = s => w.document.querySelector(s);
let bad = 0;
const A = (n, c, extra) => { console.log(`  [${c ? '✓' : '✗'}] ${n}${extra ? '  → ' + extra : ''}`);
                             if (!c) { bad++; process.exitCode = 1; } };

(async () => {
  w.innerWidth = 1280; w.innerHeight = 900;
  const sc = w.document.createElement('script');
  sc.textContent = appjs;
  w.document.body.appendChild(sc);
  await sleep(200);
  const T = $('#toast');

  console.log('\n══ 一、动作型提示在承诺时长内不可被信息型抢占 ═════════════════════');
  w.eval('TQ.q.length = 0; TQ.cur = null;');
  w.eval(`toastAction('已跟随到 999 —— 由另一窗口/设备切换',
           { label:'切回 888', ms:600, onClick:()=>{ window.__CLICKED = true; } })`);
  A('「切回」按钮已出场', !!T.querySelector('.toast-act'), T.textContent);
  w.eval(`toast('正在观测 999 房')`);      // 旧版:此刻按钮被抹除
  A('信息型 toast 到达后按钮仍在(不被抢占)', !!T.querySelector('.toast-act'),
    '文案=' + T.textContent);
  A('信息型被排队而非丢弃', w.eval('TQ.q.length') === 1, 'queue=' + w.eval('TQ.q.length'));
  const btn = T.querySelector('.toast-act');
  btn.dispatchEvent(new w.Event('click', { bubbles: true }));
  A('点击动作按钮 → onClick 真的执行了', w.__CLICKED === true);
  await sleep(30);
  A('点击后立刻播放排队中的信息型', T.textContent === '正在观测 999 房', T.textContent);

  console.log('\n══ 二、动作型到期后自动放行,不会把队列卡死 ════════════════════════');
  w.eval('TQ.q.length = 0; TQ.cur = null;');
  w.eval(`toastAction('A 动作', { label:'X', ms:200, onClick:()=>{} })`);
  w.eval(`toast('B 信息')`);
  await sleep(320);
  A('动作型到期后信息型自动接棒', T.textContent === 'B 信息', T.textContent);

  console.log('\n══ 三、一次性提示:确实出场后才落「已看过」════════════════════════');
  w.eval('window.__SHOWN = 0; TQ.q.length = 0; TQ.cur = null;');
  w.eval(`toastAction('占位动作', { label:'Y', ms:400, onClick:()=>{} })`);
  w.eval(`toastAction('一次性说明', { label:'Z', ms:400,
            onShown: ()=>{ window.__SHOWN++; }, onClick:()=>{} })`);
  A('被排队时 onShown 尚未触发(不会预落盘)', w.__SHOWN === 0, '__SHOWN=' + w.__SHOWN);
  await sleep(520);
  A('真正出场那一刻才触发 onShown', w.__SHOWN === 1, '__SHOWN=' + w.__SHOWN);
  A('源码里 jfIntro/roomIntro 已改用 onShown 落盘',
    /onShown: \(\) => store\.set\(KEY\.jfIntro/.test(appjs)
      && /onShown: \(\) => store\.set\(KEY\.roomIntro/.test(appjs));

  console.log('\n══ 四、jfToast 去抖按内容分桶 ════════════════════════════════════');
  w.eval('TQ.q.length = 0; TQ.cur = null; _jfToastAt.clear();');
  w.eval(`jfToast('同一账号同一时间只能监控 1 个直播间')`);
  const first = T.textContent;
  w.eval(`jfToast('同一账号同一时间只能监控 1 个直播间')`);
  A('同一句 4s 内仍去抖(原意保住)', T.textContent === first);
  w.eval(`jfToast('另一条完全不同的重要提示')`);
  A('不同内容不再被误杀', T.textContent === '另一条完全不同的重要提示', T.textContent);
  A('去抖账本有容量上限,不会无界增长', /JF_TOAST_KEYS_MAX/.test(appjs));

  console.log('\n══ 五、动画重放 + **不破坏 aria-live 播报** ═══════════════════════');
  w.eval('TQ.q.length = 0; TQ.cur = null;');
  T.hidden = true;
  let hiddenFlips = 0, animResets = 0;
  new w.MutationObserver(muts => { for (const m of muts) {
    if (m.attributeName === 'hidden') hiddenFlips++;
    if (m.attributeName === 'style') animResets++;
  } }).observe(T, { attributes: true, attributeFilter: ['hidden', 'style'] });
  w.eval(`toast('第一条')`);
  await sleep(20);                    // MutationObserver 回调是微任务,必须让它跑完再读
  const flipsAfterFirst = hiddenFlips;
  A('从隐藏态出场时翻 hidden(display:none→非none,规范保证重启动画)',
    flipsAfterFirst >= 1, 'hidden 翻转 ' + flipsAfterFirst + ' 次');
  w.eval(`toast('第二条')`);
  await sleep(30);
  A('**已可见时不再翻 hidden** —— 活动区域不被移出无障碍树,读屏能听到第二条',
    hiddenFlips === flipsAfterFirst, '第二条后 hidden 翻转仍为 ' + hiddenFlips + ' 次');
  A('已可见时改走 animation 重置(动画照样重放)', animResets >= 2,
    'style 变更 ' + animResets + ' 次');
  A('文案确实换成了第二条', T.textContent === '第二条', T.textContent);
  A('源码里 aria 反模式已消除(不再无条件 hidden=true)',
    !/el\.hidden = true;\s*\n\s*el\.textContent = '';/.test(appjs));

  console.log('\n══ 六、队列封顶 + 同文案去重,不会堆成弹幕 ════════════════════════');
  w.eval('TQ.q.length = 0; TQ.cur = null;');
  w.eval(`toastAction('长动作', { label:'K', ms:5000, onClick:()=>{} })`);
  for (let i = 0; i < 12; i++) w.eval(`toast('刷屏 ${i % 2}')`);
  A('队列长度受控', w.eval('TQ.q.length') <= 3, 'queue=' + w.eval('TQ.q.length'));
  for (let i = 0; i < 5; i++)
    w.eval(`toastAction('同一动作', { label:'S', ms:1000, onClick:()=>{} })`);
  A('同文案动作型自动去重', w.eval("TQ.q.filter(x=>x.msg==='同一动作').length") === 1);

  console.log('\n══ 七、admin 气泡:淡出后不再吃点击,且读屏可播报 ══════════════════');
  const dom2 = new JSDOM('<!doctype html><html><body><div id="main"></div></body></html>',
                         { url: 'http://localhost/admin', pretendToBeVisual: true,
                           runScripts: 'dangerously' });
  const w2 = dom2.window;
  // 按大括号配平精确取出 admin.js 的 toast() 实现(行数会随注释变化,不能写死)
  const at = adminjs.indexOf('function toast(msg');
  let depth = 0, end = at;
  for (let i = adminjs.indexOf('{', at); i < adminjs.length; i++) {
    if (adminjs[i] === '{') depth++;
    else if (adminjs[i] === '}') { depth--; if (depth === 0) { end = i + 1; break; } }
  }
  const src = adminjs.slice(at, end);
  const s2 = w2.document.createElement('script');
  s2.textContent = 'var $ = s => document.querySelector(s);\n' + src + "\ntoast('保存成功');";
  w2.document.body.appendChild(s2);
  const el2 = w2.document.querySelector('#toast');
  const cs = w2.getComputedStyle(el2);
  A('气泡自身就不接收点击(pointer-events:none)', cs.pointerEvents === 'none',
    'pointerEvents=' + cs.pointerEvents);
  A('带 role=status / aria-live(读屏可播报)',
    el2.getAttribute('role') === 'status' && el2.getAttribute('aria-live') === 'polite');
  await sleep(2900);
  const cs2 = w2.getComputedStyle(el2);
  A('淡出后彻底移出命中测试(visibility:hidden)', cs2.visibility === 'hidden',
    'visibility=' + cs2.visibility + ' opacity=' + cs2.opacity);

  console.log('\n' + '='.repeat(70));
  console.log(bad === 0 ? '✓ TOAST 管线验收:全部通过' : `✗ 有 ${bad} 条未通过`);
})();
