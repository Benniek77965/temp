/* js_scope_scan.mjs — 前端 JS「未声明标识符」静态扫描(4.7.7)

   用法(项目根):
       npm i --no-save acorn eslint-scope
       node backend_async/scripts/js_scope_scan.mjs                  # 扫 assets/*.js
       node backend_async/scripts/js_scope_scan.mjs assets/admin.js  # 只扫指定文件

   ⚠ **必须带 --no-save**:依赖一旦写进 package.json,目标机 `npm ci` 会因
     「package.json and package-lock.json are not in sync」直接失败,整个镜像
     重建中断 —— 本项目发生过这起真实部署事故,admin_secret_jsdom.js 的头部
     有同样的告诫。本脚本沿用同一约定。

   ── 为什么要有这一份 ────────────────────────────────────────────────────────
   4.7.7 事故:`const purgeOn = !!ov.purgeEnabled;` 连同它上方三行注释,被从
   「值」视图误粘贴进「注」视图的三个函数里。那三处根本拿不到 `ov`,而 admin.js
   是 `type="module"`(严格模式)—— 读一个未声明的标识符直接 ReferenceError。
   后果:注册流水与观测台封禁两个区永远停在「加载中…」。

   仓库里已有的前端检查全是**字符串扫描**(tests/_srcscan.py 剥注释后 grep)。
   那类手段结构上不可能发现这种错:被粘贴的文本本身完全合法,错的是它待的地方。
   本脚本做真正的作用域解析(acorn 出 AST,eslint-scope 建作用域链),把「读了一个
   在任何上层作用域里都没声明过的名字」全部列出来 —— 毫秒级,一次抓一整类。

   退出码:0 = 干净;1 = 发现未解析标识符(或解析失败)。 */
import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';

const require_ = createRequire(import.meta.url);
let acorn, escope;
try {
  acorn = require_('acorn');
  escope = require_('eslint-scope');
} catch (e) {
  console.error('缺少依赖。请在项目根执行:  npm i --no-save acorn eslint-scope');
  process.exit(1);
}

const ROOT = path.resolve(new URL('.', import.meta.url).pathname, '..', '..');

/* 浏览器 / 标准库全局白名单。刻意手写而非引第三方 globals 包:多一个依赖,
   就多一次 `npm ci` 出事的机会;而这份名单几年也动不了几次。 */
const GLOBALS = new Set(`
  window document navigator location history screen top parent self globalThis
  console setTimeout clearTimeout setInterval clearInterval queueMicrotask
  requestAnimationFrame cancelAnimationFrame requestIdleCallback
  fetch Headers Request Response FormData Blob File FileReader URL URLSearchParams
  AbortController AbortSignal EventSource WebSocket BroadcastChannel Worker
  localStorage sessionStorage indexedDB caches crypto performance
  alert confirm prompt matchMedia getComputedStyle structuredClone
  MutationObserver IntersectionObserver ResizeObserver PerformanceObserver
  Event CustomEvent EventTarget Node Element HTMLElement DocumentFragment
  Image Audio Option Text Range Selection DOMParser XMLSerializer XMLHttpRequest
  Object Array String Number Boolean Symbol BigInt Function Math JSON Date RegExp
  Map Set WeakMap WeakSet WeakRef Promise Proxy Reflect Intl
  Error TypeError RangeError ReferenceError SyntaxError EvalError URIError AggregateError
  ArrayBuffer SharedArrayBuffer DataView Atomics
  Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array
  Int32Array Uint32Array Float32Array Float64Array BigInt64Array BigUint64Array
  isNaN isFinite parseInt parseFloat encodeURIComponent decodeURIComponent
  encodeURI decodeURI escape unescape btoa atob NaN Infinity undefined
  Notification IntlMessageFormat TextEncoder TextDecoder CSS
  /* window 的属性可以不带 window. 前缀直接读 —— 作用域分析器看不出这层,
     必须显式列出。下面这批是 assets/app.js 实际在用的(逐条人工核对过,
     全部是 WindowOrWorkerGlobalScope / Window 的标准成员,不是漏声明)。 */
  innerWidth innerHeight outerWidth outerHeight scrollX scrollY pageXOffset pageYOffset
  devicePixelRatio visualViewport addEventListener removeEventListener dispatchEvent
  scrollTo scrollBy open close postMessage focus blur print getSelection
  origin isSecureContext name closed frames length opener
`.trim().split(/\s+/).filter(Boolean));

function scan(file) {
  const src = fs.readFileSync(file, 'utf8');
  let ast;
  try {
    // ranges 必须为 true:eslint-scope 的 __isValidResolution 直接读 node.range,
    // 缺了它在遇到某些函数表达式时会以 TypeError 崩掉整次扫描(实测)。
    ast = acorn.parse(src, { ecmaVersion: 2022, sourceType: 'module',
                             locations: true, ranges: true });
  } catch (e) {
    console.log(`✗ ${path.relative(ROOT, file)} — 解析失败: ${e.message}`);
    return 1;
  }
  let sm;
  try {
    sm = escope.analyze(ast, { ecmaVersion: 2022, sourceType: 'module', ignoreEval: true });
  } catch (e) {                       // 单文件分析失败不拖垮整次扫描
    console.log(`✗ ${path.relative(ROOT, file)} — 作用域分析失败: ${e.message}`);
    return 1;
  }
  const lines = src.split('\n');
  const bad = sm.globalScope.through
    .filter(ref => !GLOBALS.has(ref.identifier.name))
    .map(ref => ({
      name: ref.identifier.name,
      line: ref.identifier.loc.start.line,
      col: ref.identifier.loc.start.column,
      write: !!ref.writeExpr,
    }))
    .sort((a, b) => a.line - b.line);

  const rel = path.relative(ROOT, file);
  if (!bad.length) { console.log(`✓ ${rel} — 无未解析标识符`); return 0; }
  console.log(`✗ ${rel} — 未解析标识符 ${bad.length} 处:`);
  for (const b of bad) {
    console.log(`    L${b.line}:${b.col}  ${b.name}${b.write ? ' (写)' : ' (读)'}`
      + `  | ${(lines[b.line - 1] || '').trim().slice(0, 110)}`);
  }
  console.log('  → 若确为浏览器全局,请补进本脚本的 GLOBALS 名单;否则就是真 bug。');
  return 1;
}

const args = process.argv.slice(2);
const targets = args.length
  ? args.map(a => path.resolve(ROOT, a))
  : fs.readdirSync(path.join(ROOT, 'assets'))
      .filter(f => f.endsWith('.js'))
      .map(f => path.join(ROOT, 'assets', f));

let rc = 0;
for (const t of targets) rc |= scan(t);
process.exit(rc);
