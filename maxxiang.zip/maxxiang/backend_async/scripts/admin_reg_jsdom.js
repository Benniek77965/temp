/* 用法:项目根 `npm i jsdom` 后 `node backend_async/scripts/admin_reg_jsdom.js`(Node ≥20)。

   管理台「注」视图(4.0.0)整机集成冒烟:交付版 admin.html + admin.js 在 jsdom 真
   DOM 中原样执行,桩掉 /api/admin/* 网络。**专测那些后端 API 测不到的前端交互**:
     · renderReg 首帧:模式药丸、今日/7 日、PoW 水位、邀请码概况都渲染出来
     · 邀请码生成弹窗(ask 的 html+collect 新路径 —— 本轮复查修的真 bug:
       旧代码把 HTML 当 textContent、读不存在的 #giXxx 会 TypeError)
     · 模式切换的键名确认(键入不符→取消;键入符→发请求)
     · 熔断横幅 + 恢复按钮
     · 封禁/解封表单
     · 限流运维:清空按钮的确认/取消/请求与 toast 计数(4.0.3)
     · 4.0.5:筛选条与数据区分离(刷新不清输入)· 邀请码分页总数 · 「导出 txt」按钮
     · **切走视图后定时器清零**(不留全局监听器/interval 泄漏)
*/
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
const html = fs.readFileSync(ROOT + '/admin.html', 'utf8');
const JS_ARG = process.argv.indexOf('--js');
const adminjs = fs.readFileSync(JS_ARG > 0 ? process.argv[JS_ARG + 1] : ROOT + '/assets/admin.js', 'utf8');

let PASS = 0, FAIL = 0;
const A = (n, c) => { console.log(`  [${c ? '✓' : '✗'}] ${n}`); if (c) PASS++; else { FAIL++; process.exitCode = 1; } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ── /api/admin/* 桩:记录调用,给最小可用返回 ─────────────────────────────── */
const NET = { calls: [], invites: [], blocks: [], breaker: {}, mode: 'invite',
              genCount: 0, lastGen: null, lastBlock: null, lastMode: null,
              lastLogQ: null, regBig: false };   // 4.0.7:流水桩的参数回显与多页开关
function route(url, opt) {
  const m = (opt && opt.method) || 'GET';
  const bodyObj = opt && opt.body ? JSON.parse(opt.body) : {};
  NET.calls.push(m + ' ' + url);
  if (url.endsWith('/login')) return { ok: true, token: 'tok', csrf: 'csrf', version: '1.4.0' };
  if (url.includes('/reg/overview')) return { ok: true, enabled: true,
    modeConfigured: NET.mode, modeEffective: (NET.breaker.mode || NET.mode),
    breaker: NET.breaker, passShape: 'md5',
    pow: { base: 17, current: 19 },
    thresholds: { ipHourly: 5, ipDaily: 10, ipOkDaily: 2, globalHourly: 30,
                  globalDaily: 200, globalDailyInvite: 500 },
    today: { ok: 3, fail: 5 },
    days: [{ d: '2026-07-12', ok: 1, fail: 0 }, { d: '2026-07-13', ok: 2, fail: 3 }],
    invites: { total: NET.invites.length, active: NET.invites.filter(x => !x.disabled).length,
               used: 0 } };
  if (url.includes('/reg/invites/generate')) {
    NET.lastGen = bodyObj;
    const codes = [];
    for (let i = 0; i < (bodyObj.count || 1); i++) {
      const c = 'AAAA-BBBB-CCCC-' + String(1000 + NET.genCount++);
      NET.invites.push({ id: NET.genCount, code_disp: c, days_granted: bodyObj.days || 0,
                         quota: bodyObj.quota || 1, used_count: 0, disabled: 0,
                         expires_at: '', expired: 0, note: bodyObj.note || '' });
      codes.push(c);
    }
    return { ok: true, codes };
  }
  if (/\/reg\/invites\/\d+\/disable/.test(url)) {
    const id = +url.match(/invites\/(\d+)\/disable/)[1];
    const it = NET.invites.find(x => x.id === id); if (it) it.disabled = 1;
    return { ok: true, changed: true };
  }
  if (url.includes('/reg/invites')) return { ok: true, enabled: true,
    total: NET.invites.length, page: 1, size: 50, items: NET.invites };
  if (url.includes('/reg/mode')) {
    NET.lastMode = bodyObj.mode;
    if (['off', 'invite', 'open'].includes(bodyObj.mode)) { NET.mode = bodyObj.mode; return { ok: true }; }
    return { __status: 422, ok: false, error: 'bad_mode' };
  }
  if (url.includes('/reg/breaker/clear')) { NET.breaker = {}; return { ok: true, cleared: true }; }
  if (url.includes('/reg/throttle/clear')) return { ok: true, enabled: true,
    cleared: { redis: 7, mem: 2, redis_ok: true } };
  if (url.includes('/reg/log')) {
    /* 4.0.7:桩升级为参数感知 —— 时窗聚类/原因筛/跳页/悬空页四枚新钉都要求
       后端「按参数回话」。样本三组各有用意:
         9.9.9.9 ×3 · 8 分钟内  → 必须整组淡金(真·近时批量);
         8.8.8.8 ×3 · 跨 30 天  → 必须一根毛都不亮(家庭固定 IP,时窗防误判);
         1.2.3.4 的 u5           → 既有「筛选带 ip 参数」断言的老现场,原样保留。
       NET.regBig=true 时假装库里有 200 条(多页形态,考跳页);其余情况 page>1
       一律回空 items(考悬空页自愈:总数在、这一页没了)。 */
    const q = Object.fromEntries(new URLSearchParams(url.split('?')[1] || ''));
    NET.lastLogQ = q;
    let items = [
      { id: 9, user_id: 0, user_name: 'b3', ip: '9.9.9.9', ua: 'UA-batch-' + 'x'.repeat(70),
        fp: 'ffff000011112222', invite_id: 0, ok: 0, reason: 'throttled', created_at: '2026-07-18T10:08:00' },
      { id: 8, user_id: 0, user_name: 'b2', ip: '9.9.9.9', ua: 'UA', fp: '',
        invite_id: 0, ok: 0, reason: 'pow_failed', created_at: '2026-07-18T10:04:00' },
      { id: 7, user_id: 7, user_name: 'b1', ip: '9.9.9.9', ua: 'UA', fp: '',
        invite_id: 0, ok: 1, reason: 'ok', created_at: '2026-07-18T10:00:00' },
      { id: 6, user_id: 6, user_name: 'fam3', ip: '8.8.8.8', ua: 'UA', fp: '',
        invite_id: 0, ok: 1, reason: 'ok', created_at: '2026-07-17T09:00:00' },
      { id: 5, user_id: 5, user_name: 'fam2', ip: '8.8.8.8', ua: 'UA', fp: '',
        invite_id: 0, ok: 1, reason: 'ok', created_at: '2026-07-01T09:00:00' },
      { id: 4, user_id: 4, user_name: 'fam1', ip: '8.8.8.8', ua: 'UA', fp: '',
        invite_id: 0, ok: 1, reason: 'ok', created_at: '2026-06-17T09:00:00' },
      { id: 1, user_id: 5, user_name: 'u5', ip: '1.2.3.4', ua: 'UA', fp: 'abcd1234',
        invite_id: 0, ok: 1, reason: 'ok', created_at: '2026-07-18T10:00:00' },
    ];
    if (q.ip) items = items.filter(x => x.ip === q.ip);
    if (q.reason) items = items.filter(x => x.reason === q.reason);
    if (q.ok === '0' || q.ok === '1') items = items.filter(x => String(x.ok) === q.ok);
    const page = +(q.page || 1);
    if (NET.regBig) return { ok: true, enabled: true, total: 200, page, size: 30, items };
    if (page > 1) return { ok: true, enabled: true, total: items.length, page, size: 30, items: [] };
    return { ok: true, enabled: true, total: items.length, page: 1, size: 30, items };
  }
  if (url.includes('/reg/blocks')) return { ok: true, enabled: true, items: NET.blocks };
  if (url.includes('/reg/block')) {
    NET.lastBlock = bodyObj;
    if (bodyObj.unblock) { NET.blocks = NET.blocks.filter(b => !bodyObj.userIds.map(Number).includes(b.user_id)); return { ok: true, affected: 1 }; }
    for (const u of bodyObj.userIds) NET.blocks.push({ user_id: +u, reason: 'malicious_reg',
      note: bodyObj.note || '', created_at: '2026-07-18T10:00:00', user_name: 'u' + u });
    return { ok: true, affected: bodyObj.userIds.length };
  }
  if (url.includes('/audit')) return { ok: true, total: 0, page: 1, size: 50, items: [] };
  if (url.includes('/state') || url.includes('/effective')) return { ok: true, rev: 1, settings: {}, effective: {} };
  if (url.includes('/registry')) return { ok: true, cards: [] };
  return { ok: true };
}

(async () => {
  console.log('管理台「注」视图(4.0.0)整机冒烟 —— 交付版 admin.html + admin.js @ jsdom\n');
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => { if (!/Not implemented/.test(e.message)) console.log('  · jsdomError:', e.message.slice(0, 90)); });
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
                                url: 'http://localhost/', virtualConsole: vc });
  const w = dom.window;
  const jsErrs = [];
  w.addEventListener('error', e => jsErrs.push(e.message || String(e.error)));
  w.fetch = async (input, opt = {}) => {
    const url = typeof input === 'string' ? input : input.url;
    const b = route(url, opt);
    const status = b.__status || 200;
    return { ok: status < 400, status, headers: { get: () => null },
             json: async () => b, text: async () => JSON.stringify(b) };
  };
  w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){} };
  w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
  w.matchMedia = q => ({ matches: false, media: q, addEventListener(){}, removeEventListener(){},
                         addListener(){}, removeListener(){} });
  w.scrollTo = () => {};
  // localStorage 桩(admin.js 令牌存这里)
  const _ls = {};
  Object.defineProperty(w, 'localStorage', { value: {
    getItem: k => (k in _ls ? _ls[k] : null), setItem: (k, v) => { _ls[k] = String(v); },
    removeItem: k => { delete _ls[k]; }, clear: () => { for (const k in _ls) delete _ls[k]; } },
    configurable: true });

  const sc = w.document.createElement('script');
  sc.textContent = adminjs;
  w.document.body.appendChild(sc);
  await sleep(150);

  const $ = s => w.document.querySelector(s);
  const $$ = s => [...w.document.querySelectorAll(s)];
  const click = el => el && el.dispatchEvent(new w.Event('click', { bubbles: true }));
  const setVal = (el, v) => { if (el) el.value = v; };

  // ── 登录 ────────────────────────────────────────────────────────────────
  setVal($('#pw'), 'x');
  click($('#loginBtn'));
  await sleep(200);
  A('管理台登录后进入 shell', $('#shell').classList.contains('on'));

  // ── 切到「注」视图 ──────────────────────────────────────────────────────
  const regNav = $$('.nav-item').find(b => b.dataset.view === 'reg');
  A('左栏存在「注」导航项', !!regNav);
  click(regNav);
  await sleep(250);
  A('renderReg 首帧渲染标题', /注册与邀请/.test($('#main').textContent));
  A('模式药丸显示当前生效档', /邀请码|开放|关闭/.test($('#main').textContent));
  A('今日注册数渲染(3 成功 / 5 失败)', /3/.test($('#main').textContent) && /5 失败/.test($('#main').textContent));
  A('PoW 难度水位渲染(当前 19)', /19/.test($('#main').textContent));
  A('三档模式切换按钮齐全', $$('[data-mode]').length === 3);

  // ── 邀请码生成弹窗(本轮复查修复的真 bug 现场)────────────────────────────
  const genBtn = $('#invGen');
  A('「批量生成」按钮存在且已绑定', !!genBtn);
  click(genBtn);
  await sleep(150);
  A('生成弹窗以真实表单渲染(#giCount 等元素真的存在)',
    !!$('#giCount') && !!$('#giQuota') && !!$('#giDays') && !!$('#giExp') && !!$('#giNote'));
  A('弹窗打开无 JS 异常(旧代码此处 TypeError)', jsErrs.length === 0);
  // 填表并确定
  setVal($('#giCount'), '5'); setVal($('#giQuota'), '3'); setVal($('#giDays'), '7');
  setVal($('#giExp'), '30'); setVal($('#giNote'), '测试批次');
  click($('#askYes'));
  await sleep(300);   // 生成请求 + 结果弹窗(第二个 ask)各需一拍
  A('生成请求带正确载荷(collect 现场回收字段)',
    NET.lastGen && NET.lastGen.count === 5 && NET.lastGen.quota === 3
    && NET.lastGen.days === 7 && NET.lastGen.expiresDays === 30 && NET.lastGen.note === '测试批次');
  A('后端确已生成 5 枚码', NET.invites.length === 5);
  A('结果弹窗展示明文码(textarea)', !!$('#giOut') && /AAAA-BBBB/.test($('#giOut').value));
  click($('#askYes'));   // 关闭结果弹窗
  await sleep(200);
  A('邀请码列表刷新出新码', /AAAA-BBBB-CCCC/.test($('#invBox').textContent));

  // 禁用一枚
  const disBtn = $$('#invBox [data-dis]')[0];
  A('邀请码行有「禁用」按钮', !!disBtn);
  click(disBtn); await sleep(80);
  click($('#askYes')); await sleep(150);
  A('禁用后该码标记为已禁用', NET.invites[0].disabled === 1);

  // ── 4.0.5:筛选条与数据区分离 · 分页/导出控件 ───────────────────────────
  A('筛选条与数据区分离(#rlBar / #rlTbl 各自存在)', !!$('#rlBar') && !!$('#rlTbl'));
  setVal($('#rlIp'), '1.2.3.4');
  click($('#rlGo')); await sleep(150);
  A('点「筛选」请求带 ip 参数', NET.calls.some(c => c.includes('/reg/log') && c.includes('ip=1.2.3.4')));
  A('数据区刷新后筛选输入值原地保留(不再被整块重建清空)', $('#rlIp').value === '1.2.3.4');
  A('邀请码区渲染「导出 txt」按钮(§5-R7②)', !!$('#invExp'));
  A('邀请码列表随行显示总数(分页贯通)', /共 5 枚/.test($('#invBox').textContent));

  // ── 4.0.7:聚类 = 条数 × 时窗;行点按详情;原因筛;跳页;悬空页自愈 ──────
  // 每一枚都对应一处真机复现的实伤,修前当场是红的(反向钉纪律,同 4.9.4)。
  setVal($('#rlIp'), ''); click($('#rlGo')); await sleep(160);
  const hotRows = () => $$('#rlTbl tr').filter(tr => (tr.getAttribute('style') || '').includes('gilt'));
  A('近时批量(同 IP ×3 · 8 分钟内)整组淡金', hotRows().length === 3
    && hotRows().every(tr => /9\.9\.9\.9/.test(tr.textContent)));
  A('高亮悬停依据带时距(「分钟内」)', /分钟内/.test(hotRows()[0].getAttribute('title') || ''));
  A('家庭 IP(同 IP ×3 · 跨 30 天)不再淡金 —— 时窗防误判',
    !$$('#rlTbl tr').some(tr => /8\.8\.8\.8/.test(tr.textContent)
                                && (tr.getAttribute('style') || '').includes('gilt')));
  setVal($('#rlIp'), '8.8.8.8'); click($('#rlGo')); await sleep(160);
  A('按 IP 精确筛后不按 IP 聚类(全员同 IP 零信息量)', hotRows().length === 0
    && $$('#rlTbl tr[data-ri]').length === 3);
  // 行点按 → 详情弹窗(触屏读不到 title 的唯一替代通道)
  click($$('#rlTbl tr[data-ri]')[0]); await sleep(140);
  A('点行弹出「注册流水详情」', $('#ask').classList.contains('open')
    && /注册流水详情/.test($('#askT').textContent));
  A('详情里 UA / 指纹以全文呈现(不再截断)', /UA/.test($('#askB').textContent));
  A('确认键化身「按此 IP 筛选」', /按此 IP 筛选/.test($('#askYes').textContent));
  click($('#askYes')); await sleep(160);
  A('确认后 IP 回填筛选框并即时生效', $('#rlIp').value === '8.8.8.8'
    && NET.lastLogQ && NET.lastLogQ.ip === '8.8.8.8');
  // 原因筛选:下拉三态(''/成败/r:码)的 r: 分支
  setVal($('#rlIp'), '');
  $('#rlOk').value = 'r:throttled';
  $('#rlOk').dispatchEvent(new w.Event('change', { bubbles: true }));
  await sleep(160);
  A('选具体原因 → 请求带 reason=throttled 且不带 ok',
    NET.lastLogQ && NET.lastLogQ.reason === 'throttled' && !('ok' in NET.lastLogQ));
  A('原因命中行以中文语义渲染(触发限流)', /触发限流/.test($('#rlTbl').textContent));
  $('#rlOk').value = '';
  $('#rlOk').dispatchEvent(new w.Event('change', { bubbles: true }));
  await sleep(140);
  // 跳页(>3 页才出现)与悬空页自愈
  NET.regBig = true; click($('#rlGo')); await sleep(160);
  A('多页形态渲染跳页控件(复用 .jv-pjump 样式)', !!$('#rlJump') && !!$('#rlJumpGo'));
  setVal($('#rlJump'), '5'); click($('#rlJumpGo')); await sleep(160);
  A('跳页请求带 page=5(越界会被钳制)', NET.lastLogQ && NET.lastLogQ.page === '5');
  NET.regBig = false;                    // 桩恢复常态:page>1 一律回空(演悬空页)
  click($('#rlNext')); await sleep(220); // 前进到已不存在的一页
  A('悬空页自动回退第 1 页(不再困死在空页)', NET.lastLogQ && NET.lastLogQ.page === '1'
    && /9\.9\.9\.9/.test($('#rlTbl').textContent));

  // ── 模式切换二次确认(admin 1.8.0 起:键名抄写下线,保留一次危级二次确认 —— 见 admin.js
  //    renderReg 注释。本段原按旧「键名确认」写的断言随之过期,5.2.0 复查时按现行设计改写)──
  const openBtn = $$('[data-mode]').find(b => b.dataset.mode === 'open');
  click(openBtn); await sleep(100);
  A('切换模式弹出危级二次确认(不再要求抄写键名)', $('#ask').classList.contains('open') && $('#askI').hidden
    && /任何人都能自助注册/.test($('#askB').textContent));
  click($('#askNo')); await sleep(120);
  A('取消 → 不发切换请求', NET.lastMode === null);
  click($$('[data-mode]').find(b => b.dataset.mode === 'open')); await sleep(100);
  click($('#askYes')); await sleep(150);
  A('确认 → 发出切到 open 的请求', NET.lastMode === 'open');

  // ── 封禁 / 解封 ─────────────────────────────────────────────────────────
  setVal($('#blkUids'), '111, 222, abc'); setVal($('#blkNote'), '刷号');
  click($('#blkAdd')); await sleep(80);
  click($('#askYes')); await sleep(150);
  A('封禁只取合法数字 uid(111,222;abc 被滤)',
    NET.lastBlock && NET.lastBlock.userIds.length === 2
    && NET.lastBlock.userIds.every(x => /^\d+$/.test(x)));
  A('封禁列表出现新记录', /111/.test($('#blockBox').textContent) && /222/.test($('#blockBox').textContent));
  const unblkBtn = $$('#blockBox [data-unblk]')[0];
  click(unblkBtn); await sleep(80); click($('#askYes')); await sleep(150);
  A('解封请求带 unblock:true', NET.lastBlock && NET.lastBlock.unblock === true);

  // ── 熔断横幅 + 恢复 ─────────────────────────────────────────────────────
  NET.breaker = { mode: 'off', why: '日成功注册达上限 200/200', by: 'auto', at: '2026-07-18T09:00:00' };
  click(regNav); await sleep(250);   // 重渲染以拉到熔断态
  A('熔断态渲染红色横幅', /熔断中/.test($('#main').textContent));
  const brBtn = $('#brClear');
  A('熔断横幅带「恢复注册」按钮', !!brBtn);
  click(brBtn); await sleep(80); click($('#askYes')); await sleep(150);
  A('恢复请求已发出且熔断清除', NET.calls.some(c => c.includes('/reg/breaker/clear')) && !NET.breaker.mode);

  // ── 限流运维:清空全部注册限流(4.0.3)──────────────────────────────────
  const tcBtn = $('#thrClear');
  A('「限流运维」卡渲染清空按钮', !!tcBtn);
  click(tcBtn); await sleep(80);
  A('清空弹确认框且文案点名 guantai:reg:*',
    $('#ask').classList.contains('open') && /guantai:reg/.test($('#ask').textContent));
  click($('#askNo')); await sleep(120);
  A('取消不发清空请求', !NET.calls.some(c => c.includes('/reg/throttle/clear')));
  click($('#thrClear')); await sleep(80); click($('#askYes')); await sleep(200);
  A('确认后 POST /reg/throttle/clear',
    NET.calls.some(c => c.startsWith('POST') && c.includes('/reg/throttle/clear')));
  const toastEl = $('#toast');
  A('toast 报 Redis/进程内清除计数',
    !!toastEl && /Redis 7/.test(toastEl.textContent) && /进程内 2/.test(toastEl.textContent));
  /* 1.7.4:toast 元素三件套 —— 这三项是内联 cssText/属性,混淆器会把字符串搬进编码
     串数组,**源码 grep 找得到不代表产物运行时还在**(本套件是唯一同时跑源码与
     --js 产物两种形态、且真实触发 toast 的地方,故钉在这里)。 */
  if (toastEl){
    const tcs = w.getComputedStyle(toastEl);
    A('toast 气泡自身不吃点击(pointer-events:none)', tcs.pointerEvents === 'none');
    A('toast 带 role=status + aria-live(读屏可播报)',
      toastEl.getAttribute('role') === 'status' && toastEl.getAttribute('aria-live') === 'polite');
    await sleep(2950);
    A('toast 淡出后 visibility:hidden 收尾(不留隐形拦截条)',
      w.getComputedStyle(toastEl).visibility === 'hidden');
  }
  A('熔断态未被清空动作触碰(专属路径语义)', !NET.breaker.mode);

  // ── 切走视图:定时器清零(无泄漏)─────────────────────────────────────────
  // S/w.eval 依赖模块级符号名 —— 混淆产物里 renameGlobals 会改名,故仅源码态断言
  const OB = JS_ARG > 0;
  if (!OB) A('「注」视图注册了定时器', w.eval('S.timers.length') >= 1);
  click($$('.nav-item').find(b => b.dataset.view === 'audit'));
  await sleep(150);
  if (!OB) A('切到「审」后 reg 的定时器被 clearTimers 收摊', w.eval("S.view") === 'audit');
  else A('切到「审」视图成功(混淆态黑盒)', /审计/.test($('#crumb').textContent + $('#main').textContent));
  // 关键:切走后 S.timers 是新视图的,不含 reg 的残留;且无全局 click 委托泄漏
  A('无全局 click 监听器泄漏(切视图不再触发 reg 逻辑)', jsErrs.length === 0);

  console.log(`\n管理台「注」视图冒烟:${PASS} 通过 / ${FAIL} 失败`
    + (jsErrs.length ? `\n⚠ 捕获 JS 错误 ${jsErrs.length} 条:` + jsErrs.slice(0, 3).join(' | ') : ''));
  if (FAIL || jsErrs.length) process.exit(1);
})().catch(e => { console.error('冒烟异常:', e); process.exit(1); });
