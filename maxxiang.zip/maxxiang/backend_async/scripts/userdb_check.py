#!/usr/bin/env python3
"""
userdb_check.py — 登录系统(3.8.0)用户库一键体检
================================================================================
在**部署机**上对真实用户库做启用前体检(开发沙箱通常出不去 3306,请上部署机跑):

    cd backend_async
    STA_USERDB_HOST=120.79.26.174 STA_USERDB_NAME=fanxing_changkong_user_db \
    STA_USERDB_USER=fanxing_admin STA_USERDB_PASSWORD='***' \
    python3 scripts/userdb_check.py                 # 只读体检
    python3 scripts/userdb_check.py --init          # 附带幂等建 guantai_ 新表
    python3 scripts/userdb_check.py --probe-user 某用户 --probe-pass 其口令
                                                    # 用真实账号实测口令校验逻辑(不落任何写)

体检项(全部只读,除显式 --init):
  1. 连通性 / 服务器版本 / 库默认字符集 / 时区与 NOW()(due_time 判定的钟)
  2. 当前账号权限(能否 SELECT tb_user、能否 CREATE TABLE)
  3. tb_user 概况:总行数 / user_name 列排序规则(应为 gbk_bin)
  4. pass_word 形态分布(32hex≈MD5 / 40hex≈SHA1 / 64hex≈SHA256 / 其它≈明文)
     —— 观测台的口令校验会自适应全部形态,这里只为让你心里有数
  5. is_off 取值分布(默认把 '1' 视为封停;有其它取值请配 STA_USER_BANNED_VALUES)
  6. due_time 范围与「当前有效账号」数
  7. guantai_ 新表是否已存在(--init 时不存在则建)

docker 部署机上也可在 web 容器里跑(依赖已就位):
    docker compose exec web python3 scripts/userdb_check.py
"""
from __future__ import annotations

import argparse
import json
import os
import re
import secrets
import sys
import threading
import time


def secrets_token() -> str:
    return secrets.token_hex(4)


def _split_sql(raw: str) -> list:
    """把 .sql 文本切成可执行语句列表。规则:单引号字符串('' 为转义)内的一切
    字符(含 ; 与 --)都属于字面量;字符串外,`-- ` 起的行注释吞到行尾,`;` 收束
    一条语句。够用且可预测——本项目 init SQL 只用这两种语法元素。"""
    stmts, buf = [], []
    i, n = 0, len(raw)
    in_str = False
    while i < n:
        ch = raw[i]
        if in_str:
            if ch == "'":
                if i + 1 < n and raw[i + 1] == "'":     # '' 转义
                    buf.append("''")
                    i += 2
                    continue
                in_str = False
            buf.append(ch)
            i += 1
            continue
        if ch == "'":
            in_str = True
            buf.append(ch)
            i += 1
            continue
        if ch == "-" and raw[i:i + 2] == "--":
            j = raw.find("\n", i)
            i = n if j < 0 else j                       # 吞到行尾(保留换行本身)
            continue
        if ch == ";":
            s2 = "".join(buf).strip()
            if s2:
                stmts.append(s2)
            buf = []
            i += 1
            continue
        buf.append(ch)
        i += 1
    tail = "".join(buf).strip()
    if tail:
        stmts.append(tail)
    return stmts

try:
    import pymysql
except ImportError:
    print("缺少 PyMySQL:pip install PyMySQL(requirements.txt 已含)", file=sys.stderr)
    sys.exit(2)

# 允许从 backend_async 根目录直接跑:复用 userauth 的口令校验做 --probe 实测
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def env(k: str, d: str = "") -> str:
    return os.environ.get(k, d) or d


# ══ 多网络入口(4.5.0)══════════════════════════════════════════════════════════
# `STA_USERDB_HOST` 可填一组「同一逻辑库的网络入口」(ip[:port][*权重],逗号分隔),
# 用来把「单个弹性 IP 出口带宽有限」摊开。运行期的选路/熔断/身份校验在
# app/userdb_pool.py;本节是**上线前的实机验证**,与运行期共用同一份解析函数。
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from app.userdb_pool import parse_endpoints, bad_tokens   # 单一真源,杜绝手抄漂移
except Exception:                       # noqa: BLE001 —— 极简兜底(仅当包结构异常)
    def parse_endpoints(raw, default_port):                   # type: ignore[misc]
        out = []
        for t in re.split(r"[,\s;、，]+", str(raw or "").strip()):
            if not t:
                continue
            h, _, rest = t.partition("*")
            host, _, port = h.rpartition(":")
            out.append((host or h, int(port) if host and port.isdigit() else default_port,
                        float(rest or 1)))
        return out

    def bad_tokens(raw):                                      # type: ignore[misc]
        return []

_IDENT_SQL = ("SHOW GLOBAL VARIABLES WHERE Variable_name IN "
              "('server_uuid','server_id','hostname','port','version','read_only')")


def _fingerprint(ident: dict) -> str:
    """身份指纹。MySQL 5.7 有 server_uuid(最强);MariaDB 没有,退回 sid|host|ver。
    用 SHOW 而非 SELECT @@server_uuid —— 后者在没有该变量的服务端会直接报错。"""
    if ident.get("server_uuid"):
        return "uuid:" + ident["server_uuid"]
    sid, hn, ver = ident.get("server_id", ""), ident.get("hostname", ""), ident.get("version", "")
    return f"sid:{sid}|host:{hn}|ver:{ver}" if (sid or hn) else ""


def _connect(a, host, port, timeout=10):
    return pymysql.connect(host=host, port=port, user=a.user, password=a.password,
                           database=a.db, charset=a.charset, connect_timeout=timeout,
                           cursorclass=pymysql.cursors.DictCursor, autocommit=True)


def check_endpoints(a, eps) -> int:
    """逐入口:连通性 / RTT / 身份指纹是否一致 / 是否只读从库。"""
    print("═" * 62)
    print(f"多网络入口体检 —— 共 {len(eps)} 个入口")
    bad = bad_tokens(a.host)
    if bad:
        print(f"⚠️ 有无法解析、已被跳过的片段:{', '.join(bad)}")
    ref, ref_from, rc = "", "", 0
    for host, port, weight in eps:
        tag = f"{host}:{port}" + ("" if weight == 1 else f"*{weight:g}")
        t0 = time.time()
        try:
            conn = _connect(a, host, port)
        except Exception as e:          # noqa: BLE001
            print(f"✗ {tag:28} 连不上:{e!r}")
            rc = 1
            continue
        rtt = (time.time() - t0) * 1000
        try:
            with conn.cursor() as cur:
                cur.execute(_IDENT_SQL)
                ident = {str(r["Variable_name"]).lower(): str(r["Value"]) for r in cur.fetchall()}
                t1 = time.time()
                cur.execute("SELECT 1")
                cur.fetchall()
                q = (time.time() - t1) * 1000
        finally:
            conn.close()
        fp = _fingerprint(ident)
        note = ""
        if not ref:
            ref, ref_from = fp, tag
        elif fp and fp != ref:
            note = "  ⛔ **不是同一个库**(与 " + ref_from + " 指纹不符)"
            rc = 1
        if str(ident.get("read_only", "")).upper() in ("ON", "1"):
            note += "  ⚠️ read_only=ON(若是从库,会话/订单写入会失败)"
        print(f"{'✗' if note.startswith('  ⛔') else '✓'} {tag:28} "
              f"建连 {rtt:6.1f}ms · 空查 {q:5.1f}ms · {fp or '(无指纹)'}{note}")
    print("─" * 62)
    if rc == 0:
        print("✓ 全部入口可达且指纹一致 —— 满足「同一逻辑库的多网络入口」前提")
    else:
        print("✗ 存在不可达或指纹不符的入口 —— 请先处理再启用多入口")
    return rc


def _drain(a, host, port, mb: int) -> float:
    """从一个入口搬 mb 兆下行数据,回实测吞吐 Mbps。

    用 `SELECT REPEAT('x', N)` 让服务端凭空造数据:纯只读、不碰任何表、零副作用,
    且数据量完全可控。单条按 max_allowed_packet 的一半切块(5.7 默认 4MB),
    避免撞包上限。"""
    conn = _connect(a, host, port, timeout=15)
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT @@max_allowed_packet p")
            cap = int(cur.fetchone()["p"])
            chunk = max(64 * 1024, min(2 * 1024 * 1024, cap // 2 - 4096))
            rounds = max(1, (mb * 1024 * 1024) // chunk)
            t0 = time.time()
            for _ in range(rounds):
                cur.execute(f"SELECT REPEAT('x', {chunk}) AS b")
                cur.fetchall()
            dt = max(1e-6, time.time() - t0)
    finally:
        conn.close()
    return (rounds * chunk * 8) / dt / 1e6


def check_bandwidth(a, eps) -> int:
    """先逐个测(拿每个入口的独立上限),再并发测(拿聚合上限)。

    **这是整个多 IP 方案的证伪实验**。云上每个弹性 IP 有各自的带宽封顶,但实例
    (网卡)也有一个总封顶。若几个 EIP 都挂在同一台机器上、且实例总带宽就是瓶颈,
    那么「聚合吞吐 ≈ 单入口吞吐」—— 这时多入口一分钱不赚,方案应当就地取消,
    改去做别的(降低回源频次 / 换更大带宽 / 走内网)。跑完这一节再决定。
    """
    print("═" * 62)
    print(f"入口带宽实测 —— 每入口搬 {a.bw_mb}MB(SELECT REPEAT,只读零副作用)")
    singles = {}
    for host, port, _w in eps:
        tag = f"{host}:{port}"
        try:
            mbps = _drain(a, host, port, a.bw_mb)
        except Exception as e:          # noqa: BLE001
            print(f"✗ {tag:28} 实测失败:{e!r}")
            continue
        singles[tag] = mbps
        print(f"✓ {tag:28} 单独 {mbps:8.2f} Mbps")
    if len(singles) < 2:
        print("ℹ 可用入口不足 2 个,跳过聚合实测")
        return 0 if singles else 1

    res, lock = {}, threading.Lock()

    def _work(host, port, tag):
        try:
            v = _drain(a, host, port, a.bw_mb)
        except Exception:               # noqa: BLE001
            v = 0.0
        with lock:
            res[tag] = v

    ths = [threading.Thread(target=_work, args=(h, p, f"{h}:{p}")) for h, p, _ in eps]
    t0 = time.time()
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    wall = time.time() - t0
    agg = sum(res.values())
    best = max(singles.values())
    print("─" * 62)
    for tag, v in res.items():
        print(f"  并发时 {tag:28} {v:8.2f} Mbps")
    print(f"  聚合 {agg:8.2f} Mbps(墙钟 {wall:.1f}s) · 最好的单入口 {best:8.2f} Mbps"
          f" · 增益 ×{agg / best if best else 0:.2f}")
    print("─" * 62)
    if best and agg >= best * 1.5:
        print("✓ 聚合吞吐显著高于单入口 —— 多入口方案成立,值得上")
        return 0
    print("⚠️ 聚合吞吐没有明显高于单入口 —— 这些 IP 很可能共享同一条物理出口"
          "(实例级带宽封顶)。**多入口方案在此拓扑下不产生收益**,请先解决物理出口,"
          "或改走内网/降低回源频次。")
    return 1


def main() -> int:
    ap = argparse.ArgumentParser(description="登录系统用户库体检")
    ap.add_argument("--host", default=env("STA_USERDB_HOST"))
    ap.add_argument("--port", type=int, default=int(env("STA_USERDB_PORT", "3306")))
    ap.add_argument("--db", default=env("STA_USERDB_NAME"))
    ap.add_argument("--user", default=env("STA_USERDB_USER"))
    ap.add_argument("--password", default=env("STA_USERDB_PASSWORD"))
    ap.add_argument("--charset", default=env("STA_USERDB_CHARSET", "gbk"))
    ap.add_argument("--table", default=env("STA_USERDB_TABLE", "tb_user"))
    ap.add_argument("--init", action="store_true", help="幂等创建 guantai_ 新表")
    ap.add_argument("--reg-preflight", action="store_true",
                    help="注册系统(4.0.0)启用前体检:tb_user 列/口令列长/唯一键/"
                         "INSERT 权限(事务内回滚,零数据副作用)")
    ap.add_argument("--jfvip-preflight", action="store_true",
                    help="九法VIP(4.2.0)上线前实机预检:tb_user 的 UPDATE 权限、"
                         "guantai_jf_* 建表权限、小叮当卡类型时长核对")
    ap.add_argument("--endpoints", action="store_true",
                    help="多网络入口(4.5.0)体检:逐入口连通性 + RTT + 「是不是同一个库」"
                         "身份指纹比对。STA_USERDB_HOST 填了多个 IP 时**上线前必跑**")
    ap.add_argument("--bandwidth", action="store_true",
                    help="逐入口实测下行吞吐 + 并发聚合吞吐(只读,零副作用)。"
                         "**多 IP 方案的成立前提就靠它证伪**:若多个弹性 IP 挂在同一块"
                         "网卡、受实例级带宽封顶,聚合吞吐≈单入口,那这个方案一分钱不赚")
    ap.add_argument("--bw-mb", type=int, default=48, help="--bandwidth 每入口搬运的 MB 数")
    ap.add_argument("--probe-user", default="", help="用真实账号实测口令校验(只读)")
    ap.add_argument("--probe-pass", default="")
    a = ap.parse_args()
    if not (a.host and a.db and a.user):
        print("请给出 --host/--db/--user(或设 STA_USERDB_* 环境变量)", file=sys.stderr)
        return 2

    eps = parse_endpoints(a.host, a.port)
    if not eps:
        print(f"✗ --host 解析不出任何入口:{a.host!r}", file=sys.stderr)
        return 2
    if a.endpoints or a.bandwidth:
        rc = 0
        if a.endpoints:
            rc |= check_endpoints(a, eps)
        if a.bandwidth:
            rc |= check_bandwidth(a, eps)
        return rc
    if len(eps) > 1:
        print(f"ℹ STA_USERDB_HOST 含 {len(eps)} 个网络入口;本次单机体检只连第一个"
              f"({eps[0][0]}:{eps[0][1]})。多入口专项请跑 --endpoints / --bandwidth。")
    a.host, a.port = eps[0][0], eps[0][1]

    print(f"→ 连接 {a.user}@{a.host}:{a.port}/{a.db} charset={a.charset} …")
    try:
        conn = pymysql.connect(host=a.host, port=a.port, user=a.user, password=a.password,
                               database=a.db, charset=a.charset, connect_timeout=10,
                               cursorclass=pymysql.cursors.DictCursor, autocommit=True)
    except Exception as e:
        print(f"✗ 连接失败:{e!r}")
        print("  · 部署机安全组/防火墙需放行 3306;开发沙箱通常仅 80/443 出网,请上部署机跑本脚本")
        return 1

    ok = True
    with conn.cursor() as cur:
        cur.execute("SELECT VERSION() v, @@character_set_database cs, @@collation_database col,"
                    " @@system_time_zone stz, @@time_zone tz, NOW() now_")
        r = cur.fetchone()
        print(f"✓ 服务器 {r['v']} · 库字符集 {r['cs']}/{r['col']} · 时区 {r['stz']}({r['tz']})"
              f" · NOW()={r['now_']}")
        print("  ↳ due_time 到期判定用的正是这只钟(SQL due_time > NOW());请确认与业务口径一致")

        cur.execute("SHOW GRANTS")
        grants = " | ".join(list(g.values())[0] for g in cur.fetchall())
        print(f"✓ 权限:{grants[:300]}{'…' if len(grants) > 300 else ''}")

        # tb_user 概况
        try:
            cur.execute(f"SELECT COUNT(*) n FROM `{a.table}`")
            n = cur.fetchone()["n"]
            cur.execute("SELECT COLLATION_NAME c FROM information_schema.COLUMNS"
                        " WHERE TABLE_SCHEMA=%s AND TABLE_NAME=%s AND COLUMN_NAME='user_name'",
                        (a.db, a.table))
            col = (cur.fetchone() or {}).get("c", "?")
            print(f"✓ {a.table}:{n} 行 · user_name 排序规则 {col}"
                  f"{'(gbk_bin:用户名区分大小写,符合预期)' if col == 'gbk_bin' else ' ⚠️ 非 gbk_bin,请核对'}")
        except Exception as e:
            print(f"✗ 读取 {a.table} 失败:{e!r}"); ok = False; n = 0

        if n:
            cur.execute(f"""
                SELECT CASE
                         WHEN pass_word REGEXP '^[0-9a-fA-F]{{32}}$' THEN 'md5(32hex)'
                         WHEN pass_word REGEXP '^[0-9a-fA-F]{{40}}$' THEN 'sha1(40hex)'
                         WHEN pass_word REGEXP '^[0-9a-fA-F]{{64}}$' THEN 'sha256(64hex)'
                         ELSE '明文/其它'
                       END AS shape, COUNT(*) n
                FROM `{a.table}` GROUP BY shape ORDER BY n DESC""")
            print("✓ pass_word 形态分布(观测台校验自适应全部形态,常数时间比较):")
            for r in cur.fetchall():
                print(f"    {r['shape']:<14} {r['n']}")
            cur.execute(f"SELECT is_off, COUNT(*) n FROM `{a.table}` GROUP BY is_off ORDER BY n DESC")
            rows = cur.fetchall()
            print("✓ is_off 取值分布(默认把 '1' 视为封停;其它取值请配 STA_USER_BANNED_VALUES):")
            for r in rows:
                print(f"    {r['is_off']!r:<8} {r['n']}")
            cur.execute(f"SELECT MIN(due_time) mn, MAX(due_time) mx,"
                        f" SUM(due_time > NOW()) alive FROM `{a.table}`")
            r = cur.fetchone()
            print(f"✓ due_time:{r['mn']} ~ {r['mx']} · 当前有效账号 {int(r['alive'] or 0)}/{n}")

        # guantai_ 新表
        cur.execute("SHOW TABLES LIKE 'guantai\\_%'")
        have = [list(t.values())[0] for t in cur.fetchall()]
        need = {"guantai_user_session", "guantai_login_log",
                "guantai_invite_code", "guantai_reg_log", "guantai_user_block",
                "guantai_sso_ticket"}
        if need <= set(have):
            print(f"✓ 会话/审计表已就绪:{sorted(have)}")
        elif a.init:
            sql_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "init_userdb.sql")
            raw = open(sql_path, encoding="utf-8").read()
            # 引号感知切句:字符串字面量('' 转义)内的 ; 与 -- 都不作数——
            # 4.0.0 复查发现旧的「剥行 + 硬切 ;」会把 COMMENT 里的分号当句尾,
            # 从字符串中间腰斩语句(1064)。一次修根因,注释再怎么写都切不坏。
            for stmt in _split_sql(raw):
                cur.execute(stmt)
            print("✓ 已幂等创建全部 guantai_ 新表(会话/审计 + 注册三表;未触碰任何既有表)")
        else:
            print(f"· guantai_ 新表尚不存在({sorted(set(have))});web 首启会自动建,"
                  f"或本脚本加 --init 现在建")

        # ── 注册系统(4.0.0)启用前体检 ────────────────────────────────────
        if a.reg_preflight:
            print("─" * 62)
            print("注册系统(4.0.0)预检:")
            # ① 全列点名 + NOT NULL 且无默认 → EXTRA_COLS 建议
            cur.execute(f"SHOW FULL COLUMNS FROM `{a.table}`")
            cols = cur.fetchall()
            base = {"id", "user_name", "pass_word", "due_time", "is_off"}
            need_extra = {}
            print("  ① tb_user 全列:")
            pw_len = None
            pw_typ = ""
            for c in cols:
                fld = c.get("Field")
                typ = str(c.get("Type") or "")
                base_t = typ.lower().split("(", 1)[0].strip()
                nullable = str(c.get("Null") or "").upper() == "YES"
                default = c.get("Default")
                extra = str(c.get("Extra") or "")
                auto = "auto_increment" in extra
                gen = "GENERATED" in extra.upper()   # 生成列(STORED/VIRTUAL;MySQL 8
                #   允许 NOT NULL 且 SHOW 报 Default=NULL,但 INSERT 不可也不必供值)
                flag = ""
                if str(fld).lower() == "pass_word":
                    m = re.search(r"\((\d+)\)", typ)
                    pw_len = int(m.group(1)) if m else None
                    pw_typ = typ
                if (not nullable) and default is None and not auto and not gen \
                        and base_t != "enum" and str(fld).lower() not in base:
                    flag = "  ← NOT NULL 且无默认 → 需在 EXTRA_COLS 提供"
                    # 类型化建议值(MariaDB 10.11 + MySQL 8.0 严格模式双引擎实测可插):
                    if base_t in ("datetime", "timestamp", "date"):
                        need_extra[fld] = "$now"          # 展开为 NOW()
                    elif base_t == "time":
                        need_extra[fld] = "00:00:00"
                    elif base_t == "set":
                        ms = re.match(r"set\('([^']*)'", typ, re.I)
                        need_extra[fld] = ms.group(1) if ms else ""  # 首字面量,保留原大小写(_bin 排序规则下才可插)
                    elif base_t == "json":
                        need_extra[fld] = "{}"            # 空串非法 JSON,会被拒
                    elif base_t in ("int", "bigint", "smallint", "tinyint",
                                    "mediumint", "decimal", "float", "double",
                                    "numeric", "bit", "year"):
                        need_extra[fld] = 0               # 数值列:空串在严格模式下会被拒
                    else:
                        need_extra[fld] = ""
                elif gen and (not nullable) and default is None:
                    flag = "  ← 生成列:INSERT 不可供值,自动计算(无需 EXTRA_COLS)"
                elif base_t == "enum" and (not nullable) and default is None and not auto:
                    flag = "  ← ENUM:省略即隐式首枚举值(双引擎实测),无需 EXTRA_COLS"
                print(f"     {fld:<20} {typ:<22} "
                      f"{'NULL' if nullable else 'NOT NULL'}"
                      f"{' auto_inc' if auto else ''}{' generated' if gen else ''}{flag}")
            if need_extra:
                print("     ↳ 建议 STA_USER_REG_EXTRA_COLS(照抄,按需改值):")
                print(f"        {json.dumps(need_extra, ensure_ascii=False)}")
            else:
                print("     ↳ 基础四列外无强制列 —— STA_USER_REG_EXTRA_COLS 可留空")

            # ② pass_word 真实列长(裁决 C7)+ 形态建议(多数派)
            print(f"  ② pass_word 列长:{pw_typ or f'varchar({pw_len})'}")
            _need_len = (("plain", 16), ("md5", 32), ("sha1", 40), ("sha256", 64))
            if pw_len is not None:
                fits = [s for s, req in _need_len if pw_len >= req]
                lack = [f"{s}(需≥{req})" for s, req in _need_len if pw_len < req]
                if lack:
                    print(f"     ↳ 列长 {pw_len}:可选形态 {' / '.join(fits) or '(无!须扩列)'}"
                          f";放不下 {' / '.join(lack)}")
                else:
                    print("     ↳ 列长 ≥64 —— 四种形态均可(如你的续费系统用 sha256 存)")
            else:
                print("     ↳ 未解析出定长(如 TEXT 类)—— 四种形态均放得下")
            if n:
                cur.execute(f"""
                    SELECT CASE
                             WHEN pass_word REGEXP '^[0-9a-fA-F]{{32}}$' THEN 'md5'
                             WHEN pass_word REGEXP '^[0-9a-fA-F]{{40}}$' THEN 'sha1'
                             WHEN pass_word REGEXP '^[0-9a-fA-F]{{64}}$' THEN 'sha256'
                             ELSE 'plain'
                           END AS shape, COUNT(*) n
                    FROM `{a.table}` GROUP BY shape ORDER BY n DESC""")
                dist = cur.fetchall()
                top = dist[0]["shape"] if dist else "plain"
                print("     ↳ 存量形态分布:" + " · ".join(
                    f"{r['shape']}={r['n']}" for r in dist))
                print(f"     ↳ 建议 STA_USER_REG_PASS_SHAPE={top}(多数派;**务必确认与你"
                      f"续费系统登录校验一致**——这是跨系统契约,只有你能拍板)")

            # ③ user_name 唯一键实存性
            cur.execute(f"SHOW INDEX FROM `{a.table}`")
            idx = cur.fetchall()
            uniq_on_name = any(str(i.get("Column_name")) == "user_name"
                               and int(i.get("Non_unique", 1)) == 0 for i in idx)
            if uniq_on_name:
                print("  ③ user_name 唯一键:存在 ✓(1062 撞键即最终重名闸)")
            else:
                print("  ③ user_name 唯一键:**不存在** ⚠️ —— 注册将启用 Redis 名义锁"
                      "兜底并发重名(仍安全,但强烈建议为 user_name 建唯一索引)")

            # ④ INSERT 权限探针(事务内回滚;零数据副作用)
            probe_name = "__guantai_reg_probe__" + secrets_token()
            try:
                cur.execute("START TRANSACTION")
                try:
                    cols_i = ["user_name", "pass_word", "due_time", "is_off"]
                    exprs = ["%s", "%s", "NOW()", "%s"]
                    vals = [probe_name, "x", "0"]
                    for k, v in need_extra.items():
                        cols_i.append(k)
                        if v == "$now":
                            exprs.append("NOW()")
                        else:
                            exprs.append("%s")
                            vals.append(v)
                    cur.execute(
                        f"INSERT INTO `{a.table}` "
                        f"({', '.join('`' + x + '`' for x in cols_i)}) "
                        f"VALUES ({', '.join(exprs)})", tuple(vals))
                    print("  ④ INSERT 权限:具备 ✓(探针行已在事务内 ROLLBACK,"
                          "零数据副作用;注:AUTO_INCREMENT 计数会前进一格)")
                finally:
                    cur.execute("ROLLBACK")
            except Exception as e:
                print(f"  ④ INSERT 权限:**不足或建列不匹配** ✗ {e!r}")
                print("     ↳ 账号需 INSERT on tb_user;若报未知列请据 ① 补 EXTRA_COLS")
                ok = False

            # ⑤ guantai_ 三新表(--init 时建)
            cur.execute("SHOW TABLES LIKE 'guantai\\_%'")
            have5 = {list(t.values())[0] for t in cur.fetchall()}
            need5 = {"guantai_invite_code", "guantai_reg_log", "guantai_user_block"}
            if need5 <= have5:
                print("  ⑤ 注册三新表已就绪 ✓")
            elif a.init:
                pass   # 下方 --init 分支统一建(含登录两表)
            else:
                print(f"  ⑤ 注册三新表缺 {sorted(need5 - have5)};web 首启会自动建,"
                      f"或加 --init 现在建")
            print("─" * 62)


        if a.jfvip_preflight:
            # ══════════════════════════════════════════════════════════════
            # 九法 VIP 上线前预检(4.2.0)。三件事,任何一件不过就**不要开**
            # STA_JF_VIP —— 收了钱开不出会员是最不能接受的故障。
            # 全部只读/回滚,绝不留下任何副作用。
            # ══════════════════════════════════════════════════════════════
            print("═" * 62)
            print("九法VIP 预检")
            ok_all = True

            # ① tb_user 的 UPDATE 权限 —— 赠送小叮当时长的命门。
            #    做法:开一个事务,对**一行都不匹配**的条件执行真实 UPDATE 语句,
            #    再 ROLLBACK。语句形态与线上完全一致(DATE_ADD+GREATEST),
            #    权限不足会当场报 1142;WHERE id=0 保证零行受影响。
            try:
                conn.begin()
                cur.execute(
                    f"UPDATE `{a.table}` SET due_time = "
                    f"DATE_ADD(GREATEST(NOW(), due_time), INTERVAL 0 HOUR) "
                    f"WHERE id = 0")
                affected = cur.rowcount
                conn.rollback()
                print(f"  ① tb_user UPDATE 权限 ✓(试写 0 行、已回滚,"
                      f"rowcount={affected})")
            except Exception as e:
                conn.rollback()
                ok_all = False
                print(f"  ① ✗ tb_user 无 UPDATE 权限或语句被拒:{e!r}")
                print("     → 赠送小叮当时长将失败。请先授权:")
                print(f"        GRANT UPDATE ON {a.db}.{a.table} TO '{a.user}'@'%';")

            # ② guantai_jf_* 四张新表:能否幂等自建
            try:
                cur.execute("SHOW TABLES LIKE 'guantai\\_jf\\_%'")
                have = {list(t.values())[0] for t in cur.fetchall()}
                need = {"guantai_jf_vip", "guantai_jf_order",
                        "guantai_jf_card", "guantai_jf_grant_log"}
                if need <= have:
                    print(f"  ② 九法VIP 四表已就绪 ✓")
                else:
                    print(f"  ② 九法VIP 表缺 {sorted(need - have)}"
                          f"(web 首启会自动幂等建,或加 --init)")
                    # 试探建表权限(建一张临时表再删)
                    try:
                        conn.begin()
                        cur.execute("CREATE TABLE IF NOT EXISTS "
                                    "guantai_jf_preflight_probe (id INT PRIMARY KEY)")
                        cur.execute("DROP TABLE IF EXISTS guantai_jf_preflight_probe")
                        conn.commit()
                        print("     建表权限 ✓(已清理探针表)")
                    except Exception as e:
                        conn.rollback()
                        ok_all = False
                        print(f"     ✗ 无建表权限:{e!r}")
            except Exception as e:
                print(f"  ② 检查异常:{e!r}")

            # ③ 小叮当卡类型时长核对 —— 档位默认值 744h/2232h 的依据。
            #    这个值来自参考项目的注释自述,**必须自己核一遍**:
            #    错了会导致「1个月」实际送成别的时长,是直接的资损/客诉。
            try:
                cur.execute("SELECT card_name, recharge_length "
                            "FROM tb_user_recharge_type ORDER BY recharge_length")
                rows = cur.fetchall()
                if not rows:
                    print("  ③ tb_user_recharge_type 为空 —— 无法核对档位时长")
                else:
                    print("  ③ 小叮当卡类型(recharge_length 单位=小时):")
                    m = {}
                    for r in rows:
                        nm = str(r["card_name"])
                        hs = int(r["recharge_length"])
                        m[nm] = hs
                        print(f"       {nm:<10s} {hs:>6d}h = {hs / 24:.1f} 天")
                    for want_name, want_h, plan in (("月卡", 744, "m1"),
                                                    ("季卡", 2232, "m3")):
                        got = m.get(want_name)
                        if got is None:
                            print(f"     ⚠ 未找到「{want_name}」—— 档位 {plan} 的"
                                  f"默认 {want_h}h 无法据此对齐,请人工确认")
                        elif got != want_h:
                            ok_all = False
                            print(f"     ✗ 「{want_name}」实为 {got}h,而档位 {plan} "
                                  f"默认写的是 {want_h}h —— **必须改** "
                                  f"STA_JF_VIP_PLANS 的 ddHours/jfHours")
                        else:
                            print(f"     ✓ 「{want_name}」{got}h 与档位 {plan} 默认一致")
            except Exception as e:
                print(f"  ③ 无法读取 tb_user_recharge_type:{e!r}")

            print("─" * 62)
            print(("预检通过 —— 可以开启 STA_JF_VIP=1" if ok_all
                   else "✗ 预检未通过 —— **请勿开启 STA_JF_VIP**,先解决上面的问题"))
            print("═" * 62)
            if not ok_all:
                return 1

        if a.probe_user:
            try:
                from app.userauth import verify_password  # noqa: PLC0415
            except Exception as e:
                print(f"✗ 无法导入 app.userauth(请在 backend_async 目录下运行):{e!r}")
                return 1
            cur.execute(f"SELECT id, pass_word, is_off, due_time, (due_time > NOW()) alive"
                        f" FROM `{a.table}` WHERE user_name=%s", (a.probe_user,))
            r = cur.fetchone()
            if not r:
                print(f"✗ probe:用户 {a.probe_user!r} 不存在(注意 gbk_bin 区分大小写)")
                ok = False
            else:
                good = verify_password(a.probe_pass, r["pass_word"])
                print(f"{'✓' if good else '✗'} probe:口令校验 {'通过' if good else '不通过'}"
                      f" · is_off={r['is_off']!r} · 有效期内={bool(r['alive'])}(至 {r['due_time']})")
                ok = ok and good

    conn.close()
    print("═" * 62)
    print("体检结论:" + ("可以启用登录系统 ✓" if ok else "存在问题,请先处理 ✗"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
