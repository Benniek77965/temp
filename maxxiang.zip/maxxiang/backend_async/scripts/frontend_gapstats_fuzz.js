/* frontend_gapstats_fuzz.js — 连空口径 + 快照并集「对拍模糊测试」(4.4.0)
   用法:项目根 `node backend_async/scripts/frontend_gapstats_fuzz.js [组数]`
        `--js <混淆产物路径>` 可对产物跑同一套(与其它前端套件同款约定)

   ── 为什么必须有这一份 ────────────────────────────────────────────────────
   连空(未出场)是本产品的核心读数,而 4.4.0 起它有**三种展示形态**,每种是一句
   不同强度的断言:

       `N`        精确 —— 真值恰等于 N
       `lo~hi`    区间 —— 真值必落在 [lo, hi] 内
       `≥lo`      开区间 —— 只声明下界,上不封顶

   这三句话如果有一句站不住,就是在用户面前撒谎。而它们的正确性依赖于「哪些格点
   被观测到、哪些没有」的组合爆炸,**人眼审不出来**:四轮复审里,前三轮都靠人眼
   遍历,前三轮都漏了东西;第四轮换成本脚本,当场抓到一个人眼三轮没看见的真 bug ——
   「窗内从未出现」的号位被配了一个闭区间上界,而它其实上不封顶(实测 2127 组样本
   中 1.8% 的真值落在所谓上界之外;无断口时更糟,直接显示成单数仿佛精确)。

   ── 方法 ────────────────────────────────────────────────────────────────
   随机生成一段**完整真值**(连续格点 + 随机号位),再随机挖掉一部分模拟「未观测」,
   把剩下的喂给生产版 deriveStats/gapText(直接从 assets/app.js 抠原文执行,零改写),
   然后按各自形态验证语义。真值是脚本自己造的,故「正确答案」不依赖被测代码。

   退出码 0 = 全部形态语义成立;2 = 有反例(会打印前若干条)。
*/
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..');
const _ARGJ = process.argv.indexOf('--js');
const APPJS = _ARGJ > 0 ? process.argv[_ARGJ + 1] : ROOT + '/assets/app.js';
const ROUNDS = Number(process.argv[2]) > 0 ? Number(process.argv[2]) : 8000;

const T = { ROUND: 50001 };
const src = fs.readFileSync(APPJS, 'utf8');

/* 从源码抠出被测函数原文。混淆产物里标识符已被重命名,抠不到 —— 那是预期的:
   本脚本验的是**算法语义**,产物的整机行为由 frontend_jfvip_jsdom.js 负责。 */
const i0 = src.indexOf('function deriveStats(){');
const i1 = src.indexOf('function officialProb(n){');
if (i0 < 0 || i1 < 0 || i1 <= i0) {
  console.error('抠不到 deriveStats/gapText 原文 —— 本脚本只能跑**源码**版。');
  console.error('(产物版整机验收请跑 frontend_jfvip_jsdom.js --js <产物>)');
  process.exit(1);
}
const CODE = src.slice(i0, i1) + '; return { deriveStats, gapText };';
const make = hist => new Function('S', 'T', 'midnight', CODE)({ hist }, T, () => 0);

let bad = 0;
const examples = [];
const cnt = { exact: 0, range: 0, open: 0 };
let groups = 0;

for (let seed = 1; seed <= ROUNDS; seed++) {
  let x = (seed * 2654435761) % 4294967296;
  const rnd = () => ((x = (x * 1103515245 + 12345) % 2147483648) / 2147483648);

  // ① 完整真值:N 个**连续**格点(与「九法 24h 连续出怪」的架构前提一致)
  const N = 6 + Math.floor(rnd() * 50);
  const base = 1783000000000;
  const truth = [];
  for (let i = 0; i < N; i++) truth.push({ start: base + i * T.ROUND, n: 1 + Math.floor(rnd() * 9) });

  // ② 随机挖洞 = 用户没在线的那些局
  const seen = truth.filter(() => rnd() > 0.22);
  if (seen.length < 2) continue;
  // 最新一局必须看到 —— 与实况一致(序列的锚点就是最新一局)
  if (seen[seen.length - 1].start !== truth[truth.length - 1].start) continue;
  groups++;

  const hist = seen.slice().reverse();          // S.hist 恒为「新 → 旧」
  const F = make(hist);
  const st = F.st || F.deriveStats();
  const latest = hist[0].start;

  for (let n = 1; n <= 9; n++) {
    let last = -1;
    for (const r of truth) if (r.n === n) last = r.start;
    if (last < 0) continue;                     // 真值里也从未出现 → 无真值可对
    const real = Math.round((latest - last) / T.ROUND);
    const txt = F.gapText(st, n);
    const lo = st.gap[n], hi = st.gapHi[n];

    /* ★ 判据必须从**用户真正看到的那串字**反解,不能读内部标志位。
       初版就是读 st.gapOpen/gapMin 判形态 —— 结果做反向自检(故意打坏 gapText)
       时脚本照样全绿:它验的是数据,不是渲染,而用户看的是渲染。
       一个打不红的测试等于没有测试。现改为解析 txt 本身。 */
    let ok, form, m;
    if ((m = /^≥(\d+)$/.exec(txt))) { form = 'open'; ok = real >= Number(m[1]); }
    else if ((m = /^(\d+)~(\d+)$/.exec(txt))) {
      form = 'range';
      ok = Number(m[1]) <= Number(m[2]) && real >= Number(m[1]) && real <= Number(m[2]);
    }
    else if ((m = /^(\d+)$/.exec(txt))) { form = 'exact'; ok = real === Number(m[1]); }
    else { form = 'exact'; ok = false; }        // 认不出的形态一律判负(防新增形态无人验)
    cnt[form]++;
    if (!ok) {
      bad++;
      if (examples.length < 8)
        examples.push(`seed=${seed} n=${n} 形态=${form} 真值=${real} UI="${txt}" (lo=${lo} hi=${hi} 断口=${st.holes})`);
    }
  }
}

/* ═══ 第二部分:快照并集(mergeEnc / clampEnc)的属性对拍 ═══════════════════
   落盘必须**单调不减** —— 同账号同房两个标签页各自 saveSnapshot 时,覆盖式写盘
   会让陈旧的一页把另一页积累的满窗抹掉(典型:被租约挤下、长期不再 ingest 的
   标签页,在关闭时的 saveSnapshot 里写回它较少的历史)。并集式写盘让这一整类
   竞态**结构上不存在**。
   ★ 建模必须用「同一份真值 + 各自观测子集」:初版给两页生成了两份独立随机数据,
     于是同一格点上 A 说 7、B 说 2 —— 现实中两页看的是同一场出怪,这种冲突不可能
     发生。用错的模型跑出 4699 个"违反",差点让我去改一个没坏的实现。 */
let mbad = 0;
const mex = [];
{
  const i2 = src.indexOf('function mergeEnc(prev, cur){');
  const i3 = src.indexOf('function decodeHist(b, str, spells){');
  if (i2 < 0 || i3 < 0) { console.error('抠不到 mergeEnc/clampEnc 原文'); process.exit(1); }
  const M = new Function('T', 'HIST_CAP',
    src.slice(i2, i3) + '; return { mergeEnc, clampEnc };')(T, 2200);
  const obs = e => { const m = new Map();
    for (let i = 0; i < e.r.length; i++) if (e.r[i] !== '0') m.set(e.b + i * T.ROUND, e.r[i]);
    return m; };
  for (let seed = 1; seed <= ROUNDS; seed++) {
    let x = (seed * 2654435761) % 4294967296;
    const rnd = () => ((x = (x * 1103515245 + 12345) % 2147483648) / 2147483648);
    const base = 1783000000000;
    const N = 10 + Math.floor(rnd() * 80);
    const truth = []; for (let i = 0; i < N; i++) truth.push(String(1 + Math.floor(rnd() * 9)));
    const view = () => { const a = truth.map(c => (rnd() > 0.3 ? c : '0'));
      let from = 0; while (from < a.length && a[from] === '0') from++;
      let to = a.length - 1; while (to >= 0 && a[to] === '0') to--;
      return from > to ? null : { b: base + from * T.ROUND, r: a.slice(from, to + 1).join('') }; };
    const A = view(), B = view(); if (!A || !B) continue;
    const G = M.mergeEnc(A, B), oa = obs(A), ob = obs(B), og = obs(G);
    const fail = m => { mbad++; if (mex.length < 4) mex.push(`seed=${seed} ${m}`); };
    for (const [k, v] of [...oa, ...ob]) if (og.get(k) !== v) { fail('并集丢点'); break; }
    for (const [k, v] of og) if (oa.get(k) !== v && ob.get(k) !== v) { fail('并集凭空多点'); break; }
    if (og.size < Math.max(oa.size, ob.size)) fail('非单调');
    const H = 0.5 + rnd() * 24, C = M.clampEnc(G, H);
    if (C) { const oc = obs(C), newest = G.b + (G.r.length - 1) * T.ROUND, cut = newest - H * 3600e3;
      for (const [k, v] of oc) if (og.get(k) !== v) { fail('裁窗凭空'); break; }
      for (const [k, v] of og) if (k >= cut && oc.get(k) !== v) { fail('裁窗误删窗内'); break; } }
  }
}

const tot = cnt.exact + cnt.range + cnt.open;
console.log('连空口径对拍模糊测试');
console.log(`  有效组数 ${groups} / ${ROUNDS},共 ${tot} 次判定`);
console.log(`  形态分布:精确 ${cnt.exact} · 区间 ${cnt.range} · 开区间 ${cnt.open}`);
console.log(`  违反各自语义 = ${bad}`);
examples.forEach(e => console.log('   ✗ ' + e));
console.log(`快照并集属性对拍(同真值 · 双视图)`);
console.log(`  违反并集/单调/裁窗性质 = ${mbad}`);
mex.forEach(e => console.log('   ✗ ' + e));
if (bad || mbad) {
  console.log('\n✗ 连空展示与真值不符 —— 这是直接摆在用户面前的数字,必须修好再发。');
  process.exit(2);
}
console.log('\n✓ 三种展示形态各自的断言全部成立;快照并集单调不减');
