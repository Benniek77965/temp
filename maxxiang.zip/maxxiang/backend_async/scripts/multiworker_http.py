"""multiworker_http.py — 多 worker 真实 HTTP 栈的并发核查(4.2.9 第九轮)

── 为什么必须有这一份 ──────────────────────────────────────────────────────────
第八轮已用 `idem_multiprocess.py` 证明了 `SET NX` 的**跨进程原子性**,但那是直接调
`jfvip.idem_begin`,**绕过了 HTTP 层**。而生产形态是 `uvicorn --workers N`:
请求由 OS 分发到不同进程,途中还要过中间件、鉴权、闸序、限频。
「函数层原子」不等于「端点在多进程下不超发」——中间任何一步用了**进程内**状态,
多进程下就会各算各的。

本脚本起真 uvicorn(多 worker)+ 真 Redis + 真 MariaDB + 真 PostgreSQL,
打真 HTTP,核两件在多进程下最容易失守的事:

  ① **幂等**:N 路并发同一个 idempotencyKey ⇒ 库里必须恰好一批卡、
     所有 200 响应必须回**同一组卡号**;
  ② **限频**:cap=M 时 N 路并发 ⇒ 实际发出的批数必须 ≤ M。
     限频用 Redis INCR(跨进程共享);若哪天退化成进程内计数,
     4 个 worker 就会各放行 M 次 —— 这条只有多进程测得出来。

实测(2026-07,4 workers,40 路并发):
    幂等 → 3×200(1 首发 + 2 重放)+ 37×409,库里恰好 5 张,卡号 1 组 ✅
    限频 cap=5 / 30 路 → 实发 5 批 ✅

用法(四个服务缺任一则整体跳过,不阻断主干):
    python3 backend_async/scripts/multiworker_http.py
    # 需要:MariaDB(STA_USERDB_*)、Redis、PostgreSQL、以及本机可起 uvicorn
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor

_HERE = os.path.dirname(os.path.abspath(__file__))
_BACKEND = os.path.dirname(_HERE)

PORT = int(os.environ.get("STA_TEST_HTTP_PORT", "8799"))
WORKERS = int(os.environ.get("STA_TEST_WORKERS", "4"))
KEY = "k" * 64
BASE = f"http://127.0.0.1:{PORT}"
PASS = FAIL = 0


def A(name, ok, extra=""):
    global PASS, FAIL
    print(f"  [{'✓' if ok else '✗'}] {name}" + ("" if ok else f"  → {extra}"))
    if ok:
        PASS += 1
    else:
        FAIL += 1


def _up(host, port) -> bool:
    try:
        with socket.create_connection((host, port), timeout=1):
            return True
    except OSError:
        return False


def _env(rate: int) -> dict:
    e = dict(os.environ)
    e.update({
        "STA_PG_DSN": os.environ.get(
            "STA_TEST_PG_DSN", "postgresql://star:star@127.0.0.1:5433/spelltamer"),
        "STA_REDIS_URL": os.environ.get("STA_TEST_REDIS_URL",
                                        "redis://127.0.0.1:6380/0"),
        "STA_ADMIN_PASSWORD": "admin-pw-test",
        # ★ 多 worker 必须固定签名密钥:未显式设置时由密码材料派生(仍一致),
        #   但显式设更稳,也顺带说明「随机密钥会让会话在 worker 间来回失效」。
        "STA_ADMIN_SECRET": "fixed-secret-so-all-workers-agree",
        "STA_USERDB_HOST": "127.0.0.1", "STA_USERDB_PORT": "3307",
        "STA_USERDB_NAME": os.environ.get("STA_TEST_USERDB_NAME", "fx_demo_e2e"),
        "STA_USERDB_USER": "root", "STA_USERDB_PASSWORD": "",
        "STA_USERDB_CHARSET": "gbk",
        "STA_JF_VIP": "1", "STA_JF_CARD_API": "1", "STA_JF_CARD_API_KEY": KEY,
        "STA_JF_CARD_API_RATE_HOURLY": str(rate),
    })
    return e


def _post(body: dict, timeout=25):
    req = urllib.request.Request(
        f"{BASE}/api/admin/jfvip/cards/issue",
        data=json.dumps(body).encode(), method="POST",
        headers={"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:                   # noqa: BLE001
            return e.code, {}
    except Exception as e:                  # noqa: BLE001
        return 0, {"error": repr(e)}


def _serve(rate: int):
    # ★ 本脚本自身的缺陷回归钉(第九轮实测踩到):端口若被**上一轮残留**的服务占着,
    #   新 uvicorn 绑定失败,而下面的健康检查会从那个陈旧服务拿到 200 ⇒ 脚本把测试
    #   打在了一个**用着别的配置**的进程上。我就是这样得出过一条「限频完全失效」的
    #   **假结论**(实为在 rate=0 的残留服务上测 cap=5)。
    #   测试工具产出假结论,比没有测试更糟 —— 故:端口非空即拒绝启动。
    if _up("127.0.0.1", PORT):
        raise RuntimeError(
            f"端口 {PORT} 已被占用 —— 拒绝启动。残留服务会让本脚本测在错误的配置上"
            f"(真实踩过,据此得出过一条『限频失效』的假结论)。"
            f"请先 `pkill -f 'uvicorn app.web:app'` 或改 STA_TEST_HTTP_PORT。")
    p = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "app.web:app", "--host", "127.0.0.1",
         "--port", str(PORT), "--workers", str(WORKERS), "--log-level", "error"],
        cwd=_BACKEND, env=_env(rate),
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(60):
        time.sleep(1)
        if p.poll() is not None:      # 子进程已退出(绑定失败等)⇒ 别空等 60s
            raise RuntimeError(f"uvicorn 启动失败(退出码 {p.returncode})")
        try:
            with urllib.request.urlopen(f"{BASE}/api/version", timeout=2) as r:
                if r.status == 200:
                    return p
        except Exception:                   # noqa: BLE001
            pass
    p.kill()
    raise RuntimeError("uvicorn 未能在 60s 内就绪")


def _cards_in(batch: str) -> int:
    import pymysql
    c = pymysql.connect(host="127.0.0.1", port=3307, user="root", password="",
                        database=_env(0)["STA_USERDB_NAME"], charset="gbk")
    try:
        with c.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM guantai_jf_card WHERE batch=%s", (batch,))
            return int(cur.fetchone()[0])
    finally:
        c.close()


def _wipe(batch: str):
    import pymysql
    import redis
    redis.from_url(_env(0)["STA_REDIS_URL"]).flushall()
    c = pymysql.connect(host="127.0.0.1", port=3307, user="root", password="",
                        database=_env(0)["STA_USERDB_NAME"], charset="gbk")
    try:
        with c.cursor() as cur:
            cur.execute("DELETE FROM guantai_jf_card WHERE batch=%s", (batch,))
        c.commit()
    finally:
        c.close()


def main() -> int:
    need = [("MariaDB", "127.0.0.1", 3307), ("Redis", "127.0.0.1", 6380),
            ("PostgreSQL", "127.0.0.1", 5433)]
    down = [n for n, h, p in need if not _up(h, p)]
    if down:
        print(f"[跳过] 缺少 {', '.join(down)} —— 多 worker HTTP 核查需要真实全栈;"
              f"函数层的跨进程原子性由 idem_multiprocess.py 覆盖。")
        return 0

    # ── ① 幂等:40 路并发同一个键 ────────────────────────────────────────
    print(f"\n[幂等 · {WORKERS} workers × 40 路并发同一 idempotencyKey]")
    _wipe("MPRACE")
    srv = _serve(rate=0)
    try:
        body = {"hours": 24, "count": 5, "batch": "MPRACE",
                "idempotencyKey": "http-race-1"}
        with ThreadPoolExecutor(max_workers=40) as ex:
            rs = list(ex.map(lambda _: _post(body), range(40)))
        codes = {}
        for st, _ in rs:
            codes[st] = codes.get(st, 0) + 1
        oks = [d for st, d in rs if st == 200 and d.get("ok")]
        sets = {tuple(sorted(d["cards"])) for d in oks if d.get("cards")}
        n = _cards_in("MPRACE")
        A(f"库里恰好一批(实得 {n} 张,期望 5)", n == 5, f"状态码 {codes}")
        A(f"所有成功响应回同一组卡号(实得 {len(sets)} 组)", len(sets) == 1)
        A("非首发一律 409/200,无 5xx", all(st in (200, 409) for st, _ in rs), codes)
        A("确有并发发生(不是被串行化)", codes.get(409, 0) >= 1, codes)
    finally:
        srv.kill(); srv.wait()

    # ── ② 限频:cap=5,30 路并发无幂等键 ─────────────────────────────────
    print(f"\n[限频 · {WORKERS} workers × 30 路并发,cap=5]")
    _wipe("MPRATE")
    srv = _serve(rate=5)
    try:
        with ThreadPoolExecutor(max_workers=30) as ex:
            rs = list(ex.map(
                lambda i: _post({"hours": 24, "count": 1, "batch": "MPRATE"}),
                range(30)))
        ok = sum(1 for st, d in rs if st == 200 and d.get("ok"))
        n = _cards_in("MPRATE")
        # 限频用 Redis INCR(跨进程共享)。若退化成进程内计数,4 个 worker
        # 会各放行 5 次 ⇒ 实发 20 批。
        A(f"未超发(实发 {n} 批,上限 5)", n <= 5, f"200×{ok}")
        A(f"确实放行了应放行的(实发 {n} ≥ 1)", n >= 1)
        A("超限一律 429", all(st in (200, 429) for st, _ in rs),
          {st for st, _ in rs})
    finally:
        srv.kill(); srv.wait()

    print("\n" + "─" * 54)
    print(f"多 worker 真实 HTTP 核查:{PASS} 通过 / {FAIL} 失败")
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
