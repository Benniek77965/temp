#!/usr/bin/env python3
"""
seed_rooms.py — 批量把房间注入名录(Redis 名录 + PG rooms 表)
================================================================================
把要监控的房间灌进系统。worker 的 janitor 会在下个周期(默认 30s)自动接管抓取;
本脚本经**批量准入控制器**给每个房排一个错峰起抓的 MainPage 任务,并对短号做归一。

【重构要点】旧实现是一个**严格串行**的 for 循环:每房 `await canon -> upsert -> schedule`
一个接一个。5000 房 = 5000 次串行网络往返,可能要跑数十分钟到数小时。现改为经
`app.admission.admit_rooms`:去重 -> **有界并发归一(过繁星令牌桶,不惊群)** ->
**批量落库/登记** -> **首抓错峰铺开**。5000 房归一从「串行数千往返」变为「有界并发
一次跑完」,落库从「逐房 N 次往返」变为「批量 ~1 次/批」。安全且快。

来源(优先级):命令行房号 > --file 每行一个 > config.yaml 的 rooms。
房号可为短号/靓号,归一失败的房进挂起集(worker janitor 后续自动重试归一并转正;
只读查询按原号最多得到空结果,无害)。

用法:
    python -m scripts.seed_rooms 321 2678075
    python -m scripts.seed_rooms --file rooms.txt          # 每行一个,支持数千房
    python -m scripts.seed_rooms                            # 仅注入 config.yaml 里的 rooms
    python -m scripts.seed_rooms --list                    # 打印当前名录后退出
    python -m scripts.seed_rooms --no-canon 2678075        # 跳过归一,按原号注入
    python -m scripts.seed_rooms --concurrency 48 --file big.txt   # 覆盖归一并发
"""
from __future__ import annotations

import argparse
import asyncio
import dataclasses
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.admission import admit_rooms              # noqa: E402
from app.db import DB                               # noqa: E402
from app.ratelimit import TokenBucket              # noqa: E402
from app.redis_bus import RedisBus                 # noqa: E402
from app.settings import settings                   # noqa: E402
from app.starmeta import StarMeta                   # noqa: E402


async def _seed(rooms: list, do_canon: bool, concurrency: int) -> None:
    db = DB(settings.pg_dsn, settings.pg_pool_min, settings.pg_pool_max)
    bus = RedisBus(settings.redis_url,
                   max_connections=max(settings.redis_max_connections,
                                       (concurrency or settings.admission.canon_concurrency) + 32),
                   pool_timeout=settings.redis_pool_timeout)
    # 归一走繁星令牌桶(与 web/worker 同一路,跨进程共享),并接跨进程归一缓存。
    fx_rl = TokenBucket(bus.r, "rl:fanxing",
                        settings.ratelimit.fanxing_rps, settings.ratelimit.fanxing_burst)
    star = StarMeta(conn_limit=settings.starmeta_conn_limit, bucket=fx_rl, redis=bus.r)
    await db.connect()
    await db.migrate()
    await star.start()
    # 允许命令行覆盖归一并发(其余准入参数取 config)
    cfg = settings.admission
    if concurrency and concurrency > 0:
        cfg = dataclasses.replace(cfg, canon_concurrency=int(concurrency))
    try:
        t0 = time.monotonic()
        print("批量注入 %d 个房间(归一并发=%d, 繁星限流=%.0f rps, 起抓错峰窗口=%d ms)%s ..."
              % (len(rooms), cfg.canon_concurrency, settings.ratelimit.fanxing_rps,
                 cfg.warmup_window_ms, "(--no-canon)" if not do_canon else ""))
        res = await admit_rooms(rooms, bus=bus, db=db, star=star, cfg=cfg,
                                do_canon=do_canon, aliases=settings.room_aliases)
        # 转正:注入的房若此前被自动发现,移出发现集 + 清 PG 时钟残行
        # (与 web /api/monitor/add-bulk 语义一致 —— 手动添加的房归策展列表,前端可见)。
        added = res.get("added_rooms", [])
        if added:
            await bus.discovered_remove_bulk(added)
            await db.discovered_delete_bulk(added)
        dt = time.monotonic() - t0
        print("\n完成(用时 %.1fs):" % dt)
        print("  请求 %d · 去重后 %d · 注入(已归一) %d · 挂起(待归一) %d · 跳过(非法) %d"
              % (res["requested"], res["deduped"], res["added"], res["pending"], res["skipped"]))
        if res.get("truncated"):
            print("  ⚠️ 超出单次上限,截断 %d 个(见 admission.max_bulk)" % res["truncated"])
        if res["pending"]:
            sample = ", ".join(res["pending_rooms"][:10])
            more = "…" if len(res["pending_rooms"]) > 10 else ""
            print("  ⏳ 挂起房(worker janitor 将自动重试归一并转正): %s%s" % (sample, more))
        print("\n当前活跃名录共 %d 房。" % len(await bus.active_rooms()))
    finally:
        await star.close()
        await bus.close()
        await db.close()


async def _list() -> None:
    bus = RedisBus(settings.redis_url, max_connections=8)
    try:
        active = await bus.active_rooms()
        if not active:
            print("(名录为空)")
        for r in active:
            print("  %s  (alias=%s)" % (r, await bus.alias_of(r)))
    finally:
        await bus.close()


def main() -> None:
    ap = argparse.ArgumentParser(description="批量注入监控房间到 Redis 名录 + PG(经准入控制器)")
    ap.add_argument("rooms", nargs="*", help="房号(可多个;短号会自动归一)")
    ap.add_argument("--file", help="从文件读房号(每行一个;支持数千房)")
    ap.add_argument("--no-canon", action="store_true", help="跳过繁星归一,按原号注入")
    ap.add_argument("--concurrency", type=int, default=0, help="覆盖归一并发(默认取 config)")
    ap.add_argument("--list", action="store_true", help="打印当前名录后退出")
    args = ap.parse_args()

    if args.list:
        asyncio.run(_list())
        return

    rooms = list(args.rooms)
    if args.file:
        rooms += [ln.strip() for ln in Path(args.file).read_text(encoding="utf-8").splitlines()
                  if ln.strip() and not ln.strip().startswith("#")]
    if not rooms:
        rooms = list(settings.rooms)
    if not rooms:
        print("没有要注入的房间(命令行/文件/config.yaml 均为空)。", file=sys.stderr)
        sys.exit(1)
    asyncio.run(_seed(rooms, do_canon=not args.no_canon, concurrency=args.concurrency))


if __name__ == "__main__":
    main()
