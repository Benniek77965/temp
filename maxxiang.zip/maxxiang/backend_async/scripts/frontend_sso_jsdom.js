/* 用法:项目根 `npm i jsdom` 后 `node backend_async/scripts/frontend_sso_jsdom.js`(Node ≥20)。
   混淆产物复验:`node backend_async/scripts/frontend_sso_jsdom.js --js dist/assets/app.js`。

   链接快速登录(4.1.0,SSO)前端整机冒烟:交付版 index.html + app.js 在 jsdom 真 DOM
   中原样执行,仅桩网络(与 frontend_reg_jsdom.js 同款手法)。覆盖:
     · 片段消费契约:#sso=<64hex>(大写照收)→ **恰一次** POST /api/auth/sso,
       载荷里的 ticket 已小写归一;读到即清片段(location.hash 空)
     · 成功链:兑换 200 → 不 reload,authInit 见新会话 → 登录门不出场、数据引导继续
     · 失败链:401 bad_ticket → 门照常拉起,服务端 message 摆上 #authMsg
     · 换号确认:409 switch_confirm → window.confirm 弹出;确认 → 第二发带
       allowSwitch:true → switched 提示进 #toast;取消 → **不再发**,保持原账号继续
     · 无片段:零 SSO 请求,一切如旧
   每个场景独立 JSDOM(片段必须先于 app.js 执行就位);全程断言 window.__errlog
   为空 —— 运行期零异常,这是 node --check 语法检查覆盖不到的那一半。 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
const html = fs.readFileSync(ROOT + '/index.html', 'utf8');
const JS_ARG = process.argv.indexOf('--js');
const JS_PATH = JS_ARG > 0 ? path.resolve(process.argv[JS_ARG + 1]) : ROOT + '/assets/app.js';
const appjs = fs.readFileSync(JS_PATH, 'utf8');

let PASS = 0, FAIL = 0;
const A = (n, c) => { console.log(`  [${c ? '✓' : '✗'}] ${n}`); if (c) PASS++; else { FAIL++; process.exitCode = 1; } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const T_UP = 'A1B2C3D4'.repeat(8);                 // 64 hex,大写形态入 URL
const T_LO = T_UP.toLowerCase();

async function scenario(name, { hash = '', route, confirmAnswer = true, settle = 450 }) {
  const NET = { sso: [], confirms: [], authed: false, user: null, toasts: [],
                navs: [] };   // navs:jsdom 对 location.reload 的观测口径(见 ⑥)
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => { const m = String((e && e.message) || e);
    if (/Not implemented: navigation/i.test(m)) NET.navs.push(m); }); vc.on('error', () => {}); vc.on('warn', () => {});
  vc.on('info', () => {}); vc.on('log', () => {});
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
                                url: 'http://localhost/' + hash, virtualConsole: vc });
  const w = dom.window;
  w.confirm = m => { NET.confirms.push(m); return confirmAnswer; };
  w.fetch = async (input, opt = {}) => {
    const url = typeof input === 'string' ? input : input.url;
    let body;
    if (url.startsWith('/api/auth/sso')) {
      const req = JSON.parse(opt.body);
      NET.sso.push(req);
      body = route(req, NET);
    } else if (url.startsWith('/api/auth/session')) {
      body = { ok: true, enabled: true, authed: NET.authed, pow: { enabled: false },
               ...(NET.authed
                 ? { user: { id: 7, userName: NET.user, dueTime: '2027-01-01T00:00:00', dueDays: 165 } }
                 : { state: 'auth_required' }) };
    } else if (url.startsWith('/api/live-rooms')) { NET.rooms = (NET.rooms || 0) + 1; body = { ok: true, rooms: [] }; }
    else if (url.startsWith('/api/spells')) body = { ok: true, spells: [] };
    else body = { ok: true };
    const status = body.__status || 200;
    return { ok: status < 400, status, headers: { get: () => null },
             json: async () => body, text: async () => JSON.stringify(body) };
  };
  w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){} };
  w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
  w.PerformanceObserver = class { observe(){} disconnect(){} };
  w.matchMedia = q => ({ matches: false, media: q, addEventListener(){}, removeEventListener(){},
                         addListener(){}, removeListener(){} });
  w.scrollTo = () => {};
  w.Worker = class { postMessage(){} };            // SSO 链不触 Worker;占位防未定义
  const sc = w.document.createElement('script');
  sc.textContent = appjs;
  // toast 是**单管线后到覆盖**(见 app.js toast/toastAction 注):切换提示可能被
  // 随后的空名录引导覆盖 —— 用变化探针收集历史,断言「曾弹出」而非「停留」。
  const toastEl0 = w.document.querySelector('#toast');
  new w.MutationObserver(() => { const t = toastEl0.textContent;
    if (t && NET.toasts[NET.toasts.length - 1] !== t) NET.toasts.push(t); })
    .observe(toastEl0, { childList: true, characterData: true, subtree: true });
  w.document.body.appendChild(sc);
  await sleep(settle);
  console.log(`— ${name}`);
  return { w, NET, $: s => w.document.querySelector(s) };
}

(async () => {
  console.log('链接快速登录(4.1.0)前端整机冒烟 —— 交付版 index.html + app.js @ jsdom');
  console.log(`  目标 JS:${path.relative(ROOT, JS_PATH)}\n`);

  { // ① 成功链:大写票据 → 小写归一恰一发,清片段,不锁门,数据引导继续
    const { w, NET, $ } = await scenario('成功兑换(#sso= 大写票据)', {
      hash: '#sso=' + T_UP,
      route: (req, NET) => { NET.authed = true; NET.user = '测试用户A';
        return { ok: true, user: { id: 7, userName: '测试用户A' }, switched: false }; },
    });
    A('恰一次 POST /api/auth/sso', NET.sso.length === 1);
    A('载荷 ticket 已小写归一', NET.sso[0] && NET.sso[0].ticket === T_LO);
    A('首发不带 allowSwitch', !NET.sso[0].allowSwitch);
    A('URL 片段已清(只消费一次)', w.location.hash === '');
    A('登录门未出场', $('#authGate').hidden === true && w.document.body.dataset.auth !== 'locked');
    A('数据引导继续(live-rooms 已拉)', (NET.rooms || 0) >= 1);
    A('运行期零异常(__errlog 空)', Array.isArray(w.__errlog) && w.__errlog.length === 0);
  }

  { // ② 失败链:401 bad_ticket → 门上摆服务端 message
    const MSG = '快速登录链接已失效或已使用,请回到来源页面重新进入';
    const { w, NET, $ } = await scenario('失效票据(401 bad_ticket)', {
      hash: '#sso=' + T_LO,
      route: () => ({ __status: 401, ok: false, error: 'bad_ticket', message: MSG }),
    });
    A('恰一次兑换尝试', NET.sso.length === 1);
    A('片段仍被清(失败也不残留)', w.location.hash === '');
    A('登录门出场', $('#authGate').hidden === false && w.document.body.dataset.auth === 'locked');
    A('失败原因摆上 #authMsg', $('#authMsg').textContent === MSG);
    A('运行期零异常', w.__errlog.length === 0);
  }

  { // ③ 换号确认 · 同意:二发带 allowSwitch,toast 提示已切换
    const { w, NET, $ } = await scenario('已登录他号 → 确认切换', {
      hash: '#sso=' + T_LO, confirmAnswer: true,
      route: (req, NET) => {
        if (!req.allowSwitch)
          return { __status: 409, ok: false, error: 'switch_confirm',
                   current: '测试用户A', target: 'plainuser', message: '当前已登录其他账号,请确认是否切换' };
        NET.authed = true; NET.user = 'plainuser';
        return { ok: true, user: { id: 8, userName: 'plainuser' }, switched: true };
      },
    });
    A('confirm 弹出且文案含两个账号', NET.confirms.length === 1
      && /测试用户A/.test(NET.confirms[0]) && /plainuser/.test(NET.confirms[0]));
    A('恰两发:409 后带 allowSwitch 重试', NET.sso.length === 2 && NET.sso[1].allowSwitch === true);
    A('切换提示曾进 #toast(单管线可被空名录引导覆盖 —— 后到覆盖先到是既有语义)',
      NET.toasts.some(t => /已切换为.*plainuser/.test(t)));
    A('登录门未出场(已在新会话)', $('#authGate').hidden === true);
    A('运行期零异常', w.__errlog.length === 0);
  }

  { // ④ 换号确认 · 取消:不再发,保持原账号继续
    const { w, NET, $ } = await scenario('已登录他号 → 取消切换', {
      hash: '#sso=' + T_LO, confirmAnswer: false,
      route: (req, NET) => {
        NET.authed = true; NET.user = '测试用户A';   // 会话侧:仍是原账号
        return { __status: 409, ok: false, error: 'switch_confirm',
                 current: '测试用户A', target: 'plainuser' };
      },
    });
    A('取消后不再发第二发(票据留给 60s 自然过期)', NET.sso.length === 1);
    A('片段已清', w.location.hash === '');
    A('以原账号继续(门不出场)', $('#authGate').hidden === true);
    A('运行期零异常', w.__errlog.length === 0);
  }

  { // ⑤ 无片段:零 SSO 请求,一切如旧
    const { w, NET, $ } = await scenario('无 #sso= 片段(基线)', {
      hash: '',
      route: () => ({ ok: true }),
    });
    A('零 SSO 请求', NET.sso.length === 0);
    A('常规登录门出场', $('#authGate').hidden === false);
    A('运行期零异常', w.__errlog.length === 0);
  }

  { // ⑥ 4.3.4:已停在登录门,把链接粘进地址栏 —— 浏览器**只改 hash 不重载**
    //    (真实反馈:「在登录页粘贴回车没反应,不在登录页则正常」)
    const { w, NET, $ } = await scenario('已在登录门 → 仅片段变化(成功)', {
      hash: '', route: (req, NET) => { NET.authed = true; NET.user = 'plainuser';
                                       return { ok: true, user: { id: 7, userName: 'plainuser' } }; },
    });
    A('前置:登录门已出场', $('#authGate').hidden === false);
    A('前置:此时零 SSO 请求', NET.sso.length === 0);
    // location.reload 在 jsdom 里不可 stub(Cannot redefine property),但它会派发
    // jsdomError「Not implemented: navigation to another Document」—— 以此为观测口径。
    NET.navs.length = 0;
    w.location.hash = '#sso=' + T_LO;      // ← 等价于「粘贴 URL 回车」:不重载,只派发 hashchange
    await sleep(400);
    A('hashchange 触发了恰一次兑换', NET.sso.length === 1);
    A('载荷 ticket 正确且已小写归一', NET.sso[0] && NET.sso[0].ticket === T_LO);
    A('片段已清(单次消费纪律不破)', w.location.hash === '');
    A('成功后调了 reload(带新会话重建应用)', NET.navs.length >= 1);
    A('运行期零异常', w.__errlog.length === 0);
  }

  { // ⑦ 同上但票据失效:不重载,原因摆到登录门上
    const { w, NET, $ } = await scenario('已在登录门 → 仅片段变化(票据失效)', {
      hash: '', route: () => ({ __status: 401, ok: false, error: 'bad_ticket',
                                message: '快速登录链接已失效或已使用' }),
    });
    NET.navs.length = 0;                   // 与 ⑥ 同口径;⑥ 已证明该口径确实会被触发,
    w.location.hash = '#sso=' + T_LO;      // 故此处的「为空」是真断言而非空过
    await sleep(400);
    A('恰一次兑换尝试', NET.sso.length === 1);
    A('失败不重载', NET.navs.length === 0);
    A('失败原因摆上 #authMsg', ($('#authMsg').textContent || '').includes('失效'));
    A('片段仍被清', w.location.hash === '');
    A('运行期零异常', w.__errlog.length === 0);
  }

  { // ⑧ 无关 hash 变化不得触发兑换(防误伤)
    const { w, NET } = await scenario('无关片段变化(基线)', {
      hash: '', route: () => ({ ok: true }),
    });
    w.location.hash = '#room=123';
    await sleep(250);
    A('非 sso 片段:零兑换请求', NET.sso.length === 0);
    A('运行期零异常', w.__errlog.length === 0);
  }

  console.log(`\n结果:${PASS} 项通过,${FAIL} 项失败`);
  if (FAIL === 0) console.log('✓ SSO 前端链在真 DOM 中整机可用(含只消费一次/小写归一/换号确认三大契约 + 仅片段变化路径)');
})();
