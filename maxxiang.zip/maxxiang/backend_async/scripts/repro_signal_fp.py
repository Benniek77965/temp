"""4.9.0「疑似脚本来源」误报修复 —— **前后对拍**取证/回归守卫。

用法:`cd backend_async && python3 scripts/repro_signal_fp.py`

本脚本把**修复前的评分函数逐字冻结**在 `_sig_score_v392()` 里,与现行
`admin_api._sig_score()` 并排跑同一批画像,证明两件事:
  一、旧算法把**正常使用的真人**打成 65 分(45「从未加载页面」+ 20「执行证明失败
      N 次」),与用户实际看到的分数与依据逐字吻合;新算法给 0 分。
  二、对**真搬运器**的判定**零削弱** —— 新旧算法都给高分。

误报的四条成因(均已实地复现,见 verify_claims.py):
  ① 画像 Hash 的 TTL 由「最近一次事件」续期,而 `html` 在 SPA 里整个页面生命周期
     只发生一次。app.js 的 visibilitychange 分支明确「隐藏期间 schedulePolls 完全
     静默」—— 手机锁屏 / 标签页后台超过窗口后画像自然过期,回到前台第一拍就打明细,
     画像**以 html=0 重建**。
  ② 一次被拒的明细请求同时进 pow_fail 与 detail,而旧阈值写的是
     `detail + pow_fail >= 8`,等于门槛只有 4 次。
  ③ 后端挑战 TTL 默认 180s,而前端「铸一次、永不主动续铸」——真人每 3 分钟稳吃
     一次 pow_fail,30 分钟窗口刚好凑够 10 次。
  ④ 画像里存了 first/last/detail_ok/sse,评分函数一个都没用 —— 只加不减。
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import app.admin_api as admin_api              # noqa: E402
from app.admin_api import _looks_like_browser  # noqa: E402


def _sig_score_v392(rec):
    """**3.9.2 原版评分,逐字冻结**,仅供对拍。请勿"顺手优化"这里的任何一行。"""
    html = int(rec.get("html", 0) or 0)
    asset = int(rec.get("asset", 0) or 0)
    detail = int(rec.get("detail", 0) or 0)
    pow_ok = int(rec.get("pow_ok", 0) or 0)
    pow_fail = int(rec.get("pow_fail", 0) or 0)
    rooms = int(rec.get("rooms", 0) or 0)
    ua = str(rec.get("ua", "") or "")
    score, reasons = 0, []
    if html == 0 and (detail + pow_fail) >= 8:
        score += 45
        reasons.append("从未加载页面(HTML)却在访问明细端点")
    if pow_fail >= 5 and pow_ok == 0:
        score += 35
        reasons.append("执行证明失败 %d 次、从未通过(疑似不执行 JS)" % pow_fail)
    elif pow_fail >= 10:
        score += 20
        reasons.append("执行证明失败 %d 次" % pow_fail)
    if html > 0 and asset == 0 and detail >= 10:
        score += 15
        reasons.append("加载了页面却从不请求静态资源(注意:热缓存回访亦可能如此)")
    if rooms >= 6:
        score += 15
        reasons.append("短时访问 %d 个不同直播间" % rooms)
    if ua and not _looks_like_browser(ua):
        score += 10
        reasons.append("User-Agent 非主流浏览器")
    return {"score": min(100, score), "reasons": reasons}


WIN = 30 * 60_000          # 观测跨度 30 分钟(= 默认画像窗)

CASES = [
    ("真人 · 手机锁屏 35 分钟后回前台(画像超窗重建)",
     {"html": 0, "asset": 0, "detail": 68, "detail_ok": 58, "pow_ok": 58,
      "pow_fail": 10, "rooms": 1, "foot": True, "first": 0, "last": WIN,
      "ua": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5) Safari/605.1.15"},
     65, 0),
    ("真人 · 双标签页(旧挑战键互相覆盖形成乒乓)",
     {"html": 1, "asset": 8, "detail": 90, "detail_ok": 76, "pow_ok": 76,
      "pow_fail": 14, "rooms": 1, "foot": True, "first": 0, "last": WIN,
      "ua": "Mozilla/5.0 (Windows NT 10.0) Chrome/126"},
     20, 0),
    ("真人 · 热缓存回访(取到页面但不再取静态)",
     {"html": 2, "asset": 0, "detail": 30, "detail_ok": 30, "pow_ok": 30,
      "pow_fail": 0, "rooms": 1, "foot": True, "first": 0, "last": WIN,
      "ua": "Mozilla/5.0"},
     15, 0),
    ("搬运器 · 拿 Cookie 用 curl 直拉(L2 开)",
     {"html": 0, "asset": 0, "detail": 20, "detail_ok": 0, "pow_ok": 0,
      "pow_fail": 20, "rooms": 9, "foot": False, "first": 0, "last": 60_000,
      "ua": "python-requests/2.31"},
     100, 100),
    ("搬运器 · 高速轮转多房采集(L2 关,靠速率identification)",
     {"html": 0, "asset": 0, "detail": 50, "detail_ok": 50, "pow_ok": 0,
      "pow_fail": 0, "rooms": 20, "foot": False, "first": 0, "last": 120_000,
      "ua": "curl/8.0"},
     70, 70),
]


def main():
    bad = 0
    print("=" * 94)
    print("%-46s%11s%11s   %s" % ("画像", "旧(3.9.2)", "新(4.9.0)", "判定"))
    print("=" * 94)
    for name, prof, want_old, want_new in CASES:
        old = _sig_score_v392(prof)["score"]
        new = admin_api._sig_score(prof)["score"]
        ok = (old == want_old and new == want_new)
        bad += 0 if ok else 1
        tail = "OK" if ok else ("期望 %d/%d" % (want_old, want_new))
        print("%-46s%11d%11d   %s" % (name, old, new, tail))
    print("=" * 94)

    human = CASES[0][1]
    print("\n【旧算法给真人的研判依据】(与用户实际看到的两条逐字吻合)")
    for r in _sig_score_v392(human)["reasons"]:
        print("   -", r)
    new = admin_api._sig_score(human)
    print("\n【新算法】分数 =", new["score"], " 依据 =", new["reasons"] or "(无)")
    print("   研判辅助(此前被丢弃的无罪信号,现已呈现给运营者):")
    for n in new["notes"]:
        print("   *", n)

    print("\n【前后端「明细端点」口径对拍】")
    import re
    import app.web as web
    fe = re.compile(r"^/api/rooms/[^/?]+(?:/(?:prediction|coverage|history))?(?:\?|$)")
    guarded = {"/api/rooms/1", "/api/rooms/1/prediction",
               "/api/rooms/1/coverage", "/api/rooms/1/history"}
    for p in ["/api/rooms/1", "/api/rooms/1/prediction", "/api/rooms/1/coverage",
              "/api/rooms/1/history", "/api/rooms/1/history?limit=30",
              "/api/rooms/1/history/days", "/api/rooms/1/config", "/api/rooms"]:
        bare = p.split("?")[0]
        g = bare in guarded
        sig = bool(web._SIG_DETAIL_RE.match(bare))
        hdr = bool(fe.match(p))
        ok = (g == sig == hdr)
        bad += 0 if ok else 1
        print("   [%s] %-34s 设闸=%-5s 计明细=%-5s 前端带头=%s"
              % ("OK" if ok else "!!", p, g, sig, hdr))

    print("\n" + ("== 前后对拍全部符合预期 ==" if not bad else "== %d 项不符 ==" % bad))
    return bad


sys.exit(1 if main() else 0)
