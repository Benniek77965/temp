/* admin_secret_jsdom.js — 参数中心「敏感项」整机冒烟(4.2.9)
   用法:项目根 `npm i --no-save jsdom` 后 `node backend_async/scripts/admin_secret_jsdom.js`
   ⚠ **必须带 --no-save**:jsdom 一旦写进 package.json,目标机 `npm ci` 会因
     「package.json and package-lock.json are not in sync」直接失败,整个镜像
     重建中断 —— 这是本项目发生过的真实部署事故,有回归钉
     (test_package_manifest_has_no_test_only_deps)。本轮我又踩了一次。

   ── 为什么必须补这一份 ──────────────────────────────────────────────────────
   4.2.9 在参数中心的密钥项旁加了两颗按钮(🎲 生成 / 👁 查看),而项目既有的四个
   jsdom 脚本**没有一个覆盖参数中心** —— 它们跑的是「值」视图与用户端。也就是说
   这两颗按钮从写出来到交付,行为层零覆盖。

   本脚本让交付版 admin.html + admin.js 在真 DOM 里跑参数中心,只桩网络:
     · 按钮是否真的渲染出来(且只对声明了 genBytes / revealable 的项渲染);
     · 🎲 生成是否真的用 crypto.getRandomValues 且把值写进了暂存;
     · 取消生成是否**撤销暂存**(否则运维会把一把自己没有的密钥推上生产);
     · 👁 查看是否真的打 /config/reveal、把明文渲染出来、且失败时不静默;
     · 无安全随机源时是否**拒绝生成**而不是回退到别的随机源。

   与 admin_jfvip_jsdom.js 同款约定:--js/--html 可指向混淆产物做验收。 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
const _ARGJ = process.argv.indexOf('--js');
const _ARGH = process.argv.indexOf('--html');
const html = fs.readFileSync(_ARGH > 0 ? process.argv[_ARGH + 1] : ROOT + '/admin.html', 'utf8');
const js = fs.readFileSync(_ARGJ > 0 ? process.argv[_ARGJ + 1] : ROOT + '/assets/admin.js', 'utf8');

let PASS = 0, FAIL = 0;
const A = (n, c, e) => { console.log(`  [${c ? '✓' : '✗'}] ${n}${c ? '' : '  → ' + (e || '')}`);
                         if (c) PASS++; else { FAIL++; process.exitCode = 1; } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* 只放三个字段:一个可生成可揭示的密钥、一个仅敏感不可揭示的凭据、一个普通项。
   授予面的断言全靠这三者的对比 —— 只放一个的话「是不是所有 sensitive 都给了」
   这条根本测不出来。 */
const FIELDS = {
  'userauth.jf_card_api_key': {
    label: '外部发卡API密钥', type: 'str', default: '', hot: 'hot',
    consumers: ['web'], section: '九法VIP', desc: '外部发卡密钥', unit: '',
    ge: null, le: null, choices: null, env: 'STA_JF_CARD_API_KEY',
    sensitive: true, danger: true, readonly: false, no_reset: false,
    depends: '', genBytes: 32, revealable: true},
  'auth.ticket': {
    label: '上游票据', type: 'str', default: '', hot: 'hook',
    consumers: ['worker'], section: '接入凭据', desc: '上游签发', unit: '',
    ge: null, le: null, choices: null, env: 'STA_AUTH_TICKET',
    sensitive: true, danger: true, readonly: false, no_reset: true,
    depends: '', genBytes: 0, revealable: false},
  'userauth.jf_order_rate_hourly': {
    label: '下单限频', type: 'int', default: 20, hot: 'hot',
    consumers: ['web'], section: '九法VIP', desc: '每账号每小时', unit: '次/时',
    ge: 1, le: 500, choices: null, env: 'STA_JF_ORDER_RATE_HOURLY',
    sensitive: false, danger: false, readonly: false, no_reset: false,
    depends: '', genBytes: 0, revealable: false},
};

async function boot(opt = {}) {
  const errs = [], calls = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => errs.push(String(e && e.message || e)));
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
                                url: 'http://localhost/admin#/params', virtualConsole: vc });
  const w = dom.window;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({matches:false, media:q, addEventListener(){}, removeEventListener(){},
                        addListener(){}, removeListener(){}});
  w.ResizeObserver = class { observe(){} disconnect(){} unobserve(){} };
  /* jsdom 不带 crypto.getRandomValues。opt.noCrypto 时**刻意不注入** ——
     那正是要测的分支:无安全随机源时必须拒绝生成,而不是回退到 Math.random。 */
  /* ⚠ jsdom 的 window.crypto 是**原型上的 getter**,`delete w.crypto.getRandomValues`
     删不掉(初版就是这么写的,结果 noCrypto 分支里真的生成出了 64 位 hex,
     用例假红了一次才发现)。必须整个替换掉 window.crypto 这个属性。 */
  Object.defineProperty(w, 'crypto', {
    configurable: true,
    value: opt.noCrypto ? {} : {
      getRandomValues: a => { for (let i = 0; i < a.length; i++) a[i] = (i * 7 + 3) & 255; return a; }},
  });
  w.navigator.clipboard = { writeText: async () => {} };
  w.document.execCommand = () => true;

  w.fetch = async (url, o = {}) => {
    const u = String(url); calls.push({url: u, method: (o && o.method) || 'GET', body: o && o.body});
    let b = {ok: true};
    if (u.includes('/admin/session')) b = {ok:true, authed:true, csrf:'c', rev:1};
    else if (u.includes('/admin/schema')) b = {ok:true, fields: FIELDS, sections:['九法VIP','接入凭据'], deploy:[]};
    else if (u.includes('/config/reveal')) {
      if (opt.revealFail) return {ok:false, status:503, json: async () => ({ok:false, error:'unavailable'})};
      b = opt.revealNull ? {ok:true, key:'userauth.jf_card_api_key', value:null,
                            message:'本台没有该项的运行时明文 —— 当前生效值来自环境变量或默认'}
                         : {ok:true, key:'userauth.jf_card_api_key', value:'DEADBEEF'.repeat(8), auditOk:true};
    }
    else if (u.includes('/config/effective')) {
      /* ★ 形状必须与后端 config_center.describe() **逐字段一致**。
         初版我按印象写成 {values:{…}},页面直接渲染成「加载失败:网络错误」——
         这正是「绝不印象推断」该抓的:契约要去读后端,不能猜。 */
      const item = (k, eff) => ({key:k, effective:eff, source:'default',
        layers:{default:eff, yaml:null, yaml_set:false, env:null, env_set:false,
                runtime:null, runtime_set:false}, base:eff});
      b = {ok:true, rev:1, applied_rev:1, items:[
        item('userauth.jf_card_api_key', '0f3a…ab12'),
        item('auth.ticket', 'abcd…0011'),
        item('userauth.jf_order_rate_hourly', 20)]};
    }
    else if (u.includes('/fleet')) b = {ok:true, target_rev:1, converged:true, instances:[]};
    else if (u.includes('/instances')) b = {ok:true, items:[]};
    else if (u.includes('/revisions')) b = {ok:true, items:[]};
    return {ok:true, status:200, json: async () => b};
  };
  const s = w.document.createElement('script'); s.textContent = js;
  w.document.body.appendChild(s);
  await sleep(120);
  return {w, errs, calls, dom};
}

/* 只取**用户真正看得见**的文本:剥掉 <script>(注入的 admin.js 源码全在里面)。
   不剥的话任何 /关键词/ 断言都会被源码本身命中,恒真。 */
const visibleText = w => [...w.document.querySelectorAll('#main,#ask,#askB,#toast,#drawer')]
  .map(e => e.textContent || '').join(' ');

const $ = (w, sel) => w.document.querySelector(sel);
const $$ = (w, sel) => [...w.document.querySelectorAll(sel)];

(async () => {
  console.log('\n[参数中心 · 敏感项按钮]');
  {
    const {w, errs} = await boot();
    const gen = $$(w, '.sec-gen'), rev = $$(w, '.sec-rev');
    A('🎲 生成按钮渲染出来了', gen.length === 1, `实得 ${gen.length} 个`);
    A('👁 查看按钮渲染出来了', rev.length === 1, `实得 ${rev.length} 个`);
    A('生成按钮只给声明了 genBytes 的项',
      gen.length === 1 && gen[0].dataset.gen === 'userauth.jf_card_api_key',
      gen[0] && gen[0].dataset.gen);
    A('揭示按钮只给 revealable 的项(auth.ticket 不给)',
      rev.length === 1 && rev[0].dataset.rev === 'userauth.jf_card_api_key',
      rev[0] && rev[0].dataset.rev);
    /* ★ 布局:jsdom 不做布局,但**父子关系**是能验的 —— 这正是第四轮那个
       「包一层 span 让 flex:1 失效」的缺陷的判据。按钮与输入框必须同父。 */
    const inp = $(w, 'input[data-k="userauth.jf_card_api_key"]');
    A('输入框与按钮同父(未被额外容器包裹)',
      !!inp && gen[0].parentElement === inp.parentElement
            && rev[0].parentElement === inp.parentElement,
      inp ? inp.parentElement.className : 'no input');
    A('同父节点就是 .pctl(flex 容器本身)',
      !!inp && /pctl/.test(inp.parentElement.className), inp && inp.parentElement.className);
    A('零未捕获异常', errs.length === 0, errs[0]);
  }

  console.log('\n[🎲 生成]');
  {
    const {w, errs} = await boot();
    $(w, '.sec-gen').click(); await sleep(60);
    const inp = $(w, 'input[data-k="userauth.jf_card_api_key"]');
    A('生成后值写进了输入框', !!inp && /^[0-9a-f]{64}$/.test(inp.value), inp && inp.value.slice(0, 20));
    /* ★ 光写进输入框**不够** —— 参数卡的暂存监听的是 change 事件。初版只断言
       inp.value,于是「派发了 input 而暂存没生效」这条缺陷在 jsdom 层一路绿到
       真实浏览器才被逮到。写进框 ≠ 会被应用。 */
    A('生成后参数卡进入暂存态(否则点「应用」什么也不会发生)',
      !!inp && !!inp.closest('.pcard.staged'),
      inp && inp.closest('.pcard') && inp.closest('.pcard').className);
    A('工作台计数 +1', ($(w, '#stCnt') || {}).textContent === '1',
      ($(w, '#stCnt') || {}).textContent);
    A('弹窗展示了明文(唯一一次能看到)',
      /[0-9a-f]{64}/.test(($(w, '#askB') || {}).textContent || '') || !!$(w, '#gsOut'));
    A('有复制按钮', !!$(w, '#gsCopy'));
    const t = ($(w, '#askB') || {}).textContent || '';
    A('警告了旧密钥立即失效', /旧密钥.*失效/.test(t), t.slice(0, 60));
    A('零未捕获异常', errs.length === 0, errs[0]);
  }
  {   /* 取消 = 撤销暂存 */
    const {w} = await boot();
    $(w, '.sec-gen').click(); await sleep(60);
    $(w, '#askNo').click(); await sleep(60);
    const inp = $(w, 'input[data-k="userauth.jf_card_api_key"]');
    A('点取消后输入框被清空(不会把没拿到的密钥推上生产)',
      !!inp && inp.value === '', inp && inp.value);
    A('点取消后暂存也被撤销', !!inp && !inp.closest('.pcard.staged'),
      inp && inp.closest('.pcard') && inp.closest('.pcard').className);
  }
  {   /* 无安全随机源 → 拒绝生成 */
    const {w} = await boot({noCrypto: true});
    $(w, '.sec-gen').click(); await sleep(60);
    const inp = $(w, 'input[data-k="userauth.jf_card_api_key"]');
    A('无 crypto 时拒绝生成(绝不回退到别的随机源)', !!inp && inp.value === '', inp && inp.value);
    /* ★ 绝不能扫 document.body.textContent —— 它**包含我注入的整个 admin.js 源码**,
       而源码里就有 "openssl" 这个词。初版这么写,断言恒真(假阳性),
       等于什么都没测。只扫真正的可见反馈容器。 */
    A('并给出可操作提示(openssl)', /openssl/.test(visibleText(w)), visibleText(w).slice(0, 80));
  }

  console.log('\n[👁 查看]');
  {
    const {w, calls, errs} = await boot();
    $(w, '.sec-rev').click(); await sleep(120);
    const c = calls.filter(x => x.url.includes('/config/reveal'));
    A('真的打了 /config/reveal', c.length === 1, `实得 ${c.length} 次`);
    A('用 POST 且带上了 key', c[0] && c[0].method === 'POST'
      && /jf_card_api_key/.test(String(c[0].body || '')), c[0] && c[0].body);
    A('明文渲染出来了', !!$(w, '#rvOut') && /DEADBEEF/.test($(w, '#rvOut').value));
    A('告知本次查看已记入审计', /记入审计/.test(($(w, '#askB') || {}).textContent || ''));
    A('有复制按钮', !!$(w, '#rvCopy'));
    A('零未捕获异常', errs.length === 0, errs[0]);
  }
  {   /* 本台没有明文 → 诚实说明，不显示空串 */
    const {w} = await boot({revealNull: true});
    $(w, '.sec-rev').click(); await sleep(120);
    const t = ($(w, '#askB') || {}).textContent || '';
    A('无明文时说明来源(不显示空串让人以为密钥是空的)',
      /环境变量|默认/.test(t) && !$(w, '#rvOut'), t.slice(0, 50));
  }
  {   /* 后端 503 → 不静默 */
    const {w, errs} = await boot({revealFail: true});
    $(w, '.sec-rev').click(); await sleep(150);
    A('后端失败时给出可见反馈(不静默吞掉)',
      /失败|错误|unavailable/i.test(visibleText(w)), visibleText(w).slice(0, 80));
    A('失败路径零未捕获异常', errs.length === 0, errs[0]);
  }

  console.log('\n' + '─'.repeat(52));
  console.log(`参数中心敏感项冒烟:${PASS} 通过 / ${FAIL} 失败`);
})();
