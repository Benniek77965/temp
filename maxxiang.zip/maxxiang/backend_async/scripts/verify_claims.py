"""4.9.0 修复验证 —— 全部走**项目真实代码路径**,不用等价替身。

用法:`cd backend_async && python3 scripts/verify_claims.py`(需 fakeredis)

修复前的实测事实(每条都是真跑出来的,不是推断):
  A. 画像 Hash 真按 signal_window_s 过期 → 静默超窗后 html 归零 → 9 次明细即得 45 分
  B. 一次 401 同时计 pow_fail 与 detail → 因子① 的阈值 8 实际只需 4 次失败请求
  C. ensurePow 首行 `if (!POW.on || POW.ans) return;` → 应答一旦缓存永不主动重铸,
     而后端挑战 TTL 默认 180s → 每 3 分钟必吃一次 401
  D. 挑战键 `powchal:{sid}`,sid = sha256(会话 Cookie) → 同浏览器所有标签页共用一把,
     mint 互相覆盖 → 12 拍交替产生 pow_fail=14 / pow_ok=1
  E. _sig_score 采集了 detail_ok / sse / first / last,却一个都没用上

本脚本验证上述每一条**都已闭合**。
"""
import asyncio
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import fakeredis.aioredis            # noqa: E402
import app.web as web                # noqa: E402
import app.admin_api as admin_api    # noqa: E402
from app.redis_bus import RedisBus   # noqa: E402

OK, BAD = "  [OK]", "  [!!]"


def bus():
    b = RedisBus.__new__(RedisBus)
    b.r = fakeredis.aioredis.FakeRedis(decode_responses=True)
    return b


class Req:
    def __init__(self, path="/api/rooms/1/prediction", cookie="tokenXYZ",
                 proof="", tab=""):
        self.url = type("U", (), {"path": path})()
        self.headers = {"user-agent": "Mozilla/5.0 Safari",
                        "x-jf-proof": proof, "x-jf-tab": tab}
        self.cookies = {"jf_sess": cookie} if cookie else {}
        self.client = type("C", (), {"host": "1.2.3.4"})()
        self.state = type("S", (), {"user": type("U", (), {"user_id": 7,
                                                           "user_name": "a"})()})()


class Resp:
    def __init__(self, status=200, ctype="application/json"):
        self.status_code = status
        self.headers = {"content-type": ctype}


def setup(b, window_s=1800.0):
    web.userauth.enabled = lambda: True
    web.settings.userauth.signal_scoring = True
    web.settings.userauth.proof_of_browser = True
    web.settings.userauth.signal_window_s = window_s
    web.settings.userauth.proof_challenge_ttl_s = 180.0
    web.settings.userauth.proof_rotate_grace_s = 45.0
    web.settings.userauth.signal_footprint_ttl_s = 86400.0

    class Cfg:
        cookie_name = "jf_sess"
    web.userauth.UA.cfg = Cfg()
    web.ST.bus = b


async def main():
    fails = []

    print("[A] 画像超窗重建后,长效浏览器足迹仍在 -> 不再判「从不加载页面」")
    b = bus(); setup(b, window_s=1.2)          # 1.2s 画像窗,真实等待
    await web._sig_observe(Req(path="/"), Resp(200, "text/html"))
    for _ in range(3):
        await web._sig_observe(Req(path="/assets/app.js"), Resp(200, "application/javascript"))
    await asyncio.sleep(1.4)                   # 手机锁屏:零请求,画像自然过期
    gone = (await b.r.exists("sig:h:" + web._pow_sid(Req()))) == 0
    foot = (await b.r.exists("sig:f:" + web._pow_sid(Req()))) == 1
    for _ in range(9):
        await web._sig_observe(Req(path="/api/rooms/1/history"), Resp(200))
    rec = (await b.sig_top(now_ms=int(time.time() * 1000)))[0]
    sc = admin_api._sig_score(rec)
    print(f"      画像已过期={gone} 足迹仍在={foot} 重建后 html={rec['html']} "
          f"-> 分数 {sc['score']}(旧版此处 45)")
    # 只有足迹、没有执行证明实证时,按设计**降级**为 20 而不是归零 ——
    # 这样 L2 关闭的部署仍保有信号,而 20 < 面板默认阈值 50,真人不会浮现。
    ok_a1 = gone and foot and rec["html"] == 0 and sc["score"] == 20
    # 现网默认 L2 是开的:真人回前台第一拍就会通过一次证明 -> pow_ok>0 -> 归零。
    sc2 = admin_api._sig_score(dict(rec, pow_ok=1))
    print(f"      叠加一次执行证明通过(现网默认 L2 开)-> 分数 {sc2['score']}")
    ok_a2 = sc2["score"] == 0
    if ok_a1 and ok_a2:
        print(OK, "画像过期不再导致误判:仅足迹=20(不达阈值),有证明实证=0")
    else:
        fails.append("A"); print(BAD, sc, sc2)

    print("\n[B] 因子① 阈值只看 detail,不再把 pow_fail 重复计入")
    r4 = {"html": 0, "asset": 0, "detail": 4, "pow_fail": 4, "ua": "Mozilla/5.0"}
    r8 = dict(r4, detail=8)
    a = any("从未加载页面" in x for x in admin_api._sig_score(r4)["reasons"])
    c = any("从未加载页面" in x for x in admin_api._sig_score(r8)["reasons"])
    print(f"      detail=4,pow_fail=4 -> 触发={a}(旧版 True) | detail=8 -> 触发={c}")
    if not a and c:
        print(OK, "双计已消除")
    else:
        fails.append("B"); print(BAD)

    print("\n[C] 前端在 0.75*ttl 处主动续铸,且用了后端下发的 ttl")
    js = (Path(__file__).resolve().parents[2] / "assets" / "app.js").read_text(encoding="utf-8")
    i = js.index("async function ensurePow(")
    seg = js[i:i + 1200]
    c1 = "Date.now() < POW.exp" in seg
    c2 = "Number(r.ttl)" in seg
    c3 = "POW.gen++" in seg
    c4 = "mineIsCurrent" in js
    print(f"      到期前主动续铸={c1}  使用后端 ttl={c2}  代际号={c3}  并发不自伤={c4}")
    if c1 and c2 and c3 and c4:
        print(OK, "180s 被动 401 的稳定来源已消除")
    else:
        fails.append("C"); print(BAD)

    print("\n[D] 挑战键按标签页分号,多开互不作废;且旧挑战有轮转宽限")
    b = bus(); setup(b)
    kA = web._pow_key(Req(tab="tabAAA"))
    kB = web._pow_key(Req(tab="tabBBB"))
    print(f"      A页键={kA}\n      B页键={kB}  互不相同={kA != kB}")
    await web.pow_mint(Req(tab="tabAAA"))
    ansA = web._pow_answer(await b.r.get(kA))
    await web.pow_mint(Req(tab="tabBBB"))                    # B 页 mint
    passA = await web._proof_guard(Req(proof=ansA, tab="tabAAA")) is None
    await web.pow_mint(Req(tab="tabAAA"))                    # A 页自己续铸
    passOld = await web._proof_guard(Req(proof=ansA, tab="tabAAA")) is None
    print(f"      B页 mint 后 A页仍通过={passA}   A页续铸后旧应答(宽限内)仍通过={passOld}")
    top = await b.sig_top(now_ms=int(time.time() * 1000))
    print(f"      画像:pow_ok={top[0]['pow_ok']} pow_fail={top[0]['pow_fail']} "
          f"pow_stale={top[0].get('pow_stale', 0)}")
    if kA != kB and passA and passOld and top[0]["pow_fail"] == 0:
        print(OK, "乒乓风暴已消除(旧版此处 12 拍 -> pow_fail=14)")
    else:
        fails.append("D"); print(BAD)

    print("\n[E] stale 分类不可被绕过(对抗性自审:搬运器乱发证明头也洗不白)")
    b = bus(); setup(b)
    for _ in range(20):                       # 从不 mint,每次编一个证明头
        r = await web._proof_guard(Req(proof="deadbeefdeadbeef", tab="evil"))
    t = (await b.sig_top(now_ms=int(time.time() * 1000)))[0]
    sc = admin_api._sig_score(dict(t, detail=20, rooms=9, ua="python-requests/2.31"))
    hit35 = any("从未通过" in x for x in sc["reasons"])
    print(f"      乱发证明头 20 次 -> pow_fail={t['pow_fail']} "
          f"pow_stale={t.get('pow_stale', 0)} 分数={sc['score']} 因子(2)命中={hit35}")
    # 真正的轮转中场景:同一把键连铸两次,客户端拿的是第一代应答 -> 才算 stale
    b2 = bus(); setup(b2)
    await web.pow_mint(Req(tab="t1"))
    gen1 = web._pow_answer(await b2.r.get(web._pow_key(Req(tab="t1"))))
    await web.pow_mint(Req(tab="t1"))         # 第二次:gen1 进宽限键
    await web.pow_mint(Req(tab="t1"))         # 第三次:gen1 已被挤出宽限
    await b2.r.delete(web._pow_key(Req(tab="t1")))   # 当前挑战再过期
    r2 = await web._proof_guard(Req(proof=gen1, tab="t1"))
    t2 = (await b2.sig_top(now_ms=int(time.time() * 1000)))[0]
    print(f"      轮转中场景 -> 状态码={getattr(r2, 'status_code', None)} "
          f"pow_fail={t2['pow_fail']} pow_stale={t2.get('pow_stale', 0)}")
    if (getattr(r, "status_code", 0) == 401 and t["pow_fail"] == 20
            and t.get("pow_stale", 0) == 0 and hit35 and sc["score"] >= 90
            and t2.get("pow_stale", 0) == 1):
        print(OK, "洗白通道已封死(评分回到 95,与旧版同强度),真轮转仍被正确豁免")
    else:
        fails.append("E"); print(BAD, t, sc["score"], t2)

    print("\n[F] 评分已用上此前被丢弃的字段")
    import inspect
    body = inspect.getsource(admin_api._sig_score)
    used = [k for k in ("detail_ok", "sse", "first", "last", "foot", "pow_stale")
            if f'"{k}"' in body]
    print("      现已使用:", used)
    if set(used) >= {"detail_ok", "sse", "first", "last", "foot", "pow_stale"}:
        print(OK, "无罪信号与速率信息已全部进入研判")
    else:
        fails.append("F"); print(BAD)

    print("\n" + "=" * 70)
    print("验证结论:", "全部闭合" if not fails else f"以下项未闭合 -> {fails}")
    return fails


sys.exit(1 if asyncio.run(main()) else 0)
