/* frontend_snapshot_cycle_fuzz.js — 落盘「闭环」对拍模糊测试(4.4.0)
   用法:项目根 `node backend_async/scripts/frontend_snapshot_cycle_fuzz.js`

   ── 为什么必须单独有这一份 ────────────────────────────────────────────────
   frontend_gapstats_fuzz.js 分别验了「连空展示」与「快照并集」两个**函数**。
   但真正会伤到用户的是**闭环漂移**:反复「攒 → 落盘 → 刷新 → 回灌 → 再攒 →
   再落盘」若干轮之后,数据会不会凭空多、会不会悄悄丢、串长会不会无界增长。
   这个闭环在四轮复审里零覆盖 —— 而第五轮那个「特性根本不生效」的致命 bug,
   正是出在闭环的中段(回灌被 loadRoom 冲掉)。

   ── 两个模型缺一不可(实测教训,写在这里防后人删掉其一)────────────────
   ① 单页模型:长在线 + 断线 + 刷新,验无中生有 / 窗内不丢 / 串长有界;
   ② 双页模型:A 长期在线、B 中途开后被租约冻结、B 关闭时落盘。
   **只有 ① 是不够的**:单页流程里 S.hist 已含回灌种子,`mergeEnc` 是冗余的 ——
   把它退化成覆盖式,模型 ① 竟然照样全绿。补上模型 ② 后该变异立刻转红。
   一个测不出组件缺失的测试,不算覆盖了那个组件。

   退出码 0 = 闭环无漂移;2 = 有反例。
*/
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(__dirname, '..', '..');
const _ARGJ = process.argv.indexOf('--js');
const APPJS = _ARGJ > 0 ? process.argv[_ARGJ + 1] : ROOT + '/assets/app.js';
const T = { ROUND: 50001 }, HIST_CAP = 2200, HIST_WINDOW_MS = 86400000;
const src = fs.readFileSync(APPJS, 'utf8');
const i0 = src.indexOf('function encodeHist(hist){');
const i1 = src.indexOf('function saveSnapshot(){');
if (i0 < 0 || i1 < 0) { console.error('抠不到 encodeHist..clampEnc 原文(本脚本只能跑源码版)'); process.exit(1); }
const F = new Function('T', 'HIST_CAP', 'ELEM',
  src.slice(i0, i1) + '; return { encodeHist, decodeHist, mergeEnc, clampEnc };')(T, HIST_CAP, {});
const B = 1783000000000;
const e2r = e => { const o = []; for (let i = 0; i < e.r.length; i++)
  if (e.r[i] !== '0') o.push({ start: e.b + i * T.ROUND, n: Number(e.r[i]) }); return o; };
let bad = 0; const ex = [];
const fail = m => { bad++; if (ex.length < 5) ex.push(m); };

let maxLen = 0, cyc = 0;
for(let seed=1; seed<=1200; seed++){
  let x=seed*2654435761%4294967296; const rnd=()=>((x=(x*1103515245+12345)%2147483648)/2147483648);
  const WIN = [24,12,6][Math.floor(rnd()*3)];              // 生效窗(小时)
  const FETCH = 30;                                        // basic 档 history 硬闸
  const TOTAL = 2600;                                      // 真值时间线 ≈36h
  const truth=[]; for(let i=0;i<TOTAL;i++) truth.push(String(1+Math.floor(rnd()*9)));
  let disk=null, diskT=0;                                  // localStorage 里的快照
  const everSeen=new Map();                                // 用户**真正观测过**的全部格点(真值账本)
  let now=0;                                               // 当前格点下标

  const enc2rounds=(e)=>{const out=[];for(let i=0;i<e.r.length;i++) if(e.r[i]!=='0')
      out.push({start:e.b+i*T.ROUND, n:Number(e.r[i])}); return out;};
  const rounds2enc=(rs)=>{ if(!rs.length) return null;
      const h=rs.slice().sort((a,b)=>b.start-a.start); return F.encodeHist(h); };

  for(let cycle=0; cycle<6 && now<TOTAL-FETCH-2; cycle++){
    cyc++;
    // —— 刷新:hydrate(带过期判定 + 按当前窗钳内容)——
    let hist=[];
    const wallGapH = (now*T.ROUND - diskT*T.ROUND)/3600e3;
    if(disk && wallGapH <= WIN){                            // 未过期
      let rs=enc2rounds(disk);
      const newest=rs.length?rs[rs.length-1].start:0;
      rs=rs.filter(r=>r.start>=newest-WIN*3600e3);          // hydrateSnapshot 的当前窗钳制
      hist=rs.slice();
    }
    const seed0=hist.slice();
    // —— loadRoom:整体替换为硬闸后的 FETCH 局,再并回种子(4.4.0 修复)——
    const online = 20+Math.floor(rnd()*900);                // 本次在线多少局
    const start=now, end=Math.min(TOTAL-1, now+online);
    hist = [];
    for(let i=Math.max(start,end-FETCH+1); i<=end; i++) hist.push({start:B+i*T.ROUND, n:Number(truth[i])});
    seed0.forEach(r=>{ if(!hist.some(h=>h.start===r.start)) hist.push(r); });
    // —— 在线期间逐局 ingest ——
    for(let i=start; i<=end; i++){ if(!hist.some(h=>h.start===B+i*T.ROUND)) hist.push({start:B+i*T.ROUND,n:Number(truth[i])}); everSeen.set(i,truth[i]); }
    for(const [i] of [...Array(end-start+1)].map((_,k)=>[start+k])) everSeen.set(i,truth[i]);
    hist.sort((a,b)=>b.start-a.start);
    const cut0=hist[0].start-HIST_WINDOW_MS; hist=hist.filter(r=>r.start>=cut0);   // pruneHistWindow(24h 死值)
    // —— saveSnapshot:按窗裁 → 编码 → 与盘上并集 → 按窗裁 ——
    const cutH=hist[0].start-WIN*3600e3;
    let e=rounds2enc(hist.filter(r=>r.start>=cutH));
    if(e){ if(disk && wallGapH<=WIN) e=F.mergeEnc(disk,e); e=F.clampEnc(e,WIN); }
    if(e){ disk=e; diskT=end; maxLen=Math.max(maxLen,e.r.length); }
    // —— 断线/关机一段时间 ——
    now = end + 1 + Math.floor(rnd()*400);

    // ===== 不变量 =====
    if(disk){
      const rs=enc2rounds(disk);
      const newest=rs.length?rs[rs.length-1].start:0;
      for(const r of rs){
        const idx=Math.round((r.start-B)/T.ROUND);
        if(!everSeen.has(idx)){ fail(`seed=${seed} I1 无中生有 idx=${idx}`); break; }
        if(everSeen.get(idx)!==String(r.n)){ fail(`seed=${seed} I2 值不符 idx=${idx}`); break; }
      }
      // I3:窗内观测过且仍在窗内的,必须都还在
      const lo=newest-WIN*3600e3;
      for(const [idx,v] of everSeen){ const st=B+idx*T.ROUND;
        if(st>=lo && st<=newest && !rs.some(r=>r.start===st&&String(r.n)===v)){
          fail(`seed=${seed} I3 窗内丢失 idx=${idx}`); break; } }
      // I4:有界
      if(disk.r.length > Math.ceil(WIN*3600e3/T.ROUND)+2){ fail(`seed=${seed} I4 越界 len=${disk.r.length}`); }
    }
  }
}

let cyc2 = 0;
for(let seed=1; seed<=1500; seed++){
  let x=seed*2654435761%4294967296; const rnd=()=>((x=(x*1103515245+12345)%2147483648)/2147483648);
  const WIN=[24,12,6][Math.floor(rnd()*3)], TOTAL=2000;
  const truth=[]; for(let i=0;i<TOTAL;i++) truth.push(String(1+Math.floor(rnd()*9)));
  let disk=null;
  const seenBy={A:new Set(), B:new Set()};                 // 各页各自观测到的格点
  const hist={A:[], B:[]};
  const e2r=e=>{const o=[];for(let i=0;i<e.r.length;i++) if(e.r[i]!=='0') o.push({start:e.b+i*T.ROUND,n:Number(e.r[i])});return o;};
  const boot=(t,at)=>{                                      // 某页启动:hydrate + 并回种子
    let rs = disk ? e2r(disk) : [];
    const newest = rs.length?rs[rs.length-1].start:0;
    rs = rs.filter(r=>r.start>=newest-WIN*3600e3);
    hist[t]=rs.slice(); rs.forEach(r=>seenBy[t].add(Math.round((r.start-B)/T.ROUND)));
    for(let i=Math.max(0,at-29);i<=at;i++){ if(!hist[t].some(h=>h.start===B+i*T.ROUND)) hist[t].push({start:B+i*T.ROUND,n:Number(truth[i])}); seenBy[t].add(i);} };
  const live=(t,i)=>{ if(!hist[t].some(h=>h.start===B+i*T.ROUND)) hist[t].push({start:B+i*T.ROUND,n:Number(truth[i])}); seenBy[t].add(i); };
  const save=t=>{ if(!hist[t].length) return;
    const h=hist[t].slice().sort((a,b)=>b.start-a.start);
    const keep=h.filter(r=>r.start>=h[0].start-WIN*3600e3);
    let e=F.encodeHist(keep); if(!e) return;
    if(disk) e=F.mergeEnc(disk,e);
    e=F.clampEnc(e,WIN); if(e) disk=e; };

  // A 先开、长期在线;B 中途开、然后**停止 ingest**(被租约挤下),最后关闭时落盘
  let i=100; boot('A',i); save('A');
  for(let k=0;k<300 && i<TOTAL-1;k++){ i++; live('A',i); if(k%20===0) save('A'); }
  const bAt=i; boot('B',bAt); save('B');                    // B 开的那一刻盘上是 A 的
  for(let k=0;k<400 && i<TOTAL-1;k++){ i++; live('A',i); if(k%15===0) save('A'); }  // A 继续攒,B 冻结
  save('B');                                                // ★ B 关闭时落盘 —— 覆盖式会抹掉 A 攒的
  cyc2++;
  // 不变量:盘上必须仍含 A 在窗内观测到的一切
  const rs=e2r(disk), newest=rs.length?rs[rs.length-1].start:0, lo=newest-WIN*3600e3;
  for(const idx of seenBy.A){ const st=B+idx*T.ROUND;
    if(st>=lo && st<=newest && !rs.some(r=>r.start===st&&String(r.n)===truth[idx])){
      fail(`seed=${seed} A 在窗内的观测被 B 抹掉 idx=${idx}`); break; } }
  for(const r of rs){ const idx=Math.round((r.start-B)/T.ROUND);
    if(!seenBy.A.has(idx)&&!seenBy.B.has(idx)){ fail(`seed=${seed} 无中生有 idx=${idx}`); break; } }
}

console.log('落盘闭环对拍');
console.log(`  ① 单页(长在线 · 断线 · 刷新):${cyc} 个周期,最大快照串长 ${maxLen}`);
console.log(`  ② 双页(A 在线 / B 冻结后落盘):${cyc2} 组`);
console.log(`  违反「无中生有 / 窗内不丢 / 有界」= ${bad}`);
ex.forEach(e => console.log('   ✗ ' + e));
if (bad) { console.log('\n✗ 闭环出现漂移 —— 用户攒的数据会凭空多或悄悄少。'); process.exit(2); }
console.log('\n✓ 落盘闭环无漂移(单页 + 双页并发两个模型)');
