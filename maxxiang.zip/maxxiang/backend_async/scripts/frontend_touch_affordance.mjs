#!/usr/bin/env node
/* ═══════════════════════════════════════════════════════════════════════════
   frontend_touch_affordance.mjs — 触屏可达性回归钉(4.9.4)
   ═══════════════════════════════════════════════════════════════════════════
   ★ 这枚钉子守的是什么

     2026-07 用户实报「战况的『悬停看详情』在移动端好像没反应」。实地核查坐实:
     不是"好像"没反应,是**物理不可达**,三道锁串联,任何一道都足以致命:

       ① 唯一触发路径是 #trendScroll 的 pointermove,而触屏**静止点按根本不派发
          pointermove**(规范行为:touch 的 pointermove 只在手指移动时才来);
       ② 实测事件序列(Chromium 触屏模拟 iPhone 12,逐事件抓取):
            pointerdown(touch) → touchstart → pointerup(touch)
            → pointerleave(touch)×5 → touchend → mousemove → click(touch)
            → mouseleave×5
          —— pointerleave **早于 click** 抵达,onTrendLeave 先把卡藏掉、十字准星
          data-col 一并清掉,后面再怎么点都是空的;
       ③ 旧 onTrendClick 里还写着 D.trendTip.hidden = true(旧注「触屏点按后随手
          收起」),把最后一条路也堵死。

     同族问题远不止战况:全站 3500+ 个 title 在触屏浏览器**一律不渲染** ——
     主序列 1728 颗珠、游戏面板战况 1727 颗、出怪规律 9 行与「偏差/最大」两个表头
     承载的 2σ 显著性判据与 24h 窗截断口径、「单击聚光」用法、真实/模拟游戏
    「真实扣除星币」的差别、名录「断」态释义,手机上一个字都读不到。

   ★ 为什么必须是浏览器而不是 jsdom

     本钉的核心断言是「**触屏静止点按不派发 pointermove**」与「**pointerleave 早于
     click**」这两条**真实事件时序**。jsdom 不模拟指针硬件,合成什么就有什么 ——
     在 jsdom 里这枚钉子永远是绿的,而它最该报警的那一刻恰恰测不出来。
     故本脚本走 Playwright + Chromium 真触屏模拟;缺依赖则**显式 skip 并退 0**
     (与 test_frontend_js_scope 的作用域钉同款处置:缺 acorn 则 skip,不伪装通过)。

   ★ 反向钉(最重要的一条)
     A 组第一条断言「触屏点战况行 → 悬浮卡出现」在**修复前当场是红的**。
     谁把 hover 依赖写回来,它当场变红 —— 这才是这枚钉子存在的意义。

   ★ 用法
       node backend_async/scripts/frontend_touch_affordance.mjs [--url http://127.0.0.1:5173/]
     默认对 127.0.0.1:5173 起的静态服务取页;本地演示需先把 round-engine.js /
     mock-api.js 注回 index.html(仓库 2.9.0 起生产不装载它们),或直接指向真实后端。
   ═══════════════════════════════════════════════════════════════════════════ */
'use strict';

const argUrl = (() => {
  const i = process.argv.indexOf('--url');
  return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : 'http://127.0.0.1:5173/';
})();
const BASE = argUrl.replace(/\/+$/, '') + '/';
const ADMIN = BASE + 'admin.html';
const BOOT_MS = 6500;                       // 首屏落数据(序列/战况/出怪规律全部就位)
const sleep = ms => new Promise(r => setTimeout(r, ms));

let playwright;
try {
  playwright = await import('playwright');
} catch {
  console.log('[skip] 未安装 playwright —— 触屏可达性钉需要真浏览器的指针事件时序;');
  console.log('       jsdom 合成什么就有什么,在那里这枚钉子永远是绿的,等于没钉。');
  console.log('       安装后再跑:  npm i --no-save playwright && npx playwright install chromium');
  process.exit(0);
}
/* ★ 6 审教训:引擎必须可切。本轮最恶的一个缺陷(平滑滚动把气泡掐掉)在 Chromium 上
   **测不出来** —— 它的平滑滚动动画在点击前就跑完了;Firefox 的同一动画跑了 1.4 秒,
   一点就露。单引擎绿不等于没问题。CI 至少跑 chromium + firefox 两轮。 */
const ENGINE = (() => {
  const i = process.argv.indexOf('--engine');
  return (i > 0 && process.argv[i + 1]) ? process.argv[i + 1] : 'chromium';
})();
const chromium = playwright[ENGINE];
if (!chromium) { console.log('[skip] 未知引擎:' + ENGINE + '(可选 chromium|firefox|webkit)'); process.exit(0); }
const { devices } = playwright;
console.log('引擎:' + ENGINE + '   目标:' + BASE);

let pass = 0, fail = 0;
const ok = (name, cond, detail = '') => {
  if (cond) { pass++; console.log('  [✓] ' + name); }
  else { fail++; console.log('  [✗] ' + name + (detail ? '   << ' + detail : '')); }
};

const browser = await chromium.launch();

/* ═══ A. 移动端触屏:三道锁是否真的全开 ═══════════════════════════════════ */
console.log('\n═══ A. 移动端触屏(iPhone 12 · 390×664)═══');
const ctxM = await browser.newContext({ ...devices['iPhone 12'], hasTouch: true, isMobile: true, locale: 'zh-CN' });
const m = await ctxM.newPage();
const errs = []; m.on('pageerror', e => errs.push(e.message));
await m.goto(BASE, { waitUntil: 'domcontentloaded' });
await m.waitForTimeout(BOOT_MS);

ok('零未捕获异常', errs.length === 0, errs.join(' | '));
ok('<html data-input="touch"> 已标记(输入方式判定生效)',
   await m.evaluate(() => document.documentElement.dataset.input) === 'touch');
ok('战况副标题改为触屏文案(不再宣传按不出来的功能)',
   /点格看详情/.test(await m.evaluate(() => document.getElementById('trendSub').textContent)),
   await m.evaluate(() => document.getElementById('trendSub').textContent));

/* ── A·物证:静止点按的真实事件序列 ─────────────────────────────────────
   这一条不判对错,只把物证打出来 —— 序列里若出现 pointermove,说明浏览器行为
   变了,上面那套推理的前提要重新核。 */
await m.evaluate(() => document.getElementById('trendScroll').scrollIntoView({ block: 'center' }));
await sleep(500);
await m.evaluate(() => {
  window.__ev = [];
  const el = document.getElementById('trendScroll');
  ['pointerdown', 'pointermove', 'pointerup', 'pointerleave', 'touchstart', 'touchend', 'mousemove', 'click']
    .forEach(t => el.addEventListener(t, e => window.__ev.push(t + (e.pointerType ? '(' + e.pointerType + ')' : '')), true));
});
const row = (await m.$$('.trend-row'))[3];
await row.tap();
await sleep(350);
const seq = await m.evaluate(() => window.__ev);
console.log('      · 物证 · 触屏静止点按的事件序列:');
console.log('        ' + seq.join(' → '));
/* ★ 必须限定 pointerType(6 审踩过):WebKit 在 tap 之后约 330ms 会**合成**
   `pointermove(mouse)` 与 `pointerleave(mouse)`,序列里确实有 pointermove ——
   但那是合成鼠标事件,不是"触屏派发了 pointermove"。本钉要钉的是后者。 */
ok('物证:触屏静止点按确实不派发 pointermove(touch)(hover 通道天然不可达)',
   !seq.some(x => x === 'pointermove(touch)'), seq.join(' → '));
/* ★ 断言必须引擎无关(6 审踩过):此处原先写死 'click(touch)' —— 而 **WebKit 派发的是
   `click(mouse)`**(它把 click 当作合成的鼠标兼容事件),于是在 Safari 内核上
   lastIndexOf 返回 -1、断言假红。改为按事件名前缀比索引。 */
const iLeave = seq.findIndex(x => x.startsWith('pointerleave'));
const iClick = seq.findIndex(x => x.startsWith('click'));
ok('物证:pointerleave 确实早于 click 抵达(不能在 leave 里收卡)',
   iLeave >= 0 && iClick >= 0 && iLeave < iClick, seq.join(' → '));
/* ★ WebKit 合成鼠标事件钉(6 审实证,此前六轮一直挂着"待真机确认"):
   Safari 内核在触屏 tap 后会合成 `mousemove` 且把 `click` 的 pointerType 标成
   **mouse** —— 这正是"看起来依赖 hover 的页面在 iOS 上要点两次"的成因。
   本实现免疫的理由必须被钉住:① hover 通道绑的是 pointermove 而非 mousemove;
   ② onTrendMove/onTrendLeave 由 S.input 门控,而 S.input 由**pointerdown**
   (真 pointerType=touch)写定,合成的 mouse 事件不经 pointerdown、改不动它。 */
ok('★ 合成鼠标钉:tap 后合成 mousemove 未让 S.input 退回 mouse',
   await m.evaluate(() => window.JiufaDev.S.input) === 'touch');
/* ★ 合成鼠标钉必须验**结果**而不是验事件序列(6 审踩过):WebKit 的合成
   pointermove/pointerleave 在 tap 后 ~330ms 才到,验序列既滞后又脆。
   直接看它们到齐之后卡有没有被改写 —— 这才是用户真正感知到的东西。
   防线原理:S.input 由**真 pointerdown(pointerType=touch)** 写定,合成的 mouse
   事件不经 pointerdown ⇒ isTouchInput() 恒为 true ⇒ onTrendMove/onTrendLeave
   双双早退。若哪天有人把 hover 逻辑改绑到 mousemove 上,本钉当场红。 */
const beforeSynth = await m.evaluate(() => ({
  hidden: document.querySelector('.trend-tip').hidden,
  top: document.querySelector('.trend-tip').style.top,
  col: document.getElementById('trendScroll').dataset.col || '' }));
await sleep(1300);                     // 覆盖 WebKit 合成事件的到达窗口(实测 ~330ms)
const afterSynth = await m.evaluate(() => ({
  hidden: document.querySelector('.trend-tip').hidden,
  top: document.querySelector('.trend-tip').style.top,
  col: document.getElementById('trendScroll').dataset.col || '',
  input: window.JiufaDev.S.input }));
ok('★ 合成鼠标钉:合成事件到齐后 S.input 仍是 touch(未被 mouse 类合成事件改写)',
   afterSynth.input === 'touch', JSON.stringify(afterSynth));
ok('★ 合成鼠标钉:合成事件到齐后卡与十字准星逐字未变(hover 通道未复活)',
   afterSynth.hidden === beforeSynth.hidden && afterSynth.top === beforeSynth.top
   && afterSynth.col === beforeSynth.col,
   JSON.stringify({ beforeSynth, afterSynth }));

const t1 = await m.evaluate(() => ({
  hidden: document.querySelector('.trend-tip').hidden,
  text: document.querySelector('.trend-tip').textContent,
  col: document.getElementById('trendScroll').dataset.col || '',
}));
ok('★ 反向钉:触屏点战况行 → 悬浮卡出现(修复前此条为红)', t1.hidden === false, JSON.stringify(t1));
ok('悬浮卡内容完整(时刻 · 号位 · 大小 · 单双)', /\d{2}:\d{2}:\d{2}/.test(t1.text) && /·/.test(t1.text), t1.text);
ok('列十字准星 data-col 点亮(2.6 能力在触屏上恢复)', t1.col !== '', 'col=' + t1.col);

await row.tap(); await sleep(350);
ok('再点同一行 → 收卡(toggle 语义)',
   await m.evaluate(() => document.querySelector('.trend-tip').hidden) === true
   && await m.evaluate(() => window.JiufaDev.S.trendTapId) === '');
/* ★ 断口钉(4.9.4 三审揪出):断口原文只挂在最左那格 .trend-cell.idx 的 title 上,
   而战况卡此前不含断口段、通用气泡又把整个 #trendScroll 排除在外(战况另走专线)——
   于是桌面还能精确悬停到那格 10px 宽的 idx 看到「⟨此处 N 局未观测⟩」,触屏一点办法
   都没有,4.4.0 花大力气做的断口标记在这条路径上等于没做。现只补触屏分支
  (桌面有 idx 格原生 title 兜底,补了反而改动既有文案)。
   mock 数据本身无断口 —— 直接把第 4 行往后整体前移 9 个格点造一个真缺口。 */
const holeGap = await m.evaluate(() => {
  const S = window.JiufaDev.S, rows = S.trendCtx && S.trendCtx.rows;
  if (!rows || rows.length < 8) return 0;
  for (let i = 4; i < rows.length; i++) rows[i] = { ...rows[i], start: rows[i].start - 9 * 50001 };
  return Math.round((rows[3].start - rows[4].start) / 50001) - 1;
});
await (await m.$$('.trend-row'))[3].tap(); await sleep(350);
const holeTxt = await m.evaluate(() => document.querySelector('.trend-tip').textContent);
ok('★ 断口钉:触屏战况卡含断口段(4.4.0 断口标记在触屏路径上恢复)',
   holeGap === 9 && /未观测/.test(holeTxt), 'gap=' + holeGap + ' | ' + holeTxt);
await (await m.$$('.trend-row'))[3].tap(); await sleep(250);   // 收卡,复位

/* ── A·防翻车:滑动不得弹卡 ────────────────────────────────────────────
   序列与战况都是可滚容器。不做点/滑判据的话,每一次滚动都会拖着一张卡跟手跑
   —— 这是同类改造最常见的翻车点,故单列一钉。 */
const sbox = await (await m.$('#trendScroll')).boundingBox();
await m.evaluate(() => { document.querySelector('.trend-tip').hidden = true; });
await m.evaluate(async ([x, y]) => {
  const el = document.elementFromPoint(x, y);
  const o = (px, py) => ({ bubbles: true, cancelable: true, pointerType: 'touch', pointerId: 7,
                           clientX: px, clientY: py, isPrimary: true });
  el.dispatchEvent(new PointerEvent('pointerdown', o(x, y)));
  for (let i = 1; i <= 6; i++) el.dispatchEvent(new PointerEvent('pointermove', o(x, y - i * 12)));
  el.dispatchEvent(new PointerEvent('pointerup', o(x, y - 72)));
}, [Math.round(sbox.x + sbox.width / 2), Math.round(sbox.y + sbox.height * 0.6)]);
await sleep(300);
ok('滑动手势 → 不弹卡(点/滑判据生效)',
   await m.evaluate(() => document.querySelector('.trend-tip').hidden === true
                       && document.getElementById('tipBubble').hidden === true));

/* ── A·通用 title 通道 ────────────────────────────────────────────────── */
const bead = (await m.$$('#roadGrid .bead:not(.is-void)'))[20];
await m.evaluate(el => el.scrollIntoView({ block: 'center' }), bead);
await sleep(400); await bead.tap(); await sleep(300);
const t2 = await m.evaluate(() => ({ h: document.getElementById('tipBubble').hidden,
                                     t: document.getElementById('tipBubble').textContent }));
ok('★ 触屏点主序列珠 → 气泡出现(1728 颗珠的 title 在触屏上恢复可读)', t2.h === false, JSON.stringify(t2));
ok('珠气泡含法术名 · 倍率 · 开出时刻', /×\d+/.test(t2.t) && /\d{2}:\d{2}:\d{2}/.test(t2.t), t2.t);

const th = await m.$('.census thead th[title]');
await m.evaluate(el => el.scrollIntoView({ block: 'center' }), th);
await sleep(400); await th.tap(); await sleep(300);
const t3 = await m.evaluate(() => document.getElementById('tipBubble').textContent);
ok('★ 正确性:点「偏差」表头 → 2σ 显著性判据可见(不给出去会让人把噪声当信号)',
   /2σ|抽样波动/.test(t3), t3.slice(0, 70));

const cell = (await m.$$('.spell-cell'))[2];
await m.evaluate(el => el.scrollIntoView({ block: 'center' }), cell);
await sleep(400);
const hlBefore = await m.evaluate(() => document.getElementById('roadGrid').className);
await cell.tap(); await sleep(350);
const t4 = await m.evaluate(() => ({ tip: document.getElementById('tipBubble').textContent,
                                     hl: document.getElementById('roadGrid').className }));
ok('点妖怪卡 → 聚光用法说明可见(3.4.4 的能力在触屏上可发现)', /聚光/.test(t4.tip), t4.tip.slice(0, 40));
ok('★ 气泡不抢点击:点妖怪卡 → 聚光仍然生效', t4.hl !== hlBefore, hlBefore + ' → ' + t4.hl);

/* ★ 多指钉(4.9.4 五审揪出):捏合缩放时第二指落下又抬起(位移≈0、时长≈0)会被判成
   tap 而误弹气泡;更隐蔽的一半是第二指的 pointerdown 覆盖了 tapX/tapY/tapT,
   主指抬起时位移相对第二指落点算,轻易超阈被误判成"滑动" —— 捏合期间正常的
   单指 tap 反而弹不出来。现 pointerdown/pointerup 双侧按 e.isPrimary 门控。 */
const multi = await m.evaluate(async () => {
  document.getElementById('tipBubble').hidden = true;
  const el = document.querySelector('#roadGrid .bead:not(.is-void)');
  const r = el.getBoundingClientRect();
  const ev = (t, id, pri, x, y) => el.dispatchEvent(new PointerEvent(t,
    { bubbles: true, cancelable: true, pointerType: 'touch', pointerId: id, isPrimary: pri, clientX: x, clientY: y }));
  ev('pointerdown', 1, true,  r.left + 2,  r.top + 2);
  ev('pointerdown', 2, false, r.left + 40, r.top + 40);
  ev('pointerup',   2, false, r.left + 40, r.top + 40);
  await new Promise(x => setTimeout(x, 200));
  const bySecond = !document.getElementById('tipBubble').hidden;
  ev('pointerup', 1, true, r.left + 2, r.top + 2);
  await new Promise(x => setTimeout(x, 250));
  const byPrimary = !document.getElementById('tipBubble').hidden;
  return { bySecond, byPrimary };
});
/* ★ 平滑滚动钉(4.9.4 六审揪出,Firefox 上才暴露):容器带 scroll-behavior:smooth,
   程序化平滑滚动会持续派发 scroll —— 实测 Firefox 一次 scrollIntoView 的动画跑了
   1.4 秒,期间用户点出的气泡在**同一毫秒**被自己的 scroll 监听收掉。而本项目到处是
   程序化滚动(stickPin 每局贴底 / pulseBead 联动 / snapScroll),新局落地那一下正在
   平滑滚动,用户此刻点珠必被自己人掐掉。现改为**跟随锚点**,滚出视口才收。 */
const smooth = await m.evaluate(async () => {
  const wrap = document.getElementById('roadWrap');
  const beads = [...document.querySelectorAll('#roadGrid .bead:not(.is-void)')];
  const el = beads[Math.max(0, beads.length - 40)];
  // ★ 构造要点(踩过一次):必须先把锚点**滚进视口**再造动画。若在锚点还在视口外时
  //   就点,followTip 判定"锚点不在视口内"而收掉 —— 那是正确行为,不是本钉要测的。
  el.scrollIntoView({ block: 'center' });
  await new Promise(r => setTimeout(r, 900));             // 等第一次滚动落定
  wrap.scrollTo({ top: Math.max(0, wrap.scrollTop - 160), behavior: 'smooth' });  // 再造一次平滑滚动
  await new Promise(r => setTimeout(r, 60));              // 动画进行中就点(锚点仍在视口内)
  const r0 = el.getBoundingClientRect();
  if (r0.top < 0 || r0.top > innerHeight) return { skip: true, reason: '锚点不在视口内,构造失败' };
  const ev = t => el.dispatchEvent(new PointerEvent(t, { bubbles: true, cancelable: true,
    pointerType: 'touch', pointerId: 1, isPrimary: true, clientX: r0.left + 2, clientY: r0.top + 2 }));
  ev('pointerdown'); ev('pointerup');
  await new Promise(r => setTimeout(r, 700));             // 让平滑滚动跑完
  const b = document.getElementById('tipBubble');
  return { hidden: b.hidden, top: b.style.top, behavior: getComputedStyle(wrap).scrollBehavior };
});
ok('★ 平滑滚动钉:滚动进行中点出的气泡不被自己的 scroll 监听掐掉',
   smooth.skip ? false : smooth.hidden === false, JSON.stringify(smooth));
ok('★ 多指钉:非主指针不独自触发气泡', multi.bySecond === false, JSON.stringify(multi));
ok('★ 多指钉:主指的 tap 判据未被第二指污染(仍能正常弹)', multi.byPrimary === true, JSON.stringify(multi));
await sleep(4600);          // 多指钉尾部主指 tap 已重新弹出气泡 —— 自动收起断言必须排在它之后
ok('气泡按时自动收起(跳转/开层后不孤悬)',
   await m.evaluate(() => document.getElementById('tipBubble').hidden) === true);
await ctxM.close();

/* ═══ B. 桌面回归护栏:为触屏改的东西不许碰桌面 ═══════════════════════════ */
console.log('\n═══ B. 桌面鼠标回归护栏(1440×900)═══');
const ctxD = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: 'zh-CN' });
const d = await ctxD.newPage();
const derrs = []; d.on('pageerror', e => derrs.push(e.message));
await d.goto(BASE, { waitUntil: 'domcontentloaded' });
await d.waitForTimeout(BOOT_MS);
ok('零未捕获异常', derrs.length === 0, derrs.join(' | '));
ok('<html data-input="mouse">', await d.evaluate(() => document.documentElement.dataset.input) === 'mouse');
ok('副标题维持「悬停看详情」原文', /悬停看详情/.test(await d.evaluate(() => document.getElementById('trendSub').textContent)));
await d.evaluate(() => document.getElementById('trendScroll').scrollIntoView({ block: 'center' }));
await sleep(400);
const drb = await (await d.$$('.trend-row'))[3].boundingBox();
await d.mouse.move(drb.x + drb.width * 0.35, drb.y + drb.height / 2);
await sleep(300);
const dt = await d.evaluate(() => ({ h: document.querySelector('.trend-tip').hidden,
                                     t: document.querySelector('.trend-tip').textContent,
                                     c: document.getElementById('trendScroll').dataset.col || '' }));
ok('桌面 hover → 悬浮卡照旧', dt.h === false, JSON.stringify(dt));
ok('桌面 hover → 十字准星照旧', dt.c !== '');
ok('桌面 hover 内容含「距上次」推导(2.6/2.6.1 未被拆坏)', /距上次/.test(dt.t), dt.t);
ok('★ 断口钉反面:桌面卡**不含**断口段(既有文案逐字不动)', !/未观测/.test(dt.t), dt.t);
ok('桌面 .trend-cell.idx 的 title 兜底仍在',
   await d.evaluate(() => !!document.querySelector('.trend-cell.idx')?.getAttribute('title')));
await d.mouse.move(10, 10); await sleep(250);
ok('桌面移出 → 悬浮卡收起(pointerleave 未被误门控掉)',
   await d.evaluate(() => document.querySelector('.trend-tip').hidden) === true);
/* ★ 自伤钉(4.9.4 复查实测揪出):renderTrendWindow 里的收卡最初写成**无条件**,
   桌面 hover 住一行后只要战况整窗重建(新局到账 / 滚动换窗),卡就被平白收掉 ——
   触屏的卡锚在具体行元素上、行一回收就成孤儿,所以要收;桌面的卡由每一次
   pointermove 重新生成、不锚任何节点,收它纯属自伤。现已门控到 isTouchInput()。 */
await d.mouse.move(drb.x + drb.width * 0.35, drb.y + drb.height / 2); await sleep(300);
const preRebuild = await d.evaluate(() => document.querySelector('.trend-tip').hidden);
await d.evaluate(() => { const w = document.querySelector('.trend-body-wrap'); w.scrollTop += 120; });
await sleep(400);
ok('★ 自伤钉:桌面 hover 卡在战况整窗重建后未被误收',
   preRebuild === false && await d.evaluate(() => document.querySelector('.trend-tip').hidden) === false);
ok('桌面不弹自绘气泡(仍走系统 title,零双层叠加)',
   await d.evaluate(() => document.getElementById('tipBubble').hidden) === true);
/* ★ 混合设备钉(4.9.4 复查实测揪出):仓库既有四处 @media(hover:none) 兜底
   (app.css 222/320/3401/3455)守的是「触屏拿不到 :hover ⇒ 删除键与账号动作组必须
   常显、热区必须够大」。但媒体查询判的是**设备有没有 hover 能力**,而不是**用户
   此刻在用什么** —— 触屏笔记本与接了妙控板的 iPad 都是 hover:hover,四条兜底整片
   落空,手指点上去删除键根本不存在。本钉在**媒体查询保证不命中**的纯鼠标上下文里
   手工翻转 data-input,单独验证 data-input 对偶确实在干活。
   注:.ri-del 带 transition:opacity .15s —— 翻转后必须等过渡走完再读计算值,
   否则读到的是过渡起点(0),会报一个不存在的假问题。 */
const mqOff = await d.evaluate(() => matchMedia('(hover:none)').matches);
await d.evaluate(() => document.getElementById('railOpen')?.click()); await sleep(700);
await d.evaluate(() => { document.documentElement.dataset.input = 'mouse'; }); await sleep(400);
const asMouse = await d.evaluate(() => { const x = document.querySelector('.room-item .ri-del');
  return x ? { o: getComputedStyle(x).opacity, w: getComputedStyle(x).width } : null; });
await d.evaluate(() => { document.documentElement.dataset.input = 'touch'; }); await sleep(400);
const asTouch = await d.evaluate(() => { const x = document.querySelector('.room-item .ri-del');
  return x ? { o: getComputedStyle(x).opacity, w: getComputedStyle(x).width } : null; });
ok('★ 混合设备钉:media(hover:none) 确实不命中(隔离前提成立)', mqOff === false);
if (asMouse && asTouch) {
  ok('★ 混合设备钉:data-input=touch 对偶让删除键常显(mouse 态复现旧洞 opacity:0)',
     asMouse.o === '0' && asTouch.o === '0.45', JSON.stringify({ asMouse, asTouch }));
  ok('★ 混合设备钉:热区撑到 30px(WCAG 2.5.8 底线)', asTouch.w === '30px', asTouch.w);
} else ok('混合设备钉:名录条目已渲染', false, '无 .room-item .ri-del');
await d.evaluate(() => { document.documentElement.dataset.input = 'mouse'; });
ok('★ title 属性未被删 —— predgap/replay/it 三支既有 jsdom 钉读的就是它',
   await d.evaluate(() => document.querySelectorAll('[title]').length) > 1500,
   String(await d.evaluate(() => document.querySelectorAll('[title]').length)));
await ctxD.close();

/* ═══ C. iPad Pro 横屏:cockpit × hover:none 的交叉格 ═════════════════════ */
console.log('\n═══ C. iPad Pro 横屏 1366×1024(cockpit × hover:none)═══');
const ctxP = await browser.newContext({ viewport: { width: 1366, height: 1024 }, hasTouch: true, deviceScaleFactor: 2, locale: 'zh-CN' });
const p = await ctxP.newPage();
await p.goto(BASE, { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(BOOT_MS);
const pi = await p.evaluate(() => {
  const e = document.getElementById('railOpen');
  const cs = e && getComputedStyle(e), r = e && e.getBoundingClientRect();
  return { layout: document.body.dataset.layout, input: document.documentElement.dataset.input,
           menu: cs ? cs.display : '(无)', menuW: r ? Math.round(r.width) : 0 };
});
ok('确认落 cockpit 且判定为触屏(这一格才是洞所在)',
   pi.layout === 'cockpit' && pi.input === 'touch', JSON.stringify(pi));
ok('★ 驾驶舱在触屏下放出顶栏 ☰(旧版 display:none,只剩 64px 牌匾一个暗门)',
   pi.menu !== 'none' && pi.menuW > 0, JSON.stringify(pi));
await p.evaluate(() => document.getElementById('rail').classList.remove('is-open'));
await (await p.$('#railOpen')).tap(); await sleep(500);
ok('☰ 点击 → 名录展开',
   await p.evaluate(() => document.getElementById('rail').classList.contains('is-open')) === true);
await ctxP.close();

/* ═══ D. 后台管理台 ═══════════════════════════════════════════════════════ */
console.log('\n═══ D. 后台管理台 · 移动端 390 宽 ═══');
const ctxA = await browser.newContext({ ...devices['iPhone 12'], hasTouch: true, isMobile: true, locale: 'zh-CN' });
const a = await ctxA.newPage();
const aerrs = []; a.on('pageerror', e => aerrs.push(e.message));
await a.goto(ADMIN, { waitUntil: 'domcontentloaded' });
await a.waitForTimeout(2500);
ok('零未捕获异常', aerrs.length === 0, aerrs.join(' | '));
// 未登录时 #shell{display:none},后代 rect 恒为 0 —— 先放出外壳再量(只改量法,不改判据)
await a.evaluate(() => { document.getElementById('login').hidden = true; document.getElementById('shell').classList.add('on'); });
await sleep(400);
const nav = await a.evaluate(() => [...document.querySelectorAll('.nav-item')].map(b => {
  const t = b.querySelector('.tip'), r = t && t.getBoundingClientRect();
  return { name: t ? t.textContent : '', disp: t ? getComputedStyle(t).display : '-', w: r ? Math.round(r.width) : 0 };
}));
ok('★ 左栏十枚印在手机上内联出全名(旧版 .tip{display:none},十个孤立汉字)',
   nav.length === 10 && nav.every(n => n.disp !== 'none' && n.w > 20),
   nav.map(n => n.name + '/' + n.w).join(' '));
ok('左轨横向可滚(十枚印总宽 > 视口,横滑看全)',
   await a.evaluate(() => { const r = document.querySelector('.rail'); return r.scrollWidth > r.clientWidth + 20; }));
await (await a.$('#revPill')).tap(); await sleep(300);
ok('点 rev 徽章 → 气泡出现(后台 31 处 title 在触屏上恢复可读)',
   await a.evaluate(() => document.getElementById('tipBubble').hidden) === false,
   await a.evaluate(() => document.getElementById('tipBubble').textContent));
await ctxA.close();

/* ★ 横屏钉(4.9.4 复查实测揪出):admin.css 有**两格**把 .nav-item .tip 藏掉 ——
   @media(max-width:760px) 与 @media(min-width:761px)and(max-height:440px)。
   首版只补了前者,而**手机横屏 844×390** 恰好落进后者(宽 844≥761、高 390≤440),
   十枚印在横屏上又退回十个孤立汉字。竖屏测得再全,横屏也照样漏。 */
console.log('\n═══ E. 后台管理台 · 手机横屏 844×390 ═══');
const ctxL = await browser.newContext({ viewport: { width: 844, height: 390 }, hasTouch: true, isMobile: true, locale: 'zh-CN' });
const l = await ctxL.newPage();
await l.goto(ADMIN, { waitUntil: 'domcontentloaded' });
await l.waitForTimeout(2200);
await l.evaluate(() => { document.getElementById('login').hidden = true; document.getElementById('shell').classList.add('on'); });
await sleep(400);
const navL = await l.evaluate(() => [...document.querySelectorAll('.nav-item')].map(n => {
  const t = n.querySelector('.tip'), r = t && t.getBoundingClientRect();
  return { n: t ? t.textContent : '', d: t ? getComputedStyle(t).display : '-', w: r ? Math.round(r.width) : 0 };
}));
ok('★ 横屏钉:手机横屏下十枚印仍出全名(旧版落进第二格 display:none)',
   navL.length === 10 && navL.every(x => x.d !== 'none' && x.w > 10),
   navL.map(x => x.n + '/' + x.d).join(' '));
await ctxL.close();

await browser.close();
console.log('\n═══════════════════════════════════════════');
console.log(`触屏可达性回归钉:${pass} 通过 / ${fail} 失败`);
console.log('═══════════════════════════════════════════');
process.exit(fail ? 1 : 0);
