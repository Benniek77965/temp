/* 用法:项目根 `npm i jsdom` 后 `node backend_async/scripts/frontend_switch_autobind_jsdom.js`(Node ≥20)。 */
/* 切换即添加(5.0.8)的前端行为冒烟:app.js 在 jsdom 真 DOM 中原样执行,仅桩网络。
   有 index.html 就用交付版;没有(只拿到 assets/ 的裁剪包)则按 app.js cacheDom()
   的 id 清单生成一份骨架页 —— 骨架只保证「元素存在、类型对得上」,布局类断言不在
   本脚本范围内。桩后端:登录态开启,名录闸与真实后端同口径 —— 明细端点只放行绑定房,
   /api/monitor/add 只对"在播"的房放行并落绑定。
   覆盖(每个场景开一个干净的 jsdom):
     ① 登录态 · 搜索框敲不在名录且在播的房 → 自动 add → 入名录 → 打开
     ② 登录态 · 敲不在名录且未开播的房 → add 被拒 → 只提示 → 不入名录 → 不进重试循环 → 恢复原房
     ③ 登录态 · 残影卡(localStorage 有、服务端没绑定)点击 → 自动 add → 打开
     ③b 残影卡 · 未开播 → 卡从名录与 localStorage 清退,S.alias 不变
     ④ 未启用登录 · 敲号维持「看而不加」:零 add 调用
     ⑤ 登录态 · 存储恢复(explicit=false)撞 room_not_bound → 绝不自动 add
     ⑥ 登录态 · 问不到(live_unverifiable)→ 只提示不删卡;再敲一次 = 新的一次尝试
     ⑦ 登录态 · 名录满 → 连上游都不打,直接说满
     ⑧ 登录态 · 分享链接 ?room=(显式)指向不在名录的房:在播 → 自动 add → 打开;未开播 → 用原话告知并回退首房 */
const fs = require('fs');
const path = require('path');
let JSDOM;
try { ({ JSDOM } = require('jsdom')); }
catch { ({ JSDOM } = require(path.resolve(process.env.JSDOM_DIR || 'node_modules', 'jsdom'))); }
const ROOT = path.resolve(__dirname, '..', '..');
const APPJS = fs.readFileSync(ROOT + '/assets/app.js', 'utf8');

/* ── 页面:交付版 index.html,或按 cacheDom() 的 id 清单生成骨架 ─────────────── */
function skeletonHtml(){
  const m = APPJS.match(/const ids = \[([\s\S]*?)\];\s*ids\.forEach/);
  if (!m) throw new Error('找不到 cacheDom 的 id 清单');
  const ids = [...m[1].matchAll(/'([A-Za-z0-9_]+)'/g)].map(x => x[1]);
  const tag = id => {
    if (/Form$/.test(id)) return 'form';
    if (/Input$|^roomSearch$|^authUser$|^authPass$|^reg(User|Pass|Pass2|Invite|Contact)$/.test(id)) return 'input';
    if (/Cols$|^wvDay$/.test(id)) return 'select';
    if (/Avatar$|^qrBox$|^payQr$/.test(id)) return 'img';
    if (/Frame$/.test(id)) return 'iframe';
    if (/Open$|Close$|Btn$|Submit$|Go$|Refresh$|Back$|Prev$|Next$|Logout$|Buy$|Toggle$|Expand$|Replay$|CheckAll$|Sync$|Switch$|Diy$|Official$|Aide$|Acct$|^tab(Real|Sim)$|^regDoneBack$|^skinSwitch$/.test(id)) return 'button';
    return 'div';
  };
  // app.js 会在这些句柄下按选择器找子元素(实地 grep `D.x.querySelector`);骨架预置。
  const inner = { connState: '<b></b>', jiufaHint: '<strong></strong><p></p>', authGate: '<div class="auth-card"></div>',
                  simPane: '<div class="jiufa-stage"></div>', vipGate: '<div class="vip-gift"></div>' };
  const els = ids.map(id => `<${tag(id)} id="${id}">${inner[id] || ''}</${tag(id)}>`).join('\n');
  return `<!doctype html><html><head><meta charset="utf-8"></head><body>
<div class="deck"></div><div class="phase-track"></div>
<div class="phase-node" data-phase="cast"></div><div class="phase-node" data-phase="seal"></div><div class="phase-node" data-phase="draw"></div>
<div class="trend-body-wrap"></div><div class="wide-body"></div><table class="census"></table><div class="rail-plaque"></div>
<div id="predictDock"></div>
${els}
</body></html>`;
}
const HAS_INDEX = fs.existsSync(ROOT + '/index.html');
const HTML = HAS_INDEX ? fs.readFileSync(ROOT + '/index.html', 'utf8') : skeletonHtml();

const A = (n, c, extra) => { console.log(`  [${c ? '✓' : '✗'}] ${n}${extra ? '  ' + extra : ''}`);
  if (!c) process.exitCode = 1; };
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ── 桩后端(与真实后端同口径的最小模型)───────────────────────────────────── */
function makeBackend({ login = true, roster = ['888'], live = [], unverifiable = [] } = {}){
  const B = { login, roster: new Set(roster), live: new Set(live), unverifiable: new Set(unverifiable),
              calls: [], toasts: [] };
  const NOT_BOUND = { ok: false, error: 'room_not_bound',
    message: '该直播间不在你的名录中 —— 请先通过「＋ 添加直播间」加入名录再打开' };
  B.route = (url) => {
    const u = new URL(url, 'http://t/');
    const p = u.pathname, q = u.searchParams;
    B.calls.push({ p, q: Object.fromEntries(q.entries()) });
    const gate = alias => (B.login && !B.roster.has(alias)) ? { __err: 403, body: NOT_BOUND } : null;
    if (p === '/api/auth/session')
      return B.login ? { ok: true, enabled: true, authed: true, user: { id: 7, name: 't' } }
                     : { ok: true, enabled: false };
    if (p === '/api/live-rooms')
      return { ok: true, rooms: [...B.roster].map(a => ({ alias: a, roomId: a, nickname: '房 ' + a, avatar: '',
        canPlay: '1', serverNowMs: Date.now(), serverOffsetMs: 0 })) };
    let m;
    if ((m = p.match(/^\/api\/live-rooms\/([^/]+)\/profile$/)))
      return { ok: true, profile: { alias: m[1], roomId: m[1], nickname: '房 ' + m[1], avatar: '', exists: true } };
    if (p === '/api/monitor/add'){
      const r = q.get('room') || '';
      if (B.unverifiable.has(r))
        return { __err: 400, body: { ok: false, error: 'live_unverifiable', message: '暂时核实不了这个直播间的状态,请稍后再试' } };
      if (!B.live.has(r) && !B.roster.has(r))
        return { __err: 400, body: { ok: false, error: 'not_live_now',
          message: '这个直播间当前未开播 —— 后台也没有它的开播记录,请在主播开播时再添加' } };
      B.roster.add(r);
      return { ok: true, room: r, resolvedRoomId: r };
    }
    if (p === '/api/monitor/remove'){ B.roster.delete(q.get('room') || ''); return { ok: true }; }
    if (p === '/api/active-room/claim') return { ok: true, room: q.get('roomId') || '' };
    if ((m = p.match(/^\/api\/rooms\/([^/]+)\/(config|history|history\/days|prediction|coverage|summary)$/))){
      const d = gate(m[1]); if (d) return d;
      if (m[2] === 'config') return { ok: true, roomId: m[1], spells: [] };
      if (m[2] === 'history') return { ok: true, roomId: m[1], rounds: [] };
      if (m[2] === 'history/days') return { ok: true, retentionDays: 1, days: [] };
      if (m[2] === 'prediction') return { ok: true, main: [], guard: [], record: [], ens: [], accuracy: null,
        target_round_id: null, serverNowMs: Date.now() };
      return { ok: true, missing: [] };
    }
    if ((m = p.match(/^\/api\/rooms\/([^/]+)$/))){ const d = gate(m[1]); if (d) return d; return { ok: true }; }
    return { ok: true };
  };
  return B;
}

async function openPage(B, { seedRooms = [], seedRoom = '', url = 'http://localhost/' } = {}){
  const dom = new JSDOM(HTML, { url, pretendToBeVisual: true, runScripts: 'dangerously' });
  const w = dom.window;
  const ns = B.login ? '@u7' : '';                    // KEY_NS.v = '@u' + user.id(见 authInit)
  if (seedRooms.length) w.localStorage.setItem('jf2:myRooms' + ns, JSON.stringify(seedRooms));
  if (seedRoom) w.localStorage.setItem('jf2:room' + ns, seedRoom);
  w.fetch = async (input) => {
    const url = typeof input === 'string' ? input : input.url;
    const body = B.route(url);
    if (body && body.__err)
      return { ok: false, status: body.__err, headers: { get: () => null },
        json: async () => body.body, text: async () => JSON.stringify(body.body) };
    return { ok: true, status: 200, headers: { get: () => null },
      json: async () => body, text: async () => JSON.stringify(body) };
  };
  w.EventSource = class { constructor(){ this.readyState = 0; } addEventListener(){} close(){ this.readyState = 2; } };
  w.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
  w.PerformanceObserver = class { observe(){} disconnect(){} };
  w.matchMedia = w.matchMedia || (q => ({ matches: false, media: q, addEventListener(){},
    removeEventListener(){}, addListener(){}, removeListener(){} }));
  w.scrollTo = () => {};
  w.innerWidth = 1680; w.innerHeight = 960;
  Object.defineProperty(w.HTMLElement.prototype, 'offsetParent',
    { get(){ let n = this; while (n){ if (n.hidden) return null; n = n.parentElement; }
             return this.parentElement; }, configurable: true });
  const s = w.document.createElement('script');
  s.textContent = APPJS;
  w.document.body.appendChild(s);
  // toast 捕获:_toastPush 是顶层函数声明 → 全局可覆盖(toast/toastAction 都经它)
  w._toastPush = (o) => { B.toasts.push(String(o && o.msg || '')); };
  await sleep(700);
  const S = w.JiufaDev.S;
  const search = async (q) => {
    const inp = w.document.getElementById('roomSearch');
    inp.value = q;
    inp.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
  };
  const clickCard = (alias) => {
    const el = w.document.querySelector(`.room-item[data-alias="${alias}"]`);
    if (!el) return false;
    el.dispatchEvent(new w.MouseEvent('click', { bubbles: true }));
    return true;
  };
  const myRooms = () => {
    for (let i = 0; i < w.localStorage.length; i++){
      const k = w.localStorage.key(i);
      if (k && k.startsWith('jf2:myRooms')) { try { return JSON.parse(w.localStorage.getItem(k) || '[]'); } catch { return []; } }
    }
    return [];
  };
  const adds = (room) => B.calls.filter(c => c.p === '/api/monitor/add' && (!room || c.q.room === room)).length;
  return { w, S, search, clickCard, myRooms, adds, close: () => w.close() };
}

(async () => {
  console.log(`切换即添加 · 前端行为(真 DOM 执行;页面=${HAS_INDEX ? '交付版 index.html' : '按 cacheDom 生成的骨架'})`);

  // ── ① 登录态:搜索框敲不在名录、但在播的房 ─────────────────────────────────
  {
    const B = makeBackend({ live: ['654321'] });
    const P = await openPage(B);
    A('① 开机落在名录首房 888', P.S.alias === '888', `(alias=${P.S.alias})`);
    await P.search('654321');
    await sleep(1500);
    A('① 敲号后自动调了一次 /api/monitor/add', P.adds('654321') === 1, `(次数=${P.adds('654321')})`);
    A('① 加入后自动打开:S.alias=654321', P.S.alias === '654321', `(alias=${P.S.alias})`);
    A('① 入名录:S.rooms 含 654321', P.S.rooms.some(r => String(r.alias) === '654321'));
    A('① 落盘:localStorage 含 654321', P.myRooms().includes('654321'), `(存储=${JSON.stringify(P.myRooms())})`);
    A('① 有告知 toast(自动加入名录)', B.toasts.some(t => t.includes('自动加入名录')), `(toasts=${JSON.stringify(B.toasts)})`);
    P.close();
  }

  // ── ② 登录态:敲不在名录、且未开播的房 ─────────────────────────────────────
  {
    const B = makeBackend({ live: [] });
    const P = await openPage(B);
    await P.search('777');
    await sleep(1200);
    A('② add 被拒后只提示(未开播原话)', B.toasts.some(t => t.includes('未开播')), `(toasts=${JSON.stringify(B.toasts)})`);
    A('② 不入名录、不落盘', !P.S.rooms.some(r => String(r.alias) === '777') && !P.myRooms().includes('777'));
    A('② 仍停在原房 888', P.S.alias === '888', `(alias=${P.S.alias})`);
    A('② 原房实时已恢复(tick 心跳在跑)', !!P.S.tickId);
    const n0 = P.adds('777');
    await sleep(4500);                                   // 退避首拍 3s+抖动:若误入重试循环这里会再打
    A('② 不进退避重试:4.5s 内 add 只打了一次', n0 === 1 && P.adds('777') === 1, `(次数=${P.adds('777')})`);
    A('② 明细端点没有对 777 反复 403', B.calls.filter(c => /^\/api\/rooms\/777\//.test(c.p)).length <= 2,
      `(777 明细请求=${B.calls.filter(c => /^\/api\/rooms\/777\//.test(c.p)).length})`);
    P.close();
  }

  // ── ③ 登录态:残影卡(localStorage 有,服务端没绑定)→ 点击 → 自动 add → 打开 ──
  {
    const B = makeBackend({ live: ['654321'] });
    const P = await openPage(B, { seedRooms: ['654321'] });
    A('③ 残影卡被并进名录(看起来正常)', P.S.rooms.some(r => String(r.alias) === '654321'));
    A('③ 并卡阶段没有自动 add(每 30s 的路绝不打上游)', P.adds('654321') === 0, `(次数=${P.adds('654321')})`);
    const hit = P.clickCard('654321');
    await sleep(1500);
    A('③ 点卡触发一次 add', hit && P.adds('654321') === 1, `(点到卡=${hit},次数=${P.adds('654321')})`);
    A('③ 打开成功:S.alias=654321', P.S.alias === '654321', `(alias=${P.S.alias})`);
    P.close();
  }
  {
    const B = makeBackend({ live: [] });
    const P = await openPage(B, { seedRooms: ['654321'] });
    const hit = P.clickCard('654321');
    await sleep(1500);
    A('③b 未开播的残影卡:add 打了一次即止', hit && P.adds('654321') === 1, `(次数=${P.adds('654321')})`);
    A('③b 残影卡从名录清退', !P.S.rooms.some(r => String(r.alias) === '654321'));
    A('③b localStorage 一并清退', !P.myRooms().includes('654321'), `(存储=${JSON.stringify(P.myRooms())})`);
    A('③b 清退时通知了后端 remove(幂等)', B.calls.some(c => c.p === '/api/monitor/remove' && c.q.room === '654321'));
    A('③b 仍停在原房 888 且实时恢复', P.S.alias === '888' && !!P.S.tickId, `(alias=${P.S.alias})`);
    P.close();
  }

  // ── ④ 未启用登录:搜索框「看而不加」原样保留 ───────────────────────────────
  {
    const B = makeBackend({ login: false, live: [] });
    const P = await openPage(B);
    await P.search('654321');
    await sleep(1200);
    A('④ 未登录零 add 调用', P.adds() === 0, `(次数=${P.adds()})`);
    A('④ 直接观测:S.alias=654321', P.S.alias === '654321', `(alias=${P.S.alias})`);
    A('④ 房不入名录、不落盘', !P.S.rooms.some(r => String(r.alias) === '654321') && !P.myRooms().includes('654321'));
    P.close();
  }

  // ── ⑤ 登录态:存储恢复(explicit=false)撞 room_not_bound → 绝不自动 add ───────
  {
    const B = makeBackend({ roster: [], live: ['654321'] });
    const P = await openPage(B, { seedRoom: '654321' });
    await sleep(4800);                                   // 覆盖首拍退避(3s+抖动)
    A('⑤ 非显式路径全程零 add(即便该房在播)', P.adds() === 0, `(次数=${P.adds()})`);
    A('⑤ 仍按旧口径提示(不在名录)', B.toasts.some(t => t.includes('不在你的名录中')), `(toasts=${JSON.stringify(B.toasts)})`);
    P.close();
  }

  // ── ⑥ 登录态:问不到(瞬态)→ 只提示;再敲一次 = 新的一次尝试 ─────────────────
  {
    const B = makeBackend({ live: [], unverifiable: ['999'] });
    const P = await openPage(B);
    await P.search('999');
    await sleep(1200);
    A('⑥ 瞬态只提示(上游原话)', B.toasts.some(t => t.includes('暂时核实不了')), `(toasts=${JSON.stringify(B.toasts)})`);
    A('⑥ 不入名录、仍在原房', !P.S.rooms.some(r => String(r.alias) === '999') && P.S.alias === '888');
    await P.search('999');
    await sleep(1200);
    A('⑥ 用户再敲一次 → 第二次 add(不是永久拉黑)', P.adds('999') === 2, `(次数=${P.adds('999')})`);
    P.close();
  }

  // ── ⑦ 登录态:名录满 → 不打上游,直接说满 ───────────────────────────────────
  {
    const roster = Array.from({ length: 50 }, (_, i) => String(1000 + i));
    const B = makeBackend({ roster, live: ['654321'] });
    const P = await openPage(B);
    await P.search('654321');
    await sleep(800);
    A('⑦ 满额零 add 调用', P.adds() === 0, `(次数=${P.adds()})`);
    A('⑦ 提示名录已满', B.toasts.some(t => t.includes('名录已满')), `(toasts=${JSON.stringify(B.toasts)})`);
    P.close();
  }

  // ── ⑧ 登录态:分享链接 ?room= 指向不在名录的房(URL 参数是显式意图,见 dataBoot)──
  {
    const B = makeBackend({ live: ['654321'] });
    const P = await openPage(B, { url: 'http://localhost/?room=654321' });
    await sleep(1200);
    A('⑧a 分享链接:在播 → 自动 add 一次', P.adds('654321') === 1, `(次数=${P.adds('654321')})`);
    A('⑧a 打开成功:S.alias=654321 且入名录', P.S.alias === '654321' && P.S.rooms.some(r => String(r.alias) === '654321'),
      `(alias=${P.S.alias})`);
    P.close();
  }
  {
    const B = makeBackend({ live: [] });
    const P = await openPage(B, { url: 'http://localhost/?room=654321' });
    await sleep(1500);
    A('⑧b 分享链接:未开播 → add 一次即止', P.adds('654321') === 1, `(次数=${P.adds('654321')})`);
    A('⑧b 用原话告知', B.toasts.some(t => t.includes('未开播')), `(toasts=${JSON.stringify(B.toasts)})`);
    A('⑧b 回退到名录首房 888(不钉在打不开的房上)', P.S.alias === '888', `(alias=${P.S.alias})`);
    A('⑧b 不入名录、不落盘', !P.S.rooms.some(r => String(r.alias) === '654321') && !P.myRooms().includes('654321'));
    await sleep(4000);
    A('⑧b 无重试循环', P.adds('654321') === 1 && B.calls.filter(c => /^\/api\/rooms\/654321\//.test(c.p)).length <= 2,
      `(add=${P.adds('654321')},明细=${B.calls.filter(c => /^\/api\/rooms\/654321\//.test(c.p)).length})`);
    P.close();
  }
})().catch(e => { console.error('harness 异常:', e); process.exitCode = 1; });
