"""起真 web(FastAPI)+ 真 PG + 真 Redis,并播种一个策展房与它的直播状态观测,
供 scripts/frontend_rilive_e2e.mjs 用真浏览器跑通「后端下发 live → 前端画三态」全链。

⚠ **本脚本会往 PG 写入 40 条伪造 rounds 与一条 rooms** —— 只用于一次性搭台,
   绝不可对着生产库跑。故设了两道闸:DSN 必须指向 localhost/127.0.0.1,且必须显式
   设 MAXX_E2E_STAGE=1。两道都过不了就直接退出,不做任何写入。

用法:
    MAXX_E2E_STAGE=1 python3 scripts/e2e_stage_livestatus.py            # 播种 + 起 web:5199
    MAXX_E2E_STAGE=1 python3 scripts/e2e_stage_livestatus.py live 0     # 把观测改成未开播
    PROBE_BASE=http://127.0.0.1:5199 PROBE_STAGE=scripts/e2e_stage_livestatus.py \
        node scripts/frontend_rilive_e2e.mjs
不碰上游酷狗:worker 不启动,快照与 rounds 由本脚本直接写入(等价于 worker 抓到过)。
"""

import asyncio
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]      # backend_async/
sys.path.insert(0, str(ROOT))
os.environ.setdefault("STA_PG_DSN", "postgresql://star:star@localhost:5432/spelltamer")
os.environ.setdefault("STA_REDIS_URL", "redis://localhost:6379/0")
os.environ.setdefault("STA_STATIC_DIR", str(ROOT.parent))   # 仓库根:index.html/assets
os.environ.setdefault("STA_LOG_LEVEL", "WARNING")

_dsn = os.environ.get("STA_PG_DSN", "")
if os.environ.get("MAXX_E2E_STAGE") != "1" or not (
        "localhost" in _dsn or "127.0.0.1" in _dsn):
    raise SystemExit("[拒绝执行] 本脚本会往 PG 写伪造数据。"
                     "需 MAXX_E2E_STAGE=1 且 STA_PG_DSN 指向 localhost/127.0.0.1。")

ROOM = "2678075"
ALIAS = "321"
STEP = 50001


async def seed():
    from app.db import DB
    from app.redis_bus import RedisBus, now_ms
    from app.settings import settings
    db = DB(settings.pg_dsn, 1, 4)
    await db.connect()
    await db.migrate()
    async with db.pool.acquire() as con:
        await con.execute(
            "INSERT INTO rooms(room_id, alias, active, pending) VALUES($1,$2,true,false)"
            " ON CONFLICT (room_id) DO UPDATE SET active=true, pending=false, alias=$2",
            ROOM, ALIAS)
        now = int(time.time() * 1000)
        start = now - (now % STEP)
        names = ["鼠妖", "牛魔", "虎精", "兔怪", "龙王", "蛇灵", "马魈", "羊魅", "猴王"]
        for i in range(40):                       # 铺几十局历史,前端序列才有东西画
            rid = start - i * STEP
            n = (i % 9) + 1
            await con.execute(
                "INSERT INTO rounds(room_id, round_id, beast_name, official_id,"
                " custom_id, multiplier, start_ms, draw_ms, source)"
                " VALUES($1,$2,$3,$4,$5,$6,$7,$8,'seed') ON CONFLICT DO NOTHING",
                ROOM, rid, names[n - 1], n, n, 10, rid, rid + 40000)
    bus = RedisBus(settings.redis_url)
    await bus.add_rooms_bulk([(ROOM, ALIAS)])
    now = int(time.time() * 1000)
    start = now - (now % STEP)
    await bus.set_snapshot(ROOM, {"roundStartTimeMs": start, "serverNowMs": now,
                                  "serverOffsetMs": 0, "lastOkAt": now,
                                  "spellTimeMs": start + 35000,
                                  "drawTimeMs": start + 40000,
                                  "endTimeMs": start + 50000, "lastError": ""})
    await bus.livestatus_set_bulk([(ROOM, 1)], ts=now)     # ← 本次验证的主角
    print("seeded room", ROOM, "live=1")
    await db.close()
    await bus.close()


async def set_live(state):
    """把观测改成 1 / 0 / 删除(=未知),供探针逐态验证。"""
    from app.redis_bus import RedisBus
    from app.settings import settings
    bus = RedisBus(settings.redis_url)
    if state is None:
        await bus.livestatus_drop_bulk([ROOM])
    else:
        await bus.livestatus_set_bulk([(ROOM, int(state))], ts=int(time.time() * 1000))
    await bus.close()


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "live":
        v = sys.argv[2]
        asyncio.run(set_live(None if v == "none" else int(v)))
        print("live ->", v)
    else:
        asyncio.run(seed())
        import uvicorn
        uvicorn.run("app.web:app", host="127.0.0.1", port=5199, log_level="warning")
