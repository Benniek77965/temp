#!/usr/bin/env python3
"""
smoke_e2e.py — 端到端冒烟(不依赖真实上游)
================================================================================
在已起好的 Redis + PostgreSQL 上,直接经 ASGI 打 FastAPI(不开真实网络端口),
验证「只读 Web 层 + 名录写入 + 数据契约」端到端可用:

  1) POST /api/monitor/add     → 房间进 Redis 名录 + PG,排即时 MainPage 任务
  2) 直接把若干局与一条预测写进 PG(模拟 worker 抓取/预测的产物)
  3) GET  /api/rooms                    → 名录含该房
  4) GET  /api/rooms/{room}/history     → 序列回合(字段与旧契约一致)
  5) GET  /api/rooms/{room}/prediction  → pending + record + accuracy
  6) GET  /api/rooms/{room}/config      → 九法阵配置(9 条,room_id 已注入)
  7) GET  /api/crawler/status           → 爬虫状态含 latestRoundId
  8) GET  /api/live-rooms               → 直播间卡片(计时来自快照,缺则 DB 兜底)
  9) POST /api/monitor/remove  → 出名录

繁星解析(昵称/头像/归一)可能因无外网而失败,脚本对此**容错**:归一失败按原号,
昵称回退占位,不视为错误。
"""
import asyncio
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

os.environ.setdefault("STA_PG_DSN", "postgresql://star:star@127.0.0.1:5432/spelltamer")
os.environ.setdefault("STA_REDIS_URL", "redis://127.0.0.1:6379/0")
os.environ.setdefault("STA_STATIC_DIR", "")

import httpx  # noqa: E402
from httpx import ASGITransport  # noqa: E402

ROOM = "2678075"


def _new_round(base_start: int, i: int, cid: int):
    """构造一条 rounds 入库参数(与 worker._handle_award 写库口径一致)。"""
    from app.constants import ROUND_STEP, DRAW_OFFSET_MS, build_beast_meta
    _, by_cid = build_beast_meta({})
    m = by_cid[cid]
    start = base_start + i * ROUND_STEP
    draw = start + DRAW_OFFSET_MS
    from app.predictor_bridge import ms_to_local, ms_to_date
    return dict(room_id=ROOM, round_id=start, official_id=m["beast_id"],
                beast_name=m["beast_name"], custom_id=cid, multiplier=m["multiplier"],
                source="history", draw_local=ms_to_local(draw), date_local=ms_to_date(draw))


async def main():
    from app.web import app, ST, lifespan  # noqa
    # 用 lifespan 正确初始化 ST(db/bus/star)
    async with lifespan(app):
        # 沙箱无外网:繁星归一必失败 → 打桩 canon,让主流程按「归一成功」走
        # (真实归一逻辑由 starmeta 单独承担;这里测的是 Web 契约与数据链路)。
        real_canon = ST.star.canon

        async def fake_canon(alias: str):
            return (str(alias), True)

        ST.star.canon = fake_canon
        transport = ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://t") as c:
            checks = []

            def ok(name, cond, extra=""):
                checks.append((name, cond))
                print(f"  [{'✓' if cond else '✗'}] {name}{(' — ' + extra) if extra else ''}")

            # 1) 名录写入。准入限制:只允许添加「后台已存在」的房 —— 预置 ROOM 为
            #    自动发现房(模拟其近期出现在繁星在播列表),add 应通过并**转正**
            #    (移出发现集,前端可见)。
            await ST.bus.add_room(ROOM, ROOM)
            await ST.bus.discovered_seen_bulk([ROOM])
            r = await c.post("/api/monitor/add", params={"room": ROOM})
            j = r.json()
            ok("monitor/add(发现房转正)",
               r.status_code == 200 and j.get("ok") and ROOM in j.get("rooms", [])
               and ROOM not in (await ST.bus.discovered_members()),
               f"resolvedRoomId={j.get('resolvedRoomId')}")

            # 2) 直接写库:12 局历史 + 一条「下一局」预测
            base = (int(time.time() * 1000) // 50001) * 50001 - 12 * 50001
            for i in range(12):
                await ST.db.add_round(**_new_round(base, i, cid=(i % 9) + 1))
            last_start = base + 11 * 50001
            next_rid = last_start + 50001
            await ST.db.save_prediction(ROOM, next_rid, main_ids=[3, 1], guard_ids=[7, 2],
                                        detail={"ens": [3, 1, 7, 2, 5], "models": {}})
            # 补一条已结算记录(供 accuracy/record 展示)
            await ST.db.save_prediction(ROOM, last_start, main_ids=[(11 % 9)], guard_ids=[2, 4],
                                        detail={"ens": []})
            await ST.db.fill_prediction_outcome(ROOM, last_start, actual_cid=(11 % 9) + 1)

            # 3) rooms
            r = await c.get("/api/rooms"); j = r.json()
            ok("rooms 名录含该房", any(x["room_id"] == ROOM for x in j.get("rooms", [])))

            # 4) history
            r = await c.get(f"/api/rooms/{ROOM}/history", params={"limit": 20}); j = r.json()
            rounds = j.get("rounds", [])
            fields_ok = rounds and all(
                k in rounds[0] for k in ("round_id", "beast_name", "spell_key", "spell_name",
                                         "display_number", "multiplier", "start_time_ms",
                                         "spell_time_ms", "draw_time_ms", "end_time_ms",
                                         "source", "captured_at"))
            ok("history 回合数≥12", len(rounds) >= 12, f"count={len(rounds)}")
            ok("history 回合字段契约完整", bool(fields_ok),
               f"sample={rounds[0]['beast_name']}/{rounds[0]['display_number']}" if rounds else "")

            # 5) prediction
            r = await c.get(f"/api/rooms/{ROOM}/prediction"); j = r.json()
            ok("prediction pending", j.get("target_round_id") == str(next_rid)
               and j.get("main") == [3, 1] and j.get("guard") == [7, 2],
               f"target={j.get('target_round_id')} main={j.get('main')} guard={j.get('guard')}")
            ok("prediction ens", j.get("ens") == [3, 1, 7, 2, 5])
            ok("prediction record 非空", len(j.get("record", [])) >= 1)
            ok("prediction accuracy", isinstance(j.get("accuracy"), dict)
               and j["accuracy"].get("n", 0) >= 1, f"acc={j.get('accuracy')}")

            # 6) config
            r = await c.get(f"/api/rooms/{ROOM}/config"); j = r.json()
            spells = j.get("spells", [])
            ok("config 九法阵 9 条", len(spells) == 9)
            ok("config room_id 注入", all(s.get("room_id") == ROOM for s in spells))

            # 7) crawler/status
            r = await c.get("/api/crawler/status"); j = r.json()
            cr = j.get("crawler", {})
            room_row = next((x for x in cr.get("rooms", []) if x["roomId"] == ROOM), None)
            ok("crawler/status 含该房", room_row is not None,
               f"latestRoundId={room_row.get('latestRoundId') if room_row else None}")

            # 8) live-rooms
            r = await c.get("/api/live-rooms"); j = r.json()
            lr = next((x for x in j.get("rooms", []) if x["roomId"] == ROOM), None)
            ok("live-rooms 含该房", lr is not None)
            ok("live-rooms 计时(快照缺→DB兜底currentRoundId)", bool(lr and lr.get("currentRoundId")),
               f"currentRoundId={lr.get('currentRoundId') if lr else None}")

            # 9) remove
            r = await c.post("/api/monitor/remove", params={"room": ROOM}); j = r.json()
            ok("monitor/remove", j.get("ok") and ROOM not in j.get("rooms", []))

            # 10) 准入限制:归一失败(无法核验近期直播)→ **即时拒绝**,不再进挂起
            #     —— 用户路径的挂起流程已被准入限制取代;挂起机制保留给
            #     config 注入 / seed_rooms 运维路径(smoke_worker 覆盖 janitor 收敛)。
            async def failing_canon(alias: str):
                return (str(alias), False)
            ST.star.canon = failing_canon
            PEND = "321"
            r = await c.post("/api/monitor/add", params={"room": PEND}); j = r.json()
            ok("准入:归一失败即时拒绝(400+提示)",
               r.status_code == 400 and j.get("error") == "not_recent_live"
               and "近期直播" in (j.get("message") or ""),
               f"message={j.get('message')}")
            ok("准入:被拒不入名录/不入挂起",
               PEND not in (await ST.bus.active_rooms())
               and PEND not in (await ST.bus.pending_rooms()))
            r = await c.get("/api/live-rooms"); j = r.json()
            card = next((x for x in j.get("rooms", []) if x["roomId"] == PEND), None)
            ok("准入:被拒无占位卡片", card is None)

            # 10b) 准入限制:归一成功但真实号**不在后台**(近期没播过)→ 同样拒绝;
            #      预置真实号为发现房后重试 → 通过并转正(短号→发现房的主路径)。
            REAL2 = "9990321"

            async def remap_canon(alias: str):
                return (REAL2, True) if alias == PEND else (str(alias), True)
            ST.star.canon = remap_canon
            r = await c.post("/api/monitor/add", params={"room": PEND}); j = r.json()
            ok("准入:真实号不在后台亦拒绝", r.status_code == 400
               and j.get("error") == "not_recent_live")

            await ST.bus.add_room(REAL2, REAL2)            # 模拟近期在播被发现
            await ST.bus.discovered_seen_bulk([REAL2])
            r = await c.post("/api/monitor/add", params={"room": PEND}); j = r.json()
            row_real = await ST.db.pool.fetchrow(
                "SELECT active,pending FROM rooms WHERE room_id=$1", REAL2)
            ok("准入:发现房经短号添加 → 转正入册",
               j.get("ok") and j.get("resolvedRoomId") == REAL2
               and REAL2 not in (await ST.bus.discovered_members())
               and bool(row_real and row_real["active"] and not row_real["pending"]),
               f"real行={dict(row_real) if row_real else None}")
            await c.post("/api/monitor/remove", params={"room": PEND})
            ST.star.canon = fake_canon

            # 10c) 3.6.0 按日回看:until 半开区间 + /history/days 日目录 +
            #      冻结窗 immutable 缓存头 + 空旧日绕开首见宽限 + 非法区间 400。
            #      口径要点:日归属以**起局毫秒**为准(与前端 dayNo 一致);特意
            #      构造一条 23:59:40 起局、出怪落次日的跨午夜局,证明它归起局日。
            from datetime import datetime as _dt, timezone as _tz, timedelta as _td
            _BJT = _tz(_td(hours=8))
            _DAY = 86_400_000

            def _bj_mid(ms):                      # 任意时刻所在北京日的 00:00 毫秒
                return ((ms + 28_800_000) // _DAY) * _DAY - 28_800_000

            def _bj_date(ms):
                return _dt.fromtimestamp(ms / 1000, tz=_BJT).strftime("%Y-%m-%d")

            today0 = _bj_mid(int(time.time() * 1000))
            d2 = today0 - 2 * _DAY                            # 「前天」00:00(整窗必已冻结)
            ids_d2 = [d2 + k * 50001 for k in (5, 6, 7)]      # 前天日内 3 局
            cross = d2 - 20_000                               # 大前天 23:59:40 起局 → 出怪落前天
            for rid_ in ids_d2 + [cross]:
                await ST.db.add_round(**_new_round(rid_, 0, cid=int(rid_ // 50001 % 9) + 1))

            r = await c.get(f"/api/rooms/{ROOM}/history",
                            params={"since": d2, "until": d2 + _DAY, "limit": 1800})
            j = r.json()
            got = [int(x["round_id"]) for x in j.get("rounds", [])]
            ok("回看:until 区间恰取当日(起局日口径,跨午夜局不混入)",
               set(got) == set(ids_d2) and cross not in got
               and got == sorted(got, reverse=True) and j.get("until") == str(d2 + _DAY),
               f"got={len(got)}")
            ok("回看:冻结窗带 immutable 缓存头",
               "immutable" in r.headers.get("cache-control", ""),
               r.headers.get("cache-control", "(无)"))

            r = await c.get(f"/api/rooms/{ROOM}/history",
                            params={"since": today0, "until": today0 + _DAY, "limit": 1800})
            ok("回看:含今日的窗不带缓存头", r.status_code == 200
               and "cache-control" not in r.headers)

            r = await c.get(f"/api/rooms/{ROOM}/history",
                            params={"since": d2, "until": d2})
            ok("回看:until<=since → 400 invalid_range",
               r.status_code == 400 and r.json().get("error") == "invalid_range")

            r = await c.get(f"/api/rooms/{ROOM}/history",
                            params={"since": -200, "until": -100, "limit": 3})
            ok("回看:负 until 视同未指定(钳位防呆,无冻结头)",
               r.status_code == 200 and r.json().get("until") == "0"
               and "cache-control" not in r.headers
               and len(r.json().get("rounds", [])) == 3)

            _t0 = time.time()
            r = await c.get(f"/api/rooms/{ROOM}/history",
                            params={"since": d2 - 30 * _DAY, "until": d2 - 29 * _DAY,
                                    "limit": 1800})
            _el = time.time() - _t0
            ok("回看:空旧日毫秒级返回(首见 6s 宽限已绕开)",
               r.status_code == 200 and not r.json().get("rounds") and _el < 2.0,
               f"{_el * 1000:.0f}ms")

            r = await c.get(f"/api/rooms/{ROOM}/history/days")
            j = r.json()
            by_date = {d_["date"]: d_ for d_ in j.get("days", [])}
            dates = [d_["date"] for d_ in j.get("days", [])]
            ok("回看:/history/days 日目录(起局日计数,新→旧)",
               j.get("ok") and dates == sorted(dates, reverse=True)
               and by_date.get(_bj_date(d2), {}).get("n") == 3
               and by_date.get(_bj_date(d2 - _DAY), {}).get("n") == 1
               and "retentionDays" in j,
               f"days={len(dates)} 前天n={by_date.get(_bj_date(d2), {}).get('n')}"
               f" 大前天n={by_date.get(_bj_date(d2 - _DAY), {}).get('n')}")
            ok("回看:日目录 dayStartMs/首末局自洽",
               by_date.get(_bj_date(d2), {}).get("dayStartMs") == d2
               and by_date.get(_bj_date(d2), {}).get("firstMs") == ids_d2[0]
               and by_date.get(_bj_date(d2), {}).get("lastMs") == ids_d2[-1])

            # 11) SSE 契约:roomId 参数 + 自定义事件名 connected(前端实锤契约)。
            #     ASGITransport 不支持流式响应(等 app 结束才返回,SSE 永不结束),
            #     故起真 uvicorn 子进程,经真实 HTTP 读首帧 —— 这也是更彻底的端到端。
            import subprocess
            port = 5199
            # 预置快照(与 worker 写入同构),让 connected 帧携带 timer.canPlay
            _now = int(time.time() * 1000)
            await ST.bus.set_snapshot(ROOM, {
                "roundStartTimeMs": next_rid, "spellTimeMs": next_rid + 35000,
                "drawTimeMs": next_rid + 40000, "endTimeMs": next_rid + 50000,
                "canPlay": "1", "serverNowMs": _now, "serverOffsetMs": 0,
                "lastOkAt": _now, "lastError": "",
            })
            proc = subprocess.Popen(
                [sys.executable, "-m", "uvicorn", "app.web:app",
                 "--host", "127.0.0.1", "--port", str(port), "--log-level", "warning"],
                cwd=str(Path(__file__).resolve().parent.parent),
                env={**os.environ}, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            try:
                base = f"http://127.0.0.1:{port}"
                async with httpx.AsyncClient(timeout=5) as rc:
                    for _ in range(40):                       # 就绪轮询(≤4s)
                        try:
                            if (await rc.get(base + "/api/version")).status_code == 200:
                                break
                        except httpx.HTTPError:
                            pass
                        await asyncio.sleep(0.1)
                    # 房间回名录(第 9 步已 remove);子进程走真实 canon,
                    # 由 1.5s 握手限时兜底 —— 数字原号即正确频道。
                    await ST.bus.add_room(ROOM, ROOM)
                    buf: list = [""]
                    ct_box: dict = {}

                    async def _pump():
                        async with rc.stream("GET", base + "/api/events",
                                             params={"roomId": ROOM}) as resp:
                            ct_box["ct"] = resp.headers.get("content-type", "")
                            async for chunk in resp.aiter_text():
                                buf[0] += chunk

                    pump = asyncio.create_task(_pump())

                    async def _wait(substr: str, seconds: float) -> bool:
                        dl = time.time() + seconds
                        while time.time() < dl:
                            if substr in buf[0]:
                                return True
                            await asyncio.sleep(0.1)
                        return False

                    got_conn = await _wait("event: connected", 8.0)
                    ok("SSE content-type",
                       ct_box.get("ct", "").startswith("text/event-stream"))
                    ok("SSE 首帧 event: connected(真 uvicorn)", got_conn,
                       (buf[0].splitlines() or ["(空)"])[0])
                    ok("SSE connected 携带 timer.canPlay",
                       '"timer"' in buf[0] and '"canPlay"' in buf[0])

                    # 等订阅在服务器侧就位,再 publish(pub/sub 不回放)
                    chan = ST.bus.draw_channel(ROOM)
                    for _ in range(30):
                        pairs = await ST.bus.r.pubsub_numsub(chan)
                        if pairs and int(pairs[0][1]) >= 1:
                            break
                        await asyncio.sleep(0.1)
                    await ST.bus.publish_draw(ROOM, {
                        "type": "room-updated", "roomId": ROOM, "alias": ROOM,
                        "serverNowMs": int(time.time() * 1000),
                        "roundsTouched": True,
                        "round": {"round_id": str(next_rid)},
                        "timer": {"roundStartTimeMs": next_rid, "canPlay": True},
                    })
                    got_upd = await _wait("event: room-updated", 4.0)
                    ok("SSE 转发 room-updated(事件名)", got_upd)
                    ok("SSE 出怪事件带 id 行",
                       f"id: {next_rid}" in buf[0])
                    pump.cancel()
                    with __import__("contextlib").suppress(
                            asyncio.CancelledError, Exception):
                        await pump
            finally:
                proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill()

            passed = sum(1 for _, c2 in checks if c2)
            total = len(checks)
            print(f"\n==== 冒烟结果:{passed}/{total} 通过 ====")
            if passed != total:
                print("失败项:", [n for n, c2 in checks if not c2])
                sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
