/* frontend_replay_jsdom.js — 命中率行文案 · 前端真 DOM 冒烟(4.7.5)
   用法:`npm i jsdom` 后
       node backend_async/scripts/frontend_replay_jsdom.js                  # 验源码
       node backend_async/scripts/frontend_replay_jsdom.js \
            --js dist/assets/app.js --html dist/index.html                  # 验混淆产物

   为什么必须有这一份:补算的前端改动此前只做了**静态源码扫描**
   (断言 `r.s !== 'replay'` 这个字符串在文件里)。那只能证明它写在那儿,
   证明不了它跑起来是对的 —— 与 frontend_jfvip_jsdom.js 头注同一句话:
   「语法检查与纯逻辑自证都测不出运行时错误」。

   ★ 为什么必须走**真实启动链路**而不是直接调 renderPredict():
     build-deploy.mjs 的混淆选项里 `renameGlobals: true`,顶层函数一律改名
     (只有 JiufaShared / JiufaSim / JiufaDev / RoundEngine / RealGameBridge
     等跨文件契约在 reservedNames 白名单里)。按函数名调用的测试在**产物**上
     必然 ReferenceError —— 而产物才是用户真正拿到的东西。
     故本脚本只桩网络,让 boot → dataBoot → loadRoom → predChase →
     refreshPrediction → renderPredict 这条真实链路自己跑完,再读 DOM 文本。
     由此同一份断言对源码与产物皆成立。

   ★ 4.7.5 断言方向已整体反转:回测溯源角标被移除,本脚本从「证明角标在」改为
     **证明角标不在**。刻意保留整套脚手架而不是删掉它 —— 删掉等于此后再没人
     守着这条线,某次合并把 4.6.0 的拼接改回来也不会有人红。反向钉子照样是钉子。

   覆盖:
     · 全实盘   → 文案 `近N局 主中X · 防中Y`(与 4.4.x 逐字节相同)
     · 有回测行 → 文案**与全实盘完全同形**,replay 再大也不改变一个字符
     · 正文/title 双面 → 任何分支下都不出现「补算」「回测」字样
     · title    → 命中率/基线/窗口未满三句照旧(它们不是溯源提示,不得误删)
     · 徽标     → 上一局判定来自补算行时**整枚隐藏**(不冒领战绩;本轮不动这道过滤)
     · 徽标     → 同一局若是实盘判定则照常显示(证明过滤没有误杀)
     · 徽标     → 记录**不带 s 字段**(SSE 推送/旧后端)⇒ 视为实盘照常显示
     · n=0      → 命中率整行空白(场景 B 锚定后的正确空态)
*/
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
const _AJ = process.argv.indexOf('--js');
const _AH = process.argv.indexOf('--html');
const JS_PATH = _AJ > 0 ? path.resolve(process.argv[_AJ + 1]) : ROOT + '/assets/app.js';
const HTML_PATH = _AH > 0 ? path.resolve(process.argv[_AH + 1]) : ROOT + '/index.html';

/* 陈旧产物护栏 —— 与 frontend_jfvip_jsdom.js 同款约定:
   混淆构建静默失败时产物仍是上一次的,套件会照常跑完并给出一个看起来正常的
   数字。**一个测不出真相的验收比不验收更危险。** */
if (_AJ > 0) {
  const tp = fs.statSync(JS_PATH).mtimeMs;
  const ts = fs.statSync(ROOT + '/assets/app.js').mtimeMs;
  if (tp < ts) {
    console.error(`✗ 产物 ${JS_PATH} 比 assets/app.js 旧 —— 构建未成功或未重跑。`);
    process.exit(3);
  }
}
const html = fs.readFileSync(HTML_PATH, 'utf8');
const js = fs.readFileSync(JS_PATH, 'utf8');
const MODE = _AJ > 0 ? '混淆产物' : '仓库源码';

const STEP = 50001;
const R0 = 1800000000000 - (1800000000000 % STEP);   // 最新一局(落在格点上)

let pass = 0, fail = 0;
const ok = (name, cond, got) => {
  if (cond) { pass++; console.log('  [✓] ' + name); }
  else { fail++; console.log('  [✗] ' + name + (got !== undefined ? `  ← 实得:${JSON.stringify(got)}` : '')); }
};
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* 起一个完整环境:只桩网络,让应用自己跑完启动链路。
   pred = /api/rooms/321/prediction 的响应体(本套件的被测输入)。 */
async function run(pred){
  const errs = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => errs.push(String((e && e.message) || e)));
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
                                url: 'http://localhost/', virtualConsole: vc });
  const w = dom.window;
  /* jsdom 未实现的浏览器 API —— 与 frontend_jfvip_jsdom.js:138 同款补齐。
     必须**先于**注入 app.js:该文件顶层就有 matchMedia('(min-width:1024px)')。 */
  w.matchMedia = q => ({ matches: false, media: q, addEventListener(){},
                         removeEventListener(){}, addListener(){}, removeListener(){} });
  w.scrollTo = () => {};
  w.requestIdleCallback = w.requestIdleCallback || (f => setTimeout(f, 0));
  w.EventSource = function(){ this.close = () => {}; this.addEventListener = () => {}; };

  const spells = [];
  for (let n = 1; n <= 9; n++)
    spells.push({ display_number: n, spell_key: '土', spell_name: '御土术',
                  beast_name: '兽' + n, beast_id: n, multiplier: 10,
                  probability: '11.1%', beast_icon: '' });
  const rounds = [];
  for (let i = 0; i < 30; i++){
    const start = R0 - (29 - i) * STEP;
    rounds.push({ round_id: start, display_number: (i % 9) + 1, spell_key: '土',
                  spell_name: '御土术', beast_name: '兽', multiplier: 10,
                  start_time_ms: start, draw_time_ms: start + 40000 });
  }
  rounds[rounds.length - 1].display_number = 5;    // 最新一局开 5(徽标断言用)

  w.fetch = async (input) => {
    const url = typeof input === 'string' ? input : input.url;
    let body = { ok: true };
    if (url.startsWith('/api/auth/session')) body = { ok: true, enabled: false };
    else if (/\/api\/live-rooms\/[^/]+\/profile/.test(url))
      body = { ok: true, profile: { alias: '321', nickname: '房', avatar: '' } };
    else if (url.startsWith('/api/live-rooms'))
      body = { ok: true, rooms: [{ alias: '321', roomId: '321', nickname: '房' }] };
    else if (/\/api\/rooms\/[^/]+\/config/.test(url)) body = { ok: true, spells };
    else if (/\/api\/rooms\/[^/]+\/history\/days/.test(url)) body = { ok: true, days: [] };
    else if (/\/api\/rooms\/[^/]+\/history/.test(url)) body = { ok: true, rounds };
    else if (/\/api\/rooms\/[^/]+\/prediction/.test(url)) body = Object.assign({ ok: true }, pred);
    else if (/\/api\/rooms\/[^/]+\/coverage/.test(url))
      body = { ok: true, complete: true, official_missing: [] };
    return { ok: true, status: 200, headers: { get: () => null },
             json: async () => body };
  };

  const el = w.document.createElement('script');
  el.textContent = js;
  w.document.body.appendChild(el);

  // 等启动链路把推演卡渲染出来(predChase 首拉 firstWait=0,但要过 rAF/微任务)
  for (let i = 0; i < 80; i++){
    await sleep(50);
    const r = w.document.getElementById('predRound');
    if (r && /№/.test(r.textContent || '')) break;
  }
  await sleep(150);
  const st = w.document.getElementById('predStats');
  const v = w.document.getElementById('predVerdict');
  return { stats: st.textContent, title: st.title,
           verdictHidden: v.hidden, verdict: v.textContent,
           round: w.document.getElementById('predRound').textContent, errs };
}

const base = { target_round_id: String(R0 + STEP), main: [1, 2], guard: [3, 4],
               ens: [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.2] };

(async () => {
  console.log(`\n══ 命中率行文案 · 前端真 DOM 冒烟(4.7.5 · ${MODE})══`);
  console.log(`   js=${path.relative(ROOT, JS_PATH)}  html=${path.relative(ROOT, HTML_PATH)}\n`);

  console.log('[① 全实盘 —— 零视觉回归]');
  {
    const r = await run(Object.assign({}, base, { record: [],
      accuracy: { window: 100, n: 100, main: 34, cover: 66, replay: 0 } }));
    ok('启动链路跑通(推演卡已渲染)', /№/.test(r.round), r.round);
    ok('文案与旧版逐字节相同', r.stats === '近100局 主中34 · 防中32', r.stats);
    ok('正文不提补算', r.stats.indexOf('补算') < 0, r.stats);
    ok('title 不提补算', r.title.indexOf('补算') < 0, r.title);
    ok('零未捕获异常', r.errs.length === 0, r.errs);
  }

  console.log('\n[② 大量回测行 —— 文案必须与全实盘同形]');
  {
    // replay=85(占 97 条判定的绝大多数)是 4.6.0 会追加角标的最强触发条件。
    // 4.7.5 起它必须**一个字符都不改变** —— 这是本轮改动的正面证据。
    const r = await run(Object.assign({}, base, { record: [],
      accuracy: { window: 100, n: 97, main: 33, cover: 64, replay: 85 } }));
    ok('正文恒为单一形态(replay 不再分叉)',
       r.stats === '近97局 主中33 · 防中31', r.stats);
    ok('分母是真实判定数 97(不是窗口 100)', /^近97局/.test(r.stats), r.stats);
    ok('正文不出现「补算」', r.stats.indexOf('补算') < 0, r.stats);
    ok('正文不出现「回测」', r.stats.indexOf('回测') < 0, r.stats);
    ok('title 不出现「补算」', r.title.indexOf('补算') < 0, r.title);
    ok('title 不出现「回测」', r.title.indexOf('回测') < 0, r.title);
    ok('title 不分列实盘条数', /实盘\s*\d+\s*条/.test(r.title) === false, r.title);
    // 反向钉子的配套正向钉:title 其余三句是命中率本体,不得被一并误删。
    ok('title 保留命中率本体', /主命中 33\/97=34%/.test(r.title), r.title);
    ok('title 保留盲选基线', /盲选基线 22%\/44%/.test(r.title), r.title);
    ok('title 说明窗口未满', /窗口 100 局/.test(r.title), r.title);
    ok('零未捕获异常', r.errs.length === 0, r.errs);
  }
  {
    // 同一组 n/main/cover,只把 replay 从 0 摆到满 —— 两次渲染必须完全一致。
    // 这是比任何单点断言都强的证据:文案对 replay **无依赖**。
    const a = { window: 100, n: 60, main: 20, cover: 40 };
    const r0 = await run(Object.assign({}, base, { record: [],
      accuracy: Object.assign({}, a, { replay: 0 }) }));
    const r1 = await run(Object.assign({}, base, { record: [],
      accuracy: Object.assign({}, a, { replay: 60 }) }));
    ok('replay 0 → 满:正文逐字节一致', r0.stats === r1.stats, [r0.stats, r1.stats]);
    ok('replay 0 → 满:title 逐字节一致', r0.title === r1.title, [r0.title, r1.title]);
  }

  console.log('\n[③ 徽标 —— 只认实盘判定]');
  {
    const r = await run(Object.assign({}, base, {
      record: [{ id: String(R0), n: 5, v: 'main', s: 'replay' }],
      accuracy: { window: 100, n: 50, main: 20, cover: 35, replay: 50 } }));
    ok('补算判定 ⇒ 徽标整枚隐藏', r.verdictHidden === true, r.verdict);
  }
  {
    const r = await run(Object.assign({}, base, {
      record: [{ id: String(R0), n: 5, v: 'main', s: '' }],
      accuracy: { window: 100, n: 50, main: 20, cover: 35, replay: 49 } }));
    ok('同一局若是实盘判定 ⇒ 徽标照常显示(过滤未误杀)',
       r.verdictHidden === false && /主中/.test(r.verdict), r.verdict);
  }
  {
    // SSE 推送与旧后端的记录**不带 s 字段** —— undefined !== 'replay',必须照常显示
    const r = await run(Object.assign({}, base, {
      record: [{ id: String(R0), n: 5, v: 'guard' }],
      accuracy: { window: 100, n: 50, main: 20, cover: 35, replay: 0 } }));
    ok('无 s 字段(SSE 推送/旧后端)⇒ 视为实盘,照常显示',
       r.verdictHidden === false && /防中/.test(r.verdict), r.verdict);
  }

  console.log('\n[④ 空态 —— 场景 B 锚定后的正确表现]');
  {
    const r = await run(Object.assign({}, base, { record: [],
      accuracy: { window: 100, n: 0, main: 0, cover: 0, replay: 0 } }));
    ok('n=0 ⇒ 命中率整行空白', r.stats === '', r.stats);
    ok('无判定 ⇒ 徽标隐藏', r.verdictHidden === true);
    ok('零未捕获异常', r.errs.length === 0, r.errs);
  }

  console.log('\n──────────────────────────────────────────────────────────');
  console.log(`命中率行文案前端冒烟(${MODE}):${pass} 通过 / ${fail} 失败`);
  if (fail) process.exit(1);
  console.log('✓ 溯源角标已从两处渲染面消失,命中率本体与徽标过滤原样保持');
})();
