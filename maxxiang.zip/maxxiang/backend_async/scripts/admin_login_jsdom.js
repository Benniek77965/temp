/* admin_login_jsdom.js — 管理台登录(1.10.0 / 后端 5.3.0)整机冒烟
   交付版 admin.html + admin.js 在 jsdom 真 DOM 中跑通:
     A. API 前缀从页面地址推出(入口改名前端零改动;源码里不留任何一份路径);
     B. 账号 + 密码:开门先问 GET <API>/login;账号必填时空账号本地拦下(不打后端);
        未设账号的部署隐藏账号框;账号错 / 密码错同一句提示;
     C. 人机验证(Turnstile 桩):渲染参数(sitekey / action=admin / size)、令牌随登录提交、
        **每次失败后 reset 并换新令牌**、脚本加载失败 / 后端 503 时把话说清并指路应急链接、
        连点只发一次请求;
     D. 应急登录链接 <入口>#t=<票据>:票据从地址栏抹掉 → 兑换会话 → 进入;坏票据有提示;
     E. 表单语义(密码管理器能认出「账号 + 密码」)、原生 submit 被拦下。
   用法:node admin_login_jsdom.js [--js 混淆后的 admin.js] [--html 压缩后的 admin.html];依赖 jsdom(NODE_PATH)。
   交付形态验收:先 bash build-frontend.sh,再 --js dist/assets/admin.js --html dist/admin.html 跑一遍。 */
'use strict';
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = path.resolve(__dirname, '..', '..');
const HTML_ARG = process.argv.indexOf('--html');
const html = fs.readFileSync(HTML_ARG > 0 ? process.argv[HTML_ARG + 1] : ROOT + '/admin.html', 'utf8');
const JS_ARG = process.argv.indexOf('--js');
const adminjs = fs.readFileSync(JS_ARG > 0 ? process.argv[JS_ARG + 1] : ROOT + '/assets/admin.js', 'utf8');
let PASS = 0, FAIL = 0;
const A = (n, c) => { console.log(`  [${c ? '✓' : '✗'}] ${n}`); if (c) PASS++; else { FAIL++; process.exitCode = 1; } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const DOMS = [];

/* 开一页。opt.info = GET <API>/login 的应答;opt.login(body, n) = POST 登录的应答;
   opt.scripts = 'ok' | 'fail' | 'none'(外链脚本:加载成功并装上桩 / 加载失败 / 永不应答) */
async function open(url, opt = {}) {
  const vc = new VirtualConsole();
  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true, url, virtualConsole: vc });
  DOMS.push(dom);
  const w = dom.window;
  const P = { w, calls: [], posts: [], errs: [], ts: { renders: [], resets: 0, seq: 0 }, scripts: [] };
  w.addEventListener('error', e => P.errs.push(e.message || String(e.error)));
  w.fetch = async (input, o = {}) => {
    const u = typeof input === 'string' ? input : input.url;
    const m = o.method || 'GET';
    const body = o.body ? JSON.parse(o.body) : null;
    P.calls.push(m + ' ' + u);
    let b = { ok: true };
    if (m === 'GET' && /\/login$/.test(u)) b = opt.info === undefined ? { ok: true, account: true, captcha: null } : opt.info;
    else if (m === 'POST' && /\/login$/.test(u)) { P.posts.push(body); b = opt.login ? opt.login(body, P.posts.length) : { ok: true, token: 'tok', csrf: 'c' }; }
    else if (m === 'POST' && /\/login\/ticket$/.test(u)) { P.posts.push(body); b = opt.ticket ? opt.ticket(body) : { ok: true, token: 'tok', csrf: 'c' }; }
    else if (/\/session$/.test(u)) b = { __status: 401, ok: false, error: 'unauthorized' };
    if (b === null) throw new TypeError('Failed to fetch');
    const status = b.__status || 200;
    return { ok: status < 400, status, headers: { get: () => null }, json: async () => b, text: async () => JSON.stringify(b) };
  };
  w.EventSource = class { constructor() { this.readyState = 0; } addEventListener() {} close() {} };
  w.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };
  w.matchMedia = q => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} });
  w.scrollTo = () => {};
  w.HTMLElement.prototype.scrollIntoView = function () {};
  const ls = {};
  Object.defineProperty(w, 'localStorage', { value: {
    getItem: k => (k in ls ? ls[k] : null), setItem: (k, v) => { ls[k] = String(v); },
    removeItem: k => { delete ls[k]; }, clear: () => { for (const k in ls) delete ls[k]; } }, configurable: true });
  P.ls = ls;
  /* 外链脚本:jsdom 默认不加载外部资源(也不触发 onload/onerror)—— 这里按场景手动应答 */
  const head = w.document.head, rawAppend = head.appendChild.bind(head);
  head.appendChild = el => {
    if (el && el.tagName === 'SCRIPT' && el.src) {
      P.scripts.push(el.src);
      const mode = opt.scripts || 'ok';
      if (mode === 'ok') setTimeout(() => {
        w.turnstile = {
          render(box, o) { P.ts.renders.push({ box, o }); setTimeout(() => o.callback('tok-' + (++P.ts.seq)), opt.tokenDelay || 15); return 'w1'; },
          reset() { P.ts.resets++; const o = P.ts.renders[0].o; setTimeout(() => o.callback('tok-' + (++P.ts.seq)), opt.tokenDelay || 15); },
        };
        el.onload && el.onload();
      }, 10);
      else if (mode === 'fail') setTimeout(() => el.onerror && el.onerror(new w.Event('error')), 10);
      return el;
    }
    return rawAppend(el);
  };
  const sc = w.document.createElement('script');
  sc.textContent = adminjs;
  w.document.body.appendChild(sc);
  await sleep(120);
  P.$ = s => w.document.querySelector(s);
  P.click = el => el.dispatchEvent(new w.Event('click', { bubbles: true }));
  P.key = (el, key) => el.dispatchEvent(new w.KeyboardEvent('keydown', { key, bubbles: true, cancelable: true }));
  P.msg = () => P.$('#loginMsg').textContent;
  P.inShell = () => P.$('#shell').classList.contains('on') && P.$('#login').hidden;
  P.fill = (u, p) => { if (u !== null) P.$('#un').value = u; P.$('#pw').value = p; };
  return P;
}
const CAPCONF = { provider: 'turnstile', appId: 'site-key-xyz', action: 'admin' };

(async () => {
  console.log('管理台登录(账号 + 密码 + 人机验证 + 应急链接)整机冒烟 —— 交付版 admin.html + admin.js @ jsdom\n');

  console.log('A. API 前缀从页面地址推出');
  for (const [url, want] of [['http://localhost/admin-xdd', '/api/admin-xdd'], ['http://localhost/ops_9/', '/api/ops_9'],
                              ['http://localhost/Entry-A#/params', '/api/Entry-A'], ['http://localhost/', '/api/admin'],
                              ['http://localhost/admin.html', '/api/admin']]) {
    const P = await open(url);
    A(`${url.replace('http://localhost', '')} → ${want}`, P.calls.length > 0 && P.calls.every(c => c.split(' ')[1].startsWith(want + '/')));
  }
  A('admin.js 里没有任何一份后台路径(源码态直接可查;混淆产物同样不含明文)', !/\/api\/admin|admin-xdd/.test(adminjs));

  console.log('\nB. 账号 + 密码');
  let P = await open('http://localhost/admin-xdd');
  A('未登录:立即亮登录屏,进门规则只问一次 GET /login(首屏三次亮屏不重复问)', !P.$('#login').hidden && P.calls.includes('GET /api/admin-xdd/session') && P.calls.filter(c => c === 'GET /api/admin-xdd/login').length === 1);
  A('账号框可见且在密码框之前;焦点落在账号框', !P.$('#un').hidden && P.w.document.activeElement === P.$('#un'));
  P.fill('', 'pw'); P.click(P.$('#loginBtn')); await sleep(60);
  A('账号必填:空账号本地拦下,不打后端', /请先输入管理账号/.test(P.msg()) && P.posts.length === 0);
  P.fill('13268237005', ''); P.click(P.$('#loginBtn')); await sleep(60);
  A('空密码本地拦下,不打后端', /请先输入管理密码/.test(P.msg()) && P.posts.length === 0);
  P.fill('  13268237005 ', 'secret'); P.click(P.$('#loginBtn')); await sleep(150);
  A('提交体 = {username(去首尾空白), password};无人机验证时不带令牌', P.posts.length === 1 && P.posts[0].username === '13268237005' && P.posts[0].password === 'secret' && P.posts[0].captchaToken === undefined);
  A('登录成功 → 进入 shell,令牌落本地存储,密码框清空', P.inShell() && P.ls.sta_admin_tok === 'tok' && P.$('#pw').value === '');
  A('零未捕获异常', P.errs.length === 0);

  P = await open('http://localhost/admin-xdd', { login: () => ({ __status: 401, ok: false, error: 'bad_credentials' }) });
  P.fill('13268237005', 'wrong'); P.click(P.$('#loginBtn')); await sleep(150);
  A('账号错 / 密码错同一句:「账号或密码不正确」', P.msg() === '账号或密码不正确' && !P.inShell());
  P.fill('13268237005', 'pw'); P.key(P.$('#un'), 'Enter'); await sleep(120);
  A('账号框回车(已填密码)= 提交', P.posts.length === 2);
  P.$('#pw').value = ''; P.key(P.$('#un'), 'Enter'); await sleep(40);
  A('账号框回车(未填密码)= 跳到密码框', P.w.document.activeElement === P.$('#pw') && P.posts.length === 2);

  P = await open('http://localhost/admin-xdd', { info: { ok: true, account: false, captcha: null } });
  A('未设账号的部署:账号框隐藏,焦点在密码框', P.$('#un').hidden && P.w.document.activeElement === P.$('#pw'));
  P.fill(null, 'pw'); P.click(P.$('#loginBtn')); await sleep(150);
  A('只验密码的旧模式照常登录', P.inShell() && P.posts[0].username === '');

  P = await open('http://localhost/admin-xdd', { info: null });          // 开门那一问网络失败
  P.fill('13268237005', 'pw'); P.click(P.$('#loginBtn')); await sleep(200);
  { const i = P.calls.indexOf('POST /api/admin-xdd/login');
    A('GET /login 失败不拦人:提交前补问一次,照常发出登录', P.posts.length === 1 && i > 0 && P.calls[i - 1] === 'GET /api/admin-xdd/login'); }

  P = await open('http://localhost/admin-xdd', { login: () => ({ __status: 429, ok: false, error: 'rate_limited', retryAfter: 420, hint: '尝试过于频繁,请 7 分钟后再试' }) });
  P.fill('13268237005', 'pw'); P.click(P.$('#loginBtn')); await sleep(150);
  A('429:显示后端给的等待时长', /7 分钟后再试/.test(P.msg()));

  console.log('\nC. 人机验证(每次登录一枚新令牌)');
  let n401 = 0;
  P = await open('http://localhost/admin-xdd', { info: { ok: true, account: true, captcha: CAPCONF },
    login: (b, n) => n < 3 ? (n401++, { __status: n === 1 ? 401 : 400, ok: false, error: n === 1 ? 'bad_credentials' : 'captcha_failed' })
                           : { ok: true, token: 'tok', csrf: 'c' } });
  await sleep(120);
  A('开门即挂件:加载 Turnstile 脚本(render=explicit)一次', P.scripts.length === 1 && /challenges\.cloudflare\.com\/turnstile\/v0\/api\.js\?render=explicit/.test(P.scripts[0]));
  const R = P.ts.renders[0];
  A('渲染进 #capBox,容器可见', P.ts.renders.length === 1 && R.box === P.$('#capBox') && !P.$('#capBox').hidden);
  A('渲染参数:sitekey / action=admin / size 合法', R.o.sitekey === 'site-key-xyz' && R.o.action === 'admin' && ['flexible', 'compact'].includes(R.o.size));
  A('挂了 expired / error 回调', typeof R.o['expired-callback'] === 'function' && typeof R.o['error-callback'] === 'function');
  P.fill('13268237005', 'wrong'); P.click(P.$('#loginBtn')); P.click(P.$('#loginBtn')); P.click(P.$('#loginBtn')); await sleep(200);
  A('连点三下只发一次请求,带令牌 tok-1', P.posts.length === 1 && P.posts[0].captchaToken === 'tok-1');
  A('401 后 reset 挂件(旧令牌已被后端消费)', P.ts.resets === 1 && P.msg() === '账号或密码不正确');
  P.click(P.$('#loginBtn')); await sleep(200);
  A('第二次提交用的是**新**令牌 tok-2', P.posts.length === 2 && P.posts[1].captchaToken === 'tok-2');
  A('人机验证未过(400):提示并再次 reset', P.msg() === '人机验证未通过,请重试' && P.ts.resets === 2);
  P.fill('13268237005', 'right'); P.click(P.$('#loginBtn')); await sleep(200);
  A('第三次:tok-3 + 正确密码 → 进入', P.posts.length === 3 && P.posts[2].captchaToken === 'tok-3' && P.inShell());
  A('全程只渲染一枚挂件、只加载一次脚本', P.ts.renders.length === 1 && P.scripts.length === 1 && P.errs.length === 0);

  P = await open('http://localhost/admin-xdd', { info: { ok: true, account: true, captcha: CAPCONF }, tokenDelay: 400 });
  await sleep(60);
  P.ts.renders[0].o['error-callback']('300030');           // 挑战出错(令牌还没发出来)
  const r0 = P.ts.resets;
  P.fill('13268237005', 'pw'); P.click(P.$('#loginBtn')); await sleep(80);
  A('验证框出错后点登录:先 reset 重新挑战,而不是干等超时', P.ts.resets === r0 + 1 && P.posts.length === 0);
  await sleep(600);
  A('重置后拿到新令牌即自动发出登录', P.posts.length === 1 && P.posts[0].captchaToken === 'tok-1' && P.inShell());

  P = await open('http://localhost/admin-xdd', { info: { ok: true, account: true, captcha: CAPCONF }, tokenDelay: 400 });
  await sleep(60);
  P.fill('13268237005', 'pw'); P.click(P.$('#loginBtn')); await sleep(80);
  A('令牌还没到:显示「安全校验中…」并等待,不抢发', /安全校验中/.test(P.msg()) && P.posts.length === 0 && P.$('#loginBtn').disabled);
  await sleep(600);
  A('令牌一到自动发出登录', P.posts.length === 1 && P.posts[0].captchaToken === 'tok-1' && P.inShell());

  P = await open('http://localhost/admin-xdd', { info: { ok: true, account: true, captcha: CAPCONF }, scripts: 'fail' });
  await sleep(120);
  A('验证脚本加载失败:明说原因并指路应急链接', /人机验证加载失败/.test(P.msg()) && /应急登录链接/.test(P.msg()));
  P.fill('13268237005', 'pw'); P.click(P.$('#loginBtn')); await sleep(150);
  A('加载不出验证框时不发登录请求(后端必拒),按钮恢复可点', P.posts.length === 0 && !P.$('#loginBtn').disabled && /人机验证加载失败/.test(P.msg()));
  A('失败的脚本可重试(再点一次会重新加载)', P.scripts.length === 2);

  P = await open('http://localhost/admin-xdd', { info: { ok: true, account: true, captcha: CAPCONF },
    login: () => ({ __status: 503, ok: false, error: 'captcha_unavailable', hint: 'x' }) });
  await sleep(120);
  P.fill('13268237005', 'pw'); P.click(P.$('#loginBtn')); await sleep(200);
  A('后端 503 captcha_unavailable:不说成「未启用」,指路应急链接', /人机验证服务暂时不可用/.test(P.msg()) && /应急登录链接/.test(P.msg()) && !/未启用/.test(P.msg()));

  P = await open('http://localhost/admin-xdd', { info: { ok: true, account: true, captcha: { provider: '', appId: '', action: 'admin', unavailable: true } } });
  await sleep(80);
  A('always 档但供应商没配好:开门即说明,网页登录不可用', /人机验证尚未配置完整/.test(P.msg()));
  P.fill('13268237005', 'pw'); P.click(P.$('#loginBtn')); await sleep(100);
  A('此时点登录不发请求', P.posts.length === 0);

  console.log('\nD. 应急登录链接 <入口>#t=<票据>');
  const TK = 'eyJzdWIiOiJhZG1pbi10aWNrZXQiLCJleHAiOjE4MDAwMDAwMDAsImp0aSI6IjAwIn0.' + 'ab'.repeat(32);
  P = await open('http://localhost/admin-xdd#t=' + TK);
  await sleep(120);
  A('不先试旧会话,直接兑换票据', P.calls[0] !== 'GET /api/admin-xdd/session' && P.calls.includes('POST /api/admin-xdd/login/ticket') && P.posts[0].ticket === TK);
  A('票据已从地址栏抹掉', P.w.location.hash === '' && !P.w.location.href.includes(TK));
  A('兑换成功 → 进入 shell,落的是正常会话', P.inShell() && P.ls.sta_admin_tok === 'tok');
  P = await open('http://localhost/admin-xdd#t=' + TK, { ticket: () => ({ __status: 401, ok: false, error: 'bad_ticket' }) });
  await sleep(120);
  A('坏 / 用过的票据:留在登录屏并说明', !P.inShell() && /应急登录链接无效、已过期或已被使用/.test(P.msg()) && P.w.location.hash === '');
  P = await open('http://localhost/admin-xdd#/params');
  A('普通的 #/视图 哈希不被当成票据', !P.calls.some(c => /login\/ticket/.test(c)));

  console.log('\nE. 表单语义');
  P = await open('http://localhost/admin-xdd');
  const f = P.$('#loginForm');
  A('账号 / 密码在同一个 <form> 里,autocomplete = username / current-password', !!f && f.contains(P.$('#un')) && f.contains(P.$('#pw')) && P.$('#un').getAttribute('autocomplete') === 'username' && P.$('#pw').getAttribute('autocomplete') === 'current-password');
  A('账号框关掉首字母大写与自动纠错(手机键盘不改写账号)', P.$('#un').getAttribute('autocapitalize') === 'none' && P.$('#un').getAttribute('autocorrect') === 'off');
  const ev = new P.w.Event('submit', { bubbles: true, cancelable: true });
  f.dispatchEvent(ev);
  A('原生 submit 被拦下(不整页跳转)', ev.defaultPrevented === true);
  A('登录按钮 type=button', P.$('#loginBtn').getAttribute('type') === 'button');

  console.log(`\n结果:${PASS} 通过 / ${FAIL} 失败`);
  DOMS.forEach(d => { try { d.window.close(); } catch (_) {} });
  setTimeout(() => process.exit(FAIL ? 1 : 0), 50);
})().catch(e => { console.error('脚本异常:', e); process.exit(2); });
