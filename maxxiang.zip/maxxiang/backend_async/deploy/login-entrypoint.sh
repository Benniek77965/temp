#!/bin/sh
# ==============================================================================
# kugou_login 刷新服务入口:首启补齐卷上的配置/账号库, 然后常驻按周期刷新。
# ==============================================================================
set -e

mkdir -p "$(dirname "$KG_CONFIG")" "$(dirname "$KG_ACCOUNTS")"

# 1) 配置文件:卷上没有则用镜像内烘焙的那份初始化(之后刷新只改 auth.cookie)。
if [ ! -f "$KG_CONFIG" ]; then
  cp /app/jiufa_data/spell_tamer_config.json "$KG_CONFIG"
  echo "[kugou_login] 初始化配置到卷: $KG_CONFIG"
fi

# 2) 账号库:卷上没有则放一份参考模板 + 一个空账号库, 提示用户填写。
if [ ! -f "$KG_ACCOUNTS" ]; then
  cp /app/jiufa_data/kugou_login/accounts.example.json "$(dirname "$KG_ACCOUNTS")/accounts.example.json" 2>/dev/null || true
  echo '{"accounts": []}' > "$KG_ACCOUNTS"
  echo "[kugou_login] 已生成空账号库: $KG_ACCOUNTS"
  echo "[kugou_login] 请参照同目录 accounts.example.json 填入你自己的账号(username/password/mid)后, 本服务会自动开始刷新。"
fi

# 3) 常驻刷新(纯 HTTP)。周期/重试间隔可用 KG_REFRESH_DAYS / KG_RETRY_MINUTES 调。
exec python -m kugou_login.refresher --daemon \
  --accounts "$KG_ACCOUNTS" \
  --config "$KG_CONFIG" \
  --state "$KG_STATE" \
  --refresh-days "${KG_REFRESH_DAYS:-25}" \
  --retry-minutes "${KG_RETRY_MINUTES:-120}" \
  --check-interval-minutes "${KG_CHECK_MINUTES:-1}" \
  "$@"
