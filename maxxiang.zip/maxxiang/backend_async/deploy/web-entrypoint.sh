#!/bin/sh
# web 容器以 root 启动本脚本,唯一目的:把账号库卷目录 /data 归属改回 app。
# ─────────────────────────────────────────────────────────────────────────────
# docker 挂载**命名卷**(acctdata:/data)时,卷根目录默认 root:root 属主;而应用以
# 非 root 的 app 用户运行 → 写 /data/accounts.json 时 PermissionError,被 AccountStore
# ._save 静默吞掉 → 账号看似保存实则没落盘 → `docker compose up -d --build` 重建即空。
# 仅靠 Dockerfile 里 chown 一个**空** /data 目录并不可靠(docker 不一定把空目录属主
# 复制给新卷)。故在容器启动时以 root 强制 chown 卷目录,再用 gosu 降到 app 跑应用
# —— 应用进程仍非 root,但账号库可持久化写入。这是 postgres/redis 官方镜像的同款做法。
set -e
if [ -d /data ]; then
    chown -R app:app /data 2>/dev/null || true
fi
# kgdata 同款兜底(非递归):管理台编辑 accounts.json 需目录可写;
# 若用户仍以 :ro 挂载,chown 失败即静默跳过,页面会如实提示只读。
if [ -d /kgdata ]; then
    chown app:app /kgdata 2>/dev/null || true
fi
exec gosu app "$@"
