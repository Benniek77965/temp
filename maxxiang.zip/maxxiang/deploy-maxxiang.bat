@echo off
rem ============================================================================
rem  deploy-maxxiang.bat - one-click launcher for deploy-maxxiang.ps1 (Windows)
rem  - Double-click friendly: bypasses ExecutionPolicy, keeps window on exit
rem  - Prefers PowerShell 7 (pwsh) when installed, falls back to powershell.exe
rem  - All arguments are passed through, e.g.:
rem      deploy-maxxiang.bat install -Yes -Port 5173
rem      deploy-maxxiang.bat status | logs web -Follow | backup ...
rem  NOTE: for passwords containing cmd metacharacters (& ^ | < >), quote the
rem        whole argument or invoke the .ps1 directly from PowerShell.
rem  - Admin elevation (UAC) is handled by the ps1 itself when needed.
rem ============================================================================
setlocal
cd /d "%~dp0"

set "PSBIN=powershell.exe"
where pwsh >nul 2>nul && set "PSBIN=pwsh"

if not exist "%~dp0deploy-maxxiang.ps1" (
  echo [ERROR] deploy-maxxiang.ps1 not found next to this .bat file.
  pause
  exit /b 2
)

"%PSBIN%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy-maxxiang.ps1" %*
set "RC=%ERRORLEVEL%"

rem Keep window open only for double-click runs (no arguments were given).
if "%~1"=="" (
  echo.
  echo [deploy-maxxiang] finished, exit code %RC%. Press any key to close . . .
  pause >nul
)
exit /b %RC%
