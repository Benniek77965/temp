// WebView2Bridge 的 JS 桥（window.epl）类型声明：在 VS Code 或 TypeScript 项目里有自动补全和类型检查。
// 用法：把本文件放进前端项目（例如 src/types/epl.d.ts），确保 tsconfig.json 的 include 覆盖到它即可。
// 桥对象名可用易语言的 置桥接名称 () 修改；改了名请把下面的 epl 一并改掉。
// 想让自己绑定的函数也有类型，在项目里补充声明，例如：
//   declare global { interface EplBridge { add(a: number, b: number): Promise<number> } }

export {};

declare global {
  interface EplBridge {
    /** 调用易语言用 绑定 () 绑定的函数，与 epl.函数名(...) 相同；函数名不是合法的 JS 标识符时用它。
     *  参数按 JSON 传给易语言；易语言用 回传 () 返回结果，用 回传错误 () 让 Promise 失败 */
    call<T = any>(name: string, ...args: any[]): Promise<T>;
    /** 接收易语言 发送事件 () 推送的事件；事件名为 "*" 时接收全部事件，回调参数是 (事件名, 数据) */
    on(event: "*", handler: (event: string, data: any) => void): EplBridge;
    on(event: string, handler: (data: any) => void): EplBridge;
    /** 取消接收；不给回调时取消该事件名下的全部回调 */
    off(event: string, handler?: (...args: any[]) => void): EplBridge;
    /** 只接收一次；事件名为 "*" 时回调参数是 (事件名, 数据) */
    once(event: "*", handler: (event: string, data: any) => void): EplBridge;
    once(event: string, handler: (data: any) => void): EplBridge;
    /** 给易语言发一条消息，触发易语言的“收到消息”事件 */
    send(value: unknown): void;
    /** 其它名字都当作易语言绑定的函数：const r = await epl.add(1, 2) */
    [name: string]: any;
  }
  /** 只在顶层页面提供（iframe 里没有）；启用 JS 桥后首个页面加载时就已存在 */
  var epl: EplBridge;
  interface WindowEventMap {
    /** 桥对象就绪时在 window 上触发（名称为 桥接名称 + "ready"，默认 eplready） */
    eplready: CustomEvent;
  }
}
