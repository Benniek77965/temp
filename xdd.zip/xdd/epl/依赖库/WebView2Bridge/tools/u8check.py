# -*- coding: utf-8 -*-
# UTF-8 约定检查：类_WebView2、程序集_WebView2 的文本参数、返回值和回调参数一律是 UTF-8。
# 用法：python tools/u8check.py   （在工程根目录运行；发现问题时列出位置并以退出码 1 结束）
#   1. DLL：导出函数的每个 const char* 参数都经 FromCP 系列按代码页转换，返回文本的函数都经 ToCP 系列按代码页输出（易语言载入时把代码页设为 65001）
#   2. 易语言（类_WebView2、程序集_WebView2 与使用它们的示例、测试）：
#      A. 交给 类_WebView2 方法、WV载入DLL 的中文常量先经 WV编码_ANSI到UTF8（或只是转调它的子程序）转换
#      B. 本层自身代码里的中文常量都经过转换
#      C. 本层给出的文本（类方法、WV取载入错误、WV取DLL路径 的返回值）交给信息框、输出调试文本、组件属性等按 ANSI 处理的地方之前先经 WV编码_UTF8到ANSI 转回
#      D. 取运行目录 () 等系统命令和编辑框内容等组件属性给出的 ANSI 文本（以及存着这类文本或中文常量的变量），交给本层之前先转成 UTF-8
#      E. 不用按 GBK 双字节处理的文本命令处理 UTF-8 文本（寻找文本、倒找文本、子文本替换、分割文本、删首尾空、删首空、删尾空、到小写、到大写、到全角、到半角）：
#         它们把 0x80 以上的字节当成双字节字符的首字节、与下一个字节一起跳过，紧跟在汉字后面的字符会被漏掉（实机：内置 寻找文本 在 UTF-8 的“中,a”里找不到逗号，内置 到小写 不转换“中A”里的 A）。
#         本层自身代码里一律不用；使用本层的代码里，本层给出的文本、刚转成 UTF-8 的文本、存着这类文本的变量、回调子程序收到的文本参数都不交给它们
#         （改用 WV寻找文本 等按字节处理的子程序）。行尾注释写 u8check:允许 的地方是故意的（例如测试里记录内置命令的表现），不检查
#      README 里的易语言示例（读者会照抄）按同样的规则 A～E 检查：每个易语言代码块当作一个使用本层的源文件，示例里的“浏览器”是 类_WebView2 的对象
import glob, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
problems = []

# ---------------------------------------------------------------- 1. DLL 导出层
src = open(os.path.join(ROOT, 'src', 'wv_api.cpp'), encoding='utf-8').read()
exports = text_out = 0
# 入参按约定是系统 ANSI 文本、不按代码页转换的导出函数（源码里的文字常量，见 wv2bridge.h）
ANSI_IN = {'WV_TextFromAnsi'}
for part in re.split(r'\n(?=WV_EXPORT\()', src):
    m = re.match(r'WV_EXPORT\(([^)]*)\)\s+(\w+)\(([^)]*)\)', part)
    if not m: continue
    exports += 1
    ret, name, params = m.groups()
    body = part[m.end():]
    body = body[:body.find('\n}')]  # 到函数体结束（本工程的函数在第 0 列以 } 结束），后面的静态辅助函数不算
    for p in params.split(','):
        if 'const char*' in p:
            arg = p.strip().split()[-1].lstrip('*')
            if name not in ANSI_IN and not re.search(r'FromCP\w*\(\s*' + re.escape(arg) + r'\b', body):
                problems.append('DLL %s：文本参数 %s 没有按代码页转换' % (name, arg))
    if 'char*' in ret:
        text_out += 1
        # 只看函数体最外层（缩进两格）的 return；更深的缩进属于 lambda 等内部代码
        for r in re.findall(r'(?m)^  (?! )[^\n]*?\breturn ([^;]+);', body.split('\nWV_EXPORT(')[0]):
            r = r.strip()
            inner = r[4:-1].strip() if r.startswith('Ret(') and r.endswith(')') else r
            if 'ToCP' in inner or inner in ('std::string()', 'nullptr') or inner.startswith('WithView<std::string>') or r.startswith('Ret(WithView<std::string>') or re.fullmatch(r'\w+', inner): continue
            problems.append('DLL %s：返回值 %s 没有按代码页输出' % (name, r[:60]))

# ---------------------------------------------------------------- 2. 易语言代码
# 独立工程里模块在 epl\<模块>\；工程嵌在应用里时（如 应用\epl\依赖库\WebView2Bridge）在 应用\epl\模块\精易模块*\。一个文件都没找到时明确失败（原来报“易语言文件 0 个；问题 0 处”并以 0 退出，等于没查却算通过）
E = glob.glob(os.path.join(ROOT, 'epl', '*', '代码', '**', '*.e.txt'), recursive=True) or glob.glob(os.path.join(glob.escape(os.path.normpath(os.path.join(ROOT, '..', '..', '模块'))), '精易模块*', '代码', '**', '*.e.txt'), recursive=True)
if not E:
    print('找不到易语言模块源码（epl/*/代码 或 ../../模块/精易模块*/代码），无法检查')
    sys.exit(1)
TO_U8, TO_ANSI = {'WV编码_ANSI到UTF8', 'WV文本'}, {'WV编码_UTF8到ANSI'}
# 按 ANSI 处理文本的命令（接收方）与给出 ANSI 文本的命令、组件属性（来源）
SINKS = {'信息框', '输出调试文本', '调试输出', 'SetWindowTextA', '运行', '写到文件', '加入文本', '置文本', '标题', '内容'}
ANSI_FUNCS = {'取运行目录', '取当前目录', '取特定目录', '取临时文件名', '取命令行', '读环境变量', '取执行文件名', '取文本注册项', '读配置项', '取系统目录'}
ANSI_PROPS = ('内容', '标题', '文本')
# 程序集_WebView2 里收发 UTF-8 文本的公开子程序：参数按类方法检查，返回值按类方法检查
U8_PARAM_FUNCS = {'WV载入DLL', 'WV寻找文本', 'WV子文本替换', 'WV分割文本', 'WV删首尾空', 'WV到小写', 'WV到大写'}
U8_RET_FUNCS = {'WV取载入错误', 'WV取DLL路径', 'WV子文本替换', 'WV删首尾空', 'WV到小写', 'WV到大写'}
# 按 GBK 双字节匹配的文本命令（规则 E）
DBCS_CMDS = {'寻找文本', '倒找文本', '子文本替换', '分割文本', '删首尾空', '删首空', '删尾空', '到小写', '到大写', '到全角', '到半角'}
texts = {f: open(f, encoding='utf-8-sig', newline='').read().split('\r\n') for f in E}
for f, t in texts.items():  # 只是转调转换函数的子程序也算转换函数
    cur = None
    for l in t:
        m = re.match(r'\.子程序 ([^,\s]+)\s*(?:,|$)', l)
        if m: cur = m.group(1).strip(); continue
        if cur and re.match(r'\s*返回 \(WV编码_ANSI到UTF8 \(', l): TO_U8.add(cur)
        if cur and re.match(r'\s*返回 \(WV编码_UTF8到ANSI \(', l): TO_ANSI.add(cur)

def code_of(line):  # 去掉行尾注释（' 不在文本常量里时开始注释）
    out, q = [], False
    for ch in line:
        if ch == '“': q = True
        elif ch == '”': q = False
        elif ch == "'" and not q: break
        out.append(ch)
    return ''.join(out)

def calls_at(c, pos):  # pos 处外层依次是哪些调用（由外到内）
    st, q = [], False
    for i in range(pos):
        ch = c[i]
        if ch == '“': q = True
        elif ch == '”': q = False
        elif not q and ch == '(':
            j = i - 1
            while j >= 0 and c[j] == ' ': j -= 1
            k = j
            while k >= 0 and (c[k].isalnum() or c[k] in '_.' or (ord(c[k]) > 127 and c[k] not in '（）“”，')): k -= 1
            st.append(c[k + 1:j + 1])
        elif not q and ch == ')' and st: st.pop()
    return st

def in_string(c, pos):
    return c[:pos].count('“') > c[:pos].count('”')

DECL = re.compile(r'\.(?:局部变量|程序集变量|全局变量|参数) ([^,]+), 类_WebView2')
# README 里的易语言示例（读者会照抄）按同样的规则检查：每个易语言代码块当作一个使用本层的源文件，示例里的“浏览器”是 类_WebView2 的对象；
# js 代码块只取注释里写的易语言调用（如 // 接收 浏览器.发送事件 (...)）。目录清单等不是代码的块不检查
_readme = open(os.path.join(ROOT, 'README.md'), encoding='utf-8-sig').read().replace('\r\n', '\n')
for _bm in re.finditer(r'```([a-zA-Z]*)\n(.*?)```', _readme, re.S):
    _lang, _body = _bm.group(1), _bm.group(2)
    if _lang == 'js':
        _lines = [l.split('//', 1)[1].strip() if '//' in l and '浏览器.' in l.split('//', 1)[1] else '' for l in _body.split('\n')]  # 每行对应一项，行号不变
    elif _lang == '' and ('浏览器.' in _body or re.search(r'^\.(?:子程序|程序集变量) ', _body, re.M)):
        _lines = _body.split('\n')
    else:
        continue
    if any(_lines):
        _start = _readme.count('\n', 0, _bm.start()) + 2  # 代码块第一行在 README 里的行号
        texts[os.path.join(ROOT, 'README.md 第%d行起的示例' % _start)] = _lines + ['.程序集变量 浏览器, 类_WebView2, , , ']  # 声明放在最后：报告里的行号就是示例里的第几行
DECL = re.compile(r'\.(?:局部变量|程序集变量|全局变量|参数) ([^,]+), 类_WebView2')
for f, t in sorted(texts.items()):
    base = os.path.basename(f)
    inst = {DECL.match(l).group(1).strip() for l in t if DECL.match(l)}
    own = base in ('类_WebView2.class.e.txt', '程序集_WebView2.static.e.txt')
    uses = own or inst or any(re.search(r'\b(WV载入DLL|WV取载入错误|WV取DLL路径) \(', l) for l in t)
    if not uses: continue
    if own: inst.add('类_WebView2')
    def is_u8_target(x):  # 接收 UTF-8 文本的调用：类方法与 WV载入DLL
        return ('.' in x and x.split('.')[0] in inst) or x in U8_PARAM_FUNCS
    def is_u8_source(x):  # 给出 UTF-8 文本的调用
        return ('.' in x and x.split('.')[0] in inst) or x in U8_RET_FUNCS
    # 规则 E 的数据来源：回调子程序（地址交给本层的方法，如 绑定 (“名”, &子程序)）收到的文本参数，以及当前存着 UTF-8 文本的变量。
    # 按行顺序跟踪：赋值为本层给出的文本或刚转成 UTF-8 的文本时记为 UTF-8，赋值为转回 ANSI 的文本或其它内容时取消
    cb_subs = set(m.group(1) for l in t for m in re.finditer(r'&([^\s(),“”]+)', code_of(l)) if re.search(r'\b(?:' + '|'.join(re.escape(x) for x in inst) + r')\.', code_of(l)))
    cur_sub, cur_u8, cur_ansi = None, set(), set()
    # 只是转调本层方法、原样返回其结果的子程序（如测试里 执行JS 的简写）也给出 UTF-8 文本
    u8_wrappers, sub = set(), None
    for l in t:
        m = re.match(r'\.子程序 ([^,\s]+)\s*(?:,|$)', l)
        if m: sub = m.group(1).strip(); continue
        m = re.match(r'\s*返回 \(([^\s(),“”]+) \(', code_of(l))
        if sub and m and '.' in m.group(1) and m.group(1).split('.')[0] in inst: u8_wrappers.add(sub)
    is_u8_source_base = is_u8_source
    def is_u8_source(x, _b=is_u8_source_base):
        return _b(x) or x in u8_wrappers
    # 程序集变量：任何子程序里把 UTF-8 文本（本层给出的、刚转成 UTF-8 的、回调收到的文本参数）赋给它，就按 UTF-8 文本对待（不分先后）
    glob_vars = {m.group(1).strip() for l in t for m in [re.match(r'\.程序集变量 ([^,]+), 文本型', l)] if m}
    glob_u8, sub, params = set(), None, set()
    for l in t:
        m = re.match(r'\.子程序 ([^,\s]+)\s*(?:,|$)', l)
        if m: sub, params = m.group(1).strip(), set(); continue
        m = re.match(r'\.参数 ([^,]+), 文本型', l)
        if m and sub in cb_subs and not own: params.add(m.group(1).strip()); continue
        a = re.match(r'\s*赋值 \(([^,()]+), (.*)\)\s*$', code_of(l))
        if not a or a.group(1).strip() not in glob_vars: continue
        rhs = a.group(2)
        first = re.match(r'\s*([^\s(),“”]+) \(', rhs)
        if first and first.group(1) in TO_ANSI: continue
        calls = [x.group(1) for x in re.finditer(r'([^\s(),“”]+) \(', rhs) if not in_string(rhs, x.start())]
        if any(is_u8_source(x) or x in TO_U8 for x in calls) or rhs.strip() in params or rhs.strip() in glob_u8:
            glob_u8.add(a.group(1).strip())
    for n, l in enumerate(t, 1):
        m = re.match(r'\.子程序 ([^,\s]+)\s*(?:,|$)', l)
        if m: cur_sub, cur_u8, cur_ansi = m.group(1).strip(), set(), set()
        m = re.match(r'\.参数 ([^,]+), 文本型', l)
        if m and cur_sub in cb_subs and not own: cur_u8.add(m.group(1).strip())
        if l.startswith('.') and not re.match(r'\.(如果|如果真|判断|计次循环首|变量循环首|判断循环首|循环判断首)\b', l): continue
        c = code_of(l)
        n_before = len(problems)  # 行尾注释写 u8check:允许 的行，下面各条规则查出的问题都不算（变量的状态照常更新）
        # A/B：中文常量
        for m in re.finditer(r'“([^”]*)”', c):
            if all(ord(ch) < 128 for ch in m.group(1)): continue
            st = calls_at(c, m.start())
            meth = [k for k, x in enumerate(st) if is_u8_target(x)]
            conv = [k for k, x in enumerate(st) if x in TO_U8]
            sink = [k for k, x in enumerate(st) if x.split('.')[-1] in SINKS]
            if own and not conv and not sink:
                problems.append('B %s:%d 本层代码里的中文常量没有转成 UTF-8：%s' % (base, n, c.strip()[:100]))
            elif meth and not own and not [k for k in conv + sink if k > max(meth)]:
                problems.append('A %s:%d 交给本层的中文常量没有先转成 UTF-8：%s' % (base, n, c.strip()[:100]))
        # D：系统命令或组件属性给出的 ANSI 文本直接交给本层
        srcs = [(m.start(), m.group(1)) for m in re.finditer(r'(?<![^\s(,])([^\s(),“”.]+) \(', c) if m.group(1) in ANSI_FUNCS and not in_string(c, m.start())]
        first_arg_of_assign = re.match(r'\s*赋值 \(([^,]+),', c)
        for m in re.finditer(r'([^\s(),“”]+)\.(内容|标题|文本)\b(?!\s*\()', c):
            if in_string(c, m.start()) or m.group(1) in inst: continue
            if first_arg_of_assign and first_arg_of_assign.start(1) <= m.start() < first_arg_of_assign.end(1): continue
            srcs.append((m.start(), m.group(0)))
        for pos, name in srcs:
            st = calls_at(c, pos)
            meth = [k for k, x in enumerate(st) if is_u8_target(x)]
            conv = [k for k, x in enumerate(st) if x in TO_U8]
            if meth and not [k for k in conv if k > max(meth)]:
                problems.append('D %s:%d %s 给出的是 ANSI 文本，交给本层前没有转成 UTF-8：%s' % (base, n, name, c.strip()[:100]))
            elif own and not meth and not conv and not [x for x in st if x.split('.')[-1] in SINKS]:
                problems.append('D %s:%d 本层代码直接使用了 ANSI 文本 %s：%s' % (base, n, name, c.strip()[:100]))
        # C：本层给出的 UTF-8 文本交给按 ANSI 处理的命令或界面属性
        for m in re.finditer(r'([^\s(),“”]+) \(', c):
            if in_string(c, m.start()) or not is_u8_source(m.group(1)): continue
            st = calls_at(c, m.start())
            sink = [k for k, x in enumerate(st) if x.split('.')[-1] in SINKS]
            back = [k for k, x in enumerate(st) if x in TO_ANSI]
            if sink and not [k for k in back if k > max(sink)]:
                problems.append('C %s:%d 本层给出的 UTF-8 文本直接交给了按 ANSI 处理的命令：%s' % (base, n, c.strip()[:100]))
            a = re.match(r'\s*赋值 \(([^,]+\.(?:内容|标题|文本)), ', c)
            if a and m.start() > a.end(1) and not [x for x in st if x in TO_ANSI]:
                problems.append('C %s:%d 本层给出的 UTF-8 文本直接赋给了界面属性 %s：%s' % (base, n, a.group(1), c.strip()[:100]))

        # E：按 GBK 双字节匹配的文本命令处理 UTF-8 文本
        for m in re.finditer(r'([^\s(),“”]+) \(', c):
            if in_string(c, m.start()) or 'u8check:允许' in l: continue
            name = m.group(1)
            if own and name in DBCS_CMDS:
                problems.append('E %s:%d 本层代码用了按 GBK 双字节匹配的 %s（UTF-8 文本请按字节处理）：%s' % (base, n, name, c.strip()[:100]))
                continue
            if own or not (is_u8_source(name) or name in TO_U8): continue
            st = calls_at(c, m.start())
            dbcs = [k for k, x in enumerate(st) if x in DBCS_CMDS]
            back = [k for k, x in enumerate(st) if x in TO_ANSI]
            if dbcs and not [k for k in back if k > max(dbcs)]:
                problems.append('E %s:%d UTF-8 文本交给了按 GBK 双字节匹配的 %s（改用 WV寻找文本 等）：%s' % (base, n, st[max(dbcs)], c.strip()[:100]))
        # E：存着 UTF-8 文本的变量、回调收到的文本参数交给按 GBK 双字节处理的命令（第一个参数，即被处理的文本）
        if not own and 'u8check:允许' not in l:
            for m in re.finditer(r'([^\s(),“”]+) \(', c):
                if in_string(c, m.start()) or m.group(1) not in DBCS_CMDS: continue
                arg = re.match(r'\s*([^\s(),“”]+)\s*[,)]', c[m.end():])
                if arg and (arg.group(1) in cur_u8 or arg.group(1) in glob_u8):
                    problems.append('E %s:%d 变量 %s 存的是 UTF-8 文本，交给了按 GBK 双字节处理的 %s（改用 WV寻找文本 等）：%s' % (base, n, arg.group(1), m.group(1), c.strip()[:100]))
        # C：存着 UTF-8 文本的变量直接交给按 ANSI 处理的命令（作为整个参数）或赋给界面属性
        if not own and 'u8check:允许' not in l:
            u8now = cur_u8 | glob_u8
            for m in re.finditer(r'([^\s(),“”]+) \(', c):
                if in_string(c, m.start()) or m.group(1).split('.')[-1] not in SINKS: continue
                depth, q, k, args, cur = 1, False, m.end(), [], ''
                while k < len(c) and depth:
                    ch = c[k]
                    if ch == '“': q = True
                    elif ch == '”': q = False
                    if not q and ch == '(': depth += 1
                    elif not q and ch == ')':
                        depth -= 1
                        if not depth: break
                    if not q and ch == ',' and depth == 1: args.append(cur); cur = ''
                    else: cur += ch
                    k += 1
                args.append(cur)
                for x in args:
                    if x.strip() in u8now:
                        problems.append('C %s:%d 变量 %s 存的是 UTF-8 文本，直接交给了按 ANSI 处理的 %s：%s' % (base, n, x.strip(), m.group(1), c.strip()[:100]))
            pa = re.match(r'\s*赋值 \(([^,]+\.(?:内容|标题|文本)), (.*)\)\s*$', c)
            if pa and pa.group(2).strip() in u8now:
                problems.append('C %s:%d 变量 %s 存的是 UTF-8 文本，直接赋给了界面属性 %s：%s' % (base, n, pa.group(2).strip(), pa.group(1), c.strip()[:100]))
        # D：存着 ANSI 文本的变量（系统命令、组件属性、中文常量、转回 ANSI 的文本）作为整个参数交给本层
        if not own and 'u8check:允许' not in l and cur_ansi:
            for m in re.finditer(r'([^\s(),“”]+) \(', c):
                if in_string(c, m.start()) or not is_u8_target(m.group(1)): continue
                depth, q, k, args, cur = 1, False, m.end(), [], ''
                while k < len(c) and depth:
                    ch = c[k]
                    if ch == '“': q = True
                    elif ch == '”': q = False
                    if not q and ch == '(': depth += 1
                    elif not q and ch == ')':
                        depth -= 1
                        if not depth: break
                    if not q and ch == ',' and depth == 1: args.append(cur); cur = ''
                    else: cur += ch
                    k += 1
                args.append(cur)
                for x in args:
                    if x.strip() in cur_ansi:
                        problems.append('D %s:%d 变量 %s 存的是 ANSI 文本，交给本层前没有转成 UTF-8：%s' % (base, n, x.strip(), c.strip()[:100]))
        if 'u8check:允许' in l: del problems[n_before:]
        a = re.match(r'\s*赋值 \(([^,()]+), (.*)\)\s*$', c)
        if a:  # 这一行检查完之后再更新变量的状态（右边用到的是赋值之前的内容）
            var, rhs = a.group(1).strip(), a.group(2)
            first = re.match(r'\s*([^\s(),“”]+) \(', rhs)
            calls = [x.group(1) for x in re.finditer(r'([^\s(),“”]+) \(', rhs) if not in_string(rhs, x.start())]
            uses_u8 = any(is_u8_source(x) or x in TO_U8 for x in calls) or any(re.search(r'(?<![^\s(,])' + re.escape(v) + r'(?![^\s),\[])', rhs) for v in cur_u8)
            if uses_u8 and not (first and first.group(1) in TO_ANSI): cur_u8.add(var)
            else: cur_u8.discard(var)
            # ANSI：右边整体是系统命令、转回 ANSI 的结果、组件属性，或含中文的文本常量（不经转换）
            rs = rhs.strip()
            outer = first.group(1) if first else None
            if outer in TO_ANSI or (not uses_u8 and (outer in ANSI_FUNCS or re.fullmatch(r'[^\s(),“”]+\.(?:内容|标题|文本)', rs) or
                                                     (re.fullmatch(r'“[^”]*”', rs) and any(ord(ch) > 127 for ch in rs[1:-1])))):
                cur_ansi.add(var)
            else:
                cur_ansi.discard(var)

problems = list(dict.fromkeys(problems))  # 同一行里同一个问题只报一次
for p in problems: print(p)
print('DLL 导出 %d 个（返回文本的 %d 个），易语言文件 %d 个；问题 %d 处' % (exports, text_out, len(E), len(problems)))
sys.exit(1 if problems else 0)
