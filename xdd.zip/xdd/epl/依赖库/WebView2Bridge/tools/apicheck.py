# -*- coding: utf-8 -*-
# 一致性检查（在工程根目录运行 python tools/apicheck.py；有问题时列出并以退出码 1 结束）：
#   a. src/wv2bridge.h 的 WV 常量与易语言 常量.e.txt 同名同值
#   b. 头文件里的导出函数原型与 src/wv2bridge.def 一致；易语言里每处 DLL 调用的函数存在、参数个数与原型一致，返回文本的函数经 WV内部_文本 取回、返回整数的不经过
#      （包括先把 WV内部_取址 的结果存进变量、再用变量调用的写法）
#   c. demo/演示页.html 与易语言资源里内置的演示页（GBK）内容相同
#   d. 版本信息资源的版本号与头文件一致
#   e. 类里调用本对象的方法都写成“类名.方法 ()”（易语言文本格式的写法；不带前缀会被当成全局子程序）
#   f. 调用本工程定义的子程序、DLL 命令与类方法时参数个数合法，经对象变量调用的方法确实存在
#   g. 每个子程序里的流程控制块成对闭合
#   h. 没有返回值类型的子程序里不能“返回 (值)”；f 项同时检查没有返回值的子程序、方法与 DLL 命令没有被放进表达式里
#   i. 交给 事件_xxx ()、绑定 ()、执行JS_异步 () 的回调子程序，参数个数与类型同方法说明里的“子程序 (名 类型, …)”一致，并且没有“参考”参数
#      （事件回调的参数都是只读的，回填结果用 回调_置取消 () 等）；故意写错参数表的测试子程序（说明里写明“参数表比”）不算。README 里的示例一并检查
#   j. 事件常量（WVE_ 开头，WVE_MAX 与 WVE_FLAG_NO_OUT 除外）在 常量.e.txt 里的说明与头文件注释相同（逗号写成全角）：原来两份一一对应，
#      改头文件里事件参数的说明（如新窗口处理方式的初值）时容易漏改易语言常量表
import re, glob, os, sys
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+os.sep
# 易语言模块源码：独立工程里在 epl\<模块>\；工程嵌在应用里时（如 应用\epl\依赖库\WebView2Bridge）在 应用\epl\模块\精易模块*\。都找不到时明确失败，不能当成通过
_mods=glob.glob(glob.escape(R+'epl'+os.sep)+'*'+os.sep) or glob.glob(glob.escape(os.path.normpath(os.path.join(R,'..','..','模块'))+os.sep)+'精易模块*'+os.sep)
if not _mods:
    print('找不到易语言模块源码（epl\\*\\ 或 ..\\..\\模块\\精易模块*\\），无法检查'); sys.exit(1)
E=_mods[0]
H=open(R+'src/wv2bridge.h',encoding='utf-8').read()
# a. 常量：头文件与易语言常量表
hc={m.group(1):int(m.group(2),0) for m in re.finditer(r'#define (WV[A-Z]*_[A-Z0-9_]+)\s+(-?(?:0x[0-9A-Fa-f]+|\d+))\b',H)}
C=open(E+'常量.e.txt',encoding='utf-8-sig').read()
ec={}
for m in re.finditer(r'\.常量 (WV[A-Z]*_[A-Z0-9_]+), "(-?\d+)"',C): ec[m.group(1)]=int(m.group(2))
diff=[(k,hc[k],ec[k]) for k in hc if k in ec and hc[k]!=ec[k]]
problems=[]
if diff: problems.append('常量值不同')
print('a. 常量 header',len(hc),'epl(WV*)',len(ec),'值不同',diff,'| 头文件有而易语言没有',sorted(k for k in hc if k not in ec and not k.startswith(('WV_BRIDGE','WV_API','WV_CALL'))))
print('   易语言有而头文件没有', sorted(k for k in ec if k not in hc))
# b. DLL 调用参数个数、返回类型、名称
proto={}
for m in re.finditer(r'WV_API\s+(.+?)\s+WV_CALL\s+(WV_\w+)\(([^)]*)\)\s*;',H):
    ps=m.group(3).strip(); n=0 if ps in ('','void') else len(ps.split(','))
    proto[m.group(2)]=(m.group(1).strip(),n)
deff=set(re.findall(r'\b(WV_\w+)',open(R+'src/wv2bridge.def').read().split('EXPORTS',1)[1]))
print('b. 头文件原型',len(proto),'| def',len(deff),'| 原型不在def',sorted(set(proto)-deff),'| def不在原型',sorted(deff-set(proto)))
bad=[]; calls=0; viaVar=0
def check_call(f,i,l,m,n,name):
    if name not in proto: bad.append((os.path.basename(f),i,name,'不存在')); return
    ret,pn=proto[name]
    if pn!=n: bad.append((os.path.basename(f),i,name,'参数个数 %d≠%d'%(n,pn)))
    wrapped=l[:m.start()].rstrip().endswith('WV内部_文本 (')
    if ('char*' in ret)!=wrapped and name not in ('WV_CaptureToMemory',): bad.append((os.path.basename(f),i,name,'返回 %s 但%s经 WV内部_文本'%(ret,'' if wrapped else '没有')))
for f in glob.glob(glob.escape(E)+'代码/**/*.e.txt',recursive=True):
    addr={}  # 同一子程序里先取地址存进变量、再用变量调用的写法：变量 → 函数名
    for i,l in enumerate(open(f,encoding='utf-8-sig').read().split('\n'),1):
        if l.startswith('.子程序 '): addr={}
        for m in re.finditer(r'赋值 \(([^,()“”]+), WV内部_取址 \(“(WV_\w+)”\)\)',l): addr[m.group(1).strip()]=m.group(2)
        for m in re.finditer(r'WV内部_调用(\d) \(WV内部_取址 \(“(WV_\w+)”\)',l):
            calls+=1; check_call(f,i,l,m,int(m.group(1)),m.group(2))
        for m in re.finditer(r'WV内部_调用(\d) \(([^,()“”]+)[,)]',l):
            v=m.group(2).strip()
            if v in addr: calls+=1; viaVar+=1; check_call(f,i,l,m,int(m.group(1)),addr[v])
        for m in re.finditer(r'“(WV_\w+)”',l):
            if m.group(1) not in deff: bad.append((os.path.basename(f),i,m.group(1),'不是导出函数'))
print('   易语言 DLL 调用',calls,'处（其中先取地址存进变量再调用的',viaVar,'处），问题',bad[:12])
if bad: problems.append('DLL 调用')
if set(proto)!=deff: problems.append('导出表')
# d. 版本信息资源（src/wv2bridge.rc）的版本号与头文件的 WV_BRIDGE_VERSION 一致（原来各写一份，容易漏改）
vh=int(re.search(r'#define WV_BRIDGE_VERSION (\d+)',H).group(1)); want='%d,%d,%d,0'%(vh//10000,vh//100%100,vh%100)
rc=open(R+'src/wv2bridge.rc',encoding='ascii').read()
got=re.findall(r'(?:FILE|PRODUCT)VERSION (\d+,\d+,\d+,\d+)',rc)+[x.replace('.',',') for x in re.findall(r'"(?:File|Product)Version", "([\d.]+)"',rc)]
print('d. 版本信息资源',got,'应为',want)
if len(got)!=4 or any(g!=want for g in got): problems.append('版本信息资源与头文件版本号不同')
# d2. 易语言模块载入 DLL 时要求的最低版本与头文件的版本号相同：模块用到的接口与行为随 DLL 一起改，旧版 DLL 不报错、结果却不对
mt=open(E+'代码/WebView2/程序集_WebView2.static.e.txt',encoding='utf-8-sig').read()
mv=re.findall(r'\.如果真 \(小于 \(局_版本, (\d+)\)\)',mt) if '赋值 (局_版本, WV内部_调用0 (GetProcAddress (局_句柄, “WV_GetVersion”)))' in mt else []
print('d2. 模块要求的最低 DLL 版本',mv,'应为',vh)
if mv!=[str(vh)]: problems.append('模块要求的最低 DLL 版本与头文件版本号不同')
# c. 演示页两份是否一致
d=open(R+'demo/演示页.html','rb').read().decode('utf-8').replace('\r\n','\n')
rb=open(E+'资源/WebView2演示页.txt','rb').read()
enc='utf-8-sig' if rb.startswith(b'\xef\xbb\xbf') else 'gbk'
r=rb.decode(enc).replace('\r\n','\n')
print('c. 演示页 demo vs 资源(%s): 相同=%s 长度 %d/%d'%(enc,d.strip()==r.strip(),len(d),len(r)))
if d.strip()!=r.strip(): problems.append('演示页两份不同')
if d.strip()!=r.strip():
    import difflib
    for x in list(difflib.unified_diff(d.split('\n'),r.split('\n'),lineterm='',n=0))[:12]: print('   ',x[:160])
# e. 类里调用本对象的方法要写成“类名.方法 ()”：易语言的文本格式就是这样表示调用本对象的方法；不带前缀的名字会被当成全局子程序，
#    找不到就无法转换或编译（同名的全局子程序、DLL 命令不算，那是在调用它们）
glob_subs=set()
for f in glob.glob(glob.escape(E)+'代码/**/*.static.e.txt',recursive=True):
    glob_subs.update(re.findall(r'(?m)^\.子程序 ([^,\r\n]+),', open(f,encoding='utf-8-sig').read()))
glob_subs.update(re.findall(r'(?m)^\.DLL命令 ([^,\r\n]+),', open(E+'DLL.e.txt',encoding='utf-8-sig').read()))
cls_bad=[]; cls_n=0
for f in glob.glob(glob.escape(E)+'代码/**/*.class.e.txt',recursive=True):
    lines=open(f,encoding='utf-8-sig').read().splitlines()
    own=[m for m in re.findall(r'(?m)^\.子程序 ([^,\r\n]+),', '\n'.join(lines)) if m not in glob_subs and not m.startswith('_')]
    if not own: continue
    cls_n+=1
    pat=re.compile(r'(?<![\w.\u4e00-\u9fff])('+'|'.join(map(re.escape,sorted(own,key=len,reverse=True)))+r') \(')
    for i,l in enumerate(lines,1):
        t=l.strip()
        if t.startswith(("'",'.子程序','.参数','.局部变量','.程序集','.版本','.支持库')): continue
        t=re.sub(r'“[^”]*”','“”',t).split("  '")[0]   # 不看文本常量与行尾注释
        for mm in pat.finditer(t): cls_bad.append('%s:%d %s'%(os.path.basename(f),i,mm.group(1)))
print('e. 类文件',cls_n,'个，不带“类名.”前缀调用本对象方法的',len(cls_bad),'处',cls_bad[:8])
if cls_bad: problems.append('类方法调用缺少类名前缀')
# f. 调用本工程定义的子程序、DLL 命令与类方法时，参数个数合法（不多于参数表，必填的都给了）；经对象变量调用的方法确实存在
# g. 每个子程序里的流程控制块（如果、如果真、判断、各种循环）成对闭合
#    这两项只认本工程里定义的名字（核心库命令不查），是为了在没有易语言编译器的环境里尽早发现改动中的低级错误
def _params(lines,i):
    ps=[]
    for l in lines[i+1:]:
        t=l.strip()
        if not t.startswith('.参数 '): break
        fs=[x.strip() for x in t[4:].split(',')]
        ps.append('可空' in (fs[2] if len(fs)>2 else ''))
    return ps
def _args(s,start):
    d=0; out=[]; cur=''; i=start
    while i<len(s):
        c=s[i]
        if c=='“':
            j=s.find('”',i); j=len(s)-1 if j<0 else j; cur+=s[i:j+1]; i=j+1; continue
        if c=='{': d+=1
        elif c=='}': d-=1
        elif c=='(':
            d+=1
            if d==1: i+=1; continue
        elif c==')':
            d-=1
            if d==0: out.append(cur.strip()); return out
        elif c==',' and d==1: out.append(cur.strip()); cur=''; i+=1; continue
        cur+=c; i+=1
    return None
eplfiles=sorted(glob.glob(glob.escape(E)+'代码/**/*.e.txt',recursive=True))
subs={}; methods={}; dllp={}; void=set()  # void：没有返回值类型的（类名或空, 名字）
for f in eplfiles:
    L=open(f,encoding='utf-8-sig').read().splitlines(); cn=os.path.basename(f).split('.')[0]
    for i,l in enumerate(L):
        m=re.match(r'\.子程序 ([^,]+),',l)
        if m:
            (methods.setdefault(cn,{}) if f.endswith('.class.e.txt') else subs)[m.group(1)]=_params(L,i)
            if not (l.split(',')[1].strip() if l.count(',')>=1 else ''): void.add((cn if f.endswith('.class.e.txt') else '', m.group(1)))
DL=open(E+'DLL.e.txt',encoding='utf-8-sig').read().splitlines()
for i,l in enumerate(DL):
    m=re.match(r'\.DLL命令 ([^,]+),',l)
    if m:
        dllp[m.group(1)]=_params(DL,i)
        if not l.split(',')[1].strip(): void.add(('', m.group(1)))
PAIRS={'.如果真':'.如果真结束','.如果':'.如果结束','.判断开始':'.判断结束','.计次循环首':'.计次循环尾','.判断循环首':'.判断循环尾','.循环判断首':'.循环判断尾','.变量循环首':'.变量循环尾'}
ENDS={v:k for k,v in PAIRS.items()}
arity_bad=[]; block_bad=[]; ncalls=0
for f in eplfiles:
    L=open(f,encoding='utf-8-sig').read().splitlines(); cn=os.path.basename(f).split('.')[0]; bn=os.path.basename(f)
    filet={m.group(1):m.group(2).strip() for m in (re.match(r'\.程序集变量 ([^,]+), (类_[^,]+),',l) for l in L) if m}  # 程序集变量的类型
    stack=[]; sub=''; objt=dict(filet)
    for n,l in enumerate(L,1):
        t=l.strip()
        if t.startswith('.子程序 '):
            if stack: block_bad.append('%s:%d %s 未闭合 %s'%(bn,n,sub,stack))
            stack=[]; sub=t.split(',')[0][5:]; objt=dict(filet); continue  # 局部变量与参数的类型只在本子程序里有效
        mv=re.match(r'\.(?:局部变量|参数) ([^,]+), (类_[^,]+),',t)
        if mv: objt[mv.group(1)]=mv.group(2).strip()
        kw=t.split(' ')[0]
        if kw in PAIRS: stack.append(kw)
        elif kw in ENDS:
            if not stack or stack[-1]!=ENDS[kw]: block_bad.append('%s:%d %s 不配对'%(bn,n,kw))
            else: stack.pop()
        if t.startswith(("'",'.子程序','.参数','.局部变量','.程序集','.版本','.支持库','.常量','.DLL命令','.数据类型','.成员','.全局变量')): continue  # 流程控制行（如果真 (…) 等）里的调用也要查
        code=re.sub(r'“[^”]*”','“”',t).split("  '")[0]
        for m in re.finditer(r'(?<![\w\u4e00-\u9fff#&])((?:[\w\u4e00-\u9fff]+\.)?)([\w\u4e00-\u9fff]+) \(',code):
            obj,name=m.group(1)[:-1],m.group(2); cls=''
            if obj:
                cls=cn if obj==cn else objt.get(obj)
                if not cls or cls not in methods: continue
                if name not in methods[cls]: arity_bad.append('%s:%d %s 没有方法 %s'%(bn,n,cls,name)); continue
                ps=methods[cls][name]
            elif name in dllp: ps=dllp[name]
            elif name in subs: ps=subs[name]
            else: continue
            a=_args(code,m.end()-1)
            if a is None: continue
            ncalls+=1
            owner=(cls if obj else '')
            if (owner,name) in void and (m.start()>0 or code.startswith('.')): arity_bad.append('%s:%d %s 没有返回值，不能放在表达式里'%(bn,n,name))
            if a==['']: a=[]
            if len(a)>len(ps): arity_bad.append('%s:%d %s 参数过多 %d>%d'%(bn,n,name,len(a),len(ps)))
            elif any(not opt and (k>=len(a) or a[k]=='') for k,opt in enumerate(ps)): arity_bad.append('%s:%d %s 缺少必填参数'%(bn,n,name))
    if stack: block_bad.append('%s 末尾未闭合 %s'%(bn,stack))
print('f. 本工程定义的子程序、DLL 命令与类方法的调用',ncalls,'处，参数个数或方法名有误的',len(arity_bad),'处',arity_bad[:8])
print('g. 易语言文件',len(eplfiles),'个，流程控制块不成对的',len(block_bad),'处',block_bad[:8])
if arity_bad: problems.append('易语言调用参数个数')
if block_bad: problems.append('易语言流程控制块')
# h. 没有返回值类型的子程序里不能“返回 (值)”；有返回值类型的子程序被当作语句调用不算问题（易语言允许忽略返回值）
ret_bad=[]
for f in eplfiles:
    rt=None; bn=os.path.basename(f)
    for n,l in enumerate(open(f,encoding='utf-8-sig').read().splitlines(),1):
        t=l.strip()
        if t.startswith('.子程序 '):
            fs=[x.strip() for x in t[5:].split(',')]; rt=fs[1] if len(fs)>1 else ''; continue
        if rt=='' and re.match(r'返回 \((?!\))',re.sub(r'“[^”]*”','“”',t)): ret_bad.append('%s:%d'%(bn,n))
print('h. 没有返回值类型却返回了值的',len(ret_bad),'处',ret_bad[:8])
if ret_bad: problems.append('子程序返回值')
# i. 回调子程序的参数表：易语言端没法在这里运行，写错的参数表（个数、类型，或照旧写“参考”参数）只能静态查出来
clsf=E+'代码/WebView2/类_WebView2.class.e.txt'
sig={}
for l in open(clsf,encoding='utf-8-sig').read().splitlines():
    m=re.match(r'\.子程序 (事件_\w+|绑定|执行JS_异步), ',l)
    if not m: continue
    s=re.search(r'子程序 \(([^)]*)\)',l)
    if s: sig[m.group(1)]=[x.strip().split()[-1] for x in s.group(1).split(',') if x.strip()]
def subs_of(text):
    d={}; cur=None
    for l in text.splitlines():
        if l.startswith('.子程序 '):
            fs=l[5:].split(','); cur=fs[0].strip(); d[cur]={'desc':','.join(fs[3:]) if len(fs)>3 else '','ps':[]}; continue
        if cur and l.startswith('.参数 '):
            fs=[x.strip() for x in l[4:].split(',')]; d[cur]['ps'].append((fs[1] if len(fs)>1 else '', fs[2] if len(fs)>2 else ''))
        elif cur and l.strip() and not l.startswith('.局部变量'): cur=None
    return d
srcs=[(f,open(f,encoding='utf-8-sig').read()) for f in eplfiles]+[(R+'README.md',open(R+'README.md',encoding='utf-8-sig').read())]
allsubs={}
for f,t in srcs:
    for k,v in subs_of(t).items(): allsubs.setdefault(k,v)
cb_bad=[]; cb_n=0
for f,t in srcs:
    local=subs_of(t)
    regs=[(m.group(1),m.group(2)) for m in re.finditer(r'\.(事件_\w+) \(&([^),\s]+)\)',t)]
    regs+=[('绑定',m.group(1)) for m in re.finditer(r'\.绑定 \([^&()\n]*&([^),\s]+)\)',t)]
    regs+=[('执行JS_异步',m.group(1)) for m in re.finditer(r'\.执行JS_异步 \([^&\n]*?&([^),\s]+)',t)]
    for meth,name in regs:
        if meth not in sig: cb_bad.append((os.path.basename(f),meth,name,'方法说明里没有回调格式')); continue
        sd=local.get(name) or allsubs.get(name)
        if not sd: cb_bad.append((os.path.basename(f),meth,name,'找不到子程序')); continue
        if '参数表比' in sd['desc']: continue
        cb_n+=1
        types=[p[0] for p in sd['ps']]
        if types!=sig[meth]: cb_bad.append((os.path.basename(f),meth,name,'参数应为 %s，实为 %s'%('、'.join(sig[meth]),'、'.join(types) or '无')))
        if any('参考' in p[1] for p in sd['ps']): cb_bad.append((os.path.basename(f),meth,name,'有“参考”参数'))
print('i. 回调格式',len(sig),'种，检查回调子程序',cb_n,'个，参数表不符的',len(cb_bad),'处',cb_bad[:8])
if cb_bad or len(sig)<29: problems.append('回调子程序参数表')
# j. 事件常量的说明：头文件注释（逗号换成全角）与易语言常量表相同
hdoc={m.group(1):re.sub(r'\s+',' ',m.group(2).strip()).replace(',','，') for m in re.finditer(r'#define\s+(WVE_[A-Z0-9_]+)\s+\S+[ \t]*/\*(.*?)\*/',H,re.S)}
edoc={m.group(1):re.sub(r'\s+',' ',m.group(2).strip()) for m in re.finditer(r'^\.常量 (WVE_[A-Z0-9_]+), "[^"]*", [^,]*, (.*)$',C,re.M)}
ev_bad=sorted(k for k in hdoc if k in edoc and k not in ('WVE_MAX','WVE_FLAG_NO_OUT') and hdoc[k]!=edoc[k])
if ev_bad: problems.append('事件常量说明与头文件不同')
print('j. 事件常量说明',len([k for k in hdoc if k in edoc]),'个，与头文件不同的',ev_bad)
print('问题', len(problems), problems)
sys.exit(1 if problems else 0)
