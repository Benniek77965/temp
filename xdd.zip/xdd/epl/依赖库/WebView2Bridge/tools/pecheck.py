# -*- coding: utf-8 -*-
# 产物检查（Linux 上的一键验证用）：与 build.bat 调用的 tools\wv2build.ps1 -Action CheckPE 规则相同——必须是 32 位 DLL，
# （导出表除了缺少的，还检查有没有多出来的导出；DLL 标志位也检查）
# 导出表与 src\wv2bridge.def 一致，导入表里没有 Windows 8 以上才有的系统函数，也不依赖 UCRT 或 WebView2Loader.dll。
# Win7 规则（$badDll、$badSym 两个正则）直接从 wv2build.ps1 里读取，两边只维护一份。
# 用法：python3 tools/pecheck.py <dll> [<def 文件>]      全部通过时退出码为 0
import os, re, struct, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
dll = sys.argv[1]
deffile = sys.argv[2] if len(sys.argv) > 2 else os.path.join(ROOT, 'src', 'wv2bridge.def')
ps1 = open(os.path.join(ROOT, 'tools', 'wv2build.ps1'), encoding='utf-8-sig').read()
bad_dll = re.compile(re.search(r"\$badDll = '([^']*)'", ps1).group(1), re.I)  # PowerShell 的 -match 不分大小写
bad_sym = re.compile(re.search(r"\$badSym = '([^']*)'", ps1).group(1), re.I)
b = open(dll, 'rb').read()
passed = failed = 0

def check(ok, name, detail=''):
    global passed, failed
    if ok:
        passed += 1
        print('PASS ' + name)
    else:
        failed += 1
        print('FAIL ' + name + ('  [' + detail + ']' if detail else ''))

e = struct.unpack_from('<I', b, 0x3C)[0]
if b[e:e + 4] != b'PE\0\0':
    check(False, '有效的 PE 文件')
    print('RESULT pass=%d fail=%d' % (passed, failed))
    sys.exit(1)
machine, nsec = struct.unpack_from('<HH', b, e + 4)
opt_size = struct.unpack_from('<H', b, e + 20)[0]
opt = e + 24
magic = struct.unpack_from('<H', b, opt)[0]
characteristics = struct.unpack_from('<H', b, e + 22)[0]
check(machine == 0x14C and magic == 0x10B and characteristics & 0x2000, '32 位（x86）DLL', 'machine=%#x magic=%#x' % (machine, magic))
subsys = '%d.%d' % struct.unpack_from('<HH', b, opt + 48)
secs = []
for i in range(nsec):
    o = opt + opt_size + 40 * i
    vsize, va, rsize, rptr = struct.unpack_from('<IIII', b, o + 8)
    secs.append((va, max(vsize, rsize), rptr))

def off(rva):
    for va, size, rptr in secs:
        if va <= rva < va + size:
            return rva - va + rptr
    raise ValueError('RVA %#x 不在任何节里（文件可能已损坏）' % rva)

def cstr(p):
    return b[p:b.index(b'\0', p)].decode('ascii')

dd = opt + 96
exports = []
exp_rva = struct.unpack_from('<I', b, dd)[0]
if exp_rva:
    x = off(exp_rva)
    n, names = struct.unpack_from('<I', b, x + 24)[0], off(struct.unpack_from('<I', b, x + 32)[0])
    exports = [cstr(off(struct.unpack_from('<I', b, names + 4 * i)[0])) for i in range(n)]
want = []
in_exp = False
for line in open(deffile, encoding='utf-8-sig').read().splitlines():
    t = re.sub(r';.*$', '', line).strip()
    if t == 'EXPORTS':
        in_exp = True
        continue
    if in_exp and t:
        want.append(t.split()[0])
missing, extra = sorted(set(want) - set(exports)), sorted(set(exports) - set(want))
check(not missing and not extra, '导出表与 %s 一致（%d 个）' % (os.path.basename(deffile), len(want)), '缺少 %s 多出 %s' % (missing, extra))
dlls, viol, count = [], [], 0
imp_rva = struct.unpack_from('<I', b, dd + 8)[0]
d = off(imp_rva) if imp_rva else None  # 没有导入表时跳过（与 wv2build.ps1 的 if ($impRva) 一致）
while d is not None:
    oft, _, _, name_rva, ft = struct.unpack_from('<IIIII', b, d)
    if name_rva == 0:
        break
    name = cstr(off(name_rva))
    dlls.append(name)
    if bad_dll.search(name):
        viol.append('DLL ' + name)
    t = off(oft or ft)
    while True:
        v = struct.unpack_from('<I', b, t)[0]
        if v == 0:
            break
        if not v & 0x80000000:
            count += 1
            sym = cstr(off(v) + 2)
            if bad_sym.search(sym):
                viol.append(name + '!' + sym)
        t += 4
    d += 20
check(not viol, 'Win7 兼容：没有 Win8 以上才有的系统函数，也不依赖 UCRT 或 WebView2Loader.dll', '、'.join(viol))
print('INFO 子系统版本 %s，导出 %d 个，导入 %d 个函数；依赖 %s' % (subsys, len(exports), count, '、'.join(dlls)))
print('RESULT pass=%d fail=%d' % (passed, failed))
sys.exit(1 if failed else 0)
