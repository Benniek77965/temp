﻿# wv2build.ps1：build.bat 的辅助脚本（兼容 Windows PowerShell 2.0 到 5.1 以及 PowerShell 7）
#   -Action PathCheck -Path <路径>                         路径只含可见 ASCII 字符返回 0，否则返回 1
#   -Action Download -Url <地址> -Out <文件> -Sha256 <值> [-Mirrors "<镜像前缀 ...>"] [-Proxy <代理>]
#   -Action CheckPE -File <dll> [-Def <def文件>]           检查 32 位格式、导出表与 Win7 兼容的导入表
param(
  [string]$Action = '',
  [string]$Url = '',
  [string]$Out = '',
  [string]$Sha256 = '',
  [string]$Mirrors = '',
  [string]$Proxy = '',
  [string]$File = '',
  [string]$Def = '',
  [string]$Path = ''
)
$ErrorActionPreference = 'Stop'

function Get-Sha256Hex([string]$p) {
  $sha = [System.Security.Cryptography.SHA256]::Create()
  $fs = [System.IO.File]::OpenRead($p)
  try { $h = $sha.ComputeHash($fs) } finally { $fs.Close() }
  return ([System.BitConverter]::ToString($h) -replace '-', '').ToLowerInvariant()
}

function Invoke-Download([string]$u, [string]$o) {
  if (Test-Path -LiteralPath $o) { Remove-Item -LiteralPath $o -Force }
  $curl = $null
  if ($env:SystemRoot) { $curl = Join-Path $env:SystemRoot 'System32\curl.exe' }
  if ($curl -and (Test-Path -LiteralPath $curl)) {
    $ca = @('-L', '--fail', '--retry', '2', '--connect-timeout', '20', '-o', $o)
    if ($Proxy) { $ca += @('-x', $Proxy) }
    $ca += $u
    & $curl @ca
    if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $o)) { return $true }
    Write-Host '    curl 下载失败，改用 .NET 下载' -ForegroundColor Yellow
  }
  try {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor 3072 } catch { }
    $wc = New-Object System.Net.WebClient
    if ($Proxy) { $wc.Proxy = New-Object System.Net.WebProxy($Proxy, $true) }
    $wc.Headers.Add('User-Agent', 'WebView2Bridge-build')
    $wc.DownloadFile($u, $o)
    return (Test-Path -LiteralPath $o)
  } catch {
    Write-Host ('    下载失败：' + $_.Exception.Message) -ForegroundColor Yellow
    return $false
  }
}

if ($Action -eq 'PathCheck') {
  if ($Path -match '[^\x21-\x7E]') { exit 1 } else { exit 0 }
}

if ($Action -eq 'Download') {
  $want = $Sha256.ToLowerInvariant()
  if ((Test-Path -LiteralPath $Out) -and ((Get-Sha256Hex $Out) -eq $want)) { Write-Host '    已存在且校验通过，跳过下载' -ForegroundColor Green; exit 0 }
  $dir = Split-Path -Parent $Out
  if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
  $list = @($Url)
  foreach ($m in ($Mirrors -split '\s+')) { if ($m) { $list += ($m + $Url) } }
  foreach ($u in $list) {
    Write-Host ('    尝试：' + $u)
    if (Invoke-Download $u $Out) {
      $h = Get-Sha256Hex $Out
      if ($h -eq $want) { Write-Host '    SHA256 校验通过' -ForegroundColor Green; exit 0 }
      Write-Host ('    SHA256 不匹配（' + $h + '），已丢弃') -ForegroundColor Yellow
      Remove-Item -LiteralPath $Out -Force
    }
  }
  exit 1
}

if ($Action -eq 'CheckPE') {
  $b = [System.IO.File]::ReadAllBytes($File)
  $e = [BitConverter]::ToInt32($b, 0x3C)
  if ([BitConverter]::ToUInt32($b, $e) -ne 0x4550) { Write-Host '    不是有效的 PE 文件' -ForegroundColor Red; exit 1 }
  $machine = [BitConverter]::ToUInt16($b, $e + 4)
  $nsec = [BitConverter]::ToUInt16($b, $e + 6)
  $optSize = [BitConverter]::ToUInt16($b, $e + 20)
  $opt = $e + 24
  $ok = $true
  if ($machine -ne 0x14c -or [BitConverter]::ToUInt16($b, $opt) -ne 0x10b) { Write-Host '    不是 32 位（x86）DLL' -ForegroundColor Red; exit 1 }
  $subsys = '' + [BitConverter]::ToUInt16($b, $opt + 48) + '.' + [BitConverter]::ToUInt16($b, $opt + 50)
  $script:secs = @()
  for ($i = 0; $i -lt $nsec; $i++) {
    $o = $opt + $optSize + 40 * $i
    $script:secs += ,@([BitConverter]::ToUInt32($b, $o + 12), [BitConverter]::ToUInt32($b, $o + 8), [BitConverter]::ToUInt32($b, $o + 20), [BitConverter]::ToUInt32($b, $o + 16))
  }
  function Off([uint32]$rva) {
    foreach ($s in $script:secs) { $sz = [Math]::Max([uint32]$s[1], [uint32]$s[3]); if ($rva -ge $s[0] -and $rva -lt ($s[0] + $sz)) { return [int]($rva - $s[0] + $s[2]) } }
    return -1
  }
  function CStr([int]$p) { $q = $p; while ($b[$q] -ne 0) { $q++ }; return [System.Text.Encoding]::ASCII.GetString($b, $p, $q - $p) }
  $dd = $opt + 96
  $exports = @()
  $expRva = [BitConverter]::ToUInt32($b, $dd)
  if ($expRva) {
    $x = Off $expRva
    $n = [BitConverter]::ToUInt32($b, $x + 24); $names = Off ([BitConverter]::ToUInt32($b, $x + 32))
    for ($i = 0; $i -lt $n; $i++) { $exports += CStr (Off ([BitConverter]::ToUInt32($b, $names + 4 * $i))) }
  }
  $badDll = '^(api-ms-win-|ext-ms-|ucrtbase\.dll|vcruntime[0-9]*\.dll|msvcp[0-9]+\.dll|d3d12\.dll|d3d12core\.dll|dcomp\.dll|synchronization\.dll|windows\.|combase\.dll|shcore\.dll|webview2loader\.dll)'
  $badSym = '^(WaitOnAddress|WakeByAddressSingle|WakeByAddressAll|GetSystemTimePreciseAsFileTime|PrefetchVirtualMemory|GetOverlappedResultEx|CreateFile2|CopyFile2|GetCurrentThreadStackLimits|GetThreadInformation|SetThreadInformation|GetProcessInformation|SetProcessInformation|GetProcessMitigationPolicy|SetProcessMitigationPolicy|DiscardVirtualMemory|SetThreadDescription|GetThreadDescription|IsWow64Process2|VirtualAlloc2|MapViewOfFile3|QueryInterruptTime|QueryInterruptTimePrecise|QueryUnbiasedInterruptTimePrecise|GetSystemCpuSetInformation|SetThreadSelectedCpuSets|GetDpiForWindow|GetDpiForMonitor|SetProcessDpiAwareness|SetProcessDpiAwarenessContext|RoInitialize|RoUninitialize|ProcessPrng|SetDefaultDllDirectories|AddDllDirectory)$'
  $dlls = @(); $viol = @(); $count = 0
  $impRva = [BitConverter]::ToUInt32($b, $dd + 8)
  if ($impRva) {
    $d = Off $impRva
    while ($true) {
      $oft = [BitConverter]::ToUInt32($b, $d); $nameRva = [BitConverter]::ToUInt32($b, $d + 12); $ft = [BitConverter]::ToUInt32($b, $d + 16)
      if ($nameRva -eq 0) { break }
      $dll = CStr (Off $nameRva); $dlls += $dll
      if ($dll -match $badDll) { $viol += ('DLL ' + $dll) }
      $t = Off ($(if ($oft) { $oft } else { $ft }))
      while ($true) {
        $v = [BitConverter]::ToUInt32($b, $t); if ($v -eq 0) { break }
        if (($v -band 0x80000000) -eq 0) { $sym = CStr ((Off $v) + 2); $count++; if ($sym -match $badSym) { $viol += ($dll + '!' + $sym) } }
        $t += 4
      }
      $d += 20
    }
  }
  Write-Host ('    格式：32 位 DLL，子系统版本 ' + $subsys + '，导出 ' + $exports.Count + ' 个，导入 ' + $count + ' 个函数')
  Write-Host ('    依赖：' + ($dlls -join '、'))
  if ($Def -and (Test-Path -LiteralPath $Def)) {
    $want = @(); $inExp = $false
    foreach ($line in [System.IO.File]::ReadAllLines($Def)) {
      $t = ($line -replace ';.*$', '').Trim()
      if ($t -eq 'EXPORTS') { $inExp = $true; continue }
      if ($inExp -and $t) { $want += ($t -split '\s+')[0] }
    }
    $miss = @($want | Where-Object { $exports -notcontains $_ })
    if ($miss.Count) { $ok = $false; Write-Host ('    缺少导出：' + ($miss -join '、')) -ForegroundColor Red }
    else { Write-Host ('    导出表：与 ' + (Split-Path -Leaf $Def) + ' 一致（' + $want.Count + ' 个）') -ForegroundColor Green }
  }
  if ($viol.Count) { $ok = $false; Write-Host ('    Win7 兼容：不通过 ' + ($viol -join '、')) -ForegroundColor Red }
  else { Write-Host '    Win7 兼容：通过（没有 Win8 以上才有的系统函数，也不依赖 UCRT 或 WebView2Loader.dll）' -ForegroundColor Green }
  if ($ok) { exit 0 } else { exit 1 }
}

Write-Host ('未知操作：' + $Action)
exit 2
