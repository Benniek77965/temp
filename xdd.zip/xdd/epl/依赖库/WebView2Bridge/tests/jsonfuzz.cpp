// WV_JsonGet / WV_JsonQuote / 编码转换的模糊测试与差分测试（配合 tests/jsondiff.py）
//   jsonfuzz.exe crash 次数 种子                —— 随机变异输入，GBK/UTF-8/西欧三种编码页轮换；DLL 内出错时打印当时的输入
//   jsonfuzz.exe diff cases.txt results.txt     —— 逐行读取 base64 的 JSON 与路径，UTF-8 编码页下取值，结果写成 base64
//   jsonfuzz.exe quote 编码页 输入 输出          —— 逐行转义再取回，检查往返是否一致
// 用法：python3 jsondiff.py gen → 运行 diff 与两次 quote（65001 q_u.txt r_u.txt、936 q_g.txt r_g.txt）→ python3 jsondiff.py cmp
#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include "wv2bridge.h"
static decltype(&WV_JsonGet) pGet;
static decltype(&WV_JsonQuote) pQuote;
static decltype(&WV_SetOption) pSet;
static decltype(&WV_EvGet) pEvGet;
static const std::string* g_curJson;
static const std::string* g_curPath;
static long g_iter;
static std::string Hex(const std::string& s) { std::string r; char b[4]; for (unsigned char c : s.substr(0, 300)) { sprintf(b, "%02x", c); r += b; } return r; }
static LONG CALLBACK Veh(EXCEPTION_POINTERS* e) {
  DWORD c = e->ExceptionRecord->ExceptionCode;
  if (c == EXCEPTION_ACCESS_VIOLATION || c == EXCEPTION_STACK_OVERFLOW || c == EXCEPTION_ARRAY_BOUNDS_EXCEEDED || c == EXCEPTION_INT_DIVIDE_BY_ZERO) {
    HMODULE m = nullptr; wchar_t mod[MAX_PATH] = L"?";
    if (GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)e->ExceptionRecord->ExceptionAddress, &m)) GetModuleFileNameW(m, mod, MAX_PATH);
    // 只报告发生在 DLL 或本程序里的异常；系统模块自己引发并处理的第一次机会异常（例如进程退出阶段）不算
    if (m != GetModuleHandleW(L"WebView2Bridge.dll") && m != GetModuleHandleW(nullptr)) return EXCEPTION_CONTINUE_SEARCH;
    printf("CRASH code=%08lx at=%p module=%ls offset=%lx data=%p iter=%ld json=%s path=%s\n", c, e->ExceptionRecord->ExceptionAddress, mod,
           m ? (unsigned long)((char*)e->ExceptionRecord->ExceptionAddress - (char*)m) : 0ul, e->ExceptionRecord->NumberParameters > 1 ? (void*)e->ExceptionRecord->ExceptionInformation[1] : nullptr,
           g_iter, g_curJson ? Hex(*g_curJson).c_str() : "-", g_curPath ? Hex(*g_curPath).c_str() : "-");
    fflush(stdout);
    ExitProcess(3);
  }
  return EXCEPTION_CONTINUE_SEARCH;
}
static const char* B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static std::string B64Enc(const std::string& s) {
  std::string r; int i = 0; unsigned v = 0;
  for (unsigned char c : s) { v = (v << 8) | c; if (++i == 3) { r += B64[v >> 18 & 63]; r += B64[v >> 12 & 63]; r += B64[v >> 6 & 63]; r += B64[v & 63]; i = 0; v = 0; } }
  if (i == 1) { v <<= 16; r += B64[v >> 18 & 63]; r += B64[v >> 12 & 63]; r += "=="; }
  if (i == 2) { v <<= 8; r += B64[v >> 18 & 63]; r += B64[v >> 12 & 63]; r += B64[v >> 6 & 63]; r += '='; }
  return r;
}
static std::string B64Dec(const std::string& s) {
  std::string r; unsigned v = 0; int n = 0;
  for (char ch : s) { const char* p = strchr(B64, ch); if (!p || ch == 0) continue; v = (v << 6) | (unsigned)(p - B64); if (++n == 4) { r += (char)(v >> 16); r += (char)(v >> 8 & 255); r += (char)(v & 255); n = 0; v = 0; } }
  if (n == 2) r += (char)(v >> 4); else if (n == 3) { r += (char)(v >> 10); r += (char)(v >> 2 & 255); }
  return r;
}
static unsigned g_rng = 1;
static unsigned Rnd() { g_rng ^= g_rng << 13; g_rng ^= g_rng >> 17; g_rng ^= g_rng << 5; return g_rng; }
int main(int argc, char** argv) {
  HMODULE d = LoadLibraryW(L"WebView2Bridge.dll");
  pGet = reinterpret_cast<decltype(pGet)>(reinterpret_cast<void*>(GetProcAddress(d, "WV_JsonGet")));
  pQuote = reinterpret_cast<decltype(pQuote)>(reinterpret_cast<void*>(GetProcAddress(d, "WV_JsonQuote")));
  pSet = reinterpret_cast<decltype(pSet)>(reinterpret_cast<void*>(GetProcAddress(d, "WV_SetOption")));
  pEvGet = reinterpret_cast<decltype(pEvGet)>(reinterpret_cast<void*>(GetProcAddress(d, "WV_EvGet")));
  if (!getenv("NOVEH")) AddVectoredExceptionHandler(1, Veh);
  std::string mode = argc > 1 ? argv[1] : "crash";
  if (mode == "quote") {  // fuzz.exe quote 编码页 输入 输出：每行 base64 文本 → 转义结果与再取回结果
    pSet(WVO_CODEPAGE, argv[2]);
    FILE* in = fopen(argv[3], "rb"); FILE* out = fopen(argv[4], "wb");
    if (!in || !out) { printf("QUOTE cannot open files\n"); return 2; }
    char line[1 << 16]; long n = 0;
    while (fgets(line, sizeof(line), in)) {
      std::string l(line); while (!l.empty() && (l.back() == '\n' || l.back() == '\r')) l.pop_back();
      std::string txt = B64Dec(l);
      std::string q = pQuote(txt.c_str());
      std::string back = pGet(q.c_str(), "");
      fprintf(out, "%s\t%s\n", B64Enc(q).c_str(), B64Enc(back).c_str()); ++n;
    }
    fclose(out); fclose(in);
    printf("QUOTE done %ld\n", n);
    return 0;
  }
  if (mode == "diff") {
    pSet(WVO_CODEPAGE, "65001");
    FILE* in = fopen(argv[2], "rb"); FILE* out = fopen(argv[3], "wb");
    if (!in || !out) { printf("DIFF cannot open files\n"); return 2; }
    char line[1 << 16]; long n = 0;
    while (fgets(line, sizeof(line), in)) {
      std::string l(line); while (!l.empty() && (l.back() == '\n' || l.back() == '\r')) l.pop_back();
      size_t t = l.find('\t'); if (t == std::string::npos) continue;
      std::string json = B64Dec(l.substr(0, t)), path = B64Dec(l.substr(t + 1));
      g_curJson = &json; g_curPath = &path; ++g_iter;
      std::string r = pGet(json.c_str(), path.c_str());
      fprintf(out, "%s\n", B64Enc(r).c_str()); ++n;
    }
    fclose(out); fclose(in);
    printf("DIFF done %ld\n", n);
    return 0;
  }
  long iters = argc > 2 ? atol(argv[2]) : 100000; g_rng = argc > 3 ? (unsigned)atol(argv[3]) : 12345u;
  const char* seeds[] = {
      "{\"a\":{\"b\":[1,2,{\"c\":\"\\u4e2d\\u6587\\ud83d\\ude00\"}]},\"d\":true,\"e\":null,\"f\":-1.5e3}",
      "[[],[[]],{},{\"\":\"\"},\"\\\\\\\"\\/\\b\\f\\n\\r\\t\"]",
      "{\"\xd6\xd0\xce\xc4\":\"\xd6\xd0\xce\xc4\",\"x\":\"\xe4\xb8\xad\xe6\x96\x87\"}",
      "  {  \"k\" :  [ 1 , 2 , 3 ] , \"s\" : \"a b\" }  ", "\"just a string\"", "12345678901234567890", "[1,]", "{\"a\":}", "\"\\ud800\""};
  const char* pathSeeds[] = {"", "a", "a.b", "a.b[2].c", "[0]", "[4]", "d", "e", "f", "k[1]", "[99999999999]", "[-1]", "a[", "a]", ".", "..", "a..b", "[0][0]", "x", "\xd6\xd0\xce\xc4", "\xe4\xb8\xad\xe6\x96\x87", "a.b[2].c.d.e.f", "[0x1]", "[ 1 ]", "a.b[2]\x00"};
  const char* specials = "\"\\{}[]:,.ux0123456789 \t\r\n-+eE";
  const char* cps[] = {"936", "65001", "1252"};
  DWORD worst = 0; long worstIter = 0; long quotes = 0;
  for (g_iter = 0; g_iter < iters; ++g_iter) {
    if (g_iter % 20000 == 0) pSet(WVO_CODEPAGE, cps[(g_iter / 20000) % 3]);
    std::string j = seeds[Rnd() % (sizeof(seeds) / sizeof(*seeds))];
    int muts = 1 + Rnd() % 6;
    for (int m = 0; m < muts && !j.empty(); ++m) {
      size_t pos = Rnd() % (j.size() + 1);
      switch (Rnd() % 6) {
        case 0: if (pos < j.size()) j.erase(pos, 1 + Rnd() % 4); break;
        case 1: j.insert(pos, 1, specials[Rnd() % strlen(specials)]); break;
        case 2: j.insert(pos, 1, (char)(0x80 + Rnd() % 0x7f)); break;
        case 3: if (pos < j.size()) j[pos] = (char)(1 + Rnd() % 255); break;
        case 4: j.insert(pos, std::string(1 + Rnd() % 30, "[{\""[Rnd() % 3])); break;
        case 5: j = j.substr(0, pos); break;
      }
    }
    std::string p = pathSeeds[Rnd() % (sizeof(pathSeeds) / sizeof(*pathSeeds))];
    if (Rnd() % 4 == 0 && !p.empty()) p.insert(Rnd() % (p.size() + 1), 1, "[].\"0x9\xd6"[Rnd() % 9]);
    g_curJson = &j; g_curPath = &p;
    LARGE_INTEGER q0, q1, qf; QueryPerformanceCounter(&q0);
    const char* r = pGet(j.c_str(), p.c_str());
    volatile size_t len = r ? strlen(r) : 0; (void)len;
    if (Rnd() % 8 == 0) { pQuote(j.c_str()); ++quotes; }
    QueryPerformanceCounter(&q1); QueryPerformanceFrequency(&qf);
    DWORD dt = (DWORD)((q1.QuadPart - q0.QuadPart) * 1000000 / qf.QuadPart);
    if (dt > worst) { worst = dt; worstIter = g_iter; }
    if (dt > 3000) printf("SLOW iter=%ld %luus jsonlen=%d json=%s path=%s\n", g_iter, dt, (int)j.size(), Hex(j).substr(0, 120).c_str(), Hex(p).c_str());
  }
  g_curJson = nullptr; g_curPath = nullptr;
  printf("EVGET outside callback -> [%s]\n", pEvGet(1));
  printf("FUZZ ok iterations=%ld quotes=%ld worst=%luus at iter %ld\n", iters, quotes, worst, worstIter);
  return 0;
}
