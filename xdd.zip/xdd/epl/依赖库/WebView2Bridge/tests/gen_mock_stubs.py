# 从 WebView2.h 生成模拟运行时（mockwv.cpp）所需的桩类 mock_stubs.h：所有方法返回 E_NOTIMPL，模拟对象只覆盖要用到的方法
# 用法：python gen_mock_stubs.py   （在 tests 目录运行，输出到同目录）
import os, re
here = os.path.dirname(os.path.abspath(__file__))
H = open(os.path.join(here, '..', 'src', 'third_party', 'webview2', 'include', 'WebView2.h'), encoding='utf-8', errors='replace').read()
WANT = ['ICoreWebView2Environment', 'ICoreWebView2Controller', 'ICoreWebView2', 'ICoreWebView2Settings', 'ICoreWebView2NavigationStartingEventArgs',
        'ICoreWebView2NavigationCompletedEventArgs', 'ICoreWebView2SourceChangedEventArgs', 'ICoreWebView2WebMessageReceivedEventArgs',
        'ICoreWebView2NewWindowRequestedEventArgs', 'ICoreWebView2PermissionRequestedEventArgs', 'ICoreWebView2Deferral',
        'ICoreWebView2WebResourceRequestedEventArgs', 'ICoreWebView2WebResourceRequest', 'ICoreWebView2HttpRequestHeaders',
        'ICoreWebView2WebResourceResponse', 'ICoreWebView2ProcessFailedEventArgs', 'ICoreWebView2_4', 'ICoreWebView2CookieManager',
        'ICoreWebView2Cookie', 'ICoreWebView2CookieList', 'ICoreWebView2WebResourceResponseReceivedEventArgs', 'ICoreWebView2WebResourceResponseView',
        'ICoreWebView2DOMContentLoadedEventArgs', 'ICoreWebView2DownloadStartingEventArgs', 'ICoreWebView2DownloadOperation',
        'ICoreWebView2ScriptDialogOpeningEventArgs', 'ICoreWebView2_11', 'ICoreWebView2AcceleratorKeyPressedEventArgs', 'ICoreWebView2ContextMenuRequestedEventArgs',
        'ICoreWebView2ContextMenuItemCollection', 'ICoreWebView2ContextMenuItem', 'ICoreWebView2BasicAuthenticationRequestedEventArgs',
        'ICoreWebView2BasicAuthenticationResponse', 'ICoreWebView2Environment2', 'ICoreWebView2Environment6', 'ICoreWebView2Environment10', 'ICoreWebView2ControllerOptions', 'ICoreWebView2PrintSettings', 'ICoreWebView2DevToolsProtocolEventReceiver',
        'ICoreWebView2DevToolsProtocolEventReceivedEventArgs', 'ICoreWebView2Settings9',
        'ICoreWebView2WebMessageReceivedEventArgs2', 'ICoreWebView2ObjectCollectionView', 'ICoreWebView2File']
out = ['// 由 gen_mock_stubs.py 从 WebView2.h 生成，请勿手改', '#pragma once']
def methods(name):  # 沿继承链收集方法（基接口在前），派生自 ICoreWebView2_3 这类接口时一并实现基接口的全部方法
    m = re.search(r'MIDL_INTERFACE\("[0-9a-fA-F-]+"\)\s*' + name + r'\s*:\s*public\s+(\w+)\s*\{\s*public:(.*?)\n\s*\};', H, re.S)
    if not m: raise SystemExit('接口未找到：' + name)
    own = re.findall(r'virtual\s+(?:/\*.*?\*/\s*)*HRESULT\s+STDMETHODCALLTYPE\s+(\w+)\s*\((.*?)\)\s*=\s*0\s*;', m.group(2), re.S)
    return ([] if m.group(1) == 'IUnknown' else methods(m.group(1))) + own
for name in WANT:
    out.append('struct Stub_%s : public %s {' % (name, name))
    for meth, params in methods(name):
        out.append('  HRESULT STDMETHODCALLTYPE %s(%s) override { return E_NOTIMPL; }' % (meth, ' '.join(re.sub(r'/\*.*?\*/', '', params, flags=re.S).split())))
    out.append('};')
open(os.path.join(here, 'mock_stubs.h'), 'w', encoding='utf-8', newline='\r\n').write('\n'.join(out) + '\n')  # 与仓库其它文件一样用 CRLF
print('已生成 mock_stubs.h：%d 个接口' % len(WANT))
