#!/usr/bin/env bash
# 一键验证（Linux 交叉编译环境）：编译 DLL 与全部开发者测试，在 Wine（32 位）里运行，再跑 Node 测试与一致性检查，最后汇总。
# 需要：mingw-w64（i686 与 x86_64）、wine（含 32 位）、node（domtest 另需 jsdom，可用 NODE_PATH 指定）、python3；
#      中文区域 zh_CN.UTF-8（Wine 的 ANSI 代码页因此为 936，GBK 相关用例依赖它）；paneltest 的断行用例需要中文字体。
# 用法：tests/run_all.sh [输出目录]      默认 <工程目录>/_test_out；WINEPREFIX 可指定 Wine 前缀
#       LLVM_MINGW=<llvm-mingw 的 bin 目录> 时再用 Clang 编译一份 DLL，跑 wvtest、mocktest、inittest
#       用系统自带的 clang 时，在某个目录里放一个可执行的 i686-w64-mingw32-clang++：exec clang++ --target=i686-w64-mingw32 -femulated-tls "$@"，
#       再把 LLVM_MINGW 指向这个目录。线程局部变量须与 mingw-w64 GCC 一样用模拟 TLS：Wine 9 下 LoadLibrary 载入的 DLL 用原生 TLS 时，首次访问就读到未初始化的槽位
#       不要加 -fuse-ld=lld：lld 与 mingw-w64 GCC 的 libgcc（DWARF 异常）一起用时，DLL 里抛出的异常接不住，进程直接结束（实测 wvtest 的内存不足用例）；用默认的 GNU ld
# 退出码：全部通过为 0，否则为 1
set -u
# 没有图形界面时（例如服务器、容器）借助 Xvfb 运行：Wine 没有显示器就创建不了窗口，绝大部分用例会失败
if [ -z "${DISPLAY:-}" ] && [ -z "${WV_UNDER_XVFB:-}" ] && command -v xvfb-run > /dev/null; then
  export WV_UNDER_XVFB=1; exec xvfb-run -a -s "-screen 0 1280x1024x24" bash "$0" "$@"
fi
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$ROOT/_test_out}"
mkdir -p "$OUT/inc" "$OUT/logs" && cd "$OUT" || exit 1
export WINEDEBUG=-all WINEDLLOVERRIDES="mscoree,mshtml=" LANG=zh_CN.UTF-8 LC_ALL=zh_CN.UTF-8
CXX=i686-w64-mingw32-g++
echo '#include <eventtoken.h>' > inc/EventToken.h   # 大小写敏感的文件系统上 WebView2.h 引用的 EventToken.h 在 mingw-w64 里是小写
INC="-I$OUT/inc -I$ROOT/src -I$ROOT/src/third_party/webview2/include"
SRCS="$ROOT/src/wv_util.cpp $ROOT/src/wv_runtime.cpp $ROOT/src/wv_host.cpp $ROOT/src/wv_view.cpp $ROOT/src/wv_feat.cpp $ROOT/src/wv_api.cpp"
FAILED=0; SUMMARY=""
lastline() { python3 -c 'import sys,re
ls=[x.rstrip(b"\r") for x in open(sys.argv[1],"rb").read().split(b"\n") if x.strip() and not re.match(rb"(PASS|FAIL|INFO)",x)]
x=ls[-1] if ls else b""
try: t=x.decode("utf-8")
except UnicodeDecodeError: t=x.decode("gbk","replace")
print(t[:90])' "$1"; }
note() { SUMMARY="$SUMMARY$1"$'\n'; }
build() { # 名称 命令...
  local n="$1"; shift
  if "$@" > "logs/build_$n.txt" 2>&1; then return 0; fi
  note "构建失败  $n（见 logs/build_$n.txt）"; FAILED=1; tail -5 "logs/build_$n.txt"; return 1
}
run() { # 名称 超时秒 命令...
  local n="$1" t="$2"; shift 2
  timeout "$t" "$@" > "logs/$n.txt" 2>&1; local rc=$?
  local p f; p=$(grep -ac '^PASS' "logs/$n.txt"); f=$(grep -ac '^FAIL' "logs/$n.txt")
  [ "$rc" -ne 0 ] || [ "${f:-0}" -ne 0 ] && FAILED=1
  note "$(printf '%-16s 退出码 %-4s 通过 %-4s 失败 %-3s %s' "$n" "$rc" "${p:-0}" "${f:-0}" "$(lastline "logs/$n.txt")")"
  python3 -c 'import sys
for x in open(sys.argv[1],"rb").read().split(b"\n"):
    if x.startswith(b"FAIL"):
        try: print(x.decode("utf-8").rstrip()[:200])
        except UnicodeDecodeError: print(x.decode("gbk","replace").rstrip()[:200])' "logs/$n.txt" | head -20
}
# ---- 编译
# DLL 的编译命令（参数是输出文件名）。--no-insert-timestamp：不写链接时间，同一份源码编译出逐字节相同的 DLL（可复现构建）
build_dll_to() {
  $CXX -std=c++17 -O2 -s -shared -static -static-libgcc -static-libstdc++ -ffunction-sections -fdata-sections -DUNICODE -D_UNICODE \
    -DWINVER=0x0601 -D_WIN32_WINNT=0x0601 -Wall -Wextra $INC $SRCS -o "$1" -Wl,--gc-sections -Wl,--kill-at -Wl,--nxcompat \
    -Wl,--dynamicbase -Wl,--major-subsystem-version,6 -Wl,--minor-subsystem-version,1 -Wl,--no-insert-timestamp -lole32 -luser32 -lgdi32 -ladvapi32 -lshell32 -lversion
}
build_dll_in_repro() { mkdir -p repro && ( cd repro && build_dll_to WebView2Bridge.dll ); }
build dll build_dll_to WebView2Bridge.dll
W=$(grep -a 'warning:' logs/build_dll.txt | grep -avc 'pragma warning'); note "DLL 编译警告（不计 WebView2.h 自带的 #pragma 提示）：$W"; [ "$W" -ne 0 ] && FAILED=1
# 可复现构建：在另一个目录用同样的命令再编译一次（输出文件名相同：mingw 的 ld 按输出文件名推算 DLL 的默认基址），两份必须逐字节相同
if build dll_repro build_dll_in_repro; then
  if cmp -s WebView2Bridge.dll repro/WebView2Bridge.dll; then note "可复现构建：另一目录重新编译的 DLL 与原 DLL 逐字节相同"; else note "可复现构建：两次编译的 DLL 不同"; FAILED=1; fi
fi
# 产物检查：与 build.bat 调用的 wv2build.ps1 -Action CheckPE 规则相同（32 位、导出表与 .def 一致、Win7 兼容的导入表）
[ -f WebView2Bridge.dll ] && run pecheck 60 python3 "$ROOT/tools/pecheck.py" WebView2Bridge.dll "$ROOT/src/wv2bridge.def"
build mockwv $CXX -std=c++17 -O1 -shared -static $INC "$ROOT/tests/mockwv.cpp" -o mockwv.dll -Wl,--kill-at -lole32 -luser32
for t in wvtest mocktest rttest racetest jsonfuzz inittest handofftest jsonbench; do
  [ -f "$ROOT/tests/$t.cpp" ] && build $t $CXX -std=c++17 -O1 -static $INC "$ROOT/tests/$t.cpp" -o $t.exe -lole32
done
build paneltest $CXX -std=c++17 -O1 -static -municode -DUNICODE -D_UNICODE $INC "$ROOT/tests/paneltest.cpp" -o paneltest.exe -lole32 -loleacc -loleaut32 -luser32 -lgdi32 -ladvapi32 -lshell32 -lversion
build helpertest $CXX -std=c++17 -O1 -static -municode -DUNICODE -D_UNICODE $INC "$ROOT/tests/helpertest.cpp" -o helpertest.exe -lole32 -luser32 -lgdi32 -ladvapi32 -lshell32 -lversion
build installtest $CXX -std=c++17 -O1 -static -municode -DUNICODE -D_UNICODE $INC "$ROOT/tests/installtest.cpp" -o installtest.exe -lole32 -luser32 -lgdi32 -ladvapi32 -lshell32 -lversion
build cardshot $CXX -std=c++17 -O2 -static -municode -DUNICODE -D_UNICODE $INC "$ROOT/tests/cardshot.cpp" -o cardshot.exe -lole32 -luser32 -lgdi32 -ladvapi32 -lshell32 -lversion
build sigtest $CXX -std=c++17 -O1 -static -I"$ROOT/src" "$ROOT/tests/sigtest.cpp" -o sigtest.exe -lwintrust -lcrypt32
build dummy64 x86_64-w64-mingw32-gcc -shared "$ROOT/tests/d64.c" -o dummy64.dll
# ---- 运行（Wine，Windows 10 模式）
wine reg add 'HKCU\Software\Wine' /v Version /d win10 /f > /dev/null 2>&1; wineserver -w
run wvtest 600 wine wvtest.exe
run mocktest 900 wine mocktest.exe
run paneltest 600 wine paneltest.exe
[ -f helpertest.exe ] && run helpertest 300 wine helpertest.exe
run rttest 300 wine rttest.exe
run rttest_install 300 wine rttest.exe install
[ -f installtest.exe ] && run installtest 300 wine installtest.exe  # 1.8.1：后台安装（不经界面线程、状态与冷却）与等别的进程启动的安装程序
[ -f inittest.exe ] && run inittest 300 wine inittest.exe
[ -f handofftest.exe ] && for i in 1 2; do run handofftest_$i 150 wine handofftest.exe; done  # 跨线程转交：开始与取消的边界
for i in 1 2 3; do run racetest_$i 300 wine racetest.exe; done
run jsonfuzz 900 wine jsonfuzz.exe crash 30000 1
[ -f jsonbench.exe ] && run jsonbench 300 wine jsonbench.exe  # JSON取值 逐个取数组成员：复用解析结果，比每次重新解析快得多（耗时上限与快慢对比）
# ---- 可选：用 llvm-mingw 的 Clang 再编译一份 DLL，拿同一批测试程序跑一遍（设置 LLVM_MINGW 为 llvm-mingw 的 bin 目录时）
if [ -n "${LLVM_MINGW:-}" ] && [ -x "$LLVM_MINGW/i686-w64-mingw32-clang++" ]; then
  mkdir -p clang
  if build dll_clang "$LLVM_MINGW/i686-w64-mingw32-clang++" -std=c++17 -O2 -s -shared -static -ffunction-sections -fdata-sections -DUNICODE -D_UNICODE \
      -DWINVER=0x0601 -D_WIN32_WINNT=0x0601 -Wall -Wextra -Wno-unknown-pragmas $INC $SRCS -o clang/WebView2Bridge.dll -Wl,--gc-sections -Wl,--kill-at -Wl,--no-insert-timestamp \
      -Wl,--nxcompat -Wl,--dynamicbase -Wl,--major-subsystem-version,6 -Wl,--minor-subsystem-version,1 \
      -lole32 -luser32 -lgdi32 -ladvapi32 -lshell32 -lversion; then
    W=$(grep -ac 'warning:' logs/build_dll_clang.txt); note "Clang（$("$LLVM_MINGW/i686-w64-mingw32-clang++" --version | head -1 | sed 's/ (.*//')）编译 DLL 的警告：$W"; [ "$W" -ne 0 ] && FAILED=1
    run pecheck_clang 60 python3 "$ROOT/tools/pecheck.py" clang/WebView2Bridge.dll "$ROOT/src/wv2bridge.def"
    cp wvtest.exe mocktest.exe inittest.exe mockwv.dll dummy64.dll clang/
    run wvtest_clang 600 sh -c 'cd clang && exec wine wvtest.exe'
    run mocktest_clang 900 sh -c 'cd clang && exec wine mocktest.exe'
    run inittest_clang 300 sh -c 'cd clang && exec wine inittest.exe'
  fi
fi
# ---- Windows 7 模式（运行时选择只能用 109、wvtest 的系统相关用例）
wine reg add 'HKCU\Software\Wine' /v Version /d win7 /f > /dev/null 2>&1; wineserver -w
run rttest_win7 300 wine rttest.exe win7
run rttest_install_win7 300 wine rttest.exe install  # 1.8.0：Win7/8/8.1 也去下载安装（原来直接拒绝）
[ -f installtest.exe ] && run installtest_win7 300 wine installtest.exe win7  # 1.8.1：同上，走 109 版离线安装包
run wvtest_win7 600 wine wvtest.exe win7
wine reg add 'HKCU\Software\Wine' /v Version /d win10 /f > /dev/null 2>&1; wineserver -w
# ---- JSON 差分测试（与 Python json 模块逐条对比）
( cp "$ROOT/tests/jsondiff.py" . && python3 jsondiff.py gen && wine jsonfuzz.exe diff cases.txt results.txt && wine jsonfuzz.exe quote 65001 q_u.txt r_u.txt \
  && wine jsonfuzz.exe quote 936 q_g.txt r_g.txt && python3 jsondiff.py cmp ) > logs/jsondiff.txt 2>&1; rc=$?
[ $rc -ne 0 ] && FAILED=1; note "$(printf '%-16s 退出码 %-4s %s' jsondiff "$rc" "$(lastline logs/jsondiff.txt)")"
# ---- Node：JS 桥脚本与元素操作脚本（从 src/wv_feat.cpp 原样取出）
run bridgetest 120 node "$ROOT/tests/bridgetest.js"
run domtest 120 node "$ROOT/tests/domtest.js"
# ---- 一致性检查
run apicheck 60 python3 "$ROOT/tools/apicheck.py"
run u8check 60 python3 "$ROOT/tools/u8check.py"
echo "================ 汇总（$OUT）================"
printf '%s' "$SUMMARY"
[ $FAILED -eq 0 ] && echo "结果：全部通过" || echo "结果：有失败项"
exit $FAILED
