// WV_Init 在工作线程先调用（1.4.0 修正）：不能把工作线程登记成界面线程，也不能把它的 COM 套间初始化成 STA。
// 原来工作线程会被永久当成界面线程（线程结束后调度窗口随之销毁），之后在真正的界面线程创建浏览器只会得到 WVERR_THREAD，
// 工作线程自己也不能再按 MTA 使用 COM。每个进程只登记一次界面线程，所以单独成一个测试程序。
// 编译：i686-w64-mingw32-g++ -std=c++17 -O1 -static -Isrc tests\inittest.cpp -o inittest.exe（与 WebView2Bridge.dll 放在同一目录运行；不需要 WebView2 运行时）
#include <windows.h>
#include <cstdio>
#include <string>
#include "wv2bridge.h"
static int g_pass, g_fail;
static void Check(bool c, const char* n, const std::string& got = "") {
  if (c) { ++g_pass; printf("PASS %s\n", n); } else { ++g_fail; printf("FAIL %s  [%s]\n", n, got.c_str()); }
  fflush(stdout);
}
static decltype(&WV_Init) pInit;
static int g_initRet = -1;
static HRESULT g_mta = E_FAIL;
static DWORD WINAPI Worker(LPVOID) {
  g_initRet = pInit("");
  g_mta = CoInitializeEx(nullptr, COINIT_MULTITHREADED);  // 工作线程之后还要按 MTA 使用 COM
  if (SUCCEEDED(g_mta)) CoUninitialize();
  return 0;
}
int main() {
  HMODULE dll = LoadLibraryW(L"WebView2Bridge.dll");
  if (!dll) { printf("FAIL load WebView2Bridge.dll\n"); return 2; }
  pInit = reinterpret_cast<decltype(&WV_Init)>(reinterpret_cast<void*>(GetProcAddress(dll, "WV_Init")));
  auto pCreate = reinterpret_cast<decltype(&WV_Create)>(reinterpret_cast<void*>(GetProcAddress(dll, "WV_Create")));
  auto pErr = reinterpret_cast<decltype(&WV_LastErrorCode)>(reinterpret_cast<void*>(GetProcAddress(dll, "WV_LastErrorCode")));
  auto pDestroy = reinterpret_cast<decltype(&WV_Destroy)>(reinterpret_cast<void*>(GetProcAddress(dll, "WV_Destroy")));
  HANDLE t = CreateThread(nullptr, 0, Worker, nullptr, 0, nullptr);
  WaitForSingleObject(t, 10000);
  CloseHandle(t);
  char hr[16];
  sprintf(hr, "0x%08lX", (unsigned long)g_mta);
  Check(g_initRet == 1, "WV_Init on a worker thread succeeds", std::to_string(g_initRet));
  Check(g_mta == S_OK || g_mta == S_FALSE, "WV_Init on a worker thread leaves its COM apartment alone (MTA still possible)", hr);
  WNDCLASSW wc = {};
  wc.lpfnWndProc = DefWindowProcW;
  wc.hInstance = GetModuleHandleW(nullptr);
  wc.lpszClassName = L"InitTestParent";
  RegisterClassW(&wc);
  HWND p = CreateWindowExW(0, L"InitTestParent", L"p", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 400, 300, nullptr, nullptr, wc.hInstance, nullptr);
  int h = pCreate(p, 0, 0, 0, 0, "", "fallback=1", 3000);  // 没有运行时：返回句柄并显示提示卡片
  int e = pErr();
  Check(h != 0 && e != WVERR_THREAD, "creating on the real UI thread works after WV_Init ran on a worker", std::to_string(h) + "/" + std::to_string(e));
  if (h) pDestroy(h);
  DestroyWindow(p);
  printf("RESULT pass=%d fail=%d\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
