// 性能回归测试：JSON取值（WV_JsonGet）复用上一次的解析结果。
// 逐个取数组成员时传进来的总是同一段 JSON：DLL 只按字节比较原文，不再整段重新解析（原来 4000 个成员、126 KB 的数组
// 逐个取两个字段共 8000 次，Wine 下约 31 秒）。比较原文的开销仍与 JSON 的长度成正比，所以这里检查的是“复用时比重新解析快得多”
// 与一个留足余量的绝对时间，而不是与成员数成正比。在 Wine 中运行：wine jsonbench.exe（与 WebView2Bridge.dll 放在同一目录）
#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include "wv2bridge.h"

static int g_pass = 0, g_fail = 0;
static void Check(bool c, const char* name, const std::string& got = std::string()) {
  if (c) { ++g_pass; printf("PASS %s\n", name); } else { ++g_fail; printf("FAIL %s  [got: %s]\n", name, got.c_str()); }
  fflush(stdout);
}
static double NowMs() {
  LARGE_INTEGER f, c;
  QueryPerformanceFrequency(&f);
  QueryPerformanceCounter(&c);
  return (double)c.QuadPart * 1000.0 / (double)f.QuadPart;
}

int main() {
  HMODULE dll = LoadLibraryW(L"WebView2Bridge.dll");
  if (!dll) { printf("FAIL load WebView2Bridge.dll (%lu)\nRESULT pass=0 fail=1\n", GetLastError()); return 1; }
  auto setOpt = reinterpret_cast<decltype(&WV_SetOption)>(reinterpret_cast<void*>(GetProcAddress(dll, "WV_SetOption")));
  auto jsonGet = reinterpret_cast<decltype(&WV_JsonGet)>(reinterpret_cast<void*>(GetProcAddress(dll, "WV_JsonGet")));
  if (!setOpt || !jsonGet) { printf("FAIL exports missing\nRESULT pass=0 fail=1\n"); return 1; }
  setOpt(WVO_CODEPAGE, "65001");  // 与易语言模块相同：文本一律是 UTF-8
  double ms[2] = {0, 0};
  const int sizes[2] = {2000, 4000};
  for (int k = 0; k < 2; ++k) {
    const int n = sizes[k];
    std::string js = "[";
    for (int i = 0; i < n; ++i) {
      char item[64];
      snprintf(item, sizeof item, "%s{\"id\":%d,\"name\":\"\xE5\x90\x8D\xE5\xAD\x97%d\"}", i ? "," : "", i + 1, i);  // 名字0、名字1……
      js += item;
    }
    js += "]";
    long long sum = 0;
    int bad = 0;
    char path[32];
    const double t0 = NowMs();
    for (int i = 0; i < n; ++i) {
      snprintf(path, sizeof path, "[%d].id", i);
      sum += atoll(jsonGet(js.c_str(), path));
      snprintf(path, sizeof path, "[%d].name", i);
      char want[32];
      snprintf(want, sizeof want, "\xE5\x90\x8D\xE5\xAD\x97%d", i);
      if (strcmp(jsonGet(js.c_str(), path), want) != 0) ++bad;
    }
    ms[k] = NowMs() - t0;
    printf("INFO %d elements (%u bytes): %d lookups in %.1f ms (%.4f ms each)\n", n, (unsigned)js.size(), 2 * n, ms[k], ms[k] / (2 * n));
    const long long expect = (long long)n * (n + 1) / 2;
    std::string name = "every element read correctly while iterating " + std::to_string(n) + " elements";
    Check(sum == expect && bad == 0 && std::string(jsonGet(js.c_str(), "length")) == std::to_string(n), name.c_str(),
          std::to_string(sum) + " bad=" + std::to_string(bad));
  }
  // 门槛留足余量（Wine 下实测约 0.5 秒）：每次整段重新解析时需要 30 秒左右
  Check(ms[1] < 2000.0, "8000 lookups on a 4000-element array finish within 2 seconds", std::to_string(ms[1]) + " ms");
  // 复用与重新解析的对比：同样大小的 6 段 JSON 轮流传入（多于每个线程记下的 4 段，每次都要重新解析），与总传同一段（只比较字节）比较
  {
    const int n = 4000, rounds = 200, kinds = 6;
    std::string a = "[";
    for (int i = 0; i < n; ++i) a += std::string(i ? "," : "") + "{\"id\":" + std::to_string(i) + "}";
    a += "]";
    std::vector<std::string> v(kinds, a);
    for (int k = 0; k < kinds; ++k) v[k][v[k].size() - 3] = (char)('0' + k);  // a 以 3999}] 结尾，各段改成 3990}]～3995}]：长度相同、只差一个数字，必须按内容区分
    double t0 = NowMs();
    int bad = 0;
    for (int i = 0; i < rounds; ++i) if (atoi(jsonGet(a.c_str(), "[3999].id")) != 3999) ++bad;
    const double hit = NowMs() - t0;
    t0 = NowMs();
    for (int i = 0; i < rounds; ++i) {
      const int k = i % kinds;
      if (atoi(jsonGet(v[k].c_str(), "[3999].id")) != 3990 + k) ++bad;
    }
    const double miss = NowMs() - t0;
    printf("INFO %d lookups on the same %u-byte JSON: %.1f ms; cycling through %d JSON texts of the same size: %.1f ms\n", rounds, (unsigned)a.size(), hit, kinds, miss);
    Check(bad == 0, "texts of the same length that differ in one byte are told apart (no stale result)", std::to_string(bad));
    Check(hit * 10.0 < miss, "reusing the parse result is at least 10 times faster than parsing again", std::to_string(hit) + " ms vs " + std::to_string(miss) + " ms");
  }
  // 1.6.4：先取出一个成员、再取它的字段（易语言里常见的写法），两段 JSON 交替传入。每个线程记最近几段，大段的那一段一直能复用；
  // 只记一段时大段 JSON 每次都要重新解析（2000 个成员 Wine 下约 4.8 秒，4000 个成员约 20 秒）
  {
    const int n = 4000;
    std::string a = "[";
    for (int i = 0; i < n; ++i) a += std::string(i ? "," : "") + "{\"id\":" + std::to_string(i) + ",\"name\":\"n" + std::to_string(i) + "\"}";
    a += "]";
    long long sum = 0;
    char path[32];
    const double t0 = NowMs();
    for (int i = 0; i < n; ++i) {
      snprintf(path, sizeof path, "[%d]", i);
      const std::string item = jsonGet(a.c_str(), path);
      sum += atoll(jsonGet(item.c_str(), "id"));
    }
    const double ms = NowMs() - t0;
    printf("INFO element-then-field on %d elements (%u bytes): %.1f ms\n", n, (unsigned)a.size(), ms);
    Check(sum == (long long)n * (n - 1) / 2 && ms < 3000.0, "element-then-field lookups (two JSON texts alternate) on 4000 elements finish within 3 seconds",
          std::to_string(ms) + " ms, sum " + std::to_string(sum));
  }
  // 1.6.6：1～4 MB 的 JSON 也缓存（一段最大就是合计的 4 MB 上限）。原来超过 1 MB 就不缓存，1.9 MB 的数组每次取值都要整段解析（Wine 下约 90 毫秒一次）
  {
    const int n = 70000, lookups = 200;
    std::string a = "[";
    for (int i = 0; i < n; ++i) a += std::string(i ? "," : "") + "{\"id\":" + std::to_string(i) + ",\"name\":\"n" + std::to_string(i) + "\"}";
    a += "]";
    long long sum = 0, want = 0;
    char path[32];
    const double t0 = NowMs();
    for (int k = 0; k < lookups; ++k) {
      const int idx = (k * 997) % n;
      snprintf(path, sizeof path, "[%d].id", idx);
      sum += atoll(jsonGet(a.c_str(), path));
      want += idx;
    }
    const double ms = NowMs() - t0;
    printf("INFO %d lookups on a %.2f MB JSON: %.1f ms\n", lookups, a.size() / 1048576.0, ms);
    Check(a.size() > (1u << 20) && sum == want && ms < 3000.0, "a JSON between 1 and 4 MB is reused too: 200 lookups on 1.9 MB within 3 seconds", std::to_string(ms) + " ms");
  }
  printf("RESULT pass=%d fail=%d\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
