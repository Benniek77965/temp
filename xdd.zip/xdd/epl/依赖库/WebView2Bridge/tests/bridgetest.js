// JS 桥脚本测试：从 src/wv_feat.cpp 原样取出 DLL 内嵌的桥接脚本（kBridgeJs），在 Node 里模拟 window.chrome.webview 运行，
// 检查调用与回传、出错、事件（含 "*"）、once/off、链式调用、send、iframe 与重复注入。用法：node tests/bridgetest.js（任意目录均可）
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const src = fs.readFileSync(path.join(__dirname, '..', 'src', 'wv_feat.cpp'), 'utf8');
function cppWide(name) {  // 把 static const wchar_t* name = L"..." L"..."; 拼回原文并还原 C 转义
  let p = src.indexOf('=', src.indexOf('static const wchar_t* ' + name + ' =')) + 1, raw = '';
  const re = /\s*L"((?:[^"\\]|\\.)*)"/y;
  for (let m; (re.lastIndex = p, m = re.exec(src)); p = re.lastIndex) raw += m[1];
  if (!/^\s*;/.test(src.slice(p))) throw new Error('literal of ' + name + ' not terminated');
  return raw.replace(/\\(u[0-9a-fA-F]{4}|x[0-9a-fA-F]{2}|.)/g, (_, e) => e[0] === 'u' || e[0] === 'x' ? String.fromCharCode(parseInt(e.slice(1), 16)) : ({ n: '\n', r: '\r', t: '\t', 0: '\0' })[e] || e);
}
const bridge = cppWide('kBridgeJs');
// 停用 JS 桥时 DLL 在当前网页里执行的脚本：View::DisableBridge 按桥对象名拼出，这里照它的写法原样拼回
function disableJs(name) {
  const line = src.split('\n').find(l => l.includes('o.__eplBridge)delete window['));
  if (!line) throw new Error('DisableBridge script not found');
  return line.slice(line.indexOf('=') + 1).trim().replace(/;\s*$/, '').split('+').map(s => s.trim())
    .map(s => (s === 'n' ? JSON.stringify(name) : s.replace(/^L"/, '').replace(/"$/, ''))).join('');
}
let pass = 0, fail = 0;
function check(ok, name, got) { if (ok) { pass++; console.log('PASS ' + name); } else { fail++; console.log('FAIL ' + name + (got === undefined ? '' : '  [' + got + ']')); } }
function env(name, opt) {
  opt = opt || {};
  const handlers = [], posted = [], fired = [];
  const webview = { addEventListener(t, f) { if (t === 'message') handlers.push(f); }, postMessage(m) { posted.push(JSON.parse(JSON.stringify(m))); } };
  const win = { chrome: { webview }, dispatchEvent(e) { fired.push(e.type); } };
  win.window = win; win.top = opt.iframe ? {} : win;
  const ctx = vm.createContext({ window: win, console: { error() {} }, CustomEvent: class { constructor(t) { this.type = t; } } });
  const run = () => vm.runInContext(bridge.replace('%NAME%', JSON.stringify(name)), ctx);
  run();
  return { win, posted, fired, run, exec: js => vm.runInContext(js, ctx), deliver: d => handlers.forEach(f => f({ data: d })), b: win[name] };
}
(async () => {
  const e = env('epl'), epl = e.b;
  check(!!epl && epl.__eplBridge === true && e.fired.join() === 'eplready', 'bridge object defined and eplready fired');
  const p1 = epl.add(1, 2);
  const m1 = e.posted[0];
  check(m1 && m1.__epl === 1 && m1.t === 'c' && m1.n === 'add' && JSON.stringify(m1.a) === '[1,2]', 'proxy call posts name and arguments', JSON.stringify(m1));
  e.deliver({ __epl: 1, t: 'r', id: m1.id, ok: true, v: 3 });
  check(await p1 === 3, 'reply resolves the promise');
  const p2 = epl.call('bad name', 'x'); const m2 = e.posted[1];
  e.deliver({ __epl: 1, t: 'r', id: m2.id, ok: false, e: 'boom' });
  check(await p2.then(() => 'resolved', x => x.message) === 'boom' && m2.n === 'bad name', 'error reply rejects with the message; call() takes any name');
  check(epl.then === undefined && epl.toJSON === undefined && typeof epl.anything === 'function', 'not thenable, not JSON-able; other names become functions');
  const got = [];
  epl.on('x', v => got.push('on:' + v));
  epl.on('*', (n, v) => got.push('all:' + n + '=' + v));
  e.deliver({ __epl: 1, t: 'e', n: 'x', v: 1 });
  check(got.join() === 'on:1,all:x=1', 'on(name) gets data, on("*") gets (name, data)', got.join());
  got.length = 0;
  epl.once('y', v => got.push('once:' + v));
  e.deliver({ __epl: 1, t: 'e', n: 'y', v: 1 }); e.deliver({ __epl: 1, t: 'e', n: 'y', v: 2 });
  check(got.filter(s => s.startsWith('once')).join() === 'once:1', 'once fires exactly once', got.join());
  got.length = 0;
  epl.off('*');
  epl.once('*', (n, v) => got.push(n + '=' + v));
  e.deliver({ __epl: 1, t: 'e', n: 'z', v: 7 }); e.deliver({ __epl: 1, t: 'e', n: 'z', v: 8 });
  check(got.join() === 'z=7', 'once("*") gets (name, data) like on("*")', got.join());
  got.length = 0;
  const f = v => got.push('f:' + v);
  epl.once('w', f); epl.off('w', f);
  e.deliver({ __epl: 1, t: 'e', n: 'w', v: 1 });
  check(got.length === 0, 'off(name, handler) also removes a handler added with once', got.join());
  const ch = epl.on('q', () => {});
  check(typeof ch.add === 'function' && typeof epl.off('q').once === 'function', 'on/off/once return the bridge itself, so chained calls keep working', typeof ch.add);
  epl.send({ a: 1 });
  const m3 = e.posted[e.posted.length - 1];
  check(m3.t === 'm' && JSON.stringify(m3.v) === '{"a":1}', 'send posts a message', JSON.stringify(m3));
  e.deliver({ t: 'r', id: 1, ok: true }); e.deliver('text'); e.deliver(null);
  check(true, 'foreign messages are ignored without throwing');
  const fr = env('epl', { iframe: true });
  check(fr.b === undefined && fr.fired.length === 0, 'no bridge inside an iframe');
  const n = env('myBridge');
  check(!!n.b && n.win.epl === undefined && n.fired.join() === 'myBridgeready', 'custom bridge name');
  const before = e.win.epl; e.run();
  check(e.win.epl === before, 'injected twice: the first bridge object is kept');
  // 1.4.2：停用 JS 桥时删掉当前网页里的桥对象；网页自己的同名对象（没有桥的标记）不动；重新启用时再注入又能用
  const d = env('epl');
  d.exec(disableJs('epl'));
  check(d.win.epl === undefined && !('epl' in d.win), 'switching the bridge off deletes the bridge object from the page', typeof d.win.epl);
  d.run();
  check(!!d.win.epl && d.win.epl.__eplBridge === true, 'injecting again after switching off defines the bridge object again');
  const own = env('other'); own.win.mine = { keep: 1 };
  own.exec(disableJs('mine'));
  check(own.win.mine && own.win.mine.keep === 1, 'a page object with the same name but without the bridge mark is left alone');
  console.log('RESULT pass=' + pass + ' fail=' + fail);
  process.exitCode = fail ? 1 : 0;
})();
