// 白盒测试（1.4.0 新增与改动的内部函数）：把 DLL 源码直接编进来，检查路径判断、主机名解析、\u 转义、JS 桥未设白名单时的来源判定、
// 交给窗口的任务的编号表，以及一键安装的签名校验句柄。在没有 WebView2 运行时的环境（如 Wine）中运行。编译方式与 cardshot.cpp 相同：
// i686-w64-mingw32-g++ -std=c++17 -O1 -static -municode -DUNICODE -D_UNICODE -Isrc -Isrc\third_party\webview2\include tests\helpertest.cpp -o helpertest.exe -lole32 -luser32 -lgdi32 -ladvapi32 -lshell32 -lversion
#include "../src/wv_util.cpp"
#include "../src/wv_runtime.cpp"
#include "../src/wv_host.cpp"
#include "../src/wv_view.cpp"
#include "../src/wv_feat.cpp"
#include "../src/wv_api.cpp"
#include <cstdio>
#include <stdexcept>
#include <thread>
#include <malloc.h>

using namespace wv;
static int g_pass, g_fail;
static std::wstring g_fakeUrl, g_fakeFile, g_fakeUrls;  // 不联网的“下载”：记下地址与保存位置，写入一个小文件
static bool g_fakeFailHttps = false;  // 模拟没装 TLS 1.2 更新的 Windows 7：HTTPS 打不开
static HRESULT WINAPI FakeDownload(LPUNKNOWN, LPCWSTR url, LPCWSTR file, DWORD, LPVOID) {
  g_fakeUrls += (url ? url : L"") + std::wstring(L"\n");
  if (g_fakeFailHttps && url && wcsncmp(url, L"https://", 8) == 0) return (HRESULT)0x800C0008;  // INET_E_DOWNLOAD_FAILURE
  g_fakeUrl = url ? url : L"";
  g_fakeFile = file ? file : L"";
  HANDLE h = CreateFileW(file, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
  if (h == INVALID_HANDLE_VALUE) return HRESULT_FROM_WIN32(GetLastError());
  DWORD w = 0;
  WriteFile(h, "MZ-not-the-real-package", 23, &w, nullptr);
  CloseHandle(h);
  return S_OK;
}
static DWORD WINAPI FailSetSecurity(LPWSTR, SE_OBJECT_TYPE, SECURITY_INFORMATION, PSID, PSID, PACL, PACL) { return ERROR_ACCESS_DENIED; }  // 模拟加不上权限
static void Check(bool c, const char* n, const std::wstring& got = std::wstring()) {
  if (c) { ++g_pass; printf("PASS %s\n", n); } else { ++g_fail; printf("FAIL %s  [%s]\n", n, ToUtf8(got).c_str()); }
  fflush(stdout);
}

// ---- 1.5.0：回调保护调用桩的测试回调与寄存器探针
static int g_cbFlag;
static char g_cbSeen[64];
static int __stdcall HtCb4(int h, const char* s, int x, int* ref) {
  *ref = 1;
  return h + x + (int)strlen(s);
}
static int __stdcall HtCb2(int h, const char* s) { return h + (int)strlen(s); }
// 1.7.0：有回填参数的事件。回调按 g_htSetCancel / g_htSetResult 调用 WV_EvSetInt 回填；g_htCalls 记下被调用的回调（3、4、5 个参数）
static int g_htSetCancel = -1, g_htSetResult = -1000;
static std::string g_htCalls;
static void HtSetters() {
  if (g_htSetCancel >= 0) WV_EvSetInt(WVK_CANCEL, g_htSetCancel);
  if (g_htSetResult != -1000) WV_EvSetInt(WVK_RESULT, g_htSetResult);
}
static void __stdcall HtOut3(int, const char*, int) { g_htCalls += "3"; HtSetters(); }
static void __stdcall HtOut4(int, const char*, int, int) { g_htCalls += "4"; HtSetters(); }
static void __stdcall HtOut5(int, const char*, int, int, int* out) { g_htCalls += "5"; if (out) *out = 1; HtSetters(); }
static void __stdcall HtOut6(int, const char*, int, int, int* out, int) { g_htCalls += "6"; if (out) *out = 1; }
static void __cdecl HtSetOnly() { HtSetters(); }  // cdecl、不声明参数：不清栈，参数表检查不判断，只做回填
static int __stdcall HtCb6(int h, const char* s, int x, int* ref, int* extraRef, const char* extraText) {
  *ref = 1;
  *extraRef = 0x41414141;  // 给多声明的“参考”参数赋值
  snprintf(g_cbSeen, sizeof g_cbSeen, "%s", extraText ? extraText : "(null)");
  return h + x + (int)strlen(s);
}
static int __cdecl HtCbC(int h, const char* s, int x, int* ref) {
  *ref = 1;
  return h + x + (int)strlen(s);
}
static int g_regsOk;
extern "C" __attribute__((noinline)) void __stdcall HtCheckRegs(unsigned esi, unsigned edi, unsigned ebx) {
  g_regsOk = esi == 0x5E5E5E5Eu && edi == 0xD1D1D1D1u && ebx == 0xB0B0B0B0u;
}
// 调用前把 ESI、EDI、EBX 设成哨兵值，经保护调用桩调用回调后检查它们是否完好（调用方依赖这几个寄存器不被改动）
extern "C" __attribute__((naked, noinline)) int __stdcall HtProbe(void*, const intptr_t*, int, int, void*, int*) {
  __asm__ volatile(
      "pushl %ebp\n\t"
      "movl %esp, %ebp\n\t"
      "pushl %ebx\n\t"
      "pushl %esi\n\t"
      "pushl %edi\n\t"
      "movl $0x5E5E5E5E, %esi\n\t"
      "movl $0xD1D1D1D1, %edi\n\t"
      "movl $0xB0B0B0B0, %ebx\n\t"
      "pushl 28(%ebp)\n\t"
      "pushl 24(%ebp)\n\t"
      "pushl 20(%ebp)\n\t"
      "pushl 16(%ebp)\n\t"
      "pushl 12(%ebp)\n\t"
      "pushl 8(%ebp)\n\t"
      "call _WvSafeCallThunk@24\n\t"
      "pushl %eax\n\t"
      "pushl %ebx\n\t"
      "pushl %edi\n\t"
      "pushl %esi\n\t"
      "call _HtCheckRegs@12\n\t"
      "popl %eax\n\t"
      "popl %edi\n\t"
      "popl %esi\n\t"
      "popl %ebx\n\t"
      "popl %ebp\n\t"
      "ret $24\n\t");
}
static int __stdcall HtHook4(int, int, int, int) { return 0; }
// 声明了 4 个应有参数、再多写 16 个“参考”参数的回调：给第 16 个整段写入 600 字节（相当于较大的自定义数据类型）
static int __stdcall HtBigRef(int a, int b, int c, int d, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char* x16) {
  memset(x16, 0x5A, 600);
  return a + b + c + d;
}  // 只声明 4 个参数的回调转发（应为 5 个）
static std::vector<std::wstring> g_notices;
static void CaptureNotice(const std::wstring& t) { g_notices.push_back(t); }
static long StatNum(const wchar_t* key) {
  JVal j;
  if (!JsonParse(CheckStatsJson(), j)) return -1;
  const JVal* v = j.Get(key);
  return v ? (long)v->Num(-1) : -1;
}

// 1.6.4 的 JSON取值 缓存测试用：在工作线程里取一次值后一直不结束，等着被 TerminateThread（精易 线程_销毁 就是这样结束线程的）
struct KillArg {
  const std::string* doc;
  volatile LONG ready;
};
static DWORD WINAPI KillThread(LPVOID p) {
  KillArg* k = static_cast<KillArg*>(p);
  WV_JsonGet(k->doc->c_str(), "[0]");
  InterlockedExchange(&k->ready, 1);
  for (;;) Sleep(1000);
}

int wmain(int argc, wchar_t** argv) {
  if (argc > 1 && wcscmp(argv[1], L"--exit7") == 0) return 7;  // 供“持有只读句柄时仍能启动”的用例当作被启动的程序
  // ---- 主机名与路径
  Check(HostOf(L"http://[::1]:8080/x") == L"[::1]", "HostOf: an IPv6 literal keeps the whole bracketed address", HostOf(L"http://[::1]:8080/x"));
  Check(HostOf(L"https://user:pw@Host.Example:443/p") == L"host.example", "HostOf: user info and port removed, lower case", HostOf(L"https://user:pw@Host.Example:443/p"));
  Check(IsAbsPath(L"C:\\a") && IsAbsPath(L"c:/a") && IsAbsPath(L"\\\\srv\\share\\x") && IsAbsPath(L"//srv/share") && IsAbsPath(L"\\\\?\\C:\\x") && IsAbsPath(L"\\\\.\\pipe\\p"),
        "IsAbsPath: drive letters, network shares and device paths");
  Check(!IsAbsPath(L"a\\b") && !IsAbsPath(L"shot.png") && !IsAbsPath(L"\\a") && !IsAbsPath(L""), "IsAbsPath: relative paths (one leading backslash stays relative to the program folder, as before)");
  Check(AppPath(L"\\\\srv\\share\\a.png") == L"\\\\srv\\share\\a.png" && AppPath(L"").empty() && AppPath(L"a.png") == PathJoin(AppDir(), L"a.png"),
        "AppPath: network share kept, relative path joined to the program folder", AppPath(L"a.png"));
  // ---- \u 转义
  Check(DecodeUEscapes(L"a\\u0041\\u4E2D\\uD83D\\uDE00") == std::wstring(L"aA\x4E2D\xD83D\xDE00"), "DecodeUEscapes: BMP characters and a surrogate pair");
  Check(DecodeUEscapes(L"\\uDE00x\\uD83Dy\\u004") == L"\xFFFDx\xFFFDy\\u004", "DecodeUEscapes: lone surrogates become U+FFFD, an incomplete escape stays", DecodeUEscapes(L"\\uDE00x\\uD83Dy\\u004"));
  Check(DecodeUEscapes(L"\\\\srv\\u0041") == L"\\\\srvA" && DecodeUEscapes(L"\\U0041") == L"\\U0041", "DecodeUEscapes: only backslash plus lowercase u is special, doubled backslashes stay (network paths)",
        DecodeUEscapes(L"\\\\srv\\u0041"));
  // ---- 1.4.4：延迟回传时浏览器不在就绪状态（正在重建、创建失败），返回失败并说明原因
  {
    View* nv = new View(987654);
    nv->pendingCalls.insert(5);
    nv->sprops[-5] = L"1";
    ClearErr();
    const bool sent = nv->BridgeReply(5, true, L"1");
    const int code = WV_LastErrorCode();
    Check(!sent && code == WVERR_NOT_READY && !nv->pendingCalls.count(5), "BridgeReply on a view that is not ready fails with a reason", std::to_wstring(code));
    nv->Release();
  }
  // ---- 1.4.6：投递或转交给窗口的任务里抛出的异常留在窗口过程里，不穿出去（外面是系统的消息分发，穿出去进程会直接结束）
  {
    auto* boom = new std::function<void()>([] { throw std::bad_alloc(); });
    const LRESULT r1 = HostProc(nullptr, WM_WV_TASK, 0, TaskToken(boom, true));
    std::function<void()> boom2 = [] { throw std::runtime_error("x"); };
    const LRESULT r2 = DispProc(nullptr, WM_WV_INVOKE, 0, TaskToken(&boom2, false));
    bool ran = false;
    std::function<void()> ok = [&] { ran = true; };
    RunTask(ok);
    Check(r1 == 0 && r2 == 1 && ran, "an exception thrown by a posted or invoked task stays inside the window procedure");
  }
  // ---- JS 桥未设白名单时的来源判定
  std::map<std::wstring, FolderMap> none, mapped;
  mapped[L"assets.local"] = FolderMap{L"assets.local", L"C:\\ui", 1};
  std::vector<std::wstring> empty, star{L"*"};
  Check(OriginAllowed(empty, L"https://wv2bridge.example/1-1.html", none) && OriginAllowed(empty, L"https://demo.example/index.html", none) &&
            OriginAllowed(empty, L"https://a.test/", none) && OriginAllowed(empty, L"https://x.invalid/", none),
        "bridge default: https pages on reserved names are own content");
  std::wstring savedAppDir;
  {
    Guard g(GLock());
    savedAppDir = G().appDir;
    G().appDir = L"C:\\app";
  }
  Check(OriginAllowed(empty, L"file:///C:/app/ui/index.html", none) && OriginAllowed(empty, L"file:///c:/APP/Ui/x.html", none) &&
            OriginAllowed(empty, L"file://localhost/C:/app/a%20b.html?x=1#y", none) && OriginAllowed(empty, L"http://assets.local/a.html", mapped) &&
            OriginAllowed(empty, L"https://ASSETS.local/a.html", mapped),
        "bridge default: local files under the program directory and mapped hosts are own content");
  // 1.7.4：程序目录里浏览器替网页写文件的文件夹（用户数据目录、指定的下载目录）不算本程序的内容
  {
    const std::vector<std::wstring> web{L"C:\\app\\WebView2Data", L"C:\\app\\down"};
    Check(!OriginAllowed(empty, L"file:///C:/app/WebView2Data/EBWebView/Default/x.html", none, web) &&
              !OriginAllowed(empty, L"file:///C:/app/down/evil.html", none, web) && OriginAllowed(empty, L"file:///C:/app/ui/a.html", none, web) &&
              OriginAllowed(empty, L"file:///C:/app/WebView2Database/a.html", none, web),
          "bridge default: the user data folder and the download folder inside the program folder are not own content");
    std::map<std::wstring, FolderMap> appHost;
    appHost[L"app.local"] = FolderMap{L"app.local", L"C:\\app", 1};
    Check(!OriginAllowed(empty, L"https://app.local/down/evil.html", appHost, web) && !OriginAllowed(empty, L"https://app.local/%64own/evil.html", appHost, web) &&
              !OriginAllowed(empty, L"https://app.local/WebView2Data/x.html", appHost, web) && OriginAllowed(empty, L"https://app.local/ui/a.html", appHost, web) &&
              !OriginAllowed(empty, L"https://app.local/ui/..%5C..%5Cx.html", appHost, web) && OriginAllowed(empty, L"https://app.local/down/x.html", appHost),
          "bridge default: on a mapped host, files inside the user data or download folder are not own content (decoded, cannot climb out)");
    Check(PathFromMappedUrl(L"https://app.local/a%20b/%E4%B8%AD.html?x#y", L"C:\\app") == L"C:\\app\\a b\\\x4E2D.html" &&
              PathFromMappedUrl(L"https://app.local", L"C:\\app") == L"C:\\app" && PathFromMappedUrl(L"https://app.local/../x", L"C:\\app") == L"",
          "mapped host URL to file: decoded path under the mapped folder, nothing outside it");
    // 1.7.5：单个下载过的文件（回调_置下载路径 () 可以把它放进程序目录）同样不算，旁边的文件照常算
    const std::vector<std::wstring> got{L"C:\\app\\saved\\got.html"};
    RememberDownload(L"C:\\app\\saved\\remembered.html");
    Check(!OriginAllowed(empty, L"file:///C:/app/saved/got.html", none, got) && OriginAllowed(empty, L"file:///C:/app/saved/mine.html", none, got) &&
              !OriginAllowed(empty, L"https://app.local/saved/got.html", appHost, got) && !OriginAllowed(empty, L"file:///C:/app/saved/remembered.html", none) &&
              !OriginAllowed(empty, L"file:///c:/APP/Saved/REMEMBERED.HTML", none) && !OriginAllowed(empty, L"https://app.local/saved/remembered.html", appHost, web) &&
              WasDownloaded(L"C:\\APP\\saved\\Remembered.html") && !WasDownloaded(L"C:\\app\\saved\\mine.html"),
          "bridge default: a downloaded file is not own content wherever it was saved (any letter case); files next to it still are");
    // 1.7.7：被默认规则拒绝时写明具体原因；给网页的说明不写本地路径，给程序与日志的写出路径
    {
      const WebDirsFn data([] { return std::vector<std::wstring>{L"C:\\app\\WebView2Data"}; });
      const std::wstring outside = LocalDenyReason(L"file:///C:/other/x.html", none, data, false),
                         outsideP = LocalDenyReason(L"file:///C:/other/x.html", none, data, true),
                         dl = LocalDenyReason(L"file:///C:/app/saved/remembered.html", none, data, false),
                         inData = LocalDenyReason(L"file:///C:/app/WebView2Data/x.html", none, data, false),
                         inDataP = LocalDenyReason(L"file:///C:/app/WebView2Data/x.html", none, data, true),
                         mappedDl = LocalDenyReason(L"https://app.local/saved/remembered.html", appHost, data, false);
      Check(outside == L"这个本地文件不在程序目录里" && outsideP.find(L"C:\\other\\x.html") != std::wstring::npos && outsideP.find(L"C:\\app") != std::wstring::npos &&
                dl.find(L"本次运行里下载的") != std::wstring::npos && dl.find(L"C:\\") == std::wstring::npos &&
                inData.find(L"用户数据目录或下载目录") != std::wstring::npos && inData.find(L"C:\\") == std::wstring::npos &&
                inDataP.find(L"C:\\app\\WebView2Data") != std::wstring::npos && mappedDl.find(L"本次运行里下载的") != std::wstring::npos &&
                LocalDenyReason(L"file:///C:/app/ui/a.html", none, data, true).empty() && LocalDenyReason(L"https://www.baidu.com/", none, data, true).empty(),
            "bridge rejection names the reason (outside the program folder, downloaded, in a data folder); no local paths in the text for the page");
    }
    // 1.7.9：程序目录里默认的用户数据目录始终排除，即使当前没有哪个浏览器环境用它（例如改用了别的用户数据目录，旧的 WebView2Data 里
    // 仍有以前留下的网页数据）。变异测试发现去掉这一项也测不出来：用例里实际的用户数据目录恰好就是它
    {
      std::map<std::wstring, std::shared_ptr<EnvEntry>> savedEnvs;
      savedEnvs.swap(Envs());
      const std::vector<std::wstring> dirs0 = WebWrittenDirs();
      savedEnvs.swap(Envs());
      Check(std::find(dirs0.begin(), dirs0.end(), L"C:\\app\\WebView2Data") != dirs0.end() &&
                !OriginAllowed(empty, L"file:///C:/app/WebView2Data/old/x.html", none, dirs0),
            "the default user data folder inside the program folder is excluded even when no environment uses it");
    }
    // 1.7.9：往返一致：本地路径 → 打开 () 生成的网址（FileUrl）→ 浏览器规整后的网址（按 WHATWG 网址标准，路径里的空格、" < > ` { } 与非 ASCII 字符
    // 写成 UTF-8 的 %XX）→ 来源判定换回的路径，必须是同一个文件，并且算程序目录里的页面。随机生成 3000 个路径：文件名里允许的各种标点、
    // 中文、其它文字、表情（代理对），以及字面上像 %41、%2F 的文件夹名
    {
      unsigned seed = 20261017u;
      auto rnd = [&](unsigned n) {
        seed = seed * 1103515245u + 12345u;
        return (seed >> 16) % n;
      };
      const wchar_t* pool[] = {L"a", L"Z", L"0", L"9", L" ", L"!", L"#", L"$", L"%", L"&", L"'", L"(", L")", L"+", L",", L"-", L";", L"=", L"@",
                               L"[", L"]", L"^", L"_", L"`", L"{", L"}", L"~", L".", L"\x7A0B", L"\x5E8F", L"\x4E2D", L"\x6587", L"\x00E9", L"\x0416",
                               L"\xD55C", L"\xD83D\xDE00", L"%41", L"%2F"};
      const unsigned poolN = (unsigned)(sizeof(pool) / sizeof(pool[0]));
      auto canon = [](const std::wstring& u) {
        const std::string b = ToUtf8(u);
        std::wstring o;
        for (unsigned char c : b) {
          if (c >= 0x80 || c == ' ' || c == '"' || c == '<' || c == '>' || c == '`' || c == '{' || c == '}') {
            wchar_t t[8];
            swprintf(t, 8, L"%%%02X", c);
            o += t;
          } else {
            o += (wchar_t)c;
          }
        }
        return o;
      };
      int bad = 0;
      std::wstring firstBad;
      for (int i = 0; i < 3000; ++i) {
        std::wstring p = L"C:\\app";
        const unsigned segs = 1 + rnd(3);
        for (unsigned s = 0; s < segs; ++s) {
          std::wstring seg;
          const unsigned len = 1 + rnd(6);
          for (unsigned k = 0; k < len; ++k) seg += pool[rnd(poolN)];
          while (!seg.empty() && (seg.back() == L' ' || seg.back() == L'.')) seg.pop_back();  // Windows 去掉文件名末尾的空格与点
          if (seg.empty()) seg = L"x";
          p += L"\\" + seg;
        }
        const std::wstring want = FullPath(p), u1 = FileUrl(p), u2 = canon(u1);
        const bool ok = PathFromFileUrl(u1) == want && PathFromFileUrl(u2) == want && OriginAllowed(empty, u2, none);
        if (!ok && !bad++) firstBad = p + L" | " + u1 + L" | " + u2 + L" | " + PathFromFileUrl(u2);
      }
      Check(bad == 0, "3000 random local paths round-trip through the opened URL and its canonical form back to the same file in the program folder",
            std::to_wstring(bad) + L" " + firstBad);
    }
    // 1.7.9：浏览器替网页写文件的文件夹包括每个浏览器环境实际用的用户数据目录（变异测试发现：默认目录恰好在程序目录\WebView2Data 里，
    // 原来的用例去掉这一项也测不出来）
    {
      auto fake = std::make_shared<EnvEntry>();
      fake->udf = L"C:\\app\\data2";
      Envs()[L"helpertest-env"] = fake;
      const std::vector<std::wstring> dirs = WebWrittenDirs();
      Envs().erase(L"helpertest-env");
      Check(std::find(dirs.begin(), dirs.end(), L"C:\\app\\data2") != dirs.end() &&
                !OriginAllowed(empty, L"file:///C:/app/data2/EBWebView/x.html", none, dirs) && OriginAllowed(empty, L"file:///C:/app/data3/x.html", none, dirs),
            "web-written folders include each environment's actual user data folder, not only the default one");
    }
    // 1.7.6：记下几千个下载后，程序目录里的页面每次调用的来源判定仍只要几微秒（1.7.5 逐个比较，4096 个下载时约 1.9 毫秒一次）
    for (int i = 0; i < 4096; ++i) RememberDownload(L"C:\\app\\dl\\file" + std::to_wstring(i) + L".bin");
    LARGE_INTEGER pf, p0, p1;
    QueryPerformanceFrequency(&pf);
    QueryPerformanceCounter(&p0);
    int okCalls = 0;
    for (int i = 0; i < 1000; ++i) okCalls += OriginAllowed(empty, L"file:///C:/app/ui/index.html", none, WebWrittenDirs) ? 1 : 0;
    QueryPerformanceCounter(&p1);
    const double ms = (p1.QuadPart - p0.QuadPart) * 1000.0 / pf.QuadPart;
    printf("INFO 记下 4096 个下载后，1000 次来源判定用时 %.1f 毫秒\n", ms);
    Check(okCalls == 1000 && ms < 200.0 && WasDownloaded(L"C:\\app\\dl\\file4095.bin"),
          "bridge default: with thousands of remembered downloads a local page check still takes microseconds (hash lookup)", std::to_wstring(ms));
    std::vector<std::wstring> listedData{L"file:///C:/app/WebView2Data"};
    Check(OriginAllowed(listedData, L"file:///C:/app/WebView2Data/x.html", none, web), "bridge whitelist: a folder listed explicitly is still allowed");
  }
  // 1.7.0：其它目录、拖进来的文件、网络共享，以及用 .. 或 %5C 绕出程序目录的写法都不算本程序的内容
  Check(!OriginAllowed(empty, L"file:///C:/Users/u/Downloads/evil.html", none) && !OriginAllowed(empty, L"file:///C:/Windows/Temp/x.html", none) &&
            !OriginAllowed(empty, L"file://server/share/a.html", none) && !OriginAllowed(empty, L"file:///C:/app2/x.html", none) &&
            !OriginAllowed(empty, L"file:///C:/app/../Users/x.html", none) && !OriginAllowed(empty, L"file:///C:/app/..%5C..%5CUsers/x.html", none) &&
            !OriginAllowed(empty, L"file:///C:/app/a%00.html", none) && !OriginAllowed(empty, L"file:relative.html", none),
        "bridge default: local files elsewhere (downloads, temp, network shares, look-alike folders, .. and %5C escapes) are not own content");
  {
    Guard g(GLock());
    G().appDir = L"C:\\\x7A0B\x5E8F";  // C:\程序
  }
  Check(OriginAllowed(empty, L"file:///C:/%E7%A8%8B%E5%BA%8F/ui/a.html", none) && !OriginAllowed(empty, L"file:///C:/%E7%A8%8B/a.html", none),
        "bridge default: a program directory with Chinese characters matches the percent-encoded UTF-8 file URL");
  {
    Guard g(GLock());
    G().appDir = L"\\\\srv\\apps\\demo";
  }
  Check(OriginAllowed(empty, L"file://srv/apps/demo/ui.html", none) && !OriginAllowed(empty, L"file://srv/apps/other/ui.html", none) &&
            !OriginAllowed(empty, L"file:///C:/apps/demo/ui.html", none),
        "bridge default: a program run from a network share trusts only its own folder on that share");
  {
    Guard g(GLock());
    G().appDir = savedAppDir;
  }
  std::vector<std::wstring> localDir{L"file:///D:/ui"};
  Check(OriginAllowed(localDir, L"file:///D:/ui/index.html", none) && OriginAllowed(localDir, L"file:///d:/UI/sub/a.html", none) &&
            !OriginAllowed(localDir, L"file:///D:/uix/a.html", none) && !OriginAllowed(localDir, L"file:///D:/other/a.html", none),
        "bridge whitelist: a local folder listed as file:///D:/ui allows the pages inside it only");
  Check(PathFromFileUrl(L"file:///C:/a%20b/%E4%B8%AD.html") == L"C:\\a b\\\x4E2D.html" && PathFromFileUrl(L"file://server/share/x.html") == L"\\\\server\\share\\x.html" &&
            PathFromFileUrl(L"FILE:///C|/x") == L"C:\\x" && PathFromFileUrl(L"https://a.test/") == L"" && PathFromFileUrl(L"file:///C:/a/%00") == L"" &&
            PathUnder(L"C:\\App\\x", L"c:\\app\\") && PathUnder(L"C:\\app", L"C:\\app") && !PathUnder(L"C:\\app2", L"C:\\app") && PathUnder(L"C:\\x", L"C:\\"),
        "file URL to path: percent-decoding as UTF-8, network shares, drive bars; folder check only at separators");
  Check(!OriginAllowed(empty, L"https://www.baidu.com/", none) && !OriginAllowed(empty, L"http://app.example/", none) && !OriginAllowed(empty, L"https://example/", none) &&
            !OriginAllowed(empty, L"https://evil.com/?.example", none) && !OriginAllowed(empty, L"https://x.example@evil.com/", none) &&
            !OriginAllowed(empty, L"https://example.com/", none) && !OriginAllowed(empty, L"http://assets.local.evil.com/", mapped) && !OriginAllowed(empty, L"about:blank", none),
        "bridge default: real sites, plain http on reserved names and look-alikes are rejected");
  Check(OriginAllowed(star, L"https://www.baidu.com/", none), "bridge whitelist * allows every origin");
  // ---- JSON 重复的键
  JVal j;
  Check(JsonParse(L"{\"a\":1,\"b\":{\"c\":2},\"a\":3}", j) && j.Get(L"a") && j.Get(L"a")->Dump() == L"3", "JSON: a duplicated key takes the last value");
  // ---- 交给窗口的任务的编号表
  std::function<void()> f1 = [] {};
  auto* f2 = new std::function<void()>([] {});
  const LPARAM a = TaskToken(&f1, false), b = TaskToken(f2, true);
  Check(TakeTask(a, true) == nullptr && TakeTask(b, false) == nullptr, "TakeTask: a token is only taken back by the message of its own kind");
  Check(TakeTask(a, false) == &f1 && TakeTask(a, false) == nullptr, "TakeTask: a token can be taken back only once");
  Check(TakeTask((LPARAM)0x41414141, true) == nullptr && TakeTask(0, false) == nullptr, "TakeTask: numbers that were never handed out are ignored");
  delete TakeTask(b, true);
  // ---- 1.8.0：固定版运行时的两条微软要求——不能放在网络位置；Windows 10 上 120 及以上版本要给 AppContainer 读取与执行权限
  Check(NetworkRuntimePath(L"\\\\srv\\share\\rt") && NetworkRuntimePath(L"//srv/share/rt") && NetworkRuntimePath(L"\\\\?\\UNC\\srv\\share\\rt") &&
            !NetworkRuntimePath(L"\\\\?\\C:\\rt") && !NetworkRuntimePath(L"\\\\.\\C:\\rt") && !NetworkRuntimePath(L"C:\\rt") && !NetworkRuntimePath(L"rt"),
        "fixed runtimes on network locations (UNC, \\\\?\\UNC) are recognized; local paths are not");
  {
    InitOs();  // DLL 载入时由 DllMain 判定系统版本；本测试直接编进源码，没有经过 DllMain，要自己调用（否则按 0.0 版处理，这一步直接跳过）
    Check(Os().major == 10 && Os().build < 22000, "white-box tests see the Windows 10 version the suite configured", std::to_wstring(Os().major) + L"." + std::to_wstring(Os().build));
    wchar_t tp[MAX_PATH] = {0};
    GetTempPathW(MAX_PATH, tp);
    RuntimeCandidate c;
    c.kind = 1;
    c.major = 120;
    c.dir = std::wstring(tp) + L"wvacl_test";
    CreateDirectoryW(c.dir.c_str(), nullptr);
    std::wstring why;
    const bool ok120 = EnsureFixedRuntimeAcl(c, why);
    c.major = 109;
    c.dir += L"_109";
    std::wstring why109;
    Check(ok120 && why.empty() && EnsureFixedRuntimeAcl(c, why109) && why109.empty(),
          "fixed runtime ACL step: granted (or already present) for 120+, nothing to do for 109", why);
    // 加不上权限时（例如运行时放在只有管理员能改的位置）：不交给运行时客户端，原因里给出微软文档的两条 icacls 命令
    auto oldSet = g_setNamedSecurity;
    g_setNamedSecurity = FailSetSecurity;
    c.major = 121;
    c.dir = std::wstring(tp) + L"wvacl_fail";
    CreateDirectoryW(c.dir.c_str(), nullptr);
    std::wstring whyFail;
    const bool okFail = EnsureFixedRuntimeAcl(c, whyFail);
    g_setNamedSecurity = oldSet;
    Check(!okFail && whyFail.find(L"*S-1-15-2-2:(OI)(CI)(RX)") != std::wstring::npos && whyFail.find(L"*S-1-15-2-1:(OI)(CI)(RX)") != std::wstring::npos &&
              whyFail.find(c.dir) != std::wstring::npos,
          "when the permission cannot be granted, the reason names the folder and gives Microsoft's two icacls commands", whyFail);
    // 运行时目录指到常青版装好的文件夹（按固定版使用）：权限由微软的安装程序设好，不去改，也不因“改不了”而拦下
    Check(InstalledRuntimeFolder(L"C:\\Program Files (x86)\\Microsoft\\EdgeWebView\\Application\\120.0.2210.91") &&
              InstalledRuntimeFolder(L"C:\\Users\\a\\AppData\\Local\\Microsoft\\EdgeWebView\\Application\\121.0.1.1") &&
              InstalledRuntimeFolder(L"C:\\Program Files (x86)\\Microsoft\\Edge Beta\\Application\\122.0.1.1") &&
              !InstalledRuntimeFolder(L"E:\\xddck\\fanxing\\WebView2\\120.0.2210.91") && !InstalledRuntimeFolder(L"D:\\app\\WebView2\\Microsoft.WebView2.FixedVersionRuntime.120.0.2210.91.x86"),
          "Evergreen and Edge channel install folders are recognized; app-bundled fixed runtimes are not");
    g_setNamedSecurity = FailSetSecurity;
    c.dir = std::wstring(tp) + L"wvacl_ev\\Microsoft\\EdgeWebView\\Application\\121.0.1.1";
    SHCreateDirectoryExW(nullptr, c.dir.c_str(), nullptr);
    std::wstring whyEv;
    const bool okEv = EnsureFixedRuntimeAcl(c, whyEv);
    g_setNamedSecurity = oldSet;
    Check(okEv && whyEv.empty(), "an Evergreen install folder used as the runtime folder is left alone (no permission change, not blocked)", whyEv);
  }
  // ---- 1.8.0：微软当前的在线安装程序在缺 PackageIdFromFullName 的系统上启动不了：Windows 7 改用微软更新目录里的 109 版离线安装包，
  // 更早的系统不下载、不运行，直接说明，也不记冷却
  {
    RegDeleteKeyW(HKEY_CURRENT_USER, L"Software\\WebView2Bridge");
    const OsInfo realOs = g_os;
    g_onlineInstallerOverride = 0;
    g_os.major = 6;
    g_os.minor = 0;  // Vista
    const bool refused = !StartRuntimeInstall(false);
    const std::wstring msg = LastInstallError();
    HKEY k = nullptr;
    const bool noCooldown = RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\WebView2Bridge", 0, KEY_READ, &k) != ERROR_SUCCESS;
    if (k) RegCloseKey(k);
    Check(refused && msg.find(L"PackageIdFromFullName") != std::wstring::npos && noCooldown && !g_job,
          "where neither Microsoft's online installer nor the 109 offline package can run (Vista), nothing is downloaded or run and the reason is given", msg);
    g_os.minor = 1;  // Windows 7
    const bool w7 = UseLegacyOfflinePackage();
    g_onlineInstallerOverride = 1;
    g_os.minor = 3;  // Windows 8.1（有 PackageIdFromFullName）：同样用离线安装包
    const bool w81 = UseLegacyOfflinePackage();
    g_os.major = 10;
    g_os.minor = 0;
    const bool w10 = UseLegacyOfflinePackage();
    g_os.major = 6;
    g_os.minor = 1;
    g_onlineInstallerOverride = 0;
    Check(w7 && w81 && !w10, "Windows 7/8/8.1 use the 109 offline package; Windows 10 keeps Microsoft's online installer");
    const std::wstring c1 = LegacyPackageCommand(L"C:\\t\\p.exe", true), c2 = LegacyPackageCommand(L"C:\\t\\p.exe", false);
    Check(c1 == L"\"C:\\t\\p.exe\" /silent /installsource windowsupdate /install \"appguid={F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}&needsadmin=true\"" &&
              c2.find(L"needsadmin=prefers\"") != std::wstring::npos,
          "offline package command line: silent, WebView2 app id, machine-wide when elevated", c1 + L" | " + c2);
    // 不联网：换成写入一个小文件的“下载”。大小与 SHA-1 对不上：停止安装、删掉临时文件，下载地址是微软更新目录登记的那个
    g_testDownload = FakeDownload;
    const bool started = StartRuntimeInstall(false);
    for (DWORD t0 = GetTickCount(); g_job && !ReadShared(g_job->done) && GetTickCount() - t0 < 20000;) Sleep(20);
    const std::wstring vmsg = LastInstallError();
    g_testDownload = nullptr;
    Check(started && g_fakeUrl.find(L"catalog.s.download.windowsupdate.com/c/msdownload/update/software/updt/2023/09/microsoftedgestandaloneinstallerx86_179f59bc54d73843d9288a9fd5609de0e507b911.exe") != std::wstring::npos &&
              vmsg.find(L"\u4E0D\u4E00\u81F4") != std::wstring::npos && !g_fakeFile.empty() && GetFileAttributesW(g_fakeFile.c_str()) == INVALID_FILE_ATTRIBUTES,
          "Windows 7: the offline package comes from the Microsoft Update Catalog; a file that does not match its size and SHA-1 is rejected and removed", vmsg);
    // HTTPS 打不开时改用同一地址的 HTTP（文件照样按大小、SHA-1 与签名校验）
    g_fakeUrls.clear();
    g_fakeFailHttps = true;
    g_testDownload = FakeDownload;
    RegDeleteKeyW(HKEY_CURRENT_USER, L"Software\\WebView2Bridge");
    const bool started2 = StartRuntimeInstall(false);
    for (DWORD t0 = GetTickCount(); g_job && !ReadShared(g_job->done) && GetTickCount() - t0 < 20000;) Sleep(20);
    g_testDownload = nullptr;
    g_fakeFailHttps = false;
    Check(started2 && g_fakeUrls.find(L"https://catalog.s.download.windowsupdate.com/") == 0 &&
              g_fakeUrls.find(L"\nhttp://catalog.s.download.windowsupdate.com/c/msdownload/update/software/updt/2023/09/microsoftedgestandaloneinstallerx86_179f59bc54d73843d9288a9fd5609de0e507b911.exe") != std::wstring::npos &&
              LastInstallError().find(L"\u4E0D\u4E00\u81F4") != std::wstring::npos,
          "when HTTPS cannot be used the same catalog address is tried over HTTP, and the file is still checked", g_fakeUrls);
    g_onlineInstallerOverride = -1;
    g_os = realOs;
    RegDeleteKeyW(HKEY_CURRENT_USER, L"Software\\WebView2Bridge");  // 这次失败记下的冷却
    // SHA-1：标准测试向量 "abc"
    wchar_t tp[MAX_PATH] = {0};
    GetTempPathW(MAX_PATH, tp);
    const std::wstring hf = std::wstring(tp) + L"wvsha1_abc.txt";
    HANDLE w = CreateFileW(hf.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
    DWORD wr = 0;
    if (w != INVALID_HANDLE_VALUE) { WriteFile(w, "abc", 3, &wr, nullptr); CloseHandle(w); }
    HANDLE r = CreateFileW(hf.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
    const std::wstring sha = r != INVALID_HANDLE_VALUE ? Sha1OfHandle(r) : std::wstring();
    if (r != INVALID_HANDLE_VALUE) CloseHandle(r);
    Check(sha == L"a9993e364706816aba3e25717850c26c9cd0d89d", "SHA-1 of the downloaded file is computed correctly (test vector)", sha);
    std::wstring spaceWhy;
    const bool enough = EnoughSpaceFor(std::wstring(tp), 1ull << 20, spaceWhy), tooMuch = EnoughSpaceFor(std::wstring(tp), 1ull << 60, spaceWhy);
    Check(enough && !tooMuch && spaceWhy.find(L"MB") != std::wstring::npos, "the offline package checks free disk space before a 132MB download", spaceWhy);
    Check(DownloadErrorText((HRESULT)0x800C000E).find(L"TLS 1.2") != std::wstring::npos && DownloadErrorText((HRESULT)0x800C0008).find(L"(0x800C0008)") == std::wstring::npos &&
              DownloadErrorText((HRESULT)0x800C0008).find(L"0x800C0008") != std::wstring::npos && DownloadErrorText((HRESULT)0x80070005) == HrText((HRESULT)0x80070005),
          "download errors (urlmon INET_E_*) get a readable explanation with the code; other errors use the system text", DownloadErrorText((HRESULT)0x800C000E));
    HMODULE kernel = GetModuleHandleW(L"kernel32.dll");
    Check(OnlineInstallerSupported() == (GetProcAddress(kernel, "PackageIdFromFullName") != nullptr), "the check follows whether the system has PackageIdFromFullName");
  }
  // ---- 1.8.0：安装失败（包括装完仍没有可用的运行时）记在 HKCU，程序自动发起的安装 24 小时内直接失败并说明上次的原因
  {
    RegDeleteKeyW(HKEY_CURRENT_USER, L"Software\\WebView2Bridge");
    RecordInstallFailure(L"helpertest-reason");
    const bool refused = !StartRuntimeInstall(true);
    const std::wstring msg = LastInstallError();
    RegDeleteKeyW(HKEY_CURRENT_USER, L"Software\\WebView2Bridge");
    Check(refused && msg.find(L"helpertest-reason") != std::wstring::npos && msg.find(L"24") != std::wstring::npos,
          "a recorded install failure makes the next automatic install return at once with the earlier reason", msg);
  }
  // ---- 1.8.0：微软安装程序用当前用户的默认环境启动（不继承本程序改过的 PATH 等）；安装失败时取微软安装程序日志的最后几行
  {
    SetEnvironmentVariableW(L"WV_HELPERTEST_MARK", L"inherited");
    void* env = CleanEnvBlock();
    bool hasMark = false, hasVars = false;
    for (const wchar_t* e = static_cast<const wchar_t*>(env); e && *e; e += wcslen(e) + 1) {
      hasVars = true;
      if (_wcsnicmp(e, L"WV_HELPERTEST_MARK=", 19) == 0) hasMark = true;
    }
    FreeEnvBlock(env);
    SetEnvironmentVariableW(L"WV_HELPERTEST_MARK", nullptr);
    Check(env && hasVars && !hasMark, "the installer gets the user's default environment, not variables this process changed");
    BOOL inJob = FALSE;
    IsProcessInJob(GetCurrentProcess(), nullptr, &inJob);
    Check(!inJob ? !BreakawayAllowed() : true, "breakaway from a job is only requested when the process is in one");
    wchar_t tp[MAX_PATH] = {0};
    GetTempPathW(MAX_PATH, tp);
    // 实际的 MicrosoftEdgeUpdate.log 是带 BOM 的 UTF-16（小端）文本，里面有多年的记录：只取启动安装程序之后新写的行
    const std::wstring pd = std::wstring(tp) + L"wvlog_pd", logDir = pd + L"\\Microsoft\\EdgeUpdate\\Log", logFile = logDir + L"\\MicrosoftEdgeUpdate.log";
    SHCreateDirectoryExW(nullptr, logDir.c_str(), nullptr);
    auto putLog = [&](const std::wstring& text, bool append) {
      HANDLE lf = CreateFileW(logFile.c_str(), append ? FILE_APPEND_DATA : GENERIC_WRITE, 0, nullptr, append ? OPEN_ALWAYS : CREATE_ALWAYS, 0, nullptr);
      if (lf == INVALID_HANDLE_VALUE) return;
      DWORD wr = 0;
      if (!append) WriteFile(lf, "\xFF\xFE", 2, &wr, nullptr);
      WriteFile(lf, text.data(), (DWORD)(text.size() * sizeof(wchar_t)), &wr, nullptr);
      CloseHandle(lf);
    };
    std::wstring old;
    for (int i = 0; i < 3000; ++i) old += L"[05/27/24 12:00:00.000][MicrosoftEdgeUpdate:msedgeupdate][1:2][old line " + std::to_wstring(i) + L"]\r\n";
    putLog(old, false);
    wchar_t oldPd[MAX_PATH] = {0}, oldLa[MAX_PATH] = {0};
    GetEnvironmentVariableW(L"ProgramData", oldPd, MAX_PATH);
    GetEnvironmentVariableW(L"LOCALAPPDATA", oldLa, MAX_PATH);
    SetEnvironmentVariableW(L"ProgramData", pd.c_str());
    SetEnvironmentVariableW(L"LOCALAPPDATA", (std::wstring(tp) + L"wvlog_none").c_str());
    const EdgeUpdateLogMark m1 = MarkEdgeUpdateLog();
    const std::wstring none = EdgeUpdateLogSince(m1, 5);  // 安装程序一行都没写（在启动早期就失败了）
    std::wstring fresh;
    for (int i = 0; i < 8; ++i) fresh += L"[10/23/26 14:03:0" + std::to_wstring(i) + L".000][MicrosoftEdgeUpdate:msedgeupdate][3:4][new line " + std::to_wstring(i) + L" \u5B89\u88C5]\r\n";
    fresh += L"[10/23/26 14:03:12.000][MicrosoftEdgeUpdate:msedgeupdate][3:4][InstallApp returned][0x8007007f]\r\n";
    putLog(fresh, true);
    const std::wstring tail = EdgeUpdateLogSince(m1, 5);
    SetEnvironmentVariableW(L"ProgramData", oldPd[0] ? oldPd : nullptr);
    SetEnvironmentVariableW(L"LOCALAPPDATA", oldLa[0] ? oldLa : nullptr);
    size_t nLines = 0;
    for (size_t at = tail.find(L"\r\n"); at != std::wstring::npos; at = tail.find(L"\r\n", at + 2)) ++nLines;
    Check(none.empty(), "nothing written by the installer since it started: no log lines (an early failure), old history is not shown", none);
    Check(nLines == 5 && tail.find(L"0x8007007f") != std::wstring::npos && tail.find(L"new line 7 \u5B89\u88C5") != std::wstring::npos && tail.find(L"old line") == std::wstring::npos,
          "the installer log (UTF-16 with BOM, as on Windows) yields only this install's last lines", tail);
  }
  // ---- 一键安装：校验期间持有不可写的句柄
  {
    wchar_t exe[MAX_PATH] = {0};
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    std::wstring copy = PathJoin(TempDir(), L"wv2_helpertest_unsigned.exe");
    CopyFileW(exe, copy.c_str(), FALSE);
    HANDLE lock = CreateFileW(copy.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    HANDLE w = CreateFileW(copy.c_str(), GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
    const DWORD we = w == INVALID_HANDLE_VALUE ? GetLastError() : 0;
    if (w != INVALID_HANDLE_VALUE) CloseHandle(w);
    std::wstring why;
    const bool ok = VerifySignature(copy, lock, why);
    if (lock != INVALID_HANDLE_VALUE) CloseHandle(lock);
    Check(lock != INVALID_HANDLE_VALUE && we == ERROR_SHARING_VIOLATION, "install: while the bootstrapper is held for verification nobody can open it for writing", Fmt(L"%lu", we));
    Check(!ok && !why.empty(), "install: an unsigned file fails the signature check with a reason", why);
    Check(DeleteFileW(copy.c_str()) != 0, "install: the file can be deleted once the handle is closed");
  }
  // ---- 一键安装：持有只读句柄时仍能启动这个程序。安装线程就是这样做的：从校验到启动一直持有，启动之后才关闭；
  // 当前目录设为引导程序自己所在的专用子目录。这里用本测试程序的副本当作引导程序
  {
    wchar_t exe[MAX_PATH] = {0};
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    std::wstring dir = PathJoin(TempDir(), L"wv2_helpertest_run");
    CreateDirectoryW(dir.c_str(), nullptr);
    std::wstring copy = PathJoin(dir, L"wv2_helpertest_child.exe");
    CopyFileW(exe, copy.c_str(), FALSE);
    HANDLE lock = CreateFileW(copy.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    std::wstring cmd = L"\"" + copy + L"\" --exit7";
    std::vector<wchar_t> buf(cmd.begin(), cmd.end());
    buf.push_back(0);
    STARTUPINFOW si;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi;
    ZeroMemory(&pi, sizeof(pi));
    const BOOL started = CreateProcessW(copy.c_str(), buf.data(), nullptr, nullptr, FALSE, 0, nullptr, dir.c_str(), &si, &pi);  // 与安装线程相同的参数
    const DWORD se = started ? 0 : GetLastError();
    if (lock != INVALID_HANDLE_VALUE) CloseHandle(lock);
    DWORD code = 0;
    if (started) {
      WaitForSingleObject(pi.hProcess, 20000);
      GetExitCodeProcess(pi.hProcess, &code);
      CloseHandle(pi.hThread);
      CloseHandle(pi.hProcess);
    }
    DeleteFileW(copy.c_str());
    RemoveDirectoryW(dir.c_str());
    Check(lock != INVALID_HANDLE_VALUE && started && code == 7, "install: the bootstrapper still starts while the read-only handle is held",
          Fmt(L"%d/%lu/%lu", (int)started, se, code));
  }
  // ---- 1.5.0：回调保护调用桩：多写的“参考”参数写进清零槽位，不会写到调用方的栈或别的内存；弹栈字节数反映回调声明的参数个数
  {
    static unsigned char scratch[kSafeCallPad * 16];
    struct Case {
      void* fn;
      int expPopped, expRet, expFlag;
      const char* name;
    } cs[] = {{(void*)HtCb4, 16, 15, 1, "4"}, {(void*)HtCb2, 8, 10, 0, "2"}, {(void*)HtCb6, 24, 15, 1, "6"}, {(void*)HtCbC, 0, 15, 1, "cdecl"}};
    bool allOk = true;
    std::wstring got;
    for (auto& c : cs) {
      memset(scratch, 0, sizeof scratch);
      g_cbFlag = 0;
      strcpy(g_cbSeen, "x");
      g_regsOk = 0;
      int popped = -1;
      intptr_t args[4] = {7, (intptr_t)"abc", 5, (intptr_t)&g_cbFlag};
      const int r = HtProbe(c.fn, args, 4, kSafeCallPad, scratch, &popped);
      bool ok = r == c.expRet && popped == c.expPopped && g_regsOk && g_cbFlag == c.expFlag;
      if (c.fn == (void*)HtCb6) ok = ok && g_cbSeen[0] == 0 && *(unsigned*)scratch == 0x41414141u;  // 多写的文本参数是空文本，“参考”参数写进第一个槽位
      if (!ok) {
        allOk = false;
        got += FromAnsi(c.name) + L":" + std::to_wstring(r) + L"/" + std::to_wstring(popped) + L"/" + std::to_wstring(g_regsOk) + L" ";
      }
    }
    Check(allOk, "SafeCall thunk: callbacks declaring 4, 2 or 6 parameters and cdecl callbacks keep the caller's registers; extra by-ref parameters land in zeroed slots; popped bytes reveal the declared count", got);
    int pp = -1;
    intptr_t a2[2] = {1, (intptr_t)"x"};
    Check(SafeCall(nullptr, a2, 2, &pp) == 0 && pp == 0, "SafeCall: a null callback returns 0 and reports 0 popped bytes");
    // FireFn 发现参数表写错：同一回调同一事件只报一次，说明里有事件名与应有的参数表；参数表正确的回调不报
    DevChecks() = 1;
    g_devNoticeHook = CaptureNotice;
    View* fv = new View(424242);
    fv->FireFn((void*)HtCb6, WVE_TITLE_CHANGED, {(intptr_t)424242, (intptr_t)"t"}, nullptr);
    fv->FireFn((void*)HtCb6, WVE_TITLE_CHANGED, {(intptr_t)424242, (intptr_t)"t"}, nullptr);
    fv->FireFn((void*)HtCb2, WVE_TITLE_CHANGED, {(intptr_t)424242, (intptr_t)"t"}, nullptr);
    const std::wstring st = CheckStatsJson();
    const std::wstring n0 = g_notices.empty() ? std::wstring() : g_notices[0];
    Check(g_notices.size() == 1 && n0.find(L"事件“标题改变”") != std::wstring::npos && n0.find(L"应为 2 个参数（浏览器句柄, 标题）") != std::wstring::npos &&
              n0.find(L"共 24 字节") != std::wstring::npos && st.find(L"{\"event\":5,\"declaredBytes\":24,\"expected\":2}") != std::wstring::npos,
          "FireFn: a callback declaring too many parameters is reported once, naming the event and the expected parameter list", n0 + L" | " + st);
    DevChecks() = 2;
    fv->FireFn((void*)HtCb4, WVE_SOURCE_CHANGED, {(intptr_t)424242, (intptr_t)"u"}, nullptr);
    Check(g_notices.size() == 1 && CheckStatsJson().find(L"{\"event\":4,\"declaredBytes\":16,\"expected\":2}") != std::wstring::npos,
          "dev checks 2: a mismatch is recorded in diagnostics without showing a dialog", CheckStatsJson());
    fv->Release();
    DevChecks() = 0;
    g_devNoticeHook = nullptr;
  }
  // ---- 1.5.0：开发期检查：UTF-8 代码页下不合法的 UTF-8 让调用失败；关闭时照旧按 ANSI 解释并计数；合法但按 GBK 看全是汉字的文本只计数
  {
    CodePageVar() = 65001;
    DevChecks() = 2;
    bool threw = false;
    try {
      FromCP("\xC4\xE3\xBA\xC3");  // GBK 的“你好”
    } catch (const EncodingError&) {
      threw = true;
    }
    std::wstring sample;
    const bool took = TakeEncodingError(sample), tookAgain = TakeEncodingError(sample);
    Check(threw && took && !tookAgain && sample == L"\x4F60\x597D", "dev checks: invalid UTF-8 throws and keeps the text as read in the ANSI code page", sample);
    DevChecks() = 0;
    const long fb0 = StatNum(L"encodingFallback"), su0 = StatNum(L"encodingSuspect");
    const std::wstring fb = FromCP("\xC4\xE3\xBA\xC3");
    const std::wstring ok8 = FromCP("\xE4\xBD\xA0\xE5\xA5\xBD");  // 正常的 UTF-8“你好”
    const long fb1 = StatNum(L"encodingFallback"), su1 = StatNum(L"encodingSuspect");
    Check(fb == L"\x4F60\x597D" && ok8 == L"\x4F60\x597D" && fb1 == fb0 + 1 && su1 == su0,
          "dev checks off: invalid UTF-8 is read as ANSI and counted; valid UTF-8 Chinese is not counted", std::to_wstring(fb1 - fb0) + L"/" + std::to_wstring(su1 - su0));
    const std::wstring sus = FromCP("\xC2\xB7");     // GBK 的“路”恰好是合法 UTF-8（·）
    const std::wstring lat = FromCP("caf\xC3\xA9");  // 西文 café 也符合疑似条件：只计数，不改变结果
    const long su2 = StatNum(L"encodingSuspect");
    Check(sus == L"\x00B7" && lat == L"caf\x00E9" && su2 == su1 + 2, "valid UTF-8 that reads as GBK Chinese is counted as suspect and still decoded as UTF-8",
          std::to_wstring(su2 - su1));
    CodePageVar() = 0;
  }
  // ---- 1.5.0：同步等待嵌套上限
  {
    ClearErr();
    WaitDepth() = kMaxWaitDepth - 1;
    const bool under = CanWait();
    WaitDepth() = kMaxWaitDepth;
    const bool over = CanWait();
    const int ec = ErrCode();
    WaitDepth() = 0;
    ClearErr();
    Check(under && !over && ec == WVERR_REENTRANT, "CanWait refuses another synchronous wait once 16 are nested");
  }
  // ---- 1.5.0：官方加载器的覆盖规则（读取）：数据目录与附加参数也认组策略；有任何 WEBVIEW2_ 环境变量时不看组策略
  {
    const std::wstring sub = L"Software\\Policies\\Microsoft\\Edge\\WebView2\\";
    for (const wchar_t* kv : {L"UserDataFolder|D:\\pol\\data", L"AdditionalBrowserArguments|--policy-flag"}) {
      const std::wstring t = kv;
      const size_t bar = t.find(L'|');
      HKEY k = nullptr;
      if (RegCreateKeyExW(HKEY_CURRENT_USER, (sub + t.substr(0, bar)).c_str(), 0, nullptr, 0, KEY_WRITE | KEY_WOW64_64KEY, nullptr, &k, nullptr) == ERROR_SUCCESS) {
        const std::wstring val = t.substr(bar + 1);
        RegSetValueExW(k, L"*", 0, REG_SZ, reinterpret_cast<const BYTE*>(val.c_str()), (DWORD)((val.size() + 1) * sizeof(wchar_t)));
        RegCloseKey(k);
      }
    }
    const LoaderOverrides a = ReadLoaderOverrides();
    SetEnvironmentVariableW(L"WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", L"--env-flag");
    const LoaderOverrides b = ReadLoaderOverrides();
    SetEnvironmentVariableW(L"WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", nullptr);
    HKEY k = nullptr;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Policies\\Microsoft", 0, KEY_ALL_ACCESS | KEY_WOW64_64KEY, &k) == ERROR_SUCCESS) {
      RegDeleteTreeW(k, L"Edge");
      RegCloseKey(k);
    }
    Check(a.userDataFolder == L"D:\\pol\\data" && a.extraArgs == L"--policy-flag" && a.source.find(L"HKCU") != std::wstring::npos && b.extraArgs == L"--env-flag" &&
              b.userDataFolder.empty() && b.source == L"环境变量",
          "loader overrides: user data folder and extra arguments come from policies; any WEBVIEW2_ variable takes precedence over all policies", a.source + L" | " + b.source);
  }
  // ---- 1.5.2：开发期检查让 WV_EvSetResponse 转换文本失败时，不留下设了一半的应答
  {
    CodePageVar() = 65001;
    DevChecks() = 2;
    EventCtx rc;
    rc.type = WVE_REQUEST;
    PushCtx(&rc);
    const int bad = WV_EvSetResponse(201, "\xC4\xE3\xBA\xC3", "Content-Type: text/plain", "x", 1);  // 原因短语是 GBK 文本
    const int badErr = WV_LastErrorCode();
    const bool untouched = !rc.hasResp && rc.respStatus == 200 && rc.respBody.empty() && rc.respHeaders.empty();
    const int good = WV_EvSetResponse(201, "OK", "Content-Type: text/plain", "hi\0", 3);
    PopCtx();
    DevChecks() = 0;
    CodePageVar() = 0;
    Check(bad == 0 && badErr == WVERR_ENCODING && untouched && good == 1 && rc.hasResp && rc.respStatus == 201 && rc.respReason == L"OK" &&
              rc.respHeaders == L"Content-Type: text/plain" && rc.respBody.size() == 2,
          "WV_EvSetResponse: a call failing on invalid UTF-8 leaves no half-set response; a valid call sets status, reason, headers and the trimmed text body");
  }
  // ---- 1.5.2：疑似检查只看非 ASCII 字符不超过 16 个的文本：长段俄文这类正常的 UTF-8 文本不再计为疑似
  {
    CodePageVar() = 65001;
    const long s0 = StatNum(L"encodingSuspect");
    std::string ru;
    for (int k = 0; k < 20; ++k) ru += "\xD0\xB0";  // 20 个西里尔字母（按 GBK 看全是汉字）
    const std::wstring w = FromCP(ru.c_str());
    const long s1 = StatNum(L"encodingSuspect");
    const std::wstring dot = FromCP("\xC2\xB7");  // GBK 的“路”：仍计为疑似
    const long s2 = StatNum(L"encodingSuspect");
    CodePageVar() = 0;
    Check(w.size() == 20 && w[0] == 0x430 && s1 == s0 && dot == L"\x00B7" && s2 == s1 + 1,
          "suspect check skips texts with more than 16 non-ASCII characters (long Cyrillic text) and still flags a short one",
          std::to_wstring(s1 - s0) + L"/" + std::to_wstring(s2 - s1));
  }
  // ---- 1.5.0：回调转发（WVO_CALLBACK_HOOK）的参数表同样检查：转发子程序应有 5 个参数
  {
    G().callbackHook = (void*)HtHook4;
    View* hv = new View(434343);
    hv->FireFn((void*)HtCb2, WVE_TITLE_CHANGED, {(intptr_t)434343, (intptr_t)"t"}, nullptr);
    G().callbackHook = nullptr;
    hv->Release();
    const std::wstring st = CheckStatsJson();
    Check(st.find(L"{\"event\":-1,\"declaredBytes\":16,\"expected\":5}") != std::wstring::npos,
          "the callback forwarder (WVO_CALLBACK_HOOK) is checked too: a forwarder declaring 4 parameters is reported against the expected 5", st);
  }
  // ---- 1.5.2：多写的“参考”参数整段写入超过一个槽位（16 字节）时，写入仍落在调用桩准备的清零内存里，不破坏调用方的栈帧
  {
    const intptr_t a4[4] = {1, 2, 3, 4};
    int popped = 0;
    volatile int before = 0x11223344;
    const int r = SafeCall((void*)HtBigRef, a4, 4, &popped);
    volatile int after = 0x55667788;
    Check(r == 10 && popped == 80 && before == 0x11223344 && after == 0x55667788,
          "an extra by-reference parameter written beyond its 16-byte slot (600 bytes into the 16th extra) stays inside the thunk's zeroed area",
          std::to_wstring(r) + L"/" + std::to_wstring(popped));
  }
  // ---- 1.6.0：创建选项里同一函数名写了多行时以最后一行为准，回调地址为 0 表示解绑
  {
    View* ov = new View(454545);
    ParseOptions(ov, L"bind:keep=1234\r\nbind:gone=5678\r\nbind:gone=0\r\nbind:re=0\r\nbind:re=4321");
    Check(ov->binds.count(L"keep") == 1 && ov->binds.count(L"gone") == 0 && ov->binds.count(L"re") == 1 && ov->binds[L"re"] == (void*)(uintptr_t)4321,
          "options: a later bind:name=0 line removes the earlier binding, a later address replaces it");
    ov->Release();
  }
  // ---- 1.6.0：文本属性在创建前（创建选项）与创建后（WV_SetStr）按同一规则规整：删回车、换行换成空格、去掉首尾空白
  {
    View* a = new View(464646);
    View* b = new View(474747);
    // 易语言类在创建前把设置写成一行：回车删掉、换行换成空格（选项文本里看到的就是这样），DLL 解析时去首尾空白
    ParseOptions(a, L"s100=  UA x Y  \r\ns109= *ads* *.gif \r\ns105=https://a.test https://b.test");
    b->SetStrProp(WVS_USER_AGENT, L"  UA x\r\nY  ");
    b->SetStrProp(WVS_BLOCK_URLS, L" *ads*\r\n*.gif ");
    b->SetStrProp(WVS_BRIDGE_ORIGINS, L"https://a.test\r\nhttps://b.test");
    Check(a->GetStrProp(WVS_USER_AGENT) == L"UA x Y" && b->GetStrProp(WVS_USER_AGENT) == L"UA x Y",
          "string property: the same text set before or after creation ends up the same (CR dropped, LF to space, trimmed)", b->GetStrProp(WVS_USER_AGENT));
    Check(a->blockUrls == b->blockUrls && b->blockUrls.size() == 2 && b->blockUrls[1] == L"*.gif",
          "block list: one pattern per line works before and after creation", std::to_wstring(b->blockUrls.size()));
    Check(a->bridgeOrigins == b->bridgeOrigins && b->bridgeOrigins.size() == 2 && OriginAllowed(b->bridgeOrigins, L"https://b.test/x", none) &&
          !OriginAllowed(b->bridgeOrigins, L"https://c.test/", none),
          "bridge whitelist: one origin per line works before and after creation", std::to_wstring(b->bridgeOrigins.size()));
    a->Release();
    b->Release();
  }
  // ---- 1.6.1：屏蔽快捷键也可以每行一项，加号两边的空格不算分隔
  {
    View* kv = new View(484848);
    kv->SetStrProp(WVS_BLOCK_KEYS, L"Ctrl + P\r\nF5  F12,Ctrl+Shift + I");
    const bool ok = kv->blockKeys.size() == 4 && kv->blockKeys.count((1u << 16) | (unsigned)'P') && kv->blockKeys.count(VK_F5) && kv->blockKeys.count(VK_F12) &&
                    kv->blockKeys.count((3u << 16) | (unsigned)'I') && !kv->blockKeys.count((unsigned)'P');
    Check(ok, "block keys: one per line, spaces around + ignored (\"Ctrl + P\" is Ctrl+P, not P)", std::to_wstring(kv->blockKeys.size()));
    kv->Release();
  }
  // ---- 1.6.4：JSON取值 的解析缓存放在全局表里（每个线程最近 4 段；合计 4 MB、最多 256 项，1.6.6 起一段最大也是 4 MB）。线程被强制结束（精易 线程_销毁）时
  // 原来缓存放在线程局部变量里，内存与额度都漏掉；现在之后没取到缓存时查出已结束线程的项、清掉并释放
  {
    WV_SetOption(WVO_CODEPAGE, "65001");
    g_jsonSweepMs = 0;  // 每次没取到缓存都查已结束的线程（DLL 里最多每秒一次），让下面的检查不必等待
    auto make = [](size_t bytes, char c) {
      std::string j = "[", item = std::string("\"") + c + "bcdefg\"";
      while (j.size() + 12 < bytes) j += (j.size() > 1 ? "," : "") + item;
      return j + "]";
    };
    JsonCacheTable& tab = JsonCaches();
    auto has = [&](DWORD tid, const std::string& raw) { Guard g(tab.lock); for (auto& sl : tab.slots) if (sl.tid == tid && sl.e->raw == raw) return true; return false; };
    auto mineCount = [&](DWORD tid) { Guard g(tab.lock); size_t n = 0; for (auto& sl : tab.slots) n += sl.tid == tid; return n; };
    auto total = [&]() { Guard g(tab.lock); return tab.total; };
    auto count = [&]() { Guard g(tab.lock); return tab.slots.size(); };
    const DWORD me = GetCurrentThreadId();
    JsonCacheDrop(me);  // 从空表开始（前面的测试可能已在本线程取过值）
    WV_JsonGet("[1]", "[0]");
    Check(has(me, "[1]") && count() == 1, "json cache: a small JSON is kept for this thread");
    const std::string dBig = make((4u << 20) + 200000, 'a');
    WV_JsonGet(dBig.c_str(), "[0]");
    Check(has(me, "[1]") && !has(me, dBig) && count() == 1, "json cache: a JSON over 4 MB is not cached (this thread keeps its previous entries)");
    // 先取出成员、再取它的字段：两段 JSON 交替传入，大段的那一段一直留在缓存里
    {
      const std::string arr = "[{\"id\":7},{\"id\":8},{\"id\":9}]";
      bool ok = true;
      for (int k = 0; k < 3; ++k) {
        const std::string item = WV_JsonGet(arr.c_str(), ("[" + std::to_string(k) + "]").c_str());
        ok = ok && std::string(WV_JsonGet(item.c_str(), "id")) == std::to_string(7 + k);
      }
      Check(ok && has(me, arr) && mineCount(me) == 4, "json cache: a thread keeps its last 4 JSON texts, so element-then-field lookups keep the big one",
            std::to_wstring(mineCount(me)));
    }
    JsonCacheDrop(me);
    // 六个线程各传约 1 MB 的 JSON：表里合计不超过 4 MB
    const std::string d1 = make(900000, 'b'), d2 = make(950000, 'c');
    std::atomic<int> phase{0};
    size_t inThreads = 0, slotsInThreads = 0;
    std::vector<std::thread> ts;
    for (int t = 0; t < 6; ++t)
      ts.emplace_back([&, t] { WV_JsonGet((t & 1 ? d2 : d1).c_str(), "[0]"); ++phase; while (phase.load() < 100) Sleep(5); });
    while (phase.load() < 6) Sleep(5);
    inThreads = total();
    slotsInThreads = count();
    phase = 100;
    for (auto& th : ts) th.join();
    Check(inThreads <= (4u << 20) && inThreads >= 900000 && slotsInThreads <= 6, "json cache: six threads with ~1 MB JSON stay within the 4 MB total",
          std::to_wstring(inThreads) + L" in " + std::to_wstring(slotsInThreads) + L" entries");
    // 线程结束后（这里是把 DLL 源码直接编进来的测试程序，没有 DLL_THREAD_DETACH），之后没取到缓存时清掉它们的项
    WV_JsonGet("[2]", "[0]");
    Check(count() == 1 && total() == 3 && has(me, "[2]"), "json cache: entries of threads that have ended are cleared on the next miss",
          std::to_wstring(count()) + L" entries, " + std::to_wstring(total()) + L" bytes");
    // 强制结束 4 个各自缓存了约 900 KB 的线程，再在本线程换一段 JSON：它们的项被清掉、内存释放，本线程照样能缓存大段 JSON
    auto heapUsed = []() { _HEAPINFO hi = {}; size_t used = 0; while (_heapwalk(&hi) == _HEAPOK) if (hi._useflag == _USEDENTRY) used += hi._size; return used; };
    const size_t heap0 = heapUsed();
    std::string docs[4] = {make(900000, 'd'), make(900000, 'e'), make(900000, 'f'), make(900000, 'g')};
    for (auto& d : docs) {
      KillArg a{&d, 0};
      HANDLE h = CreateThread(nullptr, 0, KillThread, &a, 0, nullptr);
      while (!a.ready) Sleep(5);
      TerminateThread(h, 1);
      WaitForSingleObject(h, INFINITE);
      CloseHandle(h);
    }
    // 每个线程缓存时都会清掉已结束线程的项，所以最多只留着最后一个被结束的线程的一项（原来 4 个全留着，约 36 MB）
    const size_t afterKill = count(), heapKilled = heapUsed();
    Check(afterKill == 2 && heapKilled < heap0 + 15 * (1u << 20), "json cache: threads killed with TerminateThread leave at most one entry behind",
          std::to_wstring(afterKill) + L" entries, heap +" + std::to_wstring((heapKilled - heap0) >> 20) + L" MB");
    WV_JsonGet("[3]", "[0]");
    const size_t heapAfter = heapUsed();
    Check(count() == 2 && total() == 6 && heapAfter + 5 * (1u << 20) < heapKilled, "json cache: the next miss clears the killed thread's entry and frees its memory",
          std::to_wstring(heapKilled >> 20) + L" MB -> " + std::to_wstring(heapAfter >> 20) + L" MB");
    const std::string mine = make(900000, 'h');
    WV_JsonGet(mine.c_str(), "[0]");
    Check(has(me, mine) && total() == 6 + mine.size(), "json cache: after killed threads this thread still caches a large JSON (no budget is lost)");
    JsonCacheDrop(me);
    Check(count() == 0 && total() == 0, "json cache: dropping a thread removes all of its entries");
    g_jsonSweepMs = 1000;
    WV_SetOption(WVO_CODEPAGE, "0");
  }
  // ---- 1.6.2：响应捕获的网址通配符与屏蔽网址一样，也可以用空格或换行分隔
  {
    View* rv = new View(494949);
    rv->SetResponseCapture(L"*/api/*\r\n*.json  *.xml;*.css", true);
    Check(rv->respRules.size() == 4 && rv->respRules[1].first == L"*.json" && rv->respRules[3].first == L"*.css" && rv->respRules[0].second,
          "response capture: patterns one per line or separated by spaces", std::to_wstring(rv->respRules.size()));
    rv->Release();
  }
  // ---- 1.6.3：创建选项逐行转换，一行漏了转换只影响这一行（中文的绑定函数名不受连累）
  {
    WV_SetOption(WVO_CODEPAGE, "65001");
    WV_SetOption(WVO_DEV_CHECKS, "0");
    const char* mixed = "bind:\xE5\x8A\xA0=1234\r\ns103=C:\\\xD6\xD0\r\nbind:b=99";  // 加（UTF-8）、C:\中（GBK）
    const std::wstring whole = FromCP(mixed), lines = FromCPLines(mixed);
    View* mv = new View(505050);
    ParseOptions(mv, lines);
    Check(whole.find(L"bind:\x52A0=") == std::wstring::npos && lines == L"bind:\x52A0=1234\r\ns103=C:\\\x4E2D\r\nbind:b=99" && mv->binds.count(L"\x52A0") == 1 &&
              mv->downloadDir == L"C:\\\x4E2D" && mv->binds.count(L"b") == 1,
          "options decoded line by line: the GBK line is read as ANSI alone, the UTF-8 bind name stays intact (whole-text decoding garbled it)", lines);
    mv->Release();
    Check(FromCPLines("a=1\n\nb=2\r") == L"a=1\n\nb=2\r" && FromCPLines("") == L"" && FromCPLines(nullptr) == L"", "options: line breaks are kept as they are");
    WV_SetOption(WVO_CODEPAGE, "0");
  }
  // ---- 1.7.0：有回填参数的事件。按 WVE_FLAG_NO_OUT 注册的回调应有的参数表不含最后的 int* 参数，用 WVK_CANCEL / WVK_RESULT 回填（1.7.8 起地址仍放在原来的位置，旧写法照样回填）；
  //      WVK_CANCEL 按事件换算（逻辑事件 1/0，对话框 0/1，整数选项事件取消为 2、不取消保持默认），WVK_RESULT 原样回填并优先；照旧多写这个参数时报告参数表不符
  {
    View* ev = new View(515151);
    auto fire = [&](int e, void* fn, bool noOut, int cancel, int result, int init) -> int {
      ev->SetEvent(e, fn, noOut);
      g_htSetCancel = cancel;
      g_htSetResult = result;
      int out = init;
      if (e == WVE_PERMISSION || e == WVE_NEW_WINDOW || e == WVE_CERT_ERROR) ev->Fire(e, {(intptr_t)515151, (intptr_t)"u", 0, (intptr_t)&out});
      else ev->Fire(e, {(intptr_t)515151, (intptr_t)"u", 0, 0, (intptr_t)&out});
      return out;
    };
    g_htCalls.clear();
    const int n1 = fire(WVE_NAV_STARTING, (void*)HtOut4, true, 1, -1000, 0), n0 = fire(WVE_NAV_STARTING, (void*)HtOut4, true, 0, -1000, 0),
              nr = fire(WVE_NAV_STARTING, (void*)HtOut4, true, 0, 7, 0), nn = fire(WVE_NAV_STARTING, (void*)HtOut4, true, -1, -1000, 0);
    Check(g_htCalls == "4444" && n1 == 1 && n0 == 0 && nr == 7 && nn == 0,
          "no-out events: the callback gets 4 parameters; WVK_CANCEL 1/0 cancels or not, WVK_RESULT wins, nothing set keeps the default",
          FromAnsi(g_htCalls.c_str()) + L" " + std::to_wstring(n1) + std::to_wstring(n0) + std::to_wstring(nr) + std::to_wstring(nn));
    const int d1 = fire(WVE_SCRIPT_DIALOG, (void*)HtOut4, true, 1, -1000, 1), d0 = fire(WVE_SCRIPT_DIALOG, (void*)HtOut4, true, 0, -1000, 1),
              dn = fire(WVE_SCRIPT_DIALOG, (void*)HtOut4, true, -1, -1000, 1);
    const int p1 = fire(WVE_PERMISSION, (void*)HtOut3, true, 1, -1000, 0), p0 = fire(WVE_PERMISSION, (void*)HtOut3, true, 0, -1000, 0),
              pr = fire(WVE_PERMISSION, (void*)HtOut3, true, 1, 1, 0), w1 = fire(WVE_NEW_WINDOW, (void*)HtOut3, true, 1, -1000, 1),
              w0 = fire(WVE_NEW_WINDOW, (void*)HtOut3, true, 0, -1000, 1), c1 = fire(WVE_CERT_ERROR, (void*)HtOut3, true, 1, -1000, 0);
    Check(d1 == 0 && d0 == 1 && dn == 1 && p1 == 2 && p0 == 0 && pr == 1 && w1 == 2 && w0 == 1 && c1 == 2,
          "cancel maps per event: a dialog is answered with cancel, a permission is denied, a new window is blocked, a certificate error cancels",
          std::to_wstring(d1) + std::to_wstring(d0) + std::to_wstring(dn) + L" " + std::to_wstring(p1) + std::to_wstring(p0) + std::to_wstring(pr) + L" " +
              std::to_wstring(w1) + std::to_wstring(w0) + std::to_wstring(c1));
    g_htCalls.clear();
    const int o5 = fire(WVE_NAV_STARTING, (void*)HtOut5, false, -1, -1000, 0), o5c = fire(WVE_NAV_STARTING, (void*)HtOut5, false, 0, -1000, 0);
    Check(g_htCalls == "55" && o5 == 1 && o5c == 0, "events registered without the flag still pass the int* (C/C++), and the setters work there too",
          FromAnsi(g_htCalls.c_str()));
    DevChecks() = 1;
    g_notices.clear();
    g_devNoticeHook = CaptureNotice;
    const int bad = fire(WVE_NAV_STARTING, (void*)HtOut5, true, -1, -1000, 0);
    const std::wstring nb = g_notices.empty() ? std::wstring() : g_notices[0];
    // 1.7.8：旧写法（照旧写了最后的“参考”参数）仍然回填（HtOut5 给它赋值 1），同时按参数表不对报告、提示改成新写法；1.7.0–1.7.7 赋值悄悄失效
    Check(bad == 1 && g_notices.size() == 1 && nb.find(L"多写了最后一个参数（以前的写法）") != std::wstring::npos &&
              nb.find(L"应为 4 个参数（浏览器句柄, 网址, 用户发起, 是重定向）") != std::wstring::npos && nb.find(L"回调_置取消 ()") != std::wstring::npos &&
              CheckStatsJson().find(L"{\"event\":2,\"declaredBytes\":20,\"expected\":4}") != std::wstring::npos,
          "a no-out callback still declaring the by-ref parameter keeps working and is reported, with the read-only parameter list and how to set the result", nb);
    // 1.7.9：每个有回填参数的事件都核对取消的换算（变异测试发现：按键、下载开始、认证、拦截请求原来没有用例，把按键当成没有回填参数也测不出来）
    {
      struct K {
        int ev, kind;
      } ks[] = {{WVE_NAV_STARTING, 1}, {WVE_DOWNLOAD_START, 1}, {WVE_AUTH, 1}, {WVE_REQUEST, 1}, {WVE_KEY, 1},
                {WVE_SCRIPT_DIALOG, 2}, {WVE_NEW_WINDOW, 3}, {WVE_PERMISSION, 3}, {WVE_CERT_ERROR, 3}};
      std::wstring wrong;
      for (const K& k : ks) {
        auto fireK = [&](int cancel) {
          ev->SetEvent(k.ev, (void*)HtSetOnly, true);
          g_htSetCancel = cancel;
          g_htSetResult = -1000;
          int out = 7;  // 初值 7：不取消时整数选项事件应保持它
          ev->Fire(k.ev, {(intptr_t)515151, 0, 0, (intptr_t)&out});
          return out;
        };
        const int c1 = fireK(1), c0 = fireK(0), cn = fireK(-1);
        const int w1 = k.kind == 1 ? 1 : k.kind == 2 ? 0 : 2, w0 = k.kind == 1 ? 0 : k.kind == 2 ? 1 : 7;
        if (EvOutKind(k.ev) != k.kind || c1 != w1 || c0 != w0 || cn != 7)
          wrong += std::to_wstring(k.ev) + L":" + std::to_wstring(EvOutKind(k.ev)) + L"/" + std::to_wstring(c1) + std::to_wstring(c0) + std::to_wstring(cn) + L" ";
      }
      bool noOutOthers = true;
      for (int e = 1; e <= WVE_MAX; ++e) {
        bool listed = false;
        for (const K& k : ks) listed = listed || k.ev == e;
        if (!listed && EvOutKind(e) != 0) noOutOthers = false;
      }
      Check(wrong.empty() && noOutOthers, "every event with a result to fill maps cancel correctly (true / false / not set); other events have none", wrong);
    }
    // 1.7.9：多写了不止一个参数时用一般的说明，并写明多写的第一个参数是回填结果的地址（它仍能回填）
    g_notices.clear();
    const int bad6 = fire(WVE_NAV_STARTING, (void*)HtOut6, true, -1, -1000, 0);
    const std::wstring n6 = g_notices.empty() ? std::wstring() : g_notices[0];
    Check(bad6 == 1 && n6.find(L"参数表不对：应为 4 个参数") != std::wstring::npos && n6.find(L"多写的第一个参数是回填结果的地址") != std::wstring::npos &&
              n6.find(L"以前的写法") == std::wstring::npos,
          "a no-out callback declaring two extra parameters gets the general notice, which says the first extra one is the result address", n6);
    DevChecks() = 0;
    g_devNoticeHook = nullptr;
    g_htSetCancel = -1;
    g_htSetResult = -1000;
    ev->Release();
    View* ov = new View(525252);
    ParseOptions(ov, L"ev258=1234\r\nev8=5678\r\nev264=0\r\nev20=99\r\nev276=4321");
    Check(ov->cb[2] == (void*)1234 && ov->cbNoOut[2] == 1 && ov->cb[8] == nullptr && ov->cbNoOut[8] == 0 && ov->cb[20] == (void*)4321 && ov->cbNoOut[20] == 1,
          "options: ev with WVE_FLAG_NO_OUT added to the event number registers a no-out callback; a later line for the same event wins");
    ov->Release();
  }
  // ---- 1.7.0：调试运行（开发期检查为 1）时，特征明显的疑似没有转换的 GBK 文字弹出说明（同一段只提示一次，最多 3 次）；西文重音字母、俄文不提示
  {
    CodePageVar() = 65001;
    DevChecks() = 1;
    g_notices.clear();
    g_devNoticeHook = CaptureNotice;
    g_suspectNotices = 0;
    const std::wstring lu = FromCP("\xC2\xBD"), lu2 = FromCP("\xC2\xBD");  // GBK“陆”恰好是合法 UTF-8（½）
    FromCP("caf\xC3\xA9");                                                    // café
    FromCP("\xD0\xBF\xD1\x80\xD0\xB8");                                    // при
    FromCP("\xC3\xA9t\xC3\xA9");                                             // été
    const size_t first = g_notices.size();
    const std::wstring t1 = first ? g_notices[0] : std::wstring();
    FromCP("\xC2\xB7");  // 路 → ·
    FromCP("\xC2\xAC");  // 卢 → ¬
    FromCP("\xC2\xB3");  // 鲁 → ³
    FromCP("\xC2\xBC");  // 录 → ¼（已到 3 次，不再提示）
    Check(lu == L"\x00BD" && lu2 == lu && first == 1 && t1.find(L"\x00BD") != std::wstring::npos && t1.find(L"\x9646") != std::wstring::npos &&
              t1.find(L"WV文本 ()") != std::wstring::npos && g_notices.size() == 3,
          "debug run: an unconverted GBK word that happens to be valid UTF-8 is shown once per text, at most 3 times; café, при, été are not flagged",
          t1 + L" | " + std::to_wstring(g_notices.size()));
    // 1.7.9：特征的边界（变异测试发现阈值放宽一格也测不出来）：第二个字节是 A1 的“隆”（C2 A1 解成 U+00A1）算，A0（U+00A0 不换行空格）
    // 与俄文 Р（U+0420，低 6 位 0x20）不算
    Check(SuspectStrict(L"\x00A1") && !SuspectStrict(L"\x00A0") && !SuspectStrict(L"\x0420") && !SuspectStrict(L"\x0800"),
          "strict suspect boundary: a second byte from A1 counts, A0 and below do not, nor three-byte characters");
    DevChecks() = 2;
    g_suspectNotices = 0;
    g_notices.clear();
    FromCP("\xC2\xA5");  // 楼 → ¥：开发期检查为 2 时只计数、写日志
    Check(g_notices.empty(), "dev checks 2: suspect texts are only counted and logged");
    DevChecks() = 0;
    g_devNoticeHook = nullptr;
    CodePageVar() = 0;
  }
  // ---- 1.7.1：回填结果的键只在会读取它的事件里有效，用在别的事件的回调里返回失败并说明；开发期检查为 1 时每个“键 + 事件”只提示一次
  {
    DevChecks() = 1;
    g_notices.clear();
    g_devNoticeHook = CaptureNotice;
    auto in = [](int type, const std::function<void()>& body) {
      EventCtx c;
      c.type = type;
      PushCtx(&c);
      body();
      PopCtx();
    };
    int wrong1 = -1, wrong2 = -1, wrong3 = -1, wrong4 = -1, again = -1, e1 = -1, unknown = -1;
    std::wstring m1;
    in(WVE_TITLE_CHANGED, [&] {
      wrong1 = WV_EvSet(WVK_SET_PATH, "C:\\x");
      e1 = WV_LastErrorCode();
      m1 = FromCP(WV_LastError());
      wrong2 = WV_EvSetInt(WVK_CANCEL, 1);
      wrong3 = WV_EvSet(WVK_SET_RESULT, "1");
      again = WV_EvSet(WVK_SET_PATH, "C:\\y");
      unknown = WV_EvSetInt(99, 1);
    });
    in(WVE_JS_CALL, [&] { wrong4 = WV_EvSetInt(WVK_RESULT, 1); });
    Check(wrong1 == 0 && wrong2 == 0 && wrong3 == 0 && wrong4 == 0 && again == 0 && e1 == WVERR_ARG && unknown == 1 &&
              m1.find(L"回调_置下载路径 ()") != std::wstring::npos && m1.find(L"事件“下载开始”") != std::wstring::npos &&
              m1.find(L"事件“标题改变”") != std::wstring::npos && g_notices.size() == 4,
          "setters used in the wrong event fail with WVERR_ARG naming the event they belong to; each key and event is shown once; unknown keys pass",
          m1 + L" | " + std::to_wstring(g_notices.size()));
    int ok1 = -1, ok2 = -1, ok3 = -1, ok4 = -1, ok5 = -1, ok6 = -1;
    in(WVE_DOWNLOAD_START, [&] { ok1 = WV_EvSet(WVK_SET_PATH, "C:\\x"); ok2 = WV_EvSetInt(WVK_CANCEL, 1); });
    in(WVE_JS_CALL, [&] { ok3 = WV_EvSet(WVK_SET_RESULT, "1"); ok4 = WV_EvSetInt(WVK_DEFER, 1); });
    in(WVE_NEW_WINDOW, [&] { ok5 = WV_EvSetInt(WVK_TARGET_VIEW, 5); ok6 = WV_EvSetInt(WVK_RESULT, 2); });
    Check(ok1 == 1 && ok2 == 1 && ok3 == 1 && ok4 == 1 && ok5 == 1 && ok6 == 1, "setters in the event that reads them still succeed");
    DevChecks() = 0;
    g_devNoticeHook = nullptr;
  }
  // ---- 1.7.1：白名单里的本地文件夹按解码后的路径比较：中文文件夹名直接写，空格写成 %20，不区分大小写；带通配符时整段匹配
  {
    std::map<std::wstring, FolderMap> none;
    std::vector<std::wstring> cn{L"file:///D:/\x6211\x7684\x7A0B\x5E8F/ui"}, sp{L"file:///D:/My%20UI"}, wild{L"file:///D:/\x6211\x7684\x7A0B\x5E8F/*.html"};
    const wchar_t* inside = L"file:///D:/%E6%88%91%E7%9A%84%E7%A8%8B%E5%BA%8F/ui/a.html";
    Check(OriginAllowed(cn, inside, none) && OriginAllowed(cn, L"file:///d:/%E6%88%91%E7%9A%84%E7%A8%8B%E5%BA%8F/UI/sub/b.html", none) &&
              !OriginAllowed(cn, L"file:///D:/%E6%88%91%E7%9A%84%E7%A8%8B%E5%BA%8F/ui2/a.html", none) && OriginAllowed(sp, L"file:///D:/my%20ui/x.html", none) &&
              OriginAllowed(wild, inside, none) && !OriginAllowed(wild, L"file:///D:/%E6%88%91%E7%9A%84%E7%A8%8B%E5%BA%8F/ui/a.js", none),
          "bridge whitelist: a local folder written with Chinese characters or %20 matches the percent-encoded page URL; wildcards match the whole path");
    std::vector<std::wstring> ui{L"file:///D:/ui"}, all{L"file:///*"};
    Check(!OriginAllowed(ui, L"file:///D:/ui/..%5C..%5Cevil.html", none) && !OriginAllowed(ui, L"file:///D:/ui/..%2F..%2Fevil.html", none) &&
              OriginAllowed(ui, L"file:///D:/ui/a.html", none) && OriginAllowed(all, L"file:///E:/x/y.html", none),
          "bridge whitelist: a listed local folder is compared after decoding, so %5C or %2F escapes cannot climb out of it; file:///* still allows every local file");
    std::vector<std::wstring> twoSlash{L"file://D:/ui"};
    Check(PathFromFileUrl(L"file://C:/a/b.html") == L"C:\\a\\b.html" && PathFromFileUrl(L"file://c|/x") == L"c:\\x" &&
              PathFromFileUrl(L"file://srv/share/x") == L"\\\\srv\\share\\x" && OriginAllowed(twoSlash, L"file:///D:/ui/a.html", none) &&
              !OriginAllowed(twoSlash, L"file:///D:/other/a.html", none),
          "file URL with a drive where the host goes (file://C:/a) is the drive, as the browser reads it, not a network share");
    {
      std::wstring savedApp;
      {
        Guard g(GLock());
        savedApp = G().appDir;
        G().appDir = PathDir(ModulePath(nullptr));
      }
      wchar_t oldCwd[MAX_PATH] = {0};
      GetCurrentDirectoryW(MAX_PATH, oldCwd);
      SetCurrentDirectoryW(PathDir(ModulePath(nullptr)).c_str());  // 当前目录就是程序目录：按“该盘当前目录”解析的写法原来会被当成程序目录里的页面
      const std::wstring drv = PathDir(ModulePath(nullptr)).substr(0, 2);
      std::vector<std::wstring> empty0;
      std::map<std::wstring, FolderMap> none0;
      Check(PathFromFileUrl(L"file:///" + drv + L"ui/x.html") == L"" && !OriginAllowed(empty0, L"file:///" + drv + L"x.html", none0),
            "a drive without a separator (file:///C:x) depends on the current directory: rejected, not taken as a page in the program folder");
      Check(PathFromFileUrl(L"file:///C:") == L"C:\\" && PathFromFileUrl(L"file:///C:/") == L"C:\\", "a bare drive in a file URL is the root of that drive");
      // 1.7.7 实机报告里 WebView2 给出的本地页面网址（易语言调试运行，程序目录是文本格式源码的 .e~ 文件夹）：中文按 UTF-8 写成 %XX，
      // 方括号原样。按这份真实样本固定下来：解码后正好是程序目录里的文件，算本程序的内容
      {
        Guard g2(GLock());
        G().appDir = L"E:\\Desktop\\WebView2Bridge\\epl\\精易模块v9.3.5[源码].e~";
      }
      const std::wstring real = L"file:///E:/Desktop/WebView2Bridge/epl/%E7%B2%BE%E6%98%93%E6%A8%A1%E5%9D%97v9.3.5[%E6%BA%90%E7%A0%81].e~/"
                                L"%E6%95%B4%E9%AA%8C%E6%A1%A5%E6%8E%A5%E6%9C%AC%E5%9C%B0%E9%A1%B5.html";
      Check(PathFromFileUrl(real) == L"E:\\Desktop\\WebView2Bridge\\epl\\精易模块v9.3.5[源码].e~\\整验桥接本地页.html" && OriginAllowed(empty0, real, none0) &&
                !OriginAllowed(empty0, L"file:///E:/Desktop/WebView2Bridge/epl/%E7%B2%BE%E6%98%93%E6%A8%A1%E5%9D%97v9.3.5[%E6%BA%90%E7%A0%81].e~/WebView2Data/x.html", none0,
                               std::vector<std::wstring>{L"E:\\Desktop\\WebView2Bridge\\epl\\精易模块v9.3.5[源码].e~\\WebView2Data"}),
            "real WebView2 file URL from the Windows report (UTF-8 %XX, raw brackets) decodes to the page in the program folder");
      SetCurrentDirectoryW(oldCwd);
      Guard g(GLock());
      G().appDir = savedApp;
    }
  }
  printf("RESULT pass=%d fail=%d\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
