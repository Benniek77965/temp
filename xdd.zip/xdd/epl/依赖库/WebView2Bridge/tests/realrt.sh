#!/usr/bin/env bash
# 真实运行时验证（Linux + Wine，可选，不在 run_all.sh 里）：用微软的 x86 固定版运行时检查 1.8.0 的运行时处理——
#   missing  缺少 icudtl.dat：查找时就排除并说明原因；放回文件后同一进程里能用（没有交给运行时客户端，它不会记住失败）
#   busy     icudtl.dat 被独占打开几秒：说明“被占用”并自动重试，放开后照常启动
#   vm       32 位地址空间放不下 icudtl.dat：直接说明，不交给运行时客户端；内存降下来后同一进程里能用
#   poison   跳过预检的测试版 DLL：运行时客户端失败并记住失败后，本进程不再用它；装好另一个运行时后（指定了数据目录）能用、不报数据目录冲突
#   switch   跳过预检的测试版 DLL、先用固定版（策略 1）：固定版的客户端失败后，浏览器自己改用已安装的运行时
#   win7order / install（Win7 模式）：已安装的 109 先于程序目录的固定版；一键安装不再拒绝 Win7，自动安装失败后 24 小时冷却
# 用法：tests/realrt.sh <x86 固定版运行时目录（直接含 msedgewebview2.exe）> [输出目录]
# 运行时可下载 Microsoft.WebView2.FixedVersionRuntime.109.0.1518.78.x86.cab（或更新的 x86 版）后用 cabextract 解开。需要 mingw-w64（i686）、wine（32 位）、xvfb-run
set -u
RT="${1:?用法：tests/realrt.sh <x86 固定版运行时目录> [输出目录]}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${2:-$ROOT/_realrt_out}"
[ -f "$RT/msedgewebview2.exe" ] || { echo "不是运行时目录：$RT"; exit 2; }
mkdir -p "$OUT/inc" "$OUT/app" && cd "$OUT" || exit 1
export WINEDEBUG=-all WINEDLLOVERRIDES="mscoree,mshtml=" WINEPREFIX="${WINEPREFIX:-$OUT/wineprefix}" WINEARCH=win32 LANG=C.UTF-8
CXX=i686-w64-mingw32-g++
echo '#include <eventtoken.h>' > inc/EventToken.h
INC="-I$OUT/inc -I$ROOT/src -I$ROOT/src/third_party/webview2/include"
SRCS="$ROOT/src/wv_util.cpp $ROOT/src/wv_runtime.cpp $ROOT/src/wv_host.cpp $ROOT/src/wv_view.cpp $ROOT/src/wv_feat.cpp $ROOT/src/wv_api.cpp"
FL="-std=c++17 -O2 -s -shared -static -static-libgcc -static-libstdc++ -DUNICODE -D_UNICODE -DWINVER=0x0601 -D_WIN32_WINNT=0x0601 $INC $SRCS -Wl,--kill-at -lole32 -luser32 -lgdi32 -ladvapi32 -lshell32 -lversion"
$CXX $FL -o dll_normal.dll && $CXX -DWV_TEST_NO_PRECHECK $FL -o dll_noprecheck.dll && $CXX -std=c++17 -O1 -static "$ROOT/tests/realrt.cpp" -o app/realrt.exe -luser32 -ladvapi32 || { echo "编译失败"; exit 1; }
[ -d "$WINEPREFIX" ] || { wineboot -i > /dev/null 2>&1; wineserver -w; }
rm -rf app/WebView2 && { cp -al "$RT" app/WebView2 2> /dev/null || cp -a "$RT" app/WebView2; }
LA="$(winepath -u "$(wine cmd /c echo %LOCALAPPDATA% 2> /dev/null | tr -d '\r')")/Microsoft/EdgeWebView/Application/realrt"
rm -rf "$LA" && mkdir -p "$(dirname "$LA")" && { cp -al "$RT" "$LA" 2> /dev/null || cp -a "$RT" "$LA"; }
rm -f "$LA/EBWebView/x86/EmbeddedBrowserWebView.dll" && cp "$RT/EBWebView/x86/EmbeddedBrowserWebView.dll" "$LA/EBWebView/x86/"  # 客户端 DLL 必须是另一个文件（硬链接会被当成同一个模块）
FAILED=0
run() {  # 系统版本 场景
  local ver="$1" sc="$2" dll=dll_normal.dll cmd
  wine reg add 'HKCU\Software\Wine' /v Version /d "$ver" /f > /dev/null 2>&1; wineserver -w
  rm -rf app/WebView2Data app/realrt_log.txt
  case $sc in
    missing) mv app/WebView2/icudtl.dat app/WebView2/icudtl.dat.bak; cmd="wine realrt.exe missing";;
    busy) cmd="wine realrt.exe lock WebView2\\\\icudtl.dat 6000 & sleep 3; wine realrt.exe busy";;
    poison|switch) dll=dll_noprecheck.dll; mv app/WebView2/icudtl.dat app/WebView2/icudtl.dat.bak; cmd="wine realrt.exe $sc";;
    *) cmd="wine realrt.exe $sc";;
  esac
  cp "$dll" app/WebView2Bridge.dll
  ( cd app && timeout 170 xvfb-run -a -s "-screen 0 1280x1024x24" sh -c "$cmd; wineserver -k" ) > "realrt_$sc.txt" 2>&1
  [ -f app/WebView2/icudtl.dat.bak ] && mv app/WebView2/icudtl.dat.bak app/WebView2/icudtl.dat
  grep -a -E '^(PASS|FAIL|RESULT)' "realrt_$sc.txt"
  grep -aq '^FAIL' "realrt_$sc.txt" && FAILED=1
  grep -aq '^RESULT' "realrt_$sc.txt" || { echo "FAIL $sc 没有跑完（见 $OUT/realrt_$sc.txt）"; FAILED=1; }
}
for sc in missing busy vm poison switch; do run win10 $sc; done
for sc in win7order install; do run win7 $sc; done
wine reg add 'HKCU\Software\Wine' /v Version /d win10 /f > /dev/null 2>&1; wineserver -w
[ $FAILED -eq 0 ] && echo "结果：全部通过" || echo "结果：有失败项"
exit $FAILED
