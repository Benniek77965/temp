// 提示卡片白盒测试（开发者测试）：把 DLL 源码直接编进来，检查断行规则、多张卡片共用一次安装、提示卡片开关、只用固定版时的卡片、重新检测提示、
// 选定运行时文件夹、“已复制”恢复、键盘操作（Tab、回车与自动重复，以及对话框管理器下的按键）、看不见的按钮不可点、鼠标捕获丢失、
// 透明背景、父窗口 DPI 变化、读屏软件经 MSAA 读到的内容、选择文件夹对话框的取消，以及绘制时 GDI 对象全部释放。
// 编译：i686-w64-mingw32-g++ -std=c++17 -O1 -static -municode -DUNICODE -D_UNICODE -Isrc -Isrc\third_party\webview2\include tests\paneltest.cpp -o paneltest.exe -lole32 -loleacc -loleaut32 -luser32 -lgdi32 -ladvapi32 -lshell32 -lversion
// 在没有 WebView2 运行时的环境（如 Wine）中运行；断行用例需要系统里有中文字体
// GDI 对象计数：Wine 的 GetGuiResources 总是返回 0（mocktest 里按它做的泄漏检查在 Wine 中不会执行），
// 这里把绘制用到的创建与释放函数包一层直接计数。宏要在 windows.h 之后、DLL 源码之前定义，windows.h 的配置与 wv_internal.h 一致
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0601
#define WINVER 0x0601
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
// 1.7.9：读屏名称改变的通知（SetWinEventHook，进程外方式，在处理消息时送达）
static int g_nameChanges = 0;
static HWND g_nameHost = nullptr;
static void CALLBACK OnNameChange(HWINEVENTHOOK, DWORD, HWND hwnd, LONG obj, LONG, DWORD, DWORD) {
  if (hwnd == g_nameHost && obj == OBJID_CLIENT) ++g_nameChanges;
}

static long g_gdiNew = 0, g_gdiDel = 0, g_dcNew = 0, g_dcDel = 0;
template <class T>
static T GdiNew(T h) {
  if (h) ++g_gdiNew;
  return h;
}
static BOOL GdiDel(HGDIOBJ h) {
  BOOL r = ::DeleteObject(h);
  if (r) ++g_gdiDel;
  return r;
}
static HDC DcNew(HDC h) {
  if (h) ++g_dcNew;
  return h;
}
static BOOL DcDel(HDC h) {
  BOOL r = ::DeleteDC(h);
  if (r) ++g_dcDel;
  return r;
}
#define CreateFontW(...) GdiNew(::CreateFontW(__VA_ARGS__))
#define CreateSolidBrush(...) GdiNew(::CreateSolidBrush(__VA_ARGS__))
#define CreateDIBSection(...) GdiNew(::CreateDIBSection(__VA_ARGS__))
#define CreatePen(...) GdiNew(::CreatePen(__VA_ARGS__))
#define DeleteObject(h) GdiDel(h)
#define CreateCompatibleDC(...) DcNew(::CreateCompatibleDC(__VA_ARGS__))
#define DeleteDC(h) DcDel(h)
#include "../src/wv_util.cpp"
#include "../src/wv_runtime.cpp"
#include "../src/wv_host.cpp"
#include "../src/wv_view.cpp"
#include "../src/wv_feat.cpp"
#include "../src/wv_api.cpp"
#include <cstdio>
#include <oleacc.h>

using namespace wv;

static int g_pass = 0, g_fail = 0;
static void Check(bool c, const char* n, const std::wstring& got = std::wstring()) {
  if (c) {
    ++g_pass;
    printf("PASS %s\n", n);
  } else {
    ++g_fail;
    printf("FAIL %s  [%s]\n", n, ToUtf8(got).c_str());
  }
  fflush(stdout);
}
static void Pump(DWORD ms) {
  DWORD t = GetTickCount();
  MSG m;
  while (GetTickCount() - t < ms) {
    while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) {
      TranslateMessage(&m);
      DispatchMessageW(&m);
    }
    Sleep(5);
  }
}
static std::wstring Join(const TextBlock& b) {
  std::wstring s;
  for (auto& l : b.lines) s += l + L"|";
  return s;
}
static std::wstring NoSpace(const std::wstring& s) {
  std::wstring o;
  for (wchar_t c : s)
    if (c != L' ' && c != L'\r' && c != L'\n' && c != L'|') o += c;
  return o;
}

static void TestLayout(HDC dc) {
  HFONT f = MakeFont(96, 14, FW_NORMAL);
  const std::wstring text = L"这个程序用微软 Edge WebView2 显示页面。点“一键安装”会从微软官网下载并自动安装（大约 1～3 分钟），装好后页面会自动打开！";
  bool kinsoku = true, width = true, words = true, content = true;
  std::wstring bad;
  for (int w = 90; w <= 420; w += 7) {  // 很多个行宽都检查一遍：断点落在哪里都要守规则
    TextBlock b = LayoutText(dc, f, text, w, 14, 160, 96);
    if (NoSpace(Join(b)) != NoSpace(text)) {
      content = false;
      bad = Join(b);
    }
    for (size_t i = 0; i < b.lines.size(); ++i) {
      const std::wstring& l = b.lines[i];
      if (l.empty()) continue;
      if (i > 0 && NoLineStart(l.substr(0, 1))) {
        kinsoku = false;
        bad = Join(b);
      }
      if (i + 1 < b.lines.size() && NoLineEnd(l.substr(l.size() - 1))) {
        kinsoku = false;
        bad = Join(b);
      }
      // 允许的超出：行尾悬挂的闭合标点（中文排版的常规做法）
      std::wstring body = l;
      while (body.size() > 1 && NoLineStart(body.substr(body.size() - 1))) body.pop_back();
      if (UnitWidth(dc, body) > w + 1 && body.size() > 1) {
        width = false;
        bad = Join(b) + Fmt(L" w=%d", w);
      }
    }
    if (w >= 120) {  // 行宽放得下时，西文单词不能被拆开
      std::wstring j = Join(b);
      if (j.find(L"WebView2") == std::wstring::npos || j.find(L"Edge") == std::wstring::npos) {
        words = false;
        bad = j;
      }
    }
  }
  Check(content, "line breaking keeps every character (only spaces at breaks are dropped)", bad);
  Check(kinsoku, "no closing punctuation at line start, no opening bracket at line end", bad);
  Check(width, "every line fits the width", bad);
  Check(words, "Latin words are never split when they fit on a line", bad);
  const std::wstring spaced = L"这是一段用于测试断行的文字，包含英文单词 WebView2 ）以及后续内容（ 括号里 ）继续排版直到换行为止。";
  bool spacedOk = true;
  std::wstring spacedBad;
  for (int w = 60; w <= 400; ++w) {
    TextBlock b = LayoutText(dc, f, spaced, w, 14, 160, 96);
    if (NoSpace(Join(b)) != NoSpace(spaced)) spacedOk = false;
    for (size_t i = 0; i < b.lines.size(); ++i) {
      std::wstring l = b.lines[i];
      while (!l.empty() && l[0] == L' ') l.erase(0, 1);
      while (!l.empty() && l.back() == L' ') l.pop_back();
      if (l.empty()) continue;
      if ((i > 0 && NoLineStart(l.substr(0, 1))) || (i + 1 < b.lines.size() && NoLineEnd(l.substr(l.size() - 1)))) {
        spacedOk = false;
        spacedBad = Join(b) + Fmt(L" w=%d", w);
      }
    }
  }
  Check(spacedOk, "line-start/line-end rules also hold when a space sits next to the punctuation", spacedBad);
  TextBlock hard = LayoutText(dc, f, L"第一行\r\n第二行\n第三行", 400, 14, 160, 96);
  Check(hard.lines.size() == 3 && hard.lines[1] == L"第二行", "explicit line breaks are kept", Join(hard));
  const std::wstring path = L"找到的是 64 位运行时（D:\\app\\WebView2\\Microsoft.WebView2.FixedVersionRuntime.109.0.1518.140.x64），请换成 x86 版本";
  TextBlock pb = LayoutText(dc, f, path, 160, 14, 160, 96);
  bool sep = true;
  for (size_t i = 0; i + 1 < pb.lines.size(); ++i) {
    const std::wstring& l = pb.lines[i];
    if (l.find(L"\\") == std::wstring::npos && l.find(L".") == std::wstring::npos) continue;  // 不含路径的行
    wchar_t last = l.back();
    if (!wcschr(L"\\/.-_）（", last) && !CjkLike(last)) sep = false;
  }
  Check(sep && NoSpace(Join(pb)) == NoSpace(path), "an over-long path is split after separators, nothing lost", Join(pb));
  TextBlock one = LayoutText(dc, f, L"x", 1, 14, 160, 96);
  Check(one.lines.size() == 1, "a width smaller than one character still makes progress", Join(one));
  Check(LayoutText(dc, f, L"", 300, 14, 160, 96).lines.empty() && LayoutText(dc, f, L"abc", 0, 14, 160, 96).lines.empty(), "empty text or zero width gives no lines");
  TextBlock lh = LayoutText(dc, f, text, 200, 14, 160, 96);
  Check(lh.advance >= lh.lineH && lh.advance == std::max(lh.lineH, MulDiv(14 * 160, 96, 9600)) && lh.height == (int)(lh.lines.size() - 1) * lh.advance + lh.lineH,
        "line advance follows the requested line height", Fmt(L"%d/%d/%d", lh.lineH, lh.advance, lh.height));
  DeleteObject(f);
}

static HWND MakeParent() {
  WNDCLASSW wc = {};
  wc.lpfnWndProc = DefWindowProcW;
  wc.hInstance = GetModuleHandleW(nullptr);
  wc.lpszClassName = L"PanelTestParent";
  RegisterClassW(&wc);
  return CreateWindowExW(WS_EX_CONTROLPARENT, L"PanelTestParent", L"paneltest", WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_VISIBLE, 0, 0, 1000, 700, nullptr, nullptr, wc.hInstance,
                         nullptr);
}

// 找到本进程弹出的对话框（选择文件夹）并点“取消”
static BOOL CALLBACK FindOwnDialog(HWND h, LPARAM lp) {
  DWORD pid = 0;
  GetWindowThreadProcessId(h, &pid);
  wchar_t cls[16] = {0};
  GetClassNameW(h, cls, 15);
  if (pid == GetCurrentProcessId() && IsWindowVisible(h) && wcscmp(cls, L"#32770") == 0) {
    *(HWND*)lp = h;
    return FALSE;
  }
  return TRUE;
}
static volatile LONG g_dialogTitleOk = -1;
static DWORD WINAPI CancelDialog(LPVOID) {
  for (int i = 0; i < 300; ++i) {
    Sleep(50);
    HWND d = nullptr;
    EnumWindows(FindOwnDialog, (LPARAM)&d);
    if (d) {
      wchar_t t[128] = {0};
      GetWindowTextW(d, t, 127);
      InterlockedExchange(&g_dialogTitleOk, wcsstr(t, L"WebView2") != nullptr);
      PostMessageW(d, WM_COMMAND, IDCANCEL, 0);
      return 0;
    }
  }
  return 0;
}
static COLORREF PaintedPixel(View* v, int x, int y) {
  HDC wdc = GetDC(v->host);
  HDC mem = CreateCompatibleDC(wdc);
  RECT rc;
  GetClientRect(v->host, &rc);
  HBITMAP b = CreateCompatibleBitmap(wdc, rc.right, rc.bottom);
  HGDIOBJ o = SelectObject(mem, b);
  v->Paint(mem);
  COLORREF c = GetPixel(mem, x, y);
  SelectObject(mem, o);
  ::DeleteObject(b);
  DeleteDC(mem);
  ReleaseDC(v->host, wdc);
  return c;
}

int wmain() {
  g_module = GetModuleHandleW(nullptr);
  InitOs();
  WV_SetOption(WVO_FALLBACK_UI, "1");
  HDC sdc = GetDC(nullptr);
  TestLayout(sdc);
  ReleaseDC(nullptr, sdc);

  HWND parent = MakeParent();
  // 安装相关用例按 Win10/11 的规则（1.8.0 起 Win7/8/8.1 也能一键安装，单独核对）：白盒测试自己设定系统类型，在两种系统模式下结果一致
  const bool realLegacy = g_os.legacy;
  g_os.legacy = false;
  // 两个浏览器并排，都显示“需要运行时”卡片
  int h1 = WV_CreateAsync(parent, 0, 0, 480, 600, "https://a.test", "", nullptr);
  int h2 = WV_CreateAsync(parent, 500, 0, 480, 600, "https://b.test", "", nullptr);
  HWND edit = CreateWindowExW(0, L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_BORDER, 0, 620, 200, 24, parent, nullptr, nullptr, nullptr);
  Pump(100);
  RefPtr<View> v1 = FindView(h1), v2 = FindView(h2);
  Check(v1 && v2 && v1->panel.mode == 2 && v2->panel.mode == 2 && v1->errCode == WVERR_NO_RUNTIME, "two views show the runtime card");
  // 一次安装：点了一张卡片，两张都进入安装中；再请求安装也不会启动第二个安装程序
  InstallJob running;
  running.start = GetTickCount();
  running.stage = 1;
  g_job = &running;  // 模拟已在进行的安装（不联网）
  v1->PanelAction(PA_INSTALL);
  Check(v1->panel.mode == 3 && v2->panel.mode == 3, "starting the install moves every waiting card into the installing state",
        Fmt(L"%d/%d", v1->panel.mode, v2->panel.mode));
  Check(StartRuntimeInstall() && g_job == &running, "a second install request joins the running install instead of starting another");
  Check(v1->panel.btnCount == 0 && v2->panel.btnCount == 0, "installing cards offer no second install button");
  // 安装失败：所有安装中的卡片一起显示原因，可以重试安装
  running.done = 1;
  {
    Guard g(g_installLock);
    g_installErr = L"下载引导程序失败：测试";
  }
  PostMessageW(Dispatcher().load(), WM_WV_INSTALL_DONE, 0, 0);
  Pump(100);
  Check(v1->panel.mode == 2 && v2->panel.mode == 2 && v1->errCode == WVERR_INSTALL && v2->panel.message.find(L"测试") != std::wstring::npos &&
            v1->panel.btnAction[0] == PA_INSTALL,
        "install failure is shown on every card with a retry-install button", v2->panel.message);
  // 安装成功（这里仍没有运行时）：等待中的浏览器都会重建，各自回到“需要运行时”卡片
  v1->SetPanel(3);
  v2->SetPanel(3);
  running.done = 1;
  PostMessageW(Dispatcher().load(), WM_WV_INSTALL_DONE, 1, 0);
  Pump(200);
  Check(v1->panel.mode == 2 && v2->panel.mode == 2 && v1->errCode == WVERR_NO_RUNTIME && v2->errCode == WVERR_NO_RUNTIME,
        "after a successful install every waiting view is recreated", Fmt(L"%d/%d", v1->errCode, v2->errCode));
  g_job = nullptr;
  // 重新检测：仍然没有找到时卡片上说明已经检测过
  g_os.legacy = true;
  v1->SetPanel(2);
  Check(v1->panel.btnAction[0] == PA_INSTALL, "legacy system with one-click install available: the install button is offered");
  g_onlineInstallerOverride = 0;  // 真实的 Windows 7：微软的在线安装程序启动不了，一键安装改用 109 版离线安装包（约 132MB），卡片照实说明
  const int realMajor = g_os.major, realMinor = g_os.minor;
  g_os.major = 6;
  g_os.minor = 1;
  v1->SetPanel(2);
  Check(v1->panel.btnAction[0] == PA_INSTALL && v1->panel.message.find(L"132MB") != std::wstring::npos,
        "real Windows 7: one-click install downloads the 109 offline package and the card says so", v1->panel.message);
  v1->errBroken = true;  // 原来的问题（固定版文件不全）在 Win7 上：卡片说的一键安装也是这个离线安装包，不说“从微软官网、1～3 分钟”
  v1->SetPanel(2);
  Check(v1->panel.message.find(L"132MB") != std::wstring::npos && v1->panel.message.find(L"1\uFF5E3") == std::wstring::npos,
        "Windows 7 with a damaged fixed runtime: the card describes the offline package install", v1->panel.message);
  v1->errBroken = false;
  g_onlineInstallerOverride = 1;  // Windows 8.1（有 PackageIdFromFullName）：同样用 109 版离线安装包
  g_os.minor = 3;
  v1->SetPanel(2);
  Check(v1->panel.btnAction[0] == PA_INSTALL && v1->panel.message.find(L"132MB") != std::wstring::npos,
        "Windows 8.1: one-click install uses the same 109 offline package", v1->panel.message);
  g_onlineInstallerOverride = 0;
  g_os.minor = 0;  // 比 Windows 7 更早的系统：装不了，不提供一键安装
  v1->SetPanel(2);
  bool oldInstall = false;
  for (int i = 0; i < v1->panel.btnCount; ++i)
    if (v1->panel.btnAction[i] == PA_INSTALL) oldInstall = true;
  Check(!oldInstall && v1->panel.btnAction[0] == PA_RECHECK && v1->panel.message.find(L"Windows 7") != std::wstring::npos,
        "a system older than Windows 7: no one-click install, the card says WebView2 needs Windows 7 or later", v1->panel.message);
  g_os.major = realMajor;
  g_os.minor = realMinor;
  g_onlineInstallerOverride = -1;
  WV_SetOption(WVO_RUNTIME_POLICY, "3");  // 只用固定版：一键安装帮不上，Win7 卡片仍以“重新检测”为主
  v1->SetPanel(2);
  Check(v1->panel.btnAction[0] == PA_RECHECK, "Win7 card offers re-check as the main action when only the fixed runtime may be used");
  WV_SetOption(WVO_RUNTIME_POLICY, "0");
  v1->errBroken = true;  // 找到的运行时文件不完整：标题说明文件有问题，第二个按钮换成“重新检测”
  v1->SetPanel(2);
  Check(v1->panel.title.find(L"\u6587\u4EF6\u6709\u95EE\u9898") != std::wstring::npos && v1->panel.btnAction[0] == PA_INSTALL && v1->panel.btnAction[1] == PA_RECHECK,
        "broken-runtime card says the files are faulty and offers install and re-check", v1->panel.title);
  v1->errRestart = true;  // 运行时在本进程里已经启动失败：说明要重新启动程序，第二个按钮换成“选择运行时文件夹”（别的文件夹是另一个客户端，本次运行就能用）
  v1->SetPanel(2);
  Check(v1->panel.title.find(L"\u91CD\u65B0\u542F\u52A8") != std::wstring::npos && v1->panel.btnAction[0] == PA_INSTALL && v1->panel.btnAction[1] == PA_PICK_DIR,
        "a runtime that already failed in this process: the card says a restart is needed and offers install and another folder", v1->panel.title);
  WV_SetOption(WVO_RUNTIME_POLICY, "3");
  v1->SetPanel(2);
  Check(v1->panel.btnAction[0] == PA_PICK_DIR && v1->panel.btnAction[1] == PA_COPY, "restart card without one-click install offers another folder first", Fmt(L"%d/%d", v1->panel.btnAction[0], v1->panel.btnAction[1]));
  WV_SetOption(WVO_RUNTIME_POLICY, "0");
  v1->errRestartInstalled = true;  // 失效的是电脑上装好的运行时：重新安装装的还是它，不提供一键安装，也不说“装好后不用重启”
  v1->SetPanel(2);
  bool offersInstall = false;
  for (int i = 0; i < v1->panel.btnCount; ++i)
    if (v1->panel.btnAction[i] == PA_INSTALL) offersInstall = true;
  Check(!offersInstall && v1->panel.btnAction[0] == PA_PICK_DIR && v1->panel.title.find(L"\u91CD\u65B0\u542F\u52A8") != std::wstring::npos &&
            v1->panel.message.find(L"\u4E0D\u7528\u91CD\u542F") == std::wstring::npos,
        "an installed runtime that already failed in this process: restart card without one-click install", v1->panel.message);
  v1->errRestartInstalled = false;
  v1->errRestart = false;
  v1->errNetwork = true;  // 没有采用的是放在网络位置的固定版：文件本身没问题，卡片说明网络位置，不说“缺少文件或已经损坏”
  v1->SetPanel(2);
  Check(v1->panel.title.find(L"\u7F51\u7EDC\u4F4D\u7F6E") != std::wstring::npos && v1->panel.message.find(L"\u635F\u574F") == std::wstring::npos &&
            v1->panel.btnAction[0] == PA_INSTALL && v1->panel.btnAction[1] == PA_RECHECK,
        "a fixed runtime on a network location: the card names the cause instead of calling the files damaged", v1->panel.title + L" / " + v1->panel.message);
  v1->errNetwork = false;
  v1->errBroken = false;
  // 1.8.0：程序自己的准备工作（WV_ShowProgress）：进度卡片显示程序给的文字与进度，收起后回到原来的卡片
  v1->SetPanel(2);
  const std::wstring cardBefore = v1->panel.title;
  v1->ShowHostProgress(L"Downloading runtime", L"from our server", L"35%", 350);
  int hpStage = 0, hpPermille = -2;
  const std::wstring hpStatus = v1->InstallStatusText(&hpStage, &hpPermille);
  Check(v1->panel.mode == 3 && v1->panel.title == L"Downloading runtime" && v1->panel.btnCount == 0 && hpStatus == L"35%" && hpPermille == 350,
        "host progress card shows the program's texts and progress", v1->panel.title + L" / " + hpStatus);
  v1->ShowHostProgress(L"Downloading runtime", L"from our server", L"unpacking", -5);
  v1->InstallStatusText(&hpStage, &hpPermille);
  Check(v1->panel.mode == 3 && hpPermille == -1, "updating the host progress card keeps it open; a negative value means an animation only");
  OnInstallFinishedUi(false);
  Check(v1->panel.mode == 3 && v1->hostProgress, "a finished install does not take over the program's own progress card");
  v1->ShowHostProgress(L"", L"", L"", -1);
  Check(v1->panel.mode == 2 && v1->panel.title == cardBefore && !v1->hostProgress, "hiding the host progress card brings back the previous card", v1->panel.title);
  v1->PanelAction(PA_RECHECK);
  Pump(50);
  Check(v1->panel.mode == 2 && v1->panel.detail.find(L"已重新检测") != std::wstring::npos, "re-check that still finds nothing says so on the card", v1->panel.detail);
  g_os.legacy = false;
  v1->SetPanel(2);
  // “已复制”两秒后恢复
  int copy = -1;
  for (int i = 0; i < v1->panel.btnCount; ++i)
    if (v1->panel.btnAction[i] == PA_COPY) copy = i;
  v1->PanelAction(PA_COPY);
  bool copied = copy >= 0 && v1->panel.btnText[copy] == L"已复制";
  Pump(2400);
  Check(copied && v1->panel.btnText[copy] == L"复制诊断信息", "copy label changes to 已复制 and reverts after two seconds", copy >= 0 ? v1->panel.btnText[copy] : L"");
  // Tab：没有对话框管理器时在按钮间移动，到最后一个之后交给窗口里的下一个控件
  SetFocus(v1->host);
  Pump(20);
  Check(v1->panel.focus == 0, "focus enters the card on its first button", Fmt(L"%d", v1->panel.focus));
  for (int i = 1; i < v1->panel.btnCount; ++i) SendMessageW(v1->host, WM_KEYDOWN, VK_TAB, 0);
  Check(v1->panel.focus == v1->panel.btnCount - 1 && v1->panel.kbd, "Tab walks through the buttons", Fmt(L"%d", v1->panel.focus));
  SendMessageW(v1->host, WM_KEYDOWN, VK_TAB, 0);
  HWND now = GetFocus();
  Check(now != v1->host, "Tab on the last button leaves the card for the next control", Fmt(L"%p edit=%p v2=%p", (void*)now, (void*)edit, (void*)v2->host));
  // 窗口缩到放不下卡片时，看不见的旧按钮不能再响应鼠标
  {
    v2->errCode = WVERR_ENV_FAILED;
    v2->errMsg = L"测试";
    v2->SetPanel(2);
    HDC wdc = GetDC(v2->host);
    v2->Paint(wdc);
    RECT b0 = v2->panel.btn[0];
    SetWindowPos(v2->host, nullptr, 0, 0, 30, 30, SWP_NOZORDER | SWP_NOMOVE);
    v2->Paint(wdc);
    SendMessageW(v2->host, WM_MOUSEMOVE, 0, MAKELPARAM((b0.left + b0.right) / 2, (b0.top + b0.bottom) / 2));
    Check(!IsRectEmpty(&b0) && IsRectEmpty(&v2->panel.btn[0]) && v2->panel.hot == -1, "buttons that are not drawn (window too small) are not clickable");
    SetWindowPos(v2->host, nullptr, 0, 0, 480, 600, SWP_NOZORDER | SWP_NOMOVE);
    ReleaseDC(v2->host, wdc);
  }
  // 重新检测之后若是别的原因失败，不能说“仍未找到运行时”
  v2->recheckPending = true;
  v2->errCode = WVERR_ENV_FAILED;
  v2->SetPanel(2);
  Check(v2->panel.detail.find(L"已重新检测") == std::wstring::npos && !v2->recheckPending, "re-check note only appears when the runtime is still missing", v2->panel.detail);
  // 按住回车的自动重复只执行一次
  {
    v2->errCode = WVERR_ENV_FAILED;
    v2->SetPanel(2);
    SetFocus(v2->host);
    int ci = -1;
    for (int i = 0; i < v2->panel.btnCount; ++i)
      if (v2->panel.btnAction[i] == PA_COPY) ci = i;
    v2->panel.focus = ci;
    if (OpenClipboard(nullptr)) {
      EmptyClipboard();
      CloseClipboard();
    }
    SendMessageW(v2->host, WM_KEYDOWN, VK_RETURN, 0x40000001);  // 第 30 位为 1：自动重复
    bool repeatIgnored = !IsClipboardFormatAvailable(CF_UNICODETEXT);
    SendMessageW(v2->host, WM_KEYDOWN, VK_RETURN, 0x00000001);  // 第一次按下
    Check(ci >= 0 && repeatIgnored && IsClipboardFormatAvailable(CF_UNICODETEXT), "Enter acts on the first press and ignores auto-repeat");
  }
  // 安装失败的卡片在运行时就绪后也会恢复
  v2->errCode = WVERR_INSTALL;
  v2->errMsg = L"测试";
  v2->SetPanel(2);
  RecreateWaitingViews();
  Pump(150);
  Check(v2->errCode == WVERR_NO_RUNTIME, "views showing an install failure are recreated when the runtime may be available", Fmt(L"%d", v2->errCode));
  // 关闭了提示卡片的浏览器：别的浏览器开始安装时也不显示卡片
  {
    v1->optFallback = 0;
    v1->Fail(WVERR_NO_RUNTIME, L"测试", S_OK);
    InstallJob running2;
    running2.start = GetTickCount();
    running2.stage = 1;
    g_job = &running2;
    v2->SetPanel(2);
    v2->PanelAction(PA_INSTALL);
    Check(v1->panel.mode == 0 && v2->panel.mode == 3, "a view with the prompt card turned off stays card-less when another view starts installing",
          Fmt(L"%d/%d", v1->panel.mode, v2->panel.mode));
    running2.done = 1;
    g_job = nullptr;
    v1->optFallback = -1;
  }
  // 只用固定版运行时（策略 3、指定了运行时目录）：一键安装装不上能用的运行时，不提供；开始安装时也不切到安装中
  {
    auto offersInstall = [](View* v) {
      for (int i = 0; i < v->panel.btnCount; ++i)
        if (v->panel.btnAction[i] == PA_INSTALL) return true;
      return false;
    };
    WV_SetOption(WVO_RUNTIME_POLICY, "3");
    v2->errCode = WVERR_NO_RUNTIME;
    v2->SetPanel(2);
    bool p3 = !offersInstall(v2.get()) && v2->panel.btnAction[0] == PA_RECHECK;
    ShowInstallingOnAllViews();
    bool p3stay = v2->panel.mode == 2;
    WV_SetOption(WVO_RUNTIME_POLICY, "0");
    WV_SetOption(WVO_RUNTIME_DIR, "C:\\nowhere");
    v2->SetPanel(2);
    bool dir = !offersInstall(v2.get());
    WV_SetOption(WVO_RUNTIME_DIR, "");
    v2->SetPanel(2);
    bool normal = offersInstall(v2.get());
    Check(p3 && p3stay && dir && normal, "one-click install is only offered when the evergreen runtime would actually be used",
          Fmt(L"%d %d %d %d", p3, p3stay, dir, normal));
  }
  // 在卡片上选定运行时文件夹：本浏览器单独指定过运行时目录时改它自己的设置，否则改全局设置；文件夹里没有运行时就说明原因
  {
    wchar_t tmp[MAX_PATH];
    GetTempPathW(MAX_PATH, tmp);
    const std::wstring root = std::wstring(tmp) + Fmt(L"wvpick_%u", GetTickCount()), ver = root + L"\\120.0.2210.91", ebw = ver + L"\\EBWebView", x86 = ebw + L"\\x86",
                       dll = x86 + L"\\EmbeddedBrowserWebView.dll", empty = root + L"_empty";
    for (const std::wstring& d : {root, ver, ebw, x86, empty}) CreateDirectoryW(d.c_str(), nullptr);
    HANDLE fh = CreateFileW(dll.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);  // 空文件：能被找到，载入会失败
    if (fh != INVALID_HANDLE_VALUE) CloseHandle(fh);
    // 1.8.0 起查找运行时还要看浏览器进程、它启动时载入的两个 DLL 与 ICU 数据文件
    static const unsigned char icu[16] = {0x90, 0x00, 0xDA, 0x27};
    for (const wchar_t* n : {L"\\msedgewebview2.exe", L"\\msedge_elf.dll", L"\\msedge.dll", L"\\icudtl.dat"}) {
      HANDLE pf = CreateFileW((ver + n).c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
      DWORD w = 0;
      if (pf == INVALID_HANDLE_VALUE) continue;
      if (wcscmp(n, L"\\icudtl.dat") == 0) WriteFile(pf, icu, sizeof(icu), &w, nullptr);
      else WriteFile(pf, "MZ", 2, &w, nullptr);
      CloseHandle(pf);
    }
    int h3 = WV_CreateAsync(parent, 0, 0, 480, 600, "https://own.test", "runtime=C:\\nowhere\\rt", nullptr);
    Pump(100);
    RefPtr<View> v3 = FindView(h3);
    bool cardOk = v3 && v3->errCode == WVERR_NO_RUNTIME && v3->panel.btnAction[0] == PA_RECHECK;
    if (v3) v3->UsePickedRuntime(root);
    std::wstring global;
    {
      Guard g(GLock());
      global = G().runtimeDir;
    }
    Check(cardOk && _wcsicmp(v3->optRuntime.c_str(), ver.c_str()) == 0 && global.empty() && v3->errCode != WVERR_NO_RUNTIME,
          "a folder picked on a browser with its own runtime setting updates that setting (the global one would be ignored)",
          v3 ? v3->optRuntime + Fmt(L" err=%d global=", v3->errCode) + global : L"no view");
    if (v3) v3->UsePickedRuntime(empty);
    Check(v3 && !v3->panel.detail.empty() && _wcsicmp(v3->optRuntime.c_str(), ver.c_str()) == 0, "a folder without a runtime is explained on the card and changes nothing",
          v3 ? v3->panel.detail : L"");
    int h4 = WV_CreateAsync(parent, 500, 0, 480, 600, "https://global.test", "", nullptr);
    Pump(100);
    RefPtr<View> v4 = FindView(h4);
    if (v4) v4->UsePickedRuntime(root);
    Pump(150);
    {
      Guard g(GLock());
      global = G().runtimeDir;
    }
    Check(v4 && _wcsicmp(global.c_str(), ver.c_str()) == 0 && v4->errCode != WVERR_NO_RUNTIME, "otherwise the picked folder becomes the global runtime folder and waiting browsers retry",
          v4 ? Fmt(L"err=%d global=", v4->errCode) + global : L"no view");
    WV_SetOption(WVO_RUNTIME_DIR, "");
    FindRuntime(true, std::wstring());
    WV_Destroy(h3);
    WV_Destroy(h4);
    Pump(50);
    DeleteFileW(dll.c_str());
    for (const std::wstring& d : {x86, ebw, ver, root, empty}) RemoveDirectoryW(d.c_str());
  }
  // 透明背景：网页透明处露出宿主窗口画的内容，所以要画父窗口的背景（原来画成黑色，全局 transparent 画成白色）；卡片按父窗口背景的深浅选样式
  {
    const COLORREF light = RGB(240, 234, 214), dark = RGB(30, 42, 58);
    bool ok = true;
    std::wstring why;
    for (int i = 0; i < 2; ++i) {
      WNDCLASSW wc2 = {};
      wc2.lpfnWndProc = DefWindowProcW;
      wc2.hInstance = GetModuleHandleW(nullptr);
      wc2.lpszClassName = i ? L"PanelTestDark" : L"PanelTestLight";
      wc2.hbrBackground = CreateSolidBrush(i ? dark : light);
      RegisterClassW(&wc2);
      HWND tp = CreateWindowExW(0, wc2.lpszClassName, L"t", WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_VISIBLE, 0, 0, 760, 520, nullptr, nullptr, wc2.hInstance, nullptr);
      if (i) WV_SetOption(WVO_DEFAULT_BG, "transparent");  // 第二个用全局默认背景色
      int ht = WV_CreateAsync(tp, 0, 0, 720, 460, "https://t.test", i ? "" : "p37=0", nullptr);
      Pump(80);
      RefPtr<View> vt = FindView(ht);
      if (!vt) {
        ok = false;
        continue;
      }
      vt->SetPanel(0);
      const COLORREF want = i ? dark : light, under = PaintedPixel(vt.get(), 5, 5);
      vt->errCode = WVERR_ENV_FAILED;
      vt->errMsg = L"测试";
      vt->SetPanel(2);
      const COLORREF around = PaintedPixel(vt.get(), 5, 5);
      HDC tdc = GetDC(vt->host);
      vt->Paint(tdc);
      ReleaseDC(vt->host, tdc);
      RECT b0 = vt->panel.btn[0];
      const COLORREF body = PaintedPixel(vt.get(), b0.left - 1, b0.top - MulDiv(14, (int)WindowDpi(vt->host, nullptr), 96));  // 卡片正文区域
      const bool bodyDark = IsDarkColor(body);
      if (under != want || around != want || bodyDark != (i == 1)) {
        ok = false;
        why += Fmt(L"[%d: under %06X around %06X body %06X] ", i, (unsigned)under, (unsigned)around, (unsigned)body);
      }
      WV_Destroy(ht);
      Pump(30);
      DestroyWindow(tp);
    }
    WV_SetOption(WVO_DEFAULT_BG, "");
    Check(ok, "transparent background paints the parent window's background, and the card style follows its brightness", why);
  }
  // 默认背景色只接受文档里的写法；原来“#fff”被当成透明
  {
    bool good = WV_SetOption(WVO_DEFAULT_BG, "#112233") && WV_SetOption(WVO_DEFAULT_BG, "#FF112233") && WV_SetOption(WVO_DEFAULT_BG, "Transparent") &&
                WV_SetOption(WVO_DEFAULT_BG, "");
    bool bad = !WV_SetOption(WVO_DEFAULT_BG, "#fff") && WV_LastErrorCode() == WVERR_ARG && !WV_SetOption(WVO_DEFAULT_BG, "#12345G") && !WV_SetOption(WVO_DEFAULT_BG, "red");
    Check(good && bad && WV_GetOption(WVO_DEFAULT_BG)[0] == 0, "default background accepts #RRGGBB, #AARRGGBB and transparent, rejects other forms");
  }
  // 代码页：系统不支持的值设置失败（原来收下后，此后返回的所有文本都是空字符串）
  {
    const size_t before = strlen(WV_GetVersionText());
    bool bad = !WV_SetOption(WVO_CODEPAGE, "12345") && WV_LastErrorCode() == WVERR_ARG && !WV_SetOption(WVO_CODEPAGE, "-5") && !WV_SetOption(WVO_CODEPAGE, "936x");
    const size_t after = strlen(WV_GetVersionText());
    bool good = WV_SetOption(WVO_CODEPAGE, "65001") && WV_SetOption(WVO_CODEPAGE, "936") && WV_SetOption(WVO_CODEPAGE, "") && WV_SetOption(WVO_CODEPAGE, "0");
    Check(bad && good && before > 0 && after == before, "invalid code pages are rejected instead of silently emptying every returned string");
  }
  // 创建选项 bg= 与默认背景色同一种写法；原来“#fff”被当成透明
  {
    auto bgOf = [&](const char* opts, unsigned& argb) {
      int hb = WV_CreateAsync(parent, 0, 0, 200, 200, "https://bg.test", opts, nullptr);
      RefPtr<View> vb = FindView(hb);
      bool has = vb && vb->iprops.count(WVP_BG_COLOR);
      if (has) argb = (unsigned)vb->iprops[WVP_BG_COLOR];
      WV_Destroy(hb);
      return has;
    };
    unsigned a1 = 1, a2 = 1, a3 = 1;
    bool shortForm = bgOf("bg=#fff", a1), full = bgOf("bg=#112233", a2), transp = bgOf("bg=transparent", a3);
    Pump(30);
    Check(!shortForm && full && a2 == 0xFF112233u && transp && a3 == 0, "creation option bg= accepts the documented forms and ignores others", Fmt(L"%d %08X %d %08X", shortForm, a2, transp, a3));
  }
  // 屏蔽快捷键只认 F1～F24
  v2->SetStrProp(WVS_BLOCK_KEYS, L"f0,f32,F12,ctrl+f5");
  Check(v2->blockKeys.size() == 2 && v2->blockKeys.count(VK_F12) && v2->blockKeys.count((1u << 16) | VK_F5), "blocked keys accept F1-F24 only (f0, f32 no longer block unrelated keys)",
        Fmt(L"%u", (unsigned)v2->blockKeys.size()));
  // 按住按钮时鼠标捕获被别的窗口拿走：按钮不能一直显示为按下
  {
    v2->errCode = WVERR_ENV_FAILED;
    v2->SetPanel(2);
    HDC cdc = GetDC(v2->host);
    v2->Paint(cdc);
    ReleaseDC(v2->host, cdc);
    RECT b0 = v2->panel.btn[0];
    const LPARAM pt = MAKELPARAM((b0.left + b0.right) / 2, (b0.top + b0.bottom) / 2);
    SendMessageW(v2->host, WM_MOUSEMOVE, 0, pt);
    SendMessageW(v2->host, WM_LBUTTONDOWN, MK_LBUTTON, pt);
    const bool pressed = v2->panel.pressed == 0;
    SetCapture(parent);
    ReleaseCapture();
    Check(pressed && v2->panel.pressed == -1, "losing mouse capture mid-press releases the button");
  }
  // 每显示器 DPI 感知的程序换到另一块屏幕：宿主大小不变也要重画
  {
    ValidateRect(v2->host, nullptr);
    SendMessageW(v2->host, 0x02E3 /* WM_DPICHANGED_AFTERPARENT */, 0, 0);
    RECT ur;
    Check(GetUpdateRect(v2->host, &ur, FALSE) != FALSE, "card repaints when the parent's DPI changes");
  }
  // 窗口用对话框管理器（IsDialogMessage）处理按键时：方向键与回车交给卡片，Tab 由对话框管理器移到下一个控件
  {
    v2->errCode = WVERR_ENV_FAILED;
    v2->SetPanel(2);
    SetFocus(v2->host);
    if (OpenClipboard(nullptr)) {
      EmptyClipboard();
      CloseClipboard();
    }
    PostMessageW(v2->host, WM_KEYDOWN, VK_RIGHT, 1);
    PostMessageW(v2->host, WM_KEYDOWN, VK_RETURN, 1);
    auto pumpDlg = [&](DWORD ms) {
      DWORD t0 = GetTickCount();
      MSG m;
      while (GetTickCount() - t0 < ms) {
        while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE))
          if (!IsDialogMessageW(parent, &m)) {
            TranslateMessage(&m);
            DispatchMessageW(&m);
          }
        Sleep(5);
      }
    };
    pumpDlg(200);
    const bool entered = IsClipboardFormatAvailable(CF_UNICODETEXT) != FALSE;
    PostMessageW(v2->host, WM_KEYDOWN, VK_TAB, 1);
    pumpDlg(200);
    Check(entered && GetFocus() != v2->host, "keyboard works under a dialog manager: arrows and Enter reach the card, Tab moves on");
  }
  // 读屏软件经 MSAA 读到的名称就是卡片内容
  {
    static const IID kIidAccessible = {0x618736e0, 0x3c3d, 0x11cf, {0x81, 0x0c, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71}};
    IAccessible* acc = nullptr;
    AccessibleObjectFromWindow(v2->host, (DWORD)OBJID_CLIENT, kIidAccessible, (void**)&acc);
    BSTR name = nullptr;
    VARIANT self;
    VariantInit(&self);
    self.vt = VT_I4;
    self.lVal = CHILDID_SELF;
    if (acc) acc->get_accName(self, &name);
    const bool ok = name && wcsstr(name, L"网页组件没能启动") != nullptr;
    // 1.7.0：名称里还有按钮与键盘操作方法；方向键换了选中的按钮时，名称里的“当前选中”跟着变
    const bool lists = name && wcsstr(name, L"。按钮：") != nullptr && wcsstr(name, L"回车或空格执行") != nullptr && v2->panel.btnCount > 0 &&
                       wcsstr(name, v2->panel.btnText[0].c_str()) != nullptr;
    if (name) SysFreeString(name);
    name = nullptr;
    SetFocus(v2->host);  // WM_SETFOCUS、WM_KEYDOWN 都是同步送达，不必处理消息
    // 1.7.9：名称改变时发出 EVENT_OBJECT_NAMECHANGE，读屏软件才会重读（变异测试发现去掉通知也测不出来）
    g_nameChanges = 0;
    g_nameHost = v2->host;
    HWINEVENTHOOK weh = SetWinEventHook(EVENT_OBJECT_NAMECHANGE, EVENT_OBJECT_NAMECHANGE, nullptr, OnNameChange, GetCurrentProcessId(), 0, WINEVENT_OUTOFCONTEXT);
    SendMessageW(v2->host, WM_KEYDOWN, VK_HOME, 1);  // 先选第一个、再选最后一个：选中的按钮至少变一次（卡片有两个以上按钮）
    Pump(50);
    SendMessageW(v2->host, WM_KEYDOWN, VK_END, 1);
    Pump(100);
    if (weh) UnhookWinEvent(weh);
    if (acc) acc->get_accName(self, &name);
    const std::wstring last = v2->panel.btnCount > 0 ? L"当前选中：" + v2->panel.btnText[v2->panel.btnCount - 1] : std::wstring(L"?");
    const bool follows = name && wcsstr(name, last.c_str()) != nullptr;
    if (name) SysFreeString(name);
    if (acc) acc->Release();
    Check(ok, "screen readers get the card text through MSAA");
    Check(lists && follows, "the accessible name lists the card buttons with the keys to use and names the button selected with the keyboard");
    Check(weh && g_nameChanges >= 1, "changing the selected button raises a name-change event for screen readers", Fmt(L"%d", g_nameChanges));
  }
  // 1.7.2：高对比度主题下卡片改用系统配色（不画阴影）；顶层窗口收到系统配色改变时重画卡片、作废动画底图
  {
    g_testHighContrast = [] { return true; };
    const Theme hc = MakeTheme(RGB(32, 33, 36), true);
    const bool sys = hc.bg == GetSysColor(COLOR_WINDOW) && hc.card == hc.bg && hc.text == GetSysColor(COLOR_WINDOWTEXT) && hc.border == hc.text &&
                     hc.accent == GetSysColor(COLOR_HIGHLIGHT) && hc.onAccent == GetSysColor(COLOR_HIGHLIGHTTEXT) && hc.link == GetSysColor(COLOR_HOTLIGHT) &&
                     hc.faint == GetSysColor(COLOR_GRAYTEXT) && hc.shadow == hc.bg;
    g_testHighContrast = nullptr;
    const Theme normal = MakeTheme(RGB(32, 33, 36), true);
    v2->panel.animValid = true;
    const int mode = v2->panel.mode;
    SendMessageW(GetAncestor(v2->host, GA_ROOT), WM_SYSCOLORCHANGE, 0, 0);
    const bool afterColor = !v2->panel.animValid;
    // 1.7.9：主题改变、系统设置改变（打开或关闭高对比度时会收到）同样重画（变异测试发现只测了配色改变）
    v2->panel.animValid = true;
    SendMessageW(GetAncestor(v2->host, GA_ROOT), WM_SETTINGCHANGE, SPI_SETHIGHCONTRAST, 0);
    const bool afterSetting = !v2->panel.animValid;
    v2->panel.animValid = true;
    SendMessageW(GetAncestor(v2->host, GA_ROOT), WM_THEMECHANGED, 0, 0);
    const bool afterTheme = !v2->panel.animValid;
    Check(sys && normal.card != hc.card && mode != 0 && afterColor && afterSetting && afterTheme,
          "high contrast: the card uses the system colors without shadows, and repaints when the system colors, settings or theme change");
    // 1.7.9：高对比度下图标也用系统配色（变异测试发现只核对了配色表）：同一张错误卡片，平时画得出红色图标，高对比度时位图里没有这种红色
    auto redPixels = [&]() -> int {
      RECT rc;
      GetClientRect(v2->host, &rc);
      BITMAPINFO bi;
      ZeroMemory(&bi, sizeof(bi));
      bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
      bi.bmiHeader.biWidth = rc.right;
      bi.bmiHeader.biHeight = -rc.bottom;
      bi.bmiHeader.biPlanes = 1;
      bi.bmiHeader.biBitCount = 32;
      void* bits = nullptr;
      HDC wdc = GetDC(v2->host);
      HDC mem = CreateCompatibleDC(wdc);
      HBITMAP bmp = CreateDIBSection(wdc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
      HGDIOBJ old = SelectObject(mem, bmp);
      v2->Paint(mem);
      GdiFlush();
      int n = 0;
      const unsigned* px = static_cast<const unsigned*>(bits);
      for (long i = 0; bits && i < (long)rc.right * rc.bottom; ++i) {
        const int r = (px[i] >> 16) & 0xFF, g = (px[i] >> 8) & 0xFF, b = px[i] & 0xFF;
        if (abs(r - 239) <= 6 && abs(g - 68) <= 6 && abs(b - 68) <= 6) ++n;
      }
      SelectObject(mem, old);
      DeleteObject(bmp);
      DeleteDC(mem);
      ReleaseDC(v2->host, wdc);
      return n;
    };
    const int iconKind = v2->panel.icon, redNormal = redPixels();
    g_testHighContrast = [] { return true; };
    const int redHc = redPixels();
    g_testHighContrast = nullptr;
    Check(iconKind == 2 && redNormal > 50 && redHc == 0, "high contrast: the error icon is drawn in the text color, not red",
          Fmt(L"icon %d, red pixels %d normally, %d in high contrast", iconKind, redNormal, redHc));
  }
  // 选择文件夹对话框：显示我们的标题，取消时返回“没选”、不挂住
  {
    HANDLE th = CreateThread(nullptr, 0, CancelDialog, nullptr, 0, nullptr);
    std::wstring out;
    const bool picked = PickFolder(parent, out);
    WaitForSingleObject(th, 20000);
    CloseHandle(th);
    Check(!picked && out.empty() && g_dialogTitleOk == 1, "folder dialog shows our title and cancelling picks nothing", Fmt(L"title ok %ld", g_dialogTitleOk));
  }
  // GDI 泄漏：各种状态的整卡重画与动画帧之后，创建与释放的对象数必须相等
  {
    HDC wdc = GetDC(v2->host);
    HDC mem = ::CreateCompatibleDC(wdc);
    HBITMAP bmp = ::CreateCompatibleBitmap(wdc, 480, 600);
    HGDIOBJ old = SelectObject(mem, bmp);
    long n0 = g_gdiNew, d0 = g_gdiDel, c0 = g_dcNew, e0 = g_dcDel;
    InstallJob job;
    job.start = GetTickCount();
    job.stage = 3;
    g_job = &job;
    const int modes[] = {1, 2, 3, 4};
    for (int k = 0; k < 4; ++k) {
      v2->SetPanel(modes[k]);
      v2->panel.slowShown = v2->panel.hintShown = true;
      for (int i = 0; i < 150; ++i) v2->Paint(mem);
      for (int i = 0; i < 3000; ++i) {
        ++v2->panel.tick;
        v2->PaintAnim(mem);
      }
    }
    job.done = 1;
    g_job = nullptr;
    long made = g_gdiNew - n0, freed = g_gdiDel - d0, dcs = g_dcNew - c0, dcsFreed = g_dcDel - e0;
    Check(made > 1000 && made == freed && dcs == dcsFreed, "600 full repaints and 12000 animation frames free every GDI object and DC they create",
          Fmt(L"objects %ld/%ld, DCs %ld/%ld", made, freed, dcs, dcsFreed));
    SelectObject(mem, old);
    ::DeleteObject(bmp);
    ::DeleteDC(mem);
    ReleaseDC(v2->host, wdc);
  }
  WV_Destroy(h1);
  WV_Destroy(h2);
  Pump(50);
  DestroyWindow(parent);
  g_os.legacy = realLegacy;
  printf("RESULT pass=%d fail=%d\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
