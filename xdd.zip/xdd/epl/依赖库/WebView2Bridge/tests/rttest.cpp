// 运行时发现规则测试：注册表里的已安装常青版、程序目录的固定版、运行时策略、环境变量、Win7 的 109 限制、一键安装的失败处理
// 在没有 WebView2 运行时的环境（如 Wine）中运行：rttest.exe（Win10 规则）、rttest.exe win7（需把系统版本设为 Win7）、rttest.exe install
#include <windows.h>
#include <cstdio>
#include <cstring>
#include <string>
#include "wv2bridge.h"
static HMODULE g_dll;
static int g_pass, g_fail;
#define FN(name) static decltype(&name) p_##name;
#define LOAD(name) p_##name = reinterpret_cast<decltype(&name)>(reinterpret_cast<void*>(GetProcAddress(g_dll, #name)));
FN(WV_SetOption) FN(WV_RuntimeCheck) FN(WV_RuntimeInfo) FN(WV_JsonGet) FN(WV_InstallRuntime) FN(WV_LastErrorCode) FN(WV_LastError)
static void Check(bool c, const char* n, const std::string& got = "") {
  if (c) { ++g_pass; printf("PASS %s\n", n); } else { ++g_fail; printf("FAIL %s  [%s]\n", n, got.c_str()); }
  fflush(stdout);
}
static std::string A(const std::wstring& w) { int n = WideCharToMultiByte(936, 0, w.c_str(), -1, nullptr, 0, nullptr, nullptr); std::string s(n, 0); WideCharToMultiByte(936, 0, w.c_str(), -1, &s[0], n, nullptr, nullptr); s.resize(n - 1); return s; }
static std::wstring ExeDir() { wchar_t b[MAX_PATH]; GetModuleFileNameW(nullptr, b, MAX_PATH); std::wstring s(b); return s.substr(0, s.find_last_of(L"\\/")); }
static std::wstring Env(const wchar_t* n) { wchar_t b[MAX_PATH] = {0}; GetEnvironmentVariableW(n, b, MAX_PATH); return b; }
static void MkDirs(const std::wstring& p) { for (size_t i = 3; i <= p.size(); ++i) if (i == p.size() || p[i] == L'\\') CreateDirectoryW(p.substr(0, i).c_str(), nullptr); }
static void PutFile(const std::wstring& f, const void* data, DWORD n) { HANDLE h = CreateFileW(f.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr); if (h != INVALID_HANDLE_VALUE) { DWORD w = 0; if (n) WriteFile(h, data, n, &w, nullptr); CloseHandle(h); } }
// 1.8.0 起查找运行时还要看浏览器进程、它启动时载入的两个 DLL（开头是 MZ）与 ICU 数据文件（开头 4 字节是 ICU 数据头）
static void MkRtFiles(const std::wstring& dir) {
  for (auto n : {L"\\msedgewebview2.exe", L"\\msedge_elf.dll", L"\\msedge.dll"}) PutFile(dir + n, "MZ", 2);
  static const unsigned char icu[16] = {0x90, 0x00, 0xDA, 0x27};
  PutFile(dir + L"\\icudtl.dat", icu, sizeof(icu));
}
static void MkRt(const std::wstring& dir) {
  MkDirs(dir + L"\\EBWebView\\x86");
  PutFile(dir + L"\\EBWebView\\x86\\EmbeddedBrowserWebView.dll", "", 0);
  MkRtFiles(dir);
}
static const wchar_t* kStable = L"{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}";
static const wchar_t* kBeta = L"{2CD8A007-E189-409D-A2C8-9AF4EF3C72AA}";
static void RegSet(HKEY root, const std::wstring& sub, const wchar_t* name, const std::wstring& val) {
  HKEY k = nullptr;
  if (RegCreateKeyExW(root, sub.c_str(), 0, nullptr, 0, KEY_WRITE | KEY_WOW64_32KEY, nullptr, &k, nullptr) != ERROR_SUCCESS) { printf("RegCreateKeyEx failed\n"); return; }
  RegSetValueExW(k, name, 0, REG_SZ, reinterpret_cast<const BYTE*>(val.c_str()), (DWORD)((val.size() + 1) * sizeof(wchar_t)));
  RegCloseKey(k);
}
static void RegSetExpand(HKEY root, const std::wstring& sub, const wchar_t* name, const std::wstring& val) {
  HKEY k = nullptr;
  if (RegCreateKeyExW(root, sub.c_str(), 0, nullptr, 0, KEY_WRITE | KEY_WOW64_32KEY, nullptr, &k, nullptr) != ERROR_SUCCESS) return;
  RegSetValueExW(k, name, 0, REG_EXPAND_SZ, reinterpret_cast<const BYTE*>(val.c_str()), (DWORD)((val.size() + 1) * sizeof(wchar_t)));
  RegCloseKey(k);
}
static void RegClear() {
  for (HKEY root : {HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER}) {
    HKEY k = nullptr;
    if (RegOpenKeyExW(root, L"SOFTWARE\\Microsoft", 0, KEY_ALL_ACCESS | KEY_WOW64_32KEY, &k) == ERROR_SUCCESS) { RegDeleteTreeW(k, L"EdgeUpdate"); RegCloseKey(k); }
  }
}
// 组策略（64 位注册表视图，与组策略编辑器写入的位置相同）
static void PolSet(HKEY root, const wchar_t* key, const wchar_t* name, const std::wstring& val) {
  HKEY k = nullptr;
  if (RegCreateKeyExW(root, (std::wstring(L"Software\\Policies\\Microsoft\\Edge\\WebView2\\") + key).c_str(), 0, nullptr, 0, KEY_WRITE | KEY_WOW64_64KEY, nullptr, &k,
                      nullptr) != ERROR_SUCCESS) { printf("RegCreateKeyEx failed\n"); return; }
  RegSetValueExW(k, name, 0, REG_SZ, reinterpret_cast<const BYTE*>(val.c_str()), (DWORD)((val.size() + 1) * sizeof(wchar_t)));
  RegCloseKey(k);
}
static void PolClear() {
  for (HKEY root : {HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER}) {
    HKEY k = nullptr;
    if (RegOpenKeyExW(root, L"Software\\Policies\\Microsoft", 0, KEY_ALL_ACCESS | KEY_WOW64_64KEY, &k) == ERROR_SUCCESS) { RegDeleteTreeW(k, L"Edge"); RegCloseKey(k); }
  }
}
static std::string Info() { p_WV_RuntimeCheck(1); return p_WV_RuntimeInfo(); }
// 安装测试按断网设计：把本用户的 WinINet 代理临时指到不存在的地址，即使机器能联网也不会真的下载、安装（Windows 7 模式下要下载的是约 132MB 的
// 离线安装包，再在 Wine 里运行微软的安装程序）。结束时恢复原来的设置
struct OfflineProxy {
  const wchar_t* key = L"Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings";
  DWORD oldEnable = 0, haveEnable = 0;
  wchar_t oldServer[512] = {0};
  DWORD haveServer = 0;
  OfflineProxy() {
    HKEY k = nullptr;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, key, 0, nullptr, 0, KEY_READ | KEY_WRITE, nullptr, &k, nullptr) != ERROR_SUCCESS) return;
    DWORD n = sizeof(oldEnable);
    haveEnable = RegQueryValueExW(k, L"ProxyEnable", nullptr, nullptr, reinterpret_cast<LPBYTE>(&oldEnable), &n) == ERROR_SUCCESS;
    n = sizeof(oldServer) - sizeof(wchar_t);
    haveServer = RegQueryValueExW(k, L"ProxyServer", nullptr, nullptr, reinterpret_cast<LPBYTE>(oldServer), &n) == ERROR_SUCCESS;
    const DWORD one = 1;
    const wchar_t dead[] = L"127.0.0.1:9";
    RegSetValueExW(k, L"ProxyEnable", 0, REG_DWORD, reinterpret_cast<const BYTE*>(&one), sizeof(one));
    RegSetValueExW(k, L"ProxyServer", 0, REG_SZ, reinterpret_cast<const BYTE*>(dead), sizeof(dead));
    RegCloseKey(k);
  }
  ~OfflineProxy() {
    HKEY k = nullptr;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, key, 0, KEY_WRITE, &k) != ERROR_SUCCESS) return;
    if (haveEnable) RegSetValueExW(k, L"ProxyEnable", 0, REG_DWORD, reinterpret_cast<const BYTE*>(&oldEnable), sizeof(oldEnable));
    else RegDeleteValueW(k, L"ProxyEnable");
    if (haveServer) RegSetValueExW(k, L"ProxyServer", 0, REG_SZ, reinterpret_cast<const BYTE*>(oldServer), (DWORD)((wcslen(oldServer) + 1) * sizeof(wchar_t)));
    else RegDeleteValueW(k, L"ProxyServer");
    RegCloseKey(k);
  }
};
static std::string J(const std::string& js, const char* path) { return p_WV_JsonGet(js.c_str(), path); }
static void Policy(int n) { char b[8]; sprintf(b, "%d", n); p_WV_SetOption(WVO_RUNTIME_POLICY, b); }
int main(int argc, char** argv) {
  g_dll = LoadLibraryW(L"WebView2Bridge.dll");
  LOAD(WV_SetOption) LOAD(WV_RuntimeCheck) LOAD(WV_RuntimeInfo) LOAD(WV_JsonGet) LOAD(WV_InstallRuntime) LOAD(WV_LastErrorCode) LOAD(WV_LastError)
  p_WV_SetOption(WVO_CODEPAGE, "936");
  std::string mode = argc > 1 ? argv[1] : "win10";
  if (mode == "install") {
    OfflineProxy offline;
    DWORD t0 = GetTickCount(); int r = p_WV_InstallRuntime(0, 120000); int e = p_WV_LastErrorCode(); std::string m = p_WV_LastError(); DWORD el = GetTickCount() - t0;
    printf("INFO install -> %d, code %d, %lu ms, message: %s\n", r, e, el, m.c_str());
    Check(r == 0 && e == WVERR_INSTALL && !m.empty(), "one-click install without network fails with WVERR_INSTALL and a reason", m);
    // 1.8.0：系统有微软当前安装程序要用的函数时都去下载安装（Wine 的 kernel32 总有，真实 Windows 7 没有时的处理见 helpertest）；
    // 程序自动发起的安装（WVI_AUTO）在上次失败后 24 小时内直接失败，用户点的不受影响
    Check(m.find(A(L"\u4E0D\u80FD\u5B89\u88C5")) == std::string::npos, "install is attempted wherever Microsoft's current installer can start", m);
    t0 = GetTickCount(); r = p_WV_InstallRuntime(WVI_AUTO, 120000); e = p_WV_LastErrorCode(); m = p_WV_LastError(); el = GetTickCount() - t0;
    Check(r == 0 && e == WVERR_INSTALL && el < 3000 && m.find(A(L"24 \u5C0F\u65F6")) != std::string::npos, "an automatic install within 24 hours of a failure returns at once with the earlier reason", m);
    RegDeleteKeyW(HKEY_CURRENT_USER, L"Software\\WebView2Bridge");
    { wchar_t tp[MAX_PATH] = {0}; GetTempPathW(MAX_PATH, tp); WIN32_FIND_DATAW fd; int left = 0, dirs = 0;
      HANDLE fh = FindFirstFileW((std::wstring(tp) + L"MicrosoftEdgeWebview2Setup*.exe").c_str(), &fd);
      if (fh != INVALID_HANDLE_VALUE) { do ++left; while (FindNextFileW(fh, &fd)); FindClose(fh); }
      fh = FindFirstFileW((std::wstring(tp) + L"wv2setup_*").c_str(), &fd);  // 1.4.0 起引导程序下载到本次新建的专用子目录
      if (fh != INVALID_HANDLE_VALUE) { do ++dirs; while (FindNextFileW(fh, &fd)); FindClose(fh); }
      Check(left == 0, "a failed install leaves no bootstrapper in the temp folder", std::to_string(left));
      Check(dirs == 0, "a failed install leaves no private download folder in the temp folder", std::to_string(dirs)); }
    printf("RESULT pass=%d fail=%d\n", g_pass, g_fail); return g_fail ? 1 : 0;
  }
  std::wstring pf = Env(L"ProgramFiles(x86)"); if (pf.empty()) pf = Env(L"ProgramFiles");
  std::wstring inst121 = pf + L"\\Microsoft\\EdgeWebView\\Application\\121.0.2277.83", inst109 = pf + L"\\Microsoft\\EdgeWebView\\Application\\109.0.1518.140";
  std::wstring beta122 = pf + L"\\Microsoft\\Edge Beta\\Application\\122.0.2365.16", app = ExeDir() + L"\\rtapp", app2 = ExeDir() + L"\\rtapp2", empty = ExeDir() + L"\\rtempty";
  std::wstring fixed120 = app + L"\\WebView2\\Microsoft.WebView2.FixedVersionRuntime.120.0.2210.91.x86", fixed109 = app + L"\\WebView2\\Microsoft.WebView2.FixedVersionRuntime.109.0.1518.140.x86";
  MkRt(inst121); MkRt(inst109); MkRt(beta122); MkRt(fixed120); MkRt(app2 + L"\\WebView2"); MkDirs(empty);
  const std::wstring CS = L"SOFTWARE\\Microsoft\\EdgeUpdate\\ClientState\\", CL = L"SOFTWARE\\Microsoft\\EdgeUpdate\\Clients\\";
  RegClear(); SetEnvironmentVariableW(L"WEBVIEW2_BROWSER_EXECUTABLE_FOLDER", nullptr);
  p_WV_SetOption(WVO_APP_DIR, A(app).c_str());
  if (mode == "win10") {
    RegSet(HKEY_LOCAL_MACHINE, CS + kStable, L"EBWebView", inst121);
    Policy(0); std::string s = Info();
    Check(J(s, "legacyOs") == "false", "Win10 mode", J(s, "os"));
    Check(J(s, "selected.kind") == "installed" && J(s, "selected.version") == "121.0.2277.83" && J(s, "selected.source").find("ClientState") != std::string::npos,
          "auto policy prefers the installed evergreen runtime found in the 32-bit registry view", J(s, "selected.source"));
    Policy(1); s = Info(); Check(J(s, "selected.kind") == "fixed" && J(s, "selected.version") == "120.0.2210.91", "policy 1 prefers the fixed runtime", J(s, "selected.version"));
    Policy(2); s = Info(); Check(J(s, "selected.kind") == "installed", "policy 2 uses the installed runtime only", J(s, "selected.kind"));
    Policy(3); s = Info(); Check(J(s, "selected.kind") == "fixed", "policy 3 uses the fixed runtime only", J(s, "selected.kind"));
    Policy(0); RegClear(); RegSet(HKEY_LOCAL_MACHINE, CL + kStable, L"pv", L"121.0.2277.83"); s = Info();
    Check(J(s, "selected.kind") == "installed" && J(s, "selected.source").find("pv") != std::string::npos && J(s, "selected.dir") == A(inst121), "Clients pv plus default install folder", J(s, "selected.dir"));
    RegSet(HKEY_LOCAL_MACHINE, CL + kStable, L"pv", L"0.0.0.0"); s = Info();
    Check(J(s, "selected.kind") == "fixed", "pv 0.0.0.0 (uninstalled) is ignored", J(s, "selected.kind"));
    RegClear(); RegSet(HKEY_CURRENT_USER, CS + kStable, L"EBWebView", inst121); s = Info();
    Check(J(s, "selected.kind") == "installed" && J(s, "selected.source").find("HKCU") != std::string::npos, "per-user install (HKCU)", J(s, "selected.source"));
    RegClear(); RegSet(HKEY_LOCAL_MACHINE, CS + kBeta, L"EBWebView", beta122); Policy(2); s = Info();
    Check(J(s, "selected.kind") == "installed" && J(s, "selected.version") == "122.0.2365.16", "beta channel used when it is the only installed one", J(s, "selected.version"));
    RegSet(HKEY_LOCAL_MACHINE, CS + kStable, L"EBWebView", inst121); s = Info();
    Check(J(s, "selected.version") == "121.0.2277.83", "stable channel preferred over a newer beta", J(s, "selected.version"));
    Policy(0); SetEnvironmentVariableW(L"WEBVIEW2_BROWSER_EXECUTABLE_FOLDER", fixed120.c_str()); s = Info();
    Check(J(s, "selected.kind") == "fixed" && J(s, "selected.dir") == A(fixed120), "WEBVIEW2_BROWSER_EXECUTABLE_FOLDER overrides discovery", J(s, "selected.dir"));
    SetEnvironmentVariableW(L"WEBVIEW2_BROWSER_EXECUTABLE_FOLDER", nullptr); RegClear();
    RegSetExpand(HKEY_LOCAL_MACHINE, CS + kStable, L"EBWebView", (Env(L"ProgramFiles(x86)").empty() ? L"%ProgramFiles%" : L"%ProgramFiles(x86)%") + std::wstring(L"\\Microsoft\\EdgeWebView\\Application\\121.0.2277.83"));
    s = Info(); Check(J(s, "selected.kind") == "installed" && J(s, "selected.dir") == A(inst121), "REG_EXPAND_SZ path with environment variables is expanded", J(s, "selected.dir"));
    p_WV_SetOption(WVO_RUNTIME_DIR, "WebView2"); s = Info();
    Check(J(s, "selected.kind") == "fixed" && J(s, "selected.dir") == A(fixed120), "relative runtime folder option resolved against the program folder", J(s, "selected.dir"));
    p_WV_SetOption(WVO_RUNTIME_DIR, ""); RegClear();
    p_WV_SetOption(WVO_APP_DIR, A(app2).c_str()); s = Info();
    Check(J(s, "found") == "true" && J(s, "selected.dir") == A(app2 + L"\\WebView2"), "runtime unpacked directly as a WebView2 folder is found", J(s, "selected.dir"));
    p_WV_SetOption(WVO_APP_DIR, A(empty).c_str()); s = Info();
    Check(J(s, "found") == "false" && !J(s, "reason").empty(), "nothing anywhere: not found, with a reason", J(s, "reason"));
    // 1.5.0：官方加载器的覆盖规则：组策略（HKLM 再 HKCU；值名为程序文件名或 *）与环境变量（有任何一个时不看组策略）
    {
      PolClear(); RegClear();
      RegSet(HKEY_LOCAL_MACHINE, CS + kStable, L"EBWebView", inst121);
      RegSet(HKEY_LOCAL_MACHINE, CS + kBeta, L"EBWebView", beta122);
      p_WV_SetOption(WVO_APP_DIR, A(app).c_str()); Policy(2);
      s = Info();
      Check(J(s, "selected.version") == "121.0.2277.83" && J(s, "override").empty(), "channel order: stable first, no override without variables or policies", J(s, "selected.version"));
      PolSet(HKEY_CURRENT_USER, L"ReleaseChannelPreference", L"*", L"1"); s = Info();
      Check(J(s, "selected.version") == "122.0.2365.16" && J(s, "override.source").find("HKCU") != std::string::npos && J(s, "override.channelPreference") == "1",
            "policy ReleaseChannelPreference=1 reverses the channel order (beta before stable)", J(s, "selected.version") + " " + J(s, "override.source"));
      SetEnvironmentVariableW(L"WEBVIEW2_RELEASE_CHANNEL_PREFERENCE", L"0"); s = Info();
      Check(J(s, "selected.version") == "121.0.2277.83" && J(s, "override.channelPreference") == "0" && J(s, "override.source").find("HKCU") == std::string::npos,
            "an environment variable wins: the policy registry is not read when any WEBVIEW2_ variable is set", J(s, "override.source"));
      SetEnvironmentVariableW(L"WEBVIEW2_RELEASE_CHANNEL_PREFERENCE", nullptr); PolClear();
      Policy(0); p_WV_SetOption(WVO_RUNTIME_DIR, "WebView2");  // 程序自己指定了运行时目录（其中是固定版 120）
      PolSet(HKEY_LOCAL_MACHINE, L"BrowserExecutableFolder", L"rttest.exe", inst121); s = Info();
      Check(J(s, "selected.dir") == A(inst121) && J(s, "override.source").find("rttest.exe") != std::string::npos,
            "policy BrowserExecutableFolder for this program overrides the program's own runtime folder", J(s, "selected.dir"));
      PolClear(); s = Info();
      Check(J(s, "selected.dir") == A(fixed120), "without the policy the program's own runtime folder is used again", J(s, "selected.dir"));
      // 1.8.0：文件不完整的运行时不采用，原因写进 reason 与 broken；文件只是暂时被独占打开时照常采用（创建环境之前再查）
      {
        const std::wstring bad = ExeDir() + L"\\rtbad", badRt = bad + L"\\WebView2";
        MkRt(badRt); DeleteFileW((badRt + L"\\icudtl.dat").c_str());
        RegClear(); p_WV_SetOption(WVO_APP_DIR, A(bad).c_str()); s = Info();
        Check(J(s, "found") == "false" && J(s, "reason").find("icudtl.dat") != std::string::npos && J(s, "broken[0].reason").find("icudtl.dat") != std::string::npos,
              "a runtime without icudtl.dat is not used and the reason names the file", J(s, "reason"));
        PutFile(badRt + L"\\icudtl.dat", "", 0); s = Info();
        Check(J(s, "found") == "false" && J(s, "broken[0].reason").find(A(L"\u7A7A\u6587\u4EF6")) != std::string::npos, "an empty icudtl.dat is reported as empty", J(s, "broken[0].reason"));
        MkRtFiles(badRt); DeleteFileW((badRt + L"\\msedge_elf.dll").c_str()); s = Info();
        Check(J(s, "found") == "false" && J(s, "broken[0].reason").find("msedge_elf.dll") != std::string::npos, "a runtime without msedge_elf.dll is not used", J(s, "broken[0].reason"));
        MkRtFiles(badRt); PutFile(badRt + L"\\msedge.dll", "", 0); s = Info();
        Check(J(s, "found") == "false" && J(s, "broken[0].reason").find("msedge.dll") != std::string::npos, "a runtime whose msedge.dll is empty is not used", J(s, "broken[0].reason"));
        MkRtFiles(badRt); PutFile(badRt + L"\\msedgewebview2.exe", "XX", 2); s = Info();
        Check(J(s, "found") == "false" && J(s, "broken[0].reason").find("msedgewebview2.exe") != std::string::npos, "a runtime whose msedgewebview2.exe is not a PE file is not used", J(s, "broken[0].reason"));
        MkRtFiles(badRt); s = Info();
        Check(J(s, "found") == "true" && J(s, "selected.dir") == A(badRt) && J(s, "broken").empty(), "the repaired runtime is used again", J(s, "selected.dir"));
        HANDLE lk = CreateFileW((badRt + L"\\icudtl.dat").c_str(), GENERIC_READ, 0, nullptr, OPEN_EXISTING, 0, nullptr); s = Info();
        Check(J(s, "found") == "true", "a briefly locked icudtl.dat does not exclude the runtime at discovery", J(s, "reason"));
        if (lk != INVALID_HANDLE_VALUE) CloseHandle(lk);
        p_WV_SetOption(WVO_APP_DIR, A(app).c_str());
      }
      // 1.5.1：Microsoft Edge 浏览器自己的安装目录不能当作运行时（与官方加载器一致）
      const std::wstring edgeApp = ExeDir() + L"\\rtedge\\Microsoft\\Edge\\Application";
      MkRt(edgeApp + L"\\120.0.2210.91");
      p_WV_SetOption(WVO_RUNTIME_DIR, A(edgeApp).c_str()); s = Info();
      Check(J(s, "found") == "false" && J(s, "reason").find("Edge") != std::string::npos, "the Microsoft Edge browser's own install folder is not used as a WebView2 runtime", J(s, "reason"));
      p_WV_SetOption(WVO_RUNTIME_DIR, ""); RegClear();
    }
  } else {
    MkRt(fixed109);
    RegSet(HKEY_LOCAL_MACHINE, CS + kStable, L"EBWebView", inst121);
    Policy(0); std::string s = Info();
    Check(J(s, "legacyOs") == "true", "Win7 mode", J(s, "os"));
    Check(J(s, "selected.kind") == "fixed" && J(s, "selected.version") == "109.0.1518.140", "Win7: installed 121 skipped, fixed 109 used", J(s, "selected.version"));
    p_WV_SetOption(WVO_APP_DIR, A(empty).c_str()); s = Info();
    Check(J(s, "found") == "false" && J(s, "reason").find("109") != std::string::npos, "Win7 with only a newer installed runtime: not found, reason mentions 109", J(s, "reason"));
    RegSet(HKEY_LOCAL_MACHINE, CS + kStable, L"EBWebView", inst109); s = Info();
    Check(J(s, "selected.kind") == "installed" && J(s, "selected.version") == "109.0.1518.140", "Win7 with installed 109: used", J(s, "selected.version"));
    // 1.8.0：程序目录里有固定版 109、系统里也装了 109 时先用已安装的（原来先用固定版：固定版坏了时装好的常青版也用不上）
    p_WV_SetOption(WVO_APP_DIR, A(app).c_str()); s = Info();
    Check(J(s, "selected.kind") == "installed", "Win7: installed 109 is preferred over the fixed 109 in the program folder", J(s, "selected.source"));
  }
  RegClear();
  printf("RESULT pass=%d fail=%d\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
