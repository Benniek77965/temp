// pintest.cpp : 1.8.3 数据目录沿用运行时（同一数据目录同一时刻只能被一个版本的浏览器进程使用）
// 两个模拟运行时 R1（120）与 R2（121），各带自己的一份模拟内核 DLL：哪个运行时的 DLL 被载入，就说明在它上面建过环境。
//  1) 数据目录上还有浏览器在用 R1 的环境时，运行时改选 R2 后新建的浏览器沿用 R1 的环境（不报冲突、不在 R2 上建环境）
//  2) 这些浏览器都关闭后再新建，改用 R2
//  3) 反向对照：差的不只是运行时（浏览器参数也不同）时，指定了数据目录照旧报冲突
#include <windows.h>
#include <cstdio>
#include <string>
#include "wv2bridge.h"
static HMODULE g_dll;
static int g_pass, g_fail;
static void Check(bool c, const char* n, const std::string& got = "") {
  if (c) { ++g_pass; printf("PASS %s\n", n); } else { ++g_fail; printf("FAIL %s  [%s]\n", n, got.c_str()); }
  fflush(stdout);
}
#define FN(name) static decltype(&name) p_##name;
#define LOAD(name) p_##name = reinterpret_cast<decltype(&name)>(reinterpret_cast<void*>(GetProcAddress(g_dll, #name)));
FN(WV_SetOption) FN(WV_RuntimeCheck) FN(WV_CreateAsync) FN(WV_WaitReady) FN(WV_Destroy) FN(WV_LastErrorCode) FN(WV_LastError)
static std::wstring ExeDir() { wchar_t b[MAX_PATH]; GetModuleFileNameW(nullptr, b, MAX_PATH); std::wstring s(b); return s.substr(0, s.find_last_of(L"\\/")); }
static std::string A(const std::wstring& w) { std::string s; for (wchar_t c : w) s += c < 128 ? (char)c : '?'; return s; }
static void Pump(DWORD ms) {
  DWORD t = GetTickCount(); MSG m;
  while (GetTickCount() - t < ms) { while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); } Sleep(5); }
}
static void MockRtFiles(const std::wstring& d) {
  static const unsigned char icu[16] = {0x90, 0x00, 0xDA, 0x27};
  const struct { const wchar_t* name; const void* data; DWORD n; } files[] = {
      {L"\\msedgewebview2.exe", "MZ", 2}, {L"\\msedge_elf.dll", "MZ", 2}, {L"\\msedge.dll", "MZ", 2}, {L"\\icudtl.dat", icu, sizeof(icu)}};
  for (const auto& f : files) {
    HANDLE h = CreateFileW((d + f.name).c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
    if (h == INVALID_HANDLE_VALUE) continue;
    DWORD w = 0; WriteFile(h, f.data, f.n, &w, nullptr); CloseHandle(h);
  }
}
static std::wstring MakeRt(const std::wstring& app, const wchar_t* ver) {
  std::wstring rt = app + L"\\WebView2\\Microsoft.WebView2.FixedVersionRuntime." + ver + L".x86";
  for (auto d : {app, app + L"\\WebView2", rt, rt + L"\\EBWebView", rt + L"\\EBWebView\\x86"}) CreateDirectoryW(d.c_str(), nullptr);
  CopyFileW((ExeDir() + L"\\mockwv.dll").c_str(), (rt + L"\\EBWebView\\x86\\EmbeddedBrowserWebView.dll").c_str(), FALSE);
  MockRtFiles(rt);
  return rt;
}
static bool Loaded(const std::wstring& rt) { return GetModuleHandleW((rt + L"\\EBWebView\\x86\\EmbeddedBrowserWebView.dll").c_str()) != nullptr; }
static std::string LogText(const std::wstring& path) {  // 日志按 UTF-8 写
  HANDLE h = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
  if (h == INVALID_HANDLE_VALUE) return "";
  std::string s; char buf[65536]; DWORD n = 0;
  while (ReadFile(h, buf, sizeof(buf), &n, nullptr) && n) s.append(buf, n);
  CloseHandle(h);
  return s;
}
static bool Has(const std::string& log, const wchar_t* w) {  // 日志可能是 UTF-8 或 UTF-16LE：两种都找
  int n = WideCharToMultiByte(CP_UTF8, 0, w, -1, nullptr, 0, nullptr, nullptr); std::string u(n > 0 ? n - 1 : 0, '\0');
  if (n > 1) WideCharToMultiByte(CP_UTF8, 0, w, -1, &u[0], n, nullptr, nullptr);
  std::string w16((const char*)w, wcslen(w) * 2);
  return log.find(u) != std::string::npos || log.find(w16) != std::string::npos;
}
static std::string U8(const wchar_t* w) { int n = WideCharToMultiByte(CP_UTF8, 0, w, -1, nullptr, 0, nullptr, nullptr); std::string s(n > 0 ? n - 1 : 0, '\0'); if (n > 1) WideCharToMultiByte(CP_UTF8, 0, w, -1, &s[0], n, nullptr, nullptr); return s; }
static int Create(HWND parent) { return p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://a.test/", "", nullptr); }

int wmain() {
  std::wstring app = ExeDir() + L"\\pinapp";
  std::wstring r1 = MakeRt(app, L"120.0.0.1"), r2 = MakeRt(app, L"121.0.0.1");
  std::wstring udf = app + L"\\UI", logW = ExeDir() + L"\\pin.log";
  DeleteFileW(logW.c_str());
  g_dll = LoadLibraryW(L"WebView2Bridge.dll");
  if (!g_dll) { printf("FAIL load bridge\n"); return 2; }
  LOAD(WV_SetOption) LOAD(WV_RuntimeCheck) LOAD(WV_CreateAsync) LOAD(WV_WaitReady) LOAD(WV_Destroy) LOAD(WV_LastErrorCode) LOAD(WV_LastError)
  p_WV_SetOption(WVO_APP_DIR, A(app).c_str());
  p_WV_SetOption(WVO_LOG_FILE, A(logW).c_str());
  p_WV_SetOption(WVO_USER_DATA_DIR, A(udf).c_str());  // 指定了数据目录：参数不同时报冲突（不自动隔离）——本程序就是这样用的
  p_WV_SetOption(WVO_RUNTIME_DIR, A(r1).c_str());
  Check(p_WV_RuntimeCheck(1) == 1, "R1 selected by scan");
  WNDCLASSW wc = {}; wc.lpfnWndProc = DefWindowProcW; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"PinParent"; RegisterClassW(&wc);
  HWND parent = CreateWindowExW(0, L"PinParent", L"p", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 640, 480, nullptr, nullptr, wc.hInstance, nullptr);

  int a = Create(parent);
  Check(a > 0 && p_WV_WaitReady(a, 5000) == 1, "view A ready on R1", p_WV_LastError());
  Check(Loaded(r1) && !Loaded(r2), "A's environment is on R1");

  // 常青版在运行中更新：再查一次运行时，选到 R2
  p_WV_SetOption(WVO_RUNTIME_DIR, A(r2).c_str());
  Check(p_WV_RuntimeCheck(1) == 1, "R2 selected by rescan");
  int b = Create(parent);
  int wb = p_WV_WaitReady(b, 5000);
  Check(b > 0 && wb == 1, "view B ready although the selection moved to R2 (no DATA_CONFLICT)", std::to_string(wb) + " " + p_WV_LastError());
  Check(!Loaded(r2), "B reused A's R1 environment (nothing created on R2 while A uses the data dir)");
  Pump(200);
  Check(Has(LogText(logW), L"新浏览器沿用它"), "pinning logged");

  // 都关闭后再新建：改用 R2
  p_WV_Destroy(b); p_WV_Destroy(a);
  Pump(500);
  int c = Create(parent);
  int wc2 = p_WV_WaitReady(c, 5000);
  Check(c > 0 && wc2 == 1, "view C ready after all R1 views closed", std::to_string(wc2) + " " + p_WV_LastError());
  Check(Loaded(r2), "C's environment is on R2 (the new runtime takes over the data dir)");
  Check(Has(LogText(logW), L"改用新选的运行时"), "switch logged");

  // 反向对照：浏览器参数也不同（不只差运行时）：照旧报冲突
  p_WV_SetOption(WVO_BROWSER_ARGS, "--pin-other");
  int d = Create(parent);
  int wd = p_WV_WaitReady(d, 3000);
  Pump(200);
  int ed = p_WV_LastErrorCode();
  Check(wd != 1 && (ed == WVERR_DATA_CONFLICT || Has(LogText(logW), L"已被启动参数")), "different browser args still conflict on an explicit data dir",
        std::to_string(wd) + " code=" + std::to_string(ed) + " " + p_WV_LastError());
  p_WV_Destroy(d); p_WV_Destroy(c);
  Pump(200);
  printf("RESULT pass=%d fail=%d\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
