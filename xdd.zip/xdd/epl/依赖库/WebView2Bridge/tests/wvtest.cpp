#include <windows.h>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <string>
#include <thread>
#include <atomic>
#include <vector>
#include "wv2bridge.h"
static HMODULE g_dll;
static int g_pass = 0, g_fail = 0;
static void Check(bool c, const char* name, const std::string& got = std::string()) {
  if (c) { ++g_pass; printf("PASS %s\n", name); } else { ++g_fail; printf("FAIL %s  [got: %s]\n", name, got.c_str()); }
  fflush(stdout);
}
template <class F> static F Fn(const char* n) {
  F f = reinterpret_cast<F>(reinterpret_cast<void*>(GetProcAddress(g_dll, n)));
  if (!f) { printf("MISSING %s\n", n); exit(3); }
  return f;
}
static std::string Gbk(const wchar_t* w) {
  int n = WideCharToMultiByte(936, 0, w, -1, nullptr, 0, nullptr, nullptr);
  std::string s(n, '\0');
  WideCharToMultiByte(936, 0, w, -1, &s[0], n, nullptr, nullptr);
  s.resize(n - 1);
  return s;
}
static std::string Hex(const std::string& s) {
  std::string o; char b[4];
  for (unsigned char c : s) { if (c >= 0x20 && c < 0x7F) o += (char)c; else { sprintf(b, "\\x%02X", c); o += b; } }
  return o;
}
static decltype(&WV_GetVersion) pVer;
static decltype(&WV_GetVersionText) pVerText;
static decltype(&WV_SetOption) pSetOpt;
static decltype(&WV_GetOption) pGetOpt;
static decltype(&WV_RuntimeCheck) pRtCheck;
static decltype(&WV_RuntimeInfo) pRtInfo;
static decltype(&WV_GetDiagnostics) pDiag;
static decltype(&WV_LastErrorCode) pErrCode;
static decltype(&WV_LastError) pErr;
static decltype(&WV_JsonQuote) pQuote;
static decltype(&WV_JsonGet) pJsonGet;
static decltype(&WV_CreateAsync) pCreateA;
static decltype(&WV_Create) pCreate;
static decltype(&WV_Destroy) pDestroy;
static decltype(&WV_IsReady) pIsReady;
static decltype(&WV_GetWindow) pGetWin;
static std::atomic<int> g_ready{0}, g_readyOk{-1}, g_ready0{0}, g_destroyInCb{0};
static void WINAPI OnReady(int h, int ok) { (void)h; g_readyOk = ok; ++g_ready; }
static void WINAPI OnReadyNoArgs() { ++g_ready0; }                 // 参数个数写少：stdcall 被调方只弹 0 字节
static void WINAPI OnReadyExtra(int, int, int, int, int, int) { ++g_ready0; }  // 参数个数写多：被调方多弹 16 字节
static void WINAPI OnReadyDestroy(int h, int) { g_destroyInCb = pDestroy(h) ? 1 : 2; }
static void Pump(DWORD ms, const std::atomic<int>* until = nullptr, int value = 0) {
  DWORD t0 = GetTickCount(); MSG m;
  while (GetTickCount() - t0 < ms) {
    while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); }
    if (until && until->load() >= value) return;
    Sleep(5);
  }
}
static std::wstring ExeDir() { wchar_t b[MAX_PATH]; GetModuleFileNameW(nullptr, b, MAX_PATH); std::wstring s(b); return s.substr(0, s.find_last_of(L"\\/")); }
static void Touch(const std::wstring& f) { HANDLE h = CreateFileW(f.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr); if (h != INVALID_HANDLE_VALUE) CloseHandle(h); }
static void Put(const std::wstring& f, const void* data, DWORD n) { HANDLE h = CreateFileW(f.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr); if (h != INVALID_HANDLE_VALUE) { DWORD w = 0; WriteFile(h, data, n, &w, nullptr); CloseHandle(h); } }
// 1.8.0 起查找运行时还要看浏览器进程、它启动时载入的两个 DLL（开头是 MZ）与 ICU 数据文件（开头 4 字节是 ICU 数据头）
static void RtFiles(const std::wstring& d) {
  for (auto n : {L"\\msedgewebview2.exe", L"\\msedge_elf.dll", L"\\msedge.dll"}) Put(d + n, "MZ", 2);
  static const unsigned char icu[16] = {0x90, 0x00, 0xDA, 0x27};
  Put(d + L"\\icudtl.dat", icu, sizeof(icu));
}
static void MkFake(const std::wstring& app, const wchar_t* ver) {
  std::wstring d = app + L"\\WebView2";
  CreateDirectoryW(app.c_str(), nullptr); CreateDirectoryW(d.c_str(), nullptr);
  d += std::wstring(L"\\Microsoft.WebView2.FixedVersionRuntime.") + ver + L".x86";
  CreateDirectoryW(d.c_str(), nullptr); CreateDirectoryW((d + L"\\EBWebView").c_str(), nullptr); CreateDirectoryW((d + L"\\EBWebView\\x86").c_str(), nullptr);
  Touch(d + L"\\EBWebView\\x86\\EmbeddedBrowserWebView.dll"); RtFiles(d);
}
static std::string CreateAndGetError() {
  HWND p2 = CreateWindowExW(0, L"WvTestParent", L"t2", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 400, 300, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
  g_ready = 0; g_readyOk = -1;
  int hb = pCreateA(p2, 0, 0, 0, 0, "", "", (void*)OnReady);
  Pump(4000, &g_ready, 1);
  std::string dg = pDiag(), err = pJsonGet(dg.c_str(), "views[0].error");
  if (!(hb > 0 && g_ready == 1 && g_readyOk == 0)) err = "NO_READY0";
  InvalidateRect((HWND)(intptr_t)pGetWin(hb, 0), nullptr, TRUE); UpdateWindow((HWND)(intptr_t)pGetWin(hb, 0)); Pump(100);
  DestroyWindow(p2); Pump(200);
  return err;
}
// ---- 1.5.0：跨线程转交超时
static std::string g_wkText, g_wkMsg;
static int g_wkErr;
static DWORD g_wkMs;
static int g_wkView, g_wkDestroyRet = -1, g_wkDestroyErr = -1;
static DWORD WINAPI WkDestroy(LPVOID) {  // 工作线程里销毁浏览器
  g_wkDestroyRet = pDestroy(g_wkView);
  g_wkDestroyErr = pErrCode();
  return 0;
}
static DWORD WINAPI WkDiag(LPVOID) {
  const DWORD t = GetTickCount();
  const char* s = pDiag();
  g_wkText = s ? s : "";
  g_wkErr = pErrCode();
  g_wkMsg = pErr();
  g_wkMs = GetTickCount() - t;
  return 0;
}
static long JsonNumA(const std::string& j, const char* key) {
  const std::string k = std::string("\"") + key + "\":";
  const size_t p = j.find(k);
  return p == std::string::npos ? -1 : atol(j.c_str() + p + k.size());
}

// ---- 1.5.0：开发期检查的说明框：另一个线程找到它、记下文字后按“确定”
static volatile LONG g_dlgCount, g_dlgStop;
static std::wstring g_dlgText;
static BOOL CALLBACK DlgChild(HWND h, LPARAM p) {
  wchar_t b[1024] = {0};
  SendMessageW(h, WM_GETTEXT, 1023, (LPARAM)b);
  *reinterpret_cast<std::wstring*>(p) += std::wstring(b) + L"|";
  return TRUE;
}
static DWORD WINAPI DlgCloser(LPVOID) {
  HWND last = nullptr;
  while (!g_dlgStop) {
    HWND d = FindWindowW(L"#32770", L"WebView2Bridge 开发期检查");
    if (d && d != last && IsWindowVisible(d)) {
      Sleep(100);  // 等对话框完全建好
      std::wstring t;
      EnumChildWindows(d, DlgChild, reinterpret_cast<LPARAM>(&t));
      g_dlgText = t;
      InterlockedIncrement(&g_dlgCount);
      last = d;
      SendMessageW(d, WM_COMMAND, IDOK, 0);
      for (int k = 0; k < 100 && IsWindow(d); ++k) Sleep(10);
    }
    Sleep(20);
  }
  return 0;
}
static void PumpMs(DWORD ms) {
  MSG m;
  for (DWORD t0 = GetTickCount(); GetTickCount() - t0 < ms;) {
    while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); }
    Sleep(5);
  }
}

// 1.6.4 的 JSON取值 缓存测试用：在工作线程里取一次值（缓存约 900 KB 的 JSON），hang 为真时一直不结束，等着被 TerminateThread
struct JcArg {
  const char* doc;
  decltype(&WV_JsonGet) get;
  volatile LONG ready;
  volatile bool hang;
};
static DWORD WINAPI JcThread(LPVOID p) {
  JcArg* x = static_cast<JcArg*>(p);
  x->get(x->doc, "[0]");
  InterlockedExchange(&x->ready, 1);
  while (x->hang) Sleep(1000);
  return 0;
}

int main(int argc, char** argv) {
  const bool win7 = argc > 1 && strcmp(argv[1], "win7") == 0;
  g_dll = LoadLibraryW(L"WebView2Bridge.dll");
  if (!g_dll) { printf("LoadLibrary failed %lu\n", GetLastError()); return 2; }
  pVer = Fn<decltype(&WV_GetVersion)>("WV_GetVersion"); pVerText = Fn<decltype(&WV_GetVersionText)>("WV_GetVersionText"); pSetOpt = Fn<decltype(&WV_SetOption)>("WV_SetOption"); pGetOpt = Fn<decltype(&WV_GetOption)>("WV_GetOption");
  pRtCheck = Fn<decltype(&WV_RuntimeCheck)>("WV_RuntimeCheck"); pRtInfo = Fn<decltype(&WV_RuntimeInfo)>("WV_RuntimeInfo"); pDiag = Fn<decltype(&WV_GetDiagnostics)>("WV_GetDiagnostics"); pErrCode = Fn<decltype(&WV_LastErrorCode)>("WV_LastErrorCode");
  pErr = Fn<decltype(&WV_LastError)>("WV_LastError"); pQuote = Fn<decltype(&WV_JsonQuote)>("WV_JsonQuote"); pJsonGet = Fn<decltype(&WV_JsonGet)>("WV_JsonGet"); pCreateA = Fn<decltype(&WV_CreateAsync)>("WV_CreateAsync");
  pCreate = Fn<decltype(&WV_Create)>("WV_Create"); pDestroy = Fn<decltype(&WV_Destroy)>("WV_Destroy"); pIsReady = Fn<decltype(&WV_IsReady)>("WV_IsReady"); pGetWin = Fn<decltype(&WV_GetWindow)>("WV_GetWindow");
  // ---- 版本与选项
  Check(pVer() == WV_BRIDGE_VERSION, "version number matches header", std::to_string(pVer()));
  char verPrefix[32];  // 期望的版本文字由头文件的版本号算出，升级版本时不必改这里
  snprintf(verPrefix, sizeof(verPrefix), "WebView2Bridge %d.%d.%d", WV_BRIDGE_VERSION / 10000, WV_BRIDGE_VERSION / 100 % 100, WV_BRIDGE_VERSION % 100);
  Check(strncmp(pVerText(), verPrefix, strlen(verPrefix)) == 0, "version text derived from macro", pVerText());
  Check(pSetOpt(WVO_CODEPAGE, "936") == 1 && strcmp(pGetOpt(WVO_CODEPAGE), "936") == 0, "codepage option 936", pGetOpt(WVO_CODEPAGE));
  // ---- WV_JsonQuote
  Check(Gbk(L"\"a\\\"b\\\\c\"") == pQuote(Gbk(L"a\"b\\c").c_str()), "JsonQuote quote and backslash", Hex(pQuote("a\"b\\c")));
  Check(Gbk(L"\"\u4E57\u4FD3\"") == pQuote(Gbk(L"\u4E57\u4FD3").c_str()), "JsonQuote keeps GBK chars whose 2nd byte is 0x5C", Hex(pQuote(Gbk(L"\u4E57\u4FD3").c_str())));
  Check(std::string("\"l1\\r\\nl2\\t\\u0001\"") == pQuote("l1\r\nl2\t\x01"), "JsonQuote control chars", Hex(pQuote("l1\r\nl2\t\x01")));
  Check(std::string("\"\"") == pQuote("") && std::string("\"\"") == pQuote(nullptr), "JsonQuote empty and null", pQuote(nullptr));
  // ---- WV_JsonGet
  std::string js = Gbk(L"{\"a\":[1,{\"b\":\"\u4F60\u597D\",\"c\":[true,null,2.5]}],\"d\":{\"e\":\"x\\\"y\"},\"u\":\"\\u4e2d\\u6587\",\"\u540D\u5B57\":\"\u5F20\u4E09\",\"n\":-1.5e3,\"s\":\"\"}");
  struct T { const char* path; std::string want; } cases[] = {
      {"a[0]", "1"}, {"a[1].b", Gbk(L"\u4F60\u597D")}, {"a[1].c[0]", "true"}, {"a[1].c[1]", "null"}, {"a[1].c[2]", "2.5"},
      {"a[1].c", "[true,null,2.5]"}, {"d.e", "x\"y"}, {"u", Gbk(L"\u4E2D\u6587")}, {"s", ""}};
  for (auto& c : cases) { std::string name = std::string("JsonGet ") + c.path; Check(c.want == pJsonGet(js.c_str(), c.path), name.c_str(), Hex(pJsonGet(js.c_str(), c.path))); }
  Check(Gbk(L"\u5F20\u4E09") == pJsonGet(js.c_str(), Gbk(L"\u540D\u5B57").c_str()), "JsonGet Chinese key", Hex(pJsonGet(js.c_str(), Gbk(L"\u540D\u5B57").c_str())));
  Check(atof(pJsonGet(js.c_str(), "n")) == -1500.0, "JsonGet number", pJsonGet(js.c_str(), "n"));
  Check(Gbk(L"\u4E8C") == pJsonGet(Gbk(L"[1,\"\u4E8C\"]").c_str(), "[1]"), "JsonGet top-level array", "");
  { std::string r = pJsonGet(js.c_str(), "zz.y"); int c = pErrCode(); Check(r.empty() && c == WVERR_NOT_FOUND, "JsonGet missing key -> NOT_FOUND", r + "/" + std::to_string(c)); }
  { std::string r = pJsonGet(js.c_str(), "a[9]"); int c = pErrCode(); Check(r.empty() && c == WVERR_NOT_FOUND, "JsonGet index out of range -> NOT_FOUND", r + "/" + std::to_string(c)); }
  { std::string r = pJsonGet("{bad", "a"); int c = pErrCode(); Check(r.empty() && c == WVERR_ARG, "JsonGet invalid JSON -> ARG", r + "/" + std::to_string(c)); }
  { std::string r = pJsonGet("[1,2] x", "[0]"); int c = pErrCode(); Check(r.empty() && c == WVERR_ARG, "JsonGet trailing garbage rejected", r + "/" + std::to_string(c)); }
  { std::string r = pJsonGet("{\"k\":[1,2]}", ""); Check(r == "{\"k\":[1,2]}", "JsonGet empty path returns whole JSON", r); }
  { pJsonGet(js.c_str(), "zz"); pJsonGet(js.c_str(), "a[0]"); int c = pErrCode(); Check(c == 0, "JsonGet success clears previous error", std::to_string(c)); }
  { std::string r = pJsonGet("{\"a.b\":{\"c\":7}}", "[\"a.b\"].c"); Check(r == "7", "JsonGet quoted key containing dot", r); }
  // ---- 1.6.0：数组后面跟 length 得到成员数（与 JavaScript 相同）；同一线程连续传入相同的 JSON 时复用解析结果
  {
    const char* doc = "{\"a\":[1,2,3],\"e\":[],\"o\":{\"length\":5},\"s\":\"abc\",\"n\":[[1,2],[3]]}";
    Check(std::string(pJsonGet(doc, "a.length")) == "3", "JsonGet array.length is the element count", pJsonGet(doc, "a.length"));
    Check(std::string(pJsonGet(doc, "a[\"length\"]")) == "3", "JsonGet array[\"length\"] is the element count too", pJsonGet(doc, "a[\"length\"]"));
    Check(std::string(pJsonGet(doc, "e.length")) == "0", "JsonGet empty array length is 0", pJsonGet(doc, "e.length"));
    Check(std::string(pJsonGet(doc, "o.length")) == "5", "JsonGet object key named length is still a key lookup", pJsonGet(doc, "o.length"));
    Check(std::string(pJsonGet(doc, "n[0].length")) == "2" && std::string(pJsonGet("[7,8]", "length")) == "2", "JsonGet length after an index and on a top-level array", "");
    { std::string r = pJsonGet(doc, "s.length"); int c = pErrCode(); Check(r.empty() && c == WVERR_NOT_FOUND, "JsonGet a string has no length (NOT_FOUND)", r + "/" + std::to_string(c)); }
    { std::string r = pJsonGet(doc, "a.length.x"); int c = pErrCode(); Check(r.empty() && c == WVERR_NOT_FOUND, "JsonGet nothing below a length", r + "/" + std::to_string(c)); }
  }
  {  // 同一块内存里的文本改了（长度不变）：必须重新解析，不能用上一次的结果
    char buf[] = "{\"k\":\"v1\"}";
    std::string r1 = pJsonGet(buf, "k");
    buf[7] = '2';  // {"k":"v1"} 里的 1
    std::string r2 = pJsonGet(buf, "k");
    Check(r1 == "v1" && r2 == "v2", "JsonGet re-parses when the same buffer changes", r1 + "/" + r2);
  }
  {  // 同样的字节换了代码页要重新解析：GBK 的“路”是 C2 B7，按 UTF-8 是“·”（用旧的解析结果会输出“路”的 UTF-8：E8 B7 AF）
    const char* doc = "[\"\xC2\xB7\"]";
    pSetOpt(WVO_CODEPAGE, "936");
    std::string r1 = pJsonGet(doc, "[0]");
    pSetOpt(WVO_CODEPAGE, "65001");
    std::string r2 = pJsonGet(doc, "[0]");
    pSetOpt(WVO_CODEPAGE, "936");
    Check(r1 == "\xC2\xB7" && r2 == "\xC2\xB7", "JsonGet re-parses after the code page changes", Hex(r1) + " / " + Hex(r2));
  }
  {  // 解析失败不影响上一次的结果；之后再取原来的 JSON 照样正确
    std::string a = pJsonGet(js.c_str(), "a[0]");
    std::string bad = pJsonGet("[1,", "[0]"); int c = pErrCode();
    std::string b = pJsonGet(js.c_str(), "a[1].c[2]");
    Check(a == "1" && bad.empty() && c == WVERR_ARG && b == "2.5", "JsonGet invalid JSON between valid calls", a + "/" + b);
  }
  // ---- 1.6.1：下标只认非负十进制整数；超过缓存上限的 JSON 照常解析；全局选项的文本去掉首尾空白
  {
    const char* doc = "[10,20,30]";
    Check(std::string(pJsonGet(doc, "[ 1 ]")) == "20", "JsonGet index with spaces", pJsonGet(doc, "[ 1 ]"));
    int bad = 0;
    for (const char* path : {"[abc]", "[1.5]", "[0x1]", "[-1]", "[]", "[1e0]", "[+1]"}) {
      std::string r = pJsonGet(doc, path);
      if (!r.empty() || pErrCode() != WVERR_NOT_FOUND) { ++bad; printf("INFO path %s -> %s\n", path, r.c_str()); }
    }
    Check(bad == 0, "JsonGet: [abc] [1.5] [0x1] [-1] [] [1e0] [+1] are not indexes (NOT_FOUND, not element 0)", std::to_string(bad));
  }
  {
    std::string big = "[";
    for (int i = 0; i < 160000; ++i) big += std::string(i ? "," : "") + "{\"id\":" + std::to_string(i) + ",\"t\":\"xxxxxxxx\"}";
    big += "]";
    std::string r1 = pJsonGet(big.c_str(), "[159999].id"), r2 = pJsonGet(big.c_str(), "length"), r3 = pJsonGet(js.c_str(), "a[0]"), r4 = pJsonGet(big.c_str(), "[1].id");
    Check(big.size() > (4u << 20) && r1 == "159999" && r2 == "160000" && r3 == "1" && r4 == "1", "JsonGet a JSON larger than the cache limit is parsed every time and stays correct",
          std::to_string(big.size()) + " " + r1 + "/" + r2 + "/" + r4);
  }
  {
    const bool l = pSetOpt(WVO_LANGUAGE, "  zh-CN \t") == 1 && std::string(pGetOpt(WVO_LANGUAGE)) == "zh-CN";
    const bool r = pSetOpt(WVO_RUNTIME_DIR, " C:\\rt\\ ") == 1 && std::string(pGetOpt(WVO_RUNTIME_DIR)) == "C:\\rt";
    pSetOpt(WVO_LANGUAGE, ""); pSetOpt(WVO_RUNTIME_DIR, "");
    Check(l && r, "global text options drop surrounding whitespace (same as per-browser options)", std::string(pGetOpt(WVO_LANGUAGE)));
  }
  // ---- 运行时与诊断
  Check(pRtCheck(1) == 0, "no WebView2 runtime under Wine", "");
  printf("INFO runtime error: code %d\n", pErrCode());
  std::string info = pRtInfo();
  Check(!info.empty() && info[0] == '{' && info.back() == '}', "RuntimeInfo is JSON object", info.substr(0, 80));
  printf("INFO RuntimeInfo: %s\n", Hex(info).substr(0, 300).c_str());
  std::string diag = pDiag();
  Check(strncmp(pJsonGet(diag.c_str(), "bridge"), verPrefix, strlen(verPrefix)) == 0, "Diagnostics bridge field (before UI thread)", Hex(diag).substr(0, 120));
  // ---- 多线程并发转换（每线程独立的编码缓存与返回缓冲）
  {
    std::atomic<int> bad{0};
    std::string src = Gbk(L"\u6D4B\u8BD5\u4E57\u4FD3\"\\"), want = pQuote(src.c_str());
    std::vector<std::thread> ts;
    for (int t = 0; t < 4; ++t) ts.emplace_back([&] { for (int i = 0; i < 5000; ++i) { if (want != pQuote(src.c_str())) ++bad; if (Gbk(L"\u4F60\u597D") != pJsonGet(js.c_str(), "a[1].b")) ++bad; } });
    for (auto& t : ts) t.join();
    Check(bad == 0, "4 threads x 5000 conversions consistent", std::to_string(bad.load()));
  }
  // ---- 窗口与浏览器生命周期
  WNDCLASSW wc = {}; wc.lpfnWndProc = DefWindowProcW; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"WvTestParent";
  RegisterClassW(&wc);
  HWND parent = CreateWindowExW(0, L"WvTestParent", L"t", WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_VISIBLE, 0, 0, 640, 480, nullptr, nullptr, wc.hInstance, nullptr);
  Check(parent != nullptr, "parent window created", "");
  int hw = -1, ew = -1;
  std::thread([&] { hw = pCreateA(parent, 0, 0, 0, 0, "https://example.com", "", (void*)OnReady); ew = pErrCode(); }).join();
  Check(hw == 0 && ew == WVERR_THREAD, "create from worker thread rejected", std::to_string(hw) + "/" + std::to_string(ew));
  int h1 = pCreateA(parent, 0, 0, 0, 0, "https://example.com", "", (void*)OnReady);
  Check(h1 > 0, "create on UI thread still works after worker misuse (fallback panel kept)", std::to_string(h1) + " " + pErr());
  Check(g_ready == 0, "READY not fired synchronously inside create (posted)", std::to_string(g_ready.load()));
  Pump(3000, &g_ready, 1);
  Check(g_ready == 1 && g_readyOk == 0, "READY(0) delivered via message queue", std::to_string(g_ready.load()) + "/" + std::to_string(g_readyOk.load()));
  Check(pIsReady(h1) == -1, "IsReady reports failure", std::to_string(pIsReady(h1)));
  HWND host = (HWND)(intptr_t)pGetWin(h1, 0);
  RECT rc1, rcp; GetWindowRect(host, &rc1); GetClientRect(parent, &rcp);
  Check(host && rc1.right - rc1.left == rcp.right && rc1.bottom - rc1.top == rcp.bottom, "host fills parent", "");
  SetWindowPos(parent, nullptr, 0, 0, 800, 600, SWP_NOMOVE | SWP_NOZORDER); Pump(100);
  GetWindowRect(host, &rc1); GetClientRect(parent, &rcp);
  Check(rc1.right - rc1.left == rcp.right && rc1.bottom - rc1.top == rcp.bottom, "host follows parent resize", std::to_string(rc1.right - rc1.left));
  InvalidateRect(host, nullptr, TRUE); UpdateWindow(host); Pump(200);
  Check(IsWindow(host), "fallback panel painted without crash", "");
  std::atomic<int> diagDone{0}; std::string diag2;
  std::thread dt([&] { diag2 = pDiag(); diagDone = 1; });
  Pump(5000, &diagDone, 1); dt.join();
  Check(diagDone == 1 && diag2.find("\"views\":[{") != std::string::npos, "Diagnostics from worker marshalled to UI thread", Hex(diag2).substr(0, 200));
  int h2 = pCreateA(parent, 10, 10, 200, 100, "", "", (void*)OnReadyNoArgs);
  int h3 = pCreateA(parent, 20, 20, 200, 100, "", "", (void*)OnReadyExtra);
  Pump(2000, &g_ready0, 2);
  Check(g_ready0 == 2, "callbacks with wrong parameter count survive (stack protected)", std::to_string(g_ready0.load()));
  int h4 = pCreateA(parent, 30, 30, 200, 100, "", "", (void*)OnReadyDestroy);
  Pump(2000, &g_destroyInCb, 1); Pump(200);
  Check(g_destroyInCb == 1 && pIsReady(h4) == -1, "destroy inside READY callback", std::to_string(g_destroyInCb.load()));
  int hs = pCreate(parent, 40, 40, 100, 100, "", "", 2000);
  printf("INFO sync create without runtime -> %d, code %d\n", hs, pErrCode());
  Check(pDestroy(h2) == 1, "destroy view", "");
  Check(pIsReady(h2) == -1 && pDestroy(h2) == 0 && pErrCode() == WVERR_BAD_HANDLE, "destroyed handle invalid", std::to_string(pErrCode()));
  DestroyWindow(parent); Pump(300);
  Check(pIsReady(h1) == -1 && pIsReady(h3) == -1, "views removed when parent destroyed", "");
  std::string d3 = pDiag();
  Check(d3.find("\"views\":[]") != std::string::npos, "no views left", Hex(d3).substr(0, 160));
  // ---- 伪造的固定版运行时：目录扫描、按系统挑选版本、运行时损坏时的失败路径
  {
    std::wstring app = ExeDir() + L"\\fakeapp";
    MkFake(app, L"109.0.1518.140"); MkFake(app, L"120.0.2210.91");
    pSetOpt(WVO_APP_DIR, Gbk(app.c_str()).c_str());
    int f = pRtCheck(1);
    std::string ri = pRtInfo();
    std::string lg = pJsonGet(ri.c_str(), "legacyOs"), sv = pJsonGet(ri.c_str(), "selected.version");
    std::string nc = pJsonGet(ri.c_str(), "candidates[1].version");
    Check(f == 1, "fake fixed runtime found by directory scan", Hex(ri).substr(0, 160));
    Check(lg == (win7 ? "true" : "false"), win7 ? "Win7 detected as legacy OS" : "Win10 detected as modern OS", lg);
    Check(sv == (win7 ? "109.0.1518.140" : "120.0.2210.91"), win7 ? "Win7 selects 109 although 120 exists" : "Win10 selects newest fixed runtime (120)", sv);
    Check(!nc.empty(), "version taken from folder name when files lack version info", nc);
    std::string err = CreateAndGetError();
    Check(err.find(Gbk(L"\u635F\u574F")) != std::string::npos, "empty x86 DLL reported as corrupted, not wrong bitness", Hex(err));
  }
  {
    std::wstring a = ExeDir() + L"\\fakeapp64", d = a + L"\\WebView2\\Microsoft.WebView2.FixedVersionRuntime.120.0.2210.91.x64";
    CreateDirectoryW(a.c_str(), nullptr); CreateDirectoryW((a + L"\\WebView2").c_str(), nullptr); CreateDirectoryW(d.c_str(), nullptr);
    CreateDirectoryW((d + L"\\EBWebView").c_str(), nullptr); CreateDirectoryW((d + L"\\EBWebView\\x64").c_str(), nullptr);
    Touch(d + L"\\EBWebView\\x64\\EmbeddedBrowserWebView.dll");
    pSetOpt(WVO_APP_DIR, Gbk(a.c_str()).c_str());
    int f = pRtCheck(1); std::string ri = pRtInfo(); std::string reason = pJsonGet(ri.c_str(), "reason");
    Check(f == 0 && reason.find(Gbk(L"64 \u4F4D")) != std::string::npos, "x64-only runtime package explained as wrong bitness", Hex(reason));
  }
  {
    std::wstring a = ExeDir() + L"\\fakeapppe";
    MkFake(a, L"109.0.9.9");
    CopyFileW((ExeDir() + L"\\dummy64.dll").c_str(), (a + L"\\WebView2\\Microsoft.WebView2.FixedVersionRuntime.109.0.9.9.x86\\EBWebView\\x86\\EmbeddedBrowserWebView.dll").c_str(), FALSE);
    pSetOpt(WVO_APP_DIR, Gbk(a.c_str()).c_str());
    Check(pRtCheck(1) == 1, "x86 slot with 64-bit DLL is still a candidate", "");
    std::string err = CreateAndGetError();
    Check(err.find(Gbk(L"\u4F4D\u6570\u4E0D\u7B26")) != std::string::npos, "64-bit DLL in x86 slot reported as wrong bitness", Hex(err));
  }
  {  // 1.8.0：icudtl.dat 被别的程序独占打开时不交给运行时客户端，说明“被占用”并稍后自动重试；放开后重试照常进行（这里的客户端 DLL 是空文件，重试后报“损坏”）
    std::wstring a = ExeDir() + L"\\fakeappbusy";
    MkFake(a, L"109.0.9.8");
    const std::wstring icu = a + L"\\WebView2\\Microsoft.WebView2.FixedVersionRuntime.109.0.9.8.x86\\icudtl.dat";
    pSetOpt(WVO_APP_DIR, Gbk(a.c_str()).c_str());
    pRtCheck(1);
    HANDLE lk = CreateFileW(icu.c_str(), GENERIC_READ, 0, nullptr, OPEN_EXISTING, 0, nullptr);
    HWND p3 = CreateWindowExW(0, L"WvTestParent", L"t3", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 400, 300, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    g_ready = 0; g_readyOk = -1;
    int hb = pCreateA(p3, 0, 0, 0, 0, "", "", (void*)OnReady);
    Pump(2000, &g_ready, 1);
    std::string dg = pDiag(), e1 = pJsonGet(dg.c_str(), "views[0].error");
    Check(lk != INVALID_HANDLE_VALUE && hb > 0 && g_ready == 1 && g_readyOk == 0 && e1.find(Gbk(L"\u5360\u7528")) != std::string::npos,
          "locked icudtl.dat is not handed to the runtime client and is reported as busy", Hex(e1));
    if (lk != INVALID_HANDLE_VALUE) CloseHandle(lk);
    g_ready = 0; g_readyOk = -1;
    Pump(5000, &g_ready, 1);  // 约 1.5 秒后自动重试：这次交给客户端，空的客户端 DLL 载入失败
    dg = pDiag();
    std::string e2 = pJsonGet(dg.c_str(), "views[0].error");
    Check(g_ready == 1 && e2.find(Gbk(L"\u5360\u7528")) == std::string::npos && e2.find(Gbk(L"\u635F\u574F")) != std::string::npos,
          "after the lock is released the automatic retry goes ahead", Hex(e2));
    DestroyWindow(p3); Pump(200);
  }
  {  // 代理地址不能借空格或引号注入额外的浏览器启动参数；程序目录必须存在
    std::string proxy0 = pGetOpt(WVO_PROXY);
    Check(pSetOpt(WVO_PROXY, "127.0.0.1:8080 --disable-web-security") == 0 && pErrCode() == WVERR_ARG && proxy0 == pGetOpt(WVO_PROXY),
          "proxy containing spaces is rejected and the previous value kept");
    Check(pSetOpt(WVO_PROXY, "\"a:1\"") == 0 && pSetOpt(WVO_PROXY, "http=a:80;https=b:80") == 1 && pSetOpt(WVO_PROXY, "socks5://127.0.0.1:1080") == 1 &&
          pSetOpt(WVO_PROXY, "direct") == 1 && pSetOpt(WVO_PROXY, "") == 1, "quoted proxy rejected; valid proxy specs accepted");
    std::string dir0 = pGetOpt(WVO_APP_DIR);
    Check(pSetOpt(WVO_APP_DIR, "C:\\no_such_dir_wv2\\x") == 0 && pErrCode() == WVERR_ARG && dir0 == pGetOpt(WVO_APP_DIR),
          "nonexistent program folder is rejected and the previous one kept");
  }
  {  // 1.4.0：源码文字常量转 UTF-8（WV_TextFromAnsi）、JSON 重复的键取最后一个、网络共享路径不拼到程序目录、伪造的窗口消息被忽略
    auto pTextFn = reinterpret_cast<decltype(&WV_TextFromAnsi)>(reinterpret_cast<void*>(GetProcAddress(g_dll, "WV_TextFromAnsi")));
    Check(pTextFn != nullptr, "WV_TextFromAnsi is exported");
    auto pText = [&](const char* s) { return pTextFn ? std::string(pTextFn(s)) : std::string("(missing)"); };
    std::string cp0 = pGetOpt(WVO_CODEPAGE);
    pSetOpt(WVO_CODEPAGE, "65001");
    std::string k1 = pText((Gbk(L"\u97E9\u6587\uFF1A") + "\\uD55C\\uAD6D\\uC5B4").c_str());  // “韩文：”加上 \u 转义写的「한국어」
    Check(k1 == "\xE9\x9F\xA9\xE6\x96\x87\xEF\xBC\x9A\xED\x95\x9C\xEA\xB5\xAD\xEC\x96\xB4", "WV_TextFromAnsi: GBK text with \\u escapes becomes UTF-8, Korean kept", Hex(k1));
    std::string k2 = pText("\\uD83D\\uDE00|\\uD83D|\\u12|C:\\update\\u0000");
    Check(k2 == "\xF0\x9F\x98\x80|\xEF\xBF\xBD|\\u12|C:\\update\\u0000", "WV_TextFromAnsi: surrogate pair joined, lone surrogate replaced, incomplete escape and \\u0000 kept", Hex(k2));
    std::string k3 = pText("\xCD\xA8\xD6\xAA");  // GBK“通知”的字节恰好也是合法 UTF-8：入参固定按 ANSI 解释才不会读错
    Check(k3 == "\xE9\x80\x9A\xE7\x9F\xA5", "WV_TextFromAnsi: input always read as ANSI (GBK text that is also valid UTF-8)", Hex(k3));
    std::string k4 = pText("\x81\x5Cu0041");  // “乗”的第二个字节是 0x5C（反斜杠）
    Check(k4 == "\xE4\xB9\x97u0041", "WV_TextFromAnsi: a GBK character whose second byte is a backslash is not taken as an escape", Hex(k4));
    pSetOpt(WVO_CODEPAGE, "0");
    std::string k5 = pText("\\uD55C");
    Check(k5 == "?", "WV_TextFromAnsi in ANSI mode: characters the code page lacks become ?", Hex(k5));
    pSetOpt(WVO_CODEPAGE, cp0.c_str());
    std::string dup = pJsonGet("{\"a\":1,\"a\":2}", "a");
    Check(dup == "2", "WV_JsonGet: a duplicated key takes the last value, like JSON.parse", dup);
    // 1.4.2：日志文件的相对路径按程序目录（原来按当前目录）；程序目录的相对路径存成完整路径
    std::string app0 = pGetOpt(WVO_APP_DIR), log0 = pGetOpt(WVO_LOG_FILE);
    std::string relLog = app0 + "\\wv_rel_log_test.log";
    DeleteFileA(relLog.c_str());
    pSetOpt(WVO_LOG_FILE, "wv_rel_log_test.log");
    pSetOpt(WVO_PROXY, "bad proxy");  // 设置失败，写一行日志
    const bool logged = GetFileAttributesA(relLog.c_str()) != INVALID_FILE_ATTRIBUTES;
    pSetOpt(WVO_LOG_FILE, log0.c_str());
    DeleteFileA(relLog.c_str());
    Check(logged, "a relative log file path is resolved against the program folder", relLog);
    char cwd[MAX_PATH] = {0};
    GetCurrentDirectoryA(MAX_PATH, cwd);
    const int relApp = pSetOpt(WVO_APP_DIR, ".");
    const std::string appNow = pGetOpt(WVO_APP_DIR);
    pSetOpt(WVO_APP_DIR, app0.c_str());
    Check(relApp == 1 && appNow == cwd, "a relative program folder is stored as a full path", appNow + " / " + cwd);
    HWND pw = CreateWindowExW(0, L"WvTestParent", L"t3", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 320, 240, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    auto pCr = Fn<decltype(&WV_Create)>("WV_Create");
    auto pSS = Fn<decltype(&WV_SetStr)>("WV_SetStr");
    auto pGS = Fn<decltype(&WV_GetStr)>("WV_GetStr");
    auto pGW = Fn<decltype(&WV_GetWindow)>("WV_GetWindow");
    auto pDs = Fn<decltype(&WV_Destroy)>("WV_Destroy");
    int hv = pCr(pw, 0, 0, 0, 0, "", "fallback=1", 2000);  // 没有运行时：返回句柄并显示提示卡片
    pSS(hv, WVS_DOWNLOAD_DIR, "\\\\server\\share\\dl");
    std::string d1 = pGS(hv, WVS_DOWNLOAD_DIR);
    pSS(hv, WVS_DOWNLOAD_DIR, "dl");
    std::string d2 = pGS(hv, WVS_DOWNLOAD_DIR);
    Check(hv != 0 && d1 == "\\\\server\\share\\dl", "download folder on a network share is kept (not joined to the program folder)", d1);
    Check(d2.size() > 4 && d2.compare(d2.size() - 3, 3, "\\dl") == 0 && d2[1] == ':', "relative download folder is resolved against the program folder", d2);
    HWND host = (HWND)(intptr_t)pGW(hv, 0);
    HWND disp = FindWindowExW(HWND_MESSAGE, nullptr, L"WV2BridgeDispatch", nullptr);
    // 别的程序也能给这两个窗口发消息：原来把消息参数当成函数对象指针直接调用（投递任务还会释放它），这里会崩溃
    PostMessageW(host, WM_APP + 0x3A7, 0, (LPARAM)0x41414141);
    SendMessageW(host, WM_APP + 0x2B1, 0, (LPARAM)0x41414141);
    if (disp) SendMessageW(disp, WM_APP + 0x2B1, 0, (LPARAM)0x41414141);
    for (DWORD t0 = GetTickCount(); GetTickCount() - t0 < 300;) {
      MSG m;
      while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); }
      Sleep(10);
    }
    Check(host != nullptr && disp != nullptr && pGW(hv, 0) == (int)(intptr_t)host, "forged task messages from outside the DLL are ignored (no crash)");
    pDs(hv);
    DestroyWindow(pw);
  }
  // 1.4.6：导出函数里的异常（这里用超大的输入让转义时内存不足）不穿出 DLL：返回空文本并报告错误，进程照常运行。
  // 原来编码转换等在 WithView 之外的部分没有保护，异常穿出去进程会直接结束
  {
    std::string big;
    try {
      big.assign(160u * 1024 * 1024, '\x01');
    } catch (...) {
    }
    if (!big.empty()) {
      const char* q = pQuote(big.c_str());
      const int qe = pErrCode();
      std::string().swap(big);
      Check(q && !*q && qe == WVERR_FAILED, "an exception inside an export (out of memory on a huge input) becomes an error instead of ending the process", std::to_string(qe));
    } else {
      Check(true, "huge-input exception test skipped (no memory for the input)");
    }
  }
  // 已经创建过窗口：DLL 必须固定在进程里，FreeLibrary 不能把窗口过程所在的代码卸载掉
  FreeLibrary(g_dll);
  Check(GetModuleHandleW(L"WebView2Bridge.dll") != nullptr, "DLL stays loaded after FreeLibrary once it owns windows");
  // ---- 1.5.0：界面线程在等待工作线程（不处理消息）时，工作线程转交给界面线程的调用在限定时间内失败返回；原来两边一直互相等待
  {
    typedef int(__stdcall * InitFn)(const char*);
    InitFn pInit = (InitFn)(void*)GetProcAddress(g_dll, "WV_Init");
    HWND tw = CreateWindowExW(0, L"STATIC", L"t", WS_OVERLAPPEDWINDOW, 0, 0, 100, 100, nullptr, nullptr, nullptr, nullptr);
    pInit(nullptr);
    const bool optOk = pSetOpt(WVO_THREAD_TIMEOUT, "800") == 1 && std::string(pGetOpt(WVO_THREAD_TIMEOUT)) == "800";
    const bool optBad = pSetOpt(WVO_THREAD_TIMEOUT, "abc") == 0 && pErrCode() == WVERR_ARG && pSetOpt(WVO_THREAD_TIMEOUT, "-1") == 0;
    Check(optOk && optBad, "thread timeout option accepts milliseconds and rejects other text", pGetOpt(WVO_THREAD_TIMEOUT));
    const long to0 = JsonNumA(pDiag(), "threadTimeouts");
    HANDLE th = CreateThread(nullptr, 0, WkDiag, nullptr, 0, nullptr);
    const DWORD w = WaitForSingleObject(th, 10000);  // 相当于易语言在界面线程里“等待线程”：期间不处理消息
    CloseHandle(th);
    MSG m;
    for (int i = 0; i < 20; ++i) {  // 迟到的转交消息找不到任务，直接忽略
      while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) DispatchMessageW(&m);
      Sleep(5);
    }
    const long to1 = JsonNumA(pDiag(), "threadTimeouts");
    Check(w == WAIT_OBJECT_0 && g_wkText.find("\"views\":[]") != std::string::npos && g_wkErr == WVERR_THREAD && g_wkMs >= 700 && g_wkMs < 5000 && g_wkMsg.find("WVO_THREAD_TIMEOUT") != std::string::npos &&
              to1 == to0 + 1,
          "a worker's call is cancelled after the thread timeout while the UI thread waits for that worker (no deadlock); diagnostics still return without the UI-thread part",
          std::to_string(w) + "/" + std::to_string(g_wkErr) + "/" + std::to_string(g_wkMs) + "ms/" + std::to_string(to1 - to0));
    g_wkText.clear();
    g_wkErr = -1;
    th = CreateThread(nullptr, 0, WkDiag, nullptr, 0, nullptr);
    for (DWORD t0 = GetTickCount(); WaitForSingleObject(th, 0) == WAIT_TIMEOUT && GetTickCount() - t0 < 5000;) {
      while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) DispatchMessageW(&m);
      Sleep(1);
    }
    CloseHandle(th);
    Check(!g_wkText.empty() && g_wkErr == 0 && g_wkText.find("\"checks\":{\"devChecks\":") != std::string::npos,
          "a worker's call completes normally while the UI thread pumps messages; diagnostics include the checks section", g_wkText.substr(0, 60));
    // 工作线程里的 WV_Destroy 没能转交（界面线程不处理消息）时返回 0、错误码 WVERR_THREAD，浏览器仍在；迟到的转交消息也不会再执行这次销毁。
    // 易语言的 销毁 () 据此只在这种情况下保留句柄
    {
      g_wkView = pCreate(tw, 0, 0, 100, 100, "", "", 2000);
      pSetOpt(WVO_THREAD_TIMEOUT, "300");
      HANDLE td = CreateThread(nullptr, 0, WkDestroy, nullptr, 0, nullptr);
      const DWORD wd = WaitForSingleObject(td, 10000);  // 不处理消息
      CloseHandle(td);
      for (int i = 0; i < 20; ++i) {
        while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) DispatchMessageW(&m);
        Sleep(5);
      }
      const bool alive = pGetWin(g_wkView, 0) != 0;
      const int again = pDestroy(g_wkView);
      Check(g_wkView != 0 && wd == WAIT_OBJECT_0 && g_wkDestroyRet == 0 && g_wkDestroyErr == WVERR_THREAD && alive && again == 1,
            "a worker's WV_Destroy that could not be handed off returns 0 with WVERR_THREAD and the cancelled destroy never runs later; the view stays until destroyed again",
            std::to_string(g_wkView) + "/" + std::to_string(g_wkDestroyRet) + "/" + std::to_string(g_wkDestroyErr) + "/" + std::to_string(alive) + "/" + std::to_string(again));
    }
    pSetOpt(WVO_THREAD_TIMEOUT, "");
    Check(std::string(pGetOpt(WVO_THREAD_TIMEOUT)) == "10000", "thread timeout defaults to 10000 ms", pGetOpt(WVO_THREAD_TIMEOUT));
    DestroyWindow(tw);
  }
  // ---- 1.5.0：开发期检查（导出层）
  {
    pSetOpt(WVO_CODEPAGE, "65001");
    const bool optOk = pSetOpt(WVO_DEV_CHECKS, "2") == 1 && std::string(pGetOpt(WVO_DEV_CHECKS)) == "2";
    const bool optBad = pSetOpt(WVO_DEV_CHECKS, "3") == 0 && pErrCode() == WVERR_ARG;
    Check(optOk && optBad, "dev checks option accepts 0, 1 and 2 only", pGetOpt(WVO_DEV_CHECKS));
    const std::string q1 = pQuote("\xC4\xE3\xBA\xC3");  // GBK 的“你好”
    const int e1 = pErrCode();
    const std::string m1 = pErr();
    Check(q1.empty() && e1 == WVERR_ENCODING && m1.find("WV_JsonQuote") != std::string::npos && m1.find("\xE4\xBD\xA0\xE5\xA5\xBD") != std::string::npos,
          "dev checks: GBK text given to a UTF-8 call fails with WVERR_ENCODING naming the call and the text", m1);
    pSetOpt(WVO_DEV_CHECKS, "0");
    const long f0 = JsonNumA(pDiag(), "encodingFallback");
    const std::string q2 = pQuote("\xC4\xE3\xBA\xC3");
    const long f1 = JsonNumA(pDiag(), "encodingFallback");
    Check(q2 == "\"\xE4\xBD\xA0\xE5\xA5\xBD\"" && f1 == f0 + 1, "dev checks off: GBK text is still read as ANSI and counted in diagnostics", q2);
    const long s0 = JsonNumA(pDiag(), "encodingSuspect");
    const std::string q3 = pQuote("\xC2\xB7");  // GBK 的“路”恰好是合法 UTF-8（·）
    Check(q3 == "\"\xC2\xB7\"" && JsonNumA(pDiag(), "encodingSuspect") == s0 + 1, "valid UTF-8 that reads as GBK Chinese is decoded as UTF-8 and counted as suspect", q3);
    pSetOpt(WVO_CODEPAGE, "936");
  }
  // ---- 1.5.0：版本文字不含编译日期（可复现构建）
  Check(std::string(pVerText()).find(__DATE__) == std::string::npos, "version text has no build date (reproducible builds)", pVerText());
  // ---- 1.5.0：开发期检查为 1 时，说明框经调度窗口在事件处理之外弹出；内容含接口名与收到的文字；同一接口再出错不再提示
  {
    pSetOpt(WVO_CODEPAGE, "65001");
    pSetOpt(WVO_DEV_CHECKS, "1");
    g_dlgCount = 0;
    g_dlgStop = 0;
    HANDLE th = CreateThread(nullptr, 0, DlgCloser, nullptr, 0, nullptr);
    const std::string r1 = pQuote("\xC4\xE3\xBA\xC3");  // GBK 的“你好”
    const int e1 = pErrCode();
    const LONG beforePump = g_dlgCount;  // 说明框是投递的：调用返回时还没有弹出
    for (DWORD t0 = GetTickCount(); g_dlgCount == 0 && GetTickCount() - t0 < 5000;) PumpMs(20);
    PumpMs(300);
    const LONG first = g_dlgCount;
    pQuote("\xC4\xE3\xBA\xC3");
    PumpMs(800);
    InterlockedExchange(&g_dlgStop, 1);
    WaitForSingleObject(th, 3000);
    CloseHandle(th);
    pSetOpt(WVO_DEV_CHECKS, "0");
    pSetOpt(WVO_CODEPAGE, "936");
    const bool text = g_dlgText.find(L"WV_JsonQuote") != std::wstring::npos && g_dlgText.find(L"\x4F60\x597D") != std::wstring::npos;
    Check(r1.empty() && e1 == WVERR_ENCODING && beforePump == 0 && first == 1 && g_dlgCount == 1 && text,
          "dev checks 1: the explanation dialog pops up once per API, after the call returns, naming the call and the text it received",
          std::to_string(beforePump) + "/" + std::to_string(first) + "/" + std::to_string(g_dlgCount) + "/" + std::to_string(text));
  }
  // ---- 1.6.3：创建选项逐行转换。易语言类把各项设置拼成一段文本，某一项漏了转换（编译后的程序按 ANSI 解释）时，
  // 原来整段都按 ANSI 解释，已经是 UTF-8 的项（这里是桥接名称“桥”）也变成乱码；现在只有漏转换的那一行按 ANSI 解释
  {
    auto pGetStr = Fn<decltype(&WV_GetStr)>("WV_GetStr");
    WNDCLASSW wc2 = {}; wc2.lpfnWndProc = DefWindowProcW; wc2.hInstance = GetModuleHandleW(nullptr); wc2.lpszClassName = L"WvTestOptParent";
    RegisterClassW(&wc2);
    HWND op = CreateWindowExW(0, L"WvTestOptParent", L"o", WS_OVERLAPPEDWINDOW, 0, 0, 300, 200, nullptr, nullptr, wc2.hInstance, nullptr);
    pSetOpt(WVO_CODEPAGE, "65001");
    pSetOpt(WVO_DEV_CHECKS, "0");
    int ho = pCreateA(op, 0, 0, 0, 0, "", "s104=\xE6\xA1\xA5\r\ns103=C:\\\xD6\xD0\r\n", nullptr);  // 桥（UTF-8）、C:\中（GBK，漏了转换）
    const std::string bn = ho ? pGetStr(ho, WVS_BRIDGE_NAME) : "", dd = ho ? pGetStr(ho, WVS_DOWNLOAD_DIR) : "";
    Check(ho != 0 && bn == "\xE6\xA1\xA5" && dd == "C:\\\xE4\xB8\xAD", "options: a line that is not UTF-8 is read as ANSI on its own, the other lines stay UTF-8", Hex(bn) + " / " + Hex(dd));
    auto pSetStr = Fn<decltype(&WV_SetStr)>("WV_SetStr");
    const int sr = ho ? pSetStr(ho, WVS_BLOCK_URLS, "*\xE6\xA1\xA5*\r\n*\xD6\xD0*") : 0;  // 每行一项：*桥*（UTF-8）、*中*（GBK，漏了转换）
    const std::string bu = ho ? pGetStr(ho, WVS_BLOCK_URLS) : "";
    Check(sr == 1 && bu == "*\xE6\xA1\xA5* *\xE4\xB8\xAD*", "list properties: each line is decoded on its own (one unconverted line does not garble the others)", Hex(bu));
    pSetOpt(WVO_DEV_CHECKS, "2");
    int hd = pCreateA(op, 0, 0, 0, 0, "", "s104=\xE6\xA1\xA5\r\ns103=C:\\\xD6\xD0\r\n", nullptr);
    const int ed = pErrCode();
    std::string em = pErr();
    Check(hd == 0 && ed == WVERR_ENCODING && em.find("s103=") != std::string::npos && em.find("s104=") == std::string::npos,
          "options with dev checks on: creation fails and the message shows only the line that is not UTF-8", std::to_string(ed) + " " + Hex(em.c_str()).substr(0, 160));
    pSetOpt(WVO_DEV_CHECKS, "0");
    pSetOpt(WVO_CODEPAGE, "936");
    if (ho) pDestroy(ho);
    DestroyWindow(op);
  }
  // ---- 1.6.4：JSON取值 的缓存不放在线程局部变量里。线程正常结束时（DLL_THREAD_DETACH）立即释放它的一项；
  // 被强制结束（TerminateThread，精易 线程_销毁）的线程留下的项在下一次没取到缓存时清掉。诊断信息里的 jsonCache 是项数与原文字节数
  {
    auto pDiag = Fn<decltype(&WV_GetDiagnostics)>("WV_GetDiagnostics");
    auto stat = [&](const char* key) {  // 直接在诊断文本里找数字，不经过 WV_JsonGet（它会改动本线程的缓存）
      std::string d = pDiag();
      size_t at = d.find(std::string("\"jsonCache\":{"));
      at = at == std::string::npos ? at : d.find(std::string("\"") + key + "\":", at);
      return at == std::string::npos ? -1L : atol(d.c_str() + at + strlen(key) + 3);
    };
    pSetOpt(WVO_CODEPAGE, "65001");
    std::string doc = "[";
    while (doc.size() < 900000) doc += doc.size() > 1 ? ",\"abcdefg\"" : "\"abcdefg\"";
    doc += "]";
    pJsonGet("[0]", "[0]");  // 本线程先有一项
    const long e0 = stat("entries"), b0 = stat("bytes");
    JcArg a{doc.c_str(), pJsonGet, 0, false};
    HANDLE t1 = CreateThread(nullptr, 0, JcThread, &a, 0, nullptr);
    WaitForSingleObject(t1, 10000);
    CloseHandle(t1);
    const long e1 = stat("entries"), b1 = stat("bytes");
    a.ready = 0;
    a.hang = true;
    HANDLE t2 = CreateThread(nullptr, 0, JcThread, &a, 0, nullptr);
    while (!a.ready) Sleep(5);
    TerminateThread(t2, 1);
    WaitForSingleObject(t2, 10000);
    CloseHandle(t2);
    const long e2 = stat("entries"), b2 = stat("bytes");
    Sleep(1100);  // 已结束线程的项最多每秒查一次
    pJsonGet("[1]", "[0]");  // 本线程没取到缓存：顺便清掉已结束线程的项
    const long e3 = stat("entries"), b3 = stat("bytes");
    pSetOpt(WVO_CODEPAGE, "936");
    Check(e0 >= 1 && e1 == e0 && b1 == b0 && e2 == e0 + 1 && b2 >= b0 + 900000 && e3 <= e0 + 1 && b3 < b0 + 1000,  // 本线程最多 4 项，"[1]" 可能挤掉本线程最久没用的一项
          "json cache: a thread that ends normally drops its entry at once; one killed with TerminateThread is cleared on the next miss",
          std::to_string(e0) + "/" + std::to_string(e1) + "/" + std::to_string(e2) + "/" + std::to_string(e3) + " bytes " + std::to_string(b0) + "/" + std::to_string(b2) + "->" + std::to_string(b3));
  }
  printf("RESULT pass=%d fail=%d\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
