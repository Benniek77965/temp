// 提示卡片截图（开发者测试）：把 DLL 源码直接编进来，逐一摆出卡片的各种状态，画到位图上存成 BMP，用来人工核对视觉效果。
// 编译：i686-w64-mingw32-g++ -std=c++17 -O2 -static -municode -DUNICODE -D_UNICODE -Isrc -Isrc\third_party\webview2\include tests\cardshot.cpp -o cardshot.exe -lole32 -luser32 -lgdi32 -ladvapi32 -lshell32 -lversion
// 运行：cardshot.exe 输出目录 [aware]   （带第二个参数时先声明 DPI 感知，按系统 DPI 绘制；Wine 里改 HKCU\Control Panel\Desktop\LogPixels 模拟高 DPI）
#include "../src/wv_util.cpp"
#include "../src/wv_runtime.cpp"
#include "../src/wv_host.cpp"
#include "../src/wv_view.cpp"
#include "../src/wv_feat.cpp"
#include "../src/wv_api.cpp"
#include <cstdio>

using namespace wv;

static std::wstring g_out;
static int g_shots = 0;

static bool SaveBmp(HDC src, int w, int h, const std::wstring& name) {
  BITMAPINFO bi;
  ZeroMemory(&bi, sizeof(bi));
  bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
  bi.bmiHeader.biWidth = w;
  bi.bmiHeader.biHeight = -h;
  bi.bmiHeader.biPlanes = 1;
  bi.bmiHeader.biBitCount = 32;
  bi.bmiHeader.biCompression = BI_RGB;
  void* bits = nullptr;
  HBITMAP bmp = CreateDIBSection(src, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
  HDC mem = CreateCompatibleDC(src);
  HGDIOBJ old = SelectObject(mem, bmp);
  BitBlt(mem, 0, 0, w, h, src, 0, 0, SRCCOPY);
  GdiFlush();
  BITMAPFILEHEADER fh;
  ZeroMemory(&fh, sizeof(fh));
  fh.bfType = 0x4D42;
  fh.bfOffBits = sizeof(fh) + sizeof(BITMAPINFOHEADER);
  fh.bfSize = fh.bfOffBits + (DWORD)w * h * 4;
  std::wstring path = g_out + L"\\" + name + L".bmp";
  FILE* f = _wfopen(path.c_str(), L"wb");
  bool ok = false;
  if (f) {
    fwrite(&fh, sizeof(fh), 1, f);
    fwrite(&bi.bmiHeader, sizeof(BITMAPINFOHEADER), 1, f);
    fwrite(bits, 4, (size_t)w * h, f);
    fclose(f);
    ok = true;
  }
  SelectObject(mem, old);
  DeleteDC(mem);
  DeleteObject(bmp);
  return ok;
}

// 把宿主窗口的内容画进内存位图再存盘（不依赖屏幕截图）
static void Shot(View* v, const wchar_t* name, bool anim = false) {
  RECT rc;
  GetClientRect(v->host, &rc);
  HDC wdc = GetDC(v->host);
  HDC mem = CreateCompatibleDC(wdc);
  HBITMAP bmp = CreateCompatibleBitmap(wdc, rc.right, rc.bottom);
  HGDIOBJ old = SelectObject(mem, bmp);
  v->Paint(mem);
  if (anim) {
    for (int i = 0; i < 7; ++i) ++v->panel.tick;
    v->PaintAnim(mem);  // 走一遍动画帧的快速路径，确认只重画动画区域且位置对得上
  }
  bool ok = SaveBmp(mem, rc.right, rc.bottom, name);
  SelectObject(mem, old);
  DeleteObject(bmp);
  DeleteDC(mem);
  ReleaseDC(v->host, wdc);
  printf("%s %ls %ldx%ld\n", ok ? "SHOT" : "FAIL", name, rc.right, rc.bottom);
  ++g_shots;
}

static void Pump(DWORD ms) {
  DWORD t = GetTickCount();
  MSG m;
  while (GetTickCount() - t < ms) {
    while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) {
      TranslateMessage(&m);
      DispatchMessageW(&m);
    }
    Sleep(5);
  }
}

static HWND MakeParent(int w, int h) {
  WNDCLASSW wc = {};
  wc.lpfnWndProc = DefWindowProcW;
  wc.hInstance = GetModuleHandleW(nullptr);
  wc.lpszClassName = L"CardShotParent";
  wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
  RegisterClassW(&wc);
  RECT r = {0, 0, w, h};
  AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
  return CreateWindowExW(0, L"CardShotParent", L"cardshot", WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_VISIBLE, 0, 0, r.right - r.left, r.bottom - r.top, nullptr, nullptr,
                         wc.hInstance, nullptr);
}

static InstallJob g_fakeJob;

int wmain(int argc, wchar_t** argv) {
  g_out = argc > 1 ? argv[1] : L".";
  if (argc > 2) SetProcessDPIAware();
  g_module = GetModuleHandleW(nullptr);
  InitOs();
  WV_SetOption(WVO_FALLBACK_UI, "1");
  const int sizes[][2] = {{900, 600}, {340, 560}};
  for (int sz = 0; sz < 2; ++sz) {
    HWND parent = MakeParent(sizes[sz][0], sizes[sz][1]);
    const std::wstring suffix = sz == 0 ? L"" : L"_narrow";
    for (int dark = 0; dark < 3; ++dark) {  // 浅色、深色，以及高对比度主题（按系统配色画）
      g_testHighContrast = dark == 2 ? +[] { return true; } : nullptr;
      int id = WV_CreateAsync(parent, 0, 0, 0, 0, "https://example.com", "", nullptr);
      Pump(100);
      RefPtr<View> v = FindView(id);
      if (!v) { printf("FAIL no view\n"); return 1; }
      if (dark) v->SetIntProp(WVP_BG_COLOR, (int)0xFF202124);
      std::wstring t = (dark == 2 ? L"hc" : dark ? L"dark" : L"light") + suffix;
      auto state = [&](int code, const std::wstring& msg, HRESULT hr, bool legacy, bool plain) {
        v->errCode = code;
        v->errMsg = msg;
        v->errHr = hr;
        v->errPlain = plain;
        g_os.legacy = legacy;
        v->SetPanel(2);
      };
      state(WVERR_NO_RUNTIME, L"没有找到 WebView2 运行时", S_OK, false, true);
      Shot(v.get(), (L"01_noruntime_" + t).c_str());
      v->panel.hot = 0;
      Shot(v.get(), (L"02_hover_primary_" + t).c_str());
      v->panel.hot = -1;
      SetFocus(v->host);
      v->panel.focus = 1;
      v->panel.kbd = true;
      Shot(v.get(), (L"03_keyboard_focus_" + t).c_str());
      v->panel.kbd = false;
      state(WVERR_NO_RUNTIME, L"找到的是 64 位 WebView2 运行时（D:\\app\\WebView2\\Microsoft.WebView2.FixedVersionRuntime.109.0.1518.140.x64），本程序是 32 位，需要 x86 版本的固定版运行时（目录名以 .x86 结尾）", S_OK, false, false);
      Shot(v.get(), (L"04_noruntime_wrongarch_" + t).c_str());
      v->recheckPending = true;
      state(WVERR_NO_RUNTIME, L"没有找到", S_OK, true, true);
      Shot(v.get(), (L"05_legacy_rechecked_" + t).c_str());
      g_onlineInstallerOverride = 0;  // 1.8.0：真实的 Windows 7（微软的在线安装程序启动不了）：一键安装改用 109 版离线安装包
      const int realMajor = g_os.major, realMinor = g_os.minor;
      g_os.major = 6;
      g_os.minor = 1;
      v->recheckPending = false;
      state(WVERR_NO_RUNTIME, L"没有找到", S_OK, true, true);
      Shot(v.get(), (L"05c_win7_offline_package_" + t).c_str());
      g_fakeJob.done = 0;
      g_fakeJob.start = GetTickCount() - 30000;
      g_fakeJob.stage = 1;
      g_fakeJob.permille = 420;
      g_job = &g_fakeJob;
      v->SetPanel(3);
      Shot(v.get(), (L"05d_win7_installing_package_" + t).c_str(), true);
      g_job = nullptr;
      g_os.major = realMajor;
      g_os.minor = realMinor;
      g_onlineInstallerOverride = -1;
      WV_SetOption(WVO_RUNTIME_POLICY, "3");  // 只用固定版运行时：不提供一键安装
      state(WVERR_NO_RUNTIME, L"没有找到", S_OK, false, true);
      Shot(v.get(), (L"05b_fixed_only_" + t).c_str());
      WV_SetOption(WVO_RUNTIME_POLICY, "0");
      state(WVERR_INSTALL, L"下载引导程序失败：无法连接到服务器（0x800C0005）（请检查网络或代理）", S_OK, false, false);
      Shot(v.get(), (L"06_install_failed_" + t).c_str());
      state(WVERR_ENV_FAILED, L"浏览器环境创建失败：用户数据目录无法写入（权限不足，或该目录正被以管理员身份运行的另一个程序占用）", (HRESULT)0x80070005, false, false);
      Shot(v.get(), (L"07_env_failed_" + t).c_str());
      // 1.8.0 新增的几种卡片：权限加不上（原因里带两条完整命令，最长）、文件暂时被占用、文件不全、本次运行中已失效（固定版、装好的常青版）、放在网络位置
      state(WVERR_CTRL_FAILED, L"Windows 10 上 120 及以上版本的固定版运行时要给“所有应用程序包”读取和执行权限（微软的要求，否则网页组件一启动就崩溃），自动设置没有成功（拒绝访问。 0x80070005）。请以管理员身份运行 icacls \"D:\\app\\WebView2\\Microsoft.WebView2.FixedVersionRuntime.120.0.2210.91.x86\" /grant *S-1-15-2-2:(OI)(CI)(RX) 与 icacls \"D:\\app\\WebView2\\Microsoft.WebView2.FixedVersionRuntime.120.0.2210.91.x86\" /grant *S-1-15-2-1:(OI)(CI)(RX)，然后点“重试”", E_ACCESSDENIED, false, false);
      Shot(v.get(), (L"13_ctrl_acl_" + t).c_str());
      state(WVERR_CTRL_FAILED, L"网页组件的文件暂时打不开：icudtl.dat 正被其他程序占用（另一个程序正在使用此文件，进程无法访问。 0x80070020）。稍后会自动重试", HRESULT_FROM_WIN32(ERROR_SHARING_VIOLATION), false, false);
      Shot(v.get(), (L"14_ctrl_busy_" + t).c_str());
      v->errBroken = true;
      state(WVERR_NO_RUNTIME, L"找到的 WebView2 运行时文件不完整，没有使用：E:\\xddck\\fanxing\\WebView2\\109.0.1518.78（缺少 icudtl.dat）", S_OK, false, false);
      Shot(v.get(), (L"15_broken_files_" + t).c_str());
      v->errRestart = true;
      state(WVERR_NO_RUNTIME, L"运行时 E:\\xddck\\fanxing\\WebView2\\109.0.1518.78 在本次运行中已经启动失败（运行时组件报告找不到文件：启动时 msedgewebview2.exe 或 icudtl.dat 打不开（可能被杀毒软件拦截或临时占用）），运行时组件会记住这次失败，修复后要重新启动程序才能再用它", S_OK, false, false);
      Shot(v.get(), (L"16_restart_fixed_" + t).c_str());
      v->errRestartInstalled = true;
      state(WVERR_NO_RUNTIME, L"运行时 C:\\Program Files (x86)\\Microsoft\\EdgeWebView\\Application\\130.0.2849.80 在本次运行中已经启动失败（运行时组件报告找不到文件：启动时 msedgewebview2.exe 或 icudtl.dat 打不开（可能被杀毒软件拦截或临时占用）），运行时组件会记住这次失败，修复后要重新启动程序才能再用它", S_OK, false, false);
      Shot(v.get(), (L"17_restart_installed_" + t).c_str());
      v->errRestart = v->errRestartInstalled = false;
      v->errNetwork = true;
      state(WVERR_NO_RUNTIME, L"找到的 WebView2 固定版运行时没有使用：\\\\nas\\share\\app\\WebView2\\109.0.1518.78（固定版运行时放在网络位置（共享文件夹或网络驱动器），微软说明固定版目前不能从网络位置运行，请放到本机磁盘上）", S_OK, false, false);
      Shot(v.get(), (L"18_network_" + t).c_str());
      v->errBroken = v->errNetwork = false;
      // 本次运行中已失效：Win7 只用固定版（没有一键安装）与只用固定版两种卡片
      v->errBroken = v->errRestart = true;
      WV_SetOption(WVO_RUNTIME_POLICY, "3");
      state(WVERR_NO_RUNTIME, L"运行时 E:\\xddck\\fanxing\\WebView2\\109.0.1518.78 在本次运行中已经启动失败（运行时组件报告找不到文件：启动时 msedgewebview2.exe 或 icudtl.dat 打不开（可能被杀毒软件拦截或临时占用）），运行时组件会记住这次失败，修复后要重新启动程序才能再用它", S_OK, true, false);
      Shot(v.get(), (L"16b_restart_legacy_" + t).c_str());
      state(WVERR_NO_RUNTIME, L"运行时 E:\\xddck\\fanxing\\WebView2\\109.0.1518.78 在本次运行中已经启动失败（运行时组件报告找不到文件：启动时 msedgewebview2.exe 或 icudtl.dat 打不开（可能被杀毒软件拦截或临时占用）），运行时组件会记住这次失败，修复后要重新启动程序才能再用它", S_OK, false, false);
      Shot(v.get(), (L"16c_restart_fixedonly_" + t).c_str());
      WV_SetOption(WVO_RUNTIME_POLICY, "0");
      v->errBroken = v->errRestart = false;
      v->SetPanel(4);
      Shot(v.get(), (L"08_crashed_" + t).c_str());
      // 安装中：用伪造的安装任务摆出各阶段
      g_os.legacy = false;
      g_fakeJob.done = 0;
      g_fakeJob.start = GetTickCount() - 3000;
      g_fakeJob.stage = 1;
      g_fakeJob.permille = 420;
      g_job = &g_fakeJob;
      v->errCode = WVERR_NO_RUNTIME;
      v->SetPanel(3);
      Shot(v.get(), (L"09_installing_download_" + t).c_str(), true);
      g_fakeJob.stage = 3;
      g_fakeJob.start = GetTickCount() - 95000;
      v->panel.tick = 9;
      Shot(v.get(), (L"10_installing_setup_" + t).c_str(), true);
      g_job = nullptr;  // 1.8.0：程序自己的准备工作（WV_ShowProgress），例如安装不成功后从自己的服务器下载运行时
      v->errCode = WVERR_INSTALL;
      v->SetPanel(2);
      v->ShowHostProgress(L"正在下载网页组件", L"没能自动安装微软官方的网页组件（WebView2 运行时），正在从服务器下载，完成后页面会自动打开。", L"正在下载…", -1);
      Shot(v.get(), (L"10c_host_progress_" + t).c_str(), true);
      v->ShowHostProgress(L"", L"", L"", -1);
      g_job = &g_fakeJob;
      v->errCode = WVERR_NO_RUNTIME;
      v->SetPanel(3);
      g_fakeJob.stage = 4;  // 1.8.0：另一个程序正在安装，等它完成
      g_fakeJob.start = GetTickCount() - 20000;
      Shot(v.get(), (L"10b_installing_wait_" + t).c_str(), true);
      // 性能：整卡重画与动画帧各 200 次的平均耗时（动画帧只重画进度条那一小块）
      {
        RECT rc;
        GetClientRect(v->host, &rc);
        HDC wdc = GetDC(v->host);
        HDC mem = CreateCompatibleDC(wdc);
        HBITMAP bmp = CreateCompatibleBitmap(wdc, rc.right, rc.bottom);
        HGDIOBJ old = SelectObject(mem, bmp);
        LARGE_INTEGER fq, t0, t1, t2;
        QueryPerformanceFrequency(&fq);
        QueryPerformanceCounter(&t0);
        for (int i = 0; i < 200; ++i) v->Paint(mem);
        QueryPerformanceCounter(&t1);
        for (int i = 0; i < 200; ++i) {
          ++v->panel.tick;
          v->PaintAnim(mem);
        }
        QueryPerformanceCounter(&t2);
        printf("PERF %ls full=%.0fus anim=%.0fus area=%ldx%ld\n", t.c_str(), (t1.QuadPart - t0.QuadPart) * 1e6 / fq.QuadPart / 200.0,
               (t2.QuadPart - t1.QuadPart) * 1e6 / fq.QuadPart / 200.0, rc.right, rc.bottom);
        SelectObject(mem, old);
        DeleteObject(bmp);
        DeleteDC(mem);
        ReleaseDC(v->host, wdc);
      }
      g_fakeJob.done = 1;
      g_job = nullptr;
      // 启动中（超过 1.2 秒、超过 6 秒）
      v->SetPanel(1);
      v->panel.slowShown = true;
      v->panel.tick = 3;
      Shot(v.get(), (L"11_starting_" + t).c_str(), true);
      v->panel.hintShown = true;
      Shot(v.get(), (L"12_starting_hint_" + t).c_str());
      v->SetPanel(0);
      WV_Destroy(id);
      Pump(50);
    }
    DestroyWindow(parent);
  }
  g_testHighContrast = nullptr;
  printf("RESULT shots=%d\n", g_shots);
  return 0;
}
