// 两个线程几乎同时首次用各自的窗口创建浏览器：每个进程只有一个界面线程，结果必须是确定的：
// 只登记一个界面线程（诊断日志中“界面线程 #”只出现一次），它的浏览器创建成功并能跟随父窗口调整大小，
// 另一个线程每次都得到 WVERR_THREAD，不会时而成功时而失败
// 在没有 WebView2 运行时的环境中运行（创建走提示卡片），可多次运行观察：racetest.exe
#include <windows.h>
#include <cstdio>
#include <string>
#include "wv2bridge.h"
static decltype(&WV_Create) pCreate;
static decltype(&WV_GetWindow) pGetWindow;
static decltype(&WV_LastErrorCode) pErr;
static volatile LONG g_ready = 0, g_go = 0, g_follow = 0, g_created = 0, g_threadErr = 0;
static DWORD WINAPI Worker(void*) {
  HWND w = CreateWindowExW(0, L"STATIC", L"", WS_OVERLAPPEDWINDOW, 0, 0, 300, 200, nullptr, nullptr, nullptr, nullptr);
  InterlockedIncrement(&g_ready);
  while (!g_go) YieldProcessor();
  int h = pCreate(w, 0, 0, 0, 0, "about:blank", nullptr, 0);  // 宽高为 0：铺满父窗口
  if (h > 0) InterlockedIncrement(&g_created);
  else if (pErr() == WVERR_THREAD) InterlockedIncrement(&g_threadErr);
  MSG m;
  DWORD t0 = GetTickCount();
  while (GetTickCount() - t0 < 400) {
    while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); }
    Sleep(5);
  }
  SetWindowPos(w, nullptr, 0, 0, 520, 410, SWP_NOMOVE | SWP_NOZORDER);
  t0 = GetTickCount();
  while (GetTickCount() - t0 < 200) {
    while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); }
    Sleep(5);
  }
  HWND host = (HWND)(intptr_t)pGetWindow(h, 0);
  RECT pc{}, hr{};
  GetClientRect(w, &pc);
  GetWindowRect(host, &hr);
  if (host && hr.right - hr.left == pc.right && hr.bottom - hr.top == pc.bottom) InterlockedIncrement(&g_follow);
  return 0;
}
int main() {
  HMODULE dll = LoadLibraryW(L"WebView2Bridge.dll");
  pCreate = reinterpret_cast<decltype(&WV_Create)>(reinterpret_cast<void*>(GetProcAddress(dll, "WV_Create")));
  pErr = reinterpret_cast<decltype(&WV_LastErrorCode)>(reinterpret_cast<void*>(GetProcAddress(dll, "WV_LastErrorCode")));
  pGetWindow = reinterpret_cast<decltype(&WV_GetWindow)>(reinterpret_cast<void*>(GetProcAddress(dll, "WV_GetWindow")));
  auto pSet = reinterpret_cast<decltype(&WV_SetOption)>(reinterpret_cast<void*>(GetProcAddress(dll, "WV_SetOption")));
  wchar_t b[MAX_PATH];
  GetModuleFileNameW(nullptr, b, MAX_PATH);
  std::wstring d(b);
  d = d.substr(0, d.find_last_of(L'\\'));
  std::wstring log = d + L"\\race.log", empty = d + L"\\raceempty";
  DeleteFileW(log.c_str());
  CreateDirectoryW(empty.c_str(), nullptr);
  char a[MAX_PATH];
  WideCharToMultiByte(CP_ACP, 0, log.c_str(), -1, a, MAX_PATH, nullptr, nullptr);
  pSet(WVO_LOG_FILE, a);
  WideCharToMultiByte(CP_ACP, 0, empty.c_str(), -1, a, MAX_PATH, nullptr, nullptr);
  pSet(WVO_APP_DIR, a);
  HANDLE t[2];
  for (int i = 0; i < 2; ++i) t[i] = CreateThread(nullptr, 0, Worker, nullptr, 0, nullptr);
  while (g_ready < 2) Sleep(0);
  g_go = 1;
  WaitForMultipleObjects(2, t, TRUE, 10000);
  HANDLE f = CreateFileW(log.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
  std::string s;
  if (f != INVALID_HANDLE_VALUE) { DWORD n = GetFileSize(f, nullptr), r = 0; s.resize(n); ReadFile(f, &s[0], n, &r, nullptr); CloseHandle(f); }
  int inits = 0;
  for (size_t p = 0; (p = s.find("\xE7\x95\x8C\xE9\x9D\xA2\xE7\xBA\xBF\xE7\xA8\x8B #", p)) != std::string::npos; ++p) ++inits;  // “界面线程 #”的 UTF-8
  printf("RACE inits=%d created=%d threadErr=%d follow=%d\n", inits, (int)g_created, (int)g_threadErr, (int)g_follow);
  fflush(stdout);
  ExitProcess(inits == 1 && g_created == 1 && g_threadErr == 1 && g_follow == 1 ? 0 : 1);
}
