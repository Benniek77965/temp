#include <map>
#include <typeinfo>
// 模拟 WebView2 运行时（EmbeddedBrowserWebView.dll）：只实现 WebView2Bridge 用到的接口，所有调用写入有序日志
#include <windows.h>
#include <objbase.h>
#include <string>
#include <vector>
#include <functional>
#include <memory>
#include <mutex>
#include "WebView2.h"
#include "wv_iids.h"
#include "mock_stubs.h"
static std::mutex g_mx;
static std::vector<std::wstring> g_log;
static void Log(const std::wstring& s) { std::lock_guard<std::mutex> l(g_mx); g_log.push_back(s); }
static LPWSTR Dup(const std::wstring& s) { size_t n = (s.size() + 1) * sizeof(wchar_t); LPWSTR p = (LPWSTR)CoTaskMemAlloc(n); memcpy(p, s.c_str(), n); return p; }
static HWND g_disp;
static LRESULT CALLBACK DispProc(HWND h, UINT m, WPARAM w, LPARAM l) {
  if (m == WM_APP + 77) { std::unique_ptr<std::function<void()>> f((std::function<void()>*)l); (*f)(); return 0; }
  return DefWindowProcW(h, m, w, l);
}
static void Defer(std::function<void()> f) {  // 与真实 WebView2 一样：完成回调与事件经界面线程的消息循环送达
  if (!g_disp) {
    WNDCLASSW wc = {}; wc.lpfnWndProc = DispProc; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"MockWv2Disp"; RegisterClassW(&wc);
    g_disp = CreateWindowExW(0, L"MockWv2Disp", L"", 0, 0, 0, 0, 0, HWND_MESSAGE, nullptr, wc.hInstance, nullptr);
  }
  PostMessageW(g_disp, WM_APP + 77, 0, (LPARAM) new std::function<void()>(std::move(f)));
}
// 存活对象计数，用来检查 DLL 有没有漏掉 Release：按类型统计，Mock_Live 取总数，Mock_LiveReport 列出各类型数量
static CRITICAL_SECTION& LiveCs() { static CRITICAL_SECTION cs; static bool init = (InitializeCriticalSection(&cs), true); (void)init; return cs; }
static std::map<std::string, LONG>& LiveMap() { static std::map<std::string, LONG> m; return m; }
static void LiveTrack(const char* name, LONG d) { EnterCriticalSection(&LiveCs()); LiveMap()[name] += d; LeaveCriticalSection(&LiveCs()); }
struct LiveTag { const char* n; explicit LiveTag(const char* name) : n(name) { LiveTrack(n, 1); } ~LiveTag() { LiveTrack(n, -1); } };
template <class S, class I> struct Com : public S {
  LONG refs_ = 1;
  LiveTag live_{typeid(S).name()};
  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppv) override {
    if (!ppv) return E_POINTER;
    if (IsEqualIID(riid, wv::wv_iid<::IUnknown>::get()) || IsEqualIID(riid, wv::wv_iid<I>::get())) { *ppv = static_cast<I*>(this); this->AddRef(); return S_OK; }
    *ppv = nullptr; return E_NOINTERFACE;
  }
  ULONG STDMETHODCALLTYPE AddRef() override { return InterlockedIncrement(&refs_); }
  ULONG STDMETHODCALLTYPE Release() override { LONG r = InterlockedDecrement(&refs_); if (!r) delete this; return r; }
  virtual ~Com() {}
};
template <class T> static std::vector<T*> Snap(const std::vector<T*>& v) { for (auto* x : v) x->AddRef(); return v; }
template <class T> static void Drop(std::vector<T*>& v) { for (auto* x : v) x->Release(); }
struct MockDeferral : Com<Stub_ICoreWebView2Deferral, ICoreWebView2Deferral> {
  std::wstring tag; bool done = false; std::function<void()> onComplete;
  HRESULT STDMETHODCALLTYPE Complete() override {
    Log((done ? L"Deferral.DoubleComplete:" : L"Deferral.Complete:") + tag);
    if (!done && onComplete) Defer(onComplete);
    done = true; return S_OK;
  }
};
struct NavStartArgs : Com<Stub_ICoreWebView2NavigationStartingEventArgs, ICoreWebView2NavigationStartingEventArgs> {
  std::wstring uri; BOOL cancel = FALSE;
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR* u) override { *u = Dup(uri); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_IsUserInitiated(BOOL* b) override { *b = FALSE; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_IsRedirected(BOOL* b) override { *b = FALSE; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Cancel(BOOL* b) override { *b = cancel; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Cancel(BOOL b) override { cancel = b; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_NavigationId(UINT64* v) override { *v = 1; return S_OK; }
};
struct NavDoneArgs : Com<Stub_ICoreWebView2NavigationCompletedEventArgs, ICoreWebView2NavigationCompletedEventArgs> {
  HRESULT STDMETHODCALLTYPE get_IsSuccess(BOOL* b) override { *b = TRUE; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_WebErrorStatus(COREWEBVIEW2_WEB_ERROR_STATUS* s) override { *s = COREWEBVIEW2_WEB_ERROR_STATUS_UNKNOWN; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_NavigationId(UINT64* v) override { *v = 1; return S_OK; }
};
struct SrcArgs : Com<Stub_ICoreWebView2SourceChangedEventArgs, ICoreWebView2SourceChangedEventArgs> {
  HRESULT STDMETHODCALLTYPE get_IsNewDocument(BOOL* b) override { *b = TRUE; return S_OK; }
};
static std::wstring g_nextSource;  // 下一条网页消息的来源（空＝默认 https://a.test/）
static std::wstring TakeSource() { std::wstring s = g_nextSource.empty() ? L"https://a.test/" : g_nextSource; g_nextSource.clear(); return s; }
// 1.8.2：模拟 postMessageWithAdditionalObjects 附带的文件（ICoreWebView2File）与集合（ICoreWebView2ObjectCollectionView）
struct MockFile : Com<Stub_ICoreWebView2File, ICoreWebView2File> {
  std::wstring path;
  HRESULT STDMETHODCALLTYPE get_Path(LPWSTR* p) override { *p = Dup(path); return S_OK; }
};
struct MockObjColl : Com<Stub_ICoreWebView2ObjectCollectionView, ICoreWebView2ObjectCollectionView> {
  std::vector<IUnknown*> items;  // nullptr 表示 null/undefined 项
  ~MockObjColl() override { for (auto* x : items) if (x) x->Release(); }
  HRESULT STDMETHODCALLTYPE get_Count(UINT* c) override { *c = (UINT)items.size(); return S_OK; }
  HRESULT STDMETHODCALLTYPE GetValueAtIndex(UINT i, IUnknown** v) override { if (i >= items.size()) return E_INVALIDARG; *v = items[i]; if (items[i]) items[i]->AddRef(); return S_OK; }
};
struct MsgArgs : Com<Stub_ICoreWebView2WebMessageReceivedEventArgs2, ICoreWebView2WebMessageReceivedEventArgs2> {
  std::wstring json;
  std::wstring src = TakeSource();
  std::vector<std::wstring> files;  // 为空＝不实现 args2 的集合返回（内核更老，没有附带对象）
  bool haveColl = false;
  // QI：args2 不可用时（haveColl 为假）只认 args，和运行时 113 以下一致
  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppv) override {
    if (!ppv) return E_POINTER;
    if (IsEqualIID(riid, wv::wv_iid<::IUnknown>::get()) || IsEqualIID(riid, wv::wv_iid<ICoreWebView2WebMessageReceivedEventArgs>::get())) { *ppv = static_cast<ICoreWebView2WebMessageReceivedEventArgs*>(this); AddRef(); return S_OK; }
    if (haveColl && IsEqualIID(riid, wv::wv_iid<ICoreWebView2WebMessageReceivedEventArgs2>::get())) { *ppv = static_cast<ICoreWebView2WebMessageReceivedEventArgs2*>(this); AddRef(); return S_OK; }
    *ppv = nullptr; return E_NOINTERFACE;
  }
  HRESULT STDMETHODCALLTYPE get_Source(LPWSTR* s) override { *s = Dup(src.c_str()); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_WebMessageAsJson(LPWSTR* s) override { *s = Dup(json); return S_OK; }
  HRESULT STDMETHODCALLTYPE TryGetWebMessageAsString(LPWSTR* s) override { *s = nullptr; return E_INVALIDARG; }
  HRESULT STDMETHODCALLTYPE get_AdditionalObjects(ICoreWebView2ObjectCollectionView** v) override {
    auto* c = new MockObjColl();
    for (auto& f : files) {
      if (f == L"<null>") { c->items.push_back(nullptr); continue; }  // 混入一个 null 项
      auto* mf = new MockFile(); mf->path = f; c->items.push_back(mf);
    }
    *v = c; return S_OK;
  }
};
struct NewWinArgs : Com<Stub_ICoreWebView2NewWindowRequestedEventArgs, ICoreWebView2NewWindowRequestedEventArgs> {
  std::wstring uri; BOOL handled = FALSE;
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR* u) override { *u = Dup(uri); return S_OK; }
  HRESULT STDMETHODCALLTYPE put_NewWindow(ICoreWebView2*) override { Log(L"NewWindow.put_NewWindow"); return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Handled(BOOL b) override { handled = b; Log(L"NewWindow.Handled=" + std::to_wstring(b)); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Handled(BOOL* b) override { *b = handled; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_IsUserInitiated(BOOL* b) override { *b = TRUE; return S_OK; }
  HRESULT STDMETHODCALLTYPE GetDeferral(ICoreWebView2Deferral** d) override { auto* x = new MockDeferral(); x->tag = L"NewWindow"; *d = x; Log(L"NewWindow.GetDeferral"); return S_OK; }
};
struct PermArgs : Com<Stub_ICoreWebView2PermissionRequestedEventArgs, ICoreWebView2PermissionRequestedEventArgs> {
  std::wstring uri; COREWEBVIEW2_PERMISSION_KIND kind = COREWEBVIEW2_PERMISSION_KIND_CAMERA;
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR* u) override { *u = Dup(uri); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_PermissionKind(COREWEBVIEW2_PERMISSION_KIND* k) override { *k = kind; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_IsUserInitiated(BOOL* b) override { *b = TRUE; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_State(COREWEBVIEW2_PERMISSION_STATE* s) override { *s = COREWEBVIEW2_PERMISSION_STATE_DEFAULT; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_State(COREWEBVIEW2_PERMISSION_STATE s) override { Log(L"Permission.State=" + std::to_wstring((int)s)); return S_OK; }
  HRESULT STDMETHODCALLTYPE GetDeferral(ICoreWebView2Deferral** d) override { auto* x = new MockDeferral(); x->tag = L"Permission"; *d = x; Log(L"Permission.GetDeferral"); return S_OK; }
};
struct MockHeaders : Com<Stub_ICoreWebView2HttpRequestHeaders, ICoreWebView2HttpRequestHeaders> {
  HRESULT STDMETHODCALLTYPE SetHeader(LPCWSTR n, LPCWSTR v) override { Log(L"Header.Set:" + std::wstring(n) + L"=" + v); return S_OK; }
  HRESULT STDMETHODCALLTYPE RemoveHeader(LPCWSTR n) override { Log(L"Header.Remove:" + std::wstring(n)); return S_OK; }
};
struct MockRequest : Com<Stub_ICoreWebView2WebResourceRequest, ICoreWebView2WebResourceRequest> {
  std::wstring uri; MockHeaders* hdr = new MockHeaders();
  ~MockRequest() override { hdr->Release(); }
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR* u) override { *u = Dup(uri); return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Uri(LPCWSTR u) override { Log(L"Request.Uri=" + std::wstring(u)); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Method(LPWSTR* m) override { *m = Dup(L"GET"); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Content(IStream** c) override { *c = nullptr; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Headers(ICoreWebView2HttpRequestHeaders** h) override { hdr->AddRef(); *h = hdr; return S_OK; }
};
struct MockResponse : Com<Stub_ICoreWebView2WebResourceResponse, ICoreWebView2WebResourceResponse> {};
struct ReqArgs : Com<Stub_ICoreWebView2WebResourceRequestedEventArgs, ICoreWebView2WebResourceRequestedEventArgs> {
  MockRequest* req = new MockRequest(); COREWEBVIEW2_WEB_RESOURCE_CONTEXT ctx = COREWEBVIEW2_WEB_RESOURCE_CONTEXT_DOCUMENT;
  ~ReqArgs() override { req->Release(); }
  HRESULT STDMETHODCALLTYPE get_Request(ICoreWebView2WebResourceRequest** r) override { req->AddRef(); *r = req; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Response(ICoreWebView2WebResourceResponse** r) override { *r = nullptr; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Response(ICoreWebView2WebResourceResponse*) override { Log(L"Request.put_Response"); return S_OK; }
  HRESULT STDMETHODCALLTYPE GetDeferral(ICoreWebView2Deferral** d) override { auto* x = new MockDeferral(); x->tag = L"Request"; *d = x; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_ResourceContext(COREWEBVIEW2_WEB_RESOURCE_CONTEXT* c) override { *c = ctx; return S_OK; }
};
struct FailArgs : Com<Stub_ICoreWebView2ProcessFailedEventArgs, ICoreWebView2ProcessFailedEventArgs> {
  COREWEBVIEW2_PROCESS_FAILED_KIND kind = COREWEBVIEW2_PROCESS_FAILED_KIND_BROWSER_PROCESS_EXITED;
  HRESULT STDMETHODCALLTYPE get_ProcessFailedKind(COREWEBVIEW2_PROCESS_FAILED_KIND* k) override { *k = kind; return S_OK; }
};
struct MockCookie : Com<Stub_ICoreWebView2Cookie, ICoreWebView2Cookie> {
  std::wstring name, value, domain, path; double expires = -1; BOOL http = FALSE, secure = FALSE; COREWEBVIEW2_COOKIE_SAME_SITE_KIND ss = COREWEBVIEW2_COOKIE_SAME_SITE_KIND_LAX;
  HRESULT STDMETHODCALLTYPE get_Name(LPWSTR* v) override { *v = Dup(name); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Value(LPWSTR* v) override { *v = Dup(value); return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Value(LPCWSTR v) override { value = v; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Domain(LPWSTR* v) override { *v = Dup(domain); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Path(LPWSTR* v) override { *v = Dup(path); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Expires(double* v) override { *v = expires; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Expires(double v) override { expires = v; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_IsHttpOnly(BOOL* v) override { *v = http; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_IsHttpOnly(BOOL v) override { http = v; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_SameSite(COREWEBVIEW2_COOKIE_SAME_SITE_KIND* v) override { *v = ss; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_SameSite(COREWEBVIEW2_COOKIE_SAME_SITE_KIND v) override { ss = v; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_IsSecure(BOOL* v) override { *v = secure; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_IsSecure(BOOL v) override { secure = v; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_IsSession(BOOL* v) override { *v = expires < 0; return S_OK; }
};
struct MockCookieList : Com<Stub_ICoreWebView2CookieList, ICoreWebView2CookieList> {
  std::vector<MockCookie*> items;
  ~MockCookieList() override { for (auto* c : items) c->Release(); }
  HRESULT STDMETHODCALLTYPE get_Count(UINT* n) override { *n = (UINT)items.size(); return S_OK; }
  HRESULT STDMETHODCALLTYPE GetValueAtIndex(UINT i, ICoreWebView2Cookie** c) override { if (i >= items.size()) return E_INVALIDARG; items[i]->AddRef(); *c = items[i]; return S_OK; }
};
struct MockCookieManager : Com<Stub_ICoreWebView2CookieManager, ICoreWebView2CookieManager> {
  std::vector<MockCookie*> store;
  ~MockCookieManager() override { for (auto* c : store) c->Release(); }
  HRESULT STDMETHODCALLTYPE CreateCookie(LPCWSTR n, LPCWSTR v, LPCWSTR d, LPCWSTR p, ICoreWebView2Cookie** out) override {
    auto* c = new MockCookie(); c->name = n; c->value = v; c->domain = d; c->path = p; *out = c; return S_OK;
  }
  HRESULT STDMETHODCALLTYPE GetCookies(LPCWSTR uri, ICoreWebView2GetCookiesCompletedHandler* h) override {
    Log(L"Cookie.Get:" + std::wstring(uri ? uri : L"(all)"));
    auto* l = new MockCookieList(); for (auto* c : store) { c->AddRef(); l->items.push_back(c); }
    h->AddRef(); Defer([h, l] { h->Invoke(S_OK, l); l->Release(); h->Release(); }); return S_OK;
  }
  HRESULT STDMETHODCALLTYPE AddOrUpdateCookie(ICoreWebView2Cookie* ci) override {
    auto* c = static_cast<MockCookie*>(ci);
    for (auto& x : store) if (x->name == c->name && x->domain == c->domain && x->path == c->path) { x->Release(); x = c; c->AddRef(); Log(L"Cookie.Update:" + c->name); return S_OK; }
    c->AddRef(); store.push_back(c); Log(L"Cookie.Add:" + c->name); return S_OK;
  }
  void RemoveIf(const std::function<bool(MockCookie*)>& f) { for (size_t i = store.size(); i-- > 0;) if (f(store[i])) { store[i]->Release(); store.erase(store.begin() + i); } }
  HRESULT STDMETHODCALLTYPE DeleteCookie(ICoreWebView2Cookie* ci) override { std::wstring n = static_cast<MockCookie*>(ci)->name; Log(L"Cookie.Delete:" + n); RemoveIf([&](MockCookie* x) { return x->name == n; }); return S_OK; }
  HRESULT STDMETHODCALLTYPE DeleteCookies(LPCWSTR n, LPCWSTR uri) override { std::wstring nn = n; Log(L"Cookie.DeleteCookies:" + nn + L"@" + (uri ? uri : L"(null)")); RemoveIf([&](MockCookie* x) { return x->name == nn; }); return S_OK; }
  HRESULT STDMETHODCALLTYPE DeleteAllCookies() override { Log(L"Cookie.DeleteAll"); RemoveIf([](MockCookie*) { return true; }); return S_OK; }
};
static IStream* MemStream(const std::string& b) { IStream* st = nullptr; CreateStreamOnHGlobal(nullptr, TRUE, &st); ULONG w = 0; st->Write(b.data(), (ULONG)b.size(), &w); LARGE_INTEGER z{}; st->Seek(z, STREAM_SEEK_SET, nullptr); return st; }
struct RespView : Com<Stub_ICoreWebView2WebResourceResponseView, ICoreWebView2WebResourceResponseView> {
  int status = 200; std::string body;
  HRESULT STDMETHODCALLTYPE get_StatusCode(int* v) override { *v = status; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_ReasonPhrase(LPWSTR* v) override { *v = Dup(L"OK"); return S_OK; }
  HRESULT STDMETHODCALLTYPE GetContent(ICoreWebView2WebResourceResponseViewGetContentCompletedHandler* h) override {
    Log(L"Response.GetContent"); std::string b = body; h->AddRef(); Defer([h, b] { IStream* st = MemStream(b); h->Invoke(S_OK, st); st->Release(); h->Release(); }); return S_OK;
  }
};
struct DomArgs : Com<Stub_ICoreWebView2DOMContentLoadedEventArgs, ICoreWebView2DOMContentLoadedEventArgs> {
  HRESULT STDMETHODCALLTYPE get_NavigationId(UINT64* v) override { *v = 1; return S_OK; }
};
static bool g_holdDownloads = false;                       // Mock_HoldDownloads(1) 期间下载停在“进行中”，放开后再走完
static std::vector<std::function<void()>> g_heldDownloads;
struct DlOp : Com<Stub_ICoreWebView2DownloadOperation, ICoreWebView2DownloadOperation> {
  std::wstring uri, path; INT64 total = 0, got = 0; COREWEBVIEW2_DOWNLOAD_STATE state = COREWEBVIEW2_DOWNLOAD_STATE_IN_PROGRESS;
  std::vector<ICoreWebView2BytesReceivedChangedEventHandler*> bytesH; std::vector<ICoreWebView2StateChangedEventHandler*> stateH;
  ~DlOp() override { Drop(bytesH); Drop(stateH); }
  HRESULT STDMETHODCALLTYPE add_BytesReceivedChanged(ICoreWebView2BytesReceivedChangedEventHandler* h, EventRegistrationToken* t) override { h->AddRef(); bytesH.push_back(h); if (t) t->value = 1; return S_OK; }
  HRESULT STDMETHODCALLTYPE add_StateChanged(ICoreWebView2StateChangedEventHandler* h, EventRegistrationToken* t) override { h->AddRef(); stateH.push_back(h); if (t) t->value = 2; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR* v) override { *v = Dup(uri); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_ContentDisposition(LPWSTR* v) override { *v = Dup(L"attachment"); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_MimeType(LPWSTR* v) override { *v = Dup(L"application/pdf"); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_TotalBytesToReceive(INT64* v) override { *v = total; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_BytesReceived(INT64* v) override { *v = got; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_ResultFilePath(LPWSTR* v) override { *v = Dup(path); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_State(COREWEBVIEW2_DOWNLOAD_STATE* v) override { *v = state; return S_OK; }
  bool canceled = false;
  HRESULT STDMETHODCALLTYPE Cancel() override { Log(L"DlOp.Cancel"); canceled = true; return S_OK; }
  HRESULT STDMETHODCALLTYPE Pause() override { Log(L"DlOp.Pause"); return S_OK; }
  HRESULT STDMETHODCALLTYPE Resume() override { Log(L"DlOp.Resume"); return S_OK; }
  void Run() {  // 模拟下载：十次进度，然后完成；被取消时以“中断”结束
    if (canceled) { state = COREWEBVIEW2_DOWNLOAD_STATE_INTERRUPTED; Log(L"DlOp.Interrupted"); auto hs = Snap(stateH); for (auto* h : hs) h->Invoke(this, nullptr); Drop(hs); return; }
    for (int k = 1; k <= 10; ++k) { got = total * k / 10; auto hs = Snap(bytesH); for (auto* h : hs) h->Invoke(this, nullptr); Drop(hs); }
    state = COREWEBVIEW2_DOWNLOAD_STATE_COMPLETED; Log(L"Download.Completed"); auto hs = Snap(stateH); for (auto* h : hs) h->Invoke(this, nullptr); Drop(hs);
  }
};
struct DlArgs : Com<Stub_ICoreWebView2DownloadStartingEventArgs, ICoreWebView2DownloadStartingEventArgs> {
  DlOp* op = new DlOp(); bool deferred = false;
  ~DlArgs() override { op->Release(); }
  HRESULT STDMETHODCALLTYPE get_DownloadOperation(ICoreWebView2DownloadOperation** o) override { op->AddRef(); *o = op; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Cancel(BOOL b) override { Log(L"Download.Cancel=" + std::to_wstring(b)); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_ResultFilePath(LPWSTR* v) override { *v = Dup(op->path); return S_OK; }
  HRESULT STDMETHODCALLTYPE put_ResultFilePath(LPCWSTR v) override { op->path = v; Log(L"Download.ResultFilePath=" + op->path); return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Handled(BOOL b) override { Log(L"Download.Handled=" + std::to_wstring(b)); return S_OK; }
  HRESULT STDMETHODCALLTYPE GetDeferral(ICoreWebView2Deferral** d) override {
    auto* x = new MockDeferral(); x->tag = L"Download"; DlOp* o = op; o->AddRef();
    x->onComplete = [o] { if (g_holdDownloads) g_heldDownloads.push_back([o] { o->Run(); o->Release(); }); else { o->Run(); o->Release(); } };
    deferred = true; *d = x; return S_OK;
  }
};
struct DialogArgs : Com<Stub_ICoreWebView2ScriptDialogOpeningEventArgs, ICoreWebView2ScriptDialogOpeningEventArgs> {
  COREWEBVIEW2_SCRIPT_DIALOG_KIND kind = COREWEBVIEW2_SCRIPT_DIALOG_KIND_PROMPT; std::wstring msg, def;
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR* v) override { *v = Dup(L"https://a.test/"); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Kind(COREWEBVIEW2_SCRIPT_DIALOG_KIND* v) override { *v = kind; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Message(LPWSTR* v) override { *v = Dup(msg); return S_OK; }
  HRESULT STDMETHODCALLTYPE Accept() override { Log(L"Dialog.Accept"); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_DefaultText(LPWSTR* v) override { *v = Dup(def); return S_OK; }
  HRESULT STDMETHODCALLTYPE put_ResultText(LPCWSTR v) override { Log(L"Dialog.ResultText=" + std::wstring(v)); return S_OK; }
  HRESULT STDMETHODCALLTYPE GetDeferral(ICoreWebView2Deferral** d) override { auto* x = new MockDeferral(); x->tag = L"Dialog"; *d = x; return S_OK; }
};
struct Com2RespArgs : Com<Stub_ICoreWebView2WebResourceResponseReceivedEventArgs, ICoreWebView2WebResourceResponseReceivedEventArgs> {
  MockRequest* req = new MockRequest(); RespView* resp = new RespView();
  ~Com2RespArgs() override { req->Release(); resp->Release(); }
  HRESULT STDMETHODCALLTYPE get_Request(ICoreWebView2WebResourceRequest** r) override { req->AddRef(); *r = req; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Response(ICoreWebView2WebResourceResponseView** r) override { resp->AddRef(); *r = resp; return S_OK; }
};
struct KeyArgs : Com<Stub_ICoreWebView2AcceleratorKeyPressedEventArgs, ICoreWebView2AcceleratorKeyPressedEventArgs> {
  UINT vk = 0; COREWEBVIEW2_KEY_EVENT_KIND kind = COREWEBVIEW2_KEY_EVENT_KIND_KEY_DOWN; BOOL handled = FALSE;
  HRESULT STDMETHODCALLTYPE get_KeyEventKind(COREWEBVIEW2_KEY_EVENT_KIND* k) override { *k = kind; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_VirtualKey(UINT* v) override { *v = vk; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_KeyEventLParam(INT* v) override { *v = 0; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Handled(BOOL* b) override { *b = handled; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Handled(BOOL b) override { handled = b; return S_OK; }
};
struct MenuItem : Com<Stub_ICoreWebView2ContextMenuItem, ICoreWebView2ContextMenuItem> {
  std::wstring name; bool sep = false;
  HRESULT STDMETHODCALLTYPE get_Name(LPWSTR* v) override { *v = Dup(name); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Kind(COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND* k) override { *k = sep ? COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND_SEPARATOR : COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND_COMMAND; return S_OK; }
};
struct MenuItems : Com<Stub_ICoreWebView2ContextMenuItemCollection, ICoreWebView2ContextMenuItemCollection> {
  std::vector<MenuItem*> v;
  ~MenuItems() override { for (auto* x : v) x->Release(); }
  HRESULT STDMETHODCALLTYPE get_Count(UINT32* n) override { *n = (UINT32)v.size(); return S_OK; }
  HRESULT STDMETHODCALLTYPE GetValueAtIndex(UINT32 i, ICoreWebView2ContextMenuItem** o) override { if (i >= v.size()) return E_INVALIDARG; v[i]->AddRef(); *o = v[i]; return S_OK; }
  HRESULT STDMETHODCALLTYPE RemoveValueAtIndex(UINT32 i) override { if (i >= v.size()) { Log(L"Menu.BadRemove"); return E_INVALIDARG; } v[i]->Release(); v.erase(v.begin() + i); return S_OK; }
};
struct MenuArgs : Com<Stub_ICoreWebView2ContextMenuRequestedEventArgs, ICoreWebView2ContextMenuRequestedEventArgs> {
  MenuItems* items = new MenuItems(); BOOL handled = FALSE;
  ~MenuArgs() override { items->Release(); }
  HRESULT STDMETHODCALLTYPE get_MenuItems(ICoreWebView2ContextMenuItemCollection** o) override { items->AddRef(); *o = items; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Handled(BOOL b) override { handled = b; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Handled(BOOL* b) override { *b = handled; return S_OK; }
};
struct AuthResp : Com<Stub_ICoreWebView2BasicAuthenticationResponse, ICoreWebView2BasicAuthenticationResponse> {
  HRESULT STDMETHODCALLTYPE put_UserName(LPCWSTR v) override { Log(L"Auth.UserName=" + std::wstring(v)); return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Password(LPCWSTR v) override { Log(L"Auth.Password=" + std::wstring(v)); return S_OK; }
};
struct AuthArgs : Com<Stub_ICoreWebView2BasicAuthenticationRequestedEventArgs, ICoreWebView2BasicAuthenticationRequestedEventArgs> {
  std::wstring uri; AuthResp* resp = new AuthResp();
  ~AuthArgs() override { resp->Release(); }
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR* v) override { *v = Dup(uri); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Challenge(LPWSTR* v) override { *v = Dup(L"Basic realm=\"mock\""); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Response(ICoreWebView2BasicAuthenticationResponse** r) override { resp->AddRef(); *r = resp; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Cancel(BOOL b) override { Log(L"Auth.Cancel=" + std::to_wstring(b)); return S_OK; }
  HRESULT STDMETHODCALLTYPE GetDeferral(ICoreWebView2Deferral** d) override { auto* x = new MockDeferral(); x->tag = L"Auth"; *d = x; return S_OK; }
};
struct CdpArgs : Com<Stub_ICoreWebView2DevToolsProtocolEventReceivedEventArgs, ICoreWebView2DevToolsProtocolEventReceivedEventArgs> {
  std::wstring json;
  HRESULT STDMETHODCALLTYPE get_ParameterObjectAsJson(LPWSTR* v) override { *v = Dup(json); return S_OK; }
};
struct CdpReceiver : Com<Stub_ICoreWebView2DevToolsProtocolEventReceiver, ICoreWebView2DevToolsProtocolEventReceiver> {
  std::wstring name; std::vector<ICoreWebView2DevToolsProtocolEventReceivedEventHandler*> hs;
  ~CdpReceiver() override { Drop(hs); }
  HRESULT STDMETHODCALLTYPE add_DevToolsProtocolEventReceived(ICoreWebView2DevToolsProtocolEventReceivedEventHandler* h, EventRegistrationToken* t) override { h->AddRef(); hs.push_back(h); if (t) t->value = 7; Log(L"Cdp.Add:" + name); return S_OK; }
  HRESULT STDMETHODCALLTYPE remove_DevToolsProtocolEventReceived(EventRegistrationToken) override { Log(L"Cdp.Remove:" + name); Drop(hs); hs.clear(); return S_OK; }
};
static int g_settingsLevel = 1;  // 模拟设置接口的版本：1 只有 ICoreWebView2Settings（默认，各项新设置都报告不支持），9 实现到 ICoreWebView2Settings9
struct MockSettings : public Stub_ICoreWebView2Settings9 {
  LONG refs_ = 1;
  LiveTag live_{"MockSettings"};
  BOOL nonClient = FALSE;
  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppv) override {
    if (!ppv) return E_POINTER;
    const IID* ok[] = {&wv::wv_iid<::IUnknown>::get(), &wv::wv_iid<ICoreWebView2Settings>::get(), &wv::wv_iid<ICoreWebView2Settings2>::get(),
                       &wv::wv_iid<ICoreWebView2Settings3>::get(), &wv::wv_iid<ICoreWebView2Settings4>::get(), &wv::wv_iid<ICoreWebView2Settings5>::get(),
                       &wv::wv_iid<ICoreWebView2Settings6>::get(), &wv::wv_iid<ICoreWebView2Settings7>::get(), &wv::wv_iid<ICoreWebView2Settings8>::get(),
                       &wv::wv_iid<ICoreWebView2Settings9>::get()};
    for (int k = 0; k < 10; ++k) if (IsEqualIID(riid, *ok[k]) && (k < 2 || k <= g_settingsLevel)) { *ppv = static_cast<ICoreWebView2Settings9*>(this); AddRef(); return S_OK; }
    *ppv = nullptr; return E_NOINTERFACE;
  }
  ULONG STDMETHODCALLTYPE AddRef() override { return InterlockedIncrement(&refs_); }
  ULONG STDMETHODCALLTYPE Release() override { LONG r = InterlockedDecrement(&refs_); if (!r) delete this; return r; }
  virtual ~MockSettings() {}
  HRESULT STDMETHODCALLTYPE put_AreDefaultScriptDialogsEnabled(BOOL b) override { Log(L"Settings.ScriptDialogs=" + std::to_wstring(b)); return S_OK; }
  HRESULT STDMETHODCALLTYPE put_IsWebMessageEnabled(BOOL b) override { Log(L"Settings.WebMessage=" + std::to_wstring(b)); return S_OK; }
  HRESULT STDMETHODCALLTYPE put_AreDefaultContextMenusEnabled(BOOL b) override { Log(L"Settings.ContextMenus=" + std::to_wstring(b)); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_IsWebMessageEnabled(BOOL* b) override { *b = TRUE; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_IsNonClientRegionSupportEnabled(BOOL b) override { nonClient = b; Log(L"Settings.NonClient=" + std::to_wstring(b)); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_IsNonClientRegionSupportEnabled(BOOL* b) override { *b = nonClient; return S_OK; }
};
struct MockWebView;
static MockWebView* g_last;
static bool g_holdScripts = false;                       // Mock_HoldScripts(1) 期间暂扣“脚本登记完成”的回调
static std::vector<std::function<void()>> g_heldScripts;  // 放开时按顺序交出
static int g_domCalls;
static int g_wvLevel = 11;  // 模拟旧版运行时：只承认 ICoreWebView2_N（N 不超过此值）
struct MockWebView : public Stub_ICoreWebView2_11 {  // 实现 ICoreWebView2 到 ICoreWebView2_11，更新的版本一律拒绝
  LONG refs_ = 1;
  LiveTag live_{"MockWebView"};
  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppv) override {
    if (!ppv) return E_POINTER;
    const IID* ok[] = {&wv::wv_iid<::IUnknown>::get(), &wv::wv_iid<ICoreWebView2>::get(), &wv::wv_iid<ICoreWebView2_2>::get(), &wv::wv_iid<ICoreWebView2_3>::get(),
                       &wv::wv_iid<ICoreWebView2_4>::get(), &wv::wv_iid<ICoreWebView2_5>::get(), &wv::wv_iid<ICoreWebView2_6>::get(), &wv::wv_iid<ICoreWebView2_7>::get(),
                       &wv::wv_iid<ICoreWebView2_8>::get(), &wv::wv_iid<ICoreWebView2_9>::get(), &wv::wv_iid<ICoreWebView2_10>::get(), &wv::wv_iid<ICoreWebView2_11>::get()};
    for (int k = 0; k < 12; ++k) if (IsEqualIID(riid, *ok[k]) && (k < 2 || k <= g_wvLevel)) { *ppv = static_cast<ICoreWebView2_11*>(this); AddRef(); return S_OK; }
    *ppv = nullptr; return E_NOINTERFACE;
  }
  ULONG STDMETHODCALLTYPE AddRef() override { return InterlockedIncrement(&refs_); }
  ULONG STDMETHODCALLTYPE Release() override { LONG r = InterlockedDecrement(&refs_); if (!r) delete this; return r; }
  std::wstring source = L"about:blank"; bool closed = false; MockSettings* settings = new MockSettings(); MockCookieManager* cookies = new MockCookieManager();
  std::vector<ICoreWebView2WebResourceResponseReceivedEventHandler*> respH; std::vector<ICoreWebView2DOMContentLoadedEventHandler*> domH;
  std::vector<ICoreWebView2DownloadStartingEventHandler*> dlH; std::vector<ICoreWebView2ScriptDialogOpeningEventHandler*> dialogH; int domCalls = 0;
  std::vector<CdpReceiver*> cdpRecv;
  std::vector<ICoreWebView2ContextMenuRequestedEventHandler*> menuH; std::vector<ICoreWebView2BasicAuthenticationRequestedEventHandler*> authH;
  std::vector<ICoreWebView2NavigationStartingEventHandler*> navStart; std::vector<ICoreWebView2NavigationCompletedEventHandler*> navDone;
  std::vector<ICoreWebView2SourceChangedEventHandler*> srcChanged; std::vector<ICoreWebView2DocumentTitleChangedEventHandler*> titleChanged;
  std::vector<ICoreWebView2WebMessageReceivedEventHandler*> webMsg; std::vector<ICoreWebView2NewWindowRequestedEventHandler*> newWin;
  std::vector<ICoreWebView2PermissionRequestedEventHandler*> perm; std::vector<ICoreWebView2WebResourceRequestedEventHandler*> webRes; std::vector<ICoreWebView2ProcessFailedEventHandler*> procFail;
  std::vector<ICoreWebView2ContainsFullScreenElementChangedEventHandler*> fullH; BOOL full = FALSE; std::vector<IUnknown*> others;
  virtual ~MockWebView() { settings->Release(); cookies->Release(); }
  template <class T> HRESULT Add(std::vector<T*>& v, T* h, EventRegistrationToken* t, const wchar_t* name) { h->AddRef(); v.push_back(h); if (t) t->value = (INT64)v.size(); Log(std::wstring(L"add_") + name); return S_OK; }
  HRESULT Keep(IUnknown* h, EventRegistrationToken* t) { h->AddRef(); others.push_back(h); if (t) t->value = 1000 + (INT64)others.size(); return S_OK; }
  void Shutdown() { closed = true; Drop(navStart); Drop(navDone); Drop(srcChanged); Drop(titleChanged); Drop(webMsg); Drop(newWin); Drop(perm); Drop(webRes); Drop(others); webRes.clear(); Drop(procFail); procFail.clear(); Drop(fullH); fullH.clear(); Drop(respH); respH.clear(); Drop(domH); domH.clear(); Drop(dlH); dlH.clear(); Drop(dialogH); dialogH.clear(); Drop(menuH); menuH.clear(); Drop(authH); authH.clear(); Drop(cdpRecv); cdpRecv.clear();
    navStart.clear(); navDone.clear(); srcChanged.clear(); titleChanged.clear(); webMsg.clear(); newWin.clear(); perm.clear(); others.clear(); }
  void Later(std::function<void()> f) { AddRef(); Defer([this, f] { if (!closed) f(); Release(); }); }
  static std::wstring Eval(const std::wstring& js) {
    if (js == L"1+2") return L"3";
    if (js == L"6*7") return L"42";
    if (js == L"document.title") return L"\"Mock\"";
    if (js.compare(0, 22, L"(function(sel,val,act)") == 0 && js.find(L"\"#never\"") != std::wstring::npos) return L"false";  // 永远不出现的元素
    if (js.compare(0, 22, L"(function(sel,val,act)") == 0 && js.find(L"\"#refuse\"") != std::wstring::npos) return L"false";  // 元素在，但动作没能完成
    if (js.compare(0, 22, L"(function(sel,val,act)") == 0 && js.find(L"\"#invalid\"") != std::wstring::npos) return L"\"invalid\"";  // 表单校验没通过
    if (js.compare(0, 22, L"(function(sel,val,act)") == 0 && js.find(L"\"#disabledbtn\"") != std::wstring::npos) return L"\"disabled\"";  // 禁用的按钮
    if (js.compare(0, 22, L"(function(sel,val,act)") == 0 && js.find(L"\"#zero\"") != std::wstring::npos) return L"\"{\\\"x\\\":0,\\\"y\\\":0,\\\"w\\\":0,\\\"h\\\":0}\"";  // 隐藏的元素
    if (js.compare(0, 22, L"(function(sel,val,act)") == 0 && js.find(L"\"#box10\"") != std::wstring::npos) return L"\"{\\\"x\\\":50,\\\"y\\\":60,\\\"w\\\":10,\\\"h\\\":10}\"";
    if (js.compare(0, 22, L"(function(sel,val,act)") == 0) return ++g_domCalls >= 3 ? L"true" : L"false";  // 等待元素：第 3 次才出现
    return L"null";
  }
  void DoNav(const std::wstring& uri) {
    Log(L"Raise:NavStarting:" + uri);
    auto* a = new NavStartArgs(); a->uri = uri;
    auto hs = Snap(navStart); for (auto* h : hs) h->Invoke(this, a); Drop(hs);
    Log(L"Raised:NavStarting:" + uri);
    BOOL c = a->cancel; a->Release();
    if (c) { Log(L"Cancelled:" + uri); return; }
    source = uri; Log(L"Committed:" + uri);
    auto* s = new SrcArgs(); auto h2 = Snap(srcChanged); for (auto* h : h2) h->Invoke(this, s); Drop(h2); s->Release();
    auto h3 = Snap(titleChanged); for (auto* h : h3) h->Invoke(this, nullptr); Drop(h3);
    if (!domH.empty()) { auto* dm = new DomArgs(); auto h5 = Snap(domH); for (auto* h : h5) h->Invoke(this, dm); Drop(h5); dm->Release(); Log(L"Raised:DOMContentLoaded"); }
    auto* d = new NavDoneArgs(); auto h4 = Snap(navDone); for (auto* h : h4) h->Invoke(this, d); Drop(h4); d->Release();
    Log(L"Raised:NavCompleted:" + uri);
  }
  void RaiseMsg(const std::wstring& json) { RaiseMsgF(json, {}, false); }
  // 1.8.2：带附带文件（haveColl 为真时内核支持 args2）
  void RaiseMsgF(const std::wstring& json, const std::vector<std::wstring>& files, bool haveColl) {
    Log(L"Raise:WebMessage"); auto* a = new MsgArgs(); a->json = json; a->files = files; a->haveColl = haveColl;
    auto hs = Snap(webMsg); for (auto* h : hs) h->Invoke(this, a); Drop(hs); a->Release(); Log(L"Raised:WebMessage");
  }
  void RaiseNewWin(const std::wstring& uri) {
    Log(L"Raise:NewWindow"); auto* a = new NewWinArgs(); a->uri = uri;
    auto hs = Snap(newWin); for (auto* h : hs) h->Invoke(this, a); Drop(hs); a->Release(); Log(L"Raised:NewWindow");
  }
  void RaisePerm(const std::wstring& uri) {
    Log(L"Raise:Permission"); auto* a = new PermArgs(); a->uri = uri;
    auto hs = Snap(perm); for (auto* h : hs) h->Invoke(this, a); Drop(hs); a->Release(); Log(L"Raised:Permission");
  }
  HRESULT STDMETHODCALLTYPE get_Settings(ICoreWebView2Settings** s) override { settings->AddRef(); *s = settings; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Source(LPWSTR* u) override { *u = Dup(source); return S_OK; }
  HRESULT STDMETHODCALLTYPE Navigate(LPCWSTR uri) override { if (closed) return E_FAIL; std::wstring u = uri; Log(L"Navigate:" + u); Later([this, u] { DoNav(u); }); return S_OK; }
  HRESULT STDMETHODCALLTYPE NavigateToString(LPCWSTR) override { if (closed) return E_FAIL; Log(L"NavigateToString"); Later([this] { DoNav(L"about:blank#html"); }); return S_OK; }
  HRESULT STDMETHODCALLTYPE ExecuteScript(LPCWSTR js, ICoreWebView2ExecuteScriptCompletedHandler* h) override {
    if (!h) Log(L"NullHandler:ExecuteScript");  // 文档没说明可以传空回调：DLL 应当总是给出回调
    std::wstring s = js ? js : L""; Log(L"ExecuteScript:" + s.substr(0, 30)); if (closed) return E_FAIL;
    if (s == L"hang()") { if (h) h->AddRef(); return S_OK; }  // 永不完成：检验超时
    if (h) h->AddRef(); Later([s, h] { if (h) { h->Invoke(S_OK, Eval(s).c_str()); h->Release(); } }); return S_OK;
  }
  // ---- DevTools 协议的 Runtime 部分按真实 Chromium 的行为模拟（在 Chromium 141 中实测过）：
  // REPL 模式不等待表达式得到的 Promise（按值取回时得到 {}），只有 REPL 模式支持顶层 await，
  // 按对象取回时给出远程对象，由 Runtime.awaitPromise / callFunctionOn 取值，对象随对象组释放
  struct RObj { std::wstring group, kind, value; };  // kind：promise（value 为结果，reject: 开头为拒绝）、object（value 为 JSON）
  std::map<std::wstring, RObj> robjs; int robjSeq = 0;
  static std::wstring StrParam(const std::wstring& p, const wchar_t* key) {
    std::wstring k = std::wstring(L"\"") + key + L"\":\"", v; size_t i = p.find(k);
    if (i == std::wstring::npos) return v;
    for (i += k.size(); i < p.size() && p[i] != L'"'; ++i) { if (p[i] == L'\\' && i + 1 < p.size()) ++i; v += p[i]; }
    return v;
  }
  static bool BoolParam(const std::wstring& p, const wchar_t* key) { return p.find(std::wstring(L"\"") + key + L"\":true") != std::wstring::npos; }
  // 表达式的种类：new Promise(...r(数字)...) 是 Promise，Promise.reject(...) 是被拒绝的 Promise，[...] 是数组，throw 抛异常
  static void Classify(const std::wstring& js, std::wstring& kind, std::wstring& value) {
    if (js.compare(0, 11, L"new Promise") == 0) { size_t a = js.rfind(L"r("), b = js.find(L')', a); kind = L"promise"; value = js.substr(a + 2, b - a - 2); return; }
    if (js.compare(0, 14, L"Promise.reject") == 0) { kind = L"promise"; value = L"reject:Error: boom"; return; }
    if (!js.empty() && js[0] == L'[') { kind = L"object"; value = js; return; }
    if (js.compare(0, 6, L"throw ") == 0) { kind = L"throw"; value = L"Error: sync"; return; }
    kind = L"primitive"; value = Eval(js);
  }
  static std::wstring Prim(const std::wstring& v) {
    std::wstring type = v[0] == L'"' ? L"string" : (v == L"null" ? L"object" : (v == L"undefined" ? L"undefined" : L"number"));
    return type == L"undefined" ? L"{\"type\":\"undefined\"}" : L"{\"type\":\"" + type + L"\",\"value\":" + v + L"}";
  }
  static std::wstring Exc(const std::wstring& d) { return L"{\"result\":{\"type\":\"object\",\"subtype\":\"error\"},\"exceptionDetails\":{\"text\":\"Uncaught\",\"exception\":{\"type\":\"object\",\"subtype\":\"error\",\"description\":\"" + d + L"\"}}}"; }
  std::wstring RuntimeCall(const std::wstring& m, const std::wstring& p, HRESULT& hr) {
    hr = S_OK;
    if (m == L"Runtime.releaseObjectGroup") {
      std::wstring g = StrParam(p, L"objectGroup");
      for (auto it = robjs.begin(); it != robjs.end();) it = it->second.group == g ? robjs.erase(it) : std::next(it);
      Log(L"CDP.Release:" + g); return L"{}";
    }
    if (m == L"Runtime.awaitPromise" || m == L"Runtime.callFunctionOn") {
      auto it = robjs.find(StrParam(p, m == L"Runtime.awaitPromise" ? L"promiseObjectId" : L"objectId"));
      if (it == robjs.end()) { hr = E_FAIL; return L"{\"code\":-32000,\"message\":\"Could not find object with given id\"}"; }
      const RObj o = it->second;
      if (o.value.compare(0, 7, L"reject:") == 0) return Exc(o.value.substr(7));
      return L"{\"result\":" + (o.kind == L"object" ? L"{\"type\":\"object\",\"value\":" + o.value + L"}" : Prim(o.value)) + L"}";
    }
    // Runtime.evaluate
    std::wstring js = StrParam(p, L"expression"); const bool repl = BoolParam(p, L"replMode"), byValue = BoolParam(p, L"returnByValue");
    if (js.compare(0, 6, L"await ") == 0) {  // 顶层 await：只有 REPL 模式支持
      if (!repl) return Exc(L"SyntaxError: await is only valid in async functions and the top level bodies of modules");
      js = js.substr(6);
      std::wstring k, v; Classify(js, k, v);
      if (k == L"promise") return v.compare(0, 7, L"reject:") == 0 ? Exc(v.substr(7)) : L"{\"result\":" + Prim(v) + L"}";
    }
    std::wstring kind, value; Classify(js, kind, value);
    if (kind == L"throw") return Exc(value);
    if (kind == L"primitive") return L"{\"result\":" + Prim(value) + L"}";
    if (kind == L"promise" && !repl) return value.compare(0, 7, L"reject:") == 0 ? Exc(value.substr(7)) : L"{\"result\":" + Prim(value) + L"}";  // 普通模式：awaitPromise 生效
    if (byValue) return kind == L"promise" ? L"{\"result\":{\"type\":\"object\",\"value\":{}}}" : L"{\"result\":{\"type\":\"object\",\"value\":" + value + L"}}";  // REPL 模式按值取回：Promise 没被等待
    std::wstring id = L"obj-" + std::to_wstring(++robjSeq); robjs[id] = RObj{StrParam(p, L"objectGroup"), kind, value};
    return kind == L"promise" ? L"{\"result\":{\"type\":\"object\",\"subtype\":\"promise\",\"className\":\"Promise\",\"description\":\"Promise\",\"objectId\":\"" + id + L"\"}}"
                              : L"{\"result\":{\"type\":\"object\",\"subtype\":\"array\",\"className\":\"Array\",\"description\":\"Array\",\"objectId\":\"" + id + L"\"}}";
  }
  HRESULT STDMETHODCALLTYPE CallDevToolsProtocolMethod(LPCWSTR method, LPCWSTR params, ICoreWebView2CallDevToolsProtocolMethodCompletedHandler* h) override {
    std::wstring m = method, p = params ? params : L""; Log(L"CDP:" + m + L" " + p.substr(0, 160)); if (closed) return E_FAIL;
    if (!h) Log(L"NullHandler:CDP:" + m);
    HRESULT res = S_OK; std::wstring r = L"{}";
    if (m.compare(0, 8, L"Runtime.") == 0) r = RuntimeCall(m, p, res);
    else if (m == L"Page.getLayoutMetrics") r = L"{\"cssContentSize\":{\"x\":0,\"y\":0,\"width\":800,\"height\":3000},\"contentSize\":{\"x\":0,\"y\":0,\"width\":800,\"height\":3000}}";
    else if (m == L"Page.captureScreenshot") r = L"{\"data\":\"iVBORw0KGgo=\"}";
    if (h) h->AddRef(); Later([r, h, res] { if (h) { h->Invoke(res, r.c_str()); h->Release(); } }); return S_OK;
  }
  HRESULT STDMETHODCALLTYPE AddScriptToExecuteOnDocumentCreated(LPCWSTR js, ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler* h) override {
    static LONG seq = 0;  // 真实运行时每次登记都给新的编号
    std::wstring sid = L"script-" + std::to_wstring(InterlockedIncrement(&seq));
    Log(L"AddScript"); Log(L"InitJs:" + std::wstring(js ? js : L"").substr(0, 60) + L"=" + sid);
    if (h) h->AddRef();
    auto done = [h, sid] { if (h) { h->Invoke(S_OK, sid.c_str()); h->Release(); } };
    if (g_holdScripts) { AddRef(); g_heldScripts.push_back([this, done] { Later(done); Release(); }); }
    else Later(done);
    return S_OK;
  }
  HRESULT STDMETHODCALLTYPE RemoveScriptToExecuteOnDocumentCreated(LPCWSTR id) override { Log(L"RemoveScript:" + std::wstring(id ? id : L"")); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_CookieManager(ICoreWebView2CookieManager** c) override { cookies->AddRef(); *c = cookies; return S_OK; }
  HRESULT STDMETHODCALLTYPE add_WebResourceResponseReceived(ICoreWebView2WebResourceResponseReceivedEventHandler* h, EventRegistrationToken* t) override { return Add(respH, h, t, L"WebResourceResponseReceived"); }
  HRESULT STDMETHODCALLTYPE add_DOMContentLoaded(ICoreWebView2DOMContentLoadedEventHandler* h, EventRegistrationToken* t) override { return Add(domH, h, t, L"DOMContentLoaded"); }
  HRESULT STDMETHODCALLTYPE add_DownloadStarting(ICoreWebView2DownloadStartingEventHandler* h, EventRegistrationToken* t) override { return Add(dlH, h, t, L"DownloadStarting"); }
  HRESULT STDMETHODCALLTYPE SetVirtualHostNameToFolderMapping(LPCWSTR host, LPCWSTR folder, COREWEBVIEW2_HOST_RESOURCE_ACCESS_KIND k) override {
    Log(L"MapFolder:" + std::wstring(host) + L"=" + folder + L":" + std::to_wstring((int)k)); return S_OK;
  }
  HRESULT STDMETHODCALLTYPE add_ContextMenuRequested(ICoreWebView2ContextMenuRequestedEventHandler* h, EventRegistrationToken* t) override { return Add(menuH, h, t, L"ContextMenuRequested"); }
  HRESULT STDMETHODCALLTYPE add_BasicAuthenticationRequested(ICoreWebView2BasicAuthenticationRequestedEventHandler* h, EventRegistrationToken* t) override { return Add(authH, h, t, L"BasicAuthenticationRequested"); }
  HRESULT STDMETHODCALLTYPE GetDevToolsProtocolEventReceiver(LPCWSTR name, ICoreWebView2DevToolsProtocolEventReceiver** r) override {
    for (auto* x : cdpRecv) if (x->name == name) { x->AddRef(); *r = x; return S_OK; }
    auto* x = new CdpReceiver(); x->name = name; cdpRecv.push_back(x); x->AddRef(); *r = x; return S_OK;
  }
  void RaiseCdp(const std::wstring& name, const std::wstring& json) {
    for (auto* x : cdpRecv) if (x->name == name) { auto* a = new CdpArgs(); a->json = json; auto hs = Snap(x->hs); for (auto* h : hs) h->Invoke(this, a); Drop(hs); a->Release(); }
    Log(L"Raised:Cdp:" + name);
  }
  HRESULT STDMETHODCALLTYPE NavigateWithWebResourceRequest(ICoreWebView2WebResourceRequest* r) override {
    LPWSTR u = nullptr; r->get_Uri(&u); std::wstring uri = u ? u : L""; CoTaskMemFree(u); Log(L"NavigateWithRequest:" + uri); Later([this, uri] { DoNav(uri); }); return S_OK;
  }
  HRESULT STDMETHODCALLTYPE PrintToPdf(LPCWSTR path, ICoreWebView2PrintSettings* ps, ICoreWebView2PrintToPdfCompletedHandler* h) override {
    Log(L"PrintToPdf:" + std::wstring(path) + L" settings=" + (ps ? L"set" : L"default")); h->AddRef(); Later([h] { h->Invoke(S_OK, TRUE); h->Release(); }); return S_OK;
  }
  HRESULT STDMETHODCALLTYPE OpenTaskManagerWindow() override { Log(L"WebView.TaskManager"); return S_OK; }
  void RaiseMenu(int variant) {
    static const wchar_t* menus[] = {L"back,forward,reload,|,saveAs,print,|,copy,paste,selectAll,|,inspectElement", L"back,|,print,|", L"cut,copy,|,|,paste,|", L"|,undo,redo,|,|"};
    auto* a = new MenuArgs(); std::wstring spec = menus[variant], part;
    for (size_t i = 0; i <= spec.size(); ++i) { if (i == spec.size() || spec[i] == L',') { auto* it = new MenuItem(); it->sep = part == L"|"; it->name = it->sep ? L"" : part; a->items->v.push_back(it); part.clear(); } else part += spec[i]; }
    auto hs = Snap(menuH); for (auto* h : hs) h->Invoke(this, a); Drop(hs);
    std::wstring r; for (auto* it : a->items->v) { if (!r.empty()) r += L","; r += it->sep ? L"|" : it->name; }
    Log(L"Menu" + std::to_wstring(variant) + L":" + r + L" Handled=" + std::to_wstring(a->handled)); a->Release();
  }
  void RaiseAuth(const std::wstring& uri) { Log(L"Raise:Auth"); auto* a = new AuthArgs(); a->uri = uri; auto hs = Snap(authH); for (auto* h : hs) h->Invoke(this, a); Drop(hs); a->Release(); Log(L"Raised:Auth"); }
  HRESULT STDMETHODCALLTYPE GoBack() override { Log(L"WebView.GoBack"); return S_OK; }
  HRESULT STDMETHODCALLTYPE GoForward() override { Log(L"WebView.GoForward"); return S_OK; }
  HRESULT STDMETHODCALLTYPE Reload() override { Log(L"WebView.Reload"); return S_OK; }
  HRESULT STDMETHODCALLTYPE Stop() override { Log(L"WebView.Stop"); return S_OK; }
  HRESULT STDMETHODCALLTYPE OpenDevToolsWindow() override { Log(L"WebView.DevTools"); return S_OK; }
  HRESULT STDMETHODCALLTYPE TrySuspend(ICoreWebView2TrySuspendCompletedHandler* h) override { Log(L"WebView.TrySuspend"); if (h) h->AddRef(); Later([h] { if (h) { h->Invoke(S_OK, TRUE); h->Release(); } }); return S_OK; }
  HRESULT STDMETHODCALLTYPE Resume() override { Log(L"WebView.Resume"); return S_OK; }
  HRESULT STDMETHODCALLTYPE ClearVirtualHostNameToFolderMapping(LPCWSTR host) override { Log(L"MapFolder.Clear:" + std::wstring(host)); return S_OK; }
  HRESULT STDMETHODCALLTYPE CapturePreview(COREWEBVIEW2_CAPTURE_PREVIEW_IMAGE_FORMAT, IStream* st, ICoreWebView2CapturePreviewCompletedHandler* h) override {
    Log(L"CapturePreview"); ULONG w = 0; st->Write("\x89PNG\r\n\x1a\nMOCK", 12, &w); st->AddRef(); h->AddRef();
    Later([st, h] { h->Invoke(S_OK); h->Release(); st->Release(); }); return S_OK;
  }
  void RaiseResp(const std::wstring& uri, int status, const std::string& body) {
    Log(L"Raise:Response:" + uri); auto* a = new Com2RespArgs(); a->req->uri = uri; a->resp->status = status; a->resp->body = body;
    auto hs = Snap(respH); for (auto* h : hs) h->Invoke(this, a); Drop(hs); a->Release(); Log(L"Raised:Response:" + uri);
  }
  void RaiseDownload(const std::wstring& uri, INT64 total) {
    Log(L"Raise:Download"); auto* a = new DlArgs(); a->op->uri = uri; a->op->total = total; a->op->path = L"C:\\Users\\mock\\Downloads\\report.pdf";
    auto hs = Snap(dlH); for (auto* h : hs) h->Invoke(this, a); Drop(hs); Log(L"Raised:Download");
    if (!a->deferred) { DlOp* o = a->op; o->AddRef(); Defer([o] { if (g_holdDownloads) g_heldDownloads.push_back([o] { o->Run(); o->Release(); }); else { o->Run(); o->Release(); } }); }
    a->Release();
  }
  void RaiseDialog(int kind, const std::wstring& msg, const std::wstring& def) {
    Log(L"Raise:Dialog"); auto* a = new DialogArgs(); a->kind = (COREWEBVIEW2_SCRIPT_DIALOG_KIND)kind; a->msg = msg; a->def = def;
    auto hs = Snap(dialogH); for (auto* h : hs) h->Invoke(this, a); Drop(hs); a->Release(); Log(L"Raised:Dialog");
  }
  HRESULT STDMETHODCALLTYPE PostWebMessageAsJson(LPCWSTR j) override { Log(L"PostJson:" + std::wstring(j)); return S_OK; }
  HRESULT STDMETHODCALLTYPE PostWebMessageAsString(LPCWSTR j) override { Log(L"PostString:" + std::wstring(j)); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_DocumentTitle(LPWSTR* t) override { *t = Dup(L"Mock"); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_CanGoBack(BOOL* b) override { *b = FALSE; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_CanGoForward(BOOL* b) override { *b = FALSE; return S_OK; }
  HRESULT STDMETHODCALLTYPE add_NavigationStarting(ICoreWebView2NavigationStartingEventHandler* h, EventRegistrationToken* t) override { return Add(navStart, h, t, L"NavigationStarting"); }
  HRESULT STDMETHODCALLTYPE add_NavigationCompleted(ICoreWebView2NavigationCompletedEventHandler* h, EventRegistrationToken* t) override { return Add(navDone, h, t, L"NavigationCompleted"); }
  HRESULT STDMETHODCALLTYPE add_SourceChanged(ICoreWebView2SourceChangedEventHandler* h, EventRegistrationToken* t) override { return Add(srcChanged, h, t, L"SourceChanged"); }
  HRESULT STDMETHODCALLTYPE add_DocumentTitleChanged(ICoreWebView2DocumentTitleChangedEventHandler* h, EventRegistrationToken* t) override { return Add(titleChanged, h, t, L"DocumentTitleChanged"); }
  HRESULT STDMETHODCALLTYPE add_WebMessageReceived(ICoreWebView2WebMessageReceivedEventHandler* h, EventRegistrationToken* t) override { return Add(webMsg, h, t, L"WebMessageReceived"); }
  HRESULT STDMETHODCALLTYPE add_NewWindowRequested(ICoreWebView2NewWindowRequestedEventHandler* h, EventRegistrationToken* t) override { return Add(newWin, h, t, L"NewWindowRequested"); }
  HRESULT STDMETHODCALLTYPE add_PermissionRequested(ICoreWebView2PermissionRequestedEventHandler* h, EventRegistrationToken* t) override { return Add(perm, h, t, L"PermissionRequested"); }
  HRESULT STDMETHODCALLTYPE add_HistoryChanged(ICoreWebView2HistoryChangedEventHandler* h, EventRegistrationToken* t) override { return Keep(h, t); }
  HRESULT STDMETHODCALLTYPE add_ProcessFailed(ICoreWebView2ProcessFailedEventHandler* h, EventRegistrationToken* t) override { return Add(procFail, h, t, L"ProcessFailed"); }
  HRESULT STDMETHODCALLTYPE add_ContainsFullScreenElementChanged(ICoreWebView2ContainsFullScreenElementChangedEventHandler* h, EventRegistrationToken* t) override { return Add(fullH, h, t, L"Fullscreen"); }
  HRESULT STDMETHODCALLTYPE get_ContainsFullScreenElement(BOOL* b) override { *b = full; return S_OK; }
  void RaiseFail(int kind) { Log(L"Raise:ProcessFailed"); auto* a = new FailArgs(); a->kind = (COREWEBVIEW2_PROCESS_FAILED_KIND)kind; auto hs = Snap(procFail); for (auto* h : hs) h->Invoke(this, a); Drop(hs); a->Release(); Log(L"Raised:ProcessFailed"); }
  void RaiseFull(BOOL on) { full = on; auto hs = Snap(fullH); for (auto* h : hs) h->Invoke(this, nullptr); Drop(hs); Log(L"Raised:Fullscreen:" + std::to_wstring(on)); }
  HRESULT STDMETHODCALLTYPE add_WindowCloseRequested(ICoreWebView2WindowCloseRequestedEventHandler* h, EventRegistrationToken* t) override { return Keep(h, t); }
  HRESULT STDMETHODCALLTYPE add_ScriptDialogOpening(ICoreWebView2ScriptDialogOpeningEventHandler* h, EventRegistrationToken* t) override { return Add(dialogH, h, t, L"ScriptDialogOpening"); }
  HRESULT STDMETHODCALLTYPE add_WebResourceRequested(ICoreWebView2WebResourceRequestedEventHandler* h, EventRegistrationToken* t) override { return Add(webRes, h, t, L"WebResourceRequested"); }
  void RaiseReq(const std::wstring& uri, int ctx) {
    Log(L"Raise:Request:" + uri); auto* a = new ReqArgs(); a->req->uri = uri; a->ctx = (COREWEBVIEW2_WEB_RESOURCE_CONTEXT)ctx;
    auto hs = Snap(webRes); for (auto* h : hs) h->Invoke(this, a); Drop(hs); a->Release(); Log(L"Raised:Request:" + uri);
  }
  HRESULT STDMETHODCALLTYPE AddWebResourceRequestedFilter(LPCWSTR uri, COREWEBVIEW2_WEB_RESOURCE_CONTEXT) override { Log(L"AddFilter:" + std::wstring(uri)); return S_OK; }
};
struct FocusArgs : Com<ICoreWebView2MoveFocusRequestedEventArgs, ICoreWebView2MoveFocusRequestedEventArgs> {
  COREWEBVIEW2_MOVE_FOCUS_REASON reason = COREWEBVIEW2_MOVE_FOCUS_REASON_NEXT;
  BOOL handled = FALSE;
  HRESULT STDMETHODCALLTYPE get_Reason(COREWEBVIEW2_MOVE_FOCUS_REASON* r) override { *r = reason; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Handled(BOOL* h) override { *h = handled; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Handled(BOOL h) override { handled = h; return S_OK; }
};
struct MockController : Com<Stub_ICoreWebView2Controller, ICoreWebView2Controller> {
  MockWebView* wv = new MockWebView(); RECT bounds{}; BOOL visible = TRUE; HWND parent = nullptr; std::vector<IUnknown*> keep; std::vector<ICoreWebView2AcceleratorKeyPressedEventHandler*> accel;
  ~MockController() override { for (auto* k : keep) k->Release(); Drop(accel); Drop(focusH); wv->Release(); }
  HRESULT STDMETHODCALLTYPE get_IsVisible(BOOL* b) override { *b = visible; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_IsVisible(BOOL b) override { visible = b; Log(L"Controller.Visible=" + std::to_wstring(b)); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Bounds(RECT* r) override { *r = bounds; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_Bounds(RECT r) override { bounds = r; Log(L"Controller.Bounds=" + std::to_wstring(r.right - r.left) + L"x" + std::to_wstring(r.bottom - r.top)); return S_OK; }
  double zoom = 1.0;
  HRESULT STDMETHODCALLTYPE get_ZoomFactor(double* z) override { *z = zoom; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_ZoomFactor(double z) override { zoom = z; Log(L"Controller.Zoom=" + std::to_wstring((int)(z * 100 + 0.5))); return S_OK; }
  HRESULT STDMETHODCALLTYPE add_ZoomFactorChanged(ICoreWebView2ZoomFactorChangedEventHandler* h, EventRegistrationToken* t) override { h->AddRef(); keep.push_back(h); if (t) t->value = 1; return S_OK; }
  HRESULT STDMETHODCALLTYPE add_AcceleratorKeyPressed(ICoreWebView2AcceleratorKeyPressedEventHandler* h, EventRegistrationToken* t) override { h->AddRef(); accel.push_back(h); if (t) t->value = 2; return S_OK; }
  void RaiseKey(UINT vk, int kind) {
    auto* a = new KeyArgs(); a->vk = vk; a->kind = (COREWEBVIEW2_KEY_EVENT_KIND)kind; auto hs = Snap(accel); for (auto* h : hs) h->Invoke(this, a); Drop(hs);
    Log(L"Key" + std::to_wstring(vk) + L":Handled=" + std::to_wstring(a->handled)); a->Release();
  }
  HRESULT STDMETHODCALLTYPE MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON r) override { Log(L"Controller.MoveFocus:" + std::to_wstring((int)r)); return S_OK; }
  std::vector<ICoreWebView2MoveFocusRequestedEventHandler*> focusH;
  HRESULT STDMETHODCALLTYPE add_MoveFocusRequested(ICoreWebView2MoveFocusRequestedEventHandler* h, EventRegistrationToken* t) override { h->AddRef(); focusH.push_back(h); if (t) t->value = 3; return S_OK; }
  void RaiseMoveFocus(int reason) {
    auto* a = new FocusArgs(); a->reason = (COREWEBVIEW2_MOVE_FOCUS_REASON)reason; auto hs = Snap(focusH); for (auto* h : hs) h->Invoke(this, a); Drop(hs);
    Log(L"MoveFocusRequested:" + std::to_wstring(reason) + L":Handled=" + std::to_wstring(a->handled)); a->Release();
  }
  HRESULT STDMETHODCALLTYPE get_ParentWindow(HWND* p) override { *p = parent; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_ParentWindow(HWND p) override { parent = p; Log(L"Controller.ParentWindow"); return S_OK; }
  HRESULT STDMETHODCALLTYPE NotifyParentWindowPositionChanged() override { Log(L"Controller.NotifyParentWindowPositionChanged"); return S_OK; }
  HRESULT STDMETHODCALLTYPE Close() override { Log(L"Controller.Close"); wv->Shutdown(); for (auto* k : keep) k->Release(); keep.clear(); Drop(accel); accel.clear(); return S_OK; }
  HRESULT STDMETHODCALLTYPE get_CoreWebView2(ICoreWebView2** w) override { wv->AddRef(); *w = wv; return S_OK; }
};
static struct MockController* g_lastCtl;
struct MockPrintSettings : Com<Stub_ICoreWebView2PrintSettings, ICoreWebView2PrintSettings> {
  HRESULT STDMETHODCALLTYPE put_Orientation(COREWEBVIEW2_PRINT_ORIENTATION o) override { Log(L"Print.Orientation=" + std::to_wstring((int)o)); return S_OK; }
  HRESULT STDMETHODCALLTYPE put_ShouldPrintBackgrounds(BOOL b) override { Log(L"Print.Backgrounds=" + std::to_wstring(b)); return S_OK; }
};
struct MockCtlOptions : Com<Stub_ICoreWebView2ControllerOptions, ICoreWebView2ControllerOptions> {
  std::wstring profile; BOOL inprivate = FALSE;
  HRESULT STDMETHODCALLTYPE get_ProfileName(LPWSTR* v) override { *v = Dup(profile); return S_OK; }
  HRESULT STDMETHODCALLTYPE put_ProfileName(LPCWSTR v) override { profile = v; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_IsInPrivateModeEnabled(BOOL* v) override { *v = inprivate; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_IsInPrivateModeEnabled(BOOL v) override { inprivate = v; return S_OK; }
};
static int g_envLevel = 10;
static HRESULT g_failCtlHr = 0;  // 非 0 时下一次创建控件以此结果失败（1.8.0：验证失败后重试从新建环境开始）
static HRESULT g_failEnvHr = 0;  // 非 0 时下一次环境创建以此结果失败  // 模拟不同版本的运行时：只承认这一版本及以下的环境接口
struct MockEnv : public Stub_ICoreWebView2Environment10 {  // 实现到 ICoreWebView2Environment10（请求对象、打印设置、控件选项）
  LONG refs_ = 1;
  LiveTag live_{"MockEnv"};
  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppv) override {
    if (!ppv) return E_POINTER;
    const IID* ok[] = {&wv::wv_iid<::IUnknown>::get(), &wv::wv_iid<ICoreWebView2Environment>::get(), &wv::wv_iid<ICoreWebView2Environment2>::get(), &wv::wv_iid<ICoreWebView2Environment3>::get(),
                       &wv::wv_iid<ICoreWebView2Environment4>::get(), &wv::wv_iid<ICoreWebView2Environment5>::get(), &wv::wv_iid<ICoreWebView2Environment6>::get(),
                       &wv::wv_iid<ICoreWebView2Environment7>::get(), &wv::wv_iid<ICoreWebView2Environment8>::get(), &wv::wv_iid<ICoreWebView2Environment9>::get(),
                       &wv::wv_iid<ICoreWebView2Environment10>::get()};
    for (int k = 0; k < 11; ++k) if (IsEqualIID(riid, *ok[k]) && (k < 2 || k <= g_envLevel)) { *ppv = static_cast<ICoreWebView2Environment10*>(this); AddRef(); return S_OK; }
    *ppv = nullptr; return E_NOINTERFACE;
  }
  ULONG STDMETHODCALLTYPE AddRef() override { return InterlockedIncrement(&refs_); }
  ULONG STDMETHODCALLTYPE Release() override { LONG r = InterlockedDecrement(&refs_); if (!r) delete this; return r; }
  virtual ~MockEnv() {}
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2ControllerOptions(ICoreWebView2ControllerOptions** o) override { *o = new MockCtlOptions(); return S_OK; }
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2ControllerWithOptions(HWND parent, ICoreWebView2ControllerOptions* o, ICoreWebView2CreateCoreWebView2ControllerCompletedHandler* h) override {
    LPWSTR p = nullptr; BOOL ip = FALSE; o->get_ProfileName(&p); o->get_IsInPrivateModeEnabled(&ip);
    Log(L"CreateControllerWithOptions:profile=" + std::wstring(p ? p : L"") + L" inprivate=" + std::to_wstring(ip)); CoTaskMemFree(p);
    return CreateCoreWebView2Controller(parent, h);
  }
  HRESULT STDMETHODCALLTYPE CreatePrintSettings(ICoreWebView2PrintSettings** out) override { *out = new MockPrintSettings(); return S_OK; }
  HRESULT STDMETHODCALLTYPE CreateWebResourceRequest(LPCWSTR uri, LPCWSTR method, IStream* body, LPCWSTR headers, ICoreWebView2WebResourceRequest** out) override {
    ULONGLONG size = 0; STATSTG st{}; if (body && SUCCEEDED(body->Stat(&st, STATFLAG_NONAME))) size = st.cbSize.QuadPart;
    std::string data; if (body && size) { LARGE_INTEGER z{}; body->Seek(z, STREAM_SEEK_SET, nullptr); data.resize((size_t)size); ULONG rd = 0; body->Read(&data[0], (ULONG)size, &rd); }
    std::wstring h = headers ? headers : L""; for (auto& c : h) if (c == L'\r' || c == L'\n') c = L'|';
    Log(L"CreateRequest:" + std::wstring(method) + L" " + uri + L" body=" + std::to_wstring(size) + L" data=" + std::wstring(data.begin(), data.end()) + L" headers=" + h);
    auto* r = new MockRequest(); r->uri = uri; *out = r; return S_OK;
  }
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2Controller(HWND parent, ICoreWebView2CreateCoreWebView2ControllerCompletedHandler* h) override {
    Log(L"CreateController"); h->AddRef(); AddRef();
    HRESULT fail = g_failCtlHr; g_failCtlHr = 0;  // Mock_FailNextController：这一次以给定结果失败（像真实运行时一样经完成回调报告）
    if (fail) { Log(L"CreateController.Fail"); Defer([this, h, fail] { h->Invoke(fail, nullptr); h->Release(); Release(); }); return S_OK; }
    Defer([this, parent, h] { auto* c = new MockController(); c->parent = parent; g_last = c->wv; g_lastCtl = c; h->Invoke(S_OK, c); c->Release(); h->Release(); Release(); });
    return S_OK;
  }
  HRESULT STDMETHODCALLTYPE CreateWebResourceResponse(IStream* content, int status, LPCWSTR reason, LPCWSTR headers, ICoreWebView2WebResourceResponse** out) override {
    ULONGLONG size = 0; STATSTG st{}; if (content && SUCCEEDED(content->Stat(&st, STATFLAG_NONAME))) size = st.cbSize.QuadPart;
    std::wstring h = headers ? headers : L""; for (auto& c : h) if (c == L'\r' || c == L'\n') c = L'|';
    Log(L"CreateResponse:" + std::to_wstring(status) + L":" + std::to_wstring(size) + L":" + std::wstring(reason ? reason : L"") + L":" + h);  // 完整记下协议头（用例要核对每一项）
    *out = new MockResponse(); return S_OK;
  }
  HRESULT STDMETHODCALLTYPE get_BrowserVersionString(LPWSTR* v) override { *v = Dup(L"120.0.0.1"); return S_OK; }
  HRESULT STDMETHODCALLTYPE add_NewBrowserVersionAvailable(ICoreWebView2NewBrowserVersionAvailableEventHandler*, EventRegistrationToken* t) override { if (t) t->value = 1; return S_OK; }
  HRESULT STDMETHODCALLTYPE remove_NewBrowserVersionAvailable(EventRegistrationToken) override { return S_OK; }
};
static std::wstring Str(LPWSTR s) { std::wstring r = s ? s : L"(null)"; CoTaskMemFree(s); return r; }
template <class I> static I* Q(IUnknown* u) { I* p = nullptr; return SUCCEEDED(u->QueryInterface(wv::wv_iid<I>::get(), (void**)&p)) ? p : nullptr; }
extern "C" __declspec(dllexport) HRESULT __stdcall CreateWebViewEnvironmentWithOptionsInternal(bool, int type, PCWSTR udf, IUnknown* opt,
                                                                                               ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler* h) {
  Log(L"CreateEnv:type=" + std::to_wstring(type) + L";udf=" + (udf ? udf : L"(null)"));
  if (opt) {  // 像真实运行时一样，经各个选项接口读取宿主提供的环境选项（检验宿主 COM 对象的虚表）
    if (auto* o = Q<ICoreWebView2EnvironmentOptions>(opt)) {
      LPWSTR s = nullptr; o->get_AdditionalBrowserArguments(&s); Log(L"Opt.Args=" + Str(s));
      s = nullptr; o->get_Language(&s); Log(L"Opt.Lang=" + Str(s));
      s = nullptr; o->get_TargetCompatibleBrowserVersion(&s); Log(L"Opt.Target=" + Str(s));
      BOOL b = 7; o->get_AllowSingleSignOnUsingOSPrimaryAccount(&b); Log(L"Opt.SSO=" + std::to_wstring(b)); o->Release();
    } else Log(L"Opt=none");
    if (auto* o = Q<ICoreWebView2EnvironmentOptions2>(opt)) { BOOL b = 7; o->get_ExclusiveUserDataFolderAccess(&b); Log(L"Opt2.Exclusive=" + std::to_wstring(b)); o->Release(); } else Log(L"Opt2=none");
    if (auto* o = Q<ICoreWebView2EnvironmentOptions3>(opt)) { BOOL b = 7; o->get_IsCustomCrashReportingEnabled(&b); Log(L"Opt3.Crash=" + std::to_wstring(b)); o->Release(); } else Log(L"Opt3=none");
    if (auto* o = Q<ICoreWebView2EnvironmentOptions4>(opt)) { Log(L"Opt4=present"); o->Release(); } else Log(L"Opt4=none");
    if (auto* o = Q<ICoreWebView2EnvironmentOptions5>(opt)) { BOOL b = 7; o->get_EnableTrackingPrevention(&b); Log(L"Opt5.Tracking=" + std::to_wstring(b)); o->Release(); } else Log(L"Opt5=none");
    if (auto* o = Q<ICoreWebView2EnvironmentOptions6>(opt)) { BOOL b = 7; o->get_AreBrowserExtensionsEnabled(&b); Log(L"Opt6.Ext=" + std::to_wstring(b)); o->Release(); } else Log(L"Opt6=none");
    if (auto* o = Q<ICoreWebView2EnvironmentOptions8>(opt)) { COREWEBVIEW2_SCROLLBAR_STYLE v = (COREWEBVIEW2_SCROLLBAR_STYLE)7; o->get_ScrollBarStyle(&v); Log(L"Opt8.Scroll=" + std::to_wstring((int)v)); o->Release(); } else Log(L"Opt8=none");
  }
  h->AddRef();
  HRESULT fail = g_failEnvHr; g_failEnvHr = 0;
  if (fail) { Log(L"CreateEnv.Fail"); Defer([h, fail] { h->Invoke(fail, nullptr); h->Release(); }); return S_OK; }
  Defer([h] { auto* e = new MockEnv(); h->Invoke(S_OK, e); e->Release(); h->Release(); });
  return S_OK;
}
extern "C" __declspec(dllexport) void __stdcall Mock_Note(const wchar_t* s) { Log(L"Note:" + std::wstring(s)); }
extern "C" __declspec(dllexport) void __stdcall Mock_HoldDownloads(int on) {
  g_holdDownloads = on != 0;
  if (on) return;
  std::vector<std::function<void()>> list;
  list.swap(g_heldDownloads);
  for (auto& f : list) f();
}
extern "C" __declspec(dllexport) void __stdcall Mock_HoldScripts(int on) {
  g_holdScripts = on != 0;
  if (on) return;
  std::vector<std::function<void()>> list;
  list.swap(g_heldScripts);
  for (auto& f : list) f();
}
extern "C" __declspec(dllexport) void __stdcall Mock_SendWebMessageFrom(const wchar_t* src, const wchar_t* j) { std::wstring s = j, o = src; if (auto* w = g_last) w->Later([w, s, o] { g_nextSource = o; w->RaiseMsg(s); }); }
extern "C" __declspec(dllexport) void __stdcall Mock_SendWebMessage(const wchar_t* j) { std::wstring s = j; if (auto* w = g_last) w->Later([w, s] { w->RaiseMsg(s); }); }
// 1.8.2：发一条附带文件的网页消息（files 以竖线分隔；haveColl 非 0＝内核支持附带对象）。ç¨äº WVK_FILES çæµè¯
extern "C" __declspec(dllexport) void __stdcall Mock_SendWebMessageFiles(const wchar_t* j, const wchar_t* files, int haveColl) {
  std::wstring s = j, f = files ? files : L""; bool hc = haveColl != 0;
  std::vector<std::wstring> v; size_t p = 0;
  while (!f.empty()) { size_t q = f.find(L'|', p); std::wstring part = f.substr(p, q == std::wstring::npos ? q : q - p); if (!part.empty()) v.push_back(part); if (q == std::wstring::npos) break; p = q + 1; }
  if (auto* w = g_last) w->Later([w, s, v, hc] { w->RaiseMsgF(s, v, hc); });
}
extern "C" __declspec(dllexport) void __stdcall Mock_NewWindow(const wchar_t* u) { std::wstring s = u; if (auto* w = g_last) w->Later([w, s] { w->RaiseNewWin(s); }); }
extern "C" __declspec(dllexport) void __stdcall Mock_Permission(const wchar_t* u) { std::wstring s = u; if (auto* w = g_last) w->Later([w, s] { w->RaisePerm(s); }); }
extern "C" __declspec(dllexport) int __stdcall Mock_LogCount() { std::lock_guard<std::mutex> l(g_mx); return (int)g_log.size(); }
extern "C" __declspec(dllexport) const wchar_t* __stdcall Mock_LogAt(int i) {
  static thread_local std::wstring r; std::lock_guard<std::mutex> l(g_mx); r = (i >= 0 && i < (int)g_log.size()) ? g_log[i] : std::wstring(); return r.c_str();
}

extern "C" __declspec(dllexport) void __stdcall Mock_Request(const wchar_t* u, int ctx) { std::wstring s = u; if (auto* w = g_last) w->Later([w, s, ctx] { w->RaiseReq(s, ctx); }); }
extern "C" __declspec(dllexport) void __stdcall Mock_ProcessFailed(int k) { if (auto* w = g_last) w->Later([w, k] { w->RaiseFail(k); }); }
extern "C" __declspec(dllexport) void __stdcall Mock_Fullscreen(int on) { if (auto* w = g_last) w->Later([w, on] { w->RaiseFull(on); }); }
extern "C" __declspec(dllexport) void __stdcall Mock_Response(const wchar_t* u, int status, const char* body) { std::wstring s = u; std::string b = body; if (auto* w = g_last) w->Later([w, s, status, b] { w->RaiseResp(s, status, b); }); }
extern "C" __declspec(dllexport) void __stdcall Mock_Download(const wchar_t* u, int total) { std::wstring s = u; if (auto* w = g_last) w->Later([w, s, total] { w->RaiseDownload(s, total); }); }
extern "C" __declspec(dllexport) void __stdcall Mock_Dialog(int kind, const wchar_t* msg, const wchar_t* def) { std::wstring m = msg, d = def; if (auto* w = g_last) w->Later([w, kind, m, d] { w->RaiseDialog(kind, m, d); }); }
extern "C" __declspec(dllexport) void __stdcall Mock_MoveFocusRequested(int reason) { if (auto* c = g_lastCtl) { c->AddRef(); c->RaiseMoveFocus(reason); c->Release(); } }
extern "C" __declspec(dllexport) int __stdcall Mock_Live() { LONG t = 0; EnterCriticalSection(&LiveCs()); for (auto& kv : LiveMap()) t += kv.second; LeaveCriticalSection(&LiveCs()); return (int)t; }
extern "C" __declspec(dllexport) const wchar_t* __stdcall Mock_LiveReport() {
  static std::wstring r; r.clear(); EnterCriticalSection(&LiveCs());
  for (auto& kv : LiveMap()) if (kv.second) r += std::wstring(kv.first.begin(), kv.first.end()) + L"=" + std::to_wstring(kv.second) + L" ";
  LeaveCriticalSection(&LiveCs()); return r.c_str();
}
extern "C" __declspec(dllexport) void __stdcall Mock_Key(int vk, int kind) { if (auto* c = g_lastCtl) { c->AddRef(); Defer([c, vk, kind] { c->RaiseKey((UINT)vk, kind); c->Release(); }); } }
extern "C" __declspec(dllexport) void __stdcall Mock_Menu(int variant) { if (auto* w = g_last) w->Later([w, variant] { w->RaiseMenu(variant); }); }
extern "C" __declspec(dllexport) void __stdcall Mock_Auth(const wchar_t* u) { std::wstring s = u; if (auto* w = g_last) w->Later([w, s] { w->RaiseAuth(s); }); }
extern "C" __declspec(dllexport) void __stdcall Mock_CdpEvent(const wchar_t* n, const wchar_t* j) { std::wstring a = n, b = j; if (auto* w = g_last) w->Later([w, a, b] { w->RaiseCdp(a, b); }); }
extern "C" __declspec(dllexport) void __stdcall Mock_SetEnvLevel(int n) { g_envLevel = n; Log(L"EnvLevel=" + std::to_wstring(n)); }
extern "C" __declspec(dllexport) void __stdcall Mock_SetWvLevel(int n) { g_wvLevel = n; Log(L"WvLevel=" + std::to_wstring(n)); }
extern "C" __declspec(dllexport) void __stdcall Mock_SetSettingsLevel(int n) { g_settingsLevel = n; Log(L"SettingsLevel=" + std::to_wstring(n)); }
extern "C" __declspec(dllexport) void __stdcall Mock_FailNextEnv(int hr) { g_failEnvHr = (HRESULT)hr; }
extern "C" __declspec(dllexport) void __stdcall Mock_FailNextController(int hr) { g_failCtlHr = (HRESULT)hr; }
