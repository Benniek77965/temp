// 由 gen_mock_stubs.py 从 WebView2.h 生成，请勿手改
#pragma once
struct Stub_ICoreWebView2Environment : public ICoreWebView2Environment {
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2Controller(HWND parentWindow, ICoreWebView2CreateCoreWebView2ControllerCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateWebResourceResponse(IStream *content, int statusCode, LPCWSTR reasonPhrase, LPCWSTR headers, ICoreWebView2WebResourceResponse **response) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_BrowserVersionString(LPWSTR *versionInfo) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_NewBrowserVersionAvailable(ICoreWebView2NewBrowserVersionAvailableEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_NewBrowserVersionAvailable(EventRegistrationToken token) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2Controller : public ICoreWebView2Controller {
  HRESULT STDMETHODCALLTYPE get_IsVisible(BOOL *isVisible) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsVisible(BOOL isVisible) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Bounds(RECT *bounds) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Bounds(RECT bounds) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ZoomFactor(double *zoomFactor) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_ZoomFactor(double zoomFactor) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ZoomFactorChanged(ICoreWebView2ZoomFactorChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ZoomFactorChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE SetBoundsAndZoomFactor(RECT bounds, double zoomFactor) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON reason) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_MoveFocusRequested(ICoreWebView2MoveFocusRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_MoveFocusRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_GotFocus(ICoreWebView2FocusChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_GotFocus(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_LostFocus(ICoreWebView2FocusChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_LostFocus(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_AcceleratorKeyPressed(ICoreWebView2AcceleratorKeyPressedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_AcceleratorKeyPressed(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ParentWindow(HWND *parentWindow) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_ParentWindow(HWND parentWindow) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE NotifyParentWindowPositionChanged(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Close(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_CoreWebView2(ICoreWebView2 **coreWebView2) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2 : public ICoreWebView2 {
  HRESULT STDMETHODCALLTYPE get_Settings(ICoreWebView2Settings **settings) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Source(LPWSTR *uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Navigate(LPCWSTR uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE NavigateToString(LPCWSTR htmlContent) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_NavigationStarting(ICoreWebView2NavigationStartingEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_NavigationStarting(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ContentLoading(ICoreWebView2ContentLoadingEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ContentLoading(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_SourceChanged(ICoreWebView2SourceChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_SourceChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_HistoryChanged(ICoreWebView2HistoryChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_HistoryChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_NavigationCompleted(ICoreWebView2NavigationCompletedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_NavigationCompleted(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_FrameNavigationStarting(ICoreWebView2NavigationStartingEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_FrameNavigationStarting(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_FrameNavigationCompleted(ICoreWebView2NavigationCompletedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_FrameNavigationCompleted(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ScriptDialogOpening(ICoreWebView2ScriptDialogOpeningEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ScriptDialogOpening(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_PermissionRequested(ICoreWebView2PermissionRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_PermissionRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ProcessFailed(ICoreWebView2ProcessFailedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ProcessFailed(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE AddScriptToExecuteOnDocumentCreated(LPCWSTR javaScript, ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE RemoveScriptToExecuteOnDocumentCreated(LPCWSTR id) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE ExecuteScript(LPCWSTR javaScript, ICoreWebView2ExecuteScriptCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CapturePreview(COREWEBVIEW2_CAPTURE_PREVIEW_IMAGE_FORMAT imageFormat, IStream *imageStream, ICoreWebView2CapturePreviewCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Reload(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE PostWebMessageAsJson(LPCWSTR webMessageAsJson) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE PostWebMessageAsString(LPCWSTR webMessageAsString) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_WebMessageReceived(ICoreWebView2WebMessageReceivedEventHandler *handler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_WebMessageReceived(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CallDevToolsProtocolMethod(LPCWSTR methodName, LPCWSTR parametersAsJson, ICoreWebView2CallDevToolsProtocolMethodCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_BrowserProcessId(UINT32 *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_CanGoBack(BOOL *canGoBack) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_CanGoForward(BOOL *canGoForward) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GoBack(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GoForward(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetDevToolsProtocolEventReceiver(LPCWSTR eventName, ICoreWebView2DevToolsProtocolEventReceiver **receiver) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Stop(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_NewWindowRequested(ICoreWebView2NewWindowRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_NewWindowRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_DocumentTitleChanged(ICoreWebView2DocumentTitleChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_DocumentTitleChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_DocumentTitle(LPWSTR *title) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE AddHostObjectToScript(LPCWSTR name, VARIANT *object) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE RemoveHostObjectFromScript(LPCWSTR name) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE OpenDevToolsWindow(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ContainsFullScreenElementChanged(ICoreWebView2ContainsFullScreenElementChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ContainsFullScreenElementChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ContainsFullScreenElement(BOOL *containsFullScreenElement) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_WebResourceRequested(ICoreWebView2WebResourceRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_WebResourceRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE AddWebResourceRequestedFilter(const LPCWSTR uri, const COREWEBVIEW2_WEB_RESOURCE_CONTEXT resourceContext) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE RemoveWebResourceRequestedFilter(const LPCWSTR uri, const COREWEBVIEW2_WEB_RESOURCE_CONTEXT resourceContext) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_WindowCloseRequested(ICoreWebView2WindowCloseRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_WindowCloseRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2Settings : public ICoreWebView2Settings {
  HRESULT STDMETHODCALLTYPE get_IsScriptEnabled(BOOL *isScriptEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsScriptEnabled(BOOL isScriptEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsWebMessageEnabled(BOOL *isWebMessageEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsWebMessageEnabled(BOOL isWebMessageEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_AreDefaultScriptDialogsEnabled(BOOL *areDefaultScriptDialogsEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_AreDefaultScriptDialogsEnabled(BOOL areDefaultScriptDialogsEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsStatusBarEnabled(BOOL *isStatusBarEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsStatusBarEnabled(BOOL isStatusBarEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_AreDevToolsEnabled(BOOL *areDevToolsEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_AreDevToolsEnabled(BOOL areDevToolsEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_AreDefaultContextMenusEnabled(BOOL *enabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_AreDefaultContextMenusEnabled(BOOL enabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_AreHostObjectsAllowed(BOOL *allowed) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_AreHostObjectsAllowed(BOOL allowed) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsZoomControlEnabled(BOOL *enabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsZoomControlEnabled(BOOL enabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsBuiltInErrorPageEnabled(BOOL *enabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsBuiltInErrorPageEnabled(BOOL enabled) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2NavigationStartingEventArgs : public ICoreWebView2NavigationStartingEventArgs {
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR *uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsUserInitiated(BOOL *isUserInitiated) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsRedirected(BOOL *isRedirected) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_RequestHeaders(ICoreWebView2HttpRequestHeaders **requestHeaders) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Cancel(BOOL *cancel) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Cancel(BOOL cancel) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_NavigationId(UINT64 *navigationId) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2NavigationCompletedEventArgs : public ICoreWebView2NavigationCompletedEventArgs {
  HRESULT STDMETHODCALLTYPE get_IsSuccess(BOOL *isSuccess) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_WebErrorStatus(COREWEBVIEW2_WEB_ERROR_STATUS *webErrorStatus) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_NavigationId(UINT64 *navigationId) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2SourceChangedEventArgs : public ICoreWebView2SourceChangedEventArgs {
  HRESULT STDMETHODCALLTYPE get_IsNewDocument(BOOL *value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2WebMessageReceivedEventArgs : public ICoreWebView2WebMessageReceivedEventArgs {
  HRESULT STDMETHODCALLTYPE get_Source(LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_WebMessageAsJson(LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE TryGetWebMessageAsString(LPWSTR *value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2NewWindowRequestedEventArgs : public ICoreWebView2NewWindowRequestedEventArgs {
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR *uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_NewWindow(ICoreWebView2 *newWindow) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_NewWindow(ICoreWebView2 **newWindow) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Handled(BOOL handled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Handled(BOOL *handled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsUserInitiated(BOOL *isUserInitiated) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetDeferral(ICoreWebView2Deferral **deferral) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_WindowFeatures(ICoreWebView2WindowFeatures **value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2PermissionRequestedEventArgs : public ICoreWebView2PermissionRequestedEventArgs {
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR *uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_PermissionKind(COREWEBVIEW2_PERMISSION_KIND *permissionKind) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsUserInitiated(BOOL *isUserInitiated) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_State(COREWEBVIEW2_PERMISSION_STATE *state) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_State(COREWEBVIEW2_PERMISSION_STATE state) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetDeferral(ICoreWebView2Deferral **deferral) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2Deferral : public ICoreWebView2Deferral {
  HRESULT STDMETHODCALLTYPE Complete(void) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2WebResourceRequestedEventArgs : public ICoreWebView2WebResourceRequestedEventArgs {
  HRESULT STDMETHODCALLTYPE get_Request(ICoreWebView2WebResourceRequest **request) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Response(ICoreWebView2WebResourceResponse **response) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Response(ICoreWebView2WebResourceResponse *response) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetDeferral(ICoreWebView2Deferral **deferral) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ResourceContext(COREWEBVIEW2_WEB_RESOURCE_CONTEXT *context) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2WebResourceRequest : public ICoreWebView2WebResourceRequest {
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR *uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Uri(LPCWSTR uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Method(LPWSTR *method) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Method(LPCWSTR method) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Content(IStream **content) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Content(IStream *content) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Headers(ICoreWebView2HttpRequestHeaders **headers) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2HttpRequestHeaders : public ICoreWebView2HttpRequestHeaders {
  HRESULT STDMETHODCALLTYPE GetHeader(LPCWSTR name, LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetHeaders(LPCWSTR name, ICoreWebView2HttpHeadersCollectionIterator **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Contains(LPCWSTR name, BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE SetHeader(LPCWSTR name, LPCWSTR value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE RemoveHeader(LPCWSTR name) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetIterator(ICoreWebView2HttpHeadersCollectionIterator **value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2WebResourceResponse : public ICoreWebView2WebResourceResponse {
  HRESULT STDMETHODCALLTYPE get_Content(IStream **content) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Content(IStream *content) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Headers(ICoreWebView2HttpResponseHeaders **headers) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_StatusCode(int *statusCode) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_StatusCode(int statusCode) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ReasonPhrase(LPWSTR *reasonPhrase) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_ReasonPhrase(LPCWSTR reasonPhrase) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2ProcessFailedEventArgs : public ICoreWebView2ProcessFailedEventArgs {
  HRESULT STDMETHODCALLTYPE get_ProcessFailedKind(COREWEBVIEW2_PROCESS_FAILED_KIND *value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2_4 : public ICoreWebView2_4 {
  HRESULT STDMETHODCALLTYPE get_Settings(ICoreWebView2Settings **settings) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Source(LPWSTR *uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Navigate(LPCWSTR uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE NavigateToString(LPCWSTR htmlContent) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_NavigationStarting(ICoreWebView2NavigationStartingEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_NavigationStarting(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ContentLoading(ICoreWebView2ContentLoadingEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ContentLoading(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_SourceChanged(ICoreWebView2SourceChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_SourceChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_HistoryChanged(ICoreWebView2HistoryChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_HistoryChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_NavigationCompleted(ICoreWebView2NavigationCompletedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_NavigationCompleted(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_FrameNavigationStarting(ICoreWebView2NavigationStartingEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_FrameNavigationStarting(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_FrameNavigationCompleted(ICoreWebView2NavigationCompletedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_FrameNavigationCompleted(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ScriptDialogOpening(ICoreWebView2ScriptDialogOpeningEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ScriptDialogOpening(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_PermissionRequested(ICoreWebView2PermissionRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_PermissionRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ProcessFailed(ICoreWebView2ProcessFailedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ProcessFailed(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE AddScriptToExecuteOnDocumentCreated(LPCWSTR javaScript, ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE RemoveScriptToExecuteOnDocumentCreated(LPCWSTR id) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE ExecuteScript(LPCWSTR javaScript, ICoreWebView2ExecuteScriptCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CapturePreview(COREWEBVIEW2_CAPTURE_PREVIEW_IMAGE_FORMAT imageFormat, IStream *imageStream, ICoreWebView2CapturePreviewCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Reload(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE PostWebMessageAsJson(LPCWSTR webMessageAsJson) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE PostWebMessageAsString(LPCWSTR webMessageAsString) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_WebMessageReceived(ICoreWebView2WebMessageReceivedEventHandler *handler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_WebMessageReceived(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CallDevToolsProtocolMethod(LPCWSTR methodName, LPCWSTR parametersAsJson, ICoreWebView2CallDevToolsProtocolMethodCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_BrowserProcessId(UINT32 *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_CanGoBack(BOOL *canGoBack) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_CanGoForward(BOOL *canGoForward) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GoBack(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GoForward(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetDevToolsProtocolEventReceiver(LPCWSTR eventName, ICoreWebView2DevToolsProtocolEventReceiver **receiver) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Stop(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_NewWindowRequested(ICoreWebView2NewWindowRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_NewWindowRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_DocumentTitleChanged(ICoreWebView2DocumentTitleChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_DocumentTitleChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_DocumentTitle(LPWSTR *title) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE AddHostObjectToScript(LPCWSTR name, VARIANT *object) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE RemoveHostObjectFromScript(LPCWSTR name) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE OpenDevToolsWindow(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ContainsFullScreenElementChanged(ICoreWebView2ContainsFullScreenElementChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ContainsFullScreenElementChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ContainsFullScreenElement(BOOL *containsFullScreenElement) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_WebResourceRequested(ICoreWebView2WebResourceRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_WebResourceRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE AddWebResourceRequestedFilter(const LPCWSTR uri, const COREWEBVIEW2_WEB_RESOURCE_CONTEXT resourceContext) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE RemoveWebResourceRequestedFilter(const LPCWSTR uri, const COREWEBVIEW2_WEB_RESOURCE_CONTEXT resourceContext) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_WindowCloseRequested(ICoreWebView2WindowCloseRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_WindowCloseRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_WebResourceResponseReceived(ICoreWebView2WebResourceResponseReceivedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_WebResourceResponseReceived(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE NavigateWithWebResourceRequest(ICoreWebView2WebResourceRequest *request) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_DOMContentLoaded(ICoreWebView2DOMContentLoadedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_DOMContentLoaded(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_CookieManager(ICoreWebView2CookieManager **cookieManager) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Environment(ICoreWebView2Environment **environment) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE TrySuspend(ICoreWebView2TrySuspendCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Resume(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsSuspended(BOOL *isSuspended) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE SetVirtualHostNameToFolderMapping(LPCWSTR hostName, LPCWSTR folderPath, COREWEBVIEW2_HOST_RESOURCE_ACCESS_KIND accessKind) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE ClearVirtualHostNameToFolderMapping(LPCWSTR hostName) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_FrameCreated(ICoreWebView2FrameCreatedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_FrameCreated(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_DownloadStarting(ICoreWebView2DownloadStartingEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_DownloadStarting(EventRegistrationToken token) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2CookieManager : public ICoreWebView2CookieManager {
  HRESULT STDMETHODCALLTYPE CreateCookie(LPCWSTR name, LPCWSTR value, LPCWSTR domain, LPCWSTR path, ICoreWebView2Cookie **cookie) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CopyCookie(ICoreWebView2Cookie *cookieParam, ICoreWebView2Cookie **cookie) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetCookies(LPCWSTR uri, ICoreWebView2GetCookiesCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE AddOrUpdateCookie(ICoreWebView2Cookie *cookie) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE DeleteCookie(ICoreWebView2Cookie *cookie) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE DeleteCookies(LPCWSTR name, LPCWSTR uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE DeleteCookiesWithDomainAndPath(LPCWSTR name, LPCWSTR domain, LPCWSTR path) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE DeleteAllCookies(void) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2Cookie : public ICoreWebView2Cookie {
  HRESULT STDMETHODCALLTYPE get_Name(LPWSTR *name) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Value(LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Value(LPCWSTR value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Domain(LPWSTR *domain) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Path(LPWSTR *path) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Expires(double *expires) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Expires(double expires) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsHttpOnly(BOOL *isHttpOnly) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsHttpOnly(BOOL isHttpOnly) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_SameSite(COREWEBVIEW2_COOKIE_SAME_SITE_KIND *sameSite) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_SameSite(COREWEBVIEW2_COOKIE_SAME_SITE_KIND sameSite) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsSecure(BOOL *isSecure) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsSecure(BOOL isSecure) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsSession(BOOL *isSession) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2CookieList : public ICoreWebView2CookieList {
  HRESULT STDMETHODCALLTYPE get_Count(UINT32 *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetValueAtIndex(UINT32 index, ICoreWebView2Cookie **value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2WebResourceResponseReceivedEventArgs : public ICoreWebView2WebResourceResponseReceivedEventArgs {
  HRESULT STDMETHODCALLTYPE get_Request(ICoreWebView2WebResourceRequest **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Response(ICoreWebView2WebResourceResponseView **value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2WebResourceResponseView : public ICoreWebView2WebResourceResponseView {
  HRESULT STDMETHODCALLTYPE get_Headers(ICoreWebView2HttpResponseHeaders **headers) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_StatusCode(int *statusCode) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ReasonPhrase(LPWSTR *reasonPhrase) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetContent(ICoreWebView2WebResourceResponseViewGetContentCompletedHandler *handler) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2DOMContentLoadedEventArgs : public ICoreWebView2DOMContentLoadedEventArgs {
  HRESULT STDMETHODCALLTYPE get_NavigationId(UINT64 *value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2DownloadStartingEventArgs : public ICoreWebView2DownloadStartingEventArgs {
  HRESULT STDMETHODCALLTYPE get_DownloadOperation(ICoreWebView2DownloadOperation **downloadOperation) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Cancel(BOOL *cancel) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Cancel(BOOL cancel) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ResultFilePath(LPWSTR *resultFilePath) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_ResultFilePath(LPCWSTR resultFilePath) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Handled(BOOL *handled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Handled(BOOL handled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetDeferral(ICoreWebView2Deferral **deferral) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2DownloadOperation : public ICoreWebView2DownloadOperation {
  HRESULT STDMETHODCALLTYPE add_BytesReceivedChanged(ICoreWebView2BytesReceivedChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_BytesReceivedChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_EstimatedEndTimeChanged(ICoreWebView2EstimatedEndTimeChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_EstimatedEndTimeChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_StateChanged(ICoreWebView2StateChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_StateChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR *uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ContentDisposition(LPWSTR *contentDisposition) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_MimeType(LPWSTR *mimeType) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_TotalBytesToReceive(INT64 *totalBytesToReceive) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_BytesReceived(INT64 *bytesReceived) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_EstimatedEndTime(LPWSTR *estimatedEndTime) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ResultFilePath(LPWSTR *resultFilePath) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_State(COREWEBVIEW2_DOWNLOAD_STATE *downloadState) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_InterruptReason(COREWEBVIEW2_DOWNLOAD_INTERRUPT_REASON *interruptReason) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Cancel(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Pause(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Resume(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_CanResume(BOOL *canResume) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2ScriptDialogOpeningEventArgs : public ICoreWebView2ScriptDialogOpeningEventArgs {
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR *uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Kind(COREWEBVIEW2_SCRIPT_DIALOG_KIND *kind) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Message(LPWSTR *message) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Accept(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_DefaultText(LPWSTR *defaultText) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ResultText(LPWSTR *resultText) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_ResultText(LPCWSTR resultText) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetDeferral(ICoreWebView2Deferral **deferral) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2_11 : public ICoreWebView2_11 {
  HRESULT STDMETHODCALLTYPE get_Settings(ICoreWebView2Settings **settings) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Source(LPWSTR *uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Navigate(LPCWSTR uri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE NavigateToString(LPCWSTR htmlContent) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_NavigationStarting(ICoreWebView2NavigationStartingEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_NavigationStarting(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ContentLoading(ICoreWebView2ContentLoadingEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ContentLoading(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_SourceChanged(ICoreWebView2SourceChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_SourceChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_HistoryChanged(ICoreWebView2HistoryChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_HistoryChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_NavigationCompleted(ICoreWebView2NavigationCompletedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_NavigationCompleted(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_FrameNavigationStarting(ICoreWebView2NavigationStartingEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_FrameNavigationStarting(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_FrameNavigationCompleted(ICoreWebView2NavigationCompletedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_FrameNavigationCompleted(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ScriptDialogOpening(ICoreWebView2ScriptDialogOpeningEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ScriptDialogOpening(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_PermissionRequested(ICoreWebView2PermissionRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_PermissionRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ProcessFailed(ICoreWebView2ProcessFailedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ProcessFailed(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE AddScriptToExecuteOnDocumentCreated(LPCWSTR javaScript, ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE RemoveScriptToExecuteOnDocumentCreated(LPCWSTR id) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE ExecuteScript(LPCWSTR javaScript, ICoreWebView2ExecuteScriptCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CapturePreview(COREWEBVIEW2_CAPTURE_PREVIEW_IMAGE_FORMAT imageFormat, IStream *imageStream, ICoreWebView2CapturePreviewCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Reload(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE PostWebMessageAsJson(LPCWSTR webMessageAsJson) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE PostWebMessageAsString(LPCWSTR webMessageAsString) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_WebMessageReceived(ICoreWebView2WebMessageReceivedEventHandler *handler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_WebMessageReceived(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CallDevToolsProtocolMethod(LPCWSTR methodName, LPCWSTR parametersAsJson, ICoreWebView2CallDevToolsProtocolMethodCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_BrowserProcessId(UINT32 *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_CanGoBack(BOOL *canGoBack) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_CanGoForward(BOOL *canGoForward) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GoBack(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GoForward(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetDevToolsProtocolEventReceiver(LPCWSTR eventName, ICoreWebView2DevToolsProtocolEventReceiver **receiver) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Stop(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_NewWindowRequested(ICoreWebView2NewWindowRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_NewWindowRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_DocumentTitleChanged(ICoreWebView2DocumentTitleChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_DocumentTitleChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_DocumentTitle(LPWSTR *title) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE AddHostObjectToScript(LPCWSTR name, VARIANT *object) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE RemoveHostObjectFromScript(LPCWSTR name) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE OpenDevToolsWindow(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ContainsFullScreenElementChanged(ICoreWebView2ContainsFullScreenElementChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ContainsFullScreenElementChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ContainsFullScreenElement(BOOL *containsFullScreenElement) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_WebResourceRequested(ICoreWebView2WebResourceRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_WebResourceRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE AddWebResourceRequestedFilter(const LPCWSTR uri, const COREWEBVIEW2_WEB_RESOURCE_CONTEXT resourceContext) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE RemoveWebResourceRequestedFilter(const LPCWSTR uri, const COREWEBVIEW2_WEB_RESOURCE_CONTEXT resourceContext) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_WindowCloseRequested(ICoreWebView2WindowCloseRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_WindowCloseRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_WebResourceResponseReceived(ICoreWebView2WebResourceResponseReceivedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_WebResourceResponseReceived(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE NavigateWithWebResourceRequest(ICoreWebView2WebResourceRequest *request) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_DOMContentLoaded(ICoreWebView2DOMContentLoadedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_DOMContentLoaded(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_CookieManager(ICoreWebView2CookieManager **cookieManager) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Environment(ICoreWebView2Environment **environment) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE TrySuspend(ICoreWebView2TrySuspendCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE Resume(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsSuspended(BOOL *isSuspended) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE SetVirtualHostNameToFolderMapping(LPCWSTR hostName, LPCWSTR folderPath, COREWEBVIEW2_HOST_RESOURCE_ACCESS_KIND accessKind) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE ClearVirtualHostNameToFolderMapping(LPCWSTR hostName) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_FrameCreated(ICoreWebView2FrameCreatedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_FrameCreated(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_DownloadStarting(ICoreWebView2DownloadStartingEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_DownloadStarting(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ClientCertificateRequested(ICoreWebView2ClientCertificateRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ClientCertificateRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE OpenTaskManagerWindow(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE PrintToPdf(LPCWSTR ResultFilePath, ICoreWebView2PrintSettings *printSettings, ICoreWebView2PrintToPdfCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_IsMutedChanged(ICoreWebView2IsMutedChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_IsMutedChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsMuted(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsMuted(BOOL value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_IsDocumentPlayingAudioChanged(ICoreWebView2IsDocumentPlayingAudioChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_IsDocumentPlayingAudioChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsDocumentPlayingAudio(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_IsDefaultDownloadDialogOpenChanged(ICoreWebView2IsDefaultDownloadDialogOpenChangedEventHandler *handler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_IsDefaultDownloadDialogOpenChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsDefaultDownloadDialogOpen(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE OpenDefaultDownloadDialog(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CloseDefaultDownloadDialog(void) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_DefaultDownloadDialogCornerAlignment(COREWEBVIEW2_DEFAULT_DOWNLOAD_DIALOG_CORNER_ALIGNMENT *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_DefaultDownloadDialogCornerAlignment(COREWEBVIEW2_DEFAULT_DOWNLOAD_DIALOG_CORNER_ALIGNMENT value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_DefaultDownloadDialogMargin(POINT *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_DefaultDownloadDialogMargin(POINT value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_BasicAuthenticationRequested(ICoreWebView2BasicAuthenticationRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_BasicAuthenticationRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CallDevToolsProtocolMethodForSession(LPCWSTR sessionId, LPCWSTR methodName, LPCWSTR parametersAsJson, ICoreWebView2CallDevToolsProtocolMethodCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ContextMenuRequested(ICoreWebView2ContextMenuRequestedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ContextMenuRequested(EventRegistrationToken token) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2AcceleratorKeyPressedEventArgs : public ICoreWebView2AcceleratorKeyPressedEventArgs {
  HRESULT STDMETHODCALLTYPE get_KeyEventKind(COREWEBVIEW2_KEY_EVENT_KIND *keyEventKind) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_VirtualKey(UINT *virtualKey) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_KeyEventLParam(INT *lParam) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_PhysicalKeyStatus(COREWEBVIEW2_PHYSICAL_KEY_STATUS *physicalKeyStatus) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Handled(BOOL *handled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Handled(BOOL handled) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2ContextMenuRequestedEventArgs : public ICoreWebView2ContextMenuRequestedEventArgs {
  HRESULT STDMETHODCALLTYPE get_MenuItems(ICoreWebView2ContextMenuItemCollection **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ContextMenuTarget(ICoreWebView2ContextMenuTarget **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Location(POINT *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_SelectedCommandId(INT32 value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_SelectedCommandId(INT32 *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Handled(BOOL value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Handled(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetDeferral(ICoreWebView2Deferral **deferral) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2ContextMenuItemCollection : public ICoreWebView2ContextMenuItemCollection {
  HRESULT STDMETHODCALLTYPE get_Count(UINT32 *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetValueAtIndex(UINT32 index, ICoreWebView2ContextMenuItem **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE RemoveValueAtIndex(UINT32 index) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE InsertValueAtIndex(UINT32 index, ICoreWebView2ContextMenuItem *value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2ContextMenuItem : public ICoreWebView2ContextMenuItem {
  HRESULT STDMETHODCALLTYPE get_Name(LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Label(LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_CommandId(INT32 *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ShortcutKeyDescription(LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Icon(IStream **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Kind(COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsEnabled(BOOL value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsEnabled(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsChecked(BOOL value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsChecked(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Children(ICoreWebView2ContextMenuItemCollection **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_CustomItemSelected(ICoreWebView2CustomItemSelectedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_CustomItemSelected(EventRegistrationToken token) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2BasicAuthenticationRequestedEventArgs : public ICoreWebView2BasicAuthenticationRequestedEventArgs {
  HRESULT STDMETHODCALLTYPE get_Uri(LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Challenge(LPWSTR *challenge) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Response(ICoreWebView2BasicAuthenticationResponse **response) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Cancel(BOOL *cancel) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Cancel(BOOL cancel) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetDeferral(ICoreWebView2Deferral **deferral) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2BasicAuthenticationResponse : public ICoreWebView2BasicAuthenticationResponse {
  HRESULT STDMETHODCALLTYPE get_UserName(LPWSTR *userName) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_UserName(LPCWSTR userName) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_Password(LPWSTR *password) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Password(LPCWSTR password) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2Environment2 : public ICoreWebView2Environment2 {
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2Controller(HWND parentWindow, ICoreWebView2CreateCoreWebView2ControllerCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateWebResourceResponse(IStream *content, int statusCode, LPCWSTR reasonPhrase, LPCWSTR headers, ICoreWebView2WebResourceResponse **response) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_BrowserVersionString(LPWSTR *versionInfo) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_NewBrowserVersionAvailable(ICoreWebView2NewBrowserVersionAvailableEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_NewBrowserVersionAvailable(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateWebResourceRequest(LPCWSTR uri, LPCWSTR Method, IStream *postData, LPCWSTR Headers, ICoreWebView2WebResourceRequest **value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2Environment6 : public ICoreWebView2Environment6 {
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2Controller(HWND parentWindow, ICoreWebView2CreateCoreWebView2ControllerCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateWebResourceResponse(IStream *content, int statusCode, LPCWSTR reasonPhrase, LPCWSTR headers, ICoreWebView2WebResourceResponse **response) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_BrowserVersionString(LPWSTR *versionInfo) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_NewBrowserVersionAvailable(ICoreWebView2NewBrowserVersionAvailableEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_NewBrowserVersionAvailable(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateWebResourceRequest(LPCWSTR uri, LPCWSTR Method, IStream *postData, LPCWSTR Headers, ICoreWebView2WebResourceRequest **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2CompositionController(HWND ParentWindow, ICoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2PointerInfo(ICoreWebView2PointerInfo **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetAutomationProviderForWindow(HWND hwnd, IUnknown **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_BrowserProcessExited(ICoreWebView2BrowserProcessExitedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_BrowserProcessExited(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreatePrintSettings(ICoreWebView2PrintSettings **value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2Environment10 : public ICoreWebView2Environment10 {
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2Controller(HWND parentWindow, ICoreWebView2CreateCoreWebView2ControllerCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateWebResourceResponse(IStream *content, int statusCode, LPCWSTR reasonPhrase, LPCWSTR headers, ICoreWebView2WebResourceResponse **response) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_BrowserVersionString(LPWSTR *versionInfo) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_NewBrowserVersionAvailable(ICoreWebView2NewBrowserVersionAvailableEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_NewBrowserVersionAvailable(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateWebResourceRequest(LPCWSTR uri, LPCWSTR Method, IStream *postData, LPCWSTR Headers, ICoreWebView2WebResourceRequest **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2CompositionController(HWND ParentWindow, ICoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2PointerInfo(ICoreWebView2PointerInfo **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetAutomationProviderForWindow(HWND hwnd, IUnknown **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_BrowserProcessExited(ICoreWebView2BrowserProcessExitedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_BrowserProcessExited(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreatePrintSettings(ICoreWebView2PrintSettings **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_UserDataFolder(LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE add_ProcessInfosChanged(ICoreWebView2ProcessInfosChangedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_ProcessInfosChanged(EventRegistrationToken token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetProcessInfos(ICoreWebView2ProcessInfoCollection **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateContextMenuItem(LPCWSTR Label, IStream *iconStream, COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND Kind, ICoreWebView2ContextMenuItem **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2ControllerOptions(ICoreWebView2ControllerOptions **value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2ControllerWithOptions(HWND ParentWindow, ICoreWebView2ControllerOptions *options, ICoreWebView2CreateCoreWebView2ControllerCompletedHandler *handler) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE CreateCoreWebView2CompositionControllerWithOptions(HWND ParentWindow, ICoreWebView2ControllerOptions *options, ICoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler *handler) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2ControllerOptions : public ICoreWebView2ControllerOptions {
  HRESULT STDMETHODCALLTYPE get_ProfileName(LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_ProfileName(LPCWSTR value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsInPrivateModeEnabled(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsInPrivateModeEnabled(BOOL value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2PrintSettings : public ICoreWebView2PrintSettings {
  HRESULT STDMETHODCALLTYPE get_Orientation(COREWEBVIEW2_PRINT_ORIENTATION *orientation) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_Orientation(COREWEBVIEW2_PRINT_ORIENTATION orientation) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ScaleFactor(double *scaleFactor) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_ScaleFactor(double scaleFactor) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_PageWidth(double *pageWidth) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_PageWidth(double pageWidth) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_PageHeight(double *pageHeight) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_PageHeight(double pageHeight) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_MarginTop(double *marginTop) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_MarginTop(double marginTop) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_MarginBottom(double *marginBottom) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_MarginBottom(double marginBottom) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_MarginLeft(double *marginLeft) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_MarginLeft(double marginLeft) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_MarginRight(double *marginRight) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_MarginRight(double marginRight) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ShouldPrintBackgrounds(BOOL *shouldPrintBackgrounds) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_ShouldPrintBackgrounds(BOOL shouldPrintBackgrounds) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ShouldPrintSelectionOnly(BOOL *shouldPrintSelectionOnly) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_ShouldPrintSelectionOnly(BOOL shouldPrintSelectionOnly) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_ShouldPrintHeaderAndFooter(BOOL *shouldPrintHeaderAndFooter) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_ShouldPrintHeaderAndFooter(BOOL shouldPrintHeaderAndFooter) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_HeaderTitle(LPWSTR *headerTitle) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_HeaderTitle(LPCWSTR headerTitle) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_FooterUri(LPWSTR *footerUri) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_FooterUri(LPCWSTR footerUri) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2DevToolsProtocolEventReceiver : public ICoreWebView2DevToolsProtocolEventReceiver {
  HRESULT STDMETHODCALLTYPE add_DevToolsProtocolEventReceived(ICoreWebView2DevToolsProtocolEventReceivedEventHandler *eventHandler, EventRegistrationToken *token) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE remove_DevToolsProtocolEventReceived(EventRegistrationToken token) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2DevToolsProtocolEventReceivedEventArgs : public ICoreWebView2DevToolsProtocolEventReceivedEventArgs {
  HRESULT STDMETHODCALLTYPE get_ParameterObjectAsJson(LPWSTR *value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2Settings9 : public ICoreWebView2Settings9 {
  HRESULT STDMETHODCALLTYPE get_IsScriptEnabled(BOOL *isScriptEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsScriptEnabled(BOOL isScriptEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsWebMessageEnabled(BOOL *isWebMessageEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsWebMessageEnabled(BOOL isWebMessageEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_AreDefaultScriptDialogsEnabled(BOOL *areDefaultScriptDialogsEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_AreDefaultScriptDialogsEnabled(BOOL areDefaultScriptDialogsEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsStatusBarEnabled(BOOL *isStatusBarEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsStatusBarEnabled(BOOL isStatusBarEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_AreDevToolsEnabled(BOOL *areDevToolsEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_AreDevToolsEnabled(BOOL areDevToolsEnabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_AreDefaultContextMenusEnabled(BOOL *enabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_AreDefaultContextMenusEnabled(BOOL enabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_AreHostObjectsAllowed(BOOL *allowed) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_AreHostObjectsAllowed(BOOL allowed) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsZoomControlEnabled(BOOL *enabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsZoomControlEnabled(BOOL enabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsBuiltInErrorPageEnabled(BOOL *enabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsBuiltInErrorPageEnabled(BOOL enabled) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_UserAgent(LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_UserAgent(LPCWSTR value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_AreBrowserAcceleratorKeysEnabled(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_AreBrowserAcceleratorKeysEnabled(BOOL value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsPasswordAutosaveEnabled(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsPasswordAutosaveEnabled(BOOL value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsGeneralAutofillEnabled(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsGeneralAutofillEnabled(BOOL value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsPinchZoomEnabled(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsPinchZoomEnabled(BOOL value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsSwipeNavigationEnabled(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsSwipeNavigationEnabled(BOOL value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_HiddenPdfToolbarItems(COREWEBVIEW2_PDF_TOOLBAR_ITEMS *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_HiddenPdfToolbarItems(COREWEBVIEW2_PDF_TOOLBAR_ITEMS value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsReputationCheckingRequired(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsReputationCheckingRequired(BOOL value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_IsNonClientRegionSupportEnabled(BOOL *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE put_IsNonClientRegionSupportEnabled(BOOL value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2WebMessageReceivedEventArgs2 : public ICoreWebView2WebMessageReceivedEventArgs2 {
  HRESULT STDMETHODCALLTYPE get_Source(LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_WebMessageAsJson(LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE TryGetWebMessageAsString(LPWSTR *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE get_AdditionalObjects(ICoreWebView2ObjectCollectionView **value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2ObjectCollectionView : public ICoreWebView2ObjectCollectionView {
  HRESULT STDMETHODCALLTYPE get_Count(UINT32 *value) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE GetValueAtIndex(UINT32 index, IUnknown **value) override { return E_NOTIMPL; }
};
struct Stub_ICoreWebView2File : public ICoreWebView2File {
  HRESULT STDMETHODCALLTYPE get_Path(LPWSTR *value) override { return E_NOTIMPL; }
};
