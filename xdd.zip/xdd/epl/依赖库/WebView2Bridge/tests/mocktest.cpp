#include <windows.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <algorithm>
#include <thread>
#include <atomic>
#include "wv2bridge.h"
static HMODULE g_dll, g_mock;
static int g_pass, g_fail;
static void Check(bool c, const char* n, const std::string& got = "") { if (c) { ++g_pass; printf("PASS %s\n", n); } else { ++g_fail; printf("FAIL %s  [%s]\n", n, got.c_str()); } fflush(stdout); }
#define FN(name) static decltype(&name) p_##name;
#define LOAD(name) p_##name = reinterpret_cast<decltype(&name)>(reinterpret_cast<void*>(GetProcAddress(g_dll, #name)));
FN(WV_NavigateToString) FN(WV_SetOption) FN(WV_GetOption) FN(WV_JsonQuote) FN(WV_RuntimeCheck) FN(WV_CreateAsync) FN(WV_WaitReady) FN(WV_IsReady) FN(WV_Destroy) FN(WV_ExecScript) FN(WV_ExecScriptAsync)
FN(WV_EvGet) FN(WV_SetParent) FN(WV_CdpCall) FN(WV_ClearData) FN(WV_DownloadControl) FN(WV_AddMemoryFile) FN(WV_SetStr) FN(WV_GetStr) FN(WV_SetEvent) FN(WV_AddRequestFilter) FN(WV_SetCookie) FN(WV_SetCookieString) FN(WV_GetCookies) FN(WV_DeleteCookies) FN(WV_SetResponseCapture) FN(WV_EvGetData) FN(WV_MapFolder) FN(WV_CaptureToMemory) FN(WV_Free) FN(WV_Dom) FN(WV_Create) FN(WV_Input) FN(WV_Command) FN(WV_SetInt) FN(WV_GetInt) FN(WV_Show) FN(WV_SetBounds) FN(WV_AddInitScript) FN(WV_RemoveInitScript) FN(WV_PostMessage) FN(WV_Emit) FN(WV_NavigateEx) FN(WV_CdpSubscribe) FN(WV_PrintToPdf) FN(WV_Bind) FN(WV_GetDiagnostics) FN(WV_GetWindow) FN(WV_LastErrorCode) FN(WV_Navigate) FN(WV_EvSet) FN(WV_EvSetInt) FN(WV_EvGetInt) FN(WV_BindReturn) FN(WV_JsonGet) FN(WV_LastError)
typedef void(__stdcall* NoteFn)(const wchar_t*); typedef int(__stdcall* CountFn)(); typedef const wchar_t*(__stdcall* AtFn)(int);
typedef void(__stdcall* ReqFn)(const wchar_t*, int); static ReqFn pReq;
typedef void(__stdcall* IntFn)(int); static IntFn pFail, pFull;
typedef void(__stdcall* RespFn)(const wchar_t*, int, const char*); static RespFn pResp;
typedef void(__stdcall* DlFn)(const wchar_t*, int); static DlFn pDownload;
typedef void(__stdcall* DlgFn)(int, const wchar_t*, const wchar_t*); static DlgFn pDialog;
typedef void(__stdcall* KeyFn)(int, int); static KeyFn pKey; static IntFn pMenu; static NoteFn pAuth;
typedef void(__stdcall* CdpFn)(const wchar_t*, const wchar_t*); static CdpFn pCdpEvent; static IntFn pEnvLevel, pWvLevel, pFailEnv;
static NoteFn pNote, pSend, pNewWin, pPerm; static CountFn pCount; static AtFn pAt;
static std::vector<std::wstring> LogAll() { std::vector<std::wstring> v; int n = pCount(); for (int i = 0; i < n; ++i) v.push_back(pAt(i)); return v; }
static int Find(const std::wstring& s, int from = 0) { auto v = LogAll(); for (int i = from; i < (int)v.size(); ++i) if (v[i].find(s) != std::wstring::npos) return i; return -1; }
static int CountOf(const std::wstring& s) { int c = 0; for (auto& l : LogAll()) if (l.find(s) != std::wstring::npos) ++c; return c; }
static void Pump(DWORD ms) { DWORD t = GetTickCount(); MSG m; while (GetTickCount() - t < ms) { while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); } Sleep(2); } }
static bool PumpFor(const std::wstring& s, DWORD ms, int count = 1) { DWORD t = GetTickCount(); MSG m; while (GetTickCount() - t < ms) { while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); } if (CountOf(s) >= count) return true; Sleep(2); } return false; }
static std::string N(int i) { return std::to_string(i); }
template <class Pred> static bool PumpFor2(Pred done, DWORD ms) { DWORD t = GetTickCount(); MSG m; while (GetTickCount() - t < ms) { while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); } if (done()) return true; Sleep(2); } return done(); }
static int g_ready = 0, g_readyOk = -1, g_navStartErr = -1, g_navStartMs = -1, g_navStartCount = 0, g_navDoneErr = -1, g_laterId = 0, g_asyncOk = -1;
static std::string g_navDoneRes, g_addInner, g_nwInner, g_asyncRes, g_asyncInner;
static void __stdcall OnReady(int, int ok) { ++g_ready; g_readyOk = ok; }
static void __stdcall OnNavStarting(int h, const char* url, int, int, int* cancel) {
  pNote(L"cb-navstarting"); ++g_navStartCount;
  DWORD t = GetTickCount(); const char* r = p_WV_ExecScript(h, "1+2", 0, 3000); (void)r; g_navStartErr = p_WV_LastErrorCode(); g_navStartMs = (int)(GetTickCount() - t);
  if (strstr(url, "blocked")) *cancel = 1;
}
static void __stdcall OnNavDone(int h, const char*, int, int, int) { pNote(L"cb-navcompleted"); g_navDoneRes = p_WV_ExecScript(h, "6*7", 0, 3000); g_navDoneErr = p_WV_LastErrorCode(); }
static void __stdcall OnAdd(int h, const char*, const char* args, int) {
  pNote(L"cb-add"); int a = atoi(p_WV_JsonGet(args, "[0]")), b = atoi(p_WV_JsonGet(args, "[1]"));
  g_addInner = p_WV_ExecScript(h, "1+2", WVX_AWAIT, 3000);
  p_WV_EvSet(WVK_SET_RESULT, std::to_string(a + b).c_str());
}
static void __stdcall OnLater(int, const char*, const char*, int callId) { pNote(L"cb-later"); p_WV_EvSetInt(WVK_DEFER, 1); g_laterId = p_WV_EvGetInt(WVK_CALL_ID); (void)callId; }
static std::string g_anyName;
static void __stdcall OnAnyCall(int, const char* name, const char*, int) { g_anyName = name ? name : ""; p_WV_EvSet(WVK_SET_RESULT, "\"any\""); }
static void __stdcall OnNewWin(int h, const char*, int, int* action) { pNote(L"cb-newwindow"); g_nwInner = p_WV_ExecScript(h, "1+2", 0, 3000); *action = 2; }
// 1.7.0：按 WVE_FLAG_NO_OUT 注册的回调（没有最后的 int* 参数），用 WVK_CANCEL / WVK_RESULT 回填
static int g_noOutNav = 0;
static void __stdcall OnNavNoOut(int, const char* url, int, int) { ++g_noOutNav; if (strstr(url, "blocked")) p_WV_EvSetInt(WVK_CANCEL, 1); }
// 1.7.8：以前的写法（照旧写了最后的“参考”参数），按 WVE_FLAG_NO_OUT 注册后仍能回填
static void __stdcall OnNavLegacy5(int, const char* url, int, int, int* cancel) { if (strstr(url, "blocked-legacy")) *cancel = 1; }
static void __stdcall OnDialogNoOut(int, int kind, const char*, const char*) { if (kind == 1) p_WV_EvSetInt(WVK_CANCEL, 1); }
static void __stdcall OnPermNoOut(int, const char*, int) { p_WV_EvSetInt(WVK_CANCEL, 1); }
static void __stdcall OnNewWinDefault(int, const char*, int, int* action) { *action = 0; }  // WV新窗口_默认弹窗
static void __stdcall OnNewWinNoOut(int, const char*, int) {}
static int g_respStatus = 0, g_respLen = -1, g_dlProg = 0, g_dlLastPct = -1, g_dlDone = -1;
static std::string g_respMethod, g_respBody, g_dlStart, g_dlDonePath;
static void __stdcall OnResponse(int, const char*, int status, const char* method, int len) {
  pNote(L"cb-response"); g_respStatus = status; g_respMethod = method; g_respLen = len;
  void* d = nullptr; int n = 0; if (p_WV_EvGetData(WVK_BODY, &d, &n) == 1 && d) g_respBody.assign((const char*)d, n);
}
static void __stdcall OnDomReady(int, const char*) { pNote(L"cb-domready"); }
// ---- 文本统一为 UTF-8 时的回调转发（WVO_CALLBACK_HOOK）：记录 DLL 传来的事件号、参数个数、文本掩码与 UTF-8 文本，再调用原回调
struct HookRec { int ev, argc; unsigned mask; std::vector<std::string> texts; };
static std::vector<HookRec> g_hookLog;
static int __stdcall TestHook(void* fn, int ev, int argc, intptr_t* argv, unsigned mask) {
  HookRec r{ev, argc, mask, {}};
  for (int i = 0; i < argc && i < 16; ++i)
    if (mask & (1u << i)) r.texts.push_back(argv[i] ? (const char*)argv[i] : "");
  g_hookLog.push_back(r);
  switch (argc) {
    case 1: return ((int(__stdcall*)(intptr_t))fn)(argv[0]);
    case 2: return ((int(__stdcall*)(intptr_t, intptr_t))fn)(argv[0], argv[1]);
    case 3: return ((int(__stdcall*)(intptr_t, intptr_t, intptr_t))fn)(argv[0], argv[1], argv[2]);
    case 4: return ((int(__stdcall*)(intptr_t, intptr_t, intptr_t, intptr_t))fn)(argv[0], argv[1], argv[2], argv[3]);
    case 5: return ((int(__stdcall*)(intptr_t, intptr_t, intptr_t, intptr_t, intptr_t))fn)(argv[0], argv[1], argv[2], argv[3], argv[4]);
  }
  return 0;
}
static std::string g_u8DlgMsg, g_u8DlgUrl, g_u8CdpName, g_u8CdpParams, g_u8BindName, g_u8BindArgs;
static int __stdcall OnU8Dialog(int, int, const char* msg, const char* url, int* accept) { g_u8DlgMsg = msg ? msg : ""; g_u8DlgUrl = url ? url : ""; if (accept) *accept = 1; return 0; }
static int __stdcall OnU8Cdp(int, const char* name, const char* params) { g_u8CdpName = name ? name : ""; g_u8CdpParams = params ? params : ""; return 0; }
static int __stdcall OnU8Bind(int, const char* name, const char* args, int) {
  g_u8BindName = name ? name : ""; g_u8BindArgs = args ? args : "";
  p_WV_EvSet(WVK_SET_RESULT, "\"\xE5\xA5\xBD\"");  // "好"（UTF-8）
  return 0;
}
// JSON 转义方式 1 的期望：系统 ANSI 代码页表示得了的字符原样（UTF-8），否则写成 \uXXXX；代理对总是转义
static int g_evalOk = -1, g_evalUd = 0; static std::string g_evalRes;
static int __stdcall OnEvalAsync(int, int ud, int ok, const char* res) { g_evalUd = ud; g_evalOk = ok; g_evalRes = res ? res : ""; return 0; }
static std::string Hex(const std::string& b) { std::string o; char t[4]; for (unsigned char c : b) { sprintf(t, "%02X", c); o += t; } return o; }
static std::string Esc1(const std::wstring& w) {
  std::string o; char hx[8];
  for (size_t i = 0; i < w.size(); ++i) {
    wchar_t c = w[i];
    bool raw = c < 0x80;
    if (!raw && !(c >= 0xD800 && c <= 0xDFFF)) { char b[8]; BOOL used = FALSE; int n = WideCharToMultiByte(CP_ACP, WC_NO_BEST_FIT_CHARS, &c, 1, b, 8, nullptr, &used); raw = n > 0 && !used; if (GetACP() == CP_UTF8) raw = true; }
    if (raw) { char u[8]; int n = WideCharToMultiByte(CP_UTF8, 0, &c, 1, u, 8, nullptr, nullptr); o.append(u, (size_t)n); }
    else { sprintf(hx, "\\u%04x", (unsigned)c); o += hx; }
  }
  return o;
}

static void __stdcall OnDialog(int, int kind, const char*, const char*, int* accept) { pNote(L"cb-dialog"); if (kind == 2) p_WV_EvSet(WVK_SET_TEXT, "answer"); *accept = 1; }
static void __stdcall OnDlStart(int, int, const char*, const char* path, int*) { pNote(L"cb-dlstart"); g_dlStart = path; }
static int g_dlId = 0;
static void __stdcall OnDlStartId(int, int did, const char*, const char*, int*) { g_dlId = did; }
static std::string g_dlSaveTo;  // 1.7.5：下载开始时用 WVK_SET_PATH 把文件放到这里
static void __stdcall OnDlStartSaveTo(int, int, const char*, const char*, int*) { pNote(L"cb-dlsaveto"); p_WV_EvSet(WVK_SET_PATH, g_dlSaveTo.c_str()); }
struct OtherWin { HWND w = nullptr; HANDLE ready = nullptr; };
static DWORD WINAPI OtherWinThread(LPVOID p) {  // 另一个线程上的窗口：置父窗口不能用它
  auto* o = static_cast<OtherWin*>(p);
  o->w = CreateWindowExW(0, L"STATIC", L"other", WS_OVERLAPPEDWINDOW, 0, 0, 100, 100, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
  SetEvent(o->ready);
  MSG m;
  while (GetMessageW(&m, nullptr, 0, 0) > 0) DispatchMessageW(&m);
  if (o->w) DestroyWindow(o->w);
  return 0;
}
static void __stdcall OnDlProg(int, int, int pct, int, int) { ++g_dlProg; g_dlLastPct = pct; }
static void __stdcall OnDlDone(int, int, int result, const char* path) { pNote(L"cb-dldone"); g_dlDone = result; g_dlDonePath = path; }
static int g_keyErr = -1, g_target = 0; static HWND g_parent; static std::string g_cdpName, g_cdpParams;
static void __stdcall OnEcho(int, const char*, const char* args, int) { p_WV_EvSet(WVK_SET_RESULT, p_WV_JsonGet(args, "[0]")); }
// 1.8.2：收到网页消息回调——记下文本与附带文件路径（WVK_FILES）
static std::string g_msgJson, g_msgFiles; static int g_msgCount;
static void __stdcall OnMsg(int, const char*, const char* json, const char*) {
  ++g_msgCount; g_msgJson = json ? json : "";  // 文本参数在模拟里为空（TryGetWebMessageAsString 返回 null），用 JSON 辨识消息
  const char* f = p_WV_EvGet(WVK_FILES); g_msgFiles = f ? f : "";
}
// 1.8.2：WVX_POST 顺序——每条投递的脚本把自己的序号追加到日志
static std::atomic<int> g_postThreadReturned{0};
static void __stdcall OnCdpEvent(int, const char* n, const char* j) { pNote(L"cb-cdp"); g_cdpName = n; g_cdpParams = j; }
static void __stdcall OnKeyCb(int h, int vk, int, int, int* handled) { if (vk == 118) { p_WV_ExecScript(h, "1+2", 0, 1000); g_keyErr = p_WV_LastErrorCode(); *handled = 1; } }
static void __stdcall OnAuth(int, const char*, const char*, int*) { pNote(L"cb-auth"); p_WV_EvSet(WVK_SET_USERNAME, "u"); p_WV_EvSet(WVK_SET_PASSWORD, "p"); }
static void __stdcall OnNewWinTarget(int, const char*, int, int*) { pNote(L"cb-nw-target"); g_target = p_WV_CreateAsync(g_parent, 0, 0, 0, 0, "", "", nullptr); p_WV_EvSetInt(WVK_TARGET_VIEW, g_target); }
static std::string g_reqInner; static int g_pf = 0, g_nwDestroy = -1;
static void __stdcall OnProcFail(int, int, int) { pNote(L"cb-processfailed"); ++g_pf; }
static void __stdcall OnNewWinDestroy(int h, const char*, int, int*) { pNote(L"cb-nw-destroy"); g_nwDestroy = p_WV_Destroy(h); }
static void __stdcall OnRequest(int h, const char*, const char*, int, int*) { pNote(L"cb-request"); p_WV_EvSet(WVK_SET_HEADER, "X-Test: 1"); g_reqInner = p_WV_ExecScript(h, "1+2", 0, 3000); }
static void __stdcall OnPerm(int, const char*, int, int* state) { pNote(L"cb-permission"); *state = 1; }
static void __stdcall OnAsync(int h, int, int ok, const char* r) { pNote(L"cb-async"); g_asyncOk = ok; g_asyncRes = r; g_asyncInner = p_WV_ExecScript(h, "1+2", 0, 3000); }
static std::wstring ExeDir() { wchar_t b[MAX_PATH]; GetModuleFileNameW(nullptr, b, MAX_PATH); std::wstring s(b); return s.substr(0, s.find_last_of(L"\\/")); }
static std::string A(const std::wstring& w) { std::string s; for (wchar_t c : w) s += c < 128 ? (char)c : '?'; return s; }
// 统计目录里旧版 加载HTML 写过的临时页面（wv2_page_*.html）；sub 为真时连同子目录
static int CountPageFiles(const std::wstring& dir, bool sub) {
  int c = 0; WIN32_FIND_DATAW fd; std::wstring d = dir; if (!d.empty() && d.back() == L'\\') d.pop_back();
  HANDLE fh = FindFirstFileW((d + L"\\*").c_str(), &fd);
  if (fh == INVALID_HANDLE_VALUE) return 0;
  do {
    std::wstring n = fd.cFileName;
    if (n == L"." || n == L"..") continue;
    if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) { if (sub) c += CountPageFiles(d + L"\\" + n, true); }
    else if (n.compare(0, 9, L"wv2_page_") == 0) ++c;
  } while (FindNextFileW(fh, &fd));
  FindClose(fh);
  return c;
}
// ---- 1.5.0：同步等待嵌套上限与跨线程转交
typedef void(__stdcall* HoldFn15)(int);
static HoldFn15 g_hold15;
static int g_reH, g_reDepth, g_reMax, g_reRefused, g_reOk;
static bool g_reStop;
static UINT_PTR g_reTick;
static void CALLBACK ReTick(HWND, UINT, UINT_PTR, DWORD) {  // 计时器回调里调用需要等待的方法：等待期间计时器再次触发，一层套一层
  if (g_reStop) return;
  if (++g_reDepth > g_reMax) g_reMax = g_reDepth;
  const char* r = p_WV_AddInitScript(g_reH, "window.re=1");
  if (r && *r) ++g_reOk;
  else if (p_WV_LastErrorCode() == WVERR_REENTRANT) ++g_reRefused;
  --g_reDepth;
}
static void CALLBACK ReRelease(HWND, UINT, UINT_PTR id, DWORD) {
  KillTimer(nullptr, id);
  KillTimer(nullptr, g_reTick);
  g_reStop = true;
  if (g_hold15) g_hold15(0);
}
static std::string g_hoId;
static int g_hoErr = -1;
static DWORD g_hoMs;
static DWORD WINAPI HoWorker(LPVOID) {
  const DWORD t = GetTickCount();
  const char* r = p_WV_AddInitScript(g_reH, "window.slow=1");
  g_hoId = r ? r : "";
  g_hoErr = p_WV_LastErrorCode();
  g_hoMs = GetTickCount() - t;
  return 0;
}
static void CALLBACK HoRelease(HWND, UINT, UINT_PTR id, DWORD) {
  KillTimer(nullptr, id);
  if (g_hold15) g_hold15(0);
}

// 1.8.0 起查找运行时还要看浏览器进程、它启动时载入的两个 DLL（开头是 MZ）与 ICU 数据文件（开头 4 字节是 ICU 数据头）
static void MockRtFiles(const std::wstring& d) {
  static const unsigned char icu[16] = {0x90, 0x00, 0xDA, 0x27};
  const struct { const wchar_t* name; const void* data; DWORD n; } files[] = {
      {L"\\msedgewebview2.exe", "MZ", 2}, {L"\\msedge_elf.dll", "MZ", 2}, {L"\\msedge.dll", "MZ", 2}, {L"\\icudtl.dat", icu, sizeof(icu)}};
  for (const auto& f : files) {
    HANDLE h = CreateFileW((d + f.name).c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
    if (h == INVALID_HANDLE_VALUE) continue;
    DWORD w = 0;
    WriteFile(h, f.data, f.n, &w, nullptr);
    CloseHandle(h);
  }
}

int main() {
  std::wstring app = ExeDir() + L"\\mockapp", rt = app + L"\\WebView2\\Microsoft.WebView2.FixedVersionRuntime.120.0.0.1.x86";
  for (auto d : {app, app + L"\\WebView2", rt, rt + L"\\EBWebView", rt + L"\\EBWebView\\x86"}) CreateDirectoryW(d.c_str(), nullptr);
  CopyFileW((ExeDir() + L"\\mockwv.dll").c_str(), (rt + L"\\EBWebView\\x86\\EmbeddedBrowserWebView.dll").c_str(), FALSE);
  MockRtFiles(rt);
  g_dll = LoadLibraryW(L"WebView2Bridge.dll");
  LOAD(WV_NavigateToString) LOAD(WV_SetOption) LOAD(WV_GetOption) LOAD(WV_JsonQuote) LOAD(WV_RuntimeCheck) LOAD(WV_CreateAsync) LOAD(WV_WaitReady) LOAD(WV_IsReady) LOAD(WV_Destroy) LOAD(WV_ExecScript) LOAD(WV_ExecScriptAsync)
  LOAD(WV_EvGet) LOAD(WV_SetParent) LOAD(WV_CdpCall) LOAD(WV_ClearData) LOAD(WV_DownloadControl) LOAD(WV_AddMemoryFile) LOAD(WV_SetStr) LOAD(WV_GetStr) LOAD(WV_SetEvent) LOAD(WV_AddRequestFilter) LOAD(WV_SetCookie) LOAD(WV_SetCookieString) LOAD(WV_GetCookies) LOAD(WV_DeleteCookies) LOAD(WV_SetResponseCapture) LOAD(WV_EvGetData) LOAD(WV_MapFolder) LOAD(WV_CaptureToMemory) LOAD(WV_Free) LOAD(WV_Dom) LOAD(WV_Create) LOAD(WV_Input) LOAD(WV_Command) LOAD(WV_SetInt) LOAD(WV_GetInt) LOAD(WV_Show) LOAD(WV_SetBounds) LOAD(WV_AddInitScript) LOAD(WV_RemoveInitScript) LOAD(WV_PostMessage) LOAD(WV_Emit) LOAD(WV_NavigateEx) LOAD(WV_CdpSubscribe) LOAD(WV_PrintToPdf) LOAD(WV_Bind) LOAD(WV_GetDiagnostics) LOAD(WV_GetWindow) LOAD(WV_LastErrorCode) LOAD(WV_Navigate) LOAD(WV_EvSet) LOAD(WV_EvSetInt) LOAD(WV_EvGetInt) LOAD(WV_BindReturn) LOAD(WV_JsonGet) LOAD(WV_LastError)
  std::string appA = A(app);
  std::string rtA = A(rt), logA = A(ExeDir() + L"\\wv.log"); DeleteFileW((ExeDir() + L"\\wv.log").c_str());
  // 显式指定运行时目录：在装有常青版的真实 Windows 上运行时也只用模拟运行时
  p_WV_SetOption(WVO_APP_DIR, appA.c_str()); p_WV_SetOption(WVO_RUNTIME_DIR, rtA.c_str());
  p_WV_SetOption(WVO_LOG_FILE, logA.c_str());
  p_WV_SetOption(WVO_BROWSER_ARGS, "--mock-flag"); p_WV_SetOption(WVO_LANGUAGE, "zh-CN");
  Check(p_WV_RuntimeCheck(1) == 1, "mock runtime found by scan");
  WNDCLASSW wc = {}; wc.lpfnWndProc = DefWindowProcW; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"MockParent"; RegisterClassW(&wc);
  HWND parent = CreateWindowExW(0, L"MockParent", L"p", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 640, 480, nullptr, nullptr, wc.hInstance, nullptr);
  g_parent = parent;
  char opts[512];
  sprintf(opts, "bind:add=%d\r\nbind:later=%d\r\nev%d=%d\r\nev%d=%d\r\nev%d=%d\r\nev%d=%d", (int)(intptr_t)OnAdd, (int)(intptr_t)OnLater, WVE_NAV_STARTING, (int)(intptr_t)OnNavStarting,
          WVE_NAV_COMPLETED, (int)(intptr_t)OnNavDone, WVE_NEW_WINDOW, (int)(intptr_t)OnNewWin, WVE_PERMISSION, (int)(intptr_t)OnPerm);
  int h = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://a.test/", opts, (void*)OnReady);
  int w = p_WV_WaitReady(h, 5000);
  Check(h > 0 && w == 1, "create with mock runtime and wait ready", N(h) + "/" + N(w) + " " + p_WV_LastError());
  g_mock = GetModuleHandleW(L"EmbeddedBrowserWebView.dll");
  pNote = (NoteFn)(void*)GetProcAddress(g_mock, "Mock_Note"); pSend = (NoteFn)(void*)GetProcAddress(g_mock, "Mock_SendWebMessage");
  pNewWin = (NoteFn)(void*)GetProcAddress(g_mock, "Mock_NewWindow"); pPerm = (NoteFn)(void*)GetProcAddress(g_mock, "Mock_Permission");
  pReq = (ReqFn)(void*)GetProcAddress(g_mock, "Mock_Request"); pFail = (IntFn)(void*)GetProcAddress(g_mock, "Mock_ProcessFailed"); pFull = (IntFn)(void*)GetProcAddress(g_mock, "Mock_Fullscreen");
  pResp = (RespFn)(void*)GetProcAddress(g_mock, "Mock_Response"); pDownload = (DlFn)(void*)GetProcAddress(g_mock, "Mock_Download"); pDialog = (DlgFn)(void*)GetProcAddress(g_mock, "Mock_Dialog");
  pKey = (KeyFn)(void*)GetProcAddress(g_mock, "Mock_Key"); pMenu = (IntFn)(void*)GetProcAddress(g_mock, "Mock_Menu"); pAuth = (NoteFn)(void*)GetProcAddress(g_mock, "Mock_Auth"); pCdpEvent = (CdpFn)(void*)GetProcAddress(g_mock, "Mock_CdpEvent"); pEnvLevel = (IntFn)(void*)GetProcAddress(g_mock, "Mock_SetEnvLevel"); pWvLevel = (IntFn)(void*)GetProcAddress(g_mock, "Mock_SetWvLevel"); pFailEnv = (IntFn)(void*)GetProcAddress(g_mock, "Mock_FailNextEnv"); pCount = (CountFn)(void*)GetProcAddress(g_mock, "Mock_LogCount"); pAt = (AtFn)(void*)GetProcAddress(g_mock, "Mock_LogAt");
  if (!pCount) { printf("mock not loaded\n"); return 2; }
  Check(PumpFor(L"Committed:https://a.test/", 3000), "initial navigation committed");
  Pump(100);
  Check(g_ready == 1 && g_readyOk == 1, "READY(1) delivered once", N(g_ready) + "/" + N(g_readyOk));
  int iAdd = Find(L"AddScript"), iNav = Find(L"Navigate:https://a.test/");
  Check(iAdd >= 0 && iNav > iAdd, "bridge script registered before first navigation", N(iAdd) + " < " + N(iNav));
  Check(Find(L"Opt.Args=") >= 0 && LogAll()[Find(L"Opt.Args=")].find(L"--mock-flag") != std::wstring::npos, "env options: browser args read through vtable");
  Check(Find(L"Opt.Lang=zh-CN") >= 0 && Find(L"Opt.Target=120.0.0.1") >= 0, "env options: language and target version");
  Check(Find(L"Opt2.Exclusive=") >= 0 && Find(L"Opt3.Crash=") >= 0 && Find(L"Opt5.Tracking=") >= 0 && Find(L"Opt6.Ext=") >= 0 && Find(L"Opt8.Scroll=") >= 0,
        "env options 2/3/5/6/8 answered via correct interfaces");
  Check(Find(L"Opt4=none") >= 0, "unimplemented options interface refused (E_NOINTERFACE)");
  { int s1 = Find(L"Raise:NavStarting:https://a.test/"), s2 = Find(L"Raised:NavStarting:https://a.test/"), bad = 0; auto v = LogAll();
    for (int k = s1; k >= 0 && k < s2; ++k) if (v[k].find(L"ExecuteScript:1+2") != std::wstring::npos) ++bad;
    Check(s1 >= 0 && s2 > s1 && bad == 0, "rejected sync call inside NavigationStarting does not reach WebView2 (no side effect)", N(bad)); }
  Check(g_navStartErr == WVERR_REENTRANT && g_navStartMs < 500, "sync call inside NavigationStarting fails fast with REENTRANT", N(g_navStartErr) + " " + N(g_navStartMs) + "ms");
  Check(g_navDoneRes == "42" && g_navDoneErr == 0, "sync ExecuteScript inside posted NavigationCompleted callback works", g_navDoneRes);
  int iRaised = Find(L"Raised:NavCompleted:https://a.test/"), iCb = Find(L"Note:cb-navcompleted");
  Check(iRaised >= 0 && iCb > iRaised, "NavigationCompleted callback runs after the WebView2 handler returned", N(iRaised) + " < " + N(iCb));
  p_WV_Navigate(h, "https://blocked.test/");
  Check(PumpFor(L"Cancelled:https://blocked.test/", 3000), "navigation cancelled from NavigationStarting callback");
  std::string r = p_WV_ExecScript(h, "1+2", WVX_AWAIT, 3000);
  Check(r == "3", "ExecScript with await (DevTools path) from UI thread", r);
  {  // 等待 Promise（WVX_AWAIT）。真实 Chromium 的 REPL 模式不等待表达式得到的 Promise，按值取回只得到 {}（实机报告里三项失败的原因）
    int rel0 = 0; for (auto& x : LogAll()) rel0 += x.find(L"CDP.Release:") == 0;
    std::string p1 = p_WV_ExecScript(h, "new Promise(r=>setTimeout(()=>r(42),50))", WVX_AWAIT | WVX_UNWRAP, 3000);
    Check(p1 == "42", "awaited Promise: an expression whose value is a Promise returns the resolved value", p1 + " | " + p_WV_LastError());
    std::string p2 = p_WV_ExecScript(h, "await new Promise(r=>setTimeout(()=>r(7),10))", WVX_AWAIT | WVX_UNWRAP, 3000);
    Check(p2 == "7", "top-level await still works", p2 + " | " + p_WV_LastError());
    std::string p3 = p_WV_ExecScript(h, "[2,4,6]", WVX_AWAIT, 3000);
    Check(p3 == "[2,4,6]", "object result is fetched by value", p3 + " | " + p_WV_LastError());
    std::string p4 = p_WV_ExecScript(h, "Promise.reject(new Error('boom'))", WVX_AWAIT, 3000); int e4 = p_WV_LastErrorCode(); std::string m4 = p_WV_LastError();
    Check(p4.empty() && e4 == WVERR_SCRIPT && m4.find("boom") != std::string::npos, "rejected Promise is reported as a script error", N(e4) + " " + m4);
    std::string p5 = p_WV_ExecScript(h, "throw new Error('sync')", WVX_AWAIT, 3000); int e5 = p_WV_LastErrorCode();
    Check(p5.empty() && e5 == WVERR_SCRIPT, "synchronous exception is reported as a script error", N(e5));
    std::vector<std::wstring> groups; for (auto& x : LogAll()) if (x.find(L"CDP.Release:") == 0) groups.push_back(x.substr(12));
    bool unique = true; for (size_t i = 0; i < groups.size(); ++i) for (size_t j = i + 1; j < groups.size(); ++j) if (groups[i] == groups[j]) unique = false;
    Check((int)groups.size() - rel0 >= 3 && unique, "remote objects are released, each evaluation in its own object group", N((int)groups.size() - rel0));
    g_evalOk = -1; g_evalRes.clear();
    Check(p_WV_ExecScriptAsync(h, "new Promise(r=>setTimeout(()=>r(42),50))", WVX_AWAIT | WVX_UNWRAP, (void*)OnEvalAsync, 77) == 1, "async await accepted");
    for (DWORD t0 = GetTickCount(); g_evalOk < 0 && GetTickCount() - t0 < 3000;) Pump(10);
    Check(g_evalOk == 1 && g_evalRes == "42" && g_evalUd == 77, "async await delivers the resolved value", N(g_evalOk) + " " + g_evalRes);
    g_evalOk = -1; g_evalRes.clear();
    p_WV_ExecScriptAsync(h, "Promise.reject(new Error('boom'))", WVX_AWAIT, (void*)OnEvalAsync, 78);
    for (DWORD t0 = GetTickCount(); g_evalOk < 0 && GetTickCount() - t0 < 3000;) Pump(10);
    Check(g_evalOk == 0 && g_evalRes.find("boom") != std::string::npos && !g_evalRes.empty() && g_evalRes[0] != '{', "async failure delivers a readable error, not raw protocol JSON", g_asyncRes);
  }
  pSend(L"{\"__epl\":1,\"t\":\"c\",\"id\":7,\"n\":\"add\",\"a\":[2,3]}");
  Check(PumpFor(L"PostJson:{\"__epl\":1,\"t\":\"r\",\"id\":7", 3000), "bridge call answered");
  int iReply = Find(L"\"id\":7"); std::wstring reply = iReply >= 0 ? LogAll()[iReply] : L"";
  Check(reply.find(L"\"ok\":true") != std::wstring::npos && reply.find(L"\"v\":5") != std::wstring::npos, "bridge result 2+3=5", A(reply));
  Check(Find(L"Note:cb-add") > Find(L"Raised:WebMessage"), "bridge callback runs after WebMessageReceived handler returned");
  Check(g_addInner == "3", "sync DevTools call inside bridge callback works", g_addInner);
  pSend(L"{\"__epl\":1,\"t\":\"c\",\"id\":8,\"n\":\"nope\",\"a\":[]}");
  Check(PumpFor(L"\"id\":8", 3000) && LogAll()[Find(L"\"id\":8")].find(L"\"ok\":false") != std::wstring::npos, "unbound function rejected");
  pSend(L"{\"__epl\":1,\"t\":\"c\",\"id\":9,\"n\":\"later\",\"a\":[]}");
  PumpFor(L"Note:cb-later", 3000); Pump(150);
  Check(g_laterId > 0 && Find(L"\"id\":9") < 0, "deferred reply not sent yet", N(g_laterId));
  p_WV_BindReturn(h, g_laterId, "\"done\"", 0);
  Check(PumpFor(L"\"id\":9", 2000) && LogAll()[Find(L"\"id\":9")].find(L"\"v\":\"done\"") != std::wstring::npos, "deferred reply delivered by BindReturn");
  // ---- 1.8.2：WVK_FILES（postMessageWithAdditionalObjects 附带的文件路径）
  {
    typedef void(__stdcall* SendFilesFn)(const wchar_t*, const wchar_t*, int);
    SendFilesFn pSendFiles = (SendFilesFn)(void*)GetProcAddress(g_mock, "Mock_SendWebMessageFiles");
    Check(pSendFiles != nullptr, "1.8.2: mock exports Mock_SendWebMessageFiles");
    p_WV_SetEvent(h, WVE_MESSAGE, (void*)OnMsg);
    // 消息经 Post 投递到界面线程处理，逐条发、逐条等它处理完（按本条的 JSON 辨识），避免互相覆盖
    auto sendWait = [&](const wchar_t* json, const wchar_t* files, int haveColl, const char* wantJson) -> bool {
      g_msgJson.clear(); g_msgFiles = "\x01";
      pSendFiles(json, files, haveColl);
      return PumpFor2([&]{ return g_msgJson == wantJson; }, 3000);
    };
    // 内核支持附带对象（haveColl=1）：两个文件路径按行取回，中间夹一个 null 项不产生空行
    bool got = sendWait(L"\"drop\"", L"C:\\a\\one.wav|<null>|C:\\b\\two.mp3", 1, "\"drop\"");
    Check(got && g_msgFiles == "C:\\a\\one.wav\nC:\\b\\two.mp3",
          "1.8.2: dropped file paths arrive via WVK_FILES, one per line, null entries skipped", "len=" + N((int)g_msgFiles.size()) + " [" + g_msgFiles + "]");
    // 没有附带文件：WVK_FILES 取到空
    got = sendWait(L"\"plain\"", L"", 1, "\"plain\"");
    Check(got && g_msgFiles.empty(), "1.8.2: a message without files reads an empty WVK_FILES", g_msgFiles);
    // 内核太老（haveColl=0，args2 不可用）：不崩溃，照常收到消息，文件为空
    got = sendWait(L"\"old\"", L"C:\\a\\one.wav", 0, "\"old\"");
    Check(got && g_msgFiles.empty(), "1.8.2: on a runtime without args2 the message still arrives and WVK_FILES is empty", g_msgFiles);
    p_WV_SetEvent(h, WVE_MESSAGE, nullptr);
  }
  // ---- 1.8.2：WVX_POST（从工作线程投递脚本，立即返回、按顺序执行，界面线程不卡死）
  {
    const int before = CountOf(L"ExecuteScript:");
    // 工作线程：界面线程此刻不处理消息（下面才 Pump），投递仍要立即返回
    g_postThreadReturned = 0;
    std::thread th([&] {
      for (int i = 1; i <= 3; ++i) {
        wchar_t js[64]; wsprintfW(js, L"post-%d", i);
        char u[64]; wsprintfA(u, "post-%d", i);
        p_WV_ExecScriptAsync(h, u, WVX_POST, nullptr, 0);
      }
      g_postThreadReturned = 1;
    });
    th.join();
    Check(g_postThreadReturned == 1, "1.8.2: WVX_POST returns from the worker thread while the UI thread is not pumping messages");
    // 现在处理消息：三条脚本应按投递顺序到达内核
    Check(PumpFor(L"ExecuteScript:post-3", 3000), "1.8.2: posted scripts run after the UI thread resumes pumping");
    const int i1 = Find(L"ExecuteScript:post-1"), i2 = Find(L"ExecuteScript:post-2"), i3 = Find(L"ExecuteScript:post-3");
    Check(i1 >= 0 && i1 < i2 && i2 < i3, "1.8.2: posted scripts execute in the order they were posted", N(i1) + "," + N(i2) + "," + N(i3));
    (void)before;
  }
  {  // JS 桥白名单：只放行白名单内的来源；按前缀放行时必须结束在路径边界上
    typedef void(__stdcall* SendFromFn)(const wchar_t*, const wchar_t*);
    SendFromFn pSendFrom = (SendFromFn)(void*)GetProcAddress(g_mock, "Mock_SendWebMessageFrom");
    p_WV_SetStr(h, WVS_BRIDGE_ORIGINS, "https://a.test; https://*.trusted.test; https://app.test/admin");
    auto call = [&](const wchar_t* src, int id) -> std::wstring {
      wchar_t b[128], key[32];
      swprintf(b, 128, L"{\"__epl\":1,\"t\":\"c\",\"id\":%d,\"n\":\"add\",\"a\":[1,1]}", id);
      swprintf(key, 32, L"\"id\":%d,", id);
      pSendFrom(src, b);
      PumpFor(key, 3000);
      int i = Find(key);
      return i >= 0 ? LogAll()[i] : std::wstring(L"(无回传)");
    };
    auto ok = [](const std::wstring& r) { return r.find(L"\"ok\":true") != std::wstring::npos; };
    auto rejected = [](const std::wstring& r) { return r.find(L"\"ok\":false") != std::wstring::npos; };
    std::wstring r1 = call(L"https://a.test/page?x=1", 501), r2 = call(L"https://a.test.evil.com/", 502), r3 = call(L"https://a.test:8443/", 503);
    std::wstring r4 = call(L"https://x.trusted.test/p", 504), r5 = call(L"https://trusted.test.evil.com/", 505);
    std::wstring r6 = call(L"https://app.test/admin/users", 506), r7 = call(L"https://app.test/administrator", 507);
    Check(ok(r1), "bridge whitelist: listed origin allowed", A(r1));
    Check(rejected(r2), "bridge whitelist: look-alike host that merely starts with a listed origin is rejected", A(r2));
    Check(rejected(r3), "bridge whitelist: same host on another port is rejected", A(r3));
    Check(ok(r4) && rejected(r5), "bridge whitelist: wildcard subdomain allowed, look-alike rejected", A(r5));
    Check(ok(r6) && rejected(r7), "bridge whitelist: path prefix allowed only at a path boundary", A(r7));
    // 通配符只能作用在来源（协议+主机+端口）上，不能越过主机去匹配路径或查询参数；网址里 @ 前面的用户名部分也不能冒充主机
    std::wstring r8 = call(L"https://attacker.test/?.trusted.test", 508), r9 = call(L"https://attacker.test/x.trusted.test", 509);
    std::wstring r10 = call(L"https://x.trusted.test@attacker.test/", 510);
    Check(rejected(r8) && rejected(r9), "bridge whitelist: wildcard cannot reach into the path or query of another site", A(r8) + " / " + A(r9));
    Check(rejected(r10), "bridge whitelist: user-info before @ cannot pose as the host", A(r10));
    p_WV_SetStr(h, WVS_BRIDGE_ORIGINS, "https://app.test/admin/*");
    std::wstring r11 = call(L"https://app.test/admin/users", 511), r12 = call(L"https://evil.test/https://app.test/admin/users", 512);
    Check(ok(r11) && rejected(r12), "bridge whitelist: wildcard path rule matches the path of the same site only", A(r12));
    p_WV_SetStr(h, WVS_BRIDGE_ORIGINS, "");
  }
  {  // 1.4.0：未设白名单时只放行本程序自己的内容（本地文件、映射目录的主机、.example/.test/.invalid 主机下的 https 页面），真实网站要列进白名单，* 放行全部
    typedef void(__stdcall* SendFromFn)(const wchar_t*, const wchar_t*);
    SendFromFn pSendFrom = (SendFromFn)(void*)GetProcAddress(g_mock, "Mock_SendWebMessageFrom");
    auto call = [&](const wchar_t* src, int id) -> std::wstring {
      wchar_t b[128], key[32];
      swprintf(b, 128, L"{\"__epl\":1,\"t\":\"c\",\"id\":%d,\"n\":\"add\",\"a\":[1,1]}", id);
      swprintf(key, 32, L"\"id\":%d,", id);
      pSendFrom(src, b);
      PumpFor(key, 3000);
      int i = Find(key);
      return i >= 0 ? LogAll()[i] : std::wstring(L"(无回传)");
    };
    auto ok = [](const std::wstring& r) { return r.find(L"\"ok\":true") != std::wstring::npos; };
    auto rejected = [](const std::wstring& r) { return r.find(L"\"ok\":false") != std::wstring::npos; };
    p_WV_SetStr(h, WVS_BRIDGE_ORIGINS, "");
    std::wstring appUrl = L"file:///";  // 程序目录（mockapp）里的本地页面
    for (wchar_t c : app) appUrl += c == L'\\' ? std::wstring(L"/") : c == L' ' ? std::wstring(L"%20") : std::wstring(1, c);
    appUrl += L"/ui/index.html";
    std::wstring d1 = call(L"https://app.example/index.html", 521), d2 = call(appUrl.c_str(), 522), d3 = call(L"https://www.baidu.com/s?wd=1", 523);
    std::wstring d4 = call(L"http://app.example/", 524), d5 = call(L"https://x.test@evil.com/", 525);
    Check(ok(d1) && ok(d2), "bridge default: own content (reserved .example host, local file in the program folder) is allowed without a whitelist", A(d1) + " / " + A(d2));
    std::wstring d2b = call(L"file:///C:/Users/u/Downloads/evil.html", 530), d2c = call(L"file://attacker/share/a.html", 531);
    // 1.7.4：用户数据目录默认在程序目录里（mockapp\WebView2Data），里面的文件是浏览器替网页写的，不算本程序的内容
    const std::string udf = p_WV_GetStr(h, WVS_USER_DATA_DIR);
    std::wstring udfUrl = L"file:///";
    for (char c : udf) udfUrl += c == '\\' ? std::wstring(L"/") : c == ' ' ? std::wstring(L"%20") : std::wstring(1, (wchar_t)(unsigned char)c);
    udfUrl += L"/EBWebView/x.html";
    const bool udfInApp = _strnicmp(udf.c_str(), appA.c_str(), appA.size()) == 0;
    std::wstring d2d = call(udfUrl.c_str(), 532);
    Check(udfInApp && rejected(d2d), "bridge default: pages inside the user data folder (inside the program folder by default) are rejected", udf + " " + A(d2d));
    // 1.7.7：网页收到的拒绝说明写明原因，但不含本地路径（程序目录、用户数据目录）
    // 路径在 JSON 里反斜杠会被转义，所以按程序目录的文件夹名（不含反斜杠）查：网页收到的说明里不应出现它
    const std::string leafA = appA.substr(appA.find_last_of('\\') + 1);
    const std::wstring leaf(leafA.begin(), leafA.end());
    Check(!leaf.empty() && d2d.find(L"用户数据目录或下载目录") != std::wstring::npos && d2b.find(L"不在程序目录里") != std::wstring::npos &&
              d2d.find(leaf) == std::wstring::npos && d2b.find(leaf) == std::wstring::npos,
          "bridge rejection sent to the page names the reason without revealing local folders", A(d2d));
    const std::string dl = appA + "\\down";
    p_WV_SetStr(h, WVS_DOWNLOAD_DIR, dl.c_str());
    std::wstring dlUrl = L"file:///";
    for (char c : dl) dlUrl += c == '\\' ? std::wstring(L"/") : c == ' ' ? std::wstring(L"%20") : std::wstring(1, (wchar_t)(unsigned char)c);
    std::wstring d2e = call((dlUrl + L"/saved.html").c_str(), 533), d2f = call(appUrl.c_str(), 534);
    p_WV_SetStr(h, WVS_DOWNLOAD_DIR, "");
    Check(rejected(d2e) && ok(d2f), "bridge default: a download folder set inside the program folder is not own content; the program pages still are", A(d2e));
    // 1.7.9：发送事件 被拒时，给程序的错误说明写明具体原因与路径（变异测试发现去掉原因也测不出来）
    p_WV_Navigate(h, "file:///C:/Users/u/Downloads/evil.html");
    PumpFor(L"Committed:file:///C:/Users/u/Downloads/evil.html", 3000);
    const int emitted = p_WV_Emit(h, "t", "1");
    const int emitErr = p_WV_LastErrorCode();
    const std::string emitMsg = p_WV_LastError();
    // 程序目录按文件夹名查：说明里的路径已规整成完整路径，写法可能与 appA 不完全相同。错误说明按 DLL 当前的文本编码给出
    // （这里是系统 ANSI 代码页；A () 只保留 ASCII，不能用来转中文）
    char reasonAcp[64] = {0};
    WideCharToMultiByte(CP_ACP, 0, L"不在程序目录", -1, reasonAcp, (int)sizeof(reasonAcp), nullptr, nullptr);
    const bool reasonShown = reasonAcp[0] && emitMsg.find(reasonAcp) != std::string::npos;
    Check(emitted == 0 && emitErr == WVERR_DENIED && reasonShown && emitMsg.find("Downloads") != std::string::npos &&
              emitMsg.find("\\mockapp") != std::string::npos,
          "Emit to a local page outside the program folder is refused, and the error names the reason and the folders",
          N(emitted) + "/" + N(emitErr) + "/" + N(reasonShown) + " " + emitMsg);
    p_WV_Navigate(h, "https://a.test/");
    PumpFor(L"Committed:https://a.test/", 3000, CountOf(L"Committed:https://a.test/") + 1);
    Check(rejected(d2b) && rejected(d2c), "bridge default: local files outside the program folder (dropped, downloaded, on a network share) are rejected", A(d2b) + " / " + A(d2c));
    Check(rejected(d3) && rejected(d5), "bridge default: real websites are rejected until listed", A(d3));
    Check(rejected(d4), "bridge default: plain http on a reserved name is not trusted (a hostile network could answer it)", A(d4));
    Check(d3.find(L"https://www.baidu.com") != std::wstring::npos && d3.find(L"*") != std::wstring::npos, "bridge default: the rejection names the origin and how to allow it", A(d3));
    Check(p_WV_MapFolder(h, "assets.local", appA.c_str(), 1) == 1, "map a folder for the bridge test");
    std::wstring d6 = call(L"http://assets.local/a.html", 526), d7 = call(L"https://assets.local/a.html", 527);
    Check(ok(d6) && ok(d7), "bridge default: the host of a mapped folder is own content", A(d6));
    // 1.7.4：映射目录里的下载目录（浏览器替网页写的文件）不算本程序的内容
    p_WV_SetStr(h, WVS_DOWNLOAD_DIR, (appA + "\\down").c_str());
    std::wstring d7b = call(L"https://assets.local/down/x.html", 535), d7c = call(L"https://assets.local/a.html", 536);
    p_WV_SetStr(h, WVS_DOWNLOAD_DIR, "");
    Check(rejected(d7b) && ok(d7c), "bridge default: on a mapped host, a page inside the download folder is rejected; other pages still pass", A(d7b));
    p_WV_MapFolder(h, "assets.local", "", 1);
    std::wstring d8 = call(L"https://assets.local/a.html", 528);
    Check(rejected(d8), "bridge default: once the mapping is cleared the host is no longer trusted", A(d8));
    p_WV_SetStr(h, WVS_BRIDGE_ORIGINS, "*");
    std::wstring d9 = call(L"https://www.baidu.com/", 529);
    Check(ok(d9), "bridge whitelist * allows every origin", A(d9));
    p_WV_SetStr(h, WVS_BRIDGE_ORIGINS, "");
  }
  {  // 新窗口交给系统打开（模式 3）：网址由网页决定，file: 与自定义协议不得交给系统外壳
    p_WV_SetEvent(h, WVE_NEW_WINDOW, nullptr);
    int oldMode = p_WV_GetInt(h, WVP_NEW_WINDOW);
    p_WV_SetInt(h, WVP_NEW_WINDOW, 3);
    pNewWin(L"file:///C:/windows/system32/notepad.exe");
    pNewWin(L"ms-settings:display");
    pNewWin(L"file://attacker-host/share/x.exe");
    Pump(400);
    std::wstring logw;
    HANDLE fh = CreateFileW((ExeDir() + L"\\wv.log").c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
    if (fh != INVALID_HANDLE_VALUE) {
      DWORD sz = GetFileSize(fh, nullptr), rd = 0; std::string b(sz, 0); ReadFile(fh, &b[0], sz, &rd, nullptr); CloseHandle(fh);
      int n = MultiByteToWideChar(CP_UTF8, 0, b.data(), (int)rd, nullptr, 0); logw.resize(n); MultiByteToWideChar(CP_UTF8, 0, b.data(), (int)rd, &logw[0], n);
    }
    int refused = 0;
    for (size_t pos = 0; (pos = logw.find(L"未交给系统打开", pos)) != std::wstring::npos; ++pos) ++refused;
    Check(refused == 3, "new window mode 3: file:, UNC and custom-protocol URLs are not handed to the shell", std::to_string(refused));
    p_WV_SetInt(h, WVP_NEW_WINDOW, oldMode);
    p_WV_SetEvent(h, WVE_NEW_WINDOW, (void*)OnNewWin);
  }
  {  // 新窗口在当前浏览器打开（模式 1）：导航由宿主发起，照浏览器规则拒绝 javascript:、data:、内部页面与远程页面打开本地文件
    p_WV_SetEvent(h, WVE_NEW_WINDOW, nullptr);
    int oldMode = p_WV_GetInt(h, WVP_NEW_WINDOW);
    p_WV_SetInt(h, WVP_NEW_WINDOW, 1);
    const wchar_t* refused[] = {L"javascript:alert(1)", L"data:text/html,<b>x</b>", L"file:///C:/Windows/win.ini", L"edge://settings/", L"about:settings", L"view-source:https://a.test/", L"filesystem:https://a.test/temporary/x.html", L"chrome-extension://abcdef/page.html"};
    const wchar_t* allowed[] = {L"https://ok1.test/", L"blob:https://a.test/0b1d", L"about:blank"};
    int nav0 = CountOf(L"Navigate:");
    for (auto* u : refused) pNewWin(u);
    Pump(300);
    int navRefused = CountOf(L"Navigate:") - nav0;
    bool allOk = true;
    for (auto* u : allowed) { pNewWin(u); PumpFor(std::wstring(L"Navigate:") + u, 2000); allOk = allOk && Find(std::wstring(L"Navigate:") + u) >= 0; }
    Check(navRefused == 0, "new window in the same view: javascript:, data:, internal pages and local files are refused", N(navRefused));
    Check(allOk, "new window in the same view: http(s), blob: and about:blank still open");
    p_WV_Navigate(h, "file:///C:/app/a.html"); PumpFor(L"Committed:file:///C:/app/a.html", 3000);
    pNewWin(L"file:///C:/app/b.html"); PumpFor(L"Navigate:file:///C:/app/b.html", 2000);
    Check(Find(L"Navigate:file:///C:/app/b.html") >= 0, "a local page may still open another local file in the same view");
    p_WV_SetInt(h, WVP_NEW_WINDOW, oldMode);
    p_WV_SetEvent(h, WVE_NEW_WINDOW, (void*)OnNewWin);
    p_WV_Navigate(h, "https://a.test/"); PumpFor(L"Committed:https://a.test/", 3000, CountOf(L"Committed:https://a.test/") + 1);
  }
  {  // 不带协议的地址补全：按主机名整体判断
    struct { const char* in; const wchar_t* out; } cases[] = {
        {"localhost:8080/x", L"Navigate:http://localhost:8080/x"}, {"172.16.0.5:3000", L"Navigate:http://172.16.0.5:3000"},
        {"[::1]:8080/", L"Navigate:http://[::1]:8080/"}, {"localhost.evil.test/", L"Navigate:https://localhost.evil.test/"},
        {"10.example.test", L"Navigate:https://10.example.test"}, {"example.test/p", L"Navigate:https://example.test/p"}};
    int good = 0; std::string bad;
    for (auto& c : cases) { p_WV_Navigate(h, c.in); if (PumpFor(c.out, 2000), Find(c.out) >= 0) ++good; else bad += std::string(c.in) + " "; }
    Check(good == 6, "address completion: http only for localhost and IP literals, https for look-alike hostnames", bad);
    p_WV_Navigate(h, "https://a.test/"); PumpFor(L"Committed:https://a.test/", 3000, CountOf(L"Committed:https://a.test/") + 1);
  }
  int nwBase = (int)LogAll().size(), nwDone = CountOf(L"Deferral.Complete:NewWindow");  // 只看这次请求产生的记录
  pNewWin(L"https://popup.test/");
  Check(PumpFor(L"Deferral.Complete:NewWindow", 3000, nwDone + 1), "NewWindow deferral completed");
  int a1 = Find(L"Raised:NewWindow", nwBase), a2 = Find(L"Note:cb-newwindow", nwBase), a3 = Find(L"NewWindow.Handled=1", nwBase), a4 = Find(L"Deferral.Complete:NewWindow", nwBase);
  Check(a1 >= 0 && a1 < a2 && a2 < a3 && a3 < a4, "NewWindow order: handler returns, callback, Handled, Complete", N(a1) + "," + N(a2) + "," + N(a3) + "," + N(a4));
  Check(g_nwInner == "3" && Find(L"Navigate:https://popup.test/") < 0 && CountOf(L"Deferral.DoubleComplete") == 0, "NewWindow callback can run sync calls; blocked popup not opened", g_nwInner);
  pPerm(L"https://a.test/");
  Check(PumpFor(L"Deferral.Complete:Permission", 3000), "Permission deferral completed");
  int b1 = Find(L"Raised:Permission"), b2 = Find(L"Note:cb-permission"), b3 = Find(L"Permission.State=1"), b4 = Find(L"Deferral.Complete:Permission");
  Check(b1 >= 0 && b1 < b2 && b2 < b3 && b3 < b4, "Permission order: handler returns, callback, State, Complete", N(b1) + "," + N(b2) + "," + N(b3) + "," + N(b4));
  p_WV_AddMemoryFile(h, "https://App.Local/Index.html", "<h1>ok</h1>", 11, "text/html");
  Check(PumpFor(L"AddFilter:https://app.local/Index.html*", 2000), "memory file filter: host lowercased, path case kept");
  pReq(L"https://app.local/Index.html?x=1", 1);
  Check(PumpFor(L"Raised:Request:https://app.local/Index.html?x=1", 2000), "memory file request raised");
  { int c1 = Find(L"CreateResponse:200:11:OK:Content-Type: text/html"), c2 = Find(L"Raised:Request:https://app.local/Index.html?x=1");
    Check(c1 >= 0 && c1 < c2 && Find(L"Request.put_Response") > c1, "memory file answered inside the handler (200, 11 bytes)", N(c1) + "," + N(c2)); }
  p_WV_SetStr(h, WVS_BLOCK_URLS, "*ads*");
  pReq(L"https://x.test/ads.js", 6);
  Check(PumpFor(L"Raised:Request:https://x.test/ads.js", 2000) && Find(L"CreateResponse:403") >= 0 && Find(L"CreateResponse:403") < Find(L"Raised:Request:https://x.test/ads.js"), "blocked URL answered 403 inside the handler");
  p_WV_SetEvent(h, WVE_REQUEST, (void*)OnRequest); p_WV_AddRequestFilter(h, "https://api.test/*", 0);
  pReq(L"https://api.test/data", 8);
  Check(PumpFor(L"Deferral.Complete:Request", 3000), "intercepted request deferral completed");
  { int r1 = Find(L"Raised:Request:https://api.test/data"), r2 = Find(L"Note:cb-request"), r3 = Find(L"Header.Set:X-Test=1"), r4 = Find(L"Deferral.Complete:Request");
    Check(r1 >= 0 && r1 < r2 && r2 < r3 && r3 < r4, "request order: handler returns, callback, header set, Complete", N(r1) + "," + N(r2) + "," + N(r3) + "," + N(r4)); }
  Check(g_reqInner == "3", "sync call inside request callback works", g_reqInner);
  pReq(L"https://other.test/x", 8);
  Check(PumpFor(L"Raised:Request:https://other.test/x", 2000) && CountOf(L"Note:cb-request") == 1 && CountOf(L"Deferral.Complete:Request") == 1, "request outside filters passes through untouched");
  Check(p_WV_ExecScriptAsync(h, "6*7", 0, (void*)OnAsync, 5) == 1 && PumpFor(L"Note:cb-async", 3000), "ExecScriptAsync callback delivered");
  Pump(50);
  Check(g_asyncOk == 1 && g_asyncRes == "42" && g_asyncInner == "3", "async result, and sync call inside async callback", g_asyncRes + "/" + g_asyncInner);
  p_WV_SetOption(WVO_CODEPAGE, "936");
  { const char* U = "https://example.com/";
    bool ok = p_WV_SetCookie(h, U, "a", "1", "", "", 0, 0) == 1 && p_WV_SetCookie(h, U, "b", "x=y", ".example.com", "/p", 2000000000, 1 | 2 | 0x200) == 1 &&
              p_WV_SetCookieString(h, U, "c=3; d=4; Path=/x; secure") == 1 && p_WV_SetCookie(h, U, "e", "\xD6\xD0\xCE\xC4", "", "", 0, 0) == 1;
    Check(ok && CountOf(L"Cookie.Add:") == 5, "cookies set; cookie string skips attributes", N(CountOf(L"Cookie.Add:")));
    std::string c1 = p_WV_GetCookies(h, U, 1);
    Check(c1 == "a=1; b=x=y; c=3; d=4; e=\xD6\xD0\xCE\xC4", "cookie header format", c1);
    std::string c0 = p_WV_GetCookies(h, U, 0);
    auto J = [&](const char* path) { return std::string(p_WV_JsonGet(c0.c_str(), path)); };
    Check(J("[0].domain") == "example.com" && J("[0].path") == "/" && J("[0].session") == "true" && J("[0].expires") == "-1" && J("[0].sameSite") == "Lax", "JSON: host-only session cookie", c0.substr(0, 170));
    Check(J("[1].domain") == ".example.com" && J("[1].path") == "/p" && J("[1].value") == "x=y" && J("[1].httpOnly") == "true" && J("[1].secure") == "true" &&
          J("[1].sameSite") == "Strict" && J("[1].expires") == "2000000000" && J("[1].session") == "false", "JSON: domain cookie with HttpOnly, Secure, Strict, expiry", c0);
    Check(J("[4].value") == "\xD6\xD0\xCE\xC4" && J("[2].path") == "/", "JSON: Chinese value round trip; cookie-string path is /");
    std::string c2 = p_WV_GetCookies(h, U, 2);
    Check(c2.rfind("# Netscape HTTP Cookie File\r\n", 0) == 0 && c2.find("\r\nexample.com\tFALSE\t/\tFALSE\t0\ta\t1\r\n") != std::string::npos &&
          c2.find("\r\n#HttpOnly_.example.com\tTRUE\t/p\tTRUE\t2000000000\tb\tx=y\r\n") != std::string::npos, "Netscape cookies.txt format", c2);
    Check(p_WV_DeleteCookies(h, U, "a") == 1 && Find(L"Cookie.DeleteCookies:a@https://example.com/") >= 0, "delete cookie by name");
    Check(p_WV_DeleteCookies(h, U, "") == 1 && CountOf(L"Cookie.Delete:") == 4, "delete all cookies of a URL", N(CountOf(L"Cookie.Delete:")));
    Check(p_WV_DeleteCookies(h, "", "") == 1 && Find(L"Cookie.DeleteAll") >= 0 && std::string(p_WV_GetCookies(h, U, 0)) == "[]", "delete every cookie; empty list is []"); }
  {  // 1.6.2：Cookie 文本也可以每行一个（值里不会有回车换行）
    const char* U2 = "https://lines.example/";
    const int adds0 = CountOf(L"Cookie.Add:");
    const bool ok = p_WV_SetCookieString(h, U2, "f=6\r\ng=7\nh=8; i=9") == 1;
    const std::string got = p_WV_GetCookies(h, U2, 1);
    Check(ok && CountOf(L"Cookie.Add:") == adds0 + 4 && got == "f=6; g=7; h=8; i=9", "cookie string: one cookie per line works too", got);
    p_WV_DeleteCookies(h, "", "");
  }
  p_WV_SetEvent(h, WVE_RESPONSE, (void*)OnResponse);
  Check(p_WV_SetResponseCapture(h, "https://api.test/*", 1) == 1 && Find(L"add_WebResourceResponseReceived") >= 0, "response capture hooked via ICoreWebView2_2");
  pResp(L"https://api.test/data", 200, "{\"ok\":1}");
  Check(PumpFor(L"Note:cb-response", 3000) && g_respStatus == 200 && g_respMethod == "GET" && g_respLen == 8 && g_respBody == "{\"ok\":1}", "captured response with body", g_respBody + "/" + N(g_respLen));
  Check(Find(L"Note:cb-response") > Find(L"Raised:Response:https://api.test/data"), "response callback runs after the handler returned");
  pResp(L"https://other.test/x", 200, "zz"); PumpFor(L"Raised:Response:https://other.test/x", 2000); Pump(100);
  Check(CountOf(L"Note:cb-response") == 1 && CountOf(L"Response.GetContent") == 1, "response outside capture rules ignored");
  p_WV_SetEvent(h, WVE_DOM_READY, (void*)OnDomReady);
  p_WV_Navigate(h, "https://dom.test/");
  Check(PumpFor(L"Note:cb-domready", 3000) && Find(L"Note:cb-domready") > Find(L"Raised:DOMContentLoaded"), "DOMContentLoaded callback");
  p_WV_Navigate(h, "https://a.test/"); PumpFor(L"Committed:https://a.test/", 3000, CountOf(L"Committed:https://a.test/") + 1);
  { std::wstring ui = app + L"\\ui"; CreateDirectoryW(ui.c_str(), nullptr);
    Check(p_WV_MapFolder(h, "app.local", "ui", 1) == 1 && Find(L"MapFolder:app.local=" + ui + L":1") >= 0, "map relative folder (resolved against the program folder) via ICoreWebView2_3");
    int r = p_WV_MapFolder(h, "x.local", "C:\\no\\such\\dir", 1); int e = p_WV_LastErrorCode();
    Check(r == 0 && e == WVERR_NOT_FOUND, "missing folder rejected with NOT_FOUND", N(e));
    Check(p_WV_MapFolder(h, "app.local", "", 1) == 1 && Find(L"MapFolder.Clear:app.local") >= 0, "empty folder clears the mapping"); }
  { void* d = nullptr; int n = 0;
    Check(p_WV_CaptureToMemory(h, 0, 0, &d, &n) == 1 && n == 12 && d && memcmp(d, "\x89PNG\r\n\x1a\nMOCK", 12) == 0 && p_WV_Free(d) == 1, "viewport capture (CapturePreview) and WV_Free", N(n));
    d = nullptr; n = 0;
    Check(p_WV_CaptureToMemory(h, 0, 1, &d, &n) == 1 && n == 8 && d && memcmp(d, "\x89PNG\r\n\x1a\n", 8) == 0 && p_WV_Free(d) == 1, "full-page capture (DevTools)", N(n) + " " + p_WV_LastError()); }
  p_WV_SetEvent(h, WVE_SCRIPT_DIALOG, (void*)OnDialog);
  Check(Find(L"Settings.ScriptDialogs=0") >= 0, "default script dialogs disabled while a callback is set");
  pDialog(2, L"name?", L"def");
  Check(PumpFor(L"Deferral.Complete:Dialog", 3000), "dialog deferral completed");
  { int d1 = Find(L"Raised:Dialog"), d2 = Find(L"Note:cb-dialog"), d3 = Find(L"Dialog.ResultText=answer"), d4 = Find(L"Dialog.Accept"), d5 = Find(L"Deferral.Complete:Dialog");
    Check(d1 >= 0 && d1 < d2 && d2 < d3 && d3 < d4 && d4 < d5, "dialog order: handler returns, callback, text, accept, complete", N(d1) + "," + N(d2) + "," + N(d3) + "," + N(d4) + "," + N(d5)); }
  {  // 1.7.0：按 WVE_FLAG_NO_OUT 注册的回调应有的参数表不含最后的 int* 参数，用 WVK_CANCEL / WVK_RESULT 回填（易语言类的事件都这样注册；1.7.8 起地址仍放在原来的位置）。
     // 放在权限请求、对话框的顺序检查之后：那两项检查从日志开头查找，之前不能有别的对话框与权限请求记录
    p_WV_SetEvent(h, WVE_NAV_STARTING | WVE_FLAG_NO_OUT, (void*)OnNavNoOut);
    p_WV_Navigate(h, "https://blocked-noout.test/");
    Check(PumpFor(L"Cancelled:https://blocked-noout.test/", 3000) && g_noOutNav >= 1, "no-out navigation callback: 4 parameters, WVK_CANCEL cancels the navigation", N(g_noOutNav));
    p_WV_SetEvent(h, WVE_NAV_STARTING | WVE_FLAG_NO_OUT, (void*)OnNavLegacy5);
    p_WV_Navigate(h, "https://blocked-legacy.test/");
    const bool legacyCancelled = PumpFor(L"Cancelled:https://blocked-legacy.test/", 3000);
    const std::string diag = p_WV_GetDiagnostics();
    Check(legacyCancelled && diag.find("{\"event\":2,\"declaredBytes\":20,\"expected\":4}") != std::string::npos,
          "an old-style callback that still declares the by-ref parameter keeps cancelling, and is reported as a parameter list mismatch", diag.substr(0, 300));
    p_WV_SetEvent(h, WVE_NAV_STARTING, (void*)OnNavStarting);
    p_WV_SetEvent(h, WVE_SCRIPT_DIALOG | WVE_FLAG_NO_OUT, (void*)OnDialogNoOut);
    int base = (int)LogAll().size(), done = CountOf(L"Deferral.Complete:Dialog");
    pDialog(1, L"sure?", L"");
    Check(PumpFor(L"Deferral.Complete:Dialog", 3000, done + 1) && Find(L"Dialog.Accept", base) < 0, "no-out dialog callback: WVK_CANCEL answers a confirm with cancel");
    base = (int)LogAll().size(); done = CountOf(L"Deferral.Complete:Dialog");
    pDialog(0, L"hi", L"");
    Check(PumpFor(L"Deferral.Complete:Dialog", 3000, done + 1) && Find(L"Dialog.Accept", base) >= 0, "no-out dialog callback: a dialog that is not cancelled is accepted");
    p_WV_SetEvent(h, WVE_SCRIPT_DIALOG, (void*)OnDialog);
    p_WV_SetEvent(h, WVE_PERMISSION | WVE_FLAG_NO_OUT, (void*)OnPermNoOut);
    base = (int)LogAll().size(); done = CountOf(L"Deferral.Complete:Permission");
    pPerm(L"https://a.test/");
    Check(PumpFor(L"Deferral.Complete:Permission", 3000, done + 1) && Find(L"Permission.State=2", base) >= 0, "no-out permission callback: WVK_CANCEL denies the request");
    p_WV_SetEvent(h, WVE_PERMISSION, (void*)OnPerm);
    // 新窗口：回调把处理方式改成 0（WV新窗口_默认弹窗）时交给 WebView2 默认弹出；原来 0 被当成“没有改”，按新窗口模式在当前浏览器打开
    int oldMode = p_WV_GetInt(h, WVP_NEW_WINDOW);
    p_WV_SetInt(h, WVP_NEW_WINDOW, 1);
    p_WV_SetEvent(h, WVE_NEW_WINDOW, (void*)OnNewWinDefault);
    base = (int)LogAll().size(); done = CountOf(L"Deferral.Complete:NewWindow");
    pNewWin(L"https://popup-default.test/");
    Check(PumpFor(L"Deferral.Complete:NewWindow", 3000, done + 1) && Find(L"NewWindow.Handled=1", base) < 0 && Find(L"Navigate:https://popup-default.test/", base) < 0,
          "new window: a callback choosing 0 (default popup) leaves the request to WebView2 even when the mode is open-in-place");
    p_WV_SetEvent(h, WVE_NEW_WINDOW | WVE_FLAG_NO_OUT, (void*)OnNewWinNoOut);
    base = (int)LogAll().size(); done = CountOf(L"Deferral.Complete:NewWindow");
    pNewWin(L"https://popup-mode.test/");
    Check(PumpFor(L"Deferral.Complete:NewWindow", 3000, done + 1) && Find(L"Navigate:https://popup-mode.test/", base) >= 0,
          "no-out new window callback that sets nothing keeps the configured mode (open in the same view)");
    p_WV_SetInt(h, WVP_NEW_WINDOW, oldMode);
    p_WV_SetEvent(h, WVE_NEW_WINDOW, (void*)OnNewWin);
    p_WV_Navigate(h, "https://a.test/"); PumpFor(L"Committed:https://a.test/", 3000, CountOf(L"Committed:https://a.test/") + 1);
  }
  { DWORD t0 = GetTickCount(); std::string r2 = p_WV_ExecScript(h, "hang()", 0, 300); int e = p_WV_LastErrorCode(); DWORD el = GetTickCount() - t0;
    Check(r2.empty() && e == WVERR_TIMEOUT && el >= 250 && el < 2000, "script that never completes times out", N(e) + " " + N((int)el) + "ms");
    t0 = GetTickCount(); std::string d = p_WV_Dom(h, WVD_EXISTS, "#late", "", 3000); el = GetTickCount() - t0;
    Check(d == "true" && el >= 200 && el < 3000, "wait for element polls until it appears", d + " " + N((int)el) + "ms");
    t0 = GetTickCount(); d = p_WV_Dom(h, WVD_EXISTS, "#never", "", 300); el = GetTickCount() - t0; e = p_WV_LastErrorCode();
    Check(d == "false" && e == WVERR_TIMEOUT && el >= 250 && el < 3000, "wait for a missing element times out with WVERR_TIMEOUT", d + " " + N(e) + " " + N((int)el) + "ms");
    d = p_WV_Dom(h, WVD_EXISTS, "#never", "", 0); e = p_WV_LastErrorCode();
    Check(d == "false" && e == 0, "exists without waiting: a missing element is not an error", d + " " + N(e)); }
  { std::wstring dl = ExeDir() + L"\\dl"; std::string dlA = A(dl);
    p_WV_SetStr(h, WVS_DOWNLOAD_DIR, dlA.c_str());
    p_WV_SetEvent(h, WVE_DOWNLOAD_START, (void*)OnDlStart); p_WV_SetEvent(h, WVE_DOWNLOAD_PROGRESS, (void*)OnDlProg); p_WV_SetEvent(h, WVE_DOWNLOAD_DONE, (void*)OnDlDone);
    pDownload(L"https://files.test/report.pdf", 1000000);
    Check(PumpFor(L"Note:cb-dldone", 5000), "download finished"); Pump(50);
    std::string want = dlA + "\\report.pdf";
    int k1 = Find(L"Raised:Download"), k2 = Find(L"Note:cb-dlstart"), k3 = Find(L"Download.ResultFilePath="), k4 = Find(L"Deferral.Complete:Download");
    Check(g_dlStart == want && k1 < k2 && k2 < k3 && k3 < k4, "download redirected into the download folder before the deferral completes", g_dlStart);
    Check(g_dlProg >= 2 && g_dlProg <= 10 && g_dlLastPct == 100 && g_dlDone == 1 && g_dlDonePath == want, "download progress and completion reported", N(g_dlProg) + "/" + N(g_dlLastPct) + "/" + N(g_dlDone)); }
  {  // 1.7.5：下载过的文件不算本程序的内容，即使用 WVK_SET_PATH 放进了程序目录；旁边的文件照常算
    const std::string oldDir = p_WV_GetStr(h, WVS_DOWNLOAD_DIR);
    p_WV_SetStr(h, WVS_DOWNLOAD_DIR, "");
    g_dlSaveTo = appA + "\\saved\\got.html";
    p_WV_SetEvent(h, WVE_DOWNLOAD_START, (void*)OnDlStartSaveTo);
    const int done0 = CountOf(L"Note:cb-dldone");
    typedef void(__stdcall* HoldFn)(int);
    HoldFn pHold = (HoldFn)(void*)GetProcAddress(g_mock, "Mock_HoldDownloads");
    if (pHold) pHold(1);  // 先让下载停在进行中：检查下载开始时就已记下（1.7.9 变异测试发现原来只靠下载完成时那一份也能通过）
    pDownload(L"https://files.test/got.html", 1000);
    PumpFor(L"Note:cb-dlsaveto", 3000);
    Pump(50);
    typedef void(__stdcall* SendFromFn)(const wchar_t*, const wchar_t*);
    SendFromFn pSendFrom = (SendFromFn)(void*)GetProcAddress(g_mock, "Mock_SendWebMessageFrom");
    auto callFrom = [&](const std::string& file, int id) -> std::wstring {
      std::wstring src = L"file:///";
      for (char c : file) src += c == '\\' ? std::wstring(L"/") : c == ' ' ? std::wstring(L"%20") : std::wstring(1, (wchar_t)(unsigned char)c);
      wchar_t b[128], key[32];
      swprintf(b, 128, L"{\"__epl\":1,\"t\":\"c\",\"id\":%d,\"n\":\"add\",\"a\":[1,1]}", id);
      swprintf(key, 32, L"\"id\":%d,", id);
      pSendFrom(src.c_str(), b);
      PumpFor(key, 3000);
      int i = Find(key);
      return i >= 0 ? LogAll()[i] : std::wstring(L"(无回传)");
    };
    const std::wstring early = callFrom(g_dlSaveTo, 540);
    const bool stillRunning = CountOf(L"Note:cb-dldone") == done0;
    if (pHold) pHold(0);
    PumpFor(L"Note:cb-dldone", 5000, done0 + 1);
    Check(pHold && stillRunning && early.find(L"\"ok\":false") != std::wstring::npos,
          "a file being downloaded into the program folder is excluded from the start, before the download completes", A(early));
    const std::wstring r1 = callFrom(g_dlSaveTo, 541), r2 = callFrom(appA + "\\saved\\mine.html", 542);
    Check(CountOf(L"Note:cb-dlsaveto") >= 1 && r1.find(L"\"ok\":false") != std::wstring::npos && r2.find(L"\"ok\":true") != std::wstring::npos,
          "a file downloaded into the program folder (path set in the download callback) is not own content; a file next to it still is", A(r1));
    p_WV_SetEvent(h, WVE_DOWNLOAD_START, (void*)OnDlStart);
    p_WV_SetStr(h, WVS_DOWNLOAD_DIR, oldDir.c_str());
  }
  { auto inputs = [&] { std::vector<std::wstring> r; for (auto& l : LogAll()) if (l.rfind(L"CDP:Input.", 0) == 0) r.push_back(l); return r; };
    auto has = [](const std::wstring& l, const wchar_t* f) { return l.find(f) != std::wstring::npos; };
    size_t c0 = inputs().size();
    Check(p_WV_Input(h, WVI_CLICK, 10, 20, "") == 1, "simulated click returns success");
    auto I = inputs();
    Check(I.size() == c0 + 3 && has(I[c0], L"{\"type\":\"mouseMoved\",\"x\":10,\"y\":20,\"button\":\"none\",\"clickCount\":0}") &&
          has(I[c0 + 1], L"{\"type\":\"mousePressed\",\"x\":10,\"y\":20,\"button\":\"left\",\"clickCount\":1}") && has(I[c0 + 2], L"{\"type\":\"mouseReleased\",\"x\":10,\"y\":20,\"button\":\"left\",\"clickCount\":1}"),
          "click = move, press, release with exact DevTools parameters", I.size() > c0 ? A(I[c0]) : "none");
    c0 = inputs().size(); p_WV_Input(h, WVI_DBLCLICK, 1, 2, ""); I = inputs();
    Check(I.size() == c0 + 5 && has(I[c0 + 3], L"\"type\":\"mousePressed\"") && has(I[c0 + 3], L"\"clickCount\":2") && has(I[c0 + 4], L"\"type\":\"mouseReleased\"") && has(I[c0 + 4], L"\"clickCount\":2"),
          "double click sends a second press/release with clickCount 2", N((int)(I.size() - c0)));
    c0 = inputs().size(); p_WV_Input(h, WVI_RIGHT_CLICK, 3, 4, ""); I = inputs();
    Check(I.size() == c0 + 3 && has(I[c0 + 1], L"\"button\":\"right\""), "right click uses the right button");
    c0 = inputs().size(); p_WV_Input(h, WVI_TEXT, 0, 0, "hi\"x"); I = inputs();
    Check(I.size() == c0 + 1 && has(I[c0], L"CDP:Input.insertText {\"text\":\"hi\\\"x\"}"), "text input escaped as JSON", I.size() > c0 ? A(I[c0]) : "none");
    c0 = inputs().size(); p_WV_Input(h, WVI_KEY, 0, 0, "Ctrl+A"); I = inputs();
    Check(I.size() == c0 + 2 && has(I[c0], L"{\"type\":\"rawKeyDown\",\"windowsVirtualKeyCode\":65,\"nativeVirtualKeyCode\":65,\"modifiers\":2,\"key\":\"a\",\"code\":\"KeyA\"}") &&
          has(I[c0 + 1], L"{\"type\":\"keyUp\",\"windowsVirtualKeyCode\":65"), "Ctrl+A = rawKeyDown with Ctrl modifier, then keyUp", I.size() > c0 ? A(I[c0]) : "none");
    c0 = inputs().size(); p_WV_Input(h, WVI_KEY, 0, 0, "Enter"); I = inputs();
    Check(I.size() == c0 + 2 && has(I[c0], L"\"type\":\"keyDown\"") && has(I[c0], L"\"key\":\"Enter\"") && has(I[c0], L"\"text\":\"\\r\""), "Enter = keyDown with text \\r", I.size() > c0 ? A(I[c0]) : "none");
    c0 = inputs().size(); p_WV_Input(h, WVI_KEY, 0, 0, "Shift+b"); I = inputs();
    Check(I.size() == c0 + 2 && has(I[c0], L"\"modifiers\":8") && has(I[c0], L"\"key\":\"B\"") && has(I[c0], L"\"text\":\"B\""), "Shift+b = keyDown B with Shift modifier");
    c0 = inputs().size(); p_WV_Input(h, WVI_KEY, 0, 0, "F5"); I = inputs();
    Check(I.size() == c0 + 2 && has(I[c0], L"\"type\":\"rawKeyDown\",\"windowsVirtualKeyCode\":116") && has(I[c0], L"\"key\":\"F5\""), "F5 = rawKeyDown vk 116");
    Check(p_WV_Input(h, WVI_KEY, 0, 0, "Nope") == 0 && p_WV_LastErrorCode() == WVERR_ARG, "unknown key name rejected");
    RECT hc{}; GetClientRect((HWND)(intptr_t)p_WV_GetWindow(h, 0), &hc);
    c0 = inputs().size(); p_WV_Input(h, WVI_WHEEL, 0, 120, ""); I = inputs();
    std::wstring want = L"{\"type\":\"mouseWheel\",\"x\":" + std::to_wstring(hc.right / 2) + L",\"y\":" + std::to_wstring(hc.bottom / 2) + L",\"deltaX\":0,\"deltaY\":120}";
    Check(I.size() == c0 + 1 && has(I[c0], want.c_str()), "wheel at the centre of the view", I.size() > c0 ? A(I[c0]) : "none"); }
  {  // 不要结果的异步调用也必须给出完成回调（WebView2 文档没说明这些方法接受空的回调）：强制刷新、退出全屏、打印、创建后绑定时注入桥接脚本
    p_WV_Command(h, WVC_HARD_RELOAD); p_WV_Command(h, WVC_EXIT_FULLSCREEN); p_WV_Command(h, WVC_PRINT_SYSTEM); p_WV_Bind(h, "lateBind", (void*)OnEcho); Pump(100);
    int nh = Find(L"NullHandler"); Check(nh < 0 && Find(L"CDP:Page.reload") >= 0, "async WebView2 calls always pass a completion handler", nh >= 0 ? A(LogAll()[nh]) : std::string()); }
  { Check(p_WV_Command(h, WVC_RELOAD) == 1 && Find(L"WebView.Reload") >= 0, "command reload");
    Check(p_WV_Command(h, WVC_BACK) == 1 && p_WV_Command(h, WVC_FORWARD) == 1 && p_WV_Command(h, WVC_STOP) == 1 && Find(L"WebView.GoBack") >= 0 && Find(L"WebView.GoForward") >= 0 && Find(L"WebView.Stop") >= 0, "commands back, forward, stop");
    Check(p_WV_Command(h, WVC_HARD_RELOAD) == 1 && Find(L"CDP:Page.reload {\"ignoreCache\":true}") >= 0, "hard reload ignores cache");
    int v0 = CountOf(L"Controller.Visible=0");
    Check(p_WV_Command(h, WVC_SUSPEND) == 1 && CountOf(L"Controller.Visible=0") == v0 + 1 && Find(L"WebView.TrySuspend") > 0, "suspend hides the view first, then TrySuspend");
    { auto v = LogAll(); int hide = -1, sus = -1; for (int k = 0; k < (int)v.size(); ++k) { if (v[k] == L"Controller.Visible=0") hide = k; if (v[k] == L"WebView.TrySuspend") sus = k; }
      Check(hide >= 0 && hide < sus, "hide happens before TrySuspend", N(hide) + "<" + N(sus)); }
    Check(p_WV_Command(h, WVC_RESUME) == 1 && Find(L"WebView.Resume") >= 0 && LogAll().back() == L"Controller.Visible=1", "resume shows the view again", A(LogAll().back()));
    Check(p_WV_Command(h, WVC_TASK_MANAGER) == 1 && Find(L"WebView.TaskManager") >= 0, "task manager via ICoreWebView2_6");
    Check(p_WV_SetStr(h, WVS_USER_AGENT, "X") == 0 && p_WV_LastErrorCode() == WVERR_UNSUPPORTED, "setting needing a newer runtime reports UNSUPPORTED");
    { const int n0 = CountOf(L"Controller.NotifyParentWindowPositionChanged");  // 1.8.1：顶层窗口属于别的线程或进程时由程序转告移动与最小化
      Check(p_WV_Command(h, WVC_NOTIFY_MOVED) == 1 && CountOf(L"Controller.NotifyParentWindowPositionChanged") == n0 + 1, "1.8.1: notify-moved command forwards NotifyParentWindowPositionChanged");
      const int v0 = CountOf(L"Controller.Visible=0"), v1 = CountOf(L"Controller.Visible=1");
      Check(p_WV_Command(h, WVC_MINIMIZED) == 1 && CountOf(L"Controller.Visible=0") == v0 + 1 && p_WV_Command(h, WVC_MINIMIZED) == 1 && CountOf(L"Controller.Visible=0") == v0 + 1,
            "1.8.1: minimized command hides the view once (repeated calls do not hide again)");
      Check(p_WV_Command(h, WVC_RESTORED) == 1 && CountOf(L"Controller.Visible=1") == v1 + 1, "1.8.1: restored command shows the view again"); }
    Check(p_WV_Command(h, 99) == 0 && p_WV_LastErrorCode() == WVERR_ARG, "unknown command rejected"); }
  { HWND host = (HWND)(intptr_t)p_WV_GetWindow(h, 0), par = GetParent(host);
    Check(p_WV_SetInt(h, WVP_ZOOM, 150) == 1 && Find(L"Controller.Zoom=150") >= 0 && p_WV_GetInt(h, WVP_ZOOM) == 150, "zoom set and read back", N(p_WV_GetInt(h, WVP_ZOOM)));
    p_WV_SetInt(h, WVP_ZOOM, 100);
    Check(p_WV_Show(h, 0) == 1 && !IsWindowVisible(host) && LogAll().back() == L"Controller.Visible=0", "hide view");
    Check(p_WV_Show(h, 1) == 1 && IsWindowVisible(host) && LogAll().back() == L"Controller.Visible=1", "show view");
    p_WV_SetBounds(h, 5, 6, 300, 200); Pump(30);
    RECT r{}; GetWindowRect(host, &r); MapWindowPoints(nullptr, par, (POINT*)&r, 2);
    Check(r.left == 5 && r.top == 6 && r.right - r.left == 300 && r.bottom - r.top == 200 && Find(L"Controller.Bounds=300x200") >= 0, "set bounds", N(r.left) + "," + N(r.top) + " " + N(r.right - r.left) + "x" + N(r.bottom - r.top));
    p_WV_SetBounds(h, 0, 0, 0, 0); Pump(30);
    RECT pc{}; GetClientRect(par, &pc); GetWindowRect(host, &r);
    Check(r.right - r.left == pc.right && r.bottom - r.top == pc.bottom, "zero size returns to fill-parent mode");
    Check(p_WV_SetInt(h, WVP_CONTEXT_MENU, 1) == 1 && Find(L"Settings.ContextMenus=0") >= 0, "context menu disabled through settings");
    p_WV_SetInt(h, WVP_CONTEXT_MENU, 0); }
  { p_WV_SetStr(h, WVS_BLOCK_KEYS, "F5, Ctrl+R, F12");
    pKey(116, 0); pKey(123, 0); pKey(117, 0); pKey(116, 1);
    PumpFor(L"Key116:", 2000, 2);
    Check(Find(L"Key116:Handled=1") >= 0 && Find(L"Key123:Handled=1") >= 0 && Find(L"Key117:Handled=0") >= 0, "blocked keys F5/F12 swallowed (list written with spaces), F6 passes");
    Check(CountOf(L"Key116:Handled=0") == 1, "key-up of a blocked key passes through");
    p_WV_SetEvent(h, WVE_KEY, (void*)OnKeyCb);
    pKey(118, 0); PumpFor(L"Key118:", 2000);
    Check(Find(L"Key118:Handled=1") >= 0 && g_keyErr == WVERR_REENTRANT, "key callback swallows a key; sync call inside it fails fast", N(g_keyErr));
    p_WV_SetEvent(h, WVE_KEY, nullptr); p_WV_SetStr(h, WVS_BLOCK_KEYS, ""); }
  { p_WV_SetInt(h, WVP_CONTEXT_MENU, 2);
    for (int k = 0; k < 4; ++k) pMenu(k);
    PumpFor(L"Menu3:", 2000);
    auto line = [&](const wchar_t* pre) { int i = Find(pre); return i >= 0 ? A(LogAll()[i]) : std::string("none"); };
    Check(Find(L"Menu0:copy,paste,selectAll Handled=0") >= 0, "simplified menu keeps only edit items", line(L"Menu0:"));
    Check(Find(L"Menu1: Handled=1") >= 0, "menu with nothing left is suppressed", line(L"Menu1:"));
    Check(Find(L"Menu2:cut,copy,|,paste Handled=0") >= 0, "duplicate and trailing separators removed", line(L"Menu2:"));
    Check(Find(L"Menu3:undo,redo Handled=0") >= 0 && Find(L"Menu.BadRemove") < 0, "leading separators removed, no out-of-range removal", line(L"Menu3:"));
    p_WV_SetInt(h, WVP_CONTEXT_MENU, 0); }
  { p_WV_SetEvent(h, WVE_AUTH, (void*)OnAuth); pAuth(L"https://secure.test/");
    Check(PumpFor(L"Deferral.Complete:Auth", 3000), "auth deferral completed");
    int a1 = Find(L"Raised:Auth"), a2 = Find(L"Note:cb-auth"), a3 = Find(L"Auth.UserName=u"), a4 = Find(L"Auth.Password=p"), a5 = Find(L"Deferral.Complete:Auth");
    Check(a1 >= 0 && a1 < a2 && a2 < a3 && a3 < a4 && a4 < a5, "auth order: handler returns, callback, user name, password, complete", N(a1) + "," + N(a2) + "," + N(a3) + "," + N(a4) + "," + N(a5)); }
  { std::string sid = p_WV_AddInitScript(h, "window.x=1");
    Check(sid.compare(0, 7, "script-") == 0 && p_WV_RemoveInitScript(h, sid.c_str()) == 1 && Find(L"RemoveScript:" + std::wstring(sid.begin(), sid.end())) >= 0, "init script added (id returned) and removed", sid);
    p_WV_PostMessage(h, "hello", 0); p_WV_PostMessage(h, "{\"a\":1}", 1);
    Check(Find(L"PostString:hello") >= 0 && Find(L"PostJson:{\"a\":1}") >= 0, "post message as text and as JSON");
    p_WV_Emit(h, "tick", "50"); p_WV_Emit(h, "msg", "hi there");
    int e1 = Find(L"\"n\":\"tick\""), e2 = Find(L"\"n\":\"msg\"");
    Check(e1 >= 0 && e2 >= 0 && LogAll()[e1].find(L"\"t\":\"e\"") != std::wstring::npos && LogAll()[e1].find(L"\"v\":50") != std::wstring::npos && LogAll()[e2].find(L"\"v\":\"hi there\"") != std::wstring::npos,
          "emit: JSON value kept as JSON, plain text sent as a string", e1 >= 0 ? A(LogAll()[e1]) : "none");
    p_WV_NavigateEx(h, "https://post.test/login", "POST", "Content-Type: application/x-www-form-urlencoded", "a=1&b=2", 7);
    Check(PumpFor(L"Committed:https://post.test/login", 3000) && Find(L"CreateRequest:POST https://post.test/login body=7 data=a=1&b=2 headers=Content-Type: application/x-www-form-urlencoded") >= 0,
          "POST navigation carries body and header", Find(L"CreateRequest:") >= 0 ? A(LogAll()[Find(L"CreateRequest:")]) : "none");
    p_WV_Navigate(h, "https://a.test/"); PumpFor(L"Committed:https://a.test/", 3000, CountOf(L"Committed:https://a.test/") + 1);
    p_WV_SetEvent(h, WVE_CDP_EVENT, (void*)OnCdpEvent);
    Check(p_WV_CdpSubscribe(h, "Network.responseReceived", 1) == 1 && Find(L"Cdp.Add:Network.responseReceived") >= 0, "subscribe DevTools event");
    pCdpEvent(L"Network.responseReceived", L"{\"requestId\":\"7\"}");
    Check(PumpFor(L"Note:cb-cdp", 2000) && g_cdpName == "Network.responseReceived" && g_cdpParams == "{\"requestId\":\"7\"}" && Find(L"Note:cb-cdp") > Find(L"Raised:Cdp:Network.responseReceived"),
          "DevTools event delivered after the handler returned", g_cdpParams);
    Check(p_WV_CdpSubscribe(h, "Network.responseReceived", 0) == 1 && Find(L"Cdp.Remove:Network.responseReceived") >= 0, "unsubscribe removes the handler");
    pCdpEvent(L"Network.responseReceived", L"{}"); PumpFor(L"Raised:Cdp:Network.responseReceived", 2000, 2); Pump(100);
    Check(CountOf(L"Note:cb-cdp") == 1, "no event after unsubscribe");
    Check(p_WV_PrintToPdf(h, "C:\\out\\a.pdf", 0, 3000) == 1 && Find(L"PrintToPdf:C:\\out\\a.pdf") >= 0, "print to PDF via ICoreWebView2_7", p_WV_LastError());
    int lr = p_WV_PrintToPdf(h, "C:\\out\\b.pdf", 1, 3000);
    { auto v = LogAll(); int o1 = -1, pb = -1; for (int k = 0; k < (int)v.size(); ++k) { if (v[k] == L"Print.Orientation=1") o1 = k; if (v[k] == L"PrintToPdf:C:\\out\\b.pdf settings=set") pb = k; }
      Check(lr == 1 && o1 >= 0 && pb > o1, "landscape PDF: settings created, orientation set, then printed", N(lr) + " " + N(o1) + "<" + N(pb)); } }
  { struct PS { int prop; const char* name; } ps[] = {{WVP_AUTOFILL, "autofill"}, {WVP_PASSWORD_AUTOSAVE, "password"}, {WVP_ACCELERATOR_KEYS, "accelerators"},
      {WVP_COLOR_SCHEME, "scheme"}, {WVP_MUTED, "mute"}, {WVP_STATUS_BAR, "statusbar"}, {WVP_DEVTOOLS, "devtools"}, {WVP_ZOOM_CONTROL, "zoomcontrol"}, {WVP_EXTERNAL_DROP, "externaldrop"}};
    std::string silent;
    for (auto& q : ps) { int r = p_WV_SetInt(h, q.prop, 0); int e = p_WV_LastErrorCode(); printf("INFO setting %s on a runtime without it -> %d, code %d\n", q.name, r, e); if (r == 1) silent += std::string(q.name) + " "; }
    Check(silent.empty(), "settings the runtime cannot apply report an error instead of silent success", silent); }
  { Check(p_WV_Bind(h, "echo", (void*)OnEcho) == 1, "bind echo after creation");
    int start = pCount(); DWORD t0 = GetTickCount();
    for (int k = 0; k < 3000; ++k) { wchar_t b[96]; swprintf(b, 96, L"{\"__epl\":1,\"t\":\"c\",\"id\":%d,\"n\":\"echo\",\"a\":[%d]}", 100000 + k, k); pSend(b); }
    DWORD tw = GetTickCount(); bool got = false; MSG mm;
    while (GetTickCount() - tw < 30000) { while (PeekMessageW(&mm, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&mm); DispatchMessageW(&mm); } if (Find(L"\"id\":102999,", start) >= 0) { got = true; break; } Sleep(2); }
    auto v = LogAll(); int n = 0, bad = 0, last = -1;
    for (int k = start; k < (int)v.size(); ++k) { size_t i = v[k].find(L"PostJson:{\"__epl\":1,\"t\":\"r\",\"id\":1"); if (i == std::wstring::npos) continue;
      int id = _wtoi(v[k].c_str() + v[k].find(L"\"id\":") + 5), val = _wtoi(v[k].c_str() + v[k].find(L"\"v\":") + 4); if (id <= last || val != id - 100000) ++bad; last = id; ++n; }
    Check(got && n == 3000 && bad == 0, "3000 bridge calls in a burst: all answered, in order, correct values", N(n) + " replies, " + N(bad) + " bad, " + N((int)(GetTickCount() - t0)) + "ms"); }
  { std::atomic<int> done{0}; std::string wr;
    std::thread th([&] { wr = p_WV_ExecScript(h, "1+2", 0, 3000); done = 1; });
    DWORD t0 = GetTickCount(); while (!done && GetTickCount() - t0 < 5000) Pump(5); th.join();
    Check(done == 1 && wr == "3", "ExecScript from a worker thread is marshalled to the UI thread", wr); }
  { int env0 = CountOf(L"CreateEnv:"), scr0 = CountOf(L"AddScript"), nav0 = CountOf(L"Navigate:https://a.test/"), close0 = CountOf(L"Controller.Close");
    p_WV_SetEvent(h, WVE_PROCESS_FAILED, (void*)OnProcFail);
    pFail(0);
    Check(PumpFor(L"Navigate:https://a.test/", 5000, nav0 + 1), "browser process exit: view re-navigates to the last URL");
    Pump(100);
    auto v = LogAll(); int lastScr = -1, lastNav = -1; for (int k = 0; k < (int)v.size(); ++k) { if (v[k] == L"AddScript") lastScr = k; if (v[k] == L"Navigate:https://a.test/") lastNav = k; }
    Check(CountOf(L"CreateEnv:") == env0 + 1 && CountOf(L"Controller.Close") == close0 + 1 && CountOf(L"AddScript") == scr0 + 1, "recovery: old controller closed, new environment, bridge re-registered",
          N(CountOf(L"CreateEnv:") - env0) + "/" + N(CountOf(L"Controller.Close") - close0) + "/" + N(CountOf(L"AddScript") - scr0));
    Check(lastScr >= 0 && lastScr < lastNav, "recovery: bridge registered before re-navigation", N(lastScr) + "<" + N(lastNav));
    Check(g_pf == 1 && p_WV_IsReady(h) == 1, "PROCESS_FAILED callback notified, view ready again", N(g_pf));
    pSend(L"{\"__epl\":1,\"t\":\"c\",\"id\":10,\"n\":\"add\",\"a\":[20,22]}");
    Check(PumpFor(L"\"id\":10,", 3000) && LogAll()[Find(L"\"id\":10,")].find(L"\"v\":42") != std::wstring::npos, "bridge works on the recreated webview"); }
  { HWND host = (HWND)(intptr_t)p_WV_GetWindow(h, 0), before = GetParent(host);
    pFull(1); PumpFor(L"Raised:Fullscreen:1", 2000); Pump(50);
    HWND during = GetParent(host); RECT fr{}; GetWindowRect(during, &fr);
    Check(during && during != before && fr.right - fr.left == GetSystemMetrics(SM_CXSCREEN), "fullscreen: host moved into a screen-sized window", N(fr.right - fr.left));
    pFull(0); PumpFor(L"Raised:Fullscreen:0", 2000); Pump(50);
    RECT hr{}, pr{}; GetWindowRect(host, &hr); GetClientRect(before, &pr);
    Check(GetParent(host) == before && hr.right - hr.left == pr.right, "exit fullscreen: host back in parent and fills it again"); }
  { int hs = p_WV_Create(parent, 10, 10, 200, 150, "https://sync.test/", "", 5000);
    Check(hs > 0 && p_WV_IsReady(hs) == 1 && PumpFor(L"Committed:https://sync.test/", 3000), "synchronous WV_Create with mock runtime", N(hs));
    p_WV_Destroy(hs); }
  { auto envs = [&] { std::vector<std::pair<std::wstring, std::wstring>> r; auto v = LogAll();
      for (size_t k = 0; k < v.size(); ++k) if (v[k].rfind(L"CreateEnv:", 0) == 0) { std::wstring a; for (size_t j = k + 1; j < v.size() && j < k + 4; ++j) if (v[j].rfind(L"Opt.Args=", 0) == 0) a = v[j]; r.push_back({v[k], a}); }
      return r; };
    auto E0 = envs(); size_t e0 = E0.size();
    int q1 = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://p1.test/", "proxy=127.0.0.1:1111", nullptr); p_WV_WaitReady(q1, 5000);
    auto E1 = envs();
    Check(E1.size() == e0 + 1 && E1.back().second.find(L"1111") != std::wstring::npos && E1.back().first != E0[0].first,
          "view with its own proxy gets its own environment and data folder", E1.size() > e0 ? A(E1.back().first + L" | " + E1.back().second) : "none");
    int q2 = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://p2.test/", "", nullptr); p_WV_WaitReady(q2, 5000);
    int q3 = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://p3.test/", "proxy=127.0.0.1:1111", nullptr); p_WV_WaitReady(q3, 5000);
    Check(envs().size() == e0 + 1 && p_WV_IsReady(q2) == 1 && p_WV_IsReady(q3) == 1, "views with the same settings share an environment", N((int)envs().size() - (int)e0));
    int q4 = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://p4.test/", "proxy=127.0.0.1:2222", nullptr); p_WV_WaitReady(q4, 5000);
    auto E4 = envs();
    Check(E4.size() == e0 + 2 && E4.back().second.find(L"2222") != std::wstring::npos && E4.back().first != E1.back().first && E4.back().first != E0[0].first,
          "a different proxy gets another environment and data folder", E4.size() > e0 + 1 ? A(E4.back().first) : "none");
    for (int q : {q1, q2, q3, q4}) p_WV_Destroy(q);
    {  // 创建选项里单独指定的代理含空格时被忽略：一个代理值不能被拆成多个浏览器启动参数
      int qx = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://px.test/", "proxy=127.0.0.1:3333 --disable-web-security", nullptr);
      p_WV_WaitReady(qx, 5000);
      bool injected = false;
      for (auto& l : LogAll()) if (l.find(L"Opt.Args=") != std::wstring::npos && l.find(L"--disable-web-security") != std::wstring::npos) injected = true;
      std::wstring logw;
      HANDLE fh = CreateFileW((ExeDir() + L"\\wv.log").c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
      if (fh != INVALID_HANDLE_VALUE) {
        DWORD sz = GetFileSize(fh, nullptr), rd = 0; std::string b(sz, 0); ReadFile(fh, &b[0], sz, &rd, nullptr); CloseHandle(fh);
        int n = MultiByteToWideChar(CP_UTF8, 0, b.data(), (int)rd, nullptr, 0); logw.resize(n); MultiByteToWideChar(CP_UTF8, 0, b.data(), (int)rd, &logw[0], n);
      }
      Check(!injected && logw.find(L"代理地址含空格") != std::wstring::npos, "per-view proxy with spaces is ignored and cannot inject browser switches", N(injected));
      p_WV_Destroy(qx);
    }
    Pump(100); }
  int closeBefore = CountOf(L"Controller.Close");
  Check(p_WV_Destroy(h) == 1 && PumpFor(L"Controller.Close", 2000, closeBefore + 1) && p_WV_IsReady(h) == -1, "destroy closes controller");
  int h2 = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://b.test/", "", nullptr);
  Check(p_WV_WaitReady(h2, 5000) == 1 && PumpFor(L"Committed:https://b.test/", 3000), "second view without bridge navigates immediately");
  Check(Find(L"Navigate:https://b.test/") >= 0, "second view navigated");
  { char o3[64]; sprintf(o3, "ev%d=%d", WVE_NEW_WINDOW, (int)(intptr_t)OnNewWinDestroy);
    int h3 = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://c.test/", o3, nullptr);
    Check(p_WV_WaitReady(h3, 5000) == 1 && PumpFor(L"Committed:https://c.test/", 3000), "third view ready");
    int close0 = CountOf(L"Controller.Close"), comp0 = CountOf(L"Deferral.Complete:NewWindow");
    pNewWin(L"https://popup2.test/");
    Check(PumpFor(L"Controller.Close", 3000, close0 + 1) && CountOf(L"Deferral.Complete:NewWindow") == comp0 + 1 && CountOf(L"Deferral.DoubleComplete") == 0 && p_WV_IsReady(h3) == -1 && g_nwDestroy == 1,
          "destroy inside NewWindow callback: deferral completed once, view closed after the callback", N(CountOf(L"Deferral.Complete:NewWindow") - comp0));
    auto v = LogAll(); int nd = -1, cl = -1; for (int k = 0; k < (int)v.size(); ++k) { if (v[k] == L"Note:cb-nw-destroy") nd = k; if (v[k] == L"Controller.Close") cl = k; }
    Check(nd >= 0 && cl > nd, "controller closed only after the callback returned", N(nd) + "<" + N(cl)); }
  { int cc0 = CountOf(L"CreateController"), close0 = CountOf(L"Controller.Close");
    int ha = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://early.test/", "", nullptr);
    bool syncCtl = CountOf(L"CreateController") == cc0 + 1;
    Check(p_WV_Destroy(ha) == 1, "destroy right after async create (environment cached)");
    Pump(400);
    Check(syncCtl && CountOf(L"Controller.Close") == close0 + 1 && Find(L"Navigate:https://early.test/") < 0, "late controller closed at once, no navigation", N(CountOf(L"Controller.Close") - close0));
    int env0 = CountOf(L"CreateEnv:"); cc0 = CountOf(L"CreateController");
    int hb = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://early2.test/", "proxy=127.0.0.1:3333", nullptr);
    Check(CountOf(L"CreateEnv:") == env0 + 1 && p_WV_Destroy(hb) == 1, "destroy while its environment is still being created");
    Pump(400);
    Check(CountOf(L"CreateController") == cc0 && Find(L"Navigate:https://early2.test/") < 0, "no controller for a view destroyed before its environment was ready"); }
  { char o[64]; sprintf(o, "ev%d=%d", WVE_NEW_WINDOW, (int)(intptr_t)OnNewWinTarget);
    int hn = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://opener.test/", o, nullptr);
    Check(p_WV_WaitReady(hn, 5000) == 1 && PumpFor(L"Committed:https://opener.test/", 3000), "opener ready");
    int put0 = CountOf(L"NewWindow.put_NewWindow"), comp0 = CountOf(L"Deferral.Complete:NewWindow"), navs0 = CountOf(L"Navigate:");
    pNewWin(L"https://popup3.test/");
    Check(PumpFor(L"Deferral.Complete:NewWindow", 5000, comp0 + 1) && CountOf(L"NewWindow.put_NewWindow") == put0 + 1, "popup handed to a browser created inside the callback");
    auto v = LogAll(); int pp = -1, hd = -1, cp = -1;
    for (int k = 0; k < (int)v.size(); ++k) { if (v[k] == L"NewWindow.put_NewWindow") pp = k; if (v[k] == L"NewWindow.Handled=1") hd = k; if (v[k] == L"Deferral.Complete:NewWindow") cp = k; }
    Check(pp >= 0 && pp < hd && hd < cp, "put_NewWindow, Handled, then Complete", N(pp) + "," + N(hd) + "," + N(cp));
    Check(p_WV_IsReady(g_target) == 1 && CountOf(L"Navigate:") == navs0, "target browser ready and did not navigate by itself", N(CountOf(L"Navigate:") - navs0));
    // 1.4.1：弹窗目标的浏览器进程退出后，恢复时按它最后的网址重新打开（原来恢复后一直是空白页）
    int nt0 = CountOf(L"Committed:https://popup3.test/page");
    p_WV_Navigate(g_target, "https://popup3.test/page");
    PumpFor(L"Committed:https://popup3.test/page", 3000, nt0 + 1);
    int nn0 = CountOf(L"Navigate:https://popup3.test/page");
    pFail(0);  // COREWEBVIEW2_PROCESS_FAILED_KIND_BROWSER_PROCESS_EXITED
    Check(PumpFor(L"Navigate:https://popup3.test/page", 5000, nn0 + 1) && p_WV_WaitReady(g_target, 3000) == 1, "a popup target whose browser process exited reopens its last page when it recovers",
          N(CountOf(L"Navigate:https://popup3.test/page") - nn0));
    p_WV_Destroy(g_target); p_WV_Destroy(hn); Pump(100); }
  { pEnvLevel(6);
    int hp = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://prof.test/", "profile=work", nullptr);
    int w = p_WV_WaitReady(hp, 3000);
    Check(w == 0 && p_WV_IsReady(hp) == -1 && Find(L"Navigate:https://prof.test/") < 0, "profile on a runtime without controller options: creation fails instead of silently using the default profile", N(w));
    std::string dg = p_WV_GetDiagnostics(); Check(dg.find("101") != std::string::npos, "failure reason mentions the required runtime version");
    p_WV_Destroy(hp);
    pEnvLevel(10);
    int hq = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://prof2.test/", "profile=work\r\ninprivate=1", nullptr);
    Check(p_WV_WaitReady(hq, 5000) == 1 && Find(L"CreateControllerWithOptions:profile=work inprivate=1") >= 0 && PumpFor(L"Committed:https://prof2.test/", 3000), "profile and InPrivate passed through controller options");
    p_WV_Destroy(hq); Pump(100); }
  { int hv = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://old.test/", "", nullptr);
    Check(p_WV_WaitReady(hv, 5000) == 1 && PumpFor(L"Committed:https://old.test/", 3000), "view for old-runtime checks ready");
    pWvLevel(1);
    std::string bad; std::wstring ui = app + L"\\ui"; std::string uiA = A(ui);
    auto expect = [&](const char* what, bool failed) { int e = p_WV_LastErrorCode(); printf("INFO old runtime: %s -> %s, code %d\n", what, failed ? "failed" : "SUCCEEDED", e); if (!failed || e != WVERR_UNSUPPORTED) bad += std::string(what) + " "; };
    expect("SetResponseCapture", p_WV_SetResponseCapture(hv, "*", 0) == 0);
    expect("GetCookies", std::string(p_WV_GetCookies(hv, "", 1)).empty());
    expect("SetCookie", p_WV_SetCookie(hv, "https://old.test/", "a", "1", "", "", 0, 0) == 0);
    expect("MapFolder", p_WV_MapFolder(hv, "x.local", uiA.c_str(), 1) == 0);
    expect("PrintToPdf", p_WV_PrintToPdf(hv, "C:\\out\\c.pdf", 0, 1000) == 0);
    expect("Suspend", p_WV_Command(hv, WVC_SUSPEND) == 0);
    expect("TaskManager", p_WV_Command(hv, WVC_TASK_MANAGER) == 0);
    expect("POST navigation", p_WV_NavigateEx(hv, "https://post2.test/", "POST", "", "x=1", 3) == 0);
    expect("Mute", p_WV_SetInt(hv, WVP_MUTED, 1) == 0);
    Pump(200);
    Check(bad.empty() && Find(L"Navigate:https://post2.test/") < 0, "on an old runtime every newer feature reports UNSUPPORTED; POST is not silently turned into GET", bad);
    pWvLevel(11); p_WV_Destroy(hv); Pump(100); }
  { pFailEnv((int)0x80070005);
    int hf = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://retry.test/", "proxy=127.0.0.1:4444", nullptr);
    Check(p_WV_WaitReady(hf, 3000) == 0 && p_WV_IsReady(hf) == -1 && Find(L"CreateEnv.Fail") >= 0, "environment creation failure reported");
    HWND hf0 = (HWND)(intptr_t)p_WV_GetWindow(hf, 0); InvalidateRect(hf0, nullptr, TRUE); UpdateWindow(hf0);
    RECT rc; GetClientRect(hf0, &rc); std::vector<RECT> btn;
    for (int y = 0; y < rc.bottom; y += 3) for (int x = 0; x < rc.right; x += 3) {
      SendMessageW(hf0, WM_MOUSEMOVE, 0, MAKELPARAM(x, y));
      if (!SendMessageW(hf0, WM_SETCURSOR, (WPARAM)hf0, MAKELPARAM(HTCLIENT, WM_MOUSEMOVE))) continue;
      bool merged = false;
      for (auto& b : btn) if (x >= b.left - 6 && x <= b.right + 6 && y >= b.top - 6 && y <= b.bottom + 6) { b.left = std::min(b.left, (LONG)x); b.right = std::max(b.right, (LONG)x); b.top = std::min(b.top, (LONG)y); b.bottom = std::max(b.bottom, (LONG)y); merged = true; break; }
      if (!merged) btn.push_back({x, y, x, y});
    }
    SendMessageW(hf0, WM_MOUSEMOVE, 0, MAKELPARAM(1, 1));
    std::sort(btn.begin(), btn.end(), [](const RECT& a, const RECT& b) { return a.left < b.left; });
    Check(btn.size() == 2, "failure card shows two clickable buttons (retry, copy)", N((int)btn.size()));
    auto click = [&](const RECT& b) { int cx = (b.left + b.right) / 2, cy = (b.top + b.bottom) / 2;
      SendMessageW(hf0, WM_MOUSEMOVE, 0, MAKELPARAM(cx, cy)); SendMessageW(hf0, WM_LBUTTONDOWN, MK_LBUTTON, MAKELPARAM(cx, cy)); SendMessageW(hf0, WM_LBUTTONUP, 0, MAKELPARAM(cx, cy)); };
    if (btn.size() == 2) {
      if (OpenClipboard(nullptr)) { EmptyClipboard(); CloseClipboard(); }
      click(btn[1]); Pump(50);
      std::wstring clip; if (OpenClipboard(nullptr)) { HANDLE d = GetClipboardData(CF_UNICODETEXT); if (d) { const wchar_t* q = (const wchar_t*)GlobalLock(d); if (q) clip = q; GlobalUnlock(d); } CloseClipboard(); }
      Check(clip.find(L"WebView2Bridge \u8BCA\u65AD\u4FE1\u606F") != std::wstring::npos && clip.find(L"\u73AF\u5883\u521B\u5EFA\u5931\u8D25") != std::wstring::npos,
            "copy button puts the diagnostics (with the failure reason) on the clipboard", A(clip.substr(0, 60)));
      int env0 = CountOf(L"CreateEnv:");
      click(btn[0]);
      Check(p_WV_WaitReady(hf, 5000) == 1 && CountOf(L"CreateEnv:") == env0 + 1 && PumpFor(L"Committed:https://retry.test/", 3000), "retry button recreates the environment and the view recovers");
    }
    typedef DWORD(WINAPI* GGR)(HANDLE, DWORD); GGR ggr = (GGR)(void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetGuiResources");
    int hz = p_WV_CreateAsync(parent, 0, 0, 0, 0, "", "proxy=127.0.0.1:5555", nullptr); pFailEnv(0);
    (void)hz; Pump(50);
    DWORD g0 = ggr ? ggr(GetCurrentProcess(), 0) : 0;
    for (int k = 0; k < 300; ++k) { InvalidateRect(hf0, nullptr, TRUE); UpdateWindow(hf0); }
    DWORD g1 = ggr ? ggr(GetCurrentProcess(), 0) : 0;
    printf("INFO GDI objects before/after 300 repaints: %lu -> %lu\n", g0, g1);
    if (g0) Check(g1 <= g0 + 2, "300 repaints do not leak GDI objects", N((int)g0) + " -> " + N((int)g1));
    p_WV_Destroy(hz); p_WV_Destroy(hf); Pump(100); }
  { // 网页标题栏（app-region）：新内核上创建选项在首次导航之前交给 WebView2（文档：改动在下一次导航后生效），之后可读回、可关闭；
    // 旧内核没有 ICoreWebView2Settings9，如实报告不支持
    IntFn pSetLv = (IntFn)(void*)GetProcAddress(g_mock, "Mock_SetSettingsLevel");
    pSetLv(9);
    int hn = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://nc.test/", "nonclient=1", nullptr);
    bool ready = p_WV_WaitReady(hn, 5000) == 1 && PumpFor(L"Committed:https://nc.test/", 3000);
    int iNc = Find(L"Settings.NonClient=1"), iNav = Find(L"Navigate:https://nc.test/");
    Check(ready && iNc >= 0 && iNav > iNc, "non-client region option reaches WebView2 before the first navigation", N(iNc) + "/" + N(iNav));
    Check(p_WV_GetInt(hn, WVP_NONCLIENT_REGION) == 1, "non-client region setting reads back", N(p_WV_GetInt(hn, WVP_NONCLIENT_REGION)));
    Check(p_WV_SetInt(hn, WVP_NONCLIENT_REGION, 0) == 1 && Find(L"Settings.NonClient=0") >= 0 && p_WV_GetInt(hn, WVP_NONCLIENT_REGION) == 0,
          "non-client region can be turned off after creation");
    p_WV_Destroy(hn); Pump(100);
    pSetLv(1);
    int ho = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://nc-old.test/", "", nullptr);
    p_WV_WaitReady(ho, 5000);
    int r = p_WV_SetInt(ho, WVP_NONCLIENT_REGION, 1), e = p_WV_LastErrorCode();
    Check(r == 0 && e == WVERR_UNSUPPORTED, "old runtime reports the non-client region setting as unsupported", N(r) + "/" + N(e));
    p_WV_Destroy(ho); Pump(100); }
  { // 提示卡片的键盘操作与读屏：方向键移动焦点，回车/空格执行；卡片内容写在宿主窗口名称里
    pFailEnv((int)0x80070005);
    int hk = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://kbd.test/", "proxy=127.0.0.1:6666", nullptr);
    p_WV_WaitReady(hk, 3000);
    pFailEnv(0);
    HWND hk0 = (HWND)(intptr_t)p_WV_GetWindow(hk, 0);
    wchar_t name[512] = {0};
    GetWindowTextW(hk0, name, 511);
    Check(p_WV_IsReady(hk) == -1 && wcsstr(name, L"\u7F51\u9875\u7EC4\u4EF6\u6CA1\u80FD\u542F\u52A8") != nullptr && wcsstr(name, L"\u73AF\u5883\u521B\u5EFA\u5931\u8D25") != nullptr,
          "failure card text is exposed as the host window name (screen readers)", A(name).substr(0, 60));
    MSG dm = {hk0, WM_KEYDOWN, VK_RETURN, 0, 0, {0, 0}};
    LRESULT code = SendMessageW(hk0, WM_GETDLGCODE, VK_RETURN, (LPARAM)&dm);
    Check((code & DLGC_WANTARROWS) && (code & DLGC_WANTMESSAGE), "card asks the dialog manager for arrows and Enter", N((int)code));
    SetFocus(hk0);
    if (OpenClipboard(nullptr)) { EmptyClipboard(); CloseClipboard(); }
    SendMessageW(hk0, WM_KEYDOWN, VK_RIGHT, 0);   // 焦点：重试 → 复制诊断信息
    SendMessageW(hk0, WM_KEYDOWN, VK_RETURN, 0);  // 回车执行复制
    Pump(50);
    std::wstring clip; if (OpenClipboard(nullptr)) { HANDLE d = GetClipboardData(CF_UNICODETEXT); if (d) { const wchar_t* q = (const wchar_t*)GlobalLock(d); if (q) clip = q; GlobalUnlock(d); } CloseClipboard(); }
    Check(clip.find(L"WebView2Bridge \u8BCA\u65AD\u4FE1\u606F") != std::wstring::npos, "Right arrow + Enter activates the copy link", A(clip.substr(0, 40)));
    int env0 = CountOf(L"CreateEnv:");
    SendMessageW(hk0, WM_KEYDOWN, VK_LEFT, 0);   // 焦点回到“重试”
    SendMessageW(hk0, WM_KEYDOWN, VK_SPACE, 0);  // 空格执行重试
    Check(p_WV_WaitReady(hk, 5000) == 1 && CountOf(L"CreateEnv:") == env0 + 1, "Left arrow + Space activates retry and the view recovers");
    GetWindowTextW(hk0, name, 511);
    Check(name[0] == 0, "host window name cleared once the browser is ready", A(name));
    p_WV_Destroy(hk); Pump(100); }
  { // 内核崩溃且关闭了自动恢复：显示“页面意外关闭了”卡片；关闭了提示卡片时不画任何卡片（交给程序处理“进程崩溃”事件）
    auto crash = [&](const char* opts, std::wstring& name) {
      int hc = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://crash.test/", opts, nullptr);
      bool ok = p_WV_WaitReady(hc, 5000) == 1;
      HWND hc0 = (HWND)(intptr_t)p_WV_GetWindow(hc, 0);
      pFail(0);  // COREWEBVIEW2_PROCESS_FAILED_KIND_BROWSER_PROCESS_EXITED
      Pump(200);
      wchar_t nm[512] = {0};
      GetWindowTextW(hc0, nm, 511);
      name = nm;
      p_WV_Destroy(hc); Pump(100);
      return ok;
    };
    std::wstring on, off;
    bool r1 = crash("recover=0", on), r2 = crash("recover=0\nfallback=0", off);
    Check(r1 && on.find(L"\u9875\u9762\u610F\u5916\u5173\u95ED\u4E86") != std::wstring::npos, "browser crash with auto-recover off shows the crash card", A(on.substr(0, 30)));
    Check(r2 && off.empty(), "with the prompt card turned off, a browser crash draws no card", A(off.substr(0, 30))); }
  { // 文本统一为 UTF-8（易语言类就是这样用的）：代码页 65001、JSON 按系统 ANSI 代码页转义、回调经转发
    const std::string hook = std::to_string((unsigned long long)(uintptr_t)&TestHook);
    Check(p_WV_SetOption(WVO_CODEPAGE, "65001") == 1 && p_WV_SetOption(WVO_JSON_ESCAPE, "1") == 1 && p_WV_SetOption(WVO_CALLBACK_HOOK, hook.c_str()) == 1,
          "UTF-8 mode, JSON escaping for the ANSI code page and the callback hook can be set");
    Check(p_WV_SetOption(WVO_JSON_ESCAPE, "3") == 0 && p_WV_SetOption(WVO_CALLBACK_HOOK, "12ab") == 0 && std::string(p_WV_GetOption(WVO_CALLBACK_HOOK)) == hook &&
          std::string(p_WV_GetOption(WVO_JSON_ESCAPE)) == "1", "invalid JSON escape mode or hook address rejected, settings read back");
    const std::string opts = std::string("bind:\xE5\x8A\xA0=") + std::to_string((unsigned long long)(uintptr_t)&OnU8Bind);  // 绑定“加”，选项文本是 UTF-8
    int hu = p_WV_CreateAsync(parent, 0, 0, 0, 0, "https://u8.test/", opts.c_str(), nullptr);
    Check(p_WV_WaitReady(hu, 5000) == 1, "browser created with UTF-8 options");
    p_WV_SetEvent(hu, WVE_SCRIPT_DIALOG, (void*)OnU8Dialog);
    p_WV_SetEvent(hu, WVE_CDP_EVENT, (void*)OnU8Cdp);
    p_WV_CdpSubscribe(hu, "Network.u8", 1);
    Pump(100);
    g_hookLog.clear();
    pDialog(0, L"\u6D88\u606F\u4E2D\u6587", L"");  // 消息中文（第三个参数是 prompt 的默认文本，网址由模拟内核给出）
    PumpFor(L"Deferral.Complete:Dialog", 3000); Pump(50);
    const HookRec* dl = nullptr;
    for (auto& r : g_hookLog) if (r.ev == WVE_SCRIPT_DIALOG) dl = &r;
    Check(dl && dl->argc == 5 && dl->mask == ((1u << 2) | (1u << 3)) && dl->texts.size() == 2 && dl->texts[0] == "\xE6\xB6\x88\xE6\x81\xAF\xE4\xB8\xAD\xE6\x96\x87" &&
          g_u8DlgMsg == dl->texts[0] && !g_u8DlgUrl.empty() && g_u8DlgUrl == dl->texts[1] && Find(L"Dialog.Accept") >= 0,
          "hook gets the dialog event with UTF-8 texts and the right mask; the callback's out-parameter reaches the DLL", dl ? N(dl->argc) + " mask " + N((int)dl->mask) + " msg=" + Hex(g_u8DlgMsg) + " url=" + g_u8DlgUrl : "no hook call");
    // 1.7.9：按 WVE_FLAG_NO_OUT 注册的事件经转发调用时，参数个数不含最后的 int*（对话框为 4 个），回填照样用 WV_EvSetInt
    p_WV_SetEvent(hu, WVE_SCRIPT_DIALOG | WVE_FLAG_NO_OUT, (void*)OnDialogNoOut);
    g_hookLog.clear();
    const int baseH = (int)LogAll().size(), doneH = CountOf(L"Deferral.Complete:Dialog");
    pDialog(1, L"sure?", L"");
    PumpFor(L"Deferral.Complete:Dialog", 3000, doneH + 1); Pump(50);
    const HookRec* dn = nullptr;
    for (auto& r : g_hookLog) if (r.ev == WVE_SCRIPT_DIALOG) dn = &r;
    Check(dn && dn->argc == 4 && dn->mask == ((1u << 2) | (1u << 3)) && Find(L"Dialog.Accept", baseH) < 0,
          "through the hook, a no-out event is called with its 4 read-only parameters and WVK_CANCEL still answers the dialog", dn ? N(dn->argc) : std::string("no hook call"));
    p_WV_SetEvent(hu, WVE_SCRIPT_DIALOG, (void*)OnU8Dialog);
    pCdpEvent(L"Network.u8", L"{\"v\":\"\u503C\U0001F600\"}");  // 值😀
    PumpFor(L"Raised:Cdp:Network.u8", 2000, 1); Pump(100);
    const std::string wantCdp = "{\"v\":\"" + Esc1(L"\u503C\U0001F600") + "\"}";
    Check(g_u8CdpName == "Network.u8" && g_u8CdpParams == wantCdp, "CDP event JSON escapes only what the ANSI code page cannot hold (emoji survives the trip back to ANSI)", g_u8CdpParams);
    pSend(L"{\"__epl\":1,\"t\":\"c\",\"id\":31,\"n\":\"\u52A0\",\"a\":[\"\u4E2D\u6587\U0001F600\"]}");
    Check(PumpFor(L"\"id\":31", 3000), "bound function with a Chinese name answered");
    int iu = Find(L"\"id\":31"); std::wstring rep = iu >= 0 ? LogAll()[iu] : L"";
    Check(g_u8BindName == "\xE5\x8A\xA0" && g_u8BindArgs == "[\"" + Esc1(L"\u4E2D\u6587\U0001F600") + "\"]" && rep.find(L"\"v\":\"\u597D\"") != std::wstring::npos,
          "bind callback gets UTF-8 name and JSON; its UTF-8 result reaches the page intact", g_u8BindArgs);
    bool hookSaw = false;
    for (auto& r : g_hookLog) if (r.ev == WVE_JS_CALL && r.mask == ((1u << 1) | (1u << 2)) && r.argc == 4) hookSaw = true;
    Check(hookSaw, "bound-function calls go through the hook with the JS-call mask");
    // JSON 三种转义方式与严格的 UTF-8 解码
    const char* zhEmoji = "\xE4\xB8\xAD\xF0\x9F\x98\x80";  // 中😀
    std::string q1 = p_WV_JsonQuote(zhEmoji);
    p_WV_SetOption(WVO_JSON_ESCAPE, "2"); std::string q2 = p_WV_JsonQuote(zhEmoji);
    p_WV_SetOption(WVO_JSON_ESCAPE, "0"); std::string q0 = p_WV_JsonQuote(zhEmoji);
    Check(q1 == "\"" + Esc1(L"\u4E2D\U0001F600") + "\"" && q2 == "\"\\u4e2d\\ud83d\\ude00\"" && q0 == std::string("\"") + zhEmoji + "\"",
          "JSON escaping: 1 = what ANSI cannot hold, 2 = all non-ASCII, 0 = none in UTF-8 mode", q1 + " | " + q2 + " | " + q0);
    std::string bad = p_WV_JsonQuote("\xD6\xD0\xCE\xC4");  // 误传了 GBK 的“中文”
    wchar_t wb[8] = {0}; MultiByteToWideChar(CP_ACP, 0, "\xD6\xD0\xCE\xC4", -1, wb, 8);
    char ub[32] = {0}; WideCharToMultiByte(CP_UTF8, 0, wb, -1, ub, 32, nullptr, nullptr);
    Check(bad == std::string("\"") + ub + "\"" && bad.find("\xEF\xBF\xBD") == std::string::npos, "invalid UTF-8 input falls back to the ANSI code page instead of replacement characters", bad);
    // 高地址时易语言给出的是负数（与创建选项里的回调地址相同的约定）；设置后立即清除，期间不处理消息，不会真的被调用
    bool neg = p_WV_SetOption(WVO_CALLBACK_HOOK, "-2") == 1 && std::string(p_WV_GetOption(WVO_CALLBACK_HOOK)) == "4294967294";
    bool range = p_WV_SetOption(WVO_CALLBACK_HOOK, "4294967296") == 0 && p_WV_SetOption(WVO_CALLBACK_HOOK, "-2147483649") == 0 && p_WV_SetOption(WVO_CALLBACK_HOOK, "-") == 0;
    p_WV_SetOption(WVO_CALLBACK_HOOK, "");
    Check(neg && range, "hook address accepts negative decimal like other callback addresses, rejects out-of-range values");
    p_WV_SetOption(WVO_CALLBACK_HOOK, ""); p_WV_SetOption(WVO_JSON_ESCAPE, ""); p_WV_SetOption(WVO_CODEPAGE, "");
    Check(std::string(p_WV_GetOption(WVO_CALLBACK_HOOK)).empty(), "hook can be removed");
    p_WV_Destroy(hu); Pump(100); }
  DestroyWindow(parent);
  Check(PumpFor(L"Controller.Close", 2000, 2) && p_WV_IsReady(h2) == -1, "parent destroyed first: controller closed, view removed");
  Pump(200);
  { Pump(100); HANDLE fh = CreateFileW((ExeDir() + L"\\wv.log").c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
    std::string lb; if (fh != INVALID_HANDLE_VALUE) { DWORD n = 0; char buf[65536]; while (ReadFile(fh, buf, sizeof(buf), &n, nullptr) && n) lb.append(buf, n); CloseHandle(fh); }
    bool utf8 = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, lb.data(), (int)lb.size(), nullptr, 0) > 0;
    printf("INFO log file: %d bytes, BOM %d, valid UTF-8 %d, first line: %s\n", (int)lb.size(), lb.rfind("\xEF\xBB\xBF", 0) == 0, utf8, lb.substr(lb.rfind("\xEF\xBB\xBF", 0) == 0 ? 3 : 0, 60).c_str());
    Check(!lb.empty() && lb.rfind("\xEF\xBB\xBF", 0) == 0 && lb.find("\xEF\xBB\xBF", 3) == std::string::npos && utf8 && lb.find("\xE5\xB0\xB1\xE7\xBB\xAA") != std::string::npos,
          "diagnostic log: one UTF-8 BOM at the start, readable Chinese"); }
  printf("---- mock log (%d entries)\n", pCount());
  for (auto& l : LogAll()) printf("  %s\n", A(l.substr(0, 110)).c_str());
  {  // 焦点：Tab 进入网页时按方向聚焦首尾元素；网页里 Tab 到尽头时把焦点交给窗口里的下一个/上一个控件
    typedef void(__stdcall* ReasonFn)(int);
    typedef int(__stdcall* LiveFn)();
    typedef const wchar_t*(__stdcall* ReportFn)();
    ReasonFn pFocusReq = (ReasonFn)(void*)GetProcAddress(g_mock, "Mock_MoveFocusRequested");
    LiveFn pLive = (LiveFn)(void*)GetProcAddress(g_mock, "Mock_Live");
    ReportFn pReport = (ReportFn)(void*)GetProcAddress(g_mock, "Mock_LiveReport");
    WNDCLASSW fc = {}; fc.lpfnWndProc = DefWindowProcW; fc.hInstance = GetModuleHandleW(nullptr); fc.lpszClassName = L"WvFocusTest"; RegisterClassW(&fc);
    HWND fw = CreateWindowExW(WS_EX_CONTROLPARENT, L"WvFocusTest", L"focus", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 500, 400, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    int hf = p_WV_Create(fw, 0, 0, 300, 200, "https://focus.test/", "", 5000);
    HWND host = (HWND)(intptr_t)p_WV_GetWindow(hf, 0);
    HWND b1 = CreateWindowExW(0, L"BUTTON", L"b1", WS_CHILD | WS_VISIBLE | WS_TABSTOP, 310, 10, 80, 30, fw, nullptr, nullptr, nullptr);
    HWND b2 = CreateWindowExW(0, L"BUTTON", L"b2", WS_CHILD | WS_VISIBLE | WS_TABSTOP, 310, 50, 80, 30, fw, nullptr, nullptr, nullptr);
    BYTE ks[256]; GetKeyboardState(ks);
    auto keys = [&](bool tab, bool shift) { ks[VK_TAB] = tab ? 0x80 : 0; ks[VK_SHIFT] = shift ? 0x80 : 0; SetKeyboardState(ks); };
    int n0 = CountOf(L"Controller.MoveFocus:0"), n1 = CountOf(L"Controller.MoveFocus:1"), n2 = CountOf(L"Controller.MoveFocus:2");
    keys(true, false); SetFocus(b1); SetFocus(host);
    keys(true, true); SetFocus(b1); SetFocus(host);
    keys(false, false); SetFocus(b1); SetFocus(host);
    Check(CountOf(L"Controller.MoveFocus:1") == n1 + 1 && CountOf(L"Controller.MoveFocus:2") == n2 + 1 && CountOf(L"Controller.MoveFocus:0") == n0 + 1,
          "focus into the page: Tab -> first element, Shift+Tab -> last element, otherwise previous focus",
          N(CountOf(L"Controller.MoveFocus:1") - n1) + "/" + N(CountOf(L"Controller.MoveFocus:2") - n2) + "/" + N(CountOf(L"Controller.MoveFocus:0") - n0));
    pFocusReq(1); HWND f1 = GetFocus();
    SetFocus(host); pFocusReq(2); HWND f2 = GetFocus();
    Check(f1 == b1 && f2 == b2, "Tab out of the page moves focus to the next / previous control in the window", N(f1 == b1) + N(f2 == b2));
    DestroyWindow(b1); DestroyWindow(b2);
    SetFocus(host); int h0 = CountOf(L"MoveFocusRequested:1:Handled=0"); pFocusReq(1);
    Check(CountOf(L"MoveFocusRequested:1:Handled=0") == h0 + 1 && GetFocus() == host, "browser is the only control: focus stays in the page");
    p_WV_Destroy(hf); Pump(200);
    // COM 引用不泄漏：反复创建、使用、销毁浏览器，模拟运行时里存活的对象数不再增长
    auto cycle = [&]() {
      int hc = p_WV_Create(fw, 0, 0, 300, 200, "https://cycle.test/", "", 5000);
      p_WV_ExecScript(hc, "1+1", 0, 3000);
      pSend(L"{\"__epl\":1,\"t\":\"c\",\"id\":900,\"n\":\"nope\",\"a\":[]}"); PumpFor(L"\"id\":900,", 2000, CountOf(L"\"id\":900,") + 1);
      pNewWin(L"https://cyclepop.test/"); PumpFor(L"Deferral.Complete:NewWindow", 2000, CountOf(L"Deferral.Complete:NewWindow") + 1);
      p_WV_Navigate(hc, "https://cycle2.test/"); PumpFor(L"Committed:https://cycle2.test/", 2000, CountOf(L"Committed:https://cycle2.test/") + 1);
      p_WV_Destroy(hc); Pump(150);
    };
    cycle(); cycle(); Pump(300);
    int base = pLive();
    {  // 检测器本身要能看到对象：浏览器存活期间存活对象数应明显增加，销毁后回落
      int hc = p_WV_Create(fw, 0, 0, 300, 200, "https://cycle.test/", "", 5000);
      int during = pLive(); std::wstring rep = pReport();
      p_WV_Destroy(hc); Pump(300);
      printf("INFO live objects: base %d, with one view %d, after destroy %d\nINFO with one view: %s\n", base, during, pLive(), A(rep).c_str());
      Check(during > base && pLive() == base, "leak detector sees the view's objects and their release", N(base) + "/" + N(during) + "/" + N(pLive()));
    }
    for (int i = 0; i < 8; ++i) cycle();
    Pump(500);
    int after = pLive();
    Check(after == base, "no COM objects leak across 8 create/use/destroy cycles", N(base) + "->" + N(after) + " | " + A(pReport()));
    DestroyWindow(fw);
  }
  HWND dw = CreateWindowExW(0, L"MockParent", L"dom", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 400, 300, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
  int hd = p_WV_Create(dw, 0, 0, 0, 0, "https://dom.test/", "", 5000);
  Check(hd > 0 && p_WV_IsReady(hd) == 1, "view for the DOM checks created");
  {  // 元素动作没能完成（页面脚本返回 false）时 取最后错误 给出原因；“元素是否存在”返回假不是错误
    struct C { int act; const char* val; int code; } cs[] = {{WVD_SELECT, "x", WVERR_NOT_FOUND}, {WVD_SUBMIT, "", WVERR_NOT_FOUND}, {WVD_CHECK, "0", WVERR_FAILED}, {WVD_SET_VALUE, "v", WVERR_UNSUPPORTED}, {WVD_CLICK, "", WVERR_FAILED}};
    std::string bad;
    for (auto& c : cs) {
      std::string r = p_WV_Dom(hd, c.act, "#refuse", c.val, 0); int e = p_WV_LastErrorCode(); std::string m = p_WV_LastError();
      if (r != "false" || e != c.code || m.empty()) bad += N(c.act) + ":" + r + "/" + N(e) + " ";
    }
    std::string r = p_WV_Dom(hd, WVD_EXISTS, "#refuse", "", 0); int e = p_WV_LastErrorCode();
    Check(bad.empty() && r == "false" && e == 0, "a DOM action that cannot be done reports why (select, submit, check, set value); exists=false is not an error", bad + "exists:" + r + "/" + N(e));
  }
  {  // 输入文本：元素没聚焦上就不输入（否则文字进到原来有焦点的别的输入框）；聚焦失败给出原因
    int t0 = CountOf(L"Input.insertText");
    std::string r0 = p_WV_Dom(hd, WVD_TYPE_TEXT, "#refuse", "secret", 0); int e0 = p_WV_LastErrorCode();
    std::string r1 = p_WV_Dom(hd, WVD_FOCUS, "#refuse", "", 0); int e1 = p_WV_LastErrorCode();
    Check(r0.empty() && e0 == WVERR_FAILED && CountOf(L"Input.insertText") == t0 && r1 == "false" && e1 == WVERR_FAILED,
          "type text into an element that cannot take focus: refused with a reason and nothing typed; failed focus reports why", r0 + "/" + N(e0) + "/" + N(CountOf(L"Input.insertText") - t0) + "/" + r1 + "/" + N(e1));
  }
  {  // 表单校验没通过时不算提交成功；真实点击遇到禁用的元素不点
    std::string r0 = p_WV_Dom(hd, WVD_SUBMIT, "#invalid", "", 0); int e0 = p_WV_LastErrorCode();
    int m0 = CountOf(L"Input.dispatchMouseEvent");
    std::string r1 = p_WV_Dom(hd, WVD_TRUSTED_CLICK, "#disabledbtn", "", 0); int e1 = p_WV_LastErrorCode();
    Check(r0 == "false" && e0 == WVERR_FAILED && r1.empty() && e1 == WVERR_FAILED && CountOf(L"Input.dispatchMouseEvent") == m0,
          "submit blocked by form validation reports false with a reason; trusted click on a disabled element is refused without a mouse event", r0 + "/" + N(e0) + "/" + r1 + "/" + N(e1));
  }
  {  // 真实点击：隐藏或大小为 0 的元素不点（否则会点到左上角的别的东西），并给出原因；正常元素点在中心
    int m0 = CountOf(L"Input.dispatchMouseEvent");
    std::string r0 = p_WV_Dom(hd, WVD_TRUSTED_CLICK, "#zero", "", 0); int e0 = p_WV_LastErrorCode();
    int m1 = CountOf(L"Input.dispatchMouseEvent");
    std::string r1 = p_WV_Dom(hd, WVD_TRUSTED_CLICK, "#box10", "", 0);
    int at = Find(L"\"x\":50,\"y\":60");
    Check(r0.empty() && e0 == WVERR_FAILED && m1 == m0 && r1 == "true" && CountOf(L"Input.dispatchMouseEvent") > m1 && at >= 0,
          "trusted click: a hidden (0x0) element is refused with a reason and no mouse event; a visible one is clicked at its centre", r0 + "/" + N(e0) + "/" + N(m1 - m0) + "/" + r1 + "/" + N(at));
  }
  {  // Cookie 过期时间在 2038-01-19 以后（有符号 32 位放不下）：按无符号 32 位解释，仍是持久 Cookie
    bool ok = p_WV_SetCookie(hd, "https://ck2050.test/", "f", "1", "", "", (int)2524608000u, 0) == 1;
    std::string j = ok ? p_WV_GetCookies(hd, "https://ck2050.test/", 0) : std::string();
    Check(ok && j.find("\"expires\":2524608000") != std::string::npos && j.find("\"session\":false") != std::string::npos,
          "cookie expiring in 2050 (past the signed 32-bit limit) stays a persistent cookie with that expiry", j.substr(0, 200));
  }
  p_WV_Destroy(hd); Pump(100); DestroyWindow(dw);
  {  // 加载HTML：内容放在内存里，以 https://wv2bridge.example/编号-序号.html 打开，由请求事件当场应答；不调用 NavigateToString、不写临时文件，没有 2MB 限制
    const std::wstring origin = L"https://wv2bridge.example/";
    auto pageNavs = [&](int from) { std::vector<std::wstring> r; auto v = LogAll(); for (int i = from; i < (int)v.size(); ++i) if (v[i].compare(0, 9 + origin.size(), L"Navigate:" + origin) == 0) r.push_back(v[i].substr(9)); return r; };
    auto waitNavs = [&](int from, size_t n) { for (DWORD t0 = GetTickCount(); pageNavs(from).size() < n && GetTickCount() - t0 < 5000;) Pump(5); return pageNavs(from); };
    auto ask = [&](const std::wstring& u) -> std::string {  // 请求一个网址，返回模拟运行时记下的应答“状态:字节数”
      int from = (int)LogAll().size(), n = CountOf(L"Raised:Request:" + u);
      pReq(u.c_str(), 1);
      if (!PumpFor(L"Raised:Request:" + u, 3000, n + 1)) return "timeout";
      auto v = LogAll();
      for (int i = from; i < (int)v.size(); ++i)
        if (v[i].compare(0, 15, L"CreateResponse:") == 0) { size_t a = v[i].find(L':', 15), b = v[i].find(L':', a + 1); return A(v[i].substr(15, b - 15)); }
      return "none";
    };
    HWND pw = CreateWindowExW(0, L"MockParent", L"html", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 400, 300, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    int nts0 = CountOf(L"NavigateToString"), base = (int)LogAll().size();
    int hh = p_WV_CreateAsync(pw, 0, 0, 0, 0, "", "", nullptr);
    Check(p_WV_NavigateToString(hh, "<p id=early>early</p>") == 1, "load html while the browser is still being created");
    bool rdy = p_WV_WaitReady(hh, 5000) == 1;
    auto n1 = waitNavs(base, 1);
    std::wstring pfx = origin + std::to_wstring(hh) + L"-";
    int fIdx = Find(L"AddFilter:" + origin + L"*", base), nIdx = n1.empty() ? -1 : Find(L"Navigate:" + n1[0], base);
    Check(rdy && n1.size() == 1 && n1[0].compare(0, pfx.size(), pfx) == 0 && n1[0].size() > 5 && n1[0].substr(n1[0].size() - 5) == L".html" && fIdx >= 0 && fIdx < nIdx,
          "html loaded during creation: the first navigation opens a wv2bridge.example page after the page-host filter is installed", (n1.empty() ? std::string("-") : A(n1[0])) + " f=" + N(fIdx) + " n=" + N(nIdx));
    if (n1.empty()) n1.push_back(L"none");
    Check(ask(n1[0]) == "200:21" && Find(L"CreateResponse:200:21:OK:Content-Type: text/html; charset=utf-8", base) >= 0, "page answered from memory as UTF-8 HTML (exact bytes)");
    { int r = Find(L"CreateResponse:200:21:OK:", base); std::wstring hl = r >= 0 ? LogAll()[r] : std::wstring();
      Check(hl.find(L"Cache-Control: no-store") != std::wstring::npos && hl.find(L"X-Content-Type-Options: nosniff") != std::wstring::npos &&
                hl.find(L"Cross-Origin-Resource-Policy: same-origin") != std::wstring::npos && hl.find(L"Access-Control-Allow-Origin") == std::wstring::npos,
            "page response: no-store, nosniff, CORP same-origin and no Access-Control-Allow-Origin (other sites in this browser cannot read it)", A(hl.substr(0, 220))); }
    std::string big = "<p>" + std::string(3000000, 'a') + "</p>";
    int b2 = (int)LogAll().size();
    Check(p_WV_NavigateToString(hh, big.c_str()) == 1, "load a 3,000,007-byte page (NavigateToString allows at most 2 MB)");
    auto n2 = waitNavs(b2, 1);
    Check(n2.size() == 1 && n2[0] != n1[0] && ask(n2[0]) == "200:3000007", "3 MB page: new URL, served intact", n2.empty() ? std::string("-") : A(n2[0]));
    std::string cp0 = p_WV_GetOption(WVO_CODEPAGE) ? p_WV_GetOption(WVO_CODEPAGE) : "0";
    p_WV_SetOption(WVO_CODEPAGE, "65001");
    std::string zh = "<p>"; zh.reserve(4200010); for (int i = 0; i < 1400000; ++i) zh += "\xE4\xB8\xAD"; zh += "</p>";
    int b3 = (int)LogAll().size();
    bool zok = p_WV_NavigateToString(hh, zh.c_str()) == 1;
    p_WV_SetOption(WVO_CODEPAGE, cp0.c_str());
    auto n3 = waitNavs(b3, 1);
    Check(zok && n3.size() == 1 && ask(n3[0]) == "200:4200007", "1.4 million Chinese characters (4.2 MB UTF-8, under the old 1.5M-character threshold) served intact", n3.empty() ? std::string("-") : A(n3[0]));
    wchar_t tmp[MAX_PATH] = {0}; GetTempPathW(MAX_PATH, tmp);
    Check(CountPageFiles(app, true) == 0 && CountPageFiles(tmp, false) == 0 && CountOf(L"NavigateToString") == nts0, "no NavigateToString call and no temporary page file (wv2_page_*.html) anywhere");
    for (int i = 0; i < 10; ++i) { std::string s = "<p>" + std::to_string(i) + "</p>"; p_WV_NavigateToString(hh, s.c_str()); }
    auto all = waitNavs(base, 13);
    Check(all.size() == 13, "13 page loads, 13 distinct navigations", N((int)all.size()));
    if (all.size() == 13)
      Check(ask(all[0]) == "404:13" && ask(all[4]) == "404:13" && ask(all[5]) == "200:8" && ask(all[12]) == "200:8",
            "only the newest 8 pages stay in memory; evicted pages answer 404", ask(all[0]) + "," + ask(all[4]) + "," + ask(all[5]) + "," + ask(all[12]));
    Check(ask(origin + L"img/logo.png") == "404:13", "unknown path on the page host is answered 404 at once (never sent to the network)");
    p_WV_AddMemoryFile(hh, "https://wv2bridge.example/logo.svg", "<svg/>", 6, "image/svg+xml");
    int lb = (int)LogAll().size();
    Check(ask(origin + L"logo.svg") == "200:6", "memory file on the page host serves relative resources of loaded pages");
    Check(Find(L"CreateResponse:200:6:OK:Content-Type: image/svg+xml||Access-Control-Allow-Origin: *||Cache-Control: no-cache", lb) >= 0, "ordinary memory files keep their headers (CORS allowed, no-cache)");
    p_WV_AddMemoryFile(hh, "", nullptr, 0, "");
    Check(ask(origin + L"logo.svg") == "404:13" && ask(all.empty() ? L"x" : all.back()) == "200:8", "clearing memory files keeps the loaded pages");
    std::string mb25(25 * 1024 * 1024, 'b');
    int b5 = (int)LogAll().size();
    for (int i = 0; i < 3; ++i) p_WV_NavigateToString(hh, mb25.c_str());
    auto n5 = waitNavs(b5, 3);
    Check(n5.size() == 3 && ask(n5[0]) == "404:13" && ask(n5[1]) == "200:26214400" && ask(n5[2]) == "200:26214400",
          "pages over 64 MB in total: the oldest are evicted, the newest kept", n5.size() == 3 ? ask(n5[0]) + "," + ask(n5[1]) : std::string("-"));
    std::wstring last = n5.empty() ? L"none" : n5.back();
    int nav0 = CountOf(L"Navigate:" + last), flt0 = CountOf(L"AddFilter:" + origin + L"*");
    pFail(0);  // 浏览器进程退出：自动恢复后重新打开最后的网址
    Check(PumpFor(L"Navigate:" + last, 5000, nav0 + 1) && CountOf(L"AddFilter:" + origin + L"*") == flt0 + 1 && ask(last) == "200:26214400",
          "after a browser crash the view reloads the loaded page from memory");
    p_WV_Destroy(hh); Pump(100); DestroyWindow(pw);
  }
  {  // 1.4.0：崩溃自动恢复有上限：60 秒内最多自动恢复 3 次，再崩溃就显示“页面意外关闭了”卡片，不会“崩溃—恢复”无限循环
    HWND rw = CreateWindowExW(0, L"MockParent", L"r", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 400, 300, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    int hl = p_WV_CreateAsync(rw, 0, 0, 0, 0, "https://loop.test/", "", nullptr);
    Check(p_WV_WaitReady(hl, 5000) == 1, "crash-loop view ready");
    HWND hostw = (HWND)(intptr_t)p_WV_GetWindow(hl, 0);
    int env0 = CountOf(L"CreateEnv:");
    for (int i = 0; i < 5; ++i) {
      pFail(0);  // COREWEBVIEW2_PROCESS_FAILED_KIND_BROWSER_PROCESS_EXITED
      Pump(300);
      p_WV_WaitReady(hl, 3000);
      Pump(100);
    }
    wchar_t nm[512] = {0};
    GetWindowTextW(hostw, nm, 511);
    int recreated = CountOf(L"CreateEnv:") - env0;
    Check(recreated == 3, "browser crash loop: automatic recovery stops after 3 times within 60 s", N(recreated));
    Check(std::wstring(nm).find(L"\u9875\u9762\u610F\u5916\u5173\u95ED\u4E86") != std::wstring::npos, "browser crash loop: the crash card is shown instead of recovering again", A(std::wstring(nm).substr(0, 30)));
    p_WV_Destroy(hl); Pump(100); DestroyWindow(rw);
  }
  {  // 1.4.1：JS 桥的出站消息（推送事件、延迟回传）只交给允许的网页；浏览器重建后恢复映射目录、注入的脚本与 DevTools 事件订阅
    HWND qw = CreateWindowExW(0, L"MockParent", L"q", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 400, 300, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    char qopts[128];
    sprintf(qopts, "bind:later=%d", (int)(intptr_t)OnLater);
    int hq = p_WV_CreateAsync(qw, 0, 0, 0, 0, "https://own.test/", qopts, nullptr);
    Check(p_WV_WaitReady(hq, 5000) == 1 && PumpFor(L"Committed:https://own.test/", 3000), "outbound/restore view ready");
    typedef void(__stdcall* SendFromFn)(const wchar_t*, const wchar_t*);
    SendFromFn pSendFrom = (SendFromFn)(void*)GetProcAddress(g_mock, "Mock_SendWebMessageFrom");
    // 推送事件：当前网页是本程序的内容时送出；换成外部网站后不送出，数据不会被它读到
    Check(p_WV_Emit(hq, "own", "1") == 1 && PumpFor(L"\"n\":\"own\"", 2000), "Emit reaches a page that may use the bridge");
    p_WV_Navigate(hq, "https://www.example.com/");
    PumpFor(L"Committed:https://www.example.com/", 3000);
    int e0 = p_WV_Emit(hq, "leak", "{\"secret\":1}");
    int ee = p_WV_LastErrorCode();
    Pump(200);
    Check(e0 == 0 && ee == WVERR_DENIED && Find(L"\"n\":\"leak\"") < 0, "Emit to an outside website is refused and nothing is posted", N(e0) + "/" + N(ee));
    // 延迟回传：发起调用的网页离开（打开了外部网站）后，结果不交给新网页
    int cb0 = CountOf(L"Committed:https://own.test/b");
    p_WV_Navigate(hq, "https://own.test/b");
    PumpFor(L"Committed:https://own.test/b", 3000, cb0 + 1);
    g_laterId = 0;
    pSendFrom(L"https://own.test/b", L"{\"__epl\":1,\"t\":\"c\",\"id\":931,\"n\":\"later\",\"a\":[]}");
    for (DWORD t0 = GetTickCount(); g_laterId == 0 && GetTickCount() - t0 < 3000;) Pump(10);
    p_WV_Navigate(hq, "https://www.example.com/x");
    PumpFor(L"Committed:https://www.example.com/x", 3000);
    int br = p_WV_BindReturn(hq, g_laterId, "\"secret\"", 0);
    Pump(200);
    Check(g_laterId > 0 && br == 0 && Find(L"\"id\":931") < 0, "deferred reply is not delivered once the calling page has gone", N(g_laterId) + "/" + N(br));
    // 浏览器重建后恢复映射目录、注入的脚本（编号不变）与 DevTools 事件订阅；注入的脚本登记完才打开页面
    int co = CountOf(L"Committed:https://own.test/");
    p_WV_Navigate(hq, "https://own.test/");
    PumpFor(L"Committed:https://own.test/", 3000, co + 1);
    Check(p_WV_MapFolder(hq, "restore.example", appA.c_str(), 1) == 1, "map a folder before the browser process exits");
    std::string sid = p_WV_AddInitScript(hq, "window.restored=1");
    Check(!sid.empty() && p_WV_CdpSubscribe(hq, "Runtime.consoleAPICalled", 1) == 1, "init script and DevTools subscription before the browser process exits", sid);
    int m0 = CountOf(L"MapFolder:restore.example="), c0 = CountOf(L"Cdp.Add:Runtime.consoleAPICalled"), n0 = CountOf(L"Navigate:https://own.test/");
    int base = (int)LogAll().size();
    pFail(0);  // COREWEBVIEW2_PROCESS_FAILED_KIND_BROWSER_PROCESS_EXITED：自动重建
    Pump(300);
    p_WV_WaitReady(hq, 3000);
    PumpFor(L"Navigate:https://own.test/", 3000, n0 + 1);
    Pump(200);
    Check(CountOf(L"MapFolder:restore.example=") == m0 + 1, "after the rebuild the folder mapping is applied again", N(CountOf(L"MapFolder:restore.example=") - m0));
    Check(CountOf(L"Cdp.Add:Runtime.consoleAPICalled") == c0 + 1, "after the rebuild the DevTools subscription is made again", N(CountOf(L"Cdp.Add:Runtime.consoleAPICalled") - c0));
    int iAdd = Find(L"InitJs:window.restored=1", base), iNav = Find(L"Navigate:https://own.test/", base);
    Check(iAdd >= 0 && iNav > iAdd, "after the rebuild the init script is registered again before the page is opened", N(iAdd) + " < " + N(iNav));
    std::wstring newId = iAdd >= 0 ? LogAll()[iAdd].substr(LogAll()[iAdd].rfind(L'=') + 1) : L"";
    int rem0 = (int)LogAll().size();
    Check(p_WV_RemoveInitScript(hq, sid.c_str()) == 1 && !newId.empty() && A(newId) != sid && Find(L"RemoveScript:" + newId, rem0) >= 0,
          "the init script id returned before the rebuild removes the re-registered script (it has a new id inside WebView2)", sid + " -> " + A(newId));
    // 1.4.2：重建后脚本还在登记中就被移除：登记完成时立即撤掉，不会留在新内核里
    typedef void(__stdcall* HoldFn)(int);
    HoldFn pHold = (HoldFn)(void*)GetProcAddress(g_mock, "Mock_HoldScripts");
    std::string sid2 = p_WV_AddInitScript(hq, "window.gone=1");
    int base2 = (int)LogAll().size();
    if (pHold) pHold(1);
    pFail(0);  // 浏览器进程退出：重建，重新登记的完成回调被暂扣
    Pump(400);
    int iGone = Find(L"InitJs:window.gone=1", base2);
    std::wstring goneId = iGone >= 0 ? LogAll()[iGone].substr(LogAll()[iGone].rfind(L'=') + 1) : L"";
    int rmOk = p_WV_RemoveInitScript(hq, sid2.c_str());
    int base3 = (int)LogAll().size();
    if (pHold) pHold(0);
    Pump(300);
    Check(pHold && !goneId.empty() && rmOk == 1 && Find(L"RemoveScript:" + goneId, base3) >= 0,
          "a script removed while it is being registered again after a rebuild is taken out as soon as the registration completes", A(goneId));
    // 1.4.2：桥对象连续改名时，还在登记中的旧桥接脚本作废后撤掉；停用 JS 桥时撤掉桥接脚本、删掉当前网页里的桥对象，
    // 停用前拿到的桥对象再调用时如实回绝（原来脚本一直留着，调用的 Promise 永远不会结束）
    int rb = (int)LogAll().size();
    p_WV_SetStr(hq, WVS_BRIDGE_NAME, "eplA");
    p_WV_SetStr(hq, WVS_BRIDGE_NAME, "eplB");
    Pump(300);
    int iA = Find(L"InitJs:(function(){var N=\"eplA\"", rb), iB = Find(L"InitJs:(function(){var N=\"eplB\"", rb);
    std::wstring idA = iA >= 0 ? LogAll()[iA].substr(LogAll()[iA].rfind(L'=') + 1) : L"";
    std::wstring idB = iB >= 0 ? LogAll()[iB].substr(LogAll()[iB].rfind(L'=') + 1) : L"";
    Check(!idA.empty() && !idB.empty() && Find(L"RemoveScript:" + idA, rb) >= 0 && Find(L"RemoveScript:" + idB, rb) < 0,
          "a bridge script superseded while it is still being registered (renamed twice) is removed, the newest one stays", A(idA) + " / " + A(idB));
    int rd0 = (int)LogAll().size();
    Check(p_WV_SetInt(hq, WVP_BRIDGE, 0) == 1 && p_WV_GetInt(hq, WVP_BRIDGE) == 0, "bridge can be switched off");
    Pump(200);
    Check(Find(L"RemoveScript:" + idB, rd0) >= 0 && Find(L"ExecuteScript:try{var o=window[\"eplB\"]", rd0) >= 0,
          "switching the bridge off removes its script and deletes the bridge object from the current page", A(idB));
    pSendFrom(L"https://own.test/", L"{\"__epl\":1,\"t\":\"c\",\"id\":951,\"n\":\"later\",\"a\":[]}");
    Check(PumpFor(L"\"id\":951,", 2000) && LogAll()[Find(L"\"id\":951,")].find(L"\"ok\":false") != std::wstring::npos,
          "a call through a bridge object left over after switching it off is rejected instead of waiting forever");
    // 1.4.3：被来源规则拒绝的推送不会把停用的 JS 桥重新打开；解绑函数不启用 JS 桥，绑定时才启用
    int cy = CountOf(L"Committed:https://www.example.com/y");
    p_WV_Navigate(hq, "https://www.example.com/y");
    PumpFor(L"Committed:https://www.example.com/y", 3000, cy + 1);
    int ex0 = p_WV_Emit(hq, "x", "1");
    int exErr = p_WV_LastErrorCode();
    Check(ex0 == 0 && exErr == WVERR_DENIED && p_WV_GetInt(hq, WVP_BRIDGE) == 0, "a refused Emit does not switch a disabled bridge back on", N(ex0) + "/" + N(exErr) + "/" + N(p_WV_GetInt(hq, WVP_BRIDGE)));
    p_WV_Bind(hq, "later", nullptr);
    Check(p_WV_GetInt(hq, WVP_BRIDGE) == 0, "unbinding a function does not switch a disabled bridge back on");
    p_WV_Bind(hq, "later", (void*)OnLater);
    Check(p_WV_GetInt(hq, WVP_BRIDGE) == 1, "binding a function switches the bridge on");
    p_WV_Destroy(hq); Pump(100); DestroyWindow(qw);
  }
  {  // 1.4.3：只设“JS调用”事件（没有单独绑定的函数）时也启用 JS 桥（原来网页里没有桥对象，这个事件永远不会触发）
    HWND gw = CreateWindowExW(0, L"MockParent", L"g", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 400, 300, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    char gopts[64];
    sprintf(gopts, "ev%d=%d", WVE_JS_CALL, (int)(intptr_t)OnAnyCall);
    int b0 = (int)LogAll().size();
    int hg = p_WV_CreateAsync(gw, 0, 0, 0, 0, "https://any.test/", gopts, nullptr);
    Check(p_WV_WaitReady(hg, 5000) == 1 && PumpFor(L"Committed:https://any.test/", 3000), "view with only the JS call event ready");
    Check(p_WV_GetInt(hg, WVP_BRIDGE) == 1 && Find(L"InitJs:(function(){var N=\"epl\"", b0) >= 0, "setting only the JS call event at creation switches the bridge on");
    g_anyName.clear();
    pSend(L"{\"__epl\":1,\"t\":\"c\",\"id\":961,\"n\":\"anyName\",\"a\":[]}");
    Check(PumpFor(L"\"id\":961,", 3000) && g_anyName == "anyName" && LogAll()[Find(L"\"id\":961,")].find(L"\"v\":\"any\"") != std::wstring::npos,
          "a call to an unbound name reaches the JS call event and its result returns to the page", g_anyName);
    p_WV_Destroy(hg); Pump(100); DestroyWindow(gw);
    HWND gw2 = CreateWindowExW(0, L"MockParent", L"g2", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 400, 300, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    int hg2 = p_WV_CreateAsync(gw2, 0, 0, 0, 0, "https://any2.test/", "", nullptr);
    p_WV_WaitReady(hg2, 5000);
    const int off = p_WV_GetInt(hg2, WVP_BRIDGE);
    p_WV_SetEvent(hg2, WVE_JS_CALL, (void*)OnAnyCall);
    Check(off == 0 && p_WV_GetInt(hg2, WVP_BRIDGE) == 1, "setting the JS call event after creation switches the bridge on", N(off));
    p_WV_Destroy(hg2); Pump(100); DestroyWindow(gw2);
  }
  {  // 1.4.5：之前没有任何测试调用过的导出函数——置父窗口（新父窗口必须属于界面线程）、CDP调用、清除数据、下载的暂停/继续/取消
    HWND dw = CreateWindowExW(0, L"MockParent", L"d", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 400, 300, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    HWND dw2 = CreateWindowExW(0, L"MockParent", L"d2", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 400, 300, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    int hd = p_WV_CreateAsync(dw, 0, 0, 0, 0, "https://dl.test/", "", nullptr);
    Check(p_WV_WaitReady(hd, 5000) == 1 && PumpFor(L"Committed:https://dl.test/", 3000), "view for the remaining exports ready");
    HWND hostWnd = (HWND)(intptr_t)p_WV_GetWindow(hd, 0);  // 0：宿主窗口
    Check(p_WV_SetParent(hd, dw2) == 1 && GetParent(hostWnd) == dw2, "SetParent moves the browser into another window of the UI thread");
    OtherWin ow;
    ow.ready = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    DWORD otid = 0;
    HANDLE oth = CreateThread(nullptr, 0, OtherWinThread, &ow, 0, &otid);
    WaitForSingleObject(ow.ready, 5000);
    const int sp = p_WV_SetParent(hd, ow.w);
    const int spErr = p_WV_LastErrorCode();
    const bool stayed = GetParent(hostWnd) == dw2;
    p_WV_SetParent(hd, dw2);  // 旧版会把浏览器放进别的线程的窗口：先移回来，再结束那个线程
    PostThreadMessageW(otid, WM_QUIT, 0, 0);
    for (DWORD t0 = GetTickCount(); WaitForSingleObject(oth, 10) == WAIT_TIMEOUT && GetTickCount() - t0 < 5000;) Pump(10);
    CloseHandle(oth); CloseHandle(ow.ready);
    Check(ow.w && sp == 0 && spErr == WVERR_THREAD && stayed, "SetParent refuses a window of another thread", N(sp) + "/" + N(spErr));
    int b0 = (int)LogAll().size();
    std::string cr = p_WV_CdpCall(hd, "Browser.getVersion", "{}", 3000);
    Check(p_WV_LastErrorCode() == 0 && Find(L"CDP:Browser.getVersion {}", b0) >= 0, "CdpCall sends the method and returns its result", cr);
    int b1 = (int)LogAll().size();
    Check(p_WV_ClearData(hd, 0) == 1 && Find(L"CDP:Network.clearBrowserCache", b1) >= 0 && Find(L"CDP:Network.clearBrowserCookies", b1) >= 0,
          "ClearData on a runtime without the profile API clears cache and cookies through DevTools");
    typedef void(__stdcall* HoldFn)(int);
    HoldFn pHoldDl = (HoldFn)(void*)GetProcAddress(g_mock, "Mock_HoldDownloads");
    g_dlId = 0;
    p_WV_SetEvent(hd, WVE_DOWNLOAD_START, (void*)OnDlStartId);
    p_WV_SetEvent(hd, WVE_DOWNLOAD_DONE, (void*)OnDlDone);
    if (pHoldDl) pHoldDl(1);
    pDownload(L"https://dl.test/big.bin", 5000000);
    for (DWORD t0 = GetTickCount(); g_dlId == 0 && GetTickCount() - t0 < 3000;) Pump(10);
    Pump(100);
    int b2 = (int)LogAll().size();
    const int pa = p_WV_DownloadControl(hd, g_dlId, 2), re = p_WV_DownloadControl(hd, g_dlId, 3), ca = p_WV_DownloadControl(hd, g_dlId, 1);
    const int iP = Find(L"DlOp.Pause", b2), iR = Find(L"DlOp.Resume", b2), iC = Find(L"DlOp.Cancel", b2);
    Check(pHoldDl && g_dlId > 0 && pa == 1 && re == 1 && ca == 1 && iP >= 0 && iR > iP && iC > iR, "DownloadControl pauses, resumes and cancels a running download",
          N(g_dlId) + ":" + N(pa) + N(re) + N(ca));
    int dn = CountOf(L"Note:cb-dldone");
    g_dlDone = -1;
    if (pHoldDl) pHoldDl(0);
    Check(PumpFor(L"Note:cb-dldone", 3000, dn + 1) && g_dlDone == 2, "a cancelled download ends as interrupted", N(g_dlDone));
    const int bad = p_WV_DownloadControl(hd, 987654, 1), badErr = p_WV_LastErrorCode();
    Check(bad == 0 && badErr == WVERR_NOT_FOUND, "DownloadControl reports an unknown download id", N(badErr));
    p_WV_Destroy(hd); Pump(100); DestroyWindow(dw2); DestroyWindow(dw);
  }
  // ---- 1.5.0：计时器在同步等待中反复调用需要等待的方法：最多嵌套 16 层，更深的调用立即失败（原来每次触发都多一层，实测 3 秒 299 层）
  {
    g_hold15 = (HoldFn15)(void*)GetProcAddress(g_mock, "Mock_HoldScripts");
    HWND rw = CreateWindowExW(0, L"MockParent", L"re", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 300, 200, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    g_reH = p_WV_Create(rw, 0, 0, 0, 0, "https://re.test/", "", 5000);
    g_reDepth = g_reMax = g_reRefused = g_reOk = 0;
    g_reStop = false;
    if (g_hold15) g_hold15(1);
    g_reTick = SetTimer(nullptr, 0, 5, ReTick);
    SetTimer(nullptr, 0, 1500, ReRelease);
    for (DWORD t0 = GetTickCount(); !g_reStop && GetTickCount() - t0 < 15000;) Pump(10);
    Pump(200);
    Check(g_hold15 && g_reH > 0 && g_reMax == 17 && g_reOk == 16 && g_reRefused >= 1,
          "nested synchronous waits stop at 16 levels: deeper calls fail with WVERR_REENTRANT and the 16 waiting calls all complete",
          N(g_reMax) + "/" + N(g_reOk) + "/" + N(g_reRefused));
    // 转交给界面线程的调用已经开始执行时，超过开始时限也等它执行完（执行中的调用不能取消）
    p_WV_SetOption(WVO_THREAD_TIMEOUT, "300");
    if (g_hold15) g_hold15(1);
    g_hoId.clear();
    g_hoErr = -1;
    SetTimer(nullptr, 0, 1200, HoRelease);
    HANDLE th = CreateThread(nullptr, 0, HoWorker, nullptr, 0, nullptr);
    for (DWORD t0 = GetTickCount(); WaitForSingleObject(th, 0) == WAIT_TIMEOUT && GetTickCount() - t0 < 15000;) Pump(5);
    CloseHandle(th);
    p_WV_SetOption(WVO_THREAD_TIMEOUT, "");
    Check(!g_hoId.empty() && g_hoErr == 0 && g_hoMs >= 1000, "a call already running on the UI thread is awaited past the thread timeout", g_hoId + "/" + N(g_hoErr) + "/" + N((int)g_hoMs));
    p_WV_Destroy(g_reH);
    Pump(100);
    DestroyWindow(rw);
  }
  {  // 1.8.0：创建控件失败后点“重试”，按微软的建议从新建环境开始（原来沿用同一个环境对象）
    IntFn pFailCtl = (IntFn)(void*)GetProcAddress(g_mock, "Mock_FailNextController");
    auto countLog = [](const wchar_t* s) { int n = 0; const int c = pCount(); for (int i = 0; i < c; ++i) if (wcsstr(pAt(i), s)) ++n; return n; };
    HWND rp = CreateWindowExW(0, L"MockParent", L"retry", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 640, 480, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    if (!rp) rp = parent;
    pFailCtl((int)0x80004005);  // E_FAIL：不是“找不到文件”，显示一般的失败卡片（重试、复制诊断信息）
    int hc = p_WV_CreateAsync(rp, 0, 0, 0, 0, "https://ctlretry.test/", "proxy=127.0.0.1:6666", nullptr);
    const bool failed = p_WV_WaitReady(hc, 3000) == 0 && p_WV_IsReady(hc) == -1 && Find(L"CreateController.Fail") >= 0;
    const int envs = countLog(L"CreateEnv:");
    HWND hh = (HWND)(intptr_t)p_WV_GetWindow(hc, 0);
    InvalidateRect(hh, nullptr, TRUE); UpdateWindow(hh);  // 按钮的位置在绘制卡片时才算出来
    RECT rc = {}; GetClientRect(hh, &rc);
    bool clicked = false;  // 找到第一个可点的位置（左边的“重试”）并点它
    for (int y = 0; y < rc.bottom && !clicked; y += 3)
      for (int x = 0; x < rc.right && !clicked; x += 3) {
        SendMessageW(hh, WM_MOUSEMOVE, 0, MAKELPARAM(x, y));
        if (!SendMessageW(hh, WM_SETCURSOR, (WPARAM)hh, MAKELPARAM(HTCLIENT, WM_MOUSEMOVE))) continue;
        SendMessageW(hh, WM_LBUTTONDOWN, MK_LBUTTON, MAKELPARAM(x + 4, y + 4)); SendMessageW(hh, WM_LBUTTONUP, 0, MAKELPARAM(x + 4, y + 4));
        clicked = true;
      }
    for (DWORD t0 = GetTickCount(); p_WV_IsReady(hc) != 1 && GetTickCount() - t0 < 3000;) Pump(20);
    Check(failed && clicked && p_WV_IsReady(hc) == 1 && countLog(L"CreateEnv:") == envs + 1,
          "after a controller failure, retry starts over with a new environment and succeeds", N(envs) + "/" + N(countLog(L"CreateEnv:")) + "/" + N(p_WV_IsReady(hc)) + (clicked ? "" : "/no-button"));
    p_WV_Destroy(hc); Pump(100);
    if (rp != parent) DestroyWindow(rp);
  }
  printf("RESULT pass=%d fail=%d\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
