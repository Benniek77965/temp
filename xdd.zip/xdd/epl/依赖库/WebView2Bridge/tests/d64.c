int __declspec(dllexport) f(void){return 1;}
