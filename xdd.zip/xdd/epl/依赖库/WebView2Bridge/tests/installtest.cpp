// 1.8.1 白盒测试：后台安装（WV_InstallRuntimeAsync / WV_InstallState）与“别的进程启动的安装程序仍在运行”时的等待。不联网：下载换成写入一个
// 小文件（签名或 SHA-1 校验必然失败），所以安装总以失败结束；测的是线程、状态、冷却与等待规则。installtest.exe（Win10 规则）、installtest.exe win7
// 编译方式与 helpertest.cpp 相同：i686-w64-mingw32-g++ -std=c++17 -O1 -static -municode -DUNICODE -D_UNICODE -Isrc -Isrc\third_party\webview2\include tests\installtest.cpp -o installtest.exe -lole32 -luser32 -lgdi32 -ladvapi32 -lshell32 -lversion
#include "../src/wv_util.cpp"
#include "../src/wv_runtime.cpp"
#include "../src/wv_host.cpp"
#include "../src/wv_view.cpp"
#include "../src/wv_feat.cpp"
#include "../src/wv_api.cpp"
#include <cstdio>

using namespace wv;
static int g_pass, g_fail;
static volatile LONG g_dlCalls;
static volatile DWORD g_dlTick;
static HRESULT WINAPI FakeDownload(LPUNKNOWN, LPCWSTR, LPCWSTR file, DWORD, LPVOID) {
  InterlockedIncrement(&g_dlCalls);
  g_dlTick = GetTickCount();
  HANDLE h = CreateFileW(file, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
  if (h == INVALID_HANDLE_VALUE) return HRESULT_FROM_WIN32(GetLastError());
  DWORD w = 0;
  WriteFile(h, "MZ-not-the-real-package", 23, &w, nullptr);
  CloseHandle(h);
  return S_OK;
}
static void Check(bool c, const char* n, const std::wstring& got = std::wstring()) {
  if (c) { ++g_pass; printf("PASS %s\n", n); } else { ++g_fail; printf("FAIL %s  [%s]\n", n, ToUtf8(got).c_str()); }
  fflush(stdout);
}
static int WaitDone(DWORD ms) {
  const DWORD t0 = GetTickCount();
  int st;
  while ((st = WV_InstallState()) == WVIS_RUNNING && GetTickCount() - t0 < ms) Sleep(20);
  return st;
}
static void ClearCooldown() { RegDeleteKeyW(HKEY_CURRENT_USER, L"Software\\WebView2Bridge"); }
static std::wstring g_fakeDir;
// 以安装程序的进程名运行本程序的一个副本，睡 ms 毫秒后退出：模拟“另一个程序启动的安装程序还在运行”
static HANDLE FakeInstaller(DWORD ms) {
  wchar_t self[MAX_PATH] = {0}, tp[MAX_PATH] = {0};
  GetModuleFileNameW(nullptr, self, MAX_PATH);
  GetTempPathW(MAX_PATH, tp);
  g_fakeDir = std::wstring(tp) + L"wvfake_" + std::to_wstring(GetCurrentProcessId());
  CreateDirectoryW(g_fakeDir.c_str(), nullptr);
  const std::wstring exe = g_fakeDir + L"\\MicrosoftEdgeWebview2Setup.exe";
  CopyFileW(self, exe.c_str(), FALSE);
  std::wstring cmd = L"\"" + exe + L"\" sleep " + std::to_wstring(ms);
  std::vector<wchar_t> b(cmd.begin(), cmd.end());
  b.push_back(0);
  STARTUPINFOW si;
  ZeroMemory(&si, sizeof(si));
  si.cb = sizeof(si);
  PROCESS_INFORMATION pi;
  ZeroMemory(&pi, sizeof(pi));
  if (!CreateProcessW(exe.c_str(), b.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) return nullptr;
  CloseHandle(pi.hThread);
  return pi.hProcess;
}
struct AsyncResult {
  DWORD ms = 0;
  int r = -1, st = -1;
};
static DWORD WINAPI AsyncFromWorker(LPVOID p) {
  AsyncResult* a = static_cast<AsyncResult*>(p);
  const DWORD t0 = GetTickCount();
  a->r = WV_InstallRuntimeAsync(0);
  a->ms = GetTickCount() - t0;
  a->st = WV_InstallState();
  return 0;
}
int wmain(int argc, wchar_t** argv) {
  if (argc >= 3 && wcscmp(argv[1], L"sleep") == 0) {  // 冒充安装程序的副本
    Sleep((DWORD)_wtoi(argv[2]));
    return 0;
  }
  const bool win7 = argc >= 2 && wcscmp(argv[1], L"win7") == 0;
  WV_SetOption(WVO_CODEPAGE, "65001");
  ClearCooldown();
  if (!win7) g_onlineInstallerOverride = 1;  // Wine 的 kernel32 不一定有 PackageIdFromFullName：按 Win10 规则测
  if (win7) {  // 与 helpertest 相同：直接设系统版本，走 Win7/8/8.1 的 109 版离线安装包（大小与 SHA-1 校验必然失败）
    g_os.major = 6;
    g_os.minor = 1;
  }
  printf("INFO mode=%s legacyPackage=%d\n", win7 ? "win7" : "win10", UseLegacyOfflinePackage() ? 1 : 0);
  g_testDownload = FakeDownload;
  Check(WV_InstallState() == WVIS_NONE, "1.8.1: before any install the state is WVIS_NONE");
  // 界面线程登记为本线程、而本线程此刻不处理消息：工作线程里的 WV_InstallRuntimeAsync 不经界面线程，立即返回
  UiThread().store(GetCurrentThreadId());
  AsyncResult a;
  HANDLE th = CreateThread(nullptr, 0, AsyncFromWorker, &a, 0, nullptr);
  const bool joined = th && WaitForSingleObject(th, 10000) == WAIT_OBJECT_0;
  if (th) CloseHandle(th);
  Check(joined && a.r == 1 && a.ms < 1000 && (a.st == WVIS_RUNNING || a.st == WVIS_FAILED),
        "1.8.1: WV_InstallRuntimeAsync returns at once from a worker thread while the UI thread is not pumping messages (no hand-off to the UI thread)",
        std::to_wstring(a.r) + L" " + std::to_wstring(a.ms) + L"ms st=" + std::to_wstring(a.st));
  int st = WaitDone(30000);
  std::string msg = WV_LastError();
  Check(st == WVIS_FAILED && WV_LastErrorCode() == WVERR_INSTALL && !msg.empty(), "1.8.1: the background install ends and WV_InstallState gives the state and the reason", FromUtf8(msg.c_str(), (int)msg.size()));
  // 不带 WVI_AUTO：失败后立即可以再发起（不受 24 小时冷却）；带 WVI_AUTO：照旧冷却
  const int r2 = WV_InstallRuntimeAsync(0);
  st = WaitDone(30000);
  Check(r2 == 1 && st == WVIS_FAILED, "1.8.1: without WVI_AUTO a failed install can be started again at once (no cooldown)");
  const int r3 = WV_InstallRuntimeAsync(WVI_AUTO);
  msg = WV_LastError();
  Check(r3 == 0 && WV_LastErrorCode() == WVERR_INSTALL && msg.find("24 \xE5\xB0\x8F\xE6\x97\xB6") != std::string::npos, "1.8.1: with WVI_AUTO the 24-hour cooldown after a failure still applies", FromUtf8(msg.c_str(), (int)msg.size()));
  // 别的进程启动的安装程序还在运行：等它结束才下载；安装进行中再发起只沿用这一次
  ClearCooldown();
  g_foreignWaitMs = 20000;
  HANDLE f = FakeInstaller(3000);
  Check(f != nullptr, "test setup: a fake installer process is running");
  Sleep(300);
  const LONG dl0 = g_dlCalls;
  const int r4 = WV_InstallRuntimeAsync(0);
  InstallJob* j1 = g_job;
  const int r5 = WV_InstallRuntimeAsync(0);
  InstallJob* j2 = g_job;
  Check(r4 == 1 && r5 == 1 && j1 == j2, "1.8.1: starting again while an install is running joins it instead of starting a second installer");
  bool sawWait = false;
  for (DWORD t0 = GetTickCount(); GetTickCount() - t0 < 2500 && !sawWait; Sleep(20)) {
    int stage = 0, pm = 0;
    DWORD el = 0;
    if (InstallStatus(stage, pm, el) && stage == 4) sawWait = true;
  }
  DWORD fakeExit = GetTickCount();
  if (f) {
    WaitForSingleObject(f, 15000);
    fakeExit = GetTickCount();
    CloseHandle(f);
  }
  st = WaitDone(30000);
  Check(sawWait && g_dlCalls == dl0 + 1 && g_dlTick + 50 >= fakeExit && st == WVIS_FAILED,
        "1.8.1: while another installer process is still running the install waits for it (stage 4) and only downloads after it exits",
        L"sawWait=" + std::to_wstring(sawWait) + L" dl=" + std::to_wstring(g_dlCalls - dl0) + L" dlTick-exit=" + std::to_wstring((long)(g_dlTick - fakeExit)));
  // 别的安装程序一直不结束：等满上限就失败并说明，不下载
  ClearCooldown();
  g_foreignWaitMs = 1500;
  HANDLE f2 = FakeInstaller(20000);
  Sleep(300);
  const LONG dl1 = g_dlCalls;
  WV_InstallRuntimeAsync(0);
  st = WaitDone(15000);
  const std::wstring why = LastInstallError();
  Check(st == WVIS_FAILED && g_dlCalls == dl1 && why.find(L"\u4ECD\u672A\u7ED3\u675F") != std::wstring::npos,
        "1.8.1: an installer that never finishes is waited for only up to the limit, then the install fails with the reason and nothing is downloaded", why);
  if (f2) {
    TerminateProcess(f2, 0);
    WaitForSingleObject(f2, 5000);
    CloseHandle(f2);
  }
  Sleep(200);
  DeleteFileW((g_fakeDir + L"\\MicrosoftEdgeWebview2Setup.exe").c_str());
  RemoveDirectoryW(g_fakeDir.c_str());
  g_testDownload = nullptr;
  ClearCooldown();
  printf("RESULT pass=%d fail=%d\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
