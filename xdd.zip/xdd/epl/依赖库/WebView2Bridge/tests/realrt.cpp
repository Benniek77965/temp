// 真实运行时验证（见 realrt.sh）：realrt.exe 场景。程序目录的 WebView2 文件夹里是微软的 x86 固定版运行时；
// Wine 下浏览器进程本身起不来（实测停在创建中或以 0x80010108 失败），所以“能用”按“没有立即失败、也不是找不到文件”判断。
// realrt.exe lock 文件 毫秒：独占打开文件一段时间（模拟杀毒软件扫描）
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
typedef int(__stdcall* FnInit)(const char*);
typedef int(__stdcall* FnSetOption)(int, const char*);
typedef const char*(__stdcall* FnStr0)(void);
typedef int(__stdcall* FnInt0)(void);
typedef int(__stdcall* FnInt1)(int);
typedef int(__stdcall* FnCreate)(HWND, int, int, int, int, const char*, const char*, int);
typedef const char*(__stdcall* FnGetStr)(int, int);
typedef int(__stdcall* FnGetInt)(int, int);
typedef int(__stdcall* FnInst)(int, int);
typedef const char*(__stdcall* FnJson)(const char*, const char*);
static FnInit WV_Init; static FnSetOption WV_SetOption; static FnStr0 WV_LastError, WV_RuntimeInfo; static FnInt0 WV_LastErrorCode;
static FnInt1 WV_RuntimeCheck, WV_Destroy, WV_IsReady; static FnCreate WV_Create; static FnGetStr WV_GetStr; static FnGetInt WV_GetInt;
static FnInst WV_InstallRuntime; static FnJson WV_JsonGet;
static HWND g_hw;
static int g_pass = 0, g_fail = 0;
static void Check(bool c, const char* what, const std::string& got) { printf("%s %s  [%s]\n", c ? "PASS" : "FAIL", what, got.c_str()); c ? ++g_pass : ++g_fail; }
static LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM w, LPARAM l) { return DefWindowProcW(h, m, w, l); }
static void Pump(DWORD ms) { DWORD t = GetTickCount(); MSG msg; while (GetTickCount() - t < ms) { while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&msg); DispatchMessageW(&msg); } Sleep(10); } }
struct Res { int h, state; DWORD ms; std::string err; };
// 创建并等待：就绪、失败或超时；返回最终状态（0 创建中 1 就绪 2 失败）、耗时与失败原因
static Res Create(DWORD waitMs) {
  DWORD t0 = GetTickCount();
  Res r; r.h = WV_Create(g_hw, 0, 0, 0, 0, "about:blank", nullptr, 0);
  r.state = -1;
  while (GetTickCount() - t0 < waitMs) { r.state = WV_GetInt(r.h, 47); if (r.state == 1 || r.state == 2) break; Pump(20); }
  r.ms = GetTickCount() - t0; r.err = WV_GetStr(r.h, 114);
  printf("INFO create h=%d state=%d %lums err=%s\n", r.h, r.state, r.ms, r.err.c_str());
  return r;
}
static bool Proceeds(const Res& r) { return r.ms > 2000 && r.err.find("0x80070002") == std::string::npos && r.err.find("找不到") == std::string::npos; }
static std::string J(const char* path) { std::string s = WV_RuntimeInfo(); return WV_JsonGet(s.c_str(), path); }
static const wchar_t* kCs = L"Software\\Microsoft\\EdgeUpdate\\ClientState\\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}";
static std::wstring InstalledDir() { wchar_t la[MAX_PATH]; GetEnvironmentVariableW(L"LOCALAPPDATA", la, MAX_PATH); return std::wstring(la) + L"\\Microsoft\\EdgeWebView\\Application\\realrt"; }  // 由 realrt.sh 准备：同一运行时的副本（客户端 DLL 是另一个文件）
static void SimInstall(bool on) {
  if (!on) { RegDeleteKeyW(HKEY_CURRENT_USER, kCs); return; }
  std::wstring p = InstalledDir(); HKEY k; RegCreateKeyExW(HKEY_CURRENT_USER, kCs, 0, nullptr, 0, KEY_WRITE, nullptr, &k, nullptr);
  RegSetValueExW(k, L"EBWebView", 0, REG_SZ, (const BYTE*)p.c_str(), (DWORD)((p.size() + 1) * 2)); RegCloseKey(k);
}
int main(int argc, char** argv) {
  setvbuf(stdout, NULL, _IONBF, 0);
  std::string sc = argc > 1 ? argv[1] : "";
  if (sc == "lock" && argc > 3) {
    HANDLE f = CreateFileA(argv[2], GENERIC_READ, 0, nullptr, OPEN_EXISTING, 0, nullptr);
    printf("INFO lock %s -> %s\n", argv[2], f != INVALID_HANDLE_VALUE ? "ok" : "failed");
    Sleep(atoi(argv[3]));
    return 0;
  }
  HMODULE m = LoadLibraryW(L"WebView2Bridge.dll");
#define GP(n) n = (decltype(n))(void*)GetProcAddress(m, #n)
  GP(WV_Init); GP(WV_SetOption); GP(WV_LastError); GP(WV_RuntimeInfo); GP(WV_LastErrorCode); GP(WV_RuntimeCheck); GP(WV_Destroy); GP(WV_IsReady);
  GP(WV_Create); GP(WV_GetStr); GP(WV_GetInt); GP(WV_InstallRuntime); GP(WV_JsonGet);
  WNDCLASSW wc = {}; wc.lpfnWndProc = WndProc; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"realrt"; RegisterClassW(&wc);
  g_hw = CreateWindowW(L"realrt", L"realrt", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 800, 600, nullptr, nullptr, wc.hInstance, nullptr);
  char dir[MAX_PATH]; GetModuleFileNameA(nullptr, dir, MAX_PATH); *strrchr(dir, '\\') = 0;
  WV_SetOption(8, "65001"); WV_SetOption(9, "realrt_log.txt"); WV_Init(dir);
  SimInstall(false);
  if (sc == "missing") {  // 缺 icudtl.dat：查找时就排除，创建立即说明原因；放回文件后同一进程里能用（没有让客户端记住失败）
    int f = WV_RuntimeCheck(1); std::string reason = J("reason"), b0 = J("broken[0].reason");
    Check(f == 0 && reason.find("icudtl.dat") != std::string::npos && b0 == "缺少 icudtl.dat", "broken runtime excluded at discovery, reason names icudtl.dat", reason);
    Res r = Create(10000);
    Check(r.state == 2 && r.ms < 2000 && r.err.find("icudtl.dat") != std::string::npos, "creation fails at once with the precise reason", r.err);
    WV_Destroy(r.h);
    printf("INFO restore=%d\n", MoveFileA("WebView2\\icudtl.dat.bak", "WebView2\\icudtl.dat"));
    Check(WV_RuntimeCheck(1) == 1, "after restoring the file the runtime is found again", J("selected.dir"));
    Res r2 = Create(15000);
    Check(Proceeds(r2), "same process: browser startup proceeds (client never poisoned)", r2.err);
  } else if (sc == "busy") {  // icudtl.dat 被独占打开几秒：稍后自动重试，放开后照常启动
    Res r = Create(3000);
    Check(r.state == 2 && r.err.find("占用") != std::string::npos, "locked icudtl.dat reported as busy (not poisoned)", r.err);
    Pump(14000);
    int st = WV_GetInt(r.h, 47); std::string e = WV_GetStr(r.h, 114);
    printf("INFO after retries state=%d err=%s\n", st, e.c_str());
    Check(e.find("占用") == std::string::npos && e.find("0x80070002") == std::string::npos, "after the lock is released the automatic retry proceeds", e);
  } else if (sc == "vm") {  // 地址空间放不下 icudtl.dat：直接说明，不交给客户端；释放后同一进程里能用
    std::vector<void*> blocks;
    LoadLibraryExW(L"WebView2\\EBWebView\\x86\\EmbeddedBrowserWebView.dll", nullptr, LOAD_WITH_ALTERED_SEARCH_PATH);
    for (SIZE_T mb = 256; mb >= 8; mb /= 2) for (;;) { void* p = VirtualAlloc(nullptr, mb << 20, MEM_RESERVE, PAGE_NOACCESS); if (!p) break; blocks.push_back(p); }
    Res r = Create(10000);
    Check(r.state == 2 && r.ms < 2000 && r.err.find("地址空间") != std::string::npos, "no 12MB hole: explained, client not called", r.err);
    for (void* p : blocks) VirtualFree(p, 0, MEM_RELEASE);
    WV_Destroy(r.h);
    Res r2 = Create(15000);
    Check(Proceeds(r2), "after memory is freed the same process can start the browser", r2.err);
  } else if (sc == "poison") {  // 测试版 DLL（跳过预检）：客户端失败并记住失败后，本进程不再用它；装好另一个运行时后（指定了数据目录）自动可用
    WV_SetOption(4, "WebView2Data");
    Res r = Create(10000);
    Check(r.state == 2 && r.err.find("本次运行中") != std::string::npos, "client failure: runtime marked unusable for this process, card explains restart", r.err);
    printf("INFO restore=%d\n", MoveFileA("WebView2\\icudtl.dat.bak", "WebView2\\icudtl.dat"));
    Check(WV_RuntimeCheck(1) == 0 && J("broken[0].inProcess") == "true", "restored files do not resurrect the poisoned client in this process", J("reason"));
    SimInstall(true);
    Check(WV_RuntimeCheck(1) == 1 && J("selected.kind") == "installed", "newly installed runtime is selected", J("selected.dir"));
    WV_Destroy(r.h);
    Res r2 = Create(15000);
    Check(Proceeds(r2) && r2.err.find("数据目录") == std::string::npos, "recreate with the new runtime and the same explicit data folder proceeds (no conflict 14)", r2.err);
    SimInstall(false);
  } else if (sc == "switch") {  // 测试版 DLL（跳过预检）：先用固定版（策略 1），固定版的客户端失败并记住失败后，浏览器自己改用已安装的运行时
    SimInstall(true);
    WV_SetOption(3, "1");
    WV_SetOption(4, "WebView2Data");
    Res r = Create(15000);
    std::string kind = J("selected.kind");
    Check(Proceeds(r) && kind == "installed", "the fixed client fails and the view switches to the installed runtime by itself", r.err + " / " + kind);
    SimInstall(false);
  } else if (sc == "win7order") {  // Win7：已安装的 109 与程序目录的固定版都在时先用已安装的
    SimInstall(true);
    WV_RuntimeCheck(1);
    Check(J("legacyOs") == "true" && J("selected.kind") == "installed", "Win7: installed 109 preferred over fixed 109", J("selected.source"));
    SimInstall(false);
  } else if (sc == "install") {  // Win7 也会去下载安装（不再直接拒绝）；自动安装失败后 24 小时冷却，手动安装不受影响
    RegDeleteKeyW(HKEY_CURRENT_USER, L"Software\\WebView2Bridge");
    DWORD t0 = GetTickCount(); int r = WV_InstallRuntime(0, 90000); std::string e = WV_LastError(); DWORD ms = GetTickCount() - t0;
    printf("INFO manual install -> %d %lums %s\n", r, ms, e.c_str());
    Check(r == 0 && e.find("不能安装") == std::string::npos && !e.empty(), "install is attempted (not refused on Win7) and fails without network", e);
    t0 = GetTickCount(); r = WV_InstallRuntime(1, 90000); e = WV_LastError(); ms = GetTickCount() - t0;
    printf("INFO auto install -> %d %lums %s\n", r, ms, e.c_str());
    Check(r == 0 && ms < 1500 && e.find("24 小时") != std::string::npos, "automatic install within 24h of a failure returns at once", e);
    RegDeleteKeyW(HKEY_CURRENT_USER, L"Software\\WebView2Bridge");
  }
  printf("RESULT %s pass=%d fail=%d\n", sc.c_str(), g_pass, g_fail);
  return g_fail ? 1 : 0;
}
