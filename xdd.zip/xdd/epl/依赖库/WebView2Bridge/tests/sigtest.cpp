// 签名者读取测试：sigtest.exe 文件1 文件2 ...，逐个输出 Authenticode 签名者名称与 WinVerifyTrust 结果
// 与 DLL 共用 src/wv_sign.h 中的同一份代码
#include <windows.h>
#include <wintrust.h>
#include <softpub.h>
#include <cstdio>
#include "wv_sign.h"
int main(int argc, char** argv) {
  HMODULE c = LoadLibraryW(L"crypt32.dll");
  for (int i = 1; i < argc; ++i) {
    wchar_t w[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, argv[i], -1, w, MAX_PATH);
    std::wstring s = wvsign::AuthenticodeSigner(w, c);
    WINTRUST_FILE_INFO fi;
    ZeroMemory(&fi, sizeof(fi));
    fi.cbStruct = sizeof(fi);
    fi.pcwszFilePath = w;
    WINTRUST_DATA wd;
    ZeroMemory(&wd, sizeof(wd));
    wd.cbStruct = sizeof(wd);
    wd.dwUIChoice = WTD_UI_NONE;
    wd.fdwRevocationChecks = WTD_REVOKE_NONE;
    wd.dwUnionChoice = WTD_CHOICE_FILE;
    wd.pFile = &fi;
    wd.dwStateAction = WTD_STATEACTION_VERIFY;
    GUID a = WINTRUST_ACTION_GENERIC_VERIFY_V2;
    LONG r = WinVerifyTrust(nullptr, &a, &wd);
    wd.dwStateAction = WTD_STATEACTION_CLOSE;
    WinVerifyTrust(nullptr, &a, &wd);
    printf("SIGN %s | signer=[%ls] | WinVerifyTrust=0x%08lX\n", argv[i], s.c_str(), (unsigned long)r);
  }
  return 0;
}
