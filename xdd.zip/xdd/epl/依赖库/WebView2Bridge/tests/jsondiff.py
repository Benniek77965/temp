# JSON 取值与转义的差分测试（配合 tests/jsonfuzz.cpp）
#   python3 jsondiff.py gen  生成 cases.txt（文档与路径）、q_u.txt / q_g.txt（UTF-8 与 GBK 文本）及期望结果
#   python3 jsondiff.py cmp  对比 results.txt、r_u.txt、r_g.txt 与 Python json 模块的结果（取值还核对 length 与下标规则）；有不一致时退出码为 1
import json, random, base64, pickle, collections, sys

def gen():
    random.seed(20261015)
    KEYCH = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_中文键名测试值'
    STRPOOL = ['', 'hello', '中文内容', '😀👍', 'a"b', 'back\\slash', 'slash/', 'tab\there', 'line\nbreak', '\x01\x1f控制', 'é ñ ü', '𝄞', 'mixed 中 😀 "q" \\ /', ' spaces  ']
    def rkey(): return ''.join(random.choice(KEYCH) for _ in range(random.randint(1, 6)))
    def rval(d):
        r = random.random()
        if d > 0 and r < 0.25:
            ks = set(); o = {}
            for _ in range(random.randint(0, 5)):
                k = rkey()
                if k in ks: continue
                ks.add(k); o[k] = rval(d - 1)
            return o
        if d > 0 and r < 0.45: return [rval(d - 1) for _ in range(random.randint(0, 5))]
        r = random.random()
        if r < 0.3: return random.choice(STRPOOL) + (rkey() if random.random() < 0.5 else '')
        if r < 0.5: return random.choice([0, 1, -1, 42, 2**53 + 1, 1234567890123456789, -9223372036854775808, 12345678901234567890])
        if r < 0.65: return random.choice([0.1, -2.5, 1e-07, 3.141592653589793, 1e300, -0.0, 6.02e23])
        if r < 0.8: return random.choice([True, False])
        return None
    def paths(v, prefix, out):
        out.append((prefix, v))
        if isinstance(v, dict):
            for k, x in v.items(): paths(x, (prefix + '.' if prefix else '') + k, out)
        elif isinstance(v, list):
            for i, x in enumerate(v): paths(x, prefix + f'[{i}]', out)
    cases, expect = [], []
    for _ in range(3000):
        doc = rval(6)
        ensure = random.random() < 0.5
        indent = random.choice([None, None, 1, 2])
        seps = random.choice([(',', ':'), (', ', ': '), (' , ', ' : ')]) if indent is None else None
        text = json.dumps(doc, ensure_ascii=ensure, indent=indent, separators=seps)
        ps = []; paths(doc, '', ps)
        chosen = random.sample(ps, min(len(ps), 6))
        for p, v in chosen:
            cases.append((text, p)); expect.append(('S', v) if isinstance(v, str) else ('J', v))
        for bad in ['nokey_xyz', '[999]', (chosen[0][0] + '.zz9') if chosen and chosen[0][0] else 'zz9']:
            cases.append((text, bad)); expect.append(('N', None))
        # 路径规则（1.6.0 起）：数组后面跟 length（或 ["length"]）得到成员数，字符串没有 length；
        # 下标只认非负十进制整数，两边可以有空格，[x]、[1.5]、[-1]、[]、[0x1]、[+1]、[1e0] 都不是下标（按路径不存在处理）
        arrs = [(p, v) for p, v in ps if isinstance(v, list)]
        for p, v in random.sample(arrs, min(len(arrs), 2)):
            cases.append((text, (p + '.length') if p else 'length')); expect.append(('J', len(v)))
            cases.append((text, p + '["length"]')); expect.append(('J', len(v)))
            cases.append((text, p + random.choice(['[x]', '[1.5]', '[-1]', '[]', '[0x1]', '[+1]', '[1e0]']))); expect.append(('N', None))
            if v:
                cases.append((text, p + '[ 0 ]')); expect.append(('S', v[0]) if isinstance(v[0], str) else ('J', v[0]))
        strs_ = [(p, v) for p, v in ps if isinstance(v, str) and p]
        for p, v in random.sample(strs_, min(len(strs_), 1)):
            cases.append((text, p + '.length')); expect.append(('N', None))
    with open('cases.txt', 'w') as f:
        for t, p in cases: f.write(base64.b64encode(t.encode('utf-8')).decode() + '\t' + base64.b64encode(p.encode('utf-8')).decode() + '\n')
    pickle.dump(expect, open('expect.pkl', 'wb'))
    print('生成用例', len(cases))

    random.seed(7)
    pool_u = [chr(c) for c in list(range(1, 0x80)) + [0x7f, 0x80, 0xa0, 0xe9, 0x2028, 0x2029, 0x4e2d, 0x6587, 0xfeff, 0xfffd, 0x1f600, 0x1d11e, 0x20000]]
    pool_g = [chr(c) for c in range(1, 0x80)] + list('中文测试“引号”、，。！？…—·')
    strs = lambda pool, n: [''.join(random.choice(pool) for _ in range(random.randint(0, 40))) for _ in range(n)]
    def ok_gbk(s):
        try:
            s.encode('gbk'); return True
        except UnicodeEncodeError:
            return False
    U = strs(pool_u, 4000); G = [s for s in strs(pool_g, 4000) if ok_gbk(s)]
    open('q_u.txt', 'w').write(''.join(base64.b64encode(s.encode('utf-8')).decode() + '\n' for s in U))
    open('q_g.txt', 'w').write(''.join(base64.b64encode(s.encode('gbk')).decode() + '\n' for s in G))
    pickle.dump((U, G), open('q.pkl', 'wb'))

def cmp():
    expect = pickle.load(open('expect.pkl', 'rb'))
    res = [base64.b64decode(l.strip()).decode('utf-8', 'replace') for l in open('results.txt')]
    cases = [l.rstrip('\n').split('\t') for l in open('cases.txt')]
    bad = collections.Counter(); ex = {}
    for i, ((kind, val), r) in enumerate(zip(expect, res)):
        ok = True
        if kind == 'S': ok = (r == val)
        elif kind == 'N': ok = (r == '')
        else:
            try: ok = (json.loads(r) == val) and not (isinstance(val, bool) != isinstance(json.loads(r), bool))
            except Exception: ok = False
        if not ok:
            bad[kind] += 1
            ex.setdefault(kind, []).append((base64.b64decode(cases[i][1]).decode(), repr(val)[:80], r[:80], base64.b64decode(cases[i][0]).decode()[:120]))
    print('结果', len(res), '期望', len(expect), '不一致', dict(bad))
    total = sum(bad.values()) + abs(len(res) - len(expect))  # 结果条数不对也算不一致
    for k, v in ex.items():
        for e in v[:4]: print(' ', k, '路径', repr(e[0]), '期望', e[1], '得到', repr(e[2]), '文档', repr(e[3]))

    U, G = pickle.load(open('q.pkl', 'rb'))
    for name, src, enc, f in [('UTF-8', U, 'utf-8', 'r_u.txt'), ('GBK', G, 'gbk', 'r_g.txt')]:
        rows = [l.rstrip('\n').split('\t') for l in open(f)]
        bad = 0
        for s, (q, b) in zip(src, rows):
            qt = base64.b64decode(q).decode(enc, 'replace'); bt = base64.b64decode(b).decode(enc, 'replace')
            try:
                good = json.loads(qt) == s and bt == s
            except Exception:
                good = False
            bad += not good
        print(f'{name} 转义往返：{len(rows)} 个，不一致 {bad}')
        total += bad + abs(len(rows) - len(src))
    # 有不一致时退出码为 1：run_all.sh 按退出码判断，原来这里总是 0，不一致也会显示为通过
    print(f'合计：取值 {len(res)} 个，转义往返 {len(U) + len(G)} 个，不一致 {total}')
    sys.exit(1 if total else 0)

if __name__ == '__main__':
    {'gen': gen, 'cmp': cmp}[sys.argv[1] if len(sys.argv) > 1 else 'gen']()
