// handofftest.cpp : 开发者测试：跨线程转交的压力测试（1.5.2 复查时新增）
// i686-w64-mingw32-g++ -std=c++17 -O1 -static tests\handofftest.cpp -o handofftest.exe   （与 WebView2Bridge.dll 放在同一目录运行）
// 跨线程转交压力测试：界面线程交替“处理消息”与“不处理消息”，8 个工作线程反复调用需要转交到界面线程的接口，
// 开始时限设得很短（3 毫秒），让大量调用落在“刚开始执行 / 刚被取消”的边界上。检查：不崩溃、不卡死、每次调用要么成功
// 要么得到 WVERR_THREAD，成功与取消两种情况都大量出现；迟到的转交消息找不到任务，直接忽略
#include <windows.h>
#include <cstdio>
#include <cstring>
#include <atomic>
typedef int(__stdcall* SetOptFn)(int, const char*);
typedef const char*(__stdcall* DiagFn)(void);
typedef int(__stdcall* ErrFn)(void);
typedef int(__stdcall* InitFn)(const char*);
typedef int(__stdcall* CreateFn)(HWND, int, int, int, int, const char*, const char*, void*);
typedef int(__stdcall* GetWinFn)(int, int);
static DiagFn pDiag;
static ErrFn pErr;
static GetWinFn pGetWin;
static std::atomic<int> g_ok{0}, g_cancel{0}, g_other{0}, g_done{0};
static int g_view;
static HWND g_parent;
static const int kWorkers = 8, kCalls = 300;
static DWORD WINAPI Worker(LPVOID p) {
  const int id = (int)(intptr_t)p;
  for (int i = 0; i < kCalls; ++i) {
    if ((i + id) & 1) {  // WithUi：诊断信息里界面线程上的部分
      const char* s = pDiag();
      const int e = pErr();
      if (e == 0 && s && strstr(s, "\"views\":[{")) ++g_ok;
      else if (e == 8 && s && strstr(s, "\"views\":[]")) ++g_cancel;
      else ++g_other;
    } else {  // WithView：取父窗口
      const int r = pGetWin(g_view, 1);
      const int e = pErr();
      if (e == 0 && (HWND)(intptr_t)r == g_parent) ++g_ok;
      else if (e == 8 && r == 0) ++g_cancel;
      else ++g_other;
    }
  }
  ++g_done;
  return 0;
}
int main() {
  HMODULE m = LoadLibraryA("WebView2Bridge.dll");
  if (!m) { printf("载入失败\n"); return 2; }
  SetOptFn so = (SetOptFn)(void*)GetProcAddress(m, "WV_SetOption");
  InitFn init = (InitFn)(void*)GetProcAddress(m, "WV_Init");
  CreateFn create = (CreateFn)(void*)GetProcAddress(m, "WV_CreateAsync");
  pDiag = (DiagFn)(void*)GetProcAddress(m, "WV_GetDiagnostics");
  pErr = (ErrFn)(void*)GetProcAddress(m, "WV_LastErrorCode");
  pGetWin = (GetWinFn)(void*)GetProcAddress(m, "WV_GetWindow");
  g_parent = CreateWindowExA(0, "STATIC", "p", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 300, 200, nullptr, nullptr, nullptr, nullptr);
  init(nullptr);
  g_view = create(g_parent, 0, 0, 0, 0, "about:blank", "", nullptr);  // 没有运行时：保留宿主窗口显示提示卡片，句柄有效
  so(19, "3");  // WVO_THREAD_TIMEOUT
  HANDLE th[kWorkers];
  for (int k = 0; k < kWorkers; ++k) th[k] = CreateThread(nullptr, 0, Worker, (LPVOID)(intptr_t)k, 0, nullptr);
  unsigned seed = 12345, round = 0;
  const DWORD t0 = GetTickCount();
  MSG msg;
  while (g_done < kWorkers && GetTickCount() - t0 < 120000) {
    seed = seed * 1103515245u + 12345u;
    ++round;
    const DWORD pumpMs = (seed >> 16) % 6, blockMs = round % 40 == 1 ? 20 : (seed >> 8) % 6;  // 第 1 轮起每 40 轮阻塞 20 毫秒：等着的调用一定会超时取消
    const DWORD s0 = GetTickCount();
    do {
      while (PeekMessageA(&msg, nullptr, 0, 0, PM_REMOVE)) DispatchMessageA(&msg);
    } while (GetTickCount() - s0 < pumpMs);
    Sleep(blockMs);  // 不处理消息：这段时间里到达的转交大多会超时取消
  }
  WaitForMultipleObjects(kWorkers, th, TRUE, 5000);
  for (int i = 0; i < 50; ++i) {  // 处理迟到的转交消息
    while (PeekMessageA(&msg, nullptr, 0, 0, PM_REMOVE)) DispatchMessageA(&msg);
    Sleep(2);
  }
  so(19, "");
  const int total = g_ok + g_cancel + g_other;
  const bool pass = g_done == kWorkers && g_other == 0 && total == kWorkers * kCalls && g_ok > 0 && g_cancel > 0;
  printf("%s handoff stress: %d calls, %d completed, %d cancelled (WVERR_THREAD), %d unexpected, %lu ms\n", pass ? "PASS" : "FAIL", total, (int)g_ok,
         (int)g_cancel, (int)g_other, GetTickCount() - t0);
  printf("RESULT pass=%d fail=%d\n", pass ? 1 : 0, pass ? 0 : 1);
  return pass ? 0 : 1;
}
