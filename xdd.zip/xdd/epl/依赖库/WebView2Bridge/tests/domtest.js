// 网页元素脚本测试：从 src/wv_feat.cpp 原样取出 DLL 内嵌的元素操作脚本（kDomJs），在 jsdom 里逐个动作（WVD_ 常量）检查。
// 用法：npm install jsdom 后运行 node tests/domtest.js（jsdom 不在本工程里：可以装在任意目录，用 NODE_PATH 指向它的 node_modules）。
// jsdom 没有实现排版，innerText、isContentEditable、scrollIntoView 在这里按浏览器的行为补上；坐标都是 0
'use strict';
const fs = require('fs'), path = require('path');
let JSDOM;
try { ({ JSDOM } = require('jsdom')); } catch (e) { console.log('需要 jsdom：npm install jsdom'); process.exit(2); }
const src = fs.readFileSync(path.join(__dirname, '..', 'src', 'wv_feat.cpp'), 'utf8');
function cppWide(name) {
  let p = src.indexOf('=', src.indexOf('static const wchar_t* ' + name + ' =')) + 1, raw = '';
  const re = /\s*L"((?:[^"\\]|\\.)*)"/y;
  for (let m; (re.lastIndex = p, m = re.exec(src)); p = re.lastIndex) raw += m[1];
  return raw.replace(/\\(u[0-9a-fA-F]{4}|x[0-9a-fA-F]{2}|.)/g, (_, e) => e[0] === 'u' || e[0] === 'x' ? String.fromCharCode(parseInt(e.slice(1), 16)) : ({ n: '\n', r: '\r', t: '\t', 0: '\0' })[e] || e);
}
const W = { EXISTS: 1, CLICK: 2, SET_VALUE: 3, GET_TEXT: 4, GET_HTML: 5, GET_VALUE: 6, GET_ATTR: 7, SET_ATTR: 8, FOCUS: 9, SCROLL: 10, COUNT: 11, REMOVE: 12, SUBMIT: 13, CHECK: 14, SELECT: 15, GET_ALL_TEXT: 16, SET_HTML: 17, RECT: 18 };
const dom = new JSDOM('<form id=f><input id=in value=a><textarea id=ta></textarea><select id=sel><option value=1>一</option><option value=2> 二 </option></select>' +
  '<input type=checkbox id=cb><input type=radio name=r id=r1><input type=radio name=r id=r2><div id=ce contenteditable=true>x</div><button id=btn type=button>b</button><input id=dis disabled><button id=dbtn type=button disabled>d</button></form><form id=f2><input id=req required><button id=go>go</button></form><form id=f3 novalidate><input id=req3 required></form><fieldset disabled><button id=fsb type=button>f</button></fieldset>' +
  '<p id=p data-x="属性">段落</p><ul><li>一</li><li>二</li><li>三</li></ul><div id=box></div><span id=lone>lone</span>', { runScripts: 'outside-only' });
const win = dom.window, doc = win.document;
Object.defineProperty(win.HTMLElement.prototype, 'innerText', { get() { return this.textContent; }, set(v) { this.textContent = v; }, configurable: true });
Object.defineProperty(win.HTMLElement.prototype, 'isContentEditable', { get() { return this.getAttribute('contenteditable') === 'true'; }, configurable: true });
win.Element.prototype.scrollIntoView = function () {};
win.eval('var __dom = ' + cppWide('kDomJs') + ';');
const run = (sel, val, act) => win.__dom(sel, val, act);
let pass = 0, fail = 0;
function check(ok, name, got) { if (ok) { pass++; console.log('PASS ' + name); } else { fail++; console.log('FAIL ' + name + '  [' + JSON.stringify(got) + ']'); } }
check(run('#in', '', W.EXISTS) === true && run('#nope', '', W.EXISTS) === false && run('//p[@id="p"]', '', W.EXISTS) === true && run('###', '', W.EXISTS) === false, 'exists: CSS, XPath, missing, invalid selector');
check(run('#nope', '', W.GET_TEXT) === null, 'missing element gives null (DLL reports “没有找到元素”)');
let clicks = 0; doc.getElementById('btn').addEventListener('click', () => clicks++);
check(run('#btn', '', W.CLICK) === true && clicks === 1, 'click');
const inp = doc.getElementById('in'), ev = [];
inp.addEventListener('input', () => ev.push('input')); inp.addEventListener('change', () => ev.push('change'));
let tracked = 0; const nativeDesc = Object.getOwnPropertyDescriptor(win.HTMLInputElement.prototype, 'value');
Object.defineProperty(inp, 'value', { configurable: true, get() { return nativeDesc.get.call(this); }, set(v) { tracked++; nativeDesc.set.call(this, v); } });  // 仿 React 在元素上改写 value
check(run('#in', '你好', W.SET_VALUE) === true && nativeDesc.get.call(inp) === '你好' && tracked === 0 && ev.join() === 'input,change', 'set value through the native setter (React/Vue see the change), fires input and change', { tracked, ev });
check(run('#ta', '多行', W.SET_VALUE) === true && doc.getElementById('ta').value === '多行', 'set value of a textarea');
check(run('#sel', '2', W.SET_VALUE) === true && doc.getElementById('sel').value === '2', 'set value of a select');
check(run('#ce', '可编辑', W.SET_VALUE) === true && doc.getElementById('ce').textContent === '可编辑', 'set value of a contenteditable element');
check(run('#p', 'x', W.SET_VALUE) === false, 'set value of an element without value fails');
check(run('#p', '', W.GET_TEXT) === '段落' && /data-x/.test(run('#p', '', W.GET_HTML)) && run('#in', '', W.GET_VALUE) === '你好', 'get text, html, value');
check(run('#p', 'data-x', W.GET_ATTR) === '属性' && run('#p', 'nope', W.GET_ATTR) === '', 'get attribute (missing gives empty text)');
check(run('#p', 'data-y=新=值', W.SET_ATTR) === true && doc.getElementById('p').getAttribute('data-y') === '新=值' && run('#p', 'flag', W.SET_ATTR) === true && doc.getElementById('p').getAttribute('flag') === '', 'set attribute (name=value, value may contain =; bare name)');
check(run('#ta', '', W.FOCUS) === true && doc.activeElement === doc.getElementById('ta') && run('#p', '', W.SCROLL) === true, 'focus and scroll');
check(run('#dis', '', W.FOCUS) === false && run('#p', '', W.FOCUS) === false && doc.activeElement === doc.getElementById('ta'), 'focus on a disabled or non-focusable element reports false and keeps the old focus (typing would go elsewhere)');
check(run('li', '', W.COUNT) === 3 && run('//li', '', W.COUNT) === 3 && run('.none', '', W.COUNT) === 0, 'count with CSS and XPath');
check(run('li', '', W.GET_ALL_TEXT) === '["一","二","三"]', 'all texts as a JSON array', run('li', '', W.GET_ALL_TEXT));
let submits = 0; doc.getElementById('f').addEventListener('submit', e => { submits++; e.preventDefault(); });
check(run('#in', '', W.SUBMIT) === true && submits === 1 && run('#p', '', W.SUBMIT) === false, 'submit the form of an element; element outside a form fails');
const cb = doc.getElementById('cb'), r1 = doc.getElementById('r1');
check(run('#cb', '1', W.CHECK) === true && cb.checked && run('#cb', '0', W.CHECK) === true && !cb.checked && run('#cb', '', W.CHECK) === true && cb.checked && run('#cb', '假', W.CHECK) === true && !cb.checked, 'check and uncheck a checkbox (1, 0, empty, 假)');
check(run('#r1', '1', W.CHECK) === true && r1.checked, 'check a radio button');
check(run('#r1', '0', W.CHECK) === false && r1.checked, 'unchecking a radio button cannot be done by clicking: reports false instead of success');
check(run('#p', '1', W.CHECK) === false, 'checking an element that is not a checkbox reports false');
const sel = doc.getElementById('sel'), sev = []; sel.addEventListener('change', () => sev.push('change'));
check(run('#sel', '二', W.SELECT) === true && sel.value === '2' && run('#sel', '1', W.SELECT) === true && sel.value === '1' && sev.length === 2, 'select by shown text (trimmed) or value, fires change');
check(run('#sel', '没有', W.SELECT) === false && sel.value === '1', 'select a missing option fails and keeps the selection');
check(run('#box', '<b>粗</b>', W.SET_HTML) === true && doc.getElementById('box').innerHTML === '<b>粗</b>', 'set innerHTML');
let dclicks = 0; doc.getElementById('dbtn').addEventListener('click', () => dclicks++); doc.getElementById('fsb').addEventListener('click', () => dclicks++);
check(run('#dbtn', '', W.CLICK) === false && run('#fsb', '', W.CLICK) === false && dclicks === 0, 'click on a disabled button (or one inside a disabled fieldset) reports false instead of a silent no-op');
let s2 = 0, s3 = 0; doc.getElementById('f2').addEventListener('submit', e => { s2++; e.preventDefault(); }); doc.getElementById('f3').addEventListener('submit', e => { s3++; e.preventDefault(); });
check(run('#req', '', W.SUBMIT) === 'invalid' && s2 === 0, 'submit a form with an empty required field: reports invalid, not submitted');
doc.getElementById('req').value = 'x';
check(run('#req', '', W.SUBMIT) === true && s2 === 1 && run('#req3', '', W.SUBMIT) === true && s3 === 1, 'valid form is submitted; novalidate form skips validation');
check(run('#dbtn', '', 19) === 'disabled' && JSON.parse(run('#btn', '', 19)).w !== undefined, 'trusted click step: disabled element reported, enabled one gives its rect');
const rect = JSON.parse(run('#in', '', W.RECT));
check(['x', 'y', 'w', 'h'].every(k => typeof rect[k] === 'number'), 'rect gives {x,y,w,h}', rect);
check(run('#lone', '', W.REMOVE) === true && !doc.getElementById('lone'), 'remove');
console.log('RESULT pass=' + pass + ' fail=' + fail);
process.exitCode = fail ? 1 : 0;
