/*
 * WebView2Bridge：易语言与 C/C++ 通用的 WebView2 中间层（32 位 DLL，全部为 stdcall 纯 C 导出）
 *
 * 依赖：只依赖 Windows 系统 DLL 与 Microsoft Edge WebView2 运行时，不需要 WebView2Loader.dll。
 * 内核：DLL 载入时判定系统版本；Win7/8/8.1 自动选用 v109 内核（固定版目录或已安装的 109 版），
 *       Win10/11 优先用系统已安装的常青版新内核，没有时再用程序目录里的固定版运行时。
 *
 * 文本约定：
 *   入参 const char* 按“当前代码页”解释（默认系统 ANSI 代码页，中文系统即 GBK；可用 WVO_CODEPAGE 改为 65001=UTF-8）。
 *   每行一项的文本（创建选项、文本属性、协议头与应答头、Cookie 文本、响应捕获的通配符）逐行转换：代码页为 UTF-8 而某一行不是合法的 UTF-8 时，
 *   只有这一行按系统 ANSI 代码页解释，其它行不受连累。
 *   返回 const char* 的函数把结果放在“调用线程专用”的缓冲区里，下一次同线程调用返回文本的函数前一直有效，请立即复制。
 *   返回 JSON 的函数会把当前代码页无法表示的字符写成 \uXXXX，保证经过 GBK 也不丢字。
 * 线程约定：浏览器属于创建它的界面线程。其它线程调用接口时会自动转到界面线程同步执行；界面线程在 WVO_THREAD_TIMEOUT（默认 10 秒）
 *           内没有开始执行（例如它正在等待调用方线程结束）时，这次调用失败返回（WVERR_THREAD），不会两边一直互相等待。
 * 回调约定：所有回调都是 stdcall，参数都是 4 字节（整数、逻辑、文本指针、整数指针）；DLL 用保护桩调用：参数写少或多写（16 个以内）
 *           都不会破坏堆栈与内存，多写的参数收到指向空数据的指针（文本为空，给“参考”参数赋值无效）；参数表与事件不符时（声明为没有参数的
 *           子程序与 cdecl 回调无法区分，不算在内）写日志并记入
 *           WV_GetDiagnostics 的 checks.callbackMismatch，开发期检查（WVO_DEV_CHECKS）为 1 时还会弹出说明。回调总在界面线程触发。
 */
#ifndef WV2BRIDGE_H
#define WV2BRIDGE_H

#include <windows.h>

#ifdef __cplusplus
#define WV_EXTERN_C extern "C"
#else
#define WV_EXTERN_C
#endif
#if defined(WV2BRIDGE_BUILD) && defined(_MSC_VER)
#define WV_API WV_EXTERN_C /* MSVC 由 wv2bridge.def 导出无修饰名 */
#elif defined(WV2BRIDGE_BUILD)
#define WV_API WV_EXTERN_C __declspec(dllexport)
#else
#define WV_API WV_EXTERN_C __declspec(dllimport)
#endif
#define WV_CALL __stdcall

#define WV_BRIDGE_VERSION 10803 /* 1.8.3：主版本*10000 + 次版本*100 + 修订号 */

/* ---------------- 全局选项 WV_SetOption / WV_GetOption（在创建浏览器之前设置；文本去掉首尾空白） ---------------- */
#define WVO_APP_DIR              1  /* 程序目录（易语言传 取运行目录()；用于查找运行时与默认数据目录）；必须是已存在的目录，否则设置失败并保留原值；相对路径按当前目录换成完整路径 */
#define WVO_RUNTIME_DIR          2  /* 指定固定版运行时目录（可填上级目录，自动向下查找） */
#define WVO_RUNTIME_POLICY       3  /* 0自动 1优先固定版 2只用已安装常青版 3只用固定版 */
#define WVO_USER_DATA_DIR        4  /* 用户数据目录（Cookie、缓存等）；空＝程序目录\WebView2Data（不可写时改用 LOCALAPPDATA） */
#define WVO_BROWSER_ARGS         5  /* 附加浏览器启动参数，如 --disable-features=msSmartScreenProtection */
#define WVO_LANGUAGE             6  /* 界面语言，如 zh-CN */
#define WVO_PROXY                7  /* 代理：127.0.0.1:7890 / socks5://127.0.0.1:1080 / direct（不使用系统代理）；不能含空格或引号，否则设置失败 */
#define WVO_CODEPAGE             8  /* 文本代码页：0=系统ANSI(默认) 65001=UTF-8；系统不支持的代码页设置失败（WVERR_ARG） */
#define WVO_LOG_FILE             9  /* 诊断日志文件路径（相对路径按程序目录，随时可以设置）；空＝不写文件（始终输出到 OutputDebugString） */
#define WVO_DISABLE_GPU         10  /* "1" 关闭 GPU 加速（老旧显卡花屏/黑屏时用） */
#define WVO_AUTOPLAY            11  /* "1" 允许媒体无需用户手势自动播放 */
#define WVO_IGNORE_CERT_ERRORS  12  /* "1" 浏览器级忽略证书错误（仅限调试）；忽略后网页来源可被网络上的攻击者冒充，JS 桥的来源限制不再可靠 */
#define WVO_TRACKING_PREVENTION 13  /* "0" 关闭跟踪防护；"1" 开启；空＝默认 */
#define WVO_SCROLLBAR_STYLE     14  /* "1" Fluent 悬浮滚动条（新内核支持，109 内核忽略） */
#define WVO_DEFAULT_BG          15  /* 默认背景色：#RRGGBB、#AARRGGBB 或 transparent，其余写法设置失败（WVERR_ARG）；提示卡片按它（或 WVP_BG_COLOR）自动用浅色或深色样式 */
#define WVO_FALLBACK_UI         16  /* "1"(默认) 无运行时、启动失败，或浏览器进程退出而没有自动恢复（关闭了自动恢复，或短时间内反复退出）时，在原位置显示提示卡片（可用键盘操作，读屏软件可读出内容与按钮，高对比度主题下用系统配色）；"0" 都不显示，交给程序自己处理 */
#define WVO_JSON_ESCAPE         17  /* JSON 输出里写成 \uXXXX 的字符："0"(默认) 文本代码页表示不了的（代码页为 UTF-8 时都不转义）；
                                       "1" 系统 ANSI 代码页表示不了的（文本用 UTF-8、调用方再转回 ANSI 时用，转回后 JSON 不丢字符）；"2" 全部非 ASCII 字符 */
#define WVO_CALLBACK_HOOK       18  /* 回调转发（十进制地址，可以是负数、按 32 位无符号解释；空或 0 取消）。设置后 DLL 不直接调用回调，而是调用
                                       转发(回调地址, 事件号, 参数个数, 参数数组地址, 文本掩码)，由它转换文本后调用回调地址并返回其返回值。
                                       事件号即 WVE_ 常量（WV_Bind 的回调为 WVE_JS_CALL，WV_ExecScriptAsync 的回调为 0）；
                                       文本掩码第 i 位为 1 表示第 i 个参数（从 0 起，第 0 个是浏览器句柄）是文本指针。
                                       按 WVE_FLAG_NO_OUT 注册的事件，参数个数与参数数组不含最后的 int*（回调按只读参数调用，回填结果用 WV_EvSetInt）。
                                       供需要转换文本编码的语言绑定使用，一般程序不需要（易语言类不使用：它的文本一律是 UTF-8） */
#define WVO_THREAD_TIMEOUT      19  /* 其它线程调用接口时，最多等界面线程多少毫秒开始执行（十进制；空＝默认 10000，0＝一直等）。超时说明界面线程正在等待
                                       调用方线程或长时间没有处理消息，这次调用失败（WVERR_THREAD）；已经开始执行的调用总会等它执行完 */
#define WVO_DEV_CHECKS          20  /* 开发期检查："0"(默认) 关闭；"1" 打开并在发现问题时弹出说明（每个问题只提示一次）；"2" 打开但只写日志、不弹出。
                                       打开后，文本代码页为 UTF-8 时收到不合法的 UTF-8（例如没有转换的 GBK 文本）调用失败（WVERR_ENCODING），不再按 ANSI 猜测；
                                       回调参数表与事件不符时（参见回调约定）提示。易语言模块在调试运行时自动设为 1 */

/* ---------------- 每个浏览器的整数属性 WV_SetInt / WV_GetInt ---------------- */
#define WVP_DEVTOOLS             1  /* 开发者工具(F12) */
#define WVP_CONTEXT_MENU         2  /* 右键菜单：0默认 1禁用 2精简(只保留复制粘贴等编辑项) */
#define WVP_SCRIPT               3  /* 允许 JavaScript */
#define WVP_WEB_MESSAGE          4  /* 允许网页消息（JS 桥依赖它） */
#define WVP_SCRIPT_DIALOGS       5  /* 默认 alert/confirm/prompt 对话框 */
#define WVP_STATUS_BAR           6  /* 左下角链接状态栏 */
#define WVP_ZOOM_CONTROL         7  /* Ctrl+滚轮/Ctrl+加减号 缩放 */
#define WVP_HOST_OBJECTS         8  /* 宿主对象 */
#define WVP_ERROR_PAGE           9  /* 内置错误页 */
#define WVP_ACCELERATOR_KEYS    10  /* 浏览器快捷键（F5、Ctrl+F 等） */
#define WVP_PASSWORD_AUTOSAVE   11  /* 保存密码提示 */
#define WVP_AUTOFILL            12  /* 表单自动填充 */
#define WVP_PINCH_ZOOM          13  /* 触摸屏双指缩放 */
#define WVP_SWIPE_NAV           14  /* 触摸屏左右滑动前进后退 */
#define WVP_PDF_TOOLBAR_HIDE    15  /* 隐藏 PDF 工具栏按钮（位标志，见 COREWEBVIEW2_PDF_TOOLBAR_ITEMS） */
#define WVP_SMARTSCREEN         16  /* SmartScreen 信誉检查 */
#define WVP_ZOOM                30  /* 缩放百分比，100＝原始大小 */
#define WVP_VISIBLE             31  /* 是否可见 */
#define WVP_MUTED               32  /* 静音 */
#define WVP_PLAYING_AUDIO       33  /* 只读：是否正在播放声音 */
#define WVP_CAN_BACK            34  /* 只读：能否后退 */
#define WVP_CAN_FORWARD         35  /* 只读：能否前进 */
#define WVP_LOADING             36  /* 只读：是否正在加载 */
#define WVP_BG_COLOR            37  /* 背景色 0xAARRGGBB；透明度为0＝透明：网页透明处显示父窗口的背景（Windows 7 不支持透明） */
#define WVP_NEW_WINDOW          38  /* 新窗口：0默认弹窗 1在当前浏览器打开(默认；javascript、data、内部页面及网页打开本地文件的请求不打开) 2拦截 3用系统浏览器打开(只限 http/https/mailto 网址) 4只触发事件 */
#define WVP_PERMISSION          39  /* 权限请求：0默认询问 1全部允许 2全部拒绝 */
#define WVP_IGNORE_CERT         40  /* 忽略证书错误（需 Edge 104+ 内核）；忽略后网页来源可被网络上的攻击者冒充，JS 桥的来源限制不再可靠 */
#define WVP_FULLSCREEN          41  /* 网页全屏(视频等)：0只铺满浏览器区域 1自动铺满整个显示器(默认) */
#define WVP_AUTO_RECOVER        42  /* 进程崩溃自动恢复：0不处理 1自动(默认；60 秒内最多自动恢复 3 次，再崩溃时显示“页面意外关闭了”卡片或只触发“进程崩溃”事件)；
                                      重建后自动恢复映射目录、注入的脚本与 DevTools 事件订阅，DevTools 协议的 enable 等调用请在 WVE_READY 里重新执行 */
#define WVP_COLOR_SCHEME        43  /* 网页配色偏好：0跟随系统 1浅色 2深色 */
#define WVP_SILENT_DOWNLOAD     44  /* 静默下载：不弹下载框，直接保存到下载目录 */
#define WVP_BLOCK_IMAGES        45  /* 不加载图片（采集提速） */
#define WVP_IS_FULLSCREEN       46  /* 只读：当前是否网页全屏 */
#define WVP_STATE               47  /* 只读：0创建中 1就绪 2失败 3已关闭 */
#define WVP_PROCESS_ID          48  /* 只读：浏览器主进程 PID */
#define WVP_SUSPENDED           49  /* 只读：是否已挂起 */
#define WVP_BRIDGE              50  /* JS 桥：1启用(绑定函数、设置 WVE_JS_CALL 事件、WV_Emit 时自动启用) 0停用 */
#define WVP_DOWNLOAD_DIALOG_OPEN 51 /* 只读：下载面板是否打开 */
#define WVP_EXTERNAL_DROP       52  /* 允许把外部文件拖进网页 */
#define WVP_NONCLIENT_REGION    53  /* 网页标题栏：网页里 CSS 写 app-region: drag 的元素当作窗口标题栏（拖动窗口、双击最大化、右键系统菜单），no-drag 排除其中的按钮；
                                       默认关闭，改动在下一次打开网页后生效（在创建前设置则首个页面就生效）；需要 Edge 123 及以上内核，109 内核报告不支持 */

/* ---------------- 每个浏览器的文本属性 WV_SetStr / WV_GetStr（写入的文本删掉回车、换行换成空格、去掉首尾空白，与创建选项的写法相同） ---------------- */
#define WVS_USER_AGENT         100  /* UA */
#define WVS_URL                101  /* 只读：当前网址 */
#define WVS_TITLE              102  /* 只读：网页标题 */
#define WVS_DOWNLOAD_DIR       103  /* 下载保存目录（空＝系统默认“下载”目录） */
#define WVS_BRIDGE_NAME        104  /* JS 桥对象名，默认 epl（网页里用 window.epl） */
#define WVS_BRIDGE_ORIGINS     105  /* JS 桥白名单：分号分隔（也可以用逗号、空格或换行，每行一项），如 https://app.example；每项的来源(协议+主机+端口)与可选的路径分别比较，通配符(星号)只作用于所在部分；路径不带通配符时按前缀比较(只在路径边界处匹配)；
                                      空＝只放行本程序自己的内容：程序目录（WVO_APP_DIR）及其子目录里的本地文件（各浏览器的用户数据目录、WVS_DOWNLOAD_DIR 指定的下载目录与本次运行里下载过的文件除外：这些是浏览器替网页写的文件）、映射目录的主机（网址对应的文件落在上述位置时同样不算），以及 .example/.test/.invalid 主机下的 https 页面（加载HTML 的页面在其中，内存文件与拦截返回的页面也可放在这类主机下）；
                                      其它目录与网络共享上的本地文件（包括拖进浏览器的文件）不算，需要时把文件夹列进白名单，如 file:///D:/ui（按解码后的路径放行这个文件夹里的页面：中文直接写，空格写 %20，不区分大小写）；* 放行全部来源。
                                      WV_Emit 推送的事件同样只发给允许的网页 */
#define WVS_STATUS_TEXT        106  /* 只读：状态栏文本 */
#define WVS_FAVICON_URL        107  /* 只读：网页图标地址 */
#define WVS_BLOCK_KEYS         108  /* 屏蔽快捷键：逗号分隔（也可以用空格或换行，每行一项；加号两边可以有空格），如 F5,F12,Ctrl+P,Ctrl+Shift+I */
#define WVS_BLOCK_URLS         109  /* 屏蔽网址：分号分隔的通配符（也可以用空格或换行，每行一项），如 *.doubleclick.net* 和 *.gif */
#define WVS_USER_DATA_DIR      110  /* 只读：实际使用的用户数据目录 */
#define WVS_BROWSER_VERSION    111  /* 只读：实际使用的内核版本 */
#define WVS_PROFILE_PATH       112  /* 只读：配置文件目录 */
#define WVS_PROFILE_NAME       113  /* 只读：配置名称 */
#define WVS_LAST_ERROR         114  /* 只读：本浏览器最近的创建失败原因 */
#define WVS_RUNTIME_DIR        115  /* 只读：本浏览器使用的运行时目录 */

/* ---------------- 事件 WV_SetEvent（括号内为回调参数，h 为浏览器句柄，int* 为“参考”参数） ---------------- */
#define WVE_READY              1  /* (h, 是否成功)                                         创建完成 */
#define WVE_NAV_STARTING       2  /* (h, 网址, 用户发起, 是重定向, int* 取消)               将要跳转 */
#define WVE_NAV_COMPLETED      3  /* (h, 网址, 是否成功, HTTP状态码, 错误码)                加载完成 */
#define WVE_SOURCE_CHANGED     4  /* (h, 网址)                                              网址改变 */
#define WVE_TITLE_CHANGED      5  /* (h, 标题)                                              标题改变 */
#define WVE_DOM_READY          6  /* (h, 网址)                                              DOM 就绪 */
#define WVE_MESSAGE            7  /* (h, 文本, JSON, 来源网址)                              收到网页消息 */
#define WVE_NEW_WINDOW         8  /* (h, 网址, 用户发起, int* 处理方式)                      新窗口请求；处理方式的初值是 WVP_NEW_WINDOW 的当前设置，改为 0 时按 WebView2 默认弹出新窗口 */
#define WVE_DOWNLOAD_START     9  /* (h, 下载ID, 网址, 保存路径, int* 取消)                  下载开始 */
#define WVE_DOWNLOAD_PROGRESS 10  /* (h, 下载ID, 百分比, 已下载KB, 总KB)                    下载进度 */
#define WVE_DOWNLOAD_DONE     11  /* (h, 下载ID, 结果(1完成 2中断), 保存路径)               下载结束 */
#define WVE_PERMISSION        12  /* (h, 网址, 权限类型, int* 状态(0默认 1允许 2拒绝))      权限请求 */
#define WVE_PROCESS_FAILED    13  /* (h, 进程类型, 原因)                                    进程崩溃 */
#define WVE_FULLSCREEN        14  /* (h, 是否全屏)                                          全屏改变 */
#define WVE_CLOSE_REQUESTED   15  /* (h)                                                    网页请求关闭 window.close() */
#define WVE_KEY               16  /* (h, 虚拟键码, 类型(0按下1放开2系统键按下3系统键放开), 修饰键(1Ctrl 2Shift 4Alt), int* 已处理) */
#define WVE_FAVICON           17  /* (h, 图标网址)                                          图标改变 */
#define WVE_STATUS_TEXT       18  /* (h, 文本)                                              状态栏文本改变 */
#define WVE_AUDIO             19  /* (h, 正在播放, 已静音)                                  声音状态改变 */
#define WVE_SCRIPT_DIALOG     20  /* (h, 类型(0alert 1confirm 2prompt 3离开页面), 消息, 网址, int* 确定)  确定的初值为 1 */
#define WVE_AUTH              21  /* (h, 网址, 认证说明, int* 取消)  上下文 WVK_SET_USERNAME/WVK_SET_PASSWORD 填写账号 */
#define WVE_REQUEST           22  /* (h, 网址, 方法, 资源类型, int* 动作(0放行 1拦截))  需先 WV_AddRequestFilter */
#define WVE_RESPONSE          23  /* (h, 网址, 状态码, 方法, 内容长度)  需先 WV_SetResponseCapture；内容用 WV_EvGetData(WVK_BODY) */
#define WVE_CDP_EVENT         24  /* (h, 事件名, 参数JSON)  需先 WV_CdpSubscribe */
#define WVE_ZOOM              25  /* (h, 缩放百分比) */
#define WVE_HISTORY           26  /* (h, 能后退, 能前进) */
#define WVE_CERT_ERROR        27  /* (h, 网址, 错误码, int* 动作(0默认 1继续访问 2取消))；继续访问的网页来源未经验证，同 WVP_IGNORE_CERT */
#define WVE_JS_CALL           28  /* (h, 函数名, 参数JSON, 调用ID)  JS 调用了未单独绑定的函数名时触发；设置它会启用 JS 桥 */
#define WVE_MAX               28
/* 注册事件时把事件号与 WVE_FLAG_NO_OUT 按位或（WV_SetEvent，或创建选项“ev事件号=回调地址”里的事件号）：回调应有的参数表不含最后一个 int* 参数
   （“参考”参数），参数全是只读的；需要回填结果时在回调里调用 WV_EvSetInt(WVK_CANCEL, 1/0) 或 WV_EvSetInt(WVK_RESULT, 值)。易语言类的事件都这样注册：
   漏写“参考”时参数个数仍然对，保护桩发现不了，赋值却不会生效；参数表不含这个参数，多写它时参数表检查就会指出。照旧写了最后的“参考”参数的回调
   （以前的写法）仍会在这个位置收到回填结果的地址，赋值照样生效，同时按参数表不对报告（开发期检查为 1 时弹出说明）。没有 int* 参数的事件不受影响 */
#define WVE_FLAG_NO_OUT    0x100

/* ---------------- 事件上下文键 WV_EvGet* / WV_EvSet*（只在回调执行期间有效） ---------------- */
#define WVK_URL                1
#define WVK_METHOD             2
#define WVK_HEADERS            3  /* 请求头 JSON */
#define WVK_POST_DATA          4  /* 请求体（按 UTF-8 解为文本） */
#define WVK_RESOURCE_TYPE      5
#define WVK_STATUS             6
#define WVK_REASON             7
#define WVK_RESP_HEADERS       8  /* 响应头 JSON */
#define WVK_BODY               9  /* 响应内容（WV_EvGetData 取数据） */
#define WVK_MIME              10
#define WVK_TOTAL_BYTES       11
#define WVK_CONTENT_DISPOSITION 12
#define WVK_CALL_ID           13
#define WVK_ORIGIN            14
#define WVK_DEFAULT_TEXT      15
#define WVK_FILES             17  /* 收到网页消息的回调里：这次 postMessage 附带的文件路径（每行一个），网页用 chrome.webview.postMessageWithAdditionalObjects 传来；没有附带文件时为空。需要内核支持（WebView2 运行时 113 及以上） */
#define WVK_CHALLENGE         16
#define WVK_SET_HEADER        30  /* "名: 值" 修改请求头 */
#define WVK_REMOVE_HEADER     31  /* 删除请求头 */
#define WVK_SET_URL           32  /* 改写请求网址 */
#define WVK_SET_PATH          33  /* 下载保存路径 */
#define WVK_SET_TEXT          34  /* prompt 返回的文本 */
#define WVK_SET_USERNAME      35
#define WVK_SET_PASSWORD      36
#define WVK_SET_RESULT        37  /* JS 调用的返回值（合法 JSON 原样返回，否则按文本返回） */
#define WVK_SET_RESULT_TEXT   41  /* JS 调用的返回值，始终按普通文本返回 */
#define WVK_SET_ERROR         38  /* JS 调用返回错误（JS 端 Promise 被拒绝） */
#define WVK_DEFER             39  /* 整数 1：稍后用 WV_BindReturn 返回 */
#define WVK_TARGET_VIEW       40  /* 整数：新窗口装入这个浏览器句柄（新窗口事件里用） */
#define WVK_RESULT            42  /* 整数：事件的回填结果，取值与该事件 int* 参数相同（如新窗口的处理方式、权限请求的状态）；回调返回后生效，与 WVK_CANCEL 同时设置时以它为准 */
#define WVK_CANCEL            43  /* 整数 1/0：1 取消（拦截、拒绝）事件的默认动作：将要跳转、下载开始、认证取消，拦截请求拦下，按键屏蔽，对话框按“取消”，
                                     新窗口不打开，权限请求拒绝，证书错误取消访问；0 不取消：对话框按“确定”，其它事件保持默认处理 */

/* ---------------- 命令 WV_Command ---------------- */
#define WVC_BACK               1
#define WVC_FORWARD            2
#define WVC_RELOAD             3
#define WVC_STOP               4
#define WVC_DEVTOOLS           5
#define WVC_TASK_MANAGER       6
#define WVC_PRINT_DIALOG       7  /* 浏览器打印预览 */
#define WVC_PRINT_SYSTEM       8  /* 系统打印对话框 */
#define WVC_DOWNLOAD_DIALOG    9
#define WVC_DOWNLOAD_DIALOG_CLOSE 10
#define WVC_SUSPEND           11
#define WVC_RESUME            12
#define WVC_HARD_RELOAD       13  /* 忽略缓存刷新 */
#define WVC_EXIT_FULLSCREEN   14
#define WVC_FOCUS             15
#define WVC_NOTIFY_MOVED      16  /* 1.8.1：宿主的祖先窗口移动了，通知内核更新下拉框、输入法候选框等弹出窗口的位置。顶层窗口属于别的线程或别的进程（DLL 子类化不了它）时由程序在它移动后调用；尚未就绪时不做事 */
#define WVC_MINIMIZED         17  /* 1.8.1：顶层窗口最小化了：隐藏内核以降低占用（DLL 子类化不了顶层窗口时由程序调用，重复调用不重复隐藏） */
#define WVC_RESTORED          18  /* 1.8.1：顶层窗口从最小化还原了：恢复显示（与 WVC_MINIMIZED 配对） */

/* ---------------- 网页元素操作 WV_Dom（选择器支持 CSS，以 / 或 (/ 开头按 XPath） ---------------- */
#define WVD_EXISTS             1
#define WVD_CLICK              2  /* 脚本点击；元素已禁用时不点，返回 false */
#define WVD_SET_VALUE          3  /* 兼容 React/Vue：用原生 setter 赋值并触发 input/change；元素不能赋值时返回 false */
#define WVD_GET_TEXT           4
#define WVD_GET_HTML           5
#define WVD_GET_VALUE          6
#define WVD_GET_ATTR           7  /* 值＝属性名 */
#define WVD_SET_ATTR           8  /* 值＝"名=值" */
#define WVD_FOCUS              9  /* 焦点没能落到元素上（隐藏、禁用或不能聚焦）时返回 false */
#define WVD_SCROLL            10
#define WVD_COUNT             11
#define WVD_REMOVE            12
#define WVD_SUBMIT            13  /* 与点提交按钮一样先做表单校验；不在表单里或校验不通过时不提交，返回 false */
#define WVD_CHECK             14  /* 值：空/1/true 勾选；0/false/假 取消；没能变成指定状态时返回 false */
#define WVD_SELECT            15  /* 值＝选项的 value 或显示文本；没有这个选项时返回 false */
#define WVD_GET_ALL_TEXT      16  /* 返回 JSON 数组 */
#define WVD_SET_HTML          17
#define WVD_RECT              18  /* 返回 JSON {x,y,w,h}（中心点，CSS 像素）；隐藏的元素宽高为 0 */
#define WVD_TRUSTED_CLICK     19  /* 用真实鼠标事件点击（isTrusted=true）；元素隐藏、大小为 0 或已禁用时不点，调用失败 */
#define WVD_TYPE_TEXT         20  /* 聚焦后用真实键盘输入文本；没能聚焦时不输入，调用失败 */

/* ---------------- 模拟输入 WV_Input（坐标为网页可视区 CSS 像素） ---------------- */
#define WVI_CLICK              1
#define WVI_DBLCLICK           2
#define WVI_RIGHT_CLICK        3
#define WVI_MOVE               4
#define WVI_TEXT               5  /* 文本参数 */
#define WVI_KEY                6  /* 文本参数，如 Enter、Tab、Ctrl+A、F5 */
#define WVI_WHEEL              7  /* x,y 为滚动量 */

/* ---------------- WV_ExecScript 标志 ---------------- */
#define WVX_UNWRAP             1  /* 结果是 JSON 字符串时去掉引号与转义，直接返回文本 */
#define WVX_AWAIT              2  /* 等待 Promise（支持顶层 await），用 DevTools 协议执行：表达式的值是 Promise 时等它完成，对象按值取回；Promise 被拒绝或脚本抛出异常时失败（WVERR_SCRIPT） */
#define WVX_POST               4  /* 只用于 WV_ExecScriptAsync：从别的线程调用时，把脚本投递到界面线程按顺序执行后立即返回，不同步等界面线程接手（默认会转交界面线程、最长等转交超时）。
                                      界面线程正忙于等这个工作线程时，避免互相等待；投递的脚本之间、与同样投递的脚本保持先后顺序。界面线程自己调用时与不加这个标志相同 */

/* ---------------- 错误码 WV_LastErrorCode ---------------- */
#define WVERR_OK               0
#define WVERR_BAD_HANDLE       1
#define WVERR_NOT_READY        2
#define WVERR_NO_RUNTIME       3
#define WVERR_RUNTIME_LOAD     4
#define WVERR_ENV_FAILED       5
#define WVERR_CTRL_FAILED      6
#define WVERR_TIMEOUT          7
#define WVERR_THREAD           8
#define WVERR_ARG              9
#define WVERR_UNSUPPORTED     10
#define WVERR_SCRIPT          11
#define WVERR_IO              12
#define WVERR_CLOSED          13
#define WVERR_DATA_CONFLICT   14
#define WVERR_INSTALL         15
#define WVERR_NO_CONTEXT      16
#define WVERR_NOT_FOUND       17
#define WVERR_FAILED          18
#define WVERR_REENTRANT       19  /* 在“将要跳转”“按键”事件回调里调用了需要等待结果的方法（WebView2 不支持），请改用异步方法，如 WV_ExecScriptAsync */
#define WVERR_DENIED          20  /* 当前网页的来源不在 JS 桥允许的范围内（见 WVS_BRIDGE_ORIGINS），没有发送 */
#define WVERR_ENCODING        21  /* 开发期检查打开时，文本代码页为 UTF-8 而收到的文本不是合法的 UTF-8（例如易语言源码里的中文没有用 WV文本 () 转换） */

/* ---------------- 导出函数 ---------------- */
/* 全局 */
WV_API int         WV_CALL WV_GetVersion(void);
WV_API const char* WV_CALL WV_GetVersionText(void);
WV_API int         WV_CALL WV_Init(const char* appDir);                /* 设置程序目录（相对路径换成完整路径）；在已有窗口的线程（界面线程）调用时同时登记界面线程，工作线程调用只设置程序目录 */
WV_API int         WV_CALL WV_SetOption(int key, const char* value);
WV_API const char* WV_CALL WV_GetOption(int key);
WV_API int         WV_CALL WV_RuntimeCheck(int rescan);               /* 1 有可用运行时 0 没有 */
WV_API const char* WV_CALL WV_RuntimeInfo(void);                      /* JSON；环境变量或组策略覆盖了运行时设置时有 override 一项（来源、运行时目录、数据目录、附加参数、通道偏好）；程序指定了运行时目录时有 runtimeDir；文件不完整、放在网络位置或本进程里已失效而没有采用的运行时列在 broken（dir、reason、inProcess） */
WV_API const char* WV_CALL WV_GetDiagnostics(void);                   /* JSON；checks 一项是开发期检查的统计：devChecks、encodingFallback（不是 UTF-8 而按 ANSI 解释的次数）、
                                                                      encodingSuspect（疑似没有转换的 GBK 文本）、threadTimeouts（跨线程转交超时）、callbackMismatch（参数表不符的回调：event、declaredBytes、expected）；
                                                                      jsonCache 是 WV_JsonGet 缓存的项数与原文字节数（entries、bytes；每个线程最多 4 项，线程结束后释放） */
#define WVI_AUTO                 1  /* WV_InstallRuntime 的 flags：程序自动发起的安装（不是用户点的）。上次安装失败（包括装完仍没有可用的运行时）后 24 小时内直接失败（WVERR_INSTALL，说明里写着上次失败的时间与原因），不再每次都等一遍下载 */
WV_API int         WV_CALL WV_InstallRuntime(int flags, int timeoutMs);/* 下载微软的常青版引导程序（校验微软签名）并静默安装，装好后等待运行时的浏览器自动恢复。Win7/8/8.1 改为下载微软更新目录里的
                                                                       109.0.1518.140 x86 离线安装包（约 132MB，必须与目录登记的大小、SHA-1 一致，签名照常校验）静默安装（微软当前的在线安装程序要用
                                                                       Windows 8 起才有的系统函数，在 Win7 上启动不了）；更早的系统直接失败（WVERR_INSTALL） */
/* 1.8.1：在后台发起安装（规则与 WV_InstallRuntime 相同，flags 可带 WVI_AUTO），立即返回：1 已发起或已有安装在进行，0 没能发起（原因见 WV_LastError）。
   不转交界面线程、不等待（WV_InstallRuntime 在界面线程已登记后，会把整个等待转交界面线程，在嵌套的消息循环里等到安装结束）；进度与结果用 WV_InstallState 查询 */
WV_API int         WV_CALL WV_InstallRuntimeAsync(int flags);
#define WVIS_NONE                0  /* WV_InstallState：本进程还没有发起过安装 */
#define WVIS_RUNNING             1  /* 正在下载、校验或安装（含等另一个程序启动的安装程序结束） */
#define WVIS_SUCCEEDED           2  /* 最近一次安装已结束且安装程序报告成功（或本来就有可用的常青版）；之后再用 WV_RuntimeCheck(1) 确认按当前设置有可用的运行时 */
#define WVIS_FAILED              3  /* 最近一次安装已结束但没有成功：原因见 WV_LastError */
WV_API int         WV_CALL WV_InstallState(void);                   /* 1.8.1：安装状态（WVIS_）；为 WVIS_FAILED 时 WV_LastError 给出原因、WV_LastErrorCode 为 WVERR_INSTALL；任何线程都可以调用 */
WV_API int         WV_CALL WV_LastErrorCode(void);
WV_API const char* WV_CALL WV_LastError(void);
/* 实例。宽或高 <=0 表示铺满父窗口并自动跟随大小：左、上边距取 x、y，右、下边距取 -w、-h */
/* WV_Create 返回非 0 不代表已就绪：创建超时，或失败但启用了提示卡片（WVO_FALLBACK_UI，默认启用）时也返回句柄，便于装好运行时后自动恢复，
   此时 WV_LastErrorCode 非 0，WV_IsReady 返回 0（仍在创建）或 -1（失败）；没有启用提示卡片时失败返回 0。是否就绪以 WV_IsReady 为准 */
/* options 是每行一项的“键=值”文本，逐行按代码页转换：某一行不是合法的 UTF-8 时只有这一行按系统 ANSI 代码页解释（开发期检查打开时调用失败） */
WV_API int  WV_CALL WV_Create(HWND parent, int x, int y, int w, int h, const char* url, const char* options, int timeoutMs);
WV_API int  WV_CALL WV_CreateAsync(HWND parent, int x, int y, int w, int h, const char* url, const char* options, void* onReady);
WV_API int  WV_CALL WV_Destroy(int view);                             /* 跨线程转交没有执行（WVERR_THREAD）时返回 0，浏览器仍在，可以稍后再调用 */
WV_API int  WV_CALL WV_IsReady(int view);                             /* 1 就绪 0 创建中 -1 失败或无效 */
WV_API int  WV_CALL WV_WaitReady(int view, int timeoutMs);
WV_API int  WV_CALL WV_GetWindow(int view, int which);                /* 0 宿主窗口 1 父窗口 */
WV_API int  WV_CALL WV_SetBounds(int view, int x, int y, int w, int h);
WV_API int  WV_CALL WV_Show(int view, int visible);
/* 在浏览器所在位置显示进度卡片，说明程序自己正在做的准备工作（例如自动安装运行时不成功、改从自己的服务器下载运行时），免得卡片停在失败的说明上、
   之后页面又不声不响地出来。status 是卡片下方的一行状态；permille 0～1000 显示进度条，小于 0 只显示动画；可以反复调用更新。
   title 为空（或 NULL）时收起，浏览器还没就绪时回到原来的提示卡片；浏览器开始重建、就绪时自动收起 */
WV_API int  WV_CALL WV_ShowProgress(int view, const char* title, const char* text, const char* status, int permille);
WV_API int  WV_CALL WV_SetParent(int view, HWND parent);  /* 新的父窗口必须属于界面线程，否则返回 0（WVERR_THREAD） */
/* 导航 */
WV_API int  WV_CALL WV_Navigate(int view, const char* url);           /* 自动补全 https://，支持本地文件路径 */
WV_API int  WV_CALL WV_NavigateToString(int view, const char* html);  /* 显示一段 HTML：内容按 UTF-8 放在内存里，以 https://wv2bridge.example/浏览器编号-序号.html 打开（有正常的 https 来源，localStorage 可用；
                                                                      不用 WebView2 的 NavigateToString，所以没有 2MB 限制，也不写临时文件）。每个浏览器保留最近 8 页（总共不超过 64MB，最新一页总保留），
                                                                      后退、刷新与崩溃后的自动恢复都能取回；该主机上的其它网址回 404，可用 WV_AddMemoryFile 在该主机下放页面引用的资源。
                                                                      页面应答不允许别的来源读取；所有页面共用这一个来源（共用 localStorage，保留着的页面之间可以互相读取），显示不可信的 HTML 时要考虑这一点 */
WV_API int  WV_CALL WV_NavigateEx(int view, const char* url, const char* method, const char* headers, const void* body, int bodyLen);
WV_API int  WV_CALL WV_Command(int view, int cmd);
/* 脚本 */
WV_API const char* WV_CALL WV_ExecScript(int view, const char* js, int flags, int timeoutMs);
WV_API int  WV_CALL WV_ExecScriptAsync(int view, const char* js, int flags, void* callback, int userData); /* 回调(h, 用户数据, 是否成功, 结果) */
WV_API const char* WV_CALL WV_AddInitScript(int view, const char* js);
WV_API int  WV_CALL WV_RemoveInitScript(int view, const char* id);
WV_API const char* WV_CALL WV_Dom(int view, int action, const char* selector, const char* value, int timeoutMs);  /* 元素操作（WVD_）：返回结果文本；动作没能完成时返回 "false"，元素不存在、等待超时或拒绝执行时返回空文本，原因都由 WV_LastError 给出。
                                                                                                                  WVD_EXISTS 例外：元素不存在时返回 "false"（不算出错），给了等待时间而等到超时仍没有时也返回 "false"，错误码为 WVERR_TIMEOUT */
WV_API int  WV_CALL WV_Input(int view, int kind, int x, int y, const char* text);
/* 消息与 JS 桥 */
WV_API int  WV_CALL WV_PostMessage(int view, const char* text, int asJson);
WV_API int  WV_CALL WV_Bind(int view, const char* name, void* callback);  /* 回调(h, 函数名, 参数JSON, 调用ID) */
WV_API int  WV_CALL WV_BindReturn(int view, int callId, const char* result, int isError);  /* 发起调用的网页已离开（打开了别的页面）时不送出，返回 0 */
WV_API int  WV_CALL WV_Emit(int view, const char* eventName, const char* json);  /* 只发给允许调用 JS 桥的网页（见 WVS_BRIDGE_ORIGINS），否则返回 0，错误码 WVERR_DENIED */
/* 事件 */
WV_API int  WV_CALL WV_SetEvent(int view, int eventId, void* callback);
WV_API const char* WV_CALL WV_EvGet(int key);
WV_API int  WV_CALL WV_EvGetInt(int key);
/* 回填结果的 WVK_SET_ 等键只在会读取它的事件的回调里有效（见各键说明；WVK_CANCEL / WVK_RESULT 用于有 int* 参数的事件），用在别的事件里返回 0（WVERR_ARG） */
WV_API int  WV_CALL WV_EvSet(int key, const char* value);
WV_API int  WV_CALL WV_EvSetInt(int key, int value);
WV_API int  WV_CALL WV_EvGetData(int key, void** data, int* length);
WV_API int  WV_CALL WV_EvSetResponse(int status, const char* reason, const char* headers, const void* body, int length);
/* 属性 */
WV_API int  WV_CALL WV_SetInt(int view, int prop, int value);
WV_API int  WV_CALL WV_GetInt(int view, int prop);
WV_API int  WV_CALL WV_SetStr(int view, int prop, const char* value);
WV_API const char* WV_CALL WV_GetStr(int view, int prop);
/* Cookie 与数据 */
WV_API const char* WV_CALL WV_GetCookies(int view, const char* url, int format); /* 0 JSON 1 "a=b; c=d" 2 Netscape cookies.txt */
WV_API int  WV_CALL WV_SetCookie(int view, const char* url, const char* name, const char* value, const char* domain, const char* path, int expires, int flags); /* expires：Unix 时间戳（秒），按无符号 32 位解释（可到 2106 年），0＝会话 Cookie，内核会把超过 400 天的过期时间压到 400 天；flags：1 HttpOnly 2 Secure 0x100 Lax 0x200 Strict 0x400 None（SameSite=None 须同时带 Secure） */
WV_API int  WV_CALL WV_SetCookieString(int view, const char* url, const char* cookies);  /* “名=值; 名=值”（也可以每行一个），path、domain 等属性项跳过 */
WV_API int  WV_CALL WV_DeleteCookies(int view, const char* url, const char* name);
WV_API int  WV_CALL WV_ClearData(int view, int kinds);                /* 0＝全部；其它见 COREWEBVIEW2_BROWSING_DATA_KINDS */
/* 截图与打印 */
WV_API int  WV_CALL WV_Capture(int view, const char* filePath, int format, int fullPage); /* format 0 PNG 1 JPG */
WV_API int  WV_CALL WV_CaptureToMemory(int view, int format, int fullPage, void** data, int* length); /* 用 WV_Free 释放 */
WV_API int  WV_CALL WV_PrintToPdf(int view, const char* filePath, int landscape, int timeoutMs);
/* DevTools 协议 */
WV_API const char* WV_CALL WV_CdpCall(int view, const char* method, const char* paramsJson, int timeoutMs);
WV_API int  WV_CALL WV_CdpSubscribe(int view, const char* eventName, int enable);
/* 网络 */
WV_API int  WV_CALL WV_AddRequestFilter(int view, const char* urlPattern, int resourceType);
WV_API int  WV_CALL WV_RemoveRequestFilter(int view, const char* urlPattern, int resourceType);
WV_API int  WV_CALL WV_SetResponseCapture(int view, const char* urlPatterns, int withBody);  /* 网址通配符，分号分隔（也可以用空格或换行，每行一项） */
WV_API int  WV_CALL WV_MapFolder(int view, const char* hostName, const char* folder, int accessKind);  /* 主机名建议用 .example 结尾（如 app.example）：微软文档提醒用 .local 会拖慢导航 */
WV_API int  WV_CALL WV_AddMemoryFile(int view, const char* url, const void* data, int length, const char* mimeType);  /* 让该网址（不计查询串）直接返回这段数据；data 为 NULL 或 length<0 删除该网址；url 为空清空本浏览器的全部内存文件（WV_NavigateToString 的页面不受影响） */
WV_API int  WV_CALL WV_DownloadControl(int view, int downloadId, int action);  /* 1取消 2暂停 3继续 */
/* 其它 */
WV_API int  WV_CALL WV_Free(void* p);
WV_API const char* WV_CALL WV_JsonGet(const char* json, const char* path); /* 取 JSON 值，路径如 [0]、a.b[2].c；数组后面跟 length 得到成员数（a.length，与 JavaScript 相同；对象仍按键名取 length，字符串没有 length）；
                                                                        下标只认非负整数，两边可以有空格（[x]、[1.5]、[-1] 按路径不存在处理）；
                                                                        字符串返回内容，其它返回 JSON。同一线程传入最近用过的 JSON 时只按字节比较原文、复用记下的解析结果（每个线程记最近 4 段，所有线程合计 4 MB 以内，
                                                                        线程结束后释放，强制结束的线程也一样；先取出成员再取它的字段时两段交替传入也能复用），
                                                                        逐个取数组成员时每次的开销从整段解析降为一次字节比较（Wine 实测快约 60 倍） */
WV_API const char* WV_CALL WV_JsonQuote(const char* text); /* 把文本转成带引号的 JSON 字符串（按字符转义，多字节字符不会被破坏），用于拼接回传值 */
WV_API const char* WV_CALL WV_TextFromAnsi(const char* ansiText); /* 源码里的文字常量：入参固定按系统 ANSI 代码页解释（不受 WVO_CODEPAGE 影响），其中的 \uXXXX 换成对应字符
                                                                  （连写的高低代理项合成一个字符），按当前代码页返回；用来写 GBK 表示不了的韩文、表情等 */

#endif /* WV2BRIDGE_H */
