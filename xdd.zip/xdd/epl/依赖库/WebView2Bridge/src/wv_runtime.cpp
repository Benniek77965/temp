// wv_runtime.cpp : 系统版本识别、WebView2 运行时查找与选择、自建加载器、环境选项、运行时安装
#include "wv_internal.h"
#include <urlmon.h>
#include "wv_sign.h"
#include <wintrust.h>
#include <softpub.h>
#include <aclapi.h>
#include <sddl.h>
#include <tlhelp32.h>

namespace wv {

// ---------------------------------------------------------------- 系统版本（DllMain 中调用，只用 ntdll，不触发 LoadLibrary）
static OsInfo g_os;
const OsInfo& Os() { return g_os; }

void InitOs() {
  typedef LONG(WINAPI * RtlGetVersionFn)(PRTL_OSVERSIONINFOW);
  RTL_OSVERSIONINFOEXW vi;
  ZeroMemory(&vi, sizeof(vi));
  vi.dwOSVersionInfoSize = sizeof(vi);
  HMODULE nt = GetModuleHandleW(L"ntdll.dll");
  RtlGetVersionFn fn = nt ? reinterpret_cast<RtlGetVersionFn>(reinterpret_cast<void*>(GetProcAddress(nt, "RtlGetVersion"))) : nullptr;
  if (fn && fn(reinterpret_cast<PRTL_OSVERSIONINFOW>(&vi)) == 0) {
    g_os.major = vi.dwMajorVersion;
    g_os.minor = vi.dwMinorVersion;
    g_os.build = vi.dwBuildNumber;
    g_os.sp = vi.wServicePackMajor;
  }
  g_os.legacy = g_os.major != 0 && g_os.major < 10;
  if (g_os.major == 6 && g_os.minor == 1) g_os.name = L"Windows 7";
  else if (g_os.major == 6 && g_os.minor == 2) g_os.name = L"Windows 8";
  else if (g_os.major == 6 && g_os.minor == 3) g_os.name = L"Windows 8.1";
  else if (g_os.major == 10 && g_os.build >= 22000) g_os.name = L"Windows 11";
  else if (g_os.major == 10) g_os.name = L"Windows 10";
  else g_os.name = Fmt(L"Windows NT %u.%u", g_os.major, g_os.minor);
  if (g_os.sp) g_os.name += Fmt(L" SP%u", g_os.sp);
  g_os.name += Fmt(L"（%u.%u.%u）", g_os.major, g_os.minor, g_os.build);
}

// ---------------------------------------------------------------- 运行时查找
static const wchar_t* kChannelGuid[] = {
    L"{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}",  // WebView2 运行时（稳定版）
    L"{2CD8A007-E189-409D-A2C8-9AF4EF3C72AA}",  // Edge Beta
    L"{0D50BFEC-CD6A-4F9A-964C-C7416E3ACB10}",  // Edge Dev
    L"{65C35B14-6C1D-4122-AC46-7148CC9D6497}",  // Edge Canary
};
static const wchar_t* kChannelName[] = {L"稳定版", L"Beta", L"Dev", L"Canary"};

static std::wstring RegString(HKEY root, const std::wstring& sub, const wchar_t* name) {
  HKEY k = nullptr;
  if (RegOpenKeyExW(root, sub.c_str(), 0, KEY_READ | KEY_WOW64_32KEY, &k) != ERROR_SUCCESS) return std::wstring();
  wchar_t buf[2048];
  DWORD type = 0, size = sizeof(buf) - sizeof(wchar_t);
  std::wstring r;
  if (RegQueryValueExW(k, name, nullptr, &type, reinterpret_cast<LPBYTE>(buf), &size) == ERROR_SUCCESS &&
      (type == REG_SZ || type == REG_EXPAND_SZ)) {
    buf[size / sizeof(wchar_t)] = 0;
    r = buf;
    if (type == REG_EXPAND_SZ) {  // 带环境变量的路径（如 %ProgramFiles(x86)%\...）要展开后才能使用
      wchar_t ex[2048];
      DWORD n = ExpandEnvironmentStringsW(buf, ex, 2048);
      if (n > 0 && n <= 2048) r = ex;
    }
  }
  RegCloseKey(k);
  return Trim(r);
}

// 从目录名里取版本号：Microsoft.WebView2.FixedVersionRuntime.109.0.1518.140.x86 → 109.0.1518.140
// 运行时文件缺少版本资源（被精简或损坏）时用它兜底，否则主版本会被当成 0，按版本挑选和 Win7 的 109 限制都会失效
static std::wstring VersionFromName(const std::wstring& name) {
  for (size_t i = 0; i < name.size(); ++i) {
    if (!iswdigit(name[i]) || (i > 0 && iswdigit(name[i - 1]))) continue;
    size_t j = i;
    int parts = 0;
    for (;;) {
      size_t k = j;
      while (k < name.size() && iswdigit(name[k])) ++k;
      if (k == j) break;
      ++parts;
      j = k;
      if (parts == 4 || j + 1 >= name.size() || name[j] != L'.' || !iswdigit(name[j + 1])) break;
      ++j;
    }
    if (parts == 4) return name.substr(i, j - i);
  }
  return std::wstring();
}

// ---------------------------------------------------------------- 运行时文件自检
// 运行时客户端（EBWebView\x86\EmbeddedBrowserWebView.dll）第一次创建环境时在宿主进程里映射 icudtl.dat 初始化 ICU（失败也不报错），创建控件时再启动 msedgewebview2.exe
// （它静态依赖 msedge_elf.dll，再载入 msedge.dll）。用微软的 109.0.1518.78 x86 固定版实测（Wine）：缺少 msedgewebview2.exe 或 icudtl.dat、
// icudtl.dat 为空或被别的程序独占打开、地址空间放不下 icudtl.dat 时，环境照常创建成功，创建控件在 20 毫秒内以 0x80070002 失败，而且客户端
// 会记住这次失败：把文件放回、换数据目录新建环境，本进程里同一个运行时都还是立即失败；缺少 msedge.dll、msedge_elf.dll 时一直停在创建中。
// 所以查找运行时、创建环境之前都先查这些文件，有问题就不交给运行时客户端
static DWORD ReadHead(const std::wstring& path, DWORD share, unsigned char* buf, DWORD want, DWORD& got, unsigned long long& size) {
  got = 0;
  size = 0;
  HANDLE f = CreateFileW(path.c_str(), GENERIC_READ, share, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (f == INVALID_HANDLE_VALUE) return GetLastError();
  LARGE_INTEGER li = {};
  if (GetFileSizeEx(f, &li)) size = (unsigned long long)li.QuadPart;
  DWORD e = 0;
  if (want && !ReadFile(f, buf, want, &got, nullptr)) e = GetLastError();
  CloseHandle(f);
  return e;
}
static bool BusyError(DWORD e) { return e == ERROR_SHARING_VIOLATION || e == ERROR_LOCK_VIOLATION; }
static bool MissingError(DWORD e) { return e == ERROR_FILE_NOT_FOUND || e == ERROR_PATH_NOT_FOUND; }

RuntimeFileCheck CheckRuntimeFiles(const std::wstring& dir) {
  RuntimeFileCheck r;
  auto bad = [&r](const std::wstring& why) {
    if (r.ok) r.reason = why;  // 只报第一个问题
    r.ok = false;
  };
  auto busy = [&r](const std::wstring& why) {
    if (r.ok && !r.busy) r.reason = why;
    r.busy = true;
  };
  {  // 浏览器进程：要能打开、开头是 MZ。共享读写删除打开，不妨碍别的程序，正在运行的 msedgewebview2.exe 也能打开（文件小，读版本号时本来就要打开它）
    const std::wstring p = PathJoin(dir, L"msedgewebview2.exe");
    unsigned char b[2] = {0, 0};
    DWORD got = 0;
    unsigned long long size = 0;
    const DWORD e = DirExists(p) ? ERROR_FILE_NOT_FOUND : ReadHead(p, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, b, 2, got, size);
    if (MissingError(e)) bad(L"缺少 msedgewebview2.exe");
    else if (BusyError(e)) busy(L"msedgewebview2.exe 正被其他程序独占打开");
    else if (e) bad(L"msedgewebview2.exe 无法读取：" + HrText(HRESULT_FROM_WIN32(e)));
    else if (size == 0) bad(L"msedgewebview2.exe 是空文件");
    else if (got < 2 || b[0] != 'M' || b[1] != 'Z') bad(L"msedgewebview2.exe 已损坏（不是有效的程序文件）");
  }
  // 浏览器进程启动时载入的两个 DLL：只看文件属性（存在、不是目录、不是空文件），不打开——msedge.dll 约 200MB，打开它可能让杀毒软件
  // 在界面线程上先把它扫描一遍（浏览器进程启动时它们本来就会被载入、扫描）
  for (const wchar_t* name : {L"msedge_elf.dll", L"msedge.dll"}) {
    WIN32_FILE_ATTRIBUTE_DATA fa;
    if (!GetFileAttributesExW(PathJoin(dir, name).c_str(), GetFileExInfoStandard, &fa)) {
      const DWORD e = GetLastError();
      bad(MissingError(e) ? Fmt(L"缺少 %ls", name) : Fmt(L"%ls 无法读取：", name) + HrText(HRESULT_FROM_WIN32(e)));
    } else if (fa.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
      bad(Fmt(L"%ls 不是文件", name));
    } else if (fa.nFileSizeHigh == 0 && fa.nFileSizeLow == 0) {
      bad(Fmt(L"%ls 是空文件", name));
    }
  }
  // ICU 数据文件：只共享读打开（不比运行时客户端打开它的条件宽），别的程序正在写它（如解压覆盖）时也算被占用
  const std::wstring icu = PathJoin(dir, L"icudtl.dat");
  unsigned char h[4] = {0, 0, 0, 0};
  DWORD got = 0;
  unsigned long long size = 0;
  const DWORD e = DirExists(icu) ? ERROR_FILE_NOT_FOUND : ReadHead(icu, FILE_SHARE_READ, h, 4, got, size);
  if (MissingError(e)) bad(L"缺少 icudtl.dat");
  else if (BusyError(e)) busy(L"icudtl.dat 正被其他程序占用（可能是杀毒软件正在扫描，或另一个程序正在解压覆盖运行时）");
  else if (e) bad(L"icudtl.dat 无法读取：" + HrText(HRESULT_FROM_WIN32(e)));
  else if (size == 0) bad(L"icudtl.dat 是空文件");
  else if (got < 4 || h[2] != 0xDA || h[3] != 0x27) bad(L"icudtl.dat 已损坏（不是 ICU 数据文件）");
  r.icuSize = size;
  return r;
}

// 32 位程序运行久了、占用内存多时，地址空间里可能已经没有能放下 icudtl.dat（109 版约 12MB）的连续空闲区域：这时运行时客户端映射不了它，
// 同样以 0x80070002 失败并记住失败（实测：只剩小于 8MB 的空洞时失败，小于 16MB 时可以）
unsigned long long LargestFreeRegion() {
  SYSTEM_INFO si;
  GetSystemInfo(&si);
  const ULONG_PTR gran = si.dwAllocationGranularity ? si.dwAllocationGranularity : 65536;
  unsigned long long best = 0;
  unsigned char* p = static_cast<unsigned char*>(si.lpMinimumApplicationAddress);
  unsigned char* const end = static_cast<unsigned char*>(si.lpMaximumApplicationAddress);
  const ULONG_PTR limit = (ULONG_PTR)end + 1;  // 用户地址空间的上限：最后一块空闲区可能被报告得越过上限（Wine 实测报出越过 2GB 的 1.7GB），超出部分分配不了
  while (p < end) {
    MEMORY_BASIC_INFORMATION mbi;
    if (!VirtualQuery(p, &mbi, sizeof(mbi))) break;
    unsigned char* const next = static_cast<unsigned char*>(mbi.BaseAddress) + mbi.RegionSize;
    if (mbi.State == MEM_FREE) {
      const ULONG_PTR b = ((ULONG_PTR)mbi.BaseAddress + gran - 1) / gran * gran, e = (ULONG_PTR)next < limit ? (ULONG_PTR)next : limit;
      if (e > b && e - b > best) best = e - b;
    }
    if (next <= p) break;
    p = next;
  }
  return best;
}

static Lock& ClientLock() {
  static Lock l;
  return l;
}
static std::map<std::wstring, std::wstring>& BadClients() {
  static std::map<std::wstring, std::wstring> m;
  return m;
}
static std::map<std::wstring, int>& ReadyClients() {  // 1 本进程里创建过环境 2 成功启动过
  static std::map<std::wstring, int> m;
  return m;
}
bool ClientBroken(const std::wstring& clientDll, std::wstring* reason) {
  Guard g(ClientLock());
  auto it = BadClients().find(Lower(clientDll));
  if (it == BadClients().end()) return false;
  if (reason) *reason = it->second;
  return true;
}
void MarkClientBroken(const std::wstring& clientDll, const std::wstring& reason) {
  {
    Guard g(ClientLock());
    BadClients()[Lower(clientDll)] = reason;
  }
  Log(L"运行时客户端 %ls 在本进程里已失效：%ls", clientDll.c_str(), reason.c_str());
}
void MarkClientReady(const std::wstring& clientDll) {
  Guard g(ClientLock());
  ReadyClients()[Lower(clientDll)] = 2;
}
bool ClientEverReady(const std::wstring& clientDll) {
  Guard g(ClientLock());
  auto it = ReadyClients().find(Lower(clientDll));
  return it != ReadyClients().end() && it->second >= 2;
}
void MarkClientEnvTried(const std::wstring& clientDll) {
  Guard g(ClientLock());
  int& v = ReadyClients()[Lower(clientDll)];
  if (v < 1) v = 1;
}
bool ClientEnvTried(const std::wstring& clientDll) {
  Guard g(ClientLock());
  return ReadyClients().count(Lower(clientDll)) != 0;
}

std::wstring ProcessText() {
  if (sizeof(void*) == 8) return L"64 位程序";
  typedef BOOL(WINAPI * IsWow64ProcessFn)(HANDLE, PBOOL);
  HMODULE k = GetModuleHandleW(L"kernel32.dll");
  IsWow64ProcessFn fn = k ? reinterpret_cast<IsWow64ProcessFn>(reinterpret_cast<void*>(GetProcAddress(k, "IsWow64Process"))) : nullptr;
  BOOL wow = FALSE;
  if (fn) fn(GetCurrentProcess(), &wow);
  return wow ? L"32 位程序（64 位系统）" : L"32 位程序（32 位系统）";
}

// 固定版运行时在网络位置（共享文件夹、网络驱动器）：微软说明固定版目前不能从网络位置或 UNC 路径运行（“固定版运行时分发”的已知问题）
bool NetworkRuntimePath(const std::wstring& d) {
  if (d.size() >= 2 && (d[0] == L'\\' || d[0] == L'/') && (d[1] == L'\\' || d[1] == L'/')) {
    if (d.size() >= 4 && (d[2] == L'?' || d[2] == L'.') && (d[3] == L'\\' || d[3] == L'/'))  // \\?\ 与 \\.\ 开头：后面是 UNC\ 才是网络路径
      return d.size() >= 8 && _wcsnicmp(d.c_str() + 4, L"UNC", 3) == 0 && (d[7] == L'\\' || d[7] == L'/');
    return true;
  }
  if (d.size() >= 2 && iswalpha(d[0]) && d[1] == L':') {
    const wchar_t root[4] = {d[0], L':', L'\\', 0};
    return GetDriveTypeW(root) == DRIVE_REMOTE;
  }
  return false;
}

// Windows 10 上 120 及以上的固定版运行时：渲染进程在 AppContainer 里运行，运行时文件夹要给“所有应用程序包”（S-1-15-2-1）与
// “所有受限应用程序包”（S-1-15-2-2）读取和执行权限，否则 WebView2 一启动就崩溃（微软文档“固定版运行时分发”第 6 步；Windows 11、
// 常青版与 119 及以下不受影响）。缺少时自动加上，与文档里的 icacls 命令相同（(OI)(CI)(RX)，子文件夹与文件继承）；加不上时返回原因。
// 读不到权限表时无法判断，不拦；没有权限表（FAT32、exFAT）时谁都能读，不用加。每次新建环境前都查（读权限表很快）：运行时文件夹
// 可能在本进程里被删掉重新解压（例如程序修复运行时），新的文件夹没有这两项权限，记住“查过了”会漏掉
static DWORD(WINAPI* g_setNamedSecurity)(LPWSTR, SE_OBJECT_TYPE, SECURITY_INFORMATION, PSID, PSID, PACL, PACL) = SetNamedSecurityInfoW;  // 测试可换成失败的版本
// 常青版与 Edge 各频道装好的文件夹（…\Microsoft\EdgeWebView\Application\…、…\Microsoft\Edge*\Application\…）：权限由微软的安装程序设好
// （微软说明这一要求不影响常青版）。程序把运行时目录指到这些位置时（如按固定版使用常青版的文件夹）不去改它们的权限，通常也没有权限改
bool InstalledRuntimeFolder(const std::wstring& dir) {
  std::wstring d = Lower(dir);
  for (auto& ch : d)
    if (ch == L'/') ch = L'\\';  // 程序指定的目录可能写成正斜杠
  for (const wchar_t* p : {L"\\microsoft\\edgewebview\\application\\", L"\\microsoft\\edge\\application\\", L"\\microsoft\\edge beta\\application\\",
                           L"\\microsoft\\edge dev\\application\\", L"\\microsoft\\edge sxs\\application\\"})
    if (d.find(p) != std::wstring::npos) return true;
  return false;
}
bool EnsureFixedRuntimeAcl(const RuntimeCandidate& rt, std::wstring& why) {
  if (rt.kind != 1 || rt.major < 120 || Os().major != 10 || Os().build >= 22000 || InstalledRuntimeFolder(rt.dir)) return true;
  PSID sids[2] = {nullptr, nullptr};
  if (!ConvertStringSidToSidW(L"S-1-15-2-1", &sids[0]) || !ConvertStringSidToSidW(L"S-1-15-2-2", &sids[1])) {
    if (sids[0]) LocalFree(sids[0]);
    return true;
  }
  PACL dacl = nullptr;
  PSECURITY_DESCRIPTOR sd = nullptr;
  DWORD e = GetNamedSecurityInfoW(rt.dir.c_str(), SE_FILE_OBJECT, DACL_SECURITY_INFORMATION, nullptr, nullptr, &dacl, nullptr, &sd);
  bool ok = true;
  if (e == ERROR_SUCCESS && dacl) {
    const DWORD rx = FILE_GENERIC_READ | FILE_GENERIC_EXECUTE;
    bool has[2] = {false, false};
    for (DWORD i = 0; i < dacl->AceCount; ++i) {
      void* a = nullptr;
      if (!GetAce(dacl, i, &a)) continue;
      const ACE_HEADER* h = static_cast<const ACE_HEADER*>(a);
      if (h->AceType != ACCESS_ALLOWED_ACE_TYPE) continue;
      const ACCESS_ALLOWED_ACE* x = static_cast<const ACCESS_ALLOWED_ACE*>(a);
      const bool rights = (x->Mask & rx) == rx || (x->Mask & GENERIC_ALL) || (x->Mask & (GENERIC_READ | GENERIC_EXECUTE)) == (GENERIC_READ | GENERIC_EXECUTE);
      const bool inherit = (h->AceFlags & (OBJECT_INHERIT_ACE | CONTAINER_INHERIT_ACE)) == (OBJECT_INHERIT_ACE | CONTAINER_INHERIT_ACE);
      for (int k = 0; k < 2; ++k)
        if (rights && inherit && EqualSid(const_cast<DWORD*>(&x->SidStart), sids[k])) has[k] = true;
    }
    if (!has[0] || !has[1]) {
      EXPLICIT_ACCESSW ea[2];
      ZeroMemory(ea, sizeof(ea));
      for (int k = 0; k < 2; ++k) {
        ea[k].grfAccessPermissions = rx;
        ea[k].grfAccessMode = GRANT_ACCESS;
        ea[k].grfInheritance = SUB_CONTAINERS_AND_OBJECTS_INHERIT;
        ea[k].Trustee.TrusteeForm = TRUSTEE_IS_SID;
        ea[k].Trustee.TrusteeType = TRUSTEE_IS_WELL_KNOWN_GROUP;
        ea[k].Trustee.ptstrName = static_cast<LPWSTR>(sids[k]);
      }
      PACL nd = nullptr;
      e = SetEntriesInAclW(2, ea, dacl, &nd);
      if (e == ERROR_SUCCESS)  // 写到运行时目录上，并按继承规则带到里面已有的文件与子文件夹
        e = g_setNamedSecurity(const_cast<LPWSTR>(rt.dir.c_str()), SE_FILE_OBJECT, DACL_SECURITY_INFORMATION, nullptr, nullptr, nd, nullptr);
      if (nd) LocalFree(nd);
      if (e == ERROR_SUCCESS) {
        Log(L"已给固定版运行时 %ls 加上“所有应用程序包”的读取与执行权限（Windows 10 上 120 及以上版本需要）", rt.dir.c_str());
      } else {
        ok = false;
        why = L"Windows 10 上 120 及以上版本的固定版运行时要给“所有应用程序包”读取和执行权限（微软的要求，否则网页组件一启动就崩溃），自动设置没有成功（" +
              HrText(HRESULT_FROM_WIN32(e)) + L"）。请以管理员身份运行 icacls \"" + rt.dir + L"\" /grant *S-1-15-2-2:(OI)(CI)(RX) 与 icacls \"" + rt.dir +
              L"\" /grant *S-1-15-2-1:(OI)(CI)(RX)，然后点“重试”";
      }
    }
  }
  if (sd) LocalFree(sd);
  LocalFree(sids[0]);
  LocalFree(sids[1]);
  return ok;
}

static bool MakeCandidate(const std::wstring& dir, int kind, const std::wstring& source, RuntimeCandidate& c,
                          std::vector<BrokenRuntime>* broken = nullptr) {
  std::wstring d = TrimSlash(dir);
  std::wstring dll = PathJoin(d, L"EBWebView\\x86\\EmbeddedBrowserWebView.dll");
  if (!FileExists(dll)) return false;
  if (kind == 1 && NetworkRuntimePath(d)) {  // 微软说明固定版目前不能从网络位置运行：不采用，说明原因
    if (broken) broken->push_back({d, L"固定版运行时放在网络位置（共享文件夹或网络驱动器），微软说明固定版目前不能从网络位置运行，请放到本机磁盘上", false, kind, true});
    return false;
  }
  // 在本进程里启动失败过的运行时客户端会记住失败，文件不全的运行时启动不了：都不采用，记下原因（找不到别的运行时时说明，也写进诊断信息）
  std::wstring why;
  if (ClientBroken(dll, &why)) {
    if (broken) broken->push_back({d, why, true, kind});
    return false;
  }
#ifdef WV_TEST_NO_PRECHECK  // 只供测试：不查文件，让运行时客户端自己失败，验证失败后的处理
  RuntimeFileCheck fc;
#else
  const RuntimeFileCheck fc = CheckRuntimeFiles(d);
#endif
  if (!fc.ok) {  // 只是暂时被占用（busy）的照常采用：创建环境之前还会再查，到时仍被占用就稍后重试
    if (broken) broken->push_back({d, fc.reason, false, kind});
    return false;
  }
  c.kind = kind;
  c.dir = d;
  c.clientDll = dll;
  c.source = source;
  c.version = FileVersion(PathJoin(d, L"msedgewebview2.exe"));
  if (c.version.empty()) c.version = FileVersion(dll);
  if (c.version.empty()) c.version = VersionFromName(PathName(d));
  if (c.version.empty()) c.version = PathName(d);
  c.major = VersionMajor(c.version);
  return true;
}

static void AddInstalled(std::vector<RuntimeCandidate>& out, std::vector<BrokenRuntime>* broken = nullptr) {
  for (int ch = 0; ch < 4; ++ch) {
    for (int r = 0; r < 2; ++r) {
      HKEY root = r == 0 ? HKEY_LOCAL_MACHINE : HKEY_CURRENT_USER;
      const wchar_t* rootName = r == 0 ? L"HKLM" : L"HKCU";
      RuntimeCandidate c;
      c.channel = ch;
      std::wstring p = RegString(root, std::wstring(L"SOFTWARE\\Microsoft\\EdgeUpdate\\ClientState\\") + kChannelGuid[ch], L"EBWebView");
      if (!p.empty() && MakeCandidate(p, 0, Fmt(L"已安装（%ls，%ls ClientState）", kChannelName[ch], rootName), c, broken)) {
        out.push_back(c);
        continue;
      }
      if (ch != 0) continue;
      // 官方文档的检测方式：Clients\{GUID} 的 pv 值 + 默认安装位置
      std::wstring pv = RegString(root, std::wstring(L"SOFTWARE\\Microsoft\\EdgeUpdate\\Clients\\") + kChannelGuid[ch], L"pv");
      if (pv.empty() || pv == L"0.0.0.0") continue;
      wchar_t base[MAX_PATH] = {0};
      if (r == 0) {
        if (!GetEnvironmentVariableW(L"ProgramFiles(x86)", base, MAX_PATH)) GetEnvironmentVariableW(L"ProgramFiles", base, MAX_PATH);
      } else {
        GetEnvironmentVariableW(L"LOCALAPPDATA", base, MAX_PATH);
      }
      std::wstring dir = PathJoin(PathJoin(base, L"Microsoft\\EdgeWebView\\Application"), pv);
      if (MakeCandidate(dir, 0, Fmt(L"已安装（稳定版，%ls pv）", rootName), c, broken)) out.push_back(c);
    }
  }
}

static bool Interesting(const std::wstring& name) {
  std::wstring n = Lower(name);
  if (n.find(L"webview") != std::wstring::npos || n.find(L"runtime") != std::wstring::npos || n.find(L"edge") != std::wstring::npos ||
      n.find(L"ebwebview") != std::wstring::npos || n.find(L"内核") != std::wstring::npos || n.find(L"运行时") != std::wstring::npos)
    return true;
  return !n.empty() && iswdigit(n[0]) && n.find(L'.') != std::wstring::npos;  // 109.0.1518.140 这类版本目录
}

static void ScanFixed(const std::wstring& base, int depth, bool all, std::vector<RuntimeCandidate>& out, int& budget,
                      std::vector<std::wstring>* wrongArch = nullptr, std::vector<BrokenRuntime>* broken = nullptr) {
  if (base.empty() || budget <= 0) return;
  RuntimeCandidate c;
  if (MakeCandidate(base, 1, L"固定版：" + base, c, broken)) {
    for (const auto& x : out)
      if (_wcsicmp(x.dir.c_str(), c.dir.c_str()) == 0) return;
    out.push_back(c);
    return;
  }
  // 64 位或 ARM64 的固定版运行时：32 位程序用不了，记下来以便给出准确的提示
  if (wrongArch && (FileExists(PathJoin(base, L"EBWebView\\x64\\EmbeddedBrowserWebView.dll")) ||
                    FileExists(PathJoin(base, L"EBWebView\\arm64\\EmbeddedBrowserWebView.dll")))) {
    wrongArch->push_back(TrimSlash(base));
    return;
  }
  if (depth <= 0) return;
  WIN32_FIND_DATAW fd;
  HANDLE h = FindFirstFileW(PathJoin(base, L"*").c_str(), &fd);
  if (h == INVALID_HANDLE_VALUE) return;
  do {
    if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
    if (!wcscmp(fd.cFileName, L".") || !wcscmp(fd.cFileName, L"..")) continue;
    if (!all && !Interesting(fd.cFileName)) continue;
    if (--budget <= 0) break;
    ScanFixed(PathJoin(base, fd.cFileName), depth - 1, true, out, budget, wrongArch, broken);
  } while (FindNextFileW(h, &fd));
  FindClose(h);
}

static bool Better(const RuntimeCandidate& a, const RuntimeCandidate& b) { return CompareVersion(a.version, b.version) > 0; }

static Lock& RtLock() {
  static Lock l;
  return l;
}
static RuntimeInfo g_rt;
static bool g_rtValid = false;
static std::wstring g_rtKey;

// ---------------------------------------------------------------- 官方加载器的覆盖规则：环境变量与组策略
// 与 WebView2Loader 相同（CreateCoreWebView2EnvironmentWithOptions 的说明）：先看 WEBVIEW2_BROWSER_EXECUTABLE_FOLDER、WEBVIEW2_USER_DATA_FOLDER、
// WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS、WEBVIEW2_RELEASE_CHANNEL_PREFERENCE 四个环境变量；一个都没有时再看组策略
// [HKLM，再 HKCU]\Software\Policies\Microsoft\Edge\WebView2\{BrowserExecutableFolder, UserDataFolder, AdditionalBrowserArguments, ReleaseChannelPreference}，
// 值名依次试本进程的 AppUserModelID、程序文件名、*。运行时目录与数据目录覆盖程序自己的设置，附加参数追加在后面，通道偏好为 1 时常青版按
// Canary、Dev、Beta、稳定版的顺序找。原来只认 WEBVIEW2_BROWSER_EXECUTABLE_FOLDER（而且程序设置了运行时目录时不认）与附加参数环境变量，
// 管理员用组策略指定的运行时目录、数据目录与通道对本模块都不起作用
static std::wstring EnvValue(const wchar_t* name, bool& present) {
  const DWORD need = GetEnvironmentVariableW(name, nullptr, 0);
  if (need <= 1) return std::wstring();
  std::wstring v((size_t)need, L'\0');
  const DWORD got = GetEnvironmentVariableW(name, &v[0], need);
  v.resize(got < need ? got : 0);
  if (!v.empty()) present = true;
  return v;
}
static bool PolicyValue(const wchar_t* key, const std::vector<std::wstring>& ids, std::wstring& out, std::wstring& where) {
  const std::wstring sub = std::wstring(L"Software\\Policies\\Microsoft\\Edge\\WebView2\\") + key;
  for (int r = 0; r < 2; ++r) {
    HKEY k = nullptr;
    if (RegOpenKeyExW(r == 0 ? HKEY_LOCAL_MACHINE : HKEY_CURRENT_USER, sub.c_str(), 0, KEY_READ | KEY_WOW64_64KEY, &k) != ERROR_SUCCESS) continue;
    for (const auto& id : ids) {
      if (id.empty()) continue;
      DWORD type = 0, size = 0;
      if (RegQueryValueExW(k, id.c_str(), nullptr, &type, nullptr, &size) != ERROR_SUCCESS) continue;
      bool ok = false;
      if (type == REG_DWORD && size == sizeof(DWORD)) {
        DWORD d = 0;
        ok = RegQueryValueExW(k, id.c_str(), nullptr, nullptr, reinterpret_cast<LPBYTE>(&d), &size) == ERROR_SUCCESS;
        out = std::to_wstring(d);
      } else if ((type == REG_SZ || type == REG_EXPAND_SZ) && size < 65536) {
        std::wstring v(size / sizeof(wchar_t) + 1, L'\0');
        DWORD sz = (DWORD)(v.size() * sizeof(wchar_t));
        ok = RegQueryValueExW(k, id.c_str(), nullptr, nullptr, reinterpret_cast<LPBYTE>(&v[0]), &sz) == ERROR_SUCCESS;
        v.resize(wcsnlen(v.c_str(), v.size()));
        if (type == REG_EXPAND_SZ) {
          wchar_t buf[2048];
          const DWORD n = ExpandEnvironmentStringsW(v.c_str(), buf, 2048);
          if (n > 0 && n <= 2048) v = buf;
        }
        out = v;
      }
      if (ok) {
        where = Fmt(L"组策略 %ls\\%ls（值名 %ls）", r == 0 ? L"HKLM" : L"HKCU", sub.c_str(), id.c_str());
        RegCloseKey(k);
        return true;
      }
    }
    RegCloseKey(k);
  }
  return false;
}
LoaderOverrides ReadLoaderOverrides() {
  LoaderOverrides o;
  bool env = false;
  o.browserFolder = EnvValue(L"WEBVIEW2_BROWSER_EXECUTABLE_FOLDER", env);
  o.userDataFolder = EnvValue(L"WEBVIEW2_USER_DATA_FOLDER", env);
  o.extraArgs = EnvValue(L"WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", env);
  const std::wstring ch = EnvValue(L"WEBVIEW2_RELEASE_CHANNEL_PREFERENCE", env);
  if (env) {
    if (!ch.empty()) o.channelPref = (int)wcstol(ch.c_str(), nullptr, 10);
    o.source = L"环境变量";
    return o;
  }
  std::vector<std::wstring> ids;
  typedef HRESULT(WINAPI * AumidFn)(PWSTR*);
  HMODULE sh = GetModuleHandleW(L"shell32.dll");
  AumidFn aumidFn = sh ? reinterpret_cast<AumidFn>(reinterpret_cast<void*>(GetProcAddress(sh, "GetCurrentProcessExplicitAppUserModelID"))) : nullptr;
  PWSTR aumid = nullptr;
  if (aumidFn && SUCCEEDED(aumidFn(&aumid)) && aumid) {
    ids.push_back(aumid);
    CoTaskMemFree(aumid);
  }
  ids.push_back(PathName(ModulePath(nullptr)));
  ids.push_back(L"*");
  std::wstring v, where;
  std::vector<std::wstring> from;
  if (PolicyValue(L"BrowserExecutableFolder", ids, v, where)) {
    o.browserFolder = v;
    from.push_back(where);
  }
  if (PolicyValue(L"UserDataFolder", ids, v, where)) {
    o.userDataFolder = v;
    from.push_back(where);
  }
  if (PolicyValue(L"AdditionalBrowserArguments", ids, v, where)) {
    o.extraArgs = v;
    from.push_back(where);
  }
  if (PolicyValue(L"ReleaseChannelPreference", ids, v, where)) {
    o.channelPref = (int)wcstol(v.c_str(), nullptr, 10);
    from.push_back(where);
  }
  for (size_t i = 0; i < from.size(); ++i) o.source += (i ? L"；" : L"") + from[i];
  return o;
}

RuntimeInfo FindRuntime(bool rescan, const std::wstring& explicitDirIn) {
  std::wstring explicitDir = explicitDirIn;
  int policy = 0;
  {
    Guard g(GLock());
    if (explicitDir.empty()) explicitDir = G().runtimeDir;
    policy = G().policy;
  }
  const LoaderOverrides ov = ReadLoaderOverrides();
  if (!ov.browserFolder.empty()) explicitDir = ov.browserFolder;  // 环境变量或组策略指定的运行时目录覆盖程序自己的设置（与官方加载器一致）
  std::wstring appDir = AppDir();
  std::wstring dllDir = PathDir(ModulePath(g_module));
  if (!explicitDir.empty() && !IsAbsPath(explicitDir)) explicitDir = PathJoin(appDir, explicitDir);  // 与其它路径一致（也认 //服务器/共享）
  std::wstring key = explicitDir + L"|" + appDir + L"|" + std::to_wstring(policy) + L"|" + std::to_wstring(ov.channelPref);
  Guard g(RtLock());
  if (g_rtValid && !rescan && key == g_rtKey) return g_rt;

  RuntimeInfo info;
  info.ov = ov;
  const bool legacy = Os().legacy;
  auto okOs = [&](const RuntimeCandidate& c) { return !legacy || c.major <= 109; };
  std::vector<RuntimeCandidate> fixed, installed;
  std::vector<std::wstring> wrongArch;
  std::vector<BrokenRuntime> broken;
  int budget = 600;
  if (!explicitDir.empty()) {
    ScanFixed(explicitDir, 3, true, fixed, budget, &wrongArch, &broken);
  } else {
    ScanFixed(appDir, 3, false, fixed, budget, &wrongArch, &broken);
    if (_wcsicmp(dllDir.c_str(), appDir.c_str()) != 0) ScanFixed(dllDir, 3, false, fixed, budget, &wrongArch, &broken);
    AddInstalled(installed, &broken);
  }
  // 不能把 Microsoft Edge 浏览器自己的安装目录（…\Edge\Application\…）当作 WebView2 运行时：微软的加载器对这种目录返回 ERROR_NOT_SUPPORTED
  bool edgeDir = false;
  fixed.erase(std::remove_if(fixed.begin(), fixed.end(),
                             [&](const RuntimeCandidate& c) {
                               std::wstring l = Lower(c.dir) + L"\\";
                               std::replace(l.begin(), l.end(), L'/', L'\\');
                               const bool e = l.find(L"\\edge\\application\\") != std::wstring::npos;
                               if (e) edgeDir = true;
                               return e;
                             }),
              fixed.end());
  info.all = installed;
  info.all.insert(info.all.end(), fixed.begin(), fixed.end());

  auto pick = [&](const std::vector<RuntimeCandidate>& v, RuntimeCandidate& outc) {
    bool got = false;
    for (const auto& c : v) {
      if (!okOs(c)) continue;
      if (!got || Better(c, outc)) { outc = c; got = true; }
    }
    return got;
  };
  // 已安装的常青版按通道顺序找：稳定版、Beta、Dev、Canary（通道偏好为 1 时反过来），取找到的第一个通道里版本最高的（与官方加载器一致；
  // 原来没有稳定版时在各预览通道里取版本最高的，装了 Beta 和 Canary 时会选 Canary）
  auto pickInstalled = [&](RuntimeCandidate& outc) {
    for (int k = 0; k < 4; ++k) {
      const int ch = ov.channelPref == 1 ? 3 - k : k;
      std::vector<RuntimeCandidate> one;
      for (const auto& c : installed)
        if (c.channel == ch) one.push_back(c);
      if (pick(one, outc)) return true;
    }
    return false;
  };
  RuntimeCandidate sel;
  bool found = false;
  if (!explicitDir.empty()) {
    found = pick(fixed, sel);
    if (!found) info.reason = fixed.empty() ? L"指定的运行时目录中没有找到 32 位（x86）WebView2 运行时：" + explicitDir
                                            : L"指定目录里的运行时版本不支持当前系统（Win7/8/8.1 只能用 109 及以下版本）";
  } else {
    switch (policy) {
      case 1: found = pick(fixed, sel) || pickInstalled(sel); break;
      case 2: found = pickInstalled(sel); break;
      case 3: found = pick(fixed, sel); break;
      default:
        // 所有系统都先用已安装的常青版（Win7/8/8.1 上微软安装常青版装的就是为这些系统保留的 109 版，版本由 okOs 把关），没有时再用固定版。
        // 原来 Win7/8/8.1 先用固定版：程序目录里的固定版坏了时，即使已经装好常青版，查找结果仍然是坏的那个
        found = pickInstalled(sel) || pick(fixed, sel);
        break;
    }
    if (!found) {
      bool tooNew = false;
      for (const auto& c : info.all)
        if (!okOs(c)) tooNew = true;
      if (legacy)
        info.reason = tooNew ? L"找到的运行时版本高于 109，不能在 Windows 7/8/8.1 上运行，请改用 109 版固定版运行时（x86）"
                             : L"没有找到 WebView2 运行时。Windows 7/8/8.1 请把 109 版固定版运行时（x86）解压到程序目录的 WebView2 文件夹";
      else
        info.reason = L"没有找到 WebView2 运行时（Windows 11 自带；Windows 10 可一键安装常青版，或把固定版运行时放到程序目录的 WebView2 文件夹）";
      info.plainMissing = !tooNew;
    }
  }
  if (!found && !wrongArch.empty()) {
    info.reason = L"找到的是 64 位 WebView2 运行时（" + wrongArch[0] + L"），本程序是 32 位，需要 x86 版本的固定版运行时（目录名以 .x86 结尾）";
    info.plainMissing = false;
  }
  if (!found && edgeDir) {
    info.reason = L"不能把 Microsoft Edge 浏览器的安装目录（…\\Edge\\Application）当作 WebView2 运行时（微软的加载器同样拒绝），请改用 WebView2 固定版运行时";
    info.plainMissing = false;
  }
  for (const auto& b : broken) {  // 去重：同一目录可能既是程序目录又是 DLL 所在目录，常青版可能同时登记在 ClientState 与 pv
    bool dup = false;
    for (const auto& x : info.broken)
      if (_wcsicmp(x.dir.c_str(), b.dir.c_str()) == 0) dup = true;
    if (!dup) info.broken.push_back(b);
  }
  if (!found && !info.broken.empty()) {  // 找到了运行时却用不了：说明具体原因，比“没有找到”更有用
    const BrokenRuntime& b = info.broken[0];
    info.reason = b.inProcess ? L"运行时 " + b.dir + L" 在本次运行中已经启动失败（" + b.reason +
                                    L"），运行时组件会记住这次失败，修复后要重新启动程序才能再用它"
                  : b.network ? L"找到的 WebView2 固定版运行时没有使用：" + b.dir + L"（" + b.reason + L"）"  // 文件本身没有问题，不说“文件不完整”
                              : L"找到的 WebView2 运行时文件不完整，没有使用：" + b.dir + L"（" + b.reason + L"）";
    if (info.broken.size() > 1) info.reason += Fmt(L"；另有 %u 个运行时也用不了，见诊断信息", (unsigned)(info.broken.size() - 1));
    info.plainMissing = false;
  }
  info.found = found;
  if (found) info.sel = sel;
  Log(L"运行时查找：系统 %ls，策略 %d，候选 %u 个，结果：%ls", Os().name.c_str(), policy, (unsigned)info.all.size(),
      found ? (sel.version + L" @ " + sel.dir).c_str() : info.reason.c_str());
  for (const auto& b : info.broken) Log(L"运行时查找：没有采用 %ls（%ls%ls）", b.dir.c_str(), b.reason.c_str(), b.inProcess ? L"，本进程里已失效" : L"");
  g_rt = info;
  g_rtValid = true;
  g_rtKey = key;
  return info;
}

static std::wstring CandJson(const RuntimeCandidate& c) {
  return L"{\"kind\":" + JsonStr(c.kind == 0 ? L"installed" : L"fixed") + L",\"version\":" + JsonStr(c.version) +
         L",\"major\":" + std::to_wstring(c.major) + L",\"dir\":" + JsonStr(c.dir) + L",\"source\":" + JsonStr(c.source) + L"}";
}
std::wstring RuntimeJson(const RuntimeInfo& r) {
  std::wstring s = L"{\"found\":" + std::wstring(r.found ? L"true" : L"false");
  s += L",\"os\":" + JsonStr(Os().name) + L",\"legacyOs\":" + (Os().legacy ? L"true" : L"false");
  int policy = 0;
  std::wstring runtimeDir;
  {
    Guard g(GLock());
    policy = G().policy;
    runtimeDir = G().runtimeDir;
  }
  s += L",\"policy\":" + std::to_wstring(policy);
  if (!runtimeDir.empty()) s += L",\"runtimeDir\":" + JsonStr(runtimeDir);  // 程序指定的运行时目录：指定了就只用那里的运行时，装了常青版也不用
  if (!r.ov.source.empty())
    s += L",\"override\":{\"source\":" + JsonStr(r.ov.source) + L",\"browserFolder\":" + JsonStr(r.ov.browserFolder) + L",\"userDataFolder\":" +
         JsonStr(r.ov.userDataFolder) + L",\"extraArgs\":" + JsonStr(r.ov.extraArgs) + L",\"channelPreference\":" + std::to_wstring(r.ov.channelPref) + L"}";
  if (r.found) s += L",\"selected\":" + CandJson(r.sel);
  else s += L",\"reason\":" + JsonStr(r.reason);
  s += L",\"candidates\":[";
  for (size_t i = 0; i < r.all.size(); ++i) { if (i) s += L','; s += CandJson(r.all[i]); }
  s += L"]";
  if (!r.broken.empty()) {  // 文件不完整、放在网络位置、在本进程里已失效而没有采用的运行时
    s += L",\"broken\":[";
    for (size_t i = 0; i < r.broken.size(); ++i) {
      if (i) s += L',';
      s += L"{\"dir\":" + JsonStr(r.broken[i].dir) + L",\"reason\":" + JsonStr(r.broken[i].reason) + L",\"inProcess\":" +
           (r.broken[i].inProcess ? L"true" : L"false") + L"}";
    }
    s += L"]";
  }
  return s + L"}";
}

std::wstring DefaultUserDataDir() {
  std::wstring base = AppDir();
  std::wstring d = PathJoin(base, L"WebView2Data");
  if (EnsureDir(d) && DirWritable(d)) return d;
  wchar_t la[MAX_PATH] = {0};
  if (!GetEnvironmentVariableW(L"LOCALAPPDATA", la, MAX_PATH)) GetTempPathW(MAX_PATH, la);
  d = PathJoin(PathJoin(la, L"WebView2Bridge"), Hash8(Lower(base)));
  EnsureDir(d);
  return d;
}

// ---------------------------------------------------------------- 环境选项 COM 对象
class EnvOptions final : public ICoreWebView2EnvironmentOptions,
                         public ICoreWebView2EnvironmentOptions2,
                         public ICoreWebView2EnvironmentOptions3,
                         public ICoreWebView2EnvironmentOptions5,
                         public ICoreWebView2EnvironmentOptions6,
                         public ICoreWebView2EnvironmentOptions8 {
 public:
  std::wstring args, lang, target;
  BOOL sso = FALSE, exclusive = FALSE, crash = FALSE, tracking = TRUE, extensions = FALSE;
  COREWEBVIEW2_SCROLLBAR_STYLE scrollbar = COREWEBVIEW2_SCROLLBAR_STYLE_DEFAULT;

  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppv) override {
    if (!ppv) return E_POINTER;
    *ppv = nullptr;
    if (IsEqualIID(riid, wv_iid<IUnknown>::get()) || IsEqualIID(riid, wv_iid<ICoreWebView2EnvironmentOptions>::get()))
      *ppv = static_cast<ICoreWebView2EnvironmentOptions*>(this);
    else if (IsEqualIID(riid, wv_iid<ICoreWebView2EnvironmentOptions2>::get()))
      *ppv = static_cast<ICoreWebView2EnvironmentOptions2*>(this);
    else if (IsEqualIID(riid, wv_iid<ICoreWebView2EnvironmentOptions3>::get()))
      *ppv = static_cast<ICoreWebView2EnvironmentOptions3*>(this);
    else if (IsEqualIID(riid, wv_iid<ICoreWebView2EnvironmentOptions5>::get()))
      *ppv = static_cast<ICoreWebView2EnvironmentOptions5*>(this);
    else if (IsEqualIID(riid, wv_iid<ICoreWebView2EnvironmentOptions6>::get()))
      *ppv = static_cast<ICoreWebView2EnvironmentOptions6*>(this);
    else if (IsEqualIID(riid, wv_iid<ICoreWebView2EnvironmentOptions8>::get()))
      *ppv = static_cast<ICoreWebView2EnvironmentOptions8*>(this);
    if (!*ppv) return E_NOINTERFACE;
    AddRef();
    return S_OK;
  }
  ULONG STDMETHODCALLTYPE AddRef() override { return (ULONG)InterlockedIncrement(&ref_); }
  ULONG STDMETHODCALLTYPE Release() override {
    LONG r = InterlockedDecrement(&ref_);
    if (!r) delete this;
    return (ULONG)r;
  }
  static HRESULT Dup(const std::wstring& s, LPWSTR* out) {
    if (!out) return E_POINTER;
    size_t bytes = (s.size() + 1) * sizeof(wchar_t);
    *out = static_cast<LPWSTR>(CoTaskMemAlloc(bytes));
    if (!*out) return E_OUTOFMEMORY;
    memcpy(*out, s.c_str(), bytes);
    return S_OK;
  }
  HRESULT STDMETHODCALLTYPE get_AdditionalBrowserArguments(LPWSTR* v) override { return Dup(args, v); }
  HRESULT STDMETHODCALLTYPE put_AdditionalBrowserArguments(LPCWSTR v) override { args = v ? v : L""; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_Language(LPWSTR* v) override { return Dup(lang, v); }
  HRESULT STDMETHODCALLTYPE put_Language(LPCWSTR v) override { lang = v ? v : L""; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_TargetCompatibleBrowserVersion(LPWSTR* v) override { return Dup(target, v); }
  HRESULT STDMETHODCALLTYPE put_TargetCompatibleBrowserVersion(LPCWSTR v) override { target = v ? v : L""; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_AllowSingleSignOnUsingOSPrimaryAccount(BOOL* v) override { if (!v) return E_POINTER; *v = sso; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_AllowSingleSignOnUsingOSPrimaryAccount(BOOL v) override { sso = v; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_ExclusiveUserDataFolderAccess(BOOL* v) override { if (!v) return E_POINTER; *v = exclusive; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_ExclusiveUserDataFolderAccess(BOOL v) override { exclusive = v; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_IsCustomCrashReportingEnabled(BOOL* v) override { if (!v) return E_POINTER; *v = crash; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_IsCustomCrashReportingEnabled(BOOL v) override { crash = v; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_EnableTrackingPrevention(BOOL* v) override { if (!v) return E_POINTER; *v = tracking; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_EnableTrackingPrevention(BOOL v) override { tracking = v; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_AreBrowserExtensionsEnabled(BOOL* v) override { if (!v) return E_POINTER; *v = extensions; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_AreBrowserExtensionsEnabled(BOOL v) override { extensions = v; return S_OK; }
  HRESULT STDMETHODCALLTYPE get_ScrollBarStyle(COREWEBVIEW2_SCROLLBAR_STYLE* v) override { if (!v) return E_POINTER; *v = scrollbar; return S_OK; }
  HRESULT STDMETHODCALLTYPE put_ScrollBarStyle(COREWEBVIEW2_SCROLLBAR_STYLE v) override { scrollbar = v; return S_OK; }

 private:
  volatile LONG ref_ = 1;
};

ComPtr<IUnknown> MakeEnvOptions(const std::wstring& args, const std::wstring& lang, const std::wstring& target, int tracking, int scrollbar) {
  EnvOptions* o = new EnvOptions();
  o->args = args;
  o->lang = lang;
  o->target = target;  // 返回实际选中运行时的版本：兼容判定总能通过
  if (tracking == 0) o->tracking = FALSE;
  if (scrollbar == 1) o->scrollbar = COREWEBVIEW2_SCROLLBAR_STYLE_FLUENT_OVERLAY;
  ComPtr<IUnknown> r;
  r.attach(static_cast<ICoreWebView2EnvironmentOptions*>(o));
  return r;
}

// ---------------------------------------------------------------- 自建加载器：直接调用运行时客户端 DLL 的入口
// 与 WebView2Loader 及 webview/webview 内置加载器相同：EBWebView\x86\EmbeddedBrowserWebView.dll 导出
// CreateWebViewEnvironmentWithOptionsInternal(bool checkRunningInstance, int runtimeType, PCWSTR userDataDir, IUnknown* options, handler)
typedef HRESULT(STDMETHODCALLTYPE* CreateInternalFn)(bool, int, PCWSTR, IUnknown*, ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler*);

// PE 文件头里的机器类型：0x14C=x86，0x8664=x64，0xAA64=ARM64；不是有效的 PE 文件返回 0
static WORD PeMachine(const std::wstring& path) {
  HANDLE f = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING, 0, nullptr);
  if (f == INVALID_HANDLE_VALUE) return 0;
  unsigned char b[1024];
  DWORD n = 0;
  BOOL ok = ReadFile(f, b, sizeof(b), &n, nullptr);
  CloseHandle(f);
  if (!ok || n < 0x40 || b[0] != 'M' || b[1] != 'Z') return 0;
  DWORD pe = 0;
  memcpy(&pe, b + 0x3C, 4);
  if (pe > n - 6 || memcmp(b + pe, "PE\0\0", 4) != 0) return 0;
  WORD m = 0;
  memcpy(&m, b + pe + 4, 2);
  return m;
}

HRESULT CreateEnvironment(const RuntimeCandidate& rt, const std::wstring& udf, IUnknown* options,
                          ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler* h) {
  HMODULE m = LoadLibraryExW(rt.clientDll.c_str(), nullptr, LOAD_WITH_ALTERED_SEARCH_PATH);
  if (!m) {
    DWORD e = GetLastError();
    // 错误 193 既可能是位数不对，也可能是文件根本不是 DLL（下载或解压不完整）：看文件头区分，给出准确的提示
    if (e == ERROR_BAD_EXE_FORMAT && PeMachine(rt.clientDll) == 0) e = ERROR_FILE_CORRUPT;
    Log(L"载入运行时客户端失败 %u：%ls", e, rt.clientDll.c_str());
    return HRESULT_FROM_WIN32(e);
  }
  CreateInternalFn fn = reinterpret_cast<CreateInternalFn>(reinterpret_cast<void*>(GetProcAddress(m, "CreateWebViewEnvironmentWithOptionsInternal")));
  if (!fn) return HRESULT_FROM_WIN32(ERROR_PROC_NOT_FOUND);
  Log(L"创建环境：运行时 %ls（%ls），数据目录 %ls", rt.version.c_str(), rt.kind ? L"固定版" : L"常青版", udf.c_str());
  return fn(true, rt.kind == 1 ? 1 : 0, udf.empty() ? nullptr : udf.c_str(), options, h);
}

std::wstring FriendlyHr(HRESULT hr) {
  switch ((unsigned)hr) {
    case 0x80070002u:
    case 0x80070003u: return L"找不到 WebView2 运行时文件";
    case 0x80070005u: return L"用户数据目录无法写入（权限不足，或该目录正被以管理员身份运行的另一个程序占用）";
    case 0x8007139Fu: return L"同一个用户数据目录已被启动参数不同（代理、语言、浏览器参数）的浏览器占用，请给不同配置使用不同的数据目录";
    case 0x80004004u: return L"创建被中止（父窗口已关闭）";
    case 0x80010106u: return L"当前线程的 COM 不是 STA 单线程套间";
    case 0x8007000Eu: return L"内存不足";
    case 0x80070057u: return L"参数无效（例如配置名称含非法字符）";
    case 0x8007007Eu: return L"运行时文件不完整或缺少依赖项";
    case 0x800700C1u: return L"运行时位数不符（这是 64 位运行时文件，本程序需要 32 位 x86 版本）";
    case 0x80070570u: return L"运行时文件已损坏或不完整（不是有效的 DLL），请重新下载并解压 32 位（x86）固定版运行时";
    case 0x80070032u: return L"当前运行时不支持该功能";
    case 0x800706BAu:
    case 0x80080005u: return L"浏览器进程启动失败";
  }
  return L"操作失败";
}

// ---------------------------------------------------------------- 运行时安装（Win10/11：常青版引导程序；Win7/8/8.1：109 版离线安装包）
namespace {
// 读安装线程写的字段：InterlockedCompareExchange 带完整的内存屏障，读到完成标志后再读的结果与错误说明一定是安装线程写好的
LONG ReadShared(volatile LONG& v) { return InterlockedCompareExchange(&v, 0, 0); }

// Windows 7/8/8.1 用的 109.0.1518.140 x86 离线安装包：微软更新目录的下载地址（目录给出的是 HTTPS 与 HTTP 两种写法）、大小与 SHA-1
const wchar_t kLegacyPackageUrl[] =
    L"https://catalog.s.download.windowsupdate.com/c/msdownload/update/software/updt/2023/09/microsoftedgestandaloneinstallerx86_179f59bc54d73843d9288a9fd5609de0e507b911.exe";
const wchar_t kLegacyPackageUrlHttp[] =
    L"http://catalog.s.download.windowsupdate.com/c/msdownload/update/software/updt/2023/09/microsoftedgestandaloneinstallerx86_179f59bc54d73843d9288a9fd5609de0e507b911.exe";
const unsigned long long kLegacyPackageSize = 138366936ull;
const wchar_t kLegacyPackageSha1[] = L"179f59bc54d73843d9288a9fd5609de0e507b911";
// 只供测试：不联网时换成写入指定内容的“下载”
HRESULT(WINAPI* g_testDownload)(LPUNKNOWN, LPCWSTR, LPCWSTR, DWORD, LPVOID) = nullptr;

// 文件内容的 SHA-1（小写十六进制），按已打开的句柄从头读；算不出时返回空
std::wstring Sha1OfHandle(HANDLE f) {
  HCRYPTPROV prov = 0;
  HCRYPTHASH hash = 0;
  std::wstring out;
  LARGE_INTEGER zero = {};
  if (!SetFilePointerEx(f, zero, nullptr, FILE_BEGIN)) return out;
  if (!CryptAcquireContextW(&prov, nullptr, nullptr, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) return out;
  if (CryptCreateHash(prov, CALG_SHA1, 0, 0, &hash)) {
    std::vector<unsigned char> buf(1 << 20);
    DWORD got = 0;
    bool ok = true;
    while (ok && ReadFile(f, buf.data(), (DWORD)buf.size(), &got, nullptr) && got) ok = CryptHashData(hash, buf.data(), got, 0) != FALSE;
    unsigned char d[20];
    DWORD n = sizeof(d);
    if (ok && CryptGetHashParam(hash, HP_HASHVAL, d, &n, 0) && n == sizeof(d))
      for (unsigned char c : d) out += Fmt(L"%02x", (unsigned)c);
    CryptDestroyHash(hash);
  }
  CryptReleaseContext(prov, 0);
  SetFilePointerEx(f, zero, nullptr, FILE_BEGIN);  // 读回开头：之后按同一个句柄校验签名
  return out;
}

// 离线安装包的命令行（网友实测可用的写法，另加 /silent 不显示界面）：已经以管理员身份运行时装给整台电脑；没有时与微软的引导程序一样
// “尽量装给整台电脑”（needsadmin=prefers），不能提升时只装给当前用户
std::wstring LegacyPackageCommand(const std::wstring& file, bool elevated) {
  return L"\"" + file + L"\" /silent /installsource windowsupdate /install \"appguid={F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}&needsadmin=" +
         (elevated ? L"true" : L"prefers") + L"\"";
}

struct InstallJob {
  volatile LONG done = 0;
  volatile LONG ok = 0;
  volatile LONG stage = 0;      // 1 下载（引导程序，Win7/8/8.1 为离线安装包） 2 校验 3 运行安装程序 4 等另一个程序装完
  volatile LONG permille = -1;  // 下载进度（千分比）；大小未知时为 -1
  DWORD start = 0;
  std::wstring err;
  std::wstring log;  // 安装失败时微软安装程序日志的最后几行（“复制诊断信息”里带上）
};
Lock g_installLock;
InstallJob* g_job = nullptr;
std::wstring g_installErr;
std::wstring g_installLog;

// 下载进度回调：URLDownloadToFileW 在调用它的线程里同步回调（文档推荐用 IBindStatusCallback::OnProgress 取进度）。
// 对象放在安装线程的栈上，调用期间一直有效，引用计数不决定生命周期；其余方法照 ATL 的 CBindStatusCallback 返回默认值
class DownloadProgress final : public IBindStatusCallback {
 public:
  explicit DownloadProgress(InstallJob* j) : job_(j) {}
  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppv) override {
    static const IID kIidBindStatusCallback = {0x79eac9c1, 0xbaf9, 0x11ce, {0x8c, 0x82, 0x00, 0xaa, 0x00, 0x4b, 0xa9, 0x0b}};
    if (!ppv) return E_POINTER;
    if (IsEqualIID(riid, kIidBindStatusCallback) || IsEqualIID(riid, wv_iid<IUnknown>::get())) {
      *ppv = static_cast<IBindStatusCallback*>(this);
      return S_OK;
    }
    *ppv = nullptr;
    return E_NOINTERFACE;
  }
  ULONG STDMETHODCALLTYPE AddRef() override { return 2; }
  ULONG STDMETHODCALLTYPE Release() override { return 1; }
  HRESULT STDMETHODCALLTYPE OnStartBinding(DWORD, IBinding*) override { return S_OK; }
  HRESULT STDMETHODCALLTYPE GetPriority(LONG*) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE OnLowResource(DWORD) override { return S_OK; }
  HRESULT STDMETHODCALLTYPE OnProgress(ULONG got, ULONG total, ULONG, LPCWSTR) override {
    if (total) InterlockedExchange(&job_->permille, (LONG)((unsigned long long)std::min(got, total) * 1000ull / total));
    return S_OK;
  }
  HRESULT STDMETHODCALLTYPE OnStopBinding(HRESULT, LPCWSTR) override { return S_OK; }
  HRESULT STDMETHODCALLTYPE GetBindInfo(DWORD*, BINDINFO*) override { return E_NOTIMPL; }
  HRESULT STDMETHODCALLTYPE OnDataAvailable(DWORD, DWORD, FORMATETC*, STGMEDIUM*) override { return S_OK; }
  HRESULT STDMETHODCALLTYPE OnObjectAvailable(REFIID, IUnknown*) override { return S_OK; }

 private:
  InstallJob* job_;
};

// 签名必须可信（WinVerifyTrust），且签名者是微软；任何其他受信任证书签名的程序都不运行
// 按调用方持有的句柄校验（WINTRUST_FILE_INFO.hFile）：调用方从校验到启动一直持有不允许写入的句柄，校验过的内容就是要运行的内容
bool VerifySignature(const std::wstring& file, HANDLE handle, std::wstring& why) {
  typedef LONG(WINAPI * WinVerifyTrustFn)(HWND, GUID*, LPVOID);
  HMODULE h = LoadSystemDll(L"wintrust.dll");
  WinVerifyTrustFn fn = h ? reinterpret_cast<WinVerifyTrustFn>(reinterpret_cast<void*>(GetProcAddress(h, "WinVerifyTrust"))) : nullptr;
  if (!fn) {
    why = L"系统缺少签名校验组件";
    return false;
  }
  WINTRUST_FILE_INFO fi;
  ZeroMemory(&fi, sizeof(fi));
  fi.cbStruct = sizeof(fi);
  fi.pcwszFilePath = file.c_str();
  fi.hFile = handle;
  WINTRUST_DATA wd;
  ZeroMemory(&wd, sizeof(wd));
  wd.cbStruct = sizeof(wd);
  wd.dwUIChoice = WTD_UI_NONE;
  wd.fdwRevocationChecks = WTD_REVOKE_NONE;
  wd.dwUnionChoice = WTD_CHOICE_FILE;
  wd.pFile = &fi;
  wd.dwStateAction = WTD_STATEACTION_VERIFY;
  GUID action = WINTRUST_ACTION_GENERIC_VERIFY_V2;
  LONG r = fn(nullptr, &action, &wd);
  wd.dwStateAction = WTD_STATEACTION_CLOSE;
  fn(nullptr, &action, &wd);
  if (r != 0) {
    why = Fmt(L"签名无效或不受信任，错误 0x%08X", (unsigned)r);
    return false;
  }
  std::wstring signer = wvsign::AuthenticodeSigner(file, LoadSystemDll(L"crypt32.dll"));
  if (signer != L"Microsoft Corporation") {
    why = L"签名者不是微软：" + (signer.empty() ? std::wstring(L"无法读取签名者") : signer);
    return false;
  }
  return true;
}

// 已经有可用的常青版（别的程序刚装好，或本来就有）：不必再下载安装。文件不全的、Win7/8/8.1 上高于 109 的不算
bool InstalledRuntimeUsable() {
  std::vector<RuntimeCandidate> v;
  AddInstalled(v);
  for (const auto& c : v)
    if (!Os().legacy || c.major <= 109) return true;
  return false;
}

// 安装结果记在 HKCU（所有用本 DLL 的程序共用）：失败时记下时间与原因，成功时清除。程序自动发起的安装据此冷却 24 小时
const wchar_t kInstallStateKey[] = L"Software\\WebView2Bridge";
const unsigned long long kInstallCooldown = 24ull * 3600ull * 10000000ull;  // FILETIME 单位（100 纳秒）
unsigned long long NowFileTime() {
  FILETIME ft;
  GetSystemTimeAsFileTime(&ft);
  return ((unsigned long long)ft.dwHighDateTime << 32) | ft.dwLowDateTime;
}
void RecordInstallResult(bool ok, const std::wstring& err) {
  HKEY k = nullptr;
  if (RegCreateKeyExW(HKEY_CURRENT_USER, kInstallStateKey, 0, nullptr, 0, KEY_SET_VALUE, nullptr, &k, nullptr) != ERROR_SUCCESS) return;
  if (ok) {
    RegDeleteValueW(k, L"InstallFailedAt");
    RegDeleteValueW(k, L"InstallFailedReason");
  } else {
    const unsigned long long t = NowFileTime();
    const std::wstring why = err.empty() ? std::wstring(L"原因未知") : err.substr(0, 900);
    RegSetValueExW(k, L"InstallFailedAt", 0, REG_QWORD, reinterpret_cast<const BYTE*>(&t), sizeof(t));
    RegSetValueExW(k, L"InstallFailedReason", 0, REG_SZ, reinterpret_cast<const BYTE*>(why.c_str()), (DWORD)((why.size() + 1) * sizeof(wchar_t)));
  }
  RegCloseKey(k);
}
bool InstallCooldown(std::wstring& msg) {
  HKEY k = nullptr;
  if (RegOpenKeyExW(HKEY_CURRENT_USER, kInstallStateKey, 0, KEY_QUERY_VALUE, &k) != ERROR_SUCCESS) return false;
  unsigned long long t = 0;
  DWORD type = 0, size = sizeof(t);
  bool cool = false;
  if (RegQueryValueExW(k, L"InstallFailedAt", nullptr, &type, reinterpret_cast<LPBYTE>(&t), &size) == ERROR_SUCCESS && type == REG_QWORD &&
      size == sizeof(t)) {
    const unsigned long long now = NowFileTime();
    if (now >= t && now - t < kInstallCooldown) {
      wchar_t why[1024] = {0};
      DWORD ws = sizeof(why) - sizeof(wchar_t);
      RegQueryValueExW(k, L"InstallFailedReason", nullptr, nullptr, reinterpret_cast<LPBYTE>(why), &ws);
      FILETIME u, lt;
      u.dwLowDateTime = (DWORD)t;
      u.dwHighDateTime = (DWORD)(t >> 32);
      SYSTEMTIME st = {};
      FileTimeToLocalFileTime(&u, &lt);
      FileTimeToSystemTime(&lt, &st);
      msg = Fmt(L"上次安装 WebView2 运行时没有成功（%u-%02u-%02u %02u:%02u，%ls），24 小时内不再自动安装；可以在提示卡片上点“一键安装”手动重试",
                st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, why[0] ? why : L"原因未知");
      cool = true;
    }
  }
  RegCloseKey(k);
  return cool;
}

// 系统对错误码的说明（不带错误码本身）
std::wstring SysText(DWORD code) {
  wchar_t* msg = nullptr;
  const DWORD n = FormatMessageW(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, nullptr, code, 0,
                                 reinterpret_cast<LPWSTR>(&msg), 0, nullptr);
  std::wstring s = n && msg ? Trim(msg) : std::wstring();
  if (msg) LocalFree(msg);
  return s;
}

// 目录所在的磁盘至少还有 need 字节：132MB 的离线安装包先查空间，免得下载到一半才因磁盘满失败（白下一大半）
bool EnoughSpaceFor(const std::wstring& dir, unsigned long long need, std::wstring& why) {
  ULARGE_INTEGER freeBytes = {};
  if (!GetDiskFreeSpaceExW(dir.c_str(), &freeBytes, nullptr, nullptr)) return true;  // 查不到时不拦
  if (freeBytes.QuadPart >= need) return true;
  why = Fmt(L"临时文件夹所在的磁盘空间不足：下载 109 版离线安装包需要约 %llu MB，只剩 %llu MB（%ls）", need >> 20, (unsigned long long)(freeBytes.QuadPart >> 20), dir.c_str());
  return false;
}

// urlmon 下载时先存进 IE 的缓存（Temporary Internet Files）再复制出来：132MB 的离线安装包用完后把缓存里那份也删掉，不白占磁盘
void DropDownloadCache(const wchar_t* url) {
  HMODULE wi = LoadSystemDll(L"wininet.dll");
  typedef BOOL(WINAPI * DeleteFn)(LPCWSTR);
  DeleteFn del = wi ? reinterpret_cast<DeleteFn>(reinterpret_cast<void*>(GetProcAddress(wi, "DeleteUrlCacheEntryW"))) : nullptr;
  if (del) del(url);
}

// 下载失败的错误码（urlmon 的 INET_E_*）在系统里查不到说明，原来只显示一串十六进制：常见的几种写成文字
std::wstring DownloadErrorText(HRESULT hr) {
  const wchar_t* t = nullptr;
  switch ((unsigned)hr) {
    case 0x800C0002u: t = L"下载地址无效"; break;
    case 0x800C0003u: t = L"无法建立网络会话"; break;
    case 0x800C0004u: t = L"无法连接到服务器"; break;
    case 0x800C0005u: t = L"找不到服务器或文件"; break;
    case 0x800C0006u: t = L"服务器上没有这个文件"; break;
    case 0x800C0007u: t = L"服务器没有返回数据"; break;
    case 0x800C0008u: t = L"下载中断或无法下载"; break;
    case 0x800C0009u: t = L"需要代理或服务器的身份验证"; break;
    case 0x800C000Bu: t = L"连接超时"; break;
    case 0x800C000Eu: t = L"安全连接失败（系统可能不支持 TLS 1.2，或系统时间、根证书有问题）"; break;
    case 0x800C0014u: t = L"重定向失败"; break;
    case 0x800C0019u: t = L"服务器证书无效"; break;
  }
  return t ? std::wstring(t) + Fmt(L"（0x%08X）", (unsigned)hr) : HrText(hr);
}

// 本进程是否以管理员身份（提升后）运行：安装失败时据此决定要不要建议“以管理员身份运行”
bool ProcessElevated() {
  HANDLE t = nullptr;
  if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &t)) return false;
  TOKEN_ELEVATION e = {};
  DWORD n = 0;
  const bool elevated = GetTokenInformation(t, TokenElevation, &e, sizeof(e), &n) && e.TokenIsElevated;
  CloseHandle(t);
  return elevated;
}

// 用当前用户的默认环境启动安装程序（与在资源管理器里双击一样），不继承本程序改过的环境变量：宿主程序常把自己的 DLL 目录加到 PATH
// 最前面（如精易模块的 程序_初始化路径），兼容模式的设置也经 __COMPAT_LAYER 传给子进程，这些都不该影响微软的安装程序。
// 返回的环境块用 FreeEnvBlock 释放；拿不到时返回空（照旧继承）
void* CleanEnvBlock() {
  wchar_t sys[MAX_PATH] = {0};
  if (!GetSystemDirectoryW(sys, MAX_PATH)) return nullptr;
  HMODULE ue = LoadLibraryW((std::wstring(sys) + L"\\userenv.dll").c_str());  // 按完整路径载入系统 DLL；留在进程里，释放环境块时还要用
  typedef BOOL(WINAPI * CreateFn)(LPVOID*, HANDLE, BOOL);
  CreateFn create = ue ? reinterpret_cast<CreateFn>(reinterpret_cast<void*>(GetProcAddress(ue, "CreateEnvironmentBlock"))) : nullptr;
  void* env = nullptr;
  HANDLE tok = nullptr;
  if (create && OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY | TOKEN_DUPLICATE, &tok)) {
    if (!create(&env, tok, FALSE)) env = nullptr;  // FALSE：不带本进程的环境变量，只用这个用户的默认环境
    CloseHandle(tok);
  }
  return env;
}
void FreeEnvBlock(void* env) {
  if (!env) return;
  HMODULE ue = GetModuleHandleW(L"userenv.dll");
  typedef BOOL(WINAPI * DestroyFn)(LPVOID);
  DestroyFn destroy = ue ? reinterpret_cast<DestroyFn>(reinterpret_cast<void*>(GetProcAddress(ue, "DestroyEnvironmentBlock"))) : nullptr;
  if (destroy) destroy(env);
}

// 本程序在允许脱离的作业里（例如由启动器、兼容性助手放进作业）：让安装程序脱离出去，与手动运行时一样不受作业限制（Win7 不支持嵌套作业，
// 安装程序自己再建作业会失败）
bool BreakawayAllowed() {
  BOOL inJob = FALSE;
  if (!IsProcessInJob(GetCurrentProcess(), nullptr, &inJob) || !inJob) return false;
  JOBOBJECT_EXTENDED_LIMIT_INFORMATION li;
  ZeroMemory(&li, sizeof(li));
  if (!QueryInformationJobObject(nullptr, JobObjectExtendedLimitInformation, &li, sizeof(li), nullptr)) return false;
  return (li.BasicLimitInformation.LimitFlags & JOB_OBJECT_LIMIT_BREAKAWAY_OK) != 0;
}

// 微软安装程序（Edge 更新程序）的日志：装给整台电脑时在 %ProgramData%，只装给当前用户时在 %LOCALAPPDATA% 下的
// Microsoft\EdgeUpdate\Log\MicrosoftEdgeUpdate.log。实际的日志是带 BOM 的 UTF-16（小端）文本，追加写入，多年的记录都在里面，
// 所以启动安装程序前记下文件大小，失败后只取这之后新写的几行（旧的记录与这次失败无关，混进来只会误导）
struct EdgeUpdateLogMark {
  std::wstring path[2];
  unsigned long long size[2] = {0, 0};
};
EdgeUpdateLogMark MarkEdgeUpdateLog() {
  EdgeUpdateLogMark m;
  const wchar_t* vars[2] = {L"ProgramData", L"LOCALAPPDATA"};
  for (int i = 0; i < 2; ++i) {
    wchar_t b[MAX_PATH] = {0};
    const DWORD n = GetEnvironmentVariableW(vars[i], b, MAX_PATH);
    if (!n || n >= MAX_PATH) continue;
    m.path[i] = PathJoin(b, L"Microsoft\\EdgeUpdate\\Log\\MicrosoftEdgeUpdate.log");
    WIN32_FILE_ATTRIBUTE_DATA fa;
    if (GetFileAttributesExW(m.path[i].c_str(), GetFileExInfoStandard, &fa) && !(fa.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
      m.size[i] = ((unsigned long long)fa.nFileSizeHigh << 32) | fa.nFileSizeLow;
  }
  return m;
}
// 记下之后新写进日志的最后几行（每行一个 \r\n）；安装程序一行都没写时返回空——它在启动早期就失败了
std::wstring EdgeUpdateLogSince(const EdgeUpdateLogMark& m, size_t maxLines) {
  for (int i = 0; i < 2; ++i) {
    if (m.path[i].empty()) continue;
    HANDLE f = CreateFileW(m.path[i].c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING, 0, nullptr);
    if (f == INVALID_HANDLE_VALUE) continue;
    LARGE_INTEGER li = {};
    GetFileSizeEx(f, &li);
    const unsigned long long size = (unsigned long long)li.QuadPart, prev = m.size[i] <= size ? m.size[i] : 0;  // 变小了：日志被轮换，从头看
    if (size <= prev) {
      CloseHandle(f);
      continue;
    }
    unsigned char head[3] = {0, 0, 0};
    DWORD got = 0;
    ReadFile(f, head, 3, &got, nullptr);
    const bool utf16 = got >= 2 && head[0] == 0xFF && head[1] == 0xFE, utf8bom = got >= 3 && head[0] == 0xEF && head[1] == 0xBB && head[2] == 0xBF;
    const unsigned long long cap = 65536;  // 只看最后 64KB：安装程序写得再多，最后几行也在里面
    unsigned long long start = size - prev > cap ? size - cap : prev;
    if (utf16 && (start & 1)) ++start;  // UTF-16 按两字节对齐
    if (start == 0) start = utf16 ? 2 : utf8bom ? 3 : 0;  // 跳过 BOM
    const bool partial = start > prev && start > 3;  // 从新内容的中间开始读：第一行不完整
    std::string raw(start < size ? (size_t)(size - start) : 0, '\0');
    LARGE_INTEGER pos = {};
    pos.QuadPart = (LONGLONG)start;
    got = 0;
    if (raw.empty() || !SetFilePointerEx(f, pos, nullptr, FILE_BEGIN) || !ReadFile(f, &raw[0], (DWORD)raw.size(), &got, nullptr)) got = 0;
    CloseHandle(f);
    raw.resize(got);
    std::wstring w;
    if (utf16) {
      w.assign(raw.size() / 2, L'\0');
      if (!w.empty()) memcpy(&w[0], raw.data(), w.size() * sizeof(wchar_t));
    } else {  // 没有 BOM：按 UTF-8，不是合法的 UTF-8 时按系统代码页
      UINT cp = CP_UTF8;
      DWORD fl = MB_ERR_INVALID_CHARS;
      int n = raw.empty() ? 0 : MultiByteToWideChar(cp, fl, raw.data(), (int)raw.size(), nullptr, 0);
      if (n <= 0 && !raw.empty()) {
        cp = CP_ACP;
        fl = 0;
        n = MultiByteToWideChar(cp, fl, raw.data(), (int)raw.size(), nullptr, 0);
      }
      if (n > 0) {
        w.assign((size_t)n, L'\0');
        MultiByteToWideChar(cp, fl, raw.data(), (int)raw.size(), &w[0], n);
      }
    }
    std::vector<std::wstring> lines;
    size_t at = 0;
    if (partial) {
      const size_t first = w.find(L'\n');
      at = first == std::wstring::npos ? w.size() : first + 1;
    }
    while (at < w.size()) {
      size_t e = w.find(L'\n', at);
      if (e == std::wstring::npos) e = w.size();
      std::wstring line = Trim(w.substr(at, e - at));
      if (!line.empty()) lines.push_back(line.size() > 400 ? line.substr(0, 400) + L"…" : line);
      at = e + 1;
    }
    if (lines.empty()) continue;
    std::wstring out;
    for (size_t k = lines.size() > maxLines ? lines.size() - maxLines : 0; k < lines.size(); ++k) out += lines[k] + L"\r\n";
    return out;
  }
  return std::wstring();
}

DWORD InstallThreadBody(LPVOID p) {
  InstallJob* job = static_cast<InstallJob*>(p);
  HRESULT hrCo = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
  // 跨进程：同一台电脑上几个程序（或同一程序多开）同时要安装时，后来的等前一个结束、再看是否已经装好，不同时运行两个引导程序
  HANDLE mx = CreateMutexW(nullptr, FALSE, L"Global\\WebView2Bridge.RuntimeInstall");
  if (!mx) mx = CreateMutexW(nullptr, FALSE, L"Local\\WebView2Bridge.RuntimeInstall");
  bool owned = false;
  if (mx) {
    DWORD w = WaitForSingleObject(mx, 0);
    if (w == WAIT_TIMEOUT) {
      InterlockedExchange(&job->stage, 4);
      Log(L"另一个程序正在安装 WebView2 运行时，等它结束");
      w = WaitForSingleObject(mx, 20 * 60 * 1000);
    }
    owned = w == WAIT_OBJECT_0 || w == WAIT_ABANDONED;
  }
  // 下载到本次安装新建的专用子目录：引导程序启动时先在自己所在的目录里找依赖的 DLL，直接放在公共的临时目录里，别的程序预先放在
  // 那里的同名 DLL 就可能被它载入。目录必须是这次新建的（已存在就换个名字），里面只有引导程序；名字带进程号，同一程序多开时互不干扰
  std::wstring dir, file;
  for (int i = 0; i < 16 && dir.empty(); ++i) {
    std::wstring d = PathJoin(TempDir(), Fmt(L"wv2setup_%lu_%lu_%d", (unsigned long)GetCurrentProcessId(), (unsigned long)GetTickCount(), i));
    if (CreateDirectoryW(d.c_str(), nullptr)) dir = d;
  }
  const bool legacyPkg = UseLegacyOfflinePackage();  // Windows 7/8/8.1：微软更新目录里的 109.0.1518.140 x86 离线安装包（见 UseLegacyOfflinePackage）
  if (!dir.empty()) file = PathJoin(dir, legacyPkg ? L"MicrosoftEdgeStandaloneInstallerX86.exe" : L"MicrosoftEdgeWebview2Setup.exe");
  auto cleanup = [&] {  // 用不上了：不在临时目录里留下引导程序和它的目录
    if (!file.empty()) DeleteFileW(file.c_str());
    if (!dir.empty()) RemoveDirectoryW(dir.c_str());
  };
  typedef HRESULT(WINAPI * DownloadFn)(LPUNKNOWN, LPCWSTR, LPCWSTR, DWORD, LPVOID);
  HMODULE um = LoadSystemDll(L"urlmon.dll");
  DownloadFn dl = um ? reinterpret_cast<DownloadFn>(reinterpret_cast<void*>(GetProcAddress(um, "URLDownloadToFileW"))) : nullptr;
  if (g_testDownload) dl = g_testDownload;  // 只供测试：不联网，换成写入指定内容的“下载”
  do {
    if (mx && !owned) { job->err = L"另一个程序正在安装 WebView2 运行时，等了 20 分钟仍未结束，请稍后重试"; cleanup(); break; }
    unsigned foreign = 0;  // 1.8.1：互斥体被遗弃（上一个持有者没释放就结束了）或别的程序没用本 DLL 也在装：等它启动的安装程序结束，再看是否已经装好
    if (!WaitForeignInstallers(&job->stage, g_foreignWaitMs, foreign)) {
      job->err = Fmt(L"另一个 WebView2 安装程序运行了 %u 分钟仍未结束，请稍后重试", (unsigned)(g_foreignWaitMs / 60000));
      cleanup();
      break;
    }
    if (InstalledRuntimeUsable()) {
      Log(L"已有可用的常青版运行时，不再下载安装");
      cleanup();
      InterlockedExchange(&job->ok, 1);
      break;
    }
    if (dir.empty()) { job->err = L"无法在临时目录里新建安装用的文件夹（临时目录不可写？）"; break; }
    if (!dl) { job->err = L"系统缺少 urlmon.dll，无法下载"; cleanup(); break; }
    if (legacyPkg && !EnoughSpaceFor(dir, kLegacyPackageSize + (16ull << 20), job->err)) {
      cleanup();
      break;
    }
    Log(legacyPkg ? L"下载 Windows 7/8/8.1 用的 WebView2 109.0.1518.140 x86 离线安装包（约 132MB）到 %ls" : L"下载 WebView2 常青版引导程序到 %ls", file.c_str());
    InterlockedExchange(&job->stage, 1);
    DownloadProgress progress(job);
    HRESULT hr = dl(nullptr, legacyPkg ? kLegacyPackageUrl : L"https://go.microsoft.com/fwlink/p/?LinkId=2124703", file.c_str(), 0, &progress);
    if (FAILED(hr) && legacyPkg) {  // 没装 TLS 1.2 更新的 Windows 7 打不开 HTTPS：改用同一地址的 HTTP（文件按大小、SHA-1 与微软签名校验，不怕被改）
      Log(L"HTTPS 下载失败（%ls），改用 HTTP", DownloadErrorText(hr).c_str());
      DeleteFileW(file.c_str());
      hr = dl(nullptr, kLegacyPackageUrlHttp, file.c_str(), 0, &progress);
    }
    if (legacyPkg) {  // 已经保存到专用子目录（或下载失败）：IE 缓存里的那份不再需要
      DropDownloadCache(kLegacyPackageUrl);
      DropDownloadCache(kLegacyPackageUrlHttp);
    }
    if (FAILED(hr)) {
      job->err = (legacyPkg ? L"下载 109 版离线安装包失败：" : L"下载引导程序失败：") + DownloadErrorText(hr) +
                 (legacyPkg ? L"（请检查网络或代理；网络正常时可能是微软更新目录的下载地址已经失效）" : L"（请检查网络或代理）");
      cleanup();  // 中途失败时可能留下不完整的文件
      break;
    }
    // 文档说明：文件没能创建时 URLDownloadToFile 也可能返回成功。这里先确认文件确实存在，否则会被误报成签名校验失败
    WIN32_FILE_ATTRIBUTE_DATA fa;
    if (!GetFileAttributesExW(file.c_str(), GetFileExInfoStandard, &fa) || (fa.nFileSizeHigh == 0 && fa.nFileSizeLow == 0)) {
      job->err = std::wstring(legacyPkg ? L"下载 109 版离线安装包失败" : L"下载引导程序失败") + L"：文件没有保存下来（临时目录不可写，或被安全软件拦截）";
      cleanup();
      break;
    }
    InterlockedExchange(&job->stage, 2);
    // 从校验到启动一直持有不允许写入的句柄，签名也按这个句柄校验：通过校验的文件在开始运行之前不能被改写或替换
    HANDLE lock = CreateFileW(file.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (lock == INVALID_HANDLE_VALUE) {
      job->err = std::wstring(legacyPkg ? L"无法打开下载的 109 版离线安装包：" : L"无法打开下载的引导程序：") + HrText(HRESULT_FROM_WIN32(GetLastError()));
      cleanup();
      break;
    }
    std::wstring why;
    if (legacyPkg) {  // 离线安装包是微软更新目录里固定的一个文件：大小与 SHA-1（目录的文件名里就是它）都要对上，按持有的句柄算，校验后不会被换掉
      LARGE_INTEGER sz = {};
      GetFileSizeEx(lock, &sz);
      const std::wstring sha1 = Sha1OfHandle(lock);
      if ((unsigned long long)sz.QuadPart != kLegacyPackageSize || _wcsicmp(sha1.c_str(), kLegacyPackageSha1) != 0) {
        CloseHandle(lock);
        job->err = Fmt(L"下载的 109 版离线安装包与微软更新目录登记的不一致（大小 %llu 字节，SHA-1 %ls），已停止安装", (unsigned long long)sz.QuadPart,
                       sha1.empty() ? L"无法计算" : sha1.c_str());
        cleanup();
        break;
      }
      // 签名照常校验；文件已经与微软登记的完全一致，没装 SHA-2 签名更新的 Windows 7 校验不了微软的新签名时只记下来，不拦
      if (!VerifySignature(file, lock, why)) Log(L"离线安装包的数字签名没能校验（%ls），文件与微软更新目录登记的 SHA-1 一致，继续安装", why.c_str());
    } else if (!VerifySignature(file, lock, why)) {
      CloseHandle(lock);
      job->err = L"下载的引导程序未通过数字签名校验（" + why + L"），已停止安装";
      cleanup();
      break;
    }
    InterlockedExchange(&job->stage, 3);
    std::wstring cmd = legacyPkg ? LegacyPackageCommand(file, ProcessElevated()) : L"\"" + file + L"\" /silent /install";
    STARTUPINFOW si;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi;
    ZeroMemory(&pi, sizeof(pi));
    std::vector<wchar_t> buf(cmd.begin(), cmd.end());
    buf.push_back(0);
    // 当前目录也设为专用子目录：引导程序按当前目录找文件时同样只看得到它自己。环境用当前用户的默认环境（见 CleanEnvBlock）
    void* env = CleanEnvBlock();
    const EdgeUpdateLogMark logMark = MarkEdgeUpdateLog();  // 失败后只取这之后新写的日志
    DWORD flags = env ? CREATE_UNICODE_ENVIRONMENT : 0;
    if (BreakawayAllowed()) flags |= CREATE_BREAKAWAY_FROM_JOB;
    // 安装程序缺系统函数这类启动错误不弹系统对话框（“无法定位程序输入点”）：子进程在创建时继承本进程的错误模式，这一刻带上
    // SEM_FAILCRITICALERRORS（立即恢复）。失败照样以错误码结束，由卡片说明
    const UINT errMode = GetErrorMode();
    SetErrorMode(errMode | SEM_FAILCRITICALERRORS);
    BOOL started = CreateProcessW(file.c_str(), buf.data(), nullptr, nullptr, FALSE, flags, env, dir.c_str(), &si, &pi);
    DWORD startErr = started ? 0 : GetLastError();
    if (!started && (flags & CREATE_BREAKAWAY_FROM_JOB)) {  // 作业不让脱离时照常启动
      started = CreateProcessW(file.c_str(), buf.data(), nullptr, nullptr, FALSE, flags & ~CREATE_BREAKAWAY_FROM_JOB, env, dir.c_str(), &si, &pi);
      startErr = started ? 0 : GetLastError();
    }
    SetErrorMode(errMode);
    FreeEnvBlock(env);
    CloseHandle(lock);
    if (!started) {
      job->err = L"启动安装程序失败：" + HrText(HRESULT_FROM_WIN32(startErr));
      cleanup();  // 启动不了就用不上了
      break;
    }
    DWORD wait = WaitForSingleObject(pi.hProcess, 15 * 60 * 1000);
    DWORD code = 0;
    GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    if (wait == WAIT_TIMEOUT) {  // 原来会把仍在运行的状态码 0x103 当成安装程序的错误码报出来
      job->err = L"安装程序运行了 15 分钟仍未结束（可能在等待网络，或被安全软件拦截）。可以稍后重试，或从微软官网手动安装 WebView2 运行时";
      break;  // 安装程序还在使用这个文件，不删除
    }
    cleanup();
    Log(L"安装程序退出码 0x%08X", (unsigned)code);
    if (code != 0 && InstalledRuntimeUsable()) {  // 1.8.1：与另一个安装程序同时进行时，后启动的那个会报错，运行时却已经装好了
      Log(L"安装程序返回错误码 0x%08X，但已有可用的常青版运行时（可能是同时进行的另一个安装装好的），按成功处理", (unsigned)code);
      InterlockedExchange(&job->ok, 1);
      break;
    }
    if (code != 0) {
      // 错误码多是 HRESULT：带上系统的说明。安装程序这次写了日志时，具体原因在日志里；一行都没写时它在启动早期就失败了
      // （实际遇到过：Win7 上当前的引导程序以 0x8007007F“找不到指定的程序”结束、日志里没有这次的任何记录——它载入自己的组件时
      // 就失败了，常见原因是组件用到了这个系统没有的函数）。“以管理员身份运行”只在没有提升时建议，已经是管理员时这样提示只会误导
      const std::wstring sys = (code & 0x80000000u) ? SysText(code) : std::wstring();
      job->log = EdgeUpdateLogSince(logMark, 15);
      const bool early = job->log.empty(), loadFail = code == 0x8007007Fu || code == 0x8007007Eu;
      std::wstring hint;
      if (legacyPkg)
        hint = early ? L"。109 版离线安装包在启动早期就失败了（没有写安装日志），可以改用 109 版固定版运行时"
                     : L"。可以从微软更新目录手动下载“Microsoft Edge-WebView2 Runtime Version 109 Update for x86 based Editions (Build 109.0.1518.140)”安装，"
                       L"或改用 109 版固定版运行时（微软安装程序这次写的日志见“复制诊断信息”）";
      else if (early && loadFail)
        hint = L"。微软的安装程序在启动早期就失败了（没有写安装日志，多半是用到了这个系统没有的函数），可以从微软官网下载 WebView2 运行时手动安装";
      else if (early)
        hint = ProcessElevated() ? L"。微软的安装程序在启动早期就失败了（没有写安装日志），可以从微软官网下载 WebView2 运行时手动安装"
                                 : L"。微软的安装程序在启动早期就失败了（没有写安装日志），可以以管理员身份运行本程序后重试，或从微软官网下载 WebView2 运行时手动安装";
      else
        hint = (ProcessElevated() ? L"。可以从微软官网下载 WebView2 运行时手动安装" : L"。可以以管理员身份运行本程序后重试，或从微软官网下载 WebView2 运行时手动安装") +
               std::wstring(L"（微软安装程序这次写的日志见“复制诊断信息”）");
      job->err = Fmt(L"安装程序返回错误码 0x%08X", (unsigned)code) + (sys.empty() ? std::wstring() : L"（" + sys + L"）") + hint;
      Log(L"%ls", job->err.c_str());
      break;
    }
    InterlockedExchange(&job->ok, 1);
  } while (false);
  if (owned) ReleaseMutex(mx);
  if (mx) CloseHandle(mx);
  RecordInstallResult(ReadShared(job->ok) != 0, job->err);
  if (SUCCEEDED(hrCo)) CoUninitialize();
  {
    Guard g(g_installLock);
    g_installErr = job->err;
    g_installLog = job->log;
  }
  InterlockedExchange(&job->done, 1);
  // 交给界面线程统一处理：所有等待运行时的浏览器一起恢复（或一起显示失败原因），不只通知点了按钮的那一个
  HWND disp = Dispatcher().load();
  if (disp && IsWindow(disp)) PostMessageW(disp, WM_WV_INSTALL_DONE, (WPARAM)ReadShared(job->ok), 0);
  return 0;
}
// 线程入口里的异常不能穿出去（进程会直接结束）。出错时同样把这次安装标记为结束并通知界面线程：
// 否则安装一直算作“正在进行”，之后再点“一键安装”也不会启动
DWORD WINAPI InstallThread(LPVOID p) {
  try {
    return InstallThreadBody(p);
  } catch (...) {
    InstallJob* job = static_cast<InstallJob*>(p);
    try {
      Guard g(g_installLock);
      g_installErr = L"安装过程中出现内部异常（可能是内存不足）";
    } catch (...) {
    }
    InterlockedExchange(&job->done, 1);
    HWND disp = Dispatcher().load();
    if (disp && IsWindow(disp)) PostMessageW(disp, WM_WV_INSTALL_DONE, 0, 0);
    return 1;
  }
}
}  // namespace

// 安装程序正常结束、却仍没有可用的运行时（例如装好的常青版文件不全、程序只用固定版）也算失败：否则程序自动发起的安装每次都要
// 下载、运行一遍引导程序才回退到固定版
void RecordInstallFailure(const std::wstring& why) { RecordInstallResult(false, why); }

// 微软当前的在线安装程序（常青版引导程序带的 MicrosoftEdgeUpdate.exe）启动时要用 kernel32 的 PackageIdFromFullName（Windows 8 起才有）：
// Windows 7（及 Server 2008 R2）上一启动就报“无法定位程序输入点 PackageIdFromFullName 于动态链接库 KERNEL32.dll 上”，从程序里静默运行时
// 以 0x8007007F 退出、不写任何安装日志（实际遇到过，用户手动运行得到同样的提示）。这样的系统上不再下载运行它，直接说明原因
int g_onlineInstallerOverride = -1;  // 只供测试：-1 按系统实际情况，0 当作不支持，1 当作支持（Wine 的 kernel32 总有这个函数）
bool OnlineInstallerSupported() {
  if (g_onlineInstallerOverride >= 0) return g_onlineInstallerOverride != 0;
  HMODULE k = GetModuleHandleW(L"kernel32.dll");
  return k && GetProcAddress(k, "PackageIdFromFullName");
}
// Windows 7/8/8.1（及 Server 2008 R2/2012/2012 R2，内核 6.1～6.3）改用微软更新目录里的“Microsoft Edge-WebView2 Runtime Version 109 Update
// for x86 based Editions (Build 109.0.1518.140)”（2023-09-15，138366936 字节）：它是离线安装包，自带当年还支持这些系统的更新程序，不用再联网
// 下载运行时，装的是 109 的最后一版（与在线安装在这些系统上装的相同）。微软员工说明这个包就是给 Win7/8/8.1（含 Server 2012 R2）的 109
// 延长支持用的；Win7 上实测用 LegacyPackageCommand 的命令能全新安装，而微软当前的在线安装程序在 Win7 上启动不了，在 8/8.1 上没有验证过
// ——它们和 Win7 同时停止支持，统一用离线安装包更稳。x86 版给 32 位程序用（本 DLL 是 32 位），64 位系统上也一样。Vista、XP 连 109 也不支持
bool UseLegacyOfflinePackage() { return Os().major == 6 && Os().minor >= 1; }

std::wstring LastInstallError() {
  Guard g(g_installLock);
  return g_installErr;
}
std::wstring LastInstallLog() {
  Guard g(g_installLock);
  return g_installLog;
}

// 1.8.1：别的进程启动的微软 WebView2 安装程序还在运行时先等它结束。例如同一账号再开软件时旧实例被结束：它启动的安装程序是独立的进程，
// 不随它退出，安装互斥体却已被遗弃，后来的实例拿到互斥体时 InstalledRuntimeUsable() 仍为假；也可能是别的程序没用本 DLL 也在装。
// 这时再启动一个安装程序，后一个会失败并把正在进行的安装报成失败（程序随后可能多余地改用别的运行时）
const wchar_t* g_testInstallerImage = nullptr;
DWORD g_foreignWaitMs = 15 * 60 * 1000;
static bool IsInstallerImage(const wchar_t* exe) {
  static const wchar_t* const names[] = {L"MicrosoftEdgeWebview2Setup.exe", L"MicrosoftEdgeStandaloneInstallerX86.exe",
                                         L"MicrosoftEdgeWebView2RuntimeInstallerX86.exe", L"MicrosoftEdgeWebView2RuntimeInstallerX64.exe",
                                         L"MicrosoftEdgeWebView2RuntimeInstallerARM64.exe"};
  for (const wchar_t* n : names)
    if (_wcsicmp(exe, n) == 0) return true;
  return g_testInstallerImage && _wcsicmp(exe, g_testInstallerImage) == 0;
}
static unsigned CountForeignInstallers() {
  unsigned n = 0;
  HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if (snap == INVALID_HANDLE_VALUE) return 0;
  PROCESSENTRY32W pe;
  pe.dwSize = sizeof(pe);
  for (BOOL more = Process32FirstW(snap, &pe); more; more = Process32NextW(snap, &pe))
    if (pe.th32ProcessID != GetCurrentProcessId() && IsInstallerImage(pe.szExeFile)) ++n;
  CloseHandle(snap);
  return n;
}
// 按进程快照轮询（别的用户或提升了权限的进程不一定打得开句柄），全部结束返回真；等满 maxMs 仍有在运行的返回假
bool WaitForeignInstallers(volatile LONG* stage, DWORD maxMs, unsigned& seen) {
  seen = CountForeignInstallers();
  if (!seen) return true;
  if (stage) InterlockedExchange(stage, 4);
  Log(L"另一个 WebView2 安装程序正在运行（%u 个），等它结束再继续", seen);
  const DWORD t0 = GetTickCount();
  while (CountForeignInstallers()) {
    if (GetTickCount() - t0 >= maxMs) return false;
    Sleep(500);
  }
  return true;
}
int InstallStateCode(std::wstring& err) {
  Guard g(g_installLock);
  if (!g_job) return WVIS_NONE;
  if (!ReadShared(g_job->done)) return WVIS_RUNNING;
  if (ReadShared(g_job->ok)) return WVIS_SUCCEEDED;
  err = g_installErr.empty() ? std::wstring(L"安装没有成功（原因未知）") : g_installErr;
  return WVIS_FAILED;
}

bool StartRuntimeInstall(bool automatic) {
  Guard g(g_installLock);
  // Win7/8/8.1 也可以安装：用微软更新目录里的 109 版离线安装包（见 UseLegacyOfflinePackage；微软当前的在线引导程序在 Win7 上启动不了），
  // 装好后查找运行时只认 109 及以下版本。原来在这些系统上直接拒绝安装，只能用固定版
  // 已有安装在进行：不再启动第二个安装程序（同时运行两个引导程序，后一个会失败并把已经开始的安装报成失败）
  if (g_job && !ReadShared(g_job->done)) return true;
  if (!OnlineInstallerSupported() && !UseLegacyOfflinePackage()) {  // 装不上的系统（Vista、XP）：不下载、不运行，也不算一次失败（不记冷却）
    g_installErr = L"这个系统上装不了 WebView2 运行时：微软当前的在线安装程序启动时要用 Windows 8 起才有的系统函数 PackageIdFromFullName，"
                   L"Windows 7/8/8.1 用的 109 版离线安装包也不支持更早的系统";
    return false;
  }
  std::wstring cooling;
  if (automatic && InstallCooldown(cooling)) {  // 程序自动发起的安装：上次失败后 24 小时内不再自动安装，免得每次打开都等一遍下载
    g_installErr = cooling;
    return false;
  }
  g_installLog.clear();  // 上次失败的安装日志只属于上一次
  InstallJob* job = new InstallJob();  // 线程结束后保留，供并发查询（体积很小，安装通常只发生一次）
  job->start = GetTickCount();
  HANDLE t = CreateThread(nullptr, 0, InstallThread, job, 0, nullptr);
  if (!t) {
    g_installErr = L"无法启动安装线程：" + HrText(HRESULT_FROM_WIN32(GetLastError()));
    delete job;
    return false;
  }
  g_job = job;
  CloseHandle(t);
  return true;
}

bool EvergreenAllowed(const std::wstring& viewRuntimeDir) {
  if (!viewRuntimeDir.empty()) return false;
  {
    Guard g(GLock());
    if (!G().runtimeDir.empty() || G().policy == 3) return false;
  }
  return ReadLoaderOverrides().browserFolder.empty();  // 环境变量或组策略指定了运行时目录时只用那里的运行时，装常青版没有用
}

bool InstallStatus(int& stage, int& permille, DWORD& elapsedMs) {
  Guard g(g_installLock);
  if (!g_job || ReadShared(g_job->done)) return false;
  stage = (int)ReadShared(g_job->stage);
  permille = stage == 1 ? (int)ReadShared(g_job->permille) : -1;
  elapsedMs = GetTickCount() - g_job->start;
  return true;
}

bool InstallRuntimeBlocking(DWORD timeoutMs, bool automatic) {
  if (!StartRuntimeInstall(automatic)) return false;  // 已有安装在进行时等它结束
  InstallJob* job;
  {
    Guard g(g_installLock);
    job = g_job;
  }
  if (!PumpUntil([job] { return ReadShared(job->done) != 0; }, timeoutMs)) {
    Guard g(g_installLock);
    g_installErr = L"安装超时（安装仍在后台进行，可稍后再试）";
    return false;
  }
  return ReadShared(job->ok) != 0;
}

}  // namespace wv
