// wv_api.cpp : DllMain 与全部导出函数（stdcall 纯 C 接口）
#include "wv_internal.h"

using namespace wv;

namespace {
void JsonCacheDrop(DWORD tid);
std::wstring JsonCacheStatsJson();
}
BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID) {
  if (reason == DLL_PROCESS_ATTACH) {
    g_module = h;
    InitOs();  // 载入时就判定系统版本，决定走 v109（Win7/8/8.1）还是新内核（Win10/11）
  } else if (reason == DLL_THREAD_DETACH) {
    JsonCacheDrop(GetCurrentThreadId());  // 线程正常结束：立即释放它在 JSON取值 缓存里的一项（只动本 DLL 自己的锁与内存）
  }
  return TRUE;
}

namespace {

// 交给界面线程执行并等它执行完（target 属于界面线程）。界面线程在 WVO_THREAD_TIMEOUT 内（默认 10 秒，0 为一直等）没有开始执行时取消这次调用：
// 此时界面线程多半正在等待本线程（例如易语言用“等待线程”等它结束）或长时间没有处理消息。原来用不限时的 SendMessage，两边会一直互相等待
// （实测界面线程无限等待时，20 秒后两边仍卡着）。任务登记在编号表里，界面线程取走编号才开始执行；超时后本线程先从表里注销：注销成功说明还没开始，
// 之后界面线程再收到这条消息也找不到任务；注销失败说明界面线程已经取走、正在执行，任务引用着调用方栈上的数据，必须等它执行完。
// 等待期间像 SendMessage 一样处理别的线程发给本线程的同步消息（不处理投递的消息）
enum class Handoff { Done, NotRun, TimedOut };
Handoff RunOnUiThread(HWND target, std::function<void()>& task, const std::atomic<bool>& finished, DWORD& limit) {
  {
    Guard g(GLock());
    limit = G().threadTimeout;
  }
  const LPARAM tok = TaskToken(&task, false);
  bool timedOut = false;
  if (limit == 0) {
    SendMessageW(target, WM_WV_INVOKE, 0, tok);
  } else {
    DWORD_PTR res = 0;
    const DWORD t0 = GetTickCount();
    if (!SendMessageTimeoutW(target, WM_WV_INVOKE, 0, tok, SMTO_NORMAL, limit, &res)) {
      // 超时时系统设置 ERROR_TIMEOUT；个别实现可能不设置，再按已等待的时间与目标窗口是否还在判断
      timedOut = GetLastError() == ERROR_TIMEOUT || (IsWindow(target) && GetTickCount() - t0 >= limit);
    }
  }
  if (TakeTask(tok, false)) return timedOut ? Handoff::TimedOut : Handoff::NotRun;
  while (!finished.load(std::memory_order_acquire)) {
    MsgWaitForMultipleObjectsEx(0, nullptr, 10, QS_SENDMESSAGE, 0);
    MSG m;
    PeekMessageW(&m, nullptr, 0, 0, PM_NOREMOVE | PM_QS_SENDMESSAGE);
  }
  return Handoff::Done;
}
void SetHandoffErr(Handoff h, DWORD limit) {
  if (h == Handoff::TimedOut) {
    CountThreadTimeout();
    SetErr(WVERR_THREAD, Fmt(L"界面线程在 %u 毫秒内没有开始执行这次调用，已取消：界面线程可能正在等待调用方线程（例如用“等待线程”等它结束），"
                             L"或长时间没有处理消息。不要让界面线程一边等工作线程、一边让这个工作线程调用浏览器；必要时用 全局_置转交超时 ()（C/C++：WVO_THREAD_TIMEOUT）调整等待时间",
                             (unsigned)limit));
  } else {
    SetErr(WVERR_THREAD, L"界面线程没有执行这次调用（窗口已销毁或界面线程已退出）");
  }
}

// 在浏览器所属的界面线程执行；其它线程调用时转交界面线程（RunOnUiThread），并把错误信息带回调用线程
template <class R, class F>
R WithView(int h, R fail, F&& fn) {
  RefPtr<View> v = FindView(h);
  if (!v || v->closing) {
    SetErr(WVERR_BAD_HANDLE, L"无效的浏览器句柄（未创建或已销毁）");
    return fail;
  }
  if (GetCurrentThreadId() == v->thread) {
    ClearErr();
    try {
      return fn(v.get());
    } catch (...) {
      SetErr(WVERR_FAILED, L"内部异常（可能是内存不足）");
      return fail;
    }
  }
  R r = fail;
  int ec = 0;
  HRESULT hr = S_OK;
  std::wstring em;
  std::atomic<bool> finished{false};
  std::function<void()> task = [&]() {
    ClearErr();
    try {
      r = fn(v.get());
    } catch (...) {
      SetErr(WVERR_FAILED, L"内部异常（可能是内存不足）");
    }
    ec = ErrCode();
    hr = ErrHr();
    em = ErrMsg();
    finished.store(true, std::memory_order_release);  // 最后一步：之后调用方就会返回，任务不能再碰它的栈
  };
  HWND target = Dispatcher().load();  // 交给调度窗口（界面线程的消息窗口）：不在调用方线程上读浏览器的宿主窗口，它只在界面线程上改动
  DWORD limit = 0;
  const Handoff ho = target ? RunOnUiThread(target, task, finished, limit) : Handoff::NotRun;
  if (ho != Handoff::Done) {
    SetHandoffErr(ho, limit);
    return fail;
  }
  if (ec) SetErr(ec, em, hr);
  else ClearErr();
  return r;
}

template <class R, class F>
R WithUi(R fail, F&& fn) {
  const DWORD ui = UiThread().load();
  if (!ui || ui == GetCurrentThreadId()) {
    ClearErr();
    try {
      return fn();
    } catch (...) {
      SetErr(WVERR_FAILED, L"内部异常（可能是内存不足）");
      return fail;
    }
  }
  R r = fail;
  int ec = 0;
  HRESULT hr = S_OK;
  std::wstring em;
  std::atomic<bool> finished{false};
  std::function<void()> task = [&]() {
    ClearErr();
    try {
      r = fn();
    } catch (...) {
      SetErr(WVERR_FAILED, L"内部异常（可能是内存不足）");
    }
    ec = ErrCode();
    hr = ErrHr();
    em = ErrMsg();
    finished.store(true, std::memory_order_release);
  };
  DWORD limit = 0;
  HWND disp = Dispatcher().load();
  const Handoff ho = disp ? RunOnUiThread(disp, task, finished, limit) : Handoff::NotRun;
  if (ho != Handoff::Done) {
    SetHandoffErr(ho, limit);
    return fail;
  }
  if (ec) SetErr(ec, em, hr);
  else ClearErr();
  return r;
}

DWORD Timeout(int ms, DWORD def) { return ms > 0 ? (DWORD)ms : def; }

// 回调地址：易语言按有符号整数写出（高于 2GB 的地址为负数），C/C++ 调用方可能按无符号写出，两种都按 32 位地址解释
static void* ParsePtr(const std::wstring& s) {
  long long x = wcstoll(s.c_str(), nullptr, 10);
  return reinterpret_cast<void*>(static_cast<uintptr_t>(static_cast<uint32_t>(x)));
}

void ParseOptions(View* v, const std::wstring& text) {
  static const struct { const wchar_t* k; int p; } intKeys[] = {
      {L"devtools", WVP_DEVTOOLS},   {L"contextmenu", WVP_CONTEXT_MENU}, {L"newwindow", WVP_NEW_WINDOW}, {L"zoom", WVP_ZOOM},
      {L"permission", WVP_PERMISSION}, {L"fullscreen", WVP_FULLSCREEN}, {L"scheme", WVP_COLOR_SCHEME},   {L"mute", WVP_MUTED},
      {L"statusbar", WVP_STATUS_BAR}, {L"accelerators", WVP_ACCELERATOR_KEYS}, {L"autofill", WVP_AUTOFILL},
      {L"password", WVP_PASSWORD_AUTOSAVE}, {L"ignorecert", WVP_IGNORE_CERT}, {L"blockimages", WVP_BLOCK_IMAGES},
      {L"silentdownload", WVP_SILENT_DOWNLOAD}, {L"recover", WVP_AUTO_RECOVER}, {L"zoomcontrol", WVP_ZOOM_CONTROL},
      {L"scriptdialogs", WVP_SCRIPT_DIALOGS}, {L"externaldrop", WVP_EXTERNAL_DROP}, {L"nonclient", WVP_NONCLIENT_REGION}};
  static const struct { const wchar_t* k; int p; } strKeys[] = {{L"ua", WVS_USER_AGENT}, {L"downloaddir", WVS_DOWNLOAD_DIR},
                                                               {L"bridgename", WVS_BRIDGE_NAME}, {L"bridgeorigins", WVS_BRIDGE_ORIGINS},
                                                               {L"blockurls", WVS_BLOCK_URLS}, {L"blockkeys", WVS_BLOCK_KEYS}};
  for (const auto& line : Split(text, L"\r\n")) {
    size_t eq = line.find(L'=');
    if (eq == std::wstring::npos) continue;
    std::wstring rawKey = Trim(line.substr(0, eq));
    std::wstring k = Lower(rawKey), val = Trim(line.substr(eq + 1));
    // 易语言类在创建前登记的内容：bind:函数名=回调地址、ev事件号=回调地址、p属性号=整数、s属性号=文本
    if (StartsWithI(rawKey, L"bind:")) {
      std::wstring name = Trim(rawKey.substr(5));
      void* fn = ParsePtr(val);
      if (!name.empty() && fn) {
        v->binds[name] = fn;
        v->bridgeOn = true;
      } else if (!name.empty()) {
        v->binds.erase(name);  // 同一函数名写了多行时以最后一行为准，回调地址为 0 表示解绑（与事件、属性的规则一致）
      }
      continue;
    }
    if (k.size() > 2 && k[0] == L'e' && k[1] == L'v' && iswdigit(k[2])) {
      const int raw = (int)wcstol(k.c_str() + 2, nullptr, 10);
      const int ev = raw & ~WVE_FLAG_NO_OUT;  // 事件号可以带 WVE_FLAG_NO_OUT（易语言类的事件都带）：回调应有的参数表不含最后的 int* 参数
      if (ev > 0 && ev <= WVE_MAX) {
        v->cb[ev] = ParsePtr(val);
        v->cbNoOut[ev] = v->cb[ev] && (raw & WVE_FLAG_NO_OUT) ? 1 : 0;
        // 只设了“JS调用”事件、没有单独绑定的函数时，网页里也要有桥对象；原来不启用 JS 桥，这个事件永远不会触发
        if (ev == WVE_JS_CALL && v->cb[ev]) v->bridgeOn = true;
      }
      continue;
    }
    if (k.size() > 1 && (k[0] == L'p' || k[0] == L's') && iswdigit(k[1])) {
      int prop = (int)wcstol(k.c_str() + 1, nullptr, 10);
      if (k[0] == L'p') v->SetIntProp(prop, (int)wcstol(val.c_str(), nullptr, 10));
      else v->SetStrProp(prop, val);
      continue;
    }
    if (k == L"userdata") v->optUserData = val;
    else if (k == L"proxy") v->optProxy = val;
    else if (k == L"args") v->optArgs = val;
    else if (k == L"lang") v->optLang = val;
    else if (k == L"profile") v->optProfile = val;
    else if (k == L"inprivate") v->optInPrivate = val == L"1" || _wcsicmp(val.c_str(), L"true") == 0;
    else if (k == L"runtime") v->optRuntime = val;
    else if (k == L"fallback") v->optFallback = (int)wcstol(val.c_str(), nullptr, 10);
    else if (k == L"visible") v->visible = val != L"0";
    else if (k == L"bg") {  // 写法与默认背景色相同；原来“#fff”会被当成透明、其余无效写法变成白色
      unsigned argb = 0;
      if (ParseBgColor(val, argb)) v->SetIntProp(WVP_BG_COLOR, (int)argb);
      else Log(L"创建选项 bg 的写法无效，已忽略（只支持 #RRGGBB、#AARRGGBB 或 transparent）：%ls", val.c_str());
    } else {
      bool done = false;
      for (const auto& e : intKeys)
        if (k == e.k) { v->SetIntProp(e.p, (int)wcstol(val.c_str(), nullptr, 10)); done = true; break; }
      if (!done)
        for (const auto& e : strKeys)
          if (k == e.k) { v->SetStrProp(e.p, val); break; }
    }
  }
}

int CreateView(HWND parent, int x, int y, int w, int h, const std::wstring& url, const std::wstring& options, void* onReady, bool sync, DWORD timeout) {
  if (!parent || !IsWindow(parent)) {
    SetErr(WVERR_ARG, L"父窗口句柄无效");
    return 0;
  }
  if (GetWindowThreadProcessId(parent, nullptr) != GetCurrentThreadId()) {
    SetErr(WVERR_THREAD, L"父窗口必须属于界面线程（请在界面线程创建浏览器）");
    return 0;
  }
  if (sync && !CanWait()) return 0;  // 在“将要跳转”等事件回调里，或同步等待已嵌套太深时，不能再等
  // 确认父窗口属于当前线程后才登记界面线程：在工作线程误调用时不会把工作线程登记成界面线程
  if (!EnsureUiThread()) return 0;
  // 每个进程只有一个界面线程（环境缓存与 WebView2 环境对象都只能在它上面使用）。两个线程几乎同时首次创建时，
  // 两边都可能在登记前进入这里；登记后再确认一次，未登记成界面线程的一方与之后从其它线程转交过来的调用结果一致
  if (UiThread().load() != GetCurrentThreadId()) {
    SetErr(WVERR_THREAD, L"父窗口必须属于界面线程（请在界面线程创建浏览器）");
    return 0;
  }
  RegisterClasses();
  View* v = new View(0);
  v->thread = GetCurrentThreadId();
  v->parent = parent;
  v->initialUrl = url;
  ParseOptions(v, options);
  if (onReady) v->cb[WVE_READY] = onReady;
  int id = AddView(v);
  RefPtr<View> hold(v);
  bool fillMode = w <= 0 || h <= 0;
  if (fillMode) {
    v->fill = true;
    v->margin.left = x;
    v->margin.top = y;
    v->margin.right = w < 0 ? -w : 0;
    v->margin.bottom = h < 0 ? -h : 0;
  }
  v->host = CreateWindowExW(WS_EX_CONTROLPARENT, kHostClass, L"", WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS | WS_TABSTOP | (v->visible ? WS_VISIBLE : 0),
                            fillMode ? 0 : x, fillMode ? 0 : y, fillMode ? 0 : w, fillMode ? 0 : h, parent, nullptr, g_module, v);
  if (!v->host) {
    SetErr(WVERR_FAILED, L"创建宿主窗口失败：" + HrText(HRESULT_FROM_WIN32(GetLastError())));
    v->FinishDestroy();
    return 0;
  }
  v->top = GetAncestor(parent, GA_ROOT);
  v->parentSub = HookParent(parent, (UINT_PTR)id, id);
  if (v->top && v->top != parent) v->topSub = HookParent(v->top, (UINT_PTR)id | 0x40000000u, id);
  if (v->top && IsIconic(v->top)) v->minimized = true;
  v->Layout();
  Log(L"创建浏览器 #%d：父窗口 %p，%ls", id, (void*)parent, fillMode ? L"铺满父窗口" : L"指定位置");
  v->StartCreate();
  if (sync && v->state == WV_STATE_CREATING) PumpUntil([v] { return v->state != WV_STATE_CREATING || v->closing; }, timeout);
  if (v->closing) {
    SetErr(WVERR_CLOSED, L"创建过程中父窗口被关闭");
    return 0;
  }
  if (v->state == WV_STATE_READY) {
    ClearErr();
    return id;
  }
  if (v->state == WV_STATE_CREATING) {
    if (sync) SetErr(WVERR_TIMEOUT, L"创建超时（内核仍在启动，完成后会触发“创建完成”事件）");
    return id;
  }
  SetErr(v->errCode, v->errMsg, v->errHr);
  int fb = v->optFallback;
  if (fb < 0) {
    Guard g(GLock());
    fb = G().fallback;
  }
  if (!fb) {
    int code = v->errCode;
    std::wstring msg = v->errMsg;
    HRESULT hr = v->errHr;
    v->FinishDestroy();
    SetErr(code, msg, hr);
    return 0;
  }
  return id;  // 失败但保留宿主窗口显示提示卡片（装好运行时后可自动恢复）
}

std::string OptionText(int key) {
  Guard g(GLock());
  const Globals& s = G();
  switch (key) {
    case WVO_APP_DIR: return ToCP(s.appDir.empty() ? AppDir() : s.appDir);
    case WVO_RUNTIME_DIR: return ToCP(s.runtimeDir);
    case WVO_RUNTIME_POLICY: return std::to_string(s.policy);
    case WVO_USER_DATA_DIR: return ToCP(s.userDataDir);
    case WVO_BROWSER_ARGS: return ToCP(s.args);
    case WVO_LANGUAGE: return ToCP(s.lang);
    case WVO_PROXY: return ToCP(s.proxy);
    case WVO_CODEPAGE: return std::to_string(CodePageVar().load());
    case WVO_LOG_FILE: return ToCP(s.logFile);
    case WVO_DISABLE_GPU: return std::to_string(s.disableGpu);
    case WVO_AUTOPLAY: return std::to_string(s.autoplay);
    case WVO_IGNORE_CERT_ERRORS: return std::to_string(s.ignoreCert);
    case WVO_TRACKING_PREVENTION: return s.tracking < 0 ? std::string() : std::to_string(s.tracking);
    case WVO_SCROLLBAR_STYLE: return std::to_string(s.scrollbar);
    case WVO_DEFAULT_BG: return ToCP(s.defaultBg);
    case WVO_FALLBACK_UI: return std::to_string(s.fallback);
    case WVO_JSON_ESCAPE: return std::to_string(s.jsonEscape);
    case WVO_CALLBACK_HOOK: return s.callbackHook ? std::to_string((unsigned long long)(uintptr_t)s.callbackHook) : std::string();
    case WVO_THREAD_TIMEOUT: return std::to_string(s.threadTimeout);
    case WVO_DEV_CHECKS: return std::to_string(DevChecks().load());
  }
  return std::string();
}

}  // namespace

#define WV_EXPORT(ret) WV_API ret WV_CALL
// 导出函数里的异常不能抛给调用方：易语言等调用方的栈上没有 C++ 的异常处理信息，异常穿出去进程会直接结束。浏览器方法的主体
// 在 WithView、WithUi 里原来就有这层保护；参数与返回值的编码转换、不经过它们的导出函数原来没有，例如超大的文本导致内存不足。
// 现在每个导出函数都是函数级 try 块，异常时按失败返回（整数 0、空文本），错误码 WVERR_FAILED
// 开发期检查打开时，FromCP 收到不合法的 UTF-8 也走这里（抛出 EncodingError）：换成 WVERR_ENCODING，说明里写出接口名和收到的文字
static void ExportFailed(const char* api) noexcept {
  try {
    std::wstring sample;
    if (TakeEncodingError(sample)) {
      const std::wstring msg = Fmt(L"%hs 收到的文本不是 UTF-8（按系统 ANSI 代码页看是“%ls”）。交给本层的文本一律是 UTF-8："
                                   L"易语言源码里的中文用 WV文本 () 包起来，取运行目录 () 等系统给出的文本先用 WV编码_ANSI到UTF8 () 转换",
                                   api, sample.c_str());
      SetErr(WVERR_ENCODING, msg);
      DevNotice(L"encoding:" + FromAnsi(api), msg);  // 每个接口只提示一次
      return;
    }
    SetErr(WVERR_FAILED, L"内部异常（可能是内存不足）");
  } catch (...) {
  }
}

// ================================================================ 全局
WV_EXPORT(int) WV_GetVersion(void) try { return WV_BRIDGE_VERSION; } catch (...) { ExportFailed(__func__); return 0; }

WV_EXPORT(const char*) WV_GetVersionText(void) try {
  // 不写编译日期（__DATE__）：同一份源码任何时候编译都得到逐字节相同的 DLL（可复现构建，另见 build.bat 的 --no-insert-timestamp、/Brepro）
  std::wstring s = Fmt(L"WebView2Bridge %d.%d.%d（SDK 1.0.2903.40，%ls）", WV_BRIDGE_VERSION / 10000, WV_BRIDGE_VERSION / 100 % 100, WV_BRIDGE_VERSION % 100,
#if defined(_MSC_VER)
                       L"MSVC"
#elif defined(__clang__)
                       L"Clang"
#else
                       L"GCC"
#endif
  );
  return Ret(ToCP(s));
} catch (...) {
  ExportFailed(__func__);
  return "";
}

// 程序目录必须已存在：易语言按 ANSI 代码页传入路径，含有代码页无法表示的字符时得到的是不存在的路径，
// 这时保留原值（默认是 EXE 所在目录，用宽字符取得，准确无误），不按错误的目录查找运行时
static bool CheckAppDir(const std::wstring& d) {
  DWORD a = GetFileAttributesW(d.c_str());
  if (a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY)) return true;
  SetErr(WVERR_ARG, L"程序目录不存在（路径可能含有当前代码页无法表示的字符），继续使用原来的目录：" + d);
  return false;
}

// 当前线程是否已有窗口（界面线程的特征）。消息窗口不在枚举之列
static BOOL CALLBACK AnyThreadWindow(HWND, LPARAM p) {
  *reinterpret_cast<bool*>(p) = true;
  return FALSE;
}
static bool ThreadHasWindow() {
  bool any = false;
  EnumThreadWindows(GetCurrentThreadId(), AnyThreadWindow, reinterpret_cast<LPARAM>(&any));
  return any;
}

WV_EXPORT(int) WV_Init(const char* appDir) try {
  std::wstring d = TrimSlash(FullPath(FromCP(appDir)));  // 相对路径换成完整路径：之后当前目录变了也不影响
  ClearErr();
  if (!d.empty() && !CheckAppDir(d)) return 0;
  if (!d.empty()) {
    Guard g(GLock());
    G().appDir = d;
  }
  ClearErr();
  // 只在已有窗口的线程登记界面线程。原来任何线程调用都会登记：在工作线程先调用时，它被永久当成界面线程（还被初始化成 STA 套间，
  // 之后不能再按 MTA 使用 COM），在真正的界面线程创建浏览器只会得到 WVERR_THREAD。没有窗口的线程只设置程序目录，
  // 界面线程等第一次创建浏览器时由父窗口所在的线程登记
  if (!ThreadHasWindow()) return 1;
  return EnsureUiThread() ? 1 : 0;
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_SetOption(int key, const char* value) try {
  // 去掉首尾空白：与创建选项（每个浏览器的设置）的写法一致，路径、语言、启动参数前后多出的空格没有意义，路径前多一个空格还会被当成相对路径
  std::wstring v = Trim(FromCP(value));
  int n = (int)wcstol(v.c_str(), nullptr, 10);
  ClearErr();
  Guard g(GLock());
  Globals& s = G();
  switch (key) {
    case WVO_APP_DIR: {
      std::wstring d = TrimSlash(FullPath(v));  // 相对路径换成完整路径：之后当前目录变了也不影响
      if (!d.empty() && !CheckAppDir(d)) return 0;
      s.appDir = d;
      break;
    }
    case WVO_RUNTIME_DIR: s.runtimeDir = TrimSlash(v); break;
    case WVO_RUNTIME_POLICY: s.policy = (n < 0 || n > 3) ? 0 : n; break;
    case WVO_USER_DATA_DIR: s.userDataDir = TrimSlash(v); break;
    case WVO_BROWSER_ARGS: s.args = v; break;
    case WVO_LANGUAGE: s.lang = v; break;
    case WVO_PROXY: {
      std::wstring pv = Trim(v);
      if (!ValidProxy(pv)) {
        SetErr(WVERR_ARG, L"代理地址不能包含空格、引号或控制字符：" + pv);
        return 0;
      }
      s.proxy = pv;
      break;
    }
    case WVO_CODEPAGE: {  // 原来任何数都收下：无效的代码页会让此后返回的所有文本都变成空字符串
      std::wstring t = Trim(v);
      long cp = 0;
      bool ok = true;
      if (!t.empty()) {
        wchar_t* end = nullptr;
        cp = wcstol(t.c_str(), &end, 10);
        ok = end && *end == L'\0' && cp >= 0 && (cp == 0 || IsValidCodePage((UINT)cp));
      }
      if (!ok) {
        SetErr(WVERR_ARG, L"无效的代码页：" + t + L"（0 为系统默认，65001 为 UTF-8，936 为 GBK）");
        return 0;
      }
      CodePageVar() = (int)cp;
      break;
    }
    case WVO_LOG_FILE: s.logFile = v; break;
    case WVO_DISABLE_GPU: s.disableGpu = n; break;
    case WVO_AUTOPLAY: s.autoplay = n; break;
    case WVO_IGNORE_CERT_ERRORS: s.ignoreCert = n; break;
    case WVO_TRACKING_PREVENTION: s.tracking = v.empty() ? -1 : n; break;
    case WVO_SCROLLBAR_STYLE: s.scrollbar = n; break;
    case WVO_DEFAULT_BG: {  // 原来任何文本都收下：“#fff”会被当成透明，非十六进制会变成黑色
      std::wstring t = Trim(v);
      unsigned argb = 0;
      if (!t.empty() && !ParseBgColor(t, argb)) {
        SetErr(WVERR_ARG, L"默认背景色只支持 #RRGGBB、#AARRGGBB 或 transparent：" + t);
        return 0;
      }
      s.defaultBg = t;
      break;
    }
    case WVO_FALLBACK_UI: s.fallback = v.empty() ? 1 : n; break;
    case WVO_JSON_ESCAPE: {
      std::wstring t = Trim(v);
      if (t.empty()) t = L"0";
      if (t.size() != 1 || t[0] < L'0' || t[0] > L'2') {
        SetErr(WVERR_ARG, L"JSON 转义方式只能是 0、1 或 2：" + t);
        return 0;
      }
      s.jsonEscape = t[0] - L'0';
      break;
    }
    case WVO_CALLBACK_HOOK: {  // 十进制地址。与创建选项里的回调地址（ParsePtr）一样也接受负数：易语言 到文本 (到整数 (&子程序)) 在高地址时是负数
      std::wstring t = Trim(v);
      bool ok = t.size() <= 11;
      for (size_t k = 0; k < t.size(); ++k) ok = ok && ((t[k] >= L'0' && t[k] <= L'9') || (k == 0 && t[k] == L'-' && t.size() > 1));
      const long long a = ok && !t.empty() ? wcstoll(t.c_str(), nullptr, 10) : 0;
      if (!ok || a < -2147483648LL || a > 4294967295LL) {
        SetErr(WVERR_ARG, L"回调转发须是十进制地址：" + t);
        return 0;
      }
      s.callbackHook = reinterpret_cast<void*>(static_cast<uintptr_t>(static_cast<uint32_t>(a)));
      break;
    }
    case WVO_THREAD_TIMEOUT: {  // 空＝默认 10000；0＝一直等
      std::wstring t = Trim(v);
      if (t.empty()) {
        s.threadTimeout = 10000;
        break;
      }
      wchar_t* end = nullptr;
      const long long ms = wcstoll(t.c_str(), &end, 10);
      if (!end || *end != L'\0' || ms < 0 || ms > 0x7FFFFFFFLL) {
        SetErr(WVERR_ARG, L"跨线程调用的等待时间须是 0 到 2147483647 之间的毫秒数：" + t);
        return 0;
      }
      s.threadTimeout = (DWORD)ms;
      break;
    }
    case WVO_DEV_CHECKS: {
      std::wstring t = Trim(v);
      if (t.empty()) t = L"0";
      if (t.size() != 1 || t[0] < L'0' || t[0] > L'2') {
        SetErr(WVERR_ARG, L"开发期检查只能是 0、1 或 2：" + t);
        return 0;
      }
      DevChecks() = t[0] - L'0';
      break;
    }
    default: SetErr(WVERR_ARG, L"未知的选项编号"); return 0;
  }
  return 1;
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(const char*) WV_GetOption(int key) try { return Ret(OptionText(key)); } catch (...) { ExportFailed(__func__); return ""; }

WV_EXPORT(int) WV_RuntimeCheck(int rescan) try {
  ClearErr();
  RuntimeInfo r = FindRuntime(rescan != 0, std::wstring());
  if (!r.found) SetErr(WVERR_NO_RUNTIME, r.reason);
  return r.found ? 1 : 0;
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(const char*) WV_RuntimeInfo(void) try { return Ret(ToCPJson(RuntimeJson(FindRuntime(false, std::wstring())))); } catch (...) { ExportFailed(__func__); return ""; }

WV_EXPORT(const char*) WV_GetDiagnostics(void) try {
  std::wstring s = L"{\"bridge\":" + JsonStr(FromCP(WV_GetVersionText())) + L",\"module\":" + JsonStr(ModulePath(g_module)) +
                   L",\"appDir\":" + JsonStr(AppDir()) + L",\"runtime\":" + RuntimeJson(FindRuntime(false, std::wstring()));
  // 浏览器状态只在界面线程读取，避免与界面线程同时修改
  s += WithUi<std::wstring>(L",\"environments\":[],\"views\":[]", []() -> std::wstring {
    std::wstring r = L",\"environments\":" + EnvListJson() + L",\"views\":[";
    bool first = true;
    for (auto& v : AllViews()) {
      if (!first) r += L",";
      first = false;
      r += L"{\"id\":" + std::to_wstring(v->id) + L",\"state\":" + std::to_wstring(v->state) + L",\"url\":" + JsonStr(v->lastUrl) +
           L",\"error\":" + JsonStr(v->errMsg) + L"}";
    }
    return r + L"]";
  });
  s += L",\"jsonCache\":" + JsonCacheStatsJson();  // JSON取值 缓存的项数与原文字节数（每个线程最多 4 项）
  return Ret(ToCPJson(s + L",\"checks\":" + CheckStatsJson() + L"}"));
} catch (...) {
  ExportFailed(__func__);
  return "";
}

WV_EXPORT(const char*) WV_JsonQuote(const char* text) try { return Ret(ToCPJson(JsonStr(FromCP(text)))); } catch (...) { ExportFailed(__func__); return ""; }

// 源码里的文字常量：按系统 ANSI 代码页解释（约定如此，不受 WVO_CODEPAGE 影响），再把 \uXXXX 换成对应字符，按当前代码页返回。
// 易语言源码按 ANSI 保存，写不进 GBK 表示不了的韩文、表情等，用 \uXXXX 写；入参固定按 ANSI 解释，不会把恰好也是合法 UTF-8 的 GBK 文字读错
WV_EXPORT(const char*) WV_TextFromAnsi(const char* ansiText) try {
  ClearErr();
  return Ret(ToCP(DecodeUEscapes(FromAnsi(ansiText))));
} catch (...) {
  ExportFailed(__func__);
  return "";
}

WV_EXPORT(int) WV_InstallRuntime(int flags, int timeoutMs) try {
  const bool automatic = (flags & WVI_AUTO) != 0;  // 程序自动发起的安装：上次失败后 24 小时内直接失败，不再每次都等一遍下载
  return WithUi<int>(0, [&]() -> int {
    if (!CanWait()) return 0;  // 先检查再启动安装：不在“将要跳转”等回调里留下已开始的后台安装
    if (UiThread().load() == GetCurrentThreadId() && StartRuntimeInstall(automatic)) ShowInstallingOnAllViews();  // 卡片一起显示安装进度，不再提供第二个安装按钮
    if (!InstallRuntimeBlocking(Timeout(timeoutMs, 10 * 60 * 1000), automatic)) {
      SetErr(WVERR_INSTALL, LastInstallError());
      return 0;
    }
    RuntimeInfo r = FindRuntime(true, std::wstring());
    if (!r.found) {
      const std::wstring why = L"装好了常青版（或电脑上本来就有），但按当前的运行时设置仍没有可用的运行时：" + r.reason;
      RecordInstallFailure(why);  // 自动安装据此冷却：否则每次都要下载、运行一遍引导程序才回退
      SetErr(WVERR_INSTALL, why);
      return 0;
    }
    RecreateWaitingViews();
    return 1;
  });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

// 1.8.1：在后台发起安装，立即返回：不转交界面线程，也不等待。WV_InstallRuntime 在界面线程已登记后会把整个等待转交界面线程，从工作线程
// 调用时界面线程要在嵌套的消息循环里等到安装结束（最长几十分钟），期间程序的界面代码都在这层嵌套里运行。进度与结果用 WV_InstallState 查询
WV_EXPORT(int) WV_InstallRuntimeAsync(int flags) try {
  ClearErr();
  if (!StartRuntimeInstall((flags & WVI_AUTO) != 0)) {
    SetErr(WVERR_INSTALL, LastInstallError());
    return 0;
  }
  // 有等待运行时的浏览器时，让它们的卡片一起显示安装进度（与 WV_InstallRuntime 相同）：界面线程上直接做，别的线程只投递、不等
  if (UiThread().load() == GetCurrentThreadId()) {
    ShowInstallingOnAllViews();
  } else {
    HWND disp = Dispatcher().load();
    if (disp && IsWindow(disp)) PostMessageW(disp, WM_WV_SHOW_INSTALLING, 0, 0);
  }
  return 1;
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_InstallState(void) try {
  ClearErr();
  std::wstring err;
  const int st = InstallStateCode(err);
  if (st == WVIS_FAILED) SetErr(WVERR_INSTALL, err);
  return st;
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_LastErrorCode(void) try { return ErrCode(); } catch (...) { ExportFailed(__func__); return 0; }

WV_EXPORT(const char*) WV_LastError(void) try {
  std::wstring m = ErrMsg();
  if (ErrHr() != S_OK && m.find(L"0x") == std::wstring::npos) m += Fmt(L"（0x%08X）", (unsigned)ErrHr());
  return Ret(ToCP(m));
} catch (...) {
  ExportFailed(__func__);
  return "";
}

// ================================================================ 实例
WV_EXPORT(int) WV_Create(HWND parent, int x, int y, int w, int h, const char* url, const char* options, int timeoutMs) try {
  std::wstring u = FromCP(url), o = FromCPLines(options);
  return WithUi<int>(0, [&]() -> int { return CreateView(parent, x, y, w, h, u, o, nullptr, true, Timeout(timeoutMs, 30000)); });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_CreateAsync(HWND parent, int x, int y, int w, int h, const char* url, const char* options, void* onReady) try {
  std::wstring u = FromCP(url), o = FromCPLines(options);
  return WithUi<int>(0, [&]() -> int { return CreateView(parent, x, y, w, h, u, o, onReady, false, 0); });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_Destroy(int view) try {
  return WithView<int>(view, 0, [](View* v) -> int {
    v->Destroy();
    return 1;
  });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_IsReady(int view) try {
  RefPtr<View> v = FindView(view);
  if (!v || v->closing) return -1;
  return v->state == WV_STATE_READY ? 1 : v->state == WV_STATE_CREATING ? 0 : -1;
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_WaitReady(int view, int timeoutMs) try {
  return WithView<int>(view, 0, [&](View* v) -> int {
    if (!CanWait()) return 0;  // 在界面线程上检查：事件回调里不能等，同步等待已嵌套太深时也不再等
    RefPtr<View> hold(v);
    PumpUntil([v] { return v->state != WV_STATE_CREATING || v->closing; }, Timeout(timeoutMs, 30000));
    if (v->state == WV_STATE_READY) return 1;
    v->RequireReady();
    return 0;
  });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_GetWindow(int view, int which) try {
  return WithView<int>(view, 0, [&](View* v) -> int { return (int)(INT_PTR)(which == 1 ? v->parent : v->host); });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_SetBounds(int view, int x, int y, int w, int h) try {
  return WithView<int>(view, 0, [&](View* v) -> int {
    v->SetBounds(x, y, w, h);
    return 1;
  });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_Show(int view, int visible) try {
  return WithView<int>(view, 0, [&](View* v) -> int {
    v->SetVisible(visible != 0);
    return 1;
  });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_ShowProgress(int view, const char* title, const char* text, const char* status, int permille) try {
  const std::wstring t = FromCP(title), m = FromCP(text), s = FromCP(status);
  return WithView<int>(view, 0, [&](View* v) -> int {
    v->ShowHostProgress(t, m, s, permille);
    return 1;
  });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_SetParent(int view, HWND parent) try {
  return WithView<int>(view, 0, [&](View* v) -> int { return v->SetParentWindow(parent) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

// ================================================================ 导航
WV_EXPORT(int) WV_Navigate(int view, const char* url) try {
  std::wstring u = FromCP(url);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->Navigate(u) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_NavigateToString(int view, const char* html) try {
  std::wstring s = FromCP(html);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->NavigateHtml(s) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_NavigateEx(int view, const char* url, const char* method, const char* headers, const void* body, int bodyLen) try {
  std::wstring u = FromCP(url), m = FromCP(method), hd = FromCPLines(headers);  // 协议头每行一个，逐行转换
  return WithView<int>(view, 0, [&](View* v) -> int { return v->NavigateEx(u, m, hd, body, bodyLen) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_Command(int view, int cmd) try {
  return WithView<int>(view, 0, [&](View* v) -> int { return v->Command(cmd) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

// ================================================================ 脚本
WV_EXPORT(const char*) WV_ExecScript(int view, const char* js, int flags, int timeoutMs) try {
  std::wstring s = FromCP(js);
  std::string r = WithView<std::string>(view, std::string(), [&](View* v) -> std::string {
    std::wstring out;
    if (!v->ExecSync(s, flags, Timeout(timeoutMs, 15000), out)) return std::string();
    return (flags & WVX_UNWRAP) ? ToCP(out) : ToCPJson(out);
  });
  return Ret(r);
} catch (...) {
  ExportFailed(__func__);
  return "";
}

WV_EXPORT(int) WV_ExecScriptAsync(int view, const char* js, int flags, void* callback, int userData) try {
  std::wstring s = FromCP(js);
  // 1.8.2：WVX_POST——从别的线程调用时投递到界面线程按顺序执行后立即返回，不同步转交（界面线程正忙于等这个工作线程时避免互相等待）。
  // 界面线程自己调用、或没有界面线程时按原路同步执行。投递前先确认句柄有效，并在界面线程上重新查一次（投递期间可能已销毁）
  if ((flags & WVX_POST) && UiThread().load() && UiThread().load() != GetCurrentThreadId()) {
    RefPtr<View> v = FindView(view);
    if (!v || v->closing) {
      SetErr(WVERR_BAD_HANDLE, L"无效的浏览器句柄（未创建或已销毁）");
      return 0;
    }
    const int vid = view;
    const int f = flags & ~WVX_POST;
    if (!PostToUi([vid, s, f, callback, userData]() {
          RefPtr<View> v2 = FindView(vid);
          if (v2 && !v2->closing) v2->ExecAsync(s, f, callback, userData);
        })) {
      SetErr(WVERR_THREAD, L"界面线程不可用（窗口已销毁或界面线程已退出）");
      return 0;
    }
    ClearErr();
    return 1;
  }
  return WithView<int>(view, 0, [&](View* v) -> int { return v->ExecAsync(s, flags & ~WVX_POST, callback, userData) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(const char*) WV_AddInitScript(int view, const char* js) try {
  std::wstring s = FromCP(js);
  std::string r = WithView<std::string>(view, std::string(), [&](View* v) -> std::string {
    std::wstring id;
    return v->AddInitScript(s, 10000, id) ? ToCP(id) : std::string();
  });
  return Ret(r);
} catch (...) {
  ExportFailed(__func__);
  return "";
}

WV_EXPORT(int) WV_RemoveInitScript(int view, const char* id) try {
  std::wstring s = FromCP(id);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->RemoveInitScript(s) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(const char*) WV_Dom(int view, int action, const char* selector, const char* value, int timeoutMs) try {
  std::wstring sel = FromCP(selector), val = FromCP(value);
  std::string r = WithView<std::string>(view, std::string(), [&](View* v) -> std::string {
    std::wstring out;
    if (!v->Dom(action, sel, val, timeoutMs > 0 ? (DWORD)timeoutMs : 0, out)) return std::string();
    return action == WVD_GET_ALL_TEXT || action == WVD_RECT ? ToCPJson(out) : ToCP(out);
  });
  return Ret(r);
} catch (...) {
  ExportFailed(__func__);
  return "";
}

WV_EXPORT(int) WV_Input(int view, int kind, int x, int y, const char* text) try {
  std::wstring t = FromCP(text);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->Input(kind, x, y, t) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

// ================================================================ 消息与 JS 桥
WV_EXPORT(int) WV_PostMessage(int view, const char* text, int asJson) try {
  std::wstring t = FromCP(text);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->PostMsg(t, asJson != 0) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_Bind(int view, const char* name, void* callback) try {
  std::wstring n = Trim(FromCP(name));
  return WithView<int>(view, 0, [&](View* v) -> int {
    if (n.empty()) {
      SetErr(WVERR_ARG, L"函数名不能为空");
      return 0;
    }
    if (callback) {
      v->binds[n] = callback;
      v->EnsureBridge();  // 绑定时自动启用；解绑不启用（原来解绑也会把停用的 JS 桥重新打开）
    } else {
      v->binds.erase(n);
    }
    return 1;
  });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_BindReturn(int view, int callId, const char* result, int isError) try {
  std::wstring r = FromCP(result);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->BridgeReply(callId, isError == 0, isError ? r : (r.empty() ? std::wstring(L"null") : r)) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_Emit(int view, const char* eventName, const char* json) try {
  std::wstring n = FromCP(eventName), j = FromCP(json);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->Emit(n, j) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

// ================================================================ 事件
WV_EXPORT(int) WV_SetEvent(int view, int eventId, void* callback) try {
  return WithView<int>(view, 0, [&](View* v) -> int {
    const int ev = eventId & ~WVE_FLAG_NO_OUT;
    if (ev <= 0 || ev > WVE_MAX) {
      SetErr(WVERR_ARG, L"未知的事件编号");
      return 0;
    }
    v->SetEvent(ev, callback, (eventId & WVE_FLAG_NO_OUT) != 0);
    return 1;
  });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

static EventCtx* NeedCtx() {
  EventCtx* c = CurCtx();
  if (!c) SetErr(WVERR_NO_CONTEXT, L"只能在事件回调执行期间调用");
  return c;
}

WV_EXPORT(const char*) WV_EvGet(int key) try {
  ClearErr();
  EventCtx* c = NeedCtx();
  if (!c) return Ret(std::string());
  std::wstring v;
  auto it = c->s.find(key);
  if (it != c->s.end()) v = it->second;
  else if (c->n.count(key)) v = std::to_wstring(c->n[key]);
  else if (key == WVK_BODY) v = FromUtf8(reinterpret_cast<const char*>(c->body.data()), (int)c->body.size());
  else if (c->lazy) {
    v = c->lazy(key);
    c->s[key] = v;
  }
  bool json = key == WVK_HEADERS || key == WVK_RESP_HEADERS;
  return Ret(json ? ToCPJson(v) : ToCP(v));
} catch (...) {
  ExportFailed(__func__);
  return "";
}

WV_EXPORT(int) WV_EvGetInt(int key) try {
  ClearErr();
  EventCtx* c = NeedCtx();
  if (!c) return 0;
  auto it = c->n.find(key);
  if (it != c->n.end()) return it->second;
  auto s = c->s.find(key);
  return s != c->s.end() ? (int)wcstol(s->second.c_str(), nullptr, 10) : 0;
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

// 回填结果的键只在会读取它的事件里有效。原来用在别的事件的回调里时照样返回成功、却什么也不发生，例如在“加载完成”里调用
// 回调_置下载路径 ()、在绑定函数里调用 回调_置结果 () 想当返回值（应该用 回传 ()）。现在返回失败（WVERR_ARG）并说明它在哪个事件里才有效；
// 开发期检查为 1 时，每个“键 + 事件”只弹出一次说明。WV_EvSetResponse 原来就只在“拦截请求”里有效
static int SetterEvent(int key) {  // 会读取这个键的事件；-1：有回填参数的事件都读取；0：不限（未知的键照旧收下）
  switch (key) {
    case WVK_SET_HEADER:
    case WVK_REMOVE_HEADER:
    case WVK_SET_URL: return WVE_REQUEST;
    case WVK_SET_PATH: return WVE_DOWNLOAD_START;
    case WVK_SET_TEXT: return WVE_SCRIPT_DIALOG;
    case WVK_SET_USERNAME:
    case WVK_SET_PASSWORD: return WVE_AUTH;
    case WVK_TARGET_VIEW: return WVE_NEW_WINDOW;
    case WVK_SET_RESULT:
    case WVK_SET_RESULT_TEXT:
    case WVK_SET_ERROR:
    case WVK_DEFER: return WVE_JS_CALL;
    case WVK_RESULT:
    case WVK_CANCEL: return -1;
  }
  return 0;
}
static const wchar_t* SetterName(int key) {  // 易语言类里对应的方法
  switch (key) {
    case WVK_SET_HEADER: return L"回调_置请求头 ()";
    case WVK_REMOVE_HEADER: return L"回调_删请求头 ()";
    case WVK_SET_URL: return L"回调_改网址 ()";
    case WVK_SET_PATH: return L"回调_置下载路径 ()";
    case WVK_SET_TEXT: return L"回调_置对话框文本 ()";
    case WVK_SET_USERNAME:
    case WVK_SET_PASSWORD: return L"回调_置账号密码 ()";
    case WVK_TARGET_VIEW: return L"回调_新窗口装入 ()";
    case WVK_SET_RESULT: return L"回传 ()";
    case WVK_SET_RESULT_TEXT: return L"回传文本 ()";
    case WVK_SET_ERROR: return L"回传错误 ()";
    case WVK_DEFER: return L"延迟回传 ()";
    case WVK_RESULT: return L"回调_置结果 ()";
    case WVK_CANCEL: return L"回调_置取消 ()";
  }
  return L"";
}
static bool SetterAllowed(const EventCtx* c, int key) {
  const int want = SetterEvent(key);
  if (want == 0 || (want == -1 ? EvOutKind(c->type) != 0 : c->type == want)) return true;
  const std::wstring where = want == -1 ? std::wstring(L"将要跳转、新窗口、下载开始、权限请求、按键、对话框、认证、拦截请求、证书错误这些事件")
                                        : std::wstring(EventName(want));
  const std::wstring msg = Fmt(L"%ls只在%ls的回调里有效，在%ls的回调里调用不起作用（WVK 键 %d），已返回失败", SetterName(key), where.c_str(),
                               EventName(c->type), key);
  SetErr(WVERR_ARG, msg);
  DevNotice(L"setter:" + std::to_wstring(key) + L":" + std::to_wstring(c->type), msg);
  return false;
}

WV_EXPORT(int) WV_EvSet(int key, const char* value) try {
  ClearErr();
  EventCtx* c = NeedCtx();
  if (!c) return 0;
  if (!SetterAllowed(c, key)) return 0;
  std::wstring v = FromCP(value);
  if (key == WVK_SET_HEADER || key == WVK_REMOVE_HEADER) {
    std::wstring& cur = c->setS[key];
    if (!cur.empty()) cur += L"\n";
    cur += v;
  } else {
    c->setS[key] = v;
  }
  return 1;
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_EvSetInt(int key, int value) try {
  ClearErr();
  EventCtx* c = NeedCtx();
  if (!c) return 0;
  if (!SetterAllowed(c, key)) return 0;
  c->setN[key] = value;
  return 1;
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_EvGetData(int key, void** data, int* length) try {
  ClearErr();
  if (data) *data = nullptr;
  if (length) *length = 0;
  EventCtx* c = NeedCtx();
  if (!c) return 0;
  if (key != WVK_BODY) {
    SetErr(WVERR_ARG, L"只有 WVK_BODY 有二进制数据");
    return 0;
  }
  if (data) *data = c->body.empty() ? nullptr : c->body.data();
  if (length) *length = (int)c->body.size();
  return 1;
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

WV_EXPORT(int) WV_EvSetResponse(int status, const char* reason, const char* headers, const void* body, int length) try {
  ClearErr();
  EventCtx* c = NeedCtx();
  if (!c) return 0;
  if (c->type != WVE_REQUEST) {
    SetErr(WVERR_ARG, L"只能在“拦截请求”事件里设置响应");
    return 0;
  }
  // 先在局部变量里准备好全部内容，最后一次性写进事件上下文：转换文本失败（开发期检查遇到不是 UTF-8 的文本）或内存不足时，
  // 不留下设了一半的应答（原来先标记“已设置应答”再转换，转换失败时事件结束后照样按空内容应答）
  std::wstring reasonW = FromCP(reason);
  std::wstring h = ReplaceAll(ReplaceAll(FromCPLines(headers), L"\r\n", L"\n"), L"\n", L"\r\n");  // 应答头每行一个，逐行转换
  std::vector<unsigned char> bodyV;
  if (body && length > 0) bodyV.assign(static_cast<const unsigned char*>(body), static_cast<const unsigned char*>(body) + length);
  std::wstring lh = Lower(h);
  if (lh.find(L"text/") != std::wstring::npos || lh.find(L"json") != std::wstring::npos || lh.find(L"javascript") != std::wstring::npos)
    while (!bodyV.empty() && bodyV.back() == 0) bodyV.pop_back();  // 去掉文本结尾零字节
  c->respStatus = status > 0 ? status : 200;
  c->respReason.swap(reasonW);
  c->respHeaders.swap(h);
  c->respBody.swap(bodyV);
  c->hasResp = true;
  return 1;
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

// ================================================================ 属性
WV_EXPORT(int) WV_SetInt(int view, int prop, int value) try {
  return WithView<int>(view, 0, [&](View* v) -> int { return v->SetIntProp(prop, value) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}
WV_EXPORT(int) WV_GetInt(int view, int prop) try {
  return WithView<int>(view, 0, [&](View* v) -> int { return v->GetIntProp(prop); });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}
WV_EXPORT(int) WV_SetStr(int view, int prop, const char* value) try {
  std::wstring s = FromCPLines(value);  // 白名单、屏蔽列表可以每行一项：逐行转换，一行漏了转换只影响这一行
  return WithView<int>(view, 0, [&](View* v) -> int { return v->SetStrProp(prop, s) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}
WV_EXPORT(const char*) WV_GetStr(int view, int prop) try {
  return Ret(WithView<std::string>(view, std::string(), [&](View* v) -> std::string { return ToCP(v->GetStrProp(prop)); }));
} catch (...) {
  ExportFailed(__func__);
  return "";
}

// ================================================================ Cookie 与数据
WV_EXPORT(const char*) WV_GetCookies(int view, const char* url, int format) try {
  std::wstring u = FromCP(url);
  return Ret(WithView<std::string>(view, std::string(), [&](View* v) -> std::string {
    std::wstring out;
    if (!v->GetCookies(u, format, out)) return std::string();
    return format == 0 ? ToCPJson(out) : ToCP(out);
  }));
} catch (...) {
  ExportFailed(__func__);
  return "";
}
WV_EXPORT(int) WV_SetCookie(int view, const char* url, const char* name, const char* value, const char* domain, const char* path, int expires, int flags) try {
  std::wstring u = FromCP(url), n = FromCP(name), val = FromCP(value), d = FromCP(domain), p = FromCP(path);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->SetCookie(u, n, val, d, p, expires, flags) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}
WV_EXPORT(int) WV_SetCookieString(int view, const char* url, const char* cookies) try {
  std::wstring u = FromCP(url), c = FromCPLines(cookies);  // 可以每行一个 Cookie，逐行转换
  return WithView<int>(view, 0, [&](View* v) -> int { return v->SetCookieString(u, c) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}
WV_EXPORT(int) WV_DeleteCookies(int view, const char* url, const char* name) try {
  std::wstring u = FromCP(url), n = FromCP(name);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->DeleteCookies(u, n) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}
WV_EXPORT(int) WV_ClearData(int view, int kinds) try {
  return WithView<int>(view, 0, [&](View* v) -> int { return v->ClearData(kinds) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

// ================================================================ 截图与打印
WV_EXPORT(int) WV_Capture(int view, const char* filePath, int format, int fullPage) try {
  std::wstring p = FromCP(filePath);
  return WithView<int>(view, 0, [&](View* v) -> int {
    std::vector<unsigned char> d;
    if (!v->Capture(format, fullPage != 0, d)) return 0;
    std::wstring full = AppPath(p);
    if (!WriteFileBytes(full, d.data(), d.size())) {
      SetErr(WVERR_IO, L"保存截图失败：" + full);
      return 0;
    }
    return 1;
  });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}
WV_EXPORT(int) WV_CaptureToMemory(int view, int format, int fullPage, void** data, int* length) try {
  if (data) *data = nullptr;
  if (length) *length = 0;
  return WithView<int>(view, 0, [&](View* v) -> int {
    std::vector<unsigned char> d;
    if (!v->Capture(format, fullPage != 0, d)) return 0;
    void* p = HeapAlloc(GetProcessHeap(), 0, d.size());
    if (!p) {
      SetErr(WVERR_FAILED, L"内存不足");
      return 0;
    }
    memcpy(p, d.data(), d.size());
    if (data) *data = p;
    else HeapFree(GetProcessHeap(), 0, p);
    if (length) *length = (int)d.size();
    return 1;
  });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}
WV_EXPORT(int) WV_PrintToPdf(int view, const char* filePath, int landscape, int timeoutMs) try {
  std::wstring p = FromCP(filePath);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->PrintPdf(p, landscape != 0, Timeout(timeoutMs, 60000)) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

// ================================================================ DevTools 协议
WV_EXPORT(const char*) WV_CdpCall(int view, const char* method, const char* paramsJson, int timeoutMs) try {
  std::wstring m = FromCP(method), p = FromCP(paramsJson);
  return Ret(WithView<std::string>(view, std::string(), [&](View* v) -> std::string {
    std::wstring out;
    if (!v->CdpSync(m, p, Timeout(timeoutMs, 15000), out)) return std::string();
    return ToCPJson(out);
  }));
} catch (...) {
  ExportFailed(__func__);
  return "";
}
WV_EXPORT(int) WV_CdpSubscribe(int view, const char* eventName, int enable) try {
  std::wstring e = FromCP(eventName);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->CdpSubscribe(e, enable != 0) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

// ================================================================ 网络
WV_EXPORT(int) WV_AddRequestFilter(int view, const char* urlPattern, int resourceType) try {
  std::wstring p = FromCP(urlPattern);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->AddRequestFilter(p, resourceType) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}
WV_EXPORT(int) WV_RemoveRequestFilter(int view, const char* urlPattern, int resourceType) try {
  std::wstring p = FromCP(urlPattern);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->RemoveRequestFilter(p, resourceType) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}
WV_EXPORT(int) WV_SetResponseCapture(int view, const char* urlPatterns, int withBody) try {
  std::wstring p = FromCPLines(urlPatterns);  // 可以每行一项，逐行转换
  return WithView<int>(view, 0, [&](View* v) -> int { return v->SetResponseCapture(p, withBody != 0) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}
WV_EXPORT(int) WV_MapFolder(int view, const char* hostName, const char* folder, int accessKind) try {
  std::wstring hn = FromCP(hostName), f = FromCP(folder);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->MapFolder(hn, f, accessKind) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}
WV_EXPORT(int) WV_AddMemoryFile(int view, const char* url, const void* data, int length, const char* mimeType) try {
  std::wstring u = FromCP(url), m = FromCP(mimeType);
  return WithView<int>(view, 0, [&](View* v) -> int { return v->AddMemoryFile(u, data, length, m) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}
WV_EXPORT(int) WV_DownloadControl(int view, int downloadId, int action) try {
  return WithView<int>(view, 0, [&](View* v) -> int { return v->DownloadControl(downloadId, action) ? 1 : 0; });
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

// ================================================================ 其它
WV_EXPORT(int) WV_Free(void* p) try {
  if (!p) return 0;
  return HeapFree(GetProcessHeap(), 0, p) ? 1 : 0;
} catch (...) {
  ExportFailed(__func__);
  return 0;
}

// JSON取值 的解析缓存。逐个取数组成员、在绑定函数的回调里多次 取参数 时传进来的总是同一段 JSON，
// 每次整段重新解析会让逐个取完 n 个成员的总耗时随 n 的平方增长（4000 个成员、126 KB 时约 16 秒）。这里为每个线程记下最近解析过的几段（kJsonCachePerThread）的原始字节、
// 代码页与开发期检查开关，三者完全相同时直接用记下的解析结果：按字节比较，文本内容有任何不同都会重新解析。
// 记几段而不是一段：易语言里常见先用 JSON取值 取出一个成员、再从这个成员里取字段，两段 JSON 交替传入，只记一段时大段 JSON 每次都要重新解析
// （实测 2000 个成员这样取要 4.8 秒，同一段连续取只要 58 毫秒）
// 比较原文的开销仍与 JSON 的长度成正比，只是逐字节比较比解析快得多（Wine 实测 4000 个成员逐个取两个字段：31 秒降到 0.5 秒）。
// 解析结果约为原文的 9～10 倍（Wine 实测 1 MB 的 JSON 占约 9 MB）：所有线程合计最多 kJsonCacheBudget、
// 最多 kJsonCacheSlots 项，超出时先清掉最久没用的项。
// 缓存放在一张全局表里（按线程号分项），不放在线程局部变量里：易语言程序常用 线程_销毁 ()（TerminateThread）结束卡住的线程，
// 被强制结束的线程不执行线程局部变量的析构，原来每结束一个就漏掉它缓存的全部内存（1 MB 的 JSON 约 9 MB），总量额度也一直占着，
// 之后大段 JSON 就再也不缓存（实测结束 4 个线程漏掉约 36 MB）。现在线程正常结束时（DLL_THREAD_DETACH）立即释放它的一项，
// 被强制结束的线程留下的项在之后没取到缓存时查出来清掉、释放内存（最多每秒查一次）。
// 线程号会被新线程重用：表项照样按字节比较原文，不会取到别人的结果
namespace {
const size_t kJsonCacheBudget = 4u << 20;
// 一段最大就是合计的上限：内存最多时与“每段 1 MB、合计 4 MB”相同（合计一样），只是不再把 1～4 MB 的 JSON 排除在外。
// 原来超过 1 MB 就不缓存，逐个取 1.9 MB 的数组每次要 90 毫秒（Wine），取完 7 万个成员要一个半小时；缓存后每次只是一次逐字节比较
const size_t kJsonCacheMax = kJsonCacheBudget;
const size_t kJsonCacheSlots = 256;
const size_t kJsonCachePerThread = 4;  // 每个线程记下最近用过的几段：先取出一个成员、再取它的字段时两段 JSON 交替传入
struct JsonCacheEntry {
  std::string raw;
  int cp = 0;
  bool dev = false;
  JVal root;
  mutable std::atomic<unsigned long long> used{0};  // 最近一次使用的序号，清理时先清最小的
};
typedef std::shared_ptr<const JsonCacheEntry> JsonCacheRef;  // 正在用它的调用各持一份引用：被清掉时等这些调用结束才释放
struct JsonCacheSlot {
  DWORD tid;
  JsonCacheRef e;
};
struct JsonCacheTable {
  JsonCacheTable() { slots.reserve(kJsonCacheSlots); }  // 一次分配到上限：之后在锁内增删都不再分配内存
  Lock lock;
  std::vector<JsonCacheSlot> slots;
  size_t total = 0;  // 表里各项原文的字节数之和
  DWORD lastSweep = 0;  // 上一次查已结束线程的时间
  bool swept = false;
};
// 查已结束线程的最短间隔（毫秒）。每查一次要为表里每一项调用 OpenThread，线程多、JSON 又小时，每次没取到缓存都查会比解析本身还慢；
// 线程正常结束时已由 DLL_THREAD_DETACH 释放，这里只为被强制结束的线程兜底，隔一会儿查一次就够了
DWORD g_jsonSweepMs = 1000;
std::atomic<bool> g_jsonCacheUsed{false};  // 用过缓存才需要在线程结束时清理
std::atomic<unsigned long long> g_jsonTick{0};
JsonCacheTable& JsonCaches() {
  static JsonCacheTable t;
  return t;
}
bool ThreadGone(DWORD tid) {  // 线程已经结束（被强制结束的线程不经过 DLL_THREAD_DETACH，只能这样查）
  HANDLE h = OpenThread(SYNCHRONIZE, FALSE, tid);
  if (!h) return true;
  const bool gone = WaitForSingleObject(h, 0) == WAIT_OBJECT_0;
  CloseHandle(h);
  return gone;
}
// 从表里拿掉第 i 项，放进 dropped（调用方在锁外释放）
void JsonCacheTake(JsonCacheTable& t, size_t i, std::vector<JsonCacheRef>& dropped) {
  t.total -= t.slots[i].e->raw.size();
  dropped.push_back(std::move(t.slots[i].e));
  t.slots.erase(t.slots.begin() + (std::ptrdiff_t)i);
}
// 线程正常结束（在 DllMain 的 DLL_THREAD_DETACH 里调用）：释放它的各项。不分配内存、不抛出异常，释放在锁外进行
void JsonCacheDrop(DWORD tid) {
  if (!g_jsonCacheUsed.load()) return;
  JsonCacheRef dropped[kJsonCachePerThread];
  size_t n = 0;
  JsonCacheTable& t = JsonCaches();
  Guard g(t.lock);
  for (size_t i = t.slots.size(); i-- > 0 && n < kJsonCachePerThread;)
    if (t.slots[i].tid == tid) {
      t.total -= t.slots[i].e->raw.size();
      dropped[n++] = std::move(t.slots[i].e);
      t.slots.erase(t.slots.begin() + (std::ptrdiff_t)i);
    }
}
// 本线程记下的、与这段原文完全相同（代码页与开发期检查开关也相同）的解析结果。逐字节比较在锁外做
JsonCacheRef JsonCacheGet(DWORD tid, const char* src, size_t len, int cp, bool dev) {
  JsonCacheRef cand[kJsonCachePerThread];
  size_t n = 0;
  {
    JsonCacheTable& t = JsonCaches();
    Guard g(t.lock);
    for (const auto& s : t.slots)
      if (s.tid == tid && n < kJsonCachePerThread) cand[n++] = s.e;
  }
  for (size_t k = 0; k < n; ++k) {
    const JsonCacheEntry& e = *cand[k];
    if (e.cp == cp && e.dev == dev && e.raw.size() == len && memcmp(e.raw.data(), src, len) == 0) {
      e.used = ++g_jsonTick;
      return cand[k];
    }
  }
  return JsonCacheRef();
}
// 记下本线程的解析结果：本线程已有 kJsonCachePerThread 项时先清掉它最久没用的一项，超出总量或项数时再清掉全表最久没用的项。
// 清掉的项移到锁外释放（大段 JSON 的解析树释放要几毫秒，不让别的线程等）。锁内不分配、不释放内存：持锁时间只有微秒级，
// 也不会在持有这把锁时再去等堆的锁（线程在锁内被 TerminateThread 强制结束时，这把锁不会再释放；这是 TerminateThread 本身的风险，
// 在堆分配中途被结束同样会卡住整个进程的堆，所以只能让锁内的时间尽量短）
void JsonCachePut(DWORD tid, JsonCacheRef e) {
  e->used = ++g_jsonTick;
  std::vector<JsonCacheRef> dropped;
  dropped.reserve(kJsonCacheSlots + 1);  // 在锁外先分配好：内存不足时在这里抛出，表还没有改；锁内只做不分配内存的增删
  JsonCacheTable& t = JsonCaches();
  {
    Guard g(t.lock);
    // 距上次查过 g_jsonSweepMs 以上时，去掉已经结束的线程留下的项
    const DWORD now = GetTickCount();
    if (!t.swept || now - t.lastSweep >= g_jsonSweepMs) {
      t.lastSweep = now;
      t.swept = true;
      for (size_t i = t.slots.size(); i-- > 0;)
        if (t.slots[i].tid != tid && ThreadGone(t.slots[i].tid)) JsonCacheTake(t, i, dropped);
    }
    auto lruOf = [&](bool mineOnly) {  // 最久没用的一项；mineOnly 时只在本线程的项里找
      size_t best = t.slots.size();
      for (size_t i = 0; i < t.slots.size(); ++i)
        if ((!mineOnly || t.slots[i].tid == tid) && (best == t.slots.size() || t.slots[i].e->used.load() < t.slots[best].e->used.load())) best = i;
      return best;
    };
    size_t mine = 0;
    for (const auto& s : t.slots) mine += s.tid == tid;
    for (; mine >= kJsonCachePerThread; --mine) JsonCacheTake(t, lruOf(true), dropped);
    while (!t.slots.empty() && (t.total + e->raw.size() > kJsonCacheBudget || t.slots.size() >= kJsonCacheSlots)) JsonCacheTake(t, lruOf(false), dropped);
    t.total += e->raw.size();
    t.slots.push_back(JsonCacheSlot{tid, std::move(e)});
    g_jsonCacheUsed = true;
  }
}
std::wstring JsonCacheStatsJson() {
  size_t entries = 0, bytes = 0;
  if (g_jsonCacheUsed.load()) {
    JsonCacheTable& t = JsonCaches();
    Guard g(t.lock);  // 锁内只读两个数，文本在锁外拼
    entries = t.slots.size();
    bytes = t.total;
  }
  return L"{\"entries\":" + std::to_wstring(entries) + L",\"bytes\":" + std::to_wstring(bytes) + L"}";
}
// 路径里的一段键名：对象按键名取值；数组的 length 是成员数（与 JavaScript 相同，对象仍按键名取 length）
const JVal* JsonMember(const JVal* cur, const std::wstring& key, JVal& lengthOut) {
  if (cur->t == JVal::ARR && key == L"length") {
    lengthOut = JVal();
    lengthOut.t = JVal::NUM;
    lengthOut.n = (double)cur->a.size();
    lengthOut.s = std::to_wstring(cur->a.size());
    return &lengthOut;
  }
  return cur->Get(key.c_str());
}
}  // namespace

WV_EXPORT(const char*) WV_JsonGet(const char* json, const char* path) try {
  ClearErr();
  const char* src = json ? json : "";
  const size_t len = strlen(src);
  const int cp = CodePage();
  const bool dev = DevChecks().load() != 0;
  const DWORD tid = GetCurrentThreadId();
  JsonCacheRef hold = JsonCacheGet(tid, src, len, cp, dev);  // 本次调用期间一直持有，别的线程清掉这一项也不影响
  JVal parsed;
  const JVal* root = nullptr;
  if (hold) {
    root = &hold->root;
  } else {
    if (!JsonParse(FromCP(json), parsed)) {
      SetErr(WVERR_ARG, L"不是合法的 JSON");
      return Ret(std::string());
    }
    root = &parsed;
    if (len <= kJsonCacheMax) {
      try {
        auto e = std::make_shared<JsonCacheEntry>();
        e->raw.assign(src, len);
        e->cp = cp;
        e->dev = dev;
        e->root = std::move(parsed);
        root = &e->root;
        hold = e;
        JsonCachePut(tid, std::move(e));
      } catch (...) {  // 缓存只是加速：内存不足时这次不缓存，结果照常给出
        if (!hold) root = &parsed;
      }
    }
  }
  JVal lengthVal;
  const JVal* cur = root;
  std::wstring p = FromCP(path);
  size_t i = 0;
  while (cur && i < p.size()) {
    if (p[i] == L'.') { ++i; continue; }
    if (p[i] == L'[') {
      size_t e = p.find(L']', i);
      if (e == std::wstring::npos) { cur = nullptr; break; }
      std::wstring idx = Trim(p.substr(i + 1, e - i - 1));
      i = e + 1;
      if (idx.size() >= 2 && (idx[0] == L'"' || idx[0] == L'\'')) {
        cur = JsonMember(cur, idx.substr(1, idx.size() - 2), lengthVal);
      } else {
        // 下标只认非负十进制整数（两边可以有空格）；[abc]、[1.5]、[0x1]、[-1] 这类写法不是下标，按路径不存在处理，不当成第 0 项
        bool digits = !idx.empty() && idx.size() <= 9;
        for (wchar_t ch : idx) digits = digits && ch >= L'0' && ch <= L'9';
        const size_t n = digits ? (size_t)wcstoul(idx.c_str(), nullptr, 10) : 0;
        cur = (digits && cur->t == JVal::ARR && n < cur->a.size()) ? &cur->a[n] : nullptr;
      }
      continue;
    }
    size_t e = p.find_first_of(L".[", i);
    std::wstring key = p.substr(i, e == std::wstring::npos ? std::wstring::npos : e - i);
    i = e == std::wstring::npos ? p.size() : e;
    cur = JsonMember(cur, key, lengthVal);
  }
  if (!cur) {
    SetErr(WVERR_NOT_FOUND, L"JSON 中没有这个路径：" + p);
    return Ret(std::string());
  }
  // 字符串返回内容；其它（数字、true、false、null、对象、数组）返回 JSON 文本，与头文件说明一致
  return Ret(cur->t == JVal::STR ? ToCP(cur->s) : ToCPJson(cur->Dump()));
} catch (...) {
  ExportFailed(__func__);
  return "";
}
