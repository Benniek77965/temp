// wv_host.cpp : 宿主窗口、调度窗口、父窗口子类化、原生提示卡片（无运行时/启动失败/安装中）、全屏窗口
#include "wv_internal.h"
#include <cmath>

namespace wv {

const wchar_t* kHostClass = L"WV2BridgeHost";
const wchar_t* kFullClass = L"WV2BridgeFullscreen";
const wchar_t* kDispClass = L"WV2BridgeDispatch";

static LRESULT CALLBACK HostProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
static LRESULT CALLBACK FullProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
static LRESULT CALLBACK DispProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);

static bool DoRegisterClasses() {
  WNDCLASSEXW wc;
  ZeroMemory(&wc, sizeof(wc));
  wc.cbSize = sizeof(wc);
  wc.hInstance = g_module;
  wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
  wc.lpfnWndProc = HostProc;
  wc.lpszClassName = kHostClass;
  RegisterClassExW(&wc);
  wc.lpfnWndProc = FullProc;
  wc.lpszClassName = kFullClass;
  wc.hbrBackground = static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH));
  RegisterClassExW(&wc);
  wc.lpfnWndProc = DispProc;
  wc.lpszClassName = kDispClass;
  wc.hbrBackground = nullptr;
  RegisterClassExW(&wc);
  // 固定本 DLL：窗口过程、父窗口子类化、计时器都在本模块中，卸载后再有消息到达就会跳进已卸载的代码。
  // 运行库为带析构的 thread_local（编码转换缓存）登记线程退出回调时，也会在该线程存活期间持有本 DLL 的引用，
  // 但那只是附带效果；这里明确固定，不依赖它
  HMODULE self = nullptr;
  GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_PIN, reinterpret_cast<LPCWSTR>(g_module), &self);
  return true;
}

void RegisterClasses() {
  static const bool done = DoRegisterClasses();  // C++11 局部静态初始化是线程安全的，多个线程同时首次调用也只注册一次
  (void)done;
}

bool EnsureUiThread() {
  // 两个线程同时首次创建浏览器时只能登记一个界面线程：检查与登记必须在同一把锁内完成。
  // 锁内只有本线程的 CreateWindowEx（消息窗口），不会与其它线程互相等待
  static Lock lock;
  Guard g(lock);
  DWORD tid = GetCurrentThreadId();
  if (UiThread().load()) return true;
  HRESULT hr = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
  if (hr == RPC_E_CHANGED_MODE) {
    SetErr(WVERR_THREAD, L"当前线程已按 MTA 方式初始化 COM，WebView2 需要 STA（单线程套间）线程", hr);
    return false;
  }
  RegisterClasses();
  // 调度窗口承担其它线程转交的调用、安装结束的通知与开发期说明：建不出来时不登记界面线程，否则之后其它线程的调用无处转交
  HWND disp = CreateWindowExW(0, kDispClass, L"", 0, 0, 0, 0, 0, HWND_MESSAGE, nullptr, g_module, nullptr);
  if (!disp) {
    SetErr(WVERR_FAILED, L"创建调度窗口失败：" + HrText(HRESULT_FROM_WIN32(GetLastError())));
    return false;
  }
  Dispatcher() = disp;  // 先发布调度窗口再登记界面线程：看到界面线程已登记的线程一定也能看到调度窗口
  UiThread() = tid;
  Log(L"界面线程 #%u 初始化完成（%ls）", tid, Os().name.c_str());
  return true;
}

// 系统调进本 DLL 的入口（窗口过程、子类化过程）里的异常不能穿出去：外面是系统的消息分发，异常穿出去进程会直接结束。
// 投递的任务另有 RunTask 截住；这里兜住其余的消息处理（绘制、布局、按钮动作等），出错时按默认处理并写诊断日志
static void ProcFailed(const wchar_t* where) noexcept {
  try {
    Log(L"%ls处理消息时出现异常（可能是内存不足），已按默认处理", where);
  } catch (...) {
  }
}

static LRESULT DispProcBody(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  if (msg == WM_WV_INVOKE) {  // 消息参数是任务编号（TaskToken），不是本进程登记的就忽略
    if (std::function<void()>* f = TakeTask(lp, false)) RunTask(*f);
    return 1;
  }
  if (msg == WM_WV_TASK) {  // 投递给调度窗口的任务（例如开发期检查的说明框）：任务对象在堆上，由这里释放
    std::unique_ptr<std::function<void()>> f(TakeTask(lp, true));
    if (f) RunTask(*f);
    return 0;
  }
  if (msg == WM_WV_SHOW_INSTALLING) {  // 1.8.1：别的线程用 WV_InstallRuntimeAsync 发起了安装
    ShowInstallingOnAllViews();
    return 0;
  }
  if (msg == WM_WV_INSTALL_DONE) {  // 安装线程结束（见 StartRuntimeInstall）
    OnInstallFinishedUi(wp != 0);
    return 0;
  }
  return DefWindowProcW(hwnd, msg, wp, lp);
}
static LRESULT CALLBACK DispProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  try {
    return DispProcBody(hwnd, msg, wp, lp);
  } catch (...) {
    ProcFailed(L"调度窗口");
    return DefWindowProcW(hwnd, msg, wp, lp);
  }
}

// ---------------------------------------------------------------- 子类化（comctl32 动态取址，兼容 v5.82 按序号导出）
typedef LRESULT(CALLBACK* WvSubclassProc)(HWND, UINT, WPARAM, LPARAM, UINT_PTR, DWORD_PTR);
struct Comctl {
  BOOL(WINAPI* set)(HWND, WvSubclassProc, UINT_PTR, DWORD_PTR) = nullptr;
  BOOL(WINAPI* remove)(HWND, WvSubclassProc, UINT_PTR) = nullptr;
  LRESULT(WINAPI* def)(HWND, UINT, WPARAM, LPARAM) = nullptr;
};
static Comctl LoadComctl() {
  Comctl c;
  {
    HMODULE h = LoadSystemDll(L"comctl32.dll");
    if (h) {
      FARPROC a = GetProcAddress(h, "SetWindowSubclass");
      if (!a) a = GetProcAddress(h, MAKEINTRESOURCEA(410));
      FARPROC b = GetProcAddress(h, "RemoveWindowSubclass");
      if (!b) b = GetProcAddress(h, MAKEINTRESOURCEA(412));
      FARPROC d = GetProcAddress(h, "DefSubclassProc");
      if (!d) d = GetProcAddress(h, MAKEINTRESOURCEA(413));
      c.set = reinterpret_cast<decltype(c.set)>(reinterpret_cast<void*>(a));
      c.remove = reinterpret_cast<decltype(c.remove)>(reinterpret_cast<void*>(b));
      c.def = reinterpret_cast<decltype(c.def)>(reinterpret_cast<void*>(d));
    }
    if (!c.set || !c.remove || !c.def) Log(L"comctl32 子类化函数不可用：自动铺满与窗口移动通知将失效");
  }
  return c;
}
// 线程安全的一次性初始化：原先先置标志再取函数地址，另一个界面线程可能在中间读到空的函数指针
static Comctl& CC() {
  static Comctl c = LoadComctl();
  return c;
}

static LRESULT CALLBACK ParentSubProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp, UINT_PTR sid, DWORD_PTR ref);
static LRESULT ParentSubBody(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp, UINT_PTR sid, DWORD_PTR ref) {
  int vid = (int)ref;
  switch (msg) {
    case WM_SIZE:
    case WM_MOVE:
    case WM_WINDOWPOSCHANGED: {
      RefPtr<View> v = FindView(vid);
      if (v && !v->closing) {
        if (msg == WM_SIZE && hwnd == v->parent && v->fill && !v->isFull) v->Layout();
        if (msg == WM_SIZE && hwnd == v->top) {
          if (wp == SIZE_MINIMIZED) v->OnMinimize(true);
          else if (wp == SIZE_RESTORED || wp == SIZE_MAXIMIZED) v->OnMinimize(false);
        }
        if (hwnd == v->top && (msg == WM_MOVE || msg == WM_WINDOWPOSCHANGED)) v->NotifyMoved();
      }
      break;
    }
    case WM_SYSCOLORCHANGE:  // 系统配色、高对比度开关变了（只发给顶层窗口）：重画提示卡片，动画底图作废
    case WM_THEMECHANGED:
    case WM_SETTINGCHANGE: {
      RefPtr<View> v = FindView(vid);
      if (v && !v->closing && v->host && v->panel.mode) {
        v->panel.animValid = false;
        InvalidateRect(v->host, nullptr, FALSE);
      }
      break;
    }
    case WM_NCDESTROY:
      if (CC().remove) CC().remove(hwnd, ParentSubProc, sid);
      break;
  }
  return CC().def ? CC().def(hwnd, msg, wp, lp) : DefWindowProcW(hwnd, msg, wp, lp);
}
static LRESULT CALLBACK ParentSubProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp, UINT_PTR sid, DWORD_PTR ref) {  // 子类化的是程序自己的父窗口
  try {
    return ParentSubBody(hwnd, msg, wp, lp, sid, ref);
  } catch (...) {
    ProcFailed(L"父窗口子类化");
    return CC().def ? CC().def(hwnd, msg, wp, lp) : DefWindowProcW(hwnd, msg, wp, lp);
  }
}

bool HookParent(HWND hwnd, UINT_PTR id, int viewId) {
  if (!hwnd || !CC().set) return false;
  return CC().set(hwnd, ParentSubProc, id, (DWORD_PTR)viewId) != FALSE;
}
void UnhookParent(HWND hwnd, UINT_PTR id) {
  if (hwnd && IsWindow(hwnd) && CC().remove) CC().remove(hwnd, ParentSubProc, id);
}

// 读屏软件读的是窗口名称：把卡片内容写进宿主窗口的标题（子窗口的标题不会显示出来）。卡片上的按钮是自绘的，不是单独的可访问对象，
// 原来名称里只有卡片文字，用读屏软件的人不知道有哪些按钮、怎样操作。现在一并写出按钮、键盘操作方法与键盘当前选中的按钮；
// 选中的按钮改变时发出名称改变的通知，读屏软件读出新的名称
static void PanelAccName(View* v) {
  if (!v->host) return;
  const PanelState& p = v->panel;
  std::wstring name = p.mode == 1 ? std::wstring(L"正在启动网页组件") : p.mode >= 2 ? p.title + L"。" + p.message : std::wstring();
  if (v->PanelHasButtons()) {
    name += L"。按钮：";
    for (int i = 0; i < p.btnCount; ++i) name += (i ? L"、" : L"") + p.btnText[i];
    name += L"（用方向键选择，回车或空格执行）";
    if (p.focus >= 0 && p.focus < p.btnCount) name += L"。当前选中：" + p.btnText[p.focus];
  }
  wchar_t cur[2048] = {0};
  GetWindowTextW(v->host, cur, 2048);
  if (name == cur) return;
  SetWindowTextW(v->host, name.c_str());
  NotifyWinEvent(EVENT_OBJECT_NAMECHANGE, v->host, OBJID_CLIENT, CHILDID_SELF);
}

// ---------------------------------------------------------------- 宿主窗口
void DrainTasks(HWND h) {
  MSG m;
  while (h && PeekMessageW(&m, h, WM_WV_TASK, WM_WV_TASK, PM_REMOVE)) {
    std::unique_ptr<std::function<void()>> f(TakeTask(m.lParam, true));
    if (f) RunTask(*f);  // 浏览器已关闭：任务只会完成 Deferral，不再调用易语言回调
  }
}

static LRESULT HostProcBody(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  if (msg == WM_NCCREATE) {
    CREATESTRUCTW* cs = reinterpret_cast<CREATESTRUCTW*>(lp);
    SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(cs->lpCreateParams));
    return DefWindowProcW(hwnd, msg, wp, lp);
  }
  if (msg == WM_WV_INVOKE) {  // 消息参数是任务编号（TaskToken），不是本进程登记的就忽略
    if (std::function<void()>* f = TakeTask(lp, false)) RunTask(*f);
    return 1;
  }
  if (msg == WM_WV_TASK) {
    std::unique_ptr<std::function<void()>> f(TakeTask(lp, true));
    if (f) RunTask(*f);
    return 0;
  }
  if (msg == WM_DESTROY) {
    View* r0 = reinterpret_cast<View*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (r0) {
      RefPtr<View> v0(r0);
      SetWindowLongPtrW(hwnd, GWLP_USERDATA, 0);  // 之后的 WM_NCDESTROY 等消息不能再碰这个对象（它可能马上被释放）
      v0->OnHostDestroy();
    }
    DrainTasks(hwnd);
    return DefWindowProcW(hwnd, msg, wp, lp);
  }
  View* raw = reinterpret_cast<View*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
  if (!raw) return DefWindowProcW(hwnd, msg, wp, lp);
  RefPtr<View> v(raw);
  switch (msg) {
    case WM_ERASEBKGND:
      return 1;
    case WM_PAINT: {
      PAINTSTRUCT ps;
      HDC dc = BeginPaint(hwnd, &ps);
      v->Paint(dc);
      EndPaint(hwnd, &ps);
      return 0;
    }
    case WM_SIZE:
      v->OnHostSize();
      return 0;
    case WM_MOVE:  // 宿主在父窗口内移动时，网页的下拉框、输入法候选框位置也要跟着更新
      if (v->Ready()) v->NotifyMoved();
      return 0;
    case WM_SETFOCUS:
      v->OnHostFocus();
      if (v->PanelHasButtons()) {  // 卡片上的按钮可以用键盘操作：用 Tab 进入时从第一个（Shift+Tab 时从最后一个）开始
        bool tab = GetKeyState(VK_TAB) < 0;
        if (v->panel.focus < 0 || v->panel.focus >= v->panel.btnCount) v->panel.focus = tab && GetKeyState(VK_SHIFT) < 0 ? v->panel.btnCount - 1 : 0;
        if (tab) v->panel.kbd = true;
        PanelAccName(v.get());
        InvalidateRect(hwnd, nullptr, FALSE);
      }
      return 0;
    case WM_KILLFOCUS:
      if (v->PanelHasButtons()) InvalidateRect(hwnd, nullptr, FALSE);
      return 0;
    case WM_GETDLGCODE:
    case WM_KEYDOWN: {
      LRESULT r = 0;
      if (v->PanelKey(msg, wp, lp, r)) return r;
      break;
    }
    case WM_TIMER:
      if (wp == 3) {  // JS 桥脚本登记迟迟没有完成时，照常进行首次导航
        KillTimer(hwnd, 3);
        v->NavigateInitial();
        return 0;
      }
      v->OnTimer(wp);
      return 0;
    case WM_MOUSEMOVE:
    case WM_MOUSELEAVE:
    case WM_LBUTTONDOWN:
    case WM_LBUTTONUP:
    case WM_CAPTURECHANGED:
    case WM_SETCURSOR: {
      LRESULT r = 0;
      if (v->PanelMouse(msg, wp, lp, r)) return r;
      break;
    }
    case 0x02E3:  // WM_DPICHANGED_AFTERPARENT（Win10 1703 起）：每显示器 DPI 感知的程序拖到另一块屏幕上，宿主大小不变时也要按新 DPI 重画卡片
      v->panel.animValid = false;
      if (v->panel.mode) InvalidateRect(hwnd, nullptr, FALSE);
      break;
    case WM_WV_RECREATE:
      // wParam 1：运行时装好后的恢复，只重建仍在等待运行时的浏览器（同一次安装可能投递多次，已经在重建的不再重复）
      if (wp == 0 || v->state == WV_STATE_FAILED) v->Recreate();
      return 0;
    case WM_WV_FINISH_DESTROY:
      if (v->pendingDestroy && v->busy == 0) v->FinishDestroy();
      return 0;
    case WM_NCDESTROY:
      SetWindowLongPtrW(hwnd, GWLP_USERDATA, 0);
      break;
  }
  return DefWindowProcW(hwnd, msg, wp, lp);
}
static LRESULT CALLBACK HostProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  try {
    return HostProcBody(hwnd, msg, wp, lp);
  } catch (...) {
    ProcFailed(L"宿主窗口");
    return DefWindowProcW(hwnd, msg, wp, lp);
  }
}

static LRESULT FullProcBody(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  if (msg == WM_NCCREATE) {
    CREATESTRUCTW* cs = reinterpret_cast<CREATESTRUCTW*>(lp);
    SetWindowLongPtrW(hwnd, GWLP_USERDATA, (LONG_PTR)(INT_PTR)(intptr_t)cs->lpCreateParams);
    return DefWindowProcW(hwnd, msg, wp, lp);
  }
  int vid = (int)(INT_PTR)GetWindowLongPtrW(hwnd, GWLP_USERDATA);
  switch (msg) {
    case WM_SIZE: {
      HWND child = GetWindow(hwnd, GW_CHILD);
      if (child) SetWindowPos(child, nullptr, 0, 0, LOWORD(lp), HIWORD(lp), SWP_NOZORDER | SWP_NOACTIVATE);
      return 0;
    }
    case WM_CLOSE: {
      RefPtr<View> v = FindView(vid);
      if (v) v->Command(WVC_EXIT_FULLSCREEN);
      return 0;
    }
  }
  return DefWindowProcW(hwnd, msg, wp, lp);
}
static LRESULT CALLBACK FullProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  try {
    return FullProcBody(hwnd, msg, wp, lp);
  } catch (...) {
    ProcFailed(L"全屏窗口");
    return DefWindowProcW(hwnd, msg, wp, lp);
  }
}

// ---------------------------------------------------------------- 提示卡片
// 卡片画在一块 32 位位图上：圆角、柔和阴影、图标、转圈与进度条都按“像素中心到图形边界的距离”计算覆盖率，
// 任何 DPI 下边缘都平滑，不依赖 GDI+，也不需要放大几倍再缩小；位图只覆盖卡片附近，窗口其余部分直接填底色，
// 大窗口、高 DPI 也不占多少内存。文字用 GDI 画在同一块位图上
namespace {

typedef UINT(WINAPI* GetDpiForWindowFn)(HWND);

// Win10 1607 起按窗口所在显示器取 DPI（每显示器 DPI 感知的程序拖到另一块屏幕上，卡片大小也对）；更早的系统按设备上下文取
UINT WindowDpi(HWND h, HDC dc) {
  static const GetDpiForWindowFn fn =
      reinterpret_cast<GetDpiForWindowFn>(reinterpret_cast<void*>(GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetDpiForWindow")));
  UINT d = fn && h ? fn(h) : 0;
  if (!d && dc) d = (UINT)GetDeviceCaps(dc, LOGPIXELSY);
  return d >= 48 && d <= 960 ? d : 96;
}

inline float Clamp01(float v) { return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v); }
// 有符号距离（形状内部为负）→ 覆盖率：边界两侧各半个像素平滑过渡
inline float Cover(float d) { return Clamp01(0.5f - d); }
inline float SmoothStep(float a, float b, float x) {
  float t = Clamp01((x - a) / (b - a));
  return t * t * (3.0f - 2.0f * t);
}
inline uint32_t Px(COLORREF c) { return ((uint32_t)GetRValue(c) << 16) | ((uint32_t)GetGValue(c) << 8) | (uint32_t)GetBValue(c); }

COLORREF Mix(COLORREF a, COLORREF b, int pctB) {
  return RGB((GetRValue(a) * (100 - pctB) + GetRValue(b) * pctB) / 100, (GetGValue(a) * (100 - pctB) + GetGValue(b) * pctB) / 100,
             (GetBValue(a) * (100 - pctB) + GetBValue(b) * pctB) / 100);
}

struct RF {
  float l, t, r, b;
};
RF ToRF(const RECT& r) { return RF{(float)r.left, (float)r.top, (float)r.right, (float)r.bottom}; }
RF Inflate(RF r, float d) { return RF{r.l - d, r.t - d, r.r + d, r.b + d}; }

// 圆角矩形的有符号距离。只有圆角区域（两个方向都超出直边）才需要开方，直边部分直接相减
inline float SdRoundRect(float x, float y, const RF& r, float rad) {
  const float hw = (r.r - r.l) * 0.5f, hh = (r.b - r.t) * 0.5f;
  const float qx = std::fabs(x - (r.l + hw)) - (hw - rad), qy = std::fabs(y - (r.t + hh)) - (hh - rad);
  if (qx > 0.0f && qy > 0.0f) return std::sqrt(qx * qx + qy * qy) - rad;
  return std::max(qx, qy) - rad;
}
// 点到线段的距离
inline float SdSegment(float x, float y, float ax, float ay, float bx, float by) {
  float px = x - ax, py = y - ay, dx = bx - ax, dy = by - ay;
  float l2 = dx * dx + dy * dy;
  float t = l2 > 0.0f ? Clamp01((px * dx + py * dy) / l2) : 0.0f;
  float ex = px - dx * t, ey = py - dy * t;
  return std::sqrt(ex * ex + ey * ey);
}

class Canvas {
 public:
  Canvas(HDC ref, const RECT& r) : ox_(r.left), oy_(r.top), w_(r.right - r.left), h_(r.bottom - r.top) {
    if (w_ <= 0 || h_ <= 0) return;
    BITMAPINFO bi;
    ZeroMemory(&bi, sizeof(bi));
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w_;
    bi.bmiHeader.biHeight = -h_;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;
    void* bits = nullptr;
    dc_ = CreateCompatibleDC(ref);
    if (!dc_) return;
    bmp_ = CreateDIBSection(ref, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    if (!bmp_ || !bits) return;
    px_ = static_cast<uint32_t*>(bits);
    old_ = SelectObject(dc_, bmp_);
    SetViewportOrgEx(dc_, -ox_, -oy_, nullptr);  // GDI 文字直接按窗口坐标画
    SetBkMode(dc_, TRANSPARENT);
  }
  ~Canvas() {
    if (dc_) {
      if (old_) SelectObject(dc_, old_);
      DeleteDC(dc_);
    }
    if (bmp_) DeleteObject(bmp_);
  }
  Canvas(const Canvas&) = delete;
  Canvas& operator=(const Canvas&) = delete;
  bool Ok() const { return px_ != nullptr; }
  HDC Dc() const { return dc_; }
  void Fill(COLORREF c) {
    const uint32_t v = Px(c);
    for (size_t i = 0, n = (size_t)w_ * (size_t)h_; i < n; ++i) px_[i] = v;
  }
  // 窗口坐标 [l,r)×[t,b) 内逐像素混色，cov(x, y) 按像素中心返回 0～1 的覆盖率。
  // inner 不为空时，像素中心落在 inner 里的整段一次处理（solid 为真填满，为假跳过），只有边缘像素逐个计算：
  // 大块内部占了绝大多数像素，这样整张卡片重画从约 8 毫秒降到 1 毫秒左右
  template <class F>
  void Shade(float l, float t, float r, float b, COLORREF c, F cov, const RF* inner = nullptr, bool solidInner = false) {
    int x0 = std::max(0, (int)std::floor(l) - ox_), y0 = std::max(0, (int)std::floor(t) - oy_);
    int x1 = std::min(w_, (int)std::ceil(r) - ox_), y1 = std::min(h_, (int)std::ceil(b) - oy_);
    if (x0 >= x1 || y0 >= y1) return;
    GdiFlush();  // 之前的 GDI 绘制可能还在批处理队列里，直接写像素前先刷新
    const int icr = GetRValue(c), icg = GetGValue(c), icb = GetBValue(c);
    const uint32_t solid = Px(c);
    // 内部整段的列范围：像素中心 x+0.5 严格落在 (inner.l, inner.r) 之间
    int ix0 = x1, ix1 = x1;
    if (inner && inner->r > inner->l && inner->b > inner->t) {
      ix0 = std::max(x0, (int)std::floor(inner->l - (float)ox_ - 0.5f) + 1);
      ix1 = std::min(x1, (int)std::ceil(inner->r - (float)ox_ - 0.5f));
      if (ix0 >= ix1) ix0 = ix1 = x1;
    }
    for (int y = y0; y < y1; ++y) {
      uint32_t* row = px_ + (size_t)y * (size_t)w_;
      const float py = (float)(y + oy_) + 0.5f;
      const bool rowInner = ix0 < ix1 && py > inner->t && py < inner->b;
      for (int x = x0; x < x1; ++x) {
        if (rowInner && x == ix0) {
          if (solidInner) std::fill(row + ix0, row + ix1, solid);
          x = ix1 - 1;
          continue;
        }
        const float a = cov((float)(x + ox_) + 0.5f, py);
        if (a <= 0.003f) continue;
        if (a >= 0.997f) {
          row[x] = solid;
          continue;
        }
        // 只做一次浮点转整数（32 位 GCC 默认用 x87，浮点转整数很慢），三个通道用整数混合
        const int ai = (int)(a * 256.0f + 0.5f);
        const uint32_t d = row[x];
        const int dr = (int)((d >> 16) & 0xFF), dg = (int)((d >> 8) & 0xFF), db = (int)(d & 0xFF);
        row[x] = ((uint32_t)(dr + (((icr - dr) * ai + 128) >> 8)) << 16) | ((uint32_t)(dg + (((icg - dg) * ai + 128) >> 8)) << 8) |
                 (uint32_t)(db + (((icb - db) * ai + 128) >> 8));
      }
    }
  }
  // 透明背景时用来判断父窗口背景的深浅：隔几个像素取一个样就够
  COLORREF Average() {
    if (!px_) return RGB(255, 255, 255);
    GdiFlush();
    unsigned long long r = 0, g = 0, b = 0, n = 0;
    for (size_t i = 0, total = (size_t)w_ * (size_t)h_; i < total; i += 7, ++n) {
      r += (px_[i] >> 16) & 0xFF;
      g += (px_[i] >> 8) & 0xFF;
      b += px_[i] & 0xFF;
    }
    return n ? RGB((BYTE)(r / n), (BYTE)(g / n), (BYTE)(b / n)) : RGB(255, 255, 255);
  }
  // 取出 / 写回窗口坐标矩形内的像素（动画区域的底图）；矩形必须完全在画布内
  bool Grab(const RECT& r, std::vector<uint32_t>& out) {
    if (!Ok() || r.left < ox_ || r.top < oy_ || r.right > ox_ + w_ || r.bottom > oy_ + h_ || r.right <= r.left || r.bottom <= r.top) return false;
    GdiFlush();
    const int rw = r.right - r.left, rh = r.bottom - r.top;
    out.resize((size_t)rw * (size_t)rh);
    for (int y = 0; y < rh; ++y)
      memcpy(&out[(size_t)y * (size_t)rw], px_ + (size_t)(r.top - oy_ + y) * (size_t)w_ + (size_t)(r.left - ox_), (size_t)rw * 4);
    return true;
  }
  bool Put(const RECT& r, const std::vector<uint32_t>& in) {
    const int rw = r.right - r.left, rh = r.bottom - r.top;
    if (!Ok() || r.left < ox_ || r.top < oy_ || r.right > ox_ + w_ || r.bottom > oy_ + h_ || rw <= 0 || rh <= 0 ||
        in.size() != (size_t)rw * (size_t)rh)
      return false;
    GdiFlush();
    for (int y = 0; y < rh; ++y)
      memcpy(px_ + (size_t)(r.top - oy_ + y) * (size_t)w_ + (size_t)(r.left - ox_), &in[(size_t)y * (size_t)rw], (size_t)rw * 4);
    return true;
  }
  void Present(HDC dst) {
    if (!Ok()) return;
    GdiFlush();
    BitBlt(dst, ox_, oy_, w_, h_, dc_, ox_, oy_, SRCCOPY);
  }

 private:
  int ox_, oy_, w_, h_;
  HDC dc_ = nullptr;
  HBITMAP bmp_ = nullptr;
  HGDIOBJ old_ = nullptr;
  uint32_t* px_ = nullptr;
};

// 矩形向内收缩 m：收缩后的范围里，圆角矩形的覆盖率恒为 1（或描边恒为 0）
RF Shrink(const RF& r, float m) { return RF{r.l + m, r.t + m, r.r - m, r.b - m}; }

void FillRound(Canvas& cv, const RF& r, float rad, COLORREF c) {
  rad = std::max(0.0f, std::min(rad, std::min(r.r - r.l, r.b - r.t) * 0.5f));
  const RF inner = Shrink(r, rad + 1.0f);
  cv.Shade(r.l - 1, r.t - 1, r.r + 1, r.b + 1, c, [&](float x, float y) { return Cover(SdRoundRect(x, y, r, rad)); }, &inner, true);
}
// 描边画在形状内侧：外缘覆盖率减内缘覆盖率
void StrokeRound(Canvas& cv, const RF& r, float rad, float width, COLORREF c) {
  rad = std::max(0.0f, std::min(rad, std::min(r.r - r.l, r.b - r.t) * 0.5f));
  const RF inner = Shrink(r, rad + width + 1.0f);
  cv.Shade(r.l - 1, r.t - 1, r.r + 1, r.b + 1, c, [&](float x, float y) {
    float d = SdRoundRect(x, y, r, rad);
    return Cover(d) - Cover(d + width);
  }, &inner, false);
}
// 柔和阴影：卡片下移、外扩后按距离平滑衰减（近似高斯模糊的边缘）；卡片内部会被卡片盖住，跳过不算
void ShadowRound(Canvas& cv, const RF& card, float rad, float dy, float blur, float spread, COLORREF c, float maxA) {
  RF s = Inflate(card, spread);
  s.t += dy;
  s.b += dy;
  const float srad = std::max(0.0f, rad + spread), half = blur * 0.5f;
  const RF inner = Shrink(card, rad + 2.0f);  // 卡片内部会被卡片盖住，整段跳过
  cv.Shade(s.l - half - 1, s.t - half - 1, s.r + half + 1, s.b + half + 1, c, [&](float x, float y) {
    if (SdRoundRect(x, y, card, rad) < -1.5f) return 0.0f;
    return maxA * (1.0f - SmoothStep(-half, half, SdRoundRect(x, y, s, srad)));
  }, &inner, false);
}
void FillCircle(Canvas& cv, float cx, float cy, float rad, COLORREF c) {
  cv.Shade(cx - rad - 1, cy - rad - 1, cx + rad + 1, cy + rad + 1, c, [&](float x, float y) {
    float dx = x - cx, dy = y - cy;
    return Cover(std::sqrt(dx * dx + dy * dy) - rad);
  });
}
// 圆头线段
void Line(Canvas& cv, float ax, float ay, float bx, float by, float thick, COLORREF c) {
  const float h = thick * 0.5f;
  cv.Shade(std::min(ax, bx) - h - 1, std::min(ay, by) - h - 1, std::max(ax, bx) + h + 1, std::max(ay, by) + h + 1, c,
           [&](float x, float y) { return Cover(SdSegment(x, y, ax, ay, bx, by) - h); });
}
// 圆头圆弧：从 a0 顺时针（屏幕坐标里角度增大的方向）扫过 sweep 弧度
void Arc(Canvas& cv, float cx, float cy, float rad, float thick, float a0, float sweep, COLORREF c) {
  const float kTwoPi = 6.28318531f, h = thick * 0.5f;
  const float e0x = cx + rad * std::cos(a0), e0y = cy + rad * std::sin(a0);
  const float e1x = cx + rad * std::cos(a0 + sweep), e1y = cy + rad * std::sin(a0 + sweep);
  cv.Shade(cx - rad - h - 1, cy - rad - h - 1, cx + rad + h + 1, cy + rad + h + 1, c, [&](float x, float y) {
    float dx = x - cx, dy = y - cy, d;
    float rel = std::atan2(dy, dx) - a0;
    rel -= kTwoPi * std::floor(rel / kTwoPi);
    if (sweep >= kTwoPi || rel <= sweep) d = std::fabs(std::sqrt(dx * dx + dy * dy) - rad);
    else d = std::min(std::hypot(x - e0x, y - e0y), std::hypot(x - e1x, y - e1y));
    return Cover(d - h);
  });
}

// 图标：0 下载 1 提醒 2 错误 3 重新加载
void DrawIcon(Canvas& cv, const RECT& ic, int kind, COLORREF circle, COLORREF glyph) {
  const float D = (float)(ic.right - ic.left), cx = (float)ic.left + D * 0.5f, cy = (float)ic.top + D * 0.5f, t = D * 0.095f;
  FillCircle(cv, cx, cy, D * 0.5f, circle);
  switch (kind) {
    case 0:
      Line(cv, cx, cy - 0.24f * D, cx, cy + 0.10f * D, t, glyph);
      Line(cv, cx - 0.15f * D, cy - 0.03f * D, cx, cy + 0.12f * D, t, glyph);
      Line(cv, cx + 0.15f * D, cy - 0.03f * D, cx, cy + 0.12f * D, t, glyph);
      Line(cv, cx - 0.19f * D, cy + 0.27f * D, cx + 0.19f * D, cy + 0.27f * D, t, glyph);
      break;
    case 3: {
      const float r = 0.21f * D;
      Arc(cv, cx, cy, r, t, -0.5236f, 5.236f, glyph);  // 从右上方顺时针绕到正上方，留出右上角的缺口
      const float tx = cx + 0.07f * D, ty = cy - r;  // 箭头在正上方指向右侧的缺口
      Line(cv, tx - 0.11f * D, ty - 0.10f * D, tx, ty, t, glyph);
      Line(cv, tx - 0.11f * D, ty + 0.10f * D, tx, ty, t, glyph);
      break;
    }
    default:
      Line(cv, cx, cy - 0.23f * D, cx, cy + 0.05f * D, t * 1.1f, glyph);
      FillCircle(cv, cx, cy + 0.21f * D, t * 0.62f, glyph);
      break;
  }
}

struct Theme {
  bool dark;
  COLORREF bg, card, border, text, sub, faint, accent, onAccent, link, track, shadow;
};
// 高对比度主题：Windows 的无障碍要求自绘界面跟随高对比度配色。原来高对比度下照样按背景色画自己的浅色或深色卡片
// （带阴影和彩色图标），读不清；现在卡片改用系统配色（窗口底色与文字、选中色、超链接色、灰色文字），不画阴影，图标用文字色。
// g_testHighContrast 供测试把高对比度当成打开的
bool (*g_testHighContrast)() = nullptr;
bool HighContrastOn() {
  if (g_testHighContrast) return g_testHighContrast();
  HIGHCONTRASTW hc;
  ZeroMemory(&hc, sizeof(hc));
  hc.cbSize = sizeof(hc);
  return SystemParametersInfoW(SPI_GETHIGHCONTRAST, sizeof(hc), &hc, 0) && (hc.dwFlags & HCF_HIGHCONTRASTON) != 0;
}
// 配色都核对过对比度（WCAG AA）：正文与按钮文字不低于 4.5:1，按钮与卡片底色不低于 3:1
Theme MakeTheme(COLORREF bg, bool dark) {
  Theme t;
  if (HighContrastOn()) {
    t.bg = t.card = GetSysColor(COLOR_WINDOW);
    t.dark = (GetRValue(t.bg) * 299 + GetGValue(t.bg) * 587 + GetBValue(t.bg) * 114) / 1000 < 128;
    t.text = t.sub = t.border = GetSysColor(COLOR_WINDOWTEXT);
    t.faint = t.track = GetSysColor(COLOR_GRAYTEXT);
    t.accent = GetSysColor(COLOR_HIGHLIGHT);
    t.onAccent = GetSysColor(COLOR_HIGHLIGHTTEXT);
    t.link = GetSysColor(COLOR_HOTLIGHT);
    t.shadow = t.bg;  // 阴影画成底色，等于不画
    return t;
  }
  t.dark = dark;
  t.bg = bg;
  if (dark) {
    t.card = Mix(bg, RGB(255, 255, 255), 6);
    t.border = Mix(bg, RGB(255, 255, 255), 14);
    t.text = RGB(243, 244, 246);
    t.sub = RGB(203, 208, 216);
    t.faint = RGB(156, 163, 175);
    t.accent = RGB(138, 180, 248);  // 深色模式用浅蓝底配深色字：白字配饱和蓝在深色卡片上达不到对比度要求
    t.onAccent = RGB(16, 24, 40);
    t.link = RGB(138, 180, 248);
    t.track = Mix(t.card, RGB(255, 255, 255), 14);
    t.shadow = RGB(0, 0, 0);
  } else {
    t.card = RGB(255, 255, 255);
    t.border = RGB(229, 231, 235);
    t.text = RGB(17, 24, 39);
    t.sub = RGB(75, 85, 99);
    t.faint = RGB(107, 114, 128);
    t.accent = RGB(37, 99, 235);
    t.onAccent = RGB(255, 255, 255);
    t.link = RGB(37, 99, 235);
    t.track = RGB(229, 231, 235);
    t.shadow = RGB(15, 23, 42);
  }
  return t;
}

int CALLBACK FontFound(const LOGFONTW*, const TEXTMETRICW*, DWORD, LPARAM p) {
  *reinterpret_cast<bool*>(p) = true;
  return 0;
}
const wchar_t* UiFace() {
  static std::wstring face;
  if (!face.empty()) return face.c_str();
  const wchar_t* prefer[] = {L"Microsoft YaHei UI", L"Microsoft YaHei", L"Segoe UI", L"Tahoma"};
  HDC dc = GetDC(nullptr);
  for (const wchar_t* f : prefer) {
    LOGFONTW lf;
    ZeroMemory(&lf, sizeof(lf));
    lf.lfCharSet = DEFAULT_CHARSET;
    wcsncpy(lf.lfFaceName, f, LF_FACESIZE - 1);
    bool found = false;
    EnumFontFamiliesExW(dc, &lf, FontFound, reinterpret_cast<LPARAM>(&found), 0);
    if (found) {
      face = f;
      break;
    }
  }
  ReleaseDC(nullptr, dc);
  if (face.empty()) face = L"Tahoma";
  return face.c_str();
}
HFONT MakeFont(UINT dpi, int px, int weight, bool underline = false) {
  return CreateFontW(-MulDiv(px, (int)dpi, 96), 0, 0, 0, weight, FALSE, underline ? TRUE : FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                     CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, UiFace());
}
// 一次绘制用到的字体，绘制结束统一释放
struct Fonts {
  HFONT title, msg, det, btn, link, linkHot, status;
  explicit Fonts(UINT dpi)
      : title(MakeFont(dpi, 18, FW_BOLD)),
        msg(MakeFont(dpi, 14, FW_NORMAL)),
        det(MakeFont(dpi, 12, FW_NORMAL)),
        btn(MakeFont(dpi, 14, FW_SEMIBOLD)),
        link(MakeFont(dpi, 13, FW_NORMAL)),
        linkHot(MakeFont(dpi, 13, FW_NORMAL, true)),
        status(MakeFont(dpi, 13, FW_NORMAL)) {}
  ~Fonts() {
    HFONT all[] = {title, msg, det, btn, link, linkHot, status};
    for (HFONT f : all)
      if (f) DeleteObject(f);
  }
  Fonts(const Fonts&) = delete;
  Fonts& operator=(const Fonts&) = delete;
};

void FillSolid(HDC dc, const RECT& r, COLORREF c) {
  HBRUSH b = CreateSolidBrush(c);
  FillRect(dc, &r, b);
  DeleteObject(b);
}
inline bool IsDarkColor(COLORREF c) { return (GetRValue(c) * 299 + GetGValue(c) * 587 + GetBValue(c) * 114) / 1000 < 128; }

typedef HRESULT(WINAPI* DrawThemeParentBackgroundFn)(HWND, HDC, const RECT*);
// 透明背景：请父窗口把自己的背景画进来（透明子窗口的标准做法，父窗口会收到 WM_ERASEBKGND 与 WM_PRINTCLIENT）。
// 先铺一层界面底色，父窗口什么都不画时也不会是黑的；矩形总是传整个客户区，各系统实现都按子窗口坐标对齐，
// 实际只画到设备上下文当前的剪裁区与位图范围内
void PaintParentBg(HWND host, HDC dc) {
  static const DrawThemeParentBackgroundFn fn = []() -> DrawThemeParentBackgroundFn {
    HMODULE m = LoadSystemDll(L"uxtheme.dll");
    return m ? reinterpret_cast<DrawThemeParentBackgroundFn>(reinterpret_cast<void*>(GetProcAddress(m, "DrawThemeParentBackground"))) : nullptr;
  }();
  RECT cr;
  GetClientRect(host, &cr);
  FillSolid(dc, cr, GetSysColor(COLOR_3DFACE));
  if (fn && GetParent(host)) fn(host, dc, &cr);
}
// 背景：不透明时填底色，透明时画父窗口的背景
void FillBackdrop(HWND host, HDC dc, const RECT& r, COLORREF c, bool transparent) {
  if (transparent) PaintParentBg(host, dc);
  else FillSolid(dc, r, c);
}
// 位图之外的区域直接画背景（不进位图）
void FillOutside(HWND host, HDC dc, const RECT& all, const RECT& inner, COLORREF c, bool transparent) {
  int saved = SaveDC(dc);
  ExcludeClipRect(dc, inner.left, inner.top, inner.right, inner.bottom);
  FillBackdrop(host, dc, all, c, transparent);
  RestoreDC(dc, saved);
}
int TextHeight(HDC dc, HFONT f, const std::wstring& s, int width, UINT flags) {
  if (s.empty() || width <= 0) return 0;
  HGDIOBJ o = SelectObject(dc, f);
  RECT r = {0, 0, width, 0};
  DrawTextW(dc, s.c_str(), (int)s.size(), &r, flags | DT_CALCRECT);
  SelectObject(dc, o);
  return r.bottom;
}
int TextWidth(HDC dc, HFONT f, const std::wstring& s) {
  HGDIOBJ o = SelectObject(dc, f);
  SIZE sz = {0, 0};
  GetTextExtentPoint32W(dc, s.c_str(), (int)s.size(), &sz);
  SelectObject(dc, o);
  return sz.cx;
}
void Text(HDC dc, HFONT f, COLORREF c, const std::wstring& s, RECT r, UINT flags) {
  if (s.empty()) return;
  SelectObject(dc, f);
  SetTextColor(dc, c);
  DrawTextW(dc, s.c_str(), (int)s.size(), &r, flags | DT_NOPREFIX);
}

// ---------------------------------------------------------------- 文字排版
// GDI 的 DT_WORDBREAK 按西文单词断行：汉字与紧挨着的路径、数字会被当成一个“单词”整体挪到下一行，造成上一行很短、
// 下一行在单词中间硬断，还会把“）”“，”这类标点放到行首。这里自己断行：汉字之间都可以断，西文单词保持完整，
// 超出整行宽度的长串（如文件路径）优先在 \ / . - _ 之后断开；遵守中文禁则（行首不放闭合标点，行尾不放开括号）；
// 行距按字号放宽，读起来更松快
bool CjkLike(wchar_t c) {
  return (c >= 0x2E80 && c <= 0x9FFF) || (c >= 0xAC00 && c <= 0xD7AF) || (c >= 0xF900 && c <= 0xFAFF) || (c >= 0xFE30 && c <= 0xFE4F) ||
         (c >= 0xFF00 && c <= 0xFFEF) || (c >= 0x2018 && c <= 0x201F) || c == 0x2026 || c == 0x2014 || c == 0x00B7;
}
bool NoLineStart(const std::wstring& u) {
  return u.size() == 1 && wcschr(L"，。、；：？！）》」』】〕〉’”…·％,.;:?!)]}%", u[0]) != nullptr;
}
bool NoLineEnd(const std::wstring& u) { return u.size() == 1 && wcschr(L"（《「『【〔〈‘“([{", u[0]) != nullptr; }

struct TextBlock {
  std::vector<std::wstring> lines;
  int lineH = 0, advance = 0, height = 0;
};

int UnitWidth(HDC dc, const std::wstring& s) {
  SIZE sz = {0, 0};
  if (!s.empty()) GetTextExtentPoint32W(dc, s.c_str(), (int)s.size(), &sz);
  return sz.cx;
}

// 排版一段文字：maxW 为行宽（像素），linePct 为行距（字号的百分比，如 160）
TextBlock LayoutText(HDC dc, HFONT f, const std::wstring& s, int maxW, int fontPx, int linePct, UINT dpi) {
  TextBlock b;
  if (s.empty() || maxW <= 0) return b;
  HGDIOBJ old = SelectObject(dc, f);
  TEXTMETRICW tm;
  GetTextMetricsW(dc, &tm);
  b.lineH = tm.tmHeight;
  b.advance = std::max(b.lineH, MulDiv(fontPx * linePct, (int)dpi, 9600));
  // 切成断行单位：汉字与全角标点各自一个，西文单词（连续的非空白、非汉字字符）一个，空格一个，换行单独标记
  enum { kText, kSpace, kBreak };
  struct Unit {
    std::wstring t;
    int kind;
    int w;
  };
  std::vector<Unit> units;
  for (size_t i = 0; i < s.size();) {
    wchar_t c = s[i];
    if (c == L'\r' || c == L'\n') {
      i += (c == L'\r' && i + 1 < s.size() && s[i + 1] == L'\n') ? 2 : 1;
      units.push_back({std::wstring(), kBreak, 0});
    } else if (c == L' ' || c == L'\t') {
      units.push_back({L" ", kSpace, 0});
      ++i;
    } else if (CjkLike(c) || (c >= 0xD800 && c <= 0xDBFF)) {
      size_t n = (c >= 0xD800 && c <= 0xDBFF && i + 1 < s.size()) ? 2 : 1;  // 代理对（表情、扩展区汉字）保持完整
      units.push_back({s.substr(i, n), kText, 0});
      i += n;
    } else {
      size_t j = i;
      while (j < s.size() && s[j] != L' ' && s[j] != L'\t' && s[j] != L'\r' && s[j] != L'\n' && !CjkLike(s[j]) && !(s[j] >= 0xD800 && s[j] <= 0xDBFF)) ++j;
      units.push_back({s.substr(i, j - i), kText, 0});
      i = j;
    }
  }
  for (auto& u : units) u.w = u.kind == kText ? UnitWidth(dc, u.t) : u.kind == kSpace ? UnitWidth(dc, L" ") : 0;
  std::vector<Unit> line;
  int lineW = 0;
  auto flush = [&]() {
    while (!line.empty() && line.back().kind == kSpace) line.pop_back();
    std::wstring t;
    for (auto& u : line) t += u.t;
    b.lines.push_back(t);
    line.clear();
    lineW = 0;
  };
  for (size_t k = 0; k < units.size(); ++k) {
    Unit u = units[k];
    if (u.kind == kBreak) {
      flush();
      continue;
    }
    if (u.kind == kSpace && line.empty()) continue;  // 行首不留空格
    if (lineW + u.w <= maxW) {
      line.push_back(u);
      lineW += u.w;
      continue;
    }
    if (u.kind == kSpace) {  // 空格放不下：先留在行尾（换行时会去掉），由下一个文字单位按禁则决定在哪里换行
      line.push_back(u);
      lineW += u.w;
      continue;
    }
    if (u.w > maxW) {  // 比整行还宽的长串：先填满当前行剩余空间，再逐行切开，优先切在分隔符之后
      std::wstring rest = u.t;
      while (!rest.empty()) {
        int avail = maxW - lineW;
        INT fit = 0;
        SIZE sz;
        GetTextExtentExPointW(dc, rest.c_str(), (int)rest.size(), std::max(avail, 0), &fit, nullptr, &sz);
        if (fit >= (int)rest.size()) {
          line.push_back({rest, kText, UnitWidth(dc, rest)});
          lineW += line.back().w;
          break;
        }
        if (fit <= 0) {
          if (line.empty()) fit = 1;  // 一个字符都放不下也要前进，避免死循环
          else {
            flush();
            continue;
          }
        }
        int cut = fit;
        for (int p = fit; p > fit / 2 && p > 0; --p)
          if (wcschr(L"\\/.-_", rest[(size_t)(p - 1)])) {
            cut = p;
            break;
          }
        line.push_back({rest.substr(0, (size_t)cut), kText, 0});
        flush();
        rest = rest.substr((size_t)cut);
      }
      continue;
    }
    // 正常换行，遵守禁则：行首不放闭合标点、行尾不放开括号——把当前行末尾的单位一起带到下一行。
    // 判断时跳过空格（“WebView2 ）”里的空格不能让“）”落到行首），每次至少带走一个文字单位，当前行至少留一个
    // 当前行只有一个文字单位，没法把它带到下一行：闭合标点悬挂在行尾（略超出行宽，中文排版的常规做法），
    // 行尾只有一个开括号时也把下一个字留在本行，不让开括号孤零零留在行尾
    {
      int texts = 0;
      const Unit* last = nullptr;
      for (auto& c : line)
        if (c.kind == kText) {
          last = &c;
          ++texts;
        }
      if (texts <= 1 && (NoLineStart(u.t) || (last && NoLineEnd(last->t)))) {
        line.push_back(u);
        lineW += u.w;
        continue;
      }
    }
    std::vector<Unit> carry;
    carry.push_back(u);
    for (;;) {
      const Unit* first = nullptr;
      for (auto& c : carry)
        if (c.kind == kText) {
          first = &c;
          break;
        }
      const Unit* last = nullptr;
      int texts = 0;
      for (auto& c : line)
        if (c.kind == kText) {
          last = &c;
          ++texts;
        }
      if (texts <= 1 || !((first && NoLineStart(first->t)) || (last && NoLineEnd(last->t)))) break;
      while (!line.empty()) {
        Unit m = line.back();
        line.pop_back();
        lineW -= m.w;
        carry.insert(carry.begin(), m);
        if (m.kind == kText) break;
      }
    }
    flush();
    for (auto& c : carry) {
      if (c.kind == kSpace && line.empty()) continue;
      line.push_back(c);
      lineW += c.w;
    }
  }
  if (!line.empty()) flush();
  while (!b.lines.empty() && b.lines.back().empty()) b.lines.pop_back();
  SelectObject(dc, old);
  b.height = b.lines.empty() ? 0 : (int)(b.lines.size() - 1) * b.advance + b.lineH;
  return b;
}

void DrawBlock(HDC dc, HFONT f, COLORREF c, const TextBlock& b, int x, int y, int w, bool center) {
  SelectObject(dc, f);
  SetTextColor(dc, c);
  for (size_t i = 0; i < b.lines.size(); ++i) {
    RECT r = {x, y + (int)i * b.advance, x + w, y + (int)i * b.advance + b.lineH};
    DrawTextW(dc, b.lines[i].c_str(), (int)b.lines[i].size(), &r, DT_SINGLELINE | DT_NOPREFIX | DT_NOCLIP | (center ? DT_CENTER : DT_LEFT));
  }
}

// 启动转圈：浅色整圈作底，一段主色圆弧匀速旋转（约 0.9 秒一圈）
void DrawSpinner(Canvas& cv, const PanelState& p) {
  Arc(cv, p.spinX, p.spinY, p.spinR, p.spinT, 0.0f, 6.28318531f, p.animTrack);
  Arc(cv, p.spinX, p.spinY, p.spinR, p.spinT, -1.5708f + (float)(p.tick % 22) * (6.28318531f / 22.0f), 1.75f, p.animFg);
}
// 安装进度条：知道下载大小时按百分比，其余阶段来回滑动表示“正在进行”
void DrawProgress(Canvas& cv, const PanelState& p, int permille) {
  const RF bar = ToRF(p.bar);
  const float W = bar.r - bar.l, H = bar.b - bar.t;
  if (W <= 0 || H <= 0) return;
  if (permille >= 0) {
    float fw = std::max(H, W * (float)std::min(permille, 1000) / 1000.0f);
    FillRound(cv, RF{bar.l, bar.t, bar.l + fw, bar.b}, H * 0.5f, p.animFg);
    return;
  }
  const int period = 40;  // 1.6 秒走一趟
  float ph = (float)(p.tick % period) / (float)period;
  ph = ph < 0.5f ? 2 * ph * ph : 1 - 2 * (1 - ph) * (1 - ph);  // 两头慢中间快
  const float seg = W * 0.32f, x0 = bar.l - seg + (W + seg) * ph;
  RF s{std::max(bar.l, x0), bar.t, std::min(bar.r, x0 + seg), bar.b};
  if (s.r - s.l > 1.0f) FillRound(cv, s, H * 0.5f, p.animFg);
}

void PaintStarting(View& v, HDC dc, const RECT& rc, UINT dpi, Theme th, bool transparent) {
  PanelState& p = v.panel;
  if (!p.slowShown) {  // 前 1.2 秒什么也不画：内核很快就绪时不闪一下加载提示
    FillBackdrop(v.host, dc, rc, th.bg, transparent);
    return;
  }
  const int D = MulDiv(30, (int)dpi, 96), gap = MulDiv(14, (int)dpi, 96), pad = MulDiv(8, (int)dpi, 96);
  Fonts f(dpi);
  const std::wstring t1 = L"正在启动网页组件", t2 = p.hintShown ? L"第一次启动会慢一些，请稍候" : L"";
  const int t1w = TextWidth(dc, f.status, t1), t1h = TextHeight(dc, f.status, t1, 10000, DT_SINGLELINE);
  const int t2w = t2.empty() ? 0 : TextWidth(dc, f.det, t2), t2h = t2.empty() ? 0 : TextHeight(dc, f.det, t2, 10000, DT_SINGLELINE);
  const int blockH = D + gap + t1h + (t2h ? MulDiv(4, (int)dpi, 96) + t2h : 0), blockW = std::max(D, std::max(t1w, t2w));
  const int cx = (int)rc.right / 2, top = std::max(0, ((int)rc.bottom - blockH) / 2);
  RECT content = {cx - blockW / 2 - pad, top - pad, cx + blockW / 2 + pad, top + blockH + pad};
  IntersectRect(&content, &content, &rc);
  Canvas cv(dc, content);
  if (!cv.Ok()) {
    FillBackdrop(v.host, dc, rc, th.bg, transparent);
    return;
  }
  if (transparent) {  // 先画出父窗口的背景，再按它的深浅选样式
    PaintParentBg(v.host, cv.Dc());
    const COLORREF avg = cv.Average();
    th = MakeTheme(avg, IsDarkColor(avg));
  } else {
    cv.Fill(th.bg);
  }
  p.spinX = (float)cx;
  p.spinY = (float)top + (float)D * 0.5f;
  p.spinT = MulDiv(3, (int)dpi, 96) > 2 ? (float)MulDiv(3, (int)dpi, 96) : 2.5f;
  p.spinR = (float)D * 0.5f - p.spinT * 0.5f - 0.5f;
  p.anim = {cx - D / 2 - 1, top - 1, cx + D / 2 + 2, top + D + 2};
  p.animFg = th.accent;
  p.animTrack = Mix(th.bg, th.text, 12);
  p.animValid = cv.Grab(p.anim, p.animBg);
  DrawSpinner(cv, p);
  HDC m = cv.Dc();
  Text(m, f.status, th.faint, t1, RECT{cx - t1w / 2 - 2, top + D + gap, cx + t1w / 2 + 2, top + D + gap + t1h}, DT_CENTER | DT_SINGLELINE);
  if (t2h) {
    int y2 = top + D + gap + t1h + MulDiv(4, (int)dpi, 96);
    Text(m, f.det, th.faint, t2, RECT{cx - t2w / 2 - 2, y2, cx + t2w / 2 + 2, y2 + t2h}, DT_CENTER | DT_SINGLELINE);
  }
  FillOutside(v.host, dc, rc, content, th.bg, transparent);
  cv.Present(dc);
}

void PaintCard(View& v, HDC dc, const RECT& rc, UINT dpi, Theme th, bool transparent) {
  PanelState& p = v.panel;
  for (RECT& r : p.btn) SetRectEmpty(&r);  // 下面没画出来的按钮不能还按旧位置响应鼠标
  auto Si = [dpi](int x) { return MulDiv(x, (int)dpi, 96); };
  const int w = rc.right, h = rc.bottom;
  const bool narrow = w < Si(360);
  const int pad = narrow ? Si(18) : Si(28), icon = Si(44), gap = Si(14), btnH = Si(36), btnGap = Si(8), radius = Si(14);
  int cardW = std::min(Si(540), w - Si(32));
  if (cardW < Si(240)) cardW = std::max(w - Si(8), 10);
  const int innerW = cardW - pad * 2;
  if (innerW < Si(40) || h < Si(40)) {  // 太小放不下卡片：只画背景
    p.hot = p.pressed = -1;
    FillBackdrop(v.host, dc, rc, th.bg, transparent);
    return;
  }
  Fonts f(dpi);
  const TextBlock tTitle = LayoutText(dc, f.title, p.title, innerW - icon - gap, 18, 135, dpi);
  const TextBlock tMsg = LayoutText(dc, f.msg, p.message, innerW, 14, 165, dpi);
  const TextBlock tDet = LayoutText(dc, f.det, p.detail, innerW, 12, 155, dpi);
  const int titleH = tTitle.height, msgH = tMsg.height, detH = tDet.height;
  const int rowH = std::max(icon, titleH);
  int stage = 0, permille = -1;
  std::wstring status;
  if (p.mode == 3) status = v.InstallStatusText(&stage, &permille);
  const TextBlock tStatus = LayoutText(dc, f.status, status, innerW, 13, 150, dpi);
  const int barH = Si(6), statusH = p.mode == 3 ? tStatus.height : 0;
  // 按钮：主按钮、次要按钮从左往右排，放不下就换行；文字链接靠右放在最后一行，放不下另起一行
  int bw[3] = {0, 0, 0}, bx[3] = {0, 0, 0}, brow[3] = {0, 0, 0}, rows = 0, cur = 0;
  for (int i = 0; i < p.btnCount; ++i) {
    bw[i] = p.btnStyle[i] == 2 ? TextWidth(dc, f.link, p.btnText[i]) + Si(12) : std::max(Si(96), TextWidth(dc, f.btn, p.btnText[i]) + Si(36));
    bw[i] = std::min(bw[i], innerW);
  }
  for (int i = 0; i < p.btnCount; ++i) {
    if (!rows) rows = 1;
    if (p.btnStyle[i] == 2) {
      if (cur > 0 && cur + bw[i] > innerW) {
        ++rows;
        cur = 0;
      }
      bx[i] = cur > 0 ? innerW - bw[i] : 0;
      brow[i] = rows - 1;
      cur = innerW + 1;
      continue;
    }
    if (cur > 0 && cur + bw[i] > innerW) {
      ++rows;
      cur = 0;
    }
    bx[i] = cur;
    brow[i] = rows - 1;
    cur += bw[i] + Si(10);
  }
  const int buttonsH = rows ? rows * btnH + (rows - 1) * btnGap : 0;
  const int cardH = pad + rowH + (msgH ? Si(10) + msgH : 0) + (detH ? Si(8) + detH : 0) + (p.mode == 3 ? Si(20) + barH + Si(10) + statusH : 0) +
                    (rows ? Si(24) + buttonsH : 0) + pad;
  const int x = (w - cardW) / 2, y = std::max(Si(12), (h - cardH) / 2 - Si(8));
  const RECT card = {x, y, x + cardW, y + cardH};
  RECT content = {x - Si(40), y - Si(24), x + cardW + Si(40), y + cardH + Si(48)};
  IntersectRect(&content, &content, &rc);
  Canvas cv(dc, content);
  if (!cv.Ok()) {
    p.hot = p.pressed = -1;
    FillBackdrop(v.host, dc, rc, th.bg, transparent);
    return;
  }
  if (transparent) {
    PaintParentBg(v.host, cv.Dc());
    const COLORREF avg = cv.Average();
    th = MakeTheme(avg, IsDarkColor(avg));
  } else {
    cv.Fill(th.bg);
  }
  const RF cardF = ToRF(card);
  const float rad = (float)radius;
  // 两层阴影：大范围的淡阴影衬出层次，贴边的细阴影勾出轮廓
  ShadowRound(cv, cardF, rad, (float)Si(12), (float)Si(32), (float)-Si(6), th.shadow, th.dark ? 0.45f : 0.10f);
  ShadowRound(cv, cardF, rad, (float)Si(1), (float)Si(3), 0.0f, th.shadow, th.dark ? 0.30f : 0.07f);
  FillRound(cv, cardF, rad, th.card);
  StrokeRound(cv, cardF, rad, std::max(1.0f, (float)dpi / 96.0f), th.border);
  // 图标与标题
  const RECT ic = {x + pad, y + pad + (rowH - icon) / 2, x + pad + icon, y + pad + (rowH - icon) / 2 + icon};
  COLORREF circle = th.accent, glyph = th.onAccent;
  if (p.icon == 1 || p.icon == 3) {
    circle = RGB(245, 158, 11);
    glyph = RGB(31, 41, 55);
  } else if (p.icon == 2) {
    circle = RGB(239, 68, 68);
    glyph = RGB(255, 255, 255);
  }
  if (HighContrastOn()) {  // 高对比度：图标用文字色，提醒与错误靠图形区分（感叹号、叉号），不靠颜色
    circle = th.text;
    glyph = th.card;
  }
  DrawIcon(cv, ic, p.icon, circle, glyph);
  // 进度条底槽（静态部分）；记下它的像素作为动画底图
  int cy = y + pad + rowH + (msgH ? Si(10) + msgH : 0) + (detH ? Si(8) + detH : 0);
  if (p.mode == 3) {
    p.bar = {x + pad, cy + Si(20), x + cardW - pad, cy + Si(20) + barH};
    FillRound(cv, ToRF(p.bar), (float)barH * 0.5f, th.track);
    p.anim = p.bar;
    p.animFg = th.accent;
    p.animTrack = th.track;
    p.animValid = cv.Grab(p.anim, p.animBg);
    DrawProgress(cv, p, permille);
  }
  // 按钮
  const int by = card.bottom - pad - buttonsH;
  for (int i = 0; i < p.btnCount; ++i) {
    RECT br = {x + pad + bx[i], by + brow[i] * (btnH + btnGap), x + pad + bx[i] + bw[i], by + brow[i] * (btnH + btnGap) + btnH};
    p.btn[i] = br;
    const bool hot = p.hot == i, down = p.pressed == i && hot;
    const RF bf = ToRF(br);
    const float brad = (float)Si(9);
    if (p.btnStyle[i] == 0) {
      FillRound(cv, bf, brad, down ? Mix(th.accent, th.dark ? RGB(255, 255, 255) : RGB(0, 0, 0), 24)
                                   : hot ? Mix(th.accent, th.dark ? RGB(255, 255, 255) : RGB(0, 0, 0), 13) : th.accent);
    } else if (p.btnStyle[i] == 1) {
      FillRound(cv, bf, brad, down ? Mix(th.card, th.text, 12) : hot ? Mix(th.card, th.text, 6) : th.card);
      StrokeRound(cv, bf, brad, std::max(1.0f, (float)dpi / 96.0f), th.border);
    }
    if (p.focus == i && p.kbd && GetFocus() == v.host)  // 键盘操作时的焦点框
      StrokeRound(cv, Inflate(bf, (float)Si(3)), brad + (float)Si(3), std::max(2.0f, 2.0f * (float)dpi / 96.0f), th.accent);
  }
  // 文字（画在所有图形之后）
  HDC m = cv.Dc();
  DrawBlock(m, f.title, th.text, tTitle, ic.right + gap, y + pad + (rowH - titleH) / 2, innerW - icon - gap, false);
  int ty = y + pad + rowH;
  if (msgH) {
    ty += Si(10);
    DrawBlock(m, f.msg, th.sub, tMsg, x + pad, ty, innerW, false);
    ty += msgH;
  }
  if (detH) {
    ty += Si(8);
    DrawBlock(m, f.det, th.faint, tDet, x + pad, ty, innerW, false);
  }
  if (p.mode == 3) {
    DrawBlock(m, f.status, th.faint, tStatus, x + pad, p.bar.bottom + Si(10), innerW, false);
    p.statusShown = status;
  }
  for (int i = 0; i < p.btnCount; ++i) {
    const bool hot = p.hot == i, down = p.pressed == i && hot;
    COLORREF tc = p.btnStyle[i] == 0 ? th.onAccent : p.btnStyle[i] == 1 ? th.text : (down ? Mix(th.link, th.text, 30) : th.link);
    Text(m, p.btnStyle[i] == 2 ? (hot ? f.linkHot : f.link) : f.btn, tc, p.btnText[i], p.btn[i], DT_CENTER | DT_VCENTER | DT_SINGLELINE);
  }
  FillOutside(v.host, dc, rc, content, th.bg, transparent);
  cv.Present(dc);
}

bool CopyText(HWND owner, const std::wstring& s) {
  if (!OpenClipboard(owner)) return false;
  EmptyClipboard();
  size_t bytes = (s.size() + 1) * sizeof(wchar_t);
  HGLOBAL g = GlobalAlloc(GMEM_MOVEABLE, bytes);
  bool ok = false;
  if (g) {
    void* p = GlobalLock(g);
    if (p) {
      memcpy(p, s.c_str(), bytes);
      GlobalUnlock(g);
      ok = SetClipboardData(CF_UNICODETEXT, g) != nullptr;
    }
    if (!ok) GlobalFree(g);
  }
  CloseClipboard();
  return ok;
}

// 选择运行时所在的文件夹：用 Vista 起的新式文件夹对话框（与系统其它对话框风格一致），不可用时退回旧式“浏览文件夹”。
// 用户取消返回假
bool PickFolder(HWND owner, std::wstring& out) {
  static const CLSID kClsidFileOpenDialog = {0xdc1c5a9c, 0xe88a, 0x4dde, {0xa5, 0xa1, 0x60, 0xf8, 0x2a, 0x20, 0xae, 0xf7}};
  static const IID kIidFileOpenDialog = {0xd57c7288, 0xd4ad, 0x4768, {0xbe, 0x02, 0x9d, 0x96, 0x95, 0x32, 0xd9, 0x60}};
  const wchar_t* title = L"选择 WebView2 运行时所在的文件夹（可以选它的上级文件夹）";
  out.clear();
  IFileOpenDialog* dlg = nullptr;
  if (SUCCEEDED(CoCreateInstance(kClsidFileOpenDialog, nullptr, CLSCTX_INPROC_SERVER, kIidFileOpenDialog, reinterpret_cast<void**>(&dlg))) && dlg) {
    DWORD opt = 0;
    dlg->GetOptions(&opt);
    dlg->SetOptions(opt | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM | FOS_PATHMUSTEXIST | FOS_NOCHANGEDIR);
    dlg->SetTitle(title);
    if (SUCCEEDED(dlg->Show(owner))) {
      IShellItem* item = nullptr;
      if (SUCCEEDED(dlg->GetResult(&item)) && item) {
        LPWSTR path = nullptr;
        if (SUCCEEDED(item->GetDisplayName(SIGDN_FILESYSPATH, &path)) && path) {
          out = path;
          CoTaskMemFree(path);
        }
        item->Release();
      }
    }
    dlg->Release();
    return !out.empty();
  }
  BROWSEINFOW bi;
  ZeroMemory(&bi, sizeof(bi));
  bi.hwndOwner = owner;
  bi.lpszTitle = title;
  bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
  LPITEMIDLIST pidl = SHBrowseForFolderW(&bi);
  if (!pidl) return false;
  wchar_t path[MAX_PATH] = {0};
  BOOL got = SHGetPathFromIDListW(pidl, path);
  CoTaskMemFree(pidl);
  if (got) out = path;
  return !out.empty();
}

}  // namespace

void RecreateWaitingViews() {
  for (auto& o : AllViews())
    if (!o->closing && o->host && o->state == WV_STATE_FAILED &&
        (o->errCode == WVERR_NO_RUNTIME || o->errCode == WVERR_INSTALL || o->panel.mode == 3))
      PostMessageW(o->host, WM_WV_RECREATE, 1, 0);
}

unsigned View::BgArgb() const {
  auto it = iprops.find(WVP_BG_COLOR);
  if (it != iprops.end()) return (unsigned)it->second;
  std::wstring d;
  {
    Guard g(GLock());
    d = G().defaultBg;
  }
  unsigned argb = 0xFFFFFFFFu;
  if (!d.empty()) ParseBgColor(d, argb);  // 与交给 WebView2 的默认背景色同一个解析（原来这里不认 transparent，透明时画成白色）
  return argb;
}
COLORREF View::BgRef() const {
  const unsigned argb = BgArgb();
  return RGB((argb >> 16) & 0xFF, (argb >> 8) & 0xFF, argb & 0xFF);
}
bool View::BgTransparent() const { return (BgArgb() >> 24) == 0; }
bool View::IsDarkBg() const { return IsDarkColor(BgRef()); }

void View::Paint(HDC dc) {
  RECT rc;
  GetClientRect(host, &rc);
  if (rc.right <= 0 || rc.bottom <= 0) return;
  const UINT dpi = WindowDpi(host, dc);
  const Theme th = MakeTheme(BgRef(), IsDarkBg());
  // 透明背景（置背景色 的“透明”、默认背景色 transparent）：网页透明处露出的是这里画的内容，要画父窗口的背景，
  // 原来画成黑色（或白色）。卡片按父窗口背景的实际深浅选样式
  const bool transparent = BgTransparent();
  panel.animValid = false;
  if (panel.mode == 1) PaintStarting(*this, dc, rc, dpi, th, transparent);
  else if (panel.mode >= 2) PaintCard(*this, dc, rc, dpi, th, transparent);
  else FillBackdrop(host, dc, rc, th.bg, transparent);
}

// 动画帧：还原动画区域的底图，只重画转圈或进度条，不重画整张卡片
void View::PaintAnim(HDC dc) {
  if (!panel.animValid) return;
  Canvas cv(dc, panel.anim);
  if (!cv.Put(panel.anim, panel.animBg)) return;
  if (panel.mode == 1) DrawSpinner(cv, panel);
  else if (panel.mode == 3) {
    int stage = 0, permille = -1;
    InstallStatusText(&stage, &permille);
    DrawProgress(cv, panel, permille);
  }
  cv.Present(dc);
}

std::wstring View::InstallStatusText(int* stageOut, int* permilleOut) {
  if (hostProgress && panel.mode == 3) {  // 程序自己的进度卡片：状态与进度由程序给出（按“下载”阶段画：有进度时画进度条，没有时画动画）
    if (stageOut) *stageOut = 1;
    if (permilleOut) *permilleOut = hostPermille;
    return hostStatus.empty() ? std::wstring(L"请稍候…") : hostStatus;
  }
  int stage = 0, permille = -1;
  DWORD elapsed = 0;
  const bool running = InstallStatus(stage, permille, elapsed);
  if (stageOut) *stageOut = stage;
  if (permilleOut) *permilleOut = running ? permille : -1;
  if (!running) return L"正在完成…";
  const unsigned sec = elapsed / 1000;
  switch (stage) {
    case 1:
      if (UseLegacyOfflinePackage()) return permille >= 0 ? Fmt(L"正在下载 109 版离线安装包（约 132MB） · %d%%", permille / 10) : std::wstring(L"正在下载 109 版离线安装包（约 132MB）…");
      return permille >= 0 ? Fmt(L"正在下载安装程序 · %d%%", permille / 10) : std::wstring(L"正在下载安装程序…");
    case 2: return UseLegacyOfflinePackage() ? L"正在校验安装包（大小、SHA-1 与微软数字签名）…" : L"正在校验微软数字签名…";
    case 3: return Fmt(L"正在安装 · 已用 %u:%02u · 通常需要 1～3 分钟", sec / 60, sec % 60);
    case 4: return L"正在等待另一个程序完成安装…";
  }
  return L"正在准备…";
}

void View::SetPanel(int mode) {
  panel.mode = mode;
  panel.detail.clear();  // 详情只属于当前这次失败，不能沿用上一次的
  panel.hot = panel.pressed = -1;
  panel.focus = host && GetFocus() == host ? 0 : -1;
  panel.btnCount = 0;
  panel.slowShown = panel.hintShown = false;
  panel.animValid = false;
  std::vector<uint32_t>().swap(panel.animBg);
  panel.statusShown.clear();
  panel.tick = 0;
  if (!host) return;
  KillTimer(host, 1);
  KillTimer(host, 2);
  KillTimer(host, 4);
  if (mode == 1) SetTimer(host, 2, 1200, nullptr);
  if (mode == 3) SetTimer(host, 1, 40, nullptr);
  auto add = [this](const wchar_t* t, int action, int style) {
    panel.btnText[panel.btnCount] = t;
    panel.btnAction[panel.btnCount] = action;
    panel.btnStyle[panel.btnCount] = style;
    ++panel.btnCount;
  };
  if (mode == 4) {
    panel.icon = 3;
    panel.title = L"页面意外关闭了";
    panel.message = L"网页内核意外退出了，点“重新加载”就能恢复。";
    add(L"重新加载", PA_RETRY, 0);
    add(L"复制诊断信息", PA_COPY, 2);
  } else if (mode == 2) {
    if (errCode == WVERR_NO_RUNTIME) {
      if (errRestartInstalled) {  // 电脑上装好的运行时在本进程里已失效：重新安装装的还是它（运行时客户端仍记着失败），换别的运行时文件夹或重启程序
        panel.icon = 1;
        panel.title = L"网页组件要重新启动程序才能用";
        panel.message = L"电脑上装好的 WebView2 运行时在本次运行中启动失败了（原因见下方），它会记住这次失败，要重新启动程序才能再用；也可以选择别的运行时文件夹。";
        add(L"选择运行时文件夹", PA_PICK_DIR, 0);
      } else if (InstallCanHelp()) {  // Win7/8/8.1 也能一键安装：用微软更新目录里的 109 版离线安装包
        panel.icon = errBroken ? 1 : 0;
        panel.title = errRestart ? L"网页组件要重新启动程序才能用" : errNetwork ? L"网页组件放在了网络位置" : errBroken ? L"网页组件的文件有问题" : L"还差一步：安装网页组件";
        // 一键安装会做什么：Win7/8/8.1 下载约 132MB 的 109 版离线安装包，别的系统下载微软的在线安装程序
        const std::wstring how = UseLegacyOfflinePackage() ? L"点“一键安装”会从微软更新目录下载 Windows 7/8/8.1 能用的 109 版离线安装包（约 132MB）并安装，装好后页面会自动打开"
                                                           : L"点“一键安装”会从微软官网下载并安装官方运行时，大约 1～3 分钟，装好后页面会自动打开";
        panel.message = errRestart   ? std::wstring(L"这个 WebView2 运行时在本次运行中启动失败了（原因见下方），它会记住这次失败，要重新启动程序才能再用。点“一键安装”会装上微软官方运行时，装好后不用重启，页面会自动打开。")
                        : errNetwork   ? L"找到的 WebView2 固定版运行时放在共享文件夹或网络驱动器上（原因见下方），微软说明固定版不能从网络位置运行。" + how + L"；也可以把它复制到本机磁盘后点“重新检测”。"
                        : errBroken    ? L"找到的 WebView2 运行时缺少文件或已经损坏（原因见下方）。" + how + L"。"
                        : UseLegacyOfflinePackage()
                            ? L"这个程序用微软 Edge WebView2 显示页面。点“一键安装”会从微软更新目录下载 Windows 7/8/8.1 能用的 109 版离线安装包（约 132MB）并自动安装，装好后页面会自动打开。"
                            : L"这个程序用微软 Edge WebView2 显示页面。点“一键安装”会从微软官网下载并自动安装，大约 1～3 分钟，装好后页面会自动打开。";
        add(L"一键安装", PA_INSTALL, 0);
        if (errBroken && !errRestart) add(L"重新检测", PA_RECHECK, 1);  // 修好运行时文件后重新检测（运行时客户端没有记住失败，不用重启）
        else add(L"选择运行时文件夹", PA_PICK_DIR, 1);  // 本进程里已失效时“重新检测”帮不上：别的运行时文件夹是另一个客户端，本次运行就能用
      } else if (Os().legacy) {
        panel.icon = 1;
        panel.title = errRestart ? L"网页组件要重新启动程序才能用" : errNetwork ? L"网页组件放在了网络位置" : errBroken ? L"网页组件的文件有问题" : L"还差一步：放好 Win7 专用的网页组件";
        panel.message = errRestart ? L"这个 109 版 WebView2 运行时在本次运行中启动失败了（原因见下方），它会记住这次失败，要重新启动程序才能再用；也可以选择别的运行时文件夹。"
                        : errNetwork ? L"找到的 109 版 WebView2 固定版运行时放在共享文件夹或网络驱动器上（原因见下方），微软说明固定版不能从网络位置运行。把它复制到本机磁盘（例如程序目录下的 WebView2 文件夹）后点“重新检测”，也可以手动选择别的运行时文件夹。"
                        : errBroken ? L"找到的 109 版 WebView2 运行时缺少文件或已经损坏（原因见下方）。修复或重新解压后点“重新检测”，也可以手动选择别的运行时文件夹。"
                        : (Os().major == 6 && Os().minor == 0) || (Os().major != 0 && Os().major < 6)
                            ? L"WebView2 需要 Windows 7 或更新的系统，这台电脑的系统太旧，装不了也用不了 WebView2 运行时。"
                            : L"Windows 7/8/8.1 需要 109 版 WebView2 固定版运行时（32 位，通常随程序一起提供）。把它解压到程序目录下的 WebView2 文件夹后点“重新检测”，也可以手动选择它所在的文件夹。";
        if (!errRestart) add(L"重新检测", PA_RECHECK, 0);
        add(L"选择运行时文件夹", PA_PICK_DIR, errRestart ? 0 : 1);
      } else {  // 只用固定版运行时：装系统里的常青版不起作用，不提供一键安装
        panel.icon = 1;
        panel.title = errRestart ? L"网页组件要重新启动程序才能用" : errNetwork ? L"网页组件放在了网络位置" : errBroken ? L"网页组件的文件有问题" : L"还差一步：放好网页组件";
        panel.message = errRestart ? L"这个程序设置为使用随程序提供的 WebView2 固定版运行时，它在本次运行中启动失败了（原因见下方），会记住这次失败，要重新启动程序才能再用；也可以选择别的运行时文件夹。"
                        : errNetwork ? L"这个程序设置为使用随程序提供的 WebView2 固定版运行时，找到的运行时放在共享文件夹或网络驱动器上（原因见下方），微软说明固定版不能从网络位置运行。把它复制到本机磁盘后点“重新检测”，也可以手动选择别的运行时文件夹。"
                        : errBroken ? L"这个程序设置为使用随程序提供的 WebView2 固定版运行时，找到的运行时缺少文件或已经损坏（原因见下方）。修复或重新放好后点“重新检测”，也可以手动选择别的运行时文件夹。"
                                  : L"这个程序设置为使用随程序提供的 WebView2 固定版运行时，但没有找到它。把运行时放到程序指定的位置（默认是程序目录下的 WebView2 文件夹）后点“重新检测”，也可以手动选择它所在的文件夹。";
        if (!errRestart) add(L"重新检测", PA_RECHECK, 0);
        add(L"选择运行时文件夹", PA_PICK_DIR, errRestart ? 0 : 1);
      }
      add(L"复制诊断信息", PA_COPY, 2);
      if (!errPlain) panel.detail = errMsg;  // 位数不符、版本过高等情况需要说明；单纯没找到时上面的说明已经够了
    } else if (errCode == WVERR_INSTALL) {
      panel.icon = 2;
      panel.title = L"安装没有完成";
      panel.message = errMsg;
      add(L"重试安装", PA_INSTALL, 0);
      add(L"选择运行时文件夹", PA_PICK_DIR, 1);
      add(L"复制诊断信息", PA_COPY, 2);
    } else {
      panel.icon = 2;
      panel.title = L"网页组件没能启动";
      panel.message = errMsg;
      add(L"重试", PA_RETRY, 0);
      add(L"复制诊断信息", PA_COPY, 2);
      if (errHr != S_OK) panel.detail = HrText(errHr);
    }
    if (recheckPending && errCode == WVERR_NO_RUNTIME) {  // 刚点了“重新检测”仍然没有找到：说明已经检测过，免得以为按钮没反应
      SYSTEMTIME st;
      GetLocalTime(&st);
      std::wstring note = Fmt(L"%02u:%02u:%02u 已重新检测，仍未找到可用的运行时。", st.wHour, st.wMinute, st.wSecond);
      panel.detail = panel.detail.empty() ? note : note + L"\r\n" + panel.detail;
    }
    recheckPending = false;  // 找到了运行时但随后因别的原因失败时，不能再说“仍未找到”
  } else if (mode == 3 && hostProgress) {  // 程序自己的准备工作（WV_ShowProgress）
    panel.icon = 0;
    panel.title = hostTitle;
    panel.message = hostText;
  } else if (mode == 3) {
    panel.icon = 0;
    panel.title = L"正在安装网页组件";
    panel.message = UseLegacyOfflinePackage()
                        ? L"正在从微软更新目录下载并安装 Windows 7/8/8.1 能用的 109 版 WebView2 运行时（离线安装包约 132MB），装好后页面会自动打开。安装在后台进行，不影响使用程序的其他功能。"
                        : L"正在从微软官网下载并安装 WebView2 运行时，装好后页面会自动打开。安装在后台进行，不影响使用程序的其他功能。";
  }
  if (mode == 0) recheckPending = false;
  PanelAccName(this);  // 读屏软件读的是窗口名称：卡片内容、按钮与键盘操作方法
  InvalidateRect(host, nullptr, FALSE);
}

// 程序自己的准备工作：显示（或更新）进度卡片；标题为空时收起，回到显示进度卡片之前的卡片。程序明确要求显示，所以关闭了提示卡片
// （WVO_FALLBACK_UI 为 "0"）时也显示；浏览器已经就绪、页面正在显示时只记下，不盖住页面
void View::ShowHostProgress(const std::wstring& title, const std::wstring& text, const std::wstring& status, int permille) {
  if (title.empty()) {
    if (!hostProgress) return;
    hostProgress = false;
    if (!host || panel.mode != 3) return;  // 卡片已经换成别的（例如浏览器开始重建）
    // 回到显示进度卡片之前的卡片：失败时是原来的说明（或“页面意外关闭了”），正在创建时是启动中
    if (state == WV_STATE_READY || !FallbackEnabled()) SetPanel(0);
    else if (state == WV_STATE_FAILED) SetPanel(hostPrevMode == 4 ? 4 : 2);
    else SetPanel(1);
    return;
  }
  const bool update = hostProgress && panel.mode == 3;
  if (!hostProgress) hostPrevMode = panel.mode == 3 ? 2 : panel.mode;
  hostProgress = true;
  hostTitle = title;
  hostText = text;
  hostStatus = status;
  hostPermille = permille < 0 ? -1 : std::min(permille, 1000);
  if (!host || state == WV_STATE_READY) return;
  if (!update) {
    SetPanel(3);
    return;
  }
  panel.title = hostTitle;  // 只改文字与进度：不重新开始动画
  panel.message = hostText;
  panel.animValid = false;
  PanelAccName(this);
  InvalidateRect(host, nullptr, FALSE);
}

void View::OnTimer(UINT_PTR tid) {
  if (!host) return;
  if (tid == 1) {  // 动画帧
    if (panel.mode != 3 && !(panel.mode == 1 && panel.slowShown)) {
      KillTimer(host, 1);
      return;
    }
    ++panel.tick;
    HWND root = GetAncestor(host, GA_ROOT);
    if (!IsWindowVisible(host) || (root && IsIconic(root))) return;  // 看不见时不画，不占 CPU
    if (panel.mode == 3 && InstallStatusText(nullptr, nullptr) != panel.statusShown) {
      InvalidateRect(host, nullptr, FALSE);  // 进度文字变了（百分比、已用时间）：整卡重画
      return;
    }
    HDC dc = GetDC(host);
    if (dc) {
      PaintAnim(dc);
      ReleaseDC(host, dc);
    }
  } else if (tid == 2) {  // 启动稍慢：1.2 秒后出现转圈，再过几秒补一句提示
    if (panel.mode != 1) {
      KillTimer(host, 2);
      return;
    }
    if (!panel.slowShown) {
      panel.slowShown = true;
      SetTimer(host, 1, 40, nullptr);
      SetTimer(host, 2, 4800, nullptr);
    } else {
      panel.hintShown = true;
      KillTimer(host, 2);
    }
    InvalidateRect(host, nullptr, FALSE);
  } else if (tid == 4) {  // “已复制”两秒后恢复原来的文字
    KillTimer(host, 4);
    for (int i = 0; i < panel.btnCount; ++i)
      if (panel.btnAction[i] == PA_COPY) panel.btnText[i] = L"复制诊断信息";
    InvalidateRect(host, nullptr, FALSE);
  } else if (tid == 5) {  // 运行时文件暂时被别的程序占用：稍后重试（运行时客户端还没碰这些文件，不会记住失败）
    KillTimer(host, 5);
    if (!closing && state == WV_STATE_FAILED) Recreate();
  }
}

bool View::PanelMouse(UINT msg, WPARAM, LPARAM lp, LRESULT& res) {
  if (panel.mode != 2 && panel.mode != 4) return false;
  POINT pt = {(short)LOWORD(lp), (short)HIWORD(lp)};
  auto hit = [&](POINT p) {
    for (int i = 0; i < panel.btnCount; ++i)
      if (PtInRect(&panel.btn[i], p)) return i;
    return -1;
  };
  switch (msg) {
    case WM_CAPTURECHANGED:  // 按住按钮时鼠标捕获被别的窗口拿走（弹出对话框等）：按钮恢复原样，不能一直显示为按下
      if (panel.pressed >= 0 && (HWND)lp != host) {
        panel.pressed = -1;
        InvalidateRect(host, nullptr, FALSE);
      }
      res = 0;
      return true;
    case WM_SETCURSOR:
      if (panel.hot >= 0) {
        SetCursor(LoadCursor(nullptr, IDC_HAND));
        res = TRUE;
        return true;
      }
      return false;
    case WM_MOUSEMOVE: {
      int h = hit(pt);
      if (!panel.tracking) {
        TRACKMOUSEEVENT t = {sizeof(t), TME_LEAVE, host, 0};
        TrackMouseEvent(&t);
        panel.tracking = true;
      }
      if (h != panel.hot) {
        panel.hot = h;
        InvalidateRect(host, nullptr, FALSE);
      }
      res = 0;
      return true;
    }
    case WM_MOUSELEAVE:
      panel.tracking = false;
      if (panel.hot != -1) {
        panel.hot = -1;
        InvalidateRect(host, nullptr, FALSE);
      }
      res = 0;
      return true;
    case WM_LBUTTONDOWN:
      panel.pressed = hit(pt);
      if (panel.pressed >= 0) {
        SetCapture(host);
        panel.focus = panel.pressed;  // 像系统按钮一样，点击后键盘焦点落在这个按钮上（鼠标操作不画焦点框）
        panel.kbd = false;
        PanelAccName(this);
        if (GetFocus() != host) SetFocus(host);
      }
      InvalidateRect(host, nullptr, FALSE);
      res = 0;
      return true;
    case WM_LBUTTONUP: {
      int was = panel.pressed;
      panel.pressed = -1;
      if (GetCapture() == host) ReleaseCapture();
      InvalidateRect(host, nullptr, FALSE);
      if (was >= 0 && was == hit(pt)) PanelAction(panel.btnAction[was]);
      res = 0;
      return true;
    }
  }
  return false;
}

// 键盘：左右（上下）方向键在按钮间移动，回车或空格执行；对话框管理器没有处理 Tab 时，在按钮间移动，到头交给窗口里的下一个控件
bool View::PanelKey(UINT msg, WPARAM wp, LPARAM lp, LRESULT& res) {
  if (!PanelHasButtons()) return false;
  if (msg == WM_GETDLGCODE) {
    LRESULT r = DLGC_WANTARROWS;
    const MSG* m = reinterpret_cast<const MSG*>(lp);
    if (m && m->message == WM_KEYDOWN && (m->wParam == VK_RETURN || m->wParam == VK_SPACE)) r |= DLGC_WANTMESSAGE;
    res = r;
    return true;
  }
  if (msg != WM_KEYDOWN) return false;
  const int n = panel.btnCount;
  int f = panel.focus < 0 || panel.focus >= n ? 0 : panel.focus;
  switch (wp) {
    case VK_LEFT:
    case VK_UP: f = (f + n - 1) % n; break;
    case VK_RIGHT:
    case VK_DOWN: f = (f + 1) % n; break;
    case VK_HOME: f = 0; break;
    case VK_END: f = n - 1; break;
    case VK_TAB: {
      const bool back = GetKeyState(VK_SHIFT) < 0;
      const int nf = f + (back ? -1 : 1);
      if (nf >= 0 && nf < n) {
        f = nf;
        break;
      }
      HWND root = GetAncestor(host, GA_ROOT);
      HWND next = root ? GetNextDlgTabItem(root, host, back ? TRUE : FALSE) : nullptr;
      if (next && next != host && !IsChild(host, next)) {
        SetFocus(next);
        res = 0;
        return true;
      }
      f = back ? n - 1 : 0;  // 窗口里只有这一个可停留的控件：在按钮间循环
      break;
    }
    case VK_RETURN:
    case VK_SPACE:
      if (lp & 0x40000000) {  // 按住不放产生的自动重复：只在第一次按下时执行
        res = 0;
        return true;
      }
      panel.focus = f;
      panel.kbd = true;
      PanelAccName(this);
      InvalidateRect(host, nullptr, FALSE);
      PanelAction(panel.btnAction[f]);
      res = 0;
      return true;
    default:
      return false;
  }
  panel.focus = f;
  panel.kbd = true;
  PanelAccName(this);
  InvalidateRect(host, nullptr, FALSE);
  res = 0;
  return true;
}

void ShowInstallingOnAllViews() {
  // 关闭了提示卡片的浏览器不显示任何卡片（装好后仍会自动恢复）；只用固定版的浏览器装了也没有用，保持原来的卡片
  for (auto& o : AllViews())
    if (!o->closing && o->host && o->state == WV_STATE_FAILED && (o->errCode == WVERR_NO_RUNTIME || o->errCode == WVERR_INSTALL) &&
        (o->panel.mode != 3 || o->hostProgress) && o->FallbackEnabled() && o->InstallCanHelp()) {
      o->hostProgress = false;  // 程序发起了安装：卡片改为显示安装进度
      o->SetPanel(3);
    }
}

void OnInstallFinishedUi(bool ok) {
  if (ok) {
    const RuntimeInfo r = FindRuntime(true, std::wstring());
    if (!r.found) RecordInstallFailure(L"装好了常青版（或电脑上本来就有），但按当前的运行时设置仍没有可用的运行时：" + r.reason);
    RecreateWaitingViews();  // 仍然没有时，重建后卡片照常说明原因
    return;
  }
  const std::wstring err = LastInstallError();
  for (auto& o : AllViews()) {
    if (o->closing || !o->host || o->panel.mode != 3 || o->hostProgress) continue;  // 程序自己的进度卡片不归安装结果管
    o->errMsg = err;
    o->errHr = S_OK;
    o->errCode = WVERR_INSTALL;
    o->SetPanel(2);
  }
}

void View::PanelAction(int action) {
  if (action != PA_COPY) {  // 用户亲自操作：自动重试、自动换用运行时的次数重新计（这两个上限只防止自动进行时来回折腾）
    precheckRetries = 0;
    runtimeSwitches = 0;
  }
  switch (action) {
    case PA_INSTALL:
      if (StartRuntimeInstall()) {
        ShowInstallingOnAllViews();
      } else {
        errMsg = LastInstallError();
        errHr = S_OK;
        errCode = WVERR_INSTALL;
        SetPanel(2);
      }
      break;
    case PA_PICK_DIR: {
      std::wstring path;
      if (PickFolder(GetAncestor(host, GA_ROOT), path)) UsePickedRuntime(path);
      break;
    }
    case PA_COPY: {
      std::wstring diag = Fmt(L"WebView2Bridge 诊断信息\r\n版本：%d.%d.%d\r\n系统：", WV_BRIDGE_VERSION / 10000, WV_BRIDGE_VERSION / 100 % 100,
                              WV_BRIDGE_VERSION % 100) +
                          Os().name + L"，" + ProcessText() + L"\r\n错误：" + errMsg + (errHr != S_OK ? L"\r\n代码：" + HrText(errHr) : std::wstring()) +
                          L"\r\n运行时：" + RuntimeJson(FindRuntime(false, optRuntime));  // 按本浏览器自己的运行时设置查找，与它实际用的一致
      // 失败的原因常常要结合这些才看得出来：文件是否完整、地址空间、环境与数据目录、安装结果、失败前后的日志
      diag += L"\r\n环境：" + EnvListJson() + Fmt(L"\r\n地址空间：最大连续空闲 %.1f MB", LargestFreeRegion() / 1048576.0);
      const std::wstring inst = LastInstallError();
      if (!inst.empty()) diag += L"\r\n安装：" + inst;
      const std::wstring instLog = LastInstallLog();
      if (!instLog.empty()) diag += L"\r\n微软安装程序日志（MicrosoftEdgeUpdate.log 里这次安装写的最后几行）：\r\n" + instLog;
      const std::wstring tail = LogTail(20);
      if (!tail.empty()) diag += L"\r\n最近日志：\r\n" + tail;
      if (CopyText(host, diag)) {
        for (int i = 0; i < panel.btnCount; ++i)
          if (panel.btnAction[i] == PA_COPY) panel.btnText[i] = L"已复制";
        SetTimer(host, 4, 2000, nullptr);
        InvalidateRect(host, nullptr, FALSE);
      }
      break;
    }
    case PA_RECHECK:
      recheckPending = true;
      FindRuntime(true, optRuntime);
      Recreate();
      break;
    case PA_RETRY:
      Recreate();
      break;
  }
}

void View::UsePickedRuntime(const std::wstring& path) {
  RuntimeInfo r = FindRuntime(true, path);
  if (!r.found) {
    panel.detail = r.reason;
    if (host) InvalidateRect(host, nullptr, FALSE);  // 选择对话框是模态的，期间浏览器可能已被销毁
    return;
  }
  if (!optRuntime.empty()) {
    optRuntime = r.sel.dir;
    FindRuntime(true, optRuntime);
    Recreate();
    return;
  }
  {
    Guard g(GLock());
    G().runtimeDir = r.sel.dir;
  }
  FindRuntime(true, std::wstring());
  RecreateWaitingViews();  // 全局运行时目录对所有浏览器生效：一起恢复
  if (state != WV_STATE_FAILED) Recreate();
}

}  // namespace wv
