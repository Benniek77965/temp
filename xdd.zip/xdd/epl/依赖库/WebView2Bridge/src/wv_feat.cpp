// wv_feat.cpp : 脚本、DevTools 协议、JS 桥、元素操作、模拟输入、Cookie、截图、PDF、网络、下载、新窗口、右键菜单、快捷键
#include "wv_internal.h"

namespace wv {

namespace {
struct SyncState {
  bool done = false;
  HRESULT hr = E_PENDING;
  std::wstring text;
  BOOL flag = FALSE;
};
bool WaitState(View* v, const std::shared_ptr<SyncState>& st, DWORD timeout) {
  if (HandlerDepth() > 0) {
    SetErr(WVERR_REENTRANT, ReentrantText());
    return false;
  }
  RefPtr<View> hold(v);
  if (!PumpUntil([&] { return st->done || v->closing; }, timeout)) {
    SetErr(WVERR_TIMEOUT, L"等待超时");
    return false;
  }
  if (!st->done) {
    SetErr(WVERR_CLOSED, L"浏览器已关闭");
    return false;
  }
  return true;
}
std::wstring UnwrapJson(const std::wstring& json) {
  JVal j;
  if (!JsonParse(json, j)) return json;
  return j.Text();
}
}  // namespace

// ---------------------------------------------------------------- 脚本
bool View::CdpSync(const std::wstring& method, const std::wstring& params, DWORD timeout, std::wstring& out) {
  if (!RequireReady()) return false;
  if (!CanWait()) return false;
  auto st = std::make_shared<SyncState>();
  HRESULT hr = wv->CallDevToolsProtocolMethod(method.c_str(), params.empty() ? L"{}" : params.c_str(),
                                              Callback<ICoreWebView2CallDevToolsProtocolMethodCompletedHandler, HRESULT, LPCWSTR>(
                                                  [st](HRESULT e, LPCWSTR r) -> HRESULT {
                                                    st->hr = e;
                                                    st->text = r ? r : L"";
                                                    st->done = true;
                                                    return S_OK;
                                                  })
                                                  .get());
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"调用 DevTools 协议失败：" + HrText(hr), hr);
    return false;
  }
  if (!WaitState(this, st, timeout)) return false;
  if (FAILED(st->hr)) {
    SetErr(WVERR_FAILED, L"DevTools 协议返回错误：" + method + L" " + st->text, st->hr);
    out = st->text;
    return false;
  }
  out = st->text;
  return true;
}

// 等待 Promise 的执行（WVX_AWAIT）。用 REPL 模式求值：支持顶层 await，顶层 let 可以重复声明。
// REPL 模式本身不等待表达式得到的 Promise——按值取回只得到 {}，被拒绝的 Promise 也不报错（Chromium 141 实测，
// 实机报告中“执行JS 等待 Promise”和两项 JS 桥用例因此失败）——所以结果先按远程对象取回：完成值是 Promise 时
// 用 Runtime.awaitPromise 等它，其它对象用 Runtime.callFunctionOn 按值取回，基本类型直接用。每次求值用自己的
// 对象组，用到远程对象时结束后整组释放；内核不接受 REPL 模式时退回普通求值（按值取回，同样等待 Promise）。
// 同步与异步执行共用这一条调用链，同步执行只是等它完成
static std::wstring NewEvalGroup() {
  static volatile LONG seq = 0;
  return L"wv2bridge-eval-" + std::to_wstring(InterlockedIncrement(&seq));
}
static std::wstring EvalParams(const std::wstring& js, const std::wstring& group) {
  if (group.empty()) return L"{\"expression\":" + JsonStr(js) + L",\"awaitPromise\":true,\"returnByValue\":true,\"userGesture\":true}";
  return L"{\"expression\":" + JsonStr(js) + L",\"awaitPromise\":true,\"returnByValue\":false,\"userGesture\":true,\"replMode\":true,\"objectGroup\":" +
         JsonStr(group) + L"}";
}
enum class EvalStep { Done, Error, Next };
// 处理一步的返回：完成（out 为结果 JSON）、出错（code、err）或者还要再调用一次（method、params）
static EvalStep EvalNext(const std::wstring& json, std::wstring& out, std::wstring& method, std::wstring& params, int& code, std::wstring& err) {
  JVal j;
  if (!JsonParse(json, j)) {  // 原来解析失败时把原文当结果返回，调用方看不出出了错
    code = WVERR_FAILED;
    err = L"DevTools 协议的返回无法解析：" + json.substr(0, 200);
    return EvalStep::Error;
  }
  if (const JVal* ex = j.Get(L"exceptionDetails")) {
    std::wstring m;
    const JVal* e = ex->Get(L"exception");
    if (e && e->Get(L"description")) m = e->Get(L"description")->Text();
    else if (ex->Get(L"text")) m = ex->Get(L"text")->Text();
    code = WVERR_SCRIPT;
    err = L"脚本异常：" + m;
    return EvalStep::Error;
  }
  const JVal* r = j.Get(L"result");
  if (!r) {
    out = L"null";
    return EvalStep::Done;
  }
  if (const JVal* oid = r->Get(L"objectId")) {
    const JVal* sub = r->Get(L"subtype");
    if (sub && sub->Text() == L"promise") {
      method = L"Runtime.awaitPromise";
      params = L"{\"promiseObjectId\":" + JsonStr(oid->Text()) + L",\"returnByValue\":true}";
    } else {
      method = L"Runtime.callFunctionOn";
      params = L"{\"objectId\":" + JsonStr(oid->Text()) + L",\"functionDeclaration\":\"function(){return this}\",\"returnByValue\":true}";
    }
    return EvalStep::Next;
  }
  const JVal* val = r->Get(L"value");
  out = val ? val->Dump() : L"null";
  return EvalStep::Done;
}
struct AwaitChain {
  int vid = 0;
  std::wstring js, group;
  int steps = 0;
  bool objects = false;  // 产生过远程对象：结束时释放对象组
  std::function<void(bool ok, int code, const std::wstring& text)> done;
};
static void AwaitFinish(const std::shared_ptr<AwaitChain>& c, bool ok, int code, const std::wstring& text) {
  if (c->objects && !c->group.empty()) {
    RefPtr<View> v = FindView(c->vid);
    if (v && v->wv)
      v->wv->CallDevToolsProtocolMethod(L"Runtime.releaseObjectGroup", (L"{\"objectGroup\":" + JsonStr(c->group) + L"}").c_str(),
                                        Callback<ICoreWebView2CallDevToolsProtocolMethodCompletedHandler, HRESULT, LPCWSTR>(
                                            [](HRESULT, LPCWSTR) -> HRESULT { return S_OK; })
                                            .get());
  }
  auto done = std::move(c->done);
  c->done = nullptr;
  if (done) done(ok, code, text);
}
static HRESULT AwaitCall(const std::shared_ptr<AwaitChain>& c, const std::wstring& method, const std::wstring& params, bool first) {
  RefPtr<View> v = FindView(c->vid);
  if (!v || !v->wv || v->closing) return E_ABORT;
  return v->wv->CallDevToolsProtocolMethod(
      method.c_str(), params.c_str(),
      Callback<ICoreWebView2CallDevToolsProtocolMethodCompletedHandler, HRESULT, LPCWSTR>([c, method, first](HRESULT e, LPCWSTR r) -> HRESULT {
        const std::wstring text = r ? r : L"";
        if (FAILED(e)) {
          if (first) {  // 内核不接受 REPL 模式：退回普通求值
            c->group.clear();
            HRESULT h2 = AwaitCall(c, L"Runtime.evaluate", EvalParams(c->js, std::wstring()), false);
            if (FAILED(h2)) AwaitFinish(c, false, WVERR_FAILED, L"调用 DevTools 协议失败：" + HrText(h2));
            return S_OK;
          }
          AwaitFinish(c, false, WVERR_FAILED, L"DevTools 协议返回错误：" + method + L" " + text);
          return S_OK;
        }
        std::wstring out, m2, p2, err;
        int code = 0;
        switch (EvalNext(text, out, m2, p2, code, err)) {
          case EvalStep::Done:
            AwaitFinish(c, true, 0, out);
            break;
          case EvalStep::Error:
            if (text.find(L"\"objectId\"") != std::wstring::npos) c->objects = true;  // 异常对象也登记在对象组里
            AwaitFinish(c, false, code, err);
            break;
          case EvalStep::Next: {
            c->objects = true;
            if (++c->steps > 3) {
              AwaitFinish(c, false, WVERR_FAILED, L"取脚本结果的步骤过多");
              break;
            }
            HRESULT h2 = AwaitCall(c, m2, p2, false);
            if (FAILED(h2)) AwaitFinish(c, false, WVERR_FAILED, L"调用 DevTools 协议失败：" + HrText(h2));
            break;
          }
        }
        return S_OK;
      }).get());
}
// 开始一次等待 Promise 的执行；返回失败时不会再调用 done
static HRESULT StartAwait(int vid, const std::wstring& js, std::function<void(bool, int, const std::wstring&)> done) {
  auto c = std::make_shared<AwaitChain>();
  c->vid = vid;
  c->js = js;
  c->group = NewEvalGroup();
  c->done = std::move(done);
  HRESULT hr = AwaitCall(c, L"Runtime.evaluate", EvalParams(js, c->group), true);
  if (FAILED(hr)) c->done = nullptr;
  return hr;
}

bool View::ExecSync(const std::wstring& js, int flags, DWORD timeout, std::wstring& out) {
  if (!RequireReady()) return false;
  if (!CanWait()) return false;
  std::wstring raw;
  if (flags & WVX_AWAIT) {
    auto st = std::make_shared<SyncState>();
    auto code = std::make_shared<int>(0);
    HRESULT hr = StartAwait(id, js, [st, code](bool ok, int c, const std::wstring& t) {
      st->hr = ok ? S_OK : E_FAIL;
      *code = c;
      st->text = t;
      st->done = true;
    });
    if (FAILED(hr)) {
      SetErr(WVERR_FAILED, L"调用 DevTools 协议失败：" + HrText(hr), hr);
      return false;
    }
    if (!WaitState(this, st, timeout)) return false;  // 超时后调用链仍会走完并释放对象组，结果丢弃
    if (FAILED(st->hr)) {
      SetErr(*code ? *code : WVERR_FAILED, st->text);
      return false;
    }
    raw = st->text;
  } else {
    auto st = std::make_shared<SyncState>();
    HRESULT hr = wv->ExecuteScript(js.c_str(), Callback<ICoreWebView2ExecuteScriptCompletedHandler, HRESULT, LPCWSTR>([st](HRESULT e, LPCWSTR r) -> HRESULT {
                                                 st->hr = e;
                                                 st->text = r ? r : L"";
                                                 st->done = true;
                                                 return S_OK;
                                               }).get());
    if (FAILED(hr)) {
      SetErr(WVERR_FAILED, L"执行脚本失败：" + HrText(hr), hr);
      return false;
    }
    if (!WaitState(this, st, timeout)) return false;
    if (FAILED(st->hr)) {
      SetErr(WVERR_SCRIPT, L"执行脚本失败：" + HrText(st->hr), st->hr);
      return false;
    }
    raw = st->text;
  }
  out = (flags & WVX_UNWRAP) ? UnwrapJson(raw) : raw;
  return true;
}

bool View::ExecAsync(const std::wstring& js, int flags, void* fn, int userData) {
  if (!RequireReady()) return false;
  const int vid = id;
  auto deliver = [vid, fn, userData, flags](bool ok, const std::wstring& raw) {
    RefPtr<View> v0 = FindView(vid);
    if (!v0 || v0->closing || !fn) return;
    // 完成回调也属于 WebView2 的处理流程：投递出去再调用易语言，回调里才能继续使用同步方法
    v0->Post([vid, fn, userData, flags, ok, raw] {
      WV_TASK(vid);
      std::wstring t = (ok && (flags & WVX_UNWRAP)) ? UnwrapJson(raw) : raw;
      std::string s = (flags & WVX_UNWRAP) ? ToCP(t) : ToCPJson(t);
      v->FireFn(fn, 0, {(intptr_t)vid, (intptr_t)userData, ok ? 1 : 0, (intptr_t)s.c_str()}, nullptr);
    });
  };
  HRESULT hr;
  if (flags & WVX_AWAIT) {
    // 失败时把错误说明交给回调（原来交的是 DevTools 协议的原始 JSON）
    hr = StartAwait(vid, js, [deliver](bool ok, int, const std::wstring& t) { deliver(ok, t); });
  } else {
    hr = wv->ExecuteScript(js.c_str(), Callback<ICoreWebView2ExecuteScriptCompletedHandler, HRESULT, LPCWSTR>([deliver](HRESULT e, LPCWSTR r) -> HRESULT {
                                         deliver(SUCCEEDED(e), r ? r : L"");
                                         return S_OK;
                                       }).get());
  }
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"执行脚本失败：" + HrText(hr), hr);
    return false;
  }
  return true;
}

bool View::AddInitScript(const std::wstring& js, DWORD timeout, std::wstring& outId) {
  if (!RequireReady()) return false;
  if (!CanWait()) return false;
  auto st = std::make_shared<SyncState>();
  HRESULT hr = wv->AddScriptToExecuteOnDocumentCreated(js.c_str(), Callback<ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler, HRESULT, LPCWSTR>(
                                                                       [st](HRESULT e, LPCWSTR r) -> HRESULT {
                                                                         st->hr = e;
                                                                         st->text = r ? r : L"";
                                                                         st->done = true;
                                                                         return S_OK;
                                                                       })
                                                                       .get());
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"注入脚本失败：" + HrText(hr), hr);
    return false;
  }
  if (!WaitState(this, st, timeout)) return false;
  if (FAILED(st->hr)) {
    SetErr(WVERR_FAILED, L"注入脚本失败：" + HrText(st->hr), st->hr);
    return false;
  }
  outId = st->text;
  initScripts.push_back({outId, outId, js});  // 记下来：内核崩溃后重建时重新登记（原来重建后注入的脚本就没了）
  return true;
}

bool View::RemoveInitScript(const std::wstring& sid) {
  auto it = std::find_if(initScripts.begin(), initScripts.end(), [&](const InitScript& s) { return s.userId == sid; });
  const bool known = it != initScripts.end();
  const std::wstring cur = known ? it->curId : sid;  // 重建后内核里的编号变了，程序手里的仍是原来的编号
  if (known) initScripts.erase(it);
  if (!Ready()) {
    if (known) return true;  // 浏览器正在重建：从登记表里删掉，重建后就不再注入
    return RequireReady();
  }
  HRESULT hr = wv->RemoveScriptToExecuteOnDocumentCreated(cur.c_str());
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"移除注入脚本失败：" + HrText(hr), hr);
    return false;
  }
  return true;
}

// ---------------------------------------------------------------- 元素操作
static const wchar_t* kDomJs =
    L"(function(sel,val,act){"
    L"function x(s){return s.charAt(0)==='/'||s.substr(0,2)==='(/';}"
    L"function q(s){if(!s)return null;try{return x(s)?document.evaluate(s,document,null,9,null).singleNodeValue:document.querySelector(s);}catch(e){return null;}}"
    L"function qa(s){var r=[];if(!s)return r;try{if(x(s)){var it=document.evaluate(s,document,null,7,null);for(var i=0;i<it.snapshotLength;i++)r.push(it.snapshotItem(i));return r;}"
    L"return Array.prototype.slice.call(document.querySelectorAll(s));}catch(e){return r;}}"
    L"function fire(el,t){el.dispatchEvent(new Event(t,{bubbles:true}));}"
    L"function txt(e){return(e.innerText!==undefined?e.innerText:e.textContent)||'';}"
    L"if(act===11)return qa(sel).length;"
    L"if(act===16)return JSON.stringify(qa(sel).map(txt));"
    L"var el=q(sel);if(act===1)return !!el;if(!el)return null;"
    L"switch(act){"
    L"case 2:if(el.matches&&el.matches(':disabled'))return false;el.scrollIntoView({block:'center'});el.click();return true;"
    L"case 3:{el.focus();var p=el instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:(el instanceof HTMLSelectElement?HTMLSelectElement.prototype:HTMLInputElement.prototype);"
    L"var d=Object.getOwnPropertyDescriptor(p,'value');if(el.isContentEditable){el.innerText=val;}else if(d&&d.set&&(el instanceof p.constructor)){d.set.call(el,val);}else if('value' in el){el.value=val;}else{return false;}"
    L"fire(el,'input');fire(el,'change');return true;}"
    L"case 4:return txt(el);"
    L"case 5:return el.outerHTML;"
    L"case 6:return el.value===undefined?'':String(el.value);"
    L"case 7:{var a=el.getAttribute(val);return a===null?'':a;}"
    L"case 8:{var k=val.indexOf('=');if(k<0)el.setAttribute(val,'');else el.setAttribute(val.substr(0,k),val.substr(k+1));return true;}"
    L"case 9:el.focus();return document.activeElement===el;"
    L"case 10:el.scrollIntoView({block:'center',behavior:'smooth'});return true;"
    L"case 12:el.remove();return true;"
    L"case 13:{var f=el.form||(el.tagName==='FORM'?el:null);if(!f)return false;if(f.requestSubmit){if(!f.noValidate&&!f.reportValidity())return 'invalid';f.requestSubmit();}else f.submit();return true;}"
    L"case 14:{var on=!/^(0|false|off|no|\\u5047|\\u5426)$/i.test(String(val).trim());if(!!el.checked!==on)el.click();return !!el.checked===on;}"
    L"case 15:{var o=Array.prototype.slice.call(el.options||[]),m=null;for(var i=0;i<o.length;i++){if(o[i].value===val||o[i].text===val||o[i].text.trim()===String(val).trim()){m=o[i];break;}}"
    L"if(!m)return false;el.value=m.value;fire(el,'input');fire(el,'change');return true;}"
    L"case 17:el.innerHTML=val;return true;"
    L"case 18:{el.scrollIntoView({block:'center'});var r=el.getBoundingClientRect();return JSON.stringify({x:r.left+r.width/2,y:r.top+r.height/2,w:r.width,h:r.height});}"
    L"case 19:{if(el.matches&&el.matches(':disabled'))return 'disabled';el.scrollIntoView({block:'center'});var r=el.getBoundingClientRect();return JSON.stringify({x:r.left+r.width/2,y:r.top+r.height/2,w:r.width,h:r.height});}"
    L"}return null;})";

bool View::Dom(int act, const std::wstring& sel, const std::wstring& val, DWORD timeout, std::wstring& out) {
  if (!RequireReady()) return false;
  if (timeout > 0 && act != WVD_COUNT) {
    DWORD start = GetTickCount();
    std::wstring r;
    for (;;) {
      if (!ExecSync(std::wstring(kDomJs) + L"(" + JsonStr(sel) + L",'',1)", 0, 10000, r)) return false;
      if (r == L"true") break;
      if (GetTickCount() - start >= timeout) {
        if (act == WVD_EXISTS) {  // 结果仍是 false；错误码说明是等到超时也没出现（不等待时没有元素不算出错）
          SetErr(WVERR_TIMEOUT, L"等待元素超时：" + sel);
          out = L"false";
          return true;
        }
        SetErr(WVERR_NOT_FOUND, L"等待元素超时：" + sel);
        return false;
      }
      PumpUntil([] { return false; }, 120);
      if (closing) {
        SetErr(WVERR_CLOSED, L"浏览器已关闭");  // 与其它等待一致（原来返回失败却没有错误说明）
        return false;
      }
    }
  }
  int jsAct = act;
  // 真实点击用自己的脚本动作：先看元素是否被禁用（禁用的控件收不到点击），再取中心坐标
  if (act == WVD_TYPE_TEXT) jsAct = WVD_FOCUS;
  std::wstring raw;
  if (!ExecSync(std::wstring(kDomJs) + L"(" + JsonStr(sel) + L"," + JsonStr(val) + L"," + std::to_wstring(jsAct) + L")", 0, 15000, raw)) return false;
  if (raw == L"null") {
    SetErr(WVERR_NOT_FOUND, L"没有找到元素：" + sel);
    out.clear();
    return false;
  }
  if (act == WVD_TRUSTED_CLICK && UnwrapJson(raw) == L"disabled") {
    SetErr(WVERR_FAILED, L"元素已禁用，点击不会生效：" + sel);
    return false;
  }
  if (act == WVD_SUBMIT && UnwrapJson(raw) == L"invalid") {  // 浏览器按表单校验拦下了提交（requestSubmit 不提交也不报错）
    SetErr(WVERR_FAILED, L"表单里有没通过校验的字段（如必填项为空），没有提交：" + sel);
    out = L"false";
    return true;
  }
  if (act == WVD_TRUSTED_CLICK) {
    JVal j;
    const JVal *jx = nullptr, *jy = nullptr, *jw = nullptr, *jh = nullptr;
    if (JsonParse(UnwrapJson(raw), j)) jx = j.Get(L"x"), jy = j.Get(L"y"), jw = j.Get(L"w"), jh = j.Get(L"h");
    if (!jx || !jy) {
      SetErr(WVERR_FAILED, L"取不到元素的位置：" + sel);
      return false;
    }
    if (jw && jh && (jw->Num() < 1 || jh->Num() < 1)) {  // 隐藏或大小为 0 的元素中心在 (0,0) 附近：照点会点到别的东西
      SetErr(WVERR_FAILED, L"元素不可见或大小为 0，不能用真实鼠标点击：" + sel);
      return false;
    }
    out = L"true";
    return Input(WVI_CLICK, (int)(jx->Num() + 0.5), (int)(jy->Num() + 0.5), std::wstring());
  }
  if (act == WVD_TYPE_TEXT) {
    if (UnwrapJson(raw) == L"false") {  // 没聚焦上（隐藏、禁用或不能聚焦）就输入，文字会进到原来有焦点的别的输入框里
      SetErr(WVERR_FAILED, L"元素没能获得焦点（隐藏、禁用或不能聚焦），没有输入：" + sel);
      return false;
    }
    out = L"true";
    return Input(WVI_TEXT, 0, 0, val);
  }
  out = UnwrapJson(raw);
  if (out == L"false") {  // 动作没能完成（页面脚本返回 false）：给出原因，否则 取最后错误 () 是空的
    switch (act) {
      case WVD_SET_VALUE: SetErr(WVERR_UNSUPPORTED, L"这个元素不能赋值（不是输入框、文本框、下拉框或可编辑区域）：" + sel); break;
      case WVD_SUBMIT: SetErr(WVERR_NOT_FOUND, L"元素不在表单里：" + sel); break;
      case WVD_CHECK: SetErr(WVERR_FAILED, L"元素没能变成指定的勾选状态（不是复选框或单选框，或是不能直接取消的单选框）：" + sel); break;
      case WVD_SELECT: SetErr(WVERR_NOT_FOUND, L"下拉框里没有这个选项：" + val); break;
      case WVD_FOCUS: SetErr(WVERR_FAILED, L"元素没能获得焦点（隐藏、禁用或不能聚焦）：" + sel); break;
      case WVD_CLICK: SetErr(WVERR_FAILED, L"元素已禁用，点击不会生效：" + sel); break;
      default: break;
    }
  }
  return true;
}

// ---------------------------------------------------------------- 模拟输入（DevTools Input 域，事件 isTrusted=true）
static bool KeySpec(const std::wstring& spec, int& vk, int& mods, std::wstring& key, std::wstring& code, std::wstring& text) {
  std::wstring s = Trim(spec);
  mods = 0;
  for (;;) {
    if (StartsWithI(s, L"ctrl+")) { mods |= 2; s = s.substr(5); }
    else if (StartsWithI(s, L"shift+")) { mods |= 8; s = s.substr(6); }
    else if (StartsWithI(s, L"alt+")) { mods |= 1; s = s.substr(4); }
    else break;
  }
  struct K { const wchar_t* n; int vk; const wchar_t* key; const wchar_t* code; const wchar_t* text; };
  static const K table[] = {
      {L"enter", 13, L"Enter", L"Enter", L"\r"}, {L"tab", 9, L"Tab", L"Tab", L""}, {L"backspace", 8, L"Backspace", L"Backspace", L""},
      {L"esc", 27, L"Escape", L"Escape", L""}, {L"escape", 27, L"Escape", L"Escape", L""}, {L"delete", 46, L"Delete", L"Delete", L""},
      {L"space", 32, L" ", L"Space", L" "}, {L"up", 38, L"ArrowUp", L"ArrowUp", L""}, {L"down", 40, L"ArrowDown", L"ArrowDown", L""},
      {L"left", 37, L"ArrowLeft", L"ArrowLeft", L""}, {L"right", 39, L"ArrowRight", L"ArrowRight", L""}, {L"home", 36, L"Home", L"Home", L""},
      {L"end", 35, L"End", L"End", L""}, {L"pageup", 33, L"PageUp", L"PageUp", L""}, {L"pagedown", 34, L"PageDown", L"PageDown", L""}};
  std::wstring l = Lower(s);
  for (const K& k : table)
    if (l == k.n) { vk = k.vk; key = k.key; code = k.code; text = mods & 3 ? L"" : k.text; return true; }
  if (l.size() >= 2 && l[0] == L'f' && iswdigit(l[1])) {
    int n = (int)wcstol(l.c_str() + 1, nullptr, 10);
    if (n >= 1 && n <= 12) { vk = 111 + n; key = code = Fmt(L"F%d", n); text.clear(); return true; }
  }
  if (s.size() == 1 && iswalnum(s[0])) {
    wchar_t c = s[0];
    vk = (int)towupper(c);
    key = (mods & 8) ? std::wstring(1, (wchar_t)towupper(c)) : std::wstring(1, (wchar_t)towlower(c));
    code = iswdigit(c) ? std::wstring(L"Digit") + c : std::wstring(L"Key") + (wchar_t)towupper(c);
    text = (mods & 3) ? L"" : key;
    return true;
  }
  return false;
}

bool View::Input(int kind, int x, int y, const std::wstring& text) {
  if (!RequireReady()) return false;
  std::wstring r;
  auto mouse = [&](const wchar_t* type, const wchar_t* button, int clicks) {
    return CdpSync(L"Input.dispatchMouseEvent",
                   Fmt(L"{\"type\":\"%ls\",\"x\":%d,\"y\":%d,\"button\":\"%ls\",\"clickCount\":%d}", type, x, y, button, clicks), 5000, r);
  };
  switch (kind) {
    case WVI_CLICK:
    case WVI_DBLCLICK:
    case WVI_RIGHT_CLICK: {
      const wchar_t* btn = kind == WVI_RIGHT_CLICK ? L"right" : L"left";
      if (!mouse(L"mouseMoved", L"none", 0)) return false;
      int times = kind == WVI_DBLCLICK ? 2 : 1;
      for (int i = 1; i <= times; ++i) {
        if (!mouse(L"mousePressed", btn, i) || !mouse(L"mouseReleased", btn, i)) return false;
      }
      return true;
    }
    case WVI_MOVE:
      return mouse(L"mouseMoved", L"none", 0);
    case WVI_TEXT:
      return CdpSync(L"Input.insertText", L"{\"text\":" + JsonStr(text) + L"}", 5000, r);
    case WVI_KEY: {
      int vk = 0, mods = 0;
      std::wstring key, code, t;
      if (!KeySpec(text, vk, mods, key, code, t)) {
        SetErr(WVERR_ARG, L"不认识的按键：" + text);
        return false;
      }
      std::wstring base = Fmt(L"\"windowsVirtualKeyCode\":%d,\"nativeVirtualKeyCode\":%d,\"modifiers\":%d,\"key\":", vk, vk, mods) + JsonStr(key) +
                          L",\"code\":" + JsonStr(code);
      std::wstring down = t.empty() ? L"{\"type\":\"rawKeyDown\"," + base + L"}" : L"{\"type\":\"keyDown\"," + base + L",\"text\":" + JsonStr(t) + L"}";
      return CdpSync(L"Input.dispatchKeyEvent", down, 5000, r) && CdpSync(L"Input.dispatchKeyEvent", L"{\"type\":\"keyUp\"," + base + L"}", 5000, r);
    }
    case WVI_WHEEL: {
      RECT rc = {0, 0, 0, 0};
      if (host) GetClientRect(host, &rc);
      return CdpSync(L"Input.dispatchMouseEvent",
                     Fmt(L"{\"type\":\"mouseWheel\",\"x\":%d,\"y\":%d,\"deltaX\":%d,\"deltaY\":%d}", rc.right / 2, rc.bottom / 2, x, y), 5000, r);
    }
  }
  SetErr(WVERR_ARG, L"未知的输入类型");
  return false;
}

// ---------------------------------------------------------------- 消息与 JS 桥
bool View::PostMsg(const std::wstring& text, bool asJson) {
  if (!RequireReady()) return false;
  HRESULT hr = asJson ? wv->PostWebMessageAsJson(text.c_str()) : wv->PostWebMessageAsString(text.c_str());
  if (FAILED(hr)) {
    SetErr(asJson ? WVERR_ARG : WVERR_FAILED, asJson ? L"发送失败（内容不是合法 JSON？）：" + HrText(hr) : L"发送失败：" + HrText(hr), hr);
    return false;
  }
  return true;
}

// JS 桥脚本（tests/bridgetest.js 从这里原样取出在 Node 里测试）。on/off/once 返回桥对象本身（含代理，链式调用后仍可直接调用绑定的函数）；
// once 原样转交全部参数（"*" 的回调收到事件名和数据）；off 也能取消用 once 加上的回调
static const wchar_t* kBridgeJs =
    L"(function(){var N=%NAME%;var w=window.chrome&&window.chrome.webview;if(!w)return;"
    L"if(window.top!==window||(window[N]&&window[N].__eplBridge))return;"
    L"var seq=0,pend={},ls={};"
    L"w.addEventListener('message',function(ev){var d=ev.data;if(!d||typeof d!=='object'||d.__epl!==1)return;"
    L"if(d.t==='r'){var p=pend[d.id];if(p){delete pend[d.id];if(d.ok)p.res(d.v);else p.rej(new Error(d.e||'EPL error'));}}"
    L"else if(d.t==='e'){var a=ls[d.n];if(a)a.slice().forEach(function(f){try{f(d.v);}catch(x){console.error(x);}});"
    L"var b=ls['*'];if(b)b.slice().forEach(function(f){try{f(d.n,d.v);}catch(x){console.error(x);}});}});"
    L"function call(name){var args=Array.prototype.slice.call(arguments,1);return new Promise(function(res,rej){var id=++seq;pend[id]={res:res,rej:rej};"
    L"try{w.postMessage({__epl:1,t:'c',id:id,n:String(name),a:args});}catch(x){delete pend[id];rej(x);}});}"
    L"var api={__eplBridge:true,call:call,"
    L"on:function(n,f){(ls[n]=ls[n]||[]).push(f);return px;},"
    L"off:function(n,f){var a=ls[n];if(!a)return px;if(!f){delete ls[n];}else{for(var i=0;i<a.length;i++)if(a[i]===f||a[i].__f===f){a.splice(i,1);break;}}return px;},"
    L"once:function(n,f){function g(){api.off(n,g);return f.apply(this,arguments);}g.__f=f;return api.on(n,g);},"
    L"send:function(v){w.postMessage({__epl:1,t:'m',v:v});}};"
    L"var px=(typeof Proxy==='function')?new Proxy(api,{get:function(t,k){if(k in t)return t[k];if(typeof k!=='string'||k==='then'||k==='toJSON')return undefined;"
    L"return function(){return call.apply(null,[k].concat(Array.prototype.slice.call(arguments)));};}}):api;"
    L"try{Object.defineProperty(window,N,{value:px,configurable:true,writable:true});}catch(x){window[N]=px;}"
    L"try{window.dispatchEvent(new CustomEvent(N+'ready'));}catch(x){}})();";

void View::EnsureBridge() {
  if (bridgeOn) return;
  bridgeOn = true;
  if (Ready()) InjectBridge();
}

void View::InjectBridge() {
  if (!Ready()) return;
  if (!bridgeScriptId.empty()) {
    wv->RemoveScriptToExecuteOnDocumentCreated(bridgeScriptId.c_str());
    bridgeScriptId.clear();
  }
  std::wstring js = ReplaceAll(kBridgeJs, L"%NAME%", JsonStr(bridgeName));
  const int vid = id;
  const unsigned gen = ++bridgeGen;
  HRESULT hr = wv->AddScriptToExecuteOnDocumentCreated(
      js.c_str(), Callback<ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler, HRESULT, LPCWSTR>([vid, gen](HRESULT e, LPCWSTR sid) -> HRESULT {
                    RefPtr<View> v = FindView(vid);
                    if (!v || v->closing) return S_OK;
                    if (SUCCEEDED(e) && sid) {
                      // 登记还没完成时桥对象又改了名或被停用：这次登记的脚本已经作废，立即撤掉。原来它会一直留着，
                      // 之后每个网页里都还有旧名字的桥对象（新登记的那段脚本才记成 bridgeScriptId）
                      if (gen != v->bridgeGen || !v->bridgeOn) {
                        if (v->wv) v->wv->RemoveScriptToExecuteOnDocumentCreated(sid);
                      } else {
                        v->bridgeScriptId = sid;
                      }
                    }
                    v->NavigateInitial();  // 脚本已登记，首个页面加载时就有桥对象
                    return S_OK;
                  }).get());
  if (FAILED(hr)) NavigateInitial();
  wv->ExecuteScript(js.c_str(), Callback<ICoreWebView2ExecuteScriptCompletedHandler, HRESULT, LPCWSTR>([](HRESULT, LPCWSTR) -> HRESULT { return S_OK; }).get());  // 当前页面立即可用，不必刷新（不要结果也传空回调：文档没说明这些方法接受空的回调）
}

// 停用 JS 桥：撤掉登记的桥接脚本（之后打开的网页里不再有桥对象），删掉当前网页里的桥对象，还在登记中的桥接脚本完成时撤掉。
// 原来只是不再处理调用：网页里照样有桥对象，调用它得到的 Promise 永远不会结束
void View::DisableBridge() {
  if (!bridgeOn) return;
  bridgeOn = false;
  ++bridgeGen;
  if (!Ready()) return;
  if (!bridgeScriptId.empty()) {
    wv->RemoveScriptToExecuteOnDocumentCreated(bridgeScriptId.c_str());
    bridgeScriptId.clear();
  }
  const std::wstring n = JsonStr(bridgeName);
  const std::wstring js = L"try{var o=window[" + n + L"];if(o&&o.__eplBridge)delete window[" + n + L"];}catch(e){}";
  wv->ExecuteScript(js.c_str(), Callback<ICoreWebView2ExecuteScriptCompletedHandler, HRESULT, LPCWSTR>([](HRESULT, LPCWSTR) -> HRESULT { return S_OK; }).get());
}

// 每条白名单项分成来源部分（协议+主机+端口）与可选的路径部分，两部分分别比较。来源部分只与网页的来源比较，
// 来源里不含路径，通配符也就不会越过主机去匹配路径或查询参数（否则 https://*.a.test 会放行 https://evil.test/?.a.test）。
// 写了路径时再与网址的路径比较：可用通配符，不带通配符时按前缀比较，前缀必须结束在路径边界上
// 未设白名单时只放行本程序自己提供的内容，其余来源要在白名单里列出（写 * 放行全部来源）。原来未设白名单时放行一切来源：
// 程序只要打开过外部网站（采集很常见），那个网站的脚本就能调用绑定的易语言函数。本程序自己的内容是：
//   程序目录（WVO_APP_DIR）及其子目录里的本地文件（file:）；映射目录的虚拟主机（http 与 https）；
//   主机属于 .example、.test、.invalid 这三个保留顶级域名的 https 页面——加载HTML 的 wv2bridge.example、置内存文件与拦截请求
//   返回的页面都放在这类主机下，真实网站不可能使用它们，也没有证书机构会为它们签发证书，网络上的攻击者冒充不了；
//   同样的主机名走 http 时可能被恶意网络（DNS）指向别处，所以不算
// webDirs：给出浏览器替网页写文件的文件夹（WebWrittenDirs ()：各浏览器的用户数据目录、用 WVS_DOWNLOAD_DIR 指定的下载目录）；本次运行里下载过的
// 单个文件另由 WasDownloaded 查。
// 用户数据目录默认就在程序目录里（程序目录\WebView2Data），里面的缓存等文件是网页的内容，不是本程序的。
// 只在要判断本地文件或映射目录的页面时才取：https 页面、设了白名单时都用不上
typedef std::function<std::vector<std::wstring>()> WebDirsFn;
static bool InWebDirs(const std::wstring& path, const WebDirsFn& webDirs) {
  if (!webDirs) return false;
  for (const auto& d : webDirs())
    if (!d.empty() && PathUnder(path, d)) return true;
  return false;
}
static bool OwnContent(const std::wstring& source, const std::map<std::wstring, FolderMap>& mapped, const WebDirsFn& webDirs) {
  // 本地文件只认程序目录及其子目录里的：WebView2 默认允许把外部文件拖进浏览器（拖进来就打开），拖进来的、下载目录与临时目录里的、
  // 网络共享上的页面都不是本程序的内容。原来任何 file: 页面都放行，拖进一个 HTML 文件就能调用全部绑定的函数。
  // 程序目录里浏览器替网页写文件的文件夹（webDirs）也不算
  if (StartsWithI(source, L"file:")) {
    const std::wstring path = PathFromFileUrl(source);
    return PathUnder(path, AppDir()) && !WasDownloaded(path) && !InWebDirs(path, webDirs);
  }
  const std::wstring host = HostOf(source);
  const auto m = mapped.find(host);
  if (m != mapped.end() && (StartsWithI(source, L"https://") || StartsWithI(source, L"http://"))) {
    // 映射目录里同样可能有浏览器替网页写的文件（例如把程序目录映射成主机、下载目录又在程序目录里）：网址对应的文件在 webDirs 里时不算。
    // 原来映射目录的主机整个放行，网页先把 HTML 下载进下载目录、再打开 https://映射主机/下载目录/x.html 就能调用绑定的函数
    if (!webDirs) return true;
    const std::wstring file = PathFromMappedUrl(source, m->second.dir);
    return !file.empty() && !WasDownloaded(file) && !InWebDirs(file, webDirs);
  }
  if (!StartsWithI(source, L"https://")) return false;
  for (const wchar_t* tld : {L".example", L".test", L".invalid"})
    if (host.size() > wcslen(tld) && EndsWithI(host, tld)) return true;
  return false;
}
static bool OriginAllowed(const std::vector<std::wstring>& list, const std::wstring& source, const std::map<std::wstring, FolderMap>& mapped,
                          const WebDirsFn& webDirs = WebDirsFn()) {
  if (list.empty()) return OwnContent(source, mapped, webDirs);
  std::wstring origin = OriginOf(source), src = Lower(source);
  size_t sk = src.find(L"://");
  size_t sp = sk == std::wstring::npos ? std::wstring::npos : src.find_first_of(L"/?#", sk + 3);
  std::wstring srcPath = sp == std::wstring::npos ? std::wstring(L"/") : src.substr(sp);
  for (const auto& p : list) {
    std::wstring pat = Lower(TrimSlash(p));
    if (pat.empty()) continue;
    // 写的是本地文件夹（file: 后面是完整路径）时只按解码后的路径比较：网页的网址里中文、空格等按 UTF-8 写成 %XX，白名单里直接写的
    // “file:///D:/我的程序/ui”按网址原文比较对不上；按网址原文的前缀比较还会放过 file:///D:/ui/..%5C..%5Cx.html 这类写法（解码后在文件夹外面）。
    // 不带通配符时按文件夹（只在路径分隔处、不区分大小写），带通配符时整段匹配。file:///* 这类不是完整路径的写法仍按下面的网址原文规则
    if (StartsWithI(pat, L"file:") && StartsWithI(source, L"file:")) {
      const std::wstring listed = PathFromFileUrl(p);
      if (!listed.empty()) {
        const std::wstring page = PathFromFileUrl(source);
        if (!page.empty() && (listed.find_first_of(L"*?") == std::wstring::npos ? PathUnder(page, listed) : WildMatch(listed, page))) return true;
        continue;
      }
    }
    size_t pk = pat.find(L"://");
    size_t pp = pk == std::wstring::npos ? std::wstring::npos : pat.find(L'/', pk + 3);
    std::wstring patOrigin = pp == std::wstring::npos ? pat : pat.substr(0, pp);
    std::wstring patPath = pp == std::wstring::npos ? std::wstring() : pat.substr(pp);
    if (!WildMatch(patOrigin, origin)) continue;
    if (patPath.empty() || WildMatch(patPath, srcPath)) return true;
    if (srcPath.compare(0, patPath.size(), patPath) == 0 && (srcPath.size() == patPath.size() || wcschr(L"/?#", srcPath[patPath.size()])))
      return true;
  }
  return false;
}
// 默认规则拒绝本地文件或映射目录的页面时的具体原因（其它来源、或其实被放行时返回空文本）。规则分好几条，原来只说“只放行本程序自己的内容”，
// 看不出程序目录里的页面为什么被拒（例如它是本次运行里下载的文件，或在用户数据目录里）。withPaths 为假时不写出本地路径：
// 拒绝说明会回传给被拒绝的网页，不能把程序目录、用户数据目录等路径告诉它；写日志、给程序的错误说明时写出路径
static std::wstring LocalDenyReason(const std::wstring& source, const std::map<std::wstring, FolderMap>& mapped, const WebDirsFn& webDirs,
                                    bool withPaths) {
  auto at = [withPaths](const std::wstring& p) { return withPaths ? L"（" + p + L"）" : std::wstring(); };
  std::wstring file;
  if (StartsWithI(source, L"file:")) {
    file = PathFromFileUrl(source);
    if (file.empty()) return L"无法确定这个本地文件的完整路径";
    if (!PathUnder(file, AppDir())) return L"这个本地文件" + at(file) + L"不在程序目录" + at(AppDir()) + L"里";
  } else {
    const auto m = mapped.find(HostOf(source));
    if (m == mapped.end() || !(StartsWithI(source, L"https://") || StartsWithI(source, L"http://"))) return std::wstring();
    file = PathFromMappedUrl(source, m->second.dir);
    if (file.empty()) return L"这个网址对应的文件不在映射目录里";
  }
  if (WasDownloaded(file)) return L"这个文件" + at(file) + L"是本次运行里下载的，属于网页的内容";
  if (webDirs)
    for (const auto& d : webDirs())
      if (!d.empty() && PathUnder(file, d)) return L"这个文件在浏览器替网页写文件的文件夹" + at(d) + L"里（用户数据目录或下载目录）";
  return std::wstring();
}
// 直接给出位置列表（测试用；DLL 里不调用）
[[maybe_unused]] static bool OriginAllowed(const std::vector<std::wstring>& list, const std::wstring& source, const std::map<std::wstring, FolderMap>& mapped,
                          const std::vector<std::wstring>& dirs) {
  return OriginAllowed(list, source, mapped, WebDirsFn([&dirs] { return dirs; }));
}

static LONG g_callSeq = 0;  // 各界面线程共用，原子自增

void View::OnBridgeMessage(const JVal& m, const std::wstring& source, unsigned gen) {
  if (!OriginAllowed(bridgeOrigins, source, mappedHosts, WebWrittenDirs)) {
    // 拒绝时写明来源与放行的办法：网页端的 Promise 收到这段说明，照着把来源加进白名单即可
    const std::wstring reason = bridgeOrigins.empty() ? LocalDenyReason(source, mappedHosts, WebWrittenDirs, false) : std::wstring();
    const std::wstring why = bridgeOrigins.empty()
                                 ? L"来源 " + OriginOf(source) + L" 不能调用 " + bridgeName + L"：" + (reason.empty() ? std::wstring() : reason + L"。") +
                                       L"未设置 JS 桥白名单时只放行本程序自己的内容（程序目录里的本地文件（用户数据目录、下载目录与下载过的文件除外）、映射目录、加载HTML 的页面，"
                                       L"以及 .example、.test、.invalid 主机下的 https 页面）。要放行这个来源，用 置桥接白名单（WVS_BRIDGE_ORIGINS）加上它，写 * 放行全部来源"
                                 : L"来源 " + OriginOf(source) + L" 不在 JS 桥白名单内";
    const std::wstring detail = reason.empty() ? std::wstring() : LocalDenyReason(source, mappedHosts, WebWrittenDirs, true);
    Log(L"JS 桥拒绝：%ls%ls%ls", why.c_str(), detail.empty() ? L"" : L"；", detail.c_str());
    if (const JVal* idv = m.Get(L"id")) {
      std::wstring r = L"{\"__epl\":1,\"t\":\"r\",\"id\":" + idv->Dump() + L",\"ok\":false,\"e\":" + JsonStr(why) + L"}";
      wv->PostWebMessageAsJson(r.c_str());
    }
    return;
  }
  const JVal* t = m.Get(L"t");
  std::wstring type = t ? t->Text() : std::wstring();
  if (type == L"m") {
    const JVal* val = m.Get(L"v");
    std::wstring json = val ? val->Dump() : L"null";
    std::wstring text = val && val->t == JVal::STR ? val->s : std::wstring();
    std::string a = ToCP(text), b = ToCPJson(json), c = ToCP(source);
    Fire(WVE_MESSAGE, {(intptr_t)id, (intptr_t)a.c_str(), (intptr_t)b.c_str(), (intptr_t)c.c_str()});
    return;
  }
  if (type != L"c") return;
  const JVal* jid = m.Get(L"id");
  const JVal* jn = m.Get(L"n");
  const JVal* ja = m.Get(L"a");
  if (!jid || !jn) return;
  int callId = (int)InterlockedIncrement(&g_callSeq);
  std::wstring jsId = jid->Dump();
  std::wstring name = jn->Text();
  pendingCalls.insert(callId);
  sprops[-callId] = jsId;  // 调用ID → 网页端序号（负键，避开属性号）
  callGen[callId] = gen;
  void* fn = nullptr;
  auto it = binds.find(name);
  if (it != binds.end()) fn = it->second;
  else if (HasCb(WVE_JS_CALL)) fn = cb[WVE_JS_CALL];
  if (!fn) {
    BridgeReply(callId, false, L"易语言端没有绑定函数：" + name);
    return;
  }
  EventCtx ctx;
  ctx.n[WVK_CALL_ID] = callId;
  ctx.s[WVK_ORIGIN] = OriginOf(source);
  ctx.s[WVK_URL] = source;
  std::string sn = ToCP(name), sa = ToCPJson(ja ? ja->Dump() : L"[]");
  FireFn(fn, WVE_JS_CALL, {(intptr_t)id, (intptr_t)sn.c_str(), (intptr_t)sa.c_str(), (intptr_t)callId}, &ctx);
  if (closing || !pendingCalls.count(callId)) return;  // 回调里已用 WV_BindReturn 返回
  auto er = ctx.setS.find(WVK_SET_ERROR);
  auto rs = ctx.setS.find(WVK_SET_RESULT);
  auto rt = ctx.setS.find(WVK_SET_RESULT_TEXT);
  if (er != ctx.setS.end()) BridgeReply(callId, false, er->second);
  else if (rt != ctx.setS.end()) BridgeReply(callId, true, JsonStr(rt->second));
  else if (rs != ctx.setS.end()) BridgeReply(callId, true, rs->second);
  else if (ctx.setN.count(WVK_DEFER) && ctx.setN[WVK_DEFER]) return;
  else BridgeReply(callId, true, L"null");
}

bool View::BridgeReply(int callId, bool ok, const std::wstring& payload) {
  if (!pendingCalls.count(callId)) {
    SetErr(WVERR_ARG, L"调用ID不存在或已经返回过");
    return false;
  }
  pendingCalls.erase(callId);
  std::wstring jsId = sprops[-callId];
  sprops.erase(-callId);
  auto g = callGen.find(callId);
  const bool sameDoc = g == callGen.end() || g->second == docGen;
  if (g != callGen.end()) callGen.erase(g);
  if (!RequireReady()) return false;  // 浏览器正在重建或已经失败：说明原因（原来返回失败却没有错误说明）
  // 发起调用的网页已经换成别的文档（延迟回传期间打开了别的页面、内核重建）：结果交给的会是新网页，它可能来自别的来源，
  // 用 chrome.webview 的 message 事件就能读到。原来照样送出
  if (!sameDoc) {
    SetErr(WVERR_FAILED, L"发起这次调用的网页已经离开（打开了别的页面），结果没有送出");
    return false;
  }
  std::wstring msg;
  if (ok) {
    JVal tmp;
    std::wstring v = JsonParse(payload, tmp) ? payload : JsonStr(payload);
    msg = L"{\"__epl\":1,\"t\":\"r\",\"id\":" + jsId + L",\"ok\":true,\"v\":" + v + L"}";
  } else {
    msg = L"{\"__epl\":1,\"t\":\"r\",\"id\":" + jsId + L",\"ok\":false,\"e\":" + JsonStr(payload) + L"}";
  }
  HRESULT hr = wv->PostWebMessageAsJson(msg.c_str());
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"结果没有送到网页：" + HrText(hr), hr);
    return false;
  }
  return true;
}

bool View::Emit(const std::wstring& name, const std::wstring& json) {
  if (!RequireReady()) return false;
  // 推送事件与 JS 桥的调用同样只对允许的网页：网页已经换成外部网站时，推送的数据会被它读到（chrome.webview 的 message 事件）。
  // 先核对来源再启用 JS 桥：被拒绝时没有副作用（不会把停用的桥重新打开，也不往外部网页里注入桥对象）
  CoStr cur;
  wv->get_Source(cur.put());
  if (!OriginAllowed(bridgeOrigins, cur.str(), mappedHosts, WebWrittenDirs)) {
    const std::wstring reason = bridgeOrigins.empty() ? LocalDenyReason(cur.str(), mappedHosts, WebWrittenDirs, true) : std::wstring();
    SetErr(WVERR_DENIED, L"当前网页的来源 " + OriginOf(cur.str()) + L" 不在 JS 桥允许的范围内（见 置桥接白名单）" +
                             (reason.empty() ? std::wstring() : L"：" + reason) + L"，事件没有发送");
    return false;
  }
  EnsureBridge();
  JVal tmp;
  std::wstring v = json.empty() ? L"null" : (JsonParse(json, tmp) ? json : JsonStr(json));
  std::wstring msg = L"{\"__epl\":1,\"t\":\"e\",\"n\":" + JsonStr(name) + L",\"v\":" + v + L"}";
  HRESULT hr = wv->PostWebMessageAsJson(msg.c_str());
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"推送事件失败：" + HrText(hr), hr);
    return false;
  }
  return true;
}

HRESULT View::OnWebMessage(ICoreWebView2WebMessageReceivedEventArgs* a) {
  CoStr js, src, text;
  a->get_WebMessageAsJson(js.put());
  a->get_Source(src.put());
  std::wstring t;
  if (SUCCEEDED(a->TryGetWebMessageAsString(text.put()))) t = text.str();
  std::wstring json = js.str(), source = src.str();
  // 1.8.2：这次 postMessage 附带的文件（chrome.webview.postMessageWithAdditionalObjects）：取出文件路径，每行一个（需要内核支持 ICoreWebView2WebMessageReceivedEventArgs2 与 ICoreWebView2File，运行时 113 起）。
  // 事件参数只在本回调内有效，必须现在取，不能带进投递的任务
  std::wstring files;
  if (auto a2 = ComPtr<ICoreWebView2WebMessageReceivedEventArgs>::From(a).as<ICoreWebView2WebMessageReceivedEventArgs2>()) {
    ComPtr<ICoreWebView2ObjectCollectionView> objs;
    if (SUCCEEDED(a2->get_AdditionalObjects(objs.put())) && objs) {
      UINT n = 0;
      objs->get_Count(&n);
      for (UINT i = 0; i < n; ++i) {
        ComPtr<IUnknown> unk;
        if (FAILED(objs->GetValueAtIndex(i, unk.put())) || !unk) continue;  // null/undefined 项为 nullptr
        if (auto file = unk.as<ICoreWebView2File>()) {
          CoStr p;
          if (SUCCEEDED(file->get_Path(p.put())) && p.p) {
            if (!files.empty()) files += L"\n";
            files += p.str();
          }
        }
      }
    }
  }
  const int vid = id;
  const unsigned gen = docGen;  // 收到消息时的文档：处理时网页可能已经换了
  // 到事件处理函数之外再处理：绑定函数里可以直接调用 执行JS、截图 等同步方法
  Post([vid, json, source, t, gen, files] {
    WV_TASK(vid);
    v->HandleWebMessage(json, source, t, gen, files);
  });
  return S_OK;
}

void View::HandleWebMessage(const std::wstring& json, const std::wstring& source, const std::wstring& text, unsigned gen, const std::wstring& files) {
  if (json.find(L"\"__epl\"") != std::wstring::npos) {
    JVal m;
    if (JsonParse(json, m) && m.t == JVal::OBJ) {
      const JVal* mark = m.Get(L"__epl");
      if (mark && mark->Int() == 1) {
        if (bridgeOn) {
          OnBridgeMessage(m, source, gen);
          return;
        }
        // JS 桥已停用：网页里留下的桥对象（停用前拿到的引用）发来调用时如实回绝，Promise 不会一直等下去；
        // 其它消息照旧交给“收到网页消息”事件
        const JVal* ty = m.Get(L"t");
        const JVal* idv = m.Get(L"id");
        if (ty && ty->Text() == L"c" && idv && gen == docGen && Ready()) {
          std::wstring r = L"{\"__epl\":1,\"t\":\"r\",\"id\":" + idv->Dump() + L",\"ok\":false,\"e\":" + JsonStr(L"JS 桥已停用") + L"}";
          wv->PostWebMessageAsJson(r.c_str());
          return;
        }
      }
    }
  }
  if (!HasCb(WVE_MESSAGE)) return;
  std::string s1 = ToCP(text), s2 = ToCPJson(json), s3 = ToCP(source);
  // 1.8.2：附带的文件路径放进回调上下文，回调里用 WV_EvGet(WVK_FILES) 取；没有文件时不设，取到空
  EventCtx ctx;
  if (!files.empty()) ctx.s[WVK_FILES] = files;
  Fire(WVE_MESSAGE, {(intptr_t)id, (intptr_t)s1.c_str(), (intptr_t)s2.c_str(), (intptr_t)s3.c_str()}, &ctx);
}

// ---------------------------------------------------------------- Cookie 与数据
static ComPtr<ICoreWebView2CookieManager> CookieMgr(View* v) {
  ComPtr<ICoreWebView2CookieManager> m;
  auto w2 = v->wv.as<ICoreWebView2_2>();
  if (w2) w2->get_CookieManager(m.put());
  if (!m) SetErr(WVERR_UNSUPPORTED, L"当前内核不支持 Cookie 管理（需要 Edge 89+）", E_NOINTERFACE);
  return m;
}

static bool FetchCookies(View* v, const std::wstring& url, ComPtr<ICoreWebView2CookieList>& list) {
  if (!CanWait()) return false;
  auto m = CookieMgr(v);
  if (!m) return false;
  struct St { bool done = false; HRESULT hr = E_PENDING; ComPtr<ICoreWebView2CookieList> l; };
  auto st = std::make_shared<St>();
  HRESULT hr = m->GetCookies(url.empty() ? nullptr : NormalizeUrl(url).c_str(),
                             Callback<ICoreWebView2GetCookiesCompletedHandler, HRESULT, ICoreWebView2CookieList*>([st](HRESULT e, ICoreWebView2CookieList* l) -> HRESULT {
                               st->hr = e;
                               st->l = ComPtr<ICoreWebView2CookieList>::From(l);
                               st->done = true;
                               return S_OK;
                             }).get());
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"读取 Cookie 失败：" + HrText(hr), hr);
    return false;
  }
  RefPtr<View> hold(v);
  if (!PumpUntil([&] { return st->done || v->closing; }, 10000) || !st->done) {
    SetErr(WVERR_TIMEOUT, L"读取 Cookie 超时");
    return false;
  }
  if (FAILED(st->hr) || !st->l) {
    SetErr(WVERR_FAILED, L"读取 Cookie 失败：" + HrText(st->hr), st->hr);
    return false;
  }
  list = st->l;
  return true;
}

bool View::GetCookies(const std::wstring& url, int fmt, std::wstring& out) {
  if (!RequireReady()) return false;
  ComPtr<ICoreWebView2CookieList> list;
  if (!FetchCookies(this, url, list)) return false;
  UINT count = 0;
  list->get_Count(&count);
  out.clear();
  if (fmt == 0) out = L"[";
  if (fmt == 2) out = L"# Netscape HTTP Cookie File\r\n";
  bool first = true;
  for (UINT i = 0; i < count; ++i) {
    ComPtr<ICoreWebView2Cookie> c;
    if (FAILED(list->GetValueAtIndex(i, c.put())) || !c) continue;
    CoStr n, val, dom, path;
    c->get_Name(n.put());
    c->get_Value(val.put());
    c->get_Domain(dom.put());
    c->get_Path(path.put());
    double exp = -1;
    c->get_Expires(&exp);
    BOOL http = FALSE, sec = FALSE, sess = FALSE;
    c->get_IsHttpOnly(&http);
    c->get_IsSecure(&sec);
    c->get_IsSession(&sess);
    COREWEBVIEW2_COOKIE_SAME_SITE_KIND ss = COREWEBVIEW2_COOKIE_SAME_SITE_KIND_LAX;
    c->get_SameSite(&ss);
    if (fmt == 1) {
      if (!out.empty()) out += L"; ";
      out += n.str() + L"=" + val.str();
    } else if (fmt == 2) {
      std::wstring d = dom.str();
      out += (http ? L"#HttpOnly_" : L"") + d + L"\t" + (!d.empty() && d[0] == L'.' ? L"TRUE" : L"FALSE") + L"\t" + path.str() + L"\t" +
             (sec ? L"TRUE" : L"FALSE") + L"\t" + std::to_wstring(sess || exp < 0 ? 0LL : (long long)exp) + L"\t" + n.str() + L"\t" + val.str() + L"\r\n";
    } else {
      if (!first) out += L",";  // 按“已输出过”判断：跳过的项不会在开头留下多余的逗号
      first = false;
      const wchar_t* sameSite = ss == COREWEBVIEW2_COOKIE_SAME_SITE_KIND_NONE ? L"None" : ss == COREWEBVIEW2_COOKIE_SAME_SITE_KIND_STRICT ? L"Strict" : L"Lax";
      out += L"{\"name\":" + JsonStr(n.str()) + L",\"value\":" + JsonStr(val.str()) + L",\"domain\":" + JsonStr(dom.str()) + L",\"path\":" +
             JsonStr(path.str()) + L",\"expires\":" + Fmt(L"%.0f", sess ? -1.0 : exp) + L",\"httpOnly\":" + (http ? L"true" : L"false") +
             L",\"secure\":" + (sec ? L"true" : L"false") + L",\"session\":" + (sess ? L"true" : L"false") + L",\"sameSite\":\"" + sameSite + L"\"}";
    }
  }
  if (fmt == 0) out += L"]";
  return true;
}

bool View::SetCookie(const std::wstring& url, const std::wstring& name, const std::wstring& value, const std::wstring& domain, const std::wstring& path,
                     int expires, int flags) {
  if (!RequireReady()) return false;
  auto m = CookieMgr(this);
  if (!m) return false;
  std::wstring d = domain.empty() ? HostOf(NormalizeUrl(url)) : domain;
  if (d.empty()) {
    SetErr(WVERR_ARG, L"请提供网址或域名");
    return false;
  }
  ComPtr<ICoreWebView2Cookie> c;
  HRESULT hr = m->CreateCookie(name.c_str(), value.c_str(), d.c_str(), path.empty() ? L"/" : path.c_str(), c.put());
  if (SUCCEEDED(hr) && c) {
    // 过期时间按无符号 32 位解释（可到 2106 年）：有符号 int 在 2038-01-19 之后变成负数，原来会被悄悄当成会话 Cookie。
    // 内核（Chromium 104 起）会把超过 400 天的过期时间压到 400 天，但仍是持久 Cookie
    if (expires != 0) c->put_Expires((double)(uint32_t)expires);
    if (flags & 1) c->put_IsHttpOnly(TRUE);
    if (flags & 2) c->put_IsSecure(TRUE);
    if (flags & 0x200) c->put_SameSite(COREWEBVIEW2_COOKIE_SAME_SITE_KIND_STRICT);
    else if (flags & 0x100) c->put_SameSite(COREWEBVIEW2_COOKIE_SAME_SITE_KIND_LAX);
    else if (flags & 0x400) c->put_SameSite(COREWEBVIEW2_COOKIE_SAME_SITE_KIND_NONE);
    hr = m->AddOrUpdateCookie(c.get());
  }
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"设置 Cookie 失败：" + HrText(hr), hr);
    return false;
  }
  return true;
}

bool View::SetCookieString(const std::wstring& url, const std::wstring& cookies) {
  int n = 0;
  for (const auto& part : Split(cookies, L";\r\n")) {  // Cookie 的值里不会有回车换行：每行一个也能用
    size_t eq = part.find(L'=');
    if (eq == std::wstring::npos || eq == 0) continue;
    std::wstring k = Trim(part.substr(0, eq)), v = Trim(part.substr(eq + 1));
    std::wstring lk = Lower(k);
    if (lk == L"path" || lk == L"domain" || lk == L"expires" || lk == L"max-age" || lk == L"samesite") continue;
    if (!SetCookie(url, k, v, std::wstring(), L"/", 0, 0)) return false;
    ++n;
  }
  if (!n) SetErr(WVERR_ARG, L"没有解析到“名=值”形式的 Cookie");
  return n > 0;
}

bool View::DeleteCookies(const std::wstring& url, const std::wstring& name) {
  if (!RequireReady()) return false;
  auto m = CookieMgr(this);
  if (!m) return false;
  HRESULT hr = S_OK;
  if (url.empty() && name.empty()) hr = m->DeleteAllCookies();
  else if (!name.empty()) hr = m->DeleteCookies(name.c_str(), url.empty() ? nullptr : NormalizeUrl(url).c_str());
  else {
    ComPtr<ICoreWebView2CookieList> list;
    if (!FetchCookies(this, url, list)) return false;
    UINT count = 0;
    list->get_Count(&count);
    for (UINT i = 0; i < count; ++i) {
      ComPtr<ICoreWebView2Cookie> c;
      if (SUCCEEDED(list->GetValueAtIndex(i, c.put())) && c) m->DeleteCookie(c.get());
    }
  }
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"删除 Cookie 失败：" + HrText(hr), hr);
    return false;
  }
  return true;
}

bool View::ClearData(int kinds) {
  if (!RequireReady()) return false;
  if (!CanWait()) return false;
  auto w13 = wv.as<ICoreWebView2_13>();
  ComPtr<ICoreWebView2Profile> prof;
  if (w13) w13->get_Profile(prof.put());
  auto p2 = prof ? prof.as<ICoreWebView2Profile2>() : ComPtr<ICoreWebView2Profile2>();
  if (!p2) {  // 老内核：用 DevTools 协议清缓存与 Cookie
    std::wstring r;
    bool ok = CdpSync(L"Network.clearBrowserCache", L"{}", 15000, r);
    ok = CdpSync(L"Network.clearBrowserCookies", L"{}", 15000, r) && ok;
    return ok;
  }
  auto st = std::make_shared<SyncState>();
  auto h = Callback<ICoreWebView2ClearBrowsingDataCompletedHandler, HRESULT>([st](HRESULT e) -> HRESULT {
    st->hr = e;
    st->done = true;
    return S_OK;
  });
  HRESULT hr = kinds == 0 ? p2->ClearBrowsingDataAll(h.get()) : p2->ClearBrowsingData((COREWEBVIEW2_BROWSING_DATA_KINDS)kinds, h.get());
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"清除数据失败：" + HrText(hr), hr);
    return false;
  }
  if (!WaitState(this, st, 60000)) return false;
  if (FAILED(st->hr)) {
    SetErr(WVERR_FAILED, L"清除数据失败：" + HrText(st->hr), st->hr);
    return false;
  }
  return true;
}

// ---------------------------------------------------------------- 截图与打印
bool View::Capture(int fmt, bool full, std::vector<unsigned char>& out) {
  if (!RequireReady()) return false;
  if (!CanWait()) return false;
  if (full) {
    std::wstring m;
    if (!CdpSync(L"Page.getLayoutMetrics", L"{}", 10000, m)) return false;
    JVal j;
    JsonParse(m, j);
    const JVal* cs = j.Get(L"cssContentSize");
    if (!cs) cs = j.Get(L"contentSize");
    double w = cs && cs->Get(L"width") ? cs->Get(L"width")->Num() : 0, h = cs && cs->Get(L"height") ? cs->Get(L"height")->Num() : 0;
    if (w < 1 || h < 1) {
      SetErr(WVERR_FAILED, L"取页面尺寸失败");
      return false;
    }
    if (h > 16000) h = 16000;  // 超长页面截断到约 16000 像素（GPU 纹理上限）
    std::wstring params = Fmt(L"{\"format\":\"%ls\",%ls\"captureBeyondViewport\":true,\"fromSurface\":true,\"clip\":{\"x\":0,\"y\":0,\"width\":%d,\"height\":%d,\"scale\":1}}",
                              fmt == 1 ? L"jpeg" : L"png", fmt == 1 ? L"\"quality\":92," : L"", (int)(w + 0.5), (int)(h + 0.5));
    std::wstring r;
    if (!CdpSync(L"Page.captureScreenshot", params, 30000, r)) return false;
    JVal rj;
    if (!JsonParse(r, rj) || !rj.Get(L"data")) {
      SetErr(WVERR_FAILED, L"截图返回内容无效");
      return false;
    }
    if (!Base64Decode(ToUtf8(rj.Get(L"data")->s), out) || out.empty()) {
      SetErr(WVERR_FAILED, L"截图数据解码失败");
      return false;
    }
    return true;
  }
  ComPtr<IStream> s;
  CreateStreamOnHGlobal(nullptr, TRUE, s.put());
  if (!s) {
    SetErr(WVERR_FAILED, L"创建内存流失败");
    return false;
  }
  auto st = std::make_shared<SyncState>();
  HRESULT hr = wv->CapturePreview(fmt == 1 ? COREWEBVIEW2_CAPTURE_PREVIEW_IMAGE_FORMAT_JPEG : COREWEBVIEW2_CAPTURE_PREVIEW_IMAGE_FORMAT_PNG, s.get(),
                                  Callback<ICoreWebView2CapturePreviewCompletedHandler, HRESULT>([st](HRESULT e) -> HRESULT {
                                    st->hr = e;
                                    st->done = true;
                                    return S_OK;
                                  }).get());
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"截图失败：" + HrText(hr), hr);
    return false;
  }
  if (!WaitState(this, st, 15000)) return false;
  if (FAILED(st->hr)) {
    SetErr(WVERR_FAILED, L"截图失败：" + HrText(st->hr), st->hr);
    return false;
  }
  ReadStream(s.get(), out);
  if (out.empty()) {
    SetErr(WVERR_FAILED, L"截图为空（浏览器不可见或尺寸为 0？）");
    return false;
  }
  return true;
}

bool View::PrintPdf(const std::wstring& path, bool landscape, DWORD timeout) {
  if (!RequireReady()) return false;
  if (!CanWait()) return false;
  auto w7 = wv.as<ICoreWebView2_7>();
  if (!w7) {
    SetErr(WVERR_UNSUPPORTED, L"当前内核不支持打印 PDF（需要 Edge 97+）", E_NOINTERFACE);
    return false;
  }
  ComPtr<ICoreWebView2PrintSettings> ps;
  auto e6 = env && env->env ? env->env.as<ICoreWebView2Environment6>() : ComPtr<ICoreWebView2Environment6>();
  if (e6) e6->CreatePrintSettings(ps.put());
  if (!ps && landscape) {  // 拿不到打印设置就无法指定方向：如实报告，不能悄悄按纵向打印还返回成功
    SetErr(WVERR_UNSUPPORTED, L"当前内核不支持设置打印方向（横向打印需要 Edge 97+）", E_NOINTERFACE);
    return false;
  }
  if (ps) {
    ps->put_Orientation(landscape ? COREWEBVIEW2_PRINT_ORIENTATION_LANDSCAPE : COREWEBVIEW2_PRINT_ORIENTATION_PORTRAIT);
    ps->put_ShouldPrintBackgrounds(TRUE);
  }
  std::wstring full = AppPath(path);
  EnsureDir(PathDir(full));
  auto st = std::make_shared<SyncState>();
  HRESULT hr = w7->PrintToPdf(full.c_str(), ps.get(), Callback<ICoreWebView2PrintToPdfCompletedHandler, HRESULT, BOOL>([st](HRESULT e, BOOL ok) -> HRESULT {
                                                       st->hr = e;
                                                       st->flag = ok;
                                                       st->done = true;
                                                       return S_OK;
                                                     }).get());
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"打印 PDF 失败：" + HrText(hr), hr);
    return false;
  }
  if (!WaitState(this, st, timeout)) return false;
  if (FAILED(st->hr) || !st->flag) {
    SetErr(WVERR_FAILED, L"打印 PDF 失败（路径不可写或页面正在打印？）", st->hr);
    return false;
  }
  return true;
}

// ---------------------------------------------------------------- DevTools 事件订阅
bool View::CdpSubscribe(const std::wstring& ev, bool on) {
  if (!on) cdpEvents.erase(ev);  // 退订在重建期间也算数：重建后不再订阅
  if (!on && !Ready()) return true;
  if (!RequireReady()) return false;
  auto it = cdpSubs.find(ev);
  if (!on) {
    if (it != cdpSubs.end()) {
      it->second.r->remove_DevToolsProtocolEventReceived(it->second.t);
      cdpSubs.erase(it);
    }
    return true;
  }
  if (it != cdpSubs.end()) return true;
  CdpSub sub;
  HRESULT hr = wv->GetDevToolsProtocolEventReceiver(ev.c_str(), sub.r.put());
  if (SUCCEEDED(hr) && sub.r) {
    const int vid = id;
    std::wstring name = ev;
    hr = sub.r->add_DevToolsProtocolEventReceived(
        Callback<ICoreWebView2DevToolsProtocolEventReceivedEventHandler, ICoreWebView2*, ICoreWebView2DevToolsProtocolEventReceivedEventArgs*>(
            [vid, name](ICoreWebView2*, ICoreWebView2DevToolsProtocolEventReceivedEventArgs* a) -> HRESULT {
              RefPtr<View> v = FindView(vid);
              if (!v || v->closing) return S_OK;
              CoStr p;
              a->get_ParameterObjectAsJson(p.put());
              std::wstring params = p.str();
              v->Post([vid, name, params] {
                WV_TASK(vid);
                std::string sn = ToCP(name), sp = ToCPJson(params);
                v->Fire(WVE_CDP_EVENT, {(intptr_t)vid, (intptr_t)sn.c_str(), (intptr_t)sp.c_str()});
              });
              return S_OK;
            })
            .get(),
        &sub.t);
  }
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"订阅 DevTools 事件失败：" + HrText(hr), hr);
    return false;
  }
  cdpSubs[ev] = sub;
  cdpEvents.insert(ev);
  return true;
}

// 浏览器重建（内核崩溃后自动恢复、在卡片上点“重试”、装好运行时）后，把只存在于旧内核里的设置重新做一遍：映射目录、
// 程序注入的脚本（编号不变，移除注入JS 照常可用）、DevTools 事件订阅（协议的 enable 等调用要由程序在“创建完成”事件里重新执行）。
// 原来重建后这些都没了：用映射目录显示界面的程序恢复后打不开自己的页面。首次创建时登记表都是空的。
// 返回仍在登记中的脚本数：大于 0 且没有 JS 桥时，首次导航等最后一段登记完成（有 JS 桥时等桥接脚本，它在这些脚本之后登记）
int View::ReapplyState() {
  if (!mappedHosts.empty()) {
    auto w3 = wv.as<ICoreWebView2_3>();
    for (const auto& kv : mappedHosts)
      if (!w3 || FAILED(w3->SetVirtualHostNameToFolderMapping(kv.second.host.c_str(), kv.second.dir.c_str(), (COREWEBVIEW2_HOST_RESOURCE_ACCESS_KIND)kv.second.access)))
        Log(L"浏览器 #%d 重建后重新映射目录失败：%ls", id, kv.second.host.c_str());
  }
  std::set<std::wstring> evs;
  evs.swap(cdpEvents);
  for (const auto& e : evs)
    if (!CdpSubscribe(e, true)) Log(L"浏览器 #%d 重建后重新订阅 DevTools 事件失败：%ls", id, e.c_str());
  auto left = std::make_shared<int>(0);
  const int vid = id;
  for (const auto& s : initScripts) {
    const std::wstring uid = s.userId;
    ++*left;
    HRESULT hr = wv->AddScriptToExecuteOnDocumentCreated(
        s.js.c_str(), Callback<ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler, HRESULT, LPCWSTR>([vid, uid, left](HRESULT e, LPCWSTR sid) -> HRESULT {
                        RefPtr<View> v = FindView(vid);
                        if (!v || v->closing) return S_OK;
                        bool kept = false;
                        for (auto& x : v->initScripts)
                          if (x.userId == uid) {
                            kept = true;
                            if (SUCCEEDED(e) && sid) x.curId = sid;
                          }
                        // 登记还没完成时程序已经移除了这段脚本：刚登记上的要立即撤掉，否则它会一直留在新内核里
                        if (!kept && SUCCEEDED(e) && sid && v->wv) v->wv->RemoveScriptToExecuteOnDocumentCreated(sid);
                        if (--*left == 0 && !v->bridgeOn) v->NavigateInitial();
                        return S_OK;
                      }).get());
    if (FAILED(hr)) {
      --*left;
      Log(L"浏览器 #%d 重建后重新注入脚本失败：%ls", id, HrText(hr).c_str());
    }
  }
  return *left;
}

// ---------------------------------------------------------------- 网络：请求拦截、内存文件、屏蔽、响应捕获
// 交给 WebView2 过滤器的网址：去掉查询串和锚点，协议和主机转小写（浏览器内部即小写），路径保持原样
static std::wstring FilterUrl(const std::wstring& in) {
  std::wstring u = in.substr(0, in.find_first_of(L"?#"));
  size_t p = u.find(L"://");
  size_t slash = p == std::wstring::npos ? std::wstring::npos : u.find(L'/', p + 3);
  return Lower(u.substr(0, slash)) + (slash == std::wstring::npos ? std::wstring() : u.substr(slash));
}

static std::wstring StripQuery(const std::wstring& u) {
  size_t k = u.find_first_of(L"?#");
  return Lower(k == std::wstring::npos ? u : u.substr(0, k));
}
static std::wstring GuessMime(const std::wstring& url) {
  std::wstring u = StripQuery(url);
  struct M { const wchar_t* ext; const wchar_t* mime; };
  static const M table[] = {{L".html", L"text/html; charset=utf-8"}, {L".htm", L"text/html; charset=utf-8"}, {L".css", L"text/css; charset=utf-8"},
                            {L".js", L"text/javascript; charset=utf-8"}, {L".mjs", L"text/javascript; charset=utf-8"}, {L".json", L"application/json; charset=utf-8"},
                            {L".svg", L"image/svg+xml"}, {L".png", L"image/png"}, {L".jpg", L"image/jpeg"}, {L".jpeg", L"image/jpeg"},
                            {L".gif", L"image/gif"}, {L".webp", L"image/webp"}, {L".ico", L"image/x-icon"}, {L".woff2", L"font/woff2"},
                            {L".woff", L"font/woff"}, {L".ttf", L"font/ttf"}, {L".mp4", L"video/mp4"}, {L".webm", L"video/webm"},
                            {L".mp3", L"audio/mpeg"}, {L".wav", L"audio/wav"}, {L".txt", L"text/plain; charset=utf-8"}, {L".xml", L"application/xml"},
                            {L".wasm", L"application/wasm"}, {L".pdf", L"application/pdf"}};
  for (const M& m : table)
    if (EndsWithI(u, m.ext)) return m.mime;
  if (!u.empty() && u.back() == L'/') return L"text/html; charset=utf-8";
  return L"application/octet-stream";
}

void View::EnsureRequestHook() {
  if (!Ready()) return;
  if (!reqHooked) {
    reqHooked = true;
    const int vid = id;
    EventRegistrationToken tk;
    wv->add_WebResourceRequested(Callback<ICoreWebView2WebResourceRequestedEventHandler, ICoreWebView2*, ICoreWebView2WebResourceRequestedEventArgs*>(
                                     [vid](ICoreWebView2*, ICoreWebView2WebResourceRequestedEventArgs* a) -> HRESULT {
                                       RefPtr<View> v = FindView(vid);
                                       if (!v || v->closing || !v->wv) return S_OK;
                                       return v->OnWebResourceRequested(a);
                                     }).get(),
                                 &tk);
  }
  SyncRequestFilters();
}

void View::SyncRequestFilters() {
  if (!Ready()) return;
  std::set<std::wstring> want;
  auto add = [&](const std::wstring& pat, int ctx) { want.insert(std::to_wstring(ctx) + L"|" + pat); };
  for (const auto& f : reqFilters) add(f.pat, f.ctx);
  for (const auto& kv : memFiles)
    if (!kv.second.page) add((kv.second.url.empty() ? kv.first : kv.second.url) + L"*", COREWEBVIEW2_WEB_RESOURCE_CONTEXT_ALL);
  if (!htmlPages.empty()) add(std::wstring(kHtmlPageOrigin) + L"/*", COREWEBVIEW2_WEB_RESOURCE_CONTEXT_ALL);  // 加载HTML 的页面主机整体交给本进程应答
  if (!blockUrls.empty()) add(L"*", COREWEBVIEW2_WEB_RESOURCE_CONTEXT_ALL);
  if (blockImages) add(L"*", COREWEBVIEW2_WEB_RESOURCE_CONTEXT_IMAGE);
  for (const auto& k : want) {
    if (addedFilters.count(k)) continue;
    size_t bar = k.find(L'|');
    int ctx = (int)wcstol(k.c_str(), nullptr, 10);
    if (SUCCEEDED(wv->AddWebResourceRequestedFilter(k.substr(bar + 1).c_str(), (COREWEBVIEW2_WEB_RESOURCE_CONTEXT)ctx))) addedFilters.insert(k);
  }
  for (auto it = addedFilters.begin(); it != addedFilters.end();) {
    if (want.count(*it)) { ++it; continue; }
    size_t bar = it->find(L'|');
    int ctx = (int)wcstol(it->c_str(), nullptr, 10);
    wv->RemoveWebResourceRequestedFilter(it->substr(bar + 1).c_str(), (COREWEBVIEW2_WEB_RESOURCE_CONTEXT)ctx);
    it = addedFilters.erase(it);
  }
}

bool View::AddRequestFilter(const std::wstring& pat, int ctx) {
  for (const auto& f : reqFilters)
    if (f.pat == pat && f.ctx == ctx) return true;
  reqFilters.push_back({pat.empty() ? L"*" : pat, ctx});
  if (Ready()) EnsureRequestHook();
  return true;
}
bool View::RemoveRequestFilter(const std::wstring& pat, int ctx) {
  reqFilters.erase(std::remove_if(reqFilters.begin(), reqFilters.end(), [&](const ReqFilter& f) { return f.pat == pat && f.ctx == ctx; }), reqFilters.end());
  if (Ready()) SyncRequestFilters();
  return true;
}

static std::wstring HeadersJson(ICoreWebView2HttpHeadersCollectionIterator* it) {
  std::wstring s = L"{";
  bool first = true;
  BOOL has = FALSE;
  while (it && SUCCEEDED(it->get_HasCurrentHeader(&has)) && has) {
    CoStr n, v;
    it->GetCurrentHeader(n.put(), v.put());
    if (!first) s += L",";
    first = false;
    s += JsonStr(n.str()) + L":" + JsonStr(v.str());
    BOOL next = FALSE;
    if (FAILED(it->MoveNext(&next)) || !next) break;
  }
  return s + L"}";
}

static void RespondTo(View* v, ICoreWebView2WebResourceRequestedEventArgs* a, int status, const std::wstring& reason, const std::wstring& headers,
                      const void* data, size_t n) {
  ComPtr<ICoreWebView2Environment> e = v->env ? v->env->env : ComPtr<ICoreWebView2Environment>();
  if (!e) return;
  ComPtr<IStream> st = MakeStream(data, n);
  ComPtr<ICoreWebView2WebResourceResponse> resp;
  if (SUCCEEDED(e->CreateWebResourceResponse(st.get(), status, reason.c_str(), headers.c_str(), resp.put()))) a->put_Response(resp.get());
}

HRESULT View::OnWebResourceRequested(ICoreWebView2WebResourceRequestedEventArgs* a) {
  ComPtr<ICoreWebView2WebResourceRequest> req;
  a->get_Request(req.put());
  if (!req) return S_OK;
  CoStr u, m;
  req->get_Uri(u.put());
  req->get_Method(m.put());
  std::wstring uri = u.str();
  COREWEBVIEW2_WEB_RESOURCE_CONTEXT rc = COREWEBVIEW2_WEB_RESOURCE_CONTEXT_ALL;
  a->get_ResourceContext(&rc);
  // 1. 内存文件
  auto mf = memFiles.find(StripQuery(uri));
  if (mf != memFiles.end()) {
    // 加载HTML 的页面只给它自己用：不加 Access-Control-Allow-Origin（否则同一浏览器里打开的任何网站都能按网址 fetch 读走页面内容），
    // 不进任何缓存（内容只在内存里），禁止按内容猜类型，也不许别的来源把它当作脚本、图片等子资源引用
    std::wstring headers = mf->second.page
                               ? L"Content-Type: " + mf->second.mime + L"\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nCross-Origin-Resource-Policy: same-origin"
                               : L"Content-Type: " + mf->second.mime + L"\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache";
    RespondTo(this, a, 200, L"OK", headers, mf->second.data.data(), mf->second.data.size());
    return S_OK;
  }
  // 2. 屏蔽
  if (blockImages && rc == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_IMAGE) {
    RespondTo(this, a, 403, L"Blocked", L"", nullptr, 0);
    return S_OK;
  }
  for (const auto& p : blockUrls) {
    if (WildMatch(p, uri)) {
      RespondTo(this, a, 403, L"Blocked", L"", nullptr, 0);
      return S_OK;
    }
  }
  // 3. 用户拦截事件：先取 Deferral，到事件处理函数之外再调用易语言回调（回调里可以使用同步方法）
  bool match = false;
  if (HasCb(WVE_REQUEST))
    for (const auto& f : reqFilters)
      if ((f.ctx == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_ALL || f.ctx == (int)rc) && WildMatch(f.pat, uri)) {
        match = true;
        break;
      }
  if (!match) {
    // 加载HTML 的页面主机上没有对应内容的网址（已淘汰的旧页面、页面里写的相对路径资源）：当场回 404，不交给网络（.example 域名不会解析，只会慢慢失败）
    if (!htmlPages.empty() && StartsWithI(uri, kHtmlPageOrigin) && uri.size() > wcslen(kHtmlPageOrigin) && uri[wcslen(kHtmlPageOrigin)] == L'/') {
      static const char kGone[] = "404 Not Found";
      RespondTo(this, a, 404, L"Not Found", L"Content-Type: text/plain; charset=utf-8\r\nCache-Control: no-store", kGone, sizeof(kGone) - 1);
    }
    return S_OK;
  }
  ComPtr<ICoreWebView2Deferral> def;
  a->GetDeferral(def.put());
  ComPtr<ICoreWebView2WebResourceRequestedEventArgs> args = ComPtr<ICoreWebView2WebResourceRequestedEventArgs>::From(a);
  const int vid = id, ctxType = (int)rc;
  std::wstring method = m.str();
  Post([vid, args, req, def, uri, method, ctxType] {
    RefPtr<View> v = FindView(vid);
    if (v && !v->closing) v->HandleRequest(args.get(), req.get(), uri, method, ctxType);
    if (def) def->Complete();
  });
  return S_OK;
}

void View::HandleRequest(ICoreWebView2WebResourceRequestedEventArgs* a, ICoreWebView2WebResourceRequest* req, const std::wstring& uri,
                         const std::wstring& method, int rc) {
  EventCtx ctx;
  ctx.s[WVK_URL] = uri;
  ctx.s[WVK_METHOD] = method;
  ctx.n[WVK_RESOURCE_TYPE] = rc;
  ComPtr<ICoreWebView2WebResourceRequest> reqRef = ComPtr<ICoreWebView2WebResourceRequest>::From(req);
  ctx.lazy = [reqRef](int key) -> std::wstring {
    if (key == WVK_HEADERS) {
      ComPtr<ICoreWebView2HttpRequestHeaders> h;
      reqRef->get_Headers(h.put());
      ComPtr<ICoreWebView2HttpHeadersCollectionIterator> it;
      if (h) h->GetIterator(it.put());
      return HeadersJson(it.get());
    }
    if (key == WVK_POST_DATA) {
      ComPtr<IStream> s;
      reqRef->get_Content(s.put());
      std::vector<unsigned char> d;
      ReadStream(s.get(), d);
      return d.empty() ? std::wstring() : FromUtf8(reinterpret_cast<const char*>(d.data()), (int)d.size());
    }
    return std::wstring();
  };
  int action = 0;
  std::string su = ToCP(uri), sm = ToCP(method);
  Fire(WVE_REQUEST, {(intptr_t)id, (intptr_t)su.c_str(), (intptr_t)sm.c_str(), rc, (intptr_t)&action}, &ctx);
  if (closing) return;
  if (ctx.hasResp) {
    RespondTo(this, a, ctx.respStatus, ctx.respReason.empty() ? L"OK" : ctx.respReason, ctx.respHeaders, ctx.respBody.data(), ctx.respBody.size());
    return;
  }
  if (action == 1) {
    RespondTo(this, a, 403, L"Blocked", L"", nullptr, 0);
    return;
  }
  ComPtr<ICoreWebView2HttpRequestHeaders> h;
  req->get_Headers(h.put());
  for (const auto& kv : ctx.setS) {
    if (kv.first == WVK_SET_URL && !kv.second.empty()) req->put_Uri(kv.second.c_str());
  }
  if (h) {
    for (const auto& kv : ctx.setS) {
      if (kv.first == WVK_SET_HEADER) {
        for (const auto& line : Split(kv.second, L"\n")) {
          size_t c = line.find(L':');
          if (c != std::wstring::npos) h->SetHeader(Trim(line.substr(0, c)).c_str(), Trim(line.substr(c + 1)).c_str());
        }
      } else if (kv.first == WVK_REMOVE_HEADER) {
        for (const auto& n : Split(kv.second, L"\n,;")) h->RemoveHeader(n.c_str());
      }
    }
  }
}

void View::EnsureResponseHook() {
  if (!Ready() || respHooked) return;
  auto w2 = wv.as<ICoreWebView2_2>();
  if (!w2) {
    Log(L"当前内核不支持响应捕获（需要 Edge 86+），设置的捕获规则不会生效");
    return;
  }
  respHooked = true;
  const int vid = id;
  EventRegistrationToken tk;
  w2->add_WebResourceResponseReceived(
      Callback<ICoreWebView2WebResourceResponseReceivedEventHandler, ICoreWebView2*, ICoreWebView2WebResourceResponseReceivedEventArgs*>(
          [vid](ICoreWebView2*, ICoreWebView2WebResourceResponseReceivedEventArgs* a) -> HRESULT {
            RefPtr<View> v = FindView(vid);
            if (!v || v->closing || !v->wv) return S_OK;
            return v->OnResponseReceived(a);
          })
          .get(),
      &tk);
}

bool View::SetResponseCapture(const std::wstring& patterns, bool body) {
  respRules.clear();
  for (const auto& p : Split(patterns, L"; \t\r\n")) respRules.emplace_back(p, body);  // 与屏蔽网址相同：也可以用空格或换行分隔，每行一项
  if (Ready()) {
    if (!wv.as<ICoreWebView2_2>()) {  // 内核没有响应事件：如实报告，不让调用方以为抓包已经开启
      SetErr(WVERR_UNSUPPORTED, L"当前内核不支持响应捕获（需要 Edge 86+）", E_NOINTERFACE);
      return false;
    }
    EnsureResponseHook();
  }
  return true;
}

HRESULT View::OnResponseReceived(ICoreWebView2WebResourceResponseReceivedEventArgs* a) {
  if (!HasCb(WVE_RESPONSE)) return S_OK;
  ComPtr<ICoreWebView2WebResourceRequest> req;
  ComPtr<ICoreWebView2WebResourceResponseView> resp;
  a->get_Request(req.put());
  a->get_Response(resp.put());
  if (!req || !resp) return S_OK;
  CoStr u, m, reason;
  req->get_Uri(u.put());
  req->get_Method(m.put());
  std::wstring uri = u.str();
  bool withBody = false, match = respRules.empty();
  for (const auto& r : respRules)
    if (WildMatch(r.first, uri)) { match = true; withBody = r.second; break; }
  if (!match) return S_OK;
  int status = 0;
  resp->get_StatusCode(&status);
  resp->get_ReasonPhrase(reason.put());
  ComPtr<ICoreWebView2HttpResponseHeaders> rh;
  resp->get_Headers(rh.put());
  ComPtr<ICoreWebView2HttpHeadersCollectionIterator> it;
  if (rh) rh->GetIterator(it.put());
  std::wstring headers = HeadersJson(it.get());
  ComPtr<ICoreWebView2HttpRequestHeaders> qh;
  req->get_Headers(qh.put());
  ComPtr<ICoreWebView2HttpHeadersCollectionIterator> qit;
  if (qh) qh->GetIterator(qit.put());
  std::wstring reqHeaders = HeadersJson(qit.get());
  const int vid = id;
  std::wstring method = m.str(), rs = reason.str();
  auto deliver = [vid, uri, method, status, rs, headers, reqHeaders](const std::vector<unsigned char>* body) {
    RefPtr<View> v0 = FindView(vid);
    if (!v0 || v0->closing) return;
    std::vector<unsigned char> data;
    if (body) data = *body;
    v0->Post([vid, uri, method, status, rs, headers, reqHeaders, data] {
    WV_TASK(vid);
    EventCtx ctx;
    ctx.s[WVK_URL] = uri;
    ctx.s[WVK_METHOD] = method;
    ctx.s[WVK_REASON] = rs;
    ctx.s[WVK_RESP_HEADERS] = headers;
    ctx.s[WVK_HEADERS] = reqHeaders;
    ctx.n[WVK_STATUS] = status;
    ctx.body = data;
    std::string su = ToCP(uri), sm = ToCP(method);
    v->Fire(WVE_RESPONSE, {(intptr_t)vid, (intptr_t)su.c_str(), status, (intptr_t)sm.c_str(), (intptr_t)ctx.body.size()}, &ctx);
    });
  };
  if (!withBody) {
    deliver(nullptr);
    return S_OK;
  }
  HRESULT hr = resp->GetContent(Callback<ICoreWebView2WebResourceResponseViewGetContentCompletedHandler, HRESULT, IStream*>(
                                    [deliver](HRESULT e, IStream* s) -> HRESULT {
                                      std::vector<unsigned char> d;
                                      if (SUCCEEDED(e) && s) ReadStream(s, d);
                                      deliver(&d);
                                      return S_OK;
                                    })
                                    .get());
  if (FAILED(hr)) deliver(nullptr);
  return S_OK;
}

bool View::MapFolder(const std::wstring& hostName, const std::wstring& folder, int access) {
  if (!RequireReady()) return false;
  auto w3 = wv.as<ICoreWebView2_3>();
  if (!w3) {
    SetErr(WVERR_UNSUPPORTED, L"当前内核不支持目录映射（需要 Edge 89+）", E_NOINTERFACE);
    return false;
  }
  const int acc = access < 0 || access > 2 ? 1 : access;
  std::wstring dir;
  HRESULT hr;
  if (folder.empty()) hr = w3->ClearVirtualHostNameToFolderMapping(hostName.c_str());
  else {
    dir = AppPath(folder);
    if (!DirExists(dir)) {
      SetErr(WVERR_NOT_FOUND, L"目录不存在：" + dir);
      return false;
    }
    hr = w3->SetVirtualHostNameToFolderMapping(hostName.c_str(), dir.c_str(), (COREWEBVIEW2_HOST_RESOURCE_ACCESS_KIND)acc);
  }
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"目录映射失败：" + HrText(hr), hr);
    return false;
  }
  // 登记下来：映射目录的主机算作本程序自己的内容（JS 桥未设白名单时放行），浏览器重建后按它重新映射
  if (folder.empty()) mappedHosts.erase(Lower(hostName));
  else mappedHosts[Lower(hostName)] = FolderMap{hostName, dir, acc};
  return true;
}

bool View::AddMemoryFile(const std::wstring& url, const void* data, int len, const std::wstring& mime) {
  if (url.empty()) {  // 清空内存文件：加载HTML 生成的页面不在其列（正在显示的页面刷新后仍要能取到）
    for (auto it = memFiles.begin(); it != memFiles.end();) it = it->second.page ? std::next(it) : memFiles.erase(it);
  }
  else if (!data || len < 0) memFiles.erase(StripQuery(url));
  else {
    MemFile f;
    f.data.assign(static_cast<const unsigned char*>(data), static_cast<const unsigned char*>(data) + len);
    f.mime = mime.empty() ? GuessMime(url) : mime;
    f.url = FilterUrl(url);
    std::wstring lm = Lower(f.mime);
    if (lm.find(L"text") != std::wstring::npos || lm.find(L"json") != std::wstring::npos || lm.find(L"javascript") != std::wstring::npos || lm.find(L"xml") != std::wstring::npos)
      while (!f.data.empty() && f.data.back() == 0) f.data.pop_back();  // 易语言文本转出的字节集常带结尾零字节
    memFiles[StripQuery(url)] = std::move(f);
  }
  if (Ready()) EnsureRequestHook();
  return true;
}

// ---------------------------------------------------------------- 下载
HRESULT View::OnDownloadStarting(ICoreWebView2DownloadStartingEventArgs* a) {
  if (!HasCb(WVE_DOWNLOAD_START)) {
    HandleDownload(a);
    return S_OK;
  }
  // 有易语言回调：先取 Deferral，到事件处理函数之外再决定保存位置或取消
  ComPtr<ICoreWebView2Deferral> def;
  a->GetDeferral(def.put());
  ComPtr<ICoreWebView2DownloadStartingEventArgs> args = ComPtr<ICoreWebView2DownloadStartingEventArgs>::From(a);
  const int vid = id;
  Post([vid, args, def] {
    RefPtr<View> v = FindView(vid);
    if (v && !v->closing) v->HandleDownload(args.get());
    if (def) def->Complete();
  });
  return S_OK;
}

void View::HandleDownload(ICoreWebView2DownloadStartingEventArgs* a) {
  ComPtr<ICoreWebView2DownloadOperation> op;
  a->get_DownloadOperation(op.put());
  if (!op) return;
  CoStr uri, path, mime, cd;
  op->get_Uri(uri.put());
  op->get_MimeType(mime.put());
  op->get_ContentDisposition(cd.put());
  a->get_ResultFilePath(path.put());
  INT64 total = 0;
  op->get_TotalBytesToReceive(&total);
  std::wstring finalPath = path.str();
  if (!downloadDir.empty()) finalPath = UniquePath(PathJoin(downloadDir, PathName(finalPath)));
  const int did = nextDl++;
  EventCtx ctx;
  ctx.s[WVK_URL] = uri.str();
  ctx.s[WVK_MIME] = mime.str();
  ctx.s[WVK_CONTENT_DISPOSITION] = cd.str();
  ctx.s[WVK_TOTAL_BYTES] = std::to_wstring((long long)total);
  int cancel = 0;
  std::string su = ToCP(uri.str()), sp = ToCP(finalPath);
  Fire(WVE_DOWNLOAD_START, {(intptr_t)id, did, (intptr_t)su.c_str(), (intptr_t)sp.c_str(), (intptr_t)&cancel}, &ctx);
  if (closing) return;
  if (cancel) {
    a->put_Cancel(TRUE);
    return;
  }
  auto sp2 = ctx.setS.find(WVK_SET_PATH);
  if (sp2 != ctx.setS.end() && !sp2->second.empty())
    finalPath = AppPath(sp2->second);
  if (finalPath != path.str()) {
    EnsureDir(PathDir(finalPath));
    a->put_ResultFilePath(finalPath.c_str());
  }
  RememberDownload(finalPath);  // 开始时就记下：下载完改名成目标文件的那一刻起它就不算本程序的内容
  if (silentDownload) a->put_Handled(TRUE);
  Dl d;
  d.op = op;
  d.path = finalPath;
  downloads[did] = d;
  const int vid = id;
  EventRegistrationToken tk;
  op->add_BytesReceivedChanged(Callback<ICoreWebView2BytesReceivedChangedEventHandler, ICoreWebView2DownloadOperation*, IUnknown*>(
                                   [vid, did](ICoreWebView2DownloadOperation* o, IUnknown*) -> HRESULT {
                                     RefPtr<View> v = FindView(vid);
                                     if (!v || v->closing) return S_OK;
                                     auto it = v->downloads.find(did);
                                     if (it == v->downloads.end()) return S_OK;
                                     INT64 got = 0, all = 0;
                                     o->get_BytesReceived(&got);
                                     o->get_TotalBytesToReceive(&all);
                                     int pct = all > 0 ? (int)(got * 100 / all) : -1;
                                     // 总大小已知时按百分比、未知时每 256KB 通知一次，避免每个数据块都回调
                                     int key = all > 0 ? pct : (int)(got / 262144);
                                     if (key == it->second.lastPct) return S_OK;
                                     it->second.lastPct = key;
                                     if (!v->HasCb(WVE_DOWNLOAD_PROGRESS)) return S_OK;
                                     int kb = (int)(got / 1024), allKb = (int)(all > 0 ? all / 1024 : -1);
                                     v->Post([vid, did, pct, kb, allKb] {
                                       WV_TASK(vid);
                                       v->Fire(WVE_DOWNLOAD_PROGRESS, {(intptr_t)vid, did, pct, kb, allKb});
                                     });
                                     return S_OK;
                                   }).get(),
                               &tk);
  op->add_StateChanged(Callback<ICoreWebView2StateChangedEventHandler, ICoreWebView2DownloadOperation*, IUnknown*>(
                           [vid, did](ICoreWebView2DownloadOperation* o, IUnknown*) -> HRESULT {
                             RefPtr<View> v = FindView(vid);
                             if (!v || v->closing) return S_OK;
                             COREWEBVIEW2_DOWNLOAD_STATE s = COREWEBVIEW2_DOWNLOAD_STATE_IN_PROGRESS;
                             o->get_State(&s);
                             if (s == COREWEBVIEW2_DOWNLOAD_STATE_IN_PROGRESS) return S_OK;
                             CoStr p;
                             o->get_ResultFilePath(p.put());
                             std::wstring file = p.str();
                             RememberDownload(file);  // 浏览器可能另起了文件名（重名时加编号）
                             int res = s == COREWEBVIEW2_DOWNLOAD_STATE_COMPLETED ? 1 : 2;
                             v->downloads.erase(did);
                             v->Post([vid, did, res, file] {
                               WV_TASK(vid);
                               std::string sp = ToCP(file);
                               v->Fire(WVE_DOWNLOAD_DONE, {(intptr_t)vid, did, res, (intptr_t)sp.c_str()});
                             });
                             return S_OK;
                           }).get(),
                       &tk);
}

// 本次运行里浏览器下载过的文件（只在界面线程访问，最多记 kDownloadedMax 个，超出时忘掉最早的）。判断“本程序自己的内容”时它们不算：
// 下载到哪里都是网页的内容，回调_置下载路径 () 可以把单个下载放进程序目录。按完整路径的大写形式放进哈希表，每次判断只查一次：
// 1.7.5 把它们和文件夹放在同一张表里逐个比较，每项还要规整一次路径，记下 4096 个下载后程序目录里的页面每次调用 JS 桥、
// 每次发送事件都要约 1.9 毫秒（Wine 实测，没有下载时约 7 微秒）。大写按与区域设置无关的规则，土耳其语等区域设置下 i 的大写也一致
static const size_t kDownloadedMax = 65536;
struct DownloadedSet {
  std::unordered_set<std::wstring> keys;
  std::deque<std::wstring> order;
};
static DownloadedSet& Downloaded() {
  static DownloadedSet d;
  return d;
}
static std::wstring FileKey(const std::wstring& full) {
  if (full.empty()) return full;
  std::wstring k(full.size(), L'\0');
  const int n = LCMapStringEx(LOCALE_NAME_INVARIANT, LCMAP_UPPERCASE, full.c_str(), (int)full.size(), &k[0], (int)k.size(), nullptr, nullptr, 0);
  if (n <= 0) return full;
  k.resize((size_t)n);
  return k;
}
void RememberDownload(const std::wstring& file) {
  if (file.empty()) return;
  const std::wstring key = FileKey(FullPath(file));
  DownloadedSet& d = Downloaded();
  if (!d.keys.insert(key).second) return;
  d.order.push_back(key);
  if (d.order.size() > kDownloadedMax) {
    d.keys.erase(d.order.front());
    d.order.pop_front();
  }
}
bool WasDownloaded(const std::wstring& fullPath) { return !fullPath.empty() && Downloaded().keys.count(FileKey(fullPath)) != 0; }

bool View::DownloadControl(int did, int action) {
  auto it = downloads.find(did);
  if (it == downloads.end()) {
    SetErr(WVERR_NOT_FOUND, L"下载ID不存在或已结束");
    return false;
  }
  HRESULT hr = action == 1 ? it->second.op->Cancel() : action == 2 ? it->second.op->Pause() : action == 3 ? it->second.op->Resume() : E_INVALIDARG;
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"下载控制失败：" + HrText(hr), hr);
    return false;
  }
  return true;
}

// ---------------------------------------------------------------- 新窗口
void View::CompletePendingNewWindows() {
  std::vector<PendingNW> list;
  list.swap(pendingNW);
  for (auto& p : list) {
    if (wv) p.args->put_NewWindow(wv.get());
    p.args->put_Handled(TRUE);
    if (p.def) p.def->Complete();
  }
}

HRESULT View::OnNewWindow(ICoreWebView2NewWindowRequestedEventArgs* a) {
  // 先取 Deferral，到事件处理函数之外处理：易语言回调里可以同步创建新浏览器作为弹窗目标
  ComPtr<ICoreWebView2Deferral> def;
  a->GetDeferral(def.put());
  ComPtr<ICoreWebView2NewWindowRequestedEventArgs> args = ComPtr<ICoreWebView2NewWindowRequestedEventArgs>::From(a);
  const int vid = id;
  Post([vid, args, def] {
    RefPtr<View> v = FindView(vid);
    bool kept = v && !v->closing && v->HandleNewWindow(args.get(), def);
    if (!kept && def) def->Complete();
  });
  return S_OK;
}

// 新窗口在当前浏览器打开时，导航由宿主发起，浏览器对网页发起导航的限制不再生效。照浏览器自身的规则拒绝：
// javascript:（会在当前页面执行脚本）、data:（浏览器禁止网页把顶层页面导航到 data 网址，用来防钓鱼）、内部页面，
// 以及网页打开本地文件（当前页面本身是本地文件时允许）。比较前去掉制表符与换行，浏览器解析网址时也会忽略它们
static bool SameViewNavigationAllowed(const std::wstring& url, const std::wstring& current) {
  std::wstring u;
  for (wchar_t ch : url)
    if (ch != L'\t' && ch != L'\r' && ch != L'\n') u += ch;
  u = Lower(Trim(u));
  if (StartsWithI(u, L"file:")) return StartsWithI(current, L"file:");
  if (StartsWithI(u, L"about:")) return u == L"about:blank" || StartsWithI(u, L"about:blank#") || StartsWithI(u, L"about:blank?");
  static const wchar_t* const kBlocked[] = {L"javascript:", L"data:", L"filesystem:", L"view-source:", L"edge:", L"chrome:", L"devtools:",
                                           L"edge-untrusted:", L"chrome-untrusted:", L"chrome-extension:", L"extension:"};
  for (const wchar_t* b : kBlocked)
    if (StartsWithI(u, b)) return false;
  return true;
}

bool View::HandleNewWindow(ICoreWebView2NewWindowRequestedEventArgs* a, const ComPtr<ICoreWebView2Deferral>& def) {
  CoStr u;
  a->get_Uri(u.put());
  BOOL user = FALSE;
  a->get_IsUserInitiated(&user);
  // 回调看到的初值就是新窗口模式；回调改成 0（WV新窗口_默认弹窗）时按 WebView2 默认弹出新窗口。原来初值为 0、回调返回后 0 再换成新窗口模式，
  // 回调选“默认弹窗”与没有改一样，按新窗口模式处理（默认是在当前浏览器打开）
  int action = newWindowMode;
  EventCtx ctx;
  ctx.s[WVK_URL] = u.str();
  if (HasCb(WVE_NEW_WINDOW)) {
    std::string su = ToCP(u.str());
    Fire(WVE_NEW_WINDOW, {(intptr_t)id, (intptr_t)su.c_str(), user ? 1 : 0, (intptr_t)&action}, &ctx);
    if (closing) return false;
  }
  auto tv = ctx.setN.find(WVK_TARGET_VIEW);
  if (tv != ctx.setN.end() && tv->second) {
    RefPtr<View> t = FindView(tv->second);
    if (t && !t->closing) {
      t->popupTarget = true;
      if (t->Ready()) {
        a->put_NewWindow(t->wv.get());
        a->put_Handled(TRUE);
        return false;
      }
      PendingNW p;
      p.args = ComPtr<ICoreWebView2NewWindowRequestedEventArgs>::From(a);
      p.def = def;
      t->pendingNW.push_back(p);
      return true;  // Deferral 交给目标浏览器，就绪后完成
    }
  }
  switch (action) {
    case 1: {
      a->put_Handled(TRUE);
      std::wstring url = u.str();
      if (url.empty()) break;
      CoStr cur;
      wv->get_Source(cur.put());
      if (!SameViewNavigationAllowed(url, cur.str())) {
        Log(L"新窗口网址不在当前浏览器打开（浏览器不允许网页这样导航）：%ls", url.c_str());
        break;
      }
      wv->Navigate(url.c_str());
      break;
    }
    case 2:
      a->put_Handled(TRUE);
      break;
    case 3: {
      a->put_Handled(TRUE);
      // 网址由网页决定：只把 http/https/mailto 交给系统打开。file:、UNC 路径、自定义协议（如 ms-msdt:、search-ms:）
      // 交给系统外壳会直接启动本机或网络共享上的程序、触发协议处理程序，一律不打开
      std::wstring url = u.str();
      if (StartsWithI(url, L"http://") || StartsWithI(url, L"https://") || StartsWithI(url, L"mailto:"))
        ShellExecuteW(nullptr, L"open", url.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
      else if (!url.empty())
        Log(L"新窗口网址不是 http/https/mailto，未交给系统打开：%ls", url.c_str());
      break;
    }
    case 4:
      a->put_Handled(TRUE);
      break;
    default:
      break;  // 0：WebView2 默认弹出新窗口
  }
  return false;
}

// ---------------------------------------------------------------- 右键菜单（精简模式）
HRESULT View::OnContextMenu(ICoreWebView2ContextMenuRequestedEventArgs* a) {
  if (ctxMenuMode != 2) return S_OK;
  ComPtr<ICoreWebView2ContextMenuItemCollection> items;
  a->get_MenuItems(items.put());
  if (!items) return S_OK;
  static const wchar_t* keep[] = {L"undo", L"redo", L"cut", L"copy", L"paste", L"pasteAndMatchStyle", L"selectAll", L"emoji", L"copyLinkLocation",
                                  L"copyImage", L"copyImageLocation", L"spellCheck"};
  UINT32 n = 0;
  items->get_Count(&n);
  for (UINT32 i = n; i-- > 0;) {
    ComPtr<ICoreWebView2ContextMenuItem> it;
    if (FAILED(items->GetValueAtIndex(i, it.put())) || !it) continue;
    COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND k = COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND_COMMAND;
    it->get_Kind(&k);
    if (k == COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND_SEPARATOR) continue;
    CoStr name;
    it->get_Name(name.put());
    bool ok = false;
    for (const wchar_t* kname : keep)
      if (_wcsicmp(name.str().c_str(), kname) == 0) ok = true;
    if (!ok) items->RemoveValueAtIndex(i);
  }
  // 清理首尾与连续的分隔线
  bool prevSep = true;
  items->get_Count(&n);
  for (UINT32 i = 0; i < n;) {
    ComPtr<ICoreWebView2ContextMenuItem> it;
    items->GetValueAtIndex(i, it.put());
    COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND k = COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND_COMMAND;
    if (it) it->get_Kind(&k);
    bool sep = k == COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND_SEPARATOR;
    if (sep && prevSep) {
      items->RemoveValueAtIndex(i);
      --n;
      continue;
    }
    prevSep = sep;
    ++i;
  }
  if (n > 0) {
    ComPtr<ICoreWebView2ContextMenuItem> last;
    items->GetValueAtIndex(n - 1, last.put());
    COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND k = COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND_COMMAND;
    if (last) last->get_Kind(&k);
    if (k == COREWEBVIEW2_CONTEXT_MENU_ITEM_KIND_SEPARATOR) items->RemoveValueAtIndex(--n);
  }
  if (n == 0) a->put_Handled(TRUE);  // 没有可用项：不弹菜单
  return S_OK;
}

// ---------------------------------------------------------------- 快捷键
HRESULT View::OnKey(ICoreWebView2AcceleratorKeyPressedEventArgs* a) {
  COREWEBVIEW2_KEY_EVENT_KIND kind = COREWEBVIEW2_KEY_EVENT_KIND_KEY_DOWN;
  a->get_KeyEventKind(&kind);
  UINT vk = 0;
  a->get_VirtualKey(&vk);
  unsigned mods = (GetKeyState(VK_CONTROL) < 0 ? 1u : 0u) | (GetKeyState(VK_SHIFT) < 0 ? 2u : 0u) | (GetKeyState(VK_MENU) < 0 ? 4u : 0u);
  bool down = kind == COREWEBVIEW2_KEY_EVENT_KIND_KEY_DOWN || kind == COREWEBVIEW2_KEY_EVENT_KIND_SYSTEM_KEY_DOWN;
  if (down && blockKeys.count((mods << 16) | vk)) {
    a->put_Handled(TRUE);
    return S_OK;
  }
  if (!HasCb(WVE_KEY)) return S_OK;
  int handled = 0;
  Fire(WVE_KEY, {(intptr_t)id, (int)vk, (int)kind, (int)mods, (intptr_t)&handled});
  if (!closing && handled) a->put_Handled(TRUE);
  return S_OK;
}

}  // namespace wv
