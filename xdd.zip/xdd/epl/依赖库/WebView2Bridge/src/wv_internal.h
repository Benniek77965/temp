// wv_internal.h : WebView2Bridge 内部公共声明
#pragma once
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#ifndef WINVER
#define WINVER 0x0601
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif
#include <windows.h>
#include <objbase.h>
#include <oleauto.h>
#include <shellapi.h>
#include <shlobj.h>
#include "WebView2.h"

#include <string>
#include <vector>
#include <map>
#include <deque>
#include <set>
#include <unordered_set>
#include <memory>
#include <functional>
#include <atomic>
#include <algorithm>
#include <utility>
#include <initializer_list>
#include <cstdint>
#include <cstring>
#include <cstdarg>
#include <cwchar>

#define WV2BRIDGE_BUILD 1
#include "wv2bridge.h"
#include "wv_iids.h"

#define WV_STATE_CREATING 0
#define WV_STATE_READY 1
#define WV_STATE_FAILED 2
#define WV_STATE_CLOSED 3

namespace wv {

// ---------------------------------------------------------------- 同步
class Lock {
 public:
  Lock() { InitializeCriticalSection(&cs_); }
  ~Lock() { DeleteCriticalSection(&cs_); }
  void lock() { EnterCriticalSection(&cs_); }
  void unlock() { LeaveCriticalSection(&cs_); }
  Lock(const Lock&) = delete;
  Lock& operator=(const Lock&) = delete;
 private:
  CRITICAL_SECTION cs_;
};
class Guard {
 public:
  explicit Guard(Lock& l) : l_(l) { l_.lock(); }
  ~Guard() { l_.unlock(); }
 private:
  Lock& l_;
};

// ---------------------------------------------------------------- COM 智能指针
template <class T>
class ComPtr {
 public:
  ComPtr() {}
  ComPtr(std::nullptr_t) {}
  ComPtr(const ComPtr& o) : p_(o.p_) { if (p_) p_->AddRef(); }
  ComPtr(ComPtr&& o) noexcept : p_(o.p_) { o.p_ = nullptr; }
  ~ComPtr() { reset(); }
  ComPtr& operator=(const ComPtr& o) {
    if (this != &o) { if (o.p_) o.p_->AddRef(); reset(); p_ = o.p_; }
    return *this;
  }
  ComPtr& operator=(ComPtr&& o) noexcept {
    if (this != &o) { reset(); p_ = o.p_; o.p_ = nullptr; }
    return *this;
  }
  ComPtr& operator=(std::nullptr_t) { reset(); return *this; }
  static ComPtr From(T* p) { ComPtr r; r.p_ = p; if (p) p->AddRef(); return r; }
  T* get() const { return p_; }
  T* operator->() const { return p_; }
  explicit operator bool() const { return p_ != nullptr; }
  T** put() { reset(); return &p_; }
  void reset() { if (p_) { T* t = p_; p_ = nullptr; t->Release(); } }
  void attach(T* p) { reset(); p_ = p; }
  template <class U>
  ComPtr<U> as() const {
    ComPtr<U> r;
    if (p_) p_->QueryInterface(wv_iid<U>::get(), reinterpret_cast<void**>(r.put()));
    return r;
  }
 private:
  T* p_ = nullptr;
};

// ---------------------------------------------------------------- COM 回调（替代 WRL::Callback）
template <class I, class... A>
class CallbackImpl final : public I {
 public:
  template <class F>
  explicit CallbackImpl(F&& f) : fn_(std::forward<F>(f)) {}
  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppv) override {
    if (!ppv) return E_POINTER;
    if (IsEqualIID(riid, wv_iid<IUnknown>::get()) || IsEqualIID(riid, wv_iid<I>::get())) {
      *ppv = static_cast<I*>(this);
      AddRef();
      return S_OK;
    }
    *ppv = nullptr;
    return E_NOINTERFACE;
  }
  ULONG STDMETHODCALLTYPE AddRef() override { return (ULONG)InterlockedIncrement(&ref_); }
  ULONG STDMETHODCALLTYPE Release() override {
    LONG r = InterlockedDecrement(&ref_);
    if (r == 0) delete this;
    return (ULONG)r;
  }
  HRESULT STDMETHODCALLTYPE Invoke(A... a) override {
    try {
      return fn_ ? fn_(a...) : S_OK;
    } catch (...) {
      return E_FAIL;
    }
  }
 private:
  ~CallbackImpl() {}
  volatile LONG ref_ = 1;
  std::function<HRESULT(A...)> fn_;
};
template <class I, class... A, class F>
inline ComPtr<I> Callback(F&& f) {
  ComPtr<I> p;
  p.attach(new CallbackImpl<I, A...>(std::forward<F>(f)));
  return p;
}

// CoTaskMem 字符串
struct CoStr {
  LPWSTR p = nullptr;
  CoStr() {}
  ~CoStr() { if (p) CoTaskMemFree(p); }
  CoStr(const CoStr&) = delete;
  CoStr& operator=(const CoStr&) = delete;
  LPWSTR* put() { if (p) { CoTaskMemFree(p); p = nullptr; } return &p; }
  std::wstring str() const { return p ? std::wstring(p) : std::wstring(); }
};

template <class T>
class RefPtr {
 public:
  RefPtr() {}
  RefPtr(T* p) : p_(p) { if (p_) p_->AddRef(); }
  RefPtr(const RefPtr& o) : p_(o.p_) { if (p_) p_->AddRef(); }
  RefPtr& operator=(const RefPtr& o) {
    if (o.p_) o.p_->AddRef();
    if (p_) p_->Release();
    p_ = o.p_;
    return *this;
  }
  ~RefPtr() { if (p_) p_->Release(); }
  T* get() const { return p_; }
  T* operator->() const { return p_; }
  explicit operator bool() const { return p_ != nullptr; }
 private:
  T* p_ = nullptr;
};

// ---------------------------------------------------------------- 工具函数（wv_util.cpp）
std::wstring FromCP(const char* s);
std::wstring FromCPLines(const char* s);  // 每行一项的文本逐行按代码页转换：一行漏了转换只影响这一行
std::string ToCP(const std::wstring& w);
std::string ToCPJson(const std::wstring& w);
std::string ToUtf8(const std::wstring& w);
std::wstring FromUtf8(const char* s, int len = -1);
std::wstring FromAnsi(const char* s);  // 按系统 ANSI 代码页解释，不受 WVO_CODEPAGE 影响
// 把 \uXXXX 换成对应字符：高低代理项连写时合成一个字符，落单的代理项换成 U+FFFD；\u0000 与不足 4 位十六进制的写法原样保留
std::wstring DecodeUEscapes(const std::wstring& s);
std::wstring Trim(const std::wstring& s);
std::wstring Lower(std::wstring s);
bool StartsWithI(const std::wstring& s, const wchar_t* p);
bool EndsWithI(const std::wstring& s, const wchar_t* p);
std::vector<std::wstring> Split(const std::wstring& s, const wchar_t* seps);
std::wstring ReplaceAll(std::wstring s, const std::wstring& from, const std::wstring& to);
std::wstring JsonStr(const std::wstring& s);
bool WildMatch(const std::wstring& pattern, const std::wstring& text);
std::wstring Fmt(const wchar_t* fmt, ...);
// 加载HTML 的页面来源：内容放在内存里，以 https://wv2bridge.example/浏览器编号-序号.html 打开，由 WebResourceRequested 当场应答。
// .example 是保留给示例的顶级域名，不会被真实网站占用；微软文档提醒 .local 会拖慢导航，所以不用它
static const wchar_t kHtmlPageOrigin[] = L"https://wv2bridge.example";
static const size_t kHtmlPageKeep = 8;                 // 每个浏览器最多保留最近 8 个页面（后退、刷新、崩溃后恢复仍能取到）
static const size_t kHtmlPageBytes = 64u * 1024 * 1024;  // 保留页面的总大小上限；最新的一页无论多大都保留
std::wstring HrText(HRESULT hr);
bool Base64Decode(const std::string& in, std::vector<unsigned char>& out);
std::wstring PathJoin(const std::wstring& a, const std::wstring& b);
std::wstring PathDir(const std::wstring& p);
std::wstring PathName(const std::wstring& p);
std::wstring TrimSlash(std::wstring p);
// 是否绝对路径：带盘符（C:\、C:/；C:a 这种按该盘当前目录的写法也原样交给系统，拼到程序目录后面反而无效），
// 或以两个斜杠开头（\\服务器\共享、\\?\、\\.\ 设备路径）。
// 原来按“有没有冒号”判断，网络共享路径会被拼到程序目录后面
bool IsAbsPath(const std::wstring& p);
// file: 网址转成本地完整路径（按 UTF-8 解开 %XX，规整掉 . 与 ..）；支持 file:///C:/…、file://localhost/C:/… 与网络共享 file://服务器/共享/…；
// 不是 file: 网址、不是绝对路径或含有 %00 时返回空文本
std::wstring PathFromFileUrl(const std::wstring& url);
// path 是不是 dir 本身或它下面的文件：不区分大小写，只在路径分隔处匹配（C:\app 不包括 C:\app2）
bool PathUnder(const std::wstring& path, const std::wstring& dir);
// 映射目录主机的网址（https://app.example/a/b.html）对应的本地文件：映射目录 + 解码后的路径，规整后不在映射目录里时返回空文本
std::wstring PathFromMappedUrl(const std::wstring& url, const std::wstring& dir);
std::wstring AppPath(const std::wstring& p);  // 相对路径按程序目录解析，绝对路径与空文本原样返回
std::wstring FullPath(const std::wstring& p);  // 按当前目录换成完整路径（GetFullPathName）；空文本或失败时原样返回
bool FileExists(const std::wstring& p);
bool DirExists(const std::wstring& p);
bool EnsureDir(const std::wstring& p);
bool DirWritable(const std::wstring& p);
bool WriteFileBytes(const std::wstring& p, const void* d, size_t n);
std::wstring ModulePath(HMODULE m);
std::wstring FileVersion(const std::wstring& path);
std::wstring TempDir();
std::wstring Hash8(const std::wstring& s);
std::wstring UniquePath(const std::wstring& p);
int CompareVersion(const std::wstring& a, const std::wstring& b);
int VersionMajor(const std::wstring& v);
bool ReadStream(IStream* s, std::vector<unsigned char>& out);
ComPtr<IStream> MakeStream(const void* data, size_t n);
std::wstring OriginOf(const std::wstring& url);
std::wstring HostOf(const std::wstring& url);

// JSON
struct JVal {
  enum Type { NUL, BOOL, NUM, STR, ARR, OBJ } t = NUL;
  bool b = false;
  double n = 0;
  std::wstring s;  // 字符串值，或数字的原始文本
  std::vector<JVal> a;
  std::vector<std::pair<std::wstring, JVal>> o;
  const JVal* Get(const wchar_t* k) const;
  std::wstring Dump() const;
  std::wstring Text() const;  // 字符串返回值本身，其它返回 JSON
  int Int(int def = 0) const;
  double Num(double def = 0) const;
};
bool JsonParse(const std::wstring& text, JVal& out);

// 错误与返回缓冲（每线程）
void SetErr(int code, const std::wstring& msg, HRESULT hr = S_OK);
void ClearErr();
int ErrCode();
HRESULT ErrHr();
std::wstring ErrMsg();
const char* Ret(const std::string& s);

void Log(const wchar_t* fmt, ...);
std::wstring LogTail(size_t maxLines);  // 最近几条日志（每条带换行）：“复制诊断信息”里带上
// 调用回调（stdcall 或 cdecl 都可以）：参数写少、多写（kSafeCallPad 个以内）都不会破坏堆栈与内存；popped 收到被调方从栈上弹掉的字节数
// （stdcall 即 4×声明的参数个数，cdecl 为 0），用来发现回调子程序的参数表写错
static const int kSafeCallPad = 16;
// 槽位后面再留的清零余量：多写的“参考”参数若是较大的自定义数据类型（每个槽位只有 16 字节），整段赋值会越过槽位，余量让它仍写在这块内存里
static const int kSafeCallTail = 1024;
int SafeCall(void* fn, const intptr_t* args, int n, int* popped = nullptr);
// 回调参数表与事件不符：同一个回调子程序在同一事件上只报一次（写日志、记入诊断信息；开发期检查为 1 时弹出说明）。ev 为 -1 表示回调转发
// outPassed：按 WVE_FLAG_NO_OUT 注册，回填结果的地址放在应有的参数后面（多写的第一个参数收到它）；只多写了这一个时是以前的写法，仍能回填
void ReportCallbackMismatch(int viewId, int ev, void* fn, int poppedBytes, int expectedArgs, bool outPassed = false);
// 事件名（如“事件“将要跳转””）；ev 为 0 是 执行JS_异步 的回调，超出范围时为“回调”
const wchar_t* EventName(int ev);
// 事件的回填参数（最后一个 int*）的种类：0 没有；1 逻辑值；2 对话框（1 确定 0 取消）；3 整数选项（0 默认 2 拦截、拒绝或取消访问）
int EvOutKind(int ev);
// 开发期检查的说明框：WVO_DEV_CHECKS 为 1 时投递给调度窗口显示，key 非空时同一 key 只提示一次。g_devNoticeHook 供测试截取
bool DevNotice(const std::wstring& key, const std::wstring& text);  // 返回是否提示了（开发期检查不为 1、同一 key 已提示过或没有调度窗口时不提示）
extern void (*g_devNoticeHook)(const std::wstring&);
// 文本代码页为 UTF-8、开发期检查打开时 FromCP 收到不合法的 UTF-8 抛出它；导出函数的异常处理用 TakeEncodingError 取回说明，换成 WVERR_ENCODING
struct EncodingError {};
bool TakeEncodingError(std::wstring& sample);
void CountThreadTimeout();
std::wstring CheckStatsJson();  // 诊断信息的 checks 部分
// 交给窗口的任务：消息参数里只放进程内登记的编号，不放指针。窗口过程按编号取回并注销，不是本进程登记的编号（例如别的程序
// 发来的同号消息）就忽略，不会把任意数值当成函数对象调用。owned 为真表示任务对象在堆上、执行后由接收方释放（WM_WV_TASK），
// 为假表示在发送方的栈上（WM_WV_INVOKE，SendMessage 返回前有效）；两种消息只取回各自那一类，同步任务的编号冒充不了投递任务
LPARAM TaskToken(std::function<void()>* f, bool owned);
std::function<void()>* TakeTask(LPARAM token, bool owned);
void RunTask(std::function<void()>& f) noexcept;  // 执行任务；任务里的异常在这里截住，不穿出窗口过程
bool PumpUntil(const std::function<bool()>& done, DWORD timeoutMs);

// ---------------------------------------------------------------- 全局
struct Globals {
  std::wstring appDir, runtimeDir, userDataDir, args, lang, proxy, logFile, defaultBg;
  int policy = 0, disableGpu = 0, autoplay = 0, ignoreCert = 0, tracking = -1, scrollbar = 0, fallback = 1, jsonEscape = 0;
  void* callbackHook = nullptr;  // WVO_CALLBACK_HOOK
  DWORD threadTimeout = 10000;   // WVO_THREAD_TIMEOUT：其它线程的调用最多等界面线程多少毫秒开始执行，0＝一直等
};
Globals& G();
// WVO_DEV_CHECKS：0 关闭 1 打开并弹出说明 2 打开只写日志。转换每段文本时都要读，所以是独立的原子变量（Globals 会被整体复制成快照，不能放原子成员）
std::atomic<int>& DevChecks();
// 以下几项也会在调用方线程上读取，所以同样是独立的原子变量：界面线程与调度窗口（登记一次后不再改变；其它线程转交调用、安装线程投递结果时读取），
// 文本代码页（任何线程转换参数与返回值时读取，WV_SetOption 随时可以改）
std::atomic<DWORD>& UiThread();
std::atomic<HWND>& Dispatcher();
std::atomic<int>& CodePageVar();
Lock& GLock();
int CodePage();
std::wstring AppDir();
extern HMODULE g_module;

// ---------------------------------------------------------------- 系统与运行时（wv_runtime.cpp）
struct OsInfo {
  DWORD major = 0, minor = 0, build = 0;
  WORD sp = 0;
  bool legacy = false;  // Win7/8/8.1：只能用 109 及以下内核
  std::wstring name;
};
const OsInfo& Os();
void InitOs();

struct RuntimeCandidate {
  int kind = 0;  // 0 已安装常青版 1 固定版
  std::wstring dir, clientDll, version, source;
  int major = 0;
  int channel = -1;  // 已安装常青版的通道：0 稳定版 1 Beta 2 Dev 3 Canary；固定版为 -1
};
// 官方加载器的覆盖规则（见 wv_runtime.cpp 的 ReadLoaderOverrides）：环境变量或组策略给出的运行时目录、数据目录、附加参数与通道偏好
struct LoaderOverrides {
  std::wstring browserFolder, userDataFolder, extraArgs;
  int channelPref = -1;  // -1 未指定；1 常青版按 Canary、Dev、Beta、稳定版的顺序找
  std::wstring source;   // “环境变量”或组策略的位置，写进运行时信息与日志
};
LoaderOverrides ReadLoaderOverrides();
// 没有采用的运行时：文件不完整（缺少或损坏 msedgewebview2.exe、msedge_elf.dll、msedge.dll、icudtl.dat）、固定版放在网络位置，或在本进程里已经启动失败
struct BrokenRuntime {
  std::wstring dir, reason;
  bool inProcess = false;  // 本进程里已经启动失败：运行时客户端会记住这次失败，同一个运行时要重新启动程序后才能再用
  int kind = 1;            // 0 电脑上装好的（常青版、Edge 各频道） 1 固定版
  bool network = false;    // 固定版放在网络位置（微软说明固定版目前不能从网络位置运行）：文件本身没有问题
};
struct RuntimeInfo {
  bool found = false;
  bool plainMissing = false;  // 只是“没有找到”（不是位数不符、版本过高、指定目录无效这类需要单独说明的情况）
  RuntimeCandidate sel;
  std::vector<RuntimeCandidate> all;
  std::vector<BrokenRuntime> broken;  // 因文件不完整、放在网络位置或本进程里已失效而没有采用的运行时（每个目录一条）
  std::wstring reason;
  LoaderOverrides ov;
};
RuntimeInfo FindRuntime(bool rescan, const std::wstring& explicitDir);
std::wstring RuntimeJson(const RuntimeInfo& r);
std::wstring DefaultUserDataDir();
ComPtr<IUnknown> MakeEnvOptions(const std::wstring& args, const std::wstring& lang, const std::wstring& target, int tracking, int scrollbar);
HRESULT CreateEnvironment(const RuntimeCandidate& rt, const std::wstring& udf, IUnknown* options,
                          ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler* h);
// 启动后台安装；已有安装在进行时不再启动第二个，直接返回真（多个浏览器同时点“一键安装”只装一次）。
// 结束时向调度窗口投递 WM_WV_INSTALL_DONE，由界面线程统一更新所有浏览器（OnInstallFinishedUi）
// automatic：程序自动发起的安装（WV_InstallRuntime 带 WVI_AUTO）。上次安装失败后 24 小时内直接失败，不再每次都等一遍下载；用户点的安装不受影响
bool StartRuntimeInstall(bool automatic = false);
bool OnlineInstallerSupported();  // 微软当前的在线安装程序能否在这个系统上运行（Windows 7 不行：缺 Windows 8 起才有的系统函数）
bool UseLegacyOfflinePackage();   // Windows 7/8/8.1：一键安装改用微软更新目录里的 109.0.1518.140 x86 离线安装包
void RecordInstallFailure(const std::wstring& why);  // 记下一次安装失败（自动安装据此冷却 24 小时）
bool InstallRuntimeBlocking(DWORD timeoutMs, bool automatic = false);
std::wstring LastInstallError();
int InstallStateCode(std::wstring& err);  // 1.8.1：WVIS_ 状态；为 WVIS_FAILED 时给出原因
bool WaitForeignInstallers(volatile LONG* stage, DWORD maxMs, unsigned& seen);  // 1.8.1：等别的进程启动的微软安装程序结束
extern const wchar_t* g_testInstallerImage;  // 只供测试：再认一个安装程序的进程名
extern DWORD g_foreignWaitMs;                // 只供测试：缩短等别的安装程序的上限
std::wstring LastInstallLog();  // 上次安装失败时微软安装程序这次写进日志（MicrosoftEdgeUpdate.log）的最后几行，没有写时为空
// 安装进度：阶段 1 下载（引导程序，Win7/8/8.1 为离线安装包） 2 校验 3 安装 4 等另一个程序装完；千分比只在下载阶段且大小已知时有效（否则为 -1）；已用毫秒从开始下载算起。
// 没有进行中的安装时返回假
bool InstallStatus(int& stage, int& permille, DWORD& elapsedMs);
// 装上常青版运行时能不能解决“没有运行时”：运行时策略为 3（只用固定版）、指定了运行时目录（全局、本浏览器或
// WEBVIEW2_BROWSER_EXECUTABLE_FOLDER 环境变量）时只查找固定版，装常青版没有用
bool EvergreenAllowed(const std::wstring& viewRuntimeDir);
std::wstring FriendlyHr(HRESULT hr);
// 运行时文件自检：浏览器进程 msedgewebview2.exe、它启动时载入的 msedge_elf.dll 与 msedge.dll、ICU 数据文件 icudtl.dat（运行时客户端在宿主进程里
// 映射它来初始化 ICU）。查找运行时与创建环境之前都要查：这几个文件有问题时运行时客户端到创建控件时才失败，并且记住失败（见 wv_runtime.cpp）
struct RuntimeFileCheck {
  bool ok = true;     // 假：缺少或损坏，这个运行时用不了
  bool busy = false;  // 真：文件暂时被别的程序独占（杀毒软件扫描、正在解压覆盖），稍后再试
  std::wstring reason;
  unsigned long long icuSize = 0;  // icudtl.dat 的大小（打开它时顺便取得：地址空间紧张时另外查文件属性可能失败）
};
RuntimeFileCheck CheckRuntimeFiles(const std::wstring& dir);
unsigned long long LargestFreeRegion();  // 本进程最大的一块连续空闲地址空间（按分配粒度对齐后），字节
// 运行时客户端（按 DLL 路径）：在本进程里启动失败过的不再使用；成功启动过的创建控件前不必再查文件与地址空间（ICU 已经初始化）
bool ClientBroken(const std::wstring& clientDll, std::wstring* reason);
void MarkClientBroken(const std::wstring& clientDll, const std::wstring& reason);
void MarkClientReady(const std::wstring& clientDll);
bool ClientEverReady(const std::wstring& clientDll);
void MarkClientEnvTried(const std::wstring& clientDll);  // 交给它创建过环境：ICU 在这时初始化，之后成败已定
bool ClientEnvTried(const std::wstring& clientDll);
std::wstring ProcessText();  // 如“32 位程序（64 位系统）”
bool NetworkRuntimePath(const std::wstring& dir);  // 共享文件夹、网络驱动器：微软说明固定版目前不能从网络位置运行
// Windows 10 上 120 及以上的固定版：确保运行时文件夹给 AppContainer（所有应用程序包、所有受限应用程序包）读取与执行权限；加不上时返回假并给出原因
bool EnsureFixedRuntimeAcl(const RuntimeCandidate& rt, std::wstring& why);
bool InstalledRuntimeFolder(const std::wstring& dir);  // 常青版或 Edge 各频道装好的文件夹（权限由微软的安装程序设好，不去改）

// ---------------------------------------------------------------- 事件上下文
struct EventCtx {
  int type = 0;
  int view = 0;
  std::map<int, std::wstring> s;
  std::map<int, int> n;
  std::function<std::wstring(int)> lazy;
  std::map<int, std::wstring> setS;
  std::map<int, int> setN;
  std::vector<unsigned char> body;
  bool hasResp = false;
  int respStatus = 200;
  std::wstring respReason, respHeaders;
  std::vector<unsigned char> respBody;
};
// 本线程正在执行的 WebView2 事件处理函数层数。WebView2 不支持在处理函数里嵌套消息循环（官方文档“线程模型·重入”），
// 等待类方法据此立即失败，而不是一直等到超时
int& HandlerDepth();
struct HandlerScope {
  HandlerScope() { ++HandlerDepth(); }
  ~HandlerScope() { --HandlerDepth(); }
};
const wchar_t* ReentrantText();
// 需要等待结果的方法在发出 WebView2 调用之前先调用：处于 WebView2 事件处理函数中，或同步等待已嵌套 kMaxWaitDepth 层时直接失败，
// 不留下“报告失败却已执行”的副作用
bool CanWait();
// 本线程正在进行的同步等待（PumpUntil）层数。等待期间照常处理消息，计时器、按钮又调用需要等待的方法时会一层套一层，
// 计时器间隔短于等待时间时每次触发都多一层，最终耗尽堆栈；超过上限的调用直接失败（WVERR_REENTRANT）
int& WaitDepth();
static const int kMaxWaitDepth = 16;
// 载入系统 DLL：已载入的直接复用（如程序清单载入的 comctl32 v6），否则只从系统目录载入（依赖项也从系统目录解析），
// 不在程序目录或当前目录搜索，防止同名 DLL 劫持
HMODULE LoadSystemDll(const wchar_t* name);
// 背景色文本：#RRGGBB、#AARRGGBB 或 transparent（不分大小写）；其余写法返回假且不改 argb
bool ParseBgColor(const std::wstring& s, unsigned& argb);
// 代理地址里不会出现空白字符与引号；出现时拒绝，防止被拆成额外的浏览器启动参数（例如 --disable-web-security）
bool ValidProxy(const std::wstring& proxy);
void DrainTasks(HWND h);
static const UINT WM_WV_TASK = WM_APP + 0x3A7;
// 投递任务里取回浏览器对象（浏览器已关闭时直接返回）
#define WV_TASK(vid)              \
  RefPtr<View> v = FindView(vid); \
  if (!v || v->closing) return
EventCtx* CurCtx();
void PushCtx(EventCtx* c);
void PopCtx();

// ---------------------------------------------------------------- 宿主窗口与提示卡片
const UINT WM_WV_INVOKE = WM_APP + 0x2B1;
const UINT WM_WV_INSTALL_DONE = WM_APP + 0x2B2;
const UINT WM_WV_SHOW_INSTALLING = WM_APP + 0x2B5;  // 1.8.1：WV_InstallRuntimeAsync 从别的线程发起安装后，让界面线程上等待运行时的卡片一起显示安装进度
bool PostToUi(std::function<void()> fn);  // 1.8.2：把任务投递到界面线程（调度窗口）执行后立即返回；没有界面线程时返回 false
const UINT WM_WV_RECREATE = WM_APP + 0x2B3;
const UINT WM_WV_FINISH_DESTROY = WM_APP + 0x2B4;
extern const wchar_t* kHostClass;
extern const wchar_t* kFullClass;
extern const wchar_t* kDispClass;
void RegisterClasses();
bool EnsureUiThread();
bool HookParent(HWND hwnd, UINT_PTR id, int viewId);
void UnhookParent(HWND hwnd, UINT_PTR id);

struct PanelState {
  int mode = 0;  // 0 无 1 启动中 2 失败 3 安装中 4 崩溃
  std::wstring title, message, detail;
  int icon = 0;  // 0 下载（可操作，蓝色） 1 提醒（琥珀色） 2 错误（红色） 3 重新加载（琥珀色）
  int hot = -1, pressed = -1;
  int focus = -1;     // 键盘焦点所在的按钮
  bool kbd = false;   // 最近一次操作来自键盘：只在这时画焦点框（与系统按钮一致，鼠标点击不出现焦点框）
  int btnCount = 0;
  RECT btn[3];
  std::wstring btnText[3];
  int btnAction[3] = {0, 0, 0};
  int btnStyle[3] = {0, 0, 0};  // 0 主按钮 1 次要按钮 2 文字链接
  bool tracking = false, slowShown = false, hintShown = false;
  int tick = 0;  // 动画帧计数（转圈、进度条）
  // 动画只重画这一小块：完整绘制时记下它的底图，之后每帧先还原底图再画动画元素，不必重画整张卡片
  bool animValid = false;
  RECT anim = {0, 0, 0, 0};
  std::vector<uint32_t> animBg;
  float spinX = 0, spinY = 0, spinR = 0, spinT = 0;
  RECT bar = {0, 0, 0, 0};
  COLORREF animFg = 0, animTrack = 0;
  std::wstring statusShown;  // 安装进度文字（变化时整卡重画）
};
enum PanelAction { PA_NONE = 0, PA_INSTALL = 1, PA_PICK_DIR = 2, PA_COPY = 3, PA_RETRY = 4, PA_RECHECK = 5 };
// 界面线程：安装结束后更新所有等待运行时的浏览器（成功则重建，失败则在安装中的卡片上显示原因）
void OnInstallFinishedUi(bool ok);
// 界面线程：开始安装后，所有显示“需要运行时”卡片的浏览器一起进入安装中状态，避免在别的卡片上重复点安装
void ShowInstallingOnAllViews();
// 界面线程：运行时可能已经齐备（安装成功、选定了运行时目录）时，重建所有在等待运行时的浏览器
// （没有运行时、安装失败或正在安装的；关闭了提示卡片的也包括在内，它们同样能自动恢复）
void RecreateWaitingViews();

struct EnvEntry {
  std::wstring key, udf, args, lang, configKey;
  RuntimeCandidate rt;
  int state = 0;  // 0 创建中 1 就绪 2 失败
  bool started = false;
  HRESULT hr = S_OK;
  ComPtr<ICoreWebView2Environment> env;
  std::vector<int> waiters;
};

// 映射目录：主机（原样）、本地目录（已解析成绝对路径）、跨域访问方式；浏览器重建时按它重新映射
struct FolderMap {
  std::wstring host, dir;
  int access = 1;
};

// ---------------------------------------------------------------- 浏览器实例
class View {
 public:
  explicit View(int vid);
  ~View();
  LONG AddRef() { return InterlockedIncrement(&refs_); }
  LONG Release() {
    LONG r = InterlockedDecrement(&refs_);
    if (r == 0) delete this;
    return r;
  }

  int id = 0;
  DWORD thread = 0;
  HWND parent = nullptr, host = nullptr, top = nullptr;
  bool fill = false;
  RECT margin = {0, 0, 0, 0};
  bool visible = true, minimized = false;
  // state 与 closing 也会在调用方线程上读取（WV_IsReady、转交前检查句柄），所以是原子变量
  std::atomic<int> state{WV_STATE_CREATING};
  std::atomic<bool> closing{false};
  bool pendingDestroy = false, popupTarget = false, finished = false;
  int busy = 0;

  std::wstring initialUrl, lastUrl, pendingUrl;
  std::deque<std::wstring> htmlPages;  // 加载HTML 生成的内存页面（memFiles 的键），按加载顺序，最新的在最后
  std::wstring optUserData, optProxy, optArgs, optLang, optProfile, optRuntime;
  bool optInPrivate = false;
  int optFallback = -1;
  std::shared_ptr<EnvEntry> env;

  ComPtr<ICoreWebView2Controller> ctl;
  ComPtr<ICoreWebView2> wv;
  ComPtr<ICoreWebView2Settings> settings;

  int errCode = 0;
  HRESULT errHr = S_OK;
  std::wstring errMsg;
  bool errPlain = false;       // 运行时只是没有找到（卡片不再重复显示查找结果）
  bool recheckPending = false;  // 刚点了“重新检测”：仍然没有找到时在卡片上说明已经检测过
  bool errBroken = false;       // 没有可用的运行时，是因为找到的运行时文件不完整、放在网络位置或在本进程里已失效（卡片据此说明）
  bool errRestart = false;      // 其中是在本进程里已经启动失败的运行时：运行时客户端记住了失败，要重新启动程序才能再用它（卡片据此说明）
  bool errRestartInstalled = false;  // 而且它是电脑上装好的运行时：重新安装装的还是它，本次运行帮不上，卡片不提供一键安装
  bool errNetwork = false;      // 没有采用的是放在网络位置的固定版：卡片说明要放到本机磁盘，不说“文件缺失或损坏”
  int precheckRetries = 0;      // 运行时文件被别的程序占用时已经自动重试的次数
  int runtimeSwitches = 0;      // 本次创建因运行时用不了而自动换用别的运行时的次数（防止来回切换）
  // 程序自己的准备工作（WV_ShowProgress）：进度卡片的文字与进度。浏览器开始重建、就绪时清掉
  bool hostProgress = false;
  int hostPrevMode = 0;  // 显示进度卡片之前的卡片，收起时恢复
  int hostPermille = -1;
  std::wstring hostTitle, hostText, hostStatus;

  void* cb[WVE_MAX + 1];
  unsigned char cbNoOut[WVE_MAX + 1];  // 按 WVE_FLAG_NO_OUT 注册：回调应有的参数表不含最后的 int*，用 WVK_CANCEL / WVK_RESULT 回填
  std::map<int, int> iprops;
  std::map<int, std::wstring> sprops;

  bool bridgeOn = false;
  std::wstring bridgeName = L"epl", bridgeScriptId;
  std::vector<std::wstring> bridgeOrigins;
  std::map<std::wstring, void*> binds;
  std::set<int> pendingCalls;
  unsigned bridgeGen = 0;  // 桥接脚本的登记代次：改名或停用后，还在登记中的旧脚本完成时撤掉

  int newWindowMode = 1, permPolicy = 0, ctxMenuMode = 0, fullscreenMode = 1, recoverMode = 1;
  bool ignoreCert = false, silentDownload = false, blockImages = false, loading = false;
  std::wstring downloadDir;
  std::vector<std::wstring> blockUrls;
  std::set<unsigned> blockKeys;

  struct Dl {
    ComPtr<ICoreWebView2DownloadOperation> op;
    int lastPct = -1;
    std::wstring path;
  };
  std::map<int, Dl> downloads;
  int nextDl = 1;

  struct ReqFilter {
    std::wstring pat;
    int ctx;
  };
  std::vector<ReqFilter> reqFilters;
  bool reqHooked = false;
  std::set<std::wstring> addedFilters;  // 已经交给 WebView2 的过滤器 "ctx|pattern"
  struct MemFile {
    std::vector<unsigned char> data;
    std::wstring mime, url;  // url：交给 WebView2 过滤器的原样网址（只把协议和主机转成小写）
    bool page = false;       // 加载HTML 生成的页面：清空内存文件时保留，超出保留数量或总大小时由 PruneHtmlPages 删除最旧的
  };
  std::map<std::wstring, MemFile> memFiles;
  std::vector<std::pair<std::wstring, bool>> respRules;
  bool respHooked = false;

  struct CdpSub {
    ComPtr<ICoreWebView2DevToolsProtocolEventReceiver> r;
    EventRegistrationToken t;
  };
  std::map<std::wstring, CdpSub> cdpSubs;

  HWND fullWin = nullptr, savedParent = nullptr;
  RECT savedRect = {0, 0, 0, 0};
  bool isFull = false;

  struct PendingNW {
    ComPtr<ICoreWebView2NewWindowRequestedEventArgs> args;
    ComPtr<ICoreWebView2Deferral> def;
  };
  std::vector<PendingNW> pendingNW;

  PanelState panel;
  bool parentSub = false, topSub = false;

  // 生命周期（wv_view.cpp）
  bool StartCreate();
  void CreateController();
  void OnControllerCreated(HRESULT hr, ICoreWebView2Controller* c);
  void Fail(int code, const std::wstring& msg, HRESULT hr);
  void Recreate();
  void Destroy();
  void FinishDestroy();
  void OnHostDestroy();
  void Layout();
  void UpdateBounds();
  void NotifyMoved();
  void OnMinimize(bool m);
  void OnHostSize();
  void OnHostFocus();
  void SetVisible(bool v);
  void SetBounds(int x, int y, int w, int h);
  bool SetParentWindow(HWND p);
  void RegisterEvents();
  void ApplyAll();
  bool SetIntProp(int p, int v);
  int GetIntProp(int p);
  bool SetStrProp(int p, const std::wstring& v);
  std::wstring GetStrProp(int p);
  bool ApplyInt(int p, int v);
  bool ApplyStr(int p, const std::wstring& v);
  int Fire(int ev, std::initializer_list<intptr_t> args, EventCtx* ctx = nullptr);
  int FireFn(void* fn, int ev, std::initializer_list<intptr_t> args, EventCtx* ctx);
  int FireFn(void* fn, int ev, const std::vector<intptr_t>& args, EventCtx* ctx, int expected = -1);  // expected：应有的参数个数（默认等于传入的个数）
  bool HasCb(int ev) const { return ev > 0 && ev <= WVE_MAX && cb[ev] != nullptr; }
  bool Ready() const { return state == WV_STATE_READY && wv && ctl && !closing; }
  bool RequireReady();
  bool Navigate(const std::wstring& url);
  bool NavigateHtml(const std::wstring& html);
  void PruneHtmlPages();
  bool NavigateEx(const std::wstring& url, const std::wstring& method, const std::wstring& headers, const void* body, int len);
  bool Command(int cmd);
  void EnterFullscreen();
  void ExitFullscreen();
  void SetEvent(int ev, void* fn, bool noOut = false);

  // 提示卡片（wv_host.cpp）
  void Paint(HDC dc);
  void PaintAnim(HDC dc);
  bool PanelMouse(UINT msg, WPARAM wp, LPARAM lp, LRESULT& res);
  bool PanelKey(UINT msg, WPARAM wp, LPARAM lp, LRESULT& res);
  bool PanelHasButtons() const { return (panel.mode == 2 || panel.mode == 4) && panel.btnCount > 0; }
  bool FallbackEnabled() const;  // 本浏览器是否显示提示卡片（创建选项 fallback 优先，否则看全局选项）
  bool InstallCanHelp() const;   // 一键安装常青版运行时能否让本浏览器恢复（只用固定版、指定了运行时目录时不能；Win7/8/8.1 上装的是 109 版）
  bool PrecheckRuntime();        // 交给运行时客户端创建环境前检查运行时文件（本进程第一次用这个客户端时还查地址空间）；返回假时已经处理（换用别的运行时、稍后重试或显示卡片）
  bool ControllerFileFailure(HRESULT hr);  // 创建控件以“找不到文件”失败：运行时客户端已记住失败，换用别的运行时或显示卡片；返回真表示已处理
  void RuntimeUnusable(const std::wstring& why, bool inProcess);  // 当前运行时用不了：释放环境，换用别的运行时，没有时显示“没有可用的运行时”卡片
  std::wstring InstallStatusText(int* stage, int* permille);
  void ShowHostProgress(const std::wstring& title, const std::wstring& text, const std::wstring& status, int permille);  // WV_ShowProgress
  void OnTimer(UINT_PTR tid);
  void SetPanel(int mode);
  void PanelAction(int action);
  // 用户在卡片上选定了运行时所在的文件夹：本浏览器单独指定过运行时目录时改它自己的设置（全局设置对它不起作用），
  // 否则改全局设置并恢复所有在等待运行时的浏览器；没找到可用的运行时则在卡片上说明原因
  void UsePickedRuntime(const std::wstring& path);
  unsigned BgArgb() const;      // 背景色 0xAARRGGBB：本浏览器的 WVP_BG_COLOR，否则全局默认背景色，都没有时为白色
  COLORREF BgRef() const;
  bool BgTransparent() const;   // 透明背景：网页透明处露出宿主窗口画的内容，所以宿主窗口要画出父窗口的背景
  bool IsDarkBg() const;

  // 功能（wv_feat.cpp）
  bool ExecSync(const std::wstring& js, int flags, DWORD timeout, std::wstring& out);
  bool ExecAsync(const std::wstring& js, int flags, void* fn, int userData);
  bool CdpSync(const std::wstring& method, const std::wstring& params, DWORD timeout, std::wstring& out);
  bool AddInitScript(const std::wstring& js, DWORD timeout, std::wstring& outId);
  bool RemoveInitScript(const std::wstring& sid);
  bool Dom(int act, const std::wstring& sel, const std::wstring& val, DWORD timeout, std::wstring& out);
  bool Input(int kind, int x, int y, const std::wstring& text);
  bool PostMsg(const std::wstring& text, bool asJson);
  void EnsureBridge();
  void InjectBridge();
  void DisableBridge();  // 停用 JS 桥：撤掉桥接脚本，删掉当前网页里的桥对象
  void OnBridgeMessage(const JVal& m, const std::wstring& source, unsigned gen);  // gen：收到消息时的文档代次
  bool BridgeReply(int callId, bool ok, const std::wstring& payload);
  bool Emit(const std::wstring& name, const std::wstring& json);
  bool GetCookies(const std::wstring& url, int fmt, std::wstring& out);
  bool SetCookie(const std::wstring& url, const std::wstring& name, const std::wstring& value, const std::wstring& domain,
                 const std::wstring& path, int expires, int flags);
  bool SetCookieString(const std::wstring& url, const std::wstring& cookies);
  bool DeleteCookies(const std::wstring& url, const std::wstring& name);
  bool ClearData(int kinds);
  bool Capture(int fmt, bool full, std::vector<unsigned char>& out);
  bool PrintPdf(const std::wstring& path, bool landscape, DWORD timeout);
  bool CdpSubscribe(const std::wstring& ev, bool on);
  void EnsureRequestHook();
  void SyncRequestFilters();
  bool AddRequestFilter(const std::wstring& pat, int ctx);
  bool RemoveRequestFilter(const std::wstring& pat, int ctx);
  void EnsureResponseHook();
  bool SetResponseCapture(const std::wstring& patterns, bool body);
  bool MapFolder(const std::wstring& hostName, const std::wstring& folder, int access);
  bool AddMemoryFile(const std::wstring& url, const void* data, int len, const std::wstring& mime);
  bool DownloadControl(int did, int action);
  HRESULT OnWebResourceRequested(ICoreWebView2WebResourceRequestedEventArgs* a);
  HRESULT OnResponseReceived(ICoreWebView2WebResourceResponseReceivedEventArgs* a);
  HRESULT OnDownloadStarting(ICoreWebView2DownloadStartingEventArgs* a);
  HRESULT OnNewWindow(ICoreWebView2NewWindowRequestedEventArgs* a);
  HRESULT OnContextMenu(ICoreWebView2ContextMenuRequestedEventArgs* a);
  HRESULT OnKey(ICoreWebView2AcceleratorKeyPressedEventArgs* a);
  HRESULT OnWebMessage(ICoreWebView2WebMessageReceivedEventArgs* a);
  void CompletePendingNewWindows();
  // 把任务投递到宿主窗口，在 WebView2 事件处理函数之外执行；无法投递时就地执行（保证 Deferral 一定完成）
  void Post(std::function<void()> fn);
  void NavigateInitial();
  void HandleWebMessage(const std::wstring& json, const std::wstring& source, const std::wstring& text, unsigned gen, const std::wstring& files);  // files：postMessageWithAdditionalObjects 附带的文件路径（每行一个）
  bool HandleNewWindow(ICoreWebView2NewWindowRequestedEventArgs* a, const ComPtr<ICoreWebView2Deferral>& def);
  void HandleRequest(ICoreWebView2WebResourceRequestedEventArgs* a, ICoreWebView2WebResourceRequest* req, const std::wstring& uri,
                     const std::wstring& method, int rc);
  void HandleDownload(ICoreWebView2DownloadStartingEventArgs* a);
  bool navPending = false;  // 首次导航等待 JS 桥脚本登记完成
  std::map<std::wstring, FolderMap> mappedHosts;  // 映射目录（键为小写主机名）：未设 JS 桥白名单时算作本程序自己的内容；重建后重新映射
  struct InitScript {
    std::wstring userId, curId, js;  // userId：注入JS 返回给程序的编号（重建后不变）；curId：当前内核里的编号
  };
  std::vector<InitScript> initScripts;  // 程序注入的脚本：浏览器重建后重新登记
  std::set<std::wstring> cdpEvents;     // 订阅的 DevTools 事件：浏览器重建后重新订阅
  unsigned docGen = 0;                  // 顶层文档的代次：每打开一个新文档加 1（SourceChanged 的 IsNewDocument）
  std::map<int, unsigned> callGen;      // JS 桥调用 ID → 发起调用时的文档代次：网页已离开时不再把结果交给新网页
  int ReapplyState();                   // 重建后重新映射目录、登记注入的脚本、订阅 DevTools 事件；返回仍在登记中的脚本数
  std::deque<DWORD> recoverTicks;      // 最近几次自动恢复的时刻：短时间内反复崩溃时停止自动恢复
  bool AllowRecover();                 // 登记一次自动恢复；60 秒内已有 3 次时返回假

 private:
  volatile LONG refs_ = 1;
};

RefPtr<View> FindView(int id);
int AddView(View* v);
void RemoveView(int id);
std::vector<RefPtr<View>> AllViews();
std::wstring NormalizeUrl(const std::wstring& u);
void OnEnvCreated(const std::wstring& key, HRESULT hr, ICoreWebView2Environment* env);
void ForgetEnv(const std::shared_ptr<EnvEntry>& e);
std::wstring EnvListJson();
// 浏览器替网页写文件的文件夹：默认与实际的用户数据目录、各浏览器指定的下载目录（只在界面线程调用）。下载过的单个文件另由 WasDownloaded 查
std::vector<std::wstring> WebWrittenDirs();
// 本次运行里浏览器下载过的文件（只在界面线程访问）：RememberDownload 记下一个，WasDownloaded 按完整路径查（不区分大小写）
void RememberDownload(const std::wstring& file);
bool WasDownloaded(const std::wstring& fullPath);

}  // namespace wv
