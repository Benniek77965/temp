// wv_view.cpp : 浏览器实例的生命周期、环境缓存、事件注册、属性、导航、全屏
#include "wv_internal.h"

namespace wv {

// ---------------------------------------------------------------- 句柄表
static Lock& ViewsLock() {
  static Lock l;
  return l;
}
static std::map<int, View*>& Views() {
  static std::map<int, View*> m;
  return m;
}
static int g_nextId = 1;
static LONG g_htmlSeq = 0;  // 加载HTML 页面序号（进程内唯一，原子自增）

RefPtr<View> FindView(int id) {
  Guard g(ViewsLock());
  auto it = Views().find(id);
  return it == Views().end() ? RefPtr<View>() : RefPtr<View>(it->second);
}
int AddView(View* v) {
  Guard g(ViewsLock());
  v->id = g_nextId++;
  Views()[v->id] = v;
  return v->id;
}
void RemoveView(int id) {
  View* v = nullptr;
  {
    Guard g(ViewsLock());
    auto it = Views().find(id);
    if (it == Views().end()) return;
    v = it->second;
    Views().erase(it);
  }
  v->Release();
}
std::vector<RefPtr<View>> AllViews() {
  std::vector<RefPtr<View>> r;
  Guard g(ViewsLock());
  for (auto& kv : Views()) r.push_back(RefPtr<View>(kv.second));
  return r;
}

View::View(int vid) : id(vid) {
  for (auto& c : cb) c = nullptr;
  for (auto& f : cbNoOut) f = 0;
}
View::~View() {}

static std::wstring FileUrl(const std::wstring& path) {
  std::wstring p = ReplaceAll(path, L"\\", L"/"), o;
  for (wchar_t c : p) {
    if (c == L'%') o += L"%25";
    else if (c == L'#') o += L"%23";
    else if (c == L'?') o += L"%3F";
    else if (c == L' ') o += L"%20";
    else o += c;
  }
  return o.compare(0, 2, L"//") == 0 ? L"file:" + o : L"file:///" + o;
}

std::wstring NormalizeUrl(const std::wstring& in) {
  std::wstring u = Trim(in);
  if (u.empty()) return L"about:blank";
  bool drive = u.size() >= 3 && iswalpha(u[0]) && u[1] == L':' && (u[2] == L'\\' || u[2] == L'/');
  if (drive || u.compare(0, 2, L"\\\\") == 0) return FileUrl(u);
  size_t colon = u.find(L':');
  if (colon != std::wstring::npos && colon > 1) {
    bool scheme = iswalpha(u[0]) != 0;
    for (size_t i = 1; i < colon && scheme; ++i)
      scheme = iswalnum(u[i]) || u[i] == L'+' || u[i] == L'-' || u[i] == L'.';
    if (scheme) {
      std::wstring s = Lower(u.substr(0, colon));
      if (s == L"http" || s == L"https" || s == L"file" || s == L"about" || s == L"data" || s == L"blob" || s == L"javascript" ||
          s == L"edge" || s == L"view-source" || s == L"ftp" || s == L"chrome" || s == L"mailto" || u.compare(colon, 3, L"://") == 0)
        return u;
    }
  }
  // 相对路径：程序目录下确实存在的文件或目录按本地文件打开，例如 打开 (“ui\\index.html”)
  if (u.find(L'\\') != std::wstring::npos || u.find(L'/') != std::wstring::npos || u.find(L'.') != std::wstring::npos) {
    std::wstring local = PathJoin(AppDir(), u);
    if (GetFileAttributesW(local.c_str()) != INVALID_FILE_ATTRIBUTES) return FileUrl(local);
  }
  // 不带协议的地址：主机是 localhost 或 IP 地址（多为本机或内网服务）时补 http://，其余补 https://
  // 按主机名整体判断，不按前缀：localhost.example.com、10.example.com 是普通域名
  std::wstring host = u.substr(0, u.find_first_of(L"/?#"));
  if (!host.empty() && host[0] == L'[') return L"http://" + u;  // IPv6 地址，如 [::1]:8080
  host = host.substr(0, host.find(L':'));
  int dots = 0;
  for (wchar_t ch : host) dots += ch == L'.';
  bool ipv4 = !host.empty() && dots == 3 && host.find_first_not_of(L"0123456789.") == std::wstring::npos;
  if (_wcsicmp(host.c_str(), L"localhost") == 0 || ipv4) return L"http://" + u;
  return L"https://" + u;
}

// ---------------------------------------------------------------- 环境缓存（只在界面线程访问）
static std::map<std::wstring, std::shared_ptr<EnvEntry>>& Envs() {
  static std::map<std::wstring, std::shared_ptr<EnvEntry>> m;
  return m;
}
static std::map<std::wstring, std::wstring>& UdfConfig() {
  static std::map<std::wstring, std::wstring> m;
  return m;
}

void ForgetEnv(const std::shared_ptr<EnvEntry>& e) {
  if (!e) return;
  auto it = Envs().find(e->key);
  if (it == Envs().end() || it->second != e) return;  // 只删同一个对象：别的浏览器可能已用同一键重建了新环境
  std::wstring udfKey = Lower(it->second->udf);
  auto u = UdfConfig().find(udfKey);
  if (u != UdfConfig().end() && u->second == it->second->configKey) UdfConfig().erase(u);
  Envs().erase(it);
}

std::wstring EnvListJson() {
  std::wstring s = L"[";
  bool first = true;
  for (auto& kv : Envs()) {
    if (!first) s += L',';
    first = false;
    auto& e = kv.second;
    s += L"{\"state\":" + std::to_wstring(e->state) + L",\"userData\":" + JsonStr(e->udf) + L",\"args\":" + JsonStr(e->args) +
         L",\"runtime\":" + JsonStr(e->rt.version) + L",\"hr\":" + JsonStr(Fmt(L"0x%08X", (unsigned)e->hr)) + L"}";
  }
  return s + L"]";
}

// 浏览器替网页写文件的文件夹（只在界面线程调用）：程序目录里默认的用户数据目录、各浏览器环境实际用的用户数据目录，以及各浏览器指定的下载目录。
// JS 桥判断“本程序自己的内容”时，程序目录里的这些文件夹不算（里面的缓存、下载的文件等是网页的内容）。默认的用户数据目录直接按路径拼出，
// 不调用 DefaultUserDataDir ()：它会建目录、试写文件
std::vector<std::wstring> WebWrittenDirs() {
  std::vector<std::wstring> r{PathJoin(AppDir(), L"WebView2Data")};
  for (const auto& kv : Envs()) r.push_back(kv.second->udf);
  for (const auto& v : AllViews())
    if (!v->downloadDir.empty()) r.push_back(v->downloadDir);
  return r;  // 下载过的单个文件不放在这里，另由 WasDownloaded 按哈希表查
}

static bool ResolveEnv(View* v, std::shared_ptr<EnvEntry>& out, int& code, std::wstring& err) {
  Globals g;
  {
    Guard lk(GLock());
    g = G();
  }
  RuntimeInfo rt = FindRuntime(false, v->optRuntime);
  if (!rt.found) {
    code = WVERR_NO_RUNTIME;
    err = rt.reason;
    v->errPlain = rt.plainMissing;
    v->errBroken = !rt.broken.empty();  // 找到了运行时却用不了（文件不完整、放在网络位置、本进程里已失效）：卡片按具体原因说明
    v->errRestart = !rt.broken.empty() && rt.broken[0].inProcess;  // 原因写的就是 broken[0]：本进程里已失效时卡片说明要重新启动程序
    v->errRestartInstalled = v->errRestart && rt.broken[0].kind == 0;
    v->errNetwork = !rt.broken.empty() && rt.broken[0].network;
    return false;
  }
  // 环境变量与组策略（与官方加载器一致）：数据目录覆盖程序自己的设置，附加参数追加在后面
  const LoaderOverrides ov = ReadLoaderOverrides();
  bool explicitUdf = !ov.userDataFolder.empty() || !v->optUserData.empty() || !g.userDataDir.empty();
  std::wstring udf = !ov.userDataFolder.empty() ? ov.userDataFolder
                     : !v->optUserData.empty()   ? v->optUserData
                                                  : (!g.userDataDir.empty() ? g.userDataDir : DefaultUserDataDir());
  udf = AppPath(udf);  // 与其它路径一致：带盘符或以两个斜杠开头的是绝对路径
  udf = TrimSlash(udf);
  std::wstring args = Trim(g.args + L" " + v->optArgs);
  std::wstring proxy = !v->optProxy.empty() ? v->optProxy : g.proxy;
  proxy = Trim(proxy);
  if (!proxy.empty() && !ValidProxy(proxy)) {  // 创建选项里单独指定的代理也在这里把关
    Log(L"代理地址含空格、引号或控制字符，已忽略：%ls", proxy.c_str());
    proxy.clear();
  }
  if (!proxy.empty()) {
    if (_wcsicmp(proxy.c_str(), L"direct") == 0 || _wcsicmp(proxy.c_str(), L"none") == 0) args += L" --no-proxy-server";
    else args += L" --proxy-server=" + proxy;
  }
  if (g.disableGpu) args += L" --disable-gpu";
  if (g.autoplay) args += L" --autoplay-policy=no-user-gesture-required";
  if (g.ignoreCert) args += L" --ignore-certificate-errors";
  if (!ov.extraArgs.empty()) args += L" " + ov.extraArgs;  // 管理员给出的参数视为可信，不做代理地址那样的字符检查
  args = Trim(args);
  std::wstring lang = !v->optLang.empty() ? v->optLang : g.lang;
  std::wstring configKey = args + L"|" + lang + L"|" + std::to_wstring(g.tracking) + L"|" + std::to_wstring(g.scrollbar) + L"|" + rt.sel.dir;
  std::wstring udfKey = Lower(udf);
  auto used = UdfConfig().find(udfKey);
  // 1.8.3：与登记的配置只差在运行时目录（启动参数、语言、跟踪防护、滚动条都相同），这个浏览器也没单独指定运行时：
  // 同一数据目录同一时刻只能被一个版本的浏览器进程使用。常青版在程序运行中更新后，再新建的浏览器会选到新版本——
  // 这个数据目录上还有浏览器在用旧环境时，沿用旧环境（不再报“数据目录已被参数不同的浏览器使用”）；已经没有浏览器在用时
  // 丢掉旧环境，改用新选的运行时（原来会一直报冲突，直到程序重启）
  if (used != UdfConfig().end() && used->second != configKey && v->optRuntime.empty()) {
    const size_t a = used->second.rfind(L'|'), b = configKey.rfind(L'|');
    if (a != std::wstring::npos && a == b && used->second.compare(0, a, configKey, 0, b) == 0) {
      auto old = Envs().find(udfKey + L"#" + used->second);
      std::shared_ptr<EnvEntry> oldEnv = old != Envs().end() ? old->second : nullptr;
      bool live = false;
      if (oldEnv)
        for (auto& o : AllViews())
          if (o.get() != v && o->env == oldEnv && !o->closing) { live = true; break; }
      if (live) {
        Log(L"数据目录 %ls 还有浏览器在用运行时 %ls：新浏览器沿用它（新选的运行时 %ls 要等这些浏览器都关闭后才用）", udf.c_str(),
            oldEnv->rt.dir.c_str(), rt.sel.dir.c_str());
        configKey = used->second;
      } else {
        Log(L"数据目录 %ls 已没有浏览器在用旧运行时：改用新选的运行时 %ls", udf.c_str(), rt.sel.dir.c_str());
        if (oldEnv) ForgetEnv(oldEnv);
        else UdfConfig().erase(used);
      }
      used = UdfConfig().find(udfKey);
    }
  }
  if (used != UdfConfig().end() && used->second != configKey) {
    if (explicitUdf) {
      code = WVERR_DATA_CONFLICT;
      err = L"用户数据目录 " + udf + L" 已被启动参数（代理、语言、浏览器参数或运行时）不同的浏览器使用；请给不同配置指定不同的数据目录";
      return false;
    }
    udf = PathJoin(udf, L"cfg_" + Hash8(configKey));  // 未显式指定目录时自动隔离，例如每个浏览器用不同代理
    udfKey = Lower(udf);
  }
  if (!EnsureDir(udf)) {
    code = WVERR_IO;
    err = L"无法创建用户数据目录：" + udf;
    return false;
  }
  std::wstring key = udfKey + L"#" + configKey;
  auto it = Envs().find(key);
  if (it != Envs().end() && it->second->state != 2) {
    out = it->second;
    return true;
  }
  auto e = std::make_shared<EnvEntry>();
  e->key = key;
  e->udf = udf;
  e->args = args;
  e->lang = lang;
  e->configKey = configKey;
  e->rt = rt.sel;
  Envs()[key] = e;
  UdfConfig()[udfKey] = configKey;
  out = e;
  (void)g.tracking;
  return true;
}

void OnEnvCreated(const std::wstring& key, HRESULT hr, ICoreWebView2Environment* created) {
  auto it = Envs().find(key);
  if (it == Envs().end()) return;
  std::shared_ptr<EnvEntry> e = it->second;
  if (e->state != 0) return;
  if (SUCCEEDED(hr) && created) {
    e->state = 1;
    e->env = ComPtr<ICoreWebView2Environment>::From(created);
    CoStr ver;
    created->get_BrowserVersionString(ver.put());
    Log(L"环境就绪：内核 %ls", ver.str().c_str());
  } else {
    e->state = 2;
    e->hr = FAILED(hr) ? hr : E_FAIL;
  }
  std::vector<int> waiters;
  waiters.swap(e->waiters);
  if (e->state == 2) ForgetEnv(e);
  for (int vid : waiters) {
    RefPtr<View> v = FindView(vid);
    if (!v || v->closing || v->state != WV_STATE_CREATING || v->env != e) continue;
    if (e->state == 1) v->CreateController();
    else v->Fail(WVERR_ENV_FAILED, L"浏览器环境创建失败：" + FriendlyHr(e->hr), e->hr);
  }
}

// ---------------------------------------------------------------- 创建
bool View::StartCreate() {
  state = WV_STATE_CREATING;
  errCode = 0;
  errHr = S_OK;
  errMsg.clear();
  errPlain = false;
  errBroken = false;
  errRestart = false;
  errRestartInstalled = false;
  errNetwork = false;
  hostProgress = false;  // 程序的进度卡片到此为止：浏览器开始重建
  SetPanel(1);
  std::shared_ptr<EnvEntry> e;
  int code = 0;
  std::wstring err;
  if (!ResolveEnv(this, e, code, err)) {
    Fail(code, err, S_OK);
    return false;
  }
  env = e;
  if (e->state == 1) {
    CreateController();
    return state != WV_STATE_FAILED;
  }
  // 交给运行时客户端创建环境之前先查运行时文件（新的环境要启动新的浏览器进程）；本进程里第一次用这个客户端时还查地址空间：
  // 客户端第一次创建环境时就映射 icudtl.dat、初始化 ICU，失败也不报错，到创建控件时才以 0x80070002 失败，并且记住失败（实测）
  if (!e->started && !PrecheckRuntime()) return state != WV_STATE_FAILED;
  e->waiters.push_back(id);
  if (!e->started) {
    e->started = true;
    MarkClientEnvTried(e->rt.clientDll);
    int tracking = 0, scrollbar = 0;
    {
      Guard g(GLock());
      tracking = G().tracking;
      scrollbar = G().scrollbar;
    }
    ComPtr<IUnknown> opts = MakeEnvOptions(e->args, e->lang, e->rt.version, tracking, scrollbar);
    std::wstring key = e->key;
    auto h = Callback<ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler, HRESULT, ICoreWebView2Environment*>(
        [key](HRESULT hr, ICoreWebView2Environment* created) -> HRESULT {
          OnEnvCreated(key, hr, created);
          return S_OK;
        });
    HRESULT hr = CreateEnvironment(e->rt, e->udf, opts.get(), h.get());
    if (FAILED(hr)) OnEnvCreated(key, hr, nullptr);
  }
  return state != WV_STATE_FAILED;
}

void View::CreateController() {
  if (!env || !env->env || closing) return;
  int vid = id;
  auto h = Callback<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler, HRESULT, ICoreWebView2Controller*>(
      [vid](HRESULT hr, ICoreWebView2Controller* c) -> HRESULT {
        RefPtr<View> v = FindView(vid);
        if (!v || v->closing || v->state != WV_STATE_CREATING) {
          if (c) c->Close();
          return S_OK;
        }
        v->OnControllerCreated(hr, c);
        return S_OK;
      });
  HRESULT hr = E_FAIL;
  ComPtr<ICoreWebView2Environment10> e10 = env->env.as<ICoreWebView2Environment10>();
  if ((!optProfile.empty() || optInPrivate) && e10) {
    ComPtr<ICoreWebView2ControllerOptions> o;
    hr = e10->CreateCoreWebView2ControllerOptions(o.put());
    if (SUCCEEDED(hr) && o) {
      if (!optProfile.empty()) o->put_ProfileName(optProfile.c_str());
      if (optInPrivate) o->put_IsInPrivateModeEnabled(TRUE);
      hr = e10->CreateCoreWebView2ControllerWithOptions(host, o.get(), h.get());
    }
  } else if (!optProfile.empty() || optInPrivate) {
    // 隐身模式被换成普通模式会把 Cookie 等数据持久保存，配置名称被忽略会让不同账号共用数据：如实报告，不悄悄改变语义
    Fail(WVERR_UNSUPPORTED, L"当前内核不支持配置名称或隐身模式（需要 Edge 101+）", E_NOINTERFACE);
    return;
  } else {
    hr = env->env->CreateCoreWebView2Controller(host, h.get());
  }
  if (FAILED(hr) && !ControllerFileFailure(hr)) Fail(WVERR_CTRL_FAILED, L"创建浏览器控件失败：" + FriendlyHr(hr), hr);
}

void View::OnControllerCreated(HRESULT hr, ICoreWebView2Controller* c) {
  if (FAILED(hr) || !c) {
    if (FAILED(hr) && ControllerFileFailure(hr)) return;
    Fail(WVERR_CTRL_FAILED, L"创建浏览器控件失败：" + FriendlyHr(FAILED(hr) ? hr : E_FAIL), FAILED(hr) ? hr : E_FAIL);
    return;
  }
  if (env) MarkClientReady(env->rt.clientDll);  // 这个运行时客户端成功启动过：ICU 已初始化，之后在它上面创建控件不必再查文件与地址空间
  runtimeSwitches = 0;
  precheckRetries = 0;
  ctl = ComPtr<ICoreWebView2Controller>::From(c);
  ctl->get_CoreWebView2(wv.put());
  if (!wv) {
    Fail(WVERR_CTRL_FAILED, L"浏览器控件没有返回网页对象", E_NOINTERFACE);
    return;
  }
  wv->get_Settings(settings.put());
  state = WV_STATE_READY;
  ApplyAll();
  RegisterEvents();
  navPending = true;
  ++docGen;  // 新的内核里是新的文档：旧调用的结果不再送出
  const int pendingScripts = ReapplyState();  // 重建时恢复映射目录、注入的脚本与 DevTools 订阅（首次创建时没有）
  if (bridgeOn) {
    InjectBridge();  // 登记完成后才进行首次导航（见 InjectBridge）
    if (host && navPending) SetTimer(host, 3, 3000, nullptr);
  } else if (pendingScripts > 0 && host) {
    SetTimer(host, 3, 3000, nullptr);  // 注入的脚本迟迟登记不完时照常导航
  }
  if (!reqFilters.empty() || !memFiles.empty() || !blockUrls.empty() || blockImages || HasCb(WVE_REQUEST)) {
    reqHooked = false;
    addedFilters.clear();
    EnsureRequestHook();
  }
  if (!respRules.empty() || HasCb(WVE_RESPONSE)) {
    respHooked = false;
    EnsureResponseHook();
  }
  UpdateBounds();
  ctl->put_IsVisible(visible && !minimized ? TRUE : FALSE);
  hostProgress = false;  // 就绪：程序的进度卡片（如果有）随之收起
  SetPanel(0);
  if (host) InvalidateRect(host, nullptr, FALSE);
  CoStr ver;
  if (env && env->env) env->env->get_BrowserVersionString(ver.put());
  Log(L"浏览器 #%d 就绪（内核 %ls）", id, ver.str().c_str());
  CompletePendingNewWindows();
  if (!bridgeOn && pendingScripts == 0) NavigateInitial();
  const int vid = id;
  Post([vid] {
    WV_TASK(vid);
    v->Fire(WVE_READY, {(intptr_t)vid, 1});
  });
}

bool View::FallbackEnabled() const {
  if (optFallback >= 0) return optFallback != 0;
  Guard g(GLock());
  return G().fallback != 0;
}

// Win7/8/8.1 也能一键安装：用微软更新目录里的 109 版离线安装包（见 UseLegacyOfflinePackage；微软当前的在线安装程序在 Win7 上启动不了）；
// 更早的系统装不了
bool View::InstallCanHelp() const { return EvergreenAllowed(optRuntime) && (OnlineInstallerSupported() || UseLegacyOfflinePackage()); }

// 交给运行时客户端创建环境之前再查一次运行时文件：查找运行时的结果有缓存，文件可能在那之后才被删除或占用。本进程里第一次用这个客户端时
// （它在这时映射 icudtl.dat 初始化 ICU）还查地址空间。客户端在这一步遇到问题会记住失败（见 wv_runtime.cpp 的“运行时文件自检”），所以发现问题就不交给它
bool View::PrecheckRuntime() {
#ifdef WV_TEST_NO_PRECHECK  // 只供测试：跳过预检，验证运行时客户端失败后的处理（ControllerFileFailure）
  return true;
#endif
  const RuntimeCandidate rt = env->rt;
  const RuntimeFileCheck fc = CheckRuntimeFiles(rt.dir);
  if (!fc.ok) {
    Log(L"浏览器 #%d：运行时 %ls 文件不完整（%ls）", id, rt.dir.c_str(), fc.reason.c_str());
    RuntimeUnusable(fc.reason, false);
    return false;
  }
  // 客户端还没碰这些文件：丢掉刚登记、还没开始创建的环境（不让它占着数据目录），再说明原因
  auto drop = [this] {
    if (env && !env->started && env->waiters.empty()) ForgetEnv(env);
    env.reset();
  };
  if (fc.busy) {  // 杀毒软件扫描、别的程序正在解压覆盖：稍后自动重试（最多 10 次，约 15 秒）
    drop();
    const bool again = precheckRetries < 10;
    if (again) ++precheckRetries;
    Log(L"浏览器 #%d：%ls，%ls", id, fc.reason.c_str(), again ? L"稍后重试" : L"不再自动重试");
    Fail(WVERR_CTRL_FAILED, L"网页组件的文件暂时打不开：" + fc.reason + (again ? L"。稍后会自动重试" : L"。等它结束后点“重试”"),
         HRESULT_FROM_WIN32(ERROR_SHARING_VIOLATION));
    if (again && host) SetTimer(host, 5, 1500, nullptr);
    return false;
  }
  std::wstring aclWhy;
  if (!EnsureFixedRuntimeAcl(rt, aclWhy)) {  // Windows 10 上 120 及以上的固定版：没有 AppContainer 读取权限时一启动就崩溃，不交给客户端
    drop();
    Log(L"浏览器 #%d：%ls", id, aclWhy.c_str());
    Fail(WVERR_CTRL_FAILED, aclWhy, E_ACCESSDENIED);
    return false;
  }
  if (ClientEnvTried(rt.clientDll)) return true;  // 本进程里这个客户端创建过环境：ICU 已经初始化（成败已定），不再需要映射 icudtl.dat
  const unsigned long long need = (fc.icuSize + 0xFFFFull) & ~0xFFFFull, freeMax = LargestFreeRegion();
  if (need && freeMax < need) {  // 一定映射不进来：不交给客户端（交给它会失败并记住失败）。换运行时也没用，内存降下来或重启程序才行
    drop();
    Fail(WVERR_CTRL_FAILED,
         Fmt(L"程序的内存地址空间不足：网页组件启动时要把 %.1f MB 的 icudtl.dat 整个映射进本程序，现在最大的连续空闲地址空间只有 %.1f MB"
             L"（32 位程序运行久了、占用内存多时会这样），请重新启动程序后再打开",
             need / 1048576.0, freeMax / 1048576.0),
         E_OUTOFMEMORY);
    return false;
  }
  return true;
}

// 创建控件以“找不到文件”失败，而这个运行时客户端在本进程里还没有成功启动过：客户端已经记住失败（实测缺少 msedgewebview2.exe 或
// icudtl.dat、icudtl.dat 为空或被独占打开、地址空间放不下 icudtl.dat 都是这样，之后把文件放回、换数据目录新建环境都还是立即失败），
// 本进程里不再使用它：换用别的运行时（例如刚一键安装的常青版，它是另一个运行时客户端），没有时显示“没有可用的运行时”卡片
bool View::ControllerFileFailure(HRESULT hr) {
  if (!env || (hr != HRESULT_FROM_WIN32(ERROR_FILE_NOT_FOUND) && hr != HRESULT_FROM_WIN32(ERROR_PATH_NOT_FOUND))) return false;
  if (ClientEverReady(env->rt.clientDll)) return false;
  const RuntimeCandidate rt = env->rt;
  const RuntimeFileCheck fc = CheckRuntimeFiles(rt.dir);
  std::wstring why = fc.reason;
  if (why.empty()) {
    const unsigned long long need = (fc.icuSize + 0xFFFFull) & ~0xFFFFull, freeMax = LargestFreeRegion();
    why = need && freeMax < need + (16ull << 20)
              ? Fmt(L"启动时程序可用的连续内存地址空间可能不足（现在最大 %.1f MB）", freeMax / 1048576.0)
              : std::wstring(L"运行时组件报告找不到文件：启动时 msedgewebview2.exe 或 icudtl.dat 打不开（可能被杀毒软件拦截或临时占用）");
  }
  Log(L"浏览器 #%d：运行时 %ls 创建控件失败（0x%08X，%ls），本进程里不再使用它", id, rt.dir.c_str(), (unsigned)hr, why.c_str());
  RuntimeUnusable(why, true);
  return true;
}

void View::RuntimeUnusable(const std::wstring& why, bool inProcess) {
  std::shared_ptr<EnvEntry> e = env;
  if (e) {
    if (inProcess) MarkClientBroken(e->rt.clientDll, why);
    bool live = false;
    for (auto& o : AllViews())
      if (o.get() != this && o->env == e && o->state == WV_STATE_READY) live = true;
    // 释放它对用户数据目录的登记：不释放的话，指定了数据目录时换用别的运行时会报“数据目录已被参数不同的浏览器使用”（实测）
    if (!live) ForgetEnv(e);
  }
  env.reset();
  const RuntimeInfo r = FindRuntime(true, optRuntime);  // 重新查找：文件不完整、本进程里已失效的运行时这时已被排除
  if (r.found && runtimeSwitches < 2 && (!e || _wcsicmp(r.sel.clientDll.c_str(), e->rt.clientDll.c_str()) != 0)) {
    ++runtimeSwitches;
    Log(L"浏览器 #%d：改用运行时 %ls（%ls）", id, r.sel.dir.c_str(), r.sel.version.c_str());
    if (host) PostMessageW(host, WM_WV_RECREATE, 0, 0);  // 回到消息循环再建：现在可能还在环境创建完成的通知里
    else StartCreate();
    return;
  }
  errPlain = false;
  errBroken = true;
  errRestart = r.found ? inProcess : (!r.broken.empty() && r.broken[0].inProcess);
  errRestartInstalled = errRestart && (r.found ? (e && e->rt.kind == 0) : r.broken[0].kind == 0);
  errNetwork = !r.found && !r.broken.empty() && r.broken[0].network;
  Fail(WVERR_NO_RUNTIME, r.found ? why : r.reason, HRESULT_FROM_WIN32(ERROR_FILE_NOT_FOUND));
}

void View::Fail(int code, const std::wstring& msg, HRESULT hr) {
  state = WV_STATE_FAILED;
  errCode = code;
  errMsg = msg;
  errHr = hr;
  Log(L"浏览器 #%d 创建失败：%ls", id, msg.c_str());
  if (FallbackEnabled()) SetPanel(2);
  else SetPanel(0);
  const int vid = id;
  Post([vid] {
    RefPtr<View> v = FindView(vid);
    if (v && !v->closing) v->Fire(WVE_READY, {(intptr_t)vid, 0});
  });
}

void View::Recreate() {
  if (closing) return;
  // 弹窗目标不自己打开初始网址（内容由打开它的网页交过来）。重建时已经没有在等它的弹窗，就按最后的网址重新打开：
  // 原来弹窗目标的浏览器进程退出后，恢复出来一直是空白页
  if (pendingNW.empty()) popupTarget = false;
  if (isFull) ExitFullscreen();
  if (ctl) ctl->Close();
  ctl.reset();
  wv.reset();
  settings.reset();
  cdpSubs.clear();
  downloads.clear();
  bridgeScriptId.clear();
  if (env && env->state != 1) env.reset();
  if (env && state == WV_STATE_READY) {
    // 浏览器进程已退出时，旧环境可能失效：丢弃缓存，重新建环境
    ForgetEnv(env);
    env.reset();
  }
  if (env && state == WV_STATE_FAILED) {
    // 创建控件失败后重试：按微软的建议从新建环境开始（ICoreWebView2Environment::CreateCoreWebView2Controller 的说明：失败后重试时
    // 宜重新创建环境，旧的环境对象可能已经失效）。原来总是沿用同一个环境。别的浏览器还在这个环境上正常运行时环境本身是好的，仍然沿用
    bool live = false;
    for (auto& o : AllViews())
      if (o.get() != this && o->env == env && o->state == WV_STATE_READY) live = true;
    if (!live) ForgetEnv(env);
    env.reset();
  }
  StartCreate();
}

// 60 秒内最多自动恢复 3 次：偶尔的崩溃照常恢复，反复崩溃时停下来（浏览器进程退出时显示“页面意外关闭了”卡片，可手动重新加载）
bool View::AllowRecover() {
  const DWORD now = GetTickCount();
  while (!recoverTicks.empty() && now - recoverTicks.front() > 60000) recoverTicks.pop_front();
  if (recoverTicks.size() >= 3) return false;
  recoverTicks.push_back(now);
  return true;
}

// ---------------------------------------------------------------- 销毁
void View::Destroy() {
  if (closing) return;
  if (busy > 0) {
    pendingDestroy = true;
    if (host) ShowWindow(host, SW_HIDE);
    return;
  }
  FinishDestroy();
}

void View::FinishDestroy() {
  if (finished) return;
  finished = true;
  closing = true;
  pendingDestroy = false;
  state = WV_STATE_CLOSED;
  pendingCalls.clear();
  callGen.clear();
  for (auto& p : pendingNW)
    if (p.def) p.def->Complete();
  pendingNW.clear();
  if (fullWin) {
    HWND fw = fullWin;
    fullWin = nullptr;
    if (savedParent && IsWindow(savedParent) && host) SetParent(host, savedParent);
    DestroyWindow(fw);
  }
  if (parentSub) UnhookParent(parent, (UINT_PTR)id);
  if (topSub) UnhookParent(top, (UINT_PTR)id | 0x40000000u);
  parentSub = topSub = false;
  if (ctl) ctl->Close();
  ctl.reset();
  wv.reset();
  settings.reset();
  cdpSubs.clear();
  downloads.clear();
  env.reset();
  HWND h = host;
  host = nullptr;
  if (h && IsWindow(h)) {
    SetWindowLongPtrW(h, GWLP_USERDATA, 0);
    DestroyWindow(h);
  }
  Log(L"浏览器 #%d 已销毁", id);
  RemoveView(id);
}

void View::OnHostDestroy() {
  // 父窗口被销毁时宿主窗口随之销毁：释放全部资源
  if (finished) return;
  if (busy > 0) {
    closing = true;
    pendingDestroy = true;
    host = nullptr;
    return;
  }
  host = nullptr;
  FinishDestroy();
}

// ---------------------------------------------------------------- 尺寸、可见、焦点
void View::Layout() {
  if (!fill || !host || !parent || isFull) return;
  RECT rc;
  GetClientRect(parent, &rc);
  int x = rc.left + margin.left, y = rc.top + margin.top;
  int w = std::max(0, (int)(rc.right - rc.left - margin.left - margin.right));
  int h = std::max(0, (int)(rc.bottom - rc.top - margin.top - margin.bottom));
  SetWindowPos(host, nullptr, x, y, w, h, SWP_NOZORDER | SWP_NOACTIVATE);
}
void View::UpdateBounds() {
  if (!ctl || !host) return;
  RECT rc;
  GetClientRect(host, &rc);
  ctl->put_Bounds(rc);
}
void View::NotifyMoved() {
  if (ctl) ctl->NotifyParentWindowPositionChanged();
}
void View::OnMinimize(bool m) {
  if (minimized == m) return;
  minimized = m;
  if (ctl) ctl->put_IsVisible(visible && !minimized ? TRUE : FALSE);  // 最小化时隐藏，按微软建议降低占用
}
void View::OnHostSize() {
  UpdateBounds();
  panel.animValid = false;  // 动画区域的位置随尺寸变化，等下一次完整绘制重新记录
  if (host && panel.mode) InvalidateRect(host, nullptr, FALSE);
}
void View::OnHostFocus() {
  if (!ctl) return;
  // 用 Tab 键进入时聚焦网页的第一个元素，Shift+Tab 进入时聚焦最后一个；点击或程序设置焦点时回到网页原来的焦点
  COREWEBVIEW2_MOVE_FOCUS_REASON r = COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC;
  if (GetKeyState(VK_TAB) & 0x8000)
    r = (GetKeyState(VK_SHIFT) & 0x8000) ? COREWEBVIEW2_MOVE_FOCUS_REASON_PREVIOUS : COREWEBVIEW2_MOVE_FOCUS_REASON_NEXT;
  ctl->MoveFocus(r);
}
void View::SetVisible(bool v) {
  visible = v;
  if (host) ShowWindow(host, v ? SW_SHOWNA : SW_HIDE);
  if (ctl) ctl->put_IsVisible(visible && !minimized ? TRUE : FALSE);
}
void View::SetBounds(int x, int y, int w, int h) {
  if (w <= 0 || h <= 0) {
    fill = true;
    margin.left = x;
    margin.top = y;
    margin.right = w < 0 ? -w : 0;
    margin.bottom = h < 0 ? -h : 0;
    Layout();
  } else {
    fill = false;
    if (host && !isFull) SetWindowPos(host, nullptr, x, y, w, h, SWP_NOZORDER | SWP_NOACTIVATE);
  }
}
bool View::SetParentWindow(HWND p) {
  if (!p || !IsWindow(p) || !host) {
    SetErr(WVERR_ARG, L"新的父窗口无效");
    return false;
  }
  // 与创建时的要求相同：父窗口必须属于界面线程（本函数就在界面线程上执行）。原来不检查，换成别的线程（或别的进程）的窗口后，
  // 两个线程的输入队列被连在一起，跨线程发送的窗口消息可能互相等待
  if (GetWindowThreadProcessId(p, nullptr) != GetCurrentThreadId()) {
    SetErr(WVERR_THREAD, L"新的父窗口必须属于界面线程（与创建浏览器时的要求相同）");
    return false;
  }
  if (parentSub) UnhookParent(parent, (UINT_PTR)id);
  if (topSub) UnhookParent(top, (UINT_PTR)id | 0x40000000u);
  parentSub = topSub = false;
  parent = p;
  if (!isFull) SetParent(host, p);
  else savedParent = p;  // 全屏中更换父窗口：退出全屏时回到新的父窗口
  top = GetAncestor(p, GA_ROOT);
  parentSub = HookParent(parent, (UINT_PTR)id, id);
  if (top && top != parent) topSub = HookParent(top, (UINT_PTR)id | 0x40000000u, id);
  Layout();
  NotifyMoved();
  return true;
}

// ---------------------------------------------------------------- 事件分发
// 回调参数里哪些是文本指针：第 i 位对应第 i 个参数（第 0 个是浏览器句柄）；事件号 0 是 WV_ExecScriptAsync 的回调。
// 与 wv2bridge.h 里各事件的参数说明一一对应，供回调转发（WVO_CALLBACK_HOOK）转换文本
static unsigned CallbackTextMask(int ev) {
  static const unsigned kMask[WVE_MAX + 1] = {
      1u << 3,                            // 0 WV_ExecScriptAsync：(h, 用户数据, 是否成功, 结果)
      0,                                  // WVE_READY
      1u << 1,                            // WVE_NAV_STARTING：(h, 网址, 用户发起, 是重定向, int*)
      1u << 1,                            // WVE_NAV_COMPLETED：(h, 网址, 是否成功, HTTP状态码, 错误码)
      1u << 1,                            // WVE_SOURCE_CHANGED
      1u << 1,                            // WVE_TITLE_CHANGED
      1u << 1,                            // WVE_DOM_READY
      (1u << 1) | (1u << 2) | (1u << 3),  // WVE_MESSAGE：(h, 文本, JSON, 来源网址)
      1u << 1,                            // WVE_NEW_WINDOW：(h, 网址, 用户发起, int*)
      (1u << 2) | (1u << 3),              // WVE_DOWNLOAD_START：(h, 下载ID, 网址, 保存路径, int*)
      0,                                  // WVE_DOWNLOAD_PROGRESS
      1u << 3,                            // WVE_DOWNLOAD_DONE：(h, 下载ID, 结果, 保存路径)
      1u << 1,                            // WVE_PERMISSION：(h, 网址, 权限类型, int*)
      0,                                  // WVE_PROCESS_FAILED
      0,                                  // WVE_FULLSCREEN
      0,                                  // WVE_CLOSE_REQUESTED
      0,                                  // WVE_KEY
      1u << 1,                            // WVE_FAVICON
      1u << 1,                            // WVE_STATUS_TEXT
      0,                                  // WVE_AUDIO
      (1u << 2) | (1u << 3),              // WVE_SCRIPT_DIALOG：(h, 类型, 消息, 网址, int*)
      (1u << 1) | (1u << 2),              // WVE_AUTH：(h, 网址, 认证说明, int*)
      (1u << 1) | (1u << 2),              // WVE_REQUEST：(h, 网址, 方法, 资源类型, int*)
      (1u << 1) | (1u << 3),              // WVE_RESPONSE：(h, 网址, 状态码, 方法, 内容长度)
      (1u << 1) | (1u << 2),              // WVE_CDP_EVENT：(h, 事件名, 参数JSON)
      0,                                  // WVE_ZOOM
      0,                                  // WVE_HISTORY
      1u << 1,                            // WVE_CERT_ERROR：(h, 网址, 错误码, int*)
      (1u << 1) | (1u << 2),              // WVE_JS_CALL（也是 WV_Bind 的回调）：(h, 函数名, 参数JSON, 调用ID)
  };
  return ev >= 0 && ev <= WVE_MAX ? kMask[ev] : 0u;
}

int View::FireFn(void* fn, int ev, std::initializer_list<intptr_t> args, EventCtx* ctx) {
  return FireFn(fn, ev, std::vector<intptr_t>(args), ctx);
}
int View::FireFn(void* fn, int ev, const std::vector<intptr_t>& args, EventCtx* ctx, int expected) {
  if (!fn) return 0;
  EventCtx local;
  if (!ctx) ctx = &local;
  ctx->type = ev;
  ctx->view = id;
  std::vector<intptr_t> a(args);
  RefPtr<View> hold(this);
  ++busy;
  PushCtx(ctx);
  void* hook = nullptr;
  {
    Guard g(GLock());  // WV_SetOption 可能正在别的线程上改它
    hook = G().callbackHook;
  }
  int r;
  // expected：回调应有的参数个数（默认等于传入的个数）。按 WVE_FLAG_NO_OUT 注册的回调少一个（最后的 int*），但地址照样放在栈上传入的位置，
  // 旧写法多写了这个“参考”参数的回调仍能回填（见 Fire），参数表检查按应有的个数判断
  const int want = expected >= 0 && expected <= (int)a.size() ? expected : (int)a.size();
  if (hook) {  // 回调转发：由它把文本转成调用方的编码后再调用回调（易语言类用它把 UTF-8 转成易语言文本）
    const intptr_t h[5] = {(intptr_t)fn, (intptr_t)ev, (intptr_t)want, (intptr_t)a.data(), (intptr_t)CallbackTextMask(ev)};
    int popped = 0;
    r = SafeCall(hook, h, 5, &popped);
    if (popped != 0 && popped != 5 * 4) ReportCallbackMismatch(id, -1, hook, popped, 5);
  } else {
    int popped = 0;
    r = SafeCall(fn, a.data(), (int)a.size(), &popped);
    // stdcall 回调从栈上弹掉 4×声明的参数个数，与应有的个数不符说明回调子程序的参数表写错了（cdecl 回调不清栈，弹掉 0 字节，不判断）
    if (popped != 0 && popped != 4 * want) ReportCallbackMismatch(id, ev, fn, popped, want, want < (int)a.size());
  }
  PopCtx();
  --busy;
  if (busy == 0 && pendingDestroy) {
    if (host) PostMessageW(host, WM_WV_FINISH_DESTROY, 0, 0);
    else FinishDestroy();
  }
  return r;
}
void View::Post(std::function<void()> fn) {
  if (host && !finished) {
    auto* p = new std::function<void()>(std::move(fn));
    const LPARAM tok = TaskToken(p, true);
    if (PostMessageW(host, WM_WV_TASK, 0, tok)) return;
    TakeTask(tok, true);
    fn = std::move(*p);
    delete p;
  }
  RunTask(fn);
}

// 首次导航：启用 JS 桥时在桥接脚本登记完成后进行，保证首个页面加载时 epl 对象已经存在
void View::NavigateInitial() {
  if (!navPending) return;
  navPending = false;
  if (host) KillTimer(host, 3);
  if (!Ready() || popupTarget) return;
  std::wstring u = !pendingUrl.empty() ? pendingUrl : (!lastUrl.empty() ? lastUrl : initialUrl);
  pendingUrl.clear();
  if (!u.empty()) wv->Navigate(NormalizeUrl(u).c_str());
}

// 有回填参数（最后一个 int* 参数）的事件，以及 WVK_CANCEL 换算成回填值的方式：1 逻辑值，取消（拦截、屏蔽）为 1、不取消为 0
// （将要跳转、下载开始、认证、拦截请求、按键）；2 对话框，取消为 0、确定为 1；3 整数选项，取消（新窗口不打开、权限拒绝、取消访问）为 2，
// 不取消时保持默认处理（新窗口、权限请求、证书错误）；0 没有回填参数
int EvOutKind(int ev) {
  switch (ev) {
    case WVE_NAV_STARTING:
    case WVE_DOWNLOAD_START:
    case WVE_AUTH:
    case WVE_REQUEST:
    case WVE_KEY: return 1;
    case WVE_SCRIPT_DIALOG: return 2;
    case WVE_NEW_WINDOW:
    case WVE_PERMISSION:
    case WVE_CERT_ERROR: return 3;
  }
  return 0;
}
int View::Fire(int ev, std::initializer_list<intptr_t> args, EventCtx* ctx) {
  if (!HasCb(ev)) return 0;
  const int kind = EvOutKind(ev);
  if (!kind || args.size() < 2) return FireFn(cb[ev], ev, args, ctx);
  // 回填参数是最后一个 int*。回调里也可以用 WV_EvSetInt(WVK_CANCEL / WVK_RESULT) 回填，回调返回后生效（两者都设了时以 WVK_RESULT 为准）。
  // 按 WVE_FLAG_NO_OUT 注册的回调（易语言类的事件）应有的参数表不含这个参数：漏写“参考”时参数个数仍然对，保护桩发现不了，赋值却不会生效，
  // 不含这个参数，回调的参数就全是只读的，多写它时参数表检查会指出。它的地址照样放在栈上原来的位置：1.7.0–1.7.7 不放，
  // 旧写法（照旧写了最后的“参考”参数）的回调读到的是清零槽位，赋值悄悄失效，例如在“将要跳转”里把“取消”赋值为真拦不住网页了，
  // 升级后只在调试运行时才看得出来；现在旧写法照样回填，同时按参数表不对报告，提示改成新写法
  EventCtx local;
  if (!ctx) ctx = &local;
  const std::vector<intptr_t> a(args);
  int* const out = reinterpret_cast<int*>(a.back());
  const int r = FireFn(cb[ev], ev, a, ctx, cbNoOut[ev] ? (int)a.size() - 1 : -1);
  if (out) {
    const auto res = ctx->setN.find(WVK_RESULT);
    const auto can = ctx->setN.find(WVK_CANCEL);
    if (res != ctx->setN.end()) {
      *out = res->second;
    } else if (can != ctx->setN.end()) {
      const bool c = can->second != 0;
      if (kind == 1) *out = c ? 1 : 0;
      else if (kind == 2) *out = c ? 0 : 1;
      else if (c) *out = 2;
    }
  }
  return r;
}
void View::SetEvent(int ev, void* fn, bool noOut) {
  if (ev <= 0 || ev > WVE_MAX) return;
  cb[ev] = fn;
  cbNoOut[ev] = fn && noOut ? 1 : 0;
  if (ev == WVE_SCRIPT_DIALOG && settings && !iprops.count(WVP_SCRIPT_DIALOGS))
    settings->put_AreDefaultScriptDialogsEnabled(fn ? FALSE : TRUE);
  if (ev == WVE_RESPONSE && fn) EnsureResponseHook();
  if (ev == WVE_REQUEST && fn) EnsureRequestHook();
  if (ev == WVE_JS_CALL && fn) EnsureBridge();  // 同创建选项：只设这个事件也要有桥对象
}

#define WV_HOLD(vid)              \
  HandlerScope wvScope_;          \
  RefPtr<View> v = FindView(vid); \
  if (!v || v->closing || !v->wv) return S_OK

void View::RegisterEvents() {
  // WebView2 不支持在它的事件处理函数里嵌套消息循环（官方文档“线程模型”的重入说明），处理函数里同步等待只会等到超时。
  // 约定：只通知的事件当场取出数据，投递到宿主窗口后再调用易语言回调；需要回填结果的事件先取 Deferral，
  // 投递后在回调结束时完成。只有“将要跳转”“按键”没有 Deferral，只能同步回调，此时等待类方法立即返回 WVERR_REENTRANT。
  const int vid = id;
  EventRegistrationToken tk;
  wv->add_NavigationStarting(
      Callback<ICoreWebView2NavigationStartingEventHandler, ICoreWebView2*, ICoreWebView2NavigationStartingEventArgs*>(
          [vid](ICoreWebView2*, ICoreWebView2NavigationStartingEventArgs* a) -> HRESULT {
            WV_HOLD(vid);
            v->loading = true;
            if (!v->HasCb(WVE_NAV_STARTING)) return S_OK;
            CoStr u;
            a->get_Uri(u.put());
            BOOL user = FALSE, redir = FALSE;
            a->get_IsUserInitiated(&user);
            a->get_IsRedirected(&redir);
            std::string su = ToCP(u.str());
            int cancel = 0;
            v->Fire(WVE_NAV_STARTING, {(intptr_t)vid, (intptr_t)su.c_str(), user ? 1 : 0, redir ? 1 : 0, (intptr_t)&cancel});
            if (cancel) a->put_Cancel(TRUE);
            return S_OK;
          })
          .get(),
      &tk);
  wv->add_NavigationCompleted(
      Callback<ICoreWebView2NavigationCompletedEventHandler, ICoreWebView2*, ICoreWebView2NavigationCompletedEventArgs*>(
          [vid](ICoreWebView2*, ICoreWebView2NavigationCompletedEventArgs* a) -> HRESULT {
            WV_HOLD(vid);
            v->loading = false;
            if (!v->HasCb(WVE_NAV_COMPLETED)) return S_OK;
            BOOL ok = FALSE;
            a->get_IsSuccess(&ok);
            COREWEBVIEW2_WEB_ERROR_STATUS es = COREWEBVIEW2_WEB_ERROR_STATUS_UNKNOWN;
            a->get_WebErrorStatus(&es);
            int status = 0;
            ComPtr<ICoreWebView2NavigationCompletedEventArgs2> a2 =
                ComPtr<ICoreWebView2NavigationCompletedEventArgs>::From(a).as<ICoreWebView2NavigationCompletedEventArgs2>();
            if (a2) a2->get_HttpStatusCode(&status);
            CoStr u;
            v->wv->get_Source(u.put());
            std::wstring src = u.str();
            int okI = ok ? 1 : 0, err = ok ? 0 : (int)es;
            v->Post([vid, src, okI, status, err] {
              WV_TASK(vid);
              std::string su = ToCP(src);
              v->Fire(WVE_NAV_COMPLETED, {(intptr_t)vid, (intptr_t)su.c_str(), okI, status, err});
            });
            return S_OK;
          })
          .get(),
      &tk);
  wv->add_SourceChanged(Callback<ICoreWebView2SourceChangedEventHandler, ICoreWebView2*, ICoreWebView2SourceChangedEventArgs*>(
                            [vid](ICoreWebView2*, ICoreWebView2SourceChangedEventArgs* a) -> HRESULT {
                              WV_HOLD(vid);
                              BOOL newDoc = TRUE;  // 取不到时按新文档算：宁可丢掉旧调用的结果，也不交给可能来自别处的网页
                              if (a) a->get_IsNewDocument(&newDoc);
                              if (newDoc) ++v->docGen;
                              CoStr u;
                              v->wv->get_Source(u.put());
                              v->lastUrl = u.str();
                              if (!v->HasCb(WVE_SOURCE_CHANGED)) return S_OK;
                              std::wstring src = v->lastUrl;
                              v->Post([vid, src] {
                                WV_TASK(vid);
                                std::string su = ToCP(src);
                                v->Fire(WVE_SOURCE_CHANGED, {(intptr_t)vid, (intptr_t)su.c_str()});
                              });
                              return S_OK;
                            }).get(),
                        &tk);
  wv->add_DocumentTitleChanged(Callback<ICoreWebView2DocumentTitleChangedEventHandler, ICoreWebView2*, IUnknown*>(
                                   [vid](ICoreWebView2*, IUnknown*) -> HRESULT {
                                     WV_HOLD(vid);
                                     if (!v->HasCb(WVE_TITLE_CHANGED)) return S_OK;
                                     CoStr t;
                                     v->wv->get_DocumentTitle(t.put());
                                     std::wstring title = t.str();
                                     v->Post([vid, title] {
                                       WV_TASK(vid);
                                       std::string st = ToCP(title);
                                       v->Fire(WVE_TITLE_CHANGED, {(intptr_t)vid, (intptr_t)st.c_str()});
                                     });
                                     return S_OK;
                                   }).get(),
                               &tk);
  wv->add_HistoryChanged(Callback<ICoreWebView2HistoryChangedEventHandler, ICoreWebView2*, IUnknown*>(
                             [vid](ICoreWebView2*, IUnknown*) -> HRESULT {
                               WV_HOLD(vid);
                               if (!v->HasCb(WVE_HISTORY)) return S_OK;
                               BOOL b = FALSE, f = FALSE;
                               v->wv->get_CanGoBack(&b);
                               v->wv->get_CanGoForward(&f);
                               int bi = b ? 1 : 0, fi = f ? 1 : 0;
                               v->Post([vid, bi, fi] {
                                 WV_TASK(vid);
                                 v->Fire(WVE_HISTORY, {(intptr_t)vid, bi, fi});
                               });
                               return S_OK;
                             }).get(),
                         &tk);
  wv->add_WebMessageReceived(Callback<ICoreWebView2WebMessageReceivedEventHandler, ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs*>(
                                 [vid](ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs* a) -> HRESULT {
                                   WV_HOLD(vid);
                                   return v->OnWebMessage(a);
                                 }).get(),
                             &tk);
  wv->add_NewWindowRequested(Callback<ICoreWebView2NewWindowRequestedEventHandler, ICoreWebView2*, ICoreWebView2NewWindowRequestedEventArgs*>(
                                 [vid](ICoreWebView2*, ICoreWebView2NewWindowRequestedEventArgs* a) -> HRESULT {
                                   WV_HOLD(vid);
                                   return v->OnNewWindow(a);
                                 }).get(),
                             &tk);
  wv->add_PermissionRequested(
      Callback<ICoreWebView2PermissionRequestedEventHandler, ICoreWebView2*, ICoreWebView2PermissionRequestedEventArgs*>(
          [vid](ICoreWebView2*, ICoreWebView2PermissionRequestedEventArgs* a) -> HRESULT {
            WV_HOLD(vid);
            if (!v->HasCb(WVE_PERMISSION)) {
              if (v->permPolicy == 1) a->put_State(COREWEBVIEW2_PERMISSION_STATE_ALLOW);
              else if (v->permPolicy == 2) a->put_State(COREWEBVIEW2_PERMISSION_STATE_DENY);
              return S_OK;
            }
            CoStr u;
            a->get_Uri(u.put());
            COREWEBVIEW2_PERMISSION_KIND kind = COREWEBVIEW2_PERMISSION_KIND_UNKNOWN_PERMISSION;
            a->get_PermissionKind(&kind);
            std::wstring url = u.str();
            int k = (int)kind;
            ComPtr<ICoreWebView2Deferral> def;
            a->GetDeferral(def.put());
            ComPtr<ICoreWebView2PermissionRequestedEventArgs> args = ComPtr<ICoreWebView2PermissionRequestedEventArgs>::From(a);
            v->Post([vid, args, def, url, k] {
              RefPtr<View> v = FindView(vid);
              int st = 0;
              if (v && !v->closing) {
                std::string su = ToCP(url);
                v->Fire(WVE_PERMISSION, {(intptr_t)vid, (intptr_t)su.c_str(), k, (intptr_t)&st});
                if (st == 0) st = v->permPolicy;
              }
              if (st == 1) args->put_State(COREWEBVIEW2_PERMISSION_STATE_ALLOW);
              else if (st == 2) args->put_State(COREWEBVIEW2_PERMISSION_STATE_DENY);
              if (def) def->Complete();
            });
            return S_OK;
          })
          .get(),
      &tk);
  wv->add_ProcessFailed(Callback<ICoreWebView2ProcessFailedEventHandler, ICoreWebView2*, ICoreWebView2ProcessFailedEventArgs*>(
                            [vid](ICoreWebView2*, ICoreWebView2ProcessFailedEventArgs* a) -> HRESULT {
                              WV_HOLD(vid);
                              COREWEBVIEW2_PROCESS_FAILED_KIND kind = COREWEBVIEW2_PROCESS_FAILED_KIND_BROWSER_PROCESS_EXITED;
                              a->get_ProcessFailedKind(&kind);
                              int reason = 0;
                              ComPtr<ICoreWebView2ProcessFailedEventArgs2> a2 =
                                  ComPtr<ICoreWebView2ProcessFailedEventArgs>::From(a).as<ICoreWebView2ProcessFailedEventArgs2>();
                              if (a2) {
                                COREWEBVIEW2_PROCESS_FAILED_REASON r = COREWEBVIEW2_PROCESS_FAILED_REASON_UNEXPECTED;
                                a2->get_Reason(&r);
                                reason = (int)r;
                              }
                              Log(L"浏览器 #%d 进程异常：类型 %d 原因 %d", vid, (int)kind, reason);
                              int k = (int)kind;
                              v->Post([vid, k, reason] {
                                WV_TASK(vid);
                                v->Fire(WVE_PROCESS_FAILED, {(intptr_t)vid, k, reason});
                              });
                              // 自动恢复有上限（AllowRecover）：一打开就让内核崩溃的网页、出问题的显卡驱动不会造成“崩溃—恢复”的无限循环
                              if (kind == COREWEBVIEW2_PROCESS_FAILED_KIND_BROWSER_PROCESS_EXITED) {
                                if (v->recoverMode && v->host && v->AllowRecover()) PostMessageW(v->host, WM_WV_RECREATE, 0, 0);
                                else {
                                  v->errMsg = v->recoverMode ? L"浏览器进程在短时间内多次退出，已停止自动恢复" : L"浏览器进程已退出";
                                  if (v->FallbackEnabled()) v->SetPanel(4);  // 关闭了提示卡片：交给程序处理“进程崩溃”事件
                                }
                              } else if (v->recoverMode && (kind == COREWEBVIEW2_PROCESS_FAILED_KIND_RENDER_PROCESS_EXITED ||
                                                            kind == COREWEBVIEW2_PROCESS_FAILED_KIND_RENDER_PROCESS_UNRESPONSIVE)) {
                                if (v->AllowRecover()) v->wv->Reload();
                                else Log(L"浏览器 #%d 的网页进程在短时间内多次崩溃或无响应，已停止自动刷新", vid);
                              }
                              return S_OK;
                            }).get(),
                        &tk);
  wv->add_ContainsFullScreenElementChanged(Callback<ICoreWebView2ContainsFullScreenElementChangedEventHandler, ICoreWebView2*, IUnknown*>(
                                               [vid](ICoreWebView2*, IUnknown*) -> HRESULT {
                                                 WV_HOLD(vid);
                                                 BOOL full = FALSE;
                                                 v->wv->get_ContainsFullScreenElement(&full);
                                                 if (v->fullscreenMode == 1) {
                                                   if (full) v->EnterFullscreen();
                                                   else v->ExitFullscreen();
                                                 }
                                                 int fi = full ? 1 : 0;
                                                 v->Post([vid, fi] {
                                                   WV_TASK(vid);
                                                   v->Fire(WVE_FULLSCREEN, {(intptr_t)vid, fi});
                                                 });
                                                 return S_OK;
                                               }).get(),
                                           &tk);
  wv->add_WindowCloseRequested(Callback<ICoreWebView2WindowCloseRequestedEventHandler, ICoreWebView2*, IUnknown*>(
                                   [vid](ICoreWebView2*, IUnknown*) -> HRESULT {
                                     WV_HOLD(vid);
                                     v->Post([vid] {
                                       WV_TASK(vid);
                                       v->Fire(WVE_CLOSE_REQUESTED, {(intptr_t)vid});
                                     });
                                     return S_OK;
                                   }).get(),
                               &tk);
  wv->add_ScriptDialogOpening(
      Callback<ICoreWebView2ScriptDialogOpeningEventHandler, ICoreWebView2*, ICoreWebView2ScriptDialogOpeningEventArgs*>(
          [vid](ICoreWebView2*, ICoreWebView2ScriptDialogOpeningEventArgs* a) -> HRESULT {
            WV_HOLD(vid);
            COREWEBVIEW2_SCRIPT_DIALOG_KIND kind = COREWEBVIEW2_SCRIPT_DIALOG_KIND_ALERT;
            a->get_Kind(&kind);
            CoStr msg, dflt, u;
            a->get_Message(msg.put());
            a->get_DefaultText(dflt.put());
            a->get_Uri(u.put());
            std::wstring m = msg.str(), d = dflt.str(), url = u.str();
            int k = (int)kind;
            if (!v->HasCb(WVE_SCRIPT_DIALOG)) {  // 默认对话框已关闭又没有回调：直接确认
              if (kind == COREWEBVIEW2_SCRIPT_DIALOG_KIND_PROMPT) a->put_ResultText(d.c_str());
              a->Accept();
              return S_OK;
            }
            ComPtr<ICoreWebView2Deferral> def;
            a->GetDeferral(def.put());
            ComPtr<ICoreWebView2ScriptDialogOpeningEventArgs> args = ComPtr<ICoreWebView2ScriptDialogOpeningEventArgs>::From(a);
            v->Post([vid, args, def, m, d, url, k] {
              RefPtr<View> v = FindView(vid);
              int accept = 1;
              EventCtx ctx;
              ctx.s[WVK_DEFAULT_TEXT] = d;
              ctx.s[WVK_URL] = url;
              if (v && !v->closing) {
                std::string sm = ToCP(m), su = ToCP(url);
                v->Fire(WVE_SCRIPT_DIALOG, {(intptr_t)vid, k, (intptr_t)sm.c_str(), (intptr_t)su.c_str(), (intptr_t)&accept}, &ctx);
              }
              if (accept) {
                if (k == (int)COREWEBVIEW2_SCRIPT_DIALOG_KIND_PROMPT) {
                  auto it = ctx.setS.find(WVK_SET_TEXT);
                  args->put_ResultText(it != ctx.setS.end() ? it->second.c_str() : d.c_str());
                }
                args->Accept();
              }
              if (def) def->Complete();
            });
            return S_OK;
          })
          .get(),
      &tk);

  ComPtr<ICoreWebView2_2> w2 = wv.as<ICoreWebView2_2>();
  if (w2) {
    w2->add_DOMContentLoaded(Callback<ICoreWebView2DOMContentLoadedEventHandler, ICoreWebView2*, ICoreWebView2DOMContentLoadedEventArgs*>(
                                 [vid](ICoreWebView2*, ICoreWebView2DOMContentLoadedEventArgs*) -> HRESULT {
                                   WV_HOLD(vid);
                                   if (!v->HasCb(WVE_DOM_READY)) return S_OK;
                                   CoStr u;
                                   v->wv->get_Source(u.put());
                                   std::wstring src = u.str();
                                   v->Post([vid, src] {
                                     WV_TASK(vid);
                                     std::string su = ToCP(src);
                                     v->Fire(WVE_DOM_READY, {(intptr_t)vid, (intptr_t)su.c_str()});
                                   });
                                   return S_OK;
                                 }).get(),
                             &tk);
  }
  ComPtr<ICoreWebView2_4> w4 = wv.as<ICoreWebView2_4>();
  if (w4) {
    w4->add_DownloadStarting(Callback<ICoreWebView2DownloadStartingEventHandler, ICoreWebView2*, ICoreWebView2DownloadStartingEventArgs*>(
                                 [vid](ICoreWebView2*, ICoreWebView2DownloadStartingEventArgs* a) -> HRESULT {
                                   WV_HOLD(vid);
                                   return v->OnDownloadStarting(a);
                                 }).get(),
                             &tk);
  }
  ComPtr<ICoreWebView2_8> w8 = wv.as<ICoreWebView2_8>();
  if (w8) {
    auto audio = [vid](ICoreWebView2*, IUnknown*) -> HRESULT {
      WV_HOLD(vid);
      if (!v->HasCb(WVE_AUDIO)) return S_OK;
      ComPtr<ICoreWebView2_8> x = v->wv.as<ICoreWebView2_8>();
      BOOL playing = FALSE, muted = FALSE;
      if (x) {
        x->get_IsDocumentPlayingAudio(&playing);
        x->get_IsMuted(&muted);
      }
      int p = playing ? 1 : 0, mu = muted ? 1 : 0;
      v->Post([vid, p, mu] {
        WV_TASK(vid);
        v->Fire(WVE_AUDIO, {(intptr_t)vid, p, mu});
      });
      return S_OK;
    };
    w8->add_IsDocumentPlayingAudioChanged(Callback<ICoreWebView2IsDocumentPlayingAudioChangedEventHandler, ICoreWebView2*, IUnknown*>(audio).get(), &tk);
    w8->add_IsMutedChanged(Callback<ICoreWebView2IsMutedChangedEventHandler, ICoreWebView2*, IUnknown*>(audio).get(), &tk);
  }
  ComPtr<ICoreWebView2_10> w10 = wv.as<ICoreWebView2_10>();
  if (w10) {
    w10->add_BasicAuthenticationRequested(
        Callback<ICoreWebView2BasicAuthenticationRequestedEventHandler, ICoreWebView2*, ICoreWebView2BasicAuthenticationRequestedEventArgs*>(
            [vid](ICoreWebView2*, ICoreWebView2BasicAuthenticationRequestedEventArgs* a) -> HRESULT {
              WV_HOLD(vid);
              if (!v->HasCb(WVE_AUTH)) return S_OK;
              CoStr u, ch;
              a->get_Uri(u.put());
              a->get_Challenge(ch.put());
              std::wstring url = u.str(), chal = ch.str();
              ComPtr<ICoreWebView2Deferral> def;
              a->GetDeferral(def.put());
              ComPtr<ICoreWebView2BasicAuthenticationRequestedEventArgs> args =
                  ComPtr<ICoreWebView2BasicAuthenticationRequestedEventArgs>::From(a);
              v->Post([vid, args, def, url, chal] {
                RefPtr<View> v = FindView(vid);
                if (v && !v->closing) {
                  EventCtx ctx;
                  ctx.s[WVK_URL] = url;
                  ctx.s[WVK_CHALLENGE] = chal;
                  int cancel = 0;
                  std::string su = ToCP(url), sc = ToCP(chal);
                  v->Fire(WVE_AUTH, {(intptr_t)vid, (intptr_t)su.c_str(), (intptr_t)sc.c_str(), (intptr_t)&cancel}, &ctx);
                  if (cancel) {
                    args->put_Cancel(TRUE);
                  } else {
                    auto un = ctx.setS.find(WVK_SET_USERNAME);
                    auto pw = ctx.setS.find(WVK_SET_PASSWORD);
                    if (un != ctx.setS.end()) {
                      ComPtr<ICoreWebView2BasicAuthenticationResponse> r;
                      args->get_Response(r.put());
                      if (r) {
                        r->put_UserName(un->second.c_str());
                        r->put_Password(pw != ctx.setS.end() ? pw->second.c_str() : L"");
                      }
                    }
                  }
                }
                if (def) def->Complete();
              });
              return S_OK;
            })
            .get(),
        &tk);
  }
  ComPtr<ICoreWebView2_11> w11 = wv.as<ICoreWebView2_11>();
  if (w11) {
    w11->add_ContextMenuRequested(Callback<ICoreWebView2ContextMenuRequestedEventHandler, ICoreWebView2*, ICoreWebView2ContextMenuRequestedEventArgs*>(
                                      [vid](ICoreWebView2*, ICoreWebView2ContextMenuRequestedEventArgs* a) -> HRESULT {
                                        WV_HOLD(vid);
                                        return v->OnContextMenu(a);
                                      }).get(),
                                  &tk);
  }
  ComPtr<ICoreWebView2_12> w12 = wv.as<ICoreWebView2_12>();
  if (w12) {
    w12->add_StatusBarTextChanged(Callback<ICoreWebView2StatusBarTextChangedEventHandler, ICoreWebView2*, IUnknown*>(
                                      [vid](ICoreWebView2*, IUnknown*) -> HRESULT {
                                        WV_HOLD(vid);
                                        if (!v->HasCb(WVE_STATUS_TEXT)) return S_OK;
                                        ComPtr<ICoreWebView2_12> x = v->wv.as<ICoreWebView2_12>();
                                        CoStr t;
                                        if (x) x->get_StatusBarText(t.put());
                                        std::wstring text = t.str();
                                        v->Post([vid, text] {
                                          WV_TASK(vid);
                                          std::string st = ToCP(text);
                                          v->Fire(WVE_STATUS_TEXT, {(intptr_t)vid, (intptr_t)st.c_str()});
                                        });
                                        return S_OK;
                                      }).get(),
                                  &tk);
  }
  ComPtr<ICoreWebView2_14> w14 = wv.as<ICoreWebView2_14>();
  if (w14) {
    w14->add_ServerCertificateErrorDetected(
        Callback<ICoreWebView2ServerCertificateErrorDetectedEventHandler, ICoreWebView2*, ICoreWebView2ServerCertificateErrorDetectedEventArgs*>(
            [vid](ICoreWebView2*, ICoreWebView2ServerCertificateErrorDetectedEventArgs* a) -> HRESULT {
              WV_HOLD(vid);
              if (!v->HasCb(WVE_CERT_ERROR)) {
                if (v->ignoreCert) a->put_Action(COREWEBVIEW2_SERVER_CERTIFICATE_ERROR_ACTION_ALWAYS_ALLOW);
                return S_OK;
              }
              CoStr u;
              a->get_RequestUri(u.put());
              COREWEBVIEW2_WEB_ERROR_STATUS es = COREWEBVIEW2_WEB_ERROR_STATUS_UNKNOWN;
              a->get_ErrorStatus(&es);
              std::wstring url = u.str();
              int e = (int)es;
              ComPtr<ICoreWebView2Deferral> def;
              a->GetDeferral(def.put());
              ComPtr<ICoreWebView2ServerCertificateErrorDetectedEventArgs> args =
                  ComPtr<ICoreWebView2ServerCertificateErrorDetectedEventArgs>::From(a);
              v->Post([vid, args, def, url, e] {
                RefPtr<View> v = FindView(vid);
                int act = 0;
                if (v && !v->closing) {
                  act = v->ignoreCert ? 1 : 0;
                  int user = 0;
                  std::string su = ToCP(url);
                  v->Fire(WVE_CERT_ERROR, {(intptr_t)vid, (intptr_t)su.c_str(), e, (intptr_t)&user});
                  if (user) act = user;
                }
                if (act == 1) args->put_Action(COREWEBVIEW2_SERVER_CERTIFICATE_ERROR_ACTION_ALWAYS_ALLOW);
                else if (act == 2) args->put_Action(COREWEBVIEW2_SERVER_CERTIFICATE_ERROR_ACTION_CANCEL);
                if (def) def->Complete();
              });
              return S_OK;
            })
            .get(),
        &tk);
  }
  ComPtr<ICoreWebView2_15> w15 = wv.as<ICoreWebView2_15>();
  if (w15) {
    w15->add_FaviconChanged(Callback<ICoreWebView2FaviconChangedEventHandler, ICoreWebView2*, IUnknown*>(
                                [vid](ICoreWebView2*, IUnknown*) -> HRESULT {
                                  WV_HOLD(vid);
                                  if (!v->HasCb(WVE_FAVICON)) return S_OK;
                                  ComPtr<ICoreWebView2_15> x = v->wv.as<ICoreWebView2_15>();
                                  CoStr u;
                                  if (x) x->get_FaviconUri(u.put());
                                  std::wstring fu = u.str();
                                  v->Post([vid, fu] {
                                    WV_TASK(vid);
                                    std::string su = ToCP(fu);
                                    v->Fire(WVE_FAVICON, {(intptr_t)vid, (intptr_t)su.c_str()});
                                  });
                                  return S_OK;
                                }).get(),
                            &tk);
  }
  ctl->add_AcceleratorKeyPressed(Callback<ICoreWebView2AcceleratorKeyPressedEventHandler, ICoreWebView2Controller*, ICoreWebView2AcceleratorKeyPressedEventArgs*>(
                                     [vid](ICoreWebView2Controller*, ICoreWebView2AcceleratorKeyPressedEventArgs* a) -> HRESULT {
                                       WV_HOLD(vid);
                                       return v->OnKey(a);
                                     }).get(),
                                 &tk);
  // 在网页最后（或第一个）可聚焦元素上按 Tab 时，把焦点交给窗口里的下一个（上一个）控件；
  // 不处理的话焦点只在网页内部循环，用键盘无法离开浏览器。窗口里没有别的可停留控件时不处理
  ctl->add_MoveFocusRequested(Callback<ICoreWebView2MoveFocusRequestedEventHandler, ICoreWebView2Controller*, ICoreWebView2MoveFocusRequestedEventArgs*>(
                                  [vid](ICoreWebView2Controller*, ICoreWebView2MoveFocusRequestedEventArgs* a) -> HRESULT {
                                    WV_HOLD(vid);
                                    COREWEBVIEW2_MOVE_FOCUS_REASON r = COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC;
                                    if (FAILED(a->get_Reason(&r)) || r == COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC || !v->host) return S_OK;
                                    HWND root = GetAncestor(v->host, GA_ROOT), cur = v->host, next = nullptr;
                                    // 宿主带 WS_EX_CONTROLPARENT，查找可能进入宿主内部（WebView2 自己的窗口），跳过它们继续找
                                    for (int i = 0; root && i < 256; ++i) {
                                      HWND n = GetNextDlgTabItem(root, cur, r == COREWEBVIEW2_MOVE_FOCUS_REASON_PREVIOUS);
                                      if (!n || n == v->host || n == cur) break;
                                      if (!IsChild(v->host, n)) {
                                        next = n;
                                        break;
                                      }
                                      cur = n;
                                    }
                                    if (next) {
                                      SetFocus(next);
                                      a->put_Handled(TRUE);
                                    }
                                    return S_OK;
                                  }).get(),
                              &tk);
  ctl->add_ZoomFactorChanged(Callback<ICoreWebView2ZoomFactorChangedEventHandler, ICoreWebView2Controller*, IUnknown*>(
                                 [vid](ICoreWebView2Controller*, IUnknown*) -> HRESULT {
                                   WV_HOLD(vid);
                                   if (!v->HasCb(WVE_ZOOM)) return S_OK;
                                   double z = 1.0;
                                   v->ctl->get_ZoomFactor(&z);
                                   int pct = (int)(z * 100.0 + 0.5);
                                   v->Post([vid, pct] {
                                     WV_TASK(vid);
                                     v->Fire(WVE_ZOOM, {(intptr_t)vid, pct});
                                   });
                                   return S_OK;
                                 }).get(),
                             &tk);
}

// ---------------------------------------------------------------- 属性
static bool IsReadOnly(int p) {
  return p == WVP_PLAYING_AUDIO || p == WVP_CAN_BACK || p == WVP_CAN_FORWARD || p == WVP_LOADING || p == WVP_IS_FULLSCREEN || p == WVP_STATE ||
         p == WVP_PROCESS_ID || p == WVP_SUSPENDED || p == WVP_DOWNLOAD_DIALOG_OPEN || p == WVS_URL || p == WVS_TITLE || p == WVS_STATUS_TEXT ||
         p == WVS_FAVICON_URL || p == WVS_USER_DATA_DIR || p == WVS_BROWSER_VERSION || p == WVS_PROFILE_PATH || p == WVS_PROFILE_NAME ||
         p == WVS_LAST_ERROR || p == WVS_RUNTIME_DIR;
}

bool View::SetIntProp(int p, int val) {
  if (IsReadOnly(p)) {
    SetErr(WVERR_ARG, L"该属性只读");
    return false;
  }
  iprops[p] = val;
  switch (p) {
    case WVP_NEW_WINDOW: newWindowMode = val; return true;
    case WVP_PERMISSION: permPolicy = val; return true;
    case WVP_FULLSCREEN: fullscreenMode = val; if (!val && isFull) ExitFullscreen(); return true;
    case WVP_AUTO_RECOVER: recoverMode = val; return true;
    case WVP_IGNORE_CERT: ignoreCert = val != 0; return true;
    case WVP_SILENT_DOWNLOAD: silentDownload = val != 0; return true;
    case WVP_BLOCK_IMAGES: blockImages = val != 0; if (Ready() && (blockImages || reqHooked)) EnsureRequestHook(); return true;
    case WVP_BRIDGE: if (val) EnsureBridge(); else DisableBridge(); return true;
    case WVP_VISIBLE: SetVisible(val != 0); return true;
    case WVP_CONTEXT_MENU: ctxMenuMode = val; break;
    case WVP_BG_COLOR: if (host) InvalidateRect(host, nullptr, FALSE); break;
  }
  if (!Ready()) return true;  // 就绪后统一应用
  return ApplyInt(p, val);
}

bool View::ApplyInt(int p, int val) {
  if (!Ready()) return false;
  HRESULT hr = S_OK;
  BOOL b = val ? TRUE : FALSE;
  auto s2 = settings.as<ICoreWebView2Settings2>();
  switch (p) {
    case WVP_DEVTOOLS: hr = settings->put_AreDevToolsEnabled(b); break;
    case WVP_CONTEXT_MENU: hr = settings->put_AreDefaultContextMenusEnabled(val == 1 ? FALSE : TRUE); break;
    case WVP_SCRIPT: hr = settings->put_IsScriptEnabled(b); break;
    case WVP_WEB_MESSAGE: hr = settings->put_IsWebMessageEnabled(b); break;
    case WVP_SCRIPT_DIALOGS: hr = settings->put_AreDefaultScriptDialogsEnabled(b); break;
    case WVP_STATUS_BAR: hr = settings->put_IsStatusBarEnabled(b); break;
    case WVP_ZOOM_CONTROL: hr = settings->put_IsZoomControlEnabled(b); break;
    case WVP_HOST_OBJECTS: hr = settings->put_AreHostObjectsAllowed(b); break;
    case WVP_ERROR_PAGE: hr = settings->put_IsBuiltInErrorPageEnabled(b); break;
    case WVP_ACCELERATOR_KEYS: { auto s = settings.as<ICoreWebView2Settings3>(); hr = s ? s->put_AreBrowserAcceleratorKeysEnabled(b) : E_NOINTERFACE; break; }
    case WVP_PASSWORD_AUTOSAVE: { auto s = settings.as<ICoreWebView2Settings4>(); hr = s ? s->put_IsPasswordAutosaveEnabled(b) : E_NOINTERFACE; break; }
    case WVP_AUTOFILL: { auto s = settings.as<ICoreWebView2Settings4>(); hr = s ? s->put_IsGeneralAutofillEnabled(b) : E_NOINTERFACE; break; }
    case WVP_PINCH_ZOOM: { auto s = settings.as<ICoreWebView2Settings5>(); hr = s ? s->put_IsPinchZoomEnabled(b) : E_NOINTERFACE; break; }
    case WVP_SWIPE_NAV: { auto s = settings.as<ICoreWebView2Settings6>(); hr = s ? s->put_IsSwipeNavigationEnabled(b) : E_NOINTERFACE; break; }
    case WVP_PDF_TOOLBAR_HIDE: { auto s = settings.as<ICoreWebView2Settings7>(); hr = s ? s->put_HiddenPdfToolbarItems((COREWEBVIEW2_PDF_TOOLBAR_ITEMS)val) : E_NOINTERFACE; break; }
    case WVP_SMARTSCREEN: { auto s = settings.as<ICoreWebView2Settings8>(); hr = s ? s->put_IsReputationCheckingRequired(b) : E_NOINTERFACE; break; }
    case WVP_ZOOM: hr = ctl->put_ZoomFactor(std::max(25, std::min(500, val)) / 100.0); break;
    case WVP_MUTED: { auto w = wv.as<ICoreWebView2_8>(); hr = w ? w->put_IsMuted(b) : E_NOINTERFACE; break; }
    case WVP_BG_COLOR: {
      auto c2 = ctl.as<ICoreWebView2Controller2>();
      COREWEBVIEW2_COLOR c;
      unsigned u = (unsigned)val;
      c.A = (BYTE)((u >> 24) == 0 ? 0 : 255);
      c.R = (BYTE)((u >> 16) & 0xFF);
      c.G = (BYTE)((u >> 8) & 0xFF);
      c.B = (BYTE)(u & 0xFF);
      hr = c2 ? c2->put_DefaultBackgroundColor(c) : E_NOINTERFACE;
      break;
    }
    case WVP_COLOR_SCHEME: {
      auto w13 = wv.as<ICoreWebView2_13>();
      ComPtr<ICoreWebView2Profile> prof;
      if (w13) w13->get_Profile(prof.put());
      hr = prof ? prof->put_PreferredColorScheme((COREWEBVIEW2_PREFERRED_COLOR_SCHEME)val) : E_NOINTERFACE;
      break;
    }
    case WVP_EXTERNAL_DROP: { auto c4 = ctl.as<ICoreWebView2Controller4>(); hr = c4 ? c4->put_AllowExternalDrop(b) : E_NOINTERFACE; break; }
    case WVP_NONCLIENT_REGION: { auto s9 = settings.as<ICoreWebView2Settings9>(); hr = s9 ? s9->put_IsNonClientRegionSupportEnabled(b) : E_NOINTERFACE; break; }
    default: break;
  }
  (void)s2;
  if (hr == E_NOINTERFACE) {
    SetErr(WVERR_UNSUPPORTED, L"当前内核版本不支持该设置（已记录，升级内核后自动生效）", hr);
    return false;
  }
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"设置失败：" + HrText(hr), hr);
    return false;
  }
  return true;
}

int View::GetIntProp(int p) {
  auto stored = [&](int def) {
    auto it = iprops.find(p);
    return it == iprops.end() ? def : it->second;
  };
  switch (p) {
    case WVP_STATE: return state;
    case WVP_LOADING: return loading ? 1 : 0;
    case WVP_IS_FULLSCREEN: return isFull ? 1 : 0;
    case WVP_VISIBLE: return visible ? 1 : 0;
    case WVP_NEW_WINDOW: return newWindowMode;
    case WVP_PERMISSION: return permPolicy;
    case WVP_FULLSCREEN: return fullscreenMode;
    case WVP_AUTO_RECOVER: return recoverMode;
    case WVP_BRIDGE: return bridgeOn ? 1 : 0;
    case WVP_CONTEXT_MENU: return ctxMenuMode;
  }
  if (!Ready()) return stored(0);
  BOOL b = FALSE;
  switch (p) {
    case WVP_CAN_BACK: wv->get_CanGoBack(&b); return b ? 1 : 0;
    case WVP_CAN_FORWARD: wv->get_CanGoForward(&b); return b ? 1 : 0;
    case WVP_ZOOM: { double z = 1.0; ctl->get_ZoomFactor(&z); return (int)(z * 100.0 + 0.5); }
    case WVP_MUTED: { auto w = wv.as<ICoreWebView2_8>(); if (w) w->get_IsMuted(&b); return b ? 1 : 0; }
    case WVP_PLAYING_AUDIO: { auto w = wv.as<ICoreWebView2_8>(); if (w) w->get_IsDocumentPlayingAudio(&b); return b ? 1 : 0; }
    case WVP_PROCESS_ID: { UINT32 pid = 0; wv->get_BrowserProcessId(&pid); return (int)pid; }
    case WVP_SUSPENDED: { auto w = wv.as<ICoreWebView2_3>(); if (w) w->get_IsSuspended(&b); return b ? 1 : 0; }
    case WVP_DOWNLOAD_DIALOG_OPEN: { auto w = wv.as<ICoreWebView2_9>(); if (w) w->get_IsDefaultDownloadDialogOpen(&b); return b ? 1 : 0; }
    case WVP_DEVTOOLS: settings->get_AreDevToolsEnabled(&b); return b ? 1 : 0;
    case WVP_SCRIPT: settings->get_IsScriptEnabled(&b); return b ? 1 : 0;
    case WVP_WEB_MESSAGE: settings->get_IsWebMessageEnabled(&b); return b ? 1 : 0;
    case WVP_SCRIPT_DIALOGS: settings->get_AreDefaultScriptDialogsEnabled(&b); return b ? 1 : 0;
    case WVP_STATUS_BAR: settings->get_IsStatusBarEnabled(&b); return b ? 1 : 0;
    case WVP_ZOOM_CONTROL: settings->get_IsZoomControlEnabled(&b); return b ? 1 : 0;
    case WVP_NONCLIENT_REGION: { auto s9 = settings.as<ICoreWebView2Settings9>(); if (!s9) return stored(0); s9->get_IsNonClientRegionSupportEnabled(&b); return b ? 1 : 0; }
  }
  return stored(0);
}

// 文本属性按创建选项的写法规整：删掉回车、换行换成空格、去掉首尾空白。易语言类在创建前把设置记成一行“键=值”的创建选项
// （同样删回车、换行换空格，DLL 解析时去首尾空白），创建后经 WV_SetStr 原样送来；两条路按同一规则处理，同一个设置在创建前后结果相同。
// 可写的文本属性（UA、下载目录、桥接名称、白名单、屏蔽列表）都是单行内容，首尾空白没有意义
static std::wstring PropText(const std::wstring& s) {
  std::wstring o;
  o.reserve(s.size());
  for (wchar_t c : s) {
    if (c == L'\r') continue;
    o += c == L'\n' ? L' ' : c;
  }
  return Trim(o);
}

bool View::SetStrProp(int p, const std::wstring& raw) {
  if (IsReadOnly(p)) {
    SetErr(WVERR_ARG, L"该属性只读");
    return false;
  }
  const std::wstring val = PropText(raw);
  sprops[p] = val;
  switch (p) {
    case WVS_DOWNLOAD_DIR: downloadDir = AppPath(val); return true;
    case WVS_BRIDGE_NAME: {
      std::wstring n = Trim(val).empty() ? L"epl" : Trim(val);
      if (n != bridgeName) {
        bridgeName = n;
        if (bridgeOn && Ready()) InjectBridge();
      }
      return true;
    }
    case WVS_BRIDGE_ORIGINS: bridgeOrigins = Split(val, L";, \t"); return true;  // 网址里不会有空白：多行文本（换行已换成空格）每行一项也能用
    case WVS_BLOCK_URLS: blockUrls = Split(val, L"; \t"); if (Ready() && !blockUrls.empty()) EnsureRequestHook(); return true;  // 同上，也可以每行一项
    case WVS_BLOCK_KEYS: {
      blockKeys.clear();
      // 逗号、空格或换行分隔（换行已换成空格），每行一项也能用；加号两边的空格不算分隔：“Ctrl + P” 与 “Ctrl+P” 相同
      std::wstring keys;
      for (size_t i = 0; i < val.size(); ++i) {
        if (!iswspace(val[i])) {
          keys += val[i];
          continue;
        }
        size_t j = i;
        while (j < val.size() && iswspace(val[j])) ++j;
        if (!(!keys.empty() && keys.back() == L'+') && !(j < val.size() && val[j] == L'+')) keys += L' ';
        i = j - 1;
      }
      for (const auto& k : Split(keys, L", \t")) {
        std::wstring s = Lower(k);
        unsigned mods = 0;
        for (;;) {
          if (StartsWithI(s, L"ctrl+")) { mods |= 1; s = s.substr(5); }
          else if (StartsWithI(s, L"shift+")) { mods |= 2; s = s.substr(6); }
          else if (StartsWithI(s, L"alt+")) { mods |= 4; s = s.substr(4); }
          else break;
        }
        unsigned vk = 0;
        if (s.size() == 1 && iswalnum(s[0])) vk = (unsigned)towupper(s[0]);
        else if (s.size() >= 2 && s[0] == L'f' && iswdigit(s[1])) {
          long n = wcstol(s.c_str() + 1, nullptr, 10);
          if (n >= 1 && n <= 24) vk = VK_F1 + (unsigned)n - 1;  // 只认 F1～F24（原来 f0 会屏蔽小键盘除号、f32 会屏蔽 NumLock）
        }
        else if (s == L"esc" || s == L"escape") vk = VK_ESCAPE;
        else if (s == L"tab") vk = VK_TAB;
        else if (s == L"enter") vk = VK_RETURN;
        else if (s == L"backspace") vk = VK_BACK;
        else if (s == L"delete" || s == L"del") vk = VK_DELETE;
        else if (s == L"left") vk = VK_LEFT;
        else if (s == L"right") vk = VK_RIGHT;
        if (vk) blockKeys.insert((mods << 16) | vk);
      }
      return true;
    }
  }
  if (!Ready()) return true;
  return ApplyStr(p, val);
}

bool View::ApplyStr(int p, const std::wstring& val) {
  if (!Ready()) return false;
  if (p == WVS_USER_AGENT) {
    auto s2 = settings.as<ICoreWebView2Settings2>();
    if (!s2) {
      SetErr(WVERR_UNSUPPORTED, L"当前内核不支持修改 UA（需要 Edge 86+）", E_NOINTERFACE);
      return false;
    }
    HRESULT hr = s2->put_UserAgent(val.c_str());
    if (FAILED(hr)) {
      SetErr(WVERR_FAILED, L"设置 UA 失败：" + HrText(hr), hr);
      return false;
    }
  }
  return true;
}

std::wstring View::GetStrProp(int p) {
  switch (p) {
    case WVS_LAST_ERROR: return errMsg;
    case WVS_USER_DATA_DIR: return env ? env->udf : std::wstring();
    case WVS_RUNTIME_DIR: return env ? env->rt.dir : std::wstring();
    case WVS_BRIDGE_NAME: return bridgeName;
    case WVS_DOWNLOAD_DIR: return downloadDir;
  }
  if (!Ready()) {
    if (p == WVS_URL) return !pendingUrl.empty() ? pendingUrl : (!lastUrl.empty() ? lastUrl : initialUrl);
    auto it = sprops.find(p);
    return it == sprops.end() ? std::wstring() : it->second;
  }
  CoStr s;
  switch (p) {
    case WVS_URL: wv->get_Source(s.put()); return s.str();
    case WVS_TITLE: wv->get_DocumentTitle(s.put()); return s.str();
    case WVS_USER_AGENT: { auto s2 = settings.as<ICoreWebView2Settings2>(); if (s2) s2->get_UserAgent(s.put()); return s.str(); }
    case WVS_STATUS_TEXT: { auto w = wv.as<ICoreWebView2_12>(); if (w) w->get_StatusBarText(s.put()); return s.str(); }
    case WVS_FAVICON_URL: { auto w = wv.as<ICoreWebView2_15>(); if (w) w->get_FaviconUri(s.put()); return s.str(); }
    case WVS_BROWSER_VERSION: if (env && env->env) env->env->get_BrowserVersionString(s.put()); return s.str();
    case WVS_PROFILE_PATH:
    case WVS_PROFILE_NAME: {
      auto w13 = wv.as<ICoreWebView2_13>();
      ComPtr<ICoreWebView2Profile> prof;
      if (w13) w13->get_Profile(prof.put());
      if (prof) {
        if (p == WVS_PROFILE_PATH) prof->get_ProfilePath(s.put());
        else prof->get_ProfileName(s.put());
      }
      return s.str();
    }
  }
  auto it = sprops.find(p);
  return it == sprops.end() ? std::wstring() : it->second;
}

void View::ApplyAll() {
  if (!Ready()) return;
  for (const auto& kv : iprops) ApplyInt(kv.first, kv.second);
  for (const auto& kv : sprops) ApplyStr(kv.first, kv.second);
  if (!iprops.count(WVP_BG_COLOR)) {
    std::wstring d;
    {
      Guard g(GLock());
      d = G().defaultBg;
    }
    unsigned argb = 0;
    if (!d.empty() && ParseBgColor(d, argb)) ApplyInt(WVP_BG_COLOR, (int)argb);  // 写法与宿主窗口取底色（BgArgb）共用同一个解析
  }
  if (HasCb(WVE_SCRIPT_DIALOG) && !iprops.count(WVP_SCRIPT_DIALOGS)) settings->put_AreDefaultScriptDialogsEnabled(FALSE);
  ClearErr();
}

bool View::RequireReady() {
  if (Ready()) return true;
  if (state == WV_STATE_CREATING) SetErr(WVERR_NOT_READY, L"浏览器尚未创建完成（请在“创建完成”事件之后调用，或使用同步创建）");
  else if (state == WV_STATE_FAILED) SetErr(WVERR_NOT_READY, L"浏览器创建失败：" + errMsg, errHr);
  else SetErr(WVERR_CLOSED, L"浏览器已关闭");
  return false;
}

// ---------------------------------------------------------------- 导航与命令
bool View::Navigate(const std::wstring& url) {
  if (navPending && Ready()) {  // 首次导航尚未进行：并入首次导航，保证页面里有 JS 桥
    pendingUrl = url;
    return true;
  }

  std::wstring u = NormalizeUrl(url);
  if (!Ready()) {
    if (state == WV_STATE_CLOSED) return RequireReady();
    pendingUrl = u;
    return true;
  }
  HRESULT hr = wv->Navigate(u.c_str());
  if (FAILED(hr)) {
    SetErr(WVERR_ARG, L"打开网址失败：" + HrText(hr), hr);
    return false;
  }
  return true;
}

// 加载 HTML：内容按 UTF-8 放进内存，挂在 https://wv2bridge.example/浏览器编号-序号.html 下打开，由 WebResourceRequested 当场应答。
// 不用 NavigateToString：它限制 2MB（超出报“值不在预期范围内”），页面来源为 null（localStorage、indexedDB 不可用，也不是安全上下文）。
// 也不写临时文件：那样页面来源会随内容大小在 null 与 file:// 之间变化，文件名只含进程内编号，同一程序多开时会互相覆盖，内容还会明文留在磁盘上。
// 每次加载用新网址，最近几页留在内存里，后退、刷新和内核崩溃后的自动恢复都能取回页面
bool View::NavigateHtml(const std::wstring& html) {
  if (state == WV_STATE_CLOSED) return RequireReady();
  std::wstring url = Fmt(L"%ls/%d-%ld.html", kHtmlPageOrigin, id, (long)InterlockedIncrement(&g_htmlSeq));
  std::string u8 = ToUtf8(html);
  MemFile f;
  f.data.assign(u8.begin(), u8.end());
  f.mime = L"text/html; charset=utf-8";
  f.url = url;
  f.page = true;
  std::wstring key = Lower(url);  // 与 memFiles 的键一致（网址里没有查询串与锚点）
  memFiles[key] = std::move(f);
  htmlPages.push_back(key);
  PruneHtmlPages();
  if (Ready()) EnsureRequestHook();
  return Navigate(url);
}

void View::PruneHtmlPages() {
  while (htmlPages.size() > 1) {
    size_t total = 0;
    for (const auto& k : htmlPages) {
      auto it = memFiles.find(k);
      if (it != memFiles.end() && it->second.page) total += it->second.data.size();
    }
    if (htmlPages.size() <= kHtmlPageKeep && total <= kHtmlPageBytes) break;
    auto it = memFiles.find(htmlPages.front());
    if (it != memFiles.end() && it->second.page) memFiles.erase(it);  // 已被 置内存文件 改写的同名网址不归页面管理，不删
    htmlPages.pop_front();
  }
}

bool View::NavigateEx(const std::wstring& url, const std::wstring& method, const std::wstring& headers, const void* body, int len) {
  if (navPending && Ready()) {  // 直接导航：不再进行首次导航，避免它覆盖这次导航
    navPending = false;
    if (host) KillTimer(host, 3);
  }
  if (!RequireReady()) return false;
  auto e2 = env && env->env ? env->env.as<ICoreWebView2Environment2>() : ComPtr<ICoreWebView2Environment2>();
  auto w2 = wv.as<ICoreWebView2_2>();
  if (!e2 || !w2) {
    SetErr(WVERR_UNSUPPORTED, L"当前内核不支持自定义请求导航", E_NOINTERFACE);
    return false;
  }
  ComPtr<IStream> st;
  if (body && len > 0) st = MakeStream(body, (size_t)len);
  std::wstring h = ReplaceAll(headers, L"\r\n", L"\n");
  h = ReplaceAll(h, L"\n", L"\r\n");
  ComPtr<ICoreWebView2WebResourceRequest> req;
  HRESULT hr = e2->CreateWebResourceRequest(NormalizeUrl(url).c_str(), method.empty() ? L"GET" : method.c_str(), st.get(), h.c_str(), req.put());
  if (SUCCEEDED(hr)) hr = w2->NavigateWithWebResourceRequest(req.get());
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"发送请求失败：" + HrText(hr), hr);
    return false;
  }
  return true;
}

bool View::Command(int cmd) {
  if (cmd == WVC_FOCUS) {
    if (host) SetFocus(host);
    return true;
  }
  // 1.8.1：顶层窗口属于别的线程或进程时 DLL 子类化不了它（comctl32 的子类化不能跨线程），收不到它的移动与最小化：由程序转告。
  // 尚未就绪时也返回真（程序在每次移动时调用，不必先判断）：就绪前没有弹出窗口要摆，最小化状态记下，就绪后按它设置可见
  if (cmd == WVC_NOTIFY_MOVED) {
    NotifyMoved();
    return true;
  }
  if (cmd == WVC_MINIMIZED || cmd == WVC_RESTORED) {
    OnMinimize(cmd == WVC_MINIMIZED);
    return true;
  }
  if (!RequireReady()) return false;
  HRESULT hr = S_OK;
  switch (cmd) {
    case WVC_BACK: hr = wv->GoBack(); break;
    case WVC_FORWARD: hr = wv->GoForward(); break;
    case WVC_RELOAD: hr = wv->Reload(); break;
    case WVC_STOP: hr = wv->Stop(); break;
    case WVC_DEVTOOLS: hr = wv->OpenDevToolsWindow(); break;
    case WVC_TASK_MANAGER: { auto w = wv.as<ICoreWebView2_6>(); hr = w ? w->OpenTaskManagerWindow() : E_NOINTERFACE; break; }
    case WVC_PRINT_DIALOG:
    case WVC_PRINT_SYSTEM: {
      auto w = wv.as<ICoreWebView2_16>();
      if (w) hr = w->ShowPrintUI(cmd == WVC_PRINT_DIALOG ? COREWEBVIEW2_PRINT_DIALOG_KIND_BROWSER : COREWEBVIEW2_PRINT_DIALOG_KIND_SYSTEM);
      else hr = wv->ExecuteScript(L"window.print()", Callback<ICoreWebView2ExecuteScriptCompletedHandler, HRESULT, LPCWSTR>([](HRESULT, LPCWSTR) -> HRESULT { return S_OK; }).get());
      break;
    }
    case WVC_DOWNLOAD_DIALOG: { auto w = wv.as<ICoreWebView2_9>(); hr = w ? w->OpenDefaultDownloadDialog() : E_NOINTERFACE; break; }
    case WVC_DOWNLOAD_DIALOG_CLOSE: { auto w = wv.as<ICoreWebView2_9>(); hr = w ? w->CloseDefaultDownloadDialog() : E_NOINTERFACE; break; }
    case WVC_SUSPEND: {
      auto w = wv.as<ICoreWebView2_3>();
      if (!w) { hr = E_NOINTERFACE; break; }
      ctl->put_IsVisible(FALSE);  // 挂起要求先隐藏
      hr = w->TrySuspend(Callback<ICoreWebView2TrySuspendCompletedHandler, HRESULT, BOOL>([](HRESULT, BOOL) -> HRESULT { return S_OK; }).get());
      break;
    }
    case WVC_RESUME: {
      auto w = wv.as<ICoreWebView2_3>();
      hr = w ? w->Resume() : E_NOINTERFACE;
      if (SUCCEEDED(hr)) ctl->put_IsVisible(visible && !minimized ? TRUE : FALSE);
      break;
    }
    case WVC_HARD_RELOAD:
      // 不要结果也传空回调：WebView2 文档没说明这些方法接受空的回调
      hr = wv->CallDevToolsProtocolMethod(L"Page.reload", L"{\"ignoreCache\":true}", Callback<ICoreWebView2CallDevToolsProtocolMethodCompletedHandler, HRESULT, LPCWSTR>([](HRESULT, LPCWSTR) -> HRESULT { return S_OK; }).get());
      break;
    case WVC_EXIT_FULLSCREEN:
      hr = wv->ExecuteScript(L"document.fullscreenElement&&document.exitFullscreen()", Callback<ICoreWebView2ExecuteScriptCompletedHandler, HRESULT, LPCWSTR>([](HRESULT, LPCWSTR) -> HRESULT { return S_OK; }).get());
      if (isFull) ExitFullscreen();
      break;
    default:
      SetErr(WVERR_ARG, L"未知命令");
      return false;
  }
  if (hr == E_NOINTERFACE) {
    SetErr(WVERR_UNSUPPORTED, L"当前内核版本不支持该命令", hr);
    return false;
  }
  if (FAILED(hr)) {
    SetErr(WVERR_FAILED, L"命令执行失败：" + HrText(hr), hr);
    return false;
  }
  return true;
}

// ---------------------------------------------------------------- 全屏：把宿主窗口临时搬到覆盖整个显示器的弹出窗口
void View::EnterFullscreen() {
  if (isFull || !host) return;
  HWND root = GetAncestor(host, GA_ROOT);
  HMONITOR mon = MonitorFromWindow(root ? root : host, MONITOR_DEFAULTTONEAREST);
  MONITORINFO mi;
  mi.cbSize = sizeof(mi);
  if (!GetMonitorInfoW(mon, &mi)) return;
  RECT m = mi.rcMonitor;
  savedParent = GetParent(host);
  GetWindowRect(host, &savedRect);
  MapWindowPoints(HWND_DESKTOP, savedParent, reinterpret_cast<POINT*>(&savedRect), 2);
  fullWin = CreateWindowExW(0, kFullClass, L"", WS_POPUP | WS_CLIPCHILDREN, m.left, m.top, m.right - m.left, m.bottom - m.top, root, nullptr,
                            g_module, reinterpret_cast<LPVOID>((intptr_t)id));
  if (!fullWin) return;
  isFull = true;
  SetParent(host, fullWin);
  SetWindowPos(host, nullptr, 0, 0, m.right - m.left, m.bottom - m.top, SWP_NOZORDER | SWP_NOACTIVATE | SWP_SHOWWINDOW);
  ShowWindow(fullWin, SW_SHOW);
  SetForegroundWindow(fullWin);
  UpdateBounds();
  NotifyMoved();
  if (ctl) ctl->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC);
}

void View::ExitFullscreen() {
  if (!isFull) return;
  isFull = false;
  HWND fw = fullWin;
  fullWin = nullptr;
  if (host && savedParent && IsWindow(savedParent)) {
    SetParent(host, savedParent);
    SetWindowPos(host, nullptr, savedRect.left, savedRect.top, savedRect.right - savedRect.left, savedRect.bottom - savedRect.top,
                 SWP_NOZORDER | SWP_NOACTIVATE);
    if (fill) Layout();
  }
  if (fw) DestroyWindow(fw);
  UpdateBounds();
  NotifyMoved();
  HWND root = host ? GetAncestor(host, GA_ROOT) : nullptr;
  if (root) SetForegroundWindow(root);
  if (ctl) ctl->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC);
}

}  // namespace wv
