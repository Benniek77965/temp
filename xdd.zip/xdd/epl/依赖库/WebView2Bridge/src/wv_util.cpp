// wv_util.cpp : 编码转换、JSON、路径、错误与返回缓冲、日志、保护调用桩、消息泵
#include "wv_internal.h"

namespace wv {

HMODULE g_module = nullptr;

Globals& G() {
  static Globals g;
  return g;
}
std::atomic<int>& DevChecks() {
  static std::atomic<int> v{0};
  return v;
}
std::atomic<DWORD>& UiThread() {
  static std::atomic<DWORD> v{0};
  return v;
}
std::atomic<HWND>& Dispatcher() {
  static std::atomic<HWND> v{nullptr};
  return v;
}
std::atomic<int>& CodePageVar() {
  static std::atomic<int> v{0};
  return v;
}
Lock& GLock() {
  static Lock l;
  return l;
}
int CodePage() { return CodePageVar().load(); }

std::wstring AppDir() {
  {
    Guard g(GLock());
    if (!G().appDir.empty()) return G().appDir;
  }
  return PathDir(ModulePath(nullptr));
}

// ---------------------------------------------------------------- 编码
static std::wstring MbToWide(const char* s, int len, UINT cp) {
  if (!s || len == 0) return std::wstring();
  int n = MultiByteToWideChar(cp, 0, s, len, nullptr, 0);
  if (n <= 0) return std::wstring();
  std::wstring w((size_t)n, L'\0');
  MultiByteToWideChar(cp, 0, s, len, &w[0], n);
  if (len < 0 && !w.empty() && w.back() == L'\0') w.pop_back();
  return w;
}
static std::string WideToMb(const std::wstring& w, UINT cp) {
  if (w.empty()) return std::string();
  int n = WideCharToMultiByte(cp, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
  if (n <= 0) return std::string();
  std::string s((size_t)n, '\0');
  WideCharToMultiByte(cp, 0, w.c_str(), (int)w.size(), &s[0], n, nullptr, nullptr);
  return s;
}
static UINT ActiveCp() {
  int cp = CodePage();
  return cp == 0 ? CP_ACP : (UINT)cp;
}
// ---------------------------------------------------------------- 文本检查（WVO_DEV_CHECKS）与统计
namespace {
std::atomic<long> g_encFallback{0}, g_encSuspect{0}, g_threadTimeouts{0};
std::atomic<int> g_suspectNotices{0};  // 疑似没有转换的 GBK 文字已经弹出说明的次数（每次运行最多 kSuspectNoticeMax 次）
const int kSuspectNoticeMax = 3;
thread_local bool t_encPending = false;
thread_local std::wstring t_encSample;
std::wstring EncClip(const std::wstring& s) { return s.size() <= 24 ? s : s.substr(0, 24) + L"…"; }
bool EncIsHan(wchar_t c) { return (c >= 0x4E00 && c <= 0x9FFF) || (c >= 0x3400 && c <= 0x4DBF) || (c >= 0xF900 && c <= 0xFAFF); }
// 特征更明显的疑似：每个非 ASCII 字符都正好是一个 GB2312 汉字的两个字节（第二个字节在 A1–BF 之间，解成 UTF-8 后低 6 位不小于 0x21），
// 并且不紧挨着英文字母。西文单词里的重音字母（café、naïve）紧挨着英文字母，不算；俄文词里有 р–я（低 6 位小于 0x21）的不算，
// 只由 а–п 组成的俄文短词（如 дом）仍会符合，所以说明框写明可能是误报。没有转换的中文一般不夹在英文单词中间。
// 只用来决定调试运行时要不要弹出说明，计数与日志仍按 CheckSuspectAnsi 的宽松条件
bool SuspectStrict(const std::wstring& w) {
  auto letter = [](wchar_t x) { return (x >= L'a' && x <= L'z') || (x >= L'A' && x <= L'Z'); };
  for (size_t i = 0; i < w.size(); ++i) {
    const wchar_t c = w[i];
    if (c < 0x80) continue;
    if (c > 0x7FF || (c & 0x3F) < 0x21) return false;
    if ((i > 0 && letter(w[i - 1])) || (i + 1 < w.size() && letter(w[i + 1]))) return false;
  }
  return true;
}
// 合法的 UTF-8，但疑似是没有转换的系统 ANSI 文本：GBK 里首字节 0xC2–0xDF、次字节 0xA1–0xBF 的汉字本身就是合法的两字节 UTF-8
// （实测 GB2312 一级字有 18.2%，两字词有 3.3% 整体是合法 UTF-8），解出来全在 U+0080–U+07FF。所有非 ASCII 字符都在这个范围、
// 按系统代码页解释又全是汉字时记一次疑似（只写日志与计数：按 UTF-8 处理不变，西文重音字母这类正常文本也可能符合）
// 只检查非 ASCII 字符不超过 16 个的文本：没有转换的 GBK 文字整段恰好是合法 UTF-8 的概率随字数按约 0.18 的乘方下降（2 个字约 3%，5 个字约 0.02%），
// 长文本几乎不会出现；而俄文、希腊文等正常的 UTF-8 文本全在这个范围里，长段检查只会误报，还要把整段文本按系统代码页再转换一遍
void CheckSuspectAnsi(const char* s, const std::wstring& w) {
  int nonAscii = 0;
  for (wchar_t c : w) {
    if (c < 0x80) continue;
    if (c > 0x7FF || ++nonAscii > 16) return;
  }
  if (!nonAscii) return;
  int n = MultiByteToWideChar(CP_ACP, MB_ERR_INVALID_CHARS, s, -1, nullptr, 0);
  if (n <= 1) return;
  std::wstring a((size_t)n, L'\0');
  MultiByteToWideChar(CP_ACP, MB_ERR_INVALID_CHARS, s, -1, &a[0], n);
  a.pop_back();
  for (wchar_t c : a)
    if (c >= 0x80 && !EncIsHan(c)) return;
  const long k = ++g_encSuspect;
  // 调试运行（开发期检查为 1）时，特征更明显的疑似弹出说明：这类文字合法，不会像不合法的 UTF-8 那样让调用失败，原来只计数、写日志，
  // 易语言调试时看不到，源码里单独写的“陆”“卢”“路”这类字没有用 WV文本 () 包起来时，网页里悄悄变成“½”“¬”“·”。
  // 同一段文字只提示一次，每次运行最多提示 kSuspectNoticeMax 次（正常的西文符号偶尔也会符合，不能一直弹）
  if (DevChecks().load() == 1 && g_suspectNotices.load() < kSuspectNoticeMax && SuspectStrict(w)) {
    const std::wstring u = EncClip(w), g = EncClip(a);
    const std::wstring msg = Fmt(L"交给本层的文本按 UTF-8 是“%ls”，按系统 ANSI 代码页看是“%ls”：很可能是易语言源码里的中文没有用 WV文本 () 包起来"
                                 L"（这段 GBK 文字恰好也是合法的 UTF-8，所以没有报错，已按 UTF-8 处理成“%ls”）。如果它本来就是“%ls”，忽略本提示即可。"
                                 L"同一段文字只提示一次，每次运行最多提示 %d 次",
                                 u.c_str(), g.c_str(), u.c_str(), u.c_str(), kSuspectNoticeMax);
    if (DevNotice(L"suspect:" + w, msg)) ++g_suspectNotices;
  }
  if (k > 20) return;
  // 文字本身只在开发期检查打开时写进日志：编译后的程序运行在用户机器上，日志（同时输出到 OutputDebugString）里不留用户的数据
  if (DevChecks().load() != 0)
    Log(L"疑似没有转换成 UTF-8 的系统 ANSI 文本（仍按 UTF-8 处理）：按 UTF-8 是“%ls”，按系统代码页是“%ls”", EncClip(w).c_str(), EncClip(a).c_str());
  else
    Log(L"疑似没有转换成 UTF-8 的系统 ANSI 文本（%u 个字符，仍按 UTF-8 处理；内容不写进日志）", (unsigned)w.size());
}
// 不是合法的 UTF-8：开发期检查打开时这次调用失败（导出函数的异常处理把它换成 WVERR_ENCODING 与说明），否则照旧按系统 ANSI 代码页解释
void OnInvalidUtf8(const std::wstring& ansi) {
  if (DevChecks().load() != 0) {
    t_encPending = true;
    t_encSample = EncClip(ansi);
    throw EncodingError();
  }
  const long k = ++g_encFallback;
  if (k <= 20) Log(L"收到的文本不是合法的 UTF-8，已按系统 ANSI 代码页解释（%u 个字符；内容不写进日志）", (unsigned)ansi.size());
}
}  // namespace
bool TakeEncodingError(std::wstring& sample) {
  if (!t_encPending) return false;
  t_encPending = false;
  sample = t_encSample;
  t_encSample.clear();
  return true;
}
void CountThreadTimeout() { ++g_threadTimeouts; }

std::wstring FromCP(const char* s) {
  if (!s || !*s) return std::wstring();
  const UINT cp = ActiveCp();
  if (cp == CP_UTF8) {
    // 严格按 UTF-8 解码：不是合法的 UTF-8（例如误传了 ANSI 文本）时，开发期检查打开则调用失败，否则改按系统 ANSI 代码页解释。
    // 不加 MB_ERR_INVALID_CHARS 时系统会把非法字节换成替换字符而不报错，下面的检查就永远用不上
    int n = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, s, -1, nullptr, 0);
    if (n > 0) {
      std::wstring w((size_t)n, L'\0');
      MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, s, -1, &w[0], n);
      w.pop_back();
      CheckSuspectAnsi(s, w);
      return w;
    }
    std::wstring a = MbToWide(s, -1, CP_ACP);
    OnInvalidUtf8(a);
    return a;
  }
  std::wstring w = MbToWide(s, -1, cp);
  if (w.empty()) w = MbToWide(s, -1, CP_ACP);
  return w;
}
// 每行一项的文本逐行按代码页转换：创建选项、文本属性（白名单、屏蔽列表等）、协议头与应答头、Cookie 文本、响应捕获的通配符。
// 例如易语言类把各项设置拼成一段“键=值”文本：整段一起转换时，只要有一项漏了转换（编译后的程序里不是 UTF-8 的文本按系统 ANSI 代码页解释），
// 所有行就都按 ANSI 解释，其它已经是 UTF-8 的项（中文的绑定函数名、桥接名称等）也跟着变成乱码。逐行转换时只有漏转换的那一行按 ANSI 解释；
// 开发期检查打开时，报错说明里也正好是这一行。脚本、HTML、JSON 是整段的文档，仍整段转换。回车、换行在 UTF-8 与各种双字节代码页里都只表示自己
// （双字节字符的第二个字节不小于 0x40），按字节分行不会切开字符；换行原样保留
std::wstring FromCPLines(const char* s) {
  if (!s || !*s) return std::wstring();
  std::wstring out;
  for (const char* p = s; *p;) {
    const char* e = p;
    while (*e && *e != '\r' && *e != '\n') ++e;
    if (e > p) out += FromCP(std::string(p, e).c_str());
    if (*e) out += (wchar_t)(unsigned char)*e++;
    p = e;
  }
  return out;
}
std::string ToCP(const std::wstring& w) { return WideToMb(w, ActiveCp()); }
std::string ToUtf8(const std::wstring& w) { return WideToMb(w, CP_UTF8); }
std::wstring FromUtf8(const char* s, int len) { return MbToWide(s, len, CP_UTF8); }
std::wstring FromAnsi(const char* s) { return (!s || !*s) ? std::wstring() : MbToWide(s, -1, CP_ACP); }
static int HexDigit(wchar_t c) {
  if (c >= L'0' && c <= L'9') return c - L'0';
  if (c >= L'a' && c <= L'f') return c - L'a' + 10;
  if (c >= L'A' && c <= L'F') return c - L'A' + 10;
  return -1;
}
static bool ReadUEscape(const std::wstring& s, size_t i, unsigned& v) {
  if (i + 6 > s.size() || s[i] != L'\\' || s[i + 1] != L'u') return false;
  v = 0;
  for (size_t k = i + 2; k < i + 6; ++k) {
    int d = HexDigit(s[k]);
    if (d < 0) return false;
    v = v * 16 + (unsigned)d;
  }
  return true;
}
// 在 UTF-16 上找转义：GBK 有第二个字节是 0x5C（反斜杠）的汉字，按字节找会把它后面的 u 加四个十六进制字符误当成转义
std::wstring DecodeUEscapes(const std::wstring& s) {
  std::wstring o;
  o.reserve(s.size());
  for (size_t i = 0; i < s.size();) {
    unsigned v = 0, lo = 0;
    if (!ReadUEscape(s, i, v) || v == 0) {
      o += s[i++];
      continue;
    }
    if (v >= 0xD800 && v <= 0xDBFF && ReadUEscape(s, i + 6, lo) && lo >= 0xDC00 && lo <= 0xDFFF) {
      o += (wchar_t)v;
      o += (wchar_t)lo;
      i += 12;
      continue;
    }
    o += (v >= 0xD800 && v <= 0xDFFF) ? (wchar_t)0xFFFD : (wchar_t)v;
    i += 6;
  }
  return o;
}

static bool Representable(wchar_t c, UINT cp) {
  static thread_local std::vector<unsigned char> cache;  // 每个线程一份，多线程同时转换不会互相破坏
  static thread_local UINT cacheCp = 0xFFFFFFFFu;
  if (cp == CP_ACP) cp = GetACP();
  if (cp == CP_UTF8) return true;
  if (cacheCp != cp) {
    cache.assign(65536, 0);
    cacheCp = cp;
  }
  unsigned char& st = cache[(unsigned)c];
  if (st == 0) {
    char buf[8];
    BOOL used = FALSE;
    int n = WideCharToMultiByte(cp, WC_NO_BEST_FIT_CHARS, &c, 1, buf, sizeof(buf), nullptr, &used);
    if (n <= 0) {
      used = FALSE;
      n = WideCharToMultiByte(cp, 0, &c, 1, buf, sizeof(buf), nullptr, &used);
    }
    st = (n > 0 && !used) ? 1 : 2;
  }
  return st == 1;
}
static void AppendU(std::wstring& o, unsigned v) {
  static const wchar_t* hx = L"0123456789abcdef";
  o += L"\\u";
  o += hx[(v >> 12) & 15];
  o += hx[(v >> 8) & 15];
  o += hx[(v >> 4) & 15];
  o += hx[v & 15];
}
std::string ToCPJson(const std::wstring& w) {
  // 转义的目标：默认按文本代码页；WVO_JSON_ESCAPE 为 1 时按系统 ANSI 代码页（文本是 UTF-8、调用方再转回 ANSI 时，
  // 转回后 JSON 不丢字符），为 2 时所有非 ASCII 字符都转义
  int mode = 0;
  {
    Guard g(GLock());  // WV_SetOption 可能正在别的线程上改它
    mode = G().jsonEscape;
  }
  const UINT cp = mode == 1 ? (UINT)CP_ACP : ActiveCp();
  if (mode != 2 && (cp == CP_UTF8 || (cp == CP_ACP && GetACP() == CP_UTF8))) return ToCP(w);
  std::wstring o;
  o.reserve(w.size());
  for (size_t i = 0; i < w.size(); ++i) {
    wchar_t c = w[i];
    if (c < 0x80) { o += c; continue; }
    bool pair = (c >= 0xD800 && c <= 0xDBFF && i + 1 < w.size() && w[i + 1] >= 0xDC00 && w[i + 1] <= 0xDFFF);
    if (pair) { AppendU(o, c); AppendU(o, w[i + 1]); ++i; continue; }
    if (mode != 2 && Representable(c, cp)) o += c; else AppendU(o, c);
  }
  return ToCP(o);
}

// ---------------------------------------------------------------- 字符串
std::wstring Trim(const std::wstring& s) {
  size_t b = 0, e = s.size();
  while (b < e && iswspace(s[b])) ++b;
  while (e > b && iswspace(s[e - 1])) --e;
  return s.substr(b, e - b);
}
std::wstring Lower(std::wstring s) {
  for (auto& c : s) c = (wchar_t)towlower(c);
  return s;
}
bool StartsWithI(const std::wstring& s, const wchar_t* p) {
  size_t n = wcslen(p);
  return s.size() >= n && _wcsnicmp(s.c_str(), p, n) == 0;
}
bool EndsWithI(const std::wstring& s, const wchar_t* p) {
  size_t n = wcslen(p);
  return s.size() >= n && _wcsicmp(s.c_str() + s.size() - n, p) == 0;
}
std::vector<std::wstring> Split(const std::wstring& s, const wchar_t* seps) {
  std::vector<std::wstring> r;
  std::wstring cur;
  for (wchar_t c : s) {
    if (wcschr(seps, c)) {
      cur = Trim(cur);
      if (!cur.empty()) r.push_back(cur);
      cur.clear();
    } else {
      cur += c;
    }
  }
  cur = Trim(cur);
  if (!cur.empty()) r.push_back(cur);
  return r;
}
std::wstring ReplaceAll(std::wstring s, const std::wstring& from, const std::wstring& to) {
  if (from.empty()) return s;
  size_t pos = 0;
  while ((pos = s.find(from, pos)) != std::wstring::npos) {
    s.replace(pos, from.size(), to);
    pos += to.size();
  }
  return s;
}
std::wstring JsonStr(const std::wstring& s) {
  std::wstring o;
  o.reserve(s.size() + 2);
  o += L'"';
  for (wchar_t c : s) {
    switch (c) {
      case L'"': o += L"\\\""; break;
      case L'\\': o += L"\\\\"; break;
      case L'\n': o += L"\\n"; break;
      case L'\r': o += L"\\r"; break;
      case L'\t': o += L"\\t"; break;
      case L'\b': o += L"\\b"; break;
      case L'\f': o += L"\\f"; break;
      default:
        if (c < 0x20 || c == 0x2028 || c == 0x2029) AppendU(o, c);
        else o += c;
    }
  }
  o += L'"';
  return o;
}
bool WildMatch(const std::wstring& pattern, const std::wstring& text) {
  const wchar_t* p = pattern.c_str();
  const wchar_t* t = text.c_str();
  const wchar_t* star = nullptr;
  const wchar_t* back = nullptr;
  while (*t) {
    if (*p == L'*') { star = p++; back = t; continue; }
    if (*p == L'?' || towlower(*p) == towlower(*t)) { ++p; ++t; continue; }
    if (star) { p = star + 1; t = ++back; continue; }
    return false;
  }
  while (*p == L'*') ++p;
  return *p == 0;
}
std::wstring Fmt(const wchar_t* fmt, ...) {
  wchar_t buf[2048];
  va_list ap;
  va_start(ap, fmt);
  int n = _vsnwprintf(buf, 2047, fmt, ap);
  va_end(ap);
  if (n < 0) n = 2047;
  buf[n] = 0;
  return buf;
}
std::wstring HrText(HRESULT hr) {
  wchar_t* msg = nullptr;
  DWORD n = FormatMessageW(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, nullptr,
                           (DWORD)hr, 0, (LPWSTR)&msg, 0, nullptr);
  std::wstring s;
  if (n && msg) s = Trim(msg);
  if (msg) LocalFree(msg);
  std::wstring code = Fmt(L"0x%08X", (unsigned)hr);
  return s.empty() ? code : s + L"（" + code + L"）";
}
static int B64Val(unsigned char c) {
  if (c >= 'A' && c <= 'Z') return c - 'A';
  if (c >= 'a' && c <= 'z') return c - 'a' + 26;
  if (c >= '0' && c <= '9') return c - '0' + 52;
  if (c == '+' || c == '-') return 62;
  if (c == '/' || c == '_') return 63;
  return -1;
}
bool Base64Decode(const std::string& in, std::vector<unsigned char>& out) {
  out.clear();
  out.reserve(in.size() * 3 / 4);
  unsigned acc = 0;
  int bits = 0;
  for (unsigned char c : in) {
    if (c == '=' || c == '\r' || c == '\n' || c == ' ') continue;
    int v = B64Val(c);
    if (v < 0) return false;
    acc = (acc << 6) | (unsigned)v;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      out.push_back((unsigned char)((acc >> bits) & 0xFF));
    }
  }
  return true;
}

// ---------------------------------------------------------------- 路径与文件
std::wstring PathJoin(const std::wstring& a, const std::wstring& b) {
  if (a.empty()) return b;
  if (b.empty()) return a;
  if (a.back() == L'\\' || a.back() == L'/') return a + b;
  return a + L"\\" + b;
}
std::wstring PathDir(const std::wstring& p) {
  size_t k = p.find_last_of(L"\\/");
  return k == std::wstring::npos ? std::wstring() : p.substr(0, k);
}
std::wstring PathName(const std::wstring& p) {
  size_t k = p.find_last_of(L"\\/");
  return k == std::wstring::npos ? p : p.substr(k + 1);
}
std::wstring TrimSlash(std::wstring p) {
  while (p.size() > 3 && (p.back() == L'\\' || p.back() == L'/')) p.pop_back();
  return p;
}
bool IsAbsPath(const std::wstring& p) {
  if (p.size() >= 2 && iswalpha(p[0]) && p[1] == L':') return true;
  return p.size() >= 2 && (p[0] == L'\\' || p[0] == L'/') && (p[1] == L'\\' || p[1] == L'/');
}
std::wstring AppPath(const std::wstring& p) { return p.empty() || IsAbsPath(p) ? p : PathJoin(AppDir(), p); }
std::wstring FullPath(const std::wstring& p) {
  if (p.empty()) return p;
  DWORD n = GetFullPathNameW(p.c_str(), 0, nullptr, nullptr);
  if (!n) return p;
  std::wstring r((size_t)n, L'\0');
  DWORD m = GetFullPathNameW(p.c_str(), n, &r[0], nullptr);
  if (!m || m >= n) return p;
  r.resize(m);
  return r;
}
// 解开网址路径里的 %XX：网址里的非 ASCII 字符按 UTF-8 写成 %XX，连续的几个字节一起按 UTF-8 解码；解出 %00 时 nul 为真
static std::wstring PercentDecodeUtf8(const std::wstring& p, bool& nul) {
  std::string bytes;
  std::wstring run;
  for (size_t i = 0; i < p.size(); ++i) {
    int h1 = 0, h2 = 0;
    if (p[i] == L'%' && i + 2 < p.size() && (h1 = HexDigit(p[i + 1])) >= 0 && (h2 = HexDigit(p[i + 2])) >= 0) {
      bytes += ToUtf8(run);
      run.clear();
      bytes += (char)(h1 * 16 + h2);
      i += 2;
    } else {
      run += p[i];
    }
  }
  bytes += ToUtf8(run);
  nul = bytes.find('\0') != std::string::npos;
  return FromUtf8(bytes.c_str(), (int)bytes.size());
}
std::wstring PathFromMappedUrl(const std::wstring& url, const std::wstring& dir) {
  const size_t k = url.find(L"://");
  if (k == std::wstring::npos || dir.empty()) return std::wstring();
  const size_t s = url.find(L'/', k + 3);
  std::wstring rel = s == std::wstring::npos ? std::wstring() : url.substr(s);
  const size_t cut = rel.find_first_of(L"?#");
  if (cut != std::wstring::npos) rel.resize(cut);
  bool nul = false;
  std::wstring w = PercentDecodeUtf8(rel, nul);
  if (nul) return std::wstring();
  for (auto& c : w)
    if (c == L'/') c = L'\\';
  const std::wstring full = FullPath(TrimSlash(dir) + w);
  return PathUnder(full, dir) ? full : std::wstring();  // 规整后跑到映射目录外面的（.. 或 %5C 这类写法）不算
}
std::wstring PathFromFileUrl(const std::wstring& url) {
  if (!StartsWithI(url, L"file:")) return std::wstring();
  std::wstring rest = url.substr(5);
  const size_t cut = rest.find_first_of(L"?#");
  if (cut != std::wstring::npos) rest.resize(cut);
  std::wstring p = rest;
  if (rest.compare(0, 2, L"//") == 0) {
    const size_t slash = rest.find(L'/', 2);
    const std::wstring host = rest.substr(2, slash == std::wstring::npos ? std::wstring::npos : slash - 2);
    const std::wstring tail = slash == std::wstring::npos ? std::wstring() : rest.substr(slash);
    // file://C:/a 这种少写一个斜杠的写法，“主机”其实是盘符（浏览器也按盘符处理），不是网络共享的服务器名；其余有主机名的是网络共享
    const bool drive = host.size() == 2 && iswalpha(host[0]) && (host[1] == L':' || host[1] == L'|');
    p = host.empty() || _wcsicmp(host.c_str(), L"localhost") == 0 ? tail : drive ? L"/" + host + tail : L"//" + host + tail;
  }
  bool nul = false;
  std::wstring w = PercentDecodeUtf8(p, nul);
  if (nul) return std::wstring();
  if (w.size() >= 3 && (w[0] == L'/' || w[0] == L'\\') && iswalpha(w[1]) && (w[2] == L':' || w[2] == L'|')) {  // /C:/a → C:/a
    w.erase(0, 1);
    w[1] = L':';
  }
  // 盘符后面必须紧跟路径分隔符。C:a 这种写法按该盘的“当前目录”解析，结果随进程当时的当前目录而变（浏览器进程的当前目录与本进程的也不一样），
  // 原来照样换成完整路径，当前目录恰好是程序目录时 file:///C:ui/x.html 会被当成程序目录里的页面；用来判断信任不行，按无效处理。
  // 只写盘符（file:///C:）当作该盘的根目录
  if (w.size() >= 2 && iswalpha(w[0]) && w[1] == L':') {
    if (w.size() == 2) w += L'\\';
    else if (w[2] != L'/' && w[2] != L'\\') return std::wstring();
  }
  for (auto& c : w)
    if (c == L'/') c = L'\\';
  if (!IsAbsPath(w)) return std::wstring();
  return FullPath(w);  // 规整掉 . 与 ..（不访问磁盘）：C:\app\..\x 是 C:\x，不在程序目录里
}
bool PathUnder(const std::wstring& path, const std::wstring& dir) {
  if (path.empty() || dir.empty()) return false;
  std::wstring d = FullPath(dir);
  while (!d.empty() && (d.back() == L'\\' || d.back() == L'/')) d.pop_back();
  if (d.empty() || path.size() < d.size()) return false;
  if (CompareStringOrdinal(path.c_str(), (int)d.size(), d.c_str(), (int)d.size(), TRUE) != CSTR_EQUAL) return false;
  return path.size() == d.size() || path[d.size()] == L'\\';
}
bool FileExists(const std::wstring& p) {
  DWORD a = GetFileAttributesW(p.c_str());
  return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY);
}
bool DirExists(const std::wstring& p) {
  DWORD a = GetFileAttributesW(p.c_str());
  return a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY);
}
bool EnsureDir(const std::wstring& p) {
  if (p.empty()) return false;
  if (DirExists(p)) return true;
  std::wstring parent = PathDir(p);
  if (!parent.empty() && parent != p && !DirExists(parent)) EnsureDir(parent);
  return CreateDirectoryW(p.c_str(), nullptr) || GetLastError() == ERROR_ALREADY_EXISTS;
}
bool DirWritable(const std::wstring& p) {
  std::wstring f = PathJoin(p, Fmt(L".wv2_write_test_%u", GetCurrentProcessId()));
  HANDLE h = CreateFileW(f.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_TEMPORARY | FILE_FLAG_DELETE_ON_CLOSE, nullptr);
  if (h == INVALID_HANDLE_VALUE) return false;
  CloseHandle(h);
  return true;
}
bool WriteFileBytes(const std::wstring& p, const void* d, size_t n) {
  EnsureDir(PathDir(p));
  HANDLE h = CreateFileW(p.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (h == INVALID_HANDLE_VALUE) return false;
  const unsigned char* q = static_cast<const unsigned char*>(d);
  bool ok = true;
  while (n > 0) {
    DWORD chunk = n > 0x100000 ? 0x100000 : (DWORD)n, w = 0;
    if (!WriteFile(h, q, chunk, &w, nullptr) || w == 0) { ok = false; break; }
    q += w;
    n -= w;
  }
  CloseHandle(h);
  return ok;
}
std::wstring ModulePath(HMODULE m) {
  std::wstring buf(32768, L'\0');
  DWORD n = GetModuleFileNameW(m, &buf[0], (DWORD)buf.size());
  buf.resize(n);
  return buf;
}
std::wstring FileVersion(const std::wstring& path) {
  DWORD dummy = 0;
  DWORD sz = GetFileVersionInfoSizeW(path.c_str(), &dummy);
  if (!sz) return std::wstring();
  std::vector<unsigned char> buf(sz);
  if (!GetFileVersionInfoW(path.c_str(), 0, sz, buf.data())) return std::wstring();
  VS_FIXEDFILEINFO* fi = nullptr;
  UINT len = 0;
  if (!VerQueryValueW(buf.data(), L"\\", reinterpret_cast<void**>(&fi), &len) || !fi) return std::wstring();
  return Fmt(L"%u.%u.%u.%u", HIWORD(fi->dwFileVersionMS), LOWORD(fi->dwFileVersionMS), HIWORD(fi->dwFileVersionLS),
             LOWORD(fi->dwFileVersionLS));
}
std::wstring TempDir() {
  wchar_t b[MAX_PATH + 2] = {0};
  DWORD n = GetTempPathW(MAX_PATH, b);
  return TrimSlash(std::wstring(b, n));
}
std::wstring Hash8(const std::wstring& s) {
  unsigned h = 2166136261u;
  for (wchar_t c : s) {
    h ^= (unsigned)c;
    h *= 16777619u;
  }
  return Fmt(L"%08x", h);
}
std::wstring UniquePath(const std::wstring& p) {
  if (!FileExists(p)) return p;
  std::wstring dir = PathDir(p), name = PathName(p), ext;
  size_t dot = name.find_last_of(L'.');
  if (dot != std::wstring::npos && dot > 0) { ext = name.substr(dot); name = name.substr(0, dot); }
  for (int i = 1; i < 1000; ++i) {
    std::wstring q = PathJoin(dir, Fmt(L"%ls (%d)%ls", name.c_str(), i, ext.c_str()));
    if (!FileExists(q)) return q;
  }
  return p;
}
int CompareVersion(const std::wstring& a, const std::wstring& b) {
  const wchar_t* p = a.c_str();
  const wchar_t* q = b.c_str();
  for (int i = 0; i < 4; ++i) {
    long x = wcstol(p, const_cast<wchar_t**>(&p), 10);
    long y = wcstol(q, const_cast<wchar_t**>(&q), 10);
    if (x != y) return x < y ? -1 : 1;
    if (*p == L'.') ++p;
    if (*q == L'.') ++q;
  }
  return 0;
}
int VersionMajor(const std::wstring& v) { return (int)wcstol(v.c_str(), nullptr, 10); }
bool ReadStream(IStream* s, std::vector<unsigned char>& out) {
  out.clear();
  if (!s) return false;
  LARGE_INTEGER zero;
  zero.QuadPart = 0;
  s->Seek(zero, STREAM_SEEK_SET, nullptr);
  unsigned char buf[65536];
  for (;;) {
    ULONG got = 0;
    HRESULT hr = s->Read(buf, sizeof(buf), &got);
    if (got) out.insert(out.end(), buf, buf + got);
    if (FAILED(hr) || got == 0) break;
  }
  return true;
}
ComPtr<IStream> MakeStream(const void* data, size_t n) {
  ComPtr<IStream> s;
  if (FAILED(CreateStreamOnHGlobal(nullptr, TRUE, s.put()))) return s;
  if (data && n) {
    ULONG w = 0;
    s->Write(data, (ULONG)n, &w);
  }
  LARGE_INTEGER zero;
  zero.QuadPart = 0;
  s->Seek(zero, STREAM_SEEK_SET, nullptr);
  return s;
}
std::wstring OriginOf(const std::wstring& url) {
  size_t k = url.find(L"://");
  if (k == std::wstring::npos) return Lower(url);
  size_t e = url.find_first_of(L"/?#", k + 3);
  std::wstring auth = url.substr(k + 3, e == std::wstring::npos ? std::wstring::npos : e - k - 3);
  size_t at = auth.rfind(L'@');  // 去掉 user:pass@，按真实主机比较
  if (at != std::wstring::npos) auth = auth.substr(at + 1);
  return Lower(url.substr(0, k + 3) + auth);
}
std::wstring HostOf(const std::wstring& url) {
  std::wstring o = OriginOf(url);
  size_t k = o.find(L"://");
  if (k != std::wstring::npos) o = o.substr(k + 3);
  size_t at = o.find(L'@');
  if (at != std::wstring::npos) o = o.substr(at + 1);
  if (!o.empty() && o[0] == L'[') {  // IPv6 地址：主机是方括号里的整段（原来取到第一个冒号为止，http://[::1]:8080 得到的是“[”）
    size_t rb = o.find(L']');
    return rb == std::wstring::npos ? o : o.substr(0, rb + 1);
  }
  size_t c = o.find(L':');
  if (c != std::wstring::npos) o = o.substr(0, c);
  return o;
}

// ---------------------------------------------------------------- JSON
const JVal* JVal::Get(const wchar_t* k) const {
  if (t != OBJ) return nullptr;
  // 重复的键取最后一个，与 JavaScript 的 JSON.parse、Python 的 json 模块一致（原来取第一个）
  for (auto it = o.rbegin(); it != o.rend(); ++it)
    if (it->first == k) return &it->second;
  return nullptr;
}
std::wstring JVal::Dump() const {
  switch (t) {
    case NUL: return L"null";
    case BOOL: return b ? L"true" : L"false";
    case NUM: return s.empty() ? Fmt(L"%g", n) : s;
    case STR: return JsonStr(s);
    case ARR: {
      std::wstring r = L"[";
      for (size_t i = 0; i < a.size(); ++i) { if (i) r += L','; r += a[i].Dump(); }
      return r + L"]";
    }
    case OBJ: {
      std::wstring r = L"{";
      for (size_t i = 0; i < o.size(); ++i) {
        if (i) r += L',';
        r += JsonStr(o[i].first);
        r += L':';
        r += o[i].second.Dump();
      }
      return r + L"}";
    }
  }
  return L"null";
}
std::wstring JVal::Text() const {
  if (t == STR) return s;
  if (t == NUL) return std::wstring();
  return Dump();
}
int JVal::Int(int def) const {
  if (t == NUM) return (int)n;
  if (t == BOOL) return b ? 1 : 0;
  if (t == STR) return (int)wcstol(s.c_str(), nullptr, 10);
  return def;
}
double JVal::Num(double def) const {
  if (t == NUM) return n;
  if (t == STR) return wcstod(s.c_str(), nullptr);
  return def;
}
namespace {
struct JParser {
  const wchar_t* p;
  const wchar_t* e;
  int depth = 0;
  void Ws() { while (p < e && (*p == L' ' || *p == L'\t' || *p == L'\r' || *p == L'\n')) ++p; }
  bool Hex4(unsigned& v) {
    if (e - p < 4) return false;
    v = 0;
    for (int i = 0; i < 4; ++i) {
      wchar_t c = *p++;
      v <<= 4;
      if (c >= L'0' && c <= L'9') v |= (unsigned)(c - L'0');
      else if (c >= L'a' && c <= L'f') v |= (unsigned)(c - L'a' + 10);
      else if (c >= L'A' && c <= L'F') v |= (unsigned)(c - L'A' + 10);
      else return false;
    }
    return true;
  }
  bool Str(std::wstring& out) {
    if (p >= e || *p != L'"') return false;
    ++p;
    out.clear();
    while (p < e) {
      wchar_t c = *p++;
      if (c == L'"') return true;
      if (c != L'\\') { out += c; continue; }
      if (p >= e) return false;
      wchar_t x = *p++;
      switch (x) {
        case L'"': out += L'"'; break;
        case L'\\': out += L'\\'; break;
        case L'/': out += L'/'; break;
        case L'b': out += L'\b'; break;
        case L'f': out += L'\f'; break;
        case L'n': out += L'\n'; break;
        case L'r': out += L'\r'; break;
        case L't': out += L'\t'; break;
        case L'u': {
          unsigned v;
          if (!Hex4(v)) return false;
          out += (wchar_t)v;
          break;
        }
        default: return false;
      }
    }
    return false;
  }
  bool Val(JVal& v) {
    if (++depth > 200) return false;
    Ws();
    if (p >= e) return false;
    wchar_t c = *p;
    bool ok = false;
    if (c == L'{') {
      v.t = JVal::OBJ;
      ++p;
      Ws();
      if (p < e && *p == L'}') { ++p; ok = true; }
      else {
        for (;;) {
          Ws();
          std::wstring k;
          if (!Str(k)) break;
          Ws();
          if (p >= e || *p != L':') break;
          ++p;
          JVal child;
          if (!Val(child)) break;
          v.o.emplace_back(std::move(k), std::move(child));
          Ws();
          if (p < e && *p == L',') { ++p; continue; }
          if (p < e && *p == L'}') { ++p; ok = true; }
          break;
        }
      }
    } else if (c == L'[') {
      v.t = JVal::ARR;
      ++p;
      Ws();
      if (p < e && *p == L']') { ++p; ok = true; }
      else {
        for (;;) {
          JVal child;
          if (!Val(child)) break;
          v.a.push_back(std::move(child));
          Ws();
          if (p < e && *p == L',') { ++p; continue; }
          if (p < e && *p == L']') { ++p; ok = true; }
          break;
        }
      }
    } else if (c == L'"') {
      v.t = JVal::STR;
      ok = Str(v.s);
    } else if (e - p >= 4 && wcsncmp(p, L"true", 4) == 0) {
      v.t = JVal::BOOL; v.b = true; p += 4; ok = true;
    } else if (e - p >= 5 && wcsncmp(p, L"false", 5) == 0) {
      v.t = JVal::BOOL; v.b = false; p += 5; ok = true;
    } else if (e - p >= 4 && wcsncmp(p, L"null", 4) == 0) {
      v.t = JVal::NUL; p += 4; ok = true;
    } else if (c == L'-' || (c >= L'0' && c <= L'9')) {
      const wchar_t* st = p;
      if (*p == L'-') ++p;
      bool digits = false;
      while (p < e && *p >= L'0' && *p <= L'9') { ++p; digits = true; }
      if (p < e && *p == L'.') { ++p; while (p < e && *p >= L'0' && *p <= L'9') ++p; }
      if (p < e && (*p == L'e' || *p == L'E')) {
        ++p;
        if (p < e && (*p == L'+' || *p == L'-')) ++p;
        while (p < e && *p >= L'0' && *p <= L'9') ++p;
      }
      if (digits) {
        v.t = JVal::NUM;
        v.s.assign(st, p);
        v.n = wcstod(v.s.c_str(), nullptr);
        ok = true;
      }
    }
    --depth;
    return ok;
  }
};
}  // namespace
bool JsonParse(const std::wstring& text, JVal& out) {
  out = JVal();
  JParser ps{text.c_str(), text.c_str() + text.size()};
  if (!ps.Val(out)) return false;
  ps.Ws();
  return ps.p == ps.e;
}

// ---------------------------------------------------------------- 线程数据：错误、返回缓冲、事件上下文
namespace {
struct Tls {
  std::string ret[4];
  int idx = 0;
  int err = 0;
  HRESULT hr = S_OK;
  std::wstring msg;
  std::vector<EventCtx*> ctx;
};
Tls& T() {
  static thread_local Tls t;
  return t;
}
}  // namespace
void SetErr(int code, const std::wstring& msg, HRESULT hr) {
  Tls& t = T();
  t.err = code;
  t.hr = hr;
  t.msg = msg;
  if (code) Log(L"错误 %d：%ls", code, msg.c_str());
}
void ClearErr() {
  Tls& t = T();
  t.err = 0;
  t.hr = S_OK;
  t.msg.clear();
}
int ErrCode() { return T().err; }
HRESULT ErrHr() { return T().hr; }
std::wstring ErrMsg() { return T().msg; }
const char* Ret(const std::string& s) {
  Tls& t = T();
  t.idx = (t.idx + 1) & 3;
  t.ret[t.idx] = s;
  return t.ret[t.idx].c_str();
}
EventCtx* CurCtx() {
  Tls& t = T();
  return t.ctx.empty() ? nullptr : t.ctx.back();
}
void PushCtx(EventCtx* c) { T().ctx.push_back(c); }
void PopCtx() {
  Tls& t = T();
  if (!t.ctx.empty()) t.ctx.pop_back();
}

// ---------------------------------------------------------------- 交给窗口的任务的编号表（见 wv_internal.h 的 TaskToken）
namespace {
struct TaskEntry {
  std::function<void()>* f;
  bool owned;
};
Lock& TaskLock() {
  static Lock l;
  return l;
}
std::map<LPARAM, TaskEntry>& TaskMap() {
  static std::map<LPARAM, TaskEntry> m;
  return m;
}
LPARAM g_taskSeq = 0;
}  // namespace
LPARAM TaskToken(std::function<void()>* f, bool owned) {
  Guard g(TaskLock());
  LPARAM t;
  do {
    g_taskSeq = (g_taskSeq + 1) & 0x3FFFFFFF;
    t = g_taskSeq;
  } while (t == 0 || TaskMap().count(t));
  TaskMap()[t] = TaskEntry{f, owned};
  return t;
}
std::function<void()>* TakeTask(LPARAM token, bool owned) {
  Guard g(TaskLock());
  auto it = TaskMap().find(token);
  if (it == TaskMap().end() || it->second.owned != owned) return nullptr;
  std::function<void()>* f = it->second.f;
  TaskMap().erase(it);
  return f;
}

// 执行投递或转交的任务。任务里的异常（例如超大的网页消息、响应内容导致内存不足）不能穿出窗口过程：外面是系统的消息分发，
// 异常穿出去进程会直接结束。WithView、WithUi 与 COM 回调原来就有同样的保护，投递的任务原来没有
void RunTask(std::function<void()>& f) noexcept {
  try {
    f();
  } catch (...) {
    try {
      Log(L"执行任务时出现异常（可能是内存不足），已跳过");
    } catch (...) {
    }
  }
}

// ---------------------------------------------------------------- 日志
// 最近的日志另在内存里留 40 条：“复制诊断信息”带上它们，没有设置日志文件时也能看到失败前后发生了什么
static Lock& LogRingLock() {
  static Lock l;
  return l;
}
static std::deque<std::wstring>& LogRing() {
  static std::deque<std::wstring> d;
  return d;
}
std::wstring LogTail(size_t maxLines) {
  Guard g(LogRingLock());
  std::wstring s;
  const size_t n = LogRing().size(), from = n > maxLines ? n - maxLines : 0;
  for (size_t i = from; i < n; ++i) s += LogRing()[i];
  return s;
}
void Log(const wchar_t* fmt, ...) {
  wchar_t body[1800];
  va_list ap;
  va_start(ap, fmt);
  int n = _vsnwprintf(body, 1799, fmt, ap);
  va_end(ap);
  if (n < 0) n = 1799;
  body[n] = 0;
  SYSTEMTIME st;
  GetLocalTime(&st);
  std::wstring line = Fmt(L"[WebView2Bridge %02u:%02u:%02u.%03u #%u] %ls\r\n", st.wHour, st.wMinute, st.wSecond, st.wMilliseconds,
                          GetCurrentThreadId(), body);
  OutputDebugStringW(line.c_str());
  {
    Guard g(LogRingLock());
    LogRing().push_back(line);
    if (LogRing().size() > 40) LogRing().pop_front();
  }
  std::wstring file;
  {
    Guard g(GLock());
    file = G().logFile;
  }
  if (file.empty()) return;
  file = AppPath(file);  // 相对路径按程序目录，与截图、下载、数据目录等一致（原来按当前目录，程序从快捷方式启动时日志会写到别处）
  static Lock fileLock;
  Guard g(fileLock);
  HANDLE h = CreateFileW(file.c_str(), FILE_APPEND_DATA | FILE_READ_ATTRIBUTES, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS,
                         FILE_ATTRIBUTE_NORMAL, nullptr);
  if (h == INVALID_HANDLE_VALUE) return;
  LARGE_INTEGER size = {};
  if (GetFileSizeEx(h, &size) && size.QuadPart == 0) {  // 新文件先写 UTF-8 BOM：Win7 的记事本遇到没有 BOM 的 UTF-8 会按 GBK 显示成乱码
    DWORD bw = 0;
    WriteFile(h, "\xEF\xBB\xBF", 3, &bw, nullptr);
  }
  std::string u = ToUtf8(line);
  DWORD w = 0;
  WriteFile(h, u.data(), (DWORD)u.size(), &w, nullptr);
  CloseHandle(h);
}

// ---------------------------------------------------------------- 保护调用桩
// int __stdcall WvSafeCallThunk(void* fn, const intptr_t* args, int n, int pad, void* scratch, int* popped)：
// 先压入 pad 个指针（依次指向 scratch 里 16 字节一个的清零槽位），再逆序压入 n 个参数后 call fn；返回后用调用前保存在 ESI 的栈指针
// 恢复 ESP，所以被调方无论按 stdcall/cdecl 清理、参数个数写多写少，都不会破坏调用方堆栈。
// 多写的参数（pad 个以内）读到的是指向清零槽位的指针：文本参数是空文本，给“参考”参数赋值只写进槽位。原来没有这些槽位，多写的参数
// 读到的是调用桩保存的寄存器与栈帧指针，给多写的“参考”参数赋值就是往任意地址写（实测进程崩溃；指向有效内存时则是静默破坏数据）。
// 被调方返回后，用调用前记在 EDI 的位置算出它从栈上弹掉的字节数写进 *popped：stdcall 回调即 4×声明的参数个数，cdecl 为 0。
// 作为裸函数编译进 DLL 的代码段：不在运行时生成代码，进程启用了禁止动态代码（ACG）时也能用，也不会被安全软件当成可疑行为
#if !defined(_M_IX86) && !defined(__i386__)
#error "WebView2Bridge 的回调保护调用桩只支持 32 位 x86"
#endif
#if defined(_MSC_VER)
extern "C" __declspec(naked) int __stdcall WvSafeCallThunk(void*, const intptr_t*, int, int, void*, int*) {
  __asm {
    push ebp
    mov ebp, esp
    push esi
    push edi
    mov esi, esp
    mov ecx, [ebp + 20]
    mov eax, [ebp + 24]
    shl ecx, 4
    add eax, ecx
    mov ecx, [ebp + 20]
  next_pad:
    test ecx, ecx
    jz pad_done
    sub eax, 16
    push eax
    dec ecx
    jmp next_pad
  pad_done:
    mov ecx, [ebp + 16]
    mov edx, [ebp + 12]
  next_arg:
    test ecx, ecx
    jz do_call
    push dword ptr [edx + ecx * 4 - 4]
    dec ecx
    jmp next_arg
  do_call:
    mov edi, esp
    call dword ptr [ebp + 8]
    mov ecx, esp
    sub ecx, edi
    mov edx, [ebp + 28]
    test edx, edx
    jz no_out
    mov [edx], ecx
  no_out:
    mov esp, esi
    pop edi
    pop esi
    pop ebp
    ret 24
  }
}
#else
extern "C" __attribute__((naked, noinline)) int __stdcall WvSafeCallThunk(void*, const intptr_t*, int, int, void*, int*) {
  __asm__ volatile(
      "pushl %ebp\n\t"
      "movl %esp, %ebp\n\t"
      "pushl %esi\n\t"
      "pushl %edi\n\t"
      "movl %esp, %esi\n\t"
      "movl 20(%ebp), %ecx\n\t"
      "movl 24(%ebp), %eax\n\t"
      "shll $4, %ecx\n\t"
      "addl %ecx, %eax\n\t"
      "movl 20(%ebp), %ecx\n"
      "3:\n\t"
      "testl %ecx, %ecx\n\t"
      "jz 4f\n\t"
      "subl $16, %eax\n\t"
      "pushl %eax\n\t"
      "decl %ecx\n\t"
      "jmp 3b\n"
      "4:\n\t"
      "movl 16(%ebp), %ecx\n\t"
      "movl 12(%ebp), %edx\n"
      "1:\n\t"
      "testl %ecx, %ecx\n\t"
      "jz 2f\n\t"
      "pushl -4(%edx,%ecx,4)\n\t"
      "decl %ecx\n\t"
      "jmp 1b\n"
      "2:\n\t"
      "movl %esp, %edi\n\t"
      "call *8(%ebp)\n\t"
      "movl %esp, %ecx\n\t"
      "subl %edi, %ecx\n\t"
      "movl 28(%ebp), %edx\n\t"
      "testl %edx, %edx\n\t"
      "jz 5f\n\t"
      "movl %ecx, (%edx)\n"
      "5:\n\t"
      "movl %esi, %esp\n\t"
      "popl %edi\n\t"
      "popl %esi\n\t"
      "popl %ebp\n\t"
      "ret $24\n\t");
}
#endif
int SafeCall(void* fn, const intptr_t* args, int n, int* popped) {
  if (popped) *popped = 0;
  if (!fn) return 0;
  // 多写的参数指向的清零槽位（在本函数的栈帧里，被调方的栈帧在它下面，不会重叠），后面跟 kSafeCallTail 字节清零余量：
  // 原来只有槽位，最后几个槽位上的“参考”参数若是大于 16 字节的自定义数据类型，整段赋值会写到槽位外面，破坏本函数的栈帧
  unsigned char scratch[kSafeCallPad * 16 + kSafeCallTail] = {};
  int got = 0;
  const int r = WvSafeCallThunk(fn, args, n, kSafeCallPad, scratch, &got);
  if (popped) *popped = got;
  return r;
}

// ---------------------------------------------------------------- 回调参数表检查与开发期说明
namespace {
struct Mismatch {
  int ev, declaredBytes, expected;
};
Lock& MisLock() {
  static Lock l;
  return l;
}
std::vector<Mismatch>& MisList() {
  static std::vector<Mismatch> v;
  return v;
}
std::set<std::pair<void*, int>>& MisSeen() {
  static std::set<std::pair<void*, int>> s;
  return s;
}
std::set<std::wstring>& NoticeSeen() {
  static std::set<std::wstring> s;
  return s;
}
// 事件名与回调参数表（与 wv2bridge.h 的 WVE_ 说明、类_WebView2 的“事件_”方法一致；下标 0 是 执行JS_异步 的回调）
const wchar_t* const kEvName[WVE_MAX + 1] = {
    L"执行JS_异步", L"事件“创建完成”", L"事件“将要跳转”", L"事件“加载完成”", L"事件“网址改变”", L"事件“标题改变”", L"事件“DOM就绪”",
    L"事件“收到消息”", L"事件“新窗口”", L"事件“下载开始”", L"事件“下载进度”", L"事件“下载完成”", L"事件“权限请求”", L"事件“进程崩溃”",
    L"事件“全屏改变”", L"事件“请求关闭”", L"事件“按键”", L"事件“图标改变”", L"事件“状态栏改变”", L"事件“声音状态”", L"事件“对话框”",
    L"事件“认证”", L"事件“拦截请求”", L"事件“收到响应”", L"事件“CDP”", L"事件“缩放改变”", L"事件“历史改变”", L"事件“证书错误”",
    L"绑定函数（或事件“JS调用”）"};
const wchar_t* const kEvSig[WVE_MAX + 1] = {
    L"浏览器句柄, 用户数据, 是否成功, 结果",
    L"浏览器句柄, 是否成功",
    L"浏览器句柄, 网址, 用户发起, 是重定向, 取消（参考）",
    L"浏览器句柄, 网址, 是否成功, HTTP状态码, 错误码",
    L"浏览器句柄, 网址",
    L"浏览器句柄, 标题",
    L"浏览器句柄, 网址",
    L"浏览器句柄, 文本, JSON, 来源网址",
    L"浏览器句柄, 网址, 用户发起, 处理方式（参考）",
    L"浏览器句柄, 下载ID, 网址, 保存路径, 取消（参考）",
    L"浏览器句柄, 下载ID, 百分比, 已下载KB, 总KB",
    L"浏览器句柄, 下载ID, 结果, 保存路径",
    L"浏览器句柄, 网址, 权限类型, 状态（参考）",
    L"浏览器句柄, 进程类型, 原因",
    L"浏览器句柄, 是否全屏",
    L"浏览器句柄",
    L"浏览器句柄, 虚拟键码, 类型, 修饰键, 已处理（参考）",
    L"浏览器句柄, 图标网址",
    L"浏览器句柄, 文本",
    L"浏览器句柄, 正在播放, 已静音",
    L"浏览器句柄, 类型, 消息, 网址, 确定（参考）",
    L"浏览器句柄, 网址, 认证说明, 取消（参考）",
    L"浏览器句柄, 网址, 方法, 资源类型, 动作（参考）",
    L"浏览器句柄, 网址, 状态码, 方法, 内容长度",
    L"浏览器句柄, 事件名, 参数JSON",
    L"浏览器句柄, 缩放百分比",
    L"浏览器句柄, 能后退, 能前进",
    L"浏览器句柄, 网址, 错误码, 动作（参考）",
    L"浏览器句柄, 函数名, 参数JSON, 调用ID"};
}  // namespace

const wchar_t* EventName(int ev) { return ev >= 0 && ev <= WVE_MAX ? kEvName[ev] : L"回调"; }

void (*g_devNoticeHook)(const std::wstring&) = nullptr;

bool DevNotice(const std::wstring& key, const std::wstring& text) {
  if (DevChecks().load() != 1) return false;  // 2：只检查、写日志，不弹出
  if (!key.empty()) {
    Guard g(MisLock());
    if (!NoticeSeen().insert(key).second) return false;
  }
  if (g_devNoticeHook) {
    g_devNoticeHook(text);
    return true;
  }
  HWND d = Dispatcher().load();
  if (!d) return false;
  // 投递给调度窗口，在当前的事件处理与等待之外显示
  auto* p = new std::function<void()>([text]() {
    MessageBoxW(nullptr, text.c_str(), L"WebView2Bridge 开发期检查", MB_ICONWARNING | MB_OK | MB_TASKMODAL | MB_SETFOREGROUND);
  });
  const LPARAM tok = TaskToken(p, true);
  if (!PostMessageW(d, WM_WV_TASK, 0, tok)) {
    TakeTask(tok, true);
    delete p;
    return false;
  }
  return true;
}

// 1.8.2：把任务投递到界面线程的调度窗口，执行后立即返回（堆上任务，接收方执行后释放，与开发期检查说明框同一机制）
bool PostToUi(std::function<void()> fn) {
  HWND d = Dispatcher().load();
  if (!d || !IsWindow(d)) return false;
  auto* p = new std::function<void()>(std::move(fn));
  const LPARAM tok = TaskToken(p, true);
  if (!PostMessageW(d, WM_WV_TASK, 0, tok)) {
    TakeTask(tok, true);
    delete p;
    return false;
  }
  return true;
}

void ReportCallbackMismatch(int viewId, int ev, void* fn, int poppedBytes, int expectedArgs, bool outPassed) {
  const bool legacyOut = outPassed && poppedBytes == 4 * (expectedArgs + 1);
  {
    Guard g(MisLock());
    if (!MisSeen().insert(std::make_pair(fn, ev)).second) return;  // 同一个回调子程序在同一事件上只报一次
    if (MisList().size() < 32) MisList().push_back(Mismatch{ev, poppedBytes, expectedArgs});
  }
  const bool known = ev >= 0 && ev <= WVE_MAX;
  const wchar_t* name = ev == -1 ? L"回调转发（WVO_CALLBACK_HOOK）" : known ? kEvName[ev] : L"回调";
  std::wstring sig = ev == -1 ? L"回调地址, 事件号, 参数个数, 参数数组地址, 文本掩码" : known ? kEvSig[ev] : L"";
  std::wstring hint;
  if (known && ev > 0) {  // 按 WVE_FLAG_NO_OUT 注册的回调（易语言类的事件）没有最后的“参考”参数：只列出应有的前几个参数，并说明怎样回填结果
    std::vector<std::wstring> parts;
    for (size_t s = 0;;) {
      const size_t e = sig.find(L", ", s);
      parts.push_back(sig.substr(s, e == std::wstring::npos ? std::wstring::npos : e - s));
      if (e == std::wstring::npos) break;
      s = e + 2;
    }
    if (expectedArgs >= 1 && expectedArgs < (int)parts.size()) {
      sig.clear();
      for (int i = 0; i < expectedArgs; ++i) sig += (i ? L", " : L"") + parts[(size_t)i];
      hint = L"回调的参数都是只读的，要回填结果请在回调里调用 回调_置取消 () 或 回调_置结果 ()（C/C++：WV_EvSetInt (WVK_CANCEL / WVK_RESULT)）。";
    }
  }
  // 旧写法（照旧写了最后的“参考”参数）：这个参数照样收到回填结果的地址，写成“参考”时赋值仍然有效，只是提示改成新写法
  const std::wstring msg =
      legacyOut ? Fmt(L"%ls的回调子程序多写了最后一个参数（以前的写法）：应为 %d 个参数（%ls）。写成“参考”参数时给它赋值仍然有效，"
                      L"没写“参考”时赋值不起作用。%ls请删掉这个参数（浏览器 #%d）",
                      name, expectedArgs, sig.c_str(), hint.c_str(), viewId)
                : Fmt(L"%ls的回调子程序参数表不对：应为 %d 个参数（%ls），实际声明的参数共 %d 字节（相当于 %d 个整数型参数）。"
                      L"%ls多写的参数收到的是指向空数据的指针：文本参数是空文本，“参考”参数读到 0、给它赋值无效，按值传递的数值参数是一个无意义的数；"
                      L"少写的参数收不到对应的值。%ls请按事件说明改正（浏览器 #%d）",
                      name, expectedArgs, sig.c_str(), poppedBytes, poppedBytes / 4,
                      outPassed && poppedBytes > 4 * expectedArgs ? L"多写的第一个参数是回填结果的地址（写成“参考”参数时给它赋值有效），其余" : L"",
                      hint.c_str(), viewId);
  Log(L"%ls", msg.c_str());
  DevNotice(std::wstring(), msg);
}

std::wstring CheckStatsJson() {
  std::wstring r = L"{\"devChecks\":" + std::to_wstring(DevChecks().load()) + L",\"encodingFallback\":" + std::to_wstring(g_encFallback.load()) +
                   L",\"encodingSuspect\":" + std::to_wstring(g_encSuspect.load()) + L",\"threadTimeouts\":" + std::to_wstring(g_threadTimeouts.load()) +
                   L",\"callbackMismatch\":[";
  Guard g(MisLock());
  bool first = true;
  for (const auto& m : MisList()) {
    if (!first) r += L",";
    first = false;
    r += L"{\"event\":" + std::to_wstring(m.ev) + L",\"declaredBytes\":" + std::to_wstring(m.declaredBytes) + L",\"expected\":" +
         std::to_wstring(m.expected) + L"}";
  }
  return r + L"]}";
}

// ---------------------------------------------------------------- 消息泵（同步等待时保持界面响应）
int& HandlerDepth() {
  static thread_local int depth = 0;
  return depth;
}

const wchar_t* ReentrantText() {
  return L"不能在“将要跳转”“按键”事件的回调里调用需要等待结果的方法（WebView2 不支持在它的事件处理中嵌套等待）。"
         L"请改用 执行JS_异步，或者先记下要做的事，等事件结束后再处理";
}

bool ValidProxy(const std::wstring& proxy) {
  for (wchar_t ch : proxy)
    if (iswspace(ch) || ch == L'"' || ch == L'\'' || ch < 0x20) return false;
  return true;
}

bool ParseBgColor(const std::wstring& s, unsigned& argb) {
  if (_wcsicmp(s.c_str(), L"transparent") == 0) {
    argb = 0;
    return true;
  }
  if ((s.size() != 7 && s.size() != 9) || s[0] != L'#') return false;
  for (size_t i = 1; i < s.size(); ++i)
    if (!((s[i] >= L'0' && s[i] <= L'9') || (s[i] >= L'a' && s[i] <= L'f') || (s[i] >= L'A' && s[i] <= L'F'))) return false;
  argb = (unsigned)wcstoul(s.c_str() + 1, nullptr, 16) | (s.size() == 7 ? 0xFF000000u : 0u);
  return true;
}

HMODULE LoadSystemDll(const wchar_t* name) {
  HMODULE h = GetModuleHandleW(name);
  if (h) return h;
  wchar_t dir[MAX_PATH] = {0};
  UINT n = GetSystemDirectoryW(dir, MAX_PATH);
  if (n == 0 || n >= MAX_PATH) return nullptr;
  return LoadLibraryExW((std::wstring(dir) + L"\\" + name).c_str(), nullptr, LOAD_WITH_ALTERED_SEARCH_PATH);
}

int& WaitDepth() {
  static thread_local int depth = 0;
  return depth;
}

bool CanWait() {
  if (HandlerDepth() > 0) {
    SetErr(WVERR_REENTRANT, ReentrantText());
    return false;
  }
  if (WaitDepth() >= kMaxWaitDepth) {
    SetErr(WVERR_REENTRANT, Fmt(L"同步等待已经嵌套了 %d 层：等待期间界面照常处理消息，计时器、按钮在等待中又调用了需要等待的方法，一层套一层。"
                                L"请避免在等待中重复进入（例如计时器触发时先停用它、等方法返回后再启用），或改用 执行JS_异步",
                                kMaxWaitDepth));
    return false;
  }
  return true;
}

bool PumpUntil(const std::function<bool()>& done, DWORD timeoutMs) {
  if (HandlerDepth() > 0) return done();  // 处理函数里嵌套的消息循环收不到 WebView2 的回调，等也没有用
  struct DepthScope {
    DepthScope() { ++WaitDepth(); }
    ~DepthScope() { --WaitDepth(); }
  } depthScope;
  DWORD start = GetTickCount();
  while (!done()) {
    DWORD elapsed = GetTickCount() - start;
    if (elapsed >= timeoutMs) return done();
    DWORD left = timeoutMs - elapsed;
    MsgWaitForMultipleObjectsEx(0, nullptr, left < 50 ? left : 50, QS_ALLINPUT, MWMO_INPUTAVAILABLE);
    MSG msg;
    while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
      if (msg.message == WM_QUIT) {
        PostQuitMessage((int)msg.wParam);
        return done();
      }
      TranslateMessage(&msg);
      DispatchMessageW(&msg);
      if (done()) return true;
    }
  }
  return true;
}

}  // namespace wv
