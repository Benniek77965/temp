// Authenticode 签名者名称：读取文件内嵌签名中签名者证书的名称。
// 只负责读取，不判断证书是否可信（可信与否由 WinVerifyTrust 判断）。
// 写成头文件内的函数，DLL 与测试程序共用同一份代码。所需的 crypt32 函数动态取得，不增加导入表依赖。
#pragma once
#include <windows.h>
#include <wincrypt.h>
#include <string>
#include <vector>

namespace wvsign {
inline std::wstring AuthenticodeSigner(const std::wstring& file, HMODULE crypt32) {
  typedef BOOL(WINAPI * QueryFn)(DWORD, const void*, DWORD, DWORD, DWORD, DWORD*, DWORD*, DWORD*, HCERTSTORE*, HCRYPTMSG*, const void**);
  typedef BOOL(WINAPI * ParamFn)(HCRYPTMSG, DWORD, DWORD, void*, DWORD*);
  typedef BOOL(WINAPI * MsgCloseFn)(HCRYPTMSG);
  typedef PCCERT_CONTEXT(WINAPI * FindFn)(HCERTSTORE, DWORD, DWORD, DWORD, const void*, PCCERT_CONTEXT);
  typedef DWORD(WINAPI * NameFn)(PCCERT_CONTEXT, DWORD, DWORD, void*, LPWSTR, DWORD);
  typedef BOOL(WINAPI * FreeFn)(PCCERT_CONTEXT);
  typedef BOOL(WINAPI * StoreCloseFn)(HCERTSTORE, DWORD);
  if (!crypt32) return std::wstring();
#define WVSIGN_FN(type, var, name) type var = reinterpret_cast<type>(reinterpret_cast<void*>(GetProcAddress(crypt32, name)))
  WVSIGN_FN(QueryFn, query, "CryptQueryObject");
  WVSIGN_FN(ParamFn, param, "CryptMsgGetParam");
  WVSIGN_FN(MsgCloseFn, msgClose, "CryptMsgClose");
  WVSIGN_FN(FindFn, find, "CertFindCertificateInStore");
  WVSIGN_FN(NameFn, getName, "CertGetNameStringW");
  WVSIGN_FN(FreeFn, freeCert, "CertFreeCertificateContext");
  WVSIGN_FN(StoreCloseFn, storeClose, "CertCloseStore");
#undef WVSIGN_FN
  if (!query || !param || !msgClose || !find || !getName || !freeCert || !storeClose) return std::wstring();
  DWORD enc = 0, content = 0, format = 0;
  HCERTSTORE store = nullptr;
  HCRYPTMSG msg = nullptr;
  if (!query(CERT_QUERY_OBJECT_FILE, file.c_str(), CERT_QUERY_CONTENT_FLAG_PKCS7_SIGNED_EMBED, CERT_QUERY_FORMAT_FLAG_BINARY, 0,
             &enc, &content, &format, &store, &msg, nullptr))
    return std::wstring();
  std::wstring result;
  DWORD size = 0;
  if (param(msg, CMSG_SIGNER_INFO_PARAM, 0, nullptr, &size) && size) {
    std::vector<BYTE> buf(size);
    CMSG_SIGNER_INFO* si = reinterpret_cast<CMSG_SIGNER_INFO*>(buf.data());
    if (param(msg, CMSG_SIGNER_INFO_PARAM, 0, si, &size)) {
      CERT_INFO ci;
      ZeroMemory(&ci, sizeof(ci));
      ci.Issuer = si->Issuer;
      ci.SerialNumber = si->SerialNumber;
      PCCERT_CONTEXT cert = find(store, X509_ASN_ENCODING | PKCS_7_ASN_ENCODING, 0, CERT_FIND_SUBJECT_CERT, &ci, nullptr);
      if (cert) {
        wchar_t n[256] = {0};
        if (getName(cert, CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, nullptr, n, 256) > 1) result = n;
        freeCert(cert);
      }
    }
  }
  if (store) storeClose(store, 0);
  if (msg) msgClose(msg);
  return result;
}
}  // namespace wvsign
