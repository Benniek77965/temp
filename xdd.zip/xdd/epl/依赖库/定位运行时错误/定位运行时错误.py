# -*- coding: utf-8 -*-
"""
定位运行时错误.py —— 把易语言运行时错误框里的「(子程序ID,位置)」换算成源码里的子程序与行。

易语言 5.8 及以上编译出的程序，数组下标越界等检查失败时调用核心库的报错函数，
参数为（错误号, 子程序ID, 位置）：例如「数组成员引用下标必须大于等于1 (67183002,45822)」
中 67183002＝0x0401219A 是出错子程序的内部 ID（高 8 位 0x04 表示子程序），
45822 是出错的那个表达式在该子程序代码数据（ExpressionData）中的偏移，本工具据此找到所在语句。
（以上都已用一个真实的易语言编译程序与其源码、所用模块逐条核对：数组越界类错误的位置全部落在
 含数组下标的语句里，同一函数里的检查都带它自己的 ID。）
（错误号 0 的库命令错误，如「不能求余数于零 (0,0)」，错误文本里没有位置；这时用运行时出错诊断框
 「调用栈」里地址后面附带的〔子程序ID 0x…〕运行本工具，那是从所在函数机器码里推断出来的。）

用法（Python 3.8+，无第三方依赖）：
  python 定位运行时错误.py <出错版本的 .e 工程文件> <子程序ID> <位置> [--txt <导出的文本工程根目录>]
  python 定位运行时错误.py <.e 文件> <子程序ID> [--txt <导出的文本工程根目录>]
                                                     只给 ID（如从诊断框调用栈里推断出的 ID）：查子程序名，
                                                     加 --txt 时列出其中含 求余数/整除 与数组下标的语句
  python 定位运行时错误.py <.e 文件> --list            列出全部子程序的 ID 与名称
  python 定位运行时错误.py --对比编号 <甲.e> <乙.e>      对比两份 .e 里同名子程序的 ID 是否相同（见第 1 条）
  python 定位运行时错误.py --exe <exe 文件> [更多 exe…]  读出 exe 的编译时间（PE 时间戳），与诊断框里的
                                                     「编译时间」对照，认出出错的是哪一次编译、该用哪一份 .e
  python 定位运行时错误.py <出错版本的 .e> <子程序ID> [<位置>] --exe <出错版本加壳前的 exe> --模块 <模块 .e 或 .ec>… [--详细]
                                                     模块文件写「自动」：按主工程 .e 里记下的、编译时用的那些 .ec（推荐）；
                                                     再加 --源码 <模块源码 .e>…：.ec 里名称被隐去的子程序按代码形状在源码里认出名称
                                                     ID 是编译时给模块子程序的编号时，校准出是哪个模块的哪个子程序（见第 3 条）；
                                                     严格校准对不上（或加了 --详细）时，自动放宽条件再查一遍并说明原因（见第 5 条）
  python 定位运行时错误.py --核对 <exe> <诊断框全文.txt 或 exe+0x…=0x…>…
                                                     用诊断框调用栈里的「exe+0x…〔子程序ID 0x…〕」核对手上的 exe 与出错的 exe
                                                     是不是同一次编译（按与诊断框相同的算法从这个 exe 里读出各地址的子程序 ID）；
                                                     地址对不上时再看那些编号在这个 exe 里还在不在：都在＝只是代码挪了位置、编号没变，
                                                     仍可用来按编号校准；不在了＝编号有变化。
                                                     诊断框全文里的「PE 时间戳」与这个 exe 相同＝同一次编译：这时诊断框推断不出、
                                                     这个 exe 推断得出的地方是加壳造成的，其余对不上的多半是诊断框全文抄错了
  python 定位运行时错误.py --调用 <exe> <诊断框全文.txt 或 exe+0x…>…
                                                     对每个返回地址列出上一条 call 调用了谁：易语言子程序写出 ID，调用桩写出
                                                     开头几条指令，间接 call 写出函数地址从哪里来（导入表里的 API 写出名称）
  python 定位运行时错误.py <模块源码 .e> --名称 <类名.子程序名> <位置> [--txt <该模块导出的文本目录>]
                                                     按名称在某个 .e 里定位
  子程序ID 可写十进制（67183002）或十六进制（0x0401219A）；从诊断框连带括号、「子程序ID」等字样复制过来也能读出。

注意：
  1. 编号是否稳定，取决于 .e 是怎么来的：
     ① 在易语言里直接编辑 .e：主工程子程序的 ID 创建时分配，之后改代码、改名都不变（删除后重建、剪切后粘贴、
        移到别的程序集会换新 ID）。用改过的 .e 也能按 ID 查到子程序，只有「位置」会随改动偏移。
     ② 用文本转换工具从文本重新生成 .e：文本里不保存 ID，全部 ID 会重新编排（TextECode 的源码已核实；本工程的
        文本是 e2txt 生成的格式，e2txt 不开源，但从开源工具调用它的方式看，文本转 .e 时只给文本目录与输出路径、
        不参照原 .e，原 .e 里删过的实体留下的编号空缺文本里也没有记录，所以原来的编号无从还原）。这时必须用出错
        那次编译所用的 .e，或用同一份文本、同一个工具版本重新生成的 .e。
     确认办法：把同一份 .e 转成文本再转回 .e，对两份 .e 运行 --对比编号，看同名子程序的 ID 是否相同；同一份文本
     转两次再对比应完全相同，说明转换结果是固定的。
     工具会帮着核对版本：位置不是这一版代码里任何表达式的起点、或数组下标类错误落在没有数组下标的语句上，都会提醒。
     大于出错版本当时已分配最大编号的 ID 是模块子程序的编号（见第 3 条）；用较新的 .e 查这种 ID，它可能已被后来
     新建的子程序占用，所以也须用出错的那一版 .e。代码改过时加 --txt 会列出该子程序（当前版本）里全部带数组下标
     的语句，供逐条排查。
     建议每次发版把编译所用的 .e、文本工程的版本与 exe 一起存档（至少对编译所用的 .e 运行一次 --list，把 ID 表
     存档）；诊断框里有「编译时间」，用 --exe 读出存档 exe 的编译时间即可对上是哪一版。
  2. 有密码的 .e 请先在易语言里另存为无密码副本再用。
  3. 模块（.ec）里的子程序：编译时另行编号——编号大于主工程已分配的最大编号，每个模块的子程序按模块文件里的
     先后顺序连续编号（已用真实的编译程序、其主工程 .e 与所用模块逐一核对）。主工程 .e「易模块记录段」里给模块
     子程序的那段编号只是占位，编译出的程序不用它。所以报出的 ID 若大于主工程已分配的最大编号（工具会提示），
     就是某个模块里的子程序：再给出出错版本加壳前的 exe（--exe）和各模块的源码 .e（--模块），工具用 exe 里
     每个子程序的运行时检查校准出各模块的起始编号（检查报出的位置一定恰好是该子程序某个表达式的起点，已核对），
     查到是哪个模块的哪个子程序（模块源码 .e 带行偏移时还能定位到语句）。证据明显占优时标为「结果可信」；
     exe 里该模块带检查的子程序太少时不能唯一确定，工具按相符个数列出几种可能，请结合出错现象判断。
  4. 给出 --txt 时，按同名程序集与子程序在导出的文本里数到对应行并打印出来；
     文本须与 .e 为同一版本，否则行可能对不上（以 .e 里的语句序号为准）。
  5. 模块校准原来要求：一个模块范围内 exe 里全部带检查的子程序都与模块文件对得上，并且编号按模块文件里子程序表的
     先后。模块文件与编进 exe 的 .ec 有个别子程序不同、模块引入了别的模块（文件里有只带名称的占位子程序）、或编号
     按的是程序集的先后，整个模块就会落空，只报「都对不上」。这时工具自动放宽条件再查一遍：按检查位置找出能对上的
     子程序给起始编号投票，逐种试「文件顺序」「去掉占位」「按程序集顺序」「按内部编号」，列出每个模块的最佳对位
     （相符、不符、缺号的个数）、目标编号可能对应的子程序（不符与缺号极少的标为可信），以及没有任何模块能覆盖的
     编号段（多半是还有模块没列上）。目标编号在这个 exe 里根本没有检查时会明说：多半拿错了 exe，先用 --核对 确认。

自测（一次即可；要用编译出的 exe 运行，在易语言里调试运行时错误由 IDE 接管，不走诊断框）：
  在测试版里临时加一个按钮，被单击事件写成下面这样。注意三点：①不要用 调试输出 包着测试语句——它只在调试版里
  执行，编译出的 exe 里会被整句跳过；②下标与除数用变量更稳妥（常量可能被编译器提前处理）；③函数里要有一处
  用变量下标的数组访问，编译出的代码里才有带本子程序 ID 的运行时检查，诊断框才推断得出 ID。
    .局部变量 局_数组, 整数型, , "0"
    .局部变量 局_零, 整数型
    .局部变量 局_一, 整数型
    .局部变量 局_结果, 整数型
    重定义数组 (局_数组, 假, 1)
    赋值 (局_零, 0)
    赋值 (局_一, 1)
    赋值 (局_数组[局_一], 1)
    赋值 (局_结果, 求余数 (1, 局_零))     ' 第一次测这一行：「不能求余数于零」
    ' 赋值 (局_结果, 局_数组[局_零])    ' 第二次改测这一行：「数组成员引用下标必须大于等于1」
    信息框 (到文本 (局_结果), 0, )
  第一次看诊断框「调用栈」里附带的〔子程序ID 0x…〕，用本工具对这一版的 .e 运行，应查到这个被单击事件；
  第二次看「出错位置：子程序 0x…，位置 …」，用本工具应查到这个被单击事件与那一行。
  诊断框里的「编译时间」应与 --exe 对这个 exe 读出的一致。若把同样的代码放进一个测试模块里测，报出的是编译时给
  模块子程序的编号（大于主工程已分配的最大编号），按第 3 条加 --exe 与 --模块 查。
"""
import bisect
import os
import re
import struct
import sys

CODE_SECTION_KEY = 0x03007319
END_SECTION_KEY = 0x07007319


class Reader:
    def __init__(self, data, pos=0):
        self.d = data
        self.p = pos

    def i32(self):
        v = struct.unpack_from('<i', self.d, self.p)[0]
        self.p += 4
        return v

    def u16(self):
        v = struct.unpack_from('<H', self.d, self.p)[0]
        self.p += 2
        return v

    def i16(self):
        v = struct.unpack_from('<h', self.d, self.p)[0]
        self.p += 2
        return v

    def u8(self):
        v = self.d[self.p]
        self.p += 1
        return v

    def bytes(self, n):
        if n < 0 or self.p + n > len(self.d):
            raise ValueError('数据越界：位置 %d 长度 %d' % (self.p, n))
        v = self.d[self.p:self.p + n]
        self.p += n
        return v

    def lenbytes(self):
        return self.bytes(self.i32())

    def lenstr(self):
        b = self.lenbytes()
        z = b.find(b'\0')
        if z != -1:
            b = b[:z]
        return b.decode('gbk', errors='replace')

    def i32s_bytesize(self):
        n = self.i32()
        return [self.i32() for _ in range(n // 4)]

    def i16s_bytesize(self):
        n = self.i32()
        return [self.i16() for _ in range(n // 2)]

    def mfc_strings(self):
        c = self.u16()
        if c == 0xFFFF:
            c = self.i32()
        return [self.lenstr() for _ in range(c)]


def read_sections(data):
    if data[:4] == b'WTLE':
        raise SystemExit('这是加了密码的 .e：请在易语言里另存为无密码副本后再运行本工具。')
    if data[:8] != b'CNWTEPRG':
        raise SystemExit('不是易语言工程文件（.e）。')
    r = Reader(data, 8)
    sections = {}
    while r.p < len(data):
        if r.i32() != 0x15117319:
            raise SystemExit('段头标记错误：文件可能已损坏。')
        r.i32()  # 信息校验
        key = r.i32()
        r.bytes(30)  # 段名（加扰）
        r.i16()
        r.i32()  # 序号
        r.i32()  # 可选
        r.i32()  # 数据校验
        n = r.i32()
        r.bytes(40)
        sections[key] = r.bytes(n)
        if key == END_SECTION_KEY:
            break
    return sections


def skip_blocks_with_id_and_offset(r):
    count = r.i32()
    size = r.i32()
    r.p += size
    return count


def read_blocks_with_id_and_address(r, fn):
    header = r.i32()
    count = header // 8
    ids = [r.i32() for _ in range(count)]
    [r.i32() for _ in range(count)]  # 内存地址
    return [fn(r, ids[i]) for i in range(count)]


def parse_code_section(data):
    r = Reader(data)
    r.i32()  # AllocatedIdNum
    r.i32()
    r.i32s_bytesize()
    r.i16s_bytesize()
    r.i16s_bytesize()
    r.mfc_strings()  # 支持库
    flag = r.i32()
    r.i32()  # MainMethod
    if flag & 1:
        r.bytes(16)
    r.lenbytes()  # 图标
    r.lenstr()  # 调试命令行

    def read_class(rr, cid):
        rr.i32()  # 窗口
        rr.i32()  # 基类
        name = rr.lenstr()
        rr.lenstr()  # 备注
        mids = [rr.i32() for _ in range(rr.i32() // 4)]
        skip_blocks_with_id_and_offset(rr)
        return {'id': cid, 'name': name, 'methods': mids}

    def read_method(rr, mid):
        cls = rr.i32()
        rr.i32()  # 标志
        rr.i32()  # 返回类型
        name = rr.lenstr()
        rr.lenstr()  # 备注
        skip_blocks_with_id_and_offset(rr)  # 局部变量
        skip_blocks_with_id_and_offset(rr)  # 参数
        line_off = rr.lenbytes()
        rr.lenbytes()  # BlockOffest
        rr.lenbytes()  # MethodReference
        rr.lenbytes()  # VariableReference
        rr.lenbytes()  # ConstantReference
        expr = rr.lenbytes()
        return {'id': mid, 'class': cls, 'name': name,
                'lines': [struct.unpack_from('<i', line_off, i * 4)[0] for i in range(len(line_off) // 4)],
                'expr_len': len(expr), 'expr': expr}

    classes = read_blocks_with_id_and_address(r, read_class)
    methods = read_blocks_with_id_and_address(r, read_method)
    return classes, methods


EC_DEP_SECTION_KEY = 0x0C007319


def parse_ec_dependencies(data):
    """易模块记录段：每个引入的模块在主工程 ID 空间里占的 ID 段（带类型的起始 ID 与个数）。"""
    r = Reader(data)
    n = r.i32()
    recs = []
    for _ in range(n):
        ver = r.i32()
        r.i32()  # 文件尺寸
        r.bytes(8)  # 文件时间
        if ver >= 2:
            r.i32()
        name = r.lenstr()
        path = r.lenstr()
        starts = r.i32s_bytesize()
        counts = r.i32s_bytesize()
        recs.append({'name': name, 'path': path, 'ranges': [(a, c) for a, c in zip(starts, counts) if c > 0]})
    return recs


def module_of_id(recs, mid):
    t = mid & 0xFF000000
    num = mid & 0x00FFFFFF
    for rec in recs:
        for a, c in rec['ranges']:
            if (a & 0xFF000000) == t and (a & 0x00FFFFFF) <= num < (a & 0x00FFFFFF) + c:
                return rec
    return None


NOT_IN_LINE_OFFSET = ('.如果真结束', '.如果结束', '.否则', '.默认', '.判断结束')


def counts_as_statement(text_line):
    """导出文本的这一行在代码数据里有没有行偏移：块结束、否则、默认这几种行没有（被屏蔽的块写成「' .如果真结束」，同样没有）。"""
    t = text_line.strip()
    if t.startswith("' "):
        t = t[2:].strip()
    return t not in NOT_IN_LINE_OFFSET


def decode_text(raw):
    """导出文本的编码：有 BOM 按 BOM；否则先按 UTF-8 严格解码，不成再按 GBK（e2txt 按 ANSI 导出时就是 GBK）。"""
    if raw[:3] == b'\xef\xbb\xbf':
        return raw[3:].decode('utf-8', errors='replace')
    if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return raw.decode('utf-16', errors='replace')
    try:
        return raw.decode('utf-8')
    except UnicodeDecodeError:
        return raw.decode('gbk', errors='replace')


def read_text_lines(path):
    """按行读导出的文本（编码见 decode_text）。只按换行符分行：str.splitlines 还会在 U+2028、\\x1c 等字符处断行，
    注释或字符串里若出现这些字符，会把一条语句拆成两行、数错语句序号。"""
    text = decode_text(open(path, 'rb').read())
    lines = text.split('\r\n') if '\r\n' in text else text.split('\n')
    if lines and lines[-1] == '':
        lines.pop()
    return lines


DECL_PREFIXES = ('.子程序 ', '.程序集 ', '.程序集变量 ', '.全局变量 ', '.数据类型 ', '.DLL命令 ', '.常量 ', '.版本 ')


def _method_statements(lines, i):
    """lines[i] 是「.子程序 …」：返回该子程序按行偏移规则编号的语句 [(语句序号, 行号, 文本)]。
    e2txt 导出时，声明与代码之间、子程序与下一个声明之间各有一行分隔空行，它们不是语句。"""
    j = i + 1
    while j < len(lines) and re.match(r'\s*\.(参数|局部变量) ', lines[j]):
        j += 1
    if j < len(lines) and lines[j].strip() == '':
        j += 1  # 声明与代码之间的分隔空行
    end = j
    while end < len(lines) and not lines[end].startswith(DECL_PREFIXES):
        end += 1
    if end > j and lines[end - 1] == '':
        end -= 1  # 与下一个声明之间的分隔空行
    out = []
    for n in range(j, end):
        if counts_as_statement(lines[n]):
            out.append((len(out) + 1, n + 1, lines[n].rstrip()))
    return out


def _find_methods(txt_root, class_name, method_name):
    """导出的文本里所有同名（且同程序集）的子程序：[(文件, 语句表)]。"""
    found = []
    for dp, dn, fn in sorted(os.walk(txt_root)):
        for f in sorted(fn):
            if not f.endswith('.e.txt'):
                continue
            p = os.path.join(dp, f)
            try:
                lines = read_text_lines(p)
            except OSError:
                continue
            cur_class = None
            for i, raw in enumerate(lines):
                t = raw.strip()
                if t.startswith('.程序集 '):
                    cur_class = t[len('.程序集 '):].split(',')[0].strip()
                elif t.startswith('.子程序 ') and t[len('.子程序 '):].split(',')[0].strip() == method_name \
                        and (class_name is None or cur_class == class_name):
                    found.append((p, _method_statements(lines, i)))
    return found


def text_statements(txt_root, class_name, method_name, expected=None):
    """返回 (文件, [(语句序号, 行号, 文本)], 提示)：按与行偏移表相同的规则给文本里的语句编号。
    expected 是 .e 里这个子程序的语句数：目录里有多份导出（例如文本工程里又导出了一份）时，优先用语句数相同的那份；
    语句数与 .e 不同时在提示里说明。"""
    found = _find_methods(txt_root, class_name, method_name)
    if not found:
        return None, [], ''
    pick = found[0]
    if expected is not None:
        same = [x for x in found if len(x[1]) == expected]
        if same:
            pick = same[0]
    notes = []
    if len(found) > 1:
        notes.append('目录里有 %d 份文本都含这个子程序，用的是：%s（其余：%s）。--txt 最好直接指向与 .e 同一版本的那一份导出目录。'
                     % (len(found), pick[0], '；'.join(x[0] for x in found if x is not pick)))
    if expected is not None and len(pick[1]) != expected:
        notes.append('文本里这个子程序有 %d 条语句，.e 里有 %d 条：文本与 .e 不是同一版本，下面的行号仅供参考。'
                     % (len(pick[1]), expected))
    return pick[0], pick[1], '\n'.join(notes)


def find_text_line(txt_root, class_name, method_name, stmt_index, expected=None):
    """在导出的文本里找到第 stmt_index 条（从 1 起）有行偏移的语句：返回 (文件, 行号, 文本, 提示)。"""
    p, stmts, note = text_statements(txt_root, class_name, method_name, expected)
    if not p:
        return None, None, None, note
    for k, ln, text in stmts:
        if k == stmt_index:
            return p, ln, text, note
    return p, None, None, note


def explain_text_miss(txt_root, class_name, method_name):
    """导出的文本里找不到子程序时，说明是哪种情况。"""
    n_files = 0
    elsewhere = []
    for dp, dn, fn in os.walk(txt_root):
        for f in fn:
            if not f.endswith('.e.txt'):
                continue
            n_files += 1
            try:
                lines = read_text_lines(os.path.join(dp, f))
            except OSError:
                continue
            cur = None
            for raw in lines:
                t = raw.strip()
                if t.startswith('.程序集 '):
                    cur = t[len('.程序集 '):].split(',')[0].strip()
                elif t.startswith('.子程序 ') and t[len('.子程序 '):].split(',')[0].strip() == method_name:
                    elsewhere.append('%s（%s）' % (cur or '?', os.path.join(dp, f)))
    if not os.path.isdir(txt_root):
        return '目录不存在：%s' % txt_root
    if n_files == 0:
        return ('目录 %s（含子目录）里没有任何 .e.txt 文件：--txt 要给 e2txt 导出的文本工程根目录'
                '（里面有 代码、窗口、配置 等子目录、全局变量.e.txt 的那一层）。' % txt_root)
    if elsewhere:
        return ('文本里有同名子程序，但不在程序集「%s」里：%s。文本与 .e 很可能不是同一版本。'
                % (class_name or '?', '；'.join(elsewhere[:3])))
    return ('目录里有 %d 个 .e.txt 文件，但都没有子程序「%s.%s」：这份文本与 .e 不是同一版本'
            '（例如测试用的子程序是在易语言里加到 .e 里的，文本没有重新导出）。请用 e2txt 把这份 .e 重新导出成文本，'
            '再用新导出的目录。' % (n_files, class_name or '?', method_name))


def has_divide(code):
    code = re.sub(r'“[^”]*”', '', code).split("  ' ")[0]  # 先去掉字符串再截注释：字符串里可能含「  ' 」
    if code.lstrip().startswith("' "):
        return False
    return re.search(r'(?<![\w\u4e00-\u9fff])(求余数|整除) \(', code) is not None


def has_subscript(code):
    code = re.sub(r'“[^”]*”', '', code).split("  ' ")[0]  # 先去掉字符串再截注释：字符串里可能含「  ' 」
    if code.lstrip().startswith("' "):
        return False  # 被屏蔽的语句与注释行不执行
    return re.search(r'[\w\u4e00-\u9fff\)\]]\[', code) is not None


def parse_id(s):
    """读子程序 ID。诊断框里写的是 0x…；复制时漏了 0x 也尽量认出来：带 A～F 字母的按十六进制；
    纯数字按十进制，但十进制值小于 0x04000000 而按十六进制恰好落在子程序 ID 范围（0x04xxxxxx）时按十六进制。"""
    t = s.strip()
    if re.search(r'0[xX][0-9A-Fa-f]+', t):
        return parse_int(t)
    m = re.search(r'(?<![0-9A-Za-z])([0-9A-Fa-f]{6,8})(?![0-9A-Za-z])', t)
    if m and re.search(r'[A-Fa-f]', m.group(1)):
        return int(m.group(1), 16)
    v = parse_int(t)
    if v < 0x04000000:
        try:
            h = int(re.search(r'\d+', t).group(0), 16)
        except (AttributeError, ValueError):
            h = -1
        if 0x04000000 <= h < 0x05000000:
            print('（%s 按十六进制 0x%08X 理解：十进制的 %d 不是子程序 ID）' % (t, h, v))
            return h
    return v


def parse_int(s):
    """读子程序 ID 或位置：十六进制写 0x…，否则按十进制。从诊断框里连带括号、「子程序ID」等字样复制过来也能读出数字。"""
    m = re.search(r'0[xX]([0-9A-Fa-f]+)', s)
    if m:
        return int(m.group(1), 16)
    m = re.search(r'\d+', s)
    if m:
        return int(m.group(0))
    raise SystemExit('读不出数字：%s（子程序 ID 写成 0x0401219A 或 67183002，位置写成十进制数字）' % s)


class _ExprStarts:
    """解析一个子程序的代码数据，收集每条语句与每个表达式开始处的偏移。易语言编译出的运行时检查报出的「位置」
    恰好是其中之一（已用真实的编译程序与源码逐条核对），所以可以用它判断某个位置是否属于这个子程序的这一版代码。"""
    BLOCK = {0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F, 0x70, 0x71}

    def __init__(self, data):
        self.d = data
        self.p = 0
        self.starts = set()
        self.subscripts = []  # 每处数组下标（0x3A）所在的偏移

    def u8(self):
        v = self.d[self.p]
        self.p += 1
        return v

    def i32(self):
        v = struct.unpack_from('<i', self.d, self.p)[0]
        self.p += 4
        return v

    def bstr(self):
        n = self.i32()
        if n > 0:
            self.p += n

    def call(self):
        self.starts.add(self.p)
        self.p += 8  # 命令编号、支持库编号、标志
        self.bstr()  # 未验证代码
        self.bstr()  # 备注
        if self.p < len(self.d):
            t = self.u8()
            if t == 0x38:
                self.p -= 1
                self.expr()
            elif t != 0x36:
                raise ValueError('调用格式')
            while self.expr() is not None:
                pass

    def expr(self, member=True):
        begin = self.p
        while True:
            t = self.u8()
            if t == 0x01:
                return None  # 参数表结束标记，不是表达式，不记为起点
            if t in (0x1D, 0x37):
                continue
            break
        kind = 'other'
        if t == 0x20:
            return 'end'  # 数组字面量结束标记，同上
        self.starts.add(begin)
        if t in (0x17, 0x19, 0x23):
            self.p += 8
        elif t == 0x18:
            self.p += 2
        elif t in (0x1B, 0x1C, 0x1E, 0x3B):
            self.p += 4
        elif t == 0x1A:
            self.bstr()
        elif t == 0x21:
            self.call()
            kind = 'call'
        elif t == 0x1F:
            while self.expr() != 'end':
                pass
        elif t == 0x38:
            if self.i32() == 0x0500FFFE:
                self.u8()
                return self.expr(True)
            kind = 'var'
            member = True
        elif t != 0x16:
            raise ValueError('表达式格式')
        if member and kind in ('var', 'call'):
            while self.p < len(self.d):
                t = self.u8()
                if t == 0x39:
                    self.p += 8
                elif t == 0x3A:
                    self.subscripts.append(self.p - 1)
                    self.expr(False)
                elif t == 0x37:
                    break
                else:
                    self.p -= 1
                    break
        return kind

    def block(self):
        while self.p < len(self.d):
            st = self.p
            t = self.u8()
            if t not in self.BLOCK:
                continue
            if t in (0x50, 0x51, 0x52, 0x53, 0x54, 0x6F, 0x71):
                self.p -= 1
                return
            if t == 0x55:
                continue
            self.starts.add(st)
            if t == 0x6D:
                if self.u8() != 0x6E:
                    raise ValueError('判断格式')
                while True:
                    self.starts.add(self.p - 1)
                    self.call()
                    self.block()
                    if self.u8() != 0x53:
                        raise ValueError('判断格式')
                    if self.u8() != 0x6E:
                        break
                self.block()
                self.u8()
                self.u8()
                continue
            self.call()
            if t == 0x70:
                self.block()
                self.starts.add(self.p)
                self.u8()
                self.call()
            elif t == 0x6C:
                self.block()
                self.u8()
                self.u8()
            elif t == 0x6B:
                self.block()
                self.u8()
                self.block()
                self.u8()
                self.u8()


class _CodeShape(_ExprStarts):
    """与 _ExprStarts 同样解析，另外记下每条语句里「未验证代码」「备注」两段文字的位置与长度。
    编译成 .ec 时这两段文字可能被去掉，名称与 ID 也可能被隐去或改变，其余代码数据不变；
    把各处起点按「去掉这两段文字后」的位置换算，就得到不受这些影响的形状（见 code_shape）。"""

    def __init__(self, data):
        _ExprStarts.__init__(self, data)
        self.skips = []
        self.calls = []  # 每处调用的命令编号（调用子程序时就是被调用子程序的 ID）

    def _text(self):
        n = self.i32()
        if n > 0:
            self.skips.append((self.p, n))
            self.p += n

    def call(self):
        self.starts.add(self.p)
        self.calls.append(struct.unpack_from('<i', self.d, self.p)[0])
        self.p += 8  # 命令编号、支持库编号、标志
        self._text()  # 未验证代码
        self._text()  # 备注
        if self.p < len(self.d):
            t = self.u8()
            if t == 0x38:
                self.p -= 1
                self.expr()
            elif t != 0x36:
                raise ValueError('调用格式')
            while self.expr() is not None:
                pass


def code_shape(m):
    """子程序代码数据去掉各条语句的「未验证代码」与「备注」文字之后的形状：(长度, 全部表达式与语句起点)。
    名称、ID 都是定长字段，变了不影响形状，所以能在 .ec（名称被隐去、备注可能被去掉）与模块源码 .e 之间
    认出同一个子程序。代码数据解不开时为 None。算一次后缓存在子程序记录里。"""
    if '_shape' not in m:
        shape = None
        data = m.get('expr')
        if data:
            x = _CodeShape(data)
            try:
                x.block()
                ok = x.p == len(data)
            except (ValueError, IndexError, struct.error):
                ok = False
            if ok:
                skips = sorted(x.skips)
                ends, acc = [], []
                total = 0
                for at, n in skips:
                    total += n
                    ends.append(at + n)
                    acc.append(total)

                def norm(o):
                    k = bisect.bisect_right(ends, o)
                    return o - (acc[k - 1] if k else 0)
                shape = (len(data) - total, frozenset(norm(o) for o in x.starts))
                m['_calls'] = tuple(x.calls)
        m['_shape'] = shape
    return m['_shape']


def code_calls(m):
    """子程序代码数据里各处调用的命令编号（按出现先后）；代码数据解不开时为 None。"""
    code_shape(m)
    return m.get('_calls')


_AGREE = {}
_REPORTED = set()


def module_agreement(ms, path, arr):
    """按位置对比整个模块：(代码形状相同的个数, 不同的子程序名列表)。每对文件只算一次。"""
    key = (id(ms), path)
    if key not in _AGREE:
        same, diff = 0, []
        for i in range(min(len(ms), len(arr))):
            sa, sb = code_shape(ms[i][1]), code_shape(arr[i][1])
            if sa is None or sb is None:
                continue
            if sa == sb:
                same += 1
            else:
                c3, m3 = arr[i]
                diff.append('%s.%s' % (c3 or '?', m3['name'] or '（无名称）'))
        _AGREE[key] = (same, diff)
    return _AGREE[key]


def compare_with_source(ms, k, path, arr, comparable):
    """源码与模块文件子程序先后一致时：①第 k 个子程序编进 exe 的代码调用了哪些子程序（名称按源码同位置）；
    ②源码的代码数据与模块文件可比时（全模块按位置至少一半形状相同），再与源码里的版本比少调用、多调用了什么，
    并列出整个模块里代码与源码不同的子程序（每对文件只列一次）。"""
    ec_ids = {mm['id']: i for i, (_, mm) in enumerate(ms)}
    src_ids = {mm['id']: i for i, (_, mm) in enumerate(arr)}

    def callees(calls, idmap):
        out = []
        for cid in calls or ():
            i = idmap.get(cid)
            if i is not None and i < len(arr):
                c3, m3 = arr[i]
                nm = '%s.%s' % (c3 or '?', m3['name'] or '（无名称）')
                if nm not in out:
                    out.append(nm)
        return out
    m, m2 = ms[k][1], arr[k][1]
    a, b = code_calls(m), code_calls(m2)
    if a is not None:
        print('    编进 exe 的这个子程序调用的子程序（名称按源码同位置）：%s' % ('、'.join(callees(a, ec_ids)) or '无'))
    same, diff = module_agreement(ms, path, arr)
    key = (id(ms), path)
    if not comparable:
        if key not in _REPORTED:
            _REPORTED.add(key)
            print('    （源码的代码数据与这个模块文件的写法不同：全模块按位置只有 %d/%d 个子程序代码形状相同，'
                  '多半是用文本转换工具生成的 .e。代码形状与调用不能拿两者来对比，上面同一位置的名称仍然可信）'
                  % (same, same + len(diff)))
        return
    if a is not None and b is not None:
        mine, theirs = callees(a, ec_ids), callees(b, src_ids)
        miss = [x for x in theirs if x not in mine]
        extra = [x for x in mine if x not in theirs]
        if miss:
            print('    源码里的这个子程序调用了、编进 exe 的却没有调用：%s' % '、'.join(miss))
        if extra:
            print('    编进 exe 的这个子程序调用了、源码里的却没有调用：%s' % '、'.join(extra))
    if key not in _REPORTED:
        _REPORTED.add(key)
        print('    全模块对比（按位置）：%d 个子程序代码与源码相同，%d 个不同%s' % (
            same, len(diff), '：' + '、'.join(diff[:60]) + ('……' if len(diff) > 60 else '') if diff else ''))


def show_identity(ms, k, sources, indent='    '):
    """查到的模块子程序（ms 里第 k 个，从 0 起）：名称被隐去时列出附近有名称的子程序；给了 --源码 时，
    在源码里按形状认出它的名称，并核对源码与这个模块文件的子程序先后是否一致（一致时同位置的名称也可信）。"""
    cname, m = ms[k]
    if not m['name']:
        near = []
        for step in (-1, 1):
            got = 0
            i = k + step
            while 0 <= i < len(ms) and abs(i - k) <= 40 and got < 3:
                if ms[i][1]['name']:
                    near.append((i, ms[i]))
                    got += 1
                i += step
        near.sort(key=lambda t: t[0])
        if near:
            print('%s附近有名称的子程序：%s' % (indent, '；'.join('第 %d 个 %s.%s' % (i + 1, c or '?', mm['name'])
                                                               for i, (c, mm) in near)))
    if not sources:
        if not m['name']:
            print('%s（名称被隐去：加 --源码 <这个模块的源码 .e> 可按代码形状认出名称）' % indent)
        return
    shape = code_shape(m)
    for path, v in sources:
        arr = v['array']
        both = [(a[1]['name'], b[1]['name']) for a, b in zip(ms, arr) if a[1]['name'] and b[1]['name']]
        same = sum(1 for a, b in both if a == b)
        if both and same * 100 >= len(both) * 98 and k < len(arr):
            c2, m2 = arr[k]
            agree, differ = module_agreement(ms, path, arr)
            comparable = agree * 2 >= agree + len(differ) and agree > 0
            verdict = ''
            if comparable and shape is not None and code_shape(m2) is not None:
                verdict = '，代码形状也相同' if code_shape(m2) == shape else '，但代码形状不同'
            print('%s源码 %s 与这个模块文件的子程序先后一致（有名称的 %d 个里 %d 个同名）：同一位置的是 %s.%s%s'
                  % (indent, path, len(both), same, c2 or '?', m2['name'] or '（无名称）', verdict))
            compare_with_source(ms, k, path, arr, comparable)
            continue  # 先后一致时同一位置就是它，不再到别处按形状找（短小的子程序形状可能碰巧相同）
        if shape is None:
            continue
        hits = [(i, c2, m2) for i, (c2, m2) in enumerate(arr) if code_shape(m2) == shape]
        if hits:
            print('%s源码 %s 里代码形状相同的子程序 %d 个：%s%s' % (indent, path, len(hits), '；'.join(
                '%s.%s' % (c2 or '?', m2['name'] or '（无名称）') for i, c2, m2 in hits[:8]),
                '（这个子程序很短，形状相同也可能是巧合）' if shape[0] < 120 else ''))
        else:
            print('%s源码 %s 里没有代码形状相同的子程序（源码与编进 exe 的不是同一版本，或这个子程序后来改过）' % (indent, path))
    if shape is None:
        print('%s（这个子程序的代码数据解不开，不能按形状比对）' % indent)


def parse_expr_info(data):
    """解析子程序代码数据：返回（所有语句与表达式的起始偏移集合, 各处数组下标的偏移列表）；格式不认识时返回 None。"""
    x = _ExprStarts(data)
    try:
        x.block()
    except (ValueError, IndexError, struct.error):
        return None
    return (x.starts, x.subscripts) if x.p == len(data) else None


def expr_starts(data):
    """子程序代码数据里所有语句与表达式的起始偏移；格式不认识时返回 None。"""
    info = parse_expr_info(data)
    return info[0] if info else None


def allocated_id_num(code_section):
    """程序段开头记录的「已分配到的最大编号」（不含类型字节）：主工程里所有子程序、变量等的编号都不超过它。"""
    return Reader(code_section).i32() & 0x00FFFFFF


def exe_check_groups(path):
    """扫描 exe 里易语言编译出的运行时检查（push 位置；push 子程序ID；push 错误号；call 报错函数），
    返回 {子程序编号（不含类型字节）: {位置…}}。加了壳（代码被压缩或虚拟化）的 exe 里找不到这些指令。"""
    with open(path, 'rb') as f:
        d = f.read()
    if d[:2] != b'MZ' or len(d) < 64:
        raise ValueError('不是 exe/dll 文件')
    e = struct.unpack_from('<i', d, 60)[0]
    if e <= 0 or e + 24 > len(d) or d[e:e + 4] != b'PE\0\0':
        raise ValueError('PE 头不完整')
    nsec = struct.unpack_from('<H', d, e + 6)[0]
    tbl = e + 24 + struct.unpack_from('<H', d, e + 20)[0]
    pat = re.compile(rb'(?=\x68....\x68...\x04[\x68\x6A])', re.S)  # 前瞻：可重叠，不会被前一个假匹配吞掉
    groups = {}
    for i in range(nsec):
        if tbl + i * 40 + 40 > len(d):
            break
        rsize, rptr = struct.unpack_from('<II', d, tbl + i * 40 + 16)
        ch = struct.unpack_from('<I', d, tbl + i * 40 + 36)[0]
        if not ch & 0x20000000:
            continue
        code = d[rptr:rptr + rsize]
        for mm in pat.finditer(code):
            h = mm.start()
            if h + 16 > len(code):
                continue
            if (code[h + 10] == 0x68 and code[h + 15] == 0xE8) or (code[h + 10] == 0x6A and code[h + 12] == 0xE8):
                mid = struct.unpack_from('<I', code, h + 6)[0] & 0x00FFFFFF
                groups.setdefault(mid, set()).add(struct.unpack_from('<i', code, h + 1)[0])
    return groups


def module_method_list(path):
    """模块源码 .e（或 .ec）里的子程序，按文件里出现的先后顺序：[(类名, 子程序)]。"""
    with open(path, 'rb') as f:
        secs = read_sections(f.read())
    if CODE_SECTION_KEY not in secs:
        raise ValueError('没有程序段')
    classes, methods = parse_code_section(secs[CODE_SECTION_KEY])
    cls = {}
    for c in classes:
        for x in c['methods']:
            cls[x] = c['name']
    return [(cls.get(m['id'], ''), m) for m in methods]


def calibrate_module(groups, alloc, ms):
    """编译时，模块里的子程序按模块文件里的先后顺序连续编号，起始编号（基址）不知道。
    用 exe 里每个带检查的子程序的位置来校准：报出的位置一定恰好是该子程序某个表达式的起点（代码数据解不开时退而要求小于其长度）。
    返回 [(落在范围内的检查子程序数, 基址)]，按数目从多到少；只收录范围内没有任何矛盾的基址。"""
    import bisect
    lens = [m['expr_len'] for _, m in ms]
    starts = [method_starts(m) for _, m in ms]  # 与放宽条件的诊断共用同一份缓存
    n = len(lens)
    keys = sorted(g for g in groups if g > alloc)
    mx = {g: max(groups[g]) for g in keys}
    if not keys or not n:
        return []

    def fits(g, k):
        # 检查报出的位置都必须恰好是这个子程序某个表达式的起点（解不开代码数据时退而只要求小于代码数据长度）
        st = starts[k]
        if st is not None:
            return all(p in st for p in groups[g])
        return mx[g] < lens[k]

    out = []
    for b in range(max(alloc + 1, keys[0] - n + 1), keys[-1] + 1):
        lo = bisect.bisect_left(keys, b)
        hi = bisect.bisect_left(keys, b + n)
        if lo >= hi:
            continue
        if all(fits(g, g - b) for g in keys[lo:hi]):
            out.append((hi - lo, b))
    out.sort(key=lambda t: (-t[0], t[1]))
    return out


def pe_timestamp(path):
    """exe/dll 的 PE 文件头时间戳（编译链接时间，1970-01-01 UTC 起的秒数）。"""
    with open(path, 'rb') as f:
        d = f.read(4096)
    if d[:2] != b'MZ' or len(d) < 64:
        raise ValueError('不是 exe/dll 文件')
    e = struct.unpack_from('<i', d, 60)[0]
    if e <= 0 or e + 12 > len(d) or d[e:e + 4] != b'PE\0\0':
        raise ValueError('PE 头不完整')
    return struct.unpack_from('<I', d, e + 8)[0]


def show_exe_times(paths):
    import datetime
    import glob
    files = []
    for a in paths:
        hit = sorted(glob.glob(a))
        files.extend(hit if hit else [a])
    bj = datetime.timezone(datetime.timedelta(hours=8))
    for f in files:
        try:
            ts = pe_timestamp(f)
        except (OSError, ValueError, struct.error) as ex:
            print('%s：读不出（%s）' % (f, ex))
            continue
        if ts == 0:
            print('%s：PE 时间戳为 0（没有编译时间）' % f)
            continue
        t = datetime.datetime.fromtimestamp(ts, bj)
        print('%s：编译时间 %d年%d月%d日%d时%d分%d秒（北京时间），PE 时间戳 0x%X' % (f, t.year, t.month, t.day, t.hour, t.minute, t.second, ts))
    return 0


def pe_time_text(ts):
    """PE 时间戳 → 「2026年10月27日5时53分41秒（北京时间）」。"""
    import datetime
    t = datetime.datetime.fromtimestamp(ts, datetime.timezone(datetime.timedelta(hours=8)))
    return '%d年%d月%d日%d时%d分%d秒（北京时间）' % (t.year, t.month, t.day, t.hour, t.minute, t.second)


def pe_section_table(d):
    """PE 节表：[(节名, 虚拟地址, 虚拟大小, 文件里的大小, 文件偏移, 属性)]。"""
    if d[:2] != b'MZ' or len(d) < 64:
        raise ValueError('不是 exe/dll 文件')
    e = struct.unpack_from('<i', d, 60)[0]
    if e <= 0 or e + 24 > len(d) or d[e:e + 4] != b'PE\0\0':
        raise ValueError('PE 头不完整')
    nsec = struct.unpack_from('<H', d, e + 6)[0]
    tbl = e + 24 + struct.unpack_from('<H', d, e + 20)[0]
    out = []
    for i in range(nsec):
        o = tbl + i * 40
        if o + 40 > len(d):
            break
        vsize, va, rsize, rptr = struct.unpack_from('<IIII', d, o + 8)
        ch = struct.unpack_from('<I', d, o + 36)[0]
        out.append((d[o:o + 8].rstrip(b'\0').decode('latin-1'), va, vsize, rsize, rptr, ch))
    return out


def infer_id_at(d, secs, rva):
    """与运行时出错诊断框（启动诊断_附近子程序ID）同一算法，从 exe 文件里读出相对地址 rva 所在函数的子程序 ID：
    在 rva 前后各 64KB（限在所在的可执行、可读节内）里，往前找最近的 55 8B EC、往后找下一个 55 8B EC，
    取这一段里第一处「push 位置；push 子程序ID（最高字节 04）；push 错误号；call」里的 ID。
    读不出返回 0；rva 不在可执行、可读的节里返回 None。"""
    for name, va, vsize, rsize, rptr, ch in secs:
        size = vsize if vsize else rsize
        if va <= rva < va + size and ch & 0x20000000 and ch & 0x40000000:
            break
    else:
        return None
    body = d[rptr:rptr + min(rsize, size)]
    if len(body) < size:
        body += b'\0' * (size - len(body))  # 节在内存里比文件里长的部分是零
    lo = max(rva - 65536, va)
    code = body[lo - va:min(rva + 65536, va + size) - va]
    rel = rva - lo
    head = code.rfind(b'\x55\x8b\xec', 0, rel + 3)
    if head < 0:
        return 0
    tail = code.find(b'\x55\x8b\xec', rel)
    if tail < 0:
        tail = len(code)
    p = head
    while True:
        p = code.find(b'\x68', p)
        if p < 0 or p >= tail or p + 16 > len(code):
            return 0
        if code[p + 5] == 0x68 and code[p + 9] == 0x04 and (
                (code[p + 10] == 0x68 and code[p + 15] == 0xE8) or (code[p + 10] == 0x6A and code[p + 12] == 0xE8)):
            return struct.unpack_from('<I', code, p + 6)[0]
        p += 1


# 诊断框全文里的「exe+0x…〔子程序ID 0x…〕」；也认匿名诊断摘要（服务端表 tb_yinxiao_diag）里的写法：
# 签名 sig 里是 exe+A481（不带 0x），详情 last_detail 经过净化，〔子程序ID 0x…〕成了 _ID_0x…
ADDR_ITEM_PAT = re.compile(r'exe\s*\+\s*(?:0[xX])?([0-9A-Fa-f]+)(?:\s*〔\s*子程序\s*ID\s*0[xX]([0-9A-Fa-f]+)\s*〕|_ID_0[xX]([0-9A-Fa-f]+))?')


def _addr_items_in_text(t):
    out = []
    for m in ADDR_ITEM_PAT.finditer(t):
        gid = m.group(2) or m.group(3)
        out.append((int(m.group(1), 16), int(gid, 16) if gid else 0))
    return out


def parse_address_items(args):
    """从参数或诊断框文本文件里读出 [(相对地址, 诊断框里的子程序ID)]，按出现先后、去掉重复。
    文件里找「exe+0x…〔子程序ID 0x…〕」：没带〔子程序ID〕的 exe 地址是诊断框在那里推断不出 ID，记为 0；
    参数写成 exe+0x375C34=0x40374A9（都按十六进制），只写 exe+0x375C34 时记为 None（只列出这个 exe 里推断出的 ID）。
    也认匿名诊断摘要的写法：文件里存的是详情 last_detail（exe+0x…_ID_0x…），或把签名 sig 整串作参数
    （如 cC0000005@exe+A481_t=exe+1B85D_f=exe+2F565C：出错地址与 _t、_f 两个调用者）。"""
    items = []
    for a in args:
        if os.path.isfile(a):
            items.extend(_addr_items_in_text(decode_text(open(a, 'rb').read())))
            continue
        m = re.fullmatch(r'\s*(?:exe\s*\+\s*)?(?:0[xX])?([0-9A-Fa-f]+)\s*(?:[=＝:：]\s*(?:0[xX])?([0-9A-Fa-f]+))?\s*', a)
        if not m:
            found = _addr_items_in_text(a)
            if not found:
                raise SystemExit('读不出地址：%s（写成 exe+0x375C34 或 exe+0x375C34=0x40374A9，或者给存了诊断框全文的文本文件，或匿名诊断摘要的签名整串）' % a)
            items.extend((rva, None) for rva, _ in found)
            continue
        items.append((int(m.group(1), 16), int(m.group(2), 16) if m.group(2) else None))
    out = []
    for it in items:
        if it not in out:
            out.append(it)
    return out


def _rva_to_off(secs, rva):
    for _, va, vsz, rsz, rptr, ch in secs:
        if va <= rva < va + max(vsz, rsz):
            return rptr + (rva - va)
    return None


def call_target_before(d, secs, ret_rva):
    """返回地址 ret_rva 处的上一条指令若是 5 字节相对 call（E8+4 字节偏移，易语言调用子程序就编译成这个），
    返回其目标 rva；否则返回 False（上一条不是相对 call，多半是 call ebx/eax 这类间接调用）。"""
    off = _rva_to_off(secs, ret_rva - 5)
    if off is None or d[off] != 0xE8:
        return False
    disp = struct.unpack_from('<i', d, off + 1)[0]
    return (ret_rva + disp) & 0xFFFFFFFF


PROLOGUE = b'\x55\x8b\xec'  # push ebp；mov ebp,esp：易语言编译出的子程序都以它开头
_REGS = ('eax', 'ecx', 'edx', 'ebx', 'esp', 'ebp', 'esi', 'edi')


def pe_image_layout(d):
    """装载基址、映像大小与导入表：返回 (基址, 映像大小, {导入表项的绝对地址: 'DLL!函数'})。
    导入表读不出（加壳、文件不完整等）时字典为空，不影响其余功能。"""
    try:
        e = struct.unpack_from('<i', d, 60)[0]
        opt = e + 24
        magic = struct.unpack_from('<H', d, opt)[0]
        if magic == 0x10B:
            base = struct.unpack_from('<I', d, opt + 28)[0]
            ddir, tsz = opt + 96, 4
        elif magic == 0x20B:
            base = struct.unpack_from('<Q', d, opt + 24)[0]
            ddir, tsz = opt + 112, 8
        else:
            return 0, 0, {}
        image_size = struct.unpack_from('<I', d, opt + 56)[0]
        secs = pe_section_table(d)
        imp_rva = struct.unpack_from('<I', d, ddir + 8)[0]
    except (ValueError, struct.error):
        return 0, 0, {}
    imports = {}

    def cstr(rva, limit=256):
        o = _rva_to_off(secs, rva)
        if o is None or o >= len(d):
            return None
        s = d[o:o + limit]
        z = s.find(b'\0')
        return s[:z if z >= 0 else len(s)].decode('latin-1')

    o = _rva_to_off(secs, imp_rva) if imp_rva else None
    for k in range(4096 if o is not None else 0):
        if o + k * 20 + 20 > len(d):
            break
        oft, _, _, name_rva, ft = struct.unpack_from('<IIIII', d, o + k * 20)
        if not (oft or name_rva or ft):
            break
        dll = cstr(name_rva) or '?'
        src = _rva_to_off(secs, oft or ft)
        if src is None:
            continue
        for j in range(65536):
            p = src + j * tsz
            if p + tsz > len(d):
                break
            v = struct.unpack_from('<I' if tsz == 4 else '<Q', d, p)[0]
            if v == 0:
                break
            if v >> (tsz * 8 - 1):
                fn = '#%d' % (v & 0xFFFF)
            else:
                fn = cstr((v & 0x7FFFFFFF) + 2) or '?'
            imports[base + ft + j * tsz] = '%s!%s' % (dll, fn)
    return base, image_size, imports


def _hexbytes(bs):
    return ' '.join('%02X' % b for b in bs)


def _abs_text(v, base, image_size):
    """绝对地址落在本 exe 映像里时写成 exe+0x…，否则写成 0x…。"""
    if base and image_size and base <= v < base + image_size:
        return 'exe+0x%X' % (v - base)
    return '0x%X' % v


def _stub_text(d, off, rva, base, image_size, imports):
    """把不以 55 8B EC 开头的一小段代码（调用桩之类）按最常见的几种指令写出来，遇到跳转、返回或认不出的字节就停。"""
    parts = []
    p, cur = off, rva
    for _ in range(4):
        if p + 1 > len(d):
            break
        op = d[p]
        if 0xB8 <= op <= 0xBF and p + 5 <= len(d):
            v = struct.unpack_from('<I', d, p + 1)[0]
            parts.append('mov %s,%s' % (_REGS[op - 0xB8], _abs_text(v, base, image_size)))
            p += 5
            cur += 5
        elif op == 0x68 and p + 5 <= len(d):
            parts.append('push %s' % _abs_text(struct.unpack_from('<I', d, p + 1)[0], base, image_size))
            p += 5
            cur += 5
        elif op == 0x6A and p + 2 <= len(d):
            parts.append('push %d' % struct.unpack_from('<b', d, p + 1)[0])
            p += 2
            cur += 2
        elif op == 0xE9 and p + 5 <= len(d):
            parts.append('jmp exe+0x%X' % ((cur + 5 + struct.unpack_from('<i', d, p + 1)[0]) & 0xFFFFFFFF))
            return '；'.join(parts)
        elif op == 0xEB and p + 2 <= len(d):
            parts.append('jmp exe+0x%X' % ((cur + 2 + struct.unpack_from('<b', d, p + 1)[0]) & 0xFFFFFFFF))
            return '；'.join(parts)
        elif op == 0xFF and p + 6 <= len(d) and d[p + 1] == 0x25:
            a = struct.unpack_from('<I', d, p + 2)[0]
            parts.append('jmp [0x%X]%s' % (a, '＝导入的 ' + imports[a] if a in imports else ''))
            return '；'.join(parts)
        elif op in (0xC3, 0xC2):
            parts.append('ret')
            return '；'.join(parts)
        else:
            break
    rest = _hexbytes(d[p:p + 8])
    return '；'.join(parts + ['（之后的机器码 %s）' % rest if parts else '机器码 %s' % rest])


def describe_call_target(d, secs, tgt, base, image_size, imports, depth=0):
    """直接 call 的目标。以 55 8B EC 开头的是函数入口：在函数里面推断子程序 ID（按诊断框的算法在入口处推断，前后两个
    55 8B EC 是同一个位置，永远推断不出）。不以 55 8B EC 开头的（库命令或 DLL 命令的调用桩、导入跳转桩、核心库函数等）
    不附编号：按地址推断会读到它前面那个子程序的 ID，容易误认成被调用的子程序；改为写出它开头的几条指令。"""
    off = _rva_to_off(secs, tgt)
    if off is None or off + 3 > len(d):
        return 'exe+0x%X（不在 exe 的节里）' % tgt
    if d[off:off + 3] == PROLOGUE:
        tid = infer_id_at(d, secs, tgt + 3)
        if tid:
            return 'exe+0x%X〔子程序ID 0x%X〕' % (tgt, tid)
        return 'exe+0x%X〔函数入口，推断不出 ID：函数里没有运行时检查，或不是易语言子程序〕' % tgt
    if d[off] == 0xE9 and off + 5 <= len(d) and depth < 3:
        nxt = (tgt + 5 + struct.unpack_from('<i', d, off + 1)[0]) & 0xFFFFFFFF
        return 'exe+0x%X（跳转桩，转到 %s）' % (tgt, describe_call_target(d, secs, nxt, base, image_size, imports, depth + 1))
    if d[off] == 0xFF and off + 6 <= len(d) and d[off + 1] == 0x25:
        a = struct.unpack_from('<I', d, off + 2)[0]
        return 'exe+0x%X（导入跳转桩 jmp [0x%X]%s）' % (tgt, a, '＝' + imports[a] if a in imports else '')
    return 'exe+0x%X（不是函数入口，不附编号：%s）' % (tgt, _stub_text(d, off, tgt, base, image_size, imports))


def describe_indirect_call(d, secs, ret_rva, base, image_size, imports):
    """返回地址前面若是间接 call，按最常见的几种写法认出来并说明函数地址从哪里来；认不出返回 None。
    （从返回地址往回认指令只能按固定的几种写法匹配，个别情况下可能认错，以反汇编为准。）"""
    off = _rva_to_off(secs, ret_rva)
    if off is None or off < 7 or off > len(d):
        return None
    b = d[off - 7:off]
    if b[1] == 0xFF and b[2] == 0x15:  # FF 15 绝对地址：call [0x…]
        a = struct.unpack_from('<I', b, 3)[0]
        if a in imports:
            return '间接调用 call [0x%X]＝导入的 %s' % (a, imports[a])
        return '间接调用 call [%s]（取全局变量里存的函数地址）' % _abs_text(a, base, image_size)
    if b[0] == 0xFF and b[1] == 0x94 and b[2] == 0x24:  # FF 94 24 disp32：call [esp+…]
        return '间接调用 call [esp%+#x]（栈上存的函数地址）' % struct.unpack_from('<i', b, 3)[0]
    if b[0] == 0xFF and b[1] == 0x14 and b[2] & 7 == 5 and (b[2] >> 3) & 7 != 4:  # FF 14 SIB disp32：call [寄存器*倍数+表地址]
        a = struct.unpack_from('<I', b, 3)[0]
        return '间接调用 call [%s*%d+%s]（按序号从函数地址表里取）' % (_REGS[(b[2] >> 3) & 7], 1 << (b[2] >> 6), _abs_text(a, base, image_size))
    if b[1] == 0xFF and 0x90 <= b[2] <= 0x97 and b[2] != 0x94:  # FF 9x disp32：call [寄存器+…]
        reg, disp = _REGS[b[2] & 7], struct.unpack_from('<i', b, 3)[0]
        if reg == 'ebp':
            return '间接调用 call [ebp%+#x]（局部变量或参数里存的函数地址，多半是子程序指针）' % disp
        return '间接调用 call [%s%+#x]（经寄存器加偏移取函数地址：多半是对象的方法表或函数表）' % (reg, disp)
    if b[3] == 0xFF and b[4] == 0x54 and b[5] == 0x24:  # FF 54 24 disp8：call [esp+…]
        return '间接调用 call [esp%+#x]（栈上存的函数地址）' % struct.unpack_from('<b', b, 6)[0]
    if b[4] == 0xFF and 0x50 <= b[5] <= 0x57 and b[5] != 0x54:  # FF 5x disp8：call [寄存器+…]
        reg, disp = _REGS[b[5] & 7], struct.unpack_from('<b', b, 6)[0]
        if reg == 'ebp':
            return '间接调用 call [ebp%+#x]（局部变量或参数里存的函数地址，多半是子程序指针）' % disp
        return '间接调用 call [%s%+#x]（经寄存器加偏移取函数地址：多半是对象的方法表或函数表）' % (reg, disp)
    if b[4] == 0xFF and b[5] == 0x14 and b[6] == 0x24:  # FF 14 24：call [esp]
        return '间接调用 call [esp]（栈上存的函数地址）'
    if b[5] == 0xFF and 0xD0 <= b[6] <= 0xD7:  # FF Dx：call 寄存器
        return '间接调用 call %s（寄存器里的函数地址：核心库调用库命令函数、易语言调用子程序指针都是这样）' % _REGS[b[6] & 7]
    if b[5] == 0xFF and 0x10 <= b[6] <= 0x17 and b[6] not in (0x14, 0x15):  # FF 1x：call [寄存器]
        return '间接调用 call [%s]（寄存器指向的地方存的函数地址）' % _REGS[b[6] & 7]
    return None


def function_head(d, secs, rva):
    """rva 所在函数的入口：与 infer_id_at 同样往前找最近的 55 8B EC；找不到返回 None。"""
    for name, va, vsize, rsize, rptr, ch in secs:
        size = vsize if vsize else rsize
        if va <= rva < va + size and ch & 0x20000000 and ch & 0x40000000:
            break
    else:
        return None
    lo = max(rva - 65536, va)
    o = _rva_to_off(secs, lo)
    if o is None:
        return None
    code = d[o:o + (rva - lo) + 3]
    h = code.rfind(PROLOGUE, 0, rva - lo + 3)
    return None if h < 0 else lo + h


def looks_like_return_address(d, secs, rva, base, image_size, imports):
    """rva 前面是不是一条 call（直接 call，或认得出的间接 call）。"""
    return call_target_before(d, secs, rva) is not False or describe_indirect_call(d, secs, rva, base, image_size, imports) is not None


def diag_text_info(args):
    """从诊断框全文里读出 PE 时间戳（读不出为 None）与「帧链」里的 exe 地址集合（帧链里的都是真正的返回地址）。"""
    ts, chain = None, set()
    for a in args:
        if not os.path.isfile(a):
            continue
        t = decode_text(open(a, 'rb').read())
        m = re.search(r'PE\s*时间戳\s*0[xX]([0-9A-Fa-f]+)', t)
        if m and ts is None:
            ts = int(m.group(1), 16)
        i = t.find('帧链')
        if i >= 0:
            j = t.find('栈内代码地址', i)
        else:
            # 匿名诊断摘要的详情 last_detail：帧链写成 fc=…，到 _sc=（或未净化时的 " sc="）为止
            i = t.find('fc=')
            j = -1
            if i >= 0:
                ends = [k for k in (t.find('_sc=', i), t.find(' sc=', i)) if k >= 0]
                j = min(ends) if ends else -1
        if i >= 0:
            for mm in re.finditer(r'exe\s*\+\s*0[xX]([0-9A-Fa-f]+)', t[i:j if j >= 0 else len(t)]):
                chain.add(int(mm.group(1), 16))
    return ts, chain


def disasm_calls(argv):
    """--调用：顺着出错版本 exe 的调用栈往下看。对诊断框里每个 exe 返回地址，取它上一条 call 的目标子程序，
    连同目标的子程序 ID 一起列出，看清没有 ID 的那几层到底调用了哪个子程序。
    目标是易语言子程序入口时在函数里面推断 ID；目标不是函数入口（库命令/DLL 命令的调用桩、导入跳转桩等）时不附编号，
    写出它开头的几条指令；上一条是间接 call 时写出函数地址从哪里来（导入表里的 API 会写出名称）。
    带 ID 的返回地址同时写出所在子程序的入口，便于与上一层「调用 exe+0x…」对上。
    用法：python 定位运行时错误.py --调用 某.exe 诊断框全文.txt（也可直接写 exe+0x375DE5 …）。"""
    if len(argv) < 4:
        print('用法：python 定位运行时错误.py --调用 某.exe 诊断框全文.txt  或  --调用 某.exe exe+0x375DE5 …')
        return 1
    with open(argv[2], 'rb') as f:
        d = f.read()
    try:
        secs = pe_section_table(d)
    except (ValueError, struct.error) as ex:
        print('读不了 exe：%s' % ex)
        return 2
    items = parse_address_items(argv[3:])
    if not items:
        print('没有读到「exe+0x…」地址：给诊断框全文，或直接写地址。')
        return 1
    base, image_size, imports = pe_image_layout(d)
    _, chain = diag_text_info(argv[3:])
    for rva, _ in items:
        gid = infer_id_at(d, secs, rva)
        tgt = call_target_before(d, secs, rva)
        if tgt is not False:
            line = '调用 ' + describe_call_target(d, secs, tgt, base, image_size, imports)
        else:
            line = describe_indirect_call(d, secs, rva, base, image_size, imports)
            if line is None:
                if rva in chain:
                    line = '上一条没认出是 call 指令（帧链里的应当都是返回地址：可能是少见的间接调用写法，也可能这个地址抄错了）'
                else:
                    line = '上一条没认出是 call 指令（栈内代码地址里也会夹着存在栈上的其他代码地址，不一定是返回地址）'
        where = ''
        if gid:
            h = function_head(d, secs, rva)
            where = '〔子程序ID 0x%X%s〕' % (gid, '，入口 exe+0x%X' % h if h is not None else '')
        print('  exe+0x%X%s \u2190 %s' % (rva, where, line))
    print('注：带 ID 的返回地址后面写着所在子程序的入口，与上一层「调用 exe+0x…」相同就说明是它直接调用的。'
          '「间接调用 call 寄存器」多是核心库调用库命令函数（求余数这类库命令也在其中）或易语言调用子程序指针，'
          '具体是哪个函数要反汇编才能看清。不是函数入口的目标（库命令/DLL 命令的调用桩等）不附编号：'
          '按地址推断出的编号属于排在它前面的那个子程序，不是被调用者。')
    return 0


def verify_exe(argv):
    """--核对：用诊断框调用栈里的「exe+0x…〔子程序ID 0x…〕」核对手上的 exe 与出错的 exe。
    逐个地址比较：①这个地址所在函数的 ID 是否相同（代码位置是否没变）；②不同时，诊断框里的那个编号在这个 exe 里
    还有没有。按编号校准（--模块）只用 exe 里各编号的检查位置、不看地址，所以只要编号都还在、没有重排，
    代码挪了位置也不影响校准；编号不在了才说明编号有变化。
    诊断框全文里有「PE 时间戳 0x…」时先比编译时间：相同就是同一次编译，机器码完全一样，这时诊断框推断不出、这个 exe
    推断得出的地方是加壳造成的（运行的是加壳后的程序），其余对不上的地方多半是诊断框全文抄错了；帧链里的地址前面
    认不出 call 指令时也提示可能抄错。"""
    if len(argv) < 4:
        print('用法：python 定位运行时错误.py --核对 某.exe 诊断框全文.txt  或  --核对 某.exe exe+0x375C34=0x40374A9 …')
        return 1
    with open(argv[2], 'rb') as f:
        d = f.read()
    try:
        secs = pe_section_table(d)
        groups = exe_check_groups(argv[2])
    except (ValueError, struct.error) as ex:
        print('读不了 exe：%s' % ex)
        return 2
    items = parse_address_items(argv[3:])
    if not items:
        print('没有读到「exe+0x…」地址：给诊断框全文（Ctrl＋C 复制后存成文本文件）或直接写地址。')
        return 1
    ts = struct.unpack_from('<I', d, struct.unpack_from('<i', d, 60)[0] + 8)[0]
    diag_ts, chain = diag_text_info(argv[3:])
    same_build = bool(ts) and diag_ts == ts
    if diag_ts is None:
        tail = '（重新编译的 exe 时间不同是正常的）'
    elif same_build:
        tail = '——与诊断框里的相同：就是出错的那一次编译'
    else:
        tail = '——与诊断框里的（%s，PE 时间戳 0x%X）不同：不是同一次编译' % (pe_time_text(diag_ts) if diag_ts else '无', diag_ts)
    print('%s：编译时间 %s，PE 时间戳 0x%X%s' % (argv[2], pe_time_text(ts) if ts else '无', ts, tail))
    if not groups:
        print('结论：这个 exe 里找不到任何运行时检查：多半加了壳（代码被压缩或虚拟化），请用加壳前的 exe。')
        return 2
    base, image_size, imports = pe_image_layout(d)
    same = diff = packed = typo = 0
    ids, same_ids, odd = [], [], []
    for rva, want in items:
        got = infer_id_at(d, secs, rva)
        desc = '不在可执行节里' if got is None else ('推断不出 ID' if got == 0 else '推断出〔子程序ID 0x%X〕' % got)
        ret_note = ''
        if got is not None and rva in chain and not looks_like_return_address(d, secs, rva, base, image_size, imports):
            ret_note = '；这个地址前面没认出 call 指令（帧链里的应当都是返回地址），请核对是否抄错'
            odd.append(rva)
        if want is None:
            print('  exe+0x%X：这个 exe 里%s%s' % (rva, desc, ret_note))
            continue
        ok = (got or 0) == want
        same += ok
        diff += not ok
        if want:
            if want not in ids:
                ids.append(want)
            if ok and want not in same_ids:
                same_ids.append(want)
        note = ''
        if same_build and not ok:
            if want == 0 and got:
                note = '（诊断框没读出、这个 exe 读得出：运行时用的是加壳后的程序，这段代码多半被加壳工具虚拟化、变形或改了内存属性，与代码改动无关）'
                packed += 1
            else:
                note = '（同一次编译，机器码相同却对不上：多半是诊断框全文里这一处的地址或编号抄错了，请对照截图）'
                typo += 1
        elif not ok and want:
            note = '（这个编号在这个 exe 里还在：所在的函数挪了位置）' if (want & 0x00FFFFFF) in groups else '（这个 exe 里没有这个编号）'
        elif not ok:
            note = '（这一段代码与出错的 exe 不同）'
        print('  exe+0x%X：这个 exe 里%s，诊断框里%s——%s%s%s' % (
            rva, desc, '是〔子程序ID 0x%X〕' % want if want else '推断不出 ID', '一致' if ok else '不一致', note, ret_note))
    missing = [w for w in ids if (w & 0x00FFFFFF) not in groups]
    if same + diff == 0:
        print('（给出的地址都没有附带诊断框里的子程序 ID，只列出了这个 exe 里推断出的 ID。）')
    elif same_build:
        if diff == 0:
            print('结论：同一次编译（编译时间相同），给出的 %d 处全部一致：这个 exe 就是出错的那一次编译（加壳前），'
                  '--调用、--模块 与按位置找语句都可以直接用它。' % same)
        elif typo == 0:
            print('结论：同一次编译（编译时间相同）。%d 处一致；%d 处是诊断框推断不出 ID、这个 exe 推断得出：运行的是加壳后的程序，'
                  '那几段代码被加壳工具虚拟化或变形了，是加壳造成的，不是代码改动。这个 exe 就是出错的那一次编译（加壳前），'
                  '--调用、--模块 与按位置找语句都可以直接用它。' % (same, packed))
        else:
            print('结论：同一次编译（编译时间相同），机器码应当完全相同，但有 %d 处对不上（上面注明「抄错」的行）：'
                  '多半是诊断框全文抄错了，改正后再核对%s。' % (typo, '；另有 %d 处是加壳造成的推断不出，属正常' % packed if packed else ''))
    elif diff == 0:
        print('结论：给出的 %d 处全部一致：这个 exe 与出错的 exe 在这些位置的机器码相同（同一次编译，或用完全相同的 .e 与模块重新编译），可以用来校准。' % same)
    elif not missing and same_ids:
        print('结论：%d 处一致、%d 处不一致：代码的位置有变化（多半是重新编译前改过代码），但诊断框里出现的 %d 个子程序编号'
              '在这个 exe 里都还在，其中 %s 连地址都相同：编号没有重排。按编号校准（--模块）只看编号与检查位置、不看地址，'
              '用这个 exe 校准仍然可靠；地址不一致的那几段代码有改动，那里的语句位置可能对不上。'
              % (same, diff, len(ids), '、'.join('0x%X' % w for w in same_ids)))
    elif not missing:
        print('结论：诊断框里出现的 %d 个子程序编号在这个 exe 里都还在，但没有一处地址相同：多半没有重排，但不能确定；'
              '能找到出错版本加壳前的 exe 更好。' % len(ids))
    elif same_ids:
        print('结论：编号有变化：诊断框里的 %s 在这个 exe 里没有（其余编号还在）：用它查这几个编号的结果不可靠，'
              '请用出错那次的 .e 与模块不加壳重新编译。' % '、'.join('0x%X' % w for w in missing))
    else:
        print('结论：这个 exe 不是出错的那一次编译：诊断框里的 %s 在这个 exe 里没有，也没有一处地址一致。'
              '请找出错版本加壳前的 exe，或用出错那次的 .e 与模块不加壳重新编译一次。' % '、'.join('0x%X' % w for w in missing))
    if odd:
        print('另外，帧链里的 %s 前面没认出 call 指令：若不是少见的间接调用写法，就是地址抄错了。' % '、'.join('exe+0x%X' % r for r in odd))
    return 0

def method_starts(m):
    """子程序代码数据里全部表达式与语句的起点（算一次后缓存在子程序记录里）；代码数据解不开时为 None。"""
    if '_starts' not in m:
        m['_starts'] = expr_starts(m['expr']) if 'expr' in m else None
    return m['_starts']


def fits_positions(positions, m):
    """一个子程序 ID 在 exe 里各处检查报出的位置，能否都落在这个子程序里：代码数据解得开时须全部是表达式起点，
    解不开时只要求都小于代码数据长度（与 calibrate_module 的判断相同）。"""
    st = method_starts(m)
    if st is not None:
        return all(p in st for p in positions)
    return max(positions) < m['expr_len']


def module_variants(path):
    """读模块的 .e（或 .ec）：'array' 是按文件里子程序表先后的 [(类名, 子程序)]（与 module_method_list 相同），
    'byclass' 是按程序集表、每个程序集里子程序表先后的同一批子程序，'placeholder' 是这个模块为引入别的模块而留的
    占位子程序的 ID（只有名称、没有代码；见易模块记录段）。"""
    with open(path, 'rb') as f:
        data = f.read()
    if data[:4] == b'WTLE':
        raise ValueError('文件加了密码，读不了子程序表：改用这个模块的源码 .e，或没有密码的 .ec')
    if data[:8] != b'CNWTEPRG':
        raise ValueError('不是易语言的 .e 或 .ec 文件')
    try:
        secs = read_sections(data)
    except SystemExit as ex:  # read_sections 是给主工程用的，出错时直接结束；读模块时只跳过这一个文件
        raise ValueError(str(ex))
    if CODE_SECTION_KEY not in secs:
        raise ValueError('没有程序段')
    classes, methods = parse_code_section(secs[CODE_SECTION_KEY])
    cls = {}
    for c in classes:
        for x in c['methods']:
            cls[x] = c['name']
    by_id = {m['id']: m for m in methods}
    byclass, seen = [], set()
    for c in classes:
        for x in c['methods']:
            if x in by_id and x not in seen:
                seen.add(x)
                byclass.append((c['name'], by_id[x]))
    byclass += [(cls.get(m['id'], ''), m) for m in methods if m['id'] not in seen]
    recs = []
    if EC_DEP_SECTION_KEY in secs:
        try:
            recs = parse_ec_dependencies(secs[EC_DEP_SECTION_KEY])
        except (ValueError, IndexError, struct.error, UnicodeDecodeError):
            recs = []
    ph = {m['id'] for m in methods if recs and module_of_id(recs, m['id'] & 0xFFFFFFFF)}
    return {'array': [(cls.get(m['id'], ''), m) for m in methods], 'byclass': byclass, 'placeholder': ph,
            'nocode': bool(methods) and all(m['expr_len'] == 0 for m in methods)}


def resolve_module_files(ec_recs, main_path):
    """--模块 自动：用主工程 .e「易模块记录段」里记下的各模块文件（就是编译时用的那些 .ec）。
    记下的路径找不到时，再在主工程 .e 所在目录与当前目录里找同名文件。"""
    if not ec_recs:
        print('主工程 .e 里没有读到易模块记录（或格式不认识），不能自动列出模块：请在 --模块 后面逐个写模块文件。')
        return []
    dirs = [os.path.dirname(os.path.abspath(main_path)) if main_path else '', os.getcwd()]
    out = []
    print('按主工程 .e 里记下的 %d 个模块（编译时用的就是这些文件）：' % len(ec_recs))
    for rec in ec_recs:
        recorded = rec['path'] or ''
        fname = os.path.basename(recorded.replace('\\', '/'))
        cands = [recorded] + [os.path.join(d, fname) for d in dirs if d and fname]
        if rec['name']:
            cands += [os.path.join(d, rec['name'] + '.ec') for d in dirs if d]
        hit = next((c for c in cands if c and os.path.isfile(c)), None)
        print('  %s：%s' % (rec['name'] or '?', hit if hit else '找不到（记下的路径：%s）' % (recorded or '无')))
        if hit and hit not in out:
            out.append(hit)
    return out


def numbering_orders(v):
    """编译时给这个模块的子程序编号，可能按的几种先后：[(说明, {编号偏移: (类名, 子程序)})]。
    工具原来只按第一种（文件里子程序表的先后、连同占位子程序）校准；对不上时逐种试。"""
    ph = v['placeholder']
    orders = [('文件顺序', dict(enumerate(v['array'])))]
    if ph:
        orders.append(('文件顺序、去掉占位', dict(enumerate([x for x in v['array'] if x[1]['id'] not in ph]))))
    if [m['id'] for _, m in v['byclass']] != [m['id'] for _, m in v['array']]:
        orders.append(('按程序集顺序', dict(enumerate(v['byclass']))))
        if ph:
            orders.append(('按程序集顺序、去掉占位', dict(enumerate([x for x in v['byclass'] if x[1]['id'] not in ph]))))
    orders.append(('按模块里的内部编号', {m['id'] & 0x00FFFFFF: (c, m) for c, m in v['array'] if m['id'] not in ph}))
    return orders


def align_module(groups, keys, v, vote_keys, top=4, limit=60, rare=400):
    """放宽条件的校准（不要求范围内全部相符）：在 vote_keys 这些带检查的编号上，按检查位置找出能对上的子程序，
    每对上一个就给「编号 − 偏移」这个起始编号投票（对上的子程序越多票越轻）；再对各种编号方式下得票最多的几个起始编号，
    在整个范围里数相符、不符与缺号（范围里有检查、却没有这个偏移的子程序）。
    返回 [(质量, 相符, 不符, 缺号, 起始编号, 编号方式, 偏移表)]，质量＝相符－3×(不符＋缺号)，从高到低。"""
    arr = [m for _, m in v['array']]
    inv = {}
    for j, m in enumerate(arr):
        st = method_starts(m)
        if st:
            for p in st:
                inv.setdefault(p, []).append(j)
    orders = numbering_orders(v)
    pos_of = {id(m): j for j, m in enumerate(arr)}
    offs = [{pos_of[id(m)]: off for off, (c, m) in om.items()} for _, om in orders]
    votes = [{} for _ in orders]
    for g in vote_keys:
        ps = groups[g]
        lists = [inv.get(p) for p in ps]
        if any(x is None for x in lists):
            continue
        lists.sort(key=len)
        if len(lists[0]) > rare:
            continue  # 这些位置在很多子程序里都有（例如都是很小的偏移），区分不了
        cand = [j for j in lists[0] if all(p in arr[j]['_starts'] for p in ps)]
        if not cand or len(cand) > limit:
            continue
        w = 1.0 / len(cand)
        for k, o in enumerate(offs):
            vk = votes[k]
            for j in cand:
                off = o.get(j)
                if off is not None:
                    vk[g - off] = vk.get(g - off, 0.0) + w
    out = []
    for k, (name, om) in enumerate(orders):
        if not om:
            continue
        lo_off, hi_off = min(om), max(om)
        for b, _ in sorted(votes[k].items(), key=lambda t: -t[1])[:top]:
            fit = mis = gap = 0
            for g in keys[bisect.bisect_left(keys, b + lo_off):bisect.bisect_right(keys, b + hi_off)]:
                e = om.get(g - b)
                if e is None:
                    gap += 1
                elif fits_positions(groups[g], e[1]):
                    fit += 1
                else:
                    mis += 1
            out.append((fit - 3 * (mis + gap), fit, mis, gap, b, name, om))
    out.sort(key=lambda t: (-t[0], -t[1]))
    return out


def alignment_ok(fit, mis, gap):
    """对位是否可信：相符的检查子程序够多，不符与缺号只占极少数（模块文件与 .ec 有个别出入时也能认出）。"""
    return fit >= 8 and mis + gap <= max(2, fit // 50)


def diagnose_modules(groups, alloc, loaded, target, pos, exe_path, sources=()):
    """严格校准对不上（或给了 --详细）时：说明 exe 与目标编号的情况，逐个模块放宽条件对位，
    列出目标编号可能对应的子程序，以及哪些编号段没有任何所列模块能覆盖（多半是还有模块没列上）。"""
    keys = sorted(g for g in groups if g > alloc)
    print()
    print('—— 放宽条件再查一遍（原来的校准要求一个模块范围内的检查全部相符，模块文件与编进 exe 的 .ec 有一点出入、'
          '或编号方式与假设的不同，整个模块就会对不上）——')
    try:
        print('exe：编译时间 %s（核对是不是出错的那一次编译：python 定位运行时错误.py --核对 %s 诊断框全文.txt）'
              % (pe_time_text(pe_timestamp(exe_path)), exe_path))
    except (OSError, ValueError, struct.error, OverflowError):
        pass
    print('exe 里带检查、编号大于 0x%X 的子程序共 %d 个，编号 0x%X～0x%X。' % (alloc, len(keys), keys[0], keys[-1]))
    if target in groups:
        print('目标 0x%06X：exe 里有 %d 处检查，报出的位置为 %s。'
              % (target, len(groups[target]), '、'.join(str(p) for p in sorted(groups[target]))))
    else:
        print('目标 0x%06X：这个 exe 里没有带这个编号的检查（诊断框是从出错 exe 的这个函数里读出它的）：'
              '这个 exe 很可能不是出错的那一次编译，请先用 --核对 确认。下面仍按相邻编号推算，结果仅供参考。' % target)
    step = max(1, len(keys) // 3000)
    near = [g for g in keys if abs(g - target) <= 6000]
    vote_keys = sorted(set(keys[::step]) | set(near))
    cands, cover = [], []
    print('各模块放宽条件后的最佳对位（相符/不符/缺号：exe 里这个范围内带检查的子程序，检查位置与模块里对应子程序对得上的、'
          '对不上的、模块里没有对应子程序的）：')
    for path, v in loaded:
        n = len(v['array'])
        res = align_module(groups, keys, v, vote_keys)
        if not res:
            print('  %s（%d 个子程序）：一处也对不上：多半不是编进 exe 的那个版本，或这个模块没有编进 exe' % (path, n))
            continue
        q, fit, mis, gap, b, name, om = res[0]
        ok = alignment_ok(fit, mis, gap)
        lo_off, hi_off = min(om), max(om)
        print('  %s（%d 个子程序%s）：%s，起始编号 0x%X，范围 0x%X～0x%X，相符 %d、不符 %d、缺号 %d%s'
              % (path, n, '，其中引入别的模块的占位 %d 个' % len(v['placeholder']) if v['placeholder'] else '',
                 name, b, b + lo_off, b + hi_off, fit, mis, gap, '，可信' if ok else '，不可信'))
        if ok:
            cover.append((b + lo_off, b + hi_off, path))
        seen = set()
        for q, fit, mis, gap, b, name, om in res[:6]:
            e = om.get(target - b)
            if e is not None and fit > mis + gap and id(e[1]) not in seen:  # 对上的比对不上的还少，那个起始编号显然不对，不列
                seen.add(id(e[1]))
                cands.append((alignment_ok(fit, mis, gap), q, fit, mis, gap, path, name, b, target - b, e))
    print('目标 0x%06X 可能对应的子程序（按对位质量从高到低）：' % target)
    if not cands:
        print('  没有：所列模块放宽条件后也覆盖不到这个编号（模块没列全，或模块文件与编进 exe 的不是同一版本）')
    cands.sort(key=lambda t: (not t[0], -t[1]))
    sure = [c for c in cands if c[0]]
    cands = sure[:3] + [c for c in cands if not c[0]][:3 if not sure else 2]
    for ok, q, fit, mis, gap, path, name, b, off, (cname, m) in cands:
        where = ('内部编号 0x%X' % off) if name == '按模块里的内部编号' else ('第 %d 个子程序' % (off + 1))
        print('  %s %s（%s，起始编号 0x%X，相符 %d、不符 %d、缺号 %d）→ %s：%s.%s（代码数据 %d 字节）'
              % ('【可信】' if ok else '［参考］', path, name, b, fit, mis, gap, where, cname or '?',
                 m['name'] or '（名称被隐去）', m['expr_len']))
        if target in groups:
            print('      目标在 exe 里的检查位置%s这个子程序的表达式起点' % ('全部是' if fits_positions(groups[target], m) else '不全是'))
        if name == '文件顺序':
            v = dict(loaded)[path]
            show_identity(v['array'], off, sources, '      ')
        elif not m['name'] or sources:
            show_identity([(cname, m)], 0, sources, '      ')
        if pos is not None and m['lines']:
            idx = sum(1 for o in m['lines'] if o <= pos)
            if idx:
                print('      位置 %d 落在第 %d 条语句' % (pos, idx))
    if target in groups:
        fp = [(path, c, m) for path, v in loaded for c, m in v['array']
              if method_starts(m) is not None and fits_positions(groups[target], m)]
        print('只按目标的检查位置比对（不管编号）：所列模块里有 %d 个子程序的表达式起点包含全部这些位置%s'
              % (len(fp), '：' if 0 < len(fp) <= 12 else ('（太多，不一一列出）' if fp else '')))
        if len(fp) <= 12:
            for path, c, m in fp:
                print('  %s：%s.%s（代码数据 %d 字节）' % (path, c or '?', m['name'] or '（名称被隐去）', m['expr_len']))
    rest = [g for g in keys if not any(lo <= g <= hi for lo, hi, _ in cover)]
    if rest:
        segs = []
        for g in rest:
            if segs and g - segs[-1][1] <= 64:
                segs[-1][1] = g
                segs[-1][2] += 1
            else:
                segs.append([g, g, 1])
        segs.sort(key=lambda s: -s[2])
        print('没有被任何可信对位覆盖的检查编号 %d 个（多半属于没列上的模块，或对位不可信的模块），主要分布在：%s'
              % (len(rest), '；'.join('0x%X～0x%X（%d 个）' % tuple(s) for s in segs[:8])))
    else:
        print('exe 里编号大于 0x%X 的检查全部被可信的对位覆盖。' % alloc)


def locate_module_method(argv, mid, pos, alloc, txt_root, ec_recs=None, main_path=None):
    """编译时给模块子程序的编号 → 哪个模块的哪个子程序：用出错版本的 exe（未加壳）校准各模块的起始编号。
    模块文件可以是源码 .e，也可以是编译用的 .ec（没有密码的）；写 --模块 自动 时按主工程 .e 里记下的模块文件。"""
    exe = argv[argv.index('--exe') + 1] if '--exe' in argv and argv.index('--exe') + 1 < len(argv) else None
    mods = []
    if '--模块' in argv:
        for a in argv[argv.index('--模块') + 1:]:
            if a.startswith('--'):
                break
            mods.append(a)
    if mods and mods[0] == '自动':
        mods = resolve_module_files(ec_recs, main_path) + mods[1:]
    sources = []  # --源码：模块的源码 .e，用来给名称被隐去的子程序认名称（见 show_identity）
    if '--源码' in argv:
        for a in argv[argv.index('--源码') + 1:]:
            if a.startswith('--'):
                break
            try:
                sources.append((a, module_variants(a)))
            except (OSError, ValueError, struct.error, IndexError) as ex:
                print('%s（--源码）：读不了（%s）' % (a, ex))
    if not exe or not mods:
        print('要查到是哪个模块的哪个子程序：用与出错版本同一次编译的 exe（加壳前的）和各模块的源码 .e，再运行一次：')
        print('  python 定位运行时错误.py 主工程.e 0x%08X %s --exe 出错版本.exe --模块 模块1源码.e 模块2源码.e …'
              % (mid & 0xFFFFFFFF, pos if pos is not None else ''))
        print('（工具用 exe 里每个子程序的运行时检查位置，校准出各模块子程序的起始编号；主工程 .e 也须是出错的那一版。）')
        return 2
    try:
        groups = exe_check_groups(exe)
    except (OSError, ValueError, struct.error) as ex:
        print('读不了 exe：%s' % ex)
        return 2
    if not any(g > alloc for g in groups):
        print('exe 里找不到大于 0x%X 的子程序检查指令：exe 可能加了壳，或主工程 .e 与 exe 不是同一版本。' % alloc)
        return 2
    target = mid & 0x00FFFFFF
    above = sorted(g for g in groups if g > alloc)
    results = []
    loaded = []
    for path in mods:
        try:
            v = module_variants(path)
        except (OSError, ValueError, struct.error, IndexError) as ex:
            print('%s：读不了（%s）' % (path, ex))
            continue
        ms = v['array']
        if v.get('nocode'):
            print('%s：这个文件里的子程序都没有代码数据（只有声明），不能用来校准：改用这个模块的源码 .e。' % path)
        loaded.append((path, v))
        results.append({'path': path, 'ms': ms, 'cands': calibrate_module(groups, alloc, ms), 'sure': None})

    def overlaps(b, n, ranges):
        return any(b < fb + fn and fb < b + n for fb, fn in ranges)

    # 证据明显占优的模块先定下起始编号（得分至少 5，且比第二名多出至少 3）；各模块的编号范围互不重叠，
    # 后定的模块只在不与已定范围重叠的起始编号里挑。证据不够的模块不定，后面把几种可能都列出来
    fixed = []
    for r in sorted(results, key=lambda r: -(r['cands'][0][0] if r['cands'] else 0)):
        n = len(r['ms'])
        free = [(sc, b) for sc, b in r['cands'] if not overlaps(b, n, [(fb, fn) for fb, fn, _ in fixed])]
        if not free:
            continue
        best = free[0][0]
        second = free[1][0] if len(free) > 1 else 0
        if best >= 5 and best - second >= 3:
            r['sure'] = free[0][1]
            fixed.append((free[0][1], n, r['path']))
    if results and all(r['sure'] is not None for r in results):
        covered = sum(1 for g in above if any(fb <= g < fb + fn for fb, fn, _ in fixed))
        print('exe 里带检查、编号大于 0x%X 的子程序共 %d 个，所列模块按推算的起始编号覆盖了其中 %d 个%s。'
              % (alloc, len(above), covered, '' if covered == len(above) else '（其余的属于没有列出的模块，或推算有误）'))
    found = 0
    for r in results:
        path, ms = r['path'], r['ms']
        n = len(ms)
        others = [(fb, fn) for fb, fn, fp in fixed if fp != path]
        tc = [(sc, b) for sc, b in r['cands'] if b <= target < b + n and not overlaps(b, n, others)]
        if not tc:
            continue
        sure = r['sure'] is not None and tc[0][1] == r['sure']
        if sure:
            print('%s：起始编号推算为 0x%X（exe 里该模块范围内 %d 个带检查的子程序全部相符，明显多于其他可能），结果可信'
                  % (path, tc[0][1], tc[0][0]))
        else:
            print('%s：起始编号不能唯一确定（exe 里这个模块能用来校准的检查太少），按相符的检查子程序个数从多到少列出几种可能：' % path)
        for sc, b in tc[:1 if sure else 5]:
            cname, m = ms[target - b]
            found += 1
            print('  起始编号 0x%X（%d 个相符）→ 第 %d 个子程序：%s.%s（代码数据 %d 字节）'
                  % (b, sc, target - b + 1, cname or '?', m['name'] or '（名称被隐去）', m['expr_len']))
            show_identity(ms, target - b, sources)
            if pos is not None and m['lines']:
                idx = 0
                for k, off in enumerate(m['lines']):
                    if off <= pos:
                        idx = k + 1
                if idx:
                    print('    位置 %d 落在第 %d 条语句' % (pos, idx))
                    if txt_root and sure:
                        tp, ln, text, note = find_text_line(txt_root, cname or None, m['name'], idx, len(m['lines']))
                        if note:
                            print('    ' + note.replace('\n', '\n    '))
                        if tp and ln:
                            print('    文本：%s 第 %d 行\n          %s' % (tp, ln, text.strip()))
            elif pos is not None:
                print('    （这个模块文件不含行偏移，例如编译好的 .ec，只能定位到子程序；用模块的源码 .e 可定位到语句）')
    if not found:
        print('给出的模块里都对不上这个编号：模块文件须与编进 exe 的同一版本，且要把引用的模块都列上'
              '（最稳妥的是直接用编译时用的那些 .ec：--模块 自动）。')
    if loaded and (not found or '--详细' in argv):
        diagnose_modules(groups, alloc, loaded, target, pos, exe, sources)
    return 0 if found else 2


def compare_ids(path_a, path_b):
    """两份 .e 里同一个子程序（按「程序集.子程序名」对应）的编号是否一致。"""
    def load(path):
        with open(path, 'rb') as f:
            secs = read_sections(f.read())
        if CODE_SECTION_KEY not in secs:
            raise SystemExit('%s 里没有找到程序段。' % path)
        classes, methods = parse_code_section(secs[CODE_SECTION_KEY])
        cls = {}
        for c in classes:
            for x in c['methods']:
                cls[x] = c['name']
        out = {}
        for m in methods:
            out.setdefault((cls.get(m['id'], ''), m['name']), []).append(m['id'] & 0xFFFFFFFF)
        return {k: v[0] for k, v in out.items() if len(v) == 1 and k[1]}
    a, b = load(path_a), load(path_b)
    common = [k for k in a if k in b]
    same = [k for k in common if a[k] == b[k]]
    diff = [k for k in common if a[k] != b[k]]
    print('两份 .e 里都有的子程序 %d 个：编号相同 %d 个，不同 %d 个；只在第一份里 %d 个，只在第二份里 %d 个。'
          % (len(common), len(same), len(diff), len(a) - len(common), len(b) - len(common)))
    for k in diff[:10]:
        print('  %s.%s：0x%08X → 0x%08X' % (k[0] or '?', k[1], a[k], b[k]))
    if not common:
        print('没有可对比的同名子程序（两份 .e 不是同一个工程，或子程序名被隐去）。')
    elif not diff:
        print('结论：同名子程序的编号全部沿用，用改过的 .e 也能按编号查到子程序。')
    elif len(diff) * 10 >= len(common):
        print('结论：编号大面积改变（例如 .e 是从文本重新生成的）：查出错子程序必须用出错那次编译所用的 .e。')
    else:
        print('结论：绝大部分编号沿用，个别不同（多半是删除后重建或剪切粘贴过的子程序）；查这几个子程序须用出错的那一版 .e。')
    return 0


def main(argv):
    if len(argv) >= 3 and argv[1] == '--exe':
        return show_exe_times(argv[2:])
    if len(argv) >= 2 and argv[1] == '--核对':
        return verify_exe(argv)
    if len(argv) >= 2 and argv[1] == '--调用':
        return disasm_calls(argv)
    if len(argv) >= 4 and argv[1] == '--对比编号':
        return compare_ids(argv[2], argv[3])
    if len(argv) < 3:
        print(__doc__)
        return 1
    data = open(argv[1], 'rb').read()
    sections = read_sections(data)
    if CODE_SECTION_KEY not in sections:
        raise SystemExit('没有找到程序段。')
    classes, methods = parse_code_section(sections[CODE_SECTION_KEY])
    alloc = allocated_id_num(sections[CODE_SECTION_KEY])
    class_of = {}
    for c in classes:
        for mid in c['methods']:
            class_of[mid] = c['name']
    ec_recs = []
    if EC_DEP_SECTION_KEY in sections:
        try:
            ec_recs = parse_ec_dependencies(sections[EC_DEP_SECTION_KEY])
        except (ValueError, IndexError, struct.error, UnicodeDecodeError):
            ec_recs = []  # 易模块记录段格式不认识时只是不能判断模块归属，不影响按 ID 查子程序
    if argv[2] == '--名称':
        if len(argv) < 4:
            print('--名称 后面要写「类名.子程序名」（或只写子程序名）。')
            return 1
        want = argv[3]
        pos = parse_int(argv[4]) if len(argv) > 4 and not argv[4].startswith('--') else None
        wc, wm = (want.split('.', 1) if '.' in want else (None, want))
        hit = [m for m in methods if m['name'] == wm and (wc is None or class_of.get(m['id']) == wc)]
        if not hit:
            print('这个 .e 里没有名为 %s 的子程序。' % want)
            return 2
        if len(hit) > 1:
            print('有 %d 个同名子程序，请写成「类名.子程序名」：%s' % (len(hit), '、'.join('%s.%s' % (class_of.get(m['id'], '?'), m['name']) for m in hit)))
            return 2
        mid = hit[0]['id']
        rest = argv[5:] if pos is not None else argv[4:]
        argv = [argv[0], argv[1], hex(mid & 0xFFFFFFFF)] + ([str(pos)] if pos is not None else []) + rest
    if argv[2] == '--list':
        for m in methods:
            rec = module_of_id(ec_recs, m['id'] & 0xFFFFFFFF) if ec_recs else None
            if rec:
                tail = '［模块 %s 的占位编号：主工程里只有名称，编译出的程序不用这个编号（见说明第 3 条）］' % rec['name']
            else:
                tail = '（代码数据 %d 字节，%d 条语句）' % (m['expr_len'], len(m['lines']))
            print('0x%08X  %10d  %s.%s  %s' % (m['id'] & 0xFFFFFFFF, m['id'], class_of.get(m['id'], '?'), m['name'], tail))
        return 0
    mid = parse_id(argv[2])
    pos = parse_int(argv[3]) if len(argv) > 3 and not argv[3].startswith('--') else None
    txt_root = None
    if '--txt' in argv:
        k = argv.index('--txt')
        if k + 1 >= len(argv) or argv[k + 1].startswith('--'):
            print('--txt 后面要写导出的文本工程根目录。')
            return 1
        txt_root = argv[k + 1]
    hit = [m for m in methods if (m['id'] & 0xFFFFFFFF) == (mid & 0xFFFFFFFF)]
    if not hit:
        if (mid & 0x00FFFFFF) > alloc:
            print('ID 0x%08X 大于这个主工程已分配的最大编号 0x%X：这是编译时给模块（.ec）里的子程序另行分配的编号'
                  '（每个模块的子程序按模块里的先后顺序连续编号），主工程 .e 里没有它。'
                  '（若这个 .e 比出错的 exe 旧，也可能是之后才新建的主工程子程序：请用出错的那一版 .e。）' % (mid & 0xFFFFFFFF, alloc))
            return locate_module_method(argv, mid, pos, alloc, txt_root, ec_recs, argv[1])
        print('ID 0x%08X 不在这个 .e 里：这个子程序后来被删掉了（删掉再新建、剪切粘贴都会换 ID），或这个 .e 是从文本重新生成的'
              '（全部 ID 都会重排），请用出错那次编译所用的 .e 再查。' % (mid & 0xFFFFFFFF))
        return 2
    m = hit[0]
    cname = class_of.get(m['id'])
    print('子程序：%s.%s（ID 0x%08X，代码数据 %d 字节，共 %d 条语句）' % (
        cname or '?', m['name'], m['id'] & 0xFFFFFFFF, m['expr_len'], len(m['lines'])))
    rec = module_of_id(ec_recs, m['id'] & 0xFFFFFFFF) if ec_recs else None
    if rec:
        print('这个编号在主工程里是模块「%s」（%s）的子程序的占位，只有名称、没有代码。' % (rec['name'], rec['path']))
        print('实测编译出的程序里，模块的子程序用的是编译时另行分配的编号（大于主工程已分配的最大编号），一般不会报出这种占位编号。'
              '若确实报出了它，可对该模块的源码 .e 按名称查：')
        print('  python 定位运行时错误.py 模块源码.e --名称 %s.%s %s' % (cname or '?', m['name'], argv[3] if pos is not None else '<位置>'))
        return 0
    if pos is None:
        if not txt_root:
            print('（没有位置。加 --txt <导出的文本目录> 可列出这个子程序里含 求余数/整除 与数组下标的语句。）')
            return 0
        p, stmts, note = text_statements(txt_root, cname, m['name'], len(m['lines']))
        if not p:
            print('导出的文本里没找到这个子程序：' + explain_text_miss(txt_root, cname, m['name']))
            return 0
        print('文本：%s（子程序共 %d 条语句；以下按当前版本列出，偏移为代码数据偏移）' % (p, len(stmts)))
        if note:
            print(note)
        div = [(k, ln, t) for k, ln, t in stmts if has_divide(t)]
        sub = [(k, ln, t) for k, ln, t in stmts if has_subscript(t)]
        for title, rows in (('含 求余数/整除 的语句（「不能求余数于零」只会出在这些语句或它们调用的子程序里）', div), ('含数组下标的语句', sub)):
            print(title + '：' + ('无' if not rows else ''))
            for k, ln, text in rows:
                off = m['lines'][k - 1] if k - 1 < len(m['lines']) else -1
                print('  第 %d 条（文本第 %d 行，偏移 %d）：%s' % (k, ln, off, text.strip()))
        return 0
    if pos >= m['expr_len']:
        print('位置 %d 超出这个子程序现在的代码数据长度 %d：.e 与出错的 exe 不是同一版本（代码改过）。' % (pos, m['expr_len']))
        print('若这个 .e 是在易语言里直接编辑出来的，ID 不随改动变化，出错的就是上面这个子程序，只是行对不上；'
              '若 .e 是从文本重新生成的，ID 会整体重排，上面这个子程序也未必是出错的那个（见说明第 1 条，请用出错那次编译所用的 .e）。')
        if txt_root:
            p, stmts, note = text_statements(txt_root, cname, m['name'])
            if p:
                print('这个子程序（当前版本，%s）里带数组下标的语句：' % p)
                for k, ln, text in stmts:
                    if has_subscript(text):
                        off = m['lines'][k - 1] if k - 1 < len(m['lines']) else -1
                        print('  第 %d 条（文本第 %d 行，当前偏移 %d）：%s' % (k, ln, off, text.strip()))
        return 3
    if not m['lines']:
        print('这个文件不含行偏移（例如编译好的 .ec），只能定位到子程序；用源码 .e 可定位到语句。')
        return 3
    idx = 0
    for k, off in enumerate(m['lines']):
        if off <= pos:
            idx = k + 1
        else:
            break
    if idx == 0:
        print('位置 %d 位于第一条语句之前。' % pos)
        return 3
    start = m['lines'][idx - 1]
    end = m['lines'][idx] if idx < len(m['lines']) else m['expr_len']
    print('位置 %d 落在第 %d 条语句（代码数据偏移 %d～%d）。只有这个 .e 与出错的 exe 是同一版本时，这一行才准确。' % (pos, idx, start, end))
    info = parse_expr_info(m['expr'])
    if info is not None:
        st, subs = info
        if pos not in st:
            print('注意：位置 %d 不是这一版代码里任何表达式的起点（编译出的检查报出的位置总是某个表达式的起点），'
                  '这个 .e 与出错的 exe 很可能不是同一版本，上面的行仅供参考。' % pos)
        elif any(start <= o < end for o in subs):
            print('这条语句里有数组下标（数组下标类错误都出在这样的语句里）。')
        else:
            print('这条语句里没有数组下标：报的若是数组下标类错误（错误号 1「超出定义范围」或 4「必须大于等于1」），'
                  '说明这个 .e 与出错的 exe 对不上。')
    if txt_root:
        p, ln, text, note = find_text_line(txt_root, cname, m['name'], idx, len(m['lines']))
        if note:
            print(note)
        if p and ln:
            print('文本：%s 第 %d 行' % (p, ln))
            print('      %s' % text.strip())
        elif p:
            print('文本里找到了子程序（%s），但语句数对不上：文本与 .e 不是同一版本。' % p)
        else:
            print('导出的文本里没有找到这个子程序：' + explain_text_miss(txt_root, cname, m['name']))
    return 0


if __name__ == '__main__':
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(errors='replace')
        except (AttributeError, ValueError):
            pass
    try:
        sys.exit(main(sys.argv))
    except BrokenPipeError:
        sys.exit(0)
    except OSError as ex:
        print('读不了文件：%s（%s）' % (getattr(ex, 'filename', '') or '', ex.strerror or ex))
        sys.exit(2)
