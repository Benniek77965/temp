#!/usr/bin/env python3
# SkinSharp 皮肤文件（.she）解码：python3 she_decode.py 皮肤.she 输出目录
# 格式（由本工程逐字节核对得出）：
#   ".SHE" 4 字节 | 2 字节（版本类）| 解压后大小 uint32 | LZMA 属性 5 字节（lc/lp/pb + 字典大小）| LZMA 数据
# 解压后：偏移 272 起 6 个 uint32 计数（度量 25、颜色 64、文字 15、图片 1、元素 302、其它 13），随后 6 个当年内存指针（无意义）；
#   元素表从偏移 812 起，每条 72 字节＝18 个 int32：
#     [0..3] 图集矩形 x,y,w,h  [4] 透明键色  [5..8] 字形矩形（箭头等）  [9] 字形键色  [10..13] 九宫格边距 左上右下  [14..17] 保留
#   图集：BITMAPINFOHEADER（偏移 23544，40 字节）之后隔 4 字节是 24 位自下而上的像素，宽 161 高 264，品红 #FF00FF 为透明
import lzma, struct, sys, os, zlib
def decode(path):
    d = open(path, 'rb').read()
    assert d[:4] == b'.SHE', '不是 SkinSharp 皮肤文件'
    usize = struct.unpack('<I', d[6:10])[0]
    return lzma.decompress(d[10:15] + struct.pack('<Q', usize) + d[15:], format=lzma.FORMAT_ALONE)
def find_atlas(o):
    for off in range(272, len(o) - 48, 4):
        if struct.unpack_from('<I', o, off)[0] != 40: continue
        w, h, planes, bpp = struct.unpack_from('<iiHH', o, off + 4)
        if planes == 1 and bpp == 24 and 0 < w < 4096 and 0 < h < 8192:
            stride = (w * 3 + 3) & ~3
            for gap in (0, 4, 8):
                if off + 40 + gap + stride * h == len(o): return off, gap, w, h, stride
    raise SystemExit('找不到图集')
def png(path, w, h, rows):  # rows：自上而下，每行 w*3 字节 RGB
    raw = b''.join(b'\x00' + r for r in rows)
    def chunk(t, b): return struct.pack('>I', len(b)) + t + b + struct.pack('>I', zlib.crc32(t + b) & 0xffffffff)
    open(path, 'wb').write(b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b''))
def main(src, out):
    os.makedirs(out, exist_ok=True)
    o = decode(src)
    counts = struct.unpack_from('<6I', o, 272)
    off, gap, w, h, stride = find_atlas(o)
    pix = o[off + 40 + gap:]
    rows = []
    for y in range(h):  # 自下而上存储
        r = pix[(h - 1 - y) * stride:(h - 1 - y) * stride + w * 3]
        rows.append(bytes(b for i in range(0, len(r), 3) for b in (r[i + 2], r[i + 1], r[i])))
    png(os.path.join(out, '图集.png'), w, h, rows)
    with open(os.path.join(out, '元素表.txt'), 'w', encoding='utf-8') as f:
        f.write('# 编号 图集矩形(x,y,w,h) 键色 字形矩形(x,y,w,h) 字形键色 九宫格边距(左,上,右,下)\n')
        for i in range(counts[4]):
            r = struct.unpack_from('<18i', o, 812 + i * 72)
            if r[2] > 0 and r[3] > 0:
                f.write('%3d (%d,%d,%d,%d) #%06X (%d,%d,%d,%d) #%06X (%d,%d,%d,%d)\n' % ((i,) + r[0:4] + (r[4] & 0xFFFFFF,) + r[5:9] + (r[9] & 0xFFFFFF,) + r[10:14]))
    print('解压', len(o), '字节；计数', counts, '；图集', w, 'x', h, '（头在', off, '，与像素相隔', gap, '字节）')
if __name__ == '__main__': main(sys.argv[1], sys.argv[2])
