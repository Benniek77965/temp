#!/usr/bin/env python3
# 检查 XhhSkin.dll：32 位、导出表与 src/xhhskin.def 一致、导入表里没有 Win7 没有的系统函数、不依赖 UCRT / VC 运行库
import subprocess, sys, re, os
dll = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', 'out', 'XhhSkin.dll')
root = os.path.join(os.path.dirname(__file__), '..')
od = os.environ.get('OBJDUMP', 'i686-w64-mingw32-objdump')
txt = subprocess.run([od, '-p', dll], capture_output=True, text=True).stdout
ok = True
def fail(m):
    global ok; ok = False; print('FAIL', m)
if 'file format pei-i386' not in subprocess.run([od, '-f', dll], capture_output=True, text=True).stdout: fail('不是 32 位 DLL')
exp = set()
sec = re.search(r'\[Ordinal/Name Pointer\] Table(.*?)\n\n', txt, re.S)
if sec:
    for line in sec.group(1).splitlines():
        m = re.search(r'\]\s+(\S+)$', line)
        if m: exp.add(m.group(1))
want = set(l.strip() for l in open(os.path.join(root, 'src', 'xhhskin.def'), encoding='utf-8') if l.strip() and not l.strip().startswith((';', 'LIBRARY', 'EXPORTS')))
if exp != want: fail('导出表与 .def 不一致：多 %s 少 %s' % (sorted(exp - want), sorted(want - exp)))
dlls = set(m.lower() for m in re.findall(r'DLL Name: (\S+)', txt))
allowed = {'kernel32.dll', 'user32.dll', 'gdi32.dll', 'advapi32.dll', 'msvcrt.dll'}
if dlls - allowed: fail('依赖了不该依赖的 DLL：%s' % sorted(dlls - allowed))
# Win8 起才有的系统函数（常见的几类）：静态导入会让 Win7 载入失败
win8 = ['GetSystemTimePreciseAsFileTime', 'CreateFile2', 'GetDpiForWindow', 'GetDpiForSystem', 'SetThreadDpiAwarenessContext', 'GetCurrentPackageId',
        'PackageIdFromFullName', 'SetProcessDpiAwarenessContext', 'GetDpiForMonitor', 'SetWindowDisplayAffinity', 'DwmSetWindowAttribute', 'WaitOnAddress',
        'WakeByAddressSingle', 'CreateFileMappingFromApp', 'GetOverlappedResultEx', 'SetThreadDescription', 'GetThreadDescription']
for f in win8:
    if re.search(r'\b%s\b' % f, txt): fail('静态导入了 Win7 没有（或需要按需取地址）的函数 %s' % f)
print('导出 %d 个，依赖 %s' % (len(exp), ', '.join(sorted(dlls))))
print('PASS 检查通过' if ok else 'FAIL 检查不通过')
sys.exit(0 if ok else 1)
