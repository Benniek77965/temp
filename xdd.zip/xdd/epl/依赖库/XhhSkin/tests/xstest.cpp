// XhhSkin 自测：xstest.exe <XhhSkin.dll 路径> <截图目录>
// 在 32 位 Wine（Linux 上 tests/run_all.sh）或真 Windows（tests/自测.bat）里跑。每项打印 PASS / FAIL，最后一行 SUMMARY。
#ifndef UNICODE
#define UNICODE
#endif
#include <windows.h>
#include <vector>
#include <commctrl.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

typedef INT_PTR(__stdcall* Fn)(INT_PTR, INT_PTR, INT_PTR, INT_PTR);
static Fn XS_GetVersion, XS_Set, XS_Attach, XS_Detach, XS_Exclude, XS_Refresh, XS_MessageBox, XS_ScopeBegin, XS_ScopeEnd, XS_GetInfo, XS_GetColor, XS_Census, XS_Shutdown;
static HMODULE g_dll;
#include <string>
// 易语言「ZLIB压缩数据」格式的解压（测试程序用）：4 字节标记 0D 0F 3E 03＋4 字节原长（小端）＋zlib 数据（RFC 1950 头、RFC 1951 deflate、Adler-32 校验）。
// 项目资源里的 DLL（资源\dll_*.Image.dat）就是这样存的，易语言程序写出前先解开；测试程序原来直接拿它当 DLL 用，Windows 报“损坏的映像”（0xc000012f）
namespace ezl {
struct Huff { short count[16]; short symbol[288]; };
struct St {
  const unsigned char* in; size_t n, pos; unsigned bitbuf; int bitcnt; std::vector<unsigned char>* out; size_t cap; bool err;
  int bits(int need) {
    unsigned long long v = bitbuf;
    while (bitcnt < need) { if (pos >= n) { err = true; return 0; } v |= (unsigned long long)in[pos++] << bitcnt; bitcnt += 8; }
    bitbuf = (unsigned)(v >> need); bitcnt -= need;
    return (int)(v & ((1ull << need) - 1));
  }
};
static int construct(Huff& h, const short* len, int n) {  // 由各符号的码长建范式哈夫曼表：返回 0 完整，>0 不完整，<0 超额
  for (int i = 0; i < 16; i++) h.count[i] = 0;
  for (int s = 0; s < n; s++) h.count[len[s]]++;
  if (h.count[0] == n) return 0;
  int left = 1;
  for (int l = 1; l < 16; l++) { left <<= 1; left -= h.count[l]; if (left < 0) return left; }
  short offs[16]; offs[1] = 0;
  for (int l = 1; l < 15; l++) offs[l + 1] = (short)(offs[l] + h.count[l]);
  for (int s = 0; s < n; s++) if (len[s]) h.symbol[offs[len[s]]++] = (short)s;
  return left;
}
static int decode(St& s, const Huff& h) {
  int code = 0, first = 0, index = 0;
  for (int l = 1; l < 16; l++) {
    code |= s.bits(1); if (s.err) return -1;
    int c = h.count[l];
    if (code - c < first) return h.symbol[index + (code - first)];
    index += c; first += c; first <<= 1; code <<= 1;
  }
  return -1;
}
static bool codes(St& s, const Huff& lc, const Huff& dc) {
  static const short lb[29] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
  static const short le[29] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
  static const short db[30] = {1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577};
  static const short de[30] = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};
  std::vector<unsigned char>& o = *s.out;
  for (;;) {
    int sym = decode(s, lc); if (sym < 0) return false;
    if (sym < 256) { if (o.size() >= s.cap) return false; o.push_back((unsigned char)sym); continue; }
    if (sym == 256) return true;
    sym -= 257; if (sym >= 29) return false;
    int len = lb[sym] + s.bits(le[sym]);
    int ds = decode(s, dc); if (ds < 0 || ds >= 30) return false;
    size_t dist = (size_t)(db[ds] + s.bits(de[ds]));
    if (s.err || dist > o.size() || o.size() + (size_t)len > s.cap) return false;
    size_t from = o.size() - dist;
    for (int i = 0; i < len; i++) o.push_back(o[from + i]);  // 允许重叠（距离小于长度时重复前面的字节）
  }
}
static bool inflate(St& s) {
  static Huff flc, fdc; static bool fixedReady = false;
  int last;
  do {
    last = s.bits(1); int type = s.bits(2); if (s.err) return false;
    if (type == 0) {  // 不压缩的块：跳到字节边界，LEN 与 NLEN 互为反码
      s.bitbuf = 0; s.bitcnt = 0;
      if (s.pos + 4 > s.n) return false;
      unsigned len = s.in[s.pos] | (s.in[s.pos + 1] << 8), nlen = s.in[s.pos + 2] | (s.in[s.pos + 3] << 8); s.pos += 4;
      if ((len ^ 0xFFFF) != nlen || s.pos + len > s.n || s.out->size() + len > s.cap) return false;
      s.out->insert(s.out->end(), s.in + s.pos, s.in + s.pos + len); s.pos += len;
    } else if (type == 1) {  // 固定哈夫曼表
      if (!fixedReady) {
        short l[288];
        for (int i = 0; i < 288; i++) l[i] = (short)(i < 144 ? 8 : i < 256 ? 9 : i < 280 ? 7 : 8);  // 固定表的码长（RFC 1951 3.2.6）
        construct(flc, l, 288);
        for (int i = 0; i < 30; i++) l[i] = 5;
        construct(fdc, l, 30); fixedReady = true;
      }
      if (!codes(s, flc, fdc)) return false;
    } else if (type == 2) {  // 动态哈夫曼表
      static const unsigned char order[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15};
      int nlen = s.bits(5) + 257, ndist = s.bits(5) + 1, ncode = s.bits(4) + 4; if (s.err || nlen > 286 || ndist > 30) return false;
      short l[320]; int i;
      for (i = 0; i < 19; i++) l[order[i]] = (short)(i < ncode ? s.bits(3) : 0);
      Huff lc, dc; if (s.err || construct(lc, l, 19) != 0) return false;
      for (i = 0; i < nlen + ndist;) {
        int sym = decode(s, lc); if (sym < 0) return false;
        if (sym < 16) { l[i++] = (short)sym; continue; }
        int rep, val = 0;
        if (sym == 16) { if (i == 0) return false; val = l[i - 1]; rep = 3 + s.bits(2); }
        else if (sym == 17) rep = 3 + s.bits(3);
        else rep = 11 + s.bits(7);
        if (s.err || i + rep > nlen + ndist) return false;
        while (rep--) l[i++] = (short)val;
      }
      if (l[256] == 0) return false;
      int e = construct(lc, l, nlen); if (e < 0 || (e > 0 && nlen - lc.count[0] != 1)) return false;
      e = construct(dc, l + nlen, ndist); if (e < 0 || (e > 0 && ndist - dc.count[0] != 1)) return false;
      if (!codes(s, lc, dc)) return false;
    } else return false;
  } while (!last);
  return true;
}
// 解开 zlib 数据（RFC 1950）：maxOut 为最多解出的字节数；校验 Adler-32
static bool Zlib(const unsigned char* p, size_t n, std::vector<unsigned char>& out, size_t maxOut) {
  if (n < 6 || (p[0] & 0x0F) != 8 || ((p[0] << 8) | p[1]) % 31 != 0 || (p[1] & 0x20)) return false;
  St s = {p, n, 2, 0, 0, &out, maxOut, false}; out.clear();
  if (!inflate(s)) return false;
  if (s.pos + 4 > n) return false;
  unsigned want = ((unsigned)p[s.pos] << 24) | ((unsigned)p[s.pos + 1] << 16) | ((unsigned)p[s.pos + 2] << 8) | p[s.pos + 3];
  unsigned a = 1, b = 0; for (unsigned char c : out) { a = (a + c) % 65521; b = (b + a) % 65521; }
  return ((b << 16) | a) == want;
}
// 易语言「ZLIB压缩数据」：返回 1 解开了，0 不是这种格式，-1 是这种格式但数据坏了
static int EData(const std::vector<unsigned char>& in, std::vector<unsigned char>& out) {
  if (in.size() < 8 || in[0] != 0x0D || in[1] != 0x0F || in[2] != 0x3E || in[3] != 0x03) return 0;
  size_t len = in[4] | (in[5] << 8) | (in[6] << 16) | ((size_t)in[7] << 24);
  if (len == 0 || len > (256u << 20)) return -1;
  if (!Zlib(in.data() + 8, in.size() - 8, out, len) || out.size() != len) return -1;
  return 1;
}
}  // namespace ezl
// 准备要载入的 DLL：是 DLL 原文件（MZ 开头）就原样用；是易语言「ZLIB压缩数据」就解开写到 dst；都不是返回假并说明原因（不再交给 LoadLibrary，免得 Windows 弹“损坏的映像”）
static bool PrepareDll(const std::wstring& src, const std::wstring& dst, std::string& why, bool* unpacked) {
  std::vector<unsigned char> in; *unpacked = false;
  { FILE* f = _wfopen(src.c_str(), L"rb"); if (!f) { why = "打不开这个文件"; return false; }
    unsigned char b[65536]; size_t k; while ((k = fread(b, 1, sizeof b, f)) > 0) in.insert(in.end(), b, b + k); fclose(f); }
  std::vector<unsigned char> dec; const std::vector<unsigned char>* use = &in;
  if (!(in.size() >= 2 && in[0] == 'M' && in[1] == 'Z')) {
    int r = ezl::EData(in, dec);
    if (r == 0) { why = "既不是 DLL 原文件，也不是易语言「ZLIB压缩数据」的格式"; return false; }
    if (r < 0 || dec.size() < 2 || dec[0] != 'M' || dec[1] != 'Z') { why = "是易语言「ZLIB压缩数据」的格式，但解不开或解出来的不是 DLL（文件坏了）"; return false; }
    use = &dec; *unpacked = true;
  }
  if (src == dst && !*unpacked) return true;
  FILE* g = _wfopen(dst.c_str(), L"wb"); if (!g) { why = "写不出解好的 DLL"; return false; }
  bool ok = fwrite(use->data(), 1, use->size(), g) == use->size(); fclose(g);
  if (!ok) why = "解好的 DLL 没写全";
  return ok;
}
static wchar_t g_dllPath[MAX_PATH], g_shots[MAX_PATH];
static const wchar_t* BaseName() {
  const wchar_t* b = g_dllPath;
  for (const wchar_t* p = g_dllPath; *p; ++p)
    if (*p == L'\\' || *p == L'/') b = p + 1;
  return b;
}
static int g_pass, g_fail;

enum { K_NONE = 0, K_ROOT, K_DIALOG, K_CONTAINER, K_PUSH, K_CHECK, K_RADIO, K_GROUP, K_EDIT, K_COMBO, K_COMBOLIST, K_LISTBOX, K_PROGRESS, K_LISTVIEW, K_MENUWND };

static const char* volatile g_last = "开始";
static DWORD WINAPI Watchdog(LPVOID) {  // 卡住时不至于一直挂着：超时打印最后通过的一步后退出
  Sleep(240000);
  printf("FAIL 超时（240 秒），最后一步：%s\n", g_last);
  fflush(stdout);
  ExitProcess(3);
  return 0;
}

static void Check(bool ok, const char* name, const char* detail = "") {
  g_last = name;
  if (ok) {
    ++g_pass;
    printf("PASS %s\n", name);
  } else {
    ++g_fail;
    printf("FAIL %s %s\n", name, detail);
  }
  fflush(stdout);
}

static void Pump(int ms) {
  DWORD end = GetTickCount() + ms;
  do {
    MSG m;
    while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) {
      TranslateMessage(&m);
      DispatchMessageW(&m);
    }
    Sleep(5);
  } while ((int)(end - GetTickCount()) > 0);
}

static uint32_t Px(HWND h, int x, int y) {  // 0x00RRGGBB
  HDC dc = GetDC(h);
  COLORREF c = GetPixel(dc, x, y);
  ReleaseDC(h, dc);
  return ((uint32_t)GetRValue(c) << 16) | ((uint32_t)GetGValue(c) << 8) | GetBValue(c);
}

static int Diff(uint32_t a, uint32_t b) {
  int m = 0;
  for (int s = 0; s < 24; s += 8) {
    int d = abs((int)((a >> s) & 255) - (int)((b >> s) & 255));
    if (d > m) m = d;
  }
  return m;
}

static int Lum(uint32_t c) { return (int)(((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000; }

// 系统（经典）按钮右下角是深色阴影；换肤后是圆角，露出父窗口白底
// 由系统画（没被引擎接管）的样子：与一个一直排除在外的同尺寸、同文字的参照按钮逐点比较（四角、上下边中点、左右边内侧）。
// 不论系统是经典样式（通用控件 5）、视觉样式（通用控件 6）还是 Win11 的圆角按钮，系统画的这两个按钮都一样
static HWND g_refBtn;
static bool LooksSystem(HWND h) {
  RECT r;
  GetClientRect(h, &r);
  int w = r.right, hh = r.bottom;
  POINT pts[] = {{0, 0}, {w - 1, 0}, {0, hh - 1}, {w - 1, hh - 1}, {w / 2, 0}, {w / 2, hh - 1}, {1, hh / 2}, {w - 2, hh / 2}};
  for (const POINT& p : pts)
    if (Diff(Px(h, p.x, p.y), Px(g_refBtn, p.x, p.y)) > 10) return false;
  return true;
}

static char g_buf[512];
static const char* Hex(uint32_t a, uint32_t b = 0xFFFFFFFF) {
  if (b == 0xFFFFFFFF) snprintf(g_buf, sizeof(g_buf), "(got #%06X)", a);
  else snprintf(g_buf, sizeof(g_buf), "(got #%06X want #%06X)", a, b);
  return g_buf;
}

// —— 截图：屏幕上一块区域（DWM 合成后的真实画面，能看到系统切出来的圆角）存成 BMP ——
static void SaveScreenBmp(RECT r, const wchar_t* name) {
  int W = r.right - r.left, H = r.bottom - r.top;
  HDC sdc = GetDC(nullptr);
  HDC mdc = CreateCompatibleDC(sdc);
  BITMAPINFO bi;
  memset(&bi, 0, sizeof(bi));
  bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
  bi.bmiHeader.biWidth = W;
  bi.bmiHeader.biHeight = -H;
  bi.bmiHeader.biPlanes = 1;
  bi.bmiHeader.biBitCount = 32;
  void* bits = nullptr;
  HBITMAP bmp = CreateDIBSection(sdc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
  if (bmp && bits) {
    HGDIOBJ ob = SelectObject(mdc, bmp);
    BitBlt(mdc, 0, 0, W, H, sdc, r.left, r.top, SRCCOPY);
    GdiFlush();
    wchar_t path[MAX_PATH];
    wsprintfW(path, L"%s\\%s.bmp", g_shots, name);
    HANDLE f = CreateFileW(path, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
    if (f != INVALID_HANDLE_VALUE) {
      BITMAPFILEHEADER fh;
      memset(&fh, 0, sizeof(fh));
      fh.bfType = 0x4D42;
      fh.bfOffBits = sizeof(fh) + sizeof(BITMAPINFOHEADER);
      fh.bfSize = fh.bfOffBits + W * H * 4;
      DWORD wr;
      WriteFile(f, &fh, sizeof(fh), &wr, nullptr);
      WriteFile(f, &bi.bmiHeader, sizeof(BITMAPINFOHEADER), &wr, nullptr);
      WriteFile(f, bits, W * H * 4, &wr, nullptr);
      CloseHandle(f);
    }
    SelectObject(mdc, ob);
    DeleteObject(bmp);
  }
  DeleteDC(mdc);
  ReleaseDC(nullptr, sdc);
}

static uint32_t ScreenPx(int x, int y) {
  HDC d = GetDC(nullptr);
  COLORREF c = GetPixel(d, x, y);
  ReleaseDC(nullptr, d);
  return ((uint32_t)GetRValue(c) << 16) | ((uint32_t)GetGValue(c) << 8) | GetBValue(c);
}

// 主显示适配器的名字（UTF-8，写进日志）：基本显示适配器、Hyper-V 视频这类没有显卡加速的，Win11 一代的系统不画圆角
static void PrimaryAdapter(char* out, int cap) {
  DISPLAY_DEVICEW dd;
  for (DWORD i = 0;; ++i) {
    memset(&dd, 0, sizeof(dd));
    dd.cb = sizeof(dd);
    if (!EnumDisplayDevicesW(nullptr, i, &dd, 0)) break;
    if (dd.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE) {
      if (WideCharToMultiByte(CP_UTF8, 0, dd.DeviceString, -1, out, cap, nullptr, nullptr) > 0) return;
      break;
    }
  }
  lstrcpynA(out, "?", cap);
}

static bool Magentaish(uint32_t c) {  // 底板品红（允许被抗锯齿、阴影压暗一些）
  int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
  return r > 100 && b > 100 && g < 90 && (r > b ? r - b : b - r) < 70;
}

// —— 截图：窗口（含非客户区）存成 BMP ——
static void SaveBmp(HWND h, const wchar_t* name) {
  RECT r;
  GetWindowRect(h, &r);
  int W = r.right - r.left, H = r.bottom - r.top;
  HDC wdc = GetWindowDC(h);
  HDC mdc = CreateCompatibleDC(wdc);
  BITMAPINFO bi;
  memset(&bi, 0, sizeof(bi));
  bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
  bi.bmiHeader.biWidth = W;
  bi.bmiHeader.biHeight = -H;
  bi.bmiHeader.biPlanes = 1;
  bi.bmiHeader.biBitCount = 32;
  void* bits = nullptr;
  HBITMAP bmp = CreateDIBSection(wdc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
  HGDIOBJ ob = SelectObject(mdc, bmp);
  BitBlt(mdc, 0, 0, W, H, wdc, 0, 0, SRCCOPY);
  GdiFlush();
  wchar_t path[MAX_PATH];
  wsprintfW(path, L"%s\\%s.bmp", g_shots, name);
  HANDLE f = CreateFileW(path, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
  if (f != INVALID_HANDLE_VALUE) {
    BITMAPFILEHEADER fh;
    memset(&fh, 0, sizeof(fh));
    fh.bfType = 0x4D42;
    fh.bfOffBits = sizeof(fh) + sizeof(BITMAPINFOHEADER);
    fh.bfSize = fh.bfOffBits + W * H * 4;
    DWORD wr;
    WriteFile(f, &fh, sizeof(fh), &wr, nullptr);
    WriteFile(f, &bi.bmiHeader, sizeof(BITMAPINFOHEADER), &wr, nullptr);
    WriteFile(f, bits, W * H * 4, &wr, nullptr);
    CloseHandle(f);
  }
  SelectObject(mdc, ob);
  DeleteObject(bmp);
  DeleteDC(mdc);
  ReleaseDC(h, wdc);
}

// —— 测试窗口 ——
static HFONT g_font;
static HWND g_form, g_btn, g_btnDef, g_btnDis, g_btnImg, g_btnOwner, g_chkImg, g_chkOff, g_chkOn, g_chkInd, g_chkDis, g_chkColored, g_radOff, g_radOn, g_group,
    g_edit, g_editNoBorder, g_editMulti, g_editWsBorder, g_comboList, g_comboEdit, g_list, g_prog, g_lv, g_static, g_panel, g_panelBtn;
static HBRUSH g_yellow;

static HWND g_reBtn;  // 在按钮自己的消息里卸下又接上（见用例）
static int g_reClicks;
static LRESULT CALLBACK FormProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
  switch (m) {
    case WM_COMMAND:
      if (g_reBtn && (HWND)lp == g_reBtn && HIWORD(wp) == BN_CLICKED) {
        XS_Exclude((INT_PTR)g_reBtn, 1, 0, 0);  // 按钮的 WM_LBUTTONUP 还没返回（引擎的子类化记录正在用）时卸下……
        XS_Exclude((INT_PTR)g_reBtn, 0, 0, 0);  // ……马上又接上
        ++g_reClicks;
      }
      break;
    case WM_CTLCOLORSTATIC:
      if ((HWND)lp == g_chkColored) {
        SetTextColor((HDC)wp, RGB(0x80, 0x20, 0x20));
        return (LRESULT)g_yellow;
      }
      break;
    case WM_DRAWITEM: {
      const DRAWITEMSTRUCT* d = (const DRAWITEMSTRUCT*)lp;
      HBRUSH b = CreateSolidBrush(RGB(255, 0, 255));
      FillRect(d->hDC, &d->rcItem, b);
      DeleteObject(b);
      return TRUE;
    }
    default: break;
  }
  return DefWindowProcW(h, m, wp, lp);
}

static HWND Ctl(const wchar_t* cls, const wchar_t* text, DWORD style, DWORD ex, int x, int y, int w, int hgt, HWND parent) {
  HWND h = CreateWindowExW(ex, cls, text, WS_CHILD | WS_VISIBLE | style, x, y, w, hgt, parent, nullptr, GetModuleHandleW(nullptr), nullptr);
  SendMessageW(h, WM_SETFONT, (WPARAM)g_font, FALSE);
  return h;
}

static int CALLBACK FontFound(const LOGFONTW*, const TEXTMETRICW*, DWORD, LPARAM p) {
  *(bool*)p = true;
  return 0;
}

// 模拟闪退现场那段代码：用 ANSI 版子类化、存下原窗口过程后不经 CallWindowProcA 直接调用
static WNDPROC g_thirdOld;
static LRESULT CALLBACK ThirdPartyProcA(HWND h, UINT m, WPARAM wp, LPARAM lp) { return g_thirdOld(h, m, wp, lp); }

static void BuildForm() {
  WNDCLASSW wc;
  memset(&wc, 0, sizeof(wc));
  wc.lpfnWndProc = FormProc;
  wc.hInstance = GetModuleHandleW(nullptr);
  wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
  wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
  wc.lpszClassName = L"XsTestForm";
  RegisterClassW(&wc);
  wc.lpszClassName = L"XsPanel";
  RegisterClassW(&wc);
  wc.hbrBackground = CreateSolidBrush(RGB(0xFF, 0x00, 0xFF));
  wc.lpszClassName = L"XsMagenta";  // 屏幕圆角测试的底板
  RegisterClassW(&wc);
  wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
  g_yellow = CreateSolidBrush(RGB(0xFF, 0xF4, 0xC0));
  // 中文测试字体：Wine 里装的 Droid Sans Fallback（run_all.sh 放进前缀的 Fonts 目录）；真 Windows 用微软雅黑
  const wchar_t* face = L"Microsoft YaHei";
  HDC sdc = GetDC(nullptr);
  LOGFONTW lf;
  memset(&lf, 0, sizeof(lf));
  lf.lfCharSet = DEFAULT_CHARSET;
  lstrcpyW(lf.lfFaceName, L"Droid Sans Fallback");
  bool droid = false;
  EnumFontFamiliesExW(sdc, &lf, FontFound, (LPARAM)&droid, 0);
  ReleaseDC(nullptr, sdc);
  if (droid) face = L"Droid Sans Fallback";
  printf("INFO 测试字体：%s\n", droid ? "Droid Sans Fallback" : "Microsoft YaHei");
  g_font = CreateFontW(-12, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, face);
  g_form = CreateWindowExW(0, L"XsTestForm", L"XhhSkin 自测", WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX, 40, 40, 640, 520, nullptr,
                           nullptr, GetModuleHandleW(nullptr), nullptr);
  g_btn = Ctl(L"Button", L"确定 OK", BS_PUSHBUTTON | WS_TABSTOP, 0, 16, 16, 100, 32, g_form);
  g_refBtn = Ctl(L"Button", L"确定 OK", BS_PUSHBUTTON, 0, 16, 436, 100, 32, g_form);  // 参照：一直排除在外，系统画的样子
  g_btnDef = Ctl(L"Button", L"默认 Default", BS_DEFPUSHBUTTON | WS_TABSTOP, 0, 128, 16, 110, 32, g_form);
  g_btnDis = Ctl(L"Button", L"禁止 Off", BS_PUSHBUTTON, 0, 250, 16, 100, 32, g_form);
  EnableWindow(g_btnDis, FALSE);
  g_btnImg = Ctl(L"Button", L"", BS_PUSHBUTTON | BS_ICON, 0, 362, 16, 40, 32, g_form);
  SendMessageW(g_btnImg, BM_SETIMAGE, IMAGE_ICON, (LPARAM)LoadIcon(nullptr, IDI_INFORMATION));
  g_btnOwner = Ctl(L"Button", L"自绘", BS_OWNERDRAW, 0, 414, 16, 60, 32, g_form);
  g_chkOff = Ctl(L"Button", L"选择框 Off", BS_AUTOCHECKBOX | WS_TABSTOP, 0, 16, 64, 120, 24, g_form);
  g_chkImg = Ctl(L"Button", L"", BS_AUTOCHECKBOX | BS_ICON, 0, 560, 60, 40, 32, g_form);
  SendMessageW(g_chkImg, BM_SETIMAGE, IMAGE_ICON, (LPARAM)LoadIcon(nullptr, IDI_WARNING));
  g_chkOn = Ctl(L"Button", L"选中 On", BS_AUTOCHECKBOX, 0, 140, 64, 110, 24, g_form);
  SendMessageW(g_chkOn, BM_SETCHECK, BST_CHECKED, 0);
  g_chkInd = Ctl(L"Button", L"不确定", BS_AUTO3STATE, 0, 254, 64, 100, 24, g_form);
  SendMessageW(g_chkInd, BM_SETCHECK, BST_INDETERMINATE, 0);
  g_chkDis = Ctl(L"Button", L"禁止", BS_AUTOCHECKBOX, 0, 358, 64, 80, 24, g_form);
  SendMessageW(g_chkDis, BM_SETCHECK, BST_CHECKED, 0);
  EnableWindow(g_chkDis, FALSE);
  g_chkColored = Ctl(L"Button", L"自定颜色", BS_AUTOCHECKBOX, 0, 444, 64, 110, 24, g_form);
  g_radOff = Ctl(L"Button", L"单选 A", BS_AUTORADIOBUTTON | WS_GROUP, 0, 16, 96, 100, 24, g_form);
  g_radOn = Ctl(L"Button", L"单选 B", BS_AUTORADIOBUTTON, 0, 120, 96, 100, 24, g_form);
  SendMessageW(g_radOn, BM_SETCHECK, BST_CHECKED, 0);
  g_group = Ctl(L"Button", L"分组框 Group", BS_GROUPBOX, 0, 16, 128, 290, 120, g_form);
  g_edit = Ctl(L"Edit", L"文本 Text", ES_AUTOHSCROLL | WS_TABSTOP, WS_EX_CLIENTEDGE, 28, 152, 200, 24, g_form);
  g_editNoBorder = Ctl(L"Edit", L"无边框", ES_AUTOHSCROLL, 0, 28, 184, 120, 20, g_form);
  g_editMulti = Ctl(L"Edit", L"多行\r\n第二行\r\n第三行\r\n第四行\r\n第五行", ES_MULTILINE | WS_VSCROLL, WS_EX_CLIENTEDGE, 320, 128, 150, 70, g_form);
  g_editWsBorder = Ctl(L"Edit", L"WS_BORDER", ES_AUTOHSCROLL, 0, 320, 204, 150, 22, g_form);
  SetWindowLongW(g_editWsBorder, GWL_STYLE, GetWindowLongW(g_editWsBorder, GWL_STYLE) | WS_BORDER);
  SetWindowPos(g_editWsBorder, nullptr, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
  g_comboList = Ctl(L"ComboBox", L"", CBS_DROPDOWNLIST | WS_VSCROLL | WS_TABSTOP, 0, 16, 260, 180, 200, g_form);
  SendMessageW(g_comboList, CB_ADDSTRING, 0, (LPARAM)L"选项一 First");
  SendMessageW(g_comboList, CB_ADDSTRING, 0, (LPARAM)L"选项二 Second");
  SendMessageW(g_comboList, CB_SETCURSEL, 0, 0);
  g_comboEdit = Ctl(L"ComboBox", L"可编辑", CBS_DROPDOWN | WS_VSCROLL, 0, 210, 260, 160, 200, g_form);
  SendMessageW(g_comboEdit, CB_ADDSTRING, 0, (LPARAM)L"甲");
  g_list = Ctl(L"ListBox", L"", LBS_NOTIFY | WS_VSCROLL | WS_BORDER, 0, 16, 300, 180, 90, g_form);
  SendMessageW(g_list, LB_ADDSTRING, 0, (LPARAM)L"账号 one");
  SendMessageW(g_list, LB_ADDSTRING, 0, (LPARAM)L"账号 two");
  SendMessageW(g_list, LB_ADDSTRING, 0, (LPARAM)L"账号 three");
  SendMessageW(g_list, LB_SETCURSEL, 1, 0);
  g_prog = Ctl(PROGRESS_CLASSW, L"", 0, 0, 210, 304, 200, 20, g_form);
  SendMessageW(g_prog, PBM_SETRANGE32, 0, 100);
  SendMessageW(g_prog, PBM_SETPOS, 50, 0);
  g_lv = Ctl(WC_LISTVIEWW, L"", LVS_REPORT, WS_EX_CLIENTEDGE, 210, 334, 250, 80, g_form);
  LVCOLUMNW col;
  memset(&col, 0, sizeof(col));
  col.mask = LVCF_TEXT | LVCF_WIDTH;
  col.cx = 120;
  col.pszText = (LPWSTR)L"列";
  SendMessageW(g_lv, LVM_INSERTCOLUMNW, 0, (LPARAM)&col);
  g_static = Ctl(L"Static", L"标签 Label", 0, 0, 480, 304, 120, 20, g_form);
  g_panel = Ctl(L"XsPanel", L"", 0, 0, 480, 340, 140, 80, g_form);
  g_panelBtn = Ctl(L"Button", L"面板里", BS_PUSHBUTTON, 0, 10, 10, 100, 28, g_panel);
  ShowWindow(g_form, SW_SHOWNORMAL);
  UpdateWindow(g_form);
  Pump(300);
}

static INT_PTR Kind(HWND h) { return XS_GetInfo(14, (INT_PTR)h, 0, 0); }
static WNDPROC g_padOrig;
struct MenuProbe {  // 菜单测试：TrackPopupMenu 阻塞，定时器在菜单循环里分步取样、操作
  HMENU pm;
  int step;
  HWND wnd;
  INT_PTR kind;
  bool ownerDraw, forced, rtl, mirrored;
  uint32_t bg, frame, hover, sep;
  int ink0, check, radio, arrow;
  int rCheckRight, rCheckLeft, rArrowLeft, rArrowRight, rInkRight;  // 从右到左：勾选在右、箭头在左、文字靠右
  int settle;  // 发现菜单窗口后先等几拍：真机默认开着菜单淡入，约 200 毫秒内是半透明的，这时取的颜色不准
};
static MenuProbe g_mp;
static int DarkIn(const RECT& r, int lumMax) {
  int n = 0;
  for (int y = r.top; y < r.bottom; ++y)
    for (int x = r.left; x < r.right; ++x)
      if (Lum(ScreenPx(x, y)) < lumMax) ++n;
  return n;
}
static VOID CALLBACK MenuProbeTimer(HWND, UINT, UINT_PTR, DWORD) {
  MenuProbe& m = g_mp;
  if (m.rtl) {  // 从右到左的菜单（阿拉伯语时黑月菜单带 TPM_LAYOUTRTL）：只取样、然后关掉
    HWND mw = FindWindowW(L"#32768", nullptr);
    if (m.step == 0 && mw && IsWindowVisible(mw)) {
      if (m.settle++ < 3) return;
      m.wnd = mw;
      m.mirrored = (GetWindowLongW(mw, GWL_EXSTYLE) & WS_EX_LAYOUTRTL) != 0;
      RECT r0, r2, r6;
      GetMenuItemRect(nullptr, m.pm, 0, &r0);
      GetMenuItemRect(nullptr, m.pm, 2, &r2);
      GetMenuItemRect(nullptr, m.pm, 6, &r6);
      RECT cr = {r2.right - 26, r2.top + 3, r2.right - 10, r2.bottom - 3}, cl = {r2.left + 10, r2.top + 3, r2.left + 26, r2.bottom - 3};
      RECT al = {r6.left + 8, r6.top + 3, r6.left + 24, r6.bottom - 3}, ar = {r6.right - 24, r6.top + 3, r6.right - 8, r6.bottom - 3};
      RECT ir = {r0.right - 100, r0.top + 2, r0.right - 30, r0.bottom - 2};
      m.rCheckRight = DarkIn(cr, 120);
      m.rCheckLeft = DarkIn(cl, 120);
      m.rArrowLeft = DarkIn(al, 140);
      m.rArrowRight = DarkIn(ar, 140);
      m.rInkRight = DarkIn(ir, 120);
      m.step = 1;
    } else if (m.step >= 1 || m.step++ > 20) {
      EndMenu();
    }
    return;
  }
  if (m.step == 0) {
    HWND mw = FindWindowW(L"#32768", nullptr);
    if (!mw || !IsWindowVisible(mw)) return;  // 还没弹出来：下一拍再看
    if (m.settle++ < 3) return;               // 等淡入结束
    m.wnd = mw;
    m.kind = Kind(mw);
    MENUITEMINFOW mi;
    memset(&mi, 0, sizeof(mi));
    mi.cbSize = sizeof(mi);
    mi.fMask = MIIM_FTYPE;
    m.ownerDraw = GetMenuItemInfoW(m.pm, 0, TRUE, &mi) && (mi.fType & MFT_OWNERDRAW);
    RECT r0, r2, r3, r4, r6, wr;
    GetMenuItemRect(nullptr, m.pm, 0, &r0);
    GetMenuItemRect(nullptr, m.pm, 2, &r2);
    GetMenuItemRect(nullptr, m.pm, 3, &r3);
    GetMenuItemRect(nullptr, m.pm, 4, &r4);
    GetMenuItemRect(nullptr, m.pm, 6, &r6);
    GetWindowRect(mw, &wr);
    m.bg = ScreenPx(r0.right - 6, (r0.top + r0.bottom) / 2);
    m.frame = ScreenPx(wr.left, (wr.top + wr.bottom) / 2);
    RECT t0 = {r0.left + 30, r0.top + 2, r0.left + 100, r0.bottom - 2};
    m.ink0 = DarkIn(t0, 120);
    RECT g2 = {r2.left + 10, r2.top + 3, r2.left + 26, r2.bottom - 3};
    m.check = DarkIn(g2, 120);
    RECT g3 = {r3.left + 10, r3.top + 3, r3.left + 26, r3.bottom - 3};
    m.radio = DarkIn(g3, 120);
    m.sep = ScreenPx((r4.left + r4.right) / 2, r4.top + (r4.bottom - r4.top) / 2);
    RECT a6 = {r6.right - 24, r6.top + 3, r6.right - 8, r6.bottom - 3};
    m.arrow = DarkIn(a6, 140);
    PostMessageW(mw, WM_KEYDOWN, VK_DOWN, 0);  // 键盘选中第一项
    m.step = 1;
  } else if (m.step == 1) {
    RECT r0;
    GetMenuItemRect(nullptr, m.pm, 0, &r0);
    m.hover = ScreenPx(r0.right - 8, (r0.top + r0.bottom) / 2);
    SaveBmp(m.wnd, L"菜单");  // 自测结果里留一张：键盘选中第一项时的整个菜单
    PostMessageW(m.wnd, WM_CHAR, L'a', 0);  // 助记键：自绘项靠引擎回答 WM_MENUCHAR
    m.step = 2;
  } else if (m.step++ > 6) {
    m.forced = true;  // 兜底：助记键没起作用时关掉菜单，免得测试挂住
    EndMenu();
  }
}
static LRESULT CALLBACK PadEditProc(HWND h, UINT m, WPARAM w, LPARAM l) {  // 模拟胶囊输入框：撑高上下非客户区让文字垂直居中（上下各 12、左右各 2）
  if (m == WM_NCCALCSIZE) {
    LRESULT r = CallWindowProcW(g_padOrig, h, m, w, l);
    RECT* rc = w ? &((NCCALCSIZE_PARAMS*)l)->rgrc[0] : (RECT*)l;
    rc->left += 2;
    rc->right -= 2;
    rc->top += 12;
    rc->bottom -= 12;
    return r;
  }
  return CallWindowProcW(g_padOrig, h, m, w, l);
}

static bool g_seenDlg;
static INT_PTR g_dlgKind, g_dlgBtnKind, g_dlgOwn;
static uint32_t g_dlgFooter, g_dlgContent;
static HWND g_dlg;

static BOOL CALLBACK FindDlg(HWND h, LPARAM) {
  wchar_t cls[16];
  if (GetClassNameW(h, cls, 16) && lstrcmpW(cls, L"#32770") == 0 && IsWindowVisible(h)) {
    g_dlg = h;
    return FALSE;
  }
  return TRUE;
}

static int g_dlgAnswer = IDCANCEL;

// 自己在 WM_PAINT 里画东西的简单对话框（模拟输入框一类）：引擎只画底色，内容必须保留
static INT_PTR CALLBACK PaintDlgProc(HWND h, UINT m, WPARAM, LPARAM) {
  if (m == WM_PAINT) {
    PAINTSTRUCT ps;
    HDC dc = BeginPaint(h, &ps);
    RECT r = {4, 4, 40, 20};
    HBRUSH b = CreateSolidBrush(RGB(255, 0, 255));
    FillRect(dc, &r, b);
    DeleteObject(b);
    EndPaint(h, &ps);
    return TRUE;
  }
  return FALSE;
}
static HWND MakeDialog(int edits, HWND* okBtn) {
  HWND d = CreateWindowExW(WS_EX_DLGMODALFRAME, WC_DIALOG, L"对话框", WS_POPUP | WS_CAPTION | WS_SYSMENU, 200, 200, 300, 200, g_form, nullptr, GetModuleHandleW(nullptr), nullptr);
  SetWindowLongPtrW(d, DWLP_DLGPROC, (LONG_PTR)PaintDlgProc);
  Ctl(L"Static", L"请输入：", 0, 0, 10, 30, 100, 20, d);
  for (int i = 0; i < edits; ++i) Ctl(L"Edit", L"", ES_AUTOHSCROLL, WS_EX_CLIENTEDGE, 10, 55 + i * 26, 200, 22, d);
  HWND ok = Ctl(L"Button", L"确定", BS_DEFPUSHBUTTON, 0, 120, 130, 70, 26, d);
  Ctl(L"Button", L"取消", BS_PUSHBUTTON, 0, 200, 130, 70, 26, d);
  if (okBtn) *okBtn = ok;
  return d;
}
static void CALLBACK DlgTimer(HWND, UINT, UINT_PTR id, DWORD) {
  g_dlg = nullptr;
  EnumThreadWindows(GetCurrentThreadId(), FindDlg, 0);
  if (!g_dlg) return;
  KillTimer(nullptr, id);
  g_seenDlg = true;
  UpdateWindow(g_dlg);
  g_dlgKind = XS_GetInfo(4, (INT_PTR)g_dlg, 0, 0);
  g_dlgOwn = XS_GetInfo(19, (INT_PTR)g_dlg, 0, 0);
  for (HWND c = GetWindow(g_dlg, GW_CHILD); c; c = GetWindow(c, GW_HWNDNEXT)) {
    wchar_t cls[16];
    GetClassNameW(c, cls, 16);
    if (lstrcmpiW(cls, L"Button") == 0) g_dlgBtnKind = Kind(c);
  }
  RECT rc;
  GetClientRect(g_dlg, &rc);
  g_dlgFooter = Px(g_dlg, 3, rc.bottom - 3);
  g_dlgContent = Px(g_dlg, 3, 3);
  SaveBmp(g_dlg, L"信息框");
  PostMessageW(g_dlg, WM_COMMAND, g_dlgAnswer, 0);
}

// —— 另一个界面线程 ——
static HWND g_tForm;
static HANDLE g_tReady;
static DWORD WINAPI UiThread(LPVOID) {
  g_tForm = CreateWindowExW(0, L"XsTestForm", L"线程窗口", WS_OVERLAPPEDWINDOW, 700, 60, 240, 120, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
  Ctl(L"Button", L"线程按钮", BS_PUSHBUTTON, 0, 10, 10, 100, 28, g_tForm);
  ShowWindow(g_tForm, SW_SHOWNOACTIVATE);
  INT_PTR ok = XS_Attach((INT_PTR)g_tForm, 0, 0, 0);
  SetEvent(g_tReady);
  MSG m;
  while (GetMessageW(&m, nullptr, 0, 0) > 0) {
    TranslateMessage(&m);
    DispatchMessageW(&m);
  }
  DestroyWindow(g_tForm);
  return (DWORD)ok;
}
static INT_PTR g_crossResult, g_crossErr;
static DWORD WINAPI CrossAttach(LPVOID) {
  g_crossResult = XS_Attach((INT_PTR)g_form, 0, 0, 0);
  g_crossErr = XS_GetInfo(11, 0, 0, 0);
  return 0;
}

static bool Load(const wchar_t* path) {
  g_dll = LoadLibraryW(path);
  if (!g_dll) return false;
#define GET(n) n = (Fn)(void*)GetProcAddress(g_dll, #n)
  GET(XS_GetVersion);
  GET(XS_Set);
  GET(XS_Attach);
  GET(XS_Detach);
  GET(XS_Exclude);
  GET(XS_Refresh);
  GET(XS_MessageBox);
  GET(XS_ScopeBegin);
  GET(XS_ScopeEnd);
  GET(XS_GetInfo);
  GET(XS_GetColor);
  GET(XS_Census);
  GET(XS_Shutdown);
  return XS_GetVersion && XS_Set && XS_Attach && XS_Detach && XS_Exclude && XS_Refresh && XS_MessageBox && XS_ScopeBegin && XS_ScopeEnd && XS_GetInfo &&
         XS_GetColor && XS_Census && XS_Shutdown;
}

// 复现主窗口“开启快捷键”上方色条：面板上沿 8 像素不画（被别的窗口盖住的那条），另一个窗口盖在那里
static void PanelDraw(HWND h, HDC dc) {
  RECT r;
  GetClientRect(h, &r);
  r.top = 8;
  FillRect(dc, &r, (HBRUSH)GetStockObject(WHITE_BRUSH));
}
static LRESULT CALLBACK PanelProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
  if (m == WM_ERASEBKGND) return 1;
  if (m == WM_PRINTCLIENT) { PanelDraw(h, (HDC)wp); return 0; }
  if (m == WM_PAINT) { PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps); PanelDraw(h, dc); EndPaint(h, &ps); return 0; }
  return DefWindowProcW(h, m, wp, lp);
}
// 像易语言图片框：WM_CTLCOLORBTN 不管（默认画刷），WM_CTLCOLORSTATIC 给出自己的底色画刷（绿色），打印时什么都不画
static HBRUSH g_greenBr;
static LRESULT CALLBACK StaticOnlyProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
  if (m == WM_ERASEBKGND) return 1;
  if (m == WM_PRINTCLIENT) return 0;
  if (m == WM_CTLCOLORSTATIC) return (LRESULT)g_greenBr;
  if (m == WM_PAINT) {
    PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps); FillRect(dc, &ps.rcPaint, g_greenBr); EndPaint(h, &ps); return 0;
  }
  return DefWindowProcW(h, m, wp, lp);
}
// 上沿 20 像素不画的面板（选择框的方框整个落在没画的那块里）
static LRESULT CALLBACK Panel20Proc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
  if (m == WM_ERASEBKGND) return 1;
  if (m == WM_PRINTCLIENT || m == WM_PAINT) {
    PAINTSTRUCT ps;
    HDC dc = m == WM_PAINT ? BeginPaint(h, &ps) : (HDC)wp;
    RECT r;
    GetClientRect(h, &r);
    r.top = 20;
    FillRect(dc, &r, (HBRUSH)GetStockObject(WHITE_BRUSH));
    if (m == WM_PAINT) EndPaint(h, &ps);
    return 0;
  }
  return DefWindowProcW(h, m, wp, lp);
}
// 像易语言外形框：屏幕上画白底，擦底与打印（WM_PRINTCLIENT）什么都不画，窗口类没有底色刷
static LRESULT CALLBACK BlankProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
  if (m == WM_ERASEBKGND) return 1;
  if (m == WM_PRINTCLIENT) return 0;
  if (m == WM_PAINT) {
    PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps); FillRect(dc, &ps.rcPaint, (HBRUSH)GetStockObject(WHITE_BRUSH)); EndPaint(h, &ps); return 0;
  }
  return DefWindowProcW(h, m, wp, lp);
}

int wmain(int argc, wchar_t** argv) {
  if (argc < 3) {
    printf("usage: xstest <XhhSkin.dll> <shots dir>\n");
    return 2;
  }
  CloseHandle(CreateThread(nullptr, 0, Watchdog, nullptr, 0, nullptr));
  lstrcpynW(g_dllPath, argv[1], MAX_PATH);
  lstrcpynW(g_shots, argv[2], MAX_PATH);
  {  // 自测.bat 给的是项目资源 资源\dll_XhhSkin.Image.dat：那是易语言「ZLIB压缩数据」，先解开到截图目录（原来直接 LoadLibrary，Windows 报“损坏的映像”0xc000012f）
    unsigned char mz[2] = {0, 0}; FILE* f = _wfopen(argv[1], L"rb"); if (f) { if (fread(mz, 1, 2, f) != 2) mz[0] = 0; fclose(f); }
    if (mz[0] != 'M' || mz[1] != 'Z') {
      wchar_t full[MAX_PATH]; std::wstring dir = GetFullPathNameW(argv[2], MAX_PATH, full, nullptr) ? std::wstring(full) : std::wstring(argv[2]);
      CreateDirectoryW(dir.c_str(), nullptr); std::wstring dst = dir + L"\\XhhSkin.dll";
      std::string why; bool unpacked = false;
      auto u8 = [](const std::wstring& w) { int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, nullptr, 0, nullptr, nullptr); std::string s(n > 1 ? n - 1 : 0, '\0'); if (n > 1) WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, &s[0], n, nullptr, nullptr); return s; };  // 日志是 UTF-8（同下面普查结果的写法）
      if (!PrepareDll(argv[1], dst, why, &unpacked) || dst.size() >= MAX_PATH) { printf("FAIL 载入 DLL：%s（%s）\n", u8(argv[1]).c_str(), why.empty() ? "路径太长" : why.c_str()); return 1; }
      printf("INFO %s 是易语言「ZLIB压缩数据」，已解开成 %s\n", u8(argv[1]).c_str(), u8(dst).c_str()); lstrcpynW(g_dllPath, dst.c_str(), MAX_PATH);
    }
  }
  INITCOMMONCONTROLSEX icc = {sizeof(icc), ICC_PROGRESS_CLASS | ICC_LISTVIEW_CLASSES};
  InitCommonControlsEx(&icc);
  Check(Load(g_dllPath), "载入 DLL、取到全部 13 个接口");
  if (!g_dll) return 1;
  Check(XS_GetVersion(0, 0, 0, 0) == 0x00010000, "版本 1.0.0");
  Check(XS_GetInfo(12, 0, 0, 0) == 1, "引擎可用（子类化接口都取到了）");
  printf("INFO 系统版本号=%d  DWM 能力=%d\n", (int)XS_GetInfo(7, 0, 0, 0), (int)XS_GetInfo(8, 0, 0, 0));
#ifdef XS_TEST_V6
  printf("INFO 测试程序：带视觉样式清单（通用控件 6.0，xstest_v6.exe）\n");
#else
  printf("INFO 测试程序：不带视觉样式清单（通用控件 5，xstest.exe）\n");
#endif

  // 易语言的调用方式：调用桩_4参数（程序集1）的机器码，按易语言子程序的框架拼起来调用
  {
    static const unsigned char stub[] = {0x55, 0x8B, 0xEC, 0x83, 0xEC, 0x20, 139, 69, 8, 133, 192, 116, 14, 255, 117, 24, 255, 117, 20, 255, 117, 16, 255, 117, 12, 255, 208, 201, 194, 20, 0};
    void* mem = VirtualAlloc(nullptr, 4096, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    memcpy(mem, stub, sizeof(stub));
    typedef INT_PTR(__stdcall * Stub)(INT_PTR, INT_PTR, INT_PTR, INT_PTR, INT_PTR);
    Stub call = (Stub)mem;
    Check(call((INT_PTR)XS_GetVersion, 0, 0, 0, 0) == 0x00010000, "调用桩：版本号");
    Check(call((INT_PTR)XS_GetInfo, 1, 0, 0, 0) == 0x00010000, "调用桩：XS_GetInfo 1");
    Check(call((INT_PTR)XS_GetColor, 1, 0, 0, 0) == (INT_PTR)RGB(255, 255, 255), "调用桩：4 个参数按顺序到达（颜色令牌 1＝白）");
    Check(call(0, 1, 2, 3, 4) == 0, "调用桩：地址为 0 时返回 0，不崩溃");
    VirtualFree(mem, 0, MEM_RELEASE);
  }

  BuildForm();
  XS_Exclude((INT_PTR)g_refBtn, 1, 0, 0);
  bool systemBefore = LooksSystem(g_btn);
  Check(XS_Attach((INT_PTR)g_form, 0, 0, 0) == 1, "接入测试窗口");
  Pump(300);
  Check(XS_GetInfo(4, (INT_PTR)g_form, 0, 0) == 2, "测试窗口是根窗口");
  wchar_t census[1024];
  XS_Census((INT_PTR)g_form, (INT_PTR)census, 1024, 0);
  char cu8[2048];
  WideCharToMultiByte(CP_UTF8, 0, census, -1, cu8, sizeof(cu8), nullptr, nullptr);
  printf("INFO 普查：%s\n", cu8);
  Check(wcsstr(census, L"Button x") && wcsstr(census, L"Edit x") && wcsstr(census, L"ComboBox x") && wcsstr(census, L"ListBox x") && wcsstr(census, L"msctls_progress32 x"),
        "普查：按钮、编辑框、组合框、列表框、进度条都已换肤");
  Check(wcsstr(census, L"skipped: ") && wcsstr(census, L"Static x"), "普查：静态标签没有换肤");
  Check(wcsstr(census, L"; comctl: ") != nullptr, "普查：带上按钮所属的通用控件版本（真机日志用来判断滚动条等是不是新样式）");
#ifdef XS_TEST_V6
  Check(wcsstr(census, L"; comctl: 6") != nullptr, "普查：带视觉样式清单时，按钮属于通用控件 6.0（引擎按类窗口过程所在模块判断）");
#else
  Check(wcsstr(census, L"; comctl: 5") != nullptr, "普查：没有视觉样式清单时，按钮属于通用控件 5");
#endif
  {
    INT_PTR subs = XS_GetInfo(16, 0, 0, 0), roots = XS_GetInfo(2, 0, 0, 0);
    Check(XS_Attach((INT_PTR)g_form, 0, 0, 0) == 1 && XS_GetInfo(16, 0, 0, 0) == subs && XS_GetInfo(2, 0, 0, 0) == roots,
          "重复接入同一窗口：返回成功、只重扫，不重复子类化（易语言非模态载入后直接接入、范围也接过时就是这样）");
  }  // —— ANSI 窗口（易语言运行库建的窗口与组件都是 ANSI）：换肤不能改窗口的字符集 ——
  // 真机闪退：comctl32 的 SetWindowSubclass 把 ANSI 组件变成 Unicode，之后有代码用 ANSI 版取窗口过程，拿到 0xFFFF0xxx 转换句柄还直接调用，
  // 跳到无效地址（事件日志：异常 0xc000041d、出错地址 0xffff0bc5）。下面原样模拟那段代码
  {
    // 先建在一个引擎不管的临时窗口里，量“接上之前”的字符集，再置父进换肤的窗体（一画就接上，见前面置父的测试）。
    // 通用控件 6.0 下标准控件类只注册了 W 版，CreateWindowExA 建出来的本来就是 Unicode 窗口——要求的是“接上前后字符集不变”
    HWND tmp = CreateWindowExW(0, L"XsTestForm", L"tmp", WS_POPUP, 0, 0, 10, 10, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    HWND ab = CreateWindowExA(0, "Button", "ANSI OK", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 130, 436, 90, 32, tmp, nullptr, GetModuleHandleW(nullptr), nullptr);
    bool uniBefore = IsWindowUnicode(ab) != FALSE;
    SetParent(ab, g_form);
    DestroyWindow(tmp);
    RedrawWindow(ab, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
    Pump(80);
    printf("INFO CreateWindowExA 建的按钮：接上之前是 %s 窗口\n", uniBefore ? "Unicode（通用控件 6.0 的控件类只有 W 版）" : "ANSI");
    Check(Kind(ab) == K_PUSH, "CreateWindowExA 建的按钮（易语言运行库的组件都这样建）：照样接上换肤");
    Check((IsWindowUnicode(ab) != FALSE) == uniBefore, "接上前后窗口的字符集不变（以前 comctl32 子类化会把 ANSI 窗口变成 Unicode）");
    LONG_PTR pa = uniBefore ? GetWindowLongPtrW(ab, GWLP_WNDPROC) : GetWindowLongPtrA(ab, GWLP_WNDPROC);
    Check(((ULONG_PTR)pa & 0xFFFF0000u) != 0xFFFF0000u, "按窗口原来的字符集取到的窗口过程是真地址，不是只能交给 CallWindowProc 的 0xFFFF 转换句柄（闪退根因）", Hex((uint32_t)pa));
    LRESULT len = ((WNDPROC)pa)(ab, WM_GETTEXTLENGTH, 0, 0);
    Check(len == 7, "直接调用取到的窗口过程（不经 CallWindowProc）：正常返回");
    char abuf[32] = {0};
    if (!uniBefore) {
      g_thirdOld = (WNDPROC)SetWindowLongPtrA(ab, GWLP_WNDPROC, (LONG_PTR)ThirdPartyProcA);
      SetWindowTextA(ab, "ANSI 2");
      RedrawWindow(ab, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
      Pump(30);
      GetWindowTextA(ab, abuf, 32);
      Check(lstrcmpA(abuf, "ANSI 2") == 0 && Kind(ab) == K_PUSH, "接上之后别人再用 ANSI 版子类化、直接调用存下的原过程：照常工作、照常换肤");
      XS_Detach((INT_PTR)ab, 0, 0, 0);
      Check(Kind(ab) == 0 && GetWindowLongPtrA(ab, GWLP_WNDPROC) == (LONG_PTR)ThirdPartyProcA, "卸下时外层还套着别人的子类化：不动这条链，只转交");
      SetWindowTextA(ab, "ANSI 3");
      GetWindowTextA(ab, abuf, 32);
      Check(lstrcmpA(abuf, "ANSI 3") == 0, "卸下后消息照常经过整条链");
    } else {
      printf("INFO 这个按钮本来就是 Unicode 窗口：“别人用 ANSI 版子类化后直接调用”这一组只在 ANSI 窗口上有意义（通用控件 5 的测试程序里做）\n");
    }
    DestroyWindow(ab);
    Pump(30);
    HWND ub = CreateWindowExW(0, L"Button", L"Unicode", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 230, 436, 90, 32, g_form, nullptr, GetModuleHandleW(nullptr), nullptr);
    Pump(50);
    LONG_PTR pw = GetWindowLongPtrW(ub, GWLP_WNDPROC);
    Check(Kind(ub) == K_PUSH && IsWindowUnicode(ub) && ((ULONG_PTR)pw & 0xFFFF0000u) != 0xFFFF0000u, "Unicode 窗口（黑月的组件）接上后仍是 Unicode，W 版取到真地址");
    DestroyWindow(ub);
    Pump(30);
  }

  // 种类
  Check(Kind(g_btn) == K_PUSH && Kind(g_btnDef) == K_PUSH && Kind(g_btnDis) == K_PUSH, "种类：按钮");
  Check(Kind(g_chkOff) == K_CHECK && Kind(g_chkInd) == K_CHECK && Kind(g_radOn) == K_RADIO, "种类：选择框 / 单选框");
  Check(Kind(g_group) == K_GROUP, "种类：分组框");
  printf("INFO 多行编辑框 style=%08lX ex=%08lX kind=%d；单行 style=%08lX ex=%08lX kind=%d\n", GetWindowLongW(g_editMulti, GWL_STYLE), GetWindowLongW(g_editMulti, GWL_EXSTYLE),
         (int)Kind(g_editMulti), GetWindowLongW(g_edit, GWL_STYLE), GetWindowLongW(g_edit, GWL_EXSTYLE), (int)Kind(g_edit));
  Check(Kind(g_edit) == K_EDIT && Kind(g_editMulti) == K_EDIT, "种类：有边框的编辑框（易语言编辑框的凹入式边框）");
  {
    int b = 0;
    RECT wr;
    GetWindowRect(g_editWsBorder, &wr);
    POINT o = {0, 0};
    ClientToScreen(g_editWsBorder, &o);
    b = o.y - wr.top;
    printf("INFO WS_BORDER 单线边框编辑框：非客户区边框 %d 像素，种类 %d（有非客户区边框就换肤；Wine 9 的多行编辑框会去掉 WS_BORDER、把边画在客户区里，引擎不碰）\n", b, (int)Kind(g_editWsBorder));
    Check(b > 0 ? Kind(g_editWsBorder) == K_EDIT : Kind(g_editWsBorder) == K_NONE, "单线边框编辑框：有非客户区边框才换肤");
  }
  Check(Kind(g_editNoBorder) == K_NONE, "种类：无边框编辑框不换肤（外观归程序自己）");
  Check(Kind(g_comboList) == K_COMBO && Kind(g_comboEdit) == K_COMBO, "种类：组合框");
  {
    COMBOBOXINFO ci = {sizeof(ci)};
    GetComboBoxInfo(g_comboList, &ci);
    Check(ci.hwndList && Kind(ci.hwndList) == K_COMBOLIST, "种类：组合框的下拉列表一并接上");
  }
  Check(Kind(g_list) == K_LISTBOX && Kind(g_prog) == K_PROGRESS && Kind(g_lv) == K_LISTVIEW, "种类：列表框 / 进度条 / 超级列表框");
  Check(Kind(g_btnOwner) == K_NONE, "种类：自绘按钮不换肤");
  Check(Kind(g_static) == K_NONE, "种类：静态标签不换肤");
  Check(Kind(g_panel) == K_CONTAINER && Kind(g_panelBtn) == K_PUSH, "种类：容器里的按钮也接上");

  // —— 绘制 ——
  RedrawWindow(g_form, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN | RDW_UPDATENOW);
  Pump(200);
  SaveBmp(g_form, L"浅色");
  uint32_t corner = Px(g_btn, 0, 0), center = Px(g_btn, 6, 16);
  Check(Diff(corner, 0xFFFFFF) <= 8, "按钮：左上角是圆角（露出父窗口白底）", Hex(corner, 0xFFFFFF));
  Check(systemBefore && !LooksSystem(g_btn), "按钮：换肤前与系统画的参照按钮一样，换肤后不同（圆角、原皮肤细边）");
  Check(Diff(center, 0xFFFFFF) <= 6, "按钮：底色为白（原皮肤标准按钮）", Hex(center, 0xFFFFFF));
  uint32_t topEdge = Px(g_btn, 50, 0), botEdge = Px(g_btn, 50, 31);
  Check(Diff(botEdge, 0xD0D0D0) <= 8 && Diff(topEdge, 0xD0D0D0) <= 8, "按钮：上下边同为 #D0D0D0 细边（原皮肤）", Hex(botEdge, 0xD0D0D0));
  uint32_t def = Px(g_btnDef, 4, 16);
  Check(Diff(def, 0xFFFFFF) <= 6, "默认按钮：与普通按钮一样白底，不填强调色（原皮肤）", Hex(def, 0xFFFFFF));
  uint32_t dis = Px(g_btnDis, 6, 16);
  Check(Diff(dis, 0xFDFDFD) <= 6, "禁止的按钮：浅灰底", Hex(dis, 0xFDFDFD));
  Check(XS_GetInfo(17, (INT_PTR)g_btnImg, 0, 0) == 1 && Kind(g_btnImg) == K_PUSH, "纯图片按钮：接上但交回原样绘制（诊断 17＝1）");
  Check(XS_GetInfo(17, (INT_PTR)g_chkImg, 0, 0) == 1 && Kind(g_chkImg) == K_CHECK, "带图片的选择框：交回原样绘制（外观是图片本身）");
  Check(XS_GetInfo(17, (INT_PTR)g_btn, 0, 0) == 0, "有文字的按钮：由引擎画（诊断 17＝0）");
  uint32_t own = Px(g_btnOwner, 30, 16);
  Check(own == 0xFF00FF, "自绘按钮：保持程序自己画的样子", Hex(own, 0xFF00FF));
  // 选择框：方框在左、垂直居中
  {
    RECT r;
    GetClientRect(g_chkOn, &r);
    int boxCenterY = r.bottom / 2;
    uint32_t onFill = Px(g_chkOn, 3, boxCenterY - 4);
    Check(Diff(onFill, 0x005FB8) <= 10, "选中的选择框：#005FB8 方框（原皮肤的蓝）", Hex(onFill, 0x005FB8));
    uint32_t offEdge = Px(g_chkOff, 0, boxCenterY);
    Check(Lum(offEdge) < 200 && Lum(offEdge) > 90, "未选中的选择框：中灰描边", Hex(offEdge));
    uint32_t offIn = Px(g_chkOff, 7, boxCenterY);
    Check(Lum(offIn) > 235, "未选中的选择框：方框里近白", Hex(offIn));
    uint32_t ind = Px(g_chkInd, 3, boxCenterY - 4);
    Check(Diff(ind, 0x0067C0) <= 16, "不确定的选择框：强调色方框", Hex(ind, 0x0067C0));
    uint32_t col = Px(g_chkColored, 80, 2);
    Check(Diff(col, 0xFFF4C0) <= 4, "父窗口指定的背景色照常生效（WM_CTLCOLORSTATIC）", Hex(col, 0xFFF4C0));
    uint32_t dchk = Px(g_chkDis, 3, boxCenterY - 4);
    Check(Diff(dchk, 0x0067C0) > 40 && Lum(dchk) > 150, "禁止的选择框：灰色方框而不是强调色", Hex(dchk));
  }
  {
    RECT r;
    GetClientRect(g_radOn, &r);
    int cy = r.bottom / 2;
    HDC dc = GetDC(g_radOn);
    TEXTMETRICW tm;
    HGDIOBJ of = SelectObject(dc, g_font);
    GetTextMetricsW(dc, &tm);
    SelectObject(dc, of);
    ReleaseDC(g_radOn, dc);
    int box = 13;  // 原皮肤：13×13（测试在 100% 缩放下跑）
    (void)tm;
    uint32_t mid = Px(g_radOn, box / 2, cy), ring = Px(g_radOn, 1, cy);
    Check(Lum(mid) > 230, "选中的单选框：中心白点", Hex(mid));
    Check(Diff(ring, 0x005FB8) <= 40, "选中的单选框：#005FB8 实心圆（原皮肤）", Hex(ring, 0x005FB8));
  }
  {
    RECT r;
    GetClientRect(g_group, &r);
    uint32_t edge = Px(g_group, 0, r.bottom / 2), inner = Px(g_group, 20, r.bottom - 12);
    Check(Diff(edge, 0xDBDBDB) <= 10, "分组框：浅灰细边", Hex(edge, 0xDBDBDB));
    Check(Diff(inner, 0xFFFFFF) <= 4, "分组框：里面不动（仍是父窗口底色）", Hex(inner, 0xFFFFFF));
  }
  {
    RECT wr;
    GetWindowRect(g_edit, &wr);
    int W = wr.right - wr.left, H = wr.bottom - wr.top;
    HDC dc = GetWindowDC(g_edit);
    COLORREF b = GetPixel(dc, W / 2, H - 1), t = GetPixel(dc, W / 2, 0), c0 = GetPixel(dc, 0, 0);
    ReleaseDC(g_edit, dc);
    uint32_t bb = ((uint32_t)GetRValue(b) << 16) | ((uint32_t)GetGValue(b) << 8) | GetBValue(b);
    uint32_t tt = ((uint32_t)GetRValue(t) << 16) | ((uint32_t)GetGValue(t) << 8) | GetBValue(t);
    uint32_t cc = ((uint32_t)GetRValue(c0) << 16) | ((uint32_t)GetGValue(c0) << 8) | GetBValue(c0);
    Check(Diff(bb, 0xD9D9D9) <= 8, "编辑框：底边与其余三边同为 #D9D9D9 细边（原皮肤）", Hex(bb, 0xD9D9D9));
    Check(Diff(tt, 0xD9D9D9) <= 8, "编辑框：顶边 #D9D9D9", Hex(tt, 0xD9D9D9));
    Check(Diff(cc, 0xD9D9D9) <= 8, "编辑框：直角（左上角就是边框色，原皮肤）", Hex(cc, 0xD9D9D9));
    {
      RECT mr;
      GetWindowRect(g_editMulti, &mr);
      HDC md = GetWindowDC(g_editMulti);
      COLORREF mb = GetPixel(md, 10, mr.bottom - mr.top - 1);
      ReleaseDC(g_editMulti, md);
      uint32_t mbb = ((uint32_t)GetRValue(mb) << 16) | ((uint32_t)GetGValue(mb) << 8) | GetBValue(mb);
      Check(Diff(mbb, 0xD9D9D9) <= 8, "多行编辑框（带滚动条）：同样画成原皮肤细边", Hex(mbb, 0xD9D9D9));
    }
    SetFocus(g_edit);
    Pump(100);
    dc = GetWindowDC(g_edit);
    b = GetPixel(dc, W / 2, H - 1);
    COLORREF b2 = GetPixel(dc, W / 2, H - 2);
    ReleaseDC(g_edit, dc);
    bb = ((uint32_t)GetRValue(b) << 16) | ((uint32_t)GetGValue(b) << 8) | GetBValue(b);
    uint32_t bb2 = ((uint32_t)GetRValue(b2) << 16) | ((uint32_t)GetGValue(b2) << 8) | GetBValue(b2);
    Check(Diff(bb, 0x0078D4) <= 12 && Diff(bb2, 0xFFFFFF) <= 8, "编辑框获得焦点：1 像素边框变蓝 #0078D4", Hex(bb, 0x0078D4));
    SetFocus(g_form);
    Pump(100);
    dc = GetWindowDC(g_edit);
    b = GetPixel(dc, W / 2, H - 1);
    ReleaseDC(g_edit, dc);
    bb = ((uint32_t)GetRValue(b) << 16) | ((uint32_t)GetGValue(b) << 8) | GetBValue(b);
    Check(Diff(bb, 0xD9D9D9) <= 8, "编辑框失去焦点：边框恢复 #D9D9D9", Hex(bb, 0xD9D9D9));
    {  // 原皮肤：单线边框（WS_BORDER）的编辑框——编辑框可能自己去掉样式位只留边框位置；SkinSharp 此时不画线（登录、注册窗口的输入框）
      HWND e = CreateWindowExW(0, L"Edit", L"x", WS_CHILD | WS_VISIBLE | WS_BORDER, 2, 2, 90, 22, g_form, nullptr, nullptr, nullptr);
      SetWindowPos(e, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
      RedrawWindow(e, nullptr, nullptr, RDW_INVALIDATE | RDW_FRAME | RDW_UPDATENOW);
      Pump(80);
      bool kept = (GetWindowLongW(e, GWL_STYLE) & WS_BORDER) != 0;
      RECT wr; GetWindowRect(e, &wr); POINT o = {0, 0}; ClientToScreen(e, &o);
      int inset = o.y - wr.top;
      HDC ed = GetWindowDC(e); COLORREF px = GetPixel(ed, 0, 11); ReleaseDC(e, ed);
      uint32_t v = ((uint32_t)GetRValue(px) << 16) | ((uint32_t)GetGValue(px) << 8) | GetBValue(px);
      printf("INFO 单线边框编辑框：样式位%s保留，边框位置 %d 像素\n", kept ? "" : "未", inset);
      if (inset <= 0) printf("SKIP 单线边框编辑框：这个系统不给边框位置，不判\n");
      else if (kept) Check(Diff(v, 0xD9D9D9) <= 8, "单线边框编辑框（样式位还在）：画原皮肤细边", Hex(v, 0xD9D9D9));
      else Check(Diff(v, 0xFFFFFF) <= 8, "单线边框编辑框（样式位被去掉）：边框位置只铺底色、不画线（原皮肤）", Hex(v, 0xFFFFFF));
      DestroyWindow(e);
      Pump(30);
    }
    {  // 父窗口不回答打印（易语言外形框）：选择框底色取最近一层登记的容器底色。主窗口“设置”外形框没登记时取到窗口的蓝色＝那两条蓝条
      WNDCLASSW wc = {}; wc.lpfnWndProc = BlankProc; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"XsTestBlank"; RegisterClassW(&wc);
      HWND box = CreateWindowExW(0, L"XsTestBlank", L"", WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS, 2, 30, 200, 60, g_form, nullptr, nullptr, nullptr);
      HWND chk = CreateWindowExW(0, L"Button", L"测试", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 10, 4, 150, 24, box, nullptr, nullptr, nullptr);
      SendMessageW(chk, WM_SETFONT, SendMessageW(g_btn, WM_GETFONT, 0, 0), TRUE);
      SetWindowPos(box, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
      XS_Refresh((INT_PTR)g_form, 0, 0, 0);
      XS_Set(10, (INT_PTR)g_form, RGB(0x59, 0xAC, 0xFF), 0);  // 窗口登记蓝色底色（像 主窗口.底色）
      Pump(60);
      auto u = [](COLORREF c) { return ((uint32_t)GetRValue(c) << 16) | ((uint32_t)GetGValue(c) << 8) | GetBValue(c); };
      auto top = [&]() {
        RedrawWindow(chk, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_UPDATENOW);
        Pump(80);
        HDC fd = GetDC(g_form); COLORREF v = GetPixel(fd, 2 + 10 + 100, 30 + 4 + 1); ReleaseDC(g_form, fd);
        return u(v);
      };
      uint32_t before = top();
      Check(Diff(before, 0x59ACFF) <= 8, "外形框没登记底色：其中的选择框取窗口登记的蓝色（蓝条的成因）", Hex(before, 0x59ACFF));
      XS_Set(10, (INT_PTR)box, RGB(255, 255, 255), 0);  // 易语言：置容器底色 (外形框.取窗口句柄 (), #白色)
      uint32_t after = top();
      Check(Diff(after, 0xFFFFFF) <= 8, "外形框登记白色后：其中的选择框底色是白色（不再出现蓝条）", Hex(after, 0xFFFFFF));
      XS_Set(10, (INT_PTR)g_form, -1, 0);
      DestroyWindow(box);
      Pump(30);
    }
    {  // 父窗口只画了一部分：没画的那条一律用就近登记的容器底色；点选、改文字（系统按钮会先当场画一遍经典外观）前后保持一样
      WNDCLASSW wc = {}; wc.lpfnWndProc = PanelProc; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"XsTestPanel"; RegisterClassW(&wc);
      HWND panel = CreateWindowExW(0, L"XsTestPanel", L"", WS_CHILD | WS_VISIBLE, 2, 30, 200, 60, g_form, nullptr, nullptr, nullptr);
      HWND chk = CreateWindowExW(0, L"Button", L"测试", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 10, 4, 150, 24, panel, nullptr, nullptr, nullptr);
      SendMessageW(chk, WM_SETFONT, SendMessageW(g_btn, WM_GETFONT, 0, 0), TRUE);
      SetWindowPos(panel, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
      XS_Refresh((INT_PTR)g_form, 0, 0, 0);
      Pump(60);  // 新建的控件在消息循环里接上
      XS_Set(10, (INT_PTR)panel, RGB(0, 160, 0), 0);  // 面板登记绿色
      RedrawWindow(chk, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
      Pump(80);
      uint32_t before = Px(chk, 100, 1);
      SendMessageW(chk, BM_SETCHECK, BST_CHECKED, 0);  // 系统只当场重画方框（ODA_SELECT）
      Pump(80);
      uint32_t after = Px(chk, 100, 1);
      SetWindowTextW(chk, L"换了文字");  // 改文字（多语言刷新就是这样）：系统当场把整个控件连底色重画一遍（ODA_DRAWENTIRE），引擎随后重画
      Pump(80);
      uint32_t after2 = Px(chk, 100, 1);
      char d[100];
      snprintf(d, sizeof(d), "(之前 #%06X，点选后 #%06X，改文字后 #%06X)", before, after, after2);
      Check(Diff(before, 0x00A000) <= 8 && Diff(after, 0x00A000) <= 8 && Diff(after2, 0x00A000) <= 8,
            "父窗口只画了一部分：没画的那条用面板登记的底色，点选、改文字后也不变（不残留系统当场画的经典外观）", d);
      XS_Set(10, (INT_PTR)panel, -1, 0);
      DestroyWindow(panel);
      Pump(30);
    }
    {  // 按钮在易语言图片框一类的容器里：WM_CTLCOLORBTN 只有默认画刷时再问 WM_CTLCOLORSTATIC，圆角外侧用容器自己的底色
      if (!g_greenBr) g_greenBr = CreateSolidBrush(RGB(0, 160, 0));
      WNDCLASSW wc = {}; wc.lpfnWndProc = StaticOnlyProc; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"XsTestStaticOnly"; RegisterClassW(&wc);
      HWND box = CreateWindowExW(0, L"XsTestStaticOnly", L"", WS_CHILD | WS_VISIBLE, 2, 30, 200, 60, g_form, nullptr, nullptr, nullptr);
      HWND btn = CreateWindowExW(0, L"Button", L"按钮", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 10, 10, 100, 28, box, nullptr, nullptr, nullptr);
      SendMessageW(btn, WM_SETFONT, SendMessageW(g_btn, WM_GETFONT, 0, 0), TRUE);
      SetWindowPos(box, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
      XS_Refresh((INT_PTR)g_form, 0, 0, 0);
      Pump(60);
      RedrawWindow(btn, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
      Pump(60);
      uint32_t corner = Px(btn, 0, 0), mid = Px(btn, 6, 14);  // 底色取左边留白处：正中落在文字笔画上，真机的 ClearType 彩边（如 #B66600）会被误当成底色
      char d[80];
      snprintf(d, sizeof(d), "(角 #%06X，中间 #%06X，种类 %d)", corner, mid, Kind(btn));
      Check(Kind(btn) == K_PUSH && Diff(corner, 0x00A000) <= 12 && Diff(mid, 0xFFFFFF) <= 8, "按钮在只回答 WM_CTLCOLORSTATIC 的容器里：圆角外侧用容器底色（不落到兜底灰色）", d);
      DestroyWindow(box);
      Pump(30);
    }
    {  // 父窗口只画了一部分、方框落在没画的那块里、兜底色恰好是白色：取消选中后方框里必须画回白色（不能当成“没画”跳过而留下原来的蓝色）
      WNDCLASSW wc = {}; wc.lpfnWndProc = Panel20Proc; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"XsTestPanel20"; RegisterClassW(&wc);
      HWND panel = CreateWindowExW(0, L"XsTestPanel20", L"", WS_CHILD | WS_VISIBLE, 2, 30, 200, 60, g_form, nullptr, nullptr, nullptr);
      HWND chk = CreateWindowExW(0, L"Button", L"测试", WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 10, 0, 150, 24, panel, nullptr, nullptr, nullptr);
      SendMessageW(chk, WM_SETFONT, SendMessageW(g_btn, WM_GETFONT, 0, 0), TRUE);
      SetWindowPos(panel, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
      XS_Refresh((INT_PTR)g_form, 0, 0, 0);
      XS_Set(10, (INT_PTR)panel, RGB(255, 255, 255), 0);  // 兜底色＝白色，与未选中方框里的白色相同
      Pump(60);
      SendMessageW(chk, BM_SETCHECK, BST_CHECKED, 0);
      RedrawWindow(chk, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
      Pump(80);
      uint32_t on = Px(chk, 3, 9);
      // 改状态时不让按钮控件自己当场画（它会顺手把方框画白，掩盖问题）：只看引擎这次重画的结果
      SendMessageW(chk, WM_SETREDRAW, FALSE, 0);
      SendMessageW(chk, BM_SETCHECK, BST_UNCHECKED, 0);
      SendMessageW(chk, WM_SETREDRAW, TRUE, 0);
      RedrawWindow(chk, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
      Pump(80);
      uint32_t off = Px(chk, 3, 9);
      char d[64];
      snprintf(d, sizeof(d), "(选中时 #%06X，取消后 #%06X)", on, off);
      Check(Diff(on, 0x005FB8) <= 12 && Diff(off, 0xFFFFFF) <= 8, "方框落在父窗口没画的地方、兜底色为白：取消选中后方框里画回白色，不留旧的蓝色", d);
      XS_Set(10, (INT_PTR)panel, -1, 0);
      DestroyWindow(panel);
      Pump(30);
    }
  }
  {
    RECT r;
    GetClientRect(g_comboList, &r);
    int dark = 0;
    for (int x = r.right - 24; x < r.right - 4; ++x)
      for (int y = r.bottom / 2 - 4; y <= r.bottom / 2 + 4; ++y)
        if (Lum(Px(g_comboList, x, y)) < 160) ++dark;
    Check(dark >= 6, "组合框：右侧有下拉箭头");
    uint32_t c = Px(g_comboList, 0, 0);
    Check(Diff(c, 0xD9D9D9) <= 8, "组合框：直角细边 #D9D9D9（原皮肤）", Hex(c, 0xD9D9D9));
  }
  {
    // 浅色主题：列表框（与组合框的下拉列表）的项交回系统画——原皮肤就是这样：选中项是系统高亮色整行、高亮文字色，文字从左缘起、与组合框本体对齐，没有强调色竖条
    RECT ir;
    SendMessageW(g_list, LB_GETITEMRECT, 1, (LPARAM)&ir);
    COLORREF sc = GetSysColor(COLOR_HIGHLIGHT);
    uint32_t hl = ((uint32_t)GetRValue(sc) << 16) | ((uint32_t)GetGValue(sc) << 8) | GetBValue(sc);
    int my = (ir.top + ir.bottom) / 2;
    uint32_t left = Px(g_list, ir.left + 5, my), right = Px(g_list, ir.right - 10, my);
    char d[160];
    int textX = -1;
    for (int x = ir.left; x < ir.left + 40 && textX < 0; ++x)
      for (int y = ir.top + 1; y < ir.bottom - 1; ++y)
        if (Diff(Px(g_list, x, y), hl) > 60) {
          textX = x - ir.left;
          break;
        }
    int pillPx = 0;  // 原先的强调色竖条（#005FB8）：左边 10 列里不该再有（文字从左缘起，固定取一个点会落在笔画上）
    for (int x = ir.left; x < ir.left + 10; ++x)
      for (int y = ir.top; y < ir.bottom; ++y)
        if (Diff(Px(g_list, x, y), 0x005FB8) <= 20) ++pillPx;
    (void)left;
    snprintf(d, sizeof(d), "(右侧 #%06X、系统高亮色 #%06X，左边强调色竖条像素 %d，文字起点 %d)", right, hl, pillPx, textX);
    Check(Diff(right, hl) <= 8 && pillPx == 0 && textX >= 0 && textX <= 10, "列表框（浅色）：项由系统画——选中项是系统高亮色整行、没有强调色竖条，文字从左缘起（原皮肤）", d);
  }
  {
    // 组合框展开、收起：下拉列表显示 / 隐藏时引擎通知组合框整面重画——展开时整圈蓝边（系统只重画右边的按钮区，左边框要靠这一步），
    // 收起后清掉悬停、恢复灰边；下拉列表外框是原皮肤的 #D9D9D9。焦点先移到窗体本身、光标移开，排除获得焦点、悬停的蓝边，结束后还原
    HWND prevFocus = GetFocus();
    SetFocus(g_form);
    SetCursorPos(0, 0);
    Pump(40);
    RECT cr;
    GetClientRect(g_comboList, &cr);
    SendMessageW(g_comboList, CB_SHOWDROPDOWN, TRUE, 0);
    {  // 真机的下拉列表是滑动展开的（约 150～200 毫秒）：等它真正显示、再等动画结束才取样
      COMBOBOXINFO c0;
      memset(&c0, 0, sizeof(c0));
      c0.cbSize = sizeof(c0);
      GetComboBoxInfo(g_comboList, &c0);
      for (int i = 0; i < 50 && c0.hwndList && !IsWindowVisible(c0.hwndList); ++i) Pump(20);
      Pump(250);
    }
    COMBOBOXINFO ci;
    memset(&ci, 0, sizeof(ci));
    ci.cbSize = sizeof(ci);
    GetComboBoxInfo(g_comboList, &ci);
    bool vis = ci.hwndList && IsWindowVisible(ci.hwndList);
    uint32_t openL = Px(g_comboList, 0, cr.bottom / 2), listL = 0;
    if (vis) {
      RECT lw;
      GetWindowRect(ci.hwndList, &lw);
      listL = ScreenPx(lw.left, (lw.top + lw.bottom) / 2);
    }
    SendMessageW(g_comboList, CB_SHOWDROPDOWN, FALSE, 0);
    Pump(80);
    uint32_t closedL = Px(g_comboList, 0, cr.bottom / 2);
    SetFocus(prevFocus);
    Pump(30);
    char d[160];
    snprintf(d, sizeof(d), "(展开 %d：左边框 #%06X、下拉列表外框 #%06X；收起后左边框 #%06X)", (int)vis, openL, listL, closedL);
    Check(vis && Diff(openL, 0x0078D4) <= 12 && Diff(listL, 0xD9D9D9) <= 8 && Diff(closedL, 0xD9D9D9) <= 8,
          "组合框展开：整圈蓝边、下拉列表外框 #D9D9D9；收起后恢复灰边（下拉列表显示 / 隐藏时通知组合框重画）", d);
  }
  {
    // 被 WM_PRINT 画时（Windows 10 默认的“滑动打开组合框”动画、窗口动画、截图）：下拉列表、编辑框、列表框的外框也是引擎画的（原皮肤 #D9D9D9），
    // 不是系统边框——真机上原先动画结束后下拉列表留着系统的 #646464 边框
    COMBOBOXINFO ci;
    memset(&ci, 0, sizeof(ci));
    ci.cbSize = sizeof(ci);
    GetComboBoxInfo(g_comboList, &ci);
    HWND tg[3] = {ci.hwndList, g_edit, g_list};
    const char* nm[3] = {"下拉列表", "编辑框", "列表框"};
    char d[220];
    d[0] = 0;
    bool ok = true;
    int checked = 0;
    for (int k = 0; k < 3; ++k) {
      RECT wr;
      if (!tg[k] || !GetWindowRect(tg[k], &wr)) {
        ok = false;
        continue;
      }
      int W = wr.right - wr.left, H = wr.bottom - wr.top;
      if (W < 4 || H < 4) {
        printf("INFO 被 WM_PRINT 画时：%s 尺寸太小（%dx%d），这一项不判\n", nm[k], W, H);
        ++checked;
        continue;
      }
      HDC sdc = GetDC(nullptr);
      HDC mdc = CreateCompatibleDC(sdc);
      HBITMAP bm = CreateCompatibleBitmap(sdc, W, H);
      HGDIOBJ ob = SelectObject(mdc, bm);
      RECT all = {0, 0, W, H};
      HBRUSH mg = CreateSolidBrush(RGB(255, 0, 255));  // 先涂品红：没画到的地方一眼看出
      FillRect(mdc, &all, mg);
      DeleteObject(mg);
      SendMessageW(tg[k], WM_PRINT, (WPARAM)mdc, PRF_NONCLIENT | PRF_CLIENT | PRF_ERASEBKGND);
      COLORREF c = GetPixel(mdc, 0, H / 2);
      uint32_t px = ((uint32_t)GetRValue(c) << 16) | ((uint32_t)GetGValue(c) << 8) | GetBValue(c);
      SelectObject(mdc, ob);
      DeleteObject(bm);
      DeleteDC(mdc);
      ReleaseDC(nullptr, sdc);
      // 编辑框正获得焦点时是蓝边；Win11 上下拉列表的细边由系统窗口管理器（DWM）画、不进 WM_PRINT 的位图，那里是白底
      bool dwmBorder = k == 0 && (XS_GetInfo(13, (INT_PTR)tg[k], 0, 0) & 2);
      bool good = dwmBorder ? Diff(px, 0xFFFFFF) <= 8 : (Diff(px, 0xD9D9D9) <= 12 || (k == 1 && Diff(px, 0x0078D4) <= 12));
      ok = ok && good;
      ++checked;
      size_t used = strlen(d);
      snprintf(d + used, sizeof(d) - used, "%s #%06X ", nm[k], px);
    }
    Check(ok && checked == 3, "被 WM_PRINT 画时（动画、截图）：下拉列表、编辑框、列表框的外框也是引擎画的 #D9D9D9（不留系统边框）", d);
  }
  {
    // 单线边框（WS_BORDER）的列表框：外框是 1 像素直角 #D9D9D9（原皮肤），四个角不缺线——原先 4 像素圆角的弧线落进被挖掉的客户区
    HWND lb1 = CreateWindowExW(0, L"ListBox", nullptr, WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_NOINTEGRALHEIGHT, 460, 410, 90, 60, g_form, nullptr, nullptr, nullptr);
    SetWindowPos(lb1, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
    XS_Refresh((INT_PTR)g_form, 0, 0, 0);
    Pump(60);
    RedrawWindow(lb1, nullptr, nullptr, RDW_FRAME | RDW_INVALIDATE | RDW_UPDATENOW);
    Pump(40);
    RECT wr;
    GetWindowRect(lb1, &wr);
    HDC wdc = GetWindowDC(lb1);
    COLORREF c0 = GetPixel(wdc, 0, 0), c1 = GetPixel(wdc, 0, (wr.bottom - wr.top) / 2);
    ReleaseDC(lb1, wdc);
    uint32_t corner = ((uint32_t)GetRValue(c0) << 16) | ((uint32_t)GetGValue(c0) << 8) | GetBValue(c0);
    uint32_t mid = ((uint32_t)GetRValue(c1) << 16) | ((uint32_t)GetGValue(c1) << 8) | GetBValue(c1);
    char d[120];
    snprintf(d, sizeof(d), "(角 #%06X、左边中点 #%06X，种类 %d)", corner, mid, (int)Kind(lb1));
    Check(Kind(lb1) == K_LISTBOX && Diff(corner, 0xD9D9D9) <= 8 && Diff(mid, 0xD9D9D9) <= 8, "单线边框的列表框：1 像素直角 #D9D9D9 细边，四个角不缺线（原皮肤）", d);
    DestroyWindow(lb1);
    Pump(30);
  }
  {
    RECT r;
    GetClientRect(g_prog, &r);
    uint32_t a = Px(g_prog, r.right / 4, r.bottom / 2), b = Px(g_prog, r.right * 3 / 4, r.bottom / 2), b2 = Px(g_prog, r.right * 3 / 4, 2);
    Check(Diff(a, 0x0067C0) <= 12, "进度条 50%：前半段强调色", Hex(a, 0x0067C0));
    Check(Diff(b, 0x0067C0) > 60 && Lum(b2) > 240, "进度条 50%：后半段只有一条细轨道", Hex(b));
  }
  // —— 状态 ——
  {
    // 悬停用真实光标：真机上 TrackMouseEvent 发现光标不在按钮上会立刻发 WM_MOUSELEAVE（Wine 是定时检查），只发一个假的 WM_MOUSEMOVE 测不出来
    POINT oldPos;
    GetCursorPos(&oldPos);
    SetWindowPos(g_form, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    RECT br;
    GetWindowRect(g_btn, &br);
    POINT mid = {(br.left + br.right) / 2, (br.top + br.bottom) / 2};
    SetCursorPos(mid.x, mid.y);
    Pump(50);
    bool under = WindowFromPoint(mid) == g_btn;
    POINT cm = mid;
    ScreenToClient(g_btn, &cm);
    SendMessageW(g_btn, WM_MOUSEMOVE, 0, MAKELPARAM(cm.x, cm.y));
    Pump(80);
    uint32_t hov = Px(g_btn, 6, 16);
    if (under) Check(Diff(hov, 0xE0EEF9) <= 6 && Diff(Px(g_btn, 50, 0), 0x0078D4) <= 12, "按钮悬停（真实光标在按钮上）：浅蓝底 #E0EEF9、蓝边 #0078D4（原皮肤）", Hex(hov, 0xE0EEF9));
    else printf("SKIP 按钮悬停：光标处不是测试按钮（被别的窗口挡住或没有鼠标），不判\n");
    {
      // 按住拖到按钮外面（按钮有鼠标捕获，移动消息的坐标在外面）：不算悬停，画回常态
      // 真实拖出：光标真的移到按钮外面再发移动消息。只发一条坐标在外的假消息、真实光标还停在按钮上时，
      // 真机会按真实光标位置补发移动消息（坐标在按钮里），引擎据此判回悬停是对的——那不是拖出
      SetCapture(g_btn);
      RECT bw;
      GetWindowRect(g_btn, &bw);
      POINT outPt = {bw.right + 30, bw.bottom + 30};
      SetCursorPos(outPt.x, outPt.y);
      POINT oc = outPt;
      ScreenToClient(g_btn, &oc);
      SendMessageW(g_btn, WM_MOUSEMOVE, MK_LBUTTON, MAKELPARAM(oc.x, oc.y));
      Pump(30);
      uint32_t outp = Px(g_btn, 6, 16);
      ReleaseCapture();
      SetCursorPos(mid.x, mid.y);  // 光标放回按钮上：后面的用例照原样进行
      Pump(30);
      Check(Diff(outp, 0xFFFFFF) <= 6, "按住拖到按钮外面：不算悬停（画回常态白底）", Hex(outp));
    }
    RECT fr;
    GetWindowRect(g_form, &fr);
    SetCursorPos(fr.right + 60, fr.bottom + 60);  // 光标移出测试窗口：由 TrackMouseEvent 发来 WM_MOUSELEAVE
    Pump(400);
    Check(Diff(Px(g_btn, 6, 16), 0xFFFFFF) <= 6, "鼠标离开（光标移出）：恢复白底", Hex(Px(g_btn, 6, 16)));
    SetCursorPos(oldPos.x, oldPos.y);
    SetWindowPos(g_form, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    SendMessageW(g_btn, BM_SETSTATE, TRUE, 0);
    Pump(50);
    uint32_t pr = Px(g_btn, 6, 16);
    Check(Diff(pr, 0xCEE3F4) <= 6, "按钮按下：浅蓝底 #CEE3F4（原皮肤）", Hex(pr, 0xCEE3F4));
    SendMessageW(g_btn, BM_SETSTATE, FALSE, 0);
    Pump(50);
    RECT r;
    GetClientRect(g_chkOff, &r);
    SendMessageW(g_chkOff, BM_CLICK, 0, 0);
    Pump(50);
    uint32_t now = Px(g_chkOff, 3, r.bottom / 2 - 4);
    Check(Diff(now, 0x0067C0) <= 16, "点击选择框：立刻画成选中", Hex(now, 0x0067C0));
    SendMessageW(g_chkOff, BM_CLICK, 0, 0);
    Pump(50);
    SendMessageW(g_prog, PBM_SETPOS, 90, 0);
    Pump(50);
    uint32_t p = Px(g_prog, 170, 10);
    Check(Diff(p, 0x0067C0) <= 12, "进度条改位置：立刻重画", Hex(p, 0x0067C0));
    SendMessageW(g_comboList, CB_SETCURSEL, 1, 0);
    Pump(50);
    Check(true, "组合框换选中项：不崩溃");
  }
  // —— 后加的控件：WM_PARENTNOTIFY ——
  {
    HWND late = Ctl(L"Button", L"后加 Late", BS_PUSHBUTTON, 0, 480, 100, 120, 30, g_form);
    Pump(100);
    Check(Kind(late) == K_PUSH, "程序后建的按钮自动换肤（WM_PARENTNOTIFY）");
  }
  // —— 黑月的做法：先建在隐藏窗口里，再置父进来（不发 WM_PARENTNOTIFY） ——
  {
    HWND host = CreateWindowExW(0, L"XsTestForm", L"host", WS_POPUP, 0, 0, 10, 10, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    HWND bm = Ctl(L"Button", L"黑月按钮", BS_PUSHBUTTON, 0, 0, 0, 110, 30, host);
    SetParent(bm, g_panel);
    MoveWindow(bm, 10, 44, 110, 30, TRUE);
    Check(Kind(bm) == K_NONE, "置父进来的瞬间还没接上（没有 WM_PARENTNOTIFY）");
    InvalidateRect(bm, nullptr, TRUE);
    UpdateWindow(bm);
    Pump(100);
    Check(Kind(bm) == K_PUSH, "置父进来的按钮一画就接上（容器从 WM_CTLCOLORBTN 发现它）");
    HWND bm2 = Ctl(L"Edit", L"黑月编辑框", ES_AUTOHSCROLL, WS_EX_CLIENTEDGE, 0, 0, 100, 24, host);
    ShowWindow(bm2, SW_HIDE);
    SetParent(bm2, g_form);
    MoveWindow(bm2, 480, 140, 120, 24, FALSE);
    Check(XS_Refresh((INT_PTR)g_form, 0, 0, 0) == 1 && Kind(bm2) == K_EDIT, "隐藏着置父进来的编辑框：重扫（XS_Refresh / 显示 / 激活时）接上");
    DestroyWindow(host);
  }
  // —— 排除 ——
  {
    Check(XS_Exclude((INT_PTR)g_btn, 1, 0, 0) == 1 && Kind(g_btn) == K_NONE, "排除按钮：卸下");
    UpdateWindow(g_btn);
    Pump(50);
    Check(LooksSystem(g_btn), "排除后恢复系统按钮（与参照按钮一样）");
    XS_Refresh((INT_PTR)g_form, 0, 0, 0);
    Check(Kind(g_btn) == K_NONE, "排除的按钮重扫时也不接");
    Check(XS_Exclude((INT_PTR)g_btn, 0, 0, 0) == 1 && Kind(g_btn) == K_PUSH, "取消排除：重新接上");
    {  // 在按钮自己的消息里（点击时父窗口收到 BN_CLICKED，按钮的 WM_LBUTTONUP 还没返回）卸下又接上：不能崩溃，照常响应、照常换肤，记录不残留
      INT_PTR subs0 = XS_GetInfo(16, 0, 0, 0);
      g_reBtn = Ctl(L"Button", L"重接", BS_PUSHBUTTON, 0, 560, 420, 80, 28, g_form);
      XS_Refresh((INT_PTR)g_form, 0, 0, 0);
      Pump(60);
      g_reClicks = 0;
      for (int i = 0; i < 3; ++i) {
        SendMessageW(g_reBtn, WM_LBUTTONDOWN, MK_LBUTTON, MAKELPARAM(10, 10));
        SendMessageW(g_reBtn, WM_LBUTTONUP, 0, MAKELPARAM(10, 10));
        Pump(30);
      }
      uint32_t focused = Px(g_reBtn, 40, 0);  // 点击后按钮拿到焦点：显示焦点提示时是蓝边
      SetFocus(g_btn);  // 焦点移走：若是按下态卡住会仍是蓝边
      Pump(40);
      RedrawWindow(g_reBtn, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
      Pump(60);
      uint32_t edge = Px(g_reBtn, 40, 0);
      int kind = Kind(g_reBtn);
      DestroyWindow(g_reBtn);
      g_reBtn = nullptr;
      Pump(60);
      INT_PTR subs1 = XS_GetInfo(16, 0, 0, 0);
      char d[120];
      snprintf(d, sizeof(d), "(点击 %d 次，种类 %d，有焦点时上边 #%06X、焦点移走后 #%06X，子类化记录 %d→%d)", g_reClicks, kind, focused, edge, (int)subs0, (int)subs1);
      Check(g_reClicks == 3 && kind == K_PUSH && Diff(edge, 0xD0D0D0) <= 12 && subs1 == subs0,
            "在按钮自己的消息里卸下又接上（连点 3 次）：不崩溃、照常响应与换肤，销毁后子类化记录不残留", d);
    }
  }
  // —— 信息框 ——
  {
    g_seenDlg = false;
    g_dlgAnswer = IDCANCEL;
    SetTimer(nullptr, 0, 200, DlgTimer);
    INT_PTR r = XS_MessageBox((INT_PTR)g_form, (INT_PTR)L"这是换肤后的信息框。\nThis is a themed message box.", (INT_PTR)L"标题 Title", MB_OKCANCEL | MB_ICONINFORMATION);
    Check(g_seenDlg, "信息框：弹出来了");
    Check(g_dlgKind == 2, "信息框：作为对话框根窗口接上");
    Check(g_dlgBtnKind == K_PUSH, "信息框：按钮换肤");
    Check(g_dlgOwn == 1, "信息框：正文在 0xFFFF 静态控件里，整面由引擎画");
    Check(Diff(g_dlgFooter, 0xF3F3F3) <= 4, "信息框：底部按钮区 #F3F3F3", Hex(g_dlgFooter, 0xF3F3F3));
    Check(Diff(g_dlgContent, 0xFFFFFF) <= 4, "信息框：内容区白底", Hex(g_dlgContent, 0xFFFFFF));
    Check(r == IDCANCEL, "信息框：返回值与 MessageBoxW 相同（取消＝2）");
    Check(XS_GetInfo(15, 0, 0, 0) == 0, "信息框关闭后换肤范围已结束（钩子已摘）");
    g_seenDlg = false;
    g_dlgAnswer = IDNO;
    SetTimer(nullptr, 0, 200, DlgTimer);
    r = XS_MessageBox((INT_PTR)g_form, (INT_PTR)L"是否继续？", (INT_PTR)nullptr, MB_YESNO | MB_ICONQUESTION);
    Check(g_seenDlg && r == IDNO, "信息框：是 / 否，返回“否”＝7");
  }
  // —— 换肤范围里弹出的普通窗口（易语言用它包住 载入 (充值窗口…) 这类没套黑月外框的窗口） ——
  {
    XS_ScopeBegin(0, 0, 0, 0);
    HWND w0 = CreateWindowExW(0, L"XsTestForm", L"范围0", WS_OVERLAPPEDWINDOW, 300, 300, 200, 100, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    Ctl(L"Button", L"按钮", BS_PUSHBUTTON, 0, 10, 10, 80, 28, w0);
    ShowWindow(w0, SW_SHOWNORMAL);
    Pump(50);
    Check(XS_GetInfo(4, (INT_PTR)w0, 0, 0) == 0, "换肤范围（标志 0）：普通窗口不接，只接信息框一类");
    XS_ScopeEnd(0, 0, 0, 0);
    DestroyWindow(w0);
    XS_ScopeBegin(1, 0, 0, 0);
    HWND w1 = CreateWindowExW(0, L"XsTestForm", L"范围1", WS_POPUP, 300, 300, 200, 100, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    HWND b1 = Ctl(L"Button", L"充值", BS_PUSHBUTTON, 0, 10, 10, 80, 28, w1);
    ShowWindow(w1, SW_SHOWNORMAL);
    Pump(50);
    Check(XS_GetInfo(4, (INT_PTR)w1, 0, 0) == 2 && Kind(b1) == K_PUSH, "换肤范围（标志 1）：这期间弹出的易语言窗口连同按钮接上");
    XS_ScopeEnd(0, 0, 0, 0);
    Check(XS_GetInfo(15, 0, 0, 0) == 0, "换肤范围结束：钩子已摘");
    DestroyWindow(w1);
    SetForegroundWindow(g_form);
    Pump(50);
  }
  // —— 别的简单对话框：只画底色、保留它自己画的内容；复杂对话框不碰 ——
  {
    XS_ScopeBegin(0, 0, 0, 0);
    HWND ok1 = nullptr;
    HWND d1 = MakeDialog(1, &ok1);
    ShowWindow(d1, SW_SHOWNORMAL);
    SetActiveWindow(d1);
    UpdateWindow(d1);
    Pump(100);
    Check(XS_GetInfo(4, (INT_PTR)d1, 0, 0) == 2 && Kind(ok1) == K_PUSH, "简单对话框（一个编辑框）：换肤范围里激活时接上，按钮换肤");
    uint32_t mg = Px(d1, 10, 10);
    Check(mg == 0xFF00FF, "简单对话框自己在 WM_PAINT 里画的内容保留（只有信息框才整面由引擎画）", Hex(mg, 0xFF00FF));
    Check(XS_GetInfo(19, (INT_PTR)d1, 0, 0) == 0, "简单对话框：只画底色（诊断 19＝0）");
    // Windows 的信息框是先激活、后显示（HCBT_ACTIVATE 时对话框还没显示，IsWindowVisible 对其中的按钮都是假）。
    // 在 Wine 里照这个顺序做一遍：隐藏着激活，再显示，按钮区必须照样画出来
    HWND ok3 = nullptr;
    HWND d3 = MakeDialog(1, &ok3);
    SetActiveWindow(d3);
    Pump(30);
    Check(XS_GetInfo(4, (INT_PTR)d3, 0, 0) == 2, "隐藏着激活的对话框也接上（Windows 的信息框就是先激活后显示）");
    ShowWindow(d3, SW_SHOWNA);
    UpdateWindow(d3);
    Pump(100);
    {
      RECT rc3;
      GetClientRect(d3, &rc3);
      uint32_t ft = Px(d3, 3, rc3.bottom - 3);
      Check(Diff(ft, 0xF3F3F3) <= 4, "先激活后显示的对话框：按钮区照样画出（真机 Win10 信息框底部曾是白的）", Hex(ft, 0xF3F3F3));
    }
    DestroyWindow(d3);
    HWND d2 = MakeDialog(2, nullptr);
    ShowWindow(d2, SW_SHOWNORMAL);
    SetActiveWindow(d2);
    Pump(100);
    Check(XS_GetInfo(4, (INT_PTR)d2, 0, 0) == 0, "两个编辑框的对话框（选色、查找一类）不接");
    XS_ScopeEnd(0, 0, 0, 0);
    DestroyWindow(d1);
    DestroyWindow(d2);
    XS_ScopeBegin(1, 0, 0, 0);
    HWND sp = CreateWindowExW(0, L"Static", L"系统类", WS_POPUP | WS_BORDER, 300, 320, 120, 40, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    ShowWindow(sp, SW_SHOWNORMAL);
    SetActiveWindow(sp);
    Pump(50);
    Check(XS_GetInfo(4, (INT_PTR)sp, 0, 0) == 0, "换肤范围（标志 1）：系统注册的窗口类（输入法、外壳一类）不接");
    HWND exw = CreateWindowExW(0, L"XsTestForm", L"排除", WS_POPUP, 300, 380, 120, 40, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    XS_Exclude((INT_PTR)exw, 1, 0, 0);
    ShowWindow(exw, SW_SHOWNORMAL);
    SetActiveWindow(exw);
    Pump(50);
    Check(XS_GetInfo(4, (INT_PTR)exw, 0, 0) == 0, "换肤范围（标志 1）：排除了的窗口（出场动画、旧版悬浮窗）不接");
    XS_ScopeEnd(0, 0, 0, 0);
    DestroyWindow(sp);
    DestroyWindow(exw);
    SetForegroundWindow(g_form);
    Pump(50);
  }
  // —— 深色 ——
  {
    Check(XS_Set(1, 2, 0, 0) == 1 && XS_GetInfo(5, 0, 0, 0) == 1, "切到深色");
    RedrawWindow(g_form, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN | RDW_UPDATENOW);
    Pump(150);
    SaveBmp(g_form, L"深色");
    uint32_t def = Px(g_btnDef, 4, 16);
    { uint32_t nb = Px(g_btn, 6, 16); Check(Diff(def, nb) <= 4, "深色：默认按钮与普通按钮同色、不填强调色", Hex(def, nb)); }
    Check(XS_GetColor(7, 0, 0, 0) == (INT_PTR)RGB(0x2B, 0x2B, 0x2B), "深色：对话框内容区令牌 #2B2B2B");
    Check(XS_Set(1, 1, 0, 0) == 1 && XS_GetInfo(5, 0, 0, 0) == 0, "切回浅色");
    RedrawWindow(g_form, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN | RDW_UPDATENOW);
    Pump(100);
    Check(Diff(Px(g_btnDef, 4, 16), 0xFFFFFF) <= 6, "切回浅色：默认按钮恢复白底");
  }
  // —— 窄按钮不截字（“获取验证码”原先被截成“获取验...”）——
  {
    HFONT bf = (HFONT)SendMessageW(g_btn, WM_GETFONT, 0, 0);
    auto ink = [](HWND b, int W, int H, int* x0, int* x1) {
      *x0 = W; *x1 = -1;
      for (int x = 0; x < W; ++x)
        for (int y = 3; y < H - 3; ++y)
          if (Lum(Px(b, x, y)) < 120) { if (x < *x0) *x0 = x; if (x > *x1) *x1 = x; break; }
    };
    HWND wide = CreateWindowExW(0, L"Button", L"获取验证码", WS_CHILD | WS_VISIBLE, 16, 420, 200, 30, g_form, nullptr, nullptr, nullptr);
    SendMessageW(wide, WM_SETFONT, (WPARAM)bf, TRUE);
    XS_Refresh((INT_PTR)g_form, 0, 0, 0);
    Pump(80);
    int a0, a1;
    ink(wide, 200, 30, &a0, &a1);
    int need = a1 - a0 + 1;
    HWND narrow = CreateWindowExW(0, L"Button", L"获取验证码", WS_CHILD | WS_VISIBLE, 230, 420, need + 8, 30, g_form, nullptr, nullptr, nullptr);
    SendMessageW(narrow, WM_SETFONT, (WPARAM)bf, TRUE);
    XS_Refresh((INT_PTR)g_form, 0, 0, 0);
    Pump(80);
    int b0, b1;
    ink(narrow, need + 8, 30, &b0, &b1);
    char d[96];
    snprintf(d, sizeof(d), "(宽按钮墨迹 %d 像素，窄按钮 %d 像素，窄按钮宽 %d)", need, b1 - b0 + 1, need + 8);
    Check(need > 20 && abs((b1 - b0 + 1) - need) <= 2, "窄按钮：先缩小两侧留白，文字不截成省略号", d);
    DestroyWindow(wide);
    DestroyWindow(narrow);
    Pump(30);
    // 多行按钮：缩小留白也排不成一行时，保持正常留白、让文字换行（不贴着边框挤）
    HWND ml = CreateWindowExW(0, L"Button", L"这是 一段 放不进 一行的 多行 按钮 文字", WS_CHILD | WS_VISIBLE | BS_MULTILINE, 540, 360, 90, 72, g_form, nullptr, nullptr, nullptr);
    SendMessageW(ml, WM_SETFONT, (WPARAM)bf, TRUE);
    SetWindowPos(ml, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);  // 放在窗体可见区域里、盖在其它控件上面（取的是屏幕上的像素）
    XS_Refresh((INT_PTR)g_form, 0, 0, 0);
    Pump(80);
    RedrawWindow(ml, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
    Pump(60);
    SaveBmp(ml, L"多行按钮");
    int m0, m1;
    ink(ml, 90, 72, &m0, &m1);
    snprintf(d, sizeof(d), "(多行按钮宽 90，文字墨迹 x%d-%d)", m0, m1);
    Check(Kind(ml) == K_PUSH && m0 >= 9 && m1 <= 90 - 9, "多行按钮：一行放不下时保持正常留白换行，文字不贴边", d);
    DestroyWindow(ml);
    Pump(30);
    // 上下内边距比左右大的编辑框（注册、登录窗口的胶囊输入框）：失去焦点重画边框后，客户区左边第一个字不能被盖住
    HWND prevFocus = GetFocus();  // 记下原焦点：用例结束后状态不变（后面的用例拿 g_btn 与参照按钮比，不能让它带着焦点）
    HWND pe = CreateWindowExW(0, L"Edit", L"123", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 300, 360, 160, 44, g_form, nullptr, nullptr, nullptr);
    g_padOrig = (WNDPROC)SetWindowLongPtrW(pe, GWLP_WNDPROC, (LONG_PTR)PadEditProc);
    SendMessageW(pe, WM_SETFONT, (WPARAM)bf, TRUE);
    SetWindowPos(pe, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED);
    XS_Refresh((INT_PTR)g_form, 0, 0, 0);
    Pump(60);
    SetFocus(pe);
    Pump(60);
    SetFocus(prevFocus);  // 焦点移走（还原原焦点）：引擎当场重画边框（原先这一下把客户区左边一条铺成底色）
    Pump(80);
    RECT pcr;
    GetClientRect(pe, &pcr);
    int inkFirst = 0, inkAll = 0;
    for (int x = 0; x < pcr.right; ++x)
      for (int y = 0; y < pcr.bottom; ++y)
        if (Lum(Px(pe, x, y)) < 120) {
          ++inkAll;
          if (x < 10) ++inkFirst;
        }
    snprintf(d, sizeof(d), "(客户区 %ldx%ld，左边 10 列墨迹 %d 点，全部 %d 点，种类 %d)", pcr.right, pcr.bottom, inkFirst, inkAll, (int)Kind(pe));
    Check(Kind(pe) == K_EDIT && pcr.bottom <= 44 - 24 && inkFirst > 3 && inkAll > inkFirst, "上下内边距比左右大的编辑框：失去焦点重画边框后第一个字不被盖住（注册、登录窗口的输入框）", d);
    DestroyWindow(pe);
    Pump(30);
    // 带滚动条的列表框：边框那一圈换肤时滚动条（属于非客户区）原样保留，箭头还在
    HWND lbx = CreateWindowExW(0, L"ListBox", nullptr, WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | LBS_NOINTEGRALHEIGHT, 300, 410, 140, 70, g_form, nullptr, nullptr, nullptr);
    SendMessageW(lbx, WM_SETFONT, (WPARAM)bf, TRUE);
    for (int i = 0; i < 30; ++i) SendMessageW(lbx, LB_ADDSTRING, 0, (LPARAM)L"项目");
    SetWindowPos(lbx, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
    XS_Refresh((INT_PTR)g_form, 0, 0, 0);
    Pump(60);
    RedrawWindow(lbx, nullptr, nullptr, RDW_INVALIDATE | RDW_FRAME | RDW_UPDATENOW);
    Pump(60);
    SCROLLBARINFO sbi;
    memset(&sbi, 0, sizeof(sbi));
    sbi.cbSize = sizeof(sbi);
    int arrow = -1;
    if (GetScrollBarInfo(lbx, OBJID_VSCROLL, &sbi)) {
      arrow = 0;
      for (int y = sbi.rcScrollBar.top + 1; y < sbi.rcScrollBar.bottom - 1; ++y)  // 整条滚动条里找深色点：被引擎的底色盖掉时整条一片白
        for (int x = sbi.rcScrollBar.left + 1; x < sbi.rcScrollBar.right - 1; ++x)
          if (Lum(ScreenPx(x, y)) < 150) ++arrow;
    }
    snprintf(d, sizeof(d), "(滚动条里的深色点 %d，种类 %d)", arrow, (int)Kind(lbx));
    Check(Kind(lbx) == K_LISTBOX && arrow > 2, "带滚动条的列表框：边框换肤时滚动条原样保留（箭头还在）", d);
    DestroyWindow(lbx);
    Pump(30);
    // 菜单：所有者是接入的窗口时，弹出前把菜单项临时改成自绘、按原皮肤画（与下拉列表同一套外观）；关掉后原样还原
    {
      HMENU sub = CreatePopupMenu();
      AppendMenuW(sub, MF_STRING, 9101, L"子项");
      HMENU pm = CreatePopupMenu();
      AppendMenuW(pm, MF_STRING, 9001, L"普通(&A)");
      AppendMenuW(pm, MF_STRING | MF_GRAYED, 9002, L"禁止");
      AppendMenuW(pm, MF_STRING | MF_CHECKED, 9003, L"勾选");
      AppendMenuW(pm, MF_STRING | MF_CHECKED, 9004, L"单选");
      MENUITEMINFOW rt;
      memset(&rt, 0, sizeof(rt));
      rt.cbSize = sizeof(rt);
      rt.fMask = MIIM_FTYPE;
      rt.fType = MFT_STRING | MFT_RADIOCHECK;
      SetMenuItemInfoW(pm, 3, TRUE, &rt);
      AppendMenuW(pm, MF_SEPARATOR, 0, nullptr);
      AppendMenuW(pm, MF_STRING, 9005, L"快捷\tCtrl+S");
      AppendMenuW(pm, MF_POPUP, (UINT_PTR)sub, L"子菜单");
      memset(&g_mp, 0, sizeof(g_mp));
      g_mp.pm = pm;
      SetForegroundWindow(g_form);
      Pump(30);
      SetTimer(g_form, 7701, 150, MenuProbeTimer);
      RECT fr;
      GetWindowRect(g_form, &fr);
      int cmd = (int)TrackPopupMenu(pm, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_TOPALIGN, fr.left + 60, fr.top + 80, 0, g_form, nullptr);
      KillTimer(g_form, 7701);
      Pump(30);
      snprintf(d, sizeof(d), "(种类 %d，弹出期间自绘 %d)", (int)g_mp.kind, (int)g_mp.ownerDraw);
      Check(g_mp.kind == K_MENUWND && g_mp.ownerDraw, "菜单：所有者是接入的窗口时，弹出期间菜单项改成自绘、菜单窗口接上", d);
      Check(Diff(g_mp.bg, 0xFFFFFF) <= 4, "菜单：底色是弹出层底色（与下拉列表相同）", Hex(g_mp.bg, 0xFFFFFF));
      Check(Diff(g_mp.frame, 0xD9D9D9) <= 6, "菜单：外框是弹出层细边（与原皮肤下拉列表的外框同色 #D9D9D9）", Hex(g_mp.frame, 0xD9D9D9));
      snprintf(d, sizeof(d), "(文字 %d、勾选 %d、圆点 %d、箭头 %d 个深色点，分隔线 #%06X)", g_mp.ink0, g_mp.check, g_mp.radio, g_mp.arrow, g_mp.sep);
      Check(g_mp.ink0 > 10 && g_mp.check > 3 && g_mp.radio > 3 && g_mp.arrow > 2 && Diff(g_mp.sep, 0xFFFFFF) > 20, "菜单：文字、勾选 ✓、单选圆点、子菜单箭头、分隔线都画了", d);
      COLORREF hsc = GetSysColor(COLOR_HIGHLIGHT);
      uint32_t mhl = ((uint32_t)GetRValue(hsc) << 16) | ((uint32_t)GetGValue(hsc) << 8) | GetBValue(hsc);
      Check(Diff(g_mp.hover, mhl) <= 6, "菜单：键盘选中的项是系统高亮色整行（与原皮肤的列表一样醒目）", Hex(g_mp.hover, mhl));
      snprintf(d, sizeof(d), "(返回 %d，兜底关闭 %d)", cmd, (int)g_mp.forced);
      Check(cmd == 9001 && !g_mp.forced, "菜单：助记键（&A）照常可用（自绘项由引擎回答 WM_MENUCHAR）", d);
      bool restored = true;
      for (int i = 0; i < GetMenuItemCount(pm); ++i) {
        MENUITEMINFOW mi;
        memset(&mi, 0, sizeof(mi));
        mi.cbSize = sizeof(mi);
        mi.fMask = MIIM_FTYPE;
        if (GetMenuItemInfoW(pm, i, TRUE, &mi) && (mi.fType & MFT_OWNERDRAW)) restored = false;
      }
      MENUINFO inf;
      memset(&inf, 0, sizeof(inf));
      inf.cbSize = sizeof(inf);
      inf.fMask = MIM_BACKGROUND;
      GetMenuInfo(pm, &inf);
      Check(restored && inf.hbrBack == nullptr, "菜单：关掉后菜单项与底色原样还原（程序看到的菜单数据不变）");
      // 从右到左（阿拉伯语时黑月菜单带 TPM_LAYOUTRTL）：画布按镜像后的视觉位置排版、不镜像贴上——勾选在右、子菜单箭头在左、文字靠右
      HMENU keep = g_mp.pm;
      memset(&g_mp, 0, sizeof(g_mp));
      g_mp.pm = keep;
      g_mp.rtl = true;
      SetForegroundWindow(g_form);
      Pump(30);
      SetTimer(g_form, 7701, 150, MenuProbeTimer);
      TrackPopupMenu(pm, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_TOPALIGN | TPM_LAYOUTRTL, fr.left + 60, fr.top + 80, 0, g_form, nullptr);
      KillTimer(g_form, 7701);
      Pump(30);
      if (!g_mp.mirrored) {
        printf("SKIP 菜单（从右到左）：这个系统的菜单窗口没有镜像，不判\n");
      } else {
        snprintf(d, sizeof(d), "(勾选 右 %d / 左 %d，箭头 左 %d / 右 %d，右侧文字 %d)", g_mp.rCheckRight, g_mp.rCheckLeft, g_mp.rArrowLeft, g_mp.rArrowRight, g_mp.rInkRight);
        Check(g_mp.rCheckRight > 3 && g_mp.rCheckLeft <= 1 && g_mp.rArrowLeft > 2 && g_mp.rArrowRight <= 1 && g_mp.rInkRight > 10,
              "菜单（从右到左）：勾选在右、子菜单箭头在左、文字靠右（阿拉伯语界面）", d);
      }
      DestroyMenu(pm);
      Pump(30);
    }
  }
  // —— 选择框键盘焦点：文字外围点线框（经典样式），控件四角不画 Win11 双圈 ——
  {
    HWND prevFocus = GetFocus();  // 用完恢复：焦点与“显示焦点提示”状态会影响后面的用例（高对比度时与参照按钮逐像素比较）
    SendMessageW(g_form, WM_CHANGEUISTATE, MAKEWPARAM(UIS_CLEAR, UISF_HIDEFOCUS), 0);
    SetFocus(g_btn);
    Pump(60);
    RECT rc;
    GetClientRect(g_chkOff, &rc);
    int W = rc.right < 400 ? (int)rc.right : 400, H = rc.bottom < 60 ? (int)rc.bottom : 60;
    static uint32_t a0[400 * 60];
    for (int y = 0; y < H; ++y)
      for (int x = 0; x < W; ++x) a0[y * W + x] = Px(g_chkOff, x, y);
    SetFocus(g_chkOff);
    Pump(80);
    int diff = 0, minx = W, maxx = -1, miny = H, maxy = -1;
    for (int y = 0; y < H; ++y)
      for (int x = 0; x < W; ++x)
        if (Px(g_chkOff, x, y) != a0[y * W + x]) {
          ++diff;
          if (x < minx) minx = x;
          if (x > maxx) maxx = x;
          if (y < miny) miny = y;
          if (y > maxy) maxy = y;
        }
    int corner = (Px(g_chkOff, 0, 0) != a0[0]) + (Px(g_chkOff, W - 1, 0) != a0[W - 1]) + (Px(g_chkOff, 0, H - 1) != a0[(H - 1) * W]) +
                 (Px(g_chkOff, W - 1, H - 1) != a0[(H - 1) * W + W - 1]);
    char d[128];
    snprintf(d, sizeof(d), "(变化 %d 像素，范围 x%d-%d y%d-%d，四角变化 %d)", diff, minx, maxx, miny, maxy, corner);
    Check(diff > 10 && corner == 0 && minx >= 13 && miny >= 1 && maxy <= H - 2, "选择框键盘焦点：文字外围点线框，方框与四角不变（不画 Win11 双圈）", d);
    SetFocus(g_comboList);
    Pump(80);
    uint32_t ce = Px(g_comboList, 30, 0), ci = Px(g_comboList, 30, 1);
    Check(Diff(ce, 0x0078D4) <= 12 && Lum(ci) > 230, "组合框键盘焦点：1 像素蓝边，里面不叠深色焦点圈", Hex(ce, 0x0078D4));
    SendMessageW(g_form, WM_CHANGEUISTATE, MAKEWPARAM(UIS_SET, UISF_HIDEFOCUS), 0);
    SetFocus(prevFocus ? prevFocus : g_btn);
    Pump(60);
  }
  // —— 反复重画不泄漏 GDI / USER 对象（长时间悬停、点击后句柄耗尽、界面不再重画的风险）——
  {
    for (int i = 0; i < 20; ++i) RedrawWindow(g_form, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN | RDW_UPDATENOW);
    Pump(50);  // 先热身：字体、画刷等一次性的缓存先建好
    DWORD g0 = GetGuiResources(GetCurrentProcess(), GR_GDIOBJECTS), u0 = GetGuiResources(GetCurrentProcess(), GR_USEROBJECTS);
    if (!g0) {
      // 取不到对象数（Wine 没实现 GetGuiResources）：改看 GDI 句柄表的“高水位”——释放的槽先被重用，泄漏会把表撑高。
      // 先校准：故意漏 500 个画刷，确认这个办法在这里看得出泄漏，再用它看引擎
      auto hiwater = []() {
        HBRUSH b[64];
        UINT_PTR mx = 0;
        for (int i = 0; i < 64; ++i) {
          b[i] = CreateSolidBrush(RGB(i, 1, 2));
          UINT_PTR v = (UINT_PTR)b[i] & 0xFFFF;
          if (v > mx) mx = v;
        }
        for (int i = 0; i < 64; ++i) DeleteObject(b[i]);
        return mx;
      };
      UINT_PTR c0 = hiwater();
      static HBRUSH leak[500];
      for (int i = 0; i < 500; ++i) leak[i] = CreateSolidBrush(RGB(3, 4, (BYTE)i));
      UINT_PTR c1 = hiwater();
      for (int i = 0; i < 500; ++i) DeleteObject(leak[i]);
      bool usable = c1 > c0 + 200;
      printf("INFO 句柄高水位校准：故意漏 500 个画刷前 %u、后 %u（%s）\n", (unsigned)c0, (unsigned)c1, usable ? "看得出泄漏，可以用" : "看不出，这个办法在这里不可用");
      if (!usable) {
        printf("SKIP 反复重画 300 次：这个系统既取不到对象数、高水位也看不出泄漏，真 Windows 上判\n");
      } else {
        UINT_PTR h0 = hiwater();
        for (int i = 0; i < 300; ++i) {
          RedrawWindow(g_form, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN | RDW_UPDATENOW);
          if (i % 50 == 0) Pump(5);
        }
        Pump(50);
        UINT_PTR h1 = hiwater();
        char d[96];
        snprintf(d, sizeof(d), "(句柄高水位 %u→%u；漏 500 个时涨了 %u)", (unsigned)h0, (unsigned)h1, (unsigned)(c1 - c0));
        Check(h1 <= h0 + 64, "反复重画 300 次（全部控件种类，约 9000 次控件绘制）：GDI 句柄表不被撑高（不泄漏）", d);
      }
    } else {
      for (int i = 0; i < 300; ++i) {
        RedrawWindow(g_form, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN | RDW_UPDATENOW);
        if (i % 50 == 0) Pump(5);
      }
      Pump(50);
      DWORD g1 = GetGuiResources(GetCurrentProcess(), GR_GDIOBJECTS), u1 = GetGuiResources(GetCurrentProcess(), GR_USEROBJECTS);
      char d[96];
      snprintf(d, sizeof(d), "(GDI %lu→%lu，USER %lu→%lu)", (unsigned long)g0, (unsigned long)g1, (unsigned long)u0, (unsigned long)u1);
      Check(g1 <= g0 + 4 && u1 <= u0 + 4, "反复重画 300 次（全部控件种类）：GDI、USER 对象数不增长", d);
    }
  }
  // —— 强调色 ——
  {
    XS_Set(2, 2, 0xFFD700, 0);  // 金色：配白字对比度不够，应自动加深
    uint32_t a = (uint32_t)XS_GetInfo(9, 0, 0, 0);
    double L1 = 0;
    {
      auto lin = [](double c) { c /= 255.0; return c <= 0.04045 ? c / 12.92 : pow((c + 0.055) / 1.055, 2.4); };
      L1 = 0.2126 * lin((a >> 16) & 255) + 0.7152 * lin((a >> 8) & 255) + 0.0722 * lin(a & 255);
    }
    double ratio = 1.05 / (L1 + 0.05);
    char d[64];
    snprintf(d, sizeof(d), "(#%06X, %.2f:1)", a, ratio);
    Check(ratio >= 4.5, "自定义强调色：自动加深到白字对比度≥4.5", d);
    RedrawWindow(g_chkOn, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
    Pump(60);
    RECT onRc;
    GetClientRect(g_chkOn, &onRc);
    int boxCenterY = onRc.bottom / 2;  // 与“选中的选择框”用例同一取样点
    uint32_t cf = Px(g_chkOn, 3, boxCenterY - 4);
    Check(Diff(cf, a) <= 10, "自定义强调色：浅色下选中的选择框跟着变（XS_Set 2 生效）", Hex(cf, a));
    XS_Set(2, 0, 0, 0);
    Check(XS_GetInfo(9, 0, 0, 0) == 0x005FB8, "恢复默认蓝（原皮肤 #005FB8）");
    RedrawWindow(g_chkOn, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
    Pump(60);
    uint32_t cf2 = Px(g_chkOn, 3, boxCenterY - 4);
    Check(Diff(cf2, 0x005FB8) <= 10, "恢复默认后：选中的选择框回到 #005FB8", Hex(cf2, 0x005FB8));
  }
  // —— 高对比度：交回系统 ——
  {
    XS_Set(101, 1, 0, 0);
    RedrawWindow(g_form, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN | RDW_UPDATENOW);
    Pump(100);
    Check(XS_GetInfo(6, 0, 0, 0) == 1 && LooksSystem(g_btn), "高对比度：交回系统绘制（与参照按钮一样）");
    XS_Set(101, -1, 0, 0);
    RedrawWindow(g_form, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN | RDW_UPDATENOW);
    Pump(100);
    Check(!LooksSystem(g_btn), "退出高对比度：恢复换肤外观");
  }
  // —— DWM 外框逻辑（假装 Win11 22621；Wine 里 DWM 调用无效，只核对引擎请求了哪些属性） ——
  {
    XS_Set(100, 22621, 0, 0);
    HWND pop = CreateWindowExW(0, L"XsTestForm", L"无边框", WS_POPUP | WS_VISIBLE, 60, 600, 200, 80, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    Ctl(L"Button", L"按钮", BS_PUSHBUTTON, 0, 10, 10, 80, 28, pop);
    XS_Attach((INT_PTR)pop, 0, 0, 0);
    Check((XS_GetInfo(13, (INT_PTR)pop, 0, 0) & 2) == 2, "Win11：无边框窗口请求圆角");
    XS_Detach((INT_PTR)pop, 0, 0, 0);
    SetWindowRgn(pop, CreateRoundRectRgn(0, 0, 200, 80, 30, 30), TRUE);
    XS_Attach((INT_PTR)pop, 0, 0, 0);
    Check((XS_GetInfo(13, (INT_PTR)pop, 0, 0) & 2) == 0, "Win11：设了窗口区域（黑月外形圆角）的不请求圆角（系统圆不了）");
    XS_Detach((INT_PTR)pop, 0, 0, 0);
    DestroyWindow(pop);
    XS_Set(3, 1, 0, 0);
    XS_Set(1, 2, 0, 0);
    INT_PTR fa = XS_GetInfo(13, (INT_PTR)g_form, 0, 0);
    Check((fa & 4) && (fa & 1) && !(fa & 2), "Win11：有标题栏的窗口请求 Mica 与深色标题栏、不改圆角");
    XS_Set(3, 0, 0, 0);
    XS_Set(1, 1, 0, 0);
    Check(XS_GetInfo(13, (INT_PTR)g_form, 0, 0) == 0, "关掉材质与深色：撤销请求");
    XS_Set(100, 19045, 0, 0);
    XS_Set(1, 2, 0, 0);
    fa = XS_GetInfo(13, (INT_PTR)g_form, 0, 0);
    Check(fa == 1, "Win10 22H2：只请求深色标题栏（没有圆角、材质）");
    XS_Set(1, 1, 0, 0);
    XS_Set(100, 7601, 0, 0);
    XS_Set(1, 2, 0, 0);
    Check(XS_GetInfo(13, (INT_PTR)g_form, 0, 0) == 0, "Win7：什么 DWM 属性都不请求");
    XS_Set(1, 1, 0, 0);
    XS_Set(100, 0, 0, 0);
  }
  // —— 屏幕上的真实圆角（Win11、Windows Server 2025 桌面体验这类 build ≥ 22000 的系统）——
  // 上面的 DWM 测试只核对引擎“请求了什么”（系统版本是模拟的）；窗口截图取的是窗口自己的画面，也看不到 DWM 切出来的圆角。
  // 这里读 DWM 合成后的屏幕像素：品红底板上放三个一样的白色无边框窗口——
  //   校准：测试自己直接向 DWM 要圆角。它都圆不了，说明这台机器关了圆角（虚拟机没有显卡加速、基本显示适配器等），验证不了，只记 INFO
  //   对照：什么也不要，应当是方角（证明圆角来自引擎，不是系统默认）
  //   被测：接入引擎，应当是圆角
  // 三个窗口与黑月外框一样是普通的无边框弹出窗口（不是工具窗口），底板才用工具窗口、不抢激活
  {
    int realBuild = (int)XS_GetInfo(7, 0, 0, 0);
    bool force = GetEnvironmentVariableW(L"XS_FORCE_CORNER", nullptr, 0) > 0;  // 在 Wine 里也走一遍：只验证不崩、截图能存
    if (realBuild < 22000 && !force) {
      printf("INFO 屏幕圆角：系统版本号 %d，不是 Win11 一代（Win11、Windows Server 2025 桌面体验），跳过\n", realBuild);
    } else {
      HINSTANCE hi = GetModuleHandleW(nullptr);
      HWND back = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE, L"XsMagenta", L"", WS_POPUP, 60, 60, 640, 230, nullptr, nullptr, hi, nullptr);
      HWND cal = CreateWindowExW(WS_EX_TOPMOST, L"XsTestForm", L"", WS_POPUP, 90, 110, 160, 110, nullptr, nullptr, hi, nullptr);
      HWND ctl = CreateWindowExW(WS_EX_TOPMOST, L"XsTestForm", L"", WS_POPUP, 300, 110, 160, 110, nullptr, nullptr, hi, nullptr);
      HWND sub = CreateWindowExW(WS_EX_TOPMOST, L"XsTestForm", L"", WS_POPUP, 510, 110, 160, 110, nullptr, nullptr, hi, nullptr);
      Ctl(L"Button", L"圆角", BS_PUSHBUTTON, 0, 30, 40, 100, 30, sub);
      typedef HRESULT(WINAPI * PFN_Set)(HWND, DWORD, LPCVOID, DWORD);
      typedef HRESULT(WINAPI * PFN_Flush)();
      HMODULE dwm = LoadLibraryW(L"dwmapi.dll");
      PFN_Set dset = dwm ? (PFN_Set)(void*)GetProcAddress(dwm, "DwmSetWindowAttribute") : nullptr;
      PFN_Flush dflush = dwm ? (PFN_Flush)(void*)GetProcAddress(dwm, "DwmFlush") : nullptr;
      DWORD round = 2;  // DWMWCP_ROUND
      HRESULT hrCal = dset ? dset(cal, 33, &round, sizeof(round)) : E_NOTIMPL;
      INT_PTR att = XS_Attach((INT_PTR)sub, 0, 0, 0);
      HWND order[4] = {back, cal, ctl, sub};
      for (HWND w : order) SetWindowPos(w, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
      for (HWND w : order) UpdateWindow(w);
      Pump(400);
      if (dflush) dflush();
      Pump(100);
      RECT rc, rt, rs;
      GetWindowRect(cal, &rc);
      GetWindowRect(ctl, &rt);
      GetWindowRect(sub, &rs);
      uint32_t pBack = ScreenPx(65, 65), pCal = ScreenPx(rc.left, rc.top), pCtl = ScreenPx(rt.left, rt.top);
      uint32_t pSub = ScreenPx(rs.left, rs.top), pSub2 = ScreenPx(rs.right - 1, rs.bottom - 1);
      char adapter[256];
      PrimaryAdapter(adapter, sizeof(adapter));
      printf("INFO 屏幕圆角：系统版本号 %d，主显示适配器“%s”，校准请求 hr=%08lX，被测接入=%d、请求的 DWM 属性=%d；底板 #%06X 校准左上 #%06X 对照左上 #%06X 被测左上 #%06X 右下 #%06X\n", realBuild,
             adapter, (unsigned long)hrCal, (int)att, (int)XS_GetInfo(13, (INT_PTR)sub, 0, 0), pBack, pCal, pCtl, pSub, pSub2);
      RECT shot = {60, 60, 700, 290};
      SaveScreenBmp(shot, L"圆角");
      if (!Magentaish(pBack)) {
        printf("INFO 屏幕圆角：屏幕上读不到底板（被别的窗口挡住或屏幕读取受限），不判\n");
      } else if (!Magentaish(pCal)) {
        printf("INFO 屏幕圆角：测试自己要的圆角也没有——这台机器的系统没开圆角（虚拟机没有显卡加速、基本显示适配器等），验证不了，不判。"
               "可以给虚拟机配显卡加速，或在 HKLM\\SOFTWARE\\Microsoft\\Windows\\Dwm 新建 DWORD ForceEffectMode＝2 后重启再测（非官方开关，测完可删）\n");
      } else {
        Check(!Magentaish(pCtl), "屏幕圆角：没接入引擎的无边框窗口是方角（对照）", Hex(pCtl));
        Check(Magentaish(pSub) && Magentaish(pSub2), "屏幕圆角：接入引擎的无边框窗口在屏幕上真的是圆角（左上、右下）", Hex(pSub));
      }
      XS_Detach((INT_PTR)sub, 0, 0, 0);
      DestroyWindow(sub);
      DestroyWindow(ctl);
      DestroyWindow(cal);
      DestroyWindow(back);
      if (dwm) FreeLibrary(dwm);
      SetForegroundWindow(g_form);
      Pump(50);
    }
  }
  // —— 跨线程 ——
  {
    HANDLE t = CreateThread(nullptr, 0, CrossAttach, nullptr, 0, nullptr);
    WaitForSingleObject(t, 5000);
    CloseHandle(t);
    Check(g_crossResult == 0 && g_crossErr == 3, "在别的线程接入窗口：拒绝（错误 3＝线程不对）");
    g_tReady = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    DWORD tid = 0;
    HANDLE ut = CreateThread(nullptr, 0, UiThread, nullptr, 0, &tid);
    WaitForSingleObject(g_tReady, 5000);
    Pump(200);
    Check(XS_GetInfo(4, (INT_PTR)g_tForm, 0, 0) == 2, "另一个界面线程接入自己的窗口");
    Check(XS_GetInfo(2, 0, 0, 0) == 2, "两个线程各一个根窗口");
    Check(XS_Detach((INT_PTR)g_tForm, 0, 0, 0) == 1 && XS_GetInfo(4, (INT_PTR)g_tForm, 0, 0) == 0, "在主线程卸下别的线程的根窗口（交给它自己的线程卸）");
    PostThreadMessageW(tid, WM_QUIT, 0, 0);
    WaitForSingleObject(ut, 5000);
    CloseHandle(ut);
  }
  // —— 性能 ——
  {
    LARGE_INTEGER f, a, b;
    QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&a);
    for (int i = 0; i < 300; ++i) RedrawWindow(g_btn, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
    QueryPerformanceCounter(&b);
    double btnMs = (double)(b.QuadPart - a.QuadPart) * 1000.0 / f.QuadPart / 300;
    QueryPerformanceCounter(&a);
    for (int i = 0; i < 300; ++i) RedrawWindow(g_comboList, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
    QueryPerformanceCounter(&b);
    double cbMs = (double)(b.QuadPart - a.QuadPart) * 1000.0 / f.QuadPart / 300;
    QueryPerformanceCounter(&a);
    for (int i = 0; i < 300; ++i) RedrawWindow(g_chkOn, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW);
    QueryPerformanceCounter(&b);
    double ckMs = (double)(b.QuadPart - a.QuadPart) * 1000.0 / f.QuadPart / 300;
    char d[128];
    snprintf(d, sizeof(d), "(按钮 %.3f ms，组合框 %.3f ms，选择框 %.3f ms)", btnMs, cbMs, ckMs);
    printf("INFO 每次重画 %s\n", d);
    Check(btnMs < 4 && cbMs < 4 && ckMs < 4, "每个控件一次完整重画不超过 4 毫秒（单核 Wine）", d);
  }
  // —— 卸下与反复接入（泄漏） ——
  {
    Check(XS_Detach((INT_PTR)g_form, 0, 0, 0) == 1, "卸下测试窗口");
    Check(XS_GetInfo(2, 0, 0, 0) == 0 && XS_GetInfo(16, 0, 0, 0) == 0, "卸下后没有残留的子类化");
    UpdateWindow(g_form);
    Pump(100);
    Check(LooksSystem(g_btn), "卸下后恢复系统外观（与参照按钮一样）");
    DWORD gdi0 = GetGuiResources(GetCurrentProcess(), GR_GDIOBJECTS), usr0 = GetGuiResources(GetCurrentProcess(), GR_USEROBJECTS);
    for (int i = 0; i < 200; ++i) {
      XS_Attach((INT_PTR)g_form, 0, 0, 0);
      RedrawWindow(g_form, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN | RDW_UPDATENOW);
      XS_Detach((INT_PTR)g_form, 0, 0, 0);
    }
    Pump(50);
    DWORD gdi1 = GetGuiResources(GetCurrentProcess(), GR_GDIOBJECTS), usr1 = GetGuiResources(GetCurrentProcess(), GR_USEROBJECTS);
    char d[128];
    snprintf(d, sizeof(d), "(GDI %lu→%lu，USER %lu→%lu)", gdi0, gdi1, usr0, usr1);
    printf("INFO 反复接入 200 次 %s\n", d);
    Check(XS_GetInfo(16, 0, 0, 0) == 0 && gdi1 <= gdi0 + 4 && usr1 <= usr0 + 4, "反复接入 / 卸下 200 次：不残留、不泄漏", d);
  }
  // —— 卸载安全：宿主中途 FreeLibrary ——
  {
    XS_Attach((INT_PTR)g_form, 0, 0, 0);
    Pump(50);
    FreeLibrary(g_dll);  // 宿主唯一的引用没了
    Check(GetModuleHandleW(BaseName()) != nullptr, "宿主 FreeLibrary 时还有换肤的窗口：DLL 自己留着（不会卸下正在用的代码）");
    SendMessageW(g_btn, WM_MOUSEMOVE, 0, MAKELPARAM(5, 5));
    RedrawWindow(g_form, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN | RDW_UPDATENOW);
    Pump(100);
    Check(true, "之后照常收发消息、重画，不崩溃");
    DestroyWindow(g_form);
    Pump(50);
    g_dll = LoadLibraryW(g_dllPath);
    XS_Shutdown = (Fn)(void*)GetProcAddress(g_dll, "XS_Shutdown");
    XS_GetInfo = (Fn)(void*)GetProcAddress(g_dll, "XS_GetInfo");
    Check(XS_GetInfo(16, 0, 0, 0) == 0, "窗口销毁时子类化全部摘掉");
    XS_Shutdown(0, 0, 0, 0);
    FreeLibrary(g_dll);
    Check(GetModuleHandleW(BaseName()) == nullptr, "XS_Shutdown 之后 FreeLibrary：DLL 真正卸下");
  }
  printf("SUMMARY %d passed, %d failed\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
