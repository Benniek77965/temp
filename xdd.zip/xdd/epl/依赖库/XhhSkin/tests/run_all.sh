#!/usr/bin/env bash
# 一键：编译 DLL → 检查导出 / 导入 / 位数 → 另一目录重编比对字节（可复现）→ cppcheck → 在 32 位 Wine 里跑 xstest 与带 6.0 清单的 xstest_v6（真实窗口、像素断言、截图）
# 需要：i686-w64-mingw32-g++、wine32（连同 fonts-wine）、xvfb-run、cppcheck。用法：tests/run_all.sh [截图目录]
set -e
export LANG=C.UTF-8 LC_ALL=C.UTF-8  # 路径里有中文（依赖库）：Wine 要在 UTF-8 下才认得
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SHOTS="${1:-/tmp/xhhskin_shots}"
bash "$ROOT/build.sh"
python3 "$ROOT/tools/check_dll.py" "$ROOT/out/XhhSkin.dll"
TMP="$(mktemp -d)"; cp -r "$ROOT/src" "$ROOT/build.sh" "$TMP/"; (cd "$TMP" && bash ./build.sh "$TMP/out" >/dev/null)
if cmp -s "$ROOT/out/XhhSkin.dll" "$TMP/out/XhhSkin.dll"; then echo "PASS 换目录重编，字节相同（可复现）"; else echo "FAIL 换目录重编，字节不同（不可复现）"; rm -rf "$TMP"; exit 1; fi; rm -rf "$TMP"
if command -v cppcheck >/dev/null; then
  cppcheck --quiet --enable=warning,performance,portability --inline-suppr --std=c++17 -DUNICODE -D_UNICODE -D_WIN32 --platform=win32W "$ROOT/src" 2> "$ROOT/out/cppcheck.txt" || true
  if [ -s "$ROOT/out/cppcheck.txt" ]; then echo "FAIL cppcheck 有告警："; cat "$ROOT/out/cppcheck.txt"; else echo "PASS cppcheck（warning / performance / portability）0 条"; fi
fi
i686-w64-mingw32-g++ -std=c++17 -O1 -DUNICODE -D_UNICODE -municode -static -o "$ROOT/out/xstest.exe" "$ROOT/tests/xstest.cpp" -lcomctl32 -lgdi32 -luser32 -Wl,--no-insert-timestamp
# 第二个测试程序：嵌入通用控件 6.0 的视觉样式清单（易语言编译时可能带这个清单），同一套测试在 6.0 版控件下再跑一遍
(cd "$ROOT/tests" && i686-w64-mingw32-windres -i xstest_v6.rc -O coff -o "$ROOT/out/xstest_v6_res.o")
i686-w64-mingw32-g++ -std=c++17 -O1 -DXS_TEST_V6 -DUNICODE -D_UNICODE -municode -static -o "$ROOT/out/xstest_v6.exe" "$ROOT/tests/xstest.cpp" "$ROOT/out/xstest_v6_res.o" -lcomctl32 -lgdi32 -luser32 -Wl,--no-insert-timestamp
rm -rf "$SHOTS"; mkdir -p "$SHOTS"
export WINEPREFIX="${WINEPREFIX:-$HOME/.wine-xhhskin}" WINEARCH=win32
# 中文测试字体：把 Droid Sans Fallback（fonts-droid-fallback 包）放进 Wine 前缀的字体目录，截图里的中文才不是方框
mkdir -p "$WINEPREFIX/drive_c/windows/Fonts"; [ -f /usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf ] && cp -n /usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf "$WINEPREFIX/drive_c/windows/Fonts/" || true
export WINEARCH=win32 WINEDEBUG=-all WINEDLLOVERRIDES="mscoree,mshtml="
cd "$ROOT/out"
RC=0; xvfb-run -a -s "-screen 0 1280x800x24" wine xstest.exe XhhSkin.dll "Z:$(echo "$SHOTS" | sed 's#/#\\#g')" > "$ROOT/out/xstest.log" 2>&1 || RC=$?
tr -d "\r" < "$ROOT/out/xstest.log"
mkdir -p "$SHOTS/v6"
RC6=0; xvfb-run -a -s "-screen 0 1280x800x24" wine xstest_v6.exe XhhSkin.dll "Z:$(echo "$SHOTS/v6" | sed 's#/#\\#g')" > "$ROOT/out/xstest_v6.log" 2>&1 || RC6=$?
tr -d "\r" < "$ROOT/out/xstest_v6.log"
echo "两个测试程序：通用控件 5 退出码 $RC，通用控件 6.0 退出码 $RC6"
[ "$RC" -eq 0 ] && [ "$RC6" -eq 0 ]
