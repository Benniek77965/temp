// XhhSkin 绘制层：32 位 DIB 画布上的抗锯齿图元（按有向距离算覆盖率，各系统逐像素一致），
// 文字用 GDI 按控件自己的字体画（多语言换字号、换字体照常生效），最后一次贴到窗口上。
#include <wchar.h>
#include "xs.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>

namespace xs {

bool Canvas::Begin(int W, int H) {
  End();
  if (W <= 0 || H <= 0 || W > 16384 || H > 16384) return false;
  BITMAPINFO bi;
  memset(&bi, 0, sizeof(bi));
  bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
  bi.bmiHeader.biWidth = W;
  bi.bmiHeader.biHeight = -H;  // 自上而下
  bi.bmiHeader.biPlanes = 1;
  bi.bmiHeader.biBitCount = 32;
  bi.bmiHeader.biCompression = BI_RGB;
  dc = CreateCompatibleDC(nullptr);
  if (!dc) return false;
  void* bits = nullptr;
  bmp = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
  if (!bmp || !bits) {
    DeleteDC(dc);
    dc = nullptr;
    bmp = nullptr;
    return false;
  }
  px = (uint32_t*)bits;
  oldBmp = SelectObject(dc, bmp);
  w = W;
  h = H;
  return true;
}

void Canvas::End() {
  if (dc) {
    SelectObject(dc, oldBmp);
    DeleteObject(bmp);
    DeleteDC(dc);
  }
  dc = nullptr;
  bmp = nullptr;
  oldBmp = nullptr;
  px = nullptr;
  w = h = 0;
}

static inline float Clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static inline int Clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

COLORREF ToCref(uint32_t rgb) { return RGB((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255); }
uint32_t FromCref(COLORREF c) { return ((uint32_t)GetRValue(c) << 16) | ((uint32_t)GetGValue(c) << 8) | GetBValue(c); }

uint32_t Over(uint32_t bg, Argb c) {
  uint32_t a = c >> 24;
  if (a >= 255) return c & 0xFFFFFF;
  if (a == 0) return bg & 0xFFFFFF;
  uint32_t r = (((c >> 16) & 255) * a + ((bg >> 16) & 255) * (255 - a) + 127) / 255;
  uint32_t g = (((c >> 8) & 255) * a + ((bg >> 8) & 255) * (255 - a) + 127) / 255;
  uint32_t b = ((c & 255) * a + (bg & 255) * (255 - a) + 127) / 255;
  return (r << 16) | (g << 8) | b;
}

// 按覆盖率 cov（0..1）把 c 叠到像素上
static inline void Blend(uint32_t* d, Argb c, float cov) {
  if (cov <= 0.0f) return;
  if (cov > 1.0f) cov = 1.0f;
  int a = (int)(((c >> 24) & 255) * cov + 0.5f);
  if (a <= 0) return;
  uint32_t v = *d;
  uint32_t ia = 255 - (uint32_t)a;
  uint32_t r = (((c >> 16) & 255) * a + ((v >> 16) & 255) * ia + 127) / 255;
  uint32_t g = (((c >> 8) & 255) * a + ((v >> 8) & 255) * ia + 127) / 255;
  uint32_t b = ((c & 255) * a + (v & 255) * ia + 127) / 255;
  *d = (r << 16) | (g << 8) | b;
}

void FillAll(Canvas& c, uint32_t rgb) {
  int n = c.w * c.h;
  rgb &= 0xFFFFFF;
  for (int i = 0; i < n; ++i) c.px[i] = rgb;
}

// 圆角矩形的有向距离（内负外正）
static inline float SdRR(float px, float py, float cx, float cy, float hw, float hh, float r) {
  float qx = fabsf(px - cx) - hw + r, qy = fabsf(py - cy) - hh + r;
  float ox = qx > 0 ? qx : 0, oy = qy > 0 ? qy : 0;
  float in = qx > qy ? qx : qy;
  if (in > 0) in = 0;
  return sqrtf(ox * ox + oy * oy) + in - r;
}

static inline float CovBelow(float sd, float edge) { return Clampf(edge - sd + 0.5f, 0.0f, 1.0f); }

void FillRR(Canvas& c, float x0, float y0, float x1, float y1, float r, Argb col) {
  if (x1 <= x0 || y1 <= y0 || (col >> 24) == 0) return;
  float hw = (x1 - x0) * 0.5f, hh = (y1 - y0) * 0.5f, cx = x0 + hw, cy = y0 + hh;
  r = Clampf(r, 0.0f, hw < hh ? hw : hh);
  int ix0 = Clampi((int)floorf(x0), 0, c.w), ix1 = Clampi((int)ceilf(x1), 0, c.w);
  int iy0 = Clampi((int)floorf(y0), 0, c.h), iy1 = Clampi((int)ceilf(y1), 0, c.h);
  for (int y = iy0; y < iy1; ++y) {
    uint32_t* row = c.px + y * c.w;
    for (int x = ix0; x < ix1; ++x) {
      float sd = SdRR(x + 0.5f, y + 0.5f, cx, cy, hw, hh, r);
      Blend(row + x, col, CovBelow(sd, 0.0f));
    }
  }
}

static inline Argb LerpArgb(Argb a, Argb b, float t) {
  t = Clampf(t, 0.0f, 1.0f);
  uint32_t out = 0;
  for (int s = 0; s < 32; s += 8) {
    float va = (float)((a >> s) & 255), vb = (float)((b >> s) & 255);
    out |= ((uint32_t)(va + (vb - va) * t + 0.5f) & 255) << s;
  }
  return out;
}

// 沿边内侧描 w 宽的边。gradPx > 0 时为 Win11 的“立体边”：底部 gradPx 像素内由 bottom 渐变回 top（0.33 处起渐变）
void StrokeRR(Canvas& c, float x0, float y0, float x1, float y1, float r, float w, Argb top, Argb bottom, float gradPx) {
  if (x1 <= x0 || y1 <= y0 || w <= 0) return;
  float hw = (x1 - x0) * 0.5f, hh = (y1 - y0) * 0.5f, cx = x0 + hw, cy = y0 + hh;
  r = Clampf(r, 0.0f, hw < hh ? hw : hh);
  int ix0 = Clampi((int)floorf(x0), 0, c.w), ix1 = Clampi((int)ceilf(x1), 0, c.w);
  int iy0 = Clampi((int)floorf(y0), 0, c.h), iy1 = Clampi((int)ceilf(y1), 0, c.h);
  float band = w + r + 1.0f;  // 只看离边不远的像素
  for (int y = iy0; y < iy1; ++y) {
    uint32_t* row = c.px + y * c.w;
    float py = y + 0.5f;
    Argb col = top;
    if (gradPx > 0) {
      float t = (y1 - py) / gradPx;  // 0 = 最底
      col = t <= 0.33f ? bottom : LerpArgb(bottom, top, (t - 0.33f) / 0.67f);
    }
    bool nearV = (py - y0) < band || (y1 - py) < band;
    for (int x = ix0; x < ix1; ++x) {
      float pxf = x + 0.5f;
      if (!nearV && (pxf - x0) >= band && (x1 - pxf) >= band) {
        // 跳过中间：跳到中段最后一列（单调向前；原写法在 x1-band 小数部分≥0.5 时会退回 x-1，死循环）
        int last = (int)floorf(x1 - band - 0.5f);
        if (last > x) x = last;
        continue;
      }
      float sd = SdRR(pxf, py, cx, cy, hw, hh, r);
      float cov = CovBelow(sd, 0.0f) - CovBelow(sd, -w);
      Blend(row + x, col, cov);
    }
  }
}

void FillCircle(Canvas& c, float cx, float cy, float rad, Argb col) {
  if (rad <= 0) return;
  int ix0 = Clampi((int)floorf(cx - rad - 1), 0, c.w), ix1 = Clampi((int)ceilf(cx + rad + 1), 0, c.w);
  int iy0 = Clampi((int)floorf(cy - rad - 1), 0, c.h), iy1 = Clampi((int)ceilf(cy + rad + 1), 0, c.h);
  for (int y = iy0; y < iy1; ++y)
    for (int x = ix0; x < ix1; ++x) {
      float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
      Blend(c.px + y * c.w + x, col, CovBelow(sqrtf(dx * dx + dy * dy) - rad, 0.0f));
    }
}

void StrokeCircle(Canvas& c, float cx, float cy, float rad, float w, Argb col) {
  if (rad <= 0 || w <= 0) return;
  int ix0 = Clampi((int)floorf(cx - rad - 1), 0, c.w), ix1 = Clampi((int)ceilf(cx + rad + 1), 0, c.w);
  int iy0 = Clampi((int)floorf(cy - rad - 1), 0, c.h), iy1 = Clampi((int)ceilf(cy + rad + 1), 0, c.h);
  for (int y = iy0; y < iy1; ++y)
    for (int x = ix0; x < ix1; ++x) {
      float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
      float sd = sqrtf(dx * dx + dy * dy) - rad;
      Blend(c.px + y * c.w + x, col, CovBelow(sd, 0.0f) - CovBelow(sd, -w));
    }
}

static inline float SegDist(float px, float py, float ax, float ay, float bx, float by) {
  float vx = bx - ax, vy = by - ay, wx = px - ax, wy = py - ay;
  float l2 = vx * vx + vy * vy;
  float t = l2 > 0 ? Clampf((wx * vx + wy * vy) / l2, 0.0f, 1.0f) : 0.0f;
  float dx = wx - vx * t, dy = wy - vy * t;
  return sqrtf(dx * dx + dy * dy);
}

// 圆头圆角折线（勾、下拉箭头）
void Polyline(Canvas& c, const float* pts, int n, float width, Argb col) {
  if (n < 2 || width <= 0) return;
  float minx = pts[0], maxx = pts[0], miny = pts[1], maxy = pts[1];
  for (int i = 1; i < n; ++i) {
    minx = fminf(minx, pts[i * 2]);
    maxx = fmaxf(maxx, pts[i * 2]);
    miny = fminf(miny, pts[i * 2 + 1]);
    maxy = fmaxf(maxy, pts[i * 2 + 1]);
  }
  float hwid = width * 0.5f;
  int ix0 = Clampi((int)floorf(minx - hwid - 1), 0, c.w), ix1 = Clampi((int)ceilf(maxx + hwid + 1), 0, c.w);
  int iy0 = Clampi((int)floorf(miny - hwid - 1), 0, c.h), iy1 = Clampi((int)ceilf(maxy + hwid + 1), 0, c.h);
  for (int y = iy0; y < iy1; ++y)
    for (int x = ix0; x < ix1; ++x) {
      float d = 1e9f;
      for (int i = 0; i + 1 < n; ++i) d = fminf(d, SegDist(x + 0.5f, y + 0.5f, pts[i * 2], pts[i * 2 + 1], pts[i * 2 + 2], pts[i * 2 + 3]));
      Blend(c.px + y * c.w + x, col, CovBelow(d - hwid, 0.0f));
    }
}

void FillRectA(Canvas& c, float x0, float y0, float x1, float y1, Argb col) {
  if (x1 <= x0 || y1 <= y0) return;
  int ix0 = Clampi((int)floorf(x0), 0, c.w), ix1 = Clampi((int)ceilf(x1), 0, c.w);
  int iy0 = Clampi((int)floorf(y0), 0, c.h), iy1 = Clampi((int)ceilf(y1), 0, c.h);
  for (int y = iy0; y < iy1; ++y) {
    float cy = fminf((float)y + 1, y1) - fmaxf((float)y, y0);
    for (int x = ix0; x < ix1; ++x) {
      float cx = fminf((float)x + 1, x1) - fmaxf((float)x, x0);
      Blend(c.px + y * c.w + x, col, Clampf(cx, 0, 1) * Clampf(cy, 0, 1));
    }
  }
}


static bool SolidBrushColor(HBRUSH hbr, COLORREF* out) {
  if (!hbr) return false;
  LOGBRUSH lb;
  if (GetObjectW(hbr, sizeof(lb), &lb) != (int)sizeof(lb)) return false;
  if (lb.lbStyle != BS_SOLID) return false;
  *out = lb.lbColor;
  return true;
}

static uint32_t ClassBrushColor(HWND h, uint32_t fallback) {
  HBRUSH hbr = (HBRUSH)GetClassLongPtrW(h, GCLP_HBRBACKGROUND);
  if (!hbr) return fallback;
  UINT_PTR v = (UINT_PTR)hbr;
  if (v > 0 && v <= 31) return FromCref(GetSysColor((int)(v - 1)));  // (HBRUSH)(COLOR_xxx + 1)
  COLORREF cr;
  return SolidBrushColor(hbr, &cr) ? FromCref(cr) : fallback;
}

static const uint32_t kSentinel = 0x00FE01FD;

// 让父窗口把 hwnd 背后那块的背景画进画布（与 DrawThemeParentBackground 同一做法：WM_ERASEBKGND + WM_PRINTCLIENT）。
// 返回没被画到的像素个数
static int PrintParent(Canvas& c, HWND hwnd, HWND parent, int ox, int oy) {
  POINT pt = {ox, oy};
  MapWindowPoints(hwnd, parent, &pt, 1);
  int n = c.w * c.h;
  for (int i = 0; i < n; ++i) c.px[i] = kSentinel;
  POINT old;
  SetViewportOrgEx(c.dc, -pt.x, -pt.y, &old);
  int saved = SaveDC(c.dc);
  SendMessageW(parent, WM_ERASEBKGND, (WPARAM)c.dc, 0);
  RestoreDC(c.dc, saved);
  saved = SaveDC(c.dc);
  SendMessageW(parent, WM_PRINTCLIENT, (WPARAM)c.dc, PRF_CLIENT);
  RestoreDC(c.dc, saved);
  SetViewportOrgEx(c.dc, old.x, old.y, nullptr);
  GdiFlush();
  int left = 0;
  for (int i = 0; i < n; ++i) {
    c.px[i] &= 0xFFFFFF;  // GDI 写的像素 alpha 为 0，统一去掉
    if (c.px[i] == kSentinel) ++left;
  }
  return left;
}

// 把 hwnd 背后的背景铺满画布（画布 (0,0) 是 hwnd 客户区的 (ox,oy)；非客户区绘制时为负）。
// 顺序：父窗口在 WM_CTLCOLOR* 里给的非默认纯色 → 父窗口实际画出来的样子 → XS_Set 10 交代的容器底色 → 默认刷 → 窗口类刷 → 主题底色。
// 返回画布中心的颜色；textOut 带回父窗口指定的文字颜色（没指定为 CLR_INVALID）
uint32_t ParentBackground(Canvas& c, HWND hwnd, UINT ctlMsg, COLORREF* textOut, int ox, int oy, HWND root) {
  if (textOut) *textOut = CLR_INVALID;
  uint32_t fallback = Pal().windowBg & 0xFFFFFF;
  HWND parent = (GetWindowLongW(hwnd, GWL_STYLE) & WS_CHILD) ? GetParent(hwnd) : nullptr;
  if (!parent) {
    FillAll(c, fallback);
    return fallback;
  }
  bool haveCtl = false;
  uint32_t ctlColor = 0;
  if (ctlMsg) {
    const COLORREF sentinelText = RGB(1, 2, 3);
    SetTextColor(c.dc, sentinelText);
    HBRUSH hbr = (HBRUSH)SendMessageW(parent, ctlMsg, (WPARAM)c.dc, (LPARAM)hwnd);
    COLORREF tc = GetTextColor(c.dc);
    if (textOut && tc != sentinelText) *textOut = tc;
    COLORREF bc;
    bool solid = SolidBrushColor(hbr, &bc);
    bool isDefault = solid && (hbr == GetSysColorBrush(COLOR_BTNFACE) || hbr == GetSysColorBrush(COLOR_WINDOW) || hbr == GetSysColorBrush(COLOR_3DFACE));
    // 按钮：父窗口对 WM_CTLCOLORBTN 只给默认画刷（或不是纯色）时，再问一次 WM_CTLCOLORSTATIC——易语言的图片框等容器在这里给出
    // 自己的底色画刷（实测日志：图片框里的选择框就走这条），按钮圆角外侧用它，不必等打印父窗口失败后落到兜底色
    if (ctlMsg == WM_CTLCOLORBTN && (!solid || isDefault)) {
      int sv = SaveDC(c.dc);
      HBRUSH hs = (HBRUSH)SendMessageW(parent, WM_CTLCOLORSTATIC, (WPARAM)c.dc, (LPARAM)hwnd);
      RestoreDC(c.dc, sv);
      COLORREF sc;
      if (SolidBrushColor(hs, &sc) && hs != GetSysColorBrush(COLOR_BTNFACE) && hs != GetSysColorBrush(COLOR_WINDOW) && hs != GetSysColorBrush(COLOR_3DFACE)) {
        FillAll(c, FromCref(sc));
        return FromCref(sc);
      }
    }
    if (solid) {
      if (!isDefault) {
        FillAll(c, FromCref(bc));
        return FromCref(bc);
      }
      haveCtl = true;
      ctlColor = FromCref(bc);
    }
  }
  int left = PrintParent(c, hwnd, parent, ox, oy);
  int n = c.w * c.h;
  if (left < n) {
    if (left > 0) {
      COLORREF cc = ContainerColor(hwnd, root);
      uint32_t fb = cc != 0xFFFFFFFF ? FromCref(cc) : (haveCtl ? ctlColor : ClassBrushColor(parent, fallback));
      // 父窗口只画了一部分：没画到的像素填就近一层登记的容器底色（XS_Set 10），没有登记时用控件色或父窗口类刷。
      // 不能“原样不动、留给屏幕”：改文字、启用等消息里系统按钮会先当场连底色画一遍经典外观，留着不画就会残留（见测试）
      for (int i = 0; i < n; ++i)
        if (c.px[i] == kSentinel) c.px[i] = fb;
    }
    return c.px[(c.h / 2) * c.w + c.w / 2] & 0xFFFFFF;
  }
  COLORREF cc = ContainerColor(hwnd, root);
  uint32_t fb = cc != 0xFFFFFFFF ? FromCref(cc) : (haveCtl ? ctlColor : ClassBrushColor(parent, fallback));
  FillAll(c, fb);
  return fb;
}

static HFONT CtlFont(HWND h) {
  HFONT f = (HFONT)SendMessageW(h, WM_GETFONT, 0, 0);
  return f ? f : (HFONT)GetStockObject(DEFAULT_GUI_FONT);
}

// 控件文字（宽字符；组合框 / 列表框的项由调用方取）
static int CtlText(HWND h, wchar_t* buf, int cap) {
  buf[0] = 0;
  int n = GetWindowTextW(h, buf, cap);
  return n < 0 ? 0 : n;
}

static bool FocusCues(HWND h) {
  LRESULT ui = SendMessageW(h, WM_QUERYUISTATE, 0, 0);
  return (ui & UISF_HIDEFOCUS) == 0;
}

static bool HideAccel(HWND h) {
  LRESULT ui = SendMessageW(h, WM_QUERYUISTATE, 0, 0);
  return (ui & UISF_HIDEACCEL) != 0;
}

static void DrawTextOn(Canvas& c, HFONT f, const wchar_t* s, int len, RECT rc, UINT fmt, uint32_t rgbOpaque) {
  if (len <= 0) return;
  HGDIOBJ of = SelectObject(c.dc, f);
  SetBkMode(c.dc, TRANSPARENT);
  SetTextColor(c.dc, ToCref(rgbOpaque));
  DrawTextW(c.dc, s, len, &rc, fmt);
  SelectObject(c.dc, of);
}

static inline uint32_t PxAt(Canvas& c, int x, int y) {
  x = Clampi(x, 0, c.w - 1);
  y = Clampi(y, 0, c.h - 1);
  return c.px[y * c.w + x] & 0xFFFFFF;
}

static float Px(float v, float s) {  // 设计尺寸 × DPI，至少 1
  float r = v * s;
  return r < 1.0f ? 1.0f : r;
}


// —— 按钮 ——
static bool PaintPush(Win* w, Canvas& c) {
  HWND h = w->h;
  const Palette& p = Pal();
  float s = DpiScale(h);
  LONG st = GetWindowLongW(h, GWL_STYLE), ex = GetWindowLongW(h, GWL_EXSTYLE);
  wchar_t text[512];
  int len = CtlText(h, text, 512);
  HICON ico = (HICON)SendMessageW(h, BM_GETIMAGE, IMAGE_ICON, 0);
  HBITMAP bmp = (HBITMAP)SendMessageW(h, BM_GETIMAGE, IMAGE_BITMAP, 0);
  if (len == 0 && (ico || bmp || (st & (BS_ICON | BS_BITMAP)))) return false;  // 纯图片按钮：外观是图片本身，交回原样绘制
  bool disabled = !IsWindowEnabled(h);
  LRESULT bs = SendMessageW(h, BM_GETSTATE, 0, 0);
  bool pressed = (bs & BST_PUSHED) != 0;
  int type = st & BS_TYPEMASK;
  bool pushlike = (st & BS_PUSHLIKE) && type != BS_PUSHBUTTON && type != BS_DEFPUSHBUTTON;
  bool checked = pushlike && (SendMessageW(h, BM_GETCHECK, 0, 0) != BST_UNCHECKED);
  bool focus = GetFocus() == h && FocusCues(h);
  ParentBackground(c, h, WM_CTLCOLORBTN, nullptr, 0, 0, w->root);
  float W = (float)c.w, H = (float)c.h;
  float r = Clampf(4 * s, 0, fminf(W, H) * 0.5f);
  Argb fill, top, bottom, tcol;
  // 原皮肤：默认按钮不填强调色；按钮式选择框、单选框选中时用按下态
  bool down = pressed || checked;
  fill = disabled ? p.fillDisabled : down ? p.fillPressed : w->hot ? p.fillHover : p.fillRest;
  top = disabled ? p.strokeDisabled : down ? p.strokePressed : w->hot ? p.strokeHover : focus ? p.focusLine : p.strokeTop;  // 原皮肤焦点与默认同图，这里补上：键盘焦点时蓝边
  bottom = top;
  tcol = disabled ? p.textDisabled : p.textPrimary;
  FillRR(c, 0, 0, W, H, r, fill);
  StrokeRR(c, 0, 0, W, H, r, Px(1, s), top, bottom, 0);
  // 内容：图标 / 位图在左，文字随后（BS_LEFT / BS_RIGHT / BS_TOP / BS_BOTTOM 照原义）
  int iw = 0, ih = 0;
  if (ico) {
    ICONINFO ii;
    if (GetIconInfo(ico, &ii)) {
      BITMAP bm;
      if (ii.hbmColor && GetObjectW(ii.hbmColor, sizeof(bm), &bm)) {
        iw = bm.bmWidth;
        ih = bm.bmHeight;
      } else if (ii.hbmMask && GetObjectW(ii.hbmMask, sizeof(bm), &bm)) {
        iw = bm.bmWidth;
        ih = bm.bmHeight / 2;
      }
      if (ii.hbmColor) DeleteObject(ii.hbmColor);
      if (ii.hbmMask) DeleteObject(ii.hbmMask);
    }
  } else if (bmp) {
    BITMAP bm;
    if (GetObjectW(bmp, sizeof(bm), &bm)) {
      iw = bm.bmWidth;
      ih = abs(bm.bmHeight);
    }
  }
  // 窄按钮先缩小两侧留白（原先固定留白会把“获取验证码”截成“获取验...”）。按实际要画的量：前缀 & 不算宽度，带图标时加上图标与间距。
  // 单行按钮：缩到放得下为止，确实放不下才省略；多行按钮：只在缩小留白后能排成一行时才缩，否则保持正常留白、让文字换行
  float pad = 11 * s;
  if (len) {
    HGDIOBJ of1 = SelectObject(c.dc, CtlFont(h));
    RECT m1 = {0, 0, 0, 0};
    DrawTextW(c.dc, text, len, &m1, DT_SINGLELINE | DT_CALCRECT | (HideAccel(h) ? DT_HIDEPREFIX : 0));
    SelectObject(c.dc, of1);
    float need = (float)(m1.right - m1.left) + (iw ? (float)iw + 6 * s : 0);
    float room = (W - need) / 2;
    if (room < pad && (room >= 2 * s || !(st & BS_MULTILINE))) pad = fmaxf(room, 2 * s);
  }
  RECT rc = {(LONG)pad, (LONG)(2 * s), (LONG)(W - pad), (LONG)(H - 2 * s)};
  HFONT f = CtlFont(h);
  UINT fmt = DT_NOCLIP;
  if (st & BS_MULTILINE) fmt |= DT_WORDBREAK;
  else fmt |= DT_SINGLELINE | DT_END_ELLIPSIS;
  int hal = st & (BS_LEFT | BS_RIGHT | BS_CENTER);
  if (hal == BS_LEFT) fmt |= DT_LEFT;
  else if (hal == BS_RIGHT) fmt |= DT_RIGHT;
  else fmt |= DT_CENTER;
  if (HideAccel(h)) fmt |= DT_HIDEPREFIX;
  if (ex & WS_EX_RTLREADING) fmt |= DT_RTLREADING;
  // 先量文字
  RECT tr = rc;
  int tw = 0, th = 0;
  if (len) {
    HGDIOBJ of = SelectObject(c.dc, f);
    RECT m = {0, 0, rc.right - rc.left - (iw ? iw + (LONG)(6 * s) : 0), 0};
    DrawTextW(c.dc, text, len, &m, (fmt & ~(DT_END_ELLIPSIS | DT_NOCLIP)) | DT_CALCRECT);
    SelectObject(c.dc, of);
    tw = m.right - m.left;
    th = m.bottom - m.top;
  }
  int gap = (iw && len) ? (int)(6 * s) : 0;
  int total = iw + gap + tw;
  int avail = rc.right - rc.left;
  if (total > avail) total = avail;
  int x0 = rc.left;
  if (hal == BS_RIGHT) x0 = rc.right - total;
  else if (hal != BS_LEFT) x0 = rc.left + (avail - total) / 2;
  int val = st & (BS_TOP | BS_BOTTOM | BS_VCENTER);
  int contentH = th > ih ? th : ih;
  int y0 = (int)((H - contentH) / 2);
  if (val == BS_TOP) y0 = rc.top;
  else if (val == BS_BOTTOM) y0 = rc.bottom - contentH;
  if (iw) {
    int iy = y0 + (contentH - ih) / 2;
    if (ico) {
      DrawIconEx(c.dc, x0, iy, ico, iw, ih, 0, nullptr, DI_NORMAL);
    } else {
      HDC mdc = CreateCompatibleDC(c.dc);
      HGDIOBJ ob = SelectObject(mdc, bmp);
      BitBlt(c.dc, x0, iy, iw, ih, mdc, 0, 0, SRCCOPY);
      SelectObject(mdc, ob);
      DeleteDC(mdc);
    }
  }
  if (len) {
    uint32_t under = PxAt(c, (int)(W / 2), (int)(H / 2));
    tr.left = x0 + iw + gap;
    tr.right = (LONG)(tr.left + (total - iw - gap));
    if (tr.right > rc.right) tr.right = rc.right;
    tr.top = y0;
    tr.bottom = y0 + th;
    if (!(st & BS_MULTILINE)) {
      tr.top = 0;
      tr.bottom = (LONG)H;
      fmt |= DT_VCENTER;
      if (val == BS_TOP) {
        tr.top = rc.top;
        fmt &= ~DT_VCENTER;
      } else if (val == BS_BOTTOM) {
        tr.top = rc.bottom - th;
        fmt &= ~DT_VCENTER;
      }
    }
    fmt &= ~(DT_LEFT | DT_RIGHT | DT_CENTER);
    fmt |= iw ? DT_LEFT : (hal == BS_LEFT ? DT_LEFT : hal == BS_RIGHT ? DT_RIGHT : DT_CENTER);
    if (!iw) {
      tr.left = rc.left;
      tr.right = rc.right;
    }
    DrawTextOn(c, f, text, len, tr, fmt, Over(under, tcol));
  }
  return true;
}

// —— 选择框 / 单选框 ——
static bool PaintCheck(Win* w, Canvas& c) {
  HWND h = w->h;
  const Palette& p = Pal();
  float s = DpiScale(h);
  LONG st = GetWindowLongW(h, GWL_STYLE), ex = GetWindowLongW(h, GWL_EXSTYLE);
  bool radio = w->kind == K_RADIO;
  bool disabled = !IsWindowEnabled(h);
  LRESULT bs = SendMessageW(h, BM_GETSTATE, 0, 0);
  bool pressed = (bs & BST_PUSHED) != 0;
  LRESULT chk = SendMessageW(h, BM_GETCHECK, 0, 0);
  bool on = chk == BST_CHECKED, indet = chk == BST_INDETERMINATE;
  COLORREF ctlText;
  ParentBackground(c, h, WM_CTLCOLORSTATIC, &ctlText, 0, 0, w->root);
  float W = (float)c.w, H = (float)c.h;
  HFONT f = CtlFont(h);
  TEXTMETRICW tm;
  HGDIOBJ of = SelectObject(c.dc, f);
  GetTextMetricsW(c.dc, &tm);
  SelectObject(c.dc, of);
  float box = 13 * s;  // 原皮肤：13×13（随 DPI 缩放）
  box = fminf(box, fminf(W, H));
  box = floorf(box + 0.5f);
  bool right = (st & BS_LEFTTEXT) != 0 || (ex & WS_EX_RIGHT) != 0;
  float bx = right ? W - box : 0;
  int val = st & (BS_TOP | BS_BOTTOM | BS_VCENTER);
  float by = floorf((H - box) / 2 + 0.5f);
  if (val == BS_TOP) by = 0;
  else if (val == BS_BOTTOM) by = H - box;
  float k = box / 20.0f;  // 设计稿 20×20
  if (radio) {
    float cx = bx + box / 2, cy = by + box / 2, rad = box / 2;
    if (on) {
      Argb fill = disabled ? p.accentDisabled : pressed ? p.accentPressed : w->hot ? p.accentHover : p.accent;
      FillCircle(c, cx, cy, rad, fill);
      float dot = 3.85f * k;  // 原皮肤：白色圆心直径约 5（13 像素圆），悬停、按下不变
      Argb dc = disabled ? p.textOnAccentDisabled : p.textOnAccent;
      FillCircle(c, cx, cy, dot, dc);
    } else {
      Argb fill = disabled ? 0 : pressed ? p.checkFillPressed : w->hot ? p.checkFillHover : p.checkFillRest;
      if (fill) FillCircle(c, cx, cy, rad, fill);
      StrokeCircle(c, cx, cy, rad, Px(1, s), disabled ? p.checkStrokeDisabled : w->hot ? p.checkStrokeHover : p.checkStroke);
    }
  } else {
    float r = 4 * k;
    if (on || indet) {
      Argb fill = disabled ? p.accentDisabled : pressed ? p.accentPressed : w->hot ? p.accentHover : p.accent;
      FillRR(c, bx, by, bx + box, by + box, r, fill);
      Argb g = disabled ? p.textOnAccentDisabled : pressed ? p.textOnAccentPressed : p.textOnAccent;
      if (on) {
        float pts[6] = {bx + 5.2f * k, by + 10.4f * k, bx + 8.4f * k, by + 13.6f * k, bx + 14.8f * k, by + 7.0f * k};
        Polyline(c, pts, 3, fmaxf(1.4f * k, 1.0f), g);
      } else {
        float pts[4] = {bx + 6.0f * k, by + 10.0f * k, bx + 14.0f * k, by + 10.0f * k};
        Polyline(c, pts, 2, fmaxf(1.4f * k, 1.0f), g);
      }
    } else {
      Argb fill = disabled ? 0 : pressed ? p.checkFillPressed : w->hot ? p.checkFillHover : p.checkFillRest;
      if (fill) FillRR(c, bx, by, bx + box, by + box, r, fill);
      StrokeRR(c, bx, by, bx + box, by + box, r, Px(1, s), disabled ? p.checkStrokeDisabled : w->hot ? p.checkStrokeHover : p.checkStroke,
               disabled ? p.checkStrokeDisabled : w->hot ? p.checkStrokeHover : p.checkStroke, 0);
    }
  }
  wchar_t text[512];
  int len = CtlText(h, text, 512);
  float gap = floorf(5 * s + 0.5f);  // 原皮肤：方框与文字间距
  RECT tr;
  if (right) {
    tr.left = 0;
    tr.right = (LONG)(bx - gap);
  } else {
    tr.left = (LONG)(bx + box + gap);
    tr.right = (LONG)W;
  }
  tr.top = 0;
  tr.bottom = (LONG)H;
  bool focusCue = GetFocus() == h && FocusCues(h);  // 键盘焦点（显示焦点提示时）才算焦点框的位置
  RECT focusRc = {(LONG)(bx - 2), (LONG)(by - 2), (LONG)(bx + box + 2), (LONG)(by + box + 2)};  // 没有文字时框住方框
  if (len && tr.right > tr.left) {
    UINT fmt = DT_NOCLIP | (right ? DT_RIGHT : DT_LEFT);
    if (st & BS_MULTILINE) fmt |= DT_WORDBREAK;
    else fmt |= DT_SINGLELINE | DT_VCENTER;
    if (val == BS_TOP) fmt &= ~DT_VCENTER;
    if (val == BS_BOTTOM) fmt = (fmt & ~DT_VCENTER) | DT_BOTTOM;
    if ((st & BS_MULTILINE) && val != BS_TOP) {  // 多行时自己纵向居中
      HGDIOBJ o2 = SelectObject(c.dc, f);
      RECT m = {0, 0, tr.right - tr.left, 0};
      DrawTextW(c.dc, text, len, &m, DT_WORDBREAK | DT_CALCRECT);
      SelectObject(c.dc, o2);
      int th = m.bottom - m.top;
      if (val == BS_BOTTOM) tr.top = (LONG)(H - th);
      else tr.top = (LONG)((H - th) / 2);
      tr.bottom = tr.top + th;
    }
    if (HideAccel(h)) fmt |= DT_HIDEPREFIX;
    if (ex & WS_EX_RTLREADING) fmt |= DT_RTLREADING;
    uint32_t under = PxAt(c, (tr.left + tr.right) / 2, (int)(H / 2));
    uint32_t col;
    if (disabled) col = Over(under, p.textDisabled);
    else if (ctlText != CLR_INVALID) col = FromCref(ctlText);
    else col = Over(under, p.textPrimary);
    DrawTextOn(c, f, text, len, tr, fmt, col);
    if (focusCue) {  // 文字实际占的范围（焦点框用；没有焦点时不必量）
      HGDIOBJ o3 = SelectObject(c.dc, f);
      RECT m = {0, 0, tr.right - tr.left, 0};
      DrawTextW(c.dc, text, len, &m, (fmt & (DT_WORDBREAK | DT_SINGLELINE | DT_HIDEPREFIX | DT_RTLREADING)) | DT_CALCRECT);
      SelectObject(c.dc, o3);
      LONG tw = m.right - m.left < tr.right - tr.left ? m.right - m.left : tr.right - tr.left, th = m.bottom - m.top;
      LONG ty = (st & BS_MULTILINE) ? tr.top : (fmt & DT_VCENTER) ? (LONG)((H - th) / 2) : (fmt & DT_BOTTOM) ? (LONG)(H - th) : 0;
      focusRc.left = right ? tr.right - tw - 1 : tr.left - 1;
      focusRc.right = focusRc.left + tw + 2;
      focusRc.top = ty - 1;
      focusRc.bottom = ty + th + 1;
    }
  }
  // 键盘焦点：经典的点线框（原皮肤没有焦点提示；Win11 的双圈与原皮肤的扁平样式不搭）
  if (focusCue) {
    RECT fr = focusRc;
    if (fr.left < 0) fr.left = 0;
    if (fr.top < 0) fr.top = 0;
    if (fr.right > c.w) fr.right = c.w;
    if (fr.bottom > c.h) fr.bottom = c.h;
    if (fr.right > fr.left && fr.bottom > fr.top) {
      GdiFlush();
      DrawFocusRect(c.dc, &fr);
      GdiFlush();
    }
  }
  return true;
}

// —— 分组框：只画边框与标题，里面留给父窗口（与系统分组框一样） ——
static void PaintGroup(Win* w, HDC dst) {
  HWND h = w->h;
  const Palette& p = Pal();
  float s = DpiScale(h);
  RECT rc;
  GetClientRect(h, &rc);
  int W = rc.right, H = rc.bottom;
  Canvas c;
  if (!c.Begin(W, H)) return;
  COLORREF ctlText;
  ParentBackground(c, h, WM_CTLCOLORSTATIC, &ctlText, 0, 0, w->root);
  HFONT f = CtlFont(h);
  wchar_t text[512];
  int len = CtlText(h, text, 512);
  TEXTMETRICW tm;
  HGDIOBJ of = SelectObject(c.dc, f);
  GetTextMetricsW(c.dc, &tm);
  SIZE sz = {0, 0};
  if (len) GetTextExtentPoint32W(c.dc, text, len, &sz);
  SelectObject(c.dc, of);
  float th = (float)tm.tmHeight;
  float top = floorf(th / 2);
  float r = 0, sw = Px(1, s);  // 原皮肤：分组框直角细边
  LONG st = GetWindowLongW(h, GWL_STYLE);
  bool alignRight = (st & (BS_LEFT | BS_RIGHT | BS_CENTER)) == BS_RIGHT;
  int capX0 = alignRight ? (int)(W - 8 * s - sz.cx - 4 * s) : (int)(8 * s);
  int capX1 = capX0 + (len ? (int)(sz.cx + 8 * s) : 0);
  capX0 = Clampi(capX0, 0, W);
  capX1 = Clampi(capX1, 0, W);
  int capY1 = Clampi((int)ceilf(th), 0, H);
  // 标题下面的边线要擦掉：先存下这块背景，描边后再放回
  int cw = capX1 - capX0;
  uint32_t* save = nullptr;
  if (len && cw > 0 && capY1 > 0) {
    save = (uint32_t*)malloc((size_t)cw * capY1 * 4);
    if (save)
      for (int y = 0; y < capY1; ++y) memcpy(save + y * cw, c.px + y * W + capX0, (size_t)cw * 4);
  }
  StrokeRR(c, 0, top, (float)W, (float)H, r, sw, p.groupStroke, p.groupStroke, 0);
  if (save) {
    for (int y = 0; y < capY1; ++y) memcpy(c.px + y * W + capX0, save + y * cw, (size_t)cw * 4);
    free(save);
  }
  bool disabled = !IsWindowEnabled(h);
  if (len) {
    RECT tr = {capX0 + (LONG)(4 * s), 0, capX1, capY1};
    uint32_t under = PxAt(c, (tr.left + tr.right) / 2, capY1 / 2);
    uint32_t col = disabled ? Over(under, p.textDisabled) : (ctlText != CLR_INVALID ? FromCref(ctlText) : Over(under, p.textPrimary));
    UINT fmt = DT_SINGLELINE | DT_LEFT | DT_TOP | DT_NOCLIP | (HideAccel(h) ? DT_HIDEPREFIX : 0);
    DrawTextOn(c, f, text, len, tr, fmt, col);
  }
  // 只贴边框一圈（含圆角内侧）与标题，里面不动
  int inset = (int)ceilf(r + sw);
  HRGN all = CreateRectRgn(0, 0, W, H);
  HRGN in = CreateRectRgn(inset, (int)top + inset, W - inset, H - inset);
  HRGN cap = CreateRectRgn(capX0, 0, capX1, capY1);
  CombineRgn(all, all, in, RGN_DIFF);
  CombineRgn(all, all, cap, RGN_OR);
  int saved = SaveDC(dst);
  ExtSelectClipRgn(dst, all, RGN_AND);
  BitBlt(dst, 0, 0, W, H, c.dc, 0, 0, SRCCOPY);
  RestoreDC(dst, saved);
  DeleteObject(all);
  DeleteObject(in);
  DeleteObject(cap);
}

// —— 组合框 ——
static bool PaintCombo(Win* w, Canvas& c, RECT* editRect) {
  HWND h = w->h;
  const Palette& p = Pal();
  float s = DpiScale(h);
  LONG st = GetWindowLongW(h, GWL_STYLE);
  int type = st & 3;
  bool editable = type == CBS_DROPDOWN;
  bool disabled = !IsWindowEnabled(h);
  bool dropped = SendMessageW(h, CB_GETDROPPEDSTATE, 0, 0) != 0;
  COMBOBOXINFO ci;
  memset(&ci, 0, sizeof(ci));
  ci.cbSize = sizeof(ci);
  GetComboBoxInfo(h, &ci);
  HWND focus = GetFocus();
  bool hasFocus = focus == h || (ci.hwndItem && focus == ci.hwndItem);
  ParentBackground(c, h, 0, nullptr, 0, 0, w->root);
  float W = (float)c.w, H = (float)c.h;
  float r = 0;  // 原皮肤：组合框直角
  if (editable) {
    // 可编辑：按文本框的样子（底色跟编辑框、底边一条，获得焦点时强调色）
    COLORREF eb = RGB(255, 255, 255);
    HWND parent = GetParent(h);
    if (parent) {
      HDC tdc = c.dc;
      HBRUSH hb = (HBRUSH)SendMessageW(parent, disabled ? WM_CTLCOLORSTATIC : WM_CTLCOLOREDIT, (WPARAM)tdc, (LPARAM)(ci.hwndItem ? ci.hwndItem : h));
      LOGBRUSH lb;
      if (hb && GetObjectW(hb, sizeof(lb), &lb) == (int)sizeof(lb) && lb.lbStyle == BS_SOLID) eb = lb.lbColor;
      else eb = ToCref(Over(Pal().windowBg & 0xFFFFFF, disabled ? p.fieldFillDisabled : p.fieldFill));
    }
    FillRR(c, 0, 0, W, H, r, 0xFF000000 | FromCref(eb));
    Argb fs = disabled ? p.fieldStrokeDisabled : (hasFocus || w->hot) ? p.fieldStrokeFocus : p.fieldStroke;
    StrokeRR(c, 0, 0, W, H, r, Px(1, s), fs, fs, 0);
    if (editRect && ci.hwndItem) *editRect = ci.rcItem;
  } else {
    Argb fill = disabled ? p.fillDisabled : p.fieldFill;  // 原皮肤：下拉列表同编辑框，白底细边
    FillRR(c, 0, 0, W, H, r, fill);
    Argb fs = disabled ? p.fieldStrokeDisabled : (dropped || w->hot || hasFocus) ? p.fieldStrokeFocus : p.fieldStroke;
    StrokeRR(c, 0, 0, W, H, r, Px(1, s), fs, fs, 0);
    int sel = (int)SendMessageW(h, CB_GETCURSEL, 0, 0);
    wchar_t buf[512];
    int len = 0;
    if (sel >= 0) {
      LRESULT need = SendMessageW(h, CB_GETLBTEXTLEN, sel, 0);
      if (need > 0 && need < 511) {
        LRESULT got = SendMessageW(h, CB_GETLBTEXT, sel, (LPARAM)buf);
        if (got > 0) len = (int)got;
      }
    }
    float aw = fminf(H, 32 * s);
    float pad = Clampf(H * 0.35f, 4 * s, 11 * s);
    if (len) {
      RECT tr = {(LONG)pad, 0, (LONG)(W - aw), (LONG)H};
      uint32_t under = PxAt(c, (int)(W / 2), (int)(H / 2));
      UINT fmt = DT_SINGLELINE | DT_VCENTER | DT_LEFT | DT_NOPREFIX | DT_END_ELLIPSIS;
      if (GetWindowLongW(h, GWL_EXSTYLE) & WS_EX_RTLREADING) fmt |= DT_RTLREADING;
      DrawTextOn(c, CtlFont(h), buf, len, tr, fmt, Over(under, disabled ? p.textDisabled : p.textPrimary));
    }
  }
  // 下拉箭头（与 Win11 ChevronDown 同比例）
  {
    GdiFlush();
    float aw = fminf(H, 32 * s);
    float cx = W - aw / 2, cy = H / 2;
    float hwid = 4.5f * s, hhei = 2.25f * s;
    if (dropped && !editable) cy += 0.5f * s;
    float pts[6] = {cx - hwid, cy - hhei, cx, cy + hhei, cx + hwid, cy - hhei};
    Polyline(c, pts, 3, Px(1, s), disabled ? p.chevronDisabled : p.chevron);
  }
  return true;
}

// —— 列表框 / 组合框的下拉列表 ——
static bool PaintList(Win* w, Canvas& c) {
  HWND h = w->h;
  const Palette& p = Pal();
  float s = DpiScale(h);
  LONG st = GetWindowLongW(h, GWL_STYLE);
  bool popup = w->kind == K_COMBOLIST;
  bool disabled = !IsWindowEnabled(popup && w->owner ? w->owner : h);
  uint32_t bg;
  if (popup) {
    bg = Over(p.windowBg & 0xFFFFFF, p.popupBg);
  } else {
    bg = Over(p.windowBg & 0xFFFFFF, p.fieldFill);
    HWND parent = GetParent(h);
    if (parent) {
      HBRUSH hb = (HBRUSH)SendMessageW(parent, WM_CTLCOLORLISTBOX, (WPARAM)c.dc, (LPARAM)h);
      LOGBRUSH lb;
      if (hb && hb != GetSysColorBrush(COLOR_WINDOW) && GetObjectW(hb, sizeof(lb), &lb) == (int)sizeof(lb) && lb.lbStyle == BS_SOLID) bg = FromCref(lb.lbColor);
    }
  }
  FillAll(c, bg);
  int count = (int)SendMessageW(h, LB_GETCOUNT, 0, 0);
  if (count == LB_ERR) count = 0;
  int top = (int)SendMessageW(h, LB_GETTOPINDEX, 0, 0);
  if (top < 0) top = 0;
  bool multi = (st & (LBS_MULTIPLESEL | LBS_EXTENDEDSEL)) != 0;
  int cur = multi ? -1 : (int)SendMessageW(h, LB_GETCURSEL, 0, 0);
  int caret = (int)SendMessageW(h, LB_GETCARETINDEX, 0, 0);
  HFONT f = CtlFont(h);
  bool focusCues = !popup && GetFocus() == h && FocusCues(h);
  // 深色主题（浅色时列表交回系统画）：与系统画法同一套——选中项整行系统高亮色、高亮文字色，文字从左缘 2 像素起，键盘焦点是虚线框
  uint32_t hl = FromCref(GetSysColor(COLOR_HIGHLIGHT)), hlt = FromCref(GetSysColor(COLOR_HIGHLIGHTTEXT));
  for (int i = top; i < count; ++i) {
    RECT ir;
    if (SendMessageW(h, LB_GETITEMRECT, i, (LPARAM)&ir) == LB_ERR) break;
    if (ir.top >= c.h) break;
    bool sel = multi ? SendMessageW(h, LB_GETSEL, i, 0) > 0 : i == cur;
    bool lit = sel && !disabled;
    if (lit) FillRectA(c, (float)ir.left, (float)ir.top, (float)ir.right, (float)ir.bottom, 0xFF000000 | hl);
    LRESULT need = SendMessageW(h, LB_GETTEXTLEN, i, 0);
    if (need > 0 && need < 1023) {
      wchar_t buf[1024];
      LRESULT got = SendMessageW(h, LB_GETTEXT, i, (LPARAM)buf);
      if (got > 0) {
        GdiFlush();
        RECT tr = {(LONG)(ir.left + 2 * s), ir.top, (LONG)(ir.right - 2 * s), ir.bottom};
        UINT fmt = DT_SINGLELINE | DT_VCENTER | DT_LEFT | DT_NOPREFIX | DT_END_ELLIPSIS;
        DrawTextOn(c, f, buf, (int)got, tr, fmt, lit ? hlt : Over(bg, disabled ? p.textDisabled : p.textPrimary));
      }
    }
    if (focusCues && i == caret) {
      GdiFlush();
      DrawFocusRect(c.dc, &ir);
    }
  }
  return true;
}

// —— 进度条 ——
static bool PaintProgress(Win* w, Canvas& c) {
  HWND h = w->h;
  const Palette& p = Pal();
  float s = DpiScale(h);
  LONG st = GetWindowLongW(h, GWL_STYLE);
  ParentBackground(c, h, 0, nullptr, 0, 0, w->root);
  float W = (float)c.w, H = (float)c.h;
  bool vert = (st & PBS_VERTICAL) != 0;
  int lo = (int)SendMessageW(h, PBM_GETRANGE, TRUE, 0), hi = (int)SendMessageW(h, PBM_GETRANGE, FALSE, 0);
  int pos = (int)SendMessageW(h, PBM_GETPOS, 0, 0);
  int state = ComctlMajor(h) >= 6 ? (int)SendMessageW(h, PBM_GETSTATE, 0, 0) : 1;
  float frac = hi > lo ? Clampf((float)(pos - lo) / (float)(hi - lo), 0, 1) : 0;
  bool marquee = (st & PBS_MARQUEE) != 0;
  float len = vert ? H : W, thick = vert ? W : H;
  float t = Clampf(floorf(thick * 0.25f + 0.5f), 3 * s, 6 * s);
  if (t > thick) t = thick;
  Argb bar = !IsWindowEnabled(h) ? p.textDisabled : state == 2 ? p.progressError : state == 3 ? p.progressPaused : p.accent;
  float mid = thick / 2;
  float tl = Px(1, s);
  if (vert) {
    FillRectA(c, mid - tl / 2, 0, mid + tl / 2, H, p.progressTrack);
    float a = marquee ? len * 0.35f : len * (1 - frac);
    float b = marquee ? len * 0.65f : len;
    if (b - a > 0.5f) FillRR(c, mid - t / 2, a, mid + t / 2, b, t / 2, bar);
  } else {
    FillRectA(c, 0, mid - tl / 2, W, mid + tl / 2, p.progressTrack);
    float a = marquee ? len * 0.35f : 0;
    float b = marquee ? len * 0.65f : len * frac;
    if (b - a > 0.5f) FillRR(c, a, mid - t / 2, b, mid + t / 2, t / 2, bar);
  }
  return true;
}

void PaintDialogBg(Win* w, HDC dst) {
  w->footerTop = DialogFooterTop(w->h, w->ownPaint != 0);  // 每次画都按当前布局重算：激活、显示的先后顺序和之后挪动按钮都不影响；子控件随后要底色时用这个值
  RECT rc;
  GetClientRect(w->h, &rc);
  Canvas c;
  if (!c.Begin(rc.right, rc.bottom)) return;
  const Palette& p = Pal();
  uint32_t content = Over(p.windowBg & 0xFFFFFF, p.dialogContent);
  FillAll(c, content);
  if (w->footerTop >= 0 && w->footerTop < rc.bottom) {
    FillRectA(c, 0, (float)w->footerTop, (float)rc.right, (float)rc.bottom, 0xFF000000 | Over(content, p.dialogFooter));
    FillRectA(c, 0, (float)w->footerTop, (float)rc.right, (float)w->footerTop + Px(1, DpiScale(w->h)), p.dialogDivider);
  }
  BitBlt(dst, 0, 0, rc.right, rc.bottom, c.dc, 0, 0, SRCCOPY);
}

// 按钮区：最下面一排按钮上沿再往上留出与按钮下方相同的空白。信息框一律有按钮区；别的对话框只有按钮都在下半部时才画
int DialogFooterTop(HWND dlg, bool msgBox) {
  RECT rc;
  GetClientRect(dlg, &rc);
  int minTop = 0x7FFFFFFF, maxBottom = -1;
  for (HWND ch = GetWindow(dlg, GW_CHILD); ch; ch = GetWindow(ch, GW_HWNDNEXT)) {
    // 看按钮自己的 WS_VISIBLE 位，不用 IsWindowVisible：后者要求祖先也可见，而 Windows 的信息框是先激活、后显示，
    // 在 HCBT_ACTIVATE 时对话框还隐藏着，按 IsWindowVisible 一个按钮都数不到（真机 Win10 信息框底部因此是白的）
    if (!(GetWindowLongW(ch, GWL_STYLE) & WS_VISIBLE)) continue;
    wchar_t cls[16];
    if (!GetClassNameW(ch, cls, 16) || lstrcmpiW(cls, L"Button") != 0) continue;
    int type = GetWindowLongW(ch, GWL_STYLE) & BS_TYPEMASK;
    if (type != BS_PUSHBUTTON && type != BS_DEFPUSHBUTTON) continue;
    RECT r;
    GetWindowRect(ch, &r);
    MapWindowPoints(nullptr, dlg, (POINT*)&r, 2);
    if (r.top < minTop) minTop = r.top;
    if (r.bottom > maxBottom) maxBottom = r.bottom;
  }
  if (maxBottom < 0) return -1;
  if (!msgBox && minTop < rc.bottom / 2) return -1;  // 按钮在旁边或上半部（输入框一类）：不画按钮区
  int below = rc.bottom - maxBottom;
  if (below < 0) below = 0;
  int top = minTop - below;
  return top < 0 ? 0 : top;
}

// 非客户区边框厚度：按客户区原点相对窗口左上角的实际偏移算。编辑框会自己改样式位（例如去掉 WS_BORDER、自己留边），
// 按 WS_BORDER / WS_EX_CLIENTEDGE 判断会漏掉；取上边的偏移（水平滚动条在下面，竖直滚动条在左右，都不影响上边）
bool NcBorder(HWND h, int* b) {
  RECT wr;
  if (!GetWindowRect(h, &wr)) return false;
  POINT o = {0, 0};
  if (!ClientToScreen(h, &o)) return false;
  int top = o.y - wr.top;
  int left = (GetWindowLongW(h, GWL_EXSTYLE) & WS_EX_LAYOUTRTL) ? wr.right - o.x : o.x - wr.left;
  int v = top > 0 ? top : left;
  if (v < 0) v = 0;
  if (v > 16) v = 16;
  *b = v;
  return v > 0;
}

// 编辑框：系统先画滚动条等，再只把边框那一圈换成原皮肤的样子（见函数里的说明）
// 非客户区换肤只画边框那一圈：客户区、可见的滚动条（连同两条滚动条之间的方角）都挖掉不碰。
// 原先按单一边框宽度、四边对称挖空：上下内边距比左右大的编辑框（注册、登录窗口的胶囊输入框靠撑高上下非客户区让文字垂直居中）
// 挖出来的左边界比真实客户区靠右，失去焦点重画边框时客户区左边一条被铺上底色，第一个字被盖住；左右比上下大时盖住的是文字顶上一条
static void ExcludeInner(HDC dc, HWND h, const WINDOWINFO& wi) {
  bool rtl = (GetWindowLongW(h, GWL_EXSTYLE) & WS_EX_LAYOUTRTL) != 0;  // 从右到左布局：窗口 DC 是镜像的
  auto cut = [&](const RECT& r) {
    if (r.right <= r.left || r.bottom <= r.top) return;
    int x0 = rtl ? (int)(wi.rcWindow.right - r.right) : (int)(r.left - wi.rcWindow.left);
    int y0 = (int)(r.top - wi.rcWindow.top);
    ExcludeClipRect(dc, x0, y0, x0 + (r.right - r.left), y0 + (r.bottom - r.top));
  };
  cut(wi.rcClient);
  RECT vs = {0, 0, 0, 0}, hs = {0, 0, 0, 0};
  SCROLLBARINFO sb;
  memset(&sb, 0, sizeof(sb));
  sb.cbSize = sizeof(sb);
  if (GetScrollBarInfo(h, OBJID_VSCROLL, &sb) && !(sb.rgstate[0] & (STATE_SYSTEM_INVISIBLE | STATE_SYSTEM_OFFSCREEN))) vs = sb.rcScrollBar;
  memset(&sb, 0, sizeof(sb));
  sb.cbSize = sizeof(sb);
  if (GetScrollBarInfo(h, OBJID_HSCROLL, &sb) && !(sb.rgstate[0] & (STATE_SYSTEM_INVISIBLE | STATE_SYSTEM_OFFSCREEN))) hs = sb.rcScrollBar;
  cut(vs);
  cut(hs);
  if (vs.right > vs.left && hs.right > hs.left) {  // 两条滚动条都在：它们之间的方角
    RECT corner = {vs.left, hs.top, vs.right, hs.bottom};
    cut(corner);
  }
}

void PaintEditFrame(Win* w, HDC target) {
  HWND h = w->h;
  int bb = 0;
  if (!NcBorder(h, &bb)) return;
  WINDOWINFO wi;
  memset(&wi, 0, sizeof(wi));
  wi.cbSize = sizeof(wi);
  if (!GetWindowInfo(h, &wi)) return;
  int W = wi.rcWindow.right - wi.rcWindow.left, H = wi.rcWindow.bottom - wi.rcWindow.top;
  Canvas c;
  if (!c.Begin(W, H)) return;
  const Palette& p = Pal();
  float s = DpiScale(h);
  int ox = wi.rcWindow.left - wi.rcClient.left, oy = wi.rcWindow.top - wi.rcClient.top;
  ParentBackground(c, h, 0, nullptr, ox, oy, w->root);
  LONG st = GetWindowLongW(h, GWL_STYLE);
  bool disabled = !IsWindowEnabled(h);
  bool ro = (st & ES_READONLY) != 0;
  COLORREF eb = ToCref(Over(p.windowBg & 0xFFFFFF, disabled ? p.fieldFillDisabled : p.fieldFill));
  HWND parent = GetParent(h);
  if (parent) {
    HDC tdc = GetDC(h);
    HBRUSH hb = (HBRUSH)SendMessageW(parent, (disabled || ro) ? WM_CTLCOLORSTATIC : WM_CTLCOLOREDIT, (WPARAM)tdc, (LPARAM)h);
    ReleaseDC(h, tdc);
    LOGBRUSH lb;
    if (hb && GetObjectW(hb, sizeof(lb), &lb) == (int)sizeof(lb) && lb.lbStyle == BS_SOLID) eb = lb.lbColor;
  }
  float r = 0;  // 原皮肤：编辑框直角
  FillRR(c, 0, 0, (float)W, (float)H, r, 0xFF000000 | FromCref(eb));
  bool focus = GetFocus() == h;
  // 原皮肤：有凹入、浅凹入等边框样式的编辑框画 1 像素直角细边（获得焦点时蓝色）；
  // 没有边框样式位却留了边框位置的（单线边框被编辑框自己去掉样式位、或程序留的内边距）只铺底色，看起来就是无边框——SkinSharp 也是这样画的（登录、注册窗口的输入框）
  LONG ex = GetWindowLongW(h, GWL_EXSTYLE);
  bool line = (ex & (WS_EX_CLIENTEDGE | WS_EX_STATICEDGE | WS_EX_WINDOWEDGE | WS_EX_DLGMODALFRAME)) != 0 || (st & (WS_BORDER | WS_DLGFRAME)) != 0;
  if (line) {
    Argb fs = disabled ? p.fieldStrokeDisabled : (focus && !ro) ? p.fieldStrokeFocus : p.fieldStroke;
    StrokeRR(c, 0, 0, (float)W, (float)H, r, Px(1, s), fs, fs, 0);
  }
  HDC dc = target ? target : GetWindowDC(h);
  if (!dc) return;
  int saved = SaveDC(dc);
  if (target) SelectClipRgn(dc, nullptr);  // 画进 WM_PRINT 的 DC：控件自己的打印可能留下剪裁区（编辑框会），先清掉，只按客户区、滚动条挖空
  ExcludeInner(dc, h, wi);
  BitBlt(dc, 0, 0, W, H, c.dc, 0, 0, SRCCOPY);
  RestoreDC(dc, saved);
  if (!target) ReleaseDC(h, dc);
}

// 下拉列表 / 列表框的细边（Win11 上下拉列表的圆角与外边由 DWM 画，这里只把系统的方边换成底色或细边）
void PaintPopupFrame(Win* w, HDC target) {
  HWND h = w->h;
  WINDOWINFO wi;
  memset(&wi, 0, sizeof(wi));
  wi.cbSize = sizeof(wi);
  if (!GetWindowInfo(h, &wi)) return;
  if (EqualRect(&wi.rcWindow, &wi.rcClient)) return;  // 没有非客户区
  int W = wi.rcWindow.right - wi.rcWindow.left, H = wi.rcWindow.bottom - wi.rcWindow.top;
  Canvas c;
  if (!c.Begin(W, H)) return;
  const Palette& p = Pal();
  float s = DpiScale(h);
  FillAll(c, Over(p.windowBg & 0xFFFFFF, p.popupBg));
  if (!(w->applied & 2)) StrokeRR(c, 0, 0, (float)W, (float)H, 0, Px(1, s), p.popupStroke, p.popupStroke, 0);  // Win11 有系统圆角与细边时不另画
  HDC dc = target ? target : GetWindowDC(h);
  if (!dc) return;
  int saved = SaveDC(dc);
  if (target) SelectClipRgn(dc, nullptr);  // 画进 WM_PRINT 的 DC：控件自己的打印可能留下剪裁区（编辑框会），先清掉，只按客户区、滚动条挖空
  ExcludeInner(dc, h, wi);
  BitBlt(dc, 0, 0, W, H, c.dc, 0, 0, SRCCOPY);
  RestoreDC(dc, saved);
  if (!target) ReleaseDC(h, dc);
}

void PaintListFrame(Win* w, HDC target) {
  if (w->kind == K_COMBOLIST) {
    PaintPopupFrame(w, target);
    return;
  }
  HWND h = w->h;
  int bb = 0;
  if (!NcBorder(h, &bb)) return;
  WINDOWINFO wi;
  memset(&wi, 0, sizeof(wi));
  wi.cbSize = sizeof(wi);
  if (!GetWindowInfo(h, &wi)) return;
  int W = wi.rcWindow.right - wi.rcWindow.left, H = wi.rcWindow.bottom - wi.rcWindow.top;
  Canvas c;
  if (!c.Begin(W, H)) return;
  const Palette& p = Pal();
  float s = DpiScale(h);
  {
    // 原皮肤：列表框与编辑框、组合框、下拉列表一样是 1 像素直角 #D9D9D9 细边（原先 4 像素圆角：单线边框的列表框边框区只有 1 像素，
    // 弧线落进被挖掉的客户区，四个角缺线）。边框区内侧（凹入式边框有 2 像素）按列表框自己的底色填
    uint32_t fill = Over(p.windowBg & 0xFFFFFF, p.fieldFill);
    HWND parent = GetParent(h);
    if (parent) {
      HDC tdc = GetDC(h);
      HBRUSH hb = (HBRUSH)SendMessageW(parent, WM_CTLCOLORLISTBOX, (WPARAM)tdc, (LPARAM)h);
      ReleaseDC(h, tdc);
      LOGBRUSH lb;
      if (hb && hb != GetSysColorBrush(COLOR_WINDOW) && GetObjectW(hb, sizeof(lb), &lb) == (int)sizeof(lb) && lb.lbStyle == BS_SOLID) fill = FromCref(lb.lbColor);
    }
    FillAll(c, fill);
    StrokeRR(c, 0, 0, (float)W, (float)H, 0, Px(1, s), p.fieldStroke, p.fieldStroke, 0);
  }
  HDC dc = target ? target : GetWindowDC(h);
  if (!dc) return;
  int saved = SaveDC(dc);
  if (target) SelectClipRgn(dc, nullptr);  // 画进 WM_PRINT 的 DC：控件自己的打印可能留下剪裁区（编辑框会），先清掉，只按客户区、滚动条挖空
  ExcludeInner(dc, h, wi);
  BitBlt(dc, 0, 0, W, H, c.dc, 0, 0, SRCCOPY);
  RestoreDC(dc, saved);
  if (!target) ReleaseDC(h, dc);
}

// 交回原样绘制的按钮类：没有文字的按钮（纯图片按钮；易语言的超级按钮、图形按钮一类 16×24 的播放 / 暂停图标，
// 只画“按钮框”而没有内容的 Win11 按钮没有意义）；带图片的选择框 / 单选框（外观就是图片本身）。有文字的按钮带图片照常画（图片在左、文字随后）
bool Themable(Win* w) {
  if (w->kind != K_PUSH && w->kind != K_CHECK && w->kind != K_RADIO) return true;
  HWND h = w->h;
  if (w->kind == K_PUSH) return GetWindowTextLengthW(h) > 0;
  if (GetWindowLongW(h, GWL_STYLE) & (BS_ICON | BS_BITMAP)) return false;
  return !SendMessageW(h, BM_GETIMAGE, IMAGE_ICON, 0) && !SendMessageW(h, BM_GETIMAGE, IMAGE_BITMAP, 0);
}

void PaintControl(Win* w, HDC dst) {
  if (w->kind == K_GROUP) {
    PaintGroup(w, dst);
    return;
  }
  RECT rc;
  GetClientRect(w->h, &rc);
  Canvas c;
  if (!c.Begin(rc.right, rc.bottom)) return;
  bool ok = false;
  RECT exclude = {0, 0, 0, 0};
  switch (w->kind) {
    case K_PUSH: ok = PaintPush(w, c); break;
    case K_CHECK:
    case K_RADIO: ok = PaintCheck(w, c); break;
    case K_COMBO: ok = PaintCombo(w, c, &exclude); break;
    case K_LISTBOX:
    case K_COMBOLIST: ok = PaintList(w, c); break;
    case K_PROGRESS: ok = PaintProgress(w, c); break;
    default: break;
  }
  w->passive = ok ? 0 : 1;
  if (!ok) return;
  GdiFlush();
  int saved = SaveDC(dst);
  if (exclude.right > exclude.left) ExcludeClipRect(dst, exclude.left, exclude.top, exclude.right, exclude.bottom);
  DWORD rop = SRCCOPY;
  if (GetLayout(dst) & LAYOUT_RTL) rop |= NOMIRRORBITMAP;
  BitBlt(dst, 0, 0, rc.right, rc.bottom, c.dc, 0, 0, rop);
  RestoreDC(dst, saved);
}

// —— 菜单（所有者窗口按自绘画的菜单项）——
// 外观与下拉列表同一套：弹出层底色、浅灰圆角悬停底（左右各内缩 4）、文字常态 / 禁止色；勾选画 ✓、单选画圆点，子菜单画灰色 ›，
// 分隔线是弹出层细边色；默认项粗体；“\t”后面的快捷键文字靠右、用灰色。从右到左的菜单（DC 是镜像的）按镜像后的视觉位置排版
struct MenuFontCache {
  int dpi;
  HFONT normal, bold;
  int th;
  int avg;  // 平均字宽：“a～z A～Z”52 个字母的总宽 /52（四舍五入），与 Windows 菜单的算法相同
};
static MenuFontCache g_mf = {0, nullptr, nullptr, 0, 0};
typedef BOOL(WINAPI* PFN_SpiForDpi)(UINT, UINT, PVOID, UINT, UINT);

static void MenuFontsFor(int dpi) {
  if (g_mf.normal && g_mf.dpi == dpi) return;
  NONCLIENTMETRICSW ncm;
  memset(&ncm, 0, sizeof(ncm));
  ncm.cbSize = sizeof(ncm);
  static PFN_SpiForDpi pFor = (PFN_SpiForDpi)(void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "SystemParametersInfoForDpi");
  BOOL ok = pFor ? pFor(SPI_GETNONCLIENTMETRICS, sizeof(ncm), &ncm, 0, (UINT)dpi) : SystemParametersInfoW(SPI_GETNONCLIENTMETRICS, sizeof(ncm), &ncm, 0);
  LOGFONTW lf = ncm.lfMenuFont;
  if (!ok || !lf.lfFaceName[0]) {
    memset(&lf, 0, sizeof(lf));
    lf.lfHeight = -MulDiv(9, dpi, 72);
    lf.lfCharSet = DEFAULT_CHARSET;
    lstrcpynW(lf.lfFaceName, L"Microsoft YaHei UI", LF_FACESIZE);
  }
  HFONT n = CreateFontIndirectW(&lf);
  lf.lfWeight = FW_BOLD;
  HFONT b = CreateFontIndirectW(&lf);
  if (!n) {
    if (b) DeleteObject(b);
    return;
  }
  if (g_mf.normal) DeleteObject(g_mf.normal);
  if (g_mf.bold) DeleteObject(g_mf.bold);
  g_mf.normal = n;
  g_mf.bold = b ? b : n;
  HDC dc = GetDC(nullptr);
  HGDIOBJ of = SelectObject(dc, n);
  TEXTMETRICW tm;
  memset(&tm, 0, sizeof(tm));
  GetTextMetricsW(dc, &tm);
  SIZE az = {0, 0};
  GetTextExtentPoint32W(dc, L"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", 52, &az);
  SelectObject(dc, of);
  ReleaseDC(nullptr, dc);
  g_mf.avg = az.cx > 0 ? (int)((az.cx + 26) / 52) : (tm.tmAveCharWidth > 0 ? tm.tmAveCharWidth : MulDiv(7, dpi, 96));
  g_mf.th = tm.tmHeight > 0 ? tm.tmHeight : MulDiv(16, dpi, 96);
  g_mf.dpi = dpi;
}

HBRUSH MenuBackBrush() {
  static HBRUSH br = nullptr;
  static uint32_t col = 0xFFFFFFFF;
  const Palette& p = Pal();
  uint32_t want = Over(p.windowBg & 0xFFFFFF, p.popupBg);
  if (!br || col != want) {  // 换了主题：建新画刷（旧的可能还设在正开着的菜单里，不删，主题极少切换）
    HBRUSH nb = CreateSolidBrush(ToCref(want));
    if (nb) {
      br = nb;
      col = want;
    }
  }
  return br;
}

static int MenuItemH(float s) {
  int ih = g_mf.th + (int)(12 * s + 0.5f);
  int mn = (int)(24 * s + 0.5f);
  return ih < mn ? mn : ih;
}

void MenuMeasure(HWND owner, MEASUREITEMSTRUCT* mis, const MenuItemView& v) {
  float s = DpiScale(owner);
  MenuFontsFor((int)(96 * s + 0.5f));
  if (v.type & MFT_SEPARATOR) {
    mis->itemHeight = (UINT)(9 * s + 0.5f);
    mis->itemWidth = 1;
    return;
  }
  const wchar_t* tab = v.len > 0 ? wmemchr(v.text, L'\t', (size_t)v.len) : nullptr;
  int ll = tab ? (int)(tab - v.text) : v.len, al = tab ? v.len - ll - 1 : 0;
  HDC dc = GetDC(nullptr);
  HGDIOBJ of = SelectObject(dc, (v.state & MFS_DEFAULT) ? g_mf.bold : g_mf.normal);
  RECT r1 = {0, 0, 0, 0}, r2 = {0, 0, 0, 0};
  if (ll > 0) DrawTextW(dc, v.text, ll, &r1, DT_SINGLELINE | DT_CALCRECT);  // 前缀 & 不算宽度
  SelectObject(dc, g_mf.normal);
  if (al > 0) DrawTextW(dc, tab + 1, al, &r2, DT_SINGLELINE | DT_CALCRECT | DT_NOPREFIX);
  SelectObject(dc, of);
  ReleaseDC(nullptr, dc);
  int w = (int)(32 * s) + (int)(r1.right - r1.left) + (al > 0 ? (int)(24 * s) + (int)(r2.right - r2.left) : 0) + (int)(40 * s);
  w -= 2 * g_mf.avg;  // 系统会在自绘菜单项的宽度上再加两倍的菜单字体平均字宽（Wine 在 Windows 上实测得出，见其 user32 菜单测试的 2*MOD_avec）
  mis->itemWidth = (UINT)(w > 1 ? w : 1);
  mis->itemHeight = (UINT)MenuItemH(s);
}

void MenuDraw(const DRAWITEMSTRUCT* dis, HWND owner, const MenuItemView& v) {
  RECT rc = dis->rcItem;
  int W = rc.right - rc.left, H = rc.bottom - rc.top;
  if (W <= 0 || H <= 0) return;
  float s = DpiScale(owner);
  MenuFontsFor((int)(96 * s + 0.5f));
  Canvas c;
  if (!c.Begin(W, H)) return;
  const Palette& p = Pal();
  uint32_t bg = Over(p.windowBg & 0xFFFFFF, p.popupBg);
  FillAll(c, bg);
  bool rtl = (GetLayout(dis->hDC) & LAYOUT_RTL) != 0;  // 从右到左的菜单：DC 是镜像的，画布按视觉位置排版、不镜像贴上
  float cy = H / 2.0f;
  if (v.type & MFT_SEPARATOR) {
    float y = floorf(cy);
    FillRectA(c, 4 * s, y, W - 4 * s, y + Px(1, s), p.popupStroke);
  } else {
    bool grey = (dis->itemState & (ODS_GRAYED | ODS_DISABLED)) != 0;
    bool sel = (dis->itemState & ODS_SELECTED) != 0;
    // 选中项：整行系统高亮色、高亮文字色（与原皮肤的列表一样醒目）；禁止项被键盘选中时只用浅灰底标出位置，不铺高亮色（免得像能点）
    uint32_t hl = FromCref(GetSysColor(COLOR_HIGHLIGHT)), hlt = FromCref(GetSysColor(COLOR_HIGHLIGHTTEXT));
    uint32_t under = bg;
    if (sel && !grey) {
      FillRectA(c, 0, 0, (float)W, (float)H, 0xFF000000 | hl);
      under = hl;
    } else if (sel) {
      FillRectA(c, 0, 0, (float)W, (float)H, p.listSelected);
      under = Over(bg, p.listSelected);
    }
    bool lit = sel && !grey;
    Argb tc = grey ? p.textDisabled : lit ? (0xFF000000 | hlt) : p.textPrimary;
    Argb sc = grey ? p.textDisabled : lit ? (0xFF000000 | hlt) : p.checkStroke;
    if (dis->itemState & ODS_CHECKED) {
      float cx = rtl ? W - 18 * s : 18 * s;
      if (v.type & MFT_RADIOCHECK) {
        FillCircle(c, cx, cy, 3.5f * s, tc);
      } else {
        float pts[6] = {cx - 4.5f * s, cy + 0.2f * s, cx - 1.5f * s, cy + 3.2f * s, cx + 4.5f * s, cy - 3.6f * s};
        Polyline(c, pts, 3, 1.5f * s, tc);
      }
    }
    const wchar_t* tab = v.len > 0 ? wmemchr(v.text, L'\t', (size_t)v.len) : nullptr;
    int ll = tab ? (int)(tab - v.text) : v.len, al = tab ? v.len - ll - 1 : 0;
    UINT base = DT_SINGLELINE | DT_VCENTER | DT_NOCLIP;
    UINT reading = (rtl || (v.type & MFT_RIGHTORDER)) ? DT_RTLREADING : 0;
    LONG inL = (LONG)(32 * s), inR = (LONG)(32 * s);
    if (ll > 0) {
      RECT tr = {inL, 0, W - inR, H};
      UINT fmt = base | reading | (rtl ? DT_RIGHT : DT_LEFT) | ((dis->itemState & ODS_NOACCEL) ? DT_HIDEPREFIX : 0);
      DrawTextOn(c, (v.state & MFS_DEFAULT) ? g_mf.bold : g_mf.normal, v.text, ll, tr, fmt, Over(under, tc));
    }
    if (al > 0) {
      RECT ar = {inL, 0, W - inR, H};
      DrawTextOn(c, g_mf.normal, tab + 1, al, ar, base | DT_NOPREFIX | (rtl ? DT_LEFT : DT_RIGHT), Over(under, sc));
    }
    if (v.sub) {
      float ax = rtl ? 16 * s : W - 16 * s, dir = rtl ? -1.0f : 1.0f;
      float pts[6] = {ax - dir * 2 * s, cy - 4 * s, ax + dir * 2 * s, cy, ax - dir * 2 * s, cy + 4 * s};
      Polyline(c, pts, 3, 1.25f * s, sc);
    }
  }
  BitBlt(dis->hDC, rc.left, rc.top, W, H, c.dc, 0, 0, SRCCOPY | (rtl ? NOMIRRORBITMAP : 0));
  ExcludeClipRect(dis->hDC, rc.left, rc.top, rc.right, rc.bottom);  // 系统随后补画的子菜单箭头、勾选标记画不上来
}

}  // namespace xs
