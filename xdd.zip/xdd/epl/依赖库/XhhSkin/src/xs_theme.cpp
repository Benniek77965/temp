// XhhSkin 主题层：浅色 / 深色令牌。
// 浅色令牌取自原皮肤（SkinSharp「Win11皮肤_1_浅色」，逐像素取得，见 依赖库/XhhSkin/原皮肤/样式.md）；深色令牌按 Win11（WinUI）取值（目前不用）。
// 强调色：默认浅色为原皮肤的蓝 #005FB8、深色为 Win11 深色默认蓝 #4CC2FF；跟随系统时取注册表里的强调色调色板；
// 自定义颜色按对比度自动加深 / 提亮，保证强调色上的字不低于 4.5:1。
#include "xs.h"
#include <math.h>
#include <string.h>

namespace xs {

static double Lin(double c) {
  c /= 255.0;
  return c <= 0.04045 ? c / 12.92 : pow((c + 0.055) / 1.055, 2.4);
}

double Luminance(uint32_t rgb) {
  return 0.2126 * Lin((rgb >> 16) & 255) + 0.7152 * Lin((rgb >> 8) & 255) + 0.0722 * Lin(rgb & 255);
}

double Contrast(uint32_t a, uint32_t b) {
  double la = Luminance(a), lb = Luminance(b);
  if (la < lb) {
    double t = la;
    la = lb;
    lb = t;
  }
  return (la + 0.05) / (lb + 0.05);
}

static uint32_t Mix(uint32_t a, uint32_t b, double t) {
  uint32_t out = 0;
  for (int s = 0; s < 24; s += 8) {
    double va = (double)((a >> s) & 255), vb = (double)((b >> s) & 255);
    out |= ((uint32_t)(va + (vb - va) * t + 0.5) & 255) << s;
  }
  return out;
}

// 配白字的强调色（浅色主题的填充色）
uint32_t AccentForLight(uint32_t base) {
  uint32_t c = base & 0xFFFFFF;
  for (int i = 0; i < 60 && Contrast(c, 0xFFFFFF) < 4.5; ++i) c = Mix(c, 0x000000, 0.06);
  return c;
}

// 配黑字的强调色（深色主题的填充色）
uint32_t AccentForDark(uint32_t base) {
  uint32_t c = base & 0xFFFFFF;
  for (int i = 0; i < 60 && Contrast(c, 0x000000) < 7.0; ++i) c = Mix(c, 0xFFFFFF, 0.06);
  return c;
}

static bool RegDword(HKEY root, const wchar_t* path, const wchar_t* name, DWORD* out) {
  HKEY k;
  if (RegOpenKeyExW(root, path, 0, KEY_READ, &k) != ERROR_SUCCESS) return false;
  DWORD v = 0, sz = sizeof(v), ty = 0;
  bool ok = RegQueryValueExW(k, name, nullptr, &ty, (BYTE*)&v, &sz) == ERROR_SUCCESS && ty == REG_DWORD;
  RegCloseKey(k);
  if (ok) *out = v;
  return ok;
}

bool SystemDark() {
  DWORD v = 1;
  if (RegDword(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize", L"AppsUseLightTheme", &v)) return v == 0;
  return false;
}

bool SystemHighContrast() {
  HIGHCONTRASTW hc;
  memset(&hc, 0, sizeof(hc));
  hc.cbSize = sizeof(hc);
  return SystemParametersInfoW(SPI_GETHIGHCONTRAST, sizeof(hc), &hc, 0) && (hc.dwFlags & HCF_HIGHCONTRASTON);
}

// 系统强调色：先取调色板（Win10 起：浅3 浅2 浅1 本色 深1 深2 深3，每项 RGBA），没有再取 DWM 的强调色（ABGR）
bool SystemAccent(uint32_t* light, uint32_t* dark) {
  HKEY k;
  if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Accent", 0, KEY_READ, &k) == ERROR_SUCCESS) {
    BYTE pal[32];
    DWORD sz = sizeof(pal), ty = 0;
    LONG r = RegQueryValueExW(k, L"AccentPalette", nullptr, &ty, pal, &sz);
    RegCloseKey(k);
    if (r == ERROR_SUCCESS && ty == REG_BINARY && sz >= 28) {
      uint32_t dark1 = ((uint32_t)pal[16] << 16) | ((uint32_t)pal[17] << 8) | pal[18];
      uint32_t light2 = ((uint32_t)pal[4] << 16) | ((uint32_t)pal[5] << 8) | pal[6];
      *light = AccentForLight(dark1);
      *dark = AccentForDark(light2);
      return true;
    }
  }
  DWORD abgr = 0;
  if (RegDword(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\DWM", L"AccentColor", &abgr)) {
    uint32_t base = ((abgr & 0xFF) << 16) | (abgr & 0xFF00) | ((abgr >> 16) & 0xFF);
    *light = AccentForLight(base);
    *dark = AccentForDark(Mix(base, 0xFFFFFF, 0.45));
    return true;
  }
  return false;
}

void BuildPalette(Palette& p, bool dark, uint32_t accLight, uint32_t accDark) {
  memset(&p, 0, sizeof(p));
  p.dark = dark;
  if (!dark) {
    // 浅色：原皮肤（SkinSharp「Win11皮肤_1_浅色」）的外观，数值见 依赖库/XhhSkin/原皮肤/样式.md。
    // 强调色（选中的选择框与单选框、进度条、列表选中竖条）默认是原皮肤的蓝 #005FB8；XS_Set 2 选跟随系统或自定义时用那个颜色
    uint32_t a = accLight & 0xFFFFFF;
    p.windowBg = 0xFFFFFFFF;
    p.textPrimary = 0xFF000000;
    p.textSecondary = 0xFF000000;
    p.textDisabled = 0xFF999999;
    p.accent = Mk(0xFF, a);
    p.accentHover = Mk(0xFF, a);
    p.accentPressed = Mk(0xFF, a);
    p.accentDisabled = 0xFFC3C3C3;
    p.textOnAccent = 0xFFFFFFFF;
    p.textOnAccentPressed = 0xFFFFFFFF;
    p.textOnAccentDisabled = 0xFFFFFFFF;
    p.fillRest = 0xFFFFFFFF;
    p.fillHover = 0xFFE0EEF9;
    p.fillPressed = 0xFFCEE3F4;
    p.fillDisabled = 0xFFF9F9F9;
    p.strokeTop = 0xFFD0D0D0;
    p.strokeBottom = 0xFFD0D0D0;
    p.strokeDisabled = 0xFFE9E9E9;
    p.accentStrokeTop = Mk(0xFF, a);
    p.accentStrokeBottom = Mk(0xFF, a);
    p.fieldFill = 0xFFFFFFFF;
    p.fieldFillDisabled = Mk(0x4D, 0xF9F9F9);
    p.fieldStroke = 0xFFD9D9D9;
    p.fieldBottom = 0xFFD9D9D9;
    p.fieldStrokeDisabled = 0xFFE9E9E9;
    p.checkStroke = 0xFF626262;
    p.checkStrokeDisabled = 0xFFCBCBCB;
    p.checkFillRest = 0xFFFFFFFF;
    p.checkFillHover = 0xFFFFFFFF;
    p.checkFillPressed = 0xFFFFFFFF;
    p.groupStroke = 0xFFDCDCDC;
    p.listHover = Mk(0x09, 0x000000);
    p.listSelected = Mk(0x0F, 0x000000);
    p.listSelectedHover = Mk(0x14, 0x000000);
    p.popupBg = 0xFFFFFFFF;
    p.popupStroke = 0xFFD9D9D9;  // 原皮肤：下拉列表外框 1 像素 #D9D9D9（与编辑框、组合框细边同色），菜单外框与分隔线同用
    p.progressTrack = Mk(0x72, 0x000000);
    p.progressError = 0xFFC42B1C;
    p.progressPaused = 0xFF9D5D00;
    p.focusOuter = Mk(0xE4, 0x000000);
    p.focusInner = Mk(0xB3, 0xFFFFFF);
    p.dialogContent = 0xFFFFFFFF;
    p.dialogFooter = 0xFFF0F0F0;
    p.dialogDivider = 0x00000000;
    p.chevron = Mk(0x9E, 0x000000);
    p.chevronDisabled = Mk(0x5C, 0x000000);
    p.strokeHover = 0xFF0078D4;
    p.strokePressed = 0xFF0078D4;
    p.focusLine = 0xFF0078D4;
    p.fieldStrokeFocus = 0xFF0078D4;
    p.checkStrokeHover = 0xFF818181;
  } else {
    uint32_t a = accDark & 0xFFFFFF;
    p.windowBg = 0xFF202020;
    p.textPrimary = 0xFFFFFFFF;
    p.textSecondary = Mk(0xC5, 0xFFFFFF);
    p.textDisabled = Mk(0x5D, 0xFFFFFF);
    p.accent = Mk(0xFF, a);
    p.accentHover = Mk(0xE6, a);
    p.accentPressed = Mk(0xCC, a);
    p.accentDisabled = Mk(0x28, 0xFFFFFF);
    p.textOnAccent = 0xFF000000;
    p.textOnAccentPressed = Mk(0x80, 0x000000);
    p.textOnAccentDisabled = Mk(0x87, 0xFFFFFF);
    p.fillRest = Mk(0x0F, 0xFFFFFF);
    p.fillHover = Mk(0x15, 0xFFFFFF);
    p.fillPressed = Mk(0x08, 0xFFFFFF);
    p.fillDisabled = Mk(0x0B, 0xFFFFFF);
    p.strokeTop = Mk(0x18, 0xFFFFFF);
    p.strokeBottom = Mk(0x12, 0xFFFFFF);
    p.strokeDisabled = Mk(0x12, 0xFFFFFF);
    p.accentStrokeTop = Mk(0x14, 0xFFFFFF);
    p.accentStrokeBottom = Mk(0x24, 0x000000);
    p.fieldFill = Mk(0x0F, 0xFFFFFF);
    p.fieldFillDisabled = Mk(0x0B, 0xFFFFFF);
    p.fieldStroke = Mk(0x18, 0xFFFFFF);
    p.fieldBottom = Mk(0x8B, 0xFFFFFF);
    p.fieldStrokeDisabled = Mk(0x12, 0xFFFFFF);
    p.checkStroke = Mk(0x8B, 0xFFFFFF);
    p.checkStrokeDisabled = Mk(0x28, 0xFFFFFF);
    p.checkFillRest = Mk(0x19, 0x000000);
    p.checkFillHover = Mk(0x0B, 0xFFFFFF);
    p.checkFillPressed = Mk(0x12, 0xFFFFFF);
    p.groupStroke = Mk(0x24, 0xFFFFFF);
    p.listHover = Mk(0x0F, 0xFFFFFF);
    p.listSelected = Mk(0x15, 0xFFFFFF);
    p.listSelectedHover = Mk(0x1F, 0xFFFFFF);
    p.popupBg = 0xFF2C2C2C;
    p.popupStroke = Mk(0x33, 0xFFFFFF);
    p.progressTrack = Mk(0x8B, 0xFFFFFF);
    p.progressError = 0xFFFF99A4;
    p.progressPaused = 0xFFFCE100;
    p.focusOuter = 0xFFFFFFFF;
    p.focusInner = Mk(0xB3, 0x000000);
    p.dialogContent = 0xFF2B2B2B;
    p.dialogFooter = 0xFF202020;
    p.dialogDivider = Mk(0x15, 0xFFFFFF);
    p.chevron = Mk(0xC5, 0xFFFFFF);
    p.chevronDisabled = Mk(0x5D, 0xFFFFFF);
    p.strokeHover = p.accent;
    p.strokePressed = p.accent;
    p.focusLine = p.accent;
    p.fieldStrokeFocus = p.accent;
    p.checkStrokeHover = p.checkStroke;
  }
}

}  // namespace xs
