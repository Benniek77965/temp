// XhhSkin 引擎核心：显式接入（XS_Attach）的顶层窗口及其子孙按类名换肤；不装全局钩子，不碰别的线程、别的进程的窗口。
// 后加进来的控件三条路都能接上：子窗口创建时的 WM_PARENTNOTIFY；控件绘制时向父窗口要颜色的 WM_CTLCOLOR*（黑月控件先建在隐藏的
// 黑月窗口里、再置父进来，不会发 WM_PARENTNOTIFY）；窗口显示、激活时重扫一遍。信息框只在 XS_MessageBox 调用期间装本线程的 CBT 钩子。
#include "xs.h"
#include <string.h>
#include <stdlib.h>

#define XS_EXPORT extern "C" __declspec(dllexport) INT_PTR __stdcall

namespace xs {

enum { XE_OK = 0, XE_INIT = 1, XE_BADHWND = 2, XE_THREAD = 3, XE_EXCLUDED = 4, XE_SUBCLASS = 5, XE_NOTOURS = 6, XE_PARAM = 7 };

typedef BOOL(WINAPI* PFN_SWS)(HWND, SUBCLASSPROC, UINT_PTR, DWORD_PTR);
typedef BOOL(WINAPI* PFN_GWS)(HWND, SUBCLASSPROC, UINT_PTR, DWORD_PTR*);
typedef BOOL(WINAPI* PFN_RWS)(HWND, SUBCLASSPROC, UINT_PTR);
typedef LRESULT(WINAPI* PFN_DSP)(HWND, UINT, WPARAM, LPARAM);
typedef HRESULT(WINAPI* PFN_DwmSet)(HWND, DWORD, LPCVOID, DWORD);
typedef HRESULT(WINAPI* PFN_SetTheme)(HWND, LPCWSTR, LPCWSTR);
typedef UINT(WINAPI* PFN_DpiWnd)(HWND);
typedef LONG(WINAPI* PFN_RtlVer)(OSVERSIONINFOW*);

static HMODULE g_self;
static CRITICAL_SECTION g_cs;
static volatile LONG g_initState;  // 0 未初始化 1 可用 -1 不可用
static PFN_SWS pSWS;
static PFN_GWS pGWS;
static PFN_RWS pRWS;
static PFN_DSP pDSP;
static volatile LONG g_subRecs;  // 自己子类化层现存的记录数（见 SubRec）：有记录说明本 DLL 的代码还在某个窗口过程链里，DLL 不能卸下
static PFN_DwmSet pDwm;
static PFN_SetTheme pTheme;
static PFN_DpiWnd pDpi;
static int g_realBuild, g_forceBuild, g_sysDpi = 96;
static Palette g_pal;
static bool g_hc;
static int g_forceHC = -1;
static int g_mode = 1, g_accentMode = 0, g_backdrop = 0, g_round = 1;
static uint32_t g_accentCustom = 0x005FB8, g_accLight = 0x005FB8, g_accDark = 0x4CC2FF;  // 浅色默认＝原皮肤（SkinSharp「Win11皮肤_1_浅色」）的蓝
static Win** g_wins;
static int g_nWins, g_capWins;
static int g_hooks;
static bool g_selfRef;
static int g_lastErr;
static UINT g_msgRefresh, g_msgRescan, g_msgDetach, g_msgAttachChild;
static ATOM g_atomOff, g_atomBk, g_atomPend;
static int ScopeBegin(int flags);  // 前置声明：菜单所有者的处理与 Forget 用到
static int ScopeEnd();
static int ScopeFlags();
static void RestoreMenusOf(HWND owner);
static const UINT_PTR kId = 0x58534B4E;  // 'XSKN'

struct Scope {
  DWORD tid;
  HHOOK hook;
  int depth;
  int flags[16];  // 各层的标志（1＝这期间弹出的普通顶层窗口也接上）
};
static Scope g_scopes[32];

static LRESULT CALLBACK Proc(HWND h, UINT m, WPARAM wp, LPARAM lp, UINT_PTR id, DWORD_PTR ref);

const Palette& Pal() { return g_pal; }
static int Build() { return g_forceBuild ? g_forceBuild : g_realBuild; }

float DpiScale(HWND h) {
  if (pDpi) {
    UINT d = pDpi(h);
    if (d) return (float)d / 96.0f;
  }
  return (float)g_sysDpi / 96.0f;
}

// 实现这个窗口类的模块：看类窗口过程落在哪个模块里（GCLP_WNDPROC 是类的，不受实例子类化影响）。GCLP_HMODULE 只是注册时给的
// 实例句柄，不一定是实现它的模块：Wine 在带视觉样式清单（通用控件 6.0）时对所有控件类都返回宿主 exe，通用控件 5.x 的类也返回宿主 exe。
// 取不到窗口过程所在的模块时才退回 GCLP_HMODULE
struct XsDllVer {
  DWORD cbSize, dwMajorVersion, dwMinorVersion, dwBuildNumber, dwPlatformID;
};
typedef HRESULT(CALLBACK* PFN_XsDllGetVersion)(XsDllVer*);

static HMODULE ClassImplModule(HWND h) {
  LONG_PTR proc = IsWindowUnicode(h) ? GetClassLongPtrW(h, GCLP_WNDPROC) : GetClassLongPtrA(h, GCLP_WNDPROC);
  HMODULE m = nullptr;
  if (proc && GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)proc, &m) && m)
    return m;
  return (HMODULE)GetClassLongPtrW(h, GCLP_HMODULE);
}

// 控件属于通用控件 6.0（视觉样式）还是 5.x：6.0 版是并排程序集（Windows 与 Wine 都在 WinSxS 下名字带 common-controls 的目录里）。
// 别处的 comctl32 再问它自己的版本，只认 ≥6（Wine 的 6.0 版也报 5.81，不能拿它往下判）；user32 自带的控件按 5 算
int ComctlMajor(HWND h) {
  HMODULE m = ClassImplModule(h);
  if (!m) return 0;
  wchar_t path[MAX_PATH];
  DWORD n = GetModuleFileNameW(m, path, MAX_PATH);
  if (!n || n >= MAX_PATH) return 0;
  CharLowerBuffW(path, n);
  if (wcsstr(path, L"winsxs") && wcsstr(path, L"common-controls")) return 6;
  const wchar_t* base = wcsrchr(path, L'\\');
  base = base ? base + 1 : path;
  if (lstrcmpW(base, L"comctl32.dll") == 0) {
    PFN_XsDllGetVersion dgv = (PFN_XsDllGetVersion)(void*)GetProcAddress(m, "DllGetVersion");
    XsDllVer v;
    memset(&v, 0, sizeof(v));
    v.cbSize = sizeof(v);
    if (dgv && SUCCEEDED(dgv(&v)) && v.dwMajorVersion >= 6) return 6;
  }
  return 5;
}

COLORREF ContainerColor(HWND h, HWND root) {
  for (HWND x = GetParent(h); x;) {
    UINT_PTR v = (UINT_PTR)GetPropW(x, MAKEINTATOM(g_atomBk));
    if (v) return (COLORREF)(v - 1);
    if (x == root || !(GetWindowLongW(x, GWL_STYLE) & WS_CHILD)) break;
    x = GetParent(x);
  }
  return 0xFFFFFFFF;
}

// —— 自引用：有子类化或钩子时多拿一份自己的引用，宿主中途 FreeLibrary 也不会卸下正在用的代码 ——
static void AcquireSelf() {  // 在锁内调用
  if (g_selfRef) return;
  wchar_t path[MAX_PATH];
  DWORD n = GetModuleFileNameW(g_self, path, MAX_PATH);
  if (n && n < MAX_PATH && LoadLibraryW(path)) g_selfRef = true;
}

static void MaybeReleaseSelf() {  // 只在导出函数里调用：宿主此时一定还拿着自己的引用
  bool rel = false;
  EnterCriticalSection(&g_cs);
  if (g_selfRef && g_nWins == 0 && g_hooks == 0 && g_subRecs == 0) {  // 还有记录＝本 DLL 的窗口过程还在某个链里
    g_selfRef = false;
    rel = true;
  }
  LeaveCriticalSection(&g_cs);
  if (rel) FreeLibrary(g_self);
}

// —— 登记表 ——
static void RegAdd(Win* w) {
  EnterCriticalSection(&g_cs);
  if (g_nWins == g_capWins) {
    int nc = g_capWins ? g_capWins * 2 : 64;
    Win** nw = (Win**)realloc(g_wins, (size_t)nc * sizeof(Win*));
    if (nw) {
      g_wins = nw;
      g_capWins = nc;
    }
  }
  if (g_nWins < g_capWins) g_wins[g_nWins++] = w;
  AcquireSelf();
  LeaveCriticalSection(&g_cs);
}

static void RegRemove(Win* w) {
  EnterCriticalSection(&g_cs);
  for (int i = 0; i < g_nWins; ++i)
    if (g_wins[i] == w) {
      g_wins[i] = g_wins[--g_nWins];
      break;
    }
  LeaveCriticalSection(&g_cs);
}

static int RegKind(HWND h) {  // 跨线程也能查：按窗口句柄取种类（0 = 不是本引擎的）
  int k = 0;
  EnterCriticalSection(&g_cs);
  for (int i = 0; i < g_nWins; ++i)
    if (g_wins[i]->h == h) {
      k = g_wins[i]->kind;
      break;
    }
  LeaveCriticalSection(&g_cs);
  return k;
}

// —— 子类化：保持窗口原来的字符集 ——
// 不用 comctl32 的 SetWindowSubclass：它一律装 Unicode 的分发过程，会把 ANSI 窗口（易语言运行库建的窗口与组件都是 ANSI）变成 Unicode。
// 之后谁再用 ANSI 版 GetWindowLong / SetWindowLong 取这个窗口的窗口过程，拿到的是只能交给 CallWindowProc 的转换句柄（0xFFFF0xxx），
// 若不经 CallWindowProc 直接调用就跳到无效地址——Win10 真机上“打开软件就闪退”就是这样：事件日志 异常 0xc000041d
// （STATUS_FATAL_USER_CALLBACK_EXCEPTION，窗口过程回调里出错，程序自己的崩溃诊断来不及写），出错地址 0xffff0bc5、模块 unknown。
// 这里按窗口原来的字符集用 SetWindowLongPtrA / W 装同字符集的窗口过程，转交用对应的 CallWindowProcA / W：
// 以后谁用 ANSI 版取到的都是本 DLL 里真正的 ANSI 窗口过程，可以直接调用
struct SubRec {
  HWND h;
  WNDPROC prev;   // 装上之前的窗口过程（用同一字符集的 API 取得）
  WNDPROC mine;   // 自己装上的（SubProcA 或 SubProcW）
  Win* w;         // 引擎的窗口状态；nullptr＝已卸下，只转交（后来又有人子类化、摘不掉时留在链里）
  int depth;      // 正在这个窗口过程里处理的消息层数（可重入）
  bool ansi;
  bool detached;  // 窗口过程已还原（或窗口已销毁）：当前消息处理完就释放
};
static ATOM g_atomSub;

static SubRec* SubOf(HWND h) { return (SubRec*)GetPropW(h, MAKEINTATOM(g_atomSub)); }

static LRESULT CallPrev(SubRec* s, HWND h, UINT m, WPARAM wp, LPARAM lp) {
  if (!s->prev) return s->ansi ? DefWindowProcA(h, m, wp, lp) : DefWindowProcW(h, m, wp, lp);
  return s->ansi ? CallWindowProcA(s->prev, h, m, wp, lp) : CallWindowProcW(s->prev, h, m, wp, lp);
}

static void SubRelease(SubRec* s) {  // 当前消息已处理完：摘属性（若还指着自己）并释放
  if (SubOf(s->h) == s) RemovePropW(s->h, MAKEINTATOM(g_atomSub));
  free(s);
  InterlockedDecrement(&g_subRecs);
}

static LRESULT SubDispatch(HWND h, UINT m, WPARAM wp, LPARAM lp) {
  SubRec* s = SubOf(h);
  if (!s) return IsWindowUnicode(h) ? DefWindowProcW(h, m, wp, lp) : DefWindowProcA(h, m, wp, lp);  // 不应发生
  ++s->depth;
  LRESULT r = s->w ? Proc(h, m, wp, lp, kId, (DWORD_PTR)s->w) : CallPrev(s, h, m, wp, lp);
  --s->depth;
  if (m == WM_NCDESTROY) s->detached = true;  // 窗口没了：不论摘没摘掉都释放
  if (s->detached && s->depth == 0) SubRelease(s);
  return r;
}
static LRESULT CALLBACK SubProcW(HWND h, UINT m, WPARAM wp, LPARAM lp) { return SubDispatch(h, m, wp, lp); }
static LRESULT CALLBACK SubProcA(HWND h, UINT m, WPARAM wp, LPARAM lp) { return SubDispatch(h, m, wp, lp); }

// 以下四个与 comctl32 的 SetWindowSubclass / GetWindowSubclass / RemoveWindowSubclass / DefSubclassProc 同签名，供原来的调用处直接用
static BOOL WINAPI MySetSubclass(HWND h, SUBCLASSPROC, UINT_PTR, DWORD_PTR ref) {
  SubRec* s = SubOf(h);
  if (s && !s->detached) {  // 以前卸下但摘不掉、还留在链里：重新启用
    s->w = (Win*)ref;
    return TRUE;
  }
  s = (SubRec*)calloc(1, sizeof(SubRec));
  if (!s) return FALSE;
  s->h = h;
  s->ansi = !IsWindowUnicode(h);
  s->mine = s->ansi ? SubProcA : SubProcW;
  s->w = (Win*)ref;
  if (!SetPropW(h, MAKEINTATOM(g_atomSub), s)) {
    free(s);
    return FALSE;
  }
  InterlockedIncrement(&g_subRecs);
  SetLastError(0);
  LONG_PTR prev = s->ansi ? SetWindowLongPtrA(h, GWLP_WNDPROC, (LONG_PTR)s->mine) : SetWindowLongPtrW(h, GWLP_WNDPROC, (LONG_PTR)s->mine);
  if (!prev && GetLastError()) {
    SubRelease(s);
    return FALSE;
  }
  s->prev = (WNDPROC)prev;
  return TRUE;
}

static BOOL WINAPI MyGetSubclass(HWND h, SUBCLASSPROC, UINT_PTR, DWORD_PTR* ref) {
  if (GetWindowThreadProcessId(h, nullptr) != GetCurrentThreadId()) return FALSE;  // 与 comctl32 一样只管本线程的窗口
  SubRec* s = SubOf(h);
  if (!s || !s->w || s->detached) return FALSE;
  if (ref) *ref = (DWORD_PTR)s->w;
  return TRUE;
}

static BOOL WINAPI MyRemoveSubclass(HWND h, SUBCLASSPROC, UINT_PTR) {
  SubRec* s = SubOf(h);
  if (!s || s->detached) return FALSE;
  s->w = nullptr;  // 引擎不再处理这个窗口
  LONG_PTR cur = s->ansi ? GetWindowLongPtrA(h, GWLP_WNDPROC) : GetWindowLongPtrW(h, GWLP_WNDPROC);
  if (cur == (LONG_PTR)s->mine) {  // 自己还在最外层：还原原来的窗口过程（同一字符集）
    if (s->ansi) SetWindowLongPtrA(h, GWLP_WNDPROC, (LONG_PTR)s->prev);
    else SetWindowLongPtrW(h, GWLP_WNDPROC, (LONG_PTR)s->prev);
    s->detached = true;
    if (s->depth == 0) SubRelease(s);  // 正在这个窗口的消息里时，等消息处理完（DefSubclass 还要用它转交）
  }
  // 否则后来又有人子类化、把自己当“原窗口过程”存着：留在链里只转交，窗口销毁时释放
  return TRUE;
}

static LRESULT WINAPI MyDefSubclass(HWND h, UINT m, WPARAM wp, LPARAM lp) {
  SubRec* s = SubOf(h);
  if (s) return CallPrev(s, h, m, wp, lp);
  return IsWindowUnicode(h) ? DefWindowProcW(h, m, wp, lp) : DefWindowProcA(h, m, wp, lp);
}

static bool SameThread(HWND h) { return GetWindowThreadProcessId(h, nullptr) == GetCurrentThreadId(); }

static Win* Ours(HWND h) {  // 只对本线程的窗口用
  DWORD_PTR ref = 0;
  if (pGWS && pGWS(h, Proc, kId, &ref)) return (Win*)ref;
  return nullptr;
}

static Win* Still(HWND h) { return IsWindow(h) ? Ours(h) : nullptr; }  // 交给原窗口过程之后窗口可能已被销毁

static bool IsRootKind(int k) { return k == K_ROOT || k == K_DIALOG; }

static Win* Subclass(HWND h, int kind, HWND root) {
  Win* w = (Win*)calloc(1, sizeof(Win));
  if (!w) return nullptr;
  w->h = h;
  w->kind = kind;
  w->root = root;
  w->tid = GetCurrentThreadId();
  w->footerTop = -1;
  if (!pSWS(h, Proc, kId, (DWORD_PTR)w)) {
    free(w);
    g_lastErr = XE_SUBCLASS;
    return nullptr;
  }
  RegAdd(w);
  return w;
}

static void Forget(Win* w) {  // 去掉子类化并释放（WM_NCDESTROY 或卸下时）
  if (w->menuLoop) {  // 菜单所有者在菜单循环里被销毁或卸下：接菜单窗口的内部范围照样结束（只在它自己的线程上）
    if (w->tid == GetCurrentThreadId()) ScopeEnd();
    w->menuLoop = 0;
  }
  RestoreMenusOf(w->h);
  pRWS(w->h, Proc, kId);
  RegRemove(w);
  if (w->brContent) DeleteObject(w->brContent);
  if (w->brFooter) DeleteObject(w->brFooter);
  free(w);
}

// —— 分类 ——
static bool PrefixI(const wchar_t* s, const wchar_t* pre) {
  size_t n = wcslen(pre);
  return _wcsnicmp(s, pre, n) == 0;
}

static bool IsForeignClass(const wchar_t* cls) {  // 内嵌浏览器等别的界面框架：整棵子树都不碰
  static const wchar_t* pre[] = {L"Chrome_", L"Intermediate D3D", L"Internet Explorer_", L"Shell Embedding", L"Shell DocObject", L"ATL:",
                                 L"CefBrowser", L"MozillaWindow", L"WebViewHost", L"mb_", L"Miniblink", L"wke", L"WindowsForms"};
  for (size_t i = 0; i < sizeof(pre) / sizeof(pre[0]); ++i)
    if (PrefixI(cls, pre[i])) return true;
  return false;
}

static bool IsLeafClass(const wchar_t* cls) {  // 不会有子窗口的常见类：没有子窗口时不用当容器子类化
  static const wchar_t* leaf[] = {L"Static", L"ScrollBar", L"msctls_trackbar32", L"msctls_updown32", L"msctls_hotkey32", L"SysHeader32",
                                  L"tooltips_class32", L"SysLink", L"zyTransTextView", L"RichEdit20W", L"RichEdit20A", L"RICHEDIT50W",
                                  L"ComboLBox", L"Edit", L"Button", L"ListBox", L"msctls_progress32", L"SysListView32", L"SysTreeView32", L"ComboBox"};
  for (size_t i = 0; i < sizeof(leaf) / sizeof(leaf[0]); ++i)
    if (lstrcmpiW(cls, leaf[i]) == 0) return true;
  return false;
}

static int Classify(HWND h) {
  wchar_t cls[64];
  if (!GetClassNameW(h, cls, 64)) return K_NONE;
  LONG st = GetWindowLongW(h, GWL_STYLE);
  if (lstrcmpiW(cls, L"Button") == 0) {
    switch (st & BS_TYPEMASK) {
      case BS_PUSHBUTTON:
      case BS_DEFPUSHBUTTON: return K_PUSH;
      case BS_CHECKBOX:
      case BS_AUTOCHECKBOX:
      case BS_3STATE:
      case BS_AUTO3STATE: return (st & BS_PUSHLIKE) ? K_PUSH : K_CHECK;
      case BS_RADIOBUTTON:
      case BS_AUTORADIOBUTTON: return (st & BS_PUSHLIKE) ? K_PUSH : K_RADIO;
      case BS_GROUPBOX: return K_GROUP;
      default: return K_NONE;  // 自绘、分割按钮、命令链接：外观归程序自己
    }
  }
  if (lstrcmpiW(cls, L"Edit") == 0) {
    HWND p = GetParent(h);
    wchar_t pc[32];
    if (p && GetClassNameW(p, pc, 32) && lstrcmpiW(pc, L"ComboBox") == 0) return K_NONE;  // 组合框里的编辑框归组合框
    int b = 0;
    if (!NcBorder(h, &b)) return K_NONE;  // 无边框：程序自己设计的外观（按实际边框判断，编辑框会自己改 WS_BORDER）
    return K_EDIT;
  }
  if (lstrcmpiW(cls, L"ComboBox") == 0) {
    if (st & (CBS_OWNERDRAWFIXED | CBS_OWNERDRAWVARIABLE)) return K_NONE;
    if ((st & 3) == CBS_SIMPLE) return K_NONE;
    return K_COMBO;
  }
  if (lstrcmpiW(cls, L"ListBox") == 0) {
    if (st & (LBS_OWNERDRAWFIXED | LBS_OWNERDRAWVARIABLE)) return K_NONE;
    return K_LISTBOX;
  }
  if (lstrcmpiW(cls, L"msctls_progress32") == 0) return K_PROGRESS;
  if (lstrcmpiW(cls, L"SysListView32") == 0) return K_LISTVIEW;
  return K_NONE;
}

static bool Excluded(HWND h, HWND root) {
  for (HWND x = h; x;) {
    if (GetPropW(x, MAKEINTATOM(g_atomOff))) return true;
    if (x == root || !(GetWindowLongW(x, GWL_STYLE) & WS_CHILD)) break;
    x = GetParent(x);
  }
  return false;
}

// —— DWM 外框（只对顶层窗口） ——
static bool CanRound(HWND h) {
  if (GetWindowLongW(h, GWL_EXSTYLE) & WS_EX_LAYERED) return false;  // 逐像素分层：系统不圆
  HRGN r = CreateRectRgn(0, 0, 0, 0);
  int t = GetWindowRgn(h, r);
  DeleteObject(r);
  return t == ERROR;  // 设了窗口区域（如黑月外形圆角）：系统不圆
}

static void ApplyFrame(Win* w, bool on) {
  HWND h = w->h;
  LONG st = GetWindowLongW(h, GWL_STYLE);
  if (st & WS_CHILD) {
    w->applied = 0;
    return;
  }
  int build = Build();
  uint32_t req = 0, old = w->applied;
  bool framed = (st & WS_CAPTION) == WS_CAPTION || (st & WS_THICKFRAME);
  bool dark = on && g_pal.dark && !g_hc;
  if (build >= 17763) {
    if (dark || (old & XA_DARK)) {
      BOOL v = dark;
      if (pDwm) pDwm(h, build >= 18985 ? 20 : 19, &v, sizeof(v));
    }
    if (dark) req |= XA_DARK;
  }
  if (build >= 22000) {
    bool round = on && !framed && g_round && CanRound(h);
    if (round || (old & XA_ROUND)) {
      DWORD v = round ? 2 /*DWMWCP_ROUND*/ : 0 /*DWMWCP_DEFAULT*/;
      if (pDwm) pDwm(h, 33, &v, sizeof(v));
    }
    if (round) req |= XA_ROUND;
    int bd = (on && framed && !g_hc) ? g_backdrop : 0;
    if (bd || (old & XA_BACKDROP)) {
      if (build >= 22621) {
        DWORD v = bd == 1 ? 2 : bd == 2 ? 4 : bd == 3 ? 3 : 0;  // Mica / Mica Alt / Acrylic / 系统决定
        if (pDwm) pDwm(h, 38, &v, sizeof(v));
      } else {
        BOOL v = bd == 1;  // Win11 21H2 只有 Mica 开关
        if (pDwm) pDwm(h, 1029, &v, sizeof(v));
      }
    }
    if (bd) req |= XA_BACKDROP;
  }
  w->applied = req;
}

static void PopupFrame(Win* w, bool on) {  // 组合框下拉列表：Win11 小圆角 + 细边颜色
  if (Build() < 22000) {
    w->applied = 0;
    return;
  }
  bool r = on && !g_hc;
  if (r || w->applied) {
    DWORD corner = r ? 3 /*DWMWCP_ROUNDSMALL*/ : 0;
    COLORREF bc = r ? ToCref(Over(Over(g_pal.windowBg & 0xFFFFFF, g_pal.popupBg), g_pal.popupStroke)) : 0xFFFFFFFF /*DWMWA_COLOR_DEFAULT*/;
    if (pDwm) {
      pDwm(w->h, 33, &corner, sizeof(corner));
      pDwm(w->h, 34, &bc, sizeof(bc));
    }
  }
  w->applied = r ? (XA_ROUND | XA_BORDER) : 0;
}

static void ThemeListView(Win* w, bool on) {
  if (!pTheme || ComctlMajor(w->h) < 6) {
    w->themed = 0;
    return;
  }
  HWND hd = (HWND)SendMessageW(w->h, LVM_GETHEADER, 0, 0);
  if (on && !g_hc) {
    pTheme(w->h, g_pal.dark ? L"DarkMode_Explorer" : L"Explorer", nullptr);
    if (hd) pTheme(hd, g_pal.dark ? L"DarkMode_ItemsView" : L"Explorer", nullptr);
    w->themed = 1;
  } else if (w->themed) {
    pTheme(w->h, nullptr, nullptr);
    if (hd) pTheme(hd, nullptr, nullptr);
    w->themed = 0;
  }
}

static void DialogBrushes(Win* w) {
  if (w->brContent) DeleteObject(w->brContent);
  if (w->brFooter) DeleteObject(w->brFooter);
  uint32_t content = Over(g_pal.windowBg & 0xFFFFFF, g_pal.dialogContent);
  uint32_t footer = Over(content, g_pal.dialogFooter);
  w->brContent = CreateSolidBrush(ToCref(content));
  w->brFooter = CreateSolidBrush(ToCref(footer));
}

static LRESULT DialogCtlColor(Win* w, HDC dc, HWND child) {
  RECT r = {0, 0, 0, 0};
  if (child) {
    GetWindowRect(child, &r);
    MapWindowPoints(nullptr, w->h, (POINT*)&r, 2);
  }
  bool foot = w->footerTop >= 0 && r.top >= w->footerTop;
  uint32_t content = Over(g_pal.windowBg & 0xFFFFFF, g_pal.dialogContent);
  uint32_t bg = foot ? Over(content, g_pal.dialogFooter) : content;
  SetBkColor(dc, ToCref(bg));
  SetTextColor(dc, ToCref(Over(bg, g_pal.textPrimary)));
  return (LRESULT)(foot ? w->brFooter : w->brContent);
}

// —— 接入 ——
static void SetupWin(Win* w) {
  switch (w->kind) {
    case K_COMBO: {
      COMBOBOXINFO ci;
      memset(&ci, 0, sizeof(ci));
      ci.cbSize = sizeof(ci);
      if (GetComboBoxInfo(w->h, &ci) && ci.hwndList && SameThread(ci.hwndList) && !Ours(ci.hwndList)) {
        Win* l = Subclass(ci.hwndList, K_COMBOLIST, w->root);
        if (l) {
          l->owner = w->h;
          PopupFrame(l, true);
        }
      }
      break;
    }
    case K_LISTVIEW: ThemeListView(w, true); break;
    case K_DIALOG:
      w->footerTop = DialogFooterTop(w->h, w->ownPaint != 0);
      DialogBrushes(w);
      break;
    default: break;
  }
}

// 接一个窗口（不递归）。stop 带回“这棵子树不要往下走”（别的线程、内嵌浏览器、排除的窗口）
static bool AttachOne(HWND h, HWND root, bool* stop) {
  *stop = false;
  if (!SameThread(h)) {
    *stop = true;
    return false;
  }
  if (Ours(h)) return false;
  if (Excluded(h, root)) {
    *stop = true;
    return false;
  }
  int kind = Classify(h);
  if (kind == K_NONE) {
    wchar_t cls[64];
    if (!GetClassNameW(h, cls, 64)) return false;
    if (IsForeignClass(cls)) {
      *stop = true;
      return false;
    }
    if (!GetWindow(h, GW_CHILD) && IsLeafClass(cls)) return false;
    kind = K_CONTAINER;
  }
  Win* w = Subclass(h, kind, root);
  if (!w) return false;
  SetupWin(w);
  if (kind != K_CONTAINER && kind != K_LISTVIEW) RedrawWindow(h, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME);
  return true;
}

static void AttachTree(HWND h, HWND root) {
  bool stop = false;
  AttachOne(h, root, &stop);
  if (stop) return;
  for (HWND c = GetWindow(h, GW_CHILD); c; c = GetWindow(c, GW_HWNDNEXT)) AttachTree(c, root);
}

static void Rescan(Win* root, bool force) {
  DWORD now = GetTickCount();
  if (!force && now - root->lastRescan < 300) return;
  root->lastRescan = now;
  for (HWND c = GetWindow(root->h, GW_CHILD); c; c = GetWindow(c, GW_HWNDNEXT)) AttachTree(c, root->h);
  if (root->kind == K_DIALOG) root->footerTop = DialogFooterTop(root->h, root->ownPaint != 0);
}

static HWND FindRootOf(HWND h) {
  for (HWND x = h; x;) {
    Win* w = SameThread(x) ? Ours(x) : nullptr;
    if (w) return IsRootKind(w->kind) ? w->h : w->root;
    if (!(GetWindowLongW(x, GWL_STYLE) & WS_CHILD)) break;
    x = GetParent(x);
  }
  return nullptr;
}

static bool AttachRoot(HWND h, int kind) {
  if (!IsWindow(h)) {
    g_lastErr = XE_BADHWND;
    return false;
  }
  if (!SameThread(h)) {
    g_lastErr = XE_THREAD;
    return false;
  }
  if (GetPropW(h, MAKEINTATOM(g_atomOff))) {
    g_lastErr = XE_EXCLUDED;
    return false;
  }
  Win* w = Ours(h);
  if (w) {
    g_lastErr = XE_OK;
    Win* r = IsRootKind(w->kind) ? w : Ours(w->root);
    if (r) Rescan(r, true);
    return true;  // 已经接着（作为根，或作为别的根的子孙）
  }
  w = Subclass(h, kind, h);
  if (!w) return false;
  SetupWin(w);
  ApplyFrame(w, true);
  w->lastRescan = GetTickCount();
  for (HWND c = GetWindow(h, GW_CHILD); c; c = GetWindow(c, GW_HWNDNEXT)) AttachTree(c, h);
  if (kind == K_DIALOG) w->footerTop = DialogFooterTop(h, w->ownPaint != 0);
  PostMessageW(h, g_msgRescan, 0, 0);  // 创建事件里稍后才建、才置父进来的控件，回到消息循环时再接
  RedrawWindow(h, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN);
  g_lastErr = XE_OK;
  return true;
}

// —— 卸下 ——
static void RestoreLook(Win* w) {
  switch (w->kind) {
    case K_LISTVIEW: ThemeListView(w, false); break;
    case K_COMBOLIST:
    case K_MENUWND: PopupFrame(w, false); break;
    case K_ROOT:
    case K_DIALOG: ApplyFrame(w, false); break;
    default: break;
  }
}

static void DetachOne(Win* w, bool redraw) {
  HWND h = w->h;
  int kind = w->kind;
  RestoreLook(w);
  Forget(w);
  if (!redraw || !IsWindow(h)) return;
  if (kind == K_GROUP) {  // 分组框不画里面：连父窗口那一块一起重画，旧的圆角边才会擦干净
    HWND p = GetParent(h);
    RECT r;
    GetWindowRect(h, &r);
    if (p) {
      MapWindowPoints(nullptr, p, (POINT*)&r, 2);
      RedrawWindow(p, &r, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_ALLCHILDREN);
      return;
    }
  }
  RedrawWindow(h, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME);
}

// 收集本线程里满足条件的窗口（拷出来再处理：处理时会改登记表）
static int Collect(Win*** out, bool (*pred)(Win*, HWND), HWND key) {
  DWORD tid = GetCurrentThreadId();
  EnterCriticalSection(&g_cs);
  int n = 0;
  Win** arr = (Win**)malloc((size_t)(g_nWins ? g_nWins : 1) * sizeof(Win*));
  if (arr)
    for (int i = 0; i < g_nWins; ++i)
      if (g_wins[i]->tid == tid && pred(g_wins[i], key)) arr[n++] = g_wins[i];
  LeaveCriticalSection(&g_cs);
  *out = arr;
  return n;
}

static bool PredOfRoot(Win* w, HWND root) { return w->root == root && w->h != root; }
static bool PredInSubtree(Win* w, HWND top) {
  if (w->h == top || IsChild(top, w->h)) return true;
  return w->kind == K_COMBOLIST && w->owner && (w->owner == top || IsChild(top, w->owner));
}

static void DetachRoot(Win* root) {
  HWND rh = root->h;
  Win** arr = nullptr;
  int n = Collect(&arr, PredOfRoot, rh);
  for (int i = 0; i < n; ++i) DetachOne(arr[i], false);
  free(arr);
  DetachOne(root, false);
  if (IsWindow(rh)) RedrawWindow(rh, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN | RDW_UPDATENOW);
}

static void DetachSubtree(HWND top) {
  Win** arr = nullptr;
  int n = Collect(&arr, PredInSubtree, top);
  for (int i = 0; i < n; ++i) DetachOne(arr[i], true);
  free(arr);
}

// —— 主题变化 ——
static bool Recompute() {
  EnterCriticalSection(&g_cs);
  bool dark = g_mode == 2 || (g_mode == 0 && SystemDark());
  bool hc = g_forceHC >= 0 ? g_forceHC == 1 : SystemHighContrast();
  uint32_t al = 0x005FB8, ad = 0x4CC2FF;  // 默认：浅色用原皮肤的蓝，深色用 Win11 深色默认蓝
  if (g_accentMode == 1) {
    uint32_t l, d;
    if (SystemAccent(&l, &d)) {
      al = l;
      ad = d;
    }
  } else if (g_accentMode == 2) {
    al = AccentForLight(g_accentCustom);
    ad = AccentForDark(g_accentCustom);
  }
  Palette np;
  BuildPalette(np, dark, al, ad);
  bool changed = memcmp(&np, &g_pal, sizeof(np)) != 0 || hc != g_hc;
  g_pal = np;
  g_hc = hc;
  g_accLight = al;
  g_accDark = ad;
  LeaveCriticalSection(&g_cs);
  return changed;
}

static bool PredThemeDep(Win* w, HWND root) { return w->root == root && (w->kind == K_LISTVIEW || w->kind == K_COMBOLIST); }

static void RefreshRoot(Win* root) {
  ApplyFrame(root, true);
  if (root->kind == K_DIALOG) {
    DialogBrushes(root);
    root->footerTop = DialogFooterTop(root->h, root->ownPaint != 0);
  }
  Win** arr = nullptr;
  int n = Collect(&arr, PredThemeDep, root->h);
  for (int i = 0; i < n; ++i) {
    if (arr[i]->kind == K_LISTVIEW) ThemeListView(arr[i], true);
    else PopupFrame(arr[i], true);
  }
  free(arr);
  RedrawWindow(root->h, nullptr, nullptr, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN);
}

static void RefreshAll() {
  EnterCriticalSection(&g_cs);
  int n = 0;
  HWND* hs = (HWND*)malloc((size_t)(g_nWins ? g_nWins : 1) * sizeof(HWND));
  DWORD* ts = (DWORD*)malloc((size_t)(g_nWins ? g_nWins : 1) * sizeof(DWORD));
  if (hs && ts)
    for (int i = 0; i < g_nWins; ++i)
      if (IsRootKind(g_wins[i]->kind)) {
        hs[n] = g_wins[i]->h;
        ts[n] = g_wins[i]->tid;
        ++n;
      }
  LeaveCriticalSection(&g_cs);
  DWORD me = GetCurrentThreadId();
  for (int i = 0; i < n; ++i) {
    if (ts[i] == me) {
      Win* w = Ours(hs[i]);
      if (w) RefreshRoot(w);
    } else {
      PostMessageW(hs[i], g_msgRefresh, 0, 0);
    }
  }
  free(hs);
  free(ts);
}

static void OnSystemChange() {
  if (Recompute()) RefreshAll();
}

// —— 消息处理 ——
static void Redraw(Win* w) {
  if (w->noRedraw || !IsWindowVisible(w->h)) return;
  if (w->kind == K_EDIT) {
    PaintEditFrame(w);
    return;
  }
  RedrawWindow(w->h, nullptr, nullptr, RDW_INVALIDATE | RDW_UPDATENOW | RDW_NOERASE | RDW_NOCHILDREN);
}

static void TrackLeave(Win* w) {
  if (w->tracking) return;
  TRACKMOUSEEVENT t;
  memset(&t, 0, sizeof(t));
  t.cbSize = sizeof(t);
  t.dwFlags = TME_LEAVE;
  t.hwndTrack = w->h;
  if (TrackMouseEvent(&t)) w->tracking = 1;
}

// 系统控件在这些消息里会直接（不经 WM_PAINT）画一遍自己：交给它处理之后立刻按换肤外观重画
static bool RepaintAfter(int k, UINT m) {
  switch (m) {
    case WM_SETTEXT:
    case WM_ENABLE:
    case WM_SETFOCUS:
    case WM_KILLFOCUS:
    case WM_SETFONT:
    case WM_UPDATEUISTATE:
    case WM_LBUTTONDOWN:
    case WM_LBUTTONUP:
    case WM_LBUTTONDBLCLK:
    case WM_KEYDOWN:
    case WM_KEYUP:
    case WM_SYSKEYUP:
    case WM_CAPTURECHANGED:
    case WM_CHAR: return true;
    default: break;
  }
  switch (k) {
    case K_PUSH:
    case K_CHECK:
    case K_RADIO:
    case K_GROUP: return m == BM_SETCHECK || m == BM_SETSTATE || m == BM_SETSTYLE || m == BM_CLICK || m == BM_SETIMAGE;
    case K_COMBO:
      return m == CB_SETCURSEL || m == CB_SELECTSTRING || m == CB_RESETCONTENT || m == CB_DELETESTRING || m == CB_INSERTSTRING || m == CB_ADDSTRING ||
             m == CB_SHOWDROPDOWN || m == WM_MOUSEWHEEL || m == WM_COMMAND;
    case K_LISTBOX:
    case K_COMBOLIST:
      return m == LB_SETCURSEL || m == LB_SETSEL || m == LB_SETCARETINDEX || m == LB_SETTOPINDEX || m == LB_ADDSTRING || m == LB_INSERTSTRING ||
             m == LB_DELETESTRING || m == LB_RESETCONTENT || m == LB_SELITEMRANGE || m == LB_SELITEMRANGEEX || m == LB_SETITEMHEIGHT ||
             m == LB_SELECTSTRING || m == LB_SETHORIZONTALEXTENT || m == WM_VSCROLL || m == WM_HSCROLL || m == WM_MOUSEWHEEL || m == WM_TIMER;
    case K_PROGRESS:
      return m == PBM_SETPOS || m == PBM_DELTAPOS || m == PBM_STEPIT || m == PBM_SETRANGE || m == PBM_SETRANGE32 || m == PBM_SETSTATE ||
             m == PBM_SETMARQUEE || m == PBM_SETBARCOLOR || m == PBM_SETBKCOLOR;
    default: return false;
  }
}

// 父窗口收到子控件要颜色：还没接上的标准控件（黑月控件置父进来、程序后建的）记下来，回到消息循环时接上
static void NoteCandidate(Win* w, HWND c) {
  if (!c || !SameThread(c) || Ours(c) || GetPropW(c, MAKEINTATOM(g_atomPend))) return;
  if (Classify(c) == K_NONE) return;
  HWND root = w->root;
  if (!IsWindow(root) || !IsChild(root, c)) return;
  if (Excluded(c, root)) return;
  SetPropW(c, MAKEINTATOM(g_atomPend), (HANDLE)1);
  PostMessageW(root, g_msgAttachChild, (WPARAM)c, 0);
}

static LRESULT RootProc(Win* w, HWND h, UINT m, WPARAM wp, LPARAM lp) {
  switch (m) {
    case WM_SHOWWINDOW:
      if (wp) Rescan(w, true);
      break;
    case WM_ACTIVATE:
      if (LOWORD(wp) != WA_INACTIVE) Rescan(w, false);
      break;
    case WM_SETTINGCHANGE: {
      bool theme = (lp && lstrcmpW((LPCWSTR)lp, L"ImmersiveColorSet") == 0) || wp == SPI_SETHIGHCONTRAST;
      LRESULT r = pDSP(h, m, wp, lp);
      if (theme) OnSystemChange();
      return r;
    }
    case WM_SYSCOLORCHANGE:
    case WM_THEMECHANGED:
    case 0x0320: {  // WM_DWMCOLORIZATIONCOLORCHANGED
      LRESULT r = pDSP(h, m, wp, lp);
      OnSystemChange();
      return r;
    }
    default: break;
  }
  if (w->kind == K_DIALOG && !g_hc) {
    switch (m) {
      case WM_ERASEBKGND: PaintDialogBg(w, (HDC)wp); return 1;
      case WM_PAINT:
        if (w->ownPaint) {  // 信息框：内容全在子控件里，整面由引擎画（盖住系统画的灰色按钮区）
          PAINTSTRUCT ps;
          HDC dc = wp ? (HDC)wp : BeginPaint(h, &ps);
          PaintDialogBg(w, dc);
          if (!wp) EndPaint(h, &ps);
          return 0;
        }
        break;  // 别的对话框可能在 WM_PAINT 里自己画了内容：交回原窗口过程（底色已在 WM_ERASEBKGND 画好）
      case WM_PRINTCLIENT:
        PaintDialogBg(w, (HDC)wp);
        if (w->ownPaint) return 0;
        break;
      case WM_SIZE: {
        LRESULT r = pDSP(h, m, wp, lp);
        Win* x = Still(h);
        if (x) {
          x->footerTop = DialogFooterTop(h, x->ownPaint != 0);
          InvalidateRect(h, nullptr, TRUE);
        }
        return r;
      }
      default: break;
    }
  }
  return pDSP(h, m, wp, lp);
}

static LRESULT EditProc(Win* w, HWND h, UINT m, WPARAM wp, LPARAM lp) {
  if (g_hc) return pDSP(h, m, wp, lp);
  switch (m) {
    case WM_NCPAINT: {
      LRESULT r = pDSP(h, m, wp, lp);
      Win* x = Still(h);
      if (x) PaintEditFrame(x);
      return r;
    }
    case WM_SETREDRAW: w->noRedraw = wp ? 0 : 1; break;
    case WM_PRINT: {  // 被 WM_PRINT 画时（窗口动画、截图）外框也按皮肤画
      LRESULT r = pDSP(h, m, wp, lp);
      Win* x = Still(h);
      if (x && wp && (lp & PRF_NONCLIENT)) PaintEditFrame(x, (HDC)wp);
      return r;
    }
    case WM_SETFOCUS:
    case WM_KILLFOCUS:
    case WM_ENABLE:
    case EM_SETREADONLY:
    case WM_STYLECHANGED: {
      LRESULT r = pDSP(h, m, wp, lp);
      Win* x = Still(h);
      if (x && !x->noRedraw && IsWindowVisible(h)) PaintEditFrame(x);
      return r;
    }
    default: break;
  }
  return pDSP(h, m, wp, lp);
}

static LRESULT ControlProc(Win* w, HWND h, UINT m, WPARAM wp, LPARAM lp) {
  if (g_hc) return pDSP(h, m, wp, lp);
  if (w->kind == K_LISTBOX || w->kind == K_COMBOLIST) {
    if (m == WM_PRINT) {  // 被 WM_PRINT 画时（Windows 10 默认的“滑动打开组合框”动画、窗口动画、截图）外框也按皮肤画，否则动画结束后留着系统边框
      LRESULT r = pDSP(h, m, wp, lp);
      Win* x = Still(h);
      if (x && wp && (lp & PRF_NONCLIENT)) PaintListFrame(x, (HDC)wp);
      return r;
    }
  }
  if ((w->kind == K_LISTBOX || w->kind == K_COMBOLIST) && !g_pal.dark && m != WM_WINDOWPOSCHANGED) {  // 显示 / 隐藏要走下面已有的处理
    // 浅色主题：列表框、下拉列表的项交回系统画——原皮肤就是这样（选中项是系统高亮色整行、白字，文字与组合框本体左对齐）；引擎只画外框。
    // 悬停跟踪、补画也都不做：交回系统后那些重画只会让系统整面重画、移动鼠标时闪烁
    if (m == WM_NCPAINT) {
      LRESULT r = pDSP(h, m, wp, lp);
      Win* x = Still(h);
      if (x) PaintListFrame(x);
      return r;
    }
    return pDSP(h, m, wp, lp);
  }
  switch (m) {
    case WM_PAINT: {
      if (!Themable(w)) {
        w->passive = 1;
        break;
      }
      PAINTSTRUCT ps;
      HDC dc = wp ? (HDC)wp : BeginPaint(h, &ps);
      PaintControl(w, dc);
      if (!wp) EndPaint(h, &ps);
      return 0;
    }
    case WM_PRINTCLIENT:
      if (!Themable(w)) break;
      PaintControl(w, (HDC)wp);
      return 0;
    case WM_ERASEBKGND:
      if (!Themable(w)) break;
      return 1;
    case WM_NCPAINT:
      if (w->kind == K_LISTBOX || w->kind == K_COMBOLIST) {
        LRESULT r = pDSP(h, m, wp, lp);
        Win* x = Still(h);
        if (x) PaintListFrame(x);
        return r;
      }
      break;
    case WM_SETREDRAW: {
      w->noRedraw = wp ? 0 : 1;
      LRESULT r = pDSP(h, m, wp, lp);
      Win* x = Still(h);
      if (x && wp) Redraw(x);
      return r;
    }
    case WM_MOUSEMOVE: {
      LRESULT r = pDSP(h, m, wp, lp);
      Win* x = Still(h);
      if (!x || x->kind == K_GROUP) return r;  // 分组框没有悬停样式
      // 按住拖到控件外面时（控件有鼠标捕获）也会收到移动消息，坐标在外面：这时不算悬停，与系统按钮拖出后恢复常态一致
      RECT crc;
      GetClientRect(h, &crc);
      POINT mp = {(short)LOWORD(lp), (short)HIWORD(lp)};
      bool inside = PtInRect(&crc, mp) != 0;
      bool need = false;
      if (inside && !x->hot) {
        x->hot = 1;
        TrackLeave(x);
        need = true;
      } else if (!inside && x->hot) {
        x->hot = 0;
        need = true;
      }
      if (GetCapture() == h || x->kind == K_COMBOLIST) need = true;  // 按住拖出 / 拖回、下拉列表的选中随鼠标走
      if (need) Redraw(x);
      return r;
    }
    case WM_MOUSELEAVE: {
      LRESULT r = pDSP(h, m, wp, lp);
      Win* x = Still(h);
      if (x) {
        x->hot = 0;
        x->tracking = 0;
        Redraw(x);
      }
      return r;
    }
    case WM_WINDOWPOSCHANGED:
      if (w->kind == K_COMBOLIST) {
        HWND owner = w->owner;
        UINT fl = lp ? ((const WINDOWPOS*)lp)->flags : 0;
        LRESULT r = pDSP(h, m, wp, lp);
        if ((fl & (SWP_SHOWWINDOW | SWP_HIDEWINDOW)) && owner && IsWindow(owner)) {
          Win* o = Ours(owner);
          if (o) {
            if (fl & SWP_HIDEWINDOW) o->hot = 0;
            Redraw(o);
          }
        }
        // 下拉列表显示出来（Windows 10 默认的滑动动画结束时）：再重画一次外框，动画时系统画上的边框不留
        if ((fl & SWP_SHOWWINDOW) && Still(h)) RedrawWindow(h, nullptr, nullptr, RDW_FRAME | RDW_INVALIDATE | RDW_NOCHILDREN);
        return r;
      }
      break;
    default: break;
  }
  if (RepaintAfter(w->kind, m)) {
    LRESULT r = pDSP(h, m, wp, lp);
    Win* x = Still(h);
    if (x) Redraw(x);
    return r;
  }
  return pDSP(h, m, wp, lp);
}

// —— 菜单：弹出前（所有者收到 WM_INITMENUPOPUP、程序自己改完之后）把菜单项临时改成自绘，按原皮肤画；关掉后（WM_UNINITMENUPOPUP，
// 兜底 WM_EXITMENULOOP）原样还原，程序看到的菜单数据不变。系统菜单、程序自绘 / 位图项 / 多列 / 自定义勾选图的菜单、认不准的菜单整份交回系统 ——
#ifndef MN_GETHMENU
#define MN_GETHMENU 0x01E1
#endif
struct MenuRec {
  HMENU m;
  HWND owner;
  int n;
  UINT* type;  // 原来的 fType（还原用）
  UINT* id;
  ULONG_PTR* data;
  HBRUSH oldBack;
};
static MenuRec* g_menus[64];
static int g_nMenus;

static MenuRec* FindMenuRec(HMENU m) {  // 调用方持有 g_cs
  for (int i = 0; i < g_nMenus; ++i)
    if (g_menus[i]->m == m) return g_menus[i];
  return nullptr;
}

// 按“菜单 ID + 项数据”认项（WM_MEASUREITEM 不带菜单句柄、WM_DRAWITEM 不带位置）：恰好一项才算认得，几条分隔线算同一种；-2＝认不准
static int MatchItem(const MenuRec* r, UINT id, ULONG_PTR data) {
  int hit = -1;
  for (int i = 0; i < r->n; ++i)
    if (r->id[i] == id && r->data[i] == data) {
      if (hit >= 0 && !((r->type[hit] & MFT_SEPARATOR) && (r->type[i] & MFT_SEPARATOR))) return -2;
      if (hit < 0) hit = i;
    }
  return hit;
}

static void FreeMenuRec(MenuRec* r) {
  free(r->type);
  free(r->id);
  free(r->data);
  free(r);
}

static bool ConvertMenu(HMENU hm, HWND owner) {
  if (!hm || !IsMenu(hm)) return false;
  EnterCriticalSection(&g_cs);
  bool have = FindMenuRec(hm) != nullptr, full = g_nMenus >= 64;
  LeaveCriticalSection(&g_cs);
  if (have || full) return have;
  int n = GetMenuItemCount(hm);
  if (n <= 0 || n > 1024) return false;
  MenuRec* r = (MenuRec*)calloc(1, sizeof(MenuRec));
  if (!r) return false;
  r->type = (UINT*)calloc((size_t)n, sizeof(UINT));
  r->id = (UINT*)calloc((size_t)n, sizeof(UINT));
  r->data = (ULONG_PTR*)calloc((size_t)n, sizeof(ULONG_PTR));
  if (!r->type || !r->id || !r->data) {
    FreeMenuRec(r);
    return false;
  }
  r->m = hm;
  r->owner = owner;
  r->n = n;
  for (int i = 0; i < n; ++i) {
    MENUITEMINFOW mi;
    memset(&mi, 0, sizeof(mi));
    mi.cbSize = sizeof(mi);
    mi.fMask = MIIM_FTYPE | MIIM_ID | MIIM_DATA | MIIM_BITMAP | MIIM_CHECKMARKS;
    if (!GetMenuItemInfoW(hm, (UINT)i, TRUE, &mi) || (mi.fType & (MFT_OWNERDRAW | MFT_BITMAP | MFT_MENUBREAK | MFT_MENUBARBREAK)) || mi.hbmpItem ||
        mi.hbmpChecked || mi.hbmpUnchecked) {
      FreeMenuRec(r);  // 程序自绘、位图项、多列、自定义勾选图：整份菜单交回系统
      return false;
    }
    r->type[i] = mi.fType;
    r->id[i] = mi.wID;
    r->data[i] = mi.dwItemData;
  }
  for (int i = 0; i < n; ++i)
    if (MatchItem(r, r->id[i], r->data[i]) == -2) {
      FreeMenuRec(r);  // 有两项 ID 与项数据都相同：认不准，交回系统
      return false;
    }
  MENUINFO info;
  memset(&info, 0, sizeof(info));
  info.cbSize = sizeof(info);
  info.fMask = MIM_BACKGROUND;
  GetMenuInfo(hm, &info);
  r->oldBack = info.hbrBack;
  info.fMask = MIM_BACKGROUND;
  info.hbrBack = MenuBackBrush();
  SetMenuInfo(hm, &info);
  for (int i = 0; i < n; ++i) {
    MENUITEMINFOW mi;
    memset(&mi, 0, sizeof(mi));
    mi.cbSize = sizeof(mi);
    mi.fMask = MIIM_FTYPE;
    mi.fType = r->type[i] | MFT_OWNERDRAW;
    SetMenuItemInfoW(hm, (UINT)i, TRUE, &mi);
  }
  EnterCriticalSection(&g_cs);
  g_menus[g_nMenus++] = r;
  LeaveCriticalSection(&g_cs);
  return true;
}

static void RestoreMenuRec(MenuRec* r) {  // 原样还原并从登记表去掉
  EnterCriticalSection(&g_cs);
  int k = -1;
  for (int i = 0; i < g_nMenus; ++i)
    if (g_menus[i] == r) k = i;
  if (k >= 0) g_menus[k] = g_menus[--g_nMenus];
  LeaveCriticalSection(&g_cs);
  if (k < 0) return;
  if (IsMenu(r->m)) {
    int n = GetMenuItemCount(r->m);
    for (int i = 0; i < n; ++i) {
      MENUITEMINFOW mi;
      memset(&mi, 0, sizeof(mi));
      mi.cbSize = sizeof(mi);
      mi.fMask = MIIM_FTYPE | MIIM_ID | MIIM_DATA;
      if (!GetMenuItemInfoW(r->m, (UINT)i, TRUE, &mi) || !(mi.fType & MFT_OWNERDRAW)) continue;
      int j = (i < r->n && r->id[i] == mi.wID && r->data[i] == mi.dwItemData) ? i : MatchItem(r, mi.wID, mi.dwItemData);
      if (j < 0) continue;  // 程序后来自己加的自绘项：不碰
      MENUITEMINFOW m2;
      memset(&m2, 0, sizeof(m2));
      m2.cbSize = sizeof(m2);
      m2.fMask = MIIM_FTYPE;
      m2.fType = r->type[j];
      SetMenuItemInfoW(r->m, (UINT)i, TRUE, &m2);
    }
    MENUINFO info;
    memset(&info, 0, sizeof(info));
    info.cbSize = sizeof(info);
    info.fMask = MIM_BACKGROUND;
    info.hbrBack = r->oldBack;
    SetMenuInfo(r->m, &info);
  }
  FreeMenuRec(r);
}

static void RestoreMenusOf(HWND owner) {
  for (;;) {
    MenuRec* r = nullptr;
    EnterCriticalSection(&g_cs);
    for (int i = 0; i < g_nMenus && !r; ++i)
      if (g_menus[i]->owner == owner) r = g_menus[i];
    LeaveCriticalSection(&g_cs);
    if (!r) break;
    RestoreMenuRec(r);
  }
}

static bool MenuItemFor(HWND owner, HMENU hm, UINT id, ULONG_PTR data, MenuItemView* v, wchar_t* buf, int cap) {
  HMENU m = nullptr;
  UINT sep = 0;
  EnterCriticalSection(&g_cs);
  for (int i = g_nMenus - 1; i >= 0 && !m; --i) {  // 后弹出的先找（WM_MEASUREITEM 不带菜单句柄）
    MenuRec* x = g_menus[i];
    if (hm ? x->m != hm : x->owner != owner) continue;
    int j = MatchItem(x, id, data);
    if (j >= 0) {
      m = x->m;
      sep = x->type[j] & MFT_SEPARATOR;
    }
  }
  LeaveCriticalSection(&g_cs);
  if (!m) return false;
  int n = GetMenuItemCount(m), pos = -1;
  for (int i = 0; i < n && pos < 0; ++i) {
    MENUITEMINFOW mi;
    memset(&mi, 0, sizeof(mi));
    mi.cbSize = sizeof(mi);
    mi.fMask = MIIM_ID | MIIM_DATA | MIIM_FTYPE;
    if (GetMenuItemInfoW(m, (UINT)i, TRUE, &mi) && mi.wID == id && mi.dwItemData == data && (mi.fType & MFT_SEPARATOR) == sep) pos = i;
  }
  if (pos < 0) return false;
  MENUITEMINFOW mi;
  memset(&mi, 0, sizeof(mi));
  mi.cbSize = sizeof(mi);
  mi.fMask = MIIM_FTYPE | MIIM_STATE | MIIM_SUBMENU | MIIM_STRING;
  buf[0] = 0;
  mi.dwTypeData = buf;
  mi.cch = (UINT)(cap - 1);
  if (!GetMenuItemInfoW(m, (UINT)pos, TRUE, &mi)) return false;  // 当前内容：程序可能在 WM_INITMENUPOPUP 里改过文字
  buf[cap - 1] = 0;
  v->text = buf;
  v->len = (mi.fType & MFT_SEPARATOR) ? 0 : (int)lstrlenW(buf);
  v->type = mi.fType & ~(UINT)MFT_OWNERDRAW;
  v->state = mi.fState;
  v->sub = mi.hSubMenu != nullptr;
  return true;
}

static int MenuMnemonic(HMENU hm, wchar_t ch, int* count) {  // 自绘项系统不认助记键：按“&字母”找，返回第一项、*count＝命中数
  int n = GetMenuItemCount(hm), first = -1;
  *count = 0;
  wchar_t up = (wchar_t)(UINT_PTR)CharUpperW((LPWSTR)(UINT_PTR)ch);
  for (int i = 0; i < n; ++i) {
    wchar_t buf[256];
    MENUITEMINFOW mi;
    memset(&mi, 0, sizeof(mi));
    mi.cbSize = sizeof(mi);
    mi.fMask = MIIM_STRING | MIIM_STATE | MIIM_FTYPE;
    buf[0] = 0;
    mi.dwTypeData = buf;
    mi.cch = 255;
    if (!GetMenuItemInfoW(hm, (UINT)i, TRUE, &mi) || (mi.fType & MFT_SEPARATOR) || (mi.fState & MFS_DISABLED)) continue;
    buf[255] = 0;
    for (int k = 0; buf[k]; ++k) {
      if (buf[k] != L'&') continue;
      if (buf[k + 1] == L'&') {
        ++k;
        continue;
      }
      if (buf[k + 1] && (wchar_t)(UINT_PTR)CharUpperW((LPWSTR)(UINT_PTR)buf[k + 1]) == up) {
        if (first < 0) first = i;
        ++*count;
      }
      break;
    }
  }
  return first;
}

struct MenuWndFind {
  HMENU m;
  HWND found;
};
static BOOL CALLBACK FindMenuWndProc(HWND h, LPARAM lp) {
  MenuWndFind* f = (MenuWndFind*)lp;
  wchar_t cls[16];
  if (GetClassNameW(h, cls, 16) && lstrcmpW(cls, L"#32768") == 0 && (HMENU)SendMessageW(h, MN_GETHMENU, 0, 0) == f->m) {
    f->found = h;
    return FALSE;
  }
  return TRUE;
}

// 顶层弹出菜单的窗口在 WM_ENTERMENULOOP 之前就建好了（系统先建窗口、再通知所有者、最后才显示）：建窗口时的钩子接不到它，
// 换肤后在本线程的菜单窗口里按菜单句柄找到它接上——这时还没显示、没画过，第一次画就是换肤外框。子菜单的窗口是打开时才建的，由钩子接
static void AttachMenuWnd(HMENU hm) {
  MenuWndFind f = {hm, nullptr};
  EnumThreadWindows(GetCurrentThreadId(), FindMenuWndProc, (LPARAM)&f);
  if (f.found && !Ours(f.found)) Subclass(f.found, K_MENUWND, nullptr);
}

static bool MenuOwnerMsg(Win* w, HWND h, UINT m, WPARAM wp, LPARAM lp, LRESULT* out) {
  switch (m) {
    case WM_ENTERMENULOOP:
      if (!g_hc) {
        if (!w->menuLoop) ScopeBegin(4);  // 菜单循环期间接住新建的菜单窗口（#32768），画外框
        ++w->menuLoop;
      }
      return false;
    case WM_EXITMENULOOP: {
      *out = pDSP(h, m, wp, lp);
      RestoreMenusOf(h);
      Win* x = Still(h);
      if (x && x->menuLoop && --x->menuLoop == 0) ScopeEnd();
      return true;
    }
    case WM_INITMENUPOPUP: {
      *out = pDSP(h, m, wp, lp);  // 程序先改菜单（启用、勾选、改文字），改完再换肤
      if (!HIWORD(lp) && !g_hc && Still(h) && ConvertMenu((HMENU)wp, h)) AttachMenuWnd((HMENU)wp);
      return true;
    }
    case WM_UNINITMENUPOPUP: {
      EnterCriticalSection(&g_cs);
      MenuRec* r = FindMenuRec((HMENU)wp);
      if (r && r->owner != h) r = nullptr;
      LeaveCriticalSection(&g_cs);
      if (r) RestoreMenuRec(r);
      return false;
    }
    case WM_MEASUREITEM: {
      MEASUREITEMSTRUCT* mis = (MEASUREITEMSTRUCT*)lp;
      if (wp || !mis || mis->CtlType != ODT_MENU) return false;
      wchar_t buf[512];
      MenuItemView v;
      if (!MenuItemFor(h, nullptr, mis->itemID, mis->itemData, &v, buf, 512)) return false;
      MenuMeasure(h, mis, v);
      *out = TRUE;
      return true;
    }
    case WM_DRAWITEM: {
      DRAWITEMSTRUCT* dis = (DRAWITEMSTRUCT*)lp;
      if (wp || !dis || dis->CtlType != ODT_MENU) return false;
      wchar_t buf[512];
      MenuItemView v;
      if (!MenuItemFor(h, (HMENU)dis->hwndItem, dis->itemID, dis->itemData, &v, buf, 512)) return false;
      MenuDraw(dis, h, v);
      *out = TRUE;
      return true;
    }
    case WM_MENUCHAR: {
      if (HIWORD(wp) & MF_SYSMENU) return false;
      HMENU hm = (HMENU)lp;
      EnterCriticalSection(&g_cs);
      bool ours = FindMenuRec(hm) != nullptr;
      LeaveCriticalSection(&g_cs);
      if (!ours) return false;
      int cnt = 0, hit = MenuMnemonic(hm, (wchar_t)LOWORD(wp), &cnt);
      if (hit < 0) return false;
      *out = MAKELRESULT(hit, cnt > 1 ? MNC_SELECT : MNC_EXECUTE);
      return true;
    }
    default: return false;
  }
}

static bool MenuIsOurs(HWND h) {
  HMENU hm = (HMENU)SendMessageW(h, MN_GETHMENU, 0, 0);
  if (!hm) return false;
  EnterCriticalSection(&g_cs);
  bool r = FindMenuRec(hm) != nullptr;
  LeaveCriticalSection(&g_cs);
  return r;
}

// 菜单窗口没有非客户区（Wine 把菜单外框画在客户区里）时：系统画完后，客户区边缘到全部菜单项的外接矩形之间那一圈铺换肤底色、最外一圈画细边，
// 菜单项本身不碰；菜单项超出客户区（太长、有滚动箭头）时不画。Windows 的菜单外框在非客户区，走 WM_NCPAINT，这里不会执行
static void PaintMenuClientRing(Win* w, HDC target) {
  HWND h = w->h;
  WINDOWINFO wi;
  memset(&wi, 0, sizeof(wi));
  wi.cbSize = sizeof(wi);
  if (!GetWindowInfo(h, &wi) || !EqualRect(&wi.rcWindow, &wi.rcClient)) return;
  HMENU hm = (HMENU)SendMessageW(h, MN_GETHMENU, 0, 0);
  int n = hm ? GetMenuItemCount(hm) : 0;
  if (n <= 0) return;
  RECT u = {0, 0, 0, 0};
  for (int i = 0; i < n; ++i) {
    RECT r;
    if (!GetMenuItemRect(nullptr, hm, (UINT)i, &r)) return;
    UnionRect(&u, &u, &r);
  }
  RECT cr;
  GetClientRect(h, &cr);
  POINT o = {0, 0};
  ClientToScreen(h, &o);
  OffsetRect(&u, -o.x, -o.y);
  if (u.left < cr.left || u.top < cr.top || u.right > cr.right || u.bottom > cr.bottom || IsRectEmpty(&u)) return;
  Canvas c;
  if (!c.Begin(cr.right, cr.bottom)) return;
  const Palette& p = Pal();
  FillAll(c, Over(p.windowBg & 0xFFFFFF, p.popupBg));
  StrokeRR(c, 0, 0, (float)cr.right, (float)cr.bottom, 0, (DpiScale(h) < 1.0f ? 1.0f : DpiScale(h)), p.popupStroke, p.popupStroke, 0);
  HDC dc = target ? target : GetDC(h);
  if (!dc) return;
  int saved = SaveDC(dc);
  ExcludeClipRect(dc, u.left, u.top, u.right, u.bottom);
  BitBlt(dc, 0, 0, cr.right, cr.bottom, c.dc, 0, 0, SRCCOPY);
  RestoreDC(dc, saved);
  if (!target) ReleaseDC(h, dc);
}

static LRESULT MenuWndProc(Win* w, HWND h, UINT m, WPARAM wp, LPARAM lp) {
  (void)w;
  if (g_hc) return pDSP(h, m, wp, lp);
  switch (m) {
    case WM_NCPAINT: {
      LRESULT r = pDSP(h, m, wp, lp);
      Win* x = Still(h);
      if (x && MenuIsOurs(h)) {
        if (!x->applied) PopupFrame(x, true);
        PaintPopupFrame(x, nullptr);
      }
      return r;
    }
    case WM_PRINT: {  // 菜单淡入 / 滑出动画用 WM_PRINT 画进内存位图
      LRESULT r = pDSP(h, m, wp, lp);
      Win* x = Still(h);
      if (x && wp && (lp & PRF_NONCLIENT) && MenuIsOurs(h)) PaintPopupFrame(x, (HDC)wp);
      return r;
    }
    case WM_PAINT:
    case WM_PRINTCLIENT: {
      LRESULT r = pDSP(h, m, wp, lp);
      Win* x = Still(h);
      if (x && MenuIsOurs(h)) PaintMenuClientRing(x, m == WM_PRINTCLIENT ? (HDC)wp : nullptr);
      return r;
    }
    default: break;
  }
  return pDSP(h, m, wp, lp);
}

static LRESULT CALLBACK Proc(HWND h, UINT m, WPARAM wp, LPARAM lp, UINT_PTR id, DWORD_PTR ref) {
  Win* w = (Win*)ref;
  if (m == WM_NCDESTROY) {
    Forget(w);
    return pDSP(h, m, wp, lp);
  }
  if (IsRootKind(w->kind)) {
    if (m == g_msgRescan) {
      Rescan(w, true);
      return 0;
    }
    if (m == g_msgRefresh) {
      RefreshRoot(w);
      return 0;
    }
    if (m == g_msgDetach) {
      DetachRoot(w);
      return 0;
    }
    if (m == g_msgAttachChild) {
      HWND c = (HWND)wp;
      if (IsWindow(c)) {
        RemovePropW(c, MAKEINTATOM(g_atomPend));
        if (IsChild(h, c) && SameThread(c)) AttachTree(c, h);
      }
      return 0;
    }
  }
  switch (m) {
    case WM_PARENTNOTIFY:
      if (LOWORD(wp) == WM_CREATE && lp) {
        HWND c = (HWND)lp;
        if (IsWindow(c) && SameThread(c) && IsChild(w->root, c)) AttachTree(c, w->root);
      }
      break;
    case WM_CTLCOLORBTN:
    case WM_CTLCOLORSTATIC:
    case WM_CTLCOLOREDIT:
    case WM_CTLCOLORLISTBOX:
      if ((HWND)lp != h) NoteCandidate(w, (HWND)lp);
      if (w->kind == K_DIALOG && !g_hc && (m == WM_CTLCOLORSTATIC || m == WM_CTLCOLORBTN)) return DialogCtlColor(w, (HDC)wp, (HWND)lp);
      break;
    case WM_CTLCOLORDLG:
      if (w->kind == K_DIALOG && !g_hc) return (LRESULT)w->brContent;
      break;
    case WM_ENTERMENULOOP:
    case WM_EXITMENULOOP:
    case WM_INITMENUPOPUP:
    case WM_UNINITMENUPOPUP:
    case WM_MEASUREITEM:
    case WM_DRAWITEM:
    case WM_MENUCHAR:
      if (w->kind != K_MENUWND) {  // 接入的窗口当菜单所有者（易语言窗口、黑月外框、编辑框的右键菜单）
        LRESULT res = 0;
        if (MenuOwnerMsg(w, h, m, wp, lp, &res)) return res;
      }
      break;
    default: break;
  }
  switch (w->kind) {
    case K_ROOT:
    case K_DIALOG: return RootProc(w, h, m, wp, lp);
    case K_CONTAINER:
    case K_LISTVIEW: return pDSP(h, m, wp, lp);
    case K_EDIT: return EditProc(w, h, m, wp, lp);
    case K_MENUWND: return MenuWndProc(w, h, m, wp, lp);
    default: return ControlProc(w, h, m, wp, lp);
  }
}

// —— 信息框换肤范围：只在本线程、只在调用期间装 CBT 钩子；激活时接上新出现的简单对话框 ——
// 只接信息框、输入框这类简单对话框：子窗口只有静态、普通按钮（1～7 个）、最多一个编辑框。
// 文件对话框、选色对话框（6 个编辑框、自己画色块）、查找对话框（选择框 / 单选框）都不碰
static bool IsSimpleDialog(HWND h) {
  if (GetWindowLongW(h, GWL_STYLE) & WS_CHILD) return false;
  wchar_t cls[16];
  if (!GetClassNameW(h, cls, 16) || lstrcmpW(cls, L"#32770") != 0) return false;
  if (Ours(h) || GetPropW(h, MAKEINTATOM(g_atomOff))) return false;
  int buttons = 0, edits = 0;
  for (HWND c = GetWindow(h, GW_CHILD); c; c = GetWindow(c, GW_HWNDNEXT)) {
    wchar_t cc[32];
    if (!GetClassNameW(c, cc, 32)) return false;
    if (lstrcmpiW(cc, L"Static") == 0) continue;
    if (lstrcmpiW(cc, L"Edit") == 0) {
      if (++edits > 1) return false;
      continue;
    }
    if (lstrcmpiW(cc, L"Button") == 0) {
      int t = GetWindowLongW(c, GWL_STYLE) & BS_TYPEMASK;
      if (t != BS_PUSHBUTTON && t != BS_DEFPUSHBUTTON) return false;
      ++buttons;
      continue;
    }
    return false;
  }
  return buttons >= 1 && buttons <= 7;
}

// 窗口类是不是系统模块注册的（输入法、外壳等系统窗口）：取不到模块路径时也按系统的算，不接
static bool SystemClass(HWND h) {
  HMODULE m = ClassImplModule(h);  // 按实现窗口类的模块判断（见 ClassImplModule：GCLP_HMODULE 在 6.0 版清单下可能是宿主 exe）
  if (!m) return true;
  wchar_t path[MAX_PATH], win[MAX_PATH + 1];
  DWORD n = GetModuleFileNameW(m, path, MAX_PATH);
  // 用共享的系统 Windows 目录：远程桌面会话主机上，宿主 exe 没标“终端服务感知”时 GetWindowsDirectory 返回的是每个用户的私有目录
  // （微软文档；这个标志只看主 exe，DLL 上设了也不算）。目录末尾补上“\”再比，免得 C:\Windows.old、C:\WindowsApps 也被当成系统目录
  UINT k = GetSystemWindowsDirectoryW(win, MAX_PATH);
  if (!n || n >= MAX_PATH || !k || k >= MAX_PATH) return true;
  if (win[k - 1] != L'\\') {
    win[k++] = L'\\';
    win[k] = 0;
  }
  return _wcsnicmp(path, win, k) == 0;
}

// 换肤范围标志 1 时，范围里新激活的普通顶层窗口（易语言窗口等）也接上：复杂对话框（文件对话框）、菜单、提示、下拉列表、内嵌浏览器都不碰
// 标准控件类：以顶层窗口出现时也不是程序的窗体，换肤范围不接
static bool IsControlClass(const wchar_t* c) {
  static const wchar_t* const k[] = {L"Button", L"Static", L"Edit", L"ListBox", L"ComboBox", L"ScrollBar", L"msctls_progress32", L"msctls_trackbar32",
                                     L"msctls_updown32", L"msctls_statusbar32", L"msctls_hotkey32", L"SysListView32", L"SysTreeView32", L"SysHeader32",
                                     L"SysTabControl32", L"SysLink", L"SysAnimate32", L"SysDateTimePick32", L"SysMonthCal32", L"SysIPAddress32",
                                     L"SysPager", L"ToolbarWindow32", L"ReBarWindow32", L"RichEdit20W", L"RichEdit20A", L"RICHEDIT50W"};
  for (const wchar_t* s : k)
    if (lstrcmpiW(c, s) == 0) return true;
  return false;
}

static bool IsAttachableTop(HWND h) {
  if (GetWindowLongW(h, GWL_STYLE) & WS_CHILD) return false;
  if (!SameThread(h) || Ours(h) || GetPropW(h, MAKEINTATOM(g_atomOff))) return false;
  wchar_t cls[64];
  if (!GetClassNameW(h, cls, 64)) return false;
  if (IsForeignClass(cls) || IsControlClass(cls) || lstrcmpW(cls, L"#32770") == 0 || lstrcmpW(cls, L"#32768") == 0 ||
      lstrcmpiW(cls, L"tooltips_class32") == 0 || lstrcmpiW(cls, L"ComboLBox") == 0)
    return false;
  return !SystemClass(h);  // 只接程序自己（易语言运行库、黑月）注册的窗口类：输入法窗口、外壳窗口等系统类不碰
}

static int ScopeFlags() {
  DWORD tid = GetCurrentThreadId();
  int f = 0;
  EnterCriticalSection(&g_cs);
  for (int i = 0; i < 32; ++i)
    if (g_scopes[i].tid == tid) {
      for (int d = 0; d < g_scopes[i].depth && d < 16; ++d) f |= g_scopes[i].flags[d];
      break;
    }
  LeaveCriticalSection(&g_cs);
  return f;
}

static LRESULT CALLBACK CbtProc(int code, WPARAM wp, LPARAM lp) {
  if (code == HCBT_CREATEWND) {  // 菜单循环里（标志 4）新建的菜单窗口：建好之前就接上，第一次画就是换肤外框
    HWND h = (HWND)wp;
    if (h && (ScopeFlags() & 4)) {
      wchar_t cls[16];
      if (GetClassNameW(h, cls, 16) && lstrcmpW(cls, L"#32768") == 0 && !Ours(h)) Subclass(h, K_MENUWND, nullptr);
    }
  } else if (code == HCBT_ACTIVATE) {
    HWND h = (HWND)wp;
    if (h) {
      int f = ScopeFlags();
      if (IsSimpleDialog(h)) {
        // XS_MessageBox 弹出的信息框：正文在 ID 0xFFFF 的静态控件里（Windows 与 Wine 相同），内容全在子控件里，整面由引擎画；
        // 找不到这个静态控件（意外的实现）时只画底色，对话框自己的 WM_PAINT 照常
        if (AttachRoot(h, K_DIALOG) && (f & 2) && (GetDlgItem(h, 0xFFFF) || GetDlgItem(h, -1))) {
          Win* w = Ours(h);
          if (w) {
            w->ownPaint = 1;
            w->footerTop = DialogFooterTop(h, true);
            InvalidateRect(h, nullptr, TRUE);
          }
        }
      } else if ((f & 1) && IsAttachableTop(h)) {
        AttachRoot(h, K_ROOT);
      }
    }
  }
  return CallNextHookEx(nullptr, code, wp, lp);
}

static int ScopeBegin(int flags) {
  DWORD tid = GetCurrentThreadId();
  int depth = 0;
  EnterCriticalSection(&g_cs);
  Scope* s = nullptr;
  for (int i = 0; i < 32 && !s; ++i)
    if (g_scopes[i].tid == tid) s = &g_scopes[i];
  for (int i = 0; i < 32 && !s; ++i)
    if (g_scopes[i].tid == 0) {
      s = &g_scopes[i];
      s->tid = tid;
      s->depth = 0;
      s->hook = nullptr;
    }
  if (s) {
    if (s->depth < 16) s->flags[s->depth] = flags;
    if (s->depth == 0) {
      s->hook = SetWindowsHookExW(WH_CBT, CbtProc, nullptr, tid);
      if (s->hook) {
        ++g_hooks;
        AcquireSelf();
      }
    }
    depth = ++s->depth;
  }
  LeaveCriticalSection(&g_cs);
  return depth;
}

static int ScopeEnd() {
  DWORD tid = GetCurrentThreadId();
  HHOOK un = nullptr;
  int depth = -1;
  EnterCriticalSection(&g_cs);
  for (int i = 0; i < 32; ++i)
    if (g_scopes[i].tid == tid) {
      Scope* s = &g_scopes[i];
      if (s->depth > 0) --s->depth;
      depth = s->depth;
      if (s->depth == 0) {
        un = s->hook;
        if (un) --g_hooks;
        s->hook = nullptr;
        s->tid = 0;
      }
      break;
    }
  LeaveCriticalSection(&g_cs);
  if (un) UnhookWindowsHookEx(un);
  return depth;
}

static int ScopeDepth() {
  DWORD tid = GetCurrentThreadId();
  int d = 0;
  EnterCriticalSection(&g_cs);
  for (int i = 0; i < 32; ++i)
    if (g_scopes[i].tid == tid) d = g_scopes[i].depth;
  LeaveCriticalSection(&g_cs);
  return d;
}

// —— 初始化 ——
static bool EnsureInit() {
  if (g_initState == 1) return true;
  if (g_initState == -1) {
    g_lastErr = XE_INIT;
    return false;
  }
  EnterCriticalSection(&g_cs);
  if (g_initState == 0) {
    HMODULE cc = LoadLibraryW(L"comctl32.dll");
    if (cc) {
      pSWS = MySetSubclass;  // 自己的子类化（保持窗口的字符集），见 MySetSubclass
      pGWS = MyGetSubclass;
      pRWS = MyRemoveSubclass;
      pDSP = MyDefSubclass;
    }
    HMODULE dwm = LoadLibraryW(L"dwmapi.dll");
    if (dwm) pDwm = (PFN_DwmSet)(void*)GetProcAddress(dwm, "DwmSetWindowAttribute");
    HMODULE ux = LoadLibraryW(L"uxtheme.dll");
    if (ux) pTheme = (PFN_SetTheme)(void*)GetProcAddress(ux, "SetWindowTheme");
    pDpi = (PFN_DpiWnd)(void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetDpiForWindow");
    PFN_RtlVer rv = (PFN_RtlVer)(void*)GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlGetVersion");
    OSVERSIONINFOW vi;
    memset(&vi, 0, sizeof(vi));
    vi.dwOSVersionInfoSize = sizeof(vi);
    if (rv && rv(&vi) == 0) g_realBuild = (int)vi.dwBuildNumber;
    HDC sdc = GetDC(nullptr);
    if (sdc) {
      int d = GetDeviceCaps(sdc, LOGPIXELSY);
      if (d > 0) g_sysDpi = d;
      ReleaseDC(nullptr, sdc);
    }
    g_msgRefresh = RegisterWindowMessageW(L"XhhSkin.Refresh");
    g_msgRescan = RegisterWindowMessageW(L"XhhSkin.Rescan");
    g_msgDetach = RegisterWindowMessageW(L"XhhSkin.Detach");
    g_msgAttachChild = RegisterWindowMessageW(L"XhhSkin.AttachChild");
    g_atomOff = GlobalAddAtomW(L"XhhSkin.Off");
    g_atomSub = GlobalAddAtomW(L"XhhSkin.Sub");
    g_atomBk = GlobalAddAtomW(L"XhhSkin.Bk");
    g_atomPend = GlobalAddAtomW(L"XhhSkin.Pend");
    bool ok = pSWS && pGWS && pRWS && pDSP && g_atomSub && g_msgRefresh && g_msgRescan && g_msgDetach && g_msgAttachChild && g_atomOff && g_atomBk && g_atomPend;
    if (ok) Recompute();
    g_initState = ok ? 1 : -1;
  }
  LeaveCriticalSection(&g_cs);
  if (g_initState != 1) {
    g_lastErr = XE_INIT;
    return false;
  }
  return true;
}

// —— 普查：子树里各窗口类的处理情况 ——
struct CEnt {
  wchar_t cls[40];
  int n;
};

static void CAdd(CEnt* a, int* cnt, int cap, const wchar_t* cls) {
  for (int i = 0; i < *cnt; ++i)
    if (lstrcmpiW(a[i].cls, cls) == 0) {
      ++a[i].n;
      return;
    }
  if (*cnt < cap) {
    lstrcpynW(a[*cnt].cls, cls, 40);
    a[*cnt].n = 1;
    ++*cnt;
  }
}

static void CWalk(HWND h, CEnt* themed, int* nt, CEnt* skipped, int* ns, int* containers, int* other, int* comctl) {
  for (HWND c = GetWindow(h, GW_CHILD); c; c = GetWindow(c, GW_HWNDNEXT)) {
    if (!SameThread(c)) {
      ++*other;
      continue;
    }
    wchar_t cls[64];
    if (!GetClassNameW(c, cls, 64)) cls[0] = 0;
    if (*comctl == 0 && lstrcmpiW(cls, L"Button") == 0) *comctl = ComctlMajor(c);
    Win* w = Ours(c);
    if (w && w->kind == K_CONTAINER) ++*containers;
    else if (w) CAdd(themed, nt, 24, cls);
    else CAdd(skipped, ns, 24, cls);
    CWalk(c, themed, nt, skipped, ns, containers, other, comctl);
  }
}

static void Append(wchar_t* buf, int cap, int* pos, const wchar_t* s) {
  while (*s && *pos < cap - 1) buf[(*pos)++] = *s++;
  buf[*pos] = 0;
}

}  // namespace xs

using namespace xs;

// ==================== 导出（全部 INT_PTR __stdcall f(INT_PTR, INT_PTR, INT_PTR, INT_PTR)，易语言用 调用桩_4参数 调用） ====================

XS_EXPORT XS_GetVersion(INT_PTR, INT_PTR, INT_PTR, INT_PTR) { return XS_VERSION; }

// 项：1 主题（a：0 跟随系统 1 浅色 2 深色）2 强调色（a：0 Win11 默认蓝 1 跟随系统 2 自定义，b＝0xRRGGBB）3 标题栏材质（a：0 不用 1 Mica 2 Mica Alt 3 亚克力）
//     4 无边框窗口在 Win11 上圆角（a：1 是 0 否）10 容器底色（a＝窗口句柄，b＝COLORREF，-1＝清除）100、101 测试用（假装系统版本号、高对比度）
XS_EXPORT XS_Set(INT_PTR item, INT_PTR a, INT_PTR b, INT_PTR) {
  if (!EnsureInit()) return 0;
  switch (item) {
    case 1:
      if (a < 0 || a > 2) return 0;
      g_mode = (int)a;
      break;
    case 2:
      if (a < 0 || a > 2) return 0;
      g_accentMode = (int)a;
      if (a == 2) g_accentCustom = (uint32_t)b & 0xFFFFFF;
      break;
    case 3:
      if (a < 0 || a > 3) return 0;
      g_backdrop = (int)a;
      break;
    case 4: g_round = a ? 1 : 0; break;
    case 10: {
      HWND h = (HWND)a;
      if (!IsWindow(h)) return 0;
      if (b == -1) RemovePropW(h, MAKEINTATOM(g_atomBk));
      else SetPropW(h, MAKEINTATOM(g_atomBk), (HANDLE)(UINT_PTR)(((COLORREF)b & 0xFFFFFF) + 1));
      return 1;
    }
    case 100: g_forceBuild = (int)a; break;
    case 101: g_forceHC = a < 0 ? -1 : (a ? 1 : 0); break;
    default: return 0;
  }
  Recompute();
  RefreshAll();
  return 1;
}

// 接入顶层窗口（连同全部子孙，之后新加的也会接上）。flags：1＝当对话框处理（引擎画底色与按钮区）。成功 1，失败 0（原因见 XS_GetInfo 11）
XS_EXPORT XS_Attach(INT_PTR hwnd, INT_PTR flags, INT_PTR, INT_PTR) {
  if (!EnsureInit()) return 0;
  return AttachRoot((HWND)hwnd, (flags & 1) ? K_DIALOG : K_ROOT) ? 1 : 0;
}

// 卸下：根窗口连同子孙恢复系统外观；也可以只卸某个控件（连同它的子孙）
XS_EXPORT XS_Detach(INT_PTR hwnd, INT_PTR, INT_PTR, INT_PTR) {
  if (!EnsureInit()) return 0;
  HWND h = (HWND)hwnd;
  if (!IsWindow(h)) {
    g_lastErr = XE_BADHWND;
    return 0;
  }
  if (!SameThread(h)) {
    if (!IsRootKind(RegKind(h))) {
      g_lastErr = XE_THREAD;
      return 0;
    }
    DWORD_PTR res = 0;
    SendMessageTimeoutW(h, g_msgDetach, 0, 0, SMTO_BLOCK, 3000, &res);
    MaybeReleaseSelf();
    return 1;
  }
  Win* w = Ours(h);
  if (!w) {
    g_lastErr = XE_NOTOURS;
    return 0;
  }
  if (IsRootKind(w->kind)) DetachRoot(w);
  else DetachSubtree(h);
  MaybeReleaseSelf();
  return 1;
}

// 排除（a＝1）/ 取消排除（a＝0）某个窗口连同子孙：排除后保持系统原样，自动接入也跳过它
XS_EXPORT XS_Exclude(INT_PTR hwnd, INT_PTR on, INT_PTR, INT_PTR) {
  if (!EnsureInit()) return 0;
  HWND h = (HWND)hwnd;
  if (!IsWindow(h)) {
    g_lastErr = XE_BADHWND;
    return 0;
  }
  if (on) {
    SetPropW(h, MAKEINTATOM(g_atomOff), (HANDLE)1);
    if (SameThread(h)) {
      Win* w = Ours(h);
      if (w && IsRootKind(w->kind)) DetachRoot(w);
      else DetachSubtree(h);
    }
    MaybeReleaseSelf();
  } else {
    RemovePropW(h, MAKEINTATOM(g_atomOff));
    if (SameThread(h)) {
      HWND root = FindRootOf(GetParent(h) ? GetParent(h) : h);
      if (root && root != h) AttachTree(h, root);
    }
  }
  return 1;
}

// 重扫并重画：hwnd＝0 为本线程全部根窗口
XS_EXPORT XS_Refresh(INT_PTR hwnd, INT_PTR, INT_PTR, INT_PTR) {
  if (!EnsureInit()) return 0;
  HWND h = (HWND)hwnd;
  if (!h) {
    Recompute();
    RefreshAll();
    return 1;
  }
  if (!IsWindow(h) || !SameThread(h)) {
    g_lastErr = IsWindow(h) ? XE_THREAD : XE_BADHWND;
    return 0;
  }
  HWND root = FindRootOf(h);
  Win* r = root ? Ours(root) : nullptr;
  if (!r) {
    g_lastErr = XE_NOTOURS;
    return 0;
  }
  Rescan(r, true);
  RefreshRoot(r);
  return 1;
}

// 换肤的信息框：与 MessageBoxW 相同的参数与返回值（父窗口、宽字符正文、宽字符标题、按钮与图标标志）
XS_EXPORT XS_MessageBox(INT_PTR owner, INT_PTR text, INT_PTR title, INT_PTR flags) {
  bool ok = EnsureInit();
  if (ok) ScopeBegin(2);  // 2＝信息框范围（内部标志）
  int r = MessageBoxW((HWND)owner, (LPCWSTR)text, (LPCWSTR)title, (UINT)flags);
  if (ok) {
    ScopeEnd();
    MaybeReleaseSelf();
  }
  return r;
}

// 换肤范围：在这之间本线程新出现的简单对话框（信息框、输入框）会换肤；a＝1 时新激活的、程序自己注册的窗口类的顶层窗口（易语言窗口）也接上。返回嵌套层数
XS_EXPORT XS_ScopeBegin(INT_PTR a, INT_PTR, INT_PTR, INT_PTR) {
  if (!EnsureInit()) return 0;
  return ScopeBegin((int)(a & 1));
}

XS_EXPORT XS_ScopeEnd(INT_PTR, INT_PTR, INT_PTR, INT_PTR) {
  if (!EnsureInit()) return 0;
  int d = ScopeEnd();
  MaybeReleaseSelf();
  return d;
}

// 项：1 版本 2 根窗口数 3 换肤的控件数 4 窗口状态（a＝句柄：0 不归引擎 1 控件或容器 2 根窗口）5 当前是否深色 6 高对比度（交回系统绘制）
//     7 系统版本号 8 DWM 能力（1 深色标题栏 2 圆角 4 材质 8 Win11 21H2 的 Mica）9 浅色强调色 10 控件所属通用控件版本（a＝句柄）11 上次错误
//     12 引擎可用 13 窗口已请求的 DWM 属性（a＝句柄）14 窗口种类（a＝句柄）15 本线程换肤范围层数 16 子类化的窗口总数 17 上次绘制是否交回原样（a＝句柄）
//     18 深色强调色 19 对话框是否整面由引擎画（a＝句柄；只有信息框是）
XS_EXPORT XS_GetInfo(INT_PTR item, INT_PTR a, INT_PTR, INT_PTR) {
  bool ok = EnsureInit();
  switch (item) {
    case 1: return XS_VERSION;
    case 11: return g_lastErr;
    case 12: return ok ? 1 : 0;
    default: break;
  }
  if (!ok) return 0;
  switch (item) {
    case 2:
    case 3:
    case 16: {
      int n = 0;
      EnterCriticalSection(&g_cs);
      for (int i = 0; i < g_nWins; ++i) {
        int k = g_wins[i]->kind;
        if (item == 2 && IsRootKind(k)) ++n;
        else if (item == 3 && k != K_CONTAINER && !IsRootKind(k)) ++n;
        else if (item == 16) ++n;
      }
      LeaveCriticalSection(&g_cs);
      return n;
    }
    case 4: {
      int k = RegKind((HWND)a);
      return k == 0 ? 0 : IsRootKind(k) ? 2 : 1;
    }
    case 5: return g_pal.dark ? 1 : 0;
    case 6: return g_hc ? 1 : 0;
    case 7: return Build();
    case 8: {
      int b = Build(), m = 0;
      if (pDwm && b >= 17763) m |= 1;
      if (pDwm && b >= 22000) m |= 2;
      if (pDwm && b >= 22621) m |= 4;
      if (pDwm && b >= 22000 && b < 22621) m |= 8;
      return m;
    }
    case 9: return g_accLight;
    case 10: return IsWindow((HWND)a) ? ComctlMajor((HWND)a) : 0;
    case 13:
    case 14:
    case 17:
    case 19: {
      INT_PTR v = 0;
      EnterCriticalSection(&g_cs);
      for (int i = 0; i < g_nWins; ++i)
        if (g_wins[i]->h == (HWND)a) {
          v = item == 13 ? (INT_PTR)g_wins[i]->applied : item == 14 ? g_wins[i]->kind : item == 17 ? g_wins[i]->passive : g_wins[i]->ownPaint;
          break;
        }
      LeaveCriticalSection(&g_cs);
      return v;
    }
    case 15: return ScopeDepth();
    case 18: return g_accDark;
    default: return 0;
  }
}

// 颜色令牌（COLORREF，已叠在窗口底色上）：1 窗口底色 2 主要文字 3 次要文字 4 禁止文字 5 强调色 6 强调色上的文字 7 对话框内容区 8 对话框按钮区
//     9 按钮底色 10 输入框底边 11 分组框边 12 列表选中底色
XS_EXPORT XS_GetColor(INT_PTR token, INT_PTR, INT_PTR, INT_PTR) {
  if (!EnsureInit()) return -1;
  const Palette& p = g_pal;
  uint32_t bg = p.windowBg & 0xFFFFFF, v;
  switch (token) {
    case 1: v = bg; break;
    case 2: v = Over(bg, p.textPrimary); break;
    case 3: v = Over(bg, p.textSecondary); break;
    case 4: v = Over(bg, p.textDisabled); break;
    case 5: v = Over(bg, p.accent); break;
    case 6: v = Over(Over(bg, p.accent), p.textOnAccent); break;
    case 7: v = Over(bg, p.dialogContent); break;
    case 8: v = Over(Over(bg, p.dialogContent), p.dialogFooter); break;
    case 9: v = Over(bg, p.fillRest); break;
    case 10: v = Over(bg, p.fieldBottom); break;
    case 11: v = Over(bg, p.groupStroke); break;
    case 12: v = Over(bg, p.listSelected); break;
    default: return -1;
  }
  return (INT_PTR)ToCref(v);
}

// 普查（诊断）：buf 收宽字符文字（cap 个字符，含结尾零），返回写入的字符数。格式：
// themed: Button x3, Edit x2; containers: 4; skipped: Static x7; other-thread: 1; comctl: 6
XS_EXPORT XS_Census(INT_PTR hwnd, INT_PTR buf, INT_PTR cap, INT_PTR) {
  if (!buf || cap <= 0) return 0;
  wchar_t* out = (wchar_t*)buf;
  out[0] = 0;
  if (!EnsureInit()) return 0;
  HWND h = (HWND)hwnd;
  if (!IsWindow(h) || !SameThread(h)) return 0;
  CEnt themed[24], skipped[24];
  int nt = 0, ns = 0, containers = 0, other = 0, comctl = 0;
  CWalk(h, themed, &nt, skipped, &ns, &containers, &other, &comctl);
  int pos = 0;
  wchar_t num[16];
  Append(out, (int)cap, &pos, L"themed: ");
  for (int i = 0; i < nt; ++i) {
    if (i) Append(out, (int)cap, &pos, L", ");
    Append(out, (int)cap, &pos, themed[i].cls);
    wsprintfW(num, L" x%d", themed[i].n);
    Append(out, (int)cap, &pos, num);
  }
  wsprintfW(num, L"%d", containers);
  Append(out, (int)cap, &pos, L"; containers: ");
  Append(out, (int)cap, &pos, num);
  Append(out, (int)cap, &pos, L"; skipped: ");
  for (int i = 0; i < ns; ++i) {
    if (i) Append(out, (int)cap, &pos, L", ");
    Append(out, (int)cap, &pos, skipped[i].cls);
    wsprintfW(num, L" x%d", skipped[i].n);
    Append(out, (int)cap, &pos, num);
  }
  wsprintfW(num, L"%d", other);
  Append(out, (int)cap, &pos, L"; other-thread: ");
  Append(out, (int)cap, &pos, num);
  wsprintfW(num, L"%d", comctl);  // 按钮所属的通用控件版本：6＝程序带视觉样式清单（滚动条等系统部件是新样式），5＝没有（经典样式），0＝没有按钮
  Append(out, (int)cap, &pos, L"; comctl: ");
  Append(out, (int)cap, &pos, num);
  return pos;
}

// 全部卸下（程序退出前或要 FreeLibrary 前）：本线程的根窗口直接卸，别的线程的交给它们自己的线程卸；结束本线程的换肤范围。返回卸下的根窗口数
XS_EXPORT XS_Shutdown(INT_PTR, INT_PTR, INT_PTR, INT_PTR) {
  if (g_initState != 1) return 0;
  EnterCriticalSection(&g_cs);
  int n = 0;
  HWND* hs = (HWND*)malloc((size_t)(g_nWins ? g_nWins : 1) * sizeof(HWND));
  DWORD* ts = (DWORD*)malloc((size_t)(g_nWins ? g_nWins : 1) * sizeof(DWORD));
  if (hs && ts)
    for (int i = 0; i < g_nWins; ++i)
      if (IsRootKind(g_wins[i]->kind)) {
        hs[n] = g_wins[i]->h;
        ts[n] = g_wins[i]->tid;
        ++n;
      }
  LeaveCriticalSection(&g_cs);
  DWORD me = GetCurrentThreadId();
  for (int i = 0; i < n; ++i) {
    if (ts[i] == me) {
      Win* w = Ours(hs[i]);
      if (w) DetachRoot(w);
    } else {
      DWORD_PTR res = 0;
      SendMessageTimeoutW(hs[i], g_msgDetach, 0, 0, SMTO_BLOCK, 3000, &res);
    }
  }
  free(hs);
  free(ts);
  while (ScopeDepth() > 0) ScopeEnd();
  MaybeReleaseSelf();
  return n;
}

BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID reserved) {
  if (reason == DLL_PROCESS_ATTACH) {
    g_self = inst;
    DisableThreadLibraryCalls(inst);
    InitializeCriticalSection(&g_cs);
  } else if (reason == DLL_PROCESS_DETACH) {
    if (!reserved) DeleteCriticalSection(&g_cs);  // FreeLibrary：走到这里说明已没有子类化与钩子（否则自引用让我们不会被卸下）
  }
  return TRUE;
}
