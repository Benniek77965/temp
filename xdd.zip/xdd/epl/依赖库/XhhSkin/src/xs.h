// XhhSkin.dll —— 小红花音效助手原生皮肤引擎（浅色外观取自原 SkinSharp「Win11皮肤_1_浅色」；32 位、stdcall、四参数 C 接口）
// 只处理显式接入（XS_Attach）的顶层窗口及其子孙；不装全局钩子、不改别的线程与别的进程的窗口。
#pragma once
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <commctrl.h>
#include <stdint.h>

#define XS_VERSION 0x00010000  // 1.0.0

namespace xs {

typedef uint32_t Argb;  // 0xAARRGGBB，直通 alpha
inline Argb Mk(uint32_t a, uint32_t rgb) { return (a << 24) | (rgb & 0xFFFFFF); }

// 控件种类
enum Kind {
  K_NONE = 0,
  K_ROOT,        // 接入的顶层窗口（外框）
  K_DIALOG,      // 接入的对话框顶层窗口（信息框等）：引擎负责画底色与按钮区
  K_CONTAINER,   // 容器：只为发现后加进来的控件而子类化（WM_PARENTNOTIFY、WM_CTLCOLOR*），不绘制
  K_PUSH,        // 按钮（含 BS_PUSHLIKE 的选择框/单选框）
  K_CHECK,       // 选择框（复选框）
  K_RADIO,       // 单选框
  K_GROUP,       // 分组框
  K_EDIT,        // 编辑框（只画边框）
  K_COMBO,       // 组合框（不可编辑列表式整面绘制；可编辑式画外框与箭头）
  K_COMBOLIST,   // 组合框的下拉列表（ComboLBox）
  K_LISTBOX,     // 列表框
  K_PROGRESS,    // 进度条
  K_LISTVIEW,    // 超级列表框：只设系统 Explorer 主题（通用控件 6.0 时），消息原样交回
  K_MENUWND,     // 弹出菜单窗口（#32768）：菜单换了肤时画外框（菜单项本身由所有者窗口按自绘画）
  K_COUNT
};

struct Palette {
  bool dark;
  Argb windowBg;
  Argb textPrimary, textSecondary, textDisabled;
  Argb accent, accentHover, accentPressed, accentDisabled;
  Argb textOnAccent, textOnAccentPressed, textOnAccentDisabled;
  Argb fillRest, fillHover, fillPressed, fillDisabled;
  Argb strokeTop, strokeBottom, strokeDisabled;
  Argb strokeHover, strokePressed, focusLine;  // 按钮悬停/按下/键盘焦点的边框（原皮肤为蓝色）
  Argb accentStrokeTop, accentStrokeBottom;
  Argb fieldFill, fieldFillDisabled;
  Argb fieldStroke, fieldBottom, fieldStrokeDisabled;
  Argb fieldStrokeFocus;
  Argb checkStroke, checkStrokeDisabled, checkFillRest, checkFillHover, checkFillPressed;
  Argb checkStrokeHover;
  Argb groupStroke;
  Argb listHover, listSelected, listSelectedHover;
  Argb popupBg, popupStroke;
  Argb progressTrack, progressError, progressPaused;
  Argb focusOuter, focusInner;
  Argb dialogContent, dialogFooter, dialogDivider;
  Argb chevron, chevronDisabled;
};

// 每个被子类化窗口的状态（SetWindowSubclass 的 dwRefData）
struct Win {
  HWND h;
  int kind;
  HWND root;        // 所属接入根窗口
  DWORD tid;
  uint8_t hot;      // 鼠标在上面
  uint8_t tracking; // 已 TrackMouseEvent
  uint8_t passive;  // 本次绘制交回原窗口过程（纯图片按钮、高对比度等）
  uint8_t themed;   // 设过 SetWindowTheme（K_LISTVIEW 用）
  HWND owner;       // K_COMBOLIST：所属组合框
  int footerTop;    // K_DIALOG：按钮区上沿（客户区坐标，-1 = 没有）
  uint32_t applied; // 根窗口 / 下拉列表：已请求的 DWM 属性（XA_*，测试与诊断用）
  HBRUSH brContent, brFooter; // K_DIALOG：给子控件的底色刷
  uint8_t noRedraw; // 程序发了 WM_SETREDRAW(FALSE)：这期间不主动重画
  DWORD lastRescan; // 根窗口：上次重扫子窗口的时刻
  uint8_t ownPaint; // K_DIALOG：整面由引擎画（只用于 XS_MessageBox 弹出的信息框，内容全在子控件里）
  uint8_t menuLoop; // 菜单所有者：正处在菜单循环里（开着接菜单窗口的内部范围）
};

// 已请求的 DWM 属性（Win::applied）
enum {
  XA_DARK = 1,      // 深色标题栏（DWMWA_USE_IMMERSIVE_DARK_MODE）
  XA_ROUND = 2,     // 圆角（DWMWA_WINDOW_CORNER_PREFERENCE）
  XA_BACKDROP = 4,  // 背景材质（DWMWA_SYSTEMBACKDROP_TYPE / Win11 21H2 的 Mica 开关）
  XA_BORDER = 8     // 边框颜色（DWMWA_BORDER_COLOR）
};

// 画布：32 位自上而下 DIB，像素 0x00RRGGBB
struct Canvas {
  HDC dc;
  HBITMAP bmp;
  HGDIOBJ oldBmp;
  uint32_t* px;
  int w, h;
  Canvas() : dc(nullptr), bmp(nullptr), oldBmp(nullptr), px(nullptr), w(0), h(0) {}
  ~Canvas() { End(); }
  bool Begin(int W, int H);
  void End();
};

// —— 主题（xs_theme.cpp）——
void BuildPalette(Palette& p, bool dark, uint32_t accLight, uint32_t accDark);
bool SystemDark();
bool SystemHighContrast();
bool SystemAccent(uint32_t* light, uint32_t* dark);
uint32_t AccentForLight(uint32_t base);
uint32_t AccentForDark(uint32_t base);
double Luminance(uint32_t rgb);
double Contrast(uint32_t a, uint32_t b);

// —— 引擎（xs_core.cpp）——
const Palette& Pal();                       // 当前调色板（界面线程读）
float DpiScale(HWND h);                     // 窗口 DPI / 96
int ComctlMajor(HWND h);                    // 控件所属通用控件版本：6 / 5 / 0
COLORREF ContainerColor(HWND h, HWND root); // 祖先容器上用 XS_Set 10 交代的底色（0xFFFFFFFF = 没有）

// —— 绘制（xs_draw.cpp）——
void FillAll(Canvas& c, uint32_t rgb);
void FillRR(Canvas& c, float x0, float y0, float x1, float y1, float r, Argb col);
void StrokeRR(Canvas& c, float x0, float y0, float x1, float y1, float r, float w, Argb top, Argb bottom, float gradPx);
void FillCircle(Canvas& c, float cx, float cy, float rad, Argb col);
void StrokeCircle(Canvas& c, float cx, float cy, float rad, float w, Argb col);
void Polyline(Canvas& c, const float* pts, int n, float width, Argb col);
void FillRectA(Canvas& c, float x0, float y0, float x1, float y1, Argb col);
uint32_t Over(uint32_t bg, Argb c);        // c 叠在不透明 bg 上的结果（0x00RRGGBB）
COLORREF ToCref(uint32_t rgb);
uint32_t FromCref(COLORREF c);
uint32_t ParentBackground(Canvas& c, HWND hwnd, UINT ctlMsg, COLORREF* textOut, int ox, int oy, HWND root);
bool Themable(Win* w);                      // 这次绘制是否由引擎画（纯图片按钮交回原样）
void PaintControl(Win* w, HDC dst);         // 按 w->kind 整面绘制客户区
bool NcBorder(HWND h, int* b);              // 非客户区边框厚度（按窗口矩形与客户区的实际偏移算）
void PaintEditFrame(Win* w, HDC target = nullptr);  // 编辑框边框（非客户区）：target 为空画到窗口 DC，否则画进 WM_PRINT 给的 DC
void PaintListFrame(Win* w, HDC target = nullptr);  // 下拉列表 / 列表框边框（非客户区）：同上
void PaintPopupFrame(Win* w, HDC target);   // 弹出层（下拉列表、菜单窗口）的外框：target 为空画到窗口 DC，否则画进 WM_PRINT 给的 DC
struct MenuItemView {                       // 菜单项：画、量时要用的内容
  const wchar_t* text;
  int len;
  UINT type, state;
  bool sub;
};
void MenuMeasure(HWND owner, MEASUREITEMSTRUCT* mis, const MenuItemView& v);
void MenuDraw(const DRAWITEMSTRUCT* dis, HWND owner, const MenuItemView& v);
HBRUSH MenuBackBrush();                     // 菜单底色画刷（换肤期间设进菜单，关掉后还原）
void PaintDialogBg(Win* w, HDC dst);        // 对话框底色与按钮区
int DialogFooterTop(HWND dlg, bool msgBox); // 对话框按钮区上沿（没有按钮、或按钮不在下半部返回 -1）

}  // namespace xs
