#ifndef AT_COMPANION_MAILBOX_H
#define AT_COMPANION_MAILBOX_H
#include "companion_security.h"
/* Mailbox identity is cryptographic, not a filename convention. Independent
   counters allow a temporarily unreadable control mailbox to arrive later;
   domain keys prevent copying its ciphertext to another slot to replay it. */
static int atcs_channel_key(const unsigned char root[32],unsigned channel,unsigned char out[32]){
    static const char* labels[4]={"XAKS2 channel cmd","XAKS2 channel feel","XAKS2 channel control","XAKS2 channel eject"};
    if(!root||!out||channel>=4)return 0;atc_hmac_sha256(root,32,labels[channel],strlen(labels[channel]),out);return 1;
}
static int atcs_channel_seal(const unsigned char root[32],unsigned channel,const char* sid,uint64_t sequence,uint64_t expiry,const char* plain,unsigned len,char* out,unsigned capacity){
    unsigned char key[32];if(!atcs_channel_key(root,channel,key))return 0;int ok=atcs_seal(key,sid,sequence,expiry,plain,len,out,capacity);atcs_wipe(key,sizeof key);return ok;
}
static int atcs_channel_open(const unsigned char root[32],unsigned channel,const char* sid,uint64_t expiry,const char* encoded,unsigned len,uint64_t* last,char* out,unsigned capacity){
    unsigned char key[32];if(!atcs_channel_key(root,channel,key))return 0;int ok=atcs_open(key,sid,expiry,encoded,len,last,out,capacity);atcs_wipe(key,sizeof key);return ok;
}
struct ATCS_Mailbox { uint64_t sequence; unsigned slot; char plain[1025]; };
static unsigned atcs_mailbox_decode(const unsigned char key[32],const char* sid,uint64_t expiry,const uint64_t* committed,
    const char* const* encoded,const unsigned* lengths,unsigned slots,ATCS_Mailbox* out,unsigned capacity){
    if(!key||!sid||!committed||!encoded||!lengths||!out||slots>3||capacity<slots)return 0;
    unsigned count=0;
    for(unsigned i=0;i<slots;i++){
        if(!encoded[i]||!lengths[i])continue;
        ATCS_Mailbox candidate;memset(&candidate,0,sizeof candidate);candidate.slot=i;uint64_t verified=committed[i];
        if(atcs_channel_open(key,i,sid,expiry,encoded[i],lengths[i],&verified,candidate.plain,sizeof candidate.plain)){
            candidate.sequence=verified;unsigned position=count;
            while(position&&out[position-1].sequence>candidate.sequence){out[position]=out[position-1];position--;}
            out[position]=candidate;count++;
        }
        atcs_wipe(&candidate,sizeof candidate);
    }
    return count;
}
static int atcs_mailbox_commit(const ATCS_Mailbox* record,uint64_t* committed){
    if(!record||!committed||record->slot>=3||!record->sequence||record->sequence<=committed[record->slot])return 0;
    const char* end=(const char*)memchr(record->plain,0,sizeof record->plain);
    if(!end||!atcs_plain_valid(record->plain,(unsigned)(end-record->plain)))return 0;
    committed[record->slot]=record->sequence;return 1;
}
/* A pause is a signed control-channel barrier. Independent mailbox counters
   still admit delayed reloads, but no command older than a pause/resume edge
   may change parameters. Inspect a whole authenticated snapshot before writes. */
struct ATCS_PauseBarrier { uint64_t sequence; int paused; };
static int atcs_mailbox_is_pause(const ATCS_Mailbox* record){
    if(!record||record->slot!=2||!record->sequence||!memchr(record->plain,0,sizeof record->plain))return 0;
    const char* p=record->plain;if(strncmp(p,"pause=1|t=",10))return 0;p+=10;
    if(*p<'0'||*p>'9')return 0;while(*p>='0'&&*p<='9')p++;
    return *p=='\n'&&!p[1];
}
static int atcs_pause_barrier(ATCS_PauseBarrier* state,const ATCS_Mailbox* record){
    if(!state||!atcs_mailbox_is_pause(record)||record->sequence<=state->sequence)return 0;
    state->sequence=record->sequence;state->paused=1;return 1;
}
static int atcs_mailbox_full_target(const ATCS_Mailbox* record){
    if(!record||record->slot!=0||!memchr(record->plain,0,sizeof record->plain)||strncmp(record->plain,"key=",4))return 0;
    const char* end=strchr(record->plain+4,'|');if(!end||atc_decimal(record->plain+4,(unsigned)(end-record->plain-4),11)<0||strncmp(end,"|scale=",7))return 0;
    const char* name=end+7;end=strchr(name,'|');if(!end)return 0;unsigned n=(unsigned)(end-name);
    return (n==5&&(!memcmp(name,"Major",5)||!memcmp(name,"Minor",5)))||(n==9&&!memcmp(name,"Chromatic",9));
}
static int atcs_pause_allows(const ATCS_Mailbox* record,ATCS_PauseBarrier* state){
    if(!record||!state||record->slot>1||!record->sequence||record->sequence<=state->sequence)return 0;
    if(record->slot==0){if(!atcs_mailbox_full_target(record))return 0;state->sequence=record->sequence;state->paused=0;return 1;}
    return !state->paused;
}
/* Key commands also carry the current retune. A delayed older feel mailbox
   must not roll that value back; key/scale and control reloads still execute. */
static int atcs_mailbox_retune_allowed(const ATCS_Mailbox* record,uint64_t* lastRetune){
    if(!record||!lastRetune||!memchr(record->plain,0,sizeof record->plain))return 0;
    if(!strstr(record->plain,"retune=")&&!strstr(record->plain,"speed="))return 1;
    if(!record->sequence||record->sequence<=*lastRetune)return 0;*lastRetune=record->sequence;return 1;
}
#endif
