#ifndef AT_COMPANION_LOADER_POLICY_H
#define AT_COMPANION_LOADER_POLICY_H
/* The worker publishes only immutable PUBLIC policy. No keys/tokens enter a
   callback snapshot. Readers increment before loading the pointer; reclamation
   happens on the worker only after publication and a zero-reader observation. */
typedef struct ATCS_LoaderPolicy {ATCS_Claims policy;struct ATCS_LoaderPolicy* retiredNext;} ATCS_LoaderPolicy;
static ATCS_LoaderPolicy* volatile g_loaderPolicy=NULL;
static ATCS_LoaderPolicy* g_loaderRetired=NULL;
static volatile LONG g_loaderReaders=0;
static ATCS_LoaderPolicy* atcs_loader_acquire(){InterlockedIncrement(&g_loaderReaders);return (ATCS_LoaderPolicy*)InterlockedCompareExchangePointer((void* volatile*)&g_loaderPolicy,NULL,NULL);}
static void atcs_loader_release(){InterlockedDecrement(&g_loaderReaders);}
struct ATCS_LoaderRead {ATCS_LoaderPolicy* snapshot;ATCS_LoaderRead():snapshot(atcs_loader_acquire()){}~ATCS_LoaderRead(){atcs_loader_release();}};
static void atcs_loader_collect(){
    if(InterlockedCompareExchange(&g_loaderReaders,0,0))return;
    while(g_loaderRetired){ATCS_LoaderPolicy* old=g_loaderRetired;g_loaderRetired=old->retiredNext;HeapFree(GetProcessHeap(),0,old);}
}
static int atcs_loader_publish(const ATCS_Claims* claims){
    ATCS_LoaderPolicy* fresh=NULL;
    if(claims){fresh=(ATCS_LoaderPolicy*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof *fresh);if(!fresh)return 0;
        fresh->policy.policy=claims->policy;fresh->policy.issued=claims->issued;fresh->policy.expires=claims->expires;fresh->policy.parent=claims->parent;
        memcpy(fresh->policy.racks,claims->racks,sizeof claims->racks);memcpy(fresh->policy.plugins,claims->plugins,sizeof claims->plugins);}
    ATCS_LoaderPolicy* old=(ATCS_LoaderPolicy*)InterlockedExchangePointer((void* volatile*)&g_loaderPolicy,fresh);
    if(old){old->retiredNext=g_loaderRetired;g_loaderRetired=old;}atcs_loader_collect();return 1;
}
#endif
