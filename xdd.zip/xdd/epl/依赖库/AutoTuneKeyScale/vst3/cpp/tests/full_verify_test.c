#include <stdio.h>
#include <string.h>
#include "companion_protocol.h"      /* project's own, unmodified atc_sha256 */
#include "companion_rsa_verify.h"    /* new self-contained RSA verify */
#include "vector.h"

static void print_hex(const char* label, const unsigned char* b, unsigned n) {
    printf("%s: ", label); for (unsigned i=0;i<n;i++) printf("%02x", b[i]); printf("\n");
}

int main(void) {
    int all_ok = 1;

    /* sanity: project's own sha256 matches the prefix we derived independently via python hashlib */
    unsigned char h1[32]; ATC_SHA256 c; atc_sha_init(&c); atc_sha_update(&c, TV_MSG, TV_MSG_LEN); atc_sha_final(&c, h1);
    unsigned char h2[32]; ATC_SHA256 c2; atc_sha_init(&c2); atc_sha_update(&c2, TV_MSG2, TV_MSG2_LEN); atc_sha_final(&c2, h2);

    int r;

    /* Test 1: valid signature over TV_MSG, verified against the correct hash -> MUST accept */
    r = atcs_rsa2048_pkcs1_sha256_verify(TV_MODULUS, (uint32_t)TV_EXPONENT, h1, TV_SIG_VALID);
    printf("[1] valid signature, correct hash      -> verify=%d  (expect 1) %s\n", r, r==1?"PASS":"FAIL");
    if (r!=1) all_ok=0;

    /* Test 2: same signature, single bit flipped -> MUST reject */
    r = atcs_rsa2048_pkcs1_sha256_verify(TV_MODULUS, (uint32_t)TV_EXPONENT, h1, TV_SIG_BITFLIP);
    printf("[2] bit-flipped signature               -> verify=%d  (expect 0) %s\n", r, r==0?"PASS":"FAIL");
    if (r!=0) all_ok=0;

    /* Test 3: a validly-signed signature, but for a DIFFERENT message, checked against TV_MSG's hash -> MUST reject */
    r = atcs_rsa2048_pkcs1_sha256_verify(TV_MODULUS, (uint32_t)TV_EXPONENT, h1, TV_SIG_WRONGMSG);
    printf("[3] signature of a different message    -> verify=%d  (expect 0) %s\n", r, r==0?"PASS":"FAIL");
    if (r!=0) all_ok=0;

    /* Test 4: that same wrong-message signature DOES verify against its own correct hash (h2) -> MUST accept */
    r = atcs_rsa2048_pkcs1_sha256_verify(TV_MODULUS, (uint32_t)TV_EXPONENT, h2, TV_SIG_WRONGMSG);
    printf("[4] msg2 signature against msg2's hash  -> verify=%d  (expect 1) %s\n", r, r==1?"PASS":"FAIL");
    if (r!=1) all_ok=0;

    /* Test 5: wrong exponent (e.g. e=3 instead of 65537) must reject the real signature */
    r = atcs_rsa2048_pkcs1_sha256_verify(TV_MODULUS, 3u, h1, TV_SIG_VALID);
    printf("[5] correct sig, wrong exponent(3)      -> verify=%d  (expect 0) %s\n", r, r==0?"PASS":"FAIL");
    if (r!=0) all_ok=0;

    /* Test 6: tampered modulus (flip one byte) must reject the real signature */
    {
        unsigned char badmod[256]; memcpy(badmod, TV_MODULUS, 256); badmod[10]^=0x01;
        r = atcs_rsa2048_pkcs1_sha256_verify(badmod, (uint32_t)TV_EXPONENT, h1, TV_SIG_VALID);
        printf("[6] correct sig, tampered modulus       -> verify=%d  (expect 0) %s\n", r, r==0?"PASS":"FAIL");
        if (r!=0) all_ok=0;
    }

    /* Test 7: signature == modulus-or-greater must be rejected outright (range check) */
    {
        unsigned char oor[256]; memset(oor,0xFF,256); /* definitely >= modulus */
        r = atcs_rsa2048_pkcs1_sha256_verify(TV_MODULUS, (uint32_t)TV_EXPONENT, h1, oor);
        printf("[7] out-of-range signature (0xFF..FF)   -> verify=%d  (expect 0) %s\n", r, r==0?"PASS":"FAIL");
        if (r!=0) all_ok=0;
    }

    print_hex("sha256(TV_MSG) via project's atc_sha256", h1, 32);
    printf("\n%s\n", all_ok ? "FULL_VERIFY_TEST: ALL_PASS" : "FULL_VERIFY_TEST: FAILURES_PRESENT");
    return all_ok ? 0 : 1;
}
