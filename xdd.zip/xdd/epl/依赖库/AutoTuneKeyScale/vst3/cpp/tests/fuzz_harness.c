#include <stdio.h>
#include <stdlib.h>
#include "companion_rsa_verify.h"

static void read_limbs(FILE* f, uint32_t* out, unsigned n) {
    if (fread(out, 4, n, f) != n) { fprintf(stderr, "short read\n"); exit(2); }
}

int main(void) {
    int overall_ok = 1;

    /* ---- atcs_bn_mul fuzz ---- */
    {
        FILE* f = fopen("mul_tests.bin", "rb");
        if (!f) { perror("mul_tests.bin"); return 2; }
        uint32_t n; fread(&n, 4, 1, f);
        unsigned fails = 0;
        for (uint32_t i = 0; i < n; i++) {
            ATCS_BN a, b; ATCS_BN2 expect, got;
            read_limbs(f, a, ATCS_BN_LIMBS);
            read_limbs(f, b, ATCS_BN_LIMBS);
            read_limbs(f, expect, 2*ATCS_BN_LIMBS);
            atcs_bn_mul(a, b, got);
            if (atcs_bn2_cmp(got, expect) != 0) {
                fails++;
                if (fails <= 3) fprintf(stderr, "MUL MISMATCH case %u\n", i);
            }
        }
        fclose(f);
        printf("bn_mul:    %u/%u passed\n", n - fails, n);
        if (fails) overall_ok = 0;
    }

    /* ---- atcs_bn_mod fuzz ---- */
    {
        FILE* f = fopen("mod_tests.bin", "rb");
        if (!f) { perror("mod_tests.bin"); return 2; }
        uint32_t n; fread(&n, 4, 1, f);
        unsigned fails = 0;
        for (uint32_t i = 0; i < n; i++) {
            ATCS_BN2 x; ATCS_BN m, expect, got;
            read_limbs(f, x, 2*ATCS_BN_LIMBS);
            read_limbs(f, m, ATCS_BN_LIMBS);
            read_limbs(f, expect, ATCS_BN_LIMBS);
            atcs_bn_mod(x, m, got);
            if (atcs_bn_cmp(got, expect) != 0) {
                fails++;
                if (fails <= 3) fprintf(stderr, "MOD MISMATCH case %u\n", i);
            }
        }
        fclose(f);
        printf("bn_mod:    %u/%u passed\n", n - fails, n);
        if (fails) overall_ok = 0;
    }

    /* ---- atcs_bn_modexp fuzz (includes e=65537 and other exponents) ---- */
    {
        FILE* f = fopen("modexp_tests.bin", "rb");
        if (!f) { perror("modexp_tests.bin"); return 2; }
        uint32_t n; fread(&n, 4, 1, f);
        unsigned fails = 0;
        for (uint32_t i = 0; i < n; i++) {
            ATCS_BN base, m, expect, got; uint32_t exp;
            read_limbs(f, base, ATCS_BN_LIMBS);
            fread(&exp, 4, 1, f);
            read_limbs(f, m, ATCS_BN_LIMBS);
            read_limbs(f, expect, ATCS_BN_LIMBS);
            atcs_bn_modexp(base, exp, m, got);
            if (atcs_bn_cmp(got, expect) != 0) {
                fails++;
                if (fails <= 3) fprintf(stderr, "MODEXP MISMATCH case %u (exp=%u)\n", i, exp);
            }
        }
        fclose(f);
        printf("bn_modexp: %u/%u passed\n", n - fails, n);
        if (fails) overall_ok = 0;
    }

    printf(overall_ok ? "FUZZ_HARNESS: ALL_PASS\n" : "FUZZ_HARNESS: FAILURES_PRESENT\n");
    return overall_ok ? 0 : 1;
}
