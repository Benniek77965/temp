测试运行方法
============
本目录下 fuzz_harness.c / full_verify_test.c 依赖上级目录里的
companion_rsa_verify.h 和 companion_protocol.h（项目正式源码，未额外复制）。

1) 大数运算随机对拍（需要先用 generate_vectors.py 生成 .bin 测试向量，
   或自行重新生成以使用不同的随机种子/数据量）：
     pip install cryptography
     python3 generate_vectors.py
     gcc -O2 -I.. -o fuzz_harness fuzz_harness.c
     ./fuzz_harness

2) 完整 RSA-2048 PKCS#1v1.5 验签测试（vector.h 已随附，可直接运行；
   如需换一组新的真实签名测试向量，重新运行 generate_vectors.py 即可）：
     gcc -O2 -I.. -o full_verify_test full_verify_test.c
     ./full_verify_test

两者也都可以换成 x86_64-w64-mingw32-gcc / i686-w64-mingw32-gcc 交叉编译，
在 Wine 下运行，验证与目标工具链一致的行为。
