# -*- coding: utf-8 -*-
# 重新生成 fuzz_harness.c / full_verify_test.c 所需的测试向量。
# 需要: pip install cryptography
import struct, random, os, hashlib
random.seed(20261104)

def rand_bn(nbits=2048, forceTopBit=False):
    v = random.getrandbits(nbits)
    if forceTopBit: v |= (1 << (nbits-1))
    return v

def to_le_limbs(v, nlimbs):
    return b"".join(struct.pack('<I', (v >> (32*i)) & 0xffffffff) for i in range(nlimbs))

N_MUL=3000; N_MOD=3000; N_EXP=200
with open('mul_tests.bin','wb') as f:
    f.write(struct.pack('<I', N_MUL))
    for _ in range(N_MUL):
        a=rand_bn(2048); b=rand_bn(2048)
        f.write(to_le_limbs(a,64)+to_le_limbs(b,64)+to_le_limbs(a*b,128))
with open('mod_tests.bin','wb') as f:
    f.write(struct.pack('<I', N_MOD))
    for _ in range(N_MOD):
        m=rand_bn(2048, True); x=rand_bn(4096)
        f.write(to_le_limbs(x,128)+to_le_limbs(m,64)+to_le_limbs(x%m,64))
with open('modexp_tests.bin','wb') as f:
    f.write(struct.pack('<I', N_EXP))
    for _ in range(N_EXP):
        m=rand_bn(2048, True); base=rand_bn(2048)%m
        exp=random.choice([3,17,257,65537,random.getrandbits(20)|1])
        f.write(to_le_limbs(base,64)+struct.pack('<I',exp)+to_le_limbs(m,64)+to_le_limbs(pow(base,exp,m),64))
print("写出 mul_tests.bin / mod_tests.bin / modexp_tests.bin")

from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
nums = priv.public_key().public_numbers()
msg = b"xhh-rack test claims payload, build verification"
sig = priv.sign(msg, padding.PKCS1v15(), hashes.SHA256())
bad_sig = bytearray(sig); bad_sig[100]^=1
msg2 = b"a totally different message, should not verify"
sig2 = priv.sign(msg2, padding.PKCS1v15(), hashes.SHA256())
def carr(name,b): return "static const unsigned char %s[%d] = {%s};\n"%(name,len(b),",".join("0x%02x"%x for x in b))
with open('vector.h','w') as f:
    f.write("#ifndef RSA_TEST_VECTOR_H\n#define RSA_TEST_VECTOR_H\n")
    f.write(carr("TV_MODULUS", nums.n.to_bytes(256,'big')))
    f.write("static const unsigned long TV_EXPONENT = %dUL;\n"%nums.e)
    f.write(carr("TV_MSG", msg)); f.write("static const unsigned TV_MSG_LEN=%d;\n"%len(msg))
    f.write(carr("TV_SIG_VALID", sig)); f.write(carr("TV_SIG_BITFLIP", bytes(bad_sig)))
    f.write(carr("TV_MSG2", msg2)); f.write("static const unsigned TV_MSG2_LEN=%d;\n"%len(msg2))
    f.write(carr("TV_SIG_WRONGMSG", sig2))
    f.write("#endif\n")
print("写出 vector.h (真实 RSA-2048 签名测试向量)")
