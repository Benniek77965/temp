#ifndef AT_COMPANION_UI_ROUTES_H
#define AT_COMPANION_UI_ROUTES_H
/* PINNED, never-reused forwarding identities. Owner-thread installers can finish
   after their worker timed out, so reservations are bounded CAS slots and only
   release-published records may be read. An original never changes after publish. */
#define ATUI_MAX_ROUTES 256
struct ATUI_Route {HWND window;WNDPROC original;int unicode;DWORD thread;volatile LONG destroyed,published,writeReady;};
static ATUI_Route g_uiRoutes[ATUI_MAX_ROUTES];
static volatile LONG g_uiRouteCount=0; /* reservations, including failed epochs */
static const wchar_t ATUI_PROPERTY[]=L"AutoTuneKeyScale.UIForward.v1";
static ATUI_Route* atui_find(HWND window){
    LONG count=InterlockedCompareExchange(&g_uiRouteCount,0,0);
    for(LONG i=0;i<count;i++)if(InterlockedCompareExchange(&g_uiRoutes[i].published,0,0)&&g_uiRoutes[i].window==window)return &g_uiRoutes[i];
    return NULL;
}
static int atui_thread_observed(DWORD thread){
    LONG count=InterlockedCompareExchange(&g_uiRouteCount,0,0);
    for(LONG i=0;i<count;i++)if(InterlockedCompareExchange(&g_uiRoutes[i].published,0,0)&&g_uiRoutes[i].thread==thread)return 1;
    return 0;
}
static int atui_epoch_live(const ATUI_Route* route){
    return route&&InterlockedCompareExchange((volatile LONG*)&route->published,0,0)
        &&!InterlockedCompareExchange((volatile LONG*)&route->destroyed,0,0)
        &&GetPropW(route->window,ATUI_PROPERTY)==(HANDLE)route;
}
static int atui_live(const ATUI_Route* route){
    return atui_epoch_live(route)&&InterlockedCompareExchange((volatile LONG*)&route->writeReady,0,0);
}
static ATUI_Route* atui_reserve(HWND window,int unicode,DWORD thread){
    if(atui_find(window)||GetPropW(window,ATUI_PROPERTY))return NULL;
    LONG count=InterlockedCompareExchange(&g_uiRouteCount,0,0);
    for(;;){if(count>=ATUI_MAX_ROUTES)return NULL;LONG before=InterlockedCompareExchange(&g_uiRouteCount,count+1,count);if(before==count)break;count=before;}
    ATUI_Route* route=&g_uiRoutes[count];
    route->window=window;route->unicode=unicode;route->thread=thread;
    if(!SetPropW(window,ATUI_PROPERTY,(HANDLE)route))return NULL;
    return route;
}
static void atui_publish(ATUI_Route* route,WNDPROC original,int writable){
    route->original=original;route->writeReady=writable;
    InterlockedExchange(&route->published,1);
}
/* Direct preparation is retained for read-only forwarding/lifetime regression
   fixtures. Production subclass installation reserves then publishes on owner. */
static ATUI_Route* atui_prepare(HWND window,WNDPROC original,int unicode,DWORD thread){
    ATUI_Route* route=atui_reserve(window,unicode,thread);if(!route)return NULL;
    atui_publish(route,original,1);return route;
}
static void atui_destroy(ATUI_Route* route){
    if(!route)return;
    InterlockedExchange(&route->destroyed,1);
    if(GetPropW(route->window,ATUI_PROPERTY)==(HANDLE)route)RemovePropW(route->window,ATUI_PROPERTY);
}
#endif
