#ifndef AT_COMPANION_POLICY_H
#define AT_COMPANION_POLICY_H
#include "companion_security.h"
#include <wchar.h>
/* Convert the actual OS UTF-16 basename; never reinterpret an ACP/GBK label as UTF-8.
   Bounded and API-free, so the same identity rules are testable outside Windows. */
static int atcs_policy_basename(const wchar_t* path,char out[129]){
    if(!path||!out)return 0;unsigned start=0,n=0;while(n<32768&&path[n]){if(path[n]=='\\'||path[n]=='/')start=n+1;n++;}if(n==32768||n==start)return 0;
    unsigned used=0;for(unsigned i=start;i<n;i++){
        unsigned c=(unsigned)path[i];if(c>=0xd800&&c<=0xdbff){if(++i==n)return 0;unsigned d=(unsigned)path[i];if(d<0xdc00||d>0xdfff)return 0;c=0x10000+((c-0xd800)<<10)+(d-0xdc00);}else if(c>=0xdc00&&c<=0xdfff)return 0;
        if(c>0x10ffff)return 0;unsigned bytes=c<128?1:c<2048?2:c<65536?3:4;if(used+bytes>128)return 0;
        if(bytes==1)out[used++]=(char)c;
        else{if(bytes==2)out[used++]=(char)(0xc0|(c>>6));else if(bytes==3){out[used++]=(char)(0xe0|(c>>12));out[used++]=(char)(0x80|((c>>6)&63));}else{out[used++]=(char)(0xf0|(c>>18));out[used++]=(char)(0x80|((c>>12)&63));out[used++]=(char)(0x80|((c>>6)&63));}out[used++]=(char)(0x80|(c&63));}
    }out[used]=0;return 1;
}
static int atcs_policy_path_denied(const ATCS_Claims* lease,int rack,const wchar_t* path){char name[129];return !atcs_policy_basename(path,name)||atcs_policy_denied(lease,rack,name);}
static int atcs_policy_contains(const char* name,const char* term){
    for(unsigned i=0;name[i];i++){unsigned j=0;for(;term[j]&&name[i+j];j++){unsigned c=(unsigned char)name[i+j];if(c>='A'&&c<='Z')c+=32;if(c!=(unsigned char)term[j])break;}if(!term[j])return 1;}return 0;
}
static const char* atcs_policy_family_name(const char* name){
    if(atcs_policy_contains(name,"waveshell")||atcs_policy_contains(name,"waves tune"))return "waves";
    if(atcs_policy_contains(name,"t-pain")||atcs_policy_contains(name,"tpain"))return "tpain";
    if(atcs_policy_contains(name,"auto-tune")||atcs_policy_contains(name,"autotune")||atcs_policy_contains(name,"antares"))return "antares";
    return NULL;
}
static int atcs_policy_module_denied(const ATCS_Claims* lease,const wchar_t* path,const char* family){
    char name[129];if(!atcs_policy_basename(path,name)||atcs_policy_denied(lease,0,name))return 1;
    const char* detected=atcs_policy_family_name(name);return (family&&atcs_policy_denied(lease,0,family))||(detected&&atcs_policy_denied(lease,0,detected));
}
#endif
