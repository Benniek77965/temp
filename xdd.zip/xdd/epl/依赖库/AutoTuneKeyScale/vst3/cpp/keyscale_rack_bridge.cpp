/* xhh32 native companion transport. No initialization, resource extraction,
   network or worker threads in DllMain. Configure is called by the host ONLY
   after local consent. Network renewal has its own worker; every UI/engine
   tick and WM_COPYDATA request remains bounded independently of the network. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winhttp.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
#include <map>
#include "companion_security.h"
#include "companion_envelope.h"
#include "rack_bridge_json.h"
#define XRB_AGENT_BUILD 1166

static HMODULE xrb_module=NULL;
static CRITICAL_SECTION xrb_lock;
struct XRB_Guard { XRB_Guard(){EnterCriticalSection(&xrb_lock);}~XRB_Guard(){LeaveCriticalSection(&xrb_lock);} };
enum { XRB_AUTH_NONE=0,XRB_AUTH_METADATA,XRB_AUTH_HTTP,XRB_AUTH_VERIFY,XRB_AUTH_CONTROLLER,XRB_AUTH_READY };
struct XRB_AuthDiagnostic { unsigned stage,http,reason; XRB_AuthDiagnostic():stage(XRB_AUTH_NONE),http(0),reason(0){} };
static const char* const xrb_auth_reasons[]={"none","metadata_missing","transport_failed","invalid_response","token_missing","token_validation_failed","lease_expired","lease_rollback","controller_rejected","unknown_server_error","feature_disabled","invalid_credentials","legacy_verifier_unavailable","authorization_denied","license_expiring","device_limit","license_in_use","outside_rollout","version_disabled","policy_unavailable","rate_limited","invalid_token","token_expired","revoked","session_revoked_or_replayed","authorization_changed","authorize_superseded","request_replay","renewal_too_frequent","authorization_too_frequent","internal_error","invalid_request","invalid_license_id","invalid_credential","invalid_device","invalid_nonce","invalid_parent","invalid_controller_version","invalid_agent_build","invalid_product","invalid_racks","invalid_plugins","invalid_policy","method_not_allowed","invalid_length","incomplete_body","json_required","invalid_json","invalid_peer_ip","invalid_proxy_headers","invalid_proxy_ip","transport_key_changed","invalid_envelope","transport_unavailable","transport_key_invalid"};
static unsigned xrb_auth_reason(const std::string& reason){for(unsigned i=0;i<sizeof(xrb_auth_reasons)/sizeof(xrb_auth_reasons[0]);i++)if(reason==xrb_auth_reasons[i])return i;return 9;}
static const char* xrb_auth_reason_name(unsigned reason){return reason<sizeof(xrb_auth_reasons)/sizeof(xrb_auth_reasons[0])?xrb_auth_reasons[reason]:"unknown_server_error";}
static const char* xrb_auth_stage_name(unsigned stage){static const char* const names[]={"none","waiting_metadata","http","verify_token","controller","ready"};return stage<sizeof(names)/sizeof(names[0])?names[stage]:"none";}
struct XRB_State {
    std::wstring directory,base,account,credential,language,legacy;
    std::string token,pending;
    ATCS_Claims lease;
    char device[65];
    HWND sender,controller;
    HANDLE owner,child,wake,worker;
    DWORD childPid;
    volatile LONG running,enabled,error;
    unsigned soft,workerEpoch;
    uint64_t sequence,revision,installedRevision,childLeaseIssued,pauseRevision;
    ULONGLONG deadline,nextAuth,lastLaunch,childRetireDeadline;
    bool configured,haveLease,needReplay,selfcheck,productReady,legacyReady,childLeasePossible,childRetiring,paused,pauseHandshake;
    XRB_AuthDiagnostic authDiagnostic;
    int key,scale,strength;
    uint32_t status,feel;
    XRB_State():sender(NULL),controller(NULL),owner(NULL),child(NULL),wake(NULL),worker(NULL),childPid(0),running(0),enabled(0),error(18),soft(3),workerEpoch(0),sequence(0),revision(0),installedRevision(0),childLeaseIssued(0),pauseRevision(0),deadline(0),nextAuth(0),lastLaunch(0),childRetireDeadline(0),configured(false),haveLease(false),needReplay(false),selfcheck(false),productReady(false),legacyReady(false),childLeasePossible(false),childRetiring(false),paused(false),pauseHandshake(false),key(-1),scale(-1),strength(-1),status(0xc0000000UL),feel(0x80000000UL){memset(&lease,0,sizeof lease);device[0]=0;}
};
static XRB_State xrb;
static std::wstring xrb_child_dir();   /* defined later; where the controller and its files go (runtime dir \keyscale_rack) */
enum { XRB_OK=0,XRB_CONNECTING=1,XRB_CONFIGURATION=2,XRB_DENIED=3,XRB_NETWORK=4,XRB_FILES=5,XRB_OLD_CONTROLLER=6,XRB_USER=7,XRB_OS=8,XRB_OTHER_OWNER=9,XRB_STALLED=10,XRB_EXPIRED=11,XRB_PROTOCOL=12,XRB_REVOKED=13,XRB_DISABLED=18 };
static void xrb_error(int error){InterlockedExchange(&xrb.error,error);}
static void xrb_auth_diagnostic(unsigned stage,const char* reason){xrb.authDiagnostic.stage=stage;xrb.authDiagnostic.http=0;xrb.authDiagnostic.reason=xrb_auth_reason(reason);}
static int xrb_auth_summary(wchar_t* out,uintptr_t capacity){if(!out||capacity<2||capacity>32768)return 0;wchar_t text[256];swprintf(text,256,L"auth_stage=%hs http=%u auth_reason=%hs error=%ld",xrb_auth_stage_name(xrb.authDiagnostic.stage),xrb.authDiagnostic.http,xrb_auth_reason_name(xrb.authDiagnostic.reason),(long)xrb.error);size_t n=wcslen(text);if(n>=capacity)n=(size_t)capacity-1;memcpy(out,text,n*sizeof(wchar_t));out[n]=0;return (int)n;}
static bool xrb_consent(){HKEY k=NULL;DWORD value=0,n=sizeof value,type=0;if(RegOpenKeyExW(HKEY_CURRENT_USER,L"SOFTWARE\\DianYinAssistant\\RackLink",0,KEY_QUERY_VALUE,&k)!=ERROR_SUCCESS)return false;LONG e=RegQueryValueExW(k,L"RackLinkConsent",NULL,&type,(BYTE*)&value,&n);RegCloseKey(k);return e==ERROR_SUCCESS&&type==REG_DWORD&&n==4&&value==1;}
static bool xrb_os(){typedef LONG (WINAPI* GetVersion)(OSVERSIONINFOW*);HMODULE ntdll=GetModuleHandleW(L"ntdll.dll");GetVersion get=ntdll?(GetVersion)GetProcAddress(ntdll,"RtlGetVersion"):NULL;OSVERSIONINFOW v;memset(&v,0,sizeof v);v.dwOSVersionInfoSize=sizeof v;return get&&get(&v)>=0&&((v.dwMajorVersion>6)||(v.dwMajorVersion==6&&v.dwMinorVersion>=1));}
static bool xrb_elevated(){HANDLE token=NULL;if(!OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&token))return false;TOKEN_ELEVATION elevation;DWORD n=0;BOOL ok=GetTokenInformation(token,TokenElevation,&elevation,sizeof elevation,&n);CloseHandle(token);return ok&&elevation.TokenIsElevated;}
static std::wstring xrb_copy_w(uintptr_t p,unsigned limit){if(!p)return std::wstring();const wchar_t* s=(const wchar_t*)p;unsigned n=0;while(n<limit&&s[n])n++;return n==limit?std::wstring():std::wstring(s,n);}
static std::string xrb_utf8(const std::wstring& w){if(w.empty())return std::string();int n=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w.data(),(int)w.size(),NULL,0,NULL,NULL);if(n<=0)return std::string();std::string s(n,0);if(WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w.data(),(int)w.size(),&s[0],n,NULL,NULL)!=n)return std::string();return s;}
static std::vector<wchar_t> xrb_environment(){std::vector<wchar_t> env;LPWCH block=GetEnvironmentStringsW();if(block){for(const wchar_t* p=block;*p;p+=wcslen(p)+1){if(_wcsnicmp(p,L"AT_XHH_LANGUAGE=",16)&&_wcsnicmp(p,L"AT_XHH_DIR=",11)){size_t n=wcslen(p)+1;env.insert(env.end(),p,p+n);}}FreeEnvironmentStringsW(block);}std::wstring item=L"AT_XHH_LANGUAGE="+(xrb.language.empty()?L"en":xrb.language);env.insert(env.end(),item.begin(),item.end());env.push_back(0);std::wstring dirItem=L"AT_XHH_DIR="+xrb_child_dir();env.insert(env.end(),dirItem.begin(),dirItem.end());env.push_back(0);env.push_back(0);return env;}
static void xrb_wipe_string(std::string& s){if(!s.empty())atcs_wipe(&s[0],s.size());s.clear();}
static bool xrb_base_valid(const std::wstring& base){URL_COMPONENTS u;memset(&u,0,sizeof u);u.dwStructSize=sizeof u;u.dwHostNameLength=u.dwUrlPathLength=u.dwExtraInfoLength=u.dwUserNameLength=u.dwPasswordLength=(DWORD)-1;
    return !base.empty()&&base.size()<2048&&WinHttpCrackUrl(base.c_str(),(DWORD)base.size(),0,&u)&&(u.nScheme==INTERNET_SCHEME_HTTPS||u.nScheme==INTERNET_SCHEME_HTTP)&&u.dwHostNameLength>0&&u.dwUserNameLength==0&&u.dwPasswordLength==0&&u.dwExtraInfoLength==0;
}
/* Only asynchronous request handles are cancelled. Context, body and read
   buffers remain alive until WinHTTP's final HANDLE_CLOSING notification. */
struct XRB_HTTP_CONTEXT {
    HANDLE event;volatile LONG references,error;DWORD expected,received;
    std::string body;char buffer[2048];
    XRB_HTTP_CONTEXT(const std::string& value):event(CreateEventW(NULL,TRUE,FALSE,NULL)),references(1),error(0),expected(0),received(0),body(value){memset(buffer,0,sizeof buffer);}
    ~XRB_HTTP_CONTEXT(){xrb_wipe_string(body);atcs_wipe(buffer,sizeof buffer);if(event)CloseHandle(event);}
};
static void xrb_http_release(XRB_HTTP_CONTEXT* context){if(InterlockedDecrement(&context->references)==0)delete context;}
static void CALLBACK xrb_http_callback(HINTERNET,DWORD_PTR value,DWORD status,LPVOID information,DWORD length) {
    XRB_HTTP_CONTEXT* context=(XRB_HTTP_CONTEXT*)value;if(!context)return;
    if(status==WINHTTP_CALLBACK_STATUS_HANDLE_CLOSING){xrb_http_release(context);return;}
    if(status==WINHTTP_CALLBACK_STATUS_REQUEST_ERROR){DWORD error=ERROR_WINHTTP_INTERNAL_ERROR;if(information&&length>=sizeof(WINHTTP_ASYNC_RESULT))error=((WINHTTP_ASYNC_RESULT*)information)->dwError;InterlockedExchange(&context->error,(LONG)error);}
    else if(status==context->expected){if(status==WINHTTP_CALLBACK_STATUS_READ_COMPLETE)context->received=length;}
    else return;
    /* Publish completion only through the event. A separately polled flag can
       let the next stage reset it before this callback's late SetEvent. */
    SetEvent(context->event);
}
struct XRB_HTTP {
    HINTERNET session,connection,request;XRB_HTTP_CONTEXT* context;
    XRB_HTTP():session(NULL),connection(NULL),request(NULL),context(NULL){}
    ~XRB_HTTP(){if(request)WinHttpCloseHandle(request);if(connection)WinHttpCloseHandle(connection);if(session)WinHttpCloseHandle(session);if(context)xrb_http_release(context);}
};
static void xrb_http_prepare(XRB_HTTP_CONTEXT* context,DWORD status){ResetEvent(context->event);context->expected=status;context->received=0;InterlockedExchange(&context->error,0);}
static int xrb_http_wait(XRB_HTTP_CONTEXT* context,ULONGLONG deadline) {
    for(;;){if(!InterlockedCompareExchange(&xrb.running,0,0)||!InterlockedCompareExchange(&xrb.enabled,0,0))return XRB_DISABLED;
        ULONGLONG now=GetTickCount64();if(now>=deadline)return XRB_NETWORK;
        DWORD remain=(DWORD)(deadline-now);DWORD wait=WaitForSingleObject(context->event,remain<50?remain:50);if(wait==WAIT_OBJECT_0)return context->error?XRB_NETWORK:XRB_OK;if(wait!=WAIT_TIMEOUT)return XRB_NETWORK;
    }
}
static int xrb_authorize_response(unsigned status,std::string& response,std::string& token,XRB_AuthDiagnostic& diagnostic) {
    diagnostic=XRB_AuthDiagnostic();diagnostic.stage=XRB_AUTH_HTTP;diagnostic.http=status;
    std::map<std::string,std::string> fields;xrb_json::Parser parser(response);if(!parser.object(fields)){diagnostic.reason=xrb_auth_reason("invalid_response");xrb_wipe_string(response);return XRB_PROTOCOL;}
    if(status!=200||fields["ok"]!="true"||parser.types["ok"]!='t') {std::string error=parser.types["error"]=='"'?fields["error"]:"";diagnostic.reason=xrb_auth_reason(error);bool revoked=diagnostic.reason==xrb_auth_reason("revoked")||diagnostic.reason==xrb_auth_reason("session_revoked_or_replayed");for(std::map<std::string,std::string>::iterator a=fields.begin();a!=fields.end();a++)xrb_wipe_string(a->second);xrb_wipe_string(error);xrb_wipe_string(response);return revoked?XRB_REVOKED:(status==401||status==403?XRB_DENIED:XRB_NETWORK);}
    std::map<std::string,std::string>::iterator it=fields.find("token");if(it==fields.end()||parser.types["token"]!='"'||it->second.empty()||it->second.size()>ATCS_MAX_TOKEN){diagnostic.reason=xrb_auth_reason("token_missing");for(std::map<std::string,std::string>::iterator a=fields.begin();a!=fields.end();a++)xrb_wipe_string(a->second);xrb_wipe_string(response);return XRB_PROTOCOL;}
    diagnostic.reason=0;token=it->second;for(std::map<std::string,std::string>::iterator a=fields.begin();a!=fields.end();a++)xrb_wipe_string(a->second);xrb_wipe_string(response);return XRB_OK;
}
/* One bounded POST to base+suffix. The WinHTTP handling below is the previous
   authorize request unchanged; it now returns status/body so the transport-key
   fetch and the sealed authorize/renew share it. Oversized bodies are wiped. */
static int xrb_http_post(const std::wstring& base,const wchar_t* suffix,const std::string& body,ULONGLONG deadline,unsigned& statusOut,std::string& response) {
    statusOut=0;xrb_wipe_string(response);
    std::wstring url=base;while(!url.empty()&&url[url.size()-1]=='/')url.resize(url.size()-1);url+=suffix;
    URL_COMPONENTS u;memset(&u,0,sizeof u);u.dwStructSize=sizeof u;u.dwHostNameLength=u.dwUrlPathLength=u.dwExtraInfoLength=(DWORD)-1;
    if(!xrb_base_valid(base)||!WinHttpCrackUrl(url.c_str(),(DWORD)url.size(),0,&u)||(u.nScheme!=INTERNET_SCHEME_HTTPS&&u.nScheme!=INTERNET_SCHEME_HTTP)||!u.dwHostNameLength)return XRB_CONFIGURATION;
    XRB_HTTP h;h.session=WinHttpOpen(L"XhhRackLink/3",WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,WINHTTP_FLAG_ASYNC);if(!h.session)return XRB_NETWORK;
    if(!WinHttpSetTimeouts(h.session,3000,3000,3000,5000))return XRB_NETWORK;
    const bool secure=u.nScheme==INTERNET_SCHEME_HTTPS;
    DWORD protocols=0x00000800; /* HTTPS keeps TLS 1.2 and normal certificate validation; HTTP is explicit configuration only. */
    if(secure&&!WinHttpSetOption(h.session,WINHTTP_OPTION_SECURE_PROTOCOLS,&protocols,sizeof protocols))return XRB_NETWORK;
    std::wstring host(u.lpszHostName,u.dwHostNameLength),path(u.lpszUrlPath,u.dwUrlPathLength);h.connection=WinHttpConnect(h.session,host.c_str(),u.nPort,0);if(!h.connection)return XRB_NETWORK;
    h.request=WinHttpOpenRequest(h.connection,L"POST",path.c_str(),NULL,WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,secure?WINHTTP_FLAG_SECURE:0);if(!h.request)return XRB_NETWORK;
    DWORD policy=WINHTTP_OPTION_REDIRECT_POLICY_NEVER;if(!WinHttpSetOption(h.request,WINHTTP_OPTION_REDIRECT_POLICY,&policy,sizeof policy))return XRB_NETWORK;
    h.context=new XRB_HTTP_CONTEXT(body);if(!h.context->event)return XRB_NETWORK;
    if(WinHttpSetStatusCallback(h.request,xrb_http_callback,WINHTTP_CALLBACK_FLAG_ALL_COMPLETIONS|WINHTTP_CALLBACK_FLAG_HANDLES,0)==WINHTTP_INVALID_STATUS_CALLBACK)return XRB_NETWORK;
    DWORD_PTR contextValue=(DWORD_PTR)h.context;if(!WinHttpSetOption(h.request,WINHTTP_OPTION_CONTEXT_VALUE,&contextValue,sizeof contextValue))return XRB_NETWORK;
    InterlockedIncrement(&h.context->references); /* owned by request until HANDLE_CLOSING */
    static const wchar_t headers[]=L"Content-Type: application/json; charset=utf-8\r\nCache-Control: no-store\r\n";
    xrb_http_prepare(h.context,WINHTTP_CALLBACK_STATUS_SENDREQUEST_COMPLETE);
    if(!WinHttpSendRequest(h.request,headers,(DWORD)-1,(void*)h.context->body.data(),(DWORD)h.context->body.size(),(DWORD)h.context->body.size(),contextValue)&&GetLastError()!=ERROR_IO_PENDING)return XRB_NETWORK;
    int result=xrb_http_wait(h.context,deadline);if(result!=XRB_OK)return result;
    xrb_http_prepare(h.context,WINHTTP_CALLBACK_STATUS_HEADERS_AVAILABLE);
    if(!WinHttpReceiveResponse(h.request,NULL)&&GetLastError()!=ERROR_IO_PENDING)return XRB_NETWORK;
    result=xrb_http_wait(h.context,deadline);if(result!=XRB_OK)return result;
    DWORD status=0,n=sizeof status;if(!WinHttpQueryHeaders(h.request,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,WINHTTP_HEADER_NAME_BY_INDEX,&status,&n,WINHTTP_NO_HEADER_INDEX))return XRB_NETWORK;
    statusOut=status;
    do{xrb_http_prepare(h.context,WINHTTP_CALLBACK_STATUS_READ_COMPLETE);if(!WinHttpReadData(h.request,h.context->buffer,sizeof h.context->buffer,NULL)&&GetLastError()!=ERROR_IO_PENDING){xrb_wipe_string(response);return XRB_NETWORK;}
        result=xrb_http_wait(h.context,deadline);if(result!=XRB_OK){xrb_wipe_string(response);return result;}if(response.size()+h.context->received>8192){xrb_wipe_string(response);return XRB_PROTOCOL;}response.append(h.context->buffer,h.context->received);
    }while(h.context->received);
    return XRB_OK;
}
/* Protocol v3 transport key: generated by the server in memory at start-up and
   published signed by the long-term signing key, so that key only ever signs.
   Cached per base URL; the worker is the only reader, the lock covers overlap
   with a retiring worker after reconfiguration. */
struct XRB_Transport { bool valid; std::wstring base; char kid[65]; unsigned char modulus[256]; XRB_Transport():valid(false){memset(kid,0,sizeof kid);memset(modulus,0,sizeof modulus);} };
static XRB_Transport xrb_transport;
static void xrb_wipe_fields(std::map<std::string,std::string>& fields){for(std::map<std::string,std::string>::iterator a=fields.begin();a!=fields.end();a++)xrb_wipe_string(a->second);}
static bool xrb_lower_hex(const std::string& v,size_t n){if(v.size()!=n)return false;for(size_t i=0;i<n;i++)if(!((v[i]>='0'&&v[i]<='9')||(v[i]>='a'&&v[i]<='f')))return false;return true;}
static int xrb_transport_fetch(const std::wstring& base,ULONGLONG deadline,XRB_Transport& out,XRB_AuthDiagnostic& diagnostic) {
    out=XRB_Transport();unsigned status=0;std::string response;
    int r=xrb_http_post(base,L"/racklink/v3/hello","{}",deadline,status,response);diagnostic.http=status;
    if(r!=XRB_OK){if(r==XRB_PROTOCOL)diagnostic.reason=xrb_auth_reason("invalid_response");return r;}
    std::map<std::string,std::string> fields;xrb_json::Parser parser(response);
    if(!parser.object(fields)){xrb_wipe_string(response);diagnostic.reason=xrb_auth_reason("invalid_response");return XRB_PROTOCOL;}
    if(status!=200||fields["ok"]!="true"||parser.types["ok"]!='t'){
        std::string error=parser.types["error"]=='"'?fields["error"]:"transport_unavailable";diagnostic.reason=xrb_auth_reason(error);
        xrb_wipe_fields(fields);xrb_wipe_string(error);xrb_wipe_string(response);return status==401||status==403?XRB_DENIED:XRB_NETWORK;}
    const std::string kid=fields["kid"],spki=fields["spki"],sig=fields["sig"];xrb_wipe_fields(fields);xrb_wipe_string(response);
    unsigned char der[294],signature[256],digest[32];char digestHex[65];
    bool ok=parser.types["v"]=='3'&&xrb_lower_hex(kid,64)&&xrb_lower_hex(spki,588)&&xrb_lower_hex(sig,512)
        &&atcs_hex_decode(spki.data(),588,der,sizeof der)&&atcs_hex_decode(sig.data(),512,signature,sizeof signature)
        &&atce_spki_rsa2048(der,sizeof der,out.modulus);
    if(ok){atcs_sha256(der,sizeof der,digest);atcs_hex_encode(digest,32,digestHex);ok=memcmp(digestHex,kid.data(),64)==0;}
    if(ok){const std::string message="XHH-RACKLINK-TRANSPORT-3\n"+kid+"\n"+spki+"\n";
        ok=atcs_verify_signature((const unsigned char*)message.data(),(unsigned)message.size(),signature)!=0;}
    if(!ok){out=XRB_Transport();diagnostic.reason=xrb_auth_reason("transport_key_invalid");return XRB_PROTOCOL;}
    out.valid=true;out.base=base;memcpy(out.kid,kid.data(),64);out.kid[64]=0;return XRB_OK;
}
/* Sealed authorize/renew (protocol v3). The login key and machine code only
   ever travel inside the envelope; the reply is sealed under a key derived
   from this request's K, so a stale or substituted reply cannot be opened.
   Unsealed replies come only from the envelope layer and carry no secrets;
   a stale transport key or undecryptable envelope refetches the key once. */
static int xrb_authorize_http(const std::wstring& base,const std::string& body,bool renew,std::string& token,XRB_AuthDiagnostic& diagnostic) {
    diagnostic=XRB_AuthDiagnostic();diagnostic.stage=XRB_AUTH_HTTP;diagnostic.reason=xrb_auth_reason("transport_failed");
    const ULONGLONG deadline=GetTickCount64()+8000;
    const char* path=renew?"/racklink/v3/renew":"/racklink/v3/authorize";const wchar_t* wpath=renew?L"/racklink/v3/renew":L"/racklink/v3/authorize";
    for(int attempt=0;attempt<2;attempt++){
        XRB_Transport transport;{XRB_Guard lock;transport=xrb_transport;}
        if(!transport.valid||transport.base!=base){int r=xrb_transport_fetch(base,deadline,transport,diagnostic);if(r!=XRB_OK)return r;XRB_Guard lock;xrb_transport=transport;}
        unsigned char key[32],iv[12],seed[32],ek[256],tag[16];char ivHex[25];
        if(!atcs_random(key,sizeof key)||!atcs_random(iv,sizeof iv)||!atcs_random(seed,sizeof seed)){atcs_wipe(key,sizeof key);atcs_wipe(seed,sizeof seed);return XRB_CONFIGURATION;}
        atcs_hex_encode(iv,12,ivHex);
        const std::string aad=std::string("XHH-RACKLINK-REQ-3\n")+path+"\n"+transport.kid;
        std::string box(body.size()+16,'\0');
        atce_gcm_seal(key,iv,(const unsigned char*)aad.data(),aad.size(),(const unsigned char*)body.data(),body.size(),(unsigned char*)&box[0],tag);
        memcpy(&box[body.size()],tag,16);
        const int sealed=atce_oaep_encrypt(transport.modulus,key,sizeof key,seed,ek);atcs_wipe(seed,sizeof seed);
        if(!sealed){atcs_wipe(key,sizeof key);xrb_wipe_string(box);{XRB_Guard lock;xrb_transport.valid=false;}diagnostic.reason=xrb_auth_reason("transport_key_invalid");return XRB_PROTOCOL;}
        std::string outer=std::string("{\"v\":3,\"kid\":\"")+transport.kid+"\",\"ek\":\""+atce_b64url(ek,sizeof ek)+"\",\"iv\":\""+ivHex+"\",\"box\":\""+atce_b64url((const unsigned char*)box.data(),box.size())+"\"}";
        xrb_wipe_string(box);
        unsigned status=0;std::string response;
        int r=xrb_http_post(base,wpath,outer,deadline,status,response);diagnostic.http=status;
        if(r!=XRB_OK){atcs_wipe(key,sizeof key);if(r==XRB_PROTOCOL)diagnostic.reason=xrb_auth_reason("invalid_response");return r;}
        std::map<std::string,std::string> fields;xrb_json::Parser parser(response);
        if(!parser.object(fields)){atcs_wipe(key,sizeof key);xrb_wipe_string(response);diagnostic.reason=xrb_auth_reason("invalid_response");return XRB_PROTOCOL;}
        if(parser.types.count("box")||parser.types.count("iv")){
            static const char info[]="XHH-RACKLINK-RESP-3";
            unsigned char rkey[32],riv[12],raw[8192];
            atce_hkdf_sha256(key,sizeof key,NULL,0,(const unsigned char*)info,sizeof info-1,rkey,sizeof rkey);atcs_wipe(key,sizeof key);
            const std::string ivText=fields["iv"],boxText=fields["box"];const bool shaped=parser.types["v"]=='3'&&parser.types["box"]=='"'&&parser.types["iv"]=='"';
            xrb_wipe_fields(fields);xrb_wipe_string(response);
            const int n=shaped&&xrb_lower_hex(ivText,24)&&atcs_hex_decode(ivText.data(),24,riv,sizeof riv)&&!boxText.empty()
                ?atcs_b64_decode(boxText.data(),(unsigned)boxText.size(),raw,sizeof raw):-1;
            const std::string raad=std::string("XHH-RACKLINK-RESP-3\n")+path+"\n"+transport.kid+"\n"+ivHex;
            std::string inner;bool opened=false;
            if(n>=16){inner.assign((size_t)n-16,'\0');opened=atce_gcm_open(rkey,riv,(const unsigned char*)raad.data(),raad.size(),raw,(size_t)n-16,raw+n-16,inner.empty()?raw:(unsigned char*)&inner[0])!=0;}
            atcs_wipe(rkey,sizeof rkey);if(n>0)atcs_wipe(raw,(size_t)n);
            if(!opened){xrb_wipe_string(inner);diagnostic.reason=xrb_auth_reason("invalid_response");return XRB_PROTOCOL;}
            return xrb_authorize_response(status,inner,token,diagnostic);
        }
        atcs_wipe(key,sizeof key);
        std::string error=parser.types["error"]=='"'?fields["error"]:"";xrb_wipe_fields(fields);
        if(attempt==0&&(error=="transport_key_changed"||error=="invalid_envelope")){xrb_wipe_string(error);xrb_wipe_string(response);XRB_Guard lock;xrb_transport.valid=false;continue;}
        xrb_wipe_string(error);
        return xrb_authorize_response(status,response,token,diagnostic);
    }
    diagnostic.reason=xrb_auth_reason("transport_key_changed");return XRB_NETWORK;
}
/* Exponential backoff 1,2,4,8,16,30 s with +/-25 % jitter, so clients that
   failed together (for example during a server restart) spread their retries. */
static ULONGLONG xrb_backoff(unsigned failures){ULONGLONG base=failures>5?30000ULL:1000ULL<<(failures?failures-1:0);unsigned short r=32768;if(!atcs_random((unsigned char*)&r,sizeof r))r=32768;return base*3/4+(base/2)*r/65536;}
struct XRB_WorkerContext {unsigned epoch;HMODULE reference;};
static DWORD WINAPI xrb_auth_worker(LPVOID argument) {
    XRB_WorkerContext context=*(XRB_WorkerContext*)argument;HeapFree(GetProcessHeap(),0,argument);
    const unsigned epoch=context.epoch;
    unsigned failures=0;
    while(InterlockedCompareExchange(&xrb.running,0,0)) {
        std::wstring base,account,credential,legacy;std::string previous;unsigned soft=3;uint64_t revision=0;char device[65];bool work=false;
        {XRB_Guard lock;if(epoch!=xrb.workerEpoch)break;work=xrb.enabled&&xrb.configured&&xrb.productReady&&xrb.legacyReady&&!xrb.legacy.empty()&&ATCS_PUBLIC_KEY_CONFIGURED&&GetTickCount64()>=xrb.nextAuth;if(work){base=xrb.base;account=xrb.account;credential=xrb.credential;legacy=xrb.legacy;soft=xrb.soft;if(xrb.lease.expires>atcs_now())previous=xrb.token;revision=xrb.revision;memcpy(device,xrb.device,65);}}
        if(!work){WaitForSingleObject(xrb.wake,500);continue;}
        unsigned char nonce[16];char hex[33];int error=XRB_CONFIGURATION;std::string token;XRB_AuthDiagnostic diagnostic;diagnostic.stage=XRB_AUTH_HTTP;diagnostic.reason=xrb_auth_reason("transport_failed");
        if(xrb_consent()&&atcs_random(nonce,sizeof nonce)) {
            atcs_hex_encode(nonce,16,hex);char numeric[192];snprintf(numeric,sizeof numeric,",\"parent\":%lu,\"controller_version\":%u,\"agent_build\":%u,\"soft\":%u,\"client_now\":%llu",(unsigned long)GetCurrentProcessId(),ATC_CONTROLLER_VERSION,XRB_AGENT_BUILD,soft,(unsigned long long)atcs_now());
            std::string body="{\"license_id\":"+xrb_json::quote(xrb_utf8(account))+",\"credential\":"+xrb_json::quote(xrb_utf8(credential))+",\"device\":"+xrb_json::quote(device)+",\"nonce\":"+xrb_json::quote(hex)+numeric+",\"legacy_machine_code\":"+xrb_json::quote(xrb_utf8(legacy));
            if(!previous.empty())body+=",\"token\":"+xrb_json::quote(previous);body+='}';
            error=xrb_authorize_http(base,body,!previous.empty(),token,diagnostic);xrb_wipe_string(body);
        }
        ATCS_Claims verified;memset(&verified,0,sizeof verified);
        if(error==XRB_OK){diagnostic.stage=XRB_AUTH_VERIFY;if(!atcs_verify_token(token.data(),(unsigned)token.size(),GetCurrentProcessId(),device,&verified)){error=XRB_DENIED;diagnostic.reason=xrb_auth_reason("token_validation_failed");}}
        {XRB_Guard lock;if(xrb.running&&epoch==xrb.workerEpoch&&xrb.enabled&&xrb.revision==revision){if(error==XRB_OK){
                const uint64_t now=atcs_now();
                if(verified.expires<=now){error=XRB_EXPIRED;diagnostic.reason=xrb_auth_reason("lease_expired");}
                else if(xrb.lease.expires&&!memcmp(verified.sid,xrb.lease.sid,sizeof verified.sid)&&(verified.issued<xrb.lease.issued||(verified.issued==xrb.lease.issued&&!atcs_claims_equal(&verified,&xrb.lease)))){error=XRB_DENIED;diagnostic.reason=xrb_auth_reason("lease_rollback");}
                else{xrb_wipe_string(xrb.pending);xrb.pending=token;failures=0;xrb_error(XRB_CONNECTING);
                    /* The service permits 30-second leases. Renew before the
                       verified expiry, rather than always waiting 30 seconds. */
                    const uint64_t remaining=verified.expires-now;
                    const uint64_t delay=remaining>10?((remaining-10)>30?30000:(remaining-10)*1000):1000;
                    xrb.nextAuth=GetTickCount64()+delay;
                }}
            xrb.authDiagnostic=diagnostic;
            if(error!=XRB_OK){failures++;xrb_error(error);xrb.haveLease=false;xrb.needReplay=true;xrb.status=(xrb.status|0x40000000UL)&~63UL;xrb.feel=0x80000000UL;xrb_wipe_string(xrb.pending);xrb_wipe_string(xrb.token);xrb.nextAuth=GetTickCount64()+xrb_backoff(failures);}
        }}
        atcs_wipe(&verified,sizeof verified);xrb_wipe_string(previous);xrb_wipe_string(token);if(!credential.empty())atcs_wipe(&credential[0],credential.size()*sizeof(wchar_t));
        WaitForSingleObject(xrb.wake,100);
    }
    /* The worker owns a loader reference. Even a host unloading after STOP
       cannot free its code while a bounded HTTP(S) operation is unwinding. */
    FreeLibraryAndExitThread(context.reference,0);return 0;
}
static LRESULT CALLBACK xrb_window_proc(HWND h,UINT m,WPARAM w,LPARAM l){return DefWindowProcW(h,m,w,l);}
static HWND xrb_sender(){if(xrb.sender&&IsWindow(xrb.sender))return xrb.sender;WNDCLASSW wc;memset(&wc,0,sizeof wc);wc.lpfnWndProc=xrb_window_proc;wc.hInstance=xrb_module;wc.lpszClassName=L"XhhRackBridgeV2";RegisterClassW(&wc);xrb.sender=CreateWindowExW(0,wc.lpszClassName,L"",0,0,0,0,0,HWND_MESSAGE,NULL,xrb_module,NULL);return xrb.sender;}
static BOOL CALLBACK xrb_find_window(HWND h,LPARAM p){DWORD pid=0;GetWindowThreadProcessId(h,&pid);if(pid==xrb.childPid){char name[32]={0};GetClassNameA(h,name,sizeof name);if(!strcmp(name,"AT8Ctl")){*(HWND*)p=h;return FALSE;}}return TRUE;}
static bool xrb_send(unsigned op,const char* payload,bool authenticated,uint32_t* result) {
    if(!xrb.controller||!IsWindow(xrb.controller)||!xrb_sender())return false;
    unsigned len=payload?(unsigned)strlen(payload):0;if(len>ATC_MAX_PAYLOAD)return false;
    unsigned char packet[ATC_HEADER_SIZE+ATC_MAX_PAYLOAD];memset(packet,0,ATC_HEADER_SIZE);memcpy(packet,"XAKS",4);
    packet[4]=(unsigned char)ATC_PROTOCOL_VERSION;packet[6]=ATC_HEADER_SIZE;packet[8]=(unsigned char)op;
    for(unsigned i=0;i<4;i++)packet[12+i]=(unsigned char)(len>>(i*8));uint64_t seq=++xrb.sequence;if(!seq)return false;
    for(unsigned i=0;i<8;i++)packet[16+i]=(unsigned char)(seq>>(i*8));if(len)memcpy(packet+ATC_HEADER_SIZE,payload,len);
    if(authenticated){unsigned char input[24+ATC_MAX_PAYLOAD];memcpy(input,packet,24);if(len)memcpy(input+24,payload,len);atc_hmac_sha256(xrb.lease.key,32,input,24+len,packet+24);atcs_wipe(input,sizeof input);}
    COPYDATASTRUCT cds;cds.dwData=ATC_COPYDATA_ID;cds.cbData=ATC_HEADER_SIZE+len;cds.lpData=packet;DWORD_PTR reply=0;
    LRESULT ok=SendMessageTimeoutW(xrb.controller,WM_COPYDATA,(WPARAM)xrb.sender,(LPARAM)&cds,SMTO_ABORTIFHUNG|SMTO_BLOCK,ATC_SEND_TIMEOUT_MS,&reply);atcs_wipe(packet,sizeof packet);
    if(!ok){xrb_error(XRB_STALLED);return false;}if(result)*result=(uint32_t)reply;return true;
}
/* Controllers were named 机架联动内部组件(32).exe before the English rename and
   xhh_rack_controller(32).exe before the keyscale_ prefix. Remove only those four exact
   names in this directory, never directories or reparse points; a copy still running
   (in use) stays until a later launch. */
/* The controller and the files it extracts (injectors, agents) and writes (protocol files, log) live in a
   subfolder of the runtime dir -- keyscale_rack -- so they never mix with, and can never be cleaned by
   name-pattern next to, the main program's own files. The bridge DLL itself stays in the runtime dir
   (the main program loads it from there). The controller is told this folder by env var and cwd. */
static std::wstring xrb_child_dir(){return xrb.directory+L"\\keyscale_rack";}
static void xrb_delete_plain_file(const std::wstring& p){DWORD a=GetFileAttributesW(p.c_str());if(a!=INVALID_FILE_ATTRIBUTES&&!(a&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT)))DeleteFileW(p.c_str());}
static void xrb_remove_legacy_controllers(){
    /* Older pre-rename controllers, plus the 32-bit controller a previous build staged for a genuine 32-bit OS --
       rack-link ships only the 64-bit controller now, so clear any 32-bit one left behind. In the child dir: */
    static const wchar_t* legacy[]={L"\\机架联动内部组件.exe",L"\\机架联动内部组件32.exe",L"\\xhh_rack_controller.exe",L"\\xhh_rack_controller32.exe",L"\\keyscale_rack_controller32.exe"};
    std::wstring dir=xrb_child_dir();for(const wchar_t* name:legacy)xrb_delete_plain_file(dir+name);
    /* The previous layout put the current-name controllers in the runtime dir ROOT; they live in the child dir
       now, so clear the root copies once (never the bridge DLL, which stays in the root). */
    xrb_delete_plain_file(xrb.directory+L"\\keyscale_rack_controller.exe");
    xrb_delete_plain_file(xrb.directory+L"\\keyscale_rack_controller32.exe");
}
static HANDLE xrb_extract_locked(bool win64,std::wstring& path) {
    (void)win64;   /* only the 64-bit controller ships now; xrb_launch refuses a genuine 32-bit OS before reaching here */
    HRSRC resource=FindResourceA(xrb_module,"CONTROLLER64",RT_RCDATA);if(!resource)return INVALID_HANDLE_VALUE;
    const unsigned char* data=(const unsigned char*)LockResource(LoadResource(xrb_module,resource));DWORD bytes=SizeofResource(xrb_module,resource);if(!data||!bytes)return INVALID_HANDLE_VALUE;
    std::wstring dir=xrb_child_dir();
    CreateDirectoryW(xrb.directory.c_str(),NULL);   /* the runtime dir normally exists (the bridge was loaded from it); ignore the result and check the child dir below */
    if(!CreateDirectoryW(dir.c_str(),NULL)&&GetLastError()!=ERROR_ALREADY_EXISTS)return INVALID_HANDLE_VALUE;
    DWORD attributes=GetFileAttributesW(dir.c_str());if(attributes==INVALID_FILE_ATTRIBUTES||(attributes&FILE_ATTRIBUTE_REPARSE_POINT))return INVALID_HANDLE_VALUE;
    path=dir+L"\\keyscale_rack_controller.exe";
    HANDLE f=CreateFileW(path.c_str(),GENERIC_READ|GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if(f!=INVALID_HANDLE_VALUE){DWORD wrote=0;BOOL ok=WriteFile(f,data,bytes,&wrote,NULL);FlushFileBuffers(f);CloseHandle(f);if(!ok||wrote!=bytes)return INVALID_HANDLE_VALUE;}
    f=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_FLAG_SEQUENTIAL_SCAN,NULL);if(f==INVALID_HANDLE_VALUE)return f;
    LARGE_INTEGER size;if(!GetFileSizeEx(f,&size)||size.QuadPart!=bytes){CloseHandle(f);return INVALID_HANDLE_VALUE;}
    unsigned char buffer[65536];DWORD offset=0;while(offset<bytes){DWORD take=bytes-offset;if(take>sizeof buffer)take=sizeof buffer;DWORD got=0;if(!ReadFile(f,buffer,take,&got,NULL)||got!=take||memcmp(buffer,data+offset,take)){CloseHandle(f);return INVALID_HANDLE_VALUE;}offset+=take;}
    xrb_remove_legacy_controllers();
    return f; /* caller retains deny-write/deny-delete handle through CreateProcess */
}
/* Agents retain replay counters for the same lease; only strictly newer
   issued claims reset them. Remember possible delivery, including timeout. */
static void xrb_child_finished(){if(xrb.childLeasePossible&&xrb.haveLease&&xrb.lease.issued<=xrb.childLeaseIssued){xrb.nextAuth=0;if(xrb.wake)SetEvent(xrb.wake);}xrb.pauseRevision=0;xrb.childLeaseIssued=0;xrb.childLeasePossible=false;xrb.childRetiring=false;xrb.childRetireDeadline=0;}
static bool xrb_child_retiring(){if(!xrb.childRetiring)return false;if(GetTickCount64()>=xrb.childRetireDeadline){xrb_auth_diagnostic(XRB_AUTH_CONTROLLER,"transport_failed");xrb_error(XRB_STALLED);}else xrb_error(XRB_CONNECTING);return true;}
static bool xrb_launch() {
    if(xrb.child){if(WaitForSingleObject(xrb.child,0)==WAIT_TIMEOUT){if(xrb_child_retiring())return false;if(!xrb.controller)EnumWindows(xrb_find_window,(LPARAM)&xrb.controller);return xrb.controller!=NULL;}DWORD code=0;GetExitCodeProcess(xrb.child,&code);xrb_child_finished();CloseHandle(xrb.child);xrb.child=NULL;xrb.childPid=0;xrb.controller=NULL;xrb.needReplay=true;xrb.installedRevision=0;if(code==22)xrb_error(XRB_USER);}
    if(GetTickCount64()-xrb.lastLaunch<500)return false;xrb.lastLaunch=GetTickCount64();
    HWND existing=FindWindowA("AT8Ctl",NULL);if(existing){xrb_error(XRB_OLD_CONTROLLER);return false;}
    /* Rack-link now ships only the 64-bit controller. On any 64-bit Windows a 32-bit host runs under WOW64, so the
       64-bit controller is what gets used there anyway (and the 32-bit injector still handles 32-bit targets); only
       a genuine 32-bit Windows OS -- a 32-bit process that is NOT under WOW64 -- would have needed a 32-bit
       controller, and those are effectively gone in this era (Windows 11 has no 32-bit edition). Dropping the
       32-bit controller removes the one file an antivirus kept flagging. On a real 32-bit OS, say so plainly
       instead of failing silently. */
    BOOL wow=FALSE;IsWow64Process(GetCurrentProcess(),&wow);bool win64=sizeof(void*)==8||wow;
    if(!win64){xrb_error(XRB_OS);return false;}
    std::wstring path;HANDLE pin=xrb_extract_locked(win64,path);
    if(pin==INVALID_HANDLE_VALUE){xrb_error(XRB_FILES);return false;}
    wchar_t pid[32];swprintf(pid,32,L"%lu",(unsigned long)GetCurrentProcessId());std::wstring command=L"\""+path+L"\" --companion "+pid;
    STARTUPINFOW si;PROCESS_INFORMATION pi;memset(&si,0,sizeof si);memset(&pi,0,sizeof pi);si.cb=sizeof si;
    std::vector<wchar_t> environment=xrb_environment();BOOL ok=CreateProcessW(path.c_str(),&command[0],NULL,NULL,FALSE,CREATE_NO_WINDOW|CREATE_UNICODE_ENVIRONMENT,&environment[0],xrb.directory.c_str(),&si,&pi);CloseHandle(pin);
    if(!ok){xrb_error(XRB_FILES);return false;}CloseHandle(pi.hThread);xrb.child=pi.hProcess;xrb.childPid=pi.dwProcessId;xrb.controller=NULL;xrb_error(XRB_CONNECTING);return false;
}
static bool xrb_apply(bool feelOnly) {
    if(xrb.paused||xrb.pauseHandshake)return false;
    if(!xrb.haveLease)return false;if(GetTickCount64()>=xrb.deadline||atcs_now()>=xrb.lease.expires){xrb_auth_diagnostic(XRB_AUTH_VERIFY,"lease_expired");xrb_error(XRB_EXPIRED);return false;}if(!xrb.controller){xrb_error(XRB_CONNECTING);return false;}
    char text[128];if(feelOnly){if(xrb.strength<0)return false;snprintf(text,sizeof text,"retune=%d.%03d",xrb.strength/1000,xrb.strength%1000);}
    else{if(xrb.key<0||xrb.key>11||xrb.scale<0||xrb.scale>2)return false;static const char* scales[]={"Major","Minor","Chromatic"};snprintf(text,sizeof text,"key=%d;scale=%s",xrb.key,scales[xrb.scale]);if(xrb.strength>=0){size_t n=strlen(text);snprintf(text+n,sizeof text-n,";retune=%d.%03d",xrb.strength/1000,xrb.strength%1000);}}
    uint32_t result=0;bool sent=xrb_send(feelOnly?ATC_FEEL:ATC_APPLY,text,true,&result);bool ok=sent&&result==ATC_REPLY_OK;if(ok){if(!feelOnly)xrb.needReplay=false;}else if(sent)xrb_error(result==ATC_REPLY_AUTH_REQUIRED?XRB_CONNECTING:XRB_PROTOCOL);return ok;
}
static void xrb_deactivate(bool unload) {
    uint32_t reply=0;if(xrb.controller&&xrb.lease.expires>atcs_now()){if(unload)xrb_send(ATC_EJECT,"",true,&reply);if(xrb.child&&!xrb.childRetiring){xrb.childRetiring=true;xrb.childRetireDeadline=GetTickCount64()+2000;}xrb_send(ATC_QUIT,"",true,&reply);}
    xrb.haveLease=false;xrb.pauseRevision=0;xrb.status=0xc0000000UL;xrb.feel=0x80000000UL;xrb.installedRevision=0;xrb.controller=NULL;xrb.needReplay=true;
}
static int xrb_tick() {
    XRB_Guard lock;if(!xrb.configured)return 0;if(!xrb_consent()){xrb.enabled=0;xrb_deactivate(true);xrb_error(XRB_DISABLED);return 0;}
    if(!xrb.enabled){xrb_error(XRB_DISABLED);return 0;}
    if(!ATCS_PUBLIC_KEY_CONFIGURED){xrb_error(XRB_CONFIGURATION);return 0;}
    if(!xrb.haveLease&&xrb.lease.expires&&xrb.installedRevision){xrb_deactivate(false);}
    if(!xrb.pending.empty()){
        ATCS_Claims next;memset(&next,0,sizeof next);if(!atcs_verify_token(xrb.pending.data(),(unsigned)xrb.pending.size(),GetCurrentProcessId(),xrb.device,&next)){xrb_auth_diagnostic(XRB_AUTH_VERIFY,"token_validation_failed");xrb_error(XRB_DENIED);xrb_wipe_string(xrb.pending);return 0;}
        bool replacingLostLease=!xrb.haveLease;
        xrb_wipe_string(xrb.token);xrb.token.swap(xrb.pending);xrb_wipe_string(xrb.pending);xrb.lease=next;xrb.haveLease=true;xrb.revision++;xrb.deadline=GetTickCount64()+(next.expires-atcs_now())*1000;xrb.needReplay=xrb.needReplay||replacingLostLease;atcs_wipe(&next,sizeof next);
    }
    if(!xrb.haveLease)return 0;if(atcs_now()>=xrb.lease.expires||GetTickCount64()>=xrb.deadline){xrb_deactivate(false);xrb_auth_diagnostic(XRB_AUTH_VERIFY,"lease_expired");xrb_error(XRB_EXPIRED);return 0;}
    if(!xrb_launch())return 0;
    if(xrb.installedRevision!=xrb.revision){uint32_t hello=0;if(!xrb_send(ATC_HELLO,"",false,&hello)||hello!=((ATC_PROTOCOL_VERSION<<16)|ATC_CONTROLLER_VERSION)){xrb_error(XRB_OLD_CONTROLLER);return 0;}
        if(!xrb.childLeasePossible||xrb.lease.issued>xrb.childLeaseIssued)xrb.childLeaseIssued=xrb.lease.issued;xrb.childLeasePossible=true;
        uint32_t reply=0;if(!xrb_send(ATC_AUTHORIZE,xrb.token.c_str(),false,&reply)){xrb_auth_diagnostic(XRB_AUTH_CONTROLLER,"transport_failed");xrb_error(XRB_STALLED);return 0;}if(reply!=ATC_REPLY_OK){xrb_auth_diagnostic(XRB_AUTH_CONTROLLER,"controller_rejected");xrb_error(XRB_DENIED);return 0;}xrb.installedRevision=xrb.revision;}
    if(xrb.paused||xrb.pauseHandshake){uint32_t pause=0;if(xrb.pauseRevision!=xrb.installedRevision){if(!xrb_send(ATC_PAUSE,"",true,&pause))return 0;if(pause!=ATC_REPLY_OK){xrb_error(pause==ATC_REPLY_AUTH_REQUIRED?XRB_CONNECTING:XRB_PROTOCOL);return 0;}xrb.pauseRevision=xrb.installedRevision;}
        if(!xrb_send(ATC_STATUS,"paused",false,&pause)||!(pause&0x80000000UL)){xrb_error(XRB_PROTOCOL);return 0;}if(pause&0x40000000UL){xrb_error(XRB_CONNECTING);return 0;}xrb.pauseHandshake=false;}
    char expected[32]={0};if(!xrb.paused&&xrb.key>=0&&xrb.scale>=0)snprintf(expected,sizeof expected,"expect=%d:%d",xrb.key,xrb.scale);
    uint32_t status=0;if(!xrb_send(ATC_STATUS,expected,false,&status)||!(status&0x80000000UL)){xrb_error(XRB_PROTOCOL);return 0;}xrb.status=status;
    if(status&0x40000000UL){xrb_error(XRB_CONNECTING);return 0;}
    uint32_t errors=0;if(!xrb_send(ATC_STATUS,"errors",false,&errors)||!(errors&0x80000000UL)){xrb_error(XRB_PROTOCOL);return 0;}if(errors&32){xrb_error(XRB_USER);return 0;}
    if(!xrb.paused&&xrb.needReplay&&xrb.key>=0&&!xrb_apply(false))return 0;
    uint32_t feel=0;if(!xrb_send(ATC_STATUS,"feel",false,&feel)){xrb.feel=0x80000000UL;return 0;}if(!(feel&0x80000000UL)){xrb.feel=0x80000000UL;xrb_error(XRB_PROTOCOL);return 0;}xrb.feel=0x80000000UL|((feel&0x20000000UL)?0x40000000UL:0)|((feel&0x10000000UL)?0x20000000UL:0)|(feel&0x3ff);
    xrb_auth_diagnostic(XRB_AUTH_READY,"none");xrb_error(XRB_OK);return 1;
}
/* Metadata setters retain the ABI, but stale authorization cannot survive a
   changed product/machine binding. Called only while holding xrb_lock. */
static void xrb_metadata_changed(){xrb.revision++;xrb_deactivate(false);xrb_wipe_string(xrb.pending);xrb_wipe_string(xrb.token);atcs_wipe(&xrb.lease,sizeof xrb.lease);xrb.nextAuth=0;xrb.authDiagnostic=XRB_AuthDiagnostic();xrb_auth_diagnostic(XRB_AUTH_METADATA,"metadata_missing");if(xrb.enabled)xrb_error(XRB_CONNECTING);if(xrb.wake)SetEvent(xrb.wake);}
static void xrb_metadata_ready(bool wasReady){if(!wasReady&&xrb.configured&&xrb.productReady&&xrb.legacyReady&&!xrb.legacy.empty()){xrb.nextAuth=0;if(xrb.wake)SetEvent(xrb.wake);}}
static int xrb_configure(uintptr_t dir,uintptr_t base,uintptr_t account,uintptr_t credential) {
    if(!xrb_consent()){xrb_error(XRB_DISABLED);return 0;}if(!xrb_os()){xrb_error(XRB_OS);return 0;}if(!xrb_elevated()){xrb_error(XRB_USER);return 0;}
    std::wstring d=xrb_copy_w(dir,4096),b=xrb_copy_w(base,2048),a=xrb_copy_w(account,256),c=xrb_copy_w(credential,1024);
    if(d.empty()||a.empty()||c.empty()||!xrb_base_valid(b)){xrb_error(XRB_CONFIGURATION);return 0;}
    XRB_Guard lock;if(xrb.configured){xrb_metadata_changed();if(!xrb.credential.empty())atcs_wipe(&xrb.credential[0],xrb.credential.size()*sizeof(wchar_t));xrb.directory=d;xrb.base=b;xrb.account=a;xrb.credential=c;xrb.legacy.clear();xrb.productReady=xrb.legacyReady=false;xrb.enabled=1;xrb_error(ATCS_PUBLIC_KEY_CONFIGURED?XRB_CONNECTING:XRB_CONFIGURATION);if(xrb.wake)SetEvent(xrb.wake);return 1;}
    /* Finish an old bounded HTTP(S) request before creating another worker: a
       discarded old authorize response can still revoke a newer server lease. */
    if(xrb.worker&&WaitForSingleObject(xrb.worker,0)==WAIT_TIMEOUT){xrb_error(XRB_CONNECTING);return 0;}
    HMODULE pinned=NULL;if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)&xrb_auth_worker,&pinned)){xrb_error(XRB_CONFIGURATION);return 0;}
    xrb.owner=CreateMutexW(NULL,FALSE,L"Local\\XHH_RackLink_owner_v2");if(!xrb.owner||GetLastError()==ERROR_ALREADY_EXISTS){if(xrb.owner)CloseHandle(xrb.owner);xrb.owner=NULL;xrb_error(XRB_OTHER_OWNER);return 0;}
    if(!atcs_device_fingerprint(xrb.device)){CloseHandle(xrb.owner);xrb.owner=NULL;xrb_error(XRB_USER);return 0;}
    xrb.directory=d;xrb.base=b;xrb.account=a;xrb.credential=c;xrb.legacy.clear();xrb.productReady=xrb.legacyReady=false;xrb.authDiagnostic=XRB_AuthDiagnostic();xrb_auth_diagnostic(XRB_AUTH_METADATA,"metadata_missing");xrb.configured=true;xrb.enabled=1;xrb.running=1;xrb.revision++;xrb.workerEpoch++;
    if(!xrb.wake)xrb.wake=CreateEventW(NULL,FALSE,FALSE,NULL);if(!xrb.wake){xrb.configured=false;xrb.running=0;CloseHandle(xrb.owner);xrb.owner=NULL;return 0;}
    if(xrb.worker)CloseHandle(xrb.worker);
    XRB_WorkerContext* context=(XRB_WorkerContext*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(XRB_WorkerContext));HMODULE reference=NULL;
    if(!context||!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,(LPCWSTR)&xrb_auth_worker,&reference)){if(context)HeapFree(GetProcessHeap(),0,context);xrb.running=0;xrb.configured=false;CloseHandle(xrb.owner);xrb.owner=NULL;return 0;}
    context->epoch=xrb.workerEpoch;context->reference=reference;
    xrb.worker=CreateThread(NULL,0,xrb_auth_worker,context,0,NULL);if(!xrb.worker){FreeLibrary(reference);HeapFree(GetProcessHeap(),0,context);xrb.running=0;xrb.configured=false;CloseHandle(xrb.owner);xrb.owner=NULL;return 0;}
    xrb_error(ATCS_PUBLIC_KEY_CONFIGURED?XRB_CONNECTING:XRB_CONFIGURATION);return 1;
}
extern "C" __declspec(dllexport) int WINAPI RackBridge_Command(unsigned op,uintptr_t a,uintptr_t b,uintptr_t c,uintptr_t d) {
    if(op==1)return xrb_configure(a,b,c,d);if(op==2)return xrb_tick();
    XRB_Guard lock;
    switch(op){
    case 3:if(xrb.paused)return 0;if(a>11||b>2||((intptr_t)c!=-1&&c>1000))return 0;xrb.key=(int)a;xrb.scale=(int)b;if((intptr_t)c>=0)xrb.strength=(int)c;xrb.status&=~63UL;xrb.needReplay=true;return xrb_apply(false)?1:0;
    case 4:if(xrb.paused)return 0;if(a>1000)return 0;xrb.strength=(int)a;return xrb_apply(true)?1:0;
    case 5:return (int)xrb.status;
    case 6:return 0; /* Removed visible controller UI; reserved ABI slot. */
    case 7:xrb.enabled=0;xrb.legacy.clear();xrb.productReady=xrb.legacyReady=false;xrb.authDiagnostic=XRB_AuthDiagnostic();xrb.revision++;xrb_deactivate(true);xrb.key=xrb.scale=xrb.strength=-1;xrb.needReplay=false;xrb_wipe_string(xrb.pending);xrb_wipe_string(xrb.token);xrb_error(XRB_DISABLED);return 1;
    case 8:xrb.enabled=0;xrb.legacy.clear();xrb.productReady=xrb.legacyReady=false;xrb.authDiagnostic=XRB_AuthDiagnostic();InterlockedExchange(&xrb.running,0);xrb.revision++;xrb.workerEpoch++;xrb_deactivate(false);xrb.key=xrb.scale=xrb.strength=-1;xrb.needReplay=false;xrb.configured=false;if(xrb.wake)SetEvent(xrb.wake);if(xrb.owner){CloseHandle(xrb.owner);xrb.owner=NULL;}xrb_wipe_string(xrb.pending);xrb_wipe_string(xrb.token);if(!xrb.credential.empty())atcs_wipe(&xrb.credential[0],xrb.credential.size()*sizeof(wchar_t));atcs_wipe(&xrb.lease,sizeof xrb.lease);xrb_error(XRB_DISABLED);return 1;
    case 9:if(xrb.paused)return 0;xrb.status&=~63UL;xrb.needReplay=true;return xrb_apply(false)?1:0;
    case 10:return (int)xrb.feel;
    case 11:{if(a<1||a>3)return 0;bool wasReady=xrb.productReady&&xrb.legacyReady;if(xrb.soft!=(unsigned)a)xrb_metadata_changed();xrb.soft=(unsigned)a;xrb.language=xrb_copy_w(b,32);xrb.productReady=true;xrb_metadata_ready(wasReady);return 1;}
    case 12:{wchar_t summary[256];xrb_auth_summary(summary,256);wchar_t* out=(wchar_t*)a;if(!out||b<2||b>32768)return 0;wchar_t text[768];swprintf(text,768,L"Rack link protocol=%u controller=%u agent=%u\r\nConfigured=%d consent=%d enabled=%ld public_key=%d error=%ld\r\nLease=%d captured=%u confirmed=%u pending=%u racks=%u\r\nDevice=%hs license=%hs\r\n%ls\r\n",ATC_PROTOCOL_VERSION,ATC_CONTROLLER_VERSION,XRB_AGENT_BUILD,xrb.configured?1:0,xrb_consent()?1:0,xrb.enabled,ATCS_PUBLIC_KEY_CONFIGURED,xrb.error,xrb.haveLease?1:0,(xrb.status>>12)&63,xrb.status&63,(xrb.status>>6)&63,(xrb.status>>18)&127,xrb.device,xrb.lease.license,summary);size_t n=wcslen(text);if(n>=b)n=(size_t)b-1;memcpy(out,text,n*sizeof(wchar_t));out[n]=0;return (int)n;}
    case 13:return (int)xrb.error;
    case 14:{bool wasReady=xrb.productReady&&xrb.legacyReady;std::wstring legacy=xrb_copy_w(a,1024);if(legacy!=xrb.legacy)xrb_metadata_changed();xrb.legacy=legacy;xrb.legacyReady=!legacy.empty();xrb_metadata_ready(wasReady);return xrb.legacyReady?1:0;}
    case 15:return xrb_auth_summary((wchar_t*)a,b);
    /* Pause automatic writes, not the authenticated transport. Clearing cached
       goals on both edges prevents a resume tick from replaying the old song. */
    case 16:if(a>1||!xrb.configured)return 0;if(xrb.paused!=(a!=0)){xrb.paused=a!=0;if(xrb.paused){xrb.pauseHandshake=true;xrb.pauseRevision=0;}xrb.key=xrb.scale=xrb.strength=-1;xrb.needReplay=false;xrb.status&=~63UL;}return 1;
    default:return 0;
    }
}
extern "C" __declspec(dllexport) int WINAPI XRB_Invoke(unsigned op,const uint32_t* args,unsigned count,unsigned flags) {
    if(flags||count!=4||!args)return 0;return RackBridge_Command(op,args[0],args[1],args[2],args[3]);
}
BOOL WINAPI DllMain(HINSTANCE instance,DWORD reason,LPVOID) {
    if(reason==DLL_PROCESS_ATTACH){xrb_module=instance;InitializeCriticalSection(&xrb_lock);DisableThreadLibraryCalls(instance);}
    if(reason==DLL_PROCESS_DETACH)InterlockedExchange(&xrb.running,0);
    return TRUE;
}
