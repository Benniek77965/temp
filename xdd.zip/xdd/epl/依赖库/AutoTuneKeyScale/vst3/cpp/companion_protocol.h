#ifndef AT_COMPANION_PROTOCOL_H
#define AT_COMPANION_PROTOCOL_H
/* xhh transport v3. No Windows dependency: tests compile these exact functions.
   This is a transport, NOT an authorization verifier. A valid MAC is never a
   substitute for a server-signed, device-bound, expiring authorization token. */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#define ATC_CONTROLLER_VERSION 5
#define ATC_PROTOCOL_VERSION 3
#define ATC_HEADER_SIZE 56
#define ATC_MAX_PAYLOAD 4096
#define ATC_COPYDATA_ID 0x534b4158UL
#define ATC_SEND_TIMEOUT_MS 300
#define ATC_HELLO 1
#define ATC_AUTHORIZE 2
#define ATC_APPLY 3
#define ATC_STATUS 4
#define ATC_EJECT 5
/* Operation 6 is retired; controllers have no visible UI. */
#define ATC_QUIT 7
#define ATC_FEEL 8
#define ATC_PAUSE 9
#define ATC_REPLY_OK 1
#define ATC_REPLY_BAD_PACKET 2
#define ATC_REPLY_WRONG_PARENT 3
#define ATC_REPLY_AUTH_REQUIRED 4
#define ATC_REPLY_AUTH_UNAVAILABLE 5
#define ATC_REPLY_BAD_MAC 6
#define ATC_REPLY_REPLAY 7
/* Status reply (32 bits): bit31=1, bit30=waiting for signed license,
   bit29=old agent, bit28=write failure, bit27=helper missing,
   bit26=access denied, bit25=overflow; racks[24:18], captured[17:12],
   uncaptured[11:6], confirmed[5:0]. Counts saturate at 63, racks at 127. */
typedef struct { unsigned op; uint64_t seq; const unsigned char* raw;
    const char* payload; unsigned payload_len; } ATC_Packet;
typedef struct { int key, scale, retune; } ATC_Apply;
typedef struct { uint32_t h[8]; uint64_t bytes; unsigned used; unsigned char block[64]; } ATC_SHA256;
static uint32_t atc_rotr(uint32_t x,unsigned n){return (x>>n)|(x<<(32-n));}
static void atc_sha_block(ATC_SHA256* s,const unsigned char* p){
    static const uint32_t k[64]={
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
    uint32_t w[64]; unsigned i;
    for(i=0;i<16;i++)w[i]=((uint32_t)p[i*4]<<24)|((uint32_t)p[i*4+1]<<16)|((uint32_t)p[i*4+2]<<8)|p[i*4+3];
    for(i=16;i<64;i++){uint32_t x=w[i-15],y=w[i-2];w[i]=w[i-16]+(atc_rotr(x,7)^atc_rotr(x,18)^(x>>3))+w[i-7]+(atc_rotr(y,17)^atc_rotr(y,19)^(y>>10));}
    uint32_t a=s->h[0],b=s->h[1],c=s->h[2],d=s->h[3],e=s->h[4],f=s->h[5],g=s->h[6],h=s->h[7];
    for(i=0;i<64;i++){uint32_t t=h+(atc_rotr(e,6)^atc_rotr(e,11)^atc_rotr(e,25))+((e&f)^((~e)&g))+k[i]+w[i];uint32_t u=(atc_rotr(a,2)^atc_rotr(a,13)^atc_rotr(a,22))+((a&b)^(a&c)^(b&c));h=g;g=f;f=e;e=d+t;d=c;c=b;b=a;a=t+u;}
    s->h[0]+=a;s->h[1]+=b;s->h[2]+=c;s->h[3]+=d;s->h[4]+=e;s->h[5]+=f;s->h[6]+=g;s->h[7]+=h;
}
static void atc_sha_init(ATC_SHA256* s){static const uint32_t iv[8]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};memcpy(s->h,iv,sizeof iv);s->bytes=0;s->used=0;}
static void atc_sha_update(ATC_SHA256* s,const void* data,size_t n){const unsigned char* p=(const unsigned char*)data;s->bytes+=n;while(n){size_t z=64-s->used;if(z>n)z=n;memcpy(s->block+s->used,p,z);s->used+=(unsigned)z;p+=z;n-=z;if(s->used==64){atc_sha_block(s,s->block);s->used=0;}}}
static void atc_sha_final(ATC_SHA256* s,unsigned char out[32]){uint64_t bits=s->bytes*8;unsigned char pad[128];unsigned n=(s->used<56)?56-s->used:120-s->used;memset(pad,0,sizeof pad);pad[0]=0x80;for(unsigned i=0;i<8;i++)pad[n+i]=(unsigned char)(bits>>(56-8*i));atc_sha_update(s,pad,n+8);for(unsigned i=0;i<8;i++)for(unsigned j=0;j<4;j++)out[i*4+j]=(unsigned char)(s->h[i]>>(24-j*8));}
static void atc_hmac_sha256(const void* key,size_t keylen,const void* data,size_t len,unsigned char out[32]){
    unsigned char kb[64],inner[32],pad[64];ATC_SHA256 s;memset(kb,0,64);
    if(keylen>64){atc_sha_init(&s);atc_sha_update(&s,key,keylen);atc_sha_final(&s,kb);}else if(keylen)memcpy(kb,key,keylen);
    for(unsigned i=0;i<64;i++)pad[i]=kb[i]^0x36;atc_sha_init(&s);atc_sha_update(&s,pad,64);atc_sha_update(&s,data,len);atc_sha_final(&s,inner);
    for(unsigned i=0;i<64;i++)pad[i]=kb[i]^0x5c;atc_sha_init(&s);atc_sha_update(&s,pad,64);atc_sha_update(&s,inner,32);atc_sha_final(&s,out);
    volatile unsigned char* v=kb;for(unsigned i=0;i<64;i++)v[i]=0;v=inner;for(unsigned i=0;i<32;i++)v[i]=0;v=pad;for(unsigned i=0;i<64;i++)v[i]=0;
}
static unsigned atc_u16(const unsigned char* p){return p[0]|((unsigned)p[1]<<8);}
static uint32_t atc_u32(const unsigned char* p){return p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static int atc_parse_packet(const void* data,unsigned n,ATC_Packet* out){
    if(!data||!out||n<ATC_HEADER_SIZE||n>ATC_HEADER_SIZE+ATC_MAX_PAYLOAD)return 0;const unsigned char* p=(const unsigned char*)data;
    if(memcmp(p,"XAKS",4)||atc_u16(p+4)!=ATC_PROTOCOL_VERSION||atc_u16(p+6)!=ATC_HEADER_SIZE||atc_u16(p+10))return 0;
    unsigned op=atc_u16(p+8),len=atc_u32(p+12);uint64_t seq=(uint64_t)atc_u32(p+16)|((uint64_t)atc_u32(p+20)<<32);
    if(op<ATC_HELLO||op>ATC_PAUSE||op==6||len>ATC_MAX_PAYLOAD||n!=ATC_HEADER_SIZE+len||!seq)return 0;
    for(unsigned i=0;i<len;i++)if(p[ATC_HEADER_SIZE+i]<0x20||p[ATC_HEADER_SIZE+i]>0x7e)return 0;
    out->op=op;out->seq=seq;out->raw=p;out->payload=(const char*)p+ATC_HEADER_SIZE;out->payload_len=len;return 1;
}
static int atc_verify_packet(const ATC_Packet* p,const unsigned char key[32]){if(!p||!key||!p->raw||p->payload_len>ATC_MAX_PAYLOAD)return 0;unsigned char b[24+ATC_MAX_PAYLOAD],mac[32];memcpy(b,p->raw,24);memcpy(b+24,p->payload,p->payload_len);atc_hmac_sha256(key,32,b,24+p->payload_len,mac);unsigned d=0;for(unsigned i=0;i<32;i++)d|=mac[i]^p->raw[24+i];return d==0;}
static int atc_accept_sequence(uint64_t received,uint64_t* last){if(!last||!received||received<=*last)return 0;*last=received;return 1;}
static int atc_decimal(const char* s,unsigned n,int maximum){if(!n)return -1;unsigned v=0;for(unsigned i=0;i<n;i++){if(s[i]<'0'||s[i]>'9'||v>(unsigned)maximum/10)return -1;v=v*10+s[i]-'0';if(v>(unsigned)maximum)return -1;}return (int)v;}
static int atc_fraction(const char* s,unsigned n){if(!n||(s[0]!='0'&&s[0]!='1'))return -1;int value=(s[0]-'0')*1000;if(n==1)return value;if(n<3||n>5||s[1]!='.')return -1;int place=100;for(unsigned i=2;i<n;i++,place/=10){if(s[i]<'0'||s[i]>'9'||(value>=1000&&s[i]!='0'))return -1;value+=(s[i]-'0')*place;}return value<=1000?value:-1;}
static int atc_parse_apply(const char* payload,unsigned len,int feel,ATC_Apply* out){
    if(!payload||!out||!len||len>ATC_MAX_PAYLOAD)return 0;ATC_Apply a={-1,-1,-1};unsigned seen=0,start=0;
    while(start<len){unsigned end=start;while(end<len&&payload[end]!=';')end++;unsigned n=end-start;const char* p=payload+start;unsigned bit=0;
        if(n>4&&!memcmp(p,"key=",4)){bit=1;a.key=atc_decimal(p+4,n-4,11);if(a.key<0)return 0;}
        else if(n>6&&!memcmp(p,"scale=",6)){bit=2;if(n==11&&!memcmp(p+6,"Major",5))a.scale=0;else if(n==11&&!memcmp(p+6,"Minor",5))a.scale=1;else if(n==15&&!memcmp(p+6,"Chromatic",9))a.scale=2;else return 0;}
        else if(n>7&&!memcmp(p,"retune=",7)){bit=4;a.retune=atc_fraction(p+7,n-7);if(a.retune<0)return 0;}
        else return 0;
        if(seen&bit)return 0;seen|=bit;if(end==len)break;start=end+1;if(start==len)return 0;
    }
    if(feel?seen!=4:((seen&3)!=3))return 0;*out=a;return 1;
}
static int atc_retune(int strength,int family){if(strength<0||strength>1000||family<0||family>2)return -1;return family==0?1000-strength:strength;}
static int atc_space(char c){return c==' '||c=='\t';}
static int atc_startup(const char* text,unsigned long* parent){
    if(parent)*parent=0;if(!text)return 0;while(atc_space(*text))text++;
    if(strncmp(text,"--companion",11)||!atc_space(text[11]))return 0;text+=11;while(atc_space(*text))text++;
    if(*text<'1'||*text>'9')return 0;uint64_t pid=0;while(*text>='0'&&*text<='9'){pid=pid*10+*text++-'0';if(pid>0xffffffffULL)return 0;}while(atc_space(*text))text++;if(*text)return 0;if(parent)*parent=(unsigned long)pid;return 1;
}
static const char* atc_status_field(const char* line,const char* name){
    const char* p=line;while((p=strstr(p,name))!=NULL){if(p==line||p[-1]==' '||p[-1]=='|')return p;p++;}return NULL;
}
static int atc_confirmed(int key,int scale,const char* line){
    static const int major[12]={8,3,10,5,12,7,2,9,4,11,6,1};static const int minor[12]={5,12,7,2,9,4,11,6,1,8,3,10};
    if(key<0||key>11||scale<0||scale>2||!line)return 0;
    if(scale==2){const char* p=atc_status_field(line,"Scale=Chromatic");return p&&(p[15]==0||p[15]==' '||p[15]=='\r'||p[15]=='\n'||p[15]=='\x01');}
    const char* p=atc_status_field(line,"Camelot=");if(!p)return 0;p+=8;int n=0;unsigned digits=0;while(*p>='0'&&*p<='9'&&digits<2){n=n*10+*p++-'0';digits++;}if(!digits||n!=(scale?minor[key]:major[key])||*p!=(scale?'A':'B'))return 0;p++;return !*p||*p==' '||*p=='\r'||*p=='\n'||*p=='\x01';
}
#endif
