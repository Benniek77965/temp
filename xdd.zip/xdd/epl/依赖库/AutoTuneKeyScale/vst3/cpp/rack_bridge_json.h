#ifndef XHH_RACK_BRIDGE_JSON_H
#define XHH_RACK_BRIDGE_JSON_H
#include <string>
#include <map>
#include <string.h>
/* Bounded JSON response parser, not a substring search for a token. Duplicate
   fields, invalid escaping, trailing data, excessive depth/size are errors. */
namespace xrb_json {
static std::string quote(const std::string& in) {
    static const char h[]="0123456789abcdef";std::string out="\"";
    for(size_t i=0;i<in.size();i++){unsigned char c=(unsigned char)in[i];
        if(c=='"'||c=='\\'){out+='\\';out+=(char)c;}
        else if(c<32){out+="\\u00";out+=h[c>>4];out+=h[c&15];}else out+=(char)c;
    }return out+'"';
}
struct Parser {
    const std::string& s;size_t p;unsigned depth;std::map<std::string,char> types;
    explicit Parser(const std::string& text):s(text),p(0),depth(0){}
    void ws(){while(p<s.size()&&(s[p]==' '||s[p]=='\t'||s[p]=='\r'||s[p]=='\n'))p++;}
    bool take(char c){ws();if(p==s.size()||s[p]!=c)return false;p++;return true;}
    static int hex(char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;}
    bool u16(unsigned& v){if(s.size()-p<4)return false;v=0;for(unsigned i=0;i<4;i++){int n=hex(s[p++]);if(n<0)return false;v=(v<<4)|n;}return true;}
    static void utf8(unsigned v,std::string& out){if(v<128)out+=(char)v;else if(v<2048){out+=(char)(0xc0|(v>>6));out+=(char)(0x80|(v&63));}else if(v<65536){out+=(char)(0xe0|(v>>12));out+=(char)(0x80|((v>>6)&63));out+=(char)(0x80|(v&63));}else{out+=(char)(0xf0|(v>>18));out+=(char)(0x80|((v>>12)&63));out+=(char)(0x80|((v>>6)&63));out+=(char)(0x80|(v&63));}}
    bool str(std::string& out){ws();if(p>=s.size()||s[p++]!='"')return false;out.clear();
        while(p<s.size()){unsigned char c=(unsigned char)s[p++];if(c=='"')return true;if(c<32)return false;
            if(c!='\\'){
                if(c<128){out+=(char)c;continue;}
                unsigned count=0,cp=0,minimum=0;
                if(c>=0xc2&&c<=0xdf){count=1;cp=c&31;minimum=0x80;}
                else if(c>=0xe0&&c<=0xef){count=2;cp=c&15;minimum=0x800;}
                else if(c>=0xf0&&c<=0xf4){count=3;cp=c&7;minimum=0x10000;}else return false;
                if(s.size()-p<count)return false;
                size_t start=p-1;for(unsigned i=0;i<count;i++){unsigned char tail=(unsigned char)s[p++];if((tail&0xc0)!=0x80)return false;cp=(cp<<6)|(tail&63);}
                if(cp<minimum||cp>0x10ffff||(cp>=0xd800&&cp<=0xdfff))return false;
                out.append(s,start,count+1);continue;
            }if(p==s.size())return false;char e=s[p++];
            if(e=='"'||e=='\\'||e=='/')out+=e;
            else if(e=='b')out+='\b';else if(e=='f')out+='\f';else if(e=='n')out+='\n';else if(e=='r')out+='\r';else if(e=='t')out+='\t';
            else if(e=='u'){unsigned v=0;if(!u16(v))return false;if(v>=0xd800&&v<=0xdbff){if(s.size()-p<6||s[p++]!='\\'||s[p++]!='u')return false;unsigned low=0;if(!u16(low)||low<0xdc00||low>0xdfff)return false;v=0x10000+((v-0xd800)<<10)+(low-0xdc00);}else if(v>=0xdc00&&v<=0xdfff)return false;utf8(v,out);}
            else return false;
        }return false;
    }
    bool number(){size_t start=p;if(p<s.size()&&s[p]=='-')p++;if(p==s.size())return false;if(s[p]=='0')p++;else{if(s[p]<'1'||s[p]>'9')return false;while(p<s.size()&&s[p]>='0'&&s[p]<='9')p++;}
        if(p<s.size()&&s[p]=='.'){p++;size_t a=p;while(p<s.size()&&s[p]>='0'&&s[p]<='9')p++;if(a==p)return false;}
        if(p<s.size()&&(s[p]=='e'||s[p]=='E')){p++;if(p<s.size()&&(s[p]=='+'||s[p]=='-'))p++;size_t a=p;while(p<s.size()&&s[p]>='0'&&s[p]<='9')p++;if(a==p)return false;}return p>start;
    }
    bool value(std::string* scalar=NULL){ws();if(p>=s.size())return false;
        if(s[p]=='"'){std::string v;if(!str(v))return false;if(scalar)*scalar=v;return true;}
        if(s[p]=='{'||s[p]=='['){if(++depth>16)return false;char close=s[p++]=='{'?'}':']';bool object=close=='}';std::map<std::string,bool> keys;ws();if(p<s.size()&&s[p]==close){p++;depth--;return true;}
            for(;;){if(object){std::string key;if(!str(key)||!keys.insert(std::make_pair(key,true)).second||!take(':'))return false;}if(!value())return false;ws();if(p<s.size()&&s[p]==close){p++;depth--;return true;}if(!take(','))return false;}
        }
        const char* literals[]={"true","false","null"};for(unsigned i=0;i<3;i++){size_t n=strlen(literals[i]);if(s.compare(p,n,literals[i])==0){if(scalar)*scalar=literals[i];p+=n;return true;}}
        size_t start=p;if(!number())return false;if(scalar)*scalar=s.substr(start,p-start);return true;
    }
    bool object(std::map<std::string,std::string>& fields){if(s.empty()||s.size()>8192||!take('{'))return false;fields.clear();ws();if(p<s.size()&&s[p]=='}'){p++;ws();return p==s.size();}
        for(;;){std::string key,v;if(!str(key)||!take(':'))return false;ws();if(p==s.size())return false;types[key]=s[p];if(!value(&v)||!fields.insert(std::make_pair(key,v)).second)return false;ws();if(p<s.size()&&s[p]=='}'){p++;ws();return p==s.size();}if(!take(','))return false;}
    }
};
}
#endif
