#ifndef XHH_COMPANION_SECURITY_H
#define XHH_COMPANION_SECURITY_H
/* Shared by xhh's bridge, the companion and managed agent. The server alone
   signs leases. HMAC domain-separated encryption makes parameter decoding
   depend on the live session key; it does not promise resistance to patching
   every verifier in a hostile process. Never log tokens, keys or plaintext. */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <string>
#include "companion_protocol.h"
#include "companion_public_key.h"
#include "companion_rsa_verify.h"
#ifdef _WIN32
#include <windows.h>
/* No <bcrypt.h>: the RSA verify below is self-contained (companion_rsa_verify.h)
   so the pass/fail decision never calls out to a hookable system import.
   RtlGenRandom (exported as SystemFunction036 from advapi32, already linked)
   replaces BCryptGenRandom for the same reason -- nothing in this file still
   needs bcrypt.dll. See https://learn.microsoft.com/windows/win32/api/ntsecapi/nf-ntsecapi-rtlgenrandom */
extern "C" __declspec(dllimport) int __stdcall SystemFunction036(void* RandomBuffer, unsigned long RandomBufferLength);
#else
typedef uint32_t DWORD;
#endif

#define ATCS_MAX_CLAIMS 2560
#define ATCS_MAX_TOKEN 4096
#define ATCS_MAX_FILTERS 2048
struct ATCS_Claims {
    char sid[33], license[65], device[65];
    DWORD parent;
    uint64_t issued, expires;
    unsigned char key[32];
    unsigned policy;
    char racks[ATCS_MAX_FILTERS+1], plugins[ATCS_MAX_FILTERS+1];
};
/* Parsed claims contain canonical, terminated fields. Equality deliberately
   compares their semantic values instead of struct padding or unused capacity. */
static int atcs_claims_equal(const ATCS_Claims* a,const ATCS_Claims* b){
    return a&&b&&a->parent==b->parent&&a->issued==b->issued&&a->expires==b->expires&&a->policy==b->policy
        &&!strcmp(a->sid,b->sid)&&!strcmp(a->license,b->license)&&!strcmp(a->device,b->device)
        &&!memcmp(a->key,b->key,32)&&!strcmp(a->racks,b->racks)&&!strcmp(a->plugins,b->plugins);
}
static void atcs_wipe(void* p, size_t n) {
    volatile unsigned char* v=(volatile unsigned char*)p;
    while(n--) *v++=0;
}
static uint64_t atcs_now() {
#ifdef _WIN32
    FILETIME ft; GetSystemTimeAsFileTime(&ft);
    uint64_t t=((uint64_t)ft.dwHighDateTime<<32)|ft.dwLowDateTime;
    return t<116444736000000000ULL?0:(t-116444736000000000ULL)/10000000ULL;
#else
    return (uint64_t)time(NULL);
#endif
}
static int atcs_random(unsigned char* out,unsigned n) {
    if(!out||!n) return 0;
#ifdef _WIN32
    return SystemFunction036(out,(unsigned long)n)!=0;
#else
    FILE* f=fopen("/dev/urandom","rb"); if(!f) return 0;
    int ok=fread(out,1,n,f)==n; fclose(f); return ok;
#endif
}
static int atcs_hex_digit(char c) {
    if(c>='0'&&c<='9') return c-'0';
    if(c>='a'&&c<='f') return c-'a'+10;
    return -1; /* A canonical lowercase alphabet prevents alternate encodings. */
}
static int atcs_hex_decode(const char* s,unsigned len,unsigned char* out,unsigned cap) {
    if(!s||!out||(len&1)||len/2>cap) return 0;
    for(unsigned i=0;i<len/2;i++) {
        int a=atcs_hex_digit(s[i*2]),b=atcs_hex_digit(s[i*2+1]);
        if(a<0||b<0) return 0;
        out[i]=(unsigned char)((a<<4)|b);
    }
    return 1;
}
static void atcs_hex_encode(const unsigned char* in,unsigned len,char* out) {
    static const char h[]="0123456789abcdef";
    for(unsigned i=0;i<len;i++) {out[i*2]=h[in[i]>>4];out[i*2+1]=h[in[i]&15];}
    out[len*2]=0;
}
static void atcs_sha256(const void* p,size_t n,unsigned char out[32]) {
    ATC_SHA256 c; atc_sha_init(&c);atc_sha_update(&c,p,n);atc_sha_final(&c,out);atcs_wipe(&c,sizeof c);
}
static int atcs_equal(const void* a,const void* b,size_t n) {
    const unsigned char* x=(const unsigned char*)a;const unsigned char* y=(const unsigned char*)b;
    unsigned d=0;for(size_t i=0;i<n;i++) d|=x[i]^y[i];return d==0;
}
static int atcs_u64(const char* s,unsigned len,uint64_t* out) {
    if(!s||!out||!len||len>20||(len>1&&s[0]=='0')) return 0;
    uint64_t v=0;
    for(unsigned i=0;i<len;i++) {
        if(s[i]<'0'||s[i]>'9') return 0;
        unsigned d=(unsigned)(s[i]-'0');if(v>(UINT64_MAX-d)/10) return 0;v=v*10+d;
    }
    *out=v;return 1;
}
static int atcs_b64_digit(char c) {
    if(c>='A'&&c<='Z')return c-'A';if(c>='a'&&c<='z')return c-'a'+26;
    if(c>='0'&&c<='9')return c-'0'+52;if(c=='-')return 62;if(c=='_')return 63;return -1;
}
static int atcs_b64_decode(const char* s,unsigned n,unsigned char* out,unsigned cap) {
    if(!s||!out||!n||(n%4)==1) return -1;
    unsigned accum=0,bits=0,used=0;
    for(unsigned i=0;i<n;i++) {
        int v=atcs_b64_digit(s[i]);if(v<0)return -1;
        accum=(accum<<6)|(unsigned)v;bits+=6;
        if(bits>=8){bits-=8;if(used>=cap)return -1;out[used++]=(unsigned char)(accum>>bits);}
    }
    if(bits&&(accum&((1U<<bits)-1))) return -1; /* no noncanonical pad bits */
    return (int)used;
}
static int atcs_claim_field(const char* all,unsigned n,unsigned* cursor,const char* name,const char** value,unsigned* len,int allowEmpty=0) {
    unsigned p=*cursor,k=(unsigned)strlen(name);
    if(p+k>=n||memcmp(all+p,name,k))return 0;
    unsigned start=p+k,end=start;while(end<n&&all[end]!='\n')end++;
    if(end==n||(!allowEmpty&&end==start))return 0;
    *value=all+start;*len=end-start;*cursor=end+1;return 1;
}
/* Policy names are real UTF-8 module basenames, never UI labels or paths.
   ASCII is folded only; Unicode is preserved exactly on every component. */
static int atcs_policy_name(const char* name,unsigned n,int rack) {
    if(!name||!n||n>128||name[n-1]==' '||name[n-1]=='.')return 0;
    for(unsigned i=0;i<n;) {
        unsigned c=(unsigned char)name[i++];
        if(c<128){if(c<32||c==127||strchr("/\\:,<>\"|?*",(int)c)||(c>='A'&&c<='Z'))return 0;continue;}
        unsigned need=0,code=0,min=0;
        if(c>=0xc2&&c<=0xdf){need=1;code=c&31;min=0x80;}
        else if(c>=0xe0&&c<=0xef){need=2;code=c&15;min=0x800;}
        else if(c>=0xf0&&c<=0xf4){need=3;code=c&7;min=0x10000;}else return 0;
        if(i+need>n)return 0;
        while(need--){unsigned d=(unsigned char)name[i++];if((d&0xc0)!=0x80)return 0;code=(code<<6)|(d&63);}
        if(code<min||code>0x10ffff||(code>=0xd800&&code<=0xdfff))return 0;
    }
    if(rack)return n>4&&!memcmp(name+n-4,".exe",4);
    return (n==7&&!memcmp(name,"antares",7))||(n==5&&!memcmp(name,"waves",5))||(n==5&&!memcmp(name,"tpain",5))||(n>4&&!memcmp(name+n-4,".dll",4))||(n>5&&!memcmp(name+n-5,".vst3",5));
}
static int atcs_policy_filter(const char* value,unsigned n,int rack) {
    if(!value||n>ATCS_MAX_FILTERS)return 0;
    if(!n)return 1;
    unsigned p=0,count=0,previousLen=0;unsigned char previous[129];
    while(p<n){unsigned end=p;while(end<n&&value[end]!=',')end++;unsigned len=end-p;unsigned char decoded[129];
        if(!len||len>256||++count>32||!atcs_hex_decode(value+p,len,decoded,128))return 0;
        unsigned used=len/2;if(!atcs_policy_name((const char*)decoded,used,rack))return 0;
        if(previousLen){unsigned common=previousLen<used?previousLen:used;int order=memcmp(previous,decoded,common);if(order>0||(order==0&&previousLen>=used))return 0;}
        memcpy(previous,decoded,used);previousLen=used;if(end==n)break;p=end+1;if(p==n)return 0;
    }return 1;
}
static int atcs_policy_denied(const ATCS_Claims* claims,int rack,const char* utf8Basename) {
    if(!claims||claims->policy!=1||!utf8Basename)return 1;
    unsigned n=0;char name[129];
    while(n<129&&utf8Basename[n]){unsigned char c=(unsigned char)utf8Basename[n];if(n==128)return 1;name[n]=(c>='A'&&c<='Z')?c+32:c;n++;}
    if(!atcs_policy_name(name,n,rack))return 1;
    char encoded[257];atcs_hex_encode((const unsigned char*)name,n,encoded);
    const char* filters=rack?claims->racks:claims->plugins;unsigned p=0;
    while(filters[p]){unsigned end=p;while(filters[end]&&filters[end]!=',')end++;if(end-p==n*2&&!memcmp(filters+p,encoded,n*2))return 1;if(!filters[end])break;p=end+1;}
    return 0;
}
static int atcs_parse_claims(const char* all,unsigned n,ATCS_Claims* out) {
    if(!all||!out||n<100||n>ATCS_MAX_CLAIMS)return 0;
    for(unsigned i=0;i<n;i++)if((all[i]<' '||all[i]>'~')&&all[i]!='\n')return 0;
    ATCS_Claims c;memset(&c,0,sizeof c);unsigned p=0,len=0;const char* v=NULL;uint64_t number=0;
    if(!atcs_claim_field(all,n,&p,"ver=",&v,&len)||len!=1||*v!='3')return 0;
    if(!atcs_claim_field(all,n,&p,"sid=",&v,&len)||len!=32)return 0;
    for(unsigned i=0;i<len;i++)if(atcs_hex_digit(v[i])<0)return 0;memcpy(c.sid,v,32);
    if(!atcs_claim_field(all,n,&p,"lic=",&v,&len)||len>64)return 0;
    if(len<2||len>20||v[0]!='L'||!atcs_u64(v+1,len-1,&number)||!number||number>0x7fffffffffffffffULL)return 0;
    memcpy(c.license,v,len);
    if(!atcs_claim_field(all,n,&p,"dev=",&v,&len)||len!=64)return 0;
    for(unsigned i=0;i<len;i++)if(atcs_hex_digit(v[i])<0)return 0;memcpy(c.device,v,64);
    if(!atcs_claim_field(all,n,&p,"parent=",&v,&len)||!atcs_u64(v,len,&number)||!number||number>0xffffffffULL)return 0;c.parent=(DWORD)number;
    if(!atcs_claim_field(all,n,&p,"iat=",&v,&len)||!atcs_u64(v,len,&c.issued))return 0;
    if(!atcs_claim_field(all,n,&p,"exp=",&v,&len)||!atcs_u64(v,len,&c.expires))return 0;
    if(!atcs_claim_field(all,n,&p,"key=",&v,&len)||len!=64||!atcs_hex_decode(v,len,c.key,32))return 0;
    if(!atcs_claim_field(all,n,&p,"policy=",&v,&len)||len!=1||*v!='1'){atcs_wipe(&c,sizeof c);return 0;}
    unsigned racksLen=0;
    if(!atcs_claim_field(all,n,&p,"racks=",&v,&len,1)||!atcs_policy_filter(v,len,1)){atcs_wipe(&c,sizeof c);return 0;}racksLen=len;memcpy(c.racks,v,len);
    if(!atcs_claim_field(all,n,&p,"plugins=",&v,&len,1)||len+racksLen>ATCS_MAX_FILTERS||!atcs_policy_filter(v,len,0)||p!=n){atcs_wipe(&c,sizeof c);return 0;}memcpy(c.plugins,v,len);
    c.policy=1;*out=c;atcs_wipe(&c,sizeof c);return 1;
}
static int atcs_device_fingerprint(char out[65]) {
    if(!out)return 0;out[0]=0;
#ifdef _WIN32
    HKEY k=NULL;LONG e=RegOpenKeyExW(HKEY_LOCAL_MACHINE,L"SOFTWARE\\Microsoft\\Cryptography",0,KEY_QUERY_VALUE|KEY_WOW64_64KEY,&k);
    if(e!=ERROR_SUCCESS)e=RegOpenKeyExW(HKEY_LOCAL_MACHINE,L"SOFTWARE\\Microsoft\\Cryptography",0,KEY_QUERY_VALUE,&k);
    if(e!=ERROR_SUCCESS)return 0;
    wchar_t guid[128]={0};DWORD sz=sizeof guid,type=0;e=RegQueryValueExW(k,L"MachineGuid",NULL,&type,(BYTE*)guid,&sz);RegCloseKey(k);
    if(e!=ERROR_SUCCESS||type!=REG_SZ||sz<4||sz>sizeof guid||guid[(sz/2)-1]!=0)return 0;
    char ascii[128];unsigned len=0;
    for(;guid[len];len++){if(len>=127||guid[len]>127)return 0;char c=(char)guid[len];ascii[len]=(c>='A'&&c<='Z')?c+32:c;}ascii[len]=0;
    HANDLE token=NULL;if(!OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&token))return 0;
    unsigned char buf[1024];DWORD needed=0;BOOL ok=GetTokenInformation(token,TokenUser,buf,sizeof buf,&needed);CloseHandle(token);
    if(!ok)return 0;PSID sid=((TOKEN_USER*)buf)->User.Sid;if(!IsValidSid(sid))return 0;
    DWORD sidLen=GetLengthSid(sid);if(!sidLen||sidLen>256)return 0;
    ATC_SHA256 hash;unsigned char digest[32];static const char domain[]="xhh-rack-device-v2";
    atc_sha_init(&hash);atc_sha_update(&hash,domain,sizeof domain);atc_sha_update(&hash,ascii,len+1);atc_sha_update(&hash,sid,sidLen);atc_sha_final(&hash,digest);
    atcs_hex_encode(digest,32,out);atcs_wipe(digest,sizeof digest);atcs_wipe(buf,sizeof buf);return 1;
#else
    return 0; /* Test environment must not pretend to be a Windows device. */
#endif
}
/* Same marker convention as the controller's pre-existing companion_verify_server_token:
   a VMProtect "VMProtect_虚拟" marker as the first statement of a noinline function.
   Placed here (shared code) instead of wrapping each call site, so the controller's own
   source-text marker-count guard (which only scans AutoTune_KeyScale_Controller.cpp's own
   text) is untouched, and so the agent/bridge extraction tests (which #define
   atcs_verify_token to a fixture before pulling in its extracted body) never see this
   identifier rewritten -- this function is reachable from all three binaries that link
   companion_security.h, each gets its own compiled copy and its own marker. */
#define ATC_SPROTECT_BEGIN_1() __asm__ __volatile__(".byte 0x50,0x90,0xB8,0x59,0x34,0x90,0xE8,0x90,0xB8,0x86,0x5A,0x62,0xDF,0x90,0x58" ::: "memory")
#define ATC_NOINLINE __attribute__((noinline))
static ATC_NOINLINE int atcs_verify_signature(const unsigned char* claims,unsigned n,const unsigned char signature[256]) {
#if ATCS_PUBLIC_KEY_CONFIGURED
    ATC_SPROTECT_BEGIN_1();
    /* Self-contained verify (companion_rsa_verify.h): no bcrypt.dll, no
       hookable system API in this decision. See that header for the
       fuzz-tested bignum primitives this is built on. */
    unsigned char digest[32];
    atcs_sha256(claims,n,digest);
    int ok=atcs_rsa2048_pkcs1_sha256_verify(ATCS_RSA_MODULUS,65537u,digest,signature);
    atcs_wipe(digest,sizeof digest);return ok;
#else
    (void)claims;(void)n;(void)signature;return 0;
#endif
}
static int atcs_verify_token(const char* token,unsigned len,DWORD expectedParent,const char* expectedDevice,ATCS_Claims* out) {
    if(!token||!out||!expectedParent||!expectedDevice||strlen(expectedDevice)!=64||len<400||len>ATCS_MAX_TOKEN||memcmp(token,"XAT3.",5))return 0;
    unsigned split=5;while(split<len&&token[split]!='.')split++;
    if(split==len)return 0;
    unsigned char claims[ATCS_MAX_CLAIMS+1],signature[256];
    int n=atcs_b64_decode(token+5,split-5,claims,ATCS_MAX_CLAIMS),s=atcs_b64_decode(token+split+1,len-split-1,signature,256);
    if(n<=0||s!=256)return 0;
    if(!atcs_verify_signature(claims,(unsigned)n,signature)){atcs_wipe(claims,sizeof claims);return 0;}
    ATCS_Claims c;memset(&c,0,sizeof c);
    if(!atcs_parse_claims((const char*)claims,(unsigned)n,&c)){atcs_wipe(claims,sizeof claims);return 0;}
    uint64_t now=atcs_now();
    int ok=c.parent==expectedParent&&atcs_equal(c.device,expectedDevice,64)&&c.issued<=now+30&&c.expires>now&&c.expires>c.issued&&c.expires-c.issued<=120;
    if(ok)*out=c;atcs_wipe(&c,sizeof c);atcs_wipe(claims,sizeof claims);atcs_wipe(signature,sizeof signature);return ok;
}
static void atcs_derive(const unsigned char key[32],unsigned char encryption[32],unsigned char authentication[32]) {
    static const char enc[]="XAKS2 encryption",mac[]="XAKS2 authentication";
    atc_hmac_sha256(key,32,enc,sizeof enc-1,encryption);atc_hmac_sha256(key,32,mac,sizeof mac-1,authentication);
}
static void atcs_xor(const unsigned char encryption[32],const unsigned char nonce[16],const unsigned char* in,unsigned n,unsigned char* out) {
    unsigned char block[20],stream[32];memcpy(block,nonce,16);
    for(unsigned start=0,counter=0;start<n;start+=32,counter++) {
        for(unsigned j=0;j<4;j++)block[16+j]=(unsigned char)(counter>>(j*8));
        atc_hmac_sha256(encryption,32,block,sizeof block,stream);
        unsigned take=n-start;if(take>32)take=32;
        for(unsigned j=0;j<take;j++)out[start+j]=in[start+j]^stream[j];
    }
    atcs_wipe(stream,sizeof stream);atcs_wipe(block,sizeof block);
}
static int atcs_plain_valid(const char* plain,unsigned n) {
    if(!plain||!n||n>1024||plain[n-1]!='\n')return 0;
    for(unsigned i=0;i<n-1;i++)if(plain[i]<' '||plain[i]>'~')return 0;return 1;
}
static int atcs_seal(const unsigned char key[32],const char* sid,uint64_t seq,uint64_t expires,const char* plain,unsigned len,char* out,unsigned cap) {
    if(!key||!sid||strlen(sid)!=32||!seq||!expires||!out||!atcs_plain_valid(plain,len))return 0;
    for(unsigned i=0;i<32;i++)if(atcs_hex_digit(sid[i])<0)return 0;
    unsigned char nonce[16],enc[32],mac[32],cipher[1024],digest[32];char nh[33];
    if(!atcs_random(nonce,sizeof nonce))return 0;atcs_hex_encode(nonce,16,nh);atcs_derive(key,enc,mac);atcs_xor(enc,nonce,(const unsigned char*)plain,len,cipher);
    int prefix=snprintf(out,cap,"XAC2|sid=%s|seq=%llu|exp=%llu|nonce=%s|ct=",sid,(unsigned long long)seq,(unsigned long long)expires,nh);
    int ok=prefix>0&&(unsigned)prefix+len*2+5+64+2<=cap;
    if(ok) {
        atcs_hex_encode(cipher,len,out+prefix);unsigned n=(unsigned)prefix+len*2;
        atc_hmac_sha256(mac,32,out,n,digest);memcpy(out+n,"|mac=",5);atcs_hex_encode(digest,32,out+n+5);out[n+69]='\n';out[n+70]=0;
    }
    atcs_wipe(enc,sizeof enc);atcs_wipe(mac,sizeof mac);atcs_wipe(cipher,sizeof cipher);atcs_wipe(digest,sizeof digest);return ok;
}
static int atcs_open(const unsigned char key[32],const char* sid,uint64_t expectedExpiry,const char* line,unsigned len,uint64_t* lastSeq,char* out,unsigned cap) {
    if(!key||!sid||strlen(sid)!=32||!line||!lastSeq||!out||len<150||len>2400||line[len-1]!='\n'||memcmp(line,"XAC2|sid=",9))return 0;
    const char* end=line+len;const char* p=line+9;
    if((unsigned)(end-p)<32+5||memcmp(p,sid,32)||memcmp(p+32,"|seq=",5))return 0;p+=37;
    const char* q=p;while(q<end&&*q>='0'&&*q<='9')q++;uint64_t seq=0,expiry=0;
    if(!atcs_u64(p,(unsigned)(q-p),&seq)||seq<=*lastSeq||end-q<5||memcmp(q,"|exp=",5))return 0;p=q+5;
    q=p;while(q<end&&*q>='0'&&*q<='9')q++;
    if(!atcs_u64(p,(unsigned)(q-p),&expiry)||expiry!=expectedExpiry||atcs_now()>=expiry||end-q<7||memcmp(q,"|nonce=",7))return 0;p=q+7;
    unsigned char nonce[16],enc[32],mac[32],cipher[1024],digest[32],given[32];
    if(end-p<36||!atcs_hex_decode(p,32,nonce,16)||memcmp(p+32,"|ct=",4))return 0;p+=36;
    q=p;while(q<end&&atcs_hex_digit(*q)>=0)q++;
    unsigned hexlen=(unsigned)(q-p);
    if(!hexlen||(hexlen&1)||hexlen>2048||cap<=hexlen/2||end-q!=70||memcmp(q,"|mac=",5)||!atcs_hex_decode(q+5,64,given,32))return 0;
    atcs_derive(key,enc,mac);atc_hmac_sha256(mac,32,line,(unsigned)(q-line),digest);
    int ok=atcs_equal(digest,given,32)&&atcs_hex_decode(p,hexlen,cipher,1024);
    if(ok){atcs_xor(enc,nonce,cipher,hexlen/2,(unsigned char*)out);out[hexlen/2]=0;ok=atcs_plain_valid(out,hexlen/2);}
    if(ok)*lastSeq=seq;else if(cap)out[0]=0;
    atcs_wipe(enc,sizeof enc);atcs_wipe(mac,sizeof mac);atcs_wipe(cipher,sizeof cipher);atcs_wipe(digest,sizeof digest);return ok;
}
#endif
