#ifndef XHH_COMPANION_RSA_VERIFY_H
#define XHH_COMPANION_RSA_VERIFY_H
/* Self-contained RSA-2048 / EMSA-PKCS1-v1_5(SHA-256) signature verification.
   No WinAPI, no bcrypt.dll, no external bignum library: the accept/reject
   decision this guards never calls out to code outside this translation
   unit, so it cannot be short-circuited by hooking a system import.
   Schoolbook (not constant-time) arithmetic is intentional: this verifies a
   PUBLIC signature with a PUBLIC exponent/modulus, so there is no secret
   half-side whose timing could leak; only the final digest comparison is
   constant-time, as good hygiene. Performance is irrelevant: this runs at
   most a few times per lease (minutes apart), never per-command, per-frame
   or per-sample. */
#include <stdint.h>
#include <string.h>

#define ATCS_BN_LIMBS 64            /* 64 * 32 = 2048 bits */
typedef uint32_t ATCS_BN[ATCS_BN_LIMBS];
typedef uint32_t ATCS_BN2[2*ATCS_BN_LIMBS]; /* 4096-bit-wide scratch */

static void atcs_bn_from_be(const unsigned char* be, unsigned n, ATCS_BN out) {
    memset(out, 0, sizeof(ATCS_BN));
    for (unsigned i = 0; i < n; i++) {
        unsigned byteIndexFromEnd = n - 1 - i;      /* 0 = least significant byte */
        unsigned limb = byteIndexFromEnd / 4;
        unsigned shift = (byteIndexFromEnd % 4) * 8;
        if (limb < ATCS_BN_LIMBS) out[limb] |= ((uint32_t)be[i]) << shift;
    }
}
static void atcs_bn_to_be(const ATCS_BN in, unsigned char* out /*[256]*/) {
    for (unsigned i = 0; i < ATCS_BN_LIMBS; i++) {
        uint32_t v = in[ATCS_BN_LIMBS - 1 - i];
        out[i*4+0] = (unsigned char)(v >> 24);
        out[i*4+1] = (unsigned char)(v >> 16);
        out[i*4+2] = (unsigned char)(v >> 8);
        out[i*4+3] = (unsigned char)(v);
    }
}
static int atcs_bn_cmp(const ATCS_BN a, const ATCS_BN b) {
    for (int i = ATCS_BN_LIMBS - 1; i >= 0; i--) {
        if (a[i] != b[i]) return a[i] > b[i] ? 1 : -1;
    }
    return 0;
}
/* out[128] = a[64] * b[64], exact (no reduction). Standard schoolbook
   multiply with 64-bit accumulation per cross term and explicit carry
   propagation past the current row -- the textbook algorithm, chosen over
   anything cleverer so it stays easy to read and to check by hand. */
static void atcs_bn_mul(const ATCS_BN a, const ATCS_BN b, ATCS_BN2 out) {
    memset(out, 0, sizeof(ATCS_BN2));
    for (unsigned i = 0; i < ATCS_BN_LIMBS; i++) {
        uint64_t carry = 0;
        uint64_t ai = a[i];
        if (ai == 0) continue; /* common during the early squarings' zero-extended high half; harmless either way */
        for (unsigned j = 0; j < ATCS_BN_LIMBS; j++) {
            uint64_t t = ai * (uint64_t)b[j] + out[i+j] + carry;
            out[i+j] = (uint32_t)t;
            carry = t >> 32;
        }
        unsigned k = i + ATCS_BN_LIMBS;
        while (carry) {
            uint64_t t = (uint64_t)out[k] + carry;
            out[k] = (uint32_t)t;
            carry = t >> 32;
            k++;
        }
    }
}
static int atcs_bn2_cmp(const ATCS_BN2 a, const ATCS_BN2 b) {
    for (int i = 2*ATCS_BN_LIMBS - 1; i >= 0; i--) {
        if (a[i] != b[i]) return a[i] > b[i] ? 1 : -1;
    }
    return 0;
}
static void atcs_bn2_sub_inplace(ATCS_BN2 a, const ATCS_BN2 b) { /* a -= b, requires a>=b */
    int64_t borrow = 0;
    for (unsigned i = 0; i < 2*ATCS_BN_LIMBS; i++) {
        int64_t t = (int64_t)a[i] - (int64_t)b[i] - borrow;
        if (t < 0) { t += ((int64_t)1 << 32); borrow = 1; } else borrow = 0;
        a[i] = (uint32_t)t;
    }
}
static void atcs_bn2_shl1(ATCS_BN2 a, unsigned bitin) { /* a = (a<<1)|bitin, top bit discarded (never significant here) */
    uint32_t carry = bitin & 1;
    for (unsigned i = 0; i < 2*ATCS_BN_LIMBS; i++) {
        uint32_t next = a[i] >> 31;
        a[i] = (a[i] << 1) | carry;
        carry = next;
    }
}
static unsigned atcs_bn2_bit(const ATCS_BN2 a, unsigned bitpos) {
    return (a[bitpos/32] >> (bitpos%32)) & 1;
}
/* out[64] = x[128] mod m[64], via bit-serial binary long division: classic,
   unglamorous, and simple enough to be obviously correct -- a few hundred
   microseconds here is immaterial given how rarely this runs. */
static void atcs_bn_mod(const ATCS_BN2 x, const ATCS_BN m, ATCS_BN out) {
    ATCS_BN2 rem, mWide;
    memset(rem, 0, sizeof rem);
    memset(mWide, 0, sizeof mWide);
    memcpy(mWide, m, sizeof(ATCS_BN));
    for (int bit = 2*ATCS_BN_LIMBS*32 - 1; bit >= 0; bit--) { /* 2*LIMBS limbs * 32 bits/limb = all bits of x */
        atcs_bn2_shl1(rem, atcs_bn2_bit(x, (unsigned)bit));
        if (atcs_bn2_cmp(rem, mWide) >= 0) atcs_bn2_sub_inplace(rem, mWide);
    }
    memcpy(out, rem, sizeof(ATCS_BN)); /* rem < m < 2^2048, so the high half of rem is always zero here */
}
/* result = base^exponent mod modulus. Plain left-to-right square-and-multiply;
   exponent is a public RSA exponent (e.g. 65537), never a secret, so no
   constant-time exponentiation ladder is required. */
static void atcs_bn_modexp(const ATCS_BN base, uint32_t exponent, const ATCS_BN modulus, ATCS_BN result) {
    ATCS_BN b; ATCS_BN2 wide;
    memcpy(b, base, sizeof(ATCS_BN));
    if (atcs_bn_cmp(b, modulus) >= 0) { /* normalize base mod modulus first, for robustness */
        memset(wide, 0, sizeof wide); memcpy(wide, b, sizeof(ATCS_BN));
        atcs_bn_mod(wide, modulus, b);
    }
    memset(result, 0, sizeof(ATCS_BN)); result[0] = 1; /* result = 1 */
    int started = 0;
    for (int bit = 31; bit >= 0; bit--) {
        if (started) {
            atcs_bn_mul(result, result, wide); atcs_bn_mod(wide, modulus, result); /* square */
        }
        if ((exponent >> bit) & 1) {
            if (!started) { memcpy(result, b, sizeof(ATCS_BN)); started = 1; }
            else { atcs_bn_mul(result, b, wide); atcs_bn_mod(wide, modulus, result); } /* multiply */
        }
    }
    if (!started) { memset(result, 0, sizeof(ATCS_BN)); result[0] = 1; } /* exponent==0 edge case: x^0=1 */
}
static int atcs_rsa_ct_equal(const void* a, const void* b, size_t n) {
    const unsigned char* x = (const unsigned char*)a; const unsigned char* y = (const unsigned char*)b;
    unsigned d = 0; for (size_t i = 0; i < n; i++) d |= x[i] ^ y[i]; return d == 0;
}
/* EMSA-PKCS1-v1_5 DigestInfo prefix for SHA-256 (RFC 8017 / RFC 4055),
   verified against a real RSA-2048 signature produced independently
   (python cryptography) and decoded with raw modexp before being baked in
   here -- not transcribed from memory. */
static const unsigned char ATCS_SHA256_DIGESTINFO_PREFIX[19] = {
    0x30,0x31,0x30,0x0d,0x06,0x09,0x60,0x86,0x48,0x01,0x65,0x03,0x04,0x02,0x01,0x05,0x00,0x04,0x20
};
/* Verifies an RSA-2048 PKCS#1 v1.5 signature over a SHA-256 digest.
   modulus: 256 bytes, big-endian. exponent: public exponent (65537 typical).
   hash: the 32-byte SHA-256 digest of the signed message (caller computes
   this exactly as before -- this file does not duplicate a second SHA-256).
   signature: 256 bytes, big-endian. Returns 1 iff valid. */
static int atcs_rsa2048_pkcs1_sha256_verify(const unsigned char modulus[256], uint32_t exponent,
                                             const unsigned char hash[32], const unsigned char signature[256]) {
    ATCS_BN sig, mod, em_bn;
    atcs_bn_from_be(signature, 256, sig);
    atcs_bn_from_be(modulus, 256, mod);
    if (atcs_bn_cmp(sig, mod) >= 0) return 0; /* signature representative must be < modulus */
    atcs_bn_modexp(sig, exponent, mod, em_bn);
    unsigned char EM[256];
    atcs_bn_to_be(em_bn, EM);
    if (EM[0] != 0x00 || EM[1] != 0x01) return 0;
    unsigned i = 2;
    while (i < 256 && EM[i] == 0xFF) i++;
    if (i < 2 + 8) return 0;           /* RFC 8017 requires at least 8 bytes of 0xFF padding */
    if (i >= 256 || EM[i] != 0x00) return 0;
    i++;
    if (256 - i != (unsigned)(sizeof(ATCS_SHA256_DIGESTINFO_PREFIX) + 32)) return 0;
    if (memcmp(EM + i, ATCS_SHA256_DIGESTINFO_PREFIX, sizeof(ATCS_SHA256_DIGESTINFO_PREFIX)) != 0) return 0;
    return atcs_rsa_ct_equal(EM + i + sizeof(ATCS_SHA256_DIGESTINFO_PREFIX), hash, 32);
}
#endif
