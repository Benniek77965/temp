/*
 * inject.cpp -- DLL injector used by AutoTune_KeyScale_Controller.
 *
 * Loads the agent DLL (at_agent.dll / at_agent32.dll) into a target host process
 * via CreateRemoteThread(LoadLibraryW), then VERIFIES the module is actually
 * present and reports the result. A 64-bit agent can only load into a 64-bit
 * host, and a 32-bit agent only into a 32-bit host -- the controller picks the
 * matching injector/agent by the target's bitness (see proc_is_wow64 there).
 *
 * This is the reference source for the prebuilt inject.exe / inject32.exe that
 * the controller embeds. Standard technique; antivirus may flag remote-thread
 * injection -- that is inherent to this class of tool.
 *
 * Build (run in this folder):
 *   64-bit:  x86_64-w64-mingw32-g++ -O2 -o inject.exe   inject.cpp -lpsapi -static
 *   32-bit:  i686-w64-mingw32-g++   -O2 -o inject32.exe inject.cpp -lpsapi -static
 *
 * Usage:
 *   inject.exe --pid 1234            --dll C:\path\at_agent.dll
 *   inject.exe --proc Samplitude.exe --dll C:\path\at_agent.dll
 *
 * Exit codes: 0 = agent confirmed loaded; 2 = process/DLL not found;
 *   3 = OpenProcess failed; 4 = VirtualAllocEx failed; 5 = CreateRemoteThread
 *   failed; 6 = thread ran but module not present; 9 = remote loader still running;
 *   10 = bitness mismatch or unknown; 11 = already loaded.
 */
#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <stdio.h>
#include <string.h>

static DWORD pid_by_name(const char* name) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32 pe; pe.dwSize = sizeof pe; DWORD pid = 0;
    if (Process32First(snap, &pe)) do {
        if (!_stricmp(pe.szExeFile, name)) { pid = pe.th32ProcessID; break; }
    } while (Process32Next(snap, &pe));
    CloseHandle(snap); return pid;
}

/* 1 if target is a 32-bit process, 0 if 64-bit, -1 unknown.
   Must account for OS bitness: on a 32-bit OS every process is 32-bit and IsWow64Process returns
   FALSE for all of them, so FALSE alone does NOT mean 64-bit. (Same logic as the controller.) */
static int target_is_wow64(HANDLE hp) {
    SYSTEM_INFO si; GetNativeSystemInfo(&si);
    int os64 = (si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64 || si.wProcessorArchitecture == 12 /*ARM64*/);
    if (!os64) return 1;                    /* 32-bit OS -> target is 32-bit */
    BOOL wow = FALSE;
    typedef BOOL (WINAPI *IsWow64Proc)(HANDLE, PBOOL);
    IsWow64Proc fn = (IsWow64Proc)(void*)GetProcAddress(GetModuleHandleA("kernel32.dll"), "IsWow64Process");
    if (!fn || !fn(hp, &wow)) return -1;
    return wow ? 1 : 0;
}

/* are WE (this injector) a 32-bit process? (matches the agent bitness we carry) */
static int self_is_32bit(void) { return sizeof(void*) == 4; }

static bool target_has_module(HANDLE hp, const char* leaf) {
    HMODULE mods[4096]; DWORD need = 0;
    if (!EnumProcessModulesEx(hp, mods, sizeof mods, &need, 0x03 /*LIST_MODULES_ALL*/)) return false;
    int count = (int)(need / sizeof(HMODULE));
    int cap = (int)(sizeof mods / sizeof(HMODULE)); if (count > cap) count = cap;
    for (int i = 0; i < count; i++) {
        char path[MAX_PATH] = "";
        if (GetModuleFileNameExA(hp, mods[i], path, MAX_PATH)) {
            const char* bs = strrchr(path, '\\');
            const char* nm = bs ? bs + 1 : path;
            if (!_stricmp(nm, leaf)) return true;
        }
    }
    return false;
}

struct DllPin {HANDLE h;DllPin():h(INVALID_HANDLE_VALUE){}~DllPin(){if(h!=INVALID_HANDLE_VALUE)CloseHandle(h);}};
static DWORD strict_pid(const char*s){if(!s||!*s)return 0;unsigned long long v=0;for(;*s;s++){if(*s<'0'||*s>'9')return 0;v=v*10+*s-'0';if(v>0xffffffffULL)return 0;}return (DWORD)v;}
static LPTHREAD_START_ROUTINE remote_load_library(HANDLE hp){
    FARPROC local=GetProcAddress(GetModuleHandleA("kernel32.dll"),"LoadLibraryW");HMODULE owner=NULL;
    if(!local||!GetModuleHandleExA(0x4,(LPCSTR)local,&owner))return NULL;
    char name[MAX_PATH]="";GetModuleFileNameA(owner,name,MAX_PATH);const char* leaf=strrchr(name,'\\');leaf=leaf?leaf+1:name;
    HMODULE modules[4096];DWORD size=0;LPTHREAD_START_ROUTINE remote=NULL;
    if(EnumProcessModulesEx(hp,modules,sizeof modules,&size,0x03)){
        unsigned count=size/sizeof(HMODULE);if(count>4096)count=4096;
        for(unsigned i=0;i<count;i++){char path[MAX_PATH]="";if(!GetModuleFileNameExA(hp,modules[i],path,MAX_PATH))continue;const char*part=strrchr(path,'\\');part=part?part+1:path;
            if(!_stricmp(part,leaf)){remote=(LPTHREAD_START_ROUTINE)((ULONG_PTR)modules[i]+((ULONG_PTR)local-(ULONG_PTR)owner));break;}}
    }FreeLibrary(owner);return remote;
}
int main(int argc, char** argv) {
    const char* proc = NULL; DWORD pid = 0; const char* dll = NULL;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--proc") && i + 1 < argc && !proc && !pid) proc = argv[++i];
        else if (!strcmp(argv[i], "--pid") && i + 1 < argc && !proc && !pid){pid=strict_pid(argv[++i]);if(!pid)return 1;}
        else if (!strcmp(argv[i], "--dll") && i + 1 < argc && !dll) dll = argv[++i];
        else return 1; /* no token/key parameter exists: bootstrap is an ACL memory pipe */
    }
    if (!dll || (!proc && !pid)) { printf("usage: inject (--proc name|--pid n) --dll path\n"); return 1; }
    if (!pid) pid = pid_by_name(proc);
    if (!pid) { printf("[X] process not found: %s\n", proc ? proc : "?"); return 2; }

    DllPin pin;pin.h=CreateFileA(dll,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(pin.h==INVALID_HANDLE_VALUE){printf("[X] agent DLL unavailable or not lockable\n");return 2;}

    HANDLE hp = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_CREATE_THREAD |
                            PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ,
                            FALSE, pid);
    if (!hp) { printf("[X] OpenProcess(%lu) failed err=%lu (same user / admin?)\n", pid, GetLastError()); return 3; }

    /* bitness must match: a 32-bit agent only loads into a 32-bit host and vice versa */
    int wow = target_is_wow64(hp);
    if(wow<0){printf("[X] cannot establish target architecture\n");CloseHandle(hp);return 10;}
    if (wow == 0 && self_is_32bit()) { printf("[X] target is 64-bit but this is the 32-bit injector\n"); CloseHandle(hp); return 10; }
    if (wow == 1 && !self_is_32bit()) { printf("[X] target is 32-bit but this is the 64-bit injector\n"); CloseHandle(hp); return 10; }

    char leaf[MAX_PATH]; { const char* bs = strrchr(dll, '\\'); strncpy(leaf, bs ? bs + 1 : dll, MAX_PATH - 1); leaf[MAX_PATH - 1] = 0; }
    /* "Already loaded?" must be asked PER PROCESS, not per file name. The agent takes a named mutex
       "Local\\at_agent_<pid>" on load and holds it for its whole life (at_agent.cpp). Since 1151 the
       controller may inject a FRESH-NAMED copy (at_agent.b<build>_<n>.dll) when the canonical
       at_agent.dll on disk is locked; the module-name check below would miss the agent already running
       under the old name, LoadLibraryW would add a reference, and the newcomer -- seeing the mutex --
       would exit via FreeLibraryAndExitThread, which drops only the load-time reference the new thread
       added. The injector's own LoadLibraryW reference would be left behind, pinning a dead copy and
       blocking a later clean start. Testing the mutex first makes "already present" independent of the
       file name: if we can OPEN it, some agent already owns this process, so there is nothing to do.
       We only probe it -- open and close, never hold -- so we never look like the first owner. (1161) */
    { char mn[64]; _snprintf(mn, sizeof mn, "Local\\at_agent_%lu", pid); mn[sizeof mn-1]=0;
      HANDLE em = OpenMutexA(SYNCHRONIZE, FALSE, mn);
      if (em) { CloseHandle(em); printf("[OK] agent already present in pid %lu (mutex; skip)\n", pid); CloseHandle(hp); return 11; } }
    /* already loaded? do NOT inject again -- a second LoadLibraryW bumps the DLL refcount, and the
       agent's single eject-decrement would then leave it mapped (blocking a later agent start).
       Return 11 = "already present"; the controller treats 0 and 11 both as success. */
    if (target_has_module(hp, leaf)) { printf("[OK] agent already loaded in pid %lu (skip)\n", pid); CloseHandle(hp); return 11; }

    wchar_t wdll[MAX_PATH]; if(!MultiByteToWideChar(CP_ACP, 0, dll, -1, wdll, MAX_PATH)){CloseHandle(hp);return 2;}
    DWORD need = (lstrlenW(wdll) + 1) * sizeof(wchar_t);
    void* mem = VirtualAllocEx(hp, NULL, need, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!mem) { printf("[X] VirtualAllocEx err=%lu\n", GetLastError()); CloseHandle(hp); return 4; }
    SIZE_T written=0;
    if(!WriteProcessMemory(hp,mem,wdll,need,&written)||written!=need){VirtualFreeEx(hp,mem,0,MEM_RELEASE);CloseHandle(hp);return 4;}
    LPTHREAD_START_ROUTINE loadW=remote_load_library(hp);
    if(!loadW){VirtualFreeEx(hp,mem,0,MEM_RELEASE);CloseHandle(hp);return 6;}
    HANDLE th = CreateRemoteThread(hp, NULL, 0, loadW, mem, 0, NULL);
    if (!th) { printf("[X] CreateRemoteThread err=%lu\n", GetLastError()); VirtualFreeEx(hp, mem, 0, MEM_RELEASE); CloseHandle(hp); return 5; }
    DWORD waited=WaitForSingleObject(th,10000);
    if(waited!=WAIT_OBJECT_0){
        /* LoadLibrary may still dereference its pathname: retain this bounded
           remote allocation rather than freeing memory under a live thread. */
        CloseHandle(th);CloseHandle(hp);return 9;
    }
    DWORD ec = 0; GetExitCodeThread(th, &ec);  /* truncated low 32 bits of the HMODULE */
    CloseHandle(th); VirtualFreeEx(hp, mem, 0, MEM_RELEASE);

    Sleep(200);
    bool loaded = target_has_module(hp, leaf);
    CloseHandle(hp);
    if (loaded) { printf("[OK] agent loaded into pid %lu (exit low32=0x%08lx)\n", pid, ec); return 0; }
    printf("[X] agent NOT loaded in pid %lu (missing dependency / AV blocked?)\n", pid);
    return 6;
}
