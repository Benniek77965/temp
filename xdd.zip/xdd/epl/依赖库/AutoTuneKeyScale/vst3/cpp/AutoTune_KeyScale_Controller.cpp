/*
 * at8_controller.cpp -- Auto-Tune Key/Scale controller (VST2 + VST3), native Win32, single EXE
 *
 * - No Python, no external DLL dependency (static-linked). The 32/64-bit agents and
 *   injectors are EMBEDDED as resources and extracted to the data folder (the main program's runtime dir
 *   \keyscale_rack, passed in AT_XHH_DIR) at run time.
 * - Background thread every ~2s: scan all processes for a loaded Auto-Tune .vst3,
 *   auto-inject the matching-bitness agent. Handles VST2 (5.0.9/Evo) and VST3 (AT8.1).
 * - Headless: authenticated parent commands drive agents; the zero-sized hidden
 *   AT8Ctl window exists only for IPC and timers. No visible controls or dialogs.
 * - Agents auto re-locate; agents set via setParamNormalized (no code patching -> PACE-safe).
 */
#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <stdio.h>
#include <string.h>
#include "companion_protocol.h"
#include "companion_pipe.h"
#include "companion_mailbox.h"
#include "companion_policy.h"
#ifndef AT_XHH_MANAGED
#define AT_XHH_MANAGED 0
#endif

/* Managed runtime starts only after a server-signed, device-bound short lease.
   Tokens and session keys are held in memory; agents independently verify leases. */
static const int g_managed = AT_XHH_MANAGED;
static volatile LONG g_authorized = 0;
static int g_runtimeReady = 0;
static ATCS_Claims g_compLease;
static char g_compToken[ATC_MAX_PAYLOAD+1]="",g_compDevice[65]="";
static uint64_t g_compCommandSequence=0;
static volatile LONG g_compReconnectAll=0;
static volatile LONG g_compAuthError=0,g_compHasR=0,g_compStrength=-1,g_compMixedFamily=0;
#define ATC_START_MESSAGE (WM_APP+4)
static HANDLE g_parent = NULL;
static DWORD g_parentPid = 0;
static HWND g_mainWindow = NULL;
static uint64_t g_lastSequence = 0;
static unsigned char g_sessionKey[32] = {0};
static volatile LONG g_compRacks=0, g_compCaptured=0, g_compPending=0, g_compConfirmed=0, g_compOld=0;
static ATC_Apply g_compGoal = {-1,-1,-1};
static int g_compGoalValid=0, g_compRetry=0, g_compForceExit=0;
static int g_compPaused=0,g_compPauseAcknowledged=0;
static uint64_t g_compPauseSequence=0;
static char g_compPauseSid[33]="";
static uint64_t g_compGeneration=0;
static int g_compLastSentKeyScale=0;
static DWORD g_compSentAt=0,g_compReceivedAt=0;
static CRITICAL_SECTION g_compLock;
static volatile LONG g_compRebuilding=0, g_compNeedReplay=0;
static int g_compQueuedCommand=-1;
static unsigned long g_compScopePid=0;
static unsigned g_compScopeId=0;
static char g_compScopeLeaf[96]="";
#define ATC_APPLY_MESSAGE (WM_APP+3)
#define ATC_PARENT_TIMER 42


/* Process identity is checked from the live 64-bit process, not xhh's 32-bit inventory. */
static int companion_policy_process(DWORD pid,int reportIdentity=0){
    if(!g_managed)return 1;
    HANDLE process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!process)return 0;
    HANDLE ownToken=NULL,targetToken=NULL;unsigned char ownUser[1024],targetUser[1024];DWORD a=0,b=0,ownSession=0,targetSession=0;
    int identity=OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&ownToken)&&OpenProcessToken(process,TOKEN_QUERY,&targetToken)
        &&GetTokenInformation(ownToken,TokenUser,ownUser,sizeof ownUser,&a)&&GetTokenInformation(targetToken,TokenUser,targetUser,sizeof targetUser,&b)
        &&EqualSid(((TOKEN_USER*)ownUser)->User.Sid,((TOKEN_USER*)targetUser)->User.Sid)
        &&GetTokenInformation(ownToken,TokenSessionId,&ownSession,sizeof ownSession,&a)&&GetTokenInformation(targetToken,TokenSessionId,&targetSession,sizeof targetSession,&b)&&ownSession==targetSession;
    if(ownToken)CloseHandle(ownToken);if(targetToken)CloseHandle(targetToken);if(!identity){CloseHandle(process);if(reportIdentity)InterlockedOr(&g_compAuthError,32);return 0;}
    wchar_t path[32768];DWORD length=32768;
    int known=QueryFullProcessImageNameW(process,0,path,&length)&&length<32768;CloseHandle(process);if(!known)return 0;
    ATCS_Claims lease;EnterCriticalSection(&g_compLock);lease=g_compLease;LeaveCriticalSection(&g_compLock);
    int allowed=g_authorized&&atcs_now()<lease.expires&&!atcs_policy_path_denied(&lease,1,path);atcs_wipe(&lease,sizeof lease);return allowed;
}
static int companion_policy_module(HANDLE process,HMODULE module){
    if(!g_managed)return 1;wchar_t path[32768];DWORD n=GetModuleFileNameExW(process,module,path,32768);if(!n||n>=32768)return 0;
    ATCS_Claims lease;EnterCriticalSection(&g_compLock);lease=g_compLease;LeaveCriticalSection(&g_compLock);int allowed=!atcs_policy_module_denied(&lease,path,NULL);atcs_wipe(&lease,sizeof lease);return allowed;
}

/* ---- ASCII-only case folding --------------------------------------------------------------
   tolower() and _stricmp() follow LC_CTYPE, and this code runs inside whatever process the host
   happens to be, with whatever locale it has set. Two concrete ways that bites:
     * in a Turkish locale 'I' folds to a dotless 'i', so "LIVE.EXE" stops matching the "live"
       host fragment;
     * in a single-byte Latin locale the bytes 0xC0-0xDE are letters, so folding a path like
       "...\\电音11.vst3" (GBK) rewrites bytes that are halves of Chinese characters, and the
       folded path no longer corresponds to the real one.
   Every string we fold is compared against ASCII literals, so fold ASCII and nothing else. */
static int at_lower(int c){ return (c>='A'&&c<='Z') ? c+32 : c; }
static int at_stricmp(const char* a, const char* b){
    for(;;){ int ca=at_lower((unsigned char)*a), cb=at_lower((unsigned char)*b);
             if(ca!=cb) return ca-cb;
             if(!ca) return 0;
             a++; b++; } }
#undef  tolower
#define tolower(c)   at_lower(c)
#undef  _stricmp
#define _stricmp(a,b) at_stricmp((a),(b))
/* A UTF-8 BOM at the start of a text file we read line by line must not become part of its first entry (1162). Notepad's "UTF-8"
   option used to write one; the settings window drops it when showing the file, so without this the window
   could show "ignore Waves" ticked while skip.txt's first line -- BOM + "waveshell" -- matched nothing. */
static void drop_bom(char* s){ if((unsigned char)s[0]==0xEF && (unsigned char)s[1]==0xBB && (unsigned char)s[2]==0xBF) memmove(s,s+3,strlen(s+3)+1); }

static const char* SCALES[] = {"Major","Minor","Chromatic"};

static char RTDIR[MAX_PATH];     /* where helper binaries extract -- the data folder itself (== COMMDIR); see ensure_runtime */
static char COMMDIR[MAX_PATH];    /* data folder: %LOCALAPPDATA%\AutoTune_KeyScale, else %TEMP%\at8 -- never the exe's folder (1162) */
static char EXEDIR[MAX_PATH];     /* the exe's folder: the data folder of 1161 and older whenever it was writable */
static int  g_dataDirNew = 0;     /* this launch created the data folder -> first launch of 1162 or later */
static char g_prevCommDir[MAX_PATH] = "";   /* the folder the previous controller pointed agents at (old pointer file) */
static char g_oldTemp[MAX_PATH] = "";       /* %TEMP%\at8: the fallback of every build */
#define AT_DATA_SUBDIR "AutoTune_KeyScale"   /* keep in step with the agent's fallback (t_mig compares them) */
static char CMDFILE[MAX_PATH], EJECTFLAG[MAX_PATH], SCALESFILE[MAX_PATH], PREFFILE[MAX_PATH], STATUSFILE[MAX_PATH];
static char AGENT64P[MAX_PATH], AGENT32P[MAX_PATH], INJ64P[MAX_PATH], INJ32P[MAX_PATH];
static void companion_log(const char* event,int key,int scale,int strength){
    if(!g_managed||!g_runtimeReady||!COMMDIR[0])return;
    char license[65],session[33];DWORD received;EnterCriticalSection(&g_compLock);strcpy(license,g_compLease.license);strcpy(session,g_compLease.sid);received=g_compReceivedAt;LeaveCriticalSection(&g_compLock);
    char path[MAX_PATH],line[512];snprintf(path,sizeof path,"%s\\controller.log",COMMDIR);
    int n=snprintf(line,sizeof line,"%llu event=%s session=%s license=%s device=%s key=%d scale=%d strength=%d latency_ms=%lu\r\n",(unsigned long long)atcs_now(),event,session,license,g_compDevice,key,scale,strength,(unsigned long)(received?GetTickCount()-received:0));
    if(n<=0||n>=(int)sizeof line)return;HANDLE f=CreateFileA(path,FILE_APPEND_DATA,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if(f!=INVALID_HANDLE_VALUE){DWORD wrote=0;WriteFile(f,line,(DWORD)n,&wrote,NULL);CloseHandle(f);}
}


/* Where the controller and its agents keep their files (1162). Up to 1161 it was the exe's own folder
   whenever that was writable -- and README suggested the desktop. That filled the folder with protocol
   files, markers, a log and a template; worse, their clean-up goes by NAME PATTERN, so it also deleted the
   user's own files that happened to match. Measured under Wine with 1161: status_report.txt, status_2024.txt,
   scales_notes.txt, status.txt and an unrelated cmd.ini beside the exe were all gone within seconds, and the
   agent took a pending_tasks.txt for a crash marker, wrote its first line into use_factory_hook.txt and
   deleted it. A folder of our own ends both. %LOCALAPPDATA% rather than %TEMP%: a temp clean-up would throw
   away the settings and the learned rack names. */
/* The data folder is in plain view now ("打开数据文件夹" opens it), and a user tidying up may delete it while we
   run. Every command would then fail as "disk full or folder read-only", and no agent could publish its status,
   until a restart. Re-create it instead: before each command, on every pass of the scan thread, and before the settings window writes or the folder is opened. */
static void ensure_data_dir(){ CreateDirectoryA(COMMDIR,NULL); }
/* Write a small control file an agent polls (cmd.ini, eject.flag). The write is exclusive, so it fails whenever
   it lands on the agent's 100 ms read -- and the command was then simply lost: a key change never applied, a rack
   never unloaded, with "disk full or read-only" in the status line. Retry that one error briefly (1162). */
static ATC_NOINLINE int write_ctl_file(const char* path, const char* data, DWORD len,uint64_t* sentSequence=NULL){
    ATC_SPROTECT_BEGIN_1();
    if(sentSequence)*sentSequence=0;uint64_t signedSequence=0;
    if(g_managed && (!g_authorized || !g_runtimeReady)) return 0;
    char sealed[4096],actualPath[MAX_PATH];
    if(g_managed){
        const char* leaf=strrchr(path,'\\');leaf=leaf?leaf+1:path;
        int channel=-1;const char* plain=data;char ejectPlain[64];
        if(!strcmp(leaf,"eject.flag")){channel=3;snprintf(ejectPlain,sizeof ejectPlain,"eject=1|t=%lu\n",GetTickCount());plain=ejectPlain;len=(DWORD)strlen(plain);}
        else if(!strcmp(leaf,"cmd.ini")){
            channel=(strstr(plain,"reload=")||strstr(plain,"pause="))?2:(!strstr(plain,"key=")&&!strstr(plain,"scale="))?1:0;
            if(channel){snprintf(actualPath,sizeof actualPath,"%.*s%s",(int)(leaf-path),path,channel==1?"feel.ini":"control.ini");path=actualPath;}
        }
        if(channel>=0){
            ATCS_Claims lease;uint64_t seq;EnterCriticalSection(&g_compLock);lease=g_compLease;seq=++g_compCommandSequence;LeaveCriticalSection(&g_compLock);
            if(atcs_now()>=lease.expires){SecureZeroMemory(&lease,sizeof lease);return 0;}
            int sealedOk=atcs_channel_seal(lease.key,(unsigned)channel,lease.sid,seq,lease.expires,plain,len,sealed,sizeof sealed);SecureZeroMemory(&lease,sizeof lease);
            if(!sealedOk)return 0;signedSequence=seq;data=sealed;len=(DWORD)strlen(sealed);
        }
    }
    for(int i=0;;i++){
        HANDLE f=CreateFileA(path,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
        if(f!=INVALID_HANDLE_VALUE){ DWORD w=0; BOOL ok=WriteFile(f,data,len,&w,NULL); CloseHandle(f); if(ok&&w==len&&sentSequence)*sentSequence=signedSequence;return ok && w==len; }
        if(i>=20 || GetLastError()!=ERROR_SHARING_VIOLATION) return 0;
        Sleep(5); } }
/* %LOCALAPPDATA% in the ANSI code page -- exactly, or not at all (1162). Read as Unicode and converted here: the
   ANSI GetEnvironmentVariableA maps characters the code page lacks to look-alikes or '?', yielding a DIFFERENT path
   that may even exist, and Wine's cuts a double-byte value short (measured under code page 936: ...\张三 came back
   as ...\张). A lossy conversion returns 0 and the caller falls back to %TEMP%\at8. */
static int local_appdata_ansi(char* out, int cap){
    wchar_t w[MAX_PATH]; DWORD n=GetEnvironmentVariableW(L"LOCALAPPDATA",w,MAX_PATH);
    out[0]=0;
    if(n==0 || n>=MAX_PATH) return 0;
    BOOL lossy=FALSE;
    int k=WideCharToMultiByte(CP_ACP,WC_NO_BEST_FIT_CHARS,w,-1,out,cap,NULL,&lossy);
    if(k<=0 || lossy){ out[0]=0; return 0; }
    return k-1; }
static int dir_writable(const char* d){
    char t[MAX_PATH]; snprintf(t,sizeof t,"%s\\at8_wtest.tmp",d);
    HANDLE h=CreateFileA(t,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_TEMPORARY|FILE_FLAG_DELETE_ON_CLOSE,NULL);
    if(h==INVALID_HANDLE_VALUE) return 0;
    CloseHandle(h); return 1; }
/* The data folder in the ANSI code page -- exactly, or not at all, same rule as local_appdata_ansi. The bridge
   passes it in AT_XHH_DIR: the main program's runtime dir + \keyscale_rack, so the controller, its injectors,
   its agents and its protocol files all sit together under the main program's own folder (and the clean-up by
   name-pattern can never reach the main program's files, which are one level up). */
static int xhh_dir_ansi(char* out, int cap){
    wchar_t w[MAX_PATH]; DWORD n=GetEnvironmentVariableW(L"AT_XHH_DIR",w,MAX_PATH);
    out[0]=0;
    if(n==0 || n>=MAX_PATH) return 0;
    BOOL lossy=FALSE;
    int k=WideCharToMultiByte(CP_ACP,WC_NO_BEST_FIT_CHARS,w,-1,out,cap,NULL,&lossy);
    if(k<=0 || lossy){ out[0]=0; return 0; }
    return k-1; }
static int same_dir(const char* a, const char* b);   /* defined later; used for the backup-pointer self-check */
static void resolve_commdir(){
    GetModuleFileNameA(NULL, EXEDIR, MAX_PATH);
    char* bs=strrchr(EXEDIR,'\\'); if(bs) *bs=0; else strcpy(EXEDIR,".");
    COMMDIR[0]=0;
    char xd[MAX_PATH]=""; int xn=xhh_dir_ansi(xd,MAX_PATH);   /* the folder the bridge chose (runtime dir \keyscale_rack) */
    if(xn>0 && xn<MAX_PATH){
        int made = CreateDirectoryA(xd,NULL) ? 1 : 0;
        if(dir_writable(xd)){ snprintf(COMMDIR,sizeof COMMDIR,"%s",xd); g_dataDirNew=made; }
        else if(made) RemoveDirectoryA(xd); }
    if(!COMMDIR[0]){   /* older bridge that does not pass AT_XHH_DIR: fall back to %LOCALAPPDATA%\AutoTune_KeyScale as before */
        char la[MAX_PATH]=""; int n=local_appdata_ansi(la,MAX_PATH);
        if(n>0 && n+1+(int)sizeof(AT_DATA_SUBDIR)<MAX_PATH){ char d[MAX_PATH]; snprintf(d,sizeof d,"%s\\" AT_DATA_SUBDIR,la);
            int made = CreateDirectoryA(d,NULL) ? 1 : 0;
            if(dir_writable(d)){ snprintf(COMMDIR,sizeof COMMDIR,"%s",d); g_dataDirNew=made; }
            else if(made) RemoveDirectoryA(d); } }   /* an unusable empty folder would mislead the agent's fallback */
    if(!COMMDIR[0]){   /* no usable data folder at all: unset, read-only, or not representable in the ANSI code page */
        char tmp[MAX_PATH]=""; GetTempPathA(MAX_PATH,tmp); snprintf(COMMDIR,sizeof COMMDIR,"%sat8",tmp);
        g_dataDirNew = CreateDirectoryA(COMMDIR,NULL) ? 1 : 0; }
    /* pointer file so the injected agent (in the host process) can find the same dir */
    char tmp[MAX_PATH]=""; GetTempPathA(MAX_PATH,tmp); char ptr[MAX_PATH]; snprintf(ptr,sizeof ptr,"%sat8_commdir.txt",tmp);
    snprintf(g_oldTemp,sizeof g_oldTemp,"%sat8",tmp);
    /* Read it before replacing it (1162): it names the folder the previous controller used. When 1162 is
       unzipped into a fresh folder, that is the only way to find 1161's files -- and any rack still running
       1161's agent, which keeps writing there. */
    { FILE* pf=fopen(ptr,"r");
      if(pf){ if(fgets(g_prevCommDir,sizeof g_prevCommDir,pf)){ int k=(int)strlen(g_prevCommDir);
                  while(k>0 && (unsigned char)g_prevCommDir[k-1]<=' ') g_prevCommDir[--k]=0; }
              fclose(pf); } }
    FILE* f=fopen(ptr,"w"); if(f){ fprintf(f,"%s\n",COMMDIR); fclose(f); }
    /* A second copy of the pointer in a NON-temp spot the agent can always find: %LOCALAPPDATA%\AutoTune_KeyScale.
       The %TEMP% pointer above is the fast path, but a temp clean-up can delete it while the controller has run
       for days; the agent (injected in a host, with no idea of the main program's runtime dir) then needs some
       fixed place to learn where COMMDIR really is. Before the data folder moved under the main program this was
       implicit -- the agent just assumed %LOCALAPPDATA%\AutoTune_KeyScale -- so keep that assumption valid by
       leaving a pointer there even when COMMDIR is now elsewhere. Skipped only if it would point to itself. */
    { char la[MAX_PATH]=""; int n=local_appdata_ansi(la,MAX_PATH);
      if(n>0 && n+1+(int)sizeof(AT_DATA_SUBDIR)<MAX_PATH){
          char bak[MAX_PATH]; snprintf(bak,sizeof bak,"%s\\" AT_DATA_SUBDIR,la); CreateDirectoryA(bak,NULL);
          if(!same_dir(bak,COMMDIR)){ char bp[MAX_PATH]; snprintf(bp,sizeof bp,"%s\\commdir.txt",bak);
              FILE* bf=fopen(bp,"w"); if(bf){ fprintf(bf,"%s\n",COMMDIR); fclose(bf); } } } }
    snprintf(CMDFILE,sizeof CMDFILE,"%s\\cmd.ini",COMMDIR);
    snprintf(EJECTFLAG,sizeof EJECTFLAG,"%s\\eject.flag",COMMDIR);
    snprintf(SCALESFILE,sizeof SCALESFILE,"%s\\scales.txt",COMMDIR);
    snprintf(PREFFILE,sizeof PREFFILE,"%s\\eject_on_close.flag",COMMDIR);
    snprintf(STATUSFILE,sizeof STATUSFILE,"%s\\status.txt",COMMDIR);
}

/* Named so it can be compared with MAXSG below. These two must stay in step: every instance
   listed here contributes one scale section, and 1130 found MAXSG(48) sitting under this
   table's own 64 -- instances past the 48th silently lost their scale list. A literal on one
   side and a macro on the other is what made that invisible. */
#define MAXINST 64
/* The instance signature is "pid:id:leaf|" per instance; leaf is 96 and the rest ~20, so size
   it from MAXINST instead of a literal. At 6000 it covered about 50 instances: past that the
   loop stopped appending, so any change among the LATER instances produced an identical
   signature and the Target list was never rebuilt -- plug-ins added or removed there simply did
   not show up. A literal that silently tracks another constant is the same trap that put an
   out-of-bounds write into 1130. */
#define INSTSIG_SZ (MAXINST*120 + 64)
/* What one status line is PARSED in (1158). The agent's longest line is its field sizes added up --
   host 96 + plug-in 96 + key 64 + scale 64 + Camelot 16 + feel 128 + caps 16, less their NULs, plus ~38
   bytes of fixed text: about 511. This used to be a 256-byte copy, so a long line lost its tail -- and
   the tail is where the instance id and caps live. parse_status_line() then took it for an older agent
   (id 0 = "any instance of this plug-in"), and a write aimed at that one instance reached every
   instance of the same plug-in in that host. t_sizes recomputes the agent's maximum from its source. */
#define STATUS_LINE_PARSE 1024
static struct { unsigned long pid; char leaf[96]; char label[160]; unsigned id; char caps[16]; } g_insts[MAXINST]; static int g_ninst=0; static char g_instSig[INSTSIG_SZ]="";
#define AT_BUILD_EXPECT 1166   /* keep in sync with agent AT_BUILD */
static volatile int g_running = 1;
static HANDLE g_scanTh = NULL;   /* kept so shutdown can wait for the scan thread to finish */
/* Sticky problem flags. A failure here means the user turns a control and nothing happens, with
   nothing on screen to explain why -- a full disk, a read-only folder or an antivirus quarantine all
   look identical to "it stopped working". The scan thread appends these to the status line. */
static volatile int g_cmdWriteFail = 0;   /* could not write the command file */
static volatile int g_agentMissing = 0;   /* the agent DLL / injector is not on disk */

/* ---- extract an embedded RCDATA resource to a file ---- */
static int extract_res(const char* resname, const char* outpath) {
    HRSRC h = FindResourceA(NULL, resname, RT_RCDATA);
    if (!h) return 0;
    HGLOBAL g = LoadResource(NULL, h);
    if (!g) return 0;
    void* p = LockResource(g);
    DWORD n = SizeofResource(NULL, h);
    if (!p || !n) return 0;
    HANDLE f = CreateFileA(outpath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f == INVALID_HANDLE_VALUE) {
        /* target is in use (e.g. the agent DLL is still loaded in a host after a controller crash):
           a loaded image is held with FILE_SHARE_DELETE, so rename it aside and write a fresh copy.
           The renamed .old file stays mapped in that host (harmless) and is cleaned on a later launch. */
        char aside[MAX_PATH]; snprintf(aside, sizeof aside, "%s.old%lu", outpath, (unsigned long)GetTickCount());
        if (MoveFileExA(outpath, aside, MOVEFILE_REPLACE_EXISTING))
            f = CreateFileA(outpath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (f == INVALID_HANDLE_VALUE) return 0;
    }
    DWORD wrote = 0; BOOL ok = WriteFile(f, p, n, &wrote, NULL);
    CloseHandle(f);
    return ok && wrote == n;
}

/* Does the file at path hold exactly the bytes of the embedded resource? */
static int file_matches_res(const char* resname, const char* path){
    HRSRC h=FindResourceA(NULL,resname,RT_RCDATA); if(!h) return 0;
    HGLOBAL g=LoadResource(NULL,h); if(!g) return 0;
    const unsigned char* p=(const unsigned char*)LockResource(g); DWORD n=SizeofResource(NULL,h); if(!p||!n) return 0;
    HANDLE f=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,0,NULL);
    if(f==INVALID_HANDLE_VALUE) return 0;
    int same = (GetFileSize(f,NULL)==n);
    unsigned char buf[65536]; DWORD off=0;
    while(same && off<n){ DWORD want=(n-off<sizeof buf)?(n-off):(DWORD)sizeof buf, got=0;
        if(!ReadFile(f,buf,want,&got,NULL) || got!=want || memcmp(buf,p+off,want)!=0) same=0;
        off+=want; }
    CloseHandle(f); return same; }
static volatile int g_agentStale = 0;   /* could not put this controller's own agent on disk */
/* Delete the fresh-name copies ensure_current() leaves behind ("at_agent.b<build>_<n>.dll" ...).
   A copy still loaded in some host cannot be deleted and simply stays until a later launch.
   The pattern was "*.b1*_*" in 1151, which only matches while the build number starts with 1:
   from build 2000 on the clean-up would silently stop and copies would pile up. */
static int clean_fresh_copies(const char* dir){
    int n=0; char pat[MAX_PATH]; snprintf(pat,sizeof pat,"%s\\*.b*_*",dir);
    WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA(pat,&fd);
    if(hf!=INVALID_HANDLE_VALUE){ do{ char fp[MAX_PATH]; snprintf(fp,sizeof fp,"%s\\%s",dir,fd.cFileName);
        if(DeleteFileA(fp)) n++; }while(FindNextFileA(hf,&fd)); FindClose(hf); }
    return n; }
/* Extract, verify, and if the canonical name holds something else, use a fresh name instead. */
static void ensure_current(const char* resname, char* path, size_t cap){
    extract_res(resname,path);
    if(file_matches_res(resname,path)) return;
    char alt[MAX_PATH]; const char* dot=strrchr(path,'.');
    size_t stem = dot ? (size_t)(dot-path) : strlen(path);
    snprintf(alt,sizeof alt,"%.*s.b%d_%lu%s",(int)stem,path,AT_BUILD_EXPECT,(unsigned long)GetTickCount(),dot?dot:"");
    if(extract_res(resname,alt) && file_matches_res(resname,alt)){ snprintf(path,cap,"%s",alt); return; }
    g_agentStale = 1; }

/* ---- leaving the exe's folder (1162) ---------------------------------------------------------------
   An upgrade from 1161 or older finds our files in the old data folder: usually the exe's folder, else
   %TEMP%\at8. Each candidate is identified by NAME AND CONTENT -- the name alone is exactly what deleted
   users' files before -- and then handled by what it is:
     MIG_RUNTIME   protocol files of one agent process (status_/scales_<pid>.txt, their .tmp) and the
                   command channel (cmd.ini, eject.flag): deleted once their process is gone. A live one
                   belongs to an agent of the old build still resident in a rack: left alone, and that rack
                   is told to restart (legacy_agent_build).
     MIG_PENDING   pending_<pid>.txt: an empty one is deleted; one that names a module is crash evidence and
                   is moved, so the next agent adopts it exactly as before.
     MIG_STATE     files we wrote and keep using (dawhost.txt, use_factory_hook.txt, eject_on_close.flag):
                   moved, or merged into the new folder's copy.
     MIG_LOG       agent.log: moved, or appended to the new one.
     MIG_TEMPLATE  the comment-only scalemap.txt that 1161 wrote on first run: deleted.
     MIG_USER      files the user made (noeat.txt, nouithread.txt, skip.txt, catch.txt, disabled.txt, a
                   scalemap.txt holding groups): copied in on the first launch only, originals untouched --
                   they are the user's, so the user deletes them; a one-time notice says so.
   Runs on every launch: an agent still resident from the old build keeps writing there until its rack
   restarts, and what it leaves is swept on a later launch.
   TRANSITIONAL: this block, legacy_dirs.txt and the legacy-rack banner exist only for upgrades from 1161 and
   older. Planned for removal around 1165, leaving just a notice when old files are found (CHANGELOG_1162.md). */
enum { MIG_NONE=0, MIG_RUNTIME, MIG_PENDING, MIG_STATE, MIG_LOG, MIG_TEMPLATE, MIG_USER };
/* "<prefix><decimal pid><ext>", prefix and ext compared without case. Pure. */
static int pid_suffix(const char* name, const char* prefix, const char* ext, unsigned long* pid){
    size_t pl=strlen(prefix), el=strlen(ext), nl=strlen(name);
    if(nl<=pl+el || nl-pl-el>10) return 0;
    for(size_t i=0;i<pl;i++) if(at_lower((unsigned char)name[i])!=at_lower((unsigned char)prefix[i])) return 0;
    if(at_stricmp(name+nl-el,ext)!=0) return 0;
    unsigned long long v=0;
    for(size_t i=pl;i<nl-el;i++){ char c=name[i]; if(c<'0'||c>'9') return 0; v=v*10+(unsigned)(c-'0'); }
    if(v==0 || v>0xFFFFFFFFull) return 0;
    *pid=(unsigned long)v; return 1; }
/* Could this name be one of ours? Name only: the old folder's other files are never even opened. Pure. */
static int mig_name_candidate(const char* name){
    static const char* const fixed[]={"cmd.ini","eject.flag","eject_on_close.flag","dawhost.txt","use_factory_hook.txt",
        "agent.log","scalemap.txt","noeat.txt","nouithread.txt","skip.txt","catch.txt","disabled.txt",NULL};
    unsigned long pid=0;
    for(int i=0;fixed[i];i++) if(!at_stricmp(name,fixed[i])) return 1;
    return pid_suffix(name,"status_",".txt",&pid) || pid_suffix(name,"scales_",".txt",&pid) || pid_suffix(name,"pending_",".txt",&pid)
        || pid_suffix(name,"status_",".txt.tmp",&pid) || pid_suffix(name,"scales_",".txt.tmp",&pid); }
/* A module path as cb_write_pending() records it: "X:\...\name.vst3" or ".dll", or a UNC path. Pure. */
static int looks_module_path(const char* s){
    int n=(int)strlen(s); while(n>0 && (unsigned char)s[n-1]<=' ') n--;
    int abs = (n>3 && s[1]==':' && s[2]=='\\') || (n>2 && s[0]=='\\' && s[1]=='\\');
    if(!abs || n<5) return 0;
    char tail[8]; memcpy(tail,s+n-5,5); tail[5]=0;
    return !at_stricmp(tail,".vst3") || !at_stricmp(tail+1,".dll"); }
/* Pure: what a file of a pre-1162 data folder is, from its name and its first bytes (head, NUL-terminated;
   size = the whole file's length, which may exceed what head holds). *pid gets the process id, else 0. */
static int mig_classify(const char* name, const char* head, long size, unsigned long* pid){
    unsigned long p=0; *pid=0;
    if(pid_suffix(name,"status_",".txt",&p)){ *pid=p;       /* the agent writes "#b<build>" first (since 1151) */
        return (head[0]=='#' && head[1]=='b' && head[2]>='0' && head[2]<='9') ? MIG_RUNTIME : MIG_NONE; }
    if(pid_suffix(name,"scales_",".txt",&p)){ *pid=p;       /* one "[plug-in]" section after another */
        return head[0]=='[' ? MIG_RUNTIME : MIG_NONE; }
    if(pid_suffix(name,"status_",".txt.tmp",&p)){ *pid=p;   /* half-published, so it may be empty */
        return (size==0 || (head[0]=='#' && head[1]=='b')) ? MIG_RUNTIME : MIG_NONE; }
    if(pid_suffix(name,"scales_",".txt.tmp",&p)){ *pid=p;
        return (size==0 || head[0]=='[') ? MIG_RUNTIME : MIG_NONE; }
    if(pid_suffix(name,"pending_",".txt",&p)){ *pid=p;      /* 1161 always left it empty; a path is crash evidence */
        return (size==0 || looks_module_path(head)) ? MIG_PENDING : MIG_NONE; }
    if(!at_stricmp(name,"cmd.ini")){                         /* write_cmd(): key= / retune= / audiotype= first, |t= always */
        int ours = (!strncmp(head,"key=",4) || !strncmp(head,"retune=",7) || !strncmp(head,"audiotype=",10)) && strstr(head,"|t=")!=NULL;
        return ours ? MIG_RUNTIME : MIG_NONE; }
    if(!at_stricmp(name,"eject.flag"))           return (size==2 && !strcmp(head,"1\n")) ? MIG_RUNTIME : MIG_NONE;
    if(!at_stricmp(name,"eject_on_close.flag"))  return (size==2 && !strcmp(head,"1\n")) ? MIG_STATE : MIG_NONE;
    if(!at_stricmp(name,"dawhost.txt"))          return !strncmp(head,"# DAW exe-name fragments",24) ? MIG_STATE : MIG_NONE;
    if(!at_stricmp(name,"use_factory_hook.txt")) return MIG_STATE;       /* our name alone: nobody else uses it */
    if(!at_stricmp(name,"agent.log")){                       /* every record starts "[<pid>] " */
        if(head[0]!='[') return MIG_NONE;
        int i=1; while(head[i]>='0' && head[i]<='9') i++;
        return (i>1 && head[i]==']' && head[i+1]==' ') ? MIG_LOG : MIG_NONE; }
    if(!at_stricmp(name,"scalemap.txt")){
        if(strncmp(head,"# scalemap.txt - scale synonym groups",37)!=0) return MIG_USER;   /* written by hand */
        if(size>(long)strlen(head)) return MIG_USER;         /* longer than what we looked at: not the bare template */
        for(const char* q=head; *q; ){ while(*q==' '||*q=='\t') q++;
            if(*q && *q!='#' && *q!='\r' && *q!='\n') return MIG_USER;      /* a group was added */
            while(*q && *q!='\n') q++;
            if(*q) q++; }
        return MIG_TEMPLATE; }
    if(!at_stricmp(name,"noeat.txt") || !at_stricmp(name,"nouithread.txt") || !at_stricmp(name,"skip.txt")
       || !at_stricmp(name,"catch.txt") || !at_stricmp(name,"disabled.txt")) return MIG_USER;
    return MIG_NONE; }
/* The first cap-1 bytes, NUL-terminated. Returns the file's size, or -1 if it cannot be read. */
static long read_head(const char* path, char* buf, int cap){
    buf[0]=0;
    HANDLE h=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,0,NULL);
    if(h==INVALID_HANDLE_VALUE) return -1;
    DWORD hi=0, sz=GetFileSize(h,&hi), got=0;
    if(!ReadFile(h,buf,(DWORD)(cap-1),&got,NULL)) got=0;
    buf[got]=0; CloseHandle(h);
    return hi ? 0x7FFFFFFFL : (long)sz; }
/* Is the process that wrote this file still running? Windows REUSES process ids, so "a process with that id is
   alive" is not enough: one that started after the file was last written cannot have written it -- an agent keeps
   rewriting its files while it runs. Measured under Wine: a fresh session handed the dead old agent's id (32) to
   another process, and with the id alone its leftovers were kept, its folder kept on the list, and eject.flag
   written there again on every close. 3 s of slack for FAT's 2-second timestamps. Cannot tell -> alive: never
   delete on a guess. PROCESS_QUERY_LIMITED_INFORMATION also opens an elevated rack's process. */
static int file_owner_alive(const char* path, unsigned long pid){
    HANDLE h=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,(DWORD)pid);
    if(!h) return GetLastError()==ERROR_ACCESS_DENIED;
    DWORD code=0; int alive = GetExitCodeProcess(h,&code) && code==STILL_ACTIVE;
    FILETIME c,x,k,u; WIN32_FILE_ATTRIBUTE_DATA a;
    if(alive && GetProcessTimes(h,&c,&x,&k,&u) && GetFileAttributesExA(path,GetFileExInfoStandard,&a)){
        ULONGLONG started=((ULONGLONG)c.dwHighDateTime<<32)|c.dwLowDateTime;
        ULONGLONG written=((ULONGLONG)a.ftLastWriteTime.dwHighDateTime<<32)|a.ftLastWriteTime.dwLowDateTime;
        if(written+30000000ULL < started) alive=0; }          /* written before this process existed: a reused id */
    CloseHandle(h); return alive; }
static int file_exists(const char* p){ return GetFileAttributesA(p)!=INVALID_FILE_ATTRIBUTES; }
/* Nobody has it open. A resident agent of the old build holds agent.log for as long as its rack runs:
   moving it then would copy it and fail to delete it, and the next launch would copy it again. */
static int file_free(const char* p){
    HANDLE h=CreateFileA(p,GENERIC_READ,0,NULL,OPEN_EXISTING,0,NULL);
    if(h==INVALID_HANDLE_VALUE) return 0;
    CloseHandle(h); return 1; }
/* Add the lines of src that dst lacks (dawhost.txt, use_factory_hook.txt), then remove src. */
static int merge_lines(const char* src, const char* dst){
    static char have[65536]; int hn=0;
    FILE* f=fopen(dst,"rb"); if(f){ hn=(int)fread(have,1,sizeof have-1,f); fclose(f); } have[hn]=0;
    drop_bom(have); hn=(int)strlen(have);
    FILE* s=fopen(src,"rb"); if(!s) return 0;
    FILE* d=fopen(dst,"ab"); if(!d){ fclose(s); return 0; }
    if(hn>0 && have[hn-1]!='\n') fputs("\r\n",d);
    char line[512]; int first=1;
    while(fgets(line,sizeof line,s)){
        if(first){ first=0; drop_bom(line); }
        int n=(int)strlen(line); while(n>0 && (unsigned char)line[n-1]<=' ') line[--n]=0;
        if(!n) continue;
        int dup=0;
        for(const char* q=have; *q && !dup; ){ const char* e=q; while(*e && *e!='\r' && *e!='\n') e++;
            int L=(int)(e-q); while(L>0 && (q[L-1]==' '||q[L-1]=='\t')) L--;
            if(L==n && !strncmp(q,line,(size_t)n)) dup=1;
            q=e; while(*q=='\r'||*q=='\n') q++; }
        if(dup) continue;
        fprintf(d,"%s\r\n",line);
        if(hn+n+1<(int)sizeof have){ memcpy(have+hn,line,(size_t)n); hn+=n; have[hn++]='\n'; have[hn]=0; } }
    fclose(s);
    int ok=(fclose(d)==0);
    return ok && DeleteFileA(src); }
static int append_file(const char* src, const char* dst, const char* banner){
    FILE* s=fopen(src,"rb"); if(!s) return 0;
    FILE* d=fopen(dst,"ab"); if(!d){ fclose(s); return 0; }
    if(banner) fputs(banner,d);
    static char b[65536]; size_t n;
    while((n=fread(b,1,sizeof b,s))>0) fwrite(b,1,n,d);
    fclose(s);
    int ok=(fclose(d)==0);
    return ok && DeleteFileA(src); }
static int  g_migUserCopied=0; static char g_migUserNames[1024]="";   /* user files copied in from a folder they also use: the one-time notice */
#define MAXLEGACY 7
static char g_legacyDir[MAXLEGACY][MAX_PATH]; static int g_nLegacy=0;    /* old folders still holding a live agent's files */
/* A read-only file is moved or copied with its attribute: a copied noeat.txt could then never be switched off
   from the window, and a source that cannot be deleted turns a move into a copy repeated on every launch. */
static void make_writable(const char* p){
    DWORD a=GetFileAttributesA(p);
    if(a!=INVALID_FILE_ATTRIBUTES && (a&FILE_ATTRIBUTE_READONLY)) SetFileAttributesA(p,a&~FILE_ATTRIBUTE_READONLY); }
/* Returns how many of our files had to stay for now: a live old agent's, or one held open. */
static int migrate_dir(const char* old, const char* dst, int firstRun, int shared){
    char pat[MAX_PATH]; snprintf(pat,sizeof pat,"%s\\*",old);
    WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA(pat,&fd);
    if(hf==INVALID_HANDLE_VALUE) return 0;
    int live=0, left=0;
    do{ if(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
        if(!mig_name_candidate(fd.cFileName)) continue;
        char sp[MAX_PATH], dp[MAX_PATH];
        snprintf(sp,sizeof sp,"%s\\%s",old,fd.cFileName); snprintf(dp,sizeof dp,"%s\\%s",dst,fd.cFileName);
        static char head[4096]; long size=read_head(sp,head,(int)sizeof head);
        if(size<0){ if(GetLastError()==ERROR_SHARING_VIOLATION){ live=1; left++; } continue; }   /* being written right now: by an agent, most likely -- keep the folder in view */
        unsigned long pid=0; int k=mig_classify(fd.cFileName,head,size,&pid);
        if(k==MIG_RUNTIME || k==MIG_PENDING){
            if(pid && file_owner_alive(sp,pid)){ live=1; left++; continue; }   /* an old agent still resident: its files */
            if(k==MIG_PENDING && size>0 && !file_exists(dp)){ if(MoveFileExA(sp,dp,MOVEFILE_COPY_ALLOWED)) make_writable(dp); continue; }
            DeleteFileA(sp); continue; }
        if(k==MIG_TEMPLATE){ DeleteFileA(sp); continue; }
        if(k==MIG_STATE || k==MIG_LOG){
            if(!file_free(sp)){ left++; continue; }                     /* held open: next launch */
            make_writable(sp);
            if(!file_exists(dp)){ if(MoveFileExA(sp,dp,MOVEFILE_COPY_ALLOWED)) make_writable(dp); continue; }
            make_writable(dp);
            if(k==MIG_LOG){ char ban[MAX_PATH+64]; snprintf(ban,sizeof ban,"---- moved here from %s ----\r\n",sp); append_file(sp,dp,ban); }
            else if(!at_stricmp(fd.cFileName,"eject_on_close.flag")) DeleteFileA(sp);   /* the new folder already has it */
            else merge_lines(sp,dp);
            continue; }
        if(k==MIG_USER && firstRun && !file_exists(dp) && CopyFileA(sp,dp,TRUE)){
            make_writable(dp);
            if(shared){ g_migUserCopied++;                             /* full path: it may not be this exe's folder */
                if(strlen(g_migUserNames)+strlen(sp)+8 < sizeof g_migUserNames){
                    if(g_migUserNames[0]) strcat(g_migUserNames,"\r\n    ");
                    strcat(g_migUserNames,sp); } } }
    } while(FindNextFileA(hf,&fd));
    FindClose(hf);
    if(live && g_nLegacy<MAXLEGACY) snprintf(g_legacyDir[g_nLegacy++],MAX_PATH,"%s",old);
    return left; }
/* Two spellings of one folder (case, an 8.3 name, "..", a junction) must count as one: migrating the data
   folder onto itself would merge dawhost.txt into itself and then delete it. Compared by volume + file index. */
static int dir_id(const char* d, BY_HANDLE_FILE_INFORMATION* fi){
    HANDLE h=CreateFileA(d,0,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS,NULL);
    if(h==INVALID_HANDLE_VALUE) return 0;
    BOOL ok=GetFileInformationByHandle(h,fi); CloseHandle(h); return ok?1:0; }
static int same_dir(const char* a, const char* b){
    if(!a[0] || !b[0]) return 0;
    if(!at_stricmp(a,b)) return 1;
    BY_HANDLE_FILE_INFORMATION x, y;
    if(!dir_id(a,&x) || !dir_id(b,&y)) return 0;
    return x.dwVolumeSerialNumber==y.dwVolumeSerialNumber && x.nFileIndexHigh==y.nFileIndexHigh && x.nFileIndexLow==y.nFileIndexLow; }
/* The previous folder may be a share that is offline now: enumerating it could hold up startup -- and with it
   the injection that has to beat the rack's plug-ins. */
static int is_remote_dir(const char* d){
    if(d[0]=='\\' && d[1]=='\\') return 1;
    if(d[0] && d[1]==':'){ char root[4]={d[0],':','\\',0}; return GetDriveTypeA(root)==DRIVE_REMOTE; }
    return 0; }
#define MAXREC 4
static void migrate_legacy(){
    /* Where 1161 and older kept files: beside this exe; wherever the previous controller pointed its agents
       (the old pointer file -- the case when 1162 is unzipped into a fresh folder); %TEMP%\at8; and every old
       folder an earlier launch could not finish with. That last list (legacy_dirs.txt) exists because the old
       pointer is gone after the first launch: a rack still running the old agent would otherwise lose its
       "restart this rack" banner on the second launch, and its leftovers would never be cleaned. */
    char rp[MAX_PATH]; snprintf(rp,sizeof rp,"%s\\legacy_dirs.txt",COMMDIR);
    static char rec[MAXREC][MAX_PATH]; int nrec=0;
    { FILE* f=fopen(rp,"r");
      if(f){ char ln[MAX_PATH];
          while(nrec<MAXREC && fgets(ln,sizeof ln,f)){ int k=(int)strlen(ln); while(k>0 && (unsigned char)ln[k-1]<=' ') ln[--k]=0;
              if(k>0) snprintf(rec[nrec++],MAX_PATH,"%s",ln); }
          fclose(f); } }
    const char* cand[3+MAXREC]; int nc=0;
    cand[nc++]=EXEDIR; cand[nc++]=g_prevCommDir; cand[nc++]=g_oldTemp;
    for(int i=0;i<nrec;i++) cand[nc++]=rec[i];
    static char keep[MAXREC][MAX_PATH]; int nkeep=0;
    for(int i=0;i<nc;i++){
        if(!cand[i][0] || (i>0 && is_remote_dir(cand[i])) || same_dir(cand[i],COMMDIR)) continue;
        int dup=0; for(int j=0;j<i;j++) if(cand[j][0] && same_dir(cand[i],cand[j])) dup=1;
        if(dup) continue;
        int isTemp = g_oldTemp[0] && same_dir(cand[i],g_oldTemp);
        int left = migrate_dir(cand[i],COMMDIR,g_dataDirNew,!isTemp);
        /* Every folder something of ours had to stay in is remembered -- this exe's folder too: the exe may be
           moved before the old rack restarts, and then nothing else would lead back there. */
        if(left>0 && nkeep<MAXREC) snprintf(keep[nkeep++],MAX_PATH,"%s",cand[i]); }
    if(nkeep==0) DeleteFileA(rp);
    else { FILE* f=fopen(rp,"w"); if(f){ for(int i=0;i<nkeep;i++) fprintf(f,"%s\n",keep[i]); fclose(f); } } }
/* Is an agent of the old build still alive in this old folder (a status_/scales_/pending_ file of a live process)? */
static int legacy_dir_live(const char* d){
    char pat[MAX_PATH]; snprintf(pat,sizeof pat,"%s\\*",d);
    WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA(pat,&fd);
    if(hf==INVALID_HANDLE_VALUE) return 0;
    int live=0;
    do{ if(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
        if(!mig_name_candidate(fd.cFileName)) continue;
        char fp[MAX_PATH]; snprintf(fp,sizeof fp,"%s\\%s",d,fd.cFileName);
        static char head[4096]; long sz=read_head(fp,head,(int)sizeof head); unsigned long pid=0;
        if(sz<0) continue;
        int k=mig_classify(fd.cFileName,head,sz,&pid);
        if((k==MIG_RUNTIME || k==MIG_PENDING) && pid && file_owner_alive(fp,pid)) live=1;
    } while(!live && FindNextFileA(hf,&fd));
    FindClose(hf);
    return live; }
/* "Unload on close" must reach a rack still running the old build's agent too: that agent watches the OLD
   folder's eject.flag. Only folders where such an agent is alive get one -- it is a file in a folder the user may
   keep other things in -- and a later launch removes it again (it is a runtime file of ours). */
static void eject_legacy_agents(){
    for(int d=0; d<g_nLegacy; d++){
        if(!legacy_dir_live(g_legacyDir[d])) continue;
        char p[MAX_PATH]; snprintf(p,sizeof p,"%s\\eject.flag",g_legacyDir[d]);
        write_ctl_file(p,"1\n",2); } }
/* agent.log only ever grew: every agent appends and nothing trimmed it. Keep one previous generation. At
   startup no agent of ours is normally writing; if one still holds it, the rename fails and waits for next time. */
static void rotate_log(){
    char lg[MAX_PATH], old[MAX_PATH];
    snprintf(lg,sizeof lg,"%s\\agent.log",COMMDIR); snprintf(old,sizeof old,"%s\\agent.log.1",COMMDIR);
    WIN32_FILE_ATTRIBUTE_DATA a;
    if(!GetFileAttributesExA(lg,GetFileExInfoStandard,&a)) return;
    if(a.nFileSizeHigh==0 && a.nFileSizeLow<2u*1024*1024) return;
    MoveFileExA(lg,old,MOVEFILE_REPLACE_EXISTING); }
/* Running elevated, the controller executes inject.exe and has agents load at_agent.dll out of the data folder -- a
   folder any program of this user can write. Checked once at startup but used much later, a file swapped in between
   would run with administrator rights (1162). So each one is opened with writes and deletes DENIED, checked through
   that very handle, and the handle is held until we exit: what was checked is what gets used. Loading the DLL and
   starting the injector only read the file, so they are unaffected. */
#define NPIN 4
static HANDLE g_pinned[NPIN]; static int g_nPinned=0;
static int pin_and_verify(const char* resname, const char* path){
    HRSRC h=FindResourceA(NULL,resname,RT_RCDATA); if(!h) return 0;
    HGLOBAL g=LoadResource(NULL,h); if(!g) return 0;
    const unsigned char* p=(const unsigned char*)LockResource(g); DWORD n=SizeofResource(NULL,h);
    if(!p || !n || g_nPinned>=NPIN) return 0;
    HANDLE f=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL);
    if(f==INVALID_HANDLE_VALUE) return 0;
    int same=(GetFileSize(f,NULL)==n);
    static unsigned char buf[65536]; DWORD off=0;
    while(same && off<n){ DWORD want=(n-off<sizeof buf)?(n-off):(DWORD)sizeof buf, got=0;
        if(!ReadFile(f,buf,want,&got,NULL) || got!=want || memcmp(buf,p+off,want)!=0) same=0;
        off+=want; }
    if(!same){ CloseHandle(f); return 0; }
    g_pinned[g_nPinned++]=f; return 1; }
/* ensure_current(), then pin. If the pin fails -- the file changed after it was checked, or something holds it open for
   writing -- write a fresh copy under a new name and pin that instead. */
static void ensure_pinned(const char* resname, char* path, size_t cap){
    ensure_current(resname,path,cap);
    if(pin_and_verify(resname,path)) return;
    for(int i=0;i<3;i++){
        char alt[MAX_PATH]; const char* dot=strrchr(path,'.'); size_t stem=dot?(size_t)(dot-path):strlen(path);
        snprintf(alt,sizeof alt,"%.*s.b%d_%lu%s",(int)stem,path,AT_BUILD_EXPECT,(unsigned long)GetTickCount()+(unsigned long)i,dot?dot:"");
        if(extract_res(resname,alt) && pin_and_verify(resname,alt)){ snprintf(path,cap,"%s",alt); return; } }
    g_agentStale=1; }
static void unpin_all(){ for(int i=0;i<g_nPinned;i++) CloseHandle(g_pinned[i]); g_nPinned=0; }
/* Clear one historical extraction folder: only our own file names, only when it is not the folder in use now,
   then remove it if it ended up empty. A file there we did not place (same name by coincidence) is left alone
   by removing only the known names; the directory removal then simply fails and the folder stays. */
static void purge_old_rt(const char* old){
    if(same_dir(old,RTDIR) || GetFileAttributesA(old)==INVALID_FILE_ATTRIBUTES) return;
    static const char* const names[]={"at_agent.dll","at_agent32.dll","inject.exe","inject32.exe"};
    for(int i=0;i<4;i++){ char fp[MAX_PATH]; snprintf(fp,sizeof fp,"%s\\%s",old,names[i]); DeleteFileA(fp); }
    char pat[MAX_PATH]; snprintf(pat,sizeof pat,"%s\\at_agent.b*",old);   /* fresh-named copies left by a locked extraction */
    WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA(pat,&fd);
    if(hf!=INVALID_HANDLE_VALUE){ do{ char fp[MAX_PATH]; snprintf(fp,sizeof fp,"%s\\%s",old,fd.cFileName); DeleteFileA(fp); }while(FindNextFileA(hf,&fd)); FindClose(hf); }
    RemoveDirectoryA(old); }
static void ensure_runtime() {
    if(g_managed && !g_authorized) return;
    resolve_commdir();
    /* The injectors and agents extract straight into the data folder (COMMDIR). With the bridge passing
       AT_XHH_DIR that folder is the main program's runtime dir + \keyscale_rack, so every file -- the
       controller, the injectors, the agents and the protocol files -- sits together there, one level below
       the main program's own files (which the name-pattern clean-up therefore never touches). No %TEMP%:
       an exe dropped in %TEMP% and run from there is one of the most-flagged patterns there is, and a temp
       clean-up could delete it mid-run. The injected agent never needs this path -- the controller passes
       each DLL to the injector by absolute path (--dll) -- so where it sits changes nothing for injection. */
    snprintf(RTDIR, sizeof RTDIR, "%s", COMMDIR);
    snprintf(AGENT64P, sizeof AGENT64P, "%s\\at_agent.dll", RTDIR);
    snprintf(AGENT32P, sizeof AGENT32P, "%s\\at_agent32.dll", RTDIR);
    snprintf(INJ64P, sizeof INJ64P, "%s\\inject.exe", RTDIR);
    snprintf(INJ32P, sizeof INJ32P, "%s\\inject32.exe", RTDIR);
    /* Earlier builds extracted these helpers elsewhere: %TEMP%\at8_rt (oldest), then %LOCALAPPDATA%\
       AutoTune_KeyScale\at8_rt (the previous build, before everything moved under the main program's folder).
       Each would otherwise sit there forever holding exactly the unsigned exe/dll an antivirus flags, so clear
       both once -- each only when it is a DIFFERENT folder from the current one, and only our own file names. */
    { char tmp[MAX_PATH]=""; GetTempPathA(MAX_PATH,tmp); char old[MAX_PATH]; snprintf(old,sizeof old,"%sat8_rt",tmp); purge_old_rt(old);
      char la[MAX_PATH]=""; int n=local_appdata_ansi(la,MAX_PATH);
      if(n>0){ snprintf(old,sizeof old,"%s\\" AT_DATA_SUBDIR "\\at8_rt",la); purge_old_rt(old); } }
    migrate_legacy();   /* before anything reads the data folder: dawhost.txt and the switches must be there (1162) */
    rotate_log();
    clean_fresh_copies(RTDIR);
    { char pat[MAX_PATH]; snprintf(pat,sizeof pat,"%s\\*.old*",RTDIR);   /* clean aside-files left by a previous locked extraction */
      WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA(pat,&fd);
      if(hf!=INVALID_HANDLE_VALUE){ do{ char fp[MAX_PATH]; snprintf(fp,sizeof fp,"%s\\%s",RTDIR,fd.cFileName); DeleteFileA(fp); }while(FindNextFileA(hf,&fd)); FindClose(hf); } }
    /* The agent that gets injected must be THIS controller's agent. A refresh failure used to be
       accepted "as long as a usable copy is already on disk" -- but a usable copy can be an OLDER build,
       left by a previous controller and still locked (an antivirus scan, say). Every rack would then
       get that old agent; the list would say "restart that rack", and restarting would change nothing.
       So each file is compared byte for byte with the copy embedded here; if it differs, a fresh copy
       goes to a new name and that name is the one injected. A second agent in a host that still has
       the old one resident is harmless: the agent's per-process mutex makes the newcomer leave. */
    ensure_pinned("AGENT64",  AGENT64P, sizeof AGENT64P);
    ensure_pinned("AGENT32",  AGENT32P, sizeof AGENT32P);
    ensure_pinned("INJECT64", INJ64P,   sizeof INJ64P);
    ensure_pinned("INJECT32", INJ32P,   sizeof INJ32P);
    /* But if the file is not there at all, nothing can ever work and the symptom would otherwise be
       an unexplained "injection failed". Antivirus quarantine is the common cause. */
    g_agentMissing = (GetFileAttributesA(AGENT64P) == INVALID_FILE_ATTRIBUTES)
                  || (GetFileAttributesA(INJ64P)   == INVALID_FILE_ATTRIBUTES);
    /* clear stale control files so freshly injected agents aren't killed by an old eject,
       and drop any stale scale list from a previous (different) plugin */
    DeleteFileA(CMDFILE);
    DeleteFileA(EJECTFLAG);
    if(g_managed)return; /* keep captured instances/status during controller restart */
    { char pat[MAX_PATH]; snprintf(pat,sizeof pat,"%s\\scales_*.txt",COMMDIR);
      WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA(pat,&fd);
      if(hf!=INVALID_HANDLE_VALUE){ do{ char fp[MAX_PATH]; snprintf(fp,sizeof fp,"%s\\%s",COMMDIR,fd.cFileName); DeleteFileA(fp); }while(FindNextFileA(hf,&fd)); FindClose(hf); } }
    { char pat[MAX_PATH]; snprintf(pat,sizeof pat,"%s\\status_*.txt",COMMDIR);
      WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA(pat,&fd);
      if(hf!=INVALID_HANDLE_VALUE){ do{ char fp[MAX_PATH]; snprintf(fp,sizeof fp,"%s\\%s",COMMDIR,fd.cFileName); DeleteFileA(fp); }while(FindNextFileA(hf,&fd)); FindClose(hf); } }
      { char o1[MAX_PATH],o2[MAX_PATH]; snprintf(o1,sizeof o1,"%s\\scales.txt",COMMDIR); snprintf(o2,sizeof o2,"%s\\status.txt",COMMDIR); DeleteFileA(o1); DeleteFileA(o2); }   /* remove pre-per-pid shared leftovers */
    /* ...and the half-written temporaries. The agent publishes by writing "<name>.tmp" and renaming
       it over the real file, so a host that is killed between those two steps leaves the .tmp behind.
       Neither the startup sweep nor the per-scan one could ever remove it: both match "*.txt", and
       these end in ".tmp". Nothing reads them, so the only cost is litter -- but it accumulates for
       ever, one file per kill, and the comm directory is where a user is sent to look when something
       is wrong. Startup is the one moment no agent is mid-publish, so it is the only safe time. */
    { const char* pats[2]={"%s\\scales_*.txt.tmp","%s\\status_*.txt.tmp"};
      for(int k=0;k<2;k++){ char pat[MAX_PATH]; snprintf(pat,sizeof pat,pats[k],COMMDIR);
        WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA(pat,&fd);
        if(hf!=INVALID_HANDLE_VALUE){ do{ char fp[MAX_PATH]; snprintf(fp,sizeof fp,"%s\\%s",COMMDIR,fd.cFileName); DeleteFileA(fp); }while(FindNextFileA(hf,&fd)); FindClose(hf); } } }
}

/* ---- process scan ---- */
static int proc_is_wow64(HANDLE hp) {   /* returns 1 if target is 32-bit process, 0 if 64-bit */
    SYSTEM_INFO si; GetNativeSystemInfo(&si);
    int os64 = (si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64 || si.wProcessorArchitecture == 12);
    if (!os64) return 1;
    BOOL w = FALSE;
    typedef BOOL (WINAPI *P)(HANDLE, PBOOL);
    P fn = (P)GetProcAddress(GetModuleHandleA("kernel32.dll"), "IsWow64Process");
    if (fn && fn(hp, &w)) return w ? 1 : 0;
    return 0;
}
static int icontains(const char* s, const char* sub) {
    char a[600], b[64]; size_t i;
    for (i = 0; s[i] && i < 599; i++) a[i] = (char)tolower((unsigned char)s[i]); a[i] = 0;
    for (i = 0; sub[i] && i < 63; i++) b[i] = (char)tolower((unsigned char)sub[i]); b[i] = 0;
    return strstr(a, b) != NULL;
}

/* host record */
/* tier: 3 = a tuning plug-in is loaded in it, 2 = exe named in dawhost.txt, 1 = structurally a
   plug-in host, or a child of one (a bridge). Kept because the count shown to the user has to mean
   "racks", not "processes we injected into" -- see the status line. */
typedef struct { DWORD pid; int wow; int atHost; int tier; char exe[64]; } Host;

/* cache: module path -> is-Auto-Tune (1), not (0). Avoids re-reading version info every scan. */
#define PCACHE 4096
static char  g_pcPath[PCACHE][MAX_PATH];
static char  g_pcVal[PCACHE];
static int   g_pcN=0;
static int pcache_get(const char* path, int* found){
    for(int i=0;i<g_pcN;i++) if(_stricmp(g_pcPath[i],path)==0){ *found=1; return g_pcVal[i]; }
    *found=0; return 0;
}
static void pcache_put(const char* path, int val){
    if(g_pcN<PCACHE){ snprintf(g_pcPath[g_pcN],MAX_PATH,"%s",path); g_pcVal[g_pcN]=(char)val; g_pcN++; }
}
/* fallback: scan module FILE content (<=32MB) for Antares/Auto-Tune, for stripped/renamed plugins */
static int cbuf_has(const char* hay,int n,const char* needle){ int m=(int)strlen(needle);
    for(int i=0;i+m<=n;i++){ int j=0; for(;j<m;j++){ char c=hay[i+j]; char lc=(c>='A'&&c<='Z')?(char)(c+32):c; if(lc!=needle[j]) break; } if(j==m) return 1; } return 0; }
static int file_has_at(const char* path){
    HANDLE h=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_FLAG_SEQUENTIAL_SCAN,NULL);
    if(h==INVALID_HANDLE_VALUE) return 0;
    const int CH=1<<20, OV=16; const long long LIMIT=32LL<<20; long long tot=0;
    char* buf=(char*)malloc(CH+OV); int found=0;
    if(buf){ DWORD rd=0; int carry=0;
        while(tot<LIMIT && ReadFile(h,buf+carry,CH,&rd,NULL) && rd>0){ tot+=rd; int total=carry+(int)rd;
            if(cbuf_has(buf,total,"antares")||cbuf_has(buf,total,"auto-tune")||cbuf_has(buf,total,"autotune")){ found=1; break; }
            carry=(total>=OV)?OV:total; memmove(buf,buf+total-carry,carry);
        }
        free(buf);
    }
    CloseHandle(h); return found;
}
/* read version info strings; return 1 if Antares/Auto-Tune found */
static int module_is_autotune(const char* path){
    int found=0; int cached=pcache_get(path,&found); if(found) return cached;
    int result=0;
    DWORD dummy=0; DWORD sz=GetFileVersionInfoSizeA(path,&dummy);
    if(sz){
        void* buf=malloc(sz);
        if(buf && GetFileVersionInfoA(path,0,sz,buf)){
            /* enumerate translations */
            struct LANGCP{ WORD lang, cp; } *tr=NULL; UINT trlen=0;
            if(VerQueryValueA(buf,"\\VarFileInfo\\Translation",(void**)&tr,&trlen) && tr && trlen>=4){
                int ntr=trlen/4;
                const char* fields[]={"CompanyName","ProductName","FileDescription","InternalName","OriginalFilename"};
                for(int t=0;t<ntr && !result;t++){
                    for(int fi=0; fi<5 && !result; fi++){
                        char sub[128]; snprintf(sub,sizeof sub,"\\StringFileInfo\\%04x%04x\\%s",tr[t].lang,tr[t].cp,fields[fi]);
                        char* val=NULL; UINT vlen=0;
                        if(VerQueryValueA(buf,sub,(void**)&val,&vlen) && val){
                            char low[256]; int i=0; for(;val[i]&&i<255;i++) low[i]=(char)tolower((unsigned char)val[i]); low[i]=0;
                            if(strstr(low,"antares")||strstr(low,"auto-tune")||strstr(low,"autotune")) result=1;
                        }
                    }
                }
            }
        }
        free(buf);
    }
    if(!result) result=file_has_at(path);   /* fallback for stripped version info (e.g. renamed cracks) */
    pcache_put(path,result);
    return result;
}

/* preload: optional list of DAW exe-name substrings (dawhost.txt) to inject into proactively,
   even before any Auto-Tune plugin is loaded -- so 电音11 can be caught at its first createInstance. */
#define MAXDAW 96
static char g_daw[MAXDAW][64]; static int g_ndaw=0; static int g_dawLoaded=0;
static int g_dawFull=0;   /* dawhost.txt 已满:新学到的机架名读不回来了 */
static int g_aggFull=0;   /* 状态聚合缓冲满:部分实例没显示出来 */
#define RTDIR_PARENT() COMMDIR
static const char* DAW_DEFAULTS = "# DAW exe-name fragments (whole-word, digit allowed after e.g. Cubase14/Sam_x64); rack auto-learned on first use\nsam\nsam_x64\nsamplitude\nsequoia\nmusic maker\nmusicmaker\ncubase\nnuendo\nwavelab\nstudio one\nstudioone\nableton\nreaper\npro tools\nprotools\nfl\nfl64\nflstudio\nbitwig\nreason\ncakewalk\nsonar\nmixcraft\naudition\nwaveform\ntracktion\nardour\nmixbus\nrenoise\nvegas\nsound forge\nsoundforge\nforge\nacid\npodium\nenergyxt\nmaschine\nserato\nsoundbridge\nntrack\nn-track\nluna\ndigital performer\ndigitalperformer\nmulab\npyramix\nacoustica\nmixpad\nharrison\n";
static void load_dawhosts(){ g_dawLoaded=1; g_ndaw=0;
    char pth[MAX_PATH]; snprintf(pth,sizeof pth,"%s\\dawhost.txt",RTDIR_PARENT());
    if(GetFileAttributesA(pth)==INVALID_FILE_ATTRIBUTES){ FILE* w=fopen(pth,"w"); if(w){ fputs(DAW_DEFAULTS,w); fclose(w); } }  /* seed a comprehensive default */
    FILE* f=fopen(pth,"r");
    if(f){ char line[128]; int first=1; while(fgets(line,sizeof line,f)){ if(first){ first=0; drop_bom(line); } int n=(int)strlen(line);
            while(n>0&&(line[n-1]=='\n'||line[n-1]=='\r'||line[n-1]==' '||line[n-1]=='\t')) line[--n]=0;
            int i=0; while(line[i]==' '||line[i]=='\t') i++;
            if(line[i]=='#') continue;
            if(line[i] && g_ndaw<MAXDAW){ int j=0; for(;line[i]&&j<63;i++) g_daw[g_ndaw][j++]=(char)tolower((unsigned char)line[i]); g_daw[g_ndaw][j]=0; g_ndaw++; } }
        fclose(f); } }
static int frag_matches(const char* exelo, const char* frag){
    int fl=(int)strlen(frag); if(fl==0) return 0;
    for(const char* p=strstr(exelo,frag); p; p=strstr(p+1,frag)){
        char b = (p==exelo)?0:p[-1];
        char a = p[fl];
        int bok = (b==0||b==' '||b=='_'||b=='-'||b=='.'||b=='('||b=='[');            /* at start or after a separator */
        int aok = (a==0||a==' '||a=='_'||a=='-'||a=='.'||a==')'||a==']'||(a>='0'&&a<='9')); /* whole word, digit allowed (e.g. Cubase14, vegas190, Sam_x64) */
        if(bok && aok) return 1; }
    return 0; }
static int exe_is_dawhost(const char* exe){ if(!g_dawLoaded) load_dawhosts(); if(g_ndaw==0) return 0;
    char low[128]; int i=0; for(;exe[i]&&i<127;i++) low[i]=(char)tolower((unsigned char)exe[i]); low[i]=0;
    for(int k=0;k<g_ndaw;k++) if(g_daw[k][0] && frag_matches(low,g_daw[k])) return 1; return 0; }
/* ---- every process in the snapshot, so parentage can be followed ---- */
static int g_blockedHosts = 0;     /* unopenable AND named in dawhost.txt -- a near-certain hit */
static int g_blockedOther = 0;     /* unopenable, not a system binary -- could be an unknown DAW */
/* More hosts than the caller's array can hold. This has to be visible, because the symptom is
   bizarre on its own: prune_injected() treats "not in hosts[]" as "process has exited", so a live
   rack that fell off the end is dropped from the injected list and re-injected every scan. The
   agent's own single-instance mutex makes the second copy unload itself at once, but "harmless" was
   too strong: until 1116 that copy cleared the running agent's probe marker on its way out, which
   silently disarmed the crash circuit breaker. It is harmless NOW, and the rack would still flicker
   in and out of the list with nothing to explain why -- so the overflow still has to be reported.
   The limit was 64, which was comfortable while only racks were listed; since plug-in hosts and
   every bridge they spawn are listed too, a full plug-in rescan alone was observed to occupy 9
   slots on one machine. */
static int g_hostsOverflow = 0;
/* Best-effort, once. Worth doing but worth being honest about what it buys: SeDebugPrivilege is
   present in an elevated administrator token yet DISABLED by default, so an ALREADY-ELEVATED
   controller gains reach here that it did not have before. A normal (non-elevated) process -- even
   for a user in the Administrators group -- gets a filtered token that does not contain the
   privilege at all, so AdjustTokenPrivileges reports ERROR_NOT_ALL_ASSIGNED and nothing changes.
   That case is NOT solvable from inside the process: the fix is to start the controller elevated,
   which is why g_blockedHosts exists to say so. No UAC prompt is raised either way. */
static void try_enable_debug_priv(void){
    HANDLE tok=NULL;
    if(!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &tok)) return;
    LUID luid; TOKEN_PRIVILEGES tp;
    if(LookupPrivilegeValueA(NULL, "SeDebugPrivilege", &luid)){
        tp.PrivilegeCount=1; tp.Privileges[0].Luid=luid; tp.Privileges[0].Attributes=SE_PRIVILEGE_ENABLED;
        AdjustTokenPrivileges(tok, FALSE, &tp, sizeof tp, NULL, NULL);   /* silent if not held */
    }
    CloseHandle(tok); }
/* Per-pid memo of "this process is not a plug-in host". The module walk is the expensive part of a
   scan -- a few hundred GetModuleFileNameExA calls per process, repeated every two seconds -- and
   almost all of it is spent re-proving that a browser or a chat client is still not a DAW. The
   module COUNT is the cheap invariant: it changes whenever anything is loaded or unloaded, so an
   unchanged count means the previous verdict still stands. Re-checked from scratch every 30s
   anyway, so a process that swapped one module for another cannot stay misjudged for long.
   One entry per PID, never two: matching on (pid, born) instead left a second row behind when a
   PID was recycled, and neg_forget() -- which drops a process once it IS judged a host -- removed
   only the first of them, so the stale row kept the new process skipped for ever. The row is
   matched by PID alone and its birth time is compared inside, which both detects the recycle and
   keeps the table one-row-per-PID. */
#define NEGCACHE 512
/* "when" drives the 30s re-check and "seen" drives eviction; they are not the same clock. A row
   that keeps being hit is not re-checked, so its "when" stays old on purpose -- using it to decide
   liveness would throw out exactly the rows that are doing their job. */
typedef struct { DWORD pid; unsigned long long born; int mods; DWORD when, seen; } NegEnt;
static NegEnt g_neg[NEGCACHE]; static int g_nneg=0;
static void neg_forget(DWORD pid){      /* ALL entries: see neg_hit */
    for(int i=0;i<g_nneg;){ if(g_neg[i].pid==pid) g_neg[i]=g_neg[--g_nneg]; else i++; } }
/* Drop rows for processes that were not in this scan -- they have exited. Without this the table
   only ever grows: a machine that starts short-lived processes (compilers, installers, scripts)
   fills all 512 rows with dead PIDs, after which nothing new can be cached and the whole
   optimisation quietly turns itself off. */
static void neg_sweep(DWORD now){
    for(int i=0;i<g_nneg;){ if(now-g_neg[i].seen > 60000) g_neg[i]=g_neg[--g_nneg]; else i++; } }
static int neg_hit(DWORD pid, unsigned long long born, int mods, DWORD now){
    for(int i=0;i<g_nneg;i++) if(g_neg[i].pid==pid){
        g_neg[i].seen=now;                  /* alive, whatever the verdict below */
        if(g_neg[i].born!=born){            /* the PID was recycled -- this is a different process */
            g_neg[i].born=born; g_neg[i].mods=mods; g_neg[i].when=now; return 0; }
        if(g_neg[i].mods==mods && now-g_neg[i].when < 30000) return 1;
        g_neg[i].mods=mods; g_neg[i].when=now; return 0; }
    if(g_nneg<NEGCACHE){ g_neg[g_nneg].pid=pid; g_neg[g_nneg].born=born;
                         g_neg[g_nneg].mods=mods; g_neg[g_nneg].when=now; g_neg[g_nneg].seen=now; g_nneg++; }
    return 0; }
#define PSNAP 1024
typedef struct { DWORD pid, ppid; unsigned long long born; int host, sysdir; char exe[64]; } PEnt;
static PEnt g_ps[PSNAP]; static int g_nps=0;
static unsigned long long proc_born(HANDLE hp){
    FILETIME c,e,k,u; if(!GetProcessTimes(hp,&c,&e,&k,&u)) return 0;
    return ((unsigned long long)c.dwHighDateTime<<32)|c.dwLowDateTime; }
static int ps_index(DWORD pid){ for(int i=0;i<g_nps;i++) if(g_ps[i].pid==pid) return i; return -1; }

static int find_hosts(Host* out, int cap) {
    int n = 0;
    g_nps = 0; g_blockedHosts = 0; g_blockedOther = 0;
    DWORD nowTick = GetTickCount();
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32 pe; pe.dwSize = sizeof pe;
    if (Process32First(snap, &pe)) {
        do {
            if(!companion_policy_process(pe.th32ProcessID,exe_is_dawhost(pe.szExeFile)))continue;
            HANDLE hp = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pe.th32ProcessID);
            if (!hp) {
                /* Could not be opened -- almost always a process at a higher integrity level than
                   this controller, i.e. a DAW started as administrator. Counted so the status bar
                   can say so: skipping it silently produced the one failure mode with no diagnosis
                   at all, where the rack is running and the controller simply never sees it.
                   Matching the name against dawhost.txt is not enough, because the case that needs
                   the message most is a DAW nobody has seen before. PROCESS_QUERY_LIMITED_INFORMATION
                   is the one right that still crosses integrity levels (it is what Task Manager uses
                   to show the names of elevated processes), and QueryFullProcessImageName accepts it,
                   so the path can be read even here -- enough to drop the services and system
                   processes that are expected to be unopenable and would otherwise make this a
                   permanent false alarm. */
                if (exe_is_dawhost(pe.szExeFile)) g_blockedHosts++;
                else {
                    HANDLE lp = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
                    if (lp) {
                        char full[MAX_PATH]=""; DWORD cch=MAX_PATH;
                        if (QueryFullProcessImageNameA(lp, 0, full, &cch) && full[0] &&
                            !icontains(full, "\\windows\\")) g_blockedOther++;
                        CloseHandle(lp);
                    }
                }
                continue;
            }
            HMODULE mods[4096]; DWORD need = 0; int real = 0;
            int knownDaw = exe_is_dawhost(pe.szExeFile);
            int vstHost = knownDaw;                      /* strict plug-in-host evidence; see below */
            /* A process whose name is already in dawhost.txt is going to be injected no matter what
               the module list says, and the only thing the scan could still change is atHost, which
               feeds learn_dawhost() -- and that returns immediately for a name already covered. So
               the scan is pure waste exactly where it costs the most: a DAW has hundreds of modules
               loaded, far more than anything else on the machine. */
            if (knownDaw) { /* skip the module walk entirely */ }
            else if (EnumProcessModulesEx(hp, mods, sizeof mods, &need, 0x03)) {
                int count = (int)(need / sizeof(HMODULE)); int cap=(int)(sizeof mods/sizeof(HMODULE)); if(count>cap) count=cap;
                /* previously judged "not a host" and nothing has loaded or unloaded since */
                if (neg_hit(pe.th32ProcessID, proc_born(hp), count, nowTick)) { CloseHandle(hp); continue; }
                /* Pass 1 -- names only, no file I/O. Also decide whether this process looks like a plug-in
                   host at all. The content scan in pass 2 reads up to 32MB of EVERY loaded .dll looking for
                   "antares"/"auto-tune", and running that against every process meant ordinary programs
                   (QQ, WeChat, ...) could match on some unrelated string and get injected: on one machine
                   5 of 6 injected processes contained no plug-in whatsoever. A process that has not loaded
                   a single VST-ish module is not a plug-in host, so pass 2 is skipped for it entirely. */
                int looksHost = exe_is_dawhost(pe.szExeFile);
                for (int i = 0; i < count && !real; i++) {
                    char path[MAX_PATH] = "";
                    if (!companion_policy_module(hp,mods[i])||!GetModuleFileNameExA(hp, mods[i], path, MAX_PATH)) continue;
                    size_t L=strlen(path);
                    int isdll = L>4 && (_stricmp(path+L-4,".dll")==0);
                    int isv3  = L>5 && (_stricmp(path+L-5,".vst3")==0);
                    if(!isdll && !isv3) continue;
                    if(icontains(path,"\\windows\\")) continue;
                    if(isv3 || icontains(path,"vstplugin") || icontains(path,"\\vst")) looksHost=1;
                    /* A STRICTER reading of the same evidence, used to decide whether to inject at
                       all rather than merely whether the content scan is worth running.
                       "\\vst" alone is too loose for that: Office loads its VSTO runtime from
                       ...\\Microsoft Shared\\VSTO\\, which contains it, so Outlook and Excel would
                       start receiving the agent -- the very class of process the module filter
                       exists to keep out. A .vst3 file, or a directory actually called VST3 or
                       VstPlugins, only turns up inside a plug-in host. */
                    if(isv3 || icontains(path,"\\vstplugin") || icontains(path,"\\vst3\\")) vstHost=1;
                    /* fast path: the name already says auto-tune */
                    if((icontains(path,"auto-tune")||icontains(path,"autotune")) && isv3){ real=1; break; }
                    /* Waves Tune / Tune Real-Time: the DSP DLL is loaded by WaveShell once an instance
                       exists, so its presence means this process really is hosting Waves Tune. */
                    if(icontains(path,"waves tune")||icontains(path,"wavestune")||icontains(path,"tune real-time")||icontains(path,"tunerealtime")){ real=1; break; }
                    /* The SHELL itself is proof enough. Waiting for the DSP module (Waves Tune
                       Real-Time.dll) was too late: WaveShell only loads that from inside
                       createInstance, so by the time it appeared the instance already existed -- and
                       a VST3 instance can only be captured AT creation, never afterwards. Injecting
                       when the shell loads puts the factory hook in place before any instance is
                       made. WaveShell only ever exists inside a plug-in host, so this cannot misfire. */
                    if(icontains(path,"waveshell")){ real=1; break; }
                }
                /* Pass 2 -- expensive content scan, only where it can plausibly pay off */
                if(!real && looksHost){
                    for (int i = 0; i < count; i++) {
                        char path[MAX_PATH] = "";
                        if (!companion_policy_module(hp,mods[i])||!GetModuleFileNameExA(hp, mods[i], path, MAX_PATH)) continue;
                        size_t L=strlen(path);
                        int isdll = L>4 && (_stricmp(path+L-4,".dll")==0);
                        int isv3  = L>5 && (_stricmp(path+L-5,".vst3")==0);
                        if(!isdll && !isv3) continue;
                        if(icontains(path,"\\windows\\")) continue;
                        if(module_is_autotune(path)){ real=1; break; }
                    }
                }
            }
            int dawmatch = (!real) && exe_is_dawhost(pe.szExeFile);   /* preload: named DAW even without an AT plugin yet */
            /* Recorded rather than emitted, because a second pass has to follow parentage below. */
            if (g_nps < PSNAP) {
                PEnt* q = &g_ps[g_nps++];
                q->pid = pe.th32ProcessID; q->ppid = pe.th32ParentProcessID;
                q->born = proc_born(hp);
                /* 3 = has a tuning plug-in loaded, 2 = exe named in dawhost.txt,
                   1 = structurally a plug-in host (see vstHost), 0 = not a host at all.
                   Tier 1 is what makes a DAW nobody has ever seen work on its FIRST session: the
                   agent arrives as soon as that DAW loads any plug-in at all, so it is already
                   resident when the user adds the tuning one -- the load notification fires, the
                   EAT hook goes in, and the first instance is caught. Without it a brand-new DAW
                   is only noticed once the tuning plug-in is already loaded, which is too late for
                   the hook and costs the user one "remove and re-add" per new DAW. */
                q->host = real ? 3 : (dawmatch ? 2 : (vstHost ? 1 : 0));
                if (q->host) neg_forget(pe.th32ProcessID);   /* no longer a negative */
                char full[MAX_PATH]=""; q->sysdir = 0;
                if (GetModuleFileNameExA(hp, NULL, full, MAX_PATH)) q->sysdir = icontains(full, "\\windows\\");
                strncpy(q->exe, pe.szExeFile, 63); q->exe[63] = 0;
            }
            CloseHandle(hp);
        } while (Process32Next(snap, &pe));
    }
    CloseHandle(snap);
    neg_sweep(nowTick);         /* rows for processes that have exited */

    /* ---- plug-in bridges, without naming a single one ----
       A 32-bit plug-in in a 64-bit host runs in a bridge process, so the agent has to be inside THAT
       process. Bridges were only found when they had already loaded a plug-in; at the moment one is
       spawned it has loaded nothing, so neither test above fires and the plug-in stays invisible.
       Naming them is not an option: every host calls its bridge something different
       (VSTBridge32_V300.exe, psrv.exe, plugin-host.exe ...) and no list can be complete.

       Parentage is the property they all share and nothing else does: a bridge is a CHILD of the
       host. The snapshot already carries th32ParentProcessID, so this costs nothing, and it cannot
       reach the processes the module filter was added to keep out -- QQ and WeChat are nobody's DAW
       child. Followed transitively, since a host may spawn a manager that spawns the bridge.

       Two guards. Windows recycles PIDs, so a child only counts if it was born AFTER its parent --
       otherwise an unrelated process could inherit a dead DAW's PID as its parent. And anything
       living under \Windows\ is skipped: conhost, WerFault and rundll32 are children of everything
       and host nothing. */
    for (int pass = 0; pass < 4; pass++) {
        int added = 0;
        for (int i = 0; i < g_nps; i++) {
            if (g_ps[i].host || g_ps[i].sysdir) continue;
            int pi = ps_index(g_ps[i].ppid);
            if (pi < 0 || !g_ps[pi].host) continue;
            if (g_ps[i].born && g_ps[pi].born && g_ps[i].born < g_ps[pi].born) continue;  /* recycled PID */
            g_ps[i].host = 1;                       /* same standing as a named DAW: inject, do not learn */
            added = 1;
        }
        if (!added) break;
    }

    /* Emitted strongest-first (an actual plug-in module beats a named DAW beats a child), because
       the caller's array is finite: filling it with freshly discovered children could otherwise
       push out the very process that has the plug-in loaded. */
    { int total = 0;
      for (int i = 0; i < g_nps; i++) if (g_ps[i].host) total++;
      g_hostsOverflow = (total > cap) ? total - cap : 0; }
    for (int want = 3; want >= 1 && n < cap; want--) {
        for (int i = 0; i < g_nps && n < cap; i++) {
            if (g_ps[i].host != want) continue;
            HANDLE hp = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, g_ps[i].pid);
            out[n].pid = g_ps[i].pid;
            out[n].wow = hp ? proc_is_wow64(hp) : 0;
            out[n].atHost = (want == 3);            /* only a real tuning module teaches dawhost.txt */
            out[n].tier   = want;
            strncpy(out[n].exe, g_ps[i].exe, 63); out[n].exe[63] = 0;
            if (hp) CloseHandle(hp);
            n++;
        }
    }
    return n;
}

static int run_hidden(const char* exe, const char* args) {   /* returns child exit code; -1 spawn fail; -2 timeout */
    char cmd[1024]; snprintf(cmd, sizeof cmd, "\"%s\" %s", exe, args);
    STARTUPINFOA si; memset(&si, 0, sizeof si); si.cb = sizeof si;
    si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi; memset(&pi, 0, sizeof pi);
    if (!CreateProcessA(NULL, cmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) return -1;
    /* Wait in slices rather than one 20s block, so closing the controller does not leave the scan
       thread stuck in here while the window is already gone. */
    DWORD w = WAIT_TIMEOUT;
    for (int sl = 0; sl < 80; sl++) {                       /* 80 x 250ms = the same 20s ceiling */
        w = WaitForSingleObject(pi.hProcess, 250);
        if (w == WAIT_OBJECT_0) break;
        if (!g_running) break;                              /* shutting down -> stop waiting */
    }
    int rc = -2;
    if (w == WAIT_OBJECT_0) { DWORD ec = (DWORD)-3; GetExitCodeProcess(pi.hProcess, &ec); rc = (int)ec; }
    else TerminateProcess(pi.hProcess, 0xDEAD);   /* a hung injector would otherwise linger forever,
                                                     still holding a handle on the target process */
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
    return rc;
}

/* injected pid tracking */
#define MAXTRACK 256
static DWORD g_injected[MAXTRACK]; static int g_ninj = 0;
static uint64_t g_bootIssued[MAXTRACK]={0};
static int is_injected(DWORD pid) { for (int i=0;i<g_ninj;i++) if (g_injected[i]==pid) return 1; return 0; }
/* The injector already tells us WHY it failed -- the controller was throwing that away and showing
   "check antivirus/exclusions" for every cause. Exit code 3 is a failed OpenProcess, i.e. almost
   always the rack running elevated while the controller is not; sending someone to hunt through
   antivirus settings for that is worse than saying nothing. Codes come from inject.cpp. */
/* Diagnostic knowledge is per process incarnation, never a sticky global
   guess. The existing scan worker alone owns this bounded set. */
struct CompanionMismatch {DWORD pid;uint64_t born;};
static CompanionMismatch g_compMismatches[MAXTRACK];
static int g_compMismatchCount=0;
static volatile LONG g_compMismatchFull=0;
static uint64_t companion_process_birth(DWORD pid){
    HANDLE process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!process)return 0;
    DWORD code=0;uint64_t born=GetExitCodeProcess(process,&code)&&code==STILL_ACTIVE?proc_born(process):0;
    CloseHandle(process);return born;
}
static int companion_status_owned(const char* path,uint64_t born){
    if(!born)return 0;WIN32_FILE_ATTRIBUTE_DATA data;
    if(!GetFileAttributesExA(path,GetFileExInfoStandard,&data))return 0;
    uint64_t written=((uint64_t)data.ftLastWriteTime.dwHighDateTime<<32)|data.ftLastWriteTime.dwLowDateTime;
    return written>=born; /* Uncertain/old PID files cannot establish a mode. */
}
static int companion_agent_header_mismatch(const char* head){
    if(!head||strncmp(head,"#b",2)||head[2]<'1'||head[2]>'9')return 0;
    const char* p=head+2;uint64_t build=0;
    while(*p>='0'&&*p<='9'){build=build*10+(unsigned)(*p++-'0');if(build>0xffffffffULL)return 0;}
    int mode=-1;
    if(!strncmp(p," m=",3)){if(p[3]!='0'&&p[3]!='1')return 0;mode=p[3]-'0';p+=4;}
    if(!((*p=='\n'&&!p[1])||(*p=='\r'&&p[1]=='\n'&&!p[2])))return 0;
    return build!=(unsigned)AT_BUILD_EXPECT||(mode>=0&&mode!=g_managed);
}
static void companion_mismatch_publish(){
    if(g_compMismatchCount<MAXTRACK)InterlockedExchange(&g_compMismatchFull,0);
    if(g_compMismatchCount)InterlockedOr(&g_compAuthError,16);else InterlockedAnd(&g_compAuthError,~16L);
}
static void companion_mismatch_clear(DWORD pid){
    int out=0;for(int i=0;i<g_compMismatchCount;i++)if(g_compMismatches[i].pid!=pid)g_compMismatches[out++]=g_compMismatches[i];
    g_compMismatchCount=out;companion_mismatch_publish();
}
static void companion_mismatch_note(DWORD pid,uint64_t born){
    if(!born)return;
    for(int i=0;i<g_compMismatchCount;i++)if(g_compMismatches[i].pid==pid){g_compMismatches[i].born=born;companion_mismatch_publish();return;}
    if(g_compMismatchCount<MAXTRACK){g_compMismatches[g_compMismatchCount].pid=pid;g_compMismatches[g_compMismatchCount++].born=born;}
    else InterlockedExchange(&g_compMismatchFull,1);
    companion_mismatch_publish();
}
static void companion_mismatch_reused(DWORD pid,uint64_t born){
    for(int i=0;i<g_compMismatchCount;i++)if(g_compMismatches[i].pid==pid&&g_compMismatches[i].born!=born){companion_mismatch_clear(pid);return;}
}
static void companion_mismatch_prune(Host* hosts,int count){
    int out=0;
    for(int i=0;i<g_compMismatchCount;i++){
        int allowed=0;for(int j=0;j<count;j++)if(hosts[j].pid==g_compMismatches[i].pid){allowed=1;break;}
        if(allowed&&companion_policy_process(g_compMismatches[i].pid)&&companion_process_birth(g_compMismatches[i].pid)==g_compMismatches[i].born)g_compMismatches[out++]=g_compMismatches[i];
    }
    g_compMismatchCount=out;companion_mismatch_publish();
}

static void mark_injected(DWORD pid) {
    if(!companion_policy_process(pid))return;
    uint64_t bootIssued=0;
    if(g_managed){
        uint64_t born=companion_process_birth(pid);companion_mismatch_reused(pid,born);
        char token[ATC_MAX_PAYLOAD+1];EnterCriticalSection(&g_compLock);strcpy(token,g_compToken);bootIssued=g_compLease.issued;LeaveCriticalSection(&g_compLock);
        int ok=atcs_pipe_bootstrap(pid,token,(unsigned)strlen(token),AT_BUILD_EXPECT);SecureZeroMemory(token,sizeof token);
        if(!ok){InterlockedOr(&g_compAuthError,8);char path[MAX_PATH],head[32]="";snprintf(path,sizeof path,"%s\\status_%lu.txt",COMMDIR,pid);FILE*f=fopen(path,"r");if(f){fgets(head,sizeof head,f);fclose(f);if(companion_agent_header_mismatch(head)&&companion_status_owned(path,born))companion_mismatch_note(pid,born);}return;}
        companion_mismatch_clear(pid);InterlockedAnd(&g_compAuthError,~8L);
    }
    if(g_ninj<MAXTRACK&&!is_injected(pid)){g_injected[g_ninj]=pid;g_bootIssued[g_ninj]=bootIssued;g_ninj++;}
}
/* Injection back-off. Without it a process we cannot inject into is retried every single scan, and
   each attempt blocks the scan thread for up to the 20s injector timeout -- one such process is
   enough to stop the status display updating at all. Three tries is plenty; a process that is going
   to accept us accepts us on the first or second. The entry is dropped when the process exits, so
   relaunching the DAW starts fresh. */
#define INJ_MAX_TRIES 3
static DWORD g_failPid[MAXTRACK]; static int g_failN[MAXTRACK]; static int g_nFail=0;
static int inject_abandoned(DWORD pid){ for(int i=0;i<g_nFail;i++) if(g_failPid[i]==pid) return g_failN[i]>=INJ_MAX_TRIES; return 0; }
static void inject_failed(DWORD pid, const char* exe){
    for(int i=0;i<g_nFail;i++) if(g_failPid[i]==pid){
        ++g_failN[i]; (void)exe; return; }
    if(g_nFail<MAXTRACK){ g_failPid[g_nFail]=pid; g_failN[g_nFail]=1; g_nFail++; } }
static void inject_ok(DWORD pid){ for(int i=0;i<g_nFail;i++) if(g_failPid[i]==pid){
        for(int k=i;k<g_nFail-1;k++){ g_failPid[k]=g_failPid[k+1]; g_failN[k]=g_failN[k+1]; } g_nFail--; return; } }
static void prune_injected(Host* hosts, int nh) {
    if(g_managed)companion_mismatch_prune(hosts,nh);
    int w=0; for (int i=0;i<g_ninj;i++){ int alive=0; for(int j=0;j<nh;j++) if(hosts[j].pid==g_injected[i]){alive=1;break;} if(alive){g_injected[w]=g_injected[i];g_bootIssued[w]=g_bootIssued[i];w++;} } g_ninj=w;
    { int v=0; for(int i=0;i<g_nFail;i++){ int alive=0; for(int j=0;j<nh;j++) if(hosts[j].pid==g_failPid[i]){alive=1;break;}
        if(alive){ g_failPid[v]=g_failPid[i]; g_failN[v]=g_failN[i]; v++; } } g_nFail=v; }
}

/* auto-learn: remember a real Auto-Tune host's exe so next time we inject proactively (catch-on-load) */
static void learn_dawhost(const char* exe){
    if(!g_dawLoaded) load_dawhosts();
    char low[128]; int i=0; for(;exe[i]&&i<127;i++) low[i]=(char)tolower((unsigned char)exe[i]); low[i]=0;
    for(int k=0;k<g_ndaw;k++) if(g_daw[k][0] && frag_matches(low,g_daw[k])) return;   /* already covered */
    /* The file grows by one line per new DAW and is read back with a 96-line ceiling, so after
       enough different DAWs the most recently learned ones stop being read -- they would then need a
       remove-and-re-add on every launch, with nothing to explain why. Say so instead of silently
       dropping them; the 49 seeded defaults sit at the top of the file and are never the ones lost. */
    if(g_ndaw>=MAXDAW){ g_dawFull=1; return; }   /* 标志位而非一次性提示:直接 set_status 会在下一次状态刷新(2 秒)被覆盖掉 */
    if(g_ndaw<MAXDAW){ snprintf(g_daw[g_ndaw],64,"%s",low); g_ndaw++; }
    char pth[MAX_PATH]; snprintf(pth,sizeof pth,"%s\\dawhost.txt",RTDIR_PARENT());
    FILE* a=fopen(pth,"a"); if(a){ fprintf(a,"%s\n",low); fclose(a); }
}
/* FAST proactive inject: light process-NAME scan (no module enumeration) to inject into a DAW the
   instant it launches -- so the agent (with its catch-on-load hook) is present BEFORE 电音11 loads. */
static void fast_proactive_inject(){
    if(g_managed)InterlockedAnd(&g_compAuthError,~32L);
    HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0); if(snap==INVALID_HANDLE_VALUE) return;
    PROCESSENTRY32 pe; pe.dwSize=sizeof pe;
    if(Process32First(snap,&pe)){ do{
        if(is_injected(pe.th32ProcessID)) continue;
        if(inject_abandoned(pe.th32ProcessID)) continue;
        if(!exe_is_dawhost(pe.szExeFile)) continue;                 /* only known/learned DAWs */
        if(!companion_policy_process(pe.th32ProcessID,1))continue;
        HANDLE hp=OpenProcess(PROCESS_QUERY_INFORMATION,FALSE,pe.th32ProcessID); int wow=0; if(hp){ wow=proc_is_wow64(hp); CloseHandle(hp);} 
        const char* inj=(wow==1)?INJ32P:INJ64P; const char* agt=(wow==1)?AGENT32P:AGENT64P;
        char args[1024]; snprintf(args,sizeof args,"--pid %lu --dll \"%s\"",pe.th32ProcessID,agt);
        int rc=run_hidden(inj,args);
        if(rc==0||rc==11){ mark_injected(pe.th32ProcessID); inject_ok(pe.th32ProcessID); learn_dawhost(pe.szExeFile); }
        else { inject_failed(pe.th32ProcessID, pe.szExeFile); }   /* agent now in the DAW, waiting for 电音11 to load */
    } while(Process32Next(snap,&pe)); }
    CloseHandle(snap);
}
/* Read agent status on the scan thread; publish only data consumed by parent IPC. */
/* Parse one status record into (leaf, label, instance id, capabilities). Pulled out of read_status
   so the agent -> controller -> agent round trip can be tested ACROSS the seam rather than one side
   at a time. Returns 1 when the record was usable. Modifies ln (truncates at the metadata mark). */
static int parse_status_line(char* ln, char* leafOut, char* labelOut, unsigned* idOut, char* capsOut){
    unsigned lid=0; char lcaps[16]="KSRHVA";   /* no metadata (older agent) -> assume everything */
    { char* meta=strchr(ln,'\x01');
      if(meta){ *meta=0; lid=(unsigned)strtoul(meta+1,NULL,16);
                char* sp=strchr(meta+1,' ');
                if(sp){ int q=0; sp++; while(sp[q] && sp[q]!=' ' && q<15){ lcaps[q]=sp[q]; q++; } lcaps[q]=0; } } }
    char* bar=strstr(ln," | ");                /* agent writes "proc | leaf  Key=..." */
    if(!bar) return 0;
    char* lf=bar+3; char* dd=strstr(lf,"  ");
    int leaflen=dd?(int)(dd-lf):(int)strlen(lf);
    int lbllen =dd?(int)(dd-ln):(int)strlen(ln);
    if(leaflen<=0 || leaflen>=96) return 0;
    memcpy(leafOut,lf,(size_t)leaflen); leafOut[leaflen]=0;
    if(lbllen>159) lbllen=159;
    memcpy(labelOut,ln,(size_t)lbllen); labelOut[lbllen]=0;
    *idOut=lid; snprintf(capsOut,16,"%s",lcaps);
    return 1; }
/* The pause acknowledgement is scoped to the same signed session and to the
   exact or a later pause barrier. This is readback, never an authorization grant. */
static int companion_pause_ack(const char* content,const char* sid,uint64_t minimum){
    if(!content||!sid||strlen(sid)!=32||!minimum)return 0;
    while(*content){const char* end=strchr(content,'\n');if(!end)return 0;
        if(end-content>=6&&!memcmp(content,"#pause",6)){
            const char* q=content;const char* prefix="#pause sid=";size_t n=strlen(prefix);
            if((size_t)(end-q)<n+32+5+1+8||memcmp(q,prefix,n))return 0;q+=n;
            if(memcmp(q,sid,32)||memcmp(q+32," seq=",5))return 0;q+=37;
            if(*q<'1'||*q>'9')return 0;uint64_t seq=0;
            while(q<end&&*q>='0'&&*q<='9'){unsigned d=(unsigned)(*q++-'0');if(seq>(UINT64_MAX-d)/10)return 0;seq=seq*10+d;}
            return end-q==8&&!memcmp(q," state=1",8)&&seq>=minimum;
        }
        content=end+1;
    }return 0;
}
static void read_status(){
    /* each host's agent writes status_<pid>.txt; aggregate the ones for CURRENTLY-injected hosts
       (so multiple racks/bridges don't clobber each other), and delete files of hosts that are gone. */
    int oldAgent=0, torn=0, aggregateFull=0;
    int captured=0,pending=0,confirmed=0,hasR=0,strength=-1,families=0,pauseSeen=0;
    int paused=0;uint64_t pauseSequence=0;char pauseSid[33];
    ATC_Apply goal;int goalValid;uint64_t generation;unsigned long scopePid;unsigned scopeId;char scopeLeaf[96];
    EnterCriticalSection(&g_compLock);goal=g_compGoal;goalValid=g_compGoalValid;generation=g_compGeneration;
    scopePid=g_compScopePid;scopeId=g_compScopeId;strcpy(scopeLeaf,g_compScopeLeaf);paused=g_compPaused;pauseSequence=g_compPauseSequence;strcpy(pauseSid,g_compPauseSid);LeaveCriticalSection(&g_compLock);
    struct StatusInstance { unsigned long pid; char leaf[96]; char label[160]; unsigned id; char caps[16]; };
    static StatusInstance tmp[MAXINST]; int ti=0;
    char pat[MAX_PATH]; snprintf(pat,sizeof pat,"%s\\status_*.txt",COMMDIR);
    WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA(pat,&fd);
    if(hf!=INVALID_HANDLE_VALUE){ do{
        if(strncmp(fd.cFileName,"status_",7)!=0) continue;
        unsigned long pid=strtoul(fd.cFileName+7,NULL,10);
        char fp[MAX_PATH]; snprintf(fp,sizeof fp,"%s\\%s",COMMDIR,fd.cFileName);
        if(pid==0 || !is_injected((DWORD)pid)){
            /* A live allowed old/mismatched agent may have no new bootstrap.
               Preserve its existing diagnostic header; never count it as current. */
            if(pid&&g_managed&&companion_policy_process((DWORD)pid)&&file_owner_alive(fp,pid))continue;
            DeleteFileA(fp);continue;
        }
        FILE* f=fopen(fp,"r");
        /* An agent renaming a fresh copy over the file right now makes the open fail with a sharing violation.
           Skipping the file would drop that rack's instances for one poll: the Target list rebuilds without them
           and the user's selection falls back to "all" -- the very thing atomic publishing was meant to prevent.
           Treat it as a half-written read: keep the current state, look again next poll (1162). */
        if(!f && GetLastError()==ERROR_SHARING_VIOLATION){ torn=1; break; }
        if(f){ static char b[8192]; size_t n=fread(b,1,sizeof b-1,f); b[n]=0; fclose(f);
            /* Same race as the scale lists, with agents before 1078 (they rewrote this in place). A torn read would show
               a mangled instance name with no metadata, which changes the instance signature and
               rebuilds the Target list -- losing the user's selection for a glitch that corrects
               itself anyway. Abandon the whole pass instead and keep the current state. */
            if(n==0 || b[n-1]!='\n'){ torn=1; break; }
            char* content=b;int currentAgent=0;
            if(strncmp(b,"#b",2)==0){ int bb=atoi(b+2);char* headerEnd=strchr(b,'\n');int managedMode=headerEnd&&headerEnd-b>=4&&!memcmp(headerEnd-4," m=1",4);currentAgent=bb==AT_BUILD_EXPECT&&managedMode==g_managed; if(!currentAgent){ oldAgent=1; } char* nl=strchr(b,'\n'); content=nl?nl+1:(b+(int)n); }
            else if(b[0]) oldAgent=1;                         /* no marker = older agent */
            if(currentAgent&&paused&&companion_pause_ack(content,pauseSid,pauseSequence))pauseSeen++;
            char* lp=content;   /* parse each plugin line into (pid, leaf, label, id, caps) */
            while(*lp){ char* nl=strchr(lp,'\n'); int ll = nl?(int)(nl-lp):(int)strlen(lp);
                if(ll>0){ char ln[STATUS_LINE_PARSE]; int cp=ll<STATUS_LINE_PARSE-1?ll:STATUS_LINE_PARSE-1; memcpy(ln,lp,cp); ln[cp]=0;
                    /* everything after \x01 is machine-readable metadata, never shown to the user */
                    int wasPending=strstr(ln,"[[PENDING]]")!=NULL;
                    const char* readback=strstr(ln,"  Key=");
                    int follows=readback&&goalValid&&currentAgent&&atc_confirmed(goal.key,goal.scale,readback+2);
                    StatusInstance item={};
                    if(parse_status_line(ln, item.leaf, item.label, &item.id, item.caps)){
                        item.pid=pid;
                        if(!scopePid||(scopePid==pid&&scopeId==item.id&&!strcmp(scopeLeaf,item.leaf))){
                            if(wasPending)pending++;
                            else if(readback){captured++;if(follows&&item.id&&strchr(item.caps,'K')&&strchr(item.caps,'S'))confirmed++;
                                if(currentAgent&&item.id&&strchr(item.caps,'R')){
                                    hasR=1;const char* feel=strstr(readback,"  Rtn=");int family=0;
                                    if(!feel){feel=strstr(readback,"  Spd=");family=1;}
                                    if(feel){int v=atoi(feel+6);const char*q=feel+6;while(*q>='0'&&*q<='9')q++;if(q>feel+6&&*q=='%'&&v>=0&&v<=100){families|=family?2:1;if(strength<0)strength=family?v*10:1000-v*10;}}
                                }
                            }
                        }
                        if(ti<MAXINST)tmp[ti++]=item;
                        else aggregateFull=1; /* A valid instance exceeded Target capacity; still count its readback. */
                    } }
                if(!nl) break; lp=nl+1; }
        }
    } while(FindNextFileA(hf,&fd)); FindClose(hf); }
    if(torn) return;   /* a status file was caught mid-write -- keep the current state */
    int published=0;EnterCriticalSection(&g_compLock);
    if(generation==g_compGeneration){published=1;g_aggFull=aggregateFull;InterlockedExchange(&g_compCaptured,captured);InterlockedExchange(&g_compPending,pending);InterlockedExchange(&g_compConfirmed,confirmed);InterlockedExchange(&g_compHasR,hasR);InterlockedExchange(&g_compStrength,strength);InterlockedExchange(&g_compMixedFamily,families==3);}
    if(paused&&g_compPaused&&pauseSequence==g_compPauseSequence&&!strcmp(pauseSid,g_compPauseSid))g_compPauseAcknowledged=pauseSequence&&pauseSeen==g_ninj;
    LeaveCriticalSection(&g_compLock);InterlockedExchange(&g_compOld,oldAgent);
    static uint64_t loggedGeneration=0;if(g_managed&&published&&generation!=loggedGeneration&&captured>0&&confirmed==captured){loggedGeneration=generation;companion_log("confirmed",goal.key,goal.scale,goal.retune);}
    /* Publish the instance set without GUI state. The old scope, if restored
       from this parent's recovery record, stays bound to its exact instance. */
    { static char sig[INSTSIG_SZ]; int so=0; sig[0]=0;
      for(int i=0;i<ti && so<(int)sizeof sig-130;i++)so+=snprintf(sig+so,sizeof sig-so,"%lu:%08X:%s|",tmp[i].pid,tmp[i].id,tmp[i].leaf);
      if(strcmp(sig,g_instSig)!=0){
        InterlockedExchange(&g_compRebuilding,1);
        strncpy(g_instSig,sig,sizeof g_instSig-1);g_instSig[sizeof g_instSig-1]=0;
        EnterCriticalSection(&g_compLock);memcpy(g_insts,tmp,sizeof(g_insts[0])*ti);g_ninst=ti;
        int found=!g_compScopePid;
        for(int i=0;i<g_ninst&&!found;i++)found=g_insts[i].pid==g_compScopePid&&g_insts[i].id==g_compScopeId&&!strcmp(g_insts[i].leaf,g_compScopeLeaf);
        if(!found){g_compScopePid=0;g_compScopeId=0;g_compScopeLeaf[0]=0;g_compGeneration++;InterlockedExchange(&g_compConfirmed,0);}
        int needReplay=g_compGoalValid;LeaveCriticalSection(&g_compLock);
        InterlockedExchange(&g_compRebuilding,0);
        if(g_managed&&g_authorized&&needReplay){InterlockedExchange(&g_compNeedReplay,1);PostMessageA(g_mainWindow,ATC_APPLY_MESSAGE,0,0);}
      } }

}
static ATC_NOINLINE DWORD WINAPI scan_thread(LPVOID) {
    ATC_SPROTECT_BEGIN_1();
    if(g_managed && (!g_authorized || !g_runtimeReady)) return 0;
    DWORD lastHeavy=0;
    try_enable_debug_priv();   /* no-op unless this controller is already elevated */
    while (g_running) {
        if(g_managed && !g_authorized){Sleep(100);continue;}
        if(g_managed){
            if(InterlockedExchange(&g_compReconnectAll,0))g_ninj=0;
            char token[ATC_MAX_PAYLOAD+1];uint64_t issued;EnterCriticalSection(&g_compLock);strcpy(token,g_compToken);issued=g_compLease.issued;LeaveCriticalSection(&g_compLock);
            for(int i=0;i<g_ninj&&g_running&&g_authorized;i++)if(companion_policy_process(g_injected[i])&&g_bootIssued[i]!=issued){
                if(atcs_pipe_bootstrap(g_injected[i],token,(unsigned)strlen(token),AT_BUILD_EXPECT)){g_bootIssued[i]=issued;InterlockedExchange(&g_compNeedReplay,1);}
                else InterlockedOr(&g_compAuthError,8);
            }
            SecureZeroMemory(token,sizeof token);
            if(InterlockedCompareExchange(&g_compNeedReplay,0,0))PostMessageA(g_mainWindow,ATC_APPLY_MESSAGE,0,0);
        }
        fast_proactive_inject();
        read_status();                         /* fast: catch a newly-launched DAW within ~300ms */
        if(GetTickCount()-lastHeavy < 2000){ for(int t=0;t<3 && g_running;t++) Sleep(100); continue; }
        lastHeavy=GetTickCount();
        ensure_data_dir();
        static Host hosts[256];           /* static: 256 entries is too much for the thread stack */
        int nh = find_hosts(hosts, 256);
        int failed = 0;
        for (int i = 0; i < nh; i++) {
            if(!companion_policy_process(hosts[i].pid))continue;
            if (!is_injected(hosts[i].pid)) {
                const char* inj = (hosts[i].wow == 1) ? INJ32P : INJ64P;
                const char* agt = (hosts[i].wow == 1) ? AGENT32P : AGENT64P;
                char args[1024]; snprintf(args, sizeof args, "--pid %lu --dll \"%s\"", hosts[i].pid, agt);
                int rc = run_hidden(inj, args);
                if (rc == 0 || rc == 11){ mark_injected(hosts[i].pid); inject_ok(hosts[i].pid); if(hosts[i].atHost) learn_dawhost(hosts[i].exe); }
                else { failed++; inject_failed(hosts[i].pid, hosts[i].exe); }   /* record WHY, and stop retrying forever */
            }
        }
        prune_injected(hosts, nh);
        /* Count RACKS, not processes. nh is every process the agent was put into, and since 1107
           that includes any plug-in host plus every bridge it spawns -- a full plug-in rescan was
           observed to occupy 9 of them on one machine, which would have read "Connected 9/9
           host(s)" with exactly one rack in sight. Tier 1 (a bare plug-in host, or a bridge) is an
           implementation detail; tier 2+ is what a user would call a rack: either a tuning plug-in
           is loaded in it, or it is a DAW we know by name. */
        int active = 0, racks = 0;
        for (int i = 0; i < nh; i++) if (hosts[i].tier >= 2) {
            racks++; if (is_injected(hosts[i].pid)) active++; }
        InterlockedExchange(&g_compRacks,racks);
        for (int t=0; t<3 && g_running; t++) Sleep(100);
    }
    return 0;
}

static DWORD companion_creator_pid(){
    DWORD pid=0; HANDLE ss=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
    if(ss!=INVALID_HANDLE_VALUE){ PROCESSENTRY32 pe; memset(&pe,0,sizeof pe); pe.dwSize=sizeof pe;
        if(Process32First(ss,&pe)) do { if(pe.th32ProcessID==GetCurrentProcessId()){pid=pe.th32ParentProcessID;break;} }while(Process32Next(ss,&pe)); CloseHandle(ss); }
    return pid;
}
static int companion_parent_security(HANDLE parent){
    HANDLE a=NULL,b=NULL; if(!OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&a))return 0;
    if(!OpenProcessToken(parent,TOKEN_QUERY,&b)){CloseHandle(a);return 0;}
    unsigned char ua[1024],ub[1024];DWORD na=0,nb=0,sa=0,sb=0;TOKEN_ELEVATION ea,eb;DWORD z=0;
    int ok=GetTokenInformation(a,TokenUser,ua,sizeof ua,&na)&&GetTokenInformation(b,TokenUser,ub,sizeof ub,&nb)
        &&EqualSid(((TOKEN_USER*)ua)->User.Sid,((TOKEN_USER*)ub)->User.Sid)
        &&GetTokenInformation(a,TokenSessionId,&sa,sizeof sa,&z)&&GetTokenInformation(b,TokenSessionId,&sb,sizeof sb,&z)&&sa==sb
        &&GetTokenInformation(a,TokenElevation,&ea,sizeof ea,&z)&&GetTokenInformation(b,TokenElevation,&eb,sizeof eb,&z)
        &&ea.TokenIsElevated&&eb.TokenIsElevated;
    CloseHandle(a);CloseHandle(b);return ok;
}
/* VMP integration seam: the release build can selectively protect this verifier.
   Production key generation supplies only a public modulus; private signing keys
   stay at the server. There is no development-token or boolean authorization bypass. */
/* Exact raw bytes from the project's SP_Begin_1.Image.dat. SP_End.Image.dat
   is empty, so no invented end marker is emitted. This is an SProtect converter
   marker, not an already-applied VMP protection or ownership watermark.
   Windows x86/x64: push ax-register; two harmless mov eax immediates; pop.
   It belongs only to this low-frequency verifier, never an audio or scan loop. */
#define ATC_SPROTECT_BEGIN_1() __asm__ __volatile__(".byte 0x50,0x90,0xB8,0x59,0x34,0x90,0xE8,0x90,0xB8,0x86,0x5A,0x62,0xDF,0x90,0x58" ::: "memory")
#define ATC_NOINLINE __attribute__((noinline))
static ATC_NOINLINE int companion_verify_server_token(const char* token,unsigned len){
    ATC_SPROTECT_BEGIN_1();
    ATCS_Claims lease;if(!atcs_verify_token(token,len,g_parentPid,g_compDevice,&lease)){InterlockedOr(&g_compAuthError,1);return 0;}
    EnterCriticalSection(&g_compLock);
    int same=g_compLease.expires&&atcs_claims_equal(&lease,&g_compLease);
    if(!same&&g_compLease.expires&&lease.issued<=g_compLease.issued){LeaveCriticalSection(&g_compLock);SecureZeroMemory(&lease,sizeof lease);InterlockedOr(&g_compAuthError,2);return 0;}
    if(!g_authorized)InterlockedExchange(&g_compReconnectAll,1);
    if(!same||!g_authorized){g_compPauseAcknowledged=0;g_compPauseSequence=0;g_compPauseSid[0]=0;}
    if(!same){g_compLease=lease;g_lastSequence=0;g_compCommandSequence=0;}
    memcpy(g_sessionKey,lease.key,32);memcpy(g_compToken,token,len);g_compToken[len]=0;
    LeaveCriticalSection(&g_compLock);SecureZeroMemory(&lease,sizeof lease);InterlockedAnd(&g_compAuthError,~7L);InterlockedExchange(&g_authorized,1);return 1;
}
static void companion_clear_goal(){
    EnterCriticalSection(&g_compLock);g_compGoal.key=g_compGoal.scale=g_compGoal.retune=-1;g_compGoalValid=0;InterlockedExchange(&g_compConfirmed,0);g_compLastSentKeyScale=0;g_compNeedReplay=0;g_compRetry=0;g_compScopePid=g_compScopeId=0;g_compScopeLeaf[0]=0;g_compGeneration++;LeaveCriticalSection(&g_compLock);
}
static void companion_forget_saved_goal(){
    HKEY key;if(RegOpenKeyExA(HKEY_CURRENT_USER,"SOFTWARE\\DianYinAssistant\\RackLink",0,KEY_SET_VALUE,&key)==ERROR_SUCCESS){RegDeleteValueA(key,"ControllerGoal");RegCloseKey(key);}
}
static LRESULT companion_status_reply(int expectedKey=-1,int expectedScale=-1){
    unsigned long r=0x80000000UL;
    if(!g_authorized)r|=0x40000000UL;
    if(g_compOld||(g_compAuthError&16))r|=0x20000000UL;if(g_cmdWriteFail)r|=0x10000000UL;if(g_agentMissing||g_agentStale)r|=0x08000000UL;
    if(g_blockedHosts||g_blockedOther)r|=0x04000000UL;if(g_hostsOverflow||InterlockedCompareExchange(&g_compMismatchFull,0,0))r|=0x02000000UL;
    EnterCriticalSection(&g_compLock);LONG racks=g_compRacks,cap=g_compCaptured,pend=g_compPending,conf=g_compConfirmed;
    if(g_aggFull)r|=0x02000000UL; /* Same published status generation as these counts. */
    if(expectedKey>=0&&(!g_compGoalValid||g_compGoal.key!=expectedKey||g_compGoal.scale!=expectedScale))conf=0;LeaveCriticalSection(&g_compLock);
    if(racks>127||cap>63||pend>63||conf>63)r|=0x02000000UL;
    if(racks>127)racks=127;if(cap>63)cap=63;if(pend>63)pend=63;if(conf>63)conf=63;
    r|=((unsigned long)racks<<18)|((unsigned long)cap<<12)|((unsigned long)pend<<6)|(unsigned long)conf;
    return (LRESULT)(LONG)r; /* xhh is 32 bit, including when this process is 64 bit. */
}
static ATC_NOINLINE LRESULT companion_copydata(HWND h,WPARAM wp,LPARAM lp){
    ATC_SPROTECT_BEGIN_1();
    if(!g_managed)return 0;
    COPYDATASTRUCT* cds=(COPYDATASTRUCT*)lp;ATC_Packet packet;
    if(!cds||cds->dwData!=ATC_COPYDATA_ID||!atc_parse_packet(cds->lpData,(unsigned)cds->cbData,&packet))return ATC_REPLY_BAD_PACKET;
    DWORD sender=0;GetWindowThreadProcessId((HWND)wp,&sender);
    if(!g_parent||sender!=g_parentPid||WaitForSingleObject(g_parent,0)!=WAIT_TIMEOUT)return ATC_REPLY_WRONG_PARENT;
    if(packet.op==ATC_HELLO){if(packet.payload_len)return ATC_REPLY_BAD_PACKET;return (ATC_PROTOCOL_VERSION<<16)|ATC_CONTROLLER_VERSION;}
    if(packet.op==ATC_STATUS){
        if(!packet.payload_len)return companion_status_reply();
        if(packet.payload_len>=10&&packet.payload_len<=11&&!memcmp(packet.payload,"expect=",7)){
            unsigned key=0,pos=7;if(packet.payload[pos]<'0'||packet.payload[pos]>'9')return ATC_REPLY_BAD_PACKET;
            key=(unsigned)(packet.payload[pos++]-'0');if(pos<packet.payload_len&&packet.payload[pos]>='0'&&packet.payload[pos]<='9'){if(key!=1)return ATC_REPLY_BAD_PACKET;key=key*10+(unsigned)(packet.payload[pos++]-'0');}
            if(key>11||pos+2!=packet.payload_len||packet.payload[pos++]!=':'||packet.payload[pos]<'0'||packet.payload[pos]>'2')return ATC_REPLY_BAD_PACKET;
            return companion_status_reply((int)key,packet.payload[pos]-'0');
        }
        if(packet.payload_len==6&&!memcmp(packet.payload,"paused",6)){EnterCriticalSection(&g_compLock);unsigned long r=0x80000000UL;if(!g_authorized||atcs_now()>=g_compLease.expires||!g_compPaused||!g_compPauseAcknowledged)r|=0x40000000UL;LeaveCriticalSection(&g_compLock);return (LRESULT)(LONG)r;}
        if(packet.payload_len==4&&!memcmp(packet.payload,"feel",4)){unsigned long r=0x80000000UL;if(!g_authorized)r|=0x40000000UL;if(g_compHasR)r|=0x20000000UL;if(g_compStrength>=0){r|=0x10000000UL;r|=(unsigned long)g_compStrength;}if(g_compMixedFamily)r|=0x08000000UL;return (LRESULT)(LONG)r;}
        if(packet.payload_len==6&&!memcmp(packet.payload,"errors",6))return (LRESULT)(LONG)(0x80000000UL|(unsigned long)g_compAuthError);
        return ATC_REPLY_BAD_PACKET;
    }
    if(packet.op==ATC_AUTHORIZE){
        if(!companion_verify_server_token(packet.payload,packet.payload_len))return ATC_REPLY_AUTH_UNAVAILABLE;
        PostMessageA(h,ATC_START_MESSAGE,0,0);return ATC_REPLY_OK;
    }
    if(!g_authorized||atcs_now()>=g_compLease.expires)return ATC_REPLY_AUTH_REQUIRED;
    if(!atc_verify_packet(&packet,g_sessionKey))return ATC_REPLY_BAD_MAC;
    ATC_Apply target;
    if(packet.op==ATC_APPLY||packet.op==ATC_FEEL){if(!atc_parse_apply(packet.payload,packet.payload_len,packet.op==ATC_FEEL,&target))return ATC_REPLY_BAD_PACKET;}
    else if(packet.payload_len)return ATC_REPLY_BAD_PACKET;
    if((!g_runtimeReady||g_compQueuedCommand==2)&&(packet.op==ATC_APPLY||packet.op==ATC_FEEL))return ATC_REPLY_AUTH_REQUIRED;
    if(g_compQueuedCommand==2&&packet.op==ATC_PAUSE)return ATC_REPLY_AUTH_REQUIRED;
    if(g_compPaused&&(packet.op==ATC_FEEL||(packet.op==ATC_APPLY&&!g_compPauseAcknowledged)))return ATC_REPLY_AUTH_REQUIRED;
    if(!atc_accept_sequence(packet.seq,&g_lastSequence))return ATC_REPLY_REPLAY;
    if(packet.op==ATC_APPLY||packet.op==ATC_FEEL){
        EnterCriticalSection(&g_compLock);
        if(packet.op==ATC_APPLY){g_compPaused=0;g_compPauseAcknowledged=0;g_compReceivedAt=GetTickCount();g_compGoal.key=target.key;g_compGoal.scale=target.scale;g_compGoalValid=1;g_compGeneration++;InterlockedExchange(&g_compConfirmed,0);}
        if(target.retune>=0)g_compGoal.retune=target.retune;
        LeaveCriticalSection(&g_compLock);
        /* Coalesce feel into a queued apply, never downgrade a key/scale change. */
        if(packet.op==ATC_APPLY||g_compQueuedCommand<0)g_compQueuedCommand=packet.op==ATC_FEEL?0:1;
        PostMessageA(h,ATC_APPLY_MESSAGE,0,0);return ATC_REPLY_OK;
    }
    if(packet.op==ATC_PAUSE){
        if(!g_compPaused){companion_clear_goal();EnterCriticalSection(&g_compLock);g_compPaused=1;g_compPauseSequence=0;g_compPauseAcknowledged=0;g_compPauseSid[0]=0;LeaveCriticalSection(&g_compLock);}
        if(!g_compPauseSequence){g_compQueuedCommand=3;PostMessageA(h,ATC_APPLY_MESSAGE,0,0);}
        return ATC_REPLY_OK;
    }
    if(packet.op==ATC_EJECT){g_compQueuedCommand=2;PostMessageA(h,ATC_APPLY_MESSAGE,0,0);return ATC_REPLY_OK;}
    if(packet.op==ATC_QUIT){g_compForceExit=1;PostMessageA(h,WM_CLOSE,0,0);return ATC_REPLY_OK;}
    return ATC_REPLY_BAD_PACKET;
}
/* Always retain the Target selector. Family direction is resolved from that
   target, or the first captured instance in All mode. Unknown families must not
   send a guessed speed value. Mixed-family All mode uses the primary instance,
   as specified; the diagnostic states which family supplied the direction. */
static void companion_write_goal(int keyScale){
    if(!g_managed||!g_authorized||!g_runtimeReady||g_compPaused)return;
    if(g_compRebuilding){InterlockedExchange(&g_compNeedReplay,1);return;}
    ATC_Apply goal;int valid,have=0;unsigned long pid=0;unsigned id=0;char leaf[96]="",caps[16]="";
    EnterCriticalSection(&g_compLock);goal=g_compGoal;valid=g_compGoalValid;
    int ti=g_compScopePid?1:0,idx=0;
    if(ti){idx=-1;for(int i=0;i<g_ninst;i++)if(g_insts[i].pid==g_compScopePid&&g_insts[i].id==g_compScopeId&&!strcmp(g_insts[i].leaf,g_compScopeLeaf)){idx=i;break;}}
    if(idx>=0&&idx<g_ninst){pid=g_insts[idx].pid;id=g_insts[idx].id;strcpy(leaf,g_insts[idx].leaf);strcpy(caps,g_insts[idx].caps);have=1;}
    LeaveCriticalSection(&g_compLock);
    char line[320];int o=0;line[0]=0;
    if(keyScale&&valid)o+=snprintf(line+o,sizeof line-o,"key=%d|scale=%s",goal.key,SCALES[goal.scale]);
    if(goal.retune>=0){
        int antares=atc_retune(goal.retune,0),speed=atc_retune(goal.retune,1);
        o+=snprintf(line+o,sizeof line-o,"%sretune=%d.%03d|speed=%d.%03d",o?"|":"",antares/1000,antares%1000,speed/1000,speed%1000);
        OutputDebugStringA("xhh companion: family envelope Antares=1-strength, Waves/T-Pain=strength; agent selects actual discovered family\n");
    }
    if(!o)return;
    if(ti>0&&(!have||!companion_policy_process(pid)))return;
    if(ti>0&&have)o+=snprintf(line+o,sizeof line-o,"|target=%lu:|tid=%08X",pid,id);
    o+=snprintf(line+o,sizeof line-o,"|t=%lu\n",GetTickCount());
    g_cmdWriteFail=!write_ctl_file(CMDFILE,line,(DWORD)strlen(line));
    if(keyScale){g_compSentAt=GetTickCount();g_compLastSentKeyScale=1;}
    companion_log(g_cmdWriteFail?"push_failed":"pushed",goal.key,goal.scale,goal.retune);
}
static void companion_write_pause(){
    if(!g_managed||!g_authorized||!g_runtimeReady||!g_compPaused||g_compPauseSequence)return;
    char line[64],sid[33];uint64_t seq=0;EnterCriticalSection(&g_compLock);strcpy(sid,g_compLease.sid);LeaveCriticalSection(&g_compLock);
    snprintf(line,sizeof line,"pause=1|t=%lu\n",GetTickCount());
    int ok=write_ctl_file(CMDFILE,line,(DWORD)strlen(line),&seq);g_cmdWriteFail=!ok;
    if(ok){EnterCriticalSection(&g_compLock);g_compPauseSequence=seq;strcpy(g_compPauseSid,sid);g_compPauseAcknowledged=0;LeaveCriticalSection(&g_compLock);}
}
static LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    switch (m) {
    case ATC_START_MESSAGE: {
        if(!g_authorized)return 0;
        if(!g_runtimeReady){ensure_runtime();g_runtimeReady=1; /* Fresh parent APPLY is the only goal source; never restore a stale registry goal. */
            g_scanTh=CreateThread(NULL,0,scan_thread,NULL,0,NULL);
        }else{
            /* Renew already resident agents through the authenticated pipe; never
               unload them, so captured VST3 objects survive controller renewal. */
            InterlockedExchange(&g_compNeedReplay,1);
        }
        if(g_compPaused){g_compNeedReplay=0;g_compQueuedCommand=3;PostMessageA(h,ATC_APPLY_MESSAGE,0,0);}
        companion_log("authorized",-1,-1,-1);
        return 0;
    }
    case WM_COPYDATA:return companion_copydata(h,wp,lp);
    case ATC_APPLY_MESSAGE: {
        /* This message only wakes the queue. External PostMessage calls cannot
           choose an operation or create authenticated work by guessing its ID. */
        int command=g_compQueuedCommand;g_compQueuedCommand=-1;
        if(command<0&&InterlockedExchange(&g_compNeedReplay,0))command=1;
        if(command<0)return 0;
        if(command==3){companion_forget_saved_goal();companion_write_pause();return 0;}
        if(g_compPaused&&command!=2)return 0;
        if(command==2){companion_clear_goal();companion_forget_saved_goal();if(g_authorized&&g_runtimeReady){write_ctl_file(EJECTFLAG,"1\n",2);if(!g_managed)eject_legacy_agents();InterlockedExchange(&g_authorized,0);atcs_random(g_sessionKey,sizeof g_sessionKey);}return 0;}
        if(command==1){g_compRetry=0;ATC_Apply goal;int valid;EnterCriticalSection(&g_compLock);goal=g_compGoal;valid=g_compGoalValid;LeaveCriticalSection(&g_compLock);
            /* A replay before the first automatic goal is feel-only. */
            if(!(valid&&goal.key>=0&&goal.key<12&&goal.scale>=0&&goal.scale<3))command=0;
        }
        companion_write_goal(command!=0);return 0;
    }
    case WM_TIMER:
        if(g_managed&&wp==ATC_PARENT_TIMER){
            if(g_compPaused&&!g_compPauseSequence&&g_authorized)companion_write_pause();
            if(g_authorized&&atcs_now()>=g_compLease.expires){InterlockedExchange(&g_authorized,0);InterlockedOr(&g_compAuthError,4);EnterCriticalSection(&g_compLock);atcs_random(g_sessionKey,sizeof g_sessionKey);atcs_random(g_compLease.key,sizeof g_compLease.key);SecureZeroMemory(g_compToken,sizeof g_compToken);LeaveCriticalSection(&g_compLock);}
            if(g_parent&&WaitForSingleObject(g_parent,0)!=WAIT_TIMEOUT){g_compForceExit=1;PostMessageA(h,WM_CLOSE,0,0);return 0;}
            if(g_authorized&&g_compGoalValid&&g_compLastSentKeyScale&&!g_compRetry&&g_compSentAt&&GetTickCount()-g_compSentAt>=2000&&g_compConfirmed<g_compCaptured){g_compRetry=1;companion_write_goal(1);}
        }return 0;
    case WM_CREATE:
        if(g_managed)SetTimer(h,ATC_PARENT_TIMER,250,NULL);
        return 0;
    case WM_CLOSE:
        if(g_managed&&g_parent&&!g_compForceExit)return 0;
        g_running=0;DestroyWindow(h);return 0;
    case WM_DESTROY:
        KillTimer(h,ATC_PARENT_TIMER);g_mainWindow=NULL;
        PostQuitMessage(0);return 0;
    }
    return DefWindowProcA(h, m, wp, lp);
}

static HANDLE g_single = NULL;

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR cmdline, int show) {
    /* MUST remain the first operation in WinMain. In the managed build an
       unrecognized launch (including a double-click) has ZERO side effects:
       no mutex, file operation, window lookup, runtime extraction, or UI. */
    unsigned long requestedParent=0;int intent=atc_startup(cmdline,&requestedParent);
    if(g_managed&&intent==0)return 0;
    /* g_compLease.key starts at a per-process random value, not the implicit zero a
       static ATCS_Claims defaults to, so that patching the g_authorized checks alone
       (without a real verified lease ever installing a real shared key) cannot produce
       a key an independently-patched agent would also land on. A genuinely verified
       lease overwrites this below; nothing here weakens that path. */
    atcs_random(g_compLease.key,sizeof g_compLease.key);
    atcs_random(g_sessionKey,sizeof g_sessionKey);
    if(g_managed){
        OSVERSIONINFOA os;memset(&os,0,sizeof os);os.dwOSVersionInfoSize=sizeof os;
        if(!GetVersionExA(&os)||os.dwMajorVersion<6||(os.dwMajorVersion==6&&os.dwMinorVersion<1))return 20;
        if(intent==1){
            if(requestedParent!=companion_creator_pid())return 21;
            g_parentPid=(DWORD)requestedParent;
            g_parent=OpenProcess(SYNCHRONIZE|0x1000,FALSE,g_parentPid); /* PROCESS_QUERY_LIMITED_INFORMATION */
            if(!g_parent||!companion_parent_security(g_parent)){if(g_parent)CloseHandle(g_parent);g_parent=NULL;return 22;}
        }
    }

    /* One controller per session. A second one is not a harmless duplicate: both drive the same
       command file (so the key would flip between whatever each one last sent), and the startup
       cleanup below deletes the command file, the eject flag and every published scale list --
       belonging to the instance already running. Ticking "unload on close" in the second window
       would then eject the agents the first one is using. Two copies in different folders collide
       the same way, because the agent is always staged in the data folder (COMMDIR).
       "Local\" scopes this per logon session, so separate users are unaffected. */
    g_single = CreateMutexA(NULL, FALSE, "Local\\AT8_KeyScale_Controller_single");
    if(!g_single){if(g_parent)CloseHandle(g_parent);return 23;}
    if (g_single && GetLastError() == ERROR_ALREADY_EXISTS) {
        CloseHandle(g_single); g_single = NULL;
        if(g_parent){CloseHandle(g_parent);g_parent=NULL;}
        return g_managed&&intent==1?24:0;
    }
    InitializeCriticalSection(&g_compLock);
    if(g_managed&&!atcs_device_fingerprint(g_compDevice)){if(g_parent)CloseHandle(g_parent);CloseHandle(g_single);DeleteCriticalSection(&g_compLock);return 26;}
    if(!g_managed){ensure_runtime();g_runtimeReady=1;}

    WNDCLASSA wc; memset(&wc, 0, sizeof wc);
    wc.lpfnWndProc = WndProc; wc.hInstance = hInst; wc.lpszClassName = "AT8Ctl";
    if(!RegisterClassA(&wc)){if(g_parent)CloseHandle(g_parent);CloseHandle(g_single);unpin_all();DeleteCriticalSection(&g_compLock);return 25;}
    /* Hidden top-level message endpoint: no caption, child controls, or show call.
       Keep AT8Ctl discoverable by the owning bridge's process-bound EnumWindows. */
    HWND h=CreateWindowA("AT8Ctl","",0,0,0,0,0,0,0,hInst,0);
    g_mainWindow=h;
    if(!h){if(g_parent)CloseHandle(g_parent);if(g_single)CloseHandle(g_single);unpin_all();DeleteCriticalSection(&g_compLock);return 25;}
    if(!g_managed)g_scanTh = CreateThread(NULL, 0, scan_thread, NULL, 0, NULL);

    MSG msg;
    while (GetMessage(&msg, 0, 0, 0)) { TranslateMessage(&msg); DispatchMessage(&msg); }
    g_running = 0;
    /* Let the scan thread finish before the CRT is torn down -- it may be in the middle of a file
       read or a cross-thread SendMessage. Waiting plainly would deadlock: that SendMessage can only
       complete if this thread keeps pumping, so pump while waiting, and give up after 5s rather
       than ever hanging on exit. */
    if (g_scanTh) {
        DWORD deadline = GetTickCount() + (g_managed?1500:5000);
        for (;;) {
            DWORD now = GetTickCount();
            if ((int)(deadline - now) <= 0) break;
            DWORD r = MsgWaitForMultipleObjects(1, &g_scanTh, FALSE, deadline - now, QS_ALLINPUT);
            if (r == WAIT_OBJECT_0 || r == WAIT_TIMEOUT || r == WAIT_FAILED) break;
            MSG m; while (PeekMessageA(&m, NULL, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageA(&m); }
        }
        CloseHandle(g_scanTh); g_scanTh = NULL;
    }
    if (g_single) { CloseHandle(g_single); g_single = NULL; }
    unpin_all();
    if(g_parent){CloseHandle(g_parent);g_parent=NULL;}
    atcs_random(g_sessionKey,sizeof g_sessionKey);
    /* The process owns this lock until exit; a timed-out legacy scan thread may
       still be unwinding, so never destroy its lock underneath it. */
    return 0;
}
