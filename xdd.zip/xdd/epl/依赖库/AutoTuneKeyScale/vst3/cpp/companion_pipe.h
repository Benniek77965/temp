#ifndef AT_COMPANION_PIPE_H
#define AT_COMPANION_PIPE_H
#include <windows.h>
#include <tlhelp32.h>
#include <sddl.h>
#include "companion_security.h"
#define ATCS_PIPE_MAGIC 0x33424b58UL
#define ATCS_PIPE_MAX ATCS_MAX_TOKEN
static void atcs_pipe_name(DWORD pid,unsigned build,wchar_t* out,unsigned cap){swprintf(out,cap,L"\\\\.\\pipe\\xhh.rack.agent.v3.b%u.%lu",build,(unsigned long)pid);}
static DWORD atcs_creator(DWORD pid){DWORD parent=0;HANDLE ss=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(ss==INVALID_HANDLE_VALUE)return 0;PROCESSENTRY32 pe;memset(&pe,0,sizeof pe);pe.dwSize=sizeof pe;if(Process32First(ss,&pe))do{if(pe.th32ProcessID==pid){parent=pe.th32ParentProcessID;break;}}while(Process32Next(ss,&pe));CloseHandle(ss);return parent;}
static int atcs_pid_alive(DWORD pid){HANDLE h=OpenProcess(SYNCHRONIZE,FALSE,pid);if(!h)return GetLastError()==ERROR_ACCESS_DENIED;int ok=WaitForSingleObject(h,0)==WAIT_TIMEOUT;CloseHandle(h);return ok;}
static int atcs_same_user_elevated(DWORD pid){
    HANDLE hp=OpenProcess(0x1000,FALSE,pid),a=NULL,b=NULL;if(!hp)return 0;
    int ok=OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&a)&&OpenProcessToken(hp,TOKEN_QUERY,&b);unsigned char sa[1024],sb[1024];DWORD z=0,na=0,nb=0,la=0,lb=0;TOKEN_ELEVATION e;
    if(ok)ok=GetTokenInformation(a,TokenUser,sa,sizeof sa,&na)&&GetTokenInformation(b,TokenUser,sb,sizeof sb,&nb)&&EqualSid(((TOKEN_USER*)sa)->User.Sid,((TOKEN_USER*)sb)->User.Sid)&&GetTokenInformation(a,TokenSessionId,&la,sizeof la,&z)&&GetTokenInformation(b,TokenSessionId,&lb,sizeof lb,&z)&&la==lb&&GetTokenInformation(b,TokenElevation,&e,sizeof e,&z)&&e.TokenIsElevated;
    if(a)CloseHandle(a);if(b)CloseHandle(b);CloseHandle(hp);return ok;
}
/* Both peers use kernel-reported process IDs; a predictable pipe name is never
   sufficient identity. Remote clients are rejected and the DACL admits this SID
   and SYSTEM only. PIPE_NOWAIT bounds the agent's polling work without a thread. */
static HANDLE atcs_pipe_server(unsigned build){
    HANDLE token=NULL;unsigned char user[1024];DWORD n=0;LPWSTR sid=NULL;PSECURITY_DESCRIPTOR sd=NULL;HANDLE pipe=INVALID_HANDLE_VALUE;
    if(!OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&token))return pipe;
    if(GetTokenInformation(token,TokenUser,user,sizeof user,&n)&&ConvertSidToStringSidW(((TOKEN_USER*)user)->User.Sid,&sid)){
        wchar_t acl[512],name[128];swprintf(acl,512,L"D:P(A;;GA;;;SY)(A;;GA;;;%ls)",sid);
        if(ConvertStringSecurityDescriptorToSecurityDescriptorW(acl,SDDL_REVISION_1,&sd,NULL)){
            SECURITY_ATTRIBUTES sa={sizeof sa,sd,FALSE};atcs_pipe_name(GetCurrentProcessId(),build,name,128);
            pipe=CreateNamedPipeW(name,PIPE_ACCESS_DUPLEX|FILE_FLAG_FIRST_PIPE_INSTANCE,PIPE_TYPE_MESSAGE|PIPE_READMODE_MESSAGE|PIPE_NOWAIT|0x8,1,8+ATCS_PIPE_MAX,8+ATCS_PIPE_MAX,0,&sa);
        }
    }
    if(sd)LocalFree(sd);if(sid)LocalFree(sid);CloseHandle(token);return pipe;
}
static int atcs_pipe_peer(HANDLE pipe,int server,DWORD expected,DWORD* out){
    typedef BOOL(WINAPI* Peer)(HANDLE,PULONG);Peer fn=(Peer)(void*)GetProcAddress(GetModuleHandleA("kernel32.dll"),server?"GetNamedPipeClientProcessId":"GetNamedPipeServerProcessId");ULONG pid=0;if(!fn||!fn(pipe,&pid)||!pid||(expected&&pid!=expected))return 0;if(out)*out=(DWORD)pid;return 1;
}
static int atcs_pipe_io(HANDLE pipe,int writing,void* data,DWORD count,DWORD* actual){
    OVERLAPPED ov;memset(&ov,0,sizeof ov);ov.hEvent=CreateEventA(NULL,TRUE,FALSE,NULL);if(!ov.hEvent)return 0;
    DWORD got=0;BOOL ok=writing?WriteFile(pipe,data,count,&got,&ov):ReadFile(pipe,data,count,&got,&ov);
    if(!ok&&GetLastError()==ERROR_IO_PENDING){DWORD w=WaitForSingleObject(ov.hEvent,700);if(w==WAIT_OBJECT_0)ok=GetOverlappedResult(pipe,&ov,&got,FALSE);else{CancelIo(pipe);GetOverlappedResult(pipe,&ov,&got,TRUE);ok=FALSE;}}
    CloseHandle(ov.hEvent);if(actual)*actual=got;return ok!=0;
}
static int atcs_pipe_bootstrap(DWORD target,const char* token,unsigned len,unsigned build){
    if(!token||!len||len>ATCS_PIPE_MAX||!build)return 0;wchar_t name[128];atcs_pipe_name(target,build,name,128);
    if(!WaitNamedPipeW(name,1200))return 0;
    HANDLE p=CreateFileW(name,GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_EXISTING,FILE_FLAG_OVERLAPPED,NULL);if(p==INVALID_HANDLE_VALUE)return 0;
    int ok=atcs_pipe_peer(p,0,target,NULL);DWORD mode=PIPE_READMODE_MESSAGE;if(ok)ok=SetNamedPipeHandleState(p,&mode,NULL,NULL)!=0;
    unsigned char packet[8+ATCS_PIPE_MAX];DWORD magic=ATCS_PIPE_MAGIC;memcpy(packet,&magic,4);DWORD size=len;memcpy(packet+4,&size,4);memcpy(packet+8,token,len);DWORD got=0,result=0;
    if(ok)ok=atcs_pipe_io(p,1,packet,len+8,&got)&&got==len+8;
    if(ok)ok=atcs_pipe_io(p,0,&result,4,&got)&&got==4&&result==1;
    SecureZeroMemory(packet,sizeof packet);CloseHandle(p);return ok;
}
#endif
