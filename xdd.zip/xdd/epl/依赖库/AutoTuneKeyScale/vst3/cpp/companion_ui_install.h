#ifndef AT_COMPANION_UI_INSTALL_H
#define AT_COMPANION_UI_INSTALL_H
/* A message carries only a static descriptor index, never worker stack memory.
   WH_GETMESSAGE installs before dispatch of one posted wake message. There is
   no synchronous worker-to-host call. Owner-thread original publication has no wait or
   user-code dispatch in between. Timeout cannot reclaim descriptors or routes. */
#define ATUI_MAX_INSTALLS 256
#define ATUI_INSTALL_PENDING 1
#define ATUI_INSTALL_CLAIMED 2
#define ATUI_INSTALL_DONE 3
#define ATUI_INSTALL_CANCELLED 4
#define ATUI_INSTALL_ACTIVE 5
#define ATUI_INSTALL_WAIT_MS 300
struct ATUI_Install {HWND window;DWORD thread;int unicode;WNDPROC observer;ATUI_Route* route;volatile LONG phase,abandoned;};
static ATUI_Install g_uiInstalls[ATUI_MAX_INSTALLS];
static volatile LONG g_uiInstallCount=0;
static UINT g_uiInstallMessage=0;
static const wchar_t ATUI_INSTALL_PROPERTY[]=L"AutoTuneKeyScale.UIInstall.v1";
static void atui_install_clear(ATUI_Install* request){
    if(GetPropW(request->window,ATUI_INSTALL_PROPERTY)==(HANDLE)request)RemovePropW(request->window,ATUI_INSTALL_PROPERTY);
}
static LRESULT CALLBACK atui_install_hook(int code,WPARAM wp,LPARAM lp){
    if(code==HC_ACTION&&wp==PM_REMOVE&&lp){
        const MSG* message=(const MSG*)lp;
        LONG count=InterlockedCompareExchange(&g_uiInstallCount,0,0);
        if(message->message==g_uiInstallMessage&&message->lParam==0&&message->wParam<(WPARAM)count){
            ATUI_Install* request=&g_uiInstalls[(unsigned)message->wParam];DWORD process=0;
            if(message->hwnd==request->window&&GetCurrentThreadId()==request->thread
               &&GetWindowThreadProcessId(request->window,&process)==request->thread&&process==GetCurrentProcessId()
               &&GetPropW(request->window,ATUI_INSTALL_PROPERTY)==(HANDLE)request
               &&InterlockedCompareExchange(&request->phase,ATUI_INSTALL_CLAIMED,ATUI_INSTALL_PENDING)==ATUI_INSTALL_PENDING){
                if(!InterlockedCompareExchange(&request->abandoned,0,0)&&agent_ui_install_allowed()
                   &&IsWindowUnicode(request->window)==request->unicode){
                    ATUI_Route* existing=atui_find(request->window);
                    if(existing){
                        /* A NEW timely retry may activate an earlier read-only
                           observer, without ever changing its original. */
                        if(atui_epoch_live(existing)&&existing->thread==request->thread&&existing->unicode==request->unicode)request->route=existing;
                    }else{
                    WNDPROC observed=request->unicode?(WNDPROC)GetWindowLongPtrW(request->window,GWLP_WNDPROC):(WNDPROC)GetWindowLongPtrA(request->window,GWLP_WNDPROC);
                    if(observed&&observed!=request->observer){
                        ATUI_Route* route=atui_reserve(request->window,request->unicode,request->thread);
                        if(route){
                            if(!InterlockedCompareExchange(&request->abandoned,0,0)&&agent_ui_install_allowed()){
                                SetLastError(0);
                                WNDPROC original=request->unicode?(WNDPROC)(LONG_PTR)SetWindowLongPtrW(request->window,GWLP_WNDPROC,(LONG_PTR)request->observer)
                                    :(WNDPROC)(LONG_PTR)SetWindowLongPtrA(request->window,GWLP_WNDPROC,(LONG_PTR)request->observer);
                                if(original&&original!=request->observer){atui_publish(route,original,0);request->route=route;}
                                else atui_destroy(route);
                            }else atui_destroy(route);
                        }
                    }
                    }
                }
                atui_install_clear(request);
                InterlockedExchange(&request->phase,ATUI_INSTALL_DONE);
            }
        }
    }
    return CallNextHookEx(NULL,code,wp,lp);
}
static ATUI_Route* atui_install_on_owner(HWND window,DWORD thread,int unicode,WNDPROC observer){
    DWORD process=0;
    if(!agent_ui_install_allowed()||!window||!thread||GetWindowThreadProcessId(window,&process)!=thread||process!=GetCurrentProcessId()
       ||GetPropW(window,ATUI_INSTALL_PROPERTY))return NULL;
    if(!g_uiInstallMessage)g_uiInstallMessage=RegisterWindowMessageW(L"AT8_UI_ROUTE_INSTALL_V2");
    if(!g_uiInstallMessage)return NULL;
    LONG count=InterlockedCompareExchange(&g_uiInstallCount,0,0);
    if(count>=ATUI_MAX_INSTALLS)return NULL; /* only the existing worker creates requests */
    ATUI_Install* request=&g_uiInstalls[count];
    request->window=window;request->thread=thread;request->unicode=unicode;request->observer=observer;
    InterlockedExchange(&g_uiInstallCount,count+1);
    if(!SetPropW(window,ATUI_INSTALL_PROPERTY,(HANDLE)request))return NULL;
    InterlockedExchange(&request->phase,ATUI_INSTALL_PENDING);
    /* The target thread is in this same process; NULL hMod follows the Win32
       thread-hook contract. The containing agent image is already PINNED. */
    HHOOK hook=SetWindowsHookExW(WH_GETMESSAGE,atui_install_hook,NULL,thread);
    int posted=hook&&PostMessageW(window,g_uiInstallMessage,(WPARAM)count,0);
    DWORD began=GetTickCount();
    while(posted&&InterlockedCompareExchange(&request->phase,0,0)!=ATUI_INSTALL_DONE
          &&GetTickCount()-began<(DWORD)ATUI_INSTALL_WAIT_MS&&agent_ui_install_allowed())Sleep(1);
    if(hook)UnhookWindowsHookEx(hook);
    if(posted&&GetTickCount()-began<(DWORD)ATUI_INSTALL_WAIT_MS&&agent_ui_install_allowed()&&InterlockedCompareExchange(&request->phase,ATUI_INSTALL_ACTIVE,ATUI_INSTALL_DONE)==ATUI_INSTALL_DONE
       &&request->route&&atui_epoch_live(request->route)){
        InterlockedExchange(&request->route->writeReady,1);return request->route;
    }
    InterlockedExchange(&request->abandoned,1);
    if(InterlockedCompareExchange(&request->phase,ATUI_INSTALL_CANCELLED,ATUI_INSTALL_PENDING)==ATUI_INSTALL_PENDING)atui_install_clear(request);
    /* CLAIMED may finish after return: its static descriptor and actual
       original remain valid, but that route stays a read-only observer. */
    return NULL;
}
#endif
