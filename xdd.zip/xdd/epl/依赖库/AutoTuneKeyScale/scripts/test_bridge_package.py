"""bridge_package.py: signed, deterministic download package; version and constants; read-back check.

Uses a throw-away key: the signing-key resource (机架联动_签名公钥) is written with its public half, so
the real 服务端_电音基调 private key is never needed here."""
import hashlib
import io
import json
import re
import subprocess
import sys
import tempfile
import shutil
import zipfile
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

HERE = Path(__file__).resolve().parent
SCRIPT = HERE / 'bridge_package.py'
CONSTANTS = HERE.parents[2] / '常量.e.txt'
NAMES = ['keyscale_rack_bridge.dll', 'keyscale_rack_bridge.manifest', 'keyscale_rack_bridge.sig']
checks, failures = [], []


def check(name, ok):
    checks.append(name)
    if not ok:
        failures.append(name)


def run(*args):
    r = subprocess.run([sys.executable, '-B', str(SCRIPT), *map(str, args)], capture_output=True)
    out = r.stdout.decode('utf-8')
    try: return r.returncode, json.loads(out)
    except ValueError: return r.returncode, {'stderr': r.stderr.decode('utf-8', 'replace'), 'stdout': out}


def pem(key):
    return key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption())


def key_hex(public):
    return public.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo).hex()


def entries(path):
    with zipfile.ZipFile(path) as z:
        return z.namelist(), [z.read(n) for n in z.namelist()]


def rezip(path, files):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as z:
        for name, data in files: z.writestr(name, data)
    path.write_bytes(buf.getvalue())


def main():
    work = Path(tempfile.mkdtemp(prefix='bridge-package-'))
    try:
        key, other = rsa.generate_private_key(public_exponent=65537, key_size=2048), rsa.generate_private_key(public_exponent=65537, key_size=2048)
        (work / 'key.pem').write_bytes(pem(key)); (work / 'other.pem').write_bytes(pem(other))
        source = CONSTANTS.read_bytes()
        (work / 'key.txt').write_bytes(key_hex(key.public_key()).encode('ascii'))   # 签名公钥资源换成这把一次性密钥的公钥
        source = re.sub(rb'(\.\xe5\xb8\xb8\xe9\x87\x8f \xe6\x9c\xba\xe6\x9e\xb6\xe8\x81\x94\xe5\x8a\xa8_\xe6\xa1\xa5\xe6\x9c\x80\xe4\xbd\x8e\xe7\x89\x88\xe6\x9c\xac, ")\d+(")', rb'\g<1>0\g<2>', source)   # the state before any bridge was signed
        (work / 'const.txt').write_bytes(source)
        dll = b'MZ' + bytes(range(256)) * 300
        (work / 'bridge.dll').write_bytes(dll)
        common = ['--bridge', work / 'bridge.dll', '--constants', work / 'const.txt', '--key-resource', work / 'key.txt', '--sign-key', work / 'key.pem']
        rc, report = run(*common, '--out-dir', work / 'a')
        check('package step succeeds and reports version 1', rc == 0 and report.get('status') == 'passed' and report.get('version') == 1)
        zpath = work / 'a' / 'keyscale_rack_bridge.zip'; data = zpath.read_bytes()
        names, (d, m, s) = entries(zpath)
        check('zip holds the DLL, the manifest and the signature, in that order', names == NAMES and d == dll)
        check('the manifest is the canonical five lines for this DLL',
              m == f'XHH-RACKLINK-BRIDGE-1\nversion=1\nsize={len(dll)}\nsha256={hashlib.sha256(dll).hexdigest()}\nhost_api=1\n'.encode())
        try: key.public_key().verify(s, m, padding.PKCS1v15(), hashes.SHA256()); sig_ok = True
        except Exception: sig_ok = False
        check('the signature is RSA PKCS#1 v1.5 / SHA-256 over the manifest by the key whose public half is in the constants', sig_ok and len(s) == 256)
        check('reported MD5 is the zip the server must be told about', report.get('package_md5') == hashlib.md5(data).hexdigest())
        rc, report = run(*common, '--out-dir', work / 'a')
        check('same DLL again: same version, byte-identical zip (same MD5)', rc == 0 and report.get('version') == 1 and zpath.read_bytes() == data)
        before = (work / 'const.txt').read_bytes()
        (work / 'bridge.dll').write_bytes(dll + b'x')
        rc, report = run(*common, '--out-dir', work / 'a')
        after = (work / 'const.txt').read_bytes()
        changed = [(x, y) for x, y in zip(before.decode('utf-8-sig').splitlines(), after.decode('utf-8-sig').splitlines()) if x != y]
        check('a different DLL goes up one version; the constants file is only read (机架联动_桥最低版本 stays)',
              rc == 0 and report.get('version') == 2 and after == before and not changed)
        rc, report = run(*common, '--out-dir', work / 'a', '--version', 7)
        check('--version sets the version; the constants file is still not touched', rc == 0 and report.get('version') == 7
              and (work / 'const.txt').read_bytes() == before)
        keep = zpath.read_bytes()
        rc, report = run('--bridge', work / 'bridge.dll', '--constants', work / 'const.txt', '--key-resource', work / 'key.txt', '--sign-key', work / 'other.pem', '--out-dir', work / 'a')
        check('a private key that does not match the 机架联动_签名公钥 resource is refused before anything is written',
              rc != 0 and '不是一对' in report.get('stderr', '') and zpath.read_bytes() == keep)
        rc, report = run('--bridge', work / 'bridge.dll', '--constants', work / 'const.txt', '--key-resource', work / 'key.txt', '--sign-key', work / 'missing.pem', '--out-dir', work / 'a')
        check('a missing private key is refused and says where to put it', rc != 0 and 'tools\\out-racklink' in report.get('stderr', ''))
        note = (work / 'a' / 'bridge_package.txt').read_bytes().decode('utf-8-sig')
        check('the note tells what to upload, what to type in and which version it is',
              hashlib.md5(keep).hexdigest() in note and 'keyscale_rack_bridge.zip' in note and '设置4' in note and '第 7 版' in note)
        verify = ['--bridge', work / 'bridge.dll', '--constants', work / 'const.txt', '--key-resource', work / 'key.txt', '--out-dir', work / 'a', '--verify-only']
        rc, report = run(*verify)
        check('read-back check passes on what was just written, without the private key', rc == 0 and report.get('version') == 7)
        (work / 'bridge.dll').write_bytes(dll + b'y')
        rc, report = run(*verify)
        check('read-back check fails when the DLL is not the one in the package', rc == 1 and any('不是当前的桥' in p for p in report['problems']))
        (work / 'bridge.dll').write_bytes(dll + b'x')
        names, (d, m, s) = entries(zpath)
        rezip(zpath, [(NAMES[0], d), (NAMES[1], m.replace(b'version=7', b'version=8')), (NAMES[2], s)])
        rc, report = run(*verify)
        check('read-back check fails when the manifest was changed after signing', rc == 1 and any('签名核对不通过' in p for p in report['problems']))
        zpath.write_bytes(keep)
        text = (work / 'const.txt').read_bytes()
        (work / 'api2.txt').write_bytes(text.replace('.常量 机架联动_桥接口版本, "1"'.encode('utf-8'), '.常量 机架联动_桥接口版本, "2"'.encode('utf-8')))
        rc, report = run('--bridge', work / 'bridge.dll', '--constants', work / 'api2.txt', '--key-resource', work / 'key.txt', '--out-dir', work / 'a', '--verify-only')
        check('read-back check fails when the package was made for another host interface', rc == 1 and any('host_api' in p for p in report['problems']))
        (work / 'min9.txt').write_bytes(text.replace('.常量 机架联动_桥最低版本, "0"'.encode('utf-8'), '.常量 机架联动_桥最低版本, "9"'.encode('utf-8')))
        rc, report = run('--bridge', work / 'bridge.dll', '--constants', work / 'min9.txt', '--key-resource', work / 'key.txt', '--out-dir', work / 'a', '--verify-only')
        check('read-back check fails when the main program would refuse the package as too old', rc == 1 and any('低于' in p for p in report['problems']))
        rezip(zpath, [(NAMES[0], dll + b'x')])
        rc, report = run(*verify)
        check('read-back check fails on an unsigned package from before signing', rc == 1 and report['problems'])
        (work / 'd').mkdir()
        (work / 'bridge.dll').write_bytes(dll + b'z')
        rc, report = run(*common, '--out-dir', work / 'd')
        check('without a signed package to go on, the version is the floor + 1 (a number is never reused)',
              rc == 0 and report.get('version') == 1 and (work / 'const.txt').read_bytes() == before)   # floor 0 (set above) + 1
        (work / 'const.txt').write_bytes((work / 'const.txt').read_bytes().replace('.常量 机架联动_桥最低版本, "0"'.encode('utf-8'), '.常量 机架联动_桥最低版本, "12"'.encode('utf-8')))
        rc, report = run(*common, '--out-dir', work / 'd')
        check('a floor raised by hand (to retire a bridge) re-signs the same DLL at the floor, and is left as it is',
              rc == 0 and report.get('version') == 12 and '.常量 机架联动_桥最低版本, "12"' in (work / 'const.txt').read_bytes().decode('utf-8-sig'))
        rc, report = run(*common, '--out-dir', work / 'd', '--version', 3)
        check('--version below the floor is refused (the main program would refuse that bridge)', rc != 0 and '低于' in report.get('stderr', ''))
        (work / 'bridge.dll').write_bytes(dll + b'x')
        (work / 'c').mkdir()
        rc, report = run('--bridge', work / 'bridge.dll', '--constants', work / 'const.txt', '--key-resource', work / 'key.txt', '--out-dir', work / 'c', '--verify-only')
        check('read-back check fails without the package', rc == 1 and any('没有' in p for p in report['problems']))
        (work / 'bridge.dll').write_bytes(b'not a PE file')
        rc, _ = run(*common, '--out-dir', work / 'c')
        check('a file that is not a PE image is refused', rc != 0)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    print(json.dumps({'status': 'failed' if failures else 'passed', 'checks': len(checks), 'failures': failures}, ensure_ascii=False, indent=2))
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
