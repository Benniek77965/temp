#!/usr/bin/env python3
"""Create/verify one EPL ZLIB binary resource from its exact released image."""
import argparse
import hashlib
from pathlib import Path
import struct
import zlib


def paths_alias(first, second):
    first, second = Path(first), Path(second)
    if first.resolve() == second.resolve():
        return True
    try:
        return first.samefile(second)
    except FileNotFoundError:
        return False


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--verify-only', action='store_true')
    args = ap.parse_args()
    if paths_alias(args.output, args.input):
        ap.error('--output cannot replace the input binary')
    data = args.input.read_bytes()
    resource = b'\x0d\x0f\x3e\x03' + struct.pack('<I', len(data)) + zlib.compress(data, 9)
    if not args.verify_only:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_bytes(resource)
    got = args.output.read_bytes()
    if got[:4] != resource[:4] or struct.unpack_from('<I', got, 4)[0] != len(data) or zlib.decompress(got[8:]) != data:
        raise SystemExit('EPL resource content differs from release binary')
    print(hashlib.sha256(data).hexdigest())


if __name__ == '__main__':
    main()
