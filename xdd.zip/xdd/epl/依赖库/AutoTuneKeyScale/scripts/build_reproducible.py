#!/usr/bin/env python3
"""Build the managed Windows graph twice; publish matching outputs.

Uses Win32-model MinGW compilers. Only the managed variant (AT_XHH_MANAGED=1) is
built: injectors and agents, the two controllers embedding them, and the 32-bit
bridge embedding the two controllers, all in one staging tree per build, so the
controllers can only embed these agents. Signing is a separate inside-out
release process (--signed-helpers, --signed-controllers).
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from pe_resources import inspect, summary, verify_resource

ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = {
    'inject.exe': 0x8664, 'inject32.exe': 0x14c,
    'managed/at_agent.dll': 0x8664, 'managed/at_agent32.dll': 0x14c,
    'keyscale_rack_controller.exe': 0x8664,
    'keyscale_rack_bridge.dll': 0x14c,
}
CONTROLLERS = ('keyscale_rack_controller.exe',)   # rack-link ships only the 64-bit controller now
HELPERS = ('inject.exe', 'inject32.exe', 'managed/at_agent.dll', 'managed/at_agent32.dll')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class PublishError(RuntimeError):
    def __init__(self, message, publication):
        super().__init__(message)
        self.publication = publication


def publish_outputs(outputs, journal_path):
    """Stage the whole output graph before replacing anything; roll back errors.

    Backups are renamed originals, preserving their bytes and file metadata.
    A failed rollback keeps those originals and names every recovery path. This
    is exception recovery, not a filesystem-wide atomic transaction on power loss.
    """
    journal_path = Path(journal_path)
    entries = []
    mutated = False

    def record(state, **extra):
        result = {'state': state, 'entries': entries, **extra}
        journal_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        return result

    def reserve(parent, suffix):
        descriptor, name = tempfile.mkstemp(prefix='.atks-publish-', suffix=suffix, dir=parent)
        os.close(descriptor)
        return Path(name)

    def remaining():
        return [entry[key] for entry in entries for key in ('staged', 'backup')
                if entry.get(key) and Path(entry[key]).exists()]

    def changed_targets():
        changed = []
        for entry in entries:
            target = Path(entry['target'])
            before = entry['original_sha256']
            try:
                different = (before is None and target.exists()) or (before is not None and
                    (not target.is_file() or sha(target) != before))
            except OSError:
                different = True  # Unknown/unreadable state must not be reported unchanged.
            if different:
                changed.append(str(target))
        return changed

    try:
        # Destination siblings keep every later replace on the same filesystem.
        for destination, source in outputs.items():
            target, source = Path(destination), Path(source)
            if target.is_symlink() or (target.exists() and not target.is_file()):
                raise ValueError('Unsafe publish destination: ' + str(target))
            target.parent.mkdir(parents=True, exist_ok=True)
            entry = {'target': str(target), 'source': str(source),
                     'original_sha256': sha(target) if target.exists() else None,
                     'staged': None, 'backup': None, 'installed': False}
            entries.append(entry)
            staged = reserve(target.parent, '.new')
            entry['staged'] = str(staged)
            shutil.copyfile(source, staged)
            shutil.copymode(source, staged)
            with staged.open('r+b') as stream:
                stream.flush()
                os.fsync(stream.fileno())
            if sha(staged) != sha(source):
                raise OSError('Publish staging verification failed: ' + str(target))
        record('staged')
        for entry in entries:
            target = Path(entry['target'])
            if entry['original_sha256'] is not None:
                backup = reserve(target.parent, '.bak')
                backup.unlink()
                # Record the recovery filename before the original is moved.
                entry['backup'] = str(backup)
                record('backing_up')
                os.replace(target, backup)
                mutated = True
        record('installing')
        for entry in entries:
            os.replace(entry['staged'], entry['target'])
            entry['installed'] = True
            mutated = True
            record('installing')
        for entry in entries:
            if sha(entry['target']) != sha(entry['source']):
                raise OSError('Published output differs: ' + entry['target'])
        record('committed')
    except BaseException as error:
        rollback_errors = []
        mutation_seen = mutated or any(entry['installed'] or
            (entry.get('backup') and Path(entry['backup']).exists()) for entry in entries)
        if mutation_seen:
            for entry in reversed(entries):
                try:
                    target = Path(entry['target'])
                    backup = Path(entry['backup']) if entry.get('backup') else None
                    if backup is not None and backup.exists():
                        os.replace(backup, target)
                    elif (entry['original_sha256'] is None and target.exists() and
                            (entry['installed'] or (entry.get('staged') and not Path(entry['staged']).exists()))):
                        target.unlink()
                except OSError as rollback_error:
                    rollback_errors.append({'target': entry['target'], 'error': str(rollback_error)})
        for entry in entries:
            if entry.get('staged'):
                try:
                    Path(entry['staged']).unlink(missing_ok=True)
                except OSError as cleanup_error:
                    rollback_errors.append({'target': entry['staged'], 'error': str(cleanup_error)})
        changed = changed_targets()
        residue = remaining()
        publication = {'state': 'partial' if changed or (mutation_seen and rollback_errors) else 'rolled_back' if mutation_seen else 'not_started',
                       'changed_targets': changed, 'recovery_files': residue,
                       'rollback_errors': rollback_errors, 'journal': str(journal_path)}
        try:
            record(publication['state'], error=str(error), publication=publication)
        except OSError as journal_error:
            publication['journal_error'] = str(journal_error)
        raise PublishError('Publishing failed: ' + str(error), publication) from error
    # A cleanup error after commit means outputs changed, never "published=false".
    cleanup_errors = []
    for entry in entries:
        if entry.get('backup'):
            try:
                Path(entry['backup']).unlink(missing_ok=True)
            except OSError as error:
                cleanup_errors.append({'target': entry['backup'], 'error': str(error)})
    publication = {'state': 'committed', 'targets': len(entries), 'changed_targets': changed_targets(),
                   'recovery_files': remaining(), 'cleanup_errors': cleanup_errors, 'journal': str(journal_path)}
    try:
        record('committed', publication=publication)
    except OSError as error:
        publication['journal_error'] = str(error)
        raise PublishError('Outputs committed but publication journal could not be finalized', publication) from error
    if cleanup_errors:
        raise PublishError('Outputs committed but backup cleanup failed; inspect recovery paths', publication)
    return publication


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', required=True, type=Path, help='Empty evidence directory outside source tree')
    ap.add_argument('--toolchain-bin', type=Path)
    ap.add_argument('--publish', action='store_true')
    for bits in ('64', '32'):
        ap.add_argument('--compiler' + bits, help='Explicit Win32-model compiler executable for this architecture')
        ap.add_argument('--windres' + bits, help='Explicit resource compiler executable for this architecture')
    ap.add_argument('--signed-helpers', type=Path, help='Release only: previously signed helper tree, same relative layout as vst3/cpp')
    ap.add_argument('--signed-controllers', type=Path, help='Release only: two VMP-processed and signed managed controllers to embed in the bridge')
    args = ap.parse_args()
    out = args.out.resolve()
    if out == ROOT or ROOT in out.parents:
        ap.error('--out must be outside the source tree')
    if out.exists() and any(out.iterdir()):
        ap.error('--out must be empty')
    if args.signed_controllers and not args.signed_helpers:
        ap.error('--signed-controllers requires --signed-helpers')
    out.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env['SOURCE_DATE_EPOCH'] = '0'
    if args.toolchain_bin:
        env['PATH'] = str(args.toolchain_bin.resolve()) + os.pathsep + env.get('PATH', '')
    commands = []
    log = (out / 'build.log').open('w', encoding='utf-8')
    def run(argv, cwd):
        commands.append({'argv': list(map(str, argv)), 'cwd': str(cwd)})
        log.write('\n$ ' + repr(argv) + '\n'); log.flush()
        p = subprocess.run(argv, cwd=cwd, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        log.write(p.stdout); log.flush()
        if p.returncode:
            raise RuntimeError(f'Command failed ({p.returncode}): {argv[0]}')
        return p.stdout
    publication = {'state': 'not_started', 'changed_targets': [], 'recovery_files': []}
    try:
        cxx, windres, versions = {}, {}, {}
        for bits, triple in (('64', 'x86_64-w64-mingw32'), ('32', 'i686-w64-mingw32')):
            cxx[bits] = shutil.which(getattr(args, 'compiler' + bits) or triple + '-g++-win32', path=env['PATH'])
            windres[bits] = shutil.which(getattr(args, 'windres' + bits) or triple + '-windres', path=env['PATH'])
            if not cxx[bits] or not windres[bits]:
                raise RuntimeError('Missing MinGW Win32-model toolchain for ' + bits)
            versions[bits] = run([cxx[bits], '-v'], ROOT)
            if 'Thread model: win32' not in versions[bits]:
                raise RuntimeError('Wrong compiler thread model')
        inputs = {}
        for folder in (ROOT / 'combined', ROOT / 'vst3' / 'cpp'):
            for p in sorted(folder.rglob('*')):
                if p.is_file() and p.suffix.lower() in ('.cpp', '.h', '.hpp', '.rc', '.def', '.inc'):
                    inputs[p.relative_to(ROOT).as_posix()] = sha(p)
        for required in ('combined/at_agent.cpp', 'vst3/cpp/AutoTune_KeyScale_Controller.cpp',
                         'vst3/cpp/AutoTune_KeyScale_Controller.rc', 'vst3/cpp/keyscale_rack_bridge.cpp',
                         'vst3/cpp/keyscale_rack_bridge.rc'):
            if required not in inputs:
                raise RuntimeError('Missing production source: ' + required)
        supplied = {}
        for folder, names, category in ((args.signed_helpers, HELPERS, 'signed_helpers'),
                                        (args.signed_controllers, CONTROLLERS, 'signed_controllers')):
            if folder:
                for name in names:
                    path = folder.resolve() / name
                    info = inspect(path)
                    supplied[category + '/' + name] = {'path': str(path), 'sha256': info['sha256'], 'image_sha256': info['image_sha256']}
        snapshot = out / 'source_snapshot'
        for rel, digest in inputs.items():
            target = snapshot / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / rel, target)
            if sha(target) != digest:
                raise RuntimeError('Source changed while taking the fixed build snapshot')
        common = ['-O2', '-finput-charset=UTF-8', '-fno-ident', '-Wl,--no-insert-timestamp', '-Wl,-s']
        static = ['-static', '-static-libgcc', '-static-libstdc++']
        def resource(bits, name, cpp):
            obj = name + bits + '.o'
            run([windres[bits], '--codepage=65001', '--preprocessor', cxx[bits],
                 '--preprocessor-arg=-E', '--preprocessor-arg=-xc', '--preprocessor-arg=-DRC_INVOKED',
                 name + '.rc', '-O', 'coff', '-o', obj], cpp)
            return obj
        for attempt in (1, 2):
            stage = out / f'run{attempt}'
            for rel in inputs:
                target = stage / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(snapshot / rel, target)
            cpp = stage / 'vst3' / 'cpp'
            agents = ('at_agent.dll', 'at_agent32.dll')
            for bits in ('64', '32'):
                agent = agents[0] if bits == '64' else agents[1]
                injector = 'inject.exe' if bits == '64' else 'inject32.exe'
                run([cxx[bits], *common, '-o', injector, 'inject.cpp', '-lpsapi', *static], cpp)
                run([cxx[bits], *common, '-DAT_XHH_MANAGED=1',
                     '-shared', '-o', agent, '../../combined/at_agent.cpp',
                     '-lpsapi', '-lversion', '-luser32', '-lkernel32', '-ladvapi32', *static], cpp)
            # Only a separately verified release stage may supply signed helpers.
            if args.signed_helpers:
                for name in HELPERS:
                    shutil.copyfile(args.signed_helpers.resolve() / name, cpp / Path(name).name)
            # Only the 64-bit controller is built and shipped; a 32-bit host runs under WOW64 on any 64-bit
            # Windows and uses the 64-bit controller (the 32-bit injector still handles 32-bit targets).
            res = resource('64', 'AutoTune_KeyScale_Controller', cpp)
            name = CONTROLLERS[0]
            run([cxx['64'], *common, '-DAT_XHH_MANAGED=1',
                 '-mwindows', '-o', name, 'AutoTune_KeyScale_Controller.cpp', res,
                 '-lcomctl32', '-lpsapi', '-luser32', '-lgdi32', '-lkernel32', '-lversion', '-ladvapi32', *static], cpp)
            for resource_name, binary in (('AGENT64', 'at_agent.dll'), ('AGENT32', 'at_agent32.dll'),
                                          ('INJECT64', 'inject.exe'), ('INJECT32', 'inject32.exe')):
                verify_resource(inspect(cpp / name), resource_name, cpp / binary)
            # Bridge embeds the final signed controllers during release; raw controllers otherwise.
            if args.signed_controllers:
                for name in CONTROLLERS:
                    shutil.copyfile(args.signed_controllers.resolve() / name, cpp / name)
                    final_info = inspect(cpp / name)
                    for resource_name, binary in (('AGENT64', 'at_agent.dll'), ('AGENT32', 'at_agent32.dll'), ('INJECT64', 'inject.exe'), ('INJECT32', 'inject32.exe')):
                        verify_resource(final_info, resource_name, cpp / binary)
            shutil.copyfile(cpp / CONTROLLERS[0], cpp / 'companion64.bin')
            bridge_res = resource('32', 'keyscale_rack_bridge', cpp)
            run([cxx['32'], *common, '-shared', '-Wl,--kill-at', '-o', 'keyscale_rack_bridge.dll',
                 'keyscale_rack_bridge.cpp', bridge_res, '-lwinhttp', '-ladvapi32', '-luser32', '-lkernel32', *static], cpp)
            info = inspect(cpp / 'keyscale_rack_bridge.dll')
            verify_resource(info, 'CONTROLLER64', cpp / CONTROLLERS[0])
            (cpp / 'managed').mkdir(exist_ok=True)
            for name in agents:
                shutil.copyfile(cpp / name, cpp / 'managed' / name)
        if any(sha(ROOT / rel) != digest for rel, digest in inputs.items()):
            raise RuntimeError('Source changed during the two builds; retry from stable source')
        artifacts = {}
        for name, expected_machine in ARTIFACTS.items():
            first = out / 'run1' / 'vst3' / 'cpp' / name
            second = out / 'run2' / 'vst3' / 'cpp' / name
            if first.read_bytes() != second.read_bytes():
                raise RuntimeError('Non-reproducible artifact: ' + name)
            info = inspect(first)
            origin = ('supplied_signed_helper' if args.signed_helpers and name in HELPERS else
                      'supplied_signed_controller' if args.signed_controllers and name in CONTROLLERS else 'compiled_twice')
            if info['machine'] != expected_machine or (origin != 'supplied_signed_controller' and info['pe_timestamp'] != 0):
                raise RuntimeError('PE timestamp/architecture mismatch: ' + name)
            artifacts[name] = {**summary(info), 'origin': origin, 'two_builds_identical': True}
        if any(sha(ROOT / rel) != digest for rel, digest in inputs.items()):
            raise RuntimeError('Source changed during the two builds; retry from stable source')
        if any(sha(item['path']) != item['sha256'] for item in supplied.values()):
            raise RuntimeError('Supplied signed inputs changed during builds')
        publication = {'state': 'not_requested', 'changed_targets': [], 'recovery_files': []}
        if args.publish:
            built = out / 'run1' / 'vst3' / 'cpp'
            outputs = {ROOT / 'vst3' / 'cpp' / name: built / name for name in ARTIFACTS}
            publication = publish_outputs(outputs, out / 'publish_transaction.json')
        key_header = (snapshot / 'vst3/cpp/companion_public_key.h').read_text(encoding='utf-8-sig')
        definitions = re.findall(r'^[ \t]*#[ \t]*define[ \t]+ATCS_PUBLIC_KEY_CONFIGURED[ \t]+([01])[ \t]*(?://[^\r\n]*)?\r?$', key_header, re.M)
        release_configured = definitions == ['1']
        result = {'status': 'passed', 'source_sha256': inputs, 'supplied_signed_inputs': supplied,
                  'authorization_public_key_configured': release_configured,
                  'artifacts': artifacts, 'compiler_versions': versions, 'commands': commands,
                  'published': args.publish, 'publication': publication, 'runtime_tests': 'not run by build script'}
        (out / 'build_manifest.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'status': 'passed', 'artifacts': len(artifacts), 'manifest': str(out / 'build_manifest.json'), 'published': args.publish}, ensure_ascii=False))
        return 0
    except (OSError, RuntimeError, ValueError) as exc:
        # A later manifest/read failure must not erase a completed publication.
        publication = exc.publication if isinstance(exc, PublishError) else publication
        (out / 'build_manifest.json').write_text(json.dumps({'status': 'failed', 'error': str(exc), 'commands': commands,
            'published': publication.get('state') in ('committed', 'partial') or bool(publication.get('changed_targets')),
            'publication': publication}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(str(exc), file=sys.stderr)
        return 1
    finally:
        log.close()


if __name__ == '__main__':
    raise SystemExit(main())
