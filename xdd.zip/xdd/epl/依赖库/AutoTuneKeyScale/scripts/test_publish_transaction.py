#!/usr/bin/env python3
"""Fault-inject the real publisher; never builds or replaces production outputs."""
from __future__ import annotations
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile
import unittest
from unittest.mock import patch
from build_reproducible import PublishError, publish_outputs


class PublicationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='publish-transaction-', dir=Path.cwd())
        self.root = Path(self.temporary.name)
        self.targets = [self.root / 'output' / name for name in ('old-a.dll', 'new-b.dll', 'old-c.dll')]
        self.sources = [self.root / 'built' / target.name for target in self.targets]
        for source in self.sources:
            source.parent.mkdir(parents=True, exist_ok=True)
            source.write_bytes(b'new ' + source.name.encode())
        self.before = {}
        for target in (self.targets[0], self.targets[2]):
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(b'old ' + target.name.encode())
            target.chmod(0o640)
            os.utime(target, ns=(1234567890000000000, 1234567890123456700))
            s = target.stat()
            self.before[target] = (target.read_bytes(), stat.S_IMODE(s.st_mode), s.st_mtime_ns)
        self.outputs = dict(zip(self.targets, self.sources))
        self.journal = self.root / 'journal.json'

    def tearDown(self):
        self.temporary.cleanup()

    def original_state(self):
        for target, (data, mode, mtime) in self.before.items():
            self.assertEqual(target.read_bytes(), data)
            self.assertEqual(stat.S_IMODE(target.stat().st_mode), mode)
            self.assertEqual(target.stat().st_mtime_ns, mtime)
        self.assertFalse(self.targets[1].exists())

    def no_recovery_residue(self):
        self.assertEqual(list((self.root / 'output').glob('.atks-publish-*')), [])

    def test_success_commits_whole_old_new_graph(self):
        result = publish_outputs(self.outputs, self.journal)
        self.assertEqual(result['state'], 'committed')
        self.assertEqual(result['targets'], 3)
        for target, source in self.outputs.items():
            self.assertEqual(target.read_bytes(), source.read_bytes())
        self.no_recovery_residue()

    def test_second_copy_failure_does_not_replace_any_original(self):
        original = shutil.copyfile
        calls = 0
        def copy(*args, **kwargs):
            nonlocal calls
            calls += 1
            if calls == 2:
                raise OSError('injected second staging copy failure')
            return original(*args, **kwargs)
        with patch('build_reproducible.shutil.copyfile', copy):
            with self.assertRaises(PublishError) as failed:
                publish_outputs(self.outputs, self.journal)
        self.assertEqual(failed.exception.publication['state'], 'not_started')
        self.assertEqual(failed.exception.publication['changed_targets'], [])
        self.original_state()
        self.no_recovery_residue()

    def run_replace_failure(self, fail_at, after=False):
        original = os.replace
        calls = 0
        def replace(*args, **kwargs):
            nonlocal calls
            calls += 1
            if calls == fail_at and not after:
                raise OSError('injected replace failure')
            result = original(*args, **kwargs)
            if calls == fail_at and after:
                raise OSError('injected exception after successful replace')
            return result
        with patch('build_reproducible.os.replace', replace):
            with self.assertRaises(PublishError) as failed:
                publish_outputs(self.outputs, self.journal)
        self.assertEqual(failed.exception.publication['state'], 'rolled_back')
        self.assertEqual(failed.exception.publication['changed_targets'], [])
        self.assertEqual(failed.exception.publication['rollback_errors'], [])
        self.original_state()
        self.no_recovery_residue()

    def test_second_backup_replace_failure_rolls_back(self):
        self.run_replace_failure(2)

    def test_middle_install_replace_failure_restores_old_and_removes_new(self):
        self.run_replace_failure(5)

    def test_error_after_original_replace_still_rolls_back(self):
        self.run_replace_failure(1, after=True)

    def test_error_after_new_file_install_still_removes_it(self):
        self.run_replace_failure(4, after=True)

    def test_failed_rollback_is_explicit_and_retains_original_backup(self):
        original = os.replace
        calls = 0
        def replace(*args, **kwargs):
            nonlocal calls
            calls += 1
            if calls in (5, 7):
                raise OSError('injected install then rollback failure')
            return original(*args, **kwargs)
        with patch('build_reproducible.os.replace', replace):
            with self.assertRaises(PublishError) as failed:
                publish_outputs(self.outputs, self.journal)
        result = failed.exception.publication
        self.assertEqual(result['state'], 'partial')
        self.assertEqual(result['changed_targets'], [str(self.targets[0])])
        self.assertEqual(len(result['rollback_errors']), 1)
        self.assertEqual(len(result['recovery_files']), 1)
        self.assertEqual(Path(result['recovery_files'][0]).read_bytes(), self.before[self.targets[0]][0])
        self.assertEqual(json.loads(self.journal.read_text())['state'], 'partial')
        self.assertFalse(self.targets[1].exists())
        self.assertEqual(self.targets[2].read_bytes(), self.before[self.targets[2]][0])


if __name__ == '__main__':
    unittest.main(verbosity=2)
