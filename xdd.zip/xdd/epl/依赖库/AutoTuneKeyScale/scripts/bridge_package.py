#!/usr/bin/env python3
"""Package keyscale_rack_bridge.dll for cloud download, signed with the 服务端_电音基调 private key.

The main program no longer pins one bridge. It downloads keyscale_rack_bridge.zip from the addresses
configured in TCP_主服务端 (启动窗口「设置4」页「机架联动桥 - 下载地址」), installs it once with 插件就绪, and
loads the DLL only when
  * keyscale_rack_bridge.sig is a valid RSA PKCS#1 v1.5 / SHA-256 signature (OpenSSL RSA_verify, as the
    精易 L_RSA验证签名 checks it) over keyscale_rack_bridge.manifest, made with the key whose public half
    is built into the main program (the resource 机架联动_签名公钥, epl/资源/机架联动_签名公钥.txt: the key that also signs authorization tokens),
    so a new bridge needs no new main program;
  * the manifest is exactly the five LF-terminated lines
        XHH-RACKLINK-BRIDGE-1 / version=N / size=S / sha256=H / host_api=A
    (its first line keeps it apart from everything else that key signs: tokens start with "ver=3",
    transport keys with "XHH-RACKLINK-TRANSPORT-3");
  * host_api equals 机架联动_桥接口版本, the version is not below 机架联动_桥最低版本, and the DLL has exactly
    size S and SHA-256 H. Main programs released before also refused a version below the highest one that
    Windows user had already loaded; that per-computer floor is gone: the version is a label, rolling back is
    uploading the older package, and a bridge every user must stop using is turned away by the server
    (机架联动管理界面「最低控制器版本」, with the controller version raised in the fixed bridge).

Packaging needs the private key: --sign-key, else the RACKLINK_PRIVATE_KEY environment variable, else
tools/out-racklink/racklink_private.pem. Before signing it is checked against that resource.
  * The version stays the same for the same DLL (the zip is then byte-identical and keeps its MD5) and
    goes up by one for a different DLL; without a signed package in --out-dir it is 机架联动_桥最低版本 + 1,
    so a number is never given to two bridges. --version sets it (e.g. a number above what the main programs
    released before have loaded), but not below 机架联动_桥最低版本.
  * epl/常量.e.txt is only read: 机架联动_桥最低版本 stays as it is (kept at 1; raised by hand only to keep the
    main programs built from then on off a bridge with a security problem).
--verify-only needs no private key: it checks the package against the current DLL, the constants and that resource.
"""
import argparse
import hashlib
import io
import json
import os
import re
import sys
import zipfile
from pathlib import Path

try:
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding
except ImportError:
    if __name__ == '__main__':
        print('未能加载 cryptography。请用当前 Python 执行：python -m pip install cryptography', file=sys.stderr)
        raise SystemExit(1)
    raise

ROOT = Path(__file__).resolve().parents[1]
ENTRY, MANIFEST, SIGNATURE = 'keyscale_rack_bridge.dll', 'keyscale_rack_bridge.manifest', 'keyscale_rack_bridge.sig'
ZIPNAME = 'keyscale_rack_bridge.zip'
PREFIX = 'XHH-RACKLINK-BRIDGE-1'
DEFAULT_KEY = ROOT.parents[2] / 'tools' / 'out-racklink' / 'racklink_private.pem'
MIN_LINE = re.compile(r'^(\.常量 机架联动_桥最低版本, )"(\d*)"(, .*)$', re.M)
API_LINE = re.compile(r'^\.常量 机架联动_桥接口版本, "(\d+)"', re.M)


def manifest_bytes(version, size, sha, api):
    return f'{PREFIX}\nversion={version}\nsize={size}\nsha256={sha}\nhost_api={api}\n'.encode('ascii')


def parse_manifest(data):
    """Same rule as 机架联动_解析桥清单: the five canonical lines and nothing else."""
    try: text = data.decode('ascii')
    except UnicodeDecodeError: return None
    m = re.fullmatch(PREFIX + r'\nversion=(\d+)\nsize=(\d+)\nsha256=([0-9a-f]{64})\nhost_api=(\d+)\n', text)
    if not m: return None
    version, size, sha, api = int(m.group(1)), int(m.group(2)), m.group(3), int(m.group(4))
    if min(version, size, api) < 1 or max(version, size, api) > 0x7FFFFFFF or manifest_bytes(version, size, sha, api) != data: return None
    return version, size, sha, api


def build_zip(files):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as archive:
        for name, data in files:
            info = zipfile.ZipInfo(name, date_time=(2020, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 0          # MS-DOS attributes, the same on every build machine
            info.external_attr = 0x20       # FILE_ATTRIBUTE_ARCHIVE
            archive.writestr(info, data, compresslevel=9)
    return buffer.getvalue()


def zip_entries(data):
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        names = archive.namelist()
        if names != [ENTRY, MANIFEST, SIGNATURE]:
            raise ValueError(f'压缩包里应当依次是 {ENTRY}、{MANIFEST}、{SIGNATURE}，实际是 {names}')
        return [archive.read(n) for n in names]


def read_text(path):
    raw = path.read_bytes()
    return raw.startswith(b'\xef\xbb\xbf'), raw.decode('utf-8-sig')


def constants(text):
    mins = MIN_LINE.findall(text); apis = API_LINE.findall(text)
    if len(mins) != 1 or len(apis) != 1:
        raise ValueError('常量.e.txt 里应当有 机架联动_桥最低版本、机架联动_桥接口版本 各一行')
    return int(mins[0][1] or 0), int(apis[0])


def signing_public(path):
    """主程序内置的签名公钥：长文本资源 机架联动_签名公钥（SubjectPublicKeyInfo DER 的十六进制，整个文件就是这一串）"""
    try:
        return serialization.load_der_public_key(bytes.fromhex(path.read_bytes().decode('ascii').strip()))
    except (ValueError, UnicodeDecodeError) as error:
        raise ValueError(f'{path} 应当是签名公钥（SubjectPublicKeyInfo DER）的十六进制') from error


def der(public):
    return public.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)


def signature_ok(public, manifest, signature):
    try:
        public.verify(signature, manifest, padding.PKCS1v15(), hashes.SHA256()); return True
    except InvalidSignature:
        return False


def check_package(data, dll, public, min_version, api):
    """Every problem --verify-only reports; an empty list means the main program will accept the package."""
    try: got_dll, manifest, signature = zip_entries(data)
    except (ValueError, zipfile.BadZipFile) as error: return [str(error)], None
    problems = []
    if got_dll != dll: problems.append('压缩包里不是当前的桥')
    if not signature_ok(public, manifest, signature): problems.append('签名核对不通过（不是用主程序内置公钥对应的私钥签的，或清单被改过）')
    parsed = parse_manifest(manifest)
    if parsed is None: problems.append('签名清单格式不对'); return problems, None
    version, size, sha, host_api = parsed
    if (size, sha) != (len(dll), hashlib.sha256(dll).hexdigest()): problems.append('签名清单里的大小或 SHA-256 与当前的桥不符')
    if host_api != api: problems.append(f'签名清单的 host_api={host_api}，主程序常量 机架联动_桥接口版本={api}')
    if version < min_version: problems.append(f'签名清单的版本 {version} 低于主程序常量 机架联动_桥最低版本={min_version}，这版主程序会拒绝它')
    return problems, version


def load_private(path, public):
    if not path.is_file():
        raise SystemExit(f'找不到签名私钥 {path}：把 服务端_电音基调 的 racklink_private.pem 放到 tools\\out-racklink，'
                         '或用 --sign-key、环境变量 RACKLINK_PRIVATE_KEY 指定')
    private = serialization.load_pem_private_key(path.read_bytes(), password=None)
    if der(private.public_key()) != der(public):
        raise SystemExit(f'{path} 与主程序内置的签名公钥（资源 机架联动_签名公钥）不是一对：用这把私钥签的桥，主程序一个都不会载入')
    return private


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--bridge', type=Path, default=ROOT / 'vst3/cpp' / ENTRY)
    parser.add_argument('--constants', type=Path, default=ROOT.parents[1] / '常量.e.txt')
    parser.add_argument('--key-resource', type=Path, default=ROOT.parents[1] / '资源' / '机架联动_签名公钥.txt')
    parser.add_argument('--out-dir', type=Path, default=ROOT / 'dist')
    parser.add_argument('--sign-key', type=Path, default=None, help='签名私钥（PEM）；默认取环境变量 RACKLINK_PRIVATE_KEY，再默认 tools/out-racklink/racklink_private.pem')
    parser.add_argument('--version', type=int, default=None, help='清单版本号；默认同一个桥沿用原版本，换了桥加 1')
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args(argv)
    dll = args.bridge.read_bytes()
    if dll[:2] != b'MZ':
        raise SystemExit(f'{args.bridge} 不是 PE 文件')
    sha, size = hashlib.sha256(dll).hexdigest(), len(dll)
    bom, text = read_text(args.constants)
    min_version, api = constants(text)
    public = signing_public(args.key_resource)
    package = args.out_dir / ZIPNAME
    if args.verify_only:
        problems, version = check_package(package.read_bytes(), dll, public, min_version, api) if package.is_file() else ([f'没有 {package}'], None)
        print(json.dumps({'status': 'failed' if problems else 'passed', 'problems': problems, 'version': version,
                          'bridge_sha256': sha, 'bridge_size': size}, ensure_ascii=False, indent=2))
        return 1 if problems else 0
    key_path = args.sign_key or (Path(os.environ['RACKLINK_PRIVATE_KEY']) if os.environ.get('RACKLINK_PRIVATE_KEY') else DEFAULT_KEY)
    private = load_private(key_path, public)
    previous = None
    if package.is_file():
        try:
            _, old_manifest, _ = zip_entries(package.read_bytes()); previous = parse_manifest(old_manifest)
        except (ValueError, zipfile.BadZipFile):
            previous = None                                   # an unsigned package from before signing
    if args.version is not None:
        if args.version < max(1, min_version):
            raise SystemExit(f'--version {args.version} 低于主程序常量 机架联动_桥最低版本={min_version}：这版主程序会拒绝它')
        version = args.version
    elif previous and previous[2] == sha and previous[3] == api:
        version = max(previous[0], min_version)              # same bridge: same manifest, same zip, same MD5; never below the floor
    elif previous:
        version = max(previous[0], min_version) + 1          # another bridge: a new version
    else:
        version = min_version + 1                             # no signed package to go on: never reuse the floor's number
    manifest = manifest_bytes(version, size, sha, api)
    signature = private.sign(manifest, padding.PKCS1v15(), hashes.SHA256())
    data = build_zip([(ENTRY, dll), (MANIFEST, manifest), (SIGNATURE, signature)])
    problems, _ = check_package(data, dll, public, version, api)
    if problems: raise SystemExit('生成的下载包核对不通过：' + '；'.join(problems))
    md5 = hashlib.md5(data).hexdigest()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    package.write_bytes(data)
    space_mb = max(1, -(-size * 3 // (1024 * 1024)))
    note = '\r\n'.join([
        f'上传到云端的文件：{package.name}（{len(data)} 字节，与本说明在同一个文件夹）',  # 不写绝对路径：在哪台机器上生成都对
        f'桥的签名清单：第 {version} 版，大小 {size} 字节，SHA-256 {sha}，宿主接口版本 {api}',
        '',
        'TCP_主服务端 启动窗口「设置4」页「机架联动桥 - 下载地址」：',
        f'  软件MD5：{md5}',
        f'  腾讯云文件名：{package.name}（上传到「腾讯云目录名」填的目录下）；外链1～3、iCloud、OneDrive、自搭直链：这个文件的分享链接或直链，填哪几个都行',
        f'  预计空间(MB)：{space_mb}',
        '  填好后点「保存」。',
        '',
        '带签名核对的主程序（本版起）照样接受这个桥（签名是 服务端_电音基调 的私钥，版本不低于主程序常量 机架联动_桥最低版本），不必重新发布主程序；',
        '只有改了宿主与桥之间的调用约定（机架联动_桥接口版本 加了 1）时，才要先发布新主程序。',
        '本版以前的主程序按固定的 SHA-256 核对、只认当时的桥：用户都换上带签名核对的主程序之前，不要换成新编译的桥。',
        '要换回旧桥：直接上传那一版的下载包，在「设置4」换回它的 MD5（版本号只是标签）。之前发布的主程序仍按每台电脑用过的版本拒绝，'
        '用户都换上新版之前，给它们的桥要比它们用过的版本高（bridge_package.py --version N）。要让所有用户都停用某个旧桥，在服务端机架联动管理界面调高「最低控制器版本」。',
        ''])
    (args.out_dir / 'bridge_package.txt').write_bytes(b'\xef\xbb\xbf' + note.encode('utf-8'))
    print(json.dumps({'status': 'passed', 'package': str(package), 'package_md5': md5, 'package_size': len(data), 'version': version,
                      'bridge_sha256': sha, 'bridge_size': size, 'host_api': api}, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
