#!/usr/bin/env python3
"""Verify PE resource checks and signature-normalized image digests on real PEs."""
import argparse
from pathlib import Path
import struct
import tempfile
from pe_resources import inspect, verify_resource


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--image', type=Path, required=True)
    args = ap.parse_args()
    source = args.image.read_bytes()
    original = inspect(args.image)
    pe = struct.unpack_from('<I', source, 0x3c)[0]
    optional = pe + 24
    magic = struct.unpack_from('<H', source, optional)[0]
    security = optional + (96 if magic == 0x10b else 112) + 32
    with tempfile.TemporaryDirectory(prefix='pe-tests-', dir=Path.cwd()) as d:
        temp = Path(d)
        # Synthetic certificate bytes test normalization only; this is not a signed PE.
        normalized = bytearray(source)
        normalized.extend(b'\0' * (-len(normalized) % 8))
        certificate_offset = len(normalized)
        certificate = struct.pack('<IHH', 40, 0x200, 2) + b'x' * 32
        normalized.extend(certificate)
        struct.pack_into('<II', normalized, security, certificate_offset, len(certificate))
        struct.pack_into('<I', normalized, optional + 64, 0x12345678)
        overlay = temp / 'synthetic-certificate.exe'
        overlay.write_bytes(normalized)
        assert inspect(overlay)['image_sha256'] == original['image_sha256']
        assert inspect(overlay)['sha256'] != original['sha256']
        mutated = bytearray(source)
        section = next(s for s in original['sections'] if s['size'])
        mutated[section['raw']] ^= 1
        changed = temp / 'changed-code.exe'
        changed.write_bytes(mutated)
        assert inspect(changed)['image_sha256'] != original['image_sha256']
        count = 0
        for key, data in original['resources'].items():
            if key.split('/')[0] == '10' and data:
                name = key.split('/')[1]
                verify_resource(original, name, data)
                try:
                    verify_resource(original, name, bytes([data[0] ^ 1]) + data[1:])
                except ValueError:
                    count += 1
                else:
                    raise AssertionError('Changed embedded resource was accepted')
        assert count, 'Fixture must contain RCDATA'
        truncated = temp / 'bad.exe'
        truncated.write_bytes(source[:64])
        try:
            inspect(truncated)
        except ValueError:
            pass
        else:
            raise AssertionError('Truncated PE accepted')
    print('PASS: real PE sections/resources, synthetic-signature normalization, code/resource mutation rejection and bounds validation')


if __name__ == '__main__':
    main()
