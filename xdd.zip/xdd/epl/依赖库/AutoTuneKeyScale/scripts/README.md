# 原生组件：编译、自检与发布（白话版）

本文的命令默认在 Windows 的“命令提示符（cmd）”里执行。`D:\xhh` 代表你的工程根目录，`D:\mingw64`、`D:\mingw32` 代表编译器位置，请换成你电脑上的实际位置。

## 1. 先看：我要不要编译？

| 你要做什么 | 要不要编译 C++ |
| --- | --- |
| 只用本包现有功能 | 不用。本包已附带编好的组件和云端下载包 `dist\keyscale_rack_bridge.zip`（主程序常量已与它对应）：上传下载包、在 TCP_主服务端 配好地址，再编译电音助手模块和主程序 |
| 只改服务器地址、账号或开放比例 | 不用 |
| 改了 C++ 源码，或更换授权公钥 | 要：编译原生组件（第 4 或第 5 节）→ 生成云端下载包（第 6 节）→ 编译主程序 |
| 要给控制器加 VMP、用自己的证书签名 | 要：按第 7 节的发布顺序 |

**本包的“已编译”不等于“已加 VMP”或“已用你的证书签名”**，这两步只能在你的电脑上做。

## 2. 一张图：谁装在谁里面

机架联动用到的组件是一层套一层的，外层文件里装着内层文件的完整副本：

```text
云端下载包 dist\keyscale_rack_bridge.zip（主程序按 TCP_主服务端 配的地址下载，只认 服务端_电音基调 私钥签名过的桥）
└─ keyscale_rack_bridge.dll                桥（32 位）
   ├─ keyscale_rack_controller.exe         托管控制器（64 位）
   │  ├─ managed\at_agent.dll         托管代理（64 位）
   │  ├─ managed\at_agent32.dll       托管代理（32 位）
   │  ├─ inject.exe                   注入器（64 位）
   │  └─ inject32.exe                 注入器（32 位）
```

**改了里面任何一层，外面每一层都要重新编译。**例如改了代理，就要依次重编控制器、桥，再生成云端下载包、重编主程序；只替换某个内层文件不会生效。

本工程只编托管版（编译时定义 `AT_XHH_MANAGED=1`），不再提供独立版控制器和代理。

## 3. 准备编译器（只做一次）

需要 64 位、32 位两套 MinGW-w64 编译器，而且必须是 **win32 线程模型**；另需 Python 3（第 4、6 节和自检用到）。任选一种方式：

### 方式 A（推荐）：WSL 里的 Ubuntu 24.04

与本包随附二进制用的是同一套编译器，编出来的文件与随包的逐字节相同，最容易核对。

1. 以管理员身份打开命令提示符，执行 `wsl --install -d Ubuntu-24.04`，按提示重启并设置 Ubuntu 的用户名和密码。
2. 打开“Ubuntu”，执行：

```bash
sudo apt update
sudo apt install -y g++-mingw-w64-x86-64-win32 g++-mingw-w64-i686-win32 python3
```

在 Ubuntu 里访问 Windows 的 D 盘用 `/mnt/d`，例如工程在 `/mnt/d/xhh`。

### 方式 B：直接在 Windows 上用 MinGW-builds

1. 打开 https://github.com/niXman/mingw-builds-binaries/releases ，下载**同一版本**的两个压缩包：以 `x86_64-` 开头、文件名含 `-win32-seh-` 的一个，以 `i686-` 开头、含 `-win32-dwarf-` 的一个。**文件名里必须有 `win32`**，不要下载含 `posix` 或 `mcf` 的。
2. 解压到 D 盘，得到 `D:\mingw64`、`D:\mingw32` 两个文件夹。
3. 检查（两条命令输出的最后几行里都要有 `Thread model: win32`，否则换压缩包）：

```bat
D:\mingw64\bin\g++.exe -v
D:\mingw32\bin\g++.exe -v
```

4. 从 https://www.python.org 安装 Python 3，安装时勾选“Add python.exe to PATH”；装好后在命令提示符里运行 `python -m pip install cryptography`（第 5 步给桥签名、第 6 步核对签名要用）。

方式 B 编出来的文件能正常使用，但与随包二进制不会逐字节相同（编译器版本不同），这是正常的。其它发行版（如 WinLibs、MSYS2）默认是 posix 线程，不符合要求；无论用哪种，都先确认看到 `Thread model: win32`。

## 4. 方式一：一条命令全自动编译

脚本按正确顺序编译全部组件，连续编两遍并核对两遍结果相同，再把 7 个文件写回工程的 `vst3\cpp`（两个代理在其中的 `managed` 文件夹里）。`--out` 必须是工程外**新建的空文件夹**，每次换一个新名字。

方式 A，在 Ubuntu 里：

```bash
cd /mnt/d/xhh/epl/依赖库/AutoTuneKeyScale
python3 scripts/build_reproducible.py --out /tmp/racklink-001 --publish
```

方式 B，在命令提示符里：

```bat
cd /d D:\xhh\epl\依赖库\AutoTuneKeyScale
python scripts\build_reproducible.py --out D:\RackLinkBuild\001 --compiler64 D:\mingw64\bin\g++.exe --compiler32 D:\mingw32\bin\g++.exe --windres64 D:\mingw64\bin\windres.exe --windres32 D:\mingw32\bin\windres.exe --publish
```

最后一行显示 `"status": "passed"` 和 `"published": true` 就是成功，接着做第 6 节。编译或核对失败时不会改动工程，原因写在 `--out` 文件夹的 `build.log` 里。

想了解细节：`build_manifest.json` 记录每个文件的哈希、编译器版本和实际执行的每一条命令；7 个文件先全部暂存核对再替换，写入出错会回滚，回滚也失败时清单写明 `publication.state=partial` 和原文件的恢复位置（见 `publish_transaction.json`）。所有链接都带 `-Wl,--no-insert-timestamp`，PE 时间戳为 0。

## 5. 方式二：双击 bat 一个个编译

`AutoTuneKeyScale\windows_build` 文件夹里有一组现成的 bat，双击即可，不用自己输入命令：

| 双击哪个 | 编译什么 | 编完接着运行 |
| --- | --- | --- |
| `0_build_all.bat` | 依次运行 1～6，全部重编 | 不用（最后自动检查） |
| `1_build_inject.bat` | 注入器 `inject.exe`、`inject32.exe` | 3 → 4 → 5 |
| `2_build_agent.bat` | 代理 `managed\at_agent.dll`、`managed\at_agent32.dll` | 3 → 4 → 5 |
| `3_build_controller.bat` | 控制器 `keyscale_rack_controller.exe`（只 64 位） | 4 → 5 |
| `4_build_bridge.bat` | 桥 `keyscale_rack_bridge.dll` | 5 |
| `5_make_bridge_package.bat` | 签名的云端下载包 `dist\keyscale_rack_bridge.zip`（主程序常量不改） | 上传下载包、在 TCP_主服务端 换上新的 MD5 |
| `6_check.bat` | 不编译，只检查每一层装进去的是不是工程里当前的文件 | 按提示 |

每个 bat 编完都会把结果放回工程，并在窗口里告诉你下一步运行哪个。编外层时，装进去的内层文件取自**工程里当前的版本**，所以只改了哪一层，就从那一层开始往外运行：

| 你改了什么 | 依次运行 |
| --- | --- |
| 代理源码 `combined\at_agent.cpp` | 2 → 3 → 4 → 5 |
| 注入器源码 `vst3\cpp\inject.cpp` | 1 → 3 → 4 → 5 |
| 控制器源码 `vst3\cpp\AutoTune_KeyScale_Controller.cpp` | 3 → 4 → 5 |
| 桥源码 `vst3\cpp\keyscale_rack_bridge.cpp` | 4 → 5 |
| 改了公共头文件，或拿不准改了哪些 | 0 |
| 只想确认现在是否一致 | 6 |

第一次使用前：

1. 按第 3 节方式 B 把编译器解压到 `D:\mingw64`、`D:\mingw32`（`C:\mingw64`、`C:\mingw32` 也能自动找到）。放在别处的，用记事本打开 `windows_build\config.bat`，改成实际位置后保存。
2. 安装 Python 3（第 3 节方式 B 第 4 步）。没有 Python 时 1～4 仍能编译，只是跳过核对；5 和 6 必须有 Python，而且要装 cryptography（`python -m pip install cryptography`）。

几点说明：

- 编译在临时文件夹 `C:\RackLinkBuild` 里进行（可在 `config.bat` 里改），每一步只放这一步的源码和取来的内层文件，不会装错；只有编译和核对都成功的文件才会放回工程。
- 出错时窗口会停住，并用中文说明原因：找不到编译器、缺少内层文件（会说先运行哪一个）、文件被占用（关闭主程序和机架后重试）。
- 方式 B 编出来的文件与随包二进制不会逐字节相同（编译器版本不同），可以正常使用；要与随包逐字节相同，用第 4 节方式 A。

## 6. 生成云端下载包，编译主程序

桥不再装在主程序资源里：主程序在真正要用机架联动时，按 TCP_主服务端 配的地址下载 `keyscale_rack_bridge.zip`，并且只载入 服务端_电音基调 私钥签名过的桥（签名清单 `keyscale_rack_bridge.manifest`／`.sig`，主程序用内置公钥（资源 `机架联动_签名公钥`）核对，再核对版本、宿主接口版本、大小和 SHA-256）。桥换了以后（私钥默认取 `tools\out-racklink\racklink_private.pem`，也可用 `--sign-key` 或环境变量 `RACKLINK_PRIVATE_KEY` 指定）：

```bat
cd /d D:\xhh\epl\依赖库\AutoTuneKeyScale
python scripts\bridge_package.py
python scripts\bridge_package.py --verify-only
```

第一条用私钥签名，生成 `dist\keyscale_rack_bridge.zip`（桥、签名清单、签名三个文件）和 `dist\bridge_package.txt`（主程序常量不改）：同一个桥沿用原来的版本号，每次生成的压缩包逐字节相同、MD5 也相同；换了桥版本号加 1，`--version N` 可以指定（不能低于常量 `机架联动_桥最低版本`）。版本号只是标签：主程序只要求不低于常量 `机架联动_桥最低版本`（平时保持 1，只在旧桥有安全问题时手动调高），不再按每台电脑用过的版本拒绝，换回旧桥直接上传旧包；要让所有用户都停用某个旧桥，在服务端机架联动管理界面调高「最低控制器版本」。之前发布的主程序仍按每台电脑用过的版本拒绝，用户都换上新版之前，给它们的桥要比它们用过的版本高。签名前先核对私钥与主程序内置的公钥是一对。第二条不需要私钥、什么都不改，只核对下载包的签名、清单与当前的桥和主程序常量一致。然后把压缩包上传，在 TCP_主服务端 启动窗口「设置4」页的「机架联动桥 - 下载地址」换上 `bridge_package.txt` 里的 MD5。本版起的主程序会接受新桥，不必重新发布；只有改了常量 `机架联动_桥接口版本`（宿主与桥的调用约定变了）时，才要先发布新主程序。本版以前的主程序按固定的 SHA-256 核对、只认当时的桥：用户都换上本版主程序之前，不要换成新编译的桥。

## 7. 正式发布：给注入器签名，给 agent 和控制器加 VMP，桥不加壳

> **推荐的加壳方案：agent + 控制器加壳，桥不加壳。** 桥本身没有敏感逻辑（只负责下载、验签、释放控制器），不必单独加壳；把壳花在 agent 和控制器这两个真正做注入／Hook／校验的组件上。最终桥约 105MB（三层全加壳约 200MB，少掉桥那一轮壳）。授权安全性与加不加壳无关（私钥只在服务端），理由与其它组合的取舍见 `docs/只给桥加壳的授权安全性.md`、体积详解见 `docs/VMP保护评估.md`。嫌 105MB 仍大，就按体积文档把虚拟化收敛到令牌验证一个函数、其余用变异，并勾“压缩输出”，或改用“只给桥加壳”（桥约 10MB、内层不加壳）。下面的步骤即按推荐方案：给 agent、控制器加壳，桥只签名、不加壳。

**用第 5 节的 bat 发布时最简单**：编外层时装进去的就是工程里当前的内层文件，所以只要在两步之间把签名、加 VMP 后的文件覆盖回原位置：

1. 运行 `1_build_inject.bat`、`2_build_agent.bat`。
2. 给 `vst3\cpp\inject.exe`、`inject32.exe` 签名（命令见 7.1，把路径换成工程里的这两个文件）。
3. 对 `vst3\cpp\managed\at_agent.dll`、`at_agent32.dll` 先加 VMP、再签名（加壳要点同 7.3；agent 是真正在宿主进程里注入／Hook 的那个，最该保护），结果覆盖回原位置。
4. 运行 `3_build_controller.bat`，它把已签名的注入器和**加壳后的 agent** 装进控制器。
5. 对 `vst3\cpp\keyscale_rack_controller.exe` 先加 VMP、再签名（见 7.3），结果覆盖回原位置（只 64 位控制器）。
6. 运行 `4_build_bridge.bat`，它把保护后的控制器装进桥。**桥不加壳**（推荐）；桥如需签名，给 `vst3\cpp\keyscale_rack_bridge.dll` 签名即可，不要对它加 VMP。
7. 运行 `5_make_bridge_package.bat`，上传 `dist\keyscale_rack_bridge.zip` 并在 TCP_主服务端 更新地址和 MD5，再编译主程序。

做完第 5 步后不要再运行 0、1、2、3，否则会重新编译并覆盖已经保护的文件。运行 `6_check.bat` 可以确认每一层装的都是最终文件。下面是用第 4 节脚本完成同一顺序的做法。

下面从 **随包的干净原生产物** 开始。先备份工程，将 `D:\xhh`、编译器位置、证书指纹和时间戳地址换成你自己的。代码签名使用 Windows 代码签名证书；`racklink_private.pem` 是联动授权服务的密钥，不是下面用来选择的 Windows 代码签名证书。

需要 Windows SDK 的 `signtool.exe`、Python 3、上述两套 MinGW-w64 win32 线程模型编译器，以及你实际安装的 VMProtect。先让这些工具能在命令提示符中调用。32 位和64位控制器都必须处理，不能只处理当前电脑会运行的一个。

### 7.1 第一步：准备内层文件，给注入器签名、给 agent 加壳

在命令提示符中执行。`D:\RackLinkRelease` 应是本次新建的发布目录；不要沿用已有半成品。

```bat
cd /d "D:\xhh\epl\依赖库\AutoTuneKeyScale"
mkdir "D:\RackLinkRelease\helpers\managed"
copy /b "vst3\cpp\managed\at_agent.dll" "D:\RackLinkRelease\helpers\managed\at_agent.dll"
copy /b "vst3\cpp\managed\at_agent32.dll" "D:\RackLinkRelease\helpers\managed\at_agent32.dll"
copy /b "vst3\cpp\inject.exe" "D:\RackLinkRelease\helpers\inject.exe"
copy /b "vst3\cpp\inject32.exe" "D:\RackLinkRelease\helpers\inject32.exe"
```

这四个文件必须来自同一套构建。推荐方案要给 **agent 加壳**：用 VMProtect 打开 `at_agent.dll`、`at_agent32.dll`，按 7.3 的要点（开导入保护＋内存保护，仅对低频授权路径那一处标记做虚拟化、其余变异，勾压缩输出），保护后覆盖回 `helpers\managed` 原位置，再与两个注入器一起签名。若你选“只给桥加壳”（体积最小、内层不加壳），则跳过给 agent 加壳，agent 保持原样、按需签名。以下用已安装证书的指纹选取签名身份，不把证书密码写进命令，命令里一并给加壳后的 agent 签名：

```bat
signtool sign /sha1 "你的代码签名证书指纹" /fd SHA256 /tr "证书机构提供的RFC3161时间戳地址" /td SHA256 "D:\RackLinkRelease\helpers\inject.exe"
signtool sign /sha1 "你的代码签名证书指纹" /fd SHA256 /tr "证书机构提供的RFC3161时间戳地址" /td SHA256 "D:\RackLinkRelease\helpers\inject32.exe"
signtool verify /pa /all /v "D:\RackLinkRelease\helpers\inject.exe"
signtool verify /pa /all /v "D:\RackLinkRelease\helpers\inject32.exe"
signtool sign /sha1 "你的代码签名证书指纹" /fd SHA256 /tr "证书机构提供的RFC3161时间戳地址" /td SHA256 "D:\RackLinkRelease\helpers\managed\at_agent.dll"
signtool sign /sha1 "你的代码签名证书指纹" /fd SHA256 /tr "证书机构提供的RFC3161时间戳地址" /td SHA256 "D:\RackLinkRelease\helpers\managed\at_agent32.dll"
signtool verify /pa /all /v "D:\RackLinkRelease\helpers\managed\at_agent.dll"
signtool verify /pa /all /v "D:\RackLinkRelease\helpers\managed\at_agent32.dll"
```

（最后四条是给加壳后的 agent 签名；选“只给桥加壳”时 agent 未加壳，可只按需签名或略过。）每条命令均须成功再继续。`/sha1` 指证书指纹，文件签名算法仍是 `/fd SHA256`。证书位于本机证书库而非当前用户证书库时，按你的证书安装方式给签名命令补 `/sm`。

### 7.2 第二步：把已签名注入器装进控制器

```bat
python scripts\build_reproducible.py --out "D:\RackLinkRelease\controllers-build" --compiler64 "D:\MinGW64\bin\g++.exe" --compiler32 "D:\MinGW32\bin\g++.exe" --windres64 "D:\MinGW64\bin\windres.exe" --windres32 "D:\MinGW32\bin\windres.exe" --signed-helpers "D:\RackLinkRelease\helpers" --publish
```

`--signed-helpers` 是“使用这个已经准备好的内层文件目录”的发布参数。脚本检查资源字节和构建结果，**不会代替 SignTool 验证证书**；参数名称也不代表目录里未签名的 agent 已被签名。

成功后，准备保护的是工程 `vst3\cpp` 下这个文件：`keyscale_rack_controller.exe`（只 64 位；纯 32 位 Windows 不再支持，不再有 32 位控制器）。不要拿前一步之前的旧副本去保护。

### 7.3 第三步：给控制器加 VMP，再签名

1. 在 VMProtect 中打开刚生成的控制器，选择实际需要保护的少量授权／校验函数。字节标识如何转换，须使用你实际具备的转换工具；没有转换工具时不能把“看到了标识”当成已经选中保护区。
   - **控制面：开启“导入保护(Import Protection)”和“内存保护(Memory Protection)”这两个全局开关**（隐藏 IAT、防运行时打补丁，几乎不增加体积）。只贴标记而不开导入保护，程序的 API 调用表仍是明文，注入/Hook 行为一眼可辨——理由与利弊见 `docs/VMP保护评估.md`。
   - **保护档位要克制**：真正值得“虚拟化(Virtualization)”的主要是令牌验证 `companion_verify_server_token`；`write_ctl_file`、`companion_copydata` 用“变异(Mutation)”即可；**热点扫描线程 `scan_thread` 不要虚拟化**（会严重拖慢并撑大体积），用变异或把标记移出热循环。**不要勾“虚拟化所有函数”之类的全局项。**
   - **盯住体积**：正常只虚拟化少量函数、其余变异时，单个控制器保护后一般只比未保护版(约 2.1MB)大几 MB，最终 `keyscale_rack_bridge.dll` 在 20MB 上下或更小。若保护后单个控制器上百 MB、桥达到上百 MB（曾出现过 206MB），说明虚拟化范围过大，回头把除令牌验证外的函数改为变异、关掉全局虚拟化。
2. 如果还需要 VMProtect 的归属水印，在其水印设置中建立／选取水印，并在各自的 VMP 工程中选中。不要把“SP 字节标识”和“VMP 归属水印”混为一个开关。
3. **保留内嵌资源。**输出到新的 `D:\RackLinkRelease\controllers` 目录，最终名称仍为 `keyscale_rack_controller.exe`。不要覆盖未保护输入。VMP 如果改变了内嵌 agent／注入器的资源字节，下一步构建会拒绝；需要调整保护设置，不能跳过检查。
4. 对这个保护输出执行下列签名与验签。任何保护／转换操作都必须在签名前完成。

```bat
signtool sign /sha1 "你的代码签名证书指纹" /fd SHA256 /tr "证书机构提供的RFC3161时间戳地址" /td SHA256 "D:\RackLinkRelease\controllers\keyscale_rack_controller.exe"
signtool verify /pa /all /v "D:\RackLinkRelease\controllers\keyscale_rack_controller.exe"
```

### 7.4 第四步：把最终控制器装进桥 DLL（桥不加壳），再生成云端下载包

```bat
python scripts\build_reproducible.py --out "D:\RackLinkRelease\bridge-build" --compiler64 "D:\MinGW64\bin\g++.exe" --compiler32 "D:\MinGW32\bin\g++.exe" --windres64 "D:\MinGW64\bin\windres.exe" --windres32 "D:\MinGW32\bin\windres.exe" --signed-helpers "D:\RackLinkRelease\helpers" --signed-controllers "D:\RackLinkRelease\controllers" --publish
```

脚本重新生成外层桥，并核对它嵌入的就是上一步两个最终控制器。**不要在这里又执行一次不带这两个发布参数的普通构建**，否则会重新生成未保护的控制器并覆盖这次发布结果。

**桥按推荐方案不加 VMP**（它只负责下载、验签、释放控制器，没有需要藏起来的敏感逻辑，加壳只会把已加壳的控制器再放大一轮、体积翻倍）。桥 DLL 如需代码签名，此时对 `vst3\cpp\keyscale_rack_bridge.dll` 只做签名和验签（不要加 VMP），然后生成签名的云端下载包：

```bat
python scripts\bridge_package.py
python scripts\bridge_package.py --verify-only
```

最后上传下载包、在 TCP_主服务端 换上新地址和 MD5，引用更新后的电音助手模块并编译完整主程序。主程序自己要加 VMP／签名时，也在正式编译后依次完成。更新运行目录里临时释放的 EXE 不会改变云端下载包；只给最外层 DLL 加 VMP 也不能证明它包含的控制器 EXE 已被保护。

启动最终主程序，让其实际释放文件；对释放出的注入器、控制器重新验签，并做授权、连续续期、自动切换暂停／恢复和真实机架回读检查。构建和签名验证不能代替这些运行检查。

## 附录 A：`SP_Begin_1` 字节标识是什么

本项目中 `epl\模块\SProtect转VMP水印模块.e~\资源\SP_Begin_1.Image.dat` 是以下 **15 个原始字节**，不是图片，也没有 ZLIB 包装：

```text
50 90 B8 59 34 90 E8 90 B8 86 5A 62 DF 90 58
```

同目录的 `SP_End.Image.dat` 是空文件。源码模块没有附带把这串字节转换为 VMProtect 保护区域的实现，所以不能把它当作标准 `VMProtectBegin/End` 指令对，也不能承诺 VMProtect 打开 EXE 后就自动识别。

本版控制器已在授权令牌验证的低频路径加入这串标识；不会放到机架音频回调或反复扫描的热路径里。**标识本身没有“保护强度”档位，也不会自动完成虚拟化。**如果你原来用另一个工具识别、转换这类 SProtect 标识，仍需使用那个实际工具；本包没有代替它。VMProtect 自己的“水印”是另一个功能，用于加入隐藏归属信息，需在 VMP 工程中单独选择，不能由这里的字节标识推断已经设置。

需要加 VMP 时，先对控制器的少量授权／校验逻辑进行选择性保护，保留资源；先验证启动、授权、连续续期和实际联动，再决定是否调整保护方式。不要直接把控制器全部函数、agent 音频／参数写入路径一起设为最高强度。性能和兼容性须用最终保护版实测，不能由标识数量或“最高强度”证明。

## 附录 B：结构与运行检查

```bat
python tests\epl_structure\check.py --tree "D:\xhh" --baseline "D:\Backups\previous-xhh.zip" --out "D:\RackLinkBuild\epl-check.json"
```

`tests/integration/run.py --help` 显示实机测试参数。在 Windows 上运行不传 Wine 参数；使用已安装的双架构工具链，管理员权限运行。Linux/Wine 只是可选的兼容性测试环境，不能代替 Windows 验收。

结构脚本核对本轮改动的 BOM、CRLF、控制语句、同一物理行调用、原注释控制序列和新程序集／资源登记；明确不代替易语言编译。运行脚本编译真实 Win32 进程 harness，使用生产协议头，覆盖 x64→x64、x86→x86、x86→x64。原生 Windows 下不传 `--wine64`／`--wine32`；须以管理员身份运行。

Wine 环境需要已工作的相应架构、可写临时目录与显示服务。脚本记录实际阻塞或失败，不将“编译成功”报告成“运行通过”。该 harness 覆盖待授权边界；合法在线授权、真实插件回读、音频性能和杀软兼容性另按部署教程第 3.2 节“在真实 Windows 和机架上验收”在真机上验收。

## 附录 C：在 Ubuntu（WSL）里手动编译

与 `windows_build` 里的 bat 执行的是同一组命令，适合在 Ubuntu 里不用脚本、自己逐段执行。在 Ubuntu 窗口里逐段粘贴，任何一条报错就停下：

```bash
SRC=/mnt/d/xhh/epl/依赖库/AutoTuneKeyScale
W=~/racklink-manual
G64=x86_64-w64-mingw32-g++-win32; R64=x86_64-w64-mingw32-windres
G32=i686-w64-mingw32-g++-win32;   R32=i686-w64-mingw32-windres
OPT="-O2 -finput-charset=UTF-8 -Wl,--no-insert-timestamp"
ST="-static -static-libgcc -static-libstdc++"
AGL="-lpsapi -lversion -luser32 -lkernel32 -ladvapi32"
CTL="-lcomctl32 -lpsapi -luser32 -lgdi32 -lkernel32 -lversion -ladvapi32"
rm -rf "$W"
mkdir -p "$W/combined" "$W/vst3/cpp"
cp "$SRC"/combined/*.cpp "$SRC"/combined/*.h "$W/combined/"
cp "$SRC"/vst3/cpp/*.cpp "$SRC"/vst3/cpp/*.h "$SRC"/vst3/cpp/*.rc "$W/vst3/cpp/"
```

```bash
cd "$W/vst3/cpp"
$G64 $OPT -o inject.exe inject.cpp -lpsapi $ST
$G32 $OPT -o inject32.exe inject.cpp -lpsapi $ST
$G64 $OPT -DAT_XHH_MANAGED=1 -shared -o at_agent.dll ../../combined/at_agent.cpp $AGL $ST
$G32 $OPT -DAT_XHH_MANAGED=1 -shared -o at_agent32.dll ../../combined/at_agent.cpp $AGL $ST
$R64 AutoTune_KeyScale_Controller.rc -O coff -o ctl64.o
$G64 $OPT -DAT_XHH_MANAGED=1 -mwindows -o keyscale_rack_controller.exe AutoTune_KeyScale_Controller.cpp ctl64.o $CTL $ST
cp keyscale_rack_controller.exe companion64.bin
$R32 keyscale_rack_bridge.rc -O coff -o bridge.o
$G32 $OPT -shared -Wl,--kill-at -o keyscale_rack_bridge.dll keyscale_rack_bridge.cpp bridge.o -lwinhttp -ladvapi32 -luser32 -lkernel32 $ST
```

自检并放回工程：

```bash
cd "$SRC"; M="$W/vst3/cpp"
python3 scripts/pe_resources.py "$M/keyscale_rack_bridge.dll" --verify-resource CONTROLLER64="$M/keyscale_rack_controller.exe" >/dev/null && echo "[OK] 桥"
python3 scripts/pe_resources.py "$M/keyscale_rack_controller.exe" --verify-resource AGENT64="$M/at_agent.dll" --verify-resource AGENT32="$M/at_agent32.dll" --verify-resource INJECT64="$M/inject.exe" --verify-resource INJECT32="$M/inject32.exe" >/dev/null && echo "[OK] 控制器"
cp "$M/at_agent.dll" "$M/at_agent32.dll" "$SRC/vst3/cpp/managed/"
cp "$M/inject.exe" "$M/inject32.exe" "$M/keyscale_rack_controller.exe" "$M/keyscale_rack_bridge.dll" "$SRC/vst3/cpp/"
```

两个 `[OK]` 都出现才放回工程。
