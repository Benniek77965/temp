#!/usr/bin/env python3
"""Static checks for windows_build/*.bat, the double-click per-component build.

The batch files mirror scripts/build_reproducible.py by hand, so this test keeps
them in step with it: compiler flags and link libraries, output names (the 7
published files of the managed-only build), the RCDATA input names the .rc files embed, and the order of
the steps.  It also pins the cmd idioms that were verified on Windows-style
cmd.exe (Wine, zh-CN code page 936) with MinGW-builds win32 toolchains:

* files are GBK (the default ANSI code page of Chinese Windows) with CRLF;
* no '||' or '&&': after CALL and after a multi-file COPY they were evaluated
  inconsistently, so every step uses 'if errorlevel 1 goto ...';
* no FOR loop in 0_build_all.bat and no nested 'do for': FOR variables leaked
  into called batches ('%B' inside '%BIN64%') or stayed unexpanded;
* Python is always started with stdin from NUL and its output redirected or
  logged, so a missing or odd console handle cannot stop it.

This is not a cmd.exe run. The batch files were run end to end in Wine cmd.exe
(zh-CN code page 936, project under a Chinese path) with MinGW-builds 13.2.0 win32
toolchains and Windows Python 3.12: all six steps, the four error cases (missing
inner file, missing compiler, no Python, inner layer changed but outer not rebuilt)
and swapping signed files between steps.
"""
from __future__ import annotations
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'windows_build'
NAMES = ['0_build_all.bat', '1_build_inject.bat', '2_build_agent.bat', '3_build_controller.bat',
         '4_build_bridge.bat', '5_make_bridge_package.bat', '6_check.bat', '_common.bat', 'config.bat']
failures, checks = [], []


def check(name, ok):
    checks.append(name)
    if not ok:
        failures.append(name)


def text(name):
    return (BUILD / name).read_bytes().decode('gbk')


sys.path.insert(0, str(ROOT / 'scripts'))
import build_reproducible as br


def br_names():
    return list(br.ARTIFACTS)


def main():
    for name in NAMES:
        check(f'{name}: present', (BUILD / name).is_file())
    raw = {n: (BUILD / n).read_bytes() for n in NAMES if (BUILD / n).is_file()}
    for n, data in raw.items():
        try:
            data.decode('gbk')
            gbk = True
        except UnicodeDecodeError:
            gbk = False
        check(f'{n}: GBK', gbk)
        check(f'{n}: CRLF only', b'\n' not in data.replace(b'\r\n', b''))
        t = data.decode('gbk', 'replace')
        check(f'{n}: no || or &&', '||' not in t and '&&' not in t)
        check(f'{n}: no nested FOR', not re.search(r'\bdo\s+for\b', t, re.I))
    t0 = text('0_build_all.bat')
    check('0_build_all: no FOR loop', 'for %%' not in t0.lower())
    order = re.findall(r'call "%HERE%(\d_[a-z_]+)\.bat" nopause\r\nif errorlevel 1 goto fail', t0)
    check('0_build_all: runs 1..6 in order and stops on failure', order == ['1_build_inject', '2_build_agent', '3_build_controller',
                                                                         '4_build_bridge', '5_make_bridge_package', '6_check'])

    src = (ROOT / 'scripts' / 'build_reproducible.py').read_text(encoding='utf-8')
    common = re.search(r"common = \[([^\]]*)\]", src).group(1)
    static = re.search(r"static = \[([^\]]*)\]", src).group(1)
    words = lambda s: re.findall(r"'([^']*)'", s)
    c = text('_common.bat')
    def var(name):
        m = re.search(r'^set "' + name + r'=([^"\r\n]*)"', c, re.M)
        return m.group(1).split() if m else None
    check('flags: OPT equals build_reproducible common', var('OPT') == words(common))
    check('flags: ST equals build_reproducible static', var('ST') == words(static))
    agent = re.search(r"'\.\./\.\./combined/at_agent\.cpp',\s*((?:'-l[a-z0-9]+',\s*)+)", src).group(1)
    ctl = re.search(r"'AutoTune_KeyScale_Controller\.cpp', res,\s*((?:'-l[a-z0-9]+',\s*)+)", src).group(1)
    bridge = re.search(r"bridge_res,\s*((?:'-l[a-z0-9]+',\s*)+)", src).group(1)
    check('libs: AGL equals the agent link libraries', var('AGL') == words(agent))
    check('libs: CTL equals the controller link libraries', var('CTL') == words(ctl))
    t4 = text('4_build_bridge.bat')
    check('libs: bridge links the same libraries with --kill-at', ' '.join(words(bridge)) in t4 and '-shared -Wl,--kill-at' in t4 and "'-Wl,--kill-at'" in src)
    t1, t2, t3 = text('1_build_inject.bat'), text('2_build_agent.bat'), text('3_build_controller.bat')
    check('inject: links psapi', t1.count('inject.cpp -lpsapi %ST%') == 2 and "'inject.cpp', '-lpsapi'" in src)
    check('agent: both agents are managed builds (AT_XHH_MANAGED) and none is built without it',
          t2.count('-DAT_XHH_MANAGED=1 -shared -o at_agent') == 2 and t2.count('-shared -o at_agent') == 2 and 'pushd "%M%"' in t2)
    check('controller: the one 64-bit controller is a managed build and is never built without it',
          t3.count('-DAT_XHH_MANAGED=1 -mwindows -o keyscale_rack_controller') == 1 and t3.count('-mwindows -o ') == 1)
    allbats = ''.join(text(n) for n in NAMES)
    check('no standalone leftovers in the bats', '%S%' not in allbats and 'standalone' not in allbats
          and 'AutoTune_KeyScale_Controller.exe' not in allbats and '%ROOT%\\combined"' not in allbats)
    check('build_reproducible builds the managed variant only', 'standalone' not in src and "'AutoTune_KeyScale_Controller.exe'" not in src
          and set(br_names()) == {'inject.exe', 'inject32.exe', 'managed/at_agent.dll', 'managed/at_agent32.dll',
                                 'keyscale_rack_controller.exe', 'keyscale_rack_bridge.dll'})

    published = {('vst3/cpp/' + n) for n in br.ARTIFACTS}
    puts = set()
    for n in ('1_build_inject.bat', '2_build_agent.bat', '3_build_controller.bat', '4_build_bridge.bat'):
        for m in re.finditer(r':put "%M%\\([^"]+)" "%CPP%(\\managed)?"', text(n)):
            puts.add('vst3/cpp' + (m.group(2) or '').replace('\\', '/') + '/' + m.group(1))
    check(f'outputs: the bats put back exactly the 6 published files {sorted(published ^ puts)}', puts == published and len(puts) == 6)
    check('outputs: controller names come from build_reproducible', all(n in t3 for n in br.CONTROLLERS))

    rc_ctl = (ROOT / 'vst3/cpp/AutoTune_KeyScale_Controller.rc').read_text(encoding='utf-8')
    rc_bridge = (ROOT / 'vst3/cpp/keyscale_rack_bridge.rc').read_text(encoding='utf-8')
    ctl_inputs = re.findall(r'RCDATA\s+"([^"]+)"', rc_ctl)
    bridge_inputs = re.findall(r'RCDATA\s+"([^"]+)"', rc_bridge)
    check('rc: controller embeds the four helpers step 3 provides in both folders',
          sorted(ctl_inputs) == ['at_agent.dll', 'at_agent32.dll', 'inject.exe', 'inject32.exe']
          and all(t3.count('"%M%\\' + f + '"') >= 1 for f in ctl_inputs))
    check('rc: bridge embeds only companion64.bin that step 4 provides',
          bridge_inputs == ['companion64.bin'] and '"%M%\\companion64.bin"' in t4)
    check('step 3 verifies the one controller, step 4 verifies the bridge, step 6 checks bridge and controller',
          t3.count(':verify "') == 1 and t4.count(':verify "') == 1 and text('6_check.bat').count(':verify "') == 2)
    for n in ('_common.bat', '5_make_bridge_package.bat', '6_check.bat'):
        t = text(n)
        py = [l for l in t.splitlines() if l.lstrip().startswith(('"%PYEXE%"', 'python -c', 'py -3 -c'))]
        check(f'{n}: Python stdin from NUL and output redirected', py and all('<nul' in l and '>' in l.replace('<nul', '') for l in py))
    for script in ('pe_resources.py', 'bridge_package.py'):
        check(f'referenced script exists: {script}', (ROOT / 'scripts' / script).is_file() and script in c + text('5_make_bridge_package.bat') + text('6_check.bat'))
    t5, t6 = text('5_make_bridge_package.bat'), text('6_check.bat')
    check('step 5 packages the bridge for download and reads it back; it no longer says it changes the main program constants',
          '"%ROOT%\\scripts\\bridge_package.py" >' in t5 and 'bridge_package.py" --verify-only' in t5 and '常量.e.txt' not in t5)
    check('step 6 checks the pinned constants and the package, no EPL resource any more',
          'bridge_package.py" --verify-only' in t6 and 'Image.dat' not in t6 and 'epl_resource' not in t5 + t6)
    print('PASS' if not failures else 'FAIL', len(checks) - len(failures), '/', len(checks))
    for f in failures:
        print('  FAIL', f)
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
