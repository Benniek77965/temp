#!/usr/bin/env python3
"""Inspect PE architecture, reproducibility metadata and embedded RCDATA bytes.

The image digest covers normalized headers and every raw section. Authenticode's
certificate and checksum fields are excluded so signing cannot hide code/resource
changes behind a successful certificate check.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import struct
from pathlib import Path


def require(ok, message):
    if not ok:
        raise ValueError(message)


def paths_alias(first, second):
    first, second = Path(first), Path(second)
    if first.resolve() == second.resolve():
        return True
    try:
        return first.samefile(second)
    except FileNotFoundError:
        return False


def inspect(path):
    b = Path(path).read_bytes()
    require(len(b) >= 64 and b[:2] == b'MZ', 'Not a PE image')
    pe = struct.unpack_from('<I', b, 0x3c)[0]
    require(pe + 24 <= len(b) and b[pe:pe + 4] == b'PE\0\0', 'Invalid PE header')
    machine, nsections, stamp = struct.unpack_from('<HHI', b, pe + 4)
    optional_size = struct.unpack_from('<H', b, pe + 20)[0]
    op = pe + 24
    require(op + optional_size <= len(b), 'Truncated optional header')
    magic = struct.unpack_from('<H', b, op)[0]
    require(magic in (0x10b, 0x20b), 'Unsupported PE optional header')
    directory_start = op + (96 if magic == 0x10b else 112)
    directory_count = struct.unpack_from('<I', b, directory_start - 4)[0]
    headers_size = struct.unpack_from('<I', b, op + 60)[0]
    require(headers_size <= len(b), 'Invalid SizeOfHeaders')
    sections = []
    for i in range(nsections):
        off = op + optional_size + i * 40
        require(off + 40 <= len(b), 'Truncated section table')
        raw_name, vsize, rva, size, raw = struct.unpack_from('<8s4I', b, off)
        require(raw + size <= len(b), 'Truncated PE section')
        sections.append({'name': raw_name.rstrip(b'\0').decode('ascii', 'replace'),
                         'rva': rva, 'vsize': vsize, 'size': size, 'raw': raw})
    def rva_offset(rva, size=1):
        for s in sections:
            if s['rva'] <= rva and rva + size <= s['rva'] + s['size']:
                return s['raw'] + rva - s['rva']
        if rva + size <= headers_size:
            return rva
        raise ValueError('RVA not backed by image bytes')
    normalized = bytearray(b[:headers_size])
    normalized[op + 64:op + 68] = b'\0' * 4
    if directory_count > 4:
        normalized[directory_start + 32:directory_start + 40] = b'\0' * 8
    digest = hashlib.sha256(normalized)
    for s in sections:
        digest.update(b[s['raw']:s['raw'] + s['size']])
    resources = {}
    if directory_count > 2:
        resource_rva, resource_size = struct.unpack_from('<II', b, directory_start + 16)
        if resource_rva and resource_size:
            base = rva_offset(resource_rva, resource_size)
            resource_end = base + resource_size
            seen = set()
            def resource_bounds(off, size):
                require(base <= off and off + size <= resource_end, 'Resource table out of bounds')
            def name_of(n):
                if not n & 0x80000000:
                    return str(n)
                off = base + (n & 0x7fffffff)
                resource_bounds(off, 2)
                count = struct.unpack_from('<H', b, off)[0]
                resource_bounds(off + 2, count * 2)
                return b[off + 2:off + 2 + count * 2].decode('utf-16le')
            def walk(offset, path):
                require(len(path) <= 3 and offset not in seen, 'Cyclic/deep resource directory')
                seen.add(offset)
                off = base + offset
                resource_bounds(off, 16)
                named, ids = struct.unpack_from('<HH', b, off + 12)
                resource_bounds(off + 16, (named + ids) * 8)
                for i in range(named + ids):
                    name_id, value = struct.unpack_from('<II', b, off + 16 + i * 8)
                    names = path + [name_of(name_id)]
                    if value & 0x80000000:
                        walk(value & 0x7fffffff, names)
                    else:
                        value_off = base + value
                        resource_bounds(value_off, 16)
                        data_rva, size, codepage, reserved = struct.unpack_from('<4I', b, value_off)
                        start = rva_offset(data_rva, size)
                        key = '/'.join(names)
                        require(key not in resources, 'Duplicate PE resource')
                        resources[key] = b[start:start + size]
                seen.remove(offset)
            walk(0, [])
    return {'machine': machine, 'pe_timestamp': stamp, 'image_sha256': digest.hexdigest(),
            'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b), 'resources': resources,
            'sections': sections}


def verify_resource(info, name, expected):
    matching = [data for key, data in info['resources'].items()
                if key.split('/')[:2] == ['10', name]]
    require(len(matching) == 1, 'Expected one RCDATA resource named ' + name)
    data = Path(expected).read_bytes() if isinstance(expected, (str, Path)) else expected
    require(matching[0] == data, 'Embedded RCDATA differs from release input: ' + name)


def summary(info):
    return {**{k: v for k, v in info.items() if k != 'resources'},
            'resources': {k: {'sha256': hashlib.sha256(v).hexdigest(), 'bytes': len(v)}
                          for k, v in info['resources'].items()}}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('image', type=Path)
    ap.add_argument('--verify-resource', action='append', default=[], metavar='NAME=FILE')
    ap.add_argument('--output', type=Path)
    args = ap.parse_args()
    if args.output and paths_alias(args.output, args.image):
        ap.error('--output cannot replace the input image')
    if args.output:
        for item in args.verify_resource:
            name, expected = item.split('=', 1)
            if paths_alias(args.output, expected):
                ap.error('--output cannot replace an expected resource input')
    info = inspect(args.image)
    for item in args.verify_resource:
        name, path = item.split('=', 1)
        verify_resource(info, name, path)
    output = json.dumps(summary(info), ensure_ascii=False, indent=2) + '\n'
    if args.output:
        args.output.write_text(output, encoding='utf-8')
    print(output, end='')


if __name__ == '__main__':
    main()
