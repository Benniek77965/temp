#!/usr/bin/env python3
"""Exercise real mutating CLIs: refused aliases preserve every input/output byte.

No Windows API, compiler, signing token or copied implementation is involved.
Use --scripts to execute the same safety matrix against an earlier script tree.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zlib

HERE = Path(__file__).resolve().parent


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--scripts', type=Path, default=HERE)
    ap.add_argument('--image', type=Path, default=HERE.parent / 'vst3/cpp/inject.exe')
    ap.add_argument('--log', type=Path)
    args = ap.parse_args()
    image = args.image.read_bytes()
    assert image[:2] == b'MZ', 'Use an actual PE image, not a header-only stand-in'
    records = []
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}
    with tempfile.TemporaryDirectory(prefix='output-paths-', dir=Path.cwd()) as directory:
        base = Path(directory)

        def execute(label, script, argv, protected, must_refuse=True):
            original = {path: path.read_bytes() if path.exists() else None for path in protected}
            process = subprocess.run([sys.executable, '-B', str(args.scripts.resolve() / script), *map(str, argv)],
                                     cwd=base, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            unchanged = all((path.read_bytes() if path.exists() else None) == data
                            for path, data in original.items())
            ok = process.returncode != 0 and unchanged if must_refuse else process.returncode == 0 and unchanged
            records.append({'case': label, 'returncode': process.returncode,
                            'protected_bytes_unchanged': unchanged, 'passed': ok,
                            'output': process.stdout[-1600:]})
            return process

        def alias(target, destination, kind):
            if kind == 'symlink':
                destination.symlink_to(target)
                return destination
            if kind == 'hardlink':
                os.link(target, destination)
                return destination
            if kind == 'relative':
                return Path(os.path.relpath(target, base))
            return target

        for script in ('pe_resources.py', 'epl_resource.py'):
            for kind in ('same', 'relative', 'symlink', 'hardlink'):
                case = base / (script + '-' + kind); case.mkdir()
                source = case / 'input.exe'; source.write_bytes(image)
                output = alias(source, case / 'output-alias.json', kind)
                argv = [source, '--output', output] if script == 'pe_resources.py' else ['--input', source, '--output', output]
                execute(script + ' output aliases input via ' + kind, script, argv, [source])
            case = base / (script + '-ordinary'); case.mkdir(); source = case / 'input.exe'; source.write_bytes(image)
            output = case / 'report.json' if script == 'pe_resources.py' else case / 'bridge.Image.dat'
            argv = [source, '--output', output] if script == 'pe_resources.py' else ['--input', source, '--output', output]
            execute(script + ' ordinary separate output', script, argv, [source], must_refuse=False)
            if script == 'pe_resources.py':
                assert json.loads(output.read_text())['sha256'] == hashlib.sha256(image).hexdigest()
            else:
                assert zlib.decompress(output.read_bytes()[8:]) == image

        bridge = HERE.parent / 'vst3/cpp/keyscale_rack_bridge.dll'
        controller = HERE.parent / 'vst3/cpp/keyscale_rack_controller.exe'
        case = base / 'pe-expected-resource'; case.mkdir()
        source = case / 'bridge.dll'; source.write_bytes(bridge.read_bytes())
        expected = case / 'expected-controller.exe'; expected.write_bytes(controller.read_bytes())
        execute('PE report aliases expected resource input', 'pe_resources.py',
                [source, '--verify-resource', 'CONTROLLER64=' + str(expected), '--output', expected],
                [source, expected])
        expected.write_bytes(controller.read_bytes())
        execute('PE ordinary verified-resource report', 'pe_resources.py',
                [source, '--verify-resource', 'CONTROLLER64=' + str(expected), '--output', case / 'report.json'],
                [source, expected], must_refuse=False)

    result = {'checks': len(records), 'failures': sum(not item['passed'] for item in records),
              'scope': 'Real production CLI processes, path/symlink/hardlink aliases, no Windows signing or native runtime',
              'cases': records}
    if args.log:
        args.log.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('PASS' if not result['failures'] else 'FAIL', str(result['checks']) + ' real CLI cases, ' + str(result['failures']) + ' failures')
    for case in records:
        if not case['passed']:
            print(json.dumps(case, ensure_ascii=False))
    return int(bool(result['failures']))


if __name__ == '__main__':
    raise SystemExit(main())
