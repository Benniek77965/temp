/*
 * vst3_abi.h - minimal self-written VST3 binary-interface declarations
 * (IIDs via the official INLINE_UID + COM_COMPATIBLE layout used on Windows,
 * and vtable method order), enough to host-enumerate and drive an Auto-Tune
 * VST3 plug-in's Key/Scale. Not copied from Steinberg SDK source.
 * 64-bit Windows.
 */
#ifndef VST3_ABI_H
#define VST3_ABI_H
#include <stdint.h>
#include <windows.h>

typedef int32_t tresult;
#define kResultOk        0
#define kResultTrue      0
#define kResultFalse     1
#define kNoInterface     ((tresult)0x80004002L)
#define kInvalidArgument ((tresult)0x80070057L)

typedef uint16_t char16;
typedef char16 String128[128];
typedef int32_t ParamID;
typedef double  ParamValue;
typedef uint8_t TUID[16];

/* Windows VST3 uses COM_COMPATIBLE IID byte layout. This macro reproduces it. */
#define VST3_UID(l1, l2, l3, l4) { \
  (uint8_t)((l1 & 0x000000FF)      ), (uint8_t)((l1 & 0x0000FF00) >>  8), \
  (uint8_t)((l1 & 0x00FF0000) >> 16), (uint8_t)((l1 & 0xFF000000) >> 24), \
  (uint8_t)((l2 & 0x00FF0000) >> 16), (uint8_t)((l2 & 0xFF000000) >> 24), \
  (uint8_t)((l2 & 0x000000FF)      ), (uint8_t)((l2 & 0x0000FF00) >>  8), \
  (uint8_t)((l3 & 0xFF000000) >> 24), (uint8_t)((l3 & 0x00FF0000) >> 16), \
  (uint8_t)((l3 & 0x0000FF00) >>  8), (uint8_t)((l3 & 0x000000FF)      ), \
  (uint8_t)((l4 & 0xFF000000) >> 24), (uint8_t)((l4 & 0x00FF0000) >> 16), \
  (uint8_t)((l4 & 0x0000FF00) >>  8), (uint8_t)((l4 & 0x000000FF)      ) }

static const TUID IID_FUnknown          = VST3_UID(0x00000000, 0x00000000, 0xC0000000, 0x00000046);
static const TUID IID_IPluginBase       = VST3_UID(0x22888DDB, 0x156E45AE, 0x8358B348, 0x08190625);
static const TUID IID_IPluginFactory    = VST3_UID(0x7A4D811C, 0x52114A1F, 0xAED9D2EE, 0x0B43BF9F);
static const TUID IID_IComponent        = VST3_UID(0xE831FF31, 0xF2D54301, 0x928EBBEE, 0x25697802);
static const TUID IID_IEditController    = VST3_UID(0xDCD7BBE3, 0x7742448D, 0xA874AACC, 0x979C759E);
static const TUID IID_IAudioProcessor   = VST3_UID(0x42043F99, 0xB7DA453C, 0xA569E79D, 0x9AAEC33D);
static const TUID IID_IComponentHandler = VST3_UID(0x93A0BEA3, 0x0BD05DE4, 0x8E6B0D8F, 0x4B0A4D3C);
static const TUID IID_IHostApplication  = VST3_UID(0x58E595CC, 0xDB2D4969, 0x8B6AAF8C, 0x36A664E5);
static const TUID IID_IEditController2  = VST3_UID(0x7F4EFE59, 0xF3204967, 0xAC27A3AE, 0xAFB63038);
static const TUID IID_IConnectionPoint  = VST3_UID(0x70A4156F, 0x6E6E4026, 0x989148BF, 0xAA60D8D1);
static const TUID IID_IUnitInfo         = VST3_UID(0x3D4BD6B5, 0x913A4FD2, 0xA886E768, 0xA5EB92C1);

enum { kClassInfoCategorySize = 32, kClassInfoNameSize = 64 };
typedef struct PClassInfo {
    TUID cid; int32_t cardinality;
    char category[kClassInfoCategorySize]; char name[kClassInfoNameSize];
} PClassInfo;

/* IPluginFactory : FUnknown */
typedef struct IPluginFactoryVtbl {
    tresult (WINAPI *queryInterface)(void*, const TUID, void**);
    uint32_t (WINAPI *addRef)(void*);
    uint32_t (WINAPI *release)(void*);
    tresult (WINAPI *getFactoryInfo)(void*, void*);
    int32_t (WINAPI *countClasses)(void*);
    tresult (WINAPI *getClassInfo)(void*, int32_t, PClassInfo*);
    tresult (WINAPI *createInstance)(void*, const TUID cid, const TUID iid, void** obj);
} IPluginFactoryVtbl;
typedef struct IPluginFactory { const IPluginFactoryVtbl* vtbl; } IPluginFactory;

/* IPluginBase : FUnknown  -> initialize(context), terminate() */
typedef struct IPluginBaseVtbl {
    tresult (WINAPI *queryInterface)(void*, const TUID, void**);
    uint32_t (WINAPI *addRef)(void*);
    uint32_t (WINAPI *release)(void*);
    tresult (WINAPI *initialize)(void*, void* context /*FUnknown*/);
    tresult (WINAPI *terminate)(void*);
} IPluginBaseVtbl;
typedef struct IPluginBase { const IPluginBaseVtbl* vtbl; } IPluginBase;

/* IComponent : IPluginBase. Full head through getControllerClassId, which is the first method
   after IPluginBase -- needed to resolve the controller class of a SEPARATED component/controller
   plug-in (the host creates the controller from that class id). */
typedef struct IComponentFullVtbl {
    tresult (WINAPI *queryInterface)(void*, const TUID, void**);
    uint32_t (WINAPI *addRef)(void*);
    uint32_t (WINAPI *release)(void*);
    tresult (WINAPI *initialize)(void*, void* context);
    tresult (WINAPI *terminate)(void*);
    tresult (WINAPI *getControllerClassId)(void*, TUID classId);
    /* setIoMode, getBusCount, ... follow; not used */
} IComponentFullVtbl;
typedef struct IComponentFull { const IComponentFullVtbl* vtbl; } IComponentFull;
typedef IPluginBase IComponent;

typedef struct ParameterInfo {
    ParamID id;
    String128 title; String128 shortTitle; String128 units;
    int32_t stepCount; ParamValue defaultNormalizedValue; int32_t unitId; int32_t flags;
} ParameterInfo;

/* IEditController : IPluginBase */
typedef struct IEditControllerVtbl {
    tresult (WINAPI *queryInterface)(void*, const TUID, void**);
    uint32_t (WINAPI *addRef)(void*);
    uint32_t (WINAPI *release)(void*);
    tresult (WINAPI *initialize)(void*, void* context);
    tresult (WINAPI *terminate)(void*);
    tresult (WINAPI *setComponentState)(void*, void*);
    tresult (WINAPI *setState)(void*, void*);
    tresult (WINAPI *getState)(void*, void*);
    int32_t (WINAPI *getParameterCount)(void*);
    tresult (WINAPI *getParameterInfo)(void*, int32_t, ParameterInfo*);
    tresult (WINAPI *getParamStringByValue)(void*, ParamID, ParamValue, String128);
    tresult (WINAPI *getParamValueByString)(void*, ParamID, char16*, ParamValue*);
    ParamValue (WINAPI *normalizedParamToPlain)(void*, ParamID, ParamValue);
    ParamValue (WINAPI *plainParamToNormalized)(void*, ParamID, ParamValue);
    ParamValue (WINAPI *getParamNormalized)(void*, ParamID);
    tresult (WINAPI *setParamNormalized)(void*, ParamID, ParamValue);
    tresult (WINAPI *setComponentHandler)(void*, void*);
    void* (WINAPI *createView)(void*, const char*);
} IEditControllerVtbl;
typedef struct IEditController { const IEditControllerVtbl* vtbl; } IEditController;

/* IComponentHandler : FUnknown -> beginEdit, performEdit, endEdit, restartComponent */
typedef struct IComponentHandlerVtbl {
    tresult (WINAPI *queryInterface)(void*, const TUID, void**);
    uint32_t (WINAPI *addRef)(void*);
    uint32_t (WINAPI *release)(void*);
    tresult (WINAPI *beginEdit)(void*, ParamID);
    tresult (WINAPI *performEdit)(void*, ParamID, ParamValue);
    tresult (WINAPI *endEdit)(void*, ParamID);
    tresult (WINAPI *restartComponent)(void*, int32_t);
} IComponentHandlerVtbl;
typedef struct IComponentHandler { const IComponentHandlerVtbl* vtbl; } IComponentHandler;

typedef IPluginFactory* (WINAPI *GetPluginFactoryProc)(void);
typedef bool (WINAPI *InitDllProc)(void);

static inline int tuid_eq(const TUID a, const TUID b) { return memcmp(a, b, 16) == 0; }

#endif
