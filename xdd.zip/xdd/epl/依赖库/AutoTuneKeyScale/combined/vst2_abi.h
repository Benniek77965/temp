/* vst2_abi.h - minimal self-written VST2 AEffect layout (enough to scan + setParameter). */
#ifndef VST2_ABI_H
#define VST2_ABI_H
#include <stdint.h>
#include <windows.h>
#define kEffectMagic 0x56737450  /* 'VstP' */
typedef intptr_t (__cdecl *DispatcherProc)(void*, int32_t, int32_t, intptr_t, void*, float);
typedef void     (__cdecl *SetParamProc)(void*, int32_t, float);
typedef float    (__cdecl *GetParamProc)(void*, int32_t);
typedef void     (__cdecl *ProcessProc)(void*, float**, float**, int32_t);
#pragma pack(push, 8)
typedef struct AEffect {
    int32_t magic;              /* +0x00 'VstP' */
    DispatcherProc dispatcher;  /* +0x08 (x64) / +0x04 (x86) */
    ProcessProc process;
    SetParamProc setParameter;
    GetParamProc getParameter;
    int32_t numPrograms;
    int32_t numParams;
    int32_t numInputs;
    int32_t numOutputs;
    int32_t flags;
    intptr_t resvd1;
    intptr_t resvd2;
    int32_t initialDelay;
    int32_t realQualities;
    int32_t offQualities;
    float   ioRatio;
    void*   object;
    void*   user;
    int32_t uniqueID;
    int32_t version;
    ProcessProc processReplacing;
    ProcessProc processDoubleReplacing;
    char    future[56];
} AEffect;
#pragma pack(pop)
/* dispatcher opcodes we use */
#define effGetEffectName 45
#define effGetParamName  8
#define effGetParamDisplay 7
#endif
