﻿/*
 * at_agent.cpp -- combined Auto-Tune agent (VST2 + VST3), injected into a host.
 * No code patching (PACE-safe). Scans for:
 *   - VST2 AEffect (magic 'VstP') with uniqueID ATxq(5.0.9) / ATxE(Evo) [or effectName contains Auto-Tune]
 *   - VST3 Auto-Tune 8.1 single-component controller (QI-verified)
 * Caches all found instances, auto re-locates every ~2s, and on command sets Key/Scale on ALL of them.
 * Files: the folder named in %TEMP%\at8_commdir.txt (1162: %LOCALAPPDATA%\AutoTune_KeyScale) -- cmd.ini, one line
 *   key=<0-11>|scale=<ScaleName>|...|t=<tick>; Key is universal (semitone/11), Scale resolved by NAME per plug-in.
 * Eject via eject.flag in that folder. Single instance per process. Log: agent.log in that folder.
 */
#include <windows.h>
#include "../vst3/cpp/companion_ui_routes.h"
#ifndef AT_XHH_MANAGED
#define AT_XHH_MANAGED 0
#endif
#if AT_XHH_MANAGED
#include "../vst3/cpp/companion_pipe.h"
#include "../vst3/cpp/companion_mailbox.h"
#include "../vst3/cpp/companion_policy.h"
#include "../vst3/cpp/companion_loader_policy.h"
#endif
#include <psapi.h>
#include <winver.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>
#include <ctype.h>
#include <setjmp.h>
#include "vst2_abi.h"
#include "vst3_abi.h"

/* ---- ASCII-only case folding --------------------------------------------------------------
   tolower() and _stricmp() follow LC_CTYPE, and this code runs inside whatever process the host
   happens to be, with whatever locale it has set. Two concrete ways that bites:
     * in a Turkish locale 'I' folds to a dotless 'i', so "LIVE.EXE" stops matching the "live"
       host fragment;
     * in a single-byte Latin locale the bytes 0xC0-0xDE are letters, so folding a path like
       "...\\电音11.vst3" (GBK) rewrites bytes that are halves of Chinese characters, and the
       folded path no longer corresponds to the real one.
   Every string we fold is compared against ASCII literals, so fold ASCII and nothing else. */
static int at_lower(int c){ return (c>='A'&&c<='Z') ? c+32 : c; }
static int at_stricmp(const char* a, const char* b){
    for(;;){ int ca=at_lower((unsigned char)*a), cb=at_lower((unsigned char)*b);
             if(ca!=cb) return ca-cb;
             if(!ca) return 0;
             a++; b++; } }
#undef  tolower
#define tolower(c)   at_lower(c)
#undef  _stricmp
#define _stricmp(a,b) at_stricmp((a),(b))
/* A UTF-8 BOM at the start of a list file must not become part of its first entry (1162). Notepad's "UTF-8"
   option used to write one; the settings window drops it when showing the file, so without this the window
   could show "ignore Waves" ticked while skip.txt's first line -- BOM + "waveshell" -- matched nothing. */
static void drop_bom(char* s){ if((unsigned char)s[0]==0xEF && (unsigned char)s[1]==0xBB && (unsigned char)s[2]==0xBF) memmove(s,s+3,strlen(s+3)+1); }
/* Open a file another process may be replacing this very moment (1162). The settings window writes a temp file
   and renames it over the old one, so a reader never sees half a list -- but WHILE the rename runs, an open fails
   with a sharing violation, and "cannot open" would be taken for "no list at all" for the rest of the session
   (Waves no longer skipped, say). Measured: 27 of 3000 opens during back-to-back replaces, every one a sharing
   violation, every one fine on a retry within 10 ms. Retry that one error briefly; any other is the real answer. */
static FILE* fopen_retry(const char* path, const char* mode){
    for(int i=0;;i++){
        FILE* f=fopen(path,mode);
        if(f || i>=20 || GetLastError()!=ERROR_SHARING_VIOLATION) return f;
        Sleep(5); } }

static HMODULE g_self=NULL; static HANDLE g_once=NULL;
static CRITICAL_SECTION g_cs; static int g_csInit=0; static FILE* g_log=NULL;
/* Guards the factory cache (g_gfMod/g_gfPtr) and the factory hook table (g_hookedVtbl/...).
   Those used to be touched only by the worker under g_cs. Since the EAT hook (below) runs the
   same code ON THE HOST THREAD, they need a lock of their own. It is always the INNERMOST lock
   (worker takes g_cs then this; the host thread takes only this), so no lock-order cycle exists.
   It is held for microseconds -- never across a call into the plug-in. */
static CRITICAL_SECTION g_hookCs; static int g_hookCsInit=0;
static char COMMDIR[MAX_PATH]="";          /* resolved shared dir (controller's run dir, or %TEMP%\at8) */
#define AT_BUILD 1166   /* bump whenever the agent changes; controller warns if a rack runs an older one */
/* The data folder's name under %LOCALAPPDATA% (1162). The controller creates it and keeps every file there;
   the two sources must agree on it -- t_mig compares them. */
#define AT_DATA_SUBDIR "AutoTune_KeyScale"
static char g_cmdPath[MAX_PATH], g_ejectPath[MAX_PATH], g_logPath[MAX_PATH], g_scalesPath[MAX_PATH], g_catchPath[MAX_PATH], g_statusPath[MAX_PATH];
static void LOG(const char* fmt,...);   /* forward decl (defined below) */
static char g_pendPath[MAX_PATH], g_blackPath[MAX_PATH], g_blackOldPath[MAX_PATH];
/* ---- persistent per-module circuit breaker ----
   Before we ever call a method on a VST3 candidate we write that candidate's MODULE path to
   g_pendPath (flushed). If that call takes the host down (e.g. a PACE-protected plug-in reacting to
   being probed with a pointer it does not recognise), the path survives. On the next launch, a
   marker whose process is gone tells us that module did not survive probing.

   What we DO about it changed in 1105. It used to disable the module for good, which solved the
   crash by throwing the plug-in away: the user's Auto-Tune simply stopped appearing, and the only
   cure was finding disabled.txt and deleting it. But "probing kills this module" does not mean the
   module is unusable -- it means the PROBE is the wrong way to find it. Catch mode is the other way:
   hook the factory, catch the instance as it is created, never touch an unknown pointer. So the
   module is now moved ONTO THE SAFE PATH instead of off the map, automatically, and it keeps
   working. The file is still read under its old name so an existing one keeps its meaning.

   This is what makes the behaviour general. Any plug-in that cannot tolerate probing migrates
   itself after at most one bad launch, with no catch.txt and nothing for the user to know. */
static char g_modBlack[16][MAX_PATH]; static int g_nModBlack=0;
/* was it recorded as "did not survive probing"? such a module is forced into catch mode */
static int mod_probe_unsafe(const char* path){ for(int i=0;i<g_nModBlack;i++) if(!_stricmp(g_modBlack[i],path)) return 1; return 0; }
/* user-editable skip list: skip.txt in the run dir, one substring per line (ASCII, case-insensitive).
   Any loaded module whose (lower-cased) path contains a listed substring is never scanned. Lets the
   user pre-exclude a plugin that doesn't tolerate probing, e.g. put "11.vst3" to exclude 电音11.vst3. */
static char g_skip[16][96]; static int g_nSkip=0; static char g_skipPath[MAX_PATH];
static char g_noeatPath[MAX_PATH]="";   /* presence disables the EAT hook (safety valve, no rebuild needed) */
static char g_scalemapPath[MAX_PATH];
static int mod_skiplisted_low(const char* lowpath){ for(int i=0;i<g_nSkip;i++) if(g_skip[i][0] && strstr(lowpath,g_skip[i])) return 1; return 0; }
static char g_pendNow[MAX_PATH]="";   /* in-memory copy of the marker, for the crash record */
static void cb_write_pending(const char* path){ snprintf(g_pendNow,sizeof g_pendNow,"%s",path?path:"");
    FILE* f=fopen(g_pendPath,"w"); if(f){ fputs(path,f); fflush(f); fclose(f); } }
/* Deleted rather than truncated (1162). fopen("w") left an empty pending_<pid>.txt for every process the agent
   sits in, re-created on every scan (1.2-2 s), and since 1149 it can only ever be empty: every registered
   module is on the catch path, so cb_write_pending() is never reached. Until 1162 that litter sat beside the
   controller's exe. An absent marker means what an empty one meant -- not probing: cb_startup() only ever
   adopts a marker that holds a module path. */
static void cb_clear_pending(){ g_pendNow[0]=0; DeleteFileA(g_pendPath); }
/* Is that process still running? Used to decide whether a leftover pending marker belongs to a run
   that actually died. If we cannot tell (access denied), assume it is ALIVE: never blacklist a
   module on a guess. */
static int proc_alive(unsigned long pid){
    if(!pid) return 0;
    HANDLE h=OpenProcess(SYNCHRONIZE,FALSE,(DWORD)pid);
    if(!h) return (GetLastError()==ERROR_ACCESS_DENIED);
    DWORD w=WaitForSingleObject(h,0); CloseHandle(h);
    return w==WAIT_TIMEOUT; }
static void cb_startup(){
    /* Adopt the pending markers of runs that are no longer alive.
       The marker used to be one shared pending.txt for every host. With two hosts running at once --
       which is the normal case as soon as a 32-bit plug-in puts the DAW's bridge process in play --
       a host starting up would read the marker belonging to a host that is still happily PROBING,
       conclude it had crashed on that module, and blacklist a perfectly good plug-in FOREVER (the
       blacklist lives on disk, so restarting does not help). It would also clear the other host's
       marker, so a real crash there would go unrecorded. Markers are per-process now, and only ones
       whose process is gone are acted on. */
    char pat[MAX_PATH]; snprintf(pat,sizeof pat,"%s\\pending_*.txt",COMMDIR);
    WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA(pat,&fd);
    if(hf!=INVALID_HANDLE_VALUE){ do{
        unsigned long pid=strtoul(fd.cFileName+8,NULL,10);     /* skip "pending_" */
        if(pid==(unsigned long)GetCurrentProcessId()) continue;
        if(proc_alive(pid)) continue;                          /* that host is still running */
        char fp[MAX_PATH]; snprintf(fp,sizeof fp,"%s\\%s",COMMDIR,fd.cFileName);
        char pend[MAX_PATH]=""; FILE* f=fopen(fp,"r");
        if(f){ if(fgets(pend,sizeof pend,f)){ int n=(int)strlen(pend);
                   while(n>0 && (unsigned char)pend[n-1]<=' ') pend[--n]=0; } fclose(f); }
        if(pend[0]){
            /* Only once per module. Appending unconditionally meant a plug-in that failed
               repeatedly wrote its own path again on every launch -- and a handful of duplicates
               from ONE module could use up the whole 16-entry table, leaving no room for the next
               module that needs protecting. The protection would silently stop working for
               everything else, and never recover. */
            int already=0;
            { FILE* r=fopen_retry(g_blackPath,"r");
              if(r){ char ln[MAX_PATH]; int first=1;
                  while(fgets(ln,sizeof ln,r)){ if(first){ first=0; drop_bom(ln); } int k=(int)strlen(ln);
                      while(k>0 && (unsigned char)ln[k-1]<=' ') ln[--k]=0;
                      if(k>0 && !_stricmp(ln,pend)){ already=1; break; } }
                  fclose(r); } }
            if(!already){ FILE* b=fopen(g_blackPath,"a"); if(b){ fprintf(b,"%s\n",pend); fclose(b); } }
            LOG("pid %lu died while probing %s -> that module will be caught at the factory "
                "from now on instead of probed (it stays usable)%s",pid,pend,
                already?" [already recorded]":""); }
        DeleteFileA(fp);
    } while(FindNextFileA(hf,&fd)); FindClose(hf); }
    cb_clear_pending();
    /* load the blacklist */
    g_nModBlack=0;
    for(int which=0; which<2; which++){      /* current name first, then the pre-1114 one */
        FILE* b=fopen_retry(which?g_blackOldPath:g_blackPath,"r");
        if(b){ char line[MAX_PATH]; int first=1; while(fgets(line,sizeof line,b)){ if(first){ first=0; drop_bom(line); } int n=(int)strlen(line);
                while(n>0&&(line[n-1]=='\n'||line[n-1]=='\r'||line[n-1]==' ')) line[--n]=0;
                if(n>0 && line[0]=='#') n=0;     /* 注释:与其余配置文件一致 */
                if(n>0){ int dup=0; for(int k=0;k<g_nModBlack;k++) if(!_stricmp(g_modBlack[k],line)){ dup=1; break; }
                         if(!dup && g_nModBlack<16){ snprintf(g_modBlack[g_nModBlack],MAX_PATH,"%s",line); g_nModBlack++; } } } fclose(b); } }
    if(g_nModBlack>0) LOG("%d module(s) known not to survive probing -> caught at the factory instead",g_nModBlack);
    /* load the user skip list (lower-cased for case-insensitive substring match) */
    g_nSkip=0; FILE* s=fopen_retry(g_skipPath,"r");
    /* Comments and leading blanks are skipped here exactly as in scalemap.txt and dawhost.txt.
       This file used to take every non-empty line as a pattern, '#' and all -- so a note such as
       "# disable Waves" quietly used up one of the 16 slots, and the four config files disagreed
       about whether '#' meant anything at all, with nothing to tell the user which was which.
       The whole file is read; lines past the limit are reported rather than dropped in silence. */
    if(s){ char line[96]; int dropped=0, first=1;
        while(fgets(line,sizeof line,s)){ if(first){ first=0; drop_bom(line); } int n=(int)strlen(line);
            while(n>0&&(line[n-1]=='\n'||line[n-1]=='\r'||line[n-1]==' '||line[n-1]=='\t')) line[--n]=0;
            int b=0; while(line[b]==' '||line[b]=='\t') b++;
            if(!line[b] || line[b]=='#') continue;
            if(g_nSkip>=16){ dropped++; continue; }
            int j=0; for(int i=b;line[i];i++) g_skip[g_nSkip][j++]=(char)tolower((unsigned char)line[i]);
            g_skip[g_nSkip][j]=0; g_nSkip++; }
        fclose(s);
        if(g_nSkip>0) LOG("%d user skip pattern(s) loaded from skip.txt",g_nSkip);
        if(dropped)   LOG("WARN: skip.txt: %d line(s) past the 16-pattern limit were ignored",dropped); }
}
/* %LOCALAPPDATA% in the ANSI code page -- exactly, or not at all (1162). Read as Unicode and converted here: the
   ANSI GetEnvironmentVariableA maps characters the code page lacks to look-alikes or '?', yielding a DIFFERENT path
   that may even exist, and Wine's cuts a double-byte value short (measured under code page 936: ...\张三 came back
   as ...\张). A lossy conversion returns 0 and the caller falls back to %TEMP%\at8. */
static int local_appdata_ansi(char* out, int cap){
    wchar_t w[MAX_PATH]; DWORD n=GetEnvironmentVariableW(L"LOCALAPPDATA",w,MAX_PATH);
    out[0]=0;
    if(n==0 || n>=MAX_PATH) return 0;
    BOOL lossy=FALSE;
    int k=WideCharToMultiByte(CP_ACP,WC_NO_BEST_FIT_CHARS,w,-1,out,cap,NULL,&lossy);
    if(k<=0 || lossy){ out[0]=0; return 0; }
    return k-1; }
static void resolve_commdir(){
    char tmp[MAX_PATH]=""; GetTempPathA(MAX_PATH,tmp);
    char ptr[MAX_PATH]; snprintf(ptr,sizeof ptr,"%sat8_commdir.txt",tmp);
    FILE* f=fopen(ptr,"r");
    if(f){ if(fgets(COMMDIR,sizeof COMMDIR,f)){ int n=(int)strlen(COMMDIR);
            while(n>0&&(COMMDIR[n-1]=='\n'||COMMDIR[n-1]=='\r'||COMMDIR[n-1]==' '||COMMDIR[n-1]=='\t')) COMMDIR[--n]=0; } fclose(f); }
    /* No %TEMP% pointer: a temp-folder clean-up can remove it while the controller has been running for days.
       The controller leaves a second pointer in a non-temp spot it always has -- %LOCALAPPDATA%\AutoTune_KeyScale\
       commdir.txt -- naming where COMMDIR really is (the data folder now lives under the main program's runtime
       dir, which the agent, injected in a host, cannot know on its own). Read that; accept only if it names an
       existing folder. */
    if(!COMMDIR[0]){ char la[MAX_PATH]=""; int n=local_appdata_ansi(la,MAX_PATH);
        if(n>0 && n+1+(int)sizeof(AT_DATA_SUBDIR)<MAX_PATH){ char bp[MAX_PATH]; snprintf(bp,sizeof bp,"%s\\" AT_DATA_SUBDIR "\\commdir.txt",la);
            FILE* bf=fopen(bp,"r");
            if(bf){ char d[MAX_PATH]=""; if(fgets(d,sizeof d,bf)){ int k=(int)strlen(d); while(k>0&&(unsigned char)d[k-1]<=' ') d[--k]=0; }
                fclose(bf);
                DWORD at=(d[0]?GetFileAttributesA(d):INVALID_FILE_ATTRIBUTES);
                if(at!=INVALID_FILE_ATTRIBUTES && (at&FILE_ATTRIBUTE_DIRECTORY)) snprintf(COMMDIR,sizeof COMMDIR,"%s",d); } } }
    /* Still nothing: the pre-move controller kept its files directly in %LOCALAPPDATA%\AutoTune_KeyScale -- if that
       folder exists, that is an older controller and that is where it is. %TEMP%\at8 stays the last resort. */
    if(!COMMDIR[0]){ char la[MAX_PATH]=""; int n=local_appdata_ansi(la,MAX_PATH);
        if(n>0 && n+1+(int)sizeof(AT_DATA_SUBDIR)<MAX_PATH){ char d[MAX_PATH]; snprintf(d,sizeof d,"%s\\" AT_DATA_SUBDIR,la);
            DWORD at=GetFileAttributesA(d);
            if(at!=INVALID_FILE_ATTRIBUTES && (at&FILE_ATTRIBUTE_DIRECTORY)) snprintf(COMMDIR,sizeof COMMDIR,"%s",d); } }
    if(!COMMDIR[0]) snprintf(COMMDIR,sizeof COMMDIR,"%sat8",tmp);
    CreateDirectoryA(COMMDIR,NULL);
    snprintf(g_cmdPath,sizeof g_cmdPath,"%s\\cmd.ini",COMMDIR);
    snprintf(g_ejectPath,sizeof g_ejectPath,"%s\\eject.flag",COMMDIR);
    snprintf(g_logPath,sizeof g_logPath,"%s\\agent.log",COMMDIR);
    snprintf(g_scalesPath,sizeof g_scalesPath,"%s\\scales_%lu.txt",COMMDIR,(unsigned long)GetCurrentProcessId());
    snprintf(g_statusPath,sizeof g_statusPath,"%s\\status_%lu.txt",COMMDIR,(unsigned long)GetCurrentProcessId());
    snprintf(g_catchPath,sizeof g_catchPath,"%s\\catch.txt",COMMDIR);
    snprintf(g_pendPath,sizeof g_pendPath,"%s\\pending_%lu.txt",COMMDIR,GetCurrentProcessId());
    /* Named for what it now MEANS. Until 1105 this file disabled a module outright, and "disabled"
       was accurate; since then the module is merely moved onto the factory-hook path, which does not
       probe -- the plug-in keeps working. The old name actively misleads: it reads as "something of
       yours has been switched off", and deleting it (the obvious reaction) sends that module straight
       back to the probing path that crashed or hung the host in the first place. The previous name is
       still read so an existing file keeps its meaning. */
    snprintf(g_blackPath,sizeof g_blackPath,"%s\\use_factory_hook.txt",COMMDIR);
    snprintf(g_blackOldPath,sizeof g_blackOldPath,"%s\\disabled.txt",COMMDIR);
    snprintf(g_skipPath,sizeof g_skipPath,"%s\\skip.txt",COMMDIR);
    snprintf(g_noeatPath,sizeof g_noeatPath,"%s\\noeat.txt",COMMDIR);
    snprintf(g_scalemapPath,sizeof g_scalemapPath,"%s\\scalemap.txt",COMMDIR);
}
/* ---- lazy log ----
   The agent is injected into every candidate host, and most of them turn out to have no Auto-Tune /
   Waves plug-in at all (on one machine 5 of 6 injected processes found nothing -- QQ, WeChat, ...).
   Those processes used to create and hold agent.log open anyway, which locked the file and filled it
   with noise from unrelated programs. Now nothing is written until the agent has actually found
   something: early lines go into a small buffer and are flushed only if the log is ever "armed".
   A process with no plug-in therefore never touches the file at all. */
#define PREMAX 64
static char g_preBuf[PREMAX][220]; static volatile LONG g_nPre=0; static volatile LONG g_logArmed=0;
/* Every record carries the time since the HOST started, "+12.345" seconds. Until 1148 the log had no
   time at all, so questions like "how long after the last capture did the host die" or "did the agent
   arrive before the project loaded" could not be answered from it. The base is taken in DllMain:
   the host's age at attach plus GetTickCount since then -- monotonic, two cheap calls per record. */
static DWORD g_logTick0=0, g_logHostMs0=0;
static DWORD log_now_ms(){ return g_logHostMs0 + (GetTickCount()-g_logTick0); }
/* Compose one record "[pid] +S.mmm text\n" in ONE buffer so it can be written in one call.
   Truncation used to clamp the text to cap-1-n characters, but vsnprintf only writes cap-2-n of them
   and puts its terminating NUL in the last one -- so an over-long record went out with a NUL byte just
   before the newline (latent: no real log line has been that long yet, but tools then treat the file
   as binary). The clamp is now cap-2-n, and the newline overwrites the NUL. */
static int log_compose(char* line, int cap, unsigned long pid, unsigned long ms, const char* fmt, va_list ap){
    int n = snprintf(line,(size_t)cap,"[%lu] +%lu.%03lu ",pid,ms/1000UL,ms%1000UL);
    if(n<0) n=0;
    if(n>cap-2) n=cap-2;
    int m = vsnprintf(line+n,(size_t)(cap-1-n),fmt,ap);
    if(m<0) m=0;
    if(m>cap-2-n) m=cap-2-n;                       /* what vsnprintf actually wrote, never its NUL */
    n += m;
    line[n++]='\n';
    return n; }
static void LOG(const char* fmt,...){
    if(!g_logArmed){                                   /* not armed yet -> buffer, touch no file */
        LONG idx=InterlockedIncrement(&g_nPre)-1;
        if(idx<PREMAX){ DWORD t=log_now_ms(); int k=snprintf(g_preBuf[idx],sizeof g_preBuf[idx],"+%lu.%03lu ",(unsigned long)(t/1000),(unsigned long)(t%1000));
            if(k<0) k=0;
            if(k>(int)sizeof g_preBuf[idx]-1) k=(int)sizeof g_preBuf[idx]-1;
            va_list ap; va_start(ap,fmt); vsnprintf(g_preBuf[idx]+k,sizeof g_preBuf[idx]-(size_t)k,fmt,ap); va_end(ap); }
        return; }
    if(!g_log){ if(g_logPath[0]) g_log=fopen(g_logPath,"a");
        if(!g_log){ const char* t=getenv("TEMP"); if(t){ char p[512]; snprintf(p,sizeof p,"%s\\at8_agent.log",t); g_log=fopen(p,"a"); } } }
    if(!g_log) return;
    /* Several processes share this one file (a 32-bit plug-in runs in the DAW's bridge
       process), and without a marker their lines interleave with no way to tell which
       process produced which -- that alone made one diagnosis go wrong. */
    /* Compose the whole record first and write it ONCE. Several agents append to this one file, and
       three separate writes per record let two records interleave mid-line -- which matters here
       because the log is the only diagnostic this project has. */
    char line[1024];
    va_list ap; va_start(ap,fmt);
    int n = log_compose(line,(int)sizeof line,(unsigned long)GetCurrentProcessId(),(unsigned long)log_now_ms(),fmt,ap);
    va_end(ap);
    fwrite(line,1,(size_t)n,g_log); fflush(g_log);
}
/* called the moment this process is known to host a plug-in we care about */
static void log_arm(){
    if(g_logArmed) return;
    LONG n=g_nPre; if(n>PREMAX) n=PREMAX;
    if(g_logPath[0]) g_log=fopen(g_logPath,"a");
    if(!g_log){ const char* t=getenv("TEMP"); if(t){ char p[512]; snprintf(p,sizeof p,"%s\\at8_agent.log",t); g_log=fopen(p,"a"); } }
    if(!g_log) return;
    for(LONG i=0;i<n;i++) if(g_preBuf[i][0]){ fprintf(g_log,"[%lu] ",GetCurrentProcessId()); fputs(g_preBuf[i],g_log); fputc('\n',g_log); }
    fflush(g_log);
    g_logArmed=1;   /* armed only once the file is actually open, so a concurrent LOG on a host
                       thread cannot see "armed" and open a second handle to the same file */
}

/* ---------------- scale tables (name -> index) ---------------- */
static int norm(const char* in,char* out,int n){int j=0;for(int i=0;in[i]&&j<n-1;i++){char c=in[i];
    if(c==' '||c=='.'||c=='('||c==')'||c=='&'||c=='-'||c=='\t'||c=='\'')continue; out[j++]=(char)tolower((unsigned char)c);} out[j]=0; return j;}
/* AT8 VST3 + Evo 6.0.9 share this order */
static const char* SCALES_STD[29]={"Major","Minor","Chromatic","Ling Lun","Scholar's Lute","Greek diatonic",
 "Greek chromatic","Greek enharmonic","Pythagorean","Just (major)","Just (minor)","Meantone","Werckmeister III",
 "Vallotti & Young","Barnes-Bach","Indian","Slendro","Pelog","Arabic 1","Arabic 2","19 Tone","24 Tone","31 Tone",
 "53 Tone","Partch","Carlos Alpha","Carlos Beta","Carlos Gamma","Harmonic"};
/* NOTE: Auto-Tune 5.0.9 (CN), Evo 6.0.9 and AT8 all share the SAME 29-scale order
   (the 5.0.9 Chinese labels are gibberish transliterations, but the ORDER is standard,
   confirmed by meaningful anchors + slot counts). So all versions use SCALES_STD. */
static int scale_same(const char* aNorm, const char* bNorm);   /* fwd: synonym-aware comparison */
static int scale_name_to_index(const char* const* tbl,const char* want){
    char w[64]; norm(want,w,sizeof w); if(!w[0])return -1;
    for(int i=0;i<29;i++){char a[64]; norm(tbl[i],a,sizeof a); if(scale_same(a,w))return i;} return -1; }
static void u16toascii(const char16* w,char* out,int n){ int j=0; for(int i=0;i<127&&w[i]&&j<n-1;i++){ char16 c=w[i]; out[j++]=(c<128)?(char)c:'?'; } out[j]=0; }
static double key_to_value(int semi){ return semi/11.0; }
static double scale_to_value_idx(int idx){ return idx/28.0; }

/* ---------------- crash-safe probe (VEH + longjmp) ----------------
   g_probing selects which recovery point a worker-thread fault jumps to:
     1 = inside a validate/discover/set helper      -> g_jb
     2 = inside the raw heap-scan region read loop   -> g_scanjb
   The scan reads arbitrary committed memory that another thread may free underneath us, and it may
   call queryInterface() on a slot that only coincidentally holds a known vtable; BOTH must be
   fault-tolerant or the host crashes. */
static volatile LONG g_probing=0; static jmp_buf g_jb; static jmp_buf g_scanjb; static DWORD g_workerTid=0;
/* A parameter write is handed to the HOST's UI thread (see ui_post below), so it runs outside the
   worker's guard and needs one of its own. Separate buffer and separate thread id: a jmp_buf may
   only be longjmp'd on the thread that set it up. */
static volatile LONG g_uiProbing=0,g_uiExecuting=0; static jmp_buf g_uiJb; static DWORD g_uiProbeTid=0;
#ifndef EXCEPTION_GUARD_PAGE
#define EXCEPTION_GUARD_PAGE 0x80000001L
#endif
#define EXC_CPP 0xE06D7363UL   /* MSVC C++ exception ("msc") */
static LONG CALLBACK veh(PEXCEPTION_POINTERS ep){
    if(g_probing && GetCurrentThreadId()==g_workerTid){ DWORD c=ep->ExceptionRecord->ExceptionCode;
        /* SOFT mode (g_probing==3): the plug-in's OWN C++ exceptions are normal control flow inside its
           code and are handled by its own catch blocks. Longjmping out of one skips its destructors and
           leaves its state half-built -- which is exactly what made the first factory enumeration "fault"
           and abort. In soft mode we let C++ exceptions pass through and still catch real hardware faults. */
        if(g_probing==3 && c==(DWORD)EXC_CPP) return EXCEPTION_CONTINUE_SEARCH;
        /* Recover from ANY error/warning-severity fault during a probe: not just AV, but also
           in-page errors, illegal/priv instructions, breakpoints and misaligns from a wild call
           into garbage, C++ exceptions, div-by-zero, etc. Calling queryInterface()/getParameterCount()
           on a heap slot that only coincidentally matches a plugin vtable can raise any of these.
           Stack overflow and guard-page faults are NOT recoverable via longjmp, so let them pass. */
        if(c!=EXCEPTION_STACK_OVERFLOW && c!=(DWORD)EXCEPTION_GUARD_PAGE && (c & 0x80000000u)){
            if(g_probing==2) longjmp(g_scanjb,1); else longjmp(g_jb,1); } }
    if(g_uiProbing && GetCurrentThreadId()==g_uiProbeTid){ DWORD c=ep->ExceptionRecord->ExceptionCode;
        if(c!=EXCEPTION_STACK_OVERFLOW && c!=(DWORD)EXCEPTION_GUARD_PAGE && (c & 0x80000000u))
            longjmp(g_uiJb,1); }
    return EXCEPTION_CONTINUE_SEARCH; }
/* addresses that faulted during validation -> never probe them again (persistent garbage that merely
   holds a vtable-looking value). This stops us from repeatedly calling into the same bad slot, which
   is what eventually hits an unrecoverable fault and takes the host down. */
static void* g_bad[1024]; static int g_nbad=0;
static int bad_known(void* a){ if(!a) return 0; for(int i=0;i<g_nbad;i++) if(g_bad[i]==a) return 1; return 0; }
static void bad_add(void* a){ if(a && g_nbad<1024 && !bad_known(a)) g_bad[g_nbad++]=a; }
static PVOID g_veh=NULL;
static int ptr_in_exec(void* a){ MEMORY_BASIC_INFORMATION mbi; if(!VirtualQuery(a,&mbi,sizeof mbi))return 0;
    if(mbi.State!=MEM_COMMIT)return 0; DWORD x=mbi.Protect&0xFF;
    return (x==PAGE_EXECUTE||x==PAGE_EXECUTE_READ||x==PAGE_EXECUTE_READWRITE||x==PAGE_EXECUTE_WRITECOPY); }

/* ---------------- caches ---------------- */
#define MAXI 48
/* VST2 */
static AEffect* g_v2[MAXI]; static const char* const* g_v2tbl[MAXI]; static uint32_t g_v2uid[MAXI]; static int g_v2np[MAXI]; static int g_nv2=0;
static int g_lastN2=-1, g_lastN3=-1;  /* for change-gated logging */
/* VST3 */
static IEditController* g_v3[MAXI]; static int g_nv3=0;
static void* g_curCand[MAXI]; static int g_ncur=0;      /* VST3 controllers validated THIS scan */
static void* g_prevCand[MAXI]; static int g_nprev=0;    /* ...and PREVIOUS scan (require 2 consecutive to cache) */
static int was_prev(void* c){ for(int i=0;i<g_nprev;i++) if(g_prevCand[i]==c) return 1; return 0; }
/* 8 was set when a machine was assumed to hold one Waves shell. A real one holds several: the
   user whose logs drove most of this work has 9.6, 10.0, 12.7, 13.0, 14.19, 16.7 and 17.1
   installed side by side, plus The T-Pain Effect as both .vst3 and .dll and Auto-Tune Pro --
   ten catch modules, two past the old ceiling. Running out was silent: the factory simply did not
   get hooked and that plug-in could never be captured. 32 costs ~15KB of static data in total
   across the four tables below. */
#define MAXVT 32
typedef struct { HMODULE mod; void* vt; void* self; int tries; DWORD seen; char path[MAX_PATH]; int catchMode; int antMod; int hooked; int pinned; } ATMod;   /* antMod: -1 unknown, 0 no, 1 yes */   /* one per Auto-Tune VST3 module; catchMode=factory-hook (电音11), never heap-scan */
    /* hooked: the factory's createInstance is CONFIRMED patched (verified against g_hookedVtbl, not
       merely attempted). Until it is, the catch-mode scan keeps retrying -- see scan_all(). 
       pinned: the module was already pinned, so we pin exactly once no matter how often we retry. */
static ATMod g_at[MAXVT]; static int g_nat=0;
static HMODULE g_checkedMod[2048]; static int g_nChecked=0;               /* every module AT-checked once (avoid re-reading version info) */
static int vt_known(void* v){ if(!v) return 0; for(int i=0;i<g_nat;i++) if(g_at[i].vt && g_at[i].vt==v) return 1; return 0; }
static int self_known(void* a){ if(!a) return 0; for(int i=0;i<g_nat;i++) if(g_at[i].self && g_at[i].self==a) return 1; return 0; }
static int mod_checked(HMODULE m){ for(int i=0;i<g_nChecked;i++) if(g_checkedMod[i]==m) return 1; return 0; }

typedef struct GUnkVtbl{tresult(WINAPI*queryInterface)(void*,const TUID,void**);uint32_t(WINAPI*addRef)(void*);uint32_t(WINAPI*release)(void*);}GUnkVtbl;
typedef struct GUnk{const GUnkVtbl*vtbl;}GUnk;

/* (single-module log gates removed; multi-module logs per module) */
/* true if the module file's version info names Antares / Auto-Tune (works even if renamed) */
/* fallback: scan the module FILE for Antares/Auto-Tune strings (handles plugins whose version
   info was stripped, e.g. renamed cracks). Chunked read + case-insensitive substring. */
static int buf_has(const char* hay,int n,const char* needle){ int m=(int)strlen(needle);
    for(int i=0;i+m<=n;i++){ int j=0; for(;j<m;j++){ char c=hay[i+j]; char lc=(c>='A'&&c<='Z')?(char)(c+32):c; if(lc != needle[j]) break; } if(j==m) return 1; } return 0; }
static int file_has_at(const char* path){
    HANDLE h=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_FLAG_SEQUENTIAL_SCAN,NULL);
    if(h==INVALID_HANDLE_VALUE) return 0;
    const int CH=1<<20, OV=16; const long long LIMIT=32LL<<20; long long tot=0;
    char* buf=(char*)malloc(CH+OV); int found=0;
    if(buf){ DWORD rd=0; int carry=0;
        while(tot<LIMIT && ReadFile(h,buf+carry,CH,&rd,NULL) && rd>0){ tot+=rd; int total=carry+(int)rd;
            if(buf_has(buf,total,"antares")||buf_has(buf,total,"auto-tune")||buf_has(buf,total,"autotune")){ found=1; break; }
            carry=(total>=OV)?OV:total; memmove(buf,buf+total-carry,carry);
        }
        free(buf);
    }
    CloseHandle(h); return found;
}
static int vinfo_is_at(const char* path){
    int result=0; DWORD dummy=0, sz=GetFileVersionInfoSizeA(path,&dummy);
    if(sz){ void* buf=malloc(sz);
        if(buf && GetFileVersionInfoA(path,0,sz,buf)){
            struct LC{ WORD l,c; } *tr=NULL; UINT tl=0;
            if(VerQueryValueA(buf,"\\VarFileInfo\\Translation",(void**)&tr,&tl)&&tr&&tl>=4){
                int nt=tl/4; const char* F[]={"CompanyName","ProductName","InternalName"};
                for(int t=0;t<nt&&!result;t++) for(int f=0;f<3&&!result;f++){
                    char sub[128]; snprintf(sub,sizeof sub,"\\StringFileInfo\\%04x%04x\\%s",tr[t].l,tr[t].c,F[f]);
                    char* v=NULL; UINT vl=0;
                    if(VerQueryValueA(buf,sub,(void**)&v,&vl)&&v){ char lo[256]; int i=0; for(;v[i]&&i<255;i++)lo[i]=(char)tolower((unsigned char)v[i]); lo[i]=0;
                        if(strstr(lo,"antares")||strstr(lo,"auto-tune")||strstr(lo,"autotune")) result=1; }
                }
            }
        }
        free(buf);
    }
    return result;
}
/* The one place that decides "this module is Antares". Three copies of this expression used to
   sit in scan_all(), mod_antares_idx() and (indirectly) the capture path. Worker thread only: it
   reads version info and may scan the file. */
/* Memoised BY PATH. The answer costs a version-info read plus a scan of up to 32MB of the file, and
   the callers dedupe by module HANDLE -- so the same file reloaded at a different base (what a host
   does on every plug-in rescan) would be read from disk again each time. Worker thread only, so a
   plain table needs no lock. The table is small; overflowing it just means no caching, never a
   wrong answer. */
static char g_antPath[MAXVT][MAX_PATH]; static int g_antVal[MAXVT]; static int g_nAnt=0;
static int path_is_antares(const char* path){
    if(!path||!path[0]) return 0;
    for(int i=0;i<g_nAnt;i++) if(!_stricmp(g_antPath[i],path)) return g_antVal[i];
    char low[MAX_PATH]; int k=0; for(;path[k] && k<MAX_PATH-1;k++) low[k]=(char)tolower((unsigned char)path[k]); low[k]=0;
    int v=(strstr(low,"auto-tune")||strstr(low,"autotune")||vinfo_is_at(path)||file_has_at(path)) ? 1 : 0;
    if(g_nAnt<MAXVT){ snprintf(g_antPath[g_nAnt],MAX_PATH,"%s",path); g_antVal[g_nAnt]=v; g_nAnt++; }
    return v; }

/* Two separate clearances, because they are two different questions with two different blast radii.

   EAT_CLEARED -- may this module's GetPluginFactory EXPORT be redirected?
     Rewrites one DWORD in the module's export directory, from inside the loader callback. Buys the
     user the thing that matters day to day: the hook is in place before the host creates its first
     instance, so no "remove and re-add" dance.

   VTBL_CLEARED -- may this plug-in's CONTROLLER VTABLE be patched?
     This is the one that kills PACE-protected plug-ins: patching any entry of 电音11's controller
     vtable crashes it, which is why the old getParamNormalized hook had to be removed. It is only
     needed by plug-ins whose processor and controller are separate objects and which therefore
     cannot reach the DSP without the host's IComponentHandler (Waves, The T-Pain Effect).

   Antares sits in the first list and NOT the second, and the real log is why: captured through the
   factory hook with no handler at all, its Key/Scale writes still moved the GUI and the audio. It
   does not need the vtable patch, so it does not get it. Lumping both decisions into one list would
   have handed a PACE-protected plug-in the exact treatment that crashes PACE-protected plug-ins.

   "auto-tune pro.vst3" carries the extension on purpose: as a substring it matches
   "Auto-Tune Pro.vst3" but not "Auto-Tune Pro 11.vst3", so a 电音11 installed under a longer name
   cannot slip in.

   "auto-tune.vst3" (电音9) joined in 1150. It had been left out because "it works fine on the heap-scan
   path and has no reason to be here" -- and both halves stopped being true: probing it took
   MonsterApplication down (1149), and since 1149 it is on the catch path, where the EAT hook is the
   one thing that catches the FIRST instance. Without it the worker hooks the factory ~100 ms after the
   module loads, the host has already built its first instance by then, and the user has to remove
   and re-add it every session (real log: Auto-Tune Pro caught at once via EAT; Auto-Tune 9 missed
   until re-added at +187 s). The evidence that its PACE tolerates the patch is from the same log:
   the worker rewrote its FACTORY VTABLE -- like the export directory, read-only data in the module --
   and it kept running and caught the re-added instance through that very patch. AT8.1
   ("Auto-Tune_81.vst3") has no such log yet and stays out until it does; "auto-tune.vst3" matches
   neither it nor "Auto-Tune Pro 11.vst3". */
static const char* const EAT_CLEARED[]  = { "waveshell", "t-pain", "auto-tune pro.vst3", "auto-tune.vst3", NULL };
static const char* const VTBL_CLEARED[] = { "waveshell", "t-pain", NULL };
/* Matched against the FILE NAME, never the whole path. A directory the user happens to have called
   "T-Pain Samples" or "waveshell-presets" would otherwise clear every plug-in inside it. Clearing a
   module must depend on which module it is, not on where it happens to sit. */
static int strstr_ci(const char* hay, const char* needle);   /* fwd (defined below) */
static int module_in(const char* path, const char* const* list){
    if(!path||!list) return 0;
    const char* leaf=path;
    for(const char* q=path;*q;q++) if(*q=='\\'||*q=='/') leaf=q+1;
    for(int i=0;list[i];i++) if(strstr_ci(leaf,list[i])) return 1;
    return 0; }
/* addresses of throwaway instances we created-and-freed to read a class vtable; the heap scan skips
   these freed blocks (belt-and-suspenders on top of validate + two-consecutive-sighting). */
static void* g_ignore[64]; static int g_nignore=0;
static int ignore_known(void* a){ if(!a) return 0; for(int i=0;i<g_nignore;i++) if(g_ignore[i]==a) return 1; return 0; }
/* Acquire a class vtable by briefly instantiating the factory's classes. ALL of this calls into the
   real plugin (countClasses/getClassInfo/createInstance/QI/release) and must be exception-guarded:
   doing it on a freshly-loaded, still-initialising PACE plugin from a background thread can fault,
   and an unguarded fault here takes the whole host down. */
/* GetPluginFactory() must be called at most ONCE per module, and the result reused. A second call
   makes WaveShell re-scan and APPEND to its own class list (140 -> 280 classes observed), after which
   the shell can no longer create instances at all. hook_factory already honoured that; get_v3_vtable
   did not -- it re-asked on every retry, up to 20 times for a module whose vtable never resolves. Both
   now go through here. */
static HMODULE g_gfMod[MAXVT]; static IPluginFactory* g_gfPtr[MAXVT]; static int g_nGf=0;
static IPluginFactory* factory_cached(HMODULE mod){   /* lookup only -- never calls the shell */
    IPluginFactory* r=NULL;
    if(g_hookCsInit) EnterCriticalSection(&g_hookCs);
    for(int i=0;i<g_nGf;i++) if(g_gfMod[i]==mod){ r=g_gfPtr[i]; break; }
    if(g_hookCsInit) LeaveCriticalSection(&g_hookCs);
    return r; }
/* Record a factory we did NOT have to ask for -- the EAT hook gets it out of the HOST's own
   GetPluginFactory() call. Caching it here is what guarantees the agent never adds a second call
   of its own (a second SUCCESSFUL call makes WaveShell append to its class list, 140 -> 280). */
static void factory_cache_put(HMODULE mod, IPluginFactory* f){
    if(!mod||!f) return;
    if(g_hookCsInit) EnterCriticalSection(&g_hookCs);
    int have=0; for(int i=0;i<g_nGf;i++) if(g_gfMod[i]==mod){ have=1; break; }
    if(!have && g_nGf<MAXVT){ g_gfMod[g_nGf]=mod; g_gfPtr[g_nGf]=f; g_nGf++; }
    if(g_hookCsInit) LeaveCriticalSection(&g_hookCs); }
static IPluginFactory* factory_once(HMODULE mod){
    { IPluginFactory* c=factory_cached(mod); if(c) return c; }
    typedef IPluginFactory*(WINAPI*GF)(void); GF gf=(GF)GetProcAddress(mod,"GetPluginFactory");
    if(!gf) return NULL;
    IPluginFactory* f=NULL; volatile LONG sv=g_probing; g_probing=1;
    if(setjmp(g_jb)==0) f=gf(); else f=NULL;
    g_probing=sv;
    /* the pointer is cached, so the module must not be allowed to unload underneath it */
    if(f){ HMODULE pinned=NULL; GetModuleHandleExA(0x1 /*PIN*/ | 0x4 /*FROM_ADDRESS*/, (LPCSTR)mod, &pinned); }
    /* ONLY a successful factory is cached. Caching a NULL used to make the failure PERMANENT: the
       module is pinned (so its HMODULE never changes), the cache hit returned that NULL forever, and
       hook_factory() bailed out silently on every later attempt -- no "createInstance HOOKED" line, so
       the host's instances were created through the UNhooked factory and could never be captured. The
       status list then showed "loaded, not captured" forever, and neither re-adding the plug-in nor
       restarting the controller could clear it (only a full DAW restart made a fresh process).
       Observed on WaveShell1-VST3 16.7_x64: catch-on-load asks for the factory the moment the shell is
       mapped, which is before the host has called InitDll() -- that shell hands out no factory yet.
       A call that returns NULL has not built the shell's class table, so it does NOT count towards the
       "GetPluginFactory() at most once" rule: only SUCCESSFUL calls append (140 -> 280). Retrying after
       a NULL is therefore safe, and the retry is what the catch-mode scan below relies on. */
    if(f) factory_cache_put(mod,f);
    return f; }
static void* get_v3_vtable(HMODULE mod, void** outSelf){ *outSelf=NULL;
    IPluginFactory* f=factory_once(mod); if(!f)return NULL;
    void* volatile vtret=NULL; volatile LONG saved=g_probing; g_probing=1;
    if(setjmp(g_jb)==0){
        int n=f->vtbl->countClasses(f);
        for(int i=0;i<n;i++){ PClassInfo ci; if(f->vtbl->getClassInfo(f,i,&ci)!=kResultOk)continue;
            const TUID* tries[3]={&IID_IComponent,&IID_IEditController,&IID_FUnknown};
            for(int t=0;t<3;t++){ void* obj=NULL;
                if(f->vtbl->createInstance(f,ci.cid,*tries[t],&obj)!=kResultOk||!obj) continue;
                GUnk* u=(GUnk*)obj; void* c=NULL;
                if(u->vtbl->queryInterface(u,IID_IEditController,&c)==kResultOk&&c){
                    void* vt=*(void**)c;
                    /* record + FULLY RELEASE the throwaway (keeping a live uninitialised instance of a
                       real plugin around can crash the host). vtable stays valid (static in module). */
                    if(g_nignore<64) g_ignore[g_nignore++]=c;
                    ((GUnk*)c)->vtbl->release(c);
                    u->vtbl->release(u);
                    vtret=vt; goto done;
                }
                u->vtbl->release(u); } }
        done:;
    } else vtret=NULL;   /* faulted somewhere in the factory calls -> give up on this module safely */
    g_probing=saved; return vtret; }

static int v2_known(AEffect* e){ for(int i=0;i<g_nv2;i++) if(g_v2[i]==e)return 1; return 0; }
static int v3_known(IEditController* c){ for(int i=0;i<g_nv3;i++) if(g_v3[i]==c)return 1; return 0; }

/* ================= 电音11 / PACE-hostile modules: factory-hook capture =================
   For modules that crash when their heap is scanned (real Auto-Tune 11), we DO NOT scan their
   heap and DO NOT instantiate throwaways. Instead we hook the plugin factory's createInstance:
   when the HOST creates the genuine IEditController, we capture that exact pointer and addRef it
   so it stays valid. setParamNormalized on the genuine controller is PACE-safe -- it's exactly what
   the host itself does. (The factory's methods are plain VST3-SDK glue: the log proves PACE already
   allows createInstance/QI/release on it, so patching its vtable entry is outside the protected code.) */
static char g_catchPat[8][64]; static int g_nCatchPat=0; static int g_catchLoaded=0;
/* Built-in catch patterns live in their OWN array, never in g_catchPat. They used to be appended
   into the user's 8-slot list, so a catch.txt with enough lines pushed them out -- and losing
   waveshell/t-pain/auto-tune pro there is not cosmetic: those plug-ins fall off the catch path,
   stop getting the EAT hook (so they need a remove-and-re-add), and Antares drops back to the
   probing path that has crashed and hung hosts. Kept separate, the user's list can never
   displace them, however long it is. */
/* "auto-tune" (1149) was "auto-tune pro.vst3". Only Auto-Tune Pro was on the safe path; every other
   Antares version -- Auto-Tune.vst3 (9), Auto-Tune_81.vst3 (8.1), ... -- was PROBED: the agent built an
   instance of it on its own thread and called methods on pointers that merely looked like instances.
   All Antares VST3s are PACE-protected, and README has long said probing PACE is itself the risk. It
   took MonsterApplication down: the breaker marker held Antares\Auto-Tune.vst3 at the moment of death,
   and Windows recorded 0xC000001D (illegal instruction) in memory belonging to no module -- PACE runs
   its decrypted code from such memory. The fault was on ANOTHER thread: one on the worker would have
   been caught by veh(). Matching the family name puts every version on the catch path from the moment
   it loads instead of after one crash each. EAT_CLEARED is deliberately NOT widened (only Pro is
   verified for the export patch), so these take the worker's late factory hook, as 电音11 always has. */
static const char* const g_catchBuiltin[] = { "11.vst3", "waveshell", "t-pain", "auto-tune", NULL };
static void load_catch_list(){
    g_catchLoaded=1; g_nCatchPat=0;
    FILE* f=fopen_retry(g_catchPath,"r");
    if(f){ char line[128]; int dropped=0, first=1;
        while(fgets(line,sizeof line,f)){ if(first){ first=0; drop_bom(line); } int n=(int)strlen(line);
            while(n>0&&(line[n-1]=='\n'||line[n-1]=='\r'||line[n-1]==' '||line[n-1]=='\t')) line[--n]=0;
            int i=0; while(line[i]==' '||line[i]=='\t') i++;
            if(!line[i] || line[i]=='#') continue;   /* 与其余配置文件一致:'#' 开头是注释 */
            if(g_nCatchPat>=8){ dropped++; continue; }
            int j2=0; for(;line[i]&&j2<63;i++) g_catchPat[g_nCatchPat][j2++]=(char)tolower((unsigned char)line[i]);
            g_catchPat[g_nCatchPat][j2]=0; g_nCatchPat++; }
        fclose(f);
        if(dropped>0) LOG("catch.txt: %d line(s) past the %d-line limit were ignored", dropped, 8);
    }
    /* Built-ins are NOT merged here; is_catch_path() consults g_catchBuiltin directly, so the user's
       list and the built-in list are independent and neither can crowd the other out. */
}
static int is_catch_path(const char* low){ if(!g_catchLoaded) load_catch_list();
    for(int i=0;g_catchBuiltin[i];i++) if(strstr(low,g_catchBuiltin[i])) return 1;   /* built-ins always apply */
    for(int i=0;i<g_nCatchPat;i++) if(g_catchPat[i][0] && strstr(low,g_catchPat[i])) return 1;
    return 0; }

static CRITICAL_SECTION g_catchCs; static int g_catchCsInit=0;
static void* g_caught[MAXI]; static int g_ncaught=0;
static int g_caughtRel[MAXI]; static int g_caughtStrike[MAXI];   /* -1 unknown, 0 counts unusable, 1 usable */
/* MUST be MAXVT, not a literal: this is indexed by g_nHooked alongside g_hookedVtbl/Orig/Ant.
   It sat at a hard-coded 8 while those used MAXVT, so raising MAXVT to 32 in 1130 turned a
   harmless "table full, plug-in not hooked" into an out-of-bounds write of 96 bytes per entry
   straight into g_modMap below -- and the trigger was exactly the case that raise was meant to
   support, several Waves shell versions installed side by side. */
static char g_hookedLeaf[MAXVT][96];              /* module filename per hooked factory vtbl (indexed as g_hookedVtbl) */
static struct { void* c; char leaf[96]; } g_modMap[64]; static int g_nModMap=0;   /* controller -> real plugin module filename */
/* g_caught + g_modMap are written on the HOST thread (myCreateInstance) and read/written on the WORKER
   thread (scan_region/write_status). All three accessors take g_catchCs so the two threads never race.
   g_catchCs is recursive (Windows CS), so calling these while already holding it (myCreateInstance) is fine.
   Lock order is always g_cs -> g_catchCs on the worker; the host takes only g_catchCs -> no deadlock. */
static void modmap_set(void* c, const char* leaf){ if(!c||!leaf||!leaf[0]) return;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    int done=0; for(int i=0;i<g_nModMap;i++) if(g_modMap[i].c==c){ snprintf(g_modMap[i].leaf,96,"%s",leaf); done=1; break; }
    if(!done && g_nModMap<64){ g_modMap[g_nModMap].c=c; snprintf(g_modMap[g_nModMap].leaf,96,"%s",leaf); g_nModMap++; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); }
static int modmap_get(void* c, char* out, int outsz){ out[0]=0; int found=0;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_nModMap;i++) if(g_modMap[i].c==c && g_modMap[i].leaf[0]){ snprintf(out,outsz,"%s",g_modMap[i].leaf); found=1; break; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); return found; }
/* ---- lifetime of captured controllers ----
   We hold our own reference on every controller we capture, which is what keeps it usable. Nothing
   ever gave that reference back: once the user removed a plug-in from the rack the host released
   its references, ours kept the object alive, and the scan merged it into the live set again every
   round -- a ghost instance that stayed in the status list and the Target menu, still constrained
   the "all plug-ins" scale intersection, and still received writes.
   VST3 specifies addRef/release as returning the NEW reference count, so addRef+release reports the
   current count without changing it. While the plug-in is loaded the host holds at least one
   reference besides ours, so the probe reads >= 3; once only our reference is left it reads 2.
   Probing happens on the worker thread only -- the crash guard does not protect host threads. */
static void modmap_del(void* c){ if(!c) return;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_nModMap;i++) if(g_modMap[i].c==c){ for(int k=i;k<g_nModMap-1;k++) g_modMap[k]=g_modMap[k+1]; g_nModMap--; break; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); }
static int caught_known(void* c){ int r=0;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_ncaught;i++) if(g_caught[i]==c){ r=1; break; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); return r; }

typedef tresult (WINAPI *tCreate)(void*, const TUID, const TUID, void**);
static void* g_hookedVtbl[MAXVT]; static tCreate g_hookedOrig[MAXVT]; static int g_nHooked=0;
/* Per factory: may the controller vtable behind it be patched? 0 = yes, this module is on the
   cleared list; 1 = no, treat as PACE-protected; -1 = no entry, so not established.
   This has to travel WITH the hook entry. The obvious alternative -- asking at capture time, on the
   host thread -- is wrong three times over: the test arms g_jb, which the VEH only honours on the
   worker thread (so it both loses the worker's recovery point and gives itself no protection); it
   reads g_at while the worker may be appending to it; and g_at often has no entry yet, because a
   capture can precede module registration (real log: "CAUGHT genuine controller" three lines ahead
   of "vst3 Auto-Tune module found"). An empty g_at answers "not Antares", which on 电音11 would mean
   patching the very vtable PACE protects. Resolved on the worker, where the path is known. */
static int g_hookedAnt[MAXVT];
/* ---- component initialize() hook ----
   A Waves component answers QI(IEditController) only AFTER the host has initialised it; at the instant
   createInstance returns, the controller side is not wired up yet. Rather than poll the object from our
   worker thread (a cross-thread call into a half-built instance), we patch initialize() in the object's
   vtable -- a DATA table, same technique as the factory hook -- and ask for the controller on the HOST
   thread the moment the host's own initialize() returns. That is exactly when a host would ask, so the
   timing is correct and no reference is held on an uninitialised object. */
typedef tresult (WINAPI *tInit)(void*, void*);
#define MAXIH 32   /* see MAXVT */
static void* g_ihVtbl[MAXIH]; static tInit g_ihOrig[MAXIH]; static char g_ihLeaf[MAXIH][96]; static int g_nIH=0;
/* "this controller came out of the Waves shell" is recorded EXPLICITLY at capture time. It must never
   be re-derived from the display name: the displayed name is the product name ("Waves Tune Real-Time
   Mono"), and a check for "waveshell" against it silently reports not-Waves, which sends the plug-in
   down the Auto-Tune path and makes the blind id1/id2 fallback write to unrelated parameters. */
/* ---- the host's IComponentHandler ----
   IEditController::setParamNormalized() only updates the CONTROLLER's own copy of a value. The audio
   is produced by the component, and in VST3 it is the HOST that carries a parameter change from the
   controller to the processor. That is why a plug-in's own GUI never just calls setParamNormalized:
   it calls beginEdit / performEdit / endEdit on the host's IComponentHandler, and the host then
   updates automation, the processor and the controller together. Writing only to the controller is
   exactly what produces "the read-back shows the new value but the plug-in does not react".
   So we capture the handler the host hands to the controller (vtable slot 16) and drive edits through
   it, which is precisely what the plug-in's own interface does. */
typedef tresult (WINAPI *tSetCH)(void*, void*);
#define MAXCH 32   /* see MAXVT */
static void* g_chVtbl[MAXCH]; static tSetCH g_chOrig[MAXCH]; static int g_nCH=0;
static void* g_chCtrl[MAXI]; static void* g_chHandler[MAXI]; static int g_nChMap=0;
static DWORD g_chTid[MAXI];
static volatile LONG g_inHook=0,g_handlerUiHookDepth=0,g_handlerWorkerHookDepth=0;
/* A binding owns one FUnknown reference. Map/transaction references to this
   wrapper are internal atomics, so acquiring a transaction never calls foreign
   AddRef while g_catchCs is held or touches a possibly stale raw handler hint. */
struct CHBinding {void* handler;volatile LONG refs;DWORD ownerTid,captureTid;uint64_t captureEpoch;CHBinding* pendingNext;};
static CHBinding* g_chBinding[MAXI];static uint64_t g_chEpoch[MAXI],g_chEpochCounter=0;
static DWORD g_chPauseTid[MAXI];static CHBinding* g_chPending=NULL;static CHBinding* g_chRetired=NULL;
static CHBinding* volatile g_handlerHeld=NULL; /* UI/worker execution guard admits one transaction */
static volatile DWORD g_handlerHeldTid=0;
static uint64_t handler_next_epoch(){if(++g_chEpochCounter==0)++g_chEpochCounter;return g_chEpochCounter;}
struct HandlerGuardMark {uint64_t epoch;LONG uiDepth,workerDepth;};
static HandlerGuardMark handler_guard_mark(){
    HandlerGuardMark mark;if(g_catchCsInit)EnterCriticalSection(&g_catchCs);mark.epoch=g_chEpochCounter;
    if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);
    mark.uiDepth=InterlockedCompareExchange(&g_handlerUiHookDepth,0,0);mark.workerDepth=InterlockedCompareExchange(&g_handlerWorkerHookDepth,0,0);return mark;
}
static void handler_pending_remove_locked(CHBinding* binding){
    CHBinding** link=&g_chPending;while(*link&&*link!=binding)link=&(*link)->pendingNext;
    if(*link==binding)*link=binding->pendingNext;binding->pendingNext=NULL;binding->captureTid=0;
}
static void handler_binding_release(CHBinding* binding){
    if(!binding||InterlockedDecrement(&binding->refs)!=0)return;
    /* drop_dead_instances may own an outer recursive g_catchCs. Retirement
       therefore never calls foreign Release, even after its own unlock. */
    if(g_catchCsInit)EnterCriticalSection(&g_catchCs);
    binding->pendingNext=g_chRetired;g_chRetired=binding;
    if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);
}
static void handler_retired_drain(){
    for(unsigned budget=0;budget<MAXI*2;budget++){
        if(g_catchCsInit)EnterCriticalSection(&g_catchCs);
        CHBinding* binding=g_chRetired;if(binding)g_chRetired=binding->pendingNext;
        if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);if(!binding)break;
        void* handler=binding->handler;HeapFree(GetProcessHeap(),0,binding);
        if(handler)((GUnk*)handler)->vtbl->release(handler); /* ownership already cleared before reentry/fault */
    }
}
static CHBinding* handler_binding_new(void* handler){
    if(!handler)return NULL;
    CHBinding* binding=(CHBinding*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof *binding);if(!binding)return NULL;
    binding->refs=1;binding->ownerTid=binding->captureTid=GetCurrentThreadId();
    if(g_catchCsInit)EnterCriticalSection(&g_catchCs);
    binding->captureEpoch=handler_next_epoch();
    binding->pendingNext=g_chPending;g_chPending=binding;
    if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);
    ((GUnk*)handler)->vtbl->addRef(handler); /* input is owned by setComponentHandler's caller */
    binding->handler=handler;return binding;
}
static uint64_t handler_map_pause(void* controller){
    uint64_t epoch=0;if(g_catchCsInit)EnterCriticalSection(&g_catchCs);
    int i=0;while(i<g_nChMap&&g_chCtrl[i]!=controller)i++;
    if(i==g_nChMap&&g_nChMap<MAXI){g_chCtrl[i]=controller;g_chBinding[i]=NULL;g_nChMap++;}
    if(i<g_nChMap){g_chHandler[i]=NULL;g_chTid[i]=0;g_chPauseTid[i]=GetCurrentThreadId();g_chEpoch[i]=epoch=handler_next_epoch();}
    if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);return epoch;
}
static void handler_map_commit(void* controller,uint64_t epoch,CHBinding* fresh){
    CHBinding* old=NULL;if(g_catchCsInit)EnterCriticalSection(&g_catchCs);
    if(fresh)handler_pending_remove_locked(fresh);
    for(int i=0;i<g_nChMap;i++)if(g_chCtrl[i]==controller&&g_chEpoch[i]==epoch){
        old=g_chBinding[i];g_chBinding[i]=fresh;g_chHandler[i]=fresh?fresh->handler:NULL;
        g_chTid[i]=fresh?GetCurrentThreadId():0;g_chPauseTid[i]=0;fresh=NULL;break;
    }
    if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);
    handler_binding_release(old);handler_binding_release(fresh);
}
static CHBinding* handler_binding_acquire(void* controller){
    CHBinding* binding=NULL;if(g_catchCsInit)EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_nChMap;i++)if(g_chCtrl[i]==controller){
        if(!g_chPauseTid[i]&&g_chBinding[i]&&g_chHandler[i]){binding=g_chBinding[i];InterlockedIncrement(&binding->refs);}break;
    }
    if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);return binding;
}
static int handler_binding_current(void* controller,CHBinding* binding){
    int current=0;if(g_catchCsInit)EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_nChMap;i++)if(g_chCtrl[i]==controller){current=!g_chPauseTid[i]&&g_chBinding[i]==binding&&g_chHandler[i]!=NULL;break;}
    if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);return current;
}
/* Called while the UI/worker fault guard is still active. Clear ownership
   before foreign Release: if it faults/reenters, a repeated cleanup progresses
   without releasing the same reference again. Paused maps/pending captures are
   reachable even when an original setter longjmps over its normal return. */
static void handler_transaction_cleanup(HandlerGuardMark mark){
    DWORD tid=GetCurrentThreadId();
    /* Only a fault can skip wrappers entered after this guard. An ordinary
       outer setter may still be live while it pumps a nested UI guard. */
    if(g_uiProbing&&tid==g_uiProbeTid){LONG depth=InterlockedExchange(&g_handlerUiHookDepth,mark.uiDepth);if(depth>mark.uiDepth)InterlockedExchangeAdd(&g_inHook,mark.uiDepth-depth);}
    if(g_probing&&tid==g_workerTid){LONG depth=InterlockedExchange(&g_handlerWorkerHookDepth,mark.workerDepth);if(depth>mark.workerDepth)InterlockedExchangeAdd(&g_inHook,mark.workerDepth-depth);}
    if(g_handlerHeldTid==tid){CHBinding* held=g_handlerHeld;g_handlerHeld=NULL;g_handlerHeldTid=0;handler_binding_release(held);}
    for(;;){CHBinding* retired=NULL;int found=0;if(g_catchCsInit)EnterCriticalSection(&g_catchCs);
        for(int i=0;i<g_nChMap;i++)if(g_chPauseTid[i]==tid&&g_chEpoch[i]>mark.epoch){retired=g_chBinding[i];g_chBinding[i]=NULL;g_chHandler[i]=NULL;g_chTid[i]=0;g_chPauseTid[i]=0;g_chEpoch[i]=handler_next_epoch();found=1;break;}
        if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);if(!found)break;handler_binding_release(retired);
    }
    for(;;){CHBinding* pending=NULL;if(g_catchCsInit)EnterCriticalSection(&g_catchCs);
        for(CHBinding* item=g_chPending;item;item=item->pendingNext)if(item->captureTid==tid&&item->captureEpoch>mark.epoch){pending=item;handler_pending_remove_locked(item);break;}
        if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);if(!pending)break;handler_binding_release(pending);
    }
    handler_retired_drain();
}
/* Only the main worker loop, outside g_cs/g_catchCs and outside a writer's
   recovery frame, drains refs left by ordinary host clear/drop callbacks. */
static void handler_worker_drain(){
    /* This one call site is the worker's base loop: all earlier worker probe
       frames have returned, including legacy VST2/QI recovery paths. Their
       leftover records are orphaned, unlike a live outer host setter pumping
       a nested UI callback. Other threads' records/held refs remain untouched. */
    HandlerGuardMark mark={0,0,0};
    volatile LONG saved=g_probing;g_probing=1;
    if(setjmp(g_jb)==0)handler_retired_drain();
    handler_transaction_cleanup(mark); /* includes a setter reentered by a foreign Release */
    g_probing=saved;
}
/* The thread the host was on when it installed the handler. Hosts call setComponentHandler during
   plug-in setup on their UI thread, and VST3 requires beginEdit/performEdit/endEdit to come from
   that same thread -- Studio One silently discards them otherwise (verified: writes from the worker
   changed nothing at all, the identical writes posted to this thread moved the plug-in). */
static void* g_wavesCtrl[MAXI]; static int g_nWavesCtrl=0;
static void waves_mark(void* c){ if(!c) return;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    int dup=0; for(int i=0;i<g_nWavesCtrl;i++) if(g_wavesCtrl[i]==c){ dup=1; break; }
    if(!dup && g_nWavesCtrl<MAXI) g_wavesCtrl[g_nWavesCtrl++]=c;
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); }
static int waves_known(void* c){ int r=0; if(!c) return 0;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_nWavesCtrl;i++) if(g_wavesCtrl[i]==c){ r=1; break; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); return r; }
static void waves_del(void* c){ if(!c) return;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_nWavesCtrl;i++) if(g_wavesCtrl[i]==c){ for(int k=i;k<g_nWavesCtrl-1;k++) g_wavesCtrl[k]=g_wavesCtrl[k+1]; g_nWavesCtrl--; break; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); }
static void chmap_del(void* c){ if(!c) return;
    CHBinding* retired=NULL;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_nChMap;i++) if(g_chCtrl[i]==c){retired=g_chBinding[i];for(int k=i;k<g_nChMap-1;k++){g_chCtrl[k]=g_chCtrl[k+1];g_chHandler[k]=g_chHandler[k+1];g_chTid[k]=g_chTid[k+1];g_chBinding[k]=g_chBinding[k+1];g_chPauseTid[k]=g_chPauseTid[k+1];g_chEpoch[k]=g_chEpoch[k+1];}g_nChMap--;g_chCtrl[g_nChMap]=g_chHandler[g_nChMap]=NULL;g_chBinding[g_nChMap]=NULL;g_chTid[g_nChMap]=g_chPauseTid[g_nChMap]=0;g_chEpoch[g_nChMap]=0;break;}
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs);
    handler_binding_release(retired); }
static void* handler_of(void* c){ void* h=NULL; if(!c) return NULL;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_nChMap;i++) if(g_chCtrl[i]==c){ h=g_chHandler[i]; break; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); return h; }
/* The host thread that installed this controller's handler, or 0 if we never saw one. */
static DWORD uitid_of(void* c){ DWORD t=0; if(!c) return 0;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_nChMap;i++) if(g_chCtrl[i]==c){ t=g_chTid[i]; break; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs);
    return t; }
/* ---- in-flight hook calls ------------------------------------------------------------------
   The three hooks below run on HOST threads, where the vectored handler does NOT recover faults --
   it only rescues the worker. That makes unloading delicate: unpatching a vtable stops NEW calls,
   but a host thread already executing inside one of our hooks (or one that has just read the
   pointer and is about to call it) still has our code mapped under it. Freeing the DLL at that
   moment takes the whole DAW down, and ejecting is something the user does routinely.
   The image is therefore PINNED until the rack exits. Counters describe in-flight work; zero is NOT proof that a callback has returned past its final DLL instruction. */
/* Set the moment an eject starts, BEFORE any hook is removed. Every function that INSTALLS a patch
   into a plug-in's vtable checks it and does nothing.
   Removing the hooks only stops new calls from ENTERING them; a host thread that was already inside
   one can still run on and install a fresh patch after remove_*_hooks() has finished. That patch
   points into this DLL, which is unmapped moments later -- the host then crashes on its next
   createInstance/initialize/setComponentHandler. The drain at the end of eject does not help: it
   waits for those threads to leave, but by then the pointer is already written. */
static volatile LONG g_ejecting=0;
/* A pause keeps discovery/hooks/authorization alive, but invalidates both
   unread mailbox parameters and already posted host-UI parameter requests. */
static volatile LONG g_parameterPaused=AT_XHH_MANAGED?1:0,g_parameterEpoch=1;
static int agent_parameter_ready(LONG epoch=0){
    return !InterlockedCompareExchange(&g_parameterPaused,0,0)&&(!epoch||epoch==InterlockedCompareExchange(&g_parameterEpoch,0,0));
}
static void agent_cancel_posted_writes();
#if AT_XHH_MANAGED
static int agent_pause_status(char* out,unsigned capacity);
#endif
#if AT_XHH_MANAGED
static int agent_policy_ui_allowed(const void* address,const char* family);
static int agent_policy_host(const ATCS_Claims* lease);
static int agent_policy_module(HMODULE module,const char* family=NULL);
static int agent_policy_address(const void* address,const char* family=NULL);
#else
static int agent_policy_module(HMODULE,const char* =NULL){return 1;}
static int agent_policy_address(const void*,const char* =NULL){return 1;}
#endif
/* Recheck immediately before each new parameter transaction. The caller may
   have waited on a host UI thread or a previous plug-in parameter since the
   command's initial authorization check. An already-started VST3 edit remains
   paired through endEdit; it cannot be rolled back by a later expiry. */
static int agent_write_allowed(const void* address,const char* family){
    if(g_ejecting||!agent_parameter_ready())return 0;
#if AT_XHH_MANAGED
    return agent_policy_ui_allowed(address,family);
#else
    (void)address;(void)family;return 1;
#endif
}
/* Owner-thread subclass installation may be delayed independently of the
   worker. Recheck current public lease/parent/host at both ends of that delay. */
static int agent_ui_install_allowed(){
    if(g_ejecting)return 0;
#if AT_XHH_MANAGED
    ATCS_LoaderRead read;
    return read.snapshot&&atcs_now()<read.snapshot->policy.expires
        &&atcs_pid_alive(read.snapshot->policy.parent)&&agent_policy_host(&read.snapshot->policy);
#else
    return 1;
#endif
}
static int g_suspended=0; /* worker-owned; PIN keeps all callback return tails mapped */
static tresult WINAPI mySetComponentHandler_inner(void* self, void* handler){
    void* vt=*(void**)self; tSetCH orig=NULL;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_nCH;i++) if(g_chVtbl[i]==vt){ orig=g_chOrig[i]; break; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs);
    if(!orig){ LOG("setComponentHandler hook: no original recorded for vtable %p -- cannot forward",vt); return kInvalidArgument; }
    uint64_t epoch=handler_map_pause(self); /* no new transaction may use the transitioning binding */
    tresult r=orig(self,handler);                    /* old map-owned reference survives its release */
    CHBinding* fresh=(r==kResultOk&&handler&&epoch)?handler_binding_new(handler):NULL;
    handler_map_commit(self,epoch,fresh); /* an intervening/reentrant setter keeps its newer epoch */
    DWORD callerTid=GetCurrentThreadId();
    void* current=handler_of(self);
    if(handler&&current==handler) LOG("captured host IComponentHandler %p for controller %p on host thread %lu -- edits will now go through the host",
                    handler,self,(unsigned long)callerTid);
    else if(!current) LOG("host CLEARED the IComponentHandler on controller %p -- dependent edit transactions are skipped until a new handler arrives",self);
    else LOG("host handler changed again during the setter callback on controller %p -- the newer binding was retained",self);
    return r;
}
static tresult WINAPI mySetComponentHandler(void* self, void* handler){   /* counts the call, then does the work */
    DWORD tid=GetCurrentThreadId();volatile LONG* depth=NULL;
    if(g_uiProbing&&tid==g_uiProbeTid)depth=&g_handlerUiHookDepth;
    else if(g_probing&&tid==g_workerTid)depth=&g_handlerWorkerHookDepth;
    if(depth)InterlockedIncrement(depth);
    InterlockedIncrement(&g_inHook);
    tresult r_ = mySetComponentHandler_inner(self,handler);
    InterlockedDecrement(&g_inHook);
    if(depth)InterlockedDecrement(depth);
    return r_; }

/* patch setComponentHandler (IEditController slot 16) on a CONTROLLER vtable. Only ever called for a
   pointer that answered QI(IEditController), so slot 16 really is setComponentHandler; as a belt-and-
   braces check we refuse any vtable already known as a component vtable. */
static void hook_setcomponenthandler(void* ctrl){
    if(g_ejecting) return;            /* never install a patch that would outlive this DLL */
    if(!ctrl) return; void** vt=*(void***)ctrl; if(!vt) return;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    if(g_ejecting){if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);return;} /* safe stop may have completed while this callback waited for the lock */
    { int bad=0;
      for(int i=0;i<g_nIH;i++) if(g_ihVtbl[i]==(void*)vt){ LOG("setComponentHandler: vtable %p is a component vtable -> not patching",(void*)vt); bad=1; break; }
      if(!bad) for(int i=0;i<g_nCH;i++) if(g_chVtbl[i]==(void*)vt){ bad=1; break; }
      if(bad || g_nCH>=MAXCH){ if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); return; } }
    DWORD op;
    if(VirtualProtect(&vt[16],sizeof(void*),PAGE_EXECUTE_READWRITE,&op)){
        g_chVtbl[g_nCH]=(void*)vt; g_chOrig[g_nCH]=(tSetCH)vt[16]; g_nCH++;
        __atomic_signal_fence(__ATOMIC_SEQ_CST);
        vt[16]=(void*)mySetComponentHandler;
        VirtualProtect(&vt[16],sizeof(void*),op,&op);
        LOG("setComponentHandler() hooked on controller vtable %p",(void*)vt); }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); }

static tresult WINAPI myInitialize(void* self, void* context);   /* fwd */
/* restore every patched initialize() BEFORE the agent unloads, or the vtable keeps pointing into the
   freed DLL -> host crash on the next instance. Same contract as remove_factory_hooks(). */
static void remove_init_hooks(){
    for(int i=0;i<g_nIH;i++){ void** vt=(void**)g_ihVtbl[i]; if(!vt) continue; DWORD op;
        if(VirtualProtect(&vt[3],sizeof(void*),PAGE_EXECUTE_READWRITE,&op)){
            if(vt[3]==(void*)myInitialize) vt[3]=(void*)g_ihOrig[i];
            VirtualProtect(&vt[3],sizeof(void*),op,&op); } }
    /* Keep original dispatch records: a host may have read our pointer before restoration. */ }
/* patch initialize() (IPluginBase slot 3) on this object's vtable; dedups by vtable address */
static int g_ihWaves[MAXIH]; static char g_ihShell[MAXIH][96];
/* ---- per-INSTANCE product name ----
   The initialize() hook is keyed by the component VTABLE, and the name was stored there too. But
   Waves builds "Waves Tune Real-Time Mono" and "... Stereo" from ONE C++ class, so both share a
   single component vtable: the second class to be created hits the dup check in
   hook_component_initialize(), the vtable keeps whichever name arrived first, and every later
   instance is captured under that name. Observed on 17.1: a Stereo instance whose createInstance
   line correctly said Stereo was then logged -- and listed -- as Mono.
   The class id, however, IS per class, so the name is recorded against the OBJECT here at
   createInstance time and looked up again when the controller is captured. */
#define MAXIN 64
static void* g_inObj[MAXIN]; static char g_inName[MAXIN][96]; static int g_nIn=0;
static void inst_name_set(void* obj, const char* name){
    if(!obj||!name||!name[0]) return;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    int f=-1; for(int i=0;i<g_nIn;i++) if(g_inObj[i]==obj){ f=i; break; }
    if(f<0 && g_nIn<MAXIN) f=g_nIn++;
    else if(f<0){ for(int i=0;i+1<MAXIN;i++){ g_inObj[i]=g_inObj[i+1]; memcpy(g_inName[i],g_inName[i+1],96); } f=MAXIN-1; }   /* oldest out */
    g_inObj[f]=obj; snprintf(g_inName[f],96,"%s",name);
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); }
/* (the matching lookup is inlined in myInitialize_inner, which already holds g_catchCs) */
/* shells from which at least one controller was actually captured -- used so the status list stops
   saying "loaded, not captured" once an instance from that shell IS under control. The old check
   compared the displayed name against the shell filename, which stopped matching as soon as the
   display name became the product name ("Waves Tune Real-Time Mono"). */
static char g_capShell[8][96]; static int g_nCapShell=0;
static void capshell_mark(const char* sh){ if(!sh||!sh[0]) return;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    int dup=0; for(int i=0;i<g_nCapShell;i++) if(!_stricmp(g_capShell[i],sh)){ dup=1; break; }
    if(!dup && g_nCapShell<8){ snprintf(g_capShell[g_nCapShell],96,"%s",sh); g_nCapShell++; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); }
static int capshell_known(const char* sh){ int r=0; if(!sh||!sh[0]) return 0;
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_nCapShell;i++) if(!_stricmp(g_capShell[i],sh)){ r=1; break; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); return r; }
static void hook_component_initialize(void* obj, const char* leaf, int isWaves, const char* shellLeaf){
    if(g_ejecting) return;            /* never install a patch that would outlive this DLL */
    if(!obj) return; void** vt=*(void***)obj; if(!vt) return;
    /* runs on a HOST thread and a host may create plug-ins on several threads at once; without this
       two installs can claim the same slot, losing one original and leaving a vtable patched with no
       way back -- the instance would then fail to initialise. */
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    if(g_ejecting){if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);return;} /* safe stop may have completed while this callback waited for the lock */
    { int dup=0; for(int i=0;i<g_nIH;i++) if(g_ihVtbl[i]==(void*)vt){ dup=1; break; }
      if(dup || g_nIH>=MAXIH){ if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); return; } }
    DWORD op;
    if(VirtualProtect(&vt[3],sizeof(void*),PAGE_EXECUTE_READWRITE,&op)){
        g_ihVtbl[g_nIH]=(void*)vt; g_ihOrig[g_nIH]=(tInit)vt[3]; g_ihWaves[g_nIH]=isWaves;
        snprintf(g_ihShell[g_nIH],96,"%s", (shellLeaf&&shellLeaf[0])?shellLeaf:"");
        snprintf(g_ihLeaf[g_nIH],96,"%s", (leaf&&leaf[0])?leaf:"plugin");
        g_nIH++;                                   /* publish before patching */
        __atomic_signal_fence(__ATOMIC_SEQ_CST);
        vt[3]=(void*)myInitialize;
        VirtualProtect(&vt[3],sizeof(void*),op,&op);
        LOG("initialize() hooked on component vtable %p [%s] -> will capture the controller after init",(void*)vt,leaf?leaf:"?"); }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); }
/* ---- factory class table: resolves a CID seen in createInstance to the plug-in's real NAME ----
   A shell (WaveShell) hosts hundreds of classes, so without this the log only shows an opaque pointer.
   countClasses/getClassInfo are plain VST3-SDK glue on the factory object (the same calls the host
   itself makes while scanning), so enumerating once per factory is safe; it is still setjmp-guarded. */
static int strstr_ci(const char* hay, const char* needle);   /* fwd (defined below) */
static void tuid_hex(const TUID u, char* out, int outsz){ static const char* H="0123456789ABCDEF";
    int j=0; for(int i=0;i<16 && j+2<outsz;i++){ out[j++]=H[(u[i]>>4)&0xF]; out[j++]=H[u[i]&0xF]; } out[j]=0; }
/* Identifying the plug-in from the class id alone is what REPLACES enumerating the factory,
   and the factory must NOT be enumerated: calling GetPluginFactory()/countClasses() a second
   time makes WaveShell re-scan and APPEND to its class list (observed 140 -> 280 classes),
   after which the shell can no longer create instances at all. */
/* Decode a Waves VST3 class id. Verified against six real class ids read off a live WaveShell
   (Waves Tune Real-Time Mono/Stereo, Waves Tune Mono/Stereo, SoundShifter Pitch Mono/Stereo):

       byte  0     product variant   'L' = real-time/live, 'T' = standard
       bytes 1-3   "TSV"             constant ("VST" reversed)
       bytes 4-6   three-letter product code   LVw / GNw / RSs
       byte  7     channel           'M' = Mono, 'S' = Stereo
       bytes 8-15  characters 1..8 of the plug-in NAME (character 0 is displaced by the channel code)
                   'Waves tune'   -> "aves tun"
                   'Soundshifter' -> "oundshif"

   The PRODUCT CODE is what identifies the plug-in, not the name tail: Waves V9.6 ships Waves Tune,
   Waves Tune LT and Waves Tune Real-Time, and all three truncate to the same "aves tun" tail, so a
   tail-keyed table would label different products identically. An unknown code therefore prints the
   code alongside the tail, which keeps every product distinguishable in the Target list.

   Matching the STRUCTURE rather than a hardcoded string is what makes this work across shell
   versions (9.6, 9.7, 11.0 ...): WaveShell builds its class list by scanning the disk at run time,
   so these ids exist only on a live instance and never inside the shell file.
   Whether a plug-in is a TUNER is decided by its parameters (Scale Root + Scale Type), never by the
   class id, so an unrecognised id costs nothing but a prettier label. */
static int cid_is_waves(const TUID cid, char* out, int outsz){
    const unsigned char* b=(const unsigned char*)cid;
    if(b[1]!='T' || b[2]!='S' || b[3]!='V') return 0;          /* not a Waves VST3 class id */
    if(b[7]!='M' && b[7]!='S') return 0;                        /* no channel marker */
    for(int i=4;i<16;i++) if(b[i]<32 || b[i]>126) return 0;     /* code + name tail must be printable */
    char code[4]; memcpy(code,b+4,3); code[3]=0;
    char tail[9]; memcpy(tail,b+8,8); tail[8]=0;
    const char* ch = (b[7]=='M') ? "Mono" : "Stereo";
    static const struct { const char* code; const char* name; } KNOWN[] = {
        { "LVw", "Waves Tune Real-Time" },
        { "GNw", "Waves Tune" },
        { "RSs", "SoundShifter Pitch" },
        { NULL, NULL } };
    const char* prod=NULL;
    for(int i=0;KNOWN[i].code;i++) if(!strcmp(code,KNOWN[i].code)){ prod=KNOWN[i].name; break; }
    if(out && outsz>0){
        if(prod) snprintf(out,outsz,"%s %s",prod,ch);
        else     snprintf(out,outsz,"Waves ?%s [%s] %s",tail,code,ch);   /* unknown: stays unique */
    }
    return 1;
}


/* Thread id of the worker while IT is instantiating a throwaway, so the hooks ignore only OUR own
   creations. This used to be a plain on/off flag, which is shared by every thread: a plug-in the
   HOST created during that window was taken for one of ours and silently skipped, so the user saw
   an instance that never became controllable until it was re-added. Comparing thread ids costs the
   same and scopes the suppression to the thread that actually asked for it. */
static volatile LONG g_selfCreateTid=0;
#define IN_SELF_CREATE() (g_selfCreateTid==(LONG)GetCurrentThreadId())

/* shared inline-patch primitives (used by both the GetPluginFactory hook and the LoadLibraryExW hook) */

static tresult WINAPI myCreateInstance_inner(void* factory, const TUID cid, const TUID iid, void** obj){
    IPluginFactoryVtbl* vt=(IPluginFactoryVtbl*)((IPluginFactory*)factory)->vtbl;
    tCreate orig=NULL; for(int i=0;i<g_nHooked;i++) if(g_hookedVtbl[i]==(void*)vt){ orig=g_hookedOrig[i]; break; }
    if(!orig) return kInvalidArgument;                 /* never happens: orig is recorded before patching */
    int wantEC=tuid_eq(iid,IID_IEditController);
    tresult r=orig(factory,cid,iid,obj);
    if(IN_SELF_CREATE() || g_ejecting) return r;                      /* ignore our own throwaway instantiations */
    log_arm();
    char wname[80]=""; int isWT=cid_is_waves(cid,wname,sizeof wname);
    /* Is this factory the Waves shell? Marking a controller as "Waves" must depend on WHERE it came
       from, never on it merely arriving through the factory hook: 电音11 also reaches this hook (it
       asks for IEditController directly), and marking it Waves made the Waves parameter matchers run
       against Auto-Tune's 182 parameters, where they grabbed 'Vibrato Shape' and 'HP Transition Time'
       and the feel sliders then wrote to them. */
    const char* fleaf=NULL; int fant=-1; { void* fvt=(void*)((IPluginFactory*)factory)->vtbl;
        for(int i=0;i<g_nHooked;i++) if(g_hookedVtbl[i]==fvt){ fleaf=g_hookedLeaf[i]; fant=g_hookedAnt[i]; break; } }
    int isWavesFactory = isWT || (fleaf && strstr_ci(fleaf,"waveshell"));
    { char hx[40]; tuid_hex(cid,hx,sizeof hx);
      LOG("hook: createInstance cid=%s%s%s iid-is-EditController=%d -> r=%d obj=%p",
          hx, isWT?" = ":"", isWT?wname:"", wantEC, (int)r, (obj?*obj:NULL)); }
    if(r==kResultOk && obj && *obj){
        void* c=NULL;
        if(wantEC){ c=*obj; ((GUnk*)c)->vtbl->addRef(c); if(isWavesFactory) waves_mark(c); }   /* host asked for the controller; take our own ref */
        else { GUnk* u=(GUnk*)*obj; void* q=NULL; int qr=u->vtbl->queryInterface(u,IID_IEditController,&q);
               if(qr==kResultOk && q) c=q;
               else {
                 /* Controller not wired up yet (normal for Waves). Do NOT keep probing this fresh object:
                    just patch its initialize() and capture on the host thread once the host has built it.
                    Nothing else is called here, so creation stays exactly as fast and as safe as unhooked. */
                 LOG("hook:   QI(IEditController)=0x%08X (not ready yet)",(unsigned)qr);
                 /* Label the instance with the real product name decoded from its class id. It is
                    recorded against the OBJECT as well, because Mono and Stereo share one component
                    vtable and the vtable-keyed name below is whichever variant was created first. */
                 /* Record a name for EVERY object that comes through here, not just the Waves ones.
                    The table is keyed by address and entries are never freed, so an object that
                    lands on an address a destroyed Waves instance used to occupy would otherwise be
                    captured under that old plug-in's name. Writing the fallback name overwrites the
                    stale entry instead. */
                 inst_name_set(*obj, (isWT && wname[0]) ? wname : (fleaf ? fleaf : "plugin"));
                 hook_component_initialize(*obj, isWT ? wname : fleaf, isWavesFactory, fleaf);
               } }
        if(c){
            if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
            if(!g_ejecting && !caught_known(c) && g_ncaught<MAXI){
                void* fvt=(void*)((IPluginFactory*)factory)->vtbl;
                for(int i=0;i<g_nHooked;i++) if(g_hookedVtbl[i]==fvt){ modmap_set(c, g_hookedLeaf[i]); break; }
                g_caughtRel[g_ncaught]=-1; g_caughtStrike[g_ncaught]=0; g_caught[g_ncaught++]=c;
                /* A controller the host asked the factory for DIRECTLY (iid=IEditController) belongs to
                   a plug-in whose processor and controller are SEPARATE objects -- the standard VST3
                   split. For those, setParamNormalized() only moves the controller's own copy: the
                   value reaches the DSP solely when the controller forwards it to the host's
                   IComponentHandler. 电音11 is a single-object design and works without this, which is
                   why the hook used to be installed only for Waves; The T-Pain Effect (iZotope) is a
                   split design (component cid ZTSV..., controller cid ZESV...) and was captured here
                   with no handler at all, so Key/Scale edits would have changed nothing audible.
                   Hooking setComponentHandler is the general rule for this path -- but NOT a
                   harmless one: it patches the controller's vtable, which is exactly what PACE
                     kills a plug-in for -- hence the gate in the next paragraph. */
                /* ...EXCEPT on Antares: PACE protects 电音11's controller vtable and patching any of
                   its methods crashes it (the reason the old getParamNormalized hook was removed).
                   电音11 is also a single-object design that never needed the handler, so excluding it
                   keeps its behaviour bit-for-bit identical to before.
                   The verdict is read from the hook table, where the worker put it when it hooked
                   this factory. Only a POSITIVE "not Antares" patches: -1 (never established) is
                   treated like Antares, so an unexpected module is left exactly as 1093 left it. */
                if(fant==0) hook_setcomponenthandler(c);
                { char ml[96]; const char* nm = modmap_get(c,ml,sizeof ml) ? ml : "plugin";
                  LOG("CAUGHT genuine controller @ %p (factory hook) [%s] -- now controllable%s",
                      c,nm,(fant==0)?" (host handler hook armed)":""); } }
            else { ((GUnk*)c)->vtbl->release(c); }
            if(g_catchCsInit) LeaveCriticalSection(&g_catchCs);
        }
    }
    return r;
}
static tresult WINAPI myCreateInstance(void* factory, const TUID cid, const TUID iid, void** obj){   /* counts the call, then does the work */
    InterlockedIncrement(&g_inHook);
    tresult r_ = myCreateInstance_inner(factory,cid,iid,obj);
    InterlockedDecrement(&g_inHook);
    return r_; }


/* runs on the HOST thread, right after the host finished initialising the instance: by now the
   edit-controller side is wired up, so this is the correct moment to ask for it. */
static tresult WINAPI myInitialize_inner(void* self, void* context){
    void* vt=*(void**)self; tInit orig=NULL; char leaf[96]="plugin"; int isWaves=0; char shell[96]="";
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);   /* copy out under the lock, then release: the
                                                             plug-in's own initialize must never run while
                                                             we hold a lock it might contend on */
    for(int i=0;i<g_nIH;i++) if(g_ihVtbl[i]==vt){ orig=g_ihOrig[i]; isWaves=g_ihWaves[i]; snprintf(leaf,96,"%s",g_ihLeaf[i]); snprintf(shell,96,"%s",g_ihShell[i]); break; }
    /* The per-instance name wins over the vtable's shared one (Mono and Stereo share a vtable, so
       that one carries whichever variant the host happened to create first). Looked up inline
       because the same lock is already held here. */
    for(int i=0;i<g_nIn;i++) if(g_inObj[i]==self){ if(g_inName[i][0]) snprintf(leaf,96,"%s",g_inName[i]); break; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs);
    if(!orig){ LOG("initialize hook: no original recorded for vtable %p -- cannot forward",vt); return kInvalidArgument; }
    tresult r=orig(self,context);                      /* let the plug-in initialise exactly as usual */
    if(r==kResultOk && !IN_SELF_CREATE() && !g_ejecting){
        void* q=NULL;
        if(((GUnk*)self)->vtbl->queryInterface(self,IID_IEditController,&q)==kResultOk && q){
            if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
            if(!caught_known(q) && g_ncaught>=MAXI && !caught_known(q))
                LOG("capture table is full (%d) -- this instance is NOT under control. A host plug-in "
                    "rescan instantiates every class in the shell, which can fill it; it frees up again "
                    "as those are identified and released.",MAXI);
            if(!g_ejecting && !caught_known(q) && g_ncaught<MAXI){ modmap_set(q,leaf); g_caughtRel[g_ncaught]=-1; g_caughtStrike[g_ncaught]=0; g_caught[g_ncaught++]=q;
                if(isWaves){ waves_mark(q); hook_setcomponenthandler(q); }
                capshell_mark(shell);   /* catch the handler the host is about to install */
                LOG("CAUGHT genuine controller @ %p after initialize() [%s] waves=%d",q,leaf,isWaves); }
            else ((GUnk*)q)->vtbl->release(q);
            if(g_catchCsInit) LeaveCriticalSection(&g_catchCs);
        } else LOG("initialize(): object %p still has no IEditController [%s]",self,leaf);
    }
    return r;
}
static tresult WINAPI myInitialize(void* self, void* context){   /* counts the call, then does the work */
    InterlockedIncrement(&g_inHook);
    tresult r_ = myInitialize_inner(self,context);
    InterlockedDecrement(&g_inHook);
    return r_; }


/* patch (or re-assert) createInstance on a factory's vtbl; dedups by vtbl address */
/* How long the host had been running when the agent got in. A VST3 instance can only be captured
   at the moment it is created, so an agent that arrives after the host has loaded its project
   finds those instances already made and can never take them over (README "加载顺序"). Without a
   time in the log there was no telling WHY it arrived late -- controller opened after the rack,
   or a slow injection (first launch after boot, antivirus scanning the injector). Reads only this
   process's own creation time; touches no plug-in. 0xFFFFFFFF = unknown. */
static DWORD g_hostAgeAtLoad=0xFFFFFFFF;
static DWORD ms_since_host_start(){
    FILETIME cr,ex,kn,us,now;
    if(!GetProcessTimes(GetCurrentProcess(),&cr,&ex,&kn,&us)) return 0xFFFFFFFF;
    GetSystemTimeAsFileTime(&now);
    ULONGLONG a=((ULONGLONG)cr.dwHighDateTime<<32)|cr.dwLowDateTime;
    ULONGLONG b=((ULONGLONG)now.dwHighDateTime<<32)|now.dwLowDateTime;
    if(b<=a) return 0;
    ULONGLONG ms=(b-a)/10000ULL;
    return ms>0xFFFFFFFEULL ? 0xFFFFFFFE : (DWORD)ms; }
static void patch_create_on_factory(IPluginFactory* f, const char* why, const char* leaf, int lateHook, int antares){
    if(g_ejecting) return;            /* never install a patch that would outlive this DLL */
    if(!f) return; IPluginFactoryVtbl* vt=(IPluginFactoryVtbl*)f->vtbl; if(!vt) return;
    /* The EAT hook calls this from the HOST thread while the worker may be in here for another
       module, so the table is mutated under g_hookCs. Without it two appends could race on the
       index, and -- far worse -- a second patch of the SAME vtbl could record our own hook as the
       "original", which is an instant infinite recursion on the next createInstance. */
    if(g_hookCsInit) EnterCriticalSection(&g_hookCs);
    if(g_ejecting){if(g_hookCsInit)LeaveCriticalSection(&g_hookCs);return;} /* safe stop may have completed while this callback waited for the lock */
    int idx=-1; for(int i=0;i<g_nHooked;i++) if(g_hookedVtbl[i]==(void*)vt){ idx=i; break; }
    if(idx<0 && vt->createInstance==(tCreate)myCreateInstance){   /* already ours but untracked: never record it as the original */
        if(g_hookCsInit) LeaveCriticalSection(&g_hookCs);
        return; }
    if(idx<0){
        if(g_nHooked>=MAXVT){ if(g_hookCsInit) LeaveCriticalSection(&g_hookCs);
            /* Silent until now: the factory simply did not get hooked and that plug-in could
               never be captured, with nothing anywhere to say why. */
            LOG("WARN: factory hook table full (%d) -- '%s' will NOT be captured. Too many catch "
                "modules loaded at once; remove plug-in versions you do not use.",MAXVT,leaf?leaf:"?");
            return; }
        DWORD op; if(VirtualProtect((void*)&vt->createInstance,sizeof(void*),PAGE_EXECUTE_READWRITE,&op)){
            g_hookedVtbl[g_nHooked]=(void*)vt; g_hookedOrig[g_nHooked]=vt->createInstance;
            if(leaf&&leaf[0]) snprintf(g_hookedLeaf[g_nHooked],96,"%s",leaf); else g_hookedLeaf[g_nHooked][0]=0;
            g_hookedAnt[g_nHooked]=antares;
            g_nHooked++;   /* publish vtbl+orig+leaf+ant BEFORE patching, so a concurrent createInstance always finds orig AND the module leaf */
            __atomic_signal_fence(__ATOMIC_SEQ_CST);   /* compiler barrier: keep the publish ahead of the patch regardless of optimizer (x86 TSO handles the CPU side) */
            vt->createInstance=myCreateInstance;
            VirtualProtect((void*)&vt->createInstance,sizeof(void*),op,&op);
            LOG("createInstance HOOKED on factory %p (vtbl %p) [%s]",(void*)f,(void*)vt,why);
            /* Only the LATE path (worker retry, after the host already had the factory) needs a
               re-add. When the EAT hook got here we are ahead of the host's first createInstance,
               so telling the user to re-add would be wrong and confusing. */
            if(lateHook) LOG(">>> factory hooked late (the agent got into this host %lu ms after it started): any instance the "
                             "host created before this moment cannot be captured -- if the plug-in is already in the project, "
                             "REMOVE and RE-ADD it once, or reopen the project",(unsigned long)g_hostAgeAtLoad); }
    } else if(vt->createInstance!=(tCreate)myCreateInstance){   /* was reset (e.g. by InitDll) -> re-assert */
        DWORD op; if(VirtualProtect((void*)&vt->createInstance,sizeof(void*),PAGE_EXECUTE_READWRITE,&op)){
            g_hookedOrig[idx]=vt->createInstance; vt->createInstance=myCreateInstance;
            VirtualProtect((void*)&vt->createInstance,sizeof(void*),op,&op);
            LOG("createInstance RE-ASSERTED on factory %p [%s]",(void*)f,why); }
    }
    if(g_hookCsInit) LeaveCriticalSection(&g_hookCs);
}

/* hook a catch module (电音11): patch ONLY the factory vtbl (a DATA table), never the plugin's code.
   Called on every (re)load by the LoadLibraryExW hook and re-asserted each worker scan. This is
   PACE-tolerant (first-load vtbl patch succeeded) and robust to same-address reloads (it re-reads the
   current createInstance pointer rather than writing stale bytes). No GetPluginFactory code hook. */
/* hook (or re-assert) the factory's createInstance. The factory pointer comes from factory_once(),
   so a module is never asked for its factory twice no matter which path reaches here. */
/* remember which modules we already reported as "factory not ready", so the retry loop below logs
   that once per module instead of once per scan (every ~1.2s). */
static HMODULE g_nrMod[MAXVT]; static int g_nNr=0;
static int notready_first(HMODULE mod){
    for(int i=0;i<g_nNr;i++) if(g_nrMod[i]==mod) return 0;
    if(g_nNr<MAXVT) g_nrMod[g_nNr++]=mod;
    return 1; }
static void hook_factory(HMODULE mod, const char* path){
    IPluginFactory* f=factory_once(mod);
    if(!f){                              /* module mid-unload, not ready, or not a VST3 */
        if(notready_first(mod))
            LOG("hook_factory: GetPluginFactory() not ready yet for %s (NULL/faulted) -- will retry on later scans",path);
        return; }
    /* "Is it safe to patch this plug-in's controller vtable later?" -- answered from the cleared
       list, NOT from a content scan. hook_factory() is only ever called for catch modules, so the
       question is exactly "is this catch module one we have cleared", and a list answers it with
       certainty. Deciding it by searching the file for "antares" would make a crash-critical call
       on the absence of a string: 电音11 whose vendor string failed to appear would come back
       "not Antares" and we would patch the very vtable PACE protects.
       0 = cleared (safe to patch), 1 = treat as PACE (leave alone). */
    int ant = module_in(path,VTBL_CLEARED) ? 0 : 1;
    volatile LONG saved=g_probing; g_probing=1;
    if(setjmp(g_jb)==0){ const char* bs=strrchr(path,'\\'); patch_create_on_factory(f,"factory vtbl",bs?bs+1:path,1,ant); }
    else { g_probing=saved; LOG("hook_factory: faulted while hooking %s (left clean)",path); return; }
    g_probing=saved;
    /* deliberately NOT enumerating the factory -- the class id identifies the plug-in on its own. */
}



/* (The getParamNormalized / controller-vtbl hook was removed: PACE protects the controller vtbl,
   so patching any of its methods crashes 电音11. Existing instances are captured via re-add only.) */

/* ================= EAT hook: intercept the HOST's own GetPluginFactory() =================

   WHY. The worker hooks the factory a moment AFTER the shell is loaded, because at load time the
   shell has not been through InitDll() yet and hands out no factory (WaveShell 16.7 returns NULL
   there). But the host does load -> InitDll -> GetPluginFactory -> createInstance back to back, in
   milliseconds, so the FIRST instance is always created before the late hook lands. That is why a
   plug-in added right after the rack starts had to be removed and re-added once.

   HOW. The loader notification runs INSIDE LdrLoadDll, i.e. before LoadLibrary has even returned to
   the host, so it is the last moment at which we are guaranteed to be ahead of the host's
   GetProcAddress("GetPluginFactory"). We redirect that export to a small thunk of our own by
   rewriting its RVA in the module's export address table. When the host then calls it, our thunk
   calls the real function, hooks createInstance on the returned factory, and hands the same pointer
   back. The host's createInstance therefore always goes through the hook -> no re-add, ever.

   WHY THIS IS SAFE IN THE LOADER CALLBACK. Only a DWORD in the module's export directory is
   rewritten -- a DATA table. No instruction is patched anywhere, so there is no trampoline, no
   instruction-length decoding, and nothing to get wrong on a different build of the shell. Every
   field is bounds-checked against the SizeOfImage the loader itself reports, so a malformed or
   unexpected header makes us decline rather than fault. The only APIs used are VirtualAlloc /
   VirtualQuery / VirtualProtect, which MSDN lists as safe to call from DllMain-context code: they
   are thin wrappers over the memory syscalls and never take the loader lock. Nothing is logged from
   inside the callback -- the outcome is recorded in a struct and printed later by the worker --
   because the CRT's stdio lock is the one lock that could plausibly tangle with the loader lock.

   AND IT REMOVES THE LAST 140->280 RISK. The factory the host receives is cached, so the agent
   never issues a GetPluginFactory() call of its own on an EAT-hooked shell. Where we previously
   added a second successful call (harmless on 16.7, but the shell is documented to append to its
   class list on a second call), there is now exactly one -- the host's.

   SCOPE. WaveShell only. 电音11 is PACE-protected and may verify its own headers, so its modules
   keep the existing vtable-only path, which already works for them. */
#define MAXEAT 32   /* see MAXVT */
typedef struct {
    HMODULE mod;             /* the shell */
    DWORD*  slot;            /* the export-table DWORD we rewrote */
    DWORD   origRva;         /* its original value: both the restore value and the real function */
    void*   stub;            /* our thunk; deliberately never freed, see remove_eat_hooks() */
    char    leaf[96];        /* shell filename, for the log and for the hook's module label */
    volatile LONG fired;     /* the host has called through it */
} EatHook;
static EatHook g_eat[MAXEAT]; static volatile LONG g_nEat=0;
static int g_eatOff=0;       /* noeat.txt kill switch: fall back to the old late-hook behaviour */
/* Last attempt that did NOT result in a hook, so the worker can explain why. The callback cannot
   log, and a failed attempt occupies no g_eat slot, so the reason is parked here instead. */
static HMODULE volatile g_eatFailMod=NULL; static volatile LONG g_eatFailSt=0;

/* ---- the thunk's C side: runs on the HOST thread, inside the host's GetPluginFactory() call ---- */
static IPluginFactory* gpf_call(EatHook* r){
    InterlockedIncrement(&g_inHook);           /* eject waits for this to drain before unmapping us */
    typedef IPluginFactory*(WINAPI*GF)(void);
    IPluginFactory* f=NULL;
    if(r && r->mod && r->origRva){
        /* Hand back the pointer from the first successful call instead of asking the shell again.
           WaveShell is documented to APPEND to its class list on a second successful call (140 ->
           280, after which it creates nothing), so "exactly one call per module per process" is an
           invariant of this whole design -- and the 15s fallback in scan_all can make OUR call the
           first one, which would otherwise leave the host's own call to be the fatal second.
           A VST3 factory is a singleton, so returning the same pointer is also what the shell's own
           accessor would do. (Two host threads racing the very first call is not guarded; no host
           does that, and it would be no worse than before.) */
        f=factory_cached(r->mod);
        if(!f){
            GF real=(GF)(void*)((unsigned char*)r->mod + r->origRva);
            f=real();                          /* the one and only call this module ever gets */
            if(f) factory_cache_put(r->mod,f);
        }
        if(f){
            r->fired=1;
            /* Asked separately, NOT assumed. This used to pass a hard-coded 0 on the grounds that a
               module only reaches here if it was cleared -- true when one list governed both
               decisions, false now that they are split: Antares is cleared for the EAT hook and
               deliberately not for the vtable patch, so a hard-coded 0 would hand a PACE-protected
               plug-in exactly the treatment that crashes it.
               module_in() is pure string work on the leaf we stored at install time: no file I/O and
               no crash guard, which is what the host thread requires. */
            int vok = module_in(r->leaf,VTBL_CLEARED) ? 0 : 1;
            patch_create_on_factory(f,"EAT hook (host's own GetPluginFactory)",r->leaf,0,vok);
        }
    }
    InterlockedDecrement(&g_inHook);
    return f; }
#ifdef _WIN64
static IPluginFactory* WINAPI gpf_thunk_c(EatHook* r){ return gpf_call(r); }   /* arg arrives in rcx */
#else
static IPluginFactory* __cdecl gpf_thunk_c(EatHook* r){ return gpf_call(r); }
#endif

/* The thunk jumps INDIRECTLY, through a pointer slot at offset 16.
   That one detail is what makes unhooking safe. The straightforward form ("load the target into a
   register, jump to it") has to be rewritten instruction-by-instruction to turn it into a plain
   forwarder at eject time, and a host thread sitting between those instructions would then run the
   jump with a register the new code never loaded. Here the instructions are written once and never
   change: retargeting is a single store to an aligned pointer, which the CPU performs atomically, so
   a thread executing the jump reads either the old target or the new one and both are valid.
   The stub is page-aligned, so offset 16 is pointer-aligned.
   rcx (x64) / the pushed argument (x86) carries the record. After retargeting it is simply ignored:
   GetPluginFactory takes no arguments, and the x86 form cleans up its own push either way. */
#define EAT_SLOT(stub) (*(void* volatile*)((unsigned char*)(stub)+16))
static void eat_write_thunk(unsigned char* p, void* rec, void* fn){
#ifdef _WIN64
    p[0]=0x48; p[1]=0xB9; *(void**)(p+2)=rec;            /* mov  rcx, rec              */
    p[10]=0xFF; p[11]=0x25; *(DWORD*)(p+12)=0;           /* jmp  qword ptr [rip+0]     */
#else
    p[0]=0x68; *(void**)(p+1)=rec;                       /* push rec                   */
    p[5]=0xFF; p[6]=0x15; *(void**)(p+7)=(void*)(p+16);  /* call dword ptr [p+16]      */
    p[11]=0x83; p[12]=0xC4; p[13]=0x04;                  /* add  esp,4                 */
    p[14]=0xC3; p[15]=0x00;                              /* ret                        */
#endif
    EAT_SLOT(p)=fn;                                      /* the only field ever changed */
}

/* The export table stores 32-bit RVAs, so the thunk has to live ABOVE the module base and within
   4 GB of it. Walk free regions upward from the end of the image and take the first that fits. */
static void* eat_alloc_stub_near(unsigned char* base, ULONG image){
    uintptr_t start=((uintptr_t)base+image+0xFFFF)&~(uintptr_t)0xFFFF;
    uintptr_t lim=(uintptr_t)base+0xF0000000u; if(lim<(uintptr_t)base) lim=(uintptr_t)-1;   /* 32-bit overflow guard */
    int tries=0;
    MEMORY_BASIC_INFORMATION mbi;
    /* Bounded on purpose: this walks the address space from inside the loader callback, and a
       badly fragmented process could otherwise hold the loader lock for thousands of VirtualQuery
       calls. The region just past a freshly mapped image is free in practice, so this succeeds on
       the first or second step; giving up early just falls back to the worker's late hook. */
    for(uintptr_t p=start; p<lim; ){
        if(++tries>512) break;
        if(VirtualQuery((void*)p,&mbi,sizeof mbi)!=sizeof mbi) break;
        if(mbi.State==MEM_FREE){
            void* m=VirtualAlloc((void*)p,64,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);
            if(m) return m; }
        uintptr_t nxt=(uintptr_t)mbi.BaseAddress+mbi.RegionSize; if(nxt<=p) break; p=nxt; }
    return NULL; }

/* Bounds-checked lookup of one export's RVA slot. Everything is validated against the image size
   the loader reported, so a header we do not understand ends as "decline", never as a fault. */
static int eat_find_slot(unsigned char* b, ULONG size, const char* want, DWORD** slotOut, DWORD* origOut){
    if(!b || size<0x200) return 0;
    if(b[0]!='M'||b[1]!='Z') return 0;
    LONG e=*(LONG*)(b+0x3C); if(e<0 || (ULONG)e+0x108>size) return 0;
    unsigned char* nt=b+e; if(*(DWORD*)nt!=0x00004550u) return 0;              /* "PE\0\0" */
    WORD magic=*(WORD*)(nt+0x18); DWORD er,es;
    if(magic==0x20B){ er=*(DWORD*)(nt+0x88); es=*(DWORD*)(nt+0x8C); }          /* PE32+ */
    else if(magic==0x10B){ er=*(DWORD*)(nt+0x78); es=*(DWORD*)(nt+0x7C); }     /* PE32  */
    else return 0;
    if(!er||!es||er>=size||(unsigned long long)er+es>size) return 0;
    /* The fields below live at ed+0x14 .. ed+0x27, so the directory must actually be that big AND
       lie inside the image. Checking only er+es<=size was not enough: a header that declares a
       short export directory would send these reads past the end of the mapping, i.e. an access
       violation raised inside the loader callback -- the one thing this parser promises never to do. */
    if(es<0x28 || (unsigned long long)er+0x28>size) return 0;
    unsigned char* ed=b+er;
    DWORD nf=*(DWORD*)(ed+0x14), nn=*(DWORD*)(ed+0x18);
    DWORD rf=*(DWORD*)(ed+0x1C), rn=*(DWORD*)(ed+0x20), ro=*(DWORD*)(ed+0x24);
    if(!nn||!nf||!rf||!rn||!ro) return 0;
    if((unsigned long long)rf+4ull*nf>size) return 0;
    if((unsigned long long)rn+4ull*nn>size) return 0;
    if((unsigned long long)ro+2ull*nn>size) return 0;
    /* Likewise bounded: nn is only constrained by the image size, so a malformed header could ask
       for millions of name comparisons while the loader lock is held. Real modules are far below
       this (WaveShell 17.1 exports 4968 names, the largest seen). */
    if(nn>65536u) return 0;
    DWORD* fn=(DWORD*)(b+rf); DWORD* nm=(DWORD*)(b+rn); WORD* od=(WORD*)(b+ro);
    int wl=0; while(want[wl]) wl++;
    for(DWORD i=0;i<nn;i++){
        DWORD r=nm[i]; if(!r||r>=size) continue;
        if((unsigned long long)r+wl+1>size) continue;
        const char* s=(const char*)(b+r); int ok=1;
        for(int j=0;j<=wl;j++) if(s[j]!=want[j]){ ok=0; break; }
        if(!ok) continue;
        WORD o=od[i]; if(o>=nf) return 0;
        DWORD v=fn[o];
        if(!v||v>=size) return 0;
        if(v>=er && v<er+es) return 0;                    /* forwarder, not real code -> decline */
        *slotOut=&fn[o]; *origOut=v; return 1; }
    return 0; }

/* Installs the hook. Runs UNDER THE LOADER LOCK: no logging, no locks, no CRT beyond pure
   byte-twiddling. Returns a status code the worker turns into one log line later. */
static int eat_install_inner(HMODULE mod, ULONG image, const wchar_t* wname, int wlen){
    if(g_eatOff) return 1;                                  /* disabled by noeat.txt */
    /* An eject is under way: remove_eat_hooks() may already have run, and an entry installed after
       it would leave the module's export pointing at a stub inside a DLL that is about to be
       unmapped. LdrUnregisterDllNotification does not promise that an in-flight callback has
       finished, so this check is what actually closes that window. */
    if(g_ejecting) return 8;
    for(int i=0;i<g_nEat;i++) if(g_eat[i].mod==mod){
        EatHook* r=&g_eat[i];if(r->slot)return 3;
        DWORD* slot=NULL,orig=0;if(!eat_find_slot((unsigned char*)mod,image,"GetPluginFactory",&slot,&orig)||orig!=r->origRva)return 4;
        DWORD op;if(!VirtualProtect(slot,sizeof(DWORD),PAGE_READWRITE,&op))return 6;
        EAT_SLOT(r->stub)=(void*)(uintptr_t)gpf_thunk_c;r->slot=slot;*slot=(DWORD)((unsigned char*)r->stub-(unsigned char*)mod);VirtualProtect(slot,sizeof(DWORD),op,&op);return 0;
    }
    if(g_nEat>=MAXEAT) return 2;   /* 满额由调用方记录(状态码 2) */
    DWORD* slot=NULL; DWORD orig=0;
    if(!eat_find_slot((unsigned char*)mod,image,"GetPluginFactory",&slot,&orig)) return 4;
    void* stub=eat_alloc_stub_near((unsigned char*)mod,image);
    if(!stub) return 5;
    LONG ix=g_nEat;                                         /* only the loader thread gets here */
    EatHook* r=&g_eat[ix];
    r->mod=mod; r->slot=slot; r->origRva=orig; r->stub=stub; r->fired=0;
    { int i=0,j=0;                                          /* leaf name, ASCII, no CRT */
      for(int k=0;k<wlen;k++) if(wname[k]==L'\\'||wname[k]=='/') j=k+1;
      for(int k=j;k<wlen && i<95;k++){ wchar_t c=wname[k]; r->leaf[i++]=(c<128)?(char)c:'?'; }
      r->leaf[i]=0; }
    eat_write_thunk((unsigned char*)stub,(void*)r,(void*)(uintptr_t)gpf_thunk_c);
    DWORD op;
    if(!VirtualProtect(slot,sizeof(DWORD),PAGE_READWRITE,&op)){ r->slot=NULL; return 6; }
    *slot=(DWORD)((unsigned char*)stub-(unsigned char*)mod);
    VirtualProtect(slot,sizeof(DWORD),op,&op);
    g_nEat=ix+1;                                            /* publish only once fully built */
    return 0; }
/* The slot is claimed with a plain "read g_nEat, fill, publish", which is only safe if two of these
   never overlap. Loader notifications are serialised by the loader lock, so in practice they do not
   -- but if that ever stopped holding, two modules would share one record and a host would be handed
   the WRONG plug-in's factory. A non-blocking claim removes the question: a second caller simply
   declines and falls back to the worker's late hook. Never spins, so it cannot stall the loader. */
static volatile LONG g_eatBusy=0;
static int eat_install(HMODULE mod, ULONG image, const wchar_t* wname, int wlen){
    if(InterlockedCompareExchange(&g_eatBusy,1,0)!=0){ g_eatFailMod=mod; g_eatFailSt=7; return 7; }
    int rc=eat_install_inner(mod,image,wname,wlen);
    InterlockedExchange(&g_eatBusy,0);
    if(rc){ g_eatFailMod=mod; g_eatFailSt=rc; }              /* park the reason for the worker to print */
    return rc; }

/* Undo before the agent unloads. The export goes back to its real RVA, and the thunk is rewritten
   into a bare jump to the real function and then LEAKED (one 64 KB reservation per shell): a host
   that cached the stub address keeps working forever instead of calling into unmapped memory. */
static void remove_eat_hooks(){
    for(int i=0;i<g_nEat;i++){
        EatHook* r=&g_eat[i]; if(!r->slot||!r->mod) continue;
        DWORD want=(DWORD)((unsigned char*)r->stub-(unsigned char*)r->mod), op;
        if(VirtualProtect(r->slot,sizeof(DWORD),PAGE_READWRITE,&op)){
            if(*r->slot==want) *r->slot=r->origRva;
            VirtualProtect(r->slot,sizeof(DWORD),op,&op); }
        /* Retarget the thunk straight at the real export and LEAK it: a host that cached the stub
           address keeps working for ever instead of calling into unmapped memory. One aligned
           pointer store, no instruction bytes touched, so a thread inside the thunk right now is
           unaffected. */
        if(r->stub) EAT_SLOT(r->stub)=(void*)((unsigned char*)r->mod+r->origRva);
        r->slot=NULL; }
    /* Retired records and thunks stay valid until process exit. */ }

/* ---- inline hook on LoadLibraryExW: the instant a catch-mode module (电音11) is (re)loaded, hook its
        factory BEFORE the host calls createInstance. Beats "unload on remove / reload on re-add". ---- */
/* ---- catch-on-load via LdrRegisterDllNotification (loader-lock-safe; NO code patching of LoadLibrary;
     avoids the lock-order inversion that an inline LoadLibraryExW hook + g_llcs would risk vs the loader lock) ---- */
typedef struct { USHORT Length; USHORT MaximumLength; const wchar_t* Buffer; } ATK_USTR;
typedef struct { ULONG Flags; const ATK_USTR* FullDllName; const ATK_USTR* BaseDllName; void* DllBase; ULONG SizeOfImage; } ATK_LDR_DATA;
typedef void (CALLBACK* ATK_LDR_CB)(ULONG, const ATK_LDR_DATA*, void*);
typedef LONG (NTAPI* ATK_LdrReg)(ULONG, ATK_LDR_CB, void*, void**);
typedef LONG (NTAPI* ATK_LdrUnreg)(void*);
/* Load-notification queue. This was a SINGLE slot (flag + one HMODULE): if two catch modules loaded
   back-to-back before the worker consumed it (exactly what happens with WaveShell1 + WaveShell2), the
   second notification was silently dropped and that shell was never hooked. Small ring instead.
   Written under the loader lock (callback) -> no API calls, no locks: a plain bounded array + indices. */
#define LLQ 8
static HMODULE volatile g_llQ[LLQ]; static volatile LONG g_llHead=0, g_llTail=0;
static volatile LONG g_llFlag=0;   /* retained: "queue non-empty" fast check */
static ATK_LdrReg g_ldrReg=NULL; static ATK_LdrUnreg g_ldrUnreg=NULL; static void* g_ldrCookie=NULL;
/* runs UNDER THE LOADER LOCK -> do the absolute minimum: name check (catch list pre-loaded) + set a flag.
   The worker thread (outside the loader lock) does the real factory hook. No I/O, no locks, no LoadLibrary here. */
static int wide_has_ascii_ci(const wchar_t* w, int wlen, const char* pat){   /* ASCII-ci substring, NO API calls */
    int pl=(int)strlen(pat); if(pl==0||wlen<pl) return 0;
    for(int i=0;i+pl<=wlen;i++){ int ok=1;
        for(int j=0;j<pl;j++){ wchar_t c=w[i+j]; char lc; if(c>=L'A'&&c<=L'Z') lc=(char)(c+32); else if(c<128) lc=(char)c; else lc=0;   /* inline ASCII lowercase: NO libc (tolower could touch locale/lock under the loader lock) */
            if(lc!=pat[j]){ ok=0; break; } }
        if(ok) return 1; }
    return 0; }
/* UNDER THE LOADER LOCK: no Win32 API, no I/O, no locks -- only match the (pre-loaded) catch patterns
   against the wide name and set a flag + base. The worker resolves the path and hooks the factory. */
static void CALLBACK dll_notify(ULONG reason, const ATK_LDR_DATA* d, void*){
    if(reason!=1 || !d || g_ejecting) return;
#if AT_XHH_MANAGED
    ATCS_LoaderRead policyRead;if(!policyRead.snapshot)return;
    const ATCS_Claims* publicPolicy=&policyRead.snapshot->policy;
#endif                             /* 1 = LDR_DLL_NOTIFICATION_REASON_LOADED */
    const ATK_USTR* fn=d->FullDllName; if(!fn||!fn->Buffer||!d->DllBase) return;
    int wlen=(int)(fn->Length/2), match=0;
#if AT_XHH_MANAGED
    wchar_t basename[129];int start=0;for(int i=0;i<wlen;i++)if(fn->Buffer[i]==L'\\'||fn->Buffer[i]==L'/')start=i+1;
    if(wlen-start<=0||wlen-start>128)return;for(int i=start;i<wlen;i++)basename[i-start]=fn->Buffer[i];basename[wlen-start]=0;
    if(atcs_policy_module_denied(publicPolicy,basename,NULL))return;
#endif
    /* BOTH lists. 1128 moved the built-in patterns out of g_catchPat into their own array so a long
       catch.txt could not crowd them out -- but it only updated is_catch_path(), not this second
       copy of the same test. With no catch.txt at all, g_nCatchPat is 0, the loop below never ran,
       and the notification bailed out for EVERY built-in catch module: The T-Pain Effect, WaveShell,
       Auto-Tune Pro, 电音11. The EAT hook is installed from HERE and nowhere else, so all of them
       silently fell back to the worker's late hook and needed a remove-and-re-add every session.
       (It went unnoticed because the machine under test had a hand-written catch.txt listing
       Auto-Tune Pro, so that one plug-in kept working while the rest did not.) */
    for(int k=0;g_catchBuiltin[k] && !match;k++) if(wide_has_ascii_ci(fn->Buffer,wlen,g_catchBuiltin[k])) match=1;
    for(int k=0;k<g_nCatchPat && !match;k++) if(g_catchPat[k][0] && wide_has_ascii_ci(fn->Buffer,wlen,g_catchPat[k])) match=1;
    if(!match) return;
    /* skip.txt is the user's opt-out and must hold on THIS path too (1155). It was only checked in
       scan_all, so "waveshell" in skip.txt -- documented as turning off all Waves handling -- still let
       this callback rewrite WaveShell's export and queue it for the factory hook; instances were then
       caught, listed and written to as if nothing had been said. Same matching as mod_skiplisted_low():
       case-insensitive substring of the full path. The patterns were loaded by cb_startup(), which runs
       before this notification is registered, so this is a plain read: no API, no lock, no I/O. */
    for(int k=0;k<g_nSkip;k++) if(g_skip[k][0] && wide_has_ascii_ci(fn->Buffer,wlen,g_skip[k])) return;
    /* Only a VST3 has a factory to hook. A VST2 whose name matches a catch pattern -- the VST2 WaveShell
       shells all along, and since 1149's "auto-tune" every Antares VST2 too -- used to be queued anyway:
       the worker then PINNED it (it could never unload for the rest of the session) and "hooked its
       factory", logging that it would retry on later scans, which never happens because scan_all only
       registers modules that export GetPluginFactory. The VST2 path finds those plug-ins by their
       AEffect and needs none of this. Same export parse the EAT installer uses below: bounded reads of
       the image just mapped, no API calls, no locks -- safe under the loader lock. */
    { DWORD* s_=NULL; DWORD o_=0;
      if(!eat_find_slot((unsigned char*)d->DllBase,d->SizeOfImage,"GetPluginFactory",&s_,&o_)) return; }
    /* THE moment to redirect the export: we are still inside LdrLoadDll, so the host has not yet
       had a chance to call GetProcAddress on it. Only modules on the cleared list -- 电音11 is PACE-protected and
       keeps the vtable-only path. Pure data writes, nothing logged (see eat_install). */
    /* file name only -- see module_in() for why the directory must not count */
    { int lf=0; for(int k=0;k<wlen;k++) if(fn->Buffer[k]==L'\\'||fn->Buffer[k]==L'/') lf=k+1;
      for(int k=0;EAT_CLEARED[k];k++)
        if(wide_has_ascii_ci(fn->Buffer+lf,wlen-lf,EAT_CLEARED[k])){
            eat_install((HMODULE)d->DllBase,d->SizeOfImage,fn->Buffer,wlen); break; } }
    /* The queue was previously skipped whenever g_llFlag was already set, which silently dropped a
       second shell loading back-to-back; it is a ring, so just push unless it is genuinely full. */
    { LONG t=g_llTail; LONG n=(t+1)&(LLQ-1);
      if(n!=g_llHead){ g_llQ[t]=(HMODULE)d->DllBase; g_llTail=n; g_llFlag=1; } } }   /* drop only if the ring is genuinely full */
static void install_dll_notification(){
    is_catch_path("x");                                     /* pre-load catch.txt NOW (worker thread) so the callback never does file I/O under the loader lock */
    /* Safety valve, read HERE so the loader callback never touches the disk: if the EAT hook ever
       misbehaves on some host, dropping an empty noeat.txt into the comm dir turns it off and the
       agent reverts to the (working, but re-add-requiring) late factory hook. No rebuild needed. */
    { FILE* nf=fopen_retry(g_noeatPath,"r"); if(nf){ fclose(nf); g_eatOff=1;
        LOG("noeat.txt present -> EAT hook disabled; using the late factory hook (re-add may be needed)"); } }
    HMODULE nt=GetModuleHandleA("ntdll.dll"); if(!nt){ LOG("ntdll not found; catch-on-load off (re-add still works)"); return; }
    g_ldrReg=(ATK_LdrReg)(void*)GetProcAddress(nt,"LdrRegisterDllNotification");
    g_ldrUnreg=(ATK_LdrUnreg)(void*)GetProcAddress(nt,"LdrUnregisterDllNotification");
    if(g_ldrReg){ LONG st=g_ldrReg(0,dll_notify,NULL,&g_ldrCookie);
        if(st==0) LOG("DLL-load notification registered (catch-on-load; loader-lock-safe)");
        else { g_ldrCookie=NULL; LOG("LdrRegisterDllNotification failed st=0x%lx",(long)st); } }
    else LOG("LdrRegisterDllNotification unavailable; catch-on-load off (re-add still works)"); }
static void remove_dll_notification(){ if(g_ldrCookie && g_ldrUnreg){ g_ldrUnreg(g_ldrCookie); g_ldrCookie=NULL; } }
/* restore every hooked factory's createInstance -- MUST run before the agent unloads, or the factory
   vtbl keeps pointing into the freed agent (myCreateInstance) -> host crash on the next createInstance. */
static void remove_factory_hooks(){
    for(int i=0;i<g_nHooked;i++){ IPluginFactoryVtbl* vt=(IPluginFactoryVtbl*)g_hookedVtbl[i]; if(!vt) continue;
        DWORD op;
        if(VirtualProtect((void*)&vt->createInstance,sizeof(void*),PAGE_EXECUTE_READWRITE,&op)){   /* success => page mapped (pinned module) => safe to touch */
            if(vt->createInstance==(tCreate)myCreateInstance) vt->createInstance=g_hookedOrig[i];
            VirtualProtect((void*)&vt->createInstance,sizeof(void*),op,&op); } }
    /* Keep original dispatch records for delayed host calls and safe re-assertion. */ }

/* Also neutralises control characters, because every string a plug-in hands back passes through
   here: parameter names, parameter displays, effect names, VST3 titles. Those names end up verbatim
   in the status file, whose format is one record per line with \x01 separating the part the user
   reads from the machine-readable tail. A name containing a newline would split one record into two
   (the controller would list a garbage entry), and one containing \x01 would move the metadata
   boundary and mis-parse the instance id and capabilities. Cleaning them centrally means no caller
   has to remember to. */
static void trim(char* s){ int n=(int)strlen(s);
    for(int k=0;k<n;k++) if((unsigned char)s[k] < 0x20) s[k]=' ';
    while(n>0 && (s[n-1]==' '||s[n-1]=='\t')) s[--n]=0;
    int i=0; while(s[i]==' '||s[i]=='\t') i++; if(i) memmove(s,s+i,(size_t)(n-i+1)); }
/* ---- scale synonym groups ------------------------------------------------------------------
   Different plug-ins give the SAME scale different names, so an exact-name match leaves the most
   common case broken: Auto-Tune Pro calls it "Minor", Waves calls it "Natural Minor". Measured
   against the two real lists (Pro's 15 Modern Scales, Waves' 44), 12 names already match exactly;
   these groups close the remaining gap, taking the shared vocabulary to 14/15.
   Groups are DATA, not code: scalemap.txt in the shared folder adds more without a rebuild, which
   matters because the names of plug-ins I have never seen cannot be known in advance.
   Format, one group per line, first entry is the canonical display name:
       Minor|Natural Minor|Aeolian                                                               */
#define MAXGRP 24
#define MAXMEM 8
static char g_grpN[MAXGRP][MAXMEM][48]; static char g_grpDisp[MAXGRP][48];
static int g_grpCnt[MAXGRP]; static int g_nGrp=0; static int g_grpLoaded=0;
/* 返回 1=已加入,0=跳过(满额),-1=跳过(不足两项)。
   原先一律静默返回,而调用方按「读到的行数」报数 —— 日志说加了 N 组,实际可能一组都没加。
   这个文件管的是音阶等价匹配,不生效时的症状是「选了音阶却匹配不上」,
   而用户看着日志以为它生效了,根本不会往这里查。 */
static int grp_add_line(const char* line){
    if(!line||!line[0]||line[0]=='#') return -1;
    if(g_nGrp>=MAXGRP) return 0;
    char buf[256]; snprintf(buf,sizeof buf,"%s",line);
    int m=0, haveDisp=0, extra=0; char* p=buf;
    while(*p){ char* bar=strchr(p,'|'); if(bar)*bar=0; trim(p);
        if(p[0]){
            if(m>=MAXMEM) extra++;        /* 别名超限也要说一声:少一个别名 = 那个插件的音阶名匹配不上 */
            else { if(!haveDisp){ snprintf(g_grpDisp[g_nGrp],48,"%s",p); haveDisp=1; }
                   norm(p,g_grpN[g_nGrp][m],48); m++; } }
        if(!bar) break; p=bar+1; }
    if(extra) LOG("WARN: scalemap.txt: '%s' has %d alias(es) past the %d-per-group limit -- "
                  "those names will not match",g_grpDisp[g_nGrp],extra,MAXMEM);
    if(m<2) return -1;              /* 一行至少要有「规范名|别名」两项才构成一组 */
    g_grpCnt[g_nGrp]=m; g_nGrp++; return 1; }
static void load_scalemap(){
    g_grpLoaded=1; g_nGrp=0;
    /* Built-in groups. Only equivalences that are unambiguous are enabled here:
         Minor = Natural Minor = Aeolian                    (same 7 notes, no reading in which they differ)
         Jazz Melodic Minor = Melodic Minor (Asc)           (the jazz form IS the ascending form used both ways)
       Deliberately NOT included: Auto-Tune "Diminished" vs Waves "Diminished (W-H)/(H-W)" -- a bare
       "Diminished" does not say which of the two octatonic forms it is, and guessing would silently
       select the wrong note set. Add it to scalemap.txt yourself once you have A/B'd it. */
    static const char* DEF[]={ "Minor|Natural Minor|Aeolian",
                               "Major|Ionian",
                               "Jazz Melodic Minor|Melodic Minor (Asc)|Jazz Minor|Melodic Minor", NULL };
    for(int i=0;DEF[i];i++) (void)grp_add_line(DEF[i]);   /* 内置组先加,所以永远挤不掉 */
    FILE* f=fopen_retry(g_scalemapPath,"r");
    if(f){ char line[256]; int added=0, full=0, malformed=0, first=1;
        while(fgets(line,sizeof line,f)){ if(first){ first=0; drop_bom(line); } int L=(int)strlen(line);
            while(L>0&&(line[L-1]=='\n'||line[L-1]=='\r')) line[--L]=0;
            int i=0; while(line[i]==' '||line[i]=='\t') i++;
            if(!line[i] || line[i]=='#') continue;
            int r=grp_add_line(line+i);
            if(r==1) added++; else if(r==0) full++; else malformed++; }
        fclose(f);
        if(added)     LOG("scalemap.txt: %d synonym group(s) added",added);
        if(full)      LOG("WARN: scalemap.txt: %d line(s) dropped, the table is full (%d groups max)",full,MAXGRP);
        if(malformed) LOG("WARN: scalemap.txt: %d line(s) ignored -- a group needs at least "
                          "\"Canonical|Alias\" on one line",malformed); } }
static int grp_of(const char* nm){ if(!g_grpLoaded) load_scalemap();
    if(!nm||!nm[0]) return -1;
    for(int g=0;g<g_nGrp;g++) for(int m=0;m<g_grpCnt[g];m++) if(!strcmp(g_grpN[g][m],nm)) return g;
    return -1; }
static int scale_same(const char* aNorm, const char* bNorm){
    if(!strcmp(aNorm,bNorm)) return 1;
    int ga=grp_of(aNorm); return (ga>=0 && ga==grp_of(bNorm)); }
/* canonical display name for a plug-in's own scale name, or NULL to keep it as-is */
static const char* scale_canon(const char* disp){ char n[48]; norm(disp,n,sizeof n);
    int g=grp_of(n); return (g>=0)? g_grpDisp[g] : NULL; }
/* ---- cached VST3 per-controller discovery: ParamIDs, step counts, and the plugin's OWN scale names ---- */
typedef struct { void* ctrl; ParamID scaleId, keyId; int scaleSteps, keySteps, haveS, haveK, nscales;
                 ParamID retId, humId, nvbId; int haveRet, haveHum, haveNvb;
                 ParamID audioId; int audioSteps, haveAudio;
                 char snorm[96][48]; char sdisp[96][48]; double svals[96];
                 ParamID modId; int modSteps, haveMod, modn;                       /* Auto-Tune Pro 11 "Modern Scale" (id=162) */
                 char msnorm[48][48]; char msdisp[48][48]; double msvals[48];
                 /* ---- Waves (WaveShell-hosted) support ---- */
                 int isWaves;          /* controller came from the Waves VST3 shell */
                 int isTPain;          /* T-Pain uses Root note + Scale + Speed; it is not Waves */
                 int isTuner;          /* has a Root/Key + Scale pair -> we control it; else ignore */
                 int discDone;         /* disc_fill ran to completion (param count was sane) */
                 int nkeys; char kdisp[24][48]; double kvals[24];                  /* Waves "Root": set key by matching pitch class (ordering-agnostic). 24 slots: Waves reports stepCount=16, i.e. SEVENTEEN positions C,C#,Db,D,D#,Eb,E,F,F#,Gb,G,G#,Ab,A,A#,Bb,B -- a 16-entry table silently dropped B. */
                 ParamID wSpeedId, wTransId, wVibId, wRangeId; int haveWSpeed, haveWTrans, haveWVib, haveWRange; } V3Disc;  /* v2 feel/range targets (logged now) */
#define NDISC 16
static V3Disc g_disc[NDISC]; static int g_discHead=0;
/* These two must stay equal: the published text is compared against the remembered copy to decide
   whether anything changed. A copy smaller than the buffer silently truncates in strncpy, the
   comparison then always differs, and the file is rewritten on every single scan. Two literals
   that happen to match today is exactly the arrangement that produced an out-of-bounds write in
   1130, so they are derived from one name instead. */
#define SCALES_BUF 16384
static char g_scalesWritten[SCALES_BUF]="";
static V3Disc* disc_find(void* c){ for(int i=0;i<NDISC;i++) if(g_disc[i].ctrl==c) return &g_disc[i]; return NULL; }
/* Measured from a live Waves Tune Real-Time via VST3 (which CAN enumerate); VST2 cannot, so it
   borrows these and verifies every write by reading the parameter display back. */
#define WAVES_NSCALE 44
static const char* const WAVES_SCALES[WAVES_NSCALE] = {
    "User Scale",
    "Chromatic",
    "Major",
    "Natural Minor",
    "Harmonic Minor",
    "Melodic Minor (Asc)",
    "Melodic Minor (Asc+Dec)",
    "Major Justonic",
    "Minor Justonic",
    "Dorian",
    "Mixolydian",
    "Blues",
    "Phrygian",
    "Locrian",
    "Lydian",
    "Whole Tone",
    "Diminished (W-H)",
    "Diminished (H-W)",
    "Bebop",
    "Major Pentatonic",
    "Minor Pentatonic",
    "Major Pentatonic flat 3rd",
    "Minor Pentatonic + Blues",
    "Bebop + Blues",
    "Pythagorean",
    "Maqam Rast (Rast-Rast)",
    "Maqam Saba",
    "Maqam Bayati",
    "Maqam Nahawand",
    "Maqam Hijaz",
    "Maqam Kurd",
    "Maqam Huzam",
    "Bilawal (Hindustani)",
    "Bilawal (Carnatic)",
    "Kafi (Hindustani)",
    "Kafi (Carnatic)",
    "Bhairavi (Hindustani)",
    "Bhairavi (Carnatic)",
    "Kalyan (Hindustani)",
    "Kalyan (Carnatic)",
    "Khamaj (Hindustani)",
    "Khamaj (Carnatic)",
    "Asavari (Hindustani)",
    "Asavari (Carnatic)",
};
/* ---- The T-Pain Effect (iZotope), VST2 position lists ----
   VST2 cannot enumerate a discrete parameter's values, so a position list has to be borrowed the same
   way the Waves one is. These two are not guesses: the VST3 build of this very plug-in enumerated them
   on the real machine (fill_scale_names 6/6 at scaleId=18 stepCount=5, fill_key_names 12/12 at
   keyId=19 stepCount=11), and they match the KEY / SCALE drop-downs in its GUI exactly. Order matters:
   position i is written as i/(n-1), and every write is read back and verified by v2w_set_checked(). */
#define TPAIN_NSCALE 6
static const char* const TPAIN_SCALES[TPAIN_NSCALE] = {
    "Chromatic","Major","Minor","Major Pentatonic","Minor Pentatonic","Custom" };
#define TPAIN_NROOT 12
static const char* const TPAIN_ROOTS[TPAIN_NROOT] = {
    "C","C#","D","D#","E","F","F#","G","G#","A","A#","B" };

#define WAVES_NROOT 17
static const char* const WAVES_ROOTS[WAVES_NROOT] = {
    "C",
    "C#",
    "Db",
    "D",
    "D#",
    "Eb",
    "E",
    "F",
    "F#",
    "Gb",
    "G",
    "G#",
    "Ab",
    "A",
    "A#",
    "Bb",
    "B",
};

static double g_fSpeed=-1; /* controller emits per-family speed; Antares uses retune, Waves/T-Pain speed */
static double g_fRet=-1, g_fHum=-1, g_fNvb=-1; static int g_fAudio=-1;   /* feel from current cmd (normalized 0..1; -1 = leave); g_fAudio = audio-type index 0..4 (-1 = leave) */
/* ---- Waves over VST2 ----
   VST2 reports no step count and cannot be asked for the display of any value but the current one,
   so the position lists above are borrowed from the VST3 twin (same plug-in core, and the VST2 9.6
   parameter list was measured to be 12/12 identical in names AND indices to the VST3 11.0 one).
   Borrowing is only safe because every write is CHECKED: after setting, the parameter display is
   read back and compared against what was asked for. A mismatch is reported instead of being
   silently accepted, so a wrong assumption shows up as a log line rather than as a wrong key. */
typedef struct { AEffect* e; uint32_t uid; int np;        /* identity fingerprint: see v2w_discover */
                 char name[96];                            /* effect name, used for BOTH display and targeting */
                 DWORD seen;                               /* last tick this object was still around */
                 int rootIdx, scaleIdx, speedIdx, transIdx, vibIdx; int isTuner; int announced;
                 int kind;                                 /* V2K_WAVES or V2K_TPAIN: picks the names to
                                                              look for and the position list to write */ } V2W;
#define V2K_WAVES 0
#define V2K_TPAIN 1
static V2W g_v2w[MAXI]; static int g_nV2W=0;
static V2W* v2w_find(AEffect* e){ for(int i=0;i<g_nV2W;i++) if(g_v2w[i].e==e) return &g_v2w[i]; return NULL; }

/* An instance id must be unique among LIVE objects. Truncating a 64-bit pointer to 32 bits lets two
   objects that differ only above bit 31 collide, and then picking one in Target would drive both.
   Folding the high half in costs nothing and removes that. */
/* Locale-independent number parsing. atof()/strtod() follow LC_NUMERIC, and this agent lives inside
   the HOST process -- a host that has called setlocale(LC_ALL,"") on a machine whose locale uses a
   comma makes atof("0.85") stop at the '.' and return 0. Every feel slider would then silently
   collapse to zero on some machines and work on others, with nothing in the log to show for it.
   The controller always writes '.', so parse it that way explicitly.
   Returns -1 for anything unparseable, which is this protocol's "leave it alone". */
/* The controller writes one command line and always ends it with "|t=<tick>\n". Two things follow:
   (a) the reader's buffer must be at least as large as the writer's, or the tail (|tid=, |t=) is
       silently cut off and per-instance targeting quietly stops working -- the writer's buffer is
       320, so 256 here was too small for a long plug-in name plus a long scale name;
   (b) the file is rewritten in place with fopen("w"), so a poll can land mid-write and fgets then
       returns a prefix with NO trailing newline. Acting on a prefix means acting on a truncated
       number: "key=11" cut to "key=1" would momentarily retune the singer to the wrong key before
       the next poll corrects it. A line without its terminator is simply not ready yet. */
/* Publish a shared file ATOMICALLY: write a temp beside it, then rename over the target.
   Rewriting in place means a reader polling at the wrong moment sees a half-written file. For the
   single-line command file "does it end with a newline" is enough to detect that, but these files
   hold several records: a cut at any record boundary also ends with a newline and looks perfectly
   complete while silently missing the rest -- the instance list would lose entries, the Target list
   would rebuild and the user's selection would be dropped. A rename gives the reader either the old
   file or the new one and never anything in between.
   (While the rename runs, a reader can fail to OPEN the file -- a sharing violation, not "absent". The
   controller treats that as a half-written read and keeps what it had, 1162.)
   If the rename fails (a reader happens to hold the file open) the caller leaves its "last written"
   cache untouched, so the next cycle simply tries again. */
static int publish_file(const char* path, const char* body){
    char tmp[MAX_PATH]; snprintf(tmp,sizeof tmp,"%s.tmp",path);
    FILE* f=fopen(tmp,"w"); if(!f) return 0;
    int ok = (fputs(body,f)>=0);
    if(fclose(f)!=0) ok=0;
    if(ok && MoveFileExA(tmp,path,MOVEFILE_REPLACE_EXISTING)) return 1;
    DeleteFileA(tmp);
    /* The caller retries next cycle, which is right for a reader momentarily holding the file -- but
       a full disk or a read-only folder would retry forever in silence. Say it once. */
    { static int warned=0; if(!warned){ warned=1;
        LOG("could not publish %s (disk full, folder read-only, or the file is held) -- will keep retrying",path); } }
    return 0; }
static int cmd_line_complete(const char* s){ int n=(int)strlen(s); return n>0 && s[n-1]=='\n'; }
static double parse_num(const char* s){
    if(!s) return -1;
    while(*s==' '||*s=='\t') s++;
    int neg=0; if(*s=='-'){ neg=1; s++; } else if(*s=='+') s++;
    double v=0; int any=0;
    while(*s>='0'&&*s<='9'){ v=v*10+(*s-'0'); s++; any=1; }
    if(*s=='.'){ s++; double f=0.1;
        while(*s>='0'&&*s<='9'){ v+=(*s-'0')*f; f*=0.1; s++; any=1; } }
    if(!any) return -1;
    return neg ? -v : v; }
/* The protocol says 0..1, but the file on disk is just text and could be stale, hand-edited, or read
   while being rewritten. audiotype was already clamped; these three were not, and a value above 1
   would be handed to setParamNormalized, which is specified for 0..1 only. */
static double clamp01(double v){ if(v<0) return -1; return v>1.0 ? 1.0 : v; }
/* Instance id = the pointer folded into 32 bits. It is no longer only cosmetic: since 1119 the
   controller sends it back as tid= to address one instance out of several of the same plug-in, so a
   wrong or colliding value silently retargets the user's edit.
   The high half is taken through a 64-bit value on purpose. Written as v>>32 on a 32-bit build the
   shift count equals the width of uintptr_t, which is undefined behaviour -- this compiler happens
   to fold it to 0 (leaving the id correct by luck), but x86 shift instructions reduce the count
   modulo 32, which would yield v^v == 0 for EVERY instance: every id identical, precise targeting
   quietly dead, and the Target box unable to tell two instances apart. Not something to leave to the
   optimiser's mood. On 64-bit the result is bit-for-bit what it always was. */
static unsigned inst_id(const void* p){
    uintptr_t v=(uintptr_t)p;
    unsigned lo=(unsigned)v;
    unsigned hi=(sizeof(uintptr_t)>4) ? (unsigned)(((unsigned long long)v)>>32) : 0u;
    return lo ^ hi; }
static char g_procLeaf[96]="";                                   /* this host process's exe name */
static void mod_leaf(void* addrInModule, char* out, int outsz);  /* fwd */
static void mod_of_ctrl(IEditController* c, char* out, int outsz);/* fwd */
/* Publish the scale list PER INSTANCE, keyed by the same leaf the status list uses, e.g.
       [Waves Tune Real-Time Mono]
       Chromatic
       Major
       ...
       [电音11.vst3]
       ...
   One flat merged list cannot support both of the things the controller needs: scoping the Scale
   list to the instance selected in Target, and offering only the scales EVERY loaded plug-in
   understands when Target is "all". Names are written canonicalised, so the controller's
   intersection lines up across plug-ins that spell the same scale differently. */
/* Append one whole record, or nothing. snprintf reports the length it WANTED, so on a record that does not
   fit, "off += snprintf(buf+off, sizeof buf-off, ...)" leaves half a record at the end of the buffer and
   an offset past it. Both files built this way are read by the controller, which treats a file whose last
   byte is not '\n' as caught mid-write: it ignores a torn scale list outright, and on a torn status file it
   keeps showing what it showed before -- and since the agent keeps publishing the same bytes, the
   instance list stays frozen. The status writer's guard ("leave 220 bytes") assumed lines shorter than
   they can be: host + plug-in name + key + scale + feel reach ~500 bytes. The scale writer's guards did
   cover its records (names are at most 47 bytes), but with two different margins -- 120 for a section
   header, 60 for a scale line -- so near the end a header could be refused while the lines after it were
   still written, and the controller then filed those scales under the PREVIOUS instance. Whole sections
   now go in or stay out together (see write_scales_union). */
/* A condition that persists from one scan to the next is logged when it starts, not on every scan:
   write_status runs every 1-2 s, so "buffer full" logged unconditionally is ~1800 identical lines an
   hour -- the same flood 1145 removed elsewhere. Returns 1 exactly when 'now' goes from false to true. */
static int rose(int* was, int now){ int r = (now && !*was); *was = now ? 1 : 0; return r; }
static int rec_append(char* buf, int cap, int* off, const char* fmt, ...){
    if(!buf || cap<=0 || *off<0 || *off>=cap) return 0;
    va_list ap; va_start(ap,fmt);
    int n=vsnprintf(buf+*off,(size_t)(cap-*off),fmt,ap);
    va_end(ap);
    if(n<0 || n>=cap-*off){ buf[*off]=0; return 0; }   /* did not fit: leave nothing of it behind */
    *off+=n; return 1; }

static void write_scales_union(){
    char buf[SCALES_BUF]; int off=0; buf[0]=0; int dropped=0;
    for(int k=0;k<NDISC;k++){ V3Disc* d=&g_disc[k]; if(!d->ctrl||!agent_policy_address(((IEditController*)d->ctrl)->vtbl,d->isTPain?"tpain":d->isWaves?"waves":NULL)) continue;
        if(d->isWaves && d->discDone && !d->isTuner) continue;          /* non-tuning Waves plug-in */
        /* modmap only -- deliberately NOT mod_of_ctrl: this runs inside do_set_vst3_one's crash
           guard, and mod_of_ctrl would install a second guard on the same buffer. */
        char leaf[96]=""; if(!modmap_get(d->ctrl,leaf,sizeof leaf)) continue;
        if(!leaf[0]) continue;
        if(g_procLeaf[0] && !_stricmp(leaf,g_procLeaf)) continue;       /* host-side wrapper, not a plug-in */
        int head=off, emitted=0, fits=1;
        if(!rec_append(buf,(int)sizeof buf,&off,"[%s]\n",leaf)) fits=0;
        char seen[128][48]; int nseen=0;
        int useMod = (d->haveMod && d->modn>0);                          /* Pro: only the modern list is active */
        int cnt = useMod ? d->modn : d->nscales;
        for(int i=0;i<cnt;i++){
            const char* disp = useMod ? d->msdisp[i] : d->sdisp[i];
            if(!disp[0]) continue;
            const char* cn=scale_canon(disp); const char* outn=cn?cn:disp;
            char nn[48]; norm(outn,nn,sizeof nn);
            int dup=0; for(int q=0;q<nseen;q++) if(!strcmp(seen[q],nn)){dup=1;break;}
            if(dup) continue; if(nseen<128){ strncpy(seen[nseen],nn,47); seen[nseen][47]=0; nseen++; }
            if(fits && rec_append(buf,(int)sizeof buf,&off,"%s\n",outn)) emitted++; else fits=0; }
        /* Drop an empty section, and a section that did not fit whole: a partial list would offer this
           instance as having only the scales that happened to fit. Truncating buf matters as much as
           rewinding off -- the file is published as a STRING, and rewinding off alone left an empty
           section's header in it; with Target = all, one empty section turns the controller's
           intersection into its "no common ground" union. */
        if(!emitted || !fits){ off=head; buf[off]=0; }
        if(!fits){ dropped=1; break; }                                   /* buffer full: stop at a whole section */
    }
    /* VST2 Auto-Tune matches against the classic 29-name table, so publish exactly that table for it;
       without this a VST2 instance contributes nothing and would silently fall out of the intersection. */
    for(int i=0;i<g_nv2;i++){ AEffect* e=g_v2[i]; if(!e) continue;
        char lf[96]; mod_leaf((void*)e->dispatcher,lf,sizeof lf);
        if(g_procLeaf[0] && !_stricmp(lf,g_procLeaf)) continue;
        if(!g_v2tbl[i]){                        /* name-discovered VST2: publish ITS borrowed list */
            V2W* w=v2w_find(e); if(!w || !w->isTuner) continue;
            /* Must follow the instance's own list: publishing Waves' 44 names for a T-Pain instance
               would offer scales it does not have, and -- because the controller intersects the lists
               when "all" is targeted -- would also wrongly shrink what a Waves instance can be set to. */
            const char* const* SC = (w->kind==V2K_TPAIN) ? TPAIN_SCALES : WAVES_SCALES;
            int NSC               = (w->kind==V2K_TPAIN) ? TPAIN_NSCALE : WAVES_NSCALE;
            int head=off, fits=rec_append(buf,(int)sizeof buf,&off,"[%s]\n",w->name);
            for(int q=0;q<NSC && fits;q++){ const char* cn=scale_canon(SC[q]); const char* outn=cn?cn:SC[q];
                fits=rec_append(buf,(int)sizeof buf,&off,"%s\n",outn); }
            if(!fits){ off=head; buf[off]=0; dropped=1; break; }
            continue; }
        { int head=off, fits=rec_append(buf,(int)sizeof buf,&off,"[%s]\n",lf);
          for(int q=0;q<29 && fits;q++){ const char* cn=scale_canon(SCALES_STD[q]); const char* outn=cn?cn:SCALES_STD[q];
              fits=rec_append(buf,(int)sizeof buf,&off,"%s\n",outn); }
          if(!fits){ off=head; buf[off]=0; dropped=1; break; } } }
    { static int wasFull=0;
      if(rose(&wasFull,dropped)) LOG("write_scales_union: scale-list buffer full -> later instances' scales are NOT published"); }
    /* Nothing to publish means this process has no tuning instance left. "off>0" alone only stops a
       NEW file being written -- the previous one stays on disk, and the controller keeps reading it
       because the process is still alive and still injected. The stale section then goes on taking
       part in the intersection the Scale list is built from when Target is "all": remove a 6-scale
       plug-in from a rack that also holds a 44-scale one and the list stays cut down to 6, with the
       scales that are still perfectly available greyed out of existence.
       (The status file had the same hole, fixed in 1111; this is its other half.) */
    if(off<=0){
        if(GetFileAttributesA(g_scalesPath)!=INVALID_FILE_ATTRIBUTES){ DeleteFileA(g_scalesPath); g_scalesWritten[0]=0; }
        return; }
    int scalesMissing = (GetFileAttributesA(g_scalesPath)==INVALID_FILE_ATTRIBUTES);
    if(off>0 && (scalesMissing || strcmp(buf,g_scalesWritten)!=0)){
        if(publish_file(g_scalesPath,buf)){ strncpy(g_scalesWritten,buf,sizeof g_scalesWritten-1); g_scalesWritten[sizeof g_scalesWritten-1]=0;
               LOG("published per-instance scale lists (%d byte(s))",off); } }
}


/* ---- live read-back of each plugin's CURRENT Key/Scale -> status_<pid>.txt (controller aggregates+displays) ---- */
static int gp_str(IEditController* c, ParamID id, double val, char* out, int outsz);   /* fwd (defined below) */
static int strstr_ci(const char* hay, const char* needle);                            /* fwd (defined below) */
static const char* KEYS_STD[12]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
static const char* AUDIOTYPES_STD[5]={"Soprano","Alto/Tenor","Low Male","Instrument","Bass Inst"};
/* same pairing as SCALES_BUF above */
#define STATUS_BUF 8192
static char g_statusWritten[STATUS_BUF]="";
/* g_jb is a SINGLE recovery point. Setting one up while another is already active on the same
   buffer silently destroys the outer one: after the inner helper returns, g_jb points at a frame
   that has already unwound, so a later fault longjmps into dead stack. (g_probing==2 is the heap
   scan, which uses the separate g_scanjb and may legitimately contain a g_jb guard.) */
static int g_nestWarned=0, g_offThreadWarned=0;
static void warn_nested_guard(const char* who){
    if(g_probing==1 && !g_nestWarned){ g_nestWarned=1;
        LOG("WARN: %s installed a crash guard while one was already active on g_jb -- the outer "
            "recovery point is lost. This is a bug; please send this log.",who); }
    /* g_jb and g_probing are single globals, and veh() only recovers on the worker thread. A guard
       armed anywhere else therefore protects nothing AND overwrites the worker's recovery point, so
       a later fault on the worker longjmps into another thread's stack. Arming one off-thread is
       always a bug; this catches it instead of letting it corrupt silently. (1100: the capture path
       briefly did exactly this by asking "is this module Antares?" from the host thread.) */
    if(g_workerTid && GetCurrentThreadId()!=g_workerTid && !g_offThreadWarned){ g_offThreadWarned=1;
        LOG("WARN: %s armed the g_jb crash guard on thread %lu, but only the worker thread (%lu) is "
            "recoverable -- the guard is useless there and clobbers the worker's. This is a bug; "
            "please send this log.",who,(unsigned long)GetCurrentThreadId(),(unsigned long)g_workerTid); } }
static double gp_norm_safe(IEditController* c, ParamID id){        /* VST3: read current normalized value, crash-guarded */
    volatile double v=-1.0; volatile LONG sv=g_probing; warn_nested_guard("gp_norm_safe"); g_probing=1;
    if(setjmp(g_jb)==0){ v=c->vtbl->getParamNormalized(c,id); } else v=-1.0; g_probing=sv; return v; }
static int gp2_disp(AEffect* e, int idx, char* out, int outsz){   /* VST2: current value's display string, crash-guarded (empty on AT4/5) */
    out[0]=0; volatile int ok=0; volatile LONG sv=g_probing; warn_nested_guard("gp2_disp"); g_probing=1;
    if(setjmp(g_jb)==0){ char tmp[128]=""; e->dispatcher(e,effGetParamDisplay,idx,0,tmp,0.f); tmp[127]=0; snprintf(out,outsz,"%s",tmp); trim(out); ok=1; } else ok=0;
    g_probing=sv; return ok; }
static double gp2_param(AEffect* e, int idx){                      /* VST2: current normalized value, crash-guarded */
    volatile double v=-1.0; volatile LONG sv=g_probing; warn_nested_guard("gp2_param"); g_probing=1;
    if(setjmp(g_jb)==0){ v=e->getParameter(e,idx); } else v=-1.0; g_probing=sv; return v; }
/* Name of a discrete VST2 parameter's CURRENT setting.
   effGetParamDisplay is optional and plenty of plug-ins return nothing for it -- Auto-Tune 4/5 do, and
   so does The T-Pain Effect, whose status line therefore read "Key=? Scale=?" even though the writes
   were landing correctly. When there is no display text, read the value back instead and resolve it
   through the same borrowed position list the write used: position = round(v*(n-1)). Returns 0 only
   when neither route produced anything. */
static int v2_disc_name(AEffect* e, int idx, const char* const* tbl, int n, char* out, int outsz){
    out[0]=0; if(idx<0) return 0;
    gp2_disp(e,idx,out,outsz); trim(out);
    if(out[0]) return 1;
    if(!tbl || n<2) return 0;
    double v=gp2_param(e,idx); if(v<0) return 0;
    int pos=(int)(v*(double)(n-1)+0.5); if(pos<0) pos=0; if(pos>n-1) pos=n-1;
    snprintf(out,outsz,"%s",tbl[pos]); return 1; }
static void mod_leaf(void* addrInModule, char* out, int outsz){    /* module filename containing addr (the plugin DLL) */
    out[0]=0; HMODULE hm=NULL;
    if(addrInModule && GetModuleHandleExA(0x4|0x2 /*FROM_ADDRESS|UNCHANGED_REFCOUNT*/, (LPCSTR)addrInModule, &hm) && hm){
        char path[MAX_PATH]=""; if(GetModuleFileNameA(hm,path,MAX_PATH)){ const char* bs=strrchr(path,'\\'); snprintf(out,outsz,"%s", bs?bs+1:path); } }
    if(!out[0]) snprintf(out,outsz,"plugin"); }
static void mod_of_ctrl(IEditController* c, char* out, int outsz){   /* module of a VST3 controller, crash-guarded (setjmp contained here) */
    volatile int ok=0; volatile LONG sv=g_probing; warn_nested_guard("mod_of_ctrl"); g_probing=1;
    if(setjmp(g_jb)==0){ mod_leaf(*(void**)c, out, outsz); ok=1; } g_probing=sv; if(!ok) snprintf(out,outsz,"plugin"); }
static int key_to_pc(const char* k){                 /* "C","C#","C#/Db","Bb"... -> pitch class 0..11, or -1 */
    static const char* N2[10]={"C#","DB","D#","EB","F#","GB","G#","AB","A#","BB"}; static const int P2[10]={1,1,3,3,6,6,8,8,10,10};
    static const char* N1[7]={"C","D","E","F","G","A","B"}; static const int P1[7]={0,2,4,5,7,9,11};
    char u[8]=""; int j=0; for(int i=0;k[i]&&j<4;i++){ char ch=k[i]; u[j++]=(ch>='a'&&ch<='z')?(char)(ch-32):ch; } u[j]=0;
    for(int i=0;i<10;i++) if(strncmp(u,N2[i],2)==0) return P2[i];
    for(int i=0;i<7;i++) if(u[0]==N1[i][0]) return P1[i];
    return -1; }
static void camelot_of(const char* key, const char* scale, char* out, int outsz){   /* Camelot from key + major/minor */
    out[0]=0; int pc=key_to_pc(key); if(pc<0) return;
    char ls[64]=""; for(int i=0;i<63&&scale[i];i++) ls[i]=(scale[i]>='A'&&scale[i]<='Z')?(char)(scale[i]+32):scale[i];
    int maj=(strstr(ls,"major")!=NULL), min_=(strstr(ls,"minor")!=NULL);
    static const int MAJ[12]={8,3,10,5,12,7,2,9,4,11,6,1};
    static const int MIN[12]={5,12,7,2,9,4,11,6,1,8,3,10};
    if(maj&&!min_) snprintf(out,outsz,"%dB",MAJ[pc]);
    else if(min_&&!maj) snprintf(out,outsz,"%dA",MIN[pc]); }
static int v2_pname(AEffect* e, int idx, char* out, int outsz){   /* read one VST2 param name, crash-guarded (setjmp contained) */
    out[0]=0; volatile int ok=0; volatile LONG sv=g_probing; warn_nested_guard("v2_pname"); g_probing=1;
    if(setjmp(g_jb)==0){ char tmp[128]=""; e->dispatcher(e,effGetParamName,idx,0,tmp,0); tmp[127]=0; snprintf(out,outsz,"%s",tmp); ok=1; }
    g_probing=sv; return ok;
}
static void v2_feel_find(AEffect* e, int* ret, int* hum, int* nvb, int* aud){   /* VST2: find Retune/Humanize/NaturalVibrato/AudioType by name */
    *ret=-1; *hum=-1; *nvb=-1; *aud=-1; int n=e->numParams; if(n<0)n=0; if(n>1024)n=1024;
    for(int i=0;i<n;i++){ char nm[128]; if(!v2_pname(e,i,nm,sizeof nm)) continue;
        char low[128]; int j; for(j=0;nm[j]&&j<127;j++){ char c=nm[j]; low[j]=(c>='A'&&c<='Z')?(char)(c+32):c; } low[j]=0;
        if(*ret<0 && strstr(low,"retune") && !strstr(low,"graph")) *ret=i;
        if(*hum<0 && strstr(low,"humaniz")) *hum=i;
        if(*nvb<0 && (strstr(low,"natural vibrato")||strstr(low,"flex"))) *nvb=i;
        if(*aud<0 && (strstr(low,"audio type")||strstr(low,"input type"))) *aud=i; }
}
static void write_status(){
    if(!g_procLeaf[0]){ char p[MAX_PATH]=""; if(GetModuleFileNameA(NULL,p,MAX_PATH)){ const char* bs=strrchr(p,'\\'); snprintf(g_procLeaf,sizeof g_procLeaf,"%s",bs?bs+1:p); } if(!g_procLeaf[0]) snprintf(g_procLeaf,sizeof g_procLeaf,"host"); }
    char buf[STATUS_BUF]; int full=0; int off=snprintf(buf,sizeof buf,"#b%d m=%d\n",AT_BUILD,AT_XHH_MANAGED);   /* sized for MAXI instances, not ~30 */   /* version marker (controller strips + checks it) */
#if AT_XHH_MANAGED
    off+=agent_pause_status(buf+off,(unsigned)(sizeof buf-off));
#endif
    const int hdrLen=off;   /* exact length of the marker, so "nothing was added" needs no guesswork */
    for(int i=0;i<g_nv3 && !full;i++){ IEditController* c=g_v3[i]; if(!c||!agent_policy_address(c->vtbl)) continue;
        V3Disc* d=disc_find(c); if(!d) continue;
        if(d->isWaves && d->discDone && !d->isTuner) continue;   /* non-tuning Waves plugin captured via the shell -> don't list it */
        char kn[64]="?", sn[64]="?", mod[96]="plugin";
        char ml[96]; if(modmap_get(c,ml,sizeof ml)) snprintf(mod,sizeof mod,"%s",ml);   /* real module recorded at detection/capture */
        else { mod_of_ctrl(c, mod, sizeof mod);             /* fallback: reverse-lookup from vtbl */
               if(!caught_known(c) && g_procLeaf[0] && _stricmp(mod,g_procLeaf)==0) continue; }   /* heap-scan false positive (vtbl in host) -> skip; a CAUGHT controller is genuine, never skip */
        if(d->haveK){ double kv=gp_norm_safe(c,d->keyId); if(kv>=0) gp_str(c,d->keyId,kv,kn,sizeof kn); }
        if(d->haveMod && d->modn>0){ double sv=gp_norm_safe(c,d->modId); if(sv>=0) gp_str(c,d->modId,sv,sn,sizeof sn); }
        else if(d->haveS){ double sv=gp_norm_safe(c,d->scaleId); if(sv>=0) gp_str(c,d->scaleId,sv,sn,sizeof sn); }
        { char cam[16]=""; camelot_of(kn,sn,cam,sizeof cam); char feel[128]=""; int fo=0;
          if(d->haveRet){ double v=gp_norm_safe(c,d->retId); if(v>=0) fo+=snprintf(feel+fo,sizeof feel-fo,"  Rtn=%d%%",(int)(v*100+0.5)); }
          if(d->haveHum){ double v=gp_norm_safe(c,d->humId); if(v>=0) fo+=snprintf(feel+fo,sizeof feel-fo," Hum=%d%%",(int)(v*100+0.5)); }
          if(d->haveNvb){ double v=gp_norm_safe(c,d->nvbId); if(v>=0) fo+=snprintf(feel+fo,sizeof feel-fo," NVb=%d%%",(int)(v*100+0.5)); }
          if(d->haveAudio){ double v=gp_norm_safe(c,d->audioId); if(v>=0){ char an[48]=""; gp_str(c,d->audioId,v,an,sizeof an); if(an[0]) fo+=snprintf(feel+fo,sizeof feel-fo," AT=%s",an); } }
          if(d->isWaves||d->isTPain){   /* Waves/T-Pain feel read-back: Speed / Note Transition / Vibrato Depth */
            if(d->haveWSpeed){ double v=gp_norm_safe(c,d->wSpeedId); if(v>=0) fo+=snprintf(feel+fo,sizeof feel-fo,"  Spd=%d%%",(int)(v*100+0.5)); }
            if(d->haveWTrans){ double v=gp_norm_safe(c,d->wTransId); if(v>=0) fo+=snprintf(feel+fo,sizeof feel-fo," Trn=%d%%",(int)(v*100+0.5)); }
            if(d->haveWVib){   double v=gp_norm_safe(c,d->wVibId);   if(v>=0) fo+=snprintf(feel+fo,sizeof feel-fo," Vib=%d%%",(int)(v*100+0.5)); } }
          /* Everything after \x01 is for the controller, not for the user: a stable per-instance id
             (so two plug-ins with the SAME name can still be addressed separately) and the set of
             controls this instance actually has. The controller strips it before display. */
          char caps[16]; int ci=0;
          caps[ci++]='K'; caps[ci++]='S';
          if(d->haveRet||d->haveWSpeed) caps[ci++]='R';
          if(d->haveHum||d->haveWTrans) caps[ci++]='H';
          if(d->haveNvb||d->haveWVib)   caps[ci++]='V';
          if(d->haveAudio)              caps[ci++]='A';
          caps[ci]=0;
          if(!rec_append(buf,(int)sizeof buf,&off,"%s | %s  Key=%s  Scale=%s%s%s%s\x01%08X %s\n",
                        g_procLeaf,mod,kn[0]?kn:"?",sn[0]?sn:"?",cam[0]?"  Camelot=":"",cam,feel,
                        inst_id(c), caps)) full=1; } }
    for(int i=0;i<g_nv2 && !full;i++){ AEffect* e=g_v2[i]; if(!e||!agent_policy_address((void*)e->dispatcher)) continue;
        if(!g_v2tbl[i]){                        /* Waves VST2: read the displays straight back */
            V2W* w=v2w_find(e); if(!w || !w->isTuner) continue;
            char mod[96]; mod_leaf((void*)e->dispatcher,mod,sizeof mod);
            if(g_procLeaf[0] && !_stricmp(mod,g_procLeaf)) continue;
              /* No target filter here, deliberately. Reporting answers "which instances exist";
                 the target answers "which one does THIS command act on". Mixing them meant that
                 as soon as a single instance was picked in the Target box, every OTHER instance
                 vanished from the status file -- and so from the Target box itself, which is
                 built from it: with two VST2 instances the list dropped from 3 entries to 2 the
                 moment a command was sent, leaving no way to switch straight to the other one.
                 The VST3 branch above never had this filter. do_set() is where the target
                 belongs, and that is where it is applied. */
            char kn[48]="",sn[64]="",cam[16]="";
            /* fall back to the position list when the plug-in publishes no display text */
            { int tpw=(w->kind==V2K_TPAIN);
              v2_disc_name(e,w->rootIdx , tpw?TPAIN_ROOTS :WAVES_ROOTS , tpw?TPAIN_NROOT :WAVES_NROOT , kn,sizeof kn);
              v2_disc_name(e,w->scaleIdx, tpw?TPAIN_SCALES:WAVES_SCALES, tpw?TPAIN_NSCALE:WAVES_NSCALE, sn,sizeof sn); }
            camelot_of(kn,sn,cam,sizeof cam);
            char feel[128]=""; int fo=0;
            if(w->speedIdx>=0){ double v=gp2_param(e,w->speedIdx); if(v>=0) fo+=snprintf(feel+fo,sizeof feel-fo,"  Spd=%d%%",(int)(v*100+0.5)); }
            if(w->transIdx>=0){ double v=gp2_param(e,w->transIdx); if(v>=0) fo+=snprintf(feel+fo,sizeof feel-fo," Trn=%d%%",(int)(v*100+0.5)); }
            if(w->vibIdx  >=0){ double v=gp2_param(e,w->vibIdx);   if(v>=0) fo+=snprintf(feel+fo,sizeof feel-fo," Vib=%d%%",(int)(v*100+0.5)); }
            char caps[16]; int ci=0; caps[ci++]='K'; caps[ci++]='S';
            if(w->speedIdx>=0) caps[ci++]='R'; if(w->transIdx>=0) caps[ci++]='H'; if(w->vibIdx>=0) caps[ci++]='V';
            caps[ci]=0;
            if(!rec_append(buf,(int)sizeof buf,&off,"%s | %s  Key=%s  Scale=%s%s%s%s\x01%08X %s\n",
                          g_procLeaf, w->name, kn[0]?kn:"?", sn[0]?sn:"?",
                          cam[0]?"  Camelot=":"", cam, feel, inst_id(e), caps)) full=1;
            continue; }
        char kn[64]="", sn[64]="", mod[96]="plugin";
        mod_leaf((void*)e->dispatcher, mod, sizeof mod);
        if(g_procLeaf[0] && _stricmp(mod,g_procLeaf)==0) continue;   /* dispatcher in the host = VST3->VST2 wrapper / false positive, not a standalone plugin */
        if(!gp2_disp(e,2,kn,sizeof kn) || !kn[0]){ double v=gp2_param(e,2); if(v>=0){ int ix=(int)(v*11+0.5); if(ix<0)ix=0; if(ix>11)ix=11; snprintf(kn,sizeof kn,"%s",KEYS_STD[ix]); } }   /* AT4/5: empty display -> map value */
        if(!gp2_disp(e,1,sn,sizeof sn) || !sn[0]){ double v=gp2_param(e,1); if(v>=0){ int ix=(int)(v*28+0.5); if(ix<0)ix=0; if(ix>28)ix=28; snprintf(sn,sizeof sn,"%s",SCALES_STD[ix]); } }
        { char cam[16]=""; camelot_of(kn,sn,cam,sizeof cam); char feel[128]=""; int fo=0; int ri,hi,ni,ai; v2_feel_find(e,&ri,&hi,&ni,&ai);
          if(ri>=0){ double v=gp2_param(e,ri); if(v>=0) fo+=snprintf(feel+fo,sizeof feel-fo,"  Rtn=%d%%",(int)(v*100+0.5)); }
          if(hi>=0){ double v=gp2_param(e,hi); if(v>=0) fo+=snprintf(feel+fo,sizeof feel-fo," Hum=%d%%",(int)(v*100+0.5)); }
          if(ni>=0){ double v=gp2_param(e,ni); if(v>=0) fo+=snprintf(feel+fo,sizeof feel-fo," NVb=%d%%",(int)(v*100+0.5)); }
          if(ai>=0){ double v=gp2_param(e,ai); if(v>=0){ int ix=(int)(v*4+0.5); if(ix<0)ix=0; if(ix>4)ix=4; fo+=snprintf(feel+fo,sizeof feel-fo," AT=%s",AUDIOTYPES_STD[ix]); } }
          char caps[16]; int ci=0; caps[ci++]='K'; caps[ci++]='S';
          if(ri>=0) caps[ci++]='R'; if(hi>=0) caps[ci++]='H'; if(ni>=0) caps[ci++]='V'; if(ai>=0) caps[ci++]='A';
          caps[ci]=0;
          if(!rec_append(buf,(int)sizeof buf,&off,"%s | %s  Key=%s  Scale=%s%s%s%s\x01%08X %s\n",
                        g_procLeaf,mod,kn[0]?kn:"?",sn[0]?sn:"?",cam[0]?"  Camelot=":"",cam,feel,
                        inst_id(e), caps)) full=1; } }
    /* Module names of the live VST2 instances, read once (see the use below). */
    char v2leaf[MAXI][96]; int nv2leaf=0;
    for(int i=0;i<g_nv2 && nv2leaf<MAXI;i++){ AEffect* e=g_v2[i]; if(!e) continue;
        mod_leaf((void*)e->dispatcher, v2leaf[nv2leaf], 96);
        if(v2leaf[nv2leaf][0]) nv2leaf++; }
    /* catch-mode modules (电音11) that are LOADED but no instance captured yet: list the module name so the
       user can SEE it is present. This only reads module filenames (pass-1) -- it never touches the PACE
       instance's memory, so it is safe. Captured ones are shown above with their live Key/Scale instead. */
    for(int i=0;i<g_nat && !full;i++){ if(!g_at[i].catchMode) continue;
        const char* bs=strrchr(g_at[i].path,'\\'); const char* leaf=bs?bs+1:g_at[i].path;
        int shown=capshell_known(leaf);   /* an instance from this shell is already under control */
        if(!shown){ char mlb[96]; for(int j=0;j<g_nv3;j++){ IEditController* c=g_v3[j]; if(!c) continue; if(modmap_get(c,mlb,sizeof mlb) && !_stricmp(mlb,leaf)){ shown=1; break; } } }
        /* ...and the VST2 side too. Only the VST3 set used to be consulted, so a module the host is
           using as a VST2 sat here as "loaded, not captured" for ever: its instances exist, they are
           listed above, but they are AEffects and no VST3 controller will ever come out of this
           module's factory. The T-Pain Effect runs into this because ONE dll exports both
           VSTPluginMain and GetPluginFactory, so it is registered as a VST3 catch module and then
           loaded as a VST2. (Waves never hit it: its VST2 shell has no GetPluginFactory, so pass 1
           drops it before it is ever registered.)
           The leaves were collected ONCE above rather than per module: e->dispatcher is read without
           a crash guard here, so doing it again for every catch module would multiply the number of
           raw reads into an AEffect the host may have freed since the last scan. */
        if(!shown) for(int j=0;j<nv2leaf;j++) if(!_stricmp(v2leaf[j],leaf)){ shown=1; break; }
        if(!shown && !rec_append(buf,(int)sizeof buf,&off,"%s | %s  [[PENDING]]\n",g_procLeaf,leaf)) full=1; }
    /* Only a record that really did not fit counts (1157). The loops used to stop at "fewer than 220 bytes
       left" as well -- dropping instances that would still have fitted -- and the log fired whenever the
       buffer was over ~97% used, saying instances were missing when every one had been listed. */
    { static int wasFull=0;
      if(rose(&wasFull, full)) LOG("write_status: status buffer full -> some instances are NOT listed"); }
    /* Nothing but the version marker means this process has no tuning plug-in -- not one instance,
       not even a shell waiting to be caught. Publishing an empty file for it used to be harmless
       because only racks were ever injected; since the controller also injects every plug-in host it
       finds and every bridge they spawn, that would litter the comm directory with files the
       controller then opens and parses on every poll, all of them saying nothing. An already
       published file is removed, so a host that unloads its last tuning plug-in stops being listed
       rather than lingering as an empty entry. */
    if(off <= hdrLen && !AT_XHH_MANAGED){            /* nothing was appended after the version marker */
        if(GetFileAttributesA(g_statusPath)!=INVALID_FILE_ATTRIBUTES){ DeleteFileA(g_statusPath); g_statusWritten[0]=0; }
        return; }
    if(strcmp(buf,g_statusWritten)!=0 || GetFileAttributesA(g_statusPath)==INVALID_FILE_ATTRIBUTES){
        if(publish_file(g_statusPath,buf)){ strncpy(g_statusWritten,buf,sizeof g_statusWritten-1); g_statusWritten[sizeof g_statusWritten-1]=0; } } }
/* discover ParamIDs + scale names for controller c into d (caller holds g_probing/setjmp) */
static void disc_fill(IEditController* c, V3Disc* d){
    memset(d,0,sizeof *d); d->ctrl=c;
    int pcount=c->vtbl->getParameterCount(c);
    { char ml[96]="";int haveModule=modmap_get(c,ml,sizeof ml);d->isWaves=waves_known(c)||(haveModule&&strstr_ci(ml,"waves"));d->isTPain=haveModule&&(strstr_ci(ml,"t-pain")||strstr_ci(ml,"tpain")); }   /* explicit flag; name check only as a backstop */
    ParamID speedCandidate=0;int haveSpeedCandidate=0;
    for(int pi=0; pi<pcount && !(d->haveS&&d->haveK&&d->haveMod&&d->haveRet&&d->haveHum&&d->haveNvb&&d->haveAudio); pi++){
        ParameterInfo info; if(c->vtbl->getParameterInfo(c,pi,&info)!=kResultOk) continue;
        char tnm[64]; u16toascii(info.title,tnm,sizeof tnm); trim(tnm);
        if(!_stricmp(tnm,"Speed")){speedCandidate=info.id;haveSpeedCandidate=1;}
        char low[64]; { int j; for(j=0;tnm[j]&&j<63;j++){ char ch=tnm[j]; low[j]=(ch>='A'&&ch<='Z')?(char)(ch+32):ch; } low[j]=0; }
        if(!d->haveS && !_stricmp(tnm,"Scale")){ d->scaleId=info.id; d->scaleSteps=info.stepCount; d->haveS=1; }
        else if(!d->haveK && !_stricmp(tnm,"Key")){ d->keyId=info.id; d->keySteps=info.stepCount; d->haveK=1; }
        /* iZotope (The T-Pain Effect) calls the key "Root note" and the scale plainly "Scale", so the
           Scale line above already matches but the key did not -- real log showed haveS=1 haveK=0 and
           a greyed-out Key box. The match is exact and the name is specific enough that it cannot
           shadow an Antares or Waves layout (Waves uses "Root" / "Scale Root"), so it stays ungated. */
        else if(!d->haveK && !_stricmp(tnm,"Root note")){ d->keyId=info.id; d->keySteps=info.stepCount; d->haveK=1;d->isTPain=1; }
        else if(!d->haveMod && !_stricmp(tnm,"Modern Scale")){ d->modId=info.id; d->modSteps=info.stepCount; d->haveMod=1; }
        else if(!d->haveRet && strstr(low,"retune") && !strstr(low,"graph")){ d->retId=info.id; d->haveRet=1; }
        else if(!d->haveHum && strstr(low,"humaniz")){ d->humId=info.id; d->haveHum=1; }
        else if(!d->haveNvb && (strstr(low,"natural vibrato")||strstr(low,"flex"))){ d->nvbId=info.id; d->haveNvb=1; }
        else if(!d->haveAudio && (strstr(low,"audio type")||strstr(low,"input type"))){ d->audioId=info.id; d->audioSteps=info.stepCount; d->haveAudio=1; }
        /* ---- Waves (WaveShell) param names (gated on isWaves so they never shadow an Antares layout) ---- */
        else if(d->isWaves && !d->haveK && (!_stricmp(tnm,"Root")||!_stricmp(tnm,"Scale Root"))){ d->keyId=info.id; d->keySteps=info.stepCount; d->haveK=1; }
        else if(d->isWaves && !d->haveS && !_stricmp(tnm,"Scale Type")){ d->scaleId=info.id; d->scaleSteps=info.stepCount; d->haveS=1; }
        else if(d->isWaves && !d->haveWSpeed && !_stricmp(tnm,"Speed")){ d->wSpeedId=info.id; d->haveWSpeed=1; }
        else if(d->isWaves && !d->haveWTrans && !_stricmp(tnm,"Note Transition")){ d->wTransId=info.id; d->haveWTrans=1; }
        else if(d->isWaves && !d->haveWVib && !_stricmp(tnm,"Vibrato Depth")){ d->wVibId=info.id; d->haveWVib=1; }
        else if(d->isWaves && !d->haveWRange && !_stricmp(tnm,"Range")){ d->wRangeId=info.id; d->haveWRange=1; }
    }
    if(d->isTPain&&!d->haveWSpeed&&haveSpeedCandidate){d->wSpeedId=speedCandidate;d->haveWSpeed=1;}
    d->isTuner = (d->haveK && d->haveS) ? 1 : 0;   /* a Root/Key + Scale pair identifies a tuning plugin */
    d->discDone = (pcount>0) ? 1 : 0;
    if(d->isWaves) LOG("disc(Waves): isTuner=%d | Root id=%u steps=%d | Scale id=%u steps=%d | Speed=%d Trans=%d Vib=%d Range=%d",
                       d->isTuner,d->keyId,d->keySteps,d->scaleId,d->scaleSteps,d->haveWSpeed,d->haveWTrans,d->haveWVib,d->haveWRange);
    /* disc_fill resolves only the param IDs + step counts. Scale display NAMES and per-scale normalized
       values are filled later by fill_scale_names() on the GENUINE (host-created, captured) controller,
       each getParamStringByValue() guarded by setjmp. Names are intentionally NOT queried during this
       initial pass -- on 电音11 they are read only after the controller is captured + confirmed, which is
       when it is PACE-safe. */
    LOG("disc: haveS=%d scaleId=%u steps=%d nscales=%d | haveK=%d keyId=%u keySteps=%d",
        d->haveS,d->scaleId,d->scaleSteps,d->nscales,d->haveK,d->keyId,d->keySteps);
    /* Dump the param titles so the log reveals the real names. For Auto-Tune this triggers only when an
       exact Scale/Key wasn't found; for a Waves controller we ALWAYS dump (once per controller) so the
       first real-machine agent.log pins the exact Root/Scale/Speed/Note-Transition/Vibrato/Range titles
       + IDs + step counts -- that's what locks in the v2 mapping. */
    if(!d->haveS || !d->haveK || d->isWaves){
        /* 60 was enough for Auto-Tune, but a plug-in that bundles a whole effects rack puts its
           pitch parameters well past that: iZotope's The T-Pain Effect carries ~645 effect
           parameter names, so a short dump would cut off exactly the Root note / pitch-enable
           entries this log is meant to reveal. The dump only runs when Scale/Key were NOT found,
           i.e. once per unknown controller, so a larger cap costs nothing in normal use. */
        int cap = d->isWaves ? 250 : 400; int lim=pcount<cap?pcount:cap;
        LOG("disc: param title dump (%s), first %d of %d:", d->isWaves?"Waves/WaveShell":"exact Scale/Key not found", lim, pcount);
        /* Flag anything that looks pitch-related first, so an unknown plug-in's log says in one
           line whether it exposes a root/key/scale control at all -- that is the single fact that
           decides whether this tool can drive it, and it is otherwise buried in a long dump. */
        if(!d->isWaves){
            int nh=0; char hits[512]=""; int ho=0;
            for(int pi=0;pi<lim;pi++){ ParameterInfo info; if(c->vtbl->getParameterInfo(c,pi,&info)!=kResultOk) continue;
                char tnm[64]; u16toascii(info.title,tnm,sizeof tnm);
                if(strstr_ci(tnm,"root")||strstr_ci(tnm,"key")||strstr_ci(tnm,"scale")||
                   strstr_ci(tnm,"pitch")||strstr_ci(tnm,"note")||strstr_ci(tnm,"transpos")||
                   strstr_ci(tnm,"snap")||strstr_ci(tnm,"hardness")){
                    nh++; if(ho<420) ho+=snprintf(hits+ho,(size_t)(sizeof hits-ho),"%s[%d id=%u steps=%d '%s']",ho?" ":"",pi,info.id,info.stepCount,tnm); } }
            LOG("disc: pitch-related params found: %d%s%s",nh,nh?" -> ":"",nh?hits:"(none -- this plug-in exposes no key/scale control to the host)");
        }
        for(int pi=0;pi<lim;pi++){ ParameterInfo info; if(c->vtbl->getParameterInfo(c,pi,&info)!=kResultOk) continue;
            char tnm[64]; u16toascii(info.title,tnm,sizeof tnm); LOG("  param[%d] id=%u steps=%d title='%s'",pi,info.id,info.stepCount,tnm); }
    }
}

/* VST3 candidate validation (setjmp contained): 1 if a real IEditController, else 0 */
static int validate_vst3_cand(IEditController* cand){
    volatile int result=0; void* qo=NULL; volatile LONG saved=g_probing;
    g_probing=1;
    if(setjmp(g_jb)==0){
        if(cand->vtbl->queryInterface(cand,IID_IEditController,&qo)==kResultOk && qo){
            ((GUnk*)qo)->vtbl->release(qo);
            int pc=cand->vtbl->getParameterCount(cand);
            if(pc>=1 && pc<=1000000) result=1;
        }
    } else { result=0; bad_add((void*)cand); }   /* faulted -> never probe this slot again */
    g_probing=saved; return result;   /* restore (scan mode when nested in scan_region) */
}
/* Does this cached entry still describe the object now living at that address?
   An AEffect pointer can be recycled by a different plug-in, and reusing the old entry would send
   Scale Root to whatever parameter index happens to sit there on the new one. */
static int v2w_cache_valid(const V2W* w, uint32_t uid, int np){
    return w && w->uid==uid && w->np==np; }
static V2W* v2w_discover(AEffect* e, const char* modleaf){
    /* An AEffect pointer can be RECYCLED: remove a Waves plug-in and add another, and the new object
       may land on the old address. A purely pointer-keyed cache would then hand back the previous
       plug-in's parameter indices and we would write Scale Root into whatever sits at that index on
       the new one. So the cache entry carries a fingerprint (uniqueID + numParams) and is rebuilt
       whenever it stops matching. */
    volatile uint32_t uid=0; volatile int np=0;
    { volatile LONG sv=g_probing; warn_nested_guard("v2w_discover"); g_probing=1;
      if(setjmp(g_jb)==0){ uid=(uint32_t)e->uniqueID; np=e->numParams; } else { uid=0; np=0; }
      g_probing=sv; }
    V2W* w=v2w_find(e);
    if(w){
        if(v2w_cache_valid(w,uid,(int)np)){ w->seen=GetTickCount(); return w; }   /* same object */
        LOG("waves VST2: the object at %p is not the one we catalogued (uid %08X->%08X, params %d->%d)"
            " -> discarding the cached layout and re-reading it",(void*)e,w->uid,(unsigned)uid,w->np,(int)np);
    } else {
        /* reclaim a slot that has not been seen for a while before giving up */
        if(g_nV2W>=MAXI){ DWORD now=GetTickCount(); int victim=-1;
            for(int i=0;i<g_nV2W;i++) if(now-g_v2w[i].seen > 60000){ victim=i; break; }
            if(victim<0) return NULL;
            w=&g_v2w[victim]; }
        else w=&g_v2w[g_nV2W++];
    }
    memset(w,0,sizeof *w); w->e=e; w->uid=uid; w->np=(int)np; w->seen=GetTickCount();
    /* set BEFORE the name sweep below: it decides which parameter names are looked for */
    w->kind = (modleaf && strstr_ci(modleaf,"t-pain")) ? V2K_TPAIN : V2K_WAVES;
    w->rootIdx=w->scaleIdx=w->speedIdx=w->transIdx=w->vibIdx=-1;
    /* Never hand a struct field straight to the plug-in: it decides how much it writes, and an
       overrun here would land on the parameter indices stored right after this field -- i.e. on the
       very values that decide which parameter a key change is written to. Read into a generous
       local (as every other dispatcher call here already does) and copy in. */
    { char nm[256]=""; volatile LONG sv=g_probing; g_probing=1;
      if(setjmp(g_jb)==0){ e->dispatcher(e,effGetEffectName,0,0,nm,0.f); nm[sizeof nm-1]=0; } else nm[0]=0;
      g_probing=sv; trim(nm); snprintf(w->name,sizeof w->name,"%s",nm); }
    if(!w->name[0]) snprintf(w->name,sizeof w->name,"%s",modleaf);
    int lim=(np>0&&np<200)?(int)np:0;
    for(int k=0;k<lim;k++){ char pn[128]="";
        if(!v2_pname(e,k,pn,sizeof pn)) continue; trim(pn);
        if(w->kind==V2K_TPAIN){
            /* The VST2 spec gives effGetParamName only 8 characters (kVstMaxParamStrLen), and plug-ins
               differ on whether they truncate: "Root note" is 9, so it can arrive whole or as "Root not".
               Matching the first 8 characters covers both without loosening anything that matters --
               "Scale" is compared exactly so that this plug-in's "Level Meter Scale Type" (which is what
               a substring match on "scale" would otherwise grab first) can never win. */
            if(!_stricmp(pn,"Scale"))                 w->scaleIdx=k;
            else if(!_strnicmp(pn,"Root not",8))      w->rootIdx=k;
            /* "Hardness" (the GUI's STYLE slider) is deliberately NOT bound to the Retune slider: it
               runs the opposite way round (Auto-Tune's retune 0 = hardest, T-Pain's Hardness 0 = soft),
               and the VST3 path does not bind it either -- one plug-in must not behave differently in
               one format than the other. Key and Scale are what this tool is for; the feel sliders stay
               greyed out for T-Pain in both formats. */
            continue; }
        if(!_stricmp(pn,"Scale Root"))      w->rootIdx=k;
        else if(!_stricmp(pn,"Scale Type")) w->scaleIdx=k;
        else if(!_stricmp(pn,"Speed"))      w->speedIdx=k;
        else if(!_stricmp(pn,"Note Transition")) w->transIdx=k;
        else if(!_stricmp(pn,"Vibrato Depth"))   w->vibIdx=k; }
    w->isTuner = (w->rootIdx>=0 && w->scaleIdx>=0);
    LOG("%s VST2 '%s' [%s]: Root=%d Scale=%d Speed=%d Trans=%d Vib=%d -> %s",
        w->kind==V2K_TPAIN?"t-pain":"waves",
        w->name,modleaf,w->rootIdx,w->scaleIdx,w->speedIdx,w->transIdx,w->vibIdx,
        w->isTuner?"tuner, taking control":"not a tuner, ignored");
    return w; }
static int v2set(AEffect* e,int idx,float value){
    V2W* policyW=v2w_find(e);
    const char* family=policyW?(policyW->kind==V2K_TPAIN?"tpain":"waves"):"antares";
    if(!agent_write_allowed((void*)e->dispatcher,family))return 0;
    e->setParameter(e,idx,value);return 1;
}
/* set one discrete Waves parameter and CHECK it: returns 1 if the display came back as expected */
static int v2w_set_checked(AEffect* e, int idx, int pos, int npos, const char* wantName, const char* what){
    if(idx<0 || npos<2 || pos<0 || pos>=npos) return 0;
    float v=(float)pos/(float)(npos-1);
    volatile LONG sv=g_probing; g_probing=1;
    if(setjmp(g_jb)==0){if(!v2set(e,idx,v)){g_probing=sv;return 0;}}
    g_probing=sv;
    char got[128]=""; gp2_disp(e,idx,got,sizeof got); trim(got);
    if(!got[0]){
        /* No display text (Auto-Tune 4/5 and The T-Pain Effect behave this way), which used to mean the
           write went completely unchecked. Read the value back instead: if the plug-in quantised it to
           a different position, this catches it just as well as comparing names would. */
        double rv=gp2_param(e,idx);
        if(rv<0) return 1;                       /* cannot read either -> nothing to check against */
        int rp=(int)(rv*(double)(npos-1)+0.5);
        if(rp==pos) return 1;
        LOG("VST2 %s: wrote position %d/%d for '%s' but the plug-in reads back position %d "
            "(value %.4f) -- the borrowed position list does not match this build; please report this line",
            what,pos,npos,wantName,rp,rv);
        return 0; }
    char a[64],b[64]; norm(got,a,sizeof a); norm(wantName,b,sizeof b);
    if(scale_same(a,b)) return 1;
    LOG("VST2 %s: asked for '%s' (position %d/%d) but the plug-in now reads '%s' -- the borrowed "
        "position list does not match this build; please report this line",what,wantName,pos,npos,got);
    return 0; }
static void v2w_apply(AEffect* e, V2W* w, int keySemi, const char* scaleName){
    /* Same mechanism for both, only the borrowed position list differs. */
    int tp = (w->kind==V2K_TPAIN);
    const char* const* ROOTS  = tp ? TPAIN_ROOTS  : WAVES_ROOTS;
    int                NROOT  = tp ? TPAIN_NROOT  : WAVES_NROOT;
    const char* const* SCALES = tp ? TPAIN_SCALES : WAVES_SCALES;
    int                NSCALE = tp ? TPAIN_NSCALE : WAVES_NSCALE;
    const char* WHO = tp ? "t-pain" : "waves";
    if(keySemi>=0 && w->rootIdx>=0){
        int idx=-1;
        for(int i=0;i<NROOT;i++) if(key_to_pc(ROOTS[i])==keySemi){ idx=i; break; }
        if(idx>=0) v2w_set_checked(e,w->rootIdx,idx,NROOT,ROOTS[idx],tp?"Root note":"Scale Root"); }
    if(scaleName && scaleName[0] && w->scaleIdx>=0){
        char want[64]; norm(scaleName,want,sizeof want); int idx=-1;
        for(int i=0;i<NSCALE;i++){ char a[64]; norm(SCALES[i],a,sizeof a); if(scale_same(a,want)){ idx=i; break; } }
        if(idx>=0) v2w_set_checked(e,w->scaleIdx,idx,NSCALE,SCALES[idx],tp?"Scale":"Scale Type");
        else LOG("%s VST2: scale '%s' is not in this plug-in's list -> not written",WHO,scaleName); }
    { volatile LONG sv=g_probing; g_probing=1;
      if(setjmp(g_jb)==0){
          if((g_fSpeed>=0||g_fRet>=0) && w->speedIdx>=0) v2set(e,w->speedIdx,(float)(g_fSpeed>=0?g_fSpeed:g_fRet));
          if(g_fHum>=0 && w->transIdx>=0) v2set(e,w->transIdx,(float)g_fHum);
          if(g_fNvb>=0 && w->vibIdx  >=0) v2set(e,w->vibIdx,  (float)g_fNvb); }
      g_probing=sv; } }
/* VST2 candidate validation+ID (setjmp contained): returns scale table if Auto-Tune AEffect (sets uid/np), else NULL */
static const char* const* validate_vst2_cand(AEffect* e, uint32_t* out_uid, int* out_np){
    volatile int ok=0; volatile uint32_t uid=0; volatile int npar=0; volatile LONG saved=g_probing;
    g_probing=1;
    if(setjmp(g_jb)==0){
        void* sp=(void*)e->setParameter; void* dp=(void*)e->dispatcher;
        int np=e->numParams, ni=e->numInputs, no=e->numOutputs;
        if(sp&&dp&&ptr_in_exec(sp)&&ptr_in_exec(dp)&&np>0&&np<8000&&ni>=0&&ni<=16&&no>=0&&no<=16){ uid=(uint32_t)e->uniqueID; npar=np; ok=1; }
    } else { ok=0; bad_add((void*)e); }
    if(!ok){ g_probing=saved; return NULL; }
    *out_uid=uid; *out_np=npar;
    if(uid==0x41547871u || uid==0x41547845u){ g_probing=saved; return SCALES_STD; }
    { volatile int isAT=0; char nm[128]="";
      g_probing=1;
      if(setjmp(g_jb)==0){ e->dispatcher(e,effGetEffectName,0,0,nm,0.f); nm[127]=0; if(strstr(nm,"Auto-Tune")||strstr(nm,"AutoTune")) isAT=1; } else isAT=0;
      g_probing=saved;
      return isAT ? SCALES_STD : NULL; }
}
/* discover one controller's scale/key info (setjmp contained; loop var won't cross setjmp) */
static void discover_one(IEditController* c){
    if(!c || disc_find(c)) return;
    V3Disc* d=&g_disc[g_discHead]; g_discHead=(g_discHead+1)&(NDISC-1);
    volatile LONG sv=g_probing; warn_nested_guard("discover_one"); g_probing=1;
    if(setjmp(g_jb)==0){ disc_fill(c,d); } else { d->ctrl=NULL; } g_probing=sv;
}

/* --- guarded single reads on the GENUINE controller (each sets up its OWN g_jb; never nested) --- */
static int gp_str(IEditController* c, ParamID id, double val, char* out, int outsz){
    out[0]=0; int ok=0; volatile LONG sv=g_probing; warn_nested_guard("gp_str"); g_probing=1;
    if(setjmp(g_jb)==0){ String128 s; if(c->vtbl->getParamStringByValue(c,id,val,s)==kResultOk){ u16toascii(s,out,outsz); trim(out); ok=1; } } else ok=0;
    g_probing=sv; return ok; }
/* fill scale names from the plugin's OWN enumeration; fall back to SCALES_STD where a query fails.
   svals[i] = normalized value that selects scale i (i/stepCount per VST3 convention). */
static void fill_scale_names(IEditController* c, V3Disc* d){
    if(!d || !d->haveS) return;
    int steps = d->scaleSteps>0 ? d->scaleSteps : 28; int n=steps+1; if(n>96){ LOG("fill_scale_names: plug-in reports %d scales, table holds 96 -> the rest are NOT selectable",n); n=96; }
    char probe[64]; int probeok=gp_str(c,d->scaleId,0.0,probe,sizeof probe);   /* one safe probe before the loop */
    if(!probeok){ LOG("fill_scale_names: getParamStringByValue unavailable -> standard scale list");
        for(int i=0;i<n;i++){ snprintf(d->sdisp[i],48,"%s", i<29?SCALES_STD[i]:"?"); norm(d->sdisp[i],d->snorm[i],48); d->svals[i]=(double)i/steps; }
        d->nscales=n; return; }
    int real=0;
    for(int i=0;i<n;i++){ double val=(double)i/steps; char nm[64];
        int ok=gp_str(c,d->scaleId,val,nm,sizeof nm);
        if(ok && nm[0]) { snprintf(d->sdisp[i],48,"%s",nm); real++; }
        else snprintf(d->sdisp[i],48,"%s", i<29?SCALES_STD[i]:"?");
        norm(d->sdisp[i],d->snorm[i],48); d->svals[i]=val;
        LOG("  scale[%d] norm=%.4f -> '%s'%s",i,val,d->sdisp[i],ok?"":" (fallback)"); }
    d->nscales=n;
    LOG("fill_scale_names: %d/%d names read from plugin (scaleId=%u steps=%d)",real,n,d->scaleId,steps);
    if(d->haveMod){                                /* enumerate "Modern Scale" (Pro 11 active scale) */
        int ms=d->modSteps>0?d->modSteps:14; int mn=ms+1; if(mn>48){ LOG("modern scale: plug-in reports %d, table holds 48 -> the rest are NOT selectable",mn); mn=48; }
        char mp[64]; int mpok=gp_str(c,d->modId,0.0,mp,sizeof mp);
        if(mpok){ int mr=0;
            for(int i=0;i<mn;i++){ double v=(double)i/ms; char nm[64];
                if(gp_str(c,d->modId,v,nm,sizeof nm)&&nm[0]){ snprintf(d->msdisp[i],48,"%s",nm); mr++; } else snprintf(d->msdisp[i],48,"ModScale %d",i);
                norm(d->msdisp[i],d->msnorm[i],48); d->msvals[i]=v;
                LOG("  modscale[%d] norm=%.4f -> '%s'",i,v,d->msdisp[i]); }
            d->modn=mn; LOG("modern scale: %d/%d names (modId=%u steps=%d)",mr,mn,d->modId,ms); }
        else LOG("modern scale: getParamStringByValue unavailable (modId=%u)",d->modId);
    } }
/* case-insensitive substring (ASCII) */
static int strstr_ci(const char* hay, const char* needle){ if(!hay||!needle) return 0;
    char h[256], n[128]; int i=0; for(;hay[i]&&i<255;i++) h[i]=(char)tolower((unsigned char)hay[i]); h[i]=0;
    int j=0; for(;needle[j]&&j<127;j++) n[j]=(char)tolower((unsigned char)needle[j]); n[j]=0;
    return strstr(h,n)!=NULL; }
/* Waves "Root": enumerate the note shown at each step and remember its normalized value, so we can set
   the key by matching PITCH CLASS (key_to_pc) rather than assuming the enum is in semitone order.
   Mirrors fill_scale_names; each getParamStringByValue is crash-guarded inside gp_str. */
static void fill_key_names(IEditController* c, V3Disc* d){
    if(!d || !d->haveK) return;
    int steps = d->keySteps>0 ? d->keySteps : 11; int n=steps+1; if(n>24){ LOG("fill_key_names: plug-in reports %d roots, table holds 24 -> the rest are NOT selectable",n); n=24; }   /* stepCount=16 -> 17 positions; must not clip the last one (B) */
    char probe[48]; int ok=gp_str(c,d->keyId,0.0,probe,sizeof probe);
    if(!ok){ d->nkeys=0; LOG("fill_key_names: getParamStringByValue unavailable (keyId=%u) -> semitone fallback",d->keyId); return; }
    int real=0;
    for(int i=0;i<n;i++){ double v=(double)i/steps; char nm[48]="";
        if(gp_str(c,d->keyId,v,nm,sizeof nm)&&nm[0]){ snprintf(d->kdisp[i],48,"%s",nm); real++; } else snprintf(d->kdisp[i],48,"?");
        d->kvals[i]=v; LOG("  root[%d] norm=%.4f -> '%s' pc=%d",i,v,d->kdisp[i],key_to_pc(d->kdisp[i])); }
    d->nkeys=n; LOG("fill_key_names: %d/%d root names read (keyId=%u steps=%d)",real,n,d->keyId,steps);
}

static unsigned ctrl_refcount(void* c){        /* current count, 0 = probe faulted. WORKER THREAD ONLY */
    volatile unsigned n=0; volatile LONG sv=g_probing; warn_nested_guard("ctrl_refcount"); g_probing=1;
    if(setjmp(g_jb)==0){ n=((GUnk*)c)->vtbl->addRef(c); ((GUnk*)c)->vtbl->release(c); } else n=0;
    g_probing=sv; return n; }
/* Pure decision for drop_dead_instances, kept separate so it can be exercised directly.
   n is what addRef() returned (count INCLUDING the temporary probe reference), 0 = probe faulted.
   *rel: -1 not yet judged, 0 counts unusable (never auto-drop), 1 counts usable.
   The first reading decides usability: while the plug-in is loaded the host holds a reference
   besides ours, so a usable count reads >= 3. If it does not -- e.g. a controller only we hold a
   reference to -- the counts cannot distinguish "alive" from "released", so that instance is never
   auto-dropped and behaves exactly as before. Returns 1 to drop. */
static int liveness_decide(int* rel, int* strike, unsigned n){
    if(n==0) return 1;                       /* calling into it faulted: it is gone */
    if(*rel < 0){ *rel = (n>=3) ? 1 : 0; *strike=0; return 0; }
    if(*rel != 1) return 0;                  /* counts unusable -> never auto-drop */
    if(n<=2){ if(++(*strike) >= 3) return 1; return 0; }
    *strike = 0; return 0; }
/* A Waves instance the host created and destroyed before we ever looked at it: a probe. Hosts do
   this before inserting a plug-in -- LiveProfessor 2 creates and destroys two instances of the
   shell's class before the real one, at the SAME component address, so the first is certainly gone.
   By the first liveness reading only our own reference is left (addRef->2). On that reading alone
   liveness_decide() cannot tell "released" from "a controller only we hold a reference to", and it
   rightly refuses to guess (t_life scenario 4 exists to protect Waves). So those probes were kept
   for good: listed as instances, written to on every command -- with WRONG values, because a
   destroyed instance no longer names its roots and scales, so the root fell back to semitones and
   the scale to the Antares list -- and each one held a slot of the 48-entry table.
   For Waves a second, independent signal settles it: across nine real logs from Studio One,
   Samplitude and LiveProfessor, every live Waves instance was given an IComponentHandler by its
   host, and not one of the probes ever was. So: Waves AND no handler AND only our reference on the
   first reading => a probe the host has already thrown away. Either signal alone keeps a live
   instance: one with odd reference counting still has its handler, and one whose handler arrives
   late still reads >= 3. Never applied to anything but Waves -- Antares has no handler by design.
   Returns 1 to drop. */
static int waves_probe_decide(int isWaves, int hasHandler, int rel, unsigned n){
    if(!isWaves || hasHandler) return 0;
    if(rel >= 0) return 0;                   /* first reading only; after that the normal rules apply */
    return (n>=1 && n<=2) ? 1 : 0; }         /* n==0 (probe faulted) is liveness_decide's to drop */
static int ui_instance_running(const void* controller);
static void drop_dead_instances(){
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_ncaught;){
        void* c=g_caught[i]; int drop=0; const char* why="";
        /* A host-thread parameter call can outlive the worker's wait budget.
           Keep the capture reference and all metadata until that RUN slot is
           finished; releasing our final reference here would invalidate the
           controller still used by the host-thread transaction. */
        if(c&&ui_instance_running(c)){i++;continue;}
        if(!c){ drop=1; why="null"; }
        else {
            V3Disc* dd=disc_find((IEditController*)c);
            /* A host plug-in rescan instantiates EVERY class in the shell -- 140 of them for
               WaveShell -- and we hold a reference on each one we capture, so the 48-slot table can
               fill up and real plug-ins created afterwards can no longer be captured. Once the
               worker has positively established that a Waves instance exposes no Scale Root /
               Scale Type it is of no use to us: let it go and free the slot. Deliberately limited to
               Waves -- an Auto-Tune controller whose titles were not found still has the AT8.1
               rescue path, so dropping those would throw away a capability. */
            if(dd && dd->isWaves && dd->discDone && !dd->isTuner){ drop=1; why="not a tuner"; }
            else { unsigned n=ctrl_refcount(c);
                   int before=g_caughtRel[i];
                   if(waves_probe_decide(waves_known(c), handler_of(c)!=NULL, before, n)){
                       drop=1; why="a Waves probe instance: the host never gave it a handler and holds no reference"; }
                   else{
                       drop=liveness_decide(&g_caughtRel[i],&g_caughtStrike[i],n);
                       why = (n==0) ? "probe faulted" : "host released it";
                       if(before<0 && g_caughtRel[i]==0)
                           LOG("instance %p: reference counts look unusable (addRef->%u) -> never auto-dropped",c,n); } } }
        if(drop){
            LOG("dropping instance %p (%s)",c,why);
            if(c){ volatile LONG sv=g_probing; g_probing=1; if(setjmp(g_jb)==0) ((GUnk*)c)->vtbl->release(c); g_probing=sv; }
            modmap_del(c); waves_del(c); chmap_del(c);
            for(int k=0;k<g_nv3;k++) if(g_v3[k]==(IEditController*)c) g_v3[k]=NULL;
            for(int k=0;k<NDISC;k++) if(g_disc[k].ctrl==c) g_disc[k].ctrl=NULL;
            for(int k=i;k<g_ncaught-1;k++){ g_caught[k]=g_caught[k+1]; g_caughtRel[k]=g_caughtRel[k+1]; g_caughtStrike[k]=g_caughtStrike[k+1]; }
            g_ncaught--;
        } else i++; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); }
/* Merge the factory-hook-caught controllers into the VST3 set (they bypass the heap scan). A Waves
   controller is taken only once its host has given it an IComponentHandler: without one it is either
   a probe the host is throwing away (dropped by waves_probe_decide on the next pass) or an instance
   being torn down (the host clears the handler first). Writing to either is useless -- a Waves write
   needs the host path -- and to the probe it is harmful: it is a destroyed object, and it was being
   sent wrong values. Antares and everything else is merged exactly as before. */
static void merge_caught_into_v3(){
    if(g_catchCsInit) EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_ncaught;i++){ void* c=g_caught[i];
        if(!c || v3_known((IEditController*)c) || g_nv3>=MAXI || !agent_policy_address(((IEditController*)c)->vtbl)) continue;
        if(waves_known(c) && !handler_of(c)) continue;
        g_v3[g_nv3++]=(IEditController*)c; }
    if(g_catchCsInit) LeaveCriticalSection(&g_catchCs); }
static int vt_idx(void* v){ if(!v) return -1; for(int i=0;i<g_nat;i++) if(g_at[i].vt && g_at[i].vt==v) return i; return -1; }
static int g_pendLast=-1;
/* Scan ONE committed private region for VST3 controllers (vtable match) and VST2 AEffects (magic).
   Raw reads run under g_probing=2 + setjmp(g_scanjb): a fault (region freed mid-scan, etc.) just
   abandons the rest of this region. A VST3 candidate is validated (queryInterface) only on its SECOND
   consecutive sighting, and right before that probe we record the candidate's MODULE in the pending
   file: if the probe takes the host down (a PACE-protected plugin killing the process when probed
   with a pointer it doesn't own), the next launch reads the pending file and permanently blacklists
   that module -- so a hostile plugin disables itself after at most one crash, others keep working. */
static void scan_region(unsigned char* base, size_t sz, int justGotVtable, unsigned v2magic){
    g_probing=2;
    if(setjmp(g_scanjb)==0){
        for(size_t off=0; off+sizeof(void*)<=sz; off+=sizeof(void*)){
            void* val=*(void**)(base+off);
            /* ---- VST3 controller match ---- */
            if(g_nat>0 && !justGotVtable && ((uintptr_t)(base+off)&0x7)==0 && vt_known(val)){
                IEditController* cand=(IEditController*)(base+off);
                if(!self_known((void*)cand) && !ignore_known((void*)cand) && !bad_known((void*)cand) && !v3_known(cand)){
                    if(g_ncur<MAXI) g_curCand[g_ncur++]=(void*)cand;        /* record sighting (no deref) */
                    if(was_prev((void*)cand)){                               /* validate only on 2nd sighting */
                        int mi=vt_idx(val);
                        if(mi<0||!agent_policy_module(g_at[mi].mod))continue;
                        if(mi>=0 && mi!=g_pendLast){ cb_write_pending(g_at[mi].path); g_pendLast=mi; }  /* attribute a possible PACE kill */
                        if(validate_vst3_cand(cand) && g_nv3<MAXI){ if(mi>=0){ const char* bs=strrchr(g_at[mi].path,'\\'); modmap_set((void*)cand, bs?bs+1:g_at[mi].path); } g_v3[g_nv3++]=cand; }
                    }
                }
                continue;
            }
            /* ---- VST2 AEffect match (magic in the int32 at this slot) ---- */
            if(*(uint32_t*)(base+off)==v2magic){
                AEffect* e=(AEffect*)(base+off);
                if(!agent_policy_address((void*)e->dispatcher))continue;
                if(!v2_known(e) && !bad_known((void*)e)){
                    { char ml0[96]; mod_leaf((void*)e->dispatcher, ml0, sizeof ml0);
                      /* Both of these are found by PARAMETER NAME rather than by uniqueID, which is why
                         they share this branch: validate_vst2_cand() below only knows Auto-Tune's two
                         ids and its effect-name test, so The T-Pain Effect fell through it and the log
                         read "VST2 x0" even though its AEffect was sitting right there in the scan. */
                      if(strstr_ci(ml0,"waveshell") || strstr_ci(ml0,"t-pain")){
                          log_arm();
                          V2W* w=v2w_discover(e,ml0);
                          if(w && w->isTuner && g_nv2<MAXI){
                              g_v2[g_nv2]=e; g_v2tbl[g_nv2]=NULL;   /* NULL table marks a Waves instance, not Antares */
                              /* record the real parameter count: it is the second half of the
                                 fingerprint v2w_discover() uses to notice a recycled AEffect, and
                                 printing 0 in the instance dump hid that information. */
                              g_v2uid[g_nv2]=(uint32_t)e->uniqueID; g_v2np[g_nv2]=w->np; g_nv2++;
                              if(!w->announced){ w->announced=1;
                                  LOG("vst2 accepted (%s): uid=0x%08X module=%s",
                                      w->kind==V2K_TPAIN?"t-pain":"Waves",(unsigned)e->uniqueID,ml0); } }
                          continue; } }
                    uint32_t uid=0; int npar=0;
                    const char* const* tbl=validate_vst2_cand(e,&uid,&npar);
                    if(tbl && g_nv2<MAXI){
                        char ml[96]; mod_leaf((void*)e->dispatcher, ml, sizeof ml);
                        char hp[MAX_PATH]=""; GetModuleFileNameA(NULL,hp,MAX_PATH); const char* hb=strrchr(hp,'\\'); hb=hb?hb+1:hp;
                        if(!_stricmp(ml,hb)) LOG("vst2 skipped (dispatcher in host = VST3->VST2 wrapper / false positive; unknown layout, not controlled): uid=0x%08x module=%s",uid,ml);
                        else { g_v2[g_nv2]=e; g_v2tbl[g_nv2]=tbl; g_v2uid[g_nv2]=uid; g_v2np[g_nv2]=npar; g_nv2++;
                               LOG("vst2 accepted: uid=0x%08x numParams=%d module=%s",uid,npar,ml); } }
                }
            }
        }
    } /* else: a read faulted -> abandon the rest of this region */
    g_probing=0;
}
/* one combined scan over private heap */
static void scan_all(){
    if(!g_veh) g_veh=AddVectoredExceptionHandler(1,veh);
    int justGotVtable=0;
    { HMODULE m[4096]; DWORD need=0;
      if(EnumProcessModulesEx(GetCurrentProcess(),m,sizeof m,&need,0x03)){ int c=(int)(need/sizeof(HMODULE)); int cap=(int)(sizeof m/sizeof(HMODULE)); if(c>cap) c=cap;
        /* pass 1: AT-ness check for NEW modules only (reads version info at most once per module) */
        for(int i=0;i<c;i++){ HMODULE mod=m[i];
            if(mod_checked(mod)||!GetProcAddress(mod,"GetPluginFactory")||!agent_policy_module(mod)) continue;
            char p[MAX_PATH]=""; if(!GetModuleFileNameExA(GetCurrentProcess(),mod,p,MAX_PATH)) continue;
            if(g_nChecked<2048) g_checkedMod[g_nChecked++]=mod;      /* mark AT-checked */
            if(!GetProcAddress(mod,"GetPluginFactory")) continue;    /* not a VST3 */
            char low[MAX_PATH]; int k=0; for(;p[k]&&k<MAX_PATH-1;k++) low[k]=(char)tolower((unsigned char)p[k]); low[k]=0;
            /* A catch-list module (电音11, WaveShell) is identified by FILENAME and is handled purely by the
               factory hook, so it must bypass the Antares-name/version test entirely. Previously the AT-ness
               gate ran first, so a shell that was ALREADY LOADED when the agent injected (the common case:
               DAW already running, or project opened before the controller) was never registered and its
               factory was never hooked -- only the load-notification path could catch it. */
            int catchM=is_catch_path(low);
            if(!catchM && !path_is_antares(p)) continue;   /* not Auto-Tune, not a catch module */
            /* skip.txt is the user's explicit opt-out and is honoured for catch modules too: putting
               "waveshell" in it turns off all Waves handling without needing a different build. Since 1155
               that is also true of the load-notification path (dll_notify), which used to ignore it. */
            if(mod_skiplisted_low(low)){ LOG("skipping user skip.txt module: %s",p); continue; }
            /* A module that once took the host down while being probed is PROMOTED to catch mode
               rather than skipped: catch mode is precisely the path that never probes, so the
               plug-in keeps working instead of vanishing from the list. */
            int antByContent = !catchM;   /* a non-catch module only gets here by passing the Antares test */
            if(!catchM && mod_probe_unsafe(p)){
                catchM=1;
                log_arm(); LOG("module did not survive probing before -> using the factory hook for it "
                               "from now on (no probing, no heap scan): %s",p); }
            /* 1149: an Antares module is never probed, whatever its file is called. The name pattern
               above covers the usual names from the moment of loading; this covers a renamed one
               (a repack called 电音9.vst3, say), identified by content, from the next scan on. */
            if(!catchM){
                catchM=1;
                log_arm(); LOG("Antares module (PACE-protected) -> factory hook only, never probed: %s",p); }
            if(g_nat<MAXVT){ g_at[g_nat].mod=mod; g_at[g_nat].vt=NULL; g_at[g_nat].self=NULL; g_at[g_nat].tries=0; g_at[g_nat].hooked=0; g_at[g_nat].pinned=0; g_at[g_nat].seen=GetTickCount(); snprintf(g_at[g_nat].path,MAX_PATH,"%s",p);
                             g_at[g_nat].catchMode=catchM; g_at[g_nat].antMod = antByContent ? 1 : -1;   /* identified by content -> known Antares; by name -> decided lazily */
                             log_arm(); LOG("vst3 Auto-Tune module found: %s%s",p,g_at[g_nat].catchMode?"  [catch-mode: factory hook, no heap scan]":"");
                             g_nat++; }
        }
      }
    }
    /* pass 2: acquire the class vtable for each AT module (retry up to 20x if a transient failure) */
    for(int i=0;i<g_nat;i++){
        if(!agent_policy_module(g_at[i].mod))continue;
        if(g_at[i].catchMode){                         /* 电音11 / WaveShell: PIN the module, then hook the factory */
            if(!g_at[i].pinned){ g_at[i].pinned=1;
                HMODULE pinned=NULL; GetModuleHandleExA(0x1 /*PIN*/ | 0x4 /*FROM_ADDRESS*/, (LPCSTR)g_at[i].mod, &pinned);  /* pin by module base addr; safe on already-loaded module (no fresh load/DllMain/PACE init) */
                LOG("pinned catch-mode module (won't unload on remove): %s -> %p",g_at[i].path,(void*)pinned); }
            /* Hook the factory, and KEEP RETRYING until the patch is confirmed. A shell can refuse to
               hand out its factory on the first ask -- WaveShell 16.7 returns none until the host has
               called InitDll() -- and the old code hooked exactly once ("if(!tries)"), so that single
               early miss left the factory unhooked for the life of the process. Every instance the host
               then created went through the UNhooked createInstance, nothing was ever CAUGHT, and the
               list showed "loaded, not captured" forever: re-adding the plug-in could not help, because
               the module is pinned (no reload -> no load notification) and this branch never ran again.
               A failed ask costs nothing (factory_once no longer caches the NULL and a NULL ask does not
               build the shell's class table), so retrying is both safe and the only way back.
               The 2500ms settle delay is the same one pass-2 uses below: it lets the HOST make its own
               GetPluginFactory() call first, so ours is never the call that builds the class table. */
            /* If the EAT hook is armed on this shell, the factory arrives through the HOST's own
               GetPluginFactory() call. Asking for it ourselves would both race that call and add a
               second successful one, so we simply wait. Only if the host has still not called it
               after 15s (it never loaded the shell to use it, or it resolved the entry point some
               other way) do we fall back to the late hook. */
            int eix=-1; for(int k=0;k<g_nEat;k++) if(g_eat[k].mod==g_at[i].mod){ eix=k; break; }
            int eatArmed = (eix>=0 && g_eat[eix].slot);
            if(eatArmed && !g_eat[eix].fired && GetTickCount()-g_at[i].seen < 15000) continue;
            if(!g_at[i].hooked && g_at[i].tries<40 && GetTickCount()-g_at[i].seen >= 2500){
                g_at[i].tries++;
                if(!eatArmed || !g_eat[eix].fired) hook_factory(g_at[i].mod,g_at[i].path);
                /* confirm against the hook table rather than trusting the call: hook_factory() returns
                   void and bails out silently on a not-ready factory or a fault. */
                IPluginFactory* f=factory_once(g_at[i].mod);
                if(f){ void* fvt=(void*)f->vtbl;
                    for(int h=0;h<g_nHooked;h++) if(g_hookedVtbl[h]==fvt){
                        g_at[i].hooked=1; log_arm();
                        if(eatArmed && g_eat[eix].fired)
                            LOG("catch-mode factory hooked via the host's own GetPluginFactory (EAT hook): %s"
                                "  -- instances are caught from the first one, no re-add needed",g_at[i].path);
                        else {
                            LOG("catch-mode factory CONFIRMED hooked after %d tr%s: %s",g_at[i].tries,g_at[i].tries==1?"y":"ies",g_at[i].path);
                            LOG(">>> now REMOVE and RE-ADD the plug-in once (or reopen the project) to capture its instances"); }
                        break; } }
                if(!g_at[i].hooked && g_at[i].tries==40)
                    LOG("catch-mode factory still not hooked after %d tries: %s -- the shell never handed out a factory; please report this log",g_at[i].tries,g_at[i].path);
            }
            /* NOTHING else is called on a catch module. GetPluginFactory() must SUCCEED at most ONCE per
               module: a second successful call makes WaveShell re-scan and append to its own class list
               (140 -> 280 classes observed), after which the shell fails to create any instance
               ("Failed to create VST effect"). factory_once() caches the first success and hands that
               same pointer back, so the retries above can never produce a second successful call. */
            continue;
        }
        if(g_at[i].vt || g_at[i].tries>=20) continue;
        if(GetTickCount()-g_at[i].seen < 2500) continue;   /* let the host finish loading/initialising this module before we instantiate anything in it */
        g_at[i].tries++;
        g_selfCreateTid=(LONG)GetCurrentThreadId(); void* self=NULL; void* vt=get_v3_vtable(g_at[i].mod,&self); g_selfCreateTid=0;
        if(vt){ g_at[i].vt=vt; g_at[i].self=self; justGotVtable=1; LOG("vst3 module #%d vtable acquired: %p (try %d)",i+1,vt,g_at[i].tries); }
        else if(g_at[i].tries>=20) LOG("vst3 module #%d: gave up acquiring vtable after %d tries",i+1,g_at[i].tries);
    }
    g_nv2=0; g_nv3=0; g_ncur=0; g_pendLast=-1;
    unsigned v2magic=kEffectMagic;
    DWORD scanT0=GetTickCount(); unsigned long long scanned=0;
    MEMORY_BASIC_INFORMATION mbi; unsigned char* p=0;
    while(VirtualQuery(p,&mbi,sizeof mbi)==sizeof mbi){
        if(mbi.State==MEM_COMMIT && mbi.Type==MEM_PRIVATE && (mbi.Protect&(PAGE_READWRITE|PAGE_EXECUTE_READWRITE))
           && !(mbi.Protect&PAGE_GUARD) && mbi.RegionSize<512u*1024*1024){
            scan_region((unsigned char*)mbi.BaseAddress, mbi.RegionSize, justGotVtable, v2magic);
            scanned+=mbi.RegionSize;
        }
        unsigned char* nxt=(unsigned char*)mbi.BaseAddress+mbi.RegionSize; if(nxt<=p)break; p=nxt;
    }
    /* This pass read every private writable page of the rack (VST2 instances are found by content). What that costs in a
       rack with large sample libraries has never been measured; when it is slow, say so, so that a user's agent.log can
       answer it (1162). At most once a minute, and only in a process that already logs. */
    { DWORD took=GetTickCount()-scanT0; static DWORD lastSlow=0;
      if(took>=100 && g_logArmed && (lastSlow==0 || GetTickCount()-lastSlow>60000)){ lastSlow=GetTickCount();
          LOG("heap scan took %lu ms over %lu MB (every 1.2-2 s, on the agent's own thread)",(unsigned long)took,(unsigned long)(scanned>>20)); } }
    cb_clear_pending();   /* scan done without dying -> no module to blame */
    g_nprev = (g_ncur<MAXI)?g_ncur:MAXI; for(int i=0;i<g_nprev;i++) g_prevCand[i]=g_curCand[i];
    drop_dead_instances();   /* let go of anything the host has removed, before it is merged back in */
    merge_caught_into_v3();
    if(g_nv2!=g_lastN2 || g_nv3!=g_lastN3){
        if(g_nv2||g_nv3) log_arm();
        LOG("located: VST2 x%d, VST3 x%d",g_nv2,g_nv3);
        for(int i=0;i<g_nv2;i++){
            const char* vl;
            if(g_v2uid[i]==0x41547871u) vl = (g_v2np[i]==61?"AT4 4.3.9":(g_v2np[i]==69?"AT5 5.0.9":"Auto-Tune (ATxq)"));
            else if(g_v2uid[i]==0x41547845u) vl = "Auto-Tune Evo 6.0.9";
            else vl = "Auto-Tune (by-name)";
            /* a NULL table means "found by parameter name", which is now two different plug-ins --
               saying "Waves" for a T-Pain instance made the dump actively misleading. */
            const char* nm2 = vl;
            if(!g_v2tbl[i]){ V2W* w2=v2w_find(g_v2[i]);
                nm2 = (w2 && w2->kind==V2K_TPAIN) ? "The T-Pain Effect (VST2)" : "Waves (VST2 shell)"; }
            LOG("  VST2[%d] @ %p uid=0x%08x numParams=%d -> %s",i+1,(void*)g_v2[i],g_v2uid[i],g_v2np[i],nm2);
        }
        for(int i=0;i<g_nv3;i++) LOG("  VST3[%d] @ %p",i+1,(void*)g_v3[i]);
        g_lastN2=g_nv2; g_lastN3=g_nv3;
    }
    /* prune cached discovery for controllers no longer present (prevents stale data if a freed
       controller's address is later reused by a different plugin) */
    for(int k=0;k<NDISC;k++){ if(!g_disc[k].ctrl) continue; int present=0;
        for(int i=0;i<g_nv3;i++) if(g_v3[i]==g_disc[k].ctrl){ present=1; break; }
        if(!present) g_disc[k].ctrl=NULL; }
    /* discover + export each new VST3 controller's own scale names (once), so the controller
       can populate its Scale list immediately -- before the user picks anything */
    for(int i=0;i<g_nv3;i++) discover_one(g_v3[i]);
    for(int i=0;i<g_nv3;i++){ V3Disc* d=disc_find(g_v3[i]); if(d && d->haveS && d->nscales==0) fill_scale_names(g_v3[i],d); }  /* fill once; self-corrects if an address is reused (disc is pruned -> re-filled) */
    for(int i=0;i<g_nv3;i++){ V3Disc* d=disc_find(g_v3[i]); if(d && d->haveK && d->nkeys==0) fill_key_names(g_v3[i],d); }   /* read each plug-in's own root names */
    write_scales_union();
    write_status();
}

/* Nudge plugin editor windows to repaint after a parameter change. ASYNCHRONOUS ONLY: we just mark
   the window region dirty (InvalidateRect posts WM_PAINT); the owning UI thread repaints on its own
   schedule. We must NOT use RedrawWindow(...RDW_UPDATENOW): that forces the host's UI thread to run
   the plugin's WM_PAINT *synchronously* the instant we changed the params from this worker thread,
   racing the plugin's own state and crashing fragile plugins (e.g. real Auto-Tune 11). */
static BOOL CALLBACK inv_child(HWND h,LPARAM){ InvalidateRect(h,NULL,FALSE); return TRUE; }
static BOOL CALLBACK inv_top(HWND h,LPARAM){ DWORD pid=0; GetWindowThreadProcessId(h,&pid);
    if(pid!=GetCurrentProcessId()||!IsWindowVisible(h))return TRUE; InvalidateRect(h,NULL,FALSE); EnumChildWindows(h,inv_child,0); return TRUE; }
static void gui_refresh(){ EnumWindows(inv_top,0); }

/* set Key/Scale on ONE VST2 AEffect (setjmp contained here; returns 1 ok, 0 if it faulted) */
static DWORD g_targetPid=0; static char g_targetLeaf[96]="";   /* per-instance target: apply only to this (host pid, plugin filename); 0 = all */
static unsigned g_targetId=0;                                  /* exact instance id, 0 = match by name only */
/* Two instances of the SAME plug-in share a filename, so a name-only target hits both. When the
   controller sends tid=, address exactly that one object instead. */
/* Parse the target fields of a command line. Pulled out of the worker loop so the round trip
   "agent writes status -> controller parses it -> controller writes target -> agent matches it"
   can be exercised end to end: every piece of that chain passes its own tests, but the seams
   BETWEEN them were never checked against each other. */
static void parse_target(const char* line){
    { const char* ti2=strstr(line,"tid="); g_targetId = ti2? (unsigned)strtoul(ti2+4,NULL,16) : 0u; }
    { const char* tg=strstr(line,"target="); g_targetPid=0; g_targetLeaf[0]=0;
      if(tg){ tg+=7; g_targetPid=(DWORD)strtoul(tg,NULL,10); const char* col=strchr(tg,':');
              if(col){ col++; int j=0; while(col[j]&&col[j]!='|'&&col[j]!='\n'&&col[j]!='\r'&&j<95){ g_targetLeaf[j]=col[j]; j++; } g_targetLeaf[j]=0; } } } }
static int target_ok_obj(const void* obj, const char* leaf){
    if(g_targetPid==0) return 1;                        /* no target -> all plugins */
    if(g_targetPid != GetCurrentProcessId()) return 0;  /* target is in another host -> this agent applies to none */
    if(g_targetId) return inst_id(obj) == g_targetId;
    return leaf && g_targetLeaf[0] && _stricmp(leaf,g_targetLeaf)==0; }
static int do_set_vst2_one(AEffect* e, const char* const* tbl, int keySemi, const char* scaleName, double kv){
    if(!tbl){      /* NULL table = discovered BY PARAMETER NAME (Waves shell or The T-Pain Effect),
                      not by Antares' fixed index layout -- v2w_apply picks the right position list. */
        V2W* w=v2w_find(e);
        if(w && w->isTuner) v2w_apply(e,w,keySemi,scaleName);
        return 1; }
    int ri=-1,hi=-1,ni=-1,ai=-1;
    if(g_fRet>=0||g_fHum>=0||g_fNvb>=0||g_fAudio>=0) v2_feel_find(e,&ri,&hi,&ni,&ai);   /* resolve indices BEFORE our setjmp (v2_feel_find uses g_jb internally) */
    volatile int ok=1; g_probing=1;
    if(setjmp(g_jb)==0){
        if(keySemi>=0) v2set(e,2,(float)kv);
        if(scaleName&&scaleName[0]){ int idx=scale_name_to_index(tbl,scaleName); if(idx>=0) v2set(e,1,(float)scale_to_value_idx(idx)); }
        if(g_fRet>=0&&ri>=0) v2set(e,ri,(float)g_fRet);
        if(g_fHum>=0&&hi>=0) v2set(e,hi,(float)g_fHum);
        if(g_fNvb>=0&&ni>=0) v2set(e,ni,(float)g_fNvb);
        if(g_fAudio>=0&&ai>=0){ int ix=g_fAudio; if(ix<0)ix=0; if(ix>4)ix=4; v2set(e,ai,(float)(ix/4.0)); }   /* 5 types at 0/.25/.5/.75/1 */
    } else ok=0;
    g_probing=0; return ok;
}
/* Write one VST3 parameter the way the plug-in's own GUI does: update the controller's value AND tell
   the host (beginEdit/performEdit/endEdit), so the host propagates it to the audio processor, to
   automation and back to the GUI. Without the handler part the value only lives in the controller --
   the read-back changes but the plug-in does not actually react. h==NULL (e.g. Auto-Tune, whose
   controller we deliberately do not patch) keeps the previous behaviour unchanged. */
/* Is the module behind this controller positively identified as Antares? Evaluated lazily (the
   content scan reads up to 32MB) and memoised. Used to gate the blind id1/id2 rescue: a NEGATIVE
   test ("it is not Waves") is not evidence that a plug-in is Auto-Tune -- a renamed shell, or any
   other module the user adds to catch.txt, would otherwise get ids 1 and 2 overwritten. */
static int mod_antares_idx(int i){
    if(i<0 || i>=g_nat) return 0;
    if(g_at[i].antMod < 0){
        g_at[i].antMod = path_is_antares(g_at[i].path);
        LOG("Antares identification for %s -> %d",g_at[i].path,g_at[i].antMod); }
    return g_at[i].antMod; }
static int ctrl_module_is_antares(IEditController* c){
    char leaf[96]; mod_of_ctrl(c,leaf,sizeof leaf);
    for(int i=0;i<g_nat;i++){ const char* bs=strrchr(g_at[i].path,'\\'); const char* l=bs?bs+1:g_at[i].path;
        if(!_stricmp(l,leaf)) return mod_antares_idx(i); }
    return 0; }
/* ---- writes go out on the HOST's UI thread --------------------------------------------------
   VST3 requires beginEdit/performEdit/endEdit to come from the host's UI thread. This agent runs
   its own worker thread, which most hosts tolerate -- Studio One does not: it accepted the calls
   and discarded them, and the plug-in's value did not move by so much as a bit across five
   commands, while Studio One's own undo (its own UI thread) moved the same plug-in fine. Posting
   the identical writes to that thread fixed it: 24/24 landed, GUI following.

   A thread cannot run code on another thread by itself, so we subclass one window owned by the
   thread that installed the handler and POST a private message to it; Windows then runs our window
   procedure there and the write happens on the right thread.

   The post is asynchronous on purpose. SendMessage/SendMessageTimeout would park the worker on the
   host's UI thread, which may itself be waiting on the audio thread or sitting in the loader lock,
   and the DAW freezes with no crash and no log (see the guard in tests/scale_synonym/t_guards.c).
   We post, then poll the slot for a bounded time; if it was never pumped we fall back to writing on
   this thread, which is exactly what builds before 1144 always did. So this can only add a path,
   never remove one. */
#define UIQ 16
#define UIWAIT_MS 400
static volatile UINT    g_uiMsg=0;
static HWND    volatile g_uiWnd=NULL;
/* Worker bookkeeping only. Host callbacks dispatch through immutable per-HWND
   forwarding records rather than these mutable last-selected values. */
static WNDPROC volatile g_uiOrig=NULL;
static volatile int     g_uiWndUni=1;
static DWORD   g_uiWndTid=0;
static int     g_uiOff=0;          /* nouithread.txt only -- a permanent, user-chosen opt-out */
/* A timeout must NOT disable the path for the session. A modal loop still pumps posted messages, so
   the realistic cause of a miss is the UI thread being blocked in a long synchronous operation (a
   big project loading, an inline plug-in scan). Switching off permanently on one of those would
   silently put Waves back to "reads fine, writes do nothing" until the DAW is restarted, with
   nothing in the log to connect the two. Back off for a while and try again instead. */
#define UICOOL_MS 10000
static DWORD   g_uiCoolAt=0; static int g_uiCooling=0;
/* One 32-bit word per slot carries BOTH the generation and the phase, and every transition is a
   single Interlocked operation. That is what makes the hand-off safe:
     - the UI thread CLAIMS a request with CAS(gen|POST -> gen|RUN): it runs only the request it was
       posted for, and only if the worker has not taken it back;
     - the worker, at its deadline, RECLAIMS with CAS(gen|POST -> gen|FREE): it falls back to writing
       on its own thread only if the UI thread has not started.
   Exactly one of the two CASes can succeed. 1144 checked "state==1" and then acted, on both sides,
   so a UI thread that became free right at the deadline -- precisely the situation that produces a
   deadline -- could start the write while the worker gave up and started the same write itself:
   two threads inside one controller, interleaving beginEdit/performEdit/endEdit on one handler.
   Publishing with InterlockedExchange also fences the c/h/id/v stores, which a plain volatile store
   of the phase did not (the compiler may sink non-volatile stores past a volatile one).
   27 bits of generation: a slot would have to be reused ~134 million times to wrap. */
#define UIPH_FREE 0      /* never used, or reclaimed by the worker      */
#define UIPH_POST 1      /* published, message queued                   */
#define UIPH_RUN  2      /* claimed by the UI thread, executing         */
#define UIPH_DONE 3      /* finished (fault, if any, is in .faulted)    */
#define UIGEN_MASK 0x07FFFFFFUL
#define UIW(g,ph) ((LONG)((((unsigned long)(g)&UIGEN_MASK)<<2)|(unsigned long)(ph)))
#define UIPH(w)   ((LONG)(w)&3)
#define UIGEN(w)  ((LONG)(((unsigned long)(w)>>2)&UIGEN_MASK))
#if UIQ>16
#error "the slot index travels in 4 bits of WPARAM beside 27 bits of generation; UIQ must be <= 16"
#endif
#define UIRUN_MS 2000    /* how long to wait for a write the UI thread has already started */
/* No handler field on purpose: at_wndproc re-reads it with handler_of() at execution time (see there).
   A captured copy would be the stale pointer that re-read exists to avoid. */
static struct { IEditController* c; ParamID id; double v; const char* family; HWND volatile targetWindow; ATUI_Route* volatile targetRoute; volatile LONG targetThread; volatile LONG word; volatile LONG faulted; LONG pauseEpoch; } g_uiQ[UIQ];
static int g_uiSlot=0;
static int ui_target_matches(int slot,LONG generation,HWND window,const ATUI_Route* route,DWORD thread){
    /* Establish this exact generation before reading its atomic context. If
       the worker cancels/reuses the slot afterwards, the final claim CAS must
       fail for the old generation. A future-generation message sent while the
       slot is FREE must not validate against its previous window identity. */
    if(slot<0||slot>=UIQ||!route||route->thread!=thread
       ||InterlockedCompareExchange(&g_uiQ[slot].word,0,0)!=UIW(generation,UIPH_POST))return 0;
    return InterlockedCompareExchangePointer((void* volatile*)&g_uiQ[slot].targetWindow,NULL,NULL)==(void*)window
        &&InterlockedCompareExchangePointer((void* volatile*)&g_uiQ[slot].targetRoute,NULL,NULL)==(void*)route
        &&(DWORD)InterlockedCompareExchange(&g_uiQ[slot].targetThread,0,0)==thread;
}
static int ui_instance_running(const void* controller){
    for(int i=0;i<UIQ;i++){
        LONG word=InterlockedCompareExchange(&g_uiQ[i].word,0,0);
        if(UIPH(word)==UIPH_RUN&&g_uiQ[i].c==controller)return 1;
    }
    return 0;
}

static void v3set_body(IEditController* c, void* h, ParamID id, double v,const char* family=NULL,int requiresHandler=-1,LONG pauseEpoch=0){
    if(!agent_parameter_ready(pauseEpoch))return;
    if(!agent_write_allowed(c->vtbl,family))return;
    if(requiresHandler<0)requiresHandler=h!=NULL||(family&&(!strcmp(family,"waves")||!strcmp(family,"tpain")));
    CHBinding* binding=requiresHandler?handler_binding_acquire(c):NULL;
    if(requiresHandler&&!binding){LOG("UI-thread writes: controller %p has no current host handler; id=%u skipped",c,id);return;}
    g_handlerHeldTid=GetCurrentThreadId();g_handlerHeld=binding;
    /* A posted edit can outlive a handler move to another host UI thread.
       Keep its acquired reference in the guard ledger, but skip the stale UI.
       State 2 remains the explicit worker compatibility path. */
    if(binding&&g_uiExecuting==1&&binding->ownerTid!=g_handlerHeldTid){LOG("UI-thread writes: controller %p handler moved to thread %lu; id=%u skipped",c,binding->ownerTid,id);return;}
    if(!agent_parameter_ready(pauseEpoch))return;
    c->vtbl->setParamNormalized(c,id,v);
    /* setParamNormalized can synchronously clear/replace the binding. Do not
       start a gesture on that detached handler, even though our ref keeps it
       alive. A gesture admitted here retains its ref through paired endEdit. */
    if(binding&&handler_binding_current(c,binding)){IComponentHandler* ch=(IComponentHandler*)binding->handler;
        ch->vtbl->beginEdit(ch,id); ch->vtbl->performEdit(ch,id,v); ch->vtbl->endEdit(ch,id); } }

static LRESULT CALLBACK at_wndproc(HWND hw, UINT m, WPARAM wp, LPARAM lp){
    /* Dispatch belongs to this HWND's immutable record, never to whichever
       other window the worker most recently selected. Keep a local route while
       forwarding: NCDESTROY can retire an epoch but cannot replace its fields. */
    ATUI_Route* route=atui_find(hw);
    WNDPROC orig=route?route->original:NULL; int uni=route?route->unicode:(IsWindowUnicode(hw)?1:0); UINT msg=g_uiMsg;
    if(m==WM_NCDESTROY)atui_destroy(route);
    if(msg && m==msg){
        /* Counts describe active parameter transactions for diagnostics. The
           PINNED image, not a zero count, protects all callback return tails.
           Read-only ordinary-message observers remain installed during stop
           and are deliberately not counted as parameter work. */
        InterlockedIncrement(&g_inHook);
        int  k  =(int)(wp & 0xFu);
        LONG gen=(LONG)((wp >> 4) & UIGEN_MASK);
        /* Claim atomically: right generation AND still posted, in one step. A stale message (its
           request was reclaimed, or the slot has since been reused) fails the CAS and does nothing. */
        if(!g_ejecting && atui_live(route) && ui_target_matches(k,gen,hw,route,GetCurrentThreadId())
           &&InterlockedCompareExchange(&g_uiQ[k].word,UIW(gen,UIPH_RUN),UIW(gen,UIPH_POST))==UIW(gen,UIPH_POST)){
            /* A previously started transaction can outlive UIRUN_MS on another
               host UI thread. Never let that thread's single recovery buffer
               be replaced, and never fall back to a concurrent worker write.
               Skipped parameters stay unconfirmed for normal readback/retry. */
            if(InterlockedCompareExchange(&g_uiExecuting,1,0)!=0){
                g_uiQ[k].faulted=2;
            } else {
            /* Re-read the handler NOW instead of trusting the one captured at post time. Between the
               post and this moment the user may have removed the plug-in: the host then runs
               setComponentHandler(NULL), terminate() and frees its handler -- on this very thread,
               ahead of us in the queue. Because setComponentHandler and this procedure run on the
               same thread they are serialised, so reading it here is guaranteed to see the clear,
               and a NULL simply skips the edit gesture instead of calling into freed memory.
               handler_of() is a locked table read with no call into the plug-in: the kind of work
               t_pace's 1100 rule allows on a host thread. */
            void* hNow=handler_of(g_uiQ[k].c);
            HandlerGuardMark handlerMark=handler_guard_mark();
            g_uiProbeTid=GetCurrentThreadId();
            InterlockedExchange(&g_uiProbing,1);
            if(setjmp(g_uiJb)==0){
                v3set_body(g_uiQ[k].c,hNow,g_uiQ[k].id,g_uiQ[k].v,g_uiQ[k].family,1,g_uiQ[k].pauseEpoch); }
            else                  g_uiQ[k].faulted=1;
            handler_transaction_cleanup(handlerMark); /* keep this thread's recovery frame active during release */
            InterlockedExchange(&g_uiProbing,0);
            InterlockedExchange(&g_uiExecuting,0); }
            InterlockedExchange(&g_uiQ[k].word,UIW(gen,UIPH_DONE)); }   /* fences .faulted before DONE */
        InterlockedDecrement(&g_inHook);
        return 1; }
    /* An original equal to our observer would recurse forever. Preparation
       refuses it; keep this second defence on each immutable dispatch route. */
    if(!orig || orig==(WNDPROC)at_wndproc) return uni ? DefWindowProcW(hw,m,wp,lp) : DefWindowProcA(hw,m,wp,lp);
    return uni ? CallWindowProcW(orig,hw,m,wp,lp)
               : CallWindowProcA(orig,hw,m,wp,lp); }

static BOOL CALLBACK pick_ui_wnd(HWND h, LPARAM lp){
    HWND* out=(HWND*)lp;
    if(!*out) *out=h;                                                        /* anything beats nothing */
    if(IsWindowVisible(h) && !GetWindow(h,GW_OWNER)){ *out=h; return FALSE; }  /* prefer the main window */
    return TRUE; }

/* ui_attach / ui_detach are worker-owned. Host threads only read immutable
   forwarding records and mark their own destroyed window epoch. The read-only
   observer stays PINNED during stop; private writes are cancelled/gated while
   ordinary host messages keep their own window's forwarding identity. */
static void ui_detach(){
    /* The PINNED, read-only observer remains to see WM_NCDESTROY and preserve
       third-party subclass chains. Stop selects no write window; records and
       their original procedures are never changed or reclaimed. */
    g_uiWnd=NULL; g_uiWndTid=0; }


/* Some of ui_attach's outcomes repeat on EVERY write: a host that installed the handler on a thread
   with no window logs "owns no window" for each parameter it writes, and a host that keeps replacing
   its window would log a fresh "subclassed window" each time. One integration run produced 178 and
   83 such lines. This file follows a log-the-change rule elsewhere (notready_first: once per module,
   not once per scan), and the log is shared by every process the agent is in and is what users send
   when something goes wrong -- a flood buries the lines that matter. So: the first occurrence is
   always written, later ones at most once per UILOG_MS, carrying the count that was left out. */
#define UILOG_MS 60000
typedef struct { DWORD at; LONG left; } UiLogGate;
static UiLogGate g_ulNoWnd, g_ulResub;
static DWORD g_ulTid=0;                 /* thread of the last attach we logged in full */
static int ui_log_ok(UiLogGate* g, LONG* leftOut){
    DWORD now=GetTickCount();
    if(g->at && now-g->at < (DWORD)UILOG_MS){ g->left++; return 0; }
    *leftOut=g->left; g->left=0; g->at=now?now:1; return 1; }

/* Installer callbacks run on the owner and keep no worker locks or stack data. */
#include "../vst3/cpp/companion_ui_install.h"
static int ui_attach(DWORD tid){
    if(g_ejecting) return 0;
    if(g_uiWnd && IsWindow(g_uiWnd) && g_uiWndTid==tid && atui_live(atui_find(g_uiWnd))) return 1;
    if(g_uiWnd) ui_detach();                                        /* window went away -> re-pick */
    HWND h=NULL; EnumThreadWindows(tid,pick_ui_wnd,(LPARAM)&h);
    if(!h){ LONG left=0;
        if(ui_log_ok(&g_ulNoWnd,&left))
            { if(left) LOG("UI-thread writes: host thread %lu owns no window -- writing on the worker instead "
                           "(%ld more in the last minute not logged)",(unsigned long)tid,(long)left);
              else     LOG("UI-thread writes: host thread %lu owns no window -- writing on the worker instead",
                           (unsigned long)tid); }
        return 0; }
    if(!g_uiMsg){ g_uiMsg=RegisterWindowMessageW(L"AT8_UI_PARAM_WRITE");
        if(!g_uiMsg){ LOG("UI-thread writes: RegisterWindowMessage failed (%lu)",(unsigned long)GetLastError()); return 0; } }
    g_uiWndUni = IsWindowUnicode(h)?1:0;
    ATUI_Route* route=atui_find(h);
    if(route){
        if(!atui_epoch_live(route)||route->thread!=tid||route->unicode!=g_uiWndUni){
            static int warned=0;if(!warned){warned=1;LOG("UI-thread writes: HWND epoch cannot be confirmed; keeping old forwarding identity and writing on the worker instead");}
            return 0;
        }
        /* The same window may have a later subclass above us. Never wrap that
           chain back through this observer: it would create a forwarding loop.
           If the host replaced us without chaining, normal post timeout falls
           back safely instead of overwriting the retained original. */
        if(!atui_live(route))route=atui_install_on_owner(h,tid,g_uiWndUni,(WNDPROC)at_wndproc);
        if(!route||!atui_live(route))return 0;
        g_uiOrig=route->original;g_uiWnd=h;g_uiWndTid=tid;return 1;
    }
    route=atui_install_on_owner(h,tid,g_uiWndUni,(WNDPROC)at_wndproc);
    if(!route||!atui_live(route)){LOG("UI-thread writes: could not subclass window %p on host UI thread %lu -- owner-thread confirmation unavailable; existing fallback policy applies (busy transactions are skipped)",(void*)h,(unsigned long)tid);return 0;}
    g_uiOrig=route->original; g_uiWnd=h; g_uiWndTid=tid;
    if(tid!=g_ulTid){
        g_ulTid=tid;
        LOG("UI-thread writes: subclassed window %p on host UI thread %lu -- parameter writes go there from now on",
            (void*)h,(unsigned long)tid); }
    else{ LONG left=0;
        if(ui_log_ok(&g_ulResub,&left)){
            if(left) LOG("UI-thread writes: subclassed window %p on host UI thread %lu again -- the host replaced its "
                         "window (%ld more in the last minute not logged)",(void*)h,(unsigned long)tid,(long)left);
            else     LOG("UI-thread writes: subclassed window %p on host UI thread %lu again -- the host replaced its "
                         "window",(void*)h,(unsigned long)tid); } }
    return 1; }

/* 1 = the write ran on the host's UI thread; 0 = caller must do it itself */
static int ui_post(IEditController* c, ParamID id, double v,const char* family=NULL){   /* caller has already checked there is a handler */
    if(!agent_parameter_ready())return 1;
    if(g_uiOff || g_ejecting) return 0;
    if(g_uiCooling){
        if(GetTickCount()-g_uiCoolAt < (DWORD)UICOOL_MS) return 0;    /* still backing off */
        g_uiCooling=0; LOG("UI-thread writes: back-off over, trying the host UI thread again"); }
    DWORD tid=uitid_of(c);
    if(!tid || tid==GetCurrentThreadId()) return 0;   /* unknown, or we are already there */
    /* Two attempts at most. The second one exists for exactly one case: the window we posted to was
       destroyed before our message was dispatched. Win32 drops messages addressed to a destroyed
       window, so ours can never run -- and that is NOT the UI thread being slow. Treating it as a
       timeout (as this did at first) waited the full UIWAIT_MS for a message that was already gone,
       then logged "did not pump" and backed off for UICOOL_MS: ten seconds of Waves not following in
       Studio One, blamed on the wrong cause. Found by the integration test with the host rebuilding
       its window under load -- 130 of 200 writes went that way. Now: notice the window is gone,
       reclaim the request (the CAS makes that safe: a message that can no longer run cannot also
       have run), pick a window again and post once more. */
    for(int attempt=0; attempt<2; attempt++){
        if(!ui_attach(tid)) return 0;
        /* take the next slot whose previous request is finished or was reclaimed; a slot still in
           POST or RUN belongs to a request the UI thread may yet execute, and must not be overwritten */
        int k=-1;
        for(int i=0;i<UIQ;i++){ int j=(g_uiSlot+i)%UIQ; LONG ph=UIPH(g_uiQ[j].word);
            if(ph==UIPH_FREE || ph==UIPH_DONE){ k=j; break; } }
        if(k<0){ LOG("UI-thread writes: all %d slots still pending on the UI thread -- writing on the worker instead",UIQ); return 0; }
        g_uiSlot=(k+1)%UIQ;
        LONG gen=(UIGEN(g_uiQ[k].word)+1) & (LONG)UIGEN_MASK;
        HWND target=g_uiWnd;
        ATUI_Route* targetRoute=atui_find(target);
        if(!atui_live(targetRoute)||targetRoute->thread!=tid)return 0;
        InterlockedExchangePointer((void* volatile*)&g_uiQ[k].targetWindow,(void*)target);
        InterlockedExchangePointer((void* volatile*)&g_uiQ[k].targetRoute,(void*)targetRoute);
        InterlockedExchange(&g_uiQ[k].targetThread,(LONG)tid);
        g_uiQ[k].c=c; g_uiQ[k].id=id; g_uiQ[k].v=v;g_uiQ[k].family=family;g_uiQ[k].faulted=0;g_uiQ[k].pauseEpoch=InterlockedCompareExchange(&g_parameterEpoch,0,0);   /* h is re-read on the UI thread */
        InterlockedExchange(&g_uiQ[k].word,UIW(gen,UIPH_POST));          /* publish: fences the fields above */
        if(!PostMessage(target,g_uiMsg,(WPARAM)(((unsigned long)gen<<4)|(unsigned long)k),0)){
            InterlockedExchange(&g_uiQ[k].word,UIW(gen,UIPH_FREE));
            if(!IsWindow(target)) continue;                              /* died between attach and post */
            LOG("UI-thread writes: PostMessage failed (%lu) -- writing on the worker instead",(unsigned long)GetLastError());
            return 0; }
        /* Sleep(1) is not 1 ms -- at the default timer resolution it can be ~15, so counting iterations
           made the worst case ~6 s with g_cs held. Measure the wall clock instead. */
        int gone=0;
        { DWORD t0=GetTickCount();
          while(UIPH(g_uiQ[k].word)==UIPH_POST && GetTickCount()-t0 < (DWORD)UIWAIT_MS){
              if(!IsWindow(target)){ gone=1; break; }
              Sleep(1); } }
        /* The deadline is decided atomically. If the UI thread has not claimed it yet, take it back: the
           queued message will then fail its CAS and do nothing, so writing here cannot double up. */
        if(InterlockedCompareExchange(&g_uiQ[k].word,UIW(gen,UIPH_FREE),UIW(gen,UIPH_POST))==UIW(gen,UIPH_POST)){
            if(gone) continue;                                           /* window replaced: not a slow thread */
            g_uiCooling=1; g_uiCoolAt=GetTickCount();   /* back off, do not give up: see UICOOL_MS above */
            LOG("UI-thread writes: host UI thread %lu did not pump within %d ms -- this write goes to the worker "
                "thread and marshalling pauses for %d ms (plug-ins that need the host path, such as Waves, may "
                "not follow until it resumes)",(unsigned long)g_uiWndTid,UIWAIT_MS,UICOOL_MS);
            return 0; }
        /* The UI thread has it. Never repeat it here -- that is the double write this design exists to
           prevent. Wait for it to finish so the caller's read-back sees the result, but not forever. */
        { DWORD t0=GetTickCount(); while(UIPH(g_uiQ[k].word)==UIPH_RUN && GetTickCount()-t0 < (DWORD)UIRUN_MS) Sleep(1); }
        if(UIPH(g_uiQ[k].word)==UIPH_RUN)
            LOG("UI-thread writes: the write for id=%u is still running on the UI thread after %d ms -- "
                "leaving it there, not repeating it on the worker",id,UIRUN_MS);
        else{
            g_uiCooling=0;
            if(g_uiQ[k].faulted==2) LOG("UI-thread writes: another host UI parameter transaction is still running; id=%u skipped pending readback/retry",id);
            else if(g_uiQ[k].faulted) LOG("UI-thread writes: the write for id=%u faulted on the UI thread (recovered)",id); }
        return 1; }
    LOG("UI-thread writes: the host replaced its window twice while a write was queued -- writing on the worker instead");
    return 0; }

static void v3set(IEditController* c, void* h, ParamID id, double v,const char* family=NULL){
    if(h && ui_post(c,id,v,family)) return;
    /* A timed-out UI call may still be executing. Claim the same nonblocking
       execution guard instead of racing that call from the worker. */
    if(InterlockedCompareExchange(&g_uiExecuting,2,0)!=0){LOG("UI-thread writes: a parameter write is already running -- skipped worker fallback for id=%u",id);return;}
    HandlerGuardMark handlerMark=handler_guard_mark();
    v3set_body(c,h,id,v,family);
    handler_transaction_cleanup(handlerMark);
    InterlockedCompareExchange(&g_uiExecuting,0,2); }
/* set Key/Scale on ONE VST3 controller (setjmp contained here; returns 1 ok, 0 if it faulted) */
static int do_set_vst3_one(IEditController* c, int keySemi, const char* scaleName, double kv){
    /* Discovery, the module-identity test and the handler lookup all happen BEFORE the crash guard
       is armed. discover_one() and ctrl_module_is_antares() each install their own guard on g_jb,
       and g_jb holds exactly one recovery point -- running them inside this function's guard would
       overwrite it, leaving a later fault to longjmp into a frame that has already unwound. */
    V3Disc* d=disc_find(c);
    if(!d){ discover_one(c); d=disc_find(c); if(d && d->nscales>0) write_scales_union(); }
    if(!d) return 1;                                   /* discovery faulted -> leave the plug-in alone */
    /* Resolve family before this function owns g_jb. Identity discovery may
       install its own recovery point; no writer/queue below may redo it. */
    int isAntares=(!d->isWaves&&!d->isTPain)?ctrl_module_is_antares(c):0;
    const char* family=d->isTPain?"tpain":d->isWaves?"waves":isAntares?"antares":NULL;
    int antOK = (!d->haveS && !d->haveK && !d->isWaves) ? isAntares : 0;
    void* hch=handler_of(c);                           /* host handler, if we captured one (Waves) */
    HandlerGuardMark handlerMark=handler_guard_mark();
    volatile int ok=1; volatile LONG sv=g_probing; g_probing=1;
    if(setjmp(g_jb)==0){
        if(d->haveS||d->haveK){
            int keyDone=0;
            /* Pick the step whose NOTE NAME matches the requested pitch class, for every VST3 plug-in.
               The arithmetic fallback below assumes step i == semitone i; that assumption is exactly
               what made key B land on G# when Waves turned out to expose 17 roots with enharmonics
               (C#/Db...). Matching by name is correct whatever order or spelling a plug-in uses, and
               on Auto-Tune Pro it resolves to the identical value the formula produced. */
            if(d->haveK && keySemi>=0 && d->nkeys>0){
                for(int i=0;i<d->nkeys;i++){ if(key_to_pc(d->kdisp[i])==keySemi){ v3set(c,hch,d->keyId,d->kvals[i],family); keyDone=1;
                    LOG("Root set by name: key %d -> '%s' val %.4f (id=%u)",keySemi,d->kdisp[i],d->kvals[i],d->keyId); break; } }
                if(!keyDone) LOG("Root: pitch class %d not found among %d enumerated root names -> semitone fallback",keySemi,d->nkeys);
            }
            if(!keyDone && d->haveK && keySemi>=0 && d->keySteps>0) v3set(c,hch,d->keyId,(double)keySemi/d->keySteps,family);
            if(d->haveS && scaleName && scaleName[0] && d->nscales>0){
                char want[48]; norm(scaleName,want,sizeof want); int found=-1;
                for(int sc=0; sc<d->nscales; sc++){ if(d->snorm[sc][0] && scale_same(d->snorm[sc],want)){ found=sc; break; } }
                if(found>=0){ v3set(c,hch,d->scaleId,d->svals[found],family);
                              LOG("VST3 scale set: '%s' -> idx %d val %.4f (id=%u steps=%d)",scaleName,found,d->svals[found],d->scaleId,d->scaleSteps); }
                else LOG("VST3: scale '%s' not in classic list (nscales=%d)",scaleName,d->nscales);
                if(d->haveMod && d->modn>0){                  /* Pro 11: also set the active Modern Scale */
                    int mf=-1; for(int sc=0; sc<d->modn; sc++){ if(d->msnorm[sc][0] && scale_same(d->msnorm[sc],want)){ mf=sc; break; } }
                    if(mf>=0){ v3set(c,hch,d->modId,d->msvals[mf],family);
                               LOG("VST3 MODERN scale set: '%s' -> idx %d val %.4f (modId=%u steps=%d)",scaleName,mf,d->msvals[mf],d->modId,d->modSteps); }
                    else LOG("VST3: '%s' not in modern scale list (modId=%u modn=%d)",scaleName,d->modId,d->modn);
                }
            } else if(d->haveS && scaleName && scaleName[0]) LOG("VST3: Scale found (id=%u) but no scale names enumerated (steps=%d) -> skipped",d->scaleId,d->scaleSteps);
        } else if(antOK){
            /* Legacy AT8.1 rescue: that plug-in exposes Key/Scale as bare ids 1 and 2. It is a BLIND
               write, so it may only ever run on a plug-in we did not positively identify AND that did
               not come from the Waves shell -- on Waves, ids 1 and 2 are "Note Transition" and
               "Link On/Off", and writing them there corrupts unrelated settings. */
            if(keySemi>=0) v3set(c,hch,2,kv,family);
            if(scaleName&&scaleName[0]){ int idx=scale_name_to_index(SCALES_STD,scaleName); if(idx>=0) v3set(c,hch,1,scale_to_value_idx(idx),family); }
            LOG("VST3: titles not found, used AT8.1 fallback (id1/id2)");
        } else {
            LOG("VST3: Scale/Key not resolved and the module is not positively identified as Antares -> writing NOTHING");
        }
        if(g_fRet>=0&&d->haveRet) v3set(c,hch,d->retId,g_fRet,family);
        if(g_fHum>=0&&d->haveHum) v3set(c,hch,d->humId,g_fHum,family);
        if(g_fNvb>=0&&d->haveNvb) v3set(c,hch,d->nvbId,g_fNvb,family);
        /* Waves has no Retune/Humanize/Natural-Vibrato; the equivalent feel controls are Speed,
           Note Transition and Vibrato Depth, so the three sliders drive those instead. */
        if(d->isWaves||d->isTPain){
            if((g_fSpeed>=0||g_fRet>=0)&&d->haveWSpeed) v3set(c,hch,d->wSpeedId,g_fSpeed>=0?g_fSpeed:g_fRet,family);
            if(g_fHum>=0&&d->haveWTrans) v3set(c,hch,d->wTransId,g_fHum,family);
            if(g_fNvb>=0&&d->haveWVib)   v3set(c,hch,d->wVibId,  g_fNvb,family);
        }
        if(g_fAudio>=0&&d->haveAudio){ int st=d->audioSteps>0?d->audioSteps:4; int ix=g_fAudio; if(ix<0)ix=0; if(ix>st)ix=st; v3set(c,hch,d->audioId,(double)ix/st,family); }
    } else ok=0;
    /* A worker plug-in fault longjmps over v3set's normal release. Only clear
       the worker claim (2); a still-running UI owner (1) keeps its guard. */
    if(InterlockedCompareExchange(&g_uiExecuting,0,0)==2)handler_transaction_cleanup(handlerMark);
    InterlockedCompareExchange(&g_uiExecuting,0,2);
    g_probing=sv; return ok;
}
static void do_set(int keySemi,const char* scaleName){
    if(g_nv2==0 && g_nv3==0){ scan_all(); if(g_nv2==0&&g_nv3==0){ LOG("set: nothing located yet"); return; } }
    double kv=key_to_value(keySemi>=0?keySemi:0);
    for(int i=0;i<g_nv2;i++){ AEffect* e=g_v2[i]; if(!e)continue;
        V2W* policyW=v2w_find(e);if(!agent_policy_address((void*)e->dispatcher,policyW?(policyW->kind==V2K_TPAIN?"tpain":"waves"):"antares"))continue;
        /* Match on the name the Target list SHOWS, exactly as write_status() does -- the controller
           sends back the label it displayed, so comparing anything else can only fail. For a
           name-discovered VST2 (Waves shell, The T-Pain Effect) that label is the EFFECT name
           ("The T-Pain Effect"); this used to compare the module file name
           ("The T-Pain Effect.dll") and never matched, so picking a single VST2 instance in the
           Target box silently did nothing at all. Only "all" worked, which is why it went unnoticed.
           The Antares-table VST2 path has no effect name, so its label is the module name. */
        { char lf[96]; V2W* w2=v2w_find(e);
          if(!g_v2tbl[i] && w2 && w2->isTuner) snprintf(lf,sizeof lf,"%s",w2->name);
          else mod_leaf((void*)e->dispatcher,lf,sizeof lf);
          if(!target_ok_obj(e,lf)) continue; }
        if(!do_set_vst2_one(e,g_v2tbl[i],keySemi,scaleName,kv)){ LOG("VST2 #%d invalid -> dropped",i+1); g_v2[i]=NULL; } }
    for(int i=0;i<g_nv3;i++){ IEditController* c=g_v3[i]; if(!c)continue;
        V3Disc* policyD=disc_find(c);if(!agent_policy_address(c->vtbl,policyD&&policyD->isTPain?"tpain":policyD&&policyD->isWaves?"waves":NULL))continue;
        { V3Disc* dd=disc_find(c); if(dd && dd->isWaves && dd->discDone && !dd->isTuner) continue; }   /* non-tuning Waves plugin (C6/SSL/...) -> never write */
        { char lf[96]; if(!modmap_get(c,lf,sizeof lf)) mod_of_ctrl(c,lf,sizeof lf); if(!target_ok_obj(c,lf)) continue; }
        if(!do_set_vst3_one(c,keySemi,scaleName,kv)){ LOG("VST3 #%d invalid -> dropped",i+1); g_v3[i]=NULL; for(int k=0;k<NDISC;k++) if(g_disc[k].ctrl==c) g_disc[k].ctrl=NULL; } }
    { int w=0; for(int i=0;i<g_nv2;i++) if(g_v2[i]){ g_v2[w]=g_v2[i]; g_v2tbl[w]=g_v2tbl[i];
            g_v2uid[w]=g_v2uid[i]; g_v2np[w]=g_v2np[i];   /* these were left behind, so the diagnostic
                                                             line reported another instance's uid */
            w++; } g_nv2=w; }
    { int w=0; for(int i=0;i<g_nv3;i++) if(g_v3[i]) g_v3[w++]=g_v3[i]; g_nv3=w; }
    if(g_nv3>0||g_nv2>0) gui_refresh();
    LOG("applied key=%d scale=%s -> VST2 x%d, VST3 x%d", keySemi, scaleName?scaleName:"(none)", g_nv2, g_nv3);
}

/* ---- crash record (1148) ------------------------------------------------------------------------
   When the host died, agent.log simply stopped: it showed the last thing the agent did, never where or
   why the process died, so "adding several plug-ins at once makes the rack close" could not be placed.
   This top-level filter writes ONE line when an exception is about to kill the process, then hands the
   exception on unchanged -- to the filter that was installed before ours, or to Windows' own error
   reporting -- so the host's crash handling is not altered.
   It runs on a dying thread whose locks may be held (the log's FILE lock, the heap, the loader lock), so
   it uses no CRT stdio, no heap and no LOG: a stack buffer, VirtualQuery and GetMappedFileName (neither
   takes the loader lock) and a single WriteFile.
   Not every crash comes through here: heap corruption and other fail-fast terminations bypass top-level
   filters entirely; Windows' Application event log still records those.
   Limitation: if something installs its own filter AFTER ours and chains to ours, an eject cannot unlink
   ours from that chain; a crash after the eject would then call into the unloaded agent. That changes
   which address the crash report names, not whether the host crashes. */
static LPTOP_LEVEL_EXCEPTION_FILTER g_prevUef=NULL;
static volatile LONG g_uefOn=0, g_inUef=0;
static ULONG_PTR g_selfLo=0, g_selfHi=0;
static LONG WINAPI agent_uef(EXCEPTION_POINTERS* ep){
    if(InterlockedExchange(&g_inUef,1)==0 && g_logPath[0]){
        EXCEPTION_RECORD* er = ep ? ep->ExceptionRecord : NULL;
        DWORD code = er ? er->ExceptionCode : 0; void* addr = er ? er->ExceptionAddress : NULL;
        char mod[MAX_PATH]="?"; unsigned long off=0; MEMORY_BASIC_INFORMATION mbi;
        if(addr && VirtualQuery(addr,&mbi,sizeof mbi)==sizeof mbi && mbi.AllocationBase){
            off=(unsigned long)((ULONG_PTR)addr-(ULONG_PTR)mbi.AllocationBase);
            if(!GetMappedFileNameA(GetCurrentProcess(),mbi.AllocationBase,mod,sizeof mod)) snprintf(mod,sizeof mod,"(not in a module)"); }
        const char* leaf=strrchr(mod,'\\'); leaf=leaf?leaf+1:mod;
        char av[96]="";
        if(er && code==EXCEPTION_ACCESS_VIOLATION && er->NumberParameters>=2)
            snprintf(av,sizeof av," (%s %p)", er->ExceptionInformation[0]==1?"writing":er->ExceptionInformation[0]==8?"executing":"reading",
                     (void*)er->ExceptionInformation[1]);
        DWORD tid=GetCurrentThreadId();
        const char* role = (tid==g_workerTid) ? "the agent's worker thread"
                         : (g_uiProbing && tid==g_uiProbeTid) ? "a host thread inside the agent's UI-thread write"
                         : "a host thread";
        int frames=0;   /* values on the dying thread's stack that point into the agent: was the agent on the call path? */
        if(ep && ep->ContextRecord && g_selfHi>g_selfLo){
#ifdef _WIN64
            ULONG_PTR sp=(ULONG_PTR)ep->ContextRecord->Rsp;
#else
            ULONG_PTR sp=(ULONG_PTR)ep->ContextRecord->Esp;
#endif
            /* The stack's bounds from VirtualQuery rather than NtCurrentTeb(): the committed part of a thread
               stack is one region of identical pages running from the page holding sp up to the stack's top,
               so BaseAddress+RegionSize is that top. NtCurrentTeb() reads the TEB through the gs/fs segment,
               which GCC's -Warray-bounds misreads as an access near address zero -- a false positive, but one
               that sat in every -Wall build from 1148 on and hid behind an unchanged warning COUNT, because a
               misleading-indentation warning dropped out at the same time. */
            MEMORY_BASIC_INFORMATION sm; ULONG_PTR lo=0, hi=0;
            if(VirtualQuery((void*)sp,&sm,sizeof sm)==sizeof sm && sm.State==MEM_COMMIT){
                lo=(ULONG_PTR)sm.BaseAddress; hi=lo+(ULONG_PTR)sm.RegionSize; }
            if(hi>lo && sp>=lo && sp<hi){ ULONG_PTR end=(hi-sp>32768)? sp+32768 : hi;
                for(ULONG_PTR q=sp&~(ULONG_PTR)(sizeof(void*)-1); q+sizeof(void*)<=end; q+=sizeof(void*)){
                    ULONG_PTR v=*(ULONG_PTR*)q; if(v>=g_selfLo && v<g_selfHi) frames++; } } }
        int inSelf = ((ULONG_PTR)addr>=g_selfLo && (ULONG_PTR)addr<g_selfHi);
        /* The agent observes host windows, and its window procedure forwards every other
           message with a plain call -- CallWindowProc takes five arguments, so it cannot become a tail
           jump (checked in the -O2 assembly). Its return address therefore sits on the UI thread's stack
           for EVERY message the host handles there, and any later crash in the host's own main-window
           handling read "the agent was on the call path" -- the line users are told points at the agent
           (1159). The pass-through is the one piece of agent code that runs on a host thread WITHOUT
           counting itself in g_inHook (deliberately: see at_wndproc). So on an observed thread, with no host
           thread inside any agent hook and the crash outside the agent, those frames are the forwarding
           and nothing else. Anything less certain keeps the original wording. */
        int idleFwd = (frames>0 && !inSelf && atui_thread_observed(tid) && g_inHook==0);
        char b[1400]; DWORD t=log_now_ms();
        int n=snprintf(b,sizeof b,"[%lu] +%lu.%03lu CRASH: exception 0x%08lX at %p = %s+0x%lX%s on %s (thread %lu)%s; "
            "agent code on that thread's stack: %d value(s)%s; host threads inside agent hooks: %ld; worker guard: %ld%s%s\n",
            (unsigned long)GetCurrentProcessId(),(unsigned long)(t/1000),(unsigned long)(t%1000),
            (unsigned long)code,addr,leaf,off,av,role,(unsigned long)tid, inSelf?" -- INSIDE THE AGENT":"",
            frames, inSelf?"":(!frames?" (the agent was not on the call path)"
                                 : idleFwd?" (only the agent's window-subclass pass-through: the agent was idle on this thread)"
                                 :" (the agent was on the call path)"),
            (long)g_inHook,(long)g_probing, g_pendNow[0]?"; worker was probing ":"", g_pendNow[0]?g_pendNow:"");
        if(n>0){ if(n>(int)sizeof b-1) n=(int)sizeof b-1;
            if(b[n-1]!='\n') b[n-1]='\n';
            HANDLE h=CreateFileA(g_logPath,FILE_APPEND_DATA,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
            if(h!=INVALID_HANDLE_VALUE){ DWORD w=0; WriteFile(h,b,(DWORD)n,&w,NULL); CloseHandle(h); } } }
    return g_prevUef ? g_prevUef(ep) : EXCEPTION_CONTINUE_SEARCH; }
static void crash_record_install(){
    if(g_uefOn || !g_self) return;
    IMAGE_DOS_HEADER* dh=(IMAGE_DOS_HEADER*)g_self; IMAGE_NT_HEADERS* nh=(IMAGE_NT_HEADERS*)((char*)g_self+dh->e_lfanew);
    g_selfLo=(ULONG_PTR)g_self; g_selfHi=g_selfLo+nh->OptionalHeader.SizeOfImage;
    g_prevUef=SetUnhandledExceptionFilter(agent_uef); g_uefOn=1; }
static void crash_record_remove(){
    if(!g_uefOn) return;
    LPTOP_LEVEL_EXCEPTION_FILTER cur=SetUnhandledExceptionFilter(g_prevUef);
    if(cur!=agent_uef){ SetUnhandledExceptionFilter(cur);   /* someone else's is on top: leave it (see the limitation above) */
        LOG("crash record: another top-level filter was installed after ours; leaving it in place"); }
    g_uefOn=0; }

/* Side effects of a command that do not touch a plug-in (1162). "reload=scalemap" asks for scalemap.txt to be read
   again: the one setting the settings window can apply to a running rack -- the next scale lookup reloads it. */
static void cmd_side_effects(const char* line){
    if(!strstr(line,"reload=scalemap")) return;
    if(g_csInit) EnterCriticalSection(&g_cs);
    g_grpLoaded=0;
    LOG("cmd: scalemap.txt will be read again (changed in the settings window)");
    if(g_csInit) LeaveCriticalSection(&g_cs); }

#if AT_XHH_MANAGED
static HANDLE g_authPipe=INVALID_HANDLE_VALUE;
static ATCS_Claims g_authLease;
static int g_authInstalled=0;
static uint64_t g_authResumeAfter=0;
static uint64_t g_authSequences[4]={0},g_authRetuneSequence=0;
static ATCS_PauseBarrier g_pauseBarrier={0,1};
static void agent_publish_pause(int paused){
    InterlockedExchange(&g_parameterPaused,1);InterlockedIncrement(&g_parameterEpoch);agent_cancel_posted_writes();
    if(!paused)InterlockedExchange(&g_parameterPaused,0);
}
static int agent_pause_status(char* out,unsigned capacity){
    if(!out||capacity<128)return 0;
    int n=snprintf(out,capacity,"#pause sid=%s seq=%llu state=%d\n",g_authInstalled?g_authLease.sid:"",(unsigned long long)g_pauseBarrier.sequence,InterlockedCompareExchange(&g_parameterPaused,0,0)?1:0);
    return n>0&&(unsigned)n<capacity?n:0;
}
static char g_authDevice[65]="";
static int agent_policy_host(const ATCS_Claims* lease){
    /* The same signed process-identity policy applies to native x86, WOW64 and x64 racks. */
    wchar_t path[32768];DWORD n=GetModuleFileNameW(NULL,path,32768);return n&&n<32768&&!atcs_policy_path_denied(lease,1,path);
}
static int agent_policy_module(HMODULE module,const char* family){
    if(!g_authInstalled||!module)return 0;wchar_t path[32768];DWORD n=GetModuleFileNameW(module,path,32768);
    if(!n||n>=32768||atcs_policy_module_denied(&g_authLease,path,family))return 0;
    /* Renamed Antares modules are identified from metadata/content before probing,
       matching the existing PACE gate. Other family identities come from discovery. */
    if(atcs_policy_denied(&g_authLease,0,"antares")){char local[MAX_PATH];DWORD m=GetModuleFileNameA(module,local,MAX_PATH);if(!m||m>=MAX_PATH||path_is_antares(local))return 0;}
    return 1;
}
static int agent_policy_address(const void* address,const char* family){MEMORY_BASIC_INFORMATION info;return address&&VirtualQuery(address,&info,sizeof info)==sizeof info&&agent_policy_module((HMODULE)info.AllocationBase,family);}
static int agent_policy_ui_allowed(const void* address,const char* family){
    ATCS_LoaderRead read;if(g_ejecting||!read.snapshot||atcs_now()>=read.snapshot->policy.expires||!atcs_pid_alive(read.snapshot->policy.parent))return 0;
    MEMORY_BASIC_INFORMATION info;wchar_t path[32768];if(!address||VirtualQuery(address,&info,sizeof info)!=sizeof info)return 0;
    DWORD n=GetModuleFileNameW((HMODULE)info.AllocationBase,path,32768);return n&&n<32768&&!atcs_policy_module_denied(&read.snapshot->policy,path,family);
}

/* Runs only on the existing agent worker. No extra thread touches plug-ins or
   secret state. A short signed lease is mandatory even after a controller dies. */
static void agent_poll_authorization(){
    atcs_loader_collect();
    if(g_authPipe==INVALID_HANDLE_VALUE){g_authPipe=atcs_pipe_server(AT_BUILD);return;}
    BOOL connected=ConnectNamedPipe(g_authPipe,NULL);DWORD err=connected?0:GetLastError();
    if(!connected&&err!=ERROR_PIPE_CONNECTED&&err!=ERROR_NO_DATA)return;
    DWORD available=0;if(!PeekNamedPipe(g_authPipe,NULL,0,NULL,&available,NULL)||!available){if(err==ERROR_NO_DATA)DisconnectNamedPipe(g_authPipe);return;}
    unsigned char request[8+ATCS_PIPE_MAX];DWORD got=0,result=0;
    if(ReadFile(g_authPipe,request,sizeof request,&got,NULL)&&got>=8){
        DWORD magic=0,len=0,client=0;memcpy(&magic,request,4);memcpy(&len,request+4,4);
        ATCS_Claims lease;
        if(magic==ATCS_PIPE_MAGIC&&len==got-8&&len<=ATCS_PIPE_MAX&&atcs_pipe_peer(g_authPipe,1,0,&client)&&atcs_same_user_elevated(client)
           &&atcs_verify_token((const char*)request+8,len,atcs_creator(client),g_authDevice,&lease)&&atcs_pid_alive(lease.parent)&&agent_policy_host(&lease)){
            int same=g_authInstalled&&atcs_claims_equal(&lease,&g_authLease);
            int ownerFree=!g_authInstalled||!atcs_pid_alive(g_authLease.parent)||atcs_now()>=g_authLease.expires;
            int newer=lease.parent==g_authLease.parent&&lease.issued>g_authLease.issued;
            if(g_suspended&&lease.issued<=g_authResumeAfter)result=0;
            else if(same)result=1;
            else if((ownerFree||newer)&&atcs_loader_publish(&lease)){g_authLease=lease;g_authInstalled=1;memset(g_authSequences,0,sizeof g_authSequences);g_authRetuneSequence=0;g_pauseBarrier.sequence=0;g_pauseBarrier.paused=InterlockedCompareExchange(&g_parameterPaused,0,0)?1:0;agent_publish_pause(g_pauseBarrier.paused);result=1;
                if(g_csInit)LOG("authorization session=%s license=%s device=%s expires=%llu",lease.sid,lease.license,lease.device,(unsigned long long)lease.expires);}
            SecureZeroMemory(&lease,sizeof lease);
        }
    }
    DWORD wrote=0;WriteFile(g_authPipe,&result,4,&wrote,NULL);DisconnectNamedPipe(g_authPipe);SecureZeroMemory(request,sizeof request);
}
static ATC_NOINLINE int agent_lease_alive(){
    ATC_SPROTECT_BEGIN_1();
    if(!g_authInstalled||atcs_now()>=g_authLease.expires||!atcs_pid_alive(g_authLease.parent)||!agent_policy_host(&g_authLease)){
        if(g_authInstalled){SecureZeroMemory(g_authLease.key,32);atcs_loader_publish(NULL);}
        return 0;
    }return 1;
}
static int agent_open_command(const char* encoded,char* plain,unsigned cap){
    return agent_lease_alive()&&atcs_channel_open(g_authLease.key,3,g_authLease.sid,g_authLease.expires,encoded,(unsigned)strlen(encoded),&g_authSequences[3],plain,cap);
}
#endif
static void agent_apply_command(char* line,char* last,int allowRetune){
            if(g_ejecting)return;
            if(cmd_line_complete(line) && (AT_XHH_MANAGED||strcmp(line,last)!=0)){ strcpy(last,line); cmd_side_effects(line);
                int keySemi=-1; char scaleName[64]=""; char* k=strstr(line,"key="); char* s=strstr(line,"scale=");
                if(k) keySemi=atoi(k+4);
                  if(keySemi<0 || keySemi>11) keySemi=-1;   /* only 12 pitch classes exist; anything else
                                                               means "leave the key alone" rather than
                                                               driving a parameter out of range */
                if(s){ s+=6; int j=0; while(s[j]&&s[j]!='|'&&s[j]!='\n'&&s[j]!='\r'&&j<63){ scaleName[j]=s[j]; j++; } scaleName[j]=0; }
                { char* r=strstr(line,"retune="); char* hm=strstr(line,"humanize="); char* nv=strstr(line,"nvib="); char* au=strstr(line,"audiotype=");
                  g_fSpeed=-1;char* speed=strstr(line,"speed=");if(speed)g_fSpeed=clamp01(parse_num(speed+6));
                  g_fRet = r? clamp01(parse_num(r+7)) : -1; g_fHum = hm? clamp01(parse_num(hm+9)) : -1;
                    g_fNvb = nv? clamp01(parse_num(nv+5)) : -1; g_fAudio = au? atoi(au+10) : -1;
                  if(!allowRetune)g_fRet=g_fSpeed=-1;
                }
                parse_target(line);
                if(keySemi>=0||scaleName[0]||g_fRet>=0||g_fSpeed>=0||g_fHum>=0||g_fNvb>=0||g_fAudio>=0){ EnterCriticalSection(&g_cs); LOG("cmd: key=%d scale=%s ret=%.2f hum=%.2f nvb=%.2f audio=%d",keySemi,scaleName,g_fRet,g_fHum,g_fNvb,g_fAudio); do_set(keySemi,scaleName); write_status(); LeaveCriticalSection(&g_cs); }
            }
}
#if AT_XHH_MANAGED
static void agent_consume_commands(ATCS_Mailbox* ready,unsigned count,char* last){
        /* Consume the authenticated pause before any older parameter in this
           snapshot. A later fresh full target is the only resume operation. */
        for(unsigned i=0;i<count;i++)if(agent_lease_alive()&&atcs_mailbox_is_pause(&ready[i])&&atcs_mailbox_commit(&ready[i],g_authSequences)&&atcs_pause_barrier(&g_pauseBarrier,&ready[i])){agent_publish_pause(1);EnterCriticalSection(&g_cs);write_status();LeaveCriticalSection(&g_cs);}
        for(unsigned i=0;i<count;i++)if(agent_lease_alive()&&atcs_mailbox_commit(&ready[i],g_authSequences)){
            if(ready[i].slot==2){if(!atcs_mailbox_is_pause(&ready[i]))cmd_side_effects(ready[i].plain);continue;}
            int wasPaused=g_pauseBarrier.paused;
            if(atcs_pause_allows(&ready[i],&g_pauseBarrier)){if(wasPaused&&!g_pauseBarrier.paused)agent_publish_pause(0);agent_apply_command(ready[i].plain,last,atcs_mailbox_retune_allowed(&ready[i],&g_authRetuneSequence));}
        }
}
#endif
/* A zero callback counter misses pre-read pointers and the return tail after decrement.
   Never use it to authorize unmapping. One PINNED worker supports stop and resume. */

static void agent_cancel_posted_writes(){
    for(int i=0;i<UIQ;i++){LONG word=InterlockedCompareExchange(&g_uiQ[i].word,0,0);if(UIPH(word)==UIPH_POST)InterlockedCompareExchange(&g_uiQ[i].word,UIW(UIGEN(word),UIPH_FREE),word);}
}
static void agent_suspend(){
    if(g_suspended)return;
    InterlockedExchange(&g_ejecting,1);g_suspended=1;
    agent_cancel_posted_writes();ui_detach();crash_record_remove();
    remove_dll_notification();
    if(g_hookCsInit)EnterCriticalSection(&g_hookCs);
    while(InterlockedCompareExchange(&g_eatBusy,1,0)!=0)SwitchToThread();
    remove_eat_hooks();InterlockedExchange(&g_eatBusy,0);remove_factory_hooks();
    if(g_hookCsInit)LeaveCriticalSection(&g_hookCs);
    if(g_catchCsInit)EnterCriticalSection(&g_catchCs);
    remove_init_hooks(); /* setComponentHandler remains a read-only lifetime observer */
    if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);
    g_llHead=g_llTail;g_llFlag=0;
    DeleteFileA(g_statusPath);DeleteFileA(g_scalesPath);DeleteFileA(g_pendPath);
#if AT_XHH_MANAGED
    g_authResumeAfter=g_authLease.issued;atcs_loader_publish(NULL);g_authInstalled=0;SecureZeroMemory(g_authLease.key,sizeof g_authLease.key);
    memset(g_authSequences,0,sizeof g_authSequences);g_authRetuneSequence=0;g_pauseBarrier.sequence=0;g_pauseBarrier.paused=1;agent_publish_pause(1);
#endif
    LOG("agent safely stopped: no new parameter writes; PINNED image and read-only handler observer remain until rack exit");
}
static void agent_resume(){
    if(!g_suspended)return;
#if AT_XHH_MANAGED
    if(!agent_lease_alive()||g_authLease.issued<=g_authResumeAfter)return;
#endif
    agent_cancel_posted_writes();g_llHead=g_llTail;g_llFlag=0;
    /* Originals stayed published while stopped. Re-arm known component slots without
       touching controller handlers, whose observer tracked teardown throughout. */
    if(g_catchCsInit)EnterCriticalSection(&g_catchCs);
    for(int i=0;i<g_nIH;i++){void** vt=(void**)g_ihVtbl[i];DWORD op;if(vt&&agent_policy_address(vt)&&VirtualProtect(&vt[3],sizeof(void*),PAGE_EXECUTE_READWRITE,&op)){if(vt[3]==(void*)g_ihOrig[i])vt[3]=(void*)myInitialize;VirtualProtect(&vt[3],sizeof(void*),op,&op);}}
    if(g_catchCsInit)LeaveCriticalSection(&g_catchCs);
    if(g_hookCsInit)EnterCriticalSection(&g_hookCs);
    for(int i=0;i<g_nHooked;i++){IPluginFactoryVtbl* vt=(IPluginFactoryVtbl*)g_hookedVtbl[i];DWORD op;if(vt&&agent_policy_address(vt)&&VirtualProtect((void*)&vt->createInstance,sizeof(void*),PAGE_EXECUTE_READWRITE,&op)){if(vt->createInstance==g_hookedOrig[i])vt->createInstance=myCreateInstance;VirtualProtect((void*)&vt->createInstance,sizeof(void*),op,&op);}}
    if(g_hookCsInit)LeaveCriticalSection(&g_hookCs);
    InterlockedExchange(&g_ejecting,0);g_suspended=0;
    crash_record_install();install_dll_notification();
    LOG("agent resumed on the existing worker after fresh authorization");
}
static DWORD WINAPI worker(LPVOID){
    /* Claim the single-instance mutex FIRST, before anything on disk is touched.
       A second copy of the agent does get injected from time to time -- the controller re-injects a
       host it momentarily believed had exited -- and it is supposed to notice the mutex and unload
       again, harmlessly. It was not harmless: cb_startup() ran first, and it ends by clearing THIS
       process's pending marker. That marker belongs to the agent already running here, and if that
       agent happened to be probing a module at the time, its "I am about to touch this one" note was
       wiped by the copy on its way out -- so a real crash a moment later could not be attributed to
       any module, the circuit breaker would not fire, and the same plug-in would take the host down
       again on the next launch. The duplicate must touch nothing at all. */
    char mn[128]; snprintf(mn,sizeof mn,"Local\\at_agent_%lu",GetCurrentProcessId());
    g_once=CreateMutexA(NULL,TRUE,mn);
    if(!g_once||GetLastError()==ERROR_ALREADY_EXISTS){ if(g_once){CloseHandle(g_once);g_once=NULL;} FreeLibraryAndExitThread(g_self,0); }
#if AT_XHH_MANAGED
    if(!atcs_device_fingerprint(g_authDevice)){if(g_once){CloseHandle(g_once);g_once=NULL;}FreeLibraryAndExitThread(g_self,0);}
    /* Initial state is inert: no runtime files, scans or hooks until the signed
       lease arrived through the same-user ACL pipe from an elevated real child. */
    /* g_authLease.key starts random, not the implicit zero a static ATCS_Claims
       defaults to -- see the matching comment in the controller's WinMain. */
    atcs_random(g_authLease.key,sizeof g_authLease.key);
    while(!agent_lease_alive()){agent_poll_authorization();Sleep(50);}
#endif
    HMODULE pinnedSelf=NULL;
    if(!GetModuleHandleExA(0x1|0x4,(LPCSTR)g_self,&pinnedSelf)){if(g_once){CloseHandle(g_once);g_once=NULL;}FreeLibraryAndExitThread(g_self,0);}
    resolve_commdir();
    cb_startup();   /* process crash blacklist BEFORE touching any plugin */
    /* kill switch for the UI-thread write path (build 1144). Present -> behave exactly like 1143 and
       write on this thread. Only reason to use it is if a host turns out to dislike the subclass. */
    { char p_[MAX_PATH]; snprintf(p_,sizeof p_,"%s\\nouithread.txt",COMMDIR);
      FILE* f_=fopen_retry(p_,"r"); if(f_){ fclose(f_); g_uiOff=1;
          LOG("nouithread.txt present -> parameter writes stay on the worker thread (pre-1144 behaviour)"); } }
    InitializeCriticalSection(&g_cs); g_csInit=1; g_workerTid=GetCurrentThreadId();
    InitializeCriticalSection(&g_hookCs); g_hookCsInit=1;   /* before install_dll_notification: the EAT thunk uses it */
    InitializeCriticalSection(&g_catchCs); g_catchCsInit=1;
    { char hp[MAX_PATH]=""; const char* hb="?"; if(GetModuleFileNameA(NULL,hp,MAX_PATH)){ const char* b2=strrchr(hp,'\\'); hb=b2?b2+1:hp; }
      g_hostAgeAtLoad=ms_since_host_start();
      /* The build goes in the very first line (1151). A user reported a fix "not working" and the log
         could not say which agent was running: the behaviour matched the previous build, and nothing
         in agent.log -- nor in the controller's window -- showed a version. */
      LOG("agent loaded in pid %lu [%s] (combined VST2+VST3) build %d, %lu ms after the host process started",
          GetCurrentProcessId(),hb,AT_BUILD,(unsigned long)g_hostAgeAtLoad); }
#if AT_XHH_MANAGED
    LOG("authorization session=%s license=%s device=%s expires=%llu",g_authLease.sid,g_authLease.license,g_authLease.device,(unsigned long long)g_authLease.expires);
#endif
    crash_record_install();   /* from here on, a crash of this process leaves a CRASH line in agent.log */
    /* DEFAULT ON: FLAG-ONLY LoadLibraryExW hook -> when 电音11's module loads, the worker hooks its factory
       a moment later (outside the loader frame) and catches the controller at its first createInstance
       (approach 1, "catch-on-load", no re-add/scan). The re-add path (factory hook + pin on scan, approach 2)
       stays active too. The notification itself never touches the plug-in; since 1091 the callback
         also redirects the GetPluginFactory export, but only for modules on the cleared list. */
    install_dll_notification(); LOG("catch-on-load (approach 1) + re-add (approach 2) both ACTIVE");
    char last[4096]=""; DWORD lastScan=0;   /* must be as large as the cmd line buffer */
    for(;;){
        handler_worker_drain();
#if AT_XHH_MANAGED
        agent_poll_authorization();
        if(!agent_lease_alive()){Sleep(100);continue;}
        if(g_suspended){agent_resume();last[0]=0;lastScan=0;}
#else
        if(g_suspended){if(GetFileAttributesA(g_ejectPath)!=INVALID_FILE_ATTRIBUTES){Sleep(100);continue;}agent_resume();last[0]=0;lastScan=0;}
#endif
        while(g_llHead!=g_llTail){ HMODULE base=g_llQ[g_llHead]; g_llHead=(g_llHead+1)&(LLQ-1);
            if(g_llHead==g_llTail) g_llFlag=0;
            HMODULE pinned=NULL;
            /* GET_MODULE_HANDLE_EX_FLAG_PIN|FROM_ADDRESS: validates the module is STILL loaded (returns FALSE if it
               was unloaded, e.g. during a plugin scan) AND pins it -> we then use the validated 'pinned' handle,
               never the possibly-stale base address. */
            if(base && agent_policy_module(base) && GetModuleHandleExA(0x1|0x4,(LPCSTR)base,&pinned) && pinned){
                char pth[MAX_PATH]=""; GetModuleFileNameA(pinned,pth,MAX_PATH);
                EnterCriticalSection(&g_cs);
                log_arm();
                /* report what the loader-lock callback did (it cannot log from in there) */
                int eix=-1; for(int k=0;k<g_nEat;k++) if(g_eat[k].mod==pinned){ eix=k; break; }
                if(eix>=0 && g_eat[eix].slot){
                    LOG("catch-on-load: EAT hook armed on GetPluginFactory -> the host's own call will be "
                        "intercepted, so the hook is in place BEFORE the first instance (no re-add): %s",pth);
                } else {
                    static const char* why[9]={"ok","disabled by noeat.txt","hook table full","already hooked",
                                               "GetPluginFactory export not found","no free memory within 4GB of the module",
                                               "export table not writable","another module was being hooked at the same moment",
                                               "the agent was unloading"};
                    int st=(g_eatFailMod==pinned)?(int)g_eatFailSt:-1;
                    int eatElig=module_in(pth,EAT_CLEARED);
                    if(eatElig)
                        LOG("catch-on-load: EAT hook NOT armed (%s) -> falling back to the late factory hook "
                            "(a plug-in added right now may need one remove/re-add): %s",
                            (st>=0&&st<9)?why[st]:"not attempted",pth);
                    LOG("catch-on-load: catch module loaded -> hooking factory NOW (worker): %s",pth);
                    hook_factory(pinned,pth);
                }
                LeaveCriticalSection(&g_cs);
            } }
        DWORD now=GetTickCount();
        DWORD interval = (g_nv2+g_nv3)==0 ? 1200u : 2000u;  /* hunt fast when empty; still brisk once found so new plugins show quickly */
        if(now-lastScan>interval){ lastScan=now; EnterCriticalSection(&g_cs); scan_all(); LeaveCriticalSection(&g_cs); }
        FILE* ej=fopen(g_ejectPath,"r");
        int ejectValid=ej!=NULL;
#if AT_XHH_MANAGED
        if(ej){char encoded[4096]="",decoded[1024]="";fgets(encoded,sizeof encoded,ej);ejectValid=agent_open_command(encoded,decoded,sizeof decoded)&&strstr(decoded,"eject=1|")!=NULL;}
#endif
        if(ej)fclose(ej);
        if(ejectValid){agent_suspend();last[0]=0;continue;}
        /* Read the three mailboxes as one snapshot. Authenticate first, then
           consume by sequence; fixed filename order could otherwise consume a
           new key before an older still-pending scale-map reload. */
#if AT_XHH_MANAGED
        char envelopes[3][4096];const char* inputs[3];unsigned lengths[3];
        for(unsigned slot=0;slot<3;slot++){
            envelopes[slot][0]=0;char path[MAX_PATH];
            snprintf(path,sizeof path,"%s\\%s",COMMDIR,slot==0?"cmd.ini":slot==1?"feel.ini":"control.ini");
            FILE* f=fopen(path,"r");if(f){fgets(envelopes[slot],sizeof envelopes[slot],f);fclose(f);}
            inputs[slot]=envelopes[slot];lengths[slot]=(unsigned)strlen(envelopes[slot]);
        }
        ATCS_Mailbox ready[3];memset(ready,0,sizeof ready);
        unsigned count=atcs_mailbox_decode(g_authLease.key,g_authLease.sid,g_authLease.expires,g_authSequences,inputs,lengths,3,ready,3);
        agent_consume_commands(ready,count,last);
        atcs_wipe(ready,sizeof ready);atcs_wipe(envelopes,sizeof envelopes);
#else
        FILE* f=fopen(g_cmdPath,"r");if(f){char line[4096]="";fgets(line,sizeof line,f);fclose(f);agent_apply_command(line,last,1);}
#endif
        Sleep(100);
    }
    return 0;
}
BOOL WINAPI DllMain(HINSTANCE h,DWORD r,LPVOID){ if(r==DLL_PROCESS_ATTACH){ g_self=h;
        g_logTick0=GetTickCount(); { DWORD a=ms_since_host_start(); g_logHostMs0=(a==0xFFFFFFFF)?0:a; }   /* log time base: kernel32 only, safe here */
        DisableThreadLibraryCalls(h); HANDLE th=CreateThread(NULL,0,worker,NULL,0,NULL);if(th)CloseHandle(th);} return TRUE; }
