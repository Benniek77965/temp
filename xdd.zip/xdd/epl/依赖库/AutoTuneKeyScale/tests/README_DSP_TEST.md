# DSP 运行验证工具 (dsptest)

验证"控制器→agent→setParameter→插件→实际音高输出"全链路对 **VST2** 版 Auto-Tune(电音4/5/6 等)是否真正改变音高。

## 原理
- `dsptest.exe` 载入一个 VST2 Auto-Tune 插件,持续喂一个正弦音(默认 270Hz,介于 C 与 C# 之间),
  用自相关测输出基频;看到 `measure.now` 触发文件就渲染 ~1.5s 并把输出音高写入 `pitch.txt`。
- 配合 agent:注入 agent 后,往 COMMDIR 写 `cmd.ini`(`key=N|scale=名|t=序号`),agent 会把 key/scale
  设进插件;再触发测量,即可看到输出音高按音阶吸附到最近的音。

## 构建
- 32 位(电音4/5/6 多为 32 位):`i686-w64-mingw32-gcc -O2 -o dsptest.exe dsptest.c -static -lm`
- 64 位:`x86_64-w64-mingw32-gcc -O2 -o dsptest.exe dsptest.c -static -lm`

## 用法(真机)
1. `dsptest.exe <插件.dll> [输入频率Hz]`(先记下它打印的 `Key=` / `Scale=` 参数索引、READY)。
2. 用控制器自带的注入器把 agent 注入到 dsptest 进程(或让控制器把 dsptest 当宿主)。
3. 写 `cmd.ini`(例 `key=0|scale=Chromatic|t=1`)到 COMMDIR,等 2-3 秒让 agent 应用。
4. 新建空文件 `measure.now`(与 pitch.txt 同目录,即 dsptest 的工作目录/C:\vt32),等 `pitch.txt` 出现,读出输出音高。
5. 改 `cmd.ini` 的 scale/key + 新 `t=`,重复第 3-4 步对比。

## 已验证结果(真实 dianyin5 / AT5,输入 270Hz)
| 设置 | 预期最近音 | 实测输出 |
|---|---|---|
| key=C, Chromatic | C# 277.2 | **277.4 Hz** ✓ |
| key=C, Major(无C#) | C 261.6 | **260.9 Hz** ✓ |
| 切回 Chromatic | C# 277.2 | **277.4 Hz** ✓ |

输入 290Hz(介于 C# 与 D):
| 设置 | 预期最近音 | 实测输出 |
|---|---|---|
| key=C, Major(含D无C#) | D 293.7 | **294.0 Hz** ✓ |
| key=C#, Major(含C#无D) | C# 277.2 | **277.4 Hz** ✓ |
| 回 key=C, Major | D 293.7 | **294.0 Hz** ✓ |

说明:VST3 版(电音9/X10/11)用的是 VST3 API(setParamNormalized),与此工具的 VST2 路径不同,但 agent 的
key/scale 应用机制同理;此工具用于验证 VST2 链路。
