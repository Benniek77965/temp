/* 大小写折叠必须只按 ASCII 规则,否则换个区域设置就会匹配失败 */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include "t_case_funcs.inc"
static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)
static void fold(const char* in,char* out,int ascii_only){
  int i=0; for(;in[i];i++) out[i] = ascii_only ? (char)at_lower((unsigned char)in[i])
                                               : (char)tolower((unsigned char)in[i]);
  out[i]=0;
}
int main(void){
  char b[256];
  printf("== 1. 常规 ASCII 折叠必须正确 ==\n");
  fold("WaveShell-VST3 9.6_x64.vst3",b,1);
  CK(!strcmp(b,"waveshell-vst3 9.6_x64.vst3"), "WaveShell-VST3 -> waveshell-vst3");
  CK(at_stricmp("Scale Root","SCALE ROOT")==0, "_stricmp 等价比较");
  CK(at_stricmp("Note Transition","Note Transitio")>0, "不等时返回非零");

  printf("\n== 2. 非 ASCII 字节必须【原样保留】(GBK 路径的中文字节)==\n");
  /* "电音11.vst3" 的 GBK 字节 */
  const char gbk[]="\xB5\xE7\xD2\xF4" "11.vst3";
  fold(gbk,b,1);
  CK(memcmp(b,gbk,4)==0, "中文字节 B5 E7 D2 F4 未被改动");
  CK(strstr(b,"11.vst3")!=NULL, "catch 判据 '11.vst3' 仍能命中");
  /* 对照:若按 Latin-1 规则折叠,0xC0-0xDE 会被改掉 */
  { const char latin[]="\xC4\xD6" "11.vst3"; char c[64];
    for(int i=0;latin[i];i++) c[i]=(char)((unsigned char)latin[i]>=0xC0 && (unsigned char)latin[i]<=0xDE
                                          ? (unsigned char)latin[i]+32 : latin[i]);
    c[strlen(latin)]=0;
    printf("   对照:按 Latin-1 规则折叠 C4 D6 会变成 %02X %02X <- 中文字节被破坏\n",
           (unsigned char)c[0],(unsigned char)c[1]);
    char d[64]; fold(latin,d,1);
    CK((unsigned char)d[0]==0xC4 && (unsigned char)d[1]==0xD6, "我们的折叠保持 C4 D6 不变"); }

  printf("\n== 3. 土耳其 I 问题(dawhost 片段里就有 \"live\")==\n");
  fold("LIVE.EXE",b,1);
  CK(!strcmp(b,"live.exe"), "LIVE.EXE -> live.exe(含 I 也正确)");
  CK(strstr(b,"live")!=NULL, "能匹配到 'live' 片段");
  printf("   (土耳其区域下 tolower('I') 会得到无点的 'ı',上面这条就会失败)\n");

  printf("\n失败数: %d\n",fails); return fails?1:0;
}
