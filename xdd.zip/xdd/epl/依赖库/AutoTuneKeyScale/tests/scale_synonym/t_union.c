#include "t_scale_funcs.inc"
#include "t_lists.inc"            /* 从真机日志自动生成,不再手打 */
static char seen[256][48]; static int ns=0;
static void add(const char* d){ const char* cn=scale_canon(d); const char* o=cn?cn:d;
  char n[48]; norm(o,n,sizeof n);
  for(int i=0;i<ns;i++) if(!strcmp(seen[i],n)) return;
  snprintf(seen[ns],48,"%s",n); ns++; }
static int count(const char** L){ ns=0; for(int i=0;L[i];i++) add(L[i]); return ns; }
int main(void){
  int np=0,nw=0; while(PRO[np])np++; while(WAV[nw])nw++;
  printf("  原始清单       : 电音11=%d, Waves=%d  (合计 %d)\n",np,nw,np+nw);
  printf("  电音11 单独下拉 : %d\n", count(PRO));
  printf("  Waves 单独下拉  : %d\n", count(WAV));
  ns=0; for(int i=0;PRO[i];i++) add(PRO[i]); int a=ns;
        for(int i=0;WAV[i];i++) add(WAV[i]); int both=ns;
  printf("  两个同挂下拉    : %d  (电音11 贡献 %d, Waves 新增 %d)\n", both, a, both-a);
  /* 对照:若没有同义词合并会是多少 */
  int exact=0; for(int i=0;WAV[i];i++){ char w[48]; norm(WAV[i],w,sizeof w);
      for(int j=0;PRO[j];j++){ char p[48]; norm(PRO[j],p,sizeof p); if(!strcmp(p,w)){exact++;break;} } }
  printf("  若只按原名去重  : %d  -> 同义词额外合并了 %d 项\n", np+nw-exact, (np+nw-exact)-both);
  printf("\n  预期与真机日志 'wrote %d unique scale names' 一致? %s\n", both, both==45?"是 ✓":"否 ✗");
  return both==45?0:1;
}
