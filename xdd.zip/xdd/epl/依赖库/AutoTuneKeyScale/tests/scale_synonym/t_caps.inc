static void caps_effective(char* effOut){
    char eff[16]="KSRHVA";
    int ti=g_testTarget;
    if(ti>0 && ti-1<g_ninst) snprintf(eff,sizeof eff,"%s",g_insts[ti-1].caps);
    else if(g_ninst>0){                                   /* intersection over every instance */
        int w=0; char all[16];
        for(const char* c="KSRHVA"; *c; c++){ int in=1;
            for(int i=0;i<g_ninst && in;i++) if(!strchr(g_insts[i].caps,*c)) in=0;
            if(in && w<15) all[w++]=*c; }
        all[w]=0; snprintf(eff,sizeof eff,"%s",all); }
    strcpy(effOut,eff);
}
