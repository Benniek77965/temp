/* 内置 catch 默认项不被用户列表挤掉(1128)

   catch.txt 是用户手写的,内置默认项(waveshell / t-pain / auto-tune / 11.vst3;auto-tune 在 1149 前是 auto-tune pro)
   曾经和用户的行【共用同一个 8 格数组】—— 用户写满,内置项就被挤出去。
   而丢掉它们不是小事:这些插件会掉出 catch 路径、不再装 EAT(需要重加),
   Antares 还会退回那条崩过、卡死过的探测路径。而且没有任何提示。

   1128 把内置项放进独立数组,is_catch_path 两个都查。 */
#include <stdio.h>
#include <string.h>
#include "t_catchcap_funcs.inc"

static int fails=0;
static void chk(const char* what,int got,int want){
    printf("   %-42s %-8s %s\n",what,got?"命中":"不命中",(got==want)?"OK":"FAIL");
    if(got!=want) fails++;
}
int main(void){
    /* 用户 catch.txt 写满 8 行,一个内置项的名字都没写 */
    const char* user[]={"myplg1","myplg2","myplg3","myplg4","myplg5","myplg6","myplg7","myplg8"};
    for(int i=0;i<8;i++){ strncpy(g_catchPat[g_nCatchPat],user[i],63); g_nCatchPat++; }

    printf("== 用户列表写满 8 行后,内置项仍必须生效 ==\n");
    chk("WaveShell",          is_catch_path("c:\\waveshell1-vst3 17.1.vst3"), 1);
    chk("The T-Pain Effect",  is_catch_path("c:\\the t-pain effect.vst3"),    1);
    chk("Auto-Tune Pro",      is_catch_path("c:\\auto-tune pro.vst3"),        1);
    chk("电音11(*11.vst3)",   is_catch_path("c:\\dianyin11.vst3"),            1);
    printf("\n== 所有 Antares Auto-Tune 都走捕获路径(1149) ==\n");
    /* MonsterApplication 闪退:断路器标记里是 Antares\Auto-Tune.vst3,Windows 记下 0xC000001D(非法指令),
       出错地址不属于任何模块 —— PACE 解密出的代码就在这种内存里跑。此前名单里只有 Auto-Tune Pro,
       其余 Antares 版本被探测。以下都是用户机器上真实出现过的路径(小写)。 */
    chk("Auto-Tune.vst3(电音9)",   is_catch_path("c:\\program files\\common files\\vst3\\antares\\auto-tune.vst3"), 1);
    chk("Auto-Tune_81.vst3(8.1)",  is_catch_path("c:\\program files\\common files\\vst3\\auto-tune_81.vst3"), 1);
    chk("Auto-Tune Pro(仍然命中)", is_catch_path("c:\\program files\\common files\\vst3\\antares\\auto-tune pro.vst3"), 1);
    chk("同系列其它名字",           is_catch_path("c:\\vst3\\antares\\auto-tune efx+.vst3"), 1);
    chk("不带连字符的第三方 autotune", is_catch_path("c:\\vst3\\mautopitch.vst3"), 0);
    printf("\n== 用户自己的项也仍在 ==\n");
    chk("用户 myplg3",        is_catch_path("c:\\myplg3.vst3"),               1);
    chk("用户 myplg8(第8行)", is_catch_path("c:\\myplg8.vst3"),               1);
    printf("\n== 无关插件不得命中 ==\n");
    chk("无关插件",           is_catch_path("c:\\some reverb.vst3"),          0);

    printf("\n== 加载通知必须用同一套判定(1143) ==\n");
    { /* EAT 钩子只在加载通知回调里安装。那里原先【自己抄了一遍】匹配逻辑,
         1128 把内置项移进独立数组时只改了 is_catch_path,漏了这一处:
         没有 catch.txt 时 g_nCatchPat==0,循环一次都不跑,于是对【所有】内置 catch 模块
         (T-Pain / WaveShell / Auto-Tune Pro / 电音11)通知直接 return —— EAT 永远装不上,
         每次都要移除重加。实测日志里连一行 EAT hook armed 都没有。 */
      const char* mods[]={"c:\\...\\the t-pain effect.vst3",
                          "c:\\...\\waveshell1-vst3 17.1_x64.vst3",
                          "c:\\...\\auto-tune pro.vst3",
                          "c:\\...\\dianyin11.vst3",0};
      /* 用户没有 catch.txt */
      g_nCatchPat=0;
      for(int i=0;mods[i];i++){
        int viaIsCatch = is_catch_path(mods[i]);
        /* 复刻通知里的判定:必须同时查两份清单 */
        int viaNotify=0;
        for(int k=0;g_catchBuiltin[k] && !viaNotify;k++) if(strstr(mods[i],g_catchBuiltin[k])) viaNotify=1;
        for(int k=0;k<g_nCatchPat && !viaNotify;k++) if(strstr(mods[i],g_catchPat[k])) viaNotify=1;
        int ok = viaIsCatch && viaNotify;
        printf("   %-34s is_catch=%d notify=%d  %s\n",mods[i]+8,viaIsCatch,viaNotify,ok?"OK":"FAIL");
        if(!ok){ printf("       两处判定必须一致 —— 不一致就意味着 EAT 钩子装不上。\n"); fails++; } } }

    printf("\n失败数: %d\n",fails);
    return fails?1:0;
}
