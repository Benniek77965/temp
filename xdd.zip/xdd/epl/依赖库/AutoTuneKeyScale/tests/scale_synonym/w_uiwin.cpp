/* 生产代码本体的 Windows 集成测试(1145)—— 只能在 Windows 或 Wine 下运行

   t_handoff 测的是交接协议的【模型】。这里直接 #include 生产源码,用真实窗口、真实消息循环、
   真实跨线程 PostMessage,跑 at_agent.cpp 里的原函数,一行都不抄:
     hook_setcomponenthandler / mySetComponentHandler_inner / uitid_of / handler_of /
     ui_attach / ui_detach / ui_post / at_wndproc / v3set / v3set_body / veh 的界面线程恢复点

   伪造的只有插件一侧:一个 IEditController 和一个 IComponentHandler,每次被调用都记下
   【是哪个线程】调的。断言的核心就是:performEdit 必须发生在宿主界面线程上,且每次写入恰好一次。

   为什么不命名为 t_*.c:它需要 windows.h、要链接 psapi/version/user32,而且源码是 C++,
   放进 `for t in t_*.c; do gcc ...` 的循环会在 Linux 上直接编译失败。

   Windows:  x86_64-w64-mingw32-g++ -O1 -w -o w_uiwin.exe w_uiwin.cpp -lpsapi -lversion -luser32 -static
             w_uiwin.exe
   Linux:    同上编译,然后  xvfb-run -a wine64 w_uiwin.exe   (Wine 无显示器时建不出窗口,需要 Xvfb) */
#include "../../combined/at_agent.cpp"
#include <stdio.h>
#include <string>
/* 第十九节用:扮演设置窗口,不停地「写临时文件 + 改名盖过去」 */
struct ReplArgs { volatile LONG stop; char path[MAX_PATH]; };
static DWORD WINAPI repl_writer(LPVOID p){ ReplArgs* a=(ReplArgs*)p; char tp[MAX_PATH]; snprintf(tp,sizeof tp,"%s.tmp",a->path); int i=0;
    while(!a->stop){ FILE* f=fopen(tp,"wb"); if(f){ fputs((i++&1)?"foo\r\nbar\r\n":"alpha\r\nbeta\r\ngamma\r\n",f); fclose(f); }
                     MoveFileExA(tp,a->path,MOVEFILE_REPLACE_EXISTING); }
    DeleteFileA(tp); return 0; }

/* ---------------- 伪造的插件:记录每次调用发生在哪个线程 ---------------- */
struct Rec { volatile LONG nSet, nBegin, nPerform, nEnd; volatile DWORD setTid, performTid; double v; };
static Rec rec[64]; static double pv[64];
static volatile LONG g_faultNext=0;
static tresult WINAPI f_qi(void*, const TUID, void**){ return kNoInterface; }
static uint32_t WINAPI f_ar(void*){ return 1; }
static tresult WINAPI f_z0(void*){ return kResultOk; }
static tresult WINAPI f_z1(void*, void*){ return kResultOk; }
static int32_t WINAPI f_cnt(void*){ return 0; }
static tresult WINAPI f_info(void*, int32_t, ParameterInfo*){ return kInvalidArgument; }
static tresult WINAPI f_str(void*, ParamID, ParamValue, String128){ return kInvalidArgument; }
static tresult WINAPI f_val(void*, ParamID, char16*, ParamValue*){ return kInvalidArgument; }
static ParamValue WINAPI f_n2p(void*, ParamID, ParamValue v){ return v; }
static ParamValue WINAPI f_get(void*, ParamID id){ return pv[id&63]; }
static tresult WINAPI f_set(void*, ParamID id, ParamValue v){ id&=63; pv[id]=v; InterlockedIncrement(&rec[id].nSet); rec[id].setTid=GetCurrentThreadId(); return kResultOk; }
static tresult WINAPI f_setch(void*, void*){ return kResultOk; }        /* 原版 setComponentHandler,会被 hook 掉 */
static void* WINAPI f_view(void*, const char*){ return NULL; }
static IEditControllerVtbl ctlVt = { f_qi,f_ar,f_ar, f_z1,f_z0,f_z1,f_z1,f_z1, f_cnt,f_info,f_str,f_val,f_n2p,f_n2p, f_get,f_set,f_setch,f_view };
static IEditController ctl = { &ctlVt };

static tresult WINAPI h_begin(void*, ParamID id){ InterlockedIncrement(&rec[id&63].nBegin); return kResultOk; }
static volatile LONG g_slowPerform=0;
static tresult WINAPI h_perform(void*, ParamID id, ParamValue v){
    if(InterlockedExchange(&g_faultNext,0)) *(volatile int*)0 = 1;       /* 插件在界面线程上崩 */
    if(g_slowPerform) Sleep(5);                                          /* 停留,制造与 worker 的交错窗口 */
    id&=63; InterlockedIncrement(&rec[id].nPerform); rec[id].performTid=GetCurrentThreadId(); rec[id].v=v; return kResultOk; }
static tresult WINAPI h_end(void*, ParamID id){ InterlockedIncrement(&rec[id&63].nEnd); return kResultOk; }
static tresult WINAPI h_restart(void*, int32_t){ return kResultOk; }
/* The fake handler lives for the whole host process, but exercises real
   FUnknown ownership: production map bindings own AddRef/Release pairs. */
static volatile LONG handlerRefs=1,handlerAdds=0,handlerReleases=0,handlerBadRefs=0;
static uint32_t WINAPI h_ar(void*){InterlockedIncrement(&handlerAdds);return (uint32_t)InterlockedIncrement(&handlerRefs);}
static uint32_t WINAPI h_rl(void*){InterlockedIncrement(&handlerReleases);LONG n=InterlockedDecrement(&handlerRefs);if(n<1)InterlockedIncrement(&handlerBadRefs);return (uint32_t)n;}
static IComponentHandlerVtbl hVt = { f_qi,h_ar,h_rl, h_begin,h_perform,h_end,h_restart };
static IComponentHandler handlerObj = { &hVt };
static void* H = &handlerObj;

/* 带真实引用计数的伪控制器(第十三节用):重现 LiveProfessor 的探测实例 —— 宿主建了又销毁,
   只剩 agent 自己的那一份引用。release 到 0 时记一笔,用来确认生产代码真的把它放掉了。 */
struct RcCtl { const IEditControllerVtbl* vtbl; volatile LONG rc; volatile LONG freed; };
static uint32_t WINAPI rc_ar(void* p){ return (uint32_t)InterlockedIncrement(&((RcCtl*)p)->rc); }
static uint32_t WINAPI rc_rl(void* p){ LONG n=InterlockedDecrement(&((RcCtl*)p)->rc); if(n==0) InterlockedExchange(&((RcCtl*)p)->freed,1); return (uint32_t)n; }
static IEditControllerVtbl rcVt = { f_qi,rc_ar,rc_rl, f_z1,f_z0,f_z1,f_z1,f_z1, f_cnt,f_info,f_str,f_val,f_n2p,f_n2p, f_get,f_set,f_setch,f_view };

/* 第十五节用:让本测试程序自己导出 GetPluginFactory,扮演一个 VST3 模块(exe 也可以有导出表) */
extern "C" __declspec(dllexport) void* GetPluginFactory(void){ return NULL; }
static ULONG image_size(HMODULE m){ IMAGE_DOS_HEADER* d=(IMAGE_DOS_HEADER*)m; IMAGE_NT_HEADERS* n=(IMAGE_NT_HEADERS*)((char*)m+d->e_lfanew); return n->OptionalHeader.SizeOfImage; }

/* ---------------- 宿主界面线程:真窗口 + 真消息循环 ---------------- */
#define WM_T_BUSY  (WM_APP+1)    /* wParam = 堵住多少 ms,模拟宿主正在加载工程 */
#define WM_T_SETH  (WM_APP+2)    /* lParam = handler(可为 NULL),在【本线程】上调 setComponentHandler */
#define WM_T_REWND (WM_APP+3)    /* 销毁窗口再新建一个 */
#define WM_T_QUIT  (WM_APP+4)
#define WM_T_FENCE (WM_APP+5)    /* 栅栏:置位 fenceEv */
#define WM_T_TRACE (WM_APP+7)   /* ordinary forwarding must reach this host callback */
static volatile LONG hostTrace=0;
#define WM_T_REWND2 (WM_APP+6)   /* 销毁窗口再新建一个,不发事件 —— 宿主自己在界面线程上做的合法动作 */
static volatile DWORD uiTid=0; static HWND volatile hostWnd=NULL; static HANDLE readyEv, fenceEv;
static WNDPROC hostProcPtr=NULL;
static LRESULT CALLBACK hostProc(HWND h, UINT m, WPARAM w, LPARAM l){
    if(m==WM_T_BUSY){ Sleep((DWORD)w); return 0; }
    if(m==WM_T_SETH){ IEditController* target=w?(IEditController*)w:&ctl;target->vtbl->setComponentHandler(target,(void*)l); return 0; }
    if(m==WM_T_TRACE){InterlockedIncrement(&hostTrace);return 0x6415;}
    if(m==WM_T_REWND){ DestroyWindow(h);
        hostWnd=CreateWindowW(L"HostT",L"host",WS_OVERLAPPEDWINDOW|WS_VISIBLE,0,0,40,40,0,0,0,0); SetEvent(readyEv); return 0; }
    if(m==WM_T_QUIT){ PostQuitMessage(0); return 0; }
    if(m==WM_T_FENCE){ SetEvent(fenceEv); return 0; }
    if(m==WM_T_REWND2){ DestroyWindow(h);
        hostWnd=CreateWindowW(L"HostT",L"host",WS_OVERLAPPEDWINDOW|WS_VISIBLE,0,0,40,40,0,0,0,0); return 0; }
    return DefWindowProcW(h,m,w,l); }
static DWORD WINAPI uiThread(LPVOID){
    uiTid=GetCurrentThreadId();
    WNDCLASSW wc={0}; wc.lpfnWndProc=hostProc; wc.lpszClassName=L"HostT"; RegisterClassW(&wc);
    hostProcPtr=hostProc;
    hostWnd=CreateWindowW(L"HostT",L"host",WS_OVERLAPPEDWINDOW|WS_VISIBLE,0,0,40,40,0,0,0,0);
    SetEvent(readyEv);
    MSG msg; while(GetMessageW(&msg,0,0,0)>0){ TranslateMessage(&msg); DispatchMessageW(&msg); }
    return 0; }
/* 等宿主线程把此前投递的消息全部处理完。
   栅栏必须也是【投递】消息:投递消息之间先进先出。第一版用 SendMessage(WM_NULL) 做栅栏是错的 ——
   跨线程发送的消息比投递的消息优先分派(GetMessage 先处理已发送的),栅栏会提前放行。
   后果不只是偶发失败:第五节"迟到的消息被拒绝、没有双写"那条断言会在消息还没处理时就检查,
   双写了也照样通过,等于空断言。 */
static void ui_fence(){ ResetEvent(fenceEv); PostMessageW(hostWnd,WM_T_FENCE,0,0); WaitForSingleObject(fenceEv,5000); }
static void ui_do(UINT m, WPARAM w, LPARAM l){ PostMessageW(hostWnd,m,w,l); ui_fence(); }

/* 捣乱线程:与 worker 的写入真正并发地反复 detach/attach(第十一节用)。
   worker 的 v3set 是同步等界面线程完成的,所以单靠 worker 自己 detach 打不开交错窗口 ——
   必须由第三个线程在界面线程正卡在 performEdit 的 Sleep 里时去 detach。 */
/* 宿主侧并发:后台线程不停让宿主在【它自己的界面线程上】销毁并重建窗口。
   这是宿主的合法行为,与 worker 的写入真正并发。注意它只投递消息,不碰 ui_attach/ui_detach ——
   那两个函数按契约只由 worker 调用(上一版这里从第三个线程直接调它们,测的是未定义行为,
   32 位下约四分之三的概率把 g_uiOrig 弄成指向 at_wndproc 自己,随后栈溢出。见 1145_说明.md)。 */
static volatile LONG g_churn=0;
static DWORD WINAPI churnThread(LPVOID){
    while(!g_churn) Sleep(0);
    while(g_churn==1){ HWND w=hostWnd; if(w) PostMessageW(w,WM_T_REWND2,0,0); Sleep(3); }
    return 0; }

/* 一个没有任何窗口的线程:有的宿主在加载线程而不是界面线程上调 setComponentHandler */
static HANDLE noWndGo, noWndDone, noWndExit;
static DWORD WINAPI noWndThread(LPVOID){
    WaitForSingleObject(noWndGo,INFINITE);
    ctl.vtbl->setComponentHandler(&ctl,H);              /* 记下的线程号会是本线程 */
    SetEvent(noWndDone);
    WaitForSingleObject(noWndExit,INFINITE); return 0; }

/* ---------------- 断言 ---------------- */
static int fails=0;
static void ck(int ok, const char* what){ printf("   %-4s %s\n", ok?"OK":"FAIL", what); if(!ok) fails++; }
static char logbuf[1<<20];
static int log_count(const char* s){ fflush(g_log); FILE* f=fopen("w_uiwin.log","rb"); if(!f) return -1;
    size_t n=fread(logbuf,1,sizeof logbuf-1,f); logbuf[n]=0; fclose(f);
    int c=0; for(char* p=logbuf; (p=strstr(p,s))!=NULL; p+=strlen(s)) c++; return c; }

int main(){
    DeleteFileA("w_uiwin.log");
    snprintf(g_logPath,sizeof g_logPath,"w_uiwin.log"); log_arm();
    InitializeCriticalSection(&g_cs); g_csInit=1; g_workerTid=GetCurrentThreadId();   /* 本线程扮演 worker */
    InitializeCriticalSection(&g_hookCs); g_hookCsInit=1;
    InitializeCriticalSection(&g_catchCs); g_catchCsInit=1;
    g_veh=AddVectoredExceptionHandler(1,veh);
    readyEv=CreateEventW(0,FALSE,FALSE,0); fenceEv=CreateEventW(0,TRUE,FALSE,0);
    HANDLE ut=CreateThread(0,0,uiThread,0,0,0); WaitForSingleObject(readyEv,INFINITE);
    DWORD me=GetCurrentThreadId();
    printf("worker 线程 %lu,宿主界面线程 %lu\n\n",(unsigned long)me,(unsigned long)uiTid);

    printf("== 一、handler 由宿主界面线程装上,生产代码记下的线程号要对 ==\n");
    hook_setcomponenthandler(&ctl);                      /* 真钩子:patch 伪 controller 的 vtable slot 16 */
    ck(ctl.vtbl->setComponentHandler==mySetComponentHandler, "setComponentHandler 已被生产代码挂钩");
    ui_do(WM_T_SETH,0,(LPARAM)H);                        /* 在界面线程上调,走 mySetComponentHandler_inner */
    ck(handler_of(&ctl)==H, "handler_of 返回宿主装上的 handler");
    ck(uitid_of(&ctl)==uiTid, "uitid_of 记下的是宿主界面线程");
    { CHBinding* binding=handler_binding_acquire(&ctl);
      ck(binding&&binding->handler==H, "真实setter建立map-owned binding（不是只填旧raw handler字段）");
      handler_binding_release(binding);
      ck(handlerRefs==2&&handlerAdds==1, "map持有一个真实FUnknown引用，host原引用保留"); }

    printf("\n== 二、常规写入:200 次,performEdit 必须全部在界面线程上、每次恰好一次 ==\n");
    { int wrongThread=0, wrongCount=0, wrongVal=0;
      for(int i=0;i<200;i++){ int id=i%8; LONG before=rec[id].nPerform; double v=(i+1)/1000.0;
          v3set(&ctl,H,(ParamID)id,v);
          if(rec[id].performTid!=uiTid || rec[id].setTid!=uiTid) wrongThread++;
          if(rec[id].nPerform!=before+1) wrongCount++;
          if(rec[id].v!=v || pv[id]!=v) wrongVal++; }
      char w[160];
      snprintf(w,sizeof w,"200 次写入的 setParamNormalized/performEdit 线程全部是界面线程(偏差 %d)",wrongThread); ck(wrongThread==0,w);
      snprintf(w,sizeof w,"每次写入 performEdit 恰好 +1(偏差 %d)",wrongCount); ck(wrongCount==0,w);
      snprintf(w,sizeof w,"写入值正确(偏差 %d)",wrongVal); ck(wrongVal==0,w);
      int b=0,e=0; for(int id=0;id<8;id++){ b+=rec[id].nBegin; e+=rec[id].nEnd; }
      snprintf(w,sizeof w,"beginEdit/endEdit 成对(%d / %d)",b,e); ck(b==200&&e==200,w);
      ck(GetWindowLongPtrW(hostWnd,GWLP_WNDPROC)==(LONG_PTR)at_wndproc, "宿主窗口已被子类化为 at_wndproc");
      ck(log_count("UI-thread writes: subclassed window")==1, "只子类化一次(不是每次写都重挂)"); }

    printf("\n== 三、投递后、执行前宿主清掉了 handler:执行时必须重取,不得用旧指针 ==\n");
    { PostMessageW(hostWnd,WM_T_BUSY,150,0);             /* 界面线程先忙 150ms(小于 400ms 截止) */
      PostMessageW(hostWnd,WM_T_SETH,0,0);               /* 忙完先清 handler —— 和真实的移除插件同一顺序 */
      LONG p0=rec[20].nPerform, s0=rec[20].nSet;
      v3set(&ctl,H,20,0.5);                              /* 投递时 handler 还在 */
      ck(rec[20].nSet==s0, "required handler已清除时连setParamNormalized也不开始，等待实际回读重试");
      ck(rec[20].nPerform==p0, "performEdit 没有被调用(用的是执行时重取的 NULL,而不是投递时的旧指针)");
      ui_do(WM_T_SETH,0,(LPARAM)H);
      ck(handler_of(&ctl)==H, "handler 恢复"); }

    printf("\n== 四、插件在界面线程上崩:VEH 第二恢复点必须接住,宿主线程继续泵消息 ==\n");
    { InterlockedExchange(&g_faultNext,1);
      LONG p0=rec[30].nPerform;
      v3set(&ctl,H,30,0.3);
      ck(rec[30].nPerform==p0, "崩溃发生在 performEdit 计数之前(确实走到了故障点)");
      ck(log_count("faulted on the UI thread (recovered)")>=1, "日志记录了界面线程上的故障并已恢复");
      ck(g_uiProbing==0, "g_uiProbing 已复位(否则之后宿主自己的异常会被我们劫持)");
      LONG q0=rec[31].nPerform; v3set(&ctl,H,31,0.31);
      ck(rec[31].nPerform==q0+1 && rec[31].performTid==uiTid, "崩溃之后界面线程照常工作,下一次写入正常"); }

    printf("\n== 五、界面线程堵过截止时刻:收回、退回 worker、绝不双写、退让后恢复 ==\n");
    { PostMessageW(hostWnd,WM_T_BUSY,900,0);             /* 堵 900ms,远超 400ms 截止 */
      LONG p0=rec[40].nPerform;
      v3set(&ctl,H,40,0.4);
      ck(rec[40].nPerform==p0+1 && rec[40].performTid==me, "超时后这一次由 worker 写");
      ck(g_uiCooling==1, "进入退让");
      ck(log_count("did not pump within")>=1, "日志说明了超时与退让");
      ui_fence();                                        /* 等界面线程忙完,并且【确定】已处理掉那条迟到的消息 */
      ck(rec[40].nPerform==p0+1, "迟到的那条消息已被分派且被拒绝:总共只写了一次,没有双写");
      ck(UIPH(g_uiQ[(g_uiSlot+UIQ-1)%UIQ].word)==UIPH_FREE, "那个槽位停在 FREE(被 worker 收回,界面线程的 CAS 没抢到)");
      LONG q0=rec[41].nPerform; v3set(&ctl,H,41,0.41);
      ck(rec[41].nPerform==q0+1 && rec[41].performTid==me, "退让期间直接由 worker 写,不再等");
      g_uiCoolAt -= (DWORD)(UICOOL_MS+1000);               /* 让退让期过去 */
      LONG r0=rec[42].nPerform; v3set(&ctl,H,42,0.42);
      ck(rec[42].nPerform==r0+1 && rec[42].performTid==uiTid, "退让期过后自动回到界面线程");
      ck(log_count("back-off over")>=1, "日志说明了恢复"); }

    printf("\n== 六、宿主窗口被销毁重建:重新挑窗口挂上 ==\n");
    { PostMessageW(hostWnd,WM_T_REWND,0,0); WaitForSingleObject(readyEv,INFINITE); ui_fence();
      LONG p0=rec[50].nPerform; v3set(&ctl,H,50,0.5);
      ck(rec[50].nPerform==p0+1 && rec[50].performTid==uiTid, "新窗口上写入仍在界面线程");
      ck(log_count("UI-thread writes: subclassed window")==2, "重新子类化了一次(新窗口)"); }

    printf("\n== 七、逻辑停用选择:保留只读窗口观察与普通消息转发 ==\n");
    { HWND window=g_uiWnd;ATUI_Route* route=atui_find(window);WNDPROC original=route?route->original:NULL;
      ui_detach();
      ck(GetWindowLongPtrW(window,GWLP_WNDPROC)==(LONG_PTR)at_wndproc, "PIN observer保留，没有物理还原/解映射");
      ck(g_uiWnd==NULL&&g_uiWndTid==0, "worker写入窗口选择已清空");
      ck(route&&atui_epoch_live(route)&&route->original==original, "每HWND原始过程和epoch仍保留");
      LONG trace=hostTrace;ui_do(WM_T_TRACE,0,0);
      ck(hostTrace==trace+1, "停用选择后普通消息仍转发给真实宿主"); }

    printf("\n== 八、nouithread.txt(g_uiOff):完全退回 worker 写入 ==\n");
    { g_uiOff=1; LONG p0=rec[61].nPerform; v3set(&ctl,H,61,0.61);
      ck(rec[61].nPerform==p0+1 && rec[61].performTid==me, "开关生效时由 worker 写(1143 行为)");
      g_uiOff=0; }

    printf("\n== 九、handler 是在没有窗口的线程上装的:找不到窗口,退回 worker,并说出原因 ==\n");
    { noWndGo=CreateEventW(0,FALSE,FALSE,0); noWndDone=CreateEventW(0,FALSE,FALSE,0); noWndExit=CreateEventW(0,TRUE,FALSE,0);
      HANDLE nt=CreateThread(0,0,noWndThread,0,0,0); SetEvent(noWndGo); WaitForSingleObject(noWndDone,INFINITE);
      ck(uitid_of(&ctl)==GetThreadId(nt), "记下的是那个无窗口线程");
      int before=log_count("owns no window");
      LONG p0=rec[62].nPerform; v3set(&ctl,H,62,0.62);
      ck(rec[62].nPerform==p0+1 && rec[62].performTid==me, "找不到窗口时由 worker 写(不丢写入)");
      ck(log_count("owns no window")==before+1, "日志打出了排查指南里写的那行 owns no window");
      SetEvent(noWndExit); WaitForSingleObject(nt,3000);
      ui_do(WM_T_SETH,0,(LPARAM)H);                      /* 交还给界面线程 */
      ck(uitid_of(&ctl)==uiTid, "交还后线程号回到界面线程"); }

    printf("\n== 十、选择切换:worker 反复 detach/attach,只读观察记录保持 ==\n");
    { InterlockedExchange(&g_slowPerform,1);
      /* 让界面线程每条写入停留 5ms,worker 在这期间穿插 detach + 重新 attach。
         PIN保证映像保留，detach仅清选择，已有转发记录不改变。断言300次恰好一次且保持UI线程。 */
      LONG base=0; for(int id=0;id<64;id++) base+=rec[id].nPerform;
      int N=300, wrong=0;
      for(int i=0;i<N;i++){
          int id=i%8;
          LONG p0=rec[id].nPerform;
          v3set(&ctl,H,(ParamID)id,(i+1)/777.0);         /* 走界面线程(慢),worker 在 v3set 内等它 */
          if(rec[id].nPerform!=p0+1 || rec[id].performTid!=uiTid) wrong++;
          if((i&3)==0){ ui_detach(); ui_attach(uiTid); }  /* 穿插清选择/复用现有observer */
      }
      char w[160];
      snprintf(w,sizeof w,"300 次写入在穿插 detach/attach 下每次恰好一次、全在界面线程(偏差 %d)",wrong); ck(wrong==0,w);
      LONG after=0; for(int id=0;id<64;id++) after+=rec[id].nPerform;
      snprintf(w,sizeof w,"performEdit 总增量正好 300(实际 %ld)",(long)(after-base)); ck(after-base==N,w);
      InterlockedExchange(&g_slowPerform,0);
      /* 收尾:确保重挂过,后续写入仍在界面线程 */
      ui_attach(uiTid); LONG q0=rec[7].nPerform; v3set(&ctl,H,7,0.77);
      ck(rec[7].nPerform==q0+1 && rec[7].performTid==uiTid, "竞态收尾后写入仍走界面线程"); }

    printf("\n== 十一、宿主在界面线程上反复销毁重建窗口,worker 同时写 ==\n");
    { InterlockedExchange(&g_slowPerform,0);
      ui_attach(uiTid);
      HANDLE ct=CreateThread(0,0,churnThread,0,0,0);
      InterlockedExchange(&g_churn,1);
      int N=200, lost=0, dbl=0, viaUi=0, viaWk=0, timeouts=0;
      int pump0=log_count("did not pump within");
      int flood0=log_count("owns no window")+log_count("UI-thread writes: subclassed window");
      for(int i=0;i<N;i++){ int id=i%8; LONG p0=rec[id].nPerform;
          v3set(&ctl,H,(ParamID)id,(i%97)/100.0);
          LONG d=rec[id].nPerform-p0;
          if(d==0) lost++; else if(d>1) dbl++;
          else if(rec[id].performTid==uiTid) viaUi++; else viaWk++;
          if(g_uiCooling){ timeouts++; g_uiCoolAt-=(DWORD)(UICOOL_MS+1000); }   /* 让下一次重新尝试界面线程 */
      }
      InterlockedExchange(&g_churn,2); WaitForSingleObject(ct,3000); ui_fence();
      printf("   (界面线程 %d 次,worker %d 次,其中超时退回 %d 次)\n",viaUi,viaWk,timeouts);
      char w[160];
      snprintf(w,sizeof w,"%d 次写入无一丢失(%d)",N,lost); ck(lost==0,w);
      snprintf(w,sizeof w,"%d 次写入无一重复(%d)",N,dbl); ck(dbl==0,w);
      ck(viaUi>0, "窗口频繁更替时仍有写入走通界面线程(重新挑窗口确实生效)");
      { int misblamed=log_count("did not pump within")-pump0;
        snprintf(w,sizeof w,"窗口被销毁不再被误判成「界面线程不泵」而进入 10 秒退让(误判 %d 次,应接近 0)",misblamed);
        /* 允许少数:旧窗口销毁后新窗口立刻拿到同一个句柄值时,IsWindow 仍为真,无法区分。
           真实 Windows 的句柄带代数位,同值立刻复用罕见;Wine 复用得激进,实测 4%~6%。
           修复前是 65%(200 次里 130 次),N/10 足以把两者分开,又不至于在 Wine 上抖。 */
        ck(misblamed*10 <= N, w); }
      ck(g_uiOrig!=(WNDPROC)at_wndproc, "g_uiOrig 从未指向 at_wndproc 自己");
      { int flood=log_count("owns no window")+log_count("UI-thread writes: subclassed window")-flood0;
        snprintf(w,sizeof w,"日志不刷屏:窗口狂换期间「找不到窗口/重新挂上」两类共 %d 行(限流前一次运行 261 行)",flood);
        ck(flood<=4, w); }
      LONG q0=rec[6].nPerform; v3set(&ctl,H,6,0.66);
      ck(rec[6].nPerform==q0+1, "停止更替后一次正常写入恰好落一次"); }

    printf("\n== 十二、固定HWND转发记录不受旧全局选择污染 ==\n");
    { ui_fence();ui_detach();g_uiCooling=0;
      int attached=ui_attach(uiTid);HWND tw=g_uiWnd;ATUI_Route* route=atui_find(tw);
      ck(attached&&route&&atui_live(route), "使用具有真实owner安装确认的窗口记录");
      if(attached&&route){
          WNDPROC original=route->original,saved=g_uiOrig;
          /* Fault-inject only obsolete worker selection; immutable route fields stay untouched. */
          g_uiOrig=(WNDPROC)at_wndproc;
          LONG trace=hostTrace;ui_do(WM_T_TRACE,0,0);
          ck(hostTrace==trace+1, "即使旧global original自指，普通消息仍使用此HWND真实original");
          g_uiOrig=saved;
          LONG count=InterlockedCompareExchange(&g_uiRouteCount,0,0);
          ui_detach();g_uiOrig=NULL;
          int restored=ui_attach(uiTid);
          ck(restored&&g_uiWnd==tw&&atui_find(tw)==route, "只丢worker选择时从保留的epoch恢复，不重复包链");
          ck(route->original==original&&g_uiOrig==original&&original!=(WNDPROC)at_wndproc, "未改变不可覆盖的转发身份");
          ck(InterlockedCompareExchange(&g_uiRouteCount,0,0)==count, "复用同一窗口不消耗新route槽");
          LONG before=rec[5].nPerform;v3set(&ctl,H,5,0.55);
          ck(rec[5].nPerform==before+1&&rec[5].performTid==uiTid, "恢复后正常参数写入仍在UI线程");
      }
    }

    printf("\n== 十三、宿主建了又销毁的 Waves 探测实例(LiveProfessor 2 实测的情形) ==\n");
    { /* 四个伪控制器,引用计数都是"宿主那份 + 我们那份"的真实数值:
         ghost   Waves,宿主已释放(只剩我们 1 份),从未装 handler       -> 应丢弃、应放掉引用、不列出
         live    Waves,宿主持有(2 份),装了 handler                     -> 保留、列出
         oddrc   Waves,计数只读得到 2(t_life 场景 4 保护的那种),装了 handler -> 保留、列出(永不自动丢)
         late    Waves,宿主持有(2 份),handler 还没到                   -> 保留,先不列出,handler 到了再列出
         ant     非 Waves(Antares 设计上不挂 handler),计数只读得到 2      -> 保留、列出 */
      static RcCtl ghost={&rcVt,1,0}, live={&rcVt,2,0}, oddrc={&rcVt,1,0}, late={&rcVt,2,0}, ant={&rcVt,1,0};
      void* all[5]={&ghost,&live,&oddrc,&late,&ant};
      g_ncaught=0;
      for(int i=0;i<5;i++){ g_caught[g_ncaught]=all[i]; g_caughtRel[g_ncaught]=-1; g_caughtStrike[g_ncaught]=0; g_ncaught++; }
      waves_mark(&ghost); waves_mark(&live); waves_mark(&oddrc); waves_mark(&late);
      /* Use the real hooked setter/map lifecycle, including FUnknown-owned bindings. */
      hook_setcomponenthandler(&live);
      ui_do(WM_T_SETH,(WPARAM)&live,(LPARAM)H);
      ui_do(WM_T_SETH,(WPARAM)&oddrc,(LPARAM)H);
      ck(handler_of(&live)==H&&handler_of(&oddrc)==H, "RC控制器通过真实setter建立binding");
      auto listed=[&](void* c){ for(int k=0;k<g_nv3;k++) if(g_v3[k]==(IEditController*)c) return 1; return 0; };
      int drop0=log_count("a Waves probe instance");

      /* 第一次扫描之前:探测实例还在表里,但不应被列出、不应被写 */
      g_nv3=0; merge_caught_into_v3();
      ck(!listed(&ghost), "探测实例在被丢弃之前就不列入实例集合(不会被写入错误的值)");
      ck(listed(&live) && listed(&oddrc) && listed(&ant), "有 handler 的 Waves 与 Antares 照常列出");
      ck(!listed(&late), "handler 还没到的 Waves 暂不列出");

      /* 第一次存活判定 */
      drop_dead_instances();
      int stillGhost=0; for(int i=0;i<g_ncaught;i++) if(g_caught[i]==&ghost) stillGhost=1;
      ck(!stillGhost && ghost.freed==1, "探测实例被丢弃,并且放掉了我们那份引用(释放了实例表的槽位)");
      ck(log_count("a Waves probe instance")==drop0+1, "日志说明了丢弃原因");
      int keep=0; for(int i=0;i<g_ncaught;i++) if(g_caught[i]==&live||g_caught[i]==&oddrc||g_caught[i]==&late||g_caught[i]==&ant) keep++;
      ck(keep==4 && !live.freed && !oddrc.freed && !late.freed && !ant.freed, "其余四个一个都没丢、一个引用都没多放");

      /* 再判 50 轮:计数只读得到 2 的 oddrc(有 handler)与 Antares 都必须一直留着 —— 场景 4 的保护 */
      for(int r=0;r<50;r++) drop_dead_instances();
      keep=0; for(int i=0;i<g_ncaught;i++) if(g_caught[i]==&oddrc||g_caught[i]==&ant) keep++;
      ck(keep==2, "连判 50 轮,计数恒为 2 的有 handler Waves 与 Antares 都没被误丢");

      /* late 的 handler 到了 -> 下一次合并就列出 */
      ui_do(WM_T_SETH,(WPARAM)&late,(LPARAM)H);
      g_nv3=0; merge_caught_into_v3();
      ck(listed(&late), "handler 晚到的 Waves 在 handler 到了之后被列出");

      /* 拆除:宿主先清 handler -> 立即不再列出、不再写入 */
      ui_do(WM_T_SETH,(WPARAM)&live,0);
      g_nv3=0; merge_caught_into_v3();
      ck(!listed(&live), "宿主清掉 handler(拆除中)的 Waves 立即不再列出,不再往正在销毁的对象里写");

      /* 收尾:不影响后面 */
      g_ncaught=0; g_nv3=0; }

    printf("\n== 十四、agent 记录的\"机架启动后多少毫秒\"(1147) ==\n");
    { /* 本测试进程跑到这里已有若干秒:生产代码算出的值必须为正、有限,且随时间增长 */
      DWORD a=ms_since_host_start(); Sleep(120); DWORD b=ms_since_host_start();
      char w[160]; snprintf(w,sizeof w,"值合理:%lu ms(应在 0 到 10 分钟之间,且不是未知标记)",(unsigned long)a);
      ck(a>0 && a<600000 && a!=0xFFFFFFFF, w);
      snprintf(w,sizeof w,"随时间增长:120 ms 后为 %lu ms",(unsigned long)b);
      ck(b>=a+100 && b<=a+1000, w); }

    printf("\n== 十五、加载回调只把 VST3 放进队列(1152) ==\n");
    { /* 名字命中捕获名单的 VST2(VST2 WaveShell 壳一向如此;1149 起还有每个 Antares VST2)原先也会入队:
         worker 钉住它、"挂它的工厂"、记一句永远不会兑现的"will retry"。 */
      HMODULE self=GetModuleHandleA(NULL), k32=GetModuleHandleA("kernel32.dll");
      ck(GetProcAddress(self,"GetPluginFactory")!=NULL && GetProcAddress(k32,"GetPluginFactory")==NULL,
         "前提:本测试程序导出 GetPluginFactory,kernel32 不导出");
      static const wchar_t n3[]=L"C:\\VST3\\Auto-Tune Test.vst3";   /* 命中 auto-tune,但不在 EAT 名单里 */
      static const wchar_t n2[]=L"C:\\VST2\\Auto-Tune Pro.dll";     /* 命中 auto-tune 的 VST2 */
      ATK_USTR u3={ (USHORT)(wcslen(n3)*2),(USHORT)(wcslen(n3)*2+2),n3 }, u2={ (USHORT)(wcslen(n2)*2),(USHORT)(wcslen(n2)*2+2),n2 };
      ATK_LDR_DATA d3={0,&u3,&u3,(void*)self,image_size(self)}, d2={0,&u2,&u2,(void*)k32,image_size(k32)};
      LONG t0=g_llTail; int eat0=g_nEat;
      dll_notify(1,&d2,NULL);
      ck(g_llTail==t0, "名字命中、但不导出 GetPluginFactory 的模块(VST2)不入队:不会被钉住,也不会留下误导性的日志");
      dll_notify(1,&d3,NULL);
      ck(g_llTail==((t0+1)&(LLQ-1)) && g_llQ[t0]==self, "导出 GetPluginFactory 的模块(VST3)照常入队");
      ck(g_nEat==eat0, "两者都不在 EAT 名单里,都没有改写导出表");
      g_llHead=g_llTail; g_llFlag=0;
      /* skip.txt 也必须管住加载回调这条路(1155)。原先只有后台扫描查它:写了 waveshell 想"完全停用 Waves",
         加载回调照样改写导出表、把模块交给 worker 挂工厂,实例照样被捕获、被写入。 */
      { int ns=g_nSkip; char sv[96]; snprintf(sv,sizeof sv,"%s",g_skip[0]);
        snprintf(g_skip[0],sizeof g_skip[0],"%s","auto-tune test"); g_nSkip=1;
        LONG t1=g_llTail; int e1=g_nEat;
        dll_notify(1,&d3,NULL);
        ck(g_llTail==t1 && g_nEat==e1, "skip.txt 里写了它:加载回调不入队、不改写导出表(与后台扫描一致)");
        g_nSkip=0;
        dll_notify(1,&d3,NULL);
        ck(g_llTail==((t1+1)&(LLQ-1)), "从 skip.txt 去掉后照常入队");
        g_llHead=g_llTail; g_llFlag=0; snprintf(g_skip[0],sizeof g_skip[0],"%s",sv); g_nSkip=ns; } }   /* 本测试不跑 worker 循环:清空队列,不影响后面 */

    printf("\n== 十六、音阶文件:整段写入,空段真正丢弃(1152 后) ==\n");
    { /* 直接让生产代码的 write_scales_union 写出文件,检查控制器会读到的内容。
         控制器的规则:最后一个字节不是换行 -> 整个文件当作写到一半而忽略。 */
      char tmp[MAX_PATH]; GetTempPathA(sizeof tmp,tmp); snprintf(g_scalesPath,sizeof g_scalesPath,"%sw_uiwin_scales.txt",tmp);
      int nv2save=g_nv2; g_nv2=0; g_procLeaf[0]=0;
      static int fakeCtl[NDISC];
      auto reset=[&](){ for(int k=0;k<NDISC;k++){ memset(&g_disc[k],0,sizeof g_disc[k]); } g_scalesWritten[0]=0; DeleteFileA(g_scalesPath); };
      auto readf=[&](char* out,int cap)->int{ FILE* f=fopen(g_scalesPath,"rb"); if(!f){ out[0]=0; return 0; } int n=(int)fread(out,1,cap-1,f); fclose(f); out[n>0?n:0]=0; return n; };
      static char got[70000];
      /* 情形一:最后一个实例一个音阶都没有 */
      reset();
      g_disc[0].ctrl=(IEditController*)&fakeCtl[0]; g_disc[0].isTuner=1; g_disc[0].discDone=1; g_disc[0].nscales=3;
      strcpy(g_disc[0].sdisp[0],"Major"); strcpy(g_disc[0].sdisp[1],"Minor"); strcpy(g_disc[0].sdisp[2],"Chromatic");
      modmap_set(&fakeCtl[0],"Has Scales.vst3");
      g_disc[1].ctrl=(IEditController*)&fakeCtl[1]; g_disc[1].isTuner=1; g_disc[1].discDone=1; g_disc[1].nscales=2;   /* 两项都为空串 */
      modmap_set(&fakeCtl[1],"No Scales Yet.vst3");
      write_scales_union();
      int n=readf(got,sizeof got);
      ck(n>0 && strstr(got,"[Has Scales.vst3]")!=NULL, "有音阶的实例照常发布");
      ck(strstr(got,"[No Scales Yet.vst3]")==NULL, "没有音阶的实例(且是最后一段)不出现在文件里 —— 原先它的表头会留下,目标选'全部'时交集变成并集");
      ck(n>0 && got[n-1]=='\n', "文件以换行结尾");
      /* 情形二:远超 16 KB,只能放下一部分实例 */
      reset();
      for(int k=0;k<NDISC;k++){ g_disc[k].ctrl=(IEditController*)&fakeCtl[k]; g_disc[k].isTuner=1; g_disc[k].discDone=1; g_disc[k].nscales=96;
          for(int j=0;j<96;j++) snprintf(g_disc[k].sdisp[j],48,"S%02d_%02d_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",k,j);
          char nm[64]; snprintf(nm,sizeof nm,"Instance %02d.vst3",k); modmap_set(&fakeCtl[k],nm); }
      int full0=log_count("scale-list buffer full");
      write_scales_union();
      n=readf(got,sizeof got);
      ck(log_count("scale-list buffer full")==full0+1, "缓冲区满、丢掉后面的实例时记下一行(原先完全不记)");
      write_scales_union();
      ck(log_count("scale-list buffer full")==full0+1, "下一轮仍然满:不再重复记(状况持续时只在出现那一刻记一次)");
      ck(n>0 && got[n-1]=='\n', "超出缓冲区时,文件仍以换行结尾(控制器不会整个忽略)");
      int sections=0, complete=1, lines=0; char* p=got; int cur=-1;
      while(*p){ char* nl=strchr(p,'\n'); if(!nl) break; *nl=0;
          if(p[0]=='['){ if(cur>=0 && lines!=96) complete=0; sections++; cur=sections; lines=0; }
          else { lines++; char pre[8]; snprintf(pre,sizeof pre,"S%02d_",sections-1); if(strncmp(p,pre,4)!=0) complete=0; }
          p=nl+1; }
      if(cur>=0 && lines!=96) complete=0;
      char w[160]; snprintf(w,sizeof w,"放下的 %d 个实例每段都是完整的 96 个音阶,且每行都属于它所在的段",sections);
      ck(sections>=1 && sections<NDISC && complete, w);
      reset(); g_nv2=nv2save; }

    printf("\n== 十七、状态文件:只有真的写不下才算满(1157) ==\n");
    { /* 用 PENDING 行(只需捕获模块的登记,不调用插件)让生产代码的 write_status 写出真实文件。 */
      char tmp[MAX_PATH]; GetTempPathA(sizeof tmp,tmp); snprintf(g_statusPath,sizeof g_statusPath,"%sw_uiwin_status.txt",tmp);
      int nv3=g_nv3, nv2=g_nv2, nat=g_nat; char pl[96]; snprintf(pl,sizeof pl,"%s",g_procLeaf);
      g_nv3=0; g_nv2=0;
      memset(g_procLeaf,'H',90); g_procLeaf[90]=0;                       /* 宿主名 90 字节 */
      static char got[20000];
      auto fill=[&](int leafLen){ g_nat=MAXVT; for(int i=0;i<MAXVT;i++){ memset(&g_at[i],0,sizeof g_at[i]); g_at[i].catchMode=1;
              char lf[300]; memset(lf,'a'+(i%26),(size_t)leafLen); lf[leafLen]=0; snprintf(lf,8,"m%02d_",i); lf[4]='x';
              snprintf(g_at[i].path,sizeof g_at[i].path,"C:\\V\\%s",lf); } g_statusWritten[0]=0; DeleteFileA(g_statusPath); };
      auto readf=[&]()->int{ FILE* f=fopen(g_statusPath,"rb"); if(!f){ got[0]=0; return 0; } int n=(int)fread(got,1,sizeof got-1,f); fclose(f); got[n>0?n:0]=0; return n; };
      auto lines=[&](int* complete)->int{ int c=0; *complete=1; char* p=strchr(got,'\n'); if(!p) return 0; p++;   /* 跳过 #b 行 */
              while(*p){ char* nl=strchr(p,'\n'); if(!nl){ *complete=0; break; } if(!strstr(p,"[[PENDING]]")||strstr(p,"[[PENDING]]")>nl) *complete=0; c++; p=nl+1; } return c; };
      /* 情形一:32 行每行 250 字节,共约 8007 字节 —— 全部放得下,但用量超过 97% */
      fill(143); int f0=log_count("status buffer full");
      write_status(); int n=readf(), ok1; int L=lines(&ok1);
      char w[160]; snprintf(w,sizeof w,"全部 %d 个模块都列出(文件 %d 字节,超过缓冲区的 97%%)",L,n);
      ck(L==MAXVT && ok1 && n>8192-240, w);
      ck(log_count("status buffer full")==f0, "全部放得下时不记'有实例没列出'(原先只看用量,会谎报)");
      /* 情形二:每行 347 字节,32 行远超 8 KB */
      fill(240); write_status(); n=readf(); int ok2; L=lines(&ok2);
      snprintf(w,sizeof w,"放不下时只列出能放下的 %d 行,每行完整,文件以换行结尾",L);
      ck(L>0 && L<MAXVT && ok2 && n>0 && got[n-1]=='\n', w);
      ck(log_count("status buffer full")==f0+1, "真的放不下:记一行");
      g_statusWritten[0]=0; write_status();
      ck(log_count("status buffer full")==f0+1, "下一轮仍放不下:不重复记");
      for(int i=0;i<MAXVT;i++) memset(&g_at[i],0,sizeof g_at[i]);
      g_nat=nat; g_nv3=nv3; g_nv2=nv2; snprintf(g_procLeaf,sizeof g_procLeaf,"%s",pl); g_statusWritten[0]=0; DeleteFileA(g_statusPath); }

    printf("\n== 十八、数据目录与列表文件(1162):没有指针时先找新数据目录;pending 不留空文件;列表开头的 BOM 不算进第一项 ==\n");
    { char tmpd[MAX_PATH]; GetTempPathA(MAX_PATH,tmpd);
      std::string R=std::string(tmpd)+"w_uiwin_env", T=R+"\\temp", L=R+"\\local", D=L+"\\" AT_DATA_SUBDIR, P=R+"\\fromptr";
      for(const std::string& d: {R,T,L,D}) CreateDirectoryA(d.c_str(),NULL);
      char sLog[MAX_PATH]; strcpy(sLog,g_logPath);
      char oT[MAX_PATH]="", oE[MAX_PATH]="", oL[MAX_PATH]=""; DWORD hT=GetEnvironmentVariableA("TMP",oT,MAX_PATH), hE=GetEnvironmentVariableA("TEMP",oE,MAX_PATH), hL=GetEnvironmentVariableA("LOCALAPPDATA",oL,MAX_PATH);
      SetEnvironmentVariableA("TMP",T.c_str()); SetEnvironmentVariableA("TEMP",T.c_str()); SetEnvironmentVariableA("LOCALAPPDATA",L.c_str());
      COMMDIR[0]=0; resolve_commdir();
      ck(!_stricmp(COMMDIR,D.c_str()), "没有指针文件:用控制器建好的 %LOCALAPPDATA%\\AutoTune_KeyScale(与控制器会合)");
      RemoveDirectoryA(D.c_str()); COMMDIR[0]=0; resolve_commdir();
      ck(!_stricmp(COMMDIR,(T+"\\at8").c_str()), "那个文件夹也不存在:照旧退回 %TEMP%\\at8");
      { FILE* f=fopen((T+"\\at8_commdir.txt").c_str(),"w"); fprintf(f,"%s\n",P.c_str()); fclose(f); }
      COMMDIR[0]=0; resolve_commdir();
      ck(!_stricmp(COMMDIR,P.c_str()), "有指针文件:照指针(控制器写的位置优先)");
      cb_clear_pending();
      ck(GetFileAttributesA(g_pendPath)==INVALID_FILE_ATTRIBUTES, "清除探测标记 = 删除文件,不再留下空的 pending_<pid>.txt");
      cb_write_pending("C:\\VST3\\X.vst3");
      { char b[64]=""; FILE* f=fopen(g_pendPath,"r"); if(f){ if(!fgets(b,sizeof b,f)) b[0]=0; fclose(f); }
        ck(!strcmp(b,"C:\\VST3\\X.vst3"), "探测前照旧写下模块路径(崩溃证据)"); }
      cb_clear_pending();
      ck(GetFileAttributesA(g_pendPath)==INVALID_FILE_ATTRIBUTES, "探测完删掉");
      auto put=[&](const char* p,const char* s){ FILE* f=fopen(p,"wb"); if(f){ fputs(s,f); fclose(f);} };
      put(g_skipPath,"\xEF\xBB\xBFwaveshell\r\n"); put(g_blackPath,"\xEF\xBB\xBF" "C:\\x\\Crashy.vst3\r\n");
      cb_startup();
      ck(g_nSkip==1 && !strcmp(g_skip[0],"waveshell"), "skip.txt 开头的 BOM 不算进第一项(否则界面上勾着「不处理 Waves」却不生效)");
      ck(mod_probe_unsafe("C:\\x\\Crashy.vst3"), "use_factory_hook.txt 同上");
      put(g_catchPath,"\xEF\xBB\xBFmyplug\r\n"); load_catch_list();
      ck(g_nCatchPat==1 && !strcmp(g_catchPat[0],"myplug"), "catch.txt 同上");
      put(g_scalemapPath,"\xEF\xBB\xBF" "Foo|Bar\r\n"); g_grpLoaded=0; load_scalemap();
      { const char* c=scale_canon("Bar"); ck(c && !strcmp(c,"Foo"), "scalemap.txt 同上:第一组的显示名不带乱码"); }
      if(hT) SetEnvironmentVariableA("TMP",oT); else SetEnvironmentVariableA("TMP",NULL);
      if(hE) SetEnvironmentVariableA("TEMP",oE); else SetEnvironmentVariableA("TEMP",NULL);
      if(hL) SetEnvironmentVariableA("LOCALAPPDATA",oL); else SetEnvironmentVariableA("LOCALAPPDATA",NULL);
      strcpy(g_logPath,sLog);
      for(const std::string& d: {P,T+"\\at8",T,L,R}){ WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA((d+"\\*").c_str(),&fd);
          if(hf!=INVALID_HANDLE_VALUE){ do{ if(!(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)) DeleteFileA((d+"\\"+fd.cFileName).c_str()); }while(FindNextFileA(hf,&fd)); FindClose(hf); }
          RemoveDirectoryA(d.c_str()); } }

    printf("\n== 十九、设置窗口改写列表的同时机架正在启动:agent 读到的只会是完整的旧列表或新列表,不会当成「没有列表」(1162) ==\n");
    { char tmpd[MAX_PATH]; GetTempPathA(MAX_PATH,tmpd); std::string R=std::string(tmpd)+"w_uiwin_repl"; CreateDirectoryA(R.c_str(),NULL);
      static char sv[6][MAX_PATH]; char* g[6]={COMMDIR,g_skipPath,g_pendPath,g_blackPath,g_blackOldPath,NULL}; for(int i=0;g[i];i++) strcpy(sv[i],g[i]);
      snprintf(COMMDIR,MAX_PATH,"%s",R.c_str()); snprintf(g_skipPath,MAX_PATH,"%s\\skip.txt",R.c_str()); snprintf(g_pendPath,MAX_PATH,"%s\\pending_t.txt",R.c_str());
      snprintf(g_blackPath,MAX_PATH,"%s\\use_factory_hook.txt",R.c_str()); snprintf(g_blackOldPath,MAX_PATH,"%s\\disabled.txt",R.c_str());
      { FILE* f=fopen(g_skipPath,"wb"); fputs("foo\r\nbar\r\n",f); fclose(f); }
      static ReplArgs ra; memset(&ra,0,sizeof ra); strcpy(ra.path,g_skipPath);
      HANDLE th=CreateThread(NULL,0,repl_writer,&ra,0,NULL); int runs=0, empty=0, wrong=0;
      for(int i=0;i<300;i++){ cb_startup(); runs++; if(g_nSkip==0) empty++; else if(g_nSkip!=2 && g_nSkip!=3) wrong++; }
      InterlockedExchange(&ra.stop,1); WaitForSingleObject(th,5000); CloseHandle(th);
      char w[220]; snprintf(w,sizeof w,"另一线程不停地整文件替换 skip.txt,agent 启动读了 %d 次:读成空列表 %d 次、读到不完整的 %d 次(都必须是 0)",runs,empty,wrong);
      ck(runs==300 && empty==0 && wrong==0, w);
      for(int i=0;g[i];i++) strcpy(g[i],sv[i]);
      WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA((R+"\\*").c_str(),&fd);
      if(hf!=INVALID_HANDLE_VALUE){ do{ if(!(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)) DeleteFileA((R+"\\"+fd.cFileName).c_str()); }while(FindNextFileA(hf,&fd)); FindClose(hf); }
      RemoveDirectoryA(R.c_str()); }

    printf("\n== 二十、音阶同义词改完即时生效(1162):控制器发 reload,agent 下次查音阶时重新读 scalemap.txt ==\n");
    { char tmpd[MAX_PATH]; GetTempPathA(MAX_PATH,tmpd); char sm[MAX_PATH]; snprintf(sm,sizeof sm,"%sw_uiwin_smap.txt",tmpd);
      char sv[MAX_PATH]; strcpy(sv,g_scalemapPath); snprintf(g_scalemapPath,MAX_PATH,"%s",sm);
      { FILE* f=fopen(sm,"wb"); fputs("Foo|Bar\r\n",f); fclose(f); } g_grpLoaded=0;
      const char* c1=scale_canon("Bar"); int before=(c1 && !strcmp(c1,"Foo"));
      { FILE* f=fopen(sm,"wb"); fputs("Baz|Bar\r\n",f); fclose(f); }
      const char* c2=scale_canon("Bar"); int stale=(c2 && !strcmp(c2,"Foo"));      /* 不通知就还是旧的 */
      cmd_side_effects("key=3|scale=Minor|t=5\n"); const char* c3=scale_canon("Bar"); int ignored=(c3 && !strcmp(c3,"Foo"));
      cmd_side_effects("reload=scalemap|t=6\n");  const char* c4=scale_canon("Bar"); int fresh=(c4 && !strcmp(c4,"Baz"));
      ck(before && stale && ignored && fresh, "收到 reload 才重读:普通命令不触发,reload 之后同义词立刻是新的");
      strcpy(g_scalemapPath,sv); g_grpLoaded=0; DeleteFileA(sm); }

    ui_do(WM_T_SETH,0,0);chmap_del(&ctl);handler_worker_drain();
    ck(handlerRefs==1&&handlerAdds==handlerReleases&&!handlerBadRefs, "所有map/事务真实FUnknown引用平衡，host基础引用仍在");
    ui_do(WM_T_QUIT,0,0); WaitForSingleObject(ut,3000);
    printf("\n失败数: %d\n",fails); return fails?1:0; }
