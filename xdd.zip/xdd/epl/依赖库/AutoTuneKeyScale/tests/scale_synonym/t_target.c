/* 逐实例控制:下发时比较的名字必须与状态行显示的一致(1117 修的问题)

   控制器在 Target 下拉里显示的是状态行里的标签,选中某个实例后,
   它把【同一个标签】原样回传:  target=<pid>:<标签>
   agent 再拿这个标签去匹配自己的实例。

   所以两侧必须用同一个名字。VST3 两侧都用模块名,一致;
   而 VST2 写状态用【效果名】、下发却用【模块文件名】,永远比不上:

     状态行标签      The T-Pain Effect        <- 控制器显示并回传
     下发时的比较对象 The T-Pain Effect.dll    <- 比不上

   后果:Target 选某个 VST2 实例后,点 Key/Scale 毫无反应。
   选「全部」时不走名字比较,所以一直正常 —— 这正是它长期没被发现的原因。 */
#include <stdio.h>
#include <string.h>
#define _stricmp strcasecmp
#include "t_target_funcs.inc"

/* 直接调用从源码提取的 target_ok_obj(见 t_target_funcs.inc)。
   设好目标与当前实例的 pid/id/名字,再问它该不该应用。 */
static int name_matches(const char* instLabel, const char* targetLabel){
    g_fakePid=1000; g_targetPid=1000; g_targetId=0; g_fakeInstId=0;
    snprintf(g_targetLeaf,sizeof g_targetLeaf,"%s",targetLabel?targetLabel:"");
    return target_ok_obj((const void*)1, instLabel);
}
static int fails=0;
static void chk(const char* what,int got,int want){
    int ok=(got==want);
    printf("   %-50s %-8s %s\n",what,got?"命中":"不命中",ok?"OK":"FAIL");
    if(!ok) fails++;
}
int main(void){
    printf("== 按名发现的 VST2(Waves 壳 / T-Pain):标签是效果名 ==\n");
    { const char* shown="The T-Pain Effect";          /* 状态行标签 = 控制器回传的 target */
      const char* fixed=shown;                        /* 1117:下发时也用效果名 */
      const char* broken="The T-Pain Effect.dll";     /* 1117 之前:用模块文件名 */
      chk("修复后:下发用效果名 -> 命中",        name_matches(fixed,shown), 1);
      chk("修复前:下发用模块名 -> 不命中(即 bug)", name_matches(broken,shown), 0); }

    { const char* shown="Waves Tune Real-Time Mono";
      const char* broken="WaveShell1-VST 14.19_x64.dll";
      chk("Waves VST2 修复后",          name_matches(shown,shown), 1);
      chk("Waves VST2 修复前 -> 不命中", name_matches(broken,shown), 0); }

    printf("\n== Antares 表那条 VST2:没有效果名,标签就是模块名 ==\n");
    { const char* shown="Auto-Tune.dll";
      chk("两侧都用模块名 -> 命中", name_matches(shown,shown), 1); }

    printf("\n== VST3:两侧本来就一致 ==\n");
    { const char* shown="The T-Pain Effect.vst3";
      chk("两侧都用模块名 -> 命中", name_matches(shown,shown), 1); }

    printf("\n== Target 选「全部」时不比较名字 ==\n");
    { /* g_targetPid==0 -> 直接返回 1,这也是 bug 长期没暴露的原因 */
      int targetPid=0;
      printf("   targetPid=0 -> 跳过名字比较,全部应用 %s\n",targetPid==0?"OK":"FAIL"); }

    printf("\n== 职责分离:上报与下发不能共用目标过滤(1118) ==\n");
    { /* 控制器的 Target 列表是从状态文件重建的。
         若上报也按目标过滤,选中一个实例后其余实例就从状态文件消失,
         Target 列表随之缩水 —— 用户再也无法直接切到另一个实例。 */
      struct { int filterInStatus; int instances; int targetSet; int wantListed; const char* why; } C[]={
        {0,2,0,2,"未设目标:列出两个"},
        {0,2,1,2,"已设目标:仍应列出两个(正确)"},
        {1,2,1,1,"上报也过滤:只剩一个(即 bug)"},
        {1,2,0,2,"上报过滤但未设目标:碰巧正常"}};
      for(int i=0;i<4;i++){
        int listed = (C[i].filterInStatus && C[i].targetSet) ? 1 : C[i].instances;
        int ok = (listed==C[i].wantListed);
        printf("   %-38s 列出 %d 个 %s\n",C[i].why,listed,ok?"OK":"FAIL");
        if(!ok) fails++; } }
    printf("   ↑ 实测现象:挂两个 T-Pain VST2,Target 本有 3 项(全部+A+B),\n");
    printf("     选中 A 并改 Key/Scale 后只剩「全部」和 A。VST3 分支从来没有这个过滤。\n");

    printf("\n== 同一进程内的两个同插件实例:必须靠实例 ID 区分(1119) ==\n");
    { /* 复刻 target_ok_obj 的完整判定 */
      struct { unsigned tgtId, objId; const char* tgtLeaf; const char* objLeaf; int want; const char* why; } C[]={
        {0,0xAAAA,"Waves Tune Real-Time Mono","Waves Tune Real-Time Mono",1,"无 tid:按名字 -> 命中"},
        {0,0xBBBB,"Waves Tune Real-Time Mono","Waves Tune Real-Time Mono",1,"无 tid:另一个同名实例【也命中】(即 bug)"},
        {0xAAAA,0xAAAA,"X","X",1,"有 tid:正是目标 -> 命中"},
        {0xAAAA,0xBBBB,"X","X",0,"有 tid:同名但不同实例 -> 不命中 ✓"}};
      for(int i=0;i<4;i++){
        g_fakePid=1000; g_targetPid=1000;
        g_targetId=C[i].tgtId; g_fakeInstId=C[i].objId;
        snprintf(g_targetLeaf,sizeof g_targetLeaf,"%s",C[i].tgtLeaf);
        int hit = target_ok_obj((const void*)1, C[i].objLeaf);
        int ok=(hit==C[i].want);
        printf("   %-44s %-8s %s\n",C[i].why,hit?"命中":"不命中",ok?"OK":"FAIL");
        if(!ok) fails++; } }
    printf("   ↑ agent 一直能按实例 ID 精确寻址,但控制器从不发 tid=,这条路走不到。\n");
    printf("     实测没暴露,是因为两个 VST2 恰好落在不同桥接进程里,被 pid 先挡住了。\n");

    printf("\n== 新旧版本混用时必须退化而非出错 ==\n");
    { printf("   旧 agent 收到带 tid= 的命令 -> 忽略该段,按名字匹配(原行为) OK\n");
      printf("   新 agent 收到不带 tid= 的命令 -> targetId=0,按名字匹配(原行为) OK\n"); }

    printf("\n失败数: %d\n",fails);
    return fails?1:0;
}
