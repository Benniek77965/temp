static unsigned inst_id(const void* p){
    uintptr_t v=(uintptr_t)p;
    unsigned lo=(unsigned)v;
    unsigned hi=(sizeof(uintptr_t)>4) ? (unsigned)(((unsigned long long)v)>>32) : 0u;
    return lo ^ hi; }
static void parse_target(const char* line){
    { const char* ti2=strstr(line,"tid="); g_targetId = ti2? (unsigned)strtoul(ti2+4,NULL,16) : 0u; }
    { const char* tg=strstr(line,"target="); g_targetPid=0; g_targetLeaf[0]=0;
      if(tg){ tg+=7; g_targetPid=(DWORD)strtoul(tg,NULL,10); const char* col=strchr(tg,':');
              if(col){ col++; int j=0; while(col[j]&&col[j]!='|'&&col[j]!='\n'&&col[j]!='\r'&&j<95){ g_targetLeaf[j]=col[j]; j++; } g_targetLeaf[j]=0; } } } }
static int target_ok_obj(const void* obj, const char* leaf){
    if(g_targetPid==0) return 1;                        /* no target -> all plugins */
    if(g_targetPid != GetCurrentProcessId()) return 0;  /* target is in another host -> this agent applies to none */
    if(g_targetId) return inst_id(obj) == g_targetId;
    return leaf && g_targetLeaf[0] && _stricmp(leaf,g_targetLeaf)==0; }
