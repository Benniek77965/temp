/* 注入器"已载入就跳过"的判断:必须按每进程的互斥体,而不是按 DLL 文件名(1161)。
   把注入器源码里那段判断逻辑单独拿出来验证 —— 核心是 OpenMutexA("Local\at_agent_<pid>")。 */
#include <windows.h>
#include <stdio.h>
static int fails=0;
static void ck(int c,const char* m){ printf("   %s %s\n",c?"OK  ":"FAIL",m); if(!c) fails++; }
/* 复刻注入器的判断:能打开本进程的 agent 互斥体 => 已存在 */
static int injector_would_skip(DWORD pid){
    char mn[64]; _snprintf(mn,sizeof mn,"Local\\at_agent_%lu",pid); mn[sizeof mn-1]=0;
    HANDLE em=OpenMutexA(SYNCHRONIZE,FALSE,mn);
    if(em){ CloseHandle(em); return 1; } return 0; }
/* 核对:注入器源码里真的用 OpenMutexA + "Local\\at_agent_%lu" 判断,而不是(只)用文件名 */
static int injector_source_uses_mutex(void){
    FILE* f=fopen("../../vst3/cpp/inject.cpp","rb"); if(!f) return -1;
    static char b[200000]; int n=(int)fread(b,1,sizeof b-1,f); b[n>0?n:0]=0; fclose(f);
    return strstr(b,"OpenMutexA")!=NULL && strstr(b,"at_agent_%lu")!=NULL   /* 这个片段已足够独特;避免在测试里再写一层反斜杠转义 */
           && strstr(b,"return 11")!=NULL; }
int main(void){
    DWORD me=GetCurrentProcessId();
    printf("== 0. 注入器源码按互斥体判断 ==\n");
    { int r=injector_source_uses_mutex();
      ck(r==1, r<0?"找不到 inject.cpp":"inject.cpp 用 OpenMutexA(每进程互斥体)判断已载入"); }

    printf("== 1. 没有 agent 时:不跳过,会真的注入 ==\n");
    ck(injector_would_skip(me)==0, "本进程还没有 agent 互斥体 -> 注入器不跳过");

    printf("\n== 2. agent 已在(以任意文件名注入)时:跳过 ==\n");
    char mn[64]; _snprintf(mn,sizeof mn,"Local\\at_agent_%lu",me,mn);
    HANDLE agent=CreateMutexA(NULL,TRUE,mn);   /* 扮演已载入的 agent 持有它 */
    ck(agent!=NULL, "前提:模拟 agent 持有互斥体");
    ck(injector_would_skip(me)==1, "已有 agent -> 注入器跳过(与注入时用的文件名无关:这正是 b<build>_<n> 换名注入要防的重复注入)");

    printf("\n== 3. 跳过检查只是探测,不会把自己变成持有者 ==\n");
    /* 注入器连续被调两次,第二次也应判定为"已存在",而不是第一次探测把锁占了导致第二次看不到 */
    ck(injector_would_skip(me)==1 && injector_would_skip(me)==1, "多次探测结果一致(OpenMutex 只开不持)");
    CloseHandle(agent);

    printf("\n== 4. agent 卸载(释放互斥体)后:又可以注入了 ==\n");
    ck(injector_would_skip(me)==0, "互斥体已释放 -> 下次注入不再跳过");

    printf("\n失败数: %d\n",fails); return fails?1:0; }
