/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
static int log_compose(char* line, int cap, unsigned long pid, unsigned long ms, const char* fmt, va_list ap){
    int n = snprintf(line,(size_t)cap,"[%lu] +%lu.%03lu ",pid,ms/1000UL,ms%1000UL);
    if(n<0) n=0;
    if(n>cap-2) n=cap-2;
    int m = vsnprintf(line+n,(size_t)(cap-1-n),fmt,ap);
    if(m<0) m=0;
    if(m>cap-2-n) m=cap-2-n;                       /* what vsnprintf actually wrote, never its NUL */
    n += m;
    line[n++]='\n';
    return n; }
