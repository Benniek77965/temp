/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
#include <stdlib.h>
static void trim(char* s){ int n=(int)strlen(s); while(n>0 && (unsigned char)s[n-1]<=' ') s[--n]=0;
    int i=0; while(s[i]==' '||s[i]=='\t') i++; if(i) memmove(s,s+i,strlen(s+i)+1); }
static void norm(const char* in,char* out,int n){ int o=0;
    for(int i=0;in[i]&&o<n-1;i++){ char ch=in[i]; if(ch==' '||ch=='-'||ch=='_') continue;
        out[o++]=(ch>='A'&&ch<='Z')?(char)(ch+32):ch; } out[o]=0; }
#define LOG(...) ((void)0)
#define MAXGRP 24
#define MAXMEM 8
static char g_grpN[MAXGRP][MAXMEM][48]; static char g_grpDisp[MAXGRP][48];
static int g_grpCnt[MAXGRP]; static int g_nGrp=0; static int g_grpLoaded=0;
static int grp_add_line(const char* line){
    if(!line||!line[0]||line[0]=='#') return -1;
    if(g_nGrp>=MAXGRP) return 0;
    char buf[256]; snprintf(buf,sizeof buf,"%s",line);
    int m=0, haveDisp=0, extra=0; char* p=buf;
    while(*p){ char* bar=strchr(p,'|'); if(bar)*bar=0; trim(p);
        if(p[0]){
            if(m>=MAXMEM) extra++;        /* 别名超限也要说一声:少一个别名 = 那个插件的音阶名匹配不上 */
            else { if(!haveDisp){ snprintf(g_grpDisp[g_nGrp],48,"%s",p); haveDisp=1; }
                   norm(p,g_grpN[g_nGrp][m],48); m++; } }
        if(!bar) break; p=bar+1; }
    if(extra) LOG("WARN: scalemap.txt: '%s' has %d alias(es) past the %d-per-group limit -- "
                  "those names will not match",g_grpDisp[g_nGrp],extra,MAXMEM);
    if(m<2) return -1;              /* 一行至少要有「规范名|别名」两项才构成一组 */
    g_grpCnt[g_nGrp]=m; g_nGrp++; return 1; }
