/* 状态栏把多条故障提示拼接起来 —— strncat 的长度参数是"最多再拷几个字符",
   不是缓冲区总大小,写错就是经典的差一越界。 */
#include <stdio.h>
#include <string.h>
static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)
static void build(char* buf, size_t cap, int nh, int active, int abandoned, int missing, int cmdfail){
  snprintf(buf, cap, "Connected %d/%d host(s)%s%s", active, nh,
           (active<nh) ? "   [some failed: check antivirus/exclusions]" : "",
           abandoned>0 ? "  [有进程注入失败已放弃,重启该进程可重试]" : "");
  if (missing)  strncat(buf, "  [agent 文件不在磁盘上:多半被杀毒隔离了]", cap - strlen(buf) - 1);
  if (cmdfail)  strncat(buf, "  [命令写入失败:磁盘已满或目录只读]",     cap - strlen(buf) - 1);
}
int main(void){
  char buf[1024];
  printf("== 1. 正常情况 ==\n");
  build(buf,sizeof buf,2,2,0,0,0);
  CK(strstr(buf,"Connected 2/2")!=NULL && strstr(buf,"[")==NULL, "无故障时不加任何提示");

  printf("\n== 2. 各种故障都要出现 ==\n");
  build(buf,sizeof buf,2,1,1,1,1);
  CK(strstr(buf,"some failed")!=NULL,      "部分注入失败");
  CK(strstr(buf,"已放弃")!=NULL,            "注入放弃");
  CK(strstr(buf,"杀毒隔离")!=NULL,          "agent 文件缺失");
  CK(strstr(buf,"命令写入失败")!=NULL,       "命令写入失败");
  printf("   拼出来的状态: %s\n", buf);

  printf("\n== 3. 缓冲区很小的时候不能越界 ==\n");
  for(size_t cap=16; cap<=96; cap+=8){
    char small[128]; memset(small,0xAB,sizeof small);
    build(small,cap,2,1,1,1,1);
    if(strlen(small) >= cap){ printf("   FAIL cap=%zu 时长度 %zu 越界\n",cap,strlen(small)); fails++; }
    if((unsigned char)small[cap]!=0xAB){ printf("   FAIL cap=%zu 时写到了缓冲区之外\n",cap); fails++; }
  }
  CK(1,"cap 从 16 到 96 全部不越界、不写出边界");
  printf("\n失败数: %d\n",fails); return fails?1:0;
}
