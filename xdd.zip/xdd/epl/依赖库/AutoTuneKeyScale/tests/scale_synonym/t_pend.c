/* 崩溃黑名单的归属判定:只能采纳【已经死掉的】那次运行留下的标记 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)
/* 复刻生产代码的判定:自己的跳过、活着的跳过、其余采纳 */
static int should_adopt(unsigned long filePid, unsigned long selfPid, int alive){
  if(filePid==selfPid) return 0;
  if(alive) return 0;
  return 1;
}
/* 文件名解析:pending_<pid>.txt */
static unsigned long pid_of(const char* name){ return strtoul(name+8,NULL,10); }
int main(void){
  printf("== 文件名解析 ==\n");
  CK(pid_of("pending_4512.txt")==4512, "pending_4512.txt -> 4512");
  CK(pid_of("pending_0.txt")==0,       "异常 pid 解析为 0");

  printf("\n== 归属判定(用户现有环境:两个宿主同时跑 agent)==\n");
  CK(!should_adopt(4512,4512,1), "自己的标记 -> 不采纳");
  CK(!should_adopt(4512,5620,1), "另一个宿主【还活着】-> 不采纳  <<< 旧版就是在这里误判");
  CK( should_adopt(4512,5620,0), "另一个宿主已死 -> 采纳,拉黑那个模块");
  CK(!should_adopt(0,5620,1),    "pid 解析失败且判为活着 -> 不采纳");

  printf("\n== 拿不准时必须偏向【不拉黑】 ==\n");
  printf("   proc_alive 在 OpenProcess 失败且为 ACCESS_DENIED 时返回'活着',\n");
  printf("   所以权限不足只会导致少拉黑,绝不会凭猜测把好模块永久禁用。\n");
  CK(!should_adopt(4512,5620,1), "无法判定 -> 当作活着 -> 不采纳");

  printf("\n旧版的后果:一个正常模块被永久写进磁盘黑名单,重启机架也不会恢复。\n失败数: %d\n",fails);
  return fails?1:0;
}
