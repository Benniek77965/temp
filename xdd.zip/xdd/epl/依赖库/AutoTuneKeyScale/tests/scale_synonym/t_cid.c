#include <stdio.h>
#include <string.h>
typedef char TUID[16];
#include "t_cid_funcs.inc"
static int fails=0;
static void chk(const char* raw,const char* expectName,int expectHit){
  TUID c; memcpy(c,raw,16);
  char nm[80]=""; int hit=cid_is_waves(c,nm,sizeof nm);
  int ok=(hit==expectHit) && (!expectHit || !strcmp(nm,expectName));
  char show[20]; for(int i=0;i<16;i++) show[i]=(raw[i]>=32&&raw[i]<127)?raw[i]:'.'; show[16]=0;
  printf("   %-18s -> %-30s %s\n", show, hit?nm:"(不是 Waves 类)", ok?"OK":"FAIL");
  if(!ok) fails++;
}
int main(void){
  printf("== 6 个真机样本 ==\n");
  chk("LTSVLVwMaves tun","Waves Tune Real-Time Mono",1);
  chk("LTSVLVwSaves tun","Waves Tune Real-Time Stereo",1);
  chk("TTSVGNwMaves tun","Waves Tune Mono",1);
  chk("TTSVGNwSaves tun","Waves Tune Stereo",1);
  chk("TTSVRSsMoundshif","SoundShifter Pitch Mono",1);
  chk("TTSVRSsSoundshif","SoundShifter Pitch Stereo",1);
  printf("\n== 未知 Waves 产品(例如 Waves 9 里别的插件)仍要识别 ==\n");
  chk("XTSVABcMomething","Waves ?omething [ABc] Mono",1);
  chk("XTSVABcSomething","Waves ?omething [ABc] Stereo",1);
  printf("\n== 9.6 的三个 Tune 产品必须互不混淆(尾部完全相同)==\n");
  chk("LTSVLVwMaves tun","Waves Tune Real-Time Mono",1);
  chk("TTSVGNwMaves tun","Waves Tune Mono",1);
  chk("TTSVTNlMaves tun","Waves ?aves tun [TNl] Mono",1);   /* 假想的 Waves Tune LT 代码 */
  printf("\n== 必须【不】命中的 ==\n");
  chk("AESV8TA1uto-Tune","",0);                 /* 电音11 */
  chk("LTSVLVwXaves tun","",0);                 /* 声道字节非 M/S */
  chk("LXYZLVwMaves tun","",0);                 /* 字节1-3 不是 TSV */
  { TUID c; memcpy(c,"LTSVLVwM",8); memcpy(c+8,"\x01\x02ves tun",8);
    char nm[80]=""; int hit=cid_is_waves(c,nm,sizeof nm);
    printf("   名字尾部含不可打印字节 -> %-24s %s\n", hit?nm:"(不是 Waves 类)", hit?"FAIL":"OK");
    if(hit) fails++; }
  printf("\n失败数: %d\n",fails); return fails?1:0;
}
