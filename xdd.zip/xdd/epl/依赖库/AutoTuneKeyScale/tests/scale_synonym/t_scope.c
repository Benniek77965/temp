#include "t_scale_funcs.inc"       /* agent 侧真实函数: norm / scale_canon ... */
#include "t_lists.inc"             /* 真机日志生成的两份清单 */
#define _stricmp strcasecmp
#define MAXSG 48
#define MAXSN 96
static struct { unsigned long pid; char leaf[96]; int n; char nm[MAXSN][64]; } g_sg[MAXSG];
static int g_nsg = 0;
static int g_nsgBuild = 0;
static struct { unsigned long pid; char leaf[96]; char label[160]; } g_insts[64]; static int g_ninst=0;
#include "t_ctl_funcs.inc"         /* 控制器侧真实函数 */

/* 复刻 agent 的发布格式(含规范名映射),生成 scales_<pid>.txt 的内容 */
static void publish(char* b,int cap,const char* leaf,const char** L){
    int o=strlen(b); o+=snprintf(b+o,cap-o,"[%s]\n",leaf);
    char seen[128][48]; int ns=0;
    for(int i=0;L[i];i++){ const char* cn=scale_canon(L[i]); const char* out=cn?cn:L[i];
        char n[48]; norm(out,n,sizeof n);
        int dup=0; for(int q=0;q<ns;q++) if(!strcmp(seen[q],n)){dup=1;break;}
        if(dup) continue; snprintf(seen[ns++],48,"%s",n);
        o+=snprintf(b+o,cap-o,"%s\n",out); } }
int main(void){
    char buf[16384]=""; publish(buf,sizeof buf,"电音11.vst3",PRO);
                        publish(buf,sizeof buf,"Waves Tune Real-Time Mono",WAV);
    g_nsgBuild=0; g_nsg=0; parse_scales_buffer(4124,buf); g_nsg=g_nsgBuild;   /* 复刻 maybe_update_scales 的发布步骤 */
    printf("解析出 %d 个实例段:\n",g_nsg);
    for(int i=0;i<g_nsg;i++) printf("   [%s] %d 项\n",g_sg[i].leaf,g_sg[i].n);
    /* 控制器的 Target 列表(由 status 解析而来) */
    g_ninst=2; g_insts[0].pid=4124; strcpy(g_insts[0].leaf,"电音11.vst3");
               g_insts[1].pid=4124; strcpy(g_insts[1].leaf,"Waves Tune Real-Time Mono");
    static char out[MAXSN*2][64]; int fail=0;
    int a=compute_scale_list(0,out,MAXSN*2);
    printf("\n[Target=全部]      -> %d 项(交集 = 通用设置)\n   ",a);
    for(int i=0;i<a;i++) printf("%s | ",out[i]); printf("\n");
    int b1=compute_scale_list(1,out,MAXSN*2);
    printf("\n[Target=电音11]    -> %d 项(该插件完整能力)\n",b1);
    int c=compute_scale_list(2,out,MAXSN*2);
    printf("[Target=Waves]     -> %d 项(该插件完整能力)\n",c);
    printf("\n断言:\n");
    #define CK(cond,msg) do{ if(cond) printf("   OK   %s\n",msg); else {printf("   FAIL %s\n",msg); fail++;} }while(0)
    CK(g_nsg==2,                 "两个实例段都解析到");
    CK(a==14,                    "全部模式 = 14 项通用音阶(与之前算出的交集一致)");
    CK(b1==15,                   "选中电音11 = 它自己的 15 项 Modern Scale");
    CK(c==44,                    "选中 Waves = 它自己的 44 项");
    /* 通用项必须真的两边都有 */
    int allok=1; int n0=compute_scale_list(0,out,MAXSN*2);
    for(int i=0;i<n0;i++){ int inP=0,inW=0;
        for(int j=0;j<g_sg[0].n;j++) if(!strcasecmp(g_sg[0].nm[j],out[i])) inP=1;
        for(int j=0;j<g_sg[1].n;j++) if(!strcasecmp(g_sg[1].nm[j],out[i])) inW=1;
        if(!(inP&&inW)) allok=0; }
    CK(allok,                    "全部模式里的每一项都确实两边都支持(不会静默跳过)");
    /* 单插件时不应退化 */
    g_nsgBuild=0; g_nsg=0; parse_scales_buffer(1,(char*)({static char t[8192]; t[0]=0; publish(t,sizeof t,"Waves Tune Real-Time Mono",WAV); t;})); g_nsg=g_nsgBuild;
    g_ninst=1; g_insts[0].pid=1; strcpy(g_insts[0].leaf,"Waves Tune Real-Time Mono");
    int d=compute_scale_list(0,out,MAXSN*2);
    CK(d==44,                    "只挂一个插件时,全部模式 = 它的完整 44 项(不缩水)");
    printf("\n失败数: %d\n",fail); return fail?1:0;
}
