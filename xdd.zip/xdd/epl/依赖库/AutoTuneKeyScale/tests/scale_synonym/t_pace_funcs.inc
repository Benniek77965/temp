/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
static int strstr_ci(const char* hay,const char* needle){
    if(!hay||!needle) return 0;
    for(const char* p=hay;*p;p++){ int i=0;
        while(needle[i] && p[i] && ((p[i]|32)==(needle[i]|32))) i++;
        if(!needle[i]) return 1; }
    return 0; }
static const char* const EAT_CLEARED[]  = { "waveshell", "t-pain", "auto-tune pro.vst3", "auto-tune.vst3", NULL };
static const char* const VTBL_CLEARED[] = { "waveshell", "t-pain", NULL };
static int module_in(const char* path, const char* const* list){
    if(!path||!list) return 0;
    const char* leaf=path;
    for(const char* q=path;*q;q++) if(*q=='\\'||*q=='/') leaf=q+1;
    for(int i=0;list[i];i++) if(strstr_ci(leaf,list[i])) return 1;
    return 0; }
