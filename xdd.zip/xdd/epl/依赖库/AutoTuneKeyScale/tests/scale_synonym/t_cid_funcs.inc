static int cid_is_waves(const TUID cid, char* out, int outsz){
    const unsigned char* b=(const unsigned char*)cid;
    if(b[1]!='T' || b[2]!='S' || b[3]!='V') return 0;          /* not a Waves VST3 class id */
    if(b[7]!='M' && b[7]!='S') return 0;                        /* no channel marker */
    for(int i=4;i<16;i++) if(b[i]<32 || b[i]>126) return 0;     /* code + name tail must be printable */
    char code[4]; memcpy(code,b+4,3); code[3]=0;
    char tail[9]; memcpy(tail,b+8,8); tail[8]=0;
    const char* ch = (b[7]=='M') ? "Mono" : "Stereo";
    static const struct { const char* code; const char* name; } KNOWN[] = {
        { "LVw", "Waves Tune Real-Time" },
        { "GNw", "Waves Tune" },
        { "RSs", "SoundShifter Pitch" },
        { NULL, NULL } };
    const char* prod=NULL;
    for(int i=0;KNOWN[i].code;i++) if(!strcmp(code,KNOWN[i].code)){ prod=KNOWN[i].name; break; }
    if(out && outsz>0){
        if(prod) snprintf(out,outsz,"%s %s",prod,ch);
        else     snprintf(out,outsz,"Waves ?%s [%s] %s",tail,code,ch);   /* unknown: stays unique */
    }
    return 1;
}