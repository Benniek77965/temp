#!/usr/bin/env python3
"""从源码重新生成 *_funcs.inc —— 跑测试前执行。

为什么需要这个脚本
------------------
测试套件的卖点是「直接从源码提取真实函数」,但提取一直是**手工**做的,
生成出来的 .inc 是静态快照。源码改了、快照没跟着改,测试就只是在验证
一段早已不存在的旧代码。

这不是假想:
  * 1094 改了参数识别链之后,t_chain.inc 仍是旧的,测试给出了错误结论;
  * 实测把 at_agent.cpp 里的 inst_id 改成恒返回 0(足以让精确寻址彻底失效),
    41 套测试**全部通过**。

所以"提取"必须是跑测试的一个步骤,而不是某次手工动作。

用法
----
    python3 extract.py            # 重新生成
    python3 extract.py --check    # 只检查是否过期,过期则非零退出

覆盖范围
--------
只处理本文件登记的 .inc。其余 .inc 是更早手工做的、没有记录提取规则,
无法逆向;它们由 t_fresh 这套测试间接守护 —— 那套会核对快照内容是否
仍能在源码里找到。
"""
import re, sys, os

AGENT = "../../combined/at_agent.cpp"
CTL   = "../../vst3/cpp/AutoTune_KeyScale_Controller.cpp"

def read(p):
    return open(p, encoding="utf-8", errors="surrogateescape").read()

def grab(src, pattern, what):
    m = re.search(pattern, src, re.S)
    if not m:
        raise SystemExit(f"提取失败:在源码中找不到 {what}\n"
                         f"  —— 多半是那段代码被改写了。请更新本脚本里的正则,\n"
                         f"     不要退而去手工编辑 .inc,那会让快照再次脱节。")
    return m.group(0)

def build():
    a, c = read(AGENT), read(CTL)
    out = {}

    hdr = "/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */\n"

    # --- inst_id ---
    out["t_warn_funcs.inc"] = (hdr + "#include <stdint.h>\n" +
        grab(a, r'static unsigned inst_id\(const void\* p\)\{.*?return lo \^ hi; \}', "inst_id"))

    # --- target_ok_obj:两处环境依赖换成测试桩,判定逻辑原样 ---
    out["t_target_funcs.inc"] = (hdr +
        "static unsigned long g_fakePid=0;\n#define GetCurrentProcessId() g_fakePid\n"
        "static unsigned g_fakeInstId=0;\n#define inst_id(p) g_fakeInstId\n"
        "static unsigned long g_targetPid=0; static char g_targetLeaf[96]=\"\";\n"
        "static unsigned g_targetId=0;\n" +
        grab(a, r'static int target_ok_obj\(const void\* obj, const char\* leaf\)\{.*?_stricmp\(leaf,g_targetLeaf\)==0; \}',
             "target_ok_obj"))

    # --- 负缓存 ---
    i = c.index("#define NEGCACHE"); j = c.index("#define PSNAP")   # 负缓存在控制器里
    out["t_tree_funcs.inc"] = hdr + "typedef unsigned long DWORD;\n" + c[i:j]

    # --- 清白清单 + module_in ---
    out["t_pace_funcs.inc"] = (hdr +
        "static int strstr_ci(const char* hay,const char* needle){\n"
        "    if(!hay||!needle) return 0;\n"
        "    for(const char* p=hay;*p;p++){ int i=0;\n"
        "        while(needle[i] && p[i] && ((p[i]|32)==(needle[i]|32))) i++;\n"
        "        if(!needle[i]) return 1; }\n"
        "    return 0; }\n" +
        grab(a, r'static const char\* const EAT_CLEARED\[\][^;]*;\s*\nstatic const char\* const VTBL_CLEARED\[\][^;]*;', "两份清白清单") + "\n" +
        grab(a, r'static int module_in\(const char\* path, const char\* const\* list\)\{.*?return 0; \}', "module_in"))

    # --- 实例名表 ---
    blk = (grab(a, r'#define MAXIN \d+', "MAXIN") + "\n" +
           grab(a, r'static void\* g_inObj\[MAXIN\];[^\n]*\n', "实例名表").rstrip("\n") + "\n" +
           grab(a, r'static void inst_name_set\(void\* obj, const char\* name\)\{.*?LeaveCriticalSection\(&g_catchCs\); \}', "inst_name_set"))
    blk = (blk.replace("if(g_catchCsInit) EnterCriticalSection(&g_catchCs);", "/* lock: n/a in test */")
              .replace("if(g_catchCsInit) LeaveCriticalSection(&g_catchCs);", "/* unlock: n/a in test */"))
    out["t_variant_funcs.inc"] = hdr + "#include <stdlib.h>\n" + blk

    # --- v2_disc_name:两处插件调用换成测试喂入,其余逻辑原样 ---
    vdn = grab(a, r'static int v2_disc_name\(AEffect\* e, int idx.*?snprintf\(out,outsz,"%s",tbl\[pos\]\); return 1; \}', "v2_disc_name")
    vdn = (vdn.replace("static int v2_disc_name(AEffect* e, int idx, const char* const* tbl, int n, char* out, int outsz){",
                       "static int v2_disc_name_t(const char* disp, double val, const char* const* tbl, int n, char* out, int outsz){")
              .replace("    out[0]=0; if(idx<0) return 0;\n", "    out[0]=0;\n")
              .replace("    gp2_disp(e,idx,out,outsz); trim(out);\n", '    snprintf(out,outsz,"%s",disp?disp:"");\n')
              .replace("    double v=gp2_param(e,idx); if(v<0) return 0;\n", "    double v=val; if(v<0) return 0;\n"))
    vdn = re.sub(r'/\*.*?\*/', '', vdn, flags=re.S)

    # --- T-Pain 位置表 + key_to_pc ---
    out["t_tpv2_funcs.inc"] = (hdr +
        re.sub(r'/\*.*?\*/', '', grab(a, r'#define TPAIN_NSCALE.*?"C","C#","D","D#","E","F","F#","G","G#","A","A#","B" \};', "T-Pain 位置表"), flags=re.S) + "\n" +
        re.sub(r'/\*.*?\*/', '', grab(a, r'static int key_to_pc\(const char\* k\)\{.*?return -1; \}', "key_to_pc"), flags=re.S) + "\n" + vdn)

    # --- 参数识别链(t_disc 用):整条 if/else 链,Root note 等条目都在其中 ---
    chain = grab(a, r'if\(!d->haveS && !_stricmp\(tnm,"Scale"\)\).*?haveWRange=1; \}', "参数识别链")
    chain = re.sub(r'/\*.*?\*/', '', chain, flags=re.S)
    out["t_chain.inc"] = hdr + "\n".join(l for l in chain.split("\n") if l.strip()) + "\n"

    # --- eat_find_slot:加载器锁内的导出表解析,整段原样提取 ---
    out["t_eat_funcs.inc"] = (hdr +
        "#include <stdint.h>\n#include <string.h>\n"
        "typedef uint32_t DWORD; typedef uint32_t ULONG; typedef uint16_t WORD; typedef int32_t LONG;\n" +
        grab(a, r'static int eat_find_slot\(unsigned char\* b, ULONG size, const char\* want, DWORD\*\* slotOut, DWORD\* origOut\)\{.*?\n    return 0; \}',
             "eat_find_slot"))

    # --- 存活判定(t_life 用):liveness_decide + waves_probe_decide ---
    # t_life_funcs.inc 原先是手工快照、不在本表里,源码一改就没人发现。1145 加入
    # waves_probe_decide 时一并登记,两个函数都从源码原样提取。
    out["t_life_funcs.inc"] = (hdr +
        grab(a, r'static int liveness_decide\(int\* rel, int\* strike, unsigned n\)\{.*?\*strike = 0; return 0; \}', "liveness_decide") + "\n" +
        grab(a, r'static int waves_probe_decide\(int isWaves, int hasHandler, int rel, unsigned n\)\{.*?\? 1 : 0; \}', "waves_probe_decide") + "\n")

    # --- 日志拼行(t_log 用):log_compose ---
    # t_log_funcs.inc 原先是手工快照(LOG 函数体的一段复刻),不在本表里。1148 把拼行抽成
    # log_compose 并加了时间,同时登记,从源码原样提取。
    out["t_log_funcs.inc"] = (hdr +
        grab(a, r'static int log_compose\(char\* line, int cap, unsigned long pid, unsigned long ms, const char\* fmt, va_list ap\)\{.*?return n; \}', "log_compose") + "\n")

    # --- 整条写入或不写(t_rec 用):rec_append(1152 后)---
    out["t_rec_funcs.inc"] = (hdr +
        grab(a, r'static int rose\(int\* was, int now\)\{[^\n]*\}', "rose") + "\n" +
        grab(a, r'static int rec_append\(char\* buf, int cap, int\* off, const char\* fmt, \.\.\.\)\{.*?\*off\+=n; return 1; \}', "rec_append") + "\n")

    # --- catch 列表(内置数组 + is_catch_path),t_catchcap 用 ---
    cc = grab(a, r'static char g_catchPat\[8\]\[64\];[^\n]*\n', "g_catchPat 声明")
    cc += grab(a, r'static const char\* const g_catchBuiltin\[\][^;]*;', "g_catchBuiltin") + "\n"
    isc = grab(a, r'static int is_catch_path\(const char\* low\)\{.*?return 0; \}', "is_catch_path")
    isc = isc.replace("if(!g_catchLoaded) load_catch_list();", "")   # 测试直接填 g_catchPat
    out["t_catchcap_funcs.inc"] = hdr + cc + isc

    # --- 三份原本手工维护、已经过期的快照 ---
    # 它们曾各自带着一份【过时的】源码拷贝:t_seam/t_trim 里是 1120 修掉的 UB 版 inst_id,
    # t_ctl 里是 1130 之前的音阶段循环。测试照常通过,因为它们验证的是快照、不是源码。
    inst = grab(a, r'static unsigned inst_id\(const void\* p\)\{.*?return lo \^ hi; \}', "inst_id")
    OLD_INSTID = ("static unsigned inst_id(const void* p){ uintptr_t v=(uintptr_t)p; "
                  "return (unsigned)(v ^ (v>>32)); }")
    for name in ("t_seam_agent.inc","t_trim_funcs.inc"):
        cur = read(name)
        if inst in cur:
            out[name] = cur                      # 已是最新
        elif OLD_INSTID in cur:
            out[name] = cur.replace(OLD_INSTID, inst, 1)
        else:
            raise SystemExit(f"{name}: 找不到可替换的 inst_id —— 请检查该文件是否被改过,"
                             f"不要在不确定的内容上做替换。")
    # Controller dropdown/scales UI was removed; its fixtures are retired.

    # --- 另外两份手工快照里已脱节的函数(1139) ---
    # 签名一样、函数体早已不同:t_shells 的 is_catch_path 里没有 1128 的内置数组那一行,
    # t_scale 的 load_scalemap 还是 1135 之前的写法。只比对「行文本是否出现过」发现不了这种,
    # 必须按函数体逐字比。
    def body_of_helper(text, s0, needBrace=False):
        i = text.find(s0 + "{") if needBrace else text.find(s0)
        if i < 0: i = text.find(s0)
        if i < 0: return None
        d = 0
        for j in range(i, len(text)):
            if text[j] == '{': d += 1
            elif text[j] == '}':
                d -= 1
                if d == 0: return text[i:j+1]
        return None

    def swap_fn(fname, sig, srctext):
        cur = read(fname)
        def body_of(text, s0):
            i = text.find(s0)
            if i < 0: return None
            d = 0
            for j in range(i, len(text)):
                if text[j] == '{': d += 1
                elif text[j] == '}':
                    d -= 1
                    if d == 0: return text[i:j+1]
            return None
        # 源码里同名的前向声明在定义之前,find 会先撞上它(那行以 ';' 结尾、没有函数体)。
        # 所以在源码一侧专门找带 '{' 的那一处。
        old_b = body_of(cur, sig)
        k = srctext.find(sig + "{")
        if k < 0: k = srctext.find(sig + " {")
        new_b = body_of(srctext[k:], sig) if k >= 0 else None
        if old_b is None or new_b is None:
            raise SystemExit(f"{fname}: 找不到 {sig} 的函数体,请人工确认后再改")
        return cur.replace(old_b, new_b, 1)

    sh = swap_fn("t_shells_agent.inc", "static int strstr_ci(const char* hay, const char* needle)", a)
    open("t_shells_agent.inc","w",encoding="utf-8").write(sh)
    sh = swap_fn("t_shells_agent.inc", "static int is_catch_path(const char* low)", a)
    # is_catch_path 现在要用 g_catchBuiltin(1128 加的),把那份声明一并带过来 ——
    # 提取一个函数就必须提取它依赖的数据,这正是手工快照最容易漏的地方。
    if "g_catchBuiltin" not in sh.split("static int is_catch_path")[0]:
        decl = grab(a, r'static const char\* const g_catchBuiltin\[\][^;]*;', "g_catchBuiltin")
        sh = sh.replace("static int is_catch_path", decl + "\nstatic int is_catch_path", 1)
    out["t_shells_agent.inc"] = sh

    # t_scale:整份重建。此前逐函数替换连续出错三次(漏依赖、撞前向声明、新旧签名不一致),
    # 根因是「在一份手工维护的文件上做局部手术」—— 每次都要猜它当前长什么样。
    # 整份按依赖顺序重建,就没有可猜的余地。
    sc  = "#include <stddef.h>\n#include <stdio.h>\n#include <string.h>\n#include <ctype.h>\n"
    sc += "static void LOG(const char* f,...){ (void)f; }\n"
    sc += "#define fopen_retry(p,m) fopen(p,m)   /* 重试只针对 Windows 的共享冲突,这里用普通 fopen */\n"
    sc += "static int at_lower(int c){ return (c>=65&&c<=90)?c+32:c; }\n"
    sc += grab(a, r'static void trim\(char\* s\)\{.*?memmove\(s,s\+i,\(size_t\)\(n-i\+1\)\); \}', "trim") + "\n" 
    sc += grab(a, r'static int norm\(const char\* in,char\* out,int n\)\{.*?return j;\}', "norm") + "\n" 
    sc += grab(a, r'#define MAXGRP \d+', "MAXGRP") + "\n"
    sc += grab(a, r'#define MAXMEM \d+', "MAXMEM") + "\n"
    sc += grab(a, r'static char g_grpN\[MAXGRP\][^\n]*\n', "分组表")
    sc += grab(a, r'static int g_grpCnt\[MAXGRP\][^\n]*\n', "分组计数")
    sc += "static char g_scalemapPath[260]=\"\";\n"
    sc += grab(a, r'static int grp_add_line\(const char\* line\)\{.*?g_nGrp\+\+; return 1; \}', "grp_add_line") + "\n"
    sc += grab(a, r'static void drop_bom\(char\* s\)\{[^\n]*\}', "drop_bom") + "\n"
    sc += grab(a, r'static void load_scalemap\(\)\{.*?line\(s\) ignored[^;]*; \} \}', "load_scalemap") + "\n"
    sc += grab(a, r'static int grp_of\(const char\* nm\)\{.*?return -1; \}', "grp_of") + "\n"
    sc += grab(a, r'static int scale_same\(const char\* aNorm, const char\* bNorm\)\{.*?grp_of\(bNorm\)\); \}', "scale_same") + "\n"
    sc += grab(a, r'static const char\* scale_canon\(const char\* disp\)\{.*?g_grpDisp\[g\] : NULL; \}', "scale_canon") + "\n"
    out["t_scale_funcs.inc"] = hdr + sc

    # --- scalemap 的分组解析(t_smap 用) ---
    sm  = grab(a, r'#define MAXGRP \d+', "MAXGRP") + "\n"
    sm += grab(a, r'#define MAXMEM \d+', "MAXMEM") + "\n"
    sm += grab(a, r'static char g_grpN\[MAXGRP\][^\n]*\n', "分组表")
    sm += grab(a, r'static int g_grpCnt\[MAXGRP\][^\n]*\n', "分组计数")
    gal = grab(a, r'static int grp_add_line\(const char\* line\)\{.*?g_nGrp\+\+; return 1; \}', "grp_add_line")
    out["t_smap_funcs.inc"] = (hdr +
        "#include <stdlib.h>\n"
        "static void trim(char* s){ int n=(int)strlen(s); while(n>0 && (unsigned char)s[n-1]<=' ') s[--n]=0;\n"
        "    int i=0; while(s[i]==' '||s[i]=='\\t') i++; if(i) memmove(s,s+i,strlen(s+i)+1); }\n"
        "static void norm(const char* in,char* out,int n){ int o=0;\n"
        "    for(int i=0;in[i]&&o<n-1;i++){ char ch=in[i]; if(ch==' '||ch=='-'||ch=='_') continue;\n"
        "        out[o++]=(ch>='A'&&ch<='Z')?(char)(ch+32):ch; } out[o]=0; }\n"
        "#define LOG(...) ((void)0)\n" + sm + gal)

    # --- 1162:离开 exe 目录时按「名字 + 内容」认文件(t_mig 用) ---
    # 迁移要在用户自己的目录里清理旧文件;判定稍宽,就会重犯 1161 按名字误删用户文件的错。
    mg  = "#include <string.h>\n#include <stdio.h>\n"
    mg += grab(c, r'static int at_lower\(int c\)\{[^\n]*\}', "at_lower") + "\n"
    mg += grab(c, r'static int at_stricmp\(const char\* a, const char\* b\)\{.*?a\+\+; b\+\+; \} \}', "at_stricmp") + "\n"
    mg += grab(c, r'enum \{ MIG_NONE=0[^;]*;', "MIG 枚举") + "\n"
    mg += grab(c, r'static int pid_suffix\(const char\* name, const char\* prefix, const char\* ext, unsigned long\* pid\)\{.*?\*pid=\(unsigned long\)v; return 1; \}', "pid_suffix") + "\n"
    mg += grab(c, r'static int mig_name_candidate\(const char\* name\)\{.*?pid_suffix\(name,"scales_",".txt.tmp",&pid\); \}', "mig_name_candidate") + "\n"
    mg += grab(c, r'static int looks_module_path\(const char\* s\)\{.*?!at_stricmp\(tail\+1,".dll"\); \}', "looks_module_path") + "\n"
    mg += grab(c, r'static int mig_classify\(const char\* name, const char\* head, long size, unsigned long\* pid\)\{.*?\n    return MIG_NONE; \}', "mig_classify") + "\n"
    out["t_mig_funcs.inc"] = hdr + mg

    # --- 控制器的尺寸常量(t_e2e 用) ---
    sz = ""
    for name in ("MAXINST","INSTSIG_SZ"):
        sz += grab(c, r'#define '+name+r'[^\n]*\n', name)
    out["t_e2e_funcs.inc"] = hdr + sz

    # --- 控制器的状态行解析 ---
    out["t_pline_funcs.inc"] = hdr + grab(c, r'static int parse_status_line\(.*?\n    return 1; \}', "parse_status_line")

    return out

def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    want = build()
    check = "--check" in sys.argv
    stale = []
    for name, body in want.items():
        body = body.rstrip("\n") + "\n"
        cur = read(name) if os.path.exists(name) else None
        if cur == body:
            continue
        stale.append(name)
        if not check:
            open(name, "w", encoding="utf-8", errors="surrogateescape").write(body)
    if check:
        if stale:
            print("以下快照已与源码脱节,请先运行 extract.py:")
            for n in stale: print("   ", n)
            return 1
        print(f"{len(want)} 份快照均与源码一致")
        return 0
    print(f"已重新生成 {len(stale)} / {len(want)} 份" if stale else f"{len(want)} 份均已是最新")
    return 0

if __name__ == "__main__":
    sys.exit(main())
