/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
#include <string.h>
#include <stdio.h>
static int at_lower(int c){ return (c>='A'&&c<='Z') ? c+32 : c; }
static int at_stricmp(const char* a, const char* b){
    for(;;){ int ca=at_lower((unsigned char)*a), cb=at_lower((unsigned char)*b);
             if(ca!=cb) return ca-cb;
             if(!ca) return 0;
             a++; b++; } }
enum { MIG_NONE=0, MIG_RUNTIME, MIG_PENDING, MIG_STATE, MIG_LOG, MIG_TEMPLATE, MIG_USER };
static int pid_suffix(const char* name, const char* prefix, const char* ext, unsigned long* pid){
    size_t pl=strlen(prefix), el=strlen(ext), nl=strlen(name);
    if(nl<=pl+el || nl-pl-el>10) return 0;
    for(size_t i=0;i<pl;i++) if(at_lower((unsigned char)name[i])!=at_lower((unsigned char)prefix[i])) return 0;
    if(at_stricmp(name+nl-el,ext)!=0) return 0;
    unsigned long long v=0;
    for(size_t i=pl;i<nl-el;i++){ char c=name[i]; if(c<'0'||c>'9') return 0; v=v*10+(unsigned)(c-'0'); }
    if(v==0 || v>0xFFFFFFFFull) return 0;
    *pid=(unsigned long)v; return 1; }
static int mig_name_candidate(const char* name){
    static const char* const fixed[]={"cmd.ini","eject.flag","eject_on_close.flag","dawhost.txt","use_factory_hook.txt",
        "agent.log","scalemap.txt","noeat.txt","nouithread.txt","skip.txt","catch.txt","disabled.txt",NULL};
    unsigned long pid=0;
    for(int i=0;fixed[i];i++) if(!at_stricmp(name,fixed[i])) return 1;
    return pid_suffix(name,"status_",".txt",&pid) || pid_suffix(name,"scales_",".txt",&pid) || pid_suffix(name,"pending_",".txt",&pid)
        || pid_suffix(name,"status_",".txt.tmp",&pid) || pid_suffix(name,"scales_",".txt.tmp",&pid); }
static int looks_module_path(const char* s){
    int n=(int)strlen(s); while(n>0 && (unsigned char)s[n-1]<=' ') n--;
    int abs = (n>3 && s[1]==':' && s[2]=='\\') || (n>2 && s[0]=='\\' && s[1]=='\\');
    if(!abs || n<5) return 0;
    char tail[8]; memcpy(tail,s+n-5,5); tail[5]=0;
    return !at_stricmp(tail,".vst3") || !at_stricmp(tail+1,".dll"); }
static int mig_classify(const char* name, const char* head, long size, unsigned long* pid){
    unsigned long p=0; *pid=0;
    if(pid_suffix(name,"status_",".txt",&p)){ *pid=p;       /* the agent writes "#b<build>" first (since 1151) */
        return (head[0]=='#' && head[1]=='b' && head[2]>='0' && head[2]<='9') ? MIG_RUNTIME : MIG_NONE; }
    if(pid_suffix(name,"scales_",".txt",&p)){ *pid=p;       /* one "[plug-in]" section after another */
        return head[0]=='[' ? MIG_RUNTIME : MIG_NONE; }
    if(pid_suffix(name,"status_",".txt.tmp",&p)){ *pid=p;   /* half-published, so it may be empty */
        return (size==0 || (head[0]=='#' && head[1]=='b')) ? MIG_RUNTIME : MIG_NONE; }
    if(pid_suffix(name,"scales_",".txt.tmp",&p)){ *pid=p;
        return (size==0 || head[0]=='[') ? MIG_RUNTIME : MIG_NONE; }
    if(pid_suffix(name,"pending_",".txt",&p)){ *pid=p;      /* 1161 always left it empty; a path is crash evidence */
        return (size==0 || looks_module_path(head)) ? MIG_PENDING : MIG_NONE; }
    if(!at_stricmp(name,"cmd.ini")){                         /* write_cmd(): key= / retune= / audiotype= first, |t= always */
        int ours = (!strncmp(head,"key=",4) || !strncmp(head,"retune=",7) || !strncmp(head,"audiotype=",10)) && strstr(head,"|t=")!=NULL;
        return ours ? MIG_RUNTIME : MIG_NONE; }
    if(!at_stricmp(name,"eject.flag"))           return (size==2 && !strcmp(head,"1\n")) ? MIG_RUNTIME : MIG_NONE;
    if(!at_stricmp(name,"eject_on_close.flag"))  return (size==2 && !strcmp(head,"1\n")) ? MIG_STATE : MIG_NONE;
    if(!at_stricmp(name,"dawhost.txt"))          return !strncmp(head,"# DAW exe-name fragments",24) ? MIG_STATE : MIG_NONE;
    if(!at_stricmp(name,"use_factory_hook.txt")) return MIG_STATE;       /* our name alone: nobody else uses it */
    if(!at_stricmp(name,"agent.log")){                       /* every record starts "[<pid>] " */
        if(head[0]!='[') return MIG_NONE;
        int i=1; while(head[i]>='0' && head[i]<='9') i++;
        return (i>1 && head[i]==']' && head[i+1]==' ') ? MIG_LOG : MIG_NONE; }
    if(!at_stricmp(name,"scalemap.txt")){
        if(strncmp(head,"# scalemap.txt - scale synonym groups",37)!=0) return MIG_USER;   /* written by hand */
        if(size>(long)strlen(head)) return MIG_USER;         /* longer than what we looked at: not the bare template */
        for(const char* q=head; *q; ){ while(*q==' '||*q=='\t') q++;
            if(*q && *q!='#' && *q!='\r' && *q!='\n') return MIG_USER;      /* a group was added */
            while(*q && *q!='\n') q++;
            if(*q) q++; }
        return MIG_TEMPLATE; }
    if(!at_stricmp(name,"noeat.txt") || !at_stricmp(name,"nouithread.txt") || !at_stricmp(name,"skip.txt")
       || !at_stricmp(name,"catch.txt") || !at_stricmp(name,"disabled.txt")) return MIG_USER;
    return MIG_NONE; }
