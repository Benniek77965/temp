/* 音阶等价匹配(Minor = Natural Minor = Aeolian)

   这套测试曾经把 load_scalemap / scale_canon / norm 等函数的【手抄副本】直接内联在本文件里,
   连内置组表 DEF[] 也自带一份。于是源码怎么改它都看不见 —— 比 .inc 过期更隐蔽,
   因为代码就写在测试文件里,没人会想到去比对。
   1139 实测:把源码内置组里的 Aeolian 删掉,这套测试照常通过。

   现在全部改从 t_scale_funcs.inc 取,而那份由 extract.py 从 at_agent.cpp 生成。
   源码一改,这里立刻跟着变。 */
#include <stdlib.h>
#include "t_scale_funcs.inc"

/* 本地辅助:大小写无关比较。源码里没有同名函数,所以留在这里。 */
static int at_stricmp(const char* a,const char* b){
    for(;;){ int x=at_lower((unsigned char)*a), y=at_lower((unsigned char)*b);
             if(x!=y) return x-y; if(!x) return 0; a++; b++; } }

#include "t_main.inc"
