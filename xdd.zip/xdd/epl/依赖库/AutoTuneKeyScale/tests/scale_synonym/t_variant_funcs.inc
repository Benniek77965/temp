/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
#include <stdlib.h>
#define MAXIN 64
static void* g_inObj[MAXIN]; static char g_inName[MAXIN][96]; static int g_nIn=0;
static void inst_name_set(void* obj, const char* name){
    if(!obj||!name||!name[0]) return;
    /* lock: n/a in test */
    int f=-1; for(int i=0;i<g_nIn;i++) if(g_inObj[i]==obj){ f=i; break; }
    if(f<0 && g_nIn<MAXIN) f=g_nIn++;
    else if(f<0){ for(int i=0;i+1<MAXIN;i++){ g_inObj[i]=g_inObj[i+1]; memcpy(g_inName[i],g_inName[i+1],96); } f=MAXIN-1; }   /* oldest out */
    g_inObj[f]=obj; snprintf(g_inName[f],96,"%s",name);
    /* unlock: n/a in test */ }
