/* 没有调音插件的进程不该留下状态文件(1111)

   1107 之前,"被注入"约等于"装着调音插件",每个 agent 写一个 status_<pid>.txt 是合理的。
   1107 让注入扩大到【所有 VST 宿主及其全部子进程】之后,这个前提不再成立:
   一堆根本没有调音插件的进程也会各写一个只含版本标记的空状态文件,
   而控制器每 ~300ms 就要遍历该目录并逐个打开解析。

   判据必须精确:内容长度是否仍等于【表头本身的长度】。
   先前写成 strlen("#b0000\n")+1 这种硬编码,既依赖版本号位数,又多算了一个字节。 */
#include <stdio.h>
#include <string.h>

/* 复刻判定:off 是已写入长度,hdrLen 是版本标记长度 */
static int should_delete(int off,int hdrLen){ return off <= hdrLen; }

static int fails=0;
static void chk(const char* what,int got,int want){
    int ok=(got==want);
    printf("   %-46s %-8s %s\n",what,got?"删除文件":"保留文件",ok?"OK":"FAIL");
    if(!ok) fails++;
}
int main(void){
    printf("== 以不同版本号位数验证,判定不得依赖位数 ==\n");
    const char* hdrs[]={"#b999\n","#b1110\n","#b10000\n",0};
    for(int i=0;hdrs[i];i++){
        int h=(int)strlen(hdrs[i]);
        char m[80];
        snprintf(m,sizeof m,"表头长 %d,只有表头",h);
        chk(m, should_delete(h,h), 1);
        snprintf(m,sizeof m,"表头长 %d,多出 1 字节",h);
        chk(m, should_delete(h+1,h), 0);
    }

    printf("\n== 真实状态行必须保留 ==\n");
    { const char* hdr="#b1110\n";
      const char* line="Sam_x64.exe | Auto-Tune Pro.vst3  Key=C  Scale=Major\n";
      int h=(int)strlen(hdr);
      int off=h+(int)strlen(line);
      chk("一条实例行", should_delete(off,h), 0); }

    printf("\n== 占位符行(已加载未捕获)也要保留 ==\n");
    { const char* hdr="#b1110\n";
      const char* line="Sam_x64.exe | X.vst3  [[PENDING]]\n";
      int h=(int)strlen(hdr);
      chk("占位符行", should_delete(h+(int)strlen(line),h), 0); }

    printf("\n== 旧写法的缺陷:硬编码长度会多算一字节 ==\n");
    { int h=(int)strlen("#b1110\n");                 /* 7 */
      int oldThreshold=(int)strlen("#b0000\n")+1;    /* 8 */
      printf("   实际表头 %d,旧阈值 %d -> 旧写法会把 %d 字节的内容也当成空 %s\n",
             h,oldThreshold,oldThreshold,(oldThreshold>h)?"(确有偏差)":"");
      if(oldThreshold<=h) fails++; }

    printf("\n== 音阶文件:无实例时必须删除,不能只是停写(1113) ==\n");
    { /* Target=「全部」时音阶取各段【交集】,陈旧段会继续参与 */
      /* 场景:机架里 Waves(44) + T-Pain(6),移除 T-Pain 之后 */
      int wavesN=44, tpainN=6;
      int liveOnly   = wavesN;                 /* 只剩 Waves -> 应为 44 */
      int withStale  = (wavesN<tpainN?wavesN:tpainN);  /* 陈旧段仍在 -> 交集被压到 6 */
      printf("   移除 T-Pain 后,交集应为 %d 项\n",liveOnly);
      printf("   若陈旧文件仍参与,交集只剩 %d 项 -> Waves 独有的音阶全部选不了\n",withStale);
      chk("删除陈旧段后恢复完整列表", liveOnly==44, 1);
      chk("保留陈旧段会压缩列表(即 bug)", withStale==6, 1); }

    printf("\n== 两侧必须对称:status 与 scales ==\n");
    { /* 1111 修了 status,1113 修了 scales —— 同一个洞的两半 */
      int statusDeletesWhenEmpty = 1;   /* 1111 */
      int scalesDeletesWhenEmpty = 1;   /* 1113 */
      chk("status 无内容时删除", statusDeletesWhenEmpty, 1);
      chk("scales 无内容时删除", scalesDeletesWhenEmpty, 1);
      printf("   ↑ 「off>0 才写」只阻止写新的,不会删旧的 —— 进程还活着,\n");
      printf("     控制器就一直读那份已经失效的内容。\n"); }

    printf("\n== 清理通配符必须覆盖 .tmp 残留(1115) ==\n");
    { /* publish_file 先写 <name>.tmp 再原子改名;进程被强杀会留下 .tmp */
      struct { const char* file; int matchTxt, matchTmp; const char* why; } F[]={
        {"status_1234.txt",      1,0,"正常状态文件"},
        {"scales_1234.txt",      1,0,"正常音阶文件"},
        {"status_1234.txt.tmp",  0,1,"强杀留下的状态临时文件"},
        {"scales_1234.txt.tmp",  0,1,"强杀留下的音阶临时文件"}};
      for(int i=0;i<4;i++){
        int L=(int)strlen(F[i].file);
        int isTxt = L>4 && !strcmp(F[i].file+L-4,".txt");
        int isTmp = L>4 && !strcmp(F[i].file+L-4,".tmp");
        int ok = (isTxt==F[i].matchTxt) && (isTmp==F[i].matchTmp);
        printf("   %-32s *.txt=%d  *.tmp=%d  %s\n",F[i].why,isTxt,isTmp,ok?"OK":"FAIL");
        if(!ok) fails++; }
      printf("   ↑ 原先两处清理都只匹配 *.txt,.tmp 残留永远删不掉,一次强杀留一个\n"); }

    printf("\n失败数: %d\n",fails);
    return fails?1:0;
}
