/* 控制器解出 agent 的实测(1151)。直接 #include 控制器源码,链接它的资源(内嵌的 agent 与注入程序)。
   起因:用户的两次会话里注入的是旧版 agent。控制器原先在刷新失败时"只要磁盘上已有一份可用的就行"——
   而那一份可能是旧版本。现在每个文件解出后都与内嵌副本逐字节核对,不一致就换新文件名。 */
#define WinMain controller_WinMain
#include "../../vst3/cpp/AutoTune_KeyScale_Controller.cpp"
#undef WinMain
#include <stdio.h>
#include <string>
static int fails=0;
static void ck(int c,const char* m){ printf("   %s %s\n",c?"OK  ":"FAIL",m); if(!c) fails++; }
static void put_junk(const char* p){ FILE* f=fopen(p,"wb"); fputs("an older agent build",f); fclose(f); }
/* 第十三节用:另一个线程扮演用户,操作真实的「高级设置」窗口(主线程此时在窗口的模态循环里) */
struct UiCheck { int mode, found, waves, noeat, noui, skipRO, smapRO, wavesEnabled, mbSeen, mbSaved; char skip[256], katch[256]; };
static BOOL CALLBACK mb_text(HWND c, LPARAM lp){ wchar_t t[512]; GetWindowTextW(c,t,512); if(wcsstr(t,L"\u5df2\u4fdd\u5b58")) *(int*)lp=1; return TRUE; }   /* 已保存 */
static DWORD WINAPI ui_driver(LPVOID p){
    UiCheck* u=(UiCheck*)p; HWND d=NULL;
    for(int i=0;i<100 && !d;i++){ d=FindWindowW(L"AT8Settings",NULL); if(!d) Sleep(50); }
    if(!d) return 1;
    u->found=1;
    u->waves=IsDlgButtonChecked(d,IDS_WAVES)==BST_CHECKED; u->noeat=IsDlgButtonChecked(d,IDS_NOEAT)==BST_CHECKED; u->noui=IsDlgButtonChecked(d,IDS_NOUI)==BST_CHECKED;
    GetDlgItemTextA(d,IDS_SKIP,u->skip,sizeof u->skip); GetDlgItemTextA(d,IDS_CATCH,u->katch,sizeof u->katch);
    u->skipRO=(GetWindowLongW(GetDlgItem(d,IDS_SKIP),GWL_STYLE)&ES_READONLY)!=0;
    u->smapRO=(GetWindowLongW(GetDlgItem(d,IDS_SMAP),GWL_STYLE)&ES_READONLY)!=0;
    u->wavesEnabled=IsWindowEnabled(GetDlgItem(d,IDS_WAVES))?1:0;
    if(u->mode==1){
        SetDlgItemTextA(d,IDS_CATCH,"mydaw\r\nother");
        SendDlgItemMessageW(d,IDS_NOEAT,BM_SETCHECK,BST_UNCHECKED,0);
        PostMessageW(d,WM_COMMAND,IDOK,0);
        HWND mb=NULL; for(int i=0;i<100 && !mb;i++){ mb=FindWindowW(L"#32770",L"\u9ad8\u7ea7\u8bbe\u7f6e"); if(!mb) Sleep(50); }   /* 提示框的标题「高级设置」 */
        if(mb){ u->mbSeen=1; EnumChildWindows(mb,mb_text,(LPARAM)&u->mbSaved); PostMessageW(mb,WM_COMMAND,IDOK,0); }
    } else {
        PostMessageW(d,WM_COMMAND,IDCANCEL,0);
        Sleep(400); HWND mb=FindWindowW(L"#32770",L"\u9ad8\u7ea7\u8bbe\u7f6e"); if(mb){ u->mbSeen=1; PostMessageW(mb,WM_COMMAND,IDOK,0); }
    }
    for(int i=0;i<100 && IsWindow(d);i++) Sleep(50);
    return 0; }
/* 第十五节用:扮演启动中的机架,像 agent 那样反复整体读 skip.txt */
struct TornCheck { volatile LONG stop; char path[MAX_PATH]; int reads, torn, missing; };
static DWORD WINAPI torn_reader(LPVOID p){
    TornCheck* t=(TornCheck*)p; const char* A_="foo\r\nbar\r\n"; const char* B_="waveshell\r\nalpha\r\nbeta\r\n";
    while(!t->stop){ FILE* f=fopen(t->path,"rb"); if(!f){ t->missing++; continue; }
        char b[256]; size_t n=fread(b,1,sizeof b-1,f); b[n]=0; fclose(f);
        if(strcmp(b,A_)!=0 && strcmp(b,B_)!=0) t->torn++;
        t->reads++; }
    return 0; }
/* 第十六节用:扮演 agent,在某个文件上占一会儿(像它的 fopen "r" 那样共享读写,或像改名时那样独占) */
struct HoldArgs { const char* path; int ms; DWORD share; volatile LONG ready; };
static DWORD WINAPI hold_file(LPVOID p){ HoldArgs* a=(HoldArgs*)p;
    HANDLE h=CreateFileA(a->path,GENERIC_READ,a->share,NULL,OPEN_EXISTING,0,NULL);
    InterlockedExchange(&a->ready,1); Sleep(a->ms); if(h!=INVALID_HANDLE_VALUE) CloseHandle(h); return 0; }
int main(){
    char dir[MAX_PATH]; GetTempPathA(sizeof dir,dir); strcat(dir,"w_extract_rt"); CreateDirectoryA(dir,NULL);
    char canon[MAX_PATH]; snprintf(canon,sizeof canon,"%s\\at_agent.dll",dir);
    char path[MAX_PATH];

    printf("== 一、磁盘上没有文件 ==\n");
    DeleteFileA(canon); g_agentStale=0; snprintf(path,sizeof path,"%s",canon);
    ensure_current("AGENT64",path,sizeof path);
    ck(!strcmp(path,canon) && file_matches_res("AGENT64",canon) && !g_agentStale, "解出到原文件名,内容与内嵌副本一致");

    printf("\n== 二、磁盘上是旧版本,但没被占用 ==\n");
    put_junk(canon); g_agentStale=0; snprintf(path,sizeof path,"%s",canon);
    ck(!file_matches_res("AGENT64",canon), "前提:核对能识别出旧内容");
    ensure_current("AGENT64",path,sizeof path);
    ck(!strcmp(path,canon) && file_matches_res("AGENT64",canon), "原地覆盖为当前版本");

    printf("\n== 三、磁盘上是旧版本,且被锁住(写不进、改不了名)—— 原先会照样注入它 ==\n");
    put_junk(canon);
    HANDLE lock=CreateFileA(canon,GENERIC_READ,0,NULL,OPEN_EXISTING,0,NULL);   /* 不共享:写、删、改名全部失败 */
    ck(lock!=INVALID_HANDLE_VALUE, "前提:旧文件已被独占锁住");
    g_agentStale=0; snprintf(path,sizeof path,"%s",canon);
    ensure_current("AGENT64",path,sizeof path);
    ck(strcmp(path,canon)!=0, "改用了新的文件名");
    ck(file_matches_res("AGENT64",path), "新文件名里是当前版本");
    ck(strstr(path,".b")!=NULL, "新文件名带版本标记,便于下次清理");
    ck(!g_agentStale, "没有误报'无法写出'");
    CloseHandle(lock);
    { char alt[MAX_PATH]; snprintf(alt,sizeof alt,"%s",path); DeleteFileA(alt); }

    printf("\n== 四、哪里都写不进 ==\n");
    { char bad[MAX_PATH]; snprintf(bad,sizeof bad,"%s\\no_such_dir\\at_agent.dll",dir);
      g_agentStale=0; snprintf(path,sizeof path,"%s",bad);
      ensure_current("AGENT64",path,sizeof path);
      ck(g_agentStale==1, "置位 g_agentStale,状态栏会明说,而不是悄悄注入旧文件"); }

    printf("\n== 五、启动时清理备用名副本(1152 后:与版本号首位数字无关) ==\n");
    { const char* keep[]={"at_agent.dll","at_agent32.dll","inject.exe","inject32.exe","at_agent.dll.old123",0};
      const char* gone[]={"at_agent.b1152_12345.dll","inject32.b1152_9.exe","at_agent.b2000_1.dll","at_agent32.b10000_77.dll",0};
      char fp[MAX_PATH];
      for(int i=0;keep[i];i++){ snprintf(fp,sizeof fp,"%s\\%s",dir,keep[i]); put_junk(fp); }
      for(int i=0;gone[i];i++){ snprintf(fp,sizeof fp,"%s\\%s",dir,gone[i]); put_junk(fp); }
      snprintf(fp,sizeof fp,"%s\\at_agent.b1152_inuse.dll",dir); put_junk(fp);
      HANDLE busy=CreateFileA(fp,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL);   /* 模拟仍被某个机架载入 */
      int n=clean_fresh_copies(dir);
      int okGone=1; for(int i=0;gone[i];i++){ snprintf(fp,sizeof fp,"%s\\%s",dir,gone[i]); if(GetFileAttributesA(fp)!=INVALID_FILE_ATTRIBUTES) okGone=0; }
      int okKeep=1; for(int i=0;keep[i];i++){ snprintf(fp,sizeof fp,"%s\\%s",dir,keep[i]); if(GetFileAttributesA(fp)==INVALID_FILE_ATTRIBUTES) okKeep=0; }
      snprintf(fp,sizeof fp,"%s\\at_agent.b1152_inuse.dll",dir); int busyStays=(GetFileAttributesA(fp)!=INVALID_FILE_ATTRIBUTES);
      ck(okGone && n==4, "四个备用名副本全部删除,包括 b2000、b10000(旧模式 *.b1*_* 会漏掉 b2000)");
      ck(okKeep, "正式文件与 .old 副本一个不碰");
      ck(busyStays, "仍被占用的那份删不掉,留到下次");
      CloseHandle(busy); clean_fresh_copies(dir);
      for(int i=0;keep[i];i++){ snprintf(fp,sizeof fp,"%s\\%s",dir,keep[i]); DeleteFileA(fp); } }

    printf("\n== 六、机架里的 agent 与控制器版本不一致时的提示(1157) ==\n");
    { wchar_t h[300];
      agent_mismatch_header(h,300,AT_BUILD_EXPECT-5);
      ck(wcsstr(h,L"\u65e7\u7248")!=NULL && wcsstr(h,L"\u91cd\u542f\u8be5\u673a\u67b6")!=NULL, "机架里的更旧:说'旧版',建议重启该机架");
      agent_mismatch_header(h,300,AT_BUILD_EXPECT+5);
      ck(wcsstr(h,L"\u65e7\u7248")==NULL && wcsstr(h,L"\u66f4\u65b0")!=NULL, "机架里的更新:不说'旧版',说'更新'");
      ck(wcsstr(h,L"\u6539\u7528\u65b0\u7248\u63a7\u5236\u5668")!=NULL && wcsstr(h,L"\u4e0d\u8981\u91cd\u542f")!=NULL,
         "机架里的更新:建议改用新版控制器、不要重启机架(重启会把它降级)");
      wchar_t num[32]; swprintf(num,32,L"build %d",AT_BUILD_EXPECT+5);
      ck(wcsstr(h,num)!=NULL, "提示里写出机架那边的版本号");
      agent_mismatch_header(h,300,0);
      ck(wcsstr(h,L"\u65e7\u7248")!=NULL && wcsstr(h,L"build")==NULL, "没有版本标记(更早的 agent):旧版,不写版本号"); }

    printf("\n== 七、状态栏的中文提示按本意显示(1160) ==\n");
    { /* 控件按控制器的方式建(Unicode 的 STATIC),交给生产代码的 set_status 一条真实的状态文字。
         期望值用独立写出的宽字符常量,不经任何转换函数生成。 */
      HWND st=CreateWindowW(L"STATIC",L"",WS_OVERLAPPED,0,0,10,10,NULL,NULL,GetModuleHandleW(NULL),NULL);
      g_status=st;
      set_status("Connected 1/1 host(s)  [无法写出本版 agent 文件]");
      wchar_t back[256]={0}; GetWindowTextW(st,back,256);
      const wchar_t want[]=L"Connected 1/1 host(s)  [\u65e0\u6cd5\u5199\u51fa\u672c\u7248 agent \u6587\u4ef6]";
      char w[160]; snprintf(w,sizeof w,"中文提示按本意显示(当前代码页 %u;原先 SetWindowTextA 按代码页解释 UTF-8 字节 -> 乱码)",GetACP());
      ck(wcscmp(back,want)==0, w);
      g_status=NULL; DestroyWindow(st); }

    printf("\n== 八、离开 exe 目录(1162):旧文件按「名字+内容」处理,用户的文件一个不碰 ==\n");
    { /* 生产代码 migrate_dir() 在真实文件上跑一遍。old 扮演 1161 的数据目录(exe 旁),nw 扮演新数据目录。
         99999、99997 不是 4 的倍数,Windows 上不可能是进程号 = 已退出的进程;本进程号扮演仍常驻旧版 agent 的机架。 */
      char tmp[MAX_PATH]; GetTempPathA(sizeof tmp,tmp);
      char old[MAX_PATH], nw[MAX_PATH]; snprintf(old,sizeof old,"%sw_extract_old",tmp); snprintf(nw,sizeof nw,"%sw_extract_new",tmp);
      CreateDirectoryA(old,NULL); CreateDirectoryA(nw,NULL);
      auto P=[&](const char* d,const char* n)->const char*{ static char b[4][MAX_PATH]; static int i=0; i=(i+1)&3; snprintf(b[i],MAX_PATH,"%s\\%s",d,n); return b[i]; };
      auto put=[&](const char* d,const char* n,const char* body){ FILE* f=fopen(P(d,n),"wb"); if(f){ fputs(body,f); fclose(f); } };
      auto has=[&](const char* d,const char* n){ return GetFileAttributesA(P(d,n))!=INVALID_FILE_ATTRIBUTES; };
      auto body=[&](const char* d,const char* n)->std::string{ std::string r; FILE* f=fopen(P(d,n),"rb"); if(f){ char b[4096]; size_t k; while((k=fread(b,1,sizeof b,f))>0) r.append(b,k); fclose(f);} return r; };
      const char* decoys[][2]={{"status_report.txt","my report\n"},{"status_2024.txt","keep me\n"},{"scales_notes.txt","notes\n"},
                               {"status.txt","todo\n"},{"pending_tasks.txt","buy milk\n"},{"photo.jpg","\xff\xd8\xff"}};
      for(auto& d: decoys) put(old,d[0],d[1]);
      put(old,"status_99999.txt","#b1161\nCubase | Auto-Tune Pro  C  Major\n"); put(old,"scales_99999.txt","[Auto-Tune Pro.vst3]\nMajor\n");
      put(old,"status_99999.txt.tmp",""); put(old,"pending_99999.txt",""); put(old,"pending_99997.txt","C:\\VST3\\Crashy.vst3\n");
      put(old,"cmd.ini","key=7|scale=Major|t=1\n"); put(old,"eject.flag","1\n"); put(old,"eject_on_close.flag","1\n");
      put(old,"dawhost.txt","# DAW exe-name fragments (seed)\nsam\nmydaw\n"); put(old,"agent.log","[99999] +0.100 agent loaded\n");
      put(old,"scalemap.txt","# scalemap.txt - scale synonym groups\r\n# comments only\r\n"); put(old,"noeat.txt",""); put(old,"skip.txt","waveshell\r\nfoo\r\n");
      char live[64]; snprintf(live,sizeof live,"status_%lu.txt",GetCurrentProcessId()); put(old,live,"#b1161\nLive | Auto-Tune  C  Major\n");
      g_migUserCopied=0; g_migUserNames[0]=0; g_nLegacy=0;
      migrate_dir(old,nw,1,1);
      int dk=1; for(auto& d: decoys) if(!has(old,d[0]) || body(old,d[0])!=d[1]) dk=0;
      ck(dk, "用户的 6 个文件(1161 会删掉其中 5 个)原样留在原处,内容不变");
      ck(!has(old,"status_99999.txt") && !has(old,"scales_99999.txt") && !has(old,"status_99999.txt.tmp") && !has(old,"pending_99999.txt")
         && !has(old,"cmd.ini") && !has(old,"eject.flag"), "已退出进程的协议文件、命令文件、卸载信号:删除");
      ck(!has(old,"pending_99997.txt") && body(nw,"pending_99997.txt")=="C:\\VST3\\Crashy.vst3\n", "记着模块的崩溃标记搬进新目录(下一个 agent 照旧采纳)");
      ck(has(old,live) && g_nLegacy==1, "仍在运行的旧 agent 的状态文件不动,并记下该目录供提示「请重启该机架」");
      ck(!has(old,"dawhost.txt") && body(nw,"dawhost.txt").find("mydaw")!=std::string::npos, "dawhost.txt 搬进新目录(学到的机架名不丢)");
      ck(!has(old,"agent.log") && has(nw,"agent.log") && !has(old,"eject_on_close.flag") && has(nw,"eject_on_close.flag"), "agent.log、eject_on_close.flag 搬进新目录");
      ck(!has(old,"scalemap.txt") && !has(nw,"scalemap.txt"), "纯注释的 scalemap 模板:删除,不带进新目录");
      ck(has(old,"noeat.txt") && has(nw,"noeat.txt") && has(old,"skip.txt") && body(nw,"skip.txt")=="waveshell\r\nfoo\r\n",
         "用户自己的开关文件:复制进新目录,原件不动");
      ck(g_migUserCopied==2 && strstr(g_migUserNames,"noeat.txt") && strstr(g_migUserNames,"skip.txt"), "一次性提示里列出了这两个文件");
      DeleteFileA(P(nw,"noeat.txt"));                     /* 用户随后在界面里关掉了这个安全阀 */
      put(old,"dawhost.txt","# DAW exe-name fragments (seed)\nsam\nnewdaw\n");   /* 旧版控制器又被打开过一次 */
      put(old,"agent.log","[99999] +0.200 second session\n");
      g_migUserCopied=0; migrate_dir(old,nw,0,1);
      ck(!has(nw,"noeat.txt") && g_migUserCopied==0, "非首次启动:不再从旧目录重新导入(不会把用户关掉的开关又打开)");
      std::string dh=body(nw,"dawhost.txt");
      ck(!has(old,"dawhost.txt") && dh.find("newdaw")!=std::string::npos && dh.find("mydaw")!=std::string::npos
         && dh.find("sam")==dh.rfind("sam"), "新目录已有 dawhost.txt:按行合并,不重复");
      std::string lg=body(nw,"agent.log");
      ck(!has(old,"agent.log") && lg.find("agent loaded")!=std::string::npos && lg.find("second session")!=std::string::npos
         && lg.find("moved here from")!=std::string::npos, "新目录已有 agent.log:接在后面并注明来源");
      put(old,"agent.log","[99999] +0.300 held open\n");
      HANDLE held=CreateFileA(P(old,"agent.log"),FILE_APPEND_DATA,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);   /* 常驻旧 agent 的 fopen("a") */
      size_t before=body(nw,"agent.log").size(); migrate_dir(old,nw,0,1);
      ck(has(old,"agent.log") && body(nw,"agent.log").size()==before, "被旧 agent 占着的日志:原样不动,也不复制(否则下次又复制一遍)");
      CloseHandle(held);
      WIN32_FIND_DATAA fd; HANDLE hf;
      for(const char* d: {(const char*)old,(const char*)nw}){ char pat[MAX_PATH]; snprintf(pat,sizeof pat,"%s\\*",d); hf=FindFirstFileA(pat,&fd);
          if(hf!=INVALID_HANDLE_VALUE){ do{ if(!(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)) DeleteFileA(P(d,fd.cFileName)); }while(FindNextFileA(hf,&fd)); FindClose(hf); }
          RemoveDirectoryA(d); } }

    printf("\n== 九、高级设置写回(1162):只写改过的、原子写、只读文件、过大的列表不动、Waves 行不重复 ==\n");
    { char tmp[MAX_PATH]; GetTempPathA(sizeof tmp,tmp); char cd[MAX_PATH]; snprintf(cd,sizeof cd,"%sw_extract_cfg",tmp); CreateDirectoryA(cd,NULL);
      char savedDir[MAX_PATH]; snprintf(savedDir,sizeof savedDir,"%s",COMMDIR); snprintf(COMMDIR,sizeof COMMDIR,"%s",cd);
      auto P=[&](const char* n)->std::string{ return std::string(cd)+"\\"+n; };
      auto put=[&](const char* n,const std::string& b){ FILE* f=fopen(P(n).c_str(),"wb"); if(f){ fwrite(b.data(),1,b.size(),f); fclose(f);} };
      auto has=[&](const char* n){ return GetFileAttributesA(P(n).c_str())!=INVALID_FILE_ATTRIBUTES; };
      auto body=[&](const char* n)->std::string{ std::string r; FILE* f=fopen(P(n).c_str(),"rb"); if(f){ char b[4096]; size_t k; while((k=fread(b,1,sizeof b,f))>0) r.append(b,k); fclose(f);} return r; };
      auto mtime=[&](const char* n)->unsigned long long{ WIN32_FILE_ATTRIBUTE_DATA a; if(!GetFileAttributesExA(P(n).c_str(),GetFileExInfoStandard,&a)) return 0;
                                                          return ((unsigned long long)a.ftLastWriteTime.dwHighDateTime<<32)|a.ftLastWriteTime.dwLowDateTime; };
      static CfgState was, now; CfgResult r;
      put("skip.txt","\xEF\xBB\xBFwaveshell\r\nfoo\r\n"); put("catch.txt","mydaw\r\n");
      cfg_load(&was);
      ck(was.waves==1 && !strcmp(was.list[0],"foo") && was.ok[0] && !strcmp(was.list[1],"mydaw"), "载入:去掉 BOM;waveshell 那一行由勾选框表示,框里只剩其余各行");
      unsigned long long t0=mtime("skip.txt"), t1=mtime("catch.txt"); Sleep(30);
      now=was; r=cfg_apply(&was,&now);
      ck(!r.changed && !r.fail && mtime("skip.txt")==t0 && mtime("catch.txt")==t1 && body("skip.txt").compare(0,3,"\xEF\xBB\xBF")==0,
         "什么都没改就按确定:一个文件都不重写(原文件连 BOM 都还在)");
      now=was; snprintf(now.list[0],CFG_CAP,"foo\r\n  WaveShell  \r\n"); r=cfg_apply(&was,&now);
      ck(r.changed && !r.fail && body("skip.txt")=="foo\r\nwaveshell\r\n" && r.nSkip==2, "勾着 Waves、框里又手写了 waveshell:文件里只有一行");
      ck(!has("skip.txt.tmp"), "原子写:临时文件已改名,不留 .tmp");
      put("noeat.txt",""); SetFileAttributesA(P("noeat.txt").c_str(),FILE_ATTRIBUTE_READONLY);
      cfg_load(&was); now=was; now.noeat=0; r=cfg_apply(&was,&now);
      ck(was.noeat==1 && !r.fail && !has("noeat.txt"), "只读的开关文件也能在界面里关掉");
      SetFileAttributesA(P("catch.txt").c_str(),FILE_ATTRIBUTE_READONLY);
      cfg_load(&was); now=was; snprintf(now.list[1],CFG_CAP,"mydaw\r\nother"); r=cfg_apply(&was,&now);
      ck(!r.fail && body("catch.txt")=="mydaw\r\nother\r\n", "只读的列表文件也能改写");
      { std::string big; for(int i=0;i<2500;i++) big+="Foo"+std::to_string(i)+"|Bar"+std::to_string(i)+"\r\n"; put("scalemap.txt",big); }
      size_t bsz=body("scalemap.txt").size(); cfg_load(&was);
      ck(!was.ok[2] && bsz>CFG_CAP, "比缓冲大的列表:标记为不完整(窗口里设为只读)");
      now=was; snprintf(now.list[2],CFG_CAP,"X|Y"); r=cfg_apply(&was,&now);
      ck(r.keptBig && body("scalemap.txt").size()==bsz, "不完整的列表即使框里被改了也不写回(不会被截断)");
      put("scalemap.txt","A|B\r\n"); cfg_load(&was); now=was;
      snprintf(now.list[2],CFG_CAP,"A|B\r\nlonely\r\n# note\r\nC|D|E"); snprintf(now.list[1],CFG_CAP,"mydaw\r\n\xB5\xE7\xD2\xF4");   /* GBK「电音」 */
      r=cfg_apply(&was,&now);
      ck(r.nGrp==2 && r.nNoBar==1 && r.nNonAscii==1 && r.nCatch==2, "计数:2 组、1 行缺 |、1 个非英文片段(用于提示)");
      cfg_load(&was); now=was; now.list[1][0]=0; r=cfg_apply(&was,&now);
      ck(!r.fail && !has("catch.txt"), "清空列表:删除对应文件");
      cfg_load(&was); now=was; snprintf(now.list[2],CFG_CAP,"Foo|Bar"); r=cfg_apply(&was,&now);
      int onlySmap=(r.smapChanged && !r.needRestart);
      cfg_load(&was); now=was; now.noui=!was.noui; r=cfg_apply(&was,&now); cfg_load(&was); now=was; now.noui=!was.noui; cfg_apply(&was,&now);
      ck(onlySmap && r.needRestart && !r.smapChanged, "只改音阶同义词:不需要重启机架(即时生效);改了开关:需要");
      { int sn=g_ninst; g_ninst=3;
        snprintf(g_insts[0].label,160,"Studio One.exe | Auto-Tune Pro"); snprintf(g_insts[1].label,160,"Sam_x64.exe | Waves Tune Real-Time Mono");
        snprintf(g_insts[2].label,160,"Studio One.exe | The T-Pain Effect");
        wchar_t rk[400]; running_racks(rk,400); g_ninst=sn;
        ck(wcscmp(rk,L"Studio One.exe、Sam_x64.exe")==0, "提示里点名要重启的机架(同一个机架只列一次)"); }
      cfg_load(&was); now=was; snprintf(now.list[2],CFG_CAP,"A|B|C|D|E|F|G|H|I"); snprintf(now.list[0],CFG_CAP,"%s",std::string(AG_SKIP_LINE+5,'x').c_str()); r=cfg_apply(&was,&now);
      ck(r.nTooMany==1 && r.nLong==1, "按 agent 的上限提示:一组超过 8 个名字、一行超过 agent 能读的长度");
      snprintf(COMMDIR,sizeof COMMDIR,"%s",savedDir);
      WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA((std::string(cd)+"\\*").c_str(),&fd);
      if(hf!=INVALID_HANDLE_VALUE){ do{ if(!(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)){ SetFileAttributesA(P(fd.cFileName).c_str(),FILE_ATTRIBUTE_NORMAL); DeleteFileA(P(fd.cFileName).c_str()); } }while(FindNextFileA(hf,&fd)); FindClose(hf); }
      RemoveDirectoryA(cd); }

    printf("\n== 十、旧位置:旧指针指向的文件夹也迁移;同一文件夹的两种写法只算一个;仍运行旧 agent 的机架会被提示 ==\n");
    { char tmp[MAX_PATH]; GetTempPathA(sizeof tmp,tmp);
      std::string A=std::string(tmp)+"w_extract_A", N=std::string(tmp)+"w_extract_N", X=std::string(tmp)+"w_extract_X";
      for(std::string* d: {&A,&N,&X}) CreateDirectoryA(d->c_str(),NULL);
      auto put=[&](const std::string& d,const char* n,const char* b){ FILE* f=fopen((d+"\\"+n).c_str(),"wb"); if(f){ fputs(b,f); fclose(f);} };
      auto has=[&](const std::string& d,const char* n){ return GetFileAttributesA((d+"\\"+n).c_str())!=INVALID_FILE_ATTRIBUTES; };
      auto body=[&](const std::string& d,const char* n)->std::string{ std::string r; FILE* f=fopen((d+"\\"+n).c_str(),"rb"); if(f){ char b[4096]; size_t k; while((k=fread(b,1,sizeof b,f))>0) r.append(b,k); fclose(f);} return r; };
      std::string Aalias=A+"\\..\\w_extract_A";
      ck(same_dir(A.c_str(),Aalias.c_str()) && !same_dir(A.c_str(),N.c_str()) && !same_dir(A.c_str(),(A+"_missing").c_str()),
         "same_dir:同一文件夹换种写法(..)仍是同一个;不同的、不存在的文件夹不混");
      char sE[MAX_PATH], sP[MAX_PATH], sT[MAX_PATH], sC[MAX_PATH]; strcpy(sE,EXEDIR); strcpy(sP,g_prevCommDir); strcpy(sT,g_oldTemp); strcpy(sC,COMMDIR); int sNew=g_dataDirNew;
      snprintf(EXEDIR,MAX_PATH,"%s",X.c_str()); snprintf(g_prevCommDir,MAX_PATH,"%s",A.c_str()); g_oldTemp[0]=0; snprintf(COMMDIR,MAX_PATH,"%s",N.c_str());
      g_dataDirNew=1; g_nLegacy=0; g_migUserCopied=0; g_migUserNames[0]=0;
      put(A,"noeat.txt",""); put(A,"dawhost.txt","# DAW exe-name fragments\nsam\nfromA\n"); put(A,"status_99999.txt","#b1161\nX | Y\n"); put(X,"cmd.ini","key=1|scale=Major|t=5\n");
      migrate_legacy();
      ck(has(N,"noeat.txt") && has(A,"noeat.txt") && g_migUserCopied==1 && strstr(g_migUserNames,"w_extract_A\\noeat.txt"),
         "1162 解压到新文件夹、旧版在另一个文件夹(只有旧指针指向那里):开关文件照样导入,提示里写出完整路径");
      ck(!has(A,"status_99999.txt") && body(N,"dawhost.txt").find("fromA")!=std::string::npos && !has(X,"cmd.ini"), "旧指针指向的文件夹和本 exe 的文件夹都清理了");
      std::string before=body(N,"dawhost.txt");
      snprintf(EXEDIR,MAX_PATH,"%s\\..\\w_extract_N",N.c_str()); g_prevCommDir[0]=0; migrate_legacy();
      ck(!before.empty() && body(N,"dawhost.txt")==before && has(N,"noeat.txt"),
         "exe 就在数据文件夹里、只是写法不同:不会把数据文件夹当成旧位置(dawhost.txt 不会并进自己再被删掉)");
      char live[64]; snprintf(live,sizeof live,"status_%lu.txt",GetCurrentProcessId()); put(A,live,"#b1161\nLive | Auto-Tune  C  Major\n");
      g_nLegacy=0; migrate_dir(A.c_str(),N.c_str(),0,1);
      ck(g_nLegacy==1 && legacy_agent_build()==-1, "旧 agent 所在进程还没被本控制器接管时:不提示");
      mark_injected(GetCurrentProcessId());
      ck(legacy_agent_build()==1161, "接管后(注入器报告已有 agent):提示该机架在运行 build 1161、需要重启");
      strcpy(EXEDIR,sE); strcpy(g_prevCommDir,sP); strcpy(g_oldTemp,sT); strcpy(COMMDIR,sC); g_dataDirNew=sNew; g_nLegacy=0;
      for(std::string* d: {&A,&N,&X}){ WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA((*d+"\\*").c_str(),&fd);
          if(hf!=INVALID_HANDLE_VALUE){ do{ if(!(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)) DeleteFileA((*d+"\\"+fd.cFileName).c_str()); }while(FindNextFileA(hf,&fd)); FindClose(hf); }
          RemoveDirectoryA(d->c_str()); } }

    printf("\n== 十一、没清完的旧位置要记住;「关闭时卸载」也要通知旧 agent;两条提示同时成立时都显示(1162) ==\n");
    { char tmp[MAX_PATH]; GetTempPathA(sizeof tmp,tmp);
      std::string A=std::string(tmp)+"w_extract_A2", B=std::string(tmp)+"w_extract_B2", N=std::string(tmp)+"w_extract_N2", X=std::string(tmp)+"w_extract_X2";
      for(std::string* d: {&A,&B,&N,&X}) CreateDirectoryA(d->c_str(),NULL);
      auto put=[&](const std::string& d,const char* n,const char* b){ FILE* f=fopen((d+"\\"+n).c_str(),"wb"); if(f){ fputs(b,f); fclose(f);} };
      auto has=[&](const std::string& d,const char* n){ return GetFileAttributesA((d+"\\"+n).c_str())!=INVALID_FILE_ATTRIBUTES; };
      auto body=[&](const std::string& d,const char* n)->std::string{ std::string r; FILE* f=fopen((d+"\\"+n).c_str(),"rb"); if(f){ char b[4096]; size_t k; while((k=fread(b,1,sizeof b,f))>0) r.append(b,k); fclose(f);} return r; };
      char sE[MAX_PATH], sP[MAX_PATH], sT[MAX_PATH], sC[MAX_PATH]; strcpy(sE,EXEDIR); strcpy(sP,g_prevCommDir); strcpy(sT,g_oldTemp); strcpy(sC,COMMDIR); int sNew=g_dataDirNew;
      snprintf(EXEDIR,MAX_PATH,"%s",X.c_str()); snprintf(g_prevCommDir,MAX_PATH,"%s",A.c_str()); g_oldTemp[0]=0; snprintf(COMMDIR,MAX_PATH,"%s",N.c_str());
      g_dataDirNew=0; g_nLegacy=0;
      char live[64]; snprintf(live,sizeof live,"status_%lu.txt",GetCurrentProcessId()); put(A,live,"#b1161\nLive | Y\n");
      migrate_legacy();
      ck(has(A,live) && body(N,"legacy_dirs.txt").find(A)!=std::string::npos, "首次启动:旧 agent 还活着、文件只能留在旧位置 -> 把这个位置记下来");
      put(B,"status_99999.txt","#b1161\nDead | Y\n"); snprintf(g_legacyDir[g_nLegacy++],MAX_PATH,"%s",B.c_str());
      eject_legacy_agents();
      ck(body(A,"eject.flag")=="1\n", "勾了「关闭时卸载」:旧 agent 还活着的旧位置也写 eject.flag,让它卸载");
      ck(!has(B,"eject.flag"), "旧 agent 已不在的旧位置:不往用户的文件夹里写东西");
      g_prevCommDir[0]=0; g_nLegacy=0; migrate_legacy();      /* 第二次启动:指针已指向新位置 */
      ck(g_nLegacy==1 && has(A,live), "第二次启动:旧指针已没有,靠记录仍找到旧位置 -> 「请重启该机架」的提示不会消失");
      DeleteFileA((A+"\\"+live).c_str()); put(A,"status_99999.txt","#b1161\nX | Y\n");   /* 机架重启过:旧 agent 死了,留下文件 */
      g_nLegacy=0; migrate_legacy();
      ck(!has(A,"status_99999.txt") && !has(A,"eject.flag") && !has(N,"legacy_dirs.txt"), "之后某次启动:清掉旧 agent 的残留(含 eject.flag),记录随之删除");
      wchar_t bn[600];
      ck(status_banner(bn,600,1161,1,AT_BUILD_EXPECT+1) && wcsstr(bn,L"build 1161") && wcsstr(bn,L"\u4e0d\u8981\u91cd\u542f"),
         "旧位置的机架、更新版 agent 的机架同时存在:两条提示都显示(一条说重启,一条说不要重启)");
      ck(!status_banner(bn,600,-1,0,0) && bn[0]==0, "都没有:不显示提示");
      { /* 进程号被重用:文件比当前持有这个进程号的进程还早 -> 写它的那个进程已经不在了 */
        std::string f=A+"\\"+live; put(A,live,"#b1161\nReused | Y\n"); put(A,"pending_reuse.txt","");
        HANDLE fh=CreateFileA(f.c_str(),FILE_WRITE_ATTRIBUTES,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);
        FILETIME now; GetSystemTimeAsFileTime(&now); ULARGE_INTEGER t; t.LowPart=now.dwLowDateTime; t.HighPart=now.dwHighDateTime;
        t.QuadPart-=(ULONGLONG)86400*10000000ULL; FILETIME old; old.dwLowDateTime=t.LowPart; old.dwHighDateTime=t.HighPart;
        SetFileTime(fh,NULL,NULL,&old); CloseHandle(fh);
        ck(!file_owner_alive(f.c_str(),GetCurrentProcessId()) && file_owner_alive((A+"\\pending_reuse.txt").c_str(),GetCurrentProcessId()),
           "进程号被重用(文件比持有这个号的进程还早):判为已退出;刚写的文件仍判为存活");
        g_nLegacy=0; snprintf(g_prevCommDir,MAX_PATH,"%s",A.c_str()); migrate_legacy(); g_prevCommDir[0]=0;
        ck(!has(A,live) && g_nLegacy==0 && !legacy_dir_live(A.c_str()), "重用的进程号骗不过迁移:残留照样清掉、不当成旧 agent、关闭时不往那里写 eject.flag");
        DeleteFileA((A+"\\pending_reuse.txt").c_str()); }
      put(X,live,"#b1161\nLive | Y\n"); g_prevCommDir[0]=0; g_nLegacy=0; migrate_legacy();
      ck(body(N,"legacy_dirs.txt").find(X)!=std::string::npos, "exe 所在文件夹里有没清完的也记下(exe 之后被挪走时还能找回)");
      DeleteFileA((X+"\\"+live).c_str()); g_nLegacy=0; migrate_legacy();
      strcpy(EXEDIR,sE); strcpy(g_prevCommDir,sP); strcpy(g_oldTemp,sT); strcpy(COMMDIR,sC); g_dataDirNew=sNew; g_nLegacy=0;
      for(std::string* d: {&A,&B,&N,&X}){ WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA((*d+"\\*").c_str(),&fd);
          if(hf!=INVALID_HANDLE_VALUE){ do{ if(!(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)) DeleteFileA((*d+"\\"+fd.cFileName).c_str()); }while(FindNextFileA(hf,&fd)); FindClose(hf); }
          RemoveDirectoryA(d->c_str()); } }

    printf("\n== 十二、数据目录的选择、旧指针先读后写、日志轮转、dawhost 的 BOM(1162) ==\n");
    { char tmp[MAX_PATH]; GetTempPathA(sizeof tmp,tmp);
      std::string R=std::string(tmp)+"w_extract_env", T=R+"\\temp", L=R+"\\local", F=R+"\\notadir";
      for(const std::string& d: {R,T,L}) CreateDirectoryA(d.c_str(),NULL);
      auto has=[&](const std::string& p){ return GetFileAttributesA(p.c_str())!=INVALID_FILE_ATTRIBUTES; };
      auto body=[&](const std::string& p)->std::string{ std::string r; FILE* f=fopen(p.c_str(),"rb"); if(f){ char b[4096]; size_t k; while((k=fread(b,1,sizeof b,f))>0) r.append(b,k); fclose(f);} return r; };
      auto put=[&](const std::string& p,const std::string& b){ FILE* f=fopen(p.c_str(),"wb"); if(f){ fwrite(b.data(),1,b.size(),f); fclose(f);} };
      static char sv[10][MAX_PATH]; char* g[10]={COMMDIR,EXEDIR,g_prevCommDir,g_oldTemp,CMDFILE,EJECTFLAG,SCALESFILE,PREFFILE,STATUSFILE,NULL}; int sN=g_dataDirNew;
      for(int i=0;g[i];i++) strcpy(sv[i],g[i]);
      char oT[MAX_PATH]="", oE[MAX_PATH]="", oL[MAX_PATH]=""; DWORD hT=GetEnvironmentVariableA("TMP",oT,MAX_PATH), hE=GetEnvironmentVariableA("TEMP",oE,MAX_PATH), hL=GetEnvironmentVariableA("LOCALAPPDATA",oL,MAX_PATH);
      SetEnvironmentVariableA("TMP",T.c_str()); SetEnvironmentVariableA("TEMP",T.c_str()); SetEnvironmentVariableA("LOCALAPPDATA",L.c_str());
      put(T+"\\at8_commdir.txt","D:\\old1161\n");
      resolve_commdir();
      std::string want=L+"\\AutoTune_KeyScale";
      ck(!at_stricmp(COMMDIR,want.c_str()) && g_dataDirNew==1, "数据目录选 %LOCALAPPDATA%\\AutoTune_KeyScale,并认出是首次启动");
      ck(!strcmp(g_prevCommDir,"D:\\old1161"), "旧指针先读后写:读到的是上一个控制器记下的位置");
      ck(body(T+"\\at8_commdir.txt").find(want)==0 && !at_stricmp(g_oldTemp,(T+"\\at8").c_str()), "随后指针改指新数据目录;%TEMP%\\at8 记作旧版的回退位置");
      resolve_commdir();
      ck(g_dataDirNew==0 && !at_stricmp(g_prevCommDir,want.c_str()), "第二次启动:不算首次;旧指针就是数据目录本身(迁移时会跳过)");
      put(F,"x"); SetEnvironmentVariableA("LOCALAPPDATA",F.c_str()); resolve_commdir();
      ck(!at_stricmp(COMMDIR,(T+"\\at8").c_str()) && !has(F+"\\AutoTune_KeyScale"), "%LOCALAPPDATA% 不能用时退回 %TEMP%\\at8");
      SetEnvironmentVariableA("LOCALAPPDATA",(std::string("C:\\")+std::string(250,'a')).c_str()); resolve_commdir();
      ck(!at_stricmp(COMMDIR,(T+"\\at8").c_str()), "%LOCALAPPDATA% 太长:不截断出一个名字不对的文件夹,直接退回");
      SetEnvironmentVariableA("LOCALAPPDATA",L.c_str()); resolve_commdir();
      std::string lg=want+"\\agent.log", lg1=want+"\\agent.log.1";
      put(lg,std::string(2*1024*1024+10,'x')); rotate_log();
      ck(!has(lg) && body(lg1).size()==2*1024*1024+10, "agent.log 超过 2 MB:改名为 agent.log.1");
      put(lg,"small\n"); rotate_log();
      ck(body(lg)=="small\n" && body(lg1).size()==2*1024*1024+10, "不到 2 MB:不动");
      put(lg,std::string(2*1024*1024+20,'y'));
      HANDLE held=CreateFileA(lg.c_str(),FILE_APPEND_DATA,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL); rotate_log();
      ck(body(lg).size()==2*1024*1024+20 && body(lg1).size()==2*1024*1024+10, "有机架正写着(像 fopen \"a\" 那样占着):推迟,不丢内容");
      CloseHandle(held);
      put(want+"\\dawhost.txt","\xEF\xBB\xBF# DAW exe-name fragments\r\nmydaw\r\n"); g_dawLoaded=0; load_dawhosts();
      ck(g_ndaw==1 && !strcmp(g_daw[0],"mydaw"), "dawhost.txt 开头有 BOM:注释行仍是注释,不会变成一个乱码机架名");
      g_dawLoaded=0;
      { WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA((want+"\\*").c_str(),&fd);   /* 用户在「打开数据文件夹」里把整个文件夹删了 */
        if(hf!=INVALID_HANDLE_VALUE){ do{ if(!(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)) DeleteFileA((want+"\\"+fd.cFileName).c_str()); }while(FindNextFileA(hf,&fd)); FindClose(hf); }
        RemoveDirectoryA(want.c_str()); }
      int gone=!has(want); write_cmd(1);
      ck(gone && has(CMDFILE) && !g_cmdWriteFail, "数据文件夹在运行中被删掉:下一条命令时自动重建,不报「命令写入失败」");
      if(hT) SetEnvironmentVariableA("TMP",oT); else SetEnvironmentVariableA("TMP",NULL);
      if(hE) SetEnvironmentVariableA("TEMP",oE); else SetEnvironmentVariableA("TEMP",NULL);
      if(hL) SetEnvironmentVariableA("LOCALAPPDATA",oL); else SetEnvironmentVariableA("LOCALAPPDATA",NULL);
      for(int i=0;g[i];i++) strcpy(g[i],sv[i]); g_dataDirNew=sN;
      for(const std::string& d: {want,T+"\\at8",T,L,R}){ WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA((d+"\\*").c_str(),&fd);
          if(hf!=INVALID_HANDLE_VALUE){ do{ if(!(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)) DeleteFileA((d+"\\"+fd.cFileName).c_str()); }while(FindNextFileA(hf,&fd)); FindClose(hf); }
          RemoveDirectoryA(d.c_str()); } }

    printf("\n== 十三、高级设置窗口本身(1162):打开时的控件状态、改了按确定才写、提示框、取消不写、过大的列表只读且 Waves 置灰 ==\n");
    { char tmp[MAX_PATH]; GetTempPathA(sizeof tmp,tmp); std::string cd=std::string(tmp)+"w_extract_ui"; CreateDirectoryA(cd.c_str(),NULL);
      char savedDir[MAX_PATH]; strcpy(savedDir,COMMDIR); snprintf(COMMDIR,sizeof COMMDIR,"%s",cd.c_str());
      auto P=[&](const char* n){ return cd+"\\"+n; };
      auto put=[&](const char* n,const std::string& b){ FILE* f=fopen(P(n).c_str(),"wb"); if(f){ fwrite(b.data(),1,b.size(),f); fclose(f);} };
      auto has=[&](const char* n){ return GetFileAttributesA(P(n).c_str())!=INVALID_FILE_ATTRIBUTES; };
      auto body=[&](const char* n)->std::string{ std::string r; FILE* f=fopen(P(n).c_str(),"rb"); if(f){ char b[4096]; size_t k; while((k=fread(b,1,sizeof b,f))>0) r.append(b,k); fclose(f);} return r; };
      put("skip.txt","waveshell\r\nfoo\r\n"); put("catch.txt","mydaw\r\n"); put("noeat.txt","");
      { std::string big; for(int i=0;i<2500;i++) big+="Foo"+std::to_string(i)+"|Bar"+std::to_string(i)+"\r\n"; put("scalemap.txt",big); }
      size_t bigsz=body("scalemap.txt").size();
      HWND owner=CreateWindowW(L"STATIC",L"owner",WS_OVERLAPPED,0,0,200,100,NULL,NULL,GetModuleHandleW(NULL),NULL);
      static UiCheck u; memset(&u,0,sizeof u); u.mode=1;
      HANDLE th=CreateThread(NULL,0,ui_driver,&u,0,NULL); settings_dialog(owner); WaitForSingleObject(th,10000); CloseHandle(th);
      ck(u.found && u.waves && u.noeat && !u.noui, "打开时:勾选框反映文件(有 waveshell 行 -> 不处理 Waves;有 noeat.txt -> 安全阀勾着)");
      ck(!strcmp(u.skip,"foo") && !strcmp(u.katch,"mydaw"), "打开时:框里是文件内容,waveshell 那行由勾选框表示、不重复出现");
      ck(u.smapRO && !u.skipRO && u.wavesEnabled, "过大的 scalemap 只读;skip 完整,可编辑,Waves 勾选框可用");
      ck(u.mbSeen && u.mbSaved, "按确定:弹出「已保存……重启机架」");
      ck(body("catch.txt")=="mydaw\r\nother\r\n" && !has("noeat.txt") && body("skip.txt")=="waveshell\r\nfoo\r\n" && body("scalemap.txt").size()==bigsz,
         "只写改过的:catch.txt 写入、noeat.txt 删除;没改的 skip.txt 原样、过大的 scalemap 不动");
      ck(IsWindowEnabled(owner), "窗口关闭后,主窗口重新可用");
      { std::string big; for(int i=0;i<3000;i++) big+="pattern_"+std::to_string(i)+"\r\n"; put("skip.txt",big); }
      size_t skipsz=body("skip.txt").size(); std::string catchBefore=body("catch.txt");
      memset(&u,0,sizeof u); u.mode=2; th=CreateThread(NULL,0,ui_driver,&u,0,NULL); settings_dialog(owner); WaitForSingleObject(th,10000); CloseHandle(th);
      ck(u.found && u.skipRO && !u.wavesEnabled, "skip.txt 过大:框只读,Waves 勾选框置灰(它是 skip.txt 的一行,改了也写不回)");
      ck(body("skip.txt").size()==skipsz && body("catch.txt")==catchBefore && !u.mbSeen, "按取消:什么都不写,也不弹提示");
      DestroyWindow(owner); snprintf(COMMDIR,sizeof COMMDIR,"%s",savedDir);
      WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA((cd+"\\*").c_str(),&fd);
      if(hf!=INVALID_HANDLE_VALUE){ do{ if(!(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)) DeleteFileA(P(fd.cFileName).c_str()); }while(FindNextFileA(hf,&fd)); FindClose(hf); }
      RemoveDirectoryA(cd.c_str()); }

    printf("\n== 十四、中文路径(1162;只在代码页 936 下运行,即中文 Windows 的情形) ==\n");
    if(GetACP()!=936) printf("   (当前代码页 %u,本节不适用;请用 LC_ALL=zh_CN.UTF-8 再跑一次)\n",GetACP());
    else { char tmp[MAX_PATH]; GetTempPathA(sizeof tmp,tmp);
      const char* ZS="\xD5\xC5\xC8\xFD";                    /* GBK「张三」:中文用户名 */
      const char* JIU="\xBE\xC9\xB0\xE6\xB9\xA4\xBE\xDF";   /* GBK「旧版工具」:旧版所在的中文文件夹 */
      std::string R=std::string(tmp)+"w_extract_zh", U=R+"\\"+ZS, L=U+"\\AppData\\Local", O=R+"\\"+JIU, want=L+"\\AutoTune_KeyScale";
      for(const std::string& d: {R,U,U+"\\AppData",L,O}) CreateDirectoryA(d.c_str(),NULL);
      auto put=[&](const std::string& p,const char* b){ FILE* f=fopen(p.c_str(),"wb"); if(f){ fputs(b,f); fclose(f);} };
      auto has=[&](const std::string& p){ return GetFileAttributesA(p.c_str())!=INVALID_FILE_ATTRIBUTES; };
      static char sv[10][MAX_PATH]; char* g[10]={COMMDIR,EXEDIR,g_prevCommDir,g_oldTemp,CMDFILE,EJECTFLAG,SCALESFILE,PREFFILE,STATUSFILE,NULL}; int sN=g_dataDirNew;
      for(int i=0;g[i];i++) strcpy(sv[i],g[i]);
      char oT[MAX_PATH]="", oE[MAX_PATH]="", oL[MAX_PATH]=""; DWORD hT=GetEnvironmentVariableA("TMP",oT,MAX_PATH), hE=GetEnvironmentVariableA("TEMP",oE,MAX_PATH), hL=GetEnvironmentVariableA("LOCALAPPDATA",oL,MAX_PATH);
      SetEnvironmentVariableA("TMP",R.c_str()); SetEnvironmentVariableA("TEMP",R.c_str()); SetEnvironmentVariableA("LOCALAPPDATA",L.c_str());
      resolve_commdir();
      ck(!strcmp(COMMDIR,want.c_str()) && has(want), "用户名是中文(张三):数据目录照样建在 %LOCALAPPDATA% 下,没有退回 %TEMP%");
      put(O+"\\noeat.txt",""); put(O+"\\status_99999.txt","#b1161\nX | Y\n"); put(O+"\\dawhost.txt","# DAW exe-name fragments\nsam\n");
      g_dataDirNew=1; g_migUserCopied=0; g_migUserNames[0]=0; g_nLegacy=0;
      migrate_dir(O.c_str(),COMMDIR,1,1);
      ck(has(want+"\\noeat.txt") && !has(O+"\\status_99999.txt") && has(want+"\\dawhost.txt") && strstr(g_migUserNames,JIU)!=NULL,
         "旧版在中文命名的文件夹里:照样识别、清理、导入,提示里的路径完整");
      ck(same_dir(O.c_str(),(O+"\\..\\"+JIU).c_str()) && !same_dir(O.c_str(),want.c_str()), "中文路径上的同一文件夹判断正确");
      if(hT) SetEnvironmentVariableA("TMP",oT); else SetEnvironmentVariableA("TMP",NULL);
      if(hE) SetEnvironmentVariableA("TEMP",oE); else SetEnvironmentVariableA("TEMP",NULL);
      if(hL) SetEnvironmentVariableA("LOCALAPPDATA",oL); else SetEnvironmentVariableA("LOCALAPPDATA",NULL);
      for(int i=0;g[i];i++) strcpy(g[i],sv[i]); g_dataDirNew=sN; g_migUserCopied=0; g_migUserNames[0]=0;
      for(const std::string& d: {want,L,U+"\\AppData",U,O,R+"\\at8",R}){ WIN32_FIND_DATAA fd; HANDLE hf=FindFirstFileA((d+"\\*").c_str(),&fd);
          if(hf!=INVALID_HANDLE_VALUE){ do{ if(!(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)) DeleteFileA((d+"\\"+fd.cFileName).c_str()); }while(FindNextFileA(hf,&fd)); FindClose(hf); }
          RemoveDirectoryA(d.c_str()); } }

    printf("\n== 十五、列表文件的原子写:机架正在读的时候,只会读到完整的旧内容或新内容(1162) ==\n");
    { char tmp[MAX_PATH]; GetTempPathA(sizeof tmp,tmp); std::string cd=std::string(tmp)+"w_extract_torn"; CreateDirectoryA(cd.c_str(),NULL);
      char savedDir[MAX_PATH]; strcpy(savedDir,COMMDIR); snprintf(COMMDIR,sizeof COMMDIR,"%s",cd.c_str());
      cfg_list_save("skip.txt","foo\r\nbar",NULL);
      static TornCheck tc; memset(&tc,0,sizeof tc); snprintf(tc.path,sizeof tc.path,"%s\\skip.txt",cd.c_str());
      HANDLE th=CreateThread(NULL,0,torn_reader,&tc,0,NULL); int ok=0, failed=0;
      for(int i=0;i<400;i++){ if(cfg_list_save("skip.txt",(i&1)?"foo\r\nbar":"waveshell\r\nalpha\r\nbeta",NULL)>0) ok++; else failed++; }
      InterlockedExchange(&tc.stop,1); WaitForSingleObject(th,5000); CloseHandle(th);
      char w[200]; snprintf(w,sizeof w,"一边改写 400 次、一边读了 %d 次:读到半截 %d 次(必须是 0)",tc.reads,tc.torn);
      ck(tc.reads>100 && tc.torn==0, w);
      printf("      (普通 fopen 有 %d 次在对方改名的那一刻打不开 —— 共享冲突,不是文件不在;agent 的读取会稍等重试,见 w_uiwin 第十九节)\n",tc.missing);
      snprintf(w,sizeof w,"写入成功 %d 次;%d 次因读的一方正占着文件而失败(界面会提示稍后再按确定),不会写坏",ok,failed);
      ck(ok>0, w);
      snprintf(COMMDIR,sizeof COMMDIR,"%s",savedDir);
      DeleteFileA(tc.path); DeleteFileA((std::string(tc.path)+".tmp").c_str()); RemoveDirectoryA(cd.c_str()); }

    printf("\n== 十六、与 agent 同时读写同一个文件时(1162):命令不丢;Target 选择不因一次打不开而重置;音阶列表不被清空 ==\n");
    { char tmp[MAX_PATH]; GetTempPathA(sizeof tmp,tmp); std::string cd=std::string(tmp)+"w_extract_ipc"; CreateDirectoryA(cd.c_str(),NULL);
      auto body=[&](const char* p)->std::string{ std::string r; FILE* f=fopen(p,"rb"); if(f){ char b[4096]; size_t k; while((k=fread(b,1,sizeof b,f))>0) r.append(b,k); fclose(f);} return r; };
      char sC[MAX_PATH], sCmd[MAX_PATH]; strcpy(sC,COMMDIR); strcpy(sCmd,CMDFILE);
      snprintf(COMMDIR,MAX_PATH,"%s",cd.c_str()); snprintf(CMDFILE,MAX_PATH,"%s\\cmd.ini",cd.c_str());
      { FILE* f=fopen(CMDFILE,"w"); fputs("old\n",f); fclose(f); }
      static HoldArgs ha; ha.path=CMDFILE; ha.ms=60; ha.share=FILE_SHARE_READ|FILE_SHARE_WRITE; ha.ready=0;
      HANDLE th=CreateThread(NULL,0,hold_file,&ha,0,NULL); while(!ha.ready) Sleep(1);
      write_cmd(1); WaitForSingleObject(th,3000); CloseHandle(th);
      ck(!g_cmdWriteFail && body(CMDFILE).find("|t=")!=std::string::npos, "agent 正读着 cmd.ini 时发出的命令:稍等后写入,没有丢、没有报「命令写入失败」");
      char sf[MAX_PATH]; snprintf(sf,sizeof sf,"%s\\status_%lu.txt",cd.c_str(),GetCurrentProcessId());
      { FILE* f=fopen(sf,"wb"); fputs("#b1162\nSam_x64.exe | The T-Pain Effect  Key=C  Scale=Major  Camelot=8B\x01" "12AB34CD KS\n",f); fclose(f); }
      mark_injected(GetCurrentProcessId()); g_instSig[0]=0; read_status(); int before=g_ninst;
      HANDLE lk=CreateFileA(sf,GENERIC_READ,0,NULL,OPEN_EXISTING,0,NULL);          /* 像 agent 改名盖过去的那一刻 */
      read_status(); int during=g_ninst; CloseHandle(lk);
      ck(before==1 && during==1, "状态文件那一刻打不开:保持上一轮的实例(原先这台机架会消失一轮 -> Target 重建 -> 选中的实例跳回「全部」)");
      char scf[MAX_PATH]; snprintf(scf,sizeof scf,"%s\\scales_%lu.txt",cd.c_str(),GetCurrentProcessId());
      { FILE* f=fopen(scf,"wb"); fputs("[The T-Pain Effect]\nMajor\nMinor\n",f); fclose(f); }
      maybe_update_scales(); int ns0=g_nsg;
      lk=CreateFileA(scf,GENERIC_READ,0,NULL,OPEN_EXISTING,0,NULL); maybe_update_scales(); int ns1=g_nsg; CloseHandle(lk);
      { FILE* f=fopen(scf,"wb"); fputs("[The T-Pain Effect]\nMajor\nMin",f); fclose(f); }   /* 写到一半 */
      maybe_update_scales(); int ns2=g_nsg;
      ck(ns0>=1 && ns1==ns0 && ns2==ns0, "音阶文件打不开或写到一半:保留上一轮的音阶列表(原先打不开就少一台,写到一半则清空到下一轮)");
      { std::string LG=cd+"\\legacy"; CreateDirectoryA(LG.c_str(),NULL);
        char lf[MAX_PATH]; snprintf(lf,sizeof lf,"%s\\status_%lu.txt",LG.c_str(),GetCurrentProcessId());
        { FILE* f=fopen(lf,"wb"); fputs("#b1161\nOld | Y\n",f); fclose(f); }
        int sN=g_nLegacy; char sL0[MAX_PATH]; strcpy(sL0,g_legacyDir[0]); g_nLegacy=1; snprintf(g_legacyDir[0],MAX_PATH,"%s",LG.c_str());
        int b1=legacy_agent_build(); lk=CreateFileA(lf,GENERIC_READ,0,NULL,OPEN_EXISTING,0,NULL); int b2=legacy_agent_build(); CloseHandle(lk);
        ck(b1==1161 && b2==1161, "旧版机架的状态文件那一刻打不开:「请重启该机架」照旧显示,不会闪一下就没了");
        std::string bf=LG+"\\status_99999.txt"; { FILE* f=fopen(bf.c_str(),"wb"); fputs("#b1161\nX | Y\n",f); fclose(f); }
        DeleteFileA(lf); g_nLegacy=0;
        lk=CreateFileA(bf.c_str(),GENERIC_READ,0,NULL,OPEN_EXISTING,0,NULL); int left1=migrate_dir(LG.c_str(),cd.c_str(),0,1); int reg=g_nLegacy; CloseHandle(lk);
        int left2=migrate_dir(LG.c_str(),cd.c_str(),0,1);
        ck(left1==1 && reg==1 && left2==0 && GetFileAttributesA(bf.c_str())==INVALID_FILE_ATTRIBUTES,
           "旧位置的文件那一刻正被占用:这次先留着、记下这个位置,下次照常清理(不会因为一次打不开就把它漏掉)");
        g_nLegacy=sN; strcpy(g_legacyDir[0],sL0); RemoveDirectoryA(LG.c_str()); }
      strcpy(COMMDIR,sC); strcpy(CMDFILE,sCmd);
      DeleteFileA(sf); DeleteFileA(scf); DeleteFileA((cd+"\\cmd.ini").c_str()); RemoveDirectoryA(cd.c_str()); }

    printf("\n== 十七、解出的 agent 与注入程序在使用期间被锁定(1162):以管理员身份运行时,别的程序无法在校验之后掉包 ==\n");
    { char tmp[MAX_PATH]; GetTempPathA(sizeof tmp,tmp); char d[MAX_PATH]; snprintf(d,sizeof d,"%sw_extract_pin",tmp); CreateDirectoryA(d,NULL);
      char path[MAX_PATH]; snprintf(path,sizeof path,"%s\\at_agent.dll",d); DeleteFileA(path);
      int n0=g_nPinned; g_agentStale=0;
      ensure_pinned("AGENT64",path,sizeof path);
      ck(g_nPinned==n0+1 && !g_agentStale && file_matches_res("AGENT64",path), "解出并锁定:内容就是内嵌的那一份");
      HANDLE w=CreateFileA(path,GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,0,NULL);
      int canWrite=(w!=INVALID_HANDLE_VALUE); if(canWrite) CloseHandle(w);
      char other[MAX_PATH]; snprintf(other,sizeof other,"%s\\evil.dll",d); { FILE* f=fopen(other,"wb"); fputs("evil",f); fclose(f); }
      int replaced=MoveFileExA(other,path,MOVEFILE_REPLACE_EXISTING), deleted=DeleteFileA(path);
      ck(!canWrite && !replaced && !deleted && file_matches_res("AGENT64",path), "锁定期间:写不进、换不掉、删不了,内容仍是校验过的那一份");
      HANDLE r=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,0,NULL);
      HMODULE m=LoadLibraryExA(path,NULL,DONT_RESOLVE_DLL_REFERENCES);
      ck(r!=INVALID_HANDLE_VALUE && m!=NULL, "机架照常能读取、载入它");
      if(r!=INVALID_HANDLE_VALUE) CloseHandle(r); if(m) FreeLibrary(m);
      unpin_all();
      /* 先有人以可写方式占着原文件名:校验后无法锁定 -> 换一个新文件名重新解出并锁定 */
      char p2[MAX_PATH]; snprintf(p2,sizeof p2,"%s\\at_agent32.dll",d); extract_res("AGENT32",p2);
      HANDLE hold=CreateFileA(p2,GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,0,NULL);
      char p2used[MAX_PATH]; snprintf(p2used,sizeof p2used,"%s",p2); g_agentStale=0;
      ensure_pinned("AGENT32",p2used,sizeof p2used);
      ck(hold!=INVALID_HANDLE_VALUE && strcmp(p2used,p2)!=0 && g_nPinned==1 && !g_agentStale && file_matches_res("AGENT32",p2used),
         "原文件被别的程序以可写方式占着:改用新文件名解出并锁定,注入的仍是校验过的那一份");
      unpin_all(); if(hold!=INVALID_HANDLE_VALUE) CloseHandle(hold);
      DeleteFileA(path); DeleteFileA(other); DeleteFileA(p2); clean_fresh_copies(d); RemoveDirectoryA(d); }

    DeleteFileA(canon); RemoveDirectoryA(dir);
    printf("\n失败数: %d\n",fails); return fails?1:0; }
