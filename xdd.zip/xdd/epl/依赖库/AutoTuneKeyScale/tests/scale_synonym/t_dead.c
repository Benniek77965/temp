/* 这一类失败我犯过:用脚本改源码时,某处替换因为缩进不符而【静默不生效】,
   于是新加的辅助函数定义了却从未被调用 —— 编译通过、单元测试也通过(测的是函数本身),
   功能却从头到尾没接上。所以把"有没有定义了不用的 static 函数"做成常驻检查。 */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
static char src[700000], include_probe[700000], included_uses[200000];
/* 这些是入口点或由系统按地址调用的回调,没有显式调用点是正常的 */
static const char* ENTRY[] = {
  "DllMain","WinMain","WndProc","worker","scan_thread","veh",
  "myCreateInstance","myInitialize","mySetComponentHandler",
  "myCreateInstance_inner","myInitialize_inner","mySetComponentHandler_inner",
  "dll_notify", 0 };
static int is_entry(const char* n){ for(int i=0;ENTRY[i];i++) if(!strcmp(n,ENTRY[i])) return 1; return 0; }
/* 去掉块注释,免得注释里提到函数名被当成使用 */
static void strip_comments(char* s){
  for(char* p=s; *p; ){
    if(p[0]=='/'&&p[1]=='*'){ char* e=strstr(p+2,"*/"); if(!e){ *p=0; break; } while(p<e+2) *p++=' '; }
    else if(p[0]=='/'&&p[1]=='/'){ while(*p&&*p!='\n')*p++=' '; }
    else if(*p=='"'||*p=='\''){ char quote=*p++; while(*p&&*p!=quote){if(*p=='\\'&&p[1]){*p++=' ';*p++=' ';}else *p++=' ';}if(*p)p++; }
    else p++;
  }
}
/* Preserve include string tokens while masking comments; a path mentioned
   only in a comment must not make an otherwise unused helper look connected. */
static void strip_comments_only(char* s){
  for(char* p=s;*p;){
    if(*p=='"'||*p=='\''){char quote=*p++;while(*p&&*p!=quote){if(*p=='\\'&&p[1])p+=2;else p++;}if(*p)p++;}
    else if(p[0]=='/'&&p[1]=='*'){char* e=strstr(p+2,"*/");if(!e){*p=0;break;}while(p<e+2)*p++=' ';}
    else if(p[0]=='/'&&p[1]=='/'){while(*p&&*p!='\n')*p++=' ';}
    else p++;
  }
}
static int scan(const char* path){
  FILE* f=fopen(path,"r"); if(!f){ printf("   找不到 %s —— 未验证任何东西\n",path); return 1; }   /* 必须为正:bad 是累加的,负数会抵消掉别处的真失败 */
  size_t n=fread(src,1,sizeof src-1,f); src[n]=0; fclose(f);
  included_uses[0]=0;
  strcpy(include_probe,src);strip_comments_only(include_probe);
  if(strstr(include_probe,"#include \"../vst3/cpp/companion_ui_install.h\"")){
    /* This main-file helper is called by the included owner-thread installer.
       Read the real use site instead of declaring the helper an exempt entry. */
    const char* header="../../vst3/cpp/companion_ui_install.h";
    FILE* h=fopen(header,"rb");
    if(!h){ printf("   找不到实际include %s —— 调用链未验证\n",header); return 1; }
    size_t hn=fread(included_uses,1,sizeof included_uses-1,h); included_uses[hn]=0; fclose(h);
    if(hn==sizeof included_uses-1){printf("   include缓冲不足，拒绝截断后放行\n");return 1;}
    strip_comments(included_uses);
  }
  strip_comments(src);
  int bad=0, checked=0;
  for(char* p=src; (p=strstr(p,"static ")) != NULL; p++){
    if(p!=src && p[-1]!='\n') continue;                 /* 只看行首定义 */
    char* par=strchr(p,'('); char* nl=strchr(p,'\n');
    if(!par || (nl && nl<par)) continue;                /* 不是函数定义 */
    char* q=par; while(q>p && (isalnum((unsigned char)q[-1])||q[-1]=='_')) q--;
    char name[128]; int L=(int)(par-q); if(L<=0||L>120) continue;
    memcpy(name,q,L); name[L]=0;
    if(is_entry(name)) continue;
    checked++;
    /* 统计:调用 name( 或 按地址引用 name, / name) / name; */
    int uses=0;
    const char* inputs[]={src,included_uses};
    for(int input=0;input<2;input++) for(char* r=(char*)inputs[input]; (r=strstr(r,name))!=NULL; r+=L){
      if(r==q) continue;                                 /* 定义本身 */
      char before = (r==inputs[input])?' ':r[-1];
      if(isalnum((unsigned char)before)||before=='_') continue;
      char after = r[L];
      if(after=='('||after==','||after==')'||after==';'||after==' ') uses++;
    }
    if(uses==0){ printf("   FAIL %-28s 定义了却从未被使用 <- 多半是某次改动没接上\n",name); bad++; }
  }
  printf("   检查 %d 个 static 函数,未被使用的 %d 个\n",checked,bad);
  return bad;
}
int main(int argc, char** argv){
  int bad=0;
  if(argc>1){ printf("== 自检:%s ==\n",argv[1]); int b=scan(argv[1]);
              printf("\n自检应当报出 1 个未使用函数,实际 %d 个 -> %s\n", b, b==1?"检查器有效":"检查器失效");
              return b==1?0:1; }
  printf("== at_agent.cpp ==\n");
  bad += scan("at_agent.cpp");
  printf("== AutoTune_KeyScale_Controller.cpp ==\n");
  bad += scan("AutoTune_KeyScale_Controller.cpp");
  printf("\n失败数: %d\n",bad);
  return bad?1:0;
}
