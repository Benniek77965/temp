/* 注入失败退避:一个注不进去的进程不能把扫描线程拖死,但也不能静默放弃 */
#include <stdio.h>
#include <string.h>
typedef unsigned long DWORD;
#define MAXTRACK 64
#include "t_inj_funcs.inc"
static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)
int main(void){
  printf("== 1. 连续失败 %d 次后不再尝试(每次尝试最多阻塞 20 秒)==\n", INJ_MAX_TRIES);
  CK(!inject_abandoned(1000), "首次:会尝试");
  inject_failed(1000,"QQ.exe");  CK(!inject_abandoned(1000), "失败1次:仍会尝试");
  inject_failed(1000,"QQ.exe");  CK(!inject_abandoned(1000), "失败2次:仍会尝试");
  inject_failed(1000,"QQ.exe");  CK( inject_abandoned(1000), "失败3次:放弃");
  CK(inject_abandoned_count()==1, "状态栏能显示'有进程已放弃'(不静默)");

  printf("\n== 2. 中途成功要清零,别被之前的失败拖累 ==\n");
  inject_failed(2000,"Sam.exe"); inject_failed(2000,"Sam.exe");
  inject_ok(2000);
  CK(!inject_abandoned(2000), "成功后记录清除");
  for(int i=0;i<3;i++) inject_failed(2000,"Sam.exe");
  CK(inject_abandoned(2000), "之后重新累计到 3 次才放弃");

  printf("\n== 3. 进程退出后记录要被清掉,重启该进程可重新尝试 ==\n");
  { struct { DWORD pid; } hosts[1]; hosts[0].pid=1000;        /* 2000 已退出 */
    int v=0; for(int i=0;i<g_nFail;i++){ int alive=0;
      for(int j=0;j<1;j++) if(hosts[j].pid==g_failPid[i]){alive=1;break;}
      if(alive){ g_failPid[v]=g_failPid[i]; g_failN[v]=g_failN[i]; v++; } } g_nFail=v;
    CK(!inject_abandoned(2000), "退出的进程记录已清除 -> 重启后可重试");
    CK( inject_abandoned(1000), "仍在运行的放弃记录保留"); }

  printf("\n== 4. 表满了也不能越界 ==\n");
  { g_nFail=0; for(int i=0;i<MAXTRACK+20;i++) inject_failed(5000+i,"x");
    CK(g_nFail<=MAXTRACK, "记录数不超过表容量"); }
  printf("\n失败数: %d\n",fails); return fails?1:0;
}
