/* 每一轮复查我都报告"已修"。但脚本改源码时一次匹配失败就是静默空操作,
   build 1081 就这样把一个修复丢了,直到 1087 才发现。t_dead 能抓"新函数没接上",
   抓不到"改了已有代码却没改成"。这里把【历次声称的改动】逐条对回源码。 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
static char A[700000], C[400000];
static int load(const char* p, char* buf, int cap){
    FILE* f=fopen(p,"r"); if(!f) return 0;
    size_t n=fread(buf,1,(size_t)cap-1,f); buf[n]=0; fclose(f); return (int)n;
}
/* 把搜索范围限制在某个函数体内(sig 要求出现在该函数里,而不是文件任意位置) */
static const char* scope(const char* src, const char* fn, char* out, int cap){
    if(!fn) return src;
    /* Skip FORWARD DECLARATIONS: several of these functions are declared before they are defined,
       and taking the first match would scope the search to a line ending in ';' with no body --
       reporting a perfectly present fix as missing. A definition is the occurrence whose '{'
       comes before the next ';'. */
    /* 1152 后收紧:必须是"名字 ( 参数 ) 空白 {"。原规则只看"之后先遇到 { 还是 ;",于是注释里提到函数名、
       紧跟着又是另一个函数的定义时,就把那个函数当成了它 —— 实际发生过:rec_append 的注释写了
       "see write_scales_union",1062 那一项随即在 rec_append 的函数体里找特征而误报缺失。反方向更危险:
       若那个函数恰好含有特征文字,核对会假通过。也顺带不再让 "static void trim" 配上 "static void trim_x(". */
    const char* i=src; const char* b=NULL; size_t fl=strlen(fn);
    for(;;){ i=strstr(i,fn); if(!i) return "";
             const char* p=i+fl;
             if(*p=='('){ int dp=0; const char* q=p;
                 for(;*q;q++){ if(*q=='(') dp++; else if(*q==')'){ if(--dp==0){ q++; break; } } }
                 while(*q==' '||*q=='\t'||*q=='\r'||*q=='\n') q++;
                 if(*q=='{'){ b=q; break; } }
             i+=1; }
    if(!b) return "";
    int d=0; const char* q=b;
    for(;;){ if(*q=='{')d++; else if(*q=='}')d--; if(!d||!*q) break; q++; }
    int L=(int)(q-i); if(L>cap-1) L=cap-1;
    memcpy(out,i,(size_t)L); out[L]=0; return out;
}
/* 保护标记 ATC_NOINLINE 写在 static 与返回类型之间(只影响内联,不改函数内容)。核对按不带它的签名找函数,
   所以载入后先从内存副本里去掉这个标记,否则加了标记的函数会被误报"缺失"。要核对的特征文字都在函数体里,
   去掉它不改变任何一项的结果;源文件本身不动。 */
static void drop_token(char* s, const char* tok){
    size_t n=strlen(tok); char* w=s; const char* r=s;
    while(*r){ if(!strncmp(r,tok,n)){ r+=n; continue; } *w++=*r++; }
    *w=0;
}
typedef struct { int ver; const char* desc; int file; const char* fn; const char* sig; } Claim;
/* Removed claims refer exclusively to deleted controller widgets/settings.
   Agent host-thread marshalling and all remaining runtime claims stay checked. */
static const Claim CL[] = {
 {1055,"GetPluginFactory 全局只调一次",       0,NULL,"factory_once"},
 {1056,"根音表容得下 17 档",                  0,NULL,"char kdisp[24]"},
 {1056,"滑块映射到 Waves Speed",              0,NULL,"haveWSpeed) v3set"},
 {1057,"isWaves 用事实标记",                  0,NULL,"waves_known(c)"},
 {1057,"盲写需肯定识别",                      0,NULL,"antOK"},
 {1058,"走宿主 IComponentHandler",            0,NULL,"performEdit"},
 {1059,"惰性日志",                            0,NULL,"g_logArmed"},
 {1059,"注入扫描分两遍",                      1,NULL,"looksHost"},
 {1061,"音阶同义词",                          0,NULL,"scale_same"},
 {1062,"按实例发布音阶清单",                  0,"write_scales_union","[%s]"},
 {1063,"实例 ID",                             0,NULL,"inst_id"},
 {1066,"盲写门控肯定式",                      0,NULL,"ctrl_module_is_antares"},
 {1066,"截断不再静默",                        0,NULL,"NOT selectable"},
 {1066,"按音名匹配推广",                      0,NULL,"d->haveK && keySemi>=0 && d->nkeys>0"},
 {1067,"守护保存恢复 g_probing",              0,"static void mod_of_ctrl","g_probing=sv"},
 {1067,"嵌套守护哨兵",                        0,NULL,"warn_nested_guard"},
 {1067,"钩子表加锁",                          0,"static void hook_component_initialize","EnterCriticalSection"},
 {1067,"钩子回调查表加锁",                    0,"static tresult WINAPI myInitialize_inner","EnterCriticalSection"},
 {1068,"实例生存判定",                        0,NULL,"liveness_decide"},
 {1068,"缓存工厂时钉住模块",                  0,"static IPluginFactory* factory_once","PIN"},
 {1070,"Waves CID 按结构解码",                0,NULL,"cid_is_waves"},
 {1070,"按三字母产品代码查表",                0,"static int cid_is_waves","LVw"},
 {1071,"VST2 写入带读回校验",                 0,"static void v2w_apply","v2w_set_checked"},
 {1072,"壳一加载就注入",                      1,NULL,"waveshell\")){ real=1"},
 {1072,"日志每行带 pid",                      0,NULL,"[%lu] "},
 {1073,"V2W 身份指纹",                        0,"static V2W* v2w_discover","v2w_cache_valid"},
 /* 1073 把「按显示名比对」加在了【上报】侧,那是错的位置:上报一旦按目标过滤,
    其余实例就从 Target 列表里消失(1118 实测)。能力没消失,是搬到了【下发】侧。 */
 {1118,"Target 用显示名比对(在下发侧)",        0,NULL,"snprintf(lf,sizeof lf,\"%s\",w2->name)"},
 {1074,"不把结构体成员交给插件写",            0,"static V2W* v2w_discover","char nm[256]"},
 {1074,"非调音器 Waves 实例放掉",             0,"static void drop_dead_instances","not a tuner"},
 {1075,"trim 净化控制字符",                   0,"static void trim","< 0x20) s[k]=' '"},
 {1077,"命令行完整性判据",                    0,NULL,"cmd_line_complete"},
 {1077,"命令缓冲至少512(当前4096)",           0,"static DWORD WINAPI worker","char line[4096]"},
 {1078,"状态/音阶原子发布",                   0,NULL,"publish_file"},
 {1078,"控制器拒绝半截读",                    1,"static void read_status","torn=1"},
 {1079,"ASCII 大小写折叠",                    0,NULL,"at_stricmp"},
 {1080,"在途钩子计数",                        0,NULL,"g_inHook"},
 {1164,"工作线程挂钩前固定模块映像以安全停用",  0,"static DWORD WINAPI worker","GetModuleHandleExA(0x1|0x4"},
 {1081,"注入失败退避已接上",                  1,"static DWORD WINAPI scan_thread","inject_failed"},
 {1081,"快速注入路径也接上",                  1,"static void fast_proactive_inject","inject_failed"},
 {1083,"退出时边泵边等",                      1,NULL,"MsgWaitForMultipleObjects"},
 {1083,"注入器分片等待",                      1,"static int run_hidden","!g_running"},
 {1084,"pending 按进程",                      0,NULL,"pending_%lu.txt"},
 {1084,"只采纳已死进程的标记",                0,"static void cb_startup","proc_alive"},
 {1085,"控制器单实例",                        1,NULL,"AT8_KeyScale_Controller_single"},
 {1085,"日志整行一次写出",                    0,NULL,"fwrite(line,1,(size_t)n,g_log)"},
 {1086,"agent 文件缺失要报告",                1,NULL,"g_agentMissing"},
 /* 以下两条是单行判定,无法作为函数提取;变异测试显示它们此前无人把守,
    所以改用「源码必须含有这串」的方式守住。 */
 {1095,"T-Pain 的 VST2 按名发现",           0,NULL,"strstr_ci(ml0,\"t-pain\")"},
 {1102,"卸载时禁止再安装钩子",             0,NULL,"if(g_ejecting) return;"},
 /* 1162:离开 exe 目录 */
 {1162,"数据目录不在 exe 旁",                1,"static void resolve_commdir","LOCALAPPDATA"},
 {1162,"pending 不再留空文件",               0,"static void cb_clear_pending","DeleteFileA(g_pendPath)"},
 {1162,"迁移按名字+内容认文件",              1,"static int migrate_dir","mig_classify(fd.cFileName,head,size,&pid)"},
 {1162,"迁移不删用户文件(只在首次复制)",     1,"static int migrate_dir","CopyFileA(sp,dp,TRUE)"},
 {1162,"同一文件夹的不同写法只算一个",        1,"static void migrate_legacy","same_dir(cand[i],COMMDIR)"},
 {1162,"旧指针指向的文件夹也纳入迁移",        1,"static void resolve_commdir","g_prevCommDir"},
 {1162,"没清完的旧位置记下来,下次接着处理",   1,"static void migrate_legacy","legacy_dirs.txt"},
 {1162,"关闭时卸载也通知旧版 agent",          1,NULL,"eject_legacy_agents();"},
 {1162,"进程号被重用时按文件时间判定",        1,"static int file_owner_alive","written+30000000ULL < started"},
 {1162,"列表开头的 BOM 不算进第一项(scalemap)",0,"static void load_scalemap","drop_bom(line)"},
 {1162,"列表开头的 BOM 不算进第一项(catch)",  0,"static void load_catch_list","drop_bom(line)"},
 {1162,"列表开头的 BOM 不算进第一项(skip 等)", 0,"static void cb_startup","drop_bom(line)"},
 {1162,"dawhost.txt 开头的 BOM(控制器)",     1,"static void load_dawhosts","drop_bom(line)"},
 {1162,"数据文件夹被删后:扫描线程每轮重建",   1,"static DWORD WINAPI scan_thread","ensure_data_dir();"},
 {1162,"%LOCALAPPDATA% 按 Unicode 读、精确转换(控制器)",1,"static int local_appdata_ansi","WC_NO_BEST_FIT_CHARS"},
 {1162,"%LOCALAPPDATA% 按 Unicode 读、精确转换(agent)",0,"static int local_appdata_ansi","WC_NO_BEST_FIT_CHARS"},
 {1162,"agent 读列表遇「正在替换」稍等重试(skip)",0,"static void cb_startup","fopen_retry(g_skipPath"},
 {1162,"agent 读列表遇「正在替换」稍等重试(catch)",0,"static void load_catch_list","fopen_retry(g_catchPath"},
 {1162,"agent 读列表遇「正在替换」稍等重试(scalemap)",0,"static void load_scalemap","fopen_retry(g_scalemapPath"},
 {1162,"状态文件一时打不开:保持上一轮",      1,"static void read_status","ERROR_SHARING_VIOLATION"},
 {1162,"旧位置文件正被占用:留待下次",       1,"static int migrate_dir","if(GetLastError()==ERROR_SHARING_VIOLATION){ live=1; left++; }"},
 {1162,"解出的二进制在使用期间锁定(只读共享)",1,"static int pin_and_verify","CreateFileA(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL)"},
 {1162,"启动时解出即锁定",                    1,"static void ensure_runtime","ensure_pinned(\"AGENT64\""},
 {1162,"音阶同义词即时生效(agent)",           0,"static void cmd_side_effects","g_grpLoaded=0"},
 {1162,"扫描慢时写进日志",                    0,"static void scan_all","heap scan took"},
 {0,NULL,0,NULL,NULL}
};
int main(int argc, char** argv){
    if(!load("at_agent.cpp",A,sizeof A) || !load("AutoTune_KeyScale_Controller.cpp",C,sizeof C)){
        printf("找不到源码 —— 本套未验证任何东西,按失败处理\n"); return 1; }
    drop_token(A, "ATC_NOINLINE "); drop_token(C, "ATC_NOINLINE ");
    int drop = (argc>1) ? atoi(argv[1]) : -1;   /* 自检:假装第 N 条不存在 */
    static char buf[200000];
    int bad=0, n=0;
    for(int i=0; CL[i].sig; i++){
        n++;
        const char* src = CL[i].file ? C : A;
        const char* seg = scope(src, CL[i].fn, buf, sizeof buf);
        int ok = strstr(seg, CL[i].sig) != NULL;
        if(i==drop) ok=0;                        /* 自检用 */
        if(!ok){ printf("   ✗ %d  %s\n", CL[i].ver, CL[i].desc); bad++; }
    }
    printf("   逐条核对 %d 项历史改动:%d 项确认在源码中,%d 项缺失\n", n, n-bad, bad);
    if(drop>=0){ printf("\n   自检:故意屏蔽第 %d 条,应报 1 项缺失 -> %s\n", drop, bad==1?"检查器有效":"检查器失效");
                 return bad==1?0:1; }
    printf("\n失败数: %d\n", bad);
    return bad?1:0;
}
