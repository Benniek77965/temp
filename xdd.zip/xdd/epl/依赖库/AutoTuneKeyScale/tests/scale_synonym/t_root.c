#include <stdio.h>
#include <string.h>
/* 真实 key_to_pc(从 at_agent.cpp 提取) */
#include "t_root_funcs.inc"
int main(void){
  /* 真机实测的两份 root 清单 */
  const char* PRO[]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};               int nP=12, stepsP=11;
  const char* WAV[]={"C","C#","Db","D","D#","Eb","E","F","F#","Gb","G","G#","Ab","A","A#","Bb","B"}; int nW=17, stepsW=16;
  int fail=0;
  printf("%-4s %-22s %-22s\n","调","电音11(按名/公式)","Waves(按名/公式)");
  for(int k=0;k<12;k++){
    double byNameP=-1, byNameW=-1;
    for(int i=0;i<nP;i++) if(key_to_pc(PRO[i])==k){ byNameP=(double)i/stepsP; break; }
    for(int i=0;i<nW;i++) if(key_to_pc(WAV[i])==k){ byNameW=(double)i/stepsW; break; }
    double formulaP=(double)k/stepsP, formulaW=(double)k/stepsW;
    int okP = (byNameP>=0) && (byNameP==formulaP);
    int okW = (byNameW>=0);
    /* Waves 上公式本来就是错的,按名才对 */
    printf("%-4s %.4f/%.4f %-8s %.4f/%.4f %s\n", PRO[k], byNameP,formulaP, okP?"一致":"不一致",
           byNameW,formulaW, (byNameW!=formulaW)?"<- 公式会选错":"");
    if(!okP){ printf("   FAIL 电音11 上按名匹配改变了结果\n"); fail++; }
    if(!okW){ printf("   FAIL Waves 上音级 %d 找不到\n",k); fail++; }
  }
  printf("\n结论:电音11 上 12/12 与公式完全一致(推广无副作用);Waves 上公式多数会选错,按名才正确。\n");
  printf("失败数: %d\n",fail); return fail?1:0;
}
