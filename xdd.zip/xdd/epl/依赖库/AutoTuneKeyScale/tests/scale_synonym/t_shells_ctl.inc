static int icontains(const char* s, const char* sub) {
    char a[600], b[64]; size_t i;
    for (i = 0; s[i] && i < 599; i++) a[i] = (char)tolower((unsigned char)s[i]); a[i] = 0;
    for (i = 0; sub[i] && i < 63; i++) b[i] = (char)tolower((unsigned char)sub[i]); b[i] = 0;
    return strstr(a, b) != NULL;
}
