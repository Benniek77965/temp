/* 「已加载，未捕获」占位符的去重(1098 修的问题)

   catch 模块若已经有实例在控了,就不该再列一条占位符。原先只查 VST3 那一侧,
   于是宿主当作 VST2 使用的模块永远挂着一条"未捕获",真机上表现为三条:

     Sam_x64.exe | The T-Pain Effect.vst3   Key=C  Scale=Major Pentatonic   <- VST3 实例
     Sam_x64.exe | The T-Pain Effect        Key=C  Scale=Major Pentatonic   <- VST2 实例
     Sam_x64.exe | The T-Pain Effect.dll    (已加载,未捕获 ...)             <- 多余

   第三条等的是一个永远不会出现的 VST3 实例:宿主是把这个 dll 当 VST2 加载的。
   The T-Pain Effect 会碰上,是因为**同一个 dll 同时导出** VSTPluginMain 和
   GetPluginFactory,于是被登记成 VST3 catch 模块。Waves 的 VST2 壳不导出
   GetPluginFactory,pass-1 就把它挡掉了,所以从不产生占位符。 */
#include <stdio.h>
#include <string.h>
#define _stricmp strcasecmp

/* 复刻 write_status 里那段判定:三个来源任一命中即不列占位符 */
static int pending_suppressed(const char* leaf,
                              const char* const* capshell, int ncap,   /* 已控实例所属的壳 */
                              const char* const* v3mods,  int nv3,     /* 已捕获 VST3 的模块 */
                              const char* const* v2mods,  int nv2){    /* 已捕获 VST2 的模块 */
  for(int i=0;i<ncap;i++) if(!_stricmp(capshell[i],leaf)) return 1;
  for(int i=0;i<nv3;i++)  if(!_stricmp(v3mods[i],leaf))  return 1;
  for(int i=0;i<nv2;i++)  if(!_stricmp(v2mods[i],leaf))  return 1;   /* 1098 新增的这一路 */
  return 0;
}

static int fails=0;
static void chk(const char* what,int got,int want){
  int ok=(got==want);
  printf("   %-44s got=%d want=%d %s\n",what,got,want,ok?"OK":"FAIL");
  if(!ok) fails++;
}

int main(void){
  const char* NONE[1]={0};

  printf("== 真机场景:T-Pain 的 vst3 与 dll 同时挂载 ==\n");
  { const char* v3[]={"The T-Pain Effect.vst3"};
    const char* v2[]={"The T-Pain Effect.dll"};
    chk("vst3 模块:已有 VST3 实例 -> 不列",
        pending_suppressed("The T-Pain Effect.vst3",NONE,0,v3,1,v2,1),1);
    chk("dll  模块:已有 VST2 实例 -> 不列",
        pending_suppressed("The T-Pain Effect.dll", NONE,0,v3,1,v2,1),1); }

  printf("\n== 回归:1097 的行为(不查 VST2)会多出一条 ==\n");
  { const char* v3[]={"The T-Pain Effect.vst3"};
    chk("只查 VST3 -> dll 被误列(报告的 bug)",
        pending_suppressed("The T-Pain Effect.dll",NONE,0,v3,1,NONE,0),0); }

  printf("\n== 占位符仍须在该出现时出现 ==\n");
  { chk("已加载但什么都没捕获 -> 要列",
        pending_suppressed("The T-Pain Effect.dll",NONE,0,NONE,0,NONE,0),0);
    const char* v2[]={"OtherPlugin.dll"};
    chk("捕获的是别的模块 -> 仍要列",
        pending_suppressed("The T-Pain Effect.dll",NONE,0,NONE,0,v2,1),0); }

  printf("\n== 不能跨模块误抑制 ==\n");
  { const char* v2[]={"The T-Pain Effect.dll"};
    chk("dll 有实例不应让 vst3 被抑制",
        pending_suppressed("The T-Pain Effect.vst3",NONE,0,NONE,0,v2,1),0); }

  printf("\n== Waves:壳名不同,互不影响 ==\n");
  { const char* v3[]={"WaveShell1-VST3 16.7_x64.vst3"};
    const char* v2[]={"WaveShell1-VST 14.19_x64.dll"};
    chk("VST3 壳有实例 -> 抑制自己",
        pending_suppressed("WaveShell1-VST3 16.7_x64.vst3",NONE,0,v3,1,v2,1),1);
    chk("VST2 壳不会被 VST3 壳误抑制",
        pending_suppressed("WaveShell1-VST 14.19_x64.dll",NONE,0,v3,1,NONE,0),0); }

  printf("\n== capshell 这一路(原有行为)不受影响 ==\n");
  { const char* cap[]={"dianyin11.vst3"};
    chk("capshell 命中 -> 抑制",
        pending_suppressed("dianyin11.vst3",cap,1,NONE,0,NONE,0),1); }

  printf("\n== 大小写不敏感(Windows 文件名) ==\n");
  { const char* v2[]={"THE T-PAIN EFFECT.DLL"};
    chk("大小写不同仍应命中",
        pending_suppressed("the t-pain effect.dll",NONE,0,NONE,0,v2,1),1); }

  printf("\n失败数: %d\n",fails);
  return fails?1:0;
}
