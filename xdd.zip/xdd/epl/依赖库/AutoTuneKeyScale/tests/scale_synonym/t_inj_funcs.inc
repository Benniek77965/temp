#define INJ_MAX_TRIES 3
static DWORD g_failPid[MAXTRACK]; static int g_failN[MAXTRACK]; static int g_nFail=0;
static int inject_abandoned_count(){ int n=0; for(int i=0;i<g_nFail;i++) if(g_failN[i]>=INJ_MAX_TRIES) n++; return n; }
static int inject_abandoned(DWORD pid){ for(int i=0;i<g_nFail;i++) if(g_failPid[i]==pid) return g_failN[i]>=INJ_MAX_TRIES; return 0; }
static void inject_failed(DWORD pid, const char* exe){
    for(int i=0;i<g_nFail;i++) if(g_failPid[i]==pid){
        ++g_failN[i]; (void)exe; return; }
    if(g_nFail<MAXTRACK){ g_failPid[g_nFail]=pid; g_failN[g_nFail]=1; g_nFail++; } }
static void inject_ok(DWORD pid){ for(int i=0;i<g_nFail;i++) if(g_failPid[i]==pid){
        for(int k=i;k<g_nFail-1;k++){ g_failPid[k]=g_failPid[k+1]; g_failN[k]=g_failN[k+1]; } g_nFail--; return; } }
