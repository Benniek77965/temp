/* worker 与宿主界面线程之间的交接协议(1145)—— 真线程运行时测试

   1144 把参数写入投递到宿主界面线程执行,worker 等到截止时刻没等到就自己写。两边都是
   「先看 state 再动手」:界面线程看到 state==1 就开始写,worker 看到 state!=2 就放弃并自己写。
   界面线程恰好在截止时刻前后忙完 —— 正是会产生超时的那种场景 —— 两边就会同时动手:
   两个线程同时在同一个 controller 里,交错发 beginEdit/performEdit/endEdit。

   1145 把「代数 + 阶段」打包进一个 32 位字,两边都用 CAS 抢:
     界面线程  CAS(gen|POST -> gen|RUN)   抢到才执行
     worker   CAS(gen|POST -> gen|FREE)  抢到才自己写
   两个 CAS 只可能有一个成功。

   本测试用两个真线程围绕截止时刻随机抢,断言每条请求【恰好】被执行一次。
   同一台测试也跑旧逻辑 —— 必须能稳定抓到双写,否则说明测试台本身没压到边界、不可信。

   原子原语用 __sync_val_compare_and_swap:MinGW 的 InterlockedCompareExchange 展开后就是它,
   所以这里测的和生产代码是同一条指令。线程与计时按平台条件编译,保持 `gcc -O1 -w` 即可编。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#  include <windows.h>
   static long long now_us(void){ static LARGE_INTEGER f; LARGE_INTEGER c; if(!f.QuadPart) QueryPerformanceFrequency(&f);
       QueryPerformanceCounter(&c); return (long long)(c.QuadPart*1000000LL/f.QuadPart); }
   static void yield_(void){ SwitchToThread(); }
   typedef HANDLE thr_t;
   static DWORD WINAPI ui_tramp(LPVOID a);
   static void thr_start(thr_t* t, void* a){ *t=CreateThread(0,0,ui_tramp,a,0,0); }
   static void thr_join(thr_t t){ WaitForSingleObject(t,INFINITE); CloseHandle(t); }
#else
#  include <pthread.h>
#  include <sched.h>
#  include <time.h>
   static long long now_us(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec*1000000LL+t.tv_nsec/1000; }
   static void yield_(void){ sched_yield(); }
   typedef pthread_t thr_t;
   static void* ui_tramp(void* a);
   static void thr_start(thr_t* t, void* a){ pthread_create(t,0,ui_tramp,a); }
   static void thr_join(thr_t t){ pthread_join(t,0); }
#endif

/* ---- 与 at_agent.cpp 逐字一致(下面的接缝检查会核对) ---- */
#define UIQ 16
#define UIPH_FREE 0      /* never used, or reclaimed by the worker      */
#define UIPH_POST 1      /* published, message queued                   */
#define UIPH_RUN  2      /* claimed by the UI thread, executing         */
#define UIPH_DONE 3      /* finished (fault, if any, is in .faulted)    */
#define UIGEN_MASK 0x07FFFFFFUL
#define UIW(g,ph) ((LONG_)((((unsigned long)(g)&UIGEN_MASK)<<2)|(unsigned long)(ph)))
#define UIPH(w)   ((LONG_)(w)&3)
#define UIGEN(w)  ((LONG_)(((unsigned long)(w)>>2)&UIGEN_MASK))
typedef int LONG_;                                   /* Windows LONG is 32 bits on both x86 and x64 */
static LONG_ CAS(volatile LONG_* p, LONG_ nv, LONG_ ov){ return __sync_val_compare_and_swap(p,ov,nv); }
static void  XCHG(volatile LONG_* p, LONG_ nv){ __atomic_exchange_n(p,nv,__ATOMIC_SEQ_CST); }

#define NREQ 1500
#define DEAD_US 800                                  /* worker 的截止时刻 */
#define UIDELAY_US 1600                              /* 界面线程在投递后 0..1.6ms 才处理:约一半越过截止 */
static int OLD;
static volatile LONG_ word[UIQ]; static int reqOf[UIQ];
static volatile LONG_ st[UIQ], gn[UIQ];             /* 旧逻辑的两个字段 */
static volatile LONG_ uiExec[NREQ], wkExec[NREQ];
static unsigned long q[1<<15]; static long long qts[1<<15]; static volatile LONG_ qh, qt;
static volatile LONG_ stopFlag;
static void qput(unsigned long m){ LONG_ t=qt; q[t&0x7FFF]=m; qts[t&0x7FFF]=now_us(); __sync_synchronize(); qt=t+1; }
static int  qget(unsigned long* m, long long* ts){ LONG_ h=qh; if(h==qt) return 0; __sync_synchronize();
    *m=q[h&0x7FFF]; *ts=qts[h&0x7FFF]; qh=h+1; return 1; }
static unsigned rnd(unsigned* s){ *s=*s*1103515245u+12345u; return (*s>>16)&0x7fff; }
static void spin_until(long long t){ while(now_us()<t) yield_(); }

static void ui_loop(unsigned s){
    unsigned long m; long long ts;
    while(!stopFlag){
        if(!qget(&m,&ts)){ yield_(); continue; }
        spin_until(ts + (long long)(rnd(&s)%UIDELAY_US));   /* 过期消息立刻处理,与 at_wndproc 一致 */
        int k=(int)(m&0xF); LONG_ g=(LONG_)((m>>4)&UIGEN_MASK);
        if(!OLD){
            if(CAS(&word[k],UIW(g,UIPH_RUN),UIW(g,UIPH_POST))==UIW(g,UIPH_POST)){
                spin_until(now_us()+(long long)(rnd(&s)%300));   /* 插件调用耗时 */
                __sync_fetch_and_add(&uiExec[reqOf[k]],1);
                XCHG(&word[k],UIW(g,UIPH_DONE)); }
        } else {
            if(st[k]==1 && (gn[k]&0x7FFF)==(LONG_)g){            /* 先看 …… */
                spin_until(now_us()+(long long)(rnd(&s)%300));   /* …… 再动手 */
                __sync_fetch_and_add(&uiExec[reqOf[k]],1);
                st[k]=2; } } } }
#ifdef _WIN32
static DWORD WINAPI ui_tramp(LPVOID a){ ui_loop((unsigned)(size_t)a); return 0; }
#else
static void* ui_tramp(void* a){ ui_loop((unsigned)(size_t)a); return 0; }
#endif

static int run(int old, int* bothOut, int* noneOut, int* uiOut, int* wkOut){
    OLD=old; memset((void*)word,0,sizeof word); memset((void*)st,0,sizeof st); memset((void*)gn,0,sizeof gn);
    memset((void*)uiExec,0,sizeof uiExec); memset((void*)wkExec,0,sizeof wkExec); qh=qt=0; stopFlag=0;
    thr_t t; thr_start(&t,(void*)(size_t)7);
    int slot=0;
    for(int r=0;r<NREQ;r++){
        int k=-1;
        for(int i=0;i<UIQ;i++){ int j=(slot+i)%UIQ;
            LONG_ ph = OLD ? (st[j]==1?UIPH_POST:UIPH_FREE) : UIPH(word[j]);
            if(ph==UIPH_FREE||ph==UIPH_DONE){ k=j; break; } }
        if(k<0){ yield_(); r--; continue; }
        slot=(k+1)%UIQ; reqOf[k]=r;
        if(!OLD){
            LONG_ g=(UIGEN(word[k])+1)&(LONG_)UIGEN_MASK;
            XCHG(&word[k],UIW(g,UIPH_POST));
            qput(((unsigned long)g<<4)|(unsigned long)k);
            long long t0=now_us(); while(UIPH(word[k])==UIPH_POST && now_us()-t0<DEAD_US) yield_();
            if(CAS(&word[k],UIW(g,UIPH_FREE),UIW(g,UIPH_POST))==UIW(g,UIPH_POST))
                __sync_fetch_and_add(&wkExec[r],1);                 /* 收回成功:由 worker 写 */
            else while(UIPH(word[k])==UIPH_RUN) yield_();          /* 界面线程已占用:等它写完,绝不重复 */
        } else {
            LONG_ g=__sync_add_and_fetch(&gn[k],1);
            st[k]=1;
            qput(((unsigned long)(g&0x7FFF)<<4)|(unsigned long)k);
            long long t0=now_us(); while(st[k]==1 && now_us()-t0<DEAD_US) yield_();
            if(st[k]!=2){ __sync_add_and_fetch(&gn[k],1); st[k]=0; __sync_fetch_and_add(&wkExec[r],1); }
        }
    }
    spin_until(now_us()+300000); stopFlag=1; thr_join(t);
    int both=0,none=0,ui=0,wk=0;
    for(int r=0;r<NREQ;r++){ LONG_ u=uiExec[r], w=wkExec[r];
        if(u+w==0) none++; else if(u+w>1) both++; else if(u) ui++; else wk++; }
    *bothOut=both; *noneOut=none; *uiOut=ui; *wkOut=wk; return 0; }

static char* slurp(const char* p){ FILE* f=fopen(p,"rb"); if(!f) return NULL; fseek(f,0,SEEK_END); long n=ftell(f);
    fseek(f,0,SEEK_SET); char* b=(char*)malloc(n+1); if(!b){ fclose(f); return NULL; } n=(long)fread(b,1,n,f); b[n]=0; fclose(f); return b; }

int main(void){
    int fails=0;
    printf("== 接缝:测试里的协议定义必须与 at_agent.cpp 逐字一致 ==\n");
    { char* a=slurp("at_agent.cpp"); if(!a) a=slurp("../build/at_agent.cpp");
      if(!a){ printf("   找不到 at_agent.cpp —— 本套未验证任何东西,按失败处理\n\n失败数: 1\n"); return 1; }
      const char* lines[]={
        "#define UIGEN_MASK 0x07FFFFFFUL",
        "#define UIW(g,ph) ((LONG)((((unsigned long)(g)&UIGEN_MASK)<<2)|(unsigned long)(ph)))",
        "#define UIPH(w)   ((LONG)(w)&3)",
        "#define UIGEN(w)  ((LONG)(((unsigned long)(w)>>2)&UIGEN_MASK))",
        /* 两边都必须用 CAS 抢,发布必须用 InterlockedExchange —— 退回「先看再动手」就是 1144 的竞态 */
        "InterlockedCompareExchange(&g_uiQ[k].word,UIW(gen,UIPH_RUN),UIW(gen,UIPH_POST))==UIW(gen,UIPH_POST)",
        "InterlockedCompareExchange(&g_uiQ[k].word,UIW(gen,UIPH_FREE),UIW(gen,UIPH_POST))==UIW(gen,UIPH_POST)",
        "InterlockedExchange(&g_uiQ[k].word,UIW(gen,UIPH_POST))",
        /* 执行时重取 handler,而不是用投递时捕获的那个:投递与执行之间用户可能移除了插件,
           宿主在同一线程上先跑 setComponentHandler(NULL) 并释放 handler —— 用旧指针就是释放后使用 */
        "void* hNow=handler_of(g_uiQ[k].c);",
        /* The CAS model does not cover HWND identity; bind that guard at the real call site. */
        "ui_target_matches(k,gen,hw,route,GetCurrentThreadId())",
        "InterlockedExchangePointer((void* volatile*)&g_uiQ[k].targetWindow,(void*)target)",
        "InterlockedExchangePointer((void* volatile*)&g_uiQ[k].targetRoute,(void*)targetRoute)",
        "InterlockedExchange(&g_uiQ[k].targetThread,(LONG)tid)",
        "v3set_body(g_uiQ[k].c,hNow,g_uiQ[k].id,g_uiQ[k].v,g_uiQ[k].family,1,g_uiQ[k].pauseEpoch)",
        0};
      for(int i=0;lines[i];i++){ int ok=strstr(a,lines[i])!=NULL;
          printf("   %-6s %.86s\n", ok?"OK":"FAIL", lines[i]); if(!ok) fails++; }
      free(a); }

    printf("\n== 新协议:每条请求恰好执行一次(3 轮 x %d 条) ==\n", NREQ);
    for(int i=0;i<3;i++){ int b,n,u,w; run(0,&b,&n,&u,&w);
        printf("   界面线程 %4d  worker %4d  双写 %d  丢失 %d   %s\n",u,w,b,n,(b==0&&n==0)?"OK":"FAIL");
        if(b||n) fails++;
        /* 两边都必须真的赢过,否则说明边界没被压到,这一轮证明不了什么 */
        if(u<NREQ/10 || w<NREQ/10){ printf("   边界未被充分压测(某一侧赢得太少),本轮无效\n"); fails++; } }

    printf("\n== 对照:旧逻辑必须被抓到双写(否则测试台不可信) ==\n");
    { int b,n,u,w; run(1,&b,&n,&u,&w);
      printf("   界面线程 %4d  worker %4d  双写 %d  丢失 %d   %s\n",u,w,b,n,b>0?"OK(按预期抓到)":"FAIL(测试台没压到边界)");
      if(b==0) fails++; }

    printf("\n失败数: %d\n",fails); return fails?1:0; }
