/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
#include <stdint.h>
#include <string.h>
typedef uint32_t DWORD; typedef uint32_t ULONG; typedef uint16_t WORD; typedef int32_t LONG;
static int eat_find_slot(unsigned char* b, ULONG size, const char* want, DWORD** slotOut, DWORD* origOut){
    if(!b || size<0x200) return 0;
    if(b[0]!='M'||b[1]!='Z') return 0;
    LONG e=*(LONG*)(b+0x3C); if(e<0 || (ULONG)e+0x108>size) return 0;
    unsigned char* nt=b+e; if(*(DWORD*)nt!=0x00004550u) return 0;              /* "PE\0\0" */
    WORD magic=*(WORD*)(nt+0x18); DWORD er,es;
    if(magic==0x20B){ er=*(DWORD*)(nt+0x88); es=*(DWORD*)(nt+0x8C); }          /* PE32+ */
    else if(magic==0x10B){ er=*(DWORD*)(nt+0x78); es=*(DWORD*)(nt+0x7C); }     /* PE32  */
    else return 0;
    if(!er||!es||er>=size||(unsigned long long)er+es>size) return 0;
    /* The fields below live at ed+0x14 .. ed+0x27, so the directory must actually be that big AND
       lie inside the image. Checking only er+es<=size was not enough: a header that declares a
       short export directory would send these reads past the end of the mapping, i.e. an access
       violation raised inside the loader callback -- the one thing this parser promises never to do. */
    if(es<0x28 || (unsigned long long)er+0x28>size) return 0;
    unsigned char* ed=b+er;
    DWORD nf=*(DWORD*)(ed+0x14), nn=*(DWORD*)(ed+0x18);
    DWORD rf=*(DWORD*)(ed+0x1C), rn=*(DWORD*)(ed+0x20), ro=*(DWORD*)(ed+0x24);
    if(!nn||!nf||!rf||!rn||!ro) return 0;
    if((unsigned long long)rf+4ull*nf>size) return 0;
    if((unsigned long long)rn+4ull*nn>size) return 0;
    if((unsigned long long)ro+2ull*nn>size) return 0;
    /* Likewise bounded: nn is only constrained by the image size, so a malformed header could ask
       for millions of name comparisons while the loader lock is held. Real modules are far below
       this (WaveShell 17.1 exports 4968 names, the largest seen). */
    if(nn>65536u) return 0;
    DWORD* fn=(DWORD*)(b+rf); DWORD* nm=(DWORD*)(b+rn); WORD* od=(WORD*)(b+ro);
    int wl=0; while(want[wl]) wl++;
    for(DWORD i=0;i<nn;i++){
        DWORD r=nm[i]; if(!r||r>=size) continue;
        if((unsigned long long)r+wl+1>size) continue;
        const char* s=(const char*)(b+r); int ok=1;
        for(int j=0;j<=wl;j++) if(s[j]!=want[j]){ ok=0; break; }
        if(!ok) continue;
        WORD o=od[i]; if(o>=nf) return 0;
        DWORD v=fn[o];
        if(!v||v>=size) return 0;
        if(v>=er && v<er+es) return 0;                    /* forwarder, not real code -> decline */
        *slotOut=&fn[o]; *origOut=v; return 1; }
    return 0; }
