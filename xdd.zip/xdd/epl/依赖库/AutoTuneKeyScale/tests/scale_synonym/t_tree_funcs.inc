/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
typedef unsigned long DWORD;
#define NEGCACHE 512
/* "when" drives the 30s re-check and "seen" drives eviction; they are not the same clock. A row
   that keeps being hit is not re-checked, so its "when" stays old on purpose -- using it to decide
   liveness would throw out exactly the rows that are doing their job. */
typedef struct { DWORD pid; unsigned long long born; int mods; DWORD when, seen; } NegEnt;
static NegEnt g_neg[NEGCACHE]; static int g_nneg=0;
static void neg_forget(DWORD pid){      /* ALL entries: see neg_hit */
    for(int i=0;i<g_nneg;){ if(g_neg[i].pid==pid) g_neg[i]=g_neg[--g_nneg]; else i++; } }
/* Drop rows for processes that were not in this scan -- they have exited. Without this the table
   only ever grows: a machine that starts short-lived processes (compilers, installers, scripts)
   fills all 512 rows with dead PIDs, after which nothing new can be cached and the whole
   optimisation quietly turns itself off. */
static void neg_sweep(DWORD now){
    for(int i=0;i<g_nneg;){ if(now-g_neg[i].seen > 60000) g_neg[i]=g_neg[--g_nneg]; else i++; } }
static int neg_hit(DWORD pid, unsigned long long born, int mods, DWORD now){
    for(int i=0;i<g_nneg;i++) if(g_neg[i].pid==pid){
        g_neg[i].seen=now;                  /* alive, whatever the verdict below */
        if(g_neg[i].born!=born){            /* the PID was recycled -- this is a different process */
            g_neg[i].born=born; g_neg[i].mods=mods; g_neg[i].when=now; return 0; }
        if(g_neg[i].mods==mods && now-g_neg[i].when < 30000) return 1;
        g_neg[i].mods=mods; g_neg[i].when=now; return 0; }
    if(g_nneg<NEGCACHE){ g_neg[g_nneg].pid=pid; g_neg[g_nneg].born=born;
                         g_neg[g_nneg].mods=mods; g_neg[g_nneg].when=now; g_neg[g_nneg].seen=now; g_nneg++; }
    return 0; }
