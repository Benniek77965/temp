/* agent 原地重写 status 与 scales 两种文件,控制器轮询读 —— 和 cmd.txt 是同一种竞态。
   用真实文件内容在每个字节位置截断,检查判据能挡住所有不完整读。 */
#include <stdio.h>
#include <string.h>
static int complete(const char* b,int n){ return n>0 && b[n-1]=='\n'; }
static int fails=0;
static void run(const char* name,const char* full){
  int L=(int)strlen(full); int acc=0,rej=0,harm=0;
  for(int cut=0;cut<=L;cut++){
    char buf[4096]; memcpy(buf,full,cut); buf[cut]=0;
    if(complete(buf,cut)){
      acc++;
      if(buf[cut-1]!='\n'){ printf("   FAIL %s: 接受了非完整记录\n",name); fails++; }
    } else {
      rej++;
      const char* lastnl=strrchr(buf,'\n');
      const char* tail = lastnl? lastnl+1 : buf;
      if(*tail) harm++;                 /* 贸然解析会得到一条残缺记录 */
    }
  }
  printf("  %s\n    长度 %d,截断点 %d:接受 %d,拒绝 %d\n"
         "    其中若贸然解析会产生【残缺记录】的: %d 个 -> 现已全部挡住\n",
         name,L,L+1,acc,rej,harm);
  /* 多行文件里,任何【记录边界】处的截断也以换行收尾 —— 看起来完整但少了后面的记录。
     所以换行判据只能保证"不会读到半条记录",保证不了"读到了全部记录"。
     真正的防线是 agent 侧的原子发布(写临时文件再改名),读者只会看到旧文件或新文件。
     这里断言的是换行判据确实做到了它能做到的那一半。 */
  for(int cut=0;cut<=L;cut++){
    char buf[4096]; memcpy(buf,full,cut); buf[cut]=0;
    if(!complete(buf,cut)) continue;
    const char* lastnl=strrchr(buf,'\n');
    if(!lastnl || lastnl[1]!=0){ printf("   FAIL %s: 接受的内容末尾有半条记录\n",name); fails++; }
  }
  printf("    被接受的 %d 个点全部落在记录边界(无半条记录)\n",acc);
}
int main(void){
  run("status_4512.txt",
      "#b1077\n"
      "Sam_x64.exe | Pro11.vst3  Key=C  Scale=Minor  Camelot=5A  Rtn=73%\x01" "18F23EE0 KSRHVA\n"
      "Sam_x64.exe | Waves Tune Real-Time Mono  Key=A  Scale=Chromatic  Spd=15%\x01" "1DC8DF90 KSRHV\n");
  run("scales_4512.txt",
      "[Pro11.vst3]\nChromatic\nMajor\nMinor\n"
      "[Waves Tune Real-Time Mono]\nChromatic\nMajor\nMinor\nDorian\n");
  printf("\n两道防线:\n"
        "  1) agent 原子发布(临时文件 + 改名)  -> 读者根本看不到半成品\n"
        "  2) 控制器要求以换行收尾              -> 兜住磁盘写满等仍可能的半截写入\n"
        "失败数: %d\n",fails);
  return fails?1:0;
}
