/* 状态行协议:agent 写 / 控制器读

   agent 写的格式是  "<宿主exe> | <标签>  Key=..  Scale=..[  Camelot=..][ 手感]\x01<id16进制> <能力>"
   控制器靠【两个空格】切出标签,所以标签里含单空格是正常的
   ("The T-Pain Effect"、"Waves Tune Real-Time Stereo" 都是)。

   这里用 agent 真实会输出的行,喂给从控制器源码提取的 parse_status_line,
   逐项核对标签、实例 id、能力串。覆盖本项目支持的全部插件形态。

   注意:字面量里的 \x01 必须用字符串拼接断开 —— C 的十六进制转义会贪婪吞掉
   后面的 hex 数字,"\x0112AB34CD" 会被当成一个超长转义而不是 \x01 后跟 "12AB34CD"。 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "t_pline_funcs.inc"

static int fails=0;
static void t(const char* desc,const char* raw,const char* wantLeaf,unsigned wantId,const char* wantCaps){
    char ln[512]; snprintf(ln,sizeof ln,"%s",raw);
    char leaf[96]="",label[160]=""; unsigned id=0; char caps[16]="";
    int ok=parse_status_line(ln,leaf,label,&id,caps);
    int good = ok && !strcmp(leaf,wantLeaf) && id==wantId && !strcmp(caps,wantCaps);
    printf("   %-26s leaf=%-28s id=%08X caps=%-7s %s\n",desc,leaf,id,caps,good?"OK":"FAIL");
    if(!good){ printf("       期望 leaf=%s id=%08X caps=%s (返回 %d)\n",wantLeaf,wantId,wantCaps,ok); fails++; }
}
int main(void){
    printf("== 各插件形态的真实状态行 ==\n");
    t("T-Pain VST2(效果名)",
      "Sam_x64.exe | The T-Pain Effect  Key=C  Scale=Major Pentatonic  Camelot=8B\x01" "12AB34CD KS",
      "The T-Pain Effect",0x12AB34CDu,"KS");
    t("T-Pain VST3(模块名)",
      "Sam_x64.exe | The T-Pain Effect.vst3  Key=C  Scale=Major Pentatonic  Camelot=8B\x01" "DEADBEEF KS",
      "The T-Pain Effect.vst3",0xDEADBEEFu,"KS");
    t("Waves Stereo 变体",
      "Sam_x64.exe | Waves Tune Real-Time Stereo  Key=F#  Scale=Major  Spd=30% Trn=20%\x01" "00ABCDEF KSRHV",
      "Waves Tune Real-Time Stereo",0x00ABCDEFu,"KSRHV");
    t("Auto-Tune(全能力)",
      "Sam_x64.exe | Auto-Tune Pro.vst3  Key=A  Scale=Minor\x01" "11112222 KSRHVA",
      "Auto-Tune Pro.vst3",0x11112222u,"KSRHVA");

    printf("\n== 占位符行:无元数据 -> 按老 agent 处理,默认全能力 ==\n");
    t("[[PENDING]]","Sam_x64.exe | The T-Pain Effect.dll  [[PENDING]]",
      "The T-Pain Effect.dll",0u,"KSRHVA");

    printf("\n== 边界 ==\n");
    t("Key/Scale 读不到","Sam_x64.exe | X.vst3  Key=?  Scale=?\x01" "00000001 KS","X.vst3",1u,"KS");
    t("标签紧跟两空格","Sam_x64.exe | A B C  Key=C  Scale=Major\x01" "00000002 KS","A B C",2u,"KS");

    printf("\n== 不该被接受的行 ==\n");
    { char ln[256]; char leaf[96],label[160],caps[16]; unsigned id;
      snprintf(ln,sizeof ln,"%s","没有分隔符的一行");
      int r=parse_status_line(ln,leaf,label,&id,caps);
      printf("   %-26s 返回 %d %s\n","缺少 ' | '",r,r==0?"OK":"FAIL"); if(r) fails++; }

    printf("\n== 最长的状态行(1158):各字段都取 agent 声明的上限 ==\n");
    { /* 宿主 95 + 插件 95 + 调 63 + 音阶 63 + Camelot 15 + 手感 127 + 元数据,约 510 字节 */
      char host[96],mod[96],kn[64],sn[64],cam[16],feel[128];
      memset(host,'H',95); host[95]=0; memset(mod,'M',95); mod[95]=0; memset(kn,'K',63); kn[63]=0;
      memset(sn,'S',63); sn[63]=0; memset(cam,'C',15); cam[15]=0; memset(feel,'F',127); feel[127]=0;
      static char line[1200];
      int L=snprintf(line,sizeof line,"%s | %s  Key=%s  Scale=%s%s%s%s\x01%08X %s",host,mod,kn,sn,"  Camelot=",cam,feel,0x1A2B3C4Du,"KSRV");
      char buf[1024], leaf[96], label[160], caps[16]; unsigned id=0;
      memcpy(buf,line,(size_t)L+1);
      int r=parse_status_line(buf,leaf,label,&id,caps);
      int ok = r==1 && id==0x1A2B3C4Du && strcmp(caps,"KSRV")==0 && strcmp(leaf,mod)==0;
      printf("   %-26s %d 字节,编号 %08X 能力 %s  %s\n","完整解析",L,id,caps,ok?"OK":"FAIL"); if(!ok) fails++;
      /* 原先控制器把每行截到 255 字节再解析:行尾的编号与能力标记丢了,被当成老版本 agent 的行 */
      memcpy(buf,line,255); buf[255]=0; id=0xFFFFFFFFu;
      r=parse_status_line(buf,leaf,label,&id,caps);
      int lost = (r==1 && id==0);
      printf("   %-26s 编号变成 %08X(0 = 这个插件的任意实例)%s\n","截到 255 字节时",id,lost?"—— 这正是要防的":"(?)");
      if(!lost) fails++; }

    printf("\n失败数: %d\n",fails);
    return fails?1:0;
}
