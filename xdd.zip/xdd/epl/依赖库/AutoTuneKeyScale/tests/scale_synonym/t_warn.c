/* 两个架构都必须零告警编译(1120)

   `inst_id` 里的 v>>32 在 32 位构建上是【未定义行为】:uintptr_t 只有 32 位,
   移位计数等于类型宽度。编译器对此只给一条告警,而那条告警在很长一段时间里
   被当成"既有噪音"过滤掉了。

   它一度无害 —— 这个编译器恰好把 v>>32 折成 0,于是 id == v,结果碰巧正确。
   但 x86 的移位指令是对计数【取模 32】的,那样 v>>32 == v,id 就成了 v^v == 0:
   32 位宿主里【每个实例的 id 都相同】。而 1119 起 id 承担了精确寻址的职责,
   届时「选中某一个实例」会静默失效,且没有任何征兆。

   所以这里不验证某段逻辑,而是验证一条纪律:默认告警级别下必须零告警。
   告警一旦被容忍,下一条真问题就会混在噪音里。 */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "t_warn_funcs.inc"

/* inst_id 直接取自源码(见 t_warn_funcs.inc)。本机指针为 64 位,所以这里验证的是
   64 位分支;32 位分支用同一份源码在编译期由 sizeof(uintptr_t) 选择,其正确性由
   "hi 恒为 0 -> id == 低 32 位" 这一点保证,下面单独断言该推论。 */
static unsigned id_of(unsigned long long addr){ return inst_id((const void*)(uintptr_t)addr); }

static int fails=0;
static void chk(const char* what,int ok){
    printf("   %-52s %s\n",what,ok?"OK":"FAIL"); if(!ok) fails++;
}
int main(void){
    printf("== 低位地址(等价于 32 位指针):不同实例必须得到不同 id ==\n");
    { uint32_t a[3]={0x02a50010u,0x02df0894u,0x17e27b28u};   /* 取自真机 32 位日志 */
      unsigned id[3];
      for(int i=0;i<3;i++) id[i]=id_of(a[i]);
      for(int i=0;i<3;i++) printf("   addr=%08X -> id=%08X\n",a[i],id[i]);
      chk("三个 id 互不相同", id[0]!=id[1] && id[1]!=id[2] && id[0]!=id[2]);
      chk("id 非全零",       id[0]&&id[1]&&id[2]); }

    printf("\n== 若 v>>32 被取模 32(x86 移位语义)会怎样 ==\n");
    { uint32_t v=0x02a50010u;
      unsigned broken = (unsigned)(v ^ v);   /* v>>32 == v>>0 == v */
      printf("   id 会变成 %08X —— 所有实例都一样\n",broken);
      chk("这正是必须消除的情形", broken==0); }

    printf("\n== 64 位:新写法必须与原结果完全一致 ==\n");
    { uint64_t b[3]={0x0000000013d27cb0ULL,0x00000000157f0ca0ULL,0x00007ffdbc748aa0ULL};
      unsigned want[3]={0x13d27cb0u,0x157f0ca0u,0xbc74f55du};  /* 实测的原实现输出 */
      int same=1;
      for(int i=0;i<3;i++){ unsigned got=id_of(b[i]);
          printf("   addr=%016llX -> id=%08X (原 %08X)\n",(unsigned long long)b[i],got,want[i]);
          if(got!=want[i]) same=0; }
      chk("64 位行为未改变", same); }

    printf("\n失败数: %d\n",fails);
    return fails?1:0;
}
