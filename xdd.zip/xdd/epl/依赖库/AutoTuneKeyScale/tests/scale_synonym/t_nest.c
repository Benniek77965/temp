/* 静态分析:守护区(setjmp(g_jb))内部不得再调用会 setjmp(g_jb) 的函数。
   直接读 at_agent.cpp 做调用图检查,源码一改这个测试就跟着变。 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static char src[600000];
static int body_of(const char* sig,int* s,int* e){
    char* p=strstr(src,sig); if(!p) return 0;
    char* b=strchr(p,'{'); if(!b) return 0;
    int d=0; char* q=b;
    for(;;){ if(*q=='{')d++; else if(*q=='}')d--; if(!d) break; q++; }
    *s=(int)(b-src); *e=(int)(q-src); return 1; }
static int has(const char* a,int s,int e){ char t[400]; snprintf(t,sizeof t,"%.*s",e-s,src+s); return strstr(t,a)!=NULL; }
static int body_has(int s,int e,const char* needle){
    for(int i=s;i<e-(int)strlen(needle);i++) if(!strncmp(src+i,needle,strlen(needle))) return 1; return 0; }
int main(void){
    FILE* f=fopen("../build/at_agent.cpp","r"); if(!f) f=fopen("at_agent.cpp","r");
    if(!f){ printf("找不到 at_agent.cpp —— 本套未验证任何东西,按失败处理\n"); return 1; }
    size_t n=fread(src,1,sizeof src-1,f); src[n]=0; fclose(f);
    /* 这些函数自己会 setjmp(g_jb) */
    const char* guards[]={"static void mod_of_ctrl(IEditController* c, char* out, int outsz){",
                          "static void discover_one(IEditController* c){",
                          "static int gp_str(IEditController* c, ParamID id, double val, char* out, int outsz){",
                          "static double gp_norm_safe(IEditController* c, ParamID id){",0};
    const char* gnames[]={"mod_of_ctrl","discover_one","gp_str","gp_norm_safe",0};
    /* 这些函数自身建立守护区,其内部不得再调上面任何一个 */
    const char* outer[]={"static int do_set_vst3_one(IEditController* c, int keySemi, const char* scaleName, double kv){",
                         "static int do_set_vst2_one(AEffect* e, const char* const* tbl, int keySemi, const char* scaleName, double kv){",0};
    const char* onames[]={"do_set_vst3_one","do_set_vst2_one",0};
    int fail=0;
    for(int o=0;outer[o];o++){
        int s,e; if(!body_of(outer[o],&s,&e)){ printf("  FAIL 找不到 %s —— 签名改了?这套守卫已失效\n",onames[o]); fail++; continue; }
        /* 只看 setjmp 之后的部分 */
        char* sj=NULL; for(int i=s;i<e-20;i++) if(!strncmp(src+i,"if(setjmp(g_jb)==0){",20)){ sj=src+i; s=i; break; }
        if(!sj){ printf("  FAIL %s 里没有 setjmp 守护区 —— 它本该有\n",onames[o]); fail++; continue; }
        printf("  %s 守护区内:\n",onames[o]);
        int bad=0;
        for(int g=0;gnames[g];g++){
            char call[64]; snprintf(call,sizeof call,"%s(",gnames[g]);
            if(body_has(s,e,call)){ printf("     FAIL 调用了会 setjmp(g_jb) 的 %s\n",gnames[g]); bad=1; fail++; } }
        /* 间接:write_scales_union / ctrl_module_is_antares 是否仍会调 mod_of_ctrl */
        for(int g=0; g<2; g++){
            const char* ind[]={"write_scales_union","ctrl_module_is_antares"};
            char call[64]; snprintf(call,sizeof call,"%s(",ind[g]);
            if(body_has(s,e,call)){
                char sig[128]; snprintf(sig,sizeof sig,"static %s %s(", g? "int":"void", ind[g]);
                int s2,e2; if(body_of(sig,&s2,&e2) && body_has(s2,e2,"mod_of_ctrl(")){
                    printf("     FAIL 间接经 %s 调到 mod_of_ctrl\n",ind[g]); bad=1; fail++; } } }
        if(!bad) printf("     OK 无嵌套守护\n");
    }
    printf("\n失败数: %d\n",fail); return fail?1:0;
}
