static int cmd_line_complete(const char* s){ int n=(int)strlen(s); return n>0 && s[n-1]=='\n'; }
