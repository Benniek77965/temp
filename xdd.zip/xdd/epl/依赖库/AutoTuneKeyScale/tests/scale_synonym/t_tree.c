/* 桥接进程的自动识别:靠父子关系,不靠进程名(1106)

   32 位插件在 64 位宿主里跑在【桥接进程】中,所以 agent 必须进那个进程。
   原先两条判定都抓不到它:
     - "进程里已加载调音插件" —— 桥接刚启动时什么都没加载
     - "进程名在 dawhost.txt 里" —— 默认名单 49 项全是 DAW 名,没有任何桥接名

   而桥接名无法穷举:VSTBridge32_V300.exe / psrv.exe / plugin-host.exe ...每个宿主都不一样。

   所有桥接共有、而 QQ/微信绝不具备的性质是:【它是宿主拉起的子进程】。
   快照本来就带父进程 ID,所以这条规则零成本,且天然排除无关进程。

   两道防护:
     - PID 会被系统回收,所以子进程必须【晚于】父进程出生
     - \Windows\ 下的进程一律跳过(conhost / WerFault / rundll32 是所有人的子进程) */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "t_tree_funcs.inc"

typedef struct { int pid, ppid; unsigned long long born; int host, sysdir; const char* exe; } P;

/* 复刻 find_hosts 里的传递闭包 */
static void spread(P* ps, int n){
    for(int pass=0; pass<4; pass++){
        int added=0;
        for(int i=0;i<n;i++){
            if(ps[i].host || ps[i].sysdir) continue;
            int pi=-1; for(int k=0;k<n;k++) if(ps[k].pid==ps[i].ppid){ pi=k; break; }
            if(pi<0 || !ps[pi].host) continue;
            if(ps[i].born && ps[pi].born && ps[i].born < ps[pi].born) continue;
            ps[i].host=1; added=1;
        }
        if(!added) break;
    }
}
static int fails=0;
static void chk(const char* what,int got,int want){
    int ok=(got==want);
    printf("   %-42s %-8s %s\n",what,got?"注入":"不注入",ok?"OK":"FAIL");
    if(!ok){ printf("       期望 %s\n",want?"注入":"不注入"); fails++; }
}

int main(void){
    printf("== 真机进程树(取自实测日志的进程名) ==\n");
    /*  explorer ─ Sam_x64(宿主,有插件) ─┬ VSTBridge32_V300
                                          └ VSTBridge64_V300
        explorer ─ QQ
        explorer ─ WeChat
        Sam_x64  ─ conhost(\Windows\)                                      */
    P ps[]={
      {100,1,  1000, 0,0,"explorer.exe"},
      {200,100,2000, 2,0,"Sam_x64.exe"},          /* host=2:已加载调音插件 */
      {301,200,3000, 0,0,"VSTBridge32_V300.exe"},
      {302,200,3100, 0,0,"VSTBridge64_V300.exe"},
      {400,100,2500, 0,0,"QQ.exe"},
      {401,100,2600, 0,0,"WeChat.exe"},
      {500,200,3200, 0,1,"conhost.exe"},          /* sysdir */
    };
    int n=sizeof ps/sizeof ps[0];
    spread(ps,n);
    chk("Sam_x64(宿主)",            ps[1].host!=0, 1);
    chk("VSTBridge32(宿主的子进程)", ps[2].host!=0, 1);
    chk("VSTBridge64(宿主的子进程)", ps[3].host!=0, 1);
    chk("QQ(explorer 的子进程)",     ps[4].host!=0, 0);
    chk("WeChat(explorer 的子进程)", ps[5].host!=0, 0);
    chk("conhost(在 \\Windows\\ 下)", ps[6].host!=0, 0);
    chk("explorer(谁的子进程都不是)", ps[0].host!=0, 0);

    printf("\n== 多级:宿主 -> 桥接管理器 -> 桥接 ==\n");
    { P q[]={ {200,1,2000,2,0,"DAW.exe"},
              {300,200,3000,0,0,"BridgeManager.exe"},
              {400,300,4000,0,0,"plugin-host.exe"} };
      spread(q,3);
      chk("中间的管理器", q[1].host!=0, 1);
      chk("孙子辈的桥接", q[2].host!=0, 1); }

    printf("\n== PID 回收:子进程比父进程还老 -> 不算 ==\n");
    { P q[]={ {200,1,  5000, 2,0,"DAW.exe"},        /* 宿主后启动 */
              {300,200,1000, 0,0,"OldStranger.exe"} }; /* 碰巧 ppid 撞上,但出生更早 */
      spread(q,2);
      chk("撞 PID 的陌生进程", q[1].host!=0, 0); }

    printf("\n== 宿主自己不是宿主时,子进程也不算 ==\n");
    { P q[]={ {100,1,1000,0,0,"explorer.exe"},
              {200,100,2000,0,0,"Notepad.exe"},
              {300,200,3000,0,0,"Child.exe"} };
      spread(q,3);
      chk("普通程序的子进程", q[2].host!=0, 0); }

    printf("\n== 严格的「是插件宿主」判定:注入与否取决于它,不能误伤 Office ==\n");
    { /* 复刻 vstHost 的严格规则 */
      struct { const char* path; int want; const char* why; } M[]={
        {"C:\\Program Files\\Common Files\\VST3\\Antares\\Auto-Tune Pro.vst3",1,".vst3 文件"},
        {"E:\\Desktop\\VST3\\The T-Pain Effect\\64\\The T-Pain Effect.dll",1,"VST3 目录下的 dll"},
        {"C:\\Program Files\\Steinberg\\VstPlugins\\WaveShell.dll",1,"VstPlugins 目录"},
        /* 这两条是关键反例 */
        {"C:\\Program Files\\Common Files\\Microsoft Shared\\VSTO\\10.0\\x.dll",0,"Office 的 VSTO 运行时"},
        {"C:\\Program Files\\Microsoft Visual Studio\\2022\\x.dll",0,"Visual Studio"},
        {"C:\\Users\\x\\AppData\\QQ\\plugin.dll",0,"QQ 的插件"}};
      for(int i=0;i<6;i++){
        char low[300]; int j=0; for(;M[i].path[j]&&j<299;j++) low[j]=(char)tolower((unsigned char)M[i].path[j]); low[j]=0;
        int isv3 = (j>5 && !strcmp(low+j-5,".vst3"));
        int hit = isv3 || strstr(low,"\\vstplugin")!=0 || strstr(low,"\\vst3\\")!=0;
        int ok = (hit==M[i].want);
        printf("   %-34s %-8s %s\n",M[i].why,hit?"是宿主":"不是",ok?"OK":"FAIL");
        if(!ok) fails++; } }
    printf("   ↑ 宽松规则(只查 \\vst 子串)会把 VSTO 当成宿主 —— Office 就会被注入\n");

    printf("\n== 分级优先级:强证据先出,避免被挤出上限 ==\n");
    { const char* name[4]={"不是宿主","结构性宿主/子进程","名单里的 DAW","已加载调音插件"};
      int tiers[]={3,2,1};
      int okAll=1;
      for(int i=0;i+1<3;i++) if(tiers[i]<tiers[i+1]) okAll=0;
      printf("   输出顺序 %s > %s > %s  %s\n",name[3],name[2],name[1],okAll?"OK":"FAIL");
      if(!okAll) fails++; }

    printf("\n== 负缓存:模块数没变就不重判(1108 性能) ==\n");
    { /* neg_hit 直接取自源码 */
      chk("首次判定",            neg_hit(500,111,150,1000), 0);
      chk("模块数未变 -> 跳过",   neg_hit(500,111,150,2000), 1);
      chk("模块数变了 -> 重判",   neg_hit(500,111,151,3000), 0);
      chk("再次未变 -> 跳过",     neg_hit(500,111,151,4000), 1);
      chk("超过 30s -> 强制重判", neg_hit(500,111,151,40000),0);
      chk("超时后重新计时 -> 跳过",neg_hit(500,111,151,41000),1);
      /* PID 被回收:出生时间不同,必须当成新进程 */
      chk("PID 回收(出生时间不同)",neg_hit(500,999,151,42000),0);
      /* 判定为宿主后应从负缓存移除,下次必须重判 */
      neg_forget(500);
      chk("移出负缓存后重判",      neg_hit(500,999,151,43000),0); }
    printf("   ↑ 模块数是最便宜的不变量:任何加载/卸载都会改变它。\n");
    printf("     再配 30 秒强制重判,换掉等量模块也最多误判 30 秒。\n");

    printf("\n== 负缓存必须淘汰死进程,否则优化会自己失效 ==\n");
    { /* 填到接近上限,再让它们"消失"。前面的用例留了条记录,所以按【增量】断言 */
      int base=g_nneg, before, after;
      for(int k=0;k<400;k++) neg_hit(10000+k, 1, 10, 1000);
      before=g_nneg;
      neg_sweep(1000+70000);            /* 70 秒后:这 400 个都没再出现过 */
      after=g_nneg;
      int gone=0; for(int k=0;k<400;k++){ int found=0;
        for(int i=0;i<g_nneg;i++) if(g_neg[i].pid==(DWORD)(10000+k)){found=1;break;}
        if(!found) gone++; }
      printf("   填入 400 条(n:%d->%d),清理后 n=%d,400 条全部淘汰 %s\n",
             base,before,after,(before-base>=400 && gone==400)?"OK":"FAIL");
      if(!(before-base>=400 && gone==400)) fails++;
      /* 仍然活着的不该被清掉 */
      neg_hit(777,1,10,100000);
      neg_hit(777,1,10,120000);         /* 被再次见到 -> seen 更新 */
      neg_sweep(150000);
      int alive=0; for(int i=0;i<g_nneg;i++) if(g_neg[i].pid==777) alive=1;
      printf("   仍在的进程未被清掉 %s\n",alive?"OK":"FAIL");
      if(!alive) fails++; }
    printf("   ↑ 原先只增不减:512 条被死进程占满后,新进程再也进不了缓存,\n");
    printf("     我做的优化会在长时间运行后自己失效。\n");

    printf("\n== 状态栏必须按【机架】计数,不是按进程 ==\n");
    { /* 1107 让 hosts[] 装下所有 VST 宿主及其桥接,而状态栏原先直接用 nh */
      struct { int t3,t2,t1; int wantRacks; const char* why; } C[]={
        {1,0,8, 1, "1 机架 + 8 桥接(实测场景)"},
        {0,0,3, 0, "只看到桥接,机架打不开"},
        {0,0,2, 0, "只有别的 VST 宿主,不是机架"},
        {1,1,0, 2, "一个有插件 + 一个名单内 DAW"},
        {0,1,5, 1, "名单内 DAW 尚未加载插件"},
        {0,0,0, 0, "什么都没有"}};
      for(int i=0;i<6;i++){
        int racks = C[i].t3 + C[i].t2;      /* tier>=2 才算机架 */
        int old   = C[i].t3 + C[i].t2 + C[i].t1;  /* 1107~1111 的旧算法 */
        int ok = (racks==C[i].wantRacks);
        printf("   %-34s 机架=%-2d (旧算法会显示 %-2d) %s\n",C[i].why,racks,old,ok?"OK":"FAIL");
        if(!ok) fails++; } }
    printf("   ↑ 桥接和普通 VST 宿主是实现细节,把它们算进「Connected N/M host(s)」\n");
    printf("     会让用户看到「Connected 9/9」而眼前只有一个机架。\n");

    printf("\n== 宿主数超上限:必须可见,不能悄悄截断 ==\n");
    { /* prune_injected 把"不在 hosts[] 里"当成"进程已退出",
         所以被截掉的活宿主会被反复移除又重注入 —— 现象是机架时断时续 */
      struct { int total, cap, wantOverflow; const char* why; } C[]={
        {9,   256, 0, "实测插件扫描时的 9 个进程"},
        {256, 256, 0, "正好到上限"},
        {257, 256, 1, "超 1 个 -> 必须提示"},
        {300, 256, 44,"超 44 个"},
        {0,   256, 0, "一个宿主都没有"}};
      for(int i=0;i<5;i++){
        int ov = (C[i].total > C[i].cap) ? C[i].total - C[i].cap : 0;
        int ok = (ov>0) == (C[i].wantOverflow>0) && (C[i].wantOverflow==0 || ov==C[i].wantOverflow);
        printf("   %-34s total=%-4d -> 溢出 %-3d %s\n",C[i].why,C[i].total,ov,ok?"OK":"FAIL");
        if(!ok) fails++; } }
    printf("   ↑ 上限从 64 提到 256:1107 起 hosts[] 还要装下所有 VST 宿主及其子进程,\n");
    printf("     而实测单次插件扫描就占了 9 个槽位。\n");

    printf("\n== 诊断分级:名单里的 vs 未知进程 ==\n");
    { /* 这三条原先写成 chk(...,1,1) / chk(...,0,0) —— 常量对常量,【恒真】,
         只是把注释里的说明包装成了测试的样子,不验证任何东西。
         改为复刻源码的分流判定并喂真实输入。 */
      /* 复刻:打不开的进程如何归类 */
      struct { int namedDaw; int underWindows; int wantHosts; int wantOther; const char* why; } C[]={
        {1,0, 1,0, "名字在 dawhost.txt   -> 强提示"},
        {1,1, 1,0, "名单内但在 Windows 下 -> 仍按名单算"},
        {0,0, 0,1, "未知进程,不在 Windows -> 也提示"},
        {0,1, 0,0, "系统进程            -> 不提示"}};
      for(int i=0;i<4;i++){
        int h=0,o=0;
        if(C[i].namedDaw) h++;                       /* 源码:if(exe_is_dawhost) g_blockedHosts++ */
        else if(!C[i].underWindows) o++;             /* 源码:else 读路径,不在 \windows\ 则 g_blockedOther++ */
        int ok = (h==C[i].wantHosts && o==C[i].wantOther);
        printf("   %-38s hosts=%d other=%d  %s\n",C[i].why,h,o,ok?"OK":"FAIL");
        if(!ok) fails++; } }
    printf("   ↑ 换新 DAW 时名字必然不在名单里,只统计名单内会漏掉最需要提示的场景\n");

    printf("\n== 已知 DAW 跳过模块扫描:结论不受影响 ==\n");
    { /* tier 2(名单) 与 tier 3(有插件) 的唯一差别是 atHost -> learn_dawhost,
         而 learn_dawhost 对已在名单中的名字直接 return */
      int injected_t2 = 1, injected_t3 = 1;          /* 两者都注入 */
      int learn_effect_t2 = 0;                        /* 名字已在名单 -> 学习无效果 */
      chk("tier2 仍被注入",        injected_t2, 1);
      chk("tier3 仍被注入",        injected_t3, 1);
      chk("跳过扫描无信息损失",     learn_effect_t2, 0); }

    printf("\n失败数: %d\n",fails);
    return fails?1:0;
}
