/* 1162:离开 exe 目录时,按「名字 + 内容」认出自己的文件。
   起因(Wine 下用 1161 实测):程序放在桌面时,用户自己的 status_report.txt、status_2024.txt、scales_notes.txt、
   status.txt、内容无关的 cmd.ini 几秒内全被删掉;agent 还把 pending_tasks.txt 当成崩溃标记,把第一行记进
   use_factory_hook.txt 后删除。迁移代码要在同一个目录里清理旧文件 —— 判定稍宽就会重犯同样的错。
   mig_classify / mig_name_candidate / pid_suffix / looks_module_path 由 extract.py 从控制器源码原样提取。 */
#include <stdio.h>
#include <stdlib.h>
#include "t_mig_funcs.inc"
static int fails=0;
/* 从 sig 起取到与之配对的右括号为止;找不到返回 0 */
static int body_of(const char* src, const char* sig, char* out, int cap){
    const char* p=strstr(src,sig); if(!p) return 0;
    const char* q=strchr(p,'{'); int d=0;
    for(;*q;q++){ if(*q=='{') d++; else if(*q=='}' && --d==0){ q++; break; } }
    int L=(int)(q-p); if(L>=cap) return 0;
    memcpy(out,p,(size_t)L); out[L]=0; return 1; }
static void ck(int ok,const char* m){ printf("   %s %s\n", ok?"OK  ":"FAIL", m); if(!ok) fails++; }
static int K(const char* name,const char* head,long size,unsigned long* pid){ unsigned long p=0; int k=mig_classify(name,head,size,&p); if(pid)*pid=p; return k; }
#define SZ(s) ((long)strlen(s))
int main(void){
    unsigned long pid=0;
    printf("== 一、自己的运行期文件:名字和内容都对才算 ==\n");
    { const char* st="#b1161\nCubase | Auto-Tune Pro  C  Major\n";
      ck(K("status_4512.txt",st,SZ(st),&pid)==MIG_RUNTIME && pid==4512, "status_<pid>.txt + 版本标记 -> 运行期文件,进程号 4512");
      ck(K("STATUS_4512.TXT",st,SZ(st),&pid)==MIG_RUNTIME, "大小写不同也认(Windows 文件名不分大小写)");
      const char* sc="[Auto-Tune Pro.vst3]\nMajor\nMinor\n";
      ck(K("scales_4512.txt",sc,SZ(sc),&pid)==MIG_RUNTIME && pid==4512, "scales_<pid>.txt + 段头 -> 运行期文件");
      ck(K("status_4512.txt.tmp","",0,&pid)==MIG_RUNTIME && pid==4512, "写到一半的 .tmp(空)-> 运行期文件");
      const char* cmd="key=7|scale=Major|t=123456\n";
      ck(K("cmd.ini",cmd,SZ(cmd),&pid)==MIG_RUNTIME && pid==0, "控制器写的 cmd.ini -> 运行期文件");
      const char* cmd2="retune=0.700|humanize=0.000|nvib=0.500|target=1:x|tid=0000ABCD|t=99\n";
      ck(K("cmd.ini",cmd2,SZ(cmd2),&pid)==MIG_RUNTIME, "只发手感三项的 cmd.ini 也认");
      ck(K("eject.flag","1\n",2,&pid)==MIG_RUNTIME, "eject.flag(\"1\\n\")-> 运行期文件"); }
    printf("\n== 二、名字像、内容不是:一律不碰(1161 会删掉的正是这些) ==\n");
    { ck(K("status_report.txt","my report\n",10,&pid)==MIG_NONE, "status_report.txt:后缀不是进程号");
      ck(K("status_2024.txt","keep me\n",8,&pid)==MIG_NONE, "status_2024.txt:后缀是数字,内容却没有版本标记");
      ck(K("status_2024.txt","",0,&pid)==MIG_NONE, "空的 status_2024.txt:我们的状态文件从不为空");
      ck(K("scales_notes.txt","notes\n",6,&pid)==MIG_NONE, "scales_notes.txt");
      ck(K("scales_12.txt","notes\n",6,&pid)==MIG_NONE, "scales_12.txt,内容不是段头");
      ck(K("status.txt","todo\n",5,&pid)==MIG_NONE, "status.txt(1161 每次启动按名字直接删)");
      ck(K("cmd.ini","[app]\nmode=1\n",13,&pid)==MIG_NONE, "别的程序的 cmd.ini");
      ck(K("cmd.ini","key=value\n",10,&pid)==MIG_NONE, "以 key= 开头、但没有 |t= 的 cmd.ini");
      ck(K("eject.flag","yes\n",4,&pid)==MIG_NONE, "内容不是 \"1\\n\" 的 eject.flag");
      ck(K("pending_tasks.txt","buy milk\n",9,&pid)==MIG_NONE, "pending_tasks.txt(1161 的 agent 会把它记成崩溃模块再删掉)");
      ck(K("pending_77.txt","buy milk\n",9,&pid)==MIG_NONE, "pending_77.txt,内容不是模块路径");
      ck(K("pending_77.txt","C:\\notes\\todo.txt\n",18,&pid)==MIG_NONE, "pending_77.txt,是路径但不是插件模块");
      ck(K("dawhost.txt","my hosts\n",9,&pid)==MIG_NONE, "不是我们写的 dawhost.txt");
      ck(K("agent.log","hello\n",6,&pid)==MIG_NONE, "不是我们写的 agent.log");
      ck(K("eject_on_close.flag","x",1,&pid)==MIG_NONE, "内容不对的 eject_on_close.flag");
      ck(K("status_0.txt","#b1161\n",7,&pid)==MIG_NONE, "进程号 0 不是进程");
      ck(K("status_99999999999.txt","#b1161\n",7,&pid)==MIG_NONE, "超过 32 位的进程号");
      ck(K("status_12a.txt","#b1161\n",7,&pid)==MIG_NONE, "后缀里夹着字母");
      ck(K("xstatus_12.txt","#b1161\n",7,&pid)==MIG_NONE, "前缀不在开头");
      ck(K("photo.jpg","\xff\xd8\xff",3,&pid)==MIG_NONE, "无关文件"); }
    printf("\n== 三、崩溃标记:空的照删,记着模块的要搬走(下一个 agent 照旧采纳) ==\n");
    { ck(K("pending_88.txt","",0,&pid)==MIG_PENDING && pid==88, "1161 留下的空标记");
      const char* mp="C:\\Program Files\\Common Files\\VST3\\Auto-Tune.vst3\n";
      ck(K("pending_88.txt",mp,SZ(mp),&pid)==MIG_PENDING, "记着 .vst3 路径的标记(崩溃证据)");
      const char* unc="\\\\nas\\plugins\\x.DLL";
      ck(K("pending_88.txt",unc,SZ(unc),&pid)==MIG_PENDING, "UNC 路径、大写扩展名的 .dll 也认"); }
    printf("\n== 四、状态、日志、模板与用户文件 ==\n");
    { const char* dh="# DAW exe-name fragments (whole-word...)\nsam\n";
      ck(K("dawhost.txt",dh,SZ(dh),&pid)==MIG_STATE, "dawhost.txt(带我们写的抬头)-> 搬过去");
      ck(K("use_factory_hook.txt","C:\\a\\b.vst3\n",12,&pid)==MIG_STATE, "use_factory_hook.txt -> 搬过去");
      ck(K("eject_on_close.flag","1\n",2,&pid)==MIG_STATE, "eject_on_close.flag -> 搬过去");
      const char* lg="[4512] +1.250 agent loaded in pid 4512\n";
      ck(K("agent.log",lg,SZ(lg),&pid)==MIG_LOG, "agent.log -> 搬过去,或接到新日志后面");
      const char* tpl="# scalemap.txt - scale synonym groups\r\r\n# Each line is one group\r\r\n#\r\r\n# Diminished|Diminished (W-H)\r\r\n# Add your own groups below:\r\r\n";
      ck(K("scalemap.txt",tpl,SZ(tpl),&pid)==MIG_TEMPLATE, "1161 写的纯注释模板(注释里有 | 也一样)-> 删掉");
      char tpl2[512]; snprintf(tpl2,sizeof tpl2,"%sDiminished|Diminished (W-H)\r\n",tpl);
      ck(K("scalemap.txt",tpl2,SZ(tpl2),&pid)==MIG_USER, "模板里加了一组 -> 用户文件,导入");
      ck(K("scalemap.txt",tpl,SZ(tpl)+5000,&pid)==MIG_USER, "文件比读到的长:不当成空模板");
      ck(K("scalemap.txt","Foo|Bar\n",8,&pid)==MIG_USER, "手写的 scalemap.txt -> 导入");
      const char* names[]={"noeat.txt","nouithread.txt","skip.txt","catch.txt","disabled.txt",NULL};
      for(int i=0;names[i];i++){ char w[96]; snprintf(w,sizeof w,"%s -> 用户文件(只复制、不删)",names[i]); ck(K(names[i],"",0,&pid)==MIG_USER,w); } }
    printf("\n== 五、只按名字预筛:与迁移无关的文件连打开都不打开 ==\n");
    { ck(mig_name_candidate("status_4512.txt") && mig_name_candidate("pending_1.txt") && mig_name_candidate("scales_9.txt.tmp")
         && mig_name_candidate("cmd.ini") && mig_name_candidate("Agent.log"), "自己的名字都在候选里");
      ck(!mig_name_candidate("status_report.txt") && !mig_name_candidate("photo.jpg") && !mig_name_candidate("AutoTune_KeyScale_Controller.exe")
         && !mig_name_candidate("pending_tasks.txt") && !mig_name_candidate("status.txt"), "无关文件不是候选");
      const char* all[]={"cmd.ini","eject.flag","eject_on_close.flag","dawhost.txt","use_factory_hook.txt","agent.log","scalemap.txt",
                         "noeat.txt","nouithread.txt","skip.txt","catch.txt","disabled.txt",NULL};
      int ok=1; for(int i=0;all[i];i++) if(!mig_name_candidate(all[i])) ok=0;
      ck(ok, "分类认得的每个固定名字,预筛都放行(预筛漏掉的文件永远不会被迁移)"); }
    printf("\n== 六、两份源码对数据目录名的约定一致 ==\n");
    { static char A[900000], C[600000]; FILE* f;
      f=fopen("../../combined/at_agent.cpp","rb"); size_t na=f?fread(A,1,sizeof A-1,f):0; if(f) fclose(f); A[na]=0;
      f=fopen("../../vst3/cpp/AutoTune_KeyScale_Controller.cpp","rb"); size_t nc=f?fread(C,1,sizeof C-1,f):0; if(f) fclose(f); C[nc]=0;
      if(!na || !nc){ printf("找不到源码 —— 本套未验证任何东西,按失败处理\n"); return 1; }
      const char* ka=strstr(A,"#define AT_DATA_SUBDIR "); const char* kc=strstr(C,"#define AT_DATA_SUBDIR ");
      char va[64]="", vc[64]="";
      if(ka) sscanf(ka+23,"%63s",va);
      if(kc) sscanf(kc+23,"%63s",vc);
      ck(ka && kc && va[0] && !strcmp(va,vc), "agent 找不到指针文件时的回退目录 == 控制器的数据目录");
      printf("      agent %s / 控制器 %s\n", va, vc);
      printf("\n== 八、两份源码里各有一份的工具函数必须逐字相同(1162) ==\n");
      /* 第五轮的 BOM 缺陷正是「两边对同一件事理解不同」:窗口去 BOM、agent 不去。这里防的是同一类事 ——
         只改了其中一份。按签名找到函数体,括号配对取出,逐字比较。 */
      const char* sigs[]={"static void drop_bom(char* s){","static int local_appdata_ansi(char* out, int cap){",NULL};
      for(int i=0;sigs[i];i++){ static char ba[4096], bc[4096]; int okA=body_of(A,sigs[i],ba,sizeof ba), okC=body_of(C,sigs[i],bc,sizeof bc);
          char w[160]; snprintf(w,sizeof w,"%.40s… 两份逐字相同",sigs[i]+12);
          ck(okA && okC && !strcmp(ba,bc), w); } }
    printf("\n失败数: %d\n",fails); return fails?1:0; }
