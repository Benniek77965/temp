/* 状态行协议:插件名由插件决定内容,不能让它破坏格式 */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "t_trim_funcs.inc"
static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)
static int has_ctrl(const char* s){ for(;*s;s++) if((unsigned char)*s<0x20) return 1; return 0; }
int main(void){
  printf("== 恶意/畸形插件名经 trim 之后,必须不含任何控制字符 ==\n");
  struct { const char* in; const char* what; } T[]={
    {"Waves Tune Real-Time Mono","正常名字"},
    {"Evil\nName","名字里带换行 -> 否则状态行被劈成两行"},
    {"Evil\x01""Name","名字里带 \\x01 -> 否则元数据边界错位,id/caps 解析错"},
    {"Tab\tInside","名字里带制表符"},
    {"  \r\n Padded \t ","首尾全是空白与换行"},
    {"\x01\x02\x03","全是控制字符"},
  };
  for(int i=0;i<6;i++){
    char b[128]; snprintf(b,sizeof b,"%s",T[i].in); trim(b);
    int ok=!has_ctrl(b);
    printf("   %-34s -> '%s'%s\n", T[i].what, b, ok?"":"   <<< 仍含控制字符");
    if(!ok) fails++;
  }
  CK(1,"以上全部净化");
  printf("\n== 实例 ID:只差高位的两个指针不能撞 ID ==\n");
  void* a=(void*)(uintptr_t)0x0000000011141258ULL;
  void* b=(void*)(uintptr_t)0x0000000711141258ULL;   /* 低32位完全相同 */
  printf("   %p -> %08X\n   %p -> %08X\n", a, inst_id(a), b, inst_id(b));
  CK(inst_id(a)!=inst_id(b), "低32位相同的两个对象拿到不同 ID");
  CK(inst_id(a)==inst_id(a), "同一指针 ID 稳定");
  printf("\n失败数: %d\n",fails); return fails?1:0;
}
