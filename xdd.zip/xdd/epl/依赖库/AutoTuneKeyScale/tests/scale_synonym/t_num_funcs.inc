static double parse_num(const char* s){
    if(!s) return -1;
    while(*s==' '||*s=='\t') s++;
    int neg=0; if(*s=='-'){ neg=1; s++; } else if(*s=='+') s++;
    double v=0; int any=0;
    while(*s>='0'&&*s<='9'){ v=v*10+(*s-'0'); s++; any=1; }
    if(*s=='.'){ s++; double f=0.1;
        while(*s>='0'&&*s<='9'){ v+=(*s-'0')*f; f*=0.1; s++; any=1; } }
    if(!any) return -1;
    return neg ? -v : v; }
static double clamp01(double v){ if(v<0) return -1; return v>1.0 ? 1.0 : v; }
