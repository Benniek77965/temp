/* The T-Pain Effect 的 VST2 位置映射(1095 新增)

   VST2 无法枚举离散参数的取值,所以和 Waves 一样要"借"一张位置表,按 i/(n-1) 写下去。
   写错一格就是唱错一个调,所以这里逐项核对:

   1. 12 个根音每一个都要落到正确的位置(靠 key_to_pc 匹配音高类,不是假设顺序)
   2. 6 个音阶名都能找到,且归一化值与真机 VST3 枚举出来的一致
   3. T-Pain 的表绝不能和 Waves 的表混用(两者长度/内容都不同)

   表与函数均直接取自 at_agent.cpp。 */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#define _stricmp strcasecmp
#define _strnicmp strncasecmp
#include "t_tpv2_funcs.inc"

static int fails=0;
static void chk(const char* what,int got,int want){
  int ok=(got==want);
  printf("   %-30s got=%-3d want=%-3d %s\n",what,got,want,ok?"OK":"FAIL");
  if(!ok) fails++;
}

/* 复刻 v2w_apply 里挑位置的那两段 */
static int root_pos(int keySemi,const char* const* R,int n){
  for(int i=0;i<n;i++) if(key_to_pc(R[i])==keySemi) return i;
  return -1; }
static int scale_pos(const char* want,const char* const* S,int n){
  for(int i=0;i<n;i++) if(!_stricmp(S[i],want)) return i;
  return -1; }

int main(void){
  printf("== T-Pain 根音:12 个音高类 -> 位置 ==\n");
  /* 这张表是 C=0 的半音序;T-Pain 的下拉正好也是这个顺序,所以位置==音高类 */
  const char* names[12]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
  for(int pc=0;pc<12;pc++){
    char lbl[32]; snprintf(lbl,sizeof lbl,"pc=%-2d (%s)",pc,names[pc]);
    chk(lbl,root_pos(pc,TPAIN_ROOTS,TPAIN_NROOT),pc);
  }

  printf("\n== T-Pain 音阶 -> 位置 + 归一化值(对照真机 VST3 枚举) ==\n");
  /* 真机日志: 'Major' -> idx 1 val 0.2000 ; 'Major Pentatonic' -> idx 3 val 0.6000 */
  struct { const char* n; int pos; double val; } S[]={
    {"Chromatic",0,0.0},{"Major",1,0.2},{"Minor",2,0.4},
    {"Major Pentatonic",3,0.6},{"Minor Pentatonic",4,0.8},{"Custom",5,1.0}};
  for(int i=0;i<6;i++){
    int p=scale_pos(S[i].n,TPAIN_SCALES,TPAIN_NSCALE);
    chk(S[i].n,p,S[i].pos);
    if(p>=0){
      double v=(double)p/(double)(TPAIN_NSCALE-1);
      int ok=(v>S[i].val-0.0005 && v<S[i].val+0.0005);
      printf("      归一化 %.4f (真机 %.4f) %s\n",v,S[i].val,ok?"OK":"FAIL");
      if(!ok) fails++;
    }
  }

  printf("\n== 根音归一化值:位置 i 写作 i/(n-1),n=12 ==\n");
  { double v7=(double)7/(double)(TPAIN_NROOT-1);   /* 真机 VST3: key 7 'G' -> 0.6364 */
    int ok=(v7>0.6359 && v7<0.6369);
    printf("   G(pc=7) -> %.4f (真机 VST3 为 0.6364) %s\n",v7,ok?"OK":"FAIL");
    if(!ok) fails++; }

  printf("\n== 两张表必须互不混用 ==\n");
  chk("TPAIN_NROOT",TPAIN_NROOT,12);
  chk("TPAIN_NSCALE",TPAIN_NSCALE,6);
  { /* Waves 的音阶名不应出现在 T-Pain 表里 */
    int bad=0;
    const char* wavesOnly[]={"Harmonic Minor","Melodic Minor","Blues","Whole Tone",0};
    for(int i=0;wavesOnly[i];i++) if(scale_pos(wavesOnly[i],TPAIN_SCALES,TPAIN_NSCALE)>=0) bad++;
    printf("   Waves 专有音阶混入 T-Pain 表: %d 个 %s\n",bad,bad?"FAIL":"OK");
    if(bad) fails++; }
  { /* T-Pain 没有的调式不能被误配 */
    int p=scale_pos("Dorian",TPAIN_SCALES,TPAIN_NSCALE);
    printf("   不存在的 'Dorian' -> %d (应为 -1,即不写入) %s\n",p,p<0?"OK":"FAIL");
    if(p>=0) fails++; }

  printf("\n== 无显示串时:写入位置 -> 读回数值 -> 反查名字(往返) ==\n");
  /* T-Pain 的 VST2 不提供 effGetParamDisplay,状态栏原先只能显示 "?" */
  for(int pos=0;pos<TPAIN_NROOT;pos++){
    double v=(double)pos/(double)(TPAIN_NROOT-1);      /* v2w_set_checked 写进去的值 */
    char out[64];
    v2_disc_name_t("",v,TPAIN_ROOTS,TPAIN_NROOT,out,sizeof out);
    int ok=!strcmp(out,TPAIN_ROOTS[pos]);
    printf("   根音位置 %-2d -> %.4f -> '%-3s' %s\n",pos,v,out,ok?"OK":"FAIL");
    if(!ok) fails++;
  }
  for(int pos=0;pos<TPAIN_NSCALE;pos++){
    double v=(double)pos/(double)(TPAIN_NSCALE-1);
    char out[64];
    v2_disc_name_t("",v,TPAIN_SCALES,TPAIN_NSCALE,out,sizeof out);
    int ok=!strcmp(out,TPAIN_SCALES[pos]);
    printf("   音阶位置 %-2d -> %.4f -> '%-18s' %s\n",pos,v,out,ok?"OK":"FAIL");
    if(!ok) fails++;
  }

  printf("\n== 有显示串时必须优先用插件自己的(不能被位置表覆盖) ==\n");
  { char out[64];
    v2_disc_name_t("Harmonic Minor",0.0,TPAIN_SCALES,TPAIN_NSCALE,out,sizeof out);
    int ok=!strcmp(out,"Harmonic Minor");
    printf("   插件给 'Harmonic Minor' -> '%s' %s\n",out,ok?"OK":"FAIL");
    if(!ok) fails++; }

  printf("\n== 边界与异常 ==\n");
  { char out[64]; int r;
    r=v2_disc_name_t("",-1.0,TPAIN_ROOTS,TPAIN_NROOT,out,sizeof out);
    printf("   读值失败(-1) -> 返回 %d,out='%s' %s\n",r,out,(r==0&&!out[0])?"OK":"FAIL");
    if(!(r==0&&!out[0])) fails++;
    r=v2_disc_name_t("",1.0,TPAIN_SCALES,TPAIN_NSCALE,out,sizeof out);
    printf("   上界 1.0 -> '%s' %s\n",out,!strcmp(out,"Custom")?"OK":"FAIL");
    if(strcmp(out,"Custom")) fails++;
    r=v2_disc_name_t("",2.0,TPAIN_SCALES,TPAIN_NSCALE,out,sizeof out);   /* 越界值不得越过表尾 */
    printf("   越界 2.0 被夹住 -> '%s' %s\n",out,!strcmp(out,"Custom")?"OK":"FAIL");
    if(strcmp(out,"Custom")) fails++;
    r=v2_disc_name_t("",0.0,NULL,0,out,sizeof out);
    printf("   无位置表 -> 返回 %d %s\n",r,r==0?"OK":"FAIL");
    if(r!=0) fails++; }

  printf("\n失败数: %d\n",fails);
  return fails?1:0;
}
