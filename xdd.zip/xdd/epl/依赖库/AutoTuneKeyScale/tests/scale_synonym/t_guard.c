/* 盲写兜底(id1/id2)的门控决策表 —— 复现当初写坏 Waves 的那条路径 */
#include <stdio.h>
#include <string.h>
static int blind_write_allowed(int haveS,int haveK,int isWaves,int antMod){
    if(haveS||haveK) return 0;                    /* 正常路径,根本不走兜底 */
    return (!isWaves && antMod);                  /* 修复后的门控 */
}
static int blind_write_old(int haveS,int haveK,int isWaves,int antMod){
    (void)antMod; if(haveS||haveK) return 0;
    return !isWaves;                              /* 修复前 */
}
int main(void){
  struct { const char* who; int S,K,W,A; int want; } T[]={
    {"电音11(Scale/Key 都找到)",      1,1,0,1, 0},
    {"Waves(Scale Type/Root 找到)",   1,1,1,0, 0},
    {"AT8.1 变体(找不到名字,是Antares)",0,0,0,1, 1},
    {"改名壳里的 Waves C6(非Antares)", 0,0,0,0, 0},
    {"catch.txt 加进来的未知插件",      0,0,0,0, 0},
    {"正常壳里的 Waves C6",            0,0,1,0, 0},
  };
  int fail=0, oldbad=0;
  printf("%-34s %-6s %-6s %s\n","场景","修复前","修复后","期望");
  for(int i=0;i<6;i++){
    int o=blind_write_old(T[i].S,T[i].K,T[i].W,T[i].A);
    int n=blind_write_allowed(T[i].S,T[i].K,T[i].W,T[i].A);
    printf("%-34s %-6s %-6s %s  %s\n",T[i].who,o?"会写":"不写",n?"会写":"不写",
           T[i].want?"会写":"不写", n==T[i].want?"OK":"FAIL");
    if(n!=T[i].want) fail++;
    if(o!=T[i].want) oldbad++;
  }
  printf("\n修复前有 %d 个场景判断错误;修复后 %d 个。\n",oldbad,fail);
  return fail?1:0;
}
