/* 下拉打开时不得重建;但跳过【不能】记录签名,否则关掉后就永远不重建了 */
#include <stdio.h>
#include <string.h>
static char g_sig[256]="";
static int dropped=0, rebuilds=0;
/* 复刻生产代码的顺序:比签名 -> 查下拉状态 -> 记签名 -> 重建 */
static void maybe_rebuild(const char* newsig){
  if(strcmp(newsig,g_sig)==0) return;          /* 内容没变 */
  if(dropped) return;                          /* 用户正在看 -> 跳过,且不记签名 */
  strncpy(g_sig,newsig,sizeof g_sig-1);
  rebuilds++;
}
static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)
int main(void){
  printf("== 1. 下拉关着:内容变了就重建,没变就不动 ==\n");
  maybe_rebuild("A"); CK(rebuilds==1,"首次重建");
  maybe_rebuild("A"); CK(rebuilds==1,"内容没变不重建");
  maybe_rebuild("B"); CK(rebuilds==2,"内容变了重建");

  printf("\n== 2. 下拉打开着:内容变了也不能动它 ==\n");
  dropped=1;
  maybe_rebuild("C"); CK(rebuilds==2,"打开期间不重建(列表不会在用户眼皮下被清空)");
  maybe_rebuild("D"); CK(rebuilds==2,"连续变化也不重建");

  printf("\n== 3. 关键:关掉之后必须补上 ==\n");
  dropped=0;
  maybe_rebuild("D"); CK(rebuilds==3,"关掉后的第一次轮询补上重建");
  printf("   (若跳过时记了签名,这里就会判定'没变'而永远不重建 —— 正是要避免的)\n");

  printf("\n== 4. 打开期间变回原值,则确实无需重建 ==\n");
  dropped=1; maybe_rebuild("X"); dropped=0;
  maybe_rebuild("D"); CK(rebuilds==3,"内容最终没变 -> 不做无谓重建");
  printf("\n失败数: %d\n",fails); return fails?1:0;
}
