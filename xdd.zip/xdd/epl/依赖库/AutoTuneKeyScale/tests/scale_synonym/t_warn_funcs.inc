/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
#include <stdint.h>
static unsigned inst_id(const void* p){
    uintptr_t v=(uintptr_t)p;
    unsigned lo=(unsigned)v;
    unsigned hi=(sizeof(uintptr_t)>4) ? (unsigned)(((unsigned long long)v)>>32) : 0u;
    return lo ^ hi; }
