/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
#define TPAIN_NSCALE 6
static const char* const TPAIN_SCALES[TPAIN_NSCALE] = {
    "Chromatic","Major","Minor","Major Pentatonic","Minor Pentatonic","Custom" };
#define TPAIN_NROOT 12
static const char* const TPAIN_ROOTS[TPAIN_NROOT] = {
    "C","C#","D","D#","E","F","F#","G","G#","A","A#","B" };
static int key_to_pc(const char* k){                 
    static const char* N2[10]={"C#","DB","D#","EB","F#","GB","G#","AB","A#","BB"}; static const int P2[10]={1,1,3,3,6,6,8,8,10,10};
    static const char* N1[7]={"C","D","E","F","G","A","B"}; static const int P1[7]={0,2,4,5,7,9,11};
    char u[8]=""; int j=0; for(int i=0;k[i]&&j<4;i++){ char ch=k[i]; u[j++]=(ch>='a'&&ch<='z')?(char)(ch-32):ch; } u[j]=0;
    for(int i=0;i<10;i++) if(strncmp(u,N2[i],2)==0) return P2[i];
    for(int i=0;i<7;i++) if(u[0]==N1[i][0]) return P1[i];
    return -1; }
static int v2_disc_name_t(const char* disp, double val, const char* const* tbl, int n, char* out, int outsz){
    out[0]=0;
    snprintf(out,outsz,"%s",disp?disp:"");
    if(out[0]) return 1;
    if(!tbl || n<2) return 0;
    double v=val; if(v<0) return 0;
    int pos=(int)(v*(double)(n-1)+0.5); if(pos<0) pos=0; if(pos>n-1) pos=n-1;
    snprintf(out,outsz,"%s",tbl[pos]); return 1; }
