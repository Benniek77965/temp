/* 命令文件里的数值:区域设置无关 + 范围钳位 */
#include <stdio.h>
#include <string.h>
#include <locale.h>
#include <stdlib.h>
#include "t_num_funcs.inc"
static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)
static int eq(double a,double b){ double d=a-b; return d<1e-9 && d>-1e-9; }
int main(void){
  printf("== 1. 正常解析 ==\n");
  CK(eq(parse_num("0.850"),0.85),  "0.850");
  CK(eq(parse_num("1.000"),1.0),   "1.000");
  CK(eq(parse_num("0.000"),0.0),   "0.000");
  CK(eq(parse_num("-1.000"),-1.0), "-1.000(表示\"不改\")");
  printf("\n== 2. 关键:宿主把区域设成逗号小数点时,仍必须解析正确 ==\n");
  {
    const char* loc = setlocale(LC_NUMERIC,"de_DE.UTF-8");
    if(!loc) loc = setlocale(LC_NUMERIC,"de_DE");
    if(loc){
      printf("   已切到 %s\n", loc);
      double a=atof("0.850"), o=parse_num("0.850");
      printf("   atof(\"0.850\")      = %.3f   <<< 被区域设置带偏\n", a);
      printf("   parse_num(\"0.850\") = %.3f\n", o);
      CK(!eq(a,0.85), "已复现:atof 在逗号区域下确实解析错");
      CK(eq(o,0.85),  "我们的解析不受影响");
      setlocale(LC_NUMERIC,"C");
    } else {
      /* 本机没装逗号区域。用镜像情形证明同一件事:C 区域下喂逗号写法,
         等价于逗号区域下喂点号写法 —— atof 都会在分隔符处停住。 */
      printf("   本机无逗号区域,改用【镜像情形】证明同一机制:\n");
      double a=atof("0,850");
      printf("   C 区域下 atof(\"0,850\") = %.3f  (在分隔符处停住,正是逗号区域下 atof(\"0.850\") 的遭遇)\n", a);
      CK(eq(a,0.0), "已复现 atof 的失败机制:遇到非本区域的小数点就停");
      CK(eq(parse_num("0.850"),0.85), "我们的解析只认 '.',与区域无关");
    }
  }
  printf("\n== 3. 畸形输入必须判为\"不改\"(-1),而不是乱给一个值 ==\n");
  CK(parse_num("")<0,        "空串");
  CK(parse_num("abc")<0,     "非数字");
  CK(parse_num("0,850")>=0 && eq(parse_num("0,850"),0.0), "逗号写法 -> 取到 0(不会变成 850)");
  printf("\n== 4. 钳位:协议规定 0..1 ==\n");
  CK(eq(clamp01(0.5),0.5),   "0.5 原样");
  CK(eq(clamp01(5.0),1.0),   "5.0 -> 钳到 1.0(否则会把超范围值喂给 setParamNormalized)");
  CK(clamp01(-1.0)<0,        "负值 -> -1(表示\"不改\")");
  CK(eq(clamp01(1.0),1.0),   "边界 1.0");
  printf("\n失败数: %d\n",fails); return fails?1:0;
}
