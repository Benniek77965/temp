/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
#define MAXINST 64
#define INSTSIG_SZ (MAXINST*120 + 64)
