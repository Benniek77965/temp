/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
static int rose(int* was, int now){ int r = (now && !*was); *was = now ? 1 : 0; return r; }
static int rec_append(char* buf, int cap, int* off, const char* fmt, ...){
    if(!buf || cap<=0 || *off<0 || *off>=cap) return 0;
    va_list ap; va_start(ap,fmt);
    int n=vsnprintf(buf+*off,(size_t)(cap-*off),fmt,ap);
    va_end(ap);
    if(n<0 || n>=cap-*off){ buf[*off]=0; return 0; }   /* did not fit: leave nothing of it behind */
    *off+=n; return 1; }
