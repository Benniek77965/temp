typedef struct { AEffect* e; uint32_t uid; int np;        /* identity fingerprint: see v2w_discover */
                 char name[96];                            /* effect name, used for BOTH display and targeting */
                 DWORD seen;                               /* last tick this object was still around */
                 int rootIdx, scaleIdx, speedIdx, transIdx, vibIdx; int isTuner; int announced; } V2W;
static int v2w_cache_valid(const V2W* w, uint32_t uid, int np){
    return w && w->uid==uid && w->np==np; }
