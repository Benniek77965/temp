/* 控制器用 fopen("w") 原地重写 cmd.txt,agent 每 100ms 轮询读取。
   把一条真实命令行在【每一个字节位置】截断,检查没有任何截断点会导致错误动作。 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "t_race_funcs.inc"
static int fails=0;
int main(void){
  const char* full="key=11|scale=Natural Minor|retune=0.850|humanize=0.200|nvib=0.700"
                   "|target=4512:Waves Tune Real-Time Stereo|tid=1114125F|t=123456789\n";
  int L=(int)strlen(full);
  printf("完整命令行长度 %d 字节(agent 缓冲 512,控制器 320)\n\n",L);
  int accepted=0, rejected=0, wrongkey=0;
  for(int cut=0; cut<=L; cut++){
    char buf[600]; memcpy(buf,full,cut); buf[cut]=0;
    int ok=cmd_line_complete(buf);
    if(ok){
      accepted++;
      /* 被接受的,必须就是完整行 */
      if(strcmp(buf,full)!=0){ printf("   FAIL 截断在 %d 却被当成完整行\n",cut); fails++; }
      /* 并且 key 必须解析成 11 */
      char* k=strstr(buf,"key="); int ks=k?atoi(k+4):-1;
      if(ks!=11){ printf("   FAIL 接受的行里 key=%d(应为11)\n",ks); fails++; }
    } else {
      rejected++;
      /* 被拒绝的若去解析,key 可能是 1 而不是 11 —— 正是必须避免的 */
      char* k=strstr(buf,"key="); int ks=k?atoi(k+4):-1;
      if(ks!=-1 && ks!=11) wrongkey++;
    }
  }
  printf("  截断点总数            : %d\n",L+1);
  printf("  被接受(即完整)       : %d\n",accepted);
  printf("  被拒绝(尚未写完)     : %d\n",rejected);
  printf("  其中若贸然解析会取到错误 key 的: %d 个 <- 这些现在全部被挡住\n",wrongkey);
  printf("\n  %s 只有恰好完整的那一个会被接受\n", accepted==1?"OK  ":"FAIL");
  if(accepted!=1) fails++;
  printf("  %s 错误 key 永远不会被写出去\n", wrongkey>0?"OK  ":"(本样本未触发)");
  printf("\n失败数: %d\n",fails); return fails?1:0;
}
