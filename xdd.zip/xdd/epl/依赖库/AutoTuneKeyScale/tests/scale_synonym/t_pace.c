/* 「能不能 patch 这个 controller 的 vtable」的判定(1100 修的问题)

   PACE 保护电音11 的 controller vtable,patch 它的任何方法都会崩。所以捕获时必须先判定
   模块是不是 Antares。1094 的做法是在捕获那一刻、从【宿主线程】去问,这有三个毛病:

     1. 判定链里的 mod_of_ctrl() 会 arm g_jb,而 veh() 只在 worker 线程恢复
        —— 既保护不了自己,又把 worker 的恢复点冲掉;
     2. 它读 g_at[],而 worker 可能正在往里追加;
     3. 捕获常常发生在模块登记【之前】。真机日志(1099)里:
            CAUGHT genuine controller ...        <- 第 12 行
            vst3 Auto-Tune module found ...      <- 第 15 行
        此时 g_at 里根本没有这个模块,遍历空表得到"不是 Antares",
        于是就会去 patch —— 对电音11 就是 patch 它 PACE 保护的 vtable。

   1100 改为:worker 挂工厂钩子时就把结论写进钩子表,宿主线程只读。
   且只有【确定不是 Antares】(0) 才 patch;-1(未确立)按 Antares 对待,
   即退回 1093 之前"完全不 patch"的保守行为。 */
#include <stdio.h>
#include <string.h>
#include "t_pace_funcs.inc"

/* ---- 复刻生产代码的两条判定 ---- */

/* 1100 的判定:只认钩子表里缓存的结论 */
static int may_patch_new(int fant){ return fant==0; }

/* 1094 的判定:捕获时现场去 g_at 里找,找不到就当作"不是 Antares" */
static int may_patch_old(const char* const* g_at_paths, int n, const char* leaf){
    for(int i=0;i<n;i++) if(!strcmp(g_at_paths[i],leaf)) return 0;  /* 找到->假设它是 Antares,不 patch */
    return 1;                                                       /* 没找到 -> 误判为"不是 Antares",去 patch */
}

static int fails=0;
static void chk(const char* what,int got,int want){
    int ok=(got==want);
    printf("   %-50s got=%d want=%d %s\n",what,got,want,ok?"OK":"FAIL");
    if(!ok) fails++;
}

int main(void){
    printf("== 1100:结论来自钩子表,三种状态 ==\n");
    chk("fant=0  确定不是 Antares -> patch",        may_patch_new(0), 1);
    chk("fant=1  确定是 Antares   -> 不 patch",      may_patch_new(1), 0);
    chk("fant=-1 未确立           -> 不 patch(保守)", may_patch_new(-1),0);

    printf("\n== 回归:1094 在「捕获先于登记」时会误 patch ==\n");
    { const char* empty[1]={0};
      /* 真机 1099 日志的时序:捕获时 g_at 还是空的 */
      chk("g_at 为空(捕获先于登记) -> 旧判定会去 patch",
          may_patch_old(empty,0,"dianyin11.vst3"), 1);
      const char* reg[]={"dianyin11.vst3"};
      chk("g_at 已登记 -> 旧判定才正确地不 patch",
          may_patch_old(reg,1,"dianyin11.vst3"), 0); }
    printf("   ↑ 同一个插件,结论随登记时机而变 —— 安全决策不能依赖竞态\n");

    printf("\n== 新判定不受登记时机影响 ==\n");
    { /* 钩子表的条目在工厂被挂钩时就写好了,而任何经过钩子的 createInstance
         必然发生在挂钩之后,所以读到的永远是确定值 */
      chk("电音11:worker 挂钩时已判定为 1 -> 恒不 patch", may_patch_new(1), 0);
      chk("T-Pain:worker 挂钩时已判定为 0 -> 恒 patch",   may_patch_new(0), 1); }

    printf("\n== 两份清单是分开的:EAT 与 vtable patch 各管各 ==\n");
    { struct { const char* path; int eat; int vtbl; const char* why; } C[]={
        {"C:\\...\\WaveShell1-VST3 17.1_x64.vst3", 1,1,"WaveShell:两项都清白"},
        {"C:\\...\\The T-Pain Effect.vst3",       1,1,"T-Pain:两项都清白"},
        {"C:\\...\\The T-Pain Effect.dll",        1,1,"T-Pain VST2:同上"},
        /* 这条是本次改动的要害:给 EAT,不给 vtable */
        {"C:\\...\\Auto-Tune Pro.vst3",           1,0,"Antares:只给 EAT,绝不 patch vtable"},
        /* 1150:电音9 给 EAT。此前不给的理由是"它在探测路径上工作良好"—— 探测它恰恰把机架弄崩了(1149),
           而真机日志证明它的 PACE 容忍工厂 vtable 被改写(与导出目录同属只读数据区)。vtable 仍绝不给。 */
        {"C:\\...\\Auto-Tune.vst3",               1,0,"电音9:1150 起给 EAT,仍不给 vtable"},
        {"C:\\...\\Auto-Tune_81.vst3",            0,0,"AT8.1:两项都不给"},
        /* 名字更长的 PACE 版本不得被 'auto-tune pro.vst3' 命中 */
        {"C:\\...\\Auto-Tune Pro 11.vst3",        0,0,"电音11(长名):两项都不给"},
        {"C:\\...\\dianyin11.vst3",               0,0,"电音11:两项都不给"},
        {"C:\\...\\SomeNewPlugin.vst3",           0,0,"未知模块:两项都不给"},
        /* 目录名不得污染判定 */
        {"C:\\T-Pain Pack\\Other.vst3",           0,0,"目录含 t-pain:仍不给"},
        {"C:/unix/style/Auto-Tune Pro.vst3",      1,0,"正斜杠也要正确取文件名"}};
      for(int i=0;i<11;i++){
        char m1[90],m2[90];
        snprintf(m1,sizeof m1,"%s [EAT]",C[i].why);
        snprintf(m2,sizeof m2,"%s [vtbl]",C[i].why);
        chk(m1, module_in(C[i].path,EAT_CLEARED),  C[i].eat);
        chk(m2, module_in(C[i].path,VTBL_CLEARED), C[i].vtbl); } }
    printf("   ↑ Antares 那条是关键:日志证明它不需要 handler 也能写入生效,\n");
    printf("     所以只给它省掉重加的那一项,绝不碰 PACE 保护的 controller vtable。\n");

    printf("\n== EAT 路径(宿主线程挂钩)必须【实算】而非假设 ==\n");
    printf("   两份清单拆开后,「装了 EAT」不再等于「可以 patch vtable」。\n");
    printf("   gpf_call 因此按 VTBL_CLEARED 实算,不能再硬编码 0。\n");
    { int antaresAnt = module_in("C:\\x\\Auto-Tune Pro.vst3",VTBL_CLEARED) ? 0 : 1;
      chk("Antares 走 EAT 路径时 ant 必须为 1(不 patch)", antaresAnt, 1);
      chk("-> 因此不 patch", may_patch_new(antaresAnt), 0);
      int wavesAnt = module_in("C:\\x\\WaveShell1-VST3 17.1_x64.vst3",VTBL_CLEARED) ? 0 : 1;
      chk("Waves 走 EAT 路径时 ant 为 0(可 patch)", wavesAnt, 0);
      chk("-> 因此 patch", may_patch_new(wavesAnt), 1); }

    printf("\n失败数: %d\n",fails);
    return fails?1:0;
}
