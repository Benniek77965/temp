/* VST2 Waves 的缓存身份校验:指针被回收时必须重新读取,否则会往错误的参数索引写 */
#include <stdio.h>
#include <string.h>
typedef struct AEffect AEffect;
typedef unsigned int uint32_t; typedef unsigned long DWORD;
#include "t_v2w_funcs.inc"
static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)
int main(void){
  V2W w; memset(&w,0,sizeof w);
  w.e=(AEffect*)0x1000; w.uid=0x4C564C4D; w.np=12; w.rootIdx=11; w.scaleIdx=10; w.isTuner=1;
  printf("== 缓存条目: Waves Tune Real-Time (uid=4C564C4D, 12 参数, Root=11 Scale=10) ==\n");
  CK( v2w_cache_valid(&w,0x4C564C4D,12), "同一个对象 -> 复用缓存");
  printf("\n== 指针被回收的几种情形,必须全部判为失效 ==\n");
  CK(!v2w_cache_valid(&w,0x43365F5F,12), "换成别的 Waves 插件(uid 变)-> 重新读取");
  CK(!v2w_cache_valid(&w,0x4C564C4D,30), "同 uid 但参数数变了 -> 重新读取");
  CK(!v2w_cache_valid(&w,0,0),           "探测出错(uid/np 读成 0)-> 重新读取");
  CK(!v2w_cache_valid(NULL,0x4C564C4D,12),"没有缓存条目 -> 重新读取");
  printf("\n== 为什么重要 ==\n");
  printf("   若误复用:新插件的参数 11/10 可能是别的东西,切调会写到错误参数上。\n");
  printf("   这正是之前在 Waves 上把 Note Transition / Link On-Off 写坏的同一类错误。\n");
  printf("\n失败数: %d\n",fails); return fails?1:0;
}
