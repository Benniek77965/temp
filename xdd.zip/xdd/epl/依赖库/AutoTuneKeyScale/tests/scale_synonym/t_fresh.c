/* 快照必须与源码同步(1122)

   本套测试的卖点是「直接从源码提取真实函数」,但提取长期是**手工**做的,
   生成出来的 *_funcs.inc 是静态快照。源码改了、快照没跟着改,测试就只是在
   验证一段早已不存在的旧代码。

   实测:把 at_agent.cpp 里的 inst_id 改成恒返回 0(足以让 1119 的精确寻址
   彻底失效),41 套测试【全部通过】。

   所以本套不验证任何业务逻辑,只验证一件事:
       extract.py --check 必须报告「所有快照与源码一致」。
   它一旦失败,说明有人改了源码却没重新提取 —— 此时其余测试给出的
   任何结论都不可信。 */
#include <stdio.h>
#include <stdlib.h>

int main(void){
    printf("== 快照与源码是否同步 ==\n");
    int rc = system("python3 extract.py --check > /tmp/t_fresh.out 2>&1");
    FILE* f=fopen("/tmp/t_fresh.out","r");
    if(f){ char ln[512]; while(fgets(ln,sizeof ln,f)) printf("   %s",ln); fclose(f); }
    if(rc!=0){
        printf("\n   >>> 快照已过期或提取失败。\n");
        printf("   >>> 请先运行:  python3 extract.py\n");
        printf("   >>> 在此之前,其余测试的结论都不可信。\n");
        printf("\n失败数: 1\n");
        return 1;
    }
    printf("\n失败数: 0\n");
    return 0;
}
