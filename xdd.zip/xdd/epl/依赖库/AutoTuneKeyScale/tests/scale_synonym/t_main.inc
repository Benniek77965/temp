#include "t_lists.inc"   /* 由真机日志生成,不再手打 */
/* 用两份真实清单做验证 */
static int findin(const char** L,const char* req){ char w[48]; norm(req,w,sizeof w);
  for(int i=0;L[i];i++){ char a[48]; norm(L[i],a,sizeof a); if(scale_same(a,w)) return i; } return -1; }
int main(void){
  int pass=0,fail=0;
  printf("== 1. 控制器发一个名字,两边都要命中 ==\n");
  const char* reqs[]={"Major","Minor","Natural Minor","Chromatic","Harmonic Minor","Dorian","Phrygian","Lydian","Mixolydian","Locrian","Major Pentatonic","Minor Pentatonic","Blues","Whole Tone","Jazz Melodic Minor","Melodic Minor (Asc)",0};
  for(int i=0;reqs[i];i++){ int a=findin(PRO,reqs[i]), b=findin(WAV,reqs[i]);
    int ok=(a>=0&&b>=0); ok?pass++:fail++;
    printf("  %-22s 电音11=%-24s Waves=%-24s %s\n", reqs[i],
      a>=0?PRO[a]:"(无)", b>=0?WAV[b]:"(无)", ok?"OK":"MISS"); }
  printf("\n== 2. 不该乱配的,必须仍然 MISS ==\n");
  const char* neg[][2]={{"Diminished","Waves 的 W-H/H-W 二选一不明确"},{"Pythagorean","电音11 没有"},{"Bebop","电音11 没有"},{0,0}};
  for(int i=0;neg[i][0];i++){ int a=findin(PRO,neg[i][0]), b=findin(WAV,neg[i][0]);
    int both=(a>=0&&b>=0); (!both)?pass++:fail++;
    printf("  %-14s 电音11=%-3s Waves=%-3s -> %s (%s)\n", neg[i][0], a>=0?"有":"无", b>=0?"有":"无",
      both?"FAIL 误配!":"OK 未误配", neg[i][1]); }
  printf("\n== 3. 下拉去重:同义项应合并成一条 ==\n");
  printf("  'Minor' 的规范名        -> %s\n", scale_canon("Minor"));
  printf("  'Natural Minor' 的规范名 -> %s\n", scale_canon("Natural Minor"));
  printf("  'Aeolian' 的规范名       -> %s\n", scale_canon("Aeolian"));
  printf("  'Dorian' 的规范名        -> %s (不在任何组,保持原名)\n", scale_canon("Dorian")?scale_canon("Dorian"):"(NULL)");
  /* 每个内置组的【每个成员】都要断言,不能只打印不判定。
     Aeolian 原先只被 printf 出来给人看、没进断言 —— 实测把源码内置组里的 Aeolian 删掉,
     这套测试照常通过。打印不是覆盖。 */
  { struct { const char* a; const char* b; const char* why; } EQ[]={
      {"Minor","Natural Minor","内置组 1"},
      {"Minor","Aeolian","内置组 1(此前漏断言)"},
      {"Major","Ionian","内置组 2"},
      {"Jazz Melodic Minor","Melodic Minor (Asc)","内置组 3"},
      {"Jazz Melodic Minor","Jazz Minor","内置组 3"},
      {"Jazz Melodic Minor","Melodic Minor","内置组 3"}};
    for(int i=0;i<6;i++){
      const char* ca=scale_canon(EQ[i].a); const char* cb=scale_canon(EQ[i].b);
      int ok = ca && cb && !strcmp(ca,cb);
      ok?pass++:fail++;
      printf("  %-22s = %-22s %-18s %s\n",EQ[i].a,EQ[i].b,EQ[i].why,ok?"OK":"FAIL"); } }
  /* 反面:不在任何组的音阶不得被并到一起 */
  { const char* cd=scale_canon("Dorian"); const char* cp=scale_canon("Phrygian");
    int ok = !(cd && cp && !strcmp(cd,cp));
    ok?pass++:fail++; printf("  %-22s != %-22s %-18s %s\n","Dorian","Phrygian","不该合并",ok?"OK":"FAIL"); }
  printf("\n结果: %d 通过, %d 失败\n", pass, fail);
  return fail?1:0;
}
