/* 状态文件与音阶文件的写入必须"整条写入、要么不写"(rec_append,1152 后)。
   控制器把最后一个字节不是 '\n' 的文件当作写到一半:音阶文件整个忽略,状态文件则保持原显示不更新 ——
   而 agent 每次发布的都是同样的字节,实例列表会一直冻结。旧写法 off += snprintf(...) 在记录放不下时,
   留下半条记录,并把 off 推过缓冲区末尾。本测试测的是从源码提取的 rec_append。 */
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "t_rec_funcs.inc"
static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)
int main(void){
  char b[32]; int off=0; b[0]=0;
  printf("== 1. 放得下就整条写入 ==\n");
  CK(rec_append(b,(int)sizeof b,&off,"%s\n","hello")==1 && off==6 && !strcmp(b,"hello\n"), "写入、off 前进、以 0 结尾");
  printf("\n== 2. 放不下就一个字节都不留 ==\n");
  { int o0=off; CK(rec_append(b,(int)sizeof b,&off,"%s\n","0123456789012345678901234567890")==0, "返回 0");
    CK(off==o0 && !strcmp(b,"hello\n"), "off 不变,缓冲区内容不变(没有半条记录)"); }
  printf("\n== 3. 边界:恰好放得下 / 差一个字节 ==\n");
  { char c[16]; int o=0; c[0]=0;
    CK(rec_append(c,16,&o,"%s","123456789012345")==1 && o==15, "15 字节 + 结尾 0 正好 16:放得下");
    int o2=0; c[0]=0;
    CK(rec_append(c,16,&o2,"%s","1234567890123456")==0 && o2==0 && c[0]==0, "16 字节放不下:不写");
    int o3=15; CK(rec_append(c,16,&o3,"%s","")==1 && o3==15, "空记录在末尾:写入 0 字节");
    int o4=16; CK(rec_append(c,16,&o4,"%s","x")==0 && o4==16, "off 已到末尾:不写、不越界"); }
  printf("\n== 4. 一直写到满:结果永远是完整的若干行 ==\n");
  { char f[1000]; int o=0; f[0]=0; int n=0;
    for(int i=0;i<500;i++){ char rec[200]; int L=10+(i*37)%180; memset(rec,'a'+(i%26),(size_t)L); rec[L]=0;
        if(!rec_append(f,(int)sizeof f,&o,"%s\n",rec)) break;
        n++; }
    CK(n>0 && o==(int)strlen(f), "off 与字符串长度一致");
    CK(f[o-1]=='\n', "以换行结尾 —— 控制器不会把它当作写到一半");
    int bad=0; char* p=f; while(*p){ char* nl=strchr(p,'\n'); if(!nl){ bad=1; break; } p=nl+1; }
    CK(!bad, "每一行都是完整的"); }
  printf("\n== 5. 持续性状况只在出现那一刻记一次(rose,1154)==\n");
  { int w=0;
    CK(rose(&w,0)==0, "一直没有:不记");
    CK(rose(&w,1)==1, "出现:记一次");
    CK(rose(&w,1)==0 && rose(&w,1)==0, "持续:不再记(原先每轮扫描记一次,约每 2 秒一行)");
    CK(rose(&w,0)==0, "消失:不记");
    CK(rose(&w,1)==1, "再次出现:再记一次"); }
  printf("\n失败数: %d\n",fails); return fails?1:0; }
