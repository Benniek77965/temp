/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
static int liveness_decide(int* rel, int* strike, unsigned n){
    if(n==0) return 1;                       /* calling into it faulted: it is gone */
    if(*rel < 0){ *rel = (n>=3) ? 1 : 0; *strike=0; return 0; }
    if(*rel != 1) return 0;                  /* counts unusable -> never auto-drop */
    if(n<=2){ if(++(*strike) >= 3) return 1; return 0; }
    *strike = 0; return 0; }
static int waves_probe_decide(int isWaves, int hasHandler, int rel, unsigned n){
    if(!isWaves || hasHandler) return 0;
    if(rel >= 0) return 0;                   /* first reading only; after that the normal rules apply */
    return (n>=1 && n<=2) ? 1 : 0; }
