/* 端到端接缝测试:每个部件都各自通过了测试,但【部件之间的接缝】从没对照检查过。
   链路:agent 写状态行 -> 控制器解析 -> 控制器写 target/tid -> agent 匹配。
   四种插件形态各走一遍,断言"选中第 k 个就只命中第 k 个"。 */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
typedef unsigned long DWORD;
typedef char TUID[16];
static unsigned long g_testPid=4512;
#define GetCurrentProcessId() g_testPid
static int at_lower(int c){ return (c>='A'&&c<='Z')?c+32:c; }
static int _stricmp(const char* a,const char* b){
    for(;;){ int x=at_lower((unsigned char)*a),y=at_lower((unsigned char)*b);
             if(x!=y) return x-y; if(!x) return 0; a++; b++; } }
static DWORD g_targetPid=0; static unsigned g_targetId=0; static char g_targetLeaf[96]="";
#include "t_seam_agent.inc"
#include "t_seam_ctl.inc"
static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)

/* 四个实例:VST3电音11 / VST3 Waves / VST2 Waves / VST2 Antares,其中两个同名 */
typedef struct { const char* name; void* obj; } Inst;
int main(void){
  Inst inst[4] = {
    {"Pro11.vst3",                (void*)(unsigned long long)0x0000000018F23EE0ULL},
    {"Waves Tune Real-Time Mono",  (void*)(unsigned long long)0x000000001131CF38ULL},
    {"Waves Tune Real-Time Mono",  (void*)(unsigned long long)0x0000000711141258ULL},  /* 同名,另一个实例 */
    {"dianyin5.dll",               (void*)(unsigned long long)0x000000000CBD0F20ULL},
  };
  const char* caps[4]={"KSRHVA","KSRHV","KSRHV","KSRHVA"};
  unsigned long pid=4512;

  /* ---- 1) agent 侧:按真实格式写状态行 ---- */
  char status[4][256];
  for(int i=0;i<4;i++)
    snprintf(status[i],sizeof status[i],"Sam_x64.exe | %s  Key=C  Scale=Minor\x01%08X %s",
             inst[i].name, inst_id(inst[i].obj), caps[i]);

  /* ---- 2) 控制器侧:解析 ---- */
  char leaf[4][96], label[4][160], pcaps[4][16]; unsigned pid_id[4];
  printf("== 控制器解析 agent 写出的状态行 ==\n");
  for(int i=0;i<4;i++){
    char ln[256]; snprintf(ln,sizeof ln,"%s",status[i]);
    int ok=parse_status_line(ln, leaf[i], label[i], &pid_id[i], pcaps[i]);
    printf("   [%d] leaf='%s' id=%08X caps=%s\n", i, leaf[i], pid_id[i], pcaps[i]);
    if(!ok){ printf("   FAIL 第 %d 条没解析出来\n",i); fails++; }
    if(strcmp(leaf[i],inst[i].name)){ printf("   FAIL 第 %d 条名字对不上\n",i); fails++; }
    if(pid_id[i]!=inst_id(inst[i].obj)){ printf("   FAIL 第 %d 条 id 对不上\n",i); fails++; }
    if(strcmp(pcaps[i],caps[i])){ printf("   FAIL 第 %d 条能力位对不上\n",i); fails++; }
  }

  printf("\n== 选中每个实例,必须【只】命中它自己 ==\n");
  for(int k=0;k<4;k++){
    char cmd[320];
    snprintf(cmd,sizeof cmd,"key=0|scale=Minor|target=%lu:%s|tid=%08X|t=123\n",
             pid, leaf[k], pid_id[k]);
    parse_target(cmd);
    int hits=0, hitIdx=-1;
    for(int i=0;i<4;i++){
      /* agent 侧用进程内的真实指针与显示名比对 */
      if(g_targetPid && g_targetPid!=pid) continue;
      if(target_ok_obj(inst[i].obj, inst[i].name)){ hits++; hitIdx=i; }
    }
    printf("   选中[%d] %-26s -> 命中 %d 个 (第 %d 个)%s\n",
           k, leaf[k], hits, hitIdx, (hits==1&&hitIdx==k)?"":"   <<<");
    if(!(hits==1 && hitIdx==k)){ fails++; }
  }

  printf("\n== 不选(全部)时必须全部命中 ==\n");
  { char cmd[]="key=0|scale=Minor|t=123\n"; parse_target(cmd);
    int hits=0; for(int i=0;i<4;i++) if(target_ok_obj(inst[i].obj, inst[i].name)) hits++;
    CK(hits==4,"未指定 target 时四个实例全部生效"); }

  printf("\n== 两个同名实例必须靠 id 分开(这是旧版做不到的)==\n");
  CK(strcmp(leaf[1],leaf[2])==0, "它们的显示名确实相同");
  CK(pid_id[1]!=pid_id[2],       "但 id 不同");

  printf("\n失败数: %d\n",fails); return fails?1:0;
}
