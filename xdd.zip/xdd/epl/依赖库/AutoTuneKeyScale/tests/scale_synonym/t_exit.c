/* 退出等待用的截止时间算法:GetTickCount 是 32 位,每 ~49.7 天回绕。
   注意 Windows 上 DWORD 是 32 位,所以这里必须用 uint32_t 才能复现回绕。 */
#include <stdio.h>
#include <stdint.h>
typedef uint32_t DWORD;            /* 与 Windows 一致的 32 位 */
static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)
/* 生产代码用的判据 */
static int expired(DWORD deadline, DWORD now){ return (int32_t)(deadline-now) <= 0; }
/* 朴素写法,用来对照 */
static int naive(DWORD deadline, DWORD now){ return deadline <= now; }
int main(void){
  printf("sizeof(DWORD)=%zu 字节(必须是 4,否则测不到回绕)\n\n",sizeof(DWORD));
  if(sizeof(DWORD)!=4){ printf("FAIL 类型宽度不对\n"); return 1; }
  printf("== 正常区间 ==\n");
  CK(!expired(5000,1000),  "还剩 4 秒 -> 未到期");
  CK( expired(1000,5000),  "已过 4 秒 -> 到期");
  CK( expired(1000,1000),  "正好到点 -> 到期");
  printf("\n== 回绕边界 ==\n");
  DWORD now=0xFFFFF000u, deadline=(DWORD)(now+5000);
  printf("   now=%08X  deadline=%08X  <- 确实回绕了\n",now,deadline);
  CK(deadline < now, "deadline 数值上小于 now(回绕已发生)");
  CK(!expired(deadline,now),                  "我们的判据:未到期 ✓");
  CK( naive(deadline,now),                    "朴素判据:立刻误判超时 <- 这就是要避免的");
  CK(!expired(deadline,(DWORD)(now+4000)),    "过 4 秒仍未到期");
  CK( expired(deadline,(DWORD)(now+5000)),    "满 5 秒到期");
  CK( expired(deadline,(DWORD)(now+6000)),    "超过后到期");
  printf("\n结论:关控制器时若恰逢 tick 回绕,朴素写法会把 5 秒等待变成 0 秒,\n"
         "      扫描线程来不及收尾就进了 CRT 拆解期。\n失败数: %d\n",fails);
  return fails?1:0;
}
