/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
static int compute_scale_list(int ti, char out[][64], int maxn){
    int no=0;
    int scoped = (ti>0 && ti-1<g_ninst);
    if(scoped){
        for(int i=0;i<g_nsg;i++)
            if(g_sg[i].pid==g_insts[ti-1].pid && _stricmp(g_sg[i].leaf,g_insts[ti-1].leaf)==0){
                for(int j=0;j<g_sg[i].n && no<maxn;j++) strcpy(out[no++],g_sg[i].nm[j]);
                break; }
    } else if(g_nsg>0){
        for(int j=0;j<g_sg[0].n && no<maxn;j++){
            int all=1;
            for(int i=1;i<g_nsg && all;i++){ int found=0;
                for(int k=0;k<g_sg[i].n;k++) if(_stricmp(g_sg[i].nm[k],g_sg[0].nm[j])==0){ found=1; break; }
                all=found; }
            if(all) strcpy(out[no++],g_sg[0].nm[j]); }
        if(no==0)                                  /* no common ground -> union, never an empty control */
            for(int i=0;i<g_nsg;i++) for(int j=0;j<g_sg[i].n && no<maxn;j++){
                int dup=0; for(int k=0;k<no;k++) if(_stricmp(out[k],g_sg[i].nm[j])==0){dup=1;break;}
                if(!dup) strcpy(out[no++],g_sg[i].nm[j]); }
    }
    return no;
}
static void parse_scales_buffer(unsigned long pid, char* buf){
    int cur=-1; char* p=buf;
    while(*p){ if(g_nsgBuild>=MAXSG){ /* g_sgFull: 测试里不关心 */ break; }
        char* nl=strchr(p,'\n'); if(nl)*nl=0;
        int L=(int)strlen(p); while(L>0&&(p[L-1]=='\r'||p[L-1]==' ')) p[--L]=0;
        if(p[0]=='['){ char* e=strchr(p,']');
            if(e){ *e=0; cur=g_nsgBuild; g_sg[cur].pid=pid; snprintf(g_sg[cur].leaf,96,"%s",p+1); g_sg[cur].n=0; g_nsgBuild++; } }
        else if(p[0]){ if(cur<0){ cur=g_nsgBuild; g_sg[cur].pid=pid; g_sg[cur].leaf[0]=0; g_sg[cur].n=0; g_nsgBuild++; }  /* headerless = older agent */
                       if(g_sg[cur].n<MAXSN) snprintf(g_sg[cur].nm[g_sg[cur].n++],64,"%s",p); }
        if(!nl) break; p=nl+1; }
}
