/* Headless instance identity capacity, using current production constants.
   The controller no longer aggregates display text. Its bounded instance set
   still computes pid:id:leaf| identities; test maximum 32-bit PID, 32-bit ID,
   and the actual 95-character leaf limit for every supported instance. */
#include <stdio.h>
#include <string.h>
#include "t_e2e_funcs.inc"

static int fails=0;
static void check_capacity(int count){
    char identity[INSTSIG_SZ];
    char leaf[96];memset(leaf,'x',sizeof leaf-1);leaf[sizeof leaf-1]=0;
    int offset=0;
    for(int i=0;i<count;i++){
        int wrote=snprintf(identity+offset,sizeof identity-(size_t)offset,
            "%lu:%08X:%s|",4294967295UL,0xFFFFFFFFU,leaf);
        if(wrote<0 || (size_t)wrote>=sizeof identity-(size_t)offset){
            printf("FAIL instance %d identity buffer overflow\n",i);fails++;return;}
        offset+=wrote;
    }
    if((size_t)offset>=sizeof identity || strlen(identity)!=(size_t)offset)fails++;
    printf("instance identities %d/%d: %d bytes in %d\n",count,MAXINST,offset,INSTSIG_SZ);
}
int main(void){
    if(MAXINST<1 || INSTSIG_SZ<MAXINST*116+1){printf("FAIL maximum identity bound\n");fails++;}
    check_capacity(1);check_capacity(MAXINST);
    printf("failures: %d\n",fails);return fails?1:0;
}
