/* 同一组数组必须用同一个尺寸常量(1131)

   被同一个计数器索引的几个数组,尺寸必须来自同一个常量。
   有一个写成字面量就会埋下这种雷:

     static void* g_hookedVtbl[MAXVT];     <- 跟着常量走
     static char  g_hookedLeaf[8][96];     <- 写死 8

   平时相安无事(MAXVT 本来就是 8)。1130 把 MAXVT 提到 32 来支持多版本 Waves 壳共存,
   于是 g_nHooked 可以到 32,而 g_hookedLeaf 还只有 8 格 ——
   写第 9 个起就【越界 96 字节】,正好踩进紧随其后的 g_modMap(宿主线程读写的表)。
   触发条件恰恰就是那次扩容想支持的场景。

   编译器不会报任何错。所以这里按计数器分组,核对每组的尺寸常量是否一致。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char* slurp(const char* p){
    FILE* f=fopen(p,"rb"); if(!f) return NULL;
    fseek(f,0,SEEK_END); long n=ftell(f); fseek(f,0,SEEK_SET);
    char* b=(char*)malloc(n+1); if(!b){fclose(f);return NULL;}
    size_t rd=fread(b,1,n,f); b[rd]=0; fclose(f); return b;
}
/* 取 "名字[" 之后到 ']' 之间的内容 */
/* 片段 frag 之前最近的一个 "[N]" 里的 N(用于 "char buf[16384]; size_t n=fread(buf..." 这类写法,1159) */
static int num_before(const char* src, const char* frag){
    const char* q=strstr(src,frag); if(!q) return -1;
    const char* r=q; while(r>src && *r!='[') r--; if(*r!='[') return -1;
    return atoi(r+1); }
static int num_after(const char* src, const char* frag){
    const char* q=strstr(src,frag); return q? atoi(q+strlen(frag)) : -1; }
/* write_status 函数体里,名为 nm 的数组声明的最大尺寸(1158) */
static int max_decl(const char* body, const char* nm){
    int best=-1; size_t L=strlen(nm);
    for(const char* q=body; (q=strstr(q,nm))!=NULL; q+=L){
        char prev = (q>body)? q[-1] : ' ';
        if((prev>='a'&&prev<='z')||(prev>='A'&&prev<='Z')||(prev>='0'&&prev<='9')||prev=='_'||prev=='>') continue;
        if(q[L]!='[') continue;
        int v=atoi(q+L+1); if(v>best) best=v; }
    return best; }
static int size_of(const char* src,const char* arr,char* out,int outsz){
    char pat[64]; snprintf(pat,sizeof pat,"%s[",arr);
    const char* p=strstr(src,pat); if(!p) return 0;
    p+=strlen(pat); int i=0;
    while(*p && *p!=']' && i<outsz-1) out[i++]=*p++;
    out[i]=0; return 1;
}
static int fails=0;
static void group(const char* src,const char* counter,const char* const* arrs){
    char first[64]=""; int ok=1; char line[400]=""; int o=0;
    for(int i=0;arrs[i];i++){
        char sz[64]="?";
        if(!size_of(src,arrs[i],sz,sizeof sz)){ o+=snprintf(line+o,sizeof line-o,"%s=? ",arrs[i]); continue; }
        o+=snprintf(line+o,sizeof line-o,"%s=%s ",arrs[i],sz);
        if(!first[0]) snprintf(first,sizeof first,"%s",sz);
        else if(strcmp(first,sz)!=0) ok=0;
    }
    printf("   %-12s %-56s %s\n",counter,line,ok?"一致":"**不一致**");
    if(!ok){ printf("       同一计数器索引的数组尺寸不同 -> 扩容时会越界写。\n"); fails++; }
}
int main(void){
    char* a=slurp("at_agent.cpp");
    if(!a){ printf("   读不到 at_agent.cpp\n\n失败数: 1\n"); return 1; }
    printf("== 按计数器分组核对尺寸常量 ==\n");
    { const char* g[]={"g_hookedVtbl","g_hookedOrig","g_hookedLeaf","g_hookedAnt",0}; group(a,"g_nHooked",g); }
    /* 这一组实际有五个数组:原来只列了三个,g_ihShell / g_ihWaves 一直没被核对(1145 补)。 */
    { const char* g[]={"g_ihVtbl","g_ihOrig","g_ihLeaf","g_ihShell","g_ihWaves",0};   group(a,"g_nIH",g); }
    { const char* g[]={"g_chVtbl","g_chOrig",0};                                      group(a,"g_nCH",g); }
    { const char* g[]={"g_antPath","g_antVal",0};                                     group(a,"g_nAnt",g); }
    { const char* g[]={"g_caught","g_caughtRel","g_caughtStrike",0};                  group(a,"g_ncaught",g); }
    /* g_chTid 是 1144 加进这一组的:它和 g_chCtrl / g_chHandler 由同一个 g_nChMap 索引,
       chmap_del() 也要跟着一起左移。漏掉它就正是这条测试想防的那类雷。 */
    { const char* g[]={"g_chCtrl","g_chHandler","g_chTid",0};                        group(a,"g_nChMap",g); }
    { const char* g[]={"g_v2","g_v2tbl","g_v2uid","g_v2np",0};                        group(a,"g_nv2",g); }
    { const char* g[]={"g_inObj","g_inName",0};                                       group(a,"g_nIn",g); }
    /* 1145 补:按计数器机械扫了一遍源码,这两组此前完全没有核对。 */
    { const char* g[]={"g_gfMod","g_gfPtr",0};                                       group(a,"g_nGf",g); }
    { const char* g[]={"g_grpCnt","g_grpDisp","g_grpN",0};                           group(a,"g_nGrp",g); }
    printf("\n== 同一组数组在删除时必须【一起】左移(1145) ==\n");
    { /* 尺寸一致只挡住了越界。另一半同样会出事:chmap_del() 删掉一项后要把这一组的每个数组
         都左移,漏掉一个就让它和同组其余数组错位 —— 对 g_chTid 来说,错位的后果是
         uitid_of() 返回别的插件的线程号,写入被投递到错误的界面线程,表现是"又不跟了",
         而且没有任何日志。编译器不会报错,尺寸检查也看不见。 */
      const char* need[]={"g_chCtrl[k]=g_chCtrl[k+1]","g_chHandler[k]=g_chHandler[k+1]","g_chTid[k]=g_chTid[k+1]",0};
      char* f=strstr(a,"static void chmap_del(");
      if(!f){ printf("   **找不到 chmap_del —— 签名改了?这条守卫已失效**\n"); fails++; }
      else{ char* b=strchr(f,'{'); int d=0; char* q=b;
            for(;;){ if(*q=='{')d++; else if(*q=='}')d--; if(!d) break; q++; }
            char sv=*q; *q=0;
            for(int i=0;need[i];i++){
                int ok=strstr(f,need[i])!=NULL;
                printf("   chmap_del 左移 %-34s %s\n", need[i], ok?"有":"**漏**");
                if(!ok) fails++; }
            *q=sv; } }

    printf("\n== 控制器:音阶段必须派生自实例上限 ==\n");
    { char* c=slurp("AutoTune_KeyScale_Controller.cpp");
      if(c){
        int sigDerived = strstr(c,"#define INSTSIG_SZ (MAXINST*120")!=NULL;
        printf("   %-44s %s\n","实例签名缓冲由 MAXINST 派生",sigDerived?"是":"**不是**");
        if(!sigDerived){ printf("       写死 6000 只够约 50 个实例,再往后的增删不会改变签名,\n"
                                "       Target 下拉就不重建 —— 插件增删了却不显示。\n"); fails++; }
        free(c); } }

    printf("\n== 缓冲与它的「上次内容」副本必须同源 ==\n");
    { /* 副本比缓冲小的话,strncpy 会截断,比较永远不等 -> 每轮重写文件 */
      struct { const char* what; const char* frag; } P[]={
        {"状态缓冲与副本同源","char buf[STATUS_BUF]"},
        {"状态副本用同一常量","g_statusWritten[STATUS_BUF]"},
        {"音阶缓冲与副本同源","char buf[SCALES_BUF]"},
        {"音阶副本用同一常量","g_scalesWritten[SCALES_BUF]"}};
      for(int i=0;i<4;i++){
        int ok = strstr(a,P[i].frag)!=NULL;
        printf("   %-44s %s\n",P[i].what,ok?"是":"**不是**");
        if(!ok) fails++; } }

    printf("\n== 无界面控制器:实例数组必须共享同一上限 ==\n");
    { char* c=slurp("AutoTune_KeyScale_Controller.cpp");
      if(!c){ printf("找不到控制器源码\n");fails++; }
      else{
        int bounded=strstr(c,"g_insts[MAXINST]")!=NULL &&
                    strstr(c,"static StatusInstance tmp[MAXINST]")!=NULL &&
                    strstr(c,"if(ti<MAXINST)")!=NULL;
        printf("   后台实例容量与写入边界 %s\n",bounded?"OK":"FAIL");
        if(!bounded)fails++;
        free(c); } }

    printf("\n== 控制器逐行解析缓冲须容得下 agent 的最长状态行(1158) ==\n");
    { char* c=slurp("AutoTune_KeyScale_Controller.cpp");
      const char* ws=strstr(a,"static void write_status(){"); const char* we=ws?strstr(ws+10,"\nstatic "):NULL;
      if(!c || !ws || !we){ printf("   找不到 write_status 或控制器源码\n"); fails++; }
      else{
        int bl=(int)(we-ws); char* body=(char*)malloc((size_t)bl+1); memcpy(body,ws,(size_t)bl); body[bl]=0;
        const char* pl=strstr(a,"static char g_procLeaf["); int host = pl? atoi(pl+23) : -1;
        int mod=max_decl(body,"mod"), lf=max_decl(body,"lf"), kn=max_decl(body,"kn"), sn=max_decl(body,"sn"),
            cam=max_decl(body,"cam"), feel=max_decl(body,"feel"), caps=max_decl(body,"caps");
        int plug = mod>lf? mod: lf;
        int ok = host>0 && plug>0 && kn>0 && sn>0 && cam>0 && feel>0 && caps>0;
        /* 固定文字:" | "  "  Key="  "  Scale="  "  Camelot="  "\x01"  "%08X"  " "  = 3+6+8+10+1+8+1 */
        int maxline = ok ? (host-1)+(plug-1)+(kn-1)+(sn-1)+(cam-1)+(feel-1)+(caps-1)+37 : -1;
        const char* pd=strstr(c,"#define STATUS_LINE_PARSE "); int parse = pd? atoi(pd+26) : -1;
        int uses = strstr(c,"char ln[STATUS_LINE_PARSE]")!=NULL;
        printf("   agent 最长一行(由声明算出)%d 字节;控制器解析缓冲 %d 字节;解析处用该常量:%s\n",maxline,parse,uses?"是":"**不是**");
        int good = ok && parse>0 && uses && parse-1 >= maxline;
        printf("   %-44s %s\n","解析缓冲容得下最长一行",good?"是":"**不是**");
        if(!good){ printf("       行尾是实例编号与能力标记;截掉它,控制器会把它当成老版本 agent 的行(编号 0 =\n"
                          "       \"这个插件的任意实例\"),对其中一个实例的写入会落到同名插件的所有实例上。\n"); fails++; }
        free(body); }
      if(c) free(c); }

    printf("\n== 跨进程通道:读的一方容得下写的一方的最大内容(1159) ==\n");
    { /* 这三条通道原先靠两边各写一个数字、恰好对得上;没有任何东西把它们绑在一起。
         状态与音阶文件读不全,控制器会当作写到一半:状态 -> 显示冻结,音阶 -> 整个忽略。
         命令行读不全,行尾的 |tid= 被截掉 -> 逐实例控制悄悄失效(agent 源码里记着的真实事故)。 */
      char* c=slurp("AutoTune_KeyScale_Controller.cpp");
      if(!c){ printf("   找不到控制器源码\n"); fails++; }
      else{
        struct { const char* what; int writer; int reader; } X[2];
        const char* readStatus=strstr(c,"static void read_status(){");
        const char* writeGoal=strstr(c,"static void companion_write_goal(int keyScale){");
        const char* worker=strstr(a,"static DWORD WINAPI worker(");
        X[0].what="状态文件 agent -> 控制器整文件缓冲"; X[0].writer=num_after(a,"#define STATUS_BUF "); X[0].reader=readStatus?num_after(readStatus,"static char b["):-1;
        X[1].what="命令行 控制器 -> agent 读入缓冲"; X[1].writer=writeGoal?num_after(writeGoal,"char line["):-1; X[1].reader=worker?num_after(worker,"char line["):-1;
        /* Headless controller no longer reads scale dropdown files. */
        for(int i=0;i<2;i++){
            int ok=X[i].writer>0 && X[i].reader>0 && X[i].reader>=X[i].writer;
            printf("   %s 写 %d / 读 %d %s\n",X[i].what,X[i].writer,X[i].reader,ok?"OK":"FAIL");
            if(!ok)fails++; }
        free(c); } }

    printf("\n== 这几组不得使用字面量尺寸 ==\n");
    { const char* lit[]={"g_hookedLeaf[8]","g_ihLeaf[8]","g_antPath[8]","g_inObj[64]",0};
      for(int i=0;lit[i];i++){
        int bad = strstr(a,lit[i])!=NULL;
        printf("   %-24s %s\n",lit[i],bad?"**写死了**":"没写死");
        if(bad) fails++; } }
    printf("\n失败数: %d\n",fails);
    free(a); return fails?1:0;
}
