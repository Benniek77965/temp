#include <stdio.h>
#include <string.h>
#define _stricmp strcasecmp
static struct { unsigned long pid; char leaf[96]; char label[160]; unsigned id; char caps[16]; } g_insts[64];
static int g_ninst=0; static int g_testTarget=0;
#include "t_caps.inc"
int main(void){
  int fail=0; char eff[16];
  /* 真机实测能力位: 电音11 有 Retune/Humanize/NatVib/AudioType; Waves 有 Speed/Trans/Vib,无 AudioType */
  g_ninst=2;
  g_insts[0].pid=1; strcpy(g_insts[0].leaf,"电音11.vst3");              g_insts[0].id=0xAAAA; strcpy(g_insts[0].caps,"KSRHVA");
  g_insts[1].pid=1; strcpy(g_insts[1].leaf,"Waves Tune Real-Time Mono"); g_insts[1].id=0xBBBB; strcpy(g_insts[1].caps,"KSRHV");
  #define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fail++;} }while(0)
  g_testTarget=0; caps_effective(eff);
  printf("[Target=全部]    有效控件 = %s\n",eff);
  CK(strcmp(eff,"KSRHV")==0, "全部模式自动去掉 A(AudioType)——Waves 不支持,置灰而不是静默无效");
  g_testTarget=1; caps_effective(eff);
  printf("[Target=电音11]  有效控件 = %s\n",eff);
  CK(strcmp(eff,"KSRHVA")==0,"选中电音11 时 AudioType 恢复可用");
  g_testTarget=2; caps_effective(eff);
  printf("[Target=Waves]   有效控件 = %s\n",eff);
  CK(strcmp(eff,"KSRHV")==0, "选中 Waves 时 AudioType 保持置灰");
  /* 只挂一个插件不该缩水 */
  g_ninst=1; strcpy(g_insts[0].caps,"KSRHVA"); g_testTarget=0; caps_effective(eff);
  CK(strcmp(eff,"KSRHVA")==0,"只挂电音11 时全部模式 = 它的全部能力(不缩水)");
  printf("\n失败数: %d\n",fail); return fail?1:0;
}
