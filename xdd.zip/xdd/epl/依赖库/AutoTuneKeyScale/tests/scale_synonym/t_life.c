#include <stdio.h>
#include "t_life_funcs.inc"
int main(void){
  int fail=0;
  #define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fail++;} }while(0)
  /* 场景1:宿主持有引用(正常存活)-> 永不误删 */
  { int rel=-1,st=0,dropped=0;
    for(int i=0;i<20;i++) if(liveness_decide(&rel,&st,3)) dropped=1;
    CK(rel==1 && !dropped, "存活实例(计数=3)连续 20 轮不会被误删,且计数判定为可用"); }
  /* 场景2:宿主释放后 -> 3 次后剔除,不是立刻 */
  { int rel=-1,st=0; liveness_decide(&rel,&st,3);          /* 先建立可用性 */
    int d1=liveness_decide(&rel,&st,2), d2=liveness_decide(&rel,&st,2), d3=liveness_decide(&rel,&st,2);
    CK(!d1 && !d2 && d3, "宿主释放后需连续 3 次才剔除(约6秒,避免抖动误判)"); }
  /* 场景3:抖动一次后恢复 -> 不剔除,计数清零 */
  { int rel=-1,st=0; liveness_decide(&rel,&st,3);
    liveness_decide(&rel,&st,2); liveness_decide(&rel,&st,2);
    int back=liveness_decide(&rel,&st,5);
    int d=0; for(int i=0;i<2;i++) if(liveness_decide(&rel,&st,2)) d=1;
    CK(!back && !d && st==2, "中途恢复会把计数清零,不会累积到误删"); }
  /* 场景4(关键):只有我们持有引用的控制器 -> 判定为不可用,永不自动剔除 */
  { int rel=-1,st=0,dropped=0;
    for(int i=0;i<50;i++) if(liveness_decide(&rel,&st,2)) dropped=1;
    CK(rel==0 && !dropped, "若首次读数<3(计数不可区分),标记不可用并永不自动剔除 —— 防止把 Waves 误删"); }
  /* 场景5:探测出错 -> 立即剔除 */
  { int rel=1,st=0; CK(liveness_decide(&rel,&st,0), "探测本身出错(对象已失效)-> 立即剔除"); }

  /* ---- 1145:Waves 探测实例(waves_probe_decide) ----
     LiveProfessor 2 插入插件前会先建、再销毁两个同类实例(组件对象地址都相同)。
     agent 首次读计数时宿主早已释放,只剩我们的引用 -> 场景 4 判为"不可用、永不剔除"。
     结果是它们一直留在实例表里,每条命令都被写入错误的值。
     新判定引入第二个独立信号:宿主是否给过它 IComponentHandler。
     九份真机日志里,活着的 Waves 实例全部有 handler,探测实例一个都没有。 */
  printf("\n== Waves 探测实例(1145) ==\n");
  /* 场景6:探测实例本身 */
  CK(waves_probe_decide(1,0,-1,2)==1, "Waves + 宿主从未装 handler + 首次读数只剩我们的引用 -> 判为探测实例,丢弃");
  /* 场景7(关键):场景 4 当初保护的对象 —— 活着但计数只读得到 2 的 Waves —— 仍然受保护 */
  { CK(waves_probe_decide(1,1,-1,2)==0, "有 handler 的 Waves 即使首次读数 =2 也不按探测实例丢弃");
    int rel=-1,st=0,dropped=0;
    for(int i=0;i<50;i++){
        if(waves_probe_decide(1,1,rel,2)) dropped=1;            /* 与 drop_dead_instances 相同的判定顺序 */
        else if(liveness_decide(&rel,&st,2)) dropped=1; }
    CK(rel==0 && !dropped, "按生产代码的判定顺序连读 50 轮:有 handler、计数恒为 2 的 Waves 永不剔除(场景 4 的保护不变)"); }
  /* 场景8:handler 来得晚的活实例 —— 宿主仍持有引用,计数 >=3 */
  CK(waves_probe_decide(1,0,-1,3)==0, "无 handler 但首次读数 >=3(宿主仍持有)-> 不丢,handler 晚到的活实例受保护");
  /* 场景9:Antares 设计上就没有 handler,绝不能被这条判定误伤 */
  CK(waves_probe_decide(0,0,-1,2)==0, "非 Waves(如 Antares,设计上不挂 handler)、首次读数 =2 -> 本条一律不管");
  /* 场景10:只看首次读数;已判定过的实例交给原有规则 */
  CK(waves_probe_decide(1,0,0,2)==0 && waves_probe_decide(1,0,1,2)==0, "已判定过可用性(rel=0/1)后,本条不再介入");
  /* 场景11:探测出错留给 liveness_decide 立即剔除,本条不重复处理 */
  { int rel=-1,st=0;
    CK(waves_probe_decide(1,0,-1,0)==0 && liveness_decide(&rel,&st,0)==1, "n==0(探测出错)由 liveness_decide 立即剔除,本条不介入"); }

  printf("\n失败数: %d\n",fail); return fail?1:0;
}
