/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
static void LOG(const char* f,...){ (void)f; }
#define fopen_retry(p,m) fopen(p,m)   /* 重试只针对 Windows 的共享冲突,这里用普通 fopen */
static int at_lower(int c){ return (c>=65&&c<=90)?c+32:c; }
static void trim(char* s){ int n=(int)strlen(s);
    for(int k=0;k<n;k++) if((unsigned char)s[k] < 0x20) s[k]=' ';
    while(n>0 && (s[n-1]==' '||s[n-1]=='\t')) s[--n]=0;
    int i=0; while(s[i]==' '||s[i]=='\t') i++; if(i) memmove(s,s+i,(size_t)(n-i+1)); }
static int norm(const char* in,char* out,int n){int j=0;for(int i=0;in[i]&&j<n-1;i++){char c=in[i];
    if(c==' '||c=='.'||c=='('||c==')'||c=='&'||c=='-'||c=='\t'||c=='\'')continue; out[j++]=(char)tolower((unsigned char)c);} out[j]=0; return j;}
#define MAXGRP 24
#define MAXMEM 8
static char g_grpN[MAXGRP][MAXMEM][48]; static char g_grpDisp[MAXGRP][48];
static int g_grpCnt[MAXGRP]; static int g_nGrp=0; static int g_grpLoaded=0;
static char g_scalemapPath[260]="";
static int grp_add_line(const char* line){
    if(!line||!line[0]||line[0]=='#') return -1;
    if(g_nGrp>=MAXGRP) return 0;
    char buf[256]; snprintf(buf,sizeof buf,"%s",line);
    int m=0, haveDisp=0, extra=0; char* p=buf;
    while(*p){ char* bar=strchr(p,'|'); if(bar)*bar=0; trim(p);
        if(p[0]){
            if(m>=MAXMEM) extra++;        /* 别名超限也要说一声:少一个别名 = 那个插件的音阶名匹配不上 */
            else { if(!haveDisp){ snprintf(g_grpDisp[g_nGrp],48,"%s",p); haveDisp=1; }
                   norm(p,g_grpN[g_nGrp][m],48); m++; } }
        if(!bar) break; p=bar+1; }
    if(extra) LOG("WARN: scalemap.txt: '%s' has %d alias(es) past the %d-per-group limit -- "
                  "those names will not match",g_grpDisp[g_nGrp],extra,MAXMEM);
    if(m<2) return -1;              /* 一行至少要有「规范名|别名」两项才构成一组 */
    g_grpCnt[g_nGrp]=m; g_nGrp++; return 1; }
static void drop_bom(char* s){ if((unsigned char)s[0]==0xEF && (unsigned char)s[1]==0xBB && (unsigned char)s[2]==0xBF) memmove(s,s+3,strlen(s+3)+1); }
static void load_scalemap(){
    g_grpLoaded=1; g_nGrp=0;
    /* Built-in groups. Only equivalences that are unambiguous are enabled here:
         Minor = Natural Minor = Aeolian                    (same 7 notes, no reading in which they differ)
         Jazz Melodic Minor = Melodic Minor (Asc)           (the jazz form IS the ascending form used both ways)
       Deliberately NOT included: Auto-Tune "Diminished" vs Waves "Diminished (W-H)/(H-W)" -- a bare
       "Diminished" does not say which of the two octatonic forms it is, and guessing would silently
       select the wrong note set. Add it to scalemap.txt yourself once you have A/B'd it. */
    static const char* DEF[]={ "Minor|Natural Minor|Aeolian",
                               "Major|Ionian",
                               "Jazz Melodic Minor|Melodic Minor (Asc)|Jazz Minor|Melodic Minor", NULL };
    for(int i=0;DEF[i];i++) (void)grp_add_line(DEF[i]);   /* 内置组先加,所以永远挤不掉 */
    FILE* f=fopen_retry(g_scalemapPath,"r");
    if(f){ char line[256]; int added=0, full=0, malformed=0, first=1;
        while(fgets(line,sizeof line,f)){ if(first){ first=0; drop_bom(line); } int L=(int)strlen(line);
            while(L>0&&(line[L-1]=='\n'||line[L-1]=='\r')) line[--L]=0;
            int i=0; while(line[i]==' '||line[i]=='\t') i++;
            if(!line[i] || line[i]=='#') continue;
            int r=grp_add_line(line+i);
            if(r==1) added++; else if(r==0) full++; else malformed++; }
        fclose(f);
        if(added)     LOG("scalemap.txt: %d synonym group(s) added",added);
        if(full)      LOG("WARN: scalemap.txt: %d line(s) dropped, the table is full (%d groups max)",full,MAXGRP);
        if(malformed) LOG("WARN: scalemap.txt: %d line(s) ignored -- a group needs at least "
                          "\"Canonical|Alias\" on one line",malformed); } }
static int grp_of(const char* nm){ if(!g_grpLoaded) load_scalemap();
    if(!nm||!nm[0]) return -1;
    for(int g=0;g<g_nGrp;g++) for(int m=0;m<g_grpCnt[g];m++) if(!strcmp(g_grpN[g][m],nm)) return g;
    return -1; }
static int scale_same(const char* aNorm, const char* bNorm){
    if(!strcmp(aNorm,bNorm)) return 1;
    int ga=grp_of(aNorm); return (ga>=0 && ga==grp_of(bNorm)); }
static const char* scale_canon(const char* disp){ char n[48]; norm(disp,n,sizeof n);
    int g=grp_of(n); return (g>=0)? g_grpDisp[g] : NULL; }
