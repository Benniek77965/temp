/* EAT 导出表解析:直接驱动源码里的 eat_find_slot(1123 改为提取)

   这段代码跑在【加载器锁】里,改写模块导出表中的一个 DWORD。它必须在任何
   畸形头部下都"放弃"而不是出错 —— 一次越界读就是宿主崩溃。

   先前这套测试【复刻】了判定逻辑,于是源码被改坏时它照样通过:变异测试里
   删掉 1101 加的「导出目录至少 0x28 字节」检查,42 套测试无一报警。
   现在改为把人造的 PE 镜像喂给源码中的真函数。 */
#include <stdio.h>
#include <string.h>
#include "t_eat_funcs.inc"

static int fails=0;
static void chk(const char* what,int got,int want){
    int ok=(got==want);
    printf("   %-46s %-10s %s\n",what,got?"找到":"放弃",ok?"OK":"FAIL");
    if(!ok) fails++;
}

/* 造一个最小但合法的 PE 镜像:只含我们关心的头部字段与导出表 */
static unsigned char img[0x20000];
static ULONG build(ULONG size, ULONG expRva, ULONG expSize,
                   DWORD nNames, DWORD nFuncs, DWORD funcRva, int forwarder){
    memset(img,0,sizeof img);
    img[0]='M'; img[1]='Z';
    const ULONG nt=0x100;
    *(LONG*)(img+0x3C)=(LONG)nt;
    *(DWORD*)(img+nt)=0x00004550;        /* "PE\0\0" */
    *(WORD*)(img+nt+0x18)=0x20B;         /* PE32+ */
    *(DWORD*)(img+nt+0x88)=expRva;
    *(DWORD*)(img+nt+0x8C)=expSize;
    if(expRva && expRva+0x28<=sizeof img){
        unsigned char* ed=img+expRva;
        ULONG rf=expRva+0x100, rn=expRva+0x200, ro=expRva+0x300;
        ULONG nameStr=expRva+0x400;
        *(DWORD*)(ed+0x14)=nFuncs;
        *(DWORD*)(ed+0x18)=nNames;
        *(DWORD*)(ed+0x1C)=rf;
        *(DWORD*)(ed+0x20)=rn;
        *(DWORD*)(ed+0x24)=ro;
        if(nNames){
            *(DWORD*)(img+rn)=nameStr;                       /* 名字表第 0 项 */
            memcpy(img+nameStr,"GetPluginFactory",17);
            *(WORD*)(img+ro)=0;                              /* 序号 -> 函数表第 0 项 */
            *(DWORD*)(img+rf)= forwarder ? (expRva+8) : funcRva;
        }
    }
    return size;
}

int main(void){
    DWORD *slot; DWORD orig;
    printf("== 正常镜像:应找到 GetPluginFactory ==\n");
    { ULONG sz=build(0x10000, 0x1000, 0x1000, 1,1, 0x500, 0);
      chk("合法导出表", eat_find_slot(img,sz,"GetPluginFactory",&slot,&orig), 1); }

    printf("\n== 畸形头部:必须放弃,不能出错 ==\n");
    { ULONG sz;
      sz=build(0x10000,0x1000,0x10,1,1,0x500,0);       /* 1101 的检查:目录小于结构体 */
      chk("导出目录小于 0x28(1101 加的检查)", eat_find_slot(img,sz,"GetPluginFactory",&slot,&orig), 0);
      sz=build(0x10000,0xFF00,0x1000,1,1,0x500,0);     /* 目录越过镜像末尾 */
      chk("导出目录越界", eat_find_slot(img,sz,"GetPluginFactory",&slot,&orig), 0);
      sz=build(0x10000,0x1000,0x1000,200000,200000,0x500,0);
      chk("名字数量荒谬(1101 的上限)", eat_find_slot(img,sz,"GetPluginFactory",&slot,&orig), 0);
      sz=build(0x10000,0x1000,0x1000,1,1,0x500,1);     /* 函数 rva 落在导出目录内 */
      chk("转发导出", eat_find_slot(img,sz,"GetPluginFactory",&slot,&orig), 0);
      sz=build(0x10000,0x1000,0x1000,1,1,0x90000,0);   /* 函数 rva 越界 */
      chk("函数 rva 越界", eat_find_slot(img,sz,"GetPluginFactory",&slot,&orig), 0);
      sz=build(0x10000,0,0,1,1,0x500,0);
      chk("没有导出表", eat_find_slot(img,sz,"GetPluginFactory",&slot,&orig), 0);
      sz=build(0x100,0x1000,0x1000,1,1,0x500,0);       /* size<0x200 */
      chk("镜像过小", eat_find_slot(img,sz,"GetPluginFactory",&slot,&orig), 0); }

    printf("\n== 名字必须精确匹配 ==\n");
    { ULONG sz=build(0x10000,0x1000,0x1000,1,1,0x500,0);
      chk("找不存在的 InitDll", eat_find_slot(img,sz,"InitDll",&slot,&orig), 0);
      chk("前缀 GetPlugin 不应命中", eat_find_slot(img,sz,"GetPlugin",&slot,&orig), 0); }

    printf("\n失败数: %d\n",fails);
    return fails?1:0;
}
