/* 文档与实物是否一致。文档已经两次和实物脱节:过时的截图(滑块改名后仍是旧标签),
   以及 README 说"构建脚本"却从没说明它不编译 agent。这里把文档里可核对的说法逐条对回实物。
   用法: ./t_docs [包根目录]   默认 ../..   自检: ./t_docs <包根目录> selftest */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static char R[200000], C[400000], A[700000];
static char root[512] = "../..";
static int fails = 0, selftest = 0;
static int load(const char* rel, char* buf, int cap){
    char p[1024]; snprintf(p,sizeof p,"%s/%s",root,rel);
    FILE* f=fopen(p,"rb"); if(!f) return 0;
    size_t n=fread(buf,1,(size_t)cap-1,f); buf[n]=0; fclose(f); return 1; }
static int exists(const char* rel){ char p[1024]; snprintf(p,sizeof p,"%s/%s",root,rel);
    FILE* f=fopen(p,"rb"); if(!f) return 0; fclose(f); return 1; }
static void ck(int ok, const char* what){ if(!ok){ printf("   ✗ %s\n", what); fails++; } }
static int num_after(const char* src, const char* key){ const char* p=strstr(src,key); return p? atoi(p+strlen(key)) : -1; }
int main(int argc, char** argv){
    if(argc>1) snprintf(root,sizeof root,"%s",argv[1]);
    if(argc>2 && !strcmp(argv[2],"selftest")) selftest=1;
    if(!load("README.md",R,sizeof R)){ printf("找不到 README.md —— 本套未验证任何东西,按失败处理\n"); return 1; }
    if(!load("vst3/cpp/AutoTune_KeyScale_Controller.cpp",C,sizeof C) || !load("combined/at_agent.cpp",A,sizeof A)){
        printf("找不到源码 —— 本套未验证任何东西,按失败处理\n"); return 1; }
    if(selftest){ char* p=strstr(R,"build 1"); if(p) memcpy(p,"build 9",7); }   /* 故意改坏一处 */

    /* 1) 版本号三处一致:README / agent AT_BUILD / 控制器 AT_BUILD_EXPECT */
    int va=num_after(A,"#define AT_BUILD "), vc=num_after(C,"#define AT_BUILD_EXPECT "), vr=num_after(R,"build ");
    ck(va==vc, "agent 的 AT_BUILD 与控制器的 AT_BUILD_EXPECT 不一致");
    ck(vr==va, "README 写的版本号与源码不一致");

    /* Headless control surface: documentation and real entry point agree. */
    int n_msg=0;
    ck(strstr(R,"无界面")!=NULL,"README 未说明控制器无界面");
    ck(strstr(C,"ShowWindow(")==NULL && strstr(C,"MessageBox")==NULL,"控制器仍存在可见界面调用");
    ck(strstr(C,"ATC_STATUS")!=NULL && strstr(C,"WM_COPYDATA")!=NULL,"无界面控制器丢失后台状态/IPC");

    /* 3) README 提到的文件必须存在 */
    const char* files[]={"windows_build/0_build_all.bat",
                         "插件技术说明.md","tests/README_DSP_TEST.md",0};   /* skip.txt.示例 删于 1162:改由高级设置写入 */
    for(int i=0;files[i];i++){ char w[300]; snprintf(w,sizeof w,"README 提到的文件不存在: %s",files[i]); ck(exists(files[i]),w); }

    /* 4b) 排查指南让用户去 agent.log 里搜的日志片段,必须真的会被 agent 打出来(1145)。
          措辞一改、文档没跟,用户就会去找一行永远不会出现的日志,然后得出错误结论。
          双向核对:片段要在 README 里(确实被引用),也要在 at_agent.cpp 里(确实会打印)。 */
    const char* logfr[]={"captured host IComponentHandler","UI-thread writes: subclassed window","on host UI thread",
                         "nouithread.txt present","owns no window","could not subclass","PostMessage failed",
                         "did not pump within","marshalling pauses for","host CLEARED the IComponentHandler",
                         "replaced its window twice while a write was queued",
                         "catch-mode: factory hook, no heap scan","EAT hook armed on GetPluginFactory","hooking factory NOW",
                         "Antares module (PACE-protected) -> factory hook only, never probed",
                         "only the agent's window-subclass pass-through: the agent was idle on this thread",
                         "HWND epoch cannot be confirmed",0};
    /* 报错时说清缺在哪一边:原先永远写"不在源码里",缺的其实可能是 README(1154 后) */
    for(int i=0;logfr[i];i++){ int inR=strstr(R,logfr[i])!=NULL, inA=strstr(A,logfr[i])!=NULL; char w[260];
        snprintf(w,sizeof w,"排查指南的日志片段%s%s: %s", inR?"":"不在 README 里", (!inR&&!inA)?"、也":"", logfr[i]);
        if(!inA){ size_t L=strlen(w); snprintf(w+L,sizeof w-L,"  <- 不在源码里(agent 不会打印它)"); }
        ck(inR && inA, w); }

    /* 4c) 技术说明第五节同样教用户去 agent.log 里找特定文字,此前没有任何测试核对它们(1156 后加入)。
          双向:片段要在 插件技术说明.md 里,也要在 at_agent.cpp 里。占位符(N、<path>)不纳入,只取字面部分。 */
    { static char T[300000]; int okT=load("插件技术说明.md",T,sizeof T);
      ck(okT, "找不到 插件技术说明.md");
      const char* techfr[]={"hook_factory: faulted while hooking","factory hooked late (the agent got into this host",
                            "ms after the host process started","CRASH: exception","did not pump within","marshalling pauses",
                            "replaced its window twice while a write was queued","captured host IComponentHandler",
                            "UI-thread writes: subclassed window","owns no window",0};
      for(int i=0;okT && techfr[i];i++){ int inT=strstr(T,techfr[i])!=NULL, inA=strstr(A,techfr[i])!=NULL; char w[260];
          snprintf(w,sizeof w,"技术说明引用的日志片段%s%s: %s", inT?"":"不在技术说明里", (!inT&&!inA)?"、也":"", techfr[i]);
          if(!inA){ size_t L=strlen(w); snprintf(w+L,sizeof w-L,"  <- 不在源码里(agent 不会打印它)"); }
          ck(inT && inA, w); } }

    /* 5) 已删除的图片不得再被引用 */
    ck(strstr(R,".png")==NULL, "README 仍引用图片(图片已移除)");

    /* 6) 注入放弃次数与文档一致 */
    int tries=num_after(C,"#define INJ_MAX_TRIES ");
    ck(tries==3 && strstr(R,"每进程连续注入失败 3 次后停止重试")!=NULL, "注入放弃次数与文档不一致");

    if(selftest){ printf("   自检:故意把版本号改错,应报出问题 -> %s\n", fails>0?"检查器有效":"检查器失效"); return fails>0?0:1; }
    printf("   文档与实物核对完毕(版本号、%d 条旧界面提示、文件、无界面与IPC、日志、重试次数),问题 %d 项\n", n_msg, fails);
    printf("\n失败数: %d\n", fails); return fails?1:0;
}
