static int parse_status_line(char* ln, char* leafOut, char* labelOut, unsigned* idOut, char* capsOut){
    unsigned lid=0; char lcaps[16]="KSRHVA";   /* no metadata (older agent) -> assume everything */
    { char* meta=strchr(ln,'\x01');
      if(meta){ *meta=0; lid=(unsigned)strtoul(meta+1,NULL,16);
                char* sp=strchr(meta+1,' ');
                if(sp){ int q=0; sp++; while(sp[q] && sp[q]!=' ' && q<15){ lcaps[q]=sp[q]; q++; } lcaps[q]=0; } } }
    char* bar=strstr(ln," | ");                /* agent writes "proc | leaf  Key=..." */
    if(!bar) return 0;
    char* lf=bar+3; char* dd=strstr(lf,"  ");
    int leaflen=dd?(int)(dd-lf):(int)strlen(lf);
    int lbllen =dd?(int)(dd-ln):(int)strlen(ln);
    if(leaflen<=0 || leaflen>=96) return 0;
    memcpy(leafOut,lf,(size_t)leaflen); leafOut[leaflen]=0;
    if(lbllen>159) lbllen=159;
    memcpy(labelOut,ln,(size_t)lbllen); labelOut[lbllen]=0;
    *idOut=lid; snprintf(capsOut,16,"%s",lcaps);
    return 1; }
