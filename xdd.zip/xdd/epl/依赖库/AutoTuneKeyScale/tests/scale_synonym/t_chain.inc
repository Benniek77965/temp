/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
if(!d->haveS && !_stricmp(tnm,"Scale")){ d->scaleId=info.id; d->scaleSteps=info.stepCount; d->haveS=1; }
        else if(!d->haveK && !_stricmp(tnm,"Key")){ d->keyId=info.id; d->keySteps=info.stepCount; d->haveK=1; }
        else if(!d->haveK && !_stricmp(tnm,"Root note")){ d->keyId=info.id; d->keySteps=info.stepCount; d->haveK=1;d->isTPain=1; }
        else if(!d->haveMod && !_stricmp(tnm,"Modern Scale")){ d->modId=info.id; d->modSteps=info.stepCount; d->haveMod=1; }
        else if(!d->haveRet && strstr(low,"retune") && !strstr(low,"graph")){ d->retId=info.id; d->haveRet=1; }
        else if(!d->haveHum && strstr(low,"humaniz")){ d->humId=info.id; d->haveHum=1; }
        else if(!d->haveNvb && (strstr(low,"natural vibrato")||strstr(low,"flex"))){ d->nvbId=info.id; d->haveNvb=1; }
        else if(!d->haveAudio && (strstr(low,"audio type")||strstr(low,"input type"))){ d->audioId=info.id; d->audioSteps=info.stepCount; d->haveAudio=1; }
        else if(d->isWaves && !d->haveK && (!_stricmp(tnm,"Root")||!_stricmp(tnm,"Scale Root"))){ d->keyId=info.id; d->keySteps=info.stepCount; d->haveK=1; }
        else if(d->isWaves && !d->haveS && !_stricmp(tnm,"Scale Type")){ d->scaleId=info.id; d->scaleSteps=info.stepCount; d->haveS=1; }
        else if(d->isWaves && !d->haveWSpeed && !_stricmp(tnm,"Speed")){ d->wSpeedId=info.id; d->haveWSpeed=1; }
        else if(d->isWaves && !d->haveWTrans && !_stricmp(tnm,"Note Transition")){ d->wTransId=info.id; d->haveWTrans=1; }
        else if(d->isWaves && !d->haveWVib && !_stricmp(tnm,"Vibrato Depth")){ d->wVibId=info.id; d->haveWVib=1; }
        else if(d->isWaves && !d->haveWRange && !_stricmp(tnm,"Range")){ d->wRangeId=info.id; d->haveWRange=1; }
