/* 关键门禁必须仍在调用点上(1123)

   变异测试暴露了一个盲区:已有测试大多验证「某个判定函数算得对不对」,
   却没人验证「那个判定结果有没有被用上」。于是把门禁整句删掉,42 套测试
   全部通过 —— 而其中三处删掉就会崩宿主:

     M03  EAT 钩子不再按清白清单筛选 -> 改写 PACE 模块的导出表
     M06  handler 钩子无视 fant 门禁 -> patch 电音11 的 controller vtable
     M10  卸载时不再先立 g_ejecting -> 在飞调用把指针写回即将卸载的 DLL

   这些门禁是【一行 if】,不是可提取的函数,所以只能在源码文本上核对其存在。
   这类检查脆(改写法就要跟着改),但聊胜于无:一行都没有的时候,
   任何人删掉它都不会有人知道。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* 剥掉注释与字符串字面量后再匹配。
   不这么做的话,守卫会被「把门禁删掉、只在注释里留一份同样文字」骗过 —— 实测如此。
   那比没有守卫更糟:它给的是虚假的安全感。
   字符串字面量一并剥掉,是因为本文件自身的断言文本也会出现在源码的日志串里。 */
static void strip_comments_and_strings(char* s){
    int i=0, n=(int)strlen(s);
    while(i<n){
        if(s[i]=='/' && s[i+1]=='/'){ while(i<n && s[i]!='\n'){ s[i]=' '; i++; } }
        else if(s[i]=='/' && s[i+1]=='*'){
            s[i]=' '; s[i+1]=' '; i+=2;
            while(i<n && !(s[i]=='*' && s[i+1]=='/')){ if(s[i]!='\n') s[i]=' '; i++; }
            if(i<n){ s[i]=' '; s[i+1]=' '; i+=2; } }
        else if(s[i]=='"'){
            i++;                                  /* 保留引号本身,只清内容 */
            while(i<n && s[i]!='"'){ if(s[i]=='\\' && i+1<n){ s[i]=' '; s[i+1]=' '; i+=2; continue; }
                                     s[i]=' '; i++; }
            if(i<n) i++; }
        else if(s[i]=='\''){
            i++;
            while(i<n && s[i]!='\''){ if(s[i]=='\\' && i+1<n){ i+=2; continue; } i++; }
            if(i<n) i++; }
        else i++;
    }
}
/* 只剥注释、保留字符串字面量。
   完整剥离(上面那个)能挡住「注释伪装」,但它也把字面量清空了 —— 而有些东西【本身就是字面量】:
   agent 与控制器之间的协议标记 [[PENDING]]、写死的能力串。只改字面量内容的变异,
   在完整剥离之后与原文一模一样,守卫在结构上就无法区分(实测 C05 / O12 两处如此)。
   所以按需选择:查代码结构用完整剥离,查协议字面量用这个。 */
static void strip_comments_only(char* s){
    int i=0, n=(int)strlen(s);
    while(i<n){
        if(s[i]=='"'){ i++; while(i<n && s[i]!='"'){ if(s[i]=='\\' && i+1<n){ i+=2; continue; } i++; } if(i<n) i++; }
        else if(s[i]=='\''){ i++; while(i<n && s[i]!='\''){ if(s[i]=='\\' && i+1<n){ i+=2; continue; } i++; } if(i<n) i++; }
        else if(s[i]=='/' && s[i+1]=='/'){ while(i<n && s[i]!='\n'){ s[i]=' '; i++; } }
        else if(s[i]=='/' && s[i+1]=='*'){ s[i]=' '; s[i+1]=' '; i+=2;
            while(i<n && !(s[i]=='*' && s[i+1]=='/')){ if(s[i]!='\n') s[i]=' '; i++; }
            if(i<n){ s[i]=' '; s[i+1]=' '; i+=2; } }
        else i++;
    }
}
static char* slurp(const char* p){
    FILE* f=fopen(p,"rb"); if(!f) return NULL;
    fseek(f,0,SEEK_END); long n=ftell(f); fseek(f,0,SEEK_SET);
    char* b=(char*)malloc(n+1); if(!b){fclose(f);return NULL;}
    size_t rd=fread(b,1,n,f); b[rd]=0; fclose(f); return b;
}
static int fails=0;
/* 在【指定函数体内】核对。全文搜索的弱点是:同一串若在两个函数里各出现一次,
   删掉其中一处另一处仍在,守卫照样通过(实测 catch.txt 与 scalemap.txt 的注释处理就是这样)。
   限定到函数体,就能区分是哪一处被改了。 */
static void need_in(const char* src,const char* fnStart,const char* fnEnd,
                    const char* what,const char* frag,const char* why){
    const char* a=src?strstr(src,fnStart):NULL;
    const char* b=a?strstr(a+1,fnEnd):NULL;
    int ok=0;
    if(a&&b){ size_t len=(size_t)(b-a); char* body=(char*)malloc(len+1);
              if(body){ memcpy(body,a,len); body[len]=0; ok=strstr(body,frag)!=NULL; free(body); } }
    printf("   %-46s %s\n",what,ok?"在":"**不在**");
    if(!ok){ printf("       %s\n       在 %s 内找不到: %s\n",why,fnStart,frag); fails++; }
}
/* 反向断言:某些东西【不该】出现。比「必须存在」更稳 —— 新写法会被挡下来,
   而不是等它在真机上变成死锁才发现。 */
static void forbid(const char* src,const char* what,const char* frag,const char* why){
    int bad = src && strstr(src,frag)!=NULL;
    printf("   %-46s %s\n",what,bad?"**出现了**":"没有");
    if(bad){ printf("       %s\n       出现的是: %s\n",why,frag); fails++; }
}
static void need(const char* src,const char* what,const char* frag,const char* why){
    int ok = src && strstr(src,frag)!=NULL;
    printf("   %-46s %s\n",what,ok?"在":"**不在**");
    if(!ok){ printf("       %s\n       找不到: %s\n",why,frag); fails++; }
}
int main(void){
    char* a=slurp("at_agent.cpp");
    char* c=slurp("AutoTune_KeyScale_Controller.cpp");
    char* cLit=slurp("AutoTune_KeyScale_Controller.cpp");
    if(cLit) strip_comments_only(cLit);
    char* aLit=slurp("at_agent.cpp");          /* 保留字面量的副本,专查协议标记 */
    if(aLit) strip_comments_only(aLit);
    if(a) strip_comments_and_strings(a);
    if(c) strip_comments_and_strings(c);
    if(!a||!c||!aLit||!cLit){ printf("   读不到源码(请先把两份源码拷到本目录)\n\n失败数: 1\n"); return 1; }

    printf("== 会崩宿主的三处门禁 ==\n");
    need(a,"EAT 仅对清白清单上的模块安装","for(int k=0;EAT_CLEARED[k];k++)",
           "删掉它,PACE 保护的模块的导出表也会被改写。");
    need(a,"handler 钩子受 PACE 门禁约束","if(fant==0) hook_setcomponenthandler(c);",
           "删掉门禁,电音11 的 controller vtable 会被 patch —— PACE 会直接杀掉宿主。");
    need_in(a,"static void agent_suspend(){","static void agent_resume(){",
            "安全停用先原子禁止新安装","InterlockedExchange(&g_ejecting,1)",
            "停用期间必须阻止新的写入和挂钩；回调计数不能授权物理卸载。");
    need(a,"三个安装点都检查 g_ejecting","if(g_ejecting) return;",
           "安装函数必须在卸载期间拒绝工作。");

    printf("\n== 会唱错调或控不了的门禁 ==\n");
    need(a,"VST2 按 kind 选用位置表","int tp = (w->kind==V2K_TPAIN);",
           "不分流的话 T-Pain 会用 Waves 的 44 项音阶表,选什么都错。");
    need(a,"factory_once 只缓存成功的工厂","if(f) factory_cache_put(mod,f);",
           "缓存了 NULL 就再也不会重试 —— 这正是 1090 修掉的原始 bug。");
    need(a,"catch 分支会重试挂钩","g_at[i].tries<40",
           "只试一次的话,工厂当时没就绪就永远挂不上。");
    need_in(cLit,"static void companion_write_goal(int keyScale){","static void companion_write_pause(){",
            "控制器发送实例 id","|target=%lu:|tid=%08X", "后台下发仍需保留精确实例ID。");

    printf("\n== 静默唱错调:这三处坏了不会崩,只会出错音 ==\n");
    need(a,"写入后读回校验仍在","char got[128]=\"\"; gp2_disp(e,idx,got,sizeof got); trim(got);",
           "没有它,位置表与插件实际档位错开时无人察觉 —— 一直唱错调且不报错。");
    need(a,"根音按【名字】匹配,不按半音序硬算","if(key_to_pc(ROOTS[i])==keySemi)",
           "Waves 的 17 个根音含同音异名(C#/Db 并存),按序号硬算必然错位。");
    need(a,"VST2 必须按 uid 确认是 Auto-Tune","if(uid==0x41547871u || uid==0x41547845u)",
           "不校验的话任何 VST2 都会被当成 Auto-Tune,把别人的参数写坏。");
    /* 连 if 一起核对:只查条件子串的话,把整句换成 if(0) 仍然查得到,守卫就形同虚设。 */
    need(a,"宿主自身的 VST2 包装必须排除","if(g_procLeaf[0] && _stricmp(mod,g_procLeaf)==0) continue;",
           "不排除就会把宿主当插件,列表里出现「宿主名 | 宿主名」。");
    need(a,"发布文件用原子改名","MoveFileExA(tmp,path,MOVEFILE_REPLACE_EXISTING)",
           "直接写目标文件,控制器会读到写了一半的内容。");

    printf("\n== 写入必须真的传到 DSP ==\n");
    /* 连 if(h) 一起核对:只查花括号【内部】的调用串,把条件换成 if(0) 仍能查到。 */
    need_in(a,"static void v3set_body(","static LRESULT CALLBACK at_wndproc(",
            "VST3事务从map取得owned binding","CHBinding* binding=requiresHandler?handler_binding_acquire(c):NULL;",
            "raw handler提示不能替代当前map-owned FUnknown引用。");
    need_in(a,"static void v3set_body(","static LRESULT CALLBACK at_wndproc(",
            "DSP下发只用仍current的binding","if(binding&&handler_binding_current(c,binding)){IComponentHandler* ch=(IComponentHandler*)binding->handler;",
            "setParamNormalized可重入清除旧handler；旧绑定不能开始新gesture。");
    need_in(a,"static void v3set_body(","static LRESULT CALLBACK at_wndproc(",
            "真实DSP编辑手势三调用成对","ch->vtbl->beginEdit(ch,id); ch->vtbl->performEdit(ch,id,v); ch->vtbl->endEdit(ch,id);",
            "仅改控制器副本不能证明DSP跟随，不能删performEdit或配对调用。");
    need(a,"写入前确认该插件支持这个音阶",
           "if(idx>=0) v2w_set_checked(e,w->scaleIdx,idx,NSCALE,SCALES[idx],tp?",
           "不检查就会把越界位置写进去,选到插件没有的音阶时唱错调。");
    /* 「找不到音阶时要记一笔」:1126 曾写明抓不到 —— `else LOG(` 在全文出现多次,删掉一处其余仍在。
       1136 起用 need_in 把断言限定到 v2w_apply 函数体内,在那里它只出现一次,于是能抓了。 */
    need_in(a,"static void v2w_apply","static const char* const* validate_vst2_cand",
           "音阶不在列表时会记一笔(限定 v2w_apply)","else LOG(",
           "静默跳过的话,用户看到「选了没反应」而日志里什么都没有。");

    printf("\n== 能力串必须如实,控件才会正确置灰 ==\n");
    need(a,"按名发现的 VST2 按实际发现声明 R/H/V",
           "if(w->speedIdx>=0) caps[ci++]='R'; if(w->transIdx>=0) caps[ci++]='H'; if(w->vibIdx>=0) caps[ci++]='V';",
           "谎报能力的话,控件不会置灰,用户拖了却没反应。"
           "(该路径不支持音频类型,所以能力串里本就不该有 A。)");
    forbid(aLit,"状态行没有写死的能力串","inst_id(e), \"KS",
           "写死能力串的话,控制器以为什么都支持,控件全不置灰,用户拖了没反应。");

    printf("\n== agent 不得从 worker 线程同步调用宿主的 UI ==\n");
    { /* 刷新插件界面只能用异步手段。SendMessage 会把 worker 线程阻塞在插件的 UI 线程上:
         那个线程此刻可能正等着音频线程、或正在加载器锁里,于是整个机架卡死 —— 而且是
         「没崩、没日志、只是不动了」这种最难排查的形态。
         InvalidateRect 只标脏区域、立即返回,是安全的。 */
      forbid(a,"没有 SendMessage","SendMessage",
             "worker 线程会被阻塞在插件的 UI 线程上,机架卡死且无任何日志。");
      forbid(a,"没有 SendDlgItemMessage","SendDlgItemMessage","同上。");
      forbid(a,"没有 SendNotifyMessage 之外的同步等待","SendMessageTimeout","同上(即使带超时也会拖住 worker)。");
      need(a,"界面刷新用异步的 InvalidateRect","InvalidateRect(h,NULL,FALSE);",
             "这是唯一安全的刷新方式:只标脏区域,立即返回。"); }

    printf("\n== 宿主界面线程的崩溃守护(g_uiJb)必须自洽(1145) ==\n");
    { /* at_wndproc 在宿主线程上执行 performEdit,用的是独立的恢复点 g_uiJb。它有三条不变式,
         写错任何一条都不会编译报错,但后果严重:
           1. 必须用 g_uiJb,不能误用 worker 的 g_jb —— 否则宿主线程的故障会 longjmp 到
              worker 设的恢复点,跳进另一个线程的栈,必崩;
           2. setjmp 之后无论走哪条路,都必须把 g_uiProbing 复位回 0 —— 否则这之后 worker
              或宿主自身的正常异常会被 veh() 当成"界面线程探测中的故障"劫持;
           3. veh() 里必须有一条按 g_uiProbeTid 分流到 g_uiJb 的恢复分支 —— 否则守护形同虚设。
         这些是顺序/配对约束,全文子串匹配不够,这里在 at_wndproc 函数体内按出现顺序核对。 */
      char* b=strstr(a,"static LRESULT CALLBACK at_wndproc(");
      if(!b){ printf("   **找不到 at_wndproc —— 签名改了?这条守卫已失效**\n"); fails++; }
      else{ char* lb=strchr(b,'{'); int d=0; char* q=lb;
            for(;;){ if(*q=='{')d++; else if(*q=='}')d--; if(!d) break; q++; }
            char sv=*q; *q=0;
            char* pArm   = strstr(b,"InterlockedExchange(&g_uiProbing,1)");
            char* pSetjmp= strstr(b,"setjmp(g_uiJb)");
            char* pReset = strstr(b,"InterlockedExchange(&g_uiProbing,0)");
            char* pWrongJb = strstr(b,"setjmp(g_jb)");    /* 不该在这里出现 worker 的恢复点 */
            int ok1 = pArm && pSetjmp && pReset && pArm<pSetjmp && pSetjmp<pReset;
            printf("   arm g_uiProbing -> setjmp(g_uiJb) -> 复位 g_uiProbing,顺序正确  %s\n", ok1?"是":"**否**");
            if(!ok1) fails++;
            printf("   at_wndproc 内没有误用 worker 的 setjmp(g_jb)              %s\n", pWrongJb?"**误用了**":"没有");
            if(pWrongJb) fails++;
            int uses_uijb = pSetjmp!=NULL;
            printf("   at_wndproc 用的是 g_uiJb 而非 g_jb                        %s\n", uses_uijb?"是":"**否**");
            if(!uses_uijb) fails++;
            *q=sv; }
      /* veh() 必须有按 g_uiProbeTid 分流到 g_uiJb 的分支 */
      char* v=strstr(a,"static LONG CALLBACK veh(");
      int vehok=0;
      if(v){ char* vlb=strchr(v,'{'); int d=0; char* q=vlb;
             for(;;){ if(*q=='{')d++; else if(*q=='}')d--; if(!d) break; q++; }
             char sv=*q; *q=0;
             vehok = strstr(v,"g_uiProbeTid")!=NULL && strstr(v,"longjmp(g_uiJb")!=NULL;
             *q=sv; }
      printf("   veh() 有按 g_uiProbeTid 分流到 longjmp(g_uiJb) 的恢复分支   %s\n", vehok?"有":"**无**");
      if(!vehok) fails++;
      /* 窗口过程绝不能直通到自己(1145 第六轮)。g_uiOrig 一旦指向 at_wndproc,每条普通消息都会
         自调到栈溢出,而 veh() 故意放行栈溢出 —— 宿主当场死掉、没有日志。这是用 32 位跑集成测试
         时发现的:两次 attach 竞争同一窗口,约四分之三的概率把 g_uiOrig 弄成自指。
         两道防线各一行,只跑 t_*.c 循环的人也要能看到它们被删。 */
      need(a,"防线一:at_wndproc 直通时拒绝调用自己",
             "if(!orig || orig==(WNDPROC)at_wndproc) return",
             "没有它,g_uiOrig 自指时每条普通消息都会无限自调,宿主界面线程栈溢出,不可恢复。");
      /* Waves 探测实例(1146)。LiveProfessor 2 插入插件前会先建再销毁同类实例;agent 曾一直留着它们、
         每条命令都写入错误的值。两道门各一行:没有宿主 handler 的 Waves 不列入实例集合;
         存活判定先用"Waves + 无 handler + 只剩我们的引用"认出探测实例。 */
      /* 崩溃记录器(1148)把进程级的顶层过滤器指向本 DLL。卸载时必须先摘掉它,
         否则卸载之后任何未处理异常都会调用一个已经卸载的地址。 */
      /* Antares 一律不探测(1149)。探测 PACE 保护的模块会让宿主崩溃(MonsterApplication 实测:
         断路器标记为 Antares\Auto-Tune.vst3,异常 0xC000001D 出在不属于任何模块的内存里)。 */
      need(aLit,"按内容认出的 Antares 一律走捕获路径",
             "Antares module (PACE-protected) -> factory hook only, never probed",
             "没有它,改了名、不在名字名单里的 Antares 模块会被探测,而探测 PACE 正是闪退的原因。");
      need(aLit,"内置捕获名单覆盖整个 Auto-Tune 系列","\"auto-tune\", NULL };",
             "只写 auto-tune pro.vst3 时,Auto-Tune 9 / 8.1 等版本都被探测。");
      /* 状态文件与音阶文件:整条写入、要么不写(1153)。控制器把最后一个字节不是换行的文件当作写到一半:
         音阶文件整个忽略,状态文件保持原显示不更新(agent 每次发布同样的字节 -> 实例列表冻结)。 */
      forbid(a,"不再用会留下半条记录的累加写法","off+=snprintf(buf+off,sizeof buf-off",
             "snprintf 截断时返回想写的长度:半条记录留在末尾,off 越过缓冲区。用 rec_append。");
      need(a,"状态与音阶记录走 rec_append","rec_append(buf,(int)sizeof buf,&off,",
             "整条写入或不写,文件永远以完整的一行结尾。");
      need_in(a,"static void agent_suspend(){","static void agent_resume(){",
             "安全停用撤掉崩溃记录器","crash_record_remove();",
             "停用必须撤掉记录器；该检查限定在真实停用路径。");
      need(a,"无宿主 handler 的 Waves 不列入实例集合",
             "if(waves_known(c) && !handler_of(c)) continue;",
             "没有它,宿主已销毁的探测实例会被列出、被写入,而且写的是错误的值。");
      need(a,"存活判定先认出 Waves 探测实例",
             "if(waves_probe_decide(waves_known(c), handler_of(c)!=NULL, before, n)){",
             "没有它,探测实例首次读数只剩我们的引用,会被判成'计数不可用'而永不丢弃,还占着实例表的槽位。");
      need_in(a,"static LRESULT CALLBACK at_wndproc(","static BOOL CALLBACK pick_ui_wnd(",
              "消息按当前HWND取不可覆盖的转发记录","ATUI_Route* route=atui_find(hw);",
              "不能使用worker最后选中窗口的全局原过程。");
      need_in(a,"static LRESULT CALLBACK at_wndproc(","static BOOL CALLBACK pick_ui_wnd(",
              "原过程来自当前窗口记录","WNDPROC orig=route?route->original:NULL;",
              "跨窗口回调尾部必须保留自己的original。");
      need_in(a,"static LRESULT CALLBACK at_wndproc(","static BOOL CALLBACK pick_ui_wnd(",
              "窗口字符集来自当前窗口记录","route?route->unicode:",
              "ANSI与Unicode窗口不能随全局选择一起变化。");
      need_in(a,"static LRESULT CALLBACK at_wndproc(","static BOOL CALLBACK pick_ui_wnd(",
              "观察到销毁才退休窗口epoch","if(m==WM_NCDESTROY)atui_destroy(route);",
              "停用期间也必须保留只读观察，不得把复用HWND当旧窗口。");
      need_in(a,"static LRESULT CALLBACK at_wndproc(","static BOOL CALLBACK pick_ui_wnd(",
              "私有队列绑定HWND线程及epoch","ui_target_matches(k,gen,hw,route,GetCurrentThreadId())",
              "仅匹配槽序号不能证明消息属于此窗口。");
      need_in(a,"static LRESULT CALLBACK at_wndproc(","static BOOL CALLBACK pick_ui_wnd(",
              "同时只允许一个UI参数恢复事务","InterlockedCompareExchange(&g_uiExecuting,1,0)",
              "另一个UI线程不能覆盖g_uiJb恢复点。");
      need_in(a,"static int ui_attach(DWORD tid){","static int ui_post(",
              "新子类化通过owner线程安装","atui_install_on_owner(h,tid,g_uiWndUni,(WNDPROC)at_wndproc)",
              "不能从worker预发布猜测original再改宿主窗口。");
      char* installer=slurp("../../vst3/cpp/companion_ui_install.h");
      if(!installer){printf("   找不到真实owner线程安装头 —— 未验证安装链\n");fails++;}
      else{
          strip_comments_and_strings(installer);
          need(installer,"安装回调确认目标owner线程","GetCurrentThreadId()==request->thread","不得在worker线程执行窗口过程安装。");
          need(installer,"安装用异步GETMESSAGE线程钩子","SetWindowsHookExW(WH_GETMESSAGE,atui_install_hook,NULL,thread)","不借同步宿主调用等待持锁线程。");
          need(installer,"安装拒绝把自身当旧过程","observed!=request->observer","拒绝自指链。");
          need(installer,"真实setter返回也拒绝自身","original!=request->observer","原过程必须来自真实setter返回。");
          need(installer,"安装请求使用静态描述符","static ATUI_Install g_uiInstalls[ATUI_MAX_INSTALLS]","迟到callback不得访问worker栈。");
          need(installer,"等待有实测时钟预算","GetTickCount()-began<(DWORD)ATUI_INSTALL_WAIT_MS","不得无限等待宿主UI线程。");
          need(installer,"迟到安装标记废弃","InterlockedExchange(&request->abandoned,1)","超时不能把旧请求当作及时成功。");
          free(installer);
      }
    }

    printf("\n== 加载器回调里不得做任何可能重入加载器的事 ==\n");
    { /* dll_notify 跑在 LdrLoadDll 内部,此时加载器锁已被持有且【不可重入】。
         在那里调 LoadLibrary / GetModuleHandle / CoInitialize 之类都会直接死锁,
         而且死的是正在加载插件的那个线程 —— 机架定格,无崩溃、无日志。
         现在代码里这些名字只出现在注释(已被剥离),一个真实调用都没有。 */
      forbid(a,"没有 LoadLibrary 调用","LoadLibraryA(",
             "加载器锁不可重入,在回调里调它会让机架直接定格。");
      forbid(a,"没有 LoadLibraryW 调用","LoadLibraryW(","同上。");
      forbid(a,"没有 LoadLibraryExW 调用","LoadLibraryExW(","同上。");
      forbid(a,"没有 CoInitialize","CoInitialize","COM 初始化会重入加载器。");
      forbid(a,"没有 MessageBox","MessageBox",
             "弹窗会在宿主进程里起消息循环,音频线程随之停摆。"); }

    need(a,"崩溃保护名单写入前查重","if(!already){ FILE* b=fopen(g_blackPath,",
           "不查重的话,一个反复出事的插件会用重复行占满 16 格,"
           "其余模块再也进不来 —— 崩溃保护对它们静默失效且不会自愈。");
    need(a,"读取名单不以行数停止","while(fgets(line,sizeof line,b))",
           "读满 16 行就停的话,重复行会先吃掉额度。");
    need(a,"工厂钩子表满时记一笔","MAXVT,leaf?leaf:",
           "静默放弃挂钩的话,那个插件永远捕获不到而无人知道原因。");
    /* 五个配置文件对 '#' 的处理必须一致。曾经两个支持、两个不支持,用户无从知道哪个是哪个:
       在 skip.txt 里写 "# 停用 Waves" 这种说明会白占一格,写 "# waveshell" 想注释掉也不会按预期工作。 */
    need_in(a,"static void load_catch_list","static int is_catch_path",
           "catch.txt 跳过注释","if(!line[i] || line[i]=='#') continue;",
           "五个配置文件对 # 的处理必须一致。");
    need_in(a,"static void load_scalemap","static int grp_of",
           "scalemap.txt 跳过注释","if(!line[i] || line[i]=='#') continue;","同上。");
    need(a,"skip.txt 跳过注释","if(!line[b] || line[b]=='#') continue;","同上。");
    need(a,"use_factory_hook.txt 跳过注释","if(n>0 && line[0]=='#') n=0;","同上。");
    need(a,"skip.txt 读完整个文件(不以 16 行为止)","if(g_nSkip>=16){ dropped++; continue; }",
           "读满 16 行就停的话,后面的行静默丢弃,用户以为已停用的模块其实仍在工作。");
    /* M12:1105 的行为 —— 探测出事的模块转入 catch 模式,而不是从列表里消失。
       退回旧行为的话插件会【消失】,只能手删文件恢复;这台机器的用户就亲身踩过。 */
    need_in(a,"static void scan_all","static BOOL CALLBACK inv_child",
           "探测出事的模块转 catch 而非消失","if(!catchM && mod_probe_unsafe(p)){",
           "退回旧行为会让插件从列表消失,只能手动删 disabled.txt 才恢复。");
    need_in(a,"static void scan_all","static BOOL CALLBACK inv_child",
           "  ...且确实置为 catch 模式","catchM=1;",
           "条件还在但不再置位的话,等于没修。");
    /* M16 / O12:都在 write_status 内只出现一次 */
    need_in(a,"static void write_status","static void disc_fill",
           "独立agent无实例时删除空状态文件","if(off <= hdrLen && !AT_XHH_MANAGED){",
           "托管agent须保留暂停握手；独立版仍清理空状态文件。");
    need_in(a,"static void write_status","static void disc_fill",
           "托管状态包含暂停握手","agent_pause_status(buf+off", "没有插件时也必须能确认暂停栅栏已接收。");
    need_in(aLit,"static void write_status","static void disc_fill",
           "已加载未捕获时输出占位符","[[PENDING]]",
           "占位符消失的话,用户看不到「已加载未捕获」,不知道需要重加。");
    /* EAT 钩子只在加载通知里安装,而那里有一份【独立于 is_catch_path 的】匹配判定。
       1128 把内置项移进独立数组时漏改了这一处,结果没有 catch.txt 时通知对所有内置模块
       直接返回 —— T-Pain/WaveShell/Auto-Tune Pro/电音11 全部要重加,且日志里毫无线索。
       两处判定必须都查两份清单。 */
    need_in(a,"static void CALLBACK dll_notify","static void install_dll_notification",
           "加载通知也查内置清单","g_catchBuiltin[k]",
           "只查用户清单的话,没有 catch.txt 时内置模块一个都匹配不上,EAT 永远装不上。");
    need_in(a,"static void CALLBACK dll_notify","static void install_dll_notification",
           "  ...并且仍查用户清单","g_catchPat[k][0]",
           "两份都要查,缺一不可。");
    need(a,"内置 catch 项独立于用户列表","g_catchBuiltin[i]",
           "和用户列表共用数组的话,用户写满 catch.txt 会把 waveshell/t-pain/antares 挤掉。");

    printf("\n== 职责分离:上报不得按目标过滤 ==\n");
    { int bad = a && strstr(a,"if(!target_ok_obj(e,w->name)) continue;")!=NULL;
      printf("   %-46s %s\n","状态上报中没有目标过滤", bad?"**有,错了**":"没有");
      if(bad){ printf("       上报按目标过滤会让 Target 下拉里其余实例消失(1118)。\n"); fails++; } }

    printf("\n失败数: %d\n",fails);
    free(a); free(c); if(aLit) free(aLit); if(cLit) free(cLit);
    return fails?1:0;
}
