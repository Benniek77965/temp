/* Mono / Stereo 同 vtable 时的实例命名(1092 修的问题)

   Waves 的 "Waves Tune Real-Time Mono" 和 "... Stereo" 是同一个 C++ 类做出来的,
   两者**共用一张 component vtable**。而 initialize() 钩子是按 vtable 登记的,名字
   原先也存在 vtable 上:第二个变体创建时命中 dup 分支直接返回,vtable 上留着的仍是
   先创建那个变体的名字,于是之后每个实例都被按那个名字捕获。

   真机(17.1)日志里的表现:
     hook: createInstance cid=...S... = Waves Tune Real-Time Stereo   ← createInstance 认对了
     CAUGHT genuine controller @ ... [Waves Tune Real-Time Mono]      ← 捕获时却成了 Mono

   class id 是**每个类各一份**的,所以 1092 改成在 createInstance 时按【实例对象】记名字,
   捕获时优先取它。本测试直接引用源码里的 cid_is_waves 与实例名表,复现那条真机时序。 */
#include <stdio.h>
#include <string.h>
typedef char TUID[16];
#include "t_cid_funcs.inc"
#include "t_variant_funcs.inc"

static int fails=0;
static void chk(const char* what,const char* got,const char* want){
  int ok=!strcmp(got,want);
  printf("   %-34s -> %-30s %s\n",what,got,ok?"OK":"FAIL");
  if(!ok){ printf("        期望: %s\n",want); fails++; }
}

/* 复刻真机时序:createInstance 记名字 -> initialize 取名字 */
static void create(void* obj,const char* rawcid){
  TUID c; memcpy(c,rawcid,16);
  char nm[80]=""; if(cid_is_waves(c,nm,sizeof nm) && nm[0]) inst_name_set(obj,nm);
}
/* 捕获侧:vtable 上那份是共享的(先到先得),实例名若有则覆盖它 */
static void captured(void* obj,const char* vtableShared,char* out,int outsz){
  snprintf(out,outsz,"%s",vtableShared);
  for(int i=0;i<g_nIn;i++) if(g_inObj[i]==obj){ if(g_inName[i][0]) snprintf(out,outsz,"%s",g_inName[i]); break; }
}

int main(void){
  char nm[96];
  /* 三个假实例地址,对应真机日志里的三次 createInstance */
  void* i1=(void*)0x1000; void* i2=(void*)0x2000; void* i3=(void*)0x3000;

  printf("== 真机时序:Mono, Mono, Stereo(三者同一 vtable)==\n");
  create(i1,"LTSVLVwMaves tun");    /* 实例1 Mono   */
  create(i2,"LTSVLVwMaves tun");    /* 实例2 Mono   */
  create(i3,"LTSVLVwSaves tun");    /* 实例3 Stereo */

  /* vtable 上存的是最先登记的那个名字 —— 正是 bug 的来源 */
  const char* shared="Waves Tune Real-Time Mono";
  captured(i1,shared,nm,sizeof nm); chk("实例1(Mono)",  nm,"Waves Tune Real-Time Mono");
  captured(i2,shared,nm,sizeof nm); chk("实例2(Mono)",  nm,"Waves Tune Real-Time Mono");
  captured(i3,shared,nm,sizeof nm); chk("实例3(Stereo)",nm,"Waves Tune Real-Time Stereo");

  printf("\n== 反向顺序:先 Stereo 再 Mono(vtable 上会留 Stereo)==\n");
  g_nIn=0;
  void* j1=(void*)0x4000; void* j2=(void*)0x5000;
  create(j1,"LTSVLVwSaves tun");
  create(j2,"LTSVLVwMaves tun");
  const char* shared2="Waves Tune Real-Time Stereo";
  captured(j1,shared2,nm,sizeof nm); chk("实例1(Stereo)",nm,"Waves Tune Real-Time Stereo");
  captured(j2,shared2,nm,sizeof nm); chk("实例2(Mono)",  nm,"Waves Tune Real-Time Mono");

  printf("\n== 非 Waves 实例:没有实例名,仍沿用 vtable 上那份 ==\n");
  g_nIn=0;
  void* k1=(void*)0x6000;
  create(k1,"xxxxxxxxxxxxxxxx");            /* 不是 Waves class id -> 不登记 */
  captured(k1,"Auto-Tune Pro",nm,sizeof nm); chk("非 Waves 实例",nm,"Auto-Tune Pro");

  printf("\n== 表满时淘汰最旧的,新实例仍然正确 ==\n");
  g_nIn=0;
  for(int i=0;i<MAXIN;i++) create((void*)(long)(0x10000+i*0x10),"LTSVLVwMaves tun");
  void* late=(void*)0x90000;
  create(late,"LTSVLVwSaves tun");
  captured(late,shared,nm,sizeof nm); chk("溢出后新建的 Stereo",nm,"Waves Tune Real-Time Stereo");
  printf("   表容量 MAXIN=%d,写入 %d 个后仍未越界\n",MAXIN,MAXIN+1);

  printf("\n失败数: %d\n",fails);
  return fails?1:0;
}
