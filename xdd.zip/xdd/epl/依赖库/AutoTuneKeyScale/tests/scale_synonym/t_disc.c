#include <stdio.h>
#include <string.h>
#include <ctype.h>
#define _stricmp strcasecmp
typedef struct { int haveS,haveK,haveMod,haveRet,haveHum,haveNvb,haveAudio;
                 int scaleId,keyId,modId,retId,humId,nvbId,audioId;
                 int scaleSteps,keySteps,modSteps,audioSteps;
                 int isWaves,isTPain,haveWSpeed,haveWTrans,haveWVib,haveWRange;
                 int wSpeedId,wTransId,wVibId,wRangeId; } D;
#include "t_params.inc"
static void run(D* d, const PInfo* P, const char* who){
  for(int k=0; P[k].id>=0; k++){
    char tnm[64]; snprintf(tnm,sizeof tnm,"%s",P[k].t);
    char low[64]; { int j; for(j=0;tnm[j]&&j<63;j++){ char ch=tnm[j]; low[j]=(ch>='A'&&ch<='Z')?(char)(ch+32):ch; } low[j]=0; }
    struct {int id;int stepCount;} info={P[k].id,P[k].steps};
    #include "t_chain.inc"
  }
  printf("[%s] isWaves=%d\n", who, d->isWaves);
  printf("   Antares: Scale=%d(id%d) Key=%d(id%d) Modern=%d(id%d) Retune=%d(id%d) Human=%d(id%d) NatVib=%d(id%d) Audio=%d(id%d)\n",
     d->haveS,d->scaleId,d->haveK,d->keyId,d->haveMod,d->modId,d->haveRet,d->retId,d->haveHum,d->humId,d->haveNvb,d->nvbId,d->haveAudio,d->audioId);
  printf("   Waves  : Speed=%d(id%d) Trans=%d(id%d) Vib=%d(id%d) Range=%d\n",
     d->haveWSpeed,d->wSpeedId,d->haveWTrans,d->wTransId,d->haveWVib,d->wVibId,d->haveWRange);
}
int main(void){
  int fail=0;
  D a; memset(&a,0,sizeof a); a.isWaves=0;  run(&a,PRO,"电音11 (修复后: isWaves=0)");
  if(!(a.haveS&&a.scaleId==1)) {printf("   FAIL Scale\n");fail++;}
  if(!(a.haveK&&a.keyId==2))   {printf("   FAIL Key\n");fail++;}
  if(!(a.haveMod&&a.modId==162)){printf("   FAIL ModernScale\n");fail++;}
  if(!(a.haveRet&&a.retId==4)) {printf("   FAIL RetuneSpeed\n");fail++;}
  if(!(a.haveHum&&a.humId==61)){printf("   FAIL Humanize\n");fail++;}
  if(!(a.haveNvb&&a.nvbId==62)){printf("   FAIL NaturalVibrato\n");fail++;}
  if(a.haveWTrans||a.haveWVib||a.haveWSpeed){printf("   FAIL Waves 匹配器仍在电音11上开火!\n");fail++;}
  else printf("   OK  Waves 匹配器完全未开火 ✓\n");

  printf("\n");
  D b; memset(&b,0,sizeof b); b.isWaves=1;  run(&b,WAV,"Waves (isWaves=1)");
  if(!(b.haveK&&b.keyId==11)) {printf("   FAIL Scale Root\n");fail++;}
  if(!(b.haveS&&b.scaleId==10)){printf("   FAIL Scale Type\n");fail++;}
  if(!(b.haveWSpeed&&b.wSpeedId==0)){printf("   FAIL Speed\n");fail++;}
  if(!(b.haveWTrans&&b.wTransId==1)){printf("   FAIL Note Transition\n");fail++;}
  if(!(b.haveWVib&&b.wVibId==8)){printf("   FAIL Vibrato Depth\n");fail++;}
  else printf("   OK  Waves 五项全部命中正确 id ✓\n");

  printf("\n=== 最坏情况:假如 isWaves 又被误置为 1(防御纵深) ===\n");
  D c; memset(&c,0,sizeof c); c.isWaves=1;  run(&c,PRO,"电音11 强制 isWaves=1");
  if(c.haveWTrans||c.haveWVib){printf("   FAIL 收紧后仍误抓!\n");fail++;}
  else printf("   OK  即使标志出错,精确匹配也不会误抓 ✓\n");
  printf("\n=== The T-Pain Effect (iZotope) ===\n");
  D t; memset(&t,0,sizeof t); t.isWaves=0;  run(&t,TPAIN,"T-Pain (isWaves=0)");
  if(!(t.haveS&&t.scaleId==18)){printf("   FAIL Scale 应为 id18\n");fail++;}
  if(!(t.haveK&&t.keyId==19)) {printf("   FAIL 'Root note' 未识别为 Key(应 id19)\n");fail++;}
  if(!(t.keySteps==11))       {printf("   FAIL Key steps 应为 11(12个根音)\n");fail++;}
  if(!(t.scaleSteps==5))      {printf("   FAIL Scale steps 应为 5(6个音阶)\n");fail++;}
  /* 'Level Meter Scale Type' 含 Scale,绝不能抢在真 Scale(id18)前面 */
  if(t.scaleId!=18)           {printf("   FAIL 被 'Level Meter Scale Type' 误抓\n");fail++;}
  if(t.haveWTrans||t.haveWVib||t.haveWSpeed){printf("   FAIL Waves 匹配器在 T-Pain 上开火\n");fail++;}
  else printf("   OK  Scale=id18 Key=id19('Root note') 且未被 Level Meter 干扰 ✓\n");

  printf("\n=== 回归保护:新增的 'Root note' 不得影响电音11/Waves ===\n");
  D d1; memset(&d1,0,sizeof d1); d1.isWaves=0; run(&d1,PRO,"电音11 复测");
  if(!(d1.haveK&&d1.keyId==2)){printf("   FAIL 电音11 Key 被改变\n");fail++;}
  D d2; memset(&d2,0,sizeof d2); d2.isWaves=1; run(&d2,WAV,"Waves 复测");
  if(!(d2.haveK&&d2.keyId==11)){printf("   FAIL Waves Key 被改变\n");fail++;}
  if(d1.keyId==2&&d2.keyId==11) printf("   OK  两者 Key 识别均未受影响 ✓\n");

  printf("\n失败数: %d\n", fail); return fail?1:0;
}
