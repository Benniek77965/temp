/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
static unsigned long g_fakePid=0;
#define GetCurrentProcessId() g_fakePid
static unsigned g_fakeInstId=0;
#define inst_id(p) g_fakeInstId
static unsigned long g_targetPid=0; static char g_targetLeaf[96]="";
static unsigned g_targetId=0;
static int target_ok_obj(const void* obj, const char* leaf){
    if(g_targetPid==0) return 1;                        /* no target -> all plugins */
    if(g_targetPid != GetCurrentProcessId()) return 0;  /* target is in another host -> this agent applies to none */
    if(g_targetId) return inst_id(obj) == g_targetId;
    return leaf && g_targetLeaf[0] && _stricmp(leaf,g_targetLeaf)==0; }
