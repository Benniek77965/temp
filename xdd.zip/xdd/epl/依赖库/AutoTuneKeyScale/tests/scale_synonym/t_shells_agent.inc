#include <ctype.h>   /* tolower:隐式声明在 C99 起已移除 */
static int at_lower(int c){ return (c>='A'&&c<='Z') ? c+32 : c; }
static int strstr_ci(const char* hay, const char* needle){ if(!hay||!needle) return 0;
    char h[256], n[128]; int i=0; for(;hay[i]&&i<255;i++) h[i]=(char)tolower((unsigned char)hay[i]); h[i]=0;
    int j=0; for(;needle[j]&&j<127;j++) n[j]=(char)tolower((unsigned char)needle[j]); n[j]=0;
    return strstr(h,n)!=NULL; }
static const char* const g_catchBuiltin[] = { "11.vst3", "waveshell", "t-pain", "auto-tune pro.vst3", NULL };
static int is_catch_path(const char* low){ if(!g_catchLoaded) load_catch_list();
    for(int i=0;g_catchBuiltin[i];i++) if(strstr(low,g_catchBuiltin[i])) return 1;   /* built-ins always apply */
    for(int i=0;i<g_nCatchPat;i++) if(g_catchPat[i][0] && strstr(low,g_catchPat[i])) return 1;
    return 0; }
