/* VST2 Waves 的位置映射:只要算错一位,就会把歌手切到错误的调 */
#include <stdio.h>
#include <string.h>
#include "t_scale_funcs.inc"      /* 真实 norm / scale_same / scale_canon */
#include "t_root_funcs.inc"       /* 真实 key_to_pc */
#include "t_wv_tables.inc"        /* 真机测得的 44 音阶 / 17 根音 */
static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)
int main(void){
  printf("== 1. 12 个音级都要能映射到根音档位,且归一化值必须和 VST3 一致 ==\n");
  const char* PC[12]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
  for(int pc=0;pc<12;pc++){
    int idx=-1;
    for(int i=0;i<WAVES_NROOT;i++) if(key_to_pc(WAVES_ROOTS[i])==pc){ idx=i; break; }
    double v = (idx>=0) ? (double)idx/(WAVES_NROOT-1) : -1;
    int ok = idx>=0 && key_to_pc(WAVES_ROOTS[idx])==pc;
    printf("   %-3s -> 档位 %2d/%d  值 %.4f  显示'%s'  %s\n",PC[pc],idx,WAVES_NROOT-1,v,
           idx>=0?WAVES_ROOTS[idx]:"-", ok?"OK":"FAIL");
    if(!ok) fails++;
  }
  printf("\n== 2. B 调必须落在最后一档(当初出错的就是它)==\n");
  { int idx=-1; for(int i=0;i<WAVES_NROOT;i++) if(key_to_pc(WAVES_ROOTS[i])==11){ idx=i; break; }
    CK(idx==WAVES_NROOT-1 && (double)idx/(WAVES_NROOT-1)==1.0, "B -> 档位16/16 值1.0000"); }
  printf("\n== 3. 音阶名必须能找到,且同义词也要命中 ==\n");
  const char* want[]={"Chromatic","Major","Minor","Natural Minor","Harmonic Minor","Dorian","Blues","Maqam Saba",0};
  for(int q=0;want[q];q++){
    char w[64]; norm(want[q],w,sizeof w); int idx=-1;
    for(int i=0;i<WAVES_NSCALE;i++){ char a[64]; norm(WAVES_SCALES[i],a,sizeof a); if(scale_same(a,w)){ idx=i; break; } }
    double v=(idx>=0)?(double)idx/(WAVES_NSCALE-1):-1;
    printf("   %-16s -> 档位 %2d  值 %.4f  实际'%s'  %s\n",want[q],idx,v,idx>=0?WAVES_SCALES[idx]:"-",idx>=0?"OK":"FAIL");
    if(idx<0) fails++;
  }
  printf("\n== 4. 'Minor' 必须经同义词命中 'Natural Minor' ==\n");
  { char w[64]; norm("Minor",w,sizeof w); int idx=-1;
    for(int i=0;i<WAVES_NSCALE;i++){ char a[64]; norm(WAVES_SCALES[i],a,sizeof a); if(scale_same(a,w)){ idx=i; break; } }
    CK(idx>=0 && !strcmp(WAVES_SCALES[idx],"Natural Minor"), "Minor -> Natural Minor"); }
  printf("\n== 5. 不存在的音阶必须【找不到】而不是乱写 ==\n");
  { char w[64]; norm("Ling Lun",w,sizeof w); int idx=-1;
    for(int i=0;i<WAVES_NSCALE;i++){ char a[64]; norm(WAVES_SCALES[i],a,sizeof a); if(scale_same(a,w)){ idx=i; break; } }
    CK(idx<0, "Antares 专有音阶 'Ling Lun' 在 Waves 表里找不到 -> 不写入"); }
  printf("\n== 6. 归一化端点必须正好是 0 和 1 ==\n");
  CK((double)0/(WAVES_NSCALE-1)==0.0 && (double)(WAVES_NSCALE-1)/(WAVES_NSCALE-1)==1.0, "音阶首尾 = 0.0 / 1.0");
  CK((double)0/(WAVES_NROOT-1)==0.0 && (double)(WAVES_NROOT-1)/(WAVES_NROOT-1)==1.0, "根音首尾 = 0.0 / 1.0");
  printf("\n表大小: 音阶 %d, 根音 %d\n失败数: %d\n",WAVES_NSCALE,WAVES_NROOT,fails);
  return fails?1:0;
}
