/* Waves 每个大版本给壳起的名字都不一样:
     9.x   WaveShell-VST3 9.6_x64.vst3       (无数字)
     10.0  WaveShell3-VST3 10.0_x64.vst3     (3)
     11.0  WaveShell1-VST3 11.0_x64.vst3     (1),同一安装里还有 WaveShell2
     12.7  WaveShell1-VST3 12.7_x64.vst3     (1),自 11 起只有 64 位
     13.0  WaveShell1-VST3 13.0_x64.vst3     (1);导出表只有 3 个符号(与 16.7 的 4894 个对照,
                                             说明导出规模随版本大起大落,识别绝不能依赖它)
     14.19 WaveShell1-VST3 14.19_x64.vst3    (1);版本号首次出现两位小数
     16.7  WaveShell1-VST3 16.7_x64.vst3     (1);V15 起只有 VST3
     17.1  WaveShell1-VST3 17.1_x64.vst3     (1);与 16.7 同构,导出表亦同(4968 个符号)
   代码靠子串 "waveshell" 识别,所以与版本无关。这个测试把迄今见过的【所有】命名
   都过一遍源码里的四个真实判定点,防止日后有人把匹配"收紧"(比如改成 waveshell1)
   而悄悄丢掉某个版本。 */
#include <stdio.h>
#include <string.h>
static char g_catchPat[8][96]; static int g_nCatchPat=0, g_catchLoaded=0;
static void load_catch_list(void){ g_catchLoaded=1; strcpy(g_catchPat[g_nCatchPat++],"11.vst3"); strcpy(g_catchPat[g_nCatchPat++],"waveshell"); }
#include "t_shells_agent.inc"
#include "t_shells_ctl.inc"
static void lower(const char* s, char* o){ int i=0; for(;s[i];i++) o[i]=(char)at_lower((unsigned char)s[i]); o[i]=0; }
int main(void){
  /* 版本, 文件名 —— 全部来自用户实际提供的安装包 */
  const char* shells[][2]={
    {"9.6",  "WaveShell-VST 9.6.dll"},         {"9.6",  "WaveShell-VST 9.6_x64.dll"},
    {"9.6",  "WaveShell-VST3 9.6.vst3"},       {"9.6",  "WaveShell-VST3 9.6_x64.vst3"},
    {"9.7",  "WaveShell-VST 9.7.dll"},         {"9.7",  "WaveShell-VST 9.7_x64.dll"},
    {"9.7",  "WaveShell-VST3 9.7.vst3"},       {"9.7",  "WaveShell-VST3 9.7_x64.vst3"},
    {"10.0", "WaveShell3-VST 10.0.dll"},       {"10.0", "WaveShell3-VST 10.0_x64.dll"},
    {"10.0", "WaveShell3-VST3 10.0.vst3"},     {"10.0", "WaveShell3-VST3 10.0_x64.vst3"},
    {"11.0", "WaveShell1-VST3 11.0_x64.vst3"}, {"11.0", "WaveShell2-VST3 11.0_x64.vst3"},
    {"12.7", "WaveShell1-VST 12.7_x64.dll"},   {"12.7", "WaveShell1-VST3 12.7_x64.vst3"},
    {"13.0", "WaveShell1-VST 13.0_x64.dll"},   {"13.0", "WaveShell1-VST3 13.0_x64.vst3"},
    {"14.19","WaveShell1-VST 14.19_x64.dll"},  {"14.19","WaveShell1-VST3 14.19_x64.vst3"},
    {"16.7", "WaveShell1-VST3 16.7_x64.vst3"},                                 /* V15 起已无 VST2 壳 */
    {"17.1", "WaveShell1-VST3 17.1_x64.vst3"},                                 /* 同上;命名与 16.7 同构 */
    {0,0} };
  int fails=0, n=0;
  for(int i=0;shells[i][0];i++){
    char full[300]; snprintf(full,sizeof full,"C:\\Program Files\\Common Files\\VST3\\%s",shells[i][1]);
    char low[300]; lower(full,low);
    const char* leaf=shells[i][1];
    int ok = is_catch_path(low) && strstr_ci(leaf,"waveshell") && icontains(full,"waveshell");
    n++;
    if(!ok){ printf("   ✗ %-5s %s 未被识别\n",shells[i][0],leaf); fails++; }
  }
  printf("   %d 个壳文件(9.6 / 9.7 / 10.0 / 11.0 / 12.7 / 13.0 / 14.19 / 16.7 / 17.1,VST2+VST3,32+64 位)全部通过四个判定点: %s\n",
         n, fails?"否":"是");
  /* 反例:不是 Waves 壳的东西不能被误认 */
  const char* neg[]={"C:\\VST3\\Auto-Tune Pro.vst3","C:\\VST3\\FabFilter Pro-Q 3.vst3","C:\\VST\\Waves Tune.dll",0};
  for(int i=0;neg[i];i++){ char low[300]; lower(neg[i],low);
    if(icontains(neg[i],"waveshell")){ printf("   ✗ 误认:%s\n",neg[i]); fails++; } }
  printf("   反例 3 个均未被误认为壳\n");
  printf("\n失败数: %d\n",fails); return fails?1:0;
}
