static int key_to_pc(const char* k){                 /* "C","C#","C#/Db","Bb"... -> pitch class 0..11, or -1 */
    static const char* N2[10]={"C#","DB","D#","EB","F#","GB","G#","AB","A#","BB"}; static const int P2[10]={1,1,3,3,6,6,8,8,10,10};
    static const char* N1[7]={"C","D","E","F","G","A","B"}; static const int P1[7]={0,2,4,5,7,9,11};
    char u[8]=""; int j=0; for(int i=0;k[i]&&j<4;i++){ char ch=k[i]; u[j++]=(ch>='a'&&ch<='z')?(char)(ch-32):ch; } u[j]=0;
    for(int i=0;i<10;i++) if(strncmp(u,N2[i],2)==0) return P2[i];
    for(int i=0;i<7;i++) if(u[0]==N1[i][0]) return P1[i];
    return -1; }
