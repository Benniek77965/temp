static int at_lower(int c){ return (c>='A'&&c<='Z') ? c+32 : c; }
static int at_stricmp(const char* a, const char* b){
    for(;;){ int ca=at_lower((unsigned char)*a), cb=at_lower((unsigned char)*b);
             if(ca!=cb) return ca-cb;
             if(!ca) return 0;
             a++; b++; } }
