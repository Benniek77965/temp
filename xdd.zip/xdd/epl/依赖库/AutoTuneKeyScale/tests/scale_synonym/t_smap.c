/* scalemap.txt:丢弃必须说出来(1135)

   这个文件管音阶的等价匹配(Minor = Natural Minor = Aeolian)。它不生效时的症状是
   「选了音阶却匹配不上」—— 而原先的日志按【读到的行数】报数,
   `grp_add_line` 却会在满额或「只有一项」时静默不加。
   于是日志说"加了 N 组",实际可能一组都没加,用户照着日志以为生效了,
   根本不会往这里查。

   内置组是先加的,所以永远挤不掉(这点与 catch.txt 不同,那里要靠独立数组才做到)。 */
#include <stdio.h>
#include <string.h>
#include "t_smap_funcs.inc"

static int fails=0;
static void chk(const char* what,int got,int want){
    printf("   %-46s 返回 %-3d %s\n",what,got,(got==want)?"OK":"FAIL");
    if(got!=want) fails++;
}
int main(void){
    printf("== grp_add_line 必须如实返回结果 ==\n");
    g_nGrp=0; g_grpLoaded=1;
    chk("正常一组 -> 已加入",        grp_add_line("Minor|Natural Minor|Aeolian"), 1);
    chk("只有一项 -> 不足两项",      grp_add_line("OnlyOne"),                    -1);
    chk("空行 -> 不足两项",          grp_add_line(""),                           -1);
    chk("注释行 -> 不足两项",        grp_add_line("# a comment"),                -1);
    chk("再来一组 -> 已加入",        grp_add_line("Major|Ionian"),                1);

    printf("\n== 填满后必须报「满额」而不是静默丢 ==\n");
    while(g_nGrp < MAXGRP) grp_add_line("Fill|Filler");
    printf("   已填到 %d / %d\n",g_nGrp,MAXGRP);
    chk("满额 -> 明确返回 0",        grp_add_line("TooLate|Alias"),               0);

    printf("\n== 三种结果必须互相区分 ==\n");
    { int a=1,b=0,c=-1;
      printf("   已加入=%d 满额=%d 不足两项=%d  %s\n",a,b,c,(a!=b&&b!=c&&a!=c)?"OK":"FAIL");
      if(!(a!=b&&b!=c&&a!=c)) fails++; }
    printf("   ↑ 分不开的话,调用方就只能按「读到的行数」报数 —— 那正是被修掉的 bug\n");

    printf("\n失败数: %d\n",fails);
    return fails?1:0;
}
