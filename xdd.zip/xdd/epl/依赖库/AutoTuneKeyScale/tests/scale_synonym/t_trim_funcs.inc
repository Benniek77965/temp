static void trim(char* s){ int n=(int)strlen(s);
    for(int k=0;k<n;k++) if((unsigned char)s[k] < 0x20) s[k]=' ';
    while(n>0 && (s[n-1]==' '||s[n-1]=='\t')) s[--n]=0;
    int i=0; while(s[i]==' '||s[i]=='\t') i++; if(i) memmove(s,s+i,(size_t)(n-i+1)); }
static unsigned inst_id(const void* p){
    uintptr_t v=(uintptr_t)p;
    unsigned lo=(unsigned)v;
    unsigned hi=(sizeof(uintptr_t)>4) ? (unsigned)(((unsigned long long)v)>>32) : 0u;
    return lo ^ hi; }
