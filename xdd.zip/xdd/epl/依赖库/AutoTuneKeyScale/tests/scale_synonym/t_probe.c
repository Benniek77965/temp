/* 探测断路器:出事后该「转安全路径」而不是「禁用插件」(1105 改的语义)

   默认发现方式会先实例化一个一次性探针拿到 vtable,再对内存里"看起来像"该 vtable 的
   地址调方法。PACE 把这种试探当成攻击 —— 真机上同一个 Auto-Tune Pro、同一台机器,
   一次把宿主搞崩,另一次整个窗口卡死。

   断路器的【侦测】一直是对的:探测前把模块路径写盘,下次启动发现"那个进程已经死了"
   就说明它没扛过探测。错的是【反应】:原先把模块永久禁用 —— 等于用"扔掉这个插件"
   来解决崩溃,用户看到的是 Auto-Tune 干脆不出现了,而且只能靠手动删 disabled.txt 恢复。

   但"探测会弄死它"不等于"它不能用",而是"探测是错的找法"。catch 模式正是不探测的那条路:
   挂工厂钩子,在实例被创建的那一刻接住,全程不碰未知指针。
   所以 1105 改成把模块【提升到 catch 模式】,插件继续可用,且无需任何用户配置。 */
#include <stdio.h>
#include <string.h>

/* 复刻两种反应 */
static int old_reaction(int probeUnsafe,int catchM){      /* 1104 之前:禁用 */
    if(!catchM && probeUnsafe) return -1;                 /* -1 = 该模块被跳过,插件消失 */
    return catchM;                                        /* 0=探测路径 1=catch 路径 */
}
static int new_reaction(int probeUnsafe,int catchM){      /* 1105:提升到 catch */
    if(!catchM && probeUnsafe) return 1;
    return catchM;
}
static int fails=0;
static void chk(const char* what,int got,int want){
    const char* n[3]={"跳过(插件消失)","探测路径","catch 路径"};
    int gi=got<0?0:got+1, wi=want<0?0:want+1;
    int ok=(got==want);
    printf("   %-44s %-16s %s\n",what,n[gi],ok?"OK":("FAIL 期望 "));
    if(!ok){ printf("       期望 %s\n",n[wi]); fails++; }
}
int main(void){
    printf("== 曾经探测出事的模块 ==\n");
    chk("1104 之前的反应:禁用",      old_reaction(1,0), -1);
    chk("1105 的反应:转 catch 路径", new_reaction(1,0),  1);
    printf("   ↑ 同一个插件,旧反应让它从列表里消失,新反应让它继续可用\n");

    printf("\n== 没出过事的普通模块:行为不变 ==\n");
    chk("旧",  old_reaction(0,0), 0);
    chk("新",  new_reaction(0,0), 0);

    printf("\n== 本来就是 catch 模块(Waves / T-Pain):行为不变 ==\n");
    chk("旧(即使标记过)", old_reaction(1,1), 1);
    chk("新(即使标记过)", new_reaction(1,1), 1);

    printf("\n== 关键性质:新反应永远不会让插件消失 ==\n");
    { int gone=0;
      for(int u=0;u<2;u++) for(int c=0;c<2;c++) if(new_reaction(u,c)<0) gone++;
      printf("   四种组合里「插件消失」出现 %d 次 %s\n",gone,gone==0?"OK":"FAIL");
      if(gone) fails++; }
    { int gone=0;
      for(int u=0;u<2;u++) for(int c=0;c<2;c++) if(old_reaction(u,c)<0) gone++;
      printf("   旧反应则有 %d 次(这正是被修掉的行为)\n",gone); }

    printf("\n== 文件改名:名字必须说出它真正的含义(1114) ==\n");
    { /* 1105 前 disabled.txt = 禁用该模块(插件消失)
         1105 后它的含义变成 = 该模块改走不探测的安全路径(插件照常可用)
         名字没跟着改,用户照字面理解去删它,等于把模块送回会崩会卡的探测路径 */
      const char* oldName="disabled.txt";
      const char* newName="use_factory_hook.txt";
      int oldMisleads = 1;   /* "disabled" 读起来像"你的东西被关掉了" */
      int newDescribes = 1;  /* "use factory hook" 说的就是它实际做的事 */
      printf("   旧名 %-22s 会被误解 -> %s\n",oldName,oldMisleads?"是":"否");
      printf("   新名 %-22s 描述实际行为 -> %s\n",newName,newDescribes?"是":"否");
      if(!(oldMisleads&&newDescribes)) fails++; }

    printf("\n== 改名必须兼容已存在的旧文件 ==\n");
    { /* 两份都读,且同一模块只记一次 */
      struct { int inNew, inOld, wantEntries; const char* why; } C[]={
        {1,0,1,"只有新文件"},
        {0,1,1,"只有旧文件(老用户升级上来)"},
        {1,1,1,"两份都列了同一模块 -> 去重"},
        {0,0,0,"都没有"}};
      for(int i=0;i<4;i++){
        int n = (C[i].inNew||C[i].inOld) ? 1 : 0;   /* 去重后的条数 */
        int ok = (n==C[i].wantEntries);
        printf("   %-30s 记录 %d 条 %s\n",C[i].why,n,ok?"OK":"FAIL");
        if(!ok) fails++; } }
    printf("   ↑ 漏读旧文件 = 老用户的模块突然又去走探测路径,等于把已修的问题放回去\n");

    printf("\n== 重复注入的副本必须什么都不碰(1116) ==\n");
    { /* 控制器偶尔会对"误判为已退出"的宿主重复注入;副本应认出互斥量后立刻卸载。
         原先顺序是 resolve_commdir -> cb_startup -> 抢互斥量,
         而 cb_startup 结尾会清空【本进程】的 pending 标记 ——
         那标记属于正在运行的那个 agent,若它此刻正在探测,标记就被副本抹掉了。 */
      /* 步骤编号:0=抢互斥量 1=resolve_commdir 2=cb_startup(会清 pending) */
      int oldOrder[3]={1,2,0};   /* 1116 之前 */
      int newOrder[3]={0,1,2};   /* 1116 */
      /* 副本在抢到互斥量失败那一步退出;看它退出前是否已执行过"清 pending"(步骤 2) */
      int oldTouched=0, newTouched=0;
      for(int i=0;i<3;i++){ if(oldOrder[i]==0) break; if(oldOrder[i]==2) oldTouched=1; }
      for(int i=0;i<3;i++){ if(newOrder[i]==0) break; if(newOrder[i]==2) newTouched=1; }
      printf("   旧顺序:副本退出前清掉了正在运行者的 pending -> %s\n",oldTouched?"是(即 bug)":"否");
      printf("   新顺序:副本退出前什么都没碰 -> %s\n",newTouched?"否":"是");
      if(!oldTouched) fails++;
      if(newTouched)  fails++; }
    printf("   ↑ 后果:真崩溃时无从归因 -> 断路器不触发 -> 同一插件下次还会把宿主搞崩\n");

    printf("\n失败数: %d\n",fails);
    return fails?1:0;
}
