/* 验证 agent 的状态行格式 <-> 控制器的解析/剥离/同名编号 能对上 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define _stricmp strcasecmp
int main(void){
  /* agent 真实写法: "proc | leaf  Key=..  Scale=..\x01<id8> <caps>\n" */
  char buf[1024];
  snprintf(buf,sizeof buf,
    "Sam_x64.exe | Waves Tune Real-Time Mono  Key=C  Scale=Minor  Spd=15%%\x01" "1DC8DF90 KSRHV\n"
    "Sam_x64.exe | Waves Tune Real-Time Mono  Key=A  Scale=Major\x01" "217B1700 KSRHV\n"
    "Sam_x64.exe | \xB5\xE7\xD2\xF5" "11.vst3  Key=C  Scale=Minor  Rtn=73%%\x01" "18F23EE0 KSRHVA\n");
    /* 注意那两处断开:\xF5 后面紧跟 "11" 会被当成一个超长十六进制转义(\xF511),
       "11" 随之丢失,模块名就不再以 11.vst3 结尾 —— 而那正是电音11 进 catch 列表的依据。
       本文件对 \x01 已经这么做了,唯独这一处漏了。 */
  struct { char leaf[96]; char label[160]; unsigned id; char caps[16]; } inst[8]; int n=0;
  char disp[1024]=""; int fail=0;
  for(char* lp=buf; *lp; ){
    char* nl=strchr(lp,'\n'); int ll = nl?(int)(nl-lp):(int)strlen(lp);
    if(ll>0){ char ln[256]; int cp=ll<255?ll:255; memcpy(ln,lp,cp); ln[cp]=0;
      unsigned lid=0; char lcaps[16]="KS";
      { char* meta=strchr(ln,'\x01');
        if(meta){ *meta=0; lid=(unsigned)strtoul(meta+1,NULL,16);
                  char* sp=strchr(meta+1,' ');
                  if(sp){ int q=0; sp++; while(sp[q]&&sp[q]!=' '&&q<15){lcaps[q]=sp[q];q++;} lcaps[q]=0; } } }
      char* bar=strstr(ln," | ");
      if(bar){ char* lf=bar+3; char* dd=strstr(lf,"  ");
        int leaflen=dd?(int)(dd-lf):(int)strlen(lf); int lbllen=dd?(int)(dd-ln):(int)strlen(ln);
        memcpy(inst[n].leaf,lf,leaflen); inst[n].leaf[leaflen]=0;
        memcpy(inst[n].label,ln,lbllen); inst[n].label[lbllen]=0;
        inst[n].id=lid; snprintf(inst[n].caps,16,"%s",lcaps); n++; }
      strcat(disp,ln); strcat(disp,"\n"); }
    if(!nl) break; lp=nl+1; }
  #define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fail++;} }while(0)
  printf("解析出 %d 个实例:\n",n);
  for(int i=0;i<n;i++) printf("   leaf='%s' id=%08X caps=%s\n",inst[i].leaf,inst[i].id,inst[i].caps);
  printf("\n用户看到的文本(元数据应已剥离):\n%s",disp);
  CK(n==3,"三行全部解析");
  CK(strchr(disp,'\x01')==NULL,"显示文本里不含任何 \\x01 元数据");
  CK(inst[0].id==0x1DC8DF90 && inst[1].id==0x217B1700,"两个同名实例拿到不同 id -> 可分别定向");
  CK(strcmp(inst[0].leaf,inst[1].leaf)==0,"它们文件名确实相同(正是旧版分不开的场景)");
  CK(strcmp(inst[2].caps,"KSRHVA")==0 && strcmp(inst[0].caps,"KSRHV")==0,"能力位按实例解析正确");
  /* 同名编号 */
  for(int i=0;i<n;i++){ int ord=0,dups=0;
    for(int j=0;j<n;j++) if(_stricmp(inst[j].leaf,inst[i].leaf)==0){ dups++; if(j<=i) ord++; }
    char d2[200]; if(dups>1) snprintf(d2,sizeof d2,"%s  #%d",inst[i].label,ord); else snprintf(d2,sizeof d2,"%s",inst[i].label);
    printf("   Target[%d] = %s\n",i+1,d2);
    if(i<2 && !strstr(d2,"#")) { printf("   FAIL 同名实例未编号\n"); fail++; }
    if(i==2 && strstr(d2,"#")) { printf("   FAIL 唯一实例不该编号\n"); fail++; } }
  CK(1,"同名实例已编号 #1/#2,唯一实例不编号");
  printf("\n失败数: %d\n",fail); return fail?1:0;
}
