/* 卸载时序:拆钩子之前必须先封死"安装新钩子"(1102 修的问题)

   agent 卸载时要把所有指向自身 DLL 的补丁从插件 vtable 里撤掉,否则 DLL 一卸载
   宿主下次调用就跳进空地址。原先的顺序是:

       remove_*_hooks()  ->  释放引用  ->  Sleep + 等 g_inHook 排空  ->  卸载

   注释写的是"新调用再也到不了我们这里"。这对【进入】钩子成立,但对【安装】不成立:
   一个在拆钩之前就已经进入钩子的宿主线程,可以在拆完之后才执行到安装动作
   (patch_create_on_factory / hook_component_initialize / hook_setcomponenthandler),
   把指向本 DLL 的指针重新写回 vtable —— 而那之后再没有谁会去撤它。
   末尾等 g_inHook 排空也救不了:等到线程离开时,指针早就写进去了。

   1102 改为:先立 g_ejecting 并等在飞的调用跑完,再拆钩子;
   三个安装函数都在入口检查该标志。

   1164: 上述历史时序模型只验证安装门禁，不再把零回调计数当作物理卸载许可。
   真正路径为 PIN 模块、逻辑停用、保留只读生命周期观察者；运行行为由 companion/t_suspend 覆盖。 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)

/* 复刻安装函数的入口判定 */
static int may_install(int ejecting){ return !ejecting; }

/* 把一次卸载按步骤走一遍,返回"是否留下了悬空补丁"
   installAt: 宿主线程执行到安装动作的时刻(步骤序号) */
static int dangling(int newOrder,int installAt){
    int ejecting=0, removed=0, patched=0;
    /* 步骤 0..3 */
    for(int step=0; step<4; step++){
        if(newOrder){
            if(step==0) ejecting=1;        /* 新:先立标志 */
            if(step==1) ;                  /*    再等在飞调用跑完 */
            if(step==2) removed=1;         /*    然后才拆钩子 */
        } else {
            if(step==0) removed=1;         /* 旧:直接拆钩子 */
        }
        if(step==installAt && may_install(ejecting)) patched=1;
    }
    return patched && removed;             /* 拆完之后还被装上 -> 悬空 */
}

int main(void){
    printf("== 旧顺序:先拆钩子,在飞的调用仍能装回去 ==\n");
    CK( dangling(0,1), "安装发生在拆钩之后 -> 留下悬空补丁(这正是 bug)");
    CK(!dangling(0,0)||1, "(安装与拆钩同步骤:时序不确定,不作断言)");

    printf("\n== 新顺序:标志先立,安装被拒 ==\n");
    for(int at=0; at<4; at++){
        char m[80]; snprintf(m,sizeof m,"宿主线程在步骤 %d 执行安装 -> 不留悬空",at);
        CK(!dangling(1,at), m);
    }

    printf("\n== 安装函数入口判定 ==\n");
    CK( may_install(0), "未卸载 -> 允许安装");
    CK(!may_install(1), "卸载中 -> 拒绝安装");

    printf("\n受保护的安装点:\n");
    printf("   patch_create_on_factory      (gpf_call / hook_factory)\n");
    printf("   hook_component_initialize    (myCreateInstance_inner)\n");
    printf("   hook_setcomponenthandler     (myCreateInstance_inner / myInitialize_inner)\n");
    printf("   ui_attach                    (ui_post) —— 1145 新增,窗口子类化同样是指向本 DLL 的补丁\n");

    printf("\n== 三个安装点必须【全部】受保护(1123) ==\n");
    { /* 变异测试发现:只删掉三处中的一处,t_claims 的存在性检查仍然通过。
         保护必须按数量核对 —— 少一处就等于留了一个口子。 */
      FILE* f=fopen("at_agent.cpp","r");
      if(!f){ printf("   跳过:未找到 at_agent.cpp(请先从源码目录复制)\n"); }
      else{ char ln[2048]; int n=0;
        while(fgets(ln,sizeof ln,f)) if(strstr(ln,"if(g_ejecting) return;")) n++;
        fclose(f);
        printf("   g_ejecting 检查点:找到 %d 处(应为 3)  %s\n", n, n==3?"OK":"FAIL");
        if(n!=3) fails++;
        printf("   三处分别对应:patch_create_on_factory / hook_component_initialize / hook_setcomponenthandler\n"); } }

    printf("\n== 第四个安装点 ui_attach 也必须受保护(1145) ==\n");
    { /* 1145 把参数写入搬到宿主界面线程,做法是给宿主的一个窗口挂子类化 —— 那同样是一个
         指向本 DLL 的函数指针,卸载后宿主下一条消息就会打到已解除映射的内存。
         它返回 int,所以写法是 "return 0;",上面那条按字面串计数的守卫抓不到它:
         必须单独核对,否则这个口子没有任何测试覆盖。 */
      FILE* f=fopen("at_agent.cpp","r");
      if(!f){ printf("   跳过:未找到 at_agent.cpp\n"); }
      else{ char buf[400000]; size_t n=fread(buf,1,sizeof buf-1,f); buf[n]=0; fclose(f);
        char* a=strstr(buf,"static int ui_attach(DWORD tid){");
        if(!a){ printf("   FAIL 找不到 ui_attach —— 签名改了?这条守卫已失效\n"); fails++; }
        else{ char* b=strchr(a,'{'); int d=0; char* q=b;
              for(;;){ if(*q=='{')d++; else if(*q=='}')d--; if(!d) break; q++; }
              char save=*q; *q=0;
              int ok = strstr(a,"g_ejecting")!=NULL;
              *q=save;
              printf("   ui_attach 内有 g_ejecting 检查:%s\n", ok?"OK":"FAIL");
              if(!ok) fails++; }
        /* 限定真实停用函数，防止其它调用点掩盖撤钩或禁写的遗漏。 */
        char* ej=strstr(buf,"static void agent_suspend(){");
        char* lim=ej?strstr(ej,"static void agent_resume(){"):NULL;
        if(!ej||!lim){ CK(0,"找到真实安全停用与恢复函数"); }
        else{ char save=*lim;*lim=0;
              char* gate=strstr(ej,"InterlockedExchange(&g_ejecting,1)");
              char* detach=strstr(ej,"ui_detach();");
              CK(gate&&detach&&gate<detach,"停用先禁止写入与安装，再清选择（保留只读转发）");
              CK(strstr(ej,"agent_cancel_posted_writes();")!=NULL,"停用取消尚未执行的UI写入");
              CK(strstr(ej,"remove_eat_hooks();")&&strstr(ej,"remove_factory_hooks();")&&strstr(ej,"remove_init_hooks();"),"停用撤掉主动发现及初始化挂钩");
              CK(strstr(ej,"remove_ch_hooks();")==NULL,"停用保留只读handler生命周期观察者");
              CK(strstr(ej,"FreeLibrary")==NULL,"停用路径禁止物理解除映射");
              *lim=save; }
        { char* worker=strstr(buf,"static DWORD WINAPI worker(LPVOID){");
          char* pin=worker?strstr(worker,"GetModuleHandleExA(0x1|0x4"):NULL;
          char* disk=worker?strstr(worker,"resolve_commdir()"):NULL;
          CK(pin&&disk&&pin<disk,"worker在接触磁盘及安装挂钩前PIN自身映像");
          CK(pin&&disk&&strstr(disk,"FreeLibraryAndExitThread")==NULL,"成功PIN并进入运行后无物理卸载（允许PIN失败退出）"); }
        /* 私有写入回调仍记录g_inHook以供诊断；PIN而非零计数承担映像生命周期。 */
        char* w=strstr(buf,"static LRESULT CALLBACK at_wndproc(");
        if(!w){ printf("   FAIL 找不到 at_wndproc\n"); fails++; }
        else{ char* b2=strchr(w,'{'); int d2=0; char* q2=b2;
              for(;;){ if(*q2=='{')d2++; else if(*q2=='}')d2--; if(!d2) break; q2++; }
              char sv2=*q2; *q2=0;
              int inc = strstr(w,"InterlockedIncrement(&g_inHook)")!=NULL;
              int dec = strstr(w,"InterlockedDecrement(&g_inHook)")!=NULL;
              *q2=sv2;
              printf("   at_wndproc 计入 g_inHook:%s\n", (inc&&dec)?"OK":"FAIL");
              if(!(inc&&dec)) fails++; } } }

    printf("\n失败数: %d\n",fails);
    return fails?1:0;
}
