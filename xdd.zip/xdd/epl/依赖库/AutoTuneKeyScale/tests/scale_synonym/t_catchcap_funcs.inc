/* 由 extract.py 从源码生成,请勿手工编辑。源码一改,重新跑一次即可。 */
static char g_catchPat[8][64]; static int g_nCatchPat=0; static int g_catchLoaded=0;
static const char* const g_catchBuiltin[] = { "11.vst3", "waveshell", "t-pain", "auto-tune", NULL };
static int is_catch_path(const char* low){ 
    for(int i=0;g_catchBuiltin[i];i++) if(strstr(low,g_catchBuiltin[i])) return 1;   /* built-ins always apply */
    for(int i=0;i<g_nCatchPat;i++) if(g_catchPat[i][0] && strstr(low,g_catchPat[i])) return 1;
    return 0; }
