/* 崩溃记录器(1148)在 Windows(或 Wine)上的实测。生产代码本体:直接 #include at_agent.cpp。
   父进程以子进程方式启动自己;子进程装上生产代码的顶层过滤器,在指定线程上真实地制造访问违例。
   检查:子进程是否按预期把异常交还给"之前就装着的过滤器"(它以退出码 77 结束进程),
   以及 agent.log 里那一行写对了没有。另有直接调用过滤器的单元检查。 */
#include "../../combined/at_agent.cpp"
#include <stdio.h>
static int fails=0;
static void ck(int c,const char* m){ printf("   %s %s\n",c?"OK  ":"FAIL",m); if(!c) fails++; }
static char g_tlog[MAX_PATH];
static LONG WINAPI prev_filter(EXCEPTION_POINTERS*){ ExitProcess(77); return EXCEPTION_EXECUTE_HANDLER; }
static volatile int* volatile g_null=NULL;
static DWORD WINAPI crasher(LPVOID){ *g_null=1; return 0; }
static DWORD WINAPI as_worker_crasher(LPVOID){ g_workerTid=GetCurrentThreadId(); *g_null=1; return 0; }
/* 崩溃发生在另一个模块(系统 DLL)里,但由"agent"的代码调用进去 —— 模拟 agent 的钩子调用插件、插件崩溃 */
static __attribute__((noinline)) int call_into_other_module(){ return MultiByteToWideChar(CP_ACP,0,"abcdef",6,(LPWSTR)(ULONG_PTR)8,6); }
static DWORD WINAPI via_other_module(LPVOID){ volatile int r=call_into_other_module(); (void)r; return 0; }
/* 1159:宿主界面线程被 agent 子类化之后,宿主自己的窗口过程在处理消息时崩溃。消息经过 at_wndproc 的转发
   (CallWindowProc 是普通调用,不是尾跳转),所以栈上一定有 agent 的返回地址。 */
static LRESULT CALLBACK host_proc(HWND h, UINT m, WPARAM w, LPARAM l){
    if(m==WM_APP+9){ volatile int r=call_into_other_module(); (void)r; return 0; }   /* 宿主自己的代码崩在系统 DLL 里 */
    return DefWindowProcW(h,m,w,l); }
static HANDLE fwdReady=NULL;static HWND fwdWindow=NULL;static DWORD fwdTid=0;
static DWORD WINAPI fwd_thread(LPVOID busy){
    WNDCLASSW wc; memset(&wc,0,sizeof wc); wc.lpfnWndProc=host_proc; wc.hInstance=GetModuleHandleW(NULL); wc.lpszClassName=L"w_crash_host";
    RegisterClassW(&wc);
    HWND h=CreateWindowW(L"w_crash_host",L"host",WS_OVERLAPPEDWINDOW,0,0,10,10,NULL,NULL,wc.hInstance,NULL);
    if(!h)ExitProcess(6);
    fwdWindow=h;fwdTid=GetCurrentThreadId();
    if(busy)InterlockedIncrement(&g_inHook); /* diagnostic comparison: another hook is active */
    SetEvent(fwdReady);
    /* The real asynchronous owner installer needs this thread to pump. The
       worker requests the subclass, then posts the crash message after ACK. */
    MSG message;while(GetMessageW(&message,NULL,0,0)>0){TranslateMessage(&message);DispatchMessageW(&message);}
    return 0;
}
static void child(const char* mode){
    snprintf(g_logPath,sizeof g_logPath,"%s",g_tlog); g_logTick0=GetTickCount(); g_logHostMs0=0;
    g_self=GetModuleHandleA(NULL);                 /* 测试里 agent 代码就编进了本 exe */
    SetUnhandledExceptionFilter(prev_filter);      /* 宿主"之前就装着"的过滤器 */
    crash_record_install();
    if(!strcmp(mode,"probing")) snprintf(g_pendNow,sizeof g_pendNow,"C:\\\\VST3\\\\Some Plugin.vst3");
    LPTHREAD_START_ROUTINE fn = !strcmp(mode,"worker")?as_worker_crasher : !strcmp(mode,"via")?via_other_module
                              : (!strcmp(mode,"fwd")||!strcmp(mode,"fwdbusy"))?fwd_thread : crasher;
    int forwarding=!strcmp(mode,"fwd")||!strcmp(mode,"fwdbusy");
    if(forwarding)fwdReady=CreateEventW(NULL,TRUE,FALSE,NULL);
    HANDLE t=CreateThread(NULL,0,fn,(LPVOID)(ULONG_PTR)(!strcmp(mode,"fwdbusy")?1:0),0,NULL);
    if(forwarding){
        if(WaitForSingleObject(fwdReady,5000)!=WAIT_OBJECT_0||!ui_attach(fwdTid))ExitProcess(6);
        if(g_uiWnd!=fwdWindow||g_uiWndTid!=fwdTid)ExitProcess(7);
        PostMessageW(fwdWindow,WM_APP+9,0,0); /* ordinary observer forwards into the host crash */
    }
    WaitForSingleObject(t,10000); ExitProcess(5); }   /* 不该走到这里 */
static int read_log(char* buf,int cap){ FILE* f=fopen(g_tlog,"rb"); if(!f) return 0; int n=(int)fread(buf,1,cap-1,f); fclose(f); buf[n>0?n:0]=0; return n; }
static DWORD run_child(const char* self,const char* mode){
    DeleteFileA(g_tlog);
    char cmd[1024]; snprintf(cmd,sizeof cmd,"\"%s\" child %s",self,mode);
    STARTUPINFOA si; memset(&si,0,sizeof si); si.cb=sizeof si; PROCESS_INFORMATION pi;
    if(!CreateProcessA(NULL,cmd,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi)) return 0xFFFFFFFF;
    WaitForSingleObject(pi.hProcess,20000); DWORD ec=0; GetExitCodeProcess(pi.hProcess,&ec);
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess); return ec; }
int main(int argc,char** argv){
    char tmp[MAX_PATH]; GetTempPathA(sizeof tmp,tmp); snprintf(g_tlog,sizeof g_tlog,"%sw_crash_agent.log",tmp);
    if(argc>=3 && !strcmp(argv[1],"child")){ child(argv[2]); return 0; }
    char self[MAX_PATH]; GetModuleFileNameA(NULL,self,sizeof self);
    const char* leaf=strrchr(self,'\\'); leaf=leaf?leaf+1:self;
    char lg[4096];

    printf("== 一、宿主线程上真实崩溃 ==\n");
    { DWORD ec=run_child(self,"host"); int n=read_log(lg,sizeof lg);
      ck(ec==77, "异常被原样交还给之前就装着的过滤器(子进程以它的退出码 77 结束)");
      ck(n>0 && strstr(lg,"CRASH: exception 0xC0000005")!=NULL, "agent.log 里写下了 CRASH 行与异常码");
      ck(strstr(lg,leaf)!=NULL, "指出了崩溃所在的模块");
      ck(strstr(lg,"(writing ")!=NULL, "访问违例说明了是写入以及目标地址");
      ck(strstr(lg,"on a host thread")!=NULL, "判断出是宿主线程");
      ck(strstr(lg,"agent code on that thread's stack")!=NULL, "报告了 agent 是否在调用路径上");
      int lines=0; for(char* p=lg;*p;p++) if(*p=='\n') lines++;
      ck(lines==1 && lg[n-1]=='\n', "恰好一行,以换行收尾");
      printf("        %s",lg); }

    printf("\n== 二、worker 线程上真实崩溃 ==\n");
    { DWORD ec=run_child(self,"worker"); read_log(lg,sizeof lg);
      ck(ec==77 && strstr(lg,"on the agent's worker thread")!=NULL, "判断出是 agent 的 worker 线程,并照样交还"); }

    printf("\n== 三、崩在 worker 探测某个模块的时候 ==\n");
    { DWORD ec=run_child(self,"probing"); read_log(lg,sizeof lg);
      ck(ec==77 && strstr(lg,"worker was probing C:\\\\VST3\\\\Some Plugin.vst3")!=NULL, "写出了断路器当时正在探测的模块"); }

    printf("\n== 三之二、崩在别的模块里,但 agent 在调用链上(钩子调用插件、插件崩溃的情形) ==\n");
    { DWORD ec=run_child(self,"via"); read_log(lg,sizeof lg);
      ck(ec==77, "照样交还");
      ck(strstr(lg,leaf)==NULL || strstr(lg,"INSIDE THE AGENT")==NULL, "崩溃点不在 agent 里");
      ck(strstr(lg,"(the agent was on the call path)")!=NULL, "栈上找到了 agent 的返回地址:agent 在调用链上");
      printf("        %s",lg); }
    { DWORD ec=run_child(self,"host"); read_log(lg,sizeof lg);
      ck(ec==77 && strstr(lg,"INSIDE THE AGENT")!=NULL && strstr(lg,"call path")==NULL, "崩溃就在 agent 里时,不再附带自相矛盾的'不在调用链上'"); }

    printf("\n== 三之三、子类化之后,宿主自己的窗口过程崩溃(1159) ==\n");
    { DWORD ec=run_child(self,"fwd"); read_log(lg,sizeof lg);
      ck(ec==77, "前提成立并照样交还:子类确实挂在这个窗口上、界面线程号对得上(否则子进程以 6/7 退出,不会崩到这里)");
      ck(strstr(lg,"(only the agent's window-subclass pass-through: the agent was idle on this thread)")!=NULL
         && strstr(lg,"(the agent was on the call path)")==NULL,
         "agent 空闲:栈上只有转发帧 —— 不再说'agent 在调用链上'");
      const char* cl=strstr(lg,"CRASH:"); if(cl){ char one[400]; int i=0; while(cl[i] && cl[i]!='\n' && i<399){ one[i]=cl[i]; i++; } one[i]=0; printf("        %s\n",one); } }
    { DWORD ec=run_child(self,"fwdbusy"); read_log(lg,sizeof lg);
      ck(ec==77 && strstr(lg,"(the agent was on the call path)")!=NULL && strstr(lg,"pass-through")==NULL,
         "对照组:有钩子正在运行时,保持'agent 在调用链上'(没把握就不改口)"); }

    printf("\n== 四、直接调用:只记一行、没有前任时交还系统、卸载时还原 ==\n");
    { snprintf(g_logPath,sizeof g_logPath,"%s",g_tlog); DeleteFileA(g_tlog); g_self=GetModuleHandleA(NULL);
      LPTOP_LEVEL_EXCEPTION_FILTER before=SetUnhandledExceptionFilter(NULL);   /* 没有前任 */
      crash_record_install();
      EXCEPTION_RECORD er; memset(&er,0,sizeof er); er.ExceptionCode=0xC00000FD; er.ExceptionAddress=(void*)main;
      CONTEXT cx; memset(&cx,0,sizeof cx);
#ifdef _WIN64
      cx.Rsp=(DWORD64)(ULONG_PTR)&er;
#else
      cx.Esp=(DWORD)(ULONG_PTR)&er;
#endif
      EXCEPTION_POINTERS ep={&er,&cx};
      LONG r1=agent_uef(&ep), r2=agent_uef(&ep);
      int n=read_log(lg,sizeof lg); int lines=0; for(char* p=lg;*p;p++) if(*p=='\n') lines++;
      ck(r1==EXCEPTION_CONTINUE_SEARCH && r2==EXCEPTION_CONTINUE_SEARCH, "没有前任过滤器时交还系统(EXCEPTION_CONTINUE_SEARCH)");
      ck(n>0 && lines==1 && strstr(lg,"0xC00000FD")!=NULL, "被调用两次也只记一行(防重入)");
      crash_record_remove();
      LPTOP_LEVEL_EXCEPTION_FILTER now=SetUnhandledExceptionFilter(before);
      ck(now==NULL, "卸载时把顶层过滤器还原为装之前的那个");
      g_inUef=0; }

    DeleteFileA(g_tlog);
    printf("\n失败数: %d\n",fails); return fails?1:0; }
