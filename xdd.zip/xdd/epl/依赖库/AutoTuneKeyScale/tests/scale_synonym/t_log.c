/* 日志整行一次写出:截断与边界是这类改写最容易出错的地方。
   1148 起测的是从源码提取的 log_compose(此前是 LOG 函数体的一段手工复刻,源码改了也无人察觉),
   并多验两件事:每行带"机架启动后多少秒"的时间;超长记录截断后不得混入 NUL 字节。
   旧测试自身还有越界写:out[1024] 之后 out[outn]=0,而旧代码截断时 outn 正好是 1024。 */
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "t_log_funcs.inc"
static char out[1100]; static int outn;
static void LOGTEST(unsigned long ms, const char* fmt,...){
    char line[1024]; va_list ap; va_start(ap,fmt);
    int n=log_compose(line,(int)sizeof line,5488,ms,fmt,ap);
    va_end(ap);
    memcpy(out,line,(size_t)n); outn=n; out[outn]=0; }
static int fails=0;
#define CK(c,m) do{ if(c) printf("   OK   %s\n",m); else {printf("   FAIL %s\n",m); fails++;} }while(0)
int main(void){
  printf("== 1. 普通记录 ==\n");
  LOGTEST(12345,"hello %d",42);
  CK(!strcmp(out,"[5488] +12.345 hello 42\n"), "pid + 时间 + 正文 + 换行,一次成型");
  CK(out[outn-1]=='\n', "必定以换行收尾");

  printf("\n== 2. 超长正文必须截断且仍然以换行收尾 ==\n");
  char big[4000]; memset(big,'X',sizeof big-1); big[sizeof big-1]=0;
  LOGTEST(7,"%s",big);
  CK(outn<=1023, "不超出缓冲(且留得下结尾的 0)");
  CK(out[outn-1]=='\n', "截断后仍以换行收尾");
  CK(strncmp(out,"[5488] +0.007 XXX",17)==0, "前缀与时间未被挤掉");
  { int nul=0; for(int i=0;i<outn;i++) if(out[i]==0) nul=1;
    CK(!nul, "截断的记录里没有 NUL 字节(旧拼法会在换行前留一个,工具会把整个日志当成二进制)"); }

  printf("\n== 3. 恰好填满边界 ==\n");
  for(int len=990; len<=1020; len++){
      char fit[1100]; memset(fit,'Y',(size_t)len); fit[len]=0;
      LOGTEST(1,"%s",fit);
      int nul=0; for(int i=0;i<outn;i++) if(out[i]==0) nul=1;
      if(!(outn<=1023 && out[outn-1]=='\n' && !nul)){ printf("   FAIL 正文长 %d 时出错\n",len); fails++; break; } }
  printf("   OK   正文长 990..1020 逐一检查:不越界、仍有换行、无 NUL\n");

  printf("\n== 4. 空正文 ==\n");
  LOGTEST(0,"%s","");
  CK(!strcmp(out,"[5488] +0.000 \n"), "空正文也产生合法记录");

  printf("\n== 5. 时间的格式 ==\n");
  LOGTEST(999,"a");   CK(!strcmp(out,"[5488] +0.999 a\n"), "999 ms -> +0.999");
  LOGTEST(1000,"a");  CK(!strcmp(out,"[5488] +1.000 a\n"), "1000 ms -> +1.000(进位正确)");
  LOGTEST(4294967295UL,"a"); CK(!strcmp(out,"[5488] +4294967.295 a\n"), "最大值不溢出");

  printf("\n失败数: %d\n",fails); return fails?1:0;
}
