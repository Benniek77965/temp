/*
 * vst2abi.h - minimal, self-written VST 2.x binary-interface declarations
 * (struct layout / opcode numbers only; enough to host or wrap a 32-bit VST2 plug-in).
 * Not derived from the Steinberg SDK source; values follow the public VST2 ABI.
 */
#ifndef VST2ABI_H
#define VST2ABI_H
#include <stdint.h>

#define VSTCB __cdecl
#define kEffectMagic 0x56737450 /* 'VstP' */

typedef struct AEffect AEffect;
typedef intptr_t (VSTCB *audioMasterCallback)(AEffect*, int32_t op, int32_t idx, intptr_t val, void* ptr, float opt);
typedef intptr_t (VSTCB *AEffectDispatcherProc)(AEffect*, int32_t op, int32_t idx, intptr_t val, void* ptr, float opt);
typedef void     (VSTCB *AEffectProcessProc)(AEffect*, float** in, float** out, int32_t frames);
typedef void     (VSTCB *AEffectProcessDoubleProc)(AEffect*, double** in, double** out, int32_t frames);
typedef void     (VSTCB *AEffectSetParameterProc)(AEffect*, int32_t idx, float v);
typedef float    (VSTCB *AEffectGetParameterProc)(AEffect*, int32_t idx);
typedef AEffect* (VSTCB *VstMainProc)(audioMasterCallback);

#pragma pack(push, 8)
struct AEffect {
    int32_t magic;
    AEffectDispatcherProc dispatcher;
    AEffectProcessProc process;              /* deprecated accumulating process */
    AEffectSetParameterProc setParameter;
    AEffectGetParameterProc getParameter;
    int32_t numPrograms;
    int32_t numParams;
    int32_t numInputs;
    int32_t numOutputs;
    int32_t flags;
    intptr_t resvd1;
    intptr_t resvd2;
    int32_t initialDelay;
    int32_t realQualities;
    int32_t offQualities;
    float   ioRatio;
    void*   object;
    void*   user;
    int32_t uniqueID;
    int32_t version;
    AEffectProcessProc processReplacing;
    AEffectProcessDoubleProc processDoubleReplacing;
    char    future[56];
};

typedef struct VstParameterProperties {
    float stepFloat, smallStepFloat, largeStepFloat;
    char  label[64];
    int32_t flags;
    int32_t minInteger, maxInteger, stepInteger, largeStepInteger;
    char  shortLabel[8];
    int16_t displayIndex, category, numParametersInCategory, reserved;
    char  categoryLabel[24];
    char  future[16];
} VstParameterProperties;

typedef struct VstTimeInfo {
    double samplePos, sampleRate, nanoSeconds, ppqPos, tempo, barStartPos, cycleStartPos, cycleEndPos;
    int32_t timeSigNumerator, timeSigDenominator, smpteOffset, smpteFrameRate, samplesToNextClock, flags;
} VstTimeInfo;

typedef struct VstEvent { int32_t type, byteSize, deltaFrames, flags; char data[16]; } VstEvent;
typedef struct VstMidiEvent {
    int32_t type, byteSize, deltaFrames, flags, noteLength, noteOffset;
    char midiData[4]; char detune, noteOffVelocity, reserved1, reserved2;
} VstMidiEvent;
typedef struct VstEvents { int32_t numEvents; intptr_t reserved; VstEvent* events[2]; } VstEvents;
#pragma pack(pop)

/* effect flags */
enum { effFlagsHasEditor = 1, effFlagsCanReplacing = 1 << 4, effFlagsProgramChunks = 1 << 5,
       effFlagsIsSynth = 1 << 8, effFlagsNoSoundInStop = 1 << 9, effFlagsCanDoubleReplacing = 1 << 12 };

/* dispatcher opcodes (plug-in side) */
enum {
    effOpen = 0, effClose, effSetProgram, effGetProgram, effSetProgramName, effGetProgramName,
    effGetParamLabel, effGetParamDisplay, effGetParamName, effGetVu, effSetSampleRate, effSetBlockSize,
    effMainsChanged, effEditGetRect, effEditOpen, effEditClose, effEditDraw, effEditMouse, effEditKey,
    effEditIdle, effEditTop, effEditSleep, effIdentify, effGetChunk, effSetChunk,
    effProcessEvents = 25, effCanBeAutomated, effString2Parameter, effGetNumProgramCategories,
    effGetProgramNameIndexed, effCopyProgram, effConnectInput, effConnectOutput, effGetInputProperties,
    effGetOutputProperties, effGetPlugCategory, effGetCurrentPosition, effGetDestinationBuffer,
    effOfflineNotify, effOfflinePrepare, effOfflineRun, effProcessVarIo, effSetSpeakerArrangement,
    effSetBlockSizeAndSampleRate, effSetBypass, effGetEffectName, effGetErrorText, effGetVendorString,
    effGetProductString, effGetVendorVersion, effVendorSpecific, effCanDo, effGetTailSize, effIdle,
    effGetIcon, effSetViewPosition, effGetParameterProperties, effKeysRequired, effGetVstVersion,
    effEditKeyDown, effEditKeyUp, effSetEditKnobMode, effGetMidiProgramName, effGetCurrentMidiProgram,
    effGetMidiProgramCategory, effHasMidiProgramsChanged, effGetMidiKeyName, effBeginSetProgram,
    effEndSetProgram, effGetSpeakerArrangement, effShellGetNextPlugin, effStartProcess, effStopProcess,
    effSetTotalSampleToProcess, effSetPanLaw, effBeginLoadBank, effBeginLoadProgram,
    effSetProcessPrecision, effGetNumMidiInputChannels, effGetNumMidiOutputChannels
};

/* audioMaster opcodes (host side) */
enum {
    audioMasterAutomate = 0, audioMasterVersion, audioMasterCurrentId, audioMasterIdle,
    audioMasterPinConnected, audioMasterUnused5, audioMasterWantMidi, audioMasterGetTime,
    audioMasterProcessEvents, audioMasterSetTime, audioMasterTempoAt,
    audioMasterGetNumAutomatableParameters, audioMasterGetParameterQuantization, audioMasterIOChanged,
    audioMasterNeedIdle, audioMasterSizeWindow, audioMasterGetSampleRate, audioMasterGetBlockSize,
    audioMasterGetInputLatency, audioMasterGetOutputLatency, audioMasterGetPreviousPlug,
    audioMasterGetNextPlug, audioMasterWillReplaceOrAccumulate, audioMasterGetCurrentProcessLevel,
    audioMasterGetAutomationState, audioMasterOfflineStart, audioMasterOfflineRead,
    audioMasterOfflineWrite, audioMasterOfflineGetCurrentPass, audioMasterOfflineGetCurrentMetaPass,
    audioMasterSetOutputSampleRate, audioMasterGetOutputSpeakerArrangement, audioMasterGetVendorString,
    audioMasterGetProductString, audioMasterGetVendorVersion, audioMasterVendorSpecific,
    audioMasterSetIcon, audioMasterCanDo, audioMasterGetLanguage, audioMasterOpenWindow,
    audioMasterCloseWindow, audioMasterGetDirectory, audioMasterUpdateDisplay, audioMasterBeginEdit,
    audioMasterEndEdit, audioMasterOpenFileSelector, audioMasterCloseFileSelector
};
#endif
