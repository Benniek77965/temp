// 电音助手网页窗口（js/dianyinAssistant.js，原 EXUI 窗口）的运行测试（jsdom）：显示规则、滑块跟随、右键菜单、基调修改、
// 拖动与发给 EPL 的命令。显示内容与文字由 EPL 推来（真实规则在模块里，见 tests/epl_engine/test_rack_visibility.py）。
// 需要 jsdom；没有时跳过。用法（在依赖库根目录）：node tests/companion/test_dianyin_page.js
'use strict';
let JSDOM;
try { ({ JSDOM } = require('jsdom')); } catch (e) { console.log('跳过：没有安装 jsdom'); process.exit(0); }
const fs = require('fs'), path = require('path'), assert = require('assert');
const ROOT = path.resolve(__dirname, '..', '..', '..', '..', '..');
const b64 = (s) => Buffer.from(s, 'utf8').toString('base64');
const T = ['基调修改', '自动识别', '手动设置', '当前歌曲：', '基调：', '音阶：', '保存', '添加/报错', '切换播放器模式', '手动', '自动', '退出',
  '正在查询基调中...', '查询不到此歌曲的基调信息', '自动设置 - 成功', '自动设置 - 失败', '手动设置 - 成功', '手动设置 - 失败', '确定', '电音强度', '大调', '小调'];
const SONG = '姚晓棠 / 白小白 - 从前说 (Live)';
function texts() {
  return { t: T.map((v) => ({ v: b64(v + '\u0000') })), rack: b64('机架联动'), autoswitch: b64('自动切换'),
    keys: ['C', 'D', 'E'].map((v) => ({ v: b64(v) })), scales: ['大调', '小调'].map((v) => ({ v: b64(v) })),
    players: [{ i: 'iVBORw0KGgo=' }, { i: '' }] };
}
function state(o) {
  return Object.assign({ song: b64(SONG), status: b64('插件：已切到 E'), key: b64('基调： E    音阶：大调'), sp: 310, rk: 2, pm: 0,
    pi: 2, kc: 3, sc: 1 }, o || {});
}
function page() {
  const dom = new JSDOM('<!doctype html><html><head></head><body></body></html>', { runScripts: 'outside-only', pretendToBeVisual: true,
    virtualConsole: new (require('jsdom').VirtualConsole)() });
  const w = dom.window, sent = [];
  w.TextEncoder = TextEncoder; w.TextDecoder = TextDecoder;
  w.chrome = { webview: { postMessage: (m) => sent.push(m) } };
  w.__DY_WIN__ = 1;
  w.eval(fs.readFileSync(path.join(ROOT, 'js/dianyinAssistant.js'), 'utf8'));
  if (w.document.readyState === 'loading') w.document.dispatchEvent(new w.Event('DOMContentLoaded'));   // 与 WebView2 一样等文档就绪后启动
  const d = w.document, q = (s) => d.querySelector(s), all = (s) => Array.from(d.querySelectorAll(s));
  const fire = (node, type, init) => node.dispatchEvent(new w.MouseEvent(type, Object.assign({ bubbles: true, cancelable: true }, init || {})));
  const plain = (node, type) => node.dispatchEvent(new w.Event(type, { bubbles: true }));
  const menuItems = (sel) => all(sel + ' .dy-item').map((n) => n.textContent + (n.classList.contains('dy-check') ? '✓' : ''));
  return { w, d, sent, q, all, fire, plain, menuItems };
}
let pass = 0;
const ok = (name, fn) => { fn(); pass++; console.info('ok -', name); };
const last = (sent) => sent[sent.length - 1];

ok('启动即报就绪；窗口标题；文字去掉结尾零', () => {
  const p = page();
  assert.strictEqual(p.sent[0], 'XHHDY:ready');
  assert.strictEqual(p.d.title, '电音助手');
  assert(p.d.body.hasAttribute('data-i18n-skip'), '不交给 i18n.js 的自动翻译层');
  p.w.DY.texts(texts()); p.w.DY.state(state());
  assert.strictEqual(p.q('.dy-pill-name').textContent, '电音强度');
  assert.strictEqual(p.q('.dy-song div').textContent, SONG);
  assert.strictEqual(p.all('.dy-song div')[1].textContent, '插件：已切到 E');
  assert.strictEqual(p.q('.dy-key').textContent, '基调： E    音阶：大调');
});
ok('未同意、未读到强度：不显示联动状态与电音强度（同原窗口）', () => {
  const p = page(); p.w.DY.texts(texts());
  p.w.DY.state(state({ status: '', sp: -1, rk: 1 }));
  assert(p.all('.dy-song div')[1].classList.contains('dy-hidden'));
  assert(p.q('.dy-strength').classList.contains('dy-hidden'));
  p.w.DY.state(state({ sp: 600 }));
  assert(!p.q('.dy-strength').classList.contains('dy-hidden'));
  assert.strictEqual(p.q('.dy-slider').value, '240'); assert.strictEqual(p.q('.dy-pill-value').textContent, '60%');
});
ok('滑块：同原窗口 400 格、拖动中每次调整都发（容许拖动跟踪开）；拖动中不被拉回；回显不动；插件里改了跟随；滚轮一格走 1 格', () => {
  const p = page(); p.w.DY.texts(texts()); p.w.DY.state(state({ sp: 600 }));
  const s = p.q('.dy-slider');
  assert.strictEqual(s.max, '400', '同原窗口滑块最大位置 400');
  assert.strictEqual(s.value, '240'); assert.strictEqual(p.q('.dy-pill-value').textContent, '60%');
  p.plain(s, 'pointerdown'); s.value = '180';
  p.w.DY.state(state({ sp: 700 }));
  assert.strictEqual(s.value, '180', '拖动中不被状态刷新拉回');
  p.plain(s, 'input');
  assert.strictEqual(last(p.sent), 'XHHDY:strength:180,400', '拖动中就发（同原窗口容许拖动跟踪开）');
  assert.strictEqual(p.q('.dy-pill-value').textContent, '45%');
  const n0 = p.sent.length; p.plain(s, 'change');
  assert.strictEqual(p.sent.length, n0, '松手时值没变不重发');
  p.w.DY.state(state({ sp: 450 }));
  assert.strictEqual(s.value, '180', '引擎回显同一个值时不动（截断与引擎相同）');
  p.w.DY.state(state({ sp: 300 }));
  assert.strictEqual(s.value, '120'); assert.strictEqual(p.q('.dy-pill-value').textContent, '30%');
  s.value = '180'; p.plain(s, 'input');
  assert.strictEqual(last(p.sent), 'XHHDY:strength:180,400', '跟随插件后拖回原来的值也要发');
  p.w.DY.state(state({ sp: -1 })); s.value = '0';
  p.w.DY.state(state({ sp: 300 }));
  assert.strictEqual(s.value, '120', '重新显示时按引擎的值对齐');
  p.w.DY.state(state({ sp: 305 }));
  assert.strictEqual(s.value, '122', '截断取整（同原窗口）'); assert.strictEqual(p.q('.dy-pill-value').textContent, '30%');
  const wheel = (dy) => p.q('.dy-strength').dispatchEvent(new p.w.WheelEvent('wheel', { deltaY: dy, bubbles: true, cancelable: true }));
  wheel(-100); assert.strictEqual(s.value, '123', '滚轮向上一格走 1 格（同原窗口滚动改变值 1）'); assert.strictEqual(last(p.sent), 'XHHDY:strength:123,400');
  wheel(40); wheel(40); assert.strictEqual(s.value, '123', '触控板的细小滚动没攒够一格不走');
  wheel(40); assert.strictEqual(s.value, '122', '攒够一格向下走 1 格');
});

ok('播放器：手动模式可点选并高亮当前；自动模式不能点选', () => {
  const p = page(); p.w.DY.texts(texts()); p.w.DY.state(state());
  const items = p.all('.dy-player');
  assert.strictEqual(items.length, 2);
  assert(items[1].classList.contains('dy-on') && !items[0].classList.contains('dy-on'));
  assert.strictEqual(items[0].querySelector('img').getAttribute('src'), 'data:image/png;base64,iVBORw0KGgo=');
  const before = p.sent.length;
  p.fire(items[1], 'click'); assert.strictEqual(p.sent.length, before, '点当前播放器不发命令');
  p.fire(items[0], 'click'); assert.strictEqual(last(p.sent), 'XHHDY:player:1', '按序号选（名字不经编码转换）');
  p.w.DY.state(state({ pm: 1 }));
  assert(!p.q('.dy-players').classList.contains('dy-manual') && !items[1].classList.contains('dy-on'));
  const n = p.sent.length; p.fire(items[0], 'click'); assert.strictEqual(p.sent.length, n);
});
ok('歌名、状态与基调行保留连续空格（模块用几个空格隔开基调与音阶，原 EXUI 标签原样画出）', () => {
  const css = fs.readFileSync(path.join(ROOT, 'css/dianyinAssistant.css'), 'utf8');
  const rule = css.match(/\.dy-song div, \.dy-key \{([^}]*)\}/);
  assert(rule && /white-space:\s*pre;/.test(rule[1]), '要用 white-space: pre（nowrap 会把连续空格合成一个）');
  const p = page(); p.w.DY.texts(texts()); p.w.DY.state(state({ key: b64('基调：E     音阶：大调') }));
  assert.strictEqual(p.q('.dy-key').textContent, '基调：E     音阶：大调');
});
ok('右键菜单：勾选与原窗口一致；策略不开放时没有「机架联动」；命令正确', () => {
  const p = page(); p.w.DY.texts(texts()); p.w.DY.state(state({ rk: 2, pm: 0 }));
  p.fire(p.q('.dy-bubble'), 'contextmenu', { clientX: 20, clientY: 20 });
  assert.deepStrictEqual(p.menuItems('.dy-menu:not(.dy-hidden)'), ['添加/报错', '切换播放器模式✓', '机架联动✓', '退出']);
  const mode = p.all('.dy-menu .dy-item')[1];
  p.fire(mode, 'mouseenter');
  const subs = p.all('.dy-menu')[1];
  assert.deepStrictEqual(Array.from(subs.querySelectorAll('.dy-item')).map((n) => n.textContent + (n.classList.contains('dy-check') ? '✓' : '')), ['手动✓', '自动']);
  p.fire(subs.querySelectorAll('.dy-item')[1], 'click');
  assert.strictEqual(last(p.sent), 'XHHDY:mode:1');
  assert(p.all('.dy-menu').every((m) => m.classList.contains('dy-hidden')));
  p.fire(p.q('.dy-bubble'), 'contextmenu', { clientX: 5, clientY: 5 });
  p.fire(p.all('.dy-menu .dy-item')[2], 'mouseenter');
  assert.deepStrictEqual(Array.from(p.all('.dy-menu')[1].querySelectorAll('.dy-item')).map((n) => n.textContent + (n.classList.contains('dy-check') ? '✓' : '')), ['自动切换✓']);
  p.fire(p.all('.dy-menu')[1].querySelector('.dy-item'), 'click');
  assert.strictEqual(last(p.sent), 'XHHDY:auto');
  p.w.DY.state(state({ rk: 0 }));
  p.fire(p.q('.dy-bubble'), 'contextmenu', { clientX: 5, clientY: 5 });
  assert.deepStrictEqual(p.menuItems('.dy-menu:not(.dy-hidden)'), ['添加/报错', '切换播放器模式✓', '退出']);
  p.w.DY.state(state({ rk: 1 }));
  p.fire(p.q('.dy-bubble'), 'contextmenu', { clientX: 5, clientY: 5 });
  assert.deepStrictEqual(p.menuItems('.dy-menu:not(.dy-hidden)'), ['添加/报错', '切换播放器模式✓', '机架联动', '退出']);
  p.fire(p.all('.dy-menu .dy-item')[3], 'click');
  assert.strictEqual(last(p.sent), 'XHHDY:close');
});
ok('基调修改：预选、自动识别隐藏手动项、提交打开时那首歌、结果提示；没有歌时不打开', () => {
  const p = page(); p.w.DY.texts(texts()); p.w.DY.state(state({ kc: 2, sc: 2 }));
  p.fire(p.q('.dy-bubble'), 'contextmenu', { clientX: 5, clientY: 5 });
  p.fire(p.all('.dy-menu .dy-item')[0], 'click');
  const dlg = p.q('.dy-dialog');
  assert(!dlg.classList.contains('dy-hidden'));
  assert.strictEqual(last(p.sent), 'XHHDY:dialog:1', '打开时告诉宿主（开着时不提层）');
  assert.strictEqual(p.q('.dy-dialog-title').textContent, '基调修改');
  assert.strictEqual(p.q('.dy-songname').textContent, SONG);
  const [key, scale] = p.all('.dy-select');
  assert.strictEqual(key.value, '2'); assert.strictEqual(scale.value, '2');
  assert.deepStrictEqual(Array.from(key.options).map((o) => o.textContent), ['C', 'D', 'E']);
  const [auto, manual] = p.all('.dy-radios input');
  assert(manual.checked && !auto.checked);
  auto.checked = true; p.plain(auto, 'change');
  assert(p.q('.dy-keyrow').classList.contains('dy-hidden') && p.q('.dy-songrow').classList.contains('dy-hidden'));
  manual.checked = true; p.plain(manual, 'change');
  assert(!p.q('.dy-keyrow').classList.contains('dy-hidden'));
  p.w.DY.state(state({ song: b64('别的歌'), kc: 1 }));
  key.value = '3';
  p.fire(p.q('.dy-save'), 'click');
  assert.strictEqual(last(p.sent), 'XHHDY:edit:0,3,2,' + b64(SONG), '提交给打开时显示的那首');
  assert(p.q('.dy-save').disabled);
  const n = p.sent.length; p.fire(p.q('.dy-save'), 'click'); assert.strictEqual(p.sent.length, n, '提交中不重复提交');
  p.w.DY.editResult(1, b64('手动设置 - 成功'));
  assert(!p.q('.dy-result').classList.contains('dy-hidden') && p.q('.dy-result div').textContent === '手动设置 - 成功');
  assert(!p.q('.dy-save').disabled);
  p.fire(p.q('.dy-result button'), 'click'); assert(p.q('.dy-result').classList.contains('dy-hidden'));
  p.fire(p.q('.dy-bubble'), 'contextmenu', { clientX: 5, clientY: 5 });
  assert(p.all('.dy-menu').every((m) => m.classList.contains('dy-hidden')), '对话框打开时右键不弹菜单');
  p.fire(p.q('.dy-dialog-close'), 'click'); assert(dlg.classList.contains('dy-hidden'));
  assert.strictEqual(last(p.sent), 'XHHDY:dialog:0', '关上时告诉宿主');
  p.w.DY.state(state({ song: '' }));
  p.fire(p.q('.dy-bubble'), 'contextmenu', { clientX: 5, clientY: 5 });
  p.fire(p.all('.dy-menu .dy-item')[0], 'click');
  assert(dlg.classList.contains('dy-hidden'), '没有歌曲时不打开（同原窗口）');
});
ok('透明处右键不弹菜单（同原窗口点在透明处落到桌面上），可见部分右键才弹', () => {
  const p = page(); p.w.DY.texts(texts()); p.w.DY.state(state());
  p.fire(p.d.body, 'contextmenu', { clientX: 300, clientY: 190 });
  assert(p.all('.dy-menu').every((m) => m.classList.contains('dy-hidden')));
  p.fire(p.q('.dy-players'), 'contextmenu', { clientX: 30, clientY: 140 });
  assert(!p.all('.dy-menu')[0].classList.contains('dy-hidden'));
});
ok('拖动与 Esc：按住气泡区拖动窗口；Esc 先关菜单再关对话框', () => {
  const p = page(); p.w.DY.texts(texts()); p.w.DY.state(state());
  p.fire(p.q('.dy-bubble'), 'mousedown', { button: 0 });
  assert.strictEqual(last(p.sent), 'XHHDY:drag');
  const n = p.sent.length; p.fire(p.q('.dy-key'), 'mousedown', { button: 2 }); assert.strictEqual(p.sent.length, n, '右键不拖动');
  p.fire(p.q('.dy-bubble'), 'contextmenu', { clientX: 5, clientY: 5 });
  p.d.dispatchEvent(new p.w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  assert(p.all('.dy-menu').every((m) => m.classList.contains('dy-hidden')));
});
console.info('\n' + pass + ' passed');
process.exit(0);
