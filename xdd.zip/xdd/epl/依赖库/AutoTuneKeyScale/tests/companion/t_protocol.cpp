/* Tests compile the production protocol header, never a copy of its implementation. */
#include "companion_protocol.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <vector>

static unsigned checks = 0;
static void check(bool ok, const char* expression, int line) {
    ++checks;
    if (!ok) { fprintf(stderr, "FAIL line %d: %s\n", line, expression); exit(1); }
}
#define CHECK(x) check(!!(x), #x, __LINE__)

static void le16(std::vector<unsigned char>& b, size_t p, unsigned v) {
    b[p] = (unsigned char)v; b[p + 1] = (unsigned char)(v >> 8);
}
static void le32(std::vector<unsigned char>& b, size_t p, unsigned long v) {
    for (unsigned i = 0; i < 4; ++i) b[p+i] = (unsigned char)(v >> (8*i));
}
static void le64(std::vector<unsigned char>& b, size_t p, unsigned long long v) {
    for (unsigned i = 0; i < 8; ++i) b[p+i] = (unsigned char)(v >> (8*i));
}
static std::vector<unsigned char> packet(const std::string& payload, unsigned op = 3,
                                       unsigned long long seq = 1) {
    std::vector<unsigned char> b(56 + payload.size(), 0);
    memcpy(&b[0], "XAKS", 4);
    le16(b, 4, ATC_PROTOCOL_VERSION); le16(b, 6, ATC_HEADER_SIZE); le16(b, 8, op);
    le32(b, 12, (unsigned long)payload.size()); le64(b, 16, seq);
    if (!payload.empty()) memcpy(&b[56], payload.data(), payload.size());
    return b;
}
static void sign(std::vector<unsigned char>& b, const unsigned char key[32]) {
    std::vector<unsigned char> input(24 + b.size() - 56);
    memcpy(&input[0], &b[0], 24);
    if (b.size() > 56) memcpy(&input[24], &b[56], b.size() - 56);
    atc_hmac_sha256(key, 32, &input[0], (unsigned)input.size(), &b[24]);
}
static void expect_hmac(const unsigned char* key, unsigned key_len,
                        const unsigned char* data, unsigned len, const char* expected) {
    unsigned char digest[32]; char hex[65];
    atc_hmac_sha256(key, key_len, data, len, digest);
    for (unsigned i = 0; i < 32; ++i) sprintf(hex + 2*i, "%02x", digest[i]);
    CHECK(strcmp(hex, expected) == 0);
}
static void test_hmac() {
    /* RFC 4231 cases 1, 2 and 6 exercise short and over-block-size keys. */
    unsigned char key20[20], key131[131];
    memset(key20, 0x0b, sizeof key20); memset(key131, 0xaa, sizeof key131);
    expect_hmac(key20, 20, (const unsigned char*)"Hi There", 8,
                "b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7");
    const char* second = "what do ya want for nothing?";
    expect_hmac((const unsigned char*)"Jefe", 4, (const unsigned char*)second,
                (unsigned)strlen(second),
                "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843");
    const char* sixth = "Test Using Larger Than Block-Size Key - Hash Key First";
    expect_hmac(key131, sizeof key131, (const unsigned char*)sixth,
                (unsigned)strlen(sixth),
                "60e431591ee0b67f0d8a26aacbf5b77f8e0bc6213728c5140546040f0ee37f54");
}
static void test_packet() {
    const std::string payload = "key=1;scale=Minor;retune=0.123";
    std::vector<unsigned char> good = packet(payload);
    ATC_Packet p;
    CHECK(atc_parse_packet(&good[0], (unsigned)good.size(), &p));
    CHECK(p.op == 3 && p.seq == 1 && p.payload_len == payload.size());
    CHECK(memcmp(p.payload, payload.data(), payload.size()) == 0);
    for (unsigned n = 0; n < good.size(); ++n)
        CHECK(!atc_parse_packet(&good[0], n, &p));
    std::vector<unsigned char> b = good; b.push_back(0);
    CHECK(!atc_parse_packet(&b[0], (unsigned)b.size(), &p));
    for (unsigned pos = 0; pos < 16; ++pos) {
        b = good; b[pos] ^= 0x80;
        CHECK(!atc_parse_packet(&b[0], (unsigned)b.size(), &p));
    }
    b = good; le64(b, 16, 0);
    CHECK(!atc_parse_packet(&b[0], (unsigned)b.size(), &p));
    for (unsigned bad = 0; bad < 256; ++bad) {
        if (bad >= 0x20 && bad <= 0x7e) continue;
        b = good; b[56] = (unsigned char)bad;
        CHECK(!atc_parse_packet(&b[0], (unsigned)b.size(), &p));
    }
    b = packet(std::string(ATC_MAX_PAYLOAD, 'a'));
    CHECK(atc_parse_packet(&b[0], (unsigned)b.size(), &p));
    b = packet(std::string(ATC_MAX_PAYLOAD+1, 'a'));
    CHECK(!atc_parse_packet(&b[0], (unsigned)b.size(), &p));
    for (unsigned version=1;version<ATC_PROTOCOL_VERSION;++version) {
        b = good; le16(b, 4, version); /* v1 and v2 are rejected; no downgrade path. */
        CHECK(!atc_parse_packet(&b[0], (unsigned)b.size(), &p));
    }
    CHECK(ATC_PROTOCOL_VERSION==3&&ATC_MAX_PAYLOAD==4096);
    for (unsigned op = 1; op <= 9; ++op) {
        if(op==6)continue;
        b = packet("", op);
        CHECK(atc_parse_packet(&b[0], (unsigned)b.size(), &p));
    }
    b = packet("", 0); CHECK(!atc_parse_packet(&b[0], (unsigned)b.size(), &p));
    b = packet("", 6); CHECK(!atc_parse_packet(&b[0], (unsigned)b.size(), &p));
    b = packet("", 10); CHECK(!atc_parse_packet(&b[0], (unsigned)b.size(), &p));
    unsigned char key[32]; for (unsigned i=0;i<32;++i) key[i]=(unsigned char)i;
    good = packet(payload); sign(good, key);
    CHECK(atc_parse_packet(&good[0], (unsigned)good.size(), &p));
    CHECK(atc_verify_packet(&p, key));
    for (unsigned pos = 0; pos < good.size(); ++pos) {
        b = good; b[pos] ^= 1;
        if (atc_parse_packet(&b[0], (unsigned)b.size(), &p)) CHECK(!atc_verify_packet(&p, key));
    }
    key[0] ^= 1;
    CHECK(atc_parse_packet(&good[0], (unsigned)good.size(), &p));
    CHECK(!atc_verify_packet(&p, key));
}
static void test_sequence() {
    uint64_t last = 0;
    CHECK(!atc_accept_sequence(0, &last)); CHECK(last == 0);
    CHECK(atc_accept_sequence(1, &last)); CHECK(last == 1);
    CHECK(!atc_accept_sequence(1, &last)); CHECK(last == 1);
    CHECK(!atc_accept_sequence(0, &last)); CHECK(last == 1);
    CHECK(atc_accept_sequence(8, &last)); CHECK(last == 8);
    CHECK(!atc_accept_sequence(7, &last)); CHECK(last == 8);
    CHECK(atc_accept_sequence(~0ULL, &last)); CHECK(last == ~0ULL);
    CHECK(!atc_accept_sequence(1, &last)); CHECK(last == ~0ULL);
}
static void test_startup() {
    unsigned long pid = 0;
    CHECK(atc_startup("", &pid) == 0);
    CHECK(atc_startup("--show", &pid) == 0);
    CHECK(atc_startup("--companion 123", &pid) == 1 && pid == 123);
    const char* bad[] = {"--showcase", "--show ignored", "--show --companion 1",
        "--companion", "--companion 0", "--companion -1", "--companion +1",
        "--companion 1x", "--companion 4294967296", "--companion 1 --show",
        "--Companion 1", "--unknown", "1 --companion 2"};
    for (unsigned i=0; i<sizeof bad/sizeof bad[0]; ++i) CHECK(atc_startup(bad[i], &pid) == 0);
}
static void test_apply() {
    ATC_Apply a;
    for (int key = 0; key < 12; ++key) for (int scale = 0; scale < 3; ++scale) {
        const char* names[] = {"Major", "Minor", "Chromatic"}; char s[80];
        sprintf(s, "key=%d;scale=%s", key, names[scale]);
        CHECK(atc_parse_apply(s, (unsigned)strlen(s), 0, &a));
        CHECK(a.key == key && a.scale == scale && a.retune == -1);
    }
    const char* valid[] = {"retune=0", "retune=1", "retune=0.123", "retune=1.000", "retune=0.000"};
    const int values[] = {0, 1000, 123, 1000, 0};
    for (unsigned i=0;i<sizeof valid/sizeof valid[0];++i) {
        CHECK(atc_parse_apply(valid[i], (unsigned)strlen(valid[i]), 1, &a));
        CHECK(a.retune == values[i]);
    }
    const char* ordered = "retune=0.500;scale=Minor;key=11";
    CHECK(atc_parse_apply(ordered, (unsigned)strlen(ordered), 0, &a));
    CHECK(a.key == 11 && a.scale == 1 && a.retune == 500);
    const char* bad[] = {"", "key=12;scale=Major", "key=-1;scale=Major", "key=0",
        "scale=Major", "key=0;scale=major", "key=0;scale=Unknown", "key=0;key=1;scale=Major",
        "key=0;scale=Major;scale=Minor", "key=0;scale=Major;other=1", "key=0;scale=Major;",
        "key=0;scale=Major;retune=-1", "key=0;scale=Major;retune=1.001",
        "key=0;scale=Major;retune=0.0001", "key=0;scale=Major;retune=nan",
        "key=0;scale=Major;retune=1e-3", "key=0;scale=Major\n", "key=0;scale=Major;retune=0;retune=1"};
    for (unsigned i=0; i<sizeof bad/sizeof bad[0]; ++i)
        CHECK(!atc_parse_apply(bad[i], (unsigned)strlen(bad[i]), 0, &a));
    const char* feel_bad[] = {"retune=1.001", "retune=2", "retune=-0.1", "retune=nan",
        "retune=0;key=1", "retune=0;scale=Major", "retune=0;retune=1", "retune=0\n"};
    for (unsigned i=0; i<sizeof feel_bad/sizeof feel_bad[0]; ++i)
        CHECK(!atc_parse_apply(feel_bad[i], (unsigned)strlen(feel_bad[i]), 1, &a));
    /* No trailing NUL is needed; parser must honor the supplied bound. */
    const char truncated[] = {'r','e','t','u','n','e','=','1'};
    CHECK(atc_parse_apply(truncated, sizeof truncated, 1, &a) && a.retune == 1000);
}
static void test_retune() {
    for (int strength=0;strength<=1000;++strength) {
        CHECK(atc_retune(strength, 0) == 1000-strength);
        CHECK(atc_retune(strength, 1) == strength);
        CHECK(atc_retune(strength, 2) == strength);
    }
    CHECK(atc_retune(-1, 0) == -1); CHECK(atc_retune(1001, 1) == -1);
    CHECK(atc_retune(500, -1) == -1); CHECK(atc_retune(500, 3) == -1);
}
static void test_confirmation() {
    const int major[] = {8,3,10,5,12,7,2,9,4,11,6,1};
    const int minor[] = {5,12,7,2,9,4,11,6,1,8,3,10};
    for (int key=0;key<12;++key) for (int scale=0;scale<2;++scale) {
        char line[160]; int number = scale ? minor[key] : major[key]; char letter = scale ? 'A' : 'B';
        sprintf(line,"host.exe | plugin  Key=?  Scale=?  Camelot=%d%c  #00000001 KSR", number, letter);
        CHECK(atc_confirmed(key, scale, line));
        CHECK(!atc_confirmed((key+1)%12, scale, line));
        CHECK(!atc_confirmed(key, 1-scale, line));
        sprintf(line,"host | plugin  Camelot=%d%cBAD",number,letter);
        CHECK(!atc_confirmed(key, scale, line));
    }
    CHECK(atc_confirmed(0,2,"host | plugin  Key=C  Scale=Chromatic  Spd=50%"));
    CHECK(!atc_confirmed(0,2,"host | plugin  Scale=Chromaticity"));
    CHECK(!atc_confirmed(0,2,"host | plugin  OtherScale=Chromatic"));
    CHECK(!atc_confirmed(0,2,"host | Chromatic.vst3  Scale=Major"));
    CHECK(!atc_confirmed(0,0,"host | plugin  Camelot=8BAD"));
    CHECK(!atc_confirmed(0,0,"host | plugin  Camelot=18B"));
    CHECK(!atc_confirmed(0,0,"host | plugin  FakeCamelot=8B"));
    CHECK(!atc_confirmed(-1,0,"Camelot=8B"));
    CHECK(!atc_confirmed(12,0,"Camelot=8B"));
    CHECK(!atc_confirmed(0,3,"Camelot=8B"));
}
int main() {
    test_hmac(); test_packet(); test_sequence(); test_startup();
    test_apply(); test_retune(); test_confirmation();
    printf("PASS companion protocol: %u checks against production header\n", checks);
    return 0;
}
