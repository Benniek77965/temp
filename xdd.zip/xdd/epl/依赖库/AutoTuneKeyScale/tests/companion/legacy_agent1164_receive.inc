/* Frozen actual receiver from audit4 baseline SHA256 11f0487e8ab498d47a08fc753b1368e65564b43bc4aa3731e0d54755f36d95db. Test-only negative compatibility control; never linked into production. Its v2 pipe magic is supplied by the fixture. */
static void agent_poll_authorization(){
    atcs_loader_collect();
    if(g_authPipe==INVALID_HANDLE_VALUE){g_authPipe=atcs_pipe_server();return;}
    BOOL connected=ConnectNamedPipe(g_authPipe,NULL);DWORD err=connected?0:GetLastError();
    if(!connected&&err!=ERROR_PIPE_CONNECTED&&err!=ERROR_NO_DATA)return;
    DWORD available=0;if(!PeekNamedPipe(g_authPipe,NULL,0,NULL,&available,NULL)||!available){if(err==ERROR_NO_DATA)DisconnectNamedPipe(g_authPipe);return;}
    unsigned char request[8+ATCS_PIPE_MAX];DWORD got=0,result=0;
    if(ReadFile(g_authPipe,request,sizeof request,&got,NULL)&&got>=8){
        DWORD magic=0,len=0,client=0;memcpy(&magic,request,4);memcpy(&len,request+4,4);
        ATCS_Claims lease;
        if(magic==ATCS_PIPE_MAGIC&&len==got-8&&len<=ATCS_PIPE_MAX&&atcs_pipe_peer(g_authPipe,1,0,&client)&&atcs_same_user_elevated(client)
           &&atcs_verify_token((const char*)request+8,len,atcs_creator(client),g_authDevice,&lease)&&atcs_pid_alive(lease.parent)&&agent_policy_host(&lease)){
            int same=g_authInstalled&&atcs_claims_equal(&lease,&g_authLease);
            int ownerFree=!g_authInstalled||!atcs_pid_alive(g_authLease.parent)||atcs_now()>=g_authLease.expires;
            int newer=lease.parent==g_authLease.parent&&lease.issued>g_authLease.issued;
            if(g_suspended&&lease.issued<=g_authResumeAfter)result=0;
            else if(same)result=1;
            else if((ownerFree||newer)&&atcs_loader_publish(&lease)){g_authLease=lease;g_authInstalled=1;memset(g_authSequences,0,sizeof g_authSequences);g_authRetuneSequence=0;result=1;
                if(g_csInit)LOG("authorization session=%s license=%s device=%s expires=%llu",lease.sid,lease.license,lease.device,(unsigned long long)lease.expires);}
            SecureZeroMemory(&lease,sizeof lease);
        }
    }
    DWORD wrote=0;WriteFile(g_authPipe,&result,4,&wrote,NULL);DisconnectNamedPipe(g_authPipe);SecureZeroMemory(request,sizeof request);
}
