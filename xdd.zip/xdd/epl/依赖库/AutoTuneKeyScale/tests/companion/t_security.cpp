/* Compile the production security header. Native signature verification fails
   closed; RSA signature success is deliberately outside this executable's scope
   (see w_token.cpp for the self-contained RSA cross-check). */
#include "companion_security.h"
#include <stdlib.h>
#include <vector>
static unsigned checks=0;
static void check(bool ok,const char* e,int line){++checks;if(!ok){fprintf(stderr,"FAIL security line %d: %s\n",line,e);exit(1);}}
#define CHECK(x) check(!!(x),#x,__LINE__)
static const char* SID="0123456789abcdef0123456789abcdef";
static const char* DEVICE="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
static std::string claims(){return std::string("ver=3\nsid=")+SID+"\nlic=L1\ndev="+DEVICE+"\nparent=42\niat=1000\nexp=1120\nkey=000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f\npolicy=1\nracks=\nplugins=\n";}
static std::string replaced(std::string s,const char* from,const char* to){size_t p=s.find(from);CHECK(p!=std::string::npos);s.replace(p,strlen(from),to);return s;}
static void test_encodings(){
    unsigned char bytes[64]={0};char hex[129];uint64_t n=0;
    CHECK(atcs_hex_decode("0001feff",8,bytes,sizeof bytes));CHECK(bytes[0]==0&&bytes[1]==1&&bytes[2]==254&&bytes[3]==255);
    atcs_hex_encode(bytes,4,hex);CHECK(!strcmp(hex,"0001feff"));
    CHECK(!atcs_hex_decode("FE",2,bytes,sizeof bytes));CHECK(!atcs_hex_decode("ff0",3,bytes,sizeof bytes));
    CHECK(!atcs_hex_decode("gg",2,bytes,sizeof bytes));CHECK(!atcs_hex_decode("ffff",4,bytes,1));
    CHECK(atcs_b64_decode("Zg",2,bytes,sizeof bytes)==1&&bytes[0]=='f');
    CHECK(atcs_b64_decode("Zm8",3,bytes,sizeof bytes)==2&&!memcmp(bytes,"fo",2));
    CHECK(atcs_b64_decode("Zm9v",4,bytes,sizeof bytes)==3&&!memcmp(bytes,"foo",3));
    const char* bad[]={"","Z","Zh","Zm9","Zg==","Zg+","Zg/","Zg\n"};
    for(unsigned i=0;i<sizeof bad/sizeof bad[0];i++)CHECK(atcs_b64_decode(bad[i],strlen(bad[i]),bytes,sizeof bytes)<0);
    CHECK(atcs_b64_decode("Zm9v",4,bytes,2)<0);
    CHECK(atcs_u64("18446744073709551615",20,&n)&&n==UINT64_MAX);
    const char* badnum[]={"","00","01","-1","+1","1 ","18446744073709551616","999999999999999999999"};
    for(unsigned i=0;i<sizeof badnum/sizeof badnum[0];i++)CHECK(!atcs_u64(badnum[i],strlen(badnum[i]),&n));
    CHECK(atcs_u64("0",1,&n)&&n==0);
    CHECK(!atcs_u64("1",1,NULL));
    char fingerprint[65];memset(fingerprint,1,sizeof fingerprint);
    CHECK(!atcs_device_fingerprint(fingerprint)&&fingerprint[0]==0);
    unsigned char signature[256]={0};CHECK(!atcs_verify_signature(bytes,3,signature));
}
static void test_claims(){
    ATCS_Claims c;std::string good=claims();
    CHECK(atcs_parse_claims(good.data(),good.size(),&c));
    CHECK(c.parent==42&&c.issued==1000&&c.expires==1120&&c.policy==1);
    CHECK(!strcmp(c.sid,SID)&&!strcmp(c.device,DEVICE)&&!strcmp(c.license,"L1"));
    for(unsigned i=0;i<32;i++)CHECK(c.key[i]==i);
    for(unsigned n=0;n<good.size();n++)CHECK(!atcs_parse_claims(good.data(),n,&c));
    const char* from[]={"ver=3","ver=3","parent=42","parent=42","parent=42","iat=1000","policy=1","lic=L1","sid=0123456789abcdef0123456789abcdef","dev=aaaa","key=0001"};
    const char* to[]={"ver=1","ver=2","parent=0","parent=4294967296","parent=042","iat=01000","policy=0","lic=bad.license","sid=0123456789ABCDEF0123456789abcdef","dev=AAAA","key=000G"};
    for(unsigned i=0;i<sizeof from/sizeof from[0];i++){std::string b=replaced(good,from[i],to[i]);CHECK(!atcs_parse_claims(b.data(),b.size(),&c));}
    std::string b=good+"policy=1\nracks=\nplugins=\n";CHECK(!atcs_parse_claims(b.data(),b.size(),&c));
    b=good;b.insert(b.find("parent="),"extra=1\n");CHECK(!atcs_parse_claims(b.data(),b.size(),&c));
    b=good;b[b.find("L1")]=0;CHECK(!atcs_parse_claims(b.data(),b.size(),&c));
    b=good;b[b.find("L1")]=(char)0x80;CHECK(!atcs_parse_claims(b.data(),b.size(),&c));
    CHECK(!atcs_parse_claims(NULL,good.size(),&c));CHECK(!atcs_parse_claims(good.data(),good.size(),NULL));
    CHECK(c.racks[0]==0&&c.plugins[0]==0);
    std::string filtered=replaced(good,"racks=\nplugins=\n","racks=7265617065722e657865\nplugins=7761766573\n");
    CHECK(atcs_parse_claims(filtered.data(),filtered.size(),&c));
    CHECK(!strcmp(c.racks,"7265617065722e657865")&&!strcmp(c.plugins,"7761766573"));
    const char* malformed[]={"racks=7265617065722E657865\nplugins=\n", /* uppercase hex */
        "racks=7265617065722e657865,7265617065722e657865\nplugins=\n", /* duplicate */
        "racks=7a2e657865,612e657865\nplugins=\n", /* unordered */
        "racks=612e657865,\nplugins=\n", /* trailing comma */
        "racks=\nplugins=632f782e646c6c\n", /* path */
        "racks=\nplugins=782e646c6c0a\n", /* control char */
        "racks=\nplugins=c0802e646c6c\n", /* noncanonical UTF8 */
        "racks=612e646c6c\nplugins=\n", /* rack needs .exe */
        "racks=\nplugins=612e657865\n", /* plugin needs approved suffix/family */
        "plugins=\nracks=\n", "racks=\n", "racks=\nplugins=\nextra=1\n"};
    for(unsigned i=0;i<sizeof malformed/sizeof malformed[0];++i){b=replaced(good,"racks=\nplugins=\n",malformed[i]);CHECK(!atcs_parse_claims(b.data(),b.size(),&c));}
    const char* badlicenses[]={"L0","L01","L-1","L+1","l1","L9223372036854775808","license_01-A"};
    for(unsigned i=0;i<sizeof badlicenses/sizeof badlicenses[0];++i){b=replaced(good,"lic=L1",(std::string("lic=")+badlicenses[i]).c_str());CHECK(!atcs_parse_claims(b.data(),b.size(),&c));}
    b=replaced(good,"lic=L1","lic=L9223372036854775807");CHECK(atcs_parse_claims(b.data(),b.size(),&c));
    std::string rackFilters;
    for(unsigned i=0;i<16;++i){char lead[4];sprintf(lead,"r%02u",i);std::string name=std::string(lead)+std::string(56,'x')+".exe";char encoded[257];atcs_hex_encode((const unsigned char*)name.data(),name.size(),encoded);if(i)rackFilters+=',';rackFilters+=encoded;}
    CHECK(rackFilters.size()==2031);
    b=replaced(good,"racks=\nplugins=\n",(std::string("racks=")+rackFilters+"\nplugins=616263642e646c6c\n").c_str());CHECK(atcs_parse_claims(b.data(),b.size(),&c)); /* total filter bytes 2047 */
    b=replaced(good,"racks=\nplugins=\n",(std::string("racks=")+rackFilters+"\nplugins=61626364652e646c6c\n").c_str());CHECK(!atcs_parse_claims(b.data(),b.size(),&c)); /* total 2049 */
    std::string tooMany;
    for(unsigned i=0;i<33;++i){char name[16],encoded[33];sprintf(name,"p%02u.dll",i);atcs_hex_encode((const unsigned char*)name,strlen(name),encoded);if(i)tooMany+=',';tooMany+=encoded;}
    CHECK(!atcs_policy_filter(tooMany.data(),tooMany.size(),0));
    std::string maxName=std::string(124,'x')+".dll",longName="x"+maxName;
    CHECK(atcs_policy_name(maxName.data(),maxName.size(),0));CHECK(!atcs_policy_name(longName.data(),longName.size(),0));


}
static void test_envelope(){
    unsigned char key[32],enc[32],mac[32];char hex[65],out[1100],sealed[4096];for(unsigned i=0;i<32;i++)key[i]=(unsigned char)i;
    atcs_derive(key,enc,mac);atcs_hex_encode(enc,32,hex);CHECK(!strcmp(hex,"655e079f38931f154e7954829e35668f4c19ca714a99e07e676afafbfae3d51a"));
    atcs_hex_encode(mac,32,hex);CHECK(!strcmp(hex,"4457751ce312d59fbfe16cbe54fe2cd69646d626e318c8d90ed4117700082fd2"));
    /* Independent Python hashlib/hmac vector, with nonce bytes 00..0f. */
    const std::string vector="XAC2|sid=0123456789abcdef0123456789abcdef|seq=7|exp=4102444800|nonce=000102030405060708090a0b0c0d0e0f|ct=00aa20493f69edb4a080764096454edbd601246cc1b29d6802f6fc2bb3d7b541e68357|mac=bffa3355640dcda491e3a85de9b06851d5d43a10b0276967a6cf7bb9b339c85a\n";
    const char* plain="key=5|scale=Major|retune=0.500|t=1\n";uint64_t last=0;
    CHECK(atcs_open(key,SID,4102444800ULL,vector.data(),vector.size(),&last,out,sizeof out));
    CHECK(last==7&&!strcmp(out,plain));
    CHECK(!atcs_open(key,SID,4102444800ULL,vector.data(),vector.size(),&last,out,sizeof out));CHECK(last==7);
    for(unsigned i=0;i<vector.size();i++){
        std::string b=vector;b[i]^=1;last=0;
        CHECK(!atcs_open(key,SID,4102444800ULL,b.data(),b.size(),&last,out,sizeof out));CHECK(last==0);
    }
    for(unsigned n=0;n<vector.size();n++){last=0;CHECK(!atcs_open(key,SID,4102444800ULL,vector.data(),n,&last,out,sizeof out));CHECK(last==0);}
    last=0;CHECK(!atcs_open(key,"1123456789abcdef0123456789abcdef",4102444800ULL,vector.data(),vector.size(),&last,out,sizeof out));
    CHECK(!atcs_open(key,SID,4102444801ULL,vector.data(),vector.size(),&last,out,sizeof out));
    key[0]^=1;CHECK(!atcs_open(key,SID,4102444800ULL,vector.data(),vector.size(),&last,out,sizeof out));key[0]^=1;
    CHECK(!atcs_open(key,SID,4102444800ULL,vector.data(),vector.size(),&last,out,strlen(plain)));
    CHECK(last==0);
    CHECK(atcs_seal(key,SID,8,4102444800ULL,plain,strlen(plain),sealed,sizeof sealed));
    CHECK(strstr(sealed,plain)==NULL);
    CHECK(atcs_open(key,SID,4102444800ULL,sealed,strlen(sealed),&last,out,sizeof out));CHECK(last==8&&!strcmp(out,plain));
    char second[4096];CHECK(atcs_seal(key,SID,8,4102444800ULL,plain,strlen(plain),second,sizeof second));CHECK(strcmp(sealed,second)!=0);
    CHECK(!atcs_seal(key,SID,0,4102444800ULL,plain,strlen(plain),sealed,sizeof sealed));
    CHECK(!atcs_seal(key,SID,9,0,plain,strlen(plain),sealed,sizeof sealed));
    CHECK(!atcs_seal(key,SID,9,4102444800ULL,"key=1",5,sealed,sizeof sealed));
    CHECK(!atcs_seal(key,SID,9,4102444800ULL,"a\nb\n",4,sealed,sizeof sealed));
    CHECK(!atcs_seal(key,SID,9,4102444800ULL,plain,strlen(plain),sealed,100));
    CHECK(atcs_seal(key,SID,9,1,plain,strlen(plain),sealed,sizeof sealed));last=0;
    CHECK(!atcs_open(key,SID,1,sealed,strlen(sealed),&last,out,sizeof out));CHECK(last==0);
    std::string maxplain(1023,'x');maxplain+='\n';
    CHECK(atcs_seal(key,SID,10,4102444800ULL,maxplain.data(),maxplain.size(),sealed,sizeof sealed));last=0;
    CHECK(atcs_open(key,SID,4102444800ULL,sealed,strlen(sealed),&last,out,sizeof out));CHECK(!memcmp(out,maxplain.data(),maxplain.size()));
    maxplain.insert(0,"x");CHECK(!atcs_seal(key,SID,11,4102444800ULL,maxplain.data(),maxplain.size(),sealed,sizeof sealed));
}
static void test_claim_equality(){
 ATCS_Claims a={},b={};strcpy(a.sid,SID);strcpy(a.license,"L1");strcpy(a.device,DEVICE);a.parent=42;a.issued=1000;a.expires=1120;a.policy=1;b=a;
 CHECK(atcs_claims_equal(&a,&b));b.racks[100]=1;CHECK(atcs_claims_equal(&a,&b));
 b=a;strcpy(b.sid,"different");CHECK(!atcs_claims_equal(&a,&b));b=a;strcpy(b.license,"L2");CHECK(!atcs_claims_equal(&a,&b));b=a;b.device[0]='b';CHECK(!atcs_claims_equal(&a,&b));
 b=a;++b.parent;CHECK(!atcs_claims_equal(&a,&b));b=a;++b.issued;CHECK(!atcs_claims_equal(&a,&b));b=a;++b.expires;CHECK(!atcs_claims_equal(&a,&b));b=a;b.key[0]=1;CHECK(!atcs_claims_equal(&a,&b));b=a;b.policy=0;CHECK(!atcs_claims_equal(&a,&b));
 b=a;strcpy(b.racks,"7265617065722e657865");CHECK(!atcs_claims_equal(&a,&b));b=a;strcpy(b.plugins,"7761766573");CHECK(!atcs_claims_equal(&a,&b));CHECK(!atcs_claims_equal(NULL,&b));CHECK(!atcs_claims_equal(&a,NULL));
}
int main(){test_claim_equality();test_encodings();test_claims();test_envelope();printf("PASS companion security: %u checks against production header\n",checks);return 0;}
