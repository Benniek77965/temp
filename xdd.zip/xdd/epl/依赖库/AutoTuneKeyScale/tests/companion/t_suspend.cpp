/* Exact production stop/resume functions, with OS/hook operations substituted.
   Tests state/queue/dispatch contracts, not real Windows subclass teardown. */
#include "companion_security.h"
#include "companion_mailbox.h"
#include "vst3_abi.h"
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
typedef int32_t LONG;
#define AT_XHH_MANAGED 1
#define LOG(...) ((void)0)
#define UIQ 4
#define UIPH_FREE 0
#define UIPH_POST 1
#define UIPH_RUN 2
#define UIPH_DONE 3
#define UIGEN_MASK 0x07ffffff
#define UIW(g,p) ((LONG)(((g)<<2)|(p)))
#define UIPH(w) ((w)&3)
#define UIGEN(w) ((w)>>2)
#define PAGE_EXECUTE_READWRITE 64
static struct{volatile LONG word;}g_uiQ[UIQ];
static volatile LONG g_parameterPaused=0,g_parameterEpoch=1;static ATCS_PauseBarrier g_pauseBarrier={0,0};
static LONG g_ejecting=0,g_eatBusy=0,g_llHead=0,g_llTail=0,g_llFlag=0;
static int g_suspended=0,g_hookCsInit=1,g_hookCs=0,g_catchCsInit=1,g_catchCs=0;
static int uiDetach=0,crashRemove=0,notificationRemove=0,eatRemove=0,factoryRemove=0,initRemove=0,crashInstall=0,notificationInstall=0,deletes=0,publicRevokes=0;
static const char*g_statusPath="status",*g_scalesPath="scales",*g_pendPath="pending";
static ATCS_Claims g_authLease;static int g_authInstalled=1,alive=1;static uint64_t g_authResumeAfter=0,g_authSequences[4]={1,2,3,4},g_authRetuneSequence=3;
typedef tresult(WINAPI*tCreate)(void*,const TUID,const TUID,void**);
static IPluginFactoryVtbl factoryTable={};static void* g_hookedVtbl[1]={&factoryTable};static tCreate g_hookedOrig[1]={NULL};static int g_nHooked=1;
static int agent_policy_address(const void*){return 1;}static tresult WINAPI myCreateInstance(void*,const TUID,const TUID,void**){return 0;}
static void* initTable[4];static void* g_ihVtbl[1]={initTable};static void*g_ihOrig[1]={(void*)(uintptr_t)0x1110};static int g_nIH=1;
static LONG InterlockedCompareExchange(volatile LONG*p,LONG n,LONG e){LONG v=*p;if(v==e)*p=n;return v;}static LONG InterlockedExchange(volatile LONG*p,LONG n){LONG v=*p;*p=n;return v;}
static LONG InterlockedIncrement(volatile LONG*p){return ++*p;}
static void EnterCriticalSection(int*p){++*p;}static void LeaveCriticalSection(int*p){--*p;}static void SwitchToThread(){}
static void ui_detach(){++uiDetach;}static void crash_record_remove(){++crashRemove;}static void remove_dll_notification(){++notificationRemove;}static void remove_eat_hooks(){++eatRemove;}static void remove_factory_hooks(){++factoryRemove;}static void remove_init_hooks(){++initRemove;initTable[3]=g_ihOrig[0];}
static void crash_record_install(){++crashInstall;}static void install_dll_notification(){++notificationInstall;}static int DeleteFileA(const char*){++deletes;return 1;}
static void SecureZeroMemory(void*p,size_t n){memset(p,0,n);}static int atcs_loader_publish(const ATCS_Claims* p){if(!p)++publicRevokes;return 1;}
static int VirtualProtect(void*,size_t,DWORD,DWORD*out){*out=0;return 1;}static int agent_lease_alive(){return g_authInstalled&&alive;}static void myInitialize(){}
#include "agent_lifecycle.inc"
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL suspend line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
int main(){
 g_authLease.issued=100;memset(g_authLease.key,0xa5,32);g_llHead=1;g_llTail=3;g_llFlag=1;initTable[3]=(void*)myInitialize;
 g_uiQ[0].word=UIW(1,UIPH_POST);g_uiQ[1].word=UIW(2,UIPH_RUN);g_uiQ[2].word=UIW(3,UIPH_DONE);
 agent_suspend();CHECK(g_ejecting&&g_suspended&&!g_authInstalled);CHECK(g_authResumeAfter==100&&publicRevokes==1);for(int i=0;i<32;i++)CHECK(g_authLease.key[i]==0);for(int i=0;i<4;i++)CHECK(g_authSequences[i]==0);CHECK(g_authRetuneSequence==0);CHECK(g_parameterPaused&&g_pauseBarrier.paused&&!g_pauseBarrier.sequence);
 CHECK(UIPH(g_uiQ[0].word)==UIPH_FREE&&UIGEN(g_uiQ[0].word)==1);CHECK(UIPH(g_uiQ[1].word)==UIPH_RUN);CHECK(UIPH(g_uiQ[2].word)==UIPH_DONE);
 CHECK(g_llHead==3&&!g_llFlag);CHECK(uiDetach==1&&crashRemove==1&&notificationRemove==1&&eatRemove==1&&factoryRemove==1&&initRemove==1&&deletes==3);CHECK(initTable[3]==g_ihOrig[0]);CHECK(g_hookCs==0&&g_catchCs==0&&g_eatBusy==0);
 agent_suspend();CHECK(deletes==3&&publicRevokes==1);agent_resume();CHECK(g_suspended&&g_ejecting&&notificationInstall==0);
 g_authInstalled=1;g_authLease.issued=100;agent_resume();CHECK(g_suspended&&notificationInstall==0);g_authLease.issued=101;alive=0;agent_resume();CHECK(g_suspended);alive=1;
 /* In-flight writes keep their RUN slot until completion; stale posted messages
    were invalidated and cannot acquire a reused request after safe stop. */
 g_uiQ[1].word=UIW(2,UIPH_DONE);g_uiQ[3].word=UIW(4,UIPH_POST);agent_resume();CHECK(!g_suspended&&!g_ejecting&&notificationInstall==1&&crashInstall==1);CHECK(UIPH(g_uiQ[3].word)==UIPH_FREE&&UIPH(g_uiQ[1].word)==UIPH_DONE);CHECK(initTable[3]==(void*)myInitialize);CHECK(factoryTable.createInstance==myCreateInstance);CHECK(g_hookCs==0&&g_catchCs==0);
 agent_resume();CHECK(notificationInstall==1);printf("PASS extracted agent safe stop/resume: %u checks\n",checks);
}
