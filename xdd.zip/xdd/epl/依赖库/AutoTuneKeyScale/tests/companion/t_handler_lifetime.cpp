/* Exact production handler ownership/map/writer functions. OS allocation,
   locks, clock/policy, discovery and host objects are explicit boundaries. */
#include "companion_security.h"
#include "vst3_abi.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
extern "C" int __lsan_is_turned_off(){return 1;}
extern "C" const char*__asan_default_options(){return "detect_leaks=0";}
#define MAXI 8
#define MAXCH 4
#define AT_XHH_MANAGED 1
#define LOG(...) ((void)0)
typedef int32_t LONG;
#include "handler_ownership_types.inc"
static int g_catchCs=0,g_catchCsInit=1,heapBlocks=0,allocations=0,frees=0;
static LONG g_ejecting=0,g_probing=0,g_uiExecuting=0,g_uiProbing=0;
static DWORD tid=1,g_workerTid=1,g_uiProbeTid=2;
static jmp_buf g_jb,g_uiJb;
static bool failAllocation=false;
static DWORD GetCurrentThreadId(){return tid;}
static void EnterCriticalSection(int*){g_catchCs++;}
static void LeaveCriticalSection(int*){if(g_catchCs<=0)abort();g_catchCs--;}
static LONG InterlockedIncrement(volatile LONG*p){return ++*p;}
static LONG InterlockedDecrement(volatile LONG*p){return --*p;}
static LONG InterlockedExchange(volatile LONG*p,LONG n){LONG old=*p;*p=n;return old;}
static LONG InterlockedExchangeAdd(volatile LONG*p,LONG n){LONG old=*p;*p+=n;return old;}
static volatile LONG g_parameterPaused=0,g_parameterEpoch=1;
static LONG InterlockedCompareExchange(volatile LONG*p,LONG n,LONG e){LONG old=*p;if(old==e)*p=n;return old;}
#define HEAP_ZERO_MEMORY 8
static void* GetProcessHeap(){return NULL;}
static void* HeapAlloc(void*,unsigned,size_t n){if(failAllocation)return NULL;heapBlocks++;allocations++;return calloc(1,n);}
static void HeapFree(void*,unsigned,void*p){if(p){heapBlocks--;frees++;free(p);}}
typedef tresult(WINAPI*tSetCH)(void*,void*);
static void*g_chVtbl[MAXCH];static tSetCH g_chOrig[MAXCH];static int g_nCH=1;

static tresult WINAPI mySetComponentHandler(void*,void*);
// Exact map state/helpers precede callbacks so reentrant cleanup uses real marks.
#include "handler_ownership_state.inc"
static void nested_ui(bool fault);
struct HostHandler{const IComponentHandlerVtbl*vtbl;int refs,adds,releases,begins,performs,ends;bool dead;};
static HostHandler a={},b={};static HostHandler*pluginBinding=NULL;
static bool origFault=false,captureFaultRequest=false,captureFault=false,clearDuringWait=false,reenterRelease=false,pumpCapture=false,pumpCaptureRequest=false;
static int pumpOriginal=0;
static HostHandler*releaseFault=NULL;
static bool beginClear=false;static void*activeController=NULL;
static unsigned valueWrites=0,action=0;static int identityCalls=0;
static void fault_jump(){if(g_uiProbing&&tid==g_uiProbeTid)longjmp(g_uiJb,1);longjmp(g_jb,1);}
static uint32_t WINAPI host_add(void*o){HostHandler*h=(HostHandler*)o;if(g_catchCs||h->dead)abort();if(captureFault){captureFault=false;fault_jump();}if(pumpCapture){pumpCapture=false;nested_ui(false);}h->adds++;return ++h->refs;}
static uint32_t WINAPI host_release(void*o){HostHandler*h=(HostHandler*)o;if(g_catchCs||h->dead||h->refs<1)abort();h->releases++;int refs=--h->refs;if(!refs)h->dead=true;if(reenterRelease){reenterRelease=false;handler_transaction_cleanup(handler_guard_mark());}if(releaseFault==h){releaseFault=NULL;fault_jump();}return refs;}
static tresult WINAPI host_begin(void*o,ParamID){HostHandler*h=(HostHandler*)o;if(h->dead)abort();h->begins++;if(beginClear){beginClear=false;mySetComponentHandler(activeController,NULL);}return kResultOk;}
static tresult WINAPI host_perform(void*o,ParamID,double){HostHandler*h=(HostHandler*)o;if(h->dead)abort();h->performs++;return kResultOk;}
static tresult WINAPI host_end(void*o,ParamID){HostHandler*h=(HostHandler*)o;if(h->dead)abort();h->ends++;return kResultOk;}
static IComponentHandlerVtbl hostTable={};static IEditControllerVtbl controllerTable={};static IEditController controller={&controllerTable};
static tresult WINAPI original_set(void*,void*handler){HostHandler*fresh=(HostHandler*)handler;if(pluginBinding!=fresh){if(pluginBinding)host_release(pluginBinding);pluginBinding=fresh;if(fresh)host_add(fresh);}if(pumpOriginal){int mode=pumpOriginal;pumpOriginal=0;nested_ui(mode==2);}if(origFault){origFault=false;fault_jump();}if(captureFaultRequest){captureFaultRequest=false;captureFault=true;}if(pumpCaptureRequest){pumpCaptureRequest=false;pumpCapture=true;}return kResultOk;}
static tresult WINAPI set_value(void*c,ParamID,double){valueWrites++;unsigned event=action;action=0;if(event==1)mySetComponentHandler(c,NULL);if(event==2)mySetComponentHandler(c,&b);if(event==3){origFault=true;mySetComponentHandler(c,NULL);}if(event==4){captureFaultRequest=true;mySetComponentHandler(c,&b);}if(event==5){mySetComponentHandler(c,NULL);releaseFault=&a;}if(event==6)fault_jump();return kResultOk;}
static V3Disc discovery;
static V3Disc*disc_find(IEditController*){return &discovery;}
static void discover_one(IEditController*){}
static void write_scales_union(){}
static int ctrl_module_is_antares(IEditController*){if(g_probing)abort();identityCalls++;return 1;}
static int agent_write_allowed(const void*,const char*){return !g_ejecting;}
static int key_to_pc(const char*){return 2;}
static void norm(const char*s,char*out,int n){snprintf(out,n,"%s",s);}
static int scale_same(const char*a,const char*b){return !strcmp(a,b);}
static int scale_name_to_index(const char*const*,const char*){return 1;}
static double scale_to_value_idx(int){return .5;}
static const char*const SCALES_STD[]={"Major","Minor"};
static double g_fRet=-1,g_fHum=-1,g_fNvb=-1,g_fSpeed=-1;static int g_fAudio=-1;
static int ui_post(IEditController*c,ParamID,double,const char*){if(clearDuringWait){clearDuringWait=false;mySetComponentHandler(c,NULL);/* emulate reclamation during the wait, within the existing caller guard */
 handler_transaction_cleanup(handler_guard_mark());host_release(&a);}return 0;}
#include "handler_ownership.inc"
static unsigned checks=0;
#define CHECK(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL ownership line%d: %s (heap=%d lock=%d refs=%d/%d)\n",__LINE__,#x,heapBlocks,g_catchCs,a.refs,b.refs);exit(1);}}while(0)
static void reset(){origFault=captureFaultRequest=captureFault=clearDuringWait=reenterRelease=pumpCapture=pumpCaptureRequest=false;pumpOriginal=0;beginClear=false;releaseFault=NULL;action=0;g_ejecting=g_probing=g_uiProbing=g_uiExecuting=0;tid=1;
 if(pluginBinding)original_set(&controller,NULL);while(g_nChMap)chmap_del(g_chCtrl[0]);HandlerGuardMark all={0,0,0};handler_transaction_cleanup(all);handler_worker_drain();CHECK(heapBlocks==0&&g_chPending==NULL&&g_chRetired==NULL&&g_handlerHeld==NULL&&g_catchCs==0);
 if(a.vtbl&&!a.dead)CHECK(a.refs==1);if(b.vtbl&&!b.dead)CHECK(b.refs==1);
 a=HostHandler();b=HostHandler();a.vtbl=b.vtbl=&hostTable;a.refs=b.refs=1;valueWrites=0;identityCalls=0;g_chVtbl[0]=&controllerTable;g_chOrig[0]=original_set;g_nCH=1;g_inHook=0;memset(&discovery,0,sizeof discovery);discovery.haveK=1;discovery.keySteps=11;discovery.keyId=2;discovery.isWaves=1;
}
static void nested_ui(bool fault){
 HandlerGuardMark mark=handler_guard_mark();LONG previousUi=g_uiProbing,previousExecuting=g_uiExecuting;DWORD previousProbe=g_uiProbeTid;
 g_uiProbeTid=tid;g_uiProbing=1;g_uiExecuting=1;
 if(setjmp(g_uiJb)==0){if(fault)fault_jump();v3set_body(&controller,&a,2,.5,"waves",1);}
 handler_transaction_cleanup(mark);g_uiProbing=previousUi;g_uiExecuting=previousExecuting;g_uiProbeTid=previousProbe;
}
static int write(unsigned event=0){action=event;return do_set_vst3_one(&controller,2,"",.5);}
int main(){hostTable.addRef=host_add;hostTable.release=host_release;hostTable.beginEdit=host_begin;hostTable.performEdit=host_perform;hostTable.endEdit=host_end;controllerTable.setParamNormalized=set_value;activeController=&controller;
 reset();CHECK(mySetComponentHandler(&controller,&a)==kResultOk);CHECK(a.refs==3&&handler_of(&controller)==&a);CHECK(write());CHECK(a.begins==1&&a.performs==1&&a.ends==1&&a.refs==3);CHECK(g_handlerHeld==NULL&&heapBlocks==1);
 CHECK(write(1));CHECK(valueWrites==2&&a.begins==1&&a.refs==1&&handler_of(&controller)==NULL&&heapBlocks==0);CHECK(g_handlerHeld==NULL);
 reset();mySetComponentHandler(&controller,&a);CHECK(write(2));CHECK(a.begins==0&&b.begins==0&&a.refs==1&&b.refs==3);CHECK(write());CHECK(b.begins==1&&b.ends==1);
 reset();mySetComponentHandler(&controller,&a);clearDuringWait=true;CHECK(write());CHECK(a.dead&&valueWrites==0&&handler_of(&controller)==NULL);CHECK(heapBlocks==0);
 reset();mySetComponentHandler(&controller,&a);g_uiExecuting=2;g_probing=1;HandlerGuardMark directA=handler_guard_mark();v3set_body(&controller,NULL,2,.5,"antares",0);handler_transaction_cleanup(directA);g_probing=g_uiExecuting=0;CHECK(valueWrites==1&&a.begins==0&&a.refs==3);
 reset();g_uiExecuting=2;g_probing=1;HandlerGuardMark directW=handler_guard_mark();v3set_body(&controller,NULL,2,.5,"waves");handler_transaction_cleanup(directW);g_probing=g_uiExecuting=0;CHECK(valueWrites==0);
 reset();mySetComponentHandler(&controller,&a);CHECK(!write(3));CHECK(g_chPending==NULL&&g_handlerHeld==NULL&&heapBlocks==0&&handler_of(&controller)==NULL&&a.refs==1&&g_catchCs==0&&g_inHook==0);
 reset();mySetComponentHandler(&controller,&a);CHECK(!write(4));CHECK(g_chPending==NULL&&g_handlerHeld==NULL&&heapBlocks==0&&a.refs==1&&b.refs==2&&g_catchCs==0&&g_inHook==0);mySetComponentHandler(&controller,NULL);handler_worker_drain();CHECK(b.refs==1);
 reset();mySetComponentHandler(&controller,&a);CHECK(!write(5));CHECK(g_handlerHeld==NULL&&heapBlocks==0&&a.refs==1&&g_catchCs==0&&g_inHook==0);mySetComponentHandler(&controller,&b);CHECK(write());CHECK(b.ends==1);
 reset();mySetComponentHandler(&controller,&a);CHECK(!write(6));CHECK(g_handlerHeld==NULL&&a.refs==3&&heapBlocks==1);CHECK(write());CHECK(a.ends==1);
 reset();mySetComponentHandler(&controller,&a);g_ejecting=1;CHECK(write());CHECK(valueWrites==0);mySetComponentHandler(&controller,NULL);handler_worker_drain();CHECK(a.refs==1&&heapBlocks==0);g_ejecting=0;mySetComponentHandler(&controller,&b);CHECK(write()&&b.ends==1);
 reset();mySetComponentHandler(&controller,&a);int releases=a.releases;EnterCriticalSection(&g_catchCs);chmap_del(&controller);CHECK(a.releases==releases);LeaveCriticalSection(&g_catchCs);handler_worker_drain();CHECK(a.releases==releases+1&&g_catchCs==0);
 reset();mySetComponentHandler(&controller,&a);mySetComponentHandler(&controller,NULL);reenterRelease=true;handler_worker_drain();CHECK(a.refs==1&&heapBlocks==0&&g_chRetired==NULL);
 reset();tid=2;mySetComponentHandler(&controller,&a);g_uiExecuting=1;g_uiProbeTid=2;g_uiProbing=1;HandlerGuardMark uiHeld=handler_guard_mark();v3set_body(&controller,&a,2,.5,"waves",1);CHECK(g_handlerHeld!=NULL);tid=1;handler_worker_drain();CHECK(g_handlerHeld!=NULL&&a.refs==3);tid=2;handler_transaction_cleanup(uiHeld);g_uiProbing=g_uiExecuting=0;CHECK(g_handlerHeld==NULL&&a.refs==3);tid=1;
 reset();tid=2;mySetComponentHandler(&controller,&a);g_uiExecuting=1;g_uiProbeTid=2;g_uiProbing=1;HandlerGuardMark uiFault=handler_guard_mark();action=3;if(setjmp(g_uiJb)==0)v3set_body(&controller,&a,2,.5,"waves",1);handler_transaction_cleanup(uiFault);g_uiProbing=g_uiExecuting=0;CHECK(g_handlerHeld==NULL&&g_chPending==NULL&&heapBlocks==0&&a.refs==1&&g_catchCs==0&&g_inHook==0);tid=1;
 reset();mySetComponentHandler(&controller,&a);failAllocation=true;mySetComponentHandler(&controller,&b);failAllocation=false;handler_worker_drain();CHECK(handler_of(&controller)==NULL&&heapBlocks==0&&a.refs==1&&b.refs==2);
 reset();mySetComponentHandler(&controller,&a);g_probing=1;if(setjmp(g_jb)==0){origFault=true;mySetComponentHandler(&controller,NULL);}g_probing=0;CHECK(heapBlocks==1&&g_chPauseTid[0]==1);handler_worker_drain();CHECK(heapBlocks==0&&a.refs==1&&g_chPending==NULL&&g_inHook==0);
 reset();mySetComponentHandler(&controller,&a);beginClear=true;CHECK(write());CHECK(a.begins==1&&a.performs==1&&a.ends==1&&a.refs==1&&handler_of(&controller)==NULL&&heapBlocks==0);
 reset();mySetComponentHandler(&controller,&a);tid=2;g_uiProbing=1;g_uiProbeTid=2;g_handlerUiHookDepth=g_inHook=3;HandlerGuardMark liveUi=handler_guard_mark();uint64_t pausedEpoch=handler_map_pause(&controller);original_set(&controller,&b);CHBinding* liveCapture=handler_binding_new(&b);tid=1;handler_worker_drain();CHECK(g_chPauseTid[0]==2&&g_chPending==liveCapture&&heapBlocks==2);CHECK(g_handlerUiHookDepth==3&&g_inHook==3);tid=2;handler_map_commit(&controller,pausedEpoch,liveCapture);handler_transaction_cleanup(liveUi);CHECK(handler_of(&controller)==&b&&a.refs==1&&b.refs==3&&g_handlerUiHookDepth==3&&g_inHook==3);g_handlerUiHookDepth=g_inHook=0;g_uiProbing=0;tid=1;
 reset();tid=2;pumpOriginal=1;mySetComponentHandler(&controller,&a);CHECK(handler_of(&controller)==&a&&a.refs==3&&heapBlocks==1&&g_inHook==0);tid=1;
 reset();tid=2;pumpOriginal=2;mySetComponentHandler(&controller,&a);CHECK(handler_of(&controller)==&a&&a.refs==3&&heapBlocks==1&&g_inHook==0);tid=1;
 reset();tid=2;pumpCaptureRequest=true;mySetComponentHandler(&controller,&a);CHECK(handler_of(&controller)==&a&&a.refs==3&&heapBlocks==1&&g_chPending==NULL&&g_inHook==0);tid=1;
 // A queued UI1 edit must not call a replacement binding installed on UI2.
 reset();tid=2;mySetComponentHandler(&controller,&a);tid=3;mySetComponentHandler(&controller,&b);tid=2;g_uiExecuting=1;g_uiProbeTid=2;g_uiProbing=1;HandlerGuardMark moved=handler_guard_mark();v3set_body(&controller,&a,2,.5,"waves",1);CHECK(valueWrites==0&&a.begins==0&&b.begins==0);handler_transaction_cleanup(moved);CHECK(g_handlerHeld==NULL&&a.refs==1&&b.refs==3&&heapBlocks==1);g_uiProbing=g_uiExecuting=0;
 // The new owner UI and the documented worker compatibility path still work.
 tid=3;g_uiExecuting=1;g_uiProbeTid=3;g_uiProbing=1;HandlerGuardMark owner=handler_guard_mark();v3set_body(&controller,&b,2,.5,"waves",1);CHECK(valueWrites==1&&b.begins==1&&b.ends==1);handler_transaction_cleanup(owner);g_uiProbing=g_uiExecuting=0;tid=1;CHECK(write());CHECK(valueWrites==2&&b.ends==2);
 // Reinstalling the same raw handler on another thread still creates a new binding.
 reset();tid=2;mySetComponentHandler(&controller,&a);CHBinding* oldOwner=handler_binding_acquire(&controller);tid=3;mySetComponentHandler(&controller,&a);CHBinding* newOwner=handler_binding_acquire(&controller);CHECK(oldOwner!=newOwner&&oldOwner->ownerTid==2&&newOwner->ownerTid==3);handler_binding_release(oldOwner);handler_binding_release(newOwner);
 tid=2;g_uiExecuting=1;g_uiProbeTid=2;g_uiProbing=1;HandlerGuardMark sameMoved=handler_guard_mark();v3set_body(&controller,&a,2,.5,"waves",1);CHECK(valueWrites==0&&a.begins==0);handler_transaction_cleanup(sameMoved);g_uiProbing=g_uiExecuting=0;tid=3;g_uiExecuting=1;g_uiProbeTid=3;g_uiProbing=1;HandlerGuardMark sameOwner=handler_guard_mark();v3set_body(&controller,&a,2,.5,"waves",1);CHECK(valueWrites==1&&a.begins==1&&a.ends==1);handler_transaction_cleanup(sameOwner);g_uiProbing=g_uiExecuting=0;tid=1;
 reset();CHECK(allocations==frees);printf("PASS exact handler ownership/map/writer: %u checks, %d balanced allocations\n",checks,allocations);
}
