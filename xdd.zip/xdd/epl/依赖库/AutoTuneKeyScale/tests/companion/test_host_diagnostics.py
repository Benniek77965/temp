"""Execute the production EPL diagnostic procedures with explicit file/Win32 stubs.
This checks source control flow and encoding/path contracts, not EPL compilation or Windows APIs.
"""
from pathlib import Path
import importlib.util
import json
import ntpath
import re
import sys

ROOT=Path(__file__).resolve().parents[2]
PROJECT=ROOT.parents[1]
spec=importlib.util.spec_from_file_location('epl_eval',ROOT/'tests/epl_engine/check.py')
epl=importlib.util.module_from_spec(spec);spec.loader.exec_module(epl)
base_evaluate=epl.evaluate
SOURCE=(PROJECT/'代码/集_基础支持/机架联动_宿主.static.e.txt').read_text('utf-8-sig')
PRODUCT=int(re.search(r'机架联动_调用桥 \(11, (\d+),',SOURCE).group(1))   # 交给桥的产品编号，取自宿主源码：项目 A 是 3，项目 B 是 2

class Fixture:
 def __init__(self):
  self.files={};self.handles={};self.closed=[];self.read_sizes=[];self.seek_ok=True;self.byte_positions=[]
  self.temp='C:\\TMP\\';self.emergency='C:\\TEMP';self.local='C:\\Users\\张三\\AppData\\Local'
 def key(self,path):return ntpath.normcase(ntpath.normpath(path))
 def put(self,path,data):self.files[self.key(path)]=data
 def run(self,name,*args):
  epl.evaluate=self.eval
  source=epl.section(SOURCE,name);env={'集_机架桥入口':0,'集_机架桥准备错误':0,'#HKEY_CURRENT_USER':0,'#换行符':'\r\n','#字节型':1}
  params=re.findall(r'^\.参数 ([^,]+),',source,re.M)
  for line in re.findall(r'^\.局部变量 (.+)$',source,re.M):
   parts=line.split(',');env[parts[0]]=b'' if parts[1].strip()=='字节集' else ('' if parts[1].strip()=='文本型' else 0)
  env.update(zip(params,args))
  try:self.execute(source.splitlines(),0,env)
  except epl.Returned as result:return result.value
  raise AssertionError('procedure has no return '+name)
 def eval(self,text,env):
  text=text.strip()
  if text.startswith('{') and text.endswith('}'):return bytes(int(n.strip()) for n in text[1:-1].split(',') if n.strip())
  m=re.fullmatch(r'([^ ()]+)\s*\((.*)\)',text)
  if not m:return base_evaluate(text,env)
  name,raw=m.groups();raws=epl.split_args(raw) if raw.strip() else []
  if name=='取变量数据地址':return ('ref',env,raws[0])
  if name=='取字节集数据':
   # GetBinElement writes its next index through a VARIABLE third argument.
   # Expressions create temporaries; this is an explicit core-library boundary
   # model, not an actual EPL runtime. Never silently accept an invalid peek.
   data=self.eval(raws[0],env);kind=self.eval(raws[1],env);position=self.eval(raws[2],env)
   assert kind==1 and 1<=position<=len(data),('invalid byte peek',position,len(data))
   self.byte_positions.append((position,raws[2]))
   if raws[2] in env:env[raws[2]]=position+1 if position<len(data) else -1
   return data[position-1]
  if name=='GetFileSizeEx_逻辑型':
   h=self.eval(raws[0],env);env[raws[1]]=len(self.handles[h][0]);return True
  if name=='ReadFile_整数型':
   h=self.eval(raws[0],env);_,target,variable=self.eval(raws[1],env);n=self.eval(raws[2],env)
   data,pos=self.handles[h];result=data[pos:pos+n];target[variable]=result;env[raws[3]]=len(result);self.handles[h][1]+=len(result);self.read_sizes.append(n);return True
  if name.startswith('机架联动_') and name!='机架联动_系统支持':return self.run(name,*[self.eval(a,env) for a in raws])
  funcs={
   '相加':lambda *a: (b''.join(a) if isinstance(a[0],bytes) else ''.join(map(str,a)) if isinstance(a[0],str) else sum(a)),
   '到文本':lambda x:x.decode('cp936') if isinstance(x,bytes) else str(int(x)) if isinstance(x,bool) else str(x),
   '到长整数':int,'选择':lambda c,a,b:a if c else b,'取空白字节集':bytes,'取字节集长度':len,
   '取字节集左边':lambda x,n:x[:n],'取字节集右边':lambda x,n:x[-n:] if n else b'',
   '寻找字节集':lambda x,y,u:x.find(y)+1,
   'ATU':lambda x,u:x.encode('utf-16le')+b'\0\0','UTA':lambda x:x.decode('utf-16le').rstrip('\0'),
   'un_连接':lambda *a:b''.join(x[:-2] if x.endswith(b'\0\0') else x for x in a if x is not None)+b'\0\0',
   '编码_Utf8到Ansi':lambda x:x.decode('utf-8','replace').encode('cp936','replace').decode('cp936'),
   '系统_取数值注册项':lambda *a:0,'系统_取文本注册项':lambda *a:'0','机架联动_系统支持':lambda:True,
  }
  # Delegate unknown core functions before evaluating arguments: the core
  # evaluator will evaluate them once itself, including any by-reference call.
  native={'GetTempPathA_字节集','GetEnvironmentVariableA_字节集','GetEnvironmentVariableW','CreateFileW','CloseHandle','SetFilePointerEx_整数型'}
  if name not in funcs and name not in native:return base_evaluate(text,env)
  args=[self.eval(a,env) for a in raws]
  if name in ('GetTempPathA_字节集','GetEnvironmentVariableA_字节集','GetEnvironmentVariableW'):
   variable=raws[1];wide=name.endswith('W');key=args[0]
   value=self.temp if name=='GetTempPathA_字节集' else self.local if key==('LOCALAPPDATA'.encode('utf-16le')+b'\0\0') else self.emergency
   encoded=value.encode('utf-16le' if wide else 'cp936');env[variable]=encoded+(b'\0\0' if wide else b'\0');return len(encoded)//2 if wide else len(encoded)
  if name=='CreateFileW':
   key=self.key(args[0].decode('utf-16le').rstrip('\0'))
   if key not in self.files:return -1
   h=len(self.closed)+len(self.handles)+1;self.handles[h]=[self.files[key],0];return h
  if name=='CloseHandle':self.closed.append(args[0]);del self.handles[args[0]];return True
  if name=='SetFilePointerEx_整数型':
   if not self.seek_ok:return False
   self.handles[args[0]][1]=len(self.handles[args[0]][0])+args[1];return True
  if name in funcs:return funcs[name](*args)
  return base_evaluate(text,env)
 def execute(self,lines,start,env,ends=()):
  i=start
  while i<len(lines):
   line=epl.active_line(lines[i]);token=line.split(' ',1)[0]   # 先去掉行尾注释（同 check.py）：注释里的括号会让 arguments 取错条件
   if token in ends:return i
   if not line or line.startswith("'") or token in ('.子程序','.参数','.局部变量'):i+=1;continue
   if token in ('.如果真','.如果','.判断循环首'):
    close={'.如果真':'.如果真结束','.如果':'.如果结束','.判断循环首':'.判断循环尾'}[token]
    depth=0;middle=None;end=i+1
    for end in range(i+1,len(lines)):
     t=lines[end].strip().split(' ',1)[0]
     if t in ('.如果真','.如果','.判断循环首'):depth+=1
     elif t in ('.如果真结束','.如果结束','.判断循环尾'):
      if depth==0:break
      depth-=1
     elif t=='.否则' and depth==0:middle=end
    assert lines[end].strip().startswith(close),(line,lines[end])
    condition=epl.arguments(line)[0]
    if token=='.判断循环首':
     loops=0
     while self.eval(condition,env):
      loops+=1;assert loops<100000
      try:self.execute(lines,i+1,env,(close,))
      except epl.Broke:break
    elif self.eval(condition,env):self.execute(lines,i+1,env,('.否则',close))
    elif middle is not None:self.execute(lines,middle+1,env,(close,))
    i=end+1;continue
   if line.startswith('赋值 '):
    variable,value=epl.arguments(line);env[variable]=self.eval(value,env)
   elif line.startswith('返回 '):raise epl.Returned(self.eval(epl.arguments(line)[0],env))
   elif line.startswith('跳出循环 '):raise epl.Broke()
   else:self.eval(line,env)
   i+=1
  return i


class AuthFixture:
 """Run actual host callback/helper source with explicit bridge/Win32/log boundaries."""
 def __init__(self):
  sys.path.insert(0,str(ROOT/'tests/epl_engine'))
  from review_regression import Runtime
  class AuthRuntime(Runtime):
   def evaluate(self,value,env):
    value=value.strip()
    if value.startswith('{') and value.endswith('}'):
     return bytes(int(x.strip()) for x in value[1:-1].split(',') if x.strip())
    # The shared small interpreter predates byte-set literals inside calls.
    # Resolve literals as operands before it splits function arguments; keep
    # quoted strings, source statements, and production control flow intact.
    parts=re.split(r'(“[^”]*”)',value)
    local_env=dict(env)
    def literal(match):
     key='_auth_literal_'+str(len(local_env))
     local_env[key]=bytes(int(x.strip()) for x in match.group()[1:-1].split(',') if x.strip())
     return key
    for i in range(0,len(parts),2):parts[i]=re.sub(r'\{[0-9,\s]*\}',literal,parts[i])
    return super().evaluate(''.join(parts),local_env)
  self.runtime=AuthRuntime(SOURCE);self.calls=[];self.logs=[];self.error=3;self.returned=None
  self.summary='auth_stage=http http=403 auth_reason=feature_disabled error=3'
  self.runtime.env.update({'集_机架桥入口':1,'集_机架桥准备错误':18,'集_机架授权诊断':'','集_机架准备日志':'','#字节型':1})
  # 电音助手账户配置：经真实的 电音助手配置_取 在叶子锁里复制（锁对象为替身，记下进入、退出）
  self.config_lock=[];self.runtime.env.update({'电音助手_配置文本':'','全_许可_电音助手配置':__import__('types').SimpleNamespace(进入=lambda *a:self.config_lock.append('进入') or True,退出=lambda:self.config_lock.append('退出'))})
  self.runtime.functions['电音助手配置_取']=lambda:self.runtime.invoke('电音助手配置_取')
  self.runtime.functions.update({
   '取空白字节集':bytearray,'取变量数据地址':lambda value:value,
   '取字节集左边':lambda value,count:bytes(value[:count]),
   '取字节集数据':lambda value,kind,position:value[position-1],
   'UTA':lambda value:bytes(value).decode('utf-16le').rstrip('\0'),
   '机架联动_调用桥':self.bridge,
   '机架联动_授权诊断记录':lambda value:self.runtime.invoke('机架联动_授权诊断记录',value),
   '机架联动_日志':lambda value:self.runtime.invoke('机架联动_日志',value),
   '机架联动_配置失败原因':lambda:self.runtime.invoke('机架联动_配置失败原因'),
   '机架联动_准备记日志':lambda text,level:self.runtime.invoke('机架联动_准备记日志',text,level),
   '写日志_本地':lambda value,level:self.logs.append((value,level)),
  })
 def bridge(self,operation,a,b,c,d):
  self.calls.append(operation)
  assert operation!=12,'complete op12 diagnostics may include identities and must never be logged'
  if operation==13:return self.error
  if operation in (7,8):return 123
  assert operation==15,('unexpected bridge operation',operation)
  assert len(a)==1024 and b==512 and c==d==0
  encoded=self.summary.encode('utf-16le')+b'\0\0'
  a[:min(len(encoded),len(a))]=encoded[:len(a)]
  return self.returned if self.returned is not None else len(self.summary)
 def poll(self):return self.runtime.invoke('机架联动_宿主回调',13,0,0,0,0)
 def command(self,operation):return self.runtime.invoke('机架联动_宿主回调',operation,0,0,0,0)

def check_authorization_log(check):
 f=AuthFixture();f.runtime.env.update({'集_机架桥入口':0,'集_机架授权诊断':'old'})
 check('unloaded bridge op13 returns preparation error without API calls',f.poll()==18 and not f.calls and not f.logs)
 check('unloaded bridge clears old diagnostic dedup state',f.runtime.env['集_机架授权诊断']=='')
 f=AuthFixture()
 check('op13 preserves actual error and reads only safe op15',f.poll()==3 and f.calls==[13,15])
 check('fixed auth summary reaches existing log sink',f.logs==[('机架联动：授权诊断：'+f.summary,'#日志级别_INFO')])
 for n in range(3):check('unchanged failure summary is deduplicated '+str(n),f.poll()==3 and len(f.logs)==1)
 f.summary='auth_stage=http http=401 auth_reason=invalid_credentials error=3'
 check('same error with changed safe reason logs a new line',f.poll()==3 and len(f.logs)==2 and f.logs[-1][0].endswith(f.summary))
 for code in (0,1,2,5,6,7,8,9,18,99):
  g=AuthFixture();g.poll();g.error=code;before=len(g.calls)
  check('non-auth or normal state clears dedup without op15 '+str(code),g.poll()==code and g.calls[before:]==[13] and g.runtime.env['集_机架授权诊断']=='')
  g.error=3
  check('same failure is logged again after clear '+str(code),g.poll()==3 and len(g.logs)==2)
 for code in (3,4,10,11,12,13):
  g=AuthFixture();g.error=code;g.summary='auth_stage=controller http=0 auth_reason=controller_rejected error='+str(code)
  check('authorization-related error receives safe diagnostic '+str(code),g.poll()==code and g.calls==[13,15] and len(g.logs)==1)
 for operation in (7,8):
  g=AuthFixture();g.poll();before=len(g.calls)
  check('explicit stop keeps original return and clears log dedup '+str(operation),g.command(operation)==123 and g.calls[before:]==[operation] and g.runtime.env['集_机架授权诊断']=='')
  g.poll();check('repeat failure after stop can be recorded '+str(operation),len(g.logs)==2)
 for loaded in (0,1):
  lock=[];held=__import__('types').SimpleNamespace(进入=lambda *a:lock.append('进入') or True,退出=lambda:lock.append('退出'))
  g=AuthFixture();g.runtime.env.update({'集_机架桥入口':loaded,'集_机架授权诊断':'old','集_机架引擎已启动':True,'集_机架引擎控制许可':held})
  stopped=[];g.runtime.functions['电音助手.关闭后台']=lambda:stopped.append(lock[:])
  g.runtime.invoke('机架联动_停止')
  check('public stop clears dedup with loaded state '+str(loaded),len(stopped)==1 and g.runtime.env['集_机架授权诊断']=='' and g.calls==([8] if loaded else []) and not g.logs)
  check('public stop stops the engine inside the start/stop lock and releases it '+str(loaded),stopped==[['进入']] and lock==['进入','退出'] and g.runtime.env['集_机架引擎已启动'] is False and g.runtime.env['集_机架退出中'] is True)
 # Exit while a window-close stop still holds the lock (it waits at most 10 s): the exit waits at most 15 s,
 # and if it still cannot get the lock it leaves the threads to that stop -- no handle touched twice, no unlock it never took.
 lock=[];busy=__import__('types').SimpleNamespace(进入=lambda *a:lock.append(('进入',)+a) and False,退出=lambda:lock.append(('退出',)))
 g=AuthFixture();g.runtime.env.update({'集_机架桥入口':0,'集_机架授权诊断':'old','集_机架引擎已启动':True,'集_机架引擎控制许可':busy})
 stopped=[];g.runtime.functions['电音助手.关闭后台']=lambda:stopped.append(True)
 g.runtime.invoke('机架联动_停止')
 check('exit waits for the start/stop lock at most 15 s and never stops or unlocks without it',stopped==[] and lock==[('进入',15000)] and any('交给它收尾' in l[0] for l in g.logs))
 # Executed: the late start when the window shows (only while the window is still open) and the relogin update,
 # both inside the start/stop lock, so a window close in between can never leave the engine running alone.
 for shown,started,exiting,expect in ((True,False,False,['start']),(False,False,False,[]),(True,True,False,['shown']),(True,False,True,[])):
  lock=[];held=__import__('types').SimpleNamespace(进入=lambda *a:lock.append('进入') or True,退出=lambda:lock.append('退出'))
  g=AuthFixture();g.runtime.env.update({'集_机架界面已显示':shown,'集_机架引擎已启动':started,'集_机架退出中':exiting,'集_机架引擎控制许可':held})
  did=[];g.runtime.functions['机架联动_启动引擎_内部']=lambda:did.append(('start',lock[:])) or True
  g.runtime.functions['电音助手.置界面已显示']=lambda v:did.append(('shown',lock[:]))
  g.runtime.functions['_ThreadVar_onThreadExit_tryCatch_All']=lambda:None
  g.runtime.invoke('机架联动_线程_启动引擎')
  check('engine starts inside the lock only while the window is open and the program is not exiting '+str((shown,started,exiting)),[d[0] for d in did]==expect and all(d[1]==['进入'] for d in did) and lock==['进入','退出'])
 for started in (False,True):
  lock=[];held=__import__('types').SimpleNamespace(进入=lambda *a:lock.append('进入') or True,退出=lambda:lock.append('退出'))
  g=AuthFixture();g.runtime.env.update({'集_机架引擎已启动':started,'集_机架引擎控制许可':held,'软件账号':'u','软件密钥':'k','电音助手_配置文本':'','全_服务端_电音基调_地址':'http://x','&电音助手_保存配置_回调函数':1,'&机架联动_日志':2})
  calls=[];g.runtime.functions['电音助手.启动后台']=lambda *a:calls.append(lock[:]) or True
  for f in ('电音助手.置后台语言','机架联动_交登录凭据','电音助手.重新连接','多语言_当前语言'):g.runtime.functions[f]=lambda *a:None
  g.runtime.functions['机架联动_登录后启动_内部']=lambda:g.runtime.invoke('机架联动_登录后启动_内部')   # its real source body
  g.runtime.invoke('机架联动_登录后启动')
  check('relogin updates only a running engine, inside the lock '+str(started),calls==([['进入']] if started else []) and lock==['进入','退出'])
 for returned in (-1,0,511,512,100000):
  g=AuthFixture();g.returned=returned
  check('invalid/legacy op15 length never logs '+str(returned),g.poll()==3 and not g.logs)
 for payload in ('Device=secret license=private', 'auth_stage=http\ncredential=secret',
                 'auth_stage=http\x00credential=secret', 'auth_stage=服务器 http=403',
                 'auth_stage=none http=0 auth_reason=none error=0',
                 'auth_stage=ready http=200 auth_reason=none error=0'):
  g=AuthFixture();g.summary=payload
  check('malformed or nonfailure diagnostic is ignored '+repr(payload),g.poll()==3 and not g.logs)
 f=AuthFixture();f.summary='auth_stage=verify_token http=200 auth_reason=token_validation_failed error=3';f.poll()
 check('local token validation failure is distinguishable in log',len(f.logs)==1 and 'verify_token' in f.logs[0][0])
 check('logging helper never calls full diagnostics', '调用桥 (12,' not in epl.section(SOURCE,'机架联动_授权诊断记录'))


def check_host_metadata_setup(check):
 # Real host op1 body; only synchronous bridge calls and host configuration
 # inputs are substituted. Metadata failures must reach the engine's existing
 # configuration retry path, without claiming configuration succeeded.
 def fixture(results,legacy='legacy-machine'):
  f=AuthFixture();calls=[];machine_reads=[]
  wide=lambda value:value.encode('utf-16le')+b'\0\0'
  def bridge(operation,a,b,c,d):
   calls.append((operation,a,b,c,d))
   assert operation in (1,11,14),'metadata setup must not stop or bypass the bridge gate'
   if operation==1:assert (a,b,c,d)==tuple(map(wide,('D:\\runtime','http://server','account','credential')))
   if operation==11:assert (a,b,c,d)==(PRODUCT,wide('zh-CN'),0,0)
   if operation==14:assert (a,b,c,d)==(wide(legacy),0,0,0)
   return results[operation]
  f.runtime.env.update({'全_服务端_电音基调_地址':'http://server','软件账号':'account','软件密钥':'credential','集_机架授权诊断':'old'})
  f.runtime.functions.update({'系统_取数值注册项':lambda *args:1,'机架联动_系统支持':lambda:True,
   '全_运行库.取路径':lambda:'D:\\runtime'.encode('utf-16le'),'ATU':lambda value,unused:wide(value),
   '多语言_当前语言':lambda:'zh-CN','取机器码':lambda:machine_reads.append(True) or legacy,
   '机架联动_调用桥':bridge})
  return f,calls,machine_reads
 # 桥拒绝配置时状态行显示「服务尚未配置，请联系支持」：日志写明原因（地址、账号、凭据都在时指向没内置公钥的桥），凭据内容不进日志
 f,calls,_=fixture({1:0,11:1,14:1})
 check('a refused configuration is logged with its reason and never the credential',f.command(1)==0
       and any('桥组件拒绝配置' in text and '没内置服务端公钥' in text for text,level in f.logs) and not any('credential' in text for text,level in f.logs))
 for label,results,legacy,expected,order in (
  ('complete metadata',{1:1,11:1,14:1},'legacy-machine',1,[1,11,14]),
  ('configuration rejected',{1:0,11:1,14:1},'legacy-machine',0,[1]),
  ('product metadata rejected',{1:1,11:0,14:1},'legacy-machine',0,[1,11]),
  ('empty machine metadata rejected',{1:1,11:1,14:0},'',0,[1,11,14]),
  ('oversize machine metadata rejected',{1:1,11:1,14:0},'m'*1025,0,[1,11,14])):
  f,calls,machine_reads=fixture(results,legacy)
  check('host setup return reflects '+label,f.command(1)==expected)
  check('host setup call order for '+label,[row[0] for row in calls]==order and bool(machine_reads)==(14 in order))
  check('host setup clears diagnostic dedup for '+label,f.runtime.env['集_机架授权诊断']=='')
 results={1:1,11:1,14:0};f,calls,machine_reads=fixture(results)
 check('metadata failure is returned for engine retry',f.command(1)==0)
 results[14]=1
 check('later full configuration retry can succeed',f.command(1)==1 and [row[0] for row in calls]==[1,11,14,1,11,14])

def main():
 tests=[]
 def check(name,value):
  assert value,name;tests.append(name)
 # 宿主用的 DLL 命令已统一放进精易模块（公开、不带前缀；参数不同的用 精易 惯用的类型后缀），主程序不再有 DLL.e.txt
 dll=(PROJECT/'模块/精易模块v9.3.5[源码].e~/DLL.e.txt').read_text('utf-8-sig').replace('\r\n','\n')
 check('main program declares no DLL commands of its own',not (PROJECT/'DLL.e.txt').exists())
 host_src=(PROJECT/'代码/集_基础支持/机架联动_宿主.static.e.txt').read_text('utf-8-sig')
 used=['RtlGetNtVersionNumbers_整数型','CreateFileW','ReadFile_整数型','WriteFile_整数型','GetFileSizeEx_逻辑型','LoadLibraryExW_字节集','GetSystemDirectoryW','GetEnvironmentVariableW','GetTempPathA_字节集','GetEnvironmentVariableA_字节集','SetFilePointerEx_整数型','GetFileInformationByHandle_字节集','SetFileInformationByHandle']
 blocks={}
 for name in used:
  check('host calls '+name,name+' (' in host_src)
  m=re.search(r'^\.DLL命令 '+re.escape(name)+r', [^,\n]*, "[^"]*", "[^"]*", 公开,[^\n]*\n(?:[ \t]*\.参数[^\n]*\n)*',dll,re.M)
  check('精易 declares '+name+' publicly',m is not None)
  blocks[name]=m.group(0)
 check('host no longer uses 机架_ DLL names',not re.search(r'机架_(?:取NT版本|CreateFileW|ReadFile|WriteFile|GetFileSizeEx|LoadLibraryExW|GetSystemDirectoryW|GetEnvironmentVariable[AW]|GetTempPathA|SetFilePointerEx|GetFileInformationByHandle|SetFileInformationByHandle)\b',host_src))
 for name,param,kind in [('ReadFile_整数型','lpNumberOfBytesRead','整数型'),('WriteFile_整数型','已写','整数型'),('GetFileSizeEx_逻辑型','大小','长整数型'),('RtlGetNtVersionNumbers_整数型','主','整数型'),('RtlGetNtVersionNumbers_整数型','次','整数型'),('RtlGetNtVersionNumbers_整数型','构建','整数型')]:
  check('DLL output uses 传址 '+name+' '+param,f'.参数 {param}, {kind}, 传址,' in blocks[name])
 check('host DLL declarations never use subroutine-only 参考',not any(re.search(r'^\s*\.参数 [^\n]*, 参考,',b,re.M) for b in blocks.values()))
 f=Fixture();env={'data':b'ABC','pos':1,'#字节型':1}
 check('core boundary advances a variable index',f.eval('取字节集数据 (data, #字节型, pos)',env)==65 and env['pos']==2)
 env['pos']=3
 check('core boundary marks the exhausted variable index',f.eval('取字节集数据 (data, #字节型, pos)',env)==67 and env['pos']==-1)
 env['pos']=2
 check('core boundary expression keeps caller index unchanged',f.eval('取字节集数据 (data, #字节型, 相加 (pos, 0))',env)==66 and env['pos']==2)
 for suffix in ['', '\r\n', '   ', '\t', '\r\nignored-after-first-line']:
  f=Fixture();f.put(f.temp+'at8_commdir.txt',('D:\\运行目录'+suffix).encode('cp936'));f.put('D:\\运行目录\\agent.log',b'pointer-current\r\n')
  result=f.run('机架联动_诊断文本')
  check('directory pointer peeks do not advance cursor '+repr(suffix),'pointer-current' in result and f.byte_positions and all(argument.startswith('相加 (') for position,argument in f.byte_positions))
 f=Fixture();native='agent loaded [中文机架.exe] module=D:\\机架\\电音11.vst3\r\n'.encode('cp936');path=f.local+'\\AutoTune_KeyScale\\agent.log';f.put(path,native)
 result=f.run('机架联动_诊断文本');check('native ANSI Chinese log preserved','中文机架.exe' in result and '电音11.vst3' in result)
 check('UTF8 assumption demonstrably corrupts CP936',native.decode('utf-8','replace')!=native.decode('cp936'))
 f=Fixture();f.put(f.temp+'at8_commdir.txt','D:\\运行目录\r\n'.encode('cp936'));f.put('D:\\运行目录\\agent.log',b'pointer-current\r\n');result=f.run('机架联动_诊断文本');check('actual native pointer directory including CRLF and Chinese','pointer-current' in result)
 f=Fixture();f.put(f.temp+'at8\\agent.log',b'fallback-log\r\n');check('LOCALAPPDATA-unusable fallback included','fallback-log' in f.run('机架联动_诊断文本'))
 f=Fixture();f.temp='C:\\张三\\TMP\\';f.put(f.temp+'at8\\agent.log',b'Chinese-temp-log\r\n');check('ANSI GetTempPath byte count preserves Chinese directory','Chinese-temp-log' in f.run('机架联动_诊断文本'))
 f=Fixture();f.put(f.emergency+'\\at8_agent.log',b'emergency-log\r\n');check('TEMP logger emergency independent of TMP GetTempPath','emergency-log' in f.run('机架联动_诊断文本'))
 f=Fixture();f.put(f.temp+'at8_commdir.txt',(f.local+'\\AutoTune_KeyScale\n').encode('cp936'));f.put(path,b'unique-marker\r\n');check('pointer/default log deduplicated',f.run('机架联动_诊断文本').count('unique-marker')==1)
 f=Fixture();large=b'old-line\r\n'*5000+b'last-line\r\n';f.put(path,large);result=f.run('机架联动_诊断文本');check('tail bounded and keeps final record',len(result)<34000 and result.endswith('last-line\r\n\r\n') and max(f.read_sizes)<=32768)
 check('handles closed on all successful paths',not f.handles)
 f=Fixture();f.put(path,large);f.seek_ok=False;check('seek failure never substitutes old beginning',f.run('机架联动_读取诊断文件',path.encode('utf-16le')+b'\0\0',32768,True)==b'' and not f.handles)
 f=Fixture();f.put(f.temp+'at8_commdir.txt',b'x'*100000);check('oversized pointer never allocated/read',f.run('机架联动_读取诊断文件',(f.temp+'at8_commdir.txt').encode('utf-16le')+b'\0\0',260,False)==b'' and not f.read_sizes and not f.handles)
 check('empty paths never open relative files',f.run('机架联动_读取诊断文件',b'',32768,True)==b'')
 check_authorization_log(check)
 check_host_metadata_setup(check)
 print(json.dumps({'scope':__doc__,'passed':len(tests),'checks':tests},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
