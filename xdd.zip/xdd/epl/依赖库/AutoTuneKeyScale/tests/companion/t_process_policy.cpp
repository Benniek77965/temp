/* Exact controller and agent process-policy functions. Win32 process identity and
   image APIs are explicit boundaries; signed policy matching is the real header. */
#include "companion_policy.h"
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
typedef int BOOL;typedef void* HANDLE;typedef int32_t LONG;
#define FALSE 0
#define PROCESS_QUERY_LIMITED_INFORMATION 1
#define TOKEN_QUERY 2
#define TokenUser 3
#define TokenSessionId 4
struct TOKEN_USER {struct {void* Sid;} User;};
static int g_managed=1,g_authorized=1,g_compLock=0;
static LONG g_compAuthError=0;
static ATCS_Claims g_compLease;
static int processOpen=1,ownToken=1,targetToken=1,sameSid=1,sameSession=1,tokenInfo=1,imageOk=1,imageTruncated=0;
static int nativeBits=64,compatibility=0,archQueries=0,imageQueries=0,openHandles=0;
static const wchar_t* imagePath=L"C:\\Audio\\reaper.exe";
static HANDLE OpenProcess(DWORD,BOOL,DWORD){if(!processOpen)return NULL;++openHandles;return (void*)3;}
static HANDLE GetCurrentProcess(){return (void*)2;}
static BOOL OpenProcessToken(HANDLE h,DWORD,HANDLE* out){if(h==(void*)2?!ownToken:!targetToken)return 0;*out=h==(void*)2?(void*)4:(void*)5;++openHandles;return 1;}
static BOOL GetTokenInformation(HANDLE h,DWORD type,void* out,DWORD,DWORD* actual){if(!tokenInfo)return 0;if(type==TokenUser){((TOKEN_USER*)out)->User.Sid=(h==(void*)4||sameSid)?(void*)6:(void*)7;*actual=sizeof(TOKEN_USER);}else{*(DWORD*)out=(h==(void*)4||sameSession)?11:12;*actual=sizeof(DWORD);}return 1;}
static BOOL EqualSid(void* a,void* b){return a==b;}
static BOOL CloseHandle(HANDLE){--openHandles;return 1;}
static LONG InterlockedOr(LONG* value,LONG bits){LONG old=*value;*value|=bits;return old;}
/* Kept to execute a pre-fix extracted function as a negative control too. */
static BOOL IsWow64Process(HANDLE,BOOL* wow){++archQueries;*wow=nativeBits==64&&compatibility;return 1;}
static BOOL QueryFullProcessImageNameW(HANDLE,DWORD,wchar_t* out,DWORD* n){++imageQueries;if(!imageOk)return 0;wcscpy(out,imagePath);*n=imageTruncated?32768:(DWORD)wcslen(imagePath);return 1;}
static DWORD GetModuleFileNameW(HANDLE,wchar_t* out,DWORD cap){++imageQueries;if(!imageOk)return 0;wcscpy(out,imagePath);return imageTruncated?cap:(DWORD)wcslen(imagePath);}
static void EnterCriticalSection(int* depth){++*depth;}
static void LeaveCriticalSection(int* depth){--*depth;}
#include "controller_process_policy.inc"
#define agent_policy_host agent_policy_host_32
#undef _WIN64
#include "agent_host_policy.inc"
#undef agent_policy_host
#define agent_policy_host agent_policy_host_64
#define _WIN64 1
#include "agent_host_policy.inc"
#undef agent_policy_host
#undef _WIN64
static LONG g_ejecting=0;static int parentAlive=1;
static int atcs_pid_alive(DWORD){return parentAlive;}
struct PublicSnapshot{ATCS_Claims policy;};static PublicSnapshot publicSnapshot;static PublicSnapshot* selectedSnapshot=NULL;
struct ATCS_LoaderRead{PublicSnapshot* snapshot;ATCS_LoaderRead():snapshot(selectedSnapshot){}};
#define AT_XHH_MANAGED 1
#define agent_policy_host agent_policy_host_64
#define agent_ui_install_allowed install_policy_managed
#include "agent_install_policy.inc"
#undef agent_ui_install_allowed
#undef agent_policy_host
#undef AT_XHH_MANAGED
#define AT_XHH_MANAGED 0
#define agent_ui_install_allowed install_policy_standalone
#include "agent_install_policy.inc"
#undef agent_ui_install_allowed
#undef AT_XHH_MANAGED
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL process-policy line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static void reset(){g_managed=g_authorized=1;g_compAuthError=0;memset(&g_compLease,0,sizeof g_compLease);g_compLease.policy=1;g_compLease.expires=atcs_now()+60;processOpen=ownToken=targetToken=sameSid=sameSession=tokenInfo=imageOk=1;imageTruncated=0;imageQueries=archQueries=openHandles=g_compLock=0;imagePath=L"C:\\Audio\\reaper.exe";}
static void filtered(){const char name[]="reaper.exe";atcs_hex_encode((const unsigned char*)name,sizeof name-1,g_compLease.racks);}
int main(){
 for(int arch=0;arch<3;arch++){
  reset();nativeBits=arch==0?32:64;compatibility=arch==1;CHECK(companion_policy_process(123)==1);CHECK(imageQueries==1&&openHandles==0&&g_compLock==0);
  filtered();CHECK(companion_policy_process(123)==0);CHECK(openHandles==0);
  reset();imageOk=0;CHECK(companion_policy_process(123)==0);CHECK(openHandles==0);
  reset();imageTruncated=1;CHECK(companion_policy_process(123)==0);CHECK(openHandles==0);
  reset();g_compLease.expires=atcs_now();CHECK(companion_policy_process(123)==0);CHECK(openHandles==0);
  reset();g_authorized=0;CHECK(companion_policy_process(123)==0);CHECK(openHandles==0);
 }
 reset();sameSid=0;CHECK(companion_policy_process(123,1)==0);CHECK((g_compAuthError&32)&&openHandles==0);
 reset();sameSession=0;CHECK(companion_policy_process(123,1)==0);CHECK((g_compAuthError&32)&&openHandles==0);
 reset();sameSid=0;CHECK(companion_policy_process(123)==0);CHECK(g_compAuthError==0&&openHandles==0);
 reset();ownToken=0;CHECK(companion_policy_process(123,1)==0);CHECK(openHandles==0);
 reset();targetToken=0;CHECK(companion_policy_process(123,1)==0);CHECK(openHandles==0);
 reset();tokenInfo=0;CHECK(companion_policy_process(123,1)==0);CHECK(openHandles==0);
 reset();processOpen=0;CHECK(companion_policy_process(123)==0);CHECK(openHandles==0);
 reset();g_managed=0;processOpen=0;CHECK(companion_policy_process(123)==1);CHECK(imageQueries==0);
 for(int arch=0;arch<2;arch++){
  reset();int (*host)(const ATCS_Claims*)=arch?agent_policy_host_64:agent_policy_host_32;
  CHECK(host(&g_compLease)==1);filtered();CHECK(host(&g_compLease)==0);
  reset();imageOk=0;CHECK(host(&g_compLease)==0);
  reset();imageTruncated=1;CHECK(host(&g_compLease)==0);
  reset();CHECK(host(NULL)==0);g_compLease.policy=0;CHECK(host(&g_compLease)==0);
 }
 reset();g_ejecting=0;parentAlive=1;publicSnapshot.policy=g_compLease;publicSnapshot.policy.parent=42;selectedSnapshot=&publicSnapshot;CHECK(install_policy_managed());selectedSnapshot=NULL;CHECK(!install_policy_managed());selectedSnapshot=&publicSnapshot;publicSnapshot.policy.expires=atcs_now();CHECK(!install_policy_managed());publicSnapshot.policy=g_compLease;parentAlive=0;CHECK(!install_policy_managed());parentAlive=1;filtered();publicSnapshot.policy=g_compLease;CHECK(!install_policy_managed());reset();publicSnapshot.policy=g_compLease;imageOk=0;CHECK(!install_policy_managed());imageOk=1;g_ejecting=1;CHECK(!install_policy_managed()&&!install_policy_standalone());g_ejecting=0;selectedSnapshot=NULL;CHECK(install_policy_standalone());
 printf("PASS production process policy: %u checks (native x86/WOW64/x64; identity/path APIs substituted)\n",checks);
}
