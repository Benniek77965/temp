/* Full production status reader and status reply; Win32 enumeration/UI are
   explicit boundaries. Real stdio reads exercise complete and failed files. */
#include "companion_protocol.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <string>
typedef int32_t LONG;typedef uintptr_t WPARAM;typedef intptr_t LPARAM;typedef intptr_t LRESULT;typedef void* HANDLE;typedef void* HWND;typedef uint32_t DWORD;
#define INVALID_HANDLE_VALUE ((HANDLE)(intptr_t)-1)
#define MAX_PATH 260
#define MAXINST 64
#define INSTSIG_SZ (MAXINST*120+64)
#define STATUS_LINE_PARSE 1024
#define AGG_SZ (MAXINST*320+1024)
#include "controller_build.inc"
#define CP_ACP 0
#define CB_GETDROPPEDSTATE 1
#define CB_GETCURSEL 2
#define CB_RESETCONTENT 3
#define CB_ADDSTRING 4
#define CB_SETCURSEL 5
#define ERROR_SHARING_VIOLATION 32
#define ATC_APPLY_MESSAGE 0x8003
struct WIN32_FIND_DATAA {char cFileName[MAX_PATH];};
static struct {unsigned long pid;char leaf[96],label[160];unsigned id;char caps[16];}g_insts[MAXINST];
static int g_ninst=0,g_managed=1,g_authorized=1,g_compGoalValid=1,g_compLock=0;
static LONG g_aggFull=0,g_compCaptured=0,g_compPending=0,g_compConfirmed=0,g_compHasR=0,g_compStrength=-1,g_compMixedFamily=0,g_compOld=0,g_compAuthError=0,g_compRebuilding=0,g_compNeedReplay=0;
static volatile LONG g_compMismatchFull=0;
static int g_nLegacy=0,g_cmdWriteFail=0,g_agentMissing=0,g_agentStale=0,g_blockedHosts=0,g_blockedOther=0,g_hostsOverflow=0,g_sgFull=0,g_compRacks=1;
static unsigned long g_compScopePid=0;static unsigned g_compScopeId=0;static char g_compScopeLeaf[96]="";
static int g_compPaused=0,g_compPauseAcknowledged=0,g_ninj=1;
static uint64_t g_compPauseSequence=0;static char g_compPauseSid[33]="";
static uint64_t g_compGeneration=1;static ATC_Apply g_compGoal={0,2,-1};
static char COMMDIR[MAX_PATH]="fixture",g_instSig[INSTSIG_SZ]="",g_statusLoaded[AGG_SZ+32]="";
static HWND g_target=(void*)1,g_mainWindow=(void*)2,g_list=(void*)3;
static std::string fileContents;static bool sharingFailure=false,filePresent=true,dropped=false;static unsigned uiResets=0,posted=0,deleted=0,findCloses=0;
static HANDLE FindFirstFileA(const char*,WIN32_FIND_DATAA* out){if(!filePresent)return INVALID_HANDLE_VALUE;strcpy(out->cFileName,"status_10.txt");return (void*)4;}
static int FindNextFileA(HANDLE,WIN32_FIND_DATAA*){return 0;}
static int FindClose(HANDLE){++findCloses;return 1;}
static int DeleteFileA(const char*){++deleted;return 1;}
static DWORD GetLastError(){return sharingFailure?ERROR_SHARING_VIOLATION:0;}
static bool tracked=true,allowedHost=true,ownerAlive=true;
static int is_injected(DWORD pid){return tracked&&pid==10;}static int companion_policy_process(DWORD){return allowedHost;}static int file_owner_alive(const char*,unsigned long){return ownerAlive;}
static FILE* fixture_fopen(const char*,const char*){if(sharingFailure)return NULL;const char* directory=getenv("ATC_TEST_TMP");if(!directory){fprintf(stderr,"ATC_TEST_TMP is required\n");abort();}std::string path=std::string(directory)+"/status-capacity-fixture.tmp";FILE* f=fopen(path.c_str(),"w+b");if(!f){perror("status fixture fopen");abort();}fwrite(fileContents.data(),1,fileContents.size(),f);rewind(f);return f;}
static void EnterCriticalSection(int* n){++*n;}
static void LeaveCriticalSection(int* n){--*n;}
static LONG InterlockedCompareExchange(volatile LONG* p,LONG v,LONG expected){LONG old=*p;if(old==expected)*p=v;return old;}
static LONG InterlockedExchange(volatile LONG* p,LONG v){LONG old=*p;*p=v;return old;}
static LRESULT SendMessageA(HWND,unsigned msg,WPARAM w,LPARAM){if(msg==CB_GETDROPPEDSTATE)return dropped;if(msg==CB_GETCURSEL)return 0;if(msg==CB_RESETCONTENT)++uiResets;if(msg==CB_SETCURSEL)return w;return 1;}
static LRESULT SendMessageW(HWND h,unsigned msg,WPARAM w,LPARAM l){return SendMessageA(h,msg,w,l);}
static int PostMessageA(HWND,unsigned,WPARAM,LPARAM){++posted;return 1;}
static void apply_capabilities(){}
static void rebuild_scale_list(){}
static int MultiByteToWideChar(unsigned,DWORD,const char* in,int,wchar_t* out,int cap){size_t n=strlen(in);if((int)n>=cap)return 0;for(size_t i=0;i<=n;i++)out[i]=(unsigned char)in[i];return (int)n+1;}
static int SetWindowTextW(HWND,const wchar_t*){return 1;}
static const wchar_t* ui(const wchar_t*,const wchar_t* en){return en;}
static int legacy_agent_build(){return -1;}
static int status_banner(wchar_t* out,size_t,int,int,int){*out=0;return 0;}
static void companion_log(const char*,int,int,int){}
static int at_stricmp(const char* a,const char* b){return strcmp(a,b);}
#define _stricmp at_stricmp
#define fopen fixture_fopen
#include "controller_status.inc"
#undef fopen
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL full status-capacity line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static std::string status_header(){return "#b"+std::to_string(AT_BUILD_EXPECT)+" m=1\n";}
static void reset(){g_aggFull=g_compCaptured=g_compPending=g_compConfirmed=g_compOld=0;g_compScopePid=g_compScopeId=0;g_compScopeLeaf[0]=g_instSig[0]=g_statusLoaded[0]=0;g_compGeneration++;g_compPaused=g_compPauseAcknowledged=0;g_compPauseSequence=0;g_compPauseSid[0]=0;g_ninj=1;g_compGoalValid=1;g_compGoal={0,2,-1};g_ninst=0;g_compNeedReplay=0;sharingFailure=false;filePresent=true;tracked=allowedHost=ownerAlive=true;g_compMismatchFull=0;dropped=false;uiResets=posted=deleted=findCloses=0;fileContents=status_header();}
static void add(unsigned id,bool pending){char line[180];if(pending)sprintf(line,"rack | pending%u  [[PENDING]]\n",id);else sprintf(line,"rack | tuner%u  Key=C  Scale=Chromatic\1%08X KS\n",id,id);fileContents+=line;}
static bool overflow(){return ((uint32_t)companion_status_reply()&0x02000000U)!=0;}
int main(){
 reset();for(unsigned i=1;i<=32;i++)add(i,false);for(unsigned i=33;i<=64;i++)add(i,true);read_status();CHECK(g_ninst==64&&g_compCaptured==32&&g_compPending==32&&g_compConfirmed==32);CHECK(!g_aggFull&&!overflow());CHECK(uiResets==0&&posted==1&&findCloses==1&&g_compLock==0);
 reset();for(unsigned i=1;i<=33;i++)add(i,false);for(unsigned i=34;i<=65;i++)add(i,true);read_status();CHECK(g_ninst==64&&g_compCaptured==33&&g_compPending==32&&g_compConfirmed==33);CHECK(g_aggFull&&overflow());CHECK(g_insts[63].id==0&&strstr(g_insts[63].leaf,"pending64"));
 reset();for(unsigned i=1;i<=64;i++)add(i,true);fileContents+="\ninvalid trailing line\n  \r\n";read_status();CHECK(g_ninst==64&&g_compPending==64);CHECK(g_aggFull==0);CHECK(overflow()); /* protocol six-bit count saturation itself still reports 64 */
 reset();for(unsigned i=1;i<=32;i++)add(i,false);for(unsigned i=33;i<=64;i++)add(i,true);fileContents+="\ninvalid trailing line\n  \r\n";read_status();CHECK(g_ninst==64&&g_compPending==32);CHECK(!g_aggFull&&!overflow());
 /* A valid record beyond Target capacity is still counted when it is selected. */
 reset();for(unsigned i=1;i<=65;i++)add(i,false);g_compScopePid=10;g_compScopeId=65;strcpy(g_compScopeLeaf,"tuner65");dropped=true;read_status();CHECK(g_compCaptured==1&&g_compConfirmed==0&&g_aggFull&&overflow());CHECK(g_ninst==64&&uiResets==0&&g_compScopePid==0); /* Headless instance table publishes immediately; absent scope falls back safely. */
 /* Failed reads must retain the entire published capacity warning, not only counts. */
 reset();for(unsigned i=1;i<=33;i++)add(i,false);for(unsigned i=34;i<=65;i++)add(i,true);read_status();CHECK(g_aggFull&&g_compCaptured==33&&g_compPending==32);sharingFailure=true;read_status();CHECK(g_aggFull&&overflow()&&g_compCaptured==33&&g_compPending==32&&g_ninst==64);sharingFailure=false;fileContents=status_header()+"rack | partial";read_status();CHECK(g_aggFull&&overflow()&&g_compCaptured==33&&g_compPending==32&&g_ninst==64);
 /* Growing/shrinking sets publish exactly bounded Target lists and replay intent. */
 reset();for(unsigned i=1;i<=64;i++)add(i,false);read_status();CHECK(g_ninst==64&&uiResets==0);fileContents=status_header();add(70,false);read_status();CHECK(g_ninst==1&&g_insts[0].id==70&&uiResets==0&&posted==2&&g_compCaptured==1&&!g_aggFull);
 /* Sharing failure and incomplete records preserve prior published set/counts. */
 unsigned oldCount=g_ninst;LONG oldCap=g_compCaptured,oldConf=g_compConfirmed;sharingFailure=true;read_status();CHECK(g_ninst==(int)oldCount&&g_compCaptured==oldCap&&g_compConfirmed==oldConf&&uiResets==0);
 sharingFailure=false;fileContents=status_header()+"rack | partial";read_status();CHECK(g_ninst==(int)oldCount&&g_compCaptured==oldCap&&g_compConfirmed==oldConf&&uiResets==0);
 reset();add(1,false);tracked=false;read_status();CHECK(deleted==0&&g_ninst==0);ownerAlive=false;read_status();CHECK(deleted==1&&g_ninst==0);ownerAlive=true;allowedHost=false;read_status();CHECK(deleted==2);g_compMismatchFull=1;CHECK(overflow());g_compMismatchFull=0;CHECK(!overflow());
 reset();g_compPaused=1;g_compGoalValid=0;g_compPauseSequence=12;strcpy(g_compPauseSid,"0123456789abcdef0123456789abcdef");
 fileContents=status_header()+"#pause sid=0123456789abcdef0123456789abcdef seq=12 state=1\n";add(1,false);read_status();CHECK(g_compPauseAcknowledged==1&&posted==0);
 const char* invalid[]={"#pause sid=0123456789abcdef0123456789abcdee seq=12 state=1\n","#pause sid=0123456789abcdef0123456789abcdef seq=11 state=1\n","#pause sid=0123456789abcdef0123456789abcdef seq=12 state=0\n","#pause sid=0123456789abcdef0123456789abcdef seq=012 state=1\n","#pause sid=0123456789abcdef0123456789abcdef seq=18446744073709551616 state=1\n","#pause sid=0123456789abcdef0123456789abcdef seq=12 state=1 extra\n"};
 for(unsigned i=0;i<sizeof invalid/sizeof invalid[0];i++){fileContents=status_header()+invalid[i];read_status();CHECK(!g_compPauseAcknowledged);}
 fileContents=status_header()+"#pause sid=0123456789abcdef0123456789abcdef seq=13 state=1\n";read_status();CHECK(g_compPauseAcknowledged);g_ninj=2;read_status();CHECK(!g_compPauseAcknowledged);
 g_ninj=0;filePresent=false;read_status();CHECK(g_compPauseAcknowledged);
 printf("PASS production full status capacity: %u checks (real stdio; Win32 enumeration/UI substituted)\n",checks);
}
