/* Exact production discovery/unload predicates with a fake VST3 controller.
   This is not a loaded plug-in, hook-lifetime or audio integration test. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <algorithm>
#include <math.h>
#include "vst3_abi.h"
typedef int32_t LONG;
static const char* g_module="";
static int g_waves=0,g_failIndex=-1;
struct TestParam{const char* name;ParamID id;int steps;};
static std::vector<TestParam> g_parameters;
static int modmap_get(void*,char* out,int n){snprintf(out,n,"%s",g_module);return *g_module!=0;}
static int waves_known(void*){return g_waves;}
static double g_fRet=-1,g_fSpeed=-1,g_fHum=-1,g_fNvb=-1;
static int g_fAudio=-1,g_cs=0;
static LONG g_ejecting=0;
static unsigned g_setCount=0,g_sideEffects=0,g_reloadCalls=0,g_statusCalls=0;
static int g_setKey=-1;
static double g_setRet=-1,g_setSpeed=-1;
static char g_setScale[64]="";
static void EnterCriticalSection(int* p){++*p;}
static void LeaveCriticalSection(int* p){--*p;}
static void cmd_side_effects(const char* line){++g_sideEffects;if(strstr(line,"reload="))++g_reloadCalls;}
static void parse_target(const char*){}
static void do_set(int key,const char* scale){++g_setCount;g_setKey=key;snprintf(g_setScale,sizeof g_setScale,"%s",scale);g_setRet=g_fRet;g_setSpeed=g_fSpeed;}
static void write_status(){++g_statusCalls;}
#define AT_XHH_MANAGED 1
#define LOG(...) ((void)0)
#define _stricmp(a,b) at_stricmp((a),(b))
#define tolower(c) at_lower(c)
#include "agent_discovery.inc"
static unsigned checks=0;
static void check(bool ok,const char* e,int line){++checks;if(!ok){fprintf(stderr,"FAIL agent line %d: %s\n",line,e);exit(1);}}
#define CHECK(x) check(!!(x),#x,__LINE__)
static int32_t count(void*){return g_parameters.size();}
static tresult info(void*,int32_t i,ParameterInfo* out){
    if(i==g_failIndex)return kResultFalse;
    memset(out,0,sizeof *out);out->id=g_parameters[i].id;out->stepCount=g_parameters[i].steps;
    const char* name=g_parameters[i].name;for(unsigned j=0;name[j]&&j<127;j++)out->title[j]=(unsigned char)name[j];return kResultOk;
}
static V3Disc discover(){
    static IEditControllerVtbl table={};table.getParameterCount=count;table.getParameterInfo=info;
    static IEditController controller={&table};V3Disc d;disc_fill(&controller,&d);return d;
}
static void test_apply_gate(){
    char last[4096]="";
    char fresh[]="key=5|scale=Major|retune=0.750|speed=0.250\n";
    agent_apply_command(fresh,last,1);
    CHECK(g_setCount==1&&g_setKey==5&&!strcmp(g_setScale,"Major"));
    CHECK(fabs(g_setRet-0.75)<1e-9&&fabs(g_setSpeed-0.25)<1e-9);
    char staleFeel[]="retune=0.250|speed=0.750\n";
    agent_apply_command(staleFeel,last,0);
    CHECK(g_setCount==1&&g_fRet==-1&&g_fSpeed==-1);
    CHECK(fabs(g_setRet-0.75)<1e-9&&fabs(g_setSpeed-0.25)<1e-9); /* no parameter write */
    char staleKey[]="key=7|scale=Minor|retune=0.250|speed=0.750\n";
    agent_apply_command(staleKey,last,0);
    CHECK(g_setCount==2&&g_setKey==7&&!strcmp(g_setScale,"Minor"));
    CHECK(g_setRet==-1&&g_setSpeed==-1); /* do_set receives only the key/scale */
    char control[]="reload=scalemap\n";agent_apply_command(control,last,0);
    CHECK(g_reloadCalls==1&&g_sideEffects==4&&g_setCount==2);
    char truncated[]="key=9|scale=Major";agent_apply_command(truncated,last,1);
    CHECK(g_sideEffects==4&&g_setCount==2);
    CHECK(g_cs==0&&g_statusCalls==2);
    g_ejecting=1;char stopped[]="key=9|scale=Minor|retune=0.9\n";agent_apply_command(stopped,last,1);CHECK(g_setCount==2&&g_sideEffects==4&&g_statusCalls==2);
    g_ejecting=0;agent_apply_command(stopped,last,1);CHECK(g_setCount==3&&g_setKey==9&&g_statusCalls==3);
}
int main(){
    TestParam tpain[]={{"Root note",101,11},{"Scale",102,7},{"Speed",103,0}};
    int indices[]={0,1,2};
    do{
        g_parameters.clear();for(int i=0;i<3;i++)g_parameters.push_back(tpain[indices[i]]);
        g_module="";g_waves=0;V3Disc d=discover();
        CHECK(d.isTPain&&d.isTuner&&d.discDone&&!d.isWaves);
        CHECK(d.haveK&&d.keyId==101&&d.haveS&&d.scaleId==102);
        CHECK(d.haveWSpeed&&d.wSpeedId==103&&!d.haveRet);
    }while(std::next_permutation(indices,indices+3));
    /* A module identity can identify T-Pain even when it calls its root Key. */
    g_parameters={{"Speed",9,0},{"Key",10,11},{"Scale",11,7}};g_module="The T-Pain Effect.vst3";
    V3Disc d=discover();CHECK(d.isTPain&&d.haveWSpeed&&d.wSpeedId==9&&d.isTuner);
    g_module="TPAIN.vst3";d=discover();CHECK(d.isTPain&&d.haveWSpeed);
    g_module="ordinary.vst3";d=discover();CHECK(!d.isTPain&&!d.isWaves&&!d.haveWSpeed&&d.isTuner);
    /* Waves layout remains gated by the actual shell/module association. */
    g_parameters={{"Speed",41,0},{"Scale Type",42,43},{"Root",43,16},{"Note Transition",44,0},{"Vibrato Depth",45,0},{"Range",46,4}};
    g_waves=1;g_module="WaveShell-VST3.vst3";d=discover();
    CHECK(d.isWaves&&!d.isTPain&&d.isTuner&&d.haveWSpeed&&d.wSpeedId==41);
    CHECK(d.keyId==43&&d.scaleId==42&&d.haveWTrans&&d.haveWVib&&d.haveWRange);
    g_waves=0;g_module="ordinary.vst3";d=discover();CHECK(!d.isTuner&&!d.haveWSpeed&&!d.haveK);
    g_parameters={{"Key",1,11},{"Scale",2,7},{"Retune Speed",3,0},{"Speed",4,0}};
    d=discover();CHECK(d.isTuner&&d.haveRet&&d.retId==3&&!d.haveWSpeed&&!d.isTPain);
    g_parameters={{"Root note extra",1,11},{"Scale",2,7},{"Speed",3,0}};
    d=discover();CHECK(!d.isTPain&&!d.isTuner&&!d.haveWSpeed);
    g_parameters={{" Speed ",3,0},{" root NOTE ",1,11},{" SCALE ",2,7}};
    d=discover();CHECK(d.isTPain&&d.isTuner&&d.haveWSpeed&&d.wSpeedId==3);
    g_failIndex=0;d=discover();CHECK(d.isTPain&&d.isTuner&&!d.haveWSpeed);g_failIndex=-1;
    g_parameters.clear();d=discover();CHECK(!d.discDone&&!d.isTuner&&!d.haveWSpeed);
    test_apply_gate();
    printf("PASS extracted agent discovery/apply: %u checks (fake VST3 controller/parameter sink)\n",checks);return 0;
}
