/* The exact production token verifier is extracted. Only platform signature
   result/time are substituted; parsing, parent/device/lease checks stay real. */
#include "companion_security.h"
#include <stdlib.h>
static unsigned checks=0,g_signatureCalls=0;
static int g_signatureAccept=1;
static uint64_t g_clock=1000;
static uint64_t harness_now(){return g_clock;}
static int harness_signature(const unsigned char*,unsigned,const unsigned char[256]){++g_signatureCalls;return g_signatureAccept;}
#define atcs_now harness_now
#define atcs_verify_signature harness_signature
#define atcs_verify_token extracted_atcs_verify_token
#include "token_verifier.inc"
#undef atcs_verify_token
#undef atcs_verify_signature
#undef atcs_now
static void check(bool ok,const char* e,int line){++checks;if(!ok){fprintf(stderr,"FAIL token line %d: %s\n",line,e);exit(1);}}
#define CHECK(x) check(!!(x),#x,__LINE__)
static const char* DEVICE="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
static std::string claims(){return std::string("ver=3\nsid=0123456789abcdef0123456789abcdef\nlic=L1\ndev=")+DEVICE+"\nparent=42\niat=1000\nexp=1120\nkey=000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f\npolicy=1\nracks=\nplugins=\n";}
static std::string b64(const std::string& s){
    const char* alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
    std::string out;unsigned bits=0,accum=0;
    for(unsigned i=0;i<s.size();i++){accum=(accum<<8)|(unsigned char)s[i];bits+=8;while(bits>=6){bits-=6;out+=alphabet[(accum>>bits)&63];}}
    if(bits)out+=alphabet[(accum<<(6-bits))&63];return out;
}
static std::string token(const std::string& c){return "XAT3."+b64(c)+"."+b64(std::string(256,0));}
static std::string replace(std::string s,const char* from,const char* to){size_t p=s.find(from);CHECK(p!=std::string::npos);s.replace(p,strlen(from),to);return s;}
static bool verify(const std::string& t,ATCS_Claims* c,DWORD parent=42,const char* device=DEVICE){return extracted_atcs_verify_token(t.data(),t.size(),parent,device,c)!=0;}
int main(){
    std::string good=token(claims());ATCS_Claims c;
    CHECK(verify(good,&c));CHECK(c.parent==42&&c.issued==1000&&c.expires==1120&&c.policy==1);
    /* Native production verifier never substitutes a signature success. */
    CHECK(!atcs_verify_token(good.data(),good.size(),42,DEVICE,&c));
    g_signatureAccept=0;memset(&c,0x55,sizeof c);ATCS_Claims unchanged=c;
    CHECK(!verify(good,&c));CHECK(!memcmp(&c,&unchanged,sizeof c));g_signatureAccept=1;
    CHECK(!verify(good,&c,43));CHECK(!verify(good,&c,0));
    CHECK(!verify(good,&c,42,"baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    CHECK(!verify(good,&c,42,""));CHECK(!verify(good,&c,42,NULL));CHECK(!verify(good,NULL));
    CHECK(!extracted_atcs_verify_token(NULL,good.size(),42,DEVICE,&c));
    unsigned saved=g_signatureCalls;
    std::string wrong=good;wrong[0]='Y';CHECK(!verify(wrong,&c));CHECK(g_signatureCalls==saved);
    wrong=good;wrong[wrong.find('.',5)]='x';CHECK(!verify(wrong,&c));
    wrong=good;wrong.replace(0,5,"XAT2.");CHECK(!verify(wrong,&c));CHECK(g_signatureCalls==saved);

    wrong=good;wrong+='=';CHECK(!verify(wrong,&c));
    wrong=good;wrong.resize(wrong.size()-1);CHECK(!verify(wrong,&c));
    const char* from[]={"iat=1000","exp=1120","exp=1120","exp=1120","parent=42","policy=1","ver=3","ver=3","lic=L1"};
    const char* to[]={"iat=1031","exp=1121","exp=1000","exp=999","parent=0","policy=0","ver=1","ver=2","lic=invalid.name"};
    for(unsigned i=0;i<sizeof from/sizeof from[0];i++){wrong=token(replace(claims(),from[i],to[i]));CHECK(!verify(wrong,&c));}
    CHECK(verify(token(replace(claims(),"iat=1000","iat=1030")),&c));
    g_clock=1119;CHECK(verify(good,&c));g_clock=1120;CHECK(!verify(good,&c));g_clock=1000;
    wrong=token(claims()+"extra=1\n");CHECK(!verify(wrong,&c));
    /* Supplied bounds are authoritative: no trailing NUL is required. */
    std::string adjacent=good+"garbage";
    CHECK(extracted_atcs_verify_token(adjacent.data(),good.size(),42,DEVICE,&c));
    CHECK(!verify(adjacent,&c));
    printf("PASS extracted token binding: %u checks (signature/time substitutes)\n",checks);return 0;
}
