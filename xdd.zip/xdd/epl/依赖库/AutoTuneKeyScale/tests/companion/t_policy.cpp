/* Exact production identity/policy helpers; no DLL/DAW or token-signature claim. */
#include "companion_policy.h"
#include <stdlib.h>
#include <string>
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL policy line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static std::string hex(const char* name){char value[257];atcs_hex_encode((const unsigned char*)name,strlen(name),value);return value;}
int main(){
 ATCS_Claims p={};p.policy=1;char name[129];
 CHECK(atcs_policy_basename(L"C:\\插件\\电音11.vst3",name));CHECK(!strcmp(name,"电音11.vst3"));
 CHECK(!atcs_policy_path_denied(&p,0,L"C:\\插件\\电音11.vst3"));
 strcpy(p.plugins,hex("电音11.vst3").c_str());CHECK(atcs_policy_path_denied(&p,0,L"C:\\插件\\电音11.vst3"));
 CHECK(!atcs_policy_path_denied(&p,0,L"C:\\插件\\电音12.vst3"));
 strcpy(p.racks,hex("reaper.exe").c_str());CHECK(atcs_policy_path_denied(&p,1,L"C:\\Reaper\\REAPER.EXE"));CHECK(!atcs_policy_path_denied(&p,1,L"C:\\Reaper\\Sequoia.exe"));
 strcpy(p.plugins,hex("waves").c_str());CHECK(atcs_policy_module_denied(&p,L"D:\\VST3\\WaveShell-VST3.vst3",NULL));CHECK(atcs_policy_module_denied(&p,L"renamed.dll","waves"));CHECK(!atcs_policy_module_denied(&p,L"other.dll",NULL));
 strcpy(p.plugins,hex("tpain").c_str());CHECK(atcs_policy_module_denied(&p,L"The T-Pain Effect.vst3",NULL));CHECK(atcs_policy_module_denied(&p,L"renamed.dll","tpain"));CHECK(!atcs_policy_module_denied(&p,L"WaveShell.vst3","waves"));
 strcpy(p.plugins,hex("antares").c_str());CHECK(atcs_policy_module_denied(&p,L"Auto-Tune Pro.vst3",NULL));CHECK(atcs_policy_module_denied(&p,L"custom.dll","antares"));
 CHECK(!atcs_policy_basename(NULL,name));CHECK(!atcs_policy_basename(L"C:\\folder\\",name));wchar_t loneHigh[]={0xd800,0};wchar_t loneLow[]={0xdc00,0};CHECK(!atcs_policy_basename(loneHigh,name));CHECK(!atcs_policy_basename(loneLow,name));
 std::wstring longName(129,L'x');longName+=L".dll";CHECK(!atcs_policy_basename(longName.c_str(),name));
 CHECK(atcs_policy_path_denied(&p,1,L"reaper.dll"));CHECK(atcs_policy_path_denied(&p,0,L"bad?.dll"));CHECK(atcs_policy_path_denied(&p,0,L"missing_extension"));
 wchar_t pair[]={0xd83d,0xde00,L'.',L'd',L'l',L'l',0};CHECK(atcs_policy_basename(pair,name));CHECK(!memcmp(name,"\xf0\x9f\x98\x80.dll",9));
 /* Case folding changes only ASCII bytes, including when the OS uses GBK. */
 strcpy(p.plugins,hex("电音i.vst3").c_str());CHECK(atcs_policy_path_denied(&p,0,L"电音I.vst3"));
 printf("PASS production policy identity: %u checks\n",checks);
}
