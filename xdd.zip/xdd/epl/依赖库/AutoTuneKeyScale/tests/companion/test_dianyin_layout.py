"""电音助手网页窗口在真实 Chromium 内核里的排版（jsdom 不做排版，量不出位置与截断）。
页面按宿主 主播音效_电音页面 的顺序拼装，文字取自电音助手模块的 19 语种词条，推送格式同 Edge_电音助手_文字JSON／状态JSON。
检查：各元素的位置大小与原 EXUI 窗口（窗口1）的控件坐标一致；19 种语言下状态行、基调行、两个胶囊不被截断，基调行保留连续空格；
基调行字号按语种一次定好、各状态不跳；右键菜单、子菜单与基调修改层落在 420×198 的窗口里、互不重叠，子菜单不盖住父项，基调修改层两个下拉框左右对齐；页面没有脚本错误并报就绪。
需要 Playwright 与 Chrome（找不到时跳过）。用法（在依赖库根目录）：python3 tests/companion/test_dianyin_layout.py [--chrome 路径]
"""
import argparse, atexit, base64, json, os, re, shutil, sys, tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]                     # xhh/
EPL = ROOT / 'epl'
sys.path.insert(0, str(HERE.parent / 'epl_engine'))
import check as syntax                    # noqa: E402

# 原 EXUI 窗口（模块_电音助手 窗口1）各控件按父控件换算到窗口客户区的坐标：左, 顶, 宽, 高
ORIGINAL = {'.dy-bubble': (0, 0, 415, 120), '.dy-song': (139, 24, 245, 56), '.dy-key': (136, 88, 245, 24), '.dy-players': (10, 128, 400, 24),
            '.dy-strength': (6, 156, 408, 32), '.dy-pill-name': (12, 158, 80, 25), '.dy-slider': (104, 159, 248, 26), '.dy-pill-value': (352, 158, 56, 25)}
CHROME_CANDIDATES = ['/opt/google/chrome/chrome', '/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser',
                     r'C:\Program Files\Google\Chrome\Application\chrome.exe', r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe']


def parse_table(source, name):
    out, cur = {}, None
    for line in syntax.section(source, name).split('\n'):
        m = re.match(r"\s*\.(?:判断开始|判断) \(等于 \((?:参_)?语种, (\d+)\)\)\s*'\s*(\S+)", line)
        if m:
            cur = m.group(2)
            continue
        if line.strip().startswith('.默认'):
            cur = 'zh-Hans' if 'zh-Hans' not in out else None
            continue
        if cur and '多项选择' in line:
            out[cur] = [bytes(int(x) for x in a.split(',')).decode('utf-16-le').rstrip('\x00') for a in re.findall(r'\{([0-9, ]+)\}', line)]
            cur = None
    return out


def page_html(lang):
    css_main = (ROOT / 'css/main.css').read_text(encoding='utf-8')
    css_dy = (ROOT / 'css/dianyinAssistant.css').read_text(encoding='utf-8')
    js = [(ROOT / 'js' / n).read_text(encoding='utf-8') for n in ('i18n_data.js', 'i18n.js', 'dianyinAssistant.js')]
    return ('<!DOCTYPE html><html><head><style>:root{forced-color-adjust:none}</style><meta charset=UTF-8><title></title><style></style><style>' + css_main
            + '</style><style>' + css_dy + "</style><script>window.__DY_WIN__=1;window.__XHH_LANG='" + lang + "';</script><script>" + js[0]
            + '</script><script>' + js[1] + '</script><script>' + js[2] + '</script></head><body></body></html>')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--chrome')
    args = ap.parse_args()
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print('跳过：没有安装 Playwright')
        return 0
    chrome = args.chrome or next((c for c in CHROME_CANDIDATES if os.path.exists(c)), None)
    if not chrome:
        print('跳过：找不到 Chrome／Edge')
        return 0
    lang_src = (EPL / '模块/模块_电音助手.e~/代码/程序集_多语言.static.e.txt').read_text(encoding='utf-8-sig').replace('\r\n', '\n')
    texts19, rack19 = parse_table(lang_src, '多语言_文字W_语种'), parse_table(lang_src, '多语言_机架文字W_语种')
    zr = rack19['zh-Hans']
    i_rack, i_auto = zr.index('机架联动'), zr.index('自动切换')
    i_ok = next(i for i, v in enumerate(zr) if v.startswith('插件：已切到'))
    b64 = lambda s: base64.b64encode(s.encode('utf-8')).decode()
    icons = [base64.b64encode(p.read_bytes()).decode() for p in sorted((EPL / '模块/模块_电音助手.e~/资源').glob('列表框_图标_*'))]
    checks, failures = 0, []

    def check(name, ok):
        nonlocal checks
        checks += 1
        if not ok:
            failures.append(name)

    tmp = Path(tempfile.mkdtemp(prefix='dylayout_'))
    atexit.register(shutil.rmtree, tmp, ignore_errors=True)   # 每次约 70MB：不删的话反复回归会占满磁盘
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=chrome, args=['--no-sandbox'])
        for lang, tv in texts19.items():
            rv = rack19[lang]
            ctx = browser.new_context(viewport={'width': 420, 'height': 198})
            ctx.add_init_script('window.__sent=[];window.chrome=window.chrome||{};window.chrome.webview={postMessage:function(m){window.__sent.push(m)}};')
            page = ctx.new_page()
            errors = []
            page.on('pageerror', lambda e: errors.append(str(e)))
            f = tmp / ('p_%s.html' % lang)
            f.write_text(page_html(lang), encoding='utf-8')
            page.goto(f.as_uri())
            page.wait_for_timeout(150)
            key = tv[4] + ('E' if lang == 'zh-Hans' else ' E') + ' ' * 5 + tv[5] + ('' if lang == 'zh-Hans' else ' ') + tv[20]
            texts = {'t': [{'v': b64(v + '\u0000')} for v in tv[:22]], 'rack': b64(rv[i_rack]), 'autoswitch': b64(rv[i_auto]),
                     'keys': [{'v': b64(k)} for k in 'C,C#,D,D#,E,F,F#,G,G#,A,A#,B'.split(',')], 'scales': [{'v': b64(tv[20])}, {'v': b64(tv[21])}],
                     'players': [{'i': i} for i in icons]}
            state = {'song': b64('Ed Sheeran - Shape of You (Official Live at Wembley Stadium)'), 'status': b64(rv[i_ok].rstrip() + ' E'),
                     'key': b64(key), 'sp': 310, 'rk': 2, 'pm': 0, 'pi': 2, 'kc': 5, 'sc': 1}
            page.evaluate('d => { DY.texts(d.texts); DY.state(d.state); window.__lastState = d.state; }', {'texts': texts, 'state': state})
            page.wait_for_timeout(100)
            main_view = page.evaluate('''() => { const r = {}; const box = (s) => { const b = document.querySelector(s).getBoundingClientRect(); return [Math.round(b.left), Math.round(b.top), Math.round(b.width), Math.round(b.height)]; };
                for (const s of %s) r[s] = box(s); const cut = (n) => n.scrollWidth > n.clientWidth + 1; const sd = document.querySelectorAll('.dy-song div');
                r.cut = { status: cut(sd[1]), key: cut(document.querySelector('.dy-key')), pillName: cut(document.querySelector('.dy-pill-name')), pillValue: cut(document.querySelector('.dy-pill-value')) };
                r.spaces = /\\s{5}/.test(document.querySelector('.dy-key').textContent) && /\\S\\s{5}\\S/.test(document.querySelector('.dy-key').innerText); r.sent = window.__sent; return r; }''' % json.dumps(list(ORIGINAL)))
            for sel, want in ORIGINAL.items():
                check(f'{lang}:{sel} 与原窗口一致 {main_view[sel]} != {list(want)}', main_view[sel] == list(want))
            for k, v in main_view['cut'].items():
                check(f'{lang}:{k} 不被截断', not v)
            check(f'{lang}:基调行保留连续空格', main_view['spaces'])
            check(f'{lang}:报就绪', 'XHHDY:ready' in main_view['sent'])
            # 插件按 Chromatic 兜底时的白话提示：状态行用联动文字 23（查询中）／37（查询不到），基调行说原因；19 语种都不被截断、字号不低于原字号 14 的 70%
            for idx, key_idx, tag in ((22, 12, '查询中'), (36, 13, '查询不到')):
                page.evaluate('d => DY.state(d)', dict(state, status=b64(rv[idx]), key=b64(tv[key_idx])))
                page.wait_for_timeout(60)
                fv = page.evaluate('''() => { const sd = document.querySelectorAll('.dy-song div'); const cut = (n) => n.scrollWidth > n.clientWidth + 1;
                    return { status: cut(sd[1]), key: cut(document.querySelector('.dy-key')), size: parseFloat(getComputedStyle(sd[1]).fontSize), text: sd[1].textContent.trim(), keyText: document.querySelector('.dy-key').textContent.trim() }; }''')
                check(f'{lang}:通用修音提示（{tag}）完整显示、字号 {fv["size"]}px', not fv['status'] and not fv['key'] and fv['size'] >= 9.8
                      and fv['text'] == rv[idx].strip() and fv['keyText'] == tv[key_idx].strip())
            # 同意没存进去时的提示（联动文字 31）：要写明到右键菜单的哪一项重新打开哪一项，比原先长；19 语种都不被截断、字号不低于原字号 14 的 70%
            page.evaluate('d => DY.state(d)', dict(state, status=b64(rv[30])))
            page.wait_for_timeout(60)
            cv = page.evaluate('''() => { const sd = document.querySelectorAll('.dy-song div'); const n = sd[1];
                return { cut: n.scrollWidth > n.clientWidth + 1, size: parseFloat(getComputedStyle(n).fontSize), text: n.textContent.trim() }; }''')
            check(f'{lang}:同意提示完整显示、字号 {cv["size"]}px', not cv['cut'] and cv['size'] >= 9.8 and cv['text'] == rv[30].strip())
            # 下载桥组件期间的提示（联动文字 38）：19 语种都不被截断、字号不低于原字号 14 的 70%
            page.evaluate('d => DY.state(d)', dict(state, status=b64(rv[37])))
            page.wait_for_timeout(60)
            dv = page.evaluate('''() => { const n = document.querySelectorAll('.dy-song div')[1];
                return { cut: n.scrollWidth > n.clientWidth + 1, size: parseFloat(getComputedStyle(n).fontSize), text: n.textContent.trim() }; }''')
            check(f'{lang}:下载提示完整显示、字号 {dv["size"]}px', not dv['cut'] and dv['size'] >= 9.8 and dv['text'] == rv[37].strip())
            page.evaluate('d => DY.state(d)', state)
            page.wait_for_timeout(60)
            # 文字位置同原 EXUI 标签的对齐方式：歌名区与基调行 3（横居中、纵居上），「电音强度」0（横居左，x=21），胶囊字号 14
            if lang == 'zh-Hans':
                tb = page.evaluate('''() => { const r = (n) => { const g = document.createRange(); g.selectNodeContents(n); const b = g.getBoundingClientRect(); return [Math.round(b.left), Math.round(b.top), Math.round(b.width)]; };
                    const sd = document.querySelectorAll('.dy-song div');
                    return { song: r(sd[0]), key: r(document.querySelector('.dy-key')), name: r(document.querySelector('.dy-pill-name')), value: r(document.querySelector('.dy-pill-value')),
                             size: getComputedStyle(document.querySelector('.dy-pill-name')).fontSize, vsize: getComputedStyle(document.querySelector('.dy-pill-value')).fontSize }; }''')
                check(f'{lang}:歌名从顶上排（原 纵居上，顶 24） {tb["song"]}', 22 <= tb['song'][1] <= 28)
                check(f'{lang}:基调文字顶在 88 附近（原 纵居上） {tb["key"]}', 86 <= tb['key'][1] <= 92)
                check(f'{lang}:「电音强度」从 x=21 起（原 横居左） {tb["name"]}', 20 <= tb['name'][0] <= 22)
                check(f'{lang}:胶囊字号 14（原 微软雅黑 14） {tb["size"]} {tb["vsize"]}', tb['size'] == '14px' and tb['vsize'] == '14px')
                check(f'{lang}:百分比在胶囊里水平居中（原 横居中） {tb["value"]}', abs(tb['value'][0] + tb['value'][2] / 2 - 380) <= 2)
            # 字体同原 EXUI 窗口（原 多语言_字体候选；简体中文为控件原来的微软雅黑），压过 i18n.js 按语种加的字体
            first = {'ja': 'Yu Gothic UI', 'ko': 'Malgun Gothic', 'zh-Hant': 'Microsoft JhengHei UI', 'th': 'Leelawadee UI', 'vi': 'Segoe UI', 'tr': 'Segoe UI',
                     'ar': 'Segoe UI', 'ru': 'Segoe UI', 'hi': 'Nirmala UI'}.get(lang, 'Microsoft YaHei')
            families = page.evaluate("() => [document.body, document.querySelector('.dy-key'), document.querySelector('.dy-pill-name')].map(n => getComputedStyle(n).fontFamily)")
            check(f'{lang}:字体同原窗口（先用 {first}） {families[0][:40]}', all(f.replace('"', '').startswith(first) for f in families))
            # 基调行字号按本语种一次定好（同原窗口 窗口1_多语言_刷新文字）：正在查询、查询不到、普通与最宽的基调行字号相同，换歌、换显示时不跳
            keys = [k for k in 'C,C#,D,D#,E,F,F#,G,G#,A,A#,B'.split(',')]
            labelled = lambda label, value: label + value if label.endswith('：') else label + ' ' + value
            widest_key = max(keys, key=len)
            lines = [tv[12], tv[13], labelled(tv[4], 'E') + ' ' * 5 + labelled(tv[5], tv[20]), labelled(tv[4], 'A#') + ' ' * 5 + labelled(tv[5], max(tv[20], tv[21], key=len))]
            sizes = []
            for text in lines:
                page.evaluate('k => { DY.state(Object.assign({}, window.__lastState || {}, { key: k })); }', b64(text))
                sizes.append(page.evaluate("() => getComputedStyle(document.querySelector('.dy-key')).fontSize"))
            check(f'{lang}:基调行各状态字号相同 {sizes}', len(set(sizes)) == 1)
            if lang == 'id':
                check(f'{lang}:最宽基调行放不下 14px 时整体缩小 {sizes}', sizes[0] != '14px')
            # 滑块同原窗口（滑块条EX_电音强度：最大位置 400、页改变值 10、滚动改变值 1、容许拖动跟踪开）：点滑槽走 10 格不跳、拖动中每次调整都发、滚轮一格 1 格
            if lang == 'zh-Hans':
                page.evaluate("() => { window.__sent.length = 0; }")
                r = page.evaluate("() => { const b = document.querySelector('.dy-slider').getBoundingClientRect(); return [b.left, b.top, b.width, b.height]; }")
                value = lambda: int(page.evaluate("() => document.querySelector('.dy-slider').value"))
                strengths = lambda: page.evaluate("() => window.__sent.filter(m => m.indexOf('XHHDY:strength:') === 0)")
                v0 = value(); page.mouse.click(r[0] + r[2] - 4, r[1] + r[3] / 2)
                check(f'{lang}:点滑槽右端走 10 格（不跳到点的位置） {v0}→{value()}', value() == v0 + 10 and strengths()[-1:] == ['XHHDY:strength:%d,400' % (v0 + 10)])
                v1 = value(); x = r[0] + 12 + v1 / 400 * (r[2] - 24); y = r[1] + r[3] / 2
                page.evaluate("() => { window.__sent.length = 0; }")
                page.mouse.move(x, y); page.mouse.down()
                for d in range(6, 61, 6): page.mouse.move(x + d, y)
                check(f'{lang}:拖动中（未松手）每次调整都发 {len(strengths())} 条', len(strengths()) >= 5)
                page.mouse.up()
                v2 = value(); page.mouse.move(x, y); page.mouse.wheel(0, -100); page.wait_for_timeout(30)
                check(f'{lang}:滚轮向上一格走 1 格 {v2}→{value()}', value() == v2 + 1)
                page.mouse.click(5, 5)
            page.mouse.click(200, 60, button='right')
            for parent_index, parent_name in ((1, '切换播放器模式'), (2, '机架联动')):
                page.hover('.dy-menu:not(.dy-hidden) .dy-item >> nth=%d' % parent_index)
                menus = page.evaluate('''(k) => { const ms = Array.from(document.querySelectorAll('.dy-menu:not(.dy-hidden)'));
                    const info = ms.map(m => { const b = m.getBoundingClientRect(); return { inside: b.left >= 0 && b.top >= 0 && b.right <= 420.5 && b.bottom <= 198.5,
                        cut: Array.from(m.querySelectorAll('.dy-item')).some(n => n.scrollWidth > n.clientWidth + 1), l: b.left, r: b.right, t: b.top, b: b.bottom }; });
                    const p = ms[0].querySelectorAll('.dy-item')[k].getBoundingClientRect();
                    return { info, parent: { l: p.left, r: p.right, t: p.top, b: p.bottom } }; }''', parent_index)
                check(f'{lang}:{parent_name} 的子菜单打开', len(menus['info']) == 2)
                for i, m in enumerate(menus['info']):
                    check(f'{lang}:{parent_name} 第{i + 1}层菜单在窗口里且不截断', m['inside'] and not m['cut'])
                if len(menus['info']) == 2:
                    sub, par = menus['info'][1], menus['parent']
                    covers = sub['l'] < par['r'] - 1 and par['l'] < sub['r'] - 1 and sub['t'] < par['b'] - 1 and par['t'] < sub['b'] - 1
                    check(f'{lang}:{parent_name} 的子菜单不盖住父项', not covers)
                    if lang == 'zh-Hans' and parent_index == 1:   # 同原窗口：手动／自动子菜单按 50 宽设计，窗口右边放得下时开在父项右边
                        check(f'{lang}:{parent_name} 的子菜单窄（同原窗口 50 宽设计） 宽={round(sub["r"] - sub["l"])}', sub['r'] - sub['l'] <= 80)
                        if 420 - par['r'] >= sub['r'] - sub['l']:   # 右边放得下（原窗口的菜单总开在右边；网页里只能画在窗口里）
                            check(f'{lang}:{parent_name} 的子菜单右边放得下时开在右边', sub['l'] >= par['r'] - 2)
            page.click('.dy-menu:not(.dy-hidden) .dy-item >> nth=0')
            dialog = page.evaluate('''() => { const d = document.querySelector('.dy-dialog'); if (!d || d.classList.contains('dy-hidden')) return null; const db = d.getBoundingClientRect();
                const rs = Array.from(d.querySelectorAll('label, select, button, .dy-songname, span, .dy-dialog-title')).filter(n => n.offsetParent).map(n => { const b = n.getBoundingClientRect(); return { l: b.left, r: b.right, t: b.top, b: b.bottom }; });
                const inside = db.left >= 0 && db.top >= 0 && db.right <= 420.5 && db.bottom <= 198.5 && rs.every(x => x.l >= db.left - 0.5 && x.r <= db.right + 0.5 && x.b <= db.bottom + 0.5);
                let overlap = 0; const has = (a, b) => a.l <= b.l && a.r >= b.r && a.t <= b.t && a.b >= b.b;
                for (let i = 0; i < rs.length; i++) for (let j = i + 1; j < rs.length; j++) { const a = rs[i], b = rs[j]; if (has(a, b) || has(b, a)) continue;
                    if (a.l < b.r - 1 && b.l < a.r - 1 && a.t < b.b - 1 && b.t < a.b - 1) overlap++; }
                const k = d.querySelector('.dy-keyrow select').getBoundingClientRect(), sc = d.querySelector('.dy-scalerow select').getBoundingClientRect();
                return { inside, overlap, aligned: Math.abs(k.left - sc.left) <= 0.5 && Math.abs(k.right - sc.right) <= 0.5 }; }''')
            check(f'{lang}:基调修改层打开', dialog is not None)
            if lang == 'zh-Hans':   # 关闭钮同原窗口 2：EXUI 窗口皮肤的 30×30 图，贴右上角
                close = page.evaluate('''() => { const n = document.querySelector('.dy-dialog-close'); const b = n.getBoundingClientRect(); const s = getComputedStyle(n);
                    return { box: [Math.round(b.left), Math.round(b.top), Math.round(b.width), Math.round(b.height)], img: s.backgroundImage.indexOf('data:image/png') >= 0 }; }''')
                check(f'{lang}:基调修改层关闭钮 30×30 用原皮肤图 {close}', close['box'] == [390, 0, 30, 30] and close['img'])
                song_color = page.evaluate("() => getComputedStyle(document.querySelector('.dy-songname')).color")
                check(f'{lang}:基调修改层歌名纯蓝（原窗口 2 字体色 FF0000FF） {song_color}', song_color == 'rgb(0, 0, 255)')
            if dialog:
                check(f'{lang}:基调修改层在窗口里', dialog['inside'])
                check(f'{lang}:基调修改层各项不重叠', dialog['overlap'] == 0)
                check(f'{lang}:基调与音阶两个下拉框左右对齐（同原窗口两个组合框同一位置）', dialog['aligned'])
            check(f'{lang}:没有脚本错误 {errors[:1]}', not errors)
            ctx.close()
        browser.close()
    print(json.dumps({'checks': checks, 'passed': checks - len(failures), 'failures': failures[:20], 'languages': len(texts19), 'chrome': chrome}, ensure_ascii=False))
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
