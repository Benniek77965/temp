#!/usr/bin/env python3
"""Compile real protocol functions and extract the production transport callback.

No generated source or executable is written into the checkout. Source guards
are safety tripwires, not evidence of Windows/Wine runtime behavior.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
CPP = ROOT / "vst3/cpp/AutoTune_KeyScale_Controller.cpp"
HEADER = CPP.with_name("companion_protocol.h")
SECURITY = CPP.with_name("companion_security.h")
MAILBOX = CPP.with_name("companion_mailbox.h")
POLICY = CPP.with_name("companion_policy.h")
LOADER = CPP.with_name("companion_loader_policy.h")
PIPE = CPP.with_name("companion_pipe.h")
AGENT = ROOT / "combined/at_agent.cpp"


def without_comments(source: str) -> str:
    pattern = r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|/\*[\s\S]*?\*/|//[^\n]*'
    return re.sub(pattern, lambda m: " " if m[0].startswith(("/*", "//")) else m[0], source)


def function(source: str, name: str) -> str:
    """Keep the exact source bytes spanning one named function definition."""
    clean = without_comments(source)
    definition = r"(?m)^[ \t]*(?:[\w:*&]+[ \t]+)+" + re.escape(name) + r"\s*\([^;{}]*\)\s*\{"
    match = re.search(definition, clean)
    if not match:
        raise AssertionError(f"Production function missing: {name}")
    # Comment stripping changes offsets. Find the same function in the original
    # with a lexer retaining whitespace/length, then balance braces outside strings.
    token_pattern = r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|/\*[\s\S]*?\*/|//[^\n]*'
    masked = re.sub(token_pattern, lambda m: " " * len(m[0]), source)
    match = re.search(definition, masked)
    if not match:
        raise AssertionError(f"Production definition ambiguous: {name}")
    start = source.rfind("\n", 0, match.start()) + 1
    opening = masked.index("{", match.start())
    depth = 1
    end = opening + 1
    while depth and end < len(masked):
        depth += (masked[end] == "{") - (masked[end] == "}")
        end += 1
    if depth:
        raise AssertionError(f"Unbalanced production function: {name}")
    return source[start:end]


def braced_body(source: str, marker: str) -> str:
    token_pattern = r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|/\*[\s\S]*?\*/|//[^\n]*'
    masked = re.sub(token_pattern, lambda m: " " * len(m[0]), source)
    start = source.index(marker)
    opening = masked.index("{", start + len(marker))
    depth = 1
    end = opening + 1
    while depth:
        depth += (masked[end] == "{") - (masked[end] == "}")
        end += 1
    return source[opening + 1:end - 1]


def guards(source: str, agent: str) -> list[str]:
    clean = without_comments(source)
    main = without_comments(function(source, "WinMain"))
    body = main[main.index("{") + 1:]
    first_call = re.search(r"\b([A-Za-z_]\w*)\s*\(", body)
    assert first_call and first_call[1] == "atc_startup", "Startup parser must be the first WinMain call"
    stop = re.search(r"if\s*\(\s*g_managed\s*&&\s*intent\s*==\s*0\s*\)\s*return\s+0\s*;", body)
    assert stop, "Managed unrecognized launch must return immediately"
    for api in ("CreateMutexA", "ensure_runtime", "GetVersionExA", "OpenProcess", "CreateWindowA"):
        assert body.index(api) > stop.end(), f"{api} precedes the managed silent exit"
    assert not re.search(r"\b(?:ShowWindow|MessageBox[A-W]?|SetWindowText[A-W]?|InitCommonControlsEx|settings_dialog|EnableWindow)\s*\(", clean), "Controller must remain headless"
    assert 'CreateWindowA("AT8Ctl","",0,0,0,0,0,0,0,hInst,0)' in main, "IPC endpoint must not create visible window styles"
    assert not re.search(r"\bChangeWindowMessageFilter(?:Ex)?\s*\(", clean), "Do not relax UIPI for WM_COPYDATA"
    assert re.search(r"g_managed\s*=\s*AT_XHH_MANAGED", clean), "Managed mode must be a compile-time choice"
    assert re.search(r"#ifndef\s+AT_XHH_MANAGED\s+#define\s+AT_XHH_MANAGED\s+0", clean), "Standalone is the default build"
    assert not re.search(r"\bg_authorized\s*=\s*(?:1|TRUE|true)\b", clean), "No literal authorization bypass"
    marker_source = re.search(r'#define ATC_SPROTECT_BEGIN_1\(\).*?"\.byte ([0-9A-Fa-fx,]+)"', source)
    assert marker_source, "Exact SProtect marker macro is required"
    emitted = bytes(int(value, 16) for value in marker_source[1].split(","))
    marker_dir = ROOT.parents[1] / "模块/SProtect转VMP水印模块.e~/资源"
    assert emitted == (marker_dir / "SP_Begin_1.Image.dat").read_bytes(), "Marker must match the existing EPL resource byte-for-byte"
    assert (marker_dir / "SP_End.Image.dat").read_bytes() == b"", "This source does not invent an end marker for the empty EPL resource"
    protected_functions = ("companion_verify_server_token", "write_ctl_file", "companion_copydata", "scan_thread")
    for name in protected_functions:
        body = without_comments(function(source, name))
        assert len(re.findall(r"ATC_SPROTECT_BEGIN_1\(\);", body)) == 1, f"{name} must carry exactly one marker"
    assert len(re.findall(r"ATC_SPROTECT_BEGIN_1\(\);", clean)) == len(protected_functions), \
        "Protect only the approved set: token verify, command write, message dispatch, scan gate -- nothing else"
    assert not re.search(r"\bcompanion_(?:restore|save)_goal\s*\(", clean), "A replacement controller must wait for a fresh parent APPLY"
    verifier = without_comments(function(source, "companion_verify_server_token"))
    assert verifier.index("atcs_verify_token") < verifier.index("g_compLease=lease") < verifier.index("InterlockedExchange(&g_authorized,1)")
    assert "lease.issued<=g_compLease.issued" in verifier, "Older leases must not replace the current session"
    callback = without_comments(function(source, "companion_copydata"))
    assert callback.index("if(!g_authorized||atcs_now()>=g_compLease.expires)") < callback.index("atc_verify_packet") < callback.index("atc_accept_sequence")
    assert callback.index("atc_accept_sequence") < callback.index("g_compGoal.key=")
    assert "SendMessage" not in callback and "Sleep(" not in callback and "ensure_runtime(" not in callback
    scanner = without_comments(function(source, "scan_thread"))
    assert scanner.index("!g_authorized") < scanner.index("try_enable_debug_priv") < scanner.index("fast_proactive_inject")
    writer = without_comments(function(source, "write_ctl_file"))
    assert writer.index("!g_authorized") < writer.index("CreateFileA")
    assert writer.index("atcs_now()>=lease.expires") < writer.index("atcs_channel_seal") < writer.index("CreateFileA")
    assert re.search(r"if\s*\(!g_managed\)\s*\{\s*ensure_runtime\(\);", main)
    assert re.search(r"if\s*\(!g_managed\)\s*g_scanTh\s*=\s*CreateThread", main)
    parent = without_comments(function(source, "companion_parent_security"))
    assert all(term in parent for term in ("EqualSid", "TokenSessionId", "TokenElevation", "ea.TokenIsElevated&&eb.TokenIsElevated"))
    agent_clean = without_comments(agent)
    worker = without_comments(function(agent, "worker"))
    suspend = without_comments(function(agent, "agent_suspend"))
    resume = without_comments(function(agent, "agent_resume"))
    assert "GetModuleHandleExA(0x1|0x4" in worker, "Worker must PIN its image before installing hooks"
    assert worker.index("GetModuleHandleExA(0x1|0x4") < worker.index("resolve_commdir()")
    assert "if(ejectValid){agent_suspend();" in worker and "agent_resume();" in worker
    assert "FreeLibraryAndExitThread" not in worker[worker.index("resolve_commdir()"):], "Active worker never authorizes physical unmapping"
    assert all(name in suspend for name in ("agent_cancel_posted_writes", "ui_detach", "remove_eat_hooks", "remove_factory_hooks", "remove_init_hooks"))
    assert "remove_handler_hooks" not in suspend, "Read-only lifetime observers remain while pinned and stopped"
    assert "g_ejecting,0" in resume and "g_suspended=0" in resume
    worker = without_comments(function(agent, "worker"))
    assert worker.index("atcs_mailbox_decode") < worker.index("agent_consume_commands(ready,count,last)")
    consumer = without_comments(function(agent, "agent_consume_commands"))
    assert consumer.index("atcs_mailbox_commit") < consumer.index("agent_apply_command(ready[i].plain")
    assert consumer.index("atcs_pause_barrier") < consumer.index("atcs_pause_allows") < consumer.index("agent_apply_command(ready[i].plain")
    assert "atcs_mailbox_retune_allowed(&ready[i],&g_authRetuneSequence)" in consumer
    eject = without_comments(function(agent, "agent_open_command"))
    assert "atcs_channel_open(g_authLease.key,3" in eject and "g_authSequences[3]" in eject
    apply = without_comments(function(agent, "agent_apply_command"))
    assert apply.index("cmd_side_effects(line)") < apply.index("if(!allowRetune)g_fRet=g_fSpeed=-1;") < apply.index("do_set(keySemi,scaleName)")
    assert len(re.findall(r"\bhandler_worker_drain\s*\(", agent_clean)) == 2, "Worker drain has one definition and one base-loop call"
    loop = worker.index("for(;;){")
    drain = worker.index("handler_worker_drain();", loop)
    assert not worker[loop + len("for(;;){"):drain].strip(), "Drain must be first in the worker base loop"
    assert drain < worker.index("agent_poll_authorization();", loop), "Cleanup must precede lease early-continue"
    return ["exact EPL marker in one low-frequency verifier; no invented end marker", "headless controller waits for fresh parent APPLY after replacement", "managed launch exits before OS/file/mutex/window calls", "UIPI is not relaxed",
            "standalone remains the default build", "verified and newer lease precedes authorization installation",
            "MAC precedes replay acceptance and state mutation", "COPYDATA callback has no runtime extraction/wait",
            "scanner and command writer enforce authorization", "commands sealed under unexpired lease before file writes",
            "managed startup does not initialize runtime or scanning", "parent binds user/session/elevation",
            "active agent PINs its image, safely suspends/resumes and never uses zero callbacks to unmap",
            "worker authenticates each channel before commit and gates only stale retune",
            "eject uses independent domain key and replay counter"]


def run(command: list[str], env: dict[str, str] | None = None) -> dict[str, object]:
    result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}): {' '.join(command)}\n{result.stdout}")
    return {"command": command, "returncode": result.returncode, "output": result.stdout.strip()}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cxx", default=os.environ.get("CXX", "g++"))
    parser.add_argument("--log", type=Path, help="Optional JSON report outside the source tree")
    parser.add_argument("--skip-ubsan", action="store_true")
    args = parser.parse_args()
    compiler = shutil.which(args.cxx)
    if not compiler:
        raise SystemExit(f"C++ compiler unavailable: {args.cxx}")
    source = CPP.read_text(encoding="utf-8-sig")
    agent = AGENT.read_text(encoding="utf-8-sig")
    report: dict[str, object] = {"controller_sha256": hashlib.sha256(CPP.read_bytes()).hexdigest(),
                               "protocol_sha256": hashlib.sha256(HEADER.read_bytes()).hexdigest(),
                               "security_sha256": hashlib.sha256(SECURITY.read_bytes()).hexdigest(),
                               "mailbox_sha256": hashlib.sha256(MAILBOX.read_bytes()).hexdigest(),
                               "policy_sha256": hashlib.sha256(POLICY.read_bytes()).hexdigest(),
                               "loader_policy_sha256": hashlib.sha256(LOADER.read_bytes()).hexdigest(),
                               "pipe_sha256": hashlib.sha256(PIPE.read_bytes()).hexdigest(),
                               "ui_routes_sha256": hashlib.sha256((CPP.parent / "companion_ui_routes.h").read_bytes()).hexdigest(),
                               "ui_install_sha256": hashlib.sha256((CPP.parent / "companion_ui_install.h").read_bytes()).hexdigest(),
                               "agent_sha256": hashlib.sha256(AGENT.read_bytes()).hexdigest(),
                               "compiler_version": run([compiler, "--version"])["output"],
                               "source_guards": guards(source, agent), "builds": [], "runs": [],
                               "scope": "production v3 protocol/security/policy headers and source-extracted controller/agent lifecycle; immutable-policy reclamation uses real std::threads with heap/atomic boundaries substituted; token signatures and Win32/registry calls are explicit substitutes; no positive Windows/Wine runtime claim"}
    with tempfile.TemporaryDirectory(prefix="atc-test-") as temporary:
        temp = Path(temporary)
        extracted = "\n\n".join(function(source, name) for name in
                                ("companion_verify_server_token", "companion_clear_goal", "companion_forget_saved_goal", "companion_status_reply", "companion_copydata", "companion_write_pause"))
        marker = source[source.index("#define ATC_SPROTECT_BEGIN_1()"):source.index("static ATC_NOINLINE int companion_verify_server_token")]
        extracted = marker + "\n" + extracted
        main_body = braced_body(source, "int WINAPI WinMain(")
        end_intent = main_body.index("    if(g_managed){")
        extracted += "\nstatic int production_launch_intent(const char* cmdline){" + main_body[:end_intent] + "\nreturn intent;}\n"
        extracted += "\nstatic LRESULT production_start_message(HWND h){" + braced_body(source, "case ATC_START_MESSAGE:") + "}\n"
        extracted += "\nstatic LRESULT production_apply_message(HWND h){" + braced_body(source, "case ATC_APPLY_MESSAGE:") + "}\n"
        (temp / "controller_transport.inc").write_text(extracted + "\n", encoding="utf-8")
        diagnostic_state = source[source.index("struct CompanionMismatch"):source.index("static uint64_t companion_process_birth")]
        (temp / "agent_header_diag.inc").write_text(diagnostic_state + "\n" + "\n\n".join(function(source, name) for name in ("proc_born", "is_injected", "companion_process_birth", "companion_status_owned", "companion_agent_header_mismatch", "companion_mismatch_publish", "companion_mismatch_clear", "companion_mismatch_note", "companion_mismatch_reused", "companion_mismatch_prune", "mark_injected")), encoding="utf-8")
        (temp / "controller_process_policy.inc").write_text(function(source, "companion_policy_process") + "\n", encoding="utf-8")
        (temp / "controller_status.inc").write_text("\n\n".join(function(source, name) for name in ("parse_status_line", "companion_pause_ack", "read_status", "companion_status_reply")), encoding="utf-8")
        (temp / "agent_host_policy.inc").write_text(function(agent, "agent_policy_host") + "\n", encoding="utf-8")
        (temp / "agent_install_policy.inc").write_text(function(agent, "agent_ui_install_allowed") + "\n", encoding="utf-8")
        (temp / "token_verifier.inc").write_text(function(SECURITY.read_text(encoding="utf-8-sig"), "atcs_verify_token") + "\n", encoding="utf-8")
        disc_start = agent.index("typedef struct { void* ctrl; ParamID scaleId")
        disc_end = agent.index("} V3Disc;", disc_start) + len("} V3Disc;")
        discovery = agent[disc_start:disc_end] + "\n" + "\n\n".join(function(agent, name) for name in
                        ("at_lower", "at_stricmp", "u16toascii", "trim", "strstr_ci", "disc_fill", "cmd_line_complete", "parse_num", "clamp01", "agent_apply_command"))
        (temp / "agent_discovery.inc").write_text(discovery, encoding="utf-8")
        lifecycle = "\n\n".join(function(agent, name) for name in ("agent_cancel_posted_writes", "agent_publish_pause", "agent_suspend", "agent_resume"))
        (temp / "agent_lifecycle.inc").write_text(lifecycle, encoding="utf-8")
        (temp / "windows.h").write_text("#define WINAPI\n", encoding="utf-8")
        (temp / "agent_handler_guard_type.inc").write_text(re.search(r"(?m)^struct HandlerGuardMark \{[^}]*\};", agent).group(0) + "\n", encoding="utf-8")
        (temp / "agent_ui_routes.inc").write_text("\n\n".join(function(agent, name) for name in ("ui_target_matches", "at_wndproc", "pick_ui_wnd", "ui_detach", "ui_log_ok", "ui_attach")), encoding="utf-8")
        write_types = agent[agent.index("typedef struct { AEffect* e; uint32_t uid"):agent.index("} V2W;", agent.index("typedef struct { AEffect* e; uint32_t uid")) + len("} V2W;")]
        write_types += "\n" + agent[disc_start:disc_end]
        (temp / "agent_write_gate_types.inc").write_text(write_types + "\n", encoding="utf-8")
        (temp / "agent_write_gate.inc").write_text("\n\n".join(function(agent, name) for name in ("agent_parameter_ready", "agent_write_allowed", "v2set", "v2w_set_checked", "v2w_apply", "do_set_vst2_one", "v3set_body", "v3set", "do_set_vst3_one")), encoding="utf-8")
        unknown_start = agent.index("typedef struct GUnkVtbl")
        unknown_end = agent.index("}GUnk;", unknown_start) + len("}GUnk;")
        handler_types = agent[unknown_start:unknown_end] + "\n" + agent[disc_start:disc_end]
        handler_state = agent[agent.index("static void* g_chCtrl[MAXI]"):agent.index("/* The thread the host was on", agent.index("static void* g_chCtrl[MAXI]"))]
        (temp / "handler_ownership_types.inc").write_text(handler_types + "\n", encoding="utf-8")
        (temp / "handler_ownership_state.inc").write_text(handler_state + "\n", encoding="utf-8")
        (temp / "handler_ownership.inc").write_text("\n\n".join(function(agent, name) for name in ("agent_parameter_ready", "chmap_del", "handler_of", "mySetComponentHandler_inner", "mySetComponentHandler", "v3set_body", "v3set", "do_set_vst3_one")), encoding="utf-8")
        (temp / "agent_drop_running.inc").write_text("\n\n".join(function(agent, name) for name in ("ui_instance_running", "ctrl_refcount", "liveness_decide", "waves_probe_decide", "drop_dead_instances", "agent_cancel_posted_writes", "agent_suspend")), encoding="utf-8")
        (temp / "agent_hook_installers.inc").write_text("\n\n".join(function(agent, name) for name in ("hook_setcomponenthandler", "hook_component_initialize", "patch_create_on_factory")), encoding="utf-8")
        pipe = PIPE.read_text(encoding="utf-8-sig")
        (temp / "pipe_contract.inc").write_text("\n".join(re.search(r"(?m)^#define " + name + r" .+$", pipe).group(0) for name in ("ATCS_PIPE_MAGIC", "ATCS_PIPE_MAX")) + "\n" + function(pipe, "atcs_pipe_name") + "\n", encoding="utf-8")
        (temp / "controller_build.inc").write_text(re.search(r"(?m)^#define AT_BUILD_EXPECT \d+", source).group(0) + "\n", encoding="utf-8")
        (temp / "agent_build.inc").write_text(re.search(r"(?m)^#define AT_BUILD \d+", agent).group(0) + "\n", encoding="utf-8")
        assert "#define ATCS_PIPE_MAX ATCS_MAX_TOKEN" in pipe
        assert "1,8+ATCS_PIPE_MAX,8+ATCS_PIPE_MAX,0,&sa" in pipe
        (temp / "agent_pipe_transport.inc").write_text(function(agent, "agent_publish_pause") + "\n" + function(agent, "agent_poll_authorization") + "\n" + function(pipe, "atcs_pipe_bootstrap"), encoding="utf-8")
        modes = [("optimized", ["-O2"])]
        if not args.skip_ubsan:
            modes.append(("ubsan", ["-O1", "-g", "-fsanitize=undefined", "-fno-sanitize-recover=all"]))
        for mode, flags in modes:
            for test in ("t_protocol", "t_security", "t_token", "t_transport", "t_agent", "t_mailbox", "t_policy", "t_lifecycle", "t_suspend", "t_pipe", "t_hook_stop", "t_process_policy", "t_status_capacity", "t_ui_routes", "t_write_gate", "t_drop_running", "t_agent_header_diag", "t_handler_lifetime"):
                for managed in ((0, 1) if test == "t_write_gate" else (None,)):
                    label = test + (f"-managed{managed}" if managed is not None else "")
                    binary = temp / f"{label}-{mode}"
                    command = [compiler, "-std=c++11", *flags, "-pthread", "-Wall", "-Wextra", "-Wno-misleading-indentation",
                               "-Wno-unused-function", "-Wno-unused-variable", "-I", str(CPP.parent), "-I", str(temp), "-I", str(AGENT.parent),
                               str(HERE / f"{test}.cpp"), "-o", str(binary)]
                    if managed is not None:
                        command.insert(1, "-DAT_XHH_MANAGED=" + str(managed))
                    report["builds"].append({"mode": mode, "test": label, **run(command)})
                    result = run([str(binary)], env={**os.environ, "ATC_TEST_TMP": str(temp), "PYTHONDONTWRITEBYTECODE": "1"})
                    report["runs"].append({"mode": mode, "test": label, **result})
                    print(f"{mode}: {result['output']}")
    print(f"PASS source guards: {len(report['source_guards'])}")
    if args.log:
        args.log.parent.mkdir(parents=True, exist_ok=True)
        args.log.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
