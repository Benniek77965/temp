/* Exact production RUN-slot / capture-reclamation code with a real blocked UI
   thread. Plugin refcounts and OS hooks are explicit substitutes; no DAW run. */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <thread>
#include <mutex>
#include <condition_variable>
#include "vst3_abi.h"
#define LOG(...) ((void)0)
#define AT_XHH_MANAGED 0
#define MAXI 48
#define NDISC 8
#define UIQ 4
#define UIPH_FREE 0
#define UIPH_POST 1
#define UIPH_RUN 2
#define UIPH_DONE 3
#define UIW(g,p) ((LONG)(((g)<<2)|(p)))
#define UIPH(w) ((w)&3)
#define UIGEN(w) ((w)>>2)
typedef int32_t LONG;
typedef struct GUnkVtbl{tresult(WINAPI*queryInterface)(void*,const TUID,void**);uint32_t(WINAPI*addRef)(void*);uint32_t(WINAPI*release)(void*);}GUnkVtbl;
typedef struct GUnk{const GUnkVtbl*vtbl;}GUnk;
struct Fake {const GUnkVtbl* vtbl;unsigned refs,probes;int destroyed;};
static uint32_t WINAPI add(void* p){Fake* f=(Fake*)p;++f->probes;return ++f->refs;}
static uint32_t WINAPI release(void* p){Fake* f=(Fake*)p;unsigned n=--f->refs;if(!n)f->destroyed=1;return n;}
static LONG InterlockedCompareExchange(volatile LONG*p,LONG n,LONG e){__atomic_compare_exchange_n(p,&e,n,false,__ATOMIC_SEQ_CST,__ATOMIC_SEQ_CST);return e;}
static LONG InterlockedExchange(volatile LONG*p,LONG n){return __atomic_exchange_n(p,n,__ATOMIC_SEQ_CST);}
static struct{IEditController*c;volatile LONG word;}g_uiQ[UIQ];
static volatile LONG g_probing=0,g_ejecting=0,g_eatBusy=0;static jmp_buf g_jb;static void warn_nested_guard(const char*){}
static int g_catchCsInit=1,g_catchCs=0;static void EnterCriticalSection(int*p){++*p;}static void LeaveCriticalSection(int*p){--*p;}
struct V3Disc{void*ctrl;int isWaves,discDone,isTuner;};
static void*g_caught[MAXI];static int g_caughtRel[MAXI],g_caughtStrike[MAXI],g_ncaught=0;static int g_nv3=0;static IEditController*g_v3[MAXI];static V3Disc g_disc[NDISC];
static V3Disc*disc_find(IEditController*c){for(int i=0;i<NDISC;i++)if(g_disc[i].ctrl==c)return &g_disc[i];return 0;}
static int waves_known(void*){return 1;}static void*handler_of(void*){return (void*)1;}
static void modmap_del(void*){}static void waves_del(void*){}static void chmap_del(void*){}
static int g_suspended=0,g_hookCsInit=0,g_hookCs=0;static LONG g_llHead=0,g_llTail=0,g_llFlag=0;
static const char*g_statusPath="status",*g_scalesPath="scales",*g_pendPath="pending";
static void ui_detach(){}static void crash_record_remove(){}static void remove_dll_notification(){}static void remove_eat_hooks(){}static void remove_factory_hooks(){}static void remove_init_hooks(){}static int DeleteFileA(const char*){return 1;}static void SwitchToThread(){}
#include "agent_drop_running.inc"
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL RUN capture line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static void capture(Fake* f,int slot,int strike=0){g_caught[slot]=f;g_caughtRel[slot]=1;g_caughtStrike[slot]=strike;g_v3[slot]=(IEditController*)f;g_disc[slot]={f,1,1,1};g_ncaught=slot+1;g_nv3=slot+1;}
static std::mutex mu;static std::condition_variable cv;static bool running=false,finish=false;
int main(){GUnkVtbl vt={NULL,add,release};Fake c={&vt,2,0,0};capture(&c,0);g_uiQ[0].c=(IEditController*)&c;
 std::thread ui([&]{InterlockedExchange(&g_uiQ[0].word,UIW(1,UIPH_RUN));std::unique_lock<std::mutex> l(mu);running=true;cv.notify_all();cv.wait(l,[]{return finish;});InterlockedExchange(&g_uiQ[0].word,UIW(1,UIPH_DONE));});
 {std::unique_lock<std::mutex>l(mu);cv.wait(l,[]{return running;});}
 release(&c);for(int i=0;i<3;i++)drop_dead_instances();CHECK(g_ncaught==1&&c.refs==1&&!c.destroyed);CHECK(c.probes==0&&g_caughtStrike[0]==0&&g_disc[0].ctrl==&c);
 /* The real suspend routine cancels POST but leaves RUN owned by the UI. */
 g_uiQ[1].word=UIW(1,UIPH_POST);agent_suspend();CHECK(g_ejecting&&g_suspended);CHECK(UIPH(g_uiQ[0].word)==UIPH_RUN&&UIPH(g_uiQ[1].word)==UIPH_FREE);drop_dead_instances();CHECK(c.refs==1&&!c.destroyed&&g_ncaught==1);
 Fake other={&vt,1,0,0};capture(&other,1,2);drop_dead_instances();CHECK(other.destroyed&&other.refs==0);CHECK(g_ncaught==1&&g_caught[0]==&c&&c.refs==1&&!c.destroyed);
 {std::lock_guard<std::mutex>l(mu);finish=true;}cv.notify_all();ui.join();CHECK(UIPH(g_uiQ[0].word)==UIPH_DONE);
 drop_dead_instances();CHECK(g_ncaught==1&&c.refs==1);drop_dead_instances();CHECK(g_ncaught==1&&c.refs==1);drop_dead_instances();CHECK(!g_ncaught&&c.refs==0&&c.destroyed);CHECK(g_disc[0].ctrl==NULL);
 Fake posted={&vt,1,0,0};capture(&posted,0,2);g_uiQ[0].c=(IEditController*)&posted;g_uiQ[0].word=UIW(2,UIPH_POST);agent_cancel_posted_writes();drop_dead_instances();CHECK(posted.destroyed&&!g_ncaught&&UIPH(g_uiQ[0].word)==UIPH_FREE);
 CHECK(g_catchCs==0);printf("PASS extracted RUN capture lifetime: %u checks\n",checks);return 0;}
