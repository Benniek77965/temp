// 功能快捷键 HTML 面板（dialogs.js）的「电音助手」分组运行测试（jsdom）：EPL 下发 18 项时第四组显示四个联动快捷键，
// 名称用 EPL 按语种下发的词条，组名与工具箱同一词条；rk=0（服务端策略不开放）时整组隐藏，刷新后可恢复。
// 需要 jsdom；没有时跳过（与 tests/音效包 的界面测试相同）。用法（在依赖库根目录）：node tests/companion/test_funckeys_panel.js
'use strict';
let JSDOM;
try { ({ JSDOM } = require('jsdom')); } catch (e) { console.log('跳过：没有安装 jsdom'); process.exit(0); }
const fs = require('fs'), path = require('path'), assert = require('assert');
const ROOT = path.resolve(__dirname, '..', '..', '..', '..', '..');
const b64 = (s) => Buffer.from(s, 'utf8').toString('base64');
const KEYS = ['stop', 'pause', 'volup', 'voldown', 'loop', 'bgmplay', 'bgmprev', 'bgmnext', 'bgmvolup', 'bgmvoldown',
  'allpause', 'duck', 'hotkeys', 'window', 'rackup', 'rackdown', 'rackzero', 'racklock'];
function table(opts) {
  const titles = opts.titles || {};
  const list = KEYS.map((k) => Object.assign({ k: k, c: 0, m: 0 }, titles[k] ? { t: b64(titles[k]) } : {}));
  list[14].c = 65; list[14].m = 2; list[14].n = b64('Ctrl+A键');
  const o = { list: list, cats: 1, on: 1, step: 10 };
  if (opts.rk != null) o.rk = opts.rk;
  return b64(JSON.stringify(o));
}
function page(lang) {
  const vc = new (require('jsdom').VirtualConsole)();
  const dom = new JSDOM('<!doctype html><html><body></body></html>', { runScripts: 'outside-only', pretendToBeVisual: true, virtualConsole: vc });
  const w = dom.window;
  w.TextEncoder = TextEncoder; w.TextDecoder = TextDecoder; w.scrollTo = () => {}; w.console.log = () => {}; w.console.error = () => {};
  if (lang) w.__XHH_LANG = lang;
  w.eval("window.AppState=window.AppState||{cache:{encodeCache:{get:function(){},set:function(){}}}};");
  const files = ['js/utils.js', 'js/dialogs.js'].concat(lang ? ['js/i18n_data.js', 'js/i18n.js'] : []);
  for (const f of files) w.eval(fs.readFileSync(path.join(ROOT, f), 'utf8'));
  return w;
}
const groups = (d) => Array.from(d.querySelectorAll('.fk-grid > .fk-group'));
const label = (d, k) => d.querySelector('.fk-row[data-fk="' + k + '"] .fk-label').textContent;
let pass = 0;
const ok = (name, fn) => { fn(); pass++; console.info('ok -', name); };

ok('中文：四组、第四组为「电音助手」，名称用 EPL 词条，移调归零带上下文', () => {
  const w = page(), d = w.document;
  w.openFuncKeysDialog(table({ titles: { rackup: '升半音', rackdown: '降半音', rackzero: '移调归零', racklock: '锁定当前调' } }));
  const g = groups(d);
  assert.strictEqual(g.length, 4);
  assert.strictEqual(g[3].querySelector('.fk-group-title').textContent, '电音助手');
  assert.strictEqual(g[3].querySelectorAll('.fk-row').length, 4);
  assert.deepStrictEqual(['rackup', 'rackdown', 'rackzero', 'racklock'].map((k) => label(d, k)), ['升半音', '降半音', '移调归零', '锁定当前调']);
  assert.strictEqual(d.querySelectorAll('.fk-row').length, 18, 'EPL 的 18 项全部可设置');
  assert(d.querySelector('.fk-row[data-fk="rackup"]').classList.contains('fk-has'), '已绑定的联动快捷键显示键帽');
  assert.notStrictEqual(g[3].style.display, 'none');
});
ok('服务端策略不开放（rk=0）：整组隐藏；刷新为 rk=1 后恢复；旧 EPL 不发 rk 时照常显示', () => {
  const w = page(), d = w.document;
  w.openFuncKeysDialog(table({ rk: 0 }));
  assert.strictEqual(groups(d)[3].style.display, 'none');
  w.soundSettings.hotkeys(table({ rk: 1, titles: { rackzero: '移调归零' } }));
  assert.notStrictEqual(groups(d)[3].style.display, 'none');
  assert.strictEqual(label(d, 'rackzero'), '移调归零');
  const w2 = page(), d2 = w2.document;
  w2.openFuncKeysDialog(table({}));
  assert.notStrictEqual(groups(d2)[3].style.display, 'none');
  assert.strictEqual(label(d2, 'racklock'), '锁定当前调', '没有下发词条时用中文兜底');
});
ok('英文：组名取工具箱词条，行名取 EPL 下发的本语种词条，切换后重发词条就地更新', () => {
  const w = page('en'), d = w.document;
  w.openFuncKeysDialog(table({ titles: { rackup: 'Up one semitone', rackzero: 'Transpose · Reset' } }));
  assert.strictEqual(groups(d)[3].querySelector('.fk-group-title').textContent, 'Pitch-correction assistant');
  assert.strictEqual(label(d, 'rackzero'), 'Transpose · Reset');
  w.soundSettings.hotkeys(table({ titles: { rackup: 'Einen Halbton höher', rackzero: 'Transponieren · Zurücksetzen' } }));
  assert.strictEqual(label(d, 'rackup'), 'Einen Halbton höher');
});
console.info('\n' + pass + ' passed');
process.exit(0);   // jsdom 定时器会让进程一直挂着（与 tests/音效包 的界面测试相同做法）
