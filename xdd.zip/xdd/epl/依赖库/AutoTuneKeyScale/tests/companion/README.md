# 托管协议、安全封装与界面回归

在依赖库根目录运行：

```sh
python3 tests/companion/run_tests.py
python3 tests/companion/check_epl_ui.py
python3 tests/companion/test_host_diagnostics.py
node tests/companion/test_funckeys_panel.js
node tests/companion/test_dianyin_page.js
python3 tests/companion/test_dianyin_shape_page.py

`test_dianyin_layout.py`：电音助手页面在真实 Chromium 内核里的排版。按宿主 `主播音效_电音页面` 的顺序拼装页面，文字取自电音助手模块的 19 语种词条，推送格式同宿主；核对各元素位置大小与原 EXUI 窗口控件坐标一致、文字位置同原标签的对齐方式（歌名与基调纵居上、「电音强度」横居左、胶囊 14px）、滑块同原窗口（点滑槽走 10 格不跳、拖动中每次调整都发、滚轮一格 1 格）、字体同原窗口（原 多语言_字体候选，压过 i18n.js 的语种字体），19 种语言下状态行、基调行、胶囊不被截断、基调行保留连续空格、基调行在正在查询／查询不到／普通／最宽各状态字号相同（同原窗口按语种一次定好），右键菜单、子菜单与基调修改层落在 420×198 的窗口里且不重叠，两个子菜单依次打开都不盖住父项（悬停完一个仍能指到另一个），「切换播放器模式」的子菜单同原窗口是窄的、右边放得下时开在右边，基调修改层两个下拉框左右对齐、关闭钮同原窗口 2（30×30 原皮肤图）、歌名纯蓝（原字体色 FF0000FF），没有脚本错误。需要 Playwright 与 Chrome（或 Edge，用 `--chrome` 指定），找不到时跳过：`python3 tests/companion/test_dianyin_layout.py`。
```

`test_dianyin_page.js` 用 jsdom 运行电音助手网页窗口 `js/dianyinAssistant.js`（原 EXUI 窗口）：显示规则、滑块只在引擎给出新强度时移动且拖动中不被拉回、播放器点选、右键菜单的勾选与命令、基调修改提交打开时那首歌、按住气泡拖动。显示内容由 EPL 推来，真实规则见 `tests/epl_engine/test_rack_visibility.py`。`check_epl_ui.py` 现在检查模块的类与多语言文件（窗口文件已删除），并核对主程序已接上网页窗口。

`test_dianyin_shape_page.py`：页面照本工程宿主真实的 `主播音效_电音页面` 拼装（逐项解析那一行：项目 A 带界面语言包与翻译脚本，项目 B 只有简体中文、不带），再像 `Edge_电音助手_取页面` 那样置 `__DY_SHAPE__`。Windows 7 上电音助手窗口按页面形状裁剪。WebView2 在 Windows 7 上不支持透明背景（底色只能不透明，原来整块 420×198 的窗口像贴在桌面上的截图），宿主在页面里置 `__DY_SHAPE__`，页面报出自己画着东西的地方（`shape:宽,高,左,顶,右,底…`，设备像素），宿主用 SetWindowRgn 裁剪窗口。测试在真实 Chromium 里按宿主顺序拼装页面，把页面报的形状交给宿主真实的 `Edge_电音助手_置形状`（用 epl_machine 执行，GDI 区域按布尔图建模）裁成窗口区域，再与页面实际画出来的像素逐个核对：先报形状再报就绪；看得见的像素（不透明度过半）一个也不被裁掉；区域里露出浏览器底色的只在电音强度条（Windows 7 上底色即胶囊色）；气泡是硬边的、一个设备像素对一个图像像素；右键菜单、子菜单、基调修改层（整个窗口）、电音强度显示与隐藏时形状随之变化、收起后复原；简体中文 1、1.25、1.5、1.75、2、2.5、3 倍缩放与 19 种语言；不置 `__DY_SHAPE__` 时（Windows 8 起）同原来。需要 Playwright、numpy、Pillow 与 Chrome（找不到时跳过）。它不等于 Windows 7 上的 WebView2 109 实际渲染与 DWM 合成，须在 Win7 实机验收。

`test_funckeys_panel.js` 用 jsdom 运行主程序 `js/dialogs.js` 的功能快捷键面板：EPL 下发 18 项时第四组“电音助手”显示四个联动快捷键，名称取 EPL 按语种下发的词条，`rk=0` 时整组隐藏。没有 jsdom 时跳过；它不等于 WebView2 实际渲染。

协议套件要求 Python 3.10+、本机 `g++`。可用 `--cxx` 指定编译器，`--log /绝对路径/results.json` 保存源码哈希、命令、结果。默认分别运行优化构建和 UndefinedBehaviorSanitizer 构建；工具链不支持 UBSan 时可加 `--skip-ubsan`，此时不能宣称通过了 UBSan。中间源码和可执行文件均在临时目录生成并自动清理，不污染交付树。

界面静态检查可加 `--baseline-zip /原始项目.zip`，逐项验证原有独立注释行（含禁用控制结构）未丢失；可用 `--log` 留存 JSON 证据。它检查 BOM/CRLF、活动控制结构、单行括号、19×36 条 UTF16LE 文案、无窗口启动、异步编辑、UI 定时器保存、关闭保留引擎、锁定目标显示和滑块实际最大值。它不等同于 EPL 编译或 Windows 界面渲染验收。

## 实际源码覆盖

- `t_protocol.cpp` 直接包含生产 `companion_protocol.h`：RFC 4231 三组 HMAC-SHA256 向量、v3 精确包长/4096 上限/ASCII/v1与v2拒绝/逐字节篡改、回放、启动意图、Key/Scale/Retune 解析、三家族全范围强度映射、24 调 Camelot 与 Chromatic 回读边界。
- `t_security.cpp` 直接包含生产 `companion_security.h`：规范 hex/base64url/整数、XAT3/ver=3/L正整数许可证/规范racks与plugins字段顺序、UTF8名和2048合计上限、独立 Python hashlib/hmac 生成的密文向量、seal/open 往返、逐字节篡改和截断、错误密钥/会话/期限、回放与最大明文长度。
- `t_token.cpp` 按函数边界提取真实 `atcs_verify_token`，仅以受控替身提供验签结果和时钟，验证父 PID、设备、120 秒租约、未来签发容差、到期边界、失败不覆盖输出、规范编码与XAT2拒绝。另验证 Linux 上原生产验签入口拒绝测试令牌。
- `t_transport.cpp` 提取真实 `companion_verify_server_token`、`companion_status_reply`、`companion_copydata`，替换 Win32 调用、token verifier 和时钟。验证未授权门禁、真实授权结果安装/异步启动、runtimeReady前APPLY/FEEL不消费序号、仅完整claims一致的相同续期不重开回放窗口、同签发时间但filters变化拒绝且不更新token/序列、旧租约拒绝、新租约换钥清序列、到期拒绝、MAC/字段/序列验证顺序、APPLY→FEEL 队列不降级、EJECT 优先、状态/feel/errors 的 32 位布局与计数饱和、expect=K:S仅返回匹配当前目标的确认数。另提取真实save/clear/restore、WinMain启动意图前缀、START/APPLY消息分支，执行fresh --show不恢复旧自动目标、仅空目标恢复崩溃前配置、父进程创建时间绑定、EJECT清注册表和内存目标；提取manual_goal验证人工改调清旧确认、未知音阶无效化和人工强度不重放旧自动强度；无自动目标与手工扩展音阶后的重放不访问负音阶下标。
- `t_agent.cpp` 提取真实 `V3Disc`、`disc_fill` 及文本辅助函数，使用实际 `vst3_abi.h` 和受控 VST3 参数枚举器，验证 T-Pain 的 Root note/Scale/Speed 全部排列、模块识别、Waves 门控不退化、未知插件不猜测速度和参数读取失败。提取真实 `agent_apply_command`、数字解析及行完整性函数，验证迟到手感不写参数、迟到 Key/Scale 保留调性而屏蔽旧强度、控制命令仍进入副作用处理；参数写入和 reload 接收端使用替身。由工作线程源码守卫和真实挂起/恢复函数测试验证活动助手不执行物理解映射，已删除退役的卸载判定函数。
- `t_mailbox.cpp` 直接包含生产 `companion_mailbox.h`：四通道域密钥的独立 Python HMAC 向量、四域两两交换密文拒绝、同域回放、逐字节篡改、过期和错误密钥；验证同轮 control101/key102/feel103 验证后排序，跨轮 control101 暂时不可读、key102 先提交仍不丢后续 control；迟到 feel101 不回滚 key102 的强度，迟到 key 保留调性且屏蔽旧强度，控制操作不受强度序列抑制，容量不足时拒绝处理。
- `t_policy.cpp` 直接包含生产 `companion_policy.h`：Unicode实际文件名、ASCII大小写折叠、三家族及重命名插件身份、中文/补充平面字符和无效路径拒绝。
- `t_lifecycle.cpp` 直接包含生产 `companion_loader_policy.h`：堆和原子API为替身，4个真实读线程与20000次策略发布并发，验证旧快照保活、安全回收、分配失败保留旧策略，以及不发布session/key秘密。
- `t_suspend.cpp` 按函数边界提取真实 `agent_cancel_posted_writes` / `agent_suspend` / `agent_resume`：取消已发布未执行写入、停用门禁、保留只读生命周期观察、重新授权恢复与幂等；OS钩子/参数接收端为显式替身。
- `t_pipe.cpp` 联合提取真实 `atcs_pipe_bootstrap` / `agent_poll_authorization`，验证2048/2049/3451/4096字节令牌完整封装到8字节头管道帧，超长/错误帧/对端身份拒绝、同签发时间改策略拒绝；Win32管道和验签边界为替身，可另传已有签名fixture路径验证实际token逐字节传输。
- `t_hook_stop.cpp` 提取三个真实vtable安装函数，在取锁边界模拟worker完成停用，验证持锁后二次检查停止位且不写入新钩子；正常启用时仍安装。调度点是显式替身，不是真实Windows调度。
- 源码护栏验证：托管双击路径在 OS/文件/互斥/窗口操作前返回、UIPI 不放行、独立构建仍为默认、真实租约验证先于安装、通道加密写盘前检查到期、父进程 SID/session/elevation、活动worker先PIN映像、安全停用/恢复且不使用零计数批准物理解映射，以及 worker 实际使用认证解码→通道提交→强度门控的生产调用链和独立 EJECT 域。

## 证据边界

可执行行为测试包含生产头或提取真实源函数/语句，不复制生产算法，也没有往产品加入测试令牌或授权绕过。替身只存在于测试可执行文件。RSA验签本身（自写实现，不依赖任何Windows专属API）在Linux构建下已用真实密钥对和测试向量直接证明；token/callback 测试中的验签成功仅表示替身输入，不代表走了真实签名路径。真实 Win32 消息/UIPI、父进程退出时限、DLL 加载/注入/卸载、真实 VST2/VST3、音频稳定性和界面排版须另由 Windows/Wine 或真实机架测试验收。锁替身只验证进入/退出配对；策略快照测试有真实C++线程并发，但钩子和Windows消息仍是替身。源码顺序护栏不能证明宿主线程调度或极端钩子竞态；PIN映像策略也不等于已经实机验证完整停止/恢复矩阵。

主程诊断回归提取并解释执行真实EPL过程，覆盖ANSI日志保真、原生目录指针/两种临时目录回退、有界尾读和句柄清理；文件与Win32调用为显式替身，不是EPL编译或Windows API运行证明。


第4轮补充：永久runner直接提取handler map／引用账本／writer函数，`t_handler_lifetime`覆盖clear／replace重入、捕获中fault、scope mark、退休回收和UI线程迁移（含同一raw handler重绑）。`ownerTid`仅约束状态1的排队UI事务；状态2仍是原worker兼容路径，不能据此宣称全部VST3调用符合UI线程合同。`t_agent_header_diag`核对严格agent头及多个宿主的版本不匹配生命周期。OS、插件、时钟等替身边界由fixture注明。
