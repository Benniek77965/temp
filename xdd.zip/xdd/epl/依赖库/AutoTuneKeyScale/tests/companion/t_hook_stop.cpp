/* Exact hook installers. EnterCriticalSection models a callback that passed the
   first gate, then acquired its lock after the worker completed safe stop. */
#include "companion_security.h"
#include <stdio.h>
#include <stdlib.h>
typedef int32_t LONG;
#define PAGE_EXECUTE_READWRITE 0x40
#define LOG(...) ((void)0)
#define MAXCH 8
#define MAXIH 8
#define MAXVT 8
static LONG g_ejecting=0;static int g_catchCsInit=1,g_hookCsInit=1,g_catchCs=0,g_hookCs=0;
static unsigned protections=0;static bool stopWhileWaiting=true;
static void EnterCriticalSection(int* cs){++*cs;if(stopWhileWaiting)g_ejecting=1;}
static void LeaveCriticalSection(int* cs){--*cs;}
static int VirtualProtect(void*,size_t,DWORD,DWORD* old){++protections;*old=0x20;return 1;}
typedef int(*tSetCH)();typedef int(*tInit)();typedef int(*tCreate)();
static int mySetComponentHandler(){return 0;}static int myInitialize(){return 0;}static int myCreateInstance(){return 0;}static int original(){return 0;}
static void* g_chVtbl[MAXCH];static tSetCH g_chOrig[MAXCH];static int g_nCH=0;
static void* g_ihVtbl[MAXIH];static tInit g_ihOrig[MAXIH];static int g_nIH=0;
static int g_ihWaves[MAXIH];static char g_ihShell[MAXIH][96],g_ihLeaf[MAXIH][96];
struct IPluginFactoryVtbl{tCreate createInstance;};struct IPluginFactory{IPluginFactoryVtbl* vtbl;};
static void* g_hookedVtbl[MAXVT];static tCreate g_hookedOrig[MAXVT];static int g_nHooked=0,g_hookedAnt[MAXVT];static char g_hookedLeaf[MAXVT][96];static DWORD g_hostAgeAtLoad=0;
#include "agent_hook_installers.inc"
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL hook-stop line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
int main(){
 void* table[32]={};table[16]=(void*)original;table[3]=(void*)original;void** vt=table;void* object=&vt;
 g_ejecting=0;hook_setcomponenthandler(object);CHECK(g_ejecting&&g_nCH==0&&protections==0&&table[16]==(void*)original&&g_catchCs==0);
 g_ejecting=0;hook_component_initialize(object,"test",0,"shell");CHECK(g_ejecting&&g_nIH==0&&protections==0&&table[3]==(void*)original&&g_catchCs==0);
 IPluginFactoryVtbl factoryTable={original};IPluginFactory factory={&factoryTable};
 g_ejecting=0;patch_create_on_factory(&factory,"test","test",0,0);CHECK(g_ejecting&&g_nHooked==0&&protections==0&&factoryTable.createInstance==original&&g_hookCs==0);
 stopWhileWaiting=false;g_ejecting=0;hook_setcomponenthandler(object);CHECK(g_nCH==1&&table[16]==(void*)mySetComponentHandler&&g_catchCs==0);
 hook_component_initialize(object,"test",0,"shell");CHECK(g_nIH==1&&table[3]==(void*)myInitialize&&g_catchCs==0);
 patch_create_on_factory(&factory,"test","test",0,0);CHECK(g_nHooked==1&&factoryTable.createInstance==myCreateInstance&&g_hookCs==0);
 printf("PASS production hook safe-stop installation fence: %u checks (lock scheduling substitute)\n",checks);
}
