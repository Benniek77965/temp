"""机架联动_取桥数据: the bridge is no longer embedded. It is downloaded once through 插件就绪 from the
addresses TCP_主服务端 hands out, and accepted only with a manifest signed by the 服务端_电音基调 key (whose
public half is built into the main program), so a new bridge needs no new main program.
L_RSA验证签名 is checked with the real OpenSSL (PEM_read_bio_RSA_PUBKEY + RSA_verify, as 精易 does) when
RPACK_LIBCRYPTO points at libcrypto 1.1, otherwise with the cryptography package.

Executes the real EPL procedure. The main-server request, 插件就绪, zyJson and the file system are
stand-ins at those boundaries (行为同真实函数：字节集_字节集到十六进制 输出大写十六进制，un_连接 去掉中间的结尾零).
The DLL (about 5 MB) is not read into memory: only the manifest and the signature are read whole; the DLL's size
comes from GetFileSizeEx on a read-only handle that denies writing and deleting, and its SHA-256 from 精易
L_计算文件流哈希 (64 KB at a time) while that handle is held, so what is measured cannot change underneath."""
import base64
import ctypes
import hashlib
import json
import os
import re
import sys
import zipfile

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

import test_host_diagnostics as host

epl = host.epl
BRIDGE = b'MZ' + b'keyscale bridge ' * 4000
TARGET = 'D:\\xddyx\\keyscale_rack_bridge\\keyscale_rack_bridge.dll'
MANIFEST = TARGET[:-len('keyscale_rack_bridge.dll')] + 'keyscale_rack_bridge.manifest'
SIGFILE = TARGET[:-len('keyscale_rack_bridge.dll')] + 'keyscale_rack_bridge.sig'
KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)
OTHER = rsa.generate_private_key(public_exponent=65537, key_size=2048)


def key_constants(public):
    h = public.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo).hex()
    return {'#机架联动_签名公钥': h}


def manifest(version=1, dll=BRIDGE, api=1):
    return f'XHH-RACKLINK-BRIDGE-1\nversion={version}\nsize={len(dll)}\nsha256={hashlib.sha256(dll).hexdigest()}\nhost_api={api}\n'.encode()


def package(dll=BRIDGE, version=1, api=1, key=KEY, text=None, after=None):
    m = text if text is not None else manifest(version, dll, api)
    s = key.sign(m, padding.PKCS1v15(), hashes.SHA256())
    return {TARGET: dll, MANIFEST: after(m) if after else m, SIGFILE: s}


def _openssl():
    path = os.environ.get('RPACK_LIBCRYPTO')
    if not path: return None
    L = ctypes.CDLL(path)
    L.BIO_new_mem_buf.restype = ctypes.c_void_p; L.BIO_new_mem_buf.argtypes = [ctypes.c_char_p, ctypes.c_int]
    L.PEM_read_bio_RSA_PUBKEY.restype = ctypes.c_void_p; L.PEM_read_bio_RSA_PUBKEY.argtypes = [ctypes.c_void_p] * 4
    L.RSA_verify.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_uint, ctypes.c_char_p, ctypes.c_uint, ctypes.c_void_p]
    L.BIO_free.argtypes = [ctypes.c_void_p]; L.RSA_free.argtypes = [ctypes.c_void_p]
    return L


OPENSSL = _openssl()


def rsa_verify(data, signature, pem):
    """精易 L_RSA验证签名: PEM_read_bio_RSA_PUBKEY, then RSA_verify(NID_sha256, SHA-256(data))."""
    if OPENSSL:
        bio = OPENSSL.BIO_new_mem_buf(pem, len(pem)); key = OPENSSL.PEM_read_bio_RSA_PUBKEY(bio, None, None, None); OPENSSL.BIO_free(bio)
        if not key: return False
        digest = hashlib.sha256(data).digest(); ok = OPENSSL.RSA_verify(672, digest, len(digest), signature, len(signature), key); OPENSSL.RSA_free(key)
        return ok == 1
    try:
        serialization.load_pem_public_key(pem).verify(signature, data, padding.PKCS1v15(), hashes.SHA256()); return True
    except Exception:
        return False
GOOD = {'type': '机架联动桥下载信息', 'rack_bridge_soft_md5': '4bf7e15776e7304a84d77a5fdf08e3fe', 'tencent_cloud_rack_bridge_dir_name': 'bridge',
        'tencent_cloud_rack_bridge_file_name': 'keyscale_rack_bridge.zip', 'data': [{'url': 'https://example.invalid/b.zip'}]}


class Env(dict):
    """A call's variables; the host's 程序集变量 live in one shared dict, as in EPL (every procedure of the
    程序集 sees and changes the same ones)."""
    def __init__(self, shared):
        super().__init__(); self.shared = shared
    def __getitem__(self, k): return self.shared[k] if k in self.shared else super().__getitem__(k)
    def __setitem__(self, k, v):
        if k in self.shared: self.shared[k] = v
        else: super().__setitem__(k, v)
    def __contains__(self, k): return k in self.shared or super().__contains__(k)
    def get(self, k, d=None): return self[k] if k in self else d


class Download(host.Fixture):
    def __init__(self, reply, installed=False, install_ok=True, disk=None, min_version=1, registry=None, public=None):
        super().__init__()
        self.min_version, self.registry, self.public, self.key_consts = min_version, dict(registry or {}), public or KEY.public_key(), None
        self.notes = []          # 电音助手.置组件下载中 calls, in order
        self.reply, self.installed, self.install_ok, self.disk = reply, installed, install_ok, dict(disk or {})
        self.logs, self.requests, self.installs, self.built, self.parsed, self.envs = [], [], [], {}, {}, {}
        self.now = 5_000_000
        self.state = {'集_机架取桥下次': 0, '集_机架取桥间隔': 0, '集_机架取桥错误': 0, '集_机架取桥日志': '', '集_机架相符原因': ''}
        self.positions, self.stream_fail, self.fallback_reads = {}, False, []
        self.handles, self.next_handle, self.whole_reads, self.hashed, self.sized = {}, 300, [], [], []

    def run(self, name, *args):          # Fixture.run, keeping the final environment for 参考 parameters
        epl.evaluate = self.eval
        source = epl.section(host.SOURCE, name)
        env = Env(self.state)
        env.update({'集_机架桥入口': 0, '集_机架桥准备错误': 0, '#日志级别_WARNING': 4, '#日志级别_ERROR': 2, '全_配置文件': 'D:\\xddyx\\config.ini',
                    '#机架联动_桥最低版本': self.min_version, '#机架联动_桥接口版本': 1, '#HKEY_CURRENT_USER': -2147483647, '#REG_DWORD': 4, '#L_哈希算法_SHA256': 'SHA256',
                    **(self.key_consts or key_constants(self.public))})
        params = re.findall(r'^\.参数 ([^,]+),', source, re.M)
        for line in re.findall(r'^\.局部变量 (.+)$', source, re.M):
            parts = line.split(','); env[parts[0]] = b'' if parts[1].strip() == '字节集' else ('' if parts[1].strip() == '文本型' else 0)
        env.update(zip(params, args)); self.envs[name] = env
        try: self.execute(source.splitlines(), 0, env)
        except epl.Returned as result: return result.value
        return None                       # a procedure without a return value (e.g. 机架联动_取桥记日志)

    def call_with_refs(self, name, raw, env):
        """A host procedure called from host code, with EPL 参考 semantics: a 参考 parameter given a plain
        variable writes its final value back to that variable (e.g. 机架联动_解析桥清单's outputs)."""
        raws = epl.split_args(raw) if raw.strip() else []
        result = self.run(name, *[self.eval(a, env) if a.strip() else None for a in raws])
        callee = self.envs[name]
        params = re.findall(r'^\.参数 ([^,]+),\s*[^,]*,\s*([^,\n]*)', epl.section(host.SOURCE, name), re.M)
        for (param, flags), arg in zip(params, raws):
            if '参考' in flags and re.fullmatch(r'[\w\u4e00-\u9fff]+', arg.strip()) and arg.strip() in env:
                env[arg.strip()] = callee[param.strip()]
        return result

    def eval(self, text, env):
        m = re.fullmatch(r'([^ ()]+)\s*\((.*)\)', text.strip())
        if m and m.group(1).startswith('机架联动_') and m.group(1) not in BOUNDARY and m.group(1) != '机架联动_系统支持':
            return self.call_with_refs(m.group(1), m.group(2), env)
        if m and m.group(1) == 'GetFileSizeEx_逻辑型':        # writes the size into its 参考 variable
            raws = epl.split_args(m.group(2)); handle = self.eval(raws[0], env)
            if handle not in self.handles: return False
            self.sized.append(handle); env[raws[1].strip()] = len(self.disk[self.handles[handle][0]])
            return True
        if m and m.group(1) == 'ReadFile_整数型':           # reads into the buffer variable named in 取变量数据地址 (…)
            raws = [r.strip() for r in epl.split_args(m.group(2))]; handle = self.eval(raws[0], env)
            if handle not in self.handles: return False
            target = re.fullmatch(r'取变量数据地址 \((.+)\)', raws[1]).group(1).strip(); count = self.eval(raws[2], env)
            path = self.handles[handle][0]; pos = self.positions.get(handle, 0); data = self.disk[path][pos:pos + count]
            self.positions[handle] = pos + len(data); self.fallback_reads.append(count)
            env[target] = data + bytes(env[target])[len(data):]; env[raws[3]] = len(data)
            return True
        if m and m.group(1) in BOUNDARY:
            raws = epl.split_args(m.group(2)) if m.group(2).strip() else []
            return BOUNDARY[m.group(1)](self, [self.eval(a, env) if a.strip() else None for a in raws])
        return super().eval(text, env)

    def open(self, a):
        path = a[0].decode('utf-16le').rstrip('\0')
        if path not in self.disk: return -1
        self.next_handle += 1; self.handles[self.next_handle] = (path, a[1], a[2])   # path, access, share mode
        return self.next_handle

    def stream_hash(self, a):
        """精易 L_计算文件流哈希 (path, start, algorithm, buffer size): opens the file itself and reads it in pieces."""
        path = a[0].decode('utf-16le').rstrip('\0')
        assert a[1] == 0 and a[2] == 'SHA256', a[1:3]
        pinned = [h for h, (p, access, share) in self.handles.items() if p == path and access == -2147483648 and share == 1]
        self.hashed.append((path, bool(pinned)))
        if self.stream_fail: return b''
        return hashlib.sha256(self.disk[path]).digest() if path in self.disk else b''


class Prepare(Download):
    """Runs the real 机架联动_准备桥 / 机架联动_准备失败 / 机架联动_准备记日志; only the fetch (机架联动_取桥数据,
    tested above) and the old-bridge cleanup are stand-ins, so the backoff over every failure path is exercised."""
    def __init__(self, data, error, cleanup_ok=True):
        super().__init__('')
        self.data, self.error, self.cleanup_ok, self.fetches = data, error, cleanup_ok, 0
        self.state.update({'集_机架准备下次': 0, '集_机架准备间隔': 0, '集_机架准备日志': '', '集_机架桥准备错误': 0,
                           '集_机架桥模块': 0, '集_机架桥锁': 0, '集_机架桥入口': 0})

    def eval(self, text, env):
        m = re.fullmatch(r'([^ ()]+)\s*\((.*)\)', text.strip())
        name = m.group(1) if m else ''
        if name == '置入代码': return None
        if name == '机架联动_取桥数据':
            self.fetches += 1
            refs = [a.strip() for a in epl.split_args(m.group(2))]      # the 参考 parameters
            env[refs[0]] = self.error
            if self.data:
                env[refs[1]], env[refs[2]], env[refs[3]] = TARGET.encode('utf-16le') + b'\0\0', len(BRIDGE), hashlib.sha256(BRIDGE).hexdigest()
            return self.data
        if name == '机架联动_清理旧桥': return self.cleanup_ok
        return super().eval(text, env)


def prepare_run(fx):
    return fx.run('机架联动_准备桥')


def install(fx, a):
    fx.installs.append(a)
    return fx.install_ok


BOUNDARY = {
    '局_JSON.创建': lambda fx, a: fx.built.clear() or True,
    '局_JSON.置文本': lambda fx, a: fx.built.__setitem__(a[0], a[1]) or True,
    '局_JSON.到文本': lambda fx, a: json.dumps(fx.built, ensure_ascii=False),
    '局_JSON.解析': lambda fx, a: (lambda d: fx.__dict__.__setitem__('parsed', d or {}) or d is not None)(_load(a[0])),
    '局_JSON.取文本': lambda fx, a: str(fx.parsed.get(a[0], '')),
    '主服务端_同步发送': lambda fx, a: fx.requests.append((json.loads(a[0]), a[1])) or fx.reply,
    '插件就绪_核对': lambda fx, a: fx.installed,
    '插件就绪_安装': install,
    '读入文件字节集W': lambda fx, a: (lambda path: fx.whole_reads.append(path) or fx.disk.get(path, b''))(a[0].decode('utf-16le').rstrip('\0')),
    'CreateFileW': lambda fx, a: fx.open(a),
    'CloseHandle': lambda fx, a: fx.handles.pop(a[0]) and True,
    'L_计算文件流哈希': lambda fx, a: fx.stream_hash(a),
    'L_SHA256': lambda fx, a: hashlib.sha256(bytes(a[0])).digest(),
    '取空白字节集': lambda fx, a: bytes(a[0]),
    '取文本左边': lambda fx, a: a[0][:a[1]],
    '删首尾空': lambda fx, a: a[0].strip(' '),
    '字节集_字节集到十六进制': lambda fx, a: a[0].hex().upper(),
    '到小写': lambda fx, a: a[0].lower(),
    '目录_取父路径': lambda fx, a: 'D:\\xddyx\\',
    '写日志_本地': lambda fx, a: fx.logs.append(a[0]),
    '系统_取启动时间': lambda fx, a: fx.now,
    '电音助手.置组件下载中': lambda fx, a: fx.notes.append(a[0]),
    'L_RSA验证签名': lambda fx, a: rsa_verify(a[0], a[1], a[2]),
    '编码_BASE64编码': lambda fx, a: base64.b64encode(a[0]).decode('ascii'),
    '字节集_十六进制到字节集': lambda fx, a: _unhex(a[0]),
    '系统_取数值注册项': lambda fx, a: fx.registry.get(a[2], 0),
    '系统_写数值注册项': lambda fx, a: fx.registry.__setitem__(a[3], a[4]) or True,
    # EPL text functions used by 机架联动_清单值 / 机架联动_解析桥清单 (1-based positions, -1 when not found)
    '字符': lambda fx, a: chr(a[0]),
    '寻找文本': lambda fx, a: (lambda s, sub, start: (s.find(sub, start - 1) + 1) or -1)(a[0], a[1], a[2] or 1),
    '取文本中间': lambda fx, a: a[0][a[1] - 1:a[1] - 1 + a[2]] if a[2] > 0 else '',
    '取文本长度': lambda fx, a: len(a[0].encode('gbk')),
    '到整数': lambda fx, a: _to_int(a[0]),
    '到字节集': lambda fx, a: a[0] if isinstance(a[0], (bytes, bytearray)) else str(a[0]).encode('gbk'),
    '到文本': lambda fx, a: a[0].split(b'\0', 1)[0].decode('gbk', 'replace') if isinstance(a[0], (bytes, bytearray)) else str(a[0]),
}


def _to_int(value):
    """EPL 到整数 on text: the leading integer (0 if none), wrapped to 32 bits."""
    if isinstance(value, int): return value
    m = re.match(r'\s*([-+]?\d+)', value or '')
    v = int(m.group(1)) if m else 0
    v &= 0xFFFFFFFF
    return v - (1 << 32) if v >= 1 << 31 else v


def _unhex(text):
    try: return bytes.fromhex(text)
    except ValueError: return b''


def _load(text):
    try: return json.loads(text)
    except (TypeError, ValueError): return None


checks, failures = [], []


def check(name, ok):
    checks.append(name)
    if not ok: failures.append(name)


def fetch(fx):
    """(handed over, error); what was handed over (path, signed size, signed SHA-256) is in fx.got."""
    ok = fx.run('机架联动_取桥数据', 0, b'', 0, '')
    env = fx.envs['机架联动_取桥数据']
    fx.got = (env['返回_路径W'].decode('utf-16le').rstrip('\0'), env['返回_大小'], env['返回_摘要']) if ok else None
    assert not fx.handles, ('a handle was left open', fx.handles)
    return bool(ok), env['参_错误']


def handed(fx, dll=BRIDGE):
    return fx.got == (TARGET, len(dll), hashlib.sha256(dll).hexdigest())


def main():
    fx = Download('')
    data, error = fetch(fx)
    check('no answer from the main server: nothing, error 4 (network), nothing downloaded', not data and error == 4 and not fx.installs
          and any('取不到桥组件的下载信息' in l for l in fx.logs))
    check('asks the main server for 机架联动桥下载信息 with a bounded wait', fx.requests == [({'type': '机架联动桥下载信息'}, 15000)])
    fx = Download(json.dumps({'type': '机架联动桥下载信息', 'data': []}))
    data, error = fetch(fx)
    check('server has no bridge configured: nothing, error 2 (not configured)', not data and error == 2 and not fx.installs
          and any('还没配置桥组件的下载地址' in l for l in fx.logs))
    fx = Download(json.dumps(GOOD), installed=False, install_ok=False)
    data, error = fetch(fx)
    check('download or unpack failed: nothing, error 4, retried later by the engine', not data and error == 4 and len(fx.installs) == 1
          and any('没有下载或解压成功' in l for l in fx.logs))
    check('installs through 插件就绪 with the server reply, the configured COS names and MD5, into the config folder',
          fx.installs and fx.installs[0][0] == 'keyscale_rack_bridge' and json.loads(fx.installs[0][1]) == GOOD
          and fx.installs[0][2:5] == ['bridge', 'keyscale_rack_bridge.zip', GOOD['rack_bridge_soft_md5']]
          and fx.installs[0][5].decode('utf-16le').rstrip('\0') == 'D:\\xddyx\\keyscale_rack_bridge')
    fx = Download(json.dumps(GOOD), installed=True, disk=package())
    data, error = fetch(fx)
    check('already installed and signed: its path, signed size and SHA-256 are handed over, nothing downloaded again, nothing written to the registry',
          data and handed(fx) and error == 0 and not fx.installs and not fx.logs and fx.registry == {})
    # While the bridge is really downloaded the link thread is stuck in op1, so the host tells 电音助手 to show
    # “正在下载联动组件” and switches it back afterwards whatever the outcome; nothing when it is already installed.
    fx = Download(json.dumps(GOOD), installed=False, install_ok=True, disk=package()); fetch(fx)
    check('a real download is announced before and cleared after', fx.notes == [True, False])
    fx = Download(json.dumps(GOOD), installed=True, disk=package()); fetch(fx)
    check('nothing is announced when the bridge is already installed', fx.notes == [])
    fx = Download(json.dumps(GOOD), installed=False, install_ok=False); data, error = fetch(fx)
    check('a failed download still clears the notice (error 4)', fx.notes == [True, False] and error == 4)
    # The signed manifest (keyscale_rack_bridge.manifest + .sig) is what a bridge is accepted on.
    def refused(disk, why, **kw):
        fx = Download(json.dumps(GOOD), installed=False, install_ok=True, disk=disk, **kw)
        data, error = fetch(fx)
        return not data and error == 2 and any(why in l for l in fx.logs) and not fx.registry.get('RackLinkBridgeVersion', 0) > kw.get('registry', {}).get('RackLinkBridgeVersion', 0)
    check('a package without a signed manifest (an old package) is refused', refused({TARGET: BRIDGE}, '没有签名'))
    check('a package signed with another key is refused', refused(package(key=OTHER), '签名核对不通过'))
    check('a manifest changed after signing is refused', refused(package(after=lambda m: m.replace(b'version=1', b'version=9')), '签名核对不通过'))
    check('a DLL that is not the one in the signed manifest is refused', refused({**package(), TARGET: BRIDGE[:-1] + b'!'}, '与签名清单不符'))
    check('a DLL of another size than the signed manifest says is refused', refused({**package(), TARGET: BRIDGE + b'x'}, '与签名清单不符'))
    for label, text in (('a leading zero', manifest(1).replace(b'version=1', b'version=01')), ('upper-case hex', manifest(1).replace(hashlib.sha256(BRIDGE).hexdigest().encode(), hashlib.sha256(BRIDGE).hexdigest().upper().encode())),
                        ('an extra line', manifest(1) + b'note=x\n'), ('CRLF line ends', manifest(1).replace(b'\n', b'\r\n'))):
        check('a signed but non-canonical manifest (' + label + ') is refused', refused(package(text=text), '签名清单格式不对'))
    claims = b'ver=3\nsid=' + b'0' * 32 + b'\nlic=L1\ndev=' + b'a' * 64 + b'\nparent=1\niat=1\nexp=2\n'
    transport = b'XHH-RACKLINK-TRANSPORT-3\n' + b'0' * 64 + b'\n' + b'30' * 40 + b'\n'
    check('what the same key signs for tokens and transport keys cannot pass as a bridge manifest',
          refused(package(text=claims), '签名清单格式不对') and refused(package(text=transport), '签名清单格式不对'))
    check('a manifest with valid fields under another first line (e.g. the transport-key prefix) is refused',
          refused(package(text=manifest(1).replace(b'XHH-RACKLINK-BRIDGE-1', b'XHH-RACKLINK-TRANSPORT-3')), '签名清单格式不对')
          and refused(package(text=manifest(1).replace(b'XHH-RACKLINK-BRIDGE-1\n', b'')), '签名清单格式不对'))
    check('a bridge needing another host interface is refused, naming both versions', refused(package(api=2), '要求宿主接口版本 2，本版主程序是 1'))
    check('a bridge older than this main program requires is refused, naming both versions', refused(package(version=2), '是第 2 版，低于本版主程序要求的第 3 版', min_version=3))
    # No per-computer floor any more: what a computer loaded before (RackLinkBridgeVersion, left by older main programs) is neither read nor written
    fx = Download(json.dumps(GOOD), installed=False, install_ok=True, disk=package(version=4), registry={'RackLinkBridgeVersion': 5})
    data, error = fetch(fx)
    check('an older signed bridge than one this computer loaded before is accepted (the version is a label)', data and handed(fx) and error == 0
          and fx.registry == {'RackLinkBridgeVersion': 5})
    fx = Download(json.dumps(GOOD), installed=False, install_ok=True, disk=package(version=6), registry={'RackLinkBridgeVersion': 5})
    data, error = fetch(fx)
    check('a newer signed bridge is accepted without a new main program, and the registry is not touched', data and handed(fx) and error == 0 and fx.registry == {'RackLinkBridgeVersion': 5})
    fx = Download(json.dumps(GOOD), installed=False, install_ok=True, disk=package(version=6), registry={'RackLinkBridgeVersion': 7})
    check('going back below a version loaded before works too', fetch(fx) == (True, 0) and fx.registry == {'RackLinkBridgeVersion': 7})
    check('the host neither reads nor writes a per-computer bridge version', 'RackLinkBridgeVersion' not in re.sub(r"(?m)^\\s*'.*$|  '[^\\n]*", '', host.SOURCE)
          and '机架联动_记下桥版本' not in host.SOURCE and '机架联动_桥要求版本' not in host.SOURCE)
    # End to end: the package bridge_package.py really produced, the real constants of the main program, the
    # real 机架联动_签名公钥PEM and (with RPACK_LIBCRYPTO) the real OpenSSL.
    dist = host.PROJECT / '依赖库/AutoTuneKeyScale/dist/keyscale_rack_bridge.zip'
    consts = (host.PROJECT / '常量.e.txt').read_text(encoding='utf-8-sig')
    real = {'#机架联动_签名公钥': (host.PROJECT / '资源' / '机架联动_签名公钥.txt').read_bytes().decode('ascii')}
    real_min = int(re.search(r'机架联动_桥最低版本, "(\d+)"', consts).group(1))
    with zipfile.ZipFile(dist) as archive:
        files = {TARGET: archive.read('keyscale_rack_bridge.dll'), MANIFEST: archive.read('keyscale_rack_bridge.manifest'), SIGFILE: archive.read('keyscale_rack_bridge.sig')}
    fx = Download(json.dumps(GOOD), installed=True, disk=files, min_version=real_min)
    fx.key_consts = real
    data, error = fetch(fx)
    pem = fx.run('机架联动_签名公钥PEM')
    check('end to end: the real package passes the real main-program check (real constants, real PEM, '
          + ('real OpenSSL' if OPENSSL else 'cryptography') + ')', data and handed(fx, files[TARGET]) and error == 0 and not fx.logs
          and rsa_verify(files[MANIFEST], files[SIGFILE], pem) and pem.startswith(b'-----BEGIN PUBLIC KEY-----\n')
          and all(len(l) <= 64 for l in pem.split(b'\n')))
    fx = Download(json.dumps(GOOD), installed=True, disk=package()); data, error = fetch(fx)
    check('the DLL is never read whole: only the manifest and the signature are', data and sorted(fx.whole_reads) == sorted([MANIFEST, SIGFILE]))
    check('its size is taken on a handle and its SHA-256 streamed while a read-only, write- and delete-denying handle on it is open',
          data and len(fx.sized) == 1 and fx.hashed == [(TARGET, True)])
    once_src = epl.section(host.SOURCE, '机架联动_取桥数据_一次')
    check('no whole-DLL read or in-memory hash is left in the source', 'L_SHA256' not in once_src and 'keyscale_rack_bridge.dll”, ), , , , , , , , , , , , , )))' not in once_src
          and '读入文件字节集W' in once_src and once_src.count('读入文件字节集W') == 2)
    swapped = package()
    fx = Download(json.dumps(GOOD), installed=True, disk=swapped)
    original_open = fx.open
    def open_then_swap(a, fx=fx):        # the DLL is replaced after the readability check, before it is measured
        handle = original_open(a)
        if len(fx.handles) == 1 and not fx.sized: fx.disk[TARGET] = BRIDGE[:-1] + b'?'
        return handle
    fx.open = open_then_swap
    data, error = fetch(fx)
    check('a DLL replaced after the readability check is refused: what is accepted is what was measured', not data and error == 2
          and any('与签名清单不符（SHA-256 不对：文件 ' in l for l in fx.logs))
    fx = Download(json.dumps(GOOD), installed=True, disk=package()); fx.stream_fail = True; data, error = fetch(fx)
    check('when 精易 L_计算文件流哈希 cannot compute, the old whole read on the same handle decides (the bridge still loads)',
          data and handed(fx) and error == 0 and fx.fallback_reads == [len(BRIDGE)] and fx.hashed == [(TARGET, True)])
    fx = Download(json.dumps(GOOD), installed=True, disk={**package(), TARGET: BRIDGE + b'x'}); data, error = fetch(fx)
    check('a size mismatch is logged with both sizes', not data and error == 2
          and any('大小不对：文件 ' + str(len(BRIDGE) + 1) + ' 字节，清单 ' + str(len(BRIDGE)) + ' 字节' in l for l in fx.logs))
    def config_reason(address, account, credential):
        fx = Download(''); fx.state.update({'全_服务端_电音基调_地址': address, '软件账号': account, '软件密钥': credential})
        return fx.run('机架联动_配置失败原因')
    secret = 'k3y-should-never-be-logged'
    reasons = {label: config_reason(*values) for label, values in (('no address', ('', 'u', secret)), ('not http', ('ftp://x', 'u', secret)),
               ('not logged in', ('https://a.example', '', '')), ('all present', ('HTTPS://A.example', 'u', secret)))}
    check('a refused bridge configuration names what is missing, never the credential itself',
          '服务地址为空' in reasons['no address'] and '不是 http(s) 地址（ftp://x）' in reasons['not http']
          and '账号为空' in reasons['not logged in'] and '登录凭据为空' in reasons['not logged in'] and '服务地址为空' not in reasons['not logged in']
          and '没内置服务端公钥' in reasons['all present'] and not any(secret in r for r in reasons.values()))
    fx = Download(json.dumps(GOOD), installed=False, install_ok=True, disk={})
    data, error = fetch(fx)
    check('installed but unreadable (security software removed it): error 5 (the security-software hint), not "not configured"',
          not data and error == 5 and any('多半被安全软件删除或拦截' in l for l in fx.logs) and not any('不配套' in l for l in fx.logs))
    # Backoff: the engine retries 准备组件 every 5 s; without a backoff every client would ask the main
    # server, try every download address twice and write a log line every 5 s.
    fx = Download('')
    gaps, last = [], None
    for _ in range(8):
        before = len(fx.requests); data, error = fetch(fx)
        assert len(fx.requests) == before + 1 and error == 4
        start, nxt = fx.now, fx.state['集_机架取桥下次']; gaps.append((nxt - start) // 1000)
        for dt in (1, (nxt - start) // 2, nxt - start - 1):        # first ms, middle, last ms of the window
            fx.now = start + dt
            data, error = fetch(fx)
            assert not data and error == 4 and len(fx.requests) == before + 1, ('retried inside the backoff window', dt)
        fx.now = nxt
    check('failures back off 30 s, doubling, capped at 10 min; nothing is requested inside the window', gaps == [30, 60, 120, 240, 480, 600, 600, 600])
    check('the same failure is logged once, not on every retry', fx.logs == ['机架联动：取不到桥组件的下载信息（主服务端没有回应：网络不通，或 TCP_主服务端 还是旧版、不认识「机架联动桥下载信息」），稍后自动重试'])
    fx.reply = json.dumps({'type': '机架联动桥下载信息', 'data': []}); fx.now = fx.state['集_机架取桥下次']
    data, error = fetch(fx)
    check('a different reason is logged again, and is what the window reports', error == 2 and len(fx.logs) == 2 and '还没配置' in fx.logs[1]
          and fetch(fx)[1] == 2 and len(fx.requests) == 9)
    fx.reply, fx.installed, fx.disk = json.dumps(GOOD), True, package(); fx.now = fx.state['集_机架取桥下次']
    data, error = fetch(fx)
    check('once the bridge is fetched the backoff and the log memory are cleared', data and handed(fx) and error == 0
          and fx.state == {'集_机架取桥下次': 0, '集_机架取桥间隔': 0, '集_机架取桥错误': 0, '集_机架取桥日志': '', '集_机架相符原因': ''})
    login = epl.section(host.SOURCE, '机架联动_交登录凭据')
    check('a new login clears the backoff so the next need retries at once', '赋值 (集_机架取桥下次, 0)' in login and '赋值 (集_机架取桥间隔, 0)' in login)
    # The two halves live in two projects: what the main program asks for and reads must be exactly what
    # TCP_主服务端 routes and writes, or the client only ever sees "not configured".
    once = epl.section(host.SOURCE, '机架联动_取桥数据_一次')
    asked = re.findall(r'置文本 \(“type”, “([^”]+)”\)', once)
    read = set(re.findall(r'局_JSON\.取文本 \(“([^”]+)”', once))
    server = (host.PROJECT / '服务端/TCP_主服务端/代码/Server_处理函数.static.e.txt').read_text(encoding='utf-8-sig').replace('\r', '')
    route = re.search(r'\.如果真 \(等于 \(type, “' + re.escape(asked[0]) + r'”\)\)\n\s*赋值 \(发送文本, (TCP_\w+) \(', server) if asked else None
    handler = re.search(r'^\.子程序 ' + re.escape(route.group(1)) + r',[^\n]*\n(.*?)(?=^\.子程序 |\Z)', server, re.M | re.S).group(1) if route else ''
    written = set(re.findall(r'JSON\.置文本 \(“([^”]+)”', handler)) | set(re.findall(r'JSON\.置双精度小数 \(“([^”]+)”', handler))
    check('main program and TCP_主服务端 agree on the request type and every key read',
          asked == ['机架联动桥下载信息'] and route is not None and read == {'rack_bridge_soft_md5', 'tencent_cloud_rack_bridge_dir_name', 'tencent_cloud_rack_bridge_file_name'}
          and read <= written and 'JSON.置列表 (“//data”, 存取列表, )' in handler)
    # The preparation itself backs off too: after a successful fetch the local steps (old bridge still held
    # by an old main program, security software blocking the write or the load) can keep failing, and without
    # a backoff every retry (every 5 s) asked the main server again, re-read and re-checked the 5 MB bridge
    # and wrote a log line.
    fx = Prepare(False, 4)
    gaps = []
    for _ in range(7):
        start, before = fx.now, fx.fetches
        ok = prepare_run(fx)
        assert ok is False and fx.fetches == before + 1 and fx.state['集_机架桥准备错误'] == 4
        nxt = fx.state['集_机架准备下次']; gaps.append((nxt - start) // 1000)
        for dt in (1, (nxt - start) // 2, nxt - start - 1):
            fx.now = start + dt
            assert prepare_run(fx) is False and fx.fetches == before + 1, ('prepared again inside the window', dt)
            assert fx.state['集_机架桥准备错误'] == 4, 'the window must keep reporting the real reason'
        fx.now = nxt
    check('a failed preparation backs off 30 s doubling to 10 min; inside the window it neither fetches nor touches files',
          gaps == [30, 60, 120, 240, 480, 600, 600])
    fx = Prepare(True, 0, cleanup_ok=False)
    ok1 = prepare_run(fx); logs1, err1 = list(fx.logs), fx.state['集_机架桥准备错误']
    fx.now += 1000; ok2 = prepare_run(fx)
    fx.now = fx.state['集_机架准备下次']; ok3 = prepare_run(fx)
    check('a local failure after a good fetch backs off too: no main-server request inside the window, error 5',
          (ok1, ok2, ok3) == (False, False, False) and fx.fetches == 2 and err1 == 5 and fx.state['集_机架桥准备错误'] == 5)
    check('the same preparation failure is logged once', logs1 == ['机架联动：旧桥组件仍被占用或无法清理，请完全退出旧主程序后重试'] and fx.logs == logs1)
    body = epl.section(host.SOURCE, '机架联动_准备桥')
    success = body[body.index('赋值 (集_机架桥准备错误, 0)'):body.index('返回 (真)')]
    check('a successful preparation clears the backoff and the log memory',
          all(s in success for s in ('赋值 (集_机架准备下次, 0)', '赋值 (集_机架准备间隔, 0)', '赋值 (集_机架准备日志, “”)')))
    check('a new login clears the preparation backoff as well',
          '赋值 (集_机架准备下次, 0)' in login and '赋值 (集_机架准备间隔, 0)' in login)
    check('every preparation log goes through the dedup helper', '写日志_本地 (' not in body and body.count('机架联动_准备记日志 (') == 4)
    prepare = epl.section(host.SOURCE, '机架联动_准备桥')
    lines = [l.strip() for l in prepare.splitlines()]
    i_fetch = next(i for i, l in enumerate(lines) if l.startswith('赋值 (局_取到, 机架联动_取桥数据 (局_取桥错误, 局_源W, 局_大小, 局_摘要))'))
    i_fail = next(i for i, l in enumerate(lines) if i > i_fetch and l == '机架联动_准备失败 ()')
    i_code = next(i for i, l in enumerate(lines) if i > i_fetch and l == '赋值 (集_机架桥准备错误, 局_取桥错误)')
    check('准备桥 reports the fetch error after 准备失败 (which would otherwise leave 5, the security-software hint)', i_fetch < i_fail < i_code)
    check('the bridge is no longer an EPL resource', '#dll_机架联动桥' not in host.SOURCE and 'ZLIB解压数据' not in prepare)
    print(json.dumps({'status': 'failed' if failures else 'passed', 'checks': len(checks), 'failures': failures}, ensure_ascii=False, indent=2))
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
