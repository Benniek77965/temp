/* All crypto/channel/mailbox functions come from the production header.
   These tests model reads from files; they do not model OS file timing. */
#include "companion_mailbox.h"
#include <stdlib.h>
#include <string>
static unsigned checks=0;
static void check(bool ok,const char* e,int line){++checks;if(!ok){fprintf(stderr,"FAIL mailbox line %d: %s\n",line,e);exit(1);}}
#define CHECK(x) check(!!(x),#x,__LINE__)
static unsigned char root[32];
static const char* SID="0123456789abcdef0123456789abcdef";
static const uint64_t EXPIRY=4102444800ULL;
static std::string seal(unsigned channel,uint64_t sequence,const char* plain,uint64_t expiry=EXPIRY){
    char encoded[4096];CHECK(atcs_channel_seal(root,channel,SID,sequence,expiry,plain,strlen(plain),encoded,sizeof encoded));return encoded;
}
static unsigned decode(std::string (&slots)[3],const uint64_t* committed,ATCS_Mailbox* out,unsigned capacity=3){
    const char* inputs[3];unsigned lengths[3];for(unsigned i=0;i<3;i++){inputs[i]=slots[i].data();lengths[i]=slots[i].size();}
    return atcs_mailbox_decode(root,SID,EXPIRY,committed,inputs,lengths,3,out,capacity);
}
static void test_domains(){
    const char* expected[]={
        "f611db974742cc4d10dfc772c6cac50da9ee76a04dd722c27bd0ee031e7c650b",
        "009ee83fb5abdc37d3a29675300902dca50816ae0e5c2d49d36484a60204fadc",
        "2f652736d447950bd8ea08e74b94aeb0a39f2f99d39dde4a3aec190e47ce12ad",
        "0ebe416fae345625f5c42b4f58ae0475973e89389685054a1899d969704b9550"};
    const char* plain[]={"key=5|scale=Major|retune=0.750|speed=0.250\n","retune=0.500|speed=0.500\n","reload=scalemap\n","eject=1\n"};
    for(unsigned channel=0;channel<4;channel++){
        unsigned char key[32];char hex[65],decoded[1025];
        CHECK(atcs_channel_key(root,channel,key));atcs_hex_encode(key,32,hex);CHECK(!strcmp(hex,expected[channel]));
        std::string encoded=seal(channel,100+channel,plain[channel]);uint64_t last=0;
        CHECK(atcs_channel_open(root,channel,SID,EXPIRY,encoded.data(),encoded.size(),&last,decoded,sizeof decoded));
        CHECK(last==100+channel&&!strcmp(decoded,plain[channel]));
        CHECK(!atcs_channel_open(root,channel,SID,EXPIRY,encoded.data(),encoded.size(),&last,decoded,sizeof decoded));CHECK(last==100+channel);
        for(unsigned other=0;other<4;other++)if(other!=channel){
            last=0;CHECK(!atcs_channel_open(root,other,SID,EXPIRY,encoded.data(),encoded.size(),&last,decoded,sizeof decoded));CHECK(last==0);
        }
        unsigned char wrong[32];memcpy(wrong,root,32);wrong[0]^=1;last=0;
        CHECK(!atcs_channel_open(wrong,channel,SID,EXPIRY,encoded.data(),encoded.size(),&last,decoded,sizeof decoded));CHECK(last==0);
        CHECK(!atcs_channel_open(root,channel,SID,EXPIRY+1,encoded.data(),encoded.size(),&last,decoded,sizeof decoded));
        for(unsigned p=0;p<encoded.size();p++){
            std::string tampered=encoded;tampered[p]^=1;last=0;
            CHECK(!atcs_channel_open(root,channel,SID,EXPIRY,tampered.data(),tampered.size(),&last,decoded,sizeof decoded));CHECK(last==0);
        }
        std::string expired=seal(channel,110+channel,plain[channel],1);last=0;
        CHECK(!atcs_channel_open(root,channel,SID,1,expired.data(),expired.size(),&last,decoded,sizeof decoded));CHECK(last==0);
    }
    unsigned char key[32];char out[1025];uint64_t last=0;
    CHECK(!atcs_channel_key(root,4,key));CHECK(!atcs_channel_key(NULL,0,key));CHECK(!atcs_channel_key(root,0,NULL));
    CHECK(!atcs_channel_seal(root,4,SID,1,EXPIRY,"x\n",2,out,sizeof out));
    CHECK(!atcs_channel_open(root,4,SID,EXPIRY,"",0,&last,out,sizeof out));
}
static void test_snapshot_and_replay(){
    uint64_t committed[3]={0},retune=0;ATCS_Mailbox ready[3];
    std::string slots[3]={seal(0,102,"key=5|scale=Major|retune=0.750|speed=0.250\n"),seal(1,103,"retune=0.500|speed=0.500\n"),seal(2,101,"reload=scalemap\n")};
    CHECK(decode(slots,committed,ready)==3);
    CHECK(committed[0]==0&&committed[1]==0&&committed[2]==0); /* Decode is noncommitting. */
    CHECK(ready[0].sequence==101&&ready[0].slot==2&&strstr(ready[0].plain,"reload="));
    CHECK(ready[1].sequence==102&&ready[1].slot==0&&strstr(ready[1].plain,"key="));
    CHECK(ready[2].sequence==103&&ready[2].slot==1&&strstr(ready[2].plain,"retune="));
    for(unsigned i=0;i<3;i++){CHECK(atcs_mailbox_commit(&ready[i],committed));CHECK(atcs_mailbox_retune_allowed(&ready[i],&retune));}
    CHECK(committed[0]==102&&committed[1]==103&&committed[2]==101&&retune==103);
    for(unsigned i=0;i<3;i++)CHECK(!atcs_mailbox_commit(&ready[i],committed));
    CHECK(decode(slots,committed,ready)==0);
    /* An authenticated command cannot be replayed as feel/control by renaming. */
    uint64_t fresh[3]={0};slots[1]=slots[0];slots[2]=slots[0];CHECK(decode(slots,fresh,ready)==1);
    CHECK(ready[0].slot==0&&ready[0].sequence==102);CHECK(atcs_mailbox_commit(&ready[0],fresh));
    CHECK(!atcs_mailbox_commit(&ready[0],fresh));CHECK(fresh[0]==102&&fresh[1]==0&&fresh[2]==0);
    CHECK(decode(slots,fresh,ready)==0);
    /* Editing the visible unauthenticated sequence never influences ordering. */
    slots[0]=seal(0,104,"key=6|scale=Minor\n");slots[1]=seal(1,105,"retune=0.500\n");slots[2]=seal(2,106,"reload=scalemap\n");
    size_t p=slots[0].find("|seq=104|");CHECK(p!=std::string::npos);slots[0].replace(p+5,3,"999");
    CHECK(decode(slots,fresh,ready)==2);CHECK(ready[0].sequence==105&&ready[0].slot==1&&ready[1].sequence==106&&ready[1].slot==2);
    CHECK(fresh[0]==102&&fresh[1]==0&&fresh[2]==0);
    ATCS_Mailbox untouched[3];memset(untouched,0x55,sizeof untouched);ATCS_Mailbox before[3];memcpy(before,untouched,sizeof before);
    CHECK(decode(slots,fresh,untouched,2)==0);CHECK(!memcmp(untouched,before,sizeof before));
    ATCS_Mailbox invalid;memset(&invalid,0,sizeof invalid);invalid.sequence=999;invalid.slot=3;strcpy(invalid.plain,"x\n");
    CHECK(!atcs_mailbox_commit(&invalid,fresh));invalid.slot=0;strcpy(invalid.plain,"no-newline");CHECK(!atcs_mailbox_commit(&invalid,fresh));
    memset(invalid.plain,'x',sizeof invalid.plain);CHECK(!atcs_mailbox_commit(&invalid,fresh));
}
static void test_delayed_channels(){
    uint64_t committed[3]={0},retune=0;ATCS_Mailbox ready[3];
    /* Round 1: the older control mailbox is unreadable; key 102 still commits. */
    std::string slots[3]={seal(0,102,"key=5|scale=Major|retune=0.750|speed=0.250\n"),"",""};
    CHECK(decode(slots,committed,ready)==1);CHECK(atcs_mailbox_commit(&ready[0],committed));CHECK(atcs_mailbox_retune_allowed(&ready[0],&retune));CHECK(retune==102);
    /* Round 2: control 101 must execute even though key 102 was committed. */
    slots[2]=seal(2,101,"reload=scalemap\n");
    CHECK(decode(slots,committed,ready)==1);CHECK(ready[0].slot==2&&ready[0].sequence==101);
    CHECK(atcs_mailbox_commit(&ready[0],committed));CHECK(atcs_mailbox_retune_allowed(&ready[0],&retune));CHECK(retune==102);
    /* A delayed feel is consumed once but cannot roll back newer key strength. */
    slots[1]=seal(1,101,"retune=0.250|speed=0.750\n");
    CHECK(decode(slots,committed,ready)==1);CHECK(ready[0].slot==1&&ready[0].sequence==101);
    CHECK(atcs_mailbox_commit(&ready[0],committed));CHECK(!atcs_mailbox_retune_allowed(&ready[0],&retune));CHECK(retune==102);
    CHECK(decode(slots,committed,ready)==0);
    slots[1]=seal(1,103,"retune=0.500|speed=0.500\n");
    CHECK(decode(slots,committed,ready)==1);CHECK(atcs_mailbox_commit(&ready[0],committed));CHECK(atcs_mailbox_retune_allowed(&ready[0],&retune));CHECK(retune==103);
    /* Reverse arrival: a late key remains valid, while its stale speed is gated. */
    uint64_t reverse[3]={0};std::string other[3]={"",seal(1,102,"retune=0.750|speed=0.250\n"),""};retune=0;
    CHECK(decode(other,reverse,ready)==1);CHECK(atcs_mailbox_commit(&ready[0],reverse));CHECK(atcs_mailbox_retune_allowed(&ready[0],&retune));
    other[0]=seal(0,101,"key=7|scale=Minor|retune=0.250|speed=0.750\n");
    CHECK(decode(other,reverse,ready)==1);CHECK(ready[0].slot==0&&strstr(ready[0].plain,"key=7|scale=Minor"));
    CHECK(atcs_mailbox_commit(&ready[0],reverse));CHECK(!atcs_mailbox_retune_allowed(&ready[0],&retune));CHECK(retune==102&&reverse[0]==101);
    other[2]=seal(2,100,"reload=scalemap\n");CHECK(decode(other,reverse,ready)==1);CHECK(atcs_mailbox_commit(&ready[0],reverse));CHECK(atcs_mailbox_retune_allowed(&ready[0],&retune));CHECK(retune==102);
    CHECK(decode(other,reverse,ready)==0);
}
int main(){for(unsigned i=0;i<32;i++)root[i]=(unsigned char)i;test_domains();test_snapshot_and_replay();test_delayed_channels();printf("PASS companion channels/mailboxes: %u checks against production header\n",checks);return 0;}
