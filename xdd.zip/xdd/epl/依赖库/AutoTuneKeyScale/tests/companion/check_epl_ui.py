from pathlib import Path
import re,json,zipfile,hashlib
import argparse
parser=argparse.ArgumentParser(description='Static EPL/UI/i18n invariants, not an EPL compiler')
parser.add_argument('--baseline-zip',type=Path)
parser.add_argument('--log',type=Path)
args=parser.parse_args()
package=Path(__file__).resolve().parents[2]
root=package.parent.parent/'模块/模块_电音助手.e~' 
files=['代码/类_电音助手.class.e.txt','代码/程序集_多语言.static.e.txt']  # 原 EXUI 窗口1／窗口2 已删除：界面改由主程序网页窗口承载（js/dianyinAssistant.js）
def active(line):
 out=''; quoted=False
 for c in line:
  if c=='“': quoted=True;out+=' ';continue
  if c=='”': quoted=False;out+=' ';continue
  if not quoted and c=="'":break
  out+=(' ' if quoted else c)
 return out.strip()
stack=[];checks=0
openings={'.如果真':'.如果真结束','.判断开始':'.判断结束','.计次循环首':'.计次循环尾','.判断循环首':'.判断循环尾','.变量循环首':'.变量循环尾','.循环判断首':'.循环判断尾'}
for file in files:
 p=root/file;b=p.read_bytes();assert b.startswith(b'\xef\xbb\xbf'),file
 assert b'\n' not in b.replace(b'\r\n',b''),file
 s=b.decode('utf-8-sig')
 stack=[]
 for num,line in enumerate(s.splitlines(),1):
  q=active(line)
  if not q:continue
  if q.startswith('.子程序 '):assert not stack,(file,num,stack)
  first=q.split(' ')[0]
  if first in openings:stack.append((openings[first],num))
  elif first in openings.values():assert stack and stack.pop()[0]==first,(file,num,q)
  elif first in ('.判断','.默认'):assert stack and stack[-1][0]=='.判断结束',(file,num,q,stack)
  assert q.count('(')==q.count(')'),(file,num,'split/unbalanced line')
  assert q.count('{')==q.count('}'),(file,num,'byte literal boundary')
  checks+=1
 assert not stack,(file,stack)
 # Every originally disabled control/comment line survives exactly.
 if args.baseline_zip:
  with zipfile.ZipFile(args.baseline_zip,metadata_encoding='gbk') as z:
   old=z.read(package.parents[2].name+'/epl/模块/模块_电音助手.e~/'+file).decode('utf-8-sig')  # 包里的顶层目录＝工程目录名（项目 A 是 xhh，项目 B 是 xdd）
   # 删除的子程序（随 EXUI 窗口一起移除的字体、测宽、提示框等）连同其注释一起移除；保留下来的子程序与文件头的注释必须原样保留
   new_lines=s.splitlines();new_procs=set(x.strip() for x in re.findall(r'^\.子程序 ([^,\r\n]+)',s,re.M));proc=None
   for l in old.splitlines():
    m=re.match(r'\.子程序 ([^,\r\n]+)',l)
    if m:proc=m.group(1).strip()
    if l.lstrip().startswith("'") and (proc is None or proc in new_procs): assert l in new_lines,(file,proc,'lost original comment',l)
 print('PASS BOM/CRLF/control structures/single-line preservation:',file)
lang=(root/files[-1]).read_text('utf-8-sig')
a=lang.index('.子程序 多语言_机架文字W_语种,');b=lang.index('.子程序 多语言_机架状态W,',a);table=lang[a:b]
rows=re.findall(r'返回 \(多项选择 \(序号, (.*)\)\)',table)
assert len(rows)==19,len(rows)
decoded=[]
for row in rows:
 cells=re.findall(r'\{([^{}]*)\}',row);assert len(cells)==38,len(cells)   # 38: download notice (state 23)
 words=[]
 for cell in cells:
  raw=bytes(int(n.strip()) for n in cell.split(','));assert raw.endswith(b'\0\0')
  text=raw[:-2].decode('utf-16le');assert text and '\x00' not in text;words.append(text)
 decoded.append(words)
assert len({row[11] for row in decoded})==19,'translated connecting status must be distinct'
assert len({row[26] for row in decoded})==19 and all('Chromatic' not in row[26] for row in decoded),'authorization network failure must have independent localized text'
assert len({row[37] for row in decoded})==19,'download notice must have independent localized text'
assert all(len({row[i] for row in decoded})==19 and all('Chromatic' not in row[i] for row in decoded) for i in (22,36)),'plain-language general-tuning statuses (23 looking up, 37 not found) must be localized without the jargon'
print('PASS 19 x 37 = 703 valid UTF16LE translated UI entries; all 19 connecting statuses distinct')
cl=(root/files[0]).read_text('utf-8-sig')
def sec(text,name):
 i=text.index('.子程序 '+name+',');j=text.find('\n.子程序 ',i+1);return text[i:j if j>0 else len(text)]
ui=''.join(sec(cl,n) for n in re.findall(r'^\.子程序 (界面_[^,\r\n]+)',cl,re.M))
assert ui and '机架引擎_停止' not in ui,'UI entries must not stop the background engine'
assert '基调查询.添加这首歌' not in cl and '基调查询.删除这首歌' not in cl
assert '机架引擎_提交编辑' in ui and '机架引擎_编辑结果' in ui,'key edits stay asynchronous in the engine'
start=cl.index('.子程序 启动后台,');end=cl.index('.子程序 关闭后台,',start)
assert '读取配置 (配置文本)' in cl[start:end] and '多语言_建许可区 ()' in cl[start:end],'account config and i18n lock are set up at background start'
assert not any('InitExui' in active(l) or re.search(r'(?<![\w])载入 \(',active(l)) for l in cl.splitlines()),'no active EXUI / window code left in the class'
assert '.子程序 置后台语言,' in cl
assert '快照.实际音阶' in lang and '快照.实际移调' in lang
for line in cl.splitlines():
 code=active(line)
 assert '切换播放器模式_手动_当前播放器' not in code or '内存配置项' in code,'class must take the locked player-selection snapshot'
 assert not re.search(r'(?<![\w_])切换播放器模式\s*[,)]',code),'class must not access shared selection globals directly'
edge=(package.parent.parent/'代码/集_Edge浏览器/程序集_Edge.static.e.txt').read_text('utf-8-sig')
assert '电音助手.界面_取状态 (' in edge and '.子程序 Edge_电音助手_收到消息,' in edge and '“XHHDY:”' in edge,'main program hosts the assistant page'
assert (package.parent.parent.parent/'js/dianyinAssistant.js').is_file() and (package.parent.parent.parent/'css/dianyinAssistant.css').is_file()
print('PASS UI-less module API, async edits, config at background start, no EXUI code, web window wired in the main program')
report={'scope':'static EPL structural/interface/i18n verification; not an EPL compiler or rendered Windows UI test','checks':checks,'translation_entries':684,'files':{file:hashlib.sha256((root/file).read_bytes()).hexdigest() for file in files}}
if args.log:
 args.log.parent.mkdir(parents=True,exist_ok=True)
 args.log.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
