#!/usr/bin/env python3
"""Execute real EPL fixed-bridge filename, migration and handle guards.

Windows enumeration, sharing, and handle information are explicit test boundaries;
this is not an EPL compiler, Windows filesystem run, or dynamic DLL load test.
"""
from pathlib import Path
import fnmatch
import hashlib
import json
import struct

import test_host_diagnostics as host


def wide(value):
    return value.encode('utf-16le') + b'\0\0'


def find_data(name, attributes=32):
    data=bytearray(592)
    struct.pack_into('<I',data,0,attributes)
    encoded=wide(name)
    assert len(encoded)<=520
    data[44:44+len(encoded)]=encoded
    return bytes(data)


def runtime():
    fixture=host.AuthFixture()
    rt=fixture.runtime
    rt.env['#整数型']=4
    rt.functions.update({
        '取字节集长度':len,
        '取字节集中间':lambda value,start,size:bytes(value[start-1:start-1+size]),
        '取字节集右边':lambda value,count:bytes(value[-count:]) if count else b'',
        '取字节集数据':lambda value,kind,start:int.from_bytes(value[start-1:start-1+kind],'little'),
        'ATU':lambda value,unused:wide(value),
        '删除Unicode结尾空白字节':lambda value,unused:bytes(value[:-2]),
    })
    return rt


class Migration(host.Fixture):
    def __init__(self, files=(), locked=(), payloads=None):
        super().__init__()
        self.entries=[(name,attrs) for name,attrs in files]
        self.locked=set(locked)
        self.attempted=[];self.deleted=[];self.find_closed=[]
        self.position=0;self.last_error=0
        self.first_error=None;self.next_error=18
        self.directory='D:\\项目😀\\plugin\\'
        self.guard=runtime()
        self.payloads={} if payloads is None else dict(payloads)
        self.open_errors={};self.read_failure=False;self.short_read=False;self.reported_size=None;self.metadata_failure=False
        self.handle_attributes={};self.handle_names={};self.open_calls=[];self.next_handle=200
        self.replace_before_disposition={};self.delete_errors={};self.path_delete_calls=[]
        self.providers=set();self.digests={};self.next_crypto=900;self.acquire_fail=False;self.create_fail=False;self.hashed_sizes=[]
        self.guard.functions.update({'GetFileType':lambda handle:1,
                                    'GetFileInformationByHandle_字节集':self.file_information})

    def crypto(self,name,raws,env):
        """advapi32 MD5 (CALG_MD5) by hashlib: providers and hash objects are tracked so every one must be released."""
        ev=lambda r:self.eval(r,env)
        if name=='机架联动_CryptAcquireContextW':
            assert [ev(r) for r in raws[1:]]==[0,0,1,-268435456],'NULL container and provider, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT'
            if self.acquire_fail:return 0
            self.next_crypto+=1;self.providers.add(self.next_crypto);env[raws[0]]=self.next_crypto;return 1
        if name=='CryptCreateHash':
            assert ev(raws[0]) in self.providers and ev(raws[1])==32771
            if self.create_fail:return 0
            self.next_crypto+=1;self.digests[self.next_crypto]=hashlib.md5();env[raws[4]]=self.next_crypto;return 1
        if name=='CryptHashData':
            data,count=ev(raws[1]),ev(raws[2]);assert count<=len(data),'CryptHashData asked to hash more than the bytes just read'
            self.digests[ev(raws[0])].update(bytes(data[:count]));self.hashed_sizes.append(count);return 1
        if name=='CryptGetHashParam':
            assert ev(raws[1])==2 and ev(raws[3])==16 and len(ev(raws[2]))==16
            env[raws[2]]=self.digests[ev(raws[0])].digest();env[raws[3]]=16;return 1
        if name=='CryptDestroyHash':self.digests.pop(ev(raws[0]));return 1
        if name=='CryptReleaseContext':self.providers.remove(ev(raws[0]));return 1
        return bytes(ev(raws[0])).hex().upper()

    def file_information(self,handle,buffer):
        if self.metadata_failure:return False
        struct.pack_into('<I',buffer,0,self.handle_attributes[handle])
        struct.pack_into('<I',buffer,40,1)
        return True

    def eval(self,text,env):
        text=text.strip()
        if not (text.startswith('{') and text.endswith('}')):
            # The common evaluator predates nested byte literals. Keep the
            # original EPL statement; resolve literal operands before parsing.
            parts=host.re.split(r'(“[^”]*”)',text)
            def literal(match):
                key='_bridge_literal_'+str(len(env))
                env[key]=bytes(int(n.strip()) for n in match.group()[1:-1].split(',') if n.strip())
                return key
            for i in range(0,len(parts),2):parts[i]=host.re.sub(r'\{[0-9,\s]*\}',literal,parts[i])
            text=''.join(parts)
        call=host.re.fullmatch(r'([^ ()]+)\s*\((.*)\)',text)
        if not call:return super().eval(text,env)
        name,raw=call.groups()
        if name in ('机架联动_CryptAcquireContextW','CryptCreateHash','CryptHashData','CryptGetHashParam','CryptDestroyHash','CryptReleaseContext','字节集_字节集到十六进制'):
            return self.crypto(name,[r.strip() for r in host.epl.split_args(raw)],env)
        if name=='GetFileSizeEx_逻辑型':
            raws=host.epl.split_args(raw);handle=self.eval(raws[0],env)
            env[raws[1]]=len(self.handles[handle][0]) if self.reported_size is None else self.reported_size
            return True
        if name=='ReadFile_整数型' and self.read_failure:return False
        if name=='ReadFile_整数型' and self.short_read:
            raws=host.epl.split_args(raw);env[raws[3]]=1;return True
        if name not in ('全_运行库.取路径','诊断_FindFirstFileW','诊断_FindNextFileW',
                        '诊断_FindClose','GetLastError','文件_删除W','SetFileInformationByHandle','机架联动_旧桥文件名',
                        '机架联动_桥句柄可用','CreateFileW','到字节集','取数据摘要EX'):
            return super().eval(text,env)
        args=[self.eval(a,env) for a in host.epl.split_args(raw)] if raw.strip() else []
        if name=='全_运行库.取路径':return wide(self.directory)
        if name=='GetLastError':return self.last_error
        if name=='机架联动_旧桥文件名':return self.guard.invoke(name,args[0])
        if name=='机架联动_桥句柄可用':return self.guard.invoke(name,args[0])
        if name=='到字节集':return args[0].encode('cp936')
        if name=='取数据摘要EX':return hashlib.md5(args[0]).hexdigest()
        if name=='CreateFileW':
            path=args[0].decode('utf-16le').rstrip('\0');filename=path[len(self.directory):]
            assert path.startswith(self.directory) and args[1:]==[-2147418112,5,0,3,2097280,0]
            self.open_calls.append(filename)
            if filename in self.locked:
                self.last_error=32;return -1
            if filename in self.open_errors:
                self.last_error=self.open_errors[filename];return -1
            if filename not in self.payloads:self.last_error=2;return -1
            handle=self.next_handle;self.next_handle+=1
            self.handles[handle]=[self.payloads[filename],0]
            self.handle_attributes[handle]=dict(self.entries)[filename]
            self.handle_names[handle]=filename
            return handle
        if name=='诊断_FindFirstFileW':
            _,source,key=args[0];pattern=source[key].decode('utf-16le').rstrip('\0')
            assert pattern==self.directory+'*.dll'
            self.selected=[entry for entry in self.entries if fnmatch.fnmatchcase(entry[0].lower(),'*.dll')]
            if self.first_error is not None or not self.selected:
                self.last_error=2 if self.first_error is None else self.first_error
                return -1
            self.position=0
            _,target,key=args[1];target[key]=find_data(*self.selected[0])
            return 100
        if name=='诊断_FindNextFileW':
            assert args[0]==100
            self.position+=1
            if self.position>=len(self.selected):self.last_error=self.next_error;return 0
            _,target,key=args[1];target[key]=find_data(*self.selected[self.position]);return 1
        if name=='诊断_FindClose':self.find_closed.append(args[0]);return 1
        if name=='文件_删除W':
            self.path_delete_calls.append(args)
            raise AssertionError('path deletion is forbidden after verifying a handle')
        if name=='SetFileInformationByHandle':
            handle,kind,buffer,size=args
            assert handle in self.handles and (kind,buffer,size)==(4,b'\x01',1)
            filename=self.handle_names[handle]
            self.attempted.append(filename)
            # Adversarial boundary: the verified object is renamed while its
            # deny-write/allow-delete handle is open, then foreign bytes occupy
            # its original pathname. A handle disposition must affect only the
            # verified object, never re-resolve that path to the new object.
            if filename in self.replace_before_disposition:
                self.payloads[filename]=self.replace_before_disposition[filename]
            if filename in self.delete_errors:
                self.last_error=self.delete_errors[filename];return False
            if filename not in self.replace_before_disposition:self.payloads.pop(filename,None)
            self.deleted.append(filename)
            return True
        raise AssertionError(name)


def main():
    checks=[]
    def check(name,result):
        assert result,name
        checks.append(name)

    rt=runtime()
    valid=['机架联动内部桥-2ad2380c7ff4.dll','机架联动内部桥-Aa0123456789.dll','机架联动内桥-43568dbf3d90.dll','机架联动内部桥.dll']
    for name in valid:
        check('exact legacy filename accepted:'+name,rt.invoke('机架联动_旧桥文件名',find_data(name))==wide(name))
    bad=['keyscale_rack_bridge.dll','机架联动内部桥.dll.bak','机架联动内部桥.DLL','机架联动内部桥x.dll','机架联动内部桥 .dll','机架联动内桥.dll',
         '机架联动内部桥-123.dll','机架联动内部桥-0123456789abc.dll',
         '机架联动内部桥-0123456789ag.dll','机架联动内部桥-0123456789ab.dll.bak',
         '机架联动内部桥-0123456789ab.DLL','机架联动内部桥-0123456789ａb.dll',
         'other-0123456789ab.dll','机架联动内部桥-../../escape.dll','机架联动内桥-0123456789abc.dll',
         '机架联动内桥-0123456789ab.dll.old','机架联动外部桥-0123456789ab.dll']
    for name in bad:
        check('non-owned filename ignored:'+name,rt.invoke('机架联动_旧桥文件名',find_data(name))==b'')
    for attr in (16,1024,1040):
        check('legacy directory or reparse ignored:'+str(attr),rt.invoke('机架联动_旧桥文件名',find_data(valid[0],attr))==b'')
    for size in (0,44,591,593):
        check('malformed find-data size rejected:'+str(size),rt.invoke('机架联动_旧桥文件名',bytes(size))==b'')

    info={};types={};failed=set()
    def file_info(handle,buffer):
        assert len(buffer)==52
        if handle in failed:return False
        attributes,links=info[handle]
        struct.pack_into('<I',buffer,0,attributes);struct.pack_into('<I',buffer,40,links)
        return True
    rt.functions.update({'GetFileType':lambda handle:types[handle],
                         'GetFileInformationByHandle_字节集':file_info})
    check('invalid handle rejected before API',rt.invoke('机架联动_桥句柄可用',-1) is False)
    for n,(kind,attr,links,expected) in enumerate(((1,32,1,True),(1,0,1,True),(1,16,1,False),
            (1,1024,1,False),(1,1040,1,False),(1,32,0,False),(1,32,2,False),
            (1,32,100,False),(0,32,1,False),(2,32,1,False),(3,32,1,False)),1):
        types[n]=kind;info[n]=(attr,links)
        check('actual handle type attributes links:'+str((kind,attr,links)),rt.invoke('机架联动_桥句柄可用',n)==expected)
    types[99]=1;info[99]=(32,1);failed.add(99)
    check('handle query failure blocks writing',rt.invoke('机架联动_桥句柄可用',99) is False)

    content=b'MZ'+b'\0'*100+b'XRB_Invoke\0'+b'old-bridge'*100
    digest=hashlib.md5(content).hexdigest()[:12]
    own=['机架联动内部桥-'+digest+'.dll','机架联动内桥-'+digest.upper()+'.dll']
    payloads={name:content for name in own}
    m=Migration([(own[0],32),(own[1],32),('thirdparty.dll',32),
                 ('机架联动内部桥-0123456789ag.dll',32),('机架联动内部桥-0123456789ab.dll',1024)],payloads=payloads)
    check('migration deletes only content-verified owned files from both prefixes',m.run('机架联动_清理旧桥') is True and m.deleted==own and m.find_closed==[100] and not m.handles)
    m=Migration();check('no legacy files is success',m.run('机架联动_清理旧桥') is True and not m.deleted and not m.find_closed)
    for error in (3,5,32):
        m=Migration();m.first_error=error
        check('enumeration open failure blocks release:'+str(error),m.run('机架联动_清理旧桥') is False and not m.deleted)
    m=Migration([(own[0],32),(own[1],32)],locked=[own[0]],payloads=payloads)
    check('occupied legacy blocks new release and closes enumeration',m.run('机架联动_清理旧桥') is False and not m.deleted and not m.attempted and m.open_calls==[own[0]] and m.find_closed==[100] and not m.handles)
    m=Migration([(own[0],32)])
    check('concurrent already-deleted legacy before open is harmless',m.run('机架联动_清理旧桥') is True and m.find_closed==[100] and not m.handles)
    m=Migration([(own[0],32)],payloads=payloads);m.next_error=5
    check('enumeration continuation failure is not mistaken for end',m.run('机架联动_清理旧桥') is False and m.find_closed==[100])
    for reason,data,name in [('wrong hash',content,valid[0]),('not PE',b'NO'+content[2:],own[0]),
                             ('no bridge export',content.replace(b'XRB_Invoke',b'OTHER_FUNC'),own[0]),
                             ('too short',b'MZXRB_Invoke',own[0])]:
        m=Migration([(name,32)],payloads={name:data})
        check('foreign legacy-shaped file preserved:'+reason,m.run('机架联动_清理旧桥') is True and not m.attempted and not m.handles)
    # 改英文名之前的固定名「机架联动内部桥.dll」：不带摘要，按内容（MZ 头、XRB_Invoke 标识）核对后迁走；新名 keyscale_rack_bridge.dll 不碰
    fixed='机架联动内部桥.dll'
    m=Migration([(fixed,32),('keyscale_rack_bridge.dll',32),(own[0],32)],payloads={fixed:b'MZ'+b'\0'*100+b'XRB_Invoke\0'+b'fixed-name-bridge'*50,own[0]:content})
    check('pre-rename fixed name migrated after content check, new English name untouched',m.run('机架联动_清理旧桥') is True and m.deleted==[fixed,own[0]] and 'keyscale_rack_bridge.dll' not in m.open_calls and not m.handles and m.find_closed==[100])
    for reason,data in [('not PE',b'NO'+b'\0'*100+b'XRB_Invoke\0'+b'x'*100),('no bridge export',b'MZ'+b'\0'*200),('too short',b'MZXRB_Invoke')]:
        m=Migration([(fixed,32)],payloads={fixed:data})
        check('foreign file with pre-rename fixed name preserved:'+reason,m.run('机架联动_清理旧桥') is True and not m.attempted and not m.handles)
    m=Migration([(fixed,32)],locked=[fixed],payloads={fixed:content})
    check('occupied pre-rename fixed name blocks new release',m.run('机架联动_清理旧桥') is False and not m.deleted and not m.attempted and not m.handles and m.find_closed==[100])
    # 改用 keyscale_ 前缀之前的固定名「xhh_rack_bridge.dll」：同样不带摘要，按内容（MZ 头、XRB_Invoke 标识）核对后迁走；现在的 keyscale_rack_bridge.dll 不碰
    prev='xhh_rack_bridge.dll'
    m=Migration([(prev,32),('keyscale_rack_bridge.dll',32),(fixed,32)],payloads={prev:b'MZ'+b'\0'*100+b'XRB_Invoke\0'+b'prev-name-bridge'*50,fixed:b'MZ'+b'\0'*100+b'XRB_Invoke\0'+b'fixed-name-bridge'*50})
    check('previous fixed name xhh_rack_bridge.dll migrated after content check, current name untouched',m.run('机架联动_清理旧桥') is True and m.deleted==[prev,fixed] and 'keyscale_rack_bridge.dll' not in m.open_calls and not m.handles and m.find_closed==[100])
    for reason,data in [('not PE',b'NO'+b'\0'*100+b'XRB_Invoke\0'+b'x'*100),('no bridge export',b'MZ'+b'\0'*200),('too short',b'MZXRB_Invoke')]:
        m=Migration([(prev,32)],payloads={prev:data})
        check('foreign file named xhh_rack_bridge.dll preserved:'+reason,m.run('机架联动_清理旧桥') is True and not m.attempted and not m.handles)
    # 大文件分块读（每次 64KB）：标识跨在两块之间也认得；名字带摘要的边读边算 MD5；从不按文件大小分配或一次读完
    big=b'MZ'+b'\0'*(65536-2-4)+b'XRB_Invoke'+b'big-old-bridge'*15000          # XRB_ in the first piece, Invoke in the second
    big_digest=hashlib.md5(big).hexdigest()[:12]
    big_own='机架联动内部桥-'+big_digest+'.dll'
    m=Migration([(big_own,32),(fixed,32)],payloads={big_own:big,fixed:big})
    check('large legacy files read 64 KB at a time: marker across two pieces found, MD5 summed piece by piece',
          m.run('机架联动_清理旧桥') is True and m.deleted==[big_own,fixed] and not m.handles
          and m.read_sizes and set(m.read_sizes)=={65536} and sum(m.hashed_sizes)==len(big) and max(m.hashed_sizes)<=65536)
    check('every CryptoAPI context released and every hash destroyed',not m.providers and not m.digests)
    m=Migration([('机架联动内部桥-'+'0'*12+'.dll',32)],payloads={'机架联动内部桥-'+'0'*12+'.dll':big})
    check('large legacy file with another digest preserved',m.run('机架联动_清理旧桥') is True and not m.attempted and not m.handles and not m.providers and not m.digests)
    for label,data in (('marker split but no MZ',b'NO'+big[2:]),('marker cut in half',big.replace(b'XRB_Invoke',b'XRB_Inv0ke'))):
        m=Migration([(fixed,32)],payloads={fixed:data})
        check('large foreign file preserved:'+label,m.run('机架联动_清理旧桥') is True and not m.attempted and not m.handles)
    # CryptoAPI unavailable: the old whole-file check (取数据摘要EX) on the same handle, so the result is what it was before
    for failure in ('acquire_fail','create_fail'):
        for name,expect_deleted in ((big_own,True),('机架联动内部桥-'+'0'*12+'.dll',False)):
            m=Migration([(name,32)],payloads={name:big});setattr(m,failure,True)
            ok=m.run('机架联动_清理旧桥')
            check('no CryptoAPI ('+failure+'): the old whole-file check decides, '+('own file migrated' if expect_deleted else 'foreign digest preserved'),
                  ok is True and (m.deleted==[name] if expect_deleted else not m.attempted) and m.read_sizes==[len(big)]
                  and not m.hashed_sizes and not m.handles and not m.providers and not m.digests)
    m=Migration([(fixed,32)],payloads={fixed:big});m.reported_size=len(big)-100
    check('a file longer than measured is not trusted: nothing deleted',m.run('机架联动_清理旧桥') is False and not m.attempted and not m.handles)
    longer='xhh_rack_bridge.dll.bak'
    m=Migration([(longer,32)],payloads={longer:b'MZ'+b'\0'*100+b'XRB_Invoke\0'+b'x'*100})
    check('name merely starting with the previous fixed name untouched',m.run('机架联动_清理旧桥') is True and not m.attempted and not m.handles)
    # 组件只在宿主回调 op1（引擎真正要用时才发）里准备：别的操作在桥没载入时直接返回，不写任何文件
    source=host.SOURCE.replace('\r\n','\n')
    callback=source[source.index('.子程序 机架联动_宿主回调,'):]
    callback=callback[:callback.index('\n.子程序 ',10)] if '\n.子程序 ' in callback[10:] else callback
    lines=[l.strip() for l in callback.split('\n')]
    prep=[i for i,l in enumerate(lines) if '机架联动_准备桥 (' in l]
    op1=next(i for i,l in enumerate(lines) if l.startswith('.如果真 (等于 (参_操作, 1))'))
    nxt=next((i for i,l in enumerate(lines) if i>op1 and l.startswith('.如果真 (等于 (参_操作, ')),len(lines))
    check('bridge prepared only in the op1 branch',len(prep)==1 and op1<prep[0]<nxt and source.count('机架联动_准备桥 (')==1)
    m=Migration([(own[0],32)],payloads=payloads);m.reported_size=67108865
    check('oversized candidate ignored without allocation or read',m.run('机架联动_清理旧桥') is True and not m.read_sizes and not m.attempted and not m.handles)
    for mode in ('read_failure','short_read','metadata_failure'):
        m=Migration([(own[0],32)],payloads=payloads);setattr(m,mode,True)
        check('uncertain ownership read blocks migration:'+mode,m.run('机架联动_清理旧桥') is False and not m.attempted and not m.handles)
    for code,expected in ((2,True),(5,False),(32,False)):
        m=Migration([(own[0],32)],payloads=payloads);m.open_errors[own[0]]=code
        check('candidate open failure classified:'+str(code),m.run('机架联动_清理旧桥')==expected and not m.attempted and not m.handles)

    m=Migration([(own[0],32)],payloads=payloads)
    replacement=b'third-party replacement must survive'
    m.replace_before_disposition[own[0]]=replacement
    check('rename plus path replacement deletes verified object only',m.run('机架联动_清理旧桥') is True and m.deleted==[own[0]] and m.payloads[own[0]]==replacement and not m.path_delete_calls and not m.handles and m.find_closed==[100])
    for code in (2,5,32):
        m=Migration([(own[0],32)],payloads=payloads);m.delete_errors[own[0]]=code
        check('handle disposition failure blocks migration:'+str(code),m.run('机架联动_清理旧桥') is False and m.attempted==[own[0]] and not m.deleted and not m.path_delete_calls and not m.handles and m.find_closed==[100])

    prepare=host.epl.section(host.SOURCE,'机架联动_准备桥')
    verify=host.epl.section(host.SOURCE,'机架联动_核对桥文件')
    measure=host.epl.section(host.SOURCE,'机架联动_桥文件相符')
    copy=host.epl.section(host.SOURCE,'机架联动_复制桥文件')
    check('legacy migration precedes fixed path open',prepare.index('机架联动_清理旧桥')<prepare.index('ATU (“keyscale_rack_bridge.dll”')<prepare.index('CreateFileW'))
    check('fixed name never contains digest', '取数据摘要EX' not in prepare and '机架联动内部桥-' not in prepare)
    check('release uses the English fixed name only', 'ATU (“keyscale_rack_bridge.dll”' in prepare and 'ATU (“机架联动内部桥.dll”' not in prepare)
    check('write uses nontruncating exclusive open without following reparse', 'CreateFileW (局_路径W, -1073741824, 0, 0, 4, 2097280, 0)' in prepare)
    check('actual write handle checked before data write and truncate',prepare.index('机架联动_桥句柄可用 (局_句柄)')<prepare.index('机架联动_复制桥文件 (局_源W, 局_句柄, 局_大小)')<prepare.index('SetEndOfFile')
          and 'WriteFile_整数型' not in prepare and copy.count('WriteFile_整数型 (参_目标,')==1)
    check('write count checked before truncate: every piece, and the total against the signed size',
          copy.index('WriteFile_整数型')<copy.index('.如果真 (不等于 (局_写入, 局_读取))') and '返回 (并且 (局_成功, 等于 (局_总数, 参_大小)))' in copy
          and copy.index('.如果真 (大于 (局_读取, 相减 (参_大小, 局_总数)))')<copy.index('WriteFile_整数型'))
    check('the bridge is copied in pieces, never read whole',"取空白字节集 (65536)" in copy and 'ReadFile_整数型 (局_源, 取变量数据地址 (局_缓冲), 65536,' in copy
          and '读入文件字节集' not in copy+prepare and 'CreateFileW (参_源W, -2147483648, 1, 0, 3, 128, 0)' in copy)
    check('readonly pin refuses writes deletes and reparse opens',prepare.count('CreateFileW (局_路径W, -2147483648, 1, 0, 3, 2097280, 0)')==2)
    check('readonly handle verified before measuring it',verify.index('机架联动_桥句柄可用')<verify.index('机架联动_桥文件相符 (参_句柄, 参_路径W, 参_大小, 参_摘要)')
          and measure.index('GetFileSizeEx_逻辑型 (参_句柄,')<measure.index('L_计算文件流哈希 (参_路径W, 0, #L_哈希算法_SHA256, )'))
    check('loaded file checked against the signed size and SHA-256 while the pin is retained',prepare.index('机架联动_核对桥文件 (集_机架桥锁, 局_路径W, 局_大小, 局_摘要)')<prepare.index('LoadLibraryExW_字节集'))
    callback=host.epl.section(host.SOURCE,'机架联动_宿主回调')
    configure=callback[callback.index('赋值 (局_结果, 机架联动_调用桥 (1,'):]
    check('a refused bridge configuration is logged once, through the dedup helper',
          configure.index('.如果真 (等于 (局_结果, 0))')<configure.index('机架联动_准备记日志 (相加 (“机架联动：桥组件拒绝配置')<configure.index('.如果真 (不等于 (局_结果, 0))'))
    reason=host.epl.section(host.SOURCE,'机架联动_配置失败原因')
    check('the configuration reason only says whether the credential is empty',reason.count('软件密钥')==1 and '等于 (软件密钥, “”)' in reason)
    legacy=host.epl.section(host.SOURCE,'机架联动_锁定旧桥')
    content_check=host.epl.section(host.SOURCE,'机架联动_核对旧桥内容')
    check('legacy file never read whole nor hashed through another open of its path',
          '取空白字节集 (65536)' in content_check and '取空白字节集 (到整数 (局_大小))' not in legacy+content_check
          and 'ReadFile_整数型 (参_句柄, 取变量数据地址 (局_缓冲), 65536,' in content_check and 'CreateFileW' not in content_check
          and legacy.count('CreateFileW')==1 and 'L_计算文件流哈希' not in legacy+content_check and '取数据摘要EX' not in legacy+content_check)
    fallback_calls=[i for i,l in enumerate(content_check.splitlines()) if '机架联动_核对旧桥内容_整读 (' in l]
    lines=content_check.splitlines()
    check('the whole-file fallback is reached only when CryptoAPI is unavailable',len(fallback_calls)==2
          and '机架联动_CryptAcquireContextW (局_提供者, 0, 0, 1, -268435456)' in lines[fallback_calls[0]-1]
          and 'CryptCreateHash (局_提供者, 32771, 0, 0, 局_哈希)' in lines[fallback_calls[1]-2])
    check('legacy bytes are never loaded as code','LoadLibrary' not in legacy and 'CreateFileW (参_路径W, -2147418112, 5, 0, 3, 2097280, 0)' in legacy)
    cleanup=host.epl.section(host.SOURCE,'机架联动_清理旧桥')
    check('deletion addresses verified handle and never pathname','SetFileInformationByHandle (局_旧锁, 4, {1}, 1)' in cleanup and '文件_删除W' not in cleanup)
    print(json.dumps({'status':'passed','checks':len(checks),'passed':checks,
                      'source_sha256':hashlib.sha256((host.PROJECT/'代码/集_基础支持/机架联动_宿主.static.e.txt').read_bytes()).hexdigest(),
                      'scope':__doc__},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
