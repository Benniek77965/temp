/* Exact production bootstrap + agent receive functions, with Win32 pipe/token
   boundaries substituted. Verifies frame sizes and byte identity, not ACLs. */
#include "companion_security.h"
#include "companion_mailbox.h"
#include <wchar.h>
#include <vector>
#include <string>
#include <fstream>
#include <iterator>
#include <stdio.h>
#include <stdlib.h>
typedef int BOOL;typedef int32_t LONG;typedef void* HANDLE;
#define TRUE 1
#define FALSE 0
#define INVALID_HANDLE_VALUE ((HANDLE)(intptr_t)-1)
#define GENERIC_READ 1
#define GENERIC_WRITE 2
#define OPEN_EXISTING 3
#define FILE_FLAG_OVERLAPPED 4
#define PIPE_READMODE_MESSAGE 2
#define ERROR_PIPE_CONNECTED 535
#define ERROR_NO_DATA 232
#define LOG(...) ((void)0)
#include "controller_build.inc"
#include "agent_build.inc"
#include "pipe_contract.inc"
static const DWORD current_pipe_magic=ATCS_PIPE_MAGIC;
static const DWORD legacy_pipe_magic=0x32424b58UL;
static HANDLE g_authPipe=(HANDLE)1;
static ATCS_Claims g_authLease,g_fixtureLease;
static int g_authInstalled=0,g_suspended=0,g_csInit=0;
static uint64_t g_authResumeAfter=0,g_authSequences[4]={},g_authRetuneSequence=0;
static char g_authDevice[65]="";
static volatile LONG g_parameterPaused=1,g_parameterEpoch=1;static ATCS_PauseBarrier g_pauseBarrier={0,1};
static LONG InterlockedCompareExchange(volatile LONG*p,LONG n,LONG e){LONG v=*p;if(v==e)*p=n;return v;}static LONG InterlockedExchange(volatile LONG*p,LONG n){LONG v=*p;*p=n;return v;}static LONG InterlockedIncrement(volatile LONG*p){return ++*p;}
static unsigned queueCancels=0;static void agent_cancel_posted_writes(){++queueCancels;}
static std::string g_expected;
static std::vector<unsigned char> g_wire;
static DWORD g_reply=0;
static unsigned g_verifications=0,g_submissions=0,g_disconnects=0;
static int g_peerAllowed=1,g_verifyAllowed=1,g_legacyReceiver=0,g_allowNameAlias=0;
static std::wstring g_serverName;
static void atcs_loader_collect(){}
static int atcs_loader_publish(const ATCS_Claims*){return 1;}
static unsigned g_startedBuild=0;
static HANDLE atcs_pipe_server(){return (HANDLE)1;} /* frozen 1164 receiver signature */
static HANDLE atcs_pipe_server(unsigned build){g_startedBuild=build;wchar_t name[128];atcs_pipe_name(77,build,name,128);g_serverName=name;return (HANDLE)1;}
static BOOL ConnectNamedPipe(HANDLE,void*){return TRUE;}
static DWORD GetLastError(){return 0;}
static BOOL PeekNamedPipe(HANDLE,void*,DWORD,void*,DWORD* available,void*){*available=(DWORD)g_wire.size();return TRUE;}
static BOOL ReadFile(HANDLE,void* out,DWORD capacity,DWORD* got,void*){*got=(DWORD)(g_wire.size()<capacity?g_wire.size():capacity);memcpy(out,g_wire.data(),*got);return g_wire.size()<=capacity;}
static BOOL WriteFile(HANDLE,const void* data,DWORD n,DWORD* wrote,void*){if(n!=4)return FALSE;memcpy(&g_reply,data,4);*wrote=4;return TRUE;}
static BOOL DisconnectNamedPipe(HANDLE){++g_disconnects;return TRUE;}
static int atcs_pipe_peer(HANDLE,int server,DWORD expected,DWORD* out){if(out)*out=7;return g_peerAllowed&&(server||expected==77);}
static int atcs_same_user_elevated(DWORD){return 1;}
static DWORD atcs_creator(DWORD){return 42;}
static int atcs_pid_alive(DWORD){return 1;}
static int agent_policy_host(const ATCS_Claims*){return 1;}
static uint64_t harness_now(){return 100;}
static int harness_verify_token(const char* token,unsigned len,DWORD parent,const char*,ATCS_Claims* out){++g_verifications;if(!g_verifyAllowed||parent!=42||len!=g_expected.size()||memcmp(token,g_expected.data(),len))return 0;*out=g_fixtureLease;return 1;}
static void SecureZeroMemory(void* data,size_t n){atcs_wipe(data,n);}
static BOOL WaitNamedPipeW(const wchar_t* name,DWORD){return g_allowNameAlias||g_serverName==name;}
static HANDLE CreateFileW(const wchar_t*,DWORD,DWORD,void*,DWORD,DWORD,void*){return (HANDLE)1;}
static BOOL SetNamedPipeHandleState(HANDLE,DWORD*,void*,void*){return TRUE;}
static BOOL CloseHandle(HANDLE){return TRUE;}
static int atcs_pipe_io(HANDLE,int writing,void* data,DWORD count,DWORD* actual);
#define atcs_verify_token harness_verify_token
#define atcs_now harness_now
#undef ATCS_PIPE_MAGIC
#define ATCS_PIPE_MAGIC legacy_pipe_magic
#define agent_poll_authorization legacy_agent1164_receive
#include "legacy_agent1164_receive.inc"
#undef agent_poll_authorization
#undef ATCS_PIPE_MAGIC
#define ATCS_PIPE_MAGIC current_pipe_magic
#include "agent_pipe_transport.inc"
#undef atcs_now
#undef atcs_verify_token
static int atcs_pipe_io(HANDLE,int writing,void* data,DWORD count,DWORD* actual){if(writing){++g_submissions;g_wire.assign((unsigned char*)data,(unsigned char*)data+count);*actual=count;return 1;}g_reply=0;if(g_legacyReceiver)legacy_agent1164_receive();else agent_poll_authorization();memcpy(data,&g_reply,4);*actual=4;return 1;}
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL pipe line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static void valid_size(unsigned n){g_authInstalled=0;g_expected.assign(n,'a');g_expected.replace(0,5,"XAT3.");unsigned verify=g_verifications;CHECK(atcs_pipe_bootstrap(77,g_expected.data(),n,AT_BUILD_EXPECT));CHECK(g_wire.size()==n+8&&g_verifications==verify+1&&g_authInstalled&&g_disconnects);DWORD length=0;memcpy(&length,g_wire.data()+4,4);CHECK(length==n&&!memcmp(g_wire.data()+8,g_expected.data(),n));}
int main(int argc,char** argv){
 wchar_t server[128];atcs_pipe_name(77,AT_BUILD_EXPECT,server,128);g_serverName=server;CHECK(g_serverName==std::wstring(L"\\\\.\\pipe\\xhh.rack.agent.v3.b")+std::to_wstring(AT_BUILD_EXPECT)+L".77");CHECK(current_pipe_magic==0x33424b58UL);
 memset(&g_fixtureLease,0,sizeof g_fixtureLease);strcpy(g_fixtureLease.sid,"test");g_fixtureLease.issued=101;g_fixtureLease.expires=200;g_fixtureLease.parent=42;g_fixtureLease.policy=1;
 CHECK(ATCS_PIPE_MAX==4096&&ATCS_PIPE_MAX==ATCS_MAX_TOKEN);
 valid_size(400);CHECK(g_parameterPaused&&g_pauseBarrier.paused&&!g_pauseBarrier.sequence&&queueCancels>0);valid_size(2048);valid_size(2049);valid_size(3451);valid_size(4096);
 /* Actual lease installation preserves pause, but invalidates old posted UI
    epochs and resets mailbox sequence space only for strictly newer claims. */
 g_parameterPaused=0;g_pauseBarrier={88,0};LONG oldEpoch=g_parameterEpoch;g_fixtureLease.issued++;
 CHECK(atcs_pipe_bootstrap(77,g_expected.data(),4096,AT_BUILD_EXPECT));CHECK(!g_parameterPaused&&!g_pauseBarrier.paused&&g_pauseBarrier.sequence==0&&g_parameterEpoch>oldEpoch);
 g_parameterPaused=1;g_pauseBarrier={90,1};oldEpoch=g_parameterEpoch;g_fixtureLease.issued++;
 CHECK(atcs_pipe_bootstrap(77,g_expected.data(),4096,AT_BUILD_EXPECT));CHECK(g_parameterPaused&&g_pauseBarrier.paused&&g_pauseBarrier.sequence==0&&g_parameterEpoch>oldEpoch);
 g_pauseBarrier.sequence=91;oldEpoch=g_parameterEpoch;unsigned beforeCancel=queueCancels;
 CHECK(atcs_pipe_bootstrap(77,g_expected.data(),4096,AT_BUILD_EXPECT));CHECK(g_parameterPaused&&g_pauseBarrier.sequence==91&&g_parameterEpoch==oldEpoch&&queueCancels==beforeCancel);
 strcpy(g_fixtureLease.plugins,"7761766573");g_authSequences[0]=55;
 CHECK(!atcs_pipe_bootstrap(77,g_expected.data(),4096,AT_BUILD_EXPECT));CHECK(g_authInstalled&&g_authLease.plugins[0]==0&&g_authSequences[0]==55);
 g_fixtureLease.plugins[0]=0;CHECK(atcs_pipe_bootstrap(77,g_expected.data(),4096,AT_BUILD_EXPECT));CHECK(g_authSequences[0]==55);
 unsigned submits=g_submissions;CHECK(!atcs_pipe_bootstrap(77,NULL,400,AT_BUILD_EXPECT));CHECK(!atcs_pipe_bootstrap(77,"",0,AT_BUILD_EXPECT));CHECK(!atcs_pipe_bootstrap(77,g_expected.data(),4097,AT_BUILD_EXPECT));CHECK(g_submissions==submits);
 g_authInstalled=0;g_verifyAllowed=0;CHECK(!atcs_pipe_bootstrap(77,g_expected.data(),4096,AT_BUILD_EXPECT));CHECK(!g_authInstalled);g_verifyAllowed=1;
 g_peerAllowed=0;submits=g_submissions;CHECK(!atcs_pipe_bootstrap(77,g_expected.data(),4096,AT_BUILD_EXPECT));CHECK(g_submissions==submits);g_peerAllowed=1;
 g_authInstalled=0;g_wire[0]^=1;g_reply=99;agent_poll_authorization();CHECK(g_reply==0&&!g_authInstalled);g_wire[0]^=1;
 DWORD tooLong=4097;memcpy(g_wire.data()+4,&tooLong,4);g_reply=99;agent_poll_authorization();CHECK(g_reply==0&&!g_authInstalled);
 g_wire.resize(8+4097);g_reply=99;agent_poll_authorization();CHECK(g_reply==0&&!g_authInstalled);
 /* Legacy 1164 receivers share XAT3/channel crypto, so the transport itself
    must refuse them BEFORE they install a current session key. */
 g_authInstalled=0;memset(&g_authLease,0,sizeof g_authLease);g_expected.assign(400,'a');g_expected.replace(0,5,"XAT3.");g_fixtureLease.plugins[0]=0;
 g_serverName=L"\\\\.\\pipe\\xhh.rack.agent.v2.77";g_legacyReceiver=1;unsigned verified=g_verifications;submits=g_submissions;
 CHECK(!atcs_pipe_bootstrap(77,g_expected.data(),(unsigned)g_expected.size(),AT_BUILD_EXPECT));CHECK(!g_authInstalled&&g_submissions==submits&&g_verifications==verified);
 g_allowNameAlias=1;CHECK(!atcs_pipe_bootstrap(77,g_expected.data(),(unsigned)g_expected.size(),AT_BUILD_EXPECT));CHECK(!g_authInstalled&&g_verifications==verified);
 g_legacyReceiver=0;DWORD oldMagic=legacy_pipe_magic;memcpy(g_wire.data(),&oldMagic,4);g_reply=99;agent_poll_authorization();CHECK(!g_authInstalled&&g_reply==0&&g_verifications==verified);
 g_allowNameAlias=0;g_serverName=server;CHECK(atcs_pipe_bootstrap(77,g_expected.data(),(unsigned)g_expected.size(),AT_BUILD_EXPECT));CHECK(g_authInstalled&&g_verifications==verified+1);
 /* Namespace pairing is build-bound too, so future same-token builds cannot
    silently authorize a previous agent with different GUI safety semantics. */
 g_authPipe=INVALID_HANDLE_VALUE;agent_poll_authorization();CHECK(g_startedBuild==AT_BUILD&&g_serverName==server);g_authPipe=(HANDLE)1;
 for(unsigned serverBuild=1164;serverBuild<=1166;serverBuild++){
  wchar_t buildName[128];atcs_pipe_name(77,serverBuild,buildName,128);g_serverName=buildName;
  for(unsigned clientBuild=1164;clientBuild<=1166;clientBuild++){
   g_authInstalled=0;unsigned beforeVerify=g_verifications,beforeSend=g_submissions;
   int accepted=atcs_pipe_bootstrap(77,g_expected.data(),(unsigned)g_expected.size(),clientBuild);
   CHECK(accepted==(clientBuild==serverBuild));CHECK(g_authInstalled==(clientBuild==serverBuild));
   if(clientBuild!=serverBuild)CHECK(g_submissions==beforeSend&&g_verifications==beforeVerify);
  }
 }
 g_serverName=server;CHECK(!atcs_pipe_bootstrap(77,g_expected.data(),(unsigned)g_expected.size(),0));
 if(argc==2){std::ifstream file(argv[1],std::ios::binary);g_expected.assign(std::istreambuf_iterator<char>(file),{});CHECK(g_expected.size()>2048&&g_expected.size()<=ATCS_MAX_TOKEN);g_authInstalled=0;CHECK(atcs_pipe_bootstrap(77,g_expected.data(),(unsigned)g_expected.size(),AT_BUILD_EXPECT));}
 printf("PASS production pipe bootstrap/receive: %u checks (Win32/token substitutes)\n",checks);
}
