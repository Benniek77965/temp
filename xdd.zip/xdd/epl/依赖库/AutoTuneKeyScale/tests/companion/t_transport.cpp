/* Exact production callbacks; platform/token verifier substitutes are test-only.
   This verifies dispatcher and lease installation, not UIPI. */
#include "companion_security.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <string>
typedef int32_t LONG;
typedef intptr_t LRESULT;
typedef uintptr_t WPARAM;
typedef intptr_t LPARAM;
typedef void* HWND;
typedef void* HANDLE;
typedef struct { uintptr_t dwData; DWORD cbData; void* lpData; } COPYDATASTRUCT;
#define WAIT_TIMEOUT 258
#define WM_CLOSE 0x10
#define ATC_APPLY_MESSAGE 0x8003
#define ATC_START_MESSAGE 0x8004
static LONG g_managed=1,g_authorized=0,g_runtimeReady=0,g_compGoalValid=0,g_compForceExit=0;
static HANDLE g_parent=(HANDLE)2;
static DWORD g_parentPid=42,g_senderPid=42,g_waitResult=WAIT_TIMEOUT;
static uint64_t g_lastSequence=0,g_compGeneration=0,g_compCommandSequence=0;
static DWORD g_compReceivedAt=0;
static int g_compLock=0,g_compQueuedCommand=-1;
static int g_compPaused=0,g_compPauseAcknowledged=0;
static uint64_t g_compPauseSequence=0;static char g_compPauseSid[33]="";
static LONG g_compRacks=0,g_compCaptured=0,g_compPending=0,g_compConfirmed=0,g_compOld=0;
static LONG g_compAuthError=0,g_compHasR=0,g_compStrength=-1,g_compMixedFamily=0,g_compReconnectAll=0;
static int g_cmdWriteFail=0,g_agentMissing=0,g_agentStale=0,g_blockedHosts=0,g_blockedOther=0;
static int g_hostsOverflow=0,g_sgFull=0,g_aggFull=0;
static volatile LONG g_compMismatchFull=0;
static unsigned char g_sessionKey[32]={0};
static ATCS_Claims g_compLease,g_testLease;
static char g_compDevice[65]="",g_compToken[ATC_MAX_PAYLOAD+1]="";
static ATC_Apply g_compGoal={-1,-1,-1};
static unsigned g_posts=0,g_shows=0,g_lastMessage=0,g_verifierCalls=0;
static WPARAM g_lastWparam=0;
static int g_verifyAccept=0;
static uint64_t g_clock=1000;
static DWORD GetWindowThreadProcessId(HWND,DWORD* id) {*id=g_senderPid;return 1;}
static DWORD WaitForSingleObject(HANDLE,DWORD) {return g_waitResult;}
static DWORD GetTickCount(){return 100;}
static void EnterCriticalSection(int* lock){++*lock;}
static void LeaveCriticalSection(int* lock){--*lock;}
static LONG InterlockedCompareExchange(volatile LONG* p,LONG v,LONG expected){LONG old=*p;if(old==expected)*p=v;return old;}
static LONG InterlockedExchange(LONG* v,LONG r){LONG old=*v;*v=r;return old;}
static LONG InterlockedOr(LONG* v,LONG r){LONG old=*v;*v|=r;return old;}
static LONG InterlockedAnd(LONG* v,LONG r){LONG old=*v;*v&=r;return old;}
static void SecureZeroMemory(void* p,size_t n){atcs_wipe(p,n);}
static void companion_show(HWND){++g_shows;}
static int PostMessageA(HWND,unsigned m,WPARAM wp,LPARAM){++g_posts;g_lastMessage=m;g_lastWparam=wp;return 1;}
static uint64_t harness_now(){return g_clock;}
static int harness_verify_token(const char*,unsigned,DWORD parent,const char* device,ATCS_Claims* out){
    ++g_verifierCalls;
    if(!g_verifyAccept||parent!=42||strcmp(device,g_compDevice))return 0;
    *out=g_testLease;return 1;
}

/* OS/Registry boundaries are substituted. Stored goal layout and the production
   save/clear/restore/start/apply message bodies are extracted without copying logic. */
typedef void* HKEY;typedef unsigned char BYTE;
#define HKEY_CURRENT_USER ((HKEY)4)
#define KEY_SET_VALUE 2
#define KEY_QUERY_VALUE 1
#define ERROR_SUCCESS 0
#define REG_BINARY 3
#define TRUE 1
#define CB_SETCURSEL 0x14e
#define CB_FINDSTRINGEXACT 0x158
static DWORD g_compScopePid=0,g_compScopeId=0,g_compSentAt=0;
static char g_compScopeLeaf[96]="";
static LONG g_compLastSentKeyScale=0,g_compNeedReplay=0,g_compRetry=0;
static int g_restoreAutomaticGoal=0;
static HWND g_key=0,g_scale=0,g_retune=0,g_humanize=0,g_nvib=0,g_audio=0,g_status=0;
static HANDLE g_scanTh=0;
static const char* SCALES[]={"Major","Minor","Chromatic"};
static const char* EJECTFLAG="fixture-eject";
static const char* CMDFILE="fixture-command";
static unsigned g_pauseWrites=0;static int g_pauseWriteAccept=1;static std::string g_pauseWritten;
static std::vector<unsigned char> g_registryGoal;
static uint64_t g_parentStart=123456;
static unsigned g_runtimeExtractions=0,g_scanners=0,g_ejectWrites=0;
static uint64_t companion_parent_start(){return g_parentStart;}
static LONG RegCreateKeyExA(HKEY,const char*,DWORD,const char*,DWORD,DWORD,void*,HKEY* key,DWORD*){*key=(HKEY)1;return 0;}
static LONG RegOpenKeyExA(HKEY,const char*,DWORD,DWORD,HKEY* key){if(g_registryGoal.empty())return 2;*key=(HKEY)1;return 0;}
static LONG RegSetValueExA(HKEY,const char*,DWORD,DWORD,const BYTE* data,DWORD len){g_registryGoal.assign(data,data+len);return 0;}
static LONG RegQueryValueExA(HKEY,const char*,DWORD*,DWORD* type,BYTE* data,DWORD* len){*type=REG_BINARY;if(*len<g_registryGoal.size())return 234;*len=(DWORD)g_registryGoal.size();memcpy(data,&g_registryGoal[0],*len);return 0;}
static LONG RegDeleteValueA(HKEY,const char*){g_registryGoal.clear();return 0;}
static LONG RegCloseKey(HKEY){return 0;}
static void ensure_runtime(){++g_runtimeExtractions;}
static void EnableWindow(HWND,int){}
static DWORD scan_thread(void*){return 0;}
static HANDLE CreateThread(void*,size_t,DWORD(*)(void*),void*,DWORD,void*){++g_scanners;return (HANDLE)5;}
static void companion_log(const char*,int,int,int){}
static void SetWindowTextW(HWND,const wchar_t*){}
static unsigned g_goalUiCalls=0,g_goalWrites=0;static int g_lastGoalWrite=-1;
static LONG SendMessageA(HWND,unsigned,WPARAM,LPARAM){++g_goalUiCalls;return 0;}
static int write_ctl_file(const char*,const char* data,DWORD,uint64_t* seq=NULL){if(seq)*seq=0;if(!strncmp(data,"pause=",6)){++g_pauseWrites;g_pauseWritten=data;if(!g_pauseWriteAccept)return 0;if(seq)*seq=++g_compCommandSequence;return 1;}++g_ejectWrites;return 1;}
static void eject_legacy_agents(){}
static void companion_write_goal(int keyScale){++g_goalWrites;g_lastGoalWrite=keyScale;}

#define atcs_verify_token harness_verify_token
#define atcs_now harness_now
#include "controller_transport.inc"
#undef atcs_now
#undef atcs_verify_token
static unsigned checks=0;
static void check(bool ok,const char* expression,int line){++checks;if(!ok){fprintf(stderr,"FAIL transport line %d: %s\n",line,expression);exit(1);}}
#define CHECK(x) check(!!(x),#x,__LINE__)
static std::vector<unsigned char> packet(unsigned op,uint64_t seq,const char* payload){
    size_t n=strlen(payload);std::vector<unsigned char>b(ATC_HEADER_SIZE+n,0);memcpy(&b[0],"XAKS",4);b[4]=ATC_PROTOCOL_VERSION;b[6]=ATC_HEADER_SIZE;b[8]=(unsigned char)op;
    for(unsigned i=0;i<4;++i)b[12+i]=(unsigned char)(n>>(8*i));
    for(unsigned i=0;i<8;++i)b[16+i]=(unsigned char)(seq>>(8*i));
    if(n)memcpy(&b[ATC_HEADER_SIZE],payload,n);
    std::vector<unsigned char>input(24+n);memcpy(&input[0],&b[0],24);if(n)memcpy(&input[24],payload,n);
    atc_hmac_sha256(g_sessionKey,32,&input[0],input.size(),&b[24]);return b;
}
static LRESULT dispatch(std::vector<unsigned char>& b){COPYDATASTRUCT cds={ATC_COPYDATA_ID,(DWORD)b.size(),&b[0]};return companion_copydata((HWND)1,(WPARAM)3,(LPARAM)&cds);}
int main(){
    CHECK(companion_copydata((HWND)1,0,0)==ATC_REPLY_BAD_PACKET);
    std::vector<unsigned char>b=packet(ATC_HELLO,1,"");
    g_senderPid=7;CHECK(dispatch(b)==ATC_REPLY_WRONG_PARENT);g_senderPid=42;
    g_waitResult=0;CHECK(dispatch(b)==ATC_REPLY_WRONG_PARENT);g_waitResult=WAIT_TIMEOUT;
    CHECK(dispatch(b)==((ATC_PROTOCOL_VERSION<<16)|ATC_CONTROLLER_VERSION));
    b=packet(ATC_HELLO,1,"extra");CHECK(dispatch(b)==ATC_REPLY_BAD_PACKET);
    b=packet(ATC_STATUS,1,"");CHECK((uint32_t)dispatch(b)==0xc0000000UL);
    g_compRacks=128;g_compCaptured=64;g_compPending=64;g_compConfirmed=64;
    uint32_t state=(uint32_t)dispatch(b);
    CHECK((state&0x02000000UL)!=0);CHECK(((state>>18)&127)==127);
    CHECK(((state>>12)&63)==63&&((state>>6)&63)==63&&(state&63)==63);
    g_compRacks=g_compCaptured=g_compPending=g_compConfirmed=0;
    g_compGoal={7,0,-1};g_compGoalValid=1;g_compConfirmed=1;
    b=packet(ATC_STATUS,1,"expect=3:0");CHECK(((uint32_t)dispatch(b)&63)==0);
    b=packet(ATC_STATUS,1,"expect=7:0");CHECK(((uint32_t)dispatch(b)&63)==1);
    b=packet(ATC_STATUS,1,"expect=7:1");CHECK(((uint32_t)dispatch(b)&63)==0);
    const char* badExpect[]={"expect=01:0","expect=12:0","expect=1:3","expect=0:0x","expect=-1:0","expect=1:00"};
    for(unsigned i=0;i<sizeof badExpect/sizeof badExpect[0];++i){b=packet(ATC_STATUS,1,badExpect[i]);CHECK(dispatch(b)==ATC_REPLY_BAD_PACKET);}
    g_compGoal={-1,-1,-1};g_compGoalValid=0;

    b=packet(ATC_STATUS,1,"feel");CHECK((uint32_t)dispatch(b)==0xc0000000UL);
    g_compHasR=1;g_compStrength=750;g_compMixedFamily=1;
    CHECK((uint32_t)dispatch(b)==0xf80002eeUL);
    b=packet(ATC_STATUS,1,"errors");CHECK((uint32_t)dispatch(b)==0x80000000UL);
    b=packet(ATC_STATUS,1,"extra");CHECK(dispatch(b)==ATC_REPLY_BAD_PACKET);
    b=packet(ATC_AUTHORIZE,1,"not-a-real-server-token");CHECK(dispatch(b)==ATC_REPLY_AUTH_UNAVAILABLE);
    CHECK(g_verifierCalls==1&&g_compAuthError==1);
    CHECK(g_authorized==0&&g_runtimeReady==0&&g_posts==0&&g_lastSequence==0);
    const unsigned ops[]={ATC_APPLY,ATC_FEEL,ATC_EJECT,ATC_PAUSE,ATC_QUIT};
    for(unsigned i=0;i<sizeof ops/sizeof ops[0];++i){
        const char* payload=ops[i]==ATC_APPLY?"key=5;scale=Major":ops[i]==ATC_FEEL?"retune=0.5":"";
        b=packet(ops[i],1,payload);CHECK(dispatch(b)==ATC_REPLY_AUTH_REQUIRED);
    }
    CHECK(g_compGoalValid==0&&g_compForceExit==0&&g_posts==0&&g_shows==0&&g_lastSequence==0);
    /* A verifier substitute models an already verified server lease. No
       cryptographic validity is claimed by these dispatcher assertions. */
    memset(&g_testLease,0,sizeof g_testLease);g_testLease.issued=990;g_testLease.expires=1100;
    strcpy(g_testLease.sid,"0123456789abcdef0123456789abcdef");
    memset(g_compDevice,'a',64);g_compDevice[64]=0;g_testLease.parent=42;g_testLease.policy=1;strcpy(g_testLease.license,"L1");strcpy(g_testLease.device,g_compDevice);
    for(unsigned i=0;i<32;++i)g_testLease.key[i]=(unsigned char)i;
    g_compAuthError|=4; /* A successful new lease clears a prior expiry diagnostic. */
    g_verifyAccept=1;b=packet(ATC_AUTHORIZE,1,"verified-fixture");
    CHECK(dispatch(b)==ATC_REPLY_OK);
    CHECK(g_authorized==1&&g_runtimeReady==0&&g_compAuthError==0&&g_compReconnectAll==1);
    CHECK(g_posts==1&&g_lastMessage==ATC_START_MESSAGE&&g_lastSequence==0);
    CHECK(!memcmp(g_sessionKey,g_testLease.key,32)&&!strcmp(g_compToken,"verified-fixture"));
    g_posts=0;
    b=packet(ATC_APPLY,1,"key=5;scale=Major");b[24]^=1;
    CHECK(dispatch(b)==ATC_REPLY_BAD_MAC);CHECK(g_lastSequence==0&&g_posts==0);
    b=packet(ATC_APPLY,1,"key=99;scale=Major");CHECK(dispatch(b)==ATC_REPLY_BAD_PACKET);CHECK(g_lastSequence==0&&g_posts==0);
    b=packet(ATC_APPLY,1,"key=5;scale=Major");CHECK(dispatch(b)==ATC_REPLY_AUTH_REQUIRED);
    b=packet(ATC_FEEL,1,"retune=0.500");CHECK(dispatch(b)==ATC_REPLY_AUTH_REQUIRED);
    CHECK(g_lastSequence==0&&g_posts==0&&g_compGoalValid==0&&g_compGeneration==0);
    g_runtimeReady=1; /* the asynchronous START_MESSAGE has now completed */
    g_compConfirmed=3;
    b=packet(ATC_APPLY,1,"key=5;scale=Major");CHECK(dispatch(b)==ATC_REPLY_OK);
    CHECK(g_compGoal.key==5&&g_compGoal.scale==0&&g_compGoalValid==1&&g_compGoal.retune==-1);
    CHECK(g_compGeneration==1);
    CHECK(g_lastSequence==1&&g_posts==1&&g_lastMessage==ATC_APPLY_MESSAGE&&g_compQueuedCommand==1);
    CHECK(g_compConfirmed==0);
    CHECK(dispatch(b)==ATC_REPLY_REPLAY);CHECK(g_posts==1&&g_lastSequence==1);
    b=packet(ATC_FEEL,2,"retune=0.500");CHECK(dispatch(b)==ATC_REPLY_OK);
    CHECK(g_compGoal.key==5&&g_compGoal.scale==0&&g_compGoal.retune==500&&g_lastWparam==0&&g_posts==2);
    CHECK(g_compQueuedCommand==1); /* APPLY survives a later FEEL. */
    CHECK(g_compGeneration==1); /* FEEL retains Key/Scale generation. */
    CHECK(g_compLock==0);
    g_compCommandSequence=55;
    b=packet(ATC_AUTHORIZE,3,"verified-fixture");CHECK(dispatch(b)==ATC_REPLY_OK);
    CHECK(g_lastSequence==2&&g_compCommandSequence==55); /* Identical renewal cannot reopen replay window. */
    strcpy(g_testLease.plugins,"7761766573");b=packet(ATC_AUTHORIZE,3,"same-time-changed-policy");
    CHECK(dispatch(b)==ATC_REPLY_AUTH_UNAVAILABLE);
    CHECK(g_lastSequence==2&&g_compCommandSequence==55&&g_compLease.plugins[0]==0&&!strcmp(g_compToken,"verified-fixture"));
    g_testLease.plugins[0]=0;
    g_posts=2;
    --g_testLease.issued;b=packet(ATC_AUTHORIZE,3,"older-fixture");
    CHECK(dispatch(b)==ATC_REPLY_AUTH_UNAVAILABLE);
    CHECK(g_lastSequence==2&&g_compCommandSequence==55&&g_compAuthError==2&&g_compLease.issued==990);
    g_verifyAccept=0;b=packet(ATC_AUTHORIZE,3,"bad-fixture");
    CHECK(dispatch(b)==ATC_REPLY_AUTH_UNAVAILABLE);CHECK(g_authorized==1&&g_lastSequence==2&&g_compGoal.retune==500);
    g_verifyAccept=1;g_testLease.issued=1001;g_testLease.expires=1110;g_testLease.key[0]^=0x50;
    b=packet(ATC_AUTHORIZE,3,"new-fixture");CHECK(dispatch(b)==ATC_REPLY_OK);
    CHECK(g_lastSequence==0&&g_compCommandSequence==0&&g_compAuthError==0&&g_compLease.issued==1001);
    g_posts=2;g_compQueuedCommand=-1;
    b=packet(6,1,"extra");CHECK(dispatch(b)==ATC_REPLY_BAD_PACKET);CHECK(g_lastSequence==0&&g_shows==0);
    b=packet(6,1,"");CHECK(dispatch(b)==ATC_REPLY_BAD_PACKET);CHECK(g_lastSequence==0&&g_shows==0);
    b=packet(ATC_FEEL,1,"retune=0.500");CHECK(dispatch(b)==ATC_REPLY_OK);g_posts=2;
    g_clock=1110;b=packet(ATC_APPLY,2,"key=6;scale=Minor");
    CHECK(dispatch(b)==ATC_REPLY_AUTH_REQUIRED);CHECK(g_lastSequence==1&&g_compGoal.key==5);
    g_clock=1002;b=packet(ATC_EJECT,2,"");CHECK(dispatch(b)==ATC_REPLY_OK);CHECK(g_compQueuedCommand==2&&g_posts==3);
    b=packet(ATC_APPLY,3,"key=6;scale=Minor");CHECK(dispatch(b)==ATC_REPLY_AUTH_REQUIRED);
    CHECK(g_compQueuedCommand==2&&g_lastSequence==2&&g_posts==3&&g_compGoal.key==5);
    b=packet(ATC_PAUSE,3,"");CHECK(dispatch(b)==ATC_REPLY_AUTH_REQUIRED&&g_compQueuedCommand==2);
    b=packet(ATC_FEEL,3,"retune=0.750");CHECK(dispatch(b)==ATC_REPLY_AUTH_REQUIRED);
    CHECK(g_compGoal.retune==500&&g_lastSequence==2);
    b=packet(ATC_QUIT,3,"");CHECK(dispatch(b)==ATC_REPLY_OK);CHECK(g_compForceExit==1&&g_lastMessage==WM_CLOSE&&g_posts==4);

    /* A replacement controller never resurrects a stored goal before the
       parent's new APPLY. This also covers a crash before PAUSE was processed. */
    g_managed=1;g_authorized=1;g_compGoal={-1,-1,-1};g_compGoalValid=0;g_runtimeReady=0;
    g_registryGoal.assign(128,0x41); /* old persisted bytes must be ignored */
    CHECK(production_launch_intent("--show")==0);
    CHECK(production_launch_intent("--companion 42")==1);
    production_start_message((HWND)1);CHECK(g_runtimeReady&&g_runtimeExtractions==1&&g_scanners==1&&!g_compGoalValid&&g_compGoal.key==-1);
    CHECK(!g_registryGoal.empty()); /* START does not read or resurrect it */
    g_compGoal={9,0,900};g_compGoalValid=1;g_compQueuedCommand=2;g_authorized=1;g_runtimeReady=1;
    production_apply_message((HWND)1);CHECK(g_compGoalValid==0&&g_compGoal.key==-1&&g_compGoal.scale==-1&&g_compGoal.retune==-1&&g_registryGoal.empty()&&g_compScopePid==0&&g_compScopeId==0&&g_compScopeLeaf[0]==0);
    CHECK(g_authorized==0&&g_ejectWrites==1&&g_compNeedReplay==0&&g_compRetry==0);
    unsigned runtimes=g_runtimeExtractions,scanners=g_scanners;g_runtimeReady=0;
    CHECK(production_launch_intent("")==0);CHECK(g_runtimeExtractions==runtimes&&g_scanners==scanners);

    /* A successful agent bootstrap or renewal can request replay before the
       first authenticated automatic target exists.
       Execute the real message body: no SCALES[-1] access or stale key UI write. */
    g_authorized=1;g_runtimeReady=1;g_compGoal={-1,-1,-1};g_compGoalValid=0;
    g_compQueuedCommand=-1;g_compNeedReplay=1;unsigned uiBefore=g_goalUiCalls;
    production_apply_message((HWND)1);
    CHECK(g_goalUiCalls==uiBefore&&g_lastGoalWrite==0&&g_compNeedReplay==0);
    g_compGoal={6,-1,500};g_compGoalValid=0;g_compNeedReplay=1;
    production_apply_message((HWND)1);CHECK(g_goalUiCalls==uiBefore&&g_lastGoalWrite==0);
    g_compGoal={6,1,500};g_compGoalValid=1;g_compNeedReplay=1;
    production_apply_message((HWND)1);CHECK(g_goalUiCalls==uiBefore&&g_lastGoalWrite==1);

    /* Pause is authenticated, leaves the runtime connected, and cannot be
       cancelled by APPLY before the agent-side barrier acknowledgement. */
    g_authorized=1;g_runtimeReady=1;g_clock=1002;g_compGoal={3,0,400};g_compGoalValid=1;g_compQueuedCommand=1;
    unsigned goalBefore=g_goalWrites;
    b=packet(ATC_PAUSE,100,"");b[24]^=1;CHECK(dispatch(b)==ATC_REPLY_BAD_MAC&&g_compGoalValid&&!g_compPaused);
    b=packet(ATC_PAUSE,100,"extra");CHECK(dispatch(b)==ATC_REPLY_BAD_PACKET&&!g_compPaused);
    b=packet(ATC_PAUSE,100,"");CHECK(dispatch(b)==ATC_REPLY_OK&&g_compPaused&&!g_compGoalValid&&g_authorized&&g_runtimeReady&&g_compQueuedCommand==3);
    b=packet(ATC_STATUS,1,"paused");CHECK((uint32_t)dispatch(b)==0xc0000000U);
    b=packet(ATC_APPLY,101,"key=4;scale=Minor");CHECK(dispatch(b)==ATC_REPLY_AUTH_REQUIRED&&g_lastSequence==100);
    b=packet(ATC_FEEL,101,"retune=0.5");CHECK(dispatch(b)==ATC_REPLY_AUTH_REQUIRED&&g_lastSequence==100);
    g_pauseWriteAccept=0;production_apply_message((HWND)1);CHECK(g_cmdWriteFail&&g_compPauseSequence==0&&g_goalWrites==goalBefore);
    g_pauseWriteAccept=1;companion_write_pause();CHECK(!g_cmdWriteFail&&g_compPauseSequence&&g_pauseWritten=="pause=1|t=100\n"&&!strcmp(g_compPauseSid,g_compLease.sid));
    unsigned pauseWrites=g_pauseWrites;uint64_t pauseSeq=g_compPauseSequence;
    b=packet(ATC_PAUSE,102,"");CHECK(dispatch(b)==ATC_REPLY_OK&&g_pauseWrites==pauseWrites&&g_compPauseSequence==pauseSeq);
    g_compPauseAcknowledged=1; /* read_status acknowledgement is exercised separately */
    b=packet(ATC_STATUS,1,"paused");CHECK((uint32_t)dispatch(b)==0x80000000U);
    g_clock=g_compLease.expires;CHECK((uint32_t)dispatch(b)==0xc0000000U);g_clock=1002;
    b=packet(ATC_FEEL,103,"retune=0.5");CHECK(dispatch(b)==ATC_REPLY_AUTH_REQUIRED&&g_compPaused);
    b=packet(ATC_APPLY,103,"key=4;scale=Minor");CHECK(dispatch(b)==ATC_REPLY_OK&&!g_compPaused&&g_compGoal.key==4&&g_compGoal.scale==1&&g_compGoalValid);
    production_apply_message((HWND)1);CHECK(g_goalWrites==goalBefore+1&&g_lastGoalWrite==1);
    b=packet(ATC_PAUSE,104,"");CHECK(dispatch(b)==ATC_REPLY_OK);production_apply_message((HWND)1);g_compPauseAcknowledged=1;
    g_testLease.issued=1003;g_testLease.expires=1120;g_testLease.key[0]^=0x20;
    b=packet(ATC_AUTHORIZE,1,"new-paused-lease");CHECK(dispatch(b)==ATC_REPLY_OK&&g_compPaused&&!g_compPauseSequence&&!g_compPauseAcknowledged);
    production_start_message((HWND)1);CHECK(g_compQueuedCommand==3&&!g_compGoalValid&&!g_compNeedReplay);production_apply_message((HWND)1);CHECK(g_compPauseSequence&&!g_compPauseAcknowledged&&g_goalWrites==goalBefore+1);

    g_managed=0;CHECK(dispatch(b)==0);
    CHECK(g_compLock==0);
    printf("PASS extracted companion transport: %u checks (platform/token substitutes)\n",checks);return 0;
}
