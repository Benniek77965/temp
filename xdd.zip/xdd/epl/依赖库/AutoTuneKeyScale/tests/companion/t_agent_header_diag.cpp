/* Exact failed-bootstrap status diagnostic. Process/auth are explicit boundaries;
   real stdio reads the existing status header. No bootstrap mechanism is changed. */
#include "companion_security.h"
#include "controller_build.inc"
#include <string>
#include <stdio.h>
#include <stdlib.h>
typedef int32_t LONG;typedef void* HANDLE;
#define FALSE 0
#define PROCESS_QUERY_LIMITED_INFORMATION 1
#define STILL_ACTIVE 259
#define GetFileExInfoStandard 0
struct FILETIME{DWORD dwLowDateTime,dwHighDateTime;};struct WIN32_FILE_ATTRIBUTE_DATA{FILETIME ftLastWriteTime;};struct Host{DWORD pid;};
#define MAXTRACK 256
#define MAX_PATH 260
static int g_managed=1,g_compLock=0,g_ninj=0;static LONG g_compAuthError=0;static ATCS_Claims g_compLease;
static DWORD g_injected[MAXTRACK];static uint64_t g_bootIssued[MAXTRACK];static char g_compToken[ATC_MAX_PAYLOAD+1]="XAT3.fixture",COMMDIR[MAX_PATH]="fixture";
static bool bootstrapOk=false,readFails=false,policyOk=true,attributesOk=true;static bool alive[4096],denied[4096];static uint64_t bornAt[4096],writtenAt[4096];static int handles=0;static std::string header;
static int companion_policy_process(DWORD pid){return pid<4096&&policyOk&&!denied[pid]&&alive[pid];}
static HANDLE OpenProcess(DWORD,int,DWORD pid){if(pid>=4096||!alive[pid])return NULL;++handles;return (HANDLE)(uintptr_t)(pid+1);}
static int CloseHandle(HANDLE){--handles;return 1;}
static int GetExitCodeProcess(HANDLE h,DWORD* code){DWORD pid=(DWORD)(uintptr_t)h-1;*code=alive[pid]?STILL_ACTIVE:0;return 1;}
static int GetProcessTimes(HANDLE h,FILETIME* c,FILETIME*,FILETIME*,FILETIME*){DWORD pid=(DWORD)(uintptr_t)h-1;if(!bornAt[pid])return 0;c->dwLowDateTime=(DWORD)bornAt[pid];c->dwHighDateTime=(DWORD)(bornAt[pid]>>32);return 1;}
static int GetFileAttributesExA(const char* path,int,WIN32_FILE_ATTRIBUTE_DATA* data){if(!attributesOk)return 0;const char* leaf=strrchr(path,'\\');if(!leaf)return 0;DWORD pid=(DWORD)strtoul(leaf+8,NULL,10);if(pid>=4096)return 0;data->ftLastWriteTime.dwLowDateTime=(DWORD)writtenAt[pid];data->ftLastWriteTime.dwHighDateTime=(DWORD)(writtenAt[pid]>>32);return 1;}
static int atcs_pipe_bootstrap(DWORD,const char*,unsigned,unsigned){return bootstrapOk;}
static void EnterCriticalSection(int* n){++*n;}static void LeaveCriticalSection(int* n){--*n;}
static LONG InterlockedExchange(volatile LONG* p,LONG v){LONG old=*p;*p=v;return old;}
static LONG InterlockedOr(volatile LONG* n,LONG mask){LONG old=*n;*n|=mask;return old;}static LONG InterlockedAnd(volatile LONG* n,LONG mask){LONG old=*n;*n&=mask;return old;}
static void SecureZeroMemory(void* p,size_t n){atcs_wipe(p,n);}
static FILE* fixture_fopen(const char*,const char*){if(readFails)return NULL;const char* dir=getenv("ATC_TEST_TMP");if(!dir)abort();std::string file=std::string(dir)+"/agent-header-fixture.tmp";FILE* f=fopen(file.c_str(),"w+b");if(!f)abort();fwrite(header.data(),1,header.size(),f);rewind(f);return f;}
#define fopen fixture_fopen
#include "agent_header_diag.inc"
#undef fopen
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL agent-header line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static void reset(const std::string& text){header=text;g_compAuthError=0;g_ninj=0;g_compLease.issued=123;bootstrapOk=readFails=false;policyOk=attributesOk=true;handles=0;for(unsigned i=0;i<4096;i++){alive[i]=true;denied[i]=false;bornAt[i]=100000+i;writtenAt[i]=bornAt[i]+100;}
#ifndef BEFORE_PROOF
 g_compMismatchCount=0;g_compMismatchFull=0;
#endif
}
static std::string own(const char* suffix){return "#b"+std::to_string(AT_BUILD_EXPECT)+suffix;}
int main(){
 reset(own(" m=0\n"));mark_injected(10);CHECK((g_compAuthError&24)==24);CHECK(g_ninj==0);
#ifndef BEFORE_PROOF
 reset(own(" m=1\n"));mark_injected(10);CHECK(g_compAuthError==8&&g_ninj==0);
 reset(own(" m=0\r\n"));mark_injected(10);CHECK((g_compAuthError&24)==24);
 reset("#b1164 m=1\n");mark_injected(10);CHECK((g_compAuthError&24)==24);
 reset("#b1164\n");mark_injected(10);CHECK((g_compAuthError&24)==24);
 const char* invalid[]={"","#b","garbage\n","#b0 m=0\n","#b0001165 m=0\n","#b1165 m=2\n","#b1165 m=0 garbage\n","#b1165 m=0","#b42949672960 m=0\n"};
 for(unsigned i=0;i<sizeof invalid/sizeof*invalid;i++){reset(invalid[i]);mark_injected(10);CHECK(g_compAuthError==8&&g_ninj==0);}
 reset(own("\n"));mark_injected(10);CHECK(g_compAuthError==8&&g_ninj==0); /* mode absent: no guessed mismatch */
 reset(own(" m=0\n"));readFails=true;mark_injected(10);CHECK(g_compAuthError==8&&g_ninj==0);
 reset(own(" m=0\n"));policyOk=false;mark_injected(10);CHECK(g_compAuthError==0&&g_ninj==0);
 reset(own(" m=1\n"));bootstrapOk=true;mark_injected(10);CHECK(g_ninj==1&&g_injected[0]==10&&g_bootIssued[0]==123&&!(g_compAuthError&8));
 /* Knowledge is independent per process incarnation. A success cannot clear another host. */
 reset(own(" m=0\n"));mark_injected(10);mark_injected(20);CHECK(g_compMismatchCount==2&&(g_compAuthError&16));bootstrapOk=true;mark_injected(10);CHECK(g_compMismatchCount==1&&(g_compAuthError&16));mark_injected(20);CHECK(g_compMismatchCount==0&&!(g_compAuthError&16));
 reset(own(" m=0\n"));mark_injected(10);mark_injected(20);Host only10[]={{10}};companion_mismatch_prune(only10,1);CHECK(g_compMismatchCount==1&&g_compMismatches[0].pid==10&&(g_compAuthError&16));alive[10]=false;companion_mismatch_prune(only10,1);CHECK(g_compMismatchCount==0&&!(g_compAuthError&16));
 reset(own(" m=0\n"));mark_injected(10);Host both[]={{10},{20}};bornAt[10]+=1000;companion_mismatch_prune(both,2);CHECK(g_compMismatchCount==0&&!(g_compAuthError&16));mark_injected(10);CHECK(!(g_compAuthError&16)&&g_compMismatchCount==0); /* stale file predates reused PID */
 writtenAt[10]=bornAt[10]+100;mark_injected(10);CHECK((g_compAuthError&16)&&g_compMismatchCount==1);denied[10]=true;companion_mismatch_prune(both,2);CHECK(!(g_compAuthError&16)&&g_compMismatchCount==0);
 reset(own(" m=0\n"));attributesOk=false;mark_injected(10);CHECK(g_compAuthError==8&&g_compMismatchCount==0);attributesOk=true;bornAt[10]=0;mark_injected(10);CHECK(g_compAuthError==8&&g_compMismatchCount==0);
 reset(own(" m=0\n"));for(unsigned pid=1;pid<=MAXTRACK;pid++)mark_injected(pid);CHECK(g_compMismatchCount==MAXTRACK&&!g_compMismatchFull&&(g_compAuthError&16));mark_injected(MAXTRACK+1);CHECK(g_compMismatchCount==MAXTRACK&&g_compMismatchFull);bootstrapOk=true;mark_injected(1);CHECK(g_compMismatchCount==MAXTRACK-1&&!g_compMismatchFull&&(g_compAuthError&16));companion_mismatch_prune(NULL,0);CHECK(!g_compMismatchCount&&!g_compMismatchFull&&!(g_compAuthError&16));CHECK(handles==0);
#endif
 printf("PASS production failed-bootstrap header diagnostic: %u checks (stdio real, process/auth boundaries substituted)\n",checks);
}
