/* Exercise the exact production snapshot publication/reclamation code. OS heap
   and Interlocked boundaries are substituted; real threads stress reclamation. */
#include "companion_policy.h"
#include <atomic>
#include <thread>
#include <vector>
#include <stdlib.h>
#include <string.h>
typedef int32_t LONG;
static std::atomic<unsigned> allocations(0),frees(0);static bool failAllocation=false;
static LONG InterlockedIncrement(volatile LONG* p){return __atomic_add_fetch(p,1,__ATOMIC_SEQ_CST);}static LONG InterlockedDecrement(volatile LONG* p){return __atomic_sub_fetch(p,1,__ATOMIC_SEQ_CST);}static LONG InterlockedCompareExchange(volatile LONG* p,LONG want,LONG expected){__atomic_compare_exchange_n(p,&expected,want,false,__ATOMIC_SEQ_CST,__ATOMIC_SEQ_CST);return expected;}
static void* InterlockedCompareExchangePointer(void* volatile* p,void* want,void* expected){__atomic_compare_exchange_n(p,&expected,want,false,__ATOMIC_SEQ_CST,__ATOMIC_SEQ_CST);return expected;}static void* InterlockedExchangePointer(void* volatile* p,void* want){return __atomic_exchange_n(p,want,__ATOMIC_SEQ_CST);}
#define HEAP_ZERO_MEMORY 8
static void* GetProcessHeap(){return NULL;}static void* HeapAlloc(void*,unsigned,size_t bytes){if(failAllocation)return NULL;allocations++;return calloc(1,bytes);}static int HeapFree(void*,unsigned,void* p){frees++;free(p);return 1;}
#include "companion_loader_policy.h"
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL lifecycle line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static ATCS_Claims lease(uint64_t issued){ATCS_Claims p={};p.policy=1;p.issued=issued;p.expires=issued+120;p.parent=42;memset(p.key,0xa5,32);strcpy(p.sid,"secret-session");strcpy(p.racks,"7265617065722e657865");return p;}
int main(){
 ATCS_Claims a=lease(1),b=lease(2),c=lease(3);CHECK(atcs_loader_publish(&a));ATCS_LoaderPolicy* held=atcs_loader_acquire();CHECK(held&&held->policy.issued==1&&g_loaderReaders==1);
 CHECK(atcs_loader_publish(&b));CHECK(atcs_loader_publish(&c));CHECK(allocations==3&&frees==0);CHECK(held->policy.issued==1);CHECK(held->policy.sid[0]==0);for(unsigned i=0;i<32;i++)CHECK(held->policy.key[i]==0);
 atcs_loader_release();CHECK(frees==0);atcs_loader_collect();CHECK(frees==2&&g_loaderRetired==NULL);CHECK(atcs_loader_publish(NULL));CHECK(frees==3);
 {ATCS_LoaderRead stopped;CHECK(stopped.snapshot==NULL&&g_loaderReaders==1);}CHECK(g_loaderReaders==0);
 CHECK(atcs_loader_publish(&a));failAllocation=true;CHECK(!atcs_loader_publish(&b));failAllocation=false;{ATCS_LoaderRead old;CHECK(old.snapshot->policy.issued==1);}CHECK(atcs_loader_publish(NULL));
 std::atomic<bool> done(false),bad(false);std::vector<std::thread> readers;
 for(unsigned k=0;k<4;k++)readers.emplace_back([&](){while(!done.load()){ATCS_LoaderRead read;if(read.snapshot){auto p=&read.snapshot->policy;uint64_t issued=p->issued;std::this_thread::yield();if(p->expires!=issued+120||p->policy!=1||p->parent!=42||p->key[0]!=0||p->sid[0]!=0||strcmp(p->racks,"7265617065722e657865"))bad=true;}}});
 for(unsigned i=10;i<20010;i++){ATCS_Claims current=lease(i);CHECK(atcs_loader_publish(&current));if((i&31)==0)std::this_thread::yield();}
 CHECK(atcs_loader_publish(NULL));done=true;for(auto& t:readers)t.join();atcs_loader_collect();CHECK(!bad);CHECK(g_loaderReaders==0&&g_loaderRetired==NULL&&g_loaderPolicy==NULL);CHECK(allocations==frees);
 printf("PASS production immutable-policy lifetime: %u checks, %u snapshots, 4 concurrent readers\n",checks,(unsigned)allocations);
}
