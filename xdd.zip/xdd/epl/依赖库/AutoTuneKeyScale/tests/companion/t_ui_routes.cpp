/* Exact production per-HWND routing and subclass helpers. Win32/property/message
boundaries are explicit deterministic substitutes; no Windows runtime claim. */
#include <stdio.h>
#include <thread>
#include <atomic>
#include <wchar.h>
#include <mutex>
#include <condition_variable>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <setjmp.h>
#define CALLBACK
#define WINAPI
#define AT_XHH_MANAGED 1
#define LOG(...) ((void)0)
typedef void* HHOOK;typedef void* HINSTANCE;typedef int32_t LONG;typedef uint32_t DWORD;typedef unsigned int UINT;typedef void* HWND;typedef void* HANDLE;typedef intptr_t LPARAM;typedef uintptr_t WPARAM;typedef intptr_t LRESULT;typedef intptr_t LONG_PTR;typedef int BOOL;typedef LRESULT(*WNDPROC)(HWND,UINT,WPARAM,LPARAM);
#define HC_ACTION 0
#define PM_REMOVE 1
#define WH_GETMESSAGE 3
struct MSG {HWND hwnd;UINT message;WPARAM wParam;LPARAM lParam;};
typedef LRESULT(*HOOKPROC)(int,WPARAM,LPARAM);
#define GWLP_WNDPROC 0
#define GW_OWNER 0
#define FALSE 0
#define TRUE 1
#define WM_NCDESTROY 0x82
#define UIQ 16
#define UIPH_FREE 0
#define UIPH_POST 1
#define UIPH_RUN 2
#define UIPH_DONE 3
#define UIGEN_MASK 0x07ffffffUL
#define UIW(g,p) ((LONG)((((unsigned long)(g)&UIGEN_MASK)<<2)|(unsigned long)(p)))
#define UIPH(w) ((LONG)(w)&3)
#define UIGEN(w) ((LONG)(((unsigned long)(w)>>2)&UIGEN_MASK))
static volatile LONG* interceptWord=NULL;static void(*interceptAction)()=NULL;
static LONG InterlockedIncrement(volatile LONG*p){return __atomic_add_fetch(p,1,__ATOMIC_SEQ_CST);}static LONG InterlockedDecrement(volatile LONG*p){return __atomic_sub_fetch(p,1,__ATOMIC_SEQ_CST);}static LONG InterlockedExchange(volatile LONG*p,LONG n){return __atomic_exchange_n(p,n,__ATOMIC_SEQ_CST);}static LONG InterlockedCompareExchange(volatile LONG*p,LONG n,LONG c){__atomic_compare_exchange_n(p,&c,n,false,__ATOMIC_SEQ_CST,__ATOMIC_SEQ_CST);if(p==interceptWord&&n==0&&interceptAction){void(*action)()=interceptAction;interceptAction=NULL;action();}return c;}
static void* InterlockedCompareExchangePointer(void* volatile*p,void*n,void*c){__atomic_compare_exchange_n(p,&c,n,false,__ATOMIC_SEQ_CST,__ATOMIC_SEQ_CST);return c;}static void* InterlockedExchangePointer(void* volatile*p,void*n){return __atomic_exchange_n(p,n,__ATOMIC_SEQ_CST);}
static int index(HWND h){return (int)(uintptr_t)h;}static HWND handle(int n){return (HWND)(uintptr_t)n;}
static std::atomic<WNDPROC> wnd[300];static std::atomic<HANDLE> properties[300],installProperties[300];static DWORD windowThreads[300];static int valid[300],unicode[300];static HWND picked=0;static int sets=0,wideCalls=0,ansiCalls=0,propertyFail=0,subclassFail=0,raceAttach=0;
static std::atomic<HANDLE>& property(HWND h,const wchar_t* name){return wcsstr(name,L"UIInstall")?installProperties[index(h)]:properties[index(h)];}
static HANDLE GetPropW(HWND h,const wchar_t* name){return property(h,name).load();}static BOOL SetPropW(HWND h,const wchar_t* name,HANDLE p){if(propertyFail)return 0;property(h,name)=p;return 1;}static HANDLE RemovePropW(HWND h,const wchar_t* name){return property(h,name).exchange(NULL);}
#include "companion_ui_routes.h"
struct C{void*vtbl;};static C ctl={0};
static struct {C*c;unsigned id;double v;const char*family;HWND volatile targetWindow;ATUI_Route* volatile targetRoute;volatile LONG targetThread;volatile LONG word;volatile LONG faulted;LONG pauseEpoch;}g_uiQ[UIQ];
static UINT g_uiMsg=0;static HWND g_uiWnd=0;static WNDPROC g_uiOrig=0;static int g_uiWndUni=1;static DWORD g_uiWndTid=0;static LONG g_ejecting=0,g_inHook=0,g_uiProbing=0,g_uiExecuting=0;static DWORD g_uiProbeTid=0;static jmp_buf g_uiJb;static int writes=0,policy=1;static const char*lastFamily=0;
static int seen1=0,seen2=0;
static LRESULT CALLBACK at_wndproc(HWND,UINT,WPARAM,LPARAM);
static LRESULT first(HWND,UINT,WPARAM,LPARAM){++seen1;return 11;}
static LRESULT second(HWND,UINT,WPARAM,LPARAM){++seen2;return 22;}
static LRESULT later(HWND h,UINT m,WPARAM w,LPARAM l){return at_wndproc(h,m,w,l);}
static int IsWindow(HWND h){int i=index(h);return i>0&&i<300&&valid[i];}static int IsWindowVisible(HWND){return 1;}static HWND GetWindow(HWND,int){return 0;}static int IsWindowUnicode(HWND h){return unicode[index(h)];}
static LONG_PTR GetWindowLongPtrW(HWND h,int){return (LONG_PTR)wnd[index(h)].load();}static LONG_PTR GetWindowLongPtrA(HWND h,int v){return GetWindowLongPtrW(h,v);}
static int installPolicy=1,hookFailure=0,postFailure=0,installMode=0,injectWrong=0;static LRESULT injectedResult=0;static unsigned chainCalls=0,hookInstalls=0,hookRemoves=0;static HOOKPROC activeHook=NULL;static DWORD activeHookTid=0;static MSG queued={};static HOOKPROC queuedHook=NULL;static DWORD queuedTid=0;static bool queuePending=false;static std::atomic<DWORD> ticks(1);static std::mutex installMutex;static std::condition_variable installCv;static bool installEntered=false,releaseInstall=false;static std::thread delayedInstall;
static thread_local DWORD fakeTid=77;
static LONG_PTR SetWindowLongPtrW(HWND h,int,LONG_PTR p){++sets;if(subclassFail)return 0;if(raceAttach||injectWrong){wnd[index(h)]=second;raceAttach=0;}if(installMode==2||installMode==5){std::unique_lock<std::mutex> lock(installMutex);installEntered=true;installCv.notify_all();installCv.wait(lock,[]{return releaseInstall;});}WNDPROC old=wnd[index(h)].exchange((WNDPROC)p);if(injectWrong&&fakeTid!=windowThreads[index(h)]){injectWrong=0;injectedResult=wnd[index(h)](h,7,0,0);}return (LONG_PTR)old;}
static LONG_PTR SetWindowLongPtrA(HWND h,int k,LONG_PTR p){return SetWindowLongPtrW(h,k,p);}
static LRESULT CallWindowProcW(WNDPROC p,HWND h,UINT m,WPARAM w,LPARAM l){if(m!=0x9a)++wideCalls;return p(h,m,w,l);}static LRESULT CallWindowProcA(WNDPROC p,HWND h,UINT m,WPARAM w,LPARAM l){if(m!=0x9a)++ansiCalls;return p(h,m,w,l);}
static LRESULT DefWindowProcW(HWND,UINT,WPARAM,LPARAM){return -1;}static LRESULT DefWindowProcA(HWND,UINT,WPARAM,LPARAM){return -2;}
/* Actual marker layout; map/reference ownership is tested separately by the
   handler-lifetime fixture. Here only the recovery-frame call boundary is replaced. */
#include "agent_handler_guard_type.inc"
static HandlerGuardMark handler_guard_mark(){HandlerGuardMark mark={0x123,1,2};return mark;}
static unsigned transactionCleanups=0;
static void handler_transaction_cleanup(HandlerGuardMark mark){if(mark.epoch!=0x123||mark.uiDepth!=1||mark.workerDepth!=2||!g_uiProbing||g_uiExecuting!=1)abort();++transactionCleanups;}
static void*handler_of(C*){return 0;}static int agent_policy_ui_allowed(const void*,const char*){return policy;}static void v3set_body(C*,void*,unsigned,double,const char* family,int requiresHandler,LONG pauseEpoch);
static DWORD GetCurrentThreadId(){return fakeTid;}static DWORD GetTickCount(){return ticks.load();}static void SetLastError(DWORD){}static DWORD GetLastError(){return 0;}static UINT RegisterWindowMessageW(const wchar_t* name){return wcsstr(name,L"ROUTE_INSTALL")?0x9a:0x99;}
static void EnumThreadWindows(DWORD tid,BOOL(*pick)(HWND,LPARAM),LPARAM p){if(picked){if(!windowThreads[index(picked)])windowThreads[index(picked)]=tid;pick(picked,p);}}
#define UILOG_MS 60000
typedef struct {DWORD at;LONG left;}UiLogGate;static UiLogGate g_ulNoWnd,g_ulResub;static DWORD g_ulTid=0;
static DWORD GetCurrentProcessId(){return 99;}static DWORD GetWindowThreadProcessId(HWND h,DWORD* pid){if(pid)*pid=IsWindow(h)?99:0;return IsWindow(h)?windowThreads[index(h)]:0;}
static int agent_ui_install_allowed(){return !g_ejecting&&installPolicy;}
static HHOOK SetWindowsHookExW(int kind,HOOKPROC proc,HINSTANCE module,DWORD thread){if(hookFailure)return NULL;if(kind!=WH_GETMESSAGE||module)abort();++hookInstalls;activeHook=proc;activeHookTid=thread;return (HHOOK)1;}
static void runQueued();
static BOOL UnhookWindowsHookEx(HHOOK){++hookRemoves;activeHook=NULL;if(installMode==5){{std::lock_guard<std::mutex> lock(installMutex);releaseInstall=true;}installCv.notify_all();delayedInstall.join();}return 1;}
static LRESULT CallNextHookEx(HHOOK,int,WPARAM,LPARAM){++chainCalls;return 0;}
static void runQueued(){if(!queuePending)return;MSG message=queued;HOOKPROC proc=queuedHook;DWORD tid=queuedTid;queuePending=false;DWORD previous=fakeTid;fakeTid=tid;proc(HC_ACTION,PM_REMOVE,(LPARAM)&message);if(wnd[index(message.hwnd)])wnd[index(message.hwnd)](message.hwnd,message.message,message.wParam,message.lParam);if(injectWrong){injectWrong=0;injectedResult=wnd[index(message.hwnd)](message.hwnd,7,0,0);}fakeTid=previous;}
static BOOL PostMessageW(HWND h,UINT m,WPARAM w,LPARAM l){if(postFailure)return 0;queued={h,m,w,l};queuedHook=activeHook;queuedTid=activeHookTid;queuePending=true;if(installMode==2||installMode==5){delayedInstall=std::thread(runQueued);std::unique_lock<std::mutex> lock(installMutex);installCv.wait(lock,[]{return installEntered;});}return 1;}
static void Sleep(DWORD n){ticks+=n;if(installMode==3)g_ejecting=1;if(installMode==4)installPolicy=0;if(installMode!=1&&installMode!=2&&installMode!=5)runQueued();}
#include "companion_ui_install.h"
#include "agent_ui_routes.inc"
static std::mutex uiTestMutex;static std::condition_variable uiTestCv;static int overlapping=0;static bool firstEntered=false,releaseFirst=false;
static void v3set_body(C*,void*,unsigned,double,const char* family,int requiresHandler,LONG pauseEpoch){
 if(requiresHandler!=1)abort();
 if(overlapping){std::unique_lock<std::mutex> lock(uiTestMutex);firstEntered=true;uiTestCv.notify_all();uiTestCv.wait(lock,[]{return releaseFirst;});}
 ++writes;lastFamily=family;
}
static unsigned checks=0;
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL ui routes line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static void makeWindow(int id,WNDPROC p,int uni=1){wnd[id]=p;valid[id]=1;unicode[id]=uni;properties[id]=0;installProperties[id]=0;windowThreads[id]=0;}
static void set_target(int slot,HWND window){ATUI_Route* route=atui_find(window);InterlockedExchangePointer((void* volatile*)&g_uiQ[slot].targetWindow,window);InterlockedExchangePointer((void* volatile*)&g_uiQ[slot].targetRoute,route);InterlockedExchange(&g_uiQ[slot].targetThread,route?(LONG)route->thread:0);}
static void publish_future(){set_target(0,handle(7));InterlockedExchange(&g_uiQ[0].word,UIW(21,UIPH_POST));}
static void post(){set_target(0,g_uiWnd);fakeTid=g_uiWndTid;g_uiQ[0].c=&ctl;g_uiQ[0].id=2;g_uiQ[0].family="waves";g_uiQ[0].word=UIW(1,UIPH_POST);}
int main(){
 makeWindow(1,first);makeWindow(2,second,0);picked=handle(1);CHECK(ui_attach(10));CHECK(g_uiRouteCount==1);CHECK(wnd[1]==at_wndproc);CHECK(wnd[1](handle(1),7,0,0)==11);CHECK(wideCalls==1&&ansiCalls==0);
 ATUI_Route* oldRoute=atui_find(handle(1));CHECK(atui_live(oldRoute));wnd[1]=later;int prior=sets;picked=handle(2);CHECK(ui_attach(20));CHECK(g_uiRouteCount==2);CHECK(wnd[1](handle(1),7,0,0)==11);CHECK(wnd[2](handle(2),7,0,0)==22);CHECK(ansiCalls==1&&wideCalls==2);CHECK(oldRoute->original==first);CHECK(atui_thread_observed(10)&&atui_thread_observed(20)&&!atui_thread_observed(30));
 picked=handle(1);CHECK(ui_attach(10));CHECK(sets==prior+1);CHECK(wnd[1]==later);CHECK(wnd[1](handle(1),7,0,0)==11);
 ui_detach();CHECK(!g_uiWnd&&!g_uiWndTid);CHECK(wnd[1]==later);CHECK(at_wndproc(handle(1),7,0,0)==11);CHECK(ui_attach(10));CHECK(sets==prior+1);CHECK(g_uiRouteCount==2);
 post();int before=writes;fakeTid=20;at_wndproc(handle(2),g_uiMsg,16,0);CHECK(UIPH(g_uiQ[0].word)==UIPH_POST&&writes==before);fakeTid=77;at_wndproc(handle(1),g_uiMsg,16,0);CHECK(UIPH(g_uiQ[0].word)==UIPH_POST&&writes==before);fakeTid=10;ATUI_Route* right=atui_find(handle(1));InterlockedExchangePointer((void* volatile*)&g_uiQ[0].targetRoute,atui_find(handle(2)));at_wndproc(handle(1),g_uiMsg,16,0);CHECK(UIPH(g_uiQ[0].word)==UIPH_POST&&writes==before);InterlockedExchangePointer((void* volatile*)&g_uiQ[0].targetRoute,right);wnd[1](handle(1),g_uiMsg,16,0);CHECK(writes==before+1&&lastFamily&&!strcmp(lastFamily,"waves"));CHECK(UIPH(g_uiQ[0].word)==UIPH_DONE);
 g_ejecting=1;post();wnd[1](handle(1),g_uiMsg,16,0);CHECK(writes==before+1);CHECK(wnd[1](handle(1),7,0,0)==11);ui_detach();CHECK(!ui_attach(10));g_ejecting=0;
 CHECK(wnd[1](handle(1),WM_NCDESTROY,0,0)==11);CHECK(oldRoute->destroyed&&!properties[1]);makeWindow(1,second);picked=handle(1);CHECK(!ui_attach(10));CHECK(wnd[1]==second&&oldRoute->original==first);CHECK(at_wndproc(handle(1),7,0,0)==11);
 /* A third party can swallow NCDESTROY. A new window has no old epoch marker;
    refusal does not replace the retained original or wrap the new procedure. */
 ATUI_Route* secondRoute=atui_find(handle(2));makeWindow(2,first,0);picked=handle(2);CHECK(!ui_attach(20));CHECK(wnd[2]==first&&secondRoute->original==second);CHECK(!atui_live(secondRoute));
 makeWindow(3,first);picked=handle(3);propertyFail=1;CHECK(!ui_attach(30));CHECK(wnd[3]==first&&g_uiRouteCount==2);propertyFail=0;
 subclassFail=1;CHECK(!ui_attach(30));CHECK(!atui_find(handle(3))&&!properties[3]&&wnd[3]==first);subclassFail=0;
 makeWindow(4,first);picked=handle(4);raceAttach=1;CHECK(ui_attach(40));CHECK(wnd[4]==at_wndproc&&atui_find(handle(4))->original==second);CHECK(wnd[4](handle(4),7,0,0)==22);
 makeWindow(5,at_wndproc);picked=handle(5);CHECK(!ui_attach(50));CHECK(!atui_find(handle(5)));
 /* Two real host threads overlap while the first parameter transaction is blocked.
    The second is explicitly skipped, cannot overwrite the recovery frame, and
    may retry after completion. It must not be repeated on the worker. */
 makeWindow(6,first);makeWindow(7,second);picked=handle(6);CHECK(ui_attach(60));picked=handle(7);CHECK(ui_attach(70));
 for(int k=0;k<2;k++){set_target(k,handle(6+k));g_uiQ[k].c=&ctl;g_uiQ[k].id=k+1;g_uiQ[k].family="waves";g_uiQ[k].faulted=0;g_uiQ[k].word=UIW(2,UIPH_POST);}
 overlapping=1;before=writes;
 std::thread a([]{fakeTid=60;at_wndproc(handle(6),g_uiMsg,32,0);});
 {std::unique_lock<std::mutex> lock(uiTestMutex);uiTestCv.wait(lock,[]{return firstEntered;});}
 std::thread b([]{fakeTid=70;at_wndproc(handle(7),g_uiMsg,33,0);});b.join();
 CHECK(UIPH(g_uiQ[1].word)==UIPH_DONE&&g_uiQ[1].faulted==2);CHECK(g_uiExecuting==1&&g_uiProbing==1&&g_uiProbeTid==60);CHECK(writes==before);
 {std::lock_guard<std::mutex> lock(uiTestMutex);releaseFirst=true;}uiTestCv.notify_all();a.join();
 CHECK(writes==before+1&&!g_uiExecuting&&!g_uiProbing&&g_inHook==0);CHECK(UIPH(g_uiQ[0].word)==UIPH_DONE&&!g_uiQ[0].faulted);
 overlapping=0;g_uiQ[1].word=UIW(3,UIPH_POST);g_uiQ[1].faulted=0;fakeTid=70;at_wndproc(handle(7),g_uiMsg,49,0);
 CHECK(writes==before+2&&UIPH(g_uiQ[1].word)==UIPH_DONE&&!g_uiQ[1].faulted);fakeTid=77;
 /* Old worker-side installation forwarded A while setter was returning B.
    Owner installation publishes B before the next dispatch, including this race. */
 makeWindow(8,first);picked=handle(8);injectWrong=1;CHECK(ui_attach(80));CHECK(injectedResult==22&&atui_find(handle(8))->original==second);CHECK(windowThreads[8]==80);
 /* Pending timeout cannot install later, even if an already-captured hook call arrives. */
 makeWindow(9,first);picked=handle(9);installMode=1;int beforeSets=sets;LONG requestAt=g_uiInstallCount;CHECK(!ui_attach(90));CHECK(sets==beforeSets&&g_uiInstalls[requestAt].phase==ATUI_INSTALL_CANCELLED&&!installProperties[9]);runQueued();CHECK(sets==beforeSets&&!atui_find(handle(9))&&wnd[9]==first);installMode=0;
 /* CLAIMED timeout keeps descriptor/observer alive but never selects a write window.
    A new timely descriptor may safely activate the same immutable original. */
 makeWindow(10,first);picked=handle(10);installMode=2;installEntered=releaseInstall=false;CHECK(!ui_attach(100));CHECK(!g_uiWnd&&g_uiInstalls[g_uiInstallCount-1].abandoned);{std::lock_guard<std::mutex> lock(installMutex);releaseInstall=true;}installCv.notify_all();delayedInstall.join();installMode=0;ATUI_Route* late=atui_find(handle(10));CHECK(late&&atui_epoch_live(late)&&!atui_live(late)&&late->original==first);CHECK(at_wndproc(handle(10),7,0,0)==11);beforeSets=sets;CHECK(ui_attach(100));CHECK(atui_live(late)&&g_uiWnd==handle(10)&&sets==beforeSets);
 makeWindow(11,first);picked=handle(11);installMode=3;beforeSets=sets;CHECK(!ui_attach(110));CHECK(sets==beforeSets&&wnd[11]==first&&!g_uiWnd);installMode=0;g_ejecting=0;
 makeWindow(12,first);picked=handle(12);installMode=4;beforeSets=sets;CHECK(!ui_attach(120));CHECK(sets==beforeSets&&wnd[12]==first);installMode=0;installPolicy=1;
 makeWindow(13,first);picked=handle(13);hookFailure=1;beforeSets=sets;CHECK(!ui_attach(130));CHECK(sets==beforeSets&&!installProperties[13]);hookFailure=0;
 makeWindow(14,first);picked=handle(14);postFailure=1;CHECK(!ui_attach(140));CHECK(wnd[14]==first&&!installProperties[14]);postFailure=0;
 MSG foreign={handle(14),g_uiInstallMessage,(WPARAM)(g_uiInstallCount+10),0};unsigned chainsBefore=chainCalls;atui_install_hook(-1,PM_REMOVE,(LPARAM)&foreign);atui_install_hook(HC_ACTION,0,(LPARAM)&foreign);atui_install_hook(HC_ACTION,PM_REMOVE,(LPARAM)&foreign);CHECK(chainCalls==chainsBefore+3&&wnd[14]==first);
 CHECK(hookInstalls==hookRemoves);CHECK(g_uiInstallMessage!=g_uiMsg);
 makeWindow(15,first);picked=handle(15);installMode=5;installEntered=releaseInstall=false;CHECK(!ui_attach(150));ATUI_Route* deadlineLate=atui_find(handle(15));CHECK(deadlineLate&&atui_epoch_live(deadlineLate)&&!atui_live(deadlineLate)&&!g_uiWnd);installMode=0;beforeSets=sets;CHECK(ui_attach(150));CHECK(atui_live(deadlineLate)&&sets==beforeSets);
 /* A forged future generation cannot validate against FREE's prior context. */
 set_target(0,handle(6));g_uiQ[0].c=&ctl;g_uiQ[0].family="waves";g_uiQ[0].word=UIW(20,UIPH_FREE);interceptWord=&g_uiQ[0].word;interceptAction=publish_future;before=writes;fakeTid=60;at_wndproc(handle(6),g_uiMsg,336,0);CHECK(g_uiQ[0].word==UIW(21,UIPH_POST)&&writes==before);CHECK(g_uiQ[0].targetWindow==handle(7));fakeTid=70;at_wndproc(handle(7),g_uiMsg,336,0);CHECK(writes==before+1&&UIPH(g_uiQ[0].word)==UIPH_DONE);fakeTid=77;interceptWord=NULL;
 /* Late owner callbacks on different threads reserve disjoint immutable routes. */
 LONG routesBefore=g_uiRouteCount;for(int i=16;i<48;i++)makeWindow(i,i<32?first:second);
 std::thread routesA([]{for(int i=16;i<32;i++)if(!atui_prepare(handle(i),first,1,150))abort();});std::thread routesB([]{for(int i=32;i<48;i++)if(!atui_prepare(handle(i),second,1,160))abort();});routesA.join();routesB.join();CHECK(g_uiRouteCount==routesBefore+32);for(int i=16;i<48;i++)CHECK(atui_find(handle(i))&&atui_find(handle(i))->original==(i<32?first:second));
 for(int i=48;g_uiRouteCount<ATUI_MAX_ROUTES;i++){makeWindow(i,first);CHECK(atui_prepare(handle(i),first,1,(DWORD)i)!=NULL);}
 makeWindow(299,first);picked=handle(299);prior=sets;CHECK(!ui_attach(299));CHECK(sets==prior&&g_uiRouteCount==ATUI_MAX_ROUTES);CHECK(oldRoute->original==first&&secondRoute->original==second);CHECK(at_wndproc(handle(1),7,0,0)==11);
 while(g_uiInstallCount<ATUI_MAX_INSTALLS){prior=sets;CHECK(!ui_attach(299));CHECK(sets==prior);}LONG installLimit=g_uiInstallCount;unsigned hooksBefore=hookInstalls;CHECK(!ui_attach(299));CHECK(g_uiInstallCount==installLimit&&hookInstalls==hooksBefore&&g_uiInstallCount==ATUI_MAX_INSTALLS);CHECK(hookInstalls==hookRemoves);
 printf("PASS extracted per-window immutable forwarding: %u checks\n",checks);return 0;
}
