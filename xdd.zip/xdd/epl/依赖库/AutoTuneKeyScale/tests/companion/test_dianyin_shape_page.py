"""Windows 7：电音助手页面报的形状与它实际画出来的像素逐个核对（真实 Chromium 内核），并经宿主真实 EPL 源码裁成窗口区域（端到端）。

Windows 7 的 WebView2 不支持透明背景，宿主在页面里置 window.__DY_SHAPE__=1（见 EPL Edge_电音助手_取页面），页面报出自己画着东西的地方，
宿主用 SetWindowRgn 把窗口裁成这个形状（Edge_电音助手_置形状）。页面照本工程宿主真实的 主播音效_电音页面 拼装（逐项解析那一行：
项目 A 带界面语言包与翻译脚本，项目 B 只有简体中文、不带），再像 Edge_电音助手_取页面 那样置 __DY_SHAPE__；文字取自电音助手模块的 19 语种词条。
核对（简体中文 1、1.25、1.5、1.75、2、2.5、3 倍缩放；19 种语言 1 倍）：
  · 先报形状再报就绪：窗口显示出来时已经裁好；不置 __DY_SHAPE__ 时（Windows 8 起）不报形状、最先报就绪、气泡不改，同原来；
  · 形状经宿主真实的 Edge_电音助手_置形状 执行（GDI 区域按像素建模）后，页面上看得见的像素（不透明度过半）全在窗口区域里，一个也不被裁掉；
  · 区域里透明的地方（Windows 7 上露出浏览器底色）只在电音强度条里（底色即胶囊色），别处一个像素也没有：气泡边上不露底色；
  · 气泡是硬边的（不透明度只有 0 与 255），按设备像素一比一显示；
  · 右键菜单、子菜单打开时并进区域，收起后回到原来的形状；基调修改层开着时整个窗口；电音强度显示、隐藏随之增减；没有脚本错误。
需要 Playwright 与 Chrome（找不到时跳过）。用法（在依赖库根目录）：python3 tests/companion/test_dianyin_shape_page.py [--chrome 路径]
"""
import argparse, atexit, base64, importlib.util, io, json, os, shutil, sys, tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import test_dianyin_layout as L           # noqa: E402  （页面拼装、词条解析；同时把 epl_engine 加进 sys.path）

_spec = importlib.util.spec_from_file_location('host_shape', HERE.parent / 'epl_engine' / 'test_dianyin_shape.py')
host_shape = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(host_shape)
import re                                   # noqa: E402


def host_page_html(lang):
    """按本工程宿主 窗口_音效.主播音效_电音页面 那一行逐项拼出页面（与宿主相同的内容与顺序）：
    字面文本照抄；#CSS_名／#JS_名 资源取 css/名.css、js/名.js；多语言_词典包 取 js/i18n_data.js（宿主按语种取同一份数据）；
    多语言_当前语言 () 取 lang；字体样式（CSS_fonts_xddck_yx）不影响排版，留空（同 test_dianyin_layout.page_html）。"""
    form = (L.EPL / '代码/窗_音效/窗口程序集_窗口_音效.form.e.txt').read_text(encoding='utf-8-sig').replace('\r\n', '\n')
    body = L.syntax.section(form, '主播音效_电音页面')
    line = [x for x in body.split('\n') if x.startswith('赋值 (局_页面, ')]
    assert len(line) == 1, 'page assembly line not found'
    parts = []
    for m in re.finditer(r'多语言_词典包 \(多语言_当前语言 \(\)\)|音效_HTML_解密_返回值 \(#(\w+)\)|CSS_fonts_xddck_yx|多语言_当前语言 \(\)|“([^”]*)”', line[0]):
        token, res, lit = m.group(0), m.group(1), m.group(2)
        if lit is not None:
            parts.append(lit)
        elif res:
            kind, name = res.split('_', 1)
            parts.append((L.ROOT / {'CSS': 'css', 'JS': 'js'}[kind] / (name + ('.css' if kind == 'CSS' else '.js'))).read_text(encoding='utf-8'))
        elif token.startswith('多语言_词典包'):
            parts.append((L.ROOT / 'js/i18n_data.js').read_text(encoding='utf-8'))
        elif token.startswith('多语言_当前语言'):
            parts.append(lang)
        else:
            parts.append('')
    html = ''.join(parts)
    assert html.count('window.__DY_WIN__=1;') == 1 and html.startswith('<!DOCTYPE html>') and html.endswith('</html>'), 'unexpected page assembly'
    return html.replace('<head>', '<head><style>:root{forced-color-adjust:none}</style>', 1)   # 同 test_dianyin_layout.page_html：不跟随系统高对比度


def run_host(msg, size):
    """把页面报的形状交给宿主真实的 Edge_电音助手_置形状：返回窗口区域（numpy 布尔图），没裁剪时为 None。"""
    import numpy as np

    class Grid(host_shape.Shape):          # 区域按整张布尔图建模（像素集合在 2 倍缩放下太慢）
        def create(self, l, t, r, b):
            self.next_handle += 1
            g = np.zeros((size[1], size[0]), bool)
            g[max(t, 0):max(b, 0), max(l, 0):max(r, 0)] = True
            self.regions[self.next_handle] = g
            return self.next_handle

        def combine(self, dest, a, b, mode):
            assert mode == 2
            self.regions[dest] = self.regions[a] | self.regions[b]
            return 3

    m = Grid(client=size)
    m.shape(msg)
    assert not m.leaks(), 'region leak'
    return m.regions[m.set_calls[-1]] if m.set_calls and m.set_calls[-1] else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--chrome')
    args = ap.parse_args()
    try:
        from playwright.sync_api import sync_playwright
        import numpy as np
        from PIL import Image
    except ImportError:
        print('跳过：没有安装 Playwright、numpy 或 Pillow')
        return 0
    chrome = args.chrome or next((c for c in L.CHROME_CANDIDATES if os.path.exists(c)), None)
    if not chrome:
        print('跳过：找不到 Chrome／Edge')
        return 0
    lang_src = (L.EPL / '模块/模块_电音助手.e~/代码/程序集_多语言.static.e.txt').read_text(encoding='utf-8-sig').replace('\r\n', '\n')
    texts19, rack19 = L.parse_table(lang_src, '多语言_文字W_语种'), L.parse_table(lang_src, '多语言_机架文字W_语种')
    zr = rack19['zh-Hans']
    i_rack, i_auto = zr.index('机架联动'), zr.index('自动切换')
    b64 = lambda s: base64.b64encode(s.encode('utf-8')).decode()
    icons = [base64.b64encode(p.read_bytes()).decode() for p in sorted((L.EPL / '模块/模块_电音助手.e~/资源').glob('列表框_图标_*'))]
    checks, failures = 0, []

    def check(name, ok):
        nonlocal checks
        checks += 1
        if not ok:
            failures.append(name)

    tmp = Path(tempfile.mkdtemp(prefix='dyshape_'))
    atexit.register(shutil.rmtree, tmp, ignore_errors=True)
    runs = [('zh-Hans', d) for d in (1, 1.25, 1.5, 1.75, 2, 2.5, 3)] + [(lang, 1) for lang in texts19 if lang != 'zh-Hans']
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=chrome, args=['--no-sandbox'])
        for lang, dpr in runs:
            tag = '%s@%s' % (lang, dpr)
            tv, rv = texts19[lang], rack19[lang]
            texts = {'t': [{'v': b64(v + '\u0000')} for v in tv[:22]], 'rack': b64(rv[i_rack]), 'autoswitch': b64(rv[i_auto]),
                     'keys': [{'v': b64(k)} for k in 'C,C#/Db,D,D#/Eb,E,F,F#/Gb,G,G#/Ab,A,A#/Bb,B'.split(',')], 'scales': [{'v': b64('Major')}, {'v': b64('Minor')}],
                     'players': [{'i': i} for i in icons]}
            state = {'song': b64('刀郎 - 映山红'), 'status': b64(tv[13]), 'key': b64(tv[4] + 'B     ' + tv[5] + 'Minor'), 'sp': -1, 'rk': 1, 'pm': 0, 'pi': 1, 'kc': 12, 'sc': 2}
            ctx = browser.new_context(viewport={'width': 420, 'height': 198}, device_scale_factor=dpr)
            ctx.add_init_script('window.__sent=[];window.chrome=window.chrome||{};window.chrome.webview={postMessage:function(m){window.__sent.push(m)}};')
            page = ctx.new_page()
            errors = []
            page.on('pageerror', lambda e: errors.append(str(e)))
            f = tmp / ('s_%s_%s.html' % (lang, dpr))
            f.write_text(host_page_html(lang).replace('window.__DY_WIN__=1;', 'window.__DY_WIN__=1;window.__DY_SHAPE__=1;', 1), encoding='utf-8')   # 同 Edge_电音助手_取页面
            page.goto(f.as_uri())
            page.wait_for_function('window.__sent.indexOf("XHHDY:ready") >= 0', timeout=8000)
            first = page.evaluate('window.__sent.slice()')
            check(f'{tag}:先报形状再报就绪 {[m[:18] for m in first]}', len(first) == 2 and first[0].startswith('XHHDY:shape:') and first[1] == 'XHHDY:ready')
            page.evaluate('d => { DY.texts(d.t); DY.state(d.s); }', {'t': texts, 's': state})
            page.wait_for_timeout(80)

            def last_shape():
                return [m for m in page.evaluate('window.__sent.slice()') if m.startswith('XHHDY:shape:')][-1][len('XHHDY:shape:'):]

            def verify(name, bar_allowed, extra=None):
                msg = last_shape()
                w, h = (int(v) for v in msg.split(',')[:2])
                region = run_host(msg, (w, h))
                shot = np.array(Image.open(io.BytesIO(page.screenshot(omit_background=True))).convert('RGBA'))
                hh, ww = min(h, shot.shape[0]), min(w, shot.shape[1])
                alpha = shot[:hh, :ww, 3].astype(int)
                if region is None:
                    check(f'{tag}:{name} 宿主裁出了区域', False)
                    return msg
                reg = region[:hh, :ww]
                cut = int(((alpha >= 128) & ~reg).sum())
                exposed = (alpha == 0) & reg
                allowed = np.zeros_like(exposed)
                for r in ([bar_allowed] if bar_allowed else []) + (extra or []):
                    allowed[r[1]:r[3], r[0]:r[2]] = True
                stray = int((exposed & ~allowed).sum())
                check(f'{tag}:{name} 看得见的像素都在窗口区域里（被裁掉 {cut}）', cut == 0)
                check(f'{tag}:{name} 区域里露出底色的只在电音强度条（别处 {stray}）', stray == 0)
                return msg

            def box(sel):
                return page.evaluate('([s, d]) => { const r = document.querySelector(s).getBoundingClientRect(); return [Math.floor(r.left * d), Math.floor(r.top * d), Math.ceil(r.right * d), Math.ceil(r.bottom * d)]; }', [sel, dpr])

            base = verify('无电音强度', None)
            bub = box('.dy-bubble')
            shot = np.array(Image.open(io.BytesIO(page.screenshot(omit_background=True))).convert('RGBA'))
            a = shot[bub[1]:bub[3], bub[0]:bub[2], 3]
            check(f'{tag}:气泡是硬边的（不透明度只有 0 与 255）', set(np.unique(a).tolist()) <= {0, 255})
            page.evaluate('d => DY.state(Object.assign({}, d, { sp: 600 }))', state)
            page.wait_for_timeout(80)
            strip = [min(box('.dy-pill-name')[0], box('.dy-slider')[0]), min(box('.dy-pill-name')[1], box('.dy-slider')[1]),
                     max(box('.dy-pill-value')[2], box('.dy-slider')[2]), max(box('.dy-pill-value')[3], box('.dy-slider')[3])]
            with_bar = verify('有电音强度', strip)
            check(f'{tag}:电音强度显示时形状变大', with_bar != base and len(with_bar) > len(base) - 400)
            page.mouse.click(250, 60, button='right')                       # 气泡上右键：弹出菜单
            page.wait_for_timeout(80)
            check(f'{tag}:菜单弹出', page.evaluate('!document.querySelector(".dy-menu").classList.contains("dy-hidden")'))
            verify('右键菜单', strip)
            page.mouse.move(*page.evaluate('() => { const r = document.querySelector(".dy-menu .dy-sub").getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; }'))
            page.wait_for_timeout(80)
            check(f'{tag}:子菜单弹出', page.evaluate('document.querySelectorAll(".dy-menu.dy-hidden").length === 0'))
            verify('子菜单', strip)
            page.keyboard.press('Escape')
            page.wait_for_timeout(80)
            check(f'{tag}:菜单收起后回到原来的形状', last_shape() == with_bar)
            page.mouse.click(250, 60, button='right')
            page.wait_for_timeout(60)
            page.click('.dy-menu .dy-item')                                # 第一项：添加/报错，打开基调修改层
            page.wait_for_timeout(80)
            w, h = int(420 * dpr + 0.5), int(198 * dpr + 0.5)            # 同页面的 Math.round（Python 的 round 是四舍六入五成双）
            check(f'{tag}:基调修改层开着时整个窗口', last_shape() == '%d,%d,0,0,%d,%d' % (w, h, w, h))
            page.keyboard.press('Escape')
            page.wait_for_timeout(80)
            check(f'{tag}:基调修改层关上后回到原来的形状', last_shape() == with_bar)
            page.evaluate('d => DY.state(d)', state)
            page.wait_for_timeout(80)
            check(f'{tag}:电音强度隐藏后回到没有强度条的形状', last_shape() == base)
            check(f'{tag}:没有脚本错误 {errors}', not errors)
            ctx.close()
        # Windows 8 起：不置 __DY_SHAPE__，同原来
        ctx = browser.new_context(viewport={'width': 420, 'height': 198})
        ctx.add_init_script('window.__sent=[];window.chrome=window.chrome||{};window.chrome.webview={postMessage:function(m){window.__sent.push(m)}};')
        page = ctx.new_page()
        f = tmp / 'plain.html'
        f.write_text(host_page_html('zh-Hans'), encoding='utf-8')
        page.goto(f.as_uri())
        page.wait_for_function('window.__sent.indexOf("XHHDY:ready") >= 0', timeout=8000)
        page.mouse.click(250, 60, button='right')
        page.wait_for_timeout(80)
        sent = page.evaluate('window.__sent.slice()')
        check('透明系统：最先报就绪、从不报形状', sent[0] == 'XHHDY:ready' and not any(m.startswith('XHHDY:shape') for m in sent))
        check('透明系统：气泡与原来相同', page.evaluate('!document.body.classList.contains("dy-shape") && !document.querySelector(".dy-bubble").getAttribute("style")'))
        ctx.close()
        browser.close()
    print(json.dumps({'checks': checks, 'passed': checks - len(failures), 'failures': failures, 'runs': len(runs), 'chrome': chrome}, ensure_ascii=False))
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
