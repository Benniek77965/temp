/* Production parameter writers with explicit plug-in, policy, discovery and
   clock boundaries. This checks call admission, not real VST/audio behavior. */
#include "companion_security.h"
#ifndef __cdecl
#define __cdecl
#endif
#include "vst2_abi.h"
#include "vst3_abi.h"
#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <string>
#include "agent_write_gate_types.inc"
typedef int32_t LONG;
#define LOG(...) ((void)0)
#define V2K_WAVES 0
#define V2K_TPAIN 1
static LONG g_ejecting=0,g_probing=0,g_uiExecuting=0;
static jmp_buf g_jb;
static uint64_t now=0,expiry=100;
static bool installed=true,parentAlive=true,denied=false,expireOnWrite=false,stopOnWrite=false,denyOnWrite=false,postWait=false,faultOnWrite=false;
static unsigned writes=0,begins=0,performs=0,ends=0,reads=0;
static std::string lastFamily;
static std::vector<int> parameterIds;
static V2W discovery2;
static V3Disc discovery3;
static bool haveDiscovery2=false,haveDiscovery3=false,isAntares=false;
static float parameterValues[32];
static double g_fSpeed=-1,g_fRet=-1,g_fHum=-1,g_fNvb=-1;
static int g_fAudio=-1;
/* This suite isolates admission. The separate t_handler_lifetime fixture runs
   the production map/ref ledger; here a stable current binding is a boundary. */
struct CHBinding{void*handler;DWORD ownerTid;};struct HandlerGuardMark{unsigned marker;};
static CHBinding currentBinding;static CHBinding*volatile g_handlerHeld=NULL;
static DWORD g_handlerHeldTid=0;
static DWORD GetCurrentThreadId(){return 1;}
static HandlerGuardMark handler_guard_mark(){HandlerGuardMark mark={1};return mark;}
static void handler_transaction_cleanup(HandlerGuardMark){g_handlerHeld=NULL;g_handlerHeldTid=0;}
static CHBinding*handler_binding_acquire(void*){return currentBinding.handler?&currentBinding:NULL;}
static int handler_binding_current(void*,CHBinding*binding){return binding==&currentBinding&&binding->handler;}
static volatile LONG g_parameterPaused=0,g_parameterEpoch=1;
static LONG InterlockedCompareExchange(volatile LONG* p,LONG value,LONG expected){LONG old=*p;if(old==expected)*p=value;return old;}
static V2W* v2w_find(AEffect*){return haveDiscovery2?&discovery2:NULL;}
static V3Disc* disc_find(IEditController*){return haveDiscovery3?&discovery3:NULL;}
static int ctrl_module_is_antares(IEditController*){if(g_probing){fprintf(stderr,"identity discovery entered an active writer recovery frame\n");exit(1);}return isAntares;}
static void discover_one(IEditController*){}
static void write_scales_union(){}
static void* handler_of(IEditController*){return NULL;}
static int agent_policy_ui_allowed(const void*,const char* family){lastFamily=family?family:"";return installed&&parentAlive&&!denied&&now<expiry;}
static int ui_post(IEditController*,ParamID,double,const char* family=NULL){lastFamily=family?family:"";if(postWait)now+=400;return 0;}
static void plugin_advanced(){if(expireOnWrite)now=expiry;if(stopOnWrite)g_ejecting=1;if(denyOnWrite)denied=true;if(faultOnWrite)longjmp(g_jb,1);}
static void __cdecl setParameter(void*,int32_t id,float value){writes++;parameterIds.push_back(id);parameterValues[id]=value;plugin_advanced();}
static intptr_t __cdecl dispatcher(void*,int32_t,int32_t,intptr_t,void*,float){return 0;}
static tresult WINAPI setNormalized(void*,ParamID id,ParamValue){writes++;parameterIds.push_back((int)id);plugin_advanced();return kResultOk;}
static tresult WINAPI begin(void*,ParamID){begins++;return kResultOk;}
static tresult WINAPI perform(void*,ParamID,ParamValue){performs++;return kResultOk;}
static tresult WINAPI end(void*,ParamID){ends++;return kResultOk;}
/* Synthetic plug-in metadata/readback boundaries: the writers remain exact
   production functions, and production crypto/policy have separate suites. */
static void v2_feel_find(AEffect*,int*r,int*h,int*n,int*a){*r=3;*h=4;*n=5;*a=6;}
static void gp2_disp(AEffect*,int,char*out,int){reads++;out[0]=0;}
static double gp2_param(AEffect*,int id){reads++;return parameterValues[id];}
static void trim(char*){}
static void norm(const char*s,char*out,int cap){snprintf(out,cap,"%s",s);}
static int scale_same(const char*a,const char*b){return !strcmp(a,b);}
static int key_to_pc(const char*s){return !strcmp(s,"D")?2:0;}
static int scale_name_to_index(const char*const*,const char*){return 1;}
static double scale_to_value_idx(int){return .5;}
static const char*const WAVES_ROOTS[]={"C","D"};static const int WAVES_NROOT=2;
static const char*const TPAIN_ROOTS[]={"C","D"};static const int TPAIN_NROOT=2;
static const char*const WAVES_SCALES[]={"Major","Minor"};static const int WAVES_NSCALE=2;
static const char*const TPAIN_SCALES[]={"Major","Minor"};static const int TPAIN_NSCALE=2;
static const char*const SCALES_STD[]={"Major","Minor"};
#include "agent_write_gate.inc"
static unsigned checks=0;
#define CHECK(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL write gate line%d: %s\n",__LINE__,#x);exit(1);}}while(0)
static void reset(){now=0;expiry=100;g_ejecting=0;g_probing=0;g_uiExecuting=0;installed=parentAlive=true;denied=expireOnWrite=stopOnWrite=denyOnWrite=postWait=faultOnWrite=false;writes=begins=performs=ends=reads=0;lastFamily.clear();parameterIds.clear();memset(parameterValues,0,sizeof parameterValues);memset(&discovery2,0,sizeof discovery2);memset(&discovery3,0,sizeof discovery3);haveDiscovery2=haveDiscovery3=isAntares=false;g_fSpeed=g_fRet=g_fHum=g_fNvb=-1;g_fAudio=-1;}
int main(){
 AEffect effect={};effect.dispatcher=dispatcher;effect.setParameter=setParameter;
 IEditControllerVtbl table={};table.setParamNormalized=setNormalized;IEditController controller={&table};
 IComponentHandlerVtbl handlerTable={};handlerTable.beginEdit=begin;handlerTable.performEdit=perform;handlerTable.endEdit=end;IComponentHandler handler={&handlerTable};currentBinding.handler=&handler;currentBinding.ownerTid=1;
 reset();g_ejecting=1;CHECK(!v2set(&effect,2,.5f));v3set_body(&controller,&handler,2,.5,"antares");CHECK(writes==0&&begins==0);
 reset();CHECK(v2set(&effect,2,.5f));CHECK(writes==1);
 reset();v3set_body(&controller,&handler,2,.5,"waves");CHECK(writes==1&&begins==1&&performs==1&&ends==1);
 reset();g_uiExecuting=1;v3set(&controller,NULL,2,.5,"waves");CHECK(writes==0&&g_uiExecuting==1);
 reset();v3set(&controller,NULL,2,.5,"waves");CHECK(writes==1&&g_uiExecuting==0);
 reset();haveDiscovery3=true;discovery3.isWaves=1;discovery3.haveK=1;discovery3.keySteps=11;discovery3.keyId=2;faultOnWrite=true;
 CHECK(!do_set_vst3_one(&controller,2,"",.5));CHECK(writes==1&&g_uiExecuting==0&&g_probing==0);
 faultOnWrite=false;CHECK(do_set_vst3_one(&controller,2,"",.5));CHECK(writes==2&&g_uiExecuting==0);
 reset();haveDiscovery3=true;discovery3.isWaves=1;discovery3.haveK=1;discovery3.keySteps=11;g_uiExecuting=1;
 CHECK(do_set_vst3_one(&controller,2,"",.5));CHECK(writes==0&&g_uiExecuting==1);
 reset();expireOnWrite=true;v3set_body(&controller,&handler,2,.5,"waves");CHECK(begins==1&&performs==1&&ends==1);v3set_body(&controller,&handler,3,.5,"waves");
#if AT_XHH_MANAGED
 CHECK(writes==1&&begins==1&&ends==1);CHECK(lastFamily=="waves");
 for(unsigned reason=0;reason<4;reason++){reset();if(reason==0)installed=false;else if(reason==1)parentAlive=false;else if(reason==2)denied=true;else now=expiry;CHECK(!v2set(&effect,2,.5f));v3set_body(&controller,&handler,2,.5,"waves");CHECK(writes==0&&begins==0);}
 reset();postWait=true;v3set(&controller,&handler,2,.5,"waves");CHECK(writes==0&&now==400);CHECK(lastFamily=="waves");
 reset();v3set(&controller,NULL,2,.5,"tpain");CHECK(writes==1&&lastFamily=="tpain");
 reset();v3set(&controller,NULL,2,.5,"antares");CHECK(writes==1&&lastFamily=="antares");
 reset();haveDiscovery3=true;discovery3.haveK=1;discovery3.keySteps=11;discovery3.keyId=2;isAntares=true;CHECK(do_set_vst3_one(&controller,2,"",.5));CHECK(writes==1&&lastFamily=="antares");
 for(unsigned action=0;action<3;action++){
  reset();expireOnWrite=action==0;stopOnWrite=action==1;denyOnWrite=action==2;g_fRet=g_fHum=g_fNvb=.5;g_fAudio=2;
  CHECK(do_set_vst2_one(&effect,WAVES_SCALES,2,"Minor",.5));CHECK(writes==1);CHECK(parameterIds[0]==2);
 }
 for(unsigned kind=V2K_WAVES;kind<=V2K_TPAIN;kind++){
  reset();haveDiscovery2=true;discovery2.kind=(int)kind;discovery2.rootIdx=0;discovery2.scaleIdx=1;discovery2.speedIdx=2;discovery2.transIdx=3;discovery2.vibIdx=4;discovery2.isTuner=1;expireOnWrite=true;g_fSpeed=g_fHum=g_fNvb=.5;
  v2w_apply(&effect,&discovery2,2,"Minor");CHECK(writes==1);CHECK(lastFamily==(kind==V2K_TPAIN?"tpain":"waves"));
 }
 reset();denied=true;CHECK(!v2w_set_checked(&effect,2,1,2,"Minor","Scale"));CHECK(writes==0&&reads==0);
#else
 CHECK(writes==2&&begins==2&&ends==2);
 reset();now=expiry;denied=true;installed=parentAlive=false;CHECK(v2set(&effect,2,.5f));v3set_body(&controller,&handler,2,.5,"waves");CHECK(writes==2&&begins==1&&ends==1);
 reset();stopOnWrite=true;g_fRet=g_fHum=g_fNvb=.5;g_fAudio=2;CHECK(do_set_vst2_one(&effect,WAVES_SCALES,2,"Minor",.5));CHECK(writes==1);
#endif
 reset();g_fRet=g_fHum=g_fNvb=.5;g_fAudio=2;CHECK(do_set_vst2_one(&effect,WAVES_SCALES,2,"Minor",.5));CHECK(writes==6);
 reset();haveDiscovery2=true;discovery2.kind=V2K_WAVES;discovery2.rootIdx=0;discovery2.scaleIdx=1;discovery2.speedIdx=2;discovery2.transIdx=3;discovery2.vibIdx=4;discovery2.isTuner=1;g_fSpeed=g_fHum=g_fNvb=.5;v2w_apply(&effect,&discovery2,2,"Minor");CHECK(writes==5);
 printf("PASS extracted parameter write admission managed=%d: %u checks\n",AT_XHH_MANAGED,checks);
}
