#!/usr/bin/env python3
"""Run the source-extracted Linux C regression suite without changing the source tree.

Example:
    python3 tests/run_regression.py --report-dir /absolute/path/to/results

Windows/Wine integration tests (w_*) are separate and are not counted here.
The legacy t_fresh output file is relocated inside the disposable test copy;
its assertions and extract.py invocation are preserved.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def run(command: list[str], cwd: Path, timeout: int) -> tuple[int, str]:
    try:
        result = subprocess.run(command, cwd=cwd, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=timeout)
        return result.returncode, result.stdout.decode("utf-8", errors="backslashreplace")
    except subprocess.TimeoutExpired as error:
        output = error.stdout or b""
        return 124, output.decode("utf-8", errors="backslashreplace") + "\nTIMEOUT\n"
    except OSError as error:
        return 127, str(error) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--report-dir", type=Path,
                        help="Optional output directory, outside the source tree.")
    parser.add_argument("--cc", default="gcc", help="Native C compiler (default: gcc).")
    parser.add_argument("--timeout", type=int, default=60, help="Seconds per compile or test.")
    args = parser.parse_args()
    source = args.source_root.resolve()
    report = args.report_dir.resolve() if args.report_dir else None
    if args.timeout < 1:
        parser.error("--timeout must be positive")
    if report is not None and (report == source or source in report.parents):
        parser.error("--report-dir must be outside the source tree")
    expected = [source / "combined/at_agent.cpp",
                source / "vst3/cpp/AutoTune_KeyScale_Controller.cpp",
                source / "tests/scale_synonym/extract.py"]
    for path in expected:
        if not path.is_file():
            parser.error(f"Required source missing: {path}")
    source_hashes = {}
    fixture_adjustments = []
    logs: list[str] = []
    tests: list[dict[str, object]] = []
    extraction = 1
    with tempfile.TemporaryDirectory(prefix="at-keyscale-regression-") as temporary:
        snapshot = Path(temporary) / "source"
        shutil.copytree(source, snapshot)
        source_hashes = {str(path.relative_to(source)):
                         hashlib.sha256((snapshot / path.relative_to(source)).read_bytes()).hexdigest()
                         for path in expected}
        suite = snapshot / "tests/scale_synonym"
        # t_fresh hard-codes /tmp, unavailable in workspace-only runtimes.  Change
        # only this output-file path, in the disposable copy, never its checks.
        fresh = suite / "t_fresh.c"
        old_path, new_path = b"/tmp/t_fresh.out", b"t_fresh.out"
        original_fresh = fresh.read_bytes()
        if original_fresh.count(old_path) != 2:
            parser.error("t_fresh fixture layout changed; review path relocation before running")
        fresh.write_bytes(original_fresh.replace(old_path, new_path))
        fixture_adjustments.append({"file": "tests/scale_synonym/t_fresh.c",
                                    "old": old_path.decode(), "new": new_path.decode(),
                                    "occurrences": 2, "scope": "disposable copy only"})
        logs.append("Fixture I/O relocation: t_fresh /tmp/t_fresh.out -> "
                    "t_fresh.out (disposable copy only; assertions unchanged)\n")
        print("Fixture I/O: t_fresh uses its disposable work directory; assertions unchanged.")
        shutil.copy2(snapshot / "combined/at_agent.cpp", suite / "at_agent.cpp")
        shutil.copy2(snapshot / "vst3/cpp/AutoTune_KeyScale_Controller.cpp",
                     suite / "AutoTune_KeyScale_Controller.cpp")
        extraction, output = run([sys.executable, "extract.py"], suite, args.timeout)
        logs.append("=== EXTRACT ===\n" + output)
        if extraction == 0:
            cases = sorted(suite.glob("t_*.c"))
            if not cases:
                extraction = 1
                logs.append("No t_*.c test cases found; refusing to report success.\n")
            for case in cases:
                binary = suite / case.stem
                compile_code, output = run([args.cc, "-O1", "-Wall", "-o", str(binary), str(case)],
                                           suite, args.timeout)
                logs.append(f"\n=== {case.name} BUILD ===\n" + output)
                test_code = None
                if compile_code == 0:
                    test_code, output = run([str(binary)], suite, args.timeout)
                    logs.append(f"\n=== {case.name} RUN ===\n" + output)
                tests.append({"name": case.name, "compile_exit": compile_code,
                              "run_exit": test_code})
                print(f"{'PASS' if compile_code == 0 and test_code == 0 else 'FAIL'} {case.name}",
                      flush=True)
    passed = sum(test["compile_exit"] == 0 and test["run_exit"] == 0 for test in tests)
    result = {"source_sha256": source_hashes, "fixture_adjustments": fixture_adjustments,
              "compiler": args.cc,
              "compiler_flags": ["-O1", "-Wall"], "extract_exit": extraction,
              "test_count": len(tests), "passed": passed, "tests": tests}
    summary = f"C regression: {passed}/{len(tests)} passed; extraction exit {extraction}"
    print(summary)
    if report is not None:
        report.mkdir(parents=True, exist_ok=True)
        (report / "regression.log").write_text("".join(logs), encoding="utf-8")
        (report / "regression.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n",
                                                 encoding="utf-8")
        print(f"Reports: {report}")
    elif extraction or passed != len(tests):
        print("".join(logs), file=sys.stderr)
    return 0 if extraction == 0 and tests and passed == len(tests) else 1


if __name__ == "__main__":
    sys.exit(main())
