# 真实 Windows 进程集成测试

`run.py` 编译和启动实际的测试 EXE；使用生产协议头直接给实际托管控制器发送 WM_COPYDATA。它不会替换生产函数、设置假授权、写入用户同意值或修改公钥。

```sh
python3 tests/integration/run.py --out /path/to/new-evidence --toolchain-bin /path/to/toolchain/usr/bin --wine64 /path/to/wine64 --wine32 /path/to/wine-with-x86
```

原生 Windows 以管理员身份运行，不传 Wine 参数；可用 `--compiler32`、`--compiler64` 指定实际 MinGW **win32 线程模型**编译器。64 位系统默认测 x64→x64、x86→x86、x86→x64；32 位 Windows 自动只测 x86→x86，交叉环境可显式用 `--system-bits 32`。`--out` 必须为空并位于源码树外。

## 覆盖

`w_companion.cpp` 把 TEMP、TMP、LOCALAPPDATA 仅在测试工作进程的环境中指向证据目录，核对：

- 双击和未知启动参数静默退出、目录快照完全不变；伪造父 PID 被拒绝。
- 实际隐藏窗口、协议／控制器版本握手和 300 ms 消息预算。
- 错误 magic、长度、字符集、发送者和伪造授权均被拒绝；待授权时不写出组件／命令。
- APPLY／FEEL 在合法在线授权前均不能工作。
- 关闭转后台、`--show` 复用并显示已有隐藏窗口、再次关闭仍在后台。
- 原父进程退出后，由独立监督进程持有真实句柄验证伴随进程 2 秒内退出。

`w_bridge.cpp` 加载实际 32 位桥，验证 undecorated stdcall 的两种导出、四参数封送边界、初始禁用状态、非法目标／强度拒绝、未配置 tick／apply 拒绝和诊断缓冲区边界。不修改同意值或凭据。

## 证据与边界

保存编译日志、每个实际进程的日志、实际控制器哈希和 `integration.json`。缺少某架构、运行超时或进程失败会记为 blocked／failed，整套不报通过。

这是**待授权边界**集成套件。合法服务器租约、agent 内存通道、真实插件回读和音频性能必须在部署环境与机架矩阵继续验证；本套件不把缺少这些证据的状态写成验收完成。
