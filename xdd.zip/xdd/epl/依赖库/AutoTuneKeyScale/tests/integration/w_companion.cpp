/* Real-process Win32 integration harness. Compile separately for x86/x64.
   Uses the production protocol header; does not replace controller functions,
   authorize a fake license, inject a plug-in, or weaken production validation. */
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <stdio.h>
#include <stdint.h>
#include <string>
#include <vector>
#include <algorithm>
#include "../../vst3/cpp/companion_protocol.h"

static unsigned checks=0,failed=0;
static void check(bool ok,const char* name){checks++;if(!ok)failed++;printf("%s %s\n",ok?"PASS":"FAIL",name);fflush(stdout);}
static std::wstring quote(const std::wstring& s){return L"\""+s+L"\"";}
static bool start(const std::wstring& exe,const std::wstring& args,PROCESS_INFORMATION* pi,bool inheritOutput=false){
    std::wstring cmd=quote(exe)+(args.empty()?L"":L" "+args);STARTUPINFOW si={sizeof si};ZeroMemory(pi,sizeof *pi);HANDLE copied[3]={NULL,NULL,NULL};
    if(inheritOutput){DWORD kinds[3]={STD_INPUT_HANDLE,STD_OUTPUT_HANDLE,STD_ERROR_HANDLE};for(int i=0;i<3;i++){HANDLE h=GetStdHandle(kinds[i]);if(h&&h!=INVALID_HANDLE_VALUE&&!DuplicateHandle(GetCurrentProcess(),h,GetCurrentProcess(),&copied[i],0,TRUE,DUPLICATE_SAME_ACCESS)){for(int j=0;j<3;j++)if(copied[j])CloseHandle(copied[j]);return false;}}si.dwFlags|=STARTF_USESTDHANDLES;si.hStdInput=copied[0];si.hStdOutput=copied[1];si.hStdError=copied[2];}
    bool ok=CreateProcessW(exe.c_str(),&cmd[0],NULL,NULL,inheritOutput?TRUE:FALSE,0,NULL,NULL,&si,pi)!=0;for(int i=0;i<3;i++)if(copied[i])CloseHandle(copied[i]);return ok;
}
static void close_process(PROCESS_INFORMATION* p){if(p->hThread)CloseHandle(p->hThread);if(p->hProcess)CloseHandle(p->hProcess);ZeroMemory(p,sizeof *p);}
struct Find {DWORD pid;HWND window;};
static BOOL CALLBACK enum_window(HWND h,LPARAM v){Find* f=(Find*)v;DWORD pid=0;GetWindowThreadProcessId(h,&pid);wchar_t cls[64];GetClassNameW(h,cls,64);if(pid==f->pid&&!wcscmp(cls,L"AT8Ctl")){f->window=h;return FALSE;}return TRUE;}
static HWND find_window(DWORD pid){Find f={pid,NULL};EnumWindows(enum_window,(LPARAM)&f);return f.window;}
static HWND wait_window(PROCESS_INFORMATION* child){DWORD until=GetTickCount()+5000;for(;;){HWND h=find_window(child->dwProcessId);if(h)return h;if(WaitForSingleObject(child->hProcess,0)!=WAIT_TIMEOUT||((LONG)(GetTickCount()-until)>=0))return NULL;Sleep(20);}}
static void put16(unsigned char* p,unsigned n){p[0]=(unsigned char)n;p[1]=(unsigned char)(n>>8);}
static void put32(unsigned char* p,unsigned n){for(int i=0;i<4;i++)p[i]=(unsigned char)(n>>(i*8));}
static std::vector<unsigned char> packet(unsigned op,const char* payload,uint64_t seq=1){
    unsigned len=(unsigned)strlen(payload);std::vector<unsigned char> b(ATC_HEADER_SIZE+len,0);memcpy(&b[0],"XAKS",4);put16(&b[4],ATC_PROTOCOL_VERSION);put16(&b[6],ATC_HEADER_SIZE);put16(&b[8],op);put32(&b[12],len);put32(&b[16],(unsigned)seq);put32(&b[20],(unsigned)(seq>>32));if(len)memcpy(&b[ATC_HEADER_SIZE],payload,len);return b;
}
static uint32_t send(HWND target,HWND sender,std::vector<unsigned char>& bytes,bool* delivered=NULL){
    COPYDATASTRUCT cds={(ULONG_PTR)ATC_COPYDATA_ID,(DWORD)bytes.size(),&bytes[0]};DWORD_PTR answer=0;LRESULT ok=SendMessageTimeoutW(target,WM_COPYDATA,(WPARAM)sender,(LPARAM)&cds,SMTO_ABORTIFHUNG|SMTO_BLOCK,ATC_SEND_TIMEOUT_MS,&answer);if(delivered)*delivered=ok!=0;return ok?(uint32_t)answer:0;
}
static std::wstring u16(const std::string& s){int n=MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),NULL,0);std::wstring w(n,0);MultiByteToWideChar(CP_UTF8,0,s.data(),(int)s.size(),&w[0],n);return w;}
static std::string u8(const std::wstring& s){int n=WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),NULL,0,NULL,NULL);std::string b(n,0);WideCharToMultiByte(CP_UTF8,0,s.data(),(int)s.size(),&b[0],n,NULL,NULL);return b;}
static void snapshot_walk(const std::wstring& dir,const std::wstring& rel,std::vector<std::string>& rows){
    WIN32_FIND_DATAW fd;HANDLE f=FindFirstFileW((dir+L"\\*").c_str(),&fd);if(f==INVALID_HANDLE_VALUE)return;
    do{if(!wcscmp(fd.cFileName,L".")||!wcscmp(fd.cFileName,L".."))continue;std::wstring name=rel+fd.cFileName,path=dir+L"\\"+fd.cFileName;
        if(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY){rows.push_back("D "+u8(name));if(!(fd.dwFileAttributes&FILE_ATTRIBUTE_REPARSE_POINT))snapshot_walk(path,name+L"/",rows);}
        else{ATC_SHA256 s;atc_sha_init(&s);HANDLE h=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,0,NULL);if(h!=INVALID_HANDLE_VALUE){unsigned char b[4096];DWORD n;while(ReadFile(h,b,sizeof b,&n,NULL)&&n)atc_sha_update(&s,b,n);CloseHandle(h);}unsigned char hash[32];atc_sha_final(&s,hash);char hex[65];for(int i=0;i<32;i++)sprintf(hex+i*2,"%02x",hash[i]);hex[64]=0;rows.push_back("F "+u8(name)+" "+hex);}
    }while(FindNextFileW(f,&fd));FindClose(f);
}
static std::vector<std::string> snapshot(const std::wstring& path){std::vector<std::string> rows;snapshot_walk(path,L"",rows);std::sort(rows.begin(),rows.end());return rows;}
static void make_dir(const std::wstring& d){if(!CreateDirectoryW(d.c_str(),NULL)&&GetLastError()!=ERROR_ALREADY_EXISTS){check(false,"test-directory-create");}}
static bool immediate_exit(const std::wstring& exe,const std::wstring& args,DWORD expected){PROCESS_INFORMATION pi;if(!start(exe,args,&pi))return false;DWORD exit=~0UL;bool ok=WaitForSingleObject(pi.hProcess,2000)==WAIT_OBJECT_0&&GetExitCodeProcess(pi.hProcess,&exit)&&exit==expected;if(!ok)TerminateProcess(pi.hProcess,99);close_process(&pi);return ok;}
struct Lifetime {DWORD pid;uintptr_t handle;};

static int worker(const std::wstring& controller,const std::wstring& result,DWORD supervisor){
    std::wstring probe=result+L".probe";make_dir(probe);make_dir(probe+L"\\temp");make_dir(probe+L"\\local");SetEnvironmentVariableW(L"TEMP",(probe+L"\\temp").c_str());SetEnvironmentVariableW(L"TMP",(probe+L"\\temp").c_str());SetEnvironmentVariableW(L"LOCALAPPDATA",(probe+L"\\local").c_str());
    auto clean=snapshot(probe);
    check(immediate_exit(controller,L"",0),"double-click-exits-zero");check(snapshot(probe)==clean,"double-click-zero-file-side-effects");
    check(immediate_exit(controller,L"--unrecognized",0),"unrecognized-intent-exits-zero");check(snapshot(probe)==clean,"unrecognized-intent-zero-file-side-effects");
    check(immediate_exit(controller,L"--companion 1",21),"creator-pid-mismatch-rejected");check(snapshot(probe)==clean,"invalid-parent-zero-file-side-effects");
    PROCESS_INFORMATION child;wchar_t args[80];swprintf(args,80,L"--companion %lu",GetCurrentProcessId());
    if(!start(controller,args,&child)){check(false,"companion-created");return 1;}
    HWND target=wait_window(&child);if(!target){DWORD rc=0;GetExitCodeProcess(child.hProcess,&rc);printf("DETAIL companion_exit=%lu (run elevated on Windows 7+)\n",rc);check(false,"companion-window-ready");if(rc==STILL_ACTIVE)TerminateProcess(child.hProcess,99);close_process(&child);return 1;}
    check(!IsWindowVisible(target),"companion-starts-hidden");Sleep(350);check(snapshot(probe)==clean,"waiting-authorization-zero-runtime-files");
    HWND sender=CreateWindowExW(0,L"STATIC",L"Integration sender",0,0,0,1,1,HWND_MESSAGE,NULL,GetModuleHandleW(NULL),NULL);check(sender!=NULL,"sender-window-created");
    bool delivered=false;auto b=packet(ATC_HELLO,"");DWORD begin=GetTickCount();auto reply=send(target,sender,b,&delivered);check(delivered&&reply==((ATC_PROTOCOL_VERSION<<16)|ATC_CONTROLLER_VERSION),"real-wm-copydata-handshake");check(GetTickCount()-begin<=ATC_SEND_TIMEOUT_MS+50,"handshake-within-300ms-budget");
    check(send(target,NULL,b)==ATC_REPLY_WRONG_PARENT,"wrong-sender-rejected");b[0]='!';check(send(target,sender,b)==ATC_REPLY_BAD_PACKET,"bad-magic-rejected");
    b=packet(ATC_HELLO,"extra");check(send(target,sender,b)==ATC_REPLY_BAD_PACKET,"handshake-unexpected-payload-rejected");
    b=packet(ATC_HELLO,"");put32(&b[12],1);check(send(target,sender,b)==ATC_REPLY_BAD_PACKET,"declared-length-mismatch-rejected");
    b=packet(ATC_AUTHORIZE,"\x01");check(send(target,sender,b)==ATC_REPLY_BAD_PACKET,"non-ascii-payload-rejected");
    b=packet(ATC_STATUS,"");reply=send(target,sender,b);check((reply&0xc0000000U)==0xc0000000U,"status-reports-authorization-wait");
    b=packet(ATC_AUTHORIZE,"invalid-server-signed-token");check(send(target,sender,b)==ATC_REPLY_AUTH_UNAVAILABLE,"forged-authorization-rejected");
    b=packet(ATC_APPLY,"key=1;scale=Minor;retune=0.75");check(send(target,sender,b)==ATC_REPLY_AUTH_REQUIRED,"apply-blocked-until-real-authorization");
    b=packet(ATC_FEEL,"retune=0.75");check(send(target,sender,b)==ATC_REPLY_AUTH_REQUIRED,"feel-blocked-until-real-authorization");
    check(snapshot(probe)==clean,"rejected-authorization-does-not-extract-or-write-command");
    SendMessageW(target,WM_CLOSE,0,0);Sleep(80);check(WaitForSingleObject(child.hProcess,0)==WAIT_TIMEOUT&&!IsWindowVisible(target),"close-transfers-companion-to-background");
    check(immediate_exit(controller,L"--show",0),"show-reuses-existing-controller");Sleep(100);check(IsWindowVisible(target),"show-displays-hidden-window");SendMessageW(target,WM_CLOSE,0,0);Sleep(80);
    check(WaitForSingleObject(child.hProcess,0)==WAIT_TIMEOUT&&!IsWindowVisible(target),"second-close-restores-background");
    // Transfer a real process handle to the supervisor before this parent exits.
    HANDLE owner=OpenProcess(PROCESS_DUP_HANDLE,FALSE,supervisor);HANDLE remote=NULL;
    bool transferred=owner&&DuplicateHandle(GetCurrentProcess(),child.hProcess,owner,&remote,SYNCHRONIZE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,0);
    check(transferred,"supervisor-process-handle-transfer");if(owner)CloseHandle(owner);
    if(transferred){Lifetime state={child.dwProcessId,(uintptr_t)remote};HANDLE out=CreateFileW(result.c_str(),GENERIC_WRITE,0,NULL,CREATE_ALWAYS,0,NULL);DWORD written=0;bool stored=out!=INVALID_HANDLE_VALUE&&WriteFile(out,&state,sizeof state,&written,NULL)&&written==sizeof state;if(out!=INVALID_HANDLE_VALUE)CloseHandle(out);check(stored,"parent-lifetime-state-written");}
    DestroyWindow(sender);close_process(&child);printf("WORKER checks=%u failures=%u\n",checks,failed);fflush(stdout);return failed?1:0;
}

int wmain(int argc,wchar_t** argv){
    if(argc==5&&!wcscmp(argv[1],L"--worker"))return worker(argv[2],argv[3],wcstoul(argv[4],NULL,10));
    if(argc!=3){fprintf(stderr,"Usage: w_companion.exe <managed-controller.exe> <new-result-state-file>\nRequires elevation; isolates TEMP/LOCALAPPDATA; leaves evidence in .probe.\n");return 2;}
    wchar_t self[MAX_PATH];GetModuleFileNameW(NULL,self,MAX_PATH);wchar_t pid[32];swprintf(pid,32,L"%lu",GetCurrentProcessId());
    PROCESS_INFORMATION child;std::wstring args=L"--worker "+quote(argv[1])+L" "+quote(argv[2])+L" "+pid;
    if(!start(self,args,&child,true)){check(false,"worker-start");return 1;}
    DWORD wait=WaitForSingleObject(child.hProcess,20000),rc=1;check(wait==WAIT_OBJECT_0,"worker-completes-within-20s");if(wait==WAIT_OBJECT_0)GetExitCodeProcess(child.hProcess,&rc);else TerminateProcess(child.hProcess,99);close_process(&child);
    HANDLE in=CreateFileW(argv[2],GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL);Lifetime state={0,0};DWORD read=0;bool got=in!=INVALID_HANDLE_VALUE&&ReadFile(in,&state,sizeof state,&read,NULL)&&read==sizeof state;if(in!=INVALID_HANDLE_VALUE)CloseHandle(in);check(got,"parent-exit-evidence-available");
    if(got){HANDLE h=(HANDLE)state.handle;DWORD begin=GetTickCount();check(WaitForSingleObject(h,2000)==WAIT_OBJECT_0,"companion-exits-within-2s-after-parent");printf("DETAIL parent_exit_wait_ms=%lu controller_pid=%lu\n",GetTickCount()-begin,state.pid);CloseHandle(h);}
    printf("RESULT worker_exit=%lu supervisor_checks=%u supervisor_failures=%u\n",rc,checks,failed);return rc||failed?1:0;
}
