#!/usr/bin/env python3
"""Compile/run real-process Windows integration checks on native Windows or Wine.

No test token, trust-key bypass, or production source change is used. This suite
covers the pre-authorization process/UI/IPC boundary; valid-license/plugin tests
need the deployed license service and the real DAW/plugin matrix separately.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import platform
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]


def winpath(path):
    value = str(path.resolve())
    return value if os.name == 'nt' else 'Z:' + value.replace('/', '\\')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--toolchain-bin', type=Path)
    ap.add_argument('--compiler32')
    ap.add_argument('--compiler64')
    ap.add_argument('--controller-dir', type=Path, default=ROOT / 'vst3' / 'cpp')
    ap.add_argument('--wine64', type=Path, help='Wine loader for x64; omit on native Windows')
    ap.add_argument('--wine32', type=Path, help='Wine loader with a working x86 environment')
    ap.add_argument('--only', choices=('64', '32', 'all'), default='all')
    arch = os.environ.get('PROCESSOR_ARCHITEW6432') or os.environ.get('PROCESSOR_ARCHITECTURE') or platform.machine()
    ap.add_argument('--system-bits', choices=('32', '64'), default='32' if arch.lower() in ('x86', 'i386', 'i686') else '64', help='Target Windows architecture; 32-bit Windows runs only the x86 matrix')
    args = ap.parse_args()
    if args.system_bits == '32' and args.only == '64':
        ap.error('A 32-bit Windows system cannot execute an x64 sender')
    out = args.out.resolve()
    if ROOT == out or ROOT in out.parents or (out.exists() and any(out.iterdir())):
        ap.error('--out must be a new directory outside the source tree')
    out.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    if args.toolchain_bin:
        env['PATH'] = str(args.toolchain_bin.resolve()) + os.pathsep + env.get('PATH', '')
    source = ROOT / 'tests' / 'integration' / 'w_companion.cpp'
    report = {'schema': 1, 'suite': 'actual managed-controller processes and WM_COPYDATA',
              'scope': 'pre-authorization process/UI/IPC boundary',
              'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
              'cases': [], 'claims': {'real_plugins_tested': False, 'valid_server_authorization_tested': False}}
    compilers = {}
    for bits, triple in (('64', 'x86_64-w64-mingw32'), ('32', 'i686-w64-mingw32')):
        if (args.only != 'all' and args.only != bits) or (args.system_bits == '32' and bits == '64'):
            continue
        cxx = getattr(args, 'compiler' + bits) or shutil.which(triple + '-g++-win32', path=env['PATH'])
        harness = out / ('w_companion' + bits + '.exe')
        if not cxx:
            report['cases'].append({'name': 'compile_harness' + bits, 'status': 'blocked', 'reason': 'Win32-model compiler unavailable'})
            continue
        argv = [cxx, '-O2', '-municode', '-Wl,--no-insert-timestamp', '-static', '-static-libgcc', '-static-libstdc++', str(source), '-o', str(harness)]
        result = subprocess.run(argv, env=env, capture_output=True, text=True)
        (out / ('compile' + bits + '.log')).write_text(result.stdout + result.stderr, encoding='utf-8')
        report['cases'].append({'name': 'compile_harness' + bits, 'status': 'passed' if result.returncode == 0 else 'failed', 'returncode': result.returncode, 'argv': argv})
        if result.returncode == 0:
            compilers[bits] = harness
    if '32' in compilers:
        bridge_source = source.with_name('w_bridge.cpp')
        bridge_harness = out / 'w_bridge32.exe'
        cxx = args.compiler32 or shutil.which('i686-w64-mingw32-g++-win32', path=env['PATH'])
        argv = [cxx, '-O2', '-municode', '-Wl,--no-insert-timestamp', '-static', '-static-libgcc', '-static-libstdc++', str(bridge_source), '-o', str(bridge_harness)]
        result = subprocess.run(argv, env=env, capture_output=True, text=True)
        (out / 'compile_bridge32.log').write_text(result.stdout + result.stderr, encoding='utf-8')
        report['cases'].append({'name': 'compile_bridge32', 'status': 'passed' if result.returncode == 0 else 'failed', 'returncode': result.returncode, 'argv': argv})
        if result.returncode == 0:
            loader = args.wine32
            if os.name != 'nt' and loader is None:
                report['cases'].append({'name': 'bridge32_abi', 'status': 'blocked', 'reason': 'Working x86 Wine loader not supplied'})
            else:
                bridge = args.controller_dir.resolve() / 'keyscale_rack_bridge.dll'
                argv = ([str(loader.resolve())] if loader else []) + [str(bridge_harness), winpath(bridge)]
                try:
                    result = subprocess.run(argv, cwd=out, env=env, capture_output=True, text=True, errors='replace', timeout=35)
                    (out / 'bridge32_abi.log').write_text(result.stdout + result.stderr, encoding='utf-8')
                    report['cases'].append({'name': 'bridge32_abi', 'status': 'passed' if result.returncode == 0 else 'failed', 'returncode': result.returncode, 'argv': argv})
                except OSError as error:
                    report['cases'].append({'name': 'bridge32_abi', 'status': 'failed', 'reason': str(error), 'argv': argv})
                except subprocess.TimeoutExpired:
                    report['cases'].append({'name': 'bridge32_abi', 'status': 'failed', 'reason': 'Actual runtime exceeded 35 seconds', 'argv': argv})
    matrix = [('32', '32')] if args.system_bits == '32' else [('64', '64'), ('32', '32'), ('32', '64')]
    matrix = [(sender, receiver) for sender, receiver in matrix if args.only == 'all' or sender == args.only]
    for sender, receiver in matrix:
        if sender not in compilers:
            continue
        case = 'sender' + sender + '_controller' + receiver
        controller = args.controller_dir.resolve() / ('keyscale_rack_controller' + ('32' if receiver == '32' else '') + '.exe')
        if not controller.is_file():
            report['cases'].append({'name': case, 'status': 'blocked', 'reason': 'Managed controller missing'})
            continue
        loader = args.wine64 if sender == '64' else args.wine32
        if os.name != 'nt' and loader is None:
            report['cases'].append({'name': case, 'status': 'blocked', 'reason': 'Working Wine loader for sender architecture not supplied'})
            continue
        state = out / (case + '.state')
        argv = ([str(loader.resolve())] if loader else []) + [str(compilers[sender]), winpath(controller), winpath(state)]
        record = {'name': case, 'argv': argv, 'controller_sha256': hashlib.sha256(controller.read_bytes()).hexdigest()}
        try:
            p = subprocess.run(argv, cwd=out, env=env, capture_output=True, text=True, errors='replace', timeout=35)
            record.update({'status': 'passed' if p.returncode == 0 else 'failed', 'returncode': p.returncode})
            (out / (case + '.log')).write_text(p.stdout + p.stderr, encoding='utf-8')
        except OSError as error:
            record.update({'status': 'failed', 'reason': str(error)})
        except subprocess.TimeoutExpired as error:
            record.update({'status': 'failed', 'reason': 'Actual runtime exceeded 35 seconds'})
            stdout = error.stdout.decode(errors='replace') if isinstance(error.stdout, bytes) else error.stdout or ''
            stderr = error.stderr.decode(errors='replace') if isinstance(error.stderr, bytes) else error.stderr or ''
            (out / (case + '.log')).write_text(stdout + stderr, encoding='utf-8')
        report['cases'].append(record)
    report['target_system_bits'] = args.system_bits
    report['status'] = 'passed' if report['cases'] and all(row['status'] == 'passed' for row in report['cases']) and len([r for r in report['cases'] if r['name'].startswith('sender')]) == len(matrix) else 'incomplete_or_failed'
    (out / 'integration.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
