/* Real xhh32 bridge ABI smoke check. Never modifies consent or license data. */
#ifndef UNICODE
#define UNICODE
#endif
#include <windows.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
static unsigned checks=0,failed=0;
static void check(bool ok,const char* name){checks++;if(!ok)failed++;printf("%s %s\n",ok?"PASS":"FAIL",name);}
typedef int (WINAPI* Command)(unsigned,uintptr_t,uintptr_t,uintptr_t,uintptr_t);
typedef int (WINAPI* Invoke)(unsigned,const uint32_t*,unsigned,unsigned);
int wmain(int argc,wchar_t** argv){
    if(argc!=2){fprintf(stderr,"Usage: w_bridge.exe <keyscale_rack_bridge.dll>\n");return 2;}
    HMODULE dll=LoadLibraryW(argv[1]);check(dll!=NULL,"actual-bridge-load");if(!dll)return 1;
    Command command=(Command)GetProcAddress(dll,"RackBridge_Command");Invoke invoke=(Invoke)GetProcAddress(dll,"XRB_Invoke");
    check(command!=NULL,"five-argument-stdcall-undecorated-export");check(invoke!=NULL,"four-argument-stdcall-undecorated-export");if(!command||!invoke){FreeLibrary(dll);return 1;}
    uint32_t args[4]={0,0,0,0};
    check(invoke(13,NULL,4,0)==0,"null-marshaled-arguments-rejected");
    check(invoke(13,args,3,0)==0,"wrong-marshaled-argument-count-rejected");
    check(invoke(13,args,4,1)==0,"unknown-marshaled-flags-rejected");
    check(invoke(13,args,4,0)==18,"loaded-bridge-starts-disabled");
    check((uint32_t)command(5,0,0,0,0)==0xc0000000U,"loaded-bridge-status-waits-for-authorization");
    check(command(2,0,0,0,0)==0,"tick-before-configuration-does-not-start");
    check(command(3,12,0,(uintptr_t)-1,0)==0,"out-of-range-key-rejected");
    check(command(3,0,3,(uintptr_t)-1,0)==0,"out-of-range-scale-rejected");
    check(command(4,1001,0,0,0)==0,"out-of-range-strength-rejected");
    check(command(11,4,0,0,0)==0,"out-of-range-product-rejected");
    check(command(1,0,0,0,0)==0,"incomplete-configuration-rejected");
    check(command(3,0,0,(uintptr_t)-1,0)==0,"target-cannot-apply-without-online-lease");
    wchar_t diagnostic[256];memset(diagnostic,0xff,sizeof diagnostic);int n=command(12,(uintptr_t)diagnostic,256,0,0);
    check(n>0&&n<256&&diagnostic[n]==0,"diagnostic-is-bounded-and-terminated");
    check(command(8,0,0,0,0)==1,"unconfigured-stop-is-idempotent");
    check(command(8,0,0,0,0)==1,"repeated-stop-is-idempotent");
    FreeLibrary(dll);printf("RESULT bridge_checks=%u failures=%u\n",checks,failed);return failed?1:0;
}
