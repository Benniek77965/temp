#!/usr/bin/env python3
"""Execute the production EPL 汽水音乐 (SodaMusic) reader: the current song from LunaStorage\\QueueCache.

Not an EPL compiler, real Windows file I/O or a real 汽水音乐: epl_machine runs the source text with EPL's types
(integers wrap at their declared width, 参考 parameters are written back, conditions must be 逻辑型, a class
object -- here the zyJsonDocument stand-in -- passed by value is refused). 汽水音乐 saves its play queue about a
second after every song change (never while preloading): 4 bytes "LUNA" + a gzip stream of UTF-8 JSON, written
to a temporary file and renamed over QueueCache, so every save is a new file. The JSON holds one member per queue
(u_<user>:feed and so on) with savedAt (ms), playables[] and lastPlayedKey -- the song playing (or last played).
The QueueCache files here are built by the test from invented queues (user IDs, keys, request IDs and signatures
are made up); a real QueueCache holds the account's user ID and is never used as a fixture -- run this file with
--real PATH to check one locally.

Substitutes: Win32 file calls (CreateFileW, GetFileInformationByHandle_字节集, GetFileSizeEx_逻辑型,
SetFilePointerEx_整数型, ReadFile_整数型, CloseHandle) over an in-memory file table; zyJsonDocument written from
zyJson's documented behaviour (paths a.b[0].c with \\ . [ ] escaped by \\, missing values read as empty);
GZIP_解压数据 with Python's zlib (members one after another, data after the last member ignored, empty on
failure); 子文本替换W / un_连接 / 删除Unicode结尾空白字节 as in test_wesing_log (written from their source).
"""
from pathlib import Path
import argparse
import gzip
import json
import re
import struct
import zlib
import epl_machine as em
from test_wesing_log import jy_replace, jy_trim_end

HERE = Path(__file__).resolve().parent
EPL = HERE.parents[3]
MODULE = EPL / '模块/模块_电音助手.e~'
PLAYER = MODULE / '代码/程序集_播放器和基调查询.static.e.txt'
APPDATA = 'C:\\Users\\测试😀\\AppData\\Roaming\\'
QUEUE = APPDATA + 'SodaMusic\\LunaStorage\\QueueCache'
W = lambda text: (text + '\0').encode('utf-16-le')


def wide(value):
    return bytes(value).decode('utf-16-le').split('\0')[0]


def gunzip(data):
    out, rest = b'', bytes(data)
    while rest[:2] == b'\x1f\x8b':
        d = zlib.decompressobj(16 + zlib.MAX_WBITS)
        try:
            out += d.decompress(rest) + d.flush()
        except zlib.error:
            return b''
        if not d.eof:
            return b''
        rest = d.unused_data
    return out


class ZyJson:
    """zyJsonDocument as documented: W paths a.b[0].c, \\ . [ ] escaped by \\; missing values read as empty."""
    def __init__(self):
        self.root, self.destroyed = None, False

    @staticmethod
    def steps(path):
        text = '' if path is None else wide(path)
        steps, name, i = [], '', 0
        while i < len(text):
            c = text[i]
            if c == '\\':
                assert i + 1 < len(text) and text[i + 1] in '\\.[]', ('bad escape in path', text)
                name += text[i + 1]; i += 2; continue
            if c == '.':
                steps.append(name); name = ''
            elif c == '[':
                if name: steps.append(name)
                name = ''
                j = text.index(']', i)
                steps.append(int(text[i + 1:j])); i = j + 1
                if i < len(text):
                    assert text[i] in '.[', ('bad path after index', text)
                    if text[i] == '.': i += 1
                continue
            elif c == ']':
                raise AssertionError(('unescaped ] in path', text))
            else:
                name += c
            i += 1
        if name or (text and text.endswith('.')):
            steps.append(name)
        return steps

    def find(self, path):
        node = self.root
        for step in self.steps(path):
            if isinstance(step, int):
                if not isinstance(node, list) or not 0 <= step < len(node): return None, False
                node = node[step]
            else:
                if not isinstance(node, dict) or step not in node: return None, False
                node = node[step]
        return node, True

    def 解析UTF8(self, text, *unused):
        try:
            self.root = json.loads(text.encode('latin-1').decode('utf-8'))   # 文本型 carries the raw UTF-8 bytes
            return True
        except (ValueError, UnicodeError):
            return False

    def 取文本W(self, path=None, *unused):
        node, ok = self.find(path)
        if not ok or node is None or isinstance(node, (list, dict)): return b'\0\0'
        if isinstance(node, bool): return W('true' if node else 'false')
        return W(node if isinstance(node, str) else json.dumps(node))

    def 取长整数W(self, path=None):
        node, ok = self.find(path)
        return int(node) if ok and isinstance(node, (int, float)) and not isinstance(node, bool) else 0

    def 取成员数W(self, path=None):
        node, ok = self.find(path)
        return len(node) if ok and isinstance(node, (list, dict)) else 0

    def 是否存在W(self, path=None):
        return self.find(path)[1]

    def 取所有属性名W(self, path, names):
        node, ok = self.find(path)
        names.clear()
        if ok and isinstance(node, dict):
            names.extend(W(k) for k in node)
        return len(names)

    def _销毁(self):
        self.destroyed = True


class Machine(em.Machine):
    def __init__(self):
        super().__init__()
        self.load_static(PLAYER.read_text('utf-8-sig'))
        self.factories['zyJsonDocument'] = self.new_json
        self.now, self.present = 100000, True
        self.files, self.handles, self.opened, self.closed, self.reads, self.next_index = {}, {}, [], [], 0, 1
        self.jsons, self.fail_read = [], False
        self.builtins.update({
            '系统_取启动时间': lambda: self.now,
            '目录_取特定目录W': lambda kind, *a: W(APPDATA) if kind == 8 else b'',
            '删除Unicode结尾空白字节': jy_trim_end, '子文本替换W': jy_replace,
            'un_连接': lambda *parts: (lambda s: W(s) if s else b'')(''.join(jy_trim_end(p).decode('utf-16-le') for p in parts if isinstance(p, bytes))),
            '编码_Unicode到usc2': lambda data, *a: bytes(data).decode('utf-16-le').rstrip('\0'),
            '是否为空W': lambda data: data in (b'', b'\0\0'),
            '到文本': lambda v: bytes(v).decode('latin-1') if isinstance(v, (bytes, bytearray)) else em.epl_text(v),   # bytes kept as they are
            'GZIP_解压数据': gunzip,
            'CloseHandle': self.close_handle,
        })
        self.raw_builtins.update({'进程_枚举': self.snapshot, 'CreateFileW': self.create_handle, 'GetFileInformationByHandle_字节集': self.info,
                                  'GetFileSizeEx_逻辑型': self.size_of, 'SetFilePointerEx_整数型': self.seek, 'ReadFile_整数型': self.read_into})

    def new_json(self):
        j = ZyJson()
        self.jsons.append(j)
        return j

    def save(self, data, name=QUEUE):
        """汽水音乐's save: a temporary file renamed over the old one -- a new file each time."""
        self.files[name] = {'data': bytes(data), 'index': self.next_index, 'written': self.now}
        self.next_index += 1

    def snapshot(self, env, args, raws):
        names = ['explorer.exe', 'SodaMusic.exe'] if self.present else ['explorer.exe']
        self.store(raws[0], names, env)
        self.store(raws[1], list(range(10, 10 + len(names))), env)
        return len(names)

    def create_handle(self, env, args, raws):
        path = wide(self.ev(args[0], env))
        assert self.ev(args[2], env) == 7, 'opened without FILE_SHARE_DELETE: 汽水音乐 could not rename over it'
        if path not in self.files:
            return -1
        handle = 500 + len(self.opened)
        self.opened.append(handle)
        self.handles[handle] = [self.files[path], 0]
        return handle

    def info(self, env, args, raws):
        f = self.handles[self.ev(args[0], env)][0]
        b = bytearray(52)
        struct.pack_into('<Q', b, 4, 1000 + f['index'])            # creation time of the new file
        struct.pack_into('<Q', b, 20, f['written'] // 1000)        # write time, to the second (same second, same size: index still differs)
        struct.pack_into('<III', b, 28, 0x1234, len(f['data']) >> 32, len(f['data']) & 0xFFFFFFFF)   # volume serial, size high, size low
        struct.pack_into('<II', b, 44, 0, f['index'])              # file index
        self.store(raws[1], bytes(b), env)
        return True

    def size_of(self, env, args, raws):
        self.store(raws[1], len(self.handles[self.ev(args[0], env)][0]['data']), env)
        return True

    def seek(self, env, args, raws):
        self.handles[self.ev(args[0], env)][1] = self.ev(args[1], env)
        return True

    def read_into(self, env, args, raws):
        h = self.handles[self.ev(args[0], env)]
        target = re.fullmatch(r'取变量数据地址 \((.+)\)', raws[1].strip()).group(1)   # the buffer, filled in place
        n = self.ev(args[2], env)
        data = h[0]['data'][h[1]:h[1] + n]
        if self.fail_read:
            data = data[:len(data) // 2]
        self.reads += 1
        buffer = self.ev(em.parse_expr(target), env)
        self.store(target, data + bytes(buffer[len(data):]), env)
        self.store(raws[3], len(data), env)
        return True

    def close_handle(self, handle):
        self.handles.pop(handle)
        self.closed.append(handle)
        return True

    def query(self):
        result = self.invoke(self.subs['汽水音乐_查询_正在播放的音乐'], [], {}, None)
        assert not self.handles, 'every opened file is closed'
        assert all(j.destroyed for j in self.jsons), 'every parsed JSON document is released'
        return result


def track(key, name, artists, kind='track', nested=True):
    body = {'id': key.split('-')[-1], 'name': name, 'artists': [{'id': str(i), 'name': a} for i, a in enumerate(artists)],
            'album': {'name': '专辑'}, 'duration': 215000}
    item = {'key': key, 'type': kind, **({'track': body} if nested else body)}
    if nested:
        item.update({'id': body['id'], 'name': name, 'artists': body['artists']})   # 汽水音乐 repeats them on the item
    return item


def queue(items, last, saved_at=1793972370820):
    return {'version': 2, 'savedAt': saved_at, 'cursor': None, 'hasMore': True, 'playables': items,
            'limitedFreeInfos': {it['key']: {'limited_free': False, 'sign': '0' * 32} for it in items},
            'requestIdMap': {it['key']: '20260101000000ABCDEF' for it in items}, 'lastPlayedKey': last}


def same_length(length, build):
    """A cache file of exactly this length: padding text inside the JSON until the gzip stream matches."""
    for n in range(0, 200):
        for k in range(0, 60):
            data = build('x' * n + '0123456789abcdefghij'[:k % 20] * (k // 20 + 1))
            if len(data) == length:
                return data
    raise AssertionError('no padding gives the same length')


def cache(queues):
    return b'LUNA' + gzip.compress(json.dumps(queues, ensure_ascii=False).encode('utf-8'))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--real', help='a real 汽水音乐 LunaStorage\\QueueCache to check locally (never committed)')
    opts = parser.parse_args()
    checks = []

    def check(name, passed):
        checks.append(name)
        assert passed, name

    if opts.real:
        m = Machine(); m.save(Path(opts.real).read_bytes())
        print(json.dumps({'real_queue_cache': opts.real, 'current_song': m.query()}, ensure_ascii=False))
        return

    feed = [track('track-1001', '夜曲（Live）', ['甲歌手']), track('track-1002', '飞女正传（世界将我包围）', ['南木碎碎唱']),
            track('track-1003', '夜に駆ける 🌙', ['YOASOBI']), track('track-1004', '合唱', ['甲', '', '乙', '丙']),
            track('track-1005', '一段视频 #话题', ['上传者'], kind='video'), track('track-1006', '平铺的一首', ['丁'], nested=False),
            track('track-1007', '没有歌手', []), track('track-1008', '', ['戊'])]
    user = 'u_10001:feed'

    # ---- the song is the queue's lastPlayedKey ---------------------------------------------------------------
    m = Machine(); m.save(cache({user: queue(feed, 'track-1002')}))
    check('current_song_is_the_last_played_key', m.query() == '南木碎碎唱 - 飞女正传（世界将我包围）')
    check('the_file_is_read_once', m.reads == 1 and len(m.opened) == 1)
    for key, expect in (('track-1003', 'YOASOBI - 夜に駆ける 🌙'), ('track-1004', '甲/乙/丙 - 合唱'), ('track-1006', '丁 - 平铺的一首'),
                        ('track-1005', ''), ('track-1007', ''), ('track-1008', ''), ('track-9999', '')):
        m = Machine(); m.save(cache({user: queue(feed, key)}))
        check('song_for_' + key, m.query() == expect)
    m = Machine(); m.save(cache({user: queue(feed, '')}))
    check('no_last_played_key_shows_nothing', m.query() == '')
    m = Machine(); m.save(cache({}))
    check('no_queue_shows_nothing', m.query() == '')

    # ---- several queues: the newest savedAt wins; a queue name needing escapes in the path ---------------------
    older = queue(feed, 'track-1001', saved_at=1793972000000)
    newer = queue([track('track-2001', '歌单里的歌', ['己'])], 'track-2001', saved_at=1793972999000)
    m = Machine(); m.save(cache({user: older, 'u_10001:playlist.v2[7]\\x': newer}))
    check('newest_queue_wins_and_its_name_is_escaped', m.query() == '己 - 歌单里的歌')
    m = Machine(); m.save(cache({'u_10001:playlist.v2[7]\\x': dict(newer, savedAt=1), user: older}))
    check('older_queue_loses_whatever_its_order', m.query() == '甲歌手 - 夜曲（Live）')

    # ---- looking: at most once a second; the same file is not read again; every save is a new file -------------
    m = Machine(); m.save(cache({user: queue(feed, 'track-1001')}))
    m.query(); m.now += 400; m.save(cache({user: queue(feed, 'track-1002')}))
    check('looked_at_most_once_a_second', m.query() == '甲歌手 - 夜曲（Live）' and len(m.opened) == 1)
    m.now += 700
    check('a_new_save_is_read', m.query() == '南木碎碎唱 - 飞女正传（世界将我包围）' and m.reads == 2)
    m.now += 1100
    check('the_same_file_is_not_read_again', m.query() == '南木碎碎唱 - 飞女正传（世界将我包围）' and m.reads == 2 and len(m.opened) == 3)
    # the next save written in the same second and exactly as long: only the new file's index tells them apart
    first = cache({user: dict(queue(feed, 'track-1002'), pad='y' * 40)})
    m.save(first); m.now += 1000
    assert m.query() == '南木碎碎唱 - 飞女正传（世界将我包围）'
    before = m.files[QUEUE]
    other = same_length(len(first), lambda pad: cache({user: dict(queue(feed, 'track-1003'), pad=pad)}))
    m.save(other); m.files[QUEUE]['written'] = before['written']
    assert len(m.files[QUEUE]['data']) == len(before['data']) and m.files[QUEUE]['written'] // 1000 == before['written'] // 1000
    m.now += 1000
    check('a_save_in_the_same_second_and_size_is_still_a_new_file', m.query() == 'YOASOBI - 夜に駆ける 🌙')

    # ---- damaged or unexpected files keep the last result and are read again a second later --------------------
    good = cache({user: queue(feed, 'track-1002')})
    for label, data in (('bad_header', b'LUNX' + good[4:]), ('bad_gzip', b'LUNA' + b'\x1f\x8b\x08' + b'\x00' * 30),
                        ('bad_json', b'LUNA' + gzip.compress(b'{"u_1:feed": {')), ('too_short', b'LUNA\x1f')):
        m = Machine(); m.save(good); first = m.query()
        m.save(data); m.now += 1000
        check('kept_on_' + label, m.query() == first and m.globals['集_汽水_歌名'] == first)
        m.save(cache({user: queue(feed, 'track-1003')})); m.now += 1000
        check('read_again_after_' + label, m.query() == 'YOASOBI - 夜に駆ける 🌙')
    m = Machine(); m.save(good); m.query()
    m.save(cache({user: queue(feed, 'track-1003')})); m.fail_read = True; m.now += 1000
    check('short_read_keeps_the_last_result', m.query() == '南木碎碎唱 - 飞女正传（世界将我包围）')
    m.fail_read = False; m.now += 1000
    check('read_again_after_a_short_read', m.query() == 'YOASOBI - 夜に駆ける 🌙')
    m = Machine(); m.save(b'LUNA' + b'\0' * (4 * 1024 * 1024))
    check('a_file_over_4MB_is_not_read', m.query() == '' and m.reads == 0)
    m = Machine(); m.save(cache({user: queue(feed, 'track-1002')}) + b'\x00garbage after the gzip member')
    check('data_after_the_gzip_member_ignored', m.query() == '南木碎碎唱 - 飞女正传（世界将我包围）')

    # ---- no file, not running ---------------------------------------------------------------------------------
    m = Machine()
    check('no_queue_file_shows_nothing', m.query() == '' and not m.opened)
    m = Machine(); m.save(good); m.query()
    m.present = False; m.now += 2000
    check('not_running_shows_nothing_and_forgets', m.query() == '' and m.globals['集_汽水_身份'] == b'' and m.globals['集_汽水_检查时间'] == 0)
    m.present = True; m.now += 2000
    check('running_again_reads_at_once', m.query() == '南木碎碎唱 - 飞女正传（世界将我包围）')
    del m.files[QUEUE]; m.now += 1000
    check('queue_file_gone_shows_nothing', m.query() == '' and m.globals['集_汽水_身份'] == b'')

    # ---- source: registration, icon, process, no network, the JSON object by reference -------------------------
    source = PLAYER.read_text('utf-8-sig').replace('\r', '')
    init = re.search(r'^\.子程序 播放器查询信息_初始化[^\n]*\n(.*?)(?=^\.子程序 |\Z)', source, re.M | re.S).group(1)
    order = re.findall(r'局_播放器查询信息\.名, “([^”]+)”', init)
    check('registered_just_before_kuwo', order[order.index('酷我音乐') - 1] == '汽水音乐' and '&汽水音乐_查询_正在播放的音乐' in init
          and '#列表框_图标_汽水音乐' in init)
    desc = json.loads((MODULE / '资源/资源.desc.json').read_text('utf-8-sig'))
    icon = (MODULE / '资源/列表框_图标_汽水音乐.Image.dat').read_bytes()
    check('icon_resource_32px_png', any(r['Name'] == '列表框_图标_汽水音乐' for r in desc['Resources'])
          and icon[:8] == b'\x89PNG\r\n\x1a\n' and struct.unpack('>II', icon[16:24]) == (32, 32))
    soda = '\n'.join(m.subs[n].text for n in m.subs if n.startswith('汽水音乐_'))
    check('process_is_sodamusic', '播放器_进程存在 (“SodaMusic.exe”)' in soda and 'WeSing' not in soda)
    check('detection_never_uses_the_network', not re.search(r'网页_|WinHttp|URLDownload|Internet|socket|http', soda, re.I))
    check('json_object_passed_by_reference', re.search(r'^\.参数 参_JSON, zyJsonDocument, 参考', soda, re.M) is not None)
    check('reads_the_queue_file_not_the_cache_database', 'LunaStorage\\QueueCache' in soda and '类_LMDB' not in soda and 'MP_' not in source)

    print(json.dumps({'checks': len(checks), 'passed': len(checks)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
