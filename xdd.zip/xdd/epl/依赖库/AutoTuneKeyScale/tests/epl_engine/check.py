#!/usr/bin/env python3
"""Source-extracted EPL engine checks; this is not an EPL compiler or a Windows runtime test.

The small evaluator executes the real normalization procedure's statements and control
flow. Test expectations are the musical pitch specification, not a second parser.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re


class Returned(Exception):
    def __init__(self, value): self.value = value


class Broke(Exception):
    pass


def split_args(value):
    result, start, level, quoted = [], 0, 0, False
    for i, char in enumerate(value):
        if char == '“': quoted = True
        elif char == '”': quoted = False
        elif not quoted:
            if char in '([{': level += 1      # {…} is one byte-array literal, like (…) and […]
            elif char in ')]}': level -= 1
            elif char == ',' and level == 0:
                result.append(value[start:i].strip()); start = i + 1
    result.append(value[start:].strip())
    return result


def arguments(line):
    return split_args(line[line.index('(') + 1:line.rindex(')')])


def section(source, name):
    match = re.search(r'^\.子程序 ' + re.escape(name) + r'(?=[,\s])[^\n]*\n', source, re.M)  # 名称要完全相同：只比前缀的话会取到更长的同前缀子程序（如 关闭透明 之于 关闭）
    if not match: raise AssertionError('missing procedure ' + name)
    end = source.find('\n.子程序 ', match.end())
    return source[match.start(): end if end >= 0 else len(source)]


def active_line(line):
    quoted = False
    for index, char in enumerate(line):
        if char == '“': quoted = True
        elif char == '”': quoted = False
        elif char == "'" and not quoted: return line[:index].strip()
    return line.strip()


def call_arguments(line, name):
    start = line.index(name + ' (') + len(name + ' (')
    depth, quoted = 1, False
    for end in range(start, len(line)):
        char = line[end]
        if char == '“': quoted = True
        elif char == '”': quoted = False
        elif not quoted:
            if char == '(': depth += 1
            elif char == ')':
                depth -= 1
                if depth == 0: return split_args(line[start:end])
    raise AssertionError('unclosed call ' + name)


def http_helper_path(module):
    return module.parent / '精易模块v9.3.5[源码].e~/代码/杂项/集_自己添加的.static.e.txt'


def http_call_lines(query):
    return [active_line(line) for line in query.splitlines()
            if '网页_访问_对象 (url,' in active_line(line)]


def parse_block(lines, start=0, endings=()):
    nodes, index = [], start
    while index < len(lines):
        line = active_line(lines[index])
        token = line.split(' ', 1)[0]
        if token in endings: return nodes, index
        if not line or line.startswith("'") or token in ('.参数', '.局部变量', '.子程序'):
            index += 1; continue
        if token == '.如果真':
            body, end = parse_block(lines, index + 1, ('.如果真结束',))
            assert end < len(lines), 'unclosed if'
            nodes.append(('if', arguments(line)[0], body)); index = end + 1
        elif token == '.如果':
            body, end = parse_block(lines, index + 1, ('.否则', '.如果结束'))
            assert end < len(lines), 'unclosed if/else'
            branches = [(arguments(line)[0], body)]
            if active_line(lines[end]).startswith('.否则'):
                body, end = parse_block(lines, end + 1, ('.如果结束',))
                assert end < len(lines), 'unclosed else'
                branches.append((None, body))
            nodes.append(('switch', branches)); index = end + 1
        elif token == '.判断开始':
            branches = []
            condition = arguments(line)[0]
            while True:
                body, end = parse_block(lines, index + 1, ('.判断', '.默认', '.判断结束'))
                branches.append((condition, body))
                assert end < len(lines), 'unclosed switch'
                terminal = active_line(lines[end])   # 同 .判断开始：先去掉行尾注释（注释里的括号会让 arguments 取错条件）
                if terminal.startswith('.判断结束'):
                    index = end + 1; break
                condition = None if terminal.startswith('.默认') else arguments(terminal)[0]
                index = end
            nodes.append(('switch', branches))
        elif token == '.变量循环首':
            body, end = parse_block(lines, index + 1, ('.变量循环尾',))
            assert end < len(lines), 'unclosed for'
            nodes.append(('for', arguments(line), body)); index = end + 1
        elif token == '.判断循环首':
            body, end = parse_block(lines, index + 1, ('.判断循环尾',))
            assert end < len(lines), 'unclosed while'
            nodes.append(('while', arguments(line)[0], body)); index = end + 1
        elif token == '.循环判断首':      # do … while: the condition is on the closing line
            body, end = parse_block(lines, index + 1, ('.循环判断尾',))
            assert end < len(lines), 'unclosed do-while'
            nodes.append(('dowhile', arguments(active_line(lines[end]))[0], body)); index = end + 1
        elif token == '.计次循环首':
            body, end = parse_block(lines, index + 1, ('.计次循环尾',))
            assert end < len(lines), 'unclosed repeat'
            count, variable = arguments(line)
            nodes.append(('repeat', count, variable, body)); index = end + 1
        elif token.startswith('.'):
            raise AssertionError('unsupported source control statement ' + line)
        else:
            nodes.append(('statement', line)); index += 1
    return nodes, index


SOURCE_FUNCTIONS = {}


def register_source_function(source, name):
    body = section(source, name)
    parameters = re.findall(r'^\.参数 ([^,]+),', body, re.M)
    nodes, _ = parse_block(body.splitlines())

    def invoke(*args):
        assert len(args) == len(parameters), 'wrong production helper arguments: ' + name
        try:
            execute(nodes, dict(zip(parameters, args)))
        except Returned as result:
            return result.value
        raise AssertionError('production helper did not return: ' + name)

    SOURCE_FUNCTIONS[name] = invoke


def evaluate(value, env):
    value = value.strip()
    if value == '': return None
    if value.startswith('“') and value.endswith('”'): return value[1:-1]
    if value == '真': return True
    if value == '假': return False
    if value == '{}': return b''
    if re.fullmatch(r'-?\d+', value): return int(value)
    match = re.fullmatch(r'([^\[()]+)\[(.+)\]', value)
    if match: return env[match.group(1)][evaluate(match.group(2), env) - 1]
    match = re.fullmatch(r'([^ ()]+)\s*\((.*)\)', value)
    if match:
        name, raw = match.groups()
        args = [evaluate(arg, env) for arg in split_args(raw)]
        functions = {
            '删首尾空': lambda x: x.strip(), '到小写': str.lower, '到大写': str.upper,
            '等于': lambda a, b: a == b, '不等于': lambda a, b: a != b,
            '小于': lambda a, b: a < b, '大于': lambda a, b: a > b,
            '大于或等于': lambda a, b: a >= b, '小于或等于': lambda a, b: a <= b,
            '位与': lambda a, b: a & b, '右移': lambda a, b: a >> b, '或者': lambda *a: any(a),
            '并且': lambda *a: all(a), '取反': lambda x: not x,
            '取文本左边': lambda x, n: x[:n], '取文本右边': lambda x, n: x[-n:] if n else '',
            '取文本长度': len, '取数组成员数': len,
            '相加': lambda *a: sum(a), '相减': lambda a, b: a - b,
            '相乘': lambda a, b: a * b, '选择': lambda condition, yes, no: yes if condition else no,
            '求余数': lambda a, b: a - int(a / b) * b,
            '分割文本': lambda text, sep, unused: text.split(sep), '到整数': int,
        }
        if name in SOURCE_FUNCTIONS:
            return SOURCE_FUNCTIONS[name](*args)
        assert name in functions, 'unhandled production expression ' + name
        return functions[name](*args)
    assert value in env, 'unknown production variable ' + value
    return env[value]


def execute(nodes, env):
    for node in nodes:
        if node[0] == 'if':
            if evaluate(node[1], env): execute(node[2], env)
        elif node[0] == 'switch':
            for condition, body in node[1]:
                if condition is None or evaluate(condition, env):
                    execute(body, env); break
        elif node[0] == 'repeat':
            for counter in range(1, evaluate(node[1], env) + 1):
                env[node[2]] = counter
                try: execute(node[3], env)
                except Broke: break
        else:
            line = node[1]
            if line.startswith('赋值 '):
                variable, value = arguments(line)
                env[variable] = evaluate(value, env)
            elif line.startswith('返回 '):
                raise Returned(evaluate(arguments(line)[0], env))
            elif line.startswith('跳出循环 '): raise Broke()
            else: raise AssertionError('unsupported production statement ' + line)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--module', type=Path,
                        default=Path(__file__).resolve().parents[4] / '模块/模块_电音助手.e~')
    parser.add_argument('--http-helper', type=Path, help='Actual shared EPL HTTP source; defaults to the bundled precision module')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    module = args.module.resolve()
    engine_path = module / '代码/程序集_机架联动引擎.static.e.txt'
    engine = engine_path.read_text('utf-8-sig')
    for name in ('机架引擎_较大值', '机架引擎_较小值'):
        register_source_function(engine, name)
    failures, checked = [], []
    def check(name, value):
        checked.append(name)
        if not value: failures.append(name)
    check('no_database_statistics_used_as_math', not re.search(r'(?<![\w])取(?:最大|最小)值\s*\(', engine))
    for left, right in [(-2147483648, 2147483647), (-24, -1), (-1, -24),
                        (0, 0), (1000, 30000), (30000, 1000)]:
        check(f'actual_numeric_max:{left}:{right}',
              SOURCE_FUNCTIONS['机架引擎_较大值'](left, right) == max(left, right))
        check(f'actual_numeric_min:{left}:{right}',
              SOURCE_FUNCTIONS['机架引擎_较小值'](left, right) == min(left, right))
    changed = ['代码/程序集_机架联动引擎.static.e.txt', '代码/程序集_播放器和基调查询.static.e.txt',
               '代码/类_播放记录.class.e.txt', '代码/类_基调查询.class.e.txt',
               '自定义类型.e.txt', '全局变量.e.txt']
    for name in changed:
        data = (module / name).read_bytes()
        check(name + ':BOM', data.startswith(b'\xef\xbb\xbf'))
        check(name + ':CRLF', b'\n' not in data.replace(b'\r\n', b''))
    # 电音助手模块的 DLL 声明已统一搬进精易模块（同主程序的做法）：模块不再有自己的 DLL.e.txt，
    # 机架联动/多语言用到的命令改用精易的公开声明。
    check('module_has_no_own_dll_file', not (module / 'DLL.e.txt').exists())
    jy_dll = (module.parent / '精易模块v9.3.5[源码].e~/DLL.e.txt').read_text('utf-8-sig')
    def jy_public(name):
        m = re.search(r'^\.DLL命令 ' + re.escape(name) + r', ?[^,\n]*, "[^"]*", "[^"]*", ?([^,\n]*)', jy_dll, re.M)
        return bool(m) and '公开' in m.group(1)
    moved = ['WaitForSingleObject', 'MessageBoxW_电音', 'InitializeCriticalSectionP', 'EnterCriticalSectionP',
             'LeaveCriticalSectionP', 'GetTickCount_电音', 'GetEnvironmentVariableA_电音', 'RtlGetVersion_电音',
             'CreateFileW', 'GetFileInformationByHandle_字节集', 'GetFileSizeEx_逻辑型', 'SetFilePointerEx_整数型',
             'ReadFile_整数型', 'CloseHandle']
    for name in moved:
        check('dll_moved_to_jingyi_public:' + name, jy_public(name))
    # 搬家后模块代码不得再调用旧的私有名字
    engine_src = (module / '代码/程序集_机架联动引擎.static.e.txt').read_text('utf-8-sig')
    player_src = (module / '代码/程序集_播放器和基调查询.static.e.txt').read_text('utf-8-sig')
    joined = engine_src + player_src + (module / '代码/类_播放记录.class.e.txt').read_text('utf-8-sig') + (module / '代码/类_电音助手.class.e.txt').read_text('utf-8-sig')
    # 注意：繁星日志_清缓存/繁星日志_取完整事件 是模块自己的子程序，集_繁星日志_* 是程序集变量，均保留；
    # 这里只核对搬进精易的那些旧 DLL 名不再作为调用出现。
    for old_name in ['繁星日志_CreateFileW', '繁星日志_ReadFile', '繁星日志_CloseHandle', '繁星日志_GetFileSizeEx',
                     '繁星日志_SetFilePointerEx', '繁星日志_GetFileInformationByHandle', 'MessageBoxW_多语言',
                     'InitializeCriticalSection_多语言', 'EnterCriticalSection_多语言', 'LeaveCriticalSection_多语言',
                     'GetTickCount_机架', 'GetEnvironmentVariableA_机架', 'RtlGetVersion_机架']:
        check('old_private_dll_name_gone:' + old_name, old_name + ' (' not in joined)
    detection = (module / '代码/程序集_播放器和基调查询.static.e.txt').read_text('utf-8-sig')
    check('detection_has_no_network', '基调查询.基调查询' not in section(detection, '取正在播放的音乐信息'))
    check('restart_reconfigures_and_replays', all(fragment in section(engine, '机架引擎_启动') for fragment in [
        '赋值 (集_机架_已配置, 假)', '赋值 (集_机架_已发版本, -1)',
        '赋值 (集_机架_目标版本, 相加', '赋值 (集_机架_查询版本, 相加']))
    check('exactly_two_EPL_workers', len(re.findall(r'启动线程 \(&', engine)) == 2)
    monitor = section(engine, '机架引擎_线程_监测')
    link = section(engine, '机架引擎_线程_联动')
    check('network_only_in_monitor', '.基调查询 (' in monitor and '.基调查询 (' not in link)
    check('stale_song_and_query_rejected', all(text in monitor for text in [
        '等于 (局_世代, 集_机架_歌曲世代)', '等于 (局_版本, 集_机架_查询版本)',
        '等于 (局_音乐, 集_机架_快照.音乐名W)']))
    check('800ms_fallback', '集_机架_检测时间), 800)' in link)
    check('same_song_force_refresh', all(text in section(engine, '机架引擎_强制刷新') for text in [
        '集_机架_目标版本, 相加', '集_机架_查询版本, 相加']))
    check('apply_generation_not_marked_stale', all(text in link for text in [
        '等于 (局_世代, 集_机架_歌曲世代)', '等于 (局_目标版本, 集_机架_目标版本)']))
    check('lock_blocks_apply', '取反 (局_快照.已锁定)' in link)
    check('persisted_feel_only_after_drag', '选择 (集_机架_强度已设置, 局_快照.当前强度, -1)' in link)
    check('dynamic_slider_max', '相除 (相乘 (位置, 1000), 最大值)' in section(engine, '机架引擎_电音强度'))
    query = (module / '代码/类_基调查询.class.e.txt').read_text('utf-8-sig')
    requests = http_call_lines(query)
    check('five_real_HTTP_calls', len(requests) == 5)
    check('no_duplicate_private_HTTP_implementation', '.子程序 基调安全请求,' not in query and 'WinHttp.WinHttpRequest' not in query)
    for number, line in enumerate(requests, 1):
        params = call_arguments(line, '网页_访问_对象')
        check(f'HTTP{number}:shared_strict_transport_body_status_and_timeouts', len(params) == 26 and
              params[0:3] == ['url', '1', ''] and params[7:10] == ['status', '真', 'API_基调查询_数据加密 (data)'] and
              params[19:21] == ['3', '5'] and params[25] == '真')
        check(f'HTTP{number}:explicit_valid_UserAgent_header', params[5].startswith('“User-Agent: ') and params[5].endswith('”'))
    helper_path = args.http_helper or http_helper_path(module)
    helper_bytes = helper_path.read_bytes()
    helper_source = helper_bytes.decode('utf-8-sig').replace('\r\n', '\n')
    http = section(helper_source, '网页_访问_对象')
    parameters = re.findall(r'^\.参数 ([^,]+),', http, re.M)
    check('shared_HTTP_append_only_optional_strict_parameter', len(parameters) == 26 and parameters[-1] == '严格校验证书' and
          '.参数 严格校验证书, 逻辑型, 可空,' in http)
    check('shared_HTTP_BOM_CRLF', helper_bytes.startswith(b'\xef\xbb\xbf') and b'\n' not in helper_bytes.replace(b'\r\n', b''))
    check('shared_HTTP_strict_opt_in_legacy_default_preserved', '局_WinHttp.写属性 (“Option”, 4, 选择 (严格校验证书, 0, 13056))' in http)
    check('shared_HTTP_explicit_connect_receive_timeouts', '局_WinHttp.方法 (“SetTimeouts”, 连接超时, 连接超时, 接收超时, 接收超时)' in http)
    check('shared_HTTP_redirect_option_retained', '.如果真 (禁止重定向)' in http and '局_WinHttp.写属性 (“Option”, 6, 0)' in http)
    check('shared_HTTP_scheme_guard_precedes_COM', http.index('“https://”') < http.index('线程_初始化COM库') and
          http.index('“http://”') < http.index('线程_初始化COM库'))
    check('shared_HTTP_failure_clears_status', http.index('赋值 (返回状态代码, 0)') < http.index('线程_初始化COM库'))
    record = (module / '代码/类_播放记录.class.e.txt').read_text('utf-8-sig')
    for name in ['记录', '取出', '取出_最后记录', '删除记录', '删除所有记录']:
        proc = section(record, name)
        check('record_lock:' + name, 'EnterCriticalSectionP (许可证)' in proc and
              'LeaveCriticalSectionP (许可证)' in proc)
    check('Unicode_accidentals_before_ANSI', all(fragment in query for fragment in [
        '{109, 38}', '{111, 38}', '返回 (编码_Unicode到Ansi (局_Unicode))']))
    for name in ('基调名_音高', '基调名_英文'):          # the normalization calls them: their real source runs too
        register_source_function(engine, name)
    norm = section(engine, '机架引擎_规范基调')
    nodes, end = parse_block(norm.splitlines())
    norm_parameters = re.findall(r'^\.参数 ([^,]+),', norm, re.M)
    assert len(norm_parameters) == 6, 'unexpected normalization parameter contract'
    def normalize(key, scale, transpose=0):
        env = dict(zip(norm_parameters[:3], (key, scale, transpose)))
        try: execute(nodes, env)
        except Returned as returned:
            return (bool(returned.value), *(env.get(name) for name in norm_parameters[3:]))
        raise AssertionError('production function did not return')
    # the names the server and old caches use (still accepted), and the standard English names shown now:
    # major Db / Ab, minor C# / G# (fewer accidentals in the key signature), the rest the same in both
    legacy = ['C', 'D-平行', 'D', 'E-平行', 'E', 'F', 'F-锋利', 'G', 'A-平行', 'A', 'B-平行', 'B']
    shown = {'大调': ['C', 'Db', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'],
             '小调': ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'G#', 'A', 'Bb', 'B']}
    for pitch, key in enumerate(legacy):
        for mode, scale in enumerate(['大调', '小调']):
            result = normalize(key, scale)
            check(f'canonical:{key}:{scale}', result == (True, pitch, mode, shown[scale][pitch]))
            check(f'english:{shown[scale][pitch]}:{scale}', normalize(shown[scale][pitch], scale) == result)
    check('display_follows_transpose', normalize('C', '大调', 1)[3] == 'Db' and normalize('C', '小调', 1)[3] == 'C#'
          and normalize('A', '小调', -1)[3] == 'G#' and normalize('Bbm', '', 0)[3] == 'Bb')
    check('english_scale_names', normalize('Db', 'Major') == (True, 1, 0, 'Db') and normalize('C#', 'Minor') == (True, 1, 1, 'C#')
          and normalize('A', ' minor ') == (True, 9, 1, 'A') and normalize('C', 'Chromatic')[1:] == (0, 2, 'Chromatic'))
    check('options_with_both_spellings', all(normalize(k, '大调')[1] == p for p, k in enumerate(
        ['C', 'C#/Db', 'D', 'D#/Eb', 'E', 'F', 'F#/Gb', 'G', 'G#/Ab', 'A', 'A#/Bb', 'B'])))
    for key, pitch in [('C#', 1), ('Db', 1), ('F#m', 6), ('Bbm', 10),
                       ('Cb', 11), ('Fb', 4), ('E#', 5), ('B#', 0)]:
        result = normalize(key, '')
        check('accidental:' + key, result[:3] == (True, pitch, 1 if key.endswith('m') else 0))
    # ♭ ♯ are not in GBK: EPL text cannot hold them (they become '?', which once made F♯ a flat); the query turns them
    # into b / # while the reply is still Unicode (the Unicode_accidentals_before_ANSI check above)
    for key in ['', 'H', 'C##', 'D-flat-invalid', '123', 'C major', 'D?', 'F?', 'D♭', 'F♯']:
        check('unknown:' + key, not normalize(key, 'Major')[0])
    for shift in [-24, -13, -12, -1, 0, 1, 12, 13, 24]:
        check('transpose:' + str(shift), normalize('C', 'Major', shift)[1] == shift % 12)
    check('unknown_scale', not normalize('C', 'Unknown')[0])
    check('chromatic', normalize('', 'Chromatic')[:3] == (True, 0, 2))
    ready_line = next(line.strip() for line in link.splitlines() if line.strip().startswith('赋值 (局_可推,'))
    ready_expression = arguments(ready_line)[1]
    ready_expression = ready_expression.replace('机架引擎_经过 (集_机架_检测时间)', 'ELAPSED')
    for music, known, elapsed, queried, expected in [
        (b'', False, 0, True, False), (b'', True, 800, True, False),
        (b'song', True, 0, False, True), (b'song', False, 799, False, False),
        (b'song', False, 800, False, True), (b'song', False, 0, True, True)]:
        env = {'局_快照.音乐名W': music, '局_已知': known, 'ELAPSED': elapsed,
               '集_机架_已查版本': 1 if queried else 0, '集_机架_查询版本': 1}
        check(f'actual_push_gate:{music}:{known}:{elapsed}:{queried}', evaluate(ready_expression, env) == expected)
    backoff_nodes, unused_end = parse_block(section(engine, '机架引擎_配置退避值').splitlines())
    for current, expected in [(0, 1000), (1000, 2000), (2000, 4000),
                              (4000, 5000), (5000, 5000), (10000, 5000)]:
        try: execute(backoff_nodes, {'当前': current})
        except Returned as returned: check(f'actual_config_backoff:{current}', returned.value == expected)
        else: check(f'actual_config_backoff:{current}:returned', False)
    retry_line = next(line.strip() for line in link.splitlines() if line.strip().startswith('赋值 (局_配置到期,'))
    retry_expression = arguments(retry_line)[1].replace('机架引擎_经过 (集_机架_配置重试时间)', 'ELAPSED')
    for elapsed, wait, expected in [(0, 0, True), (999, 1000, False), (1000, 1000, True),
                                     (4999, 5000, False), (5000, 5000, True)]:
        check(f'actual_config_due:{elapsed}:{wait}', evaluate(retry_expression,
              {'ELAPSED': elapsed, '集_机架_配置退避': wait}) == expected)
    check('config_retry_gate_and_instant_error_poll',
          '.如果真 (并且 (取反 (局_配置), 局_配置到期, 局_快照.已同意' in link
          and '.如果真 (并且 (取反 (局_配置), 局_快照.已同意, 集_机架_系统支持, 局_启用))\n        赋值 (局_错误, 机架引擎_宿主调用 (13, , , , ))' in link)
    check('explicit_actions_reset_config_backoff', all('赋值 (集_机架_配置退避, 0)' in section(engine, procedure)
          for procedure in ['机架引擎_启动', '机架引擎_处理控制请求',
                            '机架引擎_重新连接']) and
          '赋值 (集_机架_同意待处理, 真)' in section(engine, '机架引擎_同意') and
          '赋值 (集_机架_自动待处理, 真)' in section(engine, '机架引擎_自动切换'))
    check('steady_loop_period_preserved', '延时 (100)' in link)
    status_nodes, unused_end = parse_block(section(engine, '机架引擎_状态编号').splitlines())
    for packed, error, total, confirmed, expected in [
        (0x40000000, 1, 0, 0, 1), (0x40000000, 0, 0, 0, 1),
        (0x40000000, 4, 0, 0, 15), (0x40000000, 3, 0, 0, 19),
        (0, 2, 0, 0, 18), (0, 5, 0, 0, 6), (0, 8, 0, 0, 10),
        (0, 18, 0, 0, 16), (0, 11, 0, 0, 20), (0, 13, 0, 0, 21),
        (0x80000000, 0, 0, 0, 4), (0x80001001, 0, 1, 1, 2),
        (0x82001001, 0, 1, 1, 3), (0x84000000, 0, 0, 0, 6),
        (0xA0000000, 0, 0, 0, 7), (0x80000040, 0, 1, 0, 5)]:
        env = {'状态': packed, '错误': error, '快照.已锁定': False, '快照.总数': total,
               '快照.已确认': confirmed, '快照.实际基调': 'C', '快照.多播放器': False}
        try: execute(status_nodes, env)
        except Returned as returned:
            check(f'actual_status:{packed:x}:{error}', returned.value == expected)
        else: check(f'actual_status:{packed:x}:{error}:returned', False)
    os_nodes, unused_end = parse_block(section(engine, '机架引擎_系统版本支持').splitlines())
    for major, minor, expected in [(5, 1, False), (5, 2, False), (6, 0, False),
                                    (6, 1, True), (6, 2, True), (10, 0, True), (11, 0, True)]:
        try: execute(os_nodes, {'主版本': major, '次版本': minor})
        except Returned as returned:
            check(f'actual_OS_gate:{major}.{minor}', returned.value == expected)
        else: check(f'actual_OS_gate:{major}.{minor}:returned', False)
    check('OS_gate_avoids_legacy_ASM', '系统_取操作系统类别' not in engine and 'RtlGetVersion_电音' in engine)
    reconnect = section(engine, '机架引擎_重新连接')
    check('relogin_drops_previous_auth', '集_机架_登录世代' in reconnect and '赋值 (集_机架_重新配置, 真)' in reconnect and '机架引擎_宿主调用 (8,' in link)
    check('network_context_is_request_local', '局_查询对象.设置上下文 (局_API域名, 局_软件, 局_账号)' in monitor and '私_独立上下文' in query and '取上下文账号 ()' in query)
    edit = section(engine, '机架引擎_处理编辑')
    check('relogin_discards_queued_and_inflight_edits', all(fragment in edit for fragment in [
        '不等于 (集_机架_编辑[i].会话版本, 集_机架_登录世代)',
        '不等于 (局_请求.会话版本, 集_机架_登录世代)']))
    selector = section(engine, '机架引擎_取播放器选择')
    check('player_selection_returns_locked_text_copy', 'EnterCriticalSectionP' in selector and '赋值 (返回_播放器, 切换播放器模式_手动_当前播放器)' in selector)
    check('paused_controller_renews_without_auto_apply', '.判断开始 (局_配置)' in link and
          '并且 (局_启用, 取反 (局_快照.已锁定), 局_可推,' in link and
          '机架引擎_宿主调用 (16, 选择 (局_快照.自动切换, 0, 1)' in link and
          '并且 (取反 (局_快照.自动切换), 等于 (局_错误, 0))' in link)
    publish_nodes, unused_end = parse_block(section(engine, '机架引擎_发布').splitlines())
    types = (module / '自定义类型.e.txt').read_text('utf-8-sig')
    snapshot_type = types.split('.数据类型 自定义_机架联动快照', 1)[1].split('.数据类型 ', 1)[0]
    fields = [match.group(1) for match in re.finditer(r'^    \.成员 ([^,]+),', snapshot_type, re.M) if match.group(1) != '版本']
    for changed in [False, True]:
        env = {'集_机架_快照.版本': 5, '集_机架_快照': {}}
        for field in fields:
            env['集_机架_快照.' + field] = 0
            env['集_机架_已发布快照.' + field] = 0
        if changed: env['集_机架_快照.状态编号'] = 1
        execute(publish_nodes, env)
        check(f'actual_snapshot_version_changes_only_on_content:{changed}', env['集_机架_快照.版本'] == (6 if changed else 5))
    probe = section(engine, '机架引擎_机架运行')
    check('consent_probe_reads_all_existing_learned_locations', all(fragment in probe for fragment in [
        'LOCALAPPDATA', 'TEMP', 'at8_commdir.txt', 'dawhost.txt']) and '宿主调用' not in probe and '写到文件' not in probe)
    result = {'checks': len(checked), 'passed': len(checked) - len(failures), 'failures': failures,
              'source_sha256': {'engine': hashlib.sha256(engine_path.read_bytes()).hexdigest(), 'query': hashlib.sha256((module / '代码/类_基调查询.class.e.txt').read_bytes()).hexdigest(), 'shared_http': hashlib.sha256(helper_bytes).hexdigest()},
              'scope': 'source-extracted normalization execution and source invariants; no EPL compilation claimed'}
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
