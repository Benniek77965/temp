#!/usr/bin/env python3
"""电音助手窗口偶尔只显示背景图、播放器图标不出来（执行模块与宿主的真实 EPL 源码）。

原因：播放器列表（全_播放器查询信息：名字、图标、查询子程序）原来只在后台引擎启动时（机架引擎_启动，工作线程）才建；
引擎又是在窗口显示出来时（机架联动_界面已显示）才放到工作线程里启动。同一时刻界面线程马上 Edge_电音助手_刷新，
按 界面_取播放器数 拼文字 JSON（含图标）推给页面——这时列表多半还是空的；文字只在界面语言变了时才重推，图标就一直不出来。
另外引擎每次启动都 重定义数组 清空再逐个加入，与界面线程每 250 毫秒读列表同时进行（读到一半的列表、读到已释放的内存）。

修复：类_电音助手 创建时（程序启动，界面线程，还没有任何工作线程）就建好列表；播放器查询信息_初始化 只建一次，之后调用
（引擎启动时）什么也不做，列表从此只读；宿主重推文字的条件改为「界面语言或播放器个数变了」，万一推的时候列表还空，满了会补推。
同类问题：引擎第一次启动（工作线程）时引擎锁 集_机架_许可证 原来先交出去再初始化，界面线程这时刷新（机架引擎_快照）看到非 0 就进入，
进入全 0 的临界区会一直等下去；现在初始化好才交出来（执行真实的 机架引擎_启动 核对）。
模块后来把建列表的时机改为「第一次要用时」（类_电音助手.播放器列表_准备，在 集_配置许可 里调 播放器查询信息_初始化）：全局对象 电音助手 创建时
模块的全局数组还不能用。界面_取播放器数 因此会当场把空列表建好，本测试模拟「推的时候列表还空」时先拦住这一次重建；两种写法下各项核对都成立。

用 epl_machine 执行：模块的 类_电音助手（_初始化、界面_取播放器数、界面_取播放器）与 播放器查询信息_初始化；宿主的
Edge_电音助手_刷新、Edge_电音助手_文字JSON、Edge_电音助手_状态JSON。yyJSON构造、浏览器、资源图标、编码与 BASE64 为明确替身。
加 --epl 原工程的 epl 目录 时执行原代码，复现原问题（窗口第一次打开时页面收到 0 个播放器，引擎建好列表后也不再补推）。
不是易语言编译，也不是 Windows 实机（线程调度只按顺序模拟）。用法（在依赖库根目录）：python3 tests/epl_engine/test_dianyin_players.py [--epl 目录]
"""
import argparse
import base64
import json
import re
from pathlib import Path
import epl_machine as em

HERE = Path(__file__).resolve().parent
PLAYERS = ['酷狗音乐', 'QQ音乐', '网易云音乐', '汽水音乐', '酷我音乐', '全民K歌', '直播伴侣']


class Info:
    """自定义_播放器查询信息"""
    def __init__(self):
        self.名, self.图标, self.子程序指针_查询_正在播放的音乐 = '', b'', 0


class YyJson:
    """yyJSON构造 的替身：句柄 0（省略）为根对象。"""
    def __init__(self):
        self.root, self.nodes = None, {}

    def 创建_空对象(self):
        self.root, self.nodes = {}, {0: None}
        return True

    def _node(self, h):
        return self.root if not h else self.nodes[h]

    def _new(self, value):
        h = len(self.nodes) + 1
        self.nodes[h] = value
        return h

    def 置空数组(self, h, key, *_):
        a = []
        self._node(h)[key] = a
        return self._new(a)

    def 数组_置空对象(self, h, how, *_):
        o = {}
        self.nodes[h].append(o)
        return self._new(o)

    def 置文本(self, h, key, value, *_):
        self._node(h)[key] = value
        return True

    def 置整数(self, h, key, value, *_):
        self._node(h)[key] = value
        return True

    def 到JSON(self, *_):
        return json.dumps(self.root, ensure_ascii=True, separators=(',', ':'))

    def _销毁(self):
        pass


class Browser:
    def __init__(self):
        self.scripts = []

    def 执行JS_异步(self, code, *_):
        self.scripts.append(code)
        return True


class Assistant:
    """宿主看到的 电音助手 对象：界面_取播放器数／界面_取播放器 交给模块真实源码，其余界面接口给固定内容。"""
    def __init__(self, machine, obj):
        self.m, self.obj = machine, obj

    def _call(self, name, *args):
        return self.m.invoke(self.obj.cls.methods[name], [('lit', a) for a in args], {}, self.obj)

    def 界面_取播放器数(self):
        return self._call('界面_取播放器数')

    def 界面_取播放器(self, i, *_):
        return self._call('界面_取播放器', i)

    def 界面_取文字W(self, i):
        return ('文字%d' % i).encode('utf-16-le') + b'\0\0'

    def 界面_取选项数(self, kind):
        return 2

    def 界面_取选项W(self, kind, i):
        return ('项%d' % i).encode('utf-16-le') + b'\0\0'

    def 界面_取状态(self, *_):
        return None

    def 界面_取当前选项(self, kind):
        return 1


def build(epl):
    module = epl / '模块/模块_电音助手.e~'
    m = em.Machine()
    m.load_static((module / '代码/程序集_播放器和基调查询.static.e.txt').read_text('utf-8-sig'), names={'播放器查询信息_初始化'})
    m.load_class((module / '代码/类_电音助手.class.e.txt').read_text('utf-8-sig'))
    glob = (module / '全局变量.e.txt').read_text('utf-8-sig')
    assert re.search(r'^\.全局变量 全_播放器查询信息, 自定义_播放器查询信息, , , ?"0"', glob, re.M) or '全_播放器查询信息, 自定义_播放器查询信息' in glob
    m.global_types['全_播放器查询信息'], m.globals['全_播放器查询信息'] = ('自定义_播放器查询信息', True), []
    m.factories['自定义_播放器查询信息'] = Info
    m.builtins.update({'申请内存': lambda size, zero=None: 0x7100, 'InitializeCriticalSectionP': lambda p: None,   # 类_电音助手 创建时建配置锁（见 test_dianyin_config_lock.py）
                       'EnterCriticalSectionP': lambda p: None, 'LeaveCriticalSectionP': lambda p: None})
    for f in (module / '资源').glob('列表框_图标_*.Image.dat'):
        m.constants[f.name[:-len('.Image.dat')]] = f.read_bytes()
    base_int = m.builtins['到整数']
    m.builtins['到整数'] = lambda v: (abs(hash(v)) % 100000 + 1) if isinstance(v, str) and v.startswith('&') else base_int(v)
    m.redefines = 0
    base_redim = m.raw_builtins.get('重定义数组') or m.builtins.get('重定义数组')

    def redim(*a):                                  # 记下清空重建的次数（多线程下与界面线程读列表冲突的那一步）
        m.redefines += 1
        return base_redim(*a)
    if '重定义数组' in m.raw_builtins:
        m.raw_builtins['重定义数组'] = redim
    else:
        m.builtins['重定义数组'] = redim
    edge = (epl / '代码/集_Edge浏览器/程序集_Edge.static.e.txt').read_text('utf-8-sig')
    m.load_static(edge, names={'Edge_电音助手_刷新', 'Edge_电音助手_文字JSON', 'Edge_电音助手_状态JSON'})
    for name in ('集_电音_已载入句柄', '集_电音_文字语言', '集_电音_上次状态'):
        kind = re.search(r'^\.程序集变量 ' + name + r', ([^,]+),', edge, re.M).group(1).strip()
        m.global_types[name], m.globals[name] = (kind, False), em.DEFAULTS[kind]
    m.globals['集_电音_已载入句柄'] = 7
    m.browser = Browser()
    m.global_types['集_电音_浏览器'], m.globals['集_电音_浏览器'] = ('对象', False), m.browser
    m.factories['yyJSON构造'] = YyJson
    m.constants.update({'YJ_数组_加入': -1, 'YJ_生成标志_ANSI': 0})
    m.builtins.update({'多语言_当前语言': lambda: 'zh-Hans', '落_BASE64编码_ASM': lambda b: base64.b64encode(b).decode(),
                       '编码_Unicode到Utf8': lambda b: b.decode('utf-16-le', 'replace').encode('utf-8')})
    return m


def struct_factories(module):
    """模块 自定义类型.e.txt 里的数据类型 → 各成员取默认值的替身类。"""
    text = (module / '自定义类型.e.txt').read_text('utf-8-sig')
    out = {}
    for block in re.split(r'(?m)^(?=\.数据类型 )', text):
        m = re.match(r'\.数据类型 ([^,\s]+)', block)
        if not m:
            continue
        members = re.findall(r'^\s*\.成员 ([^,]+), ([^,]+),', block, re.M)
        def make(members=members):
            o = type('S', (), {})()
            for name, kind in members:
                setattr(o, name.strip(), em.DEFAULTS.get(kind.strip()))
            return o
        out[m.group(1)] = make
    return out


def engine_start_lock_order(epl):
    """执行真实的 机架引擎_启动（引擎第一次启动，工作线程）：InitializeCriticalSectionP 那一刻 集_机架_许可证 是否已经交出去（界面线程看得到）。"""
    module = epl / '模块/模块_电音助手.e~'
    m = em.Machine()
    m.load_static((module / '代码/程序集_机架联动引擎.static.e.txt').read_text('utf-8-sig'))
    for name, make in struct_factories(module).items():
        m.factories[name] = make
    for name, kind in (('切换播放器模式', '整数型'), ('切换播放器模式_手动_当前播放器', '文本型'), ('全_基调查询_API接口_域名', '文本型'),
                       ('全_软件类型', '整数型'), ('全_账号', '文本型')):
        m.global_types[name], m.globals[name] = (kind, False), em.DEFAULTS[kind]
    m.globals['集_机架_快照'] = m.factories['自定义_机架联动快照']()
    m.globals['集_机架_已发布快照'] = m.factories['自定义_机架联动快照']()
    seen = {}
    def init_cs(p):
        seen['published_at_init'] = m.globals['集_机架_许可证'] != 0
        seen['pointer'] = p
    def start_thread(env, args, raws):
        m.store(raws[2].strip(), 100 + len(seen.setdefault('threads', [])), env)
        seen['threads'].append(raws[0].strip())
        return True
    m.builtins.update({'申请内存': lambda size, zero=None: 0x5000, 'InitializeCriticalSectionP': init_cs,
                       'EnterCriticalSectionP': lambda p: None, 'LeaveCriticalSectionP': lambda p: None,
                       '机架引擎_系统支持': lambda: True, '机架引擎_记日志': lambda t: None, '播放器查询信息_初始化': lambda: None,
                       '系统_取数值注册项': lambda *a: 0, '系统_取文本注册项': lambda *a: '', 'GetTickCount_电音': lambda: 1000})
    m.raw_builtins['启动线程'] = start_thread
    m.constants.update({'HKEY_CURRENT_USER': -2147483647})
    ok = m.invoke(m.subs['机架引擎_启动'], [('lit', 'http://example.invalid'), ('lit', 3), ('lit', 'acc'), ('lit', 0)], {}, None)
    return ok, seen, m.globals['集_机架_许可证']


def players_pushed(m):
    """每次推给页面的文字（DY.texts）里有几个播放器图标。"""
    out = []
    for s in m.browser.scripts:
        if s.startswith('window.DY&&DY.texts('):
            out.append(len(json.loads(s[len('window.DY&&DY.texts('):-1])['players']))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--epl', type=Path, default=HERE.parents[3])
    opts = ap.parse_args()
    checks = []

    def check(name, ok):
        checks.append(name)
        assert ok, name

    # 程序启动：模块的全局对象 电音助手 创建（界面线程）
    m = build(opts.epl)
    obj = m.new_object('类_电音助手')
    host = Assistant(m, obj)
    m.global_types['电音助手'], m.globals['电音助手'] = ('对象', False), host
    at_start = host.界面_取播放器数()
    # 第一次打开窗口：页面报就绪 → 显示 → 后台引擎放到工作线程启动 → 界面线程马上刷新（引擎还没建列表）
    refresh = lambda: m.invoke(m.subs['Edge_电音助手_刷新'], [], {}, None)
    refresh()
    first = players_pushed(m)
    # 工作线程：机架引擎_启动 → 播放器查询信息_初始化
    before = [p.名 for p in m.globals['全_播放器查询信息']]
    redefines = m.redefines
    m.invoke(m.subs['播放器查询信息_初始化'], [], {}, None)
    engine_rebuilt = m.redefines > redefines
    after = [p.名 for p in m.globals['全_播放器查询信息']]
    # 之后界面线程每 250 毫秒刷新
    for _ in range(3):
        refresh()
    pushes = players_pushed(m)
    result = {'players_at_startup': at_start, 'players_in_first_push': first, 'engine_start_rebuilt_list': engine_rebuilt,
              'texts_pushes_players': pushes, 'player_order': after}
    started, seen, lock = engine_start_lock_order(opts.epl)
    result['engine_lock_published_before_initialized'] = seen.get('published_at_init')
    if opts.epl != HERE.parents[3]:
        print(json.dumps({'baseline': str(opts.epl), 'observed': result}, ensure_ascii=False))
        return
    check('engine_lock_initialized_before_it_is_published', started is True and seen.get('published_at_init') is False
          and lock == seen.get('pointer') == 0x5000 and seen.get('threads') == ['&机架引擎_线程_监测', '&机架引擎_线程_联动'])
    check('list_ready_when_the_object_is_created', at_start == len(PLAYERS) and before == PLAYERS)
    check('first_push_already_has_every_icon', first == [len(PLAYERS)])
    check('engine_start_never_clears_or_rebuilds_the_list', not engine_rebuilt and after == PLAYERS)
    check('icons_are_real_png_resources', all(p.图标[:8] == b'\x89PNG\r\n\x1a\n' for p in m.globals['全_播放器查询信息']))
    check('no_pointless_repush_while_unchanged', pushes == [len(PLAYERS)])
    # 防御：万一推的时候列表还是空的（例如将来有别的路径清空），列表满了要补推一次
    m2 = build(opts.epl)
    obj2 = m2.new_object('类_电音助手')
    host2 = Assistant(m2, obj2)
    m2.global_types['电音助手'], m2.globals['电音助手'] = ('对象', False), host2
    saved = m2.globals['全_播放器查询信息']
    m2.globals['全_播放器查询信息'] = []
    m2.builtins['播放器查询信息_初始化'] = lambda: None   # 这一次不让列表重建：界面_取播放器数 现在先调 播放器列表_准备（列表空着就当场建好），不拦住就模拟不出“推的时候列表还是空的”
    m2.invoke(m2.subs['Edge_电音助手_刷新'], [], {}, None)
    del m2.builtins['播放器查询信息_初始化']
    m2.globals['全_播放器查询信息'] = saved
    m2.invoke(m2.subs['Edge_电音助手_刷新'], [], {}, None)
    m2.invoke(m2.subs['Edge_电音助手_刷新'], [], {}, None)
    check('repushed_once_when_the_player_count_changes', players_pushed(m2) == [0, len(PLAYERS)])
    # 页面重新就绪（宿主清空 集_电音_文字语言）时照样重推
    m2.globals['集_电音_文字语言'] = ''
    m2.invoke(m2.subs['Edge_电音助手_刷新'], [], {}, None)
    check('ready_still_forces_a_repush', players_pushed(m2) == [0, len(PLAYERS), len(PLAYERS)])
    print(json.dumps({'checks': len(checks), 'passed': len(checks), 'observed': result}, ensure_ascii=False))


if __name__ == '__main__':
    main()
