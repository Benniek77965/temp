#!/usr/bin/env python3
"""Execute extracted production EPL control, cache, status and HTTPS statements.

Platform/COM calls are injected, rather than replaced engine implementations. This
does not compile EPL or test real Windows scheduling, WinHTTP or DAW plug-ins.
Pass --baseline to demonstrate the original failures against the saved input.
"""
from pathlib import Path
from types import SimpleNamespace
from copy import deepcopy
import argparse
import base64
import hashlib
import json
import re

import check as syntax


class NextIteration(Exception):
    pass


class Runtime:
    def __init__(self, source):
        self.source = source
        self.env = {}
        self.functions = {}
        self.depth = 0
        self.events = []
        self.registry = {}
        self.local_factories = {}
        self.last_locals = {}
        self.functions.update({
            'EnterCriticalSectionP': self.enter,
            'LeaveCriticalSectionP': self.leave,
            'InitializeCriticalSectionP': lambda *a: None,
            '系统_写文本注册项': self.write_registry,
            '系统_写数值注册项': self.write_registry,
            '系统_取文本注册项': self.read_registry,
            '系统_取数值注册项': lambda *args: self.read_registry(*args) or 0,
            '机架引擎_发布': lambda: self.events.append(('published',)),
            '机架引擎_毫秒': lambda: 1000,
            '机架引擎_经过': lambda tick: 1000 - tick,
            '编码_BASE64编码': lambda data: base64.b64encode(data).decode(),
            '删除Unicode结尾空白字节': lambda data, flag: data,
            '校验_取md5': lambda data, *unused: hashlib.md5(data).hexdigest(),
            '到循环尾': lambda: self.next_iteration(),
        })

    def next_iteration(self):
        raise NextIteration()

    def enter(self, license):
        self.depth += 1

    def leave(self, license):
        self.depth -= 1
        assert self.depth >= 0

    def write_registry(self, hive, path, kind, key, value, unused):
        self.registry[(path, key)] = value

    def read_registry(self, hive, path, key, unused):
        return self.registry.get((path, key), '')

    def resolve(self, value, env):
        if value in env:
            return env[value]
        if value in self.env:
            return self.env[value]
        indexed = re.fullmatch(r'([^\[()]+)\[(.+)\]', value)
        if indexed:
            return self.resolve(indexed.group(1), env)[self.evaluate(indexed.group(2), env) - 1]
        if '.' in value:
            obj, field = value.rsplit('.', 1)
            return getattr(self.resolve(obj, env), field)
        if value.startswith('#'):
            return value
        raise AssertionError('unknown source variable: ' + value)

    def assign(self, target, value, env):
        value = deepcopy(value)
        indexed = re.fullmatch(r'(.+?)\s*\[(.+)\]', target.strip())
        if indexed:                                      # 赋值 (数组[下标], 值): EPL arrays are one-based
            self.resolve(indexed.group(1).strip(), env)[self.evaluate(indexed.group(2), env) - 1] = value
            return
        if '.' in target:
            obj, field = target.rsplit('.', 1)
            setattr(self.resolve(obj, env), field, value)
        elif target.startswith('集_') or target.startswith('全_'):
            self.env[target] = value
        else:
            env[target] = value

    def evaluate(self, value, env):
        value = value.strip()
        if not value:
            return None
        if value.startswith('“') and value.endswith('”'):
            return value[1:-1]
        if value in ('真', '假'):
            return value == '真'
        if value == '{}':
            return b''
        if value.startswith('{') and value.endswith('}'):     # byte-array literal {251, 121, 0, 0}
            return bytes(int(x) for x in value[1:-1].split(','))
        if re.fullmatch(r'-?\d+', value):
            return int(value)
        # The exported object API permits chained reads: obj.读属性(...).取字节集().
        chained = re.fullmatch(r'(.+\))\.([^ ()]+)\s*\(\)', value)
        if chained:
            return getattr(self.evaluate(chained.group(1), env), chained.group(2))()
        call = re.fullmatch(r'([^ ()]+)\s*\((.*)\)', value)
        if call:
            name, raw = call.groups()
            if name == '是否为空':
                argument = raw.strip()
                assert argument in env, 'omission check needs a declared parameter: ' + argument
                return argument in env.get('_omitted_params', set())
            args = [self.evaluate(arg, env) for arg in syntax.split_args(raw)] if raw.strip() else []
            if name in self.functions:
                return self.functions[name](*args)
            if '.' in name:
                obj, method = name.rsplit('.', 1)
                return getattr(self.resolve(obj, env), method)(*args)
            if name.startswith(('机架引擎_', '基调名_', '音阶名_')):   # key and scale names live in the engine source too
                return self.invoke(name, *args)
            if name in ('WaitForSingleObject', 'CreateFileW', 'CloseHandle', 'GetTickCount_电音', 'GetFileInformationByHandle_字节集',
                        'GetFileSizeEx_逻辑型', 'SetFilePointerEx_整数型', 'ReadFile_整数型', 'GetEnvironmentVariableA_电音',
                        'RtlGetVersion_电音', 'MessageBoxW_电音'):
                return 0   # 搬进精易的 DLL：模拟执行里当作无副作用调用
            primitives = {
                '等于': lambda a, b: a == b, '不等于': lambda a, b: a != b,
                '小于': lambda a, b: a < b, '大于': lambda a, b: a > b,
                '大于或等于': lambda a, b: a >= b, '小于或等于': lambda a, b: a <= b,
                '位与': lambda a, b: a & b, '右移': lambda a, b: a >> b,
                '或者': lambda *a: any(a), '并且': lambda *a: all(a), '取反': lambda a: not a,
                '相加': lambda *a: ''.join(a) if a and isinstance(a[0], str) else b''.join(a) if a and isinstance(a[0], bytes) else sum(a),
                '相减': lambda a, b: a - b, '相乘': lambda a, b: a * b,
                '选择': lambda condition, a, b: a if condition else b,
                '到整数': int, '到小写': str.lower, '取文本左边': lambda text, count: text[:count],
                '取文本左边s': lambda text, count: text[:count], '取文本长度s': len,
                '取数组成员数': len, '删首尾空': str.strip,
                '多项选择': lambda index, *values: values[index - 1],
                '寻找文本s': lambda text, needle, *unused: text.find(needle) + 1 if needle in text else -1,
                '分割文本': lambda text, separator, unused: text.split(separator),
                '文本_取左边': lambda text, separator, *unused: text.partition(separator)[0],
                '到文本': str,
                '取文本长度': len, '取文本右边': lambda text, count: text[len(text) - count:] if count > 0 else '',
                '到大写': str.upper, '求余数': lambda a, b: a - int(a / b) * b,
            }
            assert name in primitives, 'unhandled source expression: ' + name
            return primitives[name](*args)
        return self.resolve(value, env)

    def execute(self, nodes, env):
        for node in nodes:
            if node[0] == 'if':
                if self.evaluate(node[1], env):
                    self.execute(node[2], env)
            elif node[0] == 'switch':
                for condition, body in node[1]:
                    if condition is None or self.evaluate(condition, env):
                        self.execute(body, env)
                        break
            elif node[0] == 'for':
                # .变量循环首 (起始值, 目标值, 递增值, 循环变量): after a normal end the variable is one step past the target
                first, last, step, variable = node[1]
                value, last, step = self.evaluate(first, env), self.evaluate(last, env), self.evaluate(step, env)
                self.assign(variable, value, env)
                while (step > 0 and value <= last) or (step < 0 and value >= last):
                    try:
                        self.execute(node[2], env)
                    except NextIteration:
                        pass
                    except syntax.Broke:
                        break
                    value = self.resolve(variable, env) + step
                    self.assign(variable, value, env)
            elif node[0] == 'while':
                rounds = 0
                while self.evaluate(node[1], env):
                    rounds += 1
                    assert rounds < 1000000, 'runaway while loop'   # fail fast instead of hanging
                    try:
                        self.execute(node[2], env)
                    except NextIteration:
                        continue
                    except syntax.Broke:
                        break
            elif node[0] == 'repeat':
                for counter in range(1, self.evaluate(node[1], env) + 1):
                    env[node[2]] = counter
                    try:
                        self.execute(node[3], env)
                    except syntax.Broke:
                        break
            else:
                line = node[1]
                if line.startswith('赋值 '):
                    name, value = syntax.arguments(line)
                    self.assign(name, self.evaluate(value, env), env)
                elif line.startswith('连续赋值 '):
                    value, *names = syntax.arguments(line)
                    for name in names:
                        self.assign(name, self.evaluate(value, env), env)
                elif line.startswith('返回 '):
                    raise syntax.Returned(self.evaluate(syntax.arguments(line)[0], env))
                elif line.startswith('跳出循环 '):
                    raise syntax.Broke()
                else:
                    self.evaluate(line, env)

    def execute_text(self, text, env):
        nodes, end = syntax.parse_block(text.splitlines())
        assert end == len(text.splitlines())
        self.execute(nodes, env)

    def invoke(self, name, *values):
        text = syntax.section(self.source, name)
        parameters = re.findall(r'^\.参数 ([^,]+),', text, re.M)
        assert len(values) <= len(parameters), (name, parameters, values)
        flags = [flag for flag in re.findall(r'^\.参数 [^,]+, [^,]+, ([^,\n]*),', text, re.M)]
        assert all('可空' in flag for flag in flags[len(values):]), (name, 'required argument omitted')
        values = (*values, *([None] * (len(parameters) - len(values))))
        parameter_types = {variable: kind for variable, kind in re.findall(r'^\.参数 ([^,]+), ([^,]+),', text, re.M)}
        omitted = {variable for variable, value in zip(parameters, values) if value is None}
        defaults = {'文本型': '', '字节集': b'', '逻辑型': False, '整数型': 0}
        env = {variable: defaults.get(parameter_types[variable]) if value is None else value
               for variable, value in zip(parameters, values)}
        env['_omitted_params'] = omitted
        for variable, type_name in re.findall(r'^\.局部变量 ([^,]+), ([^,]+),', text, re.M):
            env[variable] = self.local_factories[type_name]() if type_name in self.local_factories else '' if type_name == '文本型' else False if type_name == '逻辑型' else 0
        try:
            self.execute_text(text, env)
        except syntax.Returned as returned:
            self.last_locals = env
            return returned.value


def engine_runtime(source):
    runtime = Runtime(source)
    runtime.env.update({
        '集_机架_许可证': 1, '集_机架_运行': True, '集_机架_重新配置': False,
        '集_机架_快照': SimpleNamespace(已锁定=False, 自动切换=True, 已同意=True,
            需提示=False, 实际基调='C', 移调=0),
        '集_机架_锁定期望': False, '集_机架_锁定待处理': False,
        '集_机架_自动期望': True, '集_机架_自动待处理': False,
        '集_机架_同意期望': True, '集_机架_同意待处理': False,
        '集_机架_控制版本': 0, '集_机架_已处理控制版本': 0,
        '集_机架_目标版本': 12, '集_机架_歌曲世代': 5,
        '集_机架_停止请求': False, '集_机架_允许连接': True,
        '集_机架_配置退避': 5000,
        '集_机架_服务未开放': False,   # program-set default (假); policy hiding is covered by test_rack_visibility.py
        '集_机架_已配置': False, '集_机架_系统支持': True,   # program defaults: bridge not configured yet, supported system
    })
    return runtime


def link_segment(source):
    link = syntax.section(source, '机架引擎_线程_联动')
    start = link.index('        机架引擎_宿主调用 (16,') if '机架引擎_宿主调用 (16,' in link else link.index('        机架引擎_宿主调用 (2,')
    end = link.index('        .如果真 (并且 (局_启用, 局_强度请求', start)
    return link[start:end]


def interleave(source, action, when=2):
    runtime = engine_runtime(source)
    env = {'局_显示': False, '局_启用': True, '局_快照': deepcopy(runtime.env['集_机架_快照']),
           '局_可推': True, '局_目标版本': 12, '局_已发版本': 11, '局_世代': 5}
    apply_line = next(line for line in link_segment(source).splitlines()
                      if '机架引擎_宿主调用 (3,' in line)
    apply_arguments = syntax.call_arguments(apply_line, '机架引擎_宿主调用')
    assert len(apply_arguments) == 5 and apply_arguments[0] == '3'
    local_names = set(re.findall(r'^\.局部变量 ([^,]+),', syntax.section(source, '机架引擎_线程_联动'), re.M))
    assert set(apply_arguments[1:4]) <= local_names
    env.update(zip(apply_arguments[1:4], (0, 0, -1)))
    dispatched = []
    def host(operation, *args):
        assert runtime.depth == 0, 'engine lock held across host call'
        runtime.events.append(('host', operation))
        if operation == when:
            action(runtime)
        if operation == 3:
            dispatched.append(operation)
        return 0
    runtime.functions['机架引擎_宿主调用'] = host
    try:
        runtime.execute_text(link_segment(source), env)
    except NextIteration:
        pass
    assert runtime.depth == 0
    return runtime, dispatched


def clear_and_reload_cache(source, collide=False):
    runtime = engine_runtime(source)
    song = '歌曲A'.encode('utf-16le')
    path = runtime.invoke('机架引擎_缓存路径', song)
    runtime.registry.update({(path, 'song'): base64.b64encode(song).decode(),
        (path, 'key'): 'C', (path, 'scale'): '大调', (path, 'transpose'): 3,
        (path, 'source'): '手动', (path, 'time'): '2026-11-03 12:00:00'})
    if collide:
        runtime.registry[(path, 'song')] = base64.b64encode('另一首歌曲'.encode('utf-16le')).decode()
    edit = syntax.section(source, '机架引擎_处理编辑')
    start = edit.index('    机架引擎_缓存清除基调 (') if '机架引擎_缓存清除基调 (' in edit else edit.index('    赋值 (局_路径, 机架引擎_缓存路径 (')
    end = edit.index('    全_播放记录.删除记录', start)
    runtime.execute_text(edit[start:end], {'局_请求': SimpleNamespace(音乐名W=song)})
    runtime.env['集_机架_快照'].移调 = 0
    runtime.invoke('机架引擎_缓存读取', song)
    return runtime.env['集_机架_快照'].移调, runtime.registry


def http_execution(source, url, create=True, status=200, strict=True, query=None, call_index=0,
                   binary=True, redirected=False, legacy_arity=False):
    """Run the exact bundled public command with explicit COM/string boundaries.

    Optional-argument presence is modeled separately from its zero/empty value.
    The network, COM ABI and header/cookie helper boundaries are substitutes;
    request control, TLS selection, timeout conversion and body/status flow are
    extracted production statements, not a replacement HTTP client.
    """
    runtime = Runtime(source)
    calls = []
    payload = b'\x00\x80\xffencrypted-body'
    ua = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36'
    class Variant:
        def 赋值(self, data, unused):
            self.value = data
    class ByteResult:
        def 取字节集(self):
            return b'encrypted-response' if status else b''
    class Request:
        def 创建(self, name, unused):
            calls.append(('Create', name))
            return create
        def 方法(self, name, *args):
            if name == 'Send':
                args = (args[0].value if hasattr(args[0], 'value') else args[0],)
            calls.append((name, *args))
        def 写属性(self, name, index, value):
            calls.append((name, index, value))
        def 读数值属性(self, name, unused):
            calls.append(('read', name))
            return status
        def 读属性(self, name, unused):
            calls.append(('read', name))
            return ByteResult()
        def 读文本属性(self, name, unused):
            calls.append(('read', name))
            return ''  # response headers/cookies are an explicit boundary here
        def 清除(self):
            calls.append(('clear',))
    runtime.local_factories.update({'对象': Request, '变体型': Variant})
    runtime.functions.update({
        '线程_初始化COM库': lambda: calls.append(('COM_init',)),
        '线程_取消COM库': lambda: calls.append(('COM_uninit',)),
        '网页_处理协议头': lambda headers: headers,
        '内部_协议头取名': lambda header: header.partition(':')[0].strip(),
        '内部_协议头取值': lambda header: header.partition(':')[2].strip(),
        '网页_Cookie合并更新': lambda first, second: second or first,
        'API_基调查询_数据加密': lambda value: payload,
    })
    if query is None:
        values = [url, 1, 'legacy-text' if not binary else None, None, None, ua, None, 200,
                  not redirected, payload if binary else None, None, None, None, None, None,
                  None, None, None, None, 3, 5, None, None, None, None, strict]
    else:
        line = syntax.http_call_lines(query)[call_index]
        arguments = syntax.call_arguments(line, '网页_访问_对象')
        values = [runtime.evaluate(value, {'url': url, 'data': 'plaintext', 'status': 200})
                  for value in arguments]
    if legacy_arity:
        assert strict is None and query is None
        values = values[:25]  # actual old call arity; the appended parameter is absent
    response = runtime.invoke('网页_访问_对象', *values)
    return response, runtime.last_locals['返回状态代码'], calls


def player_read_branch(source, position):
    proc = syntax.section(source, '酷狗或聚星直播伴侣_查询_正在播放的音乐')
    start = proc.index('.如果真 (', proc.index('赋值 (找到的位置, 查找文件字节集'))
    end = proc.index('.如果真结束', start) + len('.如果真结束')
    runtime = Runtime(source)
    reads = []
    runtime.functions.update({
        '读文件字节集': lambda *args: reads.append(args) or b'test-event',
        '到字节集': lambda text: text.encode('gbk'),
        '字节集_取中间': lambda *args: b'eventInfo',
    })
    runtime.execute_text(proc[start:end], {'找到的位置': position, '文件号': 1, '#引号': '"'})
    return bool(reads)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--module', type=Path,
        default=Path(__file__).resolve().parents[4] / '模块/模块_电音助手.e~')
    parser.add_argument('--baseline', type=Path)
    parser.add_argument('--baseline-player', type=Path)
    parser.add_argument('--http-helper', type=Path, help='Actual shared EPL HTTP source; defaults to bundled precision module')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    source = (args.module / '代码/程序集_机架联动引擎.static.e.txt').read_text('utf-8-sig')
    query = (args.module / '代码/类_基调查询.class.e.txt').read_text('utf-8-sig')
    player = (args.module / '代码/程序集_播放器和基调查询.static.e.txt').read_text('utf-8-sig')
    helper_path = args.http_helper or syntax.http_helper_path(args.module)
    helper_bytes = helper_path.read_bytes()
    helper_source = helper_bytes.decode('utf-8-sig').replace('\r\n', '\n')
    tests = []
    def check(name, condition):
        tests.append({'name': name, 'passed': bool(condition)})

    actions = {
        'lock': lambda rt: rt.invoke('机架引擎_锁定', True),
        'auto_off': lambda rt: rt.invoke('机架引擎_自动切换', False),
        'consent_revoke': lambda rt: rt.invoke('机架引擎_同意', False),
        'stop': lambda rt: rt.env.update({'集_机架_运行': False}),
        'relogin': lambda rt: rt.env.update({'集_机架_重新配置': True}),
        'new_target': lambda rt: rt.env.update({'集_机架_目标版本': 13}),
        'new_song_generation': lambda rt: rt.env.update({'集_机架_歌曲世代': 6}),
    }
    before_results = {}
    baseline = args.baseline.read_text('utf-8-sig') if args.baseline else None
    for name, action in actions.items():
        runtime, dispatched = interleave(source, action)
        check('Host2_interleave_prevents_stale_apply:' + name, dispatched == [])
        if baseline:
            before_results['stale_apply:' + name] = bool(interleave(baseline, action)[1])

    runtime, dispatched = interleave(source, lambda rt: None)
    check('uninterrupted_loop_dispatches_apply', dispatched == [3])
    def queued_after_decision(rt):
        rt.invoke('机架引擎_锁定', True)
        check('unaccepted_lock_is_not_published_during_dispatch', not rt.env['集_机架_快照'].已锁定)
    runtime, dispatched = interleave(source, queued_after_decision, when=3)
    check('already_dispatching_apply_precedes_later_lock_acceptance', dispatched == [3] and runtime.env['集_机架_快照'].已锁定)
    check('accepted_request_version_matches', runtime.env['集_机架_已处理控制版本'] == runtime.env['集_机架_控制版本'])

    runtime = engine_runtime(source)
    runtime.invoke('机架引擎_切换锁定')
    runtime.invoke('机架引擎_切换锁定')
    runtime.invoke('机架引擎_处理控制请求')
    check('rapid_two_lock_toggles_cancel', not runtime.env['集_机架_快照'].已锁定)
    runtime.invoke('机架引擎_切换锁定')
    runtime.invoke('机架引擎_处理控制请求')
    check('third_lock_toggle_locks', runtime.env['集_机架_快照'].已锁定)
    version = runtime.env['集_机架_目标版本']
    runtime.invoke('机架引擎_锁定', False)
    runtime.invoke('机架引擎_处理控制请求')
    check('unlock_forces_current_target_replay', runtime.env['集_机架_目标版本'] == version + 1)
    runtime.invoke('机架引擎_自动切换', False)
    check('auto_desire_visible_before_acceptance', runtime.invoke('机架引擎_取自动期望') is False and runtime.env['集_机架_快照'].自动切换)
    runtime.invoke('机架引擎_自动切换', True)
    runtime.invoke('机架引擎_处理控制请求')
    check('rapid_off_on_preserves_latest_intent', runtime.env['集_机架_快照'].自动切换 and not runtime.env['集_机架_停止请求'])
    runtime.invoke('机架引擎_同意', False)
    runtime.invoke('机架引擎_自动切换', True)
    runtime.invoke('机架引擎_处理控制请求')
    check('auto_on_cannot_override_consent_revoke', not runtime.env['集_机架_快照'].已同意 and runtime.env['集_机架_停止请求'] and not runtime.env['集_机架_允许连接'])

    for error, expected in [(0, 2), (10, 1), (999, 3)]:
        runtime = engine_runtime(source)
        snapshot = SimpleNamespace(已锁定=False, 总数=1, 已确认=1, 实际基调='C', 多播放器=False)
        state = runtime.invoke('机架引擎_状态编号', 0x80001001, error, snapshot)
        check('cached_confirmed_status_error:' + str(error), state == expected)
        if baseline:
            before_results['cached_status_error:' + str(error)] = Runtime(baseline).invoke('机架引擎_状态编号', 0x80001001, error, snapshot)

    transpose, registry = clear_and_reload_cache(source)
    check('auto_redetection_preserves_per_song_transpose', transpose == 3)
    check('auto_redetection_invalidates_only_tone_metadata', all(value == '' for (path, key), value in registry.items() if key in ('key', 'scale', 'source', 'time')))
    check('auto_redetection_never_inherits_another_song_transpose', clear_and_reload_cache(source, collide=True)[0] == 0)
    if baseline:
        before_results['transpose_after_auto_redetection'] = clear_and_reload_cache(baseline)[0]
    # The former unbounded file-search branch has been replaced. Preserve its
    # baseline evidence; execute the current bounded reader in test_fanxing_log.py.
    if args.baseline_player:
        for position in (-1, 0, 128, 2147483712):
            before_results['player_read_at:' + str(position)] = player_read_branch(args.baseline_player.read_text('utf-8-sig'), position)
    player_proc = syntax.section(player, '酷狗或聚星直播伴侣_查询_正在播放的音乐')
    check('player_has_no_unbounded_search_or_copy', '查找文件字节集' not in player_proc and '文件_复制' not in player_proc)
    check('player_tail_offset_is_64bit', '.局部变量 局_起始, 长整数型,' in player_proc and '.局部变量 局_大小, 长整数型,' in player_proc)

    # Exercise the real control handler and link dispatch slice. OS/IPC remains
    # an injected boundary; source statements and ordering are not reimplemented.
    runtime = engine_runtime(source)
    runtime.env['集_机架_已配置'] = True
    version = runtime.env['集_机架_目标版本']
    runtime.invoke('机架引擎_自动切换', False)
    runtime.invoke('机架引擎_处理控制请求')
    check('accepted_auto_off_keeps_connection_and_does_not_stop',
          runtime.env['集_机架_已配置'] and runtime.env['集_机架_允许连接']
          and not runtime.env['集_机架_停止请求'] and not runtime.env['集_机架_快照'].自动切换)
    check('pause_invalidates_inflight_song_target', runtime.env['集_机架_目标版本'] == version + 1)
    current = runtime.env['集_机架_目标版本']
    calls = []
    runtime.functions['机架引擎_宿主调用'] = lambda operation,*args: calls.append((operation,args)) or 0
    env = {'局_启用':False,'局_快照':deepcopy(runtime.env['集_机架_快照']),
           '局_可推':True,'局_目标版本':current,'局_已发版本':-1,'局_世代':5,
           '局_键':0,'局_音阶编号':0,'局_强度':-1}
    runtime.execute_text(link_segment(source),env)
    check('paused_loop_sends_native_pause_then_keeps_tick_without_apply',
          calls == [(16,(1,None,None,None)),(2,(None,None,None,None))])
    runtime.invoke('机架引擎_自动切换',True)
    runtime.invoke('机架引擎_处理控制请求')
    check('resume_preserves_configuration_and_refreshes_current_target',
          runtime.env['集_机架_已配置'] and not runtime.env['集_机架_停止请求']
          and runtime.env['集_机架_目标版本']==current+1)
    for name,action in actions.items():
        rt,dispatched=interleave(source,action,when=16)
        check('pause_dispatch_interleave_prevents_stale_tick_apply:'+name,dispatched==[])
    runtime=engine_runtime(source)
    before=dict(runtime.env)
    runtime.invoke('机架引擎_打开控制器')
    check('headless_legacy_show_has_no_effect',runtime.env==before and not runtime.events)
    link=syntax.section(source,'机架引擎_线程_联动')
    gate=next(line.strip() for line in link.splitlines() if line.strip().startswith('.如果真 (并且 (取反 (局_配置), 局_配置到期'))
    expr=syntax.arguments(gate)[0]
    for auto,configured,expected in [(False,False,False),(True,False,True),(False,True,False)]:
        rt=engine_runtime(source);rt.env['集_机架_系统支持']=True
        local={'局_配置':configured,'局_配置到期':True,'局_快照':SimpleNamespace(已同意=True,音乐名W=b'x'),'局_启用':auto,'局_界面':True}
        check('cold_off_never_configures:'+str((auto,configured)),rt.evaluate(expr,local)==expected)
    # Everything else ready but no song yet: nothing is prepared (no bridge or controller written).
    rt=engine_runtime(source);rt.env['集_机架_系统支持']=True
    check('needs_a_song_before_configuring',rt.evaluate(expr,{'局_配置':False,'局_配置到期':True,'局_快照':SimpleNamespace(已同意=True,音乐名W=b''),'局_启用':True,'局_界面':True}) is False)
    # Everything ready and a song playing, but the 电音助手 window not on screen yet: nothing is prepared or downloaded.
    check('needs_the_window_on_screen_before_configuring',rt.evaluate(expr,{'局_配置':False,'局_配置到期':True,'局_快照':SimpleNamespace(已同意=True,音乐名W=b'x'),'局_启用':True,'局_界面':False}) is False
          and rt.evaluate(expr,{'局_配置':False,'局_配置到期':True,'局_快照':SimpleNamespace(已同意=True,音乐名W=b'x'),'局_启用':True,'局_界面':True}) is True)
    override=next(line.strip() for line in link.splitlines() if line.strip().startswith('.如果真 (并且 (取反 (局_快照.自动切换), 等于 (局_错误, 0))'))
    for error in (0,1,3,4,10,11,13):
        rt=engine_runtime(source)
        check('pause_never_hides_authorization_error:'+str(error),rt.evaluate(syntax.arguments(override)[0],{'局_快照':SimpleNamespace(自动切换=False),'局_错误':error})==(error==0))

    # Execute the existing precision-module command, not a private HTTP clone.
    http = syntax.section(helper_source, '网页_访问_对象')
    check('shared_strict_TLS_is_explicit_opt_in', '局_WinHttp.写属性 (“Option”, 4, 选择 (严格校验证书, 0, 13056))' in http)
    check('private_HTTP_clone_removed', '.子程序 基调安全请求,' not in query and 'WinHttp.WinHttpRequest' not in query)
    check('HTTP_scheme_allowlist_precedes_COM', http.index('“https://”') < http.index('线程_初始化COM库') and http.index('“http://”') < http.index('线程_初始化COM库'))
    requests = syntax.http_call_lines(query)
    check('five_query_call_sites_use_existing_command', len(requests) == 5)
    check('original_decryption_retained', query.count('基调响应_转Ansi (API_基调查询_数据解密 (res_字节集))') == 5)
    for index in range(len(requests)):
        response, status, calls = http_execution(helper_source, 'https://api.example/queryKey', query=query, call_index=index)
        label = 'actual_shared_HTTP_call' + str(index + 1) + ':'
        check(label + 'sends_original_encrypted_binary', ('Send', b'\x00\x80\xffencrypted-body') in calls)
        check(label + 'checks_TLS_before_send', calls.index(('Option', 4, 0)) < calls.index(('Send', b'\x00\x80\xffencrypted-body')))
        check(label + 'preserves_3_3_5_5_stage_timeouts', ('SetTimeouts', 3000, 3000, 5000, 5000) in calls)
        check(label + 'disables_redirects', ('Option', 6, 0) in calls)
        check(label + 'retains_POST_and_exact_URL', ('Open', 'POST', 'https://api.example/queryKey', False) in calls)
        check(label + 'preserves_necessary_headers', all(any(event[:2] == ('SetRequestHeader', header) for event in calls)
              for header in ['User-Agent', 'Accept', 'Referer', 'Accept-Language', 'Content-Type']))
        check(label + 'preserves_original_header_values', all(event in calls for event in [
            ('SetRequestHeader', 'Accept', '*/*'), ('SetRequestHeader', 'Referer', 'https://api.example/queryKey'),
            ('SetRequestHeader', 'Accept-Language', 'zh-cn'), ('SetRequestHeader', 'Content-Type', 'application/x-www-form-urlencoded'),
            ('SetRequestHeader', 'User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36')]))
        check(label + 'returns_status_body_and_balances_COM', status == 200 and response == b'encrypted-response' and calls[-2:] == [('clear',), ('COM_uninit',)])
    for url in ('http://api.example/queryKey', 'HTTPS://api.example/queryKey'):
        response, status, calls = http_execution(helper_source, url)
        check('actual_HTTP_preserves_allowed_scheme:' + url.split(':')[0], status == 200 and ('Send', b'\x00\x80\xffencrypted-body') in calls)
    for url in ('file:///etc/passwd', 'ftp://api.example/key', 'api.example/key', ''):
        response, status, calls = http_execution(helper_source, url)
        check('actual_HTTP_rejects_invalid_scheme_without_COM:' + url, response == b'' and status == 0 and calls == [])
    response, status, calls = http_execution(helper_source, 'https://api.example/queryKey', create=False)
    check('actual_HTTP_creation_failure_clears_status_and_balances_COM', response == b'' and status == 0 and calls == [('COM_init',), ('Create', 'WinHttp.WinHttpRequest.5.1'), ('COM_uninit',)])
    response, status, calls = http_execution(helper_source, 'https://api.example/queryKey', status=0)
    check('actual_HTTP_propagates_COM_transport_failure', response == b'' and status == 0 and calls[-1] == ('COM_uninit',))
    for code in (302, 404, 500):
        response, status, calls = http_execution(helper_source, 'https://api.example/queryKey', status=code)
        check('actual_HTTP_preserves_error_status_and_body:' + str(code), status == code and response == b'encrypted-response')
    for legacy in (None, False):
        response, status, calls = http_execution(helper_source, 'https://api.example/queryKey', strict=legacy)
        check('legacy_omitted_or_false_preserves_certificate_compatibility:' + str(legacy), status == 200 and ('Option', 4, 13056) in calls)
    response, status, calls = http_execution(helper_source, 'https://api.example/queryKey', strict=None, legacy_arity=True)
    check('legacy_actual_25_argument_call_remains_valid', status == 200 and ('Option', 4, 13056) in calls)
    response, status, calls = http_execution(helper_source, 'https://api.example/queryKey', strict=None, binary=False, redirected=True)
    check('legacy_text_submission_and_redirect_default_remain_available', status == 200 and ('Send', 'legacy-text') in calls and not any(event[:2] == ('Option', 6) for event in calls))
    # End to end with the real 机架引擎_发布 (the substitute above only records an event): the host's download
    # notice must reach the published snapshot the 250 ms UI timer reads — 23 while downloading, then back to 1.
    import copy
    def published_runtime():
        rt = engine_runtime(source)
        snap = dict(音乐名W=b'x', 播放器名='', 基调='C', 音阶='大调', 实际基调='C', 实际音阶='大调', 实际移调=0, 实际歌名W=b'x', 移调=0, 状态编号=1,
                    已确认=0, 总数=0, 自动切换=True, 已同意=True, 随启动=True, 已锁定=False, 支持速度=False, 当前强度=-1, 多播放器=False, 需提示=False,
                    来源=0, 更新时间=0, 自检结果=0, 版本=0)
        rt.env['集_机架_快照'], rt.env['集_机架_已发布快照'] = SimpleNamespace(**snap), SimpleNamespace(**snap)
        del rt.functions['机架引擎_发布']
        plain = rt.assign
        rt.assign = lambda name, value, env: plain(name, copy.copy(value) if name == '集_机架_已发布快照' else value, env)   # EPL copies a 自定义类型 on assignment
        return rt
    rt = published_runtime()
    rt.invoke('机架引擎_置下载中', True); during = (rt.env['集_机架_已发布快照'].状态编号, rt.env['集_机架_已发布快照'].版本)
    rt.invoke('机架引擎_置下载中', False); after = (rt.env['集_机架_已发布快照'].状态编号, rt.env['集_机架_已发布快照'].版本)
    # the notice stays after the download until op1 returns and the link thread recomputes (install, verify, load, configure)
    check('download_notice_reaches_the_published_snapshot_and_stays', during == (23, 1) and after == (23, 1))
    # Stop on window close, restart on reopen: a thread still stuck (downloading the bridge, a network query)
    # keeps its handle and blocks the next start; one that exited is closed and cleared. Executed for real.
    def reaper_runtime(alive):
        rt = engine_runtime(source)
        rt.env.update({'集_机架_联动线程': 11, '集_机架_监测线程': 22, '集_机架_运行': True})
        closed, logs, started = [], [], []
        rt.functions['WaitForSingleObject'] = lambda handle, ms: 258 if handle in alive else 0
        rt.functions['CloseHandle'] = lambda handle: closed.append(handle) or 1
        rt.functions['机架引擎_记日志'] = lambda text: logs.append(text)
        rt.functions['启动线程'] = lambda *a: started.append(a) or True
        return rt, closed, logs, started
    rt, closed, logs, started = reaper_runtime(alive={11})
    ok = rt.invoke('机架引擎_收线程', 30000)
    check('reap_keeps_a_stuck_thread_and_closes_an_exited_one', ok is False and closed == [22]
          and rt.env['集_机架_联动线程'] == 11 and rt.env['集_机架_监测线程'] == 0)
    rt, closed, logs, started = reaper_runtime(alive=set())
    ok = rt.invoke('机架引擎_停止并等待', 30000)
    check('stop_and_wait_stops_and_clears_both_threads', ok is True and rt.env['集_机架_运行'] is False and sorted(closed) == [11, 22]
          and rt.env['集_机架_联动线程'] == 0 and rt.env['集_机架_监测线程'] == 0)
    # Stopping publishes the state to show while not configured (real 机架引擎_发布): a reopened window never shows
    # the last session's state (e.g. "插件：已切到 …") while the new engine is still starting.
    rt, closed, logs, started = reaper_runtime(alive=set())
    del rt.functions['机架引擎_发布']
    snap = dict(音乐名W=b'x', 播放器名='', 基调='C', 音阶='大调', 实际基调='C', 实际音阶='大调', 实际移调=0, 实际歌名W=b'x', 移调=0, 状态编号=2, 已确认=1, 总数=1,
                自动切换=True, 已同意=True, 随启动=True, 已锁定=False, 支持速度=False, 当前强度=-1, 多播放器=False, 需提示=False, 来源=0, 更新时间=0, 自检结果=0, 版本=3)
    rt.env['集_机架_快照'], rt.env['集_机架_已发布快照'] = SimpleNamespace(**snap), SimpleNamespace(**snap)
    plain = rt.assign
    rt.assign = lambda name, value, env: plain(name, copy.copy(value) if name == '集_机架_已发布快照' else value, env)
    rt.invoke('机架引擎_停止并等待', 10000)
    check('stopping_publishes_the_unconfigured_state', rt.env['集_机架_已发布快照'].状态编号 == 1 and rt.env['集_机架_已发布快照'].版本 == 4)
    rt, closed, logs, started = reaper_runtime(alive={11})
    rt.env['集_机架_运行'] = False
    ok = rt.invoke('机架引擎_启动', 'https://api.example', 3, 'user', 0)
    check('restart_refuses_while_an_old_thread_is_still_running', ok is False and not started and rt.env['集_机架_联动线程'] == 11
          and any('还有线程没退出' in l for l in logs))
    result = {'checks': len(tests), 'passed': sum(t['passed'] for t in tests),
        'failures': [t['name'] for t in tests if not t['passed']], 'tests': tests,
        'baseline_observations': before_results,
        'source_sha256': {'engine': hashlib.sha256((args.module / '代码/程序集_机架联动引擎.static.e.txt').read_bytes()).hexdigest(), 'query': hashlib.sha256((args.module / '代码/类_基调查询.class.e.txt').read_bytes()).hexdigest(), 'shared_http': hashlib.sha256(helper_bytes).hexdigest()},
        'HTTP_scope': 'Full existing public HTTP procedure and five real call-site expressions; COM/network/header-cookie helper ABI boundaries substituted; optional-argument presence modeled separately from default zero values',
        'scope': 'extracted real EPL statements with injected platform calls; no EPL compiler, Windows COM, TLS or DAW runtime claim'}
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return bool(result['failures'])


if __name__ == '__main__':
    raise SystemExit(main())
