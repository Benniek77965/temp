#!/usr/bin/env python3
"""Execute the real 「打开缩小窗口」 hotkey decision (主窗口_热键_打开或缩小, reached through 热键_功能键_主线程执行),
the shared cover measure 遮挡_取被盖住比例 / 遮挡_算不算 / 遮挡_分层全透明 / 遮挡_是否被其拥有 and the three other
callers that used the naive 「any visible window above whose rectangle touches mine」 test (restore-all-settings result
visibility, the old popup's forced display, the 电音助手 keep-on-top timer).

Not an EPL compiler and not a Windows run: epl_machine runs the production source over a modelled desktop (Z order top
to bottom, rectangles, topmost band, owner, visibility, minimised, DWM cloak, layered / click-through styles, layered
alpha). Win32 calls are explicit substitutes; 主窗口_置于前台 is a substitute that activates (or, when the system
refuses, only raises within the band, as its real fallback does) and lets 「fighter」 windows put themselves back on top.

--baseline-zip ORIGINAL.zip additionally runs the original code from that archive over the same desktops and checks it
gets stuck (every press only 「brings to front」, the window never hides) where the new code alternates.
"""
from pathlib import Path
import argparse
import json
import random
import re
import struct
import zipfile

import check as syntax
import epl_machine as em

HERE = Path(__file__).resolve().parent
EPL = HERE.parents[3]
MAIN = '代码/窗_主程序/窗口程序集_主窗口.form.e.txt'
COMMON = '代码/集_公共函数/程序集1.static.e.txt'
RECORDER = '代码/窗_音效/窗口程序集_窗口_录音器.form.e.txt'
EDGE = '代码/集_Edge浏览器/程序集_Edge.static.e.txt'
RESTORE = '代码/窗_设置/窗口程序集_窗口_恢复所有设置.form.e.txt'
POPUP = '代码/窗_主程序/窗口程序集_窗口_弹窗提醒.form.e.txt'
JY = '模块/精易模块v9.3.5[源码].e~/代码/窗口句柄/集_窗口句柄.static.e.txt'
GLOBALS = '全局变量.e.txt'
OWN, CHILD, EXPLORER, GAME, OTHER = 1000, 4321, 10, 700, 800
MAIN_H = 100
LAYERED, TRANSPARENT = 0x80000, 0x20
GLWA = 0x77001234


DECL = ('.子程序', '.参数', '.局部变量', '.程序集变量', '.全局变量', '.程序集', '.DLL命令', '.常量', '.数据类型', '.成员')


def code_only(text):
    """Executable statements only: comments and the description column of declarations are documentation."""
    return '\n'.join(syntax.active_line(l) for l in text.splitlines() if not l.lstrip().startswith(DECL))


def tree_files():
    return {k: (EPL / k).read_text('utf-8-sig') for k in (MAIN, COMMON, RECORDER, EDGE, RESTORE, POPUP, JY, GLOBALS)}


def zip_files(path):
    with zipfile.ZipFile(path, metadata_encoding='gbk') as z:
        names = {n.split('/epl/', 1)[1]: n for n in z.namelist() if '/epl/' in n}
        return {k: z.read(names[k]).decode('utf-8-sig') for k in (MAIN, COMMON, RECORDER, EDGE, RESTORE, POPUP, JY, GLOBALS)}


class Win:
    def __init__(self, h, l, t, r, b, pid=OTHER, owner=0, visible=True, iconic=False, topmost=False, ex=0, cloaked=0,
                 alpha=None, cls='AppWindow', style=0, maximized=False):
        self.maximized = maximized
        self.h, self.rect, self.pid, self.owner, self.visible, self.iconic = h, [l, t, r, b], pid, owner, visible, iconic
        self.topmost, self.ex, self.cloaked, self.alpha, self.cls, self.style = topmost, ex, cloaked, alpha, cls, style


SCREEN = [((0, 0, 1920, 1080), (0, 0, 1920, 1040))]          # (monitor, work area); the taskbar takes the bottom 40 px


class Desk:
    def __init__(self, wins, fg=0, monitors=None):
        self.monitors = monitors or SCREEN
        self.w = {x.h: x for x in wins}
        self.z = [x.h for x in wins]          # top to bottom
        self.fg = fg

    def above(self, h):
        i = self.z.index(h)
        return self.z[i - 1] if i > 0 else 0

    def owned_by(self, k, h):
        o, n = self.w[k].owner, 0
        while o and n < 50:
            if o == h:
                return True
            o, n = self.w[o].owner if o in self.w else 0, n + 1
        return False

    def raise_top(self, h):
        """Top of its band; its owned windows of the same band stay right above it (system rule)."""
        band = self.w[h].topmost
        owned = [k for k in self.z if k != h and self.owned_by(k, h) and self.w[k].topmost == band]
        for k in [h] + owned:
            self.z.remove(k)
        at = 0 if band else next((i for i, k in enumerate(self.z) if not self.w[k].topmost), len(self.z))
        self.z[at:at] = owned + [h]


class Rect:
    def __init__(self):
        self.左边 = self.顶边 = self.右边 = self.底边 = 0


class WinInfo:
    def __init__(self):
        self.cbSize, self.rcWindow, self.rcClient, self.dwStyle, self.dwExStyle = 0, Rect(), Rect(), 0, 0
        self.dwWindowStatus = self.cxWindowBorders = self.cyWindowBorders = self.atomWindowType = self.wCreatorVersion = 0


class Frame:
    """黑月_主窗口: 可视 () reads IsWindowVisible, 可视 (假) hides and fires the real 被隐藏 event."""
    def __init__(self, sim):
        self.sim = sim

    def 取窗口句柄(self):
        return MAIN_H

    def 是否已创建(self):
        return True

    def 位置(self):
        return 2 if self.sim.desk.w[MAIN_H].iconic else 0

    def 可视(self, value=None):
        w = self.sim.desk.w[MAIN_H]
        if value is None:
            return w.visible
        changed, w.visible = w.visible != value, value
        if changed and not value and '黑月_主窗口_被隐藏' in self.sim.subs:
            self.sim.invoke(self.sim.subs['黑月_主窗口_被隐藏'], [('lit', MAIN_H)], {}, None)
        return True

    def 托盘气泡提示W(self, *args):
        self.sim.balloons += 1

    def 托盘气泡提示(self, *args):                       # the ANSI variant some projects call in their hide handler
        self.sim.balloons += 1


class Switch:
    def 选中(self):
        return True


class Sim(em.Machine):
    def __init__(self, desk, files, old=False):
        super().__init__()
        self.desk, self.old, self.now, self.delay = desk, old, 100000, 0
        self.allow_activation, self.modal, self.fighters = True, 0, []
        self.logs, self.brought, self.balloons, self.events, self.sorts, self.dispatch = [], [], 0, [], 0, 0
        self.addr = {}
        self.positions = []
        jy = files[JY]
        self.load_static(jy, names={'窗口_是否置顶', '窗口_是否最小化', '窗口_是否被遮挡'})
        main_names = {'热键_功能键_主线程执行', '黑月_主窗口_被激活', '黑月_主窗口_被隐藏', '主窗口_置于前台_移回屏幕'}
        if old:
            self.load_static(files[RECORDER], names={'主窗口_是否被遮挡_不算录音器窗口'})
            self.declare(files[MAIN], ['集_热键_打开缩小窗口时刻'])
        else:
            main_names |= {'主窗口_热键_打开或缩小', '主窗口_置于前台_在屏幕外'}
            self.load_static(files[COMMON], names={'遮挡_取被盖住比例', '遮挡_算不算', '遮挡_分层全透明', '遮挡_是否被其拥有', '遮挡_是否隐身', '外框点击守护_查隐身'})
            self.declare(files[COMMON], ['集_遮挡_分层接口', '集_遮挡_分层接口已取'])
            self.declare(files[MAIN], ['集_热键_打开缩小窗口时刻', '集_热键_未激活时前台', '集_热键_未激活已记'])
            self.load_static(files[EDGE], names={'Edge_电音助手_被遮挡'})
            self.declare(files[EDGE], ['集_电音_窗口'])
            self.load_static(files[RESTORE], names={'恢复所有设置HTML_判定用户在看'})
            self.declare(files[RESTORE], ['集_恢复HTML_前端在等', '集_恢复HTML_判定'])
        self.load_static(files[MAIN], names=main_names)
        for m in re.finditer(r'^\.全局变量 ([^,\r\n]+), ([^,\r\n]+), [^,\r\n]*, ("[^"]*")?', files[GLOBALS], re.M):   # the project's own globals (the event handlers of each project use their own)
            name, kind = m.group(1).strip(), m.group(2).strip()
            if name and kind in em.DEFAULTS:
                self.global_types[name] = (kind, m.group(3) is not None)
                self.globals[name] = [] if m.group(3) is not None else em.DEFAULTS[kind]
        for name, kind, value in (('全_是否关闭本软件', '逻辑型', False), ('全_主窗口是否创建成功', '逻辑型', True),
                                  ('全_是否为WIN7以下的系统', '逻辑型', False)):
            self.global_types[name], self.globals[name] = (kind, False), value
        for name, value in (('黑月_主窗口', Frame(self)), ('黑月_选择框_主播音效_开启热键', Switch()), ('窗口_音效', type('W', (), {'可视': True})())):
            self.global_types[name], self.globals[name] = ('对象', False), value
        self.constants.update({'GWL_EXSTYLE': -20, 'WS_EX_TOPMOST': 8, 'GWL_STYLE': -16, 'WS_CHILD': 1073741824, 'GW_HWNDPREV': 3,
                               'GW_HWNDLAST': 1, '日志级别_INFO': 1, '日志级别_WARNING': 4, '窗口位置_最小化': 2})
        self.factories['精易_矩形'] = Rect
        self.factories['WINDOWINFO'] = WinInfo
        w = lambda h: self.desk.w[h]
        self.builtins.update({
            'GetNextWindow': lambda h, flag: self.note('GetNextWindow') or (self.desk.above(h) if flag == 3 else self.fail('GetNextWindow flag')),
            'IsWindowVisible': lambda h: self.note('IsWindowVisible') or w(h).visible,
            '_窗口是否可见': lambda h: self.note('IsWindowVisible') or w(h).visible,   # 精易模块 DLL.e.txt 里 IsWindowVisible 的别名（主工程现在按这个名字调用，见那里的说明）
            'IsIconic': lambda h: self.note('IsIconic') or w(h).iconic,
            'GetWindow': lambda h, kind: self.note('GetWindow') or (w(h).owner if kind == 4 else self.fail('GetWindow kind')),
            'GetWindowLongA': lambda h, i: self.note('GetWindowLongA') or (w(h).ex | (8 if w(h).topmost else 0) if i == -20 else w(h).style),
            'GetForegroundWindow': lambda: self.note('GetForegroundWindow') or self.desk.fg,
            'GetModuleHandleA': lambda name: 0x77000000 if name == 'user32.dll' else 0,
            'GetProcAddress': lambda module, name: GLWA if (module, name) == (0x77000000, 'GetLayeredWindowAttributes') else 0,
            '主窗口_置于前台': self.bring, '主窗口_置于前台_取目标': lambda h: self.modal or h,
            '系统_取启动时间': lambda: self.now, '写日志_本地': lambda text, level: self.logs.append(text),
            '窗口_取类名': lambda h: w(h).cls if h in self.desk.w else '',
            '调试输出': lambda *a: None, '取程序名称': lambda *a: '', '窗口_置状态': lambda *a: True,
            '多语言_动态文字W': lambda *a: b'', '删除Unicode结尾空白字节': lambda *a: b'', '设置对话框_可用HTML': lambda: True,
            '处理事件': lambda: self.note('处理事件'), 'GetDesktopWindow': lambda: 1, 'GetParent': lambda h: 0,
            'IsZoomed': lambda h: w(h).maximized, 'MonitorFromRect': self.monitor_from_rect, 'GetMonitorInfoA': self.monitor_info,
            'SetWindowPos': self.set_pos,
            '主进程音效页_是否启用': lambda: False, '音效子进程_窗口宿主PID': lambda: CHILD, '进程内独立_是独立窗口': lambda h: False})
        self.raw_builtins.update({'GetWindowRect': self.rect, 'GetWindowThreadProcessId': self.pid, 'DwmGetWindowAttribute': self.dwm,
                                  '取变量数据地址': self.address, '调用桩_4参数': self.stub, '数组排序': self.sort, 'GetWindowInfo': self.info,
                                  '是否已创建': lambda env, args, raws: False})     # other windows of the project (not modelled): not created
        self.builtins['窗口_还原'] = lambda h: True
        self.calls = []

    def declare(self, text, names):
        for name in names:
            m = re.search(r'^\.(?:程序集变量|全局变量) ' + re.escape(name) + r', ([^,]+), [^,]*, ("[^"]*")?', text, re.M)
            assert m, 'declaration missing: ' + name
            self.global_types[name] = (m.group(1).strip(), False)
            self.globals[name] = em.DEFAULTS[m.group(1).strip()]

    def note(self, name):
        self.calls.append(name)

    @staticmethod
    def fail(what):
        raise AssertionError(what)

    # ---- substitutes that write through 参考 / 传址 arguments
    def rect(self, env, args, raws):
        self.note('GetWindowRect')
        h, target = self.ev(args[0], env), self.ev(args[1], env)
        if h not in self.desk.w:
            return False
        target.左边, target.顶边, target.右边, target.底边 = self.desk.w[h].rect
        return True

    def info(self, env, args, raws):
        h, target = self.ev(args[0], env), self.ev(args[1], env)
        target.rcWindow.左边, target.rcWindow.顶边, target.rcWindow.右边, target.rcWindow.底边 = self.desk.w[h].rect
        target.dwStyle = self.desk.w[h].style
        return True

    def pid(self, env, args, raws):
        self.note('GetWindowThreadProcessId')
        h = self.ev(args[0], env)
        self.store(raws[1].strip(), self.desk.w[h].pid if h in self.desk.w else 0, env)
        return 1

    def dwm(self, env, args, raws):
        self.note('DwmGetWindowAttribute')
        h, attribute = self.ev(args[0], env), self.ev(args[1], env)
        assert attribute == 14
        self.store(raws[2].strip(), self.desk.w[h].cloaked, env)
        return 0

    def address(self, env, args, raws):
        """取变量数据地址: the same variable keeps the same data address while it is not reallocated."""
        name = raws[0].strip()
        for base, (scope, known) in self.addr.items():
            if scope is env and known == name:
                return base
        base = 0x10000000 + 0x100 * (len(self.addr) + 1)
        self.addr[base] = (env, name)
        return base

    def stub(self, env, args, raws):
        values = [self.ev(a, env) for a in args]
        assert values[0] == GLWA, ('unexpected call stub target', values[0])
        self.note('GetLayeredWindowAttributes')
        h, key, alpha, flags = values[1:]
        assert alpha == key + 4 and flags == key + 8, 'outputs must be the 3 slots of one buffer'
        win = self.desk.w[h]
        if not (win.ex & LAYERED) or win.alpha is None:       # not layered, or drawn per pixel (UpdateLayeredWindow): the call fails
            return 0
        scope, name = self.addr[key]
        self.store(name, struct.pack('<IBxxxI', 0, win.alpha, 2), scope)
        return 1

    def bytes_at(self, address):
        scope, name = self.addr[address]
        return scope, name, self.read(name, scope)

    def monitor_from_rect(self, address, flags):
        _, _, data = self.bytes_at(address)
        l, t, r, b = struct.unpack('<4i', data[:16])
        def score(m):
            ml, mt, mr, mb = m[0]
            area = max(0, min(r, mr) - max(l, ml)) * max(0, min(b, mb) - max(t, mt))
            dx, dy = max(ml - r, l - mr, 0), max(mt - b, t - mb, 0)
            return (area, -(dx * dx + dy * dy))
        best = max(range(len(self.desk.monitors)), key=lambda i: score(self.desk.monitors[i]))
        return 0x5000 + best if (flags == 2 or score(self.desk.monitors[best])[0] > 0) else 0

    def monitor_info(self, handle, address):
        scope, name, data = self.bytes_at(address)
        assert len(data) == 40 and struct.unpack('<i', data[:4])[0] == 40, 'MONITORINFO cbSize must be 40'
        mon, work = self.desk.monitors[handle - 0x5000]
        self.store(name, struct.pack('<i4i4ii', 40, *mon, *work, 1 if handle == 0x5000 else 0), scope)
        return 1

    def set_pos(self, h, after, x, y, cx, cy, flags):
        self.positions.append((h, after, x, y, cx, cy, flags))
        if not flags & 2 and h in self.desk.w:            # SWP_NOMOVE not set: move, keeping the size under SWP_NOSIZE
            r = self.desk.w[h].rect
            r[:] = [x, y, x + (r[2] - r[0] if flags & 1 else cx), y + (r[3] - r[1] if flags & 1 else cy)]
        return 1

    def sort(self, env, args, raws):
        self.sorts += 1
        values = self.ev(args[0], env)
        ascending = self.ev(args[1], env) if len(args) > 1 else True
        values.sort(reverse=not ascending)

    # ---- 主窗口_置于前台 substitute: activate, or (refused) raise within the band like its 无激活提层 fallback
    def bring(self, source, moment):
        self.brought.append(source)
        main = self.desk.w[MAIN_H]
        main.visible, main.iconic = True, False
        self.invoke(self.subs['主窗口_置于前台_移回屏幕'], [('lit', MAIN_H)], {}, None)    # step ① of the real 主窗口_置于前台: the real mover
        fresh = abs(self.now - moment) < 3000
        if self.allow_activation:
            main.cloaked = 0                      # activating a window on another virtual desktop switches to it: the shell uncloaks it
            self.desk.raise_top(MAIN_H)
            self.desk.fg = self.modal or MAIN_H
            self.invoke(self.subs['黑月_主窗口_被激活'], [('lit', MAIN_H)], {}, None)
            done = True
        else:
            if fresh:
                self.desk.raise_top(MAIN_H)
            done = False
        for f in self.fighters:
            self.desk.raise_top(f)
        return done

    def press(self):
        """One hotkey press, delivered to the main thread like 可靠投递 does."""
        self.now += 1000
        self.globals['集_热键_打开缩小窗口时刻'] = self.now - self.delay
        before, visible = len(self.brought), self.desk.w[MAIN_H].visible
        self.invoke(self.subs['热键_功能键_主线程执行'], [('lit', '打开缩小窗口')], {}, None)
        if visible and not self.desk.w[MAIN_H].visible:
            return 'hide'
        return 'front' if len(self.brought) > before else 'nothing'

    def cover(self, h, same_band, middle):
        return self.out('遮挡_取被盖住比例', [h, same_band, middle], [('局_遮挡', '整数型')])


# ---------------------------------------------------------------------------------------------------- desktops
TASKBAR = lambda: Win(10, 0, 1040, 1920, 1080, pid=EXPLORER, topmost=True, cls='Shell_TrayWnd')


def desk_with(extra_above, main_rect=(510, 170, 1410, 870), fg=MAIN_H, below=(), main_top=False):
    main = Win(MAIN_H, *main_rect, pid=OWN, topmost=main_top, cls='zyWindow')
    tops = [x for x in extra_above if x.topmost]
    normals = [x for x in extra_above if not x.topmost]
    wins = tops + ([main, TASKBAR()] + normals if main_top else [TASKBAR()] + normals + [main]) + list(below)
    return Desk(wins, fg)


GAME_BELOW = Win(30, 0, 0, 1920, 1040, pid=GAME, cls='UnityWndClass')

FALSE_COVERS = {   # windows that stay above the main window although bringing it to the front can never get above them
    'taskbar_overlap_20px': dict(extra=[], main_rect=(510, 360, 1410, 1060)),
    'taskbar_touching_edge': dict(extra=[], main_rect=(510, 340, 1410, 1040)),
    'click_through_overlay_fullscreen': dict(extra=[Win(40, 0, 0, 1920, 1080, pid=900, topmost=True, ex=LAYERED | TRANSPARENT | 0x80 | 0x8000000, cls='CEF-OSC-WIDGET')]),
    'cloaked_window_topmost': dict(extra=[Win(48, 0, 0, 1920, 1080, pid=902, topmost=True, cloaked=2, cls='Windows.UI.Core.CoreWindow')]),
    'cloaked_window_normal_band': dict(extra=[Win(41, 0, 0, 1920, 1040, pid=901, cloaked=2, cls='ApplicationFrameWindow')]),
    'alpha0_layered_normal_band': dict(extra=[Win(42, 300, 100, 1600, 1000, pid=902, ex=LAYERED, alpha=0, cls='HiddenHost')]),
    'own_floating_window_topmost': dict(extra=[Win(43, 1300, 120, 1500, 300, pid=OWN, topmost=True, ex=0x80, cls='XhhFloat')]),
    'own_desk_notify_topmost': dict(extra=[Win(44, 1300, 780, 1910, 1030, pid=OWN, topmost=True, ex=0x80, cls='DeskNotify')]),
    'owned_nonmodal_dialog': dict(extra=[Win(45, 700, 300, 1200, 700, pid=OWN, owner=MAIN_H, cls='zyWindow')]),
    'desktop_lyrics_topmost_layered': dict(extra=[Win(46, 200, 700, 1700, 820, pid=903, topmost=True, ex=LAYERED, alpha=None, cls='DesktopLyrics')]),
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-zip', type=Path, help='the original delivered zip: also reproduce the old stuck behaviour')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    files = tree_files()
    checks, report = [], {}

    def check(name, passed, detail=None):
        checks.append(name)
        assert passed, (name, detail)

    def run(desk, presses, **setup):
        sim = Sim(desk, files)
        for k, v in setup.items():
            setattr(sim, k, v)
        return sim, [sim.press() for _ in range(presses)]

    # ---- the reported bug: open window + something that stays above it -> the hotkey must hide it at once
    for name, spec in FALSE_COVERS.items():
        for fg in (MAIN_H, GAME):
            d = desk_with(spec['extra'], spec.get('main_rect', (510, 170, 1410, 870)), fg=MAIN_H if fg == MAIN_H else 30, below=[GAME_BELOW])
            sim, out = run(d, 3)
            check(f'hides_at_once:{name}:fg={"main" if fg == MAIN_H else "game"}', out == ['hide', 'front', 'hide'], (out, sim.logs))
    # the recorder window in the child process (owned by the main window): already excluded before, still fine
    d = desk_with([Win(47, 600, 200, 1000, 500, pid=CHILD, owner=MAIN_H, cls='Chrome_WidgetWin_1')], fg=47, below=[GAME_BELOW])
    sim, out = run(d, 2)
    check('recorder_window_foreground_counts_as_ours', out == ['hide', 'front'] and '前台是主窗口或它拥有的窗口' in sim.logs[0], sim.logs)

    # ---- real covers: bring to front first, then hide
    browser = Win(50, 300, 100, 1300, 900, pid=OTHER, cls='Chrome_WidgetWin_1')
    sim, out = run(desk_with([browser], fg=50, below=[GAME_BELOW]), 2)
    check('real_cover_brings_to_front_then_hides', out == ['front', 'hide'] and '被同一层的窗口盖住' in sim.logs[0] and 'Chrome_WidgetWin_1' in sim.logs[0], sim.logs)
    sliver = Win(51, 1403, 0, 1920, 1040, pid=OTHER)       # a window snapped next to it: only its invisible 7 px border overlaps
    sim, out = run(desk_with([sliver], fg=51), 1)
    check('adjacent_window_border_is_not_a_cover', out == ['hide'] and '同一层被盖住 0%' in sim.logs[0], sim.logs)
    corner = Win(52, 1300, 700, 1600, 1000, pid=OTHER)     # 110x170 of 900x700 = 2.9 %
    sim, out = run(desk_with([corner], fg=52), 1)
    check('small_corner_overlap_below_5_percent_hides', out == ['hide'], sim.logs)
    sim, out = run(desk_with([Win(53, 510, 170, 1410, 870, pid=OTHER)], fg=53, main_top=False), 1)
    check('fully_covered_brings_to_front', out == ['front'] and '同一层被盖住 100%' in sim.logs[0], sim.logs)
    # main window set always-on-top: a topmost window above it is in its band and does count
    d = desk_with([Win(54, 300, 100, 900, 600, pid=OTHER, topmost=True)], fg=54, main_top=True)
    sim, out = run(d, 2)
    check('topmost_main_window_counts_topmost_covers', out == ['front', 'hide'], sim.logs)

    # ---- the main window itself cloaked (on another virtual desktop): the user cannot see it -> bring it, never hide it first
    d = desk_with([], fg=30, below=[GAME_BELOW]); d.w[MAIN_H].cloaked = 2
    sim, out = run(d, 2)
    check('cloaked_main_window_is_brought_not_hidden', out == ['front', 'hide'] and 'DWM 隐身' in sim.logs[0], sim.logs)
    d = desk_with([], fg=30, below=[GAME_BELOW]); d.w[MAIN_H].cloaked = 2
    sim, out = run(d, 2, allow_activation=False)          # the system refuses to switch desktops: the safety net still alternates
    check('cloaked_main_and_refused_activation_still_alternate', out == ['front', 'hide'], sim.logs)

    # ---- the main window left almost entirely off-screen (display change): the user cannot see it -> bring it back, never hide it first
    d = desk_with([], (1850, 170, 2750, 870), fg=30, below=[GAME_BELOW])
    sim, out = run(d, 2)
    check('offscreen_main_window_is_brought_back_not_hidden', out == ['front', 'hide'] and '屏幕外' in sim.logs[0]
          and sim.desk.w[MAIN_H].rect == [1020, 170, 1920, 870] and any('已移到 1020,170' in x for x in sim.logs), sim.logs)
    d = desk_with([], (1700, 170, 2600, 870), fg=30, below=[GAME_BELOW])      # 220 px still on screen: the user can drag it, it is seen
    sim, out = run(d, 1)
    check('partly_offscreen_but_operable_is_seen', out == ['hide'], sim.logs)
    d = desk_with([], (1850, 170, 2750, 870), fg=30, below=[GAME_BELOW]); d.w[MAIN_H].maximized = True
    sim, out = run(d, 1)
    check('maximised_window_is_left_to_the_system', out == ['hide'], sim.logs)

    # ---- states
    d = desk_with([], fg=30, below=[GAME_BELOW]); d.w[MAIN_H].visible = False
    sim, out = run(d, 2)
    check('hidden_shows_then_hides', out == ['front', 'hide'] and '显示' in sim.logs[0], (out, sim.logs))
    d = desk_with([], fg=30, below=[GAME_BELOW]); d.w[MAIN_H].iconic = True
    sim, out = run(d, 2)
    check('minimised_restores_then_hides', out == ['front', 'hide'] and '还原' in sim.logs[0], sim.logs)
    dialog = Win(55, 760, 370, 1160, 670, pid=OWN, owner=MAIN_H, cls='#32770')
    sim, out = run(desk_with([dialog], fg=55), 3, modal=55)
    check('modal_dialog_is_only_brought_to_front_never_hidden', out == ['front'] * 3 and sim.desk.w[MAIN_H].visible and '模态' in sim.logs[0], sim.logs)

    # ---- the safety net: activation refused and a window that keeps putting itself back on top
    fighter = Win(56, 300, 100, 1700, 1000, pid=OTHER, cls='Fighter')
    sim, out = run(desk_with([fighter], fg=56), 4, allow_activation=False, fighters=[56])
    check('fighter_and_refused_activation_still_alternate', out == ['front', 'hide', 'front', 'hide'] and '没能激活主窗口' in sim.logs[0] and '上一次提到前面没能激活它' in sim.logs[1], sim.logs)
    sim = Sim(desk_with([fighter], fg=56), files); sim.allow_activation, sim.fighters = False, [56]
    first = sim.press()
    sim.invoke(sim.subs['黑月_主窗口_被激活'], [('lit', MAIN_H)], {}, None)     # the user clicked the main window in between
    sim.desk.fg = 56; sim.desk.raise_top(56)
    check('activation_in_between_voids_the_record', [first, sim.press()] == ['front', 'front'], sim.logs)
    sim = Sim(desk_with([fighter], fg=56), files); sim.allow_activation, sim.fighters = False, [56]
    sim.press(); sim.desk.w[MAIN_H].visible = False
    sim.invoke(sim.subs['黑月_主窗口_被隐藏'], [('lit', MAIN_H)], {}, None)
    sim.desk.w[MAIN_H].visible = True
    check('hiding_voids_the_record', sim.press() == 'front', sim.logs)
    sim = Sim(desk_with([fighter], fg=56), files); sim.allow_activation, sim.fighters, sim.delay = False, [56], 4000
    first = sim.press(); sim.delay = 0
    check('stale_request_leaves_no_record', [first, sim.press(), sim.press()] == ['front', 'front', 'hide'], sim.logs)
    sim = Sim(desk_with([fighter], fg=0), files); sim.allow_activation, sim.fighters = False, [56]
    check('foreground_switching_null_still_alternates', [sim.press(), sim.press()] == ['front', 'hide'], sim.logs)

    # ---- property: from any non-modal state, two presses with nothing else happening always contain a hide
    rng = random.Random(20261107)
    stuck = 0
    for trial in range(1500):
        wins = []
        for i in range(rng.randint(0, 6)):
            l, t = rng.randint(-200, 1800), rng.randint(-200, 1000)
            wins.append(Win(200 + i, l, t, l + rng.randint(5, 1600), t + rng.randint(5, 1000), pid=rng.choice([OTHER, OWN, CHILD, 901]),
                            owner=MAIN_H if rng.random() < 0.15 else 0, visible=rng.random() < 0.9, iconic=rng.random() < 0.05,
                            topmost=rng.random() < 0.4, ex=rng.choice([0, 0, LAYERED, LAYERED | TRANSPARENT]),
                            cloaked=rng.choice([0, 0, 0, 2]), alpha=rng.choice([None, 0, 255])))
        mt = rng.random() < 0.2
        ml, mtp = rng.choice([rng.randint(-100, 1500), rng.randint(-1300, 2900)]), rng.choice([rng.randint(-100, 900), rng.randint(-900, 1500)])
        d = desk_with(wins, (ml, mtp, ml + rng.randint(300, 1200), mtp + rng.randint(200, 900)), fg=rng.choice([0, MAIN_H, 30] + [x.h for x in wins]), below=[GAME_BELOW], main_top=mt)
        d.w[MAIN_H].visible, d.w[MAIN_H].iconic, d.w[MAIN_H].cloaked = rng.random() < 0.85, rng.random() < 0.1, rng.choice([0, 0, 0, 0, 2])
        sim = Sim(d, files)
        sim.allow_activation = rng.random() < 0.6
        sim.fighters = [x.h for x in wins if not x.topmost and not x.owner and rng.random() < 0.3]
        out = [sim.press(), sim.press()]
        if 'hide' not in out:
            stuck += 1
    check('property_two_presses_always_include_a_hide', stuck == 0, stuck)

    # ---- the shared measure itself
    plain = Desk([Win(1, 0, 0, 600, 1000), Win(2, 400, 0, 1000, 500), Win(MAIN_H, 0, 0, 1000, 1000, pid=OWN)])
    sim = Sim(plain, files)
    check('union_counts_overlap_once', sim.cover(MAIN_H, True, False) == (80, 1))
    sim = Sim(Desk([Win(3, -500, -500, 200, 200), Win(MAIN_H, 0, 0, 1000, 1000, pid=OWN)]), files)
    check('clipped_to_the_window', sim.cover(MAIN_H, True, False)[0] == 4)
    sim = Sim(Desk([Win(4, 0, 1000, 1000, 1100), Win(5, 1000, 0, 1100, 1000), Win(MAIN_H, 0, 0, 1000, 1000, pid=OWN)]), files)
    check('edge_to_edge_is_not_overlap', sim.cover(MAIN_H, True, False) == (0, 0))
    sim = Sim(Desk([Win(6, 0, 800, 1000, 1000), Win(MAIN_H, 0, 0, 1000, 1000, pid=OWN)]), files)
    check('middle_only_ignores_a_bottom_strip', sim.cover(MAIN_H, False, True)[0] == 0 and sim.cover(MAIN_H, False, False)[0] == 20)
    sim = Sim(Desk([Win(7, 0, 0, 290, 1000), Win(MAIN_H, 0, 0, 1000, 1000, pid=OWN)]), files)
    check('exact_ratio_not_rounded_down', sim.cover(MAIN_H, True, False)[0] == 29)
    sim = Sim(Desk([Win(8, -10, -10, 1010, 1010), Win(9, 0, 0, 10, 10), Win(MAIN_H, 0, 0, 1000, 1000, pid=OWN)]), files)
    check('full_cover_short_circuits', sim.cover(MAIN_H, True, False) == (100, 8) and sim.sorts == 0)
    many = [Win(300 + i, (i % 20) * 50, (i // 20) * 50, (i % 20) * 50 + 50, (i // 20) * 50 + 50) for i in range(100)]
    sim = Sim(Desk(many + [Win(MAIN_H, 0, 0, 1000, 1000, pid=OWN)]), files)
    check('at_most_64_rectangles', sim.cover(MAIN_H, True, False)[0] == 16)
    ghosts = [Win(2000 + i, 0, 0, 10, 10, visible=False) for i in range(1500)]
    sim = Sim(Desk(ghosts + [Win(MAIN_H, 0, 0, 1000, 1000, pid=OWN)]), files)
    sim.cover(MAIN_H, True, False)
    check('at_most_1000_windows_looked_at', sim.calls.count('GetNextWindow') == 1001)
    owned = Desk([Win(10, 0, 0, 1000, 1000, pid=OWN, owner=11), Win(11, 0, 0, 10, 10, pid=OWN, owner=MAIN_H), Win(MAIN_H, 0, 0, 1000, 1000, pid=OWN)])
    sim = Sim(owned, files)
    check('owned_windows_skipped_only_when_asking_about_raising', sim.cover(MAIN_H, True, False)[0] == 0 and sim.cover(MAIN_H, False, False)[0] == 100)
    sim = Sim(Desk([Win(12, 0, 0, 1000, 1000, ex=LAYERED, alpha=255), Win(MAIN_H, 0, 0, 1000, 1000, pid=OWN)]), files)
    check('opaque_layered_window_counts', sim.cover(MAIN_H, True, False)[0] == 100 and 'GetLayeredWindowAttributes' in sim.calls)
    sim = Sim(Desk([Win(13, 0, 0, 1000, 1000, iconic=True), Win(MAIN_H, 0, 0, 1000, 1000, pid=OWN)]), files)
    check('minimised_window_ignored', sim.cover(MAIN_H, True, False)[0] == 0)
    sim = Sim(Desk([Win(14, 0, 0, 1000, 1000, cloaked=2), Win(MAIN_H, 0, 0, 1000, 1000, pid=OWN)]), files)
    sim.globals['全_是否为WIN7以下的系统'] = True                      # XP: DWM not queried, nothing treated as cloaked
    check('no_dwm_means_not_cloaked', sim.cover(MAIN_H, True, False)[0] == 100 and 'DwmGetWindowAttribute' not in sim.calls)
    allowed = {'GetWindowRect', 'GetNextWindow', 'IsWindowVisible', 'IsIconic', 'GetWindow', 'GetWindowLongA', 'DwmGetWindowAttribute', 'GetLayeredWindowAttributes'}
    mixed = Sim(Desk([Win(15, 0, 0, 500, 500, ex=LAYERED, alpha=255), Win(16, 0, 0, 900, 900, cloaked=2), Win(MAIN_H, 0, 0, 1000, 1000, pid=OWN)]), files)
    mixed.cover(MAIN_H, True, False)
    check('measure_only_reads_window_data', set(mixed.calls) <= allowed and {'DwmGetWindowAttribute', 'GetLayeredWindowAttributes'} <= set(mixed.calls), mixed.calls)

    # ---- the other callers
    def edge(desk):
        sim = Sim(desk, files)
        sim.globals['集_电音_窗口'] = 60
        return sim.invoke(sim.subs['Edge_电音助手_被遮挡'], [], {}, None)
    me = lambda: Win(60, 1500, 100, 1800, 400, pid=OWN, topmost=True, ex=0x80, cls='STATIC')
    check('dianyin_raised_for_a_real_topmost_cover', edge(Desk([Win(61, 1400, 0, 1700, 300, pid=OTHER, topmost=True), me()])) is True)
    check('dianyin_not_raised_for_cloaked_or_click_through_or_own_popup',
          edge(Desk([Win(62, 0, 0, 1920, 1080, topmost=True, cloaked=2), Win(63, 0, 0, 1920, 1080, topmost=True, ex=LAYERED | TRANSPARENT),
                     Win(64, 1500, 100, 1700, 300, pid=OWN, owner=60, topmost=True), me()])) is False)

    def restore(desk):
        sim = Sim(desk, files)
        sim.globals['集_恢复HTML_前端在等'] = True
        sim.invoke(sim.subs['恢复所有设置HTML_判定用户在看'], [], {}, None)
        return sim.globals['集_恢复HTML_判定']
    check('restore_result_visible_with_window_under_taskbar', restore(desk_with([], (510, 360, 1410, 1060), fg=MAIN_H)) == 1)
    check('restore_result_visible_through_overlay', restore(desk_with(FALSE_COVERS['click_through_overlay_fullscreen']['extra'], fg=MAIN_H)) == 1)
    check('restore_result_hidden_by_topmost_game', restore(desk_with([Win(65, 0, 0, 1920, 1080, pid=GAME, topmost=True)], fg=65)) == 2)
    d = desk_with([], fg=MAIN_H); d.w[MAIN_H].cloaked = 2
    check('restore_result_not_seen_on_another_virtual_desktop', restore(d) == 2)
    check('restore_result_hidden_by_own_window_over_the_middle', restore(desk_with([Win(66, 600, 250, 1300, 800, pid=CHILD, owner=MAIN_H)], fg=66)) == 2)

    # the old popup re-parented into another program's window (窗口_置父彗星 changes GWL_STYLE only): it keeps its topmost
    # extended style as a child; its siblings (the host's controls) still count, there is no band or owner among children
    child = 0x40000000
    host_kids = lambda: [Win(81, 1500, 850, 1800, 1000, pid=950, style=child), Win(82, 0, 0, 400, 300, pid=950, style=child),
                         Win(80, 1600, 900, 1900, 1030, pid=OWN, topmost=True, style=child, cls='zyWindow')]
    sim = Sim(Desk(host_kids()), files)
    got = sim.cover(80, True, False)                       # 200x100 of the 300x130 popup = 51 %
    check('child_popup_counts_overlapping_sibling_despite_kept_topmost_style', got == (200 * 100 * 100 // (300 * 130), 81), got)
    tops = host_kids()
    for x in tops:
        x.style = 0                                          # the same layout as top-level windows: a non-topmost window cannot cover a topmost one when raising
    check('same_layout_top_level_keeps_band_rule', Sim(Desk(tops), files).cover(80, True, False)[0] == 0)
    kids = host_kids(); kids[0].rect = [0, 0, 100, 100]
    check('child_popup_not_covered_when_siblings_elsewhere', Sim(Desk(kids), files).cover(80, True, False)[0] == 0)
    popup = lambda: Win(70, 1620, 900, 1920, 1040, pid=OWN, topmost=True, ex=0x80, cls='zyWindow')
    tb_above = Desk([TASKBAR(), popup()])
    sim = Sim(tb_above, files)
    check('popup_touching_taskbar_not_covered', sim.cover(70, True, False)[0] == 0)
    active = code_only(files[POPUP])
    check('popup_raise_uses_shared_measure_and_never_activates', '大于 (遮挡_取被盖住比例 (窗口_弹窗提醒.取窗口句柄 (), 真, 假, ), 0)' in active
          and '窗口_置顶 (窗口_弹窗提醒.取窗口句柄 (), 假)' in active and '窗口_强制显示' not in active and '窗口_是否被遮挡' not in active)

    # ---- source-level invariants
    code = lambda text, name: code_only(syntax.section(text, name))
    new_code = '\n'.join(code(files[COMMON], n) for n in ('遮挡_取被盖住比例', '遮挡_算不算', '遮挡_分层全透明', '遮挡_是否被其拥有', '遮挡_是否隐身')) + code(files[MAIN], '主窗口_热键_打开或缩小')
    check('new_code_sends_no_message_and_pumps_nothing', not re.search(r'处理事件|SendMessage|PostMessage|GetWindowText|窗口_取标题|窗口_枚举', new_code))
    check('old_helpers_removed', '主窗口_是否被遮挡_不算录音器窗口' not in files[RECORDER] and '.子程序 进程内独立_是独立窗口' not in files[EDGE])
    all_active = '\n'.join(code_only(files[k]) for k in (MAIN, RECORDER, EDGE, RESTORE, POPUP, COMMON))
    check('no_naive_cover_test_left_in_project_code', '窗口_是否被遮挡 (' not in all_active)
    for line in new_code.splitlines():
        body = re.sub(r'“[^”]*”', '', line)
        check('one_statement_per_line_balanced:' + line.strip()[:40], body.count('(') == body.count(')'))

    # ---- the mover split into 主窗口_置于前台_在屏幕外 + 主窗口_置于前台_移回屏幕: same moves, same log text
    layouts = [SCREEN, [((0, 0, 1920, 1080), (0, 0, 1920, 1040)), ((1920, -200, 3200, 824), (1920, -200, 3200, 824))],
               [((-1280, 0, 0, 1024), (-1280, 0, 0, 984)), ((0, 0, 2560, 1440), (0, 0, 2560, 1392))]]
    cases = [(1850, 170, 2750, 870), (1700, 170, 2600, 870), (-880, 100, 20, 800), (100, 1030, 1000, 1730), (100, -650, 1000, 50),
             (5000, 5000, 5900, 5700), (-3000, -3000, -2100, -2300), (10, 10, 3000, 2000), (3190, 300, 4090, 1000), (100, 100, 1000, 800), (600, 400, 600, 900)]
    def mover(files_, layout, rect, zoomed=False, iconic=False):
        sim = Sim(Desk([Win(MAIN_H, *rect, pid=OWN, maximized=zoomed, iconic=iconic)], monitors=layout), files_, old=files_ is not files)
        seen = None if files_ is not files else sim.out('主窗口_置于前台_在屏幕外', [MAIN_H], [('局_左', '整数型'), ('局_顶', '整数型'), ('局_说明', '文本型')])   # read-only: asked before the move
        sim.invoke(sim.subs['主窗口_置于前台_移回屏幕'], [('lit', MAIN_H)], {}, None)
        moved = [p[2:4] for p in sim.positions]
        return moved, sim.logs, seen
    expected = {(0, 0): [(1020, 170)], (0, 2): [(0, 100)], (0, 3): [(100, 340)], (0, 4): [(100, 0)], (0, 5): [(1020, 340)], (0, 6): [(0, 0)]}
    for li, layout in enumerate(layouts):
        for ci, rect in enumerate(cases):
            for zoomed, iconic in ((False, False), (True, False), (False, True)):
                moved, logs, seen = mover(files, layout, rect, zoomed, iconic)
                check(f'predicate_matches_move:{li}:{ci}:{zoomed}:{iconic}', seen[0] == bool(moved) and (not moved or (seen[1], seen[2]) == moved[0]), (moved, seen))
                if li == 0 and not zoomed and not iconic and (li, ci) in expected:
                    check(f'mover_expected:{ci}', moved == expected[(li, ci)], (moved, logs))
                if zoomed or iconic:
                    check(f'mover_leaves_zoomed_or_minimised:{li}:{ci}', moved == [], moved)

    # ---- reproduce the old behaviour from the original archive
    if args.baseline_zip:
        old_files = zip_files(args.baseline_zip)
        same = 0
        for li, layout in enumerate(layouts):
            for ci, rect in enumerate(cases):
                for zoomed, iconic in ((False, False), (True, False), (False, True)):
                    new, old = mover(files, layout, rect, zoomed, iconic), mover(old_files, layout, rect, zoomed, iconic)
                    check(f'mover_identical_to_original:{li}:{ci}:{zoomed}:{iconic}', new[:2] == old[:2], (new, old))
                    same += 1
        report['mover_cases_identical_to_original'] = same
        old_stuck, old_first_wasted = [], []
        for name, spec in FALSE_COVERS.items():
            d = desk_with(spec['extra'], spec.get('main_rect', (510, 170, 1410, 870)), fg=MAIN_H, below=[GAME_BELOW])
            sim = Sim(d, old_files, old=True)
            out = [sim.press() for _ in range(3)]
            if out == ['front'] * 3 and sim.desk.w[MAIN_H].visible:
                old_stuck.append(name)
            elif out[:2] == ['front', 'hide']:
                old_first_wasted.append(name)
        report['old_code_never_hides_on'] = old_stuck
        report['old_code_first_press_wasted_on'] = old_first_wasted
        touching_counted = '大于或等于 (局_矩形.右边, 局_主矩形.左边)' in old_files[RECORDER]   # the original helper counted edge-to-edge contact (one project had already fixed that)
        report['old_code_counted_edge_contact'] = touching_counted
        expected_stuck = set(FALSE_COVERS) - {'cloaked_window_normal_band', 'alpha0_layered_normal_band'} - (set() if touching_counted else {'taskbar_touching_edge'})
        check('baseline_reproduces_the_report', set(old_stuck) == expected_stuck
              and set(old_first_wasted) == {'cloaked_window_normal_band', 'alpha0_layered_normal_band'}, report)
        d = desk_with([Win(47, 600, 200, 1000, 500, pid=CHILD, owner=MAIN_H)], fg=47, below=[GAME_BELOW])
        sim = Sim(d, old_files, old=True)
        check('baseline_recorder_exclusion_worked', [sim.press()] == ['hide'])
        jy_sim = Sim(Desk([TASKBAR(), Win(71, 0, 0, 100, 100, topmost=True), popup()]), old_files, old=True)   # a window elsewhere between them: 处理事件 runs before the taskbar is reached
        report['old_jingyi_popup_covered'] = jy_sim.invoke(jy_sim.subs['窗口_是否被遮挡'], [('lit', 70)], {}, None)
        check('baseline_jingyi_test_false_positive_and_pumps_events', report['old_jingyi_popup_covered'] is True and '处理事件' in jy_sim.calls)

    result = {'checks': len(checks), 'passed': len(checks), **report}
    if args.out:
        args.out.write_text(json.dumps(result, ensure_ascii=False, indent=1), 'utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
