#!/usr/bin/env python3
"""Execute the production statements behind four UI decisions.

1. Operator-policy denials (feature_disabled / outside_rollout / version_disabled,
   HTTP 403 from the authorization server) hide rack link for the session instead of
   showing "authorization denied"; other denials still surface.
2. Electronic-tune strength is shown only after a real plug-in readback, always follows
   the plug-in (also after an in-assistant drag, once the plug-in confirmed it or 3 s
   passed), and is not persisted across starts (no fabricated 50%).
3. The "switched to" status names the plug-in; the toolbox entry is named after the
   assistant; no consent box pops up unsolicited; unconsented auto mode is not shown on.
4. The assistant UI moved from EXUI windows to a web window hosted by the main program:
   the module is UI-less and exposes 界面_* data/command entries (executed here); the
   page itself is covered by tests/companion/test_dianyin_page.js.

EPL statements are extracted from the module and run by the existing source
evaluator (review_regression.Runtime). Host/bridge/UI components are explicit
substitutes. This is not an EPL compiler, Win32/WebView2 rendering or real-rack test.
"""
from pathlib import Path
from types import SimpleNamespace
import argparse
import hashlib
import json
import re

import check as syntax
import review_regression as regression

HERE = Path(__file__).resolve()
EPL = HERE.parents[4]
PROJECT = EPL.parent
MODULE = EPL / '模块/模块_电音助手.e~'
ENGINE = MODULE / '代码/程序集_机架联动引擎.static.e.txt'
LANGUAGE = MODULE / '代码/程序集_多语言.static.e.txt'
HOST = EPL / '代码/集_基础支持/机架联动_宿主.static.e.txt'
CLASS = MODULE / '代码/类_电音助手.class.e.txt'
EDGE = EPL / '代码/集_Edge浏览器/程序集_Edge.static.e.txt'
COMMON = EPL / '代码/集_公共函数/程序集1.static.e.txt'
TYPES = MODULE / '自定义类型.e.txt'
FUNCKEYS = EPL / '代码/窗_设置/窗口程序集_窗口_功能快捷键设置.form.e.txt'
FORM = EPL / '窗口/主窗口.form.json'
I18N = PROJECT / 'js/i18n_data.js'

POLICY = ['feature_disabled', 'outside_rollout', 'version_disabled']
SWITCHED = {1: '插件：已切到', 2: 'Plug-in: switched to', 3: 'プラグイン：切り替え済み', 4: '플러그인: 전환 완료',
            5: '外掛：已切換為', 6: 'Plug-in: cambiado a', 7: 'Plug-in: alterado para', 8: 'Plug-in : réglé sur',
            9: 'Plug-in: umgestellt auf', 10: 'Plug-in: beralih ke', 11: 'ปลั๊กอิน: เปลี่ยนเป็น',
            12: 'Plug-in: đã chuyển sang', 13: 'Eklenti: şuna geçildi', 14: 'الإضافة: تم التبديل إلى',
            15: 'Плагин: переключено на', 16: 'Pemalam: ditukar kepada', 17: 'Plug-in: napalitan sa',
            18: 'प्लगइन: बदला गया', 19: 'Plug-in: impostato su'}
MENU_NAME = {'zh-Hans': '电音助手', 'en': 'Pitch-correction assistant', 'ja': 'ピッチ補正アシスタント',
             'ko': '음정 보정 도우미', 'zh-Hant': '電音助手', 'es': 'Asistente de corrección de tono',
             'pt-BR': 'Assistente de afinação', 'fr': 'Assistant de justesse', 'de': 'Tonhöhenkorrektur-Assistent',
             'id': 'Asisten koreksi nada', 'th': 'ผู้ช่วยแก้ระดับเสียง', 'vi': 'Trợ lý chỉnh cao độ',
             'tr': 'Perde düzeltme asistanı', 'ar': 'مساعد تصحيح الطبقة', 'ru': 'Помощник коррекции высоты',
             'ms': 'Pembantu pembetulan pic', 'fil': 'Pitch-correction assistant', 'hi': 'पिच सुधार सहायक',
             'it': 'Assistente d’intonazione'}


class Runtime(regression.Runtime):
    """Adds EPL byte-set literals ({1, 2, 3}) to the shared evaluator.

    The shared argument splitter only nests () and [], so literals outside quoted
    text are first replaced by tokens bound to their bytes in the local scope."""
    LITERAL = re.compile(r'\{\s*\d+(?:\s*,\s*\d+)*\s*\}')

    def execute(self, nodes, env):
        # Statement lines are split by the shared parser too, so bind their literals first.
        return super().execute([('statement', self.bind(node[1], env)) if node[0] == 'statement' else node
                                for node in nodes], env)

    def evaluate(self, value, env):
        return super().evaluate(self.bind(value, env), env)

    def bind(self, value, env):
        if '{' in value and self.LITERAL.search(value):
            pieces, quoted, start = [], False, 0
            for index, char in enumerate(value + '“'):
                if char in '“”' or index == len(value):
                    segment = value[start:index]
                    if not quoted:
                        def bind(match):
                            data = bytes(int(item) for item in match.group(0).strip('{}').split(','))
                            token = '__bytes_' + data.hex()
                            env[token] = data
                            return token
                        segment = self.LITERAL.sub(bind, segment)
                    pieces.append(segment)
                    if index < len(value):
                        pieces.append(char)
                    quoted = char == '“' if index < len(value) else quoted
                    start = index + 1
            value = ''.join(pieces)
        return value


def active_lines(source):
    return [syntax.active_line(line) for line in source.splitlines()]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    engine = ENGINE.read_text(encoding='utf-8-sig')
    klass = CLASS.read_text(encoding='utf-8-sig')
    language = LANGUAGE.read_text(encoding='utf-8-sig')
    checks, failures = [], []

    def check(name, condition):
        checks.append(name)
        if not condition:
            failures.append(name)

    # ---- 1a. op15 summary classifier (exact production function) ----------------
    def classify(text=None, raw=None, count=None):
        runtime = Runtime(engine)
        calls = []
        def host(op, a=None, b=None, c=None, d=None):
            calls.append((op, b))
            data = raw if raw is not None else text.encode('utf-16-le')
            a[:len(data)] = data
            return count if count is not None else len(data) // 2
        runtime.functions.update({
            '取空白字节集': lambda size: bytearray(size), '取变量数据地址': lambda buffer: buffer,
            '机架引擎_宿主调用': host, '取字节集数据': lambda buffer, kind, position: buffer[position - 1],
            '取字节集左边': lambda buffer, size: bytes(buffer[:size]),
            '编码_Unicode到Ansi': lambda data: data.decode('utf-16-le').split('\x00')[0]})
        result = runtime.invoke('机架引擎_策略未开放')
        check('classifier_reads_op15_with_bounded_buffer:' + repr(text)[:40], calls == [(15, 256)])
        return result
    for reason in POLICY:
        check('policy_hidden:' + reason, classify(f'auth_stage=http http=403 auth_reason={reason} error=3') is True)
    for text in ['auth_stage=http http=403 auth_reason=authorization_denied error=3',
                 'auth_stage=http http=401 auth_reason=invalid_credentials error=3',
                 'auth_stage=http http=403 auth_reason=license_expiring error=3',
                 'auth_stage=http http=429 auth_reason=rate_limited error=4',
                 'auth_stage=http http=403 auth_reason=feature_disabled error=4',
                 'auth_stage=http http=0 auth_reason=feature_disabled error=3',
                 'auth_stage=verify_token http=403 auth_reason=feature_disabled error=3',
                 'auth_stage=controller http=0 auth_reason=controller_rejected error=3',
                 'auth_stage=http http=403 auth_reason=feature_disabled error=3 ',
                 'auth_stage=http http=403 auth_reason=feature_disabled_x error=3',
                 'auth_stage=http http=403 auth_reason=outside_rollout error=31', '']:
        check('other_denials_still_shown:' + text, classify(text) is False)
    check('non_ascii_rejected', classify('auth_stage=http http=403 auth_reason=feature_disabléd error=3') is False)
    check('high_byte_rejected', classify(raw='auth_stage=http'.encode('utf-16-le')[:-1] + b'\x01') is False)
    check('truncated_count_rejected', classify('auth_stage=http http=403 auth_reason=feature_disabled error=3', count=40) is False)
    check('oversize_count_rejected', classify('a' * 255) is False)

    # ---- 1b. link-thread wiring ---------------------------------------------------
    link = syntax.section(engine, '机架引擎_线程_联动')
    code = '\n'.join(active_lines(link))
    gate_line = next(line.strip() for line in link.splitlines() if line.strip().startswith('赋值 (局_启用,'))
    gate = syntax.call_arguments(gate_line, '赋值')[1]
    for flag in (False, True):
        runtime = Runtime(engine)
        runtime.env.update({'集_机架_系统支持': True, '集_机架_允许连接': True, '集_机架_服务未开放': flag})
        snapshot = SimpleNamespace(已同意=True, 自动切换=True)
        check(f'gate_closed_while_not_offered:{flag}', runtime.evaluate(gate, {'局_快照': snapshot}) is (not flag))
    # The state shown while the bridge is not configured yet: at start and right after consenting or switching
    # auto-switch on, the link thread may go straight into preparing the bridge (downloaded, several seconds);
    # a user who has consented must not see “等待同意” (nor a stale “自动切换已关闭”) meanwhile.
    helper = syntax.section(engine, '机架引擎_未配置状态')
    rule = syntax.call_arguments(next(l.strip() for l in helper.splitlines() if l.strip().startswith('返回 (')), '返回')[0]
    expected = {(False, False, True, True): 10, (True, True, True, True): 22, (True, False, False, True): 16,
                (True, False, True, False): 0, (True, False, True, True): 1}
    got = {}
    for (supported, closed, consented, auto), state in expected.items():
        runtime = Runtime(engine)
        runtime.env.update({'集_机架_系统支持': supported, '集_机架_服务未开放': closed, '集_机架_快照': SimpleNamespace(已同意=consented, 自动切换=auto)})
        got[(supported, closed, consented, auto)] = runtime.evaluate(rule, {})
    check('unconfigured_state_follows_consent_and_switch', got == expected)
    check('unconfigured_state_never_asks_consent_from_who_consented', all(v != 16 for (s, c, ok, a), v in got.items() if ok))
    start = syntax.section(engine, '机架引擎_启动')
    check('start_shows_the_unconfigured_state', '赋值 (集_机架_快照.状态编号, 机架引擎_未配置状态 ())' in start)
    control = syntax.section(engine, '机架引擎_处理控制请求').replace('\r\n', '\n')
    check('consent_or_switch_change_republishes_the_unconfigured_state',
          '.如果真 (取反 (集_机架_已配置))\n        赋值 (集_机架_快照.状态编号, 机架引擎_未配置状态 ())' in control
          and control.index('机架引擎_未配置状态 ()') < control.index('机架引擎_发布 ()'))
    # “等待同意” only shows to someone who did consent but whose consent was not saved, so it must say where
    # to switch it on again, naming the two menu items exactly as that language's menu shows them.
    lang_src = (MODULE / '代码/程序集_多语言.static.e.txt').read_text(encoding='utf-8-sig')
    table = re.search(r'^\.子程序 多语言_机架文字W_语种[^\n]*\n(.*?)(?=^\.子程序 |\Z)', lang_src, re.M | re.S).group(1)
    rows = [[bytes(int(x) for x in a.split(',')).decode('utf-16-le').rstrip('\x00') for a in re.findall(r'\{([0-9, ]+)\}', l)]
            for l in table.split('\n') if '多项选择 (序号,' in l]
    check('consent_hint_names_both_menu_items_in_every_language', len(rows) == 19 and all(r[5] in r[30] and r[6] in r[30] for r in rows))
    # While the host downloads the bridge (op1 blocks the link thread) the status is 23 → text 38 “正在下载联动组件”.
    check('download_notice_has_a_text_in_every_language', all(len(r) == 38 and r[37].strip() for r in rows))
    mapping = syntax.section(lang_src, '多语言_机架状态W').replace('\r\n', '\n')
    check('state_23_maps_to_the_download_text_before_the_range_fallback',
          '.如果真 (等于 (快照.状态编号, 23))' in mapping and '返回 (多语言_机架文字W (38))' in mapping
          and mapping.index('等于 (快照.状态编号, 23)') < mapping.index('大于 (快照.状态编号, 21)'))
    notice = syntax.section(engine, '机架引擎_置下载中').replace('\r\n', '\n')
    check('download_notice_only_while_unconfigured_and_kept_until_recompute',
          '.如果真 (或者 (取反 (下载中), 取反 (集_机架_运行)))' in notice and '机架引擎_未配置状态' not in notice
          and '.如果真 (取反 (集_机架_已配置))\n    赋值 (集_机架_快照.状态编号, 23)\n    机架引擎_发布 ()' in notice
          and notice.index('EnterCriticalSectionP') < notice.index('机架引擎_发布 ()') < notice.index('LeaveCriticalSectionP'))
    # The bridge is prepared (downloaded) only once the 电音助手 window is on screen, so the notice is seen.
    link_code = link.replace('\r\n', '\n')
    check('bridge_prepared_only_after_the_window_shows',
          '赋值 (局_界面, 集_机架_界面已显示)' in link_code and link_code.index('赋值 (局_界面, 集_机架_界面已显示)') < link_code.index('LeaveCriticalSectionP (集_机架_许可证)')
          and '局_启用, 局_界面, 不等于 (局_快照.音乐名W, {})))' in link_code and '赋值 (集_机架_界面已显示, 假)' in syntax.section(engine, '机架引擎_启动'))
    edge_code = (EPL / '代码/集_Edge浏览器/程序集_Edge.static.e.txt').read_text(encoding='utf-8-sig')
    shown = syntax.section(edge_code, 'Edge_电音助手_显示')
    host_code = (EPL / '代码/集_基础支持/机架联动_宿主.static.e.txt').read_text(encoding='utf-8-sig')
    check('window_show_tells_the_engine', 0 <= shown.find('ShowWindow (集_电音_窗口, 5)') < shown.find('机架联动_界面已显示 ()')
          and '电音助手.置界面已显示 (真)' in syntax.section(host_code, '机架联动_界面已显示'))
    inner = syntax.section(host_code, '机架联动_启动引擎_内部')
    check('engine_start_reasserts_window_shown', 0 <= inner.find('电音助手.启动后台 (') < inner.find('电音助手.置界面已显示 (集_机架界面已显示)')
          and '赋值 (集_机架界面已显示, 假)' in syntax.section(host_code, '机架联动_关闭引擎'))
    # Executed, not just read: every rack text is reachable through the real lookup (多语言_机架文字W_语种 has
    # its own range check), and the status line really gets the download notice for state 23.
    import review_regression as executed
    lang_rt = executed.Runtime(lang_src)
    lang_rt.functions.setdefault('多项选择', lambda index, *items: items[index - 1])
    for real in ('多语言_机架文字W', '多语言_机架文字W_语种'):     # run their real source bodies, not stand-ins
        lang_rt.functions[real] = lambda *a, real=real: lang_rt.invoke(real, *a)
    reachable = all(lang_rt.invoke('多语言_机架文字W_语种', n, lang) == rows[lang - 1][n - 1].encode('utf-16-le') + b'\x00\x00'
                    for lang in range(1, 20) for n in range(1, len(rows[0]) + 1))
    check('every_rack_text_is_reachable_through_the_real_lookup', reachable)
    shown = []
    for lang in range(1, 20):
        lang_rt.functions['多语言_序号'] = lambda lang=lang: lang
        shown.append(lang_rt.invoke('多语言_机架状态W', SimpleNamespace(状态编号=23, 自检结果=0, 已确认=0, 总数=0, 实际基调='C')))
    check('status_line_really_shows_the_download_notice', shown == [r[37].encode('utf-16-le') + b'\x00\x00' for r in rows])
    detect = link.index('赋值 (局_未开放, 机架引擎_策略未开放 ())')
    lock_after = link.index('EnterCriticalSectionP (集_机架_许可证)', detect)
    check('classifier_called_outside_engine_lock', link.rfind('LeaveCriticalSectionP', 0, detect) > link.rfind('EnterCriticalSectionP', 0, detect)
          and lock_after > detect)
    check('classifier_only_for_bridge_denied', '.如果真 (等于 (局_错误, 3))\n            赋值 (局_未开放, 机架引擎_策略未开放 ())' in link.replace('\r\n', '\n'))
    hidden = re.search(r'\.如果真 \(局_未开放\)\n((?:            [^\n]*\n)+)        \.如果真结束', link.replace('\r\n', '\n'))
    check('hidden_state_requests_stop_and_publishes_22', hidden is not None and all(item in hidden.group(1) for item in [
        '赋值 (集_机架_服务未开放, 真)', '赋值 (集_机架_停止请求, 真)', '赋值 (局_状态编号, 22)']))
    log_at = link.index('机架引擎_记日志 (“服务端策略未向本设备开放联动')
    check('hidden_log_written_after_lock_release', link.rfind('LeaveCriticalSectionP', 0, log_at) > link.rfind('EnterCriticalSectionP', 0, log_at))
    check('idle_branch_keeps_hidden_state', '.判断 (集_机架_服务未开放)\n            赋值 (集_机架_快照.状态编号, 22)' in link.replace('\r\n', '\n'))
    check('relogin_rechecks_policy', '赋值 (集_机架_服务未开放, 假)' in syntax.section(engine, '机架引擎_重新连接')
          and syntax.section(engine, '机架引擎_启动').count('赋值 (集_机架_服务未开放, 假)') == 2)
    # The new statements stay outside the ranges executed by existing harnesses.
    health_first = link.index('        赋值 (集_机架_快照.已确认,')
    health_cap = link.index('        赋值 (集_机架_快照.支持速度,', health_first)
    health_start = link.index('        赋值 (局_状态编号, 机架引擎_状态编号')
    health_end = link.index('        .如果真 (并且 (取反 (局_快照.自动切换)', health_start)
    segment = regression.link_segment(engine)
    check('new_statements_outside_existing_extracted_ranges', all('未开放' not in part for part in
          (link[health_first:health_cap], link[health_start:health_end], segment)))

    # ---- 1c. unsolicited consent probe removed ------------------------------------
    check('no_periodic_rack_probe_before_consent', '机架引擎_机架运行 ()' not in code and '需提示' not in code)
    consent_box = syntax.section(klass, '界面_切换自动切换')
    check('consent_box_default_button_yes_when_user_initiated', '赋值 (局_样式, 36)' in consent_box and '292' not in consent_box)
    check('consent_box_uses_latest_request', '或者 (局_快照.已同意, 机架引擎_取同意期望 ())' in consent_box)
    check('consent_box_only_from_user_toggle', all('MessageBoxW_电音' not in syntax.section(klass, n)
          for n in re.findall(r'^\.子程序 ([^,\n]+)', klass, re.M) if n != '界面_切换自动切换'))
    runtime = Runtime(engine)
    runtime.env.update({'集_机架_许可证': 1, '集_机架_同意期望': True})
    check('consent_expectation_getter', runtime.invoke('机架引擎_取同意期望') is True and runtime.depth == 0)
    runtime.env['集_机架_许可证'] = 0
    check('consent_expectation_without_engine', runtime.invoke('机架引擎_取同意期望') is False)

    # ---- 2. strength follows real readback only ------------------------------------
    begin = link.index('        赋值 (集_机架_快照.支持速度, 并且 (不等于 (位与 (局_插件状态位')
    begin = link.index('\n', begin) + 1
    finish = link.index('        赋值 (局_状态编号, 机架引擎_状态编号', begin)
    block = link[begin:finish]
    def feel(value=None):
        word = 0x80000000 | 0x40000000 | ((0x20000000 | value) if value is not None else 0)
        return word - 0x100000000
    for name, dragged, pending, elapsed, speed, word, before, expected, still_pending in [
            ('readback_shown_as_is', False, False, 0, True, feel(600), -1, 600, False),
            ('no_fabricated_half', False, False, 0, True, feel(None), -1, -1, False),
            ('keep_last_real_value_on_gap', False, False, 0, True, feel(None), 420, 420, False),
            ('no_capability_back_to_unknown', False, False, 0, False, feel(600), 420, -1, False),
            ('clamped_to_1000', False, False, 0, True, feel(1023), -1, 1000, False),
            # the plug-in is the authority: a value changed in the plug-in after a drag is followed
            ('follows_plugin_change_after_confirmed_drag', True, False, 0, True, feel(300), 750, 300, False),
            ('pending_drag_ignores_stale_readback', True, True, 500, True, feel(300), 750, 750, True),
            ('pending_drag_confirmed_within_1_percent', True, True, 500, True, feel(745), 750, 745, False),
            ('pending_drag_times_out_then_follows', True, True, 3000, True, feel(300), 750, 300, False),
            ('pending_drag_without_readback_keeps_value', True, True, 500, True, feel(None), 750, 750, True),
            ('pending_cleared_when_capability_lost', True, True, 100, False, feel(None), 750, -1, False)]:
        runtime = Runtime(engine)
        runtime.functions.update({'机架引擎_经过': lambda start, elapsed=elapsed: elapsed, '取绝对值': abs})
        runtime.env.update({'集_机架_强度已设置': dragged, '集_机架_强度待确认': pending, '集_机架_强度设置时间': 0,
                            '集_机架_快照': SimpleNamespace(支持速度=speed, 当前强度=before)})
        runtime.execute_text(block, {'局_插件状态位': word})
        check('strength:' + name, runtime.env['集_机架_快照'].当前强度 == expected and runtime.env['集_机架_强度待确认'] is still_pending)
    runtime = regression.engine_runtime(engine)
    runtime.functions.update({'机架引擎_毫秒': lambda: 4321, '相除': lambda left, right: left / right, '到整数': int})
    runtime.env['集_机架_快照'] = SimpleNamespace(已同意=True, 自动切换=True, 支持速度=True, 当前强度=600)
    runtime.env.update({'集_机架_强度已设置': False, '集_机架_强度待确认': False, '集_机架_强度设置时间': 0, '集_机架_强度请求': False})
    runtime.invoke('机架引擎_电音强度', 50, 100)
    check('drag_marks_pending_until_plugin_confirms', runtime.env['集_机架_快照'].当前强度 == 500 and runtime.env['集_机架_强度已设置'] is True
          and runtime.env['集_机架_强度待确认'] is True and runtime.env['集_机架_强度设置时间'] == 4321 and runtime.env['集_机架_强度请求'] is True)
    check('strength_not_persisted', 'RackLinkStrength' not in '\n'.join(active_lines(engine)) and
          '当前强度, 500)' not in engine)
    check('push_only_dragged_strength', '赋值 (局_强度, 选择 (集_机架_强度已设置, 局_快照.当前强度, -1))' in link)
    for marker in ('        赋值 (局_配置到期, 真)\n        赋值 (集_机架_快照.支持速度, 假)',
                   '        赋值 (集_机架_已配置, 假)\n        赋值 (集_机架_快照.支持速度, 假)'):
        check('stop_and_reconfig_forget_stale_capability:' + marker.split('(')[1][:8], marker in link.replace('\r\n', '\n'))
        flat = link.replace('\r\n', '\n'); at = flat.index(marker) + len(marker)
        reset = flat[at:flat.index('LeaveCriticalSectionP', at)]
        check('bridge_cleared_strength_so_module_forgets_drag:' + marker.split('(')[1][:8], all(item in reset for item in [
            '赋值 (集_机架_快照.当前强度, -1)', '赋值 (集_机架_强度已设置, 假)', '赋值 (集_机架_强度待确认, 假)']) and '.如果真 (取反 (集_机架_强度已设置))' not in reset)

    # ---- 3. web window entries of 类_电音助手 (the module is UI-less now), executed ----
    W = lambda text: text.encode('utf-16-le') + b'\x00\x00'
    song = W('歌')   # the song name the key-line checks below also use
    def resource_lines(name):
        raw = (MODULE / '资源' / name).read_bytes()
        for encoding in ('utf-8-sig', 'gbk'):
            try:
                return [x for x in raw.decode(encoding).replace('\r\n', '\n').split('\n') if x != '']
            except UnicodeDecodeError:
                pass
        return []
    KEYS, SCALES = resource_lines('常量_基调.txt'), resource_lines('常量_音阶.txt')
    def run_entry(name, args, functions, program=None):
        runtime = Runtime(klass)
        text = syntax.section(klass, name)
        params = re.findall(r'^\.参数 ([^,]+), ([^,]+),', text, re.M)
        defaults = {'文本型': '', '字节集': b'', '逻辑型': False, '整数型': 0}
        env = {variable: (args[i] if i < len(args) else defaults.get(kind)) for i, (variable, kind) in enumerate(params)}
        env['_omitted_params'] = set()
        for variable, kind in re.findall(r'^\.局部变量 ([^,]+), ([^,]+),', text, re.M):
            env[variable] = SimpleNamespace() if kind == '自定义_机架联动快照' else defaults.get(kind, 0)
        runtime.env.update(program or {})
        runtime.functions.update(functions(env))
        depth = [0]                                   # 配置锁（类内叶子锁，加锁范围另见 test_dianyin_config_lock.py）：这里核对成对使用

        def lock():
            depth[0] += 1

        def unlock():
            assert depth[0] > 0, name + ': 配置_解锁 without 配置_加锁'
            depth[0] -= 1
        runtime.functions.setdefault('配置_加锁', lock)
        runtime.functions.setdefault('配置_解锁', unlock)
        returned = None
        try:
            runtime.execute_text(text, env)
        except syntax.Returned as value:
            returned = value.value
        assert depth[0] == 0, name + ': 配置锁没有成对释放'
        return returned, env, runtime

    def ui_state(song_state=2, **changes):           # song_state: 多语言_歌曲基调状态 (0 no song, 1 querying, 2 found, 3 not found)
        snapshot = dict(音乐名W=W('歌A'), 已同意=False, 状态编号=16, 自动切换=True, 支持速度=False, 当前强度=-1, 基调='C', 音阶='大调', 已锁定=False)
        snapshot.update(changes)
        def functions(env):
            def fill(target):
                for key, value in snapshot.items():
                    setattr(target, key, value)
            def selection(unused_mode, unused_player):
                env['返回_播放器模式'], env['返回_播放器'] = 1, '酷狗音乐'
            return {'机架引擎_快照': fill, '机架引擎_取播放器选择': selection,
                    '多语言_机架状态W': lambda value: W('STATUS'), '多语言_机架基调行W': lambda value: W('RACKKEY'),
                    '多语言_基调标签文字W': lambda state, key, scale: W('PLAIN%d%s%s' % (state, key, scale)),
                    '多语言_歌曲基调状态': lambda value: song_state,
                    '删除Unicode结尾空白字节': lambda data, flag: data[:-2] if data.endswith(b'\x00\x00') else data}
        return run_entry('界面_取状态', [], functions)[1]
    s = ui_state()
    check('ui_state:unconsented_plain_window', s['返回_状态W'] == b'\x00\x00' and s['返回_强度'] == -1 and s['返回_联动菜单'] == 1
          and s['返回_基调W'] == W('PLAIN2C大调') and s['返回_歌名W'] == W('歌A'))
    check('ui_state:player_selection_passed_through', s['返回_播放器模式'] == 1 and s['返回_播放器'] == '酷狗音乐')
    s = ui_state(已同意=True, 状态编号=2, 支持速度=True, 当前强度=600)
    check('ui_state:linked_shows_status_rack_key_and_strength', s['返回_状态W'] == W('STATUS') and s['返回_基调W'] == W('RACKKEY')
          and s['返回_强度'] == 600 and s['返回_联动菜单'] == 2)
    s = ui_state(已同意=True, 状态编号=0, 自动切换=False, 支持速度=True, 当前强度=600)
    check('ui_state:auto_off_shows_song_key_no_strength', s['返回_状态W'] == W('STATUS') and s['返回_基调W'] == W('PLAIN2C大调')
          and s['返回_强度'] == -1 and s['返回_联动菜单'] == 1)
    s = ui_state(已同意=True, 状态编号=22, 支持速度=True, 当前强度=600)
    check('ui_state:policy_hidden_like_no_feature', s['返回_状态W'] == b'\x00\x00' and s['返回_强度'] == -1 and s['返回_联动菜单'] == 0
          and s['返回_基调W'] == W('PLAIN2C大调'))
    # 这首歌的基调查到之前不出机架联动的提示（如「正在连接，请打开机架」）；强度滑块不受影响；锁定当前调时照常说明
    for song_state, label in ((1, 'querying'), (3, 'not_found'), (0, 'no_song')):
        s = ui_state(song_state, 已同意=True, 状态编号=1, 支持速度=True, 当前强度=600)
        check('ui_state:no_rack_status_before_the_key_is_known:' + label, s['返回_状态W'] == b'\x00\x00'
              and s['返回_强度'] == 600 and s['返回_基调W'] == W('RACKKEY') and s['返回_联动菜单'] == 2)
    check('ui_state:rack_status_once_the_key_is_known', ui_state(2, 已同意=True, 状态编号=1)['返回_状态W'] == W('STATUS'))
    check('ui_state:locked_key_status_shown_while_the_song_is_queried', ui_state(1, 已同意=True, 状态编号=11, 已锁定=True)['返回_状态W'] == W('STATUS'))
    check('ui_state:strength_needs_capability_and_readback',
          ui_state(已同意=True, 状态编号=2, 支持速度=False, 当前强度=600)['返回_强度'] == -1
          and ui_state(已同意=True, 状态编号=2, 支持速度=True, 当前强度=-1)['返回_强度'] == -1)

    def bit_or(*values):
        result = 0
        for value in values:
            result |= value
        return result
    def toggle(answer=6, consented=False, consent_expect=False, auto_expect=False, arabic=False, busy=False):
        calls = []
        def functions(env):
            def fill(target):
                target.已同意 = consented
            return {'机架引擎_快照': fill, '机架引擎_取同意期望': lambda: consent_expect, '机架引擎_取自动期望': lambda: auto_expect,
                    '多语言_是否阿拉伯语': lambda: arabic, '多语言_机架文字W': lambda index: W('T%d' % index),
                    'MessageBoxW_电音': lambda owner, text, caption, style: calls.append(('box', owner, text, caption, style)) or answer,
                    '机架引擎_同意': lambda value: calls.append(('consent', value)),
                    '机架引擎_自动切换': lambda value: calls.append(('auto', value)), '位或': bit_or}
        returned, env, runtime = run_entry('界面_切换自动切换', [77], functions, {'集_同意提示中': busy})
        return returned, calls, runtime.env['集_同意提示中']
    r, calls, busy_after = toggle()
    check('ui_toggle:first_use_asks_once_then_enables', r is True and busy_after is False and calls == [
        ('box', 77, W('T11'), W('T6'), 36), ('consent', True), ('auto', True)])
    check('ui_toggle:arabic_box_reads_right_to_left', toggle(arabic=True)[1][0] == ('box', 77, W('T11'), W('T6'), 36 | 1572864))
    check('ui_toggle:declined_records_and_stays_off', toggle(answer=7)[1] == [('box', 77, W('T11'), W('T6'), 36), ('consent', False)])
    check('ui_toggle:on_turns_off_without_asking', toggle(consent_expect=True, auto_expect=True)[1] == [('auto', False)])
    check('ui_toggle:consented_but_off_turns_on_without_asking', toggle(consented=True)[1] == [('auto', True)])
    r, calls, unused = toggle(busy=True)
    check('ui_toggle:no_reentry_while_box_open', r is False and calls == [])

    def select(mode, player, current='酷狗音乐', current_mode=0):
        calls = []
        def functions(env):
            def selection(unused_mode, unused_player):
                env['局_模式'], env['局_播放器'] = current_mode, current
            return {'机架引擎_取播放器选择': selection, '机架引擎_选择播放器': lambda m, p: calls.append(('select', m, p)),
                    '保存配置': lambda: calls.append('save')}
        run_entry('界面_选择播放器', [mode, player], functions, {'全_播放记录': SimpleNamespace(删除所有记录=lambda: calls.append('clear'))})
        return calls
    check('ui_player:manual_pick_clears_history_selects_saves', select(0, 'QQ音乐') == ['clear', ('select', 0, 'QQ音乐'), 'save'])
    check('ui_player:same_player_keeps_history', select(0, '酷狗音乐') == [('select', 0, '酷狗音乐'), 'save'])
    check('ui_player:mode_switch_keeps_current_player', select(1, '') == [('select', 1, '酷狗音乐'), 'save'])

    def text_of(index):
        return run_entry('界面_取文字W', [index], lambda env: {'多语言_机架文字W': lambda n: W('R%d' % n), '多语言_文字W': lambda n: W('U%d' % n)})[0]
    check('ui_texts:indexes', text_of(101) == W('R6') and text_of(102) == W('R7') and text_of(5) == W('U5') and text_of(22) == W('U22')
          and text_of(0) == b'\x00\x00' and text_of(23) == b'\x00\x00')

    def split(text, separator, *unused):
        return list({'#常量_基调': KEYS, '#常量_音阶': SCALES}[text])
    submitted = []
    for name in ('基调名_音高', '基调名_英文', '基调名_标准', '音阶名_标准'):     # the entries call them: their real engine source runs
        syntax.register_source_function(engine, name)
    names = {name: syntax.SOURCE_FUNCTIONS[name] for name in ('基调名_音高', '基调名_标准', '音阶名_标准')}
    def edit_functions(env):
        return {'分割文本': split, '机架引擎_提交编辑': lambda song, key, scale, auto: submitted.append((song, key, scale, auto)) or 42, **names}
    check('ui_edit:key_options_are_standard_english_names', KEYS == ['C', 'C#/Db', 'D', 'D#/Eb', 'E', 'F', 'F#/Gb', 'G', 'G#/Ab', 'A', 'A#/Bb', 'B']
          and SCALES == ['Major', 'Minor'])
    check('ui_edit:indexes_map_to_standard_names', run_entry('界面_提交编辑', [W('歌A'), 2, 1, False], edit_functions)[0] == 42
          and submitted[-1] == (W('歌A'), 'Db', 'Major', False))
    for key_index, scale_index, expect in ((2, 2, 'C#'), (9, 1, 'Ab'), (9, 2, 'G#'), (7, 1, 'F#'), (7, 2, 'F#'), (4, 2, 'Eb'), (11, 2, 'Bb'), (1, 2, 'C')):
        run_entry('界面_提交编辑', [W('歌A'), key_index, scale_index, False], edit_functions)
        check(f'ui_edit:submits_{key_index}_{scale_index}', submitted[-1][1:3] == (expect, SCALES[scale_index - 1]))
    run_entry('界面_提交编辑', [W('歌A'), 99, 0, True], edit_functions)
    check('ui_edit:out_of_range_sends_empty_values', submitted[-1] == (W('歌A'), '', '', True))
    def current(kind, key, scale):
        def functions(env):
            def fill(target):
                target.基调, target.音阶 = key, scale
            return {'分割文本': split, '机架引擎_快照': fill, **names}
        return run_entry('界面_取当前选项', [kind], functions)[0]
    check('ui_edit:preselects_current_song', current(1, KEYS[3], SCALES[1]) == 4 and current(2, KEYS[3], SCALES[1]) == 2
          and current(1, '?', '?') == 1 and current(1, '', '大调') == 1)
    check('ui_edit:preselects_by_pitch_whatever_the_spelling', current(1, 'C#', '小调') == 2 and current(1, 'Db', '大调') == 2
          and current(1, 'D-平行', '大调') == 2 and current(1, 'G#', '小调') == 9 and current(1, 'Bbm', '小调') == 11)
    check('ui_edit:preselects_scale_by_standard_name', current(2, 'C', 'Minor') == 2 and current(2, 'C', 'Major') == 1
          and current(2, 'C', '小调') == 2 and current(2, 'C', ' minor ') == 2 and current(2, 'C', 'Chromatic') == 1)
    check('ui_edit:option_count_and_display', run_entry('界面_取选项数', [1], lambda env: {'分割文本': split})[0] == len(KEYS)
          and run_entry('界面_取选项W', [2, 1], lambda env: {'分割文本': split, '多语言_音阶显示W': lambda v: W('S:' + v)})[0] == W('S:' + SCALES[0]))

    class Config:
        def __init__(self, data):
            self.data, self.writes = dict(data), []
        def 加载_从内存(self, text):
            pass
        def 读内存配置项(self, section, key, default):
            return self.data.get(key, default)
        def 写内存配置项(self, section, key, value, *_):
            self.writes.append((key, value)); self.data[key] = value
        def 保存到内存(self):
            return repr(sorted(self.data.items()))
    def load_position(data):
        cfg = Config(data)
        unused, env, runtime = run_entry('读取配置', [''], lambda env: {}, {'内存配置项': cfg, '集_窗口左': -1, '集_窗口顶': -1, '集_窗口有位置': False})
        return runtime.env['集_窗口有位置'], runtime.env['集_窗口左'], runtime.env['集_窗口顶'], cfg, runtime
    has, left, top, cfg, unused = load_position({})
    check('position:none_recorded_means_no_position', has is False)
    has, left, top, cfg, unused = load_position({'主窗口_位置_左边': '-1500', '主窗口_位置_顶边': '-20'})
    check('position:negative_secondary_monitor_coordinates_kept', has is True and left == -1500 and top == -20)
    def save_with(has_position):
        cfg = Config({})
        def functions(env):
            def selection(unused_mode, unused_player):
                env['局_选择模式'], env['局_选择播放器'] = 0, '酷狗音乐'
            return {'机架引擎_取播放器选择': selection}
        run_entry('保存配置', [], functions, {'内存配置项': cfg, '集_窗口左': -1500, '集_窗口顶': 30, '集_窗口有位置': has_position, '保存配置_回调函数': 0})
        return dict(cfg.writes)
    written = save_with(True)
    check('position:saved_when_recorded_even_negative', written.get('主窗口_位置_左边') == '-1500' and written.get('主窗口_位置_顶边') == '30')
    check('position:not_written_without_record', '主窗口_位置_左边' not in save_with(False))
    moved = run_entry('置窗口位置', [-800, 40], lambda env: {'保存配置': lambda: None}, {'集_窗口有位置': False})[2]
    check('position:moving_records_position', moved.env['集_窗口有位置'] is True and moved.env['集_窗口左'] == -800)
    # 联动状态行的拼接（执行 多语言_机架状态W）：联动成功只显示“插件：已切到 调名”，只有自检结果附带“(确认/总数)”
    def status_line(**snap):
        base = dict(状态编号=2, 自检结果=0, 实际基调='E', 已确认=3, 总数=4, 音乐名W=W('歌'), 基调='E', 来源='server')
        base.update(snap)
        runtime = Runtime(language)
        runtime.functions.update({'多语言_机架文字W': lambda n: W('T%d' % n), '多语言_基调显示W': lambda key: W(key),
                                  '删除Unicode结尾空白字节': lambda data, flag: data[:-2] if data.endswith(b'\x00\x00') else data,
                                  '编码_Ansi到Unicode': lambda text, flag=None: str(text).encode('utf-16-le'),
                                  '多语言_歌曲基调状态': lambda value: runtime.invoke('多语言_歌曲基调状态', value)})
        text = syntax.section(language, '多语言_机架状态W')
        env = {'快照': SimpleNamespace(**base), '_omitted_params': set(), '局_序号': 0, '局_W': b'', '局_歌态': 0}
        try:
            runtime.execute_text(text, env)
        except syntax.Returned as value:
            return value.value
    check('status_line:linked_success_has_no_count', status_line() == W('T13 E'))
    check('status_line:self_test_result_keeps_count', status_line(自检结果=2) == W('T28 (3/4)') and status_line(状态编号=1, 自检结果=3) == W('T29 (3/4)'))
    check('status_line:policy_hidden_shows_nothing', status_line(状态编号=22) == b'\x00\x00')
    # 部分插件没跟随（状态编号 3）不再提示“部分插件没跟随，请自检”（文字表第 14 项保留但不再选用）：
    # 至少一个已切到 → 同切换成功；一个都没跟随 → 不显示；主动自检的结论照常显示
    check('status_line:partial_follow_shows_switched', status_line(状态编号=3) == W('T13 E'))
    check('status_line:none_followed_shows_nothing', status_line(状态编号=3, 已确认=0) == b'\x00\x00')
    check('status_line:self_test_still_reported_when_none_followed', status_line(状态编号=3, 已确认=0, 自检结果=3) == W('T29 (0/4)'))
    # 状态编号 3 只该表示“确认不全”：桥定义的每个非零错误码都必须在 机架引擎_状态编号 里单独映射，
    # 否则新加的错误码会落进“错误不为 0 → 3”，状态行在出错时显示“插件：已切到”
    import re as _re
    _bridge = (EPL / '依赖库/AutoTuneKeyScale/vst3/cpp/keyscale_rack_bridge.cpp').read_text(encoding='utf-8')
    _codes = {int(v) for v in _re.findall(r'XRB_[A-Z_]+=(\d+)', _re.search(r'enum \{ XRB_OK=.*?\};', _bridge, _re.S).group(0))} - {0}
    _mapped = {int(v) for v in _re.findall(r'等于 \(错误, (\d+)\)', syntax.section(ENGINE.read_text(encoding='utf-8-sig').replace('\r\n', '\n'), '机架引擎_状态编号'))}
    check('state_3_only_means_partial_follow:every_bridge_error_is_mapped', _codes and _codes <= _mapped)
    check('status_line:partial_follow_prompt_never_shown', all(not status_line(状态编号=s, 已确认=c, 自检结果=r).startswith(W('T14')[:-2])
          for s in range(0, 23) for c in (0, 3) for r in (0, 1, 2, 3)))
    check('status_line:unknown_state_falls_back', status_line(状态编号=30) == W('T27'))
    # 插件按 Chromatic 兜底（状态编号 12）时用白话说明：查询中（含断网重试）→23“查到基调后自动切换”；查询不到→37“可右键添加/报错补上”；这首歌本身是 Chromatic→同普通调“插件：已切到 Chromatic”
    chroma = dict(状态编号=12, 实际基调='Chromatic')
    check('status_line:general_tuning_while_looking_up', status_line(**chroma, 基调='', 来源='') == W('T23'))
    check('status_line:general_tuning_not_found_points_to_menu', status_line(**chroma, 基调='', 来源='server') == W('T37'))
    check('status_line:song_itself_chromatic_shows_switched', status_line(**chroma, 基调='C', 来源='server') == W('T13 Chromatic'))
    loader = syntax.section(klass, '载入窗口')
    check('compat_loader_starts_background_only', '启动后台 (' in loader
          and not any(k in '\n'.join(active_lines(loader)) for k in ('载入 (', 'InitExui', '窗口1')))
    start = syntax.section(klass, '启动后台')
    check('background_start_loads_config_before_engine',
          start.index('多语言_建许可区 ()') < start.index('读取配置 (配置文本)') < start.index('机架引擎_启动 ('))
    edge = EDGE.read_text(encoding='utf-8-sig')
    opener = syntax.section(edge, 'Edge_电音助手_打开')
    check('position:host_validates_monitor_and_work_area', 'MonitorFromRect (取变量数据地址 (局_矩形), 0)' in opener and 'GetMonitorInfoA (局_显示器' in opener
          and 'Edge_电音助手_切换DPI ()' in opener and '进程内独立_恢复DPI (局_旧上下文)' in opener and '小于 (局_左, 0)' not in opener)
    remember = '\n'.join(active_lines(syntax.section(edge, 'Edge_电音助手_记位置')))
    clear = '\n'.join(active_lines(syntax.section(edge, 'Edge_电音助手_置透明')))
    check('transparent:per_pixel_like_original_window', 'CreateRectRgn (0, 0, -1, -1)' in clear and 'DwmEnableBlurBehindWindow (集_电音_窗口, 局_模糊)' in clear
          and '赋值 (局_模糊.dwFlags, 3)' in clear and '赋值 (局_模糊.fEnable, 真)' in clear and '赋值 (局_模糊.hRgnBlur, 局_区域)' in clear and 'DeleteObject (局_区域)' in clear)
    can = '\n'.join(active_lines(syntax.section(edge, 'Edge_电音助手_可透明')))
    check('transparent:only_win8_plus_with_composition', 'RtlGetNtVersionNumbers_整数型 (局_主, 局_次, 局_构建)' in can and '小于 (局_次, 2)' in can and 'DwmIsCompositionEnabled (局_合成)' in can)
    opener_code = '\n'.join(active_lines(syntax.section(edge, 'Edge_电音助手_打开')))
    check('transparent:decided_before_browser', opener_code.index('赋值 (集_电音_可透明, Edge_电音助手_可透明 ())') < opener_code.index('Edge_电音助手_创建浏览器 ()')
          and '集_电音_浏览器.置背景色 (取颜色值 (90, 160, 243), 集_电音_可透明)' in syntax.section(edge, 'Edge_电音助手_创建浏览器'))   # Windows 7 的不透明底色＝胶囊色（窗口按页面形状裁剪后只露在电音强度条里，见 test_dianyin_shape.py）
    # 透明在页面就绪后才开（就绪前 DLL 画的提示卡片是 GDI 画的，开了透明会发虚）；浏览器进程退出时先关
    msg_src = syntax.section(edge, 'Edge_电音助手_收到消息')
    ready_branch = msg_src[msg_src.index('.判断开始 (等于 (局_命令, “ready”))'):msg_src.index('.判断 (等于 (局_命令, “auto”))')]
    turn_on = '\n'.join(active_lines(syntax.section(edge, 'Edge_电音助手_开启透明')))
    check('transparent:enabled_after_page_ready_only', 'Edge_电音助手_开启透明 ()' in ready_branch and ready_branch.index('Edge_电音助手_开启透明 ()') < ready_branch.index('Edge_电音助手_显示 ()') and '赋值 (集_电音_透明, 假)' in opener_code
          and 'Edge_电音助手_置透明 ()' not in opener_code and 'Edge_电音助手_开启透明 ()' not in opener_code and '赋值 (集_电音_透明, 真)' in turn_on and 'Edge_电音助手_置透明 ()' in turn_on
          and 'RedrawWindow_int (集_电音_窗口, 0, 0, 位或 (1, 4, 128, 256))' in turn_on)
    # 浏览器宿主窗口（WebView2Bridge）在透明背景下先铺系统底色、再请父窗口画背景：父窗口在 WM_ERASEBKGND／WM_PRINTCLIENT 里涂黑，透明处才不发灰
    bridge = (EPL / '依赖库/WebView2Bridge/src/wv_host.cpp').read_text(encoding='utf-8', errors='replace')
    pbg = bridge[bridge.index('void PaintParentBg(HWND host, HDC dc) {'):]
    pbg = pbg[:pbg.index('\n}\n')]
    check('transparent:bridge_host_asks_parent_for_background', 'FillSolid(dc, cr, GetSysColor(COLOR_3DFACE));' in pbg and 'fn(host, dc, &cr)' in pbg
          and 'if (transparent) PaintParentBg(host, dc);' in bridge)
    proc_src = syntax.section(edge, 'Edge_电音助手_窗口过程')
    erase = proc_src[proc_src.index('.如果真 (等于 (消息, 20))'):]
    erase = erase[:erase.index('.如果真 (并且 (等于 (消息, 792), 集_电音_透明))') + 200]
    check('transparent:parent_paints_black_for_bridge_host', '.如果真 (集_电音_透明)\n        Edge_电音助手_涂黑 (参数1)' in erase.replace('\r\n', '\n')
          and '.如果真 (并且 (等于 (消息, 792), 集_电音_透明))' in erase and 'FillRect (设备场景, 局_矩形, GetStockObject (4))' in syntax.section(edge, 'Edge_电音助手_涂黑'))
    turn_off = '\n'.join(active_lines(syntax.section(edge, 'Edge_电音助手_关闭透明')))
    check('transparent:browser_exit_turns_it_off_until_ready', '.如果真 (等于 (进程类型, #WV进程_浏览器进程退出))' in syntax.section(edge, 'Edge_电音助手_进程崩溃')
          and 'Edge_电音助手_关闭透明 ()' in syntax.section(edge, 'Edge_电音助手_进程崩溃') and '赋值 (局_模糊.fEnable, 假)' in turn_off
          and '赋值 (集_电音_透明, 假)' in turn_off and '赋值 (集_电音_可透明, 假)' in syntax.section(edge, 'Edge_电音助手_关闭'))
    rebuild = '\n'.join(active_lines(syntax.section(edge, 'Edge_电音助手_重建')))
    check('transparent:rebuild_turns_it_off_until_ready', 'Edge_电音助手_关闭透明 ()' in rebuild and rebuild.index('Edge_电音助手_关闭透明 ()') < rebuild.index('集_电音_浏览器.销毁 ()'))
    proc_lines = [x.strip() for x in active_lines(syntax.section(edge, 'Edge_电音助手_窗口过程')) if x.strip()]
    paint_at = proc_lines.index('.如果真 (等于 (消息, 15))') if '.如果真 (等于 (消息, 15))' in proc_lines else -1
    check('transparent:static_class_never_paints', paint_at >= 0 and proc_lines[paint_at + 1] == '返回 (DefWindowProc (句柄, 消息, 参数1, 参数2))'
          and '.如果真 (等于 (消息, 798))' in proc_lines)
    jy_dll = (EPL / '模块/精易模块v9.3.5[源码].e~/DLL.e.txt').read_text(encoding='utf-8-sig')
    check('transparent:uses_existing_jingyi_declaration_and_page_background_clear', '.DLL命令 DwmEnableBlurBehindWindow, 整数型, "Dwmapi.dll", "DwmEnableBlurBehindWindow", 公开' in jy_dll
          and '.参数 pBlurBehind, 模糊属性, 传址' in jy_dll and not (EPL / 'DLL.e.txt').exists()
          and 'background: transparent;' in (PROJECT / 'css/dianyinAssistant.css').read_text(encoding='utf-8') and '#2d7d9a' not in (PROJECT / 'css/dianyinAssistant.css').read_text(encoding='utf-8'))
    check('position:minimized_not_recorded_and_dpi_consistent', 'IsIconic (集_电音_窗口)' in remember and 'Edge_电音助手_切换DPI ()' in remember)
    js = (PROJECT / 'js/dianyinAssistant.js').read_text(encoding='utf-8')
    epl_commands = set(re.findall(r'等于 \(局_命令, “([a-z]+)”\)', syntax.section(edge, 'Edge_电音助手_收到消息')))
    js_commands = set(re.findall(r"post\('([a-z]+)(?::|')", js))
    check('page_and_host_agree_on_commands', js_commands == epl_commands == {'ready', 'auto', 'mode', 'player', 'strength', 'edit', 'dialog', 'drag', 'close', 'shape'})   # shape：只在 Windows 7，页面报形状、宿主裁剪窗口
    received = syntax.section(edge, 'Edge_电音助手_收到消息')
    received_code = '\n'.join(active_lines(received))
    check('host_defers_modal_work_out_of_web_callback', 'SendMessageA' not in received_code and '界面_切换自动切换' not in received_code
          and 'Edge_电音助手_关闭' not in received_code and '&Edge_电音助手_开始拖动' in received_code and '&Edge_电音助手_切换自动' in received_code
          and 'PostMessageA (集_电音_窗口, 16, 0, 0)' in received_code)
    drag = '\n'.join(active_lines(syntax.section(edge, 'Edge_电音助手_开始拖动')))
    check('drag_only_while_button_held', drag.index('GetAsyncKeyState (1)') < drag.index('SendMessageA (集_电音_窗口, 161, 2, 0)'))
    show = '\n'.join(active_lines(syntax.section(edge, 'Edge_电音助手_显示')))
    check('first_ready_activates_once_fallback_cancelled', '时钟_销毁 (集_电音_窗口, 7360702)' in show and '赋值 (集_电音_已显示, 真)' in show
          and '.如果 (集_电音_已显示)' in received_code and '取反 (集_电音_已显示)' in syntax.section(edge, 'Edge_电音助手_显示兜底'))
    check('player_picked_by_index_not_converted_name', '电音助手.界面_取播放器 (到整数 (局_参数), )' in received_code and '编码_Utf8到Ansi' not in received_code
          and '“pp”' not in edge and '“pi”' in syntax.section(edge, 'Edge_电音助手_状态JSON'))
    opener_src = syntax.section(edge, 'Edge_电音助手_打开')
    check('floating:topmost_without_taskbar_button', 'CreateWindowExA (136, “STATIC”, “”, 位或 (-2147483648, 33554432, 256)' in opener_src
          and '262144' not in opener_src and '131072' not in opener_src)
    keep = '\n'.join(active_lines(syntax.section(edge, 'Edge_电音助手_保持置顶')))
    covered = '\n'.join(x for x in active_lines(syntax.section(edge, 'Edge_电音助手_被遮挡')) if not x.strip().startswith(('.子程序', '.局部变量', '.参数')))
    common = COMMON.read_text(encoding='utf-8-sig')   # the cover test is the shared 遮挡_取被盖住比例 (executed in test_window_cover.py)
    shared = '\n'.join(x for name in ('遮挡_取被盖住比例', '遮挡_算不算', '遮挡_是否被其拥有') for x in active_lines(syntax.section(common, name)) if not x.strip().startswith(('.子程序', '.局部变量', '.参数')))
    check('floating:no_reentry_and_own_popups_never_cover', '遮挡_取被盖住比例 (集_电音_窗口, 真, 假, )' in covered and '处理事件' not in covered + shared
          and '遮挡_是否被其拥有 (参_它, 参_我)' in shared and '小于 (局_次数, 1000)' in shared)
    check('floating:not_raised_while_in_use', '等于 (GetForegroundWindow (), 集_电音_窗口)' in keep and '集_电音_对话框打开' in keep
          and '赋值 (集_电音_对话框打开, 假)' in syntax.section(edge, 'Edge_电音助手_关闭'))
    check('floating:stays_on_top_without_stealing_focus', 'SetWindowPos (集_电音_窗口, -1, 0, 0, 0, 0, 位或 (1, 2, 16))' in keep
          and '取反 (Edge_电音助手_有弹出菜单 ())' in keep and 'Edge_电音助手_被遮挡 ()' in keep and '窗口_是否被遮挡' not in keep
          and '“#32768”' in syntax.section(edge, 'Edge_电音助手_有弹出菜单')
          and '时钟_创建 (集_电音_窗口, 7360705, 1000, &Edge_电音助手_保持置顶)' in syntax.section(edge, 'Edge_电音助手_显示')
          and '时钟_销毁 (局_窗口, 7360705)' in syntax.section(edge, 'Edge_电音助手_关闭'))
    reopen = syntax.section(edge, 'Edge_电音助手_打开')
    check('reopen_repushes_texts_and_player_icons', reopen.index('赋值 (集_电音_文字语言, “”)') < reopen.index('返回 (真)'))
    loader = syntax.section(edge, 'Edge_电音助手_载入')
    check('repeated_toolbox_clicks_guarded', '集_载入许可.进入 ()' in loader and 'Edge_电音助手_内部载入 ()' in loader
          and '赋值 (集_电音_载入阶段, 2)' in syntax.section(edge, 'Edge_电音助手_内部载入'))
    toolbox = syntax.section((EPL / '代码/窗_主程序/窗口程序集_主窗口.form.e.txt').read_text(encoding='utf-8-sig'), '_菜单_工具箱_基调查询_被选择')
    # The background engine starts only when the 电音助手 window is opened (not at login): no player detection,
    # no bridge preparation or download before that.
    main_form = (EPL / '代码/窗_主程序/窗口程序集_主窗口.form.e.txt').read_text(encoding='utf-8-sig')
    loader_thread = syntax.section(main_form, '线程_载入电音助手')
    # The engine starts only once the window is actually on screen (机架联动_界面已显示): never while loading, so a
    # window that fails to open leaves nothing running, and waiting for old threads never delays the window.
    check('loading_the_window_never_starts_the_engine', '线程_创建 (&线程_载入电音助手' in toolbox
          and not re.search(r'机架联动_启动引擎|电音助手\.启动后台', '\n'.join(active_lines(toolbox)) + '\n'.join(active_lines(loader_thread))))
    host_src = (EPL / '代码/集_基础支持/机架联动_宿主.static.e.txt').read_text(encoding='utf-8-sig')
    start = syntax.section(host_src, '机架联动_启动引擎_内部')
    at = lambda s: start.find(s)
    launch = at('电音助手.启动后台 (')
    check('window_start_sets_host_callback_language_and_log_before_starting',
          0 <= at('电音助手.置宿主回调 (到整数 (&机架联动_宿主回调))') < launch and 0 <= at('电音助手.置后台语言 (') < launch
          and '到整数 (&机架联动_日志)))' in start and at('赋值 (集_机架引擎已启动, 真)') > launch >= 0)
    login_wrapper = syntax.section(host_src, '机架联动_登录后启动')
    check('relogin_runs_inside_the_start_stop_lock', 0 <= login_wrapper.find('集_机架引擎控制许可.进入 ()') < login_wrapper.find('机架联动_登录后启动_内部 ()') < login_wrapper.find('集_机架引擎控制许可.退出 ()'))
    login = syntax.section(host_src, '机架联动_登录后启动_内部')
    login_lines = [l.strip() for l in login.splitlines() if l.strip() and not l.strip().startswith(("'", '.子程序', '.参数', '.局部变量'))]
    check('login_no_longer_starts_the_engine', login_lines[:3] == ['.如果真 (取反 (集_机架引擎已启动))', '返回 ()', '.如果真结束']
          and '电音助手.置宿主回调' not in login and '电音助手.重新连接 ()' in login)
    check('stop_clears_the_started_flag', '赋值 (集_机架引擎已启动, 假)' in syntax.section(host_src, '机架联动_停止'))
    shown_host = syntax.section(host_src, '机架联动_界面已显示'); late = syntax.section(host_src, '机架联动_线程_启动引擎')
    check('window_show_is_the_only_engine_start_inside_the_lock', '线程_创建 (&机架联动_线程_启动引擎' in shown_host
          and 0 <= late.find('集_机架引擎控制许可.进入 ()') < late.find('.如果真 (并且 (集_机架界面已显示, 取反 (集_机架退出中)))') < late.find('机架联动_启动引擎_内部 ()') < late.find('集_机架引擎控制许可.退出 ()')
          and [n for n in re.findall(r'^\.子程序 ([^,\n]+)', host_src, re.M) if '机架联动_启动引擎_内部 ()' in syntax.section(host_src, n)] == ['机架联动_线程_启动引擎'])
    check('exit_marks_itself_first_so_a_waiting_start_gives_up', [l.strip() for l in syntax.section(host_src, '机架联动_停止').splitlines()[1:3] if l.strip()][:1] == ["赋值 (集_机架退出中, 真)  ' 先置上：还在等锁的启动线程拿到锁后不再启动"])
    # Closing the 电音助手 window stops the engine (no background running); program exit keeps its own full stop.
    edge_src = (EPL / '代码/集_Edge浏览器/程序集_Edge.static.e.txt').read_text(encoding='utf-8-sig').replace('\r\n', '\n')
    wndproc = syntax.section(edge_src, 'Edge_电音助手_窗口过程')
    on_close = wndproc[wndproc.find(".如果真 (等于 (消息, 16))"):]
    on_close = on_close[:on_close.find('.如果真结束')]
    check('closing_the_window_stops_the_engine', 0 <= on_close.find('Edge_电音助手_关闭 ()') < on_close.find('机架联动_关闭引擎 ()'))
    # 退出程序：确定退出后先关电音基调窗口，再做配置同步、等上传（最多 60 秒）这些慢的收尾；只缩到托盘时不关
    main_form = (EPL / '代码/窗_主程序/窗口程序集_主窗口.form.e.txt').read_text(encoding='utf-8-sig').replace('\r\n', '\n')
    closing = '\n'.join(active_lines(syntax.section(main_form, '黑月_主窗口_窗口可否被关闭')))
    at = closing.find('Edge_电音助手_关闭 ()')
    timer_at = max(closing.find('时钟_销毁 (取窗口句柄 ()'), closing.find('时钟_销毁 (主窗口.取窗口句柄 ()'))   # 项目 B 写作 主窗口.取窗口句柄 ()
    check('exit_closes_the_key_window_before_the_slow_cleanup', at > closing.find('.如果真 (等于 (全_是否关闭本软件, 假))') >= 0
          and at > closing.find('赋值 (全_导入结束后退出, 真)') >= 0
          and at < timer_at and at < closing.find('主窗口.保存组件配置_并上传到服务器_加标识 ()')
          and at < closing.find('主播音效_上传_队列_是否空闲 ()') and at < closing.find('Edge_销毁 ()')
          and at < closing.find('退出_隐藏本进程窗口 ()') < timer_at)
    exit_proc = next(n for n in ('退出前结束音效子进程', '退出前结束子进程') if '.子程序 ' + n + ',' in main_form)   # 项目 A 与项目 B 的名字
    ending = '\n'.join(active_lines(syntax.section(main_form, exit_proc)))
    check('every_exit_path_hides_every_window_before_stopping_the_engine', 0 <= ending.find('退出_隐藏本进程窗口 ()') < ending.find('机架联动_停止 ()'))
    check('the_single_purpose_key_window_hide_is_gone', 'Edge_电音助手_隐藏' not in edge and 'Edge_电音助手_隐藏' not in main_form)
    check('program_exit_does_not_use_the_window_close_stop', '机架联动_关闭引擎' not in syntax.section(edge_src, 'Edge_销毁'))
    closer = syntax.section(host_src, '机架联动_关闭引擎'); worker = syntax.section(host_src, '机架联动_线程_关闭引擎')
    check('window_close_stops_off_the_ui_thread_inside_the_lock',
          '赋值 (集_机架引擎已启动, 假)' in closer and '线程_创建 (&机架联动_线程_关闭引擎' in closer and '停止后台' not in closer
          and 0 <= worker.find('集_机架引擎控制许可.进入 ()') < worker.find('电音助手.停止后台 (10000)') < worker.find('集_机架引擎控制许可.退出 ()'))
    exit_stop = syntax.section(host_src, '机架联动_停止')
    check('program_exit_stop_uses_the_same_lock_with_a_bound', 0 <= exit_stop.find('.如果 (集_机架引擎控制许可.进入 (15000))') < exit_stop.find('电音助手.关闭后台 ()') < exit_stop.find('集_机架引擎控制许可.退出 ()'))
    engine_start = syntax.section(engine, '机架引擎_启动')
    check('restart_reaps_old_threads_before_starting_new_ones',
          0 <= engine_start.find('机架引擎_收线程 (30000)') < engine_start.find('启动线程 (&机架引擎_线程_联动'))
    check('hotkeys_do_nothing_while_the_engine_is_stopped',
          all('.如果真 (或者 (等于 (集_机架_许可证, 0), 取反 (集_机架_运行)))' in syntax.section(engine, n) for n in ('机架引擎_移调', '机架引擎_切换锁定')))
    main_code = '\n'.join(p.read_text(encoding='utf-8-sig', errors='replace') for p in (EPL / '代码').rglob('*.e.txt'))
    check('main_program_has_no_exui_kernel_code', 'ExuiKrnln' not in main_code and '电音助手.载入窗口' not in main_code)
    configs = list(EPL.rglob('支持库.config.json'))
    check('no_project_declares_exui', bool(configs) and all('ExuiKrnln' not in p.read_text(encoding='utf-8-sig') for p in configs))
    module_code = '\n'.join('\n'.join(active_lines(p.read_text(encoding='utf-8-sig'))) for p in (MODULE / '代码').glob('*.e.txt'))
    check('module_code_uses_no_exui', not re.search(r'InitExui|信息框Ex_W|字体Ex数据|(?:标签|按钮|分组框|滑块条|组合框|单选框|图片框|图标列表框|窗口)EX|ATU \(', module_code)
          and not (MODULE / '模块/ExuiApi20220513.e~').exists() and not (MODULE / '模块/ExuiFunction20220513.e~').exists()
          and not (MODULE / '代码/窗口程序集_窗口1.form.e.txt').exists() and not (MODULE / '代码/窗口程序集_窗口2.form.e.txt').exists())
    page = syntax.section((EPL / '代码/窗_音效/窗口程序集_窗口_音效.form.e.txt').read_text(encoding='utf-8-sig'), '主播音效_电音页面')
    check('page_assembly_uses_own_resources', '#CSS_dianyinAssistant' in page and '#JS_dianyinAssistant' in page and 'window.__DY_WIN__=1;' in page)

    # ---- 3b. key line never shows an actual target that belongs to another song ----
    def key_line(**values):
        runtime = Runtime(language)
        runtime.functions.update({
            '多语言_基调显示W': lambda key: key.encode('utf-16-le') + b'\x00\x00',
            '多语言_音阶显示W': lambda scale: scale.encode('utf-16-le') + b'\x00\x00',
            '删除Unicode结尾空白字节': lambda data, flag: data[:-2] if data.endswith(b'\x00\x00') else data,
            '多语言_标签加值W': lambda label, value: value, '多语言_是否阿拉伯语': lambda: False,
            '编码_Ansi到Unicode': lambda text, flag: text.encode('utf-16-le'), '到文本': str,
            '多语言_基调标签文字W': lambda state, key, scale: ('STATE', state),
            '多语言_歌曲基调状态': lambda value: runtime.invoke('多语言_歌曲基调状态', value)})
        snapshot = SimpleNamespace(实际基调='D', 实际音阶='大调', 实际移调=0, 基调='C', 音阶='大调', 移调=0,
                                   音乐名W=song, 实际歌名W=song, 已锁定=False, 来源='server')
        for key, value in values.items():
            setattr(snapshot, key, value)
        result = runtime.invoke('多语言_机架基调行W', snapshot)
        return result if isinstance(result, tuple) else result.decode('utf-16-le').rstrip('\x00')
    other = '旧'.encode('utf-16-le') + b'\x00\x00'
    check('key_line:actual_for_this_song', key_line().startswith('D'))
    check('key_line:stale_actual_falls_back_to_song_key', key_line(实际歌名W=other).startswith('C'))
    check('key_line:never_pushed_uses_song_key', key_line(实际基调='', 实际歌名W=b'').startswith('C'))
    check('key_line:locked_keeps_locked_target', key_line(实际歌名W=other, 已锁定=True).startswith('D'))
    check('key_line:stale_and_unknown_says_not_found', key_line(实际歌名W=other, 基调='') == ('STATE', 3))
    # Chromatic 只是兜底时，基调行说原因（正在查询／查询不到），不再只显示一个 Chromatic；锁定或这首歌本身是 Chromatic 时照旧
    fallback = dict(实际基调='Chromatic', 实际音阶='Chromatic', 基调='', 音阶='')
    check('key_line:general_tuning_while_looking_up_says_looking_up', key_line(**fallback, 来源='') == ('STATE', 1))
    check('key_line:general_tuning_not_found_says_not_found', key_line(**fallback, 来源='server') == ('STATE', 3))
    check('key_line:locked_chromatic_kept', key_line(**fallback, 来源='server', 已锁定=True) == 'Chromatic')
    check('key_line:song_itself_chromatic_kept', key_line(实际基调='Chromatic', 实际音阶='Chromatic', 基调='C', 音阶='半音阶') == 'Chromatic')
    types = TYPES.read_text(encoding='utf-8-sig')
    snapshot_type = types.split('.数据类型 自定义_机架联动快照', 1)[1].split('.数据类型 ', 1)[0]
    check('snapshot_records_actual_song_and_publishes_it', '.成员 实际歌名W, 字节集' in snapshot_type and
          '不等于 (集_机架_快照.实际歌名W, 集_机架_已发布快照.实际歌名W)' in syntax.section(engine, '机架引擎_发布') and
          '赋值 (集_机架_快照.实际歌名W, 局_快照.音乐名W)' in link)
    success = link[link.index('赋值 (集_机架_快照.实际基调, 局_显示调)'):link.index('机架引擎_发布 ()', link.index('赋值 (集_机架_快照.实际基调, 局_显示调)'))]
    check('actual_song_set_only_inside_validated_push', '赋值 (集_机架_快照.实际歌名W, 局_快照.音乐名W)' in success)

    # ---- 3c. policy-hidden: bound hotkeys do not change persistent or session rack state ----
    for hidden in (False, True):
        runtime = regression.engine_runtime(engine)
        runtime.env['集_机架_快照'] = SimpleNamespace(移调=0, 音乐名W=song, 基调='C', 音阶='大调', 来源='server', 更新时间='t')
        runtime.env.update({'集_机架_服务未开放': hidden, '集_机架_目标版本': 1, '集_机架_锁定期望': False})
        runtime.invoke('机架引擎_移调', 1)
        runtime.invoke('机架引擎_切换锁定')
        runtime.invoke('机架引擎_锁定', True)
        changed = runtime.env['集_机架_快照'].移调 == 1 and runtime.env['集_机架_锁定期望'] is True
        check(f'hotkeys_inert_while_hidden:{hidden}', changed is (not hidden) and runtime.depth == 0
              and (bool(runtime.registry) is (not hidden)))

    for hidden in (False, True):
        runtime = regression.engine_runtime(engine)
        runtime.env['集_机架_快照'] = SimpleNamespace(自检结果=0)
        runtime.env.update({'集_机架_服务未开放': hidden, '集_机架_自检请求': False, '集_机架_自检时间': 0})
        runtime.invoke('机架引擎_自检')
        started = runtime.env['集_机架_快照'].自检结果 == 1 and runtime.env['集_机架_自检请求'] is True
        check(f'selfcheck_not_started_while_hidden:{hidden}', started is (not hidden) and runtime.depth == 0)
    hide_block = re.search(r'\.如果真 \(局_未开放\)\n((?:            [^\n]*\n)+)        \.如果真结束', link.replace('\r\n', '\n'))
    check('hiding_cancels_pending_selfcheck', hide_block is not None and all(item in hide_block.group(1) for item in [
        '赋值 (集_机架_自检请求, 假)', '赋值 (集_机架_快照.自检结果, 0)']))

    # A re-login between the out-of-lock op15 decision and applying it must win: no hiding, no log.
    lock_after_plugin_bits = link.index('EnterCriticalSectionP (集_机架_许可证)', link.index('赋值 (局_插件状态位, 机架引擎_宿主调用 (10'))
    apply_end = link.index('赋值 (集_机架_快照.状态编号, 局_状态编号)', lock_after_plugin_bits)
    first_use = re.search(r'^[ ]*(?:赋值 \(局_未开放|\.如果真 \(局_未开放\))', link[lock_after_plugin_bits:apply_end], re.M)
    apply_text = link[lock_after_plugin_bits + first_use.start():apply_end] if first_use else ''
    for pending in (False, True):
        runtime = regression.engine_runtime(engine)
        runtime.env['集_机架_快照'] = SimpleNamespace(支持速度=True, 自检结果=0)
        runtime.env.update({'局_未开放': True, '集_机架_重新配置': pending, '集_机架_服务未开放': False, '集_机架_停止请求': False,
                            '集_机架_自检请求': False, '局_状态编号': 19})
        runtime.execute_text(apply_text, runtime.env)
        applied = runtime.env['集_机架_服务未开放'] and runtime.env['集_机架_停止请求'] and runtime.env['局_状态编号'] == 22
        check(f'stale_policy_decision_ignored_after_relogin:{pending}', applied is (not pending) and runtime.env['局_未开放'] is (not pending))

    # ---- 3d. hotkey titles and panel visibility contract ---------------------------
    texts = {1: '移调', 2: '升半音', 3: '降半音', 4: '归零', 5: '锁定当前调'}
    english = {1: 'Transpose', 2: 'Up one semitone', 3: 'Down one semitone', 4: 'Reset', 5: 'Lock current key'}
    japanese = {1: '移調', 4: '元に戻す'}
    def title(operation, language_index, table):
        runtime = Runtime(CLASS.read_text(encoding='utf-8-sig'))
        runtime.functions.update({'多语言_机架文字W': lambda index: table[index].encode('utf-16-le') + b'\x00\x00',
                                  '多语言_序号': lambda: language_index,
                                  '删除Unicode结尾空白字节': lambda data, flag: data[:-2] if data.endswith(b'\x00\x00') else data})
        return runtime.invoke('取联动快捷键文字W', operation).decode('utf-16-le')
    check('hotkey_titles:zh', [title(op, 1, texts) for op in (1, 2, 3, 4)] == ['升半音\x00', '降半音\x00', '移调归零\x00', '锁定当前调\x00'])
    check('hotkey_titles:ja_dot', title(3, 3, japanese) == '移調・元に戻す\x00')
    check('hotkey_titles:en_separator', title(3, 2, english) == 'Transpose · Reset\x00' and title(2, 2, english) == 'Down one semitone\x00')
    check('hotkey_titles:out_of_range', title(0, 1, texts) == '\x00' and title(5, 1, texts) == '\x00')
    klass = CLASS.read_text(encoding='utf-8-sig')
    for state, expected in ((22, False), (0, True), (16, True), (2, True)):
        runtime = Runtime(klass)
        runtime.local_factories['自定义_机架联动快照'] = lambda: SimpleNamespace()
        runtime.functions['机架引擎_快照'] = lambda target, state=state: setattr(target, '状态编号', state)
        check(f'panel_group_visible:{state}', runtime.invoke('取联动入口可见') is expected)
    funckeys = FUNCKEYS.read_text(encoding='utf-8-sig')
    table_builder = syntax.section(funckeys, '功能快捷键HTML_取快捷键表')
    check('panel_table_reports_rack_visibility', 'yyJson_构造.置整数 (, “rk”, 选择 (电音助手.取联动入口可见 (), 1, 0), )' in table_builder)
    names = syntax.section(funckeys, '功能快捷键HTML_取功能名表')
    keys = re.findall(r'加入成员 \(参_键名, “([a-z]+)”\)', names)
    dialogs = (PROJECT / 'js/dialogs.js').read_text(encoding='utf-8')
    fk = dialogs[dialogs.index('var FK_LIST = ['):dialogs.index('];', dialogs.index('var FK_LIST = ['))]
    check('panel_lists_every_EPL_function_in_order', keys == re.findall(r"\{ k: '([a-z]+)'", fk) and len(keys) == 18)

    # ---- 4. texts, menu name and data integrity -----------------------------------
    a = language.index('.子程序 多语言_机架文字W_语种,')
    rows = re.findall(r'返回 \(多项选择 \(序号, (.*)\)\)', language[a:language.index('.子程序 多语言_机架状态W,', a)])
    decoded = [[bytes(int(n) for n in cell.split(','))[:-2].decode('utf-16-le')
                for cell in re.findall(r'\{([^{}]*)\}', row)] for row in rows]
    check('switched_to_names_plugin_in_19_languages', [row[12] for row in decoded] == [SWITCHED[i] for i in range(1, 20)])
    check('consent_text_kept', decoded[0][10].startswith('允许随歌曲自动切换机架修音插件的基调和音阶吗？'))
    check('general_tuning_texts_plain_language', decoded[0][22] == '暂用通用修音，查到基调后自动切换' and decoded[0][36] == '暂用通用修音，可右键“添加/报错”补上'
          and all(len(row) == 38 and 'Chromatic' not in row[22] + row[36] for row in decoded))   # 38：下载桥组件的提示（状态 23）
    raw = I18N.read_text(encoding='utf-8')
    decoder = json.JSONDecoder()
    zh, unused = decoder.raw_decode(raw, re.search(r'^window\.I18N_DATA\s*=\s*', raw, re.M).end())
    keys, unused = decoder.raw_decode(raw, re.search(r'^window\.I18N_MENU_KEYS\s*=\s*', raw, re.M).end())
    names = {'zh-Hans': zh['zh-Hans']['menu.菜单_工具箱_基调查询']}
    for match in re.finditer(r'/\*@@[A-Za-z-]+@@\*/\(window\.I18N_PACKS=window\.I18N_PACKS\|\|\{\}\)\["([A-Za-z-]+)"\]=', raw):
        pack, unused = decoder.raw_decode(raw, match.end())
        names[match.group(1)] = pack['d']['menu.菜单_工具箱_基调查询']
    check('toolbox_entry_named_assistant_in_19_languages', names == MENU_NAME)
    menu_sizes = re.findall(r'重定义数组 \(集_多语言_菜单译文W?, 假, (\d+)\)', (EPL / '代码/窗_音效/窗口程序集_窗口_音效.form.e.txt').read_text(encoding='utf-8-sig'))   # 条数以 EPL 的数组大小为准，键表只许往后加
    chinese_only = '多语言_词典包' not in syntax.section((EPL / '代码/窗_音效/窗口程序集_窗口_音效.form.e.txt').read_text(encoding='utf-8-sig'), '主播音效_电音页面')   # 项目 B 只有简体中文：页面不带语言包，也没有菜单译文表
    check('menu_key_order_unchanged', keys[4] == 'menu.菜单_工具箱_基调查询' and len(keys) >= 246 and ((chinese_only and menu_sizes == []) or (len(menu_sizes) == 4 and set(menu_sizes) == {str(len(keys))})))
    form_bytes = FORM.read_bytes()
    form = json.loads(form_bytes[3:].decode('utf-8'))
    check('native_menu_fallback_named_assistant', [m['Text'] for m in form['Menus'] if m['Name'] == '菜单_工具箱_基调查询'] == ['电音助手']
          and form_bytes.startswith(b'\xef\xbb\xbf') and b'\n' not in form_bytes.replace(b'\r\n', b''))
    host = HOST.read_text(encoding='utf-8-sig')
    check('host_log_names_window', '可从电音助手窗口重试' in host and '基调查询窗口' not in host)
    check('identifiers_and_config_keys_kept', '_菜单_工具箱_基调查询_被选择' in json.dumps(form, ensure_ascii=False)
          and '类_基调查询' in (MODULE / '代码/目录.desc.json').read_text(encoding='utf-8-sig'))

    result = {'checks': len(checks), 'passed': len(checks) - len(failures), 'failures': failures,
              'source_sha256': {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                                for path in (ENGINE, CLASS, LANGUAGE, HOST, FORM, I18N)},
              'scope': 'Real EPL statements on the shared evaluator; host, bridge, Win32 and EXUI are substitutes; no EPL compiler or real rack'}
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
