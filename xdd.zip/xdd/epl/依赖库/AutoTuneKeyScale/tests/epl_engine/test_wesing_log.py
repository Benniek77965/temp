#!/usr/bin/env python3
"""Execute the production EPL 全民K歌 (WeSing) log reader and the QQ音乐 process check with explicit substitutes.

Not an EPL compiler, real Windows file I/O or real windows. The log lines follow the real WeSing format
(UTF-16LE without BOM; each StartKSong event written on five lines with the same JSON), but carry no account
data: real WeSing logs contain cookies and tokens and are never used as fixtures. File sizes can be virtual,
so the 64-bit offsets are exercised without large fixtures.

The 精易模块 text commands the reader uses (寻找文本W, 倒找文本W, 取文本中间W, 取文本长度W, 是否为空W) run from their
real source; only the Win32 calls under them are substitutes: StrStrW is wcsstr, StrRStrIW follows Wine's
implementation (including the reproduced Windows end adjustment), lstrlenW counts to the first U+0000, and
pointers are emulated. 子文本替换W, un_连接 and 删除Unicode结尾空白字节 copy memory, so they are Python
substitutes written from their source.
"""
from pathlib import Path
import argparse
import json
import re
import struct
import check as syntax
from review_regression import Runtime, NextIteration
from test_fanxing_log import clean_inline_comments

APPDATA = 'C:\\Users\\测试😀\\AppData\\Roaming\\'
DIR_APP = APPDATA + 'Tencent\\WeSing\\WeSingCache\\Log\\WeSing\\'
DIR_E = 'E:\\WeSingCache\\Log\\WeSing\\'
W = lambda text: (text + '\0').encode('utf-16-le')
JY = Path(__file__).resolve().parents[4] / '模块/精易模块v9.3.5[源码].e~/代码/杂项/集_自己添加的.static.e.txt'
JY_REAL = ('寻找文本W', '倒找文本W', '取文本中间W', '取文本长度W', '是否为空W', '文本_取出中间文本W')


def jingyi_source(names=JY_REAL):
    text = JY.read_text('utf-8-sig').replace('\r', '')
    return '\n'.join(re.search(r'^\.子程序 ' + n + r',[^\n]*\n.*?(?=^\.子程序 |\Z)', text, re.M | re.S).group(0) for n in names)


class Ptr:
    def __init__(self, buf, off=0):
        self.buf, self.off = buf, off

    def __add__(self, k):
        return Ptr(self.buf, self.off + int(k))
    __radd__ = __add__

    def __sub__(self, other):
        return self.off - other.off

    def wstr(self):
        out = []
        for i in range(max(self.off, 0), len(self.buf) - 1, 2):
            c = self.buf[i] | self.buf[i + 1] << 8
            if c == 0:
                break
            out.append(chr(c))
        return ''.join(out)


def str_str_w(p, q, fold=False):
    hay, needle = p.wstr(), q.wstr()
    if fold:
        hay, needle = hay.lower(), needle.lower()
    k = hay.find(needle) if needle else -1
    return 0 if k < 0 else Ptr(p.buf, p.off + 2 * k)


def str_rstr_iw(first, end, search, fold=True):
    """Wine kernelbase StrRStrIW: with an end pointer the scan may start a match up to len-1 characters past it."""
    s, needle = first.wstr(), search.wstr()
    n = len(needle)
    if not n:
        return 0
    e = (end.off - first.off) // 2
    rest = len(s) - e if 0 <= e <= len(s) else 0
    limit = e + min(n - 1, rest)
    if limit < n:
        return 0
    # the last i with i + n <= limit -- same as Wine's forward scan, without its cost on large test logs
    i = (s.lower().rfind(needle.lower(), 0, limit) if fold else s.rfind(needle, 0, limit))
    return 0 if i < 0 else Ptr(first.buf, first.off + 2 * i)


def jy_replace(text, old, new=None, *rest):
    """子文本替换W: replace every occurrence in the wide string; the source text comes back unchanged when absent."""
    src, o = Ptr(bytes(text)).wstr(), Ptr(bytes(old)).wstr()
    if not o or o not in src:
        return text
    return W(src.replace(o, Ptr(bytes(new or b'')).wstr()))


def jy_trim_end(data, standard=None):
    """删除Unicode结尾空白字节: up to the first character-aligned U+0000; with 真 a terminator is put back."""
    if len(data) < 2:
        return b''
    i = next((k for k in range(0, len(data) - 1, 2) if data[k:k + 2] == b'\0\0'), len(data))
    if i == 0:
        return b''
    return data[:i] + (b'\0\0' if standard else b'')


def line(text, level='I'):
    return f'[{level}]\t\t46200\t2026-11-06 12:37:12:183\t{text}\n'.encode('utf-16-le')


def start(song, singer, callback='StartKSong1.1'):
    data = {'mid': '001', 'singerid': '002', 'songname': song, 'size': '1', 'singername': singer, 'lSongMask': '1', 'iHasCp': '1'}
    cmd = json.dumps({'cmd': {'value': '1074', 'version': '800', 'subcmd': {'value': 'StartKSong', 'callback': callback, 'data': data}}},
                     ensure_ascii=False, separators=(',', ':'))
    return (line('External.ClientInterfaceForWeb enter: cmd: ' + cmd, 'D') + line('CKSongsApiCli::FakeAsyncXmlCmd enter: identifier: 4 cmd: ' + cmd, 'D')
            + line('CQMApiWorkSvrMng:0x0340b15c - OnCmdCome - xml :' + cmd) + line('[WebContent] :' + cmd) + line('DealWebXmlInfo ParseJson------- [' + cmd + ']'))


def start_without_singer(song, mid):
    """The other StartKSong format (started from the played list): song and MID only."""
    data = {'mid': mid, 'duration': '', 'songname': song, 'lSongMask': 'undefined', 'iHasCp': 'undefined'}
    cmd = json.dumps({'cmd': {'value': '1074', 'version': '800', 'subcmd': {'value': 'StartKSong', 'callback': 'StartKSong9.9', 'data': data}}},
                     ensure_ascii=False, separators=(',', ':'))
    return line('External.ClientInterfaceForWeb enter: cmd: ' + cmd, 'D') + line('[WebContent] :' + cmd)


FAKE_COOKIE = 'ver=2.21.176.1220; qua=V1_WIN_KG_TEST; uid=1; opentype=1; openid=FAKEOPENID; openkey=FAKE/KEY+1='


def cookie_line(cookie=FAKE_COOKIE, cr=False):
    text = '[I]\t\t30248\t2026-11-06 15:21:28:797\tCProtocolCgiBase::GetLoginCookieHeader(), strCookieHeader = Cookie: ' + cookie
    return (text + ('\r' if cr else '') + '\n').encode('utf-16-le')


def g_tk(openkey):
    h = 5381
    for ch in openkey:
        h += (h << 5) + ord(ch)
    return h & 0x7fffffff


class ZyJson:
    """zyJsonDocument as documented: 解析UTF8 takes text whose bytes are UTF-8, paths are a.b.c[0],
    取文本 gives the unescaped value (the module passes 真, 真), a missing path gives empty text."""
    def __init__(self):
        self.data = None

    def 解析UTF8(self, text, *unused):
        try:
            self.data = json.loads(text.encode('latin-1').decode('utf-8'))
            return True
        except (ValueError, UnicodeError):
            return False

    def select(self, path):
        node = self.data
        for name, index in re.findall(r'([^.\[\]]+)|\[(\d+)\]', path or ''):
            if name:
                node = node.get(name) if isinstance(node, dict) else None
            else:
                node = node[int(index)] if isinstance(node, list) and int(index) < len(node) else None
        return node

    def 取文本(self, path=None, *unused):
        value = self.select(path)
        return '' if value is None or isinstance(value, (dict, list)) else value if isinstance(value, str) else str(value)

    def 解析W(self, text, *unused):
        """Wide text, read up to the first U+0000 (the real one uses lstrlenW)."""
        try:
            self.data = json.loads(text.decode('utf-16-le').split('\0')[0])
            return True
        except (ValueError, UnicodeError):
            return False

    def 取文本W(self, path=None, *unused):
        value = self.取文本(path.decode('utf-16-le').split('\0')[0] if isinstance(path, bytes) else path)
        return W(value) if value else b'\0\0'

    def 取所有属性名(self, path=None):
        value = self.select(path)
        return list(value) if isinstance(value, dict) else []


def strict_b64(text, *unused):
    """Strict: anything outside the alphabet (such as the backslash of a JSON-escaped slash) gives nothing."""
    try:
        return __import__('base64').b64decode(text, validate=True)
    except ValueError:
        return b''


def song_info_reply(singer='BY2', title='爱丫爱丫', with_unknown=True):
    """Shaped like the real fcg_ksonginfo_get reply: spaces after colons, base64 with JSON-escaped slashes."""
    xml = ('<?xml version="1.0" encoding="utf-8"?>\n<QrcInfos>\n<LyricInfo LyricCount="1">\n<Lyric_1 LyricType="1" LyricContent="[ti:' + title
           + ']\n[ar:' + singer + ']\n[al:]\n[by:]\n[offset:0]\n[26850,2513]把(26850,328)爱(27178,584)???"/>\n</LyricInfo>\n</QrcInfos>\n')
    b64 = __import__('base64').b64encode(xml.encode('utf-8')).decode()
    while '/' not in b64:            # make sure the reply really carries a JSON-escaped slash
        xml += '?'
        b64 = __import__('base64').b64encode(xml.encode('utf-8')).decode()
    entry = '"%s": { "iCode": 0, "iCompressType": 0, "iTime": 1648008509, "strContent": "%s", "strVersion": "5" }'
    items = [entry % ('CONTENT_LRC', ''), entry % ('CONTENT_QRC', 'QzZDNTAyMTIxMjNDM0Qw'), entry % ('unknown' if with_unknown else 'CONTENT_TRANS', b64.replace('/', '\\/'))]
    return ('{"code":0,"subcode":0,"message":"","default":0,"data":{ "iAdjust": 0, "iHasCp": 1, "mapContent": { ' + ', '.join(items)
            + ' }, "strKSongMid": "003ioXz03eSg7N" }}').encode('utf-8')


def filler(count):
    return b''.join(line('CKSongsDlg::OnTimerHandleCheckWKeyValid %06d' % i) for i in range(count))


def misaligned_marker():
    """A line whose bytes contain "value":"StartKSong" at an odd offset (made of ordinary CJK characters)."""
    pattern = '"value":"StartKSong"'.encode('utf-16-le')
    chars = [chr(pattern[0] << 8 | 0x41)] + [chr(pattern[i + 1] << 8 | pattern[i]) for i in range(1, len(pattern) - 1, 2)]
    chars.append(chr(0x4E00 | pattern[-1]))          # 一 (00 4E): its low byte is the pattern's last byte
    data = line('ParseJson ' + ''.join(chars) + ' "songname":"假歌","singername":"假歌手"')
    at = data.find(pattern)
    assert at >= 0 and at % 2 == 1, 'the marker must really contain the pattern at an odd offset'
    return data


class Machine(Runtime):
    def __init__(self, source):
        super().__init__(clean_inline_comments(source + '\n' + jingyi_source()))
        self.env.update({'#引号': '"', '#换行符': '\r\n', '集_K歌日志_文件W': b'', '集_K歌日志_身份': b'', '集_K歌日志_已读': 0, '集_K歌日志_找文件时间': 0,
                         '集_K歌日志_开唱行': b'', '集_K歌日志_Cookie': '', '集_K歌日志_读错': False, '集_K歌_待查MID': '', '集_K歌_待查Cookie': '',
                         '集_K歌_查询中MID': '', '集_K歌_歌手MID': [], '集_K歌_歌手名W': [], '集_K歌_失败MID': '', '集_K歌_失败时间': 0,
                         '集_K歌_许可': __import__('types').SimpleNamespace(进入=lambda *a: self.lock.append('进入'), 退出=lambda: self.lock.append('退出')),
                         '集_播放器_进程名组': [], '集_播放器_进程ID组': [], '集_播放器_进程时间': 0,
                         '集_QQ音乐_进程ID组': [], '集_QQ音乐_取进程时间': 0})
        self.local_factories.update({'字节集': bytes, '日期时间型': int, 'zyJsonDocument': ZyJson})
        self.present, self.now, self.fail = True, 100000, ''
        self.drives = {'C': 3, 'D': 5, 'E': 3, 'F': 2}        # fixed, CD-ROM, fixed, removable
        self.files = {}                                       # path -> {'content', 'mtime', 'identity', 'virtual'}
        self.enumerated, self.opened, self.closed, self.reads, self.handles = [], [], [], [], {}
        self.windows, self.next_window, self.titles, self.pids, self.names, self.name_lookups = [], {}, {}, {}, {}, []
        self.lock, self.requests, self.logs, self.reply, self.status = [], [], [], b'', 200
        self.functions.update({
            '系统_取启动时间': lambda: self.now,
            '目录_取特定目录W': lambda *a: b'' if self.fail == 'appdata' else W(APPDATA),
            'GetDriveTypeA': lambda root: self.drives.get(root[0], 1) if len(root) == 3 and root[1:] == ':\\' else 1,
            '字符': chr,
            '编码_Ansi到Unicode': lambda text, *a: text.encode('utf-16-le') if a and a[0] else W(text),
            '文件_取时间_最后修改W': lambda path: self.files[self.path(path)]['mtime'],
            '编码_Unicode到usc2': lambda data, *a: data.decode('utf-16-le').rstrip('\0'),
            '编码_Unicode到Ansi': lambda data, *a: data.decode('utf-16-le').rstrip('\0'),
            '到小写': lambda text: text.lower(),
            '取字节集长度': len, '取空白字节集': lambda n: b'\0' * n, '取数组成员数': len, '到长整数': int,
            '求余数': lambda a, b: a % b, '到整数': int,
            '编码_BASE64解码': strict_b64,
            '编码_Utf8到Unicode': lambda data: W(data.decode('utf-8', errors='replace')),
            '删首尾空': lambda text: text.strip(' '), '取代码': lambda text, i: ord(text[i - 1]), '取文本长度': len,
            '左移': lambda value, bits: ((value << bits) + 2 ** 31) % 2 ** 32 - 2 ** 31, '位与': lambda a, b: a & b,
            '到文本': lambda value: value.decode('latin-1') if isinstance(value, bytes) else str(value),   # bytes kept as they are, as in EPL
            '机架引擎_记日志': lambda text: self.logs.append(text),
            '取字节集左边': lambda data, n: data[:n],
            '取字节集中间': lambda data, s, n: data[s - 1:s - 1 + n],
            '寻找文本': lambda text, sub, *a: text.find(sub) + 1 if text.find(sub) >= 0 else -1,
            '子文本替换W': jy_replace, '删除Unicode结尾空白字节': jy_trim_end,
            'un_连接': lambda *args: (lambda s: W(s) if s else b'')(''.join(jy_trim_end(x).decode('utf-16-le') for x in args if isinstance(x, bytes))),
            '_取指针字节集': lambda b: Ptr(bytes(b)), '取字节集长度_ASM': len, 'lstrlenW': lambda p: len(p.wstr()),
            'StrStrW': str_str_w, 'StrStrIW': lambda p, q: str_str_w(p, q, True),
            'StrRStrI': str_rstr_iw, 'StrRStr': lambda a, b, c: str_rstr_iw(a, b, c, False),
            '相除': lambda a, b: a // b if a % b == 0 else a / b,
            '文本_删首尾空W': lambda data: W(data.decode('utf-16-le').rstrip('\0').strip()),
            '文本_取右边W': lambda data, sep, *a: W(data.decode('utf-16-le').rstrip('\0').split(sep.decode('utf-16-le').rstrip('\0'), 1)[1]),
            '文本_替换W': lambda data, old, new, *a: W(data.decode('utf-16-le').rstrip('\0').replace(old.decode('utf-16-le').rstrip('\0'), new.decode('utf-16-le').rstrip('\0'))),
            '窗口_取句柄': lambda parent, child, cls, *a: self.next_window.get(child, 0),
            '窗口_取标题W': lambda handle: W(self.titles.get(handle, '')),
            '窗口_句柄取进程ID': lambda handle, *a: self.pids.get(handle, 0),
        })

    @staticmethod
    def path(data):
        return data.decode('utf-16-le').split('\0')[0]       # as Windows reads it: up to the first U+0000

    def add(self, path, content, mtime, identity=(1, 2, 3)):
        self.files[path] = {'content': content, 'mtime': mtime, 'identity': identity, 'virtual': None}

    def size(self, path):
        f = self.files[path]
        return f['virtual'] if f['virtual'] is not None else len(f['content'])

    def execute(self, nodes, env):
        for node in nodes:
            if node[0] == 'repeat':
                for counter in range(1, self.evaluate(node[1], env) + 1):
                    env[node[2]] = counter
                    try:
                        self.execute(node[3], env)
                    except NextIteration:
                        continue
                    except syntax.Broke:
                        break
            else:
                super().execute([node], env)

    def evaluate(self, value, env):
        call = re.fullmatch(r'([^ ()]+)\s*\((.*)\)', value.strip())
        if call:
            name, raw = call.groups()
            args = syntax.split_args(raw) if raw.strip() else []
            values = lambda: [self.evaluate(arg, env) for arg in args]
            if name.startswith(('全民K歌', 'QQ音乐_', '播放器_')):
                return self.invoke(name, *values())
            if name in JY_REAL:   # the real 精易 source; an omitted 可空 argument stays None, so 是否为空 sees it
                return self.invoke(name, *values())
            if name == '系统_取所有磁盘盘符':
                self.assign(args[0].strip(), sorted(self.drives), env)
                return len(self.drives)
            if name == '加入成员':   # into the local array, or the 程序集变量 when it is one
                target = args[0].strip(); scope = env if target in env or target not in self.env else self.env
                current = scope.get(target)
                scope[target] = (current if isinstance(current, list) else []) + [self.evaluate(args[1], env)]
                return None
            if name == '文件_枚举W':
                folder, pattern = self.path(self.evaluate(args[0], env)), self.path(self.evaluate(args[1], env))
                self.enumerated.append(folder)
                regex = re.compile(re.escape(pattern).replace('\\*', '.*') + '$', re.I)
                found = [W(p) for p in self.files if p.rsplit('\\', 1)[0] + '\\' == folder and regex.match(p.rsplit('\\', 1)[1])]
                self.assign(args[2].strip(), found, env)
                return len(found)
            if name == '进程_枚举':   # one system snapshot: every process name and ID
                self.name_lookups.append(self.now)
                table = {**self.names, **({4242: 'WeSing.exe'} if self.present else {})}
                self.assign(args[0].strip(), list(table.values()), env); self.assign(args[1].strip(), list(table.keys()), env)
                return len(table)
            if name == '清除数组':
                self.assign(args[0].strip(), [], env)
                return None
            if name == '进程_取同名ID':
                self.name_lookups.append(self.evaluate(args[0], env))
                found = [pid for pid, exe in self.names.items() if exe.lower() == self.evaluate(args[0], env).lower()]
                self.assign(args[1].strip(), found, env)
                return len(found)
            if name == '网页_访问_对象':
                given = values()
                self.requests.append({'url': given[0], 'method': given[1], 'headers': given[5]})
                self.assign(args[7].strip(), self.status, env)
                return self.reply
            if name.endswith('.取所有属性名'):   # names come back through the 参考 array
                names = self.resolve(name.rsplit('.', 1)[0], env).取所有属性名(self.evaluate(args[0], env))
                self.assign(args[1].strip(), names, env)
                return len(names)
            if name == '窗口_枚举子窗口':
                self.assign(args[1].strip(), list(self.windows), env)
                return len(self.windows)
            if name == '分割文本W':
                data, sep = self.evaluate(args[0], env), self.evaluate(args[1], env)
                parts = data.decode('utf-16-le').rstrip('\0').split(sep.decode('utf-16-le').rstrip('\0'))
                self.assign(args[2].strip(), [W(x) for x in parts], env)
                return len(parts)
            if name == 'CreateFileW':
                path = self.path(self.evaluate(args[0], env)); self.opened.append(path)
                if self.fail == 'open' or path not in self.files:
                    return -1
                handle = 70 + len(self.opened); self.handles[handle] = [path, 0]
                return handle
            if name == 'GetFileInformationByHandle_字节集':
                path = self.handles[self.evaluate(args[0], env)][0]; identity = self.files[path]['identity']
                info = bytearray(52)
                struct.pack_into('<Q', info, 4, identity[0]); struct.pack_into('<I', info, 28, identity[1]); struct.pack_into('<II', info, 44, 0, identity[2])
                self.assign(args[1].strip(), bytes(info), env)
                return self.fail != 'info'
            if name == 'GetFileSizeEx_逻辑型':
                self.assign(args[1].strip(), self.size(self.handles[self.evaluate(args[0], env)][0]), env)
                return self.fail != 'size'
            if name == 'SetFilePointerEx_整数型':
                handle = self.evaluate(args[0], env); self.handles[handle][1] = self.evaluate(args[1], env)
                return self.fail != 'seek'
            if name == 'ReadFile_整数型':
                handle = self.evaluate(args[0], env); path, position = self.handles[handle]
                length = self.evaluate(args[2], env)
                assert 0 < length <= 65536, length
                self.reads.append((position, length))
                content = self.files[path]['content']; begin = position - (self.size(path) - len(content))
                data = (b'x' * (-begin) + content)[:length] if begin < 0 else content[begin:begin + length]
                if self.fail == 'shortread':
                    data = data[:len(data) // 2]
                pointer = syntax.split_args(args[1][args[1].index('(') + 1:args[1].rindex(')')])[0]
                self.assign(pointer.strip(), data, env)
                self.assign(args[3].strip(), len(data), env)
                return self.fail != 'read'
            if name == 'CloseHandle':
                self.closed.append(self.evaluate(args[0], env))
                return True
        indexed = re.fullmatch(r'([^\[\]]+)\[(.+)\]', value.strip())
        if indexed:
            return self.resolve(indexed[1], env)[self.evaluate(indexed[2], env) - 1]
        return super().evaluate(value, env)

    def tick(self):
        before_open, before_close = len(self.opened), len(self.closed)
        result = self.invoke('全民K歌_查询_正在播放的音乐')
        opened = [h for h in range(71 + before_open, 71 + len(self.opened)) if h in self.handles]
        assert sorted(self.closed[before_close:]) == sorted(opened), 'every successful open must close exactly once'
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--module', type=Path, default=Path(__file__).resolve().parents[4] / '模块/模块_电音助手.e~')
    parser.add_argument('--out', type=Path)
    opts = parser.parse_args()
    source = (opts.module / '代码/程序集_播放器和基调查询.static.e.txt').read_text('utf-8-sig')
    tests = []

    def check(name, passed):
        tests.append({'name': name, 'passed': bool(passed)})
        assert passed, name

    # ---- registration: sixth player, its own icon resource, the reader function ---------------------------
    init = syntax.section(source, '播放器查询信息_初始化')
    # icon order in the window = registration order: 全民K歌 fifth, 直播伴侣 sixth (each with its own icon and query)
    blocks = re.findall(r'名, “([^”]+)”\)\n赋值 \(局_播放器查询信息\.图标, #列表框_图标_([^)]+)\)\n赋值 \(局_播放器查询信息\.子程序指针_查询_正在播放的音乐, 到整数 \(&([^)]+)\)\)', init.replace('\r', ''))
    # 汽水音乐 sits just before 酷我音乐; 全民K歌 stays just before 直播伴侣 (the icons swapped on request)
    named = {b[0]: b for b in blocks}
    check('icon_order_wesing_just_before_companion', [b[0] for b in blocks] == ['酷狗音乐', 'QQ音乐', '网易云音乐', '汽水音乐', '酷我音乐', '全民K歌', '直播伴侣']
          and named['全民K歌'] == ('全民K歌', '全民K歌', '全民K歌_查询_正在播放的音乐') and named['直播伴侣'] == ('直播伴侣', '直播伴侣', '酷狗或聚星直播伴侣_查询_正在播放的音乐'))
    check('registered_as_a_player_with_its_icon', '赋值 (局_播放器查询信息.名, “全民K歌”)' in init and '#列表框_图标_全民K歌' in init
          and '&全民K歌_查询_正在播放的音乐' in init)
    desc = json.loads((opts.module / '资源/资源.desc.json').read_text('utf-8-sig'))
    icon = (opts.module / '资源/列表框_图标_全民K歌.Image.dat').read_bytes()
    check('icon_resource_registered_32px_png', any(r['Name'] == '列表框_图标_全民K歌' for r in desc['Resources'])
          and icon[:8] == b'\x89PNG\r\n\x1a\n' and struct.unpack('>II', icon[16:24]) == (32, 32))

    # ---- the reader uses the 精易模块 Unicode text commands, not its own byte scanning -------------------------
    reader = '\n'.join(syntax.section(source, n) for n in re.findall(r'^\.子程序 (全民K歌[^,\n]*)', source, re.M))
    check('reader_uses_jingyi_text_commands', all(c + ' (' in reader for c in ('寻找文本W', '倒找文本W', '取文本中间W', '子文本替换W', 'un_连接', '系统_取所有磁盘盘符'))
          and not re.search(r'寻找字节集|倒找字节集|子字节集替换|求余数 \(局_位置', reader))
    probe = Machine(source)
    middle = probe.invoke('文本_取出中间文本W', W('12345'), W('2'), W('4'))
    off_by_two = middle.decode('utf-16-le').rstrip('\0') != '3'
    calls = '\n'.join(l for l in reader.splitlines() if not l.lstrip().startswith(("'", '.')))   # code lines, not declarations or comments
    check('jingyi_take_middle_fixed_and_used_for_values', not off_by_two and '文本_取出中间文本W (' in calls and '全民K歌日志_取值W' not in reader)
    check('song_and_singer_taken_at_the_right_place', probe.invoke('全民K歌_歌名', start('无人与我', '黄静美').split(b'\n\0')[0], '') == '黄静美 - 无人与我')

    # ---- the reader -----------------------------------------------------------------------------------------
    m = Machine(source)
    m.add(DIR_APP + 'WeSing(221.176)20261101090000.log', filler(5) + start('旧歌', '旧歌手') + filler(3), mtime=100, identity=(1, 1, 1))
    m.add(DIR_E + 'WeSing(221.176)20261106123227.log', filler(20) + start('孤勇者', '陈奕迅') + filler(10) + start('有点甜', '汪苏泷/BY2')
          + filler(10) + start('无人与我', '黄静美') + filler(30), mtime=200, identity=(2, 2, 2))
    m.add(DIR_E + 'Other.log', start('不是日志', '不是'), mtime=999)
    check('newest_log_and_last_start_wins', m.tick() == '黄静美 - 无人与我')
    check('scans_appdata_and_fixed_drives_only', m.enumerated[:3] == [DIR_APP, 'C:\\WeSingCache\\Log\\WeSing\\', DIR_E]
          and not any(d.startswith(('D:', 'F:')) for d in m.enumerated))
    check('unicode_appdata_path_and_share_read_write_delete', DIR_APP in [d for d in m.enumerated])
    scans = len(m.enumerated)
    m.files[DIR_APP + 'WeSing(221.176)20261101090000.log']['mtime'] = 300
    m.now += 1000
    check('no_rescan_within_three_seconds', m.tick() == '黄静美 - 无人与我' and len(m.enumerated) == scans)
    m.now += 2000
    check('rescan_after_three_seconds_switches_to_the_newer_log', m.tick() == '旧歌手 - 旧歌' and len(m.enumerated) > scans)

    # a start far from the end (more than 64 KiB of later lines) is still found by the backward scan
    m = Machine(source)
    big = filler(50) + start('无人与我', '黄静美') + filler(4000)
    m.add(DIR_E + 'WeSing(1)1.log', big, mtime=1)
    result = m.tick()
    check('start_beyond_64KiB_found_by_backward_scan', result == '黄静美 - 无人与我' and len(m.reads) > 1 and len(big) - big.rfind(b'S\0t\0a\0r\0t\0K') > 65536)
    check('every_read_at_most_64KiB_and_at_character_boundaries', all(length <= 65536 and position % 2 == 0 for position, length in m.reads))

    # incremental: only the newly written part is read; a half-written line waits until it is complete
    reads = len(m.reads); size = len(big)
    m.files[DIR_E + 'WeSing(1)1.log']['content'] = big + filler(5)
    check('unchanged_song_on_new_lines', m.tick() == '黄静美 - 无人与我' and all(p >= size for p, _ in m.reads[reads:]))
    # one line still being written: its song and singer are already there, only the end and the newline are not
    first = start('新歌', '新歌手').split(b'\n\0')[0] + b'\n\0'
    assert '新歌手'.encode('utf-16-le') in first[:-40] and not first[:-40].endswith(b'\n\0')
    m.files[DIR_E + 'WeSing(1)1.log']['content'] += first[:-40]
    check('half_written_line_is_not_read', m.tick() == '黄静美 - 无人与我')
    m.files[DIR_E + 'WeSing(1)1.log']['content'] += first[-40:]
    check('completed_line_updates_the_song', m.tick() == '新歌手 - 新歌')

    # the very first read ends in a half-written start line: the earlier complete start is used
    m = Machine(source)
    first = start('新歌', '新歌手').split(b'\n\0')[0] + b'\n\0'
    m.add(DIR_E + 'WeSing(1)1.log', start('无人与我', '黄静美') + filler(3) + first[:-40], mtime=1)
    check('half_written_line_at_the_first_read_is_not_read', m.tick() == '黄静美 - 无人与我')
    # the engine was stopped for a while (window closed) and the log kept growing: rescan from the tail at once
    m = Machine(source)
    m.add(DIR_E + 'WeSing(1)1.log', cookie_line() + start('关窗前的歌', '甲'), mtime=1)
    m.tick()
    m.files[DIR_E + 'WeSing(1)1.log']['content'] += filler(1000000 // 140) + start('现在这首', '乙')
    reads = len(m.reads)
    check('long_gap_rescanned_from_the_tail_not_replayed', m.tick() == '乙 - 现在这首' and m.reads[reads][0] > 1000000)
    check('long_gap_keeps_the_known_cookie', m.env['集_K歌日志_Cookie'] == FAKE_COOKIE)
    # the login line is more than 4 MiB back: the backward search cannot see it, the known cookie stays
    size = m.size(DIR_E + 'WeSing(1)1.log')
    m.files[DIR_E + 'WeSing(1)1.log']['content'] = start('又一首', '丁'); m.files[DIR_E + 'WeSing(1)1.log']['virtual'] = size + 5 * 1024 * 1024
    check('login_line_beyond_the_search_keeps_the_known_cookie', m.tick() == '丁 - 又一首' and m.env['集_K歌日志_Cookie'] == FAKE_COOKIE)
    # a passing failure (the log could not be opened once) is not a new log: the cookie that only the earlier read saw stays
    m.fail = 'open'; m.tick(); m.fail = ''
    check('passing_failure_keeps_the_cookie_beyond_the_search', m.tick() == '丁 - 又一首' and m.env['集_K歌日志_Cookie'] == FAKE_COOKIE)
    m.files[DIR_E + 'WeSing(1)1.log']['content'] = cookie_line() + start('现在这首', '乙'); m.files[DIR_E + 'WeSing(1)1.log']['virtual'] = None
    m.env['集_K歌日志_已读'] = 0; m.tick()
    m.files[DIR_E + 'WeSing(1)1.log']['content'] += filler(100)
    small = len(m.reads)
    check('short_growth_still_read_incrementally', m.tick() == '乙 - 现在这首' and len(m.reads) == small + 1)
    m.files[DIR_E + 'WeSing(1)1.log'] = {'content': start('新会话', '丙'), 'mtime': 2, 'identity': (9, 9, 9), 'virtual': None}
    check('new_log_drops_the_old_cookie', m.tick() == '丙 - 新会话' and m.env['集_K歌日志_Cookie'] == '')

    # a misaligned byte match (ordinary CJK characters forming the pattern at an odd offset) is ignored
    m = Machine(source)
    m.add(DIR_E + 'WeSing(1)1.log', start('无人与我', '黄静美') + misaligned_marker() + filler(2), mtime=1)
    check('misaligned_pattern_is_ignored', m.tick() == '黄静美 - 无人与我')

    # JSON escapes in names
    m = Machine(source)
    m.add(DIR_E + 'WeSing(1)1.log', start('A "B" C/D', '歌\\手'), mtime=1)
    check('json_escapes_restored', m.tick() == '歌\\手 - A "B" C/D')

    # rotation, truncation, exit, no logs, failures, very long lines, 64-bit offsets
    m = Machine(source)
    m.add(DIR_E + 'WeSing(1)1.log', start('无人与我', '黄静美'), mtime=1, identity=(5, 5, 5))
    m.tick()
    m.files[DIR_E + 'WeSing(1)1.log'] = {'content': filler(3), 'mtime': 2, 'identity': (6, 6, 6), 'virtual': None}
    check('rotated_log_rescanned_from_its_tail', m.tick() == '')
    m.files[DIR_E + 'WeSing(1)1.log']['content'] = start('A', 'B') + filler(50)
    m.tick()
    m.files[DIR_E + 'WeSing(1)1.log']['content'] = filler(2)
    check('shorter_log_rescanned', m.tick() == '')
    m.files[DIR_E + 'WeSing(1)1.log']['content'] = start('无人与我', '黄静美')
    m.tick()
    m.present = False; m.now += 2000          # the shared process list is refreshed every 2 s
    check('wesing_exit_clears_everything', m.tick() == '' and m.env['集_K歌日志_文件W'] == b'' and m.env['集_K歌日志_开唱行'] == b'')
    m.present = True; m.now += 2000
    m.add(DIR_E + 'WeSing(1)2.log', filler(3), mtime=50, identity=(7, 7, 7))
    check('new_session_log_without_a_start_shows_nothing', m.tick() == '')
    m = Machine(source)
    check('no_log_shows_nothing', m.tick() == '')
    for _ in range(9):
        m.tick(); m.now += 100
    check('no_log_scans_only_every_3_seconds', len(m.enumerated) == 3)
    m.add(DIR_E + 'WeSing(1)1.log', start('无人与我', '黄静美'), mtime=1)
    m.now += 2100
    check('log_found_at_the_next_scan', m.tick() == '黄静美 - 无人与我' and len(m.enumerated) == 6)
    m.present = False; m.now += 2000; m.tick(); m.present = True; m.now += 2000
    scans = len(m.enumerated)
    check('started_again_scans_at_once', m.tick() == '黄静美 - 无人与我' and len(m.enumerated) == scans + 3)
    for fail in ('open', 'info', 'size', 'seek', 'read', 'shortread'):
        m = Machine(source)
        m.add(DIR_E + 'WeSing(1)1.log', start('无人与我', '黄静美'), mtime=1)
        m.tick()
        m.fail = fail
        m.files[DIR_E + 'WeSing(1)1.log']['content'] += start('新歌', '新歌手')
        check('failure_returns_nothing_and_closes:' + fail, m.tick() == '' and m.env['集_K歌日志_开唱行'] == b'')
    # a log that keeps failing to open: one cheap open attempt per round, the directories still scanned only every 3 s
    m = Machine(source)
    m.add(DIR_E + 'WeSing(1)1.log', cookie_line() + start('无人与我', '黄静美'), mtime=1)
    m.tick(); m.fail = 'open'; scans = len(m.enumerated)
    for _ in range(10):
        m.tick(); m.now += 100
    check('persistent_open_failure_keeps_the_3s_scan_throttle', (len(m.enumerated) - scans) <= 3 and m.env['集_K歌日志_文件W'] != b'')
    m.fail = ''
    check('recovers_from_the_tail_after_the_failure', m.tick() == '黄静美 - 无人与我' and m.env['集_K歌日志_Cookie'] == FAKE_COOKIE)
    m = Machine(source)
    long_line = ('[I]\t' + '长' * 200000).encode('utf-16-le')
    m.add(DIR_E + 'WeSing(1)1.log', start('无人与我', '黄静美') + long_line + b'\n\0' + long_line, mtime=1)
    check('very_long_lines_neither_loop_nor_hide_the_song', m.tick() == '黄静美 - 无人与我' and sum(n for _, n in m.reads) <= 4194304 + 65536)
    m = Machine(source)
    tail = start('无人与我', '黄静美') + filler(3)
    m.add(DIR_E + 'WeSing(1)1.log', tail, mtime=1)
    m.files[DIR_E + 'WeSing(1)1.log']['virtual'] = 2 ** 33 + len(tail)
    check('offsets_above_4GiB', m.tick() == '黄静美 - 无人与我' and m.reads[0][0] > 2 ** 32)

    # ---- only a song name in the log: not shown until the monitor thread has looked up the singer ---------------
    subs = {n: syntax.section(source, n) for n in re.findall(r'^\.子程序 (全民K歌[^,\n]*)', source, re.M)}
    engine = (opts.module / '代码/程序集_机架联动引擎.static.e.txt').read_text('utf-8-sig')
    callers = [n for n in re.findall(r'^\.子程序 ([^,\n]+)', engine, re.M) if '全民K歌_补歌手 ()' in syntax.section(engine, n)]
    check('only_the_monitor_thread_goes_online', [n for n, s in subs.items() if '网页_访问_对象 (' in s] == ['全民K歌_补歌手']
          and not any('全民K歌_补歌手 (' in s for n, s in subs.items() if n != '全民K歌_补歌手') and callers == ['机架引擎_线程_监测'])
    loop = [l.strip() for l in syntax.section(engine, '机架引擎_线程_监测').splitlines() if l.strip() and not l.strip().startswith("'")]
    hook = next(i for i, l in enumerate(loop) if l.startswith('.如果真 (全民K歌_补歌手 ())'))
    check('lookup_after_edits_before_key_query_then_next_round', loop[hook + 1] == '到循环尾 ()'
          and loop.index('.如果真 (机架引擎_处理编辑 ())') < hook < loop.index('.如果真 (取反 (局_查询))'))
    m = Machine(source)
    log = DIR_E + 'WeSing(1)1.log'
    m.add(log, cookie_line('ver=1; openid=OLD; openkey=OLDKEY') + start_without_singer('爱丫爱丫', '003ioXz03eSg7N') + cookie_line(cr=True) + filler(2), mtime=1)
    check('song_without_singer_is_not_shown', m.tick() == '')
    check('lookup_registered_with_the_latest_cookie_without_cr', m.env['集_K歌_待查MID'] == '003ioXz03eSg7N' and m.env['集_K歌_待查Cookie'] == FAKE_COOKIE)
    check('detection_never_touches_the_network', m.requests == [])
    m.reply = song_info_reply()
    check('monitor_thread_looks_it_up', m.invoke('全民K歌_补歌手') is True and len(m.requests) == 1)
    url = 'http://cgi.kg.qq.com/fcgi-bin/fcg_ksonginfo_get?g_tk_openkey=%d&g_tk=%d&strKSongMid=003ioXz03eSg7N&mapContent=CONTENT_LRC:0,CONTENT_NOTE:0,CONTENT_QRC:0,CONTENT_ROMA:0&outCharset=utf-8&format=json' % (g_tk('FAKE/KEY+1='), g_tk('FAKE/KEY+1='))
    check('request_url_g_tk_and_cookie_header', m.requests[0]['url'] == url and m.requests[0]['method'] == 0 and m.requests[0]['headers'].endswith('\r\nCookie: ' + FAKE_COOKIE))
    check('singer_from_the_lyric_ar_tag_then_shown', m.tick() == 'BY2 - 爱丫爱丫' and m.env['集_K歌_待查MID'] == '')
    check('cache_used_without_another_request', m.tick() == 'BY2 - 爱丫爱丫' and len(m.requests) == 1 and m.invoke('全民K歌_补歌手') is False)
    check('lock_entered_and_left_in_pairs', m.lock.count('进入') == m.lock.count('退出') > 0)
    check('cookie_and_openkey_never_logged', not any('FAKE' in x or 'openkey' in x for x in m.logs))
    # a song that also has the singer in the log is shown at once, nothing looked up
    m.files[log]['content'] += start('这世界那么多人', '莫文蔚')
    check('song_with_singer_shown_without_lookup', m.tick() == '莫文蔚 - 这世界那么多人' and m.env['集_K歌_待查MID'] == '' and len(m.requests) == 1)
    # failure: not shown, no new lookup for 60 s, then tried again
    m = Machine(source)
    m.add(log, cookie_line() + start_without_singer('甲', 'MID1'), mtime=1)
    m.tick(); m.status = 500
    m.invoke('全民K歌_补歌手')
    check('failed_lookup_not_shown_and_logged', m.tick() == '' and any('HTTP 500' in x for x in m.logs))
    check('no_retry_within_60_seconds', m.env['集_K歌_待查MID'] == '')
    m.now += 60000
    check('retried_after_60_seconds', m.tick() == '' and m.env['集_K歌_待查MID'] == 'MID1')
    # while a lookup is in flight the same MID is not registered again
    m.env['集_K歌_待查MID'] = ''; m.env['集_K歌_查询中MID'] = 'MID1'
    check('in_flight_mid_not_registered_again', m.tick() == '' and m.env['集_K歌_待查MID'] == '')
    # no cookie in the log: nothing sent, logged without secrets, not shown
    m = Machine(source)
    m.add(log, start_without_singer('乙', 'MID2'), mtime=1)
    m.tick(); m.invoke('全民K歌_补歌手')
    check('no_cookie_no_request', m.requests == [] and any('找不到登录信息' in x for x in m.logs) and m.tick() == '')
    # a MID that is not plain letters and digits never reaches the URL
    m = Machine(source)
    m.add(log, cookie_line() + start_without_singer('丙', 'X&g_tk=1'), mtime=1)
    check('unsafe_mid_never_registered', m.tick() == '' and m.env['集_K歌_待查MID'] == '')
    # the singer cache keeps at most 64 songs (程序集变量 arrays are emptied, then the new one is kept)
    m = Machine(source)
    m.env['集_K歌_歌手MID'] = ['M%d' % i for i in range(64)]; m.env['集_K歌_歌手名W'] = [W('S')] * 64
    m.env['集_K歌_待查MID'] = 'NEW'; m.env['集_K歌_待查Cookie'] = FAKE_COOKIE; m.reply = song_info_reply()
    m.invoke('全民K歌_补歌手')
    check('cache_bounded_to_64', m.env['集_K歌_歌手MID'] == ['NEW'] and len(m.env['集_K歌_歌手名W']) == 1)
    parse = syntax.section(source, '全民K歌_解析歌手')
    check('reply_parsed_with_zyjson_not_by_scanning_text', '局_JSON.解析UTF8 (到文本 (参_回复)' in parse and '“data.mapContent.unknown.strContent”' in parse
          and '寻找文本W' not in parse and '\\/' not in parse and '全民K歌_找歌手' not in source)
    check('zyjson_text_taken_unescaped', all(c.endswith(', 真, 真)') for c in re.findall(r'局_JSON\.取文本 \((?:[^()]|\([^()]*\))*\)', parse)) and parse.count('局_JSON.取文本 (') == 2)
    # the start line itself is JSON too: zyJson, wide text, value checked, escapes restored by the parser
    name_part = syntax.section(source, '全民K歌_歌名')
    check('start_line_parsed_with_zyjson', '局_JSON.解析W (' in name_part and '“cmd.subcmd.value”' in name_part
          and all('“cmd.subcmd.data.%s”' % k in name_part for k in ('songname', 'singername', 'mid'))
          and '{1, 0, 0, 0}' not in source and '{2, 0, 0, 0}' not in source and '全民K歌_还原转义' not in source)
    check('start_line_text_taken_unescaped', all(c.endswith(', 真, 真)') for c in re.findall(r'局_JSON\.取文本W \((?:[^()]|\((?:[^()]|\([^()]*\))*\))*\)', name_part))
          and name_part.count('局_JSON.取文本W (') == 4)
    one = lambda raw: Machine(source).invoke('全民K歌_歌名', raw.split(b'\n\0')[0], '')
    check('unicode_outside_gbk_kept', one(start('사랑해 😀', 'アーティスト')) == 'アーティスト - 사랑해 😀')
    cmd = json.dumps({'cmd': {'value': '1074', 'subcmd': {'value': 'StartKSong', 'data': {'mid': '1', 'songname': '爱丫爱丫', 'singername': 'BY2'}}}})
    check('unicode_escapes_in_the_log_restored', '\\u7231' in cmd and one(line('[WebContent] :' + cmd)) == 'BY2 - 爱丫爱丫')
    bracket = start('无人与我', '黄静美').split(b'\n\0')[4]
    check('bracketed_json_line_with_cr', bracket.decode('utf-16-le').endswith('}]') and one(bracket[:-2] + ']\r'.encode('utf-16-le')) == '黄静美 - 无人与我')
    check('broken_json_not_shown', one(line('[WebContent] :{"cmd":{"value":"1074","subcmd":{"value":"StartKSong","data":{"songname":"甲"')) == '')
    check('other_command_not_shown', one(line('[WebContent] :{"cmd":{"subcmd":{"value":"Other","data":{"songname":"甲","singername":"乙"}},"x":"\\"value\\":\\"StartKSong\\""}}')) == '')
    # reply parsing: XML entities restored once, other strContent tried when there is no unknown entry
    probe = Machine(source)
    one = lambda reply: probe.invoke('全民K歌_解析歌手', reply).decode('utf-16-le').rstrip('\0')
    check('xml_entities_restored_once', one(song_info_reply(singer='A&amp;B &amp;lt;C&gt;')) == 'A&B &lt;C>')
    check('other_strcontent_tried_without_unknown', one(song_info_reply(with_unknown=False)) == 'BY2')
    check('reply_without_singer_gives_nothing', one(song_info_reply(singer='')) == '' and one(b'{"code":-1}') == '')

    # one shared process snapshot every 2 s instead of a full system snapshot per player per 100 ms round
    m = Machine(source)
    m.add(DIR_E + 'WeSing(1)1.log', start('无人与我', '黄静美'), mtime=1)
    for _ in range(10):
        m.tick(); m.now += 100
    check('process_snapshot_shared_and_throttled', len(m.name_lookups) == 1 and m.invoke('播放器_进程存在', 'wesing.EXE') is True)
    m.present = False; m.now += 900
    check('exit_not_seen_before_two_seconds', m.tick() == '黄静美 - 无人与我' and len(m.name_lookups) == 1)
    m.now += 100
    check('exit_seen_after_the_next_refresh', m.tick() == '' and len(m.name_lookups) == 2)
    plain = '\n'.join(syntax.section(source, n) for n in re.findall(r'^\.子程序 ([^,\n]+)', source, re.M))
    check('no_per_round_system_snapshot_left', not re.search(r'进程_是否存在 \(|进程_取同名ID \(|进程_ID取进程名 \(', plain) and plain.count('进程_枚举 (') == 1)

    # ---- QQ音乐 shares the window class TXGuiFoundation with 全民K歌: only QQMusic.exe windows count ----------
    q = Machine(source)
    q.windows = [10, 20]
    q.next_window = {10: 11, 20: 21}                     # FindWindowEx: the title read is from the *next* window
    q.titles = {11: '全民K歌 - 首页', 21: '晴天 - 周杰伦', 10: '晴天 - 周杰伦'}
    q.pids = {11: 500, 21: 600, 10: 600}
    q.names = {500: 'WeSing.exe', 600: 'QQMusic.exe'}
    check('qqmusic_song_read_past_a_wesing_window', q.invoke('QQ音乐_查询_正在播放的音乐') == '周杰伦 - 晴天')
    q.invoke('QQ音乐_查询_正在播放的音乐'); q.now += 1000; q.invoke('QQ音乐_查询_正在播放的音乐')
    check('one_snapshot_per_two_seconds_however_many_windows', len(q.name_lookups) == 1)
    q.now += 1000
    check('process_list_refreshed_after_two_seconds', q.invoke('QQ音乐_查询_正在播放的音乐') == '周杰伦 - 晴天' and len(q.name_lookups) == 2)
    q = Machine(source)
    q.windows = [10]; q.next_window = {10: 11}; q.titles = {11: '全民K歌 - 首页'}; q.pids = {11: 500}; q.names = {500: 'WeSing.exe'}
    check('wesing_window_never_taken_for_qqmusic', q.invoke('QQ音乐_查询_正在播放的音乐') == '')
    q = Machine(source)
    q.windows = [10]; q.next_window = {10: 11}; q.titles = {11: '晴天 - 周杰伦'}; q.pids = {10: 600, 11: 500}; q.names = {500: 'WeSing.exe', 600: 'QQMusic.exe'}
    check('process_checked_on_the_window_whose_title_is_read', q.invoke('QQ音乐_查询_正在播放的音乐') == '')

    result = {'checks': len(tests), 'passed': sum(t['passed'] for t in tests), 'tests': tests,
              'scope': 'real source-extracted EPL with file/window/Win32 substitutes; not EPL compile, Windows I/O or real WeSing/QQ音乐'}
    if opts.out:
        opts.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
