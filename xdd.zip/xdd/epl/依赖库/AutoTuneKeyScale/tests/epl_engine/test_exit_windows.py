#!/usr/bin/env python3
"""Execute the real 退出_隐藏本进程窗口 / 退出_隐藏窗口_枚举回调 of the main window: when the program exits, every visible
top-level window of the software disappears at once instead of staying on screen through the slow cleanup.

Not an EPL compiler and not a Windows run: epl_machine runs the real source over a list of top-level windows.
Hidden at exit: visible windows of this process, of the sound child process, and windows owned by a window of this
process (the recorder and MIDI windows live in the child process and are owned by the main window). Left alone:
invisible windows and every other program's windows. The callback only reads the process id, the owner and the
visibility (none of which sends a message), hides with ShowWindowAsync (posted, never waited for, so a window of a
stuck thread or another process cannot hang the exit) and always returns true so the enumeration covers every window.
"""
from pathlib import Path
import json
import re
import epl_machine as em

HERE = Path(__file__).resolve().parent
MAIN = HERE.parents[3] / '代码/窗_主程序/窗口程序集_主窗口.form.e.txt'
OWN, CHILD = 1000, 4321
WINDOWS = [   # handle, process, owner, visible
    (1, OWN, 0, True),       # main-process window still open (audio clipper, a settings window …)
    (2, OWN, 0, False),      # already hidden
    (3, CHILD, 0, True),     # a window of the sound child process
    (4, 777, 1, True),       # another process's window owned by one of ours (recorder / MIDI window)
    (5, 555, 0, True),       # another program
    (6, 556, 5, True),       # another program's owned window
    (7, OWN, 5, True),       # ours, owned by a foreign window
]


class Exit(em.Machine):
    def __init__(self, child=CHILD):
        super().__init__()
        self.load_static(MAIN.read_text('utf-8-sig'), names={'退出_隐藏本进程窗口', '退出_隐藏窗口_枚举回调'})
        self.global_types['全_子进程_音效_ID'] = ('整数型', False)
        self.globals['全_子进程_音效_ID'] = child
        self.hidden, self.visited, self.calls = [], [], []
        info = {h: (p, o, v) for h, p, o, v in WINDOWS}
        self.builtins.update({
            '进程_取自进程ID': lambda: OWN,
            'IsWindowVisible': lambda h: self.note('IsWindowVisible') or info[h][2],
            '_窗口是否可见': lambda h: self.note('IsWindowVisible') or info[h][2],   # 精易模块 DLL.e.txt 里 IsWindowVisible 的别名（主工程现在按这个名字调用，见那里的说明）
            'GetWindow': lambda h, kind: self.note('GetWindow') or (info[h][1] if kind == 4 else 0),
            'ShowWindowAsync': lambda h, show: self.note('ShowWindowAsync') or self.hidden.append((h, show)) or True})
        self.raw_builtins.update({'EnumWindows': self.enum, 'GetWindowThreadProcessId': self.pid})
        self.info = info

    def note(self, name):
        self.calls.append(name)

    def pid(self, env, args, raws):
        self.note('GetWindowThreadProcessId')
        self.store(raws[1].strip(), self.info[self.ev(args[0], env)][0], env)
        return 1

    def enum(self, env, args, raws):
        name = re.fullmatch(r'&(.+)', raws[0].strip()).group(1)
        lparam = self.ev(args[1], env)
        for h, *_ in WINDOWS:
            self.visited.append(h)
            if not self.invoke(self.subs[name], [('lit', h), ('lit', lparam)], {}, None):
                break
        return True


def main():
    checks = []

    def check(name, passed):
        checks.append(name)
        assert passed, name

    m = Exit()
    m.invoke(m.subs['退出_隐藏本进程窗口'], [], {}, None)
    check('ours_the_child_process_and_owned_windows_hidden', m.hidden == [(1, False), (3, False), (4, False), (7, False)])
    check('every_window_visited', m.visited == [h for h, *_ in WINDOWS])
    check('only_message_free_calls', set(m.calls) <= {'IsWindowVisible', 'GetWindowThreadProcessId', 'GetWindow', 'ShowWindowAsync'})
    m = Exit(child=0)                                      # no sound child process: its rule must not catch anything
    m.invoke(m.subs['退出_隐藏本进程窗口'], [], {}, None)
    check('no_child_process_means_no_child_rule', m.hidden == [(1, False), (4, False), (7, False)])

    text = MAIN.read_text('utf-8-sig').replace('\r\n', '\n')
    code = lambda name: '\n'.join(re.sub(r"\s'.*$", '', l) for l in re.search(r'^\.子程序 ' + name + r',[^\n]*\n(.*?)(?=^\.子程序 |\Z)', text, re.M | re.S).group(1).split('\n')
                                  if l.strip() and not l.lstrip().startswith(("'", '.局部变量', '.参数')))      # code only: inline comments dropped
    both = code('退出_隐藏本进程窗口') + code('退出_隐藏窗口_枚举回调')
    check('nothing_that_sends_a_message_or_waits', not re.search(r'窗口_取标题|GetWindowText|SendMessage|ShowWindow \(|\.可视|(?<![\w\u4e00-\u9fff])窗口_枚举', both))
    check('callback_always_continues', re.findall(r'返回 \(([^)]*)\)', code('退出_隐藏窗口_枚举回调')) == ['真', '真'])

    print(json.dumps({'checks': len(checks), 'passed': len(checks)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
