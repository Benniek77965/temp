#!/usr/bin/env python3
"""Execute production consent boundaries and verify the module-owned settings root.

EPL statements use the existing source evaluator; registry/OS calls are explicit
boundaries. The native consent function is extracted unchanged and compiled for
Linux with Win32 registry substitutes. This is not a Windows/EPL runtime test.
"""
from pathlib import Path
from types import SimpleNamespace
import argparse
import hashlib
import importlib.util
import itertools
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

import check as syntax
from review_regression import Runtime, engine_runtime

HERE = Path(__file__).resolve().parent
NATIVE = HERE.parents[1]
PROJECT = NATIVE.parents[2]
MODULE = PROJECT / 'epl/模块/模块_电音助手.e~'
ENGINE = MODULE / '代码/程序集_机架联动引擎.static.e.txt'
LANGUAGE = MODULE / '代码/程序集_多语言.static.e.txt'
HOST = PROJECT / 'epl/代码/集_基础支持/机架联动_宿主.static.e.txt'
REGISTRY_API = PROJECT / 'epl/模块/精易模块v9.3.5[源码].e~/代码/系统/集_系统.static.e.txt'
BRIDGE = NATIVE / 'vst3/cpp/keyscale_rack_bridge.cpp'
CONTROLLER = NATIVE / 'vst3/cpp/AutoTune_KeyScale_Controller.cpp'
SETTINGS = r'SOFTWARE\DianYinAssistant\RackLink'
LEGACY = r'SOFTWARE\xddyx'

sys.path.insert(0, str(NATIVE / 'tests/security'))
from test_bridge_logic import extract


class NamespaceTests(unittest.TestCase):
    def test_registry_read_view_uses_the_bundled_boolean_contract(self):
        definition = syntax.section(REGISTRY_API.read_text(encoding='utf-8-sig'),
                                    '系统_取数值注册项')
        parameters = re.findall(r'^\.参数 ([^,]+), ([^,]+), ([^,\n]*),', definition, re.M)
        self.assertEqual(len(parameters), 4)
        self.assertEqual(parameters[3], ('是否为64位注册表', '逻辑型', '可空'))
        checked = []
        for path in (HOST, ENGINE):
            for line in path.read_text(encoding='utf-8-sig').splitlines():
                if line.lstrip().startswith("'") or '系统_取数值注册项 (' not in line:
                    continue
                args = syntax.call_arguments(line, '系统_取数值注册项')
                self.assertEqual(len(args), 4, line)
                self.assertIn(args[3], ('', '假'), line)
                checked.append(path)
        # host: the consent check and its diagnostic line (the per-computer bridge-version floor that read and
        # wrote RackLinkBridgeVersion is gone: the version is a label, the server turns away old bridges)
        self.assertEqual(checked.count(HOST), 2)
        self.assertEqual(checked.count(ENGINE), 3)

    def test_host_consent_calls_registry_with_a_boolean_view(self):
        source = HOST.read_text(encoding='utf-8-sig')
        for consent in (None, 0, 1, 2):
            with self.subTest(consent=consent):
                runtime = Runtime(source)
                runtime.env.update({'集_机架桥入口': 0, '集_机架桥准备错误': 0})
                reads = []
                def read(hive, path, key, view):
                    self.assertIs(type(view), bool)
                    self.assertIs(view, False)
                    reads.append((hive, path, key, view))
                    return consent or 0
                runtime.functions.update({'系统_取数值注册项': read,
                                          '机架联动_系统支持': lambda: False})
                self.assertEqual(runtime.invoke('机架联动_宿主回调', 1, 0, 0, 0, 0), 0)
                self.assertEqual(reads, [('#HKEY_CURRENT_USER', SETTINGS, 'RackLinkConsent', False)])
                self.assertEqual(runtime.env['集_机架桥准备错误'], 8 if consent == 1 else 18)

    def test_diagnostics_calls_registry_with_a_boolean_view(self):
        # Reuse the existing full diagnostic source executor with explicit file/
        # Win32 substitutes. Its evaluator is isolated from the engine evaluator.
        spec = importlib.util.spec_from_file_location(
            'namespace_diagnostics', NATIVE / 'tests/companion/test_host_diagnostics.py')
        diagnostics = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(diagnostics)
        diagnostics.SOURCE = HOST.read_text(encoding='utf-8-sig')
        test = self
        class CheckedDiagnostics(diagnostics.Fixture):
            def eval(self, text, env):
                if text.strip().startswith('系统_取数值注册项 ('):
                    values = [self.eval(arg, env) for arg in syntax.call_arguments(
                        text.strip(), '系统_取数值注册项')]
                    test.assertIs(type(values[3]), bool)
                    test.assertIs(values[3], False)
                    self.registry_reads.append(values)
                    return self.consent
                return super().eval(text, env)
        for consent in (0, 1):
            with self.subTest(consent=consent):
                fixture = CheckedDiagnostics()
                fixture.registry_reads = []
                fixture.consent = consent
                result = fixture.run('机架联动_诊断文本')
                self.assertIn('同意=' + str(consent), result)
                self.assertEqual(fixture.registry_reads,
                                 [[0, SETTINGS, 'RackLinkConsent', False]])
                self.assertFalse(fixture.handles)

    def test_removed_startup_preference_never_blocks_saved_auto_mode(self):
        source = ENGINE.read_text(encoding='utf-8-sig')
        self.assertNotIn('RackLinkAutoStart', source)
        self.assertNotIn('RackLinkAutoStart', HOST.read_text(encoding='utf-8-sig'))
        link = syntax.section(source, '机架引擎_线程_联动')
        gate_line = next(line.strip() for line in link.splitlines()
                         if line.strip().startswith('赋值 (局_启用, '))
        gate = syntax.call_arguments(gate_line, '赋值')[1]
        for obsolete, automatic, consent, supported in itertools.product(
                (None, '0', '1'), (None, '0', '1'), (0, 1), (False, True)):
            with self.subTest(old_startup=obsolete, automatic=automatic,
                              consent=consent, supported=supported):
                runtime = engine_runtime(source)
                for name, kind in re.findall(r'^\.程序集变量 ([^,]+), ([^,]+),', source, re.M):
                    runtime.env.setdefault(name, '' if kind == '文本型' else
                                           False if kind == '逻辑型' else 0)
                runtime.env.update({'集_机架_运行': False,
                                    '&机架引擎_线程_监测': 101,
                                    '&机架引擎_线程_联动': 102})
                if obsolete is not None:
                    runtime.registry[(SETTINGS, 'RackLinkAutoStart')] = obsolete
                if automatic is not None:
                    runtime.registry[(SETTINGS, 'RackLinkAutoSwitch')] = automatic
                runtime.registry[(SETTINGS, 'RackLinkConsent')] = consent
                runtime.registry[(SETTINGS, 'RackLinkStrength')] = '800'
                reads, threads = [], []
                def read(hive, path, key, view):
                    self.assertNotEqual(key, 'RackLinkAutoStart')
                    self.assertNotEqual(key, 'RackLinkStrength', 'strength follows the plug-in readback, not old settings')
                    reads.append(key)
                    return runtime.registry.get((path, key), '')
                def start_thread(entry, argument, handle):
                    # The full startup routine runs; thread creation is an
                    # explicit Win32 boundary that fills its output handle.
                    threads.append(entry)
                    runtime.env['集_机架_监测线程' if entry == 101 else
                                '集_机架_联动线程'] = entry
                    return True
                runtime.functions.update({
                    '播放器查询信息_初始化': lambda: None,
                    '机架引擎_系统支持': lambda: supported,
                    '机架引擎_记日志': lambda message: None,
                    '系统_取文本注册项': read,
                    '系统_取数值注册项': lambda *args: read(*args) or 0,
                    '到整数': lambda value: int(value or 0),
                    '启动线程': start_thread,
                })
                self.assertTrue(runtime.invoke('机架引擎_启动', 'http://example.invalid', 3, 'test', 0))
                self.assertEqual(threads, [101, 102])
                self.assertIs(runtime.env['集_机架_允许连接'], True)
                snapshot = runtime.env['集_机架_快照']
                self.assertEqual(snapshot.当前强度, -1)
                self.assertIs(snapshot.支持速度, False)
                self.assertIs(runtime.env['集_机架_强度已设置'], False)
                self.assertIs(runtime.env['集_机架_服务未开放'], False)
                self.assertIs(snapshot.随启动, True)
                self.assertEqual(snapshot.已同意, consent == 1)
                self.assertEqual(snapshot.自动切换, automatic != '0')
                self.assertEqual(runtime.evaluate(gate, {'局_快照': snapshot}),
                                 supported and consent == 1 and automatic != '0')
                self.assertEqual(runtime.registry.get((SETTINGS, 'RackLinkAutoStart')), obsolete)

    def test_removed_startup_public_entry_is_inert(self):
        source = ENGINE.read_text(encoding='utf-8-sig')
        for allowed, automatic, consent, requested in itertools.product((False, True), repeat=4):
            runtime = engine_runtime(source)
            runtime.env['集_机架_允许连接'] = allowed
            runtime.env['集_机架_快照'].自动切换 = automatic
            runtime.env['集_机架_快照'].已同意 = consent
            runtime.env['集_机架_快照'].随启动 = True
            runtime.registry[(SETTINGS, 'RackLinkAutoStart')] = '0'
            runtime.invoke('机架引擎_随启动', requested)
            self.assertIs(runtime.env['集_机架_允许连接'], allowed)
            self.assertIs(runtime.env['集_机架_快照'].自动切换, automatic)
            self.assertIs(runtime.env['集_机架_快照'].已同意, consent)
            self.assertIs(runtime.env['集_机架_快照'].随启动, True)
            self.assertEqual(runtime.registry, {(SETTINGS, 'RackLinkAutoStart'): '0'})
            self.assertEqual(runtime.events, [])

    def test_all_production_registry_endpoints_agree(self):
        expected = {ENGINE: [SETTINGS] * 6 + [SETTINGS + '\\Songs\\'],
                    HOST: [SETTINGS] * 2}   # consent read + diagnostic (the per-computer bridge-version floor is gone)
        for path, required in expected.items():
            source = path.read_text(encoding='utf-8-sig')
            roots = re.findall('“(SOFTWARE[^”]*)”', source)
            self.assertCountEqual(roots, required, path.name)
            self.assertNotIn(LEGACY, source)
        # The controller UI and its goal save/restore were removed; it only deletes the obsolete
        # ControllerGoal value on EJECT (one root). Bridge reads consent (one root).
        for path, count in ((BRIDGE, 1), (CONTROLLER, 1)):
            source = path.read_text(encoding='utf-8-sig')
            roots = [json.loads('"' + x + '"') for x in
                     re.findall(r'L?"(SOFTWARE(?:\\\\[^"\\]*)+)"', source)]
            self.assertEqual(roots, [SETTINGS] * count, path.name)
        configure = extract(BRIDGE.read_text(encoding='utf-8-sig'), 'static int xrb_configure(')
        self.assertRegex(configure[configure.index('{') + 1:], r'^\s*if\(!xrb_consent\(\)\)')

    def test_old_settings_are_neither_imported_nor_overwritten(self):
        source = ENGINE.read_text(encoding='utf-8-sig')
        runtime = engine_runtime(source)
        runtime.registry[(LEGACY, 'RackLinkConsent')] = 1
        runtime.registry[(LEGACY, 'RackLinkStrength')] = '999'
        runtime.invoke('机架引擎_同意', False)
        self.assertEqual(runtime.registry[(SETTINGS, 'RackLinkConsent')], 0)
        self.assertEqual(runtime.registry[(SETTINGS, 'RackLinkPrompted')], 1)
        runtime.invoke('机架引擎_同意', True)
        self.assertEqual(runtime.registry[(SETTINGS, 'RackLinkConsent')], 1)
        self.assertEqual(runtime.registry[(LEGACY, 'RackLinkConsent')], 1)
        self.assertEqual(runtime.registry[(LEGACY, 'RackLinkStrength')], '999')
        runtime.invoke('机架引擎_自动切换', False)
        runtime.invoke('机架引擎_随启动', False)
        self.assertEqual(runtime.registry[(SETTINGS, 'RackLinkAutoSwitch')], '0')
        self.assertNotIn((SETTINGS, 'RackLinkAutoStart'), runtime.registry)
        song = '同一首歌'.encode('utf-16le')
        self.assertEqual(runtime.invoke('机架引擎_缓存路径', song),
                         SETTINGS + '\\Songs\\' + hashlib.md5(song).hexdigest())

    def test_host_never_loads_components_without_new_consent(self):
        source = HOST.read_text(encoding='utf-8-sig')
        for consent in (None, 0, 2, 1):
            runtime = Runtime(source)
            runtime.env.update({'集_机架桥入口': 0, '集_机架桥准备错误': 0})
            runtime.registry[(LEGACY, 'RackLinkConsent')] = 1
            if consent is not None:
                runtime.registry[(SETTINGS, 'RackLinkConsent')] = consent
            calls = []
            runtime.functions['机架联动_调用桥'] = lambda *a: calls.append('bridge') or 1
            runtime.functions['机架联动_准备桥'] = lambda: calls.append('prepare') or True
            runtime.functions['机架联动_系统支持'] = lambda: calls.append('system') or False
            self.assertEqual(runtime.invoke('机架联动_宿主回调', 1, 0, 0, 0, 0), 0)
            if consent == 1:
                self.assertEqual(runtime.env['集_机架桥准备错误'], 8)
                self.assertEqual(calls, ['system'])
            else:
                self.assertEqual(runtime.env['集_机架桥准备错误'], 18)
                self.assertEqual(calls, [])

    def test_default_and_explicit_language_do_not_read_project_registry(self):
        source = LANGUAGE.read_text(encoding='utf-8-sig')
        body = syntax.section(source, '多语言_序号')
        self.assertNotIn('注册项', body)
        self.assertNotIn('xddyx', body)
        for given in range(20):
            runtime = Runtime(source)
            runtime.env['全_多语言_语言序号'] = given
            runtime.functions['系统_取文本注册项'] = lambda *a: self.fail('project registry read')
            self.assertEqual(runtime.invoke('多语言_序号'), given or 1)

    def test_native_consent_exact_function(self):
        source = BRIDGE.read_text(encoding='utf-8-sig')
        production = extract(source, 'static bool xrb_consent(')
        harness = r'''
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include <string>
typedef void* HKEY;typedef uint32_t DWORD;typedef int32_t LONG;typedef unsigned char BYTE;
#define HKEY_CURRENT_USER ((HKEY)1)
#define KEY_QUERY_VALUE 1
#define ERROR_SUCCESS 0
#define REG_DWORD 4
static LONG openError=0,queryError=0;static DWORD regType=4,regSize=4,regValue=1;
static unsigned opens=0,queries=0,closes=0,checks=0;static bool oldOnly=false;
static const wchar_t expected[]=L"SOFTWARE\\DianYinAssistant\\RackLink";
static LONG RegOpenKeyExW(HKEY,const wchar_t*path,DWORD,DWORD,HKEY*out){opens++;if(wcscmp(path,expected)){if(!oldOnly||wcscmp(path,L"SOFTWARE\\xddyx"))return 2;}else if(oldOnly)return 2;else if(openError)return openError;*out=(HKEY)2;return 0;}
static LONG RegQueryValueExW(HKEY,const wchar_t*name,void*,DWORD*type,BYTE*out,DWORD*size){queries++;if(wcscmp(name,L"RackLinkConsent"))return 2;*type=regType;*size=regSize;memcpy(out,&regValue,sizeof regValue);return queryError;}
static LONG RegCloseKey(HKEY){closes++;return 0;}
#define CHECK(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL production consent line%d: %s\n",__LINE__,#x);return 1;}}while(0)
'''
        harness += production + r'''
int main(){
 struct Case{LONG open,query;DWORD type,size,value;bool old,allow;};
 Case cases[]={{2,0,4,4,1,false,false},{0,2,4,4,1,false,false},{0,0,1,4,1,false,false},{0,0,4,3,1,false,false},{0,0,4,4,0,false,false},{0,0,4,4,2,false,false},{0,0,4,4,1,false,true},{0,0,4,4,1,true,false}};
 for(const Case&c:cases){opens=queries=closes=0;openError=c.open;queryError=c.query;regType=c.type;regSize=c.size;regValue=c.value;oldOnly=c.old;CHECK(xrb_consent()==c.allow);CHECK(opens==1);CHECK(queries==((c.open||c.old)?0:1));CHECK(closes==queries);}
 printf("PASS exact native module consent: %u checks, 8 registry states\n",checks);return 0;
}
'''
        scratch = Path(os.environ.get('XHH_TEST_TMP', tempfile.gettempdir())).resolve()
        self.assertFalse(scratch == NATIVE or NATIVE in scratch.parents)
        scratch.mkdir(parents=True, exist_ok=True)
        compiler = shutil.which('g++')
        self.assertIsNotNone(compiler, 'g++ required to execute the production native consent function')
        with tempfile.TemporaryDirectory(prefix='module-consent-', dir=scratch) as directory:
            work = Path(directory)
            cpp = work / 'consent.cpp'
            cpp.write_text(harness)
            for mode, flags in [('optimized', ['-O2']), ('ubsan', ['-O1', '-g', '-fsanitize=undefined', '-fno-sanitize-recover=all'])]:
                binary = work / mode
                built = subprocess.run([compiler, '-std=c++11', *flags, str(cpp), '-o', str(binary)], capture_output=True, text=True)
                self.assertEqual(built.returncode, 0, built.stdout + built.stderr)
                run = subprocess.run([str(binary)], capture_output=True, text=True)
                self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
                print(mode + ': ' + run.stdout.strip())


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(NamespaceTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {'status': 'passed' if result.wasSuccessful() else 'failed',
              'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
              'native_checks_per_mode': 32, 'native_modes': ['optimized', 'ubsan'],
              'settings_root': SETTINGS,
              'source_sha256': {str(p.relative_to(PROJECT)): hashlib.sha256(p.read_bytes()).hexdigest()
                                for p in (ENGINE, LANGUAGE, HOST, REGISTRY_API, BRIDGE, CONTROLLER)},
              'scope': 'Exact EPL statements/native consent function; registry/OS boundaries substituted, not Windows or formal EPL execution'}
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    raise SystemExit(not result.wasSuccessful())
