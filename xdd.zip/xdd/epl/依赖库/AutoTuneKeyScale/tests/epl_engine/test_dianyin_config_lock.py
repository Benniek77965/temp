#!/usr/bin/env python3
"""电音助手账户配置的跨线程读写（执行模块与宿主的真实 EPL 源码）。

工作线程（打开窗口时启动引擎、重新登录）在 启动后台 里调用 读取配置：内存配置项 整体重新载入、改写窗口位置；界面线程同时可能在
保存配置（拖动窗口结束、点选播放器）、取窗口位置、置窗口位置 里读写同一个 内存配置项 与窗口位置。宿主的保存回调（界面线程）整体改写
全局 电音助手_配置文本，工作线程同时把它交给 启动后台。文本、对象被整体改写时旧数据立即释放，另一线程同时读会读到已释放的内存。

修复：模块 类_电音助手 在对象创建时建一把叶子锁（集_配置许可，初始化好再交出），配置对象与窗口位置都在锁里读写，保存回调在锁外调用；
宿主加全局叶子锁 全_许可_电音助手配置（同 全_许可_MIDI配置），电音助手_配置文本 的读写都经 电音助手配置_取／电音助手配置_置。

用 epl_machine 执行模块真实的 类_电音助手（_初始化、读取配置、保存配置、启动后台、取窗口位置、置窗口位置、配置_加锁／解锁）与宿主真实的
电音助手配置_取、电音助手配置_置、电音助手_保存配置_回调函数；内存配置项、临界区、引擎接口、锁对象为替身：替身记下每次读写时锁是否持有。
加 --epl 原工程的 epl 目录 时执行原代码，复现原问题（配置对象在锁外读写）。不是易语言编译，也不是 Windows 实机（线程调度不模拟，只核对加锁范围）。
用法（在依赖库根目录）：python3 tests/epl_engine/test_dianyin_config_lock.py [--epl 目录]
"""
import argparse
import json
import re
from pathlib import Path
import epl_machine as em
import check as syntax

HERE = Path(__file__).resolve().parent


class Lock:
    def __init__(self):
        self.depth, self.max_depth, self.events = 0, 0, []

    def enter(self, *_):
        self.depth += 1
        self.max_depth = max(self.max_depth, self.depth)
        self.events.append('enter')

    def leave(self, *_):
        assert self.depth > 0, 'leave without enter'
        self.depth -= 1
        self.events.append('leave')


class Ini:
    """内存配置项 的替身：节 → 名 → 值；每次调用都记下锁是否持有。"""
    def __init__(self, lock):
        self.lock, self.data, self.unlocked = lock, {}, []

    def _seen(self, op):
        if self.lock.depth == 0:
            self.unlocked.append(op)

    def 加载_从内存(self, text):
        self._seen('加载_从内存')
        self.data = {}
        sec = None
        for line in text.splitlines():
            line = line.strip()
            if line.startswith('[') and line.endswith(']'):
                sec = self.data.setdefault(line[1:-1], {})
            elif '=' in line and sec is not None:
                k, v = line.split('=', 1)
                sec[k] = v
        return True

    def 读内存配置项(self, sec, key, default=''):
        self._seen('读内存配置项')
        return self.data.get(sec, {}).get(key, default)

    def 写内存配置项(self, sec, key, value, *_):
        self._seen('写内存配置项')
        self.data.setdefault(sec, {})[key] = value
        return True

    def 保存到内存(self):
        self._seen('保存到内存')
        return '\r\n'.join('[%s]\r\n' % s + '\r\n'.join('%s=%s' % kv for kv in d.items()) for s, d in self.data.items())


def module_machine(epl):
    module = epl / '模块/模块_电音助手.e~'
    m = em.Machine()
    m.load_class((module / '代码/类_电音助手.class.e.txt').read_text('utf-8-sig'))
    lock = Lock()
    m.cs, m.cs_lock, m.calls = {}, lock, []
    def init_cs(env, args, raws):                     # 初始化那一刻：对象成员 集_配置许可 还没交出（别的线程看不到半成品）
        m.cs['init'] = m.ev(args[0], env)
        m.cs['published_at_init'] = env['_obj'].members.get('集_配置许可', 0) != 0
    m.raw_builtins['InitializeCriticalSectionP'] = init_cs
    base_int = m.builtins['到整数']
    m.builtins.update({'申请内存': lambda size, zero=None: 0x7000,
                       'EnterCriticalSectionP': lock.enter, 'LeaveCriticalSectionP': lock.leave,
                       '播放器查询信息_初始化': lambda: None, '多语言_建许可区': lambda: None,
                       '机架引擎_启动': lambda *a: True, '机架引擎_选择播放器': lambda mode, player: m.calls.append(('选择播放器', mode, player)),
                       '到整数': lambda v: (abs(hash(v)) % 1000 + 1) if isinstance(v, str) and v.startswith('&') else base_int(v)})
    def pick(env, args, raws):                        # 机架引擎_取播放器选择 (返回_模式, 返回_播放器)：写回调用处，并记下此刻配置锁是否持有
        m.calls.append(('取播放器选择', lock.depth))
        m.store(raws[0].strip(), 1, env)
        m.store(raws[1].strip(), 'QQ音乐', env)
    def callback(env, args, raws):                    # 调用子程序 (保存配置_回调函数, , , 局_保存配置)
        m.calls.append(('回调', lock.depth, m.ev(args[3], env)))
        return True
    m.raw_builtins.update({'机架引擎_取播放器选择': pick, '调用子程序': callback})
    for name, kind in (('全_基调查询_API接口_域名', '文本型'), ('全_软件类型', '整数型'), ('全_账号', '文本型')):   # 模块全局（启动后台 里记下）
        m.global_types[name], m.globals[name] = (kind, False), em.DEFAULTS[kind]
    obj = m.new_object('类_电音助手')
    obj.members['内存配置项'] = Ini(lock)
    return m, obj


def loaders_outside_save_lock(epl):
    """配置载入与保存用同一把许可：保存组件配置 读到的全局，在载入子程序（配置文件同步到组件；项目 B 另有 配置文件同步到组件_加载所有cookie等账号信息）里
    每一处整体改写（赋值、从JSON载入）都应在 m_许可_保存组件配置 里：载入在初始化线程里（重新登录时再执行），保存在别的线程里同时读，文本被整体改写时旧缓冲区立即释放。
    返回不在许可里的改写（子程序名, 语句）。"""
    main_form = (epl / '代码/窗_主程序/窗口程序集_主窗口.form.e.txt').read_text('utf-8-sig')
    names = set(re.findall(r'^\.全局变量 ([^,\s]+),', (epl / '全局变量.e.txt').read_text('utf-8-sig'), re.M))
    save = '\n'.join(re.sub(r"\s+'.*$", '', x) for x in syntax.section(main_form, '保存组件配置').split('\n'))
    read = {g for g in names if re.search(r'(?<![\w\u4e00-\u9fff])' + re.escape(g) + r'(?![\w\u4e00-\u9fff])', save)}
    outside = []
    for loader in ('配置文件同步到组件', '配置文件同步到组件_加载所有cookie等账号信息'):
        if '.子程序 ' + loader + ',' not in main_form:
            continue
        depth = 0
        for line in syntax.section(main_form, loader).split('\n')[1:]:
            code = re.sub(r"\s+'.*$", '', line).strip()
            if code == 'm_许可_保存组件配置.进入 ()':
                depth += 1
            elif code == 'm_许可_保存组件配置.退出 ()':
                depth -= 1
            else:
                m = re.match(r'赋值 \(([^,]+),', code) or re.match(r'([^.\s(]+)\.从JSON载入 \(', code)
                if m and m.group(1).strip() in read and depth <= 0:
                    outside.append((loader, code[:40]))
    return outside


def call(m, obj, name, *args):
    return m.invoke(obj.cls.methods[name], [('lit', a) for a in args], {}, obj)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--epl', type=Path, default=HERE.parents[3])
    opts = ap.parse_args()
    checks, observed = [], {}

    def check(name, ok):
        checks.append(name)
        assert ok, name

    m, obj = module_machine(opts.epl)
    ini, lock = obj.members['内存配置项'], m.cs_lock
    observed['lock_created_at_construction'] = obj.members.get('集_配置许可', 0) == 0x7000
    cfg = '[电音助手]\r\n主窗口_位置_顶边=120\r\n主窗口_位置_左边=-1500\r\n切换播放器模式1=0\r\n切换播放器模式_手动_当前播放器=酷狗音乐'
    call(m, obj, '启动后台', cfg, 'http://example.invalid', 3, 'acc', '&电音助手_保存配置_回调函数', None)
    env = {'_obj': None, '_types': {'L': ('整数型', False), 'T': ('整数型', False)}, '_omitted': set(), 'L': 0, 'T': 0}
    has = m.invoke(obj.cls.methods['取窗口位置'], [em.parse_expr('L'), em.parse_expr('T')], env, obj)
    observed['position_after_load'] = [env['L'], env['T'], has]
    call(m, obj, '置窗口位置', 300, -20)
    observed['unlocked_config_ops'] = list(ini.unlocked)
    observed['callback_lock_depth'] = [c[1] for c in m.calls if c[0] == '回调']
    observed['pick_lock_depth'] = [c[1] for c in m.calls if c[0] == '取播放器选择']
    observed['loader_writes_outside_save_lock'] = loaders_outside_save_lock(opts.epl)
    if opts.epl != HERE.parents[3]:
        print(json.dumps({'baseline': str(opts.epl), 'observed': observed}, ensure_ascii=False))
        return
    check('lock_initialized_before_it_is_published', observed['lock_created_at_construction'] and m.cs.get('init') == 0x7000 and m.cs.get('published_at_init') is False)
    check('every_config_object_access_inside_the_lock', ini.unlocked == [])
    check('lock_balanced_and_never_nested', lock.depth == 0 and lock.max_depth == 1 and lock.events.count('enter') == lock.events.count('leave') > 0)
    check('engine_lock_taken_outside_the_config_lock', observed['pick_lock_depth'] and all(d == 0 for d in observed['pick_lock_depth']))
    check('save_callback_called_outside_the_lock', observed['callback_lock_depth'] == [0])
    check('position_round_trip', observed['position_after_load'] == [-1500, 120, True])
    saved = [c[2] for c in m.calls if c[0] == '回调'][0]
    check('saved_config_has_new_position_and_player', '主窗口_位置_左边=300' in saved and '主窗口_位置_顶边=-20' in saved and '切换播放器模式_手动_当前播放器=QQ音乐' in saved)
    check('player_choice_from_config_applied', ('选择播放器', 0, '酷狗音乐') in m.calls)
    # 窗口位置三项：除对象创建（还没有别的线程）外，各子程序里读写它们的行都在 配置_加锁 与 配置_解锁 之间
    text = (opts.epl / '模块/模块_电音助手.e~/代码/类_电音助手.class.e.txt').read_text('utf-8-sig').replace('\r\n', '\n')
    outside = []
    for name in re.findall(r'^\.子程序 ([^,]+),', text, re.M):
        if name == '_初始化':
            continue
        depth = 0
        for line in syntax.section(text, name).split('\n')[1:]:
            code = re.sub(r"\s+'.*$", '', line).strip()
            if not code or code.startswith(("'", '.参数', '.局部变量')):
                continue
            if code == '配置_加锁 ()':
                depth += 1
            elif code == '配置_解锁 ()':
                depth -= 1
            elif re.search(r'集_窗口(左|顶|有位置)|内存配置项\.', code) and depth == 0:
                outside.append((name, code[:60]))
    check('window_position_fields_only_touched_inside_the_lock ' + str(outside), not outside)

    # 宿主：电音助手_配置文本 只经 电音助手配置_取／置，在叶子锁里一次复制或赋值
    epl = opts.epl
    host = (epl / '代码/集_基础支持/机架联动_宿主.static.e.txt').read_text('utf-8-sig')
    main_form = (epl / '代码/窗_主程序/窗口程序集_主窗口.form.e.txt').read_text('utf-8-sig')
    hm = em.Machine()
    hm.load_static(host, names={'电音助手配置_取', '电音助手配置_置'})
    hm.load_static(main_form, names={'电音助手_保存配置_回调函数'})
    leaf = Lock()
    leaf_obj = type('Leaf', (), {'进入': lambda self: leaf.enter(), '退出': lambda self: leaf.leave()})()
    store = {'text': ''}
    hm.global_types['全_许可_电音助手配置'], hm.globals['全_许可_电音助手配置'] = ('对象', False), leaf_obj
    hm.global_types['电音助手_配置文本'], hm.globals['电音助手_配置文本'] = ('文本型', False), ''
    seen = []
    orig_store = hm.store
    def watched_store(target, value, env):
        if (target if isinstance(target, str) else '') == '电音助手_配置文本' or (not isinstance(target, str) and target == ('var', '电音助手_配置文本')):
            seen.append(('write', leaf.depth))
        return orig_store(target, value, env)
    hm.store = watched_store
    orig_read = hm.read
    def watched_read(name, env):
        if name == '电音助手_配置文本':
            seen.append(('read', leaf.depth))
        return orig_read(name, env)
    hm.read = watched_read
    upload = lambda: seen.append(('upload', leaf.depth))
    hm.builtins['保存组件配置_并上传到服务器_加标识'] = upload          # 项目 A 直接调用
    hm.global_types['主窗口'], hm.globals['主窗口'] = ('对象', False), type('MainWindow', (), {'保存组件配置_并上传到服务器_加标识': lambda self: upload()})()   # 项目 B 经 主窗口. 调用
    hm.invoke(hm.subs['电音助手_保存配置_回调函数'], [('lit', 'A=1')], {}, None)
    got = hm.invoke(hm.subs['电音助手配置_取'], [], {}, None)
    check('host_callback_writes_and_readers_copy_inside_the_leaf_lock', got == 'A=1' and seen == [('write', 1), ('upload', 0), ('read', 1)] and leaf.depth == 0)
    direct = []
    for f in sorted((epl / '代码').rglob('*.e.txt')):
        cur = ''
        for line in f.read_text('utf-8-sig').splitlines():
            if line.startswith('.子程序 '):
                cur = line.split(',')[0][5:]
            code = re.sub(r"\s+'.*$", '', line)
            if '电音助手_配置文本' in code and cur not in ('电音助手配置_取', '电音助手配置_置'):
                direct.append((f.name, cur))
    check('no_direct_access_to_the_global_elsewhere ' + str(direct), not direct)
    for name in ('电音助手配置_取', '电音助手配置_置'):
        body = [re.sub(r"\s+'.*$", '', l).strip() for l in syntax.section(host, name).replace('\r\n', '\n').split('\n')[1:]]
        body = [l for l in body if l and not l.startswith(('.参数', '.局部变量'))]
        inside = body[body.index('全_许可_电音助手配置.进入 ()') + 1:body.index('全_许可_电音助手配置.退出 ()')]
        check('leaf_lock_holds_exactly_one_assignment:' + name, len(inside) == 1 and inside[0].startswith('赋值 ('))
    check('config_loaders_write_saved_globals_inside_the_save_lock ' + str(observed['loader_writes_outside_save_lock']), not observed['loader_writes_outside_save_lock'])
    glob = (epl / '全局变量.e.txt').read_text('utf-8-sig')
    check('leaf_lock_is_a_global_constructed_at_startup', re.search(r'^\.全局变量 全_许可_电音助手配置, 鱼刺类_临界许可,', glob, re.M) is not None)
    print(json.dumps({'checks': len(checks), 'passed': len(checks), 'observed': observed}, ensure_ascii=False))


if __name__ == '__main__':
    main()
