// Regenerates soda_values.json (needs Node and: npm install msgpackr): single values encoded by msgpackr with records
// (useRecords, as 汽水音乐 writes them) for the EPL msgpack decoder tests. Every value is invented.
const { Packr } = require('msgpackr');
const fs = require('fs');
const path = require('path');
const packr = () => new Packr({ useRecords: true });       // a fresh encoder: structures defined inside each value
const hex = v => Buffer.from(v).toString('hex');
const scalars = [];
for (const n of [0, 1, 63, 64, 127, 128, 255, 256, 65535, 65536, 4294967295, 4294967296, 1793940362, 1793940362123,
                 -1, -32, -33, -128, -129, -32768, -32769, -2147483648, -2147483649, 1.5, -2.25])
  scalars.push({ kind: 'number', value: n, hex: hex(packr().pack(n)) });
for (const s of ['', 'a', 'x'.repeat(31), 'x'.repeat(32), 'y'.repeat(255), 'y'.repeat(256), '夜に駆ける 🌙'])
  scalars.push({ kind: 'text', value: s, hex: hex(packr().pack(s)) });
for (const v of [null, true, false]) scalars.push({ kind: 'other', value: v, hex: hex(packr().pack(v)) });
const values = [];
const add = (name, v) => values.push({ name, hex: hex(packr().pack(v)) });
add('empty array', []); add('array of 3', [1, 2, 3]); add('array of 20 (array16)', Array.from({ length: 20 }, (_, i) => i * 1000));
add('map (fixmap)', new Map([[1, 'a'], ['b', [2, 3]]])); add('map of 20 (map16)', new Map(Array.from({ length: 20 }, (_, i) => [i, 'v' + i])));
add('binary 10 (bin8)', Buffer.alloc(10, 7)); add('binary 300 (bin16)', Buffer.alloc(300, 9));
add('date (timestamp ext)', new Date(1793940362123)); add('date before 1970 (ext8)', new Date(-1000));
add('record and references', { a: 1, list: [{ x: 1, y: 'p' }, { x: 2, y: 'q' }, { x: 3, y: 'r' }] });
add('80 different structures (ids reused)', Array.from({ length: 80 }, (_, i) => ({ ['k' + i]: i, same: i % 2 })));
add('nested 10 deep', JSON.parse('['.repeat(10) + '1' + ']'.repeat(10)));
add('nested 100 deep', JSON.parse('['.repeat(100) + '1' + ']'.repeat(100)));
// whole cache records with other encodings of the fields after the playable info: size as fixint / uint16, time as a float
const T = 1793940362;
const rec = (track, name, artists, extra) => Object.assign({ resourceId: 'r' + track, info: { trackId: String(track), urls: ['u'], mediaDetail: {
  video_model: { status: 10 }, playable: { type: 'track', name, artists } } }, headers: {}, chunkId: 'c' + track }, extra);
const records = [
  { name: 'size fixint', value: rec(1, '甲', [{ name: '乙' }], { previousAccessTime: T, size: 5 }), time: T },
  { name: 'size uint16', value: rec(2, '甲', [{ name: '乙' }], { previousAccessTime: T, size: 300 }), time: T },
  { name: 'time as float (milliseconds with a fraction)', value: rec(3, '甲', [{ name: '乙' }], { previousAccessTime: 1793940362123.5, size: 70000 }), time: 1793940362123 },
  { name: 'time then a text field', value: rec(4, '甲', [{ name: '乙' }], { previousAccessTime: T, size: 9, note: 'tail' }), time: T },
  { name: 'time not a number', value: rec(5, '甲', [{ name: '乙' }], { previousAccessTime: 'yesterday', size: 9 }), time: null },
  { name: 'no artists', value: rec(6, '甲', [], { previousAccessTime: T, size: 9 }), time: T, song: '' },
  { name: 'artist name null', value: rec(7, '甲', [{ name: null }], { previousAccessTime: T, size: 9 }), time: T, song: '' },
  { name: 'empty song name', value: rec(8, '', [{ name: '乙' }], { previousAccessTime: T, size: 9 }), time: T, song: '' },
  { name: 'artists after a big field', value: rec(9, 'Song', [{ id: 1, name: 'A' }, { id: 2, name: 'B' }, { id: 3, name: '' }], { previousAccessTime: T, size: 9 }), time: T, song: 'A/B - Song' },
].map(r => ({ name: r.name, hex: hex(packr().pack(r.value)), time: r.time, song: r.song, track: r.value.info.trackId }));
fs.writeFileSync(path.join(process.argv[2] || __dirname, 'soda_values.json'), JSON.stringify({ scalars, values, records }));
console.log('scalars', scalars.length, 'values', values.length, 'records', records.length);
