// Regenerates soda_entries_synthetic.db + soda_entries_synthetic.json (needs Node and: npm install lmdb@3.1.3 msgpackr).
// The records are invented (a few public song titles are borrowed as names; keys, IDs, URLs, headers and times are
// made up); the layout follows 汽水音乐 (SodaMusic) LunaCacheV2\entries.db as observed: an lmdb-js
// database (LMDB data format 2) whose values are written as raw bytes, each one msgpackr-encoded with records
// (useRecords): the record structures are defined inside every value, there is no shared-structures key.
// Top-level fields: resourceId, info{trackId, urls, …, mediaDetail{video_model, …, playable{type, name, artists[{name}]}}},
// headers, chunkId, previousAccessTime (Unix seconds), size.
const { open } = require('lmdb');
const { Packr } = require('msgpackr');
const fs = require('fs');
const path = require('path');
const out = process.argv[2] || __dirname;
const file = path.join(out, 'soda_entries_synthetic.db');
for (const f of [file, file + '-lock']) if (fs.existsSync(f)) fs.unlinkSync(f);
const packr = new Packr({ useRecords: true });
const T0 = 1793940000;
let seq = 0;
const uuid = n => `${(0x1a2b3c4d + n).toString(16).padStart(8, '0')}-5cba-4e32-8e18-${(0xc5c731e87cfa + n).toString(16).padStart(12, '0')}`;
function record({ track, name, artists, type = 'track', t, quality = 'F_highest', pad = 0, extraTail = false }) {
  const vid = `v10ad6g50000syn${String(++seq).padStart(4, '0')}og65qhjgs6310`;
  const key = `${vid}_${quality}`;
  const value = {
    resourceId: key,
    info: {
      trackId: String(track), urls: [`https://example.invalid/${vid}/a.mp4`, `https://example.invalid/${vid}/b.mp4`],
      spade: '', quality: 'adapt_lowest', bitrate: 303054, isPreview: false,
      mediaDetail: {
        video_model: { status: 10, message: 'success', version: 3, video_id: vid, video_duration: 275.018, media_type: 'video',
                       url_expire: 1769847332, video_list: [{ main_url: 'x'.repeat(pad) }, { backup_url: 'y' }], volume: { loudness: -9.6, peak: 0.98 } },
        video_model_type: 1,
        playable: { key: `${type}-${track}`, type, id: String(track), name, media_type: type === 'video' ? 'ugc_video' : 'track',
                    artists: artists.map(a => a === null ? { id: '0', name: null } : { id: String(1000 + a.length), name: a }),
                    duration: 275018, vid, stats: { count_collected: 12, count_shared: -3 }, label_info: {}, state: { can_play: true } },
        response: { status_info: { code: 0 }, expire_at: 1769758857, player_infos: [] },
      },
    },
    headers: { 'content-type': 'video/mp4', 'content-length': '9966294', etag: '"f1f18a486eb627017d1cf13ce1b1935f"' },
    chunkId: uuid(seq), previousAccessTime: t, size: 9966294 - seq,
  };
  if (extraTail) value.note = 'a field after size';
  return [key, packr.pack(value), { time: t, track: String(track), type, name, artists, extraTail }];
}
const rows = [];
// 播放与预加载：够钟 单独播放；下一秒 5 首不同的歌一起更新（预加载）；33 秒后 Training Season 单独播放（当前歌曲）
rows.push(record({ track: 7001, name: '够钟（Cover 周柏豪）', artists: ['阿兴'], t: T0 + 328, pad: 6000 }));
['Why Am I Always Tired', 'Brave_Heart(纯净空灵版)', 'The World Is Waiting', 'One Last Time', '渣男之歌(请叫我的名字)'].forEach((n, i) =>
  rows.push(record({ track: 7100 + i, name: n, artists: ['预加载歌手' + i], t: T0 + 329, pad: 3000 + i * 900 })));
rows.push(record({ track: 7200, name: 'Training Season (Live from the Royal Albert Hall)', artists: ['Dua Lipa'], t: T0 + 362, quality: 'P_higher', pad: 20000 }));
// 同一首歌的另一种音质，和三首别的歌在同一秒（预加载）
rows.push(record({ track: 7200, name: 'Training Season (Live from the Royal Albert Hall)', artists: ['Dua Lipa'], t: T0 + 148, pad: 9000 }));
['Off My Face', '紧急联络人', '给自己的情书（请不要灰心）'].forEach((n, i) => rows.push(record({ track: 7300 + i, name: n, artists: ['歌手' + i], t: T0 + 148, pad: 500 })));
rows.push(record({ track: 7400, name: '刻在我心底的名字（Oublie-le）', artists: ['池袋西口'], t: T0 + 149, pad: 1200 }));
// 视频、多位歌手、Unicode、size 后面多一个字段（末尾读不出时从头解码）
rows.push(record({ track: 7500, name: 'Lab - 记忆棉（歌词版MV） #粤语歌', artists: ['地球娱乐Online'], type: 'video', t: T0 - 500, pad: 4000 }));
rows.push(record({ track: 7501, name: '#孙燕姿 #杨丞琳 爱是自由意志的沉沦', artists: [null], type: 'video', t: T0 - 501, pad: 100 }));
rows.push(record({ track: 7600, name: '是你', artists: ['徐健铭', '高睿'], t: T0 - 600, pad: 2500 }));
rows.push(record({ track: 7601, name: '夜に駆ける 🌙', artists: ['YOASOBI'], t: T0 - 601, pad: 700 }));
rows.push(record({ track: 7700, name: '尾巴多一个字段', artists: ['测试歌手'], t: T0 - 700, pad: 300, extraTail: true }));
// 填充：更早的记录，大小不一（有的在叶子页里，有的占多个溢出页），让 B 树分出多层
for (let i = 0; i < 100; i++)
  rows.push(record({ track: 8000 + i, name: '早先的歌 ' + i, artists: ['填充歌手 ' + (i % 7)], t: T0 - 1000 - i * 37, pad: (i * 977) % 3000 }));
const db = open({ path: file, encoding: 'binary', keyEncoding: 'binary', noSubdir: true, mapSize: 8 * 1024 * 1024 });
db.transactionSync(() => { for (const [k, v] of rows) db.putSync(Buffer.from(k, 'latin1'), v); });
const stats = db.getStats();
db.close();
const manifest = rows.map(([k, v, e]) => ({ key: k, value_sha256: require('crypto').createHash('sha256').update(v).digest('hex'), size: v.length, ...e }))
  .sort((a, b) => Buffer.compare(Buffer.from(a.key, 'latin1'), Buffer.from(b.key, 'latin1')));
fs.writeFileSync(path.join(out, 'soda_entries_synthetic.json'), JSON.stringify({ T0, entryCount: stats.entryCount, treeDepth: stats.treeDepth,
  overflowPages: stats.overflowPages, records: manifest }, null, 1));
if (fs.existsSync(file + '-lock')) fs.unlinkSync(file + '-lock');
console.log('records', rows.length, 'depth', stats.treeDepth, 'overflow pages', stats.overflowPages, 'file bytes', fs.statSync(file).size);
