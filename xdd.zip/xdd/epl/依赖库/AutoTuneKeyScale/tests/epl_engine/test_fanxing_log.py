#!/usr/bin/env python3
"""Execute the production EPL bounded reader/scanner with explicit Win32/JSON substitutes.

This is not an EPL compiler, real Windows file-I/O/Unicode performance, or zyJson DLL test.
The file size can be virtual so the actual 64-bit arithmetic is tested without large fixtures.
"""
from pathlib import Path
import argparse
import json
import re
import struct
from copy import deepcopy
import check as syntax
from review_regression import Runtime, NextIteration


def clean_inline_comments(source):
    result = []
    for line in source.splitlines():
        quote = False
        for pos, char in enumerate(line):
            if char == '“': quote = True
            elif char == '”': quote = False
            elif char == "'" and not quote:
                line = line[:pos]
                break
        result.append(line)
    return '\n'.join(result)


class JsonDocument:
    def 解析UTF8(self, text, *unused):
        try:
            self.data = json.loads(text)
            return True
        except (ValueError, UnicodeError):
            return False

    def 取文本W(self, key, *unused):
        return (str(self.data.get(key.decode('utf-16le').rstrip('\0'), '')) + '\0').encode('utf-16le')


class Reader(Runtime):
    def __init__(self, source):
        super().__init__(clean_inline_comments(source))
        self.env.update({'集_繁星日志_身份': b'', '集_繁星日志_大小': 0, '集_繁星日志_歌名': '', '#引号': '"',
                         '集_播放器_进程名组': [], '集_播放器_进程ID组': [], '集_播放器_进程时间': 0})
        self.clock = 100000
        self.local_factories.update({'字节集': bytes, 'zyJsonDocument': JsonDocument})
        self.content = b''
        self.virtual_size = None
        self.identity = (1, 2, 3)
        self.present = True
        self.fail = ''
        self.reads = []
        self.opened = []
        self.closed = []
        self.position = 0
        self.functions.update({
            '系统_取启动时间': lambda: self.tick_clock(), '到小写': lambda text: text.lower(),
            '目录_取特定目录W': lambda *args: b'' if self.fail=='directory' else ('C:\\用户\\音乐😀\\'+'\0').encode('utf-16le'),
            '编码_Ansi到Unicode': lambda text, *args: (text + '\0').encode('utf-16le'),
            '编码_Ansi到Utf8': lambda text: text.encode('utf-8'),
            'ATU': lambda text, *args: (text + '\0').encode('utf-16le'),
            '编码_Unicode到usc2': lambda data, *args: data.decode('utf-16le').rstrip('\0'),
            '到文本': lambda data: data.decode('utf-8') if isinstance(data, bytes) else str(data),
            '到长整数': int,
            '取字节集长度': len,
            '取空白字节集': lambda size: b'\0' * size,
            '取字节集左边': lambda data, count: data[:count],
            '取字节集中间': lambda data, start, count: data[start-1:start-1+count],
            '寻找字节集': lambda data, needle, start: data.find(needle, start-1)+1 if data.find(needle, start-1)>=0 else -1,
            '取字节集数据': lambda data, kind, start: data[start-1],
            '取数组成员数': len,
            '文本_删首尾空W': lambda data: (data.decode('utf-16le').rstrip('\0').strip()+'\0').encode('utf-16le'),
            '文本_取左边W': lambda data, marker, *args: data.split(marker[:-2])[0] + b'\0\0',
            '文本_替换W': lambda data, needle, replacement, *args: data.replace(needle[:-2], replacement),
            'un_连接': lambda *args: b''.join(x[:-2] if x.endswith(b'\0\0') else x for x in args if isinstance(x,bytes))+b'\0\0',
            # as in 精易: up to the first character-aligned U+0000; with 真 (标准Unicode编码) a terminator is put back
            '删除Unicode结尾空白字节': lambda data, *args: (lambda i: b'' if i == 0 else data[:i] + (b'\0\0' if args and args[0] else b''))(
                next((k for k in range(0, len(data) - 1, 2) if data[k:k + 2] == b'\0\0'), len(data))),
        })

    def tick_clock(self):
        self.clock += 2500
        return self.clock

    @property
    def size(self):
        return self.virtual_size if self.virtual_size is not None else len(self.content)

    def execute(self, nodes, env):
        for node in nodes:
            if node[0] == 'repeat':
                for counter in range(1, self.evaluate(node[1], env)+1):
                    env[node[2]] = counter
                    try:
                        self.execute(node[3], env)
                    except NextIteration:
                        continue
                    except syntax.Broke:
                        break
            else:
                super().execute([node], env)

    def evaluate(self, value, env):
        call = re.fullmatch(r'([^ ()]+)\s*\((.*)\)', value.strip())
        if call:
            name, raw = call.groups()
            args = syntax.split_args(raw) if raw.strip() else []
            values = lambda: [self.evaluate(arg, env) for arg in args]
            if name.startswith(('繁星日志_', '播放器_')):
                return self.invoke(name, *values())
            if name == '进程_枚举':   # the shared process list (refreshed on every tick here: the clock moves 2.5 s per call)
                table = {7: 'FanXingBanZou.exe'} if self.present else {}
                self.assign(args[0].strip(), list(table.values()), env); self.assign(args[1].strip(), list(table.keys()), env)
                return len(table)
            if name == 'CreateFileW':
                self.opened.append(values())
                return -1 if self.fail == 'open' else 71
            if name == 'GetFileInformationByHandle_字节集':
                info = bytearray(52)
                struct.pack_into('<Q', info, 4, self.identity[0])
                struct.pack_into('<I', info, 28, self.identity[1])
                struct.pack_into('<II', info, 44, 0, self.identity[2])
                self.assign(args[1], bytes(info), env)
                return self.fail != 'info'
            if name == 'GetFileSizeEx_逻辑型':
                self.assign(args[1], self.size, env)
                return self.fail != 'size'
            if name == 'SetFilePointerEx_整数型':
                self.position = self.evaluate(args[1], env)
                assert values()[2:] == [0, 0]
                return self.fail != 'seek'
            if name == 'ReadFile_整数型':
                length = self.evaluate(args[2], env)
                self.reads.append((self.position, length))
                assert 0 <= length <= 65536
                # content holds the real suffix of an optionally virtual large file.
                start = self.position - (self.size-len(self.content))
                result = (b'x'*(-start)+self.content)[:length] if start<0 else self.content[start:start+length]
                if self.fail=='shortread':result=result[:len(result)//2]
                pointer_arg = syntax.split_args(args[1][args[1].index('(')+1:args[1].rindex(')')])[0]
                self.assign(pointer_arg, result, env)
                self.assign(args[3], len(result), env)
                return self.fail != 'read'
            if name == 'CloseHandle':
                self.closed.append(self.evaluate(args[0], env))
                return True
            if name == '分割文本W':
                data, separator = self.evaluate(args[0],env), self.evaluate(args[1],env)
                split = data.decode('utf-16le').rstrip('\0').split(separator.decode('utf-16le').rstrip('\0'))
                self.assign(args[2],[(x+'\0').encode('utf-16le') for x in split],env)
                return len(split)
        # Native exported array indices are one-based.
        indexed = re.fullmatch(r'([^\[\]]+)\[(.+)\]', value.strip())
        if indexed:
            return self.resolve(indexed[1],env)[self.evaluate(indexed[2],env)-1]
        return super().evaluate(value,env)

    def tick(self):
        before = len(self.closed)
        before_open=len(self.opened)
        result = self.invoke('酷狗或聚星直播伴侣_查询_正在播放的音乐')
        if len(self.opened)>before_open and self.fail != 'open':
            assert self.closed[before:] == [71], 'every successful open must close exactly once'
        return result


def event(song='歌手 - 歌曲', **kwargs):
    return json.dumps({'eventCode':0,'eventInfo':'id,-1,'+song+',264000',**kwargs},ensure_ascii=False,separators=(',',':')).encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--module',type=Path,default=Path(__file__).resolve().parents[4]/'模块/模块_电音助手.e~')
    parser.add_argument('--out',type=Path)
    opts=parser.parse_args()
    source=(opts.module/'代码/程序集_播放器和基调查询.static.e.txt').read_text('utf-8-sig')
    tests=[]
    def check(name,passed):
        tests.append({'name':name,'passed':bool(passed)})
        assert passed,name
    # 繁星日志用到的文件 DLL 已搬进精易模块：核对精易里对应命令的输出参数用传址
    dll=(opts.module.parent/'精易模块v9.3.5[源码].e~/DLL.e.txt').read_text('utf-8-sig')
    check('module_has_no_own_dll_file',not (opts.module/'DLL.e.txt').exists())
    for name,type_name in [('GetFileSizeEx_逻辑型','长整数型'),('ReadFile_整数型','整数型')]:
        block=dll[dll.index('.DLL命令 '+name):].split('\n.DLL命令 ',1)[0]
        check('DLL_output_parameter_uses_native_address:'+name, f', {type_name}, 传址,' in block)
        check('DLL_output_parameter_not_subroutine_reference:'+name, not re.search(r'^\s*\.参数 [^\n]*, 参考,',block,re.M))
    reader=Reader(source)
    for name, data, expected in [
        ('event_at_offset_zero',event(),event()),
        ('latest_complete_wins',event('A - B')+b'\r\n'+event('C - D'),event('C - D')),
        ('partial_latest_retains_previous_complete',event()+b'\r\n'+event('C - D')[:-3],event()),
        ('braces_escaped_quotes_and_nested_objects',event('A - B } \\"{', nested={'a':{'b':'\\"}'}}),event('A - B } \\"{', nested={'a':{'b':'\\"}'}})),
        ('invalid_complete_ignored',event()+b'{"eventCode":0,unquoted:1}',event()),
        ('incomplete_old_line_does_not_hide_new_complete_line',event()[:-5]+b'\r\n'+event('C - D'),event('C - D')),
        ('nonzero_event_ignored',b'{"eventCode":0.1,"eventInfo":"bad"}',b''),
        ('long_line_without_complete_event',b'x'*65536,b''),
    ]:
        check(name,reader.invoke('繁星日志_取完整事件',data)==expected)
    reader.content=event()
    check('actual_reader_formats_unicode_song',reader.tick()=='歌手 - 歌曲')
    check('unicode_path_and_share_read_write_delete',reader.opened[-1][0].decode('utf-16le').rstrip('\0')=='C:\\用户\\音乐😀\\FXbanzou\\log.txt' and reader.opened[-1][1:]==[-2147483648,7,0,3,128,0])
    reader.content+=b'\r\n'+event('新歌手 - 新歌')[:-4]
    check('append_partial_keeps_last_good_song',reader.tick()=='歌手 - 歌曲')
    reader.content=event()+b'\r\n'+event('新歌手 - 新歌')
    check('completing_append_updates_song',reader.tick()=='新歌手 - 新歌')
    reader.content=b'x'*70000+event('大歌手 - 大歌')
    check('large_growth_reads_only_tail',reader.tick()=='大歌手 - 大歌' and reader.reads[-1]==(reader.size-65536,65536))
    reader.content=b'x'*70000
    check('truncated_file_clears_previous_song',reader.tick()=='')
    reader.content=event('轮转前 - 歌曲')+b'x'*100
    reader.tick()
    reader.identity=(1,2,4)
    reader.content=b'x'*len(reader.content)
    check('same_size_rotation_clears_cache',reader.tick()=='')
    for changed_identity in [(2,2,4),(2,3,4)]:
        reader.content=event();reader.tick()
        reader.identity=changed_identity
        reader.content=b'x'*len(reader.content)
        check('creation_or_volume_rotation_clears_cache:'+str(changed_identity),reader.tick()=='')
    reader.content=event('退出前 - 歌曲')
    reader.tick()
    reader.present=False
    check('process_exit_clears_cache',reader.tick()=='' and reader.env['集_繁星日志_身份']==b'')
    reader.present=True
    reader.content=b'x'*100
    check('restart_does_not_restore_old_song',reader.tick()=='')
    reader.fail='';reader.content=event('不变 - 歌曲');reader.tick();reads=len(reader.reads)
    check('unchanged_log_not_read_again',reader.tick()=='不变 - 歌曲' and len(reader.reads)==reads)
    for fail in ('directory','open','info','size','seek','read','shortread'):
        reader.fail='';reader.content=event();reader.tick()
        reader.content+=b'\r\n'+event('新增 - 歌曲')   # the log changed, so the tail really is read again
        reader.fail=fail
        check('fail_closed_and_close_handle:'+fail,reader.tick()=='' and reader.env['集_繁星日志_歌名']=='')
    reader.fail='';reader.content=event('64位 - 歌曲');reader.virtual_size=2**33+123
    check('offset_above_32bit_uses_64bit_seek',reader.tick()=='64位 - 歌曲' and reader.reads[-1]==(2**33+123-65536,65536))
    reader.virtual_size=None
    reader.content=b''
    check('empty_file_clears_cache',reader.tick()=='')
    reader.content=event('边界前 - 歌曲');reader.tick()
    reader.content+=b'x'*65536+event('超长跨边界 - '+('歌'*23000))
    check('single_record_larger_than_window_keeps_last_complete_cache',reader.tick()=='边界前 - 歌曲' and reader.reads[-1][1]==65536)
    reader.content=event('边界后 - 歌曲')+b'x'*65000
    check('complete_event_within_window_is_found',reader.tick()=='边界后 - 歌曲')
    result={'checks':len(tests),'passed':sum(x['passed'] for x in tests),'tests':tests,'scope':'real source-extracted EPL with file/Win32/JSON substitutes; not EPL compile, Windows I/O, zyJson DLL or latency proof'}
    if opts.out:opts.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
