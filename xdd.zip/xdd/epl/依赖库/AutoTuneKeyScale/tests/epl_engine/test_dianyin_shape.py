#!/usr/bin/env python3
"""Windows 7：电音助手窗口按页面形状裁剪（执行宿主真实 EPL 源码）。

Windows 7 的 WebView2 不支持透明背景（DefaultBackgroundColor 的不透明度只能是 255），浏览器底色只能不透明，整块 420×198 的窗口
像贴在桌面上的一张截图。改为页面报出自己的形状（shape:宽,高,左,顶,右,底…，设备像素），宿主用 SetWindowRgn 把窗口裁成这个形状。

用 epl_machine 执行 程序集_Edge 里真实的 Edge_电音助手_置形状、Edge_电音助手_形状换算、Edge_电音助手_清形状、Edge_电音助手_取页面；
GDI 区域（CreateRectRgn、CombineRgn、DeleteObject、SetWindowRgn）、GetClientRect、IsWindow、日志与页面拼装是明确的替身：
区域按像素集合建模，记下每个区域句柄的去向（删掉、交给系统）。覆盖：
  · 区域是各块的并集，一次 SetWindowRgn（要重画），设好的区域交给系统、不再删除；块的临时区域都删掉，没有泄漏；
  · 页面算的客户区与窗口实际大小不同时按比例四舍五入换算；
  · 格式不对（不足一块、不是 4 的倍数、超过上限、宽高为 0、全是空块、不是数字）时不裁剪，建过的区域都删掉；
  · 能按像素透明（Windows 8 起）、窗口没打开或已销毁时什么也不做；SetWindowRgn 失败时删掉区域、记一条警告，不当成已裁剪；
  · 只在第一次裁剪成功时记一条日志；清形状只在裁剪过时把区域撤成整块（SetWindowRgn 传 0）；
  · 页面只在不能按像素透明时带 window.__DY_SHAPE__=1（只加一次），字体地址照旧替换；
  · 接线：收到 shape 交给 置形状；浏览器进程退出、改用别的运行时重建、换缩放时先撤形状；关窗复位；Windows 7 底色为胶囊色；
    页面只在 __DY_SHAPE__ 时报形状，样式带 body.dy-shape 规则；新增 EPL 代码的文本常量里没有半角双引号；
  · 同类写法：全工程与各模块里没有「SetWindowRgn 成功后又删区域」（区域此时归系统所有，删了是未定义行为）。
不是易语言编译，也不是 Windows 实机（GDI 区域、DWM 合成与 WebView2 子窗口的裁剪须在 Windows 7 上验收）。
用法（在依赖库根目录）：python3 tests/epl_engine/test_dianyin_shape.py
"""
from pathlib import Path
import json
import re
import epl_machine as em
import check as syntax

HERE = Path(__file__).resolve().parent
EPL = HERE.parents[3]                       # xhh/epl
PROJECT = EPL.parent                        # xhh
EDGE = EPL / '代码/集_Edge浏览器/程序集_Edge.static.e.txt'
HWND = 0x5150
FONT_VIRTUAL, FONT_REAL = 'http://xhh-font.invalid/', 'https://xhh-font.example/'


class Rect:
    def __init__(self):
        self.左边 = self.顶边 = self.右边 = self.底边 = 0


class Page:
    def __init__(self, html):
        self.html = html

    def 主播音效_电音页面(self):
        return self.html


class Shape(em.Machine):
    """宿主真实源码 + GDI 区域替身：区域句柄 → 像素集合。"""

    def __init__(self, transparent=False, client=(420, 198), window=HWND, alive=True, set_ok=True):
        super().__init__()
        text = EDGE.read_text('utf-8-sig')
        self.load_static(text, names={'Edge_电音助手_置形状', 'Edge_电音助手_形状换算', 'Edge_电音助手_清形状', 'Edge_电音助手_取页面'})
        for name in ('集_电音_可透明', '集_电音_窗口', '集_电音_有形状'):
            m = re.search(r'^\.程序集变量 ' + name + r', ([^,]+),', text, re.M)
            assert m, 'declaration missing: ' + name
            self.global_types[name] = (m.group(1).strip(), False)
            self.globals[name] = em.DEFAULTS[m.group(1).strip()]
        self.globals['集_电音_可透明'], self.globals['集_电音_窗口'] = transparent, window
        self.client, self.alive, self.set_ok = client, alive, set_ok
        self.regions, self.next_handle = {}, 0x9000
        self.deleted, self.given, self.set_calls, self.logs = [], [], [], []
        self.factories['精易_矩形'] = Rect
        self.constants.update({'修字体_虚拟地址': FONT_VIRTUAL, '日志级别_INFO': 1, '日志级别_WARNING': 4})
        self.builtins.update({
            'IsWindow': lambda h: 1 if (self.alive and h == HWND) else 0,
            'CreateRectRgn': self.create, 'CombineRgn': self.combine, 'DeleteObject': self.delete, 'SetWindowRgn': self.set_rgn,
            '写日志_本地': lambda text, level: self.logs.append((level, text)),
            '主进程音效页_字体地址': lambda: FONT_REAL,
            '子字节集替换': self.replace_bytes})
        self.raw_builtins['GetClientRect'] = self.client_rect
        self.global_types['窗口_音效'] = ('对象', False)
        self.globals['窗口_音效'] = Page('')

    # ---- GDI substitutes ----------------------------------------------------------------------------
    def create(self, l, t, r, b):
        self.next_handle += 1
        self.regions[self.next_handle] = {(x, y) for x in range(l, r) for y in range(t, b)}
        return self.next_handle

    def combine(self, dest, a, b, mode):
        assert mode == 2, 'only RGN_OR is used'
        for h in (dest, a, b):
            assert h in self.regions and h not in self.deleted and h not in self.given, ('combine on a dead region', h)
        self.regions[dest] = self.regions[a] | self.regions[b]
        return 3

    def delete(self, h):
        assert h in self.regions, ('delete of an unknown handle', h)
        assert h not in self.deleted, ('double delete', h)
        assert h not in self.given, ('deleting a region the system owns', h)
        self.deleted.append(h)
        return 1

    def set_rgn(self, hwnd, h, redraw):
        assert hwnd == HWND and redraw is True, (hwnd, redraw)
        self.set_calls.append(h)
        if h == 0:
            return 1
        assert h in self.regions and h not in self.deleted, ('SetWindowRgn with a dead region', h)
        if not self.set_ok:
            return 0
        self.given.append(h)
        return 1

    def client_rect(self, env, args, raws):
        target = self.ev(args[1], env)
        target.左边, target.顶边, (target.右边, target.底边) = 0, 0, self.client
        return True

    @staticmethod
    def replace_bytes(data, old, new=b'', start=None, count=None):
        return data.replace(old, new, -1 if not count else count)

    # ---- helpers ------------------------------------------------------------------------------------
    def shape(self, text):
        self.invoke(self.subs['Edge_电音助手_置形状'], [('lit', text)], {}, None)

    def clear(self):
        self.invoke(self.subs['Edge_电音助手_清形状'], [], {}, None)

    def window_region(self):
        live = [h for h in self.set_calls if h != 0]
        return self.regions[self.set_calls[-1]] if self.set_calls and self.set_calls[-1] != 0 else (None if not live else None)

    def leaks(self):
        return [h for h in self.regions if h not in self.deleted and h not in self.given]


def pixels(rects):
    return {(x, y) for l, t, r, b in rects for x in range(l, r) for y in range(t, b)}


def message(w, h, rects):
    return ','.join(str(v) for v in [w, h] + [n for r in rects for n in r])


def main():
    checks = []

    def check(name, passed):
        checks.append(name)
        assert passed, name

    rects = [(0, 0, 10, 4), (8, 2, 20, 6), (30, 30, 31, 31)]
    m = Shape()
    m.shape(message(420, 198, rects))
    check('union_of_blocks_set_once_with_redraw', len(m.set_calls) == 1 and m.regions[m.set_calls[0]] == pixels(rects))
    check('region_handed_to_system_and_never_deleted', m.given == m.set_calls and m.set_calls[0] not in m.deleted)
    check('temporary_block_regions_deleted_no_leak', not m.leaks() and len(m.deleted) == len(rects))
    check('shaped_flag_and_one_info_log', m.globals['集_电音_有形状'] is True and [l for l, _ in m.logs] == [1] and '块数=3' in m.logs[0][1])
    m.shape(message(420, 198, rects[:1]))
    check('second_shape_replaces_without_touching_the_owned_one', len(m.set_calls) == 2 and m.regions[m.set_calls[1]] == pixels(rects[:1])
          and not m.leaks() and len(m.logs) == 1)
    m.clear()
    check('clear_resets_to_whole_window', m.set_calls[-1] == 0 and m.globals['集_电音_有形状'] is False and not m.leaks())
    calls = len(m.set_calls)
    m.clear()
    check('clear_without_shape_does_nothing', len(m.set_calls) == calls)
    m.shape(message(420, 198, rects))
    check('log_again_after_a_clear', [l for l, _ in m.logs] == [1, 1])

    m = Shape(client=(840, 396))                 # 页面按 1 倍算、窗口实际 2 倍：按比例换算
    m.shape(message(420, 198, [(1, 1, 3, 2)]))
    check('scaled_when_page_and_window_sizes_differ', m.regions[m.set_calls[0]] == pixels([(2, 2, 6, 4)]))
    m = Shape(client=(525, 248))                 # 1.25 倍：四舍五入
    m.shape(message(420, 198, [(1, 1, 3, 3)]))
    check('scaled_with_rounding', m.regions[m.set_calls[0]] == pixels([(1, 1, 4, 4)]))

    for bad in ('', '420,198', '420,198,1,2,3', '420,198,1,2,3,4,5', 'abc', '0,198,0,0,1,1', '420,0,0,0,1,1',
                '420,198,5,5,5,9,9,9,1,9', message(420, 198, [(0, 0, 1, 1)] * 20001)):
        m = Shape()
        m.shape(bad)
        check('malformed_ignored:' + bad[:24], not m.set_calls and not m.leaks() and m.globals['集_电音_有形状'] is False)
    m = Shape()
    m.shape(message(420, 198, [(0, 0, 1, 1)] * 20000))
    check('upper_limit_inclusive', len(m.set_calls) == 1 and not m.leaks())

    for name, kw in (('transparent_windows_8_plus', {'transparent': True}), ('no_window', {'window': 0}), ('destroyed_window', {'alive': False}),
                     ('zero_client', {'client': (0, 0)})):
        m = Shape(**kw)
        m.shape(message(420, 198, rects))
        check('nothing_when_' + name, not m.set_calls and not m.regions)
    m = Shape(set_ok=False)
    m.shape(message(420, 198, rects))
    check('set_failure_deletes_region_and_warns', len(m.set_calls) == 1 and m.set_calls[0] in m.deleted and not m.leaks()
          and m.globals['集_电音_有形状'] is False and [l for l, _ in m.logs] == [4])

    html = '<html><head><style>@font-face{src:url(' + FONT_VIRTUAL + 'a.woff2)}</style><script>window.__DY_WIN__=1;window.__XHH_LANG=\'zh-Hans\';</script></head></html>'
    for transparent in (False, True):
        m = Shape(transparent=transparent)
        m.globals['窗口_音效'] = Page(html)
        page = m.invoke(m.subs['Edge_电音助手_取页面'], [], {}, None)
        page = page if isinstance(page, bytes) else bytes(page)
        flag = page.count(b'window.__DY_WIN__=1;window.__DY_SHAPE__=1;')
        check('page_flag_only_when_not_transparent:%s' % transparent, flag == (0 if transparent else 1) and page.count(b'__DY_SHAPE__') == flag
              and FONT_REAL.encode() in page and FONT_VIRTUAL.encode() not in page)

    # ---- 执行真实的消息分发与进程崩溃回调：shape 命令从网页消息里正确取出参数并裁剪；别的来源不理；浏览器进程退出时撤掉形状，渲染进程退出时保留
    class Route(Shape):
        def __init__(self):
            super().__init__()
            text = EDGE.read_text('utf-8-sig')
            self.load_static(text, names={'Edge_电音助手_收到消息', 'Edge_电音助手_来源', 'Edge_电音助手_进程崩溃', 'Edge_电音助手_关闭透明'})
            for name in ('集_电音_透明',):
                kind = re.search(r'^\.程序集变量 ' + name + r', ([^,]+),', text, re.M).group(1).strip()
                self.global_types[name], self.globals[name] = (kind, False), em.DEFAULTS[kind]
            self.constants.update({'WV进程_浏览器进程退出': 0, 'WV进程_渲染进程退出': 1})

        def message(self, text, origin='https://xhh-dianyin.example/index.html'):
            self.invoke(self.subs['Edge_电音助手_收到消息'], [('lit', 7), ('lit', text), ('lit', '"' + text + '"'), ('lit', origin)], {}, None)

    r = Route()
    r.message('XHHDY:shape:' + message(420, 198, [(0, 0, 3, 2), (5, 5, 6, 6)]))
    check('dispatch:shape_message_reaches_set_shape', len(r.set_calls) == 1 and r.regions[r.set_calls[0]] == pixels([(0, 0, 3, 2), (5, 5, 6, 6)]))
    r.message('XHHDY:shape:' + message(420, 198, [(0, 0, 9, 9)]), origin='https://evil.example/index.html')
    r.message('XHHXX:shape:' + message(420, 198, [(0, 0, 9, 9)]))
    check('dispatch:other_origin_or_prefix_ignored', len(r.set_calls) == 1)
    r.invoke(r.subs['Edge_电音助手_进程崩溃'], [('lit', 7), ('lit', 1), ('lit', 0)], {}, None)
    check('crash:renderer_exit_keeps_shape', r.set_calls[-1] != 0 and r.globals['集_电音_有形状'] is True)
    r.invoke(r.subs['Edge_电音助手_进程崩溃'], [('lit', 7), ('lit', 0), ('lit', 0)], {}, None)
    check('crash:browser_exit_restores_whole_window', r.set_calls[-1] == 0 and r.globals['集_电音_有形状'] is False and not r.leaks())

    # ---- 接线（真实源码）
    text = EDGE.read_text('utf-8-sig').replace('\r\n', '\n')
    code = lambda name: '\n'.join(re.sub(r"\s+'.*$", '', l) for l in syntax.section(text, name).split('\n')
                                  if l.strip() and not l.lstrip().startswith(("'", '.局部变量', '.参数', '.子程序')))
    received = code('Edge_电音助手_收到消息')
    check('wired:shape_message_goes_to_set_shape', '.判断 (等于 (局_命令, “shape”))\n    Edge_电音助手_置形状 (局_参数)' in received)
    crash = code('Edge_电音助手_进程崩溃')
    check('wired:browser_exit_clears_shape', '.如果真 (等于 (进程类型, #WV进程_浏览器进程退出))' in crash
          and crash.index('Edge_电音助手_清形状 ()') > crash.index('#WV进程_浏览器进程退出'))
    rebuild = code('Edge_电音助手_重建')
    check('wired:rebuild_clears_shape_before_destroy', 0 <= rebuild.find('Edge_电音助手_清形状 ()') < rebuild.find('集_电音_浏览器.销毁 ()'))
    proc = code('Edge_电音助手_窗口过程')
    dpi = proc[proc.index('.如果真 (并且 (等于 (消息, 736), 不等于 (参数2, 0)))'):]
    check('wired:dpi_change_clears_shape_before_resize', 0 <= dpi.find('Edge_电音助手_清形状 ()') < dpi.find('SetWindowPos (句柄, 0,'))
    check('wired:close_resets_flag', '赋值 (集_电音_有形状, 假)' in code('Edge_电音助手_关闭'))
    check('wired:windows7_background_is_the_pill_colour', '集_电音_浏览器.置背景色 (取颜色值 (90, 160, 243), 集_电音_可透明)' in code('Edge_电音助手_创建浏览器'))
    new_code = '\n'.join(syntax.section(text, n) for n in ('Edge_电音助手_置形状', 'Edge_电音助手_形状换算', 'Edge_电音助手_清形状', 'Edge_电音助手_取页面'))
    check('no_ascii_double_quote_inside_epl_strings', not any('"' in s for s in re.findall(r'“([^”]*)”', new_code)))
    # 同类写法（全工程与各模块）：SetWindowRgn 成功后区域归系统所有，不能再删；不许出现「设区域」紧跟着无条件「删区域」
    stale = []
    for f in sorted(EPL.rglob('*.e.txt')):
        lines = [re.sub(r"\s+'.*$", '', l).strip() for l in f.read_text('utf-8-sig', errors='replace').splitlines()]
        lines = [l for l in lines if l and not l.startswith("'")]
        for a, b in zip(lines, lines[1:]):
            m = re.fullmatch(r'SetWindowRgn \([^,]+, ([^,]+), [^)]+\)', a)
            if m and m.group(1) != '0' and b == 'DeleteObject (' + m.group(1) + ')':
                stale.append(f.name)
    check('no_region_deleted_after_a_successful_SetWindowRgn ' + str(stale), not stale)
    js = (PROJECT / 'js/dianyinAssistant.js').read_text(encoding='utf-8')
    css = (PROJECT / 'css/dianyinAssistant.css').read_text(encoding='utf-8')
    check('page:shape_only_behind_flag', 'var SHAPE = !!window.__DY_SHAPE__;' in js and "post('shape:' + msg)" in js
          and "if (!SHAPE) { post('ready'); return; }" in js and 'if (!SHAPE || !shape.img) return;' in js)
    check('page:styles_for_windows7', 'body.dy-shape .dy-bubble { image-rendering: pixelated; }' in css and 'body.dy-shape .dy-menu { box-shadow: none; }' in css
          and 'background: transparent;' in css)
    print(json.dumps({'checks': len(checks), 'passed': len(checks)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
