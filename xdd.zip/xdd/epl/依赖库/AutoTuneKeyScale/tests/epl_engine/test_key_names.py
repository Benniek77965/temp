#!/usr/bin/env python3
"""Execute the production EPL key- and scale-name code: standard English names inside the program, the old Chinese values on the wire.

Not an EPL compiler: epl_machine runs the real source (程序集_机架联动引擎, 程序集_多语言, the server's Web服务) with EPL's
types, and 文本型 as GBK bytes (lengths, cuts and positions count bytes; what GBK lacks becomes '?'), so a name such as
D-平行 is cut the way EPL cuts it. The server and every released client exchange the old Chinese values (C, D-平行 … B,
the server writing a flat as -平行 and Gb as F-锋利); this checks that the program shows and keeps standard names
(major Db / Ab, minor C# / G#, the rest alike) and still sends exactly what older clients sent, that the server stores
exactly what it stored before for those values, and that it now also takes standard names (a client sending Db used to
be stored as D) and refuses what it cannot read (it used to store the first character).
Scales the same way: Major, Minor, Chromatic inside the program and in every language, 大调 / 小调 on the wire (the
server also takes Minor now). Arabic: EXUI lays text out left to right only, so both segments are written “value :label”;
with python-bidi installed the Unicode bidirectional algorithm checks that read right to left the line gives the key
label, the key, the scale label, the scale (the old “label: value” order for the rack line would put Major before its label).
"""
from pathlib import Path
from types import SimpleNamespace
import json
import re
import unicodedata
import epl_machine as em

HERE = Path(__file__).resolve().parent
EPL = HERE.parents[3]
MODULE = EPL / '模块/模块_电音助手.e~'
ENGINE = MODULE / '代码/程序集_机架联动引擎.static.e.txt'
LANG = MODULE / '代码/程序集_多语言.static.e.txt'
QUERY = MODULE / '代码/类_基调查询.class.e.txt'
ASSISTANT = MODULE / '代码/类_电音助手.class.e.txt'
SERVER = EPL / '服务端/服务端_电音基调/代码/Web服务.static.e.txt'
W = lambda text: (text + '\0').encode('utf-16-le')
LEGACY = ['C', 'D-平行', 'D', 'E-平行', 'E', 'F', 'F-锋利', 'G', 'A-平行', 'A', 'B-平行', 'B']
MAJOR = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B']
MINOR = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'G#', 'A', 'Bb', 'B']
OPTIONS = ['C', 'C#/Db', 'D', 'D#/Eb', 'E', 'F', 'F#/Gb', 'G', 'G#/Ab', 'A', 'A#/Bb', 'B']


def strip_w(data, standard=None):
    """精易 删除Unicode结尾空白字节: cut at the first zero unit; with 标准Unicode编码 put one terminator back; {} when it starts with one."""
    data = bytes(data)
    if len(data) < 2:
        return b''
    i = 0
    while i <= len(data) - 2 and data[i:i + 2] != b'\0\0':
        i += 2
    if i == 0 or i > len(data):
        return b''
    return data[:i] + (b'\0\0' if standard else b'')


def client():
    m = em.Machine()
    m.load_static(ENGINE.read_text('utf-8-sig'), names={'基调名_音高', '基调名_英文', '基调名_标准', '基调名_旧名', '机架引擎_规范基调',
                                                        '音阶名_标准', '音阶名_旧名'})
    m.load_static(LANG.read_text('utf-8-sig'), names={'多语言_基调显示W', '多语言_基调行W', '多语言_音阶显示W', '多语言_机架基调行W', '多语言_是否简体',
                                                      '多语言_是否阿拉伯语', '多语言_文字W', '多语言_文字W_语种', '多语言_去冒号W'})
    m.language = 1                                           # 1 简体中文 … 14 ar (多语言_语言代码)
    m.builtins.update({'多语言_序号': lambda: m.language, '删除Unicode结尾空白字节': strip_w})
    return m


def server():
    m = em.Machine()
    m.load_static(SERVER.read_text('utf-8-sig'), names={'基调_用户添加'})
    m.factories['歌曲信息'] = SimpleNamespace
    m.stored = []
    m.builtins.update({'调试输出': lambda *a: None, '编码_usc2到ansi': lambda t: t,
                       '电音基调库表_添加W': lambda kind, title, singer, key, soft, user: m.stored.append(key)})
    return m


def main():
    checks = []

    def check(name, passed):
        checks.append(name)
        assert passed, name

    m = client()
    run = lambda name, *values: m.invoke(m.subs[name], [('lit', v) for v in values], {}, None)

    # ---- one table: any spelling to a pitch, a pitch to the standard name ----------------------------------
    pitches = {'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'D#': 3, 'Eb': 3, 'E': 4, 'Fb': 4, 'E#': 5, 'F': 5, 'F#': 6, 'Gb': 6,
               'G': 7, 'G#': 8, 'Ab': 8, 'A': 9, 'A#': 10, 'Bb': 10, 'B': 11, 'Cb': 11, 'B#': 0,
               'db': 1, 'f#': 6, ' Bb ': 10, 'C#m': 1, 'Bbm': 10, 'Am': 9, 'C#/Db': 1, 'G#/Ab': 8, 'A#/Bb': 10,
               'D-平行': 1, 'F-锋利': 6, 'B-平行': 10, 'E平行': 3, 'F锋利': 6}
    check('pitch_of_every_spelling', all(run('基调名_音高', k) == p for k, p in pitches.items()))
    check('pitch_of_unknown_is_minus_one', all(run('基调名_音高', k) == -1 for k in
          ('', ' ', 'H', 'C##', 'Cbb', '123', 'C major', 'D-flat', 'D?', 'F?', 'D♭', 'F♯', 'C-锋利2', 'm', '/Db')))
    check('standard_names_major_and_minor', [run('基调名_英文', p, False) for p in range(12)] == MAJOR
          and [run('基调名_英文', p, True) for p in range(12)] == MINOR and run('基调名_英文', 12, False) == '' and run('基调名_英文', -1, True) == '')
    check('standard_names_are_plain_ascii', all(n.isascii() for n in MAJOR + MINOR + OPTIONS))

    # ---- what the program keeps: from the server's values, the options, older caches ----------------------
    for scale, names in (('大调', MAJOR), ('小调', MINOR)):
        check('server_values_become_standard_' + scale, [run('基调名_标准', k, scale) for k in LEGACY] == names)
        check('options_become_standard_' + scale, [run('基调名_标准', k, scale) for k in OPTIONS] == names)
    check('standard_names_follow_the_scale', run('基调名_标准', 'Db', '小调') == 'C#' and run('基调名_标准', 'C#', '大调') == 'Db'
          and run('基调名_标准', 'Abm', '') == 'G#' and run('基调名_标准', 'G#', 'minor') == 'G#' and run('基调名_标准', 'Gb', '大调') == 'F#')
    check('chromatic_and_unknown_kept', run('基调名_标准', ' chromatic ', '') == 'Chromatic' and run('基调名_标准', ' H ', '大调') == 'H'
          and run('基调名_标准', '', '') == '')

    # ---- on the wire: exactly what older clients sent -----------------------------------------------------
    check('wire_names_from_any_spelling', all(run('基调名_旧名', k) == LEGACY[p] for k, p in pitches.items()))
    check('wire_name_of_unknown_is_empty', all(run('基调名_旧名', k) == '' for k in ('', 'H', 'C##', 'Chromatic')))
    for scale in ('大调', '小调'):
        check('wire_round_trip_' + scale, all(run('基调名_旧名', run('基调名_标准', k, scale)) == k for k in LEGACY))

    # ---- the rack link: the plug-in gets numbers; the status shows standard names ----------------------------
    norm = lambda key, scale, shift=0: m.out('机架引擎_规范基调', (key, scale, shift), (('键', '整数型'), ('阶', '整数型'), ('显示', '文本型')))
    check('rack_numbers_unchanged', all(norm(k, s)[:3] == (True, p, i) for p, k in enumerate(LEGACY) for i, s in enumerate(('大调', '小调'))))
    check('rack_shows_standard_names', [norm(k, '大调')[3] for k in LEGACY] == MAJOR and [norm(k, '小调')[3] for k in LEGACY] == MINOR
          and norm('C', '小调', 1)[3] == 'C#' and norm('C', '大调', 1)[3] == 'Db' and norm('C', 'chromatic')[3] == 'Chromatic')

    # ---- display: standard names in every language ---------------------------------------------------------
    show = lambda k: run('多语言_基调显示W', k)
    check('display_keeps_standard_names', all(show(k) == W(k) for k in MAJOR + MINOR + OPTIONS))
    check('display_turns_old_values_into_standard_names', [show(k) for k in LEGACY] == [W(k) for k in MAJOR])
    lang = LANG.read_text('utf-8-sig').replace('\r', '')
    shown = re.search(r'^\.子程序 多语言_基调显示W,[^\n]*\n(.*?)(?=^\.子程序 |\Z)', lang, re.M | re.S).group(1)
    check('display_is_the_same_in_every_language', '多语言_是否简体' not in shown and '多语言_序号' not in shown)
    check('simplified_chinese_key_line', run('多语言_基调行W', 'C#', 'Minor') == W('基调：C#     音阶：Minor')
          and run('多语言_基调行W', 'D-平行', '大调') == W('基调：Db     音阶：Major'))

    # ---- scale names: Major / Minor / Chromatic inside and on screen, 大调 / 小调 on the wire ------------------
    standard = {'Major': 'Major', ' major ': 'Major', 'MAJOR': 'Major', '大调': 'Major', 'Minor': 'Minor', 'minor': 'Minor', '小调': 'Minor',
                'Chromatic': 'Chromatic', 'chromatic': 'Chromatic', '半音阶': 'Chromatic', ' Dorian ': 'Dorian', '': ''}
    check('scale_names_standard', all(run('音阶名_标准', k) == v for k, v in standard.items()))
    check('scale_wire_names', [run('音阶名_旧名', k) for k in ('Major', 'major', '大调', 'Minor', ' MINOR ', '小调', 'Chromatic', 'Dorian', '')]
          == ['大调', '大调', '大调', '小调', '小调', '小调', '', '', ''])
    check('scale_wire_round_trip', all(run('音阶名_旧名', run('音阶名_标准', k)) == k for k in ('大调', '小调')))
    for scale, names in (('Major', MAJOR), ('Minor', MINOR), (' minor ', MINOR)):
        check('key_spelling_follows_english_scale_' + scale.strip(), [run('基调名_标准', k, scale) for k in LEGACY] == names)
    scale_show = lambda k: run('多语言_音阶显示W', k)
    check('scale_display_is_standard_english', [scale_show(k) for k in ('Major', 'Minor', 'Chromatic', '大调', '小调', ' minor ')]
          == [W(x) for x in ('Major', 'Minor', 'Chromatic', 'Major', 'Minor', 'Minor')])
    shown_scale = re.search(r'^\.子程序 多语言_音阶显示W,[^\n]*\n(.*?)(?=^\.子程序 |\Z)', lang, re.M | re.S).group(1)
    check('scale_display_is_the_same_in_every_language', not re.search('多语言_(是否简体|序号|文字W)', shown_scale))

    # ---- Arabic: both segments “value :label”, read right to left label → value (real Arabic labels) ------------
    m.language = 14
    label = lambda n: bytes(run('多语言_去冒号W', run('多语言_文字W', n))).decode('utf-16-le')
    key_label, scale_label = label(5), label(6)
    text = lambda w: bytes(w).decode('utf-16-le').split('\0')[0]
    line = text(run('多语言_基调行W', 'Db', 'Major'))
    snapshot = SimpleNamespace(实际基调='Db', 实际音阶='Major', 实际移调=2, 已锁定=False, 实际歌名W=W('歌'), 音乐名W=W('歌'), 基调='Db', 音阶='Major', 移调=2)
    rack = text(run('多语言_机架基调行W', snapshot))
    check('arabic_labels_are_arabic', all('\u0600' <= c <= '\u06ff' or c == ' ' for c in key_label + scale_label) and key_label and scale_label)
    check('arabic_key_line_value_then_label', line == 'Major :' + scale_label + '     Db :' + key_label)
    check('arabic_rack_line_value_then_label', rack == 'Major :' + scale_label + '   Db（+2） :' + key_label)
    m.language = 1
    try:
        from bidi import get_display
    except ImportError:
        get_display = None
    bidi_note = 'checked with python-bidi' if get_display else 'skipped: python-bidi not installed'
    if get_display:
        def reads_right_to_left(logical, *parts):
            """Drawn left to right (EXUI), the parts appear from right to left in the given order."""
            visual = get_display(logical, base_dir='L')
            rtl = lambda part: any(unicodedata.bidirectional(c) in ('R', 'AL') for c in part)     # an Arabic run is drawn reversed
            spots = [visual.index(p[::-1] if rtl(p) else p) for p in parts]
            return spots == sorted(spots, reverse=True)
        check('arabic_key_line_reads_label_value_label_value', reads_right_to_left(line, key_label, 'Db', scale_label, 'Major'))
        check('arabic_rack_line_reads_label_value_label_value', reads_right_to_left(rack, key_label, 'Db（+2）', scale_label, 'Major'))
        old_rack = scale_label + ': Major   Db（+2） :' + key_label           # the old “label: value” order with an English scale
        check('old_rack_order_would_put_the_value_first', not reads_right_to_left(old_rack, key_label, 'Db（+2）', scale_label, 'Major'))

    # ---- the server: the same rows for older clients, standard names taken, unreadable ones refused ----------
    s = server()

    def add(tone, scale):
        before = len(s.stored)
        reply = s.invoke(s.subs['基调_用户添加'], [('lit', SimpleNamespace(soft=1, userName='u', 歌手W=W('甲'), 歌名W=W('乙'), tone=tone, scale=scale))], {}, None)
        return reply, (s.stored[-1] if len(s.stored) > before else None)
    old_rows = {'C': 'C', 'D-平行': 'Db', 'D': 'D', 'E-平行': 'Eb', 'E': 'E', 'F': 'F', 'F-锋利': 'Gb', 'G': 'G', 'A-平行': 'Ab', 'A': 'A', 'B-平行': 'Bb', 'B': 'B'}
    for scale, suffix in (('大调', ''), ('小调', 'm')):
        check('server_rows_for_older_clients_' + scale, all(add(k, scale) == ('ok', row + suffix) for k, row in old_rows.items()))
        check('server_rows_for_this_client_' + scale, all(add(run('基调名_旧名', n), scale) == ('ok', old_rows[run('基调名_旧名', n)] + suffix)
                                                         for n in (MAJOR if suffix == '' else MINOR)))
    check('server_takes_standard_names', [add(k, sc)[1] for k, sc in (('Db', '大调'), ('C#', '小调'), ('F#', '大调'), ('Gb', '小调'), ('bb', '小调'), ('c', '大调'))]
          == ['Db', 'C#m', 'F#', 'Gbm', 'Bbm', 'C'])
    check('server_refuses_what_it_cannot_read', all(add(k, '大调') == ('', None) for k in ('H', 'C##', '1', 'C-锋利', 'X-平行', 'Cbb', '平行')))
    check('server_takes_english_scale_names', [add(k, sc)[1] for k, sc in (('Db', 'Minor'), ('C', ' minor '), ('C', 'Major'), ('G', 'MINOR'))]
          == ['Dbm', 'Cm', 'C', 'Gm'])
    check('server_rows_for_this_client_english_scales', all(add(run('基调名_旧名', n), run('音阶名_旧名', sc)) == ('ok', old_rows[run('基调名_旧名', n)] + suffix)
                                                            for sc, suffix, names in (('Major', '', MAJOR), ('Minor', 'm', MINOR)) for n in names))

    # ---- wiring: converted where values come in and go out ----------------------------------------------------
    engine = ENGINE.read_text('utf-8-sig').replace('\r', '')
    check('server_reply_converted', re.search(r"    赋值 \(局_音阶, 文本_取右边 \(局_结果, “ ”, , \)\)\n    赋值 \(局_音阶, 音阶名_标准 \(局_音阶\)\)[^\n]*\n"
                                              r'    赋值 \(局_基调, 基调名_标准 \(局_基调, 局_音阶\)\)', engine) is not None)   # the key is spelled for the converted scale
    check('old_cache_converted', re.search(r"“scale”, \)\)\n赋值 \(集_机架_快照\.音阶, 音阶名_标准 \(集_机架_快照\.音阶\)\)[^\n]*\n"
                                           r'赋值 \(集_机架_快照\.基调, 基调名_标准 \(集_机架_快照\.基调, 集_机架_快照\.音阶\)\)', engine) is not None)
    query = QUERY.read_text('utf-8-sig').replace('\r', '')
    check('sent_as_wire_names', query.count('zyJson.置文本 (“tone”, 基调名_旧名 (') == 2 and not re.search(r'置文本 \(“tone”, (参_)?基调\)', query))
    ui = ASSISTANT.read_text('utf-8-sig').replace('\r', '')
    check('edit_submits_standard_names', re.search(r"^赋值 \(局_调, 基调名_标准 \(局_调, 局_阶\)\)(  '[^\n]*)?\n返回 \(机架引擎_提交编辑 \(参_歌曲W, 局_调, 局_阶, 参_自动\)\)", ui, re.M) is not None)
    check('edit_preselects_by_pitch', '等于 (基调名_音高 (局_项[i]), 基调名_音高 (局_快照.基调))' in ui)
    check('edit_preselects_scale_by_standard_name', '等于 (音阶名_标准 (局_项[i]), 音阶名_标准 (局_快照.音阶))' in ui)
    check('server_reply_scale_converted', re.search(r'    赋值 \(局_音阶, 文本_取右边 \(局_结果, “ ”, , \)\)\n    赋值 \(局_音阶, 音阶名_标准 \(局_音阶\)\)', engine) is not None)
    check('old_cache_scale_converted', re.search(r'“scale”, \)\)\n赋值 \(集_机架_快照\.音阶, 音阶名_标准 \(集_机架_快照\.音阶\)\)', engine) is not None)
    check('scale_sent_as_wire_names', query.count('zyJson.置文本 (“scale”, 音阶名_旧名 (') == 2 and not re.search(r'置文本 \(“scale”, (参_)?音阶\)', query))
    check('rack_records_english_scale', '选择 (等于 (局_音阶编号, 1), “Minor”, “Major”)' in engine)
    check('scale_options_resource', (MODULE / '资源/常量_音阶.txt').read_bytes() == b'Major\r\nMinor')
    resource = (MODULE / '资源/常量_基调.txt').read_bytes()
    check('key_options_resource', resource.decode('gbk').split('\r\n') == OPTIONS)
    code = '\n'.join(re.sub(r"\s'.*$", '', l) for l in (engine + lang + query + ui).split('\n') if not l.lstrip().startswith(("'", '.子程序', '.参数', '.程序集')))
    chinese = re.findall(r'“[^”]*(?:平行|锋利)[^”]*”', code)
    check('chinese_key_names_only_on_the_wire', sorted(set(chinese)) == ['“-平行”', '“-锋利”', '“C|D-平行|D|E-平行|E|F|F-锋利|G|A-平行|A|B-平行|B”', '“平行”', '“锋利”'])
    check('no_unicode_accidentals_in_code', not re.search('“[^”]*[♭♯][^”]*”', code))
    allowed = {'音阶名_标准', '音阶名_旧名', '基调名_标准', '机架引擎_规范基调'}
    users = set()
    for source in (engine, lang, query, ui):
        for sub in re.finditer(r'^\.子程序 ([^,\n]+)[^\n]*\n(.*?)(?=^\.子程序 |\Z)', source, re.M | re.S):
            body = '\n'.join(re.sub(r"\s'.*$", '', l) for l in sub.group(2).split('\n') if not l.lstrip().startswith(("'", '.参数', '.局部变量')))
            if re.search('“(大调|小调|半音阶)”', body):
                users.add(sub.group(1).strip())
    check('chinese_scale_names_only_where_old_values_are_read_or_sent', users == allowed)

    print(json.dumps({'checks': len(checks), 'passed': len(checks), 'bidi': bidi_note}, ensure_ascii=False))


if __name__ == '__main__':
    main()
