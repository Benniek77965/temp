#!/usr/bin/env python3
"""Execute the real 机架联动_准备桥: the bridge DLL (about 5 MB) is put in place and checked without being read into memory.

Not an EPL compiler and not a Windows run: epl_machine runs the real host source (机架联动_准备桥, 机架联动_核对桥文件,
机架联动_桥文件相符, 机架联动_复制桥文件, 机架联动_桥句柄可用, 机架联动_准备失败, 机架联动_准备记日志) over a file system that
keeps Windows sharing rules (an open is refused when it asks for access another handle does not share, or shares less
than another handle holds). The fetch (机架联动_取桥数据: signed manifest, tested in companion/test_host_bridge_download)
hands over the downloaded DLL's path with the size and SHA-256 the signed manifest vouches for. Checked: the DLL is
copied 64 KB at a time and every buffer stays at 64 KB; the file that is loaded is checked against the signed size and
SHA-256 while a read-only handle that denies writing and deleting is held, and stays held while it is loaded; a copy
that does not come out as signed (a source changed after the check, longer than signed, a short write, a failed read)
is never loaded; a target someone else holds, or one that is a link, is not written; every other handle is closed.
"""
from pathlib import Path
import hashlib
import json
import re
import struct
import epl_machine as em

HERE = Path(__file__).resolve().parent
HOST = HERE.parents[3] / '代码/集_基础支持/机架联动_宿主.static.e.txt'
NAMES = {'机架联动_准备桥', '机架联动_核对桥文件', '机架联动_桥文件相符', '机架联动_复制桥文件', '机架联动_桥句柄可用',
         '机架联动_准备失败', '机架联动_准备记日志'}
RUNTIME = 'D:\\小黄鸭\\plugin\\'
TARGET = RUNTIME + 'keyscale_rack_bridge.dll'
SOURCE = 'D:\\小黄鸭\\keyscale_rack_bridge\\keyscale_rack_bridge.dll'
READ, WRITE = 0x80000000, 0x40000000
PIECE = 65536
BRIDGE = bytes(range(256)) * 20000 + b'end'        # 5,120,003 bytes: 78 whole pieces and a short last one
W = lambda text: text.encode('utf-16-le') + b'\0\0'


def unw(data):
    return bytes(data).decode('utf-16-le').split('\0')[0]


class Files:
    """Files and handles with Windows sharing: READ / WRITE access against FILE_SHARE_READ (1) / FILE_SHARE_WRITE (2)."""
    def __init__(self):
        self.files, self.handles, self.next, self.opens = {}, {}, 700, []

    def open(self, path, access, share, disposition, flags=0):
        access &= 0xFFFFFFFF
        self.opens.append((path, access, share, disposition, flags))
        for h in self.handles.values():
            if h['path'] == path and ((access & READ and not h['share'] & 1) or (access & WRITE and not h['share'] & 2)
                                      or (h['access'] & READ and not share & 1) or (h['access'] & WRITE and not share & 2)):
                return -1                                     # ERROR_SHARING_VIOLATION
        if path not in self.files:
            if disposition != 4:
                return -1                                     # OPEN_EXISTING: not there
            self.files[path] = {'data': bytearray(), 'attrs': 32, 'links': 1}
        self.next += 1
        self.handles[self.next] = {'path': path, 'access': access, 'share': share, 'pos': 0}
        return self.next

    def pinned(self, path):
        """A read-only handle on path that denies writing and deleting (share mode FILE_SHARE_READ only) is open."""
        return any(h['path'] == path and h['access'] == READ and h['share'] == 1 for h in self.handles.values())


class Host(em.Machine):
    def __init__(self, fs, size=len(BRIDGE), digest=hashlib.sha256(BRIDGE).hexdigest(), fetched=True, fetch_error=0):
        super().__init__()
        text = HOST.read_text('utf-8-sig')
        self.load_static(text, names=NAMES)
        for m in re.finditer(r'^\.程序集变量 ([^,]+), ([^,]+), [^,]*, ("[^"]*")?', text.replace('\r', ''), re.M):
            name, kind = m.group(1).strip(), m.group(2).strip()
            if name.startswith(('集_机架桥', '集_机架准备', '集_机架相符')):
                self.global_types[name] = (kind, False)
                self.globals[name] = self.new_value(kind, None)
        self.fs, self.size, self.digest, self.fetched, self.fetch_error = fs, size, digest, fetched, fetch_error
        self.logs, self.loaded, self.hashed, self.allocations, self.writes, self.fetches = [], [], [], [], 0, 0
        self.short_write = self.fail_read_after = None
        self.fail_target_reads = self.truncate_noop = False
        self.hash_fails = False
        self.constants.update({'SP_VMVariant_1': 0, 'SP_VMVariant_End': 0, '日志级别_WARNING': 4, '日志级别_ERROR': 2, 'L_哈希算法_SHA256': 'SHA256'})
        self.builtins.update({
            '置入代码': lambda *a: None, '系统_取启动时间': lambda: 9_000_000, '机架联动_清理旧桥': lambda: True,
            '全_运行库.取路径': lambda: W(RUNTIME), 'ATU': lambda t, *r: W(t), 'un_连接': self.join,
            'CloseHandle': lambda h: self.fs.handles.pop(h) is not None, 'GetFileType': lambda h: 1 if h in self.fs.handles else 0,
            'SetEndOfFile': self.truncate, 'LoadLibraryW': lambda p: 1, 'LoadLibraryExW_字节集': self.load,
            'GetProcAddress': lambda module, name: 0x1234 if name == 'XRB_Invoke' else 0, 'FreeLibrary': lambda m: True,
            '写日志_本地': lambda text, level: self.logs.append(text), 'L_计算文件流哈希': self.stream_hash,
            '字节集_字节集到十六进制': lambda d: bytes(d).hex().upper(), '取空白字节集': self.blank,
            'L_SHA256': lambda d: hashlib.sha256(bytes(d)).digest()})
        self.raw_builtins.update({'机架联动_取桥数据': self.fetch, 'CreateFileW': self.create, 'GetFileSizeEx_逻辑型': self.size_of,
                                  'GetFileInformationByHandle_字节集': self.info, 'ReadFile_整数型': self.read_into,
                                  'WriteFile_整数型': self.write_from, 'GetSystemDirectoryW': self.system_dir})

    # ---- boundaries ---------------------------------------------------------------------------------------
    def join(self, *parts):                         # un_连接: drops each part's terminating zero, ends with one
        out = b''.join(bytes(p)[:-2] if bytes(p).endswith(b'\0\0') else bytes(p) for p in parts if p is not None)
        return out + b'\0\0' if out else b''

    def blank(self, n):
        self.allocations.append(n)
        return b'\0' * n

    def fetch(self, env, args, raws):
        self.fetches += 1
        refs = [r.strip() for r in raws]
        self.store(refs[0], self.fetch_error, env)
        if self.fetched:
            self.store(refs[1], W(SOURCE), env); self.store(refs[2], self.size, env); self.store(refs[3], self.digest, env)
        return self.fetched

    def create(self, env, args, raws):
        path, access, share, _, disposition, flags, _ = [self.ev(a, env) for a in args]
        return self.fs.open(unw(path), access, share, disposition, flags)

    def size_of(self, env, args, raws):
        h = self.fs.handles.get(self.ev(args[0], env))
        if h is None:
            return False
        self.store(raws[1], len(self.fs.files[h['path']]['data']), env)
        return True

    def info(self, env, args, raws):
        h = self.fs.handles.get(self.ev(args[0], env))
        if h is None:
            return False
        f = self.fs.files[h['path']]
        b = bytearray(52)
        struct.pack_into('<I', b, 0, f['attrs']); struct.pack_into('<I', b, 40, f['links'])
        self.store(raws[1], bytes(b), env)
        return True

    def buffer_name(self, raw):
        return re.fullmatch(r'取变量数据地址 \((.+)\)', raw.strip()).group(1)

    def read_into(self, env, args, raws):
        h = self.fs.handles[self.ev(args[0], env)]
        assert h['access'] & READ
        n = self.ev(args[2], env)
        if self.fail_read_after is not None and h['pos'] >= self.fail_read_after:
            return False
        if self.fail_target_reads and h['path'] == TARGET:      # the loaded file cannot be read back; the copy source can
            return False
        data = bytes(self.fs.files[h['path']]['data'][h['pos']:h['pos'] + n])
        h['pos'] += len(data)
        target = self.buffer_name(raws[1])
        buffer = self.read(target, env)
        assert len(buffer) >= n, 'ReadFile would write past the buffer'
        self.store(target, data + bytes(buffer[len(data):]), env)
        self.store(raws[3], len(data), env)
        return True

    def write_from(self, env, args, raws):
        h = self.fs.handles[self.ev(args[0], env)]
        assert h['access'] & WRITE
        n = self.ev(args[2], env)
        data = bytes(self.read(self.buffer_name(raws[1]), env)[:n])
        if self.short_write is not None and self.writes == self.short_write:
            data = data[:n // 2]
        f = self.fs.files[h['path']]['data']
        f[h['pos']:h['pos'] + len(data)] = data
        h['pos'] += len(data)
        self.writes += 1
        self.store(raws[3], len(data), env)
        return True

    def truncate(self, handle):
        h = self.fs.handles[handle]
        assert h['access'] & WRITE
        if self.truncate_noop:                       # reports success but leaves the old tail in place
            return 1
        del self.fs.files[h['path']]['data'][h['pos']:]
        return 1

    def system_dir(self, env, args, raws):
        text = 'C:\\Windows\\System32'
        buffer = self.read(raws[0].strip(), env)
        self.store(raws[0].strip(), (text.encode('utf-16-le') + bytes(buffer))[:len(buffer)], env)
        return len(text)

    def stream_hash(self, path, start, algorithm, size=None):
        """精易 L_计算文件流哈希: opens the file itself (GENERIC_READ, share read and write), reads it in pieces."""
        assert start == 0 and algorithm == 'SHA256'
        path = unw(path)
        self.hashed.append(self.fs.pinned(path))
        if self.hash_fails:
            return b''
        h = self.fs.open(path, READ, 3, 3)
        if h == -1:
            return b''
        digest = hashlib.sha256(bytes(self.fs.files[path]['data'])).digest()
        self.fs.handles.pop(h)
        return digest

    def load(self, path, flags, how):
        path = unw(path)
        self.loaded.append((path, self.fs.pinned(path), hashlib.sha256(bytes(self.fs.files[path]['data'])).hexdigest()))
        return 0x10000000

    def prepare(self):
        return self.invoke(self.subs['机架联动_准备桥'], [], {}, None)


def setup(target=None, source=BRIDGE, attrs=32, links=1, foreign=None):
    fs = Files()
    fs.files[SOURCE] = {'data': bytearray(source), 'attrs': 32, 'links': 1}
    if target is not None:
        fs.files[TARGET] = {'data': bytearray(target), 'attrs': attrs, 'links': links}
    if foreign is not None:                      # someone else holds the target: (access, share)
        fs.next += 1
        fs.handles[fs.next] = {'path': TARGET, 'access': foreign[0], 'share': foreign[1], 'pos': 0}
    return fs


def main():
    checks = []

    def check(name, passed):
        checks.append(name)
        assert passed, name

    signed = hashlib.sha256(BRIDGE).hexdigest()
    pieces = -(-len(BRIDGE) // PIECE)

    def loaded_as_signed(h):
        return h.loaded == [(TARGET, True, signed)] and bytes(h.fs.files[TARGET]['data']) == BRIDGE

    def only_the_pin_left(h):
        pin = h.globals['集_机架桥锁']
        return list(h.fs.handles) == [pin] and h.fs.handles[pin]['path'] == TARGET and h.fs.pinned(TARGET)

    # ---- not there yet: copied in pieces, checked under the pin, loaded under the pin ------------------------
    h = Host(setup())
    check('fresh_target_prepared', h.prepare() is True and loaded_as_signed(h) and h.globals['集_机架桥准备错误'] == 0)
    check('fresh_target_copied_in_64KB_pieces', h.writes == pieces and max(h.allocations) <= PIECE)
    check('fresh_target_source_read_only_denying_writers', (SOURCE, READ, 1, 3, 128) in h.fs.opens)
    check('fresh_target_measured_under_the_pin', h.hashed and all(h.hashed))
    check('fresh_target_pin_kept_others_closed', only_the_pin_left(h))

    # ---- already the signed DLL: nothing written, checked and loaded under the pin --------------------------
    h = Host(setup(target=BRIDGE))
    check('same_target_not_rewritten', h.prepare() is True and h.writes == 0 and loaded_as_signed(h) and all(h.hashed) and only_the_pin_left(h))
    check('same_target_nothing_allocated_for_it', max(h.allocations) <= PIECE)

    # ---- an older, longer bridge: rewritten and cut to the signed size ----------------------------------------
    h = Host(setup(target=b'old bridge ' * 600000))
    check('stale_target_rewritten_and_truncated', h.prepare() is True and loaded_as_signed(h) and only_the_pin_left(h))

    # ---- what would not come out as signed is never loaded ------------------------------------------------------
    def refused(h, why=None):
        ok = h.prepare()
        return (ok is False and not h.loaded and h.globals['集_机架桥锁'] == 0 and not h.fs.handles
                and (why is None or any(why in l for l in h.logs)))
    tampered = BRIDGE[:-1] + b'!'
    check('source_changed_after_the_check_refused', refused(Host(setup(source=tampered)), '写好后与签名清单不符'))
    h = Host(setup(source=BRIDGE + b'tail'))
    check('source_longer_than_signed_refused_before_writing_past_it', refused(h) and len(h.fs.files[TARGET]['data']) <= len(BRIDGE))
    h = Host(setup()); h.short_write = 5
    check('short_write_refused', refused(h))
    h = Host(setup()); h.fail_read_after = PIECE * 3
    check('failed_read_refused', refused(h))
    # 精易 L_计算文件流哈希 cannot compute (returns empty): the old way on the same pinned handle, so a bridge still loads
    h = Host(setup(target=BRIDGE)); h.hash_fails = True
    check('stream_hash_unavailable_falls_back_to_whole_read_under_the_pin', h.prepare() is True and loaded_as_signed(h)
          and h.writes == 0 and len(BRIDGE) in h.allocations and only_the_pin_left(h))
    h = Host(setup(target=BRIDGE)); h.hash_fails = True; h.fail_target_reads = True
    check('nothing_measurable_never_loaded', refused(h, '算不出 SHA-256'))
    check('wrong_signed_size_refused_naming_both_sizes', refused(Host(setup(), size=len(BRIDGE) - 1)))
    h = Host(setup(target=BRIDGE + b'old tail')); h.truncate_noop = True      # an older, longer file that was not cut
    check('an uncut old tail is caught and both sizes are logged',
          refused(h, '大小不对：文件 ' + str(len(BRIDGE) + 8) + ' 字节，清单 ' + str(len(BRIDGE)) + ' 字节'))
    check('content_reason_logged', refused(Host(setup(source=tampered)), 'SHA-256 不对：文件 ' + hashlib.sha256(tampered).hexdigest()[:16]))

    # ---- a target that must not be written ------------------------------------------------------------------------
    h = Host(setup(target=b'x' * 100, foreign=(READ | WRITE, 3)))
    ok = h.prepare()
    check('target_held_by_someone_else_not_written', ok is False and not h.loaded and h.writes == 0
          and bytes(h.fs.files[TARGET]['data']) == b'x' * 100 and any('正在使用或无法写入' in l for l in h.logs))
    for attrs, links, label in ((32 | 0x400, 1, 'reparse_point'), (32, 2, 'hard_link')):
        h = Host(setup(target=b'y' * 100, attrs=attrs, links=links))
        check('link_target_not_written:' + label, refused(h, '不是普通独立文件') and h.writes == 0 and bytes(h.fs.files[TARGET]['data']) == b'y' * 100)

    # ---- the fetch failed: nothing on disk is touched ----------------------------------------------------------------
    h = Host(setup(), fetched=False, fetch_error=4)
    check('failed_fetch_touches_nothing', h.prepare() is False and not h.fs.opens and h.globals['集_机架桥准备错误'] == 4)

    print(json.dumps({'checks': len(checks), 'passed': len(checks)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
