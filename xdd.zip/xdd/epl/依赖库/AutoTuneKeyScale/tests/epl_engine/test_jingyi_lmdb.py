#!/usr/bin/env python3
"""Execute the 精易模块 类_LMDB source (read-only LMDB) on a real LMDB data format 2 file.

Not an EPL compiler or real Windows file I/O: epl_machine runs the class source with EPL's types (integers wrap at
their declared width, 参考 parameters are written back, conditions must be 逻辑型). The fixture
fixtures/soda_entries_synthetic.db is a real LMDB data format 2 file written by lmdb-js 3.1.3
(fixtures/make_soda_fixture.js; no released LMDB reads this format), laid out like a 汽水音乐 cache database: values
stored as raw bytes (msgpackr records), some inline in leaf pages and some over several overflow pages, two tree
levels. The records are invented. Win32 file calls are substitutes reading the fixture file.
"""
from pathlib import Path
import argparse
import hashlib
import json
import epl_machine as em
from test_wesing_log import jy_trim_end

HERE = Path(__file__).resolve().parent
FIX = HERE / 'fixtures'
EPL = HERE.parents[3]
LMDB_SRC = EPL / '模块/精易模块v9.3.5[源码].e~/代码/配置与存储/类_LMDB.class.e.txt'
DB = 'C:\\测试\\entries.db'
W = lambda text: (text + '\0').encode('utf-16-le')


def wide(value):
    return bytes(value).decode('utf-16-le').split('\0')[0]


class Machine(em.Machine):
    def __init__(self, db_file=None, fake=None):
        super().__init__()
        self.load_class(LMDB_SRC.read_text('utf-8-sig'))
        self.constants.update({'FILE_ATTRIBUTE_DIRECTORY': 16, 'FILE_ATTRIBUTE_NORMAL': 128, 'FILE_BEGIN': 0,
                               'GENERIC_READ': -2147483648, 'INVALID_HANDLE_VALUE': -1, 'OPEN_EXISTING': 3})
        self.now, self.present, self.fake = 100000, True, fake
        self.files = {DB: str(db_file)} if db_file else {}
        self.handles, self.opened, self.closed, self.reads, self.snapshots, self.last_error = {}, [], [], 0, 0, 0
        self.builtins.update({
            '系统_取启动时间': lambda: self.now,
            '目录_取特定目录W': lambda kind, *a: W(APPDATA) if kind == 8 else b'',
            '删除Unicode结尾空白字节': jy_trim_end,
            'un_连接': lambda *parts: (lambda s: W(s) if s else b'')(''.join(jy_trim_end(p).decode('utf-16-le') for p in parts if isinstance(p, bytes))),
            '编码_Unicode到usc2': lambda data, *a: bytes(data).decode('utf-16-le').rstrip('\0'),
            'GetLastError': lambda: self.last_error,
        })
        self.raw_builtins.update({'进程_枚举': self.snapshot, 'GetFileAttributesW': self.attributes_file, 'GetFileAttributesA': self.attributes_file,
                                  'CreateFileW': self.create_file, 'CreateFileA': self.create_file, 'GetFileSizeEx_逻辑型': self.size_file,
                                  'SetFilePointerEx_整数型': self.seek_file, 'ReadFile_字节集': self.read_file, 'CloseHandle': self.close_file})

    # ---- substitutes --------------------------------------------------------------------------------
    def snapshot(self, env, args, raws):
        self.snapshots += 1
        names = ['explorer.exe', 'SodaMusic.exe'] if self.present else ['explorer.exe', 'WeSing.exe']
        self.store(raws[0], names, env)
        self.store(raws[1], list(range(10, 10 + len(names))), env)
        return len(names)

    def arg_path(self, env, arg):
        value = self.ev(arg, env)
        return wide(value) if isinstance(value, (bytes, bytearray)) else value

    def attributes_file(self, env, args, raws):
        p = self.arg_path(env, args[0])
        return 128 if p in self.files else -1

    def create_file(self, env, args, raws):
        p = self.arg_path(env, args[0])
        if p not in self.files:
            self.last_error = 2
            return -1
        handle = 100 + len(self.opened)
        self.opened.append(handle)
        self.handles[handle] = open(self.files[p], 'rb')
        return handle

    def size_file(self, env, args, raws):
        f = self.handles[self.ev(args[0], env)]
        here = f.tell(); f.seek(0, 2); n = f.tell(); f.seek(here)
        self.store(raws[1], n, env)
        return True

    def seek_file(self, env, args, raws):
        self.handles[self.ev(args[0], env)].seek(self.ev(args[1], env))
        return True

    def read_file(self, env, args, raws):                  # the 字节集 is passed by its data pointer and filled in place
        f = self.handles[self.ev(args[0], env)]
        n, buffer = self.ev(args[2], env), self.ev(args[1], env)
        assert len(buffer) >= n, ('read into a buffer that is too small', len(buffer), n)
        data = f.read(n)
        self.reads += 1
        self.store(raws[1], data + bytes(buffer[len(data):]), env)
        self.store(raws[3], len(data), env)
        return True

    def close_file(self, env, args, raws):
        handle = self.ev(args[0], env)
        self.handles.pop(handle).close()
        self.closed.append(handle)
        return True

    def new_object(self, name):
        if name == '类_LMDB' and self.fake is not None:
            return self.fake.handle()
        return super().new_object(name)

    # ---- calls --------------------------------------------------------------------------------------
    def query(self):
        before = len(self.opened)
        result = self.invoke(self.subs['汽水音乐_查询_正在播放的音乐'], [], {}, None)
        assert not self.handles, 'every opened database file is closed when the query returns'
        assert len(self.closed) >= before, (before, self.closed)
        return result

    def run(self, name, *values):
        return self.invoke(self.subs[name], [('lit', v) for v in values], {}, None)

    def out(self, name, values=(), outs=()):
        """Call with 参考 out-parameters: outs are (name, type) of caller variables appended after values."""
        env = {'_obj': None, '_types': {n: (k, False) for n, k in outs}, '_omitted': set()}
        env.update({n: em.DEFAULTS[k] for n, k in outs})
        result = self.invoke(self.subs[name], [('lit', v) for v in values] + [em.parse_expr(n) for n, _ in outs], env, None)
        return (result, *[env[n] for n, _ in outs])



def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--real', help='another LMDB data file to list (read-only, never committed)')
    opts = parser.parse_args()
    checks = []

    def check(name, passed):
        checks.append(name)
        assert passed, name

    path = opts.real or FIX / 'soda_entries_synthetic.db'
    m = Machine(path)
    lm = m.new_object('类_LMDB')
    call = lambda name, *v: m.invoke(lm.cls.methods[name], [('lit', x) for x in v], {}, lm)
    if opts.real:
        call('打开W', W(DB))
        print(json.dumps({'format': call('取格式版本'), 'records': call('取记录数'), 'transaction': call('取事务号')}))
        return
    manifest = json.loads((FIX / 'soda_entries_synthetic.json').read_text('utf-8'))
    check('lmdb_opens_format_2', call('打开W', W(DB)) is True and call('取格式版本') == 2 and call('取记录数') == len(manifest['records'])
          and call('取树深度') == manifest['treeDepth'] >= 2)
    rows, moved = [], call('到首记录')
    while moved:
        rows.append((call('取当前键'), call('取当前值')))
        moved = call('到下一记录')
    check('lmdb_every_record_byte_for_byte', [(k.decode('latin-1'), hashlib.sha256(v).hexdigest()) for k, v in rows]
          == [(r['key'], r['value_sha256']) for r in manifest['records']] and call('取错误信息') == '')
    check('fixture_covers_inline_and_overflow_values', manifest['overflowPages'] > 0 and min(len(v) for _, v in rows) < 2000 < max(len(v) for _, v in rows))
    key, value = rows[len(rows) // 2]
    check('lmdb_reads_one_key', call('取值', key) == value and call('取值', key + b'x') == b'')
    call('关闭')
    check('lmdb_closes_its_file', not m.handles and m.opened == m.closed)
    print(json.dumps({'checks': len(checks), 'passed': len(checks)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
