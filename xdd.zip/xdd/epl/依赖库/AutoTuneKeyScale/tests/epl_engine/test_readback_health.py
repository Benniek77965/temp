#!/usr/bin/env python3
"""Run exact production count/state/confirmation/selfcheck statements.

The native packed status is an explicit boundary input, and the clock is fixed.
This does not execute EPL, WM_COPYDATA, a native controller or real plug-ins.
"""
from pathlib import Path
from types import SimpleNamespace
import argparse
import hashlib
import json
import re
import zipfile
import review_regression as regression

MODULE = Path(__file__).resolve().parents[4] / '模块/模块_电音助手.e~'
ENTRY = 'xhh/epl/模块/模块_电音助手.e~/代码/程序集_机架联动引擎.static.e.txt'


def packed(captured=32, confirmed=32, pending=0, flags=0, valid=True):
    return (0x80000000 if valid else 0) | flags | (captured << 12) | (pending << 6) | confirmed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--module', type=Path, default=MODULE)
    parser.add_argument('--baseline-zip', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    if args.baseline_zip:
        with zipfile.ZipFile(args.baseline_zip, metadata_encoding='gbk') as archive:
            raw = archive.read(ENTRY)
    else:
        raw = (args.module / '代码/程序集_机架联动引擎.static.e.txt').read_bytes()
    source = raw.decode('utf-8-sig')
    link = regression.syntax.section(source, '机架引擎_线程_联动')
    first = link.index('        赋值 (集_机架_快照.已确认,')
    capability_write = re.search(r'^        赋值 \(集_机架_快照\.(?:支持速度|有速度),', link[first:], re.M)
    assert capability_write is not None, 'missing speed capability publication'
    count_end = first + capability_write.start()  # Also accepts old --baseline-zip exports.
    start = link.index('        赋值 (局_状态编号, 机架引擎_状态编号')
    end = link.index('        .如果真 (并且 (取反 (局_快照.自动切换)', start)
    body = link[first:count_end] + link[start:end]
    cases = []

    def case(name, **values):
        item = dict(name=name, status=packed(), error=0, healthy=True, selfcheck=True,
                    log=True, locked=False, actual='C', multi=False, sent=12, target=12,
                    push_elapsed=200, self_elapsed=300)
        item.update(values)
        cases.append(item)

    for count in (1, 32, 63):
        case('healthy_count_' + str(count), status=packed(count, count))
    for bit, label in [(30, 'auth'), (29, 'old_agent'), (28, 'write_failed'),
                       (27, 'runtime_failed'), (26, 'access_denied'), (25, 'capacity')]:
        case('status_flag_' + label, status=packed(flags=1 << bit),
             healthy=False, selfcheck=False, log=False)
    for error in (1, 2, 4, 5, 7, 10, 11, 13, 999):
        case('bridge_error_' + str(error), error=error, healthy=False, selfcheck=False, log=False)
    for name, status in [('no_marker', packed(valid=False)), ('no_instances', packed(0, 0)),
                         ('pending_only', packed(0, 0, 1)), ('pending_with_confirmed', packed(1, 1, 1)),
                         ('missing_confirmation', packed(2, 1)), ('over_confirmation', packed(1, 2))]:
        case(name, status=status, healthy=False, selfcheck=False, log=False)
    case('rack_count_is_not_error_flag', status=packed(flags=1 << 18))
    case('Chromatic_is_healthy', actual='Chromatic')
    case('locked_is_healthy', locked=True)
    case('multiple_players_is_healthy', multi=True)
    case('new_unlocked_target_must_not_reuse_old_confirmation', sent=11, target=12,
         selfcheck=False, log=False)
    case('locked_actual_goal_survives_background_song_version', locked=True, sent=11, target=12,
         selfcheck=True, log=False)
    case('locked_Chromatic_actual_goal_survives_background_version', locked=True, actual='Chromatic',
         sent=11, target=12, selfcheck=True, log=False)
    case('locked_but_no_actual_goal_cannot_borrow_old_confirmation', locked=True, actual='',
         sent=11, target=12, selfcheck=False, log=False)
    case('locked_but_never_sent_cannot_borrow_old_confirmation', locked=True,
         sent=-1, target=12, selfcheck=False, log=False)
    case('confirmation_log_waits_150ms', push_elapsed=149, log=False)
    case('selfcheck_waits_200ms', self_elapsed=199, selfcheck=False)
    case('unhealthy_selfcheck_times_out', status=packed(flags=1 << 25), self_elapsed=3100,
         healthy=False, selfcheck=False, log=False)
    tests, observed = [], []
    helper_exists = '.子程序 机架引擎_回读完整,' in source
    for item in cases:
        for signed in (False, True):
            status = item['status']
            if signed and status & 0x80000000:
                status -= 0x100000000
            runtime = regression.engine_runtime(source)
            snapshot = SimpleNamespace(已锁定=item['locked'], 总数=0, 已确认=0,
                                       实际基调=item['actual'], 多播放器=item['multi'], 自检结果=1)
            runtime.env['集_机架_快照'] = snapshot
            runtime.env.update({'集_机架_确认待记': True, '集_机架_已发版本': item['sent'],
                                '集_机架_目标版本': item['target'],
                                '集_机架_推送时间': 1000-item['push_elapsed'],
                                '集_机架_检测时间': 100, '集_机架_自检时间': 1000-item['self_elapsed']})
            local = {'局_状态': status, '局_错误': item['error'], '局_耗时日志': ''}
            runtime.execute_text(body, local)
            prefix = item['name'] + ('_signed' if signed else '_unsigned')
            expected_self = 2 if item['selfcheck'] else 3 if item['self_elapsed'] >= 3000 else 1
            healthy = runtime.invoke('机架引擎_回读完整', status, item['error']) if helper_exists else None
            tests.extend([
                {'name': prefix + ':healthy', 'passed': healthy == item['healthy']},
                {'name': prefix + ':selfcheck', 'passed': snapshot.自检结果 == expected_self},
                {'name': prefix + ':confirmation_log', 'passed': bool(local['局_耗时日志']) == item['log']
                 and runtime.env['集_机架_确认待记'] == (not item['log'])},
            ])
            observed.append({'case': prefix, 'healthy': healthy, 'state': local['局_状态编号'],
                             'selfcheck': snapshot.自检结果, 'logged': bool(local['局_耗时日志'])})
    # Protect semantic entry-point reuse without freezing a state-number string:
    # locked/Chromatic/multi-player success is covered by the executed cases.
    tests.append({'name': 'helper_reused_by_both_real_confirmation_conditions',
                  'passed': body.count('机架引擎_回读完整 (局_状态, 局_错误)') == 2})
    failures = [test['name'] for test in tests if not test['passed']]
    behavior = [item for item in tests if item['name'].endswith((':selfcheck', ':confirmation_log'))]
    result = {'behavior_checks': len(behavior), 'behavior_passed': sum(item['passed'] for item in behavior), 'helper_contract_applicable': helper_exists,
              'source_sha256': hashlib.sha256(raw).hexdigest(), 'scenarios': len(cases),
              'checks': len(tests), 'passed': len(tests)-len(failures), 'failures': failures,
              'scope': __doc__, 'tests': tests, 'observed': observed}
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in result.items() if key not in ('tests', 'observed', 'failures')}, ensure_ascii=False, indent=2))
    print('failure count:', len(failures), 'first failures:', failures[:8])
    return bool(failures)


if __name__ == '__main__':
    raise SystemExit(main())
