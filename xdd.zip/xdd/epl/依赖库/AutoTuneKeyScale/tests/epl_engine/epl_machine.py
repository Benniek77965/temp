#!/usr/bin/env python3
"""A small, type-faithful EPL interpreter for tests -- not a compiler, no Windows.

It runs real EPL source text: static 程序集 subroutines with their 程序集变量, and classes (members,
``类名.方法 ()`` calls on the object itself, ``对象.方法 ()`` calls on another object, _初始化 / _销毁).
Integers wrap like EPL's on every store, parameter binding and return (整数型 32-bit, 长整数型 64-bit,
短整数型 16-bit, 字节型 8-bit); 参考 parameters are written back to the caller's variable, array element or
member; arrays are one-based and bounds-checked. It is strict on purpose: a condition that is not a 逻辑型,
a non-逻辑型 stored into a 逻辑型, an undeclared variable, an omitted required argument or an index out of
range stops the test instead of passing silently. Win32 calls and other externals are explicit
substitutes registered by the test (``builtins`` take evaluated arguments, ``raw_builtins`` get the
argument expressions, for 参考 out-parameters).
"""
import re
import struct
from copy import deepcopy
import check as syntax

INT_BITS = {'整数型': 32, '长整数型': 64, '短整数型': 16}
DEFAULTS = {'整数型': 0, '长整数型': 0, '短整数型': 0, '字节型': 0, '逻辑型': False, '文本型': '', '字节集': b'',
            '双精度小数型': 0.0, '小数型': 0.0, '日期时间型': 0, '子程序指针': 0}
TYPE_SIZE = {'字节型': 1, '短整数型': 2, '整数型': 4, '长整数型': 8, '小数型': 4, '双精度小数型': 8}


class NextIteration(Exception):
    pass


def wrap(value, kind):
    """Store a value into a variable of the declared type, as EPL converts it."""
    if kind in INT_BITS or kind == '字节型':
        if isinstance(value, bool):
            raise AssertionError(f'逻辑型 stored into {kind}')
        if isinstance(value, float):
            value = int(value)                                   # truncation toward zero
        assert isinstance(value, int), (kind, value)
        if kind == '字节型':
            return value & 0xFF
        m = 1 << INT_BITS[kind]
        value &= m - 1
        return value - m if value >= m >> 1 else value
    if kind in ('双精度小数型', '小数型'):
        assert isinstance(value, (int, float)) and not isinstance(value, bool), (kind, value)
        return float(value)
    if kind == '逻辑型':
        assert isinstance(value, bool), ('non-逻辑型 stored into 逻辑型', value)
        return value
    if kind == '文本型':
        assert isinstance(value, str), ('non-text stored into 文本型', value)
        return value
    if kind == '字节集':
        assert isinstance(value, (bytes, bytearray)), ('non-bytes stored into 字节集', type(value))
        return bytes(value)
    return value


def int32(value):
    return wrap(value, '整数型')


def gbk(text):
    return text.encode('gbk', errors='replace')        # what EPL keeps for 文本型: GBK, '?' for what GBK lacks


def ungbk(data):
    return data.decode('gbk', errors='replace')


def find_text(text, sub, start=None, fold=None):
    hay, needle = gbk(text), gbk(sub)
    if fold:
        hay, needle = hay.lower(), needle.lower()
    at = hay.find(needle, (start or 1) - 1)
    return -1 if at < 0 else at + 1


def trunc_div(a, b):
    assert b != 0, 'division by zero'
    q = abs(a) // abs(b)
    return q if (a >= 0) == (b >= 0) else -q


def epl_text(value):
    if isinstance(value, bool):
        return '真' if value else '假'
    if isinstance(value, float):
        return repr(value)[:-2] if value.is_integer() else repr(value)
    if isinstance(value, (bytes, bytearray)):
        return bytes(value).split(b'\0')[0].decode('gbk', errors='replace')
    return str(value)


def parse_decls(text):
    """(params, locals) of one subroutine: params are (name, type, flags, is_array), locals (name, type, dims)."""
    params, local = [], []
    for line in text.split('\n'):
        m = re.match(r'^\.参数 ([^,]+), ([^,]+), ([^,]*)', line)
        if m:
            name, kind, flags = (x.strip() for x in m.groups())
            params.append((name, kind, flags, '数组' in flags))
            continue
        m = re.match(r'^\.局部变量 ([^,]+), ([^,]+), [^,]*, ("[^"]*")?', line)
        if m:
            local.append((m.group(1).strip(), m.group(2).strip(), m.group(3)[1:-1] if m.group(3) else None))
    return params, local


class Sub:
    def __init__(self, text, owner=None):
        self.text = text
        header = re.match(r'^\.子程序 ([^,\n]+), ?([^,\n]*)', text)
        self.name, self.ret = header.group(1).strip(), header.group(2).strip()
        self.params, self.locals = parse_decls(text)
        self.owner = owner
        self._body = None

    def body(self):
        if self._body is None:
            lines = self.text.split('\n')
            self._body, end = syntax.parse_block(lines)
            assert end == len(lines), self.name
        return self._body


def split_subs(text):
    return [m.group(0) for m in re.finditer(r'^\.子程序 [^\n]*\n.*?(?=^\.子程序 |\Z)', text, re.M | re.S)]


class Cls:
    def __init__(self, text):
        self.name = re.match(r'\.程序集 ([^,\s]+)', text).group(1)
        self.members = {m.group(1).strip(): (m.group(2).strip(), m.group(3)[1:-1] if m.group(3) else None)
                        for m in re.finditer(r'^\.程序集变量 ([^,]+), ([^,]+), [^,]*, ("[^"]*")?', text, re.M)}
        self.methods = {s.name: s for s in (Sub(t, self) for t in split_subs(text))}


class EObj:
    def __init__(self, cls, machine):
        self.cls = cls
        self.members = {name: machine.new_value(kind, dims) for name, (kind, dims) in cls.members.items()}

    def __repr__(self):
        return f'<{self.cls.name}>'


def is_lvalue(raw):
    return bool(re.fullmatch(r'[A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*(\.[\w\u4e00-\u9fff]+|\[.+\])?', raw.strip()))


def matching_call(s):
    """name (args) when the parenthesis opened after the name closes at the very end."""
    m = re.match(r'([^\s(\[\]“”{},]+) \(', s)
    if not m or not s.endswith(')'):
        return None
    depth, quoted = 0, False
    for i in range(m.end() - 1, len(s)):
        c = s[i]
        if c == '“': quoted = True
        elif c == '”': quoted = False
        elif not quoted:
            if c == '(': depth += 1
            elif c == ')':
                depth -= 1
                if depth == 0:
                    return (m.group(1), s[m.end():i]) if i == len(s) - 1 else None
    return None


_ast_cache = {}


def parse_expr(s):
    s = s.strip()
    cached = _ast_cache.get(s)
    if cached is not None:
        return cached
    if s == '':
        node = ('omit',)
    elif s.startswith('“') and s.endswith('”') and s.count('“') == 1 and s.count('”') == 1:
        node = ('lit', s[1:-1])
    elif s in ('真', '假'):
        node = ('lit', s == '真')
    elif s == '{}':
        node = ('lit', b'')
    elif s.startswith('{“') and s.endswith('”}') and '{' not in s[1:]:     # a text array: {“a”, “b”}
        items = [x.strip() for x in syntax.split_args(s[1:-1])]
        assert all(x.startswith('“') and x.endswith('”') for x in items), ('mixed array literal', s)
        node = ('lit', [x[1:-1] for x in items])
    elif s.startswith('{') and s.endswith('}') and '{' not in s[1:]:
        node = ('lit', bytes(int(x) for x in s[1:-1].split(',')))
    elif re.fullmatch(r'-?\d+', s):
        node = ('lit', int(s))
    elif re.fullmatch(r'-?\d+\.\d+', s):
        node = ('lit', float(s))
    elif s.startswith('#') and re.fullmatch(r'#[\w\u4e00-\u9fff]+', s):
        node = ('const', s[1:])
    elif re.fullmatch(r'&[\w\u4e00-\u9fff]+', s):           # a subroutine pointer (&子程序): its name; the substitute that takes it decides what to call
        node = ('lit', s)
    else:
        call = matching_call(s)
        if call:
            name, raw = call
            raws = syntax.split_args(raw) if raw.strip() else []
            node = ('call', name, [parse_expr(a) for a in raws], raws)
        elif re.fullmatch(r'[^\[\]]+\[.+\]', s):
            m = re.fullmatch(r'([^\[\]]+)\[(.+)\]', s)
            node = ('index', parse_expr(m.group(1)), parse_expr(m.group(2)))
        elif re.fullmatch(r'[^\[\]]+\[[^\[\]]+\]\.[\w\u4e00-\u9fff]+', s):   # 数组成员的字段：列表[序号].名
            m = re.fullmatch(r'([^\[\]]+)\[([^\[\]]+)\]\.([\w\u4e00-\u9fff]+)', s)
            node = ('member', ('index', parse_expr(m.group(1)), parse_expr(m.group(2))), m.group(3))
        elif re.fullmatch(r'[A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*', s):
            node = ('var', s)
        elif re.fullmatch(r'[A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*\.[\w\u4e00-\u9fff]+', s):
            head, field = s.rsplit('.', 1)
            node = ('member', parse_expr(head), field)
        else:
            raise AssertionError('unparsed expression: ' + s)
    _ast_cache[s] = node
    return node


class Machine:
    """Holds the loaded program, its 程序集变量, constants and substitutes."""

    def __init__(self):
        self.subs, self.classes = {}, {}
        self.globals, self.global_types = {}, {}
        self.constants = {'整数型': '整数型', '长整数型': '长整数型', '短整数型': '短整数型', '字节型': '字节型',
                          '小数型': '小数型', '双精度小数型': '双精度小数型', '引号': '"', '换行符': '\r\n'}
        self.builtins, self.raw_builtins = {}, {}
        self.factories = {}          # type name -> Python stand-in for a class whose source is not loaded (zyJsonDocument)
        self.steps = 0
        self._install_library()

    # ---- loading ------------------------------------------------------------------------------------
    def load_static(self, text, names=None):
        """Load a static 程序集 (all its subroutines, or only ``names``) and its 程序集变量."""
        text = text.lstrip('\ufeff').replace('\r', '')
        for sub_text in split_subs(text):
            sub = Sub(sub_text)
            if names is None or sub.name in names:
                self.subs[sub.name] = sub
        if names is None:
            for m in re.finditer(r'^\.程序集变量 ([^,]+), ([^,]+), [^,]*, ("[^"]*")?', text, re.M):
                name, kind = m.group(1).strip(), m.group(2).strip()
                dims = m.group(3)[1:-1] if m.group(3) else None
                self.global_types[name] = (kind, dims is not None)
                self.globals[name] = self.new_value(kind, dims)

    def load_class(self, text):
        cls = Cls(text.lstrip('\ufeff').replace('\r', ''))
        self.classes[cls.name] = cls
        return cls

    def new_object(self, name):
        obj = EObj(self.classes[name], self)
        if '_初始化' in obj.cls.methods:
            self.invoke(obj.cls.methods['_初始化'], [], {}, obj)
        return obj

    def destroy(self, obj):
        if isinstance(obj, EObj) and '_销毁' in obj.cls.methods:
            self.invoke(obj.cls.methods['_销毁'], [], {}, obj)
        elif hasattr(obj, '_销毁'):                       # a Python substitute standing in for a class object
            obj._销毁()

    def new_value(self, kind, dims):
        if dims is not None:
            count = int(dims.split(',')[0]) if dims.strip() else 0
            return [self.new_value(kind, None) for _ in range(count)]
        if kind in DEFAULTS:
            return DEFAULTS[kind]
        if kind in self.classes:
            return None   # created on first use by declare(); a 程序集变量 of a class type is made lazily
        return None

    # ---- variables ----------------------------------------------------------------------------------
    def declared(self, name, env):
        """(type, is_array) of a variable as declared where it is found."""
        if name in env.get('_types', {}):
            return env['_types'][name]
        obj = env.get('_obj')
        if obj is not None and name in obj.members:
            kind, dims = obj.cls.members[name]
            return kind, dims is not None
        if name in self.global_types:
            return self.global_types[name]
        return None, False

    def read(self, name, env):
        if name in env:
            return env[name]
        obj = env.get('_obj')
        if obj is not None and name in obj.members:
            return obj.members[name]
        if name in self.globals:
            value = self.globals[name]
            kind, is_array = self.global_types.get(name, (None, False))
            if value is None and not is_array and kind in self.classes:
                value = self.globals[name] = self.new_object(kind)
            return value
        raise AssertionError('unknown variable ' + name)

    def coerce(self, value, kind, is_array):
        if is_array:
            assert isinstance(value, list), ('array expected', value)
            return [wrap(v, kind) if kind in DEFAULTS else v for v in deepcopy(value)]
        if kind in DEFAULTS:
            return wrap(value, kind)
        return value

    def store(self, target, value, env):
        node = parse_expr(target) if isinstance(target, str) else target
        if node[0] == 'var':
            name = node[1]
            kind, is_array = self.declared(name, env)
            value = self.coerce(value, kind, is_array) if kind else deepcopy(value)
            if name in env and not name.startswith('_'):
                env[name] = value
                return
            obj = env.get('_obj')
            if obj is not None and name in obj.members:
                obj.members[name] = value
                return
            if name in self.globals:
                self.globals[name] = value
                return
            raise AssertionError('assignment to undeclared variable ' + name)
        if node[0] == 'index':
            container = self.ev(node[1], env)
            index = self.ev(node[2], env)
            assert isinstance(container, (list, bytes, bytearray)) and 1 <= index <= len(container), ('index out of range', index, len(container) if isinstance(container, (list, bytes)) else container)
            if isinstance(container, (bytes, bytearray)):        # 赋值 (字节集[i], 值): that byte replaced
                changed = bytearray(container); changed[index - 1] = wrap(value, '字节型')
                self.store(node[1], bytes(changed), env)
                return
            kind = self.declared(node[1][1], env)[0] if node[1][0] == 'var' else None
            container[index - 1] = wrap(value, kind) if kind in DEFAULTS else deepcopy(value)
            return
        if node[0] == 'member':
            obj = self.ev(node[1], env)
            if isinstance(obj, EObj):
                kind, dims = obj.cls.members[node[2]]
                obj.members[node[2]] = self.coerce(value, kind, dims is not None)
            else:
                setattr(obj, node[2], deepcopy(value))
            return
        raise AssertionError('not assignable: ' + str(target))

    # ---- evaluation ---------------------------------------------------------------------------------
    def ev(self, node, env):
        kind = node[0]
        if kind == 'lit':
            return node[1]
        if kind == 'var':
            return self.read(node[1], env)
        if kind == 'call':
            return self.call(node, env)
        if kind == 'omit':
            return None
        if kind == 'const':
            assert node[1] in self.constants, 'unknown constant #' + node[1]
            return self.constants[node[1]]
        if kind == 'index':
            container = self.ev(node[1], env)
            index = self.ev(node[2], env)
            assert isinstance(container, (list, bytes, bytearray)) and 1 <= index <= len(container), ('index out of range', index, len(container) if isinstance(container, (list, bytes)) else container)
            return container[index - 1]                     # a 字节集 element is its byte (0..255)
        if kind == 'member':
            obj = self.ev(node[1], env)
            return obj.members[node[2]] if isinstance(obj, EObj) else getattr(obj, node[2])
        raise AssertionError(node)

    def truth(self, raw, env):
        value = self.ev(parse_expr(raw), env)
        assert isinstance(value, bool), ('condition is not 逻辑型', raw, value)
        return value

    def call(self, node, env):
        _, name, args, raws = node
        if name in self.raw_builtins:
            return self.raw_builtins[name](env, args, raws)
        if name in self.builtins:
            return self.builtins[name](*[self.ev(a, env) for a in args])
        if '.' in name:
            head, method = name.rsplit('.', 1)
            obj = env.get('_obj')
            target = obj if obj is not None and head == obj.cls.name else self.read(head, env)
            if isinstance(target, EObj):
                assert method in target.cls.methods, f'{target.cls.name} has no method {method}'
                return self.invoke(target.cls.methods[method], args, env, target)
            return getattr(target, method)(*[self.ev(a, env) for a in args])
        if name in self.subs:
            return self.invoke(self.subs[name], args, env, None)
        obj = env.get('_obj')
        if obj is not None and name in obj.cls.methods:
            return self.invoke(obj.cls.methods[name], args, env, obj)
        raise AssertionError('unhandled call: ' + name)

    def invoke(self, sub, args, caller_env, obj):
        values = [self.ev(a, caller_env) for a in args]
        assert len(values) <= len(sub.params), (sub.name, 'too many arguments', len(values))
        env = {'_obj': obj, '_types': {}, '_omitted': set()}
        refs = []
        for i, (name, kind, flags, is_array) in enumerate(sub.params):
            value = values[i] if i < len(values) else None
            if value is None:
                assert '可空' in flags, (sub.name, name, 'required argument omitted')
                env['_omitted'].add(name)
                value = [] if is_array else self.new_value(kind, None)
            elif is_array:
                value = value if '参考' in flags else deepcopy(value)
            elif kind in DEFAULTS:
                value = wrap(value, kind)
            elif isinstance(value, EObj) or kind in self.factories:
                # a class object passed by value is a copy that is destroyed when the call returns: its _销毁
                # would close or free what the caller's object still uses (a file handle, a parsed JSON document)
                assert '参考' in flags, (sub.name, name, 'class object passed by value; declare the parameter 参考')
            env[name] = value
            env['_types'][name] = (kind, is_array)
            if '参考' in flags and i < len(args) and args[i][0] in ('var', 'index', 'member'):
                refs.append((name, args[i]))
        created = []
        for name, kind, dims in sub.locals:
            value = self.new_value(kind, dims)
            if value is None and dims is None and kind in self.factories:
                value = self.factories[kind]()
                created.append(value)
            elif value is None and dims is None and kind in self.classes:
                value = self.new_object(kind)
                created.append(value)
            env[name] = value
            env['_types'][name] = (kind, dims is not None)
        result = None
        try:
            self.execute(sub.body(), env)
        except syntax.Returned as returned:
            result = returned.value
        for name, target in refs:
            self.store(target, env[name], caller_env)
        for value in created:
            if value is not result:
                self.destroy(value)
        if sub.ret:
            result = self.new_value(sub.ret, None) if result is None else (wrap(result, sub.ret) if sub.ret in DEFAULTS else result)
        return result

    def out(self, name, values=(), outs=()):
        """Call a static subroutine with 参考 out-parameters: outs are (name, type) of caller variables appended after values."""
        env = {'_obj': None, '_types': {n: (k, False) for n, k in outs}, '_omitted': set()}
        env.update({n: DEFAULTS[k] for n, k in outs})
        result = self.invoke(self.subs[name], [('lit', v) for v in values] + [parse_expr(n) for n, _ in outs], env, None)
        return (result, *[env[n] for n, _ in outs])

    # ---- statements ---------------------------------------------------------------------------------
    def execute(self, nodes, env):
        for node in nodes:
            kind = node[0]
            if kind == 'statement':
                self.statement(node[1], env)
            elif kind == 'if':
                if self.truth(node[1], env):
                    self.execute(node[2], env)
            elif kind == 'switch':
                for condition, body in node[1]:
                    if condition is None or self.truth(condition, env):
                        self.execute(body, env)
                        break
            elif kind in ('while', 'dowhile'):
                rounds = 0
                while kind == 'dowhile' or self.truth(node[1], env):
                    rounds += 1
                    assert rounds < 5000000, 'runaway loop'
                    try:
                        self.execute(node[2], env)
                    except NextIteration:
                        pass
                    except syntax.Broke:
                        break
                    if kind == 'dowhile' and not self.truth(node[1], env):
                        break
            elif kind == 'repeat':
                count = self.ev(parse_expr(node[1]), env)
                for counter in range(1, count + 1):
                    if node[2].strip():
                        self.store(node[2], counter, env)
                    try:
                        self.execute(node[3], env)
                    except NextIteration:
                        continue
                    except syntax.Broke:
                        break
            elif kind == 'for':
                first, last, step, variable = node[1]
                value, last, step = (self.ev(parse_expr(x), env) for x in (first, last, step))
                self.store(variable, value, env)
                while (step > 0 and value <= last) or (step < 0 and value >= last):
                    try:
                        self.execute(node[2], env)
                    except NextIteration:
                        pass
                    except syntax.Broke:
                        break
                    value = self.read(variable, env) + step
                    self.store(variable, value, env)
            else:
                raise AssertionError(node)

    def statement(self, line, env):
        self.steps += 1
        node = parse_expr(line)
        assert node[0] == 'call', ('not a statement', line)
        name, args = node[1], node[2]
        if name == '赋值':
            self.store(node[3][0], self.ev(args[1], env), env)
        elif name == '连续赋值':
            value = self.ev(args[0], env)
            for raw in node[3][1:]:
                self.store(raw, value, env)
        elif name == '返回':
            raise syntax.Returned(self.ev(args[0], env) if args else None)
        elif name == '跳出循环':
            raise syntax.Broke()
        elif name == '到循环尾':
            raise NextIteration()
        else:
            self.call(node, env)

    # ---- library ------------------------------------------------------------------------------------
    def _install_library(self):
        b = self.builtins

        def compare(op):
            def f(x, y):
                assert type(x) in (int, float, str, bytes, bool) and type(y) in (int, float, str, bytes, bool), (x, y)
                return op(x, y)
            return f
        b.update({
            '等于': compare(lambda x, y: x == y), '不等于': compare(lambda x, y: x != y),
            '小于': compare(lambda x, y: x < y), '大于': compare(lambda x, y: x > y),
            '小于或等于': compare(lambda x, y: x <= y), '大于或等于': compare(lambda x, y: x >= y),
            '并且': lambda *a: (all(isinstance(x, bool) for x in a) or self._bad('并且', a)) and all(a),
            '或者': lambda *a: (all(isinstance(x, bool) for x in a) or self._bad('或者', a)) and any(a),
            '取反': lambda a: (isinstance(a, bool) or self._bad('取反', a)) and not a,
            '相加': self._add, '相减': lambda a, *r: a - sum(r), '相乘': self._mul,
            '相除': lambda a, c: a / c, '整除': trunc_div, '求余数': lambda a, c: a - trunc_div(a, c) * c,
            '取负数': lambda a: -a, '取绝对值': abs,
            '位与': lambda *a: int32(self._fold(lambda x, y: x & y, a)), '位或': lambda *a: int32(self._fold(lambda x, y: x | y, a)),
            '位异或': lambda *a: int32(self._fold(lambda x, y: x ^ y, a)), '位取反': lambda a: int32(~int32(a)),
            '左移': lambda a, n: int32(int32(a) << n), '右移': lambda a, n: int32(int32(a) >> n),
            '到整数': lambda v: int32(self._num(v)), '到长整数': lambda v: wrap(self._num(v), '长整数型'),
            '到文本': epl_text, '到字节集': self._to_bytes,
            '取字节集长度': lambda d: len(d),
            '取字节集中间': lambda d, s, n: bytes(d[max(s, 1) - 1:max(s, 1) - 1 + max(n, 0)]),
            '取字节集左边': lambda d, n: bytes(d[:max(n, 0)]), '取字节集右边': lambda d, n: bytes(d[len(d) - n:]) if n > 0 else b'',
            '取空白字节集': lambda n: b'\0' * n,
            '寻找字节集': lambda d, x, s=None: (lambda i: -1 if i < 0 else i + 1)(bytes(d).find(bytes(x), (s or 1) - 1)),
            # 文本型 is GBK bytes in EPL: lengths, cuts and positions count bytes, and a character GBK lacks becomes '?'
            '取文本长度': lambda t: len(gbk(t)), '取文本左边': lambda t, n: ungbk(gbk(t)[:max(n, 0)]),
            '取文本右边': lambda t, n: ungbk(gbk(t)[len(gbk(t)) - n:]) if n > 0 else '',
            '取文本中间': lambda t, s, n: ungbk(gbk(t)[max(s, 1) - 1:max(s, 1) - 1 + max(n, 0)]),
            '寻找文本': lambda t, sub, start=None, fold=None: find_text(t, sub, start, fold),
            '到大写': lambda t: ''.join(c.upper() if c.isascii() else c for c in t),
            '删首尾空': lambda t: t.strip(' \u3000'),
            '分割文本': lambda t, sep, limit=None: [] if t == '' else t.split(sep),
            '取数组成员数': lambda a: len(a) if isinstance(a, list) else -1,
            '编码_Ansi到Utf8': lambda t: t.encode('utf-8'),
            '编码_Utf8到Ansi': lambda d: bytes(d).split(b'\0')[0].decode('utf-8', errors='replace'),
            '编码_Unicode到Ansi': lambda d: ungbk(gbk(bytes(d).decode('utf-16-le', errors='replace').split('\0')[0])),
            '编码_Ansi到Unicode': lambda t, nonstandard=None: t.encode('utf-16-le') + (b'' if nonstandard else b'\0\0'),
            '编码_Utf8到Unicode': lambda d: bytes(d).split(b'\0')[0].decode('utf-8', errors='replace').encode('utf-16-le') + b'\0\0',
            '到小写': lambda t: ''.join(c.lower() if c.isascii() else c for c in t),
            '选择': lambda condition, a, c: (isinstance(condition, bool) or self._bad('选择', condition)) and a if condition else c,
            '多项选择': self._pick,
        })
        r = self.raw_builtins
        r['是否为空'] = lambda env, args, raws: raws[0].strip() in env['_omitted']
        r['加入成员'] = self._append
        r['清除数组'] = lambda env, args, raws: self.store(raws[0], [], env)
        r['重定义数组'] = self._redim
        r['取字节集数据'] = self._bytes_data

    @staticmethod
    def _pick(index, *values):
        assert isinstance(index, int) and 1 <= index <= len(values), ('多项选择 index out of range', index, len(values))
        return values[index - 1]

    @staticmethod
    def _bad(name, args):
        raise AssertionError(f'{name} needs 逻辑型 arguments: {args}')

    @staticmethod
    def _fold(f, args):
        value = args[0]
        for x in args[1:]:
            value = f(value, x)
        return value

    @staticmethod
    def _num(v):
        if isinstance(v, bool):
            raise AssertionError('逻辑型 converted to a number')
        if isinstance(v, (int, float)):
            return int(v)
        if isinstance(v, str):
            m = re.match(r'\s*(-?\d+)', v)
            return int(m.group(1)) if m else 0
        raise AssertionError(('cannot convert', v))

    @staticmethod
    def _add(*a):
        if all(isinstance(x, str) for x in a):
            return ''.join(a)
        if all(isinstance(x, (bytes, bytearray)) for x in a):
            return b''.join(bytes(x) for x in a)
        assert all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in a), ('相加 mixes types', a)
        return sum(a)

    @staticmethod
    def _mul(*a):
        value = 1
        for x in a:
            assert isinstance(x, (int, float)) and not isinstance(x, bool), x
            value *= x
        return value

    @staticmethod
    def _to_bytes(v):
        if isinstance(v, str):
            return v.encode('gbk')
        if isinstance(v, (bytes, bytearray)):
            return bytes(v)
        if isinstance(v, bool):
            return b'\x01\0\0\0' if v else b'\0\0\0\0'
        if isinstance(v, int):
            return struct.pack('<i', int32(v)) if -2 ** 31 <= v < 2 ** 31 else struct.pack('<q', v)
        if isinstance(v, float):
            return struct.pack('<d', v)
        raise AssertionError(v)

    def _append(self, env, args, raws):
        container = self.ev(args[0], env)
        assert isinstance(container, list), ('加入成员 needs an array', raws[0])
        kind = self.declared(raws[0].strip(), env)[0] if args[0][0] == 'var' else None
        value = self.ev(args[1], env)
        container.append(wrap(value, kind) if kind in DEFAULTS else deepcopy(value))

    def _redim(self, env, args, raws):
        container = self.ev(args[0], env)
        keep = self.ev(args[1], env)
        count = self.ev(args[2], env)
        assert isinstance(container, list) and isinstance(keep, bool) and count >= 0, (raws, keep, count)
        kind = self.declared(raws[0].strip(), env)[0] if args[0][0] == 'var' else None
        fresh = self.new_value(kind, None)
        value = (container[:count] + [deepcopy(fresh) for _ in range(count - len(container))]) if keep else [deepcopy(fresh) for _ in range(count)]
        self.store(raws[0], value, env)

    def _bytes_data(self, env, args, raws):
        data = self.ev(args[0], env)
        kind = self.ev(args[1], env)
        position = self.ev(args[2], env) if len(args) > 2 else None
        position = 1 if position is None else position
        size = TYPE_SIZE[kind]
        assert 1 <= position and position - 1 + size <= len(data), ('取字节集数据 out of range', position, size, len(data))
        chunk = bytes(data[position - 1:position - 1 + size])
        value = {'字节型': lambda c: c[0], '短整数型': lambda c: struct.unpack('<h', c)[0], '整数型': lambda c: struct.unpack('<i', c)[0],
                 '长整数型': lambda c: struct.unpack('<q', c)[0], '小数型': lambda c: struct.unpack('<f', c)[0],
                 '双精度小数型': lambda c: struct.unpack('<d', c)[0]}[kind](chunk)
        if len(raws) > 2 and is_lvalue(raws[2]):   # a variable given as the position moves to the next read
            nxt = position + size
            self.store(raws[2], nxt if nxt <= len(data) else -1, env)
        return value
