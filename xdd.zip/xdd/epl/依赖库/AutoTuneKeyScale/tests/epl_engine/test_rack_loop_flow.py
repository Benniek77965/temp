#!/usr/bin/env python3
"""Run the real rack-link thread loop body pass by pass with a scripted host.

The other engine tests execute extracted fragments. This one runs the whole loop body of
机架引擎_线程_联动 for several passes, so ordering across blocks is covered:

A  operator-policy denial: hidden and stopped once, then no host calls (no auth retries), one log line;
A2 a re-login while the out-of-lock policy decision is read: that decision is discarded and the new
   credentials are tried before hiding;
A3 any other denial keeps showing "authorization denied" and keeps the session;
B  strength: first shown from the plug-in, an in-assistant drag is sent once and stale readback is
   ignored until the plug-in confirms, a later change made in the plug-in is followed, and the next
   song change carries the plug-in's value back to the bridge, not the old drag.

EPL semantics kept by the harness: locals live for the whole thread function (initialised once),
struct assignment copies. Host, bridge, clock and the song monitor are substitutes; this is not an
EPL compiler, Win32 or real-rack test.
"""
from pathlib import Path
from types import SimpleNamespace
import argparse
import copy
import hashlib
import json
import re

import check as syntax
import review_regression as regression

ROOT = Path(__file__).resolve().parents[2]
MODULE = ROOT.parents[1] / '模块/模块_电音助手.e~'
ENGINE = MODULE / '代码/程序集_机架联动引擎.static.e.txt'
TYPES = MODULE / '自定义类型.e.txt'
NORMALIZE = '赋值 (局_已知, 机架引擎_规范基调 (局_快照.基调, 局_快照.音阶, 局_快照.移调, 局_键, 局_音阶编号, 局_显示调))'
DEFAULTS = {'文本型': '', '字节集': b'', '逻辑型': False, '整数型': 0, '长整数型': 0, '小数型': 0.0, '双精度小数型': 0.0}


class Continue(Exception):
    pass


def signed(value):
    return value - (1 << 32) if value >= (1 << 31) else value


class Loop:
    """One link thread: program-set state plus the loop locals in one env, advanced pass by pass."""

    def __init__(self, source, types, host):
        link = syntax.section(source, '机架引擎_线程_联动')
        lines = link.split('\n')
        start = next(i for i, line in enumerate(lines) if line.strip() == '.判断循环首 (真)')
        depth = 0
        for end in range(start, len(lines)):
            text = lines[end].strip()
            depth += text.startswith('.判断循环首')
            depth -= text.startswith('.判断循环尾')
            if depth == 0:
                break
        body = '\n'.join(line[4:] if line.startswith('    ') else line for line in lines[start + 1:end])
        assert body.count(NORMALIZE) == 1, 'key normalization call moved; update the harness'
        self.nodes = syntax.parse_block(body.replace(NORMALIZE, '赋值 (局_已知, 测试_规范基调 ())').splitlines())[0]
        self.rt = regression.engine_runtime(source)
        env = self.rt.env
        block = types.split('.数据类型 自定义_机架联动快照', 1)[1].split('\n.数据类型 ', 1)[0]
        env['集_机架_快照'] = SimpleNamespace(**{name: DEFAULTS.get(kind, 0)
                                               for name, kind in re.findall(r'^\s*\.成员 ([^,]+), ([^,]+),', block, re.M)})
        env['集_机架_快照'].已同意 = env['集_机架_快照'].自动切换 = True
        env['集_机架_快照'].当前强度 = -1
        env['集_机架_快照'].音乐名W = b'x'   # a song is playing: components are prepared only then (see lazy:*)
        env.update({'集_机架_运行': True, '集_机架_系统支持': True, '集_机架_允许连接': True, '集_机架_服务未开放': False,
                    '集_机架_界面已显示': True,   # the 电音助手 window is on screen (the bridge is prepared only then, see window:*)
                    '集_机架_已配置': False, '集_机架_配置重试时间': 0, '集_机架_配置退避': 0, '集_机架_重新配置': False,
                    '集_机架_停止请求': False, '集_机架_自检请求': False, '集_机架_强度请求': False,
                    '集_机架_目标版本': 1, '集_机架_已发版本': -1, '集_机架_歌曲世代': 1, '集_机架_已查版本': 1,
                    '集_机架_查询版本': 1, '集_机架_强度已设置': False, '集_机架_强度待确认': False})
        for name, kind in re.findall(r'^\.程序集变量 ([^,]+), ([^,]+),', source, re.M):
            env.setdefault(name, DEFAULTS.get(kind, 0))
        for name, kind in re.findall(r'^\.局部变量 ([^,]+), ([^,]+),', link, re.M):
            env.setdefault(name, DEFAULTS.get(kind, 0))
        assign = self.rt.assign
        self.rt.assign = lambda name, value, scope: assign(
            name, copy.deepcopy(value) if isinstance(value, SimpleNamespace) else value, scope)
        self.host, self.calls, self.logs, self.clock = host, [], [], [10_000]
        self.known, self.policy = None, (lambda: False)

        def normalize():
            if self.known is None:
                return False
            env['局_键'], env['局_音阶编号'], env['局_显示调'] = self.known
            return True

        def host_call(op, a=None, b=None, c=None, d=None):
            self.calls.append((op, a, b, c, d))
            return self.host(self, op, a, b, c, d)

        def next_pass(*_):
            raise Continue()

        self.rt.functions.update({
            '测试_规范基调': normalize, '机架引擎_宿主调用': host_call, '机架引擎_监测一次': lambda: None,
            '机架引擎_毫秒': lambda: self.clock[0], '机架引擎_经过': lambda began: self.clock[0] - began,
            '机架引擎_记日志': self.logs.append, '延时': lambda ms: None, '到循环尾': next_pass,
            '机架引擎_策略未开放': lambda: self.policy(), '取绝对值': abs, '右移': lambda value, n: (value % (1 << 32)) >> n,
            '相除': lambda left, right: left / right, '到整数': int})

    def step(self, ms=100):
        self.clock[0] += ms
        try:
            self.rt.execute(self.nodes, self.rt.env)
        except Continue:
            pass
        assert self.rt.depth == 0, 'engine lock left held'
        ops = [call[0] for call in self.calls]
        self.calls_last, self.calls = list(self.calls), []
        return ops


def host_with(error, feel=lambda: 0x80000000, apply_ok=0):
    def host(loop, op, a, b, c, d):
        return {1: 1, 16: 1, 2: 1, 3: apply_ok, 4: 1, 9: 1, 5: signed(0x80000000), 13: error,
                10: signed(feel()), 7: 1, 8: 1}.get(op, 0)
    return host


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    source = ENGINE.read_text(encoding='utf-8-sig').replace('\r\n', '\n')
    types = TYPES.read_text(encoding='utf-8-sig').replace('\r\n', '\n')
    checks, failures = [], []

    def check(name, condition):
        checks.append(name)
        if not condition:
            failures.append(name)

    # ---- L: components are written only when actually needed ------------------------------
    # Consent and auto-switch alone do not prepare the bridge (op1 writes the bridge, and the bridge
    # writes the managed controller): only once the player reports a song. Once prepared it stays.
    loop = Loop(source, types, host_with(0))
    loop.rt.env['集_机架_快照'].音乐名W = b''
    idle = [loop.step() for _ in range(3)]
    # Only op13 (error query) runs: with no bridge loaded the host answers it without preparing anything;
    # op1 is the one call that writes and loads the bridge (checked in test_host_bridge_deploy).
    check('lazy:no_preparation_before_a_song', all(set(ops) <= {13} for ops in idle) and loop.rt.env['集_机架_已配置'] is False)
    loop.rt.env['集_机架_快照'].音乐名W = b'x'
    first = loop.step()
    check('lazy:song_prepares_components', first[:1] == [1] and loop.rt.env['集_机架_已配置'] is True)
    loop.rt.env['集_机架_快照'].音乐名W = b''
    later = [loop.step() for _ in range(3)]
    check('lazy:song_stopping_neither_unloads_nor_reprepares', all(1 not in ops and 7 not in ops for ops in later) and loop.rt.env['集_机架_已配置'] is True)

    # ---- W: the bridge is prepared (downloaded) only once the 电音助手 window is on screen ----------------
    # Otherwise the download would finish while the window is still loading and its notice would never be seen.
    loop = Loop(source, types, host_with(0))
    loop.rt.env['集_机架_界面已显示'] = False
    hidden = [loop.step() for _ in range(3)]
    check('window:no_preparation_until_the_window_shows', all(1 not in ops for ops in hidden) and loop.rt.env['集_机架_已配置'] is False)
    loop.rt.env['集_机架_界面已显示'] = True
    shown = loop.step()
    check('window:prepares_once_the_window_shows', shown[:1] == [1] and loop.rt.env['集_机架_已配置'] is True)

    # ---- A: operator policy denial ---------------------------------------------------------
    loop = Loop(source, types, host_with(3))
    loop.policy = lambda: True
    passes = [loop.step() for _ in range(5)]
    env = loop.rt.env
    check('policy:first_pass_authorises_then_hides', passes[0][:1] == [1] and 13 in passes[0] and env['集_机架_服务未开放'] is True)
    check('policy:next_pass_only_stops', passes[1] == [7] and env['集_机架_已配置'] is False)
    check('policy:no_host_calls_afterwards', passes[2:] == [[], [], []])
    check('policy:status_hidden_throughout', env['集_机架_快照'].状态编号 == 22 and env['集_机架_停止请求'] is False)
    check('policy:logged_once', len(loop.logs) == 1 and '服务端策略未向本设备开放联动' in loop.logs[0])

    # ---- A2: re-login while the decision is read ---------------------------------------------
    loop = Loop(source, types, host_with(3))
    first = [True]

    def racing_policy():
        if first[0]:
            first[0] = False
            loop.rt.env['集_机架_重新配置'] = True   # 机架引擎_重新连接 ran on the UI thread meanwhile
        return True

    loop.policy = racing_policy
    passes, states = [], []
    for _ in range(4):
        passes.append(loop.step())
        states.append((loop.rt.env['集_机架_服务未开放'], loop.rt.env['集_机架_快照'].状态编号))
    check('relogin:stale_decision_discarded', states[0] == (False, 19) and len(loop.logs) == 1)
    check('relogin:new_credentials_tried_before_hiding', passes[1][:2] == [8, 1] and states[1] == (True, 22))
    check('relogin:then_stopped_and_idle', passes[2] == [7] and passes[3] == [])

    # ---- A3: other denials still surface ------------------------------------------------------
    loop = Loop(source, types, host_with(3))
    for _ in range(3):
        loop.step()
    env = loop.rt.env
    check('other_denial:shown_kept_not_hidden', env['集_机架_快照'].状态编号 == 19 and env['集_机架_服务未开放'] is False
          and env['集_机架_停止请求'] is False and env['集_机架_已配置'] is True and not loop.logs)

    # ---- B: strength follows the plug-in -----------------------------------------------------
    plugin = {'value': 500}
    loop = Loop(source, types, host_with(0, feel=lambda: 0x80000000 | 0x40000000 | 0x20000000 | plugin['value'], apply_ok=1))
    loop.known = (0, 0, 'C')
    loop.rt.env['集_机架_快照'].音乐名W, loop.rt.env['集_机架_快照'].基调 = b'x', 'C'
    snap = lambda: loop.rt.env['集_机架_快照']
    sent = lambda op: [call[3] if op == 3 else call[1] for call in loop.calls_last if call[0] == op]
    loop.step()
    check('strength:shown_from_plugin_without_writing', snap().当前强度 == 500 and sent(3) == [-1] and sent(4) == [])
    loop.rt.invoke('机架引擎_电音强度', 70, 100)
    loop.step()
    check('strength:drag_sent_once_stale_readback_ignored', sent(4) == [700] and snap().当前强度 == 700
          and loop.rt.env['集_机架_强度待确认'] is True)
    plugin['value'] = 700
    loop.step()
    check('strength:confirmed_by_plugin', loop.rt.env['集_机架_强度待确认'] is False and sent(4) == [])
    plugin['value'] = 300
    loop.step()
    check('strength:change_in_plugin_followed', snap().当前强度 == 300)
    loop.rt.env['集_机架_目标版本'] += 1
    loop.step()
    check('strength:song_change_carries_plugin_value', sent(3) == [300])
    plugin['value'] = 900
    loop.rt.invoke('机架引擎_电音强度', 20, 100)
    loop.clock[0] += 3000
    loop.step()
    check('strength:unconfirmed_drag_gives_way_after_3s', snap().当前强度 == 900 and loop.rt.env['集_机架_强度待确认'] is False)

    result = {'checks': len(checks), 'passed': len(checks) - len(failures), 'failures': failures,
              'source_sha256': {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in (ENGINE, TYPES)},
              'scope': 'Whole link-thread loop body on the shared evaluator; host, bridge, clock and song monitor are substitutes'}
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
