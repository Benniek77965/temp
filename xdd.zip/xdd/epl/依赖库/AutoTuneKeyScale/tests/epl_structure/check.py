#!/usr/bin/env python3
"""Check changed EPL exports against the previous delivered ZIP.

This checks text/export invariants, not EPL typechecking, linking or compilation.
Comments beginning with apostrophe are never treated as executable statements;
original commented control lines must remain verbatim and in the same order.
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import zipfile
import zlib

OPEN = {'如果真': '如果真结束', '如果': '如果结束', '判断开始': '判断结束',
        '计次循环首': '计次循环尾', '判断循环首': '判断循环尾',
        '循环判断首': '循环判断尾', '变量循环首': '变量循环尾'}
CLOSE = set(OPEN.values())
CONTROL = set(OPEN) | CLOSE | {'否则', '判断', '默认', '到循环尾', '跳出循环'}
TOKEN = re.compile(r'^\s*(\.[^\s(]+)')
COMMENT_CONTROL = re.compile(r"^\s*'+\s*\.([^\s(]+)")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def remove_strings(line):
    result = []
    quote = None
    for char in line:
        if quote:
            if char == quote:
                quote = None
            continue
        if char == '“':
            quote = '”'
        elif char == '"':
            quote = '"'
        elif char == "'":
            break
        else:
            result.append(char)
    return ''.join(result), quote is not None


def structure(text):
    issues, stack = [], []
    procedure = '<global>'
    for number, line in enumerate(text.splitlines(), 1):
        if not line.strip() or line.lstrip().startswith("'"):
            continue
        token = TOKEN.match(line)
        word = token[1][1:] if token else ''
        if word in ('子程序', '程序集'):
            for opened, origin in stack:
                issues.append({'line': origin, 'message': f'{procedure}: unclosed {opened}'})
            stack.clear()
            procedure = line.strip().split(',', 1)[0]
        if word in OPEN:
            stack.append((word, number))
        elif word in CLOSE:
            if not stack or OPEN[stack[-1][0]] != word:
                issues.append({'line': number, 'message': f'{procedure}: unmatched {word}'})
            else:
                stack.pop()
        elif word == '否则':
            if not stack or stack[-1][0] != '如果':
                issues.append({'line': number, 'message': f'{procedure}: 否则 outside 如果'})
        elif word in ('判断', '默认'):
            if not stack or stack[-1][0] != '判断开始':
                issues.append({'line': number, 'message': f'{procedure}: {word} outside 判断开始'})
        # Every call/control statement stays on one physical source line.
        clean, unterminated = remove_strings(line)
        if '(' in clean or ')' in clean:
            level = 0
            bad = False
            for char in clean:
                level += 1 if char == '(' else -1 if char == ')' else 0
                if level < 0:
                    bad = True
            if bad or level:
                issues.append({'line': number, 'message': f'{procedure}: parentheses cross a physical line'})
        if unterminated:
            issues.append({'line': number, 'message': f'{procedure}: string crosses a physical line'})
    for opened, origin in stack:
        issues.append({'line': origin, 'message': f'{procedure}: unclosed {opened}'})
    return issues


def commented_controls(text):
    return [line for line in text.splitlines() if (m := COMMENT_CONTROL.match(line)) and m[1] in CONTROL]


def is_subsequence(old, new):
    iterator = iter(new)
    return all(any(candidate == line for candidate in iterator) for line in old)


def symbols(value):
    found = []
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('Order', 'Class') and isinstance(item, list):
                found.extend(x for x in item if isinstance(x, str))
            found.extend(symbols(item))
    elif isinstance(value, list):
        for item in value:
            found.extend(symbols(item))
    return found


def nearest_desc(path):
    for parent in path.parents:
        candidate = parent / '目录.desc.json'
        if candidate.is_file():
            return candidate
    return None


def check(tree, baseline):
    tree = tree.resolve()
    errors, legacy, checked, new_files = [], [], [], []
    with zipfile.ZipFile(baseline, metadata_encoding='gbk') as archive:
        old = {i.filename: archive.read(i) for i in archive.infolist() if not i.is_dir()}
    for path in sorted(tree.rglob('*')):
        if not path.is_file():
            continue
        name = tree.name + '/' + path.relative_to(tree).as_posix()   # 包里的顶层目录＝工程目录名（项目 A 是 xhh，项目 B 是 xdd）
        data = path.read_bytes()
        if old.get(name) == data:
            continue
        if '/依赖库/' in name:
            continue
        new = name not in old
        if new:
            new_files.append(name)
        if name.endswith('.e.txt'):
            before = old.get(name, b'')
            if not data.startswith(b'\xef\xbb\xbf'):
                errors.append({'file': name, 'message': 'EPL export must retain UTF-8 BOM'})
            if b'\n' in data.replace(b'\r\n', b'') or b'\r' in data.replace(b'\r\n', b''):
                errors.append({'file': name, 'message': 'EPL export must use CRLF exclusively'})
            try:
                text = data.decode('utf-8-sig')
                oldtext = before.decode('utf-8-sig')
            except UnicodeDecodeError as error:
                errors.append({'file': name, 'message': 'EPL UTF-8 decoding failed: ' + str(error)})
                continue
            before_issues = structure(oldtext)
            after_issues = structure(text)
            prior_count = Counter(i['message'] for i in before_issues)
            for issue in after_issues:
                if prior_count[issue['message']]:
                    prior_count[issue['message']] -= 1
                    legacy.append({'file': name, **issue})
                else:
                    errors.append({'file': name, **issue})
            if not is_subsequence(commented_controls(oldtext), commented_controls(text)):
                errors.append({'file': name, 'message': 'Original apostrophe-commented control structure removed or reordered'})
            if new and any(path.name.endswith(suffix) for suffix in ('.static.e.txt', '.class.e.txt', '.form.e.txt')):
                desc = nearest_desc(path)
                match = re.search(r'^\.程序集\s+([^,\r\n]+)', text, flags=re.M)
                if desc is None or match is None:
                    errors.append({'file': name, 'message': 'New assembly lacks directory descriptor or assembly declaration'})
                else:
                    registered = symbols(json.loads(desc.read_text(encoding='utf-8-sig')))
                    if match[1].strip() not in registered:
                        errors.append({'file': name, 'message': 'New assembly not registered in ' + str(desc.relative_to(tree))})
            checked.append({'file': name, 'new': new, 'sha256': sha(data), 'lines': len(text.splitlines()), 'baseline_comment_controls': len(commented_controls(oldtext))})
        elif path.name in ('目录.desc.json', '资源.desc.json'):
            try:
                current = json.loads(data.decode('utf-8-sig'))
                prior = json.loads(old.get(name, b'{}').decode('utf-8-sig'))
                if path.name == '目录.desc.json':
                    added = set(symbols(current)) - set(symbols(prior))
                    declared = set()
                    for candidate in path.parent.rglob('*.e.txt'):
                        match = re.search(r'^\.程序集\s+([^,\r\n]+)', candidate.read_text(encoding='utf-8-sig'), flags=re.M)
                        if match:
                            declared.add(match[1].strip())
                    for symbol in sorted(added - declared):
                        errors.append({'file': name, 'message': 'New directory registration has no assembly export: ' + symbol})
                else:
                    added = {r.get('Name') for r in current.get('Resources', [])} - {r.get('Name') for r in prior.get('Resources', [])}
                    for resource in sorted(added):
                        candidates = [path.parent / (resource + suffix) for suffix in ('.txt', '.Image.dat', '.Data.dat', '.Sound.dat', '.Menu.dat')]
                        if not any(candidate.is_file() for candidate in candidates):
                            errors.append({'file': name, 'message': 'New resource registration has no resource bytes: ' + resource})
            except (UnicodeDecodeError, json.JSONDecodeError) as error:
                errors.append({'file': name, 'message': 'Invalid export descriptor: ' + str(error)})
        elif new and '/资源/' in name and path.name != '资源.desc.json':
            desc = path.parent / '资源.desc.json'
            resource = re.sub(r'\.(?:Image|Data|Sound|Menu)\.dat$|\.txt$', '', path.name)
            if not desc.is_file() or resource not in {r.get('Name') for r in json.loads(desc.read_text(encoding='utf-8-sig')).get('Resources', [])}:
                errors.append({'file': name, 'message': 'New resource not registered in 资源.desc.json'})
            if data.startswith(b'\x0d\x0f\x3e\x03'):
                try:
                    unpacked = zlib.decompress(data[8:])
                    declared = int.from_bytes(data[4:8], 'little')
                    if len(unpacked) != declared:
                        raise ValueError('uncompressed size differs')
                except (zlib.error, ValueError) as error:
                    errors.append({'file': name, 'message': 'Invalid EPL ZLIB resource: ' + str(error)})
    return {'status': 'passed' if not errors else 'failed', 'scope': 'changed EPL exports and new resources only',
            'compiler_validation': False, 'baseline_sha256': sha(Path(baseline).read_bytes()),
            'checked_epl': checked, 'new_project_files': new_files, 'errors': errors,
            'unchanged_legacy_issues': legacy,
            'limitations': ['Not an EPL compiler/typechecker/linker', 'Existing baseline issues are listed separately; newly introduced issues fail', 'Original comments are reference text, never execution instructions']}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--tree', type=Path, required=True)
    ap.add_argument('--baseline', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    result = check(args.tree, args.baseline)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'checked_epl': len(result['checked_epl']), 'errors': result['errors'], 'unchanged_legacy_issues': len(result['unchanged_legacy_issues']), 'compiler_validation': False}, ensure_ascii=False, indent=2))
    return 0 if not result['errors'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
