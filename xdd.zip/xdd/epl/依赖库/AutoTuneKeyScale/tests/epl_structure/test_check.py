#!/usr/bin/env python3
"""Behavior fixtures for the EPL export checker; no EPL implementation is copied."""
import importlib.util
import json
from pathlib import Path
import tempfile
import zipfile

p = Path(__file__).with_name('check.py')
spec = importlib.util.spec_from_file_location('epl_check', p)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def encode(text):
    return b'\xef\xbb\xbf' + text.replace('\n', '\r\n').encode('utf-8')


def main():
    text = ".程序集 示例, , ,\n'.如果真 (真)\n    ' 返回 (假)\n.子程序 入口\n.如果真 (真)\n    返回 (真)\n.如果真结束\n"
    with tempfile.TemporaryDirectory(prefix='epl-check-', dir=Path.cwd()) as d:
        root = Path(d)
        tree = root / 'xhh'
        code = tree / 'epl' / '代码'
        resources = tree / 'epl' / '资源'
        code.mkdir(parents=True); resources.mkdir()
        source = code / '示例.static.e.txt'
        desc = code / '目录.desc.json'
        source.write_bytes(encode(text))
        desc.write_text(json.dumps({'Dirs': [], 'Order': ['示例']}, ensure_ascii=False), encoding='utf-8')
        base = root / 'base.zip'
        with zipfile.ZipFile(base, 'w') as archive:
            archive.write(source, 'xhh/epl/代码/' + source.name)
            archive.write(desc, 'xhh/epl/代码/' + desc.name)
        source.write_bytes(encode(text + "' 新注释\n"))
        assert module.check(tree, base)['status'] == 'passed'
        source.write_bytes(encode(text.replace('.如果真结束\n', '')))
        assert any('unclosed 如果真' in e['message'] for e in module.check(tree, base)['errors'])
        source.write_bytes(encode(text.replace("'.如果真 (真)\n", '')))
        assert any('commented control' in e['message'] for e in module.check(tree, base)['errors'])
        source.write_bytes(encode(text + '赋值 (a,\n    1)\n'))
        assert any('physical line' in e['message'] for e in module.check(tree, base)['errors'])
        source.write_bytes(text.encode('utf-8'))
        errors = module.check(tree, base)['errors']
        assert any('BOM' in e['message'] for e in errors) and any('CRLF' in e['message'] for e in errors)
        source.write_bytes(encode(text))
        new_source = code / '新增.static.e.txt'
        new_source.write_bytes(encode('.程序集 新增, , ,\n.子程序 入口\n返回 ()\n'))
        assert any('not registered' in e['message'] for e in module.check(tree, base)['errors'])
        desc.write_text(json.dumps({'Order': ['示例','新增','幽灵']}, ensure_ascii=False), encoding='utf-8')
        assert any('幽灵' in e['message'] for e in module.check(tree, base)['errors'])
        desc.write_text(json.dumps({'Order': ['示例','新增']}, ensure_ascii=False), encoding='utf-8')
        (resources / '资源.desc.json').write_text(json.dumps({'Resources': [{'Name':'桥'}]}, ensure_ascii=False), encoding='utf-8')
        assert any('no resource bytes' in e['message'] for e in module.check(tree, base)['errors'])
        (resources / '桥.Image.dat').write_bytes(b'\x0d\x0f\x3e\x03\xff\x00\x00\x00bad zlib')
        assert any('ZLIB' in e['message'] for e in module.check(tree, base)['errors'])
    print('PASS: active/control comments, single-line calls, BOM/CRLF, bidirectional descriptor registration and binary-resource integrity')


if __name__ == '__main__':
    main()
