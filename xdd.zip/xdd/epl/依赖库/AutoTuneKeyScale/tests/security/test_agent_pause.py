"""Execute production signed-mailbox pause barriers and delayed parameter gates.
The harness uses real channel encryption/MAC/sequence validation and extracted
Agent functions. OS atomics, clocks, plug-in calls and status I/O are explicit
boundaries; this is not a Windows/DAW execution test.
"""
from pathlib import Path
from test_bridge_logic import ROOT, extract


def write_harness(path):
    source=(ROOT/'combined/at_agent.cpp').read_text(encoding='utf-8')
    code=r'''
#include "companion_mailbox.h"
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string>
#include <thread>
#include <mutex>
#include <condition_variable>
typedef int32_t LONG;
#define AT_XHH_MANAGED 1
#define LOG(...) ((void)0)
#define UIQ 4
#define UIPH_FREE 0
#define UIPH_POST 1
#define UIPH_RUN 2
#define UIPH_DONE 3
#define UIW(g,p) ((LONG)(((g)<<2)|(p)))
#define UIPH(w) ((w)&3)
#define UIGEN(w) ((w)>>2)
static volatile LONG g_parameterPaused=1,g_parameterEpoch=1,g_ejecting=0,g_uiExecuting=0;
static struct{volatile LONG word;}g_uiQ[UIQ];
static LONG InterlockedCompareExchange(volatile LONG*p,LONG n,LONG e){__atomic_compare_exchange_n(p,&e,n,false,__ATOMIC_SEQ_CST,__ATOMIC_SEQ_CST);return e;}
static LONG InterlockedExchange(volatile LONG*p,LONG n){return __atomic_exchange_n(p,n,__ATOMIC_SEQ_CST);}
static LONG InterlockedIncrement(volatile LONG*p){return __atomic_add_fetch(p,1,__ATOMIC_SEQ_CST);}
static ATCS_PauseBarrier g_pauseBarrier={0,1};
static uint64_t g_authSequences[4]={},g_authRetuneSequence=0;
static ATCS_Claims g_authLease;
static int g_authInstalled=1,g_cs=0;
static bool leaseAlive=true;
static unsigned checks=0,failures=0;
#define CHECK(c) do{checks++;if(!(c)){printf("FAIL pause line%u: %s\n",(unsigned)__LINE__,#c);failures++;}}while(0)
static void EnterCriticalSection(int*p){++*p;}static void LeaveCriticalSection(int*p){--*p;}
static int agent_lease_alive(){return leaseAlive;}
static int agent_policy_ui_allowed(const void*,const char*){return leaseAlive;}
'''
    code+='\n'.join(extract(source,x) for x in ('static int agent_parameter_ready(', 'static int agent_write_allowed(', 'static void agent_cancel_posted_writes(){', 'static void agent_publish_pause(', 'static int agent_pause_status(char* out,unsigned capacity){'))+'\n'
    code+=r'''
static unsigned writes=0,reloads=0,publications=0;
static int lastKey=-1;static std::string lastScale,ack;
static double g_fRet=-1,g_fSpeed=-1,g_fHum=-1,g_fNvb=-1;static int g_fAudio=-1;
static void cmd_side_effects(const char* line){if(strstr(line,"reload=scalemap"))reloads++;}
static void parse_target(const char*){}
static void write_status(){publications++;char text[128];int n=agent_pause_status(text,sizeof text);ack.assign(text,n);}
static void do_set(int key,const char* scale){CHECK(agent_parameter_ready());writes++;lastKey=key;lastScale=scale;}
'''
    code+='\n'.join(extract(source,x) for x in ('static int cmd_line_complete(', 'static double parse_num(', 'static double clamp01(', 'static void agent_apply_command(', 'static void agent_consume_commands('))+'\n'
    code+=r'''
typedef unsigned ParamID;
struct IEditController;
struct IEditControllerVtbl {int (*setParamNormalized)(IEditController*,ParamID,double);};
struct IEditController{IEditControllerVtbl* vtbl;};
struct IComponentHandler;
struct IComponentHandlerVtbl {int(*beginEdit)(IComponentHandler*,ParamID);int(*performEdit)(IComponentHandler*,ParamID,double);int(*endEdit)(IComponentHandler*,ParamID);};
struct IComponentHandler{IComponentHandlerVtbl*vtbl;};
struct CHBinding{void*handler;DWORD ownerTid;};
static CHBinding binding;static CHBinding*g_handlerHeld=NULL;static DWORD g_handlerHeldTid=0;
static unsigned valueWrites=0,begins=0,performs=0,ends=0;
static void(*acquireHook)()=NULL;
static void(*writeHook)()=NULL;
static DWORD GetCurrentThreadId(){return 1;}
static CHBinding*handler_binding_acquire(IEditController*){if(acquireHook)acquireHook();return &binding;}
static int handler_binding_current(IEditController*,CHBinding*){return 1;}
static int setNormalized(IEditController*,ParamID,double){valueWrites++;if(writeHook)writeHook();return 0;}
static int begin(IComponentHandler*,ParamID){begins++;return 0;}
static int perform(IComponentHandler*,ParamID,double){performs++;return 0;}
static int end(IComponentHandler*,ParamID){ends++;return 0;}
'''
    code+=extract(source,'static void v3set_body(')+'\n'
    code+=r'''
static void reset(){g_pauseBarrier={0,1};memset(g_authSequences,0,sizeof g_authSequences);g_authRetuneSequence=0;g_parameterPaused=1;g_parameterEpoch=1;g_ejecting=0;g_uiExecuting=0;leaseAlive=true;writes=reloads=publications=0;lastKey=-1;lastScale.clear();ack.clear();memset(g_uiQ,0,sizeof g_uiQ);memset(&g_authLease,0,sizeof g_authLease);memset(g_authLease.key,0x5a,32);strcpy(g_authLease.sid,"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");g_authLease.expires=atcs_now()+120;g_authInstalled=1;valueWrites=begins=performs=ends=0;acquireHook=writeHook=NULL;}
static std::string seal(unsigned slot,uint64_t seq,const char* plain){char out[4096];CHECK(atcs_channel_seal(g_authLease.key,slot,g_authLease.sid,seq,g_authLease.expires,plain,(unsigned)strlen(plain),out,sizeof out));return out;}
static unsigned consume(const std::string& cmd="",const std::string& feel="",const std::string& control=""){
 const char* inputs[]={cmd.c_str(),feel.c_str(),control.c_str()};unsigned lengths[]={(unsigned)cmd.size(),(unsigned)feel.size(),(unsigned)control.size()};ATCS_Mailbox ready[3];memset(ready,0,sizeof ready);unsigned n=atcs_mailbox_decode(g_authLease.key,g_authLease.sid,g_authLease.expires,g_authSequences,inputs,lengths,3,ready,3);char last[1025]="";agent_consume_commands(ready,n,last);CHECK(g_cs==0);return n;}
static void pause_resume(){agent_publish_pause(1);agent_publish_pause(0);}
static void pause_only(){agent_publish_pause(1);}
static std::mutex mutex;static std::condition_variable cv;static bool entered=false,releaseThread=false;
static void wait_in_handler(){std::unique_lock<std::mutex> lock(mutex);entered=true;cv.notify_all();cv.wait(lock,[]{return releaseThread;});}
int main(){
 reset();CHECK(!agent_parameter_ready());CHECK(consume(seal(0,1,"key=3|scale=Minor|t=1\n"))==1);CHECK(writes==1&&!g_parameterPaused&&g_pauseBarrier.sequence==1);LONG oldEpoch=g_parameterEpoch;
 g_uiQ[0].word=UIW(3,UIPH_POST);g_uiQ[1].word=UIW(4,UIPH_RUN);
 std::string oldCommand=seal(0,2,"key=4|scale=Major|t=2\n"),oldFeel=seal(1,3,"retune=0.7|t=3\n"),pause=seal(2,4,"pause=1|t=4\n");
 CHECK(consume(oldCommand,oldFeel,pause)==3);CHECK(writes==1&&g_parameterPaused&&g_pauseBarrier.sequence==4);CHECK(g_authSequences[0]==2&&g_authSequences[1]==3&&g_authSequences[2]==4);CHECK(publications==2&&ack=="#pause sid=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa seq=4 state=1\n");CHECK(!agent_parameter_ready(oldEpoch));CHECK(UIPH(g_uiQ[0].word)==UIPH_FREE&&UIPH(g_uiQ[1].word)==UIPH_RUN);
 CHECK(consume(oldCommand,oldFeel,pause)==0&&writes==1);CHECK(consume("",seal(1,5,"retune=0.9|t=5\n"))==1&&writes==1&&g_parameterPaused);
 CHECK(consume(seal(0,6,"key=9|scale=Chromatic|t=6\n"))==1);CHECK(writes==2&&lastKey==9&&lastScale=="Chromatic"&&!g_parameterPaused);CHECK(!agent_parameter_ready(oldEpoch));CHECK(consume("","",seal(2,5,"pause=1|t=5\n"))==1);CHECK(!g_parameterPaused&&writes==2&&g_pauseBarrier.sequence==6);
 /* A delayed old independent-channel command is still rejected after resume. */
 reset();CHECK(consume("","",seal(2,50,"pause=1|t=50\n"))==1);CHECK(consume(seal(0,40,"key=1|scale=Minor|t=40\n"))==1&&writes==0&&g_parameterPaused);CHECK(consume(seal(0,60,"key=7|scale=Major|t=60\n"))==1&&writes==1);CHECK(consume("",seal(1,45,"retune=0.1|t=45\n"))==1&&writes==1);CHECK(consume("",seal(1,61,"retune=0.2|t=61\n"))==1&&writes==2);
 /* Pause-before-resume ordering is independent of filename iteration, and a
    control reload is neither a parameter write nor an implicit resume. */
 reset();CHECK(consume(seal(0,20,"key=5|scale=Minor|t=20\n"),seal(1,19,"retune=0.3|t=19\n"),seal(2,10,"pause=1|t=10\n"))==3);CHECK(writes==1&&lastKey==5&&!g_parameterPaused&&g_pauseBarrier.sequence==20);CHECK(consume("","",seal(2,21,"reload=scalemap|t=21\n"))==1&&reloads==1&&writes==1);
 /* Wrong-channel or malformed pause data never becomes an accepted barrier. */
 reset();CHECK(consume("",seal(1,1,"pause=1|t=1\n"))==1&&g_pauseBarrier.sequence==0);const char* bad[]={"pause=0|t=2\n","pause=1|t=\n","pause=1|t=-1\n","pause=1|t=1|key=2\n","pause=1|t=1x\n"};for(unsigned i=0;i<sizeof bad/sizeof bad[0];i++){CHECK(consume("","",seal(2,2+i,bad[i]))==1);CHECK(g_pauseBarrier.sequence==0&&writes==0);}
 ATCS_Mailbox invalid;memset(&invalid,'x',sizeof invalid);invalid.slot=2;invalid.sequence=9;CHECK(!atcs_mailbox_is_pause(&invalid));invalid.slot=0;CHECK(!atcs_mailbox_full_target(&invalid));
 const char* malformedTargets[]={"key=12|scale=Major|t=8\n","key=1|scale=Unknown|t=8\n","xkey=1|scale=Major|t=8\n","key=1|t=8\n","key=1|scale=MinorExtra|t=8\n"};for(unsigned i=0;i<sizeof malformedTargets/sizeof malformedTargets[0];i++){CHECK(consume(seal(0,10+i,malformedTargets[i]))==1);CHECK(g_parameterPaused&&writes==0);}
 /* Ciphertext tampering, wrong domain, key/session/expiry and replay continue
    to fail before any pause or parameter side effect. */
 reset();std::string signedPause=seal(2,1,"pause=1|t=1\n");std::string damaged=signedPause;damaged[damaged.size()-4]=damaged[damaged.size()-4]=='a'?'b':'a';CHECK(consume("","",damaged)==0);CHECK(consume(signedPause)==0);g_authLease.key[0]^=1;CHECK(consume("","",signedPause)==0);g_authLease.key[0]^=1;g_authLease.sid[0]='b';CHECK(consume("","",signedPause)==0);g_authLease.sid[0]='a';g_authLease.expires--;CHECK(consume("","",signedPause)==0);CHECK(publications==0&&g_pauseBarrier.sequence==0);
 reset();leaseAlive=false;CHECK(consume(seal(0,1,"key=1|scale=Major|t=1\n"),"",seal(2,2,"pause=1|t=2\n"))==2);CHECK(writes==0&&publications==0&&g_authSequences[0]==0&&g_authSequences[2]==0);
 /* The actual parameter writer checks the queued epoch again after waiting
    for its handler. A fast OFF/ON cannot revive stale posted UI work. */
 reset();agent_publish_pause(0);IEditControllerVtbl vt={setNormalized};IEditController controller={&vt};IComponentHandlerVtbl hv={begin,perform,end};IComponentHandler handler={&hv};binding.handler=&handler;binding.ownerTid=1;
 LONG queued=g_parameterEpoch;v3set_body(&controller,&handler,1,.5,"waves",1,queued);CHECK(valueWrites==1&&begins==1&&performs==1&&ends==1);pause_resume();v3set_body(&controller,&handler,2,.5,"waves",1,queued);CHECK(valueWrites==1);queued=g_parameterEpoch;acquireHook=pause_resume;v3set_body(&controller,&handler,3,.5,"waves",1,queued);CHECK(valueWrites==1);acquireHook=NULL;
 queued=g_parameterEpoch;g_uiExecuting=1;acquireHook=wait_in_handler;std::thread ui([&]{v3set_body(&controller,&handler,4,.5,"waves",1,queued);});{std::unique_lock<std::mutex> lock(mutex);cv.wait(lock,[]{return entered;});}pause_resume();{std::lock_guard<std::mutex> lock(mutex);releaseThread=true;}cv.notify_all();ui.join();CHECK(valueWrites==1);acquireHook=NULL;g_uiExecuting=0;
 /* A transaction already admitted may finish its paired edit; pause is not
    a destructive rollback of a plug-in call already on its own stack. */
 queued=g_parameterEpoch;writeHook=pause_only;v3set_body(&controller,&handler,5,.5,"waves",1,queued);CHECK(valueWrites==2&&begins==2&&performs==2&&ends==2);writeHook=NULL;v3set_body(&controller,&handler,6,.5,"waves",1,g_parameterEpoch);CHECK(valueWrites==2);CHECK(!agent_write_allowed(&vt,"waves"));
 printf("agent pause production extraction checks=%u failures=%u\n",checks,failures);return failures?1:0;
}
'''
    path.write_text(code,encoding='utf-8')


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--out',required=True,type=Path)
    write_harness(parser.parse_args().out)
