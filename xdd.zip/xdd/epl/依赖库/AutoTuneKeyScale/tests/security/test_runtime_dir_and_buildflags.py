#!/usr/bin/env python3
"""Anti-false-positive layout and build flags, checked against the real sources (no compiler needed here).

Everything the rack-link native side writes or drops lives together under the MAIN PROGRAM'S OWN folder:

    全_运行库.取路径()\\                         (the EPL runtime dir)
      keyscale_rack_bridge.dll                   the bridge -- loaded by the main program, stays here
      keyscale_rack\\                             a subfolder of its own, created by the bridge
        keyscale_rack_controller(32).exe         the controller, extracted by the bridge
        at_agent(32).dll, inject(32).exe         injectors and agents, extracted by the controller
        cmd.ini, status.txt, log ...             the controller's protocol files

The subfolder keeps these one level below the main program's files, so the controller's name-pattern clean-up
can never reach them. It also keeps the injectors off %TEMP% (an exe run from %TEMP% is a top antivirus flag).

Data flow for the folder: the bridge knows the runtime dir (the main program passes it as xrb.directory), makes
runtime\\keyscale_rack, extracts the controller there, and hands that path to the controller BOTH as the process
cwd AND in the AT_XHH_DIR environment variable. The controller reads AT_XHH_DIR as its data folder (COMMDIR),
falling back to %LOCALAPPDATA% then %TEMP% only for an older bridge that does not pass it. RTDIR == COMMDIR, so
injectors and agents extract straight into keyscale_rack. Stale at8_rt folders from the two previous layouts
(%TEMP%\\at8_rt and %LOCALAPPDATA%\\AutoTune_KeyScale\\at8_rt) are cleared once, by our own file names only.

Build flags strip symbols (-Wl,-s) and drop the compiler-version string (-fno-ident) -- what actually moves the
needle on toolchain-fingerprint false positives -- and avoid -ffunction-sections/--gc-sections (measured to
balloon the static-libstdc++ controller ~4x) and --dynamicbase/--nxcompat (MinGW strips the relocation table by
default, CVE-2018-5392, so those only add a self-contradictory "claims ASLR, no reloc table" signal).
"""
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ATK = HERE.parents[1]
CTL = (ATK / 'vst3/cpp/AutoTune_KeyScale_Controller.cpp').read_text(encoding='utf-8')
BRG = (ATK / 'vst3/cpp/keyscale_rack_bridge.cpp').read_text(encoding='utf-8')
COMMON = (ATK / 'windows_build/_common.bat').read_bytes().decode('gbk')


def body(src, name):
    m = re.search(r'\n[A-Za-z].*\b' + re.escape(name) + r'\s*\([^\n]*\)\s*\{', src)
    assert m, name
    i = src.index('{', m.start())
    depth = 0
    for j in range(i, len(src)):
        if src[j] == '{':
            depth += 1
        elif src[j] == '}':
            depth -= 1
            if depth == 0:
                return src[i:j + 1]
    raise AssertionError('unbalanced ' + name)


def main():
    checks = []

    def check(name, ok):
        checks.append(name)
        assert ok, name

    # ================= bridge side =================
    child = body(BRG, 'xrb_child_dir')
    check('bridge_child_dir_is_runtime_plus_keyscale_rack', r'xrb.directory+L"\\keyscale_rack"' in child.replace(' ', ''))

    extract = body(BRG, 'xrb_extract_locked')
    check('bridge_extracts_into_child_dir', 'xrb_child_dir()' in extract and r'dir+L"\\keyscale_rack_controller.exe"' in extract.replace(' ', ''))
    check('bridge_makes_child_dir', 'CreateDirectoryW(dir.c_str()' in extract.replace(' ', ''))
    # Only the 64-bit controller ships: extract uses the CONTROLLER64 resource and never CONTROLLER32,
    # and a genuine 32-bit Windows OS (a 32-bit process NOT under WOW64) is refused with XRB_OS up front.
    check('bridge_extract_uses_only_controller64', 'CONTROLLER64' in extract and 'CONTROLLER32' not in extract)
    launch = body(BRG, 'xrb_launch')
    check('bridge_refuses_genuine_32bit_os', 'if(!win64){xrb_error(XRB_OS);returnfalse;}' in launch.replace(' ', ''))
    check('bridge_win64_true_on_wow64', 'sizeof(void*)==8||wow' in launch.replace(' ', ''))

    env = body(BRG, 'xrb_environment')
    check('bridge_passes_dir_in_env', 'AT_XHH_DIR=' in env and 'xrb_child_dir()' in env)
    check('bridge_env_drops_old_dir_value', '_wcsnicmp(p,L"AT_XHH_DIR=",11)' in env.replace(' ', ''))
    check('bridge_launch_still_sets_cwd', 'xrb.directory.c_str(),&si,&pi)' in BRG.replace(' ', ''))

    # the previous layout left the current-name controllers in the runtime-dir root; the bridge clears those
    legacy = body(BRG, 'xrb_remove_legacy_controllers')
    check('bridge_clears_root_controllers_from_old_layout',
          r'xrb.directory+L"\\keyscale_rack_controller.exe"' in legacy.replace(' ', '')
          and r'xrb.directory+L"\\keyscale_rack_controller32.exe"' in legacy.replace(' ', ''))

    # ================= controller side =================
    resolve = body(CTL, 'resolve_commdir')
    reader = body(CTL, 'xhh_dir_ansi')
    check('controller_reads_at_xhh_dir', 'AT_XHH_DIR' in reader and 'WideCharToMultiByte' in reader)
    check('controller_resolve_uses_all_three_sources',
          'xhh_dir_ansi(' in resolve and 'local_appdata_ansi(' in resolve and 'GetTempPathA' in resolve)
    at_xhh = resolve.index('xhh_dir_ansi(')
    at_local = resolve.index('local_appdata_ansi(')
    at_temp = resolve.index('GetTempPathA')
    check('controller_prefers_at_xhh_dir_then_localappdata_then_temp', at_xhh < at_local < at_temp)
    check('controller_localappdata_is_now_a_fallback', 'older bridge' in resolve)

    run = body(CTL, 'ensure_runtime')
    at_commdir = run.index('resolve_commdir()')
    at_rtdir = run.index('snprintf(RTDIR,')
    check('commdir_resolved_before_rtdir', 0 <= at_commdir < at_rtdir)
    rtdir_line = run[at_rtdir:run.index(';', at_rtdir)]
    check('rtdir_equals_commdir', 'COMMDIR' in rtdir_line and 'at8_rt' not in rtdir_line)
    check('rtdir_not_from_temp', 'GetTempPathA' not in run[:at_rtdir])

    purge = body(CTL, 'purge_old_rt')
    check('purge_guards_against_current_dir', 'same_dir(old,RTDIR)' in purge.replace(' ', ''))
    check('purge_only_our_names',
          all(n in purge for n in ('at_agent.dll', 'at_agent32.dll', 'inject.exe', 'inject32.exe')) and 'at_agent.b*' in purge)
    check('purge_removes_dir_last', purge.index('RemoveDirectoryA(old)') > purge.index('DeleteFileA'))
    cleanup = run[run.index('Earlier builds extracted'):run.index('migrate_legacy();')]
    check('cleans_old_temp_at8_rt', 'GetTempPathA' in cleanup and 'at8_rt' in cleanup)
    check('cleans_old_localappdata_at8_rt', 'local_appdata_ansi' in cleanup and r'AT_DATA_SUBDIR "\\at8_rt"' in cleanup)
    check('both_cleanups_go_through_purge', cleanup.count('purge_old_rt(') == 2)

    for m in re.finditer(r'%TEMP%\\\\?at8_rt', CTL):
        line = CTL[CTL.rindex('\n', 0, m.start()) + 1: CTL.index('\n', m.start())]
        check('temp_at8_rt_mention_is_explanatory_only:' + line.strip()[:34],
              any(w in line for w in ('Earlier builds', 'oldest', 'previous build', 'fall back', 'fallback')))

    # ================= agent <-> controller pointer contract =================
    # The agent runs inside a host process and cannot know the main program's runtime dir. Its only link to the
    # data folder is a pointer file. The fast path is %TEMP%\at8_commdir.txt; because a temp clean-up can delete
    # that, the controller also leaves a copy at %LOCALAPPDATA%\AutoTune_KeyScale\commdir.txt, and the agent reads
    # it when the %TEMP% one is gone. Before the move the agent could just assume %LOCALAPPDATA%\AutoTune_KeyScale;
    # now that COMMDIR is elsewhere, this backup pointer is what keeps that assumption working.
    AGT = (ATK / 'combined/at_agent.cpp').read_text(encoding='utf-8')
    cres = body(CTL, 'resolve_commdir')
    check('controller_writes_temp_pointer', 'at8_commdir.txt' in cres and 'fprintf(f,"%s\\n",COMMDIR)' in cres.replace(' ', ''))
    check('controller_writes_localappdata_backup_pointer',
          'commdir.txt' in cres and r'"%s\\commdir.txt"' in cres and 'local_appdata_ansi' in cres)
    check('controller_backup_pointer_avoids_self_reference', 'if(!same_dir(bak,COMMDIR))' in cres.replace(' ', ''))
    check('controller_backup_pointer_names_real_commdir',
          cres.count('fprintf(bf,"%s\\n",COMMDIR)'.replace(' ', '')) == 1 or 'fprintf(bf,"%s\\n",COMMDIR)' in cres.replace(' ', ''))
    ares = body(AGT, 'resolve_commdir')
    check('agent_reads_temp_pointer_first', ares.index('at8_commdir.txt') < ares.index('commdir.txt'))
    check('agent_reads_localappdata_backup_pointer',
          r'AT_DATA_SUBDIR "\\commdir.txt"' in ares and 'fopen(bp,"r")' in ares.replace(' ', ''))
    check('agent_backup_pointer_checked_for_existing_dir',
          ares.index('commdir.txt') < ares.index('FILE_ATTRIBUTE_DIRECTORY'))
    # the %TEMP% pointer file name is identical on both sides
    tmp_name_ctl = 'at8_commdir.txt'
    check('pointer_file_name_matches_both_sides', tmp_name_ctl in cres and tmp_name_ctl in ares)
    # commdir.txt must not be swept by the migrate name filter (it would otherwise be moved out of LOCALAPPDATA)
    cand = body(CTL, 'mig_name_candidate')
    check('backup_pointer_not_a_migrate_candidate', 'commdir.txt' not in cand)

    # ================= build flags =================
    opt = next(l for l in COMMON.splitlines() if 'set "OPT=' in l)
    check('buildflag_strip_symbols', '-Wl,-s' in opt)
    check('buildflag_no_ident', '-fno-ident' in opt)
    check('buildflag_keeps_no_insert_timestamp', '-Wl,--no-insert-timestamp' in opt)
    check('buildflag_no_gc_sections', '--gc-sections' not in opt and '-ffunction-sections' not in opt and '-fdata-sections' not in opt)
    check('buildflag_no_aslr_flags', '--dynamicbase' not in opt and '--nxcompat' not in opt)

    print({'checks': len(checks), 'passed': len(checks)})


if __name__ == '__main__':
    main()
