"""Extract and execute production bridge configuration, authorization and IPC state logic.
The stubs supply consent, clocks and IPC responses; the state machine is not rewritten.
"""
import re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]

def extract(text, marker):
    start=text.index(marker);opening=text.index('{',start);depth=0;state=None;i=opening
    while i<len(text):
        c=text[i]
        if state in ('"',"'"):
            if c=='\\':i+=2;continue
            if c==state:state=None
        elif state=='line':
            if c=='\n':state=None
        elif state=='comment':
            if text.startswith('*/',i):state=None;i+=2;continue
        elif c in ('"',"'"):state=c
        elif text.startswith('//',i):state='line';i+=2;continue
        elif text.startswith('/*',i):state='comment';i+=2;continue
        elif c=='{':depth+=1
        elif c=='}':
            depth-=1
            if depth==0:return text[start:i+1]
        i+=1
    raise ValueError('unclosed production function '+marker)

def write_harness(path):
    text=(ROOT/'vst3/cpp/keyscale_rack_bridge.cpp').read_text(encoding='utf-8')
    declarations=r'''
#include "companion_security.h"
#include "rack_bridge_json.h"
#include <string>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
typedef int32_t LONG;
typedef uint64_t ULONGLONG;
typedef void* HWND;
typedef void* HANDLE;
typedef void* LPVOID;
typedef void* HMODULE;
typedef const wchar_t* LPCWSTR;
#define FALSE 0
#define GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS 4
#define GET_MODULE_HANDLE_EX_FLAG_PIN 1
#define ERROR_ALREADY_EXISTS 183
#define HEAP_ZERO_MEMORY 8
#define WAIT_TIMEOUT 258
static HMODULE xrb_module=NULL;
#define WINAPI
#define __declspec(x)
struct XRB_Guard {XRB_Guard(){} };
static uint64_t test_now=1800000000ULL;
static ULONGLONG test_tick=1000000;
static bool test_consent=true,test_verify=true;
static bool test_child_alive=true,test_new_child_alive=true,test_window_available=true,test_quit_exits=false;
static unsigned test_launches=0;
static const char* test_http_reason="";
static bool test_fail_feel=false,test_fail_apply=false,test_fail_authorize=false,test_fail_quit=false,test_worker_busy=false;
static uint32_t test_authorize_reply=ATC_REPLY_OK,test_pause_reply=ATC_REPLY_OK,test_pause_status=0x80000000UL;
static bool test_fail_pause=false;
static void (*test_http_hook)()=NULL;
static std::string test_http_body;
static int test_http_error=0;
static bool test_http_renew=false;
static unsigned test_http_calls=0;
static uint32_t test_hello=(ATC_PROTOCOL_VERSION<<16)|ATC_CONTROLLER_VERSION;
static uint32_t test_status=0x80001001UL,test_errors=0x80000000UL;
static std::vector<unsigned> test_ops;
static std::vector<std::string> test_payloads;
static ATCS_Claims test_next;
static uint64_t fixture_now(){return test_now;}
static ULONGLONG GetTickCount64(){return test_tick;}
static DWORD GetCurrentProcessId(){return 1234;}
#define atcs_now fixture_now
#undef ATCS_PUBLIC_KEY_CONFIGURED
#define ATCS_PUBLIC_KEY_CONFIGURED 1
'''
    declarations+=re.search(r'^#define XRB_AGENT_BUILD \d+',text,re.M).group(0)+'\n'
    declarations+=text[text.index('enum { XRB_AUTH_NONE='):text.index('struct XRB_State')]+'\n'
    declarations+=extract(text,'struct XRB_State')+';\nstatic XRB_State xrb;\n'
    declarations+=extract(text,'struct XRB_WorkerContext')+';\n'
    declarations+=re.search(r'enum \{ XRB_OK=.*?\};',text,re.S).group(0)+'\n'
    declarations+=r'''
static void xrb_error(int value){xrb.error=value;}
static bool xrb_consent(){return test_consent;}
static void xrb_wipe_string(std::string& value){if(!value.empty())atcs_wipe(&value[0],value.size());value.clear();}
static int fixture_verify(const char*,unsigned,DWORD,const char*,ATCS_Claims* out){if(!test_verify)return 0;*out=test_next;return 1;}
#define atcs_verify_token fixture_verify
static bool xrb_launch();
static bool xrb_send(unsigned op,const char* payload,bool,uint32_t* output){
    if(!xrb.controller)return false;
    test_ops.push_back(op);test_payloads.push_back(payload?payload:"");
    if(op==ATC_QUIT&&test_quit_exits){if(xrb.child==(HANDLE)14)test_new_child_alive=false;else test_child_alive=false;}
    if((test_fail_pause&&op==ATC_PAUSE)||(test_fail_quit&&op==ATC_QUIT)||(test_fail_authorize&&op==ATC_AUTHORIZE)||(test_fail_apply&&op==ATC_APPLY)||(test_fail_feel&&op==ATC_STATUS&&payload&&std::string(payload)=="feel")){xrb_error(XRB_STALLED);return false;}
    uint32_t value=ATC_REPLY_OK;
    if(op==ATC_HELLO)value=test_hello;
    if(op==ATC_AUTHORIZE)value=test_authorize_reply;
    if(op==ATC_PAUSE)value=test_pause_reply;
    if(op==ATC_STATUS&&payload&&std::string(payload)=="errors")value=test_errors;
    else if(op==ATC_STATUS&&payload&&std::string(payload)=="paused")value=test_pause_status;
    else if(op==ATC_STATUS)value=(payload&&std::string(payload)=="feel")?0x80000000UL:test_status;
    if(output)*output=value;return true;
}
static unsigned test_wakes=0;
static void SetEvent(HANDLE){test_wakes++;}
static void CloseHandle(HANDLE){}
static void* GetProcessHeap(){return NULL;}
static void HeapFree(void*,unsigned,void*){}
static void* HeapAlloc(void*,unsigned,size_t bytes){static char context[256];if(bytes>sizeof context)return NULL;memset(context,0,sizeof context);return context;}
static void FreeLibraryAndExitThread(HMODULE,unsigned){}

static LONG InterlockedExchange(volatile LONG* p,LONG v){LONG old=*p;*p=v;return old;}
static LONG InterlockedCompareExchange(volatile LONG* p,LONG v,LONG expected){LONG old=*p;if(old==expected)*p=v;return old;}
static unsigned WaitForSingleObject(HANDLE handle,unsigned milliseconds){if(!milliseconds){if(handle==(HANDLE)10)return test_child_alive?WAIT_TIMEOUT:0;if(handle==(HANDLE)14)return test_new_child_alive?WAIT_TIMEOUT:0;return test_worker_busy?WAIT_TIMEOUT:0;}xrb.running=0;return WAIT_TIMEOUT;}
static bool xrb_os(){return true;}
static bool xrb_elevated(){return true;}
static bool xrb_base_valid(const std::wstring& base){return base==L"http://fixture.example:8080"||base==L"https://fixture.example";}
static int GetModuleHandleExW(unsigned,LPCWSTR,HMODULE* out){*out=(HMODULE)2;return 1;}
static HANDLE CreateMutexW(void*,int,const wchar_t*){return (HANDLE)3;}
static unsigned GetLastError(){return 0;}
static int fixture_device_fingerprint(char* out){memset(out,'a',64);out[64]=0;return 1;}
#define atcs_device_fingerprint fixture_device_fingerprint
static HANDLE CreateEventW(void*,int,int,const wchar_t*){return (HANDLE)4;}
static HANDLE CreateThread(void*,unsigned,DWORD (*)(LPVOID),LPVOID,unsigned,void*){return (HANDLE)5;}
static void FreeLibrary(HMODULE){}
static std::string xrb_utf8(const std::wstring& w){return std::string(w.begin(),w.end());}
static std::string xrb_inventory(){return ",\"racks\":[],\"plugins\":[]";}
static int xrb_authorize_http(const std::wstring&,const std::string& body,bool renew,std::string& token,XRB_AuthDiagnostic& diagnostic){test_http_calls++;test_http_renew=renew;test_http_body=body;diagnostic.stage=XRB_AUTH_HTTP;diagnostic.http=test_http_error==XRB_DENIED?401:200;diagnostic.reason=xrb_auth_reason(*test_http_reason?test_http_reason:(test_http_error==XRB_DENIED?"invalid_credentials":"none"));if(test_http_error==0)token="new-signed-token";if(test_http_hook)test_http_hook();return test_http_error;}


typedef int BOOL;
typedef intptr_t LPARAM;
#define INVALID_HANDLE_VALUE ((HANDLE)(intptr_t)-1)
#define CREATE_NO_WINDOW 0x08000000
#define CREATE_UNICODE_ENVIRONMENT 0x00000400
struct STARTUPINFOW {DWORD cb;};
struct PROCESS_INFORMATION {HANDLE hProcess;HANDLE hThread;DWORD dwProcessId;};
static BOOL GetExitCodeProcess(HANDLE,DWORD* out){*out=0;return 1;}
static BOOL xrb_find_window(HWND,LPARAM){return 1;}
static BOOL EnumWindows(BOOL (*)(HWND,LPARAM),LPARAM out){if(test_window_available)*(HWND*)out=(HWND)1;return 1;}
static HWND FindWindowA(const char*,const char*){return NULL;}
static HANDLE GetCurrentProcess(){return (HANDLE)11;}
static BOOL IsWow64Process(HANDLE,BOOL* out){*out=1;return 1;}
static HANDLE xrb_extract_locked(bool,std::wstring& path){path=L"C:\\Fixture\\controller.exe";return (HANDLE)12;}
static std::vector<wchar_t> xrb_environment(){return std::vector<wchar_t>(2,0);}
static BOOL CreateProcessW(const wchar_t*,wchar_t*,void*,void*,BOOL,DWORD,void*,const wchar_t*,STARTUPINFOW*,PROCESS_INFORMATION* out){test_launches++;out->hProcess=(HANDLE)14;out->hThread=(HANDLE)13;out->dwProcessId=5678;test_new_child_alive=true;return 1;}

'''
    declarations+='\n'.join(extract(text,m) for m in ('static void xrb_auth_diagnostic(', 'static ULONGLONG xrb_backoff(', 'static int xrb_auth_summary(', 'static std::wstring xrb_copy_w(', 'static int xrb_authorize_response(', 'static void xrb_child_finished(', 'static bool xrb_child_retiring(', 'static bool xrb_launch(', 'static bool xrb_apply(', 'static void xrb_deactivate(', 'static int xrb_tick(', 'static DWORD WINAPI xrb_auth_worker(', 'static void xrb_metadata_changed(', 'static void xrb_metadata_ready(', 'static int xrb_configure(', 'extern "C" __declspec(dllexport) int WINAPI RackBridge_Command('))+'\n'
    declarations+=r'''
static unsigned checks=0,failures=0;
#define CHECK(c) do{checks++;if(!(c)){printf("FAIL bridge line%u: %s\n",(unsigned)__LINE__,#c);failures++;}}while(0)
static void reset(){xrb=XRB_State();xrb.configured=true;xrb.enabled=1;xrb.productReady=xrb.legacyReady=true;xrb.legacy=L"fixture-machine";xrb.haveLease=true;xrb.deadline=test_tick+120000;xrb.lease.expires=test_now+120;xrb.lease.parent=1234;xrb.controller=(HWND)1;xrb.child=(HANDLE)10;xrb.childPid=5678;xrb.childLeasePossible=true;xrb.childLeaseIssued=xrb.lease.issued;xrb.revision=1;xrb.installedRevision=1;xrb.key=3;xrb.scale=1;test_consent=true;test_verify=true;test_child_alive=true;test_new_child_alive=true;test_window_available=true;test_quit_exits=true;test_launches=0;test_http_reason="";test_fail_feel=false;test_fail_apply=false;test_fail_authorize=false;test_fail_quit=false;test_worker_busy=false;test_authorize_reply=ATC_REPLY_OK;test_pause_reply=ATC_REPLY_OK;test_pause_status=0x80000000UL;test_fail_pause=false;test_http_hook=NULL;test_http_body.clear();test_wakes=0;test_status=0x80001001UL;test_errors=0x80000000UL;test_hello=(ATC_PROTOCOL_VERSION<<16)|ATC_CONTROLLER_VERSION;test_ops.clear();test_payloads.clear();test_http_error=0;test_http_renew=false;test_http_calls=0;memset(&test_next,0,sizeof test_next);test_next.expires=test_now+120;test_next.parent=1234;}
static void worker_once(){xrb.running=1;XRB_WorkerContext context={xrb.workerEpoch,NULL};xrb_auth_worker(&context);}
static int configure(const wchar_t* account=L"fixture-account",const wchar_t* credential=L"fixture-credential"){return RackBridge_Command(1,(uintptr_t)L"C:\\Fixture",(uintptr_t)L"http://fixture.example:8080",(uintptr_t)account,(uintptr_t)credential);}
static void set_metadata(){CHECK(RackBridge_Command(11,3,(uintptr_t)L"zh-CN",0,0)==1);CHECK(RackBridge_Command(14,(uintptr_t)L"fixture-machine",0,0,0)==1);}
static void change_legacy_during_http(){RackBridge_Command(14,(uintptr_t)L"replacement-machine",0,0,0);}
static void stop_during_http(){RackBridge_Command(8,0,0,0,0);}
static void disable_during_http(){RackBridge_Command(7,0,0,0,0);}
static void pause_during_http(){RackBridge_Command(16,1,0,0,0);}
static void reconfigure_during_http(){configure(L"new-account",L"new-credential");}
int main(){
    CHECK(ATC_PROTOCOL_VERSION==3);CHECK(ATC_CONTROLLER_VERSION==5);CHECK(XRB_AGENT_BUILD==1166);
    reset();xrb.installedRevision=0;test_hello=(3U<<16)|4U;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_OLD_CONTROLLER);CHECK(xrb.installedRevision==0);CHECK(test_ops.size()==1&&test_ops[0]==ATC_HELLO);
    test_ops.clear();test_payloads.clear();test_hello=(3U<<16)|5U;CHECK(xrb_tick()==1);CHECK(xrb.installedRevision==xrb.revision);CHECK(test_ops[0]==ATC_HELLO&&test_ops[1]==ATC_AUTHORIZE);
    reset();CHECK(xrb_tick()==1);CHECK(test_ops[0]==ATC_STATUS&&test_payloads[0]=="expect=3:1");
    reset();xrb.key=xrb.scale=-1;CHECK(xrb_tick()==1);CHECK(test_ops[0]==ATC_STATUS&&test_payloads[0].empty());
    reset();test_errors=0x80000020UL;xrb.needReplay=true;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_USER);CHECK(xrb.needReplay);for(unsigned i=0;i<test_ops.size();i++)CHECK(test_ops[i]!=ATC_APPLY);
    reset();test_errors=0;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_PROTOCOL);
    reset();xrb.haveLease=false;xrb.pending="recovered-lease";xrb.needReplay=false;CHECK(xrb_tick()==0);CHECK(xrb_tick()==1);{bool applied=false;for(unsigned i=0;i<test_ops.size();i++)if(test_ops[i]==ATC_APPLY)applied=true;CHECK(applied);}
    reset();xrb.pending="renewed-current-session";xrb.needReplay=false;CHECK(xrb_tick()==1);
    {unsigned applies=0;for(unsigned i=0;i<test_ops.size();i++)if(test_ops[i]==ATC_APPLY)applies++;CHECK(applies==0);}
    reset();xrb.needReplay=true;test_fail_apply=true;CHECK(xrb_tick()==0);CHECK(xrb.needReplay);
    test_fail_apply=false;CHECK(RackBridge_Command(4,700,0,0,0)==1);CHECK(xrb.needReplay);
    CHECK(xrb_tick()==1);CHECK(!xrb.needReplay);
    XRB_WorkerContext contextOne={1,NULL};
    reset();xrb.configured=false;CHECK(xrb_tick()==0);CHECK(test_ops.empty());
    reset();xrb.enabled=0;CHECK(xrb_tick()==0);CHECK(xrb.enabled==0);CHECK(xrb.error==XRB_DISABLED);CHECK(test_ops.empty());
    reset();test_consent=false;CHECK(xrb_tick()==0);CHECK(!xrb.haveLease);CHECK(xrb.error==XRB_DISABLED);CHECK(test_ops.size()==2&&test_ops[0]==ATC_EJECT&&test_ops[1]==ATC_QUIT);
    reset();xrb.haveLease=false;xrb.error=XRB_NETWORK;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_NETWORK);CHECK(test_ops.size()==1&&test_ops[0]==ATC_QUIT);
    reset();xrb.lease.expires=test_now-1;CHECK(xrb_tick()==0);CHECK(!xrb.haveLease);CHECK(xrb.error==XRB_EXPIRED);for(unsigned i=0;i<test_ops.size();i++)CHECK(test_ops[i]!=ATC_APPLY);
    reset();xrb.deadline=test_tick;CHECK(xrb_tick()==0);CHECK(!xrb.haveLease);CHECK(xrb.error==XRB_EXPIRED);
    reset();xrb.controller=NULL;test_window_available=false;CHECK(xrb_tick()==0);CHECK(test_ops.empty());
    reset();test_status=0x40000000UL;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_PROTOCOL);
    reset();test_status=0xc0000000UL;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_CONNECTING);
    reset();xrb.needReplay=true;test_fail_apply=true;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_STALLED);CHECK(test_ops.size()==3&&test_ops[0]==ATC_STATUS&&test_ops[1]==ATC_STATUS&&test_ops[2]==ATC_APPLY);
    reset();test_fail_feel=true;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_STALLED);CHECK(xrb.feel==0x80000000UL);
    reset();xrb.pending="temporary-signed-fixture";xrb.installedRevision=0;xrb.needReplay=true;CHECK(xrb_tick()==1);CHECK(xrb.pending.empty());CHECK(xrb.haveLease);CHECK(xrb.installedRevision==xrb.revision);CHECK(xrb.error==XRB_OK);CHECK(test_ops.size()==6);CHECK(test_ops[0]==ATC_HELLO&&test_ops[1]==ATC_AUTHORIZE&&test_ops[2]==ATC_STATUS&&test_ops[3]==ATC_STATUS&&test_ops[4]==ATC_APPLY&&test_ops[5]==ATC_STATUS);
    reset();xrb.pending="invalid-fixture";test_verify=false;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_DENIED);CHECK(xrb.pending.empty());CHECK(test_ops.empty());
    reset();xrb.status=0x80001001UL;CHECK(RackBridge_Command(3,5,1,(uintptr_t)-1,0)==1);CHECK((xrb.status&63)==0);CHECK(xrb.key==5&&xrb.scale==1);CHECK(test_ops.size()==1&&test_ops[0]==ATC_APPLY);
    reset();xrb.haveLease=false;CHECK(RackBridge_Command(3,5,1,(uintptr_t)-1,0)==0);CHECK(test_ops.empty());
    reset();xrb.lease.expires=test_now-1;CHECK(RackBridge_Command(3,5,1,(uintptr_t)-1,0)==0);CHECK(test_ops.empty());CHECK(xrb.error==XRB_EXPIRED);
    reset();CHECK(RackBridge_Command(3,12,1,(uintptr_t)-1,0)==0);CHECK(test_ops.empty());
    reset();CHECK(RackBridge_Command(7,0,0,0,0)==1);CHECK(xrb.enabled==0);CHECK(!xrb.haveLease);CHECK(xrb.key==-1&&xrb.scale==-1&&xrb.strength==-1&&!xrb.needReplay);test_ops.clear();test_payloads.clear();CHECK(xrb_tick()==0);CHECK(xrb.enabled==0);CHECK(test_ops.empty());
    reset();xrb.running=1;xrb.workerEpoch=1;CHECK(RackBridge_Command(8,0,0,0,0)==1);CHECK(!xrb.configured);CHECK(xrb.running==0);CHECK(xrb.workerEpoch==2);CHECK(!xrb.haveLease);CHECK(xrb.lease.key[0]==0);CHECK(xrb.key==-1&&xrb.scale==-1&&xrb.strength==-1&&!xrb.needReplay);
    reset();xrb.running=1;xrb.workerEpoch=1;xrb.account=L"account";xrb.credential=L"test-credential-only";xrb.token="old-token";test_http_error=XRB_NETWORK;
    CHECK(xrb_auth_worker(&contextOne)==0);CHECK(test_http_calls==1);CHECK(test_http_renew);CHECK(!xrb.haveLease);CHECK(xrb.token.empty());CHECK(xrb.pending.empty());CHECK(xrb.error==XRB_NETWORK);CHECK(xrb.nextAuth>test_tick);
    xrb.running=1;xrb.nextAuth=0;test_http_error=XRB_OK;test_http_calls=0;CHECK(xrb_auth_worker(&contextOne)==0);CHECK(test_http_calls==1);CHECK(!test_http_renew);CHECK(xrb.pending=="new-signed-token");
    /* v3: the authorize body carries this machine's clock (server-side time alignment). */
    {size_t at=test_http_body.find("\"client_now\":");CHECK(at!=std::string::npos);CHECK(at!=std::string::npos&&test_http_body[at+13]>='1'&&test_http_body[at+13]<='9');}
    CHECK(!xrb.haveLease);
    /* The actual service supports ttl=30 and advertises renewal at 20s.
       Derive the bridge schedule from the verified lease rather than trusting
       an optional response field or waiting until its exact expiry. */
    const unsigned expirySeconds[]={1,10,11,12,20,30,40,41,120};
    const unsigned renewalMilliseconds[]={1000,1000,1000,2000,10000,20000,30000,30000,30000};
    for(unsigned i=0;i<sizeof expirySeconds/sizeof expirySeconds[0];i++){
        reset();xrb.running=1;xrb.workerEpoch=1;xrb.account=L"account";xrb.credential=L"test-credential-only";xrb.token="old-token";
        xrb.lease.issued=test_now-1;test_next=xrb.lease;test_next.issued=test_now;test_next.expires=test_now+expirySeconds[i];
        CHECK(xrb_auth_worker(&contextOne)==0);CHECK(xrb.pending=="new-signed-token");
        CHECK(xrb.nextAuth==test_tick+renewalMilliseconds[i]);
        if(expirySeconds[i]>1)CHECK(xrb.nextAuth<test_tick+(uint64_t)expirySeconds[i]*1000);
    }
    reset();xrb.running=1;xrb.workerEpoch=1;xrb.lease.issued=test_now;test_next=xrb.lease;test_next.expires=test_now;
    CHECK(xrb_auth_worker(&contextOne)==0);CHECK(xrb.pending.empty());CHECK(xrb.error==XRB_EXPIRED);
    /* Same-time leases require every signed claim to agree in the bridge too.
       Controller and agent already impose this contract. */
    for(unsigned field=0;field<6;field++){
        reset();xrb.running=1;xrb.workerEpoch=1;xrb.lease.issued=test_now;test_next=xrb.lease;
        switch(field){case 0:strcpy(test_next.racks,"7265617065722e657865");break;case 1:strcpy(test_next.plugins,"7761766573");break;
        case 2:strcpy(test_next.license,"L2");break;case 3:strcpy(test_next.sid,"22222222222222222222222222222222");break;
        case 4:test_next.key[0]=1;break;case 5:test_next.expires++;break;}
        CHECK(xrb_auth_worker(&contextOne)==0);
    /* Protocol v3 seals every reply under this request's key, so only tokens of the
       SAME session are checked for rollback; a different sid is a new session whose
       times the server aligns to this machine's clock and is accepted. */
    if(field==3){CHECK(xrb.pending=="new-signed-token");CHECK(xrb.error==XRB_CONNECTING);}
    else{CHECK(xrb.pending.empty());CHECK(xrb.error==XRB_DENIED);CHECK(xrb.lease.issued==test_now);}
    }
    reset();xrb.running=1;xrb.workerEpoch=1;xrb.lease.issued=test_now;test_next=xrb.lease;
    CHECK(xrb_auth_worker(&contextOne)==0);CHECK(xrb.pending=="new-signed-token");
    reset();xrb.running=1;xrb.workerEpoch=1;xrb.haveLease=false;xrb.lease.issued=test_now;test_next=xrb.lease;test_next.issued--;
    CHECK(xrb_auth_worker(&contextOne)==0);CHECK(xrb.pending.empty());CHECK(xrb.error==XRB_DENIED);
    reset();xrb.running=1;xrb.workerEpoch=2;CHECK(xrb_auth_worker(&contextOne)==0);CHECK(test_http_calls==0);
    /* Execute the real controller restart path together with tick and worker.
       Process/window/HTTP/IPC boundaries are controlled; no lease decision is
       substituted by a fake xrb_launch implementation. */
    reset();xrb.lease.issued=test_now;xrb.childLeaseIssued=test_now-1;xrb.token="verified-current-token";xrb.nextAuth=test_tick+30000;xrb.wake=(HANDLE)4;test_child_alive=false;
    {uint64_t scheduled=xrb.nextAuth;CHECK(xrb_tick()==0);CHECK(test_launches==1);CHECK(xrb.haveLease);CHECK(xrb.token=="verified-current-token");CHECK(xrb.nextAuth==scheduled);CHECK(test_wakes==0);CHECK(xrb.installedRevision==0&&xrb.needReplay);
     worker_once();CHECK(test_http_calls==0);CHECK(xrb_tick()==1);CHECK(xrb.installedRevision==xrb.revision);CHECK(xrb.nextAuth==scheduled);
     bool authorized=false;for(unsigned i=0;i<test_ops.size();i++)if(test_ops[i]==ATC_AUTHORIZE){authorized=true;CHECK(test_payloads[i]=="verified-current-token");}CHECK(authorized);
     test_tick=scheduled;test_now+=30;test_next=xrb.lease;test_next.issued=test_now;test_next.expires=test_now+120;worker_once();CHECK(test_http_calls==1&&test_http_renew);CHECK(xrb.nextAuth==test_tick+30000);}
    /* QUIT is asynchronous and timeout may still mean delivery. Fresh leases
       must never be sent to the retiring child while its handle remains alive. */
    for(unsigned quitTimeout=0;quitTimeout<2;quitTimeout++){
        reset();xrb.lease.issued=test_now-1;xrb.childLeaseIssued=xrb.lease.issued;xrb.token="rejected-renewal-token";xrb.nextAuth=test_tick;test_http_error=XRB_DENIED;test_http_reason="invalid_token";test_quit_exits=false;test_fail_quit=quitTimeout!=0;
        worker_once();CHECK(test_http_calls==1&&test_http_renew);CHECK(xrb.token.empty()&&!xrb.haveLease&&xrb.error==XRB_DENIED);CHECK(xrb.authDiagnostic.reason==xrb_auth_reason("invalid_token"));
        CHECK(xrb_tick()==0);CHECK(test_child_alive&&xrb.childRetiring);test_tick=xrb.nextAuth;test_now++;test_http_error=XRB_OK;test_http_reason="";test_next.issued=test_now;test_next.expires=test_now+120;
        worker_once();CHECK(test_http_calls==2&&!test_http_renew);CHECK(xrb.pending=="new-signed-token");
        {uint64_t scheduled=xrb.nextAuth;CHECK(scheduled==test_tick+30000);CHECK(xrb_tick()==0);CHECK(test_launches==0&&xrb.haveLease&&xrb.childRetiring);CHECK(xrb.nextAuth==scheduled);CHECK(RackBridge_Command(6,0,0,0,0)==0);CHECK(test_launches==0);for(unsigned i=0;i<test_ops.size();i++)CHECK(test_ops[i]!=ATC_AUTHORIZE);
         worker_once();CHECK(test_http_calls==2);uint64_t retireDeadline=xrb.childRetireDeadline;test_tick=retireDeadline;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_STALLED&&xrb.authDiagnostic.stage==XRB_AUTH_CONTROLLER&&xrb.authDiagnostic.http==0);CHECK(xrb.authDiagnostic.reason==xrb_auth_reason("transport_failed"));CHECK(xrb.nextAuth==scheduled&&test_launches==0);CHECK(RackBridge_Command(6,0,0,0,0)==0&&xrb.error==XRB_STALLED);
         xrb_deactivate(false);CHECK(xrb.childRetireDeadline==retireDeadline);xrb.haveLease=true;test_child_alive=false;CHECK(xrb_tick()==0);CHECK(test_launches==1&&!xrb.childRetiring&&!xrb.childLeasePossible&&xrb.childRetireDeadline==0);CHECK(xrb.nextAuth==scheduled);worker_once();CHECK(test_http_calls==2);
         CHECK(xrb_tick()==1);CHECK(xrb.nextAuth==scheduled);CHECK(xrb.error==XRB_OK);CHECK(xrb.childLeasePossible&&xrb.childLeaseIssued==xrb.lease.issued);worker_once();CHECK(test_http_calls==2);
         test_tick=scheduled-1;worker_once();CHECK(test_http_calls==2);test_tick++;test_now+=30;test_next=xrb.lease;test_next.issued=test_now;test_next.expires=test_now+120;worker_once();CHECK(test_http_calls==3&&test_http_renew);}
    }
    /* Same-lease replacement needs fresh issued claims because surviving agents
       retain replay counters while the replacement controller restarts at zero. */
    reset();xrb.lease.issued=test_now;xrb.childLeaseIssued=test_now;xrb.token="same-lease-token";xrb.nextAuth=test_tick+30000;xrb.wake=(HANDLE)4;test_child_alive=false;
    CHECK(xrb_tick()==0);CHECK(xrb.nextAuth==0&&test_wakes==1);CHECK(!xrb.childLeasePossible);test_next=xrb.lease;test_next.issued=test_now+1;worker_once();CHECK(test_http_calls==1&&test_http_renew);CHECK(xrb_tick()==1);CHECK(xrb.lease.issued==test_now+1&&xrb.childLeaseIssued==test_now+1);
    /* Record before AUTHORIZE send, not after acknowledgement: a timeout can
       follow delivery even though installedRevision remains zero. */
    reset();xrb.lease.issued=test_now;xrb.token="possibly-delivered-token";xrb.childLeasePossible=false;xrb.childLeaseIssued=0;xrb.installedRevision=0;test_fail_authorize=true;
    CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_STALLED&&xrb.installedRevision==0);CHECK(xrb.childLeasePossible&&xrb.childLeaseIssued==test_now);
    test_fail_authorize=false;test_child_alive=false;xrb.nextAuth=test_tick+30000;CHECK(xrb_tick()==0);CHECK(xrb.nextAuth==0);
    /* An idempotent response advances bridge revision but preserves agent replay
       counters. A changed SID with equal issued is not strictly newer either. */
    for(unsigned changedSid=0;changedSid<2;changedSid++){
        reset();xrb.lease.issued=test_now;xrb.childLeaseIssued=test_now;xrb.token="same-claims-token";xrb.pending="idempotent-token";test_next=xrb.lease;if(changedSid)strcpy(test_next.sid,"22222222222222222222222222222222");xrb.nextAuth=test_tick+30000;uint64_t prior=xrb.revision;test_child_alive=false;
        CHECK(xrb_tick()==0);CHECK(xrb.revision==prior+1);CHECK(xrb.nextAuth==0);CHECK(xrb.lease.issued==test_now);
    }
    /* Keep the highest possible issued value and do not discard delivery or
       retirement evidence during deactivate/STOP/reconfigure. */
    reset();xrb.lease.issued=test_now;xrb.childLeaseIssued=test_now+1;xrb.installedRevision=0;test_fail_authorize=true;CHECK(xrb_tick()==0);CHECK(xrb.childLeaseIssued==test_now+1);
    reset();xrb.lease.issued=test_now;xrb.childLeaseIssued=test_now;test_quit_exits=false;CHECK(RackBridge_Command(8,0,0,0,0)==1);CHECK(xrb.childRetiring&&xrb.childLeasePossible&&xrb.childLeaseIssued==test_now);uint64_t retirement=xrb.childRetireDeadline;CHECK(configure()==1);CHECK(xrb.childRetiring&&xrb.childLeasePossible&&xrb.childLeaseIssued==test_now&&xrb.childRetireDeadline==retirement);
    /* Show-driven replacement shares marker cleanup and the freshness decision. */
    /* The removed visible-controller ABI is inert even with a dead child;
       it neither creates processes nor overrides authorization backoff. */
    for(unsigned delay=1000;delay<=30000;delay+=29000){reset();xrb.haveLease=false;xrb.error=XRB_NETWORK;xrb.authDiagnostic.http=429;xrb.authDiagnostic.reason=xrb_auth_reason("rate_limited");xrb.nextAuth=test_tick+delay;xrb.controller=NULL;test_child_alive=false;uint64_t scheduled=xrb.nextAuth;CHECK(RackBridge_Command(6,0,0,0,0)==0);CHECK(xrb.nextAuth==scheduled&&xrb.error==XRB_NETWORK);CHECK(test_launches==0&&xrb.child==(HANDLE)10);worker_once();CHECK(test_http_calls==0);}
    /* Controller loss never permits expired leases or a refused IPC grant. */
    reset();test_child_alive=false;xrb.lease.expires=test_now;CHECK(xrb_tick()==0);CHECK(test_launches==0&&!xrb.haveLease&&xrb.error==XRB_EXPIRED);
    xrb.nextAuth=test_tick;test_next.issued=test_now;test_next.expires=test_now+120;worker_once();CHECK(test_http_calls==1&&!test_http_renew);
    reset();test_child_alive=false;xrb.token="verified-current-token";xrb.nextAuth=test_tick+30000;CHECK(xrb_tick()==0);test_authorize_reply=ATC_REPLY_AUTH_REQUIRED;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_DENIED&&xrb.installedRevision==0);for(unsigned i=0;i<test_ops.size();i++)CHECK(test_ops[i]!=ATC_APPLY);
    reset();test_child_alive=false;xrb.token="verified-current-token";xrb.nextAuth=test_tick+30000;CHECK(xrb_tick()==0);test_fail_authorize=true;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_STALLED&&xrb.installedRevision==0);for(unsigned i=0;i<test_ops.size();i++)CHECK(test_ops[i]!=ATC_APPLY);
    reset();test_child_alive=false;xrb.token="verified-current-token";xrb.nextAuth=test_tick+30000;CHECK(xrb_tick()==0);test_status=0;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_PROTOCOL);for(unsigned i=0;i<test_ops.size();i++)CHECK(test_ops[i]!=ATC_APPLY);
    /* Configure creates a metadata barrier: an active worker cannot publish a
       legacy authorization request until both explicit setters have arrived. */
    reset();xrb=XRB_State();CHECK(configure()==1);CHECK(!xrb.productReady&&!xrb.legacyReady&&xrb.legacy.empty());
    worker_once();CHECK(test_http_calls==0);
    CHECK(RackBridge_Command(11,3,(uintptr_t)L"zh-CN",0,0)==1);worker_once();CHECK(test_http_calls==0);
    CHECK(RackBridge_Command(14,(uintptr_t)L"",0,0,0)==0);worker_once();CHECK(test_http_calls==0);
    CHECK(RackBridge_Command(14,(uintptr_t)L"fixture-machine",0,0,0)==1);worker_once();CHECK(test_http_calls==1);
    CHECK(test_http_body.find("\"soft\":3")!=std::string::npos);CHECK(test_http_body.find("\"legacy_machine_code\":\"fixture-machine\"")!=std::string::npos);
    CHECK(xrb.pending=="new-signed-token");CHECK(xrb.error==XRB_CONNECTING);
    reset();CHECK(configure()==1);CHECK(RackBridge_Command(14,(uintptr_t)L"fixture-machine",0,0,0)==1);worker_once();CHECK(test_http_calls==0);
    CHECK(RackBridge_Command(11,2,(uintptr_t)L"en",0,0)==1);worker_once();CHECK(test_http_calls==1);CHECK(test_http_body.find("\"soft\":2")!=std::string::npos);
    /* Even unchanged configure is an explicit new transaction; changed account
       and credential must actually be saved before its new worker request. */
    reset();xrb.token="old-sensitive-token";xrb.pending="old-pending-token";uint64_t rev=xrb.revision;CHECK(configure(L"replacement-account",L"replacement-credential")==1);
    CHECK(xrb.revision>rev);CHECK(!xrb.haveLease&&xrb.token.empty()&&xrb.pending.empty()&&xrb.lease.expires==0);CHECK(xrb.legacy.empty());worker_once();CHECK(test_http_calls==0);
    set_metadata();worker_once();CHECK(!test_http_renew);CHECK(test_http_body.find("replacement-account")!=std::string::npos);CHECK(test_http_body.find("replacement-credential")!=std::string::npos);
    CHECK(configure()==1);worker_once();CHECK(test_http_calls==1);CHECK(!xrb.productReady&&!xrb.legacyReady);
    reset();xrb.account=L"unchanged";rev=xrb.revision;CHECK(configure(L"",L"invalid")==0);CHECK(xrb.account==L"unchanged"&&xrb.revision==rev&&xrb.haveLease);
    /* Duplicate setters are harmless and do not shorten server renewal policy. */
    reset();xrb.nextAuth=test_tick+12345;rev=xrb.revision;xrb.wake=(HANDLE)1;set_metadata();CHECK(xrb.revision==rev&&xrb.haveLease);CHECK(xrb.nextAuth==test_tick+12345&&test_wakes==0);
    CHECK(RackBridge_Command(11,4,(uintptr_t)L"en",0,0)==0);CHECK(xrb.soft==3&&xrb.revision==rev);
    CHECK(RackBridge_Command(11,1,(uintptr_t)L"en",0,0)==1);CHECK(xrb.revision>rev&&!xrb.haveLease&&xrb.lease.expires==0&&xrb.nextAuth==0);
    reset();xrb.token="stale-token";xrb.pending="stale-pending";rev=xrb.revision;CHECK(RackBridge_Command(14,(uintptr_t)L"changed",0,0,0)==1);CHECK(xrb.revision>rev&&xrb.token.empty()&&xrb.pending.empty()&&!xrb.haveLease);
    for(unsigned op=7;op<=8;op++){reset();CHECK(RackBridge_Command(op,0,0,0,0)==1);CHECK(!xrb.productReady&&!xrb.legacyReady&&xrb.legacy.empty());CHECK(configure()==1);worker_once();CHECK(test_http_calls==0);}
    /* A response may arrive after setters, STOP, disable, or reconfigure. Both
       the token/error and diagnostic publication use the captured revision. */
    void (*hooks[])()={change_legacy_during_http,stop_during_http,disable_during_http,reconfigure_during_http};
    for(unsigned i=0;i<4;i++){reset();test_http_hook=hooks[i];test_http_error=XRB_DENIED;worker_once();CHECK(test_http_calls==1);CHECK(xrb.pending.empty());CHECK(xrb.error!=XRB_DENIED);CHECK(xrb.authDiagnostic.http==0);CHECK(xrb.authDiagnostic.stage!=XRB_AUTH_HTTP);}
    /* Controller transport failure is not a licensing refusal. The stub also
       deliberately starts with old DENIED to prove the error is overwritten. */
    reset();xrb.installedRevision=0;xrb.error=XRB_DENIED;xrb.authDiagnostic.http=401;test_fail_authorize=true;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_STALLED);CHECK(xrb.authDiagnostic.stage==XRB_AUTH_CONTROLLER&&xrb.authDiagnostic.http==0);CHECK(xrb.authDiagnostic.reason==xrb_auth_reason("transport_failed"));
    reset();xrb.installedRevision=0;test_authorize_reply=ATC_REPLY_AUTH_REQUIRED;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_DENIED);CHECK(xrb.authDiagnostic.reason==xrb_auth_reason("controller_rejected"));
    reset();xrb.error=XRB_DENIED;test_verify=false;worker_once();CHECK(xrb.error==XRB_DENIED);CHECK(xrb.authDiagnostic.stage==XRB_AUTH_VERIFY&&xrb.authDiagnostic.http==200);CHECK(xrb.authDiagnostic.reason==xrb_auth_reason("token_validation_failed"));
    reset();xrb.error=XRB_DENIED;worker_once();CHECK(xrb.error==XRB_CONNECTING&&xrb.authDiagnostic.stage==XRB_AUTH_VERIFY&&xrb.authDiagnostic.reason==0);CHECK(xrb_tick()==1);CHECK(xrb.authDiagnostic.stage==XRB_AUTH_READY&&xrb.authDiagnostic.http==0&&xrb.error==XRB_OK);
    /* Local expiry must replace a prior ready summary so the host does not
       discard error 11 as a non-error authorization stage. Both clocks and
       both production enforcement paths retain their original expiry code. */
    for(unsigned path=0;path<2;path++)for(unsigned clock=0;clock<2;clock++){
        reset();xrb.authDiagnostic.stage=XRB_AUTH_READY;xrb.authDiagnostic.http=200;
        if(clock==0)xrb.lease.expires=test_now;else xrb.deadline=test_tick;
        CHECK((path==0?xrb_tick():RackBridge_Command(3,5,1,(uintptr_t)-1,0))==0);CHECK(xrb.error==XRB_EXPIRED);
        wchar_t expirySummary[256];CHECK(RackBridge_Command(15,(uintptr_t)expirySummary,256,0,0)>0);
        CHECK(wcscmp(expirySummary,L"auth_stage=verify_token http=0 auth_reason=lease_expired error=11")==0);
    }
    /* Actual production JSON handling, with no server/WinHTTP stub deciding
       classification. The summary cannot contain unapproved server text. */
    struct ResponseCase{unsigned http;const char* body;int error;const char* reason;};
    const ResponseCase responses[]={
        {403,"{\"ok\":false,\"error\":\"feature_disabled\"}",XRB_DENIED,"feature_disabled"},
        {401,"{\"ok\":false,\"error\":\"invalid_credentials\"}",XRB_DENIED,"invalid_credentials"},
        {403,"{\"ok\":false,\"error\":\"authorization_denied\"}",XRB_DENIED,"authorization_denied"},
        {403,"{\"ok\":false,\"error\":\"revoked\"}",XRB_REVOKED,"revoked"},
        {403,"{\"ok\":false,\"error\":\"session_revoked_or_replayed\"}",XRB_REVOKED,"session_revoked_or_replayed"},
        {429,"{\"ok\":false,\"error\":\"rate_limited\"}",XRB_NETWORK,"rate_limited"},
        {503,"{\"ok\":false,\"error\":\"policy_unavailable\"}",XRB_NETWORK,"policy_unavailable"},
        {403,"{\"ok\":false,\"error\":\"private-account-revoked\"}",XRB_DENIED,"unknown_server_error"},
        {403,"{\"ok\":false,\"error\":123}",XRB_DENIED,"unknown_server_error"},
        {403,"{\"ok\":false,\"error\":\"invalid_credentials\\nprivate-value\"}",XRB_DENIED,"unknown_server_error"},
        {200,"<html>private-path</html>",XRB_PROTOCOL,"invalid_response"},
        {200,"{\"ok\":true}",XRB_PROTOCOL,"token_missing"},
        {200,"{\"ok\":true,\"token\":12}",XRB_PROTOCOL,"token_missing"},
        {200,"{\"ok\":true,\"token\":\"signed-token\"}",XRB_OK,"none"}};
    for(unsigned i=0;i<sizeof responses/sizeof responses[0];i++){reset();std::string body=responses[i].body,token;XRB_AuthDiagnostic diagnostic;int error=xrb_authorize_response(responses[i].http,body,token,diagnostic);CHECK(error==responses[i].error);CHECK(body.empty());CHECK(diagnostic.stage==XRB_AUTH_HTTP&&diagnostic.http==responses[i].http);CHECK(diagnostic.reason==xrb_auth_reason(responses[i].reason));if(error==XRB_OK)CHECK(token=="signed-token");else CHECK(token.empty());xrb.authDiagnostic=diagnostic;xrb.error=error;wchar_t out[256];CHECK(RackBridge_Command(15,(uintptr_t)out,256,0,0)>0);CHECK(wcsstr(out,L"private")==NULL);}
    reset();xrb.authDiagnostic.stage=XRB_AUTH_HTTP;xrb.authDiagnostic.http=401;xrb.authDiagnostic.reason=xrb_auth_reason("invalid_credentials");xrb.error=XRB_DENIED;strcpy(xrb.device,"PRIVATE_DEVICE");strcpy(xrb.lease.license,"PRIVATE_LICENSE");xrb.account=L"PRIVATE_ACCOUNT";xrb.credential=L"PRIVATE_CREDENTIAL";xrb.token="PRIVATE_TOKEN";xrb.directory=L"PRIVATE_PATH";
    wchar_t summary[512];int count=RackBridge_Command(15,(uintptr_t)summary,512,0,0);CHECK(count==(int)wcslen(summary));CHECK(wcscmp(summary,L"auth_stage=http http=401 auth_reason=invalid_credentials error=3")==0);CHECK(wcsstr(summary,L"PRIVATE")==NULL);for(int i=0;i<count;i++)CHECK(summary[i]>=32&&summary[i]<=126);
    wchar_t shortBuffer[3]={L'x',L'y',L'z'};CHECK(RackBridge_Command(15,(uintptr_t)shortBuffer,2,0,0)==1);CHECK(shortBuffer[0]==L'a'&&shortBuffer[1]==0&&shortBuffer[2]==L'z');CHECK(RackBridge_Command(15,0,512,0,0)==0);CHECK(RackBridge_Command(15,(uintptr_t)shortBuffer,1,0,0)==0);CHECK(RackBridge_Command(15,(uintptr_t)shortBuffer,32769,0,0)==0);
    wchar_t full[768];CHECK(RackBridge_Command(12,(uintptr_t)full,768,0,0)>0);CHECK(wcsstr(full,summary)!=NULL);
    xrb.authDiagnostic.stage=999;xrb.authDiagnostic.reason=999;CHECK(RackBridge_Command(15,(uintptr_t)summary,512,0,0)>0);CHECK(wcsstr(summary,L"auth_stage=none")!=NULL&&wcsstr(summary,L"auth_reason=unknown_server_error")!=NULL);
    /* Pause leaves the authorized process/worker alive and gates all automatic
       mutations, including replay, while status and future renewals continue. */
    reset();xrb.needReplay=true;xrb.token="current-token";xrb.nextAuth=test_tick+30000;uint64_t revision=xrb.revision,scheduled=xrb.nextAuth;
    CHECK(RackBridge_Command(16,2,0,0,0)==0&&!xrb.paused);CHECK(RackBridge_Command(16,1,0,0,0)==1);CHECK(xrb.paused&&xrb.pauseHandshake&&xrb.enabled&&xrb.haveLease);CHECK(xrb.child==(HANDLE)10&&xrb.controller==(HWND)1&&xrb.token=="current-token");CHECK(xrb.revision==revision&&xrb.nextAuth==scheduled);CHECK(xrb.key==-1&&xrb.scale==-1&&xrb.strength==-1&&!xrb.needReplay);
    CHECK(RackBridge_Command(3,5,2,500,0)==0);CHECK(RackBridge_Command(4,500,0,0,0)==0);CHECK(RackBridge_Command(9,0,0,0,0)==0);CHECK(!xrb_apply(false)&&!xrb_apply(true));CHECK(xrb.key==-1&&xrb.scale==-1&&xrb.strength==-1&&test_ops.empty());
    test_pause_status=0xc0000000UL;CHECK(xrb_tick()==0);CHECK(xrb.error==XRB_CONNECTING&&xrb.pauseHandshake&&xrb.pauseRevision==xrb.installedRevision);CHECK(test_ops.size()==2&&test_ops[0]==ATC_PAUSE&&test_payloads[1]=="paused");
    unsigned before=test_ops.size();CHECK(xrb_tick()==0);CHECK(test_ops.size()==before+1&&test_payloads.back()=="paused");test_pause_status=0x80000000UL;CHECK(xrb_tick()==1);CHECK(xrb.paused&&!xrb.pauseHandshake&&xrb.error==XRB_OK);CHECK(xrb.nextAuth==scheduled&&xrb.child==(HANDLE)10&&test_launches==0);
    for(unsigned i=0;i<test_ops.size();i++)CHECK(test_ops[i]!=ATC_APPLY&&test_ops[i]!=ATC_FEEL&&test_ops[i]!=ATC_EJECT&&test_ops[i]!=ATC_QUIT);
    CHECK(RackBridge_Command(16,1,0,0,0)==1&&!xrb.pauseHandshake);CHECK(RackBridge_Command(16,0,0,0,0)==1&&!xrb.paused);test_ops.clear();test_payloads.clear();CHECK(xrb_tick()==1);for(unsigned i=0;i<test_ops.size();i++)CHECK(test_ops[i]!=ATC_APPLY);CHECK(RackBridge_Command(3,7,1,600,0)==1);CHECK(test_ops.back()==ATC_APPLY&&test_payloads.back()=="key=7;scale=Minor;retune=0.600");CHECK(xrb.child==(HANDLE)10&&test_launches==0);
    /* Rapid OFF/ON cannot bypass a pause already dispatched or awaiting ack.
       A fresh new target may be cached but stays fenced until real readback. */
    reset();CHECK(RackBridge_Command(16,1,0,0,0)==1);test_pause_status=0xc0000000UL;CHECK(xrb_tick()==0);CHECK(RackBridge_Command(16,0,0,0,0)==1);CHECK(!xrb.paused&&xrb.pauseHandshake);CHECK(RackBridge_Command(3,9,2,700,0)==0&&xrb.needReplay);test_ops.clear();test_payloads.clear();CHECK(xrb_tick()==0);for(unsigned i=0;i<test_ops.size();i++)CHECK(test_ops[i]!=ATC_APPLY);test_pause_status=0x80000000UL;CHECK(xrb_tick()==1);CHECK(!xrb.pauseHandshake&&!xrb.needReplay&&test_launches==0);{bool current=false;for(unsigned i=0;i<test_ops.size();i++)if(test_ops[i]==ATC_APPLY){CHECK(test_payloads[i]=="key=9;scale=Chromatic;retune=0.700");current=true;}CHECK(current);}
    /* Pause survives a successful scheduled renewal, does not cancel the HTTP
       result, and installs its barrier again for the freshly signed session. */
    reset();xrb.token="old-token";xrb.nextAuth=0;test_http_hook=pause_during_http;worker_once();CHECK(test_http_calls==1&&test_http_renew&&xrb.paused&&xrb.enabled&&!xrb.pending.empty());CHECK(xrb_tick()==1);CHECK(xrb.haveLease&&xrb.paused&&!xrb.pauseHandshake&&xrb.installedRevision==xrb.revision);{unsigned authorize=0,pause=0;for(unsigned i=0;i<test_ops.size();i++){authorize+=test_ops[i]==ATC_AUTHORIZE;pause+=test_ops[i]==ATC_PAUSE;CHECK(test_ops[i]!=ATC_APPLY&&test_ops[i]!=ATC_FEEL&&test_ops[i]!=ATC_QUIT);}CHECK(authorize==1&&pause==1);}
    /* Refusal, missing acknowledgement, transport failure and lost consent
       never become a falsely successful pause or bypass normal invalidation. */
    reset();RackBridge_Command(16,1,0,0,0);test_fail_pause=true;CHECK(xrb_tick()==0&&xrb.pauseHandshake&&xrb.pauseRevision==0&&xrb.error==XRB_STALLED);test_fail_pause=false;test_pause_reply=ATC_REPLY_BAD_PACKET;CHECK(xrb_tick()==0&&xrb.error==XRB_PROTOCOL&&xrb.pauseRevision==0);test_pause_reply=ATC_REPLY_OK;test_pause_status=0;CHECK(xrb_tick()==0&&xrb.error==XRB_PROTOCOL&&xrb.pauseHandshake);test_pause_status=0x80000000UL;CHECK(xrb_tick()==1);
    test_consent=false;CHECK(xrb_tick()==0&&!xrb.enabled&&!xrb.haveLease&&xrb.error==XRB_DISABLED);{bool quit=false,eject=false;for(unsigned i=0;i<test_ops.size();i++){quit|=test_ops[i]==ATC_QUIT;eject|=test_ops[i]==ATC_EJECT;}CHECK(quit&&eject);}
    reset();RackBridge_Command(16,1,0,0,0);xrb.nextAuth=0;test_http_error=XRB_DENIED;test_http_reason="invalid_token";worker_once();CHECK(!xrb.haveLease&&xrb.token.empty()&&xrb.pending.empty()&&xrb.error==XRB_DENIED);CHECK(xrb_tick()==0&&!xrb.controller);CHECK(xrb.paused);
    reset();RackBridge_Command(16,1,0,0,0);CHECK(RackBridge_Command(7,0,0,0,0)==1&&!xrb.enabled&&!xrb.haveLease);CHECK(RackBridge_Command(8,0,0,0,0)==1&&!xrb.configured);CHECK(RackBridge_Command(16,0,0,0,0)==0);
        /* Backoff 1,2,4,8,16,30 s with +/-25 % jitter. */
    for(unsigned f=1;f<=8;f++){ULONGLONG base=f>5?30000ULL:1000ULL<<(f-1);for(unsigned k=0;k<64;k++){ULONGLONG b=xrb_backoff(f);CHECK(b>=base*3/4&&b<base*5/4);}}
    printf("bridge production extraction checks=%u failures=%u\n",checks,failures);return failures?1:0;
}
'''
    path.write_text(declarations,encoding='utf-8')

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--out',required=True,type=Path);args=parser.parse_args();write_harness(args.out)
