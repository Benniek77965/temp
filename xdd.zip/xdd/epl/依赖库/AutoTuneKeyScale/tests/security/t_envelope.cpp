/* CLI around the production companion_envelope.h so test_envelope_crypto.py can
   cross-check every primitive against OpenSSL (python cryptography). Each command
   reads hex arguments and prints hex results; nothing here re-implements crypto. */
#include "companion_security.h"
#include "companion_envelope.h"
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string>

static std::vector<unsigned char> unhex(const char* s){
    std::vector<unsigned char> v;size_t n=strlen(s);if(n==1&&s[0]=='-')return v;
    if(n%2){fprintf(stderr,"odd hex\n");exit(2);}v.resize(n/2);
    if(n&&!atcs_hex_decode(s,(unsigned)n,v.data(),(unsigned)v.size())){fprintf(stderr,"bad hex\n");exit(2);}return v;
}
static void hex(const unsigned char* p,size_t n){for(size_t i=0;i<n;i++)printf("%02x",p[i]);}
int main(int argc,char** argv){
    if(argc<2)return 2;
    std::string cmd=argv[1];
    if(cmd=="aes"&&argc==4){std::vector<unsigned char> k=unhex(argv[2]),in=unhex(argv[3]);if(k.size()!=32||in.size()!=16)return 2;
        unsigned char rk[240],out[16];atce_aes256_expand(k.data(),rk);atce_aes256_block(rk,in.data(),out);hex(out,16);printf("\n");return 0;}
    if(cmd=="seal"&&argc==6){std::vector<unsigned char> k=unhex(argv[2]),iv=unhex(argv[3]),aad=unhex(argv[4]),pt=unhex(argv[5]);if(k.size()!=32||iv.size()!=12)return 2;
        std::vector<unsigned char> ct(pt.size()+1);unsigned char tag[16];atce_gcm_seal(k.data(),iv.data(),aad.data(),aad.size(),pt.data(),pt.size(),ct.data(),tag);
        hex(ct.data(),pt.size());hex(tag,16);printf("\n");return 0;}
    if(cmd=="open"&&argc==6){std::vector<unsigned char> k=unhex(argv[2]),iv=unhex(argv[3]),aad=unhex(argv[4]),box=unhex(argv[5]);if(k.size()!=32||iv.size()!=12||box.size()<16)return 2;
        size_t n=box.size()-16;std::vector<unsigned char> pt(n+1,0xAA);
        int ok=atce_gcm_open(k.data(),iv.data(),aad.data(),aad.size(),box.data(),n,box.data()+n,pt.data());
        if(!ok){for(size_t i=0;i<n;i++)if(pt[i]){printf("LEAK\n");return 3;}printf("FAIL\n");return 0;}
        printf("OK ");hex(pt.data(),n);printf("\n");return 0;}
    if(cmd=="hkdf"&&argc==6){std::vector<unsigned char> ikm=unhex(argv[2]),salt=unhex(argv[3]),info=unhex(argv[4]);size_t L=(size_t)atoi(argv[5]);
        std::vector<unsigned char> out(L+1);if(!atce_hkdf_sha256(ikm.data(),ikm.size(),salt.data(),salt.size(),info.data(),info.size(),out.data(),L)){printf("FAIL\n");return 0;}
        hex(out.data(),L);printf("\n");return 0;}
    if(cmd=="spki"&&argc==3){std::vector<unsigned char> der=unhex(argv[2]);unsigned char m[256];
        if(!atce_spki_rsa2048(der.data(),der.size(),m)){printf("REJECT\n");return 0;}printf("OK ");hex(m,256);printf("\n");return 0;}
    if(cmd=="oaep"&&argc==5){std::vector<unsigned char> der=unhex(argv[2]),msg=unhex(argv[3]),seed=unhex(argv[4]);unsigned char m[256],c[256];
        if(seed.size()!=32||!atce_spki_rsa2048(der.data(),der.size(),m)){printf("REJECT\n");return 0;}
        if(!atce_oaep_encrypt(m,msg.data(),msg.size(),seed.data(),c)){printf("FAIL\n");return 0;}hex(c,256);printf("\n");return 0;}
    if(cmd=="b64"&&argc==3){std::vector<unsigned char> in=unhex(argv[2]);std::string s=atce_b64url(in.data(),in.size());printf("%s\n",s.c_str());
        std::vector<unsigned char> back(in.size()+4);int n=s.empty()?0:atcs_b64_decode(s.data(),(unsigned)s.size(),back.data(),(unsigned)back.size());
        if(in.size()&&(n!=(int)in.size()||memcmp(back.data(),in.data(),in.size()))){printf("ROUNDTRIP-FAIL\n");return 3;}return 0;}
    return 2;
}
