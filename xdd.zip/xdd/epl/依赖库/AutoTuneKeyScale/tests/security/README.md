# 共享安全协议与桥逻辑验证

本套件直接包含生产 `companion_security.h`、`companion_protocol.h`、`companion_envelope.h`、`rack_bridge_json.h`，不在测试中重写加解密、HMAC、base64或JSON解析器。桥逻辑测试从当前生产 `keyscale_rack_bridge.cpp` 提取完整函数体，替换的仅是操作系统、时钟、HTTP与消息传输边界。

运行：

```bat
python tests\security\run_security.py --out "D:\RackLinkBuild\security-001" --toolchain-bin "D:\MinGW\bin"
python tests\security\test_build_versions.py
python tests\security\test_envelope_crypto.py
python tests\security\test_bridge_v3.py
python tests\security\test_bridge_v3.py --wine wine
```

`--out` 必须为空且位于项目源码目录之外。需要宿主g++、Python和开发用cryptography依赖（`python -m pip install cryptography`），不依赖Python授权服务或SQLite；Windows编译需要win32线程模型的x86_64/i686 MinGW。可选 `--wine /真实Wine路径`。未找到Wine时只编译Windows程序，报告明确标注运行未验证。

验证项目：

- 原生产header的密文seal/open、MAC篡改、错误密钥、错误会话、到期、重放、最大序号、最大明文、截断和输出长度边界。
- XAT3固定顺序claims（拒绝XAT2）、签名内racks/plugins黑名单的UTF-8实际basename、ASCII大小写折叠、排序去重、32项/128字节/2048总长度边界、末尾LF、重复/未知字段、规范大小写hex、整数溢出与前导零、base64url非法padding及非零pad bits。
- JSON重复字段（含转义后同名）、尾随数据、数字语法、嵌套深度、大小限制、非法转义、代理对、非法UTF-8、标量类型。
- 提取生产 `xrb_apply`、`xrb_tick`、`xrb_deactivate`、`RackBridge_Command`、`xrb_auth_worker`，验证未授权与到期不发apply、显式关闭不被tick恢复、切调清旧确认、失败状态不被OK覆盖、网络失败清旧token、下一次使用authorize、过期workerEpoch不得提交结果；30秒等短租约按已验签到期时间提前续期，不固定等到30秒；相同iat仅完整claims一致才幂等，短暂失效后仍拒绝倒退租约。
- 协议v3信封原语（`companion_envelope.h`）：AES-256（FIPS-197）、AES-256-GCM、HKDF-SHA256（RFC 5869）、RSA-OAEP-SHA256（RFC 8017）、严格RSA-2048 SPKI解析、base64url，共245项与OpenSSL交叉验证（`test_envelope_crypto.py`）。
- 提取生产 `xrb_transport_fetch`、`xrb_authorize_http`、`xrb_authorize_response`、`xrb_backoff`，Python用真实OpenSSL扮演服务端（`test_bridge_v3.py`，34项）：传输公钥签名、kid与SPKI核对后才发凭据，外层不出现登录key与机器码，续期复用缓存公钥，服务端换钥只重取一次，回复被篡改、重放或换路径都打不开，加密拒绝与未加密限流的映射，退避1～30秒±25%抖动。`--wine` 用发布用的i686 MinGW编出32位Windows版在Wine里跑同一套。
- 提取生产HTTP函数（`xrb_http_post`）和异步context/回调，验证慢速逐字节响应的总8秒截止、STOP的50毫秒轮询、成功响应、延迟及即时HANDLE_CLOSING下body/readbuffer的生命期；使用确定性WinHTTP边界替身，不替代Windows网络栈运行。
- 同时提取桥tick与controller实际状态快照，验证手工改目标后不会把别的key/scale确认算给桥缓存目标；仅IPC路由替换，expect查询语法另由companion套件验证。正常续期保留手工目标，失效重新授权重推，FEEL不能清除待重推key，跨账户errors标记映射身份错误。
- 用规范XAT3测试claims和临时RSA密钥生成测试令牌、公钥头，与生产header的自写RSA验签程序交叉编译（不再经过任何Windows专属API）；覆盖有效签名、篡改、错父PID/设备、到期、未来iat、缺末尾LF及重复claims。此fixture只验证原生签名合同，不是Python授权服务，也不代表已经执行EPL服务端。
- 从真实agent／控制器／桥源码读取build标识并要求一致；测试读取实际控制器和agent版本，避免测试继续使用过期硬编码。另对三份实际源副本分别改错build，确认检查器拒绝漂移。当前控制器5、agent1166；WM帧3／XAT3保持独立版本（与服务端授权的“协议v3信封”是两回事）。

临时RSA私钥仅存在Python内存，不写文件。测试公钥、带随机会话密钥的测试token与可执行程序仅在输出目录，不能并入生产源码或发布资源。令牌有效期120秒，Windows运行验证必须由脚本当场生成并运行，不能把过期fixture拿去当失败结论。

宿主密文/JSON测试启用AddressSanitizer与UndefinedBehaviorSanitizer；状态桥提取程序启用UndefinedBehaviorSanitizer，HTTP提取程序启用AddressSanitizer与UndefinedBehaviorSanitizer。本会话容器没有可读的`/proc/<pid>/task`，LeakSanitizer因此由测试专用hook显式关闭。hook不进入任何生产二进制。报告记录编译告警数和原始日志，不把告警隐藏成零。

RSA验签本身已在宿主Linux构建上用真实密钥对和临时测试token直接证明；通过宿主提取测试仍不能替代真实Windows的WinHTTP与证书校验、UIPI、同意流程、进程生命期或真实机架/插件测试。报告的 `windows_runtime_verified` 与 `bridge_logic.origin` 用于区分这些验证边界。
