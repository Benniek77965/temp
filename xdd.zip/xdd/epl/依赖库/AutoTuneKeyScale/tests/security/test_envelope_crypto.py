#!/usr/bin/env python3
"""Cross-check the production rack-link envelope primitives (vst3/cpp/companion_envelope.h)
against OpenSSL via python cryptography: AES-256 (FIPS-197), AES-256-GCM in both
directions with tamper rejection, HKDF-SHA256 (RFC 5869), RSA-OAEP(SHA-256) encryption
decrypted by OpenSSL, the strict RSA-2048 SubjectPublicKeyInfo parser and base64url.
The C side is compiled natively from the shipped header; nothing is re-implemented here."""
import base64, os, random, subprocess, sys, tempfile
from pathlib import Path
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

ROOT = Path(__file__).resolve().parents[2]
checks = []
def check(name, ok):
    checks.append((name, bool(ok)))
    if not ok: print('FAIL', name)

def main():
    rng = random.Random(1166)
    with tempfile.TemporaryDirectory(prefix='envelope-', dir=os.environ.get('XHH_TEST_TMP')) as d:
        exe = Path(d) / 't_envelope'
        build = subprocess.run(['g++', '-std=c++11', '-O1', '-Wall', '-Wextra', '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
                                '-I', str(ROOT / 'vst3/cpp'), str(ROOT / 'tests/security/t_envelope.cpp'), '-o', str(exe)],
                               capture_output=True, text=True)
        import re as _re
        own = [l for l in build.stderr.splitlines() if _re.search(r'(companion_envelope\.h|t_envelope\.cpp):\d+:\d+: warning', l)]
        check('compile_new_code_without_warnings', build.returncode == 0 and not own)
        if own: print('\n'.join(own[:10]))
        if build.returncode: print(build.stderr[-3000:]); return 1
        env = {**os.environ, 'ASAN_OPTIONS': 'detect_leaks=0'}
        def run(*args):
            p = subprocess.run([str(exe), *args], capture_output=True, text=True, env=env)
            if p.returncode not in (0,): raise AssertionError((args[0], p.returncode, p.stderr[-800:]))
            return p.stdout.strip()
        h = lambda b: b.hex() if b else '-'
        # AES-256 FIPS-197 Appendix C.3 plus random blocks against OpenSSL ECB (single block).
        check('aes256_fips197_c3', run('aes', '000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f', '00112233445566778899aabbccddeeff') == '8ea2b7ca516745bfeafc49904b496089')
        for i in range(40):
            k, blk = os.urandom(32), os.urandom(16)
            enc = Cipher(algorithms.AES(k), modes.ECB()).encryptor()
            check(f'aes256_random_{i}', run('aes', k.hex(), blk.hex()) == (enc.update(blk) + enc.finalize()).hex())
        # AES-256-GCM: C seal -> OpenSSL open, OpenSSL seal -> C open, lengths across block boundaries.
        lengths = [0, 1, 15, 16, 17, 31, 32, 33, 100, 255, 256, 1000, 4100]
        for i, n in enumerate(lengths * 2):
            k, iv, aad, pt = os.urandom(32), os.urandom(12), os.urandom(rng.choice([0, 1, 16, 20, 47, 120])), os.urandom(n)
            box = bytes.fromhex(run('seal', k.hex(), iv.hex(), h(aad), h(pt)))
            check(f'gcm_c_seal_openssl_open_{i}_{n}', AESGCM(k).decrypt(iv, box, aad or None) == pt)
            ossl = AESGCM(k).encrypt(iv, pt, aad or None)
            out = run('open', k.hex(), iv.hex(), h(aad), ossl.hex())
            check(f'gcm_openssl_seal_c_open_{i}_{n}', out == ('OK ' + pt.hex()).strip())
            # Tamper: ciphertext, tag, AAD, IV each rejected and no plaintext released.
            bad = bytearray(ossl); bad[rng.randrange(len(bad))] ^= 1 << rng.randrange(8)
            check(f'gcm_tamper_box_{i}', run('open', k.hex(), iv.hex(), h(aad), bytes(bad).hex()) == 'FAIL')
            check(f'gcm_tamper_aad_{i}', run('open', k.hex(), iv.hex(), (aad + b'x').hex(), ossl.hex()) == 'FAIL')
            iv2 = bytearray(iv); iv2[0] ^= 0x80
            check(f'gcm_tamper_iv_{i}', run('open', k.hex(), bytes(iv2).hex(), h(aad), ossl.hex()) == 'FAIL')
        # HKDF-SHA256: RFC 5869 test case 1 and random lengths against OpenSSL.
        tc1 = run('hkdf', '0b' * 22, '000102030405060708090a0b0c', 'f0f1f2f3f4f5f6f7f8f9', '42')
        check('hkdf_rfc5869_case1', tc1 == '3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf34007208d5b887185865')
        for i in range(20):
            ikm, salt, info, L = os.urandom(rng.choice([16, 32, 64])), os.urandom(rng.choice([0, 8, 32, 80])), os.urandom(rng.choice([0, 5, 19, 64])), rng.choice([1, 31, 32, 33, 64, 100])
            ref = HKDF(algorithm=hashes.SHA256(), length=L, salt=salt or None, info=info).derive(ikm)
            check(f'hkdf_random_{i}', run('hkdf', ikm.hex(), h(salt), h(info), str(L)) == ref.hex())
        # RSA-OAEP(SHA-256): C encrypts with a parsed SPKI; OpenSSL decrypts with the private key.
        for i in range(6):
            key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
            der = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
            n = key.public_key().public_numbers().n.to_bytes(256, 'big')
            check(f'spki_parse_{i}', run('spki', der.hex()) == 'OK ' + n.hex())
            for msg_len in (0, 1, 32, 190):
                msg, seed = os.urandom(msg_len), os.urandom(32)
                ct = run('oaep', der.hex(), h(msg), seed.hex())
                got = key.decrypt(bytes.fromhex(ct), padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
                check(f'oaep_c_encrypt_openssl_decrypt_{i}_{msg_len}', got == msg)
            check(f'oaep_rejects_191_bytes_{i}', run('oaep', der.hex(), os.urandom(191).hex(), os.urandom(32).hex()) == 'FAIL')
        # The strict SPKI parser rejects every other key shape.
        k3072 = rsa.generate_private_key(public_exponent=65537, key_size=3072).public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
        k3 = rsa.generate_private_key(public_exponent=3, key_size=2048).public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
        pkcs1 = rsa.generate_private_key(public_exponent=65537, key_size=2048).public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.PKCS1)
        check('spki_rejects_3072', run('spki', k3072.hex()) == 'REJECT')
        check('spki_rejects_exponent_3', run('spki', k3.hex()) == 'REJECT')
        check('spki_rejects_pkcs1', run('spki', pkcs1.hex()) == 'REJECT')
        check('spki_rejects_truncated', run('spki', der[:-1].hex()) == 'REJECT')
        check('spki_rejects_trailing_byte', run('spki', (der + b'\x00').hex()) == 'REJECT')
        short = bytearray(der); short[33] = 0x7f
        check('spki_rejects_short_modulus', run('spki', bytes(short).hex()) == 'REJECT')
        # base64url without padding, round-tripped through the production decoder.
        for n in (1, 2, 3, 4, 5, 31, 32, 33, 256, 1000):
            data = os.urandom(n)
            check(f'b64url_{n}', run('b64', data.hex()) == base64.urlsafe_b64encode(data).decode().rstrip('='))
    failed = [n for n, ok in checks if not ok]
    print(('PASS' if not failed else 'FAIL'), len(checks) - len(failed), '/', len(checks))
    return 1 if failed else 0

if __name__ == '__main__':
    sys.exit(main())
