/* Self-contained RSA verification (no Windows CNG involved) against a token
   emitted by the actual Python service.
   fixture_tokens.h and public key are generated ONLY inside the test output tree. */
#include "companion_security.h"
#include "fixture_tokens.h"
#include <stdio.h>
#include <string>
int main(){
    unsigned failures=0,checks=0;ATCS_Claims out;
#define CHECK(expr) do{checks++;if(!(expr)){printf("FAIL line%u\n",(unsigned)__LINE__);failures++;}}while(0)
    CHECK(atcs_verify_token(TOKEN_VALID,(unsigned)strlen(TOKEN_VALID),1234,FIXTURE_DEVICE,&out));
    CHECK(!strcmp(out.license,"L1"));CHECK(!strcmp(out.sid,FIXTURE_SID));CHECK(out.parent==1234);CHECK(out.policy==1);
    CHECK(!atcs_verify_token(TOKEN_VALID,(unsigned)strlen(TOKEN_VALID),1235,FIXTURE_DEVICE,&out));
    CHECK(!atcs_verify_token(TOKEN_VALID,(unsigned)strlen(TOKEN_VALID),1234,"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc",&out));
    std::string changed(TOKEN_VALID);changed[changed.size()-8]=changed[changed.size()-8]=='A'?'B':'A';
    CHECK(!atcs_verify_token(changed.data(),(unsigned)changed.size(),1234,FIXTURE_DEVICE,&out));
    CHECK(!atcs_verify_token(TOKEN_EXPIRED,(unsigned)strlen(TOKEN_EXPIRED),1234,FIXTURE_DEVICE,&out));
    CHECK(!atcs_verify_token(TOKEN_FUTURE,(unsigned)strlen(TOKEN_FUTURE),1234,FIXTURE_DEVICE,&out));
    CHECK(!atcs_verify_token(TOKEN_NO_FINAL_LF,(unsigned)strlen(TOKEN_NO_FINAL_LF),1234,FIXTURE_DEVICE,&out));
    CHECK(!atcs_verify_token(TOKEN_DUPLICATE_CLAIM,(unsigned)strlen(TOKEN_DUPLICATE_CLAIM),1234,FIXTURE_DEVICE,&out));
    printf("self-contained RSA/server cross checks=%u failures=%u\n",checks,failures);return failures?1:0;
}
