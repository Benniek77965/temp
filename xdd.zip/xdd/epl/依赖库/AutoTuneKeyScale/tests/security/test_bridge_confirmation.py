"""Cross-module extraction: exact bridge tick and controller status snapshot.
Only IPC routing of the bridge-generated canonical query is substituted; the
controller dispatcher grammar is tested separately by tests/companion.
"""
from pathlib import Path
from test_bridge_logic import write_harness as write_bridge, extract, ROOT

def write_harness(path):
    write_bridge(path);text=path.read_text(encoding='utf-8')
    controller=(ROOT/'vst3/cpp/AutoTune_KeyScale_Controller.cpp').read_text(encoding='utf-8')
    declarations=r'''
typedef intptr_t LRESULT;
static LONG InterlockedCompareExchange(volatile LONG*,LONG,LONG);
static LONG g_compMismatchFull=0;
static LONG g_authorized=1,g_compGoalValid=1,g_compOld=0,g_compAuthError=0,g_compRacks=1,g_compCaptured=1,g_compPending=0,g_compConfirmed=1;
static int g_compLock=0,g_cmdWriteFail=0,g_agentMissing=0,g_agentStale=0,g_blockedHosts=0,g_blockedOther=0,g_hostsOverflow=0,g_sgFull=0,g_aggFull=0;
static ATC_Apply g_compGoal={7,1,-1};
static void EnterCriticalSection(int*){}static void LeaveCriticalSection(int*){}
'''
    declarations+=extract(controller,'static LRESULT companion_status_reply(')+'\n'
    text=text.replace('static bool xrb_send(',declarations+'static bool xrb_send(')
    needle='    if(output)*output=value;return true;'
    routing=r'''
    if(op==ATC_STATUS&&(!payload||!strcmp(payload,"")||!strncmp(payload,"expect=",7))){int key=-1,scale=-1;if(payload&&*payload)sscanf(payload,"expect=%d:%d",&key,&scale);value=(uint32_t)companion_status_reply(key,scale);}
'''
    text=text.replace(needle,routing+needle)
    text=text[:text.index('int main(){')]+r'''
int main(){
    reset();xrb.key=3;xrb.scale=1;xrb.needReplay=false;g_compGoal.key=7;g_compGoal.scale=1;g_compConfirmed=1;
    CHECK(xrb_tick()==1);printf("bridge goal=%d controller goal=%d confirmed=%u\n",xrb.key,g_compGoal.key,(unsigned)(xrb.status&63));CHECK((xrb.status&63)==0);
    g_compGoal.key=3;CHECK(xrb_tick()==1);CHECK((xrb.status&63)==1);
    g_compGoal.scale=2;CHECK(xrb_tick()==1);CHECK((xrb.status&63)==0);
    g_compGoal.scale=1;g_compGoalValid=0;CHECK(xrb_tick()==1);CHECK((xrb.status&63)==0);
    xrb.key=xrb.scale=-1;CHECK(xrb_tick()==1);CHECK((xrb.status&63)==1);
    g_compMismatchFull=1;CHECK(xrb_tick()==1);CHECK(xrb.status&0x02000000u);
    g_compMismatchFull=0;CHECK(xrb_tick()==1);CHECK(!(xrb.status&0x02000000u));
    printf("bridge/controller confirmation checks=%u failures=%u\n",checks,failures);return failures?1:0;
}
'''
    path.write_text(text,encoding='utf-8')
if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();write_harness(a.out)
