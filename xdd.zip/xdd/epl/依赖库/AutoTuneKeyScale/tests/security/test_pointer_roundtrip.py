#!/usr/bin/env python3
"""End-to-end check of the agent<->controller pointer handshake, run for real against a temp filesystem.

The agent is injected into a host process and cannot know the main program's runtime dir; its only link to the
data folder (COMMDIR) is a pointer file. The controller writes two: the fast path %TEMP%\\at8_commdir.txt, and --
because a temp clean-up can delete that while the controller runs for days -- a copy at %LOCALAPPDATA%\\
AutoTune_KeyScale\\commdir.txt. The agent reads the %TEMP% one first, then the backup, then falls back to the
%LOCALAPPDATA%\\AutoTune_KeyScale folder itself (an older controller kept its files there directly), then %TEMP%\\at8.

This compiles a small C program that reproduces the two sides' path logic (kept deliberately close to the C++ in
AutoTune_KeyScale_Controller.cpp resolve_commdir and combined/at_agent.cpp resolve_commdir) and exercises five
situations against a real directory tree. It needs a C compiler; if none is present the test skips (returns 0) so
it never blocks the suite on a machine without one. The source-text invariants are covered separately by
test_runtime_dir_and_buildflags.py; this adds the behavioural half.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

C_SOURCE = r'''
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <stdlib.h>
#define SUB "AutoTune_KeyScale"
static char TEMP_[1024], LOCAL_[1024];
/* controller resolve_commdir: pointer-writing part (equivalent) */
static void controller_write_pointers(const char* commdir){
    char ptr[1200]; snprintf(ptr,sizeof ptr,"%s/at8_commdir.txt",TEMP_);
    FILE* f=fopen(ptr,"w"); if(f){ fprintf(f,"%s\n",commdir); fclose(f); }
    char bak[1200]; snprintf(bak,sizeof bak,"%s/%s",LOCAL_,SUB); mkdir(bak,0777);
    if(strcmp(bak,commdir)!=0){   /* self-reference guard (same_dir; string compare suffices here) */
        char bp[1300]; snprintf(bp,sizeof bp,"%s/commdir.txt",bak);
        FILE* bf=fopen(bp,"w"); if(bf){ fprintf(bf,"%s\n",commdir); fclose(bf); } } }
/* agent resolve_commdir: fallback chain (equivalent) */
static void agent_resolve(char* out){
    out[0]=0;
    char ptr[1200]; snprintf(ptr,sizeof ptr,"%s/at8_commdir.txt",TEMP_);
    FILE* f=fopen(ptr,"r");
    if(f){ if(fgets(out,1024,f)){ int k=strlen(out); while(k>0&&(unsigned char)out[k-1]<=' ')out[--k]=0;} fclose(f);} 
    if(!out[0]){ char bp[1300]; snprintf(bp,sizeof bp,"%s/%s/commdir.txt",LOCAL_,SUB);
        FILE* bf=fopen(bp,"r");
        if(bf){ char d[1024]=""; if(fgets(d,sizeof d,bf)){int k=strlen(d);while(k>0&&(unsigned char)d[k-1]<=' ')d[--k]=0;} fclose(bf);
            struct stat st; if(d[0]&&stat(d,&st)==0&&S_ISDIR(st.st_mode)) snprintf(out,1024,"%s",d); } }
    if(!out[0]){ char d[1200]; snprintf(d,sizeof d,"%s/%s",LOCAL_,SUB);
        struct stat st; if(stat(d,&st)==0&&S_ISDIR(st.st_mode)) snprintf(out,1024,"%s",d); }
    if(!out[0]) snprintf(out,1024,"%s/at8",TEMP_); }
static int pass_=0, fail_=0;
static void check(const char* name,int ok){ if(ok)pass_++; else{fail_++; printf("FAIL %s\n",name);} }
int main(int argc,char** argv){
    const char* base=argv[1];
    snprintf(TEMP_,sizeof TEMP_,"%s/temp",base); snprintf(LOCAL_,sizeof LOCAL_,"%s/local",base);
    char runtime[1200]; snprintf(runtime,sizeof runtime,"%s/runtime/keyscale_rack",base);
    char got[1024];
    controller_write_pointers(runtime);
    agent_resolve(got);
    check("normal_uses_main_pointer", strcmp(got,runtime)==0);
    { char c[1300]; snprintf(c,sizeof c,"%s/at8_commdir.txt",TEMP_); remove(c); }
    agent_resolve(got);
    check("temp_pointer_gone_uses_backup", strcmp(got,runtime)==0);
    { char c[1300]; snprintf(c,sizeof c,"rm -rf %s/runtime",base); if(system(c)){} }
    agent_resolve(got);
    char la_sub[1200]; snprintf(la_sub,sizeof la_sub,"%s/%s",LOCAL_,SUB);
    check("stale_backup_rejected_falls_back_to_localappdata", strcmp(got,la_sub)==0);
    { char c[1300]; snprintf(c,sizeof c,"%s/at8_commdir.txt",TEMP_); remove(c);
      char c2[1300]; snprintf(c2,sizeof c2,"%s/commdir.txt",la_sub); remove(c2); }
    controller_write_pointers(la_sub);
    { char bp[1300]; snprintf(bp,sizeof bp,"%s/commdir.txt",la_sub); struct stat st;
      check("self_ref_backup_pointer_not_written", stat(bp,&st)!=0); }
    agent_resolve(got);
    check("localappdata_commdir_resolves", strcmp(got,la_sub)==0);
    { char c[1300]; snprintf(c,sizeof c,"rm -rf %s/at8_commdir.txt %s",TEMP_,la_sub); if(system(c)){} }
    agent_resolve(got);
    char last[1200]; snprintf(last,sizeof last,"%s/at8",TEMP_);
    check("last_resort_temp_at8", strcmp(got,last)==0);
    printf("{\"pass\": %d, \"fail\": %d}\n",pass_,fail_);
    return fail_?1:0; }
'''


def main():
    cc = os.environ.get('CC', 'cc')
    compiler = shutil.which(cc) or shutil.which('gcc') or shutil.which('clang')
    if not compiler:
        print(json.dumps({'status': 'skipped', 'reason': 'no C compiler'}, ensure_ascii=False))
        return
    work = Path(tempfile.mkdtemp(prefix='ptr_rt_'))
    try:
        src = work / 'rt.c'
        src.write_text(C_SOURCE, encoding='utf-8')
        binary = work / 'rt'
        build = subprocess.run([compiler, '-O2', '-w', str(src), '-o', str(binary)], capture_output=True, text=True)
        assert build.returncode == 0, 'compile failed: ' + build.stderr
        tree = work / 'tree'
        (tree / 'temp').mkdir(parents=True)
        (tree / 'local').mkdir(parents=True)
        (tree / 'runtime' / 'keyscale_rack').mkdir(parents=True)
        run = subprocess.run([str(binary), str(tree)], capture_output=True, text=True)
        print(run.stdout.strip())
        assert run.returncode == 0, 'roundtrip failed:\n' + run.stdout + run.stderr
        result = json.loads(run.stdout.strip().splitlines()[-1])
        assert result['fail'] == 0 and result['pass'] == 6, result
    finally:
        shutil.rmtree(work, ignore_errors=True)


if __name__ == '__main__':
    main()
