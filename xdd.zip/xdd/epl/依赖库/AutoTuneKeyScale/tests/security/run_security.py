#!/usr/bin/env python3
"""Test production crypto/JSON headers; build test-only XAT3→self-contained-RSA fixtures.
No private key or generated test public key is written inside the production tree.
"""
import argparse
import base64
import contextlib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives import hashes
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent

def check_build_versions(root=ROOT):
    """Read the actual build identifiers; drift must fail before fixtures run."""
    def macro(relative, name):
        source=(root/relative).read_text(encoding='utf-8-sig')
        match=re.search(r'(?m)^\s*#define\s+'+re.escape(name)+r'\s+([0-9]+)\b',source)
        if not match:raise ValueError('Missing numeric build identifier '+name+' in '+relative)
        return int(match[1])
    versions={
        'agent':macro('combined/at_agent.cpp','AT_BUILD'),
        'controller_agent':macro('vst3/cpp/AutoTune_KeyScale_Controller.cpp','AT_BUILD_EXPECT'),
        'bridge_agent':macro('vst3/cpp/keyscale_rack_bridge.cpp','XRB_AGENT_BUILD'),
        'controller':macro('vst3/cpp/companion_protocol.h','ATC_CONTROLLER_VERSION'),
        'protocol':macro('vst3/cpp/companion_protocol.h','ATC_PROTOCOL_VERSION'),
    }
    if len({versions[name] for name in ('agent','controller_agent','bridge_agent')})!=1:
        raise ValueError('Agent build drift: '+repr(versions))
    return versions

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',required=True,type=Path)
    ap.add_argument('--toolchain-bin',type=Path)
    ap.add_argument('--wine',help='optional actual Wine executable')
    args=ap.parse_args();out=args.out.resolve()
    if out==ROOT or ROOT in out.parents:ap.error('--out must be outside the source tree')
    if out.exists() and any(out.iterdir()):ap.error('--out must be empty')
    out.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy()
    if args.toolchain_bin:env['PATH']=str(args.toolchain_bin.resolve())+os.pathsep+env.get('PATH','')
    report={'source_sha256':{},'private_key_written':False,'native':{},'windows':{},'limitations':[],'build_versions':check_build_versions()}
    for name in ('companion_security.h','companion_protocol.h','companion_mailbox.h','rack_bridge_json.h','keyscale_rack_bridge.cpp','AutoTune_KeyScale_Controller.cpp'):
        report['source_sha256'][name]=hashlib.sha256((ROOT/'vst3/cpp'/name).read_bytes()).hexdigest()
    report['agent_build_source_sha256']=hashlib.sha256((ROOT/'combined/at_agent.cpp').read_bytes()).hexdigest()
    def run(argv,label,extra=None,timeout=90):
        callenv=env.copy();callenv.update(extra or {})
        try:
            p=subprocess.run(list(map(str,argv)),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=callenv,timeout=timeout)
            (out/(label+'.log')).write_text(p.stdout,encoding='utf-8')
            return {'returncode':p.returncode,'log':label+'.log','output':p.stdout}
        except (OSError,subprocess.TimeoutExpired) as e:
            (out/(label+'.log')).write_text(type(e).__name__+': '+str(e),encoding='utf-8')
            return {'returncode':None,'log':label+'.log','output':type(e).__name__}
    cxx=shutil.which('g++',path=env['PATH'])
    if cxx:
        compile=run([cxx,'-std=c++11','-O1','-Wall','-Wextra','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',ROOT/'vst3/cpp',HERE/'t_security.cpp','-o',out/'t_security'],'native_compile')
        report['native']['compile']=compile['returncode'];report['native']['compiler_warnings']=compile['output'].count('warning:')
        if compile['returncode']==0:
            result=run([out/'t_security'],'native_run',{'ASAN_OPTIONS':'detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1'})
            report['native']['run']=result['returncode'];match=re.search(r'checks=(\d+) failures=(\d+)',result['output'])
            if match:report['native'].update(checks=int(match[1]),failures=int(match[2]))
        report['limitations'].append('LeakSanitizer explicitly disabled by test-only runtime hooks because this container lacks readable /proc task metadata; AddressSanitizer and UndefinedBehaviorSanitizer remain enabled.')
    else:report['native']['error']='g++ unavailable'
    sys.path.insert(0,str(HERE))
    from test_bridge_logic import write_harness
    bridge_cpp=out/'bridge_logic_extracted.cpp';write_harness(bridge_cpp)
    if cxx:
        built=run([cxx,'-std=c++11','-O1','-fsanitize=undefined','-fno-omit-frame-pointer','-I',ROOT/'vst3/cpp',bridge_cpp,'-o',out/'t_bridge_logic'],'bridge_logic_compile')
        report['bridge_logic']={'compile':built['returncode'],'origin':'actual xrb_apply/xrb_tick/xrb_deactivate/RackBridge_Command/xrb_auth_worker functions; only OS/time/HTTP/transport boundaries stubbed'}
        if built['returncode']==0:
            result=run([out/'t_bridge_logic'],'bridge_logic_run',{'UBSAN_OPTIONS':'halt_on_error=1'})
            report['bridge_logic']['run']=result['returncode'];match=re.search(r'checks=(\d+) failures=(\d+)',result['output'])
            if match:report['bridge_logic'].update(checks=int(match[1]),failures=int(match[2]))
    from test_bridge_http import write_harness as write_http_harness
    http_cpp=out/'bridge_http_extracted.cpp';write_http_harness(http_cpp)
    if cxx:
        built=run([cxx,'-std=c++11','-O1','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',ROOT/'vst3/cpp',http_cpp,'-o',out/'t_bridge_http'],'bridge_http_compile')
        report['bridge_http']={'compile':built['returncode'],'origin':'actual HTTP function and ownership helpers; deterministic WinHTTP boundary callbacks, clocks and cancellation'}
        if built['returncode']==0:
            result=run([out/'t_bridge_http'],'bridge_http_run',{'ASAN_OPTIONS':'detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1'})
            report['bridge_http']['run']=result['returncode'];match=re.search(r'checks=(\d+) failures=(\d+)',result['output'])
            if match:report['bridge_http'].update(checks=int(match[1]),failures=int(match[2]))
    from test_bridge_confirmation import write_harness as write_confirmation_harness
    confirmation_cpp=out/'bridge_confirmation_extracted.cpp';write_confirmation_harness(confirmation_cpp)
    if cxx:
        built=run([cxx,'-std=c++11','-O1','-fsanitize=undefined','-fno-omit-frame-pointer','-I',ROOT/'vst3/cpp',confirmation_cpp,'-o',out/'t_bridge_confirmation'],'bridge_confirmation_compile')
        report['bridge_confirmation']={'compile':built['returncode'],'origin':'actual bridge tick and controller status snapshot; IPC routing alone substituted'}
        if built['returncode']==0:
            result=run([out/'t_bridge_confirmation'],'bridge_confirmation_run',{'UBSAN_OPTIONS':'halt_on_error=1'})
            report['bridge_confirmation']['run']=result['returncode'];match=re.search(r'checks=(\d+) failures=(\d+)',result['output'])
            if match:report['bridge_confirmation'].update(checks=int(match[1]),failures=int(match[2]))
    from test_agent_pause import write_harness as write_pause_harness
    pause_cpp=out/'agent_pause_extracted.cpp';write_pause_harness(pause_cpp)
    if cxx:
        built=run([cxx,'-std=c++11','-O1','-fsanitize=undefined','-fno-sanitize-recover=all','-pthread','-I',ROOT/'vst3/cpp',pause_cpp,'-o',out/'t_agent_pause'],'agent_pause_compile')
        report['agent_pause']={'compile':built['returncode'],'origin':'actual signed mailbox filter, Agent pause/epoch and parameter writer functions; real blocked UI-thread ordering with explicit OS/plugin boundaries'}
        if built['returncode']==0:
            result=run([out/'t_agent_pause'],'agent_pause_run',{'UBSAN_OPTIONS':'halt_on_error=1'})
            report['agent_pause']['run']=result['returncode'];match=re.search(r'checks=(\d+) failures=(\d+)',result['output'])
            if match:report['agent_pause'].update(checks=int(match[1]),failures=int(match[2]))
    sys.path.insert(0,str(ROOT.parents[2]/'tools'))
    from racklink_keygen import public_header
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    fixture=out/'fixture';fixture.mkdir()
    now=int(time.time());sid=os.urandom(16).hex()
    # This is a test fixture of the native signed-claims contract, not a server
    # implementation or evidence that the EPL authorization service ran.
    claims=(f'ver=3\nsid={sid}\nlic=L1\ndev={"b"*64}\nparent=1234\n'
            f'iat={now}\nexp={now+120}\nkey={os.urandom(32).hex()}\n'
            'policy=1\nracks=\nplugins=\n').encode('ascii')
    def b64(data):return base64.urlsafe_b64encode(data).decode('ascii').rstrip('=')
    def signed(data):return 'XAT3.'+b64(data)+'.'+b64(key.sign(data,padding.PKCS1v15(),hashes.SHA256()))
    token=signed(claims)
    expired=claims.replace(('iat='+str(now)).encode(),('iat='+str(now-240)).encode()).replace(('exp='+str(now+120)).encode(),('exp='+str(now-120)).encode())
    future=claims.replace(('iat='+str(now)).encode(),('iat='+str(now+60)).encode()).replace(('exp='+str(now+120)).encode(),('exp='+str(now+180)).encode())
    values={'TOKEN_VALID':token,'TOKEN_EXPIRED':signed(expired),'TOKEN_FUTURE':signed(future),'TOKEN_NO_FINAL_LF':signed(claims[:-1]),'TOKEN_DUPLICATE_CLAIM':signed(claims+b'policy=1\n'),'FIXTURE_DEVICE':'b'*64,'FIXTURE_SID':sid}
    (fixture/'fixture_tokens.h').write_text(''.join('static const char '+name+'[]='+json.dumps(value)+';\n' for name,value in values.items()),encoding='ascii')
    (fixture/'companion_public_key.h').write_text(public_header(key),encoding='ascii')
    for name in ('companion_security.h','companion_protocol.h','companion_rsa_verify.h'):
        shutil.copyfile(ROOT/'vst3/cpp'/name,fixture/name)
    report['fixture']={'origin':'test-only canonical XAT3 contract fixture with disposable RSA; does not execute EPL service','expires_at':now+120,'public_key_configured_in_test_tree_only':True}
    wine=args.wine or shutil.which('wine',path=env['PATH']) or shutil.which('wine64',path=env['PATH'])
    for bits,triple in ((64,'x86_64-w64-mingw32'),(32,'i686-w64-mingw32')):
        compiler=shutil.which(triple+'-g++-win32',path=env['PATH'])
        if not compiler:report['windows'][str(bits)]={'compile':None,'reason':'MinGW Win32 compiler unavailable'};continue
        target=out/('w_token'+str(bits)+'.exe')
        built=run([compiler,'-std=c++11','-O2','-static','-static-libgcc','-static-libstdc++','-Wl,--no-insert-timestamp','-D_WIN32_WINNT=0x0601','-I',fixture,HERE/'w_token.cpp','-o',target,'-ladvapi32'],'windows'+str(bits)+'_compile')
        item={'compile':built['returncode'],'compiler_log':built['log']};report['windows'][str(bits)]=item
        if built['returncode']==0:
            item['sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
            if wine:
                actual=run([wine,target],'windows'+str(bits)+'_run',timeout=30);item['run']=actual['returncode'];item['runtime_log']=actual['log']
            else:item['run']=None;item['reason']='Wine unavailable; Windows executable compiled but not executed.'
    report['status']='passed' if report['native'].get('run')==0 and report.get('bridge_logic',{}).get('run')==0 and report.get('bridge_http',{}).get('run')==0 and report.get('bridge_confirmation',{}).get('run')==0 and report.get('agent_pause',{}).get('run')==0 and all(v.get('compile')==0 for v in report['windows'].values()) else 'failed'
    report['windows_runtime_verified']=bool(wine) and all(v.get('run')==0 for v in report['windows'].values())
    (out/'security_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));return 0 if report['status']=='passed' else 1

if __name__=='__main__':raise SystemExit(main())
