"""Mutation checks for the actual source-version reader, without source edits."""
import shutil
import tempfile
import unittest
from pathlib import Path
from run_security import ROOT,check_build_versions

class BuildVersions(unittest.TestCase):
    def test_actual_identifiers_agree(self):
        versions=check_build_versions()
        self.assertEqual(versions['agent'],versions['controller_agent'])
        self.assertEqual(versions['agent'],versions['bridge_agent'])

    def test_actual_source_mutations_are_rejected(self):
        files={'combined/at_agent.cpp':'AT_BUILD','vst3/cpp/AutoTune_KeyScale_Controller.cpp':'AT_BUILD_EXPECT','vst3/cpp/keyscale_rack_bridge.cpp':'XRB_AGENT_BUILD'}
        import re
        for selected,identifier in files.items():
            with self.subTest(source=selected),tempfile.TemporaryDirectory(prefix='xhh-build-guard-') as directory:
                root=Path(directory)
                for relative in list(files)+['vst3/cpp/companion_protocol.h']:
                    target=root/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/relative,target)
                target=root/selected
                source=target.read_text(encoding='utf-8-sig')
                source,count=re.subn(r'(?m)^(\s*#define\s+'+identifier+r'\s+)[0-9]+\b',r'\g<1>9999',source)
                self.assertEqual(count,1);target.write_text(source)
                with self.assertRaisesRegex(ValueError,'Agent build drift'):check_build_versions(root)

if __name__=='__main__':unittest.main()
