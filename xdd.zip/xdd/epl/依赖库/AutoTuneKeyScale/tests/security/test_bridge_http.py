"""Execute the real HTTP function and async ownership helpers with deterministic WinHTTP boundaries.
This tests deadlines and buffer lifetime; it does not emulate the Windows networking stack.
"""
from pathlib import Path
from test_bridge_logic import extract
ROOT=Path(__file__).resolve().parents[2]

def write_harness(path,source=None):
    text=source if source is not None else (ROOT/'vst3/cpp/keyscale_rack_bridge.cpp').read_text(encoding='utf-8')
    pre=r'''
#include "companion_security.h"
#include "companion_envelope.h"
#include "rack_bridge_json.h"
#include <string>
#include <map>
#include <stdio.h>
#include <stdlib.h>
#include <cwctype>
#include <cwchar>
extern "C" int __lsan_is_turned_off(){return 1;}
extern "C" const char* __asan_default_options(){return "detect_leaks=0";}
typedef int32_t LONG;typedef uint64_t ULONGLONG;typedef void* LPVOID;typedef uintptr_t DWORD_PTR;typedef int BOOL;
#define CALLBACK
#define TRUE 1
#define FALSE 0
#define ERROR_IO_PENDING 997
#define ERROR_WINHTTP_INTERNAL_ERROR 12004
#define INTERNET_SCHEME_HTTP 1
#define INTERNET_SCHEME_HTTPS 2
#define WINHTTP_ACCESS_TYPE_DEFAULT_PROXY 0
#define WINHTTP_NO_PROXY_NAME NULL
#define WINHTTP_NO_PROXY_BYPASS NULL
#define WINHTTP_FLAG_ASYNC 1
#define WINHTTP_FLAG_SECURE 2
#define WINHTTP_OPTION_SECURE_PROTOCOLS 1
#define WINHTTP_OPTION_REDIRECT_POLICY 2
#define WINHTTP_OPTION_CONTEXT_VALUE 3
#define WINHTTP_OPTION_REDIRECT_POLICY_NEVER 0
#define WINHTTP_NO_REFERER NULL
#define WINHTTP_DEFAULT_ACCEPT_TYPES NULL
#define WINHTTP_QUERY_STATUS_CODE 1
#define WINHTTP_QUERY_FLAG_NUMBER 2
#define WINHTTP_HEADER_NAME_BY_INDEX NULL
#define WINHTTP_NO_HEADER_INDEX NULL
#define WINHTTP_CALLBACK_STATUS_HANDLE_CLOSING 1
#define WINHTTP_CALLBACK_STATUS_REQUEST_ERROR 2
#define WINHTTP_CALLBACK_STATUS_READ_COMPLETE 3
#define WINHTTP_CALLBACK_STATUS_SENDREQUEST_COMPLETE 4
#define WINHTTP_CALLBACK_STATUS_HEADERS_AVAILABLE 5
#define WINHTTP_CALLBACK_FLAG_ALL_COMPLETIONS 1
#define WINHTTP_CALLBACK_FLAG_HANDLES 2
#define WAIT_OBJECT_0 0
#define WAIT_TIMEOUT 258
struct URL_COMPONENTS {DWORD dwStructSize,dwHostNameLength,dwUrlPathLength,dwExtraInfoLength,dwUserNameLength,dwPasswordLength;int nScheme,nPort;const wchar_t *lpszHostName,*lpszUrlPath;};
struct WINHTTP_ASYNC_RESULT {DWORD_PTR dwResult;DWORD dwError;};
struct Event{bool set;};typedef Event* HANDLE;
struct Internet;typedef Internet* HINTERNET;
typedef void(*Callback)(HINTERNET,DWORD_PTR,DWORD,LPVOID,DWORD);
#define WINHTTP_INVALID_STATUS_CALLBACK ((Callback)(intptr_t)-1)
struct Internet {int kind;DWORD_PTR context;Callback callback;};
static Internet session={1,0,NULL},connection={2,0,NULL},request={3,0,NULL};
static DWORD_PTR closingContext=0;static Callback closingCallback=NULL;static bool asyncMode=false;
static uint64_t tick=0,due=0;static DWORD pendingStatus=0,pendingLength=0;static void* pendingBuffer=NULL;static const char* sentBody=NULL;
static unsigned events=0,mode=0,offset=0;static bool delayedClose=true;
static DWORD requestFlags=0,connectedPort=0,redirectPolicy=999;static unsigned secureProtocolOptions=0,requestOpens=0;static bool failSecureProtocols=false;
static std::wstring openedPath;
static bool probeBeforeSignal=false;static void* probeContext=NULL;static int probeResult=-1;static int http_probe_wait();
static struct {volatile LONG running,enabled;} xrb={1,1};
static const std::string reply="{\"ok\":true,\"token\":\"fixture\"}";
static ULONGLONG GetTickCount64(){return tick;}
static LONG InterlockedExchange(volatile LONG* p,LONG v){LONG old=*p;*p=v;return old;}
static LONG InterlockedCompareExchange(volatile LONG* p,LONG v,LONG expected){LONG old=*p;if(old==expected)*p=v;return old;}
static LONG InterlockedIncrement(volatile LONG* p){return ++*p;}static LONG InterlockedDecrement(volatile LONG* p){return --*p;}
static HANDLE CreateEventW(void*,BOOL,BOOL set,void*){events++;Event* e=new Event();e->set=set;return e;}
static void CloseHandle(HANDLE e){events--;delete e;}static void SetEvent(HANDLE e){if(probeBeforeSignal){probeBeforeSignal=false;probeResult=http_probe_wait();}e->set=true;}static void ResetEvent(HANDLE e){e->set=false;}
static DWORD WaitForSingleObject(HANDLE e,DWORD ms){
    if(e->set)return WAIT_OBJECT_0;uint64_t end=tick+ms;
    if(mode==3&&tick>=100){xrb.running=0;return WAIT_TIMEOUT;}
    if(pendingStatus&&due<=end){tick=due;DWORD status=pendingStatus;pendingStatus=0;request.callback(&request,request.context,status,pendingBuffer,pendingLength);}
    else tick=end;return e->set?WAIT_OBJECT_0:WAIT_TIMEOUT;
}
static DWORD GetLastError(){return ERROR_IO_PENDING;}
/* URL parsing is an explicit OS boundary model; request scheme/flags and the
   production allowlist are executed below, not a real WinHTTP parser test. */
static BOOL WinHttpCrackUrl(const wchar_t* url,DWORD length,DWORD,URL_COMPONENTS* u){
    std::wstring value(url,length);size_t scheme=value.find(L"://");if(scheme==std::wstring::npos)return FALSE;
    std::wstring name=value.substr(0,scheme);for(size_t i=0;i<name.size();i++)name[i]=std::towlower(name[i]);
    u->nScheme=name==L"https"?INTERNET_SCHEME_HTTPS:(name==L"http"?INTERNET_SCHEME_HTTP:0);
    size_t start=scheme+3,end=value.find_first_of(L"/?#",start);if(end==std::wstring::npos)end=value.size();
    size_t at=value.find(L'@',start);u->dwUserNameLength=u->dwPasswordLength=0;
    if(at<end){u->dwUserNameLength=(DWORD)(at-start);start=at+1;}
    size_t colon=value.rfind(L':',end);size_t hostEnd=(colon>=start&&colon<end)?colon:end;
    u->lpszHostName=url+start;u->dwHostNameLength=(DWORD)(hostEnd-start);
    u->nPort=u->nScheme==INTERNET_SCHEME_HTTPS?443:80;
    if(hostEnd<end)u->nPort=std::wcstol(value.substr(hostEnd+1,end-hostEnd-1).c_str(),NULL,10);
    size_t extra=value.find_first_of(L"?#",end);u->dwExtraInfoLength=extra==std::wstring::npos?0:(DWORD)(value.size()-extra);
    size_t pathEnd=extra==std::wstring::npos?value.size():extra;
    u->lpszUrlPath=url+end;u->dwUrlPathLength=(DWORD)(pathEnd-end);return TRUE;
}
static HINTERNET WinHttpOpen(const wchar_t*,DWORD,const wchar_t*,const wchar_t*,DWORD flags){asyncMode=flags&WINHTTP_FLAG_ASYNC;return &session;}
static BOOL WinHttpSetTimeouts(HINTERNET,int,int,int,int){return TRUE;}
static BOOL WinHttpSetOption(HINTERNET h,DWORD option,void* value,DWORD){if(option==WINHTTP_OPTION_CONTEXT_VALUE)h->context=*(DWORD_PTR*)value;if(option==WINHTTP_OPTION_REDIRECT_POLICY)redirectPolicy=*(DWORD*)value;if(option==WINHTTP_OPTION_SECURE_PROTOCOLS){secureProtocolOptions++;return !failSecureProtocols;}return TRUE;}
static HINTERNET WinHttpConnect(HINTERNET,const wchar_t*,int port,DWORD){connectedPort=port;return &connection;}
static HINTERNET WinHttpOpenRequest(HINTERNET,const wchar_t*,const wchar_t* path,const wchar_t*,const wchar_t*,const wchar_t**,DWORD flags){openedPath=path;requestFlags=flags;requestOpens++;request.context=0;request.callback=NULL;return &request;}
static Callback WinHttpSetStatusCallback(HINTERNET h,Callback cb,DWORD,DWORD_PTR){h->callback=cb;return NULL;}
static BOOL WinHttpCloseHandle(HINTERNET h){if(h==&request&&h->context&&h->callback){closingCallback=h->callback;closingContext=h->context;if(!delayedClose){closingCallback(h,closingContext,WINHTTP_CALLBACK_STATUS_HANDLE_CLOSING,NULL,0);closingCallback=NULL;}}return TRUE;}
static void schedule(DWORD status,unsigned delay,void* buffer=NULL,DWORD length=0){pendingStatus=status;due=tick+delay;pendingBuffer=buffer;pendingLength=length;}
static BOOL WinHttpSendRequest(HINTERNET,const wchar_t*,DWORD,void* body,DWORD,DWORD,DWORD_PTR){sentBody=(const char*)body;if(asyncMode)schedule(WINHTTP_CALLBACK_STATUS_SENDREQUEST_COMPLETE,mode==3?20000:0);return TRUE;}
static BOOL WinHttpReceiveResponse(HINTERNET,void*){if(asyncMode)schedule(WINHTTP_CALLBACK_STATUS_HEADERS_AVAILABLE,0);return TRUE;}
static BOOL WinHttpQueryHeaders(HINTERNET,DWORD,const wchar_t*,void* value,DWORD*,DWORD*){*(DWORD*)value=200;return TRUE;}
static BOOL WinHttpReadData(HINTERNET,void* buffer,DWORD cap,DWORD* got){
    unsigned delay=mode==1?4000:(mode==2?20000:1);unsigned size=offset<reply.size()?1:0;if(size&&cap)((char*)buffer)[0]=reply[offset++];
    if(asyncMode)schedule(WINHTTP_CALLBACK_STATUS_READ_COMPLETE,delay,buffer,size);else{tick+=delay;*got=size;}return TRUE;
}
static void xrb_wipe_string(std::string& s){if(!s.empty())atcs_wipe(&s[0],s.size());s.clear();}
'''
    import re
    pre+=re.search(r'enum \{ XRB_OK=.*?\};',text,re.S).group(0)+'\n'
    diagnostics='struct XRB_AuthDiagnostic' in text
    if diagnostics:pre+=text[text.index('enum { XRB_AUTH_NONE='):text.index('struct XRB_State')]+'\nstatic XRB_AuthDiagnostic lastDiagnostic;\n'
    pre+='struct XRB_Guard {XRB_Guard(){}};\n'
    pre+=extract(text,'static bool xrb_base_valid(')+'\n'
    start=text.index('struct XRB_HTTP_CONTEXT') if 'struct XRB_HTTP_CONTEXT' in text else text.index('struct XRB_HTTP ')
    pre+=text[start:text.index('struct XRB_WorkerContext',start)]
    pre+=r'''
static unsigned checks=0,failures=0;
#define CHECK(c) do{checks++;if(!(c)){printf("FAIL HTTP line%u: %s\n",(unsigned)__LINE__,#c);failures++;}}while(0)
/* Schedule the waiting worker after callback data publication but before its
   SetEvent. Returning OK here permits the next request stage to ResetEvent
   before the old callback signals, leaving the new stage's event stuck on. */
static int http_probe_wait(){return xrb_http_wait((XRB_HTTP_CONTEXT*)probeContext,GetTickCount64()+2);}
static void finish(){
    if(closingCallback){CHECK(events==1);CHECK(!memcmp(sentBody,"secret",6));
        if(pendingStatus==WINHTTP_CALLBACK_STATUS_READ_COMPLETE){if(pendingLength)((char*)pendingBuffer)[0]='z';closingCallback(&request,closingContext,pendingStatus,pendingBuffer,pendingLength);}
        pendingStatus=0;closingCallback(&request,closingContext,WINHTTP_CALLBACK_STATUS_HANDLE_CLOSING,NULL,0);closingCallback=NULL;CHECK(events==0);}
}
static int exercise(unsigned scenario,const wchar_t* base=L"https://example.test",bool renew=false){mode=scenario;tick=0;offset=0;pendingStatus=0;requestOpens=secureProtocolOptions=0;requestFlags=connectedPort=0;xrb.running=xrb.enabled=1;std::string response;unsigned status=0;int result=xrb_http_post(base,renew?L"/racklink/v3/renew":L"/racklink/v3/authorize","secret",GetTickCount64()+8000,status,response);printf("scenario=%u elapsed=%llu result=%d status=%u bytes=%u\n",scenario,(unsigned long long)tick,result,status,(unsigned)response.size());if(result==XRB_OK){CHECK(status==200);CHECK(response==reply);}finish();return result;}
int main(){
    {XRB_HTTP_CONTEXT probe("secret");tick=0;pendingStatus=0;mode=0;xrb.running=xrb.enabled=1;xrb_http_prepare(&probe,WINHTTP_CALLBACK_STATUS_READ_COMPLETE);probeContext=&probe;probeBeforeSignal=true;
        xrb_http_callback(NULL,(DWORD_PTR)&probe,WINHTTP_CALLBACK_STATUS_READ_COMPLETE,probe.buffer,0);
        CHECK(probeResult==XRB_NETWORK);CHECK(tick==2);CHECK(xrb_http_wait(&probe,GetTickCount64()+2)==XRB_OK);}
    CHECK(exercise(1)==XRB_NETWORK);CHECK(tick<=8000);
    CHECK(exercise(2)==XRB_NETWORK);CHECK(tick<=8000);
    CHECK(exercise(3)==XRB_DISABLED);CHECK(tick<=150);
    CHECK(exercise(0)==XRB_OK);CHECK(events==0);
    delayedClose=false;CHECK(exercise(0)==XRB_OK);CHECK(events==0);
    CHECK(xrb_base_valid(L"http://example.test:1333"));CHECK(xrb_base_valid(L"HTTPS://example.test"));
    CHECK(!xrb_base_valid(L"ftp://example.test"));CHECK(!xrb_base_valid(L"http://"));
    CHECK(!xrb_base_valid(L"http://user:pass@example.test"));CHECK(!xrb_base_valid(L"http://example.test?secret"));CHECK(!xrb_base_valid(L"http://example.test#part"));
    CHECK(exercise(0,L"http://example.test:1333")==XRB_OK);CHECK(requestFlags==0);CHECK(connectedPort==1333);CHECK(secureProtocolOptions==0);CHECK(events==0);CHECK(openedPath==L"/racklink/v3/authorize");CHECK(redirectPolicy==WINHTTP_OPTION_REDIRECT_POLICY_NEVER);
    CHECK(exercise(0,L"https://example.test:1443")==XRB_OK);CHECK(requestFlags==WINHTTP_FLAG_SECURE);CHECK(connectedPort==1443);CHECK(secureProtocolOptions==1);CHECK(events==0);
    CHECK(exercise(0,L"http://example.test:1333",true)==XRB_OK);CHECK(requestFlags==0);CHECK(openedPath==L"/racklink/v3/renew");CHECK(redirectPolicy==WINHTTP_OPTION_REDIRECT_POLICY_NEVER);
    CHECK(exercise(0,L"ftp://example.test")==XRB_CONFIGURATION);CHECK(requestOpens==0);CHECK(events==0);
    CHECK(exercise(0,L"http://user@example.test")==XRB_CONFIGURATION);CHECK(requestOpens==0);
    CHECK(exercise(0,L"http://example.test?secret")==XRB_CONFIGURATION);CHECK(requestOpens==0);
    failSecureProtocols=true;CHECK(exercise(0,L"https://example.test")==XRB_NETWORK);CHECK(requestOpens==0);CHECK(exercise(0,L"http://example.test:1333")==XRB_OK);CHECK(secureProtocolOptions==0);failSecureProtocols=false;
    printf("bridge HTTP extraction checks=%u failures=%u\n",checks,failures);return failures?1:0;
}
'''
    path.write_text(pre,encoding='utf-8')
if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--source',type=Path);a=ap.parse_args();write_harness(a.out,a.source.read_text() if a.source else None)
