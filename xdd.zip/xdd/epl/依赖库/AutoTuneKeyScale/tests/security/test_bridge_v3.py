#!/usr/bin/env python3
"""End-to-end check of the bridge's protocol-v3 authorization flow.

The production functions xrb_transport_fetch, xrb_authorize_http, xrb_authorize_response
and xrb_backoff are extracted from vst3/cpp/keyscale_rack_bridge.cpp and compiled natively
against the shipped headers. Only the single network round trip (xrb_http_post) is
replaced by a pipe to this script, which plays the server with real OpenSSL crypto:
a disposable signing key publishes a disposable 2048-bit transport key; requests are
opened with RSA-OAEP + AES-256-GCM exactly as the EPL server does, and replies are
sealed under HKDF(K). Nothing here is the user's key."""
import base64, json, os, re, shutil, subprocess, sys, tempfile
from pathlib import Path
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT.parents[2] / 'tools'))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from racklink_keygen import public_header
from test_bridge_logic import extract

checks = []
def check(name, ok):
    checks.append((name, bool(ok)))
    if not ok: print('FAIL', name)

def b64u(b): return base64.urlsafe_b64encode(b).decode().rstrip('=')
def unb64u(s): return base64.urlsafe_b64decode(s + '=' * (-len(s) % 4))
OAEP = padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None)

def harness_source(text):
    pre = r'''
#include "companion_security.h"
#include "companion_envelope.h"
#include "rack_bridge_json.h"
#include <string>
#include <map>
#include <stdio.h>
#include <stdlib.h>
typedef uint64_t ULONGLONG;
#define GetTickCount64 xrb_test_tick64   /* windows.h also declares GetTickCount64 */
static ULONGLONG test_tick=0;
static ULONGLONG GetTickCount64(){return test_tick;}
struct XRB_Guard {XRB_Guard(){}};
static void xrb_wipe_string(std::string& s){if(!s.empty())atcs_wipe(&s[0],s.size());s.clear();}
'''
    pre += re.search(r'enum \{ XRB_OK=.*?\};', text, re.S).group(0) + '\n'
    pre += text[text.index('enum { XRB_AUTH_NONE='):text.index('struct XRB_State')] + '\n'
    pre += extract(text, 'static int xrb_authorize_response(') + '\n'
    pre += r'''
/* Network boundary only: one POST exchanged with the Python driver. */
static unsigned test_posts=0;
static std::string hexs(const std::string& s){static const char h[]="0123456789abcdef";std::string o;for(size_t i=0;i<s.size();i++){o+=h[(unsigned char)s[i]>>4];o+=h[(unsigned char)s[i]&15];}return o.empty()?"-":o;}
static std::string unhexs(const char* h){std::string o;if(!strcmp(h,"-"))return o;size_t n=strlen(h);for(size_t i=0;i+1<n;i+=2){int a=atcs_hex_digit(h[i]),b=atcs_hex_digit(h[i+1]);o+=(char)((a<<4)|b);}return o;}
static char test_line[1<<17];
static int xrb_http_post(const std::wstring& base,const wchar_t* suffix,const std::string& body,ULONGLONG,unsigned& status,std::string& response){
    test_posts++;std::string b(base.begin(),base.end()),s;for(const wchar_t* p=suffix;*p;p++)s+=(char)*p;
    printf("REQ %s %s %s\n",hexs(b).c_str(),hexs(s).c_str(),hexs(body).c_str());fflush(stdout);
    if(!fgets(test_line,sizeof test_line,stdin))return XRB_NETWORK;
    int code=0;unsigned st=0;static char hb[1<<17];hb[0]=0;
    if(sscanf(test_line,"RES %d %u %131071s",&code,&st,hb)!=3)return XRB_NETWORK;
    status=st;response=unhexs(hb);return code;
}
'''
    pre += text[text.index('struct XRB_Transport {'):text.index('struct XRB_WorkerContext')] + '\n'
    pre += r'''
int main(){
    static char cmd[1<<17];
    while(fgets(cmd,sizeof cmd,stdin)){
        char verb[16]={0};sscanf(cmd,"%15s",verb);
        if(!strcmp(verb,"CALL")){static char hb[4096],hbody[1<<16];int renew=0;if(sscanf(cmd,"CALL %4095s %d %65535s",hb,&renew,hbody)!=3)return 2;
            std::string base=unhexs(hb),body=unhexs(hbody);std::wstring wbase(base.begin(),base.end());std::string token;XRB_AuthDiagnostic d;
            test_posts=0;int r=xrb_authorize_http(wbase,body,renew!=0,token,d);
            printf("RESULT %d %s %u %u %s\n",r,xrb_auth_reason_name(d.reason),d.http,test_posts,hexs(token).c_str());fflush(stdout);}
        else if(!strcmp(verb,"BACKOFF")){unsigned f=0;sscanf(cmd,"BACKOFF %u",&f);ULONGLONG lo=~0ULL,hi=0;for(unsigned i=0;i<512;i++){ULONGLONG v=xrb_backoff(f);if(v<lo)lo=v;if(v>hi)hi=v;}
            printf("BACKOFF %u %llu %llu\n",f,(unsigned long long)lo,(unsigned long long)hi);fflush(stdout);}
        else if(!strcmp(verb,"QUIT"))return 0;
    }
    return 0;
}
'''
    return pre

class Server:
    def __init__(self):
        self.signing = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        self.rotate()
        self.mode = {}; self.log = []; self.replies = []
    def rotate(self):
        self.transport = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        self.der = self.transport.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
        import hashlib; self.kid = hashlib.sha256(self.der).hexdigest()
    def publication(self, signer=None, kid=None, der=None):
        kid = kid or self.kid; der = der or self.der
        message = ('XHH-RACKLINK-TRANSPORT-3\n' + kid + '\n' + der.hex() + '\n').encode()
        sig = (signer or self.signing).sign(message, padding.PKCS1v15(), hashes.SHA256())
        return {'ok': True, 'v': 3, 'kid': kid, 'spki': der.hex(), 'sig': sig.hex()}
    def open(self, path, outer):
        o = json.loads(outer)
        k = self.transport.decrypt(unb64u(o['ek']), OAEP)
        iv = bytes.fromhex(o['iv']); box = unb64u(o['box'])
        aad = ('XHH-RACKLINK-REQ-3\n' + path + '\n' + o['kid']).encode()
        return o, k, AESGCM(k).decrypt(iv, box, aad)
    def seal(self, k, path, kid, iv_req_hex, inner, aad_path=None):
        rk = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b'XHH-RACKLINK-RESP-3').derive(k)
        iv = os.urandom(12)
        aad = ('XHH-RACKLINK-RESP-3\n' + (aad_path or path) + '\n' + kid + '\n' + iv_req_hex).encode()
        return {'v': 3, 'iv': iv.hex(), 'box': b64u(AESGCM(rk).encrypt(iv, json.dumps(inner).encode(), aad))}

def main():
    import argparse
    ap = argparse.ArgumentParser(); ap.add_argument('--wine', help='run the harness built by the release i686 MinGW compiler under this wine')
    ap.add_argument('--cxx', default='i686-w64-mingw32-g++-win32'); args = ap.parse_args()
    server = Server()
    with tempfile.TemporaryDirectory(prefix='bridge-v3-', dir=os.environ.get('XHH_TEST_TMP')) as d:
        d = Path(d)
        for name in ('companion_security.h', 'companion_protocol.h', 'companion_rsa_verify.h', 'companion_envelope.h', 'rack_bridge_json.h'):
            shutil.copyfile(ROOT / 'vst3/cpp' / name, d / name)
        (d / 'companion_public_key.h').write_text(public_header(server.signing), encoding='ascii')
        text = (ROOT / 'vst3/cpp/keyscale_rack_bridge.cpp').read_text(encoding='utf-8')
        (d / 'harness.cpp').write_text(harness_source(text), encoding='utf-8')
        if args.wine:
            build = subprocess.run([args.cxx, '-std=c++11', '-O2', '-finput-charset=UTF-8', '-static', '-static-libgcc', '-static-libstdc++', '-I', str(d),
                                    str(d / 'harness.cpp'), '-o', str(d / 'harness.exe'), '-ladvapi32'], capture_output=True, text=True)
            command = [args.wine, str(d / 'harness.exe')]
        else:
            build = subprocess.run(['g++', '-std=c++11', '-O1', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-I', str(d),
                                    str(d / 'harness.cpp'), '-o', str(d / 'harness')], capture_output=True, text=True)
            command = [str(d / 'harness')]
        check('compile_extracted_production_flow', build.returncode == 0)
        if build.returncode: print(build.stderr[-4000:]); return 1
        proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1,
                                env={**os.environ, 'ASAN_OPTIONS': 'detect_leaks=0', 'UBSAN_OPTIONS': 'halt_on_error=1'})
        secret, machine = 'SECRET-CRED-' + os.urandom(6).hex(), 'MACHINE-' + os.urandom(6).hex()
        body = json.dumps({'license_id': 'acct', 'credential': secret, 'device': 'ab' * 32, 'nonce': 'cd' * 16, 'parent': 77,
                           'controller_version': 5, 'agent_build': 1166, 'soft': 3, 'client_now': 1790000000, 'legacy_machine_code': machine})

        def call(base, renew, handler, payload=body):
            proc.stdin.write(f'CALL {base.encode().hex()} {1 if renew else 0} {payload.encode().hex()}\n'); proc.stdin.flush()
            requests = []
            while True:
                line = proc.stdout.readline()
                if not line: raise AssertionError('harness exited')
                parts = line.split()
                if parts[0] == 'REQ':
                    path = bytes.fromhex(parts[2]).decode(); outer = bytes.fromhex(parts[3]).decode() if parts[3] != '-' else ''
                    requests.append((path, outer))
                    code, status, reply = handler(path, outer, len(requests))
                    data = json.dumps(reply).encode() if isinstance(reply, dict) else reply
                    proc.stdin.write(f'RES {code} {status} {data.hex() or "-"}\n'); proc.stdin.flush()
                elif parts[0] == 'RESULT':
                    token = bytes.fromhex(parts[5]).decode() if parts[5] != '-' else ''
                    return int(parts[1]), parts[2], int(parts[3]), int(parts[4]), token, requests

        def normal(token, inner_check=None, status=200):
            def h(path, outer, n):
                if path == '/racklink/v3/hello': return 0, 200, server.publication()
                o, k, inner = server.open(path, outer)
                if inner_check: inner_check(path, o, inner)
                return 0, status, server.seal(k, path, o['kid'], o['iv'], token if isinstance(token, dict) else {'ok': True, 'token': token})
            return h

        seen = {}
        def inspect(path, o, inner):
            seen.update(path=path, outer=o, inner=inner)
        base = 'http://example.test:1333'
        r = call(base, False, normal('tok-1', inspect))
        check('fresh_authorize_ok', r[0] == 0 and r[4] == 'tok-1' and r[1] == 'none' and r[2] == 200)
        check('fresh_authorize_fetches_key_then_posts_once', [p for p, _ in r[5]] == ['/racklink/v3/hello', '/racklink/v3/authorize'])
        outer_text = r[5][1][1]
        check('outer_never_contains_login_key_or_machine_code', secret not in outer_text and machine not in outer_text and 'credential' not in outer_text)
        check('inner_is_exactly_the_request_body', seen.get('inner') == body.encode())
        o = seen['outer']
        check('outer_shape', set(o) == {'v', 'kid', 'ek', 'iv', 'box'} and o['v'] == 3 and o['kid'] == server.kid and len(unb64u(o['ek'])) == 256
              and re.fullmatch(r'[0-9a-f]{24}', o['iv']) is not None and len(unb64u(o['box'])) == len(body) + 16)
        r = call(base, True, normal('tok-2', inspect))
        check('renew_reuses_cached_key', r[0] == 0 and r[4] == 'tok-2' and [p for p, _ in r[5]] == ['/racklink/v3/renew'] and seen['path'] == '/racklink/v3/renew')
        # Server restart: old kid rejected once, key refetched, request resealed to the new key.
        server.rotate()
        def rotated(path, outer, n):
            if path == '/racklink/v3/hello': return 0, 200, server.publication()
            if json.loads(outer)['kid'] != server.kid: return 0, 409, {'ok': False, 'error': 'transport_key_changed'}
            o, k, _ = server.open(path, outer); return 0, 200, server.seal(k, path, o['kid'], o['iv'], {'ok': True, 'token': 'tok-3'})
        r = call(base, False, rotated)
        check('rotation_refetches_and_retries_once', r[0] == 0 and r[4] == 'tok-3' and [p for p, _ in r[5]] == ['/racklink/v3/authorize', '/racklink/v3/hello', '/racklink/v3/authorize'])
        # invalid_envelope also triggers one refetch.
        flip = {'n': 0}
        def invalid_once(path, outer, n):
            if path == '/racklink/v3/hello': return 0, 200, server.publication()
            flip['n'] += 1
            if flip['n'] == 1: return 0, 400, {'ok': False, 'error': 'invalid_envelope'}
            o, k, _ = server.open(path, outer); return 0, 200, server.seal(k, path, o['kid'], o['iv'], {'ok': True, 'token': 'tok-4'})
        r = call(base, False, invalid_once)
        check('invalid_envelope_refetches_once', r[0] == 0 and r[4] == 'tok-4' and [p for p, _ in r[5]] == ['/racklink/v3/authorize', '/racklink/v3/hello', '/racklink/v3/authorize'])
        # Two consecutive key changes: bounded, no loop.
        def always_changed(path, outer, n):
            if path == '/racklink/v3/hello': return 0, 200, server.publication()
            return 0, 409, {'ok': False, 'error': 'transport_key_changed'}
        r = call(base, False, always_changed)
        check('double_rotation_is_bounded', r[0] == 4 and r[1] == 'transport_key_changed' and len(r[5]) == 3 and r[4] == '')
        # Tampered, replayed and path-substituted sealed replies are all refused.
        def tampered(path, outer, n):
            o, k, _ = server.open(path, outer); s = server.seal(k, path, o['kid'], o['iv'], {'ok': True, 'token': 'evil'})
            raw = bytearray(unb64u(s['box'])); raw[3] ^= 1; s['box'] = b64u(bytes(raw)); return 0, 200, s
        r = call(base, False, tampered)
        check('tampered_reply_refused', r[0] == 12 and r[1] == 'invalid_response' and r[4] == '')
        keep = {}
        def remember(path, outer, n):
            o, k, _ = server.open(path, outer); s = server.seal(k, path, o['kid'], o['iv'], {'ok': True, 'token': 'old'}); keep['reply'] = s; return 0, 200, s
        call(base, False, remember)
        r = call(base, False, lambda path, outer, n: (0, 200, keep['reply']))
        check('replayed_reply_refused', r[0] == 12 and r[1] == 'invalid_response' and r[4] == '')
        def wrong_path(path, outer, n):
            o, k, _ = server.open(path, outer); return 0, 200, server.seal(k, path, o['kid'], o['iv'], {'ok': True, 'token': 'evil'}, aad_path='/racklink/v3/authorize')
        r = call(base, True, wrong_path)
        check('reply_bound_to_request_path', r[0] == 12 and r[1] == 'invalid_response')
        def missing_v(path, outer, n):
            o, k, _ = server.open(path, outer); s = server.seal(k, path, o['kid'], o['iv'], {'ok': True, 'token': 'evil'}); del s['v']; return 0, 200, s
        r = call(base, False, missing_v)
        check('reply_shape_enforced', r[0] == 12 and r[1] == 'invalid_response')
        # Sealed server decisions map exactly like before; unsealed envelope-layer errors too.
        r = call(base, False, normal({'ok': False, 'error': 'invalid_credentials'}, status=401))
        check('sealed_denial_maps_to_denied', r[0] == 3 and r[1] == 'invalid_credentials' and r[2] == 401)
        r = call(base, False, normal({'ok': False, 'error': 'session_revoked_or_replayed'}, status=409))
        check('sealed_revocation_maps_to_revoked', r[0] == 13 and r[1] == 'session_revoked_or_replayed')
        r = call(base, False, lambda path, outer, n: (0, 429, {'ok': False, 'error': 'rate_limited'}))
        check('unsealed_rate_limit_maps_to_network', r[0] == 4 and r[1] == 'rate_limited' and r[2] == 429)
        r = call(base, False, lambda path, outer, n: (4, 0, b''))
        check('transport_failure_passes_through', r[0] == 4 and r[1] == 'transport_failed')
        # Transport-key publication must verify; otherwise the credential is never sent.
        for name, pub in [('bad_signature', None), ('wrong_signer', 'signer'), ('kid_not_spki_hash', 'kid'), ('other_key_size', 'size')]:
            fake = server.publication()
            if name == 'bad_signature': s = bytearray(bytes.fromhex(fake['sig'])); s[10] ^= 1; fake['sig'] = s.hex()
            elif pub == 'signer': fake = server.publication(signer=rsa.generate_private_key(public_exponent=65537, key_size=2048))
            elif pub == 'kid': fake = server.publication(kid='0' * 64)
            elif pub == 'size':
                k3 = rsa.generate_private_key(public_exponent=65537, key_size=3072).public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
                import hashlib; fake = server.publication(kid=hashlib.sha256(k3).hexdigest(), der=k3)
            other = f'http://other-{name}.test:1333'
            r = call(other, False, lambda path, outer, n, fake=fake: (0, 200, fake) if path == '/racklink/v3/hello' else (0, 200, {'ok': True, 'token': 'leak'}))
            check(f'publication_{name}_refused_before_any_credential', r[0] == 12 and r[1] == 'transport_key_invalid' and [p for p, _ in r[5]] == ['/racklink/v3/hello'])
        r = call('http://disabled.test:1333', False, lambda path, outer, n: (0, 403, {'ok': False, 'error': 'feature_disabled'}))
        check('hello_feature_disabled_maps_to_denied', r[0] == 3 and r[1] == 'feature_disabled' and len(r[5]) == 1)
        r = call('http://garbage.test:1333', False, lambda path, outer, n: (0, 200, b'not json'))
        check('hello_garbage_is_protocol_error', r[0] == 12 and r[1] == 'invalid_response')
        # A new base URL always refetches its own key.
        r = call('http://second.test:1333', False, normal('tok-5'))
        check('new_base_refetches_key', r[0] == 0 and r[4] == 'tok-5' and r[5][0][0] == '/racklink/v3/hello')
        # Backoff with +/-25 % jitter.
        for f in range(1, 9):
            proc.stdin.write(f'BACKOFF {f}\n'); proc.stdin.flush(); _, _, lo, hi = proc.stdout.readline().split()
            base_ms = 30000 if f > 5 else 1000 << (f - 1)
            check(f'backoff_{f}_jitter_bounds', base_ms * 3 // 4 <= int(lo) <= int(hi) < base_ms * 5 // 4 and int(hi) > int(lo))
        proc.stdin.write('QUIT\n'); proc.stdin.flush(); proc.wait(timeout=30)
        check('harness_clean_exit', proc.returncode == 0)
    failed = [n for n, ok in checks if not ok]
    print(('PASS' if not failed else 'FAIL'), len(checks) - len(failed), '/', len(checks))
    return 1 if failed else 0

if __name__ == '__main__':
    sys.exit(main())
