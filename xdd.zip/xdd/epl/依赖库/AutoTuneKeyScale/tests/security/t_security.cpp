/* Tests include production headers directly; crypto/JSON functions are not copied. */
#include "rack_bridge_json.h"
#include "companion_security.h"
#include <iostream>
#include <map>
#include <string>
#include <set>
extern "C" int __lsan_is_turned_off(){return 1;}
extern "C" const char* __asan_default_options(){return "detect_leaks=0";}
static unsigned checks=0,failures=0;
#define CHECK(expr) do{checks++;if(!(expr)){std::cerr<<"FAIL "<<__LINE__<<": " #expr "\n";failures++;}}while(0)
static std::string claims(uint64_t now=1800000000ULL){
    char time[128];snprintf(time,sizeof time,"parent=1234\niat=%llu\nexp=%llu\n",(unsigned long long)now,(unsigned long long)now+120);
    return std::string("ver=3\nsid=")+std::string(32,'a')+"\nlic=L1\ndev="+std::string(64,'b')+"\n"+time+"key="+std::string(64,'c')+"\npolicy=1\nracks=\nplugins=\n";
}
static std::string replace1(std::string value,const std::string& from,const std::string& to){size_t p=value.find(from);if(p==std::string::npos)abort();value.replace(p,from.size(),to);return value;}
static bool parse(const std::string& text){ATCS_Claims out;memset(&out,0,sizeof out);return atcs_parse_claims(text.data(),(unsigned)text.size(),&out)!=0;}
static bool json(const std::string& text,std::map<std::string,std::string>* output=NULL){std::map<std::string,std::string> fields;xrb_json::Parser parser(text);bool ok=parser.object(fields);if(output)*output=fields;return ok;}
static void test_claims(){
    std::string good=claims();CHECK(parse(good));ATCS_Claims c;CHECK(atcs_parse_claims(good.data(),(unsigned)good.size(),&c));CHECK(!strcmp(c.license,"L1"));CHECK(c.parent==1234);CHECK(c.issued==1800000000ULL);CHECK(c.expires-c.issued==120);CHECK(c.key[0]==0xcc);
    const char* badFrom[]={"ver=3","sid=aaaaaaaa","lic=L1","dev=bbbbbbbb","parent=1234","parent=1234","iat=1800000000","policy=1","key=cccccccc"};
    const char* badTo[]={"ver=1","sid=AAAAaaaa","lic=L 1","dev=BBBBbbbb","parent=01234","parent=4294967296","iat=01800000000","policy=3","key=CCCCcccc"};
    for(unsigned i=0;i<sizeof badFrom/sizeof badFrom[0];i++)CHECK(!parse(replace1(good,badFrom[i],badTo[i])));
    CHECK(!parse(good.substr(0,good.size()-1)));CHECK(!parse(good+"\n"));CHECK(!parse(good+"key=extra\n"));CHECK(!parse(replace1(good,"ver=3\n","ver=3\r\n")));CHECK(!parse(replace1(good,"lic=L1","lic=")));CHECK(!parse(replace1(good,"lic=L1","lic="+std::string(65,'a'))));CHECK(!parse(replace1(good,"lic=L1\n","lic=L1\nlic=L2\n")));CHECK(!parse(replace1(good,"ver=3\nsid=","sid=ver=3\n")));
    for(unsigned i=0;i<good.size();i++)CHECK(!parse(good.substr(0,i)));
    uint64_t value=0;CHECK(atcs_u64("18446744073709551615",20,&value)&&value==UINT64_MAX);CHECK(!atcs_u64("18446744073709551616",20,&value));CHECK(!atcs_u64("01",2,&value));CHECK(!atcs_u64("+1",2,&value));CHECK(!atcs_u64("",0,&value));
}
static std::string hex(const std::string& value){std::string encoded(value.size()*2+1,0);atcs_hex_encode((const unsigned char*)value.data(),(unsigned)value.size(),&encoded[0]);encoded.resize(value.size()*2);return encoded;}
static void test_policy(){
    std::string good=claims();ATCS_Claims c;
    std::string lists=replace1(replace1(good,"racks=\n","racks="+hex("reaper.exe")+"\n"),"plugins=\n","plugins="+hex("antares")+","+hex("电音.vst3")+"\n");
    CHECK(parse(lists));CHECK(atcs_parse_claims(lists.data(),(unsigned)lists.size(),&c));
    CHECK(atcs_policy_denied(&c,1,"REAPER.EXE"));CHECK(!atcs_policy_denied(&c,1,"cubase.exe"));CHECK(atcs_policy_denied(&c,0,"ANTARES"));CHECK(atcs_policy_denied(&c,0,"电音.vst3"));CHECK(!atcs_policy_denied(&c,0,"other.dll"));CHECK(atcs_policy_denied(&c,0,"C:\\other.dll"));
    CHECK(parse(replace1(good,"lic=L1","lic=L9223372036854775807")));CHECK(!parse(replace1(good,"lic=L1","lic=L9223372036854775808")));CHECK(!parse(replace1(good,"lic=L1","lic=L01")));CHECK(!parse(replace1(good,"lic=L1","lic=other")));CHECK(!parse(replace1(good,"ver=3","ver=2")));
    const char* bad[]={"x/one.exe","C:one.exe","one.exe.","one.exe ","a,b.exe","\x01.exe","a\x7f.exe","UPPER.exe","\xc0\xaf.exe","\xed\xa0\x80.exe","\xf4\x90\x80\x80.exe","\xe2\x82.exe","antares",".exe","name.dll"};
    for(unsigned i=0;i<sizeof bad/sizeof bad[0];i++)CHECK(!parse(replace1(good,"racks=\n","racks="+hex(bad[i])+"\n")));
    CHECK(!parse(replace1(good,"plugins=\n","plugins="+hex("thing.exe")+"\n")));CHECK(!parse(replace1(good,"racks=\n","racks="+hex("z.exe")+","+hex("a.exe")+"\n")));CHECK(!parse(replace1(good,"racks=\n","racks="+hex("a.exe")+","+hex("a.exe")+"\n")));CHECK(!parse(replace1(good,"racks=\n","racks="+hex("a.exe")+",\n")));CHECK(!parse(replace1(good,"racks=\n","racks=6A2e657865\n")));
    CHECK(parse(replace1(good,"racks=\n","racks="+hex(std::string(124,'a')+".exe")+"\n")));CHECK(!parse(replace1(good,"racks=\n","racks="+hex(std::string(125,'a')+".exe")+"\n")));
    std::string many;for(unsigned i=0;i<33;i++){char name[32];snprintf(name,sizeof name,"a%02u.exe",i);if(i)many+=',';many+=hex(name);if(i==31)CHECK(parse(replace1(good,"racks=\n","racks="+many+"\n")));}CHECK(!parse(replace1(good,"racks=\n","racks="+many+"\n")));
    std::string maximum;for(unsigned i=0;i<7;i++){if(i)maximum+=',';maximum+=hex(std::string(1,'a'+i)+std::string(123,'x')+".exe");}
    std::string maxPlugins=hex(std::string(121,'p')+".dll");CHECK(maximum.size()+maxPlugins.size()==2048);CHECK(parse(replace1(replace1(good,"racks=\n","racks="+maximum+"\n"),"plugins=\n","plugins="+maxPlugins+"\n")));CHECK(!parse(replace1(replace1(good,"racks=\n","racks="+maximum+"\n"),"plugins=\n","plugins="+hex(std::string(122,'p')+".dll")+"\n")));
    std::string large;for(unsigned i=0;i<8;i++){if(i)large+=',';large+=hex(std::string(1,'a'+i)+std::string(123,'a')+".exe");}CHECK(!parse(replace1(good,"racks=\n","racks="+large+"\n")));
}
static void test_base64(){
    unsigned char out[16];CHECK(atcs_b64_decode("Zg",2,out,sizeof out)==1&&out[0]=='f');CHECK(atcs_b64_decode("Zm8",3,out,sizeof out)==2&&out[0]=='f'&&out[1]=='o');CHECK(atcs_b64_decode("Zm9v",4,out,sizeof out)==3&&!memcmp(out,"foo",3));
    const char* bad[]={"A","Zg=","Zg==","Zh","Zm9","Zg\n","Z+","Z/","","===="};
    for(unsigned i=0;i<sizeof bad/sizeof bad[0];i++)CHECK(atcs_b64_decode(bad[i],(unsigned)strlen(bad[i]),out,sizeof out)<0);
    CHECK(atcs_b64_decode("Zm9v",4,out,2)<0);
}
static void test_envelope(){
    unsigned char key[32],other[32];for(unsigned i=0;i<32;i++){key[i]=(unsigned char)i;other[i]=(unsigned char)(i+1);}char sid[33];memset(sid,'a',32);sid[32]=0;
    const char plain[]="key=1|scale=Minor|retune=0.400|t=123\n";uint64_t expiry=atcs_now()+120;char sealed[2401],out[1025];
    CHECK(atcs_seal(key,sid,1,expiry,plain,sizeof plain-1,sealed,sizeof sealed));unsigned n=(unsigned)strlen(sealed);uint64_t seq=0;
    CHECK(atcs_open(key,sid,expiry,sealed,n,&seq,out,sizeof out));CHECK(seq==1);CHECK(!strcmp(out,plain));
    CHECK(!atcs_open(key,sid,expiry,sealed,n,&seq,out,sizeof out));CHECK(seq==1);
    seq=0;CHECK(!atcs_open(other,sid,expiry,sealed,n,&seq,out,sizeof out));CHECK(seq==0);
    seq=0;CHECK(!atcs_open(key,"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",expiry,sealed,n,&seq,out,sizeof out));CHECK(seq==0);
    CHECK(!atcs_open(key,sid,expiry+1,sealed,n,&seq,out,sizeof out));CHECK(seq==0);
    for(unsigned i=0;i<n;i++){std::string modified(sealed,n);modified[i]^=1;seq=0;CHECK(!atcs_open(key,sid,expiry,modified.data(),(unsigned)modified.size(),&seq,out,sizeof out));CHECK(seq==0);}
    for(unsigned length=0;length<n;length++){seq=0;CHECK(!atcs_open(key,sid,expiry,sealed,length,&seq,out,sizeof out));}
    seq=0;CHECK(!atcs_open(key,sid,expiry,sealed,n,&seq,out,sizeof plain-1));CHECK(seq==0);
    CHECK(!atcs_seal(key,sid,0,expiry,plain,sizeof plain-1,sealed,sizeof sealed));CHECK(!atcs_seal(key,sid,1,0,plain,sizeof plain-1,sealed,sizeof sealed));CHECK(!atcs_seal(key,sid,1,expiry,"key=1",5,sealed,sizeof sealed));CHECK(!atcs_seal(key,sid,1,expiry,"a\nb\n",4,sealed,sizeof sealed));
    for(unsigned cap=0;cap<150;cap++)CHECK(!atcs_seal(key,sid,1,expiry,plain,sizeof plain-1,sealed,cap));
    uint64_t expired=atcs_now()-1;CHECK(atcs_seal(key,sid,2,expired,plain,sizeof plain-1,sealed,sizeof sealed));seq=0;CHECK(!atcs_open(key,sid,expired,sealed,(unsigned)strlen(sealed),&seq,out,sizeof out));
    CHECK(atcs_seal(key,sid,UINT64_MAX,expiry,plain,sizeof plain-1,sealed,sizeof sealed));seq=0;CHECK(atcs_open(key,sid,expiry,sealed,(unsigned)strlen(sealed),&seq,out,sizeof out));CHECK(seq==UINT64_MAX);
    std::set<std::string> nonces;for(unsigned i=0;i<8;i++){CHECK(atcs_seal(key,sid,i+1,expiry,plain,sizeof plain-1,sealed,sizeof sealed));std::string value(sealed);size_t p=value.find("|nonce=");CHECK(p!=std::string::npos);nonces.insert(value.substr(p+7,32));}CHECK(nonces.size()==8);
    std::string longest(1023,'x');longest+='\n';CHECK(atcs_seal(key,sid,99,expiry,longest.data(),1024,sealed,sizeof sealed));seq=0;CHECK(atcs_open(key,sid,expiry,sealed,(unsigned)strlen(sealed),&seq,out,sizeof out));CHECK(std::string(out)==longest);CHECK(!atcs_seal(key,sid,100,expiry,(longest+"\n").data(),1025,sealed,sizeof sealed));
    ATCS_Claims c;std::string fake="XAT3."+std::string(400,'A');CHECK(!atcs_verify_token(fake.c_str(),(unsigned)fake.size(),1234,std::string(64,'b').c_str(),&c));
}
static void test_json(){
    std::map<std::string,std::string> f;std::string typesText="{\"ok\":true,\"token\":\"value\"}";xrb_json::Parser typed(typesText);CHECK(typed.object(f));CHECK(typed.types["ok"]=='t');CHECK(typed.types["token"]=='"');CHECK(json("{\"ok\":true,\"token\":\"valid.ascii.token\",\"number\":-1.5e+2,\"x\":[{},[],null]}",&f));CHECK(f["ok"]=="true");CHECK(f["token"]=="valid.ascii.token");
    const char* bad[]={"{\"a\":1,\"a\":2}","{\"a\":1,\"\\u0061\":2}","{\"a\":{\"b\":1,\"b\":2}}","{}garbage","{\"a\":1,}","{\"a\":[1,]}","{\"a\":01}","{\"a\":+1}","{\"a\":NaN}","{\"a\":Infinity}","{\"a\":1e}","{\"a\":1.}","{\"a\":\"\\q\"}","{\"a\":\"\\ud800\"}","{\"a\":\"\\udc00\"}","{\"a\":\"\\ud800\\u0041\"}","{\"a\":tru}","[]","","{\"a\":\"line\nbreak\"}"};
    for(unsigned i=0;i<sizeof bad/sizeof bad[0];i++)CHECK(!json(bad[i]));
    CHECK(json("{\"a\":\"\\ud83d\\ude00\"}",&f));CHECK(f["a"]=="\xf0\x9f\x98\x80");CHECK(json("{\"a\":\"中文\"}",&f));CHECK(f["a"]=="中文");
    CHECK(!json("{\"a\":\""+std::string(8192,'x')+"\"}"));std::string deep="{\"a\":"+std::string(17,'[')+"0"+std::string(17,']')+"}";CHECK(!json(deep));
    const char* invalid[]={"\xc0\xaf","\xed\xa0\x80","\xf4\x90\x80\x80","\x80","\xe2\x82"};for(unsigned i=0;i<sizeof invalid/sizeof invalid[0];i++)CHECK(!json(std::string("{\"a\":\"")+invalid[i]+"\"}"));
    CHECK(xrb_json::quote("a\"b\\c\n")=="\"a\\\"b\\\\c\\u000a\"");
}
int main(){test_claims();test_policy();test_base64();test_envelope();test_json();std::cout<<"security production-header checks="<<checks<<" failures="<<failures<<"\n";return failures?1:0;}
