"""Execute production EPL authorization/rebind statements with explicit boundaries.

RSA signing is real; SQL predicates/mutations execute in SQLite in-memory with
only declared MySQL syntax adapters. Login rows, policy and connection locks are
controlled boundaries. Interleavings test stale admission/login, not actual
MySQL lock scheduling or a Windows EPL runtime. No user key/network is used.
"""
from __future__ import annotations
import copy, hashlib, hmac, json, re, sqlite3, unittest
from pathlib import Path
from test_epl_token_renewal import AUTH, CODE, Cell, TokenRuntime, rsa

DATA = CODE / '机架联动数据.static.e.txt'
A, B, C = ('a1'*32, 'b2'*32, 'c3'*32)

class AuthorizationRuntime(TokenRuntime):
    def __init__(self, key):
        super().__init__(AUTH.read_bytes(), key)
        self.load(DATA.read_text('utf-8-sig'))
        self.db=sqlite3.connect(':memory:',isolation_level=None)
        self.db.row_factory=sqlite3.Row
        self.db.executescript('''
CREATE TABLE racklink_licenses(id INTEGER PRIMARY KEY,account TEXT UNIQUE,product TEXT,revoked INTEGER,expires INTEGER,max_devices INTEGER,generation INTEGER,auth_mode TEXT,origin TEXT);
CREATE TABLE racklink_devices(license_id INTEGER,device TEXT,first_seen INTEGER,PRIMARY KEY(license_id,device));
CREATE TABLE racklink_sessions(sid TEXT PRIMARY KEY,license_id INTEGER,device TEXT,parent INTEGER,issued INTEGER,expires INTEGER,token_hash TEXT,generation INTEGER,revoked INTEGER);
CREATE TABLE racklink_nonces(license_id INTEGER,nonce TEXT,expires INTEGER,PRIMARY KEY(license_id,nonce));
''')
        self.now=1000000;self.random_serial=0;self.records={};self.record_id=0
        self.legacy={'key':'current-key','mac':'current-machine','due':2000000,'off':'0'}
        self.policy_error='';self.fail_sql='';self.failed=False;self.fail_commit=False;self.fail_locked_query=False
        self.before_transaction=None;self.lock_reads=0;self.read_queries=[];self.executed=[]
        self.globals.update({name:Cell(value) for name,value in {
            '集_机架产品':'3','集_机架会话库':'original_session','集_机架账户库':'original_account','集_机架其它产品':[],'集_机架其它会话库':[],'集_机架其它账户库':[]}.items()})   # 其它产品：默认部署为空
        self.overrides.update({
            '数据_SQL文本':lambda text:"'"+text.replace("'","''")+"'",
            '机架授权_现在':lambda:self.now,
            '数据_开始事务':self.begin,
            '数据_执行':self.execute_sql,
            '释放记录集':lambda number:self.records.pop(number,None),
            '机架配置_自动设备数':lambda:1,
            '机架配置_取TTL':lambda:120,
            'L_随机字节':self.random_bytes,
            'L_SHA256':lambda data:bytearray(hashlib.sha256(bytes(data)).digest()),
            'L_常量时间相等':lambda a,b:hmac.compare_digest(bytes(a),bytes(b)),
            '机架授权_限流':lambda *_:True,
            # Login decoder's character-to-nibble implementation is unrelated
            # to rebind; it is already covered by existing token/key tests.
            '数据_十六进制解码':lambda text:bytearray.fromhex(text),
        })
        self.ref_overrides.update({'数据_借连接':self.borrow,'数据_归还连接':self.give_back,
            '数据_结束':self.finish,'数据_查询':self.query,'读字段值':self.read_field,
            '机架配置_读取策略':self.policy})
    def random_bytes(self,n):
        self.random_serial+=1
        return bytearray(hashlib.sha256(str(self.random_serial).encode()).digest()[:n])
    def borrow(self,vm,args,env):
        self.assign(args[0],1,env);return True
    def give_back(self,vm,args,env):
        if self.db.in_transaction:self.db.rollback()
        self.assign(args[0],0,env)
    def finish(self,vm,args,env):
        commit=self.value(args[1],env)
        if commit and (not self.fail_commit or self.fail_commit=='ack_lost'):self.db.commit()
        else:self.db.rollback()
        self.assign(args[0],0,env)
        return not(commit and self.fail_commit)
    def begin(self,unused):
        if self.before_transaction:
            callback=self.before_transaction;self.before_transaction=None;callback(self)
        self.db.execute('BEGIN');return True
    @staticmethod
    def adapted(sql):
        sql=sql.removesuffix(' FOR UPDATE')
        sql=re.sub(r'DELETE ([ns]) FROM (racklink_(?:nonces|sessions)) AS \1 FORCE INDEX \([^)]*\) WHERE \1\.',r'DELETE FROM \2 WHERE ',sql)
        sql=re.sub(r'\b[ns]\.(license_id|expires)',r'\1',sql)
        return sql.replace(' ON DUPLICATE KEY UPDATE id=id',' ON CONFLICT(account) DO NOTHING')
    def execute_sql(self,conn,sql):
        assert conn==1
        self.executed.append(sql)
        if self.fail_sql and sql.startswith(self.fail_sql):self.failed=True;return False
        try:self.db.execute(self.adapted(sql));return True
        except sqlite3.DatabaseError:return False
    def query(self,vm,args,env):
        sql=self.value(args[1],env);self.read_queries.append(sql)
        self.assign(args[2],0,env)
        if sql.startswith('SELECT HEX(CONVERT(s.'):
            if sql.endswith(' LOCK IN SHARE MODE'):
                assert self.db.in_transaction;self.lock_reads+=1
                if self.fail_locked_query:return -1
            legacy=self.legacy
            rows=[{'kh':legacy['key'].encode().hex(),'mh':legacy['mac'].encode().hex(),
                'lt':str(self.now*1000),'due':str(legacy['due']),'off':legacy['off']}]
        elif sql=='SELECT ROW_COUNT() AS v':rows=[{'v':self.db.execute('SELECT changes()').fetchone()[0]}]
        else:
            try:rows=[dict(r) for r in self.db.execute(self.adapted(sql)).fetchall()]
            except sqlite3.DatabaseError as e:raise AssertionError(('unhandled SQL boundary',sql,str(e)))
        self.record_id+=1;self.records[self.record_id]=rows
        self.assign(args[2],self.record_id,env);return len(rows)
    def read_field(self,vm,args,env):
        rec=self.records[self.value(args[0],env)];name=self.value(args[1],env)
        if not rec or name not in rec[0]:return False
        self.assign(args[2],rec[0][name],env);return True
    def policy(self,vm,args,env):
        if self.policy_error:self.assign(args[4],self.policy_error,env);return False
        self.assign(args[5],'',env);self.assign(args[6],'',env);return True
    def seed(self,cap=1,devices=(A,),active=True,generation=1,origin='auto'):
        self.db.execute('INSERT INTO racklink_licenses VALUES(1,?,?,?,?,?,?,?,?)',('account','3',0,2000000,cap,generation,'legacy_session',origin))
        for i,device in enumerate(devices):
            self.db.execute('INSERT INTO racklink_devices VALUES(1,?,?)',(device,100+i))
            if active:self.db.execute('INSERT INTO racklink_sessions VALUES(?,1,?,42,?,2000000,?,?,0)',(f'{i+1:032x}',device,self.now-10,'a'*64,generation))
    def snapshot(self):
        return {table:[tuple(r) for r in self.db.execute('SELECT * FROM '+table+' ORDER BY 1,2')]
            for table in ('racklink_licenses','racklink_devices','racklink_sessions','racklink_nonces')}
    def authorize(self,device=B,credential='current-key',machine='current-machine',nonce=None,extra=None,renew_token=None):
        fields={'license_id':('account',6),'credential':(credential,6),'device':(device,6),
            'nonce':(nonce or f'{self.random_serial+100:032x}',6),'parent':('42',2),
            'controller_version':('4',2),'agent_build':('1165',2),'soft':('3',6),'legacy_machine_code':(machine,6)}
        if renew_token is not None:fields['token']=(renew_token,6)
        fields.update(extra or {})
        error,status=Cell(''),Cell(0)
        result=self.call('机架授权_签发',renew_token is not None,list(fields),[v[0] for v in fields.values()],
            [v[1] for v in fields.values()],'127.0.0.1',error,status)
        assert not self.db.in_transaction and not self.records
        return result,error.value,status.value

class DeviceRebindTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    def runtime(self,**kw):
        r=AuthorizationRuntime(self.key);r.seed(**kw);self.addCleanup(r.db.close);return r
    def test_full_authorize_moves_cap_one_and_cryptographic_token_valid(self):
        r=self.runtime();out,error,status=r.authorize();self.assertEqual(status,200,(error,out))
        self.assertEqual([x[1] for x in r.db.execute('SELECT * FROM racklink_devices')],[B])
        self.assertEqual(r.db.execute('SELECT generation FROM racklink_licenses').fetchone()[0],2)
        self.assertEqual(r.db.execute('SELECT revoked FROM racklink_sessions WHERE device=?',(A,)).fetchone()[0],1)
        self.assertEqual(r.lock_reads,1)
        token=json.loads(out)['token'];ok,fields=r.parse(token,device=B,now=r.now)
        self.assertTrue(ok,fields)
    def test_cap_multiple_evicts_only_oldest_deterministically(self):
        r=self.runtime(cap=2,devices=(A,B));out,error,status=r.authorize(device=C)
        self.assertEqual(status,200,(out,error))
        self.assertEqual([x[0] for x in r.db.execute('SELECT device FROM racklink_devices ORDER BY device')],[B,C])
        self.assertEqual(r.db.execute('SELECT COUNT(*) FROM racklink_sessions WHERE device<>? AND revoked=0',(C,)).fetchone()[0],0)
    def test_returning_bound_computer_takes_over_without_binding_loss(self):
        r=self.runtime(cap=2,devices=(A,B));out,error,status=r.authorize(device=B)
        self.assertEqual(status,200,(out,error));self.assertEqual(r.db.execute('SELECT COUNT(*) FROM racklink_devices').fetchone()[0],2)
        self.assertEqual(r.db.execute('SELECT generation FROM racklink_licenses').fetchone()[0],2)
    def test_same_computer_restart_does_not_bump_generation(self):
        r=self.runtime();out,error,status=r.authorize(device=A)
        self.assertEqual(status,200,(out,error));self.assertEqual(r.db.execute('SELECT generation FROM racklink_licenses').fetchone()[0],1)
    def test_multiple_over_capacity_bindings_only_evict_needed(self):
        r=self.runtime(cap=1,devices=(A,B));out,error,status=r.authorize(device=C)
        self.assertEqual(status,200,(out,error));self.assertEqual([x[0] for x in r.db.execute('SELECT device FROM racklink_devices')],[C])
    def test_manual_license_moves_but_does_not_extend_expiry(self):
        r=self.runtime(origin='manual');r.db.execute('UPDATE racklink_licenses SET expires=?',(r.now+50,))
        out,error,status=r.authorize();self.assertEqual(status,200,(out,error));self.assertEqual(json.loads(out)['expires_at'],r.now+50)
    def test_invalid_input_credentials_and_policy_do_not_evict(self):
        cases=[{'device':'not-a-device'},{'credential':'bad'},{'machine':'bad'},
            {'extra':{'soft':('9',6)}},{'extra':{'parent':('0',2)}}]
        for args in cases:
            with self.subTest(args=args):
                r=self.runtime();before=r.snapshot();out,error,status=r.authorize(**args)
                self.assertFalse(out);self.assertNotEqual(status,200);self.assertEqual(r.snapshot(),before)
        for reason in ('outside_rollout','feature_disabled','version_disabled','unknown'):
            r=self.runtime();before=r.snapshot();r.policy_error=reason
            out,error,status=r.authorize();self.assertFalse(out);self.assertEqual(r.snapshot(),before)
    def test_revoked_expired_and_corrupt_capacity_do_not_evict(self):
        for mutation in ('revoked=1',"origin='manual',expires=1",'max_devices=0','max_devices=33'):
            with self.subTest(mutation=mutation):
                r=self.runtime();r.db.execute('UPDATE racklink_licenses SET '+mutation);before=r.snapshot()
                self.assertFalse(r.authorize()[0]);self.assertEqual(r.snapshot(),before)
    def test_new_login_between_admission_and_lock_rejects_old_credentials(self):
        r=self.runtime();before=r.snapshot()
        r.before_transaction=lambda env:env.legacy.update(key='new-login-key',mac='new-computer')
        out,error,status=r.authorize();self.assertEqual((out,error,status),('','invalid_credentials',401))
        self.assertEqual(r.lock_reads,1);self.assertEqual(r.snapshot(),before)
    def test_completed_takeover_generation_rejects_stale_admission(self):
        r=self.runtime()
        def newer(env):
            env.db.execute('UPDATE racklink_licenses SET generation=generation+1')
            env.db.execute('DELETE FROM racklink_devices')
            env.db.execute('INSERT INTO racklink_devices VALUES(1,?,?)',(C,env.now))
        r.before_transaction=newer
        out,error,status=r.authorize();self.assertEqual((out,error,status),('','authorization_changed',409))
        self.assertEqual([x[0] for x in r.db.execute('SELECT device FROM racklink_devices')],[C])
    def test_replayed_nonce_does_not_evict(self):
        r=self.runtime();nonce='f0'*16
        r.db.execute('INSERT INTO racklink_nonces VALUES(1,?,2000000)',(nonce,));before=r.snapshot()
        self.assertEqual(r.authorize(nonce=nonce)[1:3],('request_replay',409));self.assertEqual(r.snapshot(),before)
    def test_failures_after_generation_change_roll_back_all_mutations(self):
        for sql in ('UPDATE racklink_sessions SET revoked=1','DELETE FROM racklink_devices','INSERT INTO racklink_devices',
                    'INSERT INTO racklink_nonces','INSERT INTO racklink_sessions'):
            with self.subTest(sql=sql):
                r=self.runtime();before=r.snapshot();r.fail_sql=sql
                self.assertFalse(r.authorize()[0]);self.assertTrue(r.failed);self.assertEqual(r.snapshot(),before)
        r=self.runtime();before=r.snapshot();r.fail_commit=True
        self.assertFalse(r.authorize()[0]);self.assertEqual(r.snapshot(),before)
    def test_commit_ack_loss_exposes_no_token_and_retry_recovers(self):
        # A real network loss at COMMIT may leave either complete outcome.
        # This boundary models the committed outcome, not a fictitious rollback.
        r=self.runtime();r.fail_commit='ack_lost'
        out,error,status=r.authorize();self.assertEqual((out,error,status),('','internal_error',503))
        self.assertEqual([x[0] for x in r.db.execute('SELECT device FROM racklink_devices')],[B])
        self.assertEqual(r.db.execute('SELECT generation FROM racklink_licenses').fetchone()[0],2)
        self.assertEqual(r.db.execute('SELECT COUNT(*) FROM racklink_sessions WHERE device=? AND revoked=0',(A,)).fetchone()[0],0)
        r.fail_commit=False
        out,error,status=r.authorize();self.assertEqual(status,200,(out,error))
        self.assertEqual(r.db.execute('SELECT COUNT(*) FROM racklink_sessions WHERE revoked=0').fetchone()[0],1)
    def test_max_generation_fails_without_wrapping_or_evicting(self):
        r=self.runtime(generation=(1<<63)-1);before=r.snapshot()
        self.assertFalse(r.authorize()[0]);self.assertEqual(r.snapshot(),before)
    def test_first_automatic_license_still_binds_normally(self):
        r=AuthorizationRuntime(self.key);self.addCleanup(r.db.close)
        out,error,status=r.authorize();self.assertEqual(status,200,(out,error))
        self.assertEqual(tuple(r.db.execute('SELECT max_devices,generation,origin FROM racklink_licenses').fetchone()),(1,1,'auto'))
        self.assertEqual([x[0] for x in r.db.execute('SELECT device FROM racklink_devices')],[B])
    def test_replaced_token_cannot_renew_and_new_token_can(self):
        r=self.runtime();out,error,status=r.authorize(device=A);self.assertEqual(status,200,(out,error))
        old_token=json.loads(out)['token'];r.now+=5
        r.legacy.update(key='new-login-key',mac='new-machine')
        out,error,status=r.authorize(device=B,credential='new-login-key',machine='new-machine')
        self.assertEqual(status,200,(out,error));new_token=json.loads(out)['token'];before=r.snapshot()
        self.assertEqual(r.authorize(device=A,renew_token=old_token)[1:3],('invalid_credentials',401))
        self.assertEqual(r.snapshot(),before)
        self.assertEqual(r.authorize(device=A,credential='new-login-key',machine='new-machine',renew_token=old_token)[1:3],('session_revoked_or_replayed',409))
        self.assertEqual(r.snapshot(),before);r.now+=30
        out,error,status=r.authorize(device=B,credential='new-login-key',machine='new-machine',renew_token=new_token)
        self.assertEqual(status,200,(out,error));self.assertTrue(r.parse(json.loads(out)['token'],device=B,now=r.now)[0])
    def test_locked_legacy_read_failure_leaves_binding_unchanged(self):
        r=self.runtime();r.fail_locked_query=True;before=r.snapshot()
        self.assertEqual(r.authorize()[1:3],('legacy_verifier_unavailable',503));self.assertEqual(r.snapshot(),before)
    def test_signature_failure_does_not_change_binding(self):
        r=self.runtime();before=r.snapshot();r.overrides['L_RSA签名']=lambda *_:bytearray()
        self.assertFalse(r.authorize()[0]);self.assertEqual(r.snapshot(),before)
    def test_equal_first_seen_uses_device_as_tie_breaker(self):
        r=self.runtime(cap=2,devices=(B,A));r.db.execute('UPDATE racklink_devices SET first_seen=1')
        self.assertEqual(r.authorize(device=C)[2],200)
        self.assertEqual([x[0] for x in r.db.execute('SELECT device FROM racklink_devices ORDER BY device')],[B,C])
    def test_locked_login_parameter_and_source_order(self):
        # The SQL boundary above records the generated locking SELECT, rather
        # than manufacturing the requested suffix in the test harness.
        r=self.runtime();self.assertEqual(r.authorize()[2],200)
        locked=[q for q in r.read_queries if q.endswith(' LOCK IN SHARE MODE')]
        self.assertEqual(len(locked),1);self.assertIn(' LIMIT 2 LOCK IN SHARE MODE',locked[0])
        source=AUTH.read_text('utf-8-sig').split('.子程序 机架授权_自动换机,')[0]
        self.assertLess(source.index('赋值 (局_签名, L_RSA签名'),source.index('取反 (机架授权_自动换机'))
        self.assertLess(source.index('取反 (机架授权_自动换机'),source.index('数据_结束 (局_连接, 真)'))

if __name__=='__main__':unittest.main()
