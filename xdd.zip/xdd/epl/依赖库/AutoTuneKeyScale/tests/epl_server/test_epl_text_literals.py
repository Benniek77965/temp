"""易语言文本常量里不能直接写双引号（会提前结束常量，IDE 里无法编译），一律用 #引号 拼接。

扫描本项目自己的易语言代码（主程序、各服务端、电音助手模块；不含第三方模块）中的代码行，
包括 .如果真 (…) 这类流程行；注释与声明行（.子程序/.参数/.常量 等的说明文字）不算。
"""
from pathlib import Path
import re
import unittest

EPL = Path(__file__).resolve().parents[4]
OWN_MODULES = ('模块_电音助手.e~',)
DECLARATIONS = ('.子程序', '.参数', '.局部变量', '.程序集变量', '.全局变量', '.常量', '.程序集', '.版本', '.支持库',
                '.DLL命令', '.数据类型', '.成员', '.图片', '.声音', '.模块')


def own_sources():
    for path in sorted(EPL.rglob('*.e.txt')):
        parts = path.relative_to(EPL).parts
        if parts[0] == '模块' and (len(parts) < 2 or parts[1] not in OWN_MODULES):
            continue
        if parts[0] == '依赖库':
            continue
        yield path


class TextLiteralQuoteTests(unittest.TestCase):
    def test_no_ascii_double_quote_inside_text_constants(self):
        found = []
        sources = list(own_sources())
        self.assertGreater(len(sources), 10)
        for path in sources:
            for number, line in enumerate(path.read_text(encoding='utf-8-sig').replace('\r\n', '\n').split('\n'), 1):
                stripped = line.lstrip()
                if not stripped or stripped.startswith("'") or stripped.startswith(DECLARATIONS):
                    continue
                code = line.split("  '")[0]
                for literal in re.findall(r'“([^”]*)”', code):
                    if '"' in literal:
                        found.append('%s:%d  %s' % (path.relative_to(EPL), number, literal[:60]))
        self.assertEqual(found, [], '文本常量里有双引号，请改用 #引号 拼接')


if __name__ == '__main__':
    unittest.main(verbosity=2)
