#!/usr/bin/env python3
"""Guard owned EPL variables against pinyin-initial aliases, by visible scope.

Uses the project's existing pinyin dictionary, including alternate readings.
This models the requested naming rule; it does not execute the EPL IDE/compiler.
Third-party embedded modules are outside this check.
"""
from pathlib import Path
from itertools import combinations
import re
import unicodedata
import unittest

PROJECT = Path(__file__).resolve().parents[5]
DICTIONARY = PROJECT / 'pinyin.match.js'
DECL = re.compile(r'^\s*\.(全局变量|程序集变量|局部变量|参数|成员)\s+([^,\r\n]+)')
ASSEMBLY = re.compile(r'^\.程序集\s+([^,\r\n]+)')
ROUTINE = re.compile(r'^\.(子程序|DLL命令)\s+([^,\r\n]+)')
TYPE = re.compile(r'^\.数据类型\s+([^,\r\n]+)')


def dictionary_initials(text):
    result = {}
    for syllable, characters in re.findall(r"'([^'\r\n]+)': '([^'\r\n]*)'", text):
        initial = unicodedata.normalize('NFD', syllable)[0].lower()
        if initial not in 'abcdefghijklmnopqrstuvwxyz':
            continue
        for character in characters:
            if '\u3400' <= character <= '\u9fff':
                result.setdefault(character, set()).add(initial)
    return result


def spelling(name, initials):
    output = []
    for character in name:
        if '\u3400' <= character <= '\u9fff':
            if character not in initials:
                raise ValueError('Missing pinyin initial: ' + character)
            output.append(initials[character])
        else:
            output.append({character.lower()})
    return output


def aliases(left, right, initials):
    a, b = spelling(left, initials), spelling(right, initials)
    return len(a) == len(b) and all(x & y for x, y in zip(a, b))


def collisions(files, initials):
    global_symbols, assemblies, routines, members = [], {}, [], {}
    for filename, text in sorted(files.items()):
        assembly = None
        routine = None
        record = None
        for number, line in enumerate(text.splitlines(), 1):
            if match := ASSEMBLY.match(line):
                assembly = (filename, match[1].strip())
                assemblies.setdefault(assembly, [])
                routine = record = None
            if match := ROUTINE.match(line):
                routine = {'owner': assembly, 'name': match[2].strip(), 'symbols': []}
                routines.append(routine)
                record = None
            if match := TYPE.match(line):
                record = (filename, match[1].strip())
                members.setdefault(record, [])
                routine = None
            match = DECL.match(line)
            if not match:
                continue
            kind, name = match[1], match[2].strip()
            if not name:  # Empty exported member rows are layout separators.
                continue
            symbol = (name, filename, number)
            spelling(name, initials)  # Unknown characters must not silently pass.
            if kind == '全局变量':
                global_symbols.append(symbol)
            elif kind == '程序集变量':
                assemblies.setdefault(assembly, []).append(symbol)
            elif kind == '成员':
                if record is None:
                    raise ValueError('Member without type: ' + filename)
                members[record].append(symbol)
            else:
                if routine is None:
                    raise ValueError('Parameter/local without routine: ' + filename)
                routine['symbols'].append(symbol)

    scopes = [('project globals', global_symbols)]
    scopes += [(str(owner), global_symbols + symbols) for owner, symbols in assemblies.items()]
    scopes += [(str(routine['owner']) + '::' + routine['name'],
                global_symbols + assemblies.get(routine['owner'], []) + routine['symbols'])
               for routine in routines]
    scopes += [(str(owner), symbols) for owner, symbols in members.items()]
    found = []
    for scope, symbols in scopes:
        for left, right in combinations(symbols, 2):
            if aliases(left[0], right[0], initials):
                found.append((scope, left, right))
    return found


def owned_files(root):
    # Immediate export directories only: nested reference-module source is not
    # part of the owning EPL assembly namespace.
    paths = sorted(root.glob('*.e.txt')) + sorted((root / '代码').glob('*.e.txt'))
    return {str(path): path.read_text(encoding='utf-8-sig') for path in paths}


class IdentifierInitialsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.initials = dictionary_initials(DICTIONARY.read_text(encoding='utf-8-sig'))

    def test_initial_alias_examples_and_case(self):
        for left, right in [('局_键', '局_j'), ('参_节', '参_键'),
                            ('局_文', '局_位'), ('返回_键', '返回_阶'),
                            ('局_框', '局_宽'), ('pBuffer', 'pbuffer')]:
            with self.subTest(left=left, right=right):
                self.assertTrue(aliases(left, right, self.initials))
        self.assertFalse(aliases('局_项目名', '局_查重位置', self.initials))

    def test_alternate_readings_are_conservative(self):
        self.assertTrue(aliases('私_client', '参_client', self.initials))
        self.assertTrue(aliases('局_句柄', '局_关闭', self.initials))

    def test_same_routine_and_visible_assembly_are_checked(self):
        source = '.程序集 A\n.程序集变量 集_选择模式, 整数型\n.子程序 P\n.局部变量 局_选择模式, 整数型\n'
        self.assertEqual(len(collisions({'a': source}, self.initials)), 1)

    def test_separate_routines_and_assemblies_do_not_share_locals(self):
        source = '.程序集 A\n.子程序 P\n.局部变量 局_键, 整数型\n.子程序 Q\n.局部变量 局_j, 整数型\n'
        other = '.程序集 B\n.程序集变量 局_j, 整数型\n'
        self.assertEqual(collisions({'a': source, 'b': other}, self.initials), [])

    def test_global_and_member_scopes(self):
        files = {'g': '.全局变量 集_选择模式, 整数型\n',
                 'a': '.程序集 A\n.子程序 P\n.局部变量 局_选择模式, 整数型\n'}
        self.assertEqual(len(collisions(files, self.initials)), 1)
        source = '.数据类型 A\n    .成员 键, 整数型\n    .成员 阶, 整数型\n    .成员 , , ,\n'
        self.assertEqual(len(collisions({'t': source}, self.initials)), 1)

    def test_comments_and_unknown_characters(self):
        source = ".程序集 A\n.子程序 P\n.局部变量 局_键, 整数型\n' .局部变量 局_j, 整数型\n"
        self.assertEqual(collisions({'a': source}, self.initials), [])
        with self.assertRaises(ValueError):
            spelling('局_龘', {'局': {'j'}})

    def test_entire_owned_server_export(self):
        files = owned_files(PROJECT / 'epl/服务端/服务端_电音基调')
        self.assertTrue(files)
        self.assertEqual(collisions(files, self.initials), [])

    def test_entire_owned_assistant_export(self):
        files = owned_files(PROJECT / 'epl/模块/模块_电音助手.e~')
        self.assertTrue(files)
        self.assertEqual(collisions(files, self.initials), [])


if __name__ == '__main__':
    unittest.main()
