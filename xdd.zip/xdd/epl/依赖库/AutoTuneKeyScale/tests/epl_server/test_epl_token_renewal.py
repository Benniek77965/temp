"""Execute production EPL token issuance statements and renewal parser.

The bundled small evaluator runs real extracted EPL statements with explicit
core-library boundaries; it is not an EPL compiler/Windows runtime. Numeric
literals above 2**53 follow the documented EProjectFile/TextECode double storage
boundary, then the x87 invalid-to-INT64_MIN conversion model. Decimal TEXT passed
to 到长整数 stays exact. Regex/base64 are Python boundaries; RSA2048 signatures
are real cryptography/OpenSSL with a temporary in-memory key, never the user key.
This tests token renewal validation, not MySQL transactions or live HTTP routing.
"""
from __future__ import annotations
import copy, re, math, base64
from dataclasses import dataclass

class Returned(Exception):
    def __init__(self,value): self.value=value
class Broken(Exception): pass
class Byte(int): pass
@dataclass
class Cell:
    value: object
    typ: str = ""

def splitargs(s):
    out=[];start=0;depth=0;quoted=False
    for i,c in enumerate(s):
        if c=='“':quoted=True
        elif c=='”':quoted=False
        elif not quoted:
            if c in '([{':depth+=1
            elif c in ')]}':depth-=1
            elif c==',' and depth==0:out.append(s[start:i].strip());start=i+1
    out.append(s[start:].strip())
    return out

def expression(s):
    s=s.strip()
    if not s:return ('lit',None)
    if s.startswith('“') and s.find('”')==len(s)-1:return ('lit',s[1:-1])
    if s in ('真','假'):return ('lit',s=='真')
    if s=='#引号':return ('lit','"')
    if s=='#换行符':return ('lit','\r\n')
    if s=='#字节型':return ('lit',1)
    if s.startswith('{') and s.endswith('}'):return ('lit',bytearray(int(x) for x in splitargs(s[1:-1]) if x))
    if re.fullmatch(r'-?\d+',s):return ('lit',int(s))
    # Only source primitives use infix concatenation in the reviewed helpers.
    parts=[];start=0;depth=0;quoted=False
    for i,c in enumerate(s):
        if c=='“':quoted=True
        elif c=='”':quoted=False
        elif not quoted:
            if c in '([{':depth+=1
            elif c in ')]}':depth-=1
            elif c=='＋' and depth==0:parts.append(s[start:i]);start=i+1
    if parts:return ('call','相加',[expression(x) for x in parts+[s[start:]]])
    m=re.match(r'^([^ (\[]+)\s*\((.*)\)$',s,re.S)
    if m:return ('call',m[1],[expression(x) for x in splitargs(m[2])] if m[2].strip() else [])
    m=re.match(r'^([^\[]+)\[(.*)\]$',s,re.S)
    if m:return ('index',m[1],expression(m[2]))
    return ('var',s)

def statement_expression(line):
    return expression(line[1:] if line.startswith('.') else line)

def block(lines,pos=0,stops=()):
    nodes=[]
    while pos<len(lines):
        line=lines[pos];name=line.split(' ',1)[0]
        if name in stops:return nodes,pos
        if name in ('.如果真','.如果'):
            cond=statement_expression(line);yes,pos=block(lines,pos+1,('.否则','.如果结束','.如果真结束'))
            no=[]
            if lines[pos].startswith('.否则'):no,pos=block(lines,pos+1,('.如果结束',))
            nodes.append(('if',cond[2][0],yes,no));pos+=1
        elif name=='.判断开始':
            choices=[];cond=statement_expression(line)[2][0]
            while True:
                body,pos=block(lines,pos+1,('.判断','.默认','.判断结束'))
                choices.append((cond,body))
                if lines[pos].startswith('.判断结束'):break
                if lines[pos].startswith('.默认'):
                    body,pos=block(lines,pos+1,('.判断结束',));choices.append((None,body));break
                cond=statement_expression(lines[pos])[2][0]
            nodes.append(('judge',choices));pos+=1
        elif name in ('.判断循环首','.计次循环首'):
            call=statement_expression(line);end='.判断循环尾' if name=='.判断循环首' else '.计次循环尾'
            body,pos=block(lines,pos+1,(end,));nodes.append(('while' if name=='.判断循环首' else 'count',call[2],body));pos+=1
        else:
            if not line.startswith('.') and line.strip():nodes.append(('expr',expression(line)))
            pos+=1
    return nodes,pos

class VM:
    def __init__(self,paths):
        self.functions={};self.globals={};self.overrides={};self.ref_overrides={};self.steps=0
        for path in paths:self.load(path.read_text(encoding='utf-8-sig'))
    def load(self,text):
        for piece in re.split(r'(?m)^\.子程序 ',text)[1:]:
            rows=piece.splitlines();header=splitargs(rows[0]);name=header[0];args=[];locals_=[];code=[]
            for row in rows[1:]:
                row=row.strip()
                if row.startswith("'") or not row:continue
                if row.startswith(('.参数 ','.局部变量 ')):
                    declaration=splitargs(row.split(' ',1)[1]);declaration += ['']*(5-len(declaration))
                    variable,typ,flags,dimension,*_=declaration
                    parameter = row.startswith('.参数 ')
                    # Parameter column four is documentation, not a local array dimension.
                    dimension = '' if parameter else dimension
                    item=(variable,typ,'参考' in flags,'数组' in flags or dimension!='',dimension)
                    (args if parameter else locals_).append(item)
                elif not row.startswith('.程序集'):code.append(row)
            self.functions[name]=(args,locals_,block(code)[0],header[1] if len(header)>1 else '')
    def default(self,typ,array=False,dimension=''):
        base=bytearray() if typ=='字节集' else '' if typ=='文本型' else False if typ=='逻辑型' else 0
        if array:return [copy.deepcopy(base) for _ in range(int(dimension.strip('"') or '0'))]
        return base
    def cell(self,node,env):
        if node[0]=='var':return env[node[1]] if node[1] in env else self.globals[node[1]]
        raise AssertionError(('not reference',node))
    def value(self,node,env):
        kind=node[0]
        if kind=='lit':return copy.deepcopy(node[1])
        if kind=='var':return self.cell(node,env).value
        if kind=='index':
            v=self.cell(('var',node[1]),env).value;i=self.value(node[2],env)
            assert 1<=i<=len(v),('index bounds',node,i,len(v))
            return v[i-1]
        name,args=node[1:]
        if name in self.ref_overrides:return self.ref_overrides[name](self,args,env)
        if name=='赋值':
            result=self.value(args[1],env);self.assign(args[0],result,env);return None
        if name=='返回':raise Returned(self.value(args[0],env) if args and args[0]!=('lit',None) else None)
        if name=='跳出循环':raise Broken()
        if name=='清除数组':self.cell(args[0],env).value.clear();return None
        if name=='加入成员':self.cell(args[0],env).value.append(copy.deepcopy(self.value(args[1],env)));return None
        if name=='重定义数组':
            cell=self.cell(args[0],env);size=self.value(args[2],env);cell.value=self.default(cell.typ,True,str(size));return None
        if name=='取字节集数据':
            data=self.value(args[0],env);pos=self.value(args[2],env);assert 1<=pos<=len(data)
            if args[2][0]=='var':self.assign(args[2],pos+1 if pos<len(data) else -1,env)
            return data[pos-1]
        if name in self.functions and name not in self.overrides:return self.invoke(name,args,env)
        values=[self.value(a,env) for a in args]
        if name in self.overrides:return self.overrides[name](*values)
        return self.primitive(name,values)
    def assign(self,node,value,env):
        if node[0]=='var':self.cell(node,env).value=copy.deepcopy(value)
        elif node[0]=='index':
            container=self.cell(('var',node[1]),env).value;i=self.value(node[2],env)
            assert 1<=i<=len(container),('assignment bounds',node,i,len(container))
            container[i-1]=copy.deepcopy(value)
        else:raise AssertionError(('not lvalue',node))
    def execute(self,nodes,env):
        for node in nodes:
            self.steps+=1;assert self.steps<3000000,'step limit'
            kind=node[0]
            if kind=='expr':self.value(node[1],env)
            elif kind=='if':self.execute(node[2] if self.value(node[1],env) else node[3],env)
            elif kind=='judge':
                for cond,body in node[1]:
                    if cond is None or self.value(cond,env):self.execute(body,env);break
            elif kind=='while':
                while self.value(node[1][0],env):
                    try:self.execute(node[2],env)
                    except Broken:break
            elif kind=='count':
                count=self.value(node[1][0],env);variable=node[1][1];self.assign(variable,1,env)
                while self.value(variable,env)<=count:
                    try:self.execute(node[2],env)
                    except Broken:break
                    self.assign(variable,self.value(variable,env)+1,env)
    def invoke(self,name,nodes,outer):
        parameters,locals_,code,typ=self.functions[name];assert len(nodes)<=len(parameters),(name,len(nodes),len(parameters))
        env={}
        for i,(variable,t,reference,array,dim) in enumerate(parameters):
            node=nodes[i] if i<len(nodes) else ('lit',None)
            if reference and node[0]=='var':env[variable]=self.cell(node,outer)
            else:
                v=self.value(node,outer)
                env[variable]=Cell(copy.deepcopy(v) if v is not None else self.default(t,array,dim),t)
        for variable,t,_,array,dim in locals_:env[variable]=Cell(self.default(t,array,dim),t)
        try:self.execute(code,env)
        except Returned as result:return result.value
        return self.default(typ)
    def call(self,name,*values):
        self.steps=0;outer={f'a{i}': v if isinstance(v,Cell) else Cell(v) for i,v in enumerate(values)}
        return self.invoke(name,[('var',f'a{i}') for i in range(len(values))],outer)
    def primitive(self,name,v):
        def bytes_(x):
            if isinstance(x,Byte):return bytearray([x])
            if isinstance(x,int):return bytearray(x.to_bytes(4,'little',signed=True))
            return bytearray(x.encode('latin1') if isinstance(x,str) else x)
        def text_(x):return bytes(x).decode('latin1') if isinstance(x,(bytes,bytearray)) else str(x)
        def add(*x):
            result=x[0]
            for a in x[1:]:result=result+a
            return result
        def unb64(x):
            try:return bytearray(base64.b64decode(x,validate=True))
            except (ValueError,TypeError):return bytearray()
        p={'相加':lambda:add(*v),'相减':lambda:v[0]-v[1],'相乘':lambda:v[0]*v[1],
           '相除':lambda:v[0]/v[1],'求余数':lambda:v[0]%v[1],'整除':lambda:v[0]//v[1],'取整':lambda:math.floor(v[0]),
           '等于':lambda:v[0]==v[1],'不等于':lambda:v[0]!=v[1],'小于':lambda:v[0]<v[1],'大于':lambda:v[0]>v[1],
           '小于或等于':lambda:v[0]<=v[1],'大于或等于':lambda:v[0]>=v[1],'取反':lambda:not v[0],
           '并且':lambda:all(v),'或者':lambda:any(v),'到字节':lambda:Byte(int(v[0])%256),
           '到整数':lambda:int(v[0]),'到长整数':lambda:int(v[0]),'到字节集':lambda:bytes_(v[0]),'到文本':lambda:text_(v[0]),
           '取文本长度':lambda:len(v[0]),'取字节集长度':lambda:len(v[0]),'取数组成员数':lambda:len(v[0]),
           '取文本左边':lambda:v[0][:max(0,v[1])],'取文本右边':lambda:v[0][-v[1]:] if v[1]>0 else '',
           '取字节集左边':lambda:v[0][:max(0,v[1])],'取字节集右边':lambda:v[0][-v[1]:] if v[1]>0 else bytearray(),
           '取文本中间':lambda:v[0][max(0,v[1]-1):] if len(v)<3 or v[2] is None else v[0][max(0,v[1]-1):max(0,v[1]-1)+max(0,v[2])],
           '取字节集中间':lambda:v[0][max(0,v[1]-1):max(0,v[1]-1)+max(0,v[2])],
           '取空白字节集':lambda:bytearray(v[0]),'字符':lambda:chr(v[0]),'到小写':lambda:v[0].lower(),
           '寻找文本':lambda:(lambda n:n+1 if n>=0 else -1)(v[0].find(v[1],(v[2] or 1)-1)),
           '寻找字节集':lambda:(lambda n:n+1 if n>=0 else -1)(v[0].find(v[1],(v[2] or 1)-1)),
           '分割文本':lambda:v[0].split(v[1]),'分割字节集':lambda:v[0].split(v[1]),
           '文本比较':lambda:(v[0]>v[1])-(v[0]<v[1]),
           '取最小值':lambda:min(v),'取最大值':lambda:max(v),
           '编码_BASE64编码':lambda:base64.b64encode(bytes(v[0])).decode('ascii'),
           '编码_BASE64解码':lambda:unb64(v[0]),'编码_BASE64解码_原':lambda:unb64(v[0]),
           '子文本替换':lambda:v[0].replace(v[1],v[2]),
           '选择':lambda:v[1] if v[0] else v[2]}
        if name not in p:raise AssertionError(('unsupported primitive',name,v))
        return p[name]()


from pathlib import Path
import argparse
import hashlib
import json
import unittest
import zipfile
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

CODE = Path(__file__).resolve().parents[4] / '服务端/服务端_电音基调/代码'
AUTH = CODE / '机架联动授权.static.e.txt'
CONFIG = CODE / '机架联动配置.static.e.txt'
MAX64 = (1 << 63) - 1
BASELINE_SOURCE = None
COUNTS = {'parse_cases': 0, 'RSA_signatures': 0, 'RSA_verifications': 0}


class TokenRuntime(VM):
    def __init__(self, source, key, numeric=True, reverse=False):
        super().__init__([])
        self.load(source.decode('utf-8-sig'))
        self.load(CONFIG.read_text('utf-8-sig'))
        self.source = source.decode('utf-8-sig')
        self.key, self.public = key, key.public_key()
        self.numeric, self.reverse = numeric, reverse
        self.numeric_events = []
        self.public_pem = self.public.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
        self.overrides.update({
            '机架授权_匹配': lambda text, pattern: re.fullmatch(pattern, text) is not None,
            '机架配置_取公钥': lambda: bytearray(self.public_pem),
            '机架配置_取私钥': lambda: b'ephemeral-test-key-handle',
            'L_RSA验证签名': self.verify,
            'L_RSA签名': self.sign_bytes,
        })

    def value(self, node, env):
        if node[0] == 'lit' and isinstance(node[1], int) and abs(node[1]) > (1 << 53) and self.numeric:
            rounded = int(float(node[1]))
            # Literal storage as double is backed by EProjectFile NumberLiteral
            # and TextECode double.Parse. The out-of-range conversion below is
            # an explicit x87 boundary model, not an executed EPL runtime.
            result = rounded if -(1 << 63) <= rounded <= MAX64 else -(1 << 63)
            self.numeric_events.append((str(node[1]), str(rounded), str(result)))
            return result
        if node[0] == 'call' and node[1] == '并且' and self.reverse:
            return all([self.value(arg, env) for arg in reversed(node[2])])
        return super().value(node, env)

    def primitive(self, name, args):
        if name == '取文本中间':
            assert len(args) == 3 and all(value is not None for value in args)
            text, start, count = args
            assert start >= 1 and count >= 0
            return text[start - 1:start - 1 + count]
        return super().primitive(name, args)

    def sign_bytes(self, data, unused_key, algorithm):
        assert algorithm == 'SHA256'
        COUNTS['RSA_signatures'] += 1
        return bytearray(self.key.sign(bytes(data), padding.PKCS1v15(), hashes.SHA256()))

    def verify(self, data, signature, pem, algorithm):
        assert bytes(pem) == self.public_pem and algorithm == 'SHA256'
        COUNTS['RSA_verifications'] += 1
        try:
            self.public.verify(bytes(signature), bytes(data), padding.PKCS1v15(), hashes.SHA256())
            return True
        except (InvalidSignature, ValueError):
            return False

    def issue(self, issued=1000000, expires=None, license_id=1, parent=42, device='b2' * 32, racks='', plugins='', skew=0):
        # 局_偏移: protocol v3 aligns iat/exp to the client clock (0 for protocol v2).
        values = {'局_claims': '', '局_SID': 'a1' * 16, '局_许可': license_id, '局_偏移': skew,
                  '局_设备': device, '局_父进程': parent, '局_签发': issued,
                  '局_到期': issued + 120 if expires is None else expires,
                  '局_密钥': 'c3' * 32, '局_签名': bytearray(), '局_token': '',
                  '局_机架过滤': racks, '局_插件过滤': plugins}
        env = {name: Cell(value) for name, value in values.items()}
        # These three assignments are copied unchanged from production at run
        # time; the payload format/field order/signature input are not rewritten.
        for prefix in ('赋值 (局_claims,', '赋值 (局_签名, L_RSA签名', '赋值 (局_token, 相加 (“XAT3.'):
            line = next(row.strip() for row in self.source.splitlines() if row.strip().startswith(prefix))
            self.value(expression(line), env)
        return env['局_token'].value

    def signed_claims(self, claims):
        data = claims if isinstance(claims, bytes) else claims.encode('ascii')
        signature = bytes(self.sign_bytes(data, None, 'SHA256'))
        return 'XAT3.' + base64.urlsafe_b64encode(data).rstrip(b'=').decode() + '.' + base64.urlsafe_b64encode(signature).rstrip(b'=').decode()

    def parse(self, token, license_id=1, parent=42, device='b2' * 32, now=1000030, offset=None):
        sid, issued, expires, error = Cell('', '文本型'), Cell(0, '长整数型'), Cell(0, '长整数型'), Cell('', '文本型')
        COUNTS['parse_cases'] += 1
        extra = () if offset is None else (offset,)
        ok = self.call('机架授权_解析令牌', token, license_id, device, parent, now, sid, issued, expires, error, *extra)
        return ok, {'sid': sid.value, 'issued': issued.value, 'expires': expires.value, 'error': error.value}


class EplTokenRenewalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = AUTH.read_bytes()
        cls.key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    def runtime(self, source=None, numeric=True, reverse=False):
        return TokenRuntime(self.source if source is None else source, self.key, numeric, reverse)

    def assert_token(self, runtime, token, expected, **kwargs):
        ok, fields = runtime.parse(token, **kwargs)
        self.assertEqual(ok, expected, fields)
        return fields

    def test_actual_issue_then_thirty_second_renewals(self):
        for reverse in (False, True):
            runtime = self.runtime(reverse=reverse)
            for step in range(12):
                issued = 1000000 + step * 30
                fields = self.assert_token(runtime, runtime.issue(issued=issued), True, now=issued + 30)
                self.assertEqual((fields['sid'], fields['issued'], fields['expires']), ('a1' * 16, issued, issued + 120))
            self.assertEqual(runtime.numeric_events, [])

    def test_previous_numeric_literal_form_rejects_valid_token(self):
        prior = BASELINE_SOURCE or self.source.replace('到长整数 (“9223372036854775807”)'.encode(), b'9223372036854775807')
        safe = self.runtime(numeric=False)
        token = safe.issue()
        self.assert_token(self.runtime(prior, numeric=False), token, True)
        old_runtime = self.runtime(prior, numeric=True)
        fields = self.assert_token(old_runtime, token, False)
        self.assertEqual(fields['error'], 'invalid_token')
        self.assertTrue(old_runtime.numeric_events)
        self.assertTrue(all(event[1] == str(1 << 63) for event in old_runtime.numeric_events))
        self.assert_token(self.runtime(numeric=True), token, True)

    def test_positive_integer_boundaries_remain_exact(self):
        runtime = self.runtime()
        for license_id in (1, 9, 10, 2147483647, 4294967295, (1 << 53) + 1, MAX64):
            self.assert_token(runtime, runtime.issue(license_id=license_id), True, license_id=license_id)
        self.assert_token(runtime, runtime.issue(parent=4294967295), True, parent=4294967295)
        for license_id in (0, -1, 1 << 63):
            self.assert_token(runtime, runtime.issue(license_id=license_id), False, license_id=license_id)
        for parent in (0, -1, 4294967296):
            self.assert_token(runtime, runtime.issue(parent=parent), False, parent=parent)

    def test_identity_bindings_are_not_relaxed(self):
        runtime = self.runtime(); token = runtime.issue()
        self.assert_token(runtime, token, False, license_id=2)
        self.assert_token(runtime, token, False, parent=43)
        self.assert_token(runtime, token, False, device='d4' * 32)
        self.assert_token(runtime, token, True)

    def test_v3_client_clock_offset_is_removed_before_expiry_checks(self):
        # Protocol v3 tokens carry times shifted to the client clock; renewal parsing
        # subtracts the request offset before the server-time expiry checks.
        runtime = self.runtime()
        for skew in (-86400, -31, 0, 31, 3600, 315360000):
            token = runtime.issue(skew=skew)
            fields = self.assert_token(runtime, token, True, now=1000030, offset=skew)
            self.assertEqual((fields['issued'], fields['expires']), (1000000 + skew, 1000120 + skew))
            self.assert_token(runtime, token, True, now=1000119, offset=skew)
            self.assertEqual(self.assert_token(runtime, token, False, now=1000120, offset=skew)['error'], 'token_expired')
            now, issued, expires = 1000030, 1000000 + skew, 1000120 + skew
            if issued > now + 30 or expires <= now:
                # Without the offset (protocol v2 semantics) the shifted token is outside the
                # parser's own window: issued more than 30 s ahead, or already expired.
                self.assertEqual(self.assert_token(runtime, token, False, now=1000030)['error'], 'token_expired')
        # A client clock that jumped after issuance makes the old token look stale: renewal is
        # refused (the client then re-authorizes with a fresh offset) rather than mis-dated.
        token = runtime.issue(skew=600)
        self.assertEqual(self.assert_token(runtime, token, False, now=1000030, offset=600 + 500)['error'], 'token_expired')
        self.assertEqual(self.assert_token(runtime, token, False, now=1000030, offset=600 - 500)['error'], 'token_expired')

    def test_expiry_and_clock_boundaries(self):
        runtime = self.runtime(); token = runtime.issue()
        self.assert_token(runtime, token, True, now=1000119)
        self.assertEqual(self.assert_token(runtime, token, False, now=1000120)['error'], 'token_expired')
        self.assert_token(runtime, token, True, now=999970)
        self.assertEqual(self.assert_token(runtime, token, False, now=999969)['error'], 'token_expired')
        self.assert_token(runtime, runtime.issue(expires=1000121), False)
        self.assert_token(runtime, runtime.issue(expires=1000000), False)
        self.assert_token(runtime, runtime.issue(issued=(1 << 63), expires=(1 << 63) + 120), False, now=(1 << 63) + 30)

    def test_real_signature_and_wire_corruption_are_rejected(self):
        runtime = self.runtime(); token = runtime.issue(); parts = token.split('.')
        signature = bytearray(base64.urlsafe_b64decode(parts[2] + '==')); signature[0] ^= 1
        wrong_signature = '.'.join(parts[:2] + [base64.urlsafe_b64encode(signature).rstrip(b'=').decode()])
        for changed in (wrong_signature, token + '.', 'BAD.' + '.'.join(parts[1:]),
                        'XAT3..' + parts[2], 'XAT3.' + parts[1] + '.AA',
                        'XAT3.' + parts[1] + '=.' + parts[2], 'x' * 4097):
            with self.subTest(kind=changed[:12]):
                self.assert_token(runtime, changed, False)

    def test_signed_malformed_claims_are_rejected(self):
        runtime = self.runtime(); token = runtime.issue()
        claims = base64.urlsafe_b64decode(token.split('.')[1] + '==').decode('ascii')
        changed = [claims[:-1], claims + '\n', claims.replace('\n', '\r\n'),
                   claims.replace('ver=3', 'ver=2'), claims.replace('policy=1', 'policy=2'),
                   claims.replace('lic=L1', 'lic=L01'), claims.replace('parent=42', 'parent=042'),
                   claims.replace('iat=1000000', 'iat=0'), claims.replace('iat=1000000', 'iat=1000000.0'),
                   claims.replace('exp=1000120', 'exp=9223372036854775808'),
                   claims.replace('sid=' + 'a1' * 16, 'sid=not-a-session'),
                   claims.replace('dev=' + 'b2' * 32, 'dev=' + 'B2' * 32),
                   claims.replace('key=' + 'c3' * 32, 'key=00'),
                   claims.replace('racks=\n', 'racks=f\n'),
                   claims.replace('plugins=\n', 'plugins=' + '00' * 1025 + '\n'),
                   claims + 'x' * 2600, claims.replace('ver=3', 'ver=3\x00')]
        for index, value in enumerate(changed):
            with self.subTest(index=index):
                self.assert_token(runtime, runtime.signed_claims(value), False)
        self.assert_token(runtime, runtime.signed_claims(claims.encode() + b'\x80'), False)

    def test_nonempty_filter_roundtrip(self):
        runtime = self.runtime()
        racks = 'rack.exe'.encode().hex()
        plugins = 'antares'.encode().hex()
        self.assert_token(runtime, runtime.issue(racks=racks, plugins=plugins), True)
        self.assert_token(runtime, runtime.issue(racks='RACK.EXE'.encode().hex(), plugins=plugins), False)
        self.assert_token(runtime, runtime.issue(racks=racks + ',' + racks, plugins=plugins), False)

    def test_literal_and_encoding_contract(self):
        self.assertTrue(self.source.startswith(b'\xef\xbb\xbf'))
        self.assertNotIn(b'\n', self.source.replace(b'\r\n', b''))
        parser = self.source.split('.子程序 机架授权_解析令牌,'.encode(), 1)[1].split('.子程序 '.encode(), 1)[0]
        self.assertEqual(parser.count('到长整数 (“9223372036854775807”)'.encode()), 3)
        # The source evaluator must not mask the historical precision defect.
        self.assertEqual(int(float(MAX64)), 1 << 63)
        self.assertNotEqual(int(float(MAX64)), MAX64)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if args.baseline:
        with zipfile.ZipFile(args.baseline, metadata_encoding='gbk') as archive:
            BASELINE_SOURCE = archive.read('xhh/epl/服务端/服务端_电音基调/代码/机架联动授权.static.e.txt')
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(EplTokenRenewalTests))
    report = {'status': 'passed' if result.wasSuccessful() else 'failed', 'tests': result.testsRun,
              'failures': len(result.failures), 'errors': len(result.errors), 'checks': COUNTS,
              'source_sha256': hashlib.sha256(AUTH.read_bytes()).hexdigest(),
              'test_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'baseline': 'exact supplied ZIP bytes' if args.baseline else 'original bare-limit form only',
              'actual_EPL_runtime': False, 'private_key_written': False, 'scope': __doc__}
    if args.report:
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items() if key != 'scope'}, ensure_ascii=False))
    raise SystemExit(0 if result.wasSuccessful() else 1)

