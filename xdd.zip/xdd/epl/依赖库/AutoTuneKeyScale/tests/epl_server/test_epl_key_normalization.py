"""Execute the actual EPL normalization body with a small expression/branch interpreter.
No independently rewritten production normalization function is used by these tests.
The limited interpreter is a verification aid; an EPL compiler remains a release check.
"""
import re
import unittest
from pathlib import Path

SOURCE = Path(__file__).resolve().parents[4] / "服务端/服务端_电音基调/代码/Web服务.static.e.txt"

def fields(value):
    result=[];start=0;depth=0;quoted=False
    for index,char in enumerate(value):
        if char=='“':quoted=True
        elif char=='”':quoted=False
        elif not quoted:
            if char in '([':depth+=1
            elif char in ')]':depth-=1
            elif char==',' and depth==0:result.append(value[start:index].strip());start=index+1
    result.append(value[start:].strip())
    return result

class EplFunction:
    def __init__(self):
        raw=SOURCE.read_bytes()
        assert raw.startswith(b'\xef\xbb\xbf') and b'\n' not in raw.replace(b'\r\n',b'')
        text=raw.decode('utf-8-sig').split('.子程序 基调_标准化,',1)[1].split('.子程序 ',1)[0]
        self.lines=text.splitlines()[1:]
    def __call__(self,value):
        env={'参_原调':value};stack=[]
        def active():return all(item['active'] for item in stack)
        def expression(text):
            text=text.strip()
            if not text:return None
            if text.startswith("(") and text.endswith(")"):return expression(text[1:-1])
            if text.startswith('“') and text.endswith('”'):return text[1:-1]
            if text=='真':return True
            if text=='假':return False
            if re.fullmatch(r'-?[0-9]+',text):return int(text)
            match=re.fullmatch(r'([^ ()\[\]]+)\[(.+)\]',text)
            if match:return env[match[1]][expression(match[2])-1]
            match=re.fullmatch(r'([^ ()]+)\s*\((.*)\)',text)
            if not match:return env[text]
            name,args=match[1],[expression(x) for x in fields(match[2])]
            def left(s,n):return s.encode('gbk',errors='surrogateescape')[:n].decode('gbk',errors='surrogateescape') if n>0 else ''
            def right(s,n):return s.encode('gbk',errors='surrogateescape')[-n:].decode('gbk',errors='surrogateescape') if n>0 else ''
            native={'删首尾空':lambda s:s.strip(),'或者':lambda *a:any(a),'等于':lambda a,b:a==b,'大于':lambda a,b:a>b,'小于':lambda a,b:a<b,'取文本长度':lambda s:len(s.encode('gbk',errors='surrogateescape')),'取文本右边':right,'取文本左边':left,'相减':lambda a,b:a-b,'相加':lambda *a:sum(a) if isinstance(a[0],int) else ''.join(a),'到大写':lambda s:s.upper(),'寻找文本':lambda s,needle,start,case:s.find(needle)+1 if needle in s else -1,'多项选择':lambda index,*choices:choices[index-1],'分割文本':lambda s,sep,unused:s.split(sep),'求余数':lambda a,b:a%b}
            return native[name](*args)
        def strip_comment(text):          # 先去掉行尾注释（同 epl_engine/check.py 的 active_line）：注释里的括号会让条件取错
            quoted=False
            for i,c in enumerate(text):
                if c=='“':quoted=True
                elif c=='”':quoted=False
                elif c=="'" and not quoted:return text[:i].strip()
            return text.strip()
        for raw in self.lines:
            line=strip_comment(raw)
            if not line:continue
            if line.startswith('.参数 '):continue
            if line.startswith('.局部变量 '):
                name=line.split()[1].rstrip(',');env[name]='';continue
            if line.startswith('.如果真 ('):
                parent=active();condition=bool(expression(line[len('.如果真 '):])) if parent else False
                stack.append({'active':parent and condition,'parent':parent,'taken':condition,'kind':'if'});continue
            if line=='.如果真结束':
                assert stack.pop()['kind']=='if';continue
            if line.startswith('.判断开始 ('):
                parent=active();condition=bool(expression(line[len('.判断开始 '):])) if parent else False
                stack.append({'active':parent and condition,'parent':parent,'taken':condition,'kind':'choose'});continue
            if line.startswith('.判断 ('):
                frame=stack[-1];condition=bool(expression(line[len('.判断 '):])) if frame['parent'] and not frame['taken'] else False
                frame['active']=frame['parent'] and not frame['taken'] and condition;frame['taken']|=condition;continue
            if line=='.默认':
                frame=stack[-1];frame['active']=frame['parent'] and not frame['taken'];frame['taken']=True;continue
            if line=='.判断结束':assert stack.pop()['kind']=='choose';continue
            if not active():continue
            if line.startswith('赋值 ('):
                args=fields(line[len('赋值 ('):-1]);env[args[0]]=expression(args[1]);continue
            if line.startswith('返回 ('):return expression(line[len('返回 '):])
            raise AssertionError('Unsupported EPL statement: '+line)
        raise AssertionError('EPL normalization did not return')

class ActualEplKeyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.normalize=staticmethod(EplFunction())
    def test_natural_and_both_scales(self):
        for note in ('C','D','E','F','G','A','B'):
            self.assertEqual(self.normalize(note),note+' 大调')
            self.assertEqual(self.normalize(note+'m'),note+' 小调')
    def test_all_accidentals_and_edge_enharmonics(self):
        pairs={'C#':'D-平行','Db':'D-平行','D#':'E-平行','Eb':'E-平行','F#':'F-锋利','Gb':'F-锋利','G#':'A-平行','Ab':'A-平行','A#':'B-平行','Bb':'B-平行','Cb':'B','Fb':'E','E#':'F','B#':'C','C-平行':'B','F-平行':'E','E-锋利':'F','B-锋利':'C'}
        for source,expected in pairs.items():
            self.assertEqual(self.normalize(source),expected+' 大调',source)
            self.assertEqual(self.normalize(source+'m'),expected+' 小调',source+'m')
    def test_original_sharp_bug(self):self.assertEqual(self.normalize('F#m'),'F-锋利 小调')
    def test_invalid_is_never_guessed(self):
        for source in ('','H','Hm','F##','Cbb','F# minor','Dm7','null','m','C#M','CM','C#;key=5'):
            self.assertEqual(self.normalize(source),'',source)
    def test_case_and_outer_space(self):self.assertEqual(self.normalize('  f#m  '),'F-锋利 小调')

if __name__=='__main__':unittest.main(verbosity=2)
