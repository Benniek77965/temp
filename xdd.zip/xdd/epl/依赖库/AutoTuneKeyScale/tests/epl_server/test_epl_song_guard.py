"""Execute the production song-endpoint guard and the management audit in the bundled
EPL evaluator: Web服务_限流 / Web服务_歌曲准入 / Web服务_歌曲结束 / Web服务_歌曲来源, the
real Web接口_查询基调 and Web接口_用户添加基调 handlers, and 机架界面_审计. Boundaries:
the 闪电Web context, atomics, the critical section, the boot clock and the song business
functions are recorded stand-ins; IP parsing uses Python's ipaddress in place of InetPton.
Not an EPL compiler, Windows runtime or live HTTP."""
from __future__ import annotations
import ipaddress, json, re, sys, unittest
from pathlib import Path
from test_epl_token_renewal import VM, Cell, CODE

WEB = CODE / 'Web服务.static.e.txt'
AUTH = CODE / '机架联动授权.static.e.txt'
UI = CODE / '机架联动管理界面.static.e.txt'
CONST = CODE.parent / '常量.e.txt'

def constant(name):
    m = re.search(r'^\.常量 ' + re.escape(name) + r', "([^"]*)"', CONST.read_text(encoding='utf-8-sig'), re.M)
    value = m.group(1)
    return {'真': True, '假': False}[value] if value in ('真', '假') else int(value)

def strip_trailing_comment(line):
    """EPL line comments start with ' outside “…” text; the shared evaluator only skips whole-line ones."""
    quoted = False
    for i, ch in enumerate(line):
        if ch == '“': quoted = True
        elif ch == '”': quoted = False
        elif ch == "'" and not quoted and i > 0 and line[:i].strip(): return line[:i].rstrip()
    return line

class GuardRuntime(VM):
    def load(self, text):
        super().load('\n'.join(strip_trailing_comment(l) for l in text.splitlines()))
    def __init__(self):
        super().__init__([WEB, AUTH, UI])
        self.now_ms = 3_600_000; self.lock_depth = 0; self.lock_max = 0
        self.replies = []; self.business = []; self.logs = []
        self.peer = '203.0.113.7'; self.headers = {}
        g = {'m_歌曲并发': 0, 'm_限流锁': 4096, 'm_限流键': [''] * 1024, 'm_限流分钟': [0] * 1024, 'm_限流次数': [0] * 1024,
             '局_请求.soft': 3, '局_请求.userName': 'alice'}
        for name in ('Web服务_歌曲并发上限', 'Web服务_查询每分钟上限', 'Web服务_写入每分钟上限', '歌曲写入要求登录验证'):
            g['#' + name] = constant(name)
        self.globals.update({k: Cell(v) for k, v in g.items()})
        self.overrides.update({
            'EnterCriticalSectionP': self.enter, 'LeaveCriticalSectionP': self.leave,
            '系统_取启动时间': lambda: self.now_ms,
            '局_上下文.回复字节集': lambda data, kind, status: self.replies.append(('bytes', bytes(data), status)),
            '局_上下文.连接IP': lambda: self.peer,
            '局_上下文.请求头计数': lambda name: len(self.headers.get(name, [])),
            '局_上下文.请求头': lambda name: self.headers.get(name, [''])[0],
            'MySql_基调库可用': lambda: True,
            '基调_查询': lambda req: self.business.append('query') or 'C 大调',
            '基调_用户添加': lambda req: self.business.append('add') or 'ok',
            'Web服务_回复': lambda req, text: self.replies.append(('reply', text, 200)),
            '闪电_日志': lambda text, level=1: self.logs.append((text, level)),
        })
        self.ref_overrides.update({'原子_运算': self.atomic_add, 'Web服务_机架IP标识': self.ip_identity,
                                   'Web服务_解包': lambda vm, args, env: True})
    def enter(self, lock):
        assert lock == 4096; self.lock_depth += 1; self.lock_max = max(self.lock_max, self.lock_depth)
    def leave(self, lock):
        assert lock == 4096 and self.lock_depth == 1; self.lock_depth -= 1
    def atomic_add(self, vm, args, env):
        cell = self.cell(args[0], env); old = cell.value; cell.value = old + self.value(args[1], env); return old
    def ip_identity(self, vm, args, env):
        try: ip = ipaddress.ip_address(self.value(args[0], env))
        except ValueError: self.assign(args[1], '', env); return False
        if ip.version == 6 and ip.ipv4_mapped: ip = ip.ipv4_mapped
        if int(ip) == 0: self.assign(args[1], '', env); return False
        self.assign(args[1], ('v4:%08x' % int(ip)) if ip.version == 4 else ('v6:%032x' % int(ip)), env); return True
    def concurrency(self): return self.globals['m_歌曲并发'].value

class SongGuardTests(unittest.TestCase):
    def test_limiter_counts_per_key_and_minute_with_balanced_lock(self):
        r = GuardRuntime()
        results = [r.call('Web服务_限流', 'q|v4:01020304', 3) for _ in range(5)]
        self.assertEqual(results, [True, True, True, False, False])
        self.assertTrue(r.call('Web服务_限流', 'q|v4:05060708', 3))          # another source is separate
        r.now_ms += 60_000
        self.assertTrue(r.call('Web服务_限流', 'q|v4:01020304', 3))          # next minute starts again
        self.assertEqual((r.lock_depth, r.lock_max), (0, 1))
        r.globals['m_限流锁'].value = 0                                         # not initialised: never blocks
        self.assertTrue(all(r.call('Web服务_限流', 'k', 1) for _ in range(5)))

    def test_admission_rate_limits_and_reserves_workers_for_authorization(self):
        r = GuardRuntime(); q, w, cap = constant('Web服务_查询每分钟上限'), constant('Web服务_写入每分钟上限'), constant('Web服务_歌曲并发上限')
        self.assertEqual((q, w, cap), (120, 30, 40))
        self.assertIs(constant('歌曲写入要求登录验证'), False)   # shipped default keeps old clients working
        for _ in range(q):
            self.assertTrue(r.call('Web服务_歌曲准入', False)); r.call('Web服务_歌曲结束')
        self.assertFalse(r.call('Web服务_歌曲准入', False)); self.assertEqual(r.replies[-1], ('bytes', b'', 429))
        for _ in range(w):
            self.assertTrue(r.call('Web服务_歌曲准入', True)); r.call('Web服务_歌曲结束')
        self.assertFalse(r.call('Web服务_歌曲准入', True)); self.assertEqual(r.replies[-1][2], 429)
        self.assertEqual(r.concurrency(), 0)
        r2 = GuardRuntime(); r2.globals['m_歌曲并发'].value = cap - 1
        self.assertTrue(r2.call('Web服务_歌曲准入', False)); self.assertEqual(r2.concurrency(), cap)
        self.assertFalse(r2.call('Web服务_歌曲准入', False)); self.assertEqual((r2.replies[-1], r2.concurrency()), (('bytes', b'', 503), cap))
        r2.call('Web服务_歌曲结束'); self.assertEqual(r2.concurrency(), cap - 1)

    def test_source_trusts_forwarded_header_only_from_local_proxy(self):
        r = GuardRuntime()
        r.peer, r.headers = '203.0.113.7', {}; self.assertEqual(r.call('Web服务_歌曲来源'), 'v4:cb007107')
        r.headers = {'X-Forwarded-For': ['198.51.100.9']}; self.assertEqual(r.call('Web服务_歌曲来源'), 'v4:cb007107')
        r.peer = '127.0.0.1'; self.assertEqual(r.call('Web服务_歌曲来源'), 'v4:c6336409')
        r.headers = {'X-Forwarded-For': ['198.51.100.9', '198.51.100.10']}; self.assertEqual(r.call('Web服务_歌曲来源'), 'v4:7f000001')
        r.headers = {'X-Forwarded-For': ['not-an-ip']}; self.assertEqual(r.call('Web服务_歌曲来源'), 'v4:7f000001')
        r.peer, r.headers = '::ffff:10.0.0.1', {}; self.assertEqual(r.call('Web服务_歌曲来源'), 'v4:0a000001')

    def test_real_query_handler_holds_one_slot_and_releases_it(self):
        r = GuardRuntime()
        r.call('Web接口_查询基调')
        self.assertEqual((r.business, r.replies, r.concurrency()), (['query'], [('reply', 'C 大调', 200)], 0))
        r.globals['m_歌曲并发'].value = constant('Web服务_歌曲并发上限')
        r.call('Web接口_查询基调')
        self.assertEqual((r.business, r.replies[-1]), (['query'], ('bytes', b'', 503)))
        self.assertEqual(r.concurrency(), constant('Web服务_歌曲并发上限'))

    def test_real_add_handler_limits_each_account_and_stays_balanced(self):
        r = GuardRuntime(); w = constant('Web服务_写入每分钟上限')
        for i in range(w):
            r.peer = f'198.51.100.{i + 1}'          # spread sources: only the account bucket applies
            r.call('Web接口_用户添加基调')
        self.assertEqual(r.business, ['add'] * w); self.assertEqual(r.concurrency(), 0)
        r.peer = '198.51.100.200'; r.call('Web接口_用户添加基调')
        self.assertEqual((r.business.count('add'), r.replies[-1], r.concurrency()), (w, ('bytes', b'', 429), 0))
        r.globals['局_请求.userName'].value = 'bob'; r.call('Web接口_用户添加基调')
        self.assertEqual((r.business.count('add'), r.replies[-1], r.concurrency()), (w + 1, ('reply', 'ok', 200), 0))

    def test_audit_lines_name_the_operation_target_and_result(self):
        r = GuardRuntime()
        g = {'集_界面_请求启用': True, '集_界面_请求灰度': 50, '集_界面_请求设备': 'ab' * 32, '集_界面_请求上限': 3, '集_界面_请求账号': 'carol'}
        r.globals.update({k: Cell(v) for k, v in g.items()})
        expected = {2: '保存基础配置', 4: '保存策略（允许联动=是；开放比例=50）', 6: '停用账号', 7: '恢复账号', 8: '解绑设备 ' + 'ab' * 6,
                    9: '解绑全部设备', 10: '改为跟随原账号有效期', 13: '设置设备上限为 3'}
        for task, op in expected.items():
            r.logs.clear(); r.call('机架界面_审计', task, True, '')
            account = '；账号=carol' if task >= 6 else ''
            self.assertEqual(r.logs, [(f'机架联动审计：{op}{account}；结果=成功', 1)])
            r.logs.clear(); r.call('机架界面_审计', task, False, '无法开始解绑事务。')
            self.assertEqual(r.logs, [(f'机架联动审计：{op}{account}；结果=失败：无法开始解绑事务。', 2)])
        for task in (1, 3, 5):
            r.logs.clear(); r.call('机架界面_审计', task, True, ''); self.assertEqual(r.logs, [])

    def test_background_task_audits_exactly_the_mutating_tasks(self):
        ui = UI.read_text(encoding='utf-8-sig')
        body = ui[ui.index('.子程序 机架界面_后台任务'):]; body = body[:body.index('\n.子程序 ', 5)]
        gate = re.search(r'\.如果真 \((.*)\)\n\s+机架界面_审计 \(集_界面_任务, 集_界面_结果成功, 局_错误\)', body.replace('\r', ''))
        self.assertIsNotNone(gate)
        cond = gate.group(1)
        # Evaluate the production gate with the evaluator itself rather than re-implementing it.
        r = GuardRuntime(); seen = set()
        for t in range(1, 15):
            r.globals['集_界面_任务'] = Cell(t)
            from test_epl_token_renewal import expression
            if r.value(expression(cond), {}): seen.add(t)
        self.assertEqual(seen, {2, 4, 6, 7, 8, 9, 10, 13})
        self.assertLess(body.index('.判断结束\n'.replace('\n', '\r\n') if '\r\n' in body else '.判断结束\n'), body.index('机架界面_审计 ('))

    def test_song_insert_no_longer_escapes_like_wildcards_in_values(self):
        sql = (CODE / 'MYSQL.static.e.txt').read_text(encoding='utf-8-sig')
        line = next(l for l in sql.splitlines() if 'INSERT INTO `”, 表名, “` (`songName`' in l)
        self.assertEqual((line.count('MySql_转义值 ('), line.count('MySql_转义字符处理 (')), (6, 0))

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(); ap.add_argument('--out', type=Path); args, _ = ap.parse_known_args()
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SongGuardTests))
    report = {'status': 'passed' if result.wasSuccessful() else 'failed', 'tests': result.testsRun,
              'failures': len(result.failures), 'errors': len(result.errors), 'actual_EPL_runtime': False}
    if args.out: args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False)); sys.exit(0 if result.wasSuccessful() else 1)
