"""Authenticated tone writes: the production module client (类_基调查询 私_写入v3*) talks to
the production server handlers (Web接口_歌曲写入v3 / 歌曲_处理写入信封 and the legacy
/addTone switch), both executed in the bundled EPL evaluator. Every HTTP request the
module makes is handed to the real server subroutines; crypto is real OpenSSL; the legacy
login check is the real 数据_验证登录 against the SQLite stand-in. Recorded boundaries: the
zyJson builder, 存取键值表 JSON reads, request parsing (Web服务_填请求, unchanged lines moved
out of Web服务_解包) and the song business calls. Not an EPL compiler or Windows runtime."""
from __future__ import annotations
import sys
import re
import base64, hashlib, ipaddress, json, os, sys, unittest
from pathlib import Path
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.exceptions import InvalidSignature, InvalidTag
from test_epl_transport_v3 import V3Runtime, OAEP
from test_epl_token_renewal import VM, Cell, CODE
from test_epl_song_guard import strip_trailing_comment, constant

WEB = CODE / 'Web服务.static.e.txt'
CLIENT = CODE.parents[2] / '模块/模块_电音助手.e~/代码/类_基调查询.class.e.txt'
BASE = 'http://srv.test:1333'

# ---- stand-ins written from the real sources (zyJson4.1.10, 精易 Ucs2) ----
def zy_dump(obj):
    r"""zyJson 到文本 (默认转义): strings through JsonValue_TranslationOutPtr — escapes \ " / and the
    control characters b t n r f; never writes non-ASCII as \uXXXX."""
    esc = {'\\': '\\\\', '"': '\\"', '/': '\\/', '\b': '\\b', '\t': '\\t', '\n': '\\n', '\r': '\\r', '\f': '\\f'}
    parts = []
    for k, v in obj.items():
        val = ('"' + ''.join(esc.get(c, c) for c in v) + '"') if isinstance(v, str) else json.dumps(v)
        parts.append('"' + k + '":' + val)
    return '{' + ','.join(parts) + '}'

def zy_load(text):
    """zyJsonDocument.解析 for the flat objects these requests use: None on invalid JSON; strings are kept
    raw (still escaped), as zyJson stores them until 取文本 translates them."""
    try: json.loads(text)
    except ValueError: return None
    doc, i, s = {}, 0, text.strip()
    if not s.startswith('{'): return {}
    i = 1
    def raw_string(i):
        j = i + 1
        while s[j] != '"': j += 2 if s[j] == '\\' else 1
        return s[i + 1:j], j + 1
    while i < len(s):
        while s[i] in ' \t\r\n,': i += 1
        if s[i] == '}': break
        key, i = raw_string(i)
        while s[i] in ' \t\r\n:': i += 1
        if s[i] == '"': val, i = raw_string(i); doc[key] = ('s', val)
        else:
            j = i
            while j < len(s) and s[j] not in ',}': j += 1
            doc[key] = ('v', json.loads(s[i:j])); i = j
    return doc

def zy_in(raw, unicode_):
    """JsonValue_TranslationIn: one level; \\uXXXX decoded only when 转译Unicode is true."""
    out, i = [], 0
    simple = {'/': '/', '"': '"', '\\': '\\', 'b': '\b', 't': '\t', 'n': '\n', 'r': '\r', 'f': '\f'}
    while i < len(raw):
        if raw[i] == '\\' and i + 1 < len(raw):
            c = raw[i + 1]
            if c in simple: out.append(simple[c]); i += 2; continue
            if c == 'u' and unicode_: out.append(chr(int(raw[i + 2:i + 6], 16))); i += 6; continue
        out.append(raw[i]); i += 1
    return ''.join(out)

def zy_text(doc, path, translate=None, unicode_=None):
    """zyJsonValue.取文本 (JsonValue_GetStringExW): '' when missing; numbers/booleans as text."""
    if not doc or path not in doc: return ''
    kind, v = doc[path]
    if kind == 's': return zy_in(v, bool(unicode_)) if translate is not False else v
    if isinstance(v, bool): return 'true' if v else 'false'
    return '' if isinstance(v, (dict, list)) or v is None else str(v)

def zy_int(doc, path):
    """zyJsonValue.取整数 (JsonValue_GetInt): numbers truncated, strings through StrToInt."""
    if not doc or path not in doc: return 0
    kind, v = doc[path]
    if kind == 's':
        m = __import__('re').match(r'\s*([+-]?\d+)', v); return int(m.group(1)) if m else 0
    return int(v) if isinstance(v, (int, float)) else 0

def ucs2_encode(text):
    r"""精易 编码_Unicode到usc2 → Encode_UnicodeToUcs2(sub="\u", enNumEscape=默认真, upCase=默认假): every
    UTF-16 unit, ASCII included, as \u + four lowercase hex digits."""
    data = text.encode('utf-16-le')
    return ''.join('\\u%04x' % int.from_bytes(data[k:k + 2], 'little') for k in range(0, len(data), 2))

def ucs2_decode(text):
    r"""精易 编码_usc2到Unicode → Encode_Ucs2ToUnicode: wcsstr for "\u"; whatever precedes it is copied as is."""
    out, i = [], 0
    while True:
        j = text.find('\\u', i)
        if j < 0: out.append(text[i:]); break
        out.append(text[i:j]); out.append(chr(int(text[j + 2:j + 6], 16))); i = j + 6
    return bytearray(''.join(out).encode('utf-16-le'))

def ip_identity(vm, args, env):
    try: ip = ipaddress.ip_address(vm.value(args[0], env))
    except ValueError: vm.assign(args[1], '', env); return False
    vm.assign(args[1], ('v4:%08x' % int(ip)) if ip.version == 4 else ('v6:%032x' % int(ip)), env); return True

def atomic_add(vm, args, env):
    cell = vm.cell(args[0], env); old = cell.value; cell.value = old + vm.value(args[1], env); return old

class ToneServer(V3Runtime):
    def load(self, text):
        super().load('\n'.join(strip_trailing_comment(l) for l in text.splitlines()))
    def __init__(self, key):
        super().__init__(key); self.seed(); assert self.prepare()
        self.load(WEB.read_text(encoding='utf-8-sig'))
        self.business, self.parsed, self.routes = [], {}, {'/racklink/v3/hello', '/tone/v3/add', '/tone/v3/del', '/addTone'}
        g = {'m_歌曲并发': 0, 'm_限流锁': 0, 'm_限流键': [''] * 1024, 'm_限流分钟': [0] * 1024, 'm_限流次数': [0] * 1024, '#歌曲写入要求登录验证': False}
        for name in ('Web服务_歌曲并发上限', 'Web服务_查询每分钟上限', 'Web服务_写入每分钟上限'): g['#' + name] = constant(name)
        self.globals.update({k: Cell(v) for k, v in g.items()})
        self.overrides.update({
            'MySql_基调库可用': lambda: True,
            '基调_用户添加': lambda req: self.business.append(('add', dict(self.parsed))) or 'ok',
            '基调_用户删除': lambda req: self.business.append(('del', dict(self.parsed))) or 'ok',
            '局_上下文.回复字节集': lambda data, kind, status: self.replies.append((bytes(data).decode(), status)),
            '局_上下文.连接IP': lambda: '127.0.0.1', '局_上下文.请求头计数': lambda name: 0,
            'Web服务_回复': lambda req, text: self.replies.append((text, 200)),
            '编码_Utf8到Ansi': lambda data: bytes(data).decode('utf-8'),
            'Web服务_解包': lambda req: self.fill_from(self.legacy_body),
            '编码_Ansi到Utf8': lambda text: bytearray(str(text).encode('utf-8')),
        })
        self.ref_overrides.update({'Web服务_填请求': self.fill, 'Web服务_机架IP标识': ip_identity, '原子_运算': atomic_add})
        self.legacy_body = ''; self.fill_texts = []
    def fill_from(self, text):
        data = json.loads(text); self.parsed = {k: data.get(k, '') for k in ('soft', 'userName', 'keyword', 'tone', 'scale')}
        self.globals['局_请求.soft'] = Cell(data.get('soft', 0)); self.globals['局_请求.userName'] = Cell(data.get('userName', ''))
        return bool(data.get('keyword'))
    def fill(self, vm, args, env):
        text = self.value(args[0], env); self.fill_texts.append(text)
        return self.fill_from(text)
    def http(self, path, body):
        if path not in self.routes: return 404, b''
        self.request_body = body; self.replies.clear()
        if path == '/racklink/v3/hello': self.call('机架授权_回复传输公钥')
        elif path == '/addTone': self.legacy_body = body.decode(); self.call('Web接口_用户添加基调')
        else: self.call('Web接口_歌曲写入v3', path.endswith('/del'))
        assert len(self.replies) == 1, self.replies
        text, status = self.replies[0]
        return status, text.encode()

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'epl_engine'))
import epl_machine
KEY_NAMES = epl_machine.Machine()
KEY_NAMES.load_static((CLIENT.parent / '程序集_机架联动引擎.static.e.txt').read_text(encoding='utf-8-sig'),
                      names={'基调名_音高', '基调名_旧名', '音阶名_标准', '音阶名_旧名'})


class ToneClient(VM):
    def load(self, text):
        super().load('\n'.join(strip_trailing_comment(l) for l in text.splitlines()))
    def __init__(self, server, signing_hex, credential='current-key', machine='current-machine'):
        super().__init__([CLIENT])
        # the client sends the server's old Chinese key names (基调名_旧名, in the engine source): run its real source
        # with epl_machine, whose library has the text commands it uses, and hand the result to this VM
        self.overrides['基调名_旧名'] = lambda key: KEY_NAMES.invoke(KEY_NAMES.subs['基调名_旧名'], [('lit', key)], {}, None)
        self.overrides['音阶名_旧名'] = lambda scale: KEY_NAMES.invoke(KEY_NAMES.subs['音阶名_旧名'], [('lit', scale)], {}, None)
        self.server, self.requests, self.intercept, self.zy, self.docs, self.logs = server, [], None, {}, {}, []
        g = {'私_独立上下文': True, '私_接口域名': BASE, '私_软件': 3, '私_账号': 'account', '私_凭据': credential,
             '私_机器码': machine, '私_签名公钥': signing_hex, '私_查询失败状态': 0, '全_软件类型': 3, '全_账号': 'account', '全_基调查询_API接口_域名': BASE}
        self.globals.update({k: Cell(v) for k, v in g.items()})
        self.overrides.update({
            'zyJson.创建': lambda *a: self.zy.clear(),
            'zyJson.置文本': lambda k, v, *a: self.zy.__setitem__(k, v),
            'zyJson.置整数': lambda k, v, *a: self.zy.__setitem__(k, int(v)),
            'zyJson.到文本': lambda *a: zy_dump(self.zy),
            '编码_Unicode到usc2': lambda data, *a: ucs2_encode(bytes(data).decode('utf-16-le')),
            '编码_Ansi到Utf8': lambda text: bytearray(text.encode('utf-8')),
            '字节集_十六进制到字节集': self.unhex, '字节集_字节集到十六进制': lambda data: bytes(data).hex().upper(),
            'L_SHA256': lambda data: bytearray(hashlib.sha256(bytes(data)).digest()),
            'L_随机字节': lambda n: bytearray(os.urandom(n)),
            'L_HKDF_SHA256': lambda ikm, salt, info, n: bytearray(HKDF(algorithm=hashes.SHA256(), length=n, salt=bytes(salt) or None, info=bytes(info)).derive(bytes(ikm))),
            'L_RSA验证签名': self.verify, '编码_BASE64解码': lambda text: bytearray(base64.b64decode(text)),
            '调试输出': lambda *a: None, '取程序名称': lambda *a: 'test',
            'API_基调查询_数据加密': lambda data: bytearray(b'legacy'), 'API_基调查询_数据解密': lambda data: bytearray(data),
            '基调响应_转Ansi': lambda data: '', '编码_Unicode到Ansi': lambda data: bytes(data).decode('utf-16-le'),
            '机架引擎_记日志': lambda text: self.logs.append(text), '取代码': lambda text, *a: ord(text[0]) if text else 0,
            # EPL 到字节集 encodes text as GBK; the shared evaluator uses latin1 for byte round trips, so keep
            # latin1 where it applies and fall back to GBK for real Chinese text (as the module sees it).
            '到字节集': lambda x: bytearray(x) if not isinstance(x, str) else bytearray(x.encode('latin1') if all(ord(c) < 256 for c in x) else x.encode('gbk')),
        })
        for doc in ('局_公钥JSON', '局_回复JSON', '局_结果JSON'):
            self.overrides[doc + '.解析'] = lambda text, *a, doc=doc: self.zy_parse(doc, text, *a)
            self.overrides[doc + '.取文本'] = lambda path, *a, doc=doc: zy_text(self.docs.get(doc), path, *a)
        self.ref_overrides.update({'网页_访问_对象': self.http, 'L_RSA_OAEP公钥加密': self.oaep,
                                   'L_AES256GCM_加密': self.seal, 'L_AES256GCM_解密': self.open})
    def unhex(self, text):
        try: return bytearray(bytes.fromhex(text))
        except ValueError: return bytearray()
    def zy_parse(self, name, text, *a):
        self.docs[name] = zy_load(text); return self.docs[name] is not None
    def verify(self, data, sig, pem, alg):
        assert alg == 'SHA256'
        try: serialization.load_pem_public_key(bytes(pem)).verify(bytes(sig), bytes(data), padding.PKCS1v15(), hashes.SHA256()); return True
        except (InvalidSignature, ValueError): return False
    def oaep(self, vm, args, env):
        data, pem, bits = bytes(self.value(args[0], env)), bytes(self.value(args[1], env)), self.value(args[2], env)
        key = serialization.load_pem_public_key(pem)
        if key.key_size < bits: return False
        self.assign(args[3], bytearray(key.encrypt(data, OAEP)), env); return True
    def seal(self, vm, args, env):
        key, nonce, aad, pt = (bytes(self.value(a, env)) for a in args[:4]); out = AESGCM(key).encrypt(nonce, pt, aad)
        self.assign(args[4], bytearray(out[:-16]), env); self.assign(args[5], bytearray(out[-16:]), env); return True
    def open(self, vm, args, env):
        key, nonce, aad, ct, tag = (bytes(self.value(a, env)) for a in args[:5]); self.assign(args[5], bytearray(), env)
        try: self.assign(args[5], bytearray(AESGCM(key).decrypt(nonce, ct + tag, aad)), env); return True
        except (InvalidTag, ValueError): return False
    def http(self, vm, args, env):
        url, body = self.value(args[0], env), bytes(self.value(args[9], env))
        path = url[len(BASE):]; self.requests.append((path, body))
        assert url.startswith(BASE) and (not path.startswith(('/racklink/v3/', '/tone/v3/')) or 'Content-Type: application/json' in self.value(args[5], env))
        result = self.intercept(path, body) if self.intercept else None
        status, reply = result if result is not None else self.server.http(path, body)
        self.assign(args[7], status, env); return bytearray(reply)
    def write(self, delete=False, title='歌手 - 歌名', tone='C', scale='大调'):
        name = bytearray(title.encode('utf-16-le'))
        return self.call('私_写入v3', '/tone/v3/del' if delete else '/tone/v3/add', name, '' if delete else tone, '' if delete else scale)

class ToneWriteV3Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.signing_hex = cls.key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo).hex()
    def pair(self, **kw):
        server = ToneServer(self.key); return server, ToneClient(server, self.signing_hex, **kw)

    def test_standard_key_names_go_out_the_way_older_clients_sent_them(self):
        # the program keeps standard English names (C#, Db, F#; Major, Minor); the wire keeps the old Chinese values every server reads
        for tone, scale, sent, sent_scale in (('C#', 'Minor', 'D-平行', '小调'), ('Db', 'Major', 'D-平行', '大调'), ('F#', 'Major', 'F-锋利', '大调'),
                                              ('G#', 'Minor', 'A-平行', '小调'), ('Bb', 'Minor', 'B-平行', '小调'), ('E', 'Major', 'E', '大调'),
                                              ('E', '小调', 'E', '小调')):
            with self.subTest(tone=tone, scale=scale):
                server, client = self.pair()
                self.assertEqual(client.write(tone=tone, scale=scale), 1)
                self.assertEqual((server.business[-1][1]['tone'], server.business[-1][1]['scale']), (sent, sent_scale))

    def test_add_and_delete_each_run_only_their_own_business_call(self):
        server, client = self.pair()
        self.assertEqual(client.write(), 1)
        self.assertEqual([b[0] for b in server.business], ['add'])
        self.assertEqual({k: server.business[0][1][k] for k in ('soft', 'userName', 'tone', 'scale')}, {'soft': 3, 'userName': 'account', 'tone': 'C', 'scale': '大调'})
        self.assertIn('\\u6b4c', server.business[0][1]['keyword'])
        self.assertEqual(client.write(delete=True), 1)
        self.assertEqual([b[0] for b in server.business], ['add', 'del'])
        self.assertEqual([p for p, _ in client.requests], ['/racklink/v3/hello', '/tone/v3/add', '/racklink/v3/hello', '/tone/v3/del'])
        self.assertTrue(server.lock_reads == 0 and any(q.startswith('SELECT HEX(CONVERT(s.') for q in server.read_queries))

    def test_credentials_never_appear_outside_the_envelope(self):
        server, client = self.pair(); client.write()
        outer = client.requests[1][1]
        self.assertNotIn(b'current-key', outer); self.assertNotIn(b'current-machine', outer); self.assertNotIn(b'credential', outer)
        self.assertEqual(set(json.loads(outer)), {'v', 'kid', 'ek', 'iv', 'box'})

    def test_wrong_login_key_or_machine_code_is_refused_without_writing(self):
        for kw in ({'credential': 'stale-key'}, {'machine': 'other-machine'}):
            with self.subTest(**kw):
                server, client = self.pair(**kw)
                self.assertEqual(client.write(), 0); self.assertEqual(server.business, [])
                self.assertEqual(server.replies[-1][1], 401)
                self.assertEqual(client.logs, ['添加/删除基调：服务端拒绝（invalid_credentials）'])

    def test_server_restart_between_hello_and_write_retries_once(self):
        server, client = self.pair(); state = {'rotated': False}
        def rotate_once(path, body):
            if path == '/tone/v3/add' and not state['rotated']:
                state['rotated'] = True; self.assertTrue(server.prepare())
            return None
        client.intercept = rotate_once
        self.assertEqual(client.write(), 1)
        self.assertEqual([p for p, _ in client.requests], ['/racklink/v3/hello', '/tone/v3/add', '/racklink/v3/hello', '/tone/v3/add'])
        self.assertEqual([b[0] for b in server.business], ['add'])

    def test_old_server_or_unavailable_transport_falls_back_to_legacy_path(self):
        for routes, expected in ((({'/racklink/v3/hello'}), ['/racklink/v3/hello', '/tone/v3/add']), (set(), ['/racklink/v3/hello'])):
            with self.subTest(routes=sorted(routes)):
                server, client = self.pair(); server.routes = routes
                self.assertEqual(client.write(), -1); self.assertEqual([p for p, _ in client.requests], expected)
                self.assertTrue(client.logs and all('改走旧接口' in l for l in client.logs), client.logs)
        server, client = self.pair(); client.intercept = lambda path, body: (503, b'{"ok":false,"error":"transport_unavailable"}')
        self.assertEqual(client.write(), -1)
        # A reverse proxy that answers unknown paths with the site's index page (200, HTML), or a dropped
        # connection: nothing was sent that the legacy path would not send anyway, so fall back.
        page = (200, b'<!DOCTYPE html><html>index</html>')
        for target, log in (('/racklink/v3/hello', '没转发 /racklink/v3/hello'), ('/tone/v3/add', '服务端没有有效回复（HTTP 200）')):
            server, client = self.pair(); client.intercept = lambda path, body, target=target: page if path == target else None
            self.assertEqual(client.write(), -1); self.assertEqual(server.business, []); self.assertTrue(any(log in l for l in client.logs), client.logs)
        server, client = self.pair(); client.intercept = lambda path, body: (0, b'') if path == '/tone/v3/add' else None
        self.assertEqual(client.write(), -1); self.assertTrue(any('服务端没有有效回复（HTTP 0）' in l for l in client.logs), client.logs)
        server, client = self.pair(); client.ref_overrides['L_RSA_OAEP公钥加密'] = lambda vm, args, env: False
        self.assertEqual(client.write(), -1); self.assertEqual([p for p, _ in client.requests], ['/racklink/v3/hello'])
        self.assertTrue(any('本机加密失败' in l for l in client.logs), client.logs)

    def test_impersonated_transport_key_fails_before_any_credential_is_sent(self):
        imposter = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        server, client = self.pair()
        def forge(path, body):
            if path != '/racklink/v3/hello': return None
            t = rsa.generate_private_key(public_exponent=65537, key_size=2048).public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
            kid = hashlib.sha256(t).hexdigest(); msg = ('XHH-RACKLINK-TRANSPORT-3\n' + kid + '\n' + t.hex() + '\n').encode()
            return 200, json.dumps({'ok': True, 'v': 3, 'kid': kid, 'spki': t.hex(), 'sig': imposter.sign(msg, padding.PKCS1v15(), hashes.SHA256()).hex()}).encode()
        client.intercept = forge
        self.assertEqual(client.write(), 0)
        self.assertEqual([p for p, _ in client.requests], ['/racklink/v3/hello']); self.assertEqual(server.business, [])
        self.assertTrue(any('签名核对不通过' in l and '没有发送登录凭据' in l for l in client.logs), client.logs)
        good = json.loads(server.http('/racklink/v3/hello', b'{}')[1])
        client.requests.clear(); client.intercept = lambda path, body: (200, json.dumps(dict(good, kid='0' * 64)).encode()) if path == '/racklink/v3/hello' else None
        self.assertEqual(client.write(), 0); self.assertEqual([p for p, _ in client.requests], ['/racklink/v3/hello'])

    def test_unsealed_error_text_cannot_inject_into_the_log(self):
        server, client = self.pair()
        client.intercept = lambda path, body: (400, json.dumps({'ok': False, 'error': 'bad\n[机架联动] 伪造的一行'}).encode()) if path == '/tone/v3/add' else None
        self.assertEqual(client.write(), 0)
        self.assertEqual(client.logs, ['添加/删除基调：服务端拒绝（unknown，HTTP 400）'])
        client.logs.clear(); client.intercept = lambda path, body: (429, b'{"ok":false,"error":"rate_limited"}') if path == '/tone/v3/add' else None
        self.assertEqual(client.write(), 0); self.assertEqual(client.logs, ['添加/删除基调：服务端拒绝（rate_limited，HTTP 429）'])

    def test_legacy_path_logs_why_a_write_was_refused(self):
        server, client = self.pair(credential='')            # no credentials: the add goes straight to /addTone
        client.intercept = lambda path, body: (403, b'') if path == '/addTone' else None
        self.assertIs(client.call('添加这首歌', bytearray('歌手 - 歌名'.encode('utf-16-le')), 'C', '大调'), False)
        self.assertEqual([p for p, _ in client.requests], ['/addTone'])
        self.assertEqual(client.logs, ['添加/删除基调：旧接口写入失败（HTTP 403，服务端只接受登录验证的写入）'])
        client.logs.clear(); client.requests.clear(); client.intercept = lambda path, body: (0, b'') if path == '/delTone' else None
        self.assertIs(client.call('删除这首歌', bytearray('歌手 - 歌名'.encode('utf-16-le'))), False)
        self.assertEqual(client.logs, ['添加/删除基调：旧接口写入失败（HTTP 0）'])

    def test_write_is_bound_to_the_account_that_was_verified(self):
        # The inner userName is read twice: by the strict parser (verified against the login table) and by
        # Web服务_填请求 (used for the write). If the two ever disagreed, the write must not land on the
        # unverified name. Simulate the disagreement by making the 填请求 stand-in report another account.
        server, client = self.pair()
        real = server.fill_from
        def other_account(text):
            ok = real(text); server.globals['局_请求.userName'] = Cell('someone_else'); return ok
        server.fill_from = other_account
        self.assertEqual(client.write(), 0)
        self.assertEqual(server.business, [])
        self.assertTrue(any('invalid_request' in l for l in client.logs), client.logs)
        server, client = self.pair()                 # the normal case still writes
        self.assertEqual(client.write(), 1); self.assertEqual(len(server.business), 1)

    def test_module_request_decodes_through_the_real_fill_request(self):
        # End to end for the keyword: the request the module's own code builds (zyJson + doubled
        # backslashes) is handed, exactly as the server passes it after opening the envelope, to the
        # production Web服务_填请求. The one-level version from 2026-11-06 00:01 must fail on it.
        helper = FillRequestTests()
        src = WEB.read_text(encoding='utf-8-sig')
        fixed = r'子文本替换 (子文本替换 (JSON.取文本 (“keyword”, 真, 假), “\\”, “\”, , , 真), “\\U”, “\u”, , , 真)'
        one_level = src.replace(fixed, r'子文本替换 (JSON.取文本 (“keyword”, 真, 真), “\\U”, “\u”, , , 真)')
        self.assertNotEqual(one_level, src)
        for title, artist, name in (('歌手 - 歌名', '歌手', '歌名'), ('周杰伦 - 晴天', '周杰伦', '晴天'), ('A-Lin - 给我一个理由忘记', 'A-Lin', '给我一个理由忘记')):
            server, client = self.pair()
            self.assertEqual(client.write(title=title), 1)
            text = server.fill_texts[-1]
            ok, f = helper.fill(helper.runtime(), text)
            self.assertEqual((ok, bytes(f['歌手W']).decode('utf-16-le'), bytes(f['歌名W']).decode('utf-16-le')), (True, artist, name), title)
            ok, f = helper.fill(helper.runtime(one_level), text)
            self.assertNotEqual(bytes(f['歌手W']).decode('utf-16-le'), artist, title)

    def test_query_logs_why_the_server_gave_no_answer(self):
        server, client = self.pair()
        for status, hint in ((429, '（查询太频繁，稍后自动重试）'), (503, '（服务端繁忙，稍后自动重试）'), (0, '（连不上服务端）'), (500, '')):
            client.logs.clear(); client.intercept = lambda path, body, status=status: (status, b'') if path == '/queryKey' else None
            self.assertIs(client.call('基调查询', bytearray('歌手 - 歌名'.encode('utf-16-le')), '酷狗', Cell('')), False)
            self.assertEqual(client.logs, [f'查询基调：服务端回复 HTTP {status}{hint}'])
        client.logs.clear(); client.intercept = lambda path, body: (200, b'C') if path == '/queryKey' else None
        self.assertIs(client.call('基调查询', bytearray('歌手 - 歌名'.encode('utf-16-le')), '酷狗', Cell('')), True); self.assertEqual(client.logs, [])
        # The same failure is logged once (an offline PC retries every 30 s and would flood the log);
        # after a success the same failure is logged again.
        query = lambda: client.call('基调查询', bytearray('歌手 - 歌名'.encode('utf-16-le')), '酷狗', Cell(''))
        client.intercept = lambda path, body: (0, b'') if path == '/queryKey' else None
        for _ in range(5): self.assertIs(query(), False)
        self.assertEqual(client.logs, ['查询基调：服务端回复 HTTP 0（连不上服务端）'])
        client.intercept = lambda path, body: (200, b'C') if path == '/queryKey' else None; self.assertIs(query(), True)
        client.intercept = lambda path, body: (0, b'') if path == '/queryKey' else None; query(); query()
        self.assertEqual(len(client.logs), 2)

    def test_tampered_or_replayed_reply_is_not_taken_as_success(self):
        server, client = self.pair(); keep = {}
        def tamper(path, body):
            if path != '/tone/v3/add': return None
            status, reply = server.http(path, body); r = json.loads(reply); keep['reply'] = reply
            box = bytearray(base64.urlsafe_b64decode(r['box'] + '=' * (-len(r['box']) % 4))); box[0] ^= 1
            r['box'] = base64.urlsafe_b64encode(bytes(box)).decode().rstrip('='); return status, json.dumps(r).encode()
        client.intercept = tamper; self.assertEqual(client.write(), 0)
        client.intercept = lambda path, body: (200, keep['reply']) if path == '/tone/v3/add' else None
        self.assertEqual(client.write(), 0)

    def test_legacy_endpoint_switch_refuses_unauthenticated_writes(self):
        server, _ = self.pair()
        legacy = json.dumps({'soft': 3, 'userName': 'account', 'keyword': 'x', 'tone': 'C', 'scale': '大调'})
        self.assertEqual(server.http('/addTone', legacy.encode()), (200, b'ok')); self.assertEqual([b[0] for b in server.business], ['add'])
        server.globals['#歌曲写入要求登录验证'].value = True; server.business.clear()
        self.assertEqual(server.http('/addTone', legacy.encode()), (403, b'')); self.assertEqual(server.business, [])
        self.assertEqual(server.globals['m_歌曲并发'].value, 0)
        _, client = self.pair(); client.server = server
        self.assertEqual(client.write(), 1); self.assertEqual([b[0] for b in server.business], ['add'])

    def test_constant_on_the_main_program_side_is_the_bridge_signing_key(self):
        root = CODE.parents[2]
        const = (root / '常量.e.txt').read_text(encoding='utf-8-sig')
        self.assertNotIn('机架联动_签名公钥', const)   # 只在长文本资源里放一整串，不再拆成三段常量拼接
        hexkey = (root / '资源' / '机架联动_签名公钥.txt').read_bytes().decode('ascii')
        self.assertRegex(hexkey, r'^[0-9a-f]+$')
        header = (root / '依赖库/AutoTuneKeyScale/vst3/cpp/companion_public_key.h').read_text(encoding='ascii')
        modulus = bytes(int(x, 16) for x in __import__('re').findall(r'0x([0-9a-f]{2})', header[header.index('{'):header.index('}')]))
        key = serialization.load_der_public_key(bytes.fromhex(hexkey)).public_numbers()
        self.assertEqual((key.n.to_bytes(256, 'big'), key.e), (modulus, 65537))

class FillRequestTests(unittest.TestCase):
    """The production Web服务_填请求 (shared by every song endpoint) reads the request through zyJson. It is
    executed for real against a request built the way the module builds it; zyJson and the 精易 Ucs2
    helpers are stand-ins written from their sources (see zy_dump / zy_in / ucs2_encode / ucs2_decode).r"""
    FIELDS = ['参_请求.soft', '参_请求.userName', '参_请求.player', '参_请求.tone', '参_请求.scale', '参_请求.keyword',
              '参_请求.歌手W', '参_请求.歌名W', '局_歌曲信息.歌手W', '局_歌曲信息.歌名W']
    def runtime(self, source=None):
        r = ToneServer(rsa.generate_private_key(public_exponent=65537, key_size=2048))
        if source is not None: r.load(source)
        r.ref_overrides.pop('Web服务_填请求'); r.zy = None; r.boot_ms = 5_000_000; r.warnings = []
        r.globals.update({n: Cell(bytearray() if n.endswith('W') or n.endswith('keyword') else '') for n in self.FIELDS})
        r.globals['m_解析提醒时间'] = Cell(0)
        r.overrides.update({
            'JSON.解析': lambda text, *a: setattr(r, 'zy', zy_load(text)) or r.zy is not None,
            'JSON.取文本': lambda path, *a: zy_text(r.zy, path, *a), 'JSON.取整数': lambda path: zy_int(r.zy, path),
            '编码_usc2到Unicode': ucs2_decode,
            '编码_Unicode到Ansi': lambda data: bytes(data).decode('utf-16-le'), '编码_Ansi到Unicode': lambda text, *a: bytearray(text.encode('utf-16-le')),
            '分割字节集': lambda data, sep, *a: [bytearray(x) for x in bytes(data).split(bytes(sep))],
            '删除Unicode结尾空白字节': lambda data, *a: bytearray(data), '文本_删首尾空W': lambda data: bytearray(bytes(data).decode('utf-16-le').strip().encode('utf-16-le')),
            '取数组成员数': lambda arr: len(arr), '调试输出': lambda *a: None, '取程序名称': lambda *a: 'test',
            '系统_取启动时间': lambda: r.boot_ms, '闪电_日志': lambda text, level=1: r.warnings.append((text, level))})
        return r
    def module_request(self, song='歌手 - 歌名', **fields):
        # 类_基调查询.基调查询 / 添加这首歌: usc2 of the title with every backslash doubled, written by zyJson.
        body = {'keyword': ucs2_encode(song).replace('\\', '\\\\'), 'tone': 'C', 'scale': '大调', 'soft': 3, 'userName': '张三', 'player': '酷狗'}
        body.update(fields); return zy_dump({k: v for k, v in body.items() if v is not None})
    def fill(self, r, text):
        ok = r.call('Web服务_填请求', text, Cell(0)); g = r.globals
        return ok, {n.split('.')[1]: g[n].value for n in self.FIELDS if n.startswith('参_请求.')}
    def test_request_built_like_the_module_decodes_to_artist_and_title(self):
        text = self.module_request()
        self.assertEqual(text.count('\\\\\\\\u'), 7)          # 4 backslashes before every escaped unit on the wire
        r = self.runtime(); ok, f = self.fill(r, text)
        self.assertTrue(ok)
        self.assertEqual((f['soft'], f['userName'], f['player'], f['tone'], f['scale']), (3, '张三', '酷狗', 'C', '大调'))
        self.assertEqual((bytes(f['歌手W']).decode('utf-16-le'), bytes(f['歌名W']).decode('utf-16-le')), ('歌手', '歌名'))
        self.assertEqual(r.warnings, [])
        for song, artist, title in (('周杰伦 - 晴天', '周杰伦', '晴天'), ('A-Lin - 给我一个理由忘记', 'A-Lin', '给我一个理由忘记'), ('Taylor Swift - Love Story', 'Taylor Swift', 'Love Story')):
            ok, f = self.fill(self.runtime(), self.module_request(song))
            self.assertEqual((ok, bytes(f['歌手W']).decode('utf-16-le'), bytes(f['歌名W']).decode('utf-16-le')), (True, artist, title), song)
    def test_previous_one_level_version_reproduces_the_reported_failure(self):
        # The version shipped at 2026-11-06 00:01 removed only one level: every character keeps a
        # backslash in front, the title cannot be split and the client shows 查询不到此歌曲的基调信息.
        src = WEB.read_text(encoding='utf-8-sig')
        fixed = r'子文本替换 (子文本替换 (JSON.取文本 (“keyword”, 真, 假), “\\”, “\”, , , 真), “\\U”, “\u”, , , 真)'
        self.assertEqual(src.count(fixed), 1)
        r = self.runtime(src.replace(fixed, r'子文本替换 (JSON.取文本 (“keyword”, 真, 真), “\\U”, “\u”, , , 真)'))
        ok, f = self.fill(r, self.module_request())
        # It still "succeeds": the fallback split on a single '-' yields two garbage halves, so the
        # lookup simply finds nothing. The new check (backslash left after decoding) now flags it once.
        self.assertTrue(ok)
        self.assertEqual(bytes(r.globals['参_请求.keyword'].value).decode('utf-16-le'), '\\歌\\手\\ \\-\\ \\歌\\名')
        self.assertEqual((bytes(f['歌手W']).decode('utf-16-le'), bytes(f['歌名W']).decode('utf-16-le')), ('\\歌\\手\\ \\', '\\ \\歌\\名'))
        self.assertEqual(len(r.warnings), 1); self.assertIn('解码后仍带反斜杠', r.warnings[0][0])
    def test_unsplittable_keyword_warns_at_most_every_ten_minutes(self):
        r = self.runtime()
        for _ in range(3): self.assertFalse(self.fill(r, self.module_request('只有歌名'))[0])
        self.assertEqual([lvl for _, lvl in r.warnings], [2]); self.assertIn('拆不出「歌手 - 歌名」', r.warnings[0][0])
        # Two CJK characters whose bytes happen to contain 5C 00 across the boundary are not a backslash.
        self.assertFalse(r.call('Web服务_含反斜杠', bytearray('岀一'.encode('utf-16-le'))))
        self.assertTrue(r.call('Web服务_含反斜杠', bytearray('a\\b'.encode('utf-16-le'))))
        r.boot_ms += 600_000; self.fill(r, self.module_request('只有歌名')); self.assertEqual(len(r.warnings), 2)
    def test_soft_sent_as_text_and_rejections(self):
        ok, f = self.fill(self.runtime(), self.module_request(soft='3'))
        self.assertEqual((ok, f['soft']), (True, 3))
        self.assertFalse(self.fill(self.runtime(), '{not json')[0])
        self.assertFalse(self.fill(self.runtime(), self.module_request(keyword=None))[0])
    def test_no_access_key_table_or_list_left_in_code(self):
        import re as _re
        root = CODE.parents[2]
        for proj in (root / '服务端/服务端_电音基调', root / '模块/模块_电音助手.e~'):
            for path in proj.rglob('*.e.txt'):
                for n, line in enumerate(path.read_text(encoding='utf-8-sig').replace('\r', '').split('\n'), 1):
                    s = line.lstrip()
                    if s.startswith(("'", '.子程序 ')): s = '' if s.startswith("'") else s.split(',')[0]
                    code = _re.sub(r'“[^”]*”', '', s).split("'")[0]
                    self.assertNotRegex(code, '存取键值表|存取列表', (path.name, n))
        writer = CLIENT.read_text(encoding='utf-8-sig')
        body = writer[writer.index('.子程序 私_写入v3一次,'):]; body = body[:body.index('\n.子程序 ', 5)]
        self.assertEqual(sorted(_re.findall(r'(局_\w+JSON)\.解析 \(', body)), ['局_公钥JSON', '局_回复JSON', '局_结果JSON'])

class HostCredentialChainTests(unittest.TestCase):
    """Every path that starts the module's background engine must hand over the credentials,
    otherwise tone writes silently fall back to the unauthenticated endpoint."""
    def subs(self, path):
        t = path.read_text(encoding='utf-8-sig').replace('\r', '')
        return {m.group(1).strip(): m.group(2) for m in __import__('re').finditer(r'^\.子程序 ([^,\n]+)[^\n]*\n(.*?)(?=^\.子程序 |\Z)', t, __import__('re').M | __import__('re').S)}
    def test_every_successful_engine_start_hands_over_credentials(self):
        import re
        root = CODE.parents[2]; starts = 0
        for path in (root / '代码').rglob('*.e.txt'):
            for name, body in self.subs(path).items():
                lines = [l.strip() for l in body.split('\n') if l.strip() and not l.strip().startswith("'")]
                for i, line in enumerate(lines):
                    if '电音助手.启动后台 (' not in line: continue
                    starts += 1
                    self.assertTrue(line.startswith(('.如果 (电音助手.启动后台 (', '.如果真 (电音助手.启动后台 (')), (path.name, name, line[:80]))
                    branch = []
                    for l in lines[i + 1:]:
                        if l.startswith(('.否则', '.如果结束', '.如果真结束')): break
                        branch.append(l)
                    self.assertTrue(any(l.startswith('机架联动_交登录凭据 ()') for l in branch), (path.name, name))
        self.assertGreaterEqual(starts, 2)
        host = self.subs(root / '代码/集_基础支持/机架联动_宿主.static.e.txt')
        hand = host['机架联动_交登录凭据']
        self.assertIn('.如果真 (或者 (等于 (软件账号, “”), 等于 (软件密钥, “”)))\n    返回 ()', hand)
        self.assertIn('电音助手.置登录凭据 (软件密钥, 取机器码 (), #机架联动_签名公钥)', hand)
        self.assertIn('局_旧机器码W, ATU (取机器码 (), ))', host['机架联动_登录后启动'] + ''.join(host.values()))
    def test_engine_stop_clears_credentials_inside_the_lock(self):
        engine = self.subs(CLIENT.parent / '程序集_机架联动引擎.static.e.txt')['机架引擎_停止']
        locked = engine[engine.index('EnterCriticalSectionP (集_机架_许可证)'):engine.index('LeaveCriticalSectionP (集_机架_许可证)')]
        self.assertIn('赋值 (集_机架_启动凭据, “”)', locked); self.assertIn('赋值 (集_机架_启动机器码, “”)', locked)

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(); ap.add_argument('--out', type=Path); args, _ = ap.parse_known_args()
    suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(c) for c in (ToneWriteV3Tests, FillRequestTests, HostCredentialChainTests)])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {'status': 'passed' if result.wasSuccessful() else 'failed', 'tests': result.testsRun,
              'failures': len(result.failures), 'errors': len(result.errors), 'actual_EPL_runtime': False}
    if args.out: args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False)); sys.exit(0 if result.wasSuccessful() else 1)
