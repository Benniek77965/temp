#!/usr/bin/env python3
"""Execute the actual EPL host validator and check the three root defaults.

EPL statements use the existing source evaluator. InetPton is an explicit
ipaddress boundary model; no DNS, network, MySQL or Windows API is executed.
"""
from pathlib import Path
import ipaddress
import sys
import unittest

ENGINE_TESTS = Path(__file__).resolve().parents[1] / 'epl_engine'
sys.path.insert(0, str(ENGINE_TESTS))
import review_regression as source_runtime
from test_epl_mid_contract import arguments

SERVER = Path(__file__).resolve().parents[4] / '服务端/服务端_电音基调'
CODE = SERVER / '代码'


def inet_pton_boundary(family, host, output):
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        return 0
    if '%' in host or address.version != {2: 4, 23: 6}.get(family):
        return 0
    output[:len(address.packed)] = address.packed
    return 1


def find_text(text, needle, start=None, match_case=None):
    if match_case:
        text, needle = text.lower(), needle.lower()
    position = text.find(needle, (start or 1) - 1)
    return position + 1 if position >= 0 else -1


class MysqlHostTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = (CODE / '机架联动数据.static.e.txt').read_text(encoding='utf-8-sig')
        cls.config = (CODE / '机架联动配置.static.e.txt').read_text(encoding='utf-8-sig')
        cls.gui = (CODE / '机架联动管理界面.static.e.txt').read_text(encoding='utf-8-sig')

    def valid(self, host):
        runtime = source_runtime.Runtime(self.data)
        runtime.functions.update({
            '到字节集': lambda value: value.encode('utf-8'),
            '取字节集长度': len,
            '字符': chr,
            '寻找文本': find_text,
            '取空白字节集': bytearray,
            '取文本长度': len,
            '取文本右边': lambda value, count: value[-count:] if count else '',
            '机架_InetPtonA': inet_pton_boundary,
        })
        return runtime.invoke('数据_服务器地址正确', host)

    def test_domains_hostnames_and_remote_addresses(self):
        for host in ('127.0.0.1', 'localhost', 'db.example.com', 'DB-SQL_01',
                     'db.internal.', '10.20.30.40', '203.0.113.25', '::1',
                     '2001:db8::1', '::ffff:192.0.2.1', 'xn--fiqs8s.example',
                     'a' * 63 + '.example', 'database-server'):
            with self.subTest(host=host):
                self.assertTrue(self.valid(host))

    def test_invalid_or_misplaced_address_parts(self):
        for host in ('', ' ', ' db.example.com', 'db.example.com ', 'db\n.example',
                     'db\x00.example', 'http://db.example.com', 'https://db',
                     'db.example.com:3306', '[2001:db8::1]', 'fe80::1%12',
                     'db..example', '.db', 'db.example..', '-db.example',
                     'db-.example', 'a' * 64 + '.example', '999.1.2.3',
                     '1.2.3', '2001:db8:::1', 'db/path', 'db@host',
                     '数据库.example', 'a' * 255):
            with self.subTest(host=host):
                self.assertFalse(self.valid(host))

    def test_dns_length_boundaries_and_no_pre_resolution(self):
        longest = '.'.join(('a' * 63, 'b' * 63, 'c' * 63, 'd' * 61))
        self.assertEqual(len(longest), 253)
        self.assertTrue(self.valid(longest))
        self.assertTrue(self.valid(longest + '.'))
        self.assertFalse(self.valid(longest + 'e'))
        # A syntactically valid, nonexistent domain must not require DNS in the UI.
        self.assertTrue(self.valid('not-a-real-database.invalid'))
        body = source_runtime.syntax.section(self.data, '数据_服务器地址正确')
        for network_call in ('转换为IP地址', 'IP_域名取IP', '连接MySql', '数据_查询'):
            self.assertNotIn(network_call + ' (', body)

    def test_same_host_validator_is_used_for_edit_and_startup(self):
        edit = source_runtime.syntax.section(self.config, '机架配置_编辑校验')
        startup = source_runtime.syntax.section(self.data, '数据_初始化')
        self.assertIn('取反 (数据_服务器地址正确 (局_值))', edit)
        self.assertIn('取反 (数据_服务器地址正确 (局_地址))', startup)
        self.assertIn('集_机架连接池.init (局_地址, 局_用户,', startup)

    def test_default_root_in_control_loader_and_runtime(self):
        create = source_runtime.syntax.section(self.gui, '机架界面_创建')
        line = next(row for row in create.splitlines() if row.startswith('集_界面_基础输入[8].创建 ('))
        self.assertEqual(arguments(line, line.index('('))[1], '“root”')
        load = source_runtime.syntax.section(self.config, '机架配置_界面载入')
        self.assertRegex(load, r'加入成员 \(参_项目, “user”\)\s+加入成员 \(参_值, “root”\)')
        self.assertIn('机架配置_读 (“mysql”, “user”, “root”)', self.data)
        self.assertIn('机架配置_取值 (局_节, 局_项目名, 局_值, 参_节[局_i], 参_项目[局_i], 参_值[局_i])', load)

    def test_ansi_ip_parser_uses_the_real_dll_export(self):
        dll = (SERVER / 'DLL.e.txt').read_text(encoding='utf-8-sig')
        self.assertRegex(dll, r'\.DLL命令 机架_InetPtonA, 整数型, "ws2_32\.dll", "inet_pton",')


if __name__ == '__main__':
    unittest.main()
