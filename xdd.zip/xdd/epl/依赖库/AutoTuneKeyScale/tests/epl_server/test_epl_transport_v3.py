"""Execute the production protocol-v3 server code in the bundled EPL evaluator.

Covered production subroutines: 机架授权_准备传输密钥, 机架授权_PEM到DER,
机架授权_回复传输公钥, 机架授权_处理信封, 机架授权_打开信封, 机架授权_封装回复,
the clock alignment and limiter mode inside 机架授权_签发 / 机架授权_解析令牌, and the
real 机架授权_限流. Boundaries: the 精易 L_* crypto calls are real OpenSSL (python
cryptography); MySQL is the SQLite stand-in of test_epl_device_rebind; the 闪电Web
context is recorded. The end-to-end case drives the production C bridge code
(extracted and compiled natively, as in tests/security/test_bridge_v3.py) against
this interpreted server. Not an EPL compiler, Windows runtime, MySQL or live HTTP."""
from __future__ import annotations
import base64, hashlib, hmac, json, os, re, shutil, subprocess, sys, tempfile, unittest
from pathlib import Path
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.exceptions import InvalidTag
from test_epl_device_rebind import AuthorizationRuntime, A, B
from test_epl_token_renewal import Cell

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tests/security'))
sys.path.insert(0, str(ROOT.parents[2] / 'tools'))
OAEP = padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
def b64u(b): return base64.urlsafe_b64encode(b).decode().rstrip('=')
def unb64u(s): return base64.urlsafe_b64decode(s + '=' * (-len(s) % 4))

class V3Runtime(AuthorizationRuntime):
    def __init__(self, key):
        super().__init__(key)
        for name, value in {'集_传输私钥': bytearray(), '集_传输编号': '', '集_传输发布': ''}.items():
            self.globals[name] = Cell(value)
        self.logs, self.replies, self.limits, self.oaep_calls = [], [], [], 0
        self.request_body, self.content_length, self.fail_keygen, self.transport = b'', None, False, None
        self.overrides.update({
            '闪电_日志': lambda text, level=1: self.logs.append((text, level)),
            'L_HKDF_SHA256': lambda ikm, salt, info, n: bytearray(HKDF(algorithm=hashes.SHA256(), length=n, salt=bytes(salt) or None, info=bytes(info)).derive(bytes(ikm))),
            '机架配置_是否启用': lambda: True,
            '机架配置_取私钥': lambda: bytearray(b'signing-key-handle'),
            '机架授权_限流': self.limit,
            '局_上下文.置头': lambda name, value: None,
            '局_上下文.方法': lambda: 'POST',
            '局_上下文.请求体字节集': lambda: bytearray(self.request_body),
            '局_上下文.请求头': self.header,
            '局_上下文.回复JSONUTF8': lambda text, status: self.replies.append((text, status)),
        })
        self.ref_overrides.update({
            'L_生成RSA密钥对': self.generate, 'L_RSA_OAEP私钥解密': self.oaep,
            'L_AES256GCM_解密': self.gcm_open, 'L_AES256GCM_加密': self.gcm_seal,
            'Web服务_机架来源': self.peer_source,
        })
    # ---- boundaries ----
    def limit(self, ip, account, error_cell_value=None, mode=0):
        self.limits.append((ip, account, mode or 0)); return True
    def header(self, name):
        if name == 'Content-Length': return str(len(self.request_body) if self.content_length is None else self.content_length)
        if name == 'Content-Type': return 'application/json; charset=utf-8'
        return ''
    def peer_source(self, vm, args, env):
        self.assign(args[0], 'v4:7f000001', env); return True
    def generate(self, vm, args, env):
        if self.fail_keygen: return False
        self.transport = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        self.assign(args[0], bytearray(self.transport.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)), env)
        # 精易 L_生成RSA密钥对 writes the private key with PEM_write_bio_RSAPrivateKey (PKCS#1).
        self.assign(args[1], bytearray(self.transport.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption())), env)
        return True
    def oaep(self, vm, args, env):
        self.oaep_calls += 1
        data, pem, bits = bytes(self.value(args[0], env)), bytes(self.value(args[1], env)), self.value(args[2], env)
        self.assign(args[3], bytearray(), env)
        try:
            key = serialization.load_pem_private_key(pem, None)
            if key.key_size < bits: return False
            self.assign(args[3], bytearray(key.decrypt(data, OAEP)), env); return True
        except Exception:
            return False
    def gcm_open(self, vm, args, env):
        key, nonce, aad, ct, tag = (bytes(self.value(a, env)) for a in args[:5])
        self.assign(args[5], bytearray(), env)
        try: self.assign(args[5], bytearray(AESGCM(key).decrypt(nonce, ct + tag, aad)), env); return True
        except (InvalidTag, ValueError): return False
    def gcm_seal(self, vm, args, env):
        key, nonce, aad, pt = (bytes(self.value(a, env)) for a in args[:4])
        out = AESGCM(key).encrypt(nonce, pt, aad)
        self.assign(args[4], bytearray(out[:-16]), env); self.assign(args[5], bytearray(out[-16:]), env); return True
    # ---- helpers ----
    def prepare(self):
        return self.call('机架授权_准备传输密钥')
    def envelope(self, path, inner, kid=None, ek=None, k=None, iv=None, mutate=None):
        k = k or os.urandom(32); iv = iv or os.urandom(12)
        kid = kid or self.globals['集_传输编号'].value
        aad = ('XHH-RACKLINK-REQ-3\n' + path + '\n' + kid).encode()
        box = AESGCM(k).encrypt(iv, inner if isinstance(inner, bytes) else inner.encode(), aad)
        outer = {'v': 3, 'kid': kid, 'ek': b64u(ek if ek is not None else self.transport.public_key().encrypt(k, OAEP)), 'iv': iv.hex(), 'box': b64u(box)}
        if mutate: mutate(outer)
        return json.dumps(outer), k, iv
    def open(self, outer_text, path):
        keys, values, types = Cell([], '文本型'), Cell([], '文本型'), Cell([], '整数型')
        assert self.call('机架授权_JSON解析', bytearray(outer_text.encode()), keys, values, types)
        k, iv, inner, error, status = Cell(bytearray(), '字节集'), Cell('', '文本型'), Cell(bytearray(), '字节集'), Cell('', '文本型'), Cell(0, '整数型')
        ok = self.call('机架授权_打开信封', keys, values, types, path, k, iv, inner, error, status)
        return ok, bytes(k.value), iv.value, bytes(inner.value), error.value, status.value
    def handle(self, outer_text, renew):
        self.request_body = outer_text.encode(); self.replies.clear()
        self.call('机架授权_处理信封', renew)
        assert len(self.replies) == 1, self.replies
        return self.replies[0]
    def authorize_v3(self, client_now, renew_token=None, device=B, nonce=None):
        fields = {'license_id': ('account', 6), 'credential': ('current-key', 6), 'device': (device, 6),
                  'nonce': (nonce or f'{self.random_serial+500:032x}', 6), 'parent': ('42', 2),
                  'controller_version': ('4', 2), 'agent_build': ('1165', 2), 'soft': ('3', 6),
                  'legacy_machine_code': ('current-machine', 6)}
        if client_now is not None: fields['client_now'] = (str(client_now), 2)
        if renew_token is not None: fields['token'] = (renew_token, 6)
        error, status = Cell(''), Cell(0)
        out = self.call('机架授权_签发', renew_token is not None, list(fields), [v[0] for v in fields.values()],
                        [v[1] for v in fields.values()], '127.0.0.1', error, status, True)
        return out, error.value, status.value

def claims_of(token):
    raw = base64.urlsafe_b64decode(token.split('.')[1] + '==').decode('ascii')
    return dict(line.split('=', 1) for line in raw.strip('\n').split('\n'))

class TransportV3Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    def runtime(self, seeded=True):
        r = V3Runtime(self.key)
        if seeded: r.seed()
        self.assertTrue(r.prepare())
        return r

    def test_transport_key_publication_is_signed_and_self_consistent(self):
        r = self.runtime(seeded=False)
        der = r.transport.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
        kid = r.globals['集_传输编号'].value
        self.assertEqual(kid, hashlib.sha256(der).hexdigest())
        pub = json.loads(r.globals['集_传输发布'].value)
        self.assertEqual((pub['ok'], pub['v'], pub['kid'], pub['spki']), (True, 3, kid, der.hex()))
        message = ('XHH-RACKLINK-TRANSPORT-3\n' + kid + '\n' + der.hex() + '\n').encode()
        self.key.public_key().verify(bytes.fromhex(pub['sig']), message, padding.PKCS1v15(), hashes.SHA256())
        self.assertTrue(bytes(r.globals['集_传输私钥'].value).startswith(b'-----BEGIN RSA PRIVATE KEY-----'))
        self.assertTrue(any('传输密钥已就绪' in text and kid[:12] in text for text, _ in r.logs))
        self.assertFalse(any(b'PRIVATE' in text.encode() for text, _ in r.logs))
        # hello replies with the precomputed publication and does no crypto per request.
        r.replies.clear(); calls = (r.oaep_calls,); r.call('机架授权_回复传输公钥')
        self.assertEqual(r.replies, [(r.globals['集_传输发布'].value, 200)]); self.assertEqual((r.oaep_calls,), calls)

    def test_key_generation_failure_disables_only_v3(self):
        r = V3Runtime(self.key); r.fail_keygen = True
        self.assertFalse(r.prepare())
        self.assertEqual((r.globals['集_传输编号'].value, r.globals['集_传输发布'].value, bytes(r.globals['集_传输私钥'].value)), ('', '', b''))
        self.assertTrue(any(level == 3 for _, level in r.logs))
        r.call('机架授权_回复传输公钥'); self.assertEqual(r.replies[-1][1], 503); self.assertIn('transport_unavailable', r.replies[-1][0])

    def test_pem_to_der_is_strict(self):
        r = V3Runtime(self.key)
        k = rsa.generate_private_key(public_exponent=65537, key_size=2048).public_key()
        pem = k.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
        der = k.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
        self.assertEqual(bytes(r.call('机架授权_PEM到DER', bytearray(pem))), der)
        self.assertEqual(bytes(r.call('机架授权_PEM到DER', bytearray(pem.replace(b'\n', b'\r\n')))), der)
        pkcs1 = k.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.PKCS1)
        for bad in (pkcs1, b'', b'garbage', pem[:40], b'x' + pem):
            self.assertEqual(bytes(r.call('机架授权_PEM到DER', bytearray(bad))), b'', bad[:30])

    def test_open_envelope_accepts_only_well_formed_current_envelopes(self):
        r = self.runtime(seeded=False); path = '/racklink/v3/authorize'; inner = '{"license_id":"a"}'
        outer, k, iv = r.envelope(path, inner)
        ok, got_k, got_iv, got_inner, error, status = r.open(outer, path)
        self.assertEqual((ok, got_k, got_iv, got_inner), (True, k, iv.hex(), inner.encode()))
        # Stale transport key (server restarted) is distinguished so the client refetches once.
        outer2, _, _ = r.envelope(path, inner, kid='0' * 64)
        self.assertEqual(r.open(outer2, path)[4:], ('transport_key_changed', 409))
        cases = {
            'wrong_path_aad': (r.envelope(path, inner)[0], '/racklink/v3/renew'),
            'version': (r.envelope(path, inner, mutate=lambda o: o.update(v=2))[0], path),
            'iv_upper_hex': (r.envelope(path, inner, mutate=lambda o: o.update(iv=o['iv'].upper()))[0], path),
            'box_tamper': (r.envelope(path, inner, mutate=lambda o: o.update(box=o['box'][:-2] + ('A' if o['box'][-2] != 'A' else 'B') + o['box'][-1]))[0], path),
            'box_too_short': (r.envelope(path, inner, mutate=lambda o: o.update(box=b64u(b'x' * 16)))[0], path),
            'missing_ek': (r.envelope(path, inner, mutate=lambda o: o.pop('ek'))[0], path),
            'ek_not_32_bytes': (r.envelope(path, inner, ek=r.transport.public_key().encrypt(b'y' * 31, OAEP))[0], path),
        }
        for name, (text, p) in cases.items():
            with self.subTest(case=name):
                ok, kk, _, ii, error, status = r.open(text, p)
                self.assertEqual((ok, kk, ii, error, status), (False, b'', b'', 'invalid_envelope', 400))
        # Wrong-length ek still performs exactly one full private-key operation.
        for ek in (os.urandom(10), os.urandom(300), b''):
            before = r.oaep_calls
            text, _, _ = r.envelope(path, inner, ek=ek if ek else b'\x00')
            self.assertEqual(r.open(text, path)[4:], ('invalid_envelope', 400))
            self.assertEqual(r.oaep_calls - before, 1)

    def test_seal_reply_binds_path_key_and_request_iv(self):
        r = self.runtime(seeded=False); k = os.urandom(32); req_iv = os.urandom(12).hex(); path = '/racklink/v3/renew'
        sealed = json.loads(r.call('机架授权_封装回复', bytearray(k), path, req_iv, '{"ok":true,"token":"t"}'))
        self.assertEqual(set(sealed), {'v', 'iv', 'box'}); self.assertEqual(sealed['v'], 3)
        rk = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b'XHH-RACKLINK-RESP-3').derive(k)
        kid = r.globals['集_传输编号'].value
        aad = ('XHH-RACKLINK-RESP-3\n' + path + '\n' + kid + '\n' + req_iv).encode()
        self.assertEqual(AESGCM(rk).decrypt(bytes.fromhex(sealed['iv']), unb64u(sealed['box']), aad), b'{"ok":true,"token":"t"}')
        for bad_aad in (aad.replace(b'renew', b'authorize'), aad[:-1] + (b'1' if aad[-1:] == b'0' else b'0'), aad.replace(kid.encode(), b'0' * 64)):
            self.assertNotEqual(bad_aad, aad)
            with self.assertRaises(InvalidTag): AESGCM(rk).decrypt(bytes.fromhex(sealed['iv']), unb64u(sealed['box']), bad_aad)

    def test_sealed_handler_errors_are_sealed_and_envelope_errors_are_not(self):
        r = self.runtime(); path = '/racklink/v3/authorize'
        outer, k, iv = r.envelope(path, '{"license_id":"account"}')
        text, status = r.handle(outer, False)
        self.assertEqual(status, 400)
        sealed = json.loads(text); rk = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b'XHH-RACKLINK-RESP-3').derive(k)
        aad = ('XHH-RACKLINK-RESP-3\n' + path + '\n' + r.globals['集_传输编号'].value + '\n' + iv.hex()).encode()
        self.assertEqual(json.loads(AESGCM(rk).decrypt(bytes.fromhex(sealed['iv']), unb64u(sealed['box']), aad)), {'ok': False, 'error': 'invalid_credential'})
        self.assertEqual(r.limits[0], ('v4:7f000001', '', 1))      # source IP limited before the private-key operation
        text, status = r.handle(r.envelope(path, '{}', kid='1' * 64)[0], False)
        self.assertEqual((json.loads(text), status), ({'ok': False, 'error': 'transport_key_changed'}, 409))
        r.content_length = 3; text, status = r.handle(outer, False); r.content_length = None
        self.assertEqual((json.loads(text)['error'], status), ('incomplete_body', 400))

    def test_v3_issuance_aligns_token_times_and_keeps_database_in_server_time(self):
        for skew in (0, 7, -45, 3600, -86400):
            with self.subTest(skew=skew):
                r = V3Runtime(self.key); r.seed()
                out, error, status = r.authorize_v3(client_now=r.now + skew)
                self.assertEqual(status, 200, (error, out)); reply = json.loads(out); c = claims_of(reply['token'])
                row = r.db.execute('SELECT issued,expires FROM racklink_sessions WHERE device=? AND revoked=0', (B,)).fetchone()
                self.assertEqual((int(c['iat']), int(c['exp']), reply['expires_at']), (row[0] + skew, row[1] + skew, row[1] + skew))
                self.assertTrue(r.now <= row[0] <= r.now + 30 and row[1] - row[0] <= 120)
                self.assertEqual(r.limits[-1], ('127.0.0.1', 'account', 2))
                # Renewal keeps the session's offset even though the client clock drifted 3 s.
                r.now += 30; r.random_serial += 1
                out2, error2, status2 = r.authorize_v3(client_now=r.now + skew + 3, renew_token=reply['token'])
                self.assertEqual(status2, 200, (error2, out2)); c2 = claims_of(json.loads(out2)['token'])
                row2 = r.db.execute('SELECT issued,expires FROM racklink_sessions WHERE sid=?', (c['sid'],)).fetchone()
                self.assertEqual((int(c2['iat']), int(c2['exp'])), (row2[0] + skew, row2[1] + skew))
                self.assertGreater(int(c2['iat']), int(c['iat']))
                # A protocol-v2 renewal of an aligned token is refused (offset must be 0 there).
                if skew:
                    r.now += 30; r.random_serial += 1
                    error3, status3 = Cell(''), Cell(0)
                    fields = {'license_id': ('account', 6), 'credential': ('current-key', 6), 'device': (B, 6), 'nonce': (f'{r.random_serial+900:032x}', 6),
                              'parent': ('42', 2), 'controller_version': ('4', 2), 'agent_build': ('1165', 2), 'soft': ('3', 6),
                              'legacy_machine_code': ('current-machine', 6), 'token': (json.loads(out2)['token'], 6)}
                    out3 = r.call('机架授权_签发', True, list(fields), [v[0] for v in fields.values()], [v[1] for v in fields.values()], '127.0.0.1', error3, status3)
                    self.assertEqual(out3, ''); self.assertIn(status3.value, (401, 409))

    def test_clock_jump_after_issue_forces_reauthorization(self):
        r = V3Runtime(self.key); r.seed()
        out, error, status = r.authorize_v3(client_now=r.now + 600); token = json.loads(out)['token']
        r.now += 30; r.random_serial += 1
        out2, error2, status2 = r.authorize_v3(client_now=r.now + 600 + 500, renew_token=token)
        self.assertEqual((out2, error2, status2), ('', 'token_expired', 401))
        r.random_serial += 1
        out3, error3, status3 = r.authorize_v3(client_now=r.now + 1100)
        self.assertEqual(status3, 200, error3)
        self.assertEqual(int(claims_of(json.loads(out3)['token'])['iat']) - r.db.execute('SELECT MAX(issued) FROM racklink_sessions').fetchone()[0], 1100)

    def test_client_now_is_optional_bounded_and_ignored_by_v2(self):
        cases = [(None, 0), ('0', 0), ('-5', 0), (str(1 << 41), 0), (str(1000000 + 10 ** 9), 315360000), ('1', 1 - 1000000)]
        for value, expected in cases:
            with self.subTest(client_now=value):
                r = V3Runtime(self.key); r.seed()
                if value is None:
                    out, error, status = r.authorize_v3(client_now=None)
                else:
                    fields_value = value
                    out, error, status = r.authorize_v3(client_now=fields_value) if fields_value.lstrip('-').isdigit() else (None, None, None)
                self.assertEqual(status, 200, (error, out))
                c = claims_of(json.loads(out)['token'])
                issued = r.db.execute('SELECT issued FROM racklink_sessions WHERE device=? AND revoked=0', (B,)).fetchone()[0]
                self.assertEqual(int(c['iat']) - issued, expected)
        # Protocol v2 (no envelope) never applies client_now even if present.
        r = V3Runtime(self.key); r.seed()
        out, error, status = r.authorize(extra={'client_now': (str(r.now + 3600), 2)})
        self.assertEqual(status, 200, error)
        c = claims_of(json.loads(out)['token'])
        self.assertEqual(int(c['iat']), r.db.execute('SELECT issued FROM racklink_sessions WHERE device=? AND revoked=0', (B,)).fetchone()[0])

    def test_real_rate_limiter_counts_only_the_requested_buckets(self):
        r = V3Runtime(self.key); del r.overrides['机架授权_限流']
        r.db.execute('CREATE TABLE racklink_rate_limits(bucket TEXT,minute INTEGER,count INTEGER,PRIMARY KEY(bucket,minute))')
        secret = b'limiter-secret'
        r.overrides['机架配置_取限流密钥'] = lambda: bytearray(secret)
        r.overrides['L_计算HMAC'] = lambda data, key, alg: bytearray(hmac.new(bytes(key), bytes(data), hashlib.sha256).digest())
        base_adapted = r.adapted
        r.adapted = lambda sql: base_adapted(sql).replace(' ON DUPLICATE KEY UPDATE count=count+1', ' ON CONFLICT(bucket,minute) DO UPDATE SET count=count+1')
        bucket = lambda text: "'" + hmac.new(secret, text.encode(), hashlib.sha256).hexdigest() + "'"
        def counts():
            return {row[0]: row[2] for row in r.db.execute('SELECT * FROM racklink_rate_limits')}
        err = Cell('')
        self.assertTrue(r.call('机架授权_限流', '1.2.3.4', 'acct', err))
        self.assertEqual(counts(), {bucket('ip:1.2.3.4').strip("'"): 1, bucket('account:acct').strip("'"): 1})
        self.assertTrue(r.call('机架授权_限流', '1.2.3.4', '', err, 1))
        self.assertEqual(counts(), {bucket('ip:1.2.3.4').strip("'"): 2, bucket('account:acct').strip("'"): 1})
        self.assertTrue(r.call('机架授权_限流', '9.9.9.9', 'acct', err, 2))
        self.assertEqual(counts(), {bucket('ip:1.2.3.4').strip("'"): 2, bucket('account:acct').strip("'"): 2})
        for _ in range(58): r.call('机架授权_限流', '1.2.3.4', '', err, 1)
        self.assertTrue(r.call('机架授权_限流', '1.2.3.4', '', err, 1) is False and err.value == 'rate_limited')

    def test_production_bridge_against_interpreted_server_end_to_end(self):
        from racklink_keygen import public_header
        from test_bridge_v3 import harness_source
        r = self.runtime()
        with tempfile.TemporaryDirectory(prefix='v3-e2e-', dir=os.environ.get('XHH_TEST_TMP')) as d:
            d = Path(d)
            for name in ('companion_security.h', 'companion_protocol.h', 'companion_rsa_verify.h', 'companion_envelope.h', 'rack_bridge_json.h'):
                shutil.copyfile(ROOT / 'vst3/cpp' / name, d / name)
            (d / 'companion_public_key.h').write_text(public_header(self.key), encoding='ascii')
            (d / 'h.cpp').write_text(harness_source((ROOT / 'vst3/cpp/keyscale_rack_bridge.cpp').read_text(encoding='utf-8')), encoding='utf-8')
            build = subprocess.run(['g++', '-std=c++11', '-O1', '-I', str(d), str(d / 'h.cpp'), '-o', str(d / 'h')], capture_output=True, text=True)
            self.assertEqual(build.returncode, 0, build.stderr[-3000:])
            proc = subprocess.Popen([str(d / 'h')], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1)
            try:
                def call(inner, renew):
                    proc.stdin.write(f'CALL {"http://srv.test:1333".encode().hex()} {1 if renew else 0} {inner.encode().hex()}\n'); proc.stdin.flush()
                    while True:
                        parts = proc.stdout.readline().split()
                        if parts[0] == 'RESULT':
                            return int(parts[1]), parts[2], int(parts[3]), (bytes.fromhex(parts[5]).decode() if parts[5] != '-' else '')
                        path, outer = bytes.fromhex(parts[2]).decode(), bytes.fromhex(parts[3]).decode()
                        r.replies.clear()
                        if path == '/racklink/v3/hello': r.call('机架授权_回复传输公钥'); text, status = r.replies[0]
                        else: text, status = r.handle(outer, path.endswith('/renew'))
                        proc.stdin.write(f'RES 0 {status} {text.encode().hex()}\n'); proc.stdin.flush()
                skew = 4321
                def inner(renew_token=None):
                    body = {'license_id': 'account', 'credential': 'current-key', 'device': B, 'nonce': os.urandom(16).hex(), 'parent': 42,
                            'controller_version': 4, 'agent_build': 1165, 'soft': 3, 'client_now': r.now + skew, 'legacy_machine_code': 'current-machine'}
                    if renew_token: body['token'] = renew_token
                    return json.dumps(body, separators=(',', ':'))
                code, reason, http, token = call(inner(), False)
                self.assertEqual((code, reason, http), (0, 'none', 200)); self.assertTrue(token.startswith('XAT3.'))
                c = claims_of(token); row = r.db.execute('SELECT issued FROM racklink_sessions WHERE sid=?', (c['sid'],)).fetchone()
                self.assertEqual(int(c['iat']) - row[0], skew)
                ok, fields = r.parse(token, device=B, now=r.now, offset=skew); self.assertTrue(ok, fields)
                r.now += 30
                code, reason, http, token2 = call(inner(token), True)
                self.assertEqual((code, http), (0, 200)); self.assertEqual(claims_of(token2)['sid'], c['sid'])
                # Server restart: new transport key; the bridge refetches once and succeeds.
                self.assertTrue(r.prepare()); r.now += 30
                code, reason, http, token3 = call(inner(token2), True)
                self.assertEqual((code, http), (0, 200), reason)
                # Sealed server denial reaches the client authenticated and mapped.
                code, reason, http, _ = call(inner().replace('current-key', 'stale-key'), False)
                self.assertEqual((code, reason, http), (3, 'invalid_credentials', 401))
                proc.stdin.write('QUIT\n'); proc.stdin.flush(); proc.wait(timeout=30)
            finally:
                if proc.poll() is None: proc.kill()

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(); ap.add_argument('--out', type=Path); args, rest = ap.parse_known_args()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(TransportV3Tests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {'status': 'passed' if result.wasSuccessful() else 'failed', 'tests': result.testsRun,
              'failures': len(result.failures), 'errors': len(result.errors), 'actual_EPL_runtime': False}
    if args.out: args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False)); sys.exit(0 if result.wasSuccessful() else 1)
