"""机架联动管理窗口「首次配置」页：字段个数各处一致，点「保存配置」时的校验真的能通过。

背景：给多个软件共用服务端时加了第 13 个字段「其它产品」，界面与载入都改成了 13，
配置校验却还按 12 个字段检查，结果每次保存都报「基础配置字段不完整或存在重名」。
这里先从源码数出字段个数、核对各处是否一致，再用源码运行时真正执行一遍保存前的校验。
"""
from pathlib import Path
import re
import sys
import unittest

ENGINE_TESTS = Path(__file__).resolve().parents[1] / 'epl_engine'
sys.path.insert(0, str(ENGINE_TESTS))
import review_regression as source_runtime
syntax = source_runtime.syntax

SERVER = Path(__file__).resolve().parents[4] / '服务端/服务端_电音基调'
CODE = SERVER / '代码'


def read(name):
    return (CODE / name).read_text(encoding='utf-8-sig').replace('\r\n', '\n')


def section(text, name):
    start = re.search(r'^\.子程序 ' + re.escape(name) + r'(?:\s*,|\s*$)', text, re.M).start()
    end = text.find('\n.子程序 ', start + 5)
    return text[start:end if end > 0 else len(text)]


class FieldCountConsistencyTests(unittest.TestCase):
    """以后再加减字段时，漏改任何一处都会在这里报出来。"""

    @classmethod
    def setUpClass(cls):
        cls.config = read('机架联动配置.static.e.txt')
        cls.gui = read('机架联动管理界面.static.e.txt')
        load = section(cls.config, '机架配置_界面载入')
        cls.count = len(re.findall(r'^\s*加入成员 \(参_节, “', load, re.M))

    def test_load_lists_thirteen_fields_including_other_products(self):
        self.assertEqual(self.count, 13)
        self.assertIn('“other_products”', section(self.config, '机架配置_界面载入'))

    def test_validation_checks_the_same_number_of_fields(self):
        check = section(self.config, '机架配置_编辑校验')
        counts = re.findall(r'不等于 \(取数组成员数 \(参_(?:节|项目|值)\), (\d+)\)', check)
        self.assertEqual(counts, [str(self.count)] * 3)
        loops = re.findall(r'^\s*\.计次循环首 \((\d+), 局_(?:i|其它序号)\)', check, re.M)
        self.assertTrue(loops)
        self.assertEqual(set(loops), {str(self.count)})

    def test_window_arrays_and_loops_use_the_same_number(self):
        for name in ('集_界面_基础标题', '集_界面_基础输入', '集_界面_基础节', '集_界面_基础项目'):
            with self.subTest(name=name):
                self.assertRegex(self.gui, r'\.程序集变量 ' + name + r', [^,]+, , "' + str(self.count) + '"')
        for name in ('机架界面_创建', '机架界面_忙状态', '机架界面_发起', '机架界面_回收任务'):
            with self.subTest(name=name):
                body = section(self.gui, name)
                loops = re.findall(r'^\s*\.计次循环首 \((\d+), i\)\n(?:[^\n]*\n){0,3}?[^\n]*集_界面_基础(?:输入|节|项目)\[i\]', body, re.M)
                self.assertTrue(loops, name)
                self.assertEqual(set(loops), {str(self.count)}, name)
        creation = section(self.gui, '机架界面_创建')
        for index in range(1, self.count + 1):
            self.assertIn('集_界面_基础输入[%d].创建 (' % index, creation)


# 参数声明：也认简写（.参数 参_字符上限, 整数型）；第三项是“参考／可空／数组”等标志
PARAM = r'^\.参数 ([^,\n]+), ([^,\n]+?)(?:, ([^,\n]*))?(?:,[^\n]*)?$'


class ServerRuntime(source_runtime.Runtime):
    """服务端模块的源码运行时：调用 机架配置_/数据_/机架授权_ 子程序时执行源码，参考参数写回调用方，带维数的局部变量是数组。"""
    PREFIXES = ('机架配置_', '数据_', '机架授权_')

    def __init__(self, source):
        super().__init__(source)
        self.subs = set(re.findall(r'^\.子程序 ([^,\s]+)', source, re.M))
        self.functions.update({
            '加入成员': lambda array, *values: array.extend(values),
            '重定义数组': lambda array, keep, *sizes: None if keep else array.__setitem__(slice(None), [''] * (sizes[0] if sizes else 0)),
        })

    def invoke(self, name, *values):
        text = syntax.section(self.source, name)
        params = [(n.strip(), k.strip(), f) for n, k, f in re.findall(PARAM, text, re.M)]
        values = (*values, *([None] * (len(params) - len(values))))
        defaults = {'文本型': '', '字节集': b'', '逻辑型': False}
        env = {p: (([] if '数组' in flags else defaults.get(kind, 0)) if v is None else v) for (p, kind, flags), v in zip(params, values)}
        env['_omitted_params'] = {p for (p, _, _), v in zip(params, values) if v is None}
        # 也认简写的声明（.局部变量 局_数量, 整数型）；声明了维数 "N" 的数组一开始就有 N 个成员，"0" 是空数组
        for variable, kind, dims in re.findall(r'^\.局部变量 ([^,\n]+), ([^,\n]+?)(?:, [^,\n]*, ("[^"\n]*")?[^\n]*)?$', text, re.M):
            size = int(dims.strip('"')) if dims.strip('"').isdigit() else 0
            env[variable.strip()] = [defaults.get(kind.strip(), 0)] * size if dims else defaults.get(kind.strip(), 0)
        result = None
        try:
            self.execute_text(text, env)
        except syntax.Returned as returned:
            result = returned.value
        self.last_locals = env
        return result

    def evaluate(self, value, env):
        call = re.fullmatch(r'([^ ()]+)\s*\((.*)\)', value.strip()) if isinstance(value, str) else None
        if call and call.group(1) in self.subs and call.group(1).startswith(self.PREFIXES) and call.group(1) not in self.functions:
            name, raw = call.groups()
            raws = [a.strip() for a in syntax.split_args(raw)] if raw.strip() else []
            result = self.invoke(name, *[self.evaluate(a, env) if a else None for a in raws])
            callee = self.last_locals
            params = [(n.strip(), f) for n, _, f in re.findall(PARAM, syntax.section(self.source, name), re.M)]
            for (param, flags), argument in zip(params, raws):
                if '参考' in flags and '数组' not in flags and argument in env:
                    env[argument] = callee.get(param, env[argument])   # 参考参数：被调子程序改了什么，调用方就看到什么
                elif '参考' in flags and '数组' not in flags and argument in self.env:
                    self.env[argument] = callee.get(param, self.env[argument])   # 传进去的是程序集变量时同样写回
            return result
        return super().evaluate(value, env)


class SaveValidationTests(unittest.TestCase):
    """用源码运行时执行 机架配置_编辑校验：输入与界面点「保存配置」时交给后台的一样。"""

    @classmethod
    def setUpClass(cls):
        cls.source = '\n'.join(read(name) for name in (
            '机架联动配置.static.e.txt', '机架联动数据.static.e.txt', '机架联动授权.static.e.txt'))

    def runtime(self):
        runtime = ServerRuntime(self.source)
        runtime.functions.update({
            '到字节集': lambda value: value.encode('utf-8') if isinstance(value, str) else bytes(value),
            '到文本': lambda value: value.decode('utf-8') if isinstance(value, (bytes, bytearray)) else str(value),
            '取字节集长度': len,
            '取文本长度': len,
            '字符': chr,
            '取空白字节集': bytearray,
            '寻找文本': lambda text, needle, start=None, case=None: text.find(needle, (start or 1) - 1) + 1 if needle in text[(start or 1) - 1:] else -1,
            '子文本替换': lambda text, old, new, start=None, count=None, case=None: text.replace(old, new),
            '取文本左边': lambda value, count: value[:max(count, 0)],
            '取文本右边': lambda value, count: value[-count:] if count > 0 else '',
            '取文本中间': lambda value, start, count: value[start - 1:start - 1 + count],
            '到整数': lambda value: int(value) if str(value).strip().lstrip('-').isdigit() else 0,
            '到数值': lambda value: float(value) if re.fullmatch(r'-?\d+(\.\d+)?', str(value).strip()) else 0,
            '取运行目录': lambda: 'C:\\srv',
            '文件是否存在': lambda path: True,
            # 依赖 Windows 的两处用桩：地址解析由 test_epl_mysql_host 专门测；路径只需给出非空的本机路径
            '数据_服务器地址正确': lambda host: bool(host) and ' ' not in host,
            '机架配置_路径': lambda path: ('C:\\srv\\' + path) if path else '',
            '取代码': lambda value, position=1: ord(value[position - 1]) if 0 < position <= len(value) else 0,
            '取字节集数据': lambda data, kind, position: data[position - 1],   # 源码里只按 #字节型 逐字节读
            '取字节集中间': lambda data, start, count: bytes(data[start - 1:start - 1 + count]),
        })
        runtime.env['#字节型'] = 1
        return runtime

    def form(self, other=''):
        values = {   # 按项目名填写，节名直接取自 机架配置_界面载入，与界面完全一致
            'private_key': 'racklink_private.pem', 'public_key': 'racklink_public.pem',
            'ttl': '120', 'auto_max_devices': '3',
            'host': 'lan.data-layer.master-1.example.com', 'port': '3306',
            'database': 'racklink_db', 'user': 'root', 'password': 'secret-password',
            'session_database': 'yinxiao_db', 'account_database': 'yinxiao_user_db', 'product': '3',
            'other_products': other,
        }
        load = section(read('机架联动配置.static.e.txt'), '机架配置_界面载入')
        pairs = re.findall(r'加入成员 \(参_节, “([^”]+)”\)\n\s*加入成员 \(参_项目, “([^”]+)”\)', load)
        self.assertEqual(len(pairs), 13, pairs)
        missing = [pair for pair in pairs if pair[1] not in values]
        self.assertEqual(missing, [], '测试表单要覆盖界面的每个字段')
        return [s for s, _ in pairs], [k for _, k in pairs], [values[k] for _, k in pairs]

    def check(self, sections, keys, values):
        runtime = self.runtime()
        result = runtime.invoke('机架配置_编辑校验', sections, keys, values, '', '', '')
        return result, runtime.last_locals.get('参_错误', ''), values

    def test_thirteen_field_form_from_the_window_passes(self):
        sections, keys, values = self.form('2,fanxing_changkong_db,fanxing_changkong_user_db')
        result, error, values = self.check(sections, keys, values)
        self.assertTrue(result, error)
        self.assertEqual(values[keys.index('other_products')], '2,fanxing_changkong_db,fanxing_changkong_user_db')

    def test_empty_other_products_passes(self):
        result, error, _ = self.check(*self.form(''))
        self.assertTrue(result, error)

    def test_spaces_and_chinese_punctuation_are_corrected(self):
        sections, keys, values = self.form(' 2， fanxing_changkong_db，fanxing_changkong_user_db ｜ 5,c_db,c_user_db　')
        result, error, values = self.check(sections, keys, values)
        self.assertTrue(result, error)
        self.assertEqual(values[keys.index('other_products')], '2,fanxing_changkong_db,fanxing_changkong_user_db|5,c_db,c_user_db')

    def test_enumeration_comma_from_chinese_input_is_accepted(self):
        sections, keys, values = self.form('2、fanxing_changkong_db、fanxing_changkong_user_db')
        result, error, values = self.check(sections, keys, values)
        self.assertTrue(result, error)
        self.assertEqual(values[keys.index('other_products')], '2,fanxing_changkong_db,fanxing_changkong_user_db')

    def test_wrong_other_products_reports_the_group(self):
        result, error, _ = self.check(*self.form('2,fanxing_changkong_db'))
        self.assertFalse(result)
        self.assertIn('其它产品', error)

    def test_missing_or_duplicated_field_is_still_rejected(self):
        sections, keys, values = self.form('')
        result, error, _ = self.check(sections[:-1], keys[:-1], values[:-1])
        self.assertFalse(result)
        self.assertIn('不完整或存在重名', error)
        sections, keys, values = self.form('')
        sections[-1], keys[-1] = sections[0], keys[0]
        result, error, _ = self.check(sections, keys, values)
        self.assertFalse(result)
        self.assertIn('不完整或存在重名', error)


if __name__ == '__main__':
    unittest.main(verbosity=2)
