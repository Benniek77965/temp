"""机架联动管理窗口「批量管理」页：统计概览、导出许可列表、批量设置设备上限、批量解绑、人工许可改为跟随原账号。

界面接线（始终检查）：5 个按钮在批量页、任务号 14～18 的放行与分派、忙状态、审计、结果显示。
真实数据库（可选）：设置 RACKLINK_TEST_MYSQL_SOCKET 后，用源码运行时执行真实的 机架管理_批量执行／统计／导出，
它们逐个调用的单账号操作（加锁、ROW_COUNT 核对、换代、结束会话、提交）也都由源码对数据库执行。
"""
from pathlib import Path
import csv
import io
import os
import re
import sys
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import test_epl_config_form as form
import test_epl_init_schema as schema

CODE = HERE.parents[3] / '服务端/服务端_电音基调/代码'


def read(name):
    return (CODE / name).read_text(encoding='utf-8-sig').replace('\r\n', '\n')


class BulkWiringTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.gui = read('机架联动管理界面.static.e.txt')
        cls.create = form.section(cls.gui, '机架界面_创建')

    def test_five_buttons_live_on_the_batch_page(self):
        self.assertIn('集_界面_分页.添加子夹 (, “批量管理”', self.create)
        self.assertIn('赋值 (局_批量面板, 集_界面_分页.取面板句柄 (2))', self.create)
        for index, name in ((14, '统计概览'), (15, '导出许可列表（CSV）'), (16, '批量设置设备上限'), (17, '批量解绑全部设备'), (18, '人工许可全部改为跟随原账号有效期')):
            with self.subTest(index=index):
                self.assertRegex(self.create, r'集_界面_按钮\[%d\]\.创建 \(局_批量面板, “%s”, [^\n]*, %d, , \)' % (index, re.escape(name), 43100 + index))
                self.assertIn('集_界面_按钮[%d].事件_被单击 (&机架界面_按钮被单击)' % index, self.create)
        self.assertRegex(self.gui, r'\.程序集变量 集_界面_按钮, 按钮类, , "18"')

    def test_start_accepts_only_known_tasks(self):
        start = form.section(self.gui, '机架界面_发起')
        self.assertIn('小于 (参_任务, 1), 大于 (参_任务, 18), 等于 (参_任务, 11), 等于 (参_任务, 12)', start)
        self.assertIn('赋值 (集_界面_请求产品, 机架界面_取输入UTF8 (集_界面_批量产品))', start)
        self.assertIn('取反 (数据_产品正确 (集_界面_请求产品))', start)

    def test_worker_dispatches_each_task_to_the_right_function(self):
        worker = form.section(self.gui, '机架界面_后台任务')
        self.assertIn('.判断 (等于 (集_界面_任务, 14))\n    赋值 (集_界面_结果成功, 机架管理_统计 (集_界面_请求产品, 集_界面_结果批量, 局_错误))', worker)
        self.assertIn('.判断 (等于 (集_界面_任务, 15))\n    赋值 (集_界面_结果成功, 机架管理_导出 (集_界面_请求产品, 集_界面_结果批量, 集_界面_结果计数, 局_错误))', worker)
        self.assertIn('机架管理_批量执行 (相减 (集_界面_任务, 15), 集_界面_请求产品, 集_界面_请求上限,', worker)
        self.assertIn('并且 (大于或等于 (集_界面_任务, 15), 小于或等于 (集_界面_任务, 18))', worker)   # 审计
        body = worker.split('\n', 1)[1]   # 去掉子程序声明行（注释里写着“绝不调用任何黑月控件”）
        self.assertNotRegex(body, r'集_界面_(批量产品|批量上限|批量结果|状态|摘要|设备|账号|产品|上限输入|按钮\[[^\]]+\])\.', '工作线程不能碰界面控件')

    def test_busy_state_covers_all_buttons_and_batch_inputs(self):
        busy = form.section(self.gui, '机架界面_忙状态')
        self.assertIn('.计次循环首 (18, i)\n    集_界面_按钮[i].禁止 (参_忙)', busy)
        self.assertIn('集_界面_批量产品.禁止 (参_忙)', busy)
        self.assertIn('集_界面_批量上限.禁止 (参_忙)', busy)

    def test_changes_are_confirmed_and_audited_without_listing_accounts(self):
        click = form.section(self.gui, '机架界面_按钮被单击')
        self.assertIn('.如果真 (并且 (大于或等于 (局_任务, 16), 取反 (机架界面_确认 (“”, 局_说明))))', click)
        audit = form.section(self.gui, '机架界面_审计')
        for name in ('导出许可列表', '批量设置设备上限为 ', '批量解绑全部设备', '人工许可批量改为跟随原账号有效期'):
            self.assertIn(name, audit)
        self.assertIn('.如果真 (并且 (大于或等于 (参_任务, 6), 小于或等于 (参_任务, 13)))', audit)
        recycle = form.section(self.gui, '机架界面_回收任务')
        self.assertIn('集_界面_批量结果.内容W (编码_Utf8到Unicode (到字节集 (集_界面_结果批量)))', recycle)


class BulkRuntime(schema.InitRuntime):
    PREFIXES = form.ServerRuntime.PREFIXES + ('机架管理_',)   # 管理模块的子程序也按源码执行
    OUT = schema.InitRuntime.OUT | {'数据_结束', '数据_查询原账号'}


@unittest.skipUnless(schema.SOCKET and schema.pymysql, '未设置 RACKLINK_TEST_MYSQL_SOCKET 或没有 pymysql：跳过真实数据库检查')
class RealDatabaseBulkTests(unittest.TestCase):
    NOW = 1800000000
    FOLLOW_EXPIRES = 1900000000

    @classmethod
    def setUpClass(cls):
        cls.source = '\n'.join(read(n) for n in ('机架联动配置.static.e.txt', '机架联动数据.static.e.txt', '机架联动授权.static.e.txt', '机架联动管理.static.e.txt'))
        cls.creates = re.findall(r'加入成员 \(局_建表, “([^”]+)”\)', form.section(read('机架联动数据.static.e.txt'), '数据_初始化'))

    def connect(self):
        return schema.pymysql.connect(unix_socket=schema.SOCKET, user='root', autocommit=True, database='racklink_db')

    def setUp(self):
        with schema.pymysql.connect(unix_socket=schema.SOCKET, user='root', autocommit=True) as c, c.cursor() as k:
            k.execute('DROP DATABASE IF EXISTS racklink_db'); k.execute('CREATE DATABASE racklink_db'); k.execute('USE racklink_db')
            for statement in self.creates:
                k.execute(statement)
            rows = (('alice', '3', 'auto', 0, self.NOW + 10 ** 6, 3, 2, True), ('bob', '3', 'auto', 0, self.NOW + 10 ** 6, 3, 3, True),
                    ('carol', '3', 'manual', 0, self.NOW + 10 ** 6, 5, 0, False), ('alice', '2', 'manual', 1, self.NOW - 100, 3, 1, False),
                    ('=cmd"x', '3', 'auto', 0, self.NOW + 10 ** 6, 3, 0, False))
            self.ids = {}
            for account, product, origin, revoked, expires, limit, devices, online in rows:
                k.execute('INSERT INTO racklink_licenses(account,product,origin,revoked,expires,max_devices) VALUES(%s,%s,%s,%s,%s,%s)',
                          (account, product, origin, revoked, expires, limit))
                lid = k.lastrowid; self.ids[(product, account)] = lid
                for n in range(devices):
                    k.execute('INSERT INTO racklink_devices(license_id,device,first_seen) VALUES(%s,%s,%s)', (lid, ('%d%02d' % (lid, n)).ljust(64, 'a'), n))
                k.execute('INSERT INTO racklink_sessions(sid,license_id,device,parent,issued,expires,token_hash,generation,revoked) VALUES(%s,%s,%s,0,0,%s,%s,1,0)',
                          (('s%d' % lid).ljust(32, '0'), lid, 'd'.ljust(64, 'a'), self.NOW + (60 if online else -60), 'h'.ljust(64, 'a')))

    def license(self, product, account):
        with self.connect() as c, c.cursor() as k:
            lid = self.ids[(product, account)]
            k.execute('SELECT max_devices,generation,origin,expires FROM racklink_licenses WHERE id=%s', (lid,)); m, g, o, e = k.fetchone()
            k.execute('SELECT COUNT(*) FROM racklink_devices WHERE license_id=%s', (lid,)); d = k.fetchone()[0]
            k.execute('SELECT MIN(revoked) FROM racklink_sessions WHERE license_id=%s', (lid,)); r = k.fetchone()[0]
            return {'limit': m, 'generation': g, 'origin': o, 'expires': e, 'devices': d, 'sessions_revoked': bool(r)}

    def run_source(self, name, *arguments):
        runtime = BulkRuntime(self.source)
        connection = self.connect(); cursor = connection.cursor()
        sets, current, written = {}, {}, []

        def run(sql):
            cursor.execute(sql)
            return cursor.fetchall() if cursor.description else ()

        def execute(handle, sql):
            try:
                run(sql); return True
            except schema.pymysql.MySQLError:
                return False

        def query(handle, sql, record_set):
            try:
                cursor.execute(sql)
            except schema.pymysql.MySQLError:
                return schema.Out(-1, {2: 0})
            names = [d[0] for d in cursor.description]
            key = len(sets) + 1; sets[key] = (names, cursor.fetchall()); current[key] = 0
            return schema.Out(len(sets[key][1]), {2: key})

        def field(record_set, name, value):
            if record_set not in sets or not sets[record_set][1]:
                return schema.Out(False, {})
            names, rows = sets[record_set]
            cell = rows[current[record_set]][names.index(name)]
            if cell is None:
                return schema.Out(False, {})
            return schema.Out(True, {2: cell.decode('utf-8') if isinstance(cell, (bytes, bytearray)) else str(cell)})

        def finish(handle, commit):
            try:
                run('COMMIT' if commit else 'ROLLBACK'); return schema.Out(True, {0: 0})
            except schema.pymysql.MySQLError:
                return schema.Out(False, {0: 0})

        runtime.functions.update({
            '数据_借连接': lambda handle: schema.Out(True, {0: 1}),
            '数据_开始事务': lambda handle: execute(handle, 'START TRANSACTION'),
            '数据_结束': finish, '数据_执行': execute, '数据_查询': query,
            '读字段值': field, '到指定行': lambda record_set, row: current.__setitem__(record_set, row),
            '释放记录集': lambda record_set: None, '清除数组': lambda array: array.clear(),
            '数据_查询原账号': lambda handle, account, product, expires, banned: schema.Out(1, {3: self.FOLLOW_EXPIRES, 4: 0}),
            '数据_SQL文本': lambda text: "'" + text.replace('\\', '\\\\').replace("'", "''") + "'",
            '机架授权_现在': lambda: self.NOW,
            '机架配置_读': lambda section, key, default: {'product': '3'}.get(key, default),   # 主产品 3（锁许可里 选择 的两边都会求值）
            '机架授权_匹配': lambda text, pattern: re.fullmatch(pattern, text) is not None,
            '编码_Ansi到Utf8': lambda text: text, '到文本': lambda value: value.decode('utf-8') if isinstance(value, (bytes, bytearray)) else str(value),
            '到字节集': lambda value: value.encode('utf-8') if isinstance(value, str) else bytes(value),
            '取运行目录': lambda: 'C:\\srv', '创建目录': lambda path: True,
            '写到文件': lambda path, *parts: written.append((path, b''.join(bytes(p) for p in parts))) or True,
            '取文本长度': len, '字符': chr, '取字节集长度': len, '取字节集数据': lambda data, kind, position: data[position - 1],
            '取文本左边': lambda value, count: value[:max(count, 0)], '取文本右边': lambda value, count: value[-count:] if count > 0 else '',
            '取文本中间': lambda value, start, count: value[start - 1:start - 1 + count],
            '取代码': lambda value, position=1: ord(value[position - 1]) if 0 < position <= len(value) else 0,
            '寻找文本': lambda text, needle, start=None, case=None: text.find(needle, (start or 1) - 1) + 1 if needle in text[(start or 1) - 1:] else -1,
            '子文本替换': lambda text, old, new, *unused: text.replace(old, new),
            '到整数': lambda value: int(value) if str(value).strip().lstrip('-').isdigit() else 0,
        })
        runtime.env.update({'#字节型': 1, '#换行符': '\r\n', '#引号': '"', '集_机架产品': '3', '集_机架会话库': 'yinxiao_db', '集_机架账户库': 'yinxiao_user_db',
                            '集_机架其它产品': ['2'], '集_机架其它会话库': ['fanxing_changkong_db'], '集_机架其它账户库': ['fanxing_changkong_user_db']})
        try:
            result = runtime.invoke(name, *arguments)
        finally:
            connection.close()
        return result, runtime.last_locals, written

    def test_statistics_per_product_and_total(self):
        ok, out, _ = self.run_source('机架管理_统计', '', '', '')
        self.assertTrue(ok, out.get('参_错误'))
        text = out['参_摘要UTF8']
        p2, p3 = text.index('产品 2'), text.index('产品 3')
        self.assertLess(p2, p3)
        self.assertIn('联动许可：1 个（跟随原账号 0，旧人工管理 1，其中人工期限已到 1）', text[p2:p3])
        self.assertIn('已禁用：1 个', text[p2:p3])
        self.assertIn('联动许可：4 个（跟随原账号 3，旧人工管理 1，其中人工期限已到 0）', text[p3:])
        self.assertIn('已绑定设备：5 台；设备已满的账号：1 个', text[p3:])
        self.assertIn('当前在线会话：2 个', text[p3:])
        self.assertIn('全部合计\r\n    联动许可：5 个', text)
        ok, out, _ = self.run_source('机架管理_统计', '2', '', '')
        self.assertTrue(ok)
        self.assertNotIn('产品 3', out['参_摘要UTF8']); self.assertNotIn('全部合计', out['参_摘要UTF8'])

    def test_raise_device_limit_for_everyone(self):
        before = {k: self.license(*k) for k in self.ids}
        ok, out, _ = self.run_source('机架管理_批量执行', 1, '', 5, '', '', '')
        self.assertTrue(ok, out.get('参_错误'))
        self.assertEqual(out['参_计数'], '符合条件 4 个，成功 4，跳过 0，失败 0')
        for key in self.ids:
            now = self.license(*key)
            self.assertEqual(now['limit'], 5)
            changed = before[key]['limit'] != 5
            self.assertEqual(now['generation'], before[key]['generation'] + (1 if changed else 0), key)
            self.assertEqual(now['sessions_revoked'], changed, key)

    def test_lowering_skips_and_lists_accounts_with_too_many_devices(self):
        ok, out, _ = self.run_source('机架管理_批量执行', 1, '3', 2, '', '', '')
        self.assertTrue(ok, out.get('参_错误'))
        self.assertEqual(out['参_计数'], '符合条件 4 个，成功 3，跳过 1，失败 0')
        self.assertIn('3  bob  已绑定设备数超过新上限，已跳过', out['参_摘要UTF8'])
        self.assertEqual(self.license('3', 'bob')['limit'], 3)
        self.assertEqual(self.license('3', 'alice')['limit'], 2)
        self.assertEqual(self.license('2', 'alice')['limit'], 3)          # 只改产品 3

    def test_unbind_all_devices(self):
        ok, out, _ = self.run_source('机架管理_批量执行', 2, '', 0, '', '', '')
        self.assertTrue(ok, out.get('参_错误'))
        self.assertEqual(out['参_计数'], '符合条件 3 个，成功 3，跳过 0，失败 0')
        for key in self.ids:
            now = self.license(*key)
            self.assertEqual(now['devices'], 0)
        self.assertTrue(self.license('3', 'bob')['sessions_revoked'])
        self.assertFalse(self.license('3', 'carol')['sessions_revoked'])  # 没有设备的账号不动

    def test_manual_licenses_follow_original_account(self):
        ok, out, _ = self.run_source('机架管理_批量执行', 3, '', 0, '', '', '')
        self.assertTrue(ok, out.get('参_错误'))
        self.assertEqual(out['参_计数'], '符合条件 2 个，成功 2，跳过 0，失败 0')
        for key in (('3', 'carol'), ('2', 'alice')):
            now = self.license(*key)
            self.assertEqual((now['origin'], now['expires']), ('auto', self.FOLLOW_EXPIRES))
        self.assertEqual(self.license('3', 'alice')['generation'], 1)       # 已经跟随原账号的不动

    def test_unknown_product_is_rejected(self):
        ok, out, _ = self.run_source('机架管理_批量执行', 1, '9', 5, '', '', '')
        self.assertFalse(ok)
        self.assertIn('产品编号 9 没有配置', out['参_错误'])

    def test_export_csv(self):
        ok, out, written = self.run_source('机架管理_导出', '', '', '', '')
        self.assertTrue(ok, out.get('参_错误'))
        self.assertEqual(len(written), 1)
        path, data = written[0]
        self.assertTrue(path.startswith('C:\\srv\\racklink_export\\licenses_') and path.endswith('.csv'), path)
        self.assertTrue(data.startswith(b'\xef\xbb\xbf'))
        rows = list(csv.reader(io.StringIO(data[3:].decode('utf-8'))))
        self.assertEqual(rows[0], ['产品编号', '账号', '来源', '联动状态', '到期时间', '设备上限', '已绑定设备', '在线会话'])
        self.assertEqual(len(rows), 6)
        self.assertEqual(rows[1][:4], ['2', 'alice', '人工管理', '已禁用'])
        self.assertIn(["3", "'=cmd\"x", '跟随原账号', '正常'], [r[:4] for r in rows])   # 引号转义，公式开头加单引号
        self.assertEqual(out['参_计数'], '导出 5 个许可')


if __name__ == '__main__':
    unittest.main(verbosity=2)
