import unittest
from pathlib import Path


class ActualEplConfigurationLogTests(unittest.TestCase):
    def test_mysql_configuration_debug_statement_omits_credentials(self):
        path = Path(__file__).resolve().parents[4] / "服务端/TCP_验证服务端/代码/窗口程序集.form.e.txt"
        data = path.read_bytes()
        self.assertTrue(data.startswith(b"\xef\xbb\xbf"))
        self.assertEqual(data.count(b"\n"), data.count(b"\r\n"))
        lines = [line.strip() for line in data.decode("utf-8-sig").splitlines()
                 if line.strip().startswith("调试输出 (") and "mysql配置已加载" in line]
        self.assertEqual(len(lines), 1)
        self.assertIn("MySql_端口", lines[0])
        self.assertNotIn("MySql_密码", lines[0])
        self.assertNotIn("MySql_用户名", lines[0])


if __name__ == "__main__": unittest.main(verbosity=2)
