"""The 精易 crypto wrappers the protocol-v3 server and the tone-write client depend on,
checked where the other v3 tests replace them with Python:

* L_HKDF_SHA256 is implemented in EPL on top of L_计算HMAC. The production subroutine is
  executed in the bundled evaluator (HMAC-SHA256 supplied by Python) and compared with
  RFC 5869 vectors, python cryptography and the bridge's C implementation (t_envelope).
* L_生成RSA密钥对: its exact OpenSSL 1.1.1 call sequence (RSA_generate_key_ex,
  PEM_write_bio_RSA_PUBKEY, PEM_write_bio_RSAPrivateKey, BIO_read into a 2*bits buffer) is
  replayed through ctypes against a real libcrypto-1.1; the output feeds the production
  机架授权_PEM到DER / 机架授权_准备传输密钥, the bridge's strict SPKI parser and the bridge's
  OAEP encryption, decrypted with the generated PKCS#1 private key.
The OAEP/GCM wrappers themselves are replayed against real OpenSSL by tests/音效包/
test_p1_openssl.py. Set RPACK_LIBCRYPTO to libcrypto.so.1.1 (libcrypto-1_1.dll on
Windows) for the OpenSSL part; without it that part is skipped, the HKDF part always runs."""
from __future__ import annotations
import ctypes, hashlib, hmac, json, os, re, shutil, subprocess, sys, tempfile, unittest
from pathlib import Path
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from test_epl_token_renewal import VM, Cell, CODE
from test_epl_song_guard import strip_trailing_comment

ROOT = Path(__file__).resolve().parents[2]
JY = CODE.parents[2] / '模块/精易模块v9.3.5[源码].e~'
JY_CRYPTO = JY / '代码/编码与加密/集_OpenSSL加解密.static.e.txt'
OAEP = padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None)

def jy_constant(name):
    for p in JY.rglob('常量.e.txt'):
        m = re.search(r'^\.常量 ' + re.escape(name) + r', "([^"]*)"', p.read_text(encoding='utf-8-sig', errors='replace'), re.M)
        if m: return m.group(1).strip('“”')
    raise KeyError(name)

class JyVM(VM):
    def load(self, text):
        super().load('\n'.join(strip_trailing_comment(l) for l in text.splitlines()))
    def __init__(self):
        super().__init__([JY_CRYPTO])
        self.alg = jy_constant('L_哈希算法_SHA256'); self.hmac_calls = 0
        self.globals['#L_哈希算法_SHA256'] = Cell(self.alg)
        self.overrides.update({'L_计算HMAC': self.mac, '到字节': lambda v: bytearray([int(v) & 0xFF])})
    def mac(self, data, key, alg):
        assert alg == self.alg; self.hmac_calls += 1
        return bytearray(hmac.new(bytes(key), bytes(data), hashlib.sha256).digest())

def t_envelope():
    d = Path(tempfile.mkdtemp(prefix='jy-crypto-', dir=os.environ.get('XHH_TEST_TMP')))
    exe = d / 't_envelope'
    r = subprocess.run(['g++', '-std=c++11', '-O1', '-I', str(ROOT / 'vst3/cpp'), str(ROOT / 'tests/security/t_envelope.cpp'), '-o', str(exe)], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr[-2000:]
    return d, lambda *a: subprocess.run([str(exe), *a], capture_output=True, text=True)

def real_generate_rsa_pem(lib, bits=2048):
    """ctypes replay of 精易 L_生成RSA密钥对 (same calls, arguments and buffer size)."""
    c = ctypes.CDLL(lib); P, I = ctypes.c_void_p, ctypes.c_int
    for name, res, args in [('RSA_new', P, []), ('BN_new', P, []), ('BN_set_word', I, [P, ctypes.c_ulong]),
                            ('RSA_generate_key_ex', I, [P, I, P, P]), ('BIO_s_mem', P, []), ('BIO_new', P, [P]),
                            ('PEM_write_bio_RSA_PUBKEY', I, [P, P]), ('BIO_read', I, [P, P, I]),
                            ('PEM_write_bio_RSAPrivateKey', I, [P, P, P, P, I, P, P]), ('BIO_free', I, [P]),
                            ('BN_free', None, [P]), ('RSA_free', None, [P])]:
        f = getattr(c, name); f.restype = res; f.argtypes = args
    key, bn = c.RSA_new(), c.BN_new(); assert key and bn
    c.BN_set_word(bn, 65537)
    assert c.RSA_generate_key_ex(key, bits, bn, None) == 1
    buf = ctypes.create_string_buffer(bits * 2)
    def export(write):
        bio = c.BIO_new(c.BIO_s_mem()); assert bio
        write(bio); n = c.BIO_read(bio, buf, bits * 2); c.BIO_free(bio)
        return buf.raw[:n] if n > 0 else b''
    public = export(lambda bio: c.PEM_write_bio_RSA_PUBKEY(bio, key))
    private = export(lambda bio: c.PEM_write_bio_RSAPrivateKey(bio, key, None, None, 0, None, None))
    c.BN_free(bn); c.RSA_free(key)
    return public, private

class JyCryptoTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.vm = JyVM(); cls.dir, cli = t_envelope(); cls.cli = staticmethod(cli)
    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.dir, ignore_errors=True)

    def epl_hkdf(self, ikm, salt, info, n):
        return bytes(self.vm.call('L_HKDF_SHA256', bytearray(ikm), bytearray(salt), bytearray(info), n))

    def test_epl_hkdf_matches_rfc5869_cryptography_and_the_bridge(self):
        vectors = [  # RFC 5869 appendix A, SHA-256 test cases 1-3 (case 3: empty salt and info)
            (bytes([0x0b]) * 22, bytes(range(13)), bytes(range(0xf0, 0xfa)), 42,
             '3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf34007208d5b887185865'),
            (bytes(range(0x50)), bytes(range(0x60, 0xb0)), bytes(range(0xb0, 0x100)), 82,
             'b11e398dc80327a1c8e7f78c596a49344f012eda2d4efad8a050cc4c19afa97c59045a99cac7827271cb41c65e590e09da3275600c2f09b8367793a9aca3db71cc30c58179ec3e87c14c01d5c1f3434f1d87'),
            (bytes([0x0b]) * 22, b'', b'', 42,
             '8da4e775a563c18f715f802a063c5a31b8a11f5c5ee1879ec3454e5f3c738d2d9d201395faa4b61a96c8')]
        for ikm, salt, info, n, okm in vectors:
            with self.subTest(n=n, salt=len(salt)):
                ref = HKDF(algorithm=hashes.SHA256(), length=n, salt=salt or None, info=info).derive(ikm)
                self.assertEqual(ref.hex(), okm)
                self.assertEqual(self.epl_hkdf(ikm, salt, info, n).hex(), okm)
                self.assertEqual(self.cli('hkdf', ikm.hex(), salt.hex() or '-', info.hex() or '-', str(n)).stdout.strip(), okm)
        rnd = __import__('random').Random(5869)
        for i in range(200):
            ikm = rnd.randbytes(rnd.choice([1, 16, 32, 64, 100])); salt = rnd.randbytes(rnd.choice([0, 0, 1, 32, 70]))
            info = rnd.randbytes(rnd.choice([0, 3, 19, 64])); n = rnd.choice([1, 31, 32, 33, 64, 65, 255])
            ref = HKDF(algorithm=hashes.SHA256(), length=n, salt=salt or None, info=info).derive(ikm)
            self.assertEqual(self.epl_hkdf(ikm, salt, info, n), ref, (i, len(salt), n))
        # The protocol's reply key: 32 bytes from K with an empty salt and info XHH-RACKLINK-RESP-3.
        k = os.urandom(32); info = b'XHH-RACKLINK-RESP-3'
        self.assertEqual(self.epl_hkdf(k, b'', info, 32).hex(), self.cli('hkdf', k.hex(), '-', info.hex(), '32').stdout.strip())
        for bad in (0, -1, 8161):
            self.assertEqual(self.epl_hkdf(b'x', b'', b'', bad), b'')

    @unittest.skipUnless(os.environ.get('RPACK_LIBCRYPTO'), 'RPACK_LIBCRYPTO (libcrypto 1.1) not set')
    def test_real_openssl_keygen_feeds_the_server_and_the_bridge(self):
        from test_epl_transport_v3 import V3Runtime
        public, private = real_generate_rsa_pem(os.environ['RPACK_LIBCRYPTO'])
        self.assertTrue(public.startswith(b'-----BEGIN PUBLIC KEY-----\n'), public[:40])
        self.assertTrue(private.startswith(b'-----BEGIN RSA PRIVATE KEY-----\n'), private[:40])
        key = serialization.load_pem_private_key(private, None)
        self.assertEqual((key.key_size, key.public_key().public_numbers().e), (2048, 65537))
        der = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
        self.assertEqual(serialization.load_pem_public_key(public).public_numbers(), key.public_key().public_numbers())
        signing = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        server = V3Runtime(signing)
        def real_keygen(vm, args, env):
            vm.assign(args[0], bytearray(public), env); vm.assign(args[1], bytearray(private), env); return True
        server.ref_overrides['L_生成RSA密钥对'] = real_keygen
        self.assertEqual(bytes(server.call('机架授权_PEM到DER', bytearray(public))), der)
        self.assertEqual(len(der), 294)
        self.assertTrue(self.cli('spki', der.hex()).returncode == 0)
        self.assertTrue(server.prepare())
        pub = json.loads(server.globals['集_传输发布'].value)
        self.assertEqual((pub['spki'], pub['kid']), (der.hex(), hashlib.sha256(der).hexdigest()))
        signing.public_key().verify(bytes.fromhex(pub['sig']), ('XHH-RACKLINK-TRANSPORT-3\n' + pub['kid'] + '\n' + pub['spki'] + '\n').encode(), padding.PKCS1v15(), hashes.SHA256())
        self.assertEqual(bytes(server.globals['集_传输私钥'].value), private)
        # The bridge seals K to this transport key; the generated PKCS#1 private key opens it.
        for _ in range(8):
            k, seed = os.urandom(32), os.urandom(32)
            ek = bytes.fromhex(self.cli('oaep', der.hex(), k.hex(), seed.hex()).stdout.strip())
            self.assertEqual(key.decrypt(ek, OAEP), k)

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(); ap.add_argument('--out', type=Path); args, _ = ap.parse_known_args()
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(JyCryptoTests))
    report = {'status': 'passed' if result.wasSuccessful() else 'failed', 'tests': result.testsRun, 'skipped': len(result.skipped),
              'failures': len(result.failures), 'errors': len(result.errors), 'real_openssl': bool(os.environ.get('RPACK_LIBCRYPTO'))}
    if args.out: args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False)); sys.exit(0 if result.wasSuccessful() else 1)
