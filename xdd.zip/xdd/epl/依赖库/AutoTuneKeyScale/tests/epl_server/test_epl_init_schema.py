"""服务端启动时的授权库检查（数据_初始化）。

背景：多产品版把许可表唯一键由 (account) 改成 (product,account)，启动时核对唯一约束的那条 SQL
却仍只认 (account)。改键一成功（数据库账号有 ALTER 权限时，只给一个软件用也会改），之后每次启动都在这里失败，
而且这一步失败时不写原因，管理窗口只显示「联动尚未就绪：mysql / legacy」，两个软件的机架入口都消失。

静态检查：每个失败出口都写明原因；唯一约束新旧两种键都认；登记了别的软件时严格要求只有新键。
真实数据库检查（可选）：设置 RACKLINK_TEST_MYSQL_SOCKET=MySQL/MariaDB 的 unix socket 路径（root 免密，会建删
racklink_db 等测试库）后，用源码运行时执行真实的 数据_初始化，底层 SQL 交给数据库执行。
"""
from pathlib import Path
import os
import re
import sys
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import test_epl_config_form as form   # 复用服务端源码运行时

CODE = HERE.parents[3] / '服务端/服务端_电音基调/代码'
LEGACY = ('yinxiao_db', 'yinxiao_user_db', 'fanxing_changkong_db', 'fanxing_changkong_user_db')


def read(name):
    return (CODE / name).read_text(encoding='utf-8-sig').replace('\r\n', '\n')


class StaticInitTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = read('机架联动数据.static.e.txt')
        cls.init = form.section(cls.data, '数据_初始化')

    def test_every_failure_exit_says_why(self):
        lines = self.init.split('\n')
        silent = []
        for i, line in enumerate(lines):
            if line.strip() != '返回 (假)':
                continue
            indent = len(line) - len(line.lstrip())
            head = next(j for j in range(i - 1, -1, -1)
                        if lines[j].lstrip().startswith('.如果真 (') and len(lines[j]) - len(lines[j].lstrip()) < indent)
            block = '\n'.join(lines[head:i])
            if not re.search(r'赋值 \(集_机架初始化提示, (?!“”\))', block) and '数据_其它产品解析' not in lines[head]:   # 设成非空提示（字面量或拼接）才算写了原因
                silent.append(lines[head].strip()[:80])
        self.assertEqual(silent, [], '这些失败出口没写原因，管理窗口只能显示「mysql / legacy」')

    def test_unique_key_check_accepts_old_and_new_account_key_as_one(self):
        sql = next(l for l in self.init.split('\n') if 'COUNT(DISTINCT CONCAT(t' in l)
        self.assertIn("cols IN ('account','product,account')", sql)
        self.assertIn("IF(t='racklink_licenses' AND cols='product,account','account',cols)", sql)
        self.assertRegex(sql, r'”, 7\)\)\)')

    def test_other_products_require_only_the_new_key(self):
        self.assertIn("SUM(cols='product,account')>0 AND SUM(cols='account')=0", self.init)
        migrate = form.section(self.data, '数据_迁移许可唯一键')
        self.assertIn('ALTER TABLE racklink_licenses DROP INDEX racklink_account”', migrate)

    def test_create_uses_the_new_key(self):
        self.assertIn('UNIQUE KEY racklink_product_account(product,account)', self.init)
        self.assertNotIn('UNIQUE KEY racklink_account(account)', self.init)


SOCKET = os.environ.get('RACKLINK_TEST_MYSQL_SOCKET', '')
try:
    import pymysql
except ImportError:
    pymysql = None


class Out:
    def __init__(self, value, outs):
        self.value, self.outs = value, outs


class InitRuntime(form.ServerRuntime):
    """借连接、查询、读字段值通过参考参数交回结果：桩函数返回 Out 时按位置写回调用方的变量。"""
    OUT = {'数据_借连接', '数据_查询', '读字段值'}

    def evaluate(self, value, env):
        call = re.fullmatch(r'([^ ()]+)\s*\((.*)\)', value.strip()) if isinstance(value, str) else None
        if call and call.group(1) in self.OUT:
            name, raw = call.groups()
            raws = [a.strip() for a in form.syntax.split_args(raw)] if raw.strip() else []
            result = self.functions[name](*[self.evaluate(a, env) if a else None for a in raws])
            for index, value_out in result.outs.items():
                (env if raws[index] in env else self.env)[raws[index]] = value_out
            return result.value
        return super().evaluate(value, env)


@unittest.skipUnless(SOCKET and pymysql, '未设置 RACKLINK_TEST_MYSQL_SOCKET 或没有 pymysql：跳过真实数据库检查')
class RealDatabaseInitTests(unittest.TestCase):
    BASE = {'host': 'db', 'user': 'root', 'password': 'x', 'database': 'racklink_db', 'port': '3306',
            'session_database': 'yinxiao_db', 'account_database': 'yinxiao_user_db', 'product': '3'}
    MULTI = dict(BASE, other_products='2,fanxing_changkong_db,fanxing_changkong_user_db')

    @classmethod
    def setUpClass(cls):
        cls.source = '\n'.join(read(n) for n in ('机架联动配置.static.e.txt', '机架联动数据.static.e.txt', '机架联动授权.static.e.txt'))
        creates = re.findall(r'加入成员 \(局_建表, “([^”]+)”\)', form.section(read('机架联动数据.static.e.txt'), '数据_初始化'))
        cls.creates = creates
        cls.old_creates = [s.replace('UNIQUE KEY racklink_product_account(product,account)', 'UNIQUE KEY racklink_account(account)') for s in creates]
        assert cls.creates != cls.old_creates

    def connect(self, user='root', password=None, database=None):
        options = dict(unix_socket=SOCKET, user=user, autocommit=True, database=database)
        if password:
            options['password'] = password
        return pymysql.connect(**options)

    def reset(self, schema, extra=()):
        with self.connect() as connection, connection.cursor() as cursor:
            for name in ('racklink_db',) + LEGACY:
                cursor.execute('DROP DATABASE IF EXISTS ' + name)
                cursor.execute('CREATE DATABASE ' + name)
                if name != 'racklink_db':
                    cursor.execute('CREATE TABLE %s.tb_user (id INT PRIMARY KEY) ENGINE=InnoDB' % name)
            cursor.execute('USE racklink_db')
            for statement in {'old': self.old_creates, 'none': []}[schema]:
                cursor.execute(statement)
            for statement in extra:
                cursor.execute(statement)

    def unique_keys(self):
        with self.connect(database='racklink_db') as connection, connection.cursor() as cursor:
            cursor.execute("SELECT index_name, GROUP_CONCAT(column_name ORDER BY seq_in_index) FROM information_schema.statistics "
                           "WHERE table_schema='racklink_db' AND table_name='racklink_licenses' AND non_unique=0 AND index_name<>'PRIMARY' GROUP BY index_name ORDER BY index_name")
            return [tuple(row) for row in cursor.fetchall()]

    def no_alter_user(self):
        with self.connect() as connection, connection.cursor() as cursor:
            cursor.execute("DROP USER IF EXISTS 'racklink_noalter'@'localhost'")
            cursor.execute("CREATE USER 'racklink_noalter'@'localhost' IDENTIFIED BY 'pw'")
            cursor.execute("GRANT SELECT,INSERT,UPDATE,DELETE,CREATE ON racklink_db.* TO 'racklink_noalter'@'localhost'")
            for name in LEGACY:
                cursor.execute("GRANT SELECT ON %s.* TO 'racklink_noalter'@'localhost'" % name)
        return 'racklink_noalter', 'pw'

    def init(self, config, user='root', password=None, connect_ok=True):
        runtime = InitRuntime(self.source)
        connection = self.connect(user, password, 'racklink_db')
        cursor = connection.cursor()
        record_sets = {}

        def run(sql):
            # MariaDB 的 information_schema.columns.column_default 带引号（'manual'），MySQL 5.7 不带：比较前去掉引号
            sql = sql.replace("BINARY column_default=BINARY 'manual'", "BINARY TRIM(BOTH CHAR(39) FROM column_default)=BINARY 'manual'")
            try:
                cursor.execute(sql)
                return cursor.fetchall()
            except pymysql.MySQLError:
                return None

        def count_matches(handle, sql, expected):
            rows = run(sql)
            return rows is not None and len(rows) == 1 and int(rows[0][0] or 0) == expected

        def query(handle, sql, record_set):
            rows = run(sql)
            if rows is None:
                return Out(-1, {2: 0})
            record_sets[len(record_sets) + 1] = rows
            return Out(len(rows), {2: len(record_sets)})

        class Pool:
            def init(self, *arguments):
                return True

            def getConnection_curr(self):
                return 2 if connect_ok else 0

        runtime.functions.update({
            '机架配置_读': lambda section, key, default: config.get(key, default),
            '文件是否存在': lambda path: True, '取运行目录': lambda: 'C:\\srv',
            '数据_服务器地址正确': lambda host: True,
            '数据_借连接': lambda handle: Out(True, {0: 1}), '数据_结束': lambda handle, ok: bool(ok),
            '数据_执行': lambda handle, sql: run(sql) is not None,
            '数据_计数符合': count_matches, '数据_查询': query,
            '读字段值': lambda record_set, field, value: Out(True, {2: int(record_sets[record_set][0][0])}) if record_sets.get(record_set) else Out(False, {}),
            '释放记录集': lambda record_set: None,
            '数据_SQL文本': lambda text: "'" + text.replace('\\', '\\\\').replace("'", "''") + "'",
            '到整数': lambda value: int(value) if str(value).strip().lstrip('-').isdigit() else 0,
            '子文本替换': lambda text, old, new, *unused: text.replace(old, new),
            '取文本长度': len, '字符': chr,
            '到字节集': lambda value: value.encode('utf-8') if isinstance(value, str) else bytes(value),
            '取字节集长度': len, '取字节集数据': lambda data, kind, position: data[position - 1],
            '取文本左边': lambda value, count: value[:max(count, 0)],
            '取文本右边': lambda value, count: value[-count:] if count > 0 else '',
            '取文本中间': lambda value, start, count: value[start - 1:start - 1 + count],
            '寻找文本': lambda text, needle, start=None, case=None: text.find(needle, (start or 1) - 1) + 1 if needle in text[(start or 1) - 1:] else -1,
        })
        runtime.env.update({'#字节型': 1, '集_机架数据已初始化': False, '集_机架数据就绪': False, '集_机架初始化提示': '',
                            '集_机架会话库': '', '集_机架账户库': '', '集_机架产品': '', '集_机架其它产品': [],
                            '集_机架其它会话库': [], '集_机架其它账户库': [], '集_机架连接池': Pool()})
        try:
            ready = bool(runtime.invoke('数据_初始化'))
        finally:
            connection.close()
        return ready, runtime.env['集_机架初始化提示']

    def test_old_production_database_single_product_migrates_and_starts(self):
        self.reset('old')
        ready, hint = self.init(self.BASE)
        self.assertTrue(ready, hint)
        self.assertEqual(self.unique_keys(), [('racklink_product_account', 'product,account')])
        ready, hint = self.init(self.BASE)                      # 改过键之后再启动也要就绪
        self.assertTrue(ready, hint)

    def test_old_production_database_with_other_products_starts_every_time(self):
        self.reset('old')
        for attempt in range(2):
            ready, hint = self.init(self.MULTI)
            self.assertTrue(ready, (attempt, hint))

    def test_fresh_install_with_other_products(self):
        self.reset('none')
        ready, hint = self.init(self.MULTI)
        self.assertTrue(ready, hint)
        self.assertEqual(self.unique_keys(), [('racklink_product_account', 'product,account')])

    def test_without_alter_single_product_keeps_old_key_and_starts(self):
        self.reset('old')
        ready, hint = self.init(self.BASE, *self.no_alter_user())
        self.assertTrue(ready, hint)
        self.assertEqual(self.unique_keys(), [('racklink_account', 'account')])

    def test_without_alter_other_products_explain_the_permission(self):
        self.reset('old')
        ready, hint = self.init(self.MULTI, *self.no_alter_user())
        self.assertFalse(ready)
        self.assertIn('ALTER', hint)

    def test_leftover_old_key_is_dropped_when_other_products_are_registered(self):
        self.reset('old', extra=['ALTER TABLE racklink_licenses ADD UNIQUE KEY racklink_product_account(product,account)'])
        ready, hint = self.init(self.MULTI)
        self.assertTrue(ready, hint)
        self.assertEqual(self.unique_keys(), [('racklink_product_account', 'product,account')])

    def test_same_account_name_in_two_products(self):
        self.reset('none')
        self.assertTrue(self.init(self.MULTI)[0])
        with self.connect(database='racklink_db') as connection, connection.cursor() as cursor:
            cursor.execute("SELECT column_name, data_type FROM information_schema.columns WHERE table_schema='racklink_db' AND table_name='racklink_licenses' "
                           "AND is_nullable='NO' AND column_default IS NULL AND extra NOT LIKE '%%auto_increment%%' AND column_name NOT IN ('account','product')")
            required = cursor.fetchall()   # 其余必填且没有默认值的字段：数字填 0，其余填空串
            names = ['account', 'product'] + [name for name, _ in required]
            for product in ('3', '2'):
                values = ['same-name', product] + [0 if kind in ('int', 'bigint', 'tinyint', 'smallint') else '' for _, kind in required]
                cursor.execute('INSERT INTO racklink_licenses(%s) VALUES(%s)' % (','.join(names), ','.join(['%s'] * len(names))), values)
            cursor.execute("SELECT COUNT(*) FROM racklink_licenses WHERE account='same-name'")
            self.assertEqual(cursor.fetchone()[0], 2)

    def test_connection_failure_says_why(self):
        self.reset('old')
        ready, hint = self.init(self.MULTI, connect_ok=False)
        self.assertFalse(ready)
        self.assertIn('连不上MySQL', hint)


if __name__ == '__main__':
    unittest.main(verbosity=2)
