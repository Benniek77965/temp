#!/usr/bin/env python3
"""Check mandatory core MID arguments in actual tone-server EPL exports.

The lexical check ignores comments/literals and handles nested calls and arrays.
It checks the supplied three-required-argument API contract, not EPL compilation.
"""
from pathlib import Path
import re
import unittest

SERVER = Path(__file__).resolve().parents[4] / '服务端/服务端_电音基调'
IDENTIFIER = re.compile(r'\w+', re.UNICODE)
OPEN = {'(': ')', '[': ']', '{': '}'}


def closing_quote(line, start):
    terminal = '”' if line[start] == '“' else '"'
    end = line.find(terminal, start + 1)
    if end < 0:
        raise ValueError('Unclosed EPL string literal')
    return end + 1


def arguments(line, opening):
    stack = ['(']
    output = []
    start = opening + 1
    position = start
    while position < len(line):
        character = line[position]
        if character in ('“', '"'):
            position = closing_quote(line, position)
            continue
        if character == "'":
            raise ValueError('MID call ends inside a comment')
        if character in OPEN:
            stack.append(character)
        elif character in OPEN.values():
            if not stack or OPEN[stack[-1]] != character:
                raise ValueError('Unbalanced EPL call')
            stack.pop()
            if not stack:
                output.append(line[start:position].strip())
                return output
        elif character == ',' and len(stack) == 1:
            output.append(line[start:position].strip())
            start = position + 1
        position += 1
    raise ValueError('MID call crosses a physical line')


def mid_calls(source):
    calls = []
    for number, line in enumerate(source.splitlines(), 1):
        position = 0
        while position < len(line):
            character = line[position]
            if character == "'":
                break
            if character in ('“', '"'):
                position = closing_quote(line, position)
                continue
            match = IDENTIFIER.match(line, position)
            if not match:
                position += 1
                continue
            name = match[0]
            opening = match.end()
            while opening < len(line) and line[opening].isspace():
                opening += 1
            if name.lower() in ('取文本中间', 'mid') and line[opening:opening + 1] == '(':
                calls.append((number, arguments(line, opening)))
            # Continue inside arguments as well: nested MID calls must be checked.
            position = match.end()
    return calls


def contract_violations(source):
    return [(line, values) for line, values in mid_calls(source)
            if len(values) != 3 or any(not value for value in values)]


class MidContractTests(unittest.TestCase):
    def test_all_three_arguments_are_required(self):
        for call in ['取文本中间 (文本, 2)', '取文本中间 (文本, 2, )',
                     '取文本中间 (, 2, 1)', '取文本中间 (文本, , 1)',
                     '取文本中间 (文本, 1, 2, 3)']:
            with self.subTest(call=call):
                self.assertEqual(len(contract_violations(call)), 1)

    def test_nested_calls_arrays_and_empty_text_literal(self):
        source = '相加 (取文本中间 (行[i], 相加 (长度 (键[i]), 2), 相减 (长度 (行[i]), 1)), 取文本中间 (“”, 1, 0))'
        self.assertEqual(len(mid_calls(source)), 2)
        self.assertEqual(contract_violations(source), [])

    def test_nested_mid_is_checked_separately(self):
        source = '取文本中间 (取文本中间 (文本, 1, ), 1, 1)'
        self.assertEqual(len(mid_calls(source)), 2)
        self.assertEqual(len(contract_violations(source)), 1)

    def test_comments_literals_and_longer_identifiers_are_ignored(self):
        source = '\n'.join(["' 取文本中间 (文本, 1, )",
                            '赋值 (提示, “取文本中间 (文本, 1, )”)',
                            '赋值 (提示, "取文本中间 (文本, 1, )")',
                            '自定义取文本中间 (文本, 1, )',
                            "取文本中间 (文本, 1, 0) ' 取文本中间 (文本, 2, )"])
        self.assertEqual(len(mid_calls(source)), 1)
        self.assertEqual(contract_violations(source), [])

    def test_english_alias_and_literal_delimiters(self):
        self.assertEqual(contract_violations('MID (“a,(b)”, 1, 2)'), [])
        self.assertEqual(len(contract_violations('mid (文本, 1, )')), 1)

    def test_unclosed_call_is_rejected(self):
        with self.assertRaises(ValueError):
            mid_calls('取文本中间 (文本, 1,')

    def test_all_actual_server_calls(self):
        paths = sorted(SERVER.rglob('*.e.txt'))
        self.assertTrue(paths)
        count = 0
        for path in paths:
            text = path.read_text(encoding='utf-8-sig')
            count += len(mid_calls(text))
            with self.subTest(file=path.name):
                self.assertEqual(contract_violations(text), [])
        self.assertGreater(count, 0)


if __name__ == '__main__':
    unittest.main()
