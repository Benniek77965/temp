#!/usr/bin/env python3
"""Check the real Black Moon signed-ID handoff to the server GUI callback.

Numeric expressions are extracted from production EPL and interpreted strictly.
This covers the dispatch contract, not Windows/EPL GUI execution.
"""
from pathlib import Path
import ast
import operator
import re
import unittest
from test_epl_mid_contract import arguments

EPL = Path(__file__).resolve().parents[4]
GUI = EPL / '服务端/服务端_电音基调/代码/机架联动管理界面.static.e.txt'
BLACK_MOON = EPL / '模块/黑月界面类3.9.0.e~/代码'


def section(source, name):
    start = re.search(r'^\.子程序 ' + re.escape(name) + r'(?=[,\s])[^\r\n]*', source, re.M)  # 名称要完全相同，只比前缀会取到更长的同前缀子程序
    if not start:
        raise AssertionError('Missing production procedure: ' + name)
    end = source.find('\n.子程序 ', start.end())
    return source[start.start():end if end >= 0 else len(source)]


def short_integer(value):
    value &= 65535
    return value - 65536 if value >= 32768 else value


def numeric(expression, values):
    functions = {'相减': operator.sub, '位与': operator.and_, '到短整数': short_integer}

    def visit(node):
        if isinstance(node, ast.Expression):
            return visit(node.body)
        if isinstance(node, ast.Constant) and type(node.value) is int:
            return node.value
        if isinstance(node, ast.Name) and node.id in values:
            return values[node.id]
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and not node.keywords:
            return functions[node.func.id](*(visit(argument) for argument in node.args))
        raise AssertionError('Unsupported numeric EPL expression: ' + ast.dump(node))
    return visit(ast.parse(expression, mode='eval'))


class ButtonDispatchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.gui = GUI.read_text(encoding='utf-8-sig')
        cls.create = section(cls.gui, '机架界面_创建')
        cls.callback = section(cls.gui, '机架界面_按钮被单击')
        helper = section((BLACK_MOON / '程序集_全局函数.static.e.txt').read_text(encoding='utf-8-sig'), '黑月取低16位')
        cls.helper_parameter = re.search(r'^\.参数 ([^,]+),', helper, re.M)[1]
        cls.helper_expression = re.search(r'^返回 \((.*)\)\s*$', helper, re.M)[1]
        cls.asserted_helper_header = helper.splitlines()[0]
        assignment = next(line for line in cls.callback.splitlines() if line.startswith('赋值 (局_任务,'))
        cls.task_expression = arguments(assignment, assignment.index('('))[1]
        cls.buttons = []
        for line in cls.create.splitlines():
            match = re.match(r'集_界面_按钮\[(\d+)\]\.创建\s*\(', line)
            if match:
                cls.buttons.append((int(match[1]), int(arguments(line, line.index('('))[4])))
        cls.count = max(index for index, _ in cls.buttons)   # 按钮数以生产代码为准（原 13 个，加了批量管理后 18 个）
        cls.launcher_upper = int(re.search(r'大于 \(参_任务, (\d+)\)', section(cls.gui, '机架界面_发起'))[1])

    def notification_id(self, control_id):
        return numeric(self.helper_expression, {self.helper_parameter: control_id})

    def task(self, callback_id):
        return numeric(self.task_expression, {'id': callback_id})

    def test_actual_framework_passes_signed_low_word_to_callback(self):
        self.assertIn('短整数型', self.asserted_helper_header)
        dispatcher = section((BLACK_MOON / '程序集_zyCtrol.static.e.txt').read_text(encoding='utf-8-sig'), 'zyCommand_ChildWndProc')
        self.assertIn('赋值 (id, 黑月取低16位 (wParam))', dispatcher)
        self.assertIn('zyCall (evtPtr, lParam, id,', dispatcher)
        for _, value in self.buttons:
            self.assertLess(self.notification_id(value), 0)

    def test_all_buttons_dispatch_from_actual_signed_ids(self):
        self.assertEqual(sorted(index for index, _ in self.buttons), list(range(1, self.count + 1)))
        self.assertGreaterEqual(self.count, 13)
        self.assertEqual(self.launcher_upper, self.count, '机架界面_发起 接受的任务上限要等于按钮数')
        for index, control_id in self.buttons:
            with self.subTest(button=index):
                self.assertEqual(self.task(self.notification_id(control_id)), index)
                self.assertIn('集_界面_按钮[%d].事件_被单击 (&机架界面_按钮被单击)' % index, self.create)

    def test_positive_callback_ids_remain_compatible(self):
        for index, control_id in self.buttons:
            self.assertEqual(self.task(control_id), index)

    def test_save_and_both_file_buttons_have_distinct_tasks(self):
        tasks = {index: self.task(self.notification_id(control_id)) for index, control_id in self.buttons}
        self.assertEqual((tasks[2], tasks[11], tasks[12]), (2, 11, 12))
        self.assertIn('等于 (局_任务, 11), 等于 (局_任务, 12)', self.callback)
        self.assertIn('局_对话框.打开 (集_界面_主句柄)', self.callback)
        self.assertIn('机架界面_发起 (局_任务,', self.callback)

    def test_startup_and_in_flight_guards_are_retained(self):
        before_dispatch = self.callback[:self.callback.index('赋值 (局_任务,')]
        for fragment in ('取反 (集_界面_已创建)', '取反 (集_界面_服务就绪)',
                         '集_界面_忙', '集_界面_关闭中'):
            self.assertIn(fragment, before_dispatch)
        for unknown in (0, 43100, 43101 + self.count, 65535):
            self.assertNotIn(self.task(self.notification_id(unknown)), range(1, self.count + 1))

    def test_checkbox_default_and_existing_policy_read_are_distinct(self):
        created = self.create.index('集_界面_策略启用.创建 (')
        checked = self.create.index('集_界面_策略启用.选中 (真)')
        self.assertLess(created, checked)
        recycle = section(self.gui, '机架界面_回收任务')
        self.assertIn('集_界面_策略启用.选中 (集_界面_结果启用)', recycle)
        self.assertNotIn('集_界面_策略启用.选中 (真)', recycle)


if __name__ == '__main__':
    unittest.main()
