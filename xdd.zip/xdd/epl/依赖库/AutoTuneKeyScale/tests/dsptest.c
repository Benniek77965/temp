#include <windows.h>
#include <stdio.h>
#include <math.h>
#include "vst2abi.h"
static double SR=44100; static int BLK=512;
static intptr_t VSTCB cb(AEffect*e,int32_t op,int32_t i,intptr_t v,void*p,float o){
  (void)e;(void)i;(void)v;(void)p;(void)o;
  if(op==audioMasterVersion)return 2400; if(op==audioMasterGetSampleRate)return (intptr_t)SR;
  if(op==audioMasterGetBlockSize)return BLK; if(op==audioMasterGetCurrentProcessLevel)return 2; return 0; }
static void pstr(AEffect*E,int op,int idx,char*b,int n){memset(b,0,n);E->dispatcher(E,op,idx,0,b,0);b[n-1]=0;}
static int findp(AEffect*E,const char*w){char nm[256];for(int i=0;i<E->numParams;i++){pstr(E,effGetParamName,i,nm,sizeof nm);if(!_stricmp(nm,w))return i;}return -1;}
/* autocorrelation pitch on mono float buffer */
static double pitch(float*buf,int n,double sr){
  int minlag=(int)(sr/400), maxlag=(int)(sr/150); double best=-1e30; int bl=0;
  for(int lag=minlag;lag<maxlag;lag++){ double c=0; for(int i=0;i+lag<n;i++)c+=(double)buf[i]*buf[i+lag]; if(c>best){best=c;bl=lag;} }
  return bl? sr/bl : 0; }
int main(int argc,char**argv){ setvbuf(stdout,0,_IONBF,0);
  printf("PID=%lu\n",(unsigned long)GetCurrentProcessId());
  const char* dll=argc>1?argv[1]:"C:\\vt32\\dianyin5.dll";
  double infreq=argc>2?atof(argv[2]):270.0;
  HMODULE h=LoadLibraryA(dll); if(!h){printf("LOAD FAIL %lu\n",GetLastError());return 1;}
  VstMainProc m=(VstMainProc)GetProcAddress(h,"VSTPluginMain"); if(!m)m=(VstMainProc)GetProcAddress(h,"main");
  AEffect*E=m(cb); E->dispatcher(E,effOpen,0,0,0,0); E->dispatcher(E,effSetSampleRate,0,0,0,(float)SR);
  E->dispatcher(E,effSetBlockSize,0,BLK,0,0); E->dispatcher(E,effMainsChanged,0,1,0,0); E->dispatcher(E,effStartProcess,0,0,0,0);
  /* set retune speed fast (0) if present, so correction is immediate */
  int rs=findp(E,"Retune Speed"); if(rs<0)rs=findp(E,"Speed"); if(rs>=0){E->setParameter(E,rs,0.0f);printf("retune idx=%d set 0\n",rs);}
  int nin=E->numInputs>0?E->numInputs:1, nout=E->numOutputs>0?E->numOutputs:1;
  float*ib[8],*ob[8]; for(int c=0;c<nin;c++)ib[c]=(float*)malloc(BLK*sizeof(float)); for(int c=0;c<nout;c++)ob[c]=(float*)malloc(BLK*sizeof(float));
  static float cap[44100]; /* ~1s capture */
  double ph=0, dph=2*M_PI*infreq/SR;
  /* file telling the harness which frequency we feed + ready for agent */
  printf("READY infreq=%.1f numParams=%d Key=%d Scale=%d\n",infreq,E->numParams,findp(E,"Key"),findp(E,"Scale"));
  /* wait for a trigger file to (re)measure: loop forever, each time 'measure.now' appears, process 2s + measure + write pitch.txt */
  for(int iter=0; iter<200; iter++){
    if(GetFileAttributesA("C:\\vt32\\measure.now")==INVALID_FILE_ATTRIBUTES){ Sleep(200); continue; }
    DeleteFileA("C:\\vt32\\measure.now");
    /* process ~1.5s to settle, capture last 1s */
    int capn=0; int total=(int)(SR*1.5/BLK);
    for(int b=0;b<total;b++){
      for(int s=0;s<BLK;s++){ float v=(float)(0.4*sin(ph)); ph+=dph; if(ph>2*M_PI)ph-=2*M_PI; for(int c=0;c<nin;c++)ib[c][s]=v; }
      if(E->processReplacing)E->processReplacing(E,ib,ob,BLK);
      if(b>=total-(int)(SR*1.0/BLK)){ for(int s=0;s<BLK && capn<44100;s++)cap[capn++]=ob[0][s]; }
    }
    double po=pitch(cap,capn,SR);
    FILE*pf=fopen("C:\\vt32\\pitch.txt","w"); if(pf){fprintf(pf,"%.1f\n",po);fclose(pf);}
    printf("iter=%d measured out pitch=%.1f Hz (in=%.1f)\n",iter,po,infreq);
  }
  return 0; }
