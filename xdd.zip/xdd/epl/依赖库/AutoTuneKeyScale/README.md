# Auto-Tune / 电音 / Waves Tune — 后台机架联动组件

> **这份文档给谁看**：想了解联动组件内部原理、排查机架问题、或改 C++ 源码的开发者。只想把功能部署起来的，看[新手部署教程](../../../docs/电音助手_机架联动部署教程.md)就够了，不必读本文。
>
> **本文讲什么**：支持哪些修音插件、各自能控制什么、崩溃和探测的排查、换 DAW 和 32 位桥接的原理、音阶同义词。开头几段先交代这套组件的几条前提。

当前为控制器 v5／传输协议 v3、agent build 1166。控制器已移除可见操作界面、按钮、菜单及托盘；后台 IPC 仍保留，用于主程序与控制器通信。`--show` 和旧“打开控制器”入口不再显示窗口。

日常使用由电音助手提供界面：登录主程序，在“机架联动”菜单启用“自动切换”，由主程序取得有效服务端授权并启动内部组件。取消自动切换会暂停自动写入，保留已经建立的机架连接和正常授权续期；重新开启后，同一机架可继续使用。未建立连接时的关闭状态不会主动连接。退出、撤回同意和授权失效仍按各自规则停用。

托管内部组件 `keyscale_rack_controller.exe`（只 64 位；纯 32 位 Windows 不再支持。旧的 `keyscale_rack_controller32.exe` 以及更早的 `机架联动内部组件(32).exe`、`xhh_rack_controller(32).exe` 会被新版桥按完整文件名清理；桥本身之前叫 `机架联动内部桥.dll`、`xhh_rack_bridge.dll`，由主程序按内容核对后清理） 不能靠双击获得授权。须持有真实服务器短期签名令牌，才允许进入扫描、注入及参数写入流程。只构建托管版（编译时定义 `AT_XHH_MANAGED=1`），不再提供独立版控制器和代理。

本包公钥与 `companion_public_key.h` 配套，服务端保管对应 PEM，使用 EPL＋MySQL 授权。允许 HTTP 直连或已有 HTTPS 入口（授权请求经协议v3信封加密，HTTP 直连也不暴露登录凭据）；服务端窗口完成配置并重启，缺配置不能靠复制 PEM 代替。服务端设备名额满时，当前有效新登录可自动接替旧设备；“开放比例”100表示全量开放，0表示全部暂不放行。

新控制器含与 EPL `SP_Begin_1` 相同的 15 字节标识，放在低频授权验证路径。标识不等于已经执行 VMP 保护，不等于 VMProtect 的归属水印，也不等于数字签名；正式保护和签名见构建说明。

- [新手部署教程](../../../docs/电音助手_机架联动部署教程.md)：升级、账号、自动换机、开放比例及排查。
- [构建与签名／VMP步骤](scripts/README.md)：直接用预编译组件时无需重复编译 C++；自行保护或签名内层文件时要重新嵌入、生成云端下载包并编译主程序。
- [伴随协议](docs/伴随协议.md) · [EPL服务部署](server/部署与协议.md) · [真实环境验收（部署教程第 3.2 节）](../../../docs/电音助手_机架联动部署教程.md)。

Windows 7 及以上；32位系统运行32位内部组件，64位系统使用64位内部组件，同时可处理32位桥接机架。组件需要注入受支持机架，部署时应核对安全软件的实际拦截记录；代码签名不能保证不会被拦截。联动设置位于 `HKCU\SOFTWARE\DianYinAssistant\RackLink`，与当前宿主项目标识分离。

主程序配置目录中的 `log\log.txt` 可搜索“机架联动：授权诊断：”，用于区分服务端拒绝、令牌验证和内部组件通信问题。不得把编译通过等同于 Windows／音频／真实账号验证通过；本包未代替你的真实机架验收。

# 支持的插件

标注说明：以下“已验证”均指原包历史真机日志（build 1162及以前），不是当前1166的真机认证；当前版本必须按部署教程第 3.2 节“在真实 Windows 和机架上验收”重新测试。**应可用** = 原机制相同但缺该版本日志。

## Antares / 电音系列

| 插件 | 接口 | 验证程度 | 音阶来源 |
|---|---|---|---|
| AT4 / 电音4 | VST2 | 应可用(见下方提示) | 内置 29 项表 |
| AT5 / 电音5(5.0.9) | VST2 | **已验证** | 内置 29 项表 |
| 电音6 Evo(6.0.9) | VST2 | **已验证** | 内置 29 项表 |
| AT8.1 | VST3 | **已验证**(32 位宿主) | 从插件读取 |
| 电音9(Pro 9.1) | VST3 | **已验证** | 从插件读取 |
| 电音X10 | VST3 | **已验证** | 从插件读取 |
| **电音11(Pro 11)** | VST3 | **已验证**(182 个参数全表) | 经典 29 项 + **Modern Scale 15 项** |

> **「电音11」指的是哪个文件?** 文档里沿用了中文圈的叫法,指的就是 **Antares Auto-Tune Pro**
> 这个产品。对本程序来说,**怎么处理只取决于文件名**,和产品本身无关。
>
> **1149 起所有 Antares 的 VST3 都在实例创建时捕获,从不探测**(日志里该模块那一行带
> `[catch-mode: factory hook, no heap scan]`;此前的 `vtable acquired` 不会再出现)。区别只在**第一个实例能不能当场抓到**——这取决于文件名是否在已验证的放行名单里:
>
> | 文件名 | 第一个实例 | 日志里看什么 |
> |---|---|---|
> | `Auto-Tune Pro.vst3`(原厂命名) | **当场抓到** | `catch-mode`,并有 `EAT hook armed` |
> | `Auto-Tune.vst3`(1150 起) | **当场抓到** | 同上 |
> | `Auto-Tune_81.vst3`、改名重打包的 `电音11.vst3` 等 | 每次启动机架后**可能抓不到**,移除再重加一次即可 | `catch-mode`,并有 `hooking factory NOW` |
> | 名字里既不含 `auto-tune` 也不含 `11.vst3` 的改名版 | 同上,且要等后台扫描认出它(约一两秒) | `Antares module (PACE-protected) -> factory hook only, never probed` |
>
> 排查时看日志里有没有 `EAT hook armed`,就知道第一个实例能不能当场抓到,不要凭产品名去猜。

> ⚠ **AT4 的提示**:VST2 读不到档位名,只能用内置的 29 项音阶表。该表的顺序在
> **AT5.0.9 / Evo6.0.9 / AT8** 上确认一致,**但 AT4 没有验证过**。若你用 AT4 且发现切音阶
> 对不上,把现象告诉我即可修正。Key(12 个根音)不受影响。

> **实测:Pro 系列的 Modern 模式复用同一个 `Scale` 参数。** AT8.1 / 电音9 / 电音X10 三者的
> 参数布局完全一致(`Scale` id=1 共 29 档、`Key` id=2 共 12 档),日志里从未出现独立的
> `Modern Scale`;插件切到 Modern 后,写 `Scale`(id=1) 依然让界面和声音跟着变。
> 只有**电音11**那份 182 参数的表才另有 `Modern Scale`(id=162)。
>
> **Antares 走 catch 模式(Auto-Tune Pro 自 1105,1149 起所有版本)。** 探测式发现会让 PACE 反击——真机上同一个
> `Auto-Tune Pro.vst3` 崩过一次、卡死过一次。现在它内置走工厂钩子这条不探测的路,
> 并装 EAT 钩子(第一个实例就抓到,无需重加);但**不**碰它的 controller vtable,
> 实测也不需要——没有 handler 钩子,Key/Scale 写入照样生效。

**电音11 实测参数**:`Scale`(id 1,29 档)、`Key`(id 2,12 档)、`Modern Scale`(id 162,15 档)、
`Retune Speed`(id 4)、`Humanize`(id 61)、`Natural Vibrato`(id 62)、`Input Type`(id 10)。

Pro 系列实际生效的是 **Modern Scale** 那 15 项:Chromatic / Major / Minor / Harmonic Minor /
Jazz Melodic Minor / Dorian / Phrygian / Lydian / Mixolydian / Locrian / Major Pentatonic /
Minor Pentatonic / Blues / Whole Tone / Diminished。

## Waves 系列

Waves 插件都跑在 **WaveShell** 壳里。控制器按壳文件名识别,**与版本无关**:

| 版本 | VST3 壳 | VST2 壳 | 位数 | 验证程度 |
|---|---|---|---|---|
| **13.0** | `WaveShell1-VST3 13.0_x64.vst3` | 未提供 | 仅 64 位 | **已验证**(用户真机测试通过) |
| **17.1** | `WaveShell1-VST3 17.1_x64.vst3` | —(V15 起取消) | 仅 64 位 | **已验证**(真机全链路,Mono/Stereo 多实例) |
| **16.7** | `WaveShell1-VST3 16.7_x64.vst3` | —(V15 起取消) | 仅 64 位 | **已验证**(真机全链路跑通) |
| **14.19** | `WaveShell1-VST3 14.19_x64.vst3` | `WaveShell1-VST 14.19_x64.dll` | 仅 64 位 | 应可用(同一机制) |
| **12.7** | `WaveShell1-VST3 12.7_x64.vst3` | `WaveShell1-VST 12.7_x64.dll` | 仅 64 位 | 应可用(同一机制) |
| **11.0** | `WaveShell1-VST3 11.0_x64.vst3` | — | 仅 64 位 | **VST3 已验证** |
| **10.0** | `WaveShell3-VST3 10.0.vst3` | `WaveShell3-VST 10.0.dll` | 32 / 64 位 | 应可用(同一机制) |
| **9.6 / 9.7** | `WaveShell-VST3 9.x.vst3` | `WaveShell-VST 9.x.dll` | 32 / 64 位 | **VST2 已验证**(9.6 的 x64 与 x86) |

> **Studio One 下的写入(1144 起)**:VST3 要求 `beginEdit/performEdit/endEdit` 从**宿主的界面线程**发出。
> 多数机架不计较,Studio One 会收下然后静默丢弃 —— 1143 及以前在 Studio One 里的表现是**能读、界面和声音都不动**。
> 1144 起写入改由宿主界面线程执行。真机验证:13.0 在 Studio One 下 12 条命令、24 次写入全部落地,**界面跟随**
> (声音当时未能测试)。同一个壳在 Samplitude 下 1143 即已正常。
>
> **验证范围**:这个改动不只作用于 Waves + Studio One。凡是抓到了宿主 handler 的插件(Waves、The T-Pain Effect),
> 在**所有**机架里写入都改走界面线程;Antares 不挂 handler,写法与 1143 相同。
> 1145 真机验证(用户确认正常):Studio One 与 Samplitude 下的 Waves Tune Real-Time 与 The T-Pain Effect(VST3)。
> 日志显示两个机架里 handler 所在线程与子类化窗口所在线程是同一个,8 条命令全部落地,没有任何退回 worker 的记录。
> 同一会话里的 VST2 实例(Waves VST2 壳、T-Pain VST2)走的是不受此改动影响的 VST2 路径,同样正常。
> 若真机上任何一个比 1143 差,可在数据目录建立 `nouithread.txt` 以测试兼容 worker 路径，重启机架后生效；这是兼容排查选项，当前没有高级设置窗口。
>
> **LiveProfessor 2(1146 起)**:它在插入插件前会先创建、再销毁同一插件的实例(探测用)。1145 及以前,agent 会一直留着这些
> 已被销毁的实例 —— 控制器列表里多出幽灵条目,每次应用都往这些已销毁的对象里写**错误的值**,还占着实例表的槽位。
> 1146 起,没有宿主 handler 的 Waves 实例不再列出、不再写入,并在下一轮扫描时被识别为探测实例而丢弃。
> 另外,LiveProfessor 必须在 Audio & MIDI Options 里选好输出与输入设备,Waves VST3 才写得动(见下文"能读但写不动")。

### iZotope The T-Pain Effect

真机已验证参数布局(30 个参数):`Scale` id=18(6 档)、`Root note` id=19(12 个根音)、
`Snap to scale` id=3、`Hardness` id=0、12 个 `X Enabled` id=5..16。

两点与 Waves/电音11 不同:

- 它是 `.dll` 却导出 VST3 工厂,**1093 起**才纳入识别(原先被 Antares 关键字筛选跳过)
- 它的 processor 与 controller 是**两个独立对象**(cid `ZTSV...` / `ZESV...`),
  因此写参数**必须经宿主的 `IComponentHandler`**,否则只有读回变化、声音不动。**1094 起**已挂上

> 界面上的 SCALE 下拉与那 12 个琴键是联动的:选某个音阶等于按模板开关琴键,手动点琴键则变 `Custom`。

**VST2 版**(`The T-Pain Effect.dll`)自 **1095** 起也可控。VST2 无法枚举离散取值,
所以和 Waves 一样借用位置表(12 根音 / 6 音阶,取自 VST3 真机枚举),每次写入都读回校验。
两种格式写出的数值完全一致(如 `Major`→0.2000、`G`→0.6364)。

> **32 位已真机验证**:在 32 位桥接宿主里挂 `32\The T-Pain Effect.dll`,EAT 跳板的 x86 机器码
> (`push / call [slot] / add esp,4 / ret`)被 CPU 实际执行,栈平衡、工厂挂钩成功、Key/Scale 写入生效。

> **1099 起**它的 VST3 版也装 EAT 钩子,第一个实例就能抓到(此前要移除重加一次)。
> 它的 VST2 版**不提供** `effGetParamDisplay` 文本(Auto-Tune 4/5 也一样)。
> **1097** 起改为读回数值再反查位置表,所以仍可回读 Key/Scale，写入校验也不再被跳过。

> 插件 STYLE 参数(名为 `Hardness`)**两种格式都未映射**到 Retune 控制参数:
> 它的方向与 Auto-Tune 相反(Auto-Tune 的 0 = 最硬,T-Pain 的 0 = 最软),
> 直接映射会使同一控制值在不同插件上含义相反；当前保持不映射。

> **壳的命名每个版本都不一样**:9.x 没有数字、10.0 是 `WaveShell3-`、11.0 / 12.7 / 13.0 / 14.19 / 16.7 / 17.1 是 `WaveShell1-`
> (11.0 同一安装里还有 `WaveShell2-`)。识别只看名字里有没有 `waveshell`,所以**新版本不用改代码**。
> 迄今见过的 22 个壳文件都由回归测试 `t_shells` 逐一核对。

> **从 11 起 Waves 只提供 64 位壳**(你给的 11.0 / 12.7 / 14.19 / 16.7 都只有 `_x64`,用户反馈也一致)。
> 所以 **32 位机架用不了 Waves 11 及以后的版本**——这是 Waves 自身的限制,不是本程序的。需要 32 位就用 10.0 或更早。

> **从 V15 起 Waves 不再提供 VST2 壳**,只有 VST3(Waves 官方支持页已声明不再支持 VST2;
> 你给的 14.19 还带 VST2 壳,16.7 已经没有,对得上)。所以用 Waves 15 及以后的版本,**必须加载 VST3**。

> **10.0 / 12.7 / 14.19 / 16.7 的参数布局是推断**:9.6 的 VST2 与 11.0 的 VST3 那 12 个参数**逐项一致**,
> 夹在中间和之后的版本大概率相同,但没有它们的真机日志。

壳里的具体产品:

| 产品 | 代码 | 能否控制 |
|---|---|---|
| **Waves Tune Real-Time**(Mono/Stereo) | `LVw` | **✓ 已验证**,这是主角 |
| Waves Tune(Mono/Stereo) | `GNw` | 识别得到;但它是**离线图形修音**(类似 Melodyne),Key/Scale 未必作为可自动化参数暴露 |
| Waves Tune LT | 未知 | 同上 |
| SoundShifter Pitch | `RSs` | 识别得到,**不是调音器**,自动忽略 |

**Waves Tune Real-Time 实测参数**:`Speed`(0)、`Note Transition`(1)、`Link On/Off`(2)、
`Correction`(3)、`Correction On/Off`(4)、`Reference Frequencey`(5,Waves 自己拼错的)、
`Tolerance Time`(6)、`Tolerance Cents`(7)、`Vibrato Depth`(8)、`Vibrato On/Off`(9)、
`Scale Type`(10,**44 个音阶**)、`Scale Root`(11,**17 档**,含 C#/Db 这类等音)。

> **9.6 的 VST2 与 11.0 的 VST3 参数表逐项一致**(12 个参数,名字和索引全同)。
> 这也是 VST2 能借用 VST3 位置表的依据——而且每次写入都会读回校验。

## 各插件能控什么

| 控件 | Antares / 电音 | Waves Tune Real-Time |
|---|---|---|
| Key(12 根音) | ✓ | ✓ |
| Scale | ✓ | ✓ |
| Retune/Speed | ✓ Retune Speed | ✓ Speed |
| Human/Trans | ✓ Humanize | ✓ Note Transition |
| NatVib/VibDep | ✓ Natural Vibrato | ✓ Vibrato Depth |
| Audio Type(声部) | ✓ | ✗ **Waves 没有这个参数** |
| Range(Bass/Tenor/…) | — | ✗ **不对宿主暴露,无法远程控制** |

表中列的是插件底层能力；无界面的控制器不再提供这些滑块或下拉框，电音助手只使用其已接入的参数接口。

---

# 后台使用与数据位置

正常登录主程序并启用自动切换后，再启动机架、加载受支持插件。控制器本身没有操作窗口，状态由电音助手和日志提供。启用／暂停按钮由主程序负责；不应直接双击内部组件来排查授权。

数据目录优先为 `%LOCALAPPDATA%\AutoTune_KeyScale`，失败时回退到 `%TEMP%\at8`。实际目录可查看 `%TEMP%\at8_commdir.txt`。机架中的 agent 也使用这一位置；运行期间不要手工清空其中的通信文件。

升级时退出旧主程序、控制器及机架，再使用同一套新版组件。已经加载的 agent 映像保留到机架进程退出；更换磁盘文件不会替换机架里正在运行的旧映像。旧版本迁移逻辑只处理能够识别为本程序的文件，不能用手工清空目录代替迁移。

## 机架闪退时

**1148 起,机架崩溃时 `agent.log` 会留下一行 `CRASH:`**,例如:

```
[17476] +73.512 CRASH: exception 0xC0000005 at ... = 某插件.vst3+0x1A2B3 (reading 0000000000000010) on a host thread (thread 10712);
agent code on that thread's stack: 2 value(s) (the agent was on the call path); host threads inside agent hooks: 1; worker guard: 0
```

- **`= 模块名+偏移`** —— 崩在哪个模块里。`-- INSIDE THE AGENT` 表示崩在 agent 自己的代码里
- **`agent was on the call path`** —— 崩溃线程的调用链上有 agent(例如 agent 的钩子正在调用插件时插件崩了);
  `not on the call path` 表示与 agent 的调用无关
- **`only the agent's window-subclass pass-through: the agent was idle on this thread`**(1159 起)—— 崩在 agent 子类化过的
  宿主界面线程上,但当时 agent 什么也没在做:栈上那些 agent 的地址只是它转发窗口消息时留下的。**与 agent 无关**,和 `not on the call path` 同样看待
- **`worker was probing ...`** —— 崩溃时 agent 正在探测这个模块;下次启动断路器会自动把它转到安全路径
- 每行开头的 `+73.512` 是机架启动后的秒数(1148 起每行都有),可以看出崩溃前最后几件事隔了多久

**有些崩溃不会留下这一行**:堆损坏等"快速失败"会绕过所有异常处理。这时请看 Windows 自己的记录:
**事件查看器 → Windows 日志 → 应用程序**,找来源为 `Application Error`、应用程序名为机架 exe 的那条,
把"错误模块名称""异常代码""错误偏移量"三项连同 `agent.log` 一起发来。

另外,数据文件夹里若留有 `pending_<进程号>.txt`(1162 起只在探测期间存在,平时没有),说明崩溃时 agent 正在探测那个模块。

## 插件探测导致崩溃或卡死时

VST3 插件早先的发现方式是先实例化一个一次性探针拿到 vtable,再对内存里"看起来像"该 vtable 的地址调方法。
**对 PACE 保护的插件,这种试探本身就有风险**——实测遇到过崩溃、整窗口卡死
(同一个 Auto-Tune Pro,同一台机器,前后两次表现还不一样),1149 又在 MonsterApplication 里遇到一次。
**1149 起已没有任何 VST3 模块走这条探测路径**:能被控制的 VST3(Waves、T-Pain、Antares,以及通过 `catch.txt` 明确加入的)全部在实例创建时捕获。
本节余下的内容是这条路径的历史与兜底机制。VST2 仍按内存里的 AEffect 发现,不受影响。

**自 1105 起这件事会自动处理,不需要你做任何配置。**

- **1149 起,所有 Antares 的 Auto-Tune(各个版本)都从一开始就走不探测的安全路径。**
  此前内置名单里只有 `auto-tune pro.vst3`,这句话对其它版本并不成立:Auto-Tune 9(`Auto-Tune.vst3`)、
  8.1(`Auto-Tune_81.vst3`)等都会被探测。实测在 MonsterApplication 里一次添加多个版本时闪退 ——
  断路器标记里是 `Antares\Auto-Tune.vst3`,Windows 记下的异常是 `0xC000001D`(非法指令),出错地址不属于任何模块,
  正是 PACE 解密后的代码所在的那种内存。按文件内容认出的 Antares 模块(例如改了名的"电音"版本)同样不再探测。
  **代价**:安全路径要在实例被创建的那一刻抓住它。能保证抓住**第一个**实例的做法(改写插件的 `GetPluginFactory` 导出)
  只对有真机证据的版本启用:Auto-Tune Pro,以及 **1150 起的 Auto-Tune 9(`Auto-Tune.vst3`)**。
  其它版本(如 8.1)在**每次启动机架后的第一个实例可能抓不到**,捕获状态可能仍为空;
  移除再重加一次即可,之后添加的都能抓到。8.1 等版本若想也免去这一步,请在机架里加一次它,把 `agent.log` 发来作为证据
- 万一别的插件也扛不住探测:断路器会记下"那个进程是在探测它的时候死的",
  **下次启动自动把它转到 catch 模式**(而不是像 1104 之前那样把插件永久禁用)。
  也就是说,任何插件最多经历一次意外,之后自己就走安全路径了

> 旧版会把出事的模块写进 `disabled.txt` 并**永久跳过**——表现为那个插件不再被捕获,
> 只能手动删文件才能恢复。现在同一个文件仍被读取,但含义变成"这个模块改用工厂钩子",
> 插件继续可用。

**什么时候仍需要手动介入:** 如果某个插件探测时**卡死**(不是崩溃),你得先强制结束宿主进程——
进程死了,下次启动断路器才能认出来并自动转安全路径。

## 换新 DAW 不需要配置

控制器按进程注入,所以它得先认出哪个进程是宿主。三条判定,从强到弱:

1. 进程里**已加载调音插件** —— 最强证据,同时把该 exe 名**自动学进** `dawhost.txt`
2. exe 名在 `dawhost.txt` 里 —— 下次该 DAW 一启动就预先注入
3. 进程**结构上就是个插件宿主**(加载过 `.vst3` 文件,或 `VST3` / `VstPlugins` 目录下的模块)

第 3 条自 **1107** 起加入,作用是让**从没见过的 DAW 在第一次使用时就不用重加**:
该 DAW 一加载任何插件,agent 就已经进去了,等你挂上调音插件时钩子早已就位。

> 这条判定是**严格**的:只认 `.vst3` 扩展名、`\VstPlugins\`、`\VST3\`。
> 宽松地只查 `\vst` 子串会把 Office 的 VSTO 运行时(`...\Microsoft Shared\VSTO\`)当成宿主,
> Outlook、Excel 就会被注入——那正是这套过滤要挡住的东西。

## 32 位插件(桥接)

64 位宿主加载 32 位插件时,插件实际跑在**桥接进程**里,所以 agent 必须进那个进程。

**自 1106 起这件事全自动,不需要配置。** 判定不靠进程名——桥接名每个宿主都不一样
(`VSTBridge32_V300.exe` / `psrv.exe` / `plugin-host.exe` …),没有名单能穷举——
而是靠**父子关系**:桥接是宿主拉起的子进程,这是所有桥接共有、而无关程序绝不具备的性质。

> 这条规则天然排除了 QQ、微信这类进程:它们不是任何 DAW 的子进程。
> 另有两道防护:子进程必须**晚于**父进程出生(防 PID 回收误判),
> `\Windows\` 下的进程一律跳过(conhost / WerFault 是所有人的子进程)。
> 多级也支持(宿主 → 桥接管理器 → 桥接)。

## 加载顺序与暂停

VST3 需要在实例创建时捕获，特别是 Waves 的参数写入还需要当时提供的 `IComponentHandler`。先运行主程序并取得联动授权，再打开机架；若错过捕获时机，保持主程序联动开启，关闭并重新打开机架。

Waves、T-Pain 以及放行名单内的 Antares 可在 `GetPluginFactory` 导出重定向就绪后捕获首个实例；日志 `EAT hook armed on GetPluginFactory` 是相应证据。这仍要求 agent 在插件创建前到达机架；不能保证任意加载顺序都能事后补抓。`factory hooked late` 表示 agent 到达晚于机架启动。

已成功连接后关闭“自动切换”只是暂停，保持授权续期与必要的插件生命周期观察。重新开启时恢复对仍有效实例的控制，不应要求重开机架。升级 agent、插件未捕获、机架进程已退出及授权失效属于另外的情况。

暂停／停用不等于从正在运行的机架物理卸载 DLL。agent 映像由系统在机架退出时释放，保留必要观察是为了恢复时不使用已经销毁的插件对象。

# 统一切换:不同插件的音阶名不一样

不同插件对**同一个音阶**叫法不同:

| | 自然小调 | 爵士旋律小调 |
|---|---|---|
| 电音11(Modern Scale) | `Minor` | `Jazz Melodic Minor` |
| Waves Tune | `Natural Minor` | `Melodic Minor (Asc)` |

控制器带**同义词表**:选一次,两边都正确生效。实测两份真机清单(电音11 的 15 项、Waves 的 44 项),
**15 个里有 14 个可以一次切到位**。

底层音阶匹配仍按插件实际清单和同义词判断；电音助手通常使用 Major、Minor、Chromatic。无界面控制器不再提供 Target 或 Scale 下拉框；表中的历史多插件能力不能理解为现在仍有手动控件。

## 音阶同义词 — 可自己加

需要自定义时，编辑数据目录里的 `scalemap.txt`。格式为每行一组，第一项为规范名；默认内置组一般已足够，不必为正常联动手工修改。

```
Minor|Natural Minor|Aeolian
```

内置且始终生效的三组:`Minor|Natural Minor|Aeolian`、`Major|Ionian`、
`Jazz Melodic Minor|Melodic Minor (Asc)|Jazz Minor|Melodic Minor`。文件里写的是**追加**。

**故意没有启用**的一条:电音11 的 `Diminished` 没说明是 W-H 还是 H-W 那一种八声音阶,
猜错会选到不同音集,所以没有内置;你真机 A/B 确认后,自己加一行 `Diminished|Diminished (W-H)`(或 H-W)即可。

## 电音助手的核心接口

主流歌曲实际只用 **12 根音 × 大/小调**,电音再加一个 `Chromatic`。所以助手的核心契约定成
`key=0..11` + `scale=Major|Minor|Chromatic` 就够——**这三个在电音11 和 Waves 上都是一次切到位**。
Dorian、五声、Maqam 这些当作"各插件额外能力",不进核心契约。

---

# 排查

## 确认版本和错误来源

从本次构建清单、主程序诊断和 `agent.log` 启动行核对实际版本。控制器不再显示窗口标题或状态栏。当前源码要求 controller5／协议3／XAT3／agent1166 配套；已载入旧 agent 的机架需要退出后再启动。

每进程连续注入失败 3 次后停止重试，重开机架后可重新尝试。

内部组件释放 agent／注入器时校验实际字节。目录不可写或旧文件被占用等问题不能通过继续加载错误版本来解决。查看主程序固定授权诊断字段，区分 HTTP 拒绝、令牌验证、控制器通信和实际插件捕获；详细排查见部署教程。

## 插件未捕获

1. 确认加载顺序：主程序已授权并保持联动，再重新打开机架，让插件在 agent 就绪后创建
2. 打开实际数据目录中的 `agent.log`，检查是否有:
   ```
   catch-mode factory CONFIRMED hooked after N tries: ...   ← 工厂挂钩成功(前提)
   CAUGHT genuine controller @ ...
   captured host IComponentHandler ...          ← Waves 需要这行
   disc(Waves): isTuner=1 | Root id=.. | Scale id=..
   ```
   若只看到 `GetPluginFactory() not ready yet ... will retry`,说明壳还没把工厂交出来,
   agent 会每轮扫描重试(最多 40 次);**等几秒**再看有没有 `CONFIRMED hooked`。
   出现 `CONFIRMED hooked` 后仍无捕获时，保持主程序运行并重开机架，再核对实际回读。
3. 日志每行带进程号 `[pid]`。32 位插件跑在机架的桥接进程里(如 `VSTBridge32_V300.exe`),
   和机架**共用同一个日志文件**,靠这个前缀区分

> 反馈问题时请附上 `agent.log`,并说明:机架名称与版本、插件名称与版本,
> 以及**先开的是控制器还是机架**(加载顺序直接决定 VST3 能不能被抓到)。

## 能读但写不动(界面、声音不跟)

电音助手已确认捕获插件，能读出 Key/Scale，但参数没有跟随。

**先确认机架的音频引擎在运转** —— 这一条在日志里看不出来,日志会显示一切正常。VST3 插件的写入,
要由机架在处理音频时(`process()`)交给插件的处理部分才会生效;机架没在处理音频,写入就永远到不了。
Studio One、Samplitude 的音频引擎始终在跑,不会遇到;**LiveProfessor 2 这类要在 Audio & MIDI Options 里手动选设备的机架**,
输出/输入是 `<< none >>` 时就一个插件都不处理。实测:LiveProfessor 未选设备时 Waves VST3 写不动,选好输出与输入后正常。
所选设备被拔掉(例如 USB 耳机)时,机架也可能退回到 `<< none >>`。

为什么偏偏是 Waves VST3 露馅:Waves 的界面显示的是处理部分的状态,机架不处理,界面就不动;
多数插件的界面显示的是控制部分的值,机架不处理也照样会动(但声音其实同样没变)。VST2 的写入直接进插件,不受影响。

音频引擎确认在跑之后仍不跟,再在 `agent.log` 里找这几行:

```
captured host IComponentHandler ... on host thread N     ← Waves / T-Pain 必须有
UI-thread writes: subclassed window ... on host UI thread N   ← 第一次写入时出现(1144 起)
```

- **没有 `captured host IComponentHandler`** → Waves／T-Pain缺少宿主绑定，参数写入会保守跳过。移除再重加插件
- **有 `captured`,没有 `subclassed window`** → 写入没走宿主界面线程。看紧挨着的那一行说明原因(会逐次重复的原因每分钟至多记一行,并注明期间省略了几次):
  `nouithread.txt present`(数据目录存在 `nouithread.txt`，已启用兼容 worker 路径)、`owns no window`、`could not subclass`（窗口所属线程安装不可用或握手未及时完成）、`PostMessage failed`。
  在 Studio One 里这就等于 1143 的老毛病
- **出现 `did not pump within ... marshalling pauses for ... ms`** → 那一刻宿主界面线程正忙(加载工程、扫描插件),
  这一次尝试worker回退；已有参数事务仍在执行时跳过并记录busy，避免并发。10秒后重新尝试UI通路，空闲后再观察后续联动及回读。
  (宿主恰好在写入排队时销毁重建了窗口,**不算**线程忙:会自动换窗口重投一次,不会进入这 10 秒退让)
- **出现 `replaced its window twice while a write was queued`** → 写入排队期间宿主连续两次重建窗口,这一次尝试worker回退；已有事务在执行时跳过，待实际回读或重试确认
- **出现 `HWND epoch cannot be confirmed`** → 不能确认当前窗口仍是原来的窗口对象，保留原转发身份并拒绝复用，沿用既有worker回退。附日志反馈；必要时重启机架
- **出现 `host CLEARED the IComponentHandler`,而你并没有移除插件或关闭工程** → 宿主中途丢掉了 handler,请附日志反馈
- **以上都正常、音频引擎也确认在跑,仍然不跟** → 附上 `agent.log` 反馈

## 找不到机架、版本不一致

主程序、控制器和机架应使用同一 Windows 用户，并核对实际权限。机架以管理员权限运行而控制链未提升时，普通进程可能无法读取或操作该机架；不能靠更改提示文字绕过系统权限。

更新后运行同一套组件，并退出旧主程序和机架以释放旧映像。不要把新主程序和旧控制器混搭，也不要为了“只留一个文件”删除机架正使用的组件。机架为 VST3 创建的 VST2 包装对象布局未知时，控制器继续忽略这类包装，避免误改参数。

---

# 高级配置文件

控制器已移除高级设置窗口。下面保留 agent 兼容配置的技术说明；正常联动无需改这些文件。按实际数据目录编辑，确认内容后重启机架，以便 agent 重新读取启动配置；不要清空整个通信目录。

| 配置用途 | 文件 | 作用 |
|---|---|---|
| 不处理 Waves 插件 | `skip.txt` 里的一行 `waveshell` | 完全停用 Waves 相关逻辑(不影响 Antares)。**1155 起才真正"完全"**:此前只对后台扫描生效,模块载入时挂上的钩子照装不误 |
| 专家选项:不改写插件的导出表 | `noeat.txt`(存在即生效) | 关闭**所有**导出重定向——Waves、T-Pain、Auto-Tune Pro、Auto-Tune 9(1150 起)——退回迟挂钩方式:这些插件每次启动机架后的第一个实例需要"移除再重加" |
| 专家选项:参数写入不走机架的界面线程 | `nouithread.txt`(存在即生效) | 关闭 1144 起的"参数写入走宿主界面线程"(退回 1143 的 worker 线程写入)。只有在某个机架不接受窗口子类化时才需要 |
| 忽略的模块 | `skip.txt` | 忽略某个模块(按路径片段,每行一个,最多 16 行) |
| 额外捕获的 VST3 | `catch.txt` | 额外要在实例创建时捕获的 VST3 模块名片段(每行一个,最多 8 行)。内置已含 `auto-tune` / `11.vst3` / `waveshell` / `t-pain`,一般无需填写。名字里不含这些片段的改名版 Antares 会按文件内容自动认出,但要等后台扫描(约一两秒);写进这里则在模块载入的那一刻就挂上工厂钩子 |
| 音阶同义词 | `scalemap.txt` | 见上文"音阶同义词" |

数据文件夹里另有两个自动维护的文件,一般无需理会:`dawhost.txt`(内置常见机架名 + 自动学习你的机架;容量为96行，排查时应结合实际日志核对)、
`use_factory_hook.txt`(某个模块在探测时出过事才会出现,见"插件探测导致崩溃或卡死时")。

---

# 源码与构建

- `combined/at_agent.cpp` 与 ABI 头：机架内的 agent，当前 build 1166。
- `vst3/cpp/AutoTune_KeyScale_Controller.cpp` 与资源文件：无可见界面的控制器，保留后台通信、授权和机架管理。
- `vst3/cpp/keyscale_rack_bridge.cpp` 与资源文件：主程序调用的桥，内含两个托管控制器。
- `scripts/build_reproducible.py`：完整双架构构建及资源链检查；发布使用这一入口，具体命令见 [scripts/README.md](scripts/README.md)。
- `windows_build/`：在 Windows 上双击 bat 一个个编译（`0_build_all.bat` 依次编注入器、代理、控制器、桥并生成云端下载包，`6_check.bat` 检查每一层是否一致），用法见 [scripts/README.md](scripts/README.md) 第 5 节。
- `tests/scale_synonym/`、`tests/security/`、`tests/integration/`：相应源码回归及真实进程测试；运行结果需区分平台边界，不能沿用旧界面测试来证明无界面流程。

agent、控制器、桥和签名的云端下载包必须一致（主程序只认 服务端_电音基调 私钥签名过的桥）。改变内层文件、公钥、保护或签名后，按由内到外的顺序重新生成外层产物。插件侧技术细节见 `插件技术说明.md`。
