#!/usr/bin/env python3
# 回归核对：两次 xftest 截图目录逐像素比较（4 个通道逐字节比，不比 PNG 文件本身）。
# 用法：python3 tools/compare_shots.py <改前截图目录> <改后截图目录> [要跳过的文件名前缀 ...]
# 注意：不要用 PIL 的 ImageChops.difference(a, b).getbbox() 判断——RGBA 图上 getbbox 只看透明度通道，颜色变了也报“相同”；
# 也不要直接比 PNG 文件的字节——Wine 的 GDI+ 对同样的像素不一定写出同样的字节。
import os, sys
from PIL import Image
if len(sys.argv) < 3:
    print(__doc__ or '用法：compare_shots.py 改前目录 改后目录 [跳过前缀...]'); sys.exit(2)
a, b = sys.argv[1], sys.argv[2]
skip = tuple(sys.argv[3:]) or ('_cache', '_mq', '_after', '_t.png', '_restart', 'gallery', '_probe')  # 默认跳过：状态带随机性或每轮都会变的截图
diff, missing, n = [], [], 0
for f in sorted(os.listdir(a)):
    if not f.endswith('.png') or f.startswith(skip): continue
    pb = os.path.join(b, f)
    if not os.path.exists(pb): missing.append(f); continue
    n += 1
    A = Image.open(os.path.join(a, f)).convert('RGBA'); B = Image.open(pb).convert('RGBA')
    if A.size != B.size or A.tobytes() != B.tobytes(): diff.append(f)
print('核对 %d 张，不同 %d 张%s' % (n, len(diff), '' if not missing else '，改后缺 %d 张' % len(missing)))
for f in diff: print('  不同', f)
for f in missing: print('  缺少', f)
sys.exit(1 if diff or missing else 0)
