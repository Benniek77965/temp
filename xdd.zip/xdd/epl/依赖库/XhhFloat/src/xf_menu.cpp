// 右键菜单：系统弹出菜单（键盘、子菜单、点别处关闭都由系统处理），每一项自己画——底色、文字、悬停、勾选都跟着当前皮肤。
// 文字也用精绘文字（与悬浮窗本身同一种画法）。菜单边框与阴影仍是系统的（Win11 上是圆角）。
#include "xf.h"

namespace {
struct MTheme { unsigned bg, fg, sub, hl, hlfg, accent, sep; bool square; };  // sub（右边的按键名等）在浅色皮肤上也要 4.5 以上
MTheme Theme(int skin, bool dark) {  // 底、字、次要字（右边的按键名，浅色底上也要 4.5 以上）、悬停底、悬停字、勾选色、分隔线、方角
  switch (skin) {
    case SK_CONSOLE: return {0x1E1628, 0xF4F1FA, 0x8D8698, 0x33264A, 0xFFFFFF, 0xFF5470, 0x2E2539, false};
    case SK_NEON: return {0x160A14, 0xFFD9EC, 0xB07A98, 0x3A1030, 0xFFFFFF, 0xFF2E88, 0x351428, false};
    case SK_STICKER: return {0xFFFFFF, 0x3A2626, 0x746460, 0xFFE8EC, 0x3A2626, 0xFF4F6E, 0xF1E6E4, false};
    case SK_GLASS: return dark ? MTheme{0x22242C, 0xECEDF2, 0x8B8FA0, 0x33374A, 0xFFFFFF, 0x8C9EFF, 0x2E3140, false}
                               : MTheme{0xF6F7FB, 0x1E2030, 0x60657A, 0xE7EAFF, 0x1E2030, 0x667EEA, 0xE3E5EE, false};
    case SK_CASSETTE: return {0xFFF8EA, 0x2A1D1D, 0x70635B, 0xFFE7C2, 0x2A1D1D, 0xFF6B3D, 0xEADFCB, false};
    case SK_PIXEL: return {0x17153A, 0xFFFFFF, 0x8C89B8, 0x2C2A6B, 0xFFD541, 0x45F07A, 0x2C2A5A, true};
    case SK_KEYCAP: return {0x18191E, 0xF2F3F6, 0x9A9CA8, 0x2C2E37, 0xFFFFFF, 0x5CE1E6, 0x2A2C33, false};
    case SK_AURORA: return {0x141632, 0xF3F1FF, 0x9EA0C8, 0x2A2C5A, 0xFFFFFF, 0x7CF5D5, 0x272A52, false};
    case SK_CYBER: return {0x0B0D10, 0xF2F4F5, 0x98A0A6, 0x23262B, 0xFCEE0A, 0xFCEE0A, 0x24272C, true};
    case SK_POP: return {0xFFF6D6, 0x111111, 0x5A5550, 0xFFE14D, 0x111111, 0xFF4F8B, 0xE9DFC0, true};
    case SK_CATEAR: return {0xFFF5F8, 0x4A2B3A, 0x7A5A68, 0xFFE3EC, 0x4A2B3A, 0xFF6FA0, 0xF4E1E8, false};
    case SK_COLLAGE: return {0xFBF6EA, 0x2A2633, 0x6B5F57, 0xF2E4C8, 0x2A2633, 0xE5484D, 0xE6D9C2, false};
    case SK_COMIC: return {0xFFFFFF, 0x111111, 0x5A5A5A, 0xFFE24D, 0x111111, 0xE5384D, 0xE6E6E6, true};
    case SK_VINYL: return {0x221A14, 0xF4EBDD, 0xA8998A, 0x3A2C21, 0xFFFFFF, 0xE8A75D, 0x3A2E25, false};
    case SK_SEAL: return {0xF7F1E3, 0x1F1A17, 0x6B5A4E, 0xF1E2C8, 0x1F1A17, 0xB3261E, 0xE4D7BE, false};
    default: return {0x1C1C21, 0xF5F5F7, 0x9A9AA2, 0x2E2E36, 0xFFFFFF, 0x34C759, 0x2C2C33, false};
  }
}
struct MItem { int cmd = 0; std::wstring text, right; bool check = false, radio = false, sep = false, sub = false; };
enum { MC_SETKEY = 1, MC_TOGGLE = 2, MC_OPEN = 3, MC_STOPALL = 4, MC_UNDUCK_B = 5, MC_UNDUCK_S = 6, MC_SHOT = 7, MC_GALLERY = 9, MC_HIDE = 21, MC_EXIT = 22, MC_SKIN0 = 100, MC_SCALE0 = 1000 };  // 皮肤 101～116、大小 1050～1300（原来皮肤是 11～18，扩到 16 款会与隐藏、退出相撞）
std::vector<MItem*> g_items;  // 菜单开着时有效
MTheme g_theme; bool g_rtl = false; float g_k = 1;

Color Cl(unsigned rgb, int a = 255) { return Color((BYTE)a, (BYTE)(rgb >> 16), (BYTE)(rgb >> 8), (BYTE)rgb); }
// 画一项到 w×h 的位图（不透明，底色就是菜单底色）
void DrawItem(Ctx& base, Graphics& g, const MItem& it, int w, int h, bool hot) {
  const MTheme& t = g_theme; float k = g_k;
  g.Clear(Cl(t.bg));
  if (it.sep) { SolidBrush b(Cl(t.sep)); g.FillRectangle(&b, 10 * k, h / 2.f - 0.5f * k, w - 20 * k, 1 * k); return; }
  Ctx c = base; c.g = &g; c.draw = true; c.rtl = false;
  if (hot) { SolidBrush hb(Cl(t.hl)); if (t.square) g.FillRectangle(&hb, 4 * k, 2 * k, w - 8 * k, h - 4 * k); else FillRR(c, 4 * k, 2 * k, w - 8 * k, h - 4 * k, 6 * k, hb); }
  Color fg = Cl(hot ? t.hlfg : t.fg);
  float lx = g_rtl ? w - 26 * k : 10 * k;  // 勾选标记的位置
  if (it.check || it.radio) {
    if (it.radio) { SolidBrush ab(Cl(t.accent)); g.FillEllipse(&ab, lx + 4 * k, h / 2.f - 4 * k, 8 * k, 8 * k); }
    else { Pen p(Cl(t.accent), 2 * k); p.SetStartCap(LineCapRound); p.SetEndCap(LineCapRound); p.SetLineJoin(LineJoinRound);
      PointF pts[3] = {PointF(lx + 3 * k, h / 2.f), PointF(lx + 7 * k, h / 2.f + 4 * k), PointF(lx + 14 * k, h / 2.f - 4 * k)}; g.DrawLines(&p, pts, 3); }
  }
  Font* f = c.fonts->name(it.text, 13 * k, false);
  float tx = 30 * k, tw = w - 30 * k - 16 * k;
  float rw = it.right.empty() ? 0 : TextW(c, it.right, c.fonts->num(12 * k, true)) + 10 * k;
  if (it.sub) rw = 18 * k;
  if (g_rtl) Text(c, it.text, f, fg, 16 * k + rw, 0, tw - rw, (float)h, 2, true);
  else Text(c, it.text, f, fg, tx, 0, tw - rw, (float)h, 0, true);
  if (!it.right.empty()) Text(c, it.right, c.fonts->num(12 * k, true), Cl(hot ? t.hlfg : t.sub), g_rtl ? 12 * k : w - 12 * k - rw, 0, rw, (float)h, g_rtl ? 10 : 12, false);
  if (it.sub) {  // 子菜单箭头（自己画；系统的箭头在深色底上看不清）
    Pen p(Cl(hot ? t.hlfg : t.sub), 1.6f * k); p.SetStartCap(LineCapRound); p.SetEndCap(LineCapRound);
    float ax = g_rtl ? 14 * k : w - 14 * k, d = g_rtl ? 1.f : -1.f;
    PointF pts[3] = {PointF(ax + d * 4 * k, h / 2.f - 4 * k), PointF(ax, h / 2.f), PointF(ax + d * 4 * k, h / 2.f + 4 * k)}; g.DrawLines(&p, pts, 3);
  }
}
MItem* Add(HMENU m, const MItem& src, UINT flags = 0, HMENU sub = nullptr) {
  MItem* it = new MItem(src); g_items.push_back(it);
  AppendMenuW(m, MF_OWNERDRAW | flags | (sub ? MF_POPUP : 0) | (it->sep ? MF_DISABLED : 0), sub ? (UINT_PTR)sub : (UINT_PTR)it->cmd, (LPCWSTR)it);
  return it;
}
}  // namespace
void XfMenuTheme(int skin, bool dark, unsigned* bg, unsigned* fg, bool* square) { MTheme m = Theme(skin, dark); *bg = m.bg; *fg = m.fg; *square = m.square; }

// 菜单项的尺寸、绘制（窗口过程里 WM_MEASUREITEM / WM_DRAWITEM 调用）；不是菜单项返回 false
bool XfMenuMeasure(MEASUREITEMSTRUCT* mi, Ctx& base) {
  if (mi->CtlType != ODT_MENU || !mi->itemData) return false;
  MItem* it = (MItem*)mi->itemData; float k = g_k;
  if (it->sep) { mi->itemWidth = (UINT)(40 * k); mi->itemHeight = (UINT)(9 * k); return true; }
  Ctx c = base; c.rtl = false;  // 与 DrawItem 相同：菜单项画在不镜像的位图上
  float w = TextW(c, it->text, c.fonts->name(it->text, 13 * k, false)) + 30 * k + 16 * k;
  if (!it->right.empty()) w += TextW(c, it->right, c.fonts->num(12 * k, true)) + 22 * k;
  if (it->sub) w += 24 * k;
  if (w < 180 * k) w = 180 * k;
  mi->itemWidth = (UINT)ceilf(w); mi->itemHeight = (UINT)(30 * k);
  return true;
}
bool XfMenuDraw(DRAWITEMSTRUCT* di, Ctx& base) {
  if (di->CtlType != ODT_MENU || !di->itemData) return false;
  MItem* it = (MItem*)di->itemData;
  int w = di->rcItem.right - di->rcItem.left, h = di->rcItem.bottom - di->rcItem.top;
  if (w <= 0 || h <= 0) return true;
  Bitmap bmp(w, h, PixelFormat32bppPARGB);
  { Graphics g(&bmp); g.SetSmoothingMode(SmoothingModeAntiAlias); g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit); g.SetPixelOffsetMode(PixelOffsetModeHalf);
    DrawItem(base, g, *it, w, h, (di->itemState & ODS_SELECTED) && !it->sep); }
  Graphics out(di->hDC); out.DrawImage(&bmp, di->rcItem.left, di->rcItem.top, w, h);
  if (it->sub) ExcludeClipRect(di->hDC, di->rcItem.left, di->rcItem.top, di->rcItem.right, di->rcItem.bottom);  // 不让系统再画它的箭头
  return true;
}
// 弹出右键菜单（界面线程）；返回选中的命令（0＝没选）。test≥0 时不弹出，直接当作选了这一项（测试用）
int XfMenuRun(HWND h, int sx, int sy, Ctx& base, const XState& s, int test) {
  g_theme = Theme(s.skin, base.dark); g_rtl = s.rtl; g_k = base.k;
  for (auto* p : g_items) delete p; g_items.clear();
  HMENU m = CreatePopupMenu(), ms = CreatePopupMenu();
  auto T = [&](int id) { return base.T(id); };
  // 顺序（与 XfMenuSnapshot 相同）：打开主面板是悬浮窗的默认动作（双击空白处做的就是它），按微软右键菜单规范“对象的主要命令在前”放第一，
  // 也与原来右键悬浮窗弹出的托盘菜单第一项相同；快捷键开关在它的设置前面（同一组按逻辑顺序、常用的在前）。设置项右边是当前设的键（不是这一项的快捷键：
  // 微软与苹果的规范都不在右键菜单里标快捷键）。外观（皮肤、大小）一组，隐藏悬浮窗一组，退出单独放最后
  MItem c; c.cmd = MC_OPEN; c.text = T(M_OPEN); Add(m, c);
  if (g_shotItem) { MItem sh; sh.cmd = MC_SHOT; sh.text = T(M_SHOT); Add(m, sh); }  // 1.3.2：宿主交代了才有「截屏」：紧挨在「打开主面板」下面（原来右键悬浮窗弹出的托盘菜单里两项也挨着），位置固定，不随「急停」等出没挪动
  if (s.sfx.state != 0 || s.bgm.state != 0) { MItem st; st.cmd = MC_STOPALL; st.text = T(M_STOPALL); Add(m, st); }  // 1.3.0：有东西在放时「急停」（全部停止）：只管音效的皮肤只放背景音乐时悬停没有按钮，急停在这里也点得到
  if (s.duckB == 1 || s.duckS == 1) { MItem ud; ud.cmd = s.duckB == 1 ? MC_UNDUCK_B : MC_UNDUCK_S; ud.text = T(M_UNDUCK); Add(m, ud); }  // 1.3.0：手动闪避中「取消闪避」：只管音效的皮肤不显示背景音乐那一路的闪避，取消它也在这里（说话闪避是自动的，不放）
  MItem b; b.cmd = MC_TOGGLE; b.text = T(s.armed ? S_HKON : S_HKOFF); b.check = s.armed; Add(m, b);
  MItem a; a.cmd = MC_SETKEY; a.text = T(M_SETKEY); a.right = s.key; Add(m, a);
  MItem sp; sp.sep = true; Add(m, sp);
  { MItem gi; gi.cmd = MC_GALLERY; gi.text = T(M_GALLERY); Add(ms, gi); Add(ms, sp); }  // 皮肤画廊（16 款 4×4 看全、指着就在悬浮窗上预览）
  for (int i = 1; i <= SK_COUNT; i++) {  // 指着哪款，悬浮窗就临时显示哪款（WM_MENUSELECT）；每 4 款一组，组与组之间一条分隔线（与画廊的一行对应）
    if (i > 1 && (i - 1) % 4 == 0) Add(ms, sp);
    MItem si; si.cmd = MC_SKIN0 + i; si.text = T(M_SKIN1 + i - 1); si.radio = s.skin == i; Add(ms, si);
  }
  MItem sk; sk.text = T(M_SKINS); sk.sub = true; Add(m, sk, 0, ms);
  HMENU mz = CreatePopupMenu();  // 大小：当前这款的几档（像素风只有整数倍像素的几档）
  { static const int A[5] = {80, 100, 125, 150, 200}, B[3] = {100, 150, 200}; bool px = SkinTraitsOf(s.skin).pixel; const int* L = px ? B : A; int n = px ? 3 : 5, cur = XfScalePct(s);
    for (int i = 0; i < n; i++) { MItem si; si.cmd = MC_SCALE0 + L[i]; si.text = std::to_wstring(L[i]) + L"%"; si.radio = cur == L[i]; Add(mz, si); } }
  MItem sz; sz.text = T(M_SIZE); sz.sub = true; Add(m, sz, 0, mz);
  Add(m, sp);
  MItem hd; hd.cmd = MC_HIDE; hd.text = T(M_HIDE); Add(m, hd);
  Add(m, sp);
  MItem ex; ex.cmd = MC_EXIT; ex.text = T(M_EXIT); Add(m, ex);
  HBRUSH br = CreateSolidBrush(RGB((g_theme.bg >> 16) & 255, (g_theme.bg >> 8) & 255, g_theme.bg & 255));
  MENUINFO mi = {sizeof(mi)}; mi.fMask = MIM_BACKGROUND | MIM_APPLYTOSUBMENUS; mi.hbrBack = br; SetMenuInfo(m, &mi);
  int cmd = test;
  if (test < 0) {
    HWND prev = GetForegroundWindow();
    for (int i = 0; i < 10 && !prev; i++) { Sleep(10); prev = GetForegroundWindow(); }  // 前台正在切换时会短暂取到空：稍等再取，否则菜单关掉后没法还回去，悬浮窗一直停在前台
    SetForegroundWindow(h);  // 弹出菜单要求所有者在前台，否则点别处不会关闭
    cmd = TrackPopupMenuEx(m, TPM_RETURNCMD | TPM_RIGHTBUTTON | (g_rtl ? TPM_RIGHTALIGN : 0), sx, sy, h, nullptr);  // 不用 TPM_LAYOUTRTL：镜像的菜单 DC 会把自己画的项也镜像；阿拉伯语时项内文字自己右对齐
    PostMessageW(h, WM_NULL, 0, 0);
    // 不论选了什么都把前台还给原来的窗口（例如直播软件）：悬浮窗不能一直当前台窗口——它所在的线程一旦参与激活切换，就会和主线程的激活通知相互牵连
    // （测试里实测：悬浮窗停在前台时再隐藏，界面线程卡在激活切换里，之后不再重画）。要打开主面板、设置窗口、托盘菜单的，易语言随后自己激活它的窗口
    // （刚才那次点击是本进程收到的最后一次输入，系统允许它把窗口提到前台）
    if (prev && prev != h && IsWindow(prev)) SetForegroundWindow(prev);
  }
  DestroyMenu(m); DeleteObject(br);
  for (auto* p : g_items) delete p; g_items.clear();
  return cmd;
}
int XfMenuSkinOf(int cmd) { return cmd > MC_SKIN0 && cmd <= MC_SKIN0 + SK_COUNT ? cmd - MC_SKIN0 : 0; }
bool XfMenuIsGallery(int cmd) { return cmd == MC_GALLERY; }
// 命令 → 回调事件（事件号，参数）
bool XfMenuEvent(int cmd, int* ev, int* arg) {
  *arg = 0;
  switch (cmd) {
    case MC_SETKEY: *ev = XE_SET_KEY; return true;
    case MC_TOGGLE: *ev = XE_TOGGLE_HOTKEYS; return true;
    case MC_OPEN: *ev = XE_OPEN_PANEL; return true;
    case MC_SHOT: *ev = XE_SHOT; return true;  // 1.3.2
    case MC_STOPALL: *ev = XE_STOP_ALL; return true;  // 1.3.0
    case MC_UNDUCK_B: *ev = XE_DUCK_BGM; return true;  // 1.3.0
    case MC_UNDUCK_S: *ev = XE_DUCK_SFX; return true;  // 1.3.0
    case MC_HIDE: *ev = XE_HIDE; return true;
    case MC_EXIT: *ev = XE_EXIT; return true;
  }
  if (cmd > MC_SKIN0 && cmd <= MC_SKIN0 + SK_COUNT) { *ev = XE_SKIN; *arg = cmd - MC_SKIN0; return true; }
  if (cmd >= MC_SCALE0 + 50 && cmd <= MC_SCALE0 + 300) { *ev = XE_SCALE; *arg = cmd - MC_SCALE0; return true; }
  return false;
}
// 测试用：把整份菜单（含皮肤子菜单）按当前皮肤画成一张图
bool XfMenuSnapshot(Ctx& base, const XState& s, const wchar_t* path) {
  g_theme = Theme(s.skin, base.dark); g_rtl = s.rtl; g_k = base.k;
  std::vector<MItem> items;
  auto T = [&](int id) { return base.T(id); };
  MItem c; c.text = T(M_OPEN); items.push_back(c);  // 顺序与 XfMenuRun 相同（理由见那里）
  if (g_shotItem) { MItem sh; sh.text = T(M_SHOT); items.push_back(sh); }  // 1.3.2：同 XfMenuRun
  if (s.sfx.state != 0 || s.bgm.state != 0) { MItem st; st.text = T(M_STOPALL); items.push_back(st); }  // 1.3.0：同 XfMenuRun
  if (s.duckB == 1 || s.duckS == 1) { MItem ud; ud.text = T(M_UNDUCK); items.push_back(ud); }
  MItem b; b.text = T(s.armed ? S_HKON : S_HKOFF); b.check = s.armed; items.push_back(b);
  MItem a; a.text = T(M_SETKEY); a.right = s.key; items.push_back(a);
  MItem sp; sp.sep = true; items.push_back(sp);
  int hotMain = (int)items.size();  // 1.3.0：截图里画成悬停的“皮肤”项的下标（前面多了「急停」时往后挪）
  MItem sk; sk.text = T(M_SKINS); sk.sub = true; items.push_back(sk);  // 下标 4：截图里画成悬停（右边画出它的子菜单）
  MItem szi; szi.text = T(M_SIZE); szi.sub = true; items.push_back(szi);
  items.push_back(sp);
  MItem hd; hd.text = T(M_HIDE); items.push_back(hd);
  items.push_back(sp);
  MItem ex; ex.text = T(M_EXIT); items.push_back(ex);
  float k = g_k; int W = 0, H = 0, Ws = 0, Hs = 0;
  auto meas = [&](const MItem& it, int& w, int& hh) { MEASUREITEMSTRUCT m = {}; m.CtlType = ODT_MENU; m.itemData = (ULONG_PTR)&it; XfMenuMeasure(&m, base); w = m.itemWidth; hh = m.itemHeight; };
  for (auto& it : items) { int w, hh; meas(it, w, hh); if (w > W) W = w; H += hh; }
  std::vector<MItem> subs;
  { MItem gi; gi.text = T(M_GALLERY); subs.push_back(gi); subs.push_back(sp); for (int j = 0; j < 2; j++) { int w, hh; meas(subs[j], w, hh); if (w > Ws) Ws = w; Hs += hh; } }
  int hotSub = -1;  // 截图里子菜单画成悬停的那一项：当前这款
  for (int i = 1; i <= SK_COUNT; i++) {
    if (i > 1 && (i - 1) % 4 == 0) { subs.push_back(sp); int w, hh; meas(sp, w, hh); Hs += hh; }
    MItem si; si.text = T(M_SKIN1 + i - 1); si.radio = s.skin == i; if (si.radio) hotSub = (int)subs.size(); subs.push_back(si); int w, hh; meas(si, w, hh); if (w > Ws) Ws = w; Hs += hh;
  }
  int pad = (int)(4 * k), gap = (int)(10 * k);
  Bitmap out(W + Ws + 2 * pad * 2 + gap, (H > Hs ? H : Hs) + 2 * pad, PixelFormat32bppARGB);
  Graphics g(&out); g.Clear(Color(0, 0, 0, 0));
  auto panel = [&](std::vector<MItem>& v, int x0, int w) {
    int y = pad; int total = 0; for (auto& it : v) { int ww, hh; meas(it, ww, hh); total += hh; }
    SolidBrush bb(Cl(g_theme.bg)); g.FillRectangle(&bb, x0, 0, w + 2 * pad, total + 2 * pad);
    for (size_t i = 0; i < v.size(); i++) {
      int ww, hh; meas(v[i], ww, hh);
      Bitmap ib(w, hh, PixelFormat32bppPARGB);
      base.logDx = (float)(x0 + pad); base.logDy = (float)y;  // 测试：每一项画在自己的位图里，记文字时换算到整张图
      { Graphics ig(&ib); ig.SetSmoothingMode(SmoothingModeAntiAlias); ig.SetPixelOffsetMode(PixelOffsetModeHalf); DrawItem(base, ig, v[i], w, hh, &v == &items ? (int)i == hotMain : (int)i == hotSub); }
      g.DrawImage(&ib, x0 + pad, y, w, hh); y += hh;
    }
  };
  panel(items, 0, W);
  panel(subs, W + 2 * pad + gap, Ws);
  CLSID png; UINT n = 0, sz = 0; GetImageEncodersSize(&n, &sz); if (!sz) return false;
  std::vector<BYTE> buf(sz); ImageCodecInfo* ci = (ImageCodecInfo*)buf.data(); GetImageEncoders(n, sz, ci);
  bool found = false; for (UINT i = 0; i < n; i++) if (!wcscmp(ci[i].MimeType, L"image/png")) { png = ci[i].Clsid; found = true; }
  return found && out.Save(path, &png, nullptr) == Ok;
}
