// 悬浮窗核心：自己的界面线程、逐像素透明的分层窗口、绘制流水线、鼠标（悬停、点击、拖动、贴边）、DPI、导出接口。
// 易语言从任何线程调 XF_Set*：只在锁里改状态、投递一条“要重画”的消息；绘制、动画、拖动全在本线程，主线程忙时照常。
#include "xf.h"
#include <math.h>
#include <algorithm>

#define XF_API extern "C" __declspec(dllexport) INT_PTR WINAPI
#define WM_XF_DIRTY (WM_APP + 1)
#define WM_XF_SNAP (WM_APP + 2)
#define WM_XF_CALL (WM_APP + 3)
enum { TM_ANIM = 1, TM_HOVER = 2, TM_LEAVE = 3, TM_DOCKCLOSE = 4, TM_TIP = 5, TM_HINT = 6, TM_PREVEND = 7, TM_RETRY = 8, TM_GUARD = 9, TM_TIPPOP = 10 };  // 10（1.5.0）：账号提示到时自己收起
static std::wstring g_hintText;  // 首次使用提示（非空＝正在显示；界面线程）
static volatile bool g_testCrashOk = false;  // 测试开关：选项 110 才置真（验证闪退现场记录）
volatile bool g_testNoText = false;          // 测试：选项 111，不画文字
volatile bool g_testNoDots = false;          // 测试：选项 113，点阵屏不打点
wchar_t g_testTextLog[260] = L"";            // 测试：选项 112，文字记录文件（宽字符：路径里有中文时窄字符的 fopen 打不开）
bool g_testLogNow = false;                   // 测试：正在画截图（只有这时才记文字；界面线程上读写）

typedef INT_PTR(WINAPI* XfCallback)(INT_PTR ev, INT_PTR arg);
struct TimeReq { int n; long long us; };

// ---- 跨线程共享（g_cs 保护）
static CRITICAL_SECTION g_cs;
static volatile LONG g_csInit = 0;
static XState g_state;
static bool g_dirtyPosted = false;
static bool g_animating = false;
static HANDLE g_thread = nullptr;
static DWORD g_tid = 0;
static bool g_stopReq = false;  // XF_Stop 已经叫停：还在启动的界面线程建好窗口后不再显示，直接退出
static int g_testStartDelay = 0, g_testStartWait = 0;
static HWND g_hwnd = nullptr;
static XfCallback g_cb = nullptr;
static std::wstring g_fontDir;
static int g_opt[8] = {0, 0, 0, 1, 0, 0, 0, 0};  // 2 贴边 3 置顶（1 原是“直播画面中隐藏”，已去掉）
static int g_freeze = 0, g_testHover = -1, g_testDark = -1, g_testDockOpen = 0;
static bool g_visible = true;
static POINT g_anchor = {0, 0};   // 逻辑锚点（屏幕坐标，物理像素）
static bool g_anchorRight = false;
static int g_dock = 0;
static std::string g_textBuf[S_COUNT];
static int g_infoX = 0, g_infoY = 0, g_infoDpi = 96, g_infoW = 0, g_infoH = 0;
static int g_startErr = 0;
static bool g_pmAware = false;     // 界面线程按显示器 DPI 感知（Win10 1607 起）：只有这时按屏取的 DPI 才与绘制用的一致
static volatile LONG g_selfFix = 0, g_procTaken = 0;  // 诊断：窗口被别的模块改动后自己恢复的次数（XF_GetInfo 100；悬浮窗、提示、画廊合计）、悬浮窗的窗口过程被接管（101）
// ---- 多显示器与位置记忆（1.2.0，见 README「多显示器与位置记忆」；g_cs 保护）
static std::wstring g_memFile;     // 本机位置记忆文件（XO_MEMFILE；空＝不记）
static DWORD g_hintSig = 0;        // XF_Start 交来的位置是在哪种显示布局下存的（XO_HINTSIG；0＝不知道）
static bool g_memUse = false;      // 这次启动用了位置记忆（XF_Start 标志 4）：换显示布局时按记忆挪过去
static DWORD g_layoutSig = 0;      // 当前显示布局签名（界面线程启动时、显示设置变了时算）
static int g_monCount = 0, g_posSrc = 0, g_onPrimary = 0, g_memCount = 0;  // 显示器个数、位置的来源（PS_）、悬浮窗在主屏上、本机记着几种布局
static volatile LONG g_frames = 0;  // 实际贴到窗口上的帧数（测试用：看动画时钟是否在走）  // 启动失败的原因：1 GDI+ 启动失败 2 建窗失败（低 16 位为 GetLastError）3 等待超时

static void Lock() { EnterCriticalSection(&g_cs); }
static void Unlock() { LeaveCriticalSection(&g_cs); }
static void EnsureCs() {
  if (InterlockedCompareExchange(&g_csInit, 1, 0) == 0) { InitializeCriticalSection(&g_cs); InterlockedExchange(&g_csInit, 2); }
  while (g_csInit != 2) Sleep(0);
}
static void PostDirty() {  // 在锁里调用
  if (g_hwnd && !g_dirtyPosted) { g_dirtyPosted = true; PostMessageW(g_hwnd, WM_XF_DIRTY, 0, 0); }
}

// ---- 界面线程私有
struct Ui {
  XState s;
  Fonts fonts;
  std::vector<Hit> hits;
  float W = 0, H = 0;      // 内容尺寸（物理像素）
  int m = 0;               // 阴影边距
  int dpi = 96;
  float k = 1;
  bool hover = false, tracking = false, hoverIntent = false;
  bool hoverBody = false;   // 1.5.0：鼠标在悬浮窗本身上（内容范围里），不是在四周的柔和投影上（投影也收鼠标）；账号提示只在这时显示
  int hoverId = 0, pressId = 0;
  bool pressed = false, dragging = false;
  POINT pressPt = {0, 0}, pressWin = {0, 0};
  bool dockOpen = false;
  std::wstring lastKey;  // 上一帧的画面要素：一样就不重画（倒计时类皮肤每秒只真正画一次）
  Marquee mq;  // 曲名滚动
  int ulwFails = 0;  // 贴画面（UpdateLayeredWindow）连续失败的次数：重试间隔 0.5、1、2、4 秒，之后每 4 秒
  bool dark = false;
  bool rtl = false;
  int fps = 0;
  POINT winPos = {0, 0};
  SIZE winSize = {0, 0};
  // 阴影缓存
  unsigned shadowHash = 0; int shadowW = 0, shadowH = 0; std::vector<unsigned char> shadowA;
  Bitmap* measureBmp = nullptr; Graphics* measureG = nullptr;
} ;
static Ui* U_ = nullptr;

static int SysDpi() {
  HDC dc = GetDC(nullptr); int d = GetDeviceCaps(dc, LOGPIXELSX); ReleaseDC(nullptr, dc); return d > 0 ? d : 96;
}
static int WindowDpi(HWND h) {
  typedef UINT(WINAPI * PGDFW)(HWND);
  static PGDFW f = (PGDFW)(void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetDpiForWindow");
  if (f && h) { UINT d = f(h); if (d) return (int)d; }
  return SysDpi();
}
static bool SystemDark() {
  HKEY k = nullptr; DWORD v = 1, sz = sizeof(v), ty = 0; bool dark = false;
  if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize", 0, KEY_READ, &k) == ERROR_SUCCESS) {
    if (RegQueryValueExW(k, L"AppsUseLightTheme", nullptr, &ty, (BYTE*)&v, &sz) == ERROR_SUCCESS && ty == REG_DWORD) dark = (v == 0);
    RegCloseKey(k);
  }
  return dark;
}
// ---- 毛玻璃组件卡（SK_GLASS）的实时模糊
// 微软文档：背景亚克力（含 DWMSBT_TRANSIENTWINDOW）在窗口不处于激活状态时换成纯色——悬浮窗从不激活，所以用不上。能给不激活的窗口模糊的只有
// SetWindowCompositionAttribute 的“模糊”（未公开但长期稳定，TranslucentTB 等一直在用）；不用它的“亚克力”那一档：Win10 1903 起拖动窗口时会卡。
// 卡片下面另放一个不可点、不激活、不进任务栏的窗口（只有它带模糊；悬浮窗本身的柔和投影、抗锯齿圆角不受影响），区域是往里缩 1 像素的圆角矩形；
// 卡片的底色、噪点、高光仍由悬浮窗画在上面——有实时模糊时底色 84%（与微软亚克力的明度层相当），文字对比度按黑、白两种背景都检查过；
// 模糊没生效时背景窗口是黑的，正是对比度检查里最差的那种背景。不用：关了“透明效果”、高对比度、省电模式、接口失败（如 Wine）、选项 8 设为 0
static volatile LONG g_menuN = 0, g_menuMs = 0, g_menuCmd = 0;  // 诊断：弹过几次右键菜单、上一次菜单开了多久、选了哪项（XF_GetInfo 91～93）
static volatile LONG g_clickMiss = 0, g_capLost = 0;  // 诊断：按钮上按下抬起却没算点击的原因（1 抬起前按下状态已清 2 成了拖动 3 按下、抬起不在同一个按钮＋两者编号）；按着时失去捕获的次数
bool g_glassLiveDraw = false;              // 这一帧毛玻璃组件卡按“有实时模糊”画（底色 84%）；界面线程
static HWND g_glass = nullptr;
static int g_glassState = 0;               // 1 实时模糊在用 0 还没试 -1 接口不可用
static volatile bool g_glassAllow = true;  // 选项 8
static volatile bool g_glassForce = false; // 测试（选项 114）：接口不可用也建背景窗口、按有模糊画，检查它跟得上卡片
static int g_glassW = 0, g_glassH = 0;
// 1.3.3：右键菜单开着时不改任何层次（见 GlassSync 里的说明）。真机上顶层弹出菜单没有所有者（ReactOS 的 menu.c 注明“In Windows, top menu popup is not owned.”），
// 菜单开着时 SetWindowPos(卡片, HWND_TOPMOST) 就把卡片放到菜单、子菜单上面；Wine 建菜单时把悬浮窗当所有者（拥有的窗口总在所有者上面），所以 Wine 里原样测不出来
static bool g_inMenu = false;            // 右键菜单开着（关菜单的通知不清预览，等选的结果；菜单开着时不新建毛玻璃背景、不改层次）
static bool g_zLater = false;            // 1.3.3：菜单开着时来了换层的请求（选项 3、找回悬浮窗）：菜单关掉后补做（AfterMenu）
static LRESULT CALLBACK GlassProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
  switch (m) {
    case WM_NCHITTEST: return HTTRANSPARENT;
    case WM_MOUSEACTIVATE: return MA_NOACTIVATE;
    case WM_ERASEBKGND: { RECT rc; GetClientRect(h, &rc); FillRect((HDC)wp, &rc, (HBRUSH)GetStockObject(BLACK_BRUSH)); return 1; }  // 黑色在 DWM 模糊里是透明的
    case WM_PAINT: { PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps); FillRect(dc, &ps.rcPaint, (HBRUSH)GetStockObject(BLACK_BRUSH)); EndPaint(h, &ps); return 0; }
  }
  return DefWindowProcW(h, m, wp, lp);
}
static DWORD g_glassSysLast = 0;           // 系统设置上次读的时刻（设置变了时清零，马上重读）
static bool GlassSystemOk() {  // 系统设置允许（每 2 秒最多读一次）
  DWORD& last = g_glassSysLast; static bool ok = true;
  DWORD now = GetTickCount(); if (last && now - last < 2000) return ok;
  last = now ? now : 1; ok = true;
  HKEY k; DWORD v = 1, sz = sizeof(v);
  if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize", 0, KEY_READ, &k) == ERROR_SUCCESS) { if (RegQueryValueExW(k, L"EnableTransparency", nullptr, nullptr, (BYTE*)&v, &sz) == ERROR_SUCCESS && !v) ok = false; RegCloseKey(k); }
  HIGHCONTRASTW hc = {sizeof(hc)}; if (SystemParametersInfoW(SPI_GETHIGHCONTRAST, sizeof(hc), &hc, 0) && (hc.dwFlags & HCF_HIGHCONTRASTON)) ok = false;
  SYSTEM_POWER_STATUS ps; if (GetSystemPowerStatus(&ps) && ps.SystemStatusFlag) ok = false;  // 省电模式（系统自己也会关掉模糊）
  return ok;
}
// 只在悬浮窗置顶时用（易语言从不关置顶，这是实际的用法）：不置顶时普通层里别的窗口激活、排序变化频繁，背景窗口和卡片的上下关系没法保证
// （Wine 里实测不置顶时背景会留在卡片上面），退回不透明的底
static bool GlassWanted(int skin) { bool top; Lock(); top = g_opt[3] != 0; Unlock(); return SkinTraitsOf(skin).glass && top && (g_glassForce || (g_glassAllow && GlassSystemOk())); }
static bool GlassEnsure() {
  if (g_glass) {
    if (g_glassState == -1 && !g_glassForce) { DestroyWindow(g_glass); g_glass = nullptr; return false; }  // 强制建的（接口不可用）：不再强制就收掉，不能留一块没有模糊的黑底
    if (g_inMenu && !IsWindowVisible(g_glass)) return false;  // 1.3.3：菜单开着时只用已经摆好、显示着的背景（还没显示的要先摆层次，等菜单关掉）
    return true;
  }
  if (g_glassState == -1 && !g_glassForce) return false;
  if (g_inMenu) return false;  // 1.3.3：菜单开着时不新建：新建的背景要换到置顶层、再把卡片提到最上面才摆得好，那样会压到菜单上。这一帧按没有实时模糊画（92% 的底），菜单关掉后再建
  g_glass = CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | WS_EX_TRANSPARENT, L"XhhFloatGlass",  /* 置顶与否跟悬浮窗走，见 GlassSync */ L"", WS_POPUP, 0, 0, 1, 1, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
  if (!g_glass) { g_glassState = -1; return false; }
  typedef BOOL(WINAPI * SWCA)(HWND, void*);
  static SWCA f = (SWCA)(void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetWindowCompositionAttribute");
  struct Accent { int state, flags; DWORD color; int anim; } a = {3 /*ACCENT_ENABLE_BLURBEHIND*/, 0, 0, 0};
  struct Data { int attr; void* data; SIZE_T size; } d = {19 /*WCA_ACCENT_POLICY*/, &a, sizeof(a)};
  bool ok = f && f(g_glass, &d);
  g_glassState = ok ? 1 : -1;
  if (!ok && !g_glassForce) { DestroyWindow(g_glass); g_glass = nullptr; return false; }
  g_glassW = g_glassH = 0;
  return true;
}
// 不用时直接销毁、要用时新建，不“隐藏再显示”：没有分层样式的窗口设了“不出现在截图里”后，隐藏再显示会在截图里变成黑块
// （Electron 修过同一个问题，见其提交 #31340；提示、画廊、悬浮窗本身都是分层窗口，不受影响；菜单窗口每次新建）
static void GlassHide() { if (g_glass) { DestroyWindow(g_glass); g_glass = nullptr; g_glassW = g_glassH = 0; } }
static void GlassSync(bool want, int x, int y, int w, int h, float k) {  // x, y：卡片（内容）左上角的屏幕坐标
  if (!want || !GlassEnsure()) { GlassHide(); return; }
  const int in = 1;  // 往里缩 1 像素：模糊不会从卡片抗锯齿的边缘透出来
  int gw = w - 2 * in, gh = h - 2 * in; if (gw < 8 || gh < 8) { GlassHide(); return; }
  if (gw != g_glassW || gh != g_glassH) {
    int rad = (int)roundf(20 * k) - in; if (rad < 1) rad = 1;
    SetWindowRgn(g_glass, CreateRoundRectRgn(0, 0, gw + 1, gh + 1, 2 * rad, 2 * rad), FALSE); g_glassW = gw; g_glassH = gh;
  }
  SetWindowPos(g_glass, nullptr, x + in, y + in, gw, gh, SWP_NOACTIVATE | SWP_NOZORDER);
  // 1.3.3：右键菜单开着时到此为止——只跟着移动、改大小，层次留到菜单关掉之后（RunMenu → AfterMenu）。原来菜单开着时也照下面重排：在皮肤子菜单里指到「毛玻璃组件卡」
  // （新建背景）、或当前就是组件卡而卡片与背景之间夹进了别的置顶窗口（弹菜单前的 SetForegroundWindow 会把卡片提到置顶层最上面）时，下面把卡片提到置顶层最上面，
  // 压在菜单、子菜单上——真机上顶层弹出菜单没有所有者，不会跟着卡片上来（见 g_inMenu 前的说明）
  if (g_inMenu) return;
  // 层次：背景窗口必须紧挨在悬浮窗下面（中间没有别的可见窗口）——实测只靠 SetWindowPos(背景, 悬浮窗) 背景会跑到悬浮窗上面，盖住卡片。
  // 不对时把背景放到所在层（置顶层或普通层，跟悬浮窗一样）的最上面，再把悬浮窗放到它上面；对的时候不动，免得每帧都和别的置顶窗口抢层次
  bool top = (GetWindowLongW(g_hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST) != 0, gtop = (GetWindowLongW(g_glass, GWL_EXSTYLE) & WS_EX_TOPMOST) != 0;
  if (top != gtop) SetWindowPos(g_glass, top ? HWND_TOPMOST : HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);  // 和悬浮窗在同一层：否则点了别的普通窗口，它会插到背景和卡片中间
  HWND nx = GetWindow(g_hwnd, GW_HWNDNEXT); while (nx && nx != g_glass && !IsWindowVisible(nx)) nx = GetWindow(nx, GW_HWNDNEXT);
  if (nx != g_glass) {
    SetWindowPos(g_hwnd, top ? HWND_TOPMOST : HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);  // 卡片到所在层最上
    SetWindowPos(g_glass, g_hwnd, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);  // 背景插在卡片正下方
  }
  if (!IsWindowVisible(g_glass)) ShowWindow(g_glass, SW_SHOWNOACTIVATE);  // 层次摆好之后才显示
}
static RECT WorkAreaAt(POINT p) {
  HMONITOR mon = MonitorFromPoint(p, MONITOR_DEFAULTTONEAREST);
  MONITORINFO mi = {sizeof(mi)};
  GetMonitorInfoW(mon, &mi);
  return mi.rcWork;
}
// 坐标的合理范围（1.2.0）：配置损坏、调用方传来极端值（如 0x7FFFFFFF）时，后面加减边距、宽度不会有符号溢出（未定义行为）。真实的屏幕坐标远在这个范围之内
static LONG SaneCoord(INT_PTR v) { return v < -1000000 ? -1000000 : v > 1000000 ? 1000000 : (LONG)v; }
// ---- 多显示器（1.2.0）
// 原来按锚点所在的屏摆放（WorkAreaAt(锚点)），两处会把悬浮窗放到另一块屏上（真机多屏的情形在 Wine 里用假显示器复现过，见 README「多显示器与位置记忆」）：
// ① 锚点在右侧时锚点是内容的右边界，按 RECT 的约定右边界不属于这块屏——内容正好贴着屏的右边时，锚点就落在右边相邻的那块屏上；
// ② 在两块屏的交界处贴边：拖过交界几十个像素、窗口中心还在原来那块屏时，按中心判定贴原来那块屏的边，锚点却在相邻那块屏上，
//    于是被摆到相邻那块屏的最远端（贴右边→右边那块屏的最右端），重启后照旧——那块屏关着或是电视、采集用的虚拟屏时就“找不到悬浮窗”了。
// 现在：贴边时按“贴的那条边离锚点最近”的屏（只看那条边方向上覆盖锚点的屏）；不贴边时锚点在右侧的往里收 1 像素再找；拖动结束时把内容夹回所在那块屏。
struct MonEnum { RECT rc[16], wk[16]; int n; };
static BOOL CALLBACK MonEnumProc(HMONITOR h, HDC, LPRECT, LPARAM lp) {
  MonEnum* e = (MonEnum*)lp; if (e->n >= 16) return FALSE;
  MONITORINFO mi = {sizeof(mi)}; if (GetMonitorInfoW(h, &mi)) { e->rc[e->n] = mi.rcMonitor; e->wk[e->n] = mi.rcWork; e->n++; }
  return TRUE;
}
static void MonList(MonEnum& e) {  // 全部显示器，按左、顶排序（签名与系统枚举的先后无关）
  e.n = 0; EnumDisplayMonitors(nullptr, nullptr, MonEnumProc, (LPARAM)&e);
  for (int i = 1; i < e.n; i++)
    for (int j = i; j > 0 && (e.rc[j].left < e.rc[j - 1].left || (e.rc[j].left == e.rc[j - 1].left && e.rc[j].top < e.rc[j - 1].top)); j--) { std::swap(e.rc[j], e.rc[j - 1]); std::swap(e.wk[j], e.wk[j - 1]); }
}
static RECT HomeWorkArea(POINT a, bool right, int dock) {
  POINT probe = {right ? a.x - 1 : a.x, a.y};
  if (dock >= 1 && dock <= 3) {
    MonEnum e; MonList(e);
    int best = -1; long long bd = 0;
    for (int i = 0; i < e.n; i++) {
      const RECT& r = e.rc[i]; const RECT& w = e.wk[i];
      bool cover = dock == 3 ? (probe.x >= r.left && probe.x < r.right) : (a.y >= r.top && a.y < r.bottom);
      if (!cover) continue;
      long long d = dock == 1 ? (long long)a.x - w.left : dock == 2 ? (long long)a.x - w.right : (long long)a.y - w.top;
      if (d < 0) d = -d;
      if (best < 0 || d < bd) { best = i; bd = d; }
    }
    if (best >= 0) return e.wk[best];
  }
  return WorkAreaAt(probe);
}
// 按系统目录载入系统 DLL（同 WebView2Bridge 的 LoadSystemDll）：只给文件名时先在程序（exe）目录里找，dbghelp 这类不在 KnownDLLs 里的会被同名文件顶替
// （别的程序带的旧版本、或有人放进去的同名 DLL）。只用栈上的缓冲区：闪退现场记录也用它，那时堆可能已经坏了
static HMODULE LoadSystemDll(const wchar_t* name) {
  HMODULE h = GetModuleHandleW(name);
  if (h) return h;
  wchar_t p[MAX_PATH]; UINT n = GetSystemDirectoryW(p, MAX_PATH); size_t ln = wcslen(name);
  if (n == 0 || n + 1 + ln >= MAX_PATH) return nullptr;
  p[n] = L'\\'; memcpy(p + n + 1, name, (ln + 1) * sizeof(wchar_t));
  return LoadLibraryExW(p, nullptr, LOAD_WITH_ALTERED_SEARCH_PATH);
}
static int MonitorDpiAt(POINT p, int fallback) {  // 那块屏的有效 DPI（GetDpiForMonitor：Win8.1 起，按需取地址；取不到用 fallback）
  typedef HRESULT(WINAPI * PGDFM)(HMONITOR, int, UINT*, UINT*);
  static PGDFM f = nullptr; static bool tried = false;  // 只在界面线程调用
  if (!tried) { tried = true; HMODULE m = LoadSystemDll(L"shcore.dll"); if (m) f = (PGDFM)(void*)GetProcAddress(m, "GetDpiForMonitor"); }
  UINT dx = 0, dy = 0;
  if (!g_pmAware) return fallback;  // 线程不按显示器感知（Win8.1、Win10 1607 之前）：系统按一个 DPI 换算，按屏取的 DPI 与绘制不一致
  if (f && SUCCEEDED(f(MonitorFromPoint(p, MONITOR_DEFAULTTONEAREST), 0, &dx, &dy)) && dx >= 48 && dx <= 960) return (int)dx;  // 0 = MDT_EFFECTIVE_DPI
  return fallback;
}
static HMONITOR PrimaryMon() { POINT o = {0, 0}; return MonitorFromPoint(o, MONITOR_DEFAULTTOPRIMARY); }  // 主屏的左上角总是 (0,0)
static RECT PrimaryRect(bool work) { MONITORINFO mi = {sizeof(mi)}; GetMonitorInfoW(PrimaryMon(), &mi); return work ? mi.rcWork : mi.rcMonitor; }
// 显示布局签名：这台电脑的计算机名＋全部显示器的矩形（按左、顶排序），做 FNV-1a。含计算机名：别的电脑上显示器排得一模一样，那边同一处也许是电视、关着的屏，
// 账号配置里从别的电脑带来的位置不能当作“同一种布局”照用（只在主屏上才用）。不含工作区（任务栏挪动不算换布局）、不含缩放（锚点是物理像素，改缩放后照样有效）
static DWORD LayoutSig(int* count) {
  MonEnum e; MonList(e);
  DWORD h = 2166136261u;
  auto mix = [&](LONG v) { for (int b = 0; b < 4; b++) { h ^= (BYTE)((DWORD)v >> (8 * b)); h *= 16777619u; } };
  wchar_t pc[64] = L""; DWORD pcn = 64;
  if (GetComputerNameW(pc, &pcn)) for (DWORD i = 0; i < pcn && i < 64; i++) mix((LONG)pc[i]);
  mix(e.n); for (int i = 0; i < e.n; i++) { mix(e.rc[i].left); mix(e.rc[i].top); mix(e.rc[i].right); mix(e.rc[i].bottom); }
  if (count) *count = e.n;
  return h ? h : 1;
}
// 账号配置里的位置在不在主屏上（别的显示布局下存的位置，只有在主屏上才照用：那份位置可能来自别的电脑，这台电脑同一处也许是电视、关着的屏）
static bool HintOnPrimary(POINT a, bool right, int dock) {
  if (dock >= 1 && dock <= 3) { RECT h = HomeWorkArea(a, right, dock), pw = PrimaryRect(true); return EqualRect(&h, &pw) != 0; }
  POINT probe = {right ? a.x - 1 : a.x, a.y};
  return MonitorFromPoint(probe, MONITOR_DEFAULTTONULL) == PrimaryMon();
}
// ---- 本机位置记忆（ini，只放这台电脑的显示布局与位置；路径由易语言给：配置目录里的 <账号>.xhhfloat.ini，每个账号一份，窗口位置只存本机同 midieditor.ini、recorder.ini 的做法）
// [order] list＝最近用过的布局（新的在前，最多 8 种）；[layout_XXXXXXXX] pos＝锚点 x,y,贴边（低 8 位贴哪边，256＝锚点在右），monitors＝这种布局的显示器（只供人看）
struct MemPos { bool ok = false; LONG x = 0, y = 0; int dock = 0; };
static std::wstring MemFile() { std::wstring f; Lock(); f = g_memFile; Unlock(); return f; }
static std::wstring SigHex(DWORD sig) { wchar_t b[16]; swprintf(b, 16, L"%08lX", (unsigned long)sig); return b; }
static MemPos MemRead(DWORD sig) {
  MemPos p; std::wstring f = MemFile(); if (f.empty() || !sig) return p;
  wchar_t buf[96] = L""; GetPrivateProfileStringW((L"layout_" + SigHex(sig)).c_str(), L"pos", L"", buf, 96, f.c_str());
  long x = 0, y = 0, d = 0;
  if (swscanf(buf, L"%ld,%ld,%ld", &x, &y, &d) == 3 && (d & 0xFF) <= 3 && (d & ~0x1FFL) == 0) { p.ok = true; p.x = SaneCoord(x); p.y = SaneCoord(y); p.dock = (int)d; }
  return p;
}
static std::vector<std::wstring> MemOrder(const std::wstring& f) {
  wchar_t buf[512] = L""; GetPrivateProfileStringW(L"order", L"list", L"", buf, 512, f.c_str());
  std::vector<std::wstring> v; std::wstring cur;
  for (const wchar_t* q = buf;; q++) {
    if (*q == L',' || !*q) { if (cur.size() == 8) v.push_back(cur); cur.clear(); if (!*q) break; }
    else if (*q != L' ') cur += *q;
  }
  return v;
}
static void MemSave() {  // 拖动结束、找回之后（界面线程）：记下这种显示布局下的位置，排到最前；超过 8 种就删掉最久没用的
  std::wstring f = MemFile(); if (f.empty()) return;
  int n = 0; DWORD sig = LayoutSig(&n);
  POINT a; int dk; bool ar; Lock(); a = g_anchor; dk = g_dock; ar = g_anchorRight; g_layoutSig = sig; g_monCount = n; Unlock();
  std::wstring id = SigHex(sig), sec = L"layout_" + id;
  wchar_t v[96]; swprintf(v, 96, L"%ld,%ld,%d", (long)a.x, (long)a.y, dk | (ar ? 0x100 : 0));
  WritePrivateProfileStringW(sec.c_str(), L"pos", v, f.c_str());
  MonEnum e; MonList(e); std::wstring mons;
  for (int i = 0; i < e.n; i++) { wchar_t m[64]; swprintf(m, 64, L"%ls%ld,%ld,%ld,%ld", i ? L";" : L"", (long)e.rc[i].left, (long)e.rc[i].top, (long)e.rc[i].right, (long)e.rc[i].bottom); mons += m; }
  WritePrivateProfileStringW(sec.c_str(), L"monitors", mons.c_str(), f.c_str());
  std::vector<std::wstring> old = MemOrder(f), keep; keep.push_back(id);
  for (auto& o : old) {
    if (o == id) continue;
    if (keep.size() < 8) keep.push_back(o);
    else WritePrivateProfileStringW((L"layout_" + o).c_str(), nullptr, nullptr, f.c_str());  // 删掉这一节
  }
  std::wstring lst; for (size_t i = 0; i < keep.size(); i++) { if (i) lst += L","; lst += keep[i]; }
  WritePrivateProfileStringW(L"order", L"list", lst.c_str(), f.c_str());
  Lock(); g_memCount = (int)keep.size(); Unlock();
}
static HWND g_tip = nullptr;
static volatile LONG g_tipKey = -1;  // 正在显示的提示：文字序号，另有 TIP_HINT 首次使用提示、TIP_ACCOUNT 软件账号（1.5.0）；-1＝没有（XF_GetInfo 17）
static int g_tipTarget = -1;         // 1.5.0：正在等（TM_TIP）或正在显示的提示，取值同 g_tipKey（界面线程）：鼠标在同一种提示的范围里移动时不收不闪
static RECT g_tipAt = {0, 0, 0, 0};  // 1.5.0：显示着的提示对着的地方（屏幕坐标）：悬浮窗挪了、变了大小，按钮挪了位置，就跟着重摆
static std::wstring g_tipShown;      // 1.5.0：显示着的提示的文字（界面线程）：按钮的意思（暂停 ↔ 继续）、账号变了就重画
static char g_tipText8[512] = "";    // 1.5.0：同上，UTF-8（XF_GetInfo 103，诊断与测试用；g_cs 保护）
static std::wstring g_account;       // 1.5.0：软件账号（XO_ACCOUNT；g_cs 保护）。鼠标停在悬浮窗上显示它本身，同原悬浮窗给各子控件挂的工具提示
// 换皮肤时的实时预览（界面线程；见后面“皮肤画廊”一节）
static volatile LONG g_previewSkin = 0;  // 悬浮窗正在临时显示的皮肤（0＝没有）
static bool g_previewCommit = false;     // 已经选定、等易语言换上（换上之前继续显示，免得闪回原来的皮肤）
static volatile LONG g_skinSeq = 0;      // XF_SetSkin 调用的次数：选定之后易语言（或别处）再设皮肤，预览就让位给真实设置
static LONG g_previewSeq = 0;
static bool g_galOpen = false;           // 皮肤画廊开着
static void Render();
static void GalleryClose(bool cancel);
static void GalleryOpen();
static void CommitPreview(int sk);
static void SetPreview(int sk);
static void HideTip();
static int TipKeyFor(int id);
static void Fire(int ev, int arg = 0) {
  XfCallback cb; Lock(); cb = g_cb; Unlock();
  if (cb) cb(ev, arg);
}
bool XfSyncFontDir();
// 字体缓存跟上最新的语言与字体目录（与 RenderTo 开头同样两步）。菜单、提示、画廊可能比投递的重画先到：不同步就会用上一种语言的字体
// （真机少见：用错字体、宽度差几个像素；Wine 里简体中文字成了方框）。字体目录刚变时清掉上一帧的要素，下一次重画一定换上新字体
static void SyncFonts(Ui& u, int lang) { if (XfSyncFontDir()) u.lastKey.clear(); u.fonts.setLang(lang); }
// 菜单用的上下文（量字宽、画菜单项）：当前状态、DPI、语言、深浅色
static Ctx MenuCtx() {
  Ui& u = *U_;
  if (!u.measureBmp) { u.measureBmp = new Bitmap(4, 4, PixelFormat32bppPARGB); u.measureG = new Graphics(u.measureBmp); u.measureG->SetTextRenderingHint(TextRenderingHintAntiAliasGridFit); }
  LONG seq; Lock(); u.s = g_state; seq = g_skinSeq; Unlock();
  if (g_previewCommit && (u.s.skin == (int)g_previewSkin || seq != g_previewSeq)) {  // 与 Render 同一条规则：易语言已经设过皮肤，“等换上”就结束（菜单可能比投递的重画先到）
    g_previewCommit = false; g_previewSkin = 0; KillTimer(g_hwnd, TM_PREVEND); u.lastKey.clear();
  }
  if (g_previewSkin) u.s.skin = (int)g_previewSkin;  // 正在预览别的款：提示等跟着预览的那款
  SyncFonts(u, u.s.lang);
  float k0 = (u.dpi > 0 ? u.dpi : 96) / 96.f;  // 菜单与提示只按系统缩放，不跟用户选的大小；也不改 u.k（那是悬浮窗本身的缩放，拖动门槛等还在用）
  Ctx c; c.g = u.measureG; c.draw = false; c.k = k0; c.s = &u.s; c.lang = u.s.lang; c.rtl = u.s.rtl;
  c.dark = g_testDark >= 0 ? g_testDark != 0 : u.dark; c.fonts = &u.fonts;
  return c;
}
// ---- 只有图标的按钮：悬停 0.6 秒后在上方（放不下时在下方）显示文字提示，配色跟皮肤
static int TipKeyFor(int id) {
  Ui& u = *U_; int sk = u.s.skin;
  bool sp = u.s.sfx.state == 1, bp = u.s.bgm.state == 1;
  switch (id) {
    case H_PAUSE: return (sp || bp) ? S_PAUSE : S_RESUME;
    case H_STOP: return SkinTraitsOf(sk).stopLabeled ? -1 : S_STOP;  // 急停按钮上有字的皮肤（控台、组件卡）不再提示
    case H_OPEN: return M_OPEN;
    case H_BPREV: return M_PREV;
    case H_BNEXT: return M_NEXT;
    case H_BTOGGLE: return bp ? S_PAUSE : M_PLAY;
    case H_STOGGLE: return sp ? S_PAUSE : S_RESUME;
    case H_DUCK_S: case H_DUCK_B: return SkinTraitsOf(sk).stopLabeled ? -1 : M_UNDUCK;  // 控台、组件卡的闪避按钮上有字；别的皮肤在悬停那一排里是只有图标的按钮
  }
  return -1;
}
// 1.5.0：鼠标停在 id 上要的提示——只有图标的按钮提示自己的作用（TipKeyFor）；悬浮窗上其它地方（空白处、开关、切换键等有字的地方）提示软件账号本身：
// 原悬浮窗给每个子控件都挂了内容为软件账号的工具提示，同时开着两个账号（防止多开按账号算，两个账号可以同时开）时靠它分清是哪个账号的悬浮窗。
// 没有账号、右键菜单或皮肤画廊开着时不提示账号（没有账号时与 1.4.0 完全一样）；贴边收起着时等展开了再显示（见 TM_TIP）。
// body＝鼠标在悬浮窗本身上：四周的柔和投影（画布边距）也收鼠标（分层窗口按透明度判断，不是全透明就收），停在那里看着不在悬浮窗上，不提示账号（原悬浮窗只在子控件上提示）
static int TipWant(int id, bool body) {
  int k = TipKeyFor(id); if (k >= 0) return k;
  if (!body || g_galOpen || g_inMenu) return -1;
  bool has; Lock(); has = !g_account.empty(); Unlock();
  return has ? (int)TIP_ACCOUNT : -1;
}
// 要的提示此刻的文字（与显示着的比，变了就重画）
static std::wstring TipTextNow(int key) {
  if (key == TIP_ACCOUNT) { Lock(); std::wstring a = g_account; Unlock(); return a; }
  return U_ ? I18n(U_->s.lang, key) : std::wstring();
}
// 提示对着的地方（内容坐标）：首次使用提示、账号对着整个悬浮窗；按钮的提示对着鼠标下那个按钮（与原来一样取最后一个同号的可点区域）。找不到返回假
static bool TipTargetRect(int key, RectF* out) {
  Ui& u = *U_;
  if (key == TIP_HINT || key == TIP_ACCOUNT) { *out = RectF(0, 0, u.W, u.H); return true; }
  const RectF* hr = nullptr; for (auto& h : u.hits) if (h.id == u.hoverId) hr = &h.r;
  if (!hr) return false;
  *out = *hr; return true;
}
static void TipScreenRect(const RectF& hr, RECT* r) {  // 换成屏幕坐标（阿拉伯语的画布是镜像的）
  Ui& u = *U_; float hx = hr.X; if (u.rtl) hx = u.W - hr.X - hr.Width;
  r->left = u.winPos.x + u.m + (LONG)hx; r->top = u.winPos.y + u.m + (LONG)hr.Y; r->right = u.winPos.x + u.m + (LONG)(hx + hr.Width); r->bottom = u.winPos.y + u.m + (LONG)(hr.Y + hr.Height);
}
// 1.5.0：软件账号（XO_ACCOUNT）：去掉控制字符（C0、DEL、C1）与双向控制字符（只显示一行账号，不让它们改字的顺序）、首尾空白，最多 64 个字（不切开代理对）。
// 账号按注册规则是 5～16 位英文或数字，登录前去过首尾空格与换行；这里只防异常的值把提示撑宽、排乱
static std::wstring CleanAccount(const std::wstring& a) {
  std::wstring r; r.reserve(a.size());
  for (wchar_t ch : a) {
    if (ch < 0x20 || ch == 0x7F || (ch >= 0x80 && ch < 0xA0)) continue;
    if (ch == 0x061C || ch == 0x200E || ch == 0x200F || (ch >= 0x202A && ch <= 0x202E) || (ch >= 0x2066 && ch <= 0x2069)) continue;
    r += ch;
  }
  auto sp = [](wchar_t ch) { return ch == L' ' || ch == 0x00A0 || ch == 0x3000; };
  size_t b = 0, e = r.size();
  while (b < e && sp(r[b])) b++;
  while (e > b && sp(r[e - 1])) e--;
  r = r.substr(b, e - b);
  if (r.size() > 64) { size_t n = 64; if (r[n - 1] >= 0xD800 && r[n - 1] <= 0xDBFF) n--; r.resize(n); }
  return r;
}
// 贴分层窗口的画面（悬浮窗、提示、画廊共用）：失败多半是别的模块对窗口调过 SetLayeredWindowAttributes（之后逐像素透明的提交一律失败，
// 微软文档：要把分层样式摘下再挂上），恢复后再交一次。提示、画廊原来没有这一步：换肤库改过它们时提示看不见、画廊打不开（同悬浮窗，见 EnsureOwnWindowState 前的说明）
static bool UlwPush(HWND w, HDC sdc, POINT* dst, SIZE* sz, HDC mdc, POINT* src, BLENDFUNCTION* bf) {
  if (UpdateLayeredWindow(w, sdc, dst, sz, mdc, src, 0, bf, ULW_ALPHA)) return true;
  LONG_PTR ex = GetWindowLongPtrW(w, GWL_EXSTYLE);
  SetWindowLongPtrW(w, GWL_EXSTYLE, ex & ~WS_EX_LAYERED); SetWindowLongPtrW(w, GWL_EXSTYLE, ex | WS_EX_LAYERED);
  bool ok = UpdateLayeredWindow(w, sdc, dst, sz, mdc, src, 0, bf, ULW_ALPHA) != 0;
  if (ok) InterlockedIncrement(&g_selfFix);
  return ok;
}
static bool StripRegion(HWND w) {  // 被别的模块设了窗口区域（会被裁掉）：去掉
  HRGN rg = CreateRectRgn(0, 0, 0, 0); bool had = false;
  if (rg) { if (GetWindowRgn(w, rg) != ERROR) { SetWindowRgn(w, nullptr, TRUE); had = true; } DeleteObject(rg); }
  return had;
}
static void HideTip() {
  KillTimer(g_hwnd, TM_TIP); KillTimer(g_hwnd, TM_HINT); KillTimer(g_hwnd, TM_TIPPOP); g_hintText.clear(); if (g_tip && IsWindowVisible(g_tip)) ShowWindow(g_tip, SW_HIDE); g_tipKey = -1;
  g_tipTarget = -1; g_tipShown.clear(); Lock(); g_tipText8[0] = 0; Unlock();
}
static Ctx MenuCtx();
// 显示提示：首次使用提示优先，其次是鼠标下要的那个（TipWant）。返回是否显示出来了（1.5.0 起返回值：重画、重摆不成时调用方收起）
static bool ShowTip() {
  Ui& u = *U_; bool hint = !g_hintText.empty(); int key = hint ? (int)TIP_HINT : TipWant(u.hoverId, u.hoverBody);
  if (!g_tip || key < 0) return false;
  std::wstring acc; if (key == TIP_ACCOUNT) { Lock(); acc = g_account; Unlock(); if (acc.empty()) return false; }
  RectF hr; if (!TipTargetRect(key, &hr)) return false;  // 首次提示、账号：对着整个悬浮窗
  Ctx c = MenuCtx(); c.rtl = false; float k = c.k;  // 提示画在不镜像的位图上
  unsigned bg, fg; bool sq; XfMenuTheme(u.s.skin, c.dark, &bg, &fg, &sq);
  std::wstring t = hint ? g_hintText : key == TIP_ACCOUNT ? acc : c.T(key); Font* f = c.fonts->name(t, 12 * k, false);
  bool again = key == TIP_ACCOUNT && g_tipKey == TIP_ACCOUNT && g_tipShown == t && IsWindowVisible(g_tip);  // 同一个账号提示只是重摆（悬浮窗挪了、变了大小）：自己收起的计时接着走
  int m = (int)ceilf(4 * k);
  float hx = hr.X, hw = hr.Width; if (u.rtl) hx = u.W - hr.X - hr.Width;
  POINT a = {u.winPos.x + u.m + (LONG)(hx + hw / 2), u.winPos.y + u.m + (LONG)hr.Y};
  RECT wa = WorkAreaAt(a);
  float tw = TextW(c, t, f), maxw = (float)(wa.right - wa.left - 2 * m) - 16 * k;
  bool cut = maxw > 16 * k && tw > maxw; if (cut) tw = floorf(maxw);  // 1.5.0：再长也不超出屏幕，截断加省略号（账号最多 64 个字，正常用不上）
  int W = (int)ceilf(tw + 16 * k), H = (int)ceilf(24 * k);
  PixBuf pb; pb.init(W + 2 * m, H + 2 * m);
  {
    Bitmap bmp(pb.w, pb.h, pb.w * 4, PixelFormat32bppPARGB, (BYTE*)pb.px.data());
    Graphics g(&bmp); g.SetSmoothingMode(SmoothingModeAntiAlias); g.SetPixelOffsetMode(PixelOffsetModeHalf);
    Ctx d = c; d.g = &g; d.draw = true; d.rtl = false;
    SolidBrush sh(C(0x000000, 60)); FillRR(d, (float)m, m + 1.5f * k, (float)W, (float)H, sq ? 0 : 6 * k, sh);
    SolidBrush b(C(bg)); FillRR(d, (float)m, (float)m, (float)W, (float)H, sq ? 0 : 6 * k, b);
    if (!sq) StrokeRR(d, m + 0.5f, m + 0.5f, W - 1.f, H - 1.f, 6 * k, C(fg, 40), 1, false);
    Text(d, t, f, C(fg), m + 8 * k, (float)m, tw + 2, (float)H, 0, cut);
  }
  int x = a.x - pb.w / 2, y = a.y - pb.h - (int)(2 * k);
  if (y < wa.top) y = u.winPos.y + u.m + (int)(hr.Y + hr.Height) + (int)(2 * k);
  if (x < wa.left) x = wa.left; if (x + pb.w > wa.right) x = wa.right - pb.w;
  HDC sdc = GetDC(nullptr), mdc = CreateCompatibleDC(sdc);
  BITMAPINFO bi = {}; bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = pb.w; bi.bmiHeader.biHeight = -pb.h; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
  void* bits = nullptr; HBITMAP dib = CreateDIBSection(mdc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
  if (dib && bits) {
    memcpy(bits, pb.px.data(), (size_t)pb.w * pb.h * 4);
    HGDIOBJ old = SelectObject(mdc, dib);
    POINT src = {0, 0}, dst = {x, y}; SIZE sz = {pb.w, pb.h}; BLENDFUNCTION bf = {AC_SRC_OVER, 0, 255, AC_SRC_ALPHA};
    if (StripRegion(g_tip)) InterlockedIncrement(&g_selfFix);
    UlwPush(g_tip, sdc, &dst, &sz, mdc, &src, &bf);
    SelectObject(mdc, old); DeleteObject(dib);
  }
  DeleteDC(mdc); ReleaseDC(nullptr, sdc);
  SetWindowPos(g_tip, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
  g_tipKey = key; g_tipTarget = key; g_tipShown = t; TipScreenRect(hr, &g_tipAt);
  // 1.5.0：账号提示停着不动时显示 10 倍双击时间（默认 5 秒）后自己收起——系统工具提示的默认（微软 TTM_SETDELAYTIME：初始＝双击时间、自动消失＝10 倍），
  // 原悬浮窗的账号工具提示没改过这几个时间，也是这样。新显示、账号换了才重新计时；只是跟着悬浮窗重摆不重新计时（放着东西时灵动胶囊的宽度随倒计时的字宽变，
  // 原来每变一次就重新计时，提示一直不收）。别的提示照旧不限时（按钮提示只在按钮上；首次提示 8 秒）
  if (key == TIP_ACCOUNT) { if (!again) SetTimer(g_hwnd, TM_TIPPOP, 10 * GetDoubleClickTime(), nullptr); } else KillTimer(g_hwnd, TM_TIPPOP);
  { std::string t8 = WToUtf8(t); Lock(); lstrcpynA(g_tipText8, t8.c_str(), (int)sizeof(g_tipText8)); Unlock(); }
  return true;
}
// 1.5.0：显示着的提示跟上现状（每次 Render 之后）：要的提示变了（按钮的意思变了，如暂停 ↔ 继续；账号换了）就重画，不要了就收起；悬浮窗挪了、变了大小，
// 按钮挪了位置，就跟着重摆；对着的按钮不在了就收起。原来提示一直是显示时的样子：悬停着暂停按钮时音效被暂停，提示仍是「暂停」；
// 灵动胶囊放着东西时悬停向一侧长出按钮，对着整个悬浮窗的提示还在原处。菜单开着时不动（提示是置顶的，重摆会压到菜单上，见 1.3.3）
static void TipFollow() {
  if (g_tipKey < 0 || !g_tip || !U_ || g_inMenu || !IsWindowVisible(g_tip)) return;
  Ui& u = *U_; int key = (int)g_tipKey;
  if (key != TIP_HINT) {
    int want = u.hover ? TipWant(u.hoverId, u.hoverBody) : -1;
    if (want < 0) { HideTip(); return; }
    if (want != key || TipTextNow(want) != g_tipShown) { if (!ShowTip()) HideTip(); return; }
  }
  RectF hr; RECT now;
  if (!TipTargetRect(key, &hr)) { HideTip(); return; }
  TipScreenRect(hr, &now);
  // 左右只差几个像素（不到 4 像素，按系统缩放）时不动：放着东西时灵动胶囊的宽度、悬停那一排按钮的位置随倒计时的字宽变，提示跟着每秒抖一下不好看，
  // 偏这一点也还对着悬浮窗、按钮；上下变了照常重摆（提示在上方时紧挨着，不能压到悬浮窗上）。偏差按上一次摆的位置算，不会越积越多
  int tol = (int)ceilf(4.f * (u.dpi > 0 ? u.dpi : 96) / 96.f), dx = ((now.left + now.right) - (g_tipAt.left + g_tipAt.right)) / 2;
  if ((abs(dx) > tol || now.top != g_tipAt.top || now.bottom != g_tipAt.bottom) && !ShowTip()) HideTip();
}
static volatile bool g_hintPending = false;  // 首次提示：请求时窗口还没建（易语言在 XF_Start 之前就请求）或隐藏着——等它显示出来再提示
// 1.3.3：菜单开着时推迟的事，菜单一关掉就补做：要换层的（选项 3、找回悬浮窗）照常换层（毛玻璃背景跟着）；否则核对毛玻璃背景是不是还紧挨在卡片下面（GlassSync 不对时才动）；
// 首次使用提示（提示窗是置顶的，菜单开着时显示出来会压在菜单上）
static void AfterMenu(HWND h) {
  Ui* up = U_;
  if (g_zLater) { g_zLater = false; SendMessageW(h, WM_APP + 0x7B, 1, 0); }
  else if (up && g_glass && IsWindowVisible(g_glass) && IsWindowVisible(h)) GlassSync(GlassWanted(up->s.skin), up->winPos.x + up->m, up->winPos.y + up->m, (int)up->W, (int)up->H, up->k);
  if (g_hintPending && IsWindowVisible(h)) { g_hintPending = false; PostMessageW(h, WM_APP + 0x78, 0, 0); }
}
static void RunMenu(HWND h, int test) {  // 右键：弹出跟皮肤一致的菜单，选了哪项就回调对应的事件
  Ctx c = MenuCtx();
  POINT p; GetCursorPos(&p);
  g_inMenu = true; DWORD mt0 = GetTickCount();
  int cmd = XfMenuRun(h, p.x, p.y, c, U_->s, test);
  g_inMenu = false; g_menuMs = (LONG)(GetTickCount() - mt0); g_menuCmd = cmd; InterlockedIncrement(&g_menuN);
  AfterMenu(h);  // 1.3.3：菜单开着时推迟的换层、背景层次、首次提示
  if (XfMenuIsGallery(cmd)) { SetPreview(0); GalleryOpen(); return; }
  int sk = XfMenuSkinOf(cmd);
  if (sk) { CommitPreview(sk); return; }  // 选了皮肤：回调换皮肤事件，换上之前悬浮窗继续显示选的那款
  SetPreview(0); if (U_) { U_->lastKey.clear(); Render(); }  // 没选皮肤：恢复（菜单里指过别的款时）；贴边的按原样收起
  int ev = 0, arg = 0;
  if (cmd > 0 && XfMenuEvent(cmd, &ev, &arg)) Fire(ev, arg);
}

// ---- 绘制
static unsigned HashAlpha(const PixBuf& b) {
  unsigned h = 2166136261u;
  for (size_t i = 0; i < b.px.size(); i += 1) { h ^= (b.px[i] >> 24); h *= 16777619u; }
  return h ^ (unsigned)b.w * 31u ^ (unsigned)b.h;
}
static void Composite(PixBuf& canvas, float strength) {
  if (strength <= 0) return;
  Ui& u = *U_;
  unsigned hsh = HashAlpha(canvas);
  if (hsh != u.shadowHash || u.shadowW != canvas.w || u.shadowH != canvas.h) {  // 形状变了才重新模糊（播放动画时形状不变，直接用缓存）
    u.shadowHash = hsh; u.shadowW = canvas.w; u.shadowH = canvas.h;
    u.shadowA.assign((size_t)canvas.w * canvas.h, 0);
    int dy = (int)roundf(5 * u.k);
    for (int y = 0; y < canvas.h; y++) for (int x = 0; x < canvas.w; x++) {
      int sy = y - dy;
      if (sy >= 0) u.shadowA[(size_t)y * canvas.w + x] = (unsigned char)(canvas.px[(size_t)sy * canvas.w + x] >> 24);
    }
    BoxBlurAlpha(u.shadowA, canvas.w, canvas.h, (int)roundf(6 * u.k));
  }
  for (size_t i = 0; i < canvas.px.size(); i++) {
    int al = (int)(u.shadowA[i] * strength);
    if (al <= 0) continue;
    unsigned top = canvas.px[i], ta = top >> 24;
    if (ta == 255) continue;
    unsigned inv = 255 - ta; unsigned add = (unsigned)al * inv / 255;
    canvas.px[i] = ((ta + add) << 24) | (top & 0x00FFFFFF);
  }
}
struct RenderOut { PixBuf canvas; float W, H; int m; };
// 可点范围不足 minS 的按钮：以它为中心放大到 minS（不超出内容区）；相邻的小按钮放大后重叠时，在原来两者间隙的中线处分开
static void ExpandHits(std::vector<Hit>& hs, float minS, float W, float H) {
  std::vector<RectF> orig; orig.reserve(hs.size());
  for (auto& h : hs) orig.push_back(h.r);
  for (auto& h : hs) {
    RectF& r = h.r;
    if (r.Width < minS) { r.X -= (minS - r.Width) / 2; r.Width = minS; }
    if (r.Height < minS) { r.Y -= (minS - r.Height) / 2; r.Height = minS; }
    if (r.X < 0) { r.Width += r.X; r.X = 0; }
    if (r.Y < 0) { r.Height += r.Y; r.Y = 0; }
    if (r.X + r.Width > W) r.Width = W - r.X;
    if (r.Y + r.Height > H) r.Height = H - r.Y;
  }
  for (size_t i = 0; i < hs.size(); i++) for (size_t j = i + 1; j < hs.size(); j++) {
    const RectF &a = orig[i], &b = orig[j];
    RectF &A = hs[i].r, &B = hs[j].r;
    if (A.X >= B.X + B.Width || B.X >= A.X + A.Width || A.Y >= B.Y + B.Height || B.Y >= A.Y + A.Height) continue;  // 放大后不重叠
    bool small = a.Width < minS || a.Height < minS || b.Width < minS || b.Height < minS;
    if (!small) continue;
    if (a.X + a.Width <= b.X) { float mid = (a.X + a.Width + b.X) / 2; if (A.X + A.Width > mid) A.Width = mid - A.X; if (B.X < mid) { B.Width -= mid - B.X; B.X = mid; } }
    else if (b.X + b.Width <= a.X) { float mid = (b.X + b.Width + a.X) / 2; if (B.X + B.Width > mid) B.Width = mid - B.X; if (A.X < mid) { A.Width -= mid - A.X; A.X = mid; } }
    else if (a.Y + a.Height <= b.Y) { float mid = (a.Y + a.Height + b.Y) / 2; if (A.Y + A.Height > mid) A.Height = mid - A.Y; if (B.Y < mid) { B.Height -= mid - B.Y; B.Y = mid; } }
    else if (b.Y + b.Height <= a.Y) { float mid = (b.Y + b.Height + a.Y) / 2; if (B.Y + B.Height > mid) B.Height = mid - B.Y; if (A.Y < mid) { A.Height -= mid - A.Y; A.Y = mid; } }
    // 原本就重叠（如大面积的开关区里放着小按钮）：不动，后加的优先
  }
}
static void RenderTo(RenderOut& out, int dpi, bool forSnapshot) {
  Ui& u = *U_;
  XfSyncFontDir();
  g_glassLiveDraw = GlassWanted(u.s.skin) && GlassEnsure() && (g_glassState == 1 || g_glassForce);  // 毛玻璃组件卡有实时模糊时底色淡一些（84%）
  u.k = dpi / 96.f * XfScalePct(u.s) / 100.f;  // 系统缩放 × 用户选的大小
  u.fonts.setLang(u.s.lang);
  if (!u.measureBmp) { u.measureBmp = new Bitmap(4, 4, PixelFormat32bppPARGB); u.measureG = new Graphics(u.measureBmp); u.measureG->SetTextRenderingHint(TextRenderingHintAntiAliasGridFit); }
  XState rs = XfRoleView(u.s);  // 1.3.0：按皮肤的角色只给它要显示的那一路
  Ctx c; c.g = u.measureG; c.draw = false; c.k = u.k; c.s = &rs; c.lang = u.s.lang; c.rtl = u.s.rtl;
  c.now = g_freeze ? (DWORD)g_freeze : GetTickCount();
  c.hover = g_testHover >= 0 ? g_testHover != 0 : (u.hover && u.hoverIntent);
  c.anim = !u.mq.reduce;  // 系统关闭了动画：音浪、转动、流光都画成静止的样子
  c.hoverId = u.hoverId; c.pressId = u.pressed ? u.pressId : 0;
  c.dark = g_testDark >= 0 ? g_testDark != 0 : u.dark;
  c.docked = g_dock != 0 && !(u.dockOpen || g_testDockOpen || g_galOpen || g_inMenu);  // 菜单、画廊开着时保持展开（看得见预览）
  if (c.docked) c.hover = false;
  c.dockEdge = g_dock;
  c.fonts = &u.fonts;
  std::vector<Hit> dummy; c.hits = &dummy;
  SizeF sz = SkinLayout(u.s.skin, c);
  float W = ceilf(sz.Width), H = ceilf(sz.Height);
  int m = (int)ceilf(16 * u.k);
  out.W = W; out.H = H; out.m = m;
  out.canvas.init((int)W + 2 * m, (int)H + 2 * m);
  {
    Bitmap bmp(out.canvas.w, out.canvas.h, out.canvas.w * 4, PixelFormat32bppPARGB, (BYTE*)out.canvas.px.data());
    Graphics g(&bmp);
    g.SetSmoothingMode(SmoothingModeAntiAlias);
    g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit);
    g.SetPixelOffsetMode(PixelOffsetModeHalf);
    g.SetInterpolationMode(InterpolationModeHighQualityBicubic);
    if (u.s.rtl) { Matrix mx(-1, 0, 0, 1, (REAL)(m + W), (REAL)m); g.SetTransform(&mx); }
    else g.TranslateTransform((REAL)m, (REAL)m);
    c.g = &g; c.draw = true; c.W = W; c.H = H; c.mq = &u.mq; if (!forSnapshot) u.mq.active = false;
    std::vector<Hit> hits; c.hits = &hits;
    SkinLayout(u.s.skin, c);
    ExpandHits(hits, 24.f * dpi / 96.f, W, H);  // 小按钮的可点范围至少 24×24（WCAG 2.2 的最小目标尺寸），画的大小不变
    if (!forSnapshot || true) u.hits = hits;
  }
  Composite(out.canvas, SkinTraitsOf(u.s.skin).shadow);
}
static int SkinFps() {
  Ui& u = *U_;
  int f = SkinAnimFps(u.s.skin, XfRoleView(u.s));  // 1.3.0：只看这款显示的那一路（只管音效的皮肤只放背景音乐时不按帧率重画）
  if (g_freeze || u.mq.reduce) f = 0;  // 系统关闭了动画：不按帧率重画（倒计时照常随易语言的推送每秒更新）
  return f;
}
static volatile LONG g_ulwFail = 0;  // 诊断：贴画面失败的次数（XF_GetInfo 94）
// ---- 窗口被别的模块改动后自己恢复（1.2.0；同 DeskNotify 的 EnsureOwnWindowState）
// 进程里可能有改“所有窗口”的模块：换肤库 SkinSharp（新版 XhhSkin 不可用时退回它，自动模式给进程里所有窗口换肤——DeskNotify 的卡片窗口就被它改过）、
// 辅助工具、窗口透明 / 置顶类小工具。悬浮窗被设了窗口区域、加了鼠标穿透、摘了分层样式或调过 SetLayeredWindowAttributes（之后 UpdateLayeredWindow 一律失败，
// 要把分层样式摘下再挂上——微软文档 SetLayeredWindowAttributes 的说明），就一直看不见或画面不再更新。Wine 里在建窗口时模拟过：原来一帧都贴不上、或被裁成 1×1。
// 建好窗口后、之后每 2 秒（以及贴画面失败时）核对一次，不是自己的样子就恢复；窗口过程被接管只记下来（诊断 101），不去动它
static LRESULT CALLBACK WndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp);
static bool EnsureOwnWindowState() {
  HWND h = g_hwnd; if (!h) return false;
  bool top; Lock(); top = g_opt[3] != 0; Unlock();
  const LONG_PTR want = WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE;
  LONG_PTR ex = GetWindowLongPtrW(h, GWL_EXSTYLE), st = GetWindowLongPtrW(h, GWL_STYLE); bool fixed = false;
  if ((ex & want) != want || (ex & WS_EX_TRANSPARENT)) { SetWindowLongPtrW(h, GWL_EXSTYLE, (ex | want) & ~WS_EX_TRANSPARENT); fixed = true; }  // 要能点、要逐像素透明
  if (st & (WS_CAPTION | WS_THICKFRAME | WS_SYSMENU | WS_DLGFRAME | WS_BORDER)) {  // 被加了标题栏、边框
    SetWindowLongPtrW(h, GWL_STYLE, (st & WS_VISIBLE) | WS_POPUP);
    SetWindowPos(h, nullptr, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED); fixed = true;
  }
  if (StripRegion(h)) fixed = true;  // 被设了窗口区域（裁掉了）
  if (top && !g_inMenu && !(GetWindowLongPtrW(h, GWL_EXSTYLE) & WS_EX_TOPMOST)) { SetWindowPos(h, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE); fixed = true; }  // 设了置顶却被挪出置顶层（1.3.3：右键菜单开着时不提——提回置顶层最上面就压到菜单上；菜单关掉后，之后 2 秒内的核对再恢复）
  if (fixed) InterlockedIncrement(&g_selfFix);
  InterlockedExchange(&g_procTaken, GetWindowLongPtrW(h, GWLP_WNDPROC) != (LONG_PTR)WndProc ? 1 : 0);
  return fixed;
}
static bool PlaceAndShow(RenderOut& r) {  // 返回是否真的贴上了
  Ui& u = *U_;
  HWND h = g_hwnd;
  SIZE ws = {r.canvas.w, r.canvas.h};
  // 锚点：一般是内容左上角（靠屏幕右侧时是右上角，内容变宽时向左长）
  float ax = g_anchorRight ? r.W : 0, ay = 0;
  POINT anchor; Lock(); anchor = g_anchor; Unlock();
  int x = anchor.x - r.m - (int)roundf(ax), y = anchor.y - r.m - (int)roundf(ay);
  RECT wa = HomeWorkArea(anchor, g_anchorRight, g_dock);  // 原来是 WorkAreaAt(anchor)：锚点在相邻那块屏上时会被摆过去，见 HomeWorkArea 前的说明
  { RECT pw = PrimaryRect(true); Lock(); g_onPrimary = EqualRect(&wa, &pw) ? 1 : 0; Unlock(); }  // 在不在主屏：摆放时就定了（贴画面失败时也准）
  if (g_dock && !(u.dockOpen || g_testDockOpen || g_galOpen || g_inMenu)) {
    if (g_dock == 1) x = wa.left - r.m;
    else if (g_dock == 2) x = wa.right - (int)r.W - r.m;
    else y = wa.top - r.m;
    if (g_dock == 3) { if (x + r.m < wa.left) x = wa.left - r.m; if (x + r.m + (int)r.W > wa.right) x = wa.right - r.m - (int)r.W; }
    else { if (y + r.m < wa.top) y = wa.top - r.m; if (y + r.m + (int)r.H > wa.bottom) y = wa.bottom - r.m - (int)r.H; }
  } else {
    if (g_dock == 1) x = wa.left + 4 - r.m;
    else if (g_dock == 2) x = wa.right - 4 - (int)r.W - r.m;
    else if (g_dock == 3) y = wa.top + 4 - r.m;
    if (x + r.m < wa.left) x = wa.left - r.m;
    if (y + r.m < wa.top) y = wa.top - r.m;
    if (x + r.m + (int)r.W > wa.right) x = wa.right - r.m - (int)r.W;
    if (y + r.m + (int)r.H > wa.bottom) y = wa.bottom - r.m - (int)r.H;
  }
  if (u.dragging) { x = u.winPos.x; y = u.winPos.y; }
  HDC sdc = GetDC(nullptr);
  HDC mdc = CreateCompatibleDC(sdc);
  BITMAPINFO bi = {}; bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = ws.cx; bi.bmiHeader.biHeight = -ws.cy; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
  void* bits = nullptr;
  HBITMAP dib = mdc ? CreateDIBSection(mdc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0) : nullptr;
  bool ok = false;
  if (dib && bits) {
    memcpy(bits, r.canvas.px.data(), (size_t)ws.cx * ws.cy * 4);
    HGDIOBJ old = SelectObject(mdc, dib);
    POINT src = {0, 0}, dst = {x, y};
    BLENDFUNCTION bf = {AC_SRC_OVER, 0, 255, AC_SRC_ALPHA};
    ok = UlwPush(h, sdc, &dst, &ws, mdc, &src, &bf);  // 失败时把分层样式摘下再挂上、再交一次（别的模块调过 SetLayeredWindowAttributes；同 DeskNotify）
    if (ok) InterlockedIncrement(&g_frames);  // 只数真正贴上去的帧（原来失败也算）
    SelectObject(mdc, old);
    DeleteObject(dib);
  } else if (dib) DeleteObject(dib);
  if (mdc) DeleteDC(mdc);
  if (sdc) ReleaseDC(nullptr, sdc);
  if (!ok) { InterlockedIncrement(&g_ulwFail); return false; }
  u.winPos = {x, y}; u.winSize = ws; u.W = r.W; u.H = r.H; u.m = r.m;
  GlassSync(GlassWanted(u.s.skin), x + r.m, y + r.m, (int)r.W, (int)r.H, u.k);  // 毛玻璃组件卡：实时模糊的背景窗口跟上卡片
  Lock(); g_infoX = anchor.x; g_infoY = anchor.y; g_infoW = (int)r.W; g_infoH = (int)r.H; Unlock();
  return true;
}
static void Render() {
  Ui& u = *U_;
  bool visible;
  LONG seq; Lock(); u.s = g_state; g_dirtyPosted = false; visible = g_visible; seq = g_skinSeq; Unlock();
  if (g_previewCommit && (u.s.skin == (int)g_previewSkin || seq != g_previewSeq)) { g_previewCommit = false; g_previewSkin = 0; KillTimer(g_hwnd, TM_PREVEND); }  // 易语言已换上选定的那款
  if (g_previewSkin) u.s.skin = (int)g_previewSkin;  // 临时显示预览的那款（不改设置）
  u.rtl = u.s.rtl;
  if (g_freeze) { u.s.sfx.stamp = 0; u.s.bgm.stamp = 0; }
  if (!visible) { GalleryClose(true); HideTip(); GlassHide(); if (IsWindowVisible(g_hwnd)) ShowWindow(g_hwnd, SW_HIDE); KillTimer(g_hwnd, TM_ANIM); u.fps = 0; u.lastKey.clear(); Lock(); g_animating = false; Unlock(); return; }  // 隐藏时清掉上一帧的要素：再显示时一定重画并 ShowWindow
  if (g_tipKey >= 0 && g_hintText.empty() && (!u.hover || TipWant(u.hoverId, u.hoverBody) < 0)) HideTip();  // 首次提示不跟鼠标，按时消失或一碰悬浮窗就消失；其余提示只跟着鼠标下要的那个（重画、重摆在 TipFollow）
  u.dpi = WindowDpi(g_hwnd); Lock(); g_infoDpi = u.dpi; Unlock();
  {
    int f = SkinFps();
    if (f != u.fps) { u.fps = f; if (f > 0) SetTimer(g_hwnd, TM_ANIM, 1000 / f, nullptr); else KillTimer(g_hwnd, TM_ANIM); }
    Lock(); g_animating = f > 0; Unlock();
  }
  if (XfSyncFontDir()) u.lastKey.clear();  // 字体包刚下好：换了字体要重画（不在画面要素里，单独看）
  {
    DWORD now = g_freeze ? (DWORD)g_freeze : GetTickCount();
    int fps = SkinFps();
    bool cont = SkinTraitsOf(u.s.skin).cont;  // 音浪、转动、流光：每帧都在动
    std::wstring key; key.reserve(256);
    XState ks = XfRoleView(u.s);  // 1.3.0：画面要素也只看这款显示的那一路：不显示的那一路的倒计时在变，不重画
    auto num = [&](long long v) { wchar_t d[24]; int n = 0; bool neg = v < 0; unsigned long long x = neg ? (unsigned long long)(-v) : (unsigned long long)v; do { d[n++] = (wchar_t)(L'0' + x % 10); x /= 10; } while (x && n < 23); if (neg) key += L'-'; while (n) key += d[--n]; key += L'|'; };
    num(u.s.skin); num(u.dpi); num(u.hover); num(u.hoverIntent); num(u.hoverId); num(u.pressed ? u.pressId : 0); num(g_dock); num(u.dockOpen);
    num(u.dark); num(u.s.armed); num(u.s.numlock); num(ks.duckS); num(ks.duckB); num(u.s.loop); num(u.s.order); num(u.s.lang);
    num(g_testHover); num(g_testDark); num(g_testDockOpen); num(g_galOpen); num(g_inMenu); num(g_glassForce); num(g_glassAllow); num(GlassWanted(u.s.skin)); num(g_glassState);  /* 毛玻璃的开关、系统设置变了：要重画并重新摆背景窗口 */ num(g_anchor.x); num(g_anchor.y); num(g_anchorRight); num(u.dragging);
    key += u.s.key; key += L'|';
    const Track* ts[2] = {&ks.sfx, &ks.bgm};
    for (const Track* tr : ts) {
      TrackView v = ViewOf(*tr, now);
      num(tr->state); key += tr->name; key += L'|'; num((v.remainMs + 999) / 1000); num((long long)(v.p * 200)); num((v.elapsedMs + 999) / 1000);
    }
    if (cont && fps > 0) num(now / (DWORD)(1000 / fps));
    num(XfScalePct(u.s));  // 大小变了要重画
    if (u.mq.active) num(now / 50);  // 曲名在滚：画面随时间变
    if (key == u.lastKey && u.winSize.cx > 0) { TipFollow(); return; }  // 与上一帧完全一样：不重画（提示照样跟上账号、按钮意思的变化）
    u.lastKey = key;
  }
  RenderOut r; RenderTo(r, u.dpi, false);
  if (u.ulwFails) EnsureOwnWindowState();  // 上一帧没贴上：先核对窗口是不是被别的模块改了
  if (!PlaceAndShow(r)) {  // 没贴上（锁屏或安全桌面、远程桌面切换、GDI 资源一时不足等）：这一帧的要素不算数，稍后重试。
    // 原来不管成败都记下要素，空闲时画面要素不再变，就一直不重画——启动时第一帧没贴上，悬浮窗就一直看不见（托盘菜单却显示“隐藏悬浮窗”）；Wine 里注入失败复现过
    u.lastKey.clear();
    UINT d = u.ulwFails < 3 ? 500u << u.ulwFails : 4000u;
    u.ulwFails++;
    SetTimer(g_hwnd, TM_RETRY, d, nullptr);
    return;
  }
  if (u.ulwFails) { u.ulwFails = 0; KillTimer(g_hwnd, TM_RETRY); }
  if (u.mq.active && u.fps < 20) { u.fps = 20; SetTimer(g_hwnd, TM_ANIM, 50, nullptr); Lock(); g_animating = true; Unlock(); }  // 曲名在滚：至少每秒 20 帧
  if (!IsWindowVisible(g_hwnd)) ShowWindow(g_hwnd, SW_SHOWNOACTIVATE);
  if (g_hintPending && IsWindowVisible(g_hwnd) && !g_inMenu) { g_hintPending = false; PostMessageW(g_hwnd, WM_APP + 0x78, 0, 0); }  // 首次提示：窗口显示出来了
  TipFollow();  // 1.5.0：显示着的提示跟上这一帧（悬浮窗的位置大小、按钮的意思与位置）
}

// ---- PNG
static bool PngClsid(CLSID* id) {
  UINT n = 0, sz = 0; GetImageEncodersSize(&n, &sz);
  if (!sz) return false;
  std::vector<BYTE> buf(sz); ImageCodecInfo* ici = (ImageCodecInfo*)buf.data();
  GetImageEncoders(n, sz, ici);
  for (UINT i = 0; i < n; i++) if (wcscmp(ici[i].MimeType, L"image/png") == 0) { *id = ici[i].Clsid; return true; }
  return false;
}
struct SnapReq { std::wstring path; int pct; bool ok; };
static bool Snapshot(SnapReq* q) {
  Ui& u = *U_;
  Lock(); u.s = g_state; Unlock();
  if (g_freeze) { u.s.sfx.stamp = 0; u.s.bgm.stamp = 0; }
  int dpi = q->pct > 0 ? q->pct * 96 / 100 : WindowDpi(g_hwnd);
  RenderOut r; g_testLogNow = true; RenderTo(r, dpi, true); g_testLogNow = false;
  u.shadowHash = 0;  // 下次正常绘制重新算阴影（尺寸可能不同）
  u.lastKey.clear();
  Bitmap bmp(r.canvas.w, r.canvas.h, r.canvas.w * 4, PixelFormat32bppPARGB, (BYTE*)r.canvas.px.data());
  // PNG 要非预乘：复制成 ARGB
  Bitmap out(r.canvas.w, r.canvas.h, PixelFormat32bppARGB);
  { Graphics g(&out); g.Clear(Color(0, 0, 0, 0)); g.SetCompositingMode(CompositingModeSourceCopy); g.DrawImage(&bmp, 0, 0, r.canvas.w, r.canvas.h); }
  CLSID cls; if (!PngClsid(&cls)) return false;
  return out.Save(q->path.c_str(), &cls, nullptr) == Ok;
}

// ---- 鼠标
static int HitAt(int cx, int cy) {
  Ui& u = *U_;
  float x = (float)(cx - u.m), y = (float)(cy - u.m);
  if (u.rtl) x = u.W - x;
  for (int i = (int)u.hits.size() - 1; i >= 0; i--) {
    const RectF& r = u.hits[i].r;
    if (x >= r.X && x < r.X + r.Width && y >= r.Y && y < r.Y + r.Height) return u.hits[i].id;
  }
  return 0;
}
static int HitToEvent(int id) {
  Ui& u = *U_;
  switch (id) {
    case H_SWITCH: return XE_TOGGLE_HOTKEYS;
    case H_KEY: return XE_SET_KEY;
    case H_NUMFIX: return XE_NUMLOCK;
    case H_PAUSE: return XE_PAUSE_ALL;
    case H_STOP: return XE_STOP_ALL;
    case H_OPEN: return XE_OPEN_PANEL;
    case H_DUCK_S: return XE_DUCK_SFX;
    case H_DUCK_B: return XE_DUCK_BGM;
    case H_DUCK_START: return XE_DUCK_START;
    case H_BPREV: return XE_BGM_PREV;
    case H_BTOGGLE: return XE_BGM_TOGGLE;
    case H_BNEXT: return XE_BGM_NEXT;
    case H_STOGGLE: return XE_SFX_TOGGLE;
  }
  (void)u;
  return 0;
}
static void EndDrag() {
  Ui& u = *U_;
  u.dragging = false;
  // 新的锚点：内容的左上角或右上角（窗口中心在屏幕右半边时用右上角）；碰到屏幕左、右、上边缘就贴边
  POINT tl = {u.winPos.x + u.m, u.winPos.y + u.m};
  POINT center = {tl.x + (LONG)u.W / 2, tl.y + (LONG)u.H / 2};
  RECT wa = WorkAreaAt(center);
  int snap = (int)(8 * u.k);
  int dock = 0;
  if (tl.x <= wa.left + snap / 2) dock = 1;
  else if (tl.x + (LONG)u.W >= wa.right - snap / 2) dock = 2;
  else if (tl.y <= wa.top + snap / 2) dock = 3;
  bool right = center.x > (wa.left + wa.right) / 2;
  // 贴边判断之后，把内容夹回中心所在那块屏的工作区再算锚点：锚点从此一定在这块屏上（原来越过交界松手时锚点在相邻那块屏，见 HomeWorkArea 前的说明）
  if (tl.x + (LONG)u.W > wa.right) tl.x = wa.right - (LONG)u.W;
  if (tl.x < wa.left) tl.x = wa.left;
  if (tl.y + (LONG)u.H > wa.bottom) tl.y = wa.bottom - (LONG)u.H;
  if (tl.y < wa.top) tl.y = wa.top;
  Lock();
  g_dock = dock; g_anchorRight = right;
  g_anchor.x = right ? tl.x + (LONG)u.W : tl.x; g_anchor.y = tl.y;
  if (dock) u.dockOpen = false;
  g_posSrc = PS_DRAG;
  Unlock();
  Render();
  MemSave();
  Fire(XE_MOVED);
}
// 找回悬浮窗（XO_RECOVER，托盘菜单「找回悬浮窗」）：移到鼠标旁边（用户刚点了托盘菜单，视线就在那儿）、不贴边、显示出来；
// 放在鼠标上方（上方放不下就放下方），不压在鼠标下面（免得一出现就是悬停展开的样子）；记下位置并报“位置变了”，易语言照常存配置
static void Recover() {
  if (!U_) return;
  Ui& u = *U_;
  GalleryClose(true); HideTip();
  if (u.pressed || u.dragging) { u.pressed = false; u.dragging = false; u.pressId = 0; ReleaseCapture(); }
  POINT c = {0, 0};
  if (!GetCursorPos(&c)) { RECT pw = PrimaryRect(true); c.x = (pw.left + pw.right) / 2; c.y = (pw.top + pw.bottom) / 2; }  // 取不到鼠标位置（安全桌面等，极少见）：放在主屏中间
  RECT wa = WorkAreaAt(c);
  Lock(); g_dock = 0; g_visible = true; Unlock();
  u.dockOpen = false; u.lastKey.clear();
  int dpi = MonitorDpiAt(c, WindowDpi(g_hwnd));  // 按鼠标所在那块屏的 DPI 量：两块屏缩放不同时，挪过去后系统改了 DPI 再重画，大小与这里量的一致，不会压到鼠标
  RenderOut r; RenderTo(r, dpi, false);  // 不贴边时的大小
  int W = (int)r.W, H = (int)r.H, gap = MulDiv(16, dpi, 96);
  int x = c.x - W / 2, y = c.y - gap - H;
  if (y < wa.top) y = c.y + gap;
  if (x + W > wa.right) x = wa.right - W;
  if (x < wa.left) x = wa.left;
  if (y + H > wa.bottom) y = wa.bottom - H;
  if (y < wa.top) y = wa.top;
  bool right = x + W / 2 > (wa.left + wa.right) / 2;  // 与拖动结束同一规则：在屏的右半边时锚点在右上角（内容变宽向左长）
  Lock(); g_anchorRight = right; g_anchor.x = right ? x + W : x; g_anchor.y = y; g_posSrc = PS_RECOVER; Unlock();
  EnsureOwnWindowState();  // 窗口若被别的模块改过（被裁、穿透、摘了分层），先恢复
  Render();
  SendMessageW(g_hwnd, WM_APP + 0x7B, 1, 0);  // 提到所在层的最上面（鼠标那儿可能有别的置顶窗口挡着），毛玻璃背景跟着（同选项 3 的换层）
  MemSave();
  Fire(XE_MOVED);
}
// 显示设置变了（接上 / 拔掉显示器、改分辨率、改排列）：重算布局签名；用了位置记忆、而且这种布局记过位置，就挪到那里
// （拔掉外接屏回到笔记本时回到笔记本上的老位置，再接上时回到外接屏上——与 Windows 11“按显示器连接记住窗口位置”相同）；没记过就照旧按锚点摆（就近夹进可见范围）
static void LayoutChanged() {
  int n = 0; DWORD sig = LayoutSig(&n), old; bool use;
  Lock(); old = g_layoutSig; g_layoutSig = sig; g_monCount = n; use = g_memUse; Unlock();
  if (!use || sig == old) return;
  MemPos p = MemRead(sig);
  if (!p.ok) return;
  Lock(); g_anchor.x = p.x; g_anchor.y = p.y; g_dock = p.dock & 0xFF; g_anchorRight = (p.dock & 0x100) != 0; g_posSrc = PS_MEMORY; Unlock();
  if (U_) U_->dockOpen = false;
}
static void SetHover(bool h) {
  Ui& u = *U_;
  if (u.hover == h) return;
  u.hover = h;
  if (h) {
    int delay = 110;
    if (g_dock) delay = 160;
    SetTimer(g_hwnd, TM_HOVER, delay, nullptr);
  } else {
    u.hoverIntent = false; u.hoverId = 0; u.hoverBody = false;
    KillTimer(g_hwnd, TM_HOVER);
  }
}
// =================================================================================================
// ---- 换皮肤时的实时预览与皮肤画廊
// 右键菜单「悬浮窗皮肤 ▸」里指着哪款，悬浮窗就临时显示哪款（WM_MENUSELECT）；子菜单顶上的「预览全部皮肤…」打开画廊：
// 16 款 4×4（用此刻的真实状态画的缩略图，每秒跟真实状态核对一次、变了就重画），指着哪张卡片、悬浮窗就临时换成哪款；点一下换上（同右键菜单选皮肤：回调换皮肤事件），
// Esc、点画廊外面（含悬浮窗本身）、右键都是取消，恢复原来的皮肤。画廊不抢焦点（界面线程不能停在前台，见右键菜单），
// 所以 Esc 与点外面靠每 50 毫秒看一次按键状态；30 秒没碰画廊也自动关掉（前台是管理员权限的程序时按键状态看不到）
static void SetPreview(int sk) {  // 悬浮窗临时显示第 sk 款（0＝恢复）；已选定、等易语言换上时不变
  if (g_previewCommit || sk == (int)g_previewSkin || !U_) return;
  g_previewSkin = sk; HideTip(); U_->lastKey.clear(); Render();
}
static void CommitPreview(int sk) {  // 选定了第 sk 款：回调换皮肤事件；易语言换上之前悬浮窗继续显示它（最多 3 秒），免得先闪回原来的皮肤
  int cur; Lock(); cur = g_state.skin; g_previewSeq = g_skinSeq; Unlock();
  if (sk < 1 || sk > SK_COUNT || sk == cur) { g_previewCommit = false; SetPreview(0); return; }
  g_previewCommit = false; g_previewSkin = sk; g_previewCommit = true;
  SetTimer(g_hwnd, TM_PREVEND, 3000, nullptr);
  if (U_) { U_->lastKey.clear(); Render(); }
  Fire(XE_SKIN, sk);
}
static HWND g_gal = nullptr;
struct GalState {
  int hot = 0;                   // 指着的那款（0＝没有）
  float k = 1;                   // 系统缩放（与右键菜单一样，不跟各款的大小）
  int W = 0, H = 0, x = 0, y = 0, mg = 0;  // 面板尺寸、屏幕位置（面板左上角）、四周投影边距
  RectF card[SK_COUNT + 1];      // 1～16：卡片（面板坐标）
  PixBuf thumb[SK_COUNT + 1]; float tW[SK_COUNT + 1] = {}, tH[SK_COUNT + 1] = {}, tg[SK_COUNT + 1] = {}; int tm[SK_COUNT + 1] = {};  // 缩略图（含投影边距）、内容尺寸、贴的时候的缩放
  std::wstring thumbSig;         // 上一次画缩略图时的状态（只在两路都停着时记）：没变就不重画
  bool lb = false, rb = false, esc = false;  // 上一次看到的按键状态（打开时已按着的不算）
  DWORD touched = 0;             // 最后一次碰画廊的时刻
  DWORD openedAt = 0; HWND fg0 = nullptr; bool fgSet = false;  // 打开时的前台窗口（打开 0.5 秒后才记，见 GalleryPoll）
};
static GalState G;
static XState GalState0() { Lock(); XState s = g_state; Unlock(); if (g_freeze) { s.sfx.stamp = 0; s.bgm.stamp = 0; } return s; }
// 1.4.0：缩略图的状态——此刻的真实状态，但快捷键一律按“已开启”画、不画小键盘提醒（画廊是用来挑皮肤的：16 张都是开启时的样子，不随开关变灰、
// 不变成 16 个提醒）。悬浮窗本身（指着卡片时临时换上的那款）与画廊的摆放位置照常按真实状态：直播中悬浮窗不能把关着的快捷键显示成开着
static XState GalThumbState() { XState s = GalState0(); s.armed = true; s.numlock = false; return s; }
// 缩略图的状态签名：两路都停着时画面不随时间变（没有倒计时、音浪、转动），签名没变就不必每秒重画 16 张；有东西在放或暂停着时返回空（每秒照常重画）
static std::wstring GalThumbSig() {
  XState s = GalThumbState();  // 1.4.0：与缩略图同一份状态
  if (s.sfx.state != 0 || s.bgm.state != 0) return std::wstring();
  bool dk = g_testDark >= 0 ? g_testDark != 0 : (U_ && U_->dark);
  // 皮肤：画廊里“现在用的这款”的绿框也跟着这一次重画更新。1.4.0：原来这一行的注释把后面的小键盘、两路闪避也注释掉了——画廊开着、什么都没放时
  // 闪避变了（说话闪避随说话开关），组件卡、控台缩略图上的闪避按钮不跟着变
  std::wstring sig = std::to_wstring(s.skin) + L"|" + std::to_wstring(s.armed) + L"|" + std::to_wstring(s.numlock) + L"|" + std::to_wstring(s.duckS) + L"|" + std::to_wstring(s.duckB) + L"|" +
                     std::to_wstring(s.loop) + L"|" + std::to_wstring(s.order) + L"|" + std::to_wstring(s.lang) + L"|" + std::to_wstring(s.rtl) + L"|" + std::to_wstring(dk) + L"|" +
                     std::to_wstring((int)(G.k * 1000)) + L"|" + std::to_wstring(XfFontState()) + L"|" + s.key + L"|" + s.sfx.name + L"|" + s.bgm.name;  // 字体：字体包下载解压完才设字体目录（画廊可能正开着）
  return sig;
}
static Ctx ThumbCtx(XState& s2, float k) {
  Ui& u = *U_;
  SyncFonts(u, s2.lang);
  static XState rv; rv = XfRoleView(s2);  // 1.3.0：缩略图也按各款的角色画（画廊里看到的就是换上后会显示的）
  Ctx c; c.g = u.measureG; c.draw = false; c.k = k; c.s = &rv; c.lang = s2.lang; c.rtl = s2.rtl;
  c.now = g_freeze ? (DWORD)g_freeze : GetTickCount(); c.hover = false; c.docked = false;
  c.dark = g_testDark >= 0 ? g_testDark != 0 : u.dark; c.fonts = &u.fonts;
  return c;
}
static SizeF ThumbMeasure(int sk, float k, XState& s2) {  // 第 sk 款按缩放 k 的内容尺寸（不悬停、不贴边）
  s2.skin = sk; Ctx c = ThumbCtx(s2, k); std::vector<Hit> dummy; c.hits = &dummy;
  return SkinLayout(sk, c);
}
// 第 sk 款按缩放 k 画成一张图（此刻的状态，只换皮肤；缩略图的快捷键一律按开启，见 GalThumbState）；不碰悬浮窗本身的可点区域、阴影缓存、曲名滚动
static void ThumbRender(int sk, float k, XState& s2, PixBuf& out, float* W, float* H, int* m) {
  SizeF sz = ThumbMeasure(sk, k, s2);
  float w = ceilf(sz.Width), h = ceilf(sz.Height); int mm = (int)ceilf(16 * k);
  out.init((int)w + 2 * mm, (int)h + 2 * mm);
  {
    Bitmap bmp(out.w, out.h, out.w * 4, PixelFormat32bppPARGB, (BYTE*)out.px.data());
    Graphics g(&bmp);
    g.SetSmoothingMode(SmoothingModeAntiAlias); g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit);
    g.SetPixelOffsetMode(PixelOffsetModeHalf); g.SetInterpolationMode(InterpolationModeHighQualityBicubic);
    if (s2.rtl) { Matrix mx(-1, 0, 0, 1, (REAL)(mm + w), (REAL)mm); g.SetTransform(&mx); } else g.TranslateTransform((REAL)mm, (REAL)mm);
    Ctx c = ThumbCtx(s2, k); c.g = &g; c.draw = true; c.W = w; c.H = h;
    bool glassSave = g_glassLiveDraw; g_glassLiveDraw = false;  // 缩略图下面没有实时模糊
    c.logSkip = true;  // 缩略图里的字只是预览（缩得很小），不进文字记录
    std::vector<Hit> dummy; c.hits = &dummy;
    SkinLayout(sk, c);
    g_glassLiveDraw = glassSave;
  }
  float st = SkinTraitsOf(sk).shadow;  // 投影：与悬浮窗本身同一套参数（不用悬浮窗的阴影缓存）
  if (st > 0) {
    std::vector<unsigned char> a((size_t)out.w * out.h, 0);
    int dy = (int)roundf(5 * k);
    for (int y = dy; y < out.h; y++) for (int x = 0; x < out.w; x++) a[(size_t)y * out.w + x] = (unsigned char)(out.px[(size_t)(y - dy) * out.w + x] >> 24);
    BoxBlurAlpha(a, out.w, out.h, (int)roundf(6 * k));
    for (size_t i = 0; i < out.px.size(); i++) {
      int al = (int)(a[i] * st); unsigned top = out.px[i], ta = top >> 24;
      if (al <= 0 || ta == 255) continue;
      out.px[i] = ((ta + (unsigned)al * (255 - ta) / 255) << 24) | (top & 0x00FFFFFF);
    }
  }
  *W = w; *H = h; *m = mm;
}
static RECT PreviewRectFor(int sk) {  // 换上第 sk 款后悬浮窗内容在屏幕上的位置（与 PlaceAndShow 同一套规则；画廊开着时不按贴边收起）
  Ui& u = *U_;
  XState s2 = GalState0(); POINT anchor; bool ar; int dock; Lock(); anchor = g_anchor; ar = g_anchorRight; dock = g_dock; Unlock();
  s2.skin = sk;
  float k = u.dpi / 96.f * XfScalePct(s2) / 100.f;
  SizeF sz = ThumbMeasure(sk, k, s2);
  int W = (int)ceilf(sz.Width), H = (int)ceilf(sz.Height);
  float ax = 0, ay = 0;
  if (ar) ax = (float)W;
  int x = anchor.x - (int)roundf(ax), y = anchor.y - (int)roundf(ay);
  RECT wa = HomeWorkArea(anchor, ar, dock);
  if (dock == 1) x = wa.left + 4; else if (dock == 2) x = wa.right - 4 - W; else if (dock == 3) y = wa.top + 4;
  if (x < wa.left) x = wa.left; if (y < wa.top) y = wa.top;
  if (x + W > wa.right) x = wa.right - W; if (y + H > wa.bottom) y = wa.bottom - H;
  RECT r = {x, y, x + W, y + H}; return r;
}
static const int GCOLS = 4, GROWS = (SK_COUNT + GCOLS - 1) / GCOLS;  // 4 × 4：一行一组（实用高效、氛围潮流、萌趣生活、复古文化）
static void GalleryLayout() {
  // 卡片 230×138（缩略图区 90 高）：100% 时面板 972×648，150% 时 972 高，1080p 屏幕的工作区（任务栏占 60～72）放得下；更大的缩放由 GalleryOpen 按工作区再收
  float k = G.k, pad = 14 * k, gap = 8 * k, head = 44 * k, cw = 230 * k, ch = 138 * k;
  G.W = (int)ceilf(2 * pad + GCOLS * cw + (GCOLS - 1) * gap); G.H = (int)ceilf(pad + head + GROWS * ch + (GROWS - 1) * gap + pad);
  G.mg = (int)ceilf(12 * k);
  bool rtl; Lock(); rtl = g_state.rtl; Unlock();
  for (int i = 0; i < SK_COUNT; i++) {
    int col = i % GCOLS, row = i / GCOLS; if (rtl) col = GCOLS - 1 - col;  // 阿拉伯语：从右往左排
    G.card[i + 1] = RectF(pad + col * (cw + gap), pad + head + row * (ch + gap), cw, ch);
  }
}
static void GalleryThumbs() {  // 16 张缩略图：每款缩到缩略图区里（最多原大）；像素风不能小于 2 像素一格，画出来可能比区大，贴的时候再缩
  XState s0 = GalThumbState(); float k = G.k, aw = 210 * k, ah = 90 * k;  // 1.4.0：按快捷键已开启画（见 GalThumbState）
  for (int sk = 1; sk <= SK_COUNT; sk++) {
    XState s2 = s0;
    SizeF sz = ThumbMeasure(sk, k, s2);
    float f = 1.f; if (sz.Width > aw) f = aw / sz.Width; if (sz.Height * f > ah) f = ah / sz.Height;
    ThumbRender(sk, k * f, s2, G.thumb[sk], &G.tW[sk], &G.tH[sk], &G.tm[sk]);
    float g = 1.f; if (G.tW[sk] > aw) g = aw / G.tW[sk]; if (G.tH[sk] * g > ah) g = ah / G.tH[sk];
    G.tg[sk] = g;
  }
}
static void GalleryPlace() {  // 放在悬浮窗上方（悬浮窗换皮肤时向下长，上方不会被挡）；放不下就放在 16 款里最低的那款下面
  RECT un = PreviewRectFor(1);
  for (int sk = 2; sk <= SK_COUNT; sk++) { RECT r = PreviewRectFor(sk); if (r.left < un.left) un.left = r.left; if (r.top < un.top) un.top = r.top; if (r.right > un.right) un.right = r.right; if (r.bottom > un.bottom) un.bottom = r.bottom; }
  POINT c0 = {(un.left + un.right) / 2, (un.top + un.bottom) / 2}; RECT wa = WorkAreaAt(c0);
  bool ar; Lock(); ar = g_anchorRight; Unlock();
  int gap = (int)ceilf(10 * G.k);
  int x = ar ? un.right - G.W : un.left;
  int y = un.top - gap - G.H;
  if (y < wa.top) { y = un.bottom + gap; if (y + G.H > wa.bottom) y = (wa.bottom - G.H > wa.top) ? wa.bottom - G.H : wa.top; }  // 上下都放不下：靠下边（会挡住一部分）
  if (x + G.W > wa.right) x = wa.right - G.W; if (x < wa.left) x = wa.left;
  G.x = x; G.y = y;
}
static void GalleryCompose(PixBuf& pb) {
  float k = G.k; Ctx c = MenuCtx(); c.rtl = false;  // 画在不镜像的位图上（与菜单、提示相同）
  int cur; bool rtl; Lock(); cur = g_state.skin; rtl = g_state.rtl; Unlock();
  pb.init(G.W + 2 * G.mg, G.H + 2 * G.mg);
  {
    Bitmap bmp(pb.w, pb.h, pb.w * 4, PixelFormat32bppPARGB, (BYTE*)pb.px.data());
    Graphics g(&bmp);
    g.SetSmoothingMode(SmoothingModeAntiAlias); g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit);
    g.SetPixelOffsetMode(PixelOffsetModeHalf); g.SetInterpolationMode(InterpolationModeHighQualityBicubic);
    g.TranslateTransform((REAL)G.mg, (REAL)G.mg);
    Ctx d = c; d.g = &g; d.draw = true; d.rtl = false;
    float W = (float)G.W, H = (float)G.H, pad = 14 * k;
    SolidBrush bg(C(0x1C1C21)); FillRR(d, 0, 0, W, H, 14 * k, bg);
    StrokeRR(d, 0.5f, 0.5f, W - 1, H - 1, 14 * k, C(0xFFFFFF, 26), 1, false);
    std::wstring title = c.T(M_SKINS), hint = c.T(M_GALHINT);
    Font* tf = c.fonts->name(title, 15 * k, true); Font* hf = c.fonts->name(hint, 11.5f * k, false);
    float hw = TextW(d, hint, hf); if (hw > W * 0.55f) hw = W * 0.55f;
    float tw = W - 2 * pad - hw - 16 * k;
    if (!rtl) { Text(d, title, tf, C(0xF5F5F7), pad, pad, tw, 26 * k, 0, true); Text(d, hint, hf, C(0xA6A6AE), W - pad - hw, pad + 2 * k, hw + 2, 24 * k, 0, true); }
    else { Text(d, title, tf, C(0xF5F5F7), W - pad - tw, pad, tw, 26 * k, 2, true); Text(d, hint, hf, C(0xA6A6AE), pad, pad + 2 * k, hw + 2, 24 * k, 2, true); }
    auto RoleTag = [&](int sk) -> std::wstring {  // 1.3.0：只给少数派标角色（只管背景音乐 / 两路都管）；只管音效是默认，不标
      int role = SkinTraitsOf(sk).role; return role == ROLE_BGM ? c.T(S_BGM) : role == ROLE_DUAL ? c.T(S_SFX) + L" + " + c.T(S_BGM) : std::wstring(); };
    bool tagInline = true;  // 标了角色的 4 款都能把名称（按加粗量，指着时不跳）和角色排在一行，才排在名称后面；否则这种语言一律改成缩略图角上的小标签：名称永远不因角色标记被截断
    for (int sk = 1; sk <= SK_COUNT && tagInline; sk++) {
      std::wstring tg = RoleTag(sk); if (tg.empty()) continue; std::wstring nm = c.T(M_SKIN1 + sk - 1);
      if (TextW(d, nm, c.fonts->name(nm, 12.5f * k, true)) + 6 * k + TextW(d, tg, c.fonts->name(tg, 11 * k, false)) > G.card[sk].Width - 16 * k) tagInline = false;
    }
    for (int sk = 1; sk <= SK_COUNT; sk++) {
      RectF r = G.card[sk]; bool hot = G.hot == sk, isCur = cur == sk;
      SolidBrush cb(C(hot ? 0x34343D : 0x26262D)); FillRR(d, r.X, r.Y, r.Width, r.Height, 10 * k, cb);
      RectF A(r.X + 10 * k, r.Y + 10 * k, r.Width - 20 * k, 90 * k);
      SolidBrush ab(C(0x141418)); FillRR(d, A.X, A.Y, A.Width, A.Height, 8 * k, ab);
      if (!G.thumb[sk].px.empty()) {  // 缩略图：内容居中，投影可以伸到缩略图区边上，超出部分裁掉
        PixBuf& t = G.thumb[sk]; float s = G.tg[sk];
        float dw = t.w * s, dh = t.h * s, dx = A.X + (A.Width - G.tW[sk] * s) / 2 - G.tm[sk] * s, dy = A.Y + (A.Height - G.tH[sk] * s) / 2 - G.tm[sk] * s;
        if (s == 1.f) { dx = roundf(dx); dy = roundf(dy); }
        GraphicsState st = g.Save(); GraphicsPath clip; RoundRectPath(clip, A.X, A.Y, A.Width, A.Height, 8 * k); g.SetClip(&clip);
        Bitmap tb(t.w, t.h, t.w * 4, PixelFormat32bppPARGB, (BYTE*)t.px.data());
        g.DrawImage(&tb, RectF(dx, dy, dw, dh), 0, 0, (REAL)t.w, (REAL)t.h, UnitPixel);
        g.Restore(st);
      }
      std::wstring nm = c.T(M_SKIN1 + sk - 1);
      std::wstring tag = RoleTag(sk);
      Font* nmf = c.fonts->name(nm, 12.5f * k, hot || isCur);
      if (tag.empty() || !tagInline) Text(d, nm, nmf, C(0xEDEDF0), r.X + 8 * k, A.Y + A.Height + 8 * k, r.Width - 16 * k, 24 * k, 1, true);
      else {  // 名称在前、角色在后（阿拉伯语反过来），整组居中（tagInline 已保证名称不会因此被截断）
        Font* tgf = c.fonts->name(tag, 11 * k, false); float avail = r.Width - 16 * k, gap = 6 * k, tgw = TextW(d, tag, tgf), nmw = TextW(d, nm, nmf);
        if (nmw + gap + tgw > avail) tgw = avail - gap - nmw > 0 ? avail - gap - nmw : 0;
        float x0 = r.X + 8 * k + (avail - (nmw + gap + tgw)) / 2, y0 = A.Y + A.Height + 8 * k;
        if (!rtl) { Text(d, nm, nmf, C(0xEDEDF0), x0, y0, nmw + 1, 24 * k, 0, true); Text(d, tag, tgf, C(0xA6A6AE), x0 + nmw + gap, y0, tgw + 1, 24 * k, 0, true); }
        else { Text(d, tag, tgf, C(0xA6A6AE), x0, y0, tgw + 1, 24 * k, 0, true); Text(d, nm, nmf, C(0xEDEDF0), x0 + tgw + gap, y0, nmw + 1, 24 * k, 0, true); }
      }
      if (!tag.empty() && !tagInline) {  // 排不下时：缩略图角上的小标签（现在用的这款的勾在右上角、阿拉伯语在左上角，标签放另一边）
        Font* pf = c.fonts->name(tag, 10.5f * k, false); float pad = 6 * k, ph = 17 * k, pw = TextW(d, tag, pf), maxw = A.Width - 40 * k - 2 * pad;
        if (pw > maxw) pw = maxw;
        float px = rtl ? A.X + A.Width - 6 * k - pw - 2 * pad : A.X + 6 * k, py = A.Y + 6 * k;
        SolidBrush pb(C(0x000000, 170)); FillRR(d, px, py, pw + 2 * pad, ph, ph / 2, pb);
        Text(d, tag, pf, C(0xFFFFFF), px + pad, py, pw + 1, ph, 0, true);
      }
      if (isCur) {  // 现在用的这款：绿框＋右上角（阿拉伯语左上角）一个勾
        StrokeRR(d, r.X + 1 * k, r.Y + 1 * k, r.Width - 2 * k, r.Height - 2 * k, 9 * k, C(0x34C759), 2 * k);
        float bx = rtl ? A.X + 6 * k : A.X + A.Width - 22 * k, by = A.Y + 6 * k;
        SolidBrush gb(C(0x34C759)); g.FillEllipse(&gb, bx, by, 16 * k, 16 * k);
        Pen ck(C(0x0B2E16), 1.8f * k); ck.SetStartCap(LineCapRound); ck.SetEndCap(LineCapRound); ck.SetLineJoin(LineJoinRound);
        PointF pts[3] = {PointF(bx + 4.2f * k, by + 8.4f * k), PointF(bx + 7 * k, by + 11 * k), PointF(bx + 12 * k, by + 5.4f * k)}; g.DrawLines(&ck, pts, 3);
      } else if (hot) StrokeRR(d, r.X + 0.75f * k, r.Y + 0.75f * k, r.Width - 1.5f * k, r.Height - 1.5f * k, 9.5f * k, C(0xFFFFFF, 90), 1.5f * k);
    }
  }
  std::vector<unsigned char> a((size_t)pb.w * pb.h, 0);  // 面板的投影
  int dy = (int)roundf(4 * k);
  for (int y = dy; y < pb.h; y++) for (int x = 0; x < pb.w; x++) a[(size_t)y * pb.w + x] = (unsigned char)(pb.px[(size_t)(y - dy) * pb.w + x] >> 24);
  BoxBlurAlpha(a, pb.w, pb.h, (int)roundf(6 * k));
  for (size_t i = 0; i < pb.px.size(); i++) { int al = (int)(a[i] * 0.5f); unsigned top = pb.px[i], ta = top >> 24; if (al <= 0 || ta == 255) continue; pb.px[i] = ((ta + (unsigned)al * (255 - ta) / 255) << 24) | (top & 0x00FFFFFF); }
}
static void PushLayered(HWND w, const PixBuf& pb, int x, int y) {
  HDC sdc = GetDC(nullptr), mdc = CreateCompatibleDC(sdc);
  BITMAPINFO bi = {}; bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = pb.w; bi.bmiHeader.biHeight = -pb.h; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
  void* bits = nullptr; HBITMAP dib = CreateDIBSection(mdc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
  if (dib && bits) {
    memcpy(bits, pb.px.data(), (size_t)pb.w * pb.h * 4);
    HGDIOBJ old = SelectObject(mdc, dib);
    POINT src = {0, 0}, dst = {x, y}; SIZE sz = {pb.w, pb.h}; BLENDFUNCTION bf = {AC_SRC_OVER, 0, 255, AC_SRC_ALPHA};
    if (StripRegion(w)) InterlockedIncrement(&g_selfFix);
    UlwPush(w, sdc, &dst, &sz, mdc, &src, &bf);
    SelectObject(mdc, old); DeleteObject(dib);
  }
  DeleteDC(mdc); ReleaseDC(nullptr, sdc);
}
static void GalleryShow() {
  if (!g_gal || !g_galOpen) return;
  PixBuf pb; GalleryCompose(pb);
  PushLayered(g_gal, pb, G.x - G.mg, G.y - G.mg);
  SetWindowPos(g_gal, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
}
static void GalleryClose(bool cancel) {
  if (!g_galOpen) return;
  g_galOpen = false; G.hot = 0;
  if (g_gal) { KillTimer(g_gal, 1); KillTimer(g_gal, 2); ShowWindow(g_gal, SW_HIDE); }
  for (auto& t : G.thumb) t = PixBuf();
  if (cancel && !g_previewCommit) g_previewSkin = 0;
  if (U_) { U_->lastKey.clear(); Render(); }  // 恢复原来的皮肤；贴边的悬浮窗按原样收起
}
static void GalleryOpen() {
  if (!g_gal || !U_ || g_galOpen) return;
  Ui& u = *U_;
  HideTip();
  G = GalState(); G.k = u.dpi / 96.f;
  g_galOpen = true; u.lastKey.clear(); Render();  // 贴边收起着的悬浮窗先展开（预览要看得见）
  if (!g_galOpen) return;  // 悬浮窗隐藏着：Render 已把画廊关掉（看不到预览），不再量缩略图、不开计时器
  GalleryLayout();
  {  // 屏幕放不下（高缩放、小屏幕）：整块按悬浮窗所在显示器的工作区等比缩小，四周留 8 像素
    POINT a; bool ar; int dk; Lock(); a = g_anchor; ar = g_anchorRight; dk = g_dock; Unlock(); RECT wa = HomeWorkArea(a, ar, dk);
    float fw = (float)(wa.right - wa.left - 16), fh = (float)(wa.bottom - wa.top - 16), f = 1.f;
    if (G.W > fw) f = fw / G.W;
    if (G.H * f > fh) f = fh / G.H;
    if (f < 1.f) { G.k *= f; GalleryLayout(); }
  }
  GalleryThumbs(); G.thumbSig = GalThumbSig(); GalleryPlace();
  G.lb = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0; G.rb = (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0; G.esc = (GetAsyncKeyState(VK_ESCAPE) & 0x8000) != 0;
  G.touched = G.openedAt = GetTickCount();
  GalleryShow();
  SetTimer(g_gal, 1, 1000, nullptr); SetTimer(g_gal, 2, 50, nullptr);
}
static void GalleryHot(int sk) {
  if (!g_galOpen) return;
  if (sk) G.touched = GetTickCount();
  if (sk == G.hot) return;
  G.hot = sk; SetPreview(sk); GalleryShow();
}
static void GalleryPick(int sk) { if (!g_galOpen) return; GalleryClose(false); CommitPreview(sk); }
static int GalleryCardAt(int x, int y) {  // 画廊窗口里的坐标 → 第几款
  float fx = (float)(x - G.mg), fy = (float)(y - G.mg);
  for (int sk = 1; sk <= SK_COUNT; sk++) { const RectF& r = G.card[sk]; if (fx >= r.X && fx < r.X + r.Width && fy >= r.Y && fy < r.Y + r.Height) return sk; }
  return 0;
}
static void GalleryPoll() {  // 不抢焦点：每 50 毫秒看一次按键——Esc、在画廊外面按下鼠标都算取消
  bool esc = (GetAsyncKeyState(VK_ESCAPE) & 0x8000) != 0, lb = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0, rb = (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
  bool escNew = esc && !G.esc, clickNew = (lb && !G.lb) || (rb && !G.rb);
  G.esc = esc; G.lb = lb; G.rb = rb;
  if (escNew) { GalleryClose(true); return; }
  if (clickNew) { POINT p; GetCursorPos(&p); RECT gr; GetWindowRect(g_gal, &gr); if (!PtInRect(&gr, p)) { GalleryClose(true); return; } }
  // 别的窗口到了前台（点了别的程序、Alt+Tab）就关——与系统的浮出控件、菜单一样；前台窗口不受权限高低影响，管理员权限的程序在前台、
  // 看不到它的点击时也靠这一条关。刚打开的 0.5 秒里不记（右键菜单关掉时会把前台还给原来的窗口）
  if (GetTickCount() - G.openedAt >= 500) {
    HWND fg = GetForegroundWindow();
    if (!G.fgSet) { G.fg0 = fg; G.fgSet = true; }
    else if (fg && fg != G.fg0 && fg != g_gal && fg != g_hwnd) { GalleryClose(true); return; }
  }
  if (!G.hot && GetTickCount() - G.touched > 180000) GalleryClose(true);  // 保险：3 分钟没碰也关（原来 30 秒：用户停下来看一会儿就没了）
}
static LRESULT CALLBACK GalProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
  switch (msg) {
    case WM_MOUSEACTIVATE: return MA_NOACTIVATE;
    case WM_SETCURSOR: SetCursor(LoadCursor(nullptr, G.hot ? IDC_HAND : IDC_ARROW)); return TRUE;
    case WM_MOUSEMOVE: {  // 在卡片之间的缝、标题上时预览不变（原来会先跳回原来的皮肤再跳到下一款，悬浮窗一闪）；离开画廊才恢复（WM_MOUSELEAVE）
      TRACKMOUSEEVENT t = {sizeof(t), TME_LEAVE, h, 0}; TrackMouseEvent(&t); G.touched = GetTickCount();
      int sk = GalleryCardAt((short)LOWORD(lp), (short)HIWORD(lp)); if (sk) GalleryHot(sk);
      return 0;
    }
    case WM_MOUSELEAVE: GalleryHot(0); return 0;
    case WM_LBUTTONUP: { int sk = GalleryCardAt((short)LOWORD(lp), (short)HIWORD(lp)); if (sk) GalleryPick(sk); return 0; }
    case WM_RBUTTONUP: GalleryClose(true); return 0;
    case WM_TIMER:
      if (wp == 1 && g_galOpen) {  // 缩略图每秒按真实状态更新（播放进度、倒计时……）；两路都停着、状态也没变时不重画（原来待机时也每秒重画 16 张）
        std::wstring sig = GalThumbSig();
        if (sig.empty() || sig != G.thumbSig) { G.thumbSig = sig; GalleryThumbs(); GalleryShow(); }
      }
      if (wp == 2 && g_galOpen) GalleryPoll();
      return 0;
  }
  return DefWindowProcW(h, msg, wp, lp);
}
// 诊断：最近处理过的鼠标类消息，以及任何改变了“按下状态”的消息（XF_GetInfo 26 总条数，27～58 由近到远 32 条）。
// 每条：位 0～11 消息号，12 处理前按着，13 处理后按着，14 别的线程同步送来的（测试程序的模拟），15～21 wParam 低 7 位，22～31 与上一条相隔的毫秒（最多 1023）
static volatile LONG g_mlogN = 0; static LONG g_mlog[32], g_mlog2[32]; static DWORD g_mlogT = 0;  // g_mlog2：位 0～10 横坐标、11～21 纵坐标（窗口内，低 11 位），22～25 处理后的按下目标，26～29 坐标处的按钮，30 处理后在拖动（XF_GetInfo 59～90）
static LRESULT CALLBACK WndProcImpl(HWND h, UINT msg, WPARAM wp, LPARAM lp);
static LRESULT CALLBACK WndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
  bool pb = U_ && U_->pressed;
  LRESULT r = WndProcImpl(h, msg, wp, lp);
  bool pa = U_ && U_->pressed;
  if ((msg >= WM_MOUSEFIRST && msg <= WM_MOUSELAST) || msg == WM_MOUSELEAVE || msg == WM_CAPTURECHANGED || msg == WM_CANCELMODE || pb != pa ||
      msg == WM_ENTERMENULOOP || msg == WM_EXITMENULOOP || msg == WM_INITMENUPOPUP || msg == WM_UNINITMENUPOPUP || msg == WM_ACTIVATE || msg == WM_ACTIVATEAPP || msg == WM_KILLFOCUS || msg == WM_SETFOCUS || msg == WM_NCACTIVATE) {  // 也记菜单的开关与激活、焦点的变化（都不频繁）
    DWORD now = GetTickCount(), dt = g_mlogT ? now - g_mlogT : 0; if (dt > 1023) dt = 1023; g_mlogT = now;
    LONG n = g_mlogN; g_mlog[n & 31] = (LONG)((msg & 0xFFF) | (pb ? 1u << 12 : 0) | (pa ? 1u << 13 : 0) | (InSendMessage() ? 1u << 14 : 0) | ((wp & 0x7F) << 15) | (dt << 22));
    unsigned x = (unsigned)(short)LOWORD(lp) & 0x7FF, y = (unsigned)(short)HIWORD(lp) & 0x7FF, hit = 0, pid = 0, drg = 0;
    if (U_ && msg >= WM_MOUSEFIRST && msg <= WM_MOUSELAST) { hit = (unsigned)HitAt((short)LOWORD(lp), (short)HIWORD(lp)) & 0xF; pid = (unsigned)U_->pressId & 0xF; drg = U_->dragging ? 1 : 0; }
    g_mlog2[n & 31] = (LONG)(x | (y << 11) | (pid << 22) | (hit << 26) | (drg << 30)); g_mlogN = n + 1;
  }
  return r;
}
static LRESULT CALLBACK WndProcImpl(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
  Ui* up = U_;
  switch (msg) {
    case WM_MOUSEACTIVATE: return MA_NOACTIVATE;
    case WM_XF_DIRTY: Render(); return 0;
    case WM_XF_SNAP: { SnapReq* q = (SnapReq*)lp; q->ok = Snapshot(q); Render(); return 0; }
    case WM_XF_CALL: {
      if (wp == 3) { RunMenu(h, (int)lp); return 0; }  // 测试：当作在右键菜单里选了这一项
      if (wp == 5) {  // 测试：皮肤画廊（1 画成 PNG 2 当作指着第 arg 款 3 当作点了第 arg 款 4 当作按了 Esc）
        struct GQ { int op, arg; const wchar_t* path; }* q = (GQ*)lp;
        if (q->op == 1) {
          if (!g_galOpen) return 0;
          GalleryThumbs(); PixBuf pb; g_testLogNow = true; GalleryCompose(pb); g_testLogNow = false;
          Bitmap bmp(pb.w, pb.h, pb.w * 4, PixelFormat32bppPARGB, (BYTE*)pb.px.data());
          Bitmap out(pb.w, pb.h, PixelFormat32bppARGB);
          { Graphics g(&out); g.Clear(Color(0, 0, 0, 0)); g.SetCompositingMode(CompositingModeSourceCopy); g.DrawImage(&bmp, 0, 0, pb.w, pb.h); }
          CLSID cls; return PngClsid(&cls) && out.Save(q->path, &cls, nullptr) == Ok ? 1 : 0;
        }
        if (q->op == 2) { GalleryHot(q->arg); return g_galOpen ? 1 : 0; }
        if (q->op == 3) { if (!g_galOpen) return 0; GalleryPick(q->arg); return 1; }
        if (q->op == 4) { GalleryClose(true); return 1; }
        return 0;
      }
      if (wp == 4) { Ctx c = MenuCtx(); g_testLogNow = true; bool ok = XfMenuSnapshot(c, up->s, (const wchar_t*)lp); g_testLogNow = false; return ok ? 1 : 0; }  // 测试：把菜单画成图
      if (wp == 2) {  // 测试：精绘一个字
        struct GQ { int ch, px10, bold; unsigned char* buf; int cap; long long sum; }* q = (GQ*)lp;
        Font* f = up->fonts.ui(q->px10 / 10.f, q->bold != 0);
        q->sum = XfFineDebugGlyph(f, (wchar_t)q->ch, q->buf, q->cap);
        return 0;
      }
      if (wp == 1) {
        TimeReq* q = (TimeReq*)lp; LARGE_INTEGER f, t0, t1; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&t0);
        Lock(); up->s = g_state; Unlock();
        for (int i = 0; i < q->n; i++) { RenderOut r; RenderTo(r, up->dpi, false); }
        QueryPerformanceCounter(&t1); q->us = (t1.QuadPart - t0.QuadPart) * 1000000 / f.QuadPart;
      }
      return 0;
    }
    case WM_APP + 0x7B: {  // “置顶”变了（选项 3）：卡片换层，毛玻璃背景跟着换到同一层、仍紧挨在卡片下面——都在本线程里依次做（原来在调用方线程里跨线程 SetWindowPos）
      if (g_inMenu) { g_zLater = true; return 0; }  // 1.3.3：右键菜单开着时不换层（换到置顶层最上面就压到菜单上），菜单关掉后补做（AfterMenu）
      bool tp; Lock(); tp = g_opt[3] != 0; Unlock();
      SetWindowPos(h, tp ? HWND_TOPMOST : HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
      if (up && IsWindowVisible(h)) GlassSync(GlassWanted(up->s.skin), up->winPos.x + up->m, up->winPos.y + up->m, (int)up->W, (int)up->H, up->k);
      return 0;
    }
    case WM_SYSCOLORCHANGE: case WM_POWERBROADCAST:  // 高对比度、省电模式可能变了：马上重新判断要不要实时模糊（透明效果的开关在下面 WM_SETTINGCHANGE 里）
      g_glassSysLast = 0; if (up) { up->lastKey.clear(); Render(); }
      return DefWindowProcW(h, msg, wp, lp);
    case WM_MENUSELECT: {  // 右键菜单里指着哪款皮肤，悬浮窗就临时显示哪款；关菜单的通知在菜单里不处理（等选的结果）
      UINT id = LOWORD(wp), fl = HIWORD(wp);
      if (fl == 0xFFFF && !lp) { if (!g_inMenu) SetPreview(0); return 0; }
      SetPreview((fl & MF_POPUP) ? 0 : XfMenuSkinOf((int)id));
      return 0;
    }
    case WM_SETCURSOR: {
      if (up && up->hoverId) { SetCursor(LoadCursor(nullptr, IDC_HAND)); return TRUE; }
      SetCursor(LoadCursor(nullptr, IDC_ARROW)); return TRUE;
    }
    case WM_MOUSEMOVE: {
      Ui& u = *up;
      int mx = (short)LOWORD(lp), my = (short)HIWORD(lp);
      if (!u.tracking) { TRACKMOUSEEVENT t = {sizeof(t), TME_LEAVE, h, 0}; TrackMouseEvent(&t); u.tracking = true; }
      KillTimer(h, TM_LEAVE); KillTimer(h, TM_DOCKCLOSE);
      if (u.pressed && !u.dragging) {
        POINT p = {u.winPos.x + mx, u.winPos.y + my};
        if (abs(p.x - u.pressPt.x) > GetSystemMetrics(SM_CXDRAG) || abs(p.y - u.pressPt.y) > GetSystemMetrics(SM_CYDRAG)) {
          u.dragging = true;
          if (g_dock) { Lock(); g_dock = 0; Unlock(); u.dockOpen = false; Render(); }
          u.pressWin = u.winPos;  // 从按下的那一点算位移：拖动起点就是按下处，不丢开头那几个像素
        }
      }
      if (u.dragging) {
        POINT p = {u.winPos.x + mx, u.winPos.y + my};  // 用消息里的坐标（窗口跟着动，换回屏幕坐标），不读 GetCursorPos
        int nx = u.pressWin.x + (p.x - u.pressPt.x), ny = u.pressWin.y + (p.y - u.pressPt.y);
        SetWindowPos(h, nullptr, nx, ny, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
        if (g_glass && IsWindowVisible(g_glass)) SetWindowPos(g_glass, nullptr, nx + u.m + 1, ny + u.m + 1, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);  // 毛玻璃的背景窗口一起走（层次不动）
        u.winPos = {nx, ny};
        return 0;
      }
      bool wasHover = u.hover;
      SetHover(true);
      int id = HitAt(mx, my);
      bool body = id != 0 || (mx >= u.m && my >= u.m && mx < u.m + (int)u.W && my < u.m + (int)u.H);  // 1.5.0：在悬浮窗本身上（同 TM_LEAVE 的判断；不算四周的投影）
      if (id != u.hoverId || !wasHover || body != u.hoverBody) {
        // 提示：鼠标下要的提示变了才收起、重新计时 0.6 秒；与原来一样，换了地方就收起首次使用提示。1.5.0：账号提示对着整个悬浮窗——在空白处、开关、切换键之间
        // 移动时不收不闪；按下之后（g_tipTarget 留着账号）也不重新计时，要移到只有图标的按钮上或移出悬浮窗再回来才再显示（同系统的工具提示）。没有账号时与原来完全一样
        // 从悬浮窗移到四周的投影上算离开了账号提示的范围：收起（点过、自己收起之后也一样，移回来照常显示）
        int want = TipWant(id, body);
        bool keep = want == TIP_ACCOUNT && g_tipTarget == TIP_ACCOUNT && g_hintText.empty();
        if (!keep && (id != u.hoverId || want >= 0 || (g_tipTarget == TIP_ACCOUNT && want != TIP_ACCOUNT))) { HideTip(); if (want >= 0) { g_tipTarget = want; SetTimer(h, TM_TIP, 600, nullptr); } }
        u.hoverId = id; u.hoverBody = body; Render();
      }
      return 0;
    }
    case WM_MOUSELEAVE: {
      Ui& u = *up; u.tracking = false;
      if (u.dragging || u.pressed) return 0;
      SetTimer(h, TM_LEAVE, 240, nullptr);
      return 0;
    }
    case WM_LBUTTONDOWN: {
      Ui& u = *up;
      if (g_galOpen) { GalleryClose(true); return 0; }  // 画廊开着时点悬浮窗：只当取消，不触发悬浮窗上的按钮
      { int tt = g_tipTarget; HideTip(); if (tt == TIP_ACCOUNT) g_tipTarget = tt; }  // 1.5.0：按下收起提示；账号提示要移出这片地方再回来才再显示（同系统的工具提示：点过之后不再弹）
      SetCapture(h); u.pressed = true; u.pressPt = {u.winPos.x + (short)LOWORD(lp), u.winPos.y + (short)HIWORD(lp)}; u.pressWin = u.winPos;
      u.pressId = HitAt((short)LOWORD(lp), (short)HIWORD(lp));
      if (u.pressId) Render();
      return 0;
    }
    case WM_LBUTTONUP: {
      Ui& u = *up;
      bool was = u.pressed; u.pressed = false; ReleaseCapture();
      if (!was) { g_clickMiss = 1; return 0; }
      if (u.dragging) { if (u.pressId) g_clickMiss = 2; EndDrag(); return 0; }
      int id = HitAt((short)LOWORD(lp), (short)HIWORD(lp));
      int pid = u.pressId; u.pressId = 0;
      if (pid && id != pid) g_clickMiss = 3 | (id << 8) | (pid << 16);
      if (g_dock && !u.dockOpen) { u.dockOpen = true; Render(); return 0; }
      if (id && id == pid) {
        int ev = HitToEvent(id);
        Render();
        if (ev) Fire(ev);
      } else Render();
      return 0;
    }
    case WM_CAPTURECHANGED: {  // 按着时失去鼠标捕获（Alt+Tab、别的窗口弹出等）：收尾，不留“按下 / 拖动中”的状态
      Ui& u = *up;
      if ((HWND)lp == h) return 0;
      if (u.pressed) InterlockedIncrement(&g_capLost);
      if (u.dragging) { u.pressed = false; u.pressId = 0; EndDrag(); return 0; }
      if (u.pressed) { u.pressed = false; u.pressId = 0; Render(); }
      return 0;
    }
    case WM_LBUTTONDBLCLK: {
      int id = HitAt((short)LOWORD(lp), (short)HIWORD(lp));
      if (id == 0) Fire(XE_OPEN_PANEL);
      // 双击按钮：第一下已经按单击处理过了，第二下不再触发（与原悬浮窗相同：双击开关只切换一次；双击“全部暂停”不会暂停又继续）
      return 0;
    }
    case WM_MOUSEWHEEL: {  // Ctrl＋滚轮：调大小（往上滚变大），交给易语言存配置后再设回来
      if (!(GET_KEYSTATE_WPARAM(wp) & MK_CONTROL)) break;
      Ui& u = *up; Lock(); XState st = g_state; Unlock();
      static const int A[5] = {80, 100, 125, 150, 200}, B[3] = {100, 150, 200};
      bool px = SkinTraitsOf(st.skin).pixel; const int* L = px ? B : A; int n = px ? 3 : 5, cur = XfScalePct(st), i = 0;
      while (i < n - 1 && L[i] < cur) i++;
      int j = i + (GET_WHEEL_DELTA_WPARAM(wp) > 0 ? 1 : -1); if (j < 0) j = 0; if (j >= n) j = n - 1;
      (void)u; if (L[j] != cur) Fire(XE_SCALE, L[j]);
      return 0;
    }
    case WM_RBUTTONUP: {  // 右键任何位置：弹出跟当前皮肤一致的菜单（打开主面板、快捷键开关、设置切换快捷键、皮肤、大小、隐藏悬浮窗、退出）
      if (g_galOpen) { GalleryClose(true); return 0; }
      { int tt = g_tipTarget; HideTip(); if (tt == TIP_ACCOUNT) g_tipTarget = tt; }  // 1.5.0：同左键按下——收起提示，账号提示要移出这片地方再回来才再显示（原来菜单关掉后移到别处就又弹出来）
      RunMenu(h, -1);
      return 0;
    }
    case WM_MEASUREITEM: { Ctx c = MenuCtx(); if (XfMenuMeasure((MEASUREITEMSTRUCT*)lp, c)) return TRUE; break; }
    case WM_DRAWITEM: { Ctx c = MenuCtx(); if (XfMenuDraw((DRAWITEMSTRUCT*)lp, c)) return TRUE; break; }
    case WM_TIMER: {
      Ui& u = *up;
      if (wp == TM_ANIM) { Render(); return 0; }
      if (wp == TM_RETRY) { KillTimer(h, TM_RETRY); u.lastKey.clear(); Render(); return 0; }  // 上一帧没贴上：重试
      if (wp == TM_GUARD) { if (EnsureOwnWindowState()) { u.lastKey.clear(); Render(); } return 0; }  // 每 2 秒核对窗口是不是还是自己的样子，改了就恢复、重贴一次
      if (wp == TM_HINT) { HideTip(); return 0; }
      if (wp == TM_TIPPOP) { KillTimer(h, TM_TIPPOP); if (g_tipKey == TIP_ACCOUNT) { HideTip(); g_tipTarget = TIP_ACCOUNT; } return 0; }  // 1.5.0：账号提示到时收起；同点过之后，移到只有图标的按钮上或移出再回来才再显示
      if (wp == TM_PREVEND) { KillTimer(h, TM_PREVEND); if (g_previewCommit) { g_previewCommit = false; g_previewSkin = 0; u.lastKey.clear(); Render(); } return 0; }  // 3 秒还没换上（易语言没处理）：恢复
      if (wp == TM_TIP) {
        KillTimer(h, TM_TIP);
        if (u.hover && !u.pressed && !u.dragging) {
          if (g_tipTarget == TIP_ACCOUNT && g_dock && !(u.dockOpen || g_testDockOpen || g_galOpen || g_inMenu)) SetTimer(h, TM_TIP, 200, nullptr);  // 1.5.0：贴边收起着：展开了再显示账号（悬停 0.16 秒就展开，一般用不上）
          else if (!ShowTip() && g_hintText.empty()) g_tipTarget = -1;
        }
        return 0;
      }
      if (wp == TM_HOVER) { KillTimer(h, TM_HOVER); if (u.hover) { u.hoverIntent = true; if (g_dock) u.dockOpen = true; Render(); } return 0; }
      if (wp == TM_LEAVE) {
        KillTimer(h, TM_LEAVE);
        POINT p; GetCursorPos(&p); RECT wr; GetWindowRect(h, &wr);
        if (PtInRect(&wr, p)) {  // 还在窗口范围里（透明边缘），再等等
          POINT cp = p; ScreenToClient(h, &cp);
          if (HitAt(cp.x, cp.y) || (cp.x >= u.m && cp.y >= u.m && cp.x < u.m + (int)u.W && cp.y < u.m + (int)u.H)) { SetTimer(h, TM_LEAVE, 200, nullptr); return 0; }
        }
        SetHover(false); HideTip();
        if (g_dock && u.dockOpen) { SetTimer(h, TM_DOCKCLOSE, 380, nullptr); }
        Render();
        return 0;
      }
      if (wp == TM_DOCKCLOSE) { KillTimer(h, TM_DOCKCLOSE); if (!u.hover) { u.dockOpen = false; Render(); } return 0; }
      return 0;
    }
    case 0x02E0: {  // WM_DPICHANGED
      Ui& u = *up; u.shadowHash = 0; u.lastKey.clear(); Render(); return 0;
    }
    case WM_DISPLAYCHANGE: if (up) { up->lastKey.clear(); if (!up->dragging) LayoutChanged(); } Render(); return 0;
    case WM_SETTINGCHANGE: {
      g_glassSysLast = 0;  // 透明效果的开关可能变了：毛玻璃下一帧重新判断
      if (lp && wcscmp((const wchar_t*)lp, L"ImmersiveColorSet") == 0) { up->dark = SystemDark(); up->lastKey.clear(); Render(); }
      else if (wp == SPI_SETWORKAREA && up) { up->lastKey.clear(); Render(); }  // 任务栏挪动、改大小（工作区变了）：重新摆一次，不压在任务栏下面（原来要等下一次画面变化）
      return 0;
    }
    case WM_APP + 0x78: if (!IsWindowVisible(h) || g_inMenu) { g_hintPending = true; return 0; }  // 隐藏着：等显示出来再提示（1.3.3：右键菜单开着时也等，菜单关掉后再提示）
      g_hintText = MenuCtx().T(M_HINT); ShowTip(); if (g_tipKey == 9999) SetTimer(h, TM_HINT, 8000, nullptr); else g_hintText.clear(); return 0;  // 首次使用提示（选项 5）：显示 8 秒
    case WM_APP + 0x7A: if (!g_galOpen) { SetPreview(0); GalleryOpen(); } return 0;  // 选项 7：打开皮肤画廊
    case WM_APP + 0x7C: Recover(); return 0;  // 选项 10：找回悬浮窗
    case WM_APP + 0x7D: XfTextTestFail((int)wp); if (U_) U_->lastKey.clear(); PostDirty(); return 0;  // 仅测试（选项 116）：在界面线程里清掉文字画法的各级缓存、重新自检
    case WM_APP + 0x7E: { INT_PTR v = (INT_PTR)wp; XfFineSet((v & 0xFF) != 0, ((v >> 8) & 0xFFF) / 100.f, ((v >> 20) & 0xFFF) ? ((v >> 20) & 0xFFF) / 100.f : -1.f); if (U_) U_->lastKey.clear(); PostDirty(); return 0; }  // 仅测试（选项 106）：在界面线程里切换精绘、清覆盖率图缓存
    case WM_APP + 0x77:  // 仅测试（选项 110）：故意访问空指针，验证闪退现场记录
      // cppcheck-suppress nullPointer
      if (g_testCrashOk) { volatile int* z = nullptr; *z = 1; } return 0;
    case WM_CLOSE: DestroyWindow(h); return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
  }
  return DefWindowProcW(h, msg, wp, lp);
}

// ---- 线程
struct StartArgs { HANDLE ready; bool ok; int x, y, flags; };
// ---- 闪退现场记录：进程里任何线程出现未处理的异常（即将闪退）时，在 DLL 所在目录的「崩溃记录」里写一份文字说明（异常代码、出错模块与偏移、
// 线程是否为悬浮窗界面线程）和一份小型转储（dbghelp 动态载入，不增加导入表），然后交回原来的处理（Windows 错误报告照旧）。程序原来没有任何崩溃记录
static LPTOP_LEVEL_EXCEPTION_FILTER g_prevFilter = nullptr;
static volatile LONG g_filterSet = 0;
static volatile DWORD g_uiTid = 0;
static LONG WINAPI CrashFilter(EXCEPTION_POINTERS* ep) {
  static volatile LONG once = 0;
  if (InterlockedExchange(&once, 1) == 0 && ep && ep->ExceptionRecord) {
    wchar_t dir[MAX_PATH] = L""; HMODULE me = nullptr;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)(void*)&CrashFilter, &me);
    GetModuleFileNameW(me, dir, MAX_PATH); wchar_t* sl = wcsrchr(dir, L'\\'); if (sl) *sl = 0;
    wcsncat(dir, L"\\崩溃记录", MAX_PATH - wcslen(dir) - 1); CreateDirectoryW(dir, nullptr);
    SYSTEMTIME st; GetLocalTime(&st); wchar_t base[MAX_PATH];
    swprintf(base, MAX_PATH, L"%ls\\%04d%02d%02d_%02d%02d%02d", dir, st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
    void* addr = ep->ExceptionRecord->ExceptionAddress; wchar_t mod[MAX_PATH] = L"?"; HMODULE hm = nullptr; unsigned long off = 0;
    if (GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)addr, &hm)) { GetModuleFileNameW(hm, mod, MAX_PATH); off = (unsigned long)((DWORD_PTR)addr - (DWORD_PTR)hm); }
    wchar_t txt[1024];
    swprintf(txt, 1024, L"异常代码 0x%08lX\r\n出错地址 0x%p\r\n出错模块 %ls\r\n模块内偏移 0x%08lX\r\n线程 %lu（%ls）\r\nXhhFloat 版本 %d\r\n",
             (unsigned long)ep->ExceptionRecord->ExceptionCode, addr, mod, off, (unsigned long)GetCurrentThreadId(),
             GetCurrentThreadId() == g_uiTid ? L"悬浮窗界面线程" : L"其它线程", XF_VERSION);
    wchar_t path[MAX_PATH]; swprintf(path, MAX_PATH, L"%ls.txt", base);
    HANDLE f = CreateFileW(path, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
    if (f != INVALID_HANDLE_VALUE) {
      char u8[3072]; int n = WideCharToMultiByte(CP_UTF8, 0, txt, -1, u8, sizeof(u8), nullptr, nullptr); DWORD w;
      if (n > 1) { WriteFile(f, "\xEF\xBB\xBF", 3, &w, nullptr); WriteFile(f, u8, (DWORD)(n - 1), &w, nullptr); }
      CloseHandle(f);
    }
    HMODULE dh = LoadSystemDll(L"dbghelp.dll");  // 按系统目录载入（原来只给文件名：程序目录里有同名的旧版或别人放的 dbghelp.dll 时会先载入它）
    typedef BOOL(WINAPI * MDW)(HANDLE, DWORD, HANDLE, int, void*, void*, void*);
    MDW mdw = dh ? (MDW)(void*)GetProcAddress(dh, "MiniDumpWriteDump") : nullptr;
    if (mdw) {
      swprintf(path, MAX_PATH, L"%ls.dmp", base);
      HANDLE d = CreateFileW(path, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
      if (d != INVALID_HANDLE_VALUE) {
        struct { DWORD tid; EXCEPTION_POINTERS* ep; BOOL client; } mei = {GetCurrentThreadId(), ep, FALSE};  // MINIDUMP_EXCEPTION_INFORMATION
        mdw(GetCurrentProcess(), GetCurrentProcessId(), d, 0x00001000 /*MiniDumpWithThreadInfo*/, &mei, nullptr, nullptr);
        CloseHandle(d);
      }
    }
  }
  return g_prevFilter ? g_prevFilter(ep) : EXCEPTION_CONTINUE_SEARCH;
}
static DWORD WINAPI ThreadMain(LPVOID p) {
  g_uiTid = GetCurrentThreadId();
  StartArgs* a = (StartArgs*)p;
  // 进程是 DPI 不感知的（易语言界面靠系统缩放）；悬浮窗按每个显示器的 DPI 自己画，高分屏上不发糊（Win10 1607+）
  typedef HANDLE(WINAPI * PSTDAC)(HANDLE);
  PSTDAC stdac = (PSTDAC)(void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetThreadDpiAwarenessContext");
  if (stdac) { if (stdac((HANDLE)(INT_PTR)-4) || stdac((HANDLE)(INT_PTR)-3)) g_pmAware = true; }
  ULONG_PTR tok = 0; GdiplusStartupInput gi;
  Status gs = GdiplusStartup(&tok, &gi, nullptr);
  if (gs != Ok) { g_startErr = 0x10000 | (int)gs; a->ok = false; SetEvent(a->ready); return 1; }
  U_ = new Ui();
  U_->dark = SystemDark();
  { BOOL anim = TRUE; if (SystemParametersInfoW(0x1042 /*SPI_GETCLIENTAREAANIMATION*/, 0, &anim, 0) && !anim) U_->mq.reduce = true; }  // 系统设置里关了动画：曲名不滚
  WNDCLASSEXW wc = {sizeof(wc)};
  wc.style = CS_DBLCLKS; wc.lpfnWndProc = WndProc; wc.hInstance = GetModuleHandleW(nullptr); wc.hCursor = LoadCursor(nullptr, IDC_ARROW); wc.lpszClassName = L"XhhFloatWindow";
  RegisterClassExW(&wc);
  { WNDCLASSEXW glc = {sizeof(glc)}; glc.lpfnWndProc = GlassProc; glc.hInstance = wc.hInstance; glc.lpszClassName = L"XhhFloatGlass"; RegisterClassExW(&glc); }  // 毛玻璃的背景窗口（用到时才建）
  WNDCLASSEXW tc = {sizeof(tc)}; tc.lpfnWndProc = DefWindowProcW; tc.hInstance = wc.hInstance; tc.lpszClassName = L"XhhFloatTip"; RegisterClassExW(&tc);
  { int d; Lock(); d = g_testStartDelay; Unlock(); if (d > 0) Sleep((DWORD)d); }
  bool top; Lock(); top = g_opt[3] != 0; Unlock();
  HWND h = CreateWindowExW(WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | (top ? WS_EX_TOPMOST : 0), L"XhhFloatWindow", L"XhhFloat", WS_POPUP, 0, 0, 10, 10, nullptr, nullptr, wc.hInstance, nullptr);
  if (!h) { g_startErr = 0x20000 | (int)(GetLastError() & 0xFFFF); a->ok = false; SetEvent(a->ready); delete U_; U_ = nullptr; GdiplusShutdown(tok); return 1; }
  // 初始位置：旧版保存的坐标（DPI 不感知的逻辑坐标）换算成物理像素；没有保存过时放在右上角
  POINT anc = {a->x, a->y};
  bool legacy = (a->flags & 1) != 0;
  int sd = SysDpi();
  if (legacy) { anc.x = MulDiv(anc.x, sd, 96); anc.y = MulDiv(anc.y, sd, 96); }
  // 原悬浮窗的规则（按轴分别判断）：左边 ≤ 0 时放到屏幕右侧，顶边 ≤ 0 时放到距顶 50 处。新版自己存的坐标在多显示器上可以是负数，不按这条处理
  bool freshX = legacy && a->x <= 0, freshY = legacy && a->y <= 0;
  // 1.2.0 标志 4：按显示布局记忆位置（见 README「多显示器与位置记忆」）。依次：本机记得这种显示布局下的位置 → 用它；
  // 原悬浮窗的坐标 → 逐轴判断，换算后不在主屏范围里的那一轴按默认（原悬浮窗启动时就把主屏以外的位置一律放回主屏，用户一直是在主屏上看到它的；原来只照搬了 ≤0 那一半）；
  // 账号配置里新版存的位置 → 同一种显示布局照用；别的显示布局下存的只在主屏上才用（可能来自别的电脑：这台电脑同一处也许是电视、关着的屏），否则用默认位置；旧版本存的（没记布局）照用
  bool mem = (a->flags & XS_MEMORY) != 0;
  int monN = 0, src = 0, dockSet = -1;
  DWORD sig = LayoutSig(&monN);
  if (mem) {
    MemPos mp = MemRead(sig);
    if (mp.ok) { anc.x = mp.x; anc.y = mp.y; legacy = false; freshX = freshY = false; dockSet = mp.dock; src = PS_MEMORY; }
    else if (legacy) {
      RECT pm = PrimaryRect(false);
      if (anc.x >= pm.right) freshX = true;
      if (anc.y >= pm.bottom) freshY = true;
      src = (freshX && freshY) ? PS_DEFAULT : PS_LEGACY;
    } else {
      DWORD hs; int dk; bool ar; Lock(); hs = g_hintSig; dk = g_dock; ar = g_anchorRight; Unlock();
      if (hs && hs == sig) src = PS_SAME;
      else if (!hs) src = PS_UNKNOWN;
      else if (HintOnPrimary(anc, ar, dk)) src = PS_PRIMARY;
      else { src = PS_REJECTED; freshX = freshY = true; dockSet = 0x100; }  // 默认位置：主屏右上，不贴边、锚点在右（同原悬浮窗没存过时）
    }
  }
  RECT wa = WorkAreaAt(anc);
  if (freshX || freshY) { POINT pp = {0, 0}; wa = WorkAreaAt(pp); }  // 没存过：用主显示器
  if (freshX) anc.x = wa.right - MulDiv(100, sd, 96);
  if (freshY) anc.y = wa.top + MulDiv(50, sd, 96);
  bool fresh = freshX;
  Lock();
  if (g_stopReq) {  // 启动等太久、调用方已经放弃并叫停：不显示，收拾好直接退出（不留一个没人管的窗口）
    Unlock();
    DestroyWindow(h);
    delete U_->measureG; delete U_->measureBmp; U_->fonts.clear();  // 与正常退出同样的收尾：GDI+ 对象要在 GdiplusShutdown 之前释放
    delete U_; U_ = nullptr;
    UnregisterClassW(L"XhhFloatWindow", wc.hInstance);
    GdiplusShutdown(tok);
    a->ok = false; SetEvent(a->ready);
    return 1;
  }
  g_hwnd = h; g_anchor = anc;
  if (legacy) { g_dock = 0; g_anchorRight = fresh; }  // 原悬浮窗的坐标是窗口左上角、没有贴边；新版坐标的贴边与锚点那一侧由 XO_DOCK 事先交代
  if (dockSet >= 0) { g_dock = dockSet & 0xFF; g_anchorRight = (dockSet & 0x100) != 0; }  // 本机记忆里的贴边，或改用默认位置（不贴边）
  g_visible = !(a->flags & 2);
  g_memUse = mem; g_layoutSig = sig; g_monCount = monN; g_posSrc = src;
  Unlock();
  if (mem) { std::wstring f = MemFile(); int c = f.empty() ? 0 : (int)MemOrder(f).size(); Lock(); g_memCount = c; Unlock(); }
  g_tip = CreateWindowExW(WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_TOPMOST | WS_EX_NOACTIVATE, L"XhhFloatTip", L"", WS_POPUP, 0, 0, 1, 1, nullptr, nullptr, wc.hInstance, nullptr);  // 不在锁里建窗口
  WNDCLASSEXW gc = {sizeof(gc)}; gc.lpfnWndProc = GalProc; gc.hInstance = wc.hInstance; gc.hCursor = LoadCursor(nullptr, IDC_ARROW); gc.lpszClassName = L"XhhFloatGallery"; RegisterClassExW(&gc);
  g_gal = CreateWindowExW(WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_TOPMOST | WS_EX_NOACTIVATE, L"XhhFloatGallery", L"", WS_POPUP, 0, 0, 1, 1, nullptr, nullptr, wc.hInstance, nullptr);  // 皮肤画廊（不抢焦点）
  a->ok = true;
  EnsureOwnWindowState();  // 建窗口时就可能被改（换肤库的建窗口钩子）：第一帧之前先核对
  SetTimer(h, TM_GUARD, 2000, nullptr);
  Render();
  SetEvent(a->ready);
  MSG m;
  while (GetMessageW(&m, nullptr, 0, 0) > 0) { TranslateMessage(&m); DispatchMessageW(&m); }
  if (g_tip) { DestroyWindow(g_tip); g_tip = nullptr; }
  g_tipKey = -1; g_tipTarget = -1; g_tipShown.clear(); SetRectEmpty(&g_tipAt); Lock(); g_tipText8[0] = 0; Unlock();  // 1.5.0：下一次启动不带着这次的提示状态（账号留着：易语言每次启动前都会再交代）
  UnregisterClassW(L"XhhFloatTip", wc.hInstance);
  g_galOpen = false; g_previewSkin = 0; g_previewCommit = false; G = GalState(); g_zLater = false;  // 1.3.3：菜单开着时推迟的换层请求不留给下一次启动
  if (g_gal) { DestroyWindow(g_gal); g_gal = nullptr; }
  UnregisterClassW(L"XhhFloatGallery", wc.hInstance);
  if (g_glass) { DestroyWindow(g_glass); g_glass = nullptr; } g_glassState = 0; g_glassW = g_glassH = 0;
  UnregisterClassW(L"XhhFloatGlass", wc.hInstance);
  Lock(); g_hwnd = nullptr; Unlock();
  delete U_->measureG; delete U_->measureBmp;
  U_->fonts.clear();
  XfFineReset();
  delete U_; U_ = nullptr;
  UnregisterClassW(L"XhhFloatWindow", wc.hInstance);
  GdiplusShutdown(tok);
  return 0;
}

// =================================================================================================
// 导出接口：每个都是 4 个指针宽度的参数（易语言用 调用桩_4参数 调用，见 xf.h 开头）
static std::wstring Arg(INT_PTR p) { return Utf8ToW((const char*)p); }

XF_API XF_GetVersion(INT_PTR, INT_PTR, INT_PTR, INT_PTR) { return XF_VERSION; }

XF_API XF_Start(INT_PTR x, INT_PTR y, INT_PTR flags, INT_PTR cb) {
  if (InterlockedExchange(&g_filterSet, 1) == 0) g_prevFilter = SetUnhandledExceptionFilter(CrashFilter);  // 闪退现场记录（只装一次，原有的处理照旧接在后面）
  EnsureCs();
  Lock(); g_cb = (XfCallback)cb; bool running = g_thread != nullptr; if (!running) g_stopReq = false; int wait = g_testStartWait > 0 ? g_testStartWait : 15000; Unlock();
  if (running) return 1;
  StartArgs* ap = new StartArgs(); StartArgs& a = *ap;  // 堆上：等待超时时线程可能还在写它（此时不释放，进程结束时回收）
  a.ready = CreateEventW(nullptr, TRUE, FALSE, nullptr); a.ok = false; a.x = (int)SaneCoord(x); a.y = (int)SaneCoord(y); a.flags = (int)flags;
  HANDLE th = CreateThread(nullptr, 0, ThreadMain, ap, 0, &g_tid);
  if (!th) { CloseHandle(a.ready); delete ap; return 0; }
  // 冷启动（首次装字体缓存等）可能较慢：最多等 15 秒；超时也记下线程，XF_Stop 能收尾
  if (WaitForSingleObject(a.ready, (DWORD)wait) != WAIT_OBJECT_0) { g_startErr = 0x30000; Lock(); g_thread = th; Unlock(); return 0; }
  CloseHandle(a.ready);
  bool ok = a.ok; delete ap;
  if (!ok) { WaitForSingleObject(th, 3000); CloseHandle(th); g_tid = 0; return 0; }
  Lock(); g_thread = th; Unlock();
  return 1;
}
XF_API XF_Stop(INT_PTR, INT_PTR, INT_PTR, INT_PTR) {
  if (!g_csInit) return 1;
  HANDLE th; HWND h; Lock(); g_stopReq = true; th = g_thread; h = g_hwnd; g_thread = nullptr; g_cb = nullptr; Unlock();  // 先置叫停：还没建好窗口的线程建好后会自己退出
  if (!th) return 1;
  if (h) PostMessageW(h, WM_CLOSE, 0, 0);
  DWORD r = WaitForSingleObject(th, 5000);
  CloseHandle(th);
  return r == WAIT_OBJECT_0 ? 1 : 0;
}
XF_API XF_Show(INT_PTR visible, INT_PTR, INT_PTR, INT_PTR) {
  EnsureCs(); Lock(); g_visible = visible != 0; PostDirty(); Unlock(); return 1;
}
XF_API XF_SetSkin(INT_PTR skin, INT_PTR, INT_PTR, INT_PTR) {
  if (skin < 1 || skin > SK_COUNT) return 0;
  EnsureCs(); Lock(); g_skinSeq++; if (g_state.skin != (int)skin || g_previewCommit) { g_state.skin = (int)skin; PostDirty(); } Unlock(); return 1;
}
XF_API XF_SetLanguage(INT_PTR code, INT_PTR, INT_PTR, INT_PTR) {
  EnsureCs(); int li = I18nLangIndex((const char*)code);
  Lock(); if (g_state.lang != li) { g_state.lang = li; g_state.rtl = I18nRtl(li); PostDirty(); } Unlock(); return 1;
}
XF_API XF_SetFontDir(INT_PTR dir, INT_PTR, INT_PTR, INT_PTR) {
  EnsureCs(); std::wstring d = Arg(dir);
  // 字体目录在界面线程里用（字体对象只在那个线程建）：这里记下，下次绘制时交给 Fonts
  Lock(); if (g_fontDir != d) { g_fontDir = d; PostDirty(); } Unlock();  // 易语言每 0.5 秒推一次：没变就什么也不做
  return 1;
}
XF_API XF_SetHotkeys(INT_PTR on, INT_PTR key, INT_PTR numWarn, INT_PTR) {
  EnsureCs(); std::wstring k = Arg(key);
  Lock();
  if (g_state.armed != (on != 0) || g_state.key != k || g_state.numlock != (numWarn != 0)) { g_state.armed = on != 0; g_state.key = k; g_state.numlock = numWarn != 0; PostDirty(); }
  Unlock(); return 1;
}
XF_API XF_SetTrackInfo(INT_PTR which, INT_PTR st, INT_PTR name, INT_PTR) {
  EnsureCs(); std::wstring n = Arg(name);
  Lock();
  Track& t = which ? g_state.bgm : g_state.sfx;
  if (t.state != (int)st || t.name != n) { t.state = (int)st; t.name = n; PostDirty(); }
  Unlock(); return 1;
}
XF_API XF_SetTrackTime(INT_PTR which, INT_PTR pos, INT_PTR len, INT_PTR level) {
  EnsureCs();
  Lock();
  Track& t = which ? g_state.bgm : g_state.sfx;
  int oldRemainSec = (t.lenMs - t.posMs) / 1000;
  t.posMs = (int)pos; t.lenMs = (int)len; t.level = (int)level; t.stamp = GetTickCount();
  if (!g_animating && (t.lenMs - t.posMs) / 1000 != oldRemainSec) PostDirty();
  Unlock(); return 1;
}
XF_API XF_SetTrackClip(INT_PTR which, INT_PTR a, INT_PTR b, INT_PTR) {
  EnsureCs(); Lock(); Track& t = which ? g_state.bgm : g_state.sfx;
  if (t.clipStartMs != (int)a || t.clipEndMs != (int)b) { t.clipStartMs = (int)a; t.clipEndMs = (int)b; PostDirty(); }
  Unlock(); return 1;
}
XF_API XF_SetDuck(INT_PTR ds, INT_PTR db, INT_PTR loop, INT_PTR order) {
  EnsureCs(); Lock();
  if (g_state.duckS != (int)ds || g_state.duckB != (int)db || g_state.loop != (loop != 0) || g_state.order != (int)order) {
    g_state.duckS = (int)ds; g_state.duckB = (int)db; g_state.loop = loop != 0; g_state.order = (int)order; PostDirty();
  }
  Unlock(); return 1;
}
bool g_shotItem = false;  // 1.3.2：右键菜单有「截屏」（XO_SHOTITEM；界面线程弹菜单时读）
XF_API XF_SetOption(INT_PTR opt, INT_PTR val, INT_PTR a3, INT_PTR) {
  EnsureCs();
  HWND h; Lock(); h = g_hwnd; Unlock();
  switch (opt) {
    case 4: {  // 大小：第 a3 款（1～16；0＝当前这款）改为 val %（50～300）
      int v = (int)val; if (v < 50 || v > 300) return 0;
      Lock(); int sk = (a3 >= 1 && a3 <= SK_COUNT) ? (int)a3 : g_state.skin; g_state.scale[sk] = v; PostDirty(); Unlock(); return 1;
    }
    case XO_DOCK: Lock(); g_dock = (int)(val & 0xFF); if (g_dock < 0 || g_dock > 3) g_dock = 0; g_anchorRight = (val & 0x100) != 0; PostDirty(); Unlock(); return 1;
    case XO_TOPMOST: Lock(); g_opt[3] = val != 0; Unlock(); if (h) PostMessageW(h, WM_APP + 0x7B, 1, 0); return 1;  // 换层在界面线程里做（原来在调用方线程里跨线程 SetWindowPos：实测之后在界面线程里调的层次不生效，毛玻璃背景留在卡片上面）
    case XO_TEST_FREEZE: Lock(); g_freeze = (int)val; PostDirty(); Unlock(); return 1;
    case XO_TEST_HOVER: Lock(); g_testHover = (int)val; PostDirty(); Unlock(); return 1;
    case XO_TEST_DARK: Lock(); g_testDark = (int)val; PostDirty(); Unlock(); return 1;
    case 108: if (U_) { U_->mq.test = (int)val; U_->lastKey.clear(); } PostDirty(); return 1;  // 测试：曲名滚动按这个经过时间（毫秒，-1＝按真实时间）
    case XO_MEMFILE: { std::wstring f = val ? Arg(val) : std::wstring(); Lock(); g_memFile = f; Unlock(); return 1; }  // 本机位置记忆文件（XF_Start 之前交代；空＝不记）
    case XO_RECOVER: if (!h || !val) return 0; PostMessageW(h, WM_APP + 0x7C, 0, 0); return 1;  // 找回悬浮窗：在界面线程里做（鼠标位置要按界面线程的 DPI 感知取）
    case XO_SHOTITEM: g_shotItem = val != 0; return 1;  // 1.3.2：右键菜单有没有「截屏」（下次弹出菜单时生效）
    case XO_HINTSIG: Lock(); g_hintSig = (DWORD)val; Unlock(); return 1;  // XF_Start 交来的位置是在哪种显示布局下存的（XF_Start 之前交代）
    case XO_ACCOUNT: {  // 1.5.0：软件账号（UTF-8；空或 0＝没有）。易语言启动前交代、之后每 0.5 秒推一次：没变就什么也不做；变了让界面线程把显示着的账号提示改过来（或收起）
      std::wstring v = CleanAccount(val ? Arg(val) : std::wstring());
      Lock(); if (g_account != v) { g_account = v; PostDirty(); } Unlock(); return 1;
    }
    case 7: {  // 打开皮肤画廊：请求时就按 XF_Show 记下的状态判断（同步记下的），隐藏着当场不受理、返回 0——不投递，免得之后才处理时窗口已经又显示出来
      bool vis; Lock(); vis = g_visible; Unlock();  // （易语言先 XF_Show 1 再调这项：两条消息按先后处理，画廊打开时窗口已经显示）
      if (!vis || !g_hwnd || !val) return 0;
      PostMessageW(g_hwnd, WM_APP + 0x7A, 0, 0); return 1;
    }
    case 8: g_glassAllow = val != 0; Lock(); PostDirty(); Unlock(); return 1;  // 毛玻璃组件卡的实时模糊（默认开；系统不允许时照样不用）
    case 114: g_glassForce = val != 0; Lock(); PostDirty(); Unlock(); return 1;  // 测试：接口不可用也建背景窗口、按有模糊画
    case 5: if (!val) return 1; if (g_hwnd) PostMessageW(g_hwnd, WM_APP + 0x78, 0, 0); else g_hintPending = true; return 1;  // 易语言在 XF_Start 之前就请求（原来窗口还没建就丢了，提示从没出现过）：记下，窗口显示出来再提示  // 首次使用提示「右键可换皮肤、调大小、隐藏」（易语言只在第一次用时调用）
    case 112: { const char* s = (const char*)val; std::wstring w = s ? Utf8ToW(s) : L""; lstrcpynW(g_testTextLog, w.c_str(), 260); return 1; }  // 测试：文字记录文件（空＝不记）
    case 111: g_testNoText = val != 0; Lock(); PostDirty(); Unlock(); return 1;  // 测试：不画文字（对比度检查）
    case 113: g_testNoDots = val != 0; Lock(); PostDirty(); Unlock(); return 1;  // 测试：点阵屏不打点（对比度检查）
    case 110: g_testCrashOk = true; if (g_hwnd) PostMessageW(g_hwnd, WM_APP + 0x77, 0, 0); return 1;  // 测试：让界面线程出一次访问违例（验证闪退现场记录）
    case 109: if (U_) { U_->mq.reduce = val != 0; U_->lastKey.clear(); } PostDirty(); return 1;  // 测试：当作系统关闭了动画
    case 107: XfFineSetCacheLimit((size_t)val); return 1;  // 测试：覆盖率图缓存上限（0＝默认 4000）
    case XO_TEST_TEXTFAIL: if (h) SendMessageW(h, WM_APP + 0x7D, (WPARAM)val, 0); else { Lock(); XfTextTestFail((int)val); Unlock(); } return 1;  // 测试：模拟画不出字（重新自检）。清缓存交给界面线程做：画面不在锁里画，跨线程清掉字体表会与正在画的那一帧冲突
    case XO_TEST_NAMEFONT: Lock(); g_testNameScale = val ? 1.15f : 1.f; Unlock(); if (U_) U_->lastKey.clear(); PostDirty(); return 1;  // 测试：曲名字体故意与界面字体不同（查悬停时标题换字体）
    case XO_TEST_FINE: if (h) SendMessageW(h, WM_APP + 0x7E, (WPARAM)val, 0); else { Lock(); XfFineSet((val & 0xFF) != 0, ((val >> 8) & 0xFFF) / 100.f, ((val >> 20) & 0xFFF) ? ((val >> 20) & 0xFFF) / 100.f : -1.f); Unlock(); } return 1;  // 测试：清覆盖率图缓存同样交给界面线程做（见 XO_TEST_TEXTFAIL）
    case XO_TEST_STARTDELAY: Lock(); g_testStartDelay = (int)val; Unlock(); return 1;
    case XO_TEST_STARTWAIT: Lock(); g_testStartWait = (int)val; Unlock(); return 1;
    case XO_TEST_DOCKOPEN: Lock(); g_testDockOpen = (int)val; PostDirty(); Unlock(); return 1;
  }
  return 0;
}
XF_API XF_SetPos(INT_PTR x, INT_PTR y, INT_PTR anchorRight, INT_PTR) {
  EnsureCs(); Lock(); g_anchor.x = SaneCoord(x); g_anchor.y = SaneCoord(y); g_anchorRight = anchorRight != 0; PostDirty(); Unlock(); return 1;
}
XF_API XF_GetInfo(INT_PTR what, INT_PTR arg, INT_PTR, INT_PTR) {
  EnsureCs();
  INT_PTR r = 0;
  Lock();
  switch (what) {
    case XI_X: r = g_anchor.x; break;
    case XI_Y: r = g_anchor.y; break;
    case XI_VISIBLE: r = g_visible ? 1 : 0; break;
    case XI_SKIN: r = g_state.skin; break;
    case XI_DOCK: r = g_dock | (g_anchorRight ? 0x100 : 0); break;
    case XI_VERSION: r = XF_VERSION; break;
    case XI_DPI: r = g_infoDpi; break;
    case XI_HWND: r = (INT_PTR)g_hwnd; break;
    case XI_THREAD: r = (INT_PTR)g_tid; break;
    case XI_WIDTH: r = g_infoW; break;
    case XI_HEIGHT: r = g_infoH; break;
    case XI_ULWFAIL: r = g_ulwFail; break;                  // 诊断：贴画面失败的次数（失败后会自动重试）
    case XI_POSSRC: r = g_posSrc; break;                    // 现在的位置是怎么来的（PS_，见 xf.h）
    case XI_LAYOUT: r = (INT_PTR)(LONG)g_layoutSig; break;  // 当前显示布局签名（易语言存进配置「悬浮窗／布局签名」）
    case XI_MONITORS: r = g_monCount; break;                // 显示器个数
    case XI_ONPRIMARY: r = g_onPrimary; break;              // 悬浮窗在主屏上
    case XI_MEMCOUNT: r = g_memCount; break;                // 本机位置记忆里记着几种显示布局
    case XI_SELFFIX: r = g_selfFix; break;                  // 窗口被别的模块改动后自己恢复的次数
    case XI_PROCTAKEN: r = g_procTaken; break;              // 窗口过程被别的模块接管（1；只记录）
    case 13: r = g_startErr; break;
    case 15: r = g_frames; break;
    case 17: r = g_tipKey; break;  // 正在显示的提示：文字序号，TIP_HINT 首次使用提示，TIP_ACCOUNT 软件账号；-1＝没有
    case XI_TIPTEXT: r = (INT_PTR)g_tipText8; break;  // 1.5.0：显示着的提示的文字（UTF-8；诊断与测试用）
    case 18: r = g_previewSkin; break;  // 悬浮窗正在临时显示的皮肤（右键菜单里指着、画廊里指着或刚选定还没换上；0＝没有）
    case 19: r = g_galOpen ? 1 : 0; break;  // 皮肤画廊开着
    case 22: r = (INT_PTR)g_glass; break;  // 毛玻璃的背景窗口（没有＝0）
    case 23: r = g_glassState; break;      // 实时模糊：1 在用 0 还没试 -1 接口不可用
    case 24: r = g_clickMiss; break;       // 诊断：上一次按钮没算点击的原因（见 g_clickMiss）
    case 25: r = g_capLost; break;         // 诊断：按着时失去鼠标捕获的次数
    case 26: r = g_mlogN; break;           // 诊断：消息记录的总条数（每条见 WndProc 前的说明）
    default: if (what >= 27 && what < 59) { LONG n = g_mlogN, j = (LONG)what - 27; r = j < n ? g_mlog[(n - 1 - j) & 31] : 0; }
      else if (what >= 59 && what < 91) { LONG n = g_mlogN, j = (LONG)what - 59; r = j < n ? g_mlog2[(n - 1 - j) & 31] : 0; }
      else if (what == 91) r = g_menuN; else if (what == 92) r = g_menuMs; else if (what == 93) r = g_menuCmd;  // 诊断：右键菜单次数、上一次开了多久（毫秒）、选了哪项
      break;  // 诊断：由近到远第 what-27 条
    case 16: r = XfFontState(); break;
    case 102: r = XfTextPathInfo(); break;  // 诊断：文字实际用的画法（位 0 有字体没通过精绘自检 位 1 GDI+ 画字自检没通过 位 2 用 GDI 画过字）  // 简体中文界面实际用的字体（见 xf.h）
    case 14: r = U_ ? ((U_->hover ? 1 : 0) | (U_->hoverIntent ? 2 : 0) | (U_->tracking ? 4 : 0) | (U_->pressed ? 8 : 0) | (U_->dragging ? 16 : 0)) : -1; break;
  }
  Unlock();
  return r;
}
// 文字（UTF-8，静态缓冲，程序运行期间一直有效）：key 见 xf.h 的 S_ / M_ 序号；lang＝-1 用当前语种
XF_API XF_Text(INT_PTR key, INT_PTR lang, INT_PTR, INT_PTR) {
  EnsureCs();
  int li; Lock(); li = g_state.lang; Unlock();
  if (lang >= 0 && lang < I18nCount()) li = (int)lang;
  if (key < 0 || key >= S_COUNT) return (INT_PTR)"";
  return (INT_PTR)I18nUtf8(li, (int)key);
}
XF_API XF_Snapshot(INT_PTR path, INT_PTR pct, INT_PTR, INT_PTR) {
  EnsureCs();
  HWND h; Lock(); h = g_hwnd; Unlock();
  if (!h) return 0;
  SnapReq q; q.path = Arg(path); q.pct = (int)pct; q.ok = false;
  if (q.path.empty()) return 0;
  SendMessageW(h, WM_XF_SNAP, 0, (LPARAM)&q);
  return q.ok ? 1 : 0;
}
// 测试用：模拟鼠标（客户区坐标，物理像素）。kind：1 移动 2 左键按下 3 左键抬起 4 双击 5 右键 6 离开
XF_API XF_TestMouse(INT_PTR kind, INT_PTR x, INT_PTR y, INT_PTR) {
  EnsureCs(); HWND h; Lock(); h = g_hwnd; Unlock(); if (!h) return 0;
  LPARAM lp = MAKELPARAM((WORD)(short)x, (WORD)(short)y);
  switch (kind) {
    case 1: SendMessageW(h, WM_MOUSEMOVE, 0, lp); break;
    case 2: SendMessageW(h, WM_LBUTTONDOWN, MK_LBUTTON, lp); break;
    case 3: SendMessageW(h, WM_LBUTTONUP, 0, lp); break;
    case 4: SendMessageW(h, WM_LBUTTONDBLCLK, MK_LBUTTON, lp); break;
    case 5: SendMessageW(h, WM_RBUTTONUP, 0, lp); break;
    case 6: SendMessageW(h, WM_MOUSELEAVE, 0, 0); break;
    case 7: SendMessageW(h, WM_CAPTURECHANGED, 0, 0); break;  // 失去鼠标捕获
    case 8: PostMessageW(h, WM_RBUTTONUP, 0, lp); break;  // 右键（投递：弹出菜单时界面线程进入菜单循环，不能同步等）
  }
  return 1;
}
// 测试用：取第 i 个可点区域（客户区坐标，物理像素）：返回 id，没有返回 0
struct HitQ { int i; int id; RECT r; };
XF_API XF_TestHit(INT_PTR i, INT_PTR outRect, INT_PTR, INT_PTR) {
  EnsureCs(); HWND h; Lock(); h = g_hwnd; Unlock(); if (!h || !U_) return 0;
  // 只读：界面线程画完后才读（测试里先等重画完成）
  Ui& u = *U_;
  if (i < 0 || i >= (INT_PTR)u.hits.size()) return 0;
  const Hit& ht = u.hits[(size_t)i];
  float x0 = ht.r.X, x1 = ht.r.X + ht.r.Width;
  if (u.rtl) { float a = u.W - x1, b = u.W - x0; x0 = a; x1 = b; }
  RECT* r = (RECT*)outRect;
  if (r) { r->left = (LONG)(x0 + u.m); r->top = (LONG)(ht.r.Y + u.m); r->right = (LONG)(x1 + u.m); r->bottom = (LONG)(ht.r.Y + ht.r.Height + u.m); }
  return ht.id;
}
// 测试用：在界面线程里连续绘制 n 次（不贴到窗口），返回总耗时（微秒），用来核对 CPU 开销
XF_API XF_TestMenu(INT_PTR cmd, INT_PTR, INT_PTR, INT_PTR) {  // 测试：右键菜单选第 cmd 项（1 设置切换键 2 开关 3 主面板 9 预览全部皮肤… 101～116 皮肤 21 隐藏 22 退出 1050～1300 大小）
  EnsureCs(); HWND h; Lock(); h = g_hwnd; Unlock(); if (!h) return 0;
  SendMessageW(h, WM_XF_CALL, 3, (LPARAM)cmd); return 1;
}
XF_API XF_TestGallery(INT_PTR op, INT_PTR arg, INT_PTR path, INT_PTR) {  // 测试：皮肤画廊（1 画成 PNG 到 path 2 当作指着第 arg 款 3 当作点了第 arg 款 4 当作按了 Esc）
  EnsureCs(); HWND h; Lock(); h = g_hwnd; Unlock(); if (!h) return 0;
  std::wstring p = path ? Arg(path) : L""; struct GQ { int op, arg; const wchar_t* path; } q = {(int)op, (int)arg, p.c_str()};
  return SendMessageW(h, WM_XF_CALL, 5, (LPARAM)&q);
}
XF_API XF_TestMenuSnap(INT_PTR path, INT_PTR, INT_PTR, INT_PTR) {  // 测试：菜单（含皮肤子菜单）画成 PNG
  EnsureCs(); HWND h; Lock(); h = g_hwnd; Unlock(); if (!h) return 0;
  std::wstring p = Arg(path); return SendMessageW(h, WM_XF_CALL, 4, (LPARAM)p.c_str());
}
struct GQx { int ch, px10, bold; unsigned char* buf; int cap; long long sum; };
XF_API XF_TestFineGlyph(INT_PTR ch, INT_PTR px10, INT_PTR bold, INT_PTR buf) {
  EnsureCs(); HWND h; Lock(); h = g_hwnd; Unlock(); if (!h) return -2;
  GQx q = {(int)ch, (int)px10, (int)bold, (unsigned char*)buf, 65536, 0};
  SendMessageW(h, WM_XF_CALL, 2, (LPARAM)&q);
  return (INT_PTR)q.sum;
}
XF_API XF_TestRenderTime(INT_PTR n, INT_PTR, INT_PTR, INT_PTR) {
  EnsureCs(); HWND h; Lock(); h = g_hwnd; Unlock(); if (!h) return -1;
  TimeReq q; q.n = (int)n; q.us = 0;
  SendMessageW(h, WM_XF_CALL, 1, (LPARAM)&q);
  return (INT_PTR)q.us;
}
BOOL WINAPI DllMain(HINSTANCE, DWORD reason, LPVOID reserved) {
  // 被 FreeLibrary 卸载（不是进程退出）时：如果现在的处理仍是我们装的，把原来的装回去，免得之后指向已卸载的代码
  if (reason == DLL_PROCESS_DETACH && !reserved && g_filterSet) { LPTOP_LEVEL_EXCEPTION_FILTER cur = SetUnhandledExceptionFilter(g_prevFilter); if (cur != CrashFilter) SetUnhandledExceptionFilter(cur); }
  return TRUE;
}

// Fonts 需要知道字体目录：在 RenderTo 开头同步（放在这里避免头文件互相依赖）
bool XfSyncFontDir() {  // 把易语言交来的字体目录交给 Fonts（只在界面线程调用）；返回是否变了
  if (!U_) return false;
  std::wstring d; Lock(); d = g_fontDir; Unlock();
  if (d == U_->fonts.fontDir) return U_->fonts.hosCheck();  // 目录没变：字体包里的字坏了就换回系统字体，没写完的到时候再试
  U_->fonts.setFontDir(d);
  return true;
}
