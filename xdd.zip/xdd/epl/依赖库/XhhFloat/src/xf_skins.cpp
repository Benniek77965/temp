// 16 款皮肤。每款一个函数：同一段代码先量尺寸（c.draw＝假）、再绘制（c.draw＝真），可点区域在布局时登记。
// 坐标一律是“设计单位 × k”（k＝DPI 缩放）；原有 7 款的颜色、尺寸取自设计稿（悬浮窗方案_8款 的 1_方案总览；第 6 款音浪悬浮球已去掉），
// 新增 9 款（机械键帽、极光弥散、赛博机甲、多巴胺撞色、猫耳胶囊、拼贴手账、漫画波普、黑胶唱机、国潮印章）在文件后半部分。编号与顺序见 xf.h 的 SK_ 常量
#include "xf.h"
#include <math.h>

static inline float U(Ctx& c, float v) { return v * c.k; }
static const unsigned WT = 0xF5F5F7;

// 当前该显示哪一路：音效优先（一下就放完），没有音效时显示背景音乐
struct Now { const Track* t = nullptr; TrackView v; bool isBgm = false; };
static Now Primary(Ctx& c) {
  Now n; TrackView sv = ViewOf(c.s->sfx, c.now), bv = ViewOf(c.s->bgm, c.now);
  if (sv.on) { n.t = &c.s->sfx; n.v = sv; }
  else if (bv.on) { n.t = &c.s->bgm; n.v = bv; n.isBgm = true; }
  return n;
}
static int DuckOf(Ctx& c, bool* isBgm) {  // 显示哪一路的闪避（背景音乐优先：通常压的是音乐）
  TrackView sv = ViewOf(c.s->sfx, c.now), bv = ViewOf(c.s->bgm, c.now);
  if (c.s->duckB && (bv.on || !sv.on)) { *isBgm = true; return c.s->duckB; }
  if (c.s->duckS) { *isBgm = false; return c.s->duckS; }
  if (c.s->duckB) { *isBgm = true; return c.s->duckB; }
  return 0;
}
static bool NumWarn(Ctx& c) { return c.s->numlock && c.s->armed; }
// 1.3.0：悬停那一排的“暂停 / 继续”只作用于这款皮肤显示的那一路：只管音效的暂停音效、只管背景音乐的暂停背景音乐，两路都管的（不用这一排）照旧全部暂停
static int PauseIdFor(Ctx& c) { int r = SkinTraitsOf(c.s->skin).role; return r == ROLE_SFX ? H_STOGGLE : r == ROLE_BGM ? H_BTOGGLE : H_PAUSE; }
static float Spin(Ctx& c, bool playing, float degPerSec) { return (playing && c.anim) ? fmodf((float)(c.now % 3600000u) / 1000.f * degPerSec, 360.f) : 0.f; }

// 开关（灵动胶囊 / 毛玻璃）
static float Switch(Ctx& c, float x, float cy, float w, float h, bool on, unsigned onA, unsigned onB, unsigned offRgb, int offA, int id) {
  if (c.draw) {
    GraphicsPath p; RoundRectPath(p, x, cy - h / 2, w, h, h / 2);
    if (on) { LinearGradientBrush b(PointF(x, cy - h / 2), PointF(x + w, cy + h / 2), C(onA), C(onB)); c.g->FillPath(&b, &p); }
    else { SolidBrush b(C(offRgb, offA)); c.g->FillPath(&b, &p); }
    float kd = h - 4 * c.k, kx = on ? x + w - kd - 2 * c.k : x + 2 * c.k;
    SolidBrush sh(C(0, 70)); c.g->FillEllipse(&sh, kx, cy - kd / 2 + 1 * c.k, kd, kd);
    SolidBrush kn(on ? C(0xFFFFFF) : C(0xD2D2D8)); c.g->FillEllipse(&kn, kx, cy - kd / 2, kd, kd);
  }
  c.hit(id, x - 4 * c.k, cy - h / 2 - 4 * c.k, w + 8 * c.k, h + 8 * c.k);
  return w;
}
static void Bars(Ctx& c, float x, float cy, int n, float hmax, float bw, float gap, unsigned top, unsigned bot, bool playing, int level) {
  if (!c.draw) return;
  LinearGradientBrush b(PointF(0, cy - hmax / 2 - 1), PointF(0, cy + hmax / 2 + 1), C(top), C(bot));
  for (int i = 0; i < n; i++) {
    float hh = hmax * Wave(i, c.now, level, playing && c.anim);  // 系统关闭了动画：音浪画成静止的样子
    GraphicsPath p; RoundRectPath(p, x + i * (bw + gap), cy - hh / 2, bw, hh, bw / 2); c.g->FillPath(&b, &p);
  }
}

// =================================================================================================
// 灵动胶囊（SK_CAPSULE，默认）
static void CapsuleBg(Ctx& c, float w, float h, float r, int ring) {  // ring: 0 普通 1 闪避（琥珀描边） 2 提醒（琥珀描边＋外圈）
  if (!c.draw) return;
  GraphicsPath p; RoundRectPath(p, 0, 0, w, h, r);
  LinearGradientBrush bg(PointF(0, 0), PointF(0, h), C(0x1D1D22), C(0x0C0C0F));
  c.g->FillPath(&bg, &p);
  Color lc = ring == 2 ? C(0xFFB84D, 166) : ring == 1 ? C(0xFFC15A, 140) : C(0xFFFFFF, 20);
  StrokeRR(c, 0, 0, w, h, r, lc, 1 * c.k);
  if (ring == 2) StrokeRR(c, -2.5f * c.k, -2.5f * c.k, w + 5 * c.k, h + 5 * c.k, r + 2.5f * c.k, C(0xFFB84D, 38), 2.5f * c.k);
  Pen hl(C(0xFFFFFF, 18), 1 * c.k); c.g->DrawLine(&hl, r, 1.0f * c.k, w - r, 1.0f * c.k);
}
// 图层（定义在后面）：先画进整张画布大小的透明图层，再做光晕等效果后贴回
static void LayerBegin(Ctx& c, PixBuf& pb, Bitmap*& bmp, Graphics*& g, Graphics*& save);
static void LayerEnd(Ctx& c, Bitmap* bmp, Graphics* g, Graphics* save);
static void DrawPix(Ctx& c, PixBuf& pb, float alpha = 1.f);
static void StatusDot(Ctx& c, float x, float y, int kind) {  // 0 绿 1 灰 2 琥珀
  if (!c.draw) return;
  unsigned col = kind == 0 ? 0x34D27B : kind == 2 ? 0xFFB84D : 0x74747E;
  if (kind != 1) {  // 光晕在最底下（同设计稿 box-shadow: 0 0 8px，85% 不透明），上面再盖 2px 深色描边与圆点：远看是一个小亮点，不是一团绿
    PixBuf pb; Bitmap* bmp; Graphics* g; Graphics* save; LayerBegin(c, pb, bmp, g, save);
    SolidBrush s(C(0xFFFFFF)); c.g->FillEllipse(&s, x - 4.5f * c.k, y - 4.5f * c.k, 9 * c.k, 9 * c.k);
    LayerEnd(c, bmp, g, save);
    PixBuf gl; gl.init(pb.w, pb.h); GlowAdd(gl, pb, (int)roundf(4 * c.k), col, 0.85f); DrawPix(c, gl);
  }
  SolidBrush ring(C(0x121215)); c.g->FillEllipse(&ring, x - 6.5f * c.k, y - 6.5f * c.k, 13 * c.k, 13 * c.k);
  SolidBrush b(C(col)); c.g->FillEllipse(&b, x - 4.5f * c.k, y - 4.5f * c.k, 9 * c.k, 9 * c.k);
}
static float KeyCap(Ctx& c, float x, float cy, const std::wstring& key, int id) {
  bool un = key.empty();
  Font* f = un ? c.fonts->ui(11 * c.k, false) : c.fonts->num(11 * c.k, true);
  std::wstring t = un ? c.T(S_UNSET) : key;
  float w = TextW(c, t, f) + 12 * c.k, h = 20 * c.k;
  if (c.draw) {
    if (!un) { SolidBrush b(C(0xFFFFFF, 15)); FillRR(c, x, cy - h / 2, w, h, 6 * c.k, b); StrokeRR(c, x, cy - h / 2, w, h, 6 * c.k, C(0xFFFFFF, c.hoverId == id ? 90 : 41), 1 * c.k); }
    else StrokeRR(c, x, cy - h / 2, w, h, 6 * c.k, C(0xFFFFFF, c.hoverId == id ? 140 : 71), 1 * c.k, true);
    Text(c, t, f, C(WT, un ? 140 : 204), x, cy - h / 2, w, h, un ? 1 : 11, false);
  }
  c.hit(id, x, cy - h / 2, w, h);
  return w;
}
static void RoundBtn(Ctx& c, float cx, float cy, int kind, bool red, int id) {
  bool hv = c.hoverId == id;
  if (c.draw) {
    if (red) { SolidBrush h(C(0xFF453A, 41)); c.g->FillEllipse(&h, cx - 17 * c.k, cy - 17 * c.k, 34 * c.k, 34 * c.k); }
    SolidBrush b(red ? C(0xFF453A, hv ? 140 : 92) : C(0xFFFFFF, hv ? 46 : 23)); c.g->FillEllipse(&b, cx - 14 * c.k, cy - 14 * c.k, 28 * c.k, 28 * c.k);
    Color w = C(WT);
    if (kind == 0) IconPause(c, cx, cy, 14 * c.k, w); else if (kind == 1) IconStop(c, cx, cy, 14 * c.k, w); else if (kind == 2) IconOpen(c, cx, cy, 14 * c.k, w); else if (kind == 4) IconDuck(c, cx, cy, 14 * c.k, C(0xFFC15A)); else IconPlay(c, cx, cy, 14 * c.k, w);
  }
  c.hit(id, cx - 14 * c.k, cy - 14 * c.k, 28 * c.k, 28 * c.k);
}
static SizeF SkinCapsule(Ctx& c) {
  const XState& s = *c.s; float k = c.k;
  Font* f13 = c.fonts->ui(13 * k, false); Font* f11 = c.fonts->ui(11 * k, false); Font* f11b = c.fonts->ui(11 * k, true);
  Font* f10b = c.fonts->ui(10 * k, true); Font* f12b = c.fonts->ui(12 * k, true); Font* n11 = c.fonts->num(11 * k, true);
  Now pn = Primary(c);
  if (c.docked) {  // 贴边：一小截（贴上边时上边是平的）
    float h = 24 * k; std::wstring t = pn.t ? FmtMs(pn.v.remainMs, pn.isBgm, pn.isBgm) : L"";
    float tw = t.empty() ? 0 : TextW(c, t, n11) + 7 * k;
    float w = 8 * k + 16 * k + 7 * k + (pn.t ? 18 * k : 10 * k) + tw + 10 * k;
    if (c.draw) {
      GraphicsPath p; float r = 12 * k;
      if (c.dockEdge == 3) RoundRectPath4(p, 0, 0, w, h, 0, 0, r, r);
      else RoundRectPath(p, 0, 0, w, h, r);
      LinearGradientBrush bg(PointF(0, 0), PointF(0, h), C(0x1D1D22), C(0x0C0C0F)); c.g->FillPath(&bg, &p);
      Flower(c, 16 * k, h / 2, 15 * k, !s.armed);
      if (pn.t) Bars(c, 31 * k, h / 2, 5, 12 * k, 2 * k, 2 * k, pn.isBgm ? 0x9FB0FF : 0xFFB547, pn.isBgm ? 0xB57BFF : 0xFF4F6E, !pn.v.paused, pn.t->level);
      else StatusDot(c, 31 * k + 4 * k, h / 2, s.armed ? (NumWarn(c) ? 2 : 0) : 1);
      if (!t.empty()) Text(c, t, n11, C(WT, 217), 31 * k + 25 * k, 0, tw + 4 * k, h, 10, false);
    }
    return SizeF(w, h);
  }
  if (pn.t) {  // 播放中：展开
    float h = 46 * k, x = 7 * k, cy = h / 2;
    std::wstring nm = pn.t->name.empty() ? c.T(pn.isBgm ? S_BGM : S_SFX) : pn.t->name;
    Font* fn = c.fonts->name(nm, 13 * k, true);
    float nw = TextW(c, nm, fn); if (nw > 150 * k) nw = 150 * k;
    std::wstring tag = c.T(pn.isBgm ? S_BGM : S_SFX);
    std::wstring t2 = pn.v.paused ? c.T(S_PAUSED) : pn.isBgm ? FmtMs(pn.v.remainMs, true, true) : Fmt1(c.T(S_LEFT), FmtMs(pn.v.remainMs, false, false));
    Font* ft2 = (pn.isBgm && !pn.v.paused) ? n11 : f11;
    float tagw = TextW(c, tag, f10b) + 10 * k, t2w = TextW(c, t2, ft2);
    { float a = TextW(c, c.T(S_PAUSED), f11), b = TextW(c, pn.isBgm ? FmtMs(pn.v.remainMs, true, true) : Fmt1(c.T(S_LEFT), FmtMs(pn.v.remainMs, false, false)), pn.isBgm ? n11 : f11); t2w = a > b ? a : b; }  // 1.5.0：“剩余时间 / 已暂停”这一格按两者里宽的定宽，暂停、继续前后胶囊不变宽变窄、悬停那一排按钮不挪（见 TmSlotW）
    float col = nw > tagw + 6 * k + t2w ? nw : tagw + 6 * k + t2w;
    bool duckIsB = false; int duck = DuckOf(c, &duckIsB);
    std::wstring dt = c.T(duck == 2 ? S_VDUCK : S_DUCK);
    float dw = TextW(c, dt, f11b) + 28 * k;
    float tail = c.hover ? (1 * k + 10 * k + 38 * k * 3 + 34 * k) : duck ? dw : (9 * 3 * k + 8 * 2.5f * k);
    float w = x + 32 * k + 10 * k + col + 10 * k + tail + 12 * k;
    CapsuleBg(c, w, h, 23 * k, duck && !c.hover ? 1 : 0);
    float lx = x + 16 * k;
    if (c.draw) {
      if (!pn.isBgm) { Ring(c, lx, cy, 32 * k, 2.6f * k, pn.v.p, C(0xFFFFFF, 36), C(0xFF4F6E), C(0xFFA142)); Flower(c, lx, cy, 18 * k, !s.armed); }
      else Vinyl(c, lx, cy, 30 * k, C(0x8E7CFF), Spin(c, !pn.v.paused, 200.f));
      StatusDot(c, lx + 12 * k, cy + 12 * k, s.armed ? (NumWarn(c) ? 2 : 0) : 1);
    }
    if (NumWarn(c)) c.hit(H_NUMFIX, lx + 4 * k, cy + 4 * k, 16 * k, 16 * k);
    float tx = x + 42 * k;
    if (c.draw) {
      Text(c, nm, fn, C(0xFFFFFF), tx, cy - 18 * k, col, 17 * k, 0, true);
      SolidBrush tb(pn.isBgm ? C(0x8E7CFF, 51) : C(0xFF785A, 43)); FillRR(c, tx, cy + 3 * k, tagw, 15 * k, 5 * k, tb);
      Text(c, tag, f10b, pn.isBgm ? C(0xB9AEFF) : C(0xFFB08A), tx, cy + 3 * k, tagw, 15 * k, 1, false);
      Text(c, t2, ft2, C(WT, pn.isBgm ? 224 : 148), tx + tagw + 6 * k, cy + 2 * k, t2w + 4 * k, 17 * k, pn.isBgm ? 10 : 0, false);
    }
    float rx = tx + col + 10 * k;
    if (c.hover) {
      if (c.draw) { Pen sp(C(0xFFFFFF, 31), 1 * k); c.g->DrawLine(&sp, rx, cy - 9 * k, rx, cy + 9 * k); }
      rx += 10 * k;
      bool anyPlaying = (ViewOf(s.sfx, c.now).on && !ViewOf(s.sfx, c.now).paused) || (ViewOf(s.bgm, c.now).on && !ViewOf(s.bgm, c.now).paused);
      RoundBtn(c, rx + 14 * k, cy, anyPlaying ? 0 : 3, false, PauseIdFor(c)); rx += 38 * k;
      RoundBtn(c, rx + 14 * k, cy, 1, true, H_STOP); rx += 38 * k;
      if (duck) RoundBtn(c, rx + 14 * k, cy, 4, false, duckIsB ? H_DUCK_B : H_DUCK_S);  // 闪避中：主面板换成“取消闪避”（悬停时闪避的胶囊按钮让位给这一排，不能点不到；主面板双击、右键菜单都能打开）
      else RoundBtn(c, rx + 14 * k, cy, 2, false, H_OPEN);
      rx += 38 * k;
      Switch(c, rx, cy, 34 * k, 20 * k, s.armed, 0x30C463, 0x30C463, 0x3B3B43, 255, H_SWITCH);
    } else if (duck) {
      if (c.draw) {
        SolidBrush cb(C(0xFFC15A, 38)); FillRR(c, rx, cy - 11 * k, dw, 22 * k, 11 * k, cb);
        IconDuck(c, rx + 13 * k, cy, 12 * k, C(0xFFC15A));
        Text(c, dt, f11b, C(0xFFC15A), rx + 21 * k, cy - 11 * k, dw - 21 * k, 22 * k, 0, false);
      }
      c.hit(duckIsB ? H_DUCK_B : H_DUCK_S, rx, cy - 11 * k, dw, 22 * k);
    } else {
      Bars(c, rx, cy, 9, 22 * k, 3 * k, 2.5f * k, pn.isBgm ? 0x9FB0FF : 0xFFB547, pn.isBgm ? 0xB57BFF : 0xFF4F6E, !pn.v.paused, pn.t->level);
    }
    return SizeF(w, h);
  }
  float h = 36 * k, cy = h / 2;
  if (NumWarn(c)) {  // 小键盘没开：琥珀色提醒，点“点此打开”
    std::wstring t1 = c.T(S_NUMLOCK), t2 = c.T(S_NUMFIX);
    float w1 = TextW(c, t1, f13), w2 = TextW(c, t2, f12b);
    float w = 8 * k + 24 * k + 9 * k + w1 + 9 * k + w2 + 9 * k + 1 * k + 9 * k + 34 * k + 6 * k;
    CapsuleBg(c, w, h, 18 * k, 2);
    float x = 8 * k;
    if (c.draw) {
      SolidBrush wb(C(0xFFB84D, 41)); c.g->FillEllipse(&wb, x, cy - 12 * k, 24 * k, 24 * k);
      IconKeypad(c, x + 12 * k, cy, 13 * k, C(0xFFB84D));
    }
    c.hit(H_NUMFIX, x, cy - 12 * k, 24 * k, 24 * k);
    x += 33 * k;
    if (c.draw) Text(c, t1, f13, C(WT), x, 0, w1 + 2 * k, h, 0, false);
    x += w1 + 9 * k;
    if (c.draw) Text(c, t2, f12b, c.hoverId == H_NUMFIX ? C(0xFFD27A) : C(0xFFB84D), x, 0, w2 + 2 * k, h, 0, false);
    c.hit(H_NUMFIX, x - 3 * k, cy - 11 * k, w2 + 6 * k, 22 * k);
    x += w2 + 9 * k;
    if (c.draw) { Pen sp(C(0xFFFFFF, 31), 1 * k); c.g->DrawLine(&sp, x, cy - 9 * k, x, cy + 9 * k); }
    x += 10 * k;
    Switch(c, x, cy, 34 * k, 20 * k, s.armed, 0x30C463, 0x30C463, 0x3B3B43, 255, H_SWITCH);
    return SizeF(w, h);
  }
  std::wstring t1 = c.T(s.armed ? S_HKON : S_HKOFF);
  float w1 = TextW(c, t1, f13);
  Font* kf = s.key.empty() ? f11 : n11;
  float kw = TextW(c, s.key.empty() ? c.T(S_UNSET) : s.key, kf) + 12 * k;
  float w = 8 * k + 24 * k + 9 * k + w1 + 9 * k + kw + 9 * k + 34 * k + 6 * k;
  CapsuleBg(c, w, h, 18 * k, 0);
  float x = 8 * k;
  if (c.draw) { Flower(c, x + 12 * k, cy, 22 * k, !s.armed); StatusDot(c, x + 21 * k, cy + 9 * k, s.armed ? 0 : 1); }
  c.hit(H_SWITCH, x, cy - 12 * k, 24 * k, 24 * k);
  x += 33 * k;
  if (c.draw) Text(c, t1, f13, C(WT, s.armed ? 255 : 153), x, 0, w1 + 2 * k, h, 0, false);
  x += w1 + 9 * k;
  x += KeyCap(c, x, cy, s.key, H_KEY) + 9 * k;
  Switch(c, x, cy, 34 * k, 20 * k, s.armed, 0x30C463, 0x30C463, 0x3B3B43, 255, H_SWITCH);
  return SizeF(w, h);
}

// =================================================================================================
// 全能控台（SK_CONSOLE，原名“团播控台”）
// 对比度（逐段文字检查后调整，WCAG 正文 4.5）：组件卡次要灰字 #6B7088→#575C78、急停红 #E03131→#B71C1C；贴纸次要字 #A27C78→#8A625E；控台急停字 #FF7180→#FF7A88
static void DeckBtn(Ctx& c, float x, float y, float w, float h, int kind, const std::wstring& label, int id, bool on) {
  bool hv = c.hoverId == id; float k = c.k;
  if (c.draw) {
    unsigned fg; Color bg, ln;
    if (kind == 0) {  // 闪避
      if (on) { bg = C(0xFFBA49, 43); ln = C(0xFFBA49, 166); fg = 0xFFC15A; }
      else { bg = C(0xFFFFFF, hv ? 26 : 13); ln = C(0xFFFFFF, 20); fg = 0xCFC7DC; }
    } else { bg = C(0xFF4D5E, hv ? 87 : 33); ln = C(0xFF4D5E, hv ? 217 : 102); fg = hv ? 0xFFFFFF : 0xFF7A88; }
    SolidBrush b(bg); FillRR(c, x, y, w, h, 12 * k, b); StrokeRR(c, x, y, w, h, 12 * k, ln, 1 * k);
    if (kind == 0) IconDuck(c, x + w / 2, y + 19 * k, 18 * k, C(fg)); else IconStop(c, x + w / 2, y + 19 * k, 18 * k, C(fg));
    Text(c, label, c.fonts->ui(11 * k, true), C(fg), x, y + 32 * k, w, 16 * k, 1, true);
  }
  c.hit(id, x, y, w, h);
}
static SizeF SkinConsole(Ctx& c) {
  const XState& s = *c.s; float k = c.k;
  TrackView sv = ViewOf(s.sfx, c.now), bv = ViewOf(s.bgm, c.now);
  Font* n21 = c.fonts->num(21 * k, true); Font* n15 = c.fonts->num(15 * k, true);
  bool ending = bv.on && !bv.paused && bv.remainMs <= 10000 && bv.totalMs > 15000;
  if (c.docked) {
    float h = 32 * k;
    std::wstring t = bv.on ? FmtMs(bv.remainMs, true, true) : sv.on ? FmtMs(sv.remainMs, false, false) : L"";
    float tw = t.empty() ? 0 : TextW(c, t, n15) + 9 * k;
    float pw = (bv.on || sv.on) ? 56 * k : 0;
    float w = 7 * k + 22 * k + 9 * k + tw + pw + 12 * k;
    if (c.draw) {
      LinearGradientBrush bg(PointF(0, 0), PointF(w, h), C(0x251B37), C(0x100C15)); FillRR(c, 0, 0, w, h, 16 * k, bg);
      StrokeRR(c, 0, 0, w, h, 16 * k, C(0xFFFFFF, 18), 1 * k);
      Pen rp(s.armed ? C(0xFF5470) : C(0x3B3546), 2 * k); c.g->DrawEllipse(&rp, 7 * k, h / 2 - 11 * k, 22 * k, 22 * k);
      Flower(c, 18 * k, h / 2, 14 * k, !s.armed);
      if (!t.empty()) Text(c, t, n15, ending ? C(0xFF4D5E) : C(0xFFFFFF), 38 * k, 0, tw, h, 10, false);
      if (pw > 0) {
        float px = 38 * k + tw, p = bv.on ? bv.p : sv.p;
        SolidBrush tr(C(0xFFFFFF, 26)); FillRR(c, px, h / 2 - 2 * k, 56 * k - 6 * k, 4 * k, 2 * k, tr);
        LinearGradientBrush pg(PointF(px, 0), PointF(px + 50 * k, 0), C(0xFF4F6E), C(0xFFA142)); if (p > 0) FillRR(c, px, h / 2 - 2 * k, (50 * k) * p, 4 * k, 2 * k, pg);
      }
    }
    c.hit(H_SWITCH, 7 * k, h / 2 - 11 * k, 22 * k, 22 * k);
    return SizeF(w, h);
  }
  float H = 76 * k;
  // 右侧两个按钮的宽度按文字定（最少 50）
  bool duckIsB = false; int duck = DuckOf(c, &duckIsB);
  std::wstring dl = duck ? c.T(duck == 2 ? S_VDUCK : S_DUCK) : c.T(S_DUCKBTN), sl = c.T(S_STOP);
  Font* fb11 = c.fonts->ui(11 * k, true);
  float dbw = TextW(c, dl, fb11) + 12 * k; if (dbw < 50 * k) dbw = 50 * k; if (dbw > 84 * k) dbw = 84 * k;
  float sbw = TextW(c, sl, fb11) + 12 * k; if (sbw < 50 * k) sbw = 50 * k; if (sbw > 84 * k) sbw = 84 * k;
  float msw = 84 * k, midw = 206 * k, acw = 8 * k + dbw + 6 * k + sbw + 10 * k;
  float W = msw + midw + acw;
  bool drawer = NumWarn(c) || s.key.empty();
  float totalH = H + (drawer ? 24 * k : 0);
  if (c.draw) {
    if (drawer) {  // 抽屉在控台下方露出 24
      float dx = 12 * k, dy = H - 12 * k, dw = W - 24 * k, dh = 36 * k;
      GraphicsPath p; RoundRectPath4(p, dx, dy, dw, dh, 0, 0, 12 * k, 12 * k);
      bool warn = NumWarn(c);
      LinearGradientBrush b(PointF(0, dy), PointF(0, dy + dh), warn ? C(0x3B2A10) : C(0x2A2238), warn ? C(0x2E200B) : C(0x211B2D)); c.g->FillPath(&b, &p);
      Pen ln(warn ? C(0xFFC15A, 97) : C(0xC9BFDA, 71), 1 * k); c.g->DrawPath(&ln, &p);
    }
    GraphicsPath p; RoundRectPath(p, 0, 0, W, H, 16 * k);
    LinearGradientBrush bg(PointF(0, 0), PointF(W, H), C(0x251B37), C(0x100C15));
    Color cs[3] = {C(0x251B37), C(0x151019), C(0x100C15)}; REAL ps[3] = {0, .58f, 1}; bg.SetInterpolationColors(cs, ps, 3);
    c.g->FillPath(&bg, &p);
    StrokeRR(c, 0, 0, W, H, 16 * k, C(0xFFFFFF, 18), 1 * k);
    Pen sep(C(0xFFFFFF, 18), 1 * k);
    c.g->DrawLine(&sep, msw, 0.f, msw, H); c.g->DrawLine(&sep, msw + midw, 0.f, msw + midw, H);
  }
  if (drawer) {
    bool warn = NumWarn(c);
    float dy = H, dh = 24 * k;
    if (c.draw) {
      Color fg = warn ? C(0xFFC15A) : C(0xC9BFDA);
      if (warn) IconKeypad(c, 30 * k, dy + dh / 2, 12 * k, fg); else IconPower(c, 30 * k, dy + dh / 2, 12 * k, fg);
      Font* f = c.fonts->ui(11 * k, false); Font* fbb = c.fonts->ui(11 * k, true);
      std::wstring a = c.T(warn ? S_NUMLOCK : S_UNSET), b2 = c.T(warn ? S_NUMFIX : S_SETNOW);
      float bw2 = TextW(c, b2, fbb);
      Text(c, a, f, fg, 42 * k, dy, W - 84 * k - bw2, dh, 0, true);
      Text(c, b2, fbb, warn ? C(0xFFD27A) : C(0xFF9AAA), W - 24 * k - bw2 - 8 * k, dy, bw2 + 4 * k, dh, 0, false);
    }
    c.hit(warn ? H_NUMFIX : H_KEY, 12 * k, H, W - 24 * k, 24 * k);
  }
  // 总开关
  float cx = msw / 2, rcy = 30 * k;
  if (c.draw) {
    GraphicsPath cp; cp.AddEllipse(cx - 22 * k, rcy - 22 * k, 44 * k, 44 * k);
    PathGradientBrush rb(&cp); rb.SetCenterPoint(PointF(cx, rcy - 8 * k)); rb.SetCenterColor(s.armed ? C(0x3B2542) : C(0x2B2731));
    Color sc = s.armed ? C(0x1C1322) : C(0x18151C); INT n = 1; rb.SetSurroundColors(&sc, &n); c.g->FillPath(&rb, &cp);
    if (s.armed) {  // 环的光晕：同设计稿 drop-shadow(0 0 6px rgba(255,84,112,.75))——环本身模糊后的柔光，不是几圈粗线
      PixBuf pb; Bitmap* bmp; Graphics* g; Graphics* save; LayerBegin(c, pb, bmp, g, save);
      Pen rp(C(0xFFFFFF), 3 * k); c.g->DrawEllipse(&rp, cx - 20.5f * k, rcy - 20.5f * k, 41 * k, 41 * k);
      LayerEnd(c, bmp, g, save);
      PixBuf gl; gl.init(pb.w, pb.h); GlowAdd(gl, pb, (int)roundf(3 * k), 0xFF5470, 0.75f * 1.6f); DrawPix(c, gl);
    }
    Ring(c, cx, rcy, 44 * k, 3 * k, 1, C(0, 0), s.armed ? C(0xFF4F6E) : C(0x3B3546), s.armed ? C(0xFFA142) : C(0x3B3546), true);
    Flower(c, cx, rcy, 22 * k, !s.armed);
    Text(c, c.T(s.armed ? S_ON : S_OFF), c.fonts->ui(11 * k, true), s.armed ? C(0xFF7D92) : C(0x8D8698), 0, rcy + 26 * k, msw, 14 * k, 1, true);
  }
  c.hit(H_SWITCH, cx - 24 * k, rcy - 24 * k, 48 * k, 48 * k);
  {  // 切换键角标
    bool un = s.key.empty(); Font* kf = c.fonts->num(9 * k, true);
    std::wstring kt = un ? L"+" : s.key;
    float kw = un ? 15 * k : TextW(c, kt, kf) + 8 * k; if (kw > 44 * k) kw = 44 * k;  // 没设切换键：画一个加号（画线；小字号的“+”字形在有的字体里只剩一个点）
    float kx = cx + 22 * k - kw + 11 * k, ky = rcy + 22 * k - 13 * k;
    if (c.draw) {
      SolidBrush kb(un ? C(0x1C1722) : C(0x2E2539)); FillRR(c, kx, ky, kw, 15 * k, 5 * k, kb);
      StrokeRR(c, kx, ky, kw, 15 * k, 5 * k, un ? C(0xFFFFFF, 90) : C(0xFFFFFF, c.hoverId == H_KEY ? 120 : 56), 1 * k, un);
      if (un) IconPlus(c, kx + kw / 2, ky + 7.5f * k, 7 * k, C(0xA79FB4), 1.4f * k);
      else Text(c, kt, kf, C(0xE6DEF2), kx, ky, kw, 15 * k, 11, true);
    }
    c.hit(H_KEY, kx - 2 * k, ky - 2 * k, kw + 4 * k, 19 * k);
  }
  // 中间：舞曲＋倒计时
  float mx = msw + 14 * k, mw = midw - 28 * k;
  Font* f11 = c.fonts->ui(11 * k, false);
  if (bv.on) {
    std::wstring nm = s.bgm.name.empty() ? c.T(S_BGM) : s.bgm.name;
    Font* fn = c.fonts->name(nm, 13 * k, true);
    std::wstring et = c.T(S_ENDING); Font* fe = c.fonts->ui(10 * k, true);
    float ew = ending ? TextW(c, et, fe) + 12 * k : 16 * k;
    if (c.draw) {
      IconNote(c, mx + 6.5f * k, 19 * k, 13 * k, C(0xFF8FA2));
      Text(c, nm, fn, C(0xF4F1FA), mx + 19 * k, 10 * k, mw - 19 * k - ew - 6 * k, 18 * k, 0, true);
      if (ending) { SolidBrush eb(C(0xD92D45));  /* 原 #FF4D5E 上白字只有 3.2 */ FillRR(c, mx + mw - ew, 11 * k, ew, 16 * k, 6 * k, eb); Text(c, et, fe, C(0xFFFFFF), mx + mw - ew, 11 * k, ew, 16 * k, 1, false); }
      else if (s.loop || s.order == 2) IconLoop(c, mx + mw - 7 * k, 19 * k, 12 * k, C(0x8D8698));
      SolidBrush tr(C(0xFFFFFF, 26)); FillRR(c, mx, 34 * k, mw, 4 * k, 2 * k, tr);
      if (bv.p > 0) { LinearGradientBrush pg(PointF(mx, 0), PointF(mx + mw, 0), C(0xFF4F6E), ending ? C(0xFF2D3D) : C(0xFFA142)); FillRR(c, mx, 34 * k, mw * bv.p, 4 * k, 2 * k, pg); }
      std::wstring cd = FmtMs(bv.remainMs, true, true);
      Text(c, cd, n21, ending ? C(0xFF4D5E) : C(0xFFFFFF), mx, 44 * k, mw, 24 * k, 12, false);
    }
    float cdw = TextW(c, FmtMs(bv.remainMs, true, true), n21);
    if (c.hover) {  // 悬停：上一首 / 播放暂停 / 下一首
      float bx = mx, by = 49 * k;
      int ids[3] = {H_BPREV, H_BTOGGLE, H_BNEXT};
      for (int i = 0; i < 3; i++) {
        bool hv = c.hoverId == ids[i];
        if (c.draw) {
          SolidBrush b(C(0xFFFFFF, hv ? 46 : 26)); FillRR(c, bx, by, 26 * k, 20 * k, 6 * k, b);
          Color ic = C(0xF4F1FA);
          if (i == 0) IconPrev(c, bx + 13 * k, by + 10 * k, 12 * k, ic); else if (i == 2) IconNext(c, bx + 13 * k, by + 10 * k, 12 * k, ic);
          else if (bv.paused) IconPlay(c, bx + 13 * k, by + 10 * k, 12 * k, ic); else IconPause(c, bx + 13 * k, by + 10 * k, 12 * k, ic);
        }
        c.hit(ids[i], bx, by, 26 * k, 20 * k);
        bx += 32 * k;
      }
    } else if (c.draw) {
      if (sv.on) {
        std::wstring sx = (s.sfx.name.empty() ? c.T(S_SFX) : s.sfx.name);
        Font* fs = c.fonts->name(sx, 11 * k, true);
        IconNote(c, mx + 5.5f * k, 60 * k, 11 * k, C(0xFFB08A));
        std::wstring rt = L" " + FmtMs(sv.remainMs, false, false);
        float rtw = TextW(c, rt, c.fonts->num(11 * k, true));
        float avail = mw - cdw - 8 * k - 15 * k - rtw;
        Text(c, sx, fs, C(0xFFB08A), mx + 15 * k, 52 * k, avail, 16 * k, 0, true);
        float used = TextW(c, sx, fs); if (used > avail) used = avail;
        Text(c, rt, c.fonts->num(11 * k, true), C(0xFFB08A), mx + 15 * k + used, 52 * k, rtw + 2 * k, 16 * k, 10, false);
      } else {
        std::wstring el = FmtMs(bv.elapsedMs, false, true); el += L" / " + FmtMs(bv.totalMs, false, true);
        Text(c, el, c.fonts->num(11 * k, false), C(0x8D8698), mx, 52 * k, mw - cdw - 8 * k, 16 * k, 10, false);
      }
    }
  } else {
    if (c.draw) {
      IconNote(c, mx + 6.5f * k, 19 * k, 13 * k, C(0x8D8698));
      Text(c, c.T(S_IDLEBGM), c.fonts->ui(13 * k, false), C(0x8D8698), mx + 19 * k, 10 * k, mw - 19 * k, 18 * k, 0, true);
      SolidBrush tr(C(0xFFFFFF, 26)); FillRR(c, mx, 34 * k, mw, 4 * k, 2 * k, tr);
      if (sv.on && sv.p > 0) { LinearGradientBrush pg(PointF(mx, 0), PointF(mx + mw, 0), C(0xFFB547), C(0xFF4F6E)); FillRR(c, mx, 34 * k, mw * sv.p, 4 * k, 2 * k, pg); }
      std::wstring cd = sv.on ? FmtMs(sv.remainMs, false, false) : L"00:00";
      if (!sv.on) c.logKind = 'D';  // 没在放音效时的 00:00 是有意暗淡的占位（不承载信息，旁边写着“暂无音效播放”）
      Text(c, cd, n21, sv.on ? C(0xFFFFFF) : C(0x5E5868), mx, 44 * k, mw, 24 * k, 12, false);
      c.logKind = 0;
      float cdw = TextW(c, cd, n21);
      if (sv.on) {
        std::wstring sx = s.sfx.name.empty() ? c.T(S_SFX) : s.sfx.name;
        IconNote(c, mx + 5.5f * k, 60 * k, 11 * k, C(0xFFB08A));
        Text(c, sx, c.fonts->name(sx, 11 * k, true), C(0xFFB08A), mx + 15 * k, 52 * k, mw - cdw - 23 * k, 16 * k, 0, true);
      } else Text(c, c.T(S_IDLESFX), f11, C(0x8D8698), mx, 52 * k, mw - cdw - 8 * k, 16 * k, 0, true);
    }
  }
  // 右侧：闪避、急停
  float ax = msw + midw + 8 * k, ay = 10 * k;
  DeckBtn(c, ax, ay, dbw, 56 * k, 0, dl, duck ? (duckIsB ? H_DUCK_B : H_DUCK_S) : H_DUCK_START, duck != 0);
  DeckBtn(c, ax + dbw + 6 * k, ay, sbw, 56 * k, 1, sl, H_STOP, false);
  return SizeF(W, totalH);
}

// =================================================================================================
// ON AIR 霓虹灯牌（SK_NEON）
static void NeonFlowerPath(GraphicsPath& pet, GraphicsPath& core, float cx, float cy, float s) {
  float u = s / 44.f;
  for (int i = 0; i < 5; i++) {
    GraphicsPath e; e.AddEllipse(cx - 5.6f * u, cy - (22 - 12.6f + 8.2f) * u, 11.2f * u, 16.4f * u);
    Matrix m; m.RotateAt(72.f * i, PointF(cx, cy)); e.Transform(&m);
    pet.AddPath(&e, FALSE);
  }
  core.AddEllipse(cx - 5 * u, cy - 5 * u, 10 * u, 10 * u);
}
static void LayerBegin(Ctx& c, PixBuf& pb, Bitmap*& bmp, Graphics*& g, Graphics*& save) {
  Matrix m; c.g->GetTransform(&m); REAL e[6]; m.GetElements(e);
  pb.init((int)ceilf(c.W + 2), (int)ceilf(c.H + 2));
  bmp = new Bitmap(pb.w, pb.h, pb.w * 4, PixelFormat32bppPARGB, (BYTE*)pb.px.data());
  g = new Graphics(bmp);
  g->SetSmoothingMode(SmoothingModeAntiAlias); g->SetTextRenderingHint(TextRenderingHintAntiAliasGridFit); g->SetPixelOffsetMode(PixelOffsetModeHalf);
  // 图层与画布同一套坐标（含 RTL 镜像），只去掉边距平移
  Matrix lm(e[0], e[1], e[2], e[3], e[0] < 0 ? c.W : 0.f, 0.f); g->SetTransform(&lm);
  save = c.g; c.g = g;
  c.logDx += e[4] - (e[0] < 0 ? c.W : 0.f); c.logDy += e[5];  // 测试：图层坐标 → 画布坐标（与 DrawPix 贴回时的平移相同）
}
static void LayerEnd(Ctx& c, Bitmap* bmp, Graphics* g, Graphics* save) {
  c.g = save; delete g; delete bmp;
  Matrix m; c.g->GetTransform(&m); REAL e[6]; m.GetElements(e);
  c.logDx -= e[4] - (e[0] < 0 ? c.W : 0.f); c.logDy -= e[5];
}
static void DrawPix(Ctx& c, PixBuf& pb, float alpha) {  // 图层贴回画布（图层坐标已含镜像）
  Bitmap bmp(pb.w, pb.h, pb.w * 4, PixelFormat32bppPARGB, (BYTE*)pb.px.data());
  Matrix m; c.g->GetTransform(&m); REAL e[6]; m.GetElements(e);
  GraphicsState st = c.g->Save();
  Matrix t(1, 0, 0, 1, e[4] + (e[0] < 0 ? -c.W : 0.f), e[5]); c.g->SetTransform(&t);
  if (alpha < 1.f) {
    ColorMatrix cm = {{{1, 0, 0, 0, 0}, {0, 1, 0, 0, 0}, {0, 0, 1, 0, 0}, {0, 0, 0, alpha, 0}, {0, 0, 0, 0, 1}}};
    ImageAttributes ia; ia.SetColorMatrix(&cm);
    c.g->DrawImage(&bmp, RectF(0, 0, (REAL)pb.w, (REAL)pb.h), 0, 0, (REAL)pb.w, (REAL)pb.h, UnitPixel, &ia);
  } else c.g->DrawImage(&bmp, 0, 0, pb.w, pb.h);
  c.g->Restore(st);
}
static void LedText(Ctx& c, float x, float y, float w, float h, const std::wstring& left, const std::wstring& right, unsigned col, int meterP, bool glow, bool dim) {
  // 点阵屏：先把文字画进图层，再按 2 个设计像素一格打成点、加一点光晕
  if (!c.draw) return;
  PixBuf pb; Bitmap* bmp; Graphics* g; Graphics* save;
  LayerBegin(c, pb, bmp, g, save);
  Font* fn = c.fonts->num(12 * c.k, true);
  bool ascii = true; for (wchar_t ch : right) if (ch > 0x7E) { ascii = false; break; }
  Font* rf = ascii ? fn : c.fonts->name(right, 12 * c.k, true);
  float rw = right.empty() ? 0 : TextW(c, right, rf) + 2 * c.k;
  float mw = meterP >= 0 ? 8 * 6 * c.k : 0;
  c.logKind = 'L';  // 测试：点阵字（150% 起按格打点，实际看起来比字的颜色暗，对比度按打点后的平均亮度算）
  Text(c, left, c.fonts->name(left, 12 * c.k, true), C(col), x, y, w - rw - mw - (mw > 0 ? 6 * c.k : 0) - (rw > 0 ? 6 * c.k : 0), h, 0, true);
  if (meterP >= 0) {
    float mx = x + w - rw - (rw > 0 ? 6 * c.k : 0) - mw;
    for (int i = 0; i < 8; i++) { SolidBrush b(C(col, i < meterP ? 255 : 51)); c.g->FillRectangle(&b, mx + i * 6 * c.k, y + h / 2 - 4.5f * c.k, 4 * c.k, 9 * c.k); }
  }
  if (!right.empty()) Text(c, right, rf, C(col), x + w - rw, y, rw, h, ascii ? 10 : 0, false);
  c.logKind = 0;
  LayerEnd(c, bmp, g, save);
  // 打点：一格 2 个设计像素。格子不到 4 个屏幕像素（100%～150%）时点太细、只会让字整体发暗，不打；
  // 4 个像素起每格留 1 像素的暗缝（原来是半格亮点：150% 时只有 1/9 亮、200% 时 1/4 亮，字按平均亮度算对比度只剩 2～4）；
  // 熄灭时的暗字也不打点（本来就暗，再打点就看不清了）
  int cell = (int)roundf(2 * c.k); if (cell < 2) cell = 2;
  if (!g_testNoDots && cell >= 4 && !dim) for (int yy = 0; yy < pb.h; yy++) for (int xx = 0; xx < pb.w; xx++) {
    unsigned& p = pb.px[(size_t)yy * pb.w + xx];
    if (!(p >> 24)) continue;
    bool dot = (xx % cell) < cell - 1 && (yy % cell) < cell - 1;
    if (!dot) { unsigned a = (p >> 24) * 115 / 255, r = ((p >> 16) & 255) * 115 / 255, gg = ((p >> 8) & 255) * 115 / 255, b = (p & 255) * 115 / 255; p = (a << 24) | (r << 16) | (gg << 8) | b; }
  }
  if (glow && !dim) { PixBuf gl = pb; GlowAdd(gl, pb, (int)roundf(2.5f * c.k), col, 0.9f); pb = gl; }
  DrawPix(c, pb);
}
static SizeF SkinNeon(Ctx& c) {
  const XState& s = *c.s; float k = c.k; bool lit = s.armed;
  if (c.docked) {
    float w = 60 * k, h = 60 * k;
    if (c.draw) {
      GraphicsPath p; RoundRectPath(p, 0, 0, w, h, 14 * k);
      LinearGradientBrush bg(PointF(0, 0), PointF(w * .4f, h), C(0x2E1434), C(0x0B060E)); c.g->FillPath(&bg, &p);
      StrokeRR(c, 0, 0, w, h, 14 * k, C(0xFFFFFF, 20), 1 * k);
      GraphicsPath pet, core; NeonFlowerPath(pet, core, w / 2, h / 2, 44 * k);
      if (lit) {
        PixBuf pb; Bitmap* bmp; Graphics* g; Graphics* save; LayerBegin(c, pb, bmp, g, save);
        Pen pp(C(0xFF4FA0), 2.6f * k); c.g->DrawPath(&pp, &pet); Pen cpn(C(0xFFB43D), 2.4f * k); c.g->DrawPath(&cpn, &core);
        LayerEnd(c, bmp, g, save); PixBuf gl = pb; GlowAdd(gl, pb, (int)roundf(6 * k), 0xFF2E88, 1.1f); DrawPix(c, gl);
      }
      Pen pp2(lit ? C(0xFF4FA0) : C(0xFF78B4, 61), 2.6f * k); c.g->DrawPath(&pp2, &pet);
      Pen pi2(lit ? C(0xFFE3F0, 230) : C(0xFFFFFF, 26), .9f * k); c.g->DrawPath(&pi2, &pet);
      Pen cp2(lit ? C(0xFFB43D) : C(0xFFBE5A, 56), 2.4f * k); c.g->DrawPath(&cp2, &core);
    }
    c.hit(H_SWITCH, 0, 0, w, h);
    return SizeF(w, h);
  }
  float W = 252 * k, H = 80 * k;
  if (c.draw) {
    GraphicsPath p; RoundRectPath(p, 0, 0, W, H, 14 * k);
    LinearGradientBrush bg(PointF(0, 0), PointF(W * .35f, H), C(0x2E1434), C(0x0B060E));
    Color cs[3] = {C(0x2E1434), C(0x140A19), C(0x0B060E)}; REAL ps[3] = {0, .55f, 1}; bg.SetInterpolationColors(cs, ps, 3);
    c.g->FillPath(&bg, &p);
    if (lit) {  // 灯管照亮的粉色环境光
      GraphicsPath gp; gp.AddEllipse(-20 * k, -40 * k, 200 * k, 130 * k);
      PathGradientBrush gb(&gp); gb.SetCenterColor(C(0xFF2E88, 56)); Color sc = C(0xFF2E88, 0); INT n = 1; gb.SetSurroundColors(&sc, &n);
      Region rg(&p); c.g->SetClip(&rg); c.g->FillPath(&gb, &gp); c.g->ResetClip();
    }
    StrokeRR(c, 0, 0, W, H, 14 * k, C(0xFFFFFF, 20), 1 * k);
    Pen hl(C(0xFFFFFF, 30), 1 * k); c.g->DrawLine(&hl, 14 * k, 1 * k, W - 14 * k, 1 * k);
    float sxs[4][2] = {{7, 7}, {252 - 13, 7}, {7, 80 - 13}, {252 - 13, 80 - 13}};
    for (auto& sxy : sxs) {
      GraphicsPath sp; sp.AddEllipse(sxy[0] * k, sxy[1] * k, 6 * k, 6 * k);
      PathGradientBrush sb(&sp); sb.SetCenterPoint(PointF((sxy[0] + 2) * k, (sxy[1] + 2) * k)); sb.SetCenterColor(C(0xFFFFFF)); Color sc = C(0x4C4C55); INT n = 1; sb.SetSurroundColors(&sc, &n);
      c.g->FillPath(&sb, &sp);
    }
  }
  // 灯管：小红花＋“快捷键 ON”
  Font* t1f = c.fonts->ui(21 * k, true);
  Font* t2f = c.fonts->num(23 * k, true);
  std::wstring t1 = c.T(S_HK), t2 = lit ? L"ON" : L"OFF";
  float t1w = TextW(c, t1, t1f), t2w = TextW(c, t2, t2f);
  float avail = W - 70 * k - 14 * k - 12 * k;
  float scale = (t1w + 9 * k + t2w) > avail ? avail / (t1w + 9 * k + t2w) : 1.f;
  if (scale < 1.f) { t1f = c.fonts->ui(21 * k * scale, true); t2f = c.fonts->num(23 * k * scale, true); t1w = TextW(c, t1, t1f); t2w = TextW(c, t2, t2f); }
  float tx = 70 * k, ty = 9 * k, th = 40 * k;
  GraphicsPath pet, core; NeonFlowerPath(pet, core, 38 * k, 29 * k, 44 * k);
  if (c.draw) {
    if (lit) {
      PixBuf pa; Bitmap* bmp; Graphics* g; Graphics* save; LayerBegin(c, pa, bmp, g, save);
      Pen pp(C(0xFF4FA0), 2.6f * k); c.g->DrawPath(&pp, &pet); Pen cpn(C(0xFFB43D), 2.4f * k); c.g->DrawPath(&cpn, &core);
      c.logSkip = true;  // 这两段字只是光晕的来源（图层本身不贴回），清晰的字在后面另画
      Text(c, t1, t1f, C(0xFF2E88), tx, ty, t1w + 4 * k, th, 0, false);
      LayerEnd(c, bmp, g, save);
      PixBuf pb; LayerBegin(c, pb, bmp, g, save);
      Text(c, t2, t2f, C(0x19E6C1), tx + t1w + 9 * k, ty, t2w + 4 * k, th, 10, false);
      c.logSkip = false;
      LayerEnd(c, bmp, g, save);
      PixBuf gl; gl.init(pa.w, pa.h);
      GlowAdd(gl, pa, (int)roundf(9 * k), 0xFF2E88, 1.2f); GlowAdd(gl, pa, (int)roundf(3 * k), 0xFF6FB0, 0.9f);
      GlowAdd(gl, pb, (int)roundf(9 * k), 0x19E6C1, 1.1f); GlowAdd(gl, pb, (int)roundf(3 * k), 0x5CFFE0, 0.9f);
      DrawPix(c, gl);
      Pen pp3(C(0xFF4FA0), 2.6f * k); c.g->DrawPath(&pp3, &pet);
      Pen pi(C(0xFFE3F0, 230), .9f * k); c.g->DrawPath(&pi, &pet);
      Pen cp3(C(0xFFB43D), 2.4f * k); c.g->DrawPath(&cp3, &core); Pen ci(C(0xFFF3D6), .9f * k); c.g->DrawPath(&ci, &core);
      Text(c, t1, t1f, C(0xFFEAF4), tx, ty, t1w + 4 * k, th, 0, false);
      Text(c, t2, t2f, C(0xE6FFFA), tx + t1w + 9 * k, ty, t2w + 4 * k, th, 10, false);
    } else {
      Pen pp(C(0xFF78B4, 61), 2.6f * k); c.g->DrawPath(&pp, &pet);
      Pen pi(C(0xFFFFFF, 26), .9f * k); c.g->DrawPath(&pi, &pet);
      Pen cpn(C(0xFFBE5A, 56), 2.4f * k); c.g->DrawPath(&cpn, &core);
      // 熄灭的灯管：只剩管壁（有意很淡：灯牌熄了；状态由下面点阵屏的文字说明）
      FontFamily* ff = (!c.rtl && t1f && t2f) ? XfFamilyOf(c.fonts, t1f) : nullptr;  // 字体族按名字新建（不用 Font::GetFamily：Windows 上会删掉鸿蒙黑体字体集里那份，见 xf_gfx.cpp）
      FontFamily* ff2 = ff ? XfFamilyOf(c.fonts, t2f) : nullptr;
      if (ff && ff2) {  // 字体都建不出来时（系统字体异常）不画灯管，不能读空指针让整个程序闪退
        StringFormat sf(StringFormat::GenericTypographic());
        GraphicsPath p1; p1.AddString(t1.c_str(), (INT)t1.size(), ff, t1f->GetStyle(), t1f->GetSize(), PointF(tx, ty + (th - TextH(t1f)) / 2), &sf);
        GraphicsPath p2; p2.AddString(t2.c_str(), (INT)t2.size(), ff2, t2f->GetStyle(), t2f->GetSize(), PointF(tx + t1w + 9 * k, ty + (th - TextH(t2f)) / 2), &sf);
        Color tubc = C(0xFF96C8, 66);
        RectF b1, b2; p1.GetBounds(&b1); p2.GetBounds(&b2);
        XfTestLog(c, 'O', tubc, b1.X, b1.Y, b1.Width, b1.Height, t1f->GetSize(), t1f->GetStyle(), t1);
        XfTestLog(c, 'O', tubc, b2.X, b2.Y, b2.Width, b2.Height, t2f->GetSize(), t2f->GetStyle(), t2);
        if (!g_testNoText) {
          SolidBrush fb(C(0xFFFFFF, 13)); c.g->FillPath(&fb, &p1); c.g->FillPath(&fb, &p2);
          Pen tub(tubc, 1 * k); c.g->DrawPath(&tub, &p1); c.g->DrawPath(&tub, &p2);
        }
      } else if (c.rtl) { c.logKind = 'O'; Text(c, t1, t1f, C(0xFF96C8, 66), tx, ty, t1w + 4 * k, th, 0, false); Text(c, t2, t2f, C(0xFF96C8, 66), tx + t1w + 9 * k, ty, t2w + 4 * k, th, 10, false); c.logKind = 0; }
      delete ff; delete ff2;
      for (int i = 2; i >= 1; i--) { SolidBrush gl(C(0xFF3B30, 40 * i)); float r = 3 * k + i * 2.5f * k; c.g->FillEllipse(&gl, W - 16 * k - r + 3 * k, 16 * k - r + 3 * k, 2 * r, 2 * r); }
      SolidBrush sb(C(0xFF3B30)); c.g->FillEllipse(&sb, W - 16 * k, 16 * k, 6 * k, 6 * k);
    }
  }
  c.hit(H_SWITCH, 10 * k, 5 * k, W - 20 * k, 44 * k);
  // 点阵屏
  float lx = 10 * k, ly = H - 8 * k - 19 * k, lw = W - 20 * k, lh = 19 * k;
  if (c.draw) {
    SolidBrush lb(C(0x060308)); FillRR(c, lx, ly, lw, lh, 5 * k, lb);
    StrokeRR(c, lx, ly, lw, lh, 5 * k, C(0xFFFFFF, 13), 1 * k);
    Pen in(C(0, 160), 1 * k); c.g->DrawLine(&in, lx + 4 * k, ly + 1.5f * k, lx + lw - 4 * k, ly + 1.5f * k);
  }
  TrackView sv = ViewOf(s.sfx, c.now), bv = ViewOf(s.bgm, c.now);
  bool duckIsB = false; int duck = DuckOf(c, &duckIsB);
  float ix = lx + 7 * k, iw = lw - 14 * k;
  std::wstring keyTxt = s.key.empty() ? c.T(S_UNSET) : Fmt1(c.T(lit ? S_TOGGLE : S_LIGHT), s.key);
  if (NumWarn(c)) {
    LedText(c, ix, ly, iw, lh, c.T(S_NUMLOCK) + L"  " + c.T(S_NUMFIX), L"", 0xFF5A66, -1, true, false);
    c.hit(H_NUMFIX, lx, ly, lw, lh);
  } else if (c.hover && (sv.on || bv.on)) {  // 悬停：只在有东西在放（含暂停中）时换成按钮——待机时点阵屏上的“未设置切换键”是可点的，不能换掉
    std::wstring left = sv.on ? (s.sfx.name.empty() ? c.T(S_SFX) : s.sfx.name) : bv.on ? (s.bgm.name.empty() ? c.T(S_BGM) : s.bgm.name) : keyTxt;
    float bw = 24 * k, gap = 4 * k, bh = lh - 2 * k, bx = lx + lw - 6 * k - 3 * bw - 2 * gap;  // 按钮画大些（原 18×15）：点阵屏高度内尽量大
    if (bh < 15 * k) bh = 15 * k;
    LedText(c, ix, ly, bx - ix - 6 * k, lh, left, L"", 0xFFB23F, -1, true, false);
    int ids[3] = {PauseIdFor(c), H_STOP, H_OPEN};
    if (duck && (duckIsB ? bv.on : sv.on)) ids[2] = duckIsB ? H_DUCK_B : H_DUCK_S;  // 闪避中：主面板换成“取消闪避”（暂停、急停不动）
    for (int i = 0; i < 3; i++) {
      float x0 = bx + i * (bw + gap), y0 = ly + (lh - bh) / 2; bool hv = c.hoverId == ids[i];
      if (c.draw) {
        SolidBrush b(i == 1 ? C(0xFF3B30, hv ? 170 : 115) : C(0xFF2E88, hv ? 90 : 46)); FillRR(c, x0, y0, bw, bh, 4 * k, b);
        StrokeRR(c, x0, y0, bw, bh, 4 * k, i == 1 ? C(0xFF3B30, 204) : C(0xFF4FA0, 140), 1 * k);
        Color ic = i == 1 ? C(0xFFFFFF) : C(0xFFD9EC);
        if (i == 0) { bool any = (sv.on && !sv.paused) || (bv.on && !bv.paused); if (any) IconPause(c, x0 + bw / 2, y0 + bh / 2, 11 * k, ic); else IconPlay(c, x0 + bw / 2, y0 + bh / 2, 11 * k, ic); }
        else if (i == 1) IconStop(c, x0 + bw / 2, y0 + bh / 2, 11 * k, ic);
        else if (ids[2] != H_OPEN) IconDuck(c, x0 + bw / 2, y0 + bh / 2, 11 * k, C(0xFFC15A));
        else IconOpen(c, x0 + bw / 2, y0 + bh / 2, 11 * k, ic);
      }
      c.hit(ids[i], x0, y0, bw, bh);
    }
  } else if (duck && (duckIsB ? bv.on : sv.on)) {  // 1.3.0：闪避的那一路在放（只管音效的皮肤压的是音效那一路）
    const Track& dtr = duckIsB ? s.bgm : s.sfx; const TrackView& dtv = duckIsB ? bv : sv;
    LedText(c, ix, ly, iw, lh, c.T(duck == 2 ? S_VDUCK : S_DUCK) + L"  " + (dtr.name.empty() ? c.T(duckIsB ? S_BGM : S_SFX) : dtr.name), FmtMs(dtv.remainMs, duckIsB, duckIsB), 0xFFB23F, -1, true, false);
    c.hit(duckIsB ? H_DUCK_B : H_DUCK_S, lx, ly, lw, lh);
  } else if (sv.on) {
    LedText(c, ix, ly, iw, lh, s.sfx.name.empty() ? c.T(S_SFX) : s.sfx.name, FmtMs(sv.remainMs, false, false), 0xFFB23F, (int)roundf(sv.p * 8), true, false);
  } else if (bv.on) {
    LedText(c, ix, ly, iw, lh, L"BGM  " + (s.bgm.name.empty() ? c.T(S_BGM) : s.bgm.name), FmtMs(bv.remainMs, true, true), 0x4DF2D2, -1, true, false);
  } else {
    LedText(c, ix, ly, iw, lh, keyTxt, lit ? c.T(S_READY) : L"", lit ? 0xFFB23F : 0x9C7336, -1, lit, !lit);  // 关闭时仍偏暗，但要看得清（原 #8A6630 只有 3.9）
    if (s.key.empty()) c.hit(H_KEY, lx, ly, lw, lh);
  }
  return SizeF(W, H);
}

// =================================================================================================
// 小红花贴纸（SK_STICKER，吉祥物）
enum { MO_HAPPY, MO_SLEEP, MO_SING, MO_PHONES, MO_HUM, MO_WORRY };
static void Mascot(Ctx& c, float ox, float oy, float sz, int mode) {
  if (!c.draw) return;
  float u = sz / 64.f;
  auto X = [&](float v) { return ox + v * u; }; auto Y = [&](float v) { return oy + v * u; };
  bool grey = mode == MO_SLEEP;
  // 茎与叶
  Pen stem(C(0x3FA873), 2.4f * u); stem.SetStartCap(LineCapRound); stem.SetEndCap(LineCapRound);
  c.g->DrawBezier(&stem, X(32), Y(44), X(32), Y(50), X(31), Y(55), X(30), Y(61));
  GraphicsPath l1; l1.AddBezier(X(31), Y(53), X(24), Y(51), X(20), Y(54), X(18), Y(58)); l1.AddBezier(X(18), Y(58), X(24), Y(60), X(29), Y(58), X(31), Y(53));
  SolidBrush lb1(C(0x4CC38A)); c.g->FillPath(&lb1, &l1);
  GraphicsPath l2; l2.AddBezier(X(31.5f), Y(50), X(38), Y(47), X(43), Y(49), X(46), Y(53)); l2.AddBezier(X(46), Y(53), X(40), Y(56), X(34), Y(55), X(31.5f), Y(50));
  SolidBrush lb2(C(0x5BD49A)); c.g->FillPath(&lb2, &l2);
  // 花瓣
  for (int i = 0; i < 5; i++) {
    float a = (72.f * i) * 3.14159265f / 180.f;
    float pcx = 32 + sinf(a) * 13.5f, pcy = 29 - cosf(a) * 13.5f;
    GraphicsPath pp; pp.AddEllipse(X(pcx - 10.5f), Y(pcy - 10.5f), 21 * u, 21 * u);
    if (grey) { SolidBrush b(C(0xE9B9B5)); c.g->FillPath(&b, &pp); }
    else { PathGradientBrush b(&pp); b.SetCenterPoint(PointF(X(pcx), Y(pcy - 3))); b.SetCenterColor(C(0xFF8A7C)); Color sc = C(0xF03E34); INT n = 1; b.SetSurroundColors(&sc, &n); c.g->FillPath(&b, &pp); }
  }
  // 脸
  GraphicsPath fp; fp.AddEllipse(X(20.5f), Y(17.5f), 23 * u, 23 * u);
  if (grey) { SolidBrush b(C(0xF3DFA6)); c.g->FillPath(&b, &fp); }
  else { PathGradientBrush b(&fp); b.SetCenterPoint(PointF(X(30.5f), Y(26))); b.SetCenterColor(C(0xFFEE9E)); Color sc = C(0xFFC83C); INT n = 1; b.SetSurroundColors(&sc, &n); c.g->FillPath(&b, &fp); }
  Color ink = C(0x3A2620);
  Pen ip(ink, 1.5f * u); ip.SetStartCap(LineCapRound); ip.SetEndCap(LineCapRound);
  auto openEyes = [&]() { SolidBrush b(ink); c.g->FillEllipse(&b, X(26.3f), Y(26.1f), 3.4f * u, 4.4f * u); c.g->FillEllipse(&b, X(34.3f), Y(26.1f), 3.4f * u, 4.4f * u);
    SolidBrush w(C(0xFFFFFF)); c.g->FillEllipse(&w, X(28.0f), Y(26.9f), 1.2f * u, 1.2f * u); c.g->FillEllipse(&w, X(36.0f), Y(26.9f), 1.2f * u, 1.2f * u); };
  auto happyEyes = [&]() { c.g->DrawArc(&ip, X(25.6f), Y(27.4f), 4.8f * u, 4.2f * u, 200.f, 140.f); c.g->DrawArc(&ip, X(33.6f), Y(27.4f), 4.8f * u, 4.2f * u, 200.f, 140.f); };
  auto smile = [&]() { c.g->DrawArc(&ip, X(29.4f), Y(29.8f), 5.2f * u, 4.2f * u, 20.f, 140.f); };
  auto blush = [&]() { SolidBrush b(C(0xFF8C8C, 190)); c.g->FillEllipse(&b, X(22.6f), Y(31.1f), 5.2f * u, 3 * u); c.g->FillEllipse(&b, X(36.2f), Y(31.1f), 5.2f * u, 3 * u); };
  auto phones = [&]() {
    Pen bandp(C(0x4B3F72), 3.2f * u); bandp.SetStartCap(LineCapRound); bandp.SetEndCap(LineCapRound);
    c.g->DrawArc(&bandp, X(13.5f), Y(12), 37 * u, 38 * u, 180.f, 180.f);
    SolidBrush pb(C(0x7A6CF0)); FillRR(c, X(9), Y(24.5f), 8.5f * u, 13.5f * u, 4.2f * u, pb); FillRR(c, X(46.5f), Y(24.5f), 8.5f * u, 13.5f * u, 4.2f * u, pb);
    SolidBrush hl(C(0xFFFFFF, 128)); FillRR(c, X(10.6f), Y(26.5f), 2 * u, 6 * u, 1 * u, hl);
  };
  auto note = [&](float x, float y, unsigned col, float s) {
    SolidBrush b(C(col));
    GraphicsState st = c.g->Save(); c.g->TranslateTransform(X(x), Y(y)); c.g->ScaleTransform(s, s);
    c.g->RotateTransform(-20.f); c.g->FillEllipse(&b, -2.6f * u, 4 * u, 5.2f * u, 4 * u); c.g->RotateTransform(20.f);
    c.g->FillRectangle(&b, 1.8f * u, -4 * u, 1.2f * u, 10 * u);
    PointF fl[3] = {PointF(3 * u, -4 * u), PointF(6.4f * u, 0), PointF(3 * u, -1.8f * u)}; c.g->FillPolygon(&b, fl, 3);
    c.g->Restore(st);
  };
  auto spark = [&](float x, float y, float s) {
    SolidBrush b(C(0xFFD45C)); GraphicsPath p;
    PointF pts[8] = {PointF(X(x), Y(y - 4 * s)), PointF(X(x + .7f * s), Y(y - .7f * s)), PointF(X(x + 4 * s), Y(y)), PointF(X(x + .7f * s), Y(y + .7f * s)),
                     PointF(X(x), Y(y + 4 * s)), PointF(X(x - .7f * s), Y(y + .7f * s)), PointF(X(x - 4 * s), Y(y)), PointF(X(x - .7f * s), Y(y - .7f * s))};
    p.AddPolygon(pts, 8); c.g->FillPath(&b, &p);
  };
  switch (mode) {
    case MO_SLEEP: {
      Pen sp(C(0x5A4038), 1.4f * u); sp.SetStartCap(LineCapRound); sp.SetEndCap(LineCapRound);
      c.g->DrawArc(&sp, X(25.6f), Y(27), 4.8f * u, 3.6f * u, 20.f, 140.f); c.g->DrawArc(&sp, X(33.6f), Y(27), 4.8f * u, 3.6f * u, 20.f, 140.f);
      SolidBrush m(C(0x8A5A50)); c.g->FillEllipse(&m, X(30.8f), Y(32.6f), 2.4f * u, 2 * u);
      Font* zf = c.fonts->get(L"Arial", 10 * u, FontStyleBold); Font* zf2 = c.fonts->get(L"Arial", 7.5f * u, FontStyleBold);
      SolidBrush zb(C(0x9C8CB8)), zb2(C(0xB6A9CF));
      if (zf) c.g->DrawString(L"z", 1, zf, PointF(X(46), Y(4)), &zb); if (zf2) c.g->DrawString(L"z", 1, zf2, PointF(X(53), Y(-1)), &zb2);
      break; }
    case MO_SING: {
      happyEyes(); blush();
      SolidBrush m(C(0xC2453B)); c.g->FillEllipse(&m, X(29.7f), Y(30.7f), 4.6f * u, 5.4f * u);
      SolidBrush t(C(0xFF8C8C)); c.g->FillEllipse(&t, X(30.6f), Y(33.7f), 2.8f * u, 2 * u);
      float bob = (c.draw && c.anim) ? sinf((float)(c.now % 100000u) / 1000.f * 6.f) * 1.2f : 0;
      note(51, 8 + bob, 0xFF5A6E, 1.f); note(57, 22 - bob, 0xFFB547, .8f);
      break; }
    case MO_PHONES: openEyes(); blush(); smile(); phones(); break;
    case MO_HUM: {
      happyEyes(); blush();
      Pen mp(ink, 1.4f * u); mp.SetStartCap(LineCapRound); mp.SetEndCap(LineCapRound); c.g->DrawLine(&mp, X(30.2f), Y(33.4f), X(33.8f), Y(33.4f));
      phones(); break; }
    case MO_WORRY: {
      openEyes(); blush();
      Pen bp(ink, 1.3f * u); bp.SetStartCap(LineCapRound); bp.SetEndCap(LineCapRound);
      c.g->DrawLine(&bp, X(25.4f), Y(25.2f), X(29.6f), Y(23.6f)); c.g->DrawLine(&bp, X(38.6f), Y(25.2f), X(34.4f), Y(23.6f));
      PointF wv[5] = {PointF(X(28.8f), Y(34.2f)), PointF(X(30.4f), Y(32.7f)), PointF(X(32), Y(34.2f)), PointF(X(33.6f), Y(32.7f)), PointF(X(35.2f), Y(34.2f))};
      c.g->DrawCurve(&bp, wv, 5);
      GraphicsPath dp; dp.AddBezier(X(47), Y(15), X(50.2f), Y(19.2f), X(50.2f), Y(21.4f), X(47), Y(21.4f)); dp.AddBezier(X(47), Y(21.4f), X(43.8f), Y(21.4f), X(43.8f), Y(19.2f), X(47), Y(15));
      SolidBrush db(C(0x7FC8FF)); c.g->FillPath(&db, &dp);
      break; }
    default: openEyes(); blush(); smile(); spark(9, 12, 1); spark(56, 9, .8f); spark(55, 40, .6f); break;
  }
}
static SizeF SkinSticker(Ctx& c) {
  const XState& s = *c.s; float k = c.k;
  TrackView sv = ViewOf(s.sfx, c.now), bv = ViewOf(s.bgm, c.now);
  bool duckIsB = false; int duck = DuckOf(c, &duckIsB);
  int mode = MO_HAPPY;
  if (NumWarn(c)) mode = MO_WORRY;
  else if (!s.armed) mode = MO_SLEEP;
  else if (duck && (duckIsB ? bv.on : sv.on)) mode = MO_HUM;  // 1.3.0：闪避的那一路在放
  else if (sv.on) mode = MO_SING;
  else if (bv.on) mode = MO_PHONES;
  float pad = 4 * k;  // 白边要的空间
  if (c.docked) {
    float w = 44 * k, h = 76 * k;
    if (c.draw) {
      PixBuf pb; Bitmap* bmp; Graphics* g; Graphics* save; LayerBegin(c, pb, bmp, g, save);
      GraphicsState st = c.g->Save();
      c.g->TranslateTransform(-26 * k + 32 * k, 4 * k + 40 * k); c.g->RotateTransform(16.f); c.g->TranslateTransform(-32 * k, -40 * k);
      Mascot(c, 0, 0, 64 * k, sv.on ? MO_SING : s.armed ? MO_HAPPY : MO_SLEEP);
      c.g->Restore(st);
      LayerEnd(c, bmp, g, save);
      DilateWhiteUnder(pb, (int)roundf(2.2f * k), 0xFFFFFF);
      PixBuf out = pb; ShadowUnder(out, pb, (int)roundf(5 * k), 0, (int)roundf(5 * k), 0x781E28, 0.32f);
      DrawPix(c, out);
    }
    c.hit(H_SWITCH, 0, 0, w, h);
    return SizeF(w, h);
  }
  Font* f11 = c.fonts->ui(11 * k, true);
  std::wstring t1; int t2kind = 0;  // t2: 0 键帽句 1 点进度 2 链接 3 文字 4 按钮
  std::wstring t2a, t2b; const Track* tr = nullptr; TrackView tv;
  if (mode == MO_WORRY) { t1 = c.T(S_NUMSHORT); t2kind = 2; t2a = c.T(S_NUMCUTE); }
  else if (mode == MO_SLEEP) { t1 = c.T(S_SLEEP); t2kind = s.key.empty() ? 3 : 0; t2a = s.key.empty() ? c.T(S_UNSET) : c.T(S_WAKE); }
  else if (mode == MO_HUM) { t1 = c.T(duck == 2 ? S_VDUCK : S_DUCK); t2kind = 3; t2a = (duckIsB ? s.bgm.name : s.sfx.name).empty() ? c.T(duckIsB ? S_BGM : S_SFX) : (duckIsB ? s.bgm.name : s.sfx.name); t2b = FmtMs((duckIsB ? bv : sv).remainMs, duckIsB, duckIsB); }
  else if (mode == MO_SING) { t1 = (s.sfx.name.empty() ? c.T(S_SFX) : s.sfx.name) + (c.lang <= 1 ? L"～" : L""); t2kind = 1; tr = &s.sfx; tv = sv; }
  else if (mode == MO_PHONES) { t1 = s.bgm.name.empty() ? c.T(S_BGM) : s.bgm.name; t2kind = 1; tr = &s.bgm; tv = bv; }
  else { t1 = c.T(S_HKON); t2kind = s.key.empty() ? 3 : 0; t2a = s.key.empty() ? c.T(S_UNSET) : c.T(S_TOGGLE); }
  int t2kind0 = t2kind;  // 不悬停时第二行的样子（播放中定宽时也要量它）
  if (c.hover && mode != MO_WORRY && (sv.on || bv.on)) t2kind = 4;  // 悬停：只在有东西在放时换成按钮（待机时第二行的键帽是可点的）
  Font* ft1 = c.fonts->name(t1, 13 * k, true);
  float t1w = TextW(c, t1, ft1); if (t1w > 150 * k) t1w = 150 * k;
  // 第二行的宽度
  Font* kf = c.fonts->num(10 * k, true);
  float t2w = 0; std::wstring pre, post; float keyw = 0;
  if (t2kind == 0) { Fmt1Parts(t2a, pre, post); keyw = TextW(c, s.key, kf) + 10 * k; t2w = TextW(c, pre, f11) + keyw + TextW(c, post, f11) + 4 * k; }
  else if (t2kind == 1) t2w = 10 * 7.5f * k + 6 * k + TextW(c, FmtMs(tv.remainMs, tr == &s.bgm, tr == &s.bgm), kf);
  else if (t2kind == 2) t2w = TextW(c, t2a, f11);
  else if (t2kind == 3) { float a = TextW(c, t2a, c.fonts->name(t2a, 11 * k, false)); if (a > 96 * k) a = 96 * k; t2w = a + (t2b.empty() ? 0 : 6 * k + TextW(c, t2b, kf)); }
  else t2w = 3 * 26 * k + 2 * 6 * k;
  if ((sv.on || bv.on) && mode != MO_WORRY) {  // 播放中：不悬停那一行与悬停按钮那一行取宽的定宽——悬停时气泡不变宽也不变窄（靠右放时吉祥物不跟着挪）
    float wBtn = 3 * 26 * k + 2 * 6 * k, w0 = 0;
    if (t2kind0 == 0) { std::wstring p0, q0; Fmt1Parts(t2a, p0, q0); w0 = TextW(c, p0, f11) + TextW(c, s.key, kf) + 10 * k + TextW(c, q0, f11) + 4 * k; }
    else if (t2kind0 == 1) w0 = 10 * 7.5f * k + 6 * k + TextW(c, FmtMs(tv.remainMs, tr == &s.bgm, tr == &s.bgm), kf);
    else if (t2kind0 == 2) w0 = TextW(c, t2a, f11);
    else if (t2kind0 == 3) { float a = TextW(c, t2a, c.fonts->name(t2a, 11 * k, false)); if (a > 96 * k) a = 96 * k; w0 = a + (t2b.empty() ? 0 : 6 * k + TextW(c, t2b, kf)); }
    float m = w0 > wBtn ? w0 : wBtn; if (t2w < m) t2w = m;
  }
  float bw = (t1w > t2w ? t1w : t2w) + 13 * k + 16 * k; if (bw < 118 * k) bw = 118 * k;
  float bh = 10 * k + 17 * k + 7 * k + 20 * k + 10 * k;
  float mx = pad, my = pad, msz = 64 * k;
  float bx = pad + msz - 8 * k, by = pad + (msz - bh) / 2 + 4 * k;
  float W = bx + bw + pad + 4 * k, H = pad + (msz > bh ? msz : bh) + pad + 6 * k;
  if (by < pad) by = pad;
  if (c.draw) {
    PixBuf pb; Bitmap* bmp; Graphics* g; Graphics* save; LayerBegin(c, pb, bmp, g, save);
    SolidBrush bbg(mode == MO_WORRY ? C(0xFFF3C9) : C(0xFFFFFF));
    GraphicsPath bp; RoundRectPath(bp, bx, by, bw, bh, 16 * k);
    GraphicsPath tip; float tcx = bx + 2 * k, tcy = by + bh / 2;
    PointF tp[4] = {PointF(tcx - 7 * k, tcy), PointF(tcx, tcy - 7 * k), PointF(tcx + 7 * k, tcy), PointF(tcx, tcy + 7 * k)}; tip.AddPolygon(tp, 4);
    c.g->FillPath(&bbg, &tip); c.g->FillPath(&bbg, &bp);
    Mascot(c, mx, my, msz, mode);
    float tx = bx + 16 * k, ty = by + 10 * k;
    Text(c, t1, ft1, C(0x3B2424), tx, ty, t1w + 2 * k, 17 * k, 0, true);
    float ry = ty + 17 * k + 7 * k, rh = 20 * k, x = tx;
    Color gc = C(0x8A625E);
    if (t2kind == 0) {
      if (!pre.empty()) { float w0 = TextW(c, pre, f11); Text(c, pre, f11, gc, x, ry, w0 + 2 * k, rh, 0, false); x += w0 + 2 * k; }
      SolidBrush sh(C(0xD93A4F)); FillRR(c, x, ry + 3 * k + 2 * k, keyw, 15 * k, 5 * k, sh);
      SolidBrush kb(C(0xD92D45)); FillRR(c, x, ry + 3 * k, keyw, 15 * k, 5 * k, kb);  // 键帽底色加深（原 #FF5A6E 上的白字对比度只有 3.0，低于小字要求的 4.5；#D92D45 为 4.8）
      Text(c, s.key, kf, C(0xFFFFFF), x, ry + 3 * k, keyw, 15 * k, 11, false); x += keyw + 2 * k;
      if (!post.empty()) Text(c, post, f11, gc, x, ry, TextW(c, post, f11) + 2 * k, rh, 0, false);
    } else if (t2kind == 1) {
      bool cool = tr == &s.bgm; int filled = (int)roundf(tv.p * 10);
      for (int i = 0; i < 10; i++) { SolidBrush d(i < filled ? (cool ? C(0x7A6CF0) : C(0xFF5A6E)) : (cool ? C(0xE4E0FB) : C(0xF6D9DB))); c.g->FillEllipse(&d, x + i * 7.5f * k, ry + rh / 2 - 2.5f * k, 5 * k, 5 * k); }
      Text(c, FmtMs(tv.remainMs, cool, cool), kf, C(0x3B2424), x + 75 * k + 6 * k, ry, 50 * k, rh, 10, false);
    } else if (t2kind == 2) {
      Text(c, t2a, f11, C(0xB84609), x, ry, t2w + 2 * k, rh, 0, false);
      Pen ul(C(0xB84609), 1 * k); c.g->DrawLine(&ul, x, ry + rh / 2 + 7 * k, x + t2w, ry + rh / 2 + 7 * k);
    } else if (t2kind == 3) {
      Font* fn = c.fonts->name(t2a, 11 * k, false); float a = TextW(c, t2a, fn); if (a > 96 * k) a = 96 * k;
      Text(c, t2a, fn, gc, x, ry, a + 2 * k, rh, 0, true);
      if (!t2b.empty()) Text(c, t2b, kf, C(0x3B2424), x + a + 6 * k, ry, 60 * k, rh, 10, false);
    } else {
      int ids[3] = {PauseIdFor(c), H_STOP, H_OPEN}; if (mode == MO_HUM) ids[2] = duckIsB ? H_DUCK_B : H_DUCK_S;  // 闪避中：主面板换成“取消闪避”（暂停、急停不动）
      for (int i = 0; i < 3; i++) {
        bool hv = c.hoverId == ids[i];
        SolidBrush b(i == 1 ? (hv ? C(0xF03E52) : C(0xFF5A6E)) : (hv ? C(0xFFD6DC) : C(0xFFE9EC))); FillRR(c, x, ry, 26 * k, 20 * k, 7 * k, b);
        Color ic = i == 1 ? C(0xFFFFFF) : C(0xE8455B);
        if (i == 0) { bool any = (sv.on && !sv.paused) || (bv.on && !bv.paused); if (any) IconPause(c, x + 13 * k, ry + 10 * k, 12 * k, ic); else IconPlay(c, x + 13 * k, ry + 10 * k, 12 * k, ic); }
        else if (i == 1) IconStop(c, x + 13 * k, ry + 10 * k, 12 * k, ic);
        else if (ids[2] != H_OPEN) IconDuck(c, x + 13 * k, ry + 10 * k, 12 * k, ic);
        else IconOpen(c, x + 13 * k, ry + 10 * k, 12 * k, ic);
        x += 32 * k;
      }
    }
    LayerEnd(c, bmp, g, save);
    DilateWhiteUnder(pb, (int)roundf(2.2f * k), 0xFFFFFF);
    PixBuf out = pb; ShadowUnder(out, pb, (int)roundf(6 * k), 0, (int)roundf(6 * k), 0x781E28, 0.32f);
    DrawPix(c, out);
  }
  c.hit(H_SWITCH, mx, my, msz, msz);
  {
    float tx = bx + 16 * k, ry = by + 10 * k + 17 * k + 7 * k, rh = 20 * k;
    if (t2kind == 0) { float w0 = pre.empty() ? 0 : TextW(c, pre, f11) + 2 * k; c.hit(H_KEY, tx + w0 - 2 * k, ry, keyw + 4 * k, rh); }
    else if (t2kind == 2) c.hit(H_NUMFIX, tx - 2 * k, ry - 2 * k, t2w + 6 * k, rh + 4 * k);
    else if (t2kind == 3 && mode == MO_HUM) c.hit(duckIsB ? H_DUCK_B : H_DUCK_S, bx, by, bw, bh);
    else if (t2kind == 3 && s.key.empty()) c.hit(H_KEY, tx, ry, t2w, rh);
    else if (t2kind == 4) { int ids[3] = {PauseIdFor(c), H_STOP, H_OPEN}; if (mode == MO_HUM) ids[2] = duckIsB ? H_DUCK_B : H_DUCK_S; for (int i = 0; i < 3; i++) c.hit(ids[i], tx + i * 32 * k, ry, 26 * k, 20 * k); }
  }
  return SizeF(W, H);
}

// =================================================================================================
// 毛玻璃组件卡（SK_GLASS；浅色 / 深色跟随系统；不依赖系统模糊，任何系统上效果一致）
static SizeF SkinGlass(Ctx& c) {
  const XState& s = *c.s; float k = c.k; bool dk = c.dark;
  TrackView sv = ViewOf(s.sfx, c.now), bv = ViewOf(s.bgm, c.now);
  // 有实时模糊时：浅色底 84%（透出模糊）；深色仍 91%——真机上深色卡片在白色背景前，84% 时对比度只有 4.13（Windows 合成半透明比 Wine 亮），
  // 微软的深色亚克力也比浅色不透明得多（明度层约 96% 对 85%），深色材质在亮背景前才保持深色
  Color bg = dk ? C(0x1C1D26, 232) : C(0xF8F8FC, g_glassLiveDraw ? 214 : 236), tile = dk ? C(0xFFFFFF, 18) : C(0xFFFFFF, 170), tx = dk ? C(0xF2F3F8) : C(0x1B1D2B), mut = dk ? C(0xB2B7C9) : C(0x575C78);  /* 深色：原 #A2A7BC，真机上半透明卡片的合成比 Wine 亮一点，#A9AEC1 只有 4.38 */
  Color ln = dk ? C(0xFFFFFF, 33) : C(0xFFFFFF, 217), tl = dk ? C(0xFFFFFF, 18) : C(0xFFFFFF, 153);
  float tw = 136 * k, th = 64 * k, gap = 8 * k, pad = 8 * k;
  bool only = c.docked;
  float W = only ? pad * 2 + tw : pad * 2 + tw * 2 + gap, H = only ? pad * 2 + th : pad * 2 + th * 2 + gap;
  if (c.draw) {
    GraphicsPath p; RoundRectPath(p, 0, 0, W, H, 20 * k);
    SolidBrush b(bg); c.g->FillPath(&b, &p);
    LinearGradientBrush sheen(PointF(0, 0), PointF(0, H), dk ? C(0xFFFFFF, 10) : C(0xFFFFFF, 90), C(0xFFFFFF, 0)); c.g->FillPath(&sheen, &p);
    {  // 磨砂的颗粒：微软亚克力配方里的噪点层（约 2.4%，固定图案，截图可复现）；一张 64×64 的小图平铺
      static unsigned char nz[64 * 64]; static bool made = false;
      if (!made) { unsigned v = 2463534242u; for (int i = 0; i < 64 * 64; i++) { v ^= v << 13; v ^= v >> 17; v ^= v << 5; nz[i] = (unsigned char)(v >> 24); } made = true; }
      Bitmap nb(64, 64, PixelFormat32bppPARGB);
      BitmapData bd; Rect rr(0, 0, 64, 64);
      if (nb.LockBits(&rr, ImageLockModeWrite, PixelFormat32bppPARGB, &bd) == Ok) {
        for (int y = 0; y < 64; y++) { unsigned* row = (unsigned*)((BYTE*)bd.Scan0 + y * bd.Stride); for (int x = 0; x < 64; x++) { unsigned g = nz[y * 64 + x], a = 6; unsigned pv = g * a / 255; row[x] = (a << 24) | (pv << 16) | (pv << 8) | pv; } }
        nb.UnlockBits(&bd);
        TextureBrush tb(&nb, WrapModeTile); c.g->FillPath(&tb, &p);
      }
    }
    {  // 玻璃的边：上亮下暗的渐变高光（原来是一圈一样亮的线）
      LinearGradientBrush eg(PointF(0, 0), PointF(0, H), dk ? C(0xFFFFFF, 64) : C(0xFFFFFF, 255), dk ? C(0xFFFFFF, 14) : C(0xFFFFFF, 120));
      Pen ep(&eg, 1 * k); GraphicsPath ip; RoundRectPath(ip, 0.5f * k, 0.5f * k, W - 1 * k, H - 1 * k, 20 * k - 0.5f * k); c.g->DrawPath(&ep, &ip);
    }
    (void)ln;
  }
  auto tileBg = [&](float x, float y, float w, float h, const Color& fill, const Color& line) {
    if (!c.draw) return; SolidBrush b(fill); FillRR(c, x, y, w, h, 14 * k, b); StrokeRR(c, x, y, w, h, 14 * k, line, 1 * k);
  };
  // A：快捷键
  float ax = pad, ay = pad;
  if (NumWarn(c)) {
    tileBg(ax, ay, tw, th, C(0xFFC44D, 87), C(0xF59F00, 128));
    if (c.draw) {
      IconKeypad(c, ax + 16 * k, ay + 17 * k, 13 * k, dk ? C(0xFFC15A) : C(0x793E00));  /* 浅色：有实时模糊（底 84%）时 #8D4800 只有 3.94 */
      Text(c, c.T(S_NUMLOCK), c.fonts->ui(12.5f * k, true), dk ? C(0xFFC15A) : C(0x793E00), ax + 28 * k, ay + 8 * k, tw - 36 * k, 18 * k, 0, true);
      Text(c, c.T(S_NUMFIX), c.fonts->ui(11 * k, true), dk ? C(0xFFC15A) : C(0x753C00),  /* 有实时模糊时 #8B4800 只有 3.86 */  /* 原 #E67700 只有 2.1 */ ax + 10 * k, ay + 37 * k, tw - 56 * k, 18 * k, 0, true);
    }
    c.hit(H_NUMFIX, ax, ay + 30 * k, tw - 46 * k, th - 30 * k);
    Switch(c, ax + tw - 10 * k - 32 * k, ay + 46 * k, 32 * k, 18 * k, s.armed, 0x667EEA, 0x764BA2, 0x787D96, 97, H_SWITCH);
  } else {
    tileBg(ax, ay, tw, th, tile, tl);
    if (c.draw) {
      Flower(c, ax + 18 * k, ay + 17 * k, 16 * k, !s.armed);
      Text(c, c.T(S_HK), c.fonts->ui(12 * k, false), mut, ax + 32 * k, ay + 8 * k, tw - 32 * k - 48 * k, 18 * k, 0, true);
      Text(c, c.T(s.armed ? S_ON : S_OFF), c.fonts->ui(17 * k, true), s.armed ? tx : mut, ax + 10 * k, ay + 34 * k, tw - 20 * k, 24 * k, 0, true);
    }
    Switch(c, ax + tw - 10 * k - 32 * k, ay + 17 * k, 32 * k, 18 * k, s.armed, 0x667EEA, 0x764BA2, 0x787D96, 97, H_SWITCH);
    bool un = s.key.empty(); Font* kf = un ? c.fonts->ui(10 * k, false) : c.fonts->num(10 * k, true);
    std::wstring kt = un ? c.T(S_SETKEY) : s.key;
    float kw = TextW(c, kt, kf) + 10 * k; if (kw > 64 * k) kw = 64 * k;
    float kx = ax + tw - 10 * k - kw, ky = ay + 39 * k;
    if (c.draw) { StrokeRR(c, kx, ky, kw, 16 * k, 5 * k, C(0x575C78, c.hoverId == H_KEY ? 200 : 102), 1 * k, un); Text(c, kt, kf, mut, kx, ky, kw, 16 * k, un ? 1 : 11, true); }
    c.hit(H_KEY, kx - 2 * k, ky - 2 * k, kw + 4 * k, 20 * k);
  }
  if (only) return SizeF(W, H);
  // B：音效
  float bx = pad + tw + gap, by = pad;
  tileBg(bx, by, tw, th, tile, tl);
  Color trk = dk ? C(0xFFFFFF, 31) : C(0x667EEA, 41);
  if (c.draw) {
    Ring(c, bx + 10 * k + 19 * k, by + th / 2, 38 * k, 4 * k, sv.on ? sv.p : 0, trk, C(0x667EEA), C(0x764BA2));
    Color ic = sv.on ? (dk ? C(0x9AA8FF) : C(0x667EEA)) : mut;
    if (sv.on && !sv.paused) IconPause(c, bx + 29 * k, by + th / 2, 13 * k, ic); else IconPlay(c, bx + 29 * k, by + th / 2, 13 * k, ic);
    std::wstring nm = sv.on ? (s.sfx.name.empty() ? c.T(S_SFX) : s.sfx.name) : c.T(S_SFX);
    Font* fn = sv.on ? c.fonts->name(nm, 13 * k, true) : c.fonts->ui(13 * k, false);
    Text(c, nm, fn, sv.on ? tx : mut, bx + 57 * k, by + 13 * k, tw - 63 * k, 18 * k, 0, true);
    std::wstring sub = sv.on ? (sv.paused ? c.T(S_PAUSED) : Fmt1(c.T(S_LEFT), FmtMs(sv.remainMs, false, false))) : c.T(S_IDLESHORT);
    Text(c, sub, c.fonts->ui(11 * k, false), mut, bx + 57 * k, by + 34 * k, tw - 63 * k, 16 * k, 0, true);
  }
  if (sv.on) c.hit(H_STOGGLE, bx + 8 * k, by + th / 2 - 21 * k, 42 * k, 42 * k);
  // C：背景音乐
  float cx = pad, cy = pad + th + gap;
  tileBg(cx, cy, tw, th, tile, tl);
  if (c.draw) {
    Vinyl(c, cx + 19 * k, cy + 18 * k, 18 * k, C(0x764BA2), 30.f);  // 小唱片不转（同设计稿）：这款每秒只重画几次，转起来会一跳一跳
    std::wstring nm = bv.on ? (s.bgm.name.empty() ? c.T(S_BGM) : s.bgm.name) : c.T(S_IDLEBGM);
    Text(c, nm, bv.on ? c.fonts->name(nm, 12 * k, true) : c.fonts->ui(12 * k, false), bv.on ? tx : mut, cx + 33 * k, cy + 9 * k, tw - 41 * k, 18 * k, 0, true);
    std::wstring cd = bv.on ? FmtMs(bv.remainMs, true, true) : L"00:00";
    float avail = tw - 10 * k - (10 * k + 3 * 20 * k + 2 * 4 * k) - 6 * k;  // 按钮右边到卡片右边
    float px = 15 * k; Font* nf = c.fonts->num(px, true);
    while (px > 10 * k && TextW(c, cd, nf) > avail) { px -= 0.5f * k; nf = c.fonts->num(px, true); }
    Text(c, cd, nf, bv.on ? tx : mut, cx + tw - 10 * k - avail, cy + 37 * k, avail, 20 * k, 12, false);
  }
  {
    int ids[3] = {H_BPREV, H_BTOGGLE, H_BNEXT}; float x = cx + 10 * k, y = cy + 39 * k, bw = 20 * k;
    for (int i = 0; i < 3; i++) {
      bool hv = c.hoverId == ids[i];
      if (c.draw) {
        if (i == 1) { LinearGradientBrush b(PointF(x, y), PointF(x + bw, y + 18 * k), C(0x667EEA), C(0x764BA2)); FillRR(c, x, y, bw, 18 * k, 6 * k, b); }
        else { SolidBrush b(dk ? C(0xFFFFFF, hv ? 40 : 23) : C(0x667EEA, hv ? 56 : 31)); FillRR(c, x, y, bw, 18 * k, 6 * k, b); }
        Color ic = i == 1 ? C(0xFFFFFF) : tx;
        if (i == 0) IconPrev(c, x + bw / 2, y + 9 * k, 11 * k, ic); else if (i == 2) IconNext(c, x + bw / 2, y + 9 * k, 11 * k, ic);
        else if (bv.on && !bv.paused) IconPause(c, x + bw / 2, y + 9 * k, 11 * k, ic); else IconPlay(c, x + bw / 2, y + 9 * k, 11 * k, ic);
      }
      c.hit(ids[i], x, y, bw, 18 * k); x += bw + 4 * k;  // 间隔 4：可点区域放大到 24 时各占一半间隔，三个按钮都满 24 宽（间隔 3 时只有 23，相邻又没有空隙，不合 WCAG 2.5.8）
    }
  }
  // D：闪避、急停
  float dx = pad + tw + gap, dy = pad + th + gap;
  tileBg(dx, dy, tw, th, tile, tl);
  bool duckIsB = false; int duck = DuckOf(c, &duckIsB);
  float hb = (tw - 18 * k) / 2;
  {
    float x = dx + 6 * k, y = dy + 6 * k, h = th - 12 * k; int id = duck ? (duckIsB ? H_DUCK_B : H_DUCK_S) : H_DUCK_START; bool hv = c.hoverId == id;
    if (c.draw) {
      if (duck) { SolidBrush b(C(0xFFBA49, 77)); FillRR(c, x, y, hb, h, 10 * k, b); StrokeRR(c, x, y, hb, h, 10 * k, C(0xF59F00, 140), 1 * k); }
      else { SolidBrush b(C(0x787D96, hv ? 51 : 31)); FillRR(c, x, y, hb, h, 10 * k, b); }
      Color fg = duck ? (dk ? C(0xFFC15A) : C(0x8A5200)) : (dk ? C(0xBCC0D0) : C(0x535772));  /* 深色：有实时模糊、白背景时 #B2B7C9 只有 4.38 */  /* 浅色：按钮直接在卡片底上，有实时模糊（底 84%）时 #575C78 只有 4.48 */  // 浅色：原 #C77700 只有 2.6
      IconDuck(c, x + hb / 2, y + 15 * k, 16 * k, fg);
      Text(c, c.T(duck ? (duck == 2 ? S_VDUCK : S_DUCK) : S_DUCKBTN), c.fonts->ui(11 * k, true), fg, x + 2 * k, y + 26 * k, hb - 4 * k, 16 * k, 1, true);
    }
    c.hit(id, x, y, hb, h);
    x += hb + 6 * k; hv = c.hoverId == H_STOP;
    if (c.draw) {
      SolidBrush b(hv ? C(0xF03E3E) : C(0xF03E3E, 33)); FillRR(c, x, y, hb, h, 10 * k, b);
      Color fg = hv ? C(0xFFFFFF) : (dk ? C(0xFFA3A3) : C(0xAA1A1A));  /* 深色：有实时模糊、白背景时 #FF9595 只有 4.36 */  /* 浅色：有实时模糊（底 84%）时 #B71C1C 只有 4.32 */  /* 深色：原 #FF8787 真机上 4.39 */
      IconStop(c, x + hb / 2, y + 15 * k, 16 * k, fg);
      Text(c, c.T(S_STOP), c.fonts->ui(11 * k, true), fg, x + 2 * k, y + 26 * k, hb - 4 * k, 16 * k, 1, true);
    }
    c.hit(H_STOP, x, y, hb, h);
  }
  return SizeF(W, H);
}

// =================================================================================================
// Y2K 随身听磁带（SK_CASSETTE）。1.4.0：只管音效（原来只管背景音乐）；读数放大；闪避印章移到标签纸右下角；悬停的走带键与其余单路皮肤相同
static void IconKind(Ctx& c, int id, float cx, float cy, float s, const Color& col, bool playing);  // 按可点区域画图标（定义在后面，新增 9 款共用）
static SizeF SkinCassette(Ctx& c) {
  const XState& s = *c.s; float k = c.k; bool on = s.armed;
  TrackView sv = ViewOf(s.sfx, c.now), bv = ViewOf(s.bgm, c.now);
  Now pn = Primary(c);
  bool duckIsB = false; int duck = DuckOf(c, &duckIsB);
  if (duck && !(duckIsB ? bv.on : sv.on)) duck = 0;  // 1.4.0：闪避的那一路在放时才显示（与其余各款相同；原来什么都没放时说话闪避一开也盖印章、读数换成“闪避”）
  if (c.docked) {
    float w = 196 * k, h = 26 * k;
    if (c.draw) {
      PixBuf pb; Bitmap* bmp; Graphics* g; Graphics* save; LayerBegin(c, pb, bmp, g, save);
      if (!on) { c.logDesat = .92f; c.logBright = .97f; }  // 测试：这个图层随后去色，记录的文字颜色同样换算
      LinearGradientBrush bg(PointF(0, 0), PointF(w, h), C(0xCCBEFF), C(0xFFC6EC)); FillRR(c, 0, 0, w, h, 6 * k, bg);
      StrokeRR(c, 0, 0, w, h, 6 * k, C(0xFFFFFF, 190), 1 * k);
      SolidBrush led(on ? C(0x2BE07A) : C(0x8A8792)); c.g->FillEllipse(&led, 10 * k, h / 2 - 3.5f * k, 7 * k, 7 * k);
      Text(c, c.T(S_HK), c.fonts->ui(9 * k, true), C(0x28143C, 191), 21 * k, 0, 46 * k, h, 0, true);
      float sx = 70 * k, sw = w - 82 * k; unsigned st[3] = {0xFF6B3D, 0xFFB13D, 0xFF4D6D};
      for (int i = 0; i < 3; i++) { SolidBrush b(C(st[i])); c.g->FillRectangle(&b, sx, 7 * k + i * 4 * k, sw, 4 * k); }
      LayerEnd(c, bmp, g, save); c.logDesat = 0; c.logBright = 1;
      if (!on) Desaturate(pb, .92f, .97f);
      DrawPix(c, pb);
    }
    c.hit(H_SWITCH, 0, 0, w, h);
    return SizeF(w, h);
  }
  float W = 196 * k, CH = 124 * k;
  bool keys = c.hover && pn.t;  // 悬停：磁带窗口变成走带键——尺寸不变，贴着屏幕边也不跳。1.4.0：只在显示的那一路在放（含暂停中）时换（与其余单路皮肤相同）：只管音效后，待机时的播放键点了没反应（易语言的“音效暂停或继续”在没有音效时什么也不做），急停在待机时本来也停不了什么
  float H = CH;
  float extraTop = NumWarn(c) ? 14 * k : 0, extraRight = NumWarn(c) ? 12 * k : 0;
  float ox = 0, oy = extraTop;
  // 闪避印章（1.4.0）：盖在标签纸右下角的边上（原来斜盖在磁带窗口上：读数放大后会压住倒计时，19 个语种里 16～17 个压上）。印章上的字斜着用 GDI+ 画（见下），
  // 宽度也按 GDI+ 的画法量（原来只按精绘量：GDI+ 画出来更宽，俄、法、德、英等长的字伸出印章框）；最宽 150，太长的语种逐级缩小字号（最小 8 号）。
  // 位置、大小在量尺寸与绘制两遍里一样，可点区域跟着印章
  std::wstring dt; Font* df = nullptr; float dw = 0, dcx = ox + W - 14 * k, dcy = oy + 80 * k;
  if (duck) {
    dt = c.T(duck == 2 ? S_VDUCK : S_DUCK);
    auto stampW = [&](Font* f) -> float {
      float w = TextW(c, dt, f);
      if (f && !c.rtl) {  // 从右到左的语种用 Text 画（与 TextW 同一种量法），不用再量
        StringFormat sf(StringFormat::GenericTypographic()); sf.SetFormatFlags(sf.GetFormatFlags() | StringFormatFlagsNoWrap); RectF bb;
        if (c.g->MeasureString(dt.c_str(), (INT)dt.size(), f, PointF(0, 0), &sf, &bb) == Ok && bb.Width > w) w = bb.Width;
      }
      return w + 12 * k; };
    float dpx = 11 * k; df = c.fonts->ui(dpx, true); dw = stampW(df);
    while (dpx > 8 * k && dw > 150 * k) { dpx -= 0.5f * k; df = c.fonts->ui(dpx, true); dw = stampW(df); }
    if (dw > 150 * k) dw = 150 * k;
    dcx -= dw / 2;
  }
  if (c.draw) {
    PixBuf pb; Bitmap* bmp; Graphics* g; Graphics* save; LayerBegin(c, pb, bmp, g, save);
    if (!on) { c.logDesat = .92f; c.logBright = .97f; }  // 测试：这个图层随后去色，记录的文字颜色同样换算
    GraphicsPath shell; RoundRectPath(shell, ox, oy, W, CH, 12 * k);
    LinearGradientBrush sb(PointF(ox, oy), PointF(ox + W, oy + CH), C(0xCCBEFF, 247), C(0xFFC6EC, 247));
    Color cs[3] = {C(0xCCBEFF, 247), C(0xA6E4FF, 245), C(0xFFC6EC, 247)}; REAL ps[3] = {0, .5f, 1}; sb.SetInterpolationColors(cs, ps, 3);
    c.g->FillPath(&sb, &shell);
    StrokeRR(c, ox, oy, W, CH, 12 * k, C(0xFFFFFF, 191), 1 * k);
    Pen bot(C(0x5A3C8C, 51), 3 * k); c.g->DrawLine(&bot, ox + 12 * k, oy + CH - 1.5f * k, ox + W - 12 * k, oy + CH - 1.5f * k);
    float scr[4][2] = {{5, 5}, {196 - 12, 5}, {5, 124 - 12}, {196 - 12, 124 - 12}};
    for (auto& q : scr) {
      GraphicsPath sp; sp.AddEllipse(ox + q[0] * k, oy + q[1] * k, 7 * k, 7 * k);
      PathGradientBrush b(&sp); b.SetCenterPoint(PointF(ox + (q[0] + 2.5f) * k, oy + (q[1] + 2) * k)); b.SetCenterColor(C(0xFFFFFF)); Color e2 = C(0x6F6A86); INT n = 1; b.SetSurroundColors(&e2, &n); c.g->FillPath(&b, &sp);
    }
    // 标签纸
    float lx = ox + 10 * k, ly = oy + 10 * k, lw = W - 20 * k, lh = 72 * k;
    SolidBrush lab(C(0xFFF8EA)); FillRR(c, lx, ly, lw, lh, 7 * k, lab);
    std::wstring title = pn.t ? (pn.t->name.empty() ? c.T(pn.isBgm ? S_BGM : S_SFX) : pn.t->name) : c.T(S_HK) + (on ? L" ON" : L" OFF");
    Text(c, title, c.fonts->name(title, 14 * k, true), C(0x2A1D1D), lx + 10 * k, ly + 4 * k, 112 * k, 20 * k, 0, true);
    bool un = s.key.empty(); Font* kf = c.fonts->num(10 * k, true);
    std::wstring kt = un ? L"+" : s.key; float kw = un ? 16 * k : TextW(c, kt, kf) + 10 * k; if (kw > 60 * k) kw = 60 * k;
    float kx = lx + lw - 8 * k - kw, ky = ly + 6 * k;
    if (un) StrokeRR(c, kx, ky, kw, 16 * k, 5 * k, C(0xB8A89C), 1 * k, true); else { SolidBrush kb(C(0x2A1D1D)); FillRR(c, kx, ky, kw, 16 * k, 5 * k, kb); }
    if (un) IconPlus(c, kx + kw / 2, ky + 8 * k, 8 * k, C(0x8A7A70), 1.5f * k);
    else Text(c, kt, kf, C(0xFFF8EA), kx, ky, kw, 16 * k, 11, true);
    unsigned st[3] = {0xFF6B3D, 0xFFB13D, 0xFF4D6D};
    for (int i = 0; i < 3; i++) { SolidBrush b(C(st[i])); c.g->FillRectangle(&b, lx, ly + 28 * k + i * 4 * k, lw, 4 * k); }
    // 带窗：磁带轮＋计数器
    float wx = ox + 18 * k, wy = oy + 34 * k, ww = W - 36 * k, wh = 32 * k;
    SolidBrush rim(C(0xFFF8EA)); FillRR(c, wx - 2 * k, wy - 2 * k, ww + 4 * k, wh + 4 * k, 18 * k, rim);
    LinearGradientBrush wb(PointF(0, wy), PointF(0, wy + wh), C(0x261A30, 224), C(0x3A2846, 214)); FillRR(c, wx, wy, ww, wh, 16 * k, wb);
    float p = pn.t ? pn.v.p : .5f, spin = Spin(c, pn.t && !pn.v.paused, 180.f);
    if (!keys) {
    float rL = 7.5f + (1 - p) * 5.5f, rR = 7.5f + p * 5.5f;
    float hubs[2] = {wx + 30 * k - 8 * k, wx + ww - 30 * k + 8 * k};
    float rad[2] = {rL, rR};
    for (int i = 0; i < 2; i++) {
      float hx = hubs[i], hy = wy + wh / 2;
      SolidBrush tape(C(0x4A2F28)); c.g->FillEllipse(&tape, hx - rad[i] * k, hy - rad[i] * k, 2 * rad[i] * k, 2 * rad[i] * k);
      SolidBrush hub(C(0xF4F1FF)); c.g->FillEllipse(&hub, hx - 6.2f * k, hy - 6.2f * k, 12.4f * k, 12.4f * k);
      Pen sp(C(0xB9B2D6), 1.3f * k); sp.SetStartCap(LineCapRound); sp.SetEndCap(LineCapRound);
      for (int j = 0; j < 3; j++) { float a = (spin + j * 60.f) * 3.14159265f / 180.f; c.g->DrawLine(&sp, hx - sinf(a) * 4.4f * k, hy - cosf(a) * 4.4f * k, hx + sinf(a) * 4.4f * k, hy + cosf(a) * 4.4f * k); }
      SolidBrush hole(C(0x2A1D2E)); c.g->FillEllipse(&hole, hx - 2.2f * k, hy - 2.2f * k, 4.4f * k, 4.4f * k);
    }
    // 1.4.0：读数（倒计时）放大——原来 10 号字、16 高，用户反映看不清；改为 16 号字、24 高。宽度至少按“00:00”算（数字变化时屏不跟着伸缩），
    // 最宽到两个磁带轮之间（磁带轮最大时两边各留 3）；放不下时逐级缩小字号，不截断。闪避中照常显示倒计时、改成琥珀色（原来换成“闪避”两个字：
    // 说话闪避一开倒计时就看不到了；闪避由印章表示）
    std::wstring lcd = NumWarn(c) ? L"--:--" : pn.t ? FmtMs(pn.v.remainMs, pn.isBgm, false) : (on ? L"READY" : L"--:--");
    float lpx = 16 * k, lh2 = 24 * k, lpad = 7 * k, lmax = 84 * k;
    Font* lf = c.fonts->num(lpx, true);
    while (lpx > 10 * k && TextW(c, lcd, lf) + 2 * lpad > lmax) { lpx -= 0.5f * k; lf = c.fonts->num(lpx, true); }
    float ltw = TextW(c, lcd, lf), l00 = TextW(c, L"00:00", lf), lw2 = (ltw > l00 ? ltw : l00) + 2 * lpad; if (lw2 > lmax) lw2 = lmax;
    float lcx = wx + ww / 2 - lw2 / 2, lcy = wy + wh / 2 - lh2 / 2;
    SolidBrush lb(duck ? C(0x2A1C06) : C(0x0D2418)); FillRR(c, lcx, lcy, lw2, lh2, 4 * k, lb);
    StrokeRR(c, lcx, lcy, lw2, lh2, 4 * k, duck ? C(0xFFC15A, 89) : C(0x7CFFB2, 64), 1 * k);
    Text(c, lcd, lf, duck ? C(0xFFC15A) : C(0x7CFFB2), lcx, lcy, lw2, lh2, 11, false);
    }
    // 底部梯形与小孔
    GraphicsPath tz; PointF tzp[4] = {PointF(ox + 54 * k + 8 * k, oy + CH - 24 * k), PointF(ox + W - 54 * k - 8 * k, oy + CH - 24 * k), PointF(ox + W - 54 * k, oy + CH), PointF(ox + 54 * k, oy + CH)}; tz.AddPolygon(tzp, 4);
    SolidBrush tzb(C(0x50327A, 38)); c.g->FillPath(&tzb, &tz);
    SolidBrush hb(C(0x28193C, 115)); for (int i = 0; i < 4; i++) c.g->FillEllipse(&hb, ox + W / 2 - 21 * k + i * 14 * k - 3 * k, oy + CH - 12 * k - 3 * k, 6 * k, 6 * k);  // 间距 20→14：原来最左的小孔落在“快捷键”标签的框里（标签长的语种字会压上去），收拢后离标签 4 个单位
    // 状态灯
    if (on) { SolidBrush gl(C(0x2BE07A, 90)); c.g->FillEllipse(&gl, ox + 10 * k, oy + CH - 18.5f * k, 11 * k, 11 * k); }
    SolidBrush ring2(C(0xFFFFFF, 217)); c.g->FillEllipse(&ring2, ox + 11.5f * k, oy + CH - 17 * k, 8 * k, 8 * k);
    SolidBrush led(on ? C(0x2BE07A) : C(0x8A8792)); c.g->FillEllipse(&led, ox + 12 * k, oy + CH - 16.5f * k, 7 * k, 7 * k);
    Text(c, c.T(S_HK), c.fonts->ui(9 * k, true), C(0x28143C, 191), ox + 24 * k, oy + CH - 21 * k, 46 * k, 14 * k, 0, true);
    LayerEnd(c, bmp, g, save); c.logDesat = 0; c.logBright = 1;
    if (!on) Desaturate(pb, .92f, .97f);
    PixBuf out = pb; ShadowUnder(out, pb, (int)roundf(7 * k), 0, (int)roundf(6 * k), 0x3C1E5A, 0.45f);
    DrawPix(c, out);
    if (duck) {  // 闪避印章（位置、字号见上面 dt / dw 的说明）
      GraphicsState st2 = c.g->Save();
      c.g->TranslateTransform(dcx, dcy); c.g->RotateTransform(-10.f);
      SolidBrush bgp(C(0xFFF8EA, 235)); FillRR(c, -dw / 2, -9 * k, dw, 18 * k, 5 * k, bgp);  // 印章底更实、字更深（原 #E5484D 在半透明底上只有 2.3）
      StrokeRR(c, -dw / 2, -9 * k, dw, 18 * k, 5 * k, C(0xB42318), 2 * k);
      if (!c.rtl) {  // 斜着盖的章：直接用 GDI+ 画（精绘文字只画水平的字）
        XfTestLog(c, 'S', C(0xB42318), -dw / 2 + 6 * k, -TextH(df) / 2, dw - 12 * k, TextH(df), df ? df->GetSize() : 0.f, df ? df->GetStyle() : 0, dt);
        if (!g_testNoText && !XfGdiTextImage(c, dt, df, C(0xB42318), -dw / 2, -9 * k, dw, 18 * k, 1)) { SolidBrush tb(C(0xB42318)); StringFormat sf; sf.SetAlignment(StringAlignmentCenter); sf.SetLineAlignment(StringAlignmentCenter); sf.SetFormatFlags(StringFormatFlagsNoWrap); c.g->DrawString(dt.c_str(), (INT)dt.size(), df, RectF(-dw / 2, -9 * k, dw, 18 * k), &sf, &tb); }  // GDI+ 画不出字、或缺字时先用 GDI 画成图再斜着贴
      }
      else Text(c, dt, df, C(0xB42318), -dw / 2, -9 * k, dw, 18 * k, 1, false);
      c.g->Restore(st2);
    }
    if (NumWarn(c)) {  // 便利贴
      GraphicsState st2 = c.g->Save();
      float nw = 96 * k, nh = 38 * k;  // 两行之间留够：按 Windows 字体的行高算，第一行的下伸笔画碰不到第二行（原来 36 高、两行相隔 15）
      c.g->TranslateTransform(ox + W + extraRight - nw / 2 - 2 * k, oy - extraTop + nh / 2 + 2 * k); c.g->RotateTransform(5.f);
      SolidBrush shd(C(0x503C00, 70)); c.g->FillRectangle(&shd, -nw / 2 + 2 * k, -nh / 2 + 4 * k, nw, nh);
      SolidBrush nb(C(0xFFE66D)); c.g->FillRectangle(&nb, -nw / 2, -nh / 2, nw, nh);
      Text(c, c.T(S_NUMLOCK), c.fonts->ui(10 * k, true), C(0x5A4300), -nw / 2 + 7 * k, -nh / 2 + 3 * k, nw - 14 * k, 15 * k, 0, true);
      Text(c, c.T(S_NUMFIX), c.fonts->ui(10 * k, true), C(0xB03B0B),  /* 原 #C2410C 只有 4.1 */ -nw / 2 + 7 * k, -nh / 2 + 20 * k, nw - 14 * k, 15 * k, 0, true);
      c.g->Restore(st2);
    }
  }
  c.hit(H_SWITCH, ox + 8 * k, oy + CH - 24 * k, 64 * k, 22 * k);
  if (s.key.empty() || true) c.hit(H_KEY, ox + W - 10 * k - 8 * k - 60 * k, oy + 14 * k, 62 * k, 20 * k);
  if (duck) c.hit(duckIsB ? H_DUCK_B : H_DUCK_S, dcx - dw / 2, dcy - 9 * k, dw, 18 * k);  // 1.4.0：跟着印章（不旋转的外框；碰不到开关与走带键）
  if (NumWarn(c)) c.hit(H_NUMFIX, ox + W + extraRight - 100 * k, 0, 100 * k, 44 * k);
  if (keys) {  // 悬停：实体按键，放在磁带窗口里
    const int nk = 3; float kw = 36 * k, kg = 4 * k;  // 1.4.0：与其余单路皮肤相同的三个键——暂停 / 继续、急停、主面板（闪避中主面板换成“取消闪避”；原来是上一首、暂停、急停、下一首）
    float kx = ox + W / 2 - (nk * kw + (nk - 1) * kg) / 2, ky = oy + 34 * k + 4 * k;
    int ids[3] = {PauseIdFor(c), H_STOP, duck ? (duckIsB ? H_DUCK_B : H_DUCK_S) : H_OPEN};
    for (int i = 0; i < nk; i++) {
      bool hv = c.hoverId == ids[i];
      if (c.draw) {
        SolidBrush sh(C(0x9D99B0)); FillRR(c, kx, ky + 2 * k, kw, 22 * k, 5 * k, sh);
        LinearGradientBrush kb(PointF(0, ky), PointF(0, ky + 22 * k), hv ? C(0xFFFFFF) : C(0xF4F3F8), hv ? C(0xDAD7E6) : C(0xC9C6D6)); FillRR(c, kx, ky, kw, 22 * k, 5 * k, kb);
        Color ic = ids[i] == H_STOP ? C(0xC92A2A) : (ids[i] == H_DUCK_S || ids[i] == H_DUCK_B) ? C(0xB4580A) : C(0x3A3550);
        IconKind(c, ids[i], kx + kw / 2, ky + 11 * k, 12 * k, ic, (sv.on && !sv.paused) || (bv.on && !bv.paused));
      }
      c.hit(ids[i], kx, ky, kw, 24 * k);
      kx += kw + kg;
    }
  }
  return SizeF(W + extraRight, H + extraTop);
}

// =================================================================================================
// 像素游戏 HUD（SK_PIXEL；2 个屏幕像素为一格；150%、200% 时按整数倍放大，不发糊）
static int PxU(Ctx& c) { int u = (int)roundf(2 * c.k); return u < 2 ? 2 : u; }
static void PxRect(Ctx& c, float x, float y, float w, float h, unsigned rgb) { if (!c.draw) return; SolidBrush b(C(rgb)); c.g->FillRectangle(&b, x, y, w, h); }
static void PxFrame(Ctx& c, int w, int h, int u, bool on) {
  unsigned o = on ? 0x07061A : 0x08080C, b = on ? 0x2D2A66 : 0x36353F, bg = on ? 0x17153A : 0x1C1C23, hi = on ? 0x4D47A8 : 0x4A4957, sh = on ? 0x100E2A : 0x141419;
  auto R = [&](int x, int y, int ww, int hh, unsigned col) { PxRect(c, (float)(x * u), (float)(y * u), (float)(ww * u), (float)(hh * u), col); };
  R(2, 0, w - 4, 1, o); R(2, h - 1, w - 4, 1, o); R(0, 2, 1, h - 4, o); R(w - 1, 2, 1, h - 4, o); R(1, 1, 1, 1, o); R(w - 2, 1, 1, 1, o); R(1, h - 2, 1, 1, o); R(w - 2, h - 2, 1, 1, o);
  R(2, 1, w - 4, 1, b); R(2, h - 2, w - 4, 1, b); R(1, 2, 1, h - 4, b); R(w - 2, 2, 1, h - 4, b); R(2, 2, w - 4, h - 4, bg);
  R(3, 2, w - 6, 1, hi); R(2, 3, 1, h - 6, hi); R(3, h - 3, w - 6, 1, sh); R(w - 3, 3, 1, h - 6, sh);
}
static float PxText(Ctx& c, float x, float boxTop, float boxH, const std::wstring& t, int px, unsigned col, unsigned shadow, bool hasShadow, float maxW) {
  // 不抗锯齿的点阵字（GDI 原样的字形），每个点画成 cell×cell 的方块；只取有墨的行，在行框里上下居中；返回宽度
  std::vector<unsigned char> m; int w = 0, h = 0;
  if (!PixelTextMask(c.fonts->pixelFamily(), px, t, m, w, h)) return 0;
  int cell = PxU(c);
  int top = h, bot = -1, right = 0;
  for (int yy = 0; yy < h; yy++) for (int xx = 0; xx < w; xx++) if (m[(size_t)yy * w + xx]) { if (yy < top) top = yy; if (yy > bot) bot = yy; if (xx + 1 > right) right = xx + 1; }
  if (bot < top) return 0;
  int vis = right; bool cut = false;
  auto colEmpty = [&](int x0) { for (int yy = top; yy <= bot; yy++) if (m[(size_t)yy * w + x0]) return false; return true; };
  if (maxW > 0 && vis * cell > maxW) {  // 放不下：在字与字之间的空白列截断，不把字切成半个；末尾画两个点表示还有（原来没有省略号，看不出被截了）
    int room = (int)(maxW / cell);
    cut = room >= 8;  // 留出“空、点、空、点”四格；不到 8 格时位置太窄，照原样只截断（省略号不能超出给的宽度）
    vis = cut ? room - 4 : room; if (vis < 0) vis = 0;
    while (vis > 0 && !colEmpty(vis - 1) && vis < right && !colEmpty(vis)) vis--;
    if (cut) while (vis > 0 && colEmpty(vis - 1)) vis--;
  }
  int base = bot;  // 点画在基线上：取各列最低墨点出现最多的那一行（有下伸笔画的字母不算数）
  if (cut) {
    std::vector<int> cnt((size_t)h, 0);
    for (int xx = 0; xx < vis; xx++) for (int yy = bot; yy >= top; yy--) if (m[(size_t)yy * w + xx]) { cnt[(size_t)yy]++; break; }
    int best = -1; for (int yy = top; yy <= bot; yy++) if (cnt[(size_t)yy] > 0 && (best < 0 || cnt[(size_t)yy] >= cnt[(size_t)best])) best = yy;
    if (best >= 0) base = best;
  }
  int total = vis + (cut ? 4 : 0);
  int inkH = bot - top + 1;
  if (c.draw) {
    PixBuf pb; pb.init(total * cell + cell, inkH * cell + cell);
    unsigned pc = 0xFF000000 | col, ps = 0xFF000000 | shadow;
    for (int yy = 0; yy < inkH; yy++) for (int xx = 0; xx < vis; xx++) {
      int sy = yy + top;
      bool on = m[(size_t)sy * w + xx] != 0;
      if (!on) continue;
      for (int dy = 0; dy < cell; dy++) for (int dx = 0; dx < cell; dx++) pb.px[(size_t)(yy * cell + dy) * pb.w + xx * cell + dx] = pc;
    }
    if (hasShadow) {  // 阴影：右下错一格，只画在空白处
      for (int yy = inkH; yy >= 1; yy--) for (int xx = vis; xx >= 1; xx--) {
        int sy = yy - 1 + top, sx = xx - 1;
        if (sx >= w || !m[(size_t)sy * w + sx]) continue;
        bool here = (yy < inkH && xx < vis) ? m[(size_t)(yy + top) * w + xx] != 0 : false;
        if (here) continue;
        for (int dy = 0; dy < cell; dy++) for (int dx = 0; dx < cell; dx++) { size_t o = (size_t)(yy * cell + dy) * pb.w + xx * cell + dx; if (o < pb.px.size() && !(pb.px[o] >> 24)) pb.px[o] = ps; }
      }
    }
    if (cut) for (int d = 0; d < 2; d++) {  // 省略号：基线上两个点（与字同色，阴影同样右下错一格）
      int cx = vis + 1 + d * 2, cy = base - top;
      for (int dy = 0; dy < cell; dy++) for (int dx = 0; dx < cell; dx++) pb.px[(size_t)(cy * cell + dy) * pb.w + cx * cell + dx] = pc;
      if (hasShadow) for (int dy = 0; dy < cell; dy++) for (int dx = 0; dx < cell; dx++) { size_t o = (size_t)((cy + 1) * cell + dy) * pb.w + (cx + 1) * cell + dx; if (o < pb.px.size() && !(pb.px[o] >> 24)) pb.px[o] = ps; }
    }
    float y = boxTop + roundf((boxH - inkH * cell) / 2 / cell) * cell;
    Matrix mm; c.g->GetTransform(&mm); REAL e[6]; mm.GetElements(e);
    Bitmap bmp(pb.w, pb.h, pb.w * 4, PixelFormat32bppPARGB, (BYTE*)pb.px.data());
    GraphicsState st = c.g->Save();
    c.g->SetInterpolationMode(InterpolationModeNearestNeighbor); c.g->SetPixelOffsetMode(PixelOffsetModeHalf);
    float dx = x, dy = y;
    if (e[0] < 0) { PointF p0(x, y); mm.TransformPoints(&p0, 1); c.g->ResetTransform(); dx = p0.X - pb.w; dy = p0.Y; }
    XfTestLog(c, 'P', C(col), dx, dy, (float)pb.w, (float)pb.h, (float)(px * cell), 0, t);  // 记的是整块（含右下错一格的阴影）
    if (!g_testNoText) c.g->DrawImage(&bmp, dx, dy, (REAL)pb.w, (REAL)pb.h);
    c.g->Restore(st);
  }
  return (float)(total * cell);
}
static void PxSprite(Ctx& c, float x, float y, bool grey) {
  if (!c.draw) return;
  const int z = 18, W = z + 2;
  PixBuf pb; pb.init(W, W);
  {
    Bitmap bmp(W, W, W * 4, PixelFormat32bppPARGB, (BYTE*)pb.px.data()); Graphics g(&bmp); g.SetSmoothingMode(SmoothingModeAntiAlias);
    Ctx t = c; t.g = &g; t.draw = true; t.k = 1;
    FlowerMono(t, 1 + z / 2.f, 1 + z / 2.f, (float)z, grey ? C(0x9A9AA4) : C(0xFF5A4E), grey ? C(0xD0D0D8) : C(0xFFC93D));
  }
  unsigned pet = grey ? 0x9A9AA4 : 0xFF5A4E, core = grey ? 0xD0D0D8 : 0xFFC93D, oc = grey ? 0x282830 : 0x4A0C1E;
  std::vector<unsigned char> sol((size_t)W * W, 0);
  for (int i = 0; i < W * W; i++) {
    unsigned p = pb.px[i]; unsigned a = p >> 24;
    if (a < 110) { pb.px[i] = 0; continue; }
    sol[i] = 1;
    unsigned r = ((p >> 16) & 255) * 255 / a, gg = ((p >> 8) & 255) * 255 / a;
    pb.px[i] = 0xFF000000 | ((gg > 150 && r > 200) ? core : pet);
  }
  for (int i = 0; i < W * W; i++) {
    if (sol[i]) continue; int xx = i % W, yy = i / W;
    if ((xx > 0 && sol[i - 1]) || (xx < W - 1 && sol[i + 1]) || (yy > 0 && sol[i - W]) || (yy < W - 1 && sol[i + W])) pb.px[i] = 0xFF000000 | oc;
  }
  int u = PxU(c);
  Bitmap bmp(W, W, W * 4, PixelFormat32bppPARGB, (BYTE*)pb.px.data());
  GraphicsState st = c.g->Save(); c.g->SetInterpolationMode(InterpolationModeNearestNeighbor); c.g->SetPixelOffsetMode(PixelOffsetModeHalf);
  c.g->DrawImage(&bmp, x, y, (REAL)(W * u), (REAL)(W * u));
  c.g->Restore(st);
}
static SizeF SkinPixel(Ctx& c) {
  const XState& s = *c.s; bool on = s.armed; int u = PxU(c);
  TrackView sv = ViewOf(s.sfx, c.now), bv = ViewOf(s.bgm, c.now);
  bool duckIsB = false; int duck = DuckOf(c, &duckIsB);
  if (c.docked) {
    float w = 30.f * u, h = 30.f * u;
    if (c.draw) { GraphicsState st = c.g->Save(); c.g->SetSmoothingMode(SmoothingModeNone); PxFrame(c, 30, 30, u, on); c.g->Restore(st); PxSprite(c, 4.f * u, 4.f * u, !on); }
    c.hit(H_SWITCH, 0, 0, w, h);
    return SizeF(w, h);
  }
  float W = 124.f * u, H = 38.f * u;
  if (c.draw) {
    GraphicsState st = c.g->Save(); c.g->SetSmoothingMode(SmoothingModeNone);
    PxFrame(c, 124, 38, u, on);
    // 状态灯
    float lx = W - 6.f * u - 4.f * u, ly = 5.f * u;
    PxRect(c, lx - 1.f * u, ly - 1.f * u, 6.f * u, 6.f * u, 0x07061A);
    PxRect(c, lx, ly, 4.f * u, 4.f * u, on ? 0x45F07A : 0x3B3870);
    c.g->Restore(st);
    if (on) { SolidBrush gl(C(0x45F07A, 60)); c.g->FillEllipse(&gl, lx - 4.f * u, ly - 4.f * u, 12.f * u, 12.f * u); }
    PxSprite(c, 6.f * u, 9.f * u, !on);
  }
  c.hit(H_SWITCH, 4.f * u, 6.f * u, 26.f * u, 26.f * u);
  c.hit(H_SWITCH, W - 14.f * u, 2.f * u, 12.f * u, 10.f * u);
  float x1 = 31.f * u, y1 = 4.f * u, x2 = 31.f * u, y2 = 20.f * u, bh = 14.f * u;
  float maxW = W - x1 - 13.f * u;
  auto clip = [](const std::wstring& t, size_t n) { return t.size() > n ? t.substr(0, n - 1) + L"\x2026" : t; };
  if (NumWarn(c)) {
    PxText(c, x1, y1, bh, L"! " + c.T(S_NUMLOCK), 12, 0xFF4F69, 0x07061A, true, maxW);
    PxText(c, x2, y2, bh, c.T(S_NUMFIX), 12, 0xFFD541, 0x07061A, true, maxW);
    c.hit(H_NUMFIX, x1, 2.f * u, W - x1 - 2.f * u, H - 4.f * u);
  } else if (c.hover && (sv.on || bv.on)) {  // 悬停：只在有东西在放时换成按钮（待机时第二行的键名 / “未设置切换键”是可点的）
    std::wstring t = sv.on ? (s.sfx.name.empty() ? c.T(S_SFX) : s.sfx.name) : bv.on ? (s.bgm.name.empty() ? c.T(S_BGM) : s.bgm.name) : L"P1 " + c.T(S_HK);
    PxText(c, x1, y1, bh, clip(t, 11), 12, 0xFFD541, 0x07061A, true, maxW);
    int ids[3] = {PauseIdFor(c), H_STOP, H_OPEN}; float bx = x2;
    bool duckBtn = duck && (duckIsB ? bv.on : sv.on); if (duckBtn) ids[2] = duckIsB ? H_DUCK_B : H_DUCK_S;  // 闪避中：主面板换成“取消闪避”（暂停、急停不动）
    for (int i = 0; i < 3; i++) {
      bool hv = c.hoverId == ids[i];
      float by = 21.f * u;
      if (c.draw) {
        GraphicsState st = c.g->Save(); c.g->SetSmoothingMode(SmoothingModeNone);
        PxRect(c, bx - 1.f * u, by - 1.f * u, 16.f * u, 12.f * u, 0x07061A);
        PxRect(c, bx, by, 14.f * u, 10.f * u, i == 1 ? (hv ? 0xE0304D : 0xC2253F) : (hv ? 0x3F3B8A : 0x2D2A66));
        PxRect(c, bx, by + 9.f * u, 14.f * u, 1.f * u, i == 1 ? 0x7E1328 : 0x1A1840);
        unsigned ic = 0xFFFFFF; float ix = bx + 4.5f * u, iy = by + 2.5f * u;
        if (i == 0) { bool any = (sv.on && !sv.paused) || (bv.on && !bv.paused); if (any) { PxRect(c, ix, iy, 2.f * u, 5.f * u, ic); PxRect(c, ix + 3.f * u, iy, 2.f * u, 5.f * u, ic); } else { for (int q = 0; q < 5; q++) { int off = q > 2 ? q - 2 : 0; PxRect(c, ix + q * 1.f * u, iy + off * 1.f * u, 1.f * u, (5 - 2 * off) * 1.f * u, ic); } } }  // ▶：5 列高 5 5 5 3 1、上下居中（原来偏移被乘了 0，画成“◤”）
        else if (i == 1) PxRect(c, ix, iy, 5.f * u, 5.f * u, ic);
        else if (duckBtn) { static const char* dm[5] = {"..#..", "..#..", "#.#.#", ".###.", "..#.."}; for (int yy = 0; yy < 5; yy++) for (int xx = 0; xx < 5; xx++) if (dm[yy][xx] == '#') PxRect(c, ix + xx * 1.f * u, iy + yy * 1.f * u, 1.f * u, 1.f * u, 0xFF9F43); }  // 琥珀色向下箭头＝闪避（压低）；点它取消闪避（5×5 画不下喇叭）
        else { static const char* m[5] = {"#.###", "#..##", "#.#.#", "#....", "#####"}; for (int yy = 0; yy < 5; yy++) for (int xx = 0; xx < 5; xx++) if (m[yy][xx] == '#') PxRect(c, ix + xx * 1.f * u, iy + yy * 1.f * u, 1.f * u, 1.f * u, ic); }  // 打开主面板：框＋往右上的箭头（原来是空心方块）
        c.g->Restore(st);
      }
      c.hit(ids[i], bx, by, 14.f * u, 10.f * u);
      bx += 18.f * u;
    }
  } else {
    auto bar = [&](float p, unsigned a, unsigned b) {
      if (!c.draw) return; int n = 9, f = (int)roundf(n * p);
      GraphicsState st = c.g->Save(); c.g->SetSmoothingMode(SmoothingModeNone);
      for (int i = 0; i < n; i++) PxRect(c, x2 + i * 5.f * u, 24.5f * u, 4.f * u, 5.f * u, i < f ? (i == f - 1 ? b : a) : 0x2B2858);
      c.g->Restore(st);
    };
    float tx = x2 + 9 * 5.f * u + 3.f * u;
    if (duck && (duckIsB ? bv.on : sv.on)) {  // 1.3.0：闪避的那一路在放
      PxText(c, x1, y1, bh, c.T(duck == 2 ? S_VDUCK : S_DUCK) + L"!", 12, 0xFF9F43, 0x07061A, true, maxW);
      bar((duckIsB ? bv : sv).p, 0xFF9F43, 0xFFD541); PxText(c, tx, y2, bh, FmtMs((duckIsB ? bv : sv).remainMs, duckIsB, duckIsB), 12, 0xFFFFFF, 0x07061A, true, W - tx - 4.f * u);
      c.hit(duckIsB ? H_DUCK_B : H_DUCK_S, x1, 2.f * u, W - x1 - 14.f * u, 16.f * u);
    } else if (sv.on) {
      PxText(c, x1, y1, bh, clip(s.sfx.name.empty() ? c.T(S_SFX) : s.sfx.name, 11), 12, 0xFFD541, 0x07061A, true, maxW);
      bar(sv.p, 0xFF4F69, 0xFFD541); PxText(c, tx, y2, bh, FmtMs(sv.remainMs, false, false), 12, 0xFFFFFF, 0x07061A, true, W - tx - 4.f * u);
    } else if (bv.on) {
      PxText(c, x1, y1, bh, clip(L"BGM " + (s.bgm.name.empty() ? c.T(S_BGM) : s.bgm.name), 11), 12, 0x2CE8F5, 0x07061A, true, maxW);
      bar(bv.p, 0x2CE8F5, 0xB8FBFF); PxText(c, tx, y2, bh, FmtMs(bv.remainMs, true, true), 12, 0xFFFFFF, 0x07061A, true, W - tx - 4.f * u);
    } else {
      float w1 = PxText(c, x1, y1, bh, L"P1", 12, 0xFFD541, 0x07061A, true, 0);
      PxText(c, x1 + w1 + 8.f * u, y1, bh, on ? L"READY!" : L"SLEEP", 12, on ? 0x45F07A : 0x8C89B8, 0x07061A, true, 0);
      if (!s.key.empty()) {
        std::vector<unsigned char> m; int kw = 0, kh = 0; PixelTextMask(c.fonts->pixelFamily(), 10, s.key, m, kw, kh);
        int ink = 0; for (int yy = 0; yy < kh; yy++) for (int xx = 0; xx < kw; xx++) if (m[(size_t)yy * kw + xx] && xx + 1 > ink) ink = xx + 1;
        float chipW = (float)(ink * u) + 4.f * u;
        if (c.draw) {
          GraphicsState st = c.g->Save(); c.g->SetSmoothingMode(SmoothingModeNone);
          PxRect(c, x2 - 1.f * u, 21.f * u, chipW + 2.f * u, 12.f * u, 0x07061A);
          PxRect(c, x2, 22.f * u, chipW, 10.f * u, 0xFFD541); PxRect(c, x2, 31.f * u, chipW, 1.f * u, 0xC79A00);
          c.g->Restore(st);
        }
        PxText(c, x2 + 2.f * u, 22.f * u, 10.f * u, s.key, 10, 0x17153A, 0, false, 0);
        c.hit(H_KEY, x2 - 1.f * u, 21.f * u, chipW + 2.f * u, 12.f * u);
        std::wstring pre, post; Fmt1Parts(c.T(on ? S_TOGGLE : S_LIGHT), pre, post);
        std::wstring rest = post; while (!rest.empty() && (rest[0] == L' ' || rest[0] == L':')) rest.erase(0, 1);
        if (rest.empty()) rest = c.T(S_HK);
        PxText(c, x2 + chipW + 5.f * u, y2, bh, rest, 12, 0xC9C6F0, 0x07061A, true, W - (x2 + chipW + 5.f * u) - 4.f * u);
      } else {
        PxText(c, x2, y2, bh, c.T(S_UNSET), 12, 0x8C89B8, 0x07061A, true, maxW);
        c.hit(H_KEY, x2, 20.f * u, maxW, 12.f * u);
      }
    }
  }
  return SizeF(W, H);
}

// =================================================================================================
// 新增 9 款共用：这一帧显示什么（与灵动胶囊同一套优先级：小键盘提醒 > 闪避（背景音乐在放）> 播放中（音效优先）> 待机；悬停时第二行换成按钮）
struct View2 {
  bool on = true, warn = false, anyPlaying = false, isBgm = false, paused = false, duckIsB = false;
  int duck = 0, row = 0;  // row：0 键名＋说明 1 未设切换键 2 进度＋时间 3 闪避＋时间 4 小键盘“点此打开” 5 悬停按钮
  int base = 0;            // 悬停换成按钮之前的那一行（定宽时两种都量，悬停前后尺寸不变）
  int duckId = 0;          // 闪避中（第二行是闪避）时“取消闪避”的可点区域编号，否则 0
  int hid[3] = {H_PAUSE, H_STOP, H_OPEN};  // 悬停按钮：暂停 / 继续、急停、主面板；闪避时主面板换成“取消闪避”（暂停、急停不动；主面板双击、右键菜单都能打开）
  float p = 0;
  TrackView sv, bv; Now pn;
  std::wstring title, aux, tm;  // 标题；辅助字（按键说明 / 未设切换键 / 闪避中 / 点此打开）；时间（或“已暂停”）
};
static View2 Resolve(Ctx& c) {
  const XState& s = *c.s; View2 v;
  v.on = s.armed; v.warn = NumWarn(c);
  v.sv = ViewOf(s.sfx, c.now); v.bv = ViewOf(s.bgm, c.now); v.pn = Primary(c);
  v.duck = DuckOf(c, &v.duckIsB);
  v.anyPlaying = (v.sv.on && !v.sv.paused) || (v.bv.on && !v.bv.paused);
  if (v.warn) { v.row = 4; v.title = c.T(S_NUMLOCK); v.aux = c.T(S_NUMFIX); }
  else if (v.duck && (v.duckIsB ? v.bv.on : v.sv.on)) {  // 闪避的那一路在放（与灵动胶囊一样：哪一路在闪避就写哪一路）
    const TrackView& d = v.duckIsB ? v.bv : v.sv; const Track& t = v.duckIsB ? s.bgm : s.sfx;
    v.row = 3; v.isBgm = v.duckIsB; v.title = t.name.empty() ? c.T(v.duckIsB ? S_BGM : S_SFX) : t.name; v.aux = c.T(v.duck == 2 ? S_VDUCK : S_DUCK);
    v.tm = FmtMs(d.remainMs, v.duckIsB, v.duckIsB); v.p = d.p;
  } else if (v.pn.t) {
    v.row = 2; v.isBgm = v.pn.isBgm; v.title = v.pn.t->name.empty() ? c.T(v.isBgm ? S_BGM : S_SFX) : v.pn.t->name;
    v.paused = v.pn.v.paused; v.tm = v.paused ? c.T(S_PAUSED) : FmtMs(v.pn.v.remainMs, v.isBgm, v.isBgm); v.p = v.pn.v.p;
  } else {
    v.row = s.key.empty() ? 1 : 0; v.title = c.T(v.on ? S_HKON : S_HKOFF);
    if (v.row == 0) { std::wstring pre, post; Fmt1Parts(c.T(S_TOGGLE), pre, post); while (!post.empty() && (post[0] == L' ' || post[0] == L':')) post.erase(0, 1); v.aux = post; }
    else v.aux = c.T(S_UNSET);
  }
  // 悬停：只在播放（含暂停中）或闪避时把第二行换成按钮——待机时第二行是切换键（可点），悬停不能把它换掉，否则鼠标移过去点的时候它就不见了
  v.hid[0] = PauseIdFor(c);  // 1.3.0：暂停只作用于显示的那一路
  v.base = v.row;
  if (v.row == 3) v.duckId = v.duckIsB ? H_DUCK_B : H_DUCK_S;
  if (c.hover && (v.row == 2 || v.row == 3)) { if (v.row == 3) v.hid[2] = v.duckId; v.row = 5; }
  return v;
}
// 1.5.0：播放与暂停时第二行的时间那一格（“剩余时间”或“已暂停”）按两者里宽的定宽：暂停、继续前后悬浮窗不变宽变窄，悬停那一排按钮不挪。
// 原来这一格跟着字宽变：默认位置（屏幕右上角，锚点在右，内容变宽时向左长）下 16 款里 10 款会挪，泰语最多挪 102 像素；锚点在左时阿拉伯语有 7 款挪到
// 光标正好落在急停上——点了暂停接着在同一处点继续，会点空，甚至点成急停（实测见 README「暂停、继续时按钮不挪」）。只改量宽，画的字照旧
static float TmSlotW(Ctx& c, const View2& v, Font* fPaused, Font* fNum) {
  if (v.base != 2) return TextW(c, v.tm, v.paused ? fPaused : fNum);
  float a = TextW(c, c.T(S_PAUSED), fPaused), b = TextW(c, FmtMs(v.pn.v.remainMs, v.isBgm, v.isBgm), fNum);
  return a > b ? a : b;
}
static void IconKind(Ctx& c, int id, float cx, float cy, float s, const Color& col, bool playing) {  // 按可点区域画图标
  if (id == H_PAUSE || id == H_BTOGGLE || id == H_STOGGLE) { if (playing) IconPause(c, cx, cy, s, col); else IconPlay(c, cx, cy, s, col); }
  else if (id == H_DUCK_S || id == H_DUCK_B) IconDuck(c, cx, cy, s, col);
  else if (id == H_STOP) IconStop(c, cx, cy, s, col);
  else if (id == H_OPEN) IconOpen(c, cx, cy, s, col);
  else if (id == H_BPREV) IconPrev(c, cx, cy, s, col);
  else IconNext(c, cx, cy, s, col);
}
static unsigned Mix(unsigned a, unsigned b, float t) {
  auto ch = [&](int sh) { float x = ((a >> sh) & 255) * (1 - t) + ((b >> sh) & 255) * t; return (unsigned)(x < 0 ? 0 : x > 255 ? 255 : x + .5f) << sh; };
  return ch(16) | ch(8) | ch(0);
}
// 平铺的小图案（拼贴手账的点阵格、漫画的网点）：做一块边长 cell 的小图、用纹理画刷一次填满，不逐点画（逐点画一帧要多 7～8 毫秒）
static void TileDots(Ctx& c, GraphicsPath& clip, float cell, float r, unsigned rgb, int alpha, bool offsetRows) {
  if (!c.draw) return;
  int n = (int)roundf(cell); if (n < 4) n = 4;
  int th = offsetRows ? 2 * n : n;
  Bitmap tile(n, th, PixelFormat32bppPARGB);
  { Graphics g(&tile); g.Clear(Color(0, 0, 0, 0)); g.SetSmoothingMode(SmoothingModeAntiAlias); g.SetPixelOffsetMode(PixelOffsetModeHalf);
    SolidBrush b(C(rgb, alpha)); g.FillEllipse(&b, n / 2.f - r, n / 2.f - r, 2 * r, 2 * r);
    if (offsetRows) { g.FillEllipse(&b, -r, n + n / 2.f - r, 2 * r, 2 * r); g.FillEllipse(&b, n - r, n + n / 2.f - r, 2 * r, 2 * r); } }
  TextureBrush tb(&tile, WrapModeTile);
  SmoothingMode sm = c.g->GetSmoothingMode(); c.g->SetSmoothingMode(SmoothingModeNone);  // 只在已经抗锯齿填好的底面里面铺：边缘不用再抗锯齿（抗锯齿的纹理填充每次要 1 毫秒多）
  c.g->FillPath(&tb, &clip); c.g->SetSmoothingMode(sm);
}
static void Grain(Ctx& c, GraphicsPath& clip, unsigned rgb, int maxA) {  // 纸纹：64×64 固定噪点平铺（截图可复现）
  if (!c.draw) return;
  static unsigned char nz[64 * 64]; static bool made = false;
  if (!made) { unsigned v = 0x9E3779B9u; for (int i = 0; i < 64 * 64; i++) { v ^= v << 13; v ^= v >> 17; v ^= v << 5; nz[i] = (unsigned char)(v >> 24); } made = true; }
  Bitmap nb(64, 64, PixelFormat32bppPARGB); BitmapData bd; Rect rr(0, 0, 64, 64);
  if (nb.LockBits(&rr, ImageLockModeWrite, PixelFormat32bppPARGB, &bd) != Ok) return;
  for (int y = 0; y < 64; y++) { unsigned* row = (unsigned*)((BYTE*)bd.Scan0 + y * bd.Stride); for (int x = 0; x < 64; x++) { unsigned a = nz[y * 64 + x] * (unsigned)maxA / 255; row[x] = (a << 24) | ((((rgb >> 16) & 255) * a / 255) << 16) | ((((rgb >> 8) & 255) * a / 255) << 8) | ((rgb & 255) * a / 255); } }
  nb.UnlockBits(&bd); TextureBrush tb(&nb, WrapModeTile);
  SmoothingMode sm = c.g->GetSmoothingMode(); c.g->SetSmoothingMode(SmoothingModeNone); c.g->FillPath(&tb, &clip); c.g->SetSmoothingMode(sm);
}
static void LineProgress(Ctx& c, float x, float cy, float w, float h, float p, const Color& track, const Color& a, const Color& b) {  // 圆头进度条
  if (!c.draw) return;
  SolidBrush tb(track); FillRR(c, x, cy - h / 2, w, h, h / 2, tb);
  if (p > 0) { float fw = w * (p > 1 ? 1 : p); if (fw < h) fw = h; LinearGradientBrush fb(PointF(x, 0), PointF(x + w, 0), a, b); FillRR(c, x, cy - h / 2, fw, h, h / 2, fb); }
}

// =================================================================================================
// 机械键帽（SK_KEYCAP）：一排键帽——左边是开关键（小红花图例＋指示灯），中间是切换键本身（键帽上印着键名），右边是键盘上的小屏
// （曲名、进度、倒计时）；底板下沿一条 RGB 灯带，关闭时变灰。悬停时小屏里换成三个小键帽：暂停、急停、主面板
static void KcCap(Ctx& c, float x, float y, float w, float h, unsigned top, unsigned side, bool hot) {
  if (!c.draw) return; float k = c.k;
  SolidBrush sb(C(side)); FillRR(c, x, y, w, h, 7 * k, sb);
  float d = hot ? 1 * k : 0;  // 指着时顶面下沉一点
  LinearGradientBrush tb(PointF(0, y + 2 * k + d), PointF(0, y + h - 6 * k + d), C(Mix(top, 0xFFFFFF, .10f)), C(top));
  FillRR(c, x + 3 * k, y + 2 * k + d, w - 6 * k, h - 8 * k, 5 * k, tb);
}
static void KcPlate(Ctx& c, float w, float h, bool on) {
  if (!c.draw) return; float k = c.k;
  GraphicsPath p; RoundRectPath(p, 0, 0, w, h, 12 * k);
  LinearGradientBrush bg(PointF(0, 0), PointF(0, h), C(0x272932), C(0x15161B)); c.g->FillPath(&bg, &p);
  StrokeRR(c, 0, 0, w, h, 12 * k, C(0xFFFFFF, 22), 1 * k);
  Pen hl(C(0xFFFFFF, 30), 1 * k); c.g->DrawLine(&hl, 12 * k, 1.2f * k, w - 12 * k, 1.2f * k);
  float sx = 12 * k, sw = w - 24 * k, sy = h - 4.5f * k;  // RGB 灯带
  if (on) {
    LinearGradientBrush gb(PointF(sx, 0), PointF(sx + sw, 0), C(0xFF5F6D), C(0xB57BFF));
    Color cs[5] = {C(0xFF5F6D, 230), C(0xFFC371, 230), C(0x47E5BC, 230), C(0x4DA8FF, 230), C(0xB57BFF, 230)}; REAL ps[5] = {0, .25f, .5f, .75f, 1}; gb.SetInterpolationColors(cs, ps, 5);
    FillRR(c, sx, sy, sw, 2.5f * k, 1.25f * k, gb);
  } else { SolidBrush gb(C(0x4A4C55)); FillRR(c, sx, sy, sw, 2.5f * k, 1.25f * k, gb); }
}
static SizeF SkinKeycap(Ctx& c) {
  const XState& s = *c.s; float k = c.k; View2 v = Resolve(c);
  unsigned led = v.warn ? 0xFFB547 : v.on ? 0x3BE07A : 0x5A5D66;
  auto capA = [&](float x, float y) {
    if (c.draw) {
      KcCap(c, x, y, 40 * k, 40 * k, v.on ? 0xF1F2F5 : 0x4A4D57, v.on ? 0xA9ACB6 : 0x2C2E36, c.hoverId == H_SWITCH);
      Flower(c, x + 20 * k, y + 17 * k + (c.hoverId == H_SWITCH ? 1 * k : 0), 18 * k, !v.on);
      if (v.on || v.warn) { SolidBrush gl(C(led, 70)); c.g->FillEllipse(&gl, x + 27.5f * k, y + 3.5f * k, 8 * k, 8 * k); }
      SolidBrush lb(C(led)); c.g->FillEllipse(&lb, x + 29 * k, y + 5 * k, 5 * k, 5 * k);
    }
    c.hit(H_SWITCH, x, y, 40 * k, 40 * k);
  };
  if (c.docked) { float w = 56 * k, h = w; KcPlate(c, w, h, v.on); capA(8 * k, 7 * k); return SizeF(w, h); }
  bool un = s.key.empty(); Font* kf = c.fonts->num(13 * k, true);
  float kw = un ? 40 * k : TextW(c, s.key, kf) + 22 * k; if (kw < 40 * k) kw = 40 * k; if (kw > 96 * k) kw = 96 * k;
  Font* f1 = (v.base == 2 || v.base == 3) ? c.fonts->name(v.title, 12 * k, true) : c.fonts->ui(12 * k, true);
  Font* f2 = c.fonts->ui(10.5f * k, false); Font* f2b = c.fonts->ui(10.5f * k, true); Font* fn = c.fonts->num(11 * k, true);
  Font* ft = v.paused ? f2 : fn;
  float t1w = TextW(c, v.title, f1); if (t1w > 150 * k) t1w = 150 * k;
  auto rw = [&](int row) -> float { return row == 0 || row == 1 ? TextW(c, v.aux, f2) : row == 2 ? 64 * k + 8 * k + TmSlotW(c, v, f2, fn) : row == 3 ? TextW(c, v.aux, f2b) + 8 * k + TextW(c, v.tm, fn) : row == 4 ? TextW(c, v.aux, f2b) : 3 * 30 * k + 2 * 6 * k; };
  float r2w = rw(v.row); if (v.base == 2 || v.base == 3) { float a = rw(v.base), b = rw(5); r2w = a > b ? a : b; }  // 播放 / 闪避时悬停前后两种第二行取宽的：悬停时尺寸不变
  float ow = (t1w > r2w ? t1w : r2w) + 20 * k; if (ow < 132 * k) ow = 132 * k;
  float kx = 54 * k, ox = kx + kw + 6 * k, W = ox + ow + 8 * k, H = 56 * k;
  KcPlate(c, W, H, v.on);
  capA(8 * k, 7 * k);
  if (c.draw) {
    if (un) { StrokeRR(c, kx + 1 * k, 8 * k, kw - 2 * k, 38 * k, 7 * k, C(0x8C8F9A, c.hoverId == H_KEY ? 255 : 170), 1.2f * k, true); IconPlus(c, kx + kw / 2, 25 * k, 10 * k, C(0xC9CBD3), 1.8f * k); }
    else { KcCap(c, kx, 7 * k, kw, 40 * k, 0x34363F, 0x1E1F25, c.hoverId == H_KEY); Text(c, s.key, kf, C(0xFFFFFF), kx + 3 * k, 9 * k + (c.hoverId == H_KEY ? 1 * k : 0), kw - 6 * k, 28 * k, 11, true); }
  }
  c.hit(H_KEY, kx, 7 * k, kw, 40 * k);
  if (c.draw) { SolidBrush ob(C(0x0B0C0F)); FillRR(c, ox, 7 * k, ow, 40 * k, 6 * k, ob); StrokeRR(c, ox, 7 * k, ow, 40 * k, 6 * k, C(0xFFFFFF, 16), 1 * k); }
  float tx = ox + 10 * k, tw = ow - 20 * k, cy2 = 35.5f * k;
  if (c.draw) Text(c, v.title, f1, v.warn ? C(0xFFB547) : v.on ? C(0xFFFFFF) : C(0xA9ADB8), tx, 9 * k, tw, 17 * k, 0, true);
  if (v.row == 0 || v.row == 1) { if (c.draw) Text(c, v.aux, f2, C(0xA9ADB8), tx, cy2 - 8 * k, tw, 16 * k, 0, true); }
  else if (v.row == 2) {
    LineProgress(c, tx, cy2, 64 * k, 3 * k, v.p, C(0x2A2D35), v.isBgm ? C(0x5CE1E6) : C(0xFF7AA2), v.isBgm ? C(0x4DA8FF) : C(0xFFB547));
    if (c.draw) Text(c, v.tm, ft, v.paused ? C(0xA9ADB8) : C(0xFFFFFF), tx + 72 * k, cy2 - 8 * k, tw - 72 * k, 16 * k, v.paused ? 0 : 10, false);
  } else if (v.row == 3) {
    float aw = TextW(c, v.aux, f2b);
    if (c.draw) { IconDuck(c, tx + 5 * k, cy2, 10 * k, C(0xFFB547)); Text(c, v.aux, f2b, C(0xFFB547), tx + 12 * k, cy2 - 8 * k, aw + 2 * k, 16 * k, 0, false); Text(c, v.tm, fn, C(0xFFFFFF), tx + 12 * k + aw + 8 * k, cy2 - 8 * k, tw - 20 * k - aw, 16 * k, 10, false); }
    c.hit(v.duckIsB ? H_DUCK_B : H_DUCK_S, ox, 7 * k, ow, 40 * k);
  } else if (v.row == 4) {
    if (c.draw) { float aw = TextW(c, v.aux, f2b); Text(c, v.aux, f2b, C(c.hoverId == H_NUMFIX ? 0xFFE3A3 : 0xFFD27A), tx, cy2 - 8 * k, aw + 2 * k, 16 * k, 0, false);
      Pen ul(C(0xFFD27A), 1 * k); c.g->DrawLine(&ul, tx, cy2 + 7 * k, tx + aw, cy2 + 7 * k); }
    c.hit(H_NUMFIX, ox, 7 * k, ow, 40 * k);
  } else {
    float bx = tx;
    for (int i = 0; i < 3; i++) {
      bool hv = c.hoverId == v.hid[i];
      if (c.draw) { KcCap(c, bx, 24 * k, 30 * k, 22 * k, i == 1 ? 0xE5484D : 0x3A3C46, i == 1 ? 0x9E2A2F : 0x23242B, hv); IconKind(c, v.hid[i], bx + 15 * k, 32 * k + (hv ? 1 * k : 0), 10 * k, C(0xFFFFFF), v.anyPlaying); }
      c.hit(v.hid[i], bx, 23 * k, 30 * k, 24 * k);
      bx += 36 * k;
    }
  }
  return SizeF(W, H);
}

// =================================================================================================
// 极光弥散（SK_AURORA）：深夜蓝的胶囊里几团柔光（紫、青、粉、蓝）；放着东西时光斑缓慢流动（每秒 8 帧，系统关闭动画时静止）。
// 光斑都压得很淡、文字后面再垫一层暗纱：白字在最亮处也有 4.5 以上
static void AuroraBg(Ctx& c, GraphicsPath& p, float W, float H, bool on, bool moving) {
  if (!c.draw) return; float k = c.k;
  SolidBrush base(C(on ? 0x12143A : 0x1D1E2A)); c.g->FillPath(&base, &p);
  GraphicsState st = c.g->Save(); Region rg(&p); c.g->SetClip(&rg, CombineModeIntersect);
  float t = moving ? (float)(c.now % 600000u) / 1000.f : 0.f;
  struct B { float x, y, r, sp, ph; unsigned col; } bl[4] = {{.12f, .25f, .55f, .50f, 0.f, 0x7C5CFF}, {.45f, .95f, .60f, .37f, 1.7f, 0x2DD4BF}, {.75f, .10f, .55f, .43f, 3.1f, 0xFF5FA2}, {.95f, .80f, .50f, .31f, 4.4f, 0x4DA8FF}};
  for (auto& b : bl) {
    float cx = W * (b.x + .06f * sinf(t * b.sp + b.ph)), cy = H * (b.y + .18f * cosf(t * b.sp * .8f + b.ph)), r = H * b.r + W * .08f;
    GraphicsPath gp; gp.AddEllipse(cx - r, cy - r * .8f, 2 * r, 1.6f * r);
    PathGradientBrush gb(&gp); gb.SetCenterColor(on ? C(b.col, 92) : C(0x6B6F80, 60)); Color sc = C(b.col, 0); INT n = 1; gb.SetSurroundColors(&sc, &n);
    c.g->FillPath(&gb, &gp);
  }
  LinearGradientBrush sh(PointF(0, 0), PointF(0, H), C(0xFFFFFF, 26), C(0xFFFFFF, 0)); c.g->FillRectangle(&sh, 0.f, 0.f, W, H * .5f);
  c.g->Restore(st);
  GraphicsPath ip; RoundRectPath(ip, .5f * k, .5f * k, W - 1 * k, H - 1 * k, H / 2 - .5f * k);
  LinearGradientBrush eg(PointF(0, 0), PointF(0, H), C(0xFFFFFF, 70), C(0xFFFFFF, 14)); Pen ep(&eg, 1 * k); c.g->DrawPath(&ep, &ip);
}
static SizeF SkinAurora(Ctx& c) {
  const XState& s = *c.s; float k = c.k; View2 v = Resolve(c);
  bool moving = v.anyPlaying && c.anim;
  if (c.docked) {
    float h = 30 * k; Font* fn = c.fonts->num(11 * k, true);
    std::wstring t = (v.pn.t && !v.paused) ? FmtMs(v.pn.v.remainMs, v.pn.isBgm, v.pn.isBgm) : L"";
    float w = 34 * k + (t.empty() ? 0 : TextW(c, t, fn) + 10 * k);
    GraphicsPath p; if (c.dockEdge == 3) RoundRectPath4(p, 0, 0, w, h, 0, 0, h / 2, h / 2); else RoundRectPath(p, 0, 0, w, h, h / 2);
    AuroraBg(c, p, w, h, v.on, moving);
    if (c.draw) { FlowerMono(c, 16 * k, h / 2, 16 * k, v.on ? C(0xFFFFFF) : C(0x9A9CA8), v.on ? C(0xFFD54D) : C(0x6E6E78)); if (!t.empty()) Text(c, t, fn, C(0xFFFFFF), 30 * k, 0, w - 34 * k, h, 10, false); }
    c.hit(H_SWITCH, 0, 0, w, h);
    return SizeF(w, h);
  }
  Font* f1 = (v.base == 2 || v.base == 3) ? c.fonts->name(v.title, 13 * k, true) : c.fonts->ui(13 * k, true);
  Font* f2 = c.fonts->ui(11 * k, false); Font* f2b = c.fonts->ui(11 * k, true); Font* fn = c.fonts->num(11 * k, true); Font* kf = c.fonts->num(10.5f * k, true);
  Font* ft = v.paused ? f2 : fn;
  float kw = (v.row == 0) ? TextW(c, s.key, kf) + 12 * k : 0;
  float t1w = TextW(c, v.title, f1); if (t1w > 160 * k) t1w = 160 * k;
  auto rw = [&](int row) -> float { return row == 0 ? kw + 6 * k + TextW(c, v.aux, f2) : row == 1 ? TextW(c, v.aux, f2) + 14 * k : row == 2 ? 60 * k + 8 * k + TmSlotW(c, v, f2, fn) : row == 3 ? TextW(c, v.aux, f2b) + 18 * k + 8 * k + TextW(c, v.tm, fn) : row == 4 ? TextW(c, v.aux, f2b) + 4 * k : 3 * 26 * k + 2 * 8 * k; };
  float r2w = rw(v.row); if (v.base == 2 || v.base == 3) { float a = rw(v.base), b = rw(5); r2w = a > b ? a : b; }  // 播放 / 闪避时悬停前后两种第二行取宽的：悬停时尺寸不变
  float colW = t1w > r2w ? t1w : r2w; if (colW < 116 * k) colW = 116 * k;
  float x0 = 54 * k, W = x0 + colW + 12 * k + 34 * k + 14 * k, H = 54 * k;
  GraphicsPath p; RoundRectPath(p, 0, 0, W, H, H / 2);
  AuroraBg(c, p, W, H, v.on, moving);
  if (c.draw) {
    LinearGradientBrush sc(PointF(x0 - 8 * k, 0), PointF(x0 + colW, 0), C(0x0A0B22, 110), C(0x0A0B22, 70)); FillRR(c, x0 - 8 * k, 6 * k, colW + 16 * k, H - 12 * k, 10 * k, sc);  // 文字后面的暗纱
    SolidBrush cb(C(0xFFFFFF, v.on ? 34 : 18)); c.g->FillEllipse(&cb, 9 * k, 9 * k, 36 * k, 36 * k);
    Pen cp(C(0xFFFFFF, c.hoverId == H_SWITCH ? 150 : 70), 1 * k); c.g->DrawEllipse(&cp, 9 * k, 9 * k, 36 * k, 36 * k);
    FlowerMono(c, 27 * k, 27 * k, 22 * k, v.on ? C(0xFFFFFF) : C(0x9A9CA8), v.on ? C(0xFFD54D) : C(0x6E6E78));
    if (v.warn) { SolidBrush wb(C(0xFFB547)); c.g->FillEllipse(&wb, 35 * k, 8 * k, 11 * k, 11 * k); }
    Text(c, v.title, f1, v.warn ? C(0xFFD27A) : v.on ? C(0xFFFFFF) : C(0xC9CBD8), x0, 9 * k, colW, 19 * k, 0, true);
  }
  c.hit(H_SWITCH, 9 * k, 9 * k, 36 * k, 36 * k);
  float cy2 = 38 * k;
  if (v.row == 0) {
    if (c.draw) { SolidBrush kb(C(0xFFFFFF, c.hoverId == H_KEY ? 60 : 34)); FillRR(c, x0, cy2 - 8.5f * k, kw, 17 * k, 6 * k, kb); Text(c, s.key, kf, C(0xFFFFFF), x0, cy2 - 8.5f * k, kw, 17 * k, 11, false);
      Text(c, v.aux, f2, C(0xE4E3F5), x0 + kw + 6 * k, cy2 - 8 * k, colW - kw - 6 * k, 16 * k, 0, true); }
    c.hit(H_KEY, x0, cy2 - 8.5f * k, kw, 17 * k);
  } else if (v.row == 1) {
    float w = TextW(c, v.aux, f2) + 14 * k;
    if (c.draw) { StrokeRR(c, x0, cy2 - 8.5f * k, w, 17 * k, 6 * k, C(0xFFFFFF, c.hoverId == H_KEY ? 200 : 120), 1 * k, true); Text(c, v.aux, f2, C(0xE4E3F5), x0, cy2 - 8.5f * k, w, 17 * k, 1, false); }
    c.hit(H_KEY, x0, cy2 - 8.5f * k, w, 17 * k);
  } else if (v.row == 2) {
    LineProgress(c, x0, cy2, 60 * k, 3 * k, v.p, C(0xFFFFFF, 46), C(0xFFFFFF), v.isBgm ? C(0x7CF5D5) : C(0xFFC2DD));
    if (c.draw) Text(c, v.tm, ft, v.paused ? C(0xE4E3F5) : C(0xFFFFFF), x0 + 68 * k, cy2 - 8 * k, colW - 68 * k, 16 * k, v.paused ? 0 : 10, false);
  } else if (v.row == 3) {
    float aw = TextW(c, v.aux, f2b) + 18 * k;
    if (c.draw) { SolidBrush db(C(0xFFC15A, 46)); FillRR(c, x0, cy2 - 9 * k, aw, 18 * k, 9 * k, db); IconDuck(c, x0 + 9 * k, cy2, 10 * k, C(0xFFD27A));
      Text(c, v.aux, f2b, C(0xFFD27A), x0 + 16 * k, cy2 - 9 * k, aw - 16 * k, 18 * k, 0, false); Text(c, v.tm, fn, C(0xFFFFFF), x0 + aw + 8 * k, cy2 - 8 * k, colW - aw - 8 * k, 16 * k, 10, false); }
    c.hit(v.duckIsB ? H_DUCK_B : H_DUCK_S, x0 - 4 * k, cy2 - 12 * k, colW + 8 * k, 24 * k);
  } else if (v.row == 4) {
    float aw = TextW(c, v.aux, f2b);
    if (c.draw) { Text(c, v.aux, f2b, C(c.hoverId == H_NUMFIX ? 0xFFE7B0 : 0xFFD27A), x0, cy2 - 8 * k, aw + 4 * k, 16 * k, 0, false); Pen ul(C(0xFFD27A), 1 * k); c.g->DrawLine(&ul, x0, cy2 + 7 * k, x0 + aw, cy2 + 7 * k); }
    c.hit(H_NUMFIX, x0 - 2 * k, cy2 - 12 * k, aw + 8 * k, 24 * k);
  } else {
    float bx = x0;
    for (int i = 0; i < 3; i++) {
      bool hv = c.hoverId == v.hid[i];
      if (c.draw) { SolidBrush b(i == 1 ? C(0xFF4D6D, hv ? 230 : 190) : C(0xFFFFFF, hv ? 70 : 40)); c.g->FillEllipse(&b, bx, cy2 - 13 * k, 26 * k, 26 * k); IconKind(c, v.hid[i], bx + 13 * k, cy2, 12 * k, C(0xFFFFFF), v.anyPlaying); }
      c.hit(v.hid[i], bx, cy2 - 13 * k, 26 * k, 26 * k);
      bx += 34 * k;
    }
  }
  Switch(c, W - 14 * k - 34 * k, H / 2, 34 * k, 20 * k, v.on, 0x7C5CFF, 0x2DD4BF, 0x3B3D52, 255, H_SWITCH);
  return SizeF(W, H);
}

// =================================================================================================
// 赛博机甲（SK_CYBER）：黑底斜切角面板，赛博黄描边与分段进度条，左边是六角框里的小红花（开关；关闭时换成警示斜纹）；
// 切换键是黄底黑字的标签，按钮是平行四边形。字都在纯黑底上：黄 17、青 15、白 19
static void CyPanel(Ctx& c, float W, float H, bool on, float cut) {
  if (!c.draw) return; float k = c.k;
  PointF pts[6] = {PointF(cut, 0), PointF(W, 0), PointF(W, H - cut), PointF(W - cut, H), PointF(0, H), PointF(0, cut)};
  GraphicsPath p; p.AddPolygon(pts, 6);
  SolidBrush b(C(0x0B0D10)); c.g->FillPath(&b, &p);
  { GraphicsState st = c.g->Save(); Region rg(&p); c.g->SetClip(&rg, CombineModeIntersect);  // 很淡的扫描线
    Pen sl(C(0xFFFFFF, 7), 1 * k); for (float y = 2 * k; y < H; y += 3 * k) c.g->DrawLine(&sl, 0.f, y, W, y);
    c.g->Restore(st); }
  Pen bd(C(0x2C3036), 1 * k); c.g->DrawPolygon(&bd, pts, 6);
  Pen ac(C(on ? 0xFCEE0A : 0x6A6E73), 2 * k); ac.SetStartCap(LineCapSquare); ac.SetEndCap(LineCapSquare);
  c.g->DrawLine(&ac, 0.f, cut + 10 * k, 0.f, cut); c.g->DrawLine(&ac, 0.f, cut, cut, 0.f); c.g->DrawLine(&ac, cut, 0.f, cut + 26 * k, 0.f);
  c.g->DrawLine(&ac, W, H - cut - 10 * k, W, H - cut); c.g->DrawLine(&ac, W, H - cut, W - cut, H); c.g->DrawLine(&ac, W - cut, H, W - cut - 26 * k, H);
}
static void CyHex(Ctx& c, float cx, float cy, float r, bool on, bool warn, bool hot) {
  if (!c.draw) return; float k = c.k;
  PointF hx[6]; for (int i = 0; i < 6; i++) { float a = (60.f * i - 90.f) * 3.14159265f / 180.f; hx[i] = PointF(cx + cosf(a) * r, cy + sinf(a) * r); }
  GraphicsPath hp; hp.AddPolygon(hx, 6);
  if (!on) {  // 关闭：黄黑警示斜纹（压暗）
    GraphicsState st = c.g->Save(); Region rg(&hp); c.g->SetClip(&rg, CombineModeIntersect);
    SolidBrush bb(C(0x15171A)); c.g->FillPath(&bb, &hp);
    Pen sp(C(0x5E5A1E), 3 * k); for (float x = cx - 2 * r; x < cx + 2 * r; x += 7 * k) c.g->DrawLine(&sp, x, cy + r, x + 2 * r, cy - r);
    c.g->Restore(st);
  } else { SolidBrush hb(C(warn ? 0x3A1D10 : 0x1A1C10)); c.g->FillPath(&hb, &hp); }
  Pen hpn(C(warn ? 0xFF9F1C : on ? 0xFCEE0A : 0x6A6E73, hot ? 255 : 220), 1.6f * k); c.g->DrawPath(&hpn, &hp);
  FlowerMono(c, cx, cy, r * 1.15f, on ? C(0xFCEE0A) : C(0x7C8086), on ? C(0x0B0D10) : C(0x2A2D31));
}
static void CySkewBtn(Ctx& c, float x, float y, float w, float h, unsigned fill, unsigned line) {
  if (!c.draw) return; float s = 5 * c.k;
  PointF pts[4] = {PointF(x + s, y), PointF(x + w, y), PointF(x + w - s, y + h), PointF(x, y + h)};
  SolidBrush b(C(fill)); c.g->FillPolygon(&b, pts, 4); Pen p(C(line), 1 * c.k); c.g->DrawPolygon(&p, pts, 4);
}
static SizeF SkinCyber(Ctx& c) {
  const XState& s = *c.s; float k = c.k; View2 v = Resolve(c);
  if (c.docked) { float w = 52 * k, h = w; CyPanel(c, w, h, v.on, 9 * k); CyHex(c, w / 2, h / 2, 18 * k, v.on, v.warn, false); c.hit(H_SWITCH, 0, 0, w, h); return SizeF(w, h); }
  Font* f1 = (v.base == 2 || v.base == 3) ? c.fonts->name(v.title, 13 * k, true) : c.fonts->ui(13 * k, true);
  Font* f2 = c.fonts->ui(10.5f * k, false); Font* f2b = c.fonts->ui(10.5f * k, true); Font* fn = c.fonts->num(12 * k, true); Font* kf = c.fonts->num(11 * k, true);
  Font* ft = v.paused ? f2 : fn;
  float kw = v.row == 0 ? TextW(c, s.key, kf) + 14 * k : 0;
  float t1w = TextW(c, v.title, f1); if (t1w > 160 * k) t1w = 160 * k;
  int nseg = 12; float segW = 5 * k, segG = 2 * k, barW = nseg * segW + (nseg - 1) * segG;
  auto rw = [&](int row) -> float { return row == 0 ? kw + 6 * k + TextW(c, v.aux, f2) : row == 1 ? TextW(c, v.aux, f2) + 14 * k : row == 2 ? barW + 8 * k + TmSlotW(c, v, f2, fn) : row == 3 ? TextW(c, v.aux, f2b) + 14 * k + 8 * k + TextW(c, v.tm, fn) : row == 4 ? TextW(c, v.aux, f2b) + 4 * k : 3 * 34 * k + 2 * 6 * k; };
  float r2w = rw(v.row); if (v.base == 2 || v.base == 3) { float a = rw(v.base), b = rw(5); r2w = a > b ? a : b; }  // 播放 / 闪避时悬停前后两种第二行取宽的：悬停时尺寸不变
  float colW = t1w > r2w ? t1w : r2w; if (colW < 120 * k) colW = 120 * k;
  float x0 = 58 * k, W = x0 + colW + 16 * k, H = 58 * k, cut = 10 * k;
  CyPanel(c, W, H, v.on, cut);
  CyHex(c, 29 * k, 29 * k, 19 * k, v.on, v.warn, c.hoverId == H_SWITCH);
  c.hit(H_SWITCH, 8 * k, 8 * k, 42 * k, 42 * k);
  if (c.draw) {
    Pen dv(C(0x2C3036), 1 * k); c.g->DrawLine(&dv, 54 * k, 12 * k, 54 * k, H - 12 * k);
    Text(c, v.title, f1, v.warn ? C(0xFF6B81) : v.on ? C(0xF2F4F5) : C(0x98A0A6), x0, 9 * k, colW, 19 * k, 0, true);
  }
  float cy2 = 39 * k;
  if (v.row == 0) {
    if (c.draw) { SolidBrush kb(C(c.hoverId == H_KEY ? 0xFFF56B : 0xFCEE0A)); c.g->FillRectangle(&kb, x0, cy2 - 8.5f * k, kw, 17 * k); Text(c, s.key, kf, C(0x0B0D10), x0, cy2 - 8.5f * k, kw, 17 * k, 11, false);
      Text(c, v.aux, f2, C(0x98A0A6), x0 + kw + 6 * k, cy2 - 8 * k, colW - kw - 6 * k, 16 * k, 0, true); }
    c.hit(H_KEY, x0, cy2 - 8.5f * k, kw, 17 * k);
  } else if (v.row == 1) {
    float w = TextW(c, v.aux, f2) + 14 * k;
    if (c.draw) { Pen dp(C(0xFCEE0A, c.hoverId == H_KEY ? 255 : 170), 1 * k); dp.SetDashStyle(DashStyleDash); c.g->DrawRectangle(&dp, x0 + .5f * k, cy2 - 8 * k, w - 1 * k, 16 * k); Text(c, v.aux, f2, C(0xFCEE0A), x0, cy2 - 8.5f * k, w, 17 * k, 1, false); }
    c.hit(H_KEY, x0, cy2 - 8.5f * k, w, 17 * k);
  } else if (v.row == 2) {
    if (c.draw) { int f = (int)roundf(v.p * nseg); unsigned on1 = v.isBgm ? 0x00F0FF : 0xFCEE0A;
      for (int i = 0; i < nseg; i++) { SolidBrush b(C(i < f ? on1 : 0x23272C)); c.g->FillRectangle(&b, x0 + i * (segW + segG), cy2 - 4 * k, segW, 8 * k); }
      Text(c, v.tm, ft, v.paused ? C(0x98A0A6) : C(0xFCEE0A), x0 + barW + 8 * k, cy2 - 9 * k, colW - barW - 8 * k, 18 * k, v.paused ? 0 : 10, false); }
  } else if (v.row == 3) {
    float aw = TextW(c, v.aux, f2b) + 14 * k;
    if (c.draw) { SolidBrush db(C(0xFF9F1C)); c.g->FillRectangle(&db, x0, cy2 - 8.5f * k, aw, 17 * k); Text(c, v.aux, f2b, C(0x0B0D10), x0, cy2 - 8.5f * k, aw, 17 * k, 1, false);
      Text(c, v.tm, fn, C(0xFCEE0A), x0 + aw + 8 * k, cy2 - 9 * k, colW - aw - 8 * k, 18 * k, 10, false); }
    c.hit(v.duckIsB ? H_DUCK_B : H_DUCK_S, x0 - 2 * k, cy2 - 12 * k, colW + 4 * k, 24 * k);
  } else if (v.row == 4) {
    float aw = TextW(c, v.aux, f2b);
    if (c.draw) { Text(c, v.aux, f2b, C(c.hoverId == H_NUMFIX ? 0xFFF56B : 0xFCEE0A), x0, cy2 - 8 * k, aw + 4 * k, 16 * k, 0, false); Pen ul(C(0xFCEE0A), 1 * k); c.g->DrawLine(&ul, x0, cy2 + 7 * k, x0 + aw, cy2 + 7 * k); }
    c.hit(H_NUMFIX, x0 - 2 * k, cy2 - 12 * k, aw + 8 * k, 24 * k);
  } else {
    float bx = x0;
    for (int i = 0; i < 3; i++) {
      bool hv = c.hoverId == v.hid[i];
      CySkewBtn(c, bx, cy2 - 12 * k, 34 * k, 24 * k, i == 1 ? (hv ? 0xFF4D6A : 0xD7263D) : (hv ? 0x30343A : 0x1C1F23), i == 1 ? 0xFF7A8C : 0xFCEE0A);
      IconKind(c, v.hid[i], bx + 17 * k, cy2, 11 * k, i == 1 ? C(0xFFFFFF) : C(0xFCEE0A), v.anyPlaying);
      c.hit(v.hid[i], bx, cy2 - 12 * k, 34 * k, 24 * k);
      bx += 40 * k;
    }
  }
  return SizeF(W, H);
}

// =================================================================================================
// 多巴胺撞色（SK_POP，新粗野主义）：粗黑描边、实心硬投影、糖果撞色色块；按钮按下（指着）时投影收回、整块下沉。黑字在黄、粉、蓝、绿上都在 7 以上
static void PopBox(Ctx& c, float x, float y, float w, float h, unsigned fill, float r, float sh, bool pressed, bool dash = false) {
  if (!c.draw) return; float k = c.k, d = pressed ? sh : 0;
  if (sh > 0 && !pressed) { SolidBrush sb(C(0x111111)); FillRR(c, x + sh, y + sh, w, h, r, sb); }
  SolidBrush b(C(fill)); FillRR(c, x + d, y + d, w, h, r, b);
  StrokeRR(c, x + d, y + d, w, h, r, C(0x111111), 2 * k, dash);
}
static SizeF SkinPop(Ctx& c) {
  const XState& s = *c.s; float k = c.k; View2 v = Resolve(c);
  unsigned card = v.on ? 0xFFE14D : 0xEDEDED, block = v.warn ? 0xFF9F1C : v.on ? 0xFF6B9D : 0xC4C4C4;
  if (c.docked) { float w = 50 * k, h = w; PopBox(c, 2 * k, 2 * k, 42 * k, 42 * k, block, 8 * k, 4 * k, false); if (c.draw) Flower(c, 23 * k, 23 * k, 24 * k, !v.on); c.hit(H_SWITCH, 0, 0, w, h); return SizeF(w, h); }
  Font* f1 = (v.base == 2 || v.base == 3) ? c.fonts->name(v.title, 13.5f * k, true) : c.fonts->ui(13.5f * k, true);
  Font* f2 = c.fonts->ui(11 * k, false); Font* f2b = c.fonts->ui(11 * k, true); Font* fn = c.fonts->num(12 * k, true); Font* kf = c.fonts->num(11 * k, true);
  Font* ft = v.paused ? f2 : fn;
  float kw = v.row == 0 ? TextW(c, s.key, kf) + 14 * k : 0;
  float t1w = TextW(c, v.title, f1); if (t1w > 160 * k) t1w = 160 * k;
  auto rw = [&](int row) -> float { return row == 0 ? kw + 7 * k + TextW(c, v.aux, f2) : row == 1 ? TextW(c, v.aux, f2) + 14 * k : row == 2 ? 62 * k + 8 * k + TmSlotW(c, v, f2, fn) : row == 3 ? TextW(c, v.aux, f2b) + 14 * k + 8 * k + TextW(c, v.tm, fn) : row == 4 ? TextW(c, v.aux, f2b) + 16 * k : 3 * 26 * k + 2 * 8 * k + 3 * k; };
  float r2w = rw(v.row); if (v.base == 2 || v.base == 3) { float a = rw(v.base), b = rw(5); r2w = a > b ? a : b; }  // 播放 / 闪避时悬停前后两种第二行取宽的：悬停时尺寸不变
  float colW = t1w > r2w ? t1w : r2w; if (colW < 116 * k) colW = 116 * k;
  float x0 = 62 * k, cw = x0 + colW + 14 * k, chh = 60 * k, sh = 4 * k, W = cw + sh, H = chh + sh;
  PopBox(c, 0, 0, cw, chh, card, 12 * k, sh, false);
  bool hs = c.hoverId == H_SWITCH;
  PopBox(c, 10 * k, 10 * k, 40 * k, 40 * k, block, 8 * k, 3 * k, hs);
  if (c.draw) Flower(c, 30 * k + (hs ? 3 * k : 0), 30 * k + (hs ? 3 * k : 0), 26 * k, !v.on);
  c.hit(H_SWITCH, 10 * k, 10 * k, 43 * k, 43 * k);
  if (c.draw) Text(c, v.title, f1, C(0x111111), x0, 9 * k, colW, 20 * k, 0, true);
  float cy2 = 41 * k;
  if (v.row == 0) {
    PopBox(c, x0, cy2 - 9 * k, kw, 18 * k, 0xFFFFFF, 4 * k, 2 * k, c.hoverId == H_KEY);
    if (c.draw) { float d = c.hoverId == H_KEY ? 2 * k : 0; Text(c, s.key, kf, C(0x111111), x0 + d, cy2 - 9 * k + d, kw, 18 * k, 11, false); Text(c, v.aux, f2, C(0x333333), x0 + kw + 7 * k, cy2 - 8 * k, colW - kw - 7 * k, 16 * k, 0, true); }
    c.hit(H_KEY, x0, cy2 - 9 * k, kw + 2 * k, 20 * k);
  } else if (v.row == 1) {
    float w = TextW(c, v.aux, f2) + 14 * k;
    PopBox(c, x0, cy2 - 9 * k, w, 18 * k, 0xFFFFFF, 4 * k, 0, false, true);
    if (c.draw) Text(c, v.aux, f2, C(0x333333), x0, cy2 - 9 * k, w, 18 * k, 1, false);
    c.hit(H_KEY, x0, cy2 - 9 * k, w, 18 * k);
  } else if (v.row == 2) {
    if (c.draw) {
      SolidBrush tb(C(0xFFFFFF)); FillRR(c, x0, cy2 - 5 * k, 62 * k, 10 * k, 5 * k, tb);
      if (v.p > 0) { float fw = 62 * k * (v.p > 1 ? 1 : v.p); if (fw < 10 * k) fw = 10 * k; SolidBrush fb(C(v.isBgm ? 0x4DD4FF : 0xFF6B9D)); FillRR(c, x0, cy2 - 5 * k, fw, 10 * k, 5 * k, fb); }
      StrokeRR(c, x0, cy2 - 5 * k, 62 * k, 10 * k, 5 * k, C(0x111111), 2 * k);
      Text(c, v.tm, ft, C(0x111111), x0 + 70 * k, cy2 - 9 * k, colW - 70 * k, 18 * k, v.paused ? 0 : 10, false);
    }
  } else if (v.row == 3) {
    float aw = TextW(c, v.aux, f2b) + 14 * k;
    PopBox(c, x0, cy2 - 9 * k, aw, 18 * k, 0x7CF29C, 4 * k, 2 * k, false);
    if (c.draw) { Text(c, v.aux, f2b, C(0x111111), x0, cy2 - 9 * k, aw, 18 * k, 1, false); Text(c, v.tm, fn, C(0x111111), x0 + aw + 8 * k, cy2 - 9 * k, colW - aw - 8 * k, 18 * k, 10, false); }
    c.hit(v.duckIsB ? H_DUCK_B : H_DUCK_S, x0 - 2 * k, cy2 - 12 * k, colW + 4 * k, 24 * k);
  } else if (v.row == 4) {
    float aw = TextW(c, v.aux, f2b) + 16 * k;
    PopBox(c, x0, cy2 - 9 * k, aw, 18 * k, 0xFF9F1C, 4 * k, 2 * k, c.hoverId == H_NUMFIX);
    if (c.draw) { float d = c.hoverId == H_NUMFIX ? 2 * k : 0; Text(c, v.aux, f2b, C(0x111111), x0 + d, cy2 - 9 * k + d, aw, 18 * k, 1, false); }
    c.hit(H_NUMFIX, x0, cy2 - 12 * k, aw + 2 * k, 24 * k);
  } else {
    float bx = x0;
    for (int i = 0; i < 3; i++) {
      bool hv = c.hoverId == v.hid[i];
      PopBox(c, bx, cy2 - 12 * k, 24 * k, 24 * k, i == 1 ? 0xFF5A5A : 0xFFFFFF, 6 * k, 3 * k, hv);
      IconKind(c, v.hid[i], bx + 12 * k + (hv ? 3 * k : 0), cy2 + (hv ? 3 * k : 0), 12 * k, C(0x111111), v.anyPlaying);
      c.hit(v.hid[i], bx, cy2 - 12 * k, 27 * k, 27 * k);
      bx += 34 * k;
    }
  }
  return SizeF(W, H);
}

// =================================================================================================
// 猫耳胶囊（SK_CATEAR）：奶粉色小胶囊，左边一张猫脸（开关），头顶两只猫耳——开启时竖起、关闭时耷拉（脸也睡着了）、闪避时压成“飞机耳”；
// 放着东西时戴上猫耳耳机（耳朵内侧亮起），表情变开心。字是深莓色，在奶粉底上 9 以上
static void CatEar(Ctx& c, float bx, float by, float rot, unsigned outer, unsigned inner) {  // 一只耳朵：底边中点 (bx, by)，按 rot 度往外倒
  if (!c.draw) return; float k = c.k;
  GraphicsState st = c.g->Save(); c.g->TranslateTransform(bx, by); c.g->RotateTransform(rot);
  GraphicsPath p; p.AddBezier(-7 * k, 0.f, -6 * k, -6 * k, -3 * k, -11 * k, 0.f, -13 * k); p.AddBezier(0.f, -13 * k, 3 * k, -11 * k, 6 * k, -6 * k, 7 * k, 0.f); p.CloseFigure();
  SolidBrush ob(C(outer)); c.g->FillPath(&ob, &p);
  GraphicsPath q; q.AddBezier(-3.8f * k, -1 * k, -3.4f * k, -5 * k, -1.6f * k, -8 * k, 0.f, -9.5f * k); q.AddBezier(0.f, -9.5f * k, 1.6f * k, -8 * k, 3.4f * k, -5 * k, 3.8f * k, -1 * k); q.CloseFigure();
  SolidBrush ib(C(inner)); c.g->FillPath(&ib, &q);
  c.g->Restore(st);
}
static void CatFace(Ctx& c, float cx, float cy, float r, int mood) {  // mood：0 平常 1 睡着 2 开心 3 担心
  if (!c.draw) return; float k = c.k;
  SolidBrush fb(C(0xFFFFFF)); c.g->FillEllipse(&fb, cx - r, cy - r, 2 * r, 2 * r);
  Pen ol(C(0xFFB3CD), 1.2f * k); c.g->DrawEllipse(&ol, cx - r, cy - r, 2 * r, 2 * r);
  Color ink = C(0x4A2B3A); Pen ip(ink, 1.4f * k); ip.SetStartCap(LineCapRound); ip.SetEndCap(LineCapRound);
  float ex = r * .42f, ey = cy - r * .12f;
  if (mood == 1) { c.g->DrawArc(&ip, cx - ex - 2.5f * k, ey - 1 * k, 5 * k, 3.5f * k, 20.f, 140.f); c.g->DrawArc(&ip, cx + ex - 2.5f * k, ey - 1 * k, 5 * k, 3.5f * k, 20.f, 140.f); }
  else if (mood == 2) { c.g->DrawArc(&ip, cx - ex - 2.5f * k, ey, 5 * k, 4 * k, 200.f, 140.f); c.g->DrawArc(&ip, cx + ex - 2.5f * k, ey, 5 * k, 4 * k, 200.f, 140.f); }
  else if (mood == 3) { c.g->DrawLine(&ip, cx - ex - 2 * k, ey - 2 * k, cx - ex + 2 * k, ey); c.g->DrawLine(&ip, cx - ex - 2 * k, ey + 2 * k, cx - ex + 2 * k, ey);
    c.g->DrawLine(&ip, cx + ex + 2 * k, ey - 2 * k, cx + ex - 2 * k, ey); c.g->DrawLine(&ip, cx + ex + 2 * k, ey + 2 * k, cx + ex - 2 * k, ey); }
  else { SolidBrush eb(ink); c.g->FillEllipse(&eb, cx - ex - 1.8f * k, ey - 2.2f * k, 3.6f * k, 4.4f * k); c.g->FillEllipse(&eb, cx + ex - 1.8f * k, ey - 2.2f * k, 3.6f * k, 4.4f * k); }
  SolidBrush nb(C(0xFF8FB5)); c.g->FillEllipse(&nb, cx - 1.6f * k, cy + r * .16f - 1 * k, 3.2f * k, 2.4f * k);
  Pen mp(ink, 1.1f * k); mp.SetStartCap(LineCapRound); mp.SetEndCap(LineCapRound);  // ω 嘴
  c.g->DrawArc(&mp, cx - 3.2f * k, cy + r * .16f, 3.2f * k, 3 * k, 0.f, 180.f); c.g->DrawArc(&mp, cx, cy + r * .16f, 3.2f * k, 3 * k, 0.f, 180.f);
  SolidBrush bl(C(0xFF8FB5, 110)); c.g->FillEllipse(&bl, cx - r * .78f, cy + r * .12f, 5 * k, 3 * k); c.g->FillEllipse(&bl, cx + r * .78f - 5 * k, cy + r * .12f, 5 * k, 3 * k);
}
static void CatHead(Ctx& c, float cx, float cy, float r, const View2& v) {  // 耳朵＋（耳机）＋脸
  if (!c.draw) return; float k = c.k;
  float rot = !v.on ? 38.f : v.base == 3 ? 62.f : 8.f;  // 关闭：耷拉；闪避：飞机耳；平常：微微外张（按悬停前的那一行看：闪避中悬停时耳朵不跟着竖起来）
  float drop = !v.on ? 3 * k : v.base == 3 ? 4 * k : 0;
  bool phones = v.pn.t != nullptr && v.on;
  unsigned inner = phones ? 0xFF4F9A : 0xFF9EC4;
  CatEar(c, cx - r * .62f, cy - r * .62f + drop, -rot, 0xFFB3CD, inner);
  CatEar(c, cx + r * .62f, cy - r * .62f + drop, rot, 0xFFB3CD, inner);
  if (phones) {  // 猫耳耳机：头带＋两侧耳罩
    Pen band(C(0xC77DFF), 2.4f * k); band.SetStartCap(LineCapRound); band.SetEndCap(LineCapRound);
    c.g->DrawArc(&band, cx - r - 1 * k, cy - r - 2 * k, 2 * r + 2 * k, 2 * r + 2 * k, 200.f, 140.f);
    SolidBrush cup(C(0xC77DFF)); FillRR(c, cx - r - 3.5f * k, cy - 4 * k, 5 * k, 9 * k, 2.5f * k, cup); FillRR(c, cx + r - 1.5f * k, cy - 4 * k, 5 * k, 9 * k, 2.5f * k, cup);
  }
  CatFace(c, cx, cy, r, v.warn ? 3 : !v.on ? 1 : (v.pn.t && !v.paused) ? 2 : 0);
}
static SizeF SkinCatear(Ctx& c) {
  const XState& s = *c.s; float k = c.k; View2 v = Resolve(c);
  float top = 11 * k;  // 耳朵要的空间
  if (c.docked) { float w = 46 * k, h = 30 * k + top + 6 * k; CatHead(c, w / 2, top + 17 * k, 14 * k, v); c.hit(H_SWITCH, 0, 0, w, h); return SizeF(w, h); }
  Font* f1 = (v.base == 2 || v.base == 3) ? c.fonts->name(v.title, 12.5f * k, true) : c.fonts->ui(12.5f * k, true);
  Font* f2 = c.fonts->ui(10.5f * k, false); Font* f2b = c.fonts->ui(10.5f * k, true); Font* fn = c.fonts->num(11 * k, true); Font* kf = c.fonts->num(10.5f * k, true);
  Font* ft = v.paused ? f2 : fn;
  float kw = v.row == 0 ? TextW(c, s.key, kf) + 12 * k : 0;
  float t1w = TextW(c, v.title, f1); if (t1w > 150 * k) t1w = 150 * k;
  auto rw = [&](int row) -> float { return row == 0 ? kw + 6 * k + TextW(c, v.aux, f2) : row == 1 ? TextW(c, v.aux, f2) + 12 * k : row == 2 ? 56 * k + 8 * k + TmSlotW(c, v, f2, fn) : row == 3 ? TextW(c, v.aux, f2b) + 14 * k + 8 * k + TextW(c, v.tm, fn) : row == 4 ? TextW(c, v.aux, f2b) + 4 * k : 3 * 24 * k + 2 * 7 * k; };
  float r2w = rw(v.row); if (v.base == 2 || v.base == 3) { float a = rw(v.base), b = rw(5); r2w = a > b ? a : b; }  // 播放 / 闪避时悬停前后两种第二行取宽的：悬停时尺寸不变
  float colW = t1w > r2w ? t1w : r2w; if (colW < 104 * k) colW = 104 * k;
  float bh = 50 * k, x0 = 50 * k, W = x0 + colW + 16 * k, H = top + bh;  // 胶囊高 50：标题与第二行之间留 5（原来 46 高、两行的框紧挨着，真机上标题的下伸笔画 y、g、p 碰到第二行）
  if (c.draw) {
    GraphicsPath p; RoundRectPath(p, 0, top, W, bh, bh / 2);
    LinearGradientBrush bg(PointF(0, top), PointF(0, H), C(v.on ? 0xFFF7FA : 0xF6F2F4), C(v.on ? 0xFFE9F1 : 0xEDE6EA)); c.g->FillPath(&bg, &p);
    StrokeRR(c, 0, top, W, bh, bh / 2, C(0xFFB3CD), 1.4f * k);
  }
  CatHead(c, 24 * k, top + bh / 2, 15 * k, v);
  c.hit(H_SWITCH, 4 * k, 2 * k, 40 * k, H - 4 * k);
  float ty = top + 5 * k, cy2 = top + 35 * k;  // 标题框 5～22、第二行的字框 27～43（按钮 23～47）
  if (c.draw) Text(c, v.title, f1, v.warn ? C(0xB3261E) : v.on ? C(0x4A2B3A) : C(0x7A5A68), x0, ty, colW, 17 * k, 0, true);
  if (v.row == 0) {
    if (c.draw) { SolidBrush kb(C(c.hoverId == H_KEY ? 0xFFC6DA : 0xFFD6E4)); FillRR(c, x0, cy2 - 8 * k, kw, 16 * k, 8 * k, kb); Text(c, s.key, kf, C(0x8A2D55), x0, cy2 - 8 * k, kw, 16 * k, 11, false);
      Text(c, v.aux, f2, C(0x7A5A68), x0 + kw + 6 * k, cy2 - 8 * k, colW - kw - 6 * k, 16 * k, 0, true); }
    c.hit(H_KEY, x0, cy2 - 8 * k, kw, 16 * k);
  } else if (v.row == 1) {
    float w = TextW(c, v.aux, f2) + 12 * k;
    if (c.draw) { StrokeRR(c, x0, cy2 - 8 * k, w, 16 * k, 8 * k, C(0xE58AB0, c.hoverId == H_KEY ? 255 : 190), 1 * k, true); Text(c, v.aux, f2, C(0x7A5A68), x0, cy2 - 8 * k, w, 16 * k, 1, false); }
    c.hit(H_KEY, x0, cy2 - 8 * k, w, 16 * k);
  } else if (v.row == 2) {
    LineProgress(c, x0, cy2, 56 * k, 5 * k, v.p, C(0xF6D3E0), v.isBgm ? C(0xB48CFF) : C(0xFF8FB5), v.isBgm ? C(0x8F6BFF) : C(0xFF5F98));
    if (c.draw) Text(c, v.tm, ft, C(v.paused ? 0x7A5A68 : 0x4A2B3A), x0 + 64 * k, cy2 - 8 * k, colW - 64 * k, 16 * k, v.paused ? 0 : 10, false);
  } else if (v.row == 3) {
    float aw = TextW(c, v.aux, f2b) + 14 * k;
    if (c.draw) { SolidBrush db(C(0xFFE7A3)); FillRR(c, x0, cy2 - 8 * k, aw, 16 * k, 8 * k, db); Text(c, v.aux, f2b, C(0x7A4A00), x0, cy2 - 8 * k, aw, 16 * k, 1, false);
      Text(c, v.tm, fn, C(0x4A2B3A), x0 + aw + 8 * k, cy2 - 8 * k, colW - aw - 8 * k, 16 * k, 10, false); }
    c.hit(v.duckIsB ? H_DUCK_B : H_DUCK_S, x0 - 2 * k, cy2 - 12 * k, colW + 4 * k, 24 * k);
  } else if (v.row == 4) {
    float aw = TextW(c, v.aux, f2b);
    if (c.draw) { Text(c, v.aux, f2b, C(c.hoverId == H_NUMFIX ? 0x8E1A14 : 0xB3261E), x0, cy2 - 8 * k, aw + 4 * k, 16 * k, 0, false); Pen ul(C(0xB3261E), 1 * k); c.g->DrawLine(&ul, x0, cy2 + 7 * k, x0 + aw, cy2 + 7 * k); }
    c.hit(H_NUMFIX, x0 - 2 * k, cy2 - 12 * k, aw + 8 * k, 24 * k);
  } else {
    float bx = x0;
    for (int i = 0; i < 3; i++) {
      bool hv = c.hoverId == v.hid[i];
      if (c.draw) { SolidBrush b(i == 1 ? C(hv ? 0xF0436A : 0xFF5F7E) : C(hv ? 0xFFCFDF : 0xFFE3EC)); c.g->FillEllipse(&b, bx, cy2 - 12 * k, 24 * k, 24 * k); IconKind(c, v.hid[i], bx + 12 * k, cy2, 11 * k, i == 1 ? C(0xFFFFFF) : C(0x8A2D55), v.anyPlaying); }
      c.hit(v.hid[i], bx, cy2 - 12 * k, 24 * k, 24 * k);
      bx += 31 * k;
    }
  }
  return SizeF(W, H);
}

// =================================================================================================
// 拼贴手账（SK_COLLAGE，日记拼贴风）：奶白手账纸（点阵格、纸纹、手撕的下边）叠在牛皮纸上，左边一张用和纸胶带贴着的拍立得（开关；关闭时照片褪成灰）；
// 切换键是“标签机”打出来的黑底白字条，进度是一截和纸胶带，闪避是荧光笔划重点，小键盘提醒是红笔波浪线。字都横排（精绘文字、对比度检查照常）
static const unsigned CL_INK = 0x2A2633, CL_MUTE = 0x6B5F57, CL_RED = 0xB4231B;
static void ClTape(Ctx& c, float cx, float cy, float w, float h, float rot, unsigned base, unsigned stripe, int alpha) {
  if (!c.draw) return;
  float k = c.k, tooth = 2.4f * k;
  GraphicsState st = c.g->Save(); c.g->TranslateTransform(cx, cy); c.g->RotateTransform(rot);
  std::vector<PointF> pts; float x0 = -w / 2, x1 = w / 2, y0 = -h / 2, y1 = h / 2; int n = (int)(h / tooth); if (n < 2) n = 2;
  pts.push_back(PointF(x0, y0)); pts.push_back(PointF(x1, y0));
  for (int i = 1; i < n; i++) pts.push_back(PointF(x1 - ((i & 1) ? tooth * .7f : 0.f), y0 + (y1 - y0) * i / n));
  pts.push_back(PointF(x1, y1)); pts.push_back(PointF(x0, y1));
  for (int i = n - 1; i >= 1; i--) pts.push_back(PointF(x0 + ((i & 1) ? tooth * .7f : 0.f), y0 + (y1 - y0) * i / n));
  GraphicsPath p; p.AddPolygon(pts.data(), (INT)pts.size());
  SolidBrush b(C(base, alpha)); c.g->FillPath(&b, &p);
  Region rg(&p); c.g->SetClip(&rg, CombineModeIntersect);
  Pen sp(C(stripe, alpha), 2.4f * k);
  for (float x = x0 - h; x < x1 + h; x += 6.5f * k) c.g->DrawLine(&sp, x, y1, x + h, y0);
  c.g->Restore(st);
}
static void ClPolaroid(Ctx& c, float cx, float cy, float rot, bool on, bool warn) {
  if (!c.draw) return;
  float k = c.k, fw = 44 * k, fh = 52 * k;
  GraphicsState st = c.g->Save(); c.g->TranslateTransform(cx, cy); c.g->RotateTransform(rot);
  SolidBrush sh(C(0x5A4630, 50)); c.g->FillRectangle(&sh, -fw / 2 + 1.2f * k, -fh / 2 + 2.2f * k, fw, fh);
  SolidBrush fr(C(0xFFFFFF)); c.g->FillRectangle(&fr, -fw / 2, -fh / 2, fw, fh);
  Pen fl(C(0xE4DACB), 1 * k); c.g->DrawRectangle(&fl, -fw / 2, -fh / 2, fw, fh);
  float px = -fw / 2 + 4 * k, py = -fh / 2 + 4 * k, pw = fw - 8 * k, ph = 36 * k;
  LinearGradientBrush pg(PointF(0, py), PointF(0, py + ph), on ? C(0xBFE4FF) : C(0xDADADF), on ? C(0xFFDDE8) : C(0xC2C2C9));
  c.g->FillRectangle(&pg, px, py, pw, ph);
  Flower(c, 0, py + ph / 2 + 1 * k, 25 * k, !on);
  if (warn) {
    SolidBrush rb(C(0xE5484D)); c.g->FillEllipse(&rb, fw / 2 - 13 * k, -fh / 2 - 3 * k, 15 * k, 15 * k);
    SolidBrush wb(C(0xFFFFFF)); c.g->FillRectangle(&wb, fw / 2 - 6.5f * k, -fh / 2 + .2f * k, 2 * k, 5.6f * k); c.g->FillEllipse(&wb, fw / 2 - 6.6f * k, -fh / 2 + 6.7f * k, 2.2f * k, 2.2f * k);
  }
  c.g->Restore(st);
}
static SizeF SkinCollage(Ctx& c) {
  const XState& s = *c.s; float k = c.k; View2 v = Resolve(c);
  if (c.docked) {
    float w = 56 * k, h = 64 * k;
    ClPolaroid(c, w / 2, h / 2 + 3 * k, -5.f, v.on, v.warn);
    ClTape(c, w / 2, 8 * k, 30 * k, 10 * k, 8.f, 0xFFA7B8, 0xFFDDE4, v.on ? 210 : 130);
    c.hit(H_SWITCH, 0, 0, w, h);
    return SizeF(w, h);
  }
  Font* f1 = (v.base == 2 || v.base == 3) ? c.fonts->name(v.title, 13 * k, true) : c.fonts->ui(13 * k, true);
  Font* fs = c.fonts->ui(11 * k, false); Font* fsb = c.fonts->ui(11 * k, true); Font* fn = c.fonts->num(12 * k, true);
  Font* kf = c.fonts->num(11 * k, true); Font* ef = c.fonts->ui(10.5f * k, true);
  Font* ft = v.paused ? fs : fn;
  float t1w = TextW(c, v.title, f1); if (t1w > 164 * k) t1w = 164 * k;
  float labW = v.row == 0 ? TextW(c, s.key, kf) + 14 * k : v.row == 1 ? TextW(c, v.aux, ef) + 14 * k : 0;
  auto rw = [&](int row) -> float { return row == 0 ? labW + 6 * k + TextW(c, v.aux, fs) : row == 1 ? labW : row == 2 ? 70 * k + 8 * k + TmSlotW(c, v, fs, fn) : row == 3 ? TextW(c, v.aux, fsb) + 12 * k + 8 * k + TextW(c, v.tm, fn) : row == 4 ? TextW(c, v.aux, fsb) + 4 * k : 3 * 24 * k + 2 * 9 * k; };
  float r2w = rw(v.row); if (v.base == 2 || v.base == 3) { float a = rw(v.base), b = rw(5); r2w = a > b ? a : b; }  // 播放 / 闪避时悬停前后两种第二行取宽的：悬停时尺寸不变
  float colW = t1w > r2w ? t1w : r2w; if (colW < 112 * k) colW = 112 * k;
  float x0 = 66 * k, cw = x0 + colW + 14 * k, ch = 62 * k, off = 4 * k, W = cw + off, H = ch + off;
  if (c.draw) {
    SolidBrush kb(C(v.on ? 0xC8A47A : 0xB9AB98)); c.g->FillRectangle(&kb, off, off, cw, ch);  // 下面一层牛皮纸
    std::vector<PointF> pts; pts.push_back(PointF(0, 0)); pts.push_back(PointF(cw, 0)); pts.push_back(PointF(cw, ch - 3 * k));
    int nt = (int)(cw / (5 * k)); for (int i = 1; i < nt; i++) pts.push_back(PointF(cw - cw * i / nt, ch - 3 * k + ((i * 7) % 3 == 0 ? 2.2f * k : (i & 1) ? .6f * k : 1.6f * k)));
    pts.push_back(PointF(0, ch - 3 * k));
    GraphicsPath cp; cp.AddPolygon(pts.data(), (INT)pts.size());
    SolidBrush pb(C(0xFBF6EA)); c.g->FillPath(&pb, &cp);
    TileDots(c, cp, 10 * k, .75f * k, 0xD8CBB4, 150, false);  // 点阵格（很淡，不影响文字对比度）
    Grain(c, cp, 0x8A6E4B, 9);
    ClTape(c, cw - 16 * k, 3 * k, 34 * k, 11 * k, 32.f, v.on ? 0x9ED8F0 : 0xC9C9CF, v.on ? 0xD6EFFA : 0xE4E4E8, v.on ? 200 : 140);
  }
  ClPolaroid(c, 33 * k, 31 * k, -5.f, v.on, v.warn);
  ClTape(c, 33 * k, 6 * k, 32 * k, 10 * k, -8.f, v.on ? 0xFFA7B8 : 0xCFCFD4, v.on ? 0xFFDDE4 : 0xE6E6EA, v.on ? 215 : 150);
  c.hit(H_SWITCH, 8 * k, 5 * k, 50 * k, 54 * k);
  float cy2 = 42 * k;
  if (c.draw) Text(c, v.title, f1, C(v.on || v.warn ? CL_INK : CL_MUTE), x0, 9 * k, colW, 20 * k, 0, true);
  if (v.row == 0 || v.row == 1) {
    bool hv = c.hoverId == H_KEY, empty = v.row == 1;
    if (c.draw) {
      if (empty) { StrokeRR(c, x0, cy2 - 9 * k, labW, 18 * k, 3 * k, C(hv ? 0x6B5F57 : 0x9A8C7E), 1 * k, true); Text(c, v.aux, ef, C(CL_MUTE), x0, cy2 - 9 * k, labW, 18 * k, 1, false); }
      else {
        SolidBrush b(C(hv ? 0x34323C : 0x1F1E24)); FillRR(c, x0, cy2 - 9 * k, labW, 18 * k, 2.5f * k, b);
        Pen hi(C(0xFFFFFF, 46), 1 * k); c.g->DrawLine(&hi, x0 + 2 * k, cy2 - 7.5f * k, x0 + labW - 2 * k, cy2 - 7.5f * k);
        Text(c, s.key, kf, C(0xFFFFFF), x0, cy2 - 9 * k, labW, 18 * k, 11, false);
        Text(c, v.aux, fs, C(CL_MUTE), x0 + labW + 6 * k, cy2 - 10 * k, colW - labW - 6 * k, 20 * k, 0, true);
      }
    }
    c.hit(H_KEY, x0, cy2 - 9 * k, labW, 18 * k);
  } else if (v.row == 2) {
    if (c.draw) {
      float h = 9 * k, w = 70 * k;
      StrokeRR(c, x0, cy2 - h / 2, w, h, 1.5f * k, C(0xC9BBA3), 1 * k, true);
      if (v.p > 0) { GraphicsState st = c.g->Save(); c.g->IntersectClip(RectF(x0, cy2 - h, w * (v.p > 1 ? 1 : v.p), 2 * h));
        ClTape(c, x0 + w / 2, cy2, w + 4 * k, h, 0.f, v.isBgm ? 0x8FD6C4 : 0xFFA7B8, v.isBgm ? 0xCDEFE6 : 0xFFDDE4, 235); c.g->Restore(st); }
      Text(c, v.tm, ft, C(v.paused ? CL_MUTE : CL_INK), x0 + 78 * k, cy2 - 10 * k, colW - 78 * k, 20 * k, v.paused ? 0 : 10, false);
    }
  } else if (v.row == 3) {
    float hw = TextW(c, v.aux, fsb) + 12 * k;
    if (c.draw) {
      GraphicsState st = c.g->Save(); c.g->TranslateTransform(x0 + hw / 2, cy2); c.g->RotateTransform(-1.5f);
      SolidBrush hl(C(0xFFE15C, 235)); FillRR(c, -hw / 2, -8 * k, hw, 16 * k, 2 * k, hl); c.g->Restore(st);
      Text(c, v.aux, fsb, C(CL_INK), x0, cy2 - 10 * k, hw, 20 * k, 1, false);
      Text(c, v.tm, fn, C(CL_INK), x0 + hw + 8 * k, cy2 - 10 * k, colW - hw - 8 * k, 20 * k, 10, false);
    }
    c.hit(v.duckIsB ? H_DUCK_B : H_DUCK_S, x0 - 2 * k, cy2 - 12 * k, colW + 4 * k, 24 * k);
  } else if (v.row == 4) {
    float aw = TextW(c, v.aux, fsb);
    if (c.draw) {
      Color rc = C(c.hoverId == H_NUMFIX ? 0x8E1A14 : CL_RED);
      Text(c, v.aux, fsb, rc, x0, cy2 - 10 * k, aw + 4 * k, 20 * k, 0, false);
      Pen up(rc, 1.3f * k); up.SetStartCap(LineCapRound); up.SetEndCap(LineCapRound);
      std::vector<PointF> sq; for (float xx = 0; xx <= aw; xx += 3 * k) sq.push_back(PointF(x0 + xx, cy2 + 8.5f * k + (((int)(xx / (3 * k))) & 1 ? 1.4f * k : 0.f)));
      if (sq.size() >= 2) c.g->DrawCurve(&up, sq.data(), (INT)sq.size());
    }
    c.hit(H_NUMFIX, x0 - 2 * k, cy2 - 12 * k, aw + 8 * k, 24 * k);
  } else {
    for (int i = 0; i < 3; i++) {
      float cx = x0 + 12 * k + i * 33 * k, r = 12 * k; bool hv = c.hoverId == v.hid[i];
      if (c.draw) {
        SolidBrush sh(C(0x5A4630, 55)); c.g->FillEllipse(&sh, cx - r + .8f * k, cy2 - r + 1.6f * k, 2 * r, 2 * r);
        SolidBrush wb(C(0xFFFFFF)); c.g->FillEllipse(&wb, cx - r, cy2 - r, 2 * r, 2 * r);
        float ir = r - 2.2f * k; SolidBrush fb(i == 1 ? C(hv ? 0xC93035 : 0xE5484D) : C(hv ? 0xF4CFD8 : 0xFBE6EC)); c.g->FillEllipse(&fb, cx - ir, cy2 - ir, 2 * ir, 2 * ir);
        IconKind(c, v.hid[i], cx, cy2, 12 * k, i == 1 ? C(0xFFFFFF) : C(0x8E2440), v.anyPlaying);
      }
      c.hit(v.hid[i], cx - r, cy2 - r, 2 * r, 2 * r);
    }
  }
  return SizeF(W, H);
}

// =================================================================================================
// 漫画波普（SK_COMIC）：白底粗黑框的漫画格，右边铺淡网点；左边小红花在一团圆角框里（开关），放音效时背后炸开黄色爆炸框、放音乐时飘音符；
// 切换键与倒计时放在黄色“旁白框”里。黑字在白、黄上都在 15 以上
static void ComicBurst(Ctx& c, float cx, float cy, float r, unsigned fill) {
  if (!c.draw) return; float k = c.k;
  PointF pts[24]; for (int i = 0; i < 24; i++) { float a = i * 3.14159265f / 12.f - 1.5707963f, rr = (i & 1) ? r * .68f : r * (i % 4 == 0 ? 1.f : .9f); pts[i] = PointF(cx + cosf(a) * rr, cy + sinf(a) * rr); }
  SolidBrush b(C(fill)); c.g->FillPolygon(&b, pts, 24);
  Pen p(C(0x111111), 1.8f * k); p.SetLineJoin(LineJoinRound); c.g->DrawPolygon(&p, pts, 24);
}
static void ComicBox(Ctx& c, float x, float y, float w, float h, unsigned fill, float sh, bool dash = false) {
  if (!c.draw) return; float k = c.k;
  if (sh > 0) { SolidBrush s(C(0x111111)); c.g->FillRectangle(&s, x + sh, y + sh, w, h); }
  SolidBrush b(C(fill)); c.g->FillRectangle(&b, x, y, w, h);
  Pen p(C(0x111111), 1.6f * k); if (dash) p.SetDashStyle(DashStyleDash); c.g->DrawRectangle(&p, x, y, w, h);
}
static SizeF SkinComic(Ctx& c) {
  const XState& s = *c.s; float k = c.k; View2 v = Resolve(c);
  bool sfxOn = v.pn.t && !v.pn.isBgm && !v.paused && v.on, bgmOn = v.pn.t && v.pn.isBgm && !v.paused && v.on;
  auto hero = [&](float cx, float cy, bool hot) {
    if (!c.draw) return;
    if (sfxOn || v.warn) ComicBurst(c, cx, cy, 22 * k, v.warn ? 0xFF9F1C : 0xFFE24D);
    else { SolidBrush b(C(0xFFFFFF)); c.g->FillEllipse(&b, cx - 17 * k, cy - 17 * k, 34 * k, 34 * k); Pen p(C(0x111111), (hot ? 2.4f : 1.8f) * k); c.g->DrawEllipse(&p, cx - 17 * k, cy - 17 * k, 34 * k, 34 * k); }
    Flower(c, cx, cy, 22 * k, !v.on);
    if (bgmOn) { IconNote(c, cx + 17 * k, cy - 15 * k, 11 * k, C(0x111111)); IconNote(c, cx - 19 * k, cy - 13 * k, 8 * k, C(0x111111)); }
    if (!v.on) {  // 睡着：三个点
      SolidBrush d(C(0x111111)); for (int i = 0; i < 3; i++) c.g->FillEllipse(&d, cx + 10 * k + i * 4 * k, cy - 20 * k, 2.4f * k, 2.4f * k);
    }
  };
  if (c.docked) { float w = 54 * k, h = w; ComicBox(c, 2 * k, 2 * k, 48 * k, 48 * k, 0xFFFFFF, 3 * k); hero(26 * k, 26 * k, false); c.hit(H_SWITCH, 0, 0, w, h); return SizeF(w, h); }
  Font* f1 = (v.base == 2 || v.base == 3) ? c.fonts->name(v.title, 13.5f * k, true) : c.fonts->ui(13.5f * k, true);
  Font* f2 = c.fonts->ui(11 * k, false); Font* f2b = c.fonts->ui(11 * k, true); Font* fn = c.fonts->num(12 * k, true); Font* kf = c.fonts->num(11 * k, true);
  Font* ft = v.paused ? f2 : fn;
  float kw = v.row == 0 ? TextW(c, s.key, kf) + 14 * k : 0;
  float t1w = TextW(c, v.title, f1); if (t1w > 160 * k) t1w = 160 * k;
  auto rw = [&](int row) -> float { return row == 0 ? kw + 7 * k + TextW(c, v.aux, f2) : row == 1 ? TextW(c, v.aux, f2) + 14 * k : row == 2 ? 62 * k + 8 * k + TmSlotW(c, v, f2, fn) + 12 * k : row == 3 ? TextW(c, v.aux, f2b) + 14 * k + 8 * k + TextW(c, v.tm, fn) + 12 * k : row == 4 ? TextW(c, v.aux, f2b) + 4 * k : 3 * 26 * k + 2 * 8 * k + 3 * k; };
  float r2w = rw(v.row); if (v.base == 2 || v.base == 3) { float a = rw(v.base), b = rw(5); r2w = a > b ? a : b; }  // 播放 / 闪避时悬停前后两种第二行取宽的：悬停时尺寸不变
  float colW = t1w > r2w ? t1w : r2w; if (colW < 116 * k) colW = 116 * k;
  float x0 = 62 * k, cw = x0 + colW + 14 * k, chh = 60 * k, sh = 4 * k, W = cw + sh, H = chh + sh;
  if (c.draw) {
    SolidBrush s0(C(0x111111)); c.g->FillRectangle(&s0, sh, sh, cw, chh);
    SolidBrush b0(C(v.on ? 0xFFFFFF : 0xF2F2F2)); c.g->FillRectangle(&b0, 0.f, 0.f, cw, chh);
    GraphicsPath dp; dp.AddRectangle(RectF(cw * .45f, 0, cw * .55f, chh));  // 右半边网点（越往右越密的感觉用颜色深浅做）
    TileDots(c, dp, 7 * k, 1.3f * k, v.on ? 0x9ADCF5 : 0xCFCFCF, 110, true);
    Pen bd(C(0x111111), 2.5f * k); c.g->DrawRectangle(&bd, 1.25f * k, 1.25f * k, cw - 2.5f * k, chh - 2.5f * k);
    Pen sp(C(0x111111), 1.4f * k); c.g->DrawLine(&sp, 54 * k, 8 * k, 54 * k, chh - 8 * k);  // 分格线
  }
  hero(28 * k, 30 * k, c.hoverId == H_SWITCH);
  c.hit(H_SWITCH, 6 * k, 8 * k, 44 * k, 44 * k);
  if (c.draw) Text(c, v.title, f1, v.warn ? C(0xC81E1E) : C(0x111111), x0, 8 * k, colW, 20 * k, 0, true);
  float cy2 = 41 * k;
  if (v.row == 0) {
    ComicBox(c, x0, cy2 - 9 * k, kw, 18 * k, c.hoverId == H_KEY ? 0xFFEE85 : 0xFFE24D, 2 * k);
    if (c.draw) { Text(c, s.key, kf, C(0x111111), x0, cy2 - 9 * k, kw, 18 * k, 11, false); Text(c, v.aux, f2, C(0x333333), x0 + kw + 7 * k, cy2 - 8 * k, colW - kw - 7 * k, 16 * k, 0, true); }
    c.hit(H_KEY, x0, cy2 - 9 * k, kw + 2 * k, 20 * k);
  } else if (v.row == 1) {
    float w = TextW(c, v.aux, f2) + 14 * k;
    ComicBox(c, x0, cy2 - 9 * k, w, 18 * k, 0xFFFFFF, 0, true);
    if (c.draw) Text(c, v.aux, f2, C(0x333333), x0, cy2 - 9 * k, w, 18 * k, 1, false);
    c.hit(H_KEY, x0, cy2 - 9 * k, w, 18 * k);
  } else if (v.row == 2 || v.row == 3) {
    float lx = x0;
    if (v.row == 3) { float aw = TextW(c, v.aux, f2b) + 14 * k; ComicBox(c, x0, cy2 - 9 * k, aw, 18 * k, 0x7CF29C, 2 * k); if (c.draw) Text(c, v.aux, f2b, C(0x111111), x0, cy2 - 9 * k, aw, 18 * k, 1, false); lx = x0 + aw + 8 * k; c.hit(v.duckIsB ? H_DUCK_B : H_DUCK_S, x0 - 2 * k, cy2 - 12 * k, colW + 4 * k, 24 * k); }
    else if (c.draw) {
      SolidBrush tb(C(0xFFFFFF)); c.g->FillRectangle(&tb, x0, cy2 - 4.5f * k, 62 * k, 9 * k);
      if (v.p > 0) { SolidBrush fb(C(v.isBgm ? 0x3FA9F5 : 0xE5384D)); c.g->FillRectangle(&fb, x0, cy2 - 4.5f * k, 62 * k * (v.p > 1 ? 1 : v.p), 9 * k); }
      Pen bp(C(0x111111), 1.6f * k); c.g->DrawRectangle(&bp, x0, cy2 - 4.5f * k, 62 * k, 9 * k); lx = x0 + 70 * k;
    }
    float tw = TextW(c, v.tm, v.row == 3 ? fn : ft) + 12 * k;
    ComicBox(c, lx, cy2 - 9 * k, tw, 18 * k, 0xFFE24D, 2 * k);
    if (c.draw) Text(c, v.tm, v.row == 3 ? fn : ft, C(0x111111), lx, cy2 - 9 * k, tw, 18 * k, v.paused ? 1 : 11, false);
  } else if (v.row == 4) {
    float aw = TextW(c, v.aux, f2b);
    if (c.draw) { Text(c, v.aux, f2b, C(c.hoverId == H_NUMFIX ? 0x8A1010 : 0xC81E1E), x0, cy2 - 8 * k, aw + 4 * k, 16 * k, 0, false); Pen ul(C(0xC81E1E), 1.4f * k); c.g->DrawLine(&ul, x0, cy2 + 7 * k, x0 + aw, cy2 + 7 * k); }
    c.hit(H_NUMFIX, x0 - 2 * k, cy2 - 12 * k, aw + 8 * k, 24 * k);
  } else {
    float bx = x0;
    for (int i = 0; i < 3; i++) {
      bool hv = c.hoverId == v.hid[i]; float d = hv ? 2 * k : 0;
      if (c.draw) {
        if (!hv) { SolidBrush s2(C(0x111111)); c.g->FillEllipse(&s2, bx + 2 * k, cy2 - 12 * k + 2 * k, 24 * k, 24 * k); }
        SolidBrush b(i == 1 ? C(0xE5384D) : C(0xFFFFFF)); c.g->FillEllipse(&b, bx + d, cy2 - 12 * k + d, 24 * k, 24 * k);
        Pen p(C(0x111111), 1.6f * k); c.g->DrawEllipse(&p, bx + d, cy2 - 12 * k + d, 24 * k, 24 * k);
        IconKind(c, v.hid[i], bx + 12 * k + d, cy2 + d, 11 * k, i == 1 ? C(0xFFFFFF) : C(0x111111), v.anyPlaying);
      }
      c.hit(v.hid[i], bx, cy2 - 12 * k, 26 * k, 26 * k);
      bx += 34 * k;
    }
  }
  return SizeF(W, H);
}

// =================================================================================================
// 黑胶唱机（SK_VINYL）：胡桃木底座上一张黑胶（点唱片中心的标签＝快捷键开关），显示的那一路在放时唱片转（每秒 12 帧，系统关闭动画时不转）、
// 唱臂随进度从外圈移到内圈；右边一张奶白唱片封套写名称与时间。1.4.0 起与其余单路皮肤一样只管音效（原来只管背景音乐：放音效时只显示待机），
// 悬停时封套上是暂停 / 继续、急停、主面板（闪避时主面板换成“取消闪避”，见 Resolve；原来是背景音乐的上一首、播放 / 暂停、下一首和急停）
static void VnArm(Ctx& c, float px, float py, float ang) {  // 唱臂：支点 (px, py)，ang 度（0＝竖直向下）
  if (!c.draw) return; float k = c.k;
  GraphicsState st = c.g->Save(); c.g->TranslateTransform(px, py); c.g->RotateTransform(ang);
  Pen arm(C(0xD9D6D0), 2.2f * k); arm.SetStartCap(LineCapRound); arm.SetEndCap(LineCapRound);
  c.g->DrawLine(&arm, 0.f, 0.f, 0.f, 30 * k);
  SolidBrush hd(C(0xBDB8AE)); c.g->FillRectangle(&hd, -2.5f * k, 29 * k, 5 * k, 6 * k);
  c.g->Restore(st);
  SolidBrush pv(C(0x8C8578)); c.g->FillEllipse(&pv, px - 4 * k, py - 4 * k, 8 * k, 8 * k);
  SolidBrush pc(C(0xE4E0D8)); c.g->FillEllipse(&pc, px - 2 * k, py - 2 * k, 4 * k, 4 * k);
}
static void VnDeck(Ctx& c, float w, float h) {
  if (!c.draw) return; float k = c.k;
  GraphicsPath p; RoundRectPath(p, 0, 0, w, h, 10 * k);
  LinearGradientBrush bg(PointF(0, 0), PointF(w * .3f, h), C(0x7A5232), C(0x4A3020)); c.g->FillPath(&bg, &p);
  GraphicsState st = c.g->Save(); Region rg(&p); c.g->SetClip(&rg, CombineModeIntersect);
  Pen gr(C(0x2A1A10, 40), 1 * k); for (int i = 0; i < 6; i++) { float y = h * (i + .5f) / 6; c.g->DrawBezier(&gr, 0.f, y, w * .3f, y - 2 * k, w * .6f, y + 2 * k, w, y - 1 * k); }  // 木纹
  c.g->Restore(st);
  StrokeRR(c, 0, 0, w, h, 10 * k, C(0x1A100A, 140), 1 * k);
  Pen hl(C(0xFFFFFF, 34), 1 * k); c.g->DrawLine(&hl, 10 * k, 1.2f * k, w - 10 * k, 1.2f * k);
}
static SizeF SkinVinyl(Ctx& c) {
  const XState& s = *c.s; float k = c.k; View2 v = Resolve(c);
  bool spin = v.anyPlaying && v.on && c.anim;  // 1.4.0：显示的那一路在放就转（原来只认背景音乐）
  float rot = spin ? fmodf((float)(c.now % 3600000u) / 1000.f * 200.f, 360.f) : 20.f;
  float pr = v.pn.t ? v.p : -1;  // 唱臂：没在放时停在架上
  auto record = [&](float cx, float cy, float d) {
    if (!c.draw) return;
    SolidBrush pl(C(0x1B1612)); c.g->FillEllipse(&pl, cx - d / 2 - 3 * k, cy - d / 2 - 3 * k, d + 6 * k, d + 6 * k);  // 转盘
    Vinyl(c, cx, cy, d, v.warn ? C(0xFFB547) : v.on ? C(0xE8A75D) : C(0x6A6A70), rot);
    if (c.hoverId == H_SWITCH) { Pen hp(C(0xFFFFFF, 120), 1.2f * k); c.g->DrawEllipse(&hp, cx - d / 2 - 2 * k, cy - d / 2 - 2 * k, d + 4 * k, d + 4 * k); }
    FlowerMono(c, cx, cy, d * .26f, v.on ? C(0x5A1E14) : C(0x3A3A40), v.on ? C(0xFFF1C9) : C(0x9A9AA2));
  };
  if (c.docked) { float w = 58 * k, h = w; VnDeck(c, w, h); record(29 * k, 29 * k, 44 * k); c.hit(H_SWITCH, 0, 0, w, h); return SizeF(w, h); }
  Font* f1 = (v.base == 2 || v.base == 3) ? c.fonts->name(v.title, 12.5f * k, true) : c.fonts->ui(12.5f * k, true);
  Font* f2 = c.fonts->ui(10.5f * k, false); Font* f2b = c.fonts->ui(10.5f * k, true); Font* fn = c.fonts->num(11.5f * k, true); Font* kf = c.fonts->num(10.5f * k, true);
  Font* ft = v.paused ? f2 : fn;
  float kw = v.row == 0 ? TextW(c, s.key, kf) + 12 * k : 0;
  float t1w = TextW(c, v.title, f1); if (t1w > 156 * k) t1w = 156 * k;
  const int nb = 3; const int* ids = v.hid;  // 1.4.0：悬停按钮与其余单路皮肤相同——暂停 / 继续、急停、主面板（闪避时主面板换成“取消闪避”，见 Resolve）
  auto rw = [&](int row) -> float { return row == 0 ? kw + 6 * k + TextW(c, v.aux, f2) : row == 1 ? TextW(c, v.aux, f2) + 12 * k : row == 2 ? 54 * k + 8 * k + TmSlotW(c, v, f2, fn) : row == 3 ? TextW(c, v.aux, f2b) + 14 * k + 8 * k + TextW(c, v.tm, fn) : row == 4 ? TextW(c, v.aux, f2b) + 4 * k : nb * 24 * k + (nb - 1) * 5 * k; };
  float r2w = rw(v.row); if (v.base == 2 || v.base == 3) { float a = rw(v.base), b = rw(5); r2w = a > b ? a : b; }  // 播放 / 闪避时悬停前后两种第二行取宽的：悬停时尺寸不变
  float colW = t1w > r2w ? t1w : r2w; if (colW < 112 * k) colW = 112 * k;
  float sx = 78 * k, sw = colW + 20 * k, W = sx + sw + 8 * k, H = 64 * k;
  VnDeck(c, W, H);
  record(33 * k, 32 * k, 48 * k);
  c.hit(H_SWITCH, 9 * k, 8 * k, 48 * k, 48 * k);
  if (c.draw) {
    float ang = pr < 0 ? -8.f : 16.f + pr * 22.f;  // 架上 → 外圈 → 内圈
    VnArm(c, 66 * k, 9 * k, ang);
    SolidBrush led(C(v.warn ? 0xFFB547 : v.on ? 0x4BE38A : 0x5E5650)); c.g->FillEllipse(&led, 64 * k, H - 11 * k, 5 * k, 5 * k);
    SolidBrush sl(C(0xF3E9D7)); FillRR(c, sx, 7 * k, sw, H - 14 * k, 6 * k, sl);  // 唱片封套
    Pen sd(C(0xD9C9AE), 1 * k); c.g->DrawLine(&sd, sx + 6 * k, 29 * k, sx + sw - 6 * k, 29 * k);
    Text(c, v.title, f1, v.warn ? C(0x9A3412) : v.on ? C(0x2B1E14) : C(0x6B5847), sx + 10 * k, 9 * k, colW, 19 * k, 0, true);
  }
  float x0 = sx + 10 * k, cy2 = 43 * k;
  if (v.row == 0) {
    if (c.draw) { SolidBrush kb(C(c.hoverId == H_KEY ? 0x5A4330 : 0x3A2A1E)); FillRR(c, x0, cy2 - 8 * k, kw, 16 * k, 4 * k, kb); Text(c, s.key, kf, C(0xF3E9D7), x0, cy2 - 8 * k, kw, 16 * k, 11, false);
      Text(c, v.aux, f2, C(0x6B5847), x0 + kw + 6 * k, cy2 - 8 * k, colW - kw - 6 * k, 16 * k, 0, true); }
    c.hit(H_KEY, x0, cy2 - 8 * k, kw, 16 * k);
  } else if (v.row == 1) {
    float w = TextW(c, v.aux, f2) + 12 * k;
    if (c.draw) { StrokeRR(c, x0, cy2 - 8 * k, w, 16 * k, 4 * k, C(0x8C7A66, c.hoverId == H_KEY ? 255 : 200), 1 * k, true); Text(c, v.aux, f2, C(0x6B5847), x0, cy2 - 8 * k, w, 16 * k, 1, false); }
    c.hit(H_KEY, x0, cy2 - 8 * k, w, 16 * k);
  } else if (v.row == 2) {
    LineProgress(c, x0, cy2, 54 * k, 3 * k, v.p, C(0xE2D4BC), C(0x8A5A2B), C(0xC27B3A));
    if (c.draw) Text(c, v.tm, ft, C(v.paused ? 0x6B5847 : 0x2B1E14), x0 + 62 * k, cy2 - 8 * k, colW - 62 * k, 16 * k, v.paused ? 0 : 10, false);
  } else if (v.row == 3) {
    float aw = TextW(c, v.aux, f2b) + 14 * k;
    if (c.draw) { SolidBrush db(C(0xFFE1A6)); FillRR(c, x0, cy2 - 8 * k, aw, 16 * k, 8 * k, db); Text(c, v.aux, f2b, C(0x7A4100), x0, cy2 - 8 * k, aw, 16 * k, 1, false);
      Text(c, v.tm, fn, C(0x2B1E14), x0 + aw + 8 * k, cy2 - 8 * k, colW - aw - 8 * k, 16 * k, 10, false); }
    c.hit(v.duckIsB ? H_DUCK_B : H_DUCK_S, sx, 31 * k, sw, 24 * k);
  } else if (v.row == 4) {
    float aw = TextW(c, v.aux, f2b);
    if (c.draw) { Text(c, v.aux, f2b, C(c.hoverId == H_NUMFIX ? 0x6E250C : 0x9A3412), x0, cy2 - 8 * k, aw + 4 * k, 16 * k, 0, false); Pen ul(C(0x9A3412), 1 * k); c.g->DrawLine(&ul, x0, cy2 + 7 * k, x0 + aw, cy2 + 7 * k); }
    c.hit(H_NUMFIX, x0 - 2 * k, cy2 - 12 * k, aw + 8 * k, 24 * k);
  } else {
    float bx = x0;
    for (int i = 0; i < nb; i++) {
      bool hv = c.hoverId == ids[i], red = ids[i] == H_STOP;  // 急停是红的
      if (c.draw) { SolidBrush b(red ? C(hv ? 0xB3261E : 0xC8402F) : C(hv ? 0xE6D5B8 : 0xEFE3CE)); c.g->FillEllipse(&b, bx, cy2 - 12 * k, 24 * k, 24 * k);
        Pen p(C(0xC9B79A), 1 * k); if (!red) c.g->DrawEllipse(&p, bx, cy2 - 12 * k, 24 * k, 24 * k);
        IconKind(c, ids[i], bx + 12 * k, cy2, 11 * k, red ? C(0xFFFFFF) : C(0x3A2A1E), v.anyPlaying); }
      c.hit(ids[i], bx, cy2 - 12 * k, 24 * k, 24 * k);
      bx += 29 * k;
    }
  }
  return SizeF(W, H);
}

// =================================================================================================
// 国潮印章（SK_SEAL，新中式）：宣纸底、朱红细双线框、四角回纹；左边一方朱红印章（开关）——开启时是盖上去的白文印（红底白花，
// 边缘略毛），关闭时只剩淡红的印框；进度是一笔墨痕。朱红 #B3261E 在宣纸上 6.0，墨色 15 以上
static void SealStamp(Ctx& c, float x, float y, float s, bool on, bool warn, bool hot) {
  if (!c.draw) return; float k = c.k;
  if (on || warn) {
    std::vector<PointF> pts; int n = 28;  // 印边略毛：沿方框一圈的点，按固定序列稍稍内外错开
    for (int i = 0; i < n; i++) {
      float t = (float)i / n * 4.f; int side = (int)t; float f = t - side; float j = ((i * 37) % 5 - 2) * .35f * k;
      float px, py; if (side == 0) { px = x + f * s; py = y + j; } else if (side == 1) { px = x + s + j; py = y + f * s; } else if (side == 2) { px = x + s - f * s; py = y + s + j; } else { px = x + j; py = y + s - f * s; }
      pts.push_back(PointF(px, py));
    }
    SolidBrush rb(C(warn ? 0xC2410C : hot ? 0x9E1F18 : 0xB3261E)); c.g->FillPolygon(&rb, pts.data(), (INT)pts.size());
    FlowerMono(c, x + s / 2, y + s / 2, s * .62f, C(0xF7F1E3), C(warn ? 0xC2410C : 0xB3261E));
    SolidBrush sp(C(0xF7F1E3, 70)); c.g->FillEllipse(&sp, x + s * .18f, y + s * .7f, 2.2f * k, 1.6f * k); c.g->FillEllipse(&sp, x + s * .8f, y + s * .22f, 1.8f * k, 1.4f * k);  // 印泥没吃匀的白点
  } else {
    Pen p(C(0xB3261E, hot ? 170 : 110), 1.6f * k); c.g->DrawRectangle(&p, x + 1 * k, y + 1 * k, s - 2 * k, s - 2 * k);
    FlowerMono(c, x + s / 2, y + s / 2, s * .6f, C(0xB3A79A), C(0xD8CFC2));
  }
}
static void HuiCorner(Ctx& c, float x, float y, float s, int dx, int dy, const Color& col) {  // 回纹角花：在框的四个角里往里勾一笔（不进文字区：原来右上角的祥云会压住长标题）
  if (!c.draw) return; float k = c.k;
  Pen p(col, 1.1f * k); p.SetStartCap(LineCapSquare); p.SetEndCap(LineCapSquare); p.SetLineJoin(LineJoinMiter);
  PointF pts[5] = {PointF(x + dx * s, y), PointF(x, y), PointF(x, y + dy * s), PointF(x + dx * s * .55f, y + dy * s), PointF(x + dx * s * .55f, y + dy * s * .45f)};
  c.g->DrawLines(&p, pts, 5);
}
static SizeF SkinSeal(Ctx& c) {
  const XState& s = *c.s; float k = c.k; View2 v = Resolve(c);
  if (c.docked) { float w = 52 * k, h = w; if (c.draw) { SolidBrush pb(C(0xF7F1E3)); FillRR(c, 0, 0, w, h, 4 * k, pb); StrokeRR(c, 2 * k, 2 * k, w - 4 * k, h - 4 * k, 3 * k, C(0xB3261E, 150), 1 * k); } SealStamp(c, 8 * k, 8 * k, 36 * k, v.on, v.warn, false); c.hit(H_SWITCH, 0, 0, w, h); return SizeF(w, h); }
  Font* f1 = (v.base == 2 || v.base == 3) ? c.fonts->name(v.title, 13 * k, true) : c.fonts->ui(13 * k, true);
  Font* f2 = c.fonts->ui(10.5f * k, false); Font* f2b = c.fonts->ui(10.5f * k, true); Font* fn = c.fonts->num(11.5f * k, true); Font* kf = c.fonts->num(10.5f * k, true);
  Font* ft = v.paused ? f2 : fn;
  float kw = v.row == 0 ? TextW(c, s.key, kf) + 12 * k : 0;
  float t1w = TextW(c, v.title, f1); if (t1w > 160 * k) t1w = 160 * k;
  auto rw = [&](int row) -> float { return row == 0 ? kw + 6 * k + TextW(c, v.aux, f2) : row == 1 ? TextW(c, v.aux, f2) + 12 * k : row == 2 ? 60 * k + 8 * k + TmSlotW(c, v, f2, fn) : row == 3 ? TextW(c, v.aux, f2b) + 14 * k + 8 * k + TextW(c, v.tm, fn) : row == 4 ? TextW(c, v.aux, f2b) + 4 * k : 3 * 24 * k + 2 * 8 * k; };
  float r2w = rw(v.row); if (v.base == 2 || v.base == 3) { float a = rw(v.base), b = rw(5); r2w = a > b ? a : b; }  // 播放 / 闪避时悬停前后两种第二行取宽的：悬停时尺寸不变
  float colW = t1w > r2w ? t1w : r2w; if (colW < 116 * k) colW = 116 * k;
  float x0 = 62 * k, W = x0 + colW + 18 * k, H = 60 * k;
  if (c.draw) {
    GraphicsPath p; RoundRectPath(p, 0, 0, W, H, 4 * k);
    LinearGradientBrush bg(PointF(0, 0), PointF(0, H), C(0xFAF5EA), C(0xF2EBDB)); c.g->FillPath(&bg, &p);
    Grain(c, p, 0x8A7A5A, 8);
    StrokeRR(c, 3 * k, 3 * k, W - 6 * k, H - 6 * k, 2.5f * k, C(0xB3261E, v.on ? 200 : 120), 1 * k);
    StrokeRR(c, 5.5f * k, 5.5f * k, W - 11 * k, H - 11 * k, 2 * k, C(0xB3261E, v.on ? 110 : 70), .6f * k);
    Color hc = C(0xB3261E, v.on ? 170 : 100); float hs = 6 * k, e = 8 * k;
    HuiCorner(c, e, e, hs, 1, 1, hc); HuiCorner(c, W - e, e, hs, -1, 1, hc); HuiCorner(c, e, H - e, hs, 1, -1, hc); HuiCorner(c, W - e, H - e, hs, -1, -1, hc);
  }
  SealStamp(c, 12 * k, 10 * k, 40 * k, v.on, v.warn, c.hoverId == H_SWITCH);
  c.hit(H_SWITCH, 10 * k, 8 * k, 44 * k, 44 * k);
  if (c.draw) Text(c, v.title, f1, v.warn ? C(0xB3261E) : v.on ? C(0x1F1A17) : C(0x6B5A4E), x0, 10 * k, colW, 19 * k, 0, true);
  float cy2 = 40 * k;
  if (v.row == 0) {
    if (c.draw) { SolidBrush kb(C(c.hoverId == H_KEY ? 0xF7E2DA : 0xFBF2EA)); c.g->FillRectangle(&kb, x0, cy2 - 8 * k, kw, 16 * k); Pen kp(C(0xB3261E), 1 * k); c.g->DrawRectangle(&kp, x0, cy2 - 8 * k, kw, 16 * k);
      Text(c, s.key, kf, C(0xB3261E), x0, cy2 - 8 * k, kw, 16 * k, 11, false); Text(c, v.aux, f2, C(0x6B5A4E), x0 + kw + 6 * k, cy2 - 8 * k, colW - kw - 6 * k, 16 * k, 0, true); }
    c.hit(H_KEY, x0, cy2 - 8 * k, kw, 16 * k);
  } else if (v.row == 1) {
    float w = TextW(c, v.aux, f2) + 12 * k;
    if (c.draw) { Pen dp(C(0xB3261E, c.hoverId == H_KEY ? 255 : 170), 1 * k); dp.SetDashStyle(DashStyleDash); c.g->DrawRectangle(&dp, x0, cy2 - 8 * k, w, 16 * k); Text(c, v.aux, f2, C(0x6B5A4E), x0, cy2 - 8 * k, w, 16 * k, 1, false); }
    c.hit(H_KEY, x0, cy2 - 8 * k, w, 16 * k);
  } else if (v.row == 2) {
    if (c.draw) {
      Pen tr(C(0xD9CBB0), 1 * k); tr.SetDashStyle(DashStyleDot); c.g->DrawLine(&tr, x0, cy2, x0 + 60 * k, cy2);
      if (v.p > 0) {  // 一笔墨痕：起笔重、收笔轻
        float L = 60 * k * (v.p > 1 ? 1 : v.p); if (L < 4 * k) L = 4 * k;
        PointF ink[4] = {PointF(x0, cy2 - 2.4f * k), PointF(x0 + L, cy2 - .6f * k), PointF(x0 + L, cy2 + .6f * k), PointF(x0, cy2 + 2.4f * k)};
        SolidBrush ib(C(v.isBgm ? 0x2F4F4F : 0x1F1A17)); c.g->FillPolygon(&ib, ink, 4); c.g->FillEllipse(&ib, x0 - 2.4f * k, cy2 - 2.4f * k, 4.8f * k, 4.8f * k);
      }
      Text(c, v.tm, ft, C(v.paused ? 0x6B5A4E : 0x1F1A17), x0 + 68 * k, cy2 - 8 * k, colW - 68 * k, 16 * k, v.paused ? 0 : 10, false);
    }
  } else if (v.row == 3) {
    float aw = TextW(c, v.aux, f2b) + 14 * k;
    if (c.draw) { SolidBrush db(C(0xB3261E)); c.g->FillRectangle(&db, x0, cy2 - 8 * k, aw, 16 * k); Text(c, v.aux, f2b, C(0xF7F1E3), x0, cy2 - 8 * k, aw, 16 * k, 1, false);
      Text(c, v.tm, fn, C(0x1F1A17), x0 + aw + 8 * k, cy2 - 8 * k, colW - aw - 8 * k, 16 * k, 10, false); }
    c.hit(v.duckIsB ? H_DUCK_B : H_DUCK_S, x0 - 2 * k, cy2 - 12 * k, colW + 4 * k, 24 * k);
  } else if (v.row == 4) {
    float aw = TextW(c, v.aux, f2b);
    if (c.draw) { Text(c, v.aux, f2b, C(c.hoverId == H_NUMFIX ? 0x7E1A14 : 0xB3261E), x0, cy2 - 8 * k, aw + 4 * k, 16 * k, 0, false); Pen ul(C(0xB3261E), 1 * k); c.g->DrawLine(&ul, x0, cy2 + 7 * k, x0 + aw, cy2 + 7 * k); }
    c.hit(H_NUMFIX, x0 - 2 * k, cy2 - 12 * k, aw + 8 * k, 24 * k);
  } else {
    float bx = x0;
    for (int i = 0; i < 3; i++) {
      bool hv = c.hoverId == v.hid[i];
      if (c.draw) { if (i == 1) { SolidBrush b(C(hv ? 0x9E1F18 : 0xB3261E)); c.g->FillEllipse(&b, bx, cy2 - 12 * k, 24 * k, 24 * k); }
        else { SolidBrush b(C(hv ? 0xF4E3D6 : 0xFBF4EA)); c.g->FillEllipse(&b, bx, cy2 - 12 * k, 24 * k, 24 * k); Pen p(C(0xB3261E), 1.2f * k); c.g->DrawEllipse(&p, bx, cy2 - 12 * k, 24 * k, 24 * k); }
        IconKind(c, v.hid[i], bx + 12 * k, cy2, 11 * k, i == 1 ? C(0xF7F1E3) : C(0xB3261E), v.anyPlaying); }
      c.hit(v.hid[i], bx, cy2 - 12 * k, 24 * k, 24 * k);
      bx += 32 * k;
    }
  }
  return SizeF(W, H);
}

// =================================================================================================
// 每款的特性（核心代码只看这张表）：播放音效 / 只放背景音乐时的帧率、是否每帧都在动、柔和投影的强度、像素风、毛玻璃、急停按钮上有字
static const SkinTraits kTraits[SK_COUNT + 1] = {
  {0, 0, false, .55f, false, false, false, ROLE_SFX},    // 0（不用）
  {15, 15, true, .55f, false, false, false, ROLE_SFX},   // 1 灵动胶囊：音浪
  {6, 4, false, .30f, false, true, true, ROLE_DUAL},      // 2 毛玻璃组件卡：进度环、倒计时
  {4, 4, false, .55f, false, false, true, ROLE_DUAL},     // 3 全能控台：进度条＋倒计时
  {4, 4, false, .55f, false, false, false, ROLE_SFX},    // 4 机械键帽：小屏里的进度
  {8, 8, true, .55f, false, false, false, ROLE_SFX},     // 5 极光弥散：光斑缓慢流动
  {4, 4, false, .55f, false, false, false, ROLE_SFX},    // 6 ON AIR 霓虹灯牌：点阵屏电平、倒计时
  {4, 4, false, .50f, false, false, false, ROLE_SFX},    // 7 赛博机甲：分段进度
  {4, 4, false, 0.f, false, false, false, ROLE_SFX},     // 8 多巴胺撞色：自己画硬投影
  {8, 4, true, 0.f, false, false, false, ROLE_SFX},      // 9 小红花贴纸：唱歌时音符上下（自己画投影）
  {4, 4, false, .50f, false, false, false, ROLE_SFX},    // 10 猫耳胶囊
  {4, 4, false, .45f, false, false, false, ROLE_SFX},    // 11 拼贴手账
  {4, 4, false, 0.f, false, false, false, ROLE_SFX},     // 12 漫画波普：自己画硬投影
  {12, 12, true, .55f, false, false, false, ROLE_SFX},   // 13 黑胶唱机：唱片转（快捷键关着时不转，见 SkinAnimFps）；1.4.0 起只管音效（原来只管背景音乐）
  {12, 12, true, 0.f, false, false, false, ROLE_SFX},    // 14 Y2K 随身听磁带：磁带轮（自己画投影）；1.4.0 起只管音效（原来只管背景音乐）
  {4, 4, false, .55f, true, false, false, ROLE_SFX},     // 15 像素游戏 HUD：血条
  {4, 4, false, .45f, false, false, false, ROLE_SFX},    // 16 国潮印章：墨痕进度
};
const SkinTraits& SkinTraitsOf(int skin) { return kTraits[(skin >= 1 && skin <= SK_COUNT) ? skin : 1]; }
// 1.3.0：按皮肤的角色取这款要显示的状态。只管音效的皮肤看不到背景音乐那一路（名称、进度、闪避都不显示），只管背景音乐的看不到音效那一路（1.4.0 起没有这种皮肤：单路的 14 款都只管音效）；
// 快捷键开关、切换键、小键盘提醒这些与曲目无关的全局状态照常。布局、画面要素、动画帧率、画廊缩略图都用它；急停（全部停止）按真实状态放在右键菜单里
XState XfRoleView(const XState& s) {
  XState r = s; int role = SkinTraitsOf(s.skin).role;
  if (role == ROLE_SFX) { r.bgm = Track(); r.duckB = 0; }
  else if (role == ROLE_BGM) { r.sfx = Track(); r.duckS = 0; }
  return r;
}
SizeF SkinLayout(int skin, Ctx& c) {
  switch (skin) {
    case SK_GLASS: return SkinGlass(c);
    case SK_CONSOLE: return SkinConsole(c);
    case SK_KEYCAP: return SkinKeycap(c);
    case SK_AURORA: return SkinAurora(c);
    case SK_NEON: return SkinNeon(c);
    case SK_CYBER: return SkinCyber(c);
    case SK_POP: return SkinPop(c);
    case SK_STICKER: return SkinSticker(c);
    case SK_CATEAR: return SkinCatear(c);
    case SK_COLLAGE: return SkinCollage(c);
    case SK_COMIC: return SkinComic(c);
    case SK_VINYL: return SkinVinyl(c);
    case SK_CASSETTE: return SkinCassette(c);
    case SK_PIXEL: return SkinPixel(c);
    case SK_SEAL: return SkinSeal(c);
    default: return SkinCapsule(c);
  }
}
int SkinAnimFps(int skin, const XState& s) {
  // 只在有东西在放时动；动的部分越小帧率越低（倒计时每秒变一次，4 帧足够跟上）
  bool sp = s.sfx.state == 1, bp = s.bgm.state == 1;
  if (!sp && !bp) return 0;
  if (skin == SK_VINYL) return s.armed ? 12 : 4;  // 唱片只在快捷键开着时转（s 已按角色只留显示的那一路：1.4.0 起是音效，原来只认背景音乐）
  const SkinTraits& t = SkinTraitsOf(skin);
  return sp ? t.fpsSfx : t.fpsBgm;
}
