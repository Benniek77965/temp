// XhhFloat：小红花音效助手的悬浮窗（16 款皮肤）。32 位 DLL，全部导出接口为 stdcall 纯 C，每个接口固定 4 个指针宽度的参数，
// 易语言用 调用桩_4参数 (接口地址, 参数1, 参数2, 参数3, 参数4)（程序集1 里的机器码调用桩，与精易模块 WV内部_调用N 同一写法）调用，不用 DLL 命令。
// 不用 CallWindowProcW：它把第一个参数当窗口句柄处理，曾实测在 Wine 里经它传 33 时 DLL 收到的不是 33；调用桩没有这个问题（tests/xftest.cpp 里按易语言子程序框架实测）。
// 悬浮窗在 DLL 自己的界面线程里运行（逐像素透明的分层窗口 + GDI+ 绘制），易语言主线程忙时悬浮窗照常拖动、照常刷新。
#pragma once
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <gdiplus.h>
#include <string>
#include <vector>
using namespace Gdiplus;

#define XF_VERSION 0x00010500  // 1.5.0：暂停、继续时悬浮窗不变宽变窄、悬停那一排按钮不挪（第二行的时间那一格按“剩余时间”“已暂停”里宽的定宽；原来 16 款里 10 款会挪，有的挪到急停上）；鼠标停在悬浮窗上显示软件账号（XF_SetOption 13 交来，只显示账号本身；同原悬浮窗挂在各子控件上的工具提示）——只有图标的按钮照旧提示自己的作用，悬浮窗本身的其余地方（空白处、开关、切换键等；不算四周的柔和投影）0.6 秒后在悬浮窗上方显示账号，在这些地方之间移动不收不闪，按下（左键、右键）后要移出再回来才再显示，停着不动约 10 倍双击时间（默认 5 秒）后自己收起（同系统工具提示的默认、原悬浮窗的工具提示）；顺带：显示着的提示跟上按钮的意思（暂停 ↔ 继续）、按钮与悬浮窗的位置大小（原来留在旧处、显示旧字；左右只差不到 4 像素时不动，免得随倒计时的字宽抖）。1.4.0：单路的 14 款皮肤统一只管音效（黑胶唱机、磁带原来只管背景音乐：放音效时只显示待机）；磁带的读数放大到 16 号字、闪避中照常显示倒计时，闪避印章移到标签纸右下角、按 GDI+ 的画法量宽（原来压住读数、长的字伸出印章框）；皮肤画廊的缩略图一律按“快捷键已开启”画（悬浮窗本身照常是真实状态），画廊签名补回被注释吞掉的小键盘与两路闪避。1.3.3：右键菜单开着时悬浮窗不再被提到菜单上面——毛玻璃背景的层次整理（把卡片提到置顶层最上面）、选项 3 的换层、找回悬浮窗的提层、被挪出置顶层后的恢复、首次使用提示，都推迟到菜单关掉之后；菜单开着时不新建毛玻璃背景（真机上顶层弹出菜单没有所有者，见 xf_core.cpp g_inMenu 前的说明）。1.3.2：右键菜单可加一项「截屏」（宿主用 XF_SetOption 12 打开，紧挨在「打开主面板」下面；选了发事件 21，由宿主截屏），默认没有。1.3.1：个别系统上画不出字（悬浮窗、右键菜单只剩图形）时逐级退路——精绘文字每款字先整条自检、画不出就改走 GDI+，GDI+ 也画不出、或字体缺字时改走 GDI（按系统字体链接换字体）；诊断见 XF_GetInfo 102。1.3.0：按皮肤的角色显示与控制（只管音效 / 只管背景音乐 / 两路都管，见 XfRoleView），有东西在放时右键菜单多一项「急停」。1.2.0：多显示器与位置记忆（贴边不再跳到相邻那块屏的最远端、按显示布局记位置、找回悬浮窗、贴画面失败自动重试、窗口被别的模块改动后自己恢复）；易语言 1.1.0 起就能用，1.2.0 起才用新增的选项（见 README「多显示器与位置记忆」）
// 1.1.0：16 款皮肤（去掉音浪悬浮球、新增 9 款、按推荐顺序重排编号）；易语言要求 1.1.0 及以上（皮肤编号与托盘菜单文字序号随之变化）

// ---- 事件（DLL → 易语言回调 int __stdcall 回调 (事件, 参数)，在 DLL 的界面线程上调用，易语言应只做投递）
enum {
  XE_TOGGLE_HOTKEYS = 1,  // 点了开关：切换快捷键开启状态
  XE_SET_KEY = 2,         // 设置“切换快捷键开启状态”的快捷键
  XE_OPEN_PANEL = 3,      // 打开主面板（双击或“主面板”按钮）
  XE_MENU = 4,            // 右键：弹出托盘菜单
  XE_PAUSE_ALL = 5,       // 全部暂停 / 全部继续
  XE_STOP_ALL = 6,        // 急停：音效和背景音乐都停
  XE_BGM_PREV = 7,
  XE_BGM_TOGGLE = 8,      // 背景音乐 播放 / 暂停
  XE_BGM_NEXT = 9,
  XE_DUCK_SFX = 10,       // 点了“闪避中”（音效那一路）：取消闪避；说话闪避时打开闪避设置
  XE_NUMLOCK = 11,        // 打开小键盘（NumLock）
  XE_MOVED = 12,          // 拖动或贴边结束：位置变了（用 XF_GetInfo 取）
  XE_DUCK_BGM = 13,       // 点了“闪避中”（背景音乐那一路）
  XE_DUCK_START = 14,     // 没在闪避时点了“闪避”：开始手动闪避
  XE_SFX_TOGGLE = 15,     // 音效 暂停 / 继续
  XE_SKIN = 16,           // 右键菜单选了皮肤（参数＝1～16）
  XE_HIDE = 18,           // 右键菜单“隐藏悬浮窗”
  XE_EXIT = 19,           // 右键菜单“退出”：退出整个程序（同托盘菜单的“退出”）
  XE_SCALE = 20,          // 右键菜单“大小”或 Ctrl＋滚轮：当前这款改为 参数 %
  XE_SHOT = 21,           // 1.3.2：右键菜单“截屏”（宿主用 XF_SetOption 12 打开这一项，收到后自己截屏）
};

// ---- 选项（XF_SetOption）
enum {
  XO_DOCK = 2,             // 贴边：0 不贴 1 左 2 右 3 上（启动时恢复）
  XO_TOPMOST = 3,          // 1＝总在最前（默认）
  XO_TEST_FREEZE = 100,    // 测试：动画时刻固定为给定毫秒（0＝按真实时间）
  XO_TEST_HOVER = 101,     // 测试：-1＝按鼠标；0/1＝强制悬停状态
  XO_TEST_DARK = 102,      // 测试：-1＝跟随系统；0/1＝强制浅色 / 深色
  XO_TEST_DOCKOPEN = 103,  // 测试：贴边时 1＝强制展开
  XO_TEST_STARTDELAY = 104, // 测试：界面线程建窗口前先等这么多毫秒（模拟冷启动很慢）
  XO_TEST_STARTWAIT = 105,  // 测试：XF_Start 最多等这么多毫秒（0＝默认 15 秒）
  XO_TEST_FINE = 106,       // 测试：精绘文字 低 8 位 0 关 1 开；第 8～19 位 伽马×100，第 20～31 位 对比度×100（0＝不改）
  XO_TEST_NAMEFONT = 115,   // 测试：1＝曲名用的字体故意与界面字体不同（大 15%），查“悬停时标题换了字体”
  XO_TEST_TEXTFAIL = 116,   // 测试：模拟个别系统上画不出字——位 0 精绘贴图不起作用，位 1 GDI+ 画字不起作用（设了就重新自检）
  XO_MEMFILE = 9,           // 1.2.0：本机位置记忆文件（UTF-8 路径；按显示布局各记各的位置，见 README「多显示器与位置记忆」）
  XO_RECOVER = 10,          // 1.2.0：找回悬浮窗——移到鼠标旁边、不贴边、显示出来，记下位置并报“位置变了”
  XO_SHOTITEM = 12,         // 1.3.2：右键菜单里有没有「截屏」（1＝有、0＝没有，默认没有；宿主有截屏功能时交代，XF_Start 前后都行，下次弹出菜单时生效）
  XO_HINTSIG = 11,          // 1.2.0：XF_Start 交来的位置（账号配置里那份）是在哪种显示布局下存的（布局签名；0＝不知道：旧版本存的）
  XO_ACCOUNT = 13,          // 1.5.0：软件账号（UTF-8 指针；空＝没有，不提示）。去掉控制字符与首尾空白、最多 64 个字；XF_Start 前后交代都行，没变时什么也不做
};
// ---- XF_Start 的标志
enum { XS_LEGACY = 1, XS_HIDDEN = 2, XS_MEMORY = 4 };  // 1 原悬浮窗存的坐标 2 启动后先不显示 4（1.2.0）按显示布局记忆位置：本机记忆优先，左、顶只是账号配置里那份

// ---- 信息（XF_GetInfo）
enum { XI_X = 1, XI_Y = 2, XI_VISIBLE = 3, XI_SKIN = 4, XI_DOCK = 5, XI_VERSION = 7, XI_DPI = 8, XI_HWND = 9, XI_THREAD = 10, XI_WIDTH = 11, XI_HEIGHT = 12,
       XI_ULWFAIL = 94, XI_POSSRC = 95, XI_LAYOUT = 96, XI_MONITORS = 97, XI_ONPRIMARY = 98, XI_MEMCOUNT = 99,  // 94～99（1.2.0）：贴画面失败次数、位置的来源、显示布局签名、显示器个数、在主屏上、本机记着几种布局
       XI_SELFFIX = 100, XI_PROCTAKEN = 101,   // 100、101（1.2.0）：窗口被别的模块改动后自己恢复的次数（悬浮窗、提示、画廊合计）、悬浮窗的窗口过程被别的模块接管（只记录）
       XI_TIPTEXT = 103 };  // 103（1.5.0，诊断与测试）：显示着的提示的文字（UTF-8 指针，静态缓冲，没有提示时为空串）
// 正在显示的提示（XF_GetInfo 17）：文字序号；另有 9999 首次使用提示、9998 软件账号（1.5.0）；-1＝没有
enum { TIP_HINT = 9999, TIP_ACCOUNT = 9998 };
// 位置的来源（XI_POSSRC）：1 本机记忆 2 账号里的位置（这台电脑、同一种显示布局下存的）3 账号里的位置（别的电脑或别的显示布局下存的，在主屏上）4 账号里的位置（别的电脑或别的显示布局下存的、不在主屏：改用默认位置）
// 5 账号里的位置（旧版本存的，没记布局）6 原悬浮窗的位置（逐轴：在主屏范围里的照用，否则那一轴按默认）7 默认位置 8 找回 9 拖动；0＝没用位置记忆（标志里没有 4）
enum { PS_MEMORY = 1, PS_SAME = 2, PS_PRIMARY = 3, PS_REJECTED = 4, PS_UNKNOWN = 5, PS_LEGACY = 6, PS_DEFAULT = 7, PS_RECOVER = 8, PS_DRAG = 9 };

// ---- 文字序号（xf_i18n.cpp；19 个语种）
enum {
  S_HK, S_ON, S_OFF, S_HKON, S_HKOFF, S_TOGGLE, S_UNSET, S_DUCK, S_VDUCK, S_DUCKBTN, S_NUMLOCK, S_NUMFIX, S_NUMSHORT, S_NUMCUTE,
  S_STOP, S_PAUSE, S_PANEL, S_BGM, S_SFX, S_IDLEBGM, S_IDLESFX, S_IDLESHORT, S_ENDING, S_LEFT, S_SLEEP, S_WAKE, S_LIGHT, S_READY,
  S_SETKEY, S_SETNOW, S_PAUSED, S_RESUME,
  // 与易语言的约定（XF_Text 按序号取）：32 子菜单标题，33～48 十六款皮肤名（按推荐顺序，即皮肤编号 1～16），50 预览全部皮肤…；
  // 这几个序号不能动——其余的排在后面，加删文字只挪它们
  M_SKINS, M_SKIN1, M_SKIN2, M_SKIN3, M_SKIN4, M_SKIN5, M_SKIN6, M_SKIN7, M_SKIN8,
  M_SKIN9, M_SKIN10, M_SKIN11, M_SKIN12, M_SKIN13, M_SKIN14, M_SKIN15, M_SKIN16,
  M_GALHINT, M_GALLERY,              // 皮肤画廊：画廊里的操作说明、菜单项“预览全部皮肤…”（＝50）
  M_SETKEY, M_OPEN, M_HIDE, M_EXIT,  // 右键菜单（最后一项原为“更多选项…”，改为“退出”）
  M_PREV, M_NEXT, M_PLAY,            // 只有图标的按钮的提示
  M_SIZE,                            // 右键菜单“大小”
  M_HINT,                            // 首次使用提示
  M_UNDUCK,                          // 只有图标的“取消闪避”按钮的提示（悬停那一排按钮里，闪避中才出现）
  M_RECOVER,                         // 托盘菜单“找回悬浮窗”（1.2.0；＝61，易语言按这个序号取）
  M_STOPALL,                         // 1.3.0：右键菜单“急停（全部停止）”（有东西在放时才有；排在最后，不挪动与易语言约定的序号）
  M_SHOT,                            // 1.3.2：右键菜单“截屏”（宿主用 XF_SetOption 12 打开才有；同样排在最后）
  S_COUNT
};
int I18nLangIndex(const char* code);  // 未知语种返回英文
const char* I18nLangCode(int idx);
bool I18nRtl(int idx);
const char* I18nUtf8(int idx, int key);
std::wstring I18n(int idx, int key);
int I18nCount();

// ---- 状态
struct Track {
  int state = 0;  // 0 停止 1 播放 2 暂停
  std::wstring name;
  int posMs = 0, lenMs = 0, clipStartMs = 0, clipEndMs = 0, level = 0;
  DWORD stamp = 0;  // 收到 posMs 时的 GetTickCount
};
// ---- 皮肤编号（按推荐顺序；还没上线，编号可以重排。上线后编号冻结：新增往后加，换顺序只改菜单、画廊的排列，不改编号）
// 4 组 × 4 款（画廊一行一组、菜单里组与组之间有分隔线）：实用高效 1～4、氛围潮流 5～8、萌趣生活 9～12、复古文化 13～16
enum {
  SK_CAPSULE = 1, SK_GLASS, SK_CONSOLE, SK_KEYCAP,     // 灵动胶囊（默认）、毛玻璃组件卡、全能控台、机械键帽
  SK_AURORA, SK_NEON, SK_CYBER, SK_POP,                // 极光弥散、ON AIR 霓虹灯牌、赛博机甲、多巴胺撞色
  SK_STICKER, SK_CATEAR, SK_COLLAGE, SK_COMIC,         // 小红花贴纸、猫耳胶囊、拼贴手账、漫画波普
  SK_VINYL, SK_CASSETTE, SK_PIXEL, SK_SEAL,            // 黑胶唱机、Y2K 随身听磁带、像素游戏 HUD、国潮印章
  SK_COUNT = SK_SEAL
};
// 每款皮肤的特性：核心代码（动画、阴影、大小档、毛玻璃、提示）只看这张表，不按编号写特例
struct SkinTraits {
  int fpsSfx, fpsBgm;   // 播放音效 / 只放背景音乐时要的帧率（0＝不需要动画）
  bool cont;            // 播放时每帧都在动（画面要素里带上帧号；只有倒计时在变的皮肤不用）
  float shadow;         // 柔和投影的强度（0＝皮肤自己画投影）
  bool pixel;           // 像素风：大小只有 100%／150%／200%（整数倍像素）
  bool glass;           // 毛玻璃：系统允许时卡片下面放实时模糊的背景窗口
  bool stopLabeled;     // 急停按钮上有字（悬停不再弹文字提示）
  int role;             // 1.3.0：0 两路都管（音效、背景音乐各自显示、各自控制）1 只管音效 2 只管背景音乐（见 XfRoleView）；1.4.0 起单路的 14 款都是 1，没有皮肤用 2
};
const SkinTraits& SkinTraitsOf(int skin);  // 编号超出范围时按第 1 款
enum { ROLE_DUAL = 0, ROLE_SFX = 1, ROLE_BGM = 2 };  // 1.3.0：皮肤的角色（SkinTraits::role）
struct XState {
  int skin = 1;
  int scale[SK_COUNT + 1] = {100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100};  // 各款皮肤的大小（百分比，下标 1～16）
  bool armed = true;
  std::wstring key;   // 切换键名，空＝没设
  bool numlock = false;
  Track sfx, bgm;
  int duckS = 0, duckB = 0;  // 0 没有 1 闪避中 2 说话闪避中
  bool loop = false;
  int order = 0;
  int lang = 0;
  bool rtl = false;
};
XState XfRoleView(const XState& s);  // 1.3.0：这款皮肤要显示的状态：只管音效的看不到背景音乐那一路（名称、进度、闪避），只管背景音乐的看不到音效那一路；与曲目无关的全局状态照常

// ---- 绘制上下文
struct Hit { int id; RectF r; };
enum {  // 可点区域
  H_SWITCH = 1, H_KEY, H_NUMFIX, H_PAUSE, H_STOP, H_OPEN, H_DUCK_S, H_DUCK_B, H_DUCK_START, H_BPREV, H_BTOGGLE, H_BNEXT, H_STOGGLE,  // 14 原是悬浮球（已去掉），空着
};
struct Fonts;
// 长曲名滚动（参照主流播放器：只滚放不下的曲名，先停一下再滚到结尾、停住后回到开头；鼠标在悬浮窗上时循环滚；系统关闭了动画时不滚）
struct Marquee { std::wstring text[2]; DWORD start[2] = {0, 0}; bool active = false; bool reduce = false; int test = -1; };
// 当前这款皮肤的大小（百分比）：80～200 几档；像素风只用 100／150／200（非整数倍像素会发糊）
inline int XfScalePct(const XState& s) {
  int v = (s.skin >= 1 && s.skin <= SK_COUNT) ? s.scale[s.skin] : 100;
  if (v < 50 || v > 300) v = 100;
  if (SkinTraitsOf(s.skin).pixel) v = v < 125 ? 100 : v < 175 ? 150 : 200;
  return v;
}
struct Ctx {
  Graphics* g = nullptr;   // 绘制（量尺寸时为测量用的 Graphics）
  bool draw = false;
  float k = 1;             // DPI 缩放
  const XState* s = nullptr;
  int lang = 0;
  bool rtl = false;
  float W = 0, H = 0;      // 内容尺寸（设计单位 × k）
  DWORD now = 0;           // 动画时刻（毫秒）
  bool hover = false;
  bool anim = true;        // 装饰性的动（音浪、转动、流光）：系统设置里关闭了动画时为假，画成静止的样子
  int hoverId = 0, pressId = 0;
  bool dark = false;       // 系统深色（毛玻璃卡用）
  bool docked = false;     // 贴边收起形态
  int dockEdge = 0;
  std::vector<Hit>* hits = nullptr;
  Fonts* fonts = nullptr;
  Marquee* mq = nullptr;   // 曲名滚动状态（界面线程）
  // 测试（文字记录，对比度检查用）：图层里的坐标加上这段偏移才是画布坐标；所在图层之后要去色时，记录的颜色按同样的去色换算；
  // logSkip＝这段字只是光晕的来源（本身不显示），不记
  float logDx = 0, logDy = 0, logDesat = 0, logBright = 1; bool logSkip = false; char logKind = 0;  // logKind 非 0：记录的种类改成它
  std::wstring T(int key) const { return I18n(lang, key); }
  float u(float v) const { return v * k; }
  void hit(int id, float x, float y, float w, float h) const { if (hits) hits->push_back({id, RectF(x, y, w, h)}); }
};

// ---- 字体（xf_gfx.cpp）
enum { FR_UI = 0, FR_NUM = 1, FR_PIX = 2 };
struct Fonts {
  void setLang(int lang);
  void setFontDir(const std::wstring& dir);
  // 界面文字：按语种的字体（简体中文有字体包时用鸿蒙黑体）；名称（音效名、歌名）按内容挑能显示全部字符的字体
  Font* ui(float px, bool bold);
  Font* name(const std::wstring& text, float px, bool bold);
  Font* num(float px, bool bold);
  Font* cjkPixel(float px);  // 像素皮肤：不抗锯齿的点阵字（宋体等）
  std::wstring pixelFamily();
  void clear();
  ~Fonts();
  int lang = 0;
  std::wstring fontDir;
  // 内部
  PrivateFontCollection* hos = nullptr;  // 鸿蒙黑体（只在简体中文、找到字体包时载入）
  std::wstring hosMediumFamily, hosBoldFamily;
  bool hosTried = false;
  std::vector<std::wstring> hosFiles;
  struct Cached { std::wstring fam; float px; int style; Font* f; };
  std::vector<Cached> cache;
  struct NameCached { std::wstring text; float px; bool bold; Font* f; };
  std::vector<NameCached> names;
  std::wstring uiFam;            // ui() 实际用的字体（查字是否齐全用）
  bool hosOk = true;             // 鸿蒙黑体能正常画出来（自检）
  int hosWhy = 0;                // 没用上鸿蒙黑体的原因：3 字体目录里没有文件 4 载入失败或自检画不出字
  bool hosIncomplete = false; DWORD hosRetry = 0;  // 字体包文件上次看时还不完整（如正在解压）：隔一会儿再看，写完了自动用上
  bool hosCheck();               // 每帧开头（XfSyncFontDir）：字体包里的字坏了就换回系统字体；没写完的到时候再试。返回是否变了（要重排）
  void dropHos(int why);
  bool selfTest(Font* f);
  Font* get(const std::wstring& fam, float px, int style, FontCollection* col = nullptr);
  std::vector<std::wstring> uiList();
  bool covers(const std::wstring& fam, const std::wstring& text, int* missing);
};

// ---- 绘制工具（xf_gfx.cpp）
Color C(unsigned rgb, int a = 255);
void RoundRectPath(GraphicsPath& p, float x, float y, float w, float h, float r);
void RoundRectPath4(GraphicsPath& p, float x, float y, float w, float h, float tl, float tr, float br, float bl);
float TextW(Ctx& c, const std::wstring& t, Font* f);
float TextH(Font* f);
// 画一行文字：超出宽度时省略号；RTL 语种按从右到左排；align 0 起始 1 居中 2 末尾
void Text(Ctx& c, const std::wstring& t, Font* f, const Color& col, float x, float y, float w, float h, int align = 0, bool ell = true);
void Flower(Ctx& c, float cx, float cy, float s, bool grey);
void FlowerMono(Ctx& c, float cx, float cy, float s, const Color& pet, const Color& core);
void Ring(Ctx& c, float cx, float cy, float d, float sw, float p, const Color& track, const Color& a, const Color& b, bool full = false);
void Vinyl(Ctx& c, float cx, float cy, float d, const Color& label, float rot);
void IconPause(Ctx& c, float cx, float cy, float s, const Color& col);
void IconPlus(Ctx& c, float cx, float cy, float s, const Color& col, float stroke);  // 加号（画线，不用字形：小字号下各字体的“+”大小差别很大）
int XfFontState();
// 精绘文字（xf_fine.cpp）：与设计稿同一种画法；false＝这段文字不支持，调用方改走 GDI+
bool XfFineMeasure(Font* font, const std::wstring& t, float* w);
bool XfFineDraw(Ctx& c, const std::wstring& t, Font* font, const Color& col, float x, float y, float w, float h, int align);
void XfFineSet(bool on, float gamma, float contrast);
bool XfFineEnabled();
void XfFineReset();
int XfFineBroken();              // 有字体没通过精绘自检（改走 GDI+）
int XfFinePkgBad();              // 字体包里的字形坏了（见 xf_fine.cpp g_pkgBad）
bool XfFontFileComplete(const std::wstring& path);  // 字体文件完整（表目录都在文件范围之内）
void XfFineTestFail(int bits);   // 测试：见 XO_TEST_TEXTFAIL
extern int g_testTextFail;
extern bool g_shotItem;          // 1.3.2：右键菜单有「截屏」（XO_SHOTITEM）
int XfTextPathInfo();            // 诊断（XF_GetInfo 102）：位 0 有字体没通过精绘自检 位 1 GDI+ 画字自检没通过（一律走 GDI）位 2 用 GDI 画过字
void XfTextTestFail(int bits);   // 测试：重新自检（清掉各级缓存）
bool XfGdiTextImage(Ctx& c, const std::wstring& t, Font* f, const Color& col, float x, float y, float w, float h, int a);  // 斜着画的字在 GDI+ 画不出字时的退路（见 xf_gfx.cpp）
extern volatile bool g_testNoText;  // 测试：不画文字（对比度检查用：有字图 − 无字图 ＝ 文字像素）
extern volatile bool g_testNoDots;  // 测试：点阵屏不打点（对比度检查用它找出点阵字本来的笔画范围）
extern float g_testNameScale;  // 测试：见 XO_TEST_NAMEFONT
extern bool g_glassLiveDraw;  // 毛玻璃组件卡这一帧按“有实时模糊”画（底色 84%，见 xf_core.cpp 毛玻璃一节）
extern wchar_t g_testTextLog[260];    // 测试：每段文字的颜色与位置（画布像素）记到这个文件（对比度逐段检查）
extern bool g_testLogNow;          // 测试：只在截图的那一次绘制里记（窗口平时的重画不记，免得混进别的状态、别的缩放）
// 测试：记一段字。kind：T 普通文字 P 像素字 O 熄灭的灯管（只有轮廓）S 印章；x y w h 是当前坐标系里的框（含旋转、镜像，记的是外接框）
void XfTestLog(Ctx& c, char kind, const Color& col, float x, float y, float w, float h, float px, int style, const std::wstring& t);
void XfFineSetCacheLimit(size_t n);
void XfMenuTheme(int skin, bool dark, unsigned* bg, unsigned* fg, bool* square);  // 菜单 / 提示的配色（跟皮肤）
// 右键菜单（xf_menu.cpp）
bool XfMenuMeasure(MEASUREITEMSTRUCT* mi, Ctx& base);
bool XfMenuDraw(DRAWITEMSTRUCT* di, Ctx& base);
int XfMenuRun(HWND h, int sx, int sy, Ctx& base, const XState& s, int test);
bool XfMenuEvent(int cmd, int* ev, int* arg);
int XfMenuSkinOf(int cmd);       // 菜单命令是第几款皮肤（0＝不是）
bool XfMenuIsGallery(int cmd);   // 菜单命令是“预览全部皮肤…”
bool XfMenuSnapshot(Ctx& base, const XState& s, const wchar_t* path);
bool XfFontInfo(Font* f, std::wstring& fam, int& style);  // 字体对象是用什么族名、字形建的
FontFamily* XfFamilyOf(Fonts* fonts, Font* f);  // 字体对象的字体族：新建一份（调用方 delete）。不要用 Font::GetFamily，见 xf_gfx.cpp
void XfFineRegisterFile(const std::wstring& fam, bool bold, const std::wstring& path);  // 字体包里的字体：族名＋粗细 → 文件
long long XfFineDebugGlyph(Font* font, wchar_t ch, unsigned char* buf, int cap);  // 简体中文界面实际用的字体：0 非简体中文 1 鸿蒙黑体（字体包）2 系统字体（没有字体目录）3 系统字体（目录里没有鸿蒙黑体文件）4 系统字体（载入失败或自检画不出字）
void IconPlay(Ctx& c, float cx, float cy, float s, const Color& col);
void IconStop(Ctx& c, float cx, float cy, float s, const Color& col);
void IconOpen(Ctx& c, float cx, float cy, float s, const Color& col);
void IconDuck(Ctx& c, float cx, float cy, float s, const Color& col);
void IconNote(Ctx& c, float cx, float cy, float s, const Color& col);
void IconKeypad(Ctx& c, float cx, float cy, float s, const Color& col);
void IconPower(Ctx& c, float cx, float cy, float s, const Color& col);
void IconLoop(Ctx& c, float cx, float cy, float s, const Color& col);
void IconPrev(Ctx& c, float cx, float cy, float s, const Color& col);
void IconNext(Ctx& c, float cx, float cy, float s, const Color& col);
void FillRR(Ctx& c, float x, float y, float w, float h, float r, const Brush& b);
void StrokeRR(Ctx& c, float x, float y, float w, float h, float r, const Color& col, float sw, bool dash = false);
float Wave(int i, DWORD now, int level, bool playing);  // 0..1 的音浪高度

// ---- 像素与特效（xf_gfx.cpp）
struct PixBuf {  // 预乘 BGRA
  int w = 0, h = 0;
  std::vector<unsigned> px;
  void init(int W, int H) { w = W; h = H; px.assign((size_t)W * H, 0); }
};
void BoxBlurAlpha(std::vector<unsigned char>& a, int w, int h, int r);
// 把 src 的透明度做成阴影 / 光晕（颜色 col，模糊半径 r，偏移 dx dy，强度 0..1），画在 dst 下面
void ShadowUnder(PixBuf& dst, const PixBuf& src, int r, int dx, int dy, unsigned rgb, float strength);
void GlowAdd(PixBuf& dst, const PixBuf& src, int r, unsigned rgb, float strength);
void DilateWhiteUnder(PixBuf& dst, int radius, unsigned rgb);  // 贴纸白边
void Desaturate(PixBuf& b, float amount, float bright);
// 用 GDI 不抗锯齿地写一行点阵字，返回 1 位遮罩（w×h），用于像素皮肤
bool PixelTextMask(const std::wstring& family, int px, const std::wstring& text, std::vector<unsigned char>& mask, int& w, int& h);
std::wstring Utf8ToW(const char* s);
std::string WToUtf8(const std::wstring& w);
std::wstring FmtMs(int ms, bool neg, bool twoDigitMin);
std::wstring Fmt1(const std::wstring& tpl, const std::wstring& a);
void Fmt1Parts(const std::wstring& tpl, std::wstring& pre, std::wstring& post);

// ---- 皮肤（xf_skins.cpp）：一次布局，量尺寸时 draw＝false，绘制时 draw＝true；返回内容尺寸（已乘 k）
SizeF SkinLayout(int skin, Ctx& c);
int SkinAnimFps(int skin, const XState& s);   // 播放中需要的帧率（0＝不需要动画；系统关闭了动画时一律 0，见 xf_core.cpp）

// ---- 轨道换算
struct TrackView { bool on = false, paused = false; float p = 0; int remainMs = 0, elapsedMs = 0, totalMs = 0; };
TrackView ViewOf(const Track& t, DWORD now);
