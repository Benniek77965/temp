// 绘制工具：字体（按语种挑字体，名称按内容挑能显示全部字符的字体——GDI+ 画字不会自动换字体）、文字（RTL 语种从右到左）、
// 图形、图标、阴影 / 光晕 / 贴纸白边、点阵字。全部只在 DLL 的界面线程里调用。
#include "xf.h"
#include <map>
// 字体对象 → 建它时要的族名与字形（精绘文字按这个找字体文件；不用 Font::GetStyle：有的实现把 Medium 也报成粗体）
static std::map<Font*, std::pair<std::wstring, int>> g_fontInfo;
#include <math.h>
#include <algorithm>

Color C(unsigned rgb, int a) { return Color((BYTE)(a < 0 ? 0 : a > 255 ? 255 : a), (BYTE)(rgb >> 16), (BYTE)(rgb >> 8), (BYTE)rgb); }

std::wstring Utf8ToW(const char* s) {
  if (!s || !*s) return L"";
  int n = MultiByteToWideChar(CP_UTF8, 0, s, -1, nullptr, 0);
  if (n <= 1) return L"";
  std::wstring w((size_t)n - 1, L'\0');
  MultiByteToWideChar(CP_UTF8, 0, s, -1, &w[0], n);
  return w;
}
std::string WToUtf8(const std::wstring& w) {
  if (w.empty()) return "";
  int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
  std::string s((size_t)n, '\0');
  WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n, nullptr, nullptr);
  return s;
}
std::wstring FmtMs(int ms, bool neg, bool twoDigitMin) {
  if (ms < 0) ms = 0;
  int sec = (ms + 999) / 1000;  // 剩余时间向上取整：还剩 0.2 秒时显示 0:01，到 0 才显示 0:00
  int m = sec / 60, s = sec % 60;
  std::wstring r = neg ? L"-" : L"";
  if (twoDigitMin && m < 10) r += L'0';
  { wchar_t d[12]; int n = 0; int v = m; do { d[n++] = (wchar_t)(L'0' + v % 10); v /= 10; } while (v && n < 11); while (n) r += d[--n]; }
  r += L':';
  r += (wchar_t)(L'0' + s / 10); r += (wchar_t)(L'0' + s % 10);
  return r;
}
std::wstring Fmt1(const std::wstring& tpl, const std::wstring& a) {
  size_t p = tpl.find(L"{0}");
  if (p == std::wstring::npos) return tpl;
  return tpl.substr(0, p) + a + tpl.substr(p + 3);
}
void Fmt1Parts(const std::wstring& tpl, std::wstring& pre, std::wstring& post) {
  size_t p = tpl.find(L"{0}");
  if (p == std::wstring::npos) { pre = L""; post = tpl; return; }
  pre = tpl.substr(0, p); post = tpl.substr(p + 3);
}

TrackView ViewOf(const Track& t, DWORD now) {
  TrackView v;
  if (t.state == 0) return v;
  v.on = true; v.paused = (t.state == 2);
  int st = t.clipStartMs > 0 ? t.clipStartMs : 0;
  int en = (t.clipEndMs > 0 && (t.lenMs <= 0 || t.clipEndMs <= t.lenMs)) ? t.clipEndMs : t.lenMs;
  int pos = t.posMs;
  if (t.state == 1 && t.stamp) {  // 播放中：两次推送之间按经过的时间往前推，倒计时每秒走得匀
    DWORD d = now - t.stamp;
    if (d < 5000) pos += (int)d;
  }
  if (en > 0 && pos > en) pos = en;
  if (pos < st) pos = st;
  v.totalMs = en > st ? en - st : 0;
  v.elapsedMs = pos - st;
  v.remainMs = en > 0 ? en - pos : 0;
  v.p = v.totalMs > 0 ? (float)v.elapsedMs / (float)v.totalMs : 0.f;
  if (v.p < 0) v.p = 0;
  if (v.p > 1) v.p = 1;
  return v;
}

static const float WV[14] = {.38f, .72f, .52f, .96f, .62f, .84f, .44f, .68f, .92f, .5f, .34f, .78f, .58f, .88f};
float Wave(int i, DWORD now, int level, bool playing) {
  float base = WV[((i % 14) + 14) % 14];
  if (!playing) return 0.18f + base * 0.12f;
  float lv = level > 0 ? (0.35f + 0.65f * (level > 100 ? 1.f : level / 100.f)) : 0.85f;
  float t = (float)(now % 600000u) / 1000.f;
  float m = 0.55f + 0.45f * sinf(t * 7.3f + i * 1.7f) * sinf(t * 3.1f + i * 0.9f + 1.3f);
  float v = base * (0.45f + 0.55f * m) * lv;
  if (v < 0.14f) v = 0.14f;
  if (v > 1) v = 1;
  return v;
}

void RoundRectPath(GraphicsPath& p, float x, float y, float w, float h, float r) { RoundRectPath4(p, x, y, w, h, r, r, r, r); }
void RoundRectPath4(GraphicsPath& p, float x, float y, float w, float h, float tl, float tr, float br, float bl) {
  float mx = (w < h ? w : h) / 2;
  tl = tl > mx ? mx : tl; tr = tr > mx ? mx : tr; br = br > mx ? mx : br; bl = bl > mx ? mx : bl;
  if (tl > 0) p.AddArc(x, y, tl * 2, tl * 2, 180.f, 90.f); else p.AddLine(x, y, x, y);
  if (tr > 0) p.AddArc(x + w - tr * 2, y, tr * 2, tr * 2, 270.f, 90.f); else p.AddLine(x + w, y, x + w, y);
  if (br > 0) p.AddArc(x + w - br * 2, y + h - br * 2, br * 2, br * 2, 0.f, 90.f); else p.AddLine(x + w, y + h, x + w, y + h);
  if (bl > 0) p.AddArc(x, y + h - bl * 2, bl * 2, bl * 2, 90.f, 90.f); else p.AddLine(x, y + h, x, y + h);
  p.CloseFigure();
}
void FillRR(Ctx& c, float x, float y, float w, float h, float r, const Brush& b) {
  if (!c.draw) return;
  GraphicsPath p; RoundRectPath(p, x, y, w, h, r); c.g->FillPath(&b, &p);
}
void StrokeRR(Ctx& c, float x, float y, float w, float h, float r, const Color& col, float sw, bool dash) {
  if (!c.draw) return;
  GraphicsPath p; RoundRectPath(p, x + sw / 2, y + sw / 2, w - sw, h - sw, r - sw / 2 > 0 ? r - sw / 2 : 0);
  Pen pn(col, sw);
  if (dash) { pn.SetDashStyle(DashStyleDash); }
  c.g->DrawPath(&pn, &p);
}

// ---------------- 字体 ----------------
static bool FamilyInstalled(const std::wstring& fam) {
  static std::vector<std::pair<std::wstring, bool>> memo;
  for (auto& m : memo) if (m.first == fam) return m.second;
  FontFamily ff(fam.c_str());
  bool ok = ff.GetLastStatus() == Ok && ff.IsAvailable();
  memo.push_back({fam, ok});
  return ok;
}
std::vector<std::wstring> Fonts::uiList() {
  // 与软件原生界面（多语言_工具栏字体名）各语种的字体栈一致
  const char* code = I18nLangCode(lang);
  std::vector<std::wstring> v;
  auto add = [&](const wchar_t* f) { v.push_back(f); };
  if (!strcmp(code, "ja")) { add(L"Yu Gothic UI"); add(L"Meiryo UI"); add(L"Meiryo"); }
  else if (!strcmp(code, "ko")) { add(L"Malgun Gothic"); add(L"Gulim"); }
  else if (!strcmp(code, "zh-Hant")) { add(L"Microsoft JhengHei UI"); add(L"Microsoft JhengHei"); }
  else if (!strcmp(code, "th")) { add(L"Leelawadee UI"); add(L"Leelawadee"); add(L"Tahoma"); }
  else if (!strcmp(code, "vi") || !strcmp(code, "tr") || !strcmp(code, "ru") || !strcmp(code, "ar")) { add(L"Segoe UI"); add(L"Tahoma"); add(L"Arial"); }
  else if (!strcmp(code, "hi")) { add(L"Nirmala UI"); add(L"Mangal"); add(L"Segoe UI"); }
  else { add(L"Microsoft YaHei UI"); add(L"Microsoft YaHei"); add(L"Segoe UI"); add(L"Arial"); }
  add(L"Microsoft YaHei");
  add(L"Tahoma");
  return v;
}
void Fonts::clear() {
  for (auto& c : cache) { g_fontInfo.erase(c.f); delete c.f; }
  cache.clear(); names.clear();
}
static void ReleaseHosFiles(std::vector<std::wstring>& files) {
  for (auto& f : files) RemoveFontResourceExW(f.c_str(), FR_PRIVATE, nullptr);  // 与 AddFontResourceExW 成对：换字体目录或线程退出时还回去
  files.clear();
}
Fonts::~Fonts() { clear(); delete hos; hos = nullptr; ReleaseHosFiles(hosFiles); }
void Fonts::setLang(int l) { if (l != lang) { lang = l; clear(); } }
void Fonts::setFontDir(const std::wstring& d) {
  if (d == fontDir) return;
  fontDir = d; hosTried = false; hosOk = true; hosWhy = 0; clear();
  delete hos; hos = nullptr; hosMediumFamily.clear(); hosBoldFamily.clear(); ReleaseHosFiles(hosFiles);
}
static bool FileExists(const std::wstring& p) { DWORD a = GetFileAttributesW(p.c_str()); return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY); }
// 简体中文：字体包里有鸿蒙黑体就用它（与音效页同一套字体）。查找顺序同 音效_子进程_字体_找文件：
// HarmonyOS_SansSC\ → HarmonyOS Sans\HarmonyOS_SansSC\ → HarmonyOS_Sans_SC\（现发布的字体包）→ 字体目录根；新版文件名在前
static std::wstring FindHos(const std::wstring& root, const wchar_t* weight) {
  if (root.empty()) return L"";
  std::wstring r = root;
  if (r.back() != L'\\' && r.back() != L'/') r += L'\\';
  const wchar_t* dirs[] = {L"HarmonyOS_SansSC\\", L"HarmonyOS Sans\\HarmonyOS_SansSC\\", L"HarmonyOS_Sans_SC\\", L""};
  const wchar_t* names[] = {L"HarmonyOS_SansSC_", L"HarmonyOS_Sans_SC_"};
  const wchar_t* exts[] = {L".ttf", L".otf"};
  for (auto d : dirs) for (auto n : names) for (auto e : exts) {
    std::wstring p = r + d + n + weight + e;
    if (FileExists(p)) return p;
  }
  return L"";
}
static PrivateFontCollection* LoadHos(const std::wstring& dir, std::wstring& medium, std::wstring& bold, std::vector<std::wstring>& files, int* why, bool* incomplete) {
  std::wstring fm = FindHos(dir, L"Medium"), fb = FindHos(dir, L"Bold");
  *why = 3; *incomplete = false;
  if (fm.empty() || fb.empty()) return nullptr;
  *why = 4;
  if (!XfFontFileComplete(fm) || !XfFontFileComplete(fb)) { *incomplete = true; return nullptr; }  // 文件还没写完（字体包正在解压）或被截断：先用系统字体，过一会儿再看（见 Fonts::hosCheck）
  auto* col = new PrivateFontCollection();
  if (col->AddFontFile(fm.c_str()) != Ok || col->AddFontFile(fb.c_str()) != Ok) { delete col; return nullptr; }
  int n = col->GetFamilyCount();
  if (n <= 0 || n > 8) { delete col; return nullptr; }
  FontFamily fams[8]; int found = 0;
  col->GetFamilies(n, fams, &found);
  for (int i = 0; i < found; i++) {
    WCHAR nm[LF_FACESIZE] = {0};
    fams[i].GetFamilyName(nm, 0);
    std::wstring s = nm;
    if (s.find(L"Medium") != std::wstring::npos) medium = s;
    else bold = s;
  }
  if (medium.empty()) { delete col; medium.clear(); bold.clear(); return nullptr; }
  if (bold.empty()) bold = medium;
  XfFineRegisterFile(medium, false, fm); XfFineRegisterFile(bold, true, fb); XfFineRegisterFile(bold, false, fb);  // 精绘文字直接读这两个文件
  // GDI 查字是否齐全要看得到这两个文件：只给本进程（FR_PRIVATE），不影响系统
  AddFontResourceExW(fm.c_str(), FR_PRIVATE, nullptr);
  AddFontResourceExW(fb.c_str(), FR_PRIVATE, nullptr);
  files.push_back(fm); files.push_back(fb);
  return col;
}
void Fonts::dropHos(int why) {  // 不再用鸿蒙黑体（本次运行改用系统字体）：只在每帧开头调用，那时没有字体对象还被这一帧用着
  clear(); delete hos; hos = nullptr; hosMediumFamily.clear(); hosBoldFamily.clear(); ReleaseHosFiles(hosFiles);
  hosOk = false; hosWhy = why;
}
bool Fonts::hosCheck() {
  if (hos && XfFinePkgBad()) { dropHos(4); return true; }  // 自绘发现字体包里有可见的字取不到轮廓（字形数据坏了）：这份字体 GDI+ 也画不出，换回系统字体
  if (hosIncomplete && GetTickCount() - hosRetry >= 3000) { hosIncomplete = false; hosTried = false; hosOk = true; hosWhy = 0; clear(); return true; }  // 没写完的字体包：隔 3 秒再看一次
  return false;
}
// 字体自检：真的画一个汉字，看有没有像素（个别系统上私有字体集的粗体建得出来却画不出字）
bool Fonts::selfTest(Font* f) {
  if (!f || f->GetLastStatus() != Ok) return false;
  Bitmap b(48, 32, PixelFormat32bppPARGB);
  { Graphics g(&b); g.Clear(Color(0, 0, 0, 0)); g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit); SolidBrush br(Color(255, 0, 0, 0)); g.DrawString(L"\x6d4b", 1, f, PointF(2, 2), &br); }
  BitmapData bd; Rect r(0, 0, 48, 32); int n = 0;
  if (b.LockBits(&r, ImageLockModeRead, PixelFormat32bppPARGB, &bd) == Ok) {
    for (int y = 0; y < 32; y++) { const unsigned* row = (const unsigned*)((const BYTE*)bd.Scan0 + y * bd.Stride); for (int x = 0; x < 48; x++) if (row[x] >> 24) n++; }
    b.UnlockBits(&bd);
  }
  return n >= 12;
}
// 字体对象的字体族：按族名从它原来的字体集（鸿蒙黑体是私有字体集）新建一份，调用方 delete。
// 不要用 Font::GetFamily：MinGW 的写法把 GDI+ 借出的字体族直接交给 FontFamily，析构时删掉；Windows 上对私有字体集的族这会把字体集里那份删掉，
// 之后再用这款字体就读到已释放的内存——真机自测在灯牌熄灭状态的第二次绘制闪退（GdipGetFontHeight 里读 0x80000214），Wine 里借出的是另一份引用，不出现
FontFamily* XfFamilyOf(Fonts* fonts, Font* f) {
  std::wstring fam; int style;
  if (!f || !XfFontInfo(f, fam, style)) return nullptr;
  FontCollection* col = (fonts && fonts->hos && (fam == fonts->hosMediumFamily || fam == fonts->hosBoldFamily)) ? fonts->hos : nullptr;
  FontFamily* ff = new FontFamily(fam.c_str(), col);
  if (ff->GetLastStatus() != Ok) { delete ff; return nullptr; }
  return ff;
}
bool XfFontInfo(Font* f, std::wstring& fam, int& style) {
  auto it = g_fontInfo.find(f); if (it == g_fontInfo.end()) return false;
  fam = it->second.first; style = it->second.second; return true;
}
Font* Fonts::get(const std::wstring& fam, float px, int style, FontCollection* col) {
  for (auto& c : cache) if (c.fam == fam && fabsf(c.px - px) < 0.01f && c.style == style) return c.f;
  Font* f = new Font(fam.c_str(), px, style, UnitPixel, col);
  if (f->GetLastStatus() != Ok || (col && !selfTest(f))) { delete f; return nullptr; }
  cache.push_back({fam, px, style, f});
  g_fontInfo[f] = {fam, style};
  return f;
}
static volatile LONG g_fontState = 0;
int XfFontState() { return (int)g_fontState; }
Font* Fonts::ui(float px, bool bold) {
  if (lang != 0) g_fontState = 0;
  else if (fontDir.empty()) g_fontState = 2;
  else if (!hosOk) g_fontState = hosWhy ? hosWhy : 4;
  if (lang == 0 && !fontDir.empty() && hosOk) {
    if (!hosTried) { hosTried = true; int why = 0; bool inc = false; hos = LoadHos(fontDir, hosMediumFamily, hosBoldFamily, hosFiles, &why, &inc); if (!hos) { hosWhy = why; if (inc) { hosIncomplete = true; hosRetry = GetTickCount(); } } }
    if (hos) {
      Font* f = bold ? get(hosBoldFamily, px, FontStyleBold, hos) : get(hosMediumFamily, px, FontStyleRegular, hos);
      if (!f && bold) f = get(hosBoldFamily, px, FontStyleRegular, hos);  // 粗体文件被登记成常规字形的情况
      if (!f && bold) f = get(hosMediumFamily, px, FontStyleBold, hos);
      if (f) { uiFam = hosMediumFamily; g_fontState = 1; return f; }
      hosOk = false; hosWhy = 4;  // 自检不过：本次运行改用系统字体
    }
    g_fontState = hosWhy ? hosWhy : 4;
  }
  for (auto& fam : uiList()) if (FamilyInstalled(fam)) { Font* f = get(fam, px, bold ? FontStyleBold : FontStyleRegular); if (f) { uiFam = fam; return f; } }
  uiFam = L"Tahoma";
  Font* f = get(L"Tahoma", px, bold ? FontStyleBold : FontStyleRegular);
  return f ? f : get(L"Arial", px, FontStyleRegular);
}
// 字体能否显示这段文字：用 GDI 查字形（GGI_MARK_NONEXISTING_GLYPHS）；代理对（表情等）不查
bool Fonts::covers(const std::wstring& fam, const std::wstring& text, int* missing) {
  HDC dc = CreateCompatibleDC(nullptr);
  HFONT hf = CreateFontW(-16, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, 0, 0, fam.c_str());
  HGDIOBJ old = SelectObject(dc, hf);
  WCHAR face[LF_FACESIZE] = {0};
  GetTextFaceW(dc, LF_FACESIZE, face);
  int miss = 0;
  // 没装这个字体时系统换成别的字体（字体名对不上）；名字对不上但 GDI+ 认得的是系统的字体替换，照常查
  if (_wcsicmp(face, fam.c_str()) != 0 && !FamilyInstalled(fam)) miss = (int)text.size() + 1;
  else {
    std::vector<WORD> gi(text.size() + 1);
    GetGlyphIndicesW(dc, text.c_str(), (int)text.size(), gi.data(), GGI_MARK_NONEXISTING_GLYPHS);
    for (size_t i = 0; i < text.size(); i++) {
      wchar_t ch = text[i];
      if (ch >= 0xD800 && ch <= 0xDFFF) continue;
      if (ch == L' ' || ch == 0x3000) continue;
      if (gi[i] == 0xFFFF) miss++;
    }
  }
  SelectObject(dc, old); DeleteObject(hf); DeleteDC(dc);
  if (missing) *missing = miss;
  return miss == 0;
}
float g_testNameScale = 1.f;  // 测试（XF_SetOption 115）：曲名用的字体故意比界面字体大一点——哪款悬停时在曲名字体与界面字体之间换来换去，尺寸就会跟着变
Font* Fonts::name(const std::wstring& text, float px, bool bold) {
  if (g_testNameScale != 1.f) { ui(px, bold); Font* t = get(uiFam.empty() ? L"Tahoma" : uiFam, px * g_testNameScale, bold ? FontStyleBold : FontStyleRegular); if (t) return t; }
  for (auto& n : names) if (n.bold == bold && fabsf(n.px - px) < 0.01f && n.text == text) return n.f;
  Font* first = ui(px, bold);
  Font* pick = nullptr;
  if (covers(uiFam, text, nullptr)) pick = first;
  else {
    const wchar_t* more[] = {L"Microsoft YaHei UI", L"Microsoft YaHei", L"Microsoft JhengHei UI", L"Malgun Gothic", L"Yu Gothic UI", L"Meiryo UI",
                             L"Segoe UI", L"Leelawadee UI", L"Tahoma", L"Nirmala UI", L"Mangal", L"Segoe UI Symbol", L"Arial"};
    std::vector<std::wstring> cand = uiList();
    for (auto m : more) cand.push_back(m);
    int best = 1 << 30; std::wstring bestFam;
    for (auto& f : cand) {
      int miss = 0;
      if (covers(f, text, &miss)) { bestFam = f; best = 0; break; }
      if (miss < best) { best = miss; bestFam = f; }
    }
    if (!bestFam.empty() && bestFam != uiFam) pick = get(bestFam, px, bold ? FontStyleBold : FontStyleRegular);
    if (!pick) pick = first;
  }
  if (names.size() > 96) names.clear();
  names.push_back({text, px, bold, pick});
  return pick;
}
Font* Fonts::num(float px, bool bold) {
  const wchar_t* list[] = {L"Bahnschrift SemiBold SemiConden", L"Bahnschrift", L"Segoe UI Semibold", L"Segoe UI", L"Arial"};
  for (auto f : list) if (FamilyInstalled(f)) {
    bool semi = wcsstr(f, L"SemiBold") || wcsstr(f, L"Semibold");
    Font* r = get(f, px, (bold && !semi) ? FontStyleBold : FontStyleRegular);
    if (r) return r;
  }
  Font* r = get(L"Tahoma", px, bold ? FontStyleBold : FontStyleRegular);
  return r ? r : ui(px, bold);
}
std::wstring Fonts::pixelFamily() {
  const char* code = I18nLangCode(lang);
  if (!strcmp(code, "ja")) return L"MS Gothic";
  if (!strcmp(code, "ko")) return L"Gulim";
  if (!strcmp(code, "zh-Hant")) return L"MingLiU";
  if (!strcmp(code, "zh-Hans") || !strcmp(code, "en") || !strcmp(code, "id") || !strcmp(code, "ms") || !strcmp(code, "fil") || !strcmp(code, "es") ||
      !strcmp(code, "pt-BR") || !strcmp(code, "fr") || !strcmp(code, "de") || !strcmp(code, "it")) return L"SimSun";
  for (auto& f : uiList()) if (FamilyInstalled(f)) return f;
  return L"Tahoma";
}
Font* Fonts::cjkPixel(float px) { Font* f = get(pixelFamily(), px, FontStyleRegular); return f ? f : ui(px, false); }

// ---------------- 文字的最后一道退路：GDI ----------------
// 个别系统上精绘文字、GDI+ 都画不出字（悬浮窗与菜单只剩图形：字体被替换成 GDI+ 不认的格式、缺字体、或某一步在那台机器上不起作用）。
// 这时改用 GDI：GDI 按系统的字体链接自己换字体，兼容面最广。先画成黑底白字的灰度图，再把亮度当覆盖率、换成文字颜色贴到画布上
static int g_gdipVerdict = -1;       // GDI+ 画字自检：-1 还没试 1 正常 0 画不出字（之后一律走 GDI）
static volatile LONG g_gdiUsed = 0;  // 诊断：用 GDI 画过字
struct GdiFontC { std::wstring fam; int px, style; HFONT hf; };
static std::vector<GdiFontC> g_gdiFonts;
struct GdiTextC { std::wstring key; int w, h; std::vector<unsigned> px; };
static std::vector<GdiTextC> g_gdiTexts;   // 画好的字（文字、字体、字号、颜色、版式、框的大小都相同时直接贴）
struct CovC { std::wstring fam, text; bool ok; };
static std::vector<CovC> g_cov;            // 这款字能不能显示这段文字（GDI 查字形）
static HFONT GdiFontOf(const std::wstring& fam, int px, int style) {
  for (auto& f : g_gdiFonts) if (f.px == px && f.style == style && f.fam == fam) return f.hf;
  if (g_gdiFonts.size() > 24) { for (auto& f : g_gdiFonts) DeleteObject(f.hf); g_gdiFonts.clear(); }
  HFONT hf = CreateFontW(-px, 0, 0, 0, (style & FontStyleBold) ? FW_BOLD : FW_NORMAL, (style & FontStyleItalic) ? 1 : 0, 0, 0, DEFAULT_CHARSET,
                         OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, DEFAULT_PITCH, fam.c_str());
  g_gdiFonts.push_back({fam, px, style, hf});
  return hf;
}
static bool GdiMeasure(Font* f, const std::wstring& t, float* w) {
  std::wstring fam; int st; if (!f || !XfFontInfo(f, fam, st)) return false;
  int px = (int)lroundf(f->GetSize()); if (px < 1) px = 1;
  HDC dc = CreateCompatibleDC(nullptr); HGDIOBJ o = SelectObject(dc, GdiFontOf(fam, px, st));
  SIZE sz = {0, 0}; BOOL ok = GetTextExtentPoint32W(dc, t.c_str(), (int)t.size(), &sz);
  SelectObject(dc, o); DeleteDC(dc);
  if (!ok) return false;
  *w = (float)sz.cx; return true;
}
static bool GdipTextWorks(Ctx& c, Font* f) {
  if (g_gdipVerdict >= 0) return g_gdipVerdict == 1;
  std::wstring fam, sample = L"Ag"; int st;
  if (XfFontInfo(f, fam, st) && c.fonts && c.fonts->covers(fam, L"\x6d4b\x8bd5", nullptr)) sample = L"\x6d4b\x8bd5";
  int n = 0;
  if (!(g_testTextFail & 2)) {
    Bitmap b(96, 48, PixelFormat32bppPARGB);
    { Graphics g(&b); g.Clear(Color(0, 0, 0, 0)); g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit); SolidBrush br(Color(255, 0, 0, 0)); g.DrawString(sample.c_str(), (INT)sample.size(), f, PointF(2, 2), &br); }
    BitmapData bd; Rect r(0, 0, 96, 48);
    if (b.LockBits(&r, ImageLockModeRead, PixelFormat32bppPARGB, &bd) == Ok) {
      for (int y = 0; y < 48; y++) { const unsigned* row = (const unsigned*)((const BYTE*)bd.Scan0 + y * bd.Stride); for (int x = 0; x < 96; x++) if (row[x] >> 24) n++; }
      b.UnlockBits(&bd);
    }
  }
  g_gdipVerdict = n >= 6 ? 1 : 0;
  return g_gdipVerdict == 1;
}
// 这段文字走 GDI：GDI+ 画字自检没过，或这款字没有这段文字里的某些字（GDI 会按字体链接换字体，GDI+ 只会画方框或空白）
static bool UseGdi(Ctx& c, Font* f, const std::wstring& t) {
  if (!f || t.empty()) return false;
  if (!GdipTextWorks(c, f)) return true;
  std::wstring fam; int st; if (!c.fonts || !XfFontInfo(f, fam, st)) return false;
  for (auto& v : g_cov) if (v.fam == fam && v.text == t) return !v.ok;
  if (g_cov.size() > 256) g_cov.clear();
  bool ok = c.fonts->covers(fam, t, nullptr);
  g_cov.push_back({fam, t, ok});
  return !ok;
}
// 在框 (x,y,w,h) 里用 GDI 画一行字；对齐、从右到左、镜像画布的处理与下面 GDI+ 那条路相同。false＝没画（有旋转等，调用方照旧用 GDI+）
static bool GdiDraw(Ctx& c, const std::wstring& t, Font* f, const Color& col, float x, float y, float w, float h, int a, bool ltrForced) {
  std::wstring fam; int st; if (!XfFontInfo(f, fam, st)) return false;
  Matrix m; c.g->GetTransform(&m); REAL e[6]; m.GetElements(e);
  if (fabsf(e[1]) > 1e-4f || fabsf(e[2]) > 1e-4f) return false;
  float sc = fabsf(e[0]); if (sc <= 0) return false;
  float det = e[0] * e[3] - e[1] * e[2];
  PointF p[2] = {PointF(x, y), PointF(x + w, y + h)}; m.TransformPoints(p, 2);
  float dx0 = p[0].X < p[1].X ? p[0].X : p[1].X, dy0 = p[0].Y < p[1].Y ? p[0].Y : p[1].Y, dw = fabsf(p[1].X - p[0].X), dh = fabsf(p[1].Y - p[0].Y);
  int px = (int)lroundf(f->GetSize() * sc); if (px < 1) return false;
  int ox = (int)floorf(dx0) - 2, oy = (int)floorf(dy0), bw = (int)ceilf(dw) + 6, bh = (int)ceilf(dh) + 1;
  if (bw <= 0 || bh <= 0 || bw > 4096 || bh > 1024) return false;
  bool rtlPara = c.rtl && !ltrForced;
  int al = a; if (det < 0 && ltrForced) al = a == 0 ? 2 : a == 2 ? 0 : a;  // 镜像画布上强制从左到右的字：起始边在右（同 GDI+ 那条路）
  UINT fmt = DT_SINGLELINE | DT_VCENTER | DT_NOPREFIX | DT_NOCLIP | (rtlPara ? DT_RTLREADING : 0);
  if (al == 1) fmt |= DT_CENTER; else if ((al == 0) != rtlPara) fmt |= DT_LEFT; else fmt |= DT_RIGHT;  // 从右到左的段落里“靠近”在右边
  int lx = (int)lroundf(dx0 - ox);  // 字在图里的横向起点（2 或 3）
  wchar_t kb[96]; swprintf(kb, 96, L"%d|%d|%08X|%u|%d|%d|%d|", px, st, (unsigned)col.GetValue(), fmt, bw, bh, lx);
  std::wstring key = std::wstring(kb) + fam + L"|" + t;
  const GdiTextC* hit = nullptr;
  for (auto& g2 : g_gdiTexts) if (g2.key == key) { hit = &g2; break; }
  if (!hit) {
    if (g_gdiTexts.size() > 64) g_gdiTexts.clear();
    BITMAPINFO bi = {}; bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = bw; bi.bmiHeader.biHeight = -bh; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
    void* bits = nullptr; HDC dc = CreateCompatibleDC(nullptr); HBITMAP hb = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    if (!hb || !bits) { if (hb) DeleteObject(hb); DeleteDC(dc); return false; }
    HGDIOBJ ob = SelectObject(dc, hb); memset(bits, 0, (size_t)bw * bh * 4);
    HGDIOBJ of = SelectObject(dc, GdiFontOf(fam, px, st));
    SetBkMode(dc, TRANSPARENT); SetTextColor(dc, RGB(255, 255, 255));
    RECT rc = {(LONG)lx, 0, (LONG)lroundf(dx0 - ox + dw), bh};
    DrawTextW(dc, t.c_str(), (int)t.size(), &rc, fmt);
    GdiFlush();
    GdiTextC ent; ent.key = key; ent.w = bw; ent.h = bh; ent.px.assign((size_t)bw * bh, 0);
    const unsigned* s = (const unsigned*)bits; unsigned ca = col.GetA(), cr = col.GetR(), cg = col.GetG(), cb = col.GetB();
    for (size_t i = 0; i < ent.px.size(); i++) {
      unsigned v = s[i], cov = (v >> 16) & 255, g1 = (v >> 8) & 255, b1 = v & 255;
      if (g1 > cov) cov = g1; if (b1 > cov) cov = b1;
      if (!cov) continue;
      unsigned a2 = cov * ca / 255;
      ent.px[i] = (a2 << 24) | ((cr * a2 / 255) << 16) | ((cg * a2 / 255) << 8) | (cb * a2 / 255);
    }
    SelectObject(dc, of); SelectObject(dc, ob); DeleteObject(hb); DeleteDC(dc);
    g_gdiTexts.push_back(std::move(ent)); hit = &g_gdiTexts.back();
  }
  Bitmap bmp(hit->w, hit->h, PixelFormat32bppPARGB);
  { BitmapData bd; Rect r(0, 0, hit->w, hit->h);
    if (bmp.LockBits(&r, ImageLockModeWrite, PixelFormat32bppPARGB, &bd) != Ok) return false;
    for (int yy = 0; yy < hit->h; yy++) memcpy((BYTE*)bd.Scan0 + yy * bd.Stride, &hit->px[(size_t)yy * hit->w], (size_t)hit->w * 4);
    bmp.UnlockBits(&bd); }
  GraphicsState gs = c.g->Save(); c.g->ResetTransform();
  c.g->SetInterpolationMode(InterpolationModeNearestNeighbor); c.g->SetPixelOffsetMode(PixelOffsetModeHalf);
  c.g->DrawImage(&bmp, Rect(ox, oy, hit->w, hit->h), 0, 0, hit->w, hit->h, UnitPixel);
  c.g->Restore(gs);
  InterlockedExchange(&g_gdiUsed, 1);
  return true;
}
// 斜着画的字（印章等，画布带旋转）：精绘与上面的 GDI 那条路都只画水平的字，这里在 GDI+ 画不出字、或这款字缺字时，
// 先用 GDI 按设备像素画成一张图，再按当前变换（含旋转）贴上去。false＝不需要（照旧用 GDI+）或没画成
bool XfGdiTextImage(Ctx& c, const std::wstring& t, Font* f, const Color& col, float x, float y, float w, float h, int a) {
  if (!f || t.empty() || w <= 0 || h <= 0 || !UseGdi(c, f, t)) return false;
  std::wstring fam; int st; if (!XfFontInfo(f, fam, st)) return false;
  Matrix m; c.g->GetTransform(&m); REAL e[6]; m.GetElements(e);
  float sc = sqrtf(fabsf(e[0] * e[3] - e[1] * e[2])); if (sc <= 0) return false;  // 等比缩放（可带旋转）的缩放量
  int px = (int)lroundf(f->GetSize() * sc); if (px < 1) return false;
  int bw = (int)ceilf(w * sc) + 2, bh = (int)ceilf(h * sc) + 2;
  if (bw > 4096 || bh > 1024) return false;
  BITMAPINFO bi = {}; bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = bw; bi.bmiHeader.biHeight = -bh; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
  void* bits = nullptr; HDC dc = CreateCompatibleDC(nullptr); HBITMAP hb = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
  if (!hb || !bits) { if (hb) DeleteObject(hb); DeleteDC(dc); return false; }
  HGDIOBJ ob = SelectObject(dc, hb); memset(bits, 0, (size_t)bw * bh * 4);
  HGDIOBJ of = SelectObject(dc, GdiFontOf(fam, px, st));
  SetBkMode(dc, TRANSPARENT); SetTextColor(dc, RGB(255, 255, 255));
  RECT rc = {1, 1, bw - 1, bh - 1};
  DrawTextW(dc, t.c_str(), (int)t.size(), &rc, DT_SINGLELINE | DT_VCENTER | DT_NOPREFIX | DT_NOCLIP | (a == 1 ? DT_CENTER : a == 2 ? DT_RIGHT : DT_LEFT) | (c.rtl ? DT_RTLREADING : 0));
  GdiFlush();
  Bitmap bmp(bw, bh, PixelFormat32bppPARGB); bool ok = false;
  { BitmapData bd; Rect r(0, 0, bw, bh);
    if (bmp.LockBits(&r, ImageLockModeWrite, PixelFormat32bppPARGB, &bd) == Ok) {
      const unsigned* s = (const unsigned*)bits; unsigned ca = col.GetA(), cr = col.GetR(), cg = col.GetG(), cb = col.GetB();
      for (int yy = 0; yy < bh; yy++) {
        unsigned* d = (unsigned*)((BYTE*)bd.Scan0 + yy * bd.Stride);
        for (int xx = 0; xx < bw; xx++) {
          unsigned v = s[(size_t)yy * bw + xx], cov = (v >> 16) & 255, g1 = (v >> 8) & 255, b1 = v & 255;
          if (g1 > cov) cov = g1; if (b1 > cov) cov = b1;
          unsigned a2 = cov * ca / 255;
          d[xx] = a2 ? ((a2 << 24) | ((cr * a2 / 255) << 16) | ((cg * a2 / 255) << 8) | (cb * a2 / 255)) : 0;
        }
      }
      bmp.UnlockBits(&bd); ok = true;
    } }
  SelectObject(dc, of); SelectObject(dc, ob); DeleteObject(hb); DeleteDC(dc);
  if (!ok) return false;
  GraphicsState gs = c.g->Save();
  c.g->SetInterpolationMode(InterpolationModeHighQualityBilinear); c.g->SetPixelOffsetMode(PixelOffsetModeHalf);
  c.g->DrawImage(&bmp, RectF(x - 1.f / sc, y - 1.f / sc, bw / sc, bh / sc), 0, 0, (REAL)bw, (REAL)bh, UnitPixel);
  c.g->Restore(gs);
  InterlockedExchange(&g_gdiUsed, 1);
  return true;
}
int XfTextPathInfo() { return (XfFineBroken() ? 1 : 0) | (g_gdipVerdict == 0 ? 2 : 0) | (g_gdiUsed ? 4 : 0); }
void XfTextTestFail(int bits) {
  XfFineTestFail(bits); g_gdipVerdict = -1; g_cov.clear(); g_gdiTexts.clear(); InterlockedExchange(&g_gdiUsed, 0);
}

// ---------------- 文字 ----------------
float TextW(Ctx& c, const std::wstring& t, Font* f) {
  if (t.empty() || !f) return 0;
  { float fw; if (!c.rtl && XfFineMeasure(f, t, &fw)) return ceilf(fw); }  // 精绘文字：与画的时候同一套字宽（RTL 界面画布是镜像的，文字走 GDI+，量也用 GDI+）
  if (UseGdi(c, f, t)) { float gw; if (GdiMeasure(f, t, &gw)) return ceilf(gw); }  // 走 GDI 画的字用 GDI 量，截断、对齐与画出来的一致
  StringFormat sf(StringFormat::GenericTypographic());
  sf.SetFormatFlags(StringFormatFlagsNoWrap | StringFormatFlagsMeasureTrailingSpaces);
  RectF r;
  c.g->MeasureString(t.c_str(), (INT)t.size(), f, PointF(0, 0), &sf, &r);
  return ceilf(r.Width);
}
float TextH(Font* f) { return f ? f->GetHeight(96.f) : 0; }
// 省略号自己算（不用 GDI+ 的裁剪：各系统上表现一致，RTL 文字也按逻辑顺序从尾部截断）
static std::wstring Ellipsize(Ctx& c, const std::wstring& t, Font* f, float w) {
  if (TextW(c, t, f) <= w + 0.5f) return t;
  const std::wstring ell = L"\x2026";
  size_t lo = 0, hi = t.size();
  while (lo < hi) {
    size_t mid = (lo + hi + 1) / 2;
    size_t cut = mid;
    if (cut > 0 && cut < t.size() && t[cut - 1] >= 0xD800 && t[cut - 1] <= 0xDBFF) cut--;  // 不切开代理对
    std::wstring s = t.substr(0, cut);
    while (!s.empty() && (s.back() == L' ' || s.back() == L'\x3000')) s.pop_back();
    if (TextW(c, s + ell, f) <= w + 0.5f) lo = mid; else hi = mid - 1;
  }
  size_t cut = lo;
  if (cut > 0 && cut < t.size() && t[cut - 1] >= 0xD800 && t[cut - 1] <= 0xDBFF) cut--;
  std::wstring s = t.substr(0, cut);
  while (!s.empty() && (s.back() == L' ' || s.back() == L'\x3000' || s.back() == L',' || s.back() == 0xFF0C)) s.pop_back();
  return s.empty() ? ell : s + ell;
}
// 测试：逐段记下文字的颜色与画布上的外接框，供对比度逐段检查（只在截图那一次绘制里记）。
// 一行：颜色 ARGB、左 顶 右 底（画布像素）、字号（像素）、字形（1 粗体）、种类、文字。
// 框按 4 个角换算后取外接框，所以旋转、阿拉伯语的镜像都对；图层里画的字加上图层到画布的偏移（图层没有画布四周的边距）
void XfTestLog(Ctx& c, char kind, const Color& col0, float x, float y, float w, float h, float px, int style, const std::wstring& t) {
  if (!g_testTextLog[0] || !g_testLogNow || !c.draw || !c.g || t.empty() || c.logSkip) return;
  if (c.logKind) kind = c.logKind;
  Matrix mx; c.g->GetTransform(&mx);
  PointF p[4] = {PointF(x, y), PointF(x + w, y), PointF(x, y + h), PointF(x + w, y + h)}; mx.TransformPoints(p, 4);
  float x0 = p[0].X, y0 = p[0].Y, x1 = p[0].X, y1 = p[0].Y;
  for (auto& q : p) { if (q.X < x0) x0 = q.X; if (q.X > x1) x1 = q.X; if (q.Y < y0) y0 = q.Y; if (q.Y > y1) y1 = q.Y; }
  x0 += c.logDx; x1 += c.logDx; y0 += c.logDy; y1 += c.logDy;
  unsigned a = col0.GetA(); float r = col0.GetR(), g = col0.GetG(), b = col0.GetB();
  if (c.logDesat > 0 || c.logBright != 1) {  // 与 Desaturate 同一个式子（它是线性的：先混合再去色＝先去色再混合）
    float l = 0.299f * r + 0.587f * g + 0.114f * b;
    r = (r + (l - r) * c.logDesat) * c.logBright; g = (g + (l - g) * c.logDesat) * c.logBright; b = (b + (l - b) * c.logDesat) * c.logBright;
  }
  auto cl = [](float v) { return (unsigned)(v < 0 ? 0 : v > 255 ? 255 : v + 0.5f); };
  unsigned argb = (a << 24) | (cl(r) << 16) | (cl(g) << 8) | cl(b);
  int n = WideCharToMultiByte(CP_UTF8, 0, t.c_str(), (int)t.size(), nullptr, 0, nullptr, nullptr); std::string u(n, 0); WideCharToMultiByte(CP_UTF8, 0, t.c_str(), (int)t.size(), &u[0], n, nullptr, nullptr);
  FILE* fp = _wfopen(g_testTextLog, L"ab");
  if (fp) { fprintf(fp, "%08X\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%d\t%c\t%s\n", argb, x0, y0, x1, y1, px, style, kind, u.c_str()); fclose(fp); }
}
static bool UnderWine() { static int w = -1; if (w < 0) w = GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "wine_get_version") ? 1 : 0; return w == 1; }  // 只给测试的文字记录用
void Text(Ctx& c, const std::wstring& t0, Font* f, const Color& col, float x, float y, float w, float h, int align, bool ell) {
  if (c.draw && !t0.empty() && g_testTextLog[0] && g_testLogNow) {  // 测试：记的框收紧到字实际占的地方，免得框住旁边别的字
    float lx = x, lw = w, th = TextH(f), ly = y, lh = h;
    if (f && th > 0 && th < h) { ly = y + (h - th) / 2; lh = th; }
    Matrix mx; c.g->GetTransform(&mx); REAL e[6]; mx.GetElements(e);
    // 镜像画布（阿拉伯语）上，按逻辑坐标算出的字的位置与不镜像时同一个式子；只是 Wine 不按“从右到左”对齐（字贴在框的另一头），所以 Wine 里只收紧强制从左到右的字
    if (f && w > 0 && (e[0] * e[3] - e[1] * e[2] > 0 || align >= 10 || !UnderWine())) {
      std::wstring tl = ell ? Ellipsize(c, t0, f, w) : t0; float tw = TextW(c, tl, f); if (tw > w) tw = w;
      int al = align % 10; lx = al == 1 ? x + (w - tw) / 2 : al == 2 ? x + w - tw : x; lw = tw;
      if (e[0] * e[3] - e[1] * e[2] < 0) lx += al == 2 ? 2.f : al == 1 ? 1.f : 0.f;  // 镜像时画字用的设备矩形在逻辑右边多出 2 像素（见下面 dr）：靠右的字往右 2、居中的往右 1
    }
    XfTestLog(c, 'T', col, lx, ly, lw, lh, f ? f->GetSize() : 0.f, f ? f->GetStyle() : 0, t0);
  }
  if (g_testNoText && c.draw) return;
  if (!c.draw || t0.empty() || !f || w <= 0) return;
  bool ltrForced = align >= 10;  // align+10：数字等一律从左到右
  int a = align % 10;
  std::wstring t = ell ? Ellipsize(c, t0, f, w) : t0;
  StringFormat sf(StringFormat::GenericTypographic());
  INT flags = StringFormatFlagsNoWrap | StringFormatFlagsMeasureTrailingSpaces;
  if (c.rtl && !ltrForced) flags |= StringFormatFlagsDirectionRightToLeft;
  sf.SetFormatFlags(flags);
  sf.SetTrimming(StringTrimmingEllipsisCharacter);  // 文字已按宽度截好；保留这个设置是因为部分实现只在裁剪模式下才做阿拉伯文连写与从右到左排序
  sf.SetAlignment(a == 1 ? StringAlignmentCenter : a == 2 ? StringAlignmentFar : StringAlignmentNear);
  sf.SetLineAlignment(StringAlignmentCenter);
  SolidBrush b(col);
  Matrix m; c.g->GetTransform(&m);
  REAL e[6]; m.GetElements(e);
  float det = e[0] * e[3] - e[1] * e[2];
  float pad = ell ? 0.f : 0.f;
  if (det < 0) {  // 整体左右镜像（RTL）：文字本身不能镜像，换算到设备坐标后不带镜像地画
    PointF p[2] = {PointF(x, y), PointF(x + w, y + h)};
    m.TransformPoints(p, 2);
    RectF dr((p[0].X < p[1].X ? p[0].X : p[1].X) - 2.f, p[0].Y < p[1].Y ? p[0].Y : p[1].Y, fabsf(p[1].X - p[0].X) + 2.f + pad, fabsf(p[1].Y - p[0].Y));
    if (ltrForced && a == 0) sf.SetAlignment(StringAlignmentFar);       // 镜像后 LTR 的起始边在右
    else if (ltrForced && a == 2) sf.SetAlignment(StringAlignmentNear);
    if (UseGdi(c, f, t) && GdiDraw(c, t, f, col, x, y, w, h, a, ltrForced)) return;
    GraphicsState st = c.g->Save();
    c.g->ResetTransform();
    c.g->DrawString(t.c_str(), (INT)t.size(), f, dr, &sf, &b);
    c.g->Restore(st);
  } else {
    if (ell && c.mq && c.s && t != t0) {  // 曲名放不下：按时间滚动（不是曲名的文字照旧截断加省略号）
      int slot = (!c.s->sfx.name.empty() && t0.find(c.s->sfx.name) != std::wstring::npos) ? 0 : (!c.s->bgm.name.empty() && t0.find(c.s->bgm.name) != std::wstring::npos) ? 1 : -1;
      Marquee& q = *c.mq;
      if (slot >= 0 && !q.reduce) {
        if (q.text[slot] != t0) { q.text[slot] = t0; q.start[slot] = c.now; }
        float tw = TextW(c, t0, f), D = tw - w + 2 * c.k, v = 30 * c.k;  // 每秒 30 像素
        DWORD el = c.now - q.start[slot], P1 = 1500, P2 = (DWORD)(D / v * 1000), P3 = 1500, cyc = P1 + P2 + P3;
        bool loop = c.hover;  // 鼠标在悬浮窗上：一直循环；否则新曲名只完整滚一遍
        if (q.test >= 0) el = (DWORD)q.test;
        if (!loop && el >= cyc) el = cyc + 1;  // 一遍滚完：回到开头、显示省略号
        else el %= cyc;
        if (el < cyc + 1 && (loop || c.now - q.start[slot] < cyc || q.test >= 0)) {
          float off = el < P1 ? 0 : el < P1 + P2 ? (el - P1) * v / 1000 : D;
          q.active = true;
          if (off > 0.01f || el < P1) {
            GraphicsState gs = c.g->Save();
            c.g->IntersectClip(RectF(x, y, w, h));
            if (!XfFineDraw(c, t0, f, col, x - off, y, tw + 4, h, 0) && !(UseGdi(c, f, t0) && GdiDraw(c, t0, f, col, x - off, y, tw + 4, h, 0, ltrForced)))
              c.g->DrawString(t0.c_str(), (INT)t0.size(), f, RectF(x - off, y, tw + 8, h), &sf, &b);
            c.g->Restore(gs);
            return;
          }
        }
      }
    }
    if (XfFineDraw(c, t, f, col, x, y, w, h, a)) return;  // 精绘文字（与设计稿同一种画法）；不支持的文字照旧用 GDI+
    if (UseGdi(c, f, t) && GdiDraw(c, t, f, col, x, y, w, h, a, ltrForced)) return;  // GDI+ 画不出字、或这款字缺字时用 GDI
    c.g->DrawString(t.c_str(), (INT)t.size(), f, RectF(x, y, w + 2.f, h), &sf, &b);
  }
}

// ---------------- 图形 ----------------
void Flower(Ctx& c, float cx, float cy, float s, bool grey) {
  if (!c.draw) return;
  float u = s / 24.f;
  GraphicsState st = c.g->Save();
  c.g->TranslateTransform(cx, cy);
  LinearGradientBrush pb(PointF(0, -11.6f * u), PointF(0, 0.6f * u), grey ? C(0x9C9CA6) : C(0xFF8A7A), grey ? C(0x6A6A74) : C(0xE0332C));
  if (!grey) {
    Color cs[3] = {C(0xFF8A7A), C(0xFF4D43), C(0xE0332C)}; REAL ps[3] = {0, .55f, 1};
    pb.SetInterpolationColors(cs, ps, 3);
  }
  for (int i = 0; i < 5; i++) {
    c.g->FillEllipse(&pb, -4.4f * u, -11.2f * u, 8.8f * u, 11.2f * u);
    c.g->RotateTransform(72.f);
  }
  GraphicsPath cp; cp.AddEllipse(-3.4f * u, -3.4f * u, 6.8f * u, 6.8f * u);
  PathGradientBrush cb(&cp);
  cb.SetCenterPoint(PointF(-0.7f * u, -1.1f * u));
  cb.SetCenterColor(grey ? C(0xD6D6DE) : C(0xFFF1A6));
  Color sc = grey ? C(0x9696A0) : C(0xFFB72E); INT n = 1;
  cb.SetSurroundColors(&sc, &n);
  c.g->FillPath(&cb, &cp);
  c.g->Restore(st);
}
void FlowerMono(Ctx& c, float cx, float cy, float s, const Color& pet, const Color& core) {
  if (!c.draw) return;
  float u = s / 24.f;
  GraphicsState st = c.g->Save();
  c.g->TranslateTransform(cx, cy);
  SolidBrush pb(pet);
  for (int i = 0; i < 5; i++) { c.g->FillEllipse(&pb, -4.4f * u, -11.2f * u, 8.8f * u, 11.2f * u); c.g->RotateTransform(72.f); }
  SolidBrush cb(core);
  c.g->FillEllipse(&cb, -3.4f * u, -3.4f * u, 6.8f * u, 6.8f * u);
  c.g->Restore(st);
}
void Ring(Ctx& c, float cx, float cy, float d, float sw, float p, const Color& track, const Color& a, const Color& b, bool full) {
  if (!c.draw) return;
  float r = d / 2 - sw / 2;
  Pen tp(track, sw);
  if (track.GetA()) c.g->DrawEllipse(&tp, cx - r, cy - r, 2 * r, 2 * r);
  if (p <= 0) return;
  LinearGradientBrush gb(PointF(cx - d / 2, cy - d / 2), PointF(cx + d / 2, cy + d / 2), a, b);
  Pen pp(&gb, sw);
  if (full || p >= 0.999f) c.g->DrawEllipse(&pp, cx - r, cy - r, 2 * r, 2 * r);
  else {
    pp.SetStartCap(LineCapRound); pp.SetEndCap(LineCapRound);
    c.g->DrawArc(&pp, cx - r, cy - r, 2 * r, 2 * r, -90.f, 360.f * p);
  }
}
void Vinyl(Ctx& c, float cx, float cy, float d, const Color& label, float rot) {
  if (!c.draw) return;
  float k = d / 32.f;
  SolidBrush b(C(0x0E0E12));
  c.g->FillEllipse(&b, cx - d / 2, cy - d / 2, d, d);
  Pen gr(C(0xFFFFFF, 23), 0.55f * k);
  float rs[4] = {13.4f, 11.6f, 9.8f, 8.2f};
  for (float rr : rs) c.g->DrawEllipse(&gr, cx - rr * k, cy - rr * k, 2 * rr * k, 2 * rr * k);
  GraphicsState st = c.g->Save();
  c.g->TranslateTransform(cx, cy); c.g->RotateTransform(rot);
  LinearGradientBrush sh(PointF(-d / 2, -d / 2), PointF(d / 2, d / 2), C(0xFFFFFF, 0), C(0xFFFFFF, 0));
  Color cs[3] = {C(0xFFFFFF, 0), C(0xFFFFFF, 46), C(0xFFFFFF, 0)}; REAL ps[3] = {0, .5f, 1};
  sh.SetInterpolationColors(cs, ps, 3);
  c.g->FillEllipse(&sh, -d / 2, -d / 2, d, d);
  SolidBrush lb(label);
  c.g->FillEllipse(&lb, -6 * k, -6 * k, 12 * k, 12 * k);
  SolidBrush hl(C(0xFFFFFF, 90));
  c.g->FillEllipse(&hl, -3.3f * k, -3.2f * k, 3.2f * k, 3.2f * k);
  c.g->Restore(st);
  SolidBrush hole(C(0x0E0E12));
  c.g->FillEllipse(&hole, cx - 1.3f * k, cy - 1.3f * k, 2.6f * k, 2.6f * k);
}
static void RR(Graphics* g, const Brush& b, float x, float y, float w, float h, float r) { GraphicsPath p; RoundRectPath(p, x, y, w, h, r); g->FillPath(&b, &p); }
void IconPlus(Ctx& c, float cx, float cy, float s, const Color& col, float stroke) {
  if (!c.draw) return;
  Pen p(col, stroke); p.SetStartCap(LineCapRound); p.SetEndCap(LineCapRound);
  float h = s / 2;
  c.g->DrawLine(&p, cx - h, cy, cx + h, cy);
  c.g->DrawLine(&p, cx, cy - h, cx, cy + h);
}
void IconPause(Ctx& c, float cx, float cy, float s, const Color& col) {
  if (!c.draw) return; SolidBrush b(col); float u = s / 16;
  RR(c.g, b, cx + (3.8f - 8) * u, cy + (3 - 8) * u, 3 * u, 10 * u, 1.2f * u);
  RR(c.g, b, cx + (9.2f - 8) * u, cy + (3 - 8) * u, 3 * u, 10 * u, 1.2f * u);
}
void IconStop(Ctx& c, float cx, float cy, float s, const Color& col) {
  if (!c.draw) return; SolidBrush b(col); float u = s / 16;
  RR(c.g, b, cx - 4.5f * u, cy - 4.5f * u, 9 * u, 9 * u, 2.2f * u);
}
void IconPlay(Ctx& c, float cx, float cy, float s, const Color& col) {
  if (!c.draw) return; SolidBrush b(col); float u = s / 16;
  GraphicsPath p;
  PointF pts[3] = {PointF(cx - 3 * u, cy - 5 * u), PointF(cx + 5.2f * u, cy), PointF(cx - 3 * u, cy + 5 * u)};
  p.AddPolygon(pts, 3);
  Pen pn(col, 1.6f * u); pn.SetLineJoin(LineJoinRound);
  c.g->FillPath(&b, &p); c.g->DrawPath(&pn, &p);
}
void IconPrev(Ctx& c, float cx, float cy, float s, const Color& col) {
  if (!c.draw) return; SolidBrush b(col); float u = s / 16;
  RR(c.g, b, cx - 5.4f * u, cy - 4.6f * u, 2 * u, 9.2f * u, 1 * u);
  PointF pts[3] = {PointF(cx + 5.2f * u, cy - 4.4f * u), PointF(cx - 1.8f * u, cy), PointF(cx + 5.2f * u, cy + 4.4f * u)};
  GraphicsPath p; p.AddPolygon(pts, 3); Pen pn(col, 1.2f * u); pn.SetLineJoin(LineJoinRound);
  c.g->FillPath(&b, &p); c.g->DrawPath(&pn, &p);
}
void IconNext(Ctx& c, float cx, float cy, float s, const Color& col) {
  if (!c.draw) return; SolidBrush b(col); float u = s / 16;
  RR(c.g, b, cx + 3.4f * u, cy - 4.6f * u, 2 * u, 9.2f * u, 1 * u);
  PointF pts[3] = {PointF(cx - 5.2f * u, cy - 4.4f * u), PointF(cx + 1.8f * u, cy), PointF(cx - 5.2f * u, cy + 4.4f * u)};
  GraphicsPath p; p.AddPolygon(pts, 3); Pen pn(col, 1.2f * u); pn.SetLineJoin(LineJoinRound);
  c.g->FillPath(&b, &p); c.g->DrawPath(&pn, &p);
}
void IconOpen(Ctx& c, float cx, float cy, float s, const Color& col) {
  if (!c.draw) return; float u = s / 16;
  Pen pn(col, 1.6f * u); pn.SetStartCap(LineCapRound); pn.SetEndCap(LineCapRound); pn.SetLineJoin(LineJoinRound);
  float ox = cx - 8 * u, oy = cy - 8 * u;
  GraphicsPath p;
  p.AddLine(ox + 7 * u, oy + 3.2f * u, ox + 4.6f * u, oy + 3.2f * u);
  p.AddArc(ox + 2.8f * u, oy + 3.2f * u, 3.6f * u, 3.6f * u, 270.f, -90.f);
  p.AddLine(ox + 2.8f * u, oy + 5 * u, ox + 2.8f * u, oy + 11.4f * u);
  p.AddArc(ox + 2.8f * u, oy + 9.6f * u, 3.6f * u, 3.6f * u, 180.f, -90.f);
  p.AddLine(ox + 4.6f * u, oy + 13.2f * u, ox + 11 * u, oy + 13.2f * u);
  p.AddArc(ox + 9.2f * u, oy + 9.6f * u, 3.6f * u, 3.6f * u, 90.f, -90.f);
  p.AddLine(ox + 12.8f * u, oy + 11.4f * u, ox + 12.8f * u, oy + 9 * u);
  c.g->DrawPath(&pn, &p);
  c.g->DrawLine(&pn, ox + 9.6f * u, oy + 2.8f * u, ox + 13.2f * u, oy + 2.8f * u);
  c.g->DrawLine(&pn, ox + 13.2f * u, oy + 2.8f * u, ox + 13.2f * u, oy + 6.4f * u);
  c.g->DrawLine(&pn, ox + 13 * u, oy + 3 * u, ox + 8 * u, oy + 8 * u);
}
void IconDuck(Ctx& c, float cx, float cy, float s, const Color& col) {
  if (!c.draw) return; float u = s / 16; float ox = cx - 8 * u, oy = cy - 8 * u;
  SolidBrush b(col);
  PointF sp[6] = {PointF(ox + 1.5f * u, oy + 6.1f * u), PointF(ox + 4.5f * u, oy + 6.1f * u), PointF(ox + 8.7f * u, oy + 3.2f * u),
                  PointF(ox + 8.7f * u, oy + 12.8f * u), PointF(ox + 4.5f * u, oy + 9.9f * u), PointF(ox + 1.5f * u, oy + 9.9f * u)};
  c.g->FillPolygon(&b, sp, 6);
  Pen pn(col, 1.6f * u); pn.SetStartCap(LineCapRound); pn.SetEndCap(LineCapRound); pn.SetLineJoin(LineJoinRound);
  c.g->DrawLine(&pn, ox + 12 * u, oy + 4.6f * u, ox + 12 * u, oy + 10.8f * u);
  c.g->DrawLine(&pn, ox + 10 * u, oy + 9 * u, ox + 12 * u, oy + 11 * u);
  c.g->DrawLine(&pn, ox + 14 * u, oy + 9 * u, ox + 12 * u, oy + 11 * u);
}
void IconNote(Ctx& c, float cx, float cy, float s, const Color& col) {
  if (!c.draw) return; float u = s / 16; float ox = cx - 8 * u, oy = cy - 8 * u;
  Pen pn(col, 1.6f * u); pn.SetLineJoin(LineJoinRound); pn.SetStartCap(LineCapRound); pn.SetEndCap(LineCapRound);
  PointF pts[4] = {PointF(ox + 6.2f * u, oy + 11.6f * u), PointF(ox + 6.2f * u, oy + 4.1f * u), PointF(ox + 12.8f * u, oy + 2.6f * u), PointF(ox + 12.8f * u, oy + 10.1f * u)};
  c.g->DrawLines(&pn, pts, 4);
  SolidBrush b(col);
  c.g->FillEllipse(&b, ox + 2.5f * u, oy + 9.7f * u, 4 * u, 4 * u);
  c.g->FillEllipse(&b, ox + 9.1f * u, oy + 8.2f * u, 4 * u, 4 * u);
}
void IconKeypad(Ctx& c, float cx, float cy, float s, const Color& col) {
  if (!c.draw) return; float u = s / 16; SolidBrush b(col);
  for (int r = 0; r < 3; r++) for (int q = 0; q < 3; q++) RR(c.g, b, cx - 8 * u + (2 + q * 4.3f) * u, cy - 8 * u + (2 + r * 4.3f) * u, 3.2f * u, 3.2f * u, .9f * u);
}
void IconPower(Ctx& c, float cx, float cy, float s, const Color& col) {
  if (!c.draw) return; float u = s / 16;
  Pen pn(col, 1.8f * u); pn.SetStartCap(LineCapRound); pn.SetEndCap(LineCapRound);
  c.g->DrawLine(&pn, cx, cy - 6.2f * u, cx, cy - 0.6f * u);
  c.g->DrawArc(&pn, cx - 5.2f * u, cy - 4.8f * u, 10.4f * u, 10.4f * u, -45.f, 270.f);
}
void IconLoop(Ctx& c, float cx, float cy, float s, const Color& col) {
  if (!c.draw) return; float u = s / 16; float ox = cx - 8 * u, oy = cy - 8 * u;
  Pen pn(col, 1.5f * u); pn.SetStartCap(LineCapRound); pn.SetEndCap(LineCapRound); pn.SetLineJoin(LineJoinRound);
  c.g->DrawLine(&pn, ox + 3 * u, oy + 7 * u, ox + 3 * u, oy + 6 * u);
  c.g->DrawArc(&pn, ox + 3 * u, oy + 4 * u, 4 * u, 4 * u, 180.f, 90.f);
  c.g->DrawLine(&pn, ox + 5 * u, oy + 4 * u, ox + 12.5f * u, oy + 4 * u);
  c.g->DrawLine(&pn, ox + 10.5f * u, oy + 2 * u, ox + 12.5f * u, oy + 4 * u);
  c.g->DrawLine(&pn, ox + 10.5f * u, oy + 6 * u, ox + 12.5f * u, oy + 4 * u);
  c.g->DrawLine(&pn, ox + 13 * u, oy + 9 * u, ox + 13 * u, oy + 10 * u);
  c.g->DrawArc(&pn, ox + 9 * u, oy + 8 * u, 4 * u, 4 * u, 0.f, 90.f);
  c.g->DrawLine(&pn, ox + 11 * u, oy + 12 * u, ox + 3.5f * u, oy + 12 * u);
  c.g->DrawLine(&pn, ox + 5.5f * u, oy + 14 * u, ox + 3.5f * u, oy + 12 * u);
  c.g->DrawLine(&pn, ox + 5.5f * u, oy + 10 * u, ox + 3.5f * u, oy + 12 * u);
}

// ---------------- 像素特效 ----------------
void BoxBlurAlpha(std::vector<unsigned char>& a, int w, int h, int r) {
  if (r <= 0 || w <= 0 || h <= 0) return;
  std::vector<unsigned char> t((size_t)w * h);
  int d = 2 * r + 1;
  for (int pass = 0; pass < 3; pass++) {
    for (int y = 0; y < h; y++) {
      const unsigned char* row = &a[(size_t)y * w];
      int s = 0;
      for (int x = -r; x <= r; x++) s += row[x < 0 ? 0 : x >= w ? w - 1 : x];
      for (int x = 0; x < w; x++) {
        t[(size_t)y * w + x] = (unsigned char)(s / d);
        int xo = x - r, xi = x + r + 1;
        s += row[xi >= w ? w - 1 : xi] - row[xo < 0 ? 0 : xo];
      }
    }
    for (int x = 0; x < w; x++) {
      int s = 0;
      for (int y = -r; y <= r; y++) s += t[(size_t)(y < 0 ? 0 : y >= h ? h - 1 : y) * w + x];
      for (int y = 0; y < h; y++) {
        a[(size_t)y * w + x] = (unsigned char)(s / d);
        int yo = y - r, yi = y + r + 1;
        s += t[(size_t)(yi >= h ? h - 1 : yi) * w + x] - t[(size_t)(yo < 0 ? 0 : yo) * w + x];
      }
    }
  }
}
static inline unsigned PM(unsigned rgb, int a) {  // 预乘的 BGRA
  unsigned r = ((rgb >> 16) & 255) * a / 255, g = ((rgb >> 8) & 255) * a / 255, b = (rgb & 255) * a / 255;
  return ((unsigned)a << 24) | (r << 16) | (g << 8) | b;
}
static inline unsigned Over(unsigned top, unsigned bot) {  // 预乘的 src-over
  unsigned ta = top >> 24;
  if (ta == 255) return top;
  if (ta == 0) return bot;
  unsigned inv = 255 - ta;
  unsigned a = ta + ((bot >> 24) * inv + 127) / 255;
  unsigned r = ((top >> 16) & 255) + (((bot >> 16) & 255) * inv + 127) / 255;
  unsigned g = ((top >> 8) & 255) + (((bot >> 8) & 255) * inv + 127) / 255;
  unsigned b = (top & 255) + ((bot & 255) * inv + 127) / 255;
  if (a > 255) a = 255; if (r > 255) r = 255; if (g > 255) g = 255; if (b > 255) b = 255;
  return (a << 24) | (r << 16) | (g << 8) | b;
}
void ShadowUnder(PixBuf& dst, const PixBuf& src, int r, int dx, int dy, unsigned rgb, float strength) {
  int w = dst.w, h = dst.h;
  std::vector<unsigned char> a((size_t)w * h, 0);
  for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
    int sx = x - dx, sy = y - dy;
    if (sx >= 0 && sy >= 0 && sx < src.w && sy < src.h) a[(size_t)y * w + x] = (unsigned char)(src.px[(size_t)sy * src.w + sx] >> 24);
  }
  BoxBlurAlpha(a, w, h, r);
  for (size_t i = 0; i < a.size(); i++) {
    int al = (int)(a[i] * strength);
    if (al <= 0) continue;
    dst.px[i] = Over(dst.px[i], PM(rgb, al > 255 ? 255 : al));
  }
}
void GlowAdd(PixBuf& dst, const PixBuf& src, int r, unsigned rgb, float strength) {
  int w = dst.w, h = dst.h;
  std::vector<unsigned char> a((size_t)w * h, 0);
  for (size_t i = 0; i < a.size() && i < src.px.size(); i++) a[i] = (unsigned char)(src.px[i] >> 24);
  BoxBlurAlpha(a, w, h, r);
  for (size_t i = 0; i < a.size(); i++) {
    int al = (int)(a[i] * strength);
    if (al <= 0) continue;
    if (al > 255) al = 255;
    dst.px[i] = Over(PM(rgb, al), dst.px[i]);
  }
}
void DilateWhiteUnder(PixBuf& dst, int radius, unsigned rgb) {
  int w = dst.w, h = dst.h;
  std::vector<unsigned char> a((size_t)w * h), o((size_t)w * h, 0);
  for (size_t i = 0; i < a.size(); i++) a[i] = (unsigned char)(dst.px[i] >> 24);
  int r2 = radius * radius;
  for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
    unsigned char m = 0;
    for (int yy = -radius; yy <= radius && m < 255; yy++) {
      int sy = y + yy; if (sy < 0 || sy >= h) continue;
      for (int xx = -radius; xx <= radius; xx++) {
        if (xx * xx + yy * yy > r2) continue;
        int sx = x + xx; if (sx < 0 || sx >= w) continue;
        unsigned char v = a[(size_t)sy * w + sx];
        if (v > m) m = v;
      }
    }
    o[(size_t)y * w + x] = m > 100 ? 255 : (unsigned char)(m * 255 / 100);
  }
  for (size_t i = 0; i < o.size(); i++) if (o[i]) dst.px[i] = Over(dst.px[i], PM(rgb, o[i]));
}
void Desaturate(PixBuf& b, float amount, float bright) {
  for (auto& p : b.px) {
    unsigned a = p >> 24; if (!a) continue;
    float r = (float)((p >> 16) & 255), g = (float)((p >> 8) & 255), bl = (float)(p & 255);
    float l = 0.299f * r + 0.587f * g + 0.114f * bl;
    r = (r + (l - r) * amount) * bright; g = (g + (l - g) * amount) * bright; bl = (bl + (l - bl) * amount) * bright;
    auto cl = [&](float v) { return (unsigned)(v < 0 ? 0 : v > (float)a ? (float)a : v); };
    p = (a << 24) | (cl(r) << 16) | (cl(g) << 8) | cl(bl);
  }
}
bool PixelTextMask(const std::wstring& family, int px, const std::wstring& text, std::vector<unsigned char>& mask, int& w, int& h) {
  if (text.empty()) { w = h = 0; return false; }
  HDC dc = CreateCompatibleDC(nullptr);
  HFONT hf = CreateFontW(-px, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, NONANTIALIASED_QUALITY, DEFAULT_PITCH, family.c_str());
  HGDIOBJ of = SelectObject(dc, hf);
  SIZE sz = {0, 0};
  GetTextExtentPoint32W(dc, text.c_str(), (int)text.size(), &sz);
  TEXTMETRICW tm; GetTextMetricsW(dc, &tm);
  w = sz.cx + px + 4; h = tm.tmHeight + 4;  // 多留一个字宽：个别点阵字体的字形比量出来的宽
  BITMAPINFO bi = {}; bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = -h; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
  void* bits = nullptr;
  HBITMAP bmp = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
  HGDIOBJ ob = SelectObject(dc, bmp);
  memset(bits, 0, (size_t)w * h * 4);
  SetBkMode(dc, TRANSPARENT); SetTextColor(dc, RGB(255, 255, 255));
  TextOutW(dc, 1, 1, text.c_str(), (int)text.size());
  GdiFlush();
  mask.assign((size_t)w * h, 0);
  const unsigned* p = (const unsigned*)bits;
  for (int i = 0; i < w * h; i++) mask[i] = ((p[i] & 0xFFFFFF) != 0) ? 1 : 0;
  SelectObject(dc, ob); DeleteObject(bmp); SelectObject(dc, of); DeleteObject(hf); DeleteDC(dc);
  return true;
}

namespace __gnu_cxx { void __verbose_terminate_handler() { abort(); } }
