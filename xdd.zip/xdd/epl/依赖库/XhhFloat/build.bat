@echo off
rem Windows 上用 MinGW-w64（i686，32 位）编译 out\XhhFloat.dll；与 build.sh 同一组参数，输出逐字节相同
setlocal
set ROOT=%~dp0
if not exist "%ROOT%out" mkdir "%ROOT%out"
windres -i "%ROOT%src\xhhfloat.rc" -O coff -o "%ROOT%out\xhhfloat_res.o" || exit /b 1
g++ -std=c++17 -Os -s -shared -static -static-libgcc -static-libstdc++ -ffunction-sections -fdata-sections ^
  -fno-exceptions -fno-rtti -fno-asynchronous-unwind-tables -DUNICODE -D_UNICODE -DWINVER=0x0601 -D_WIN32_WINNT=0x0601 ^
  -Wall -Wextra -Wno-unused-parameter -Wno-missing-field-initializers -Wno-misleading-indentation -Wno-free-nonheap-object -Wno-unused-function ^
  "%ROOT%src\xf_core.cpp" "%ROOT%src\xf_gfx.cpp" "%ROOT%src\xf_skins.cpp" "%ROOT%src\xf_i18n.cpp" "%ROOT%src\xf_fine.cpp" "%ROOT%src\xf_menu.cpp" "%ROOT%out\xhhfloat_res.o" ^
  -o "%ROOT%out\XhhFloat.dll" -Wl,--gc-sections -Wl,--kill-at -Wl,--nxcompat -Wl,--dynamicbase ^
  -Wl,--major-subsystem-version,6 -Wl,--minor-subsystem-version,1 -Wl,--no-insert-timestamp -Wl,--disable-auto-image-base ^
  -lgdiplus -lgdi32 -luser32 -ladvapi32 || exit /b 1
del "%ROOT%out\xhhfloat_res.o"
echo OK: %ROOT%out\XhhFloat.dll
echo 记得把它复制成 ..\..\资源\dll_XhhFloat.Image.dat（易语言资源 dll_XhhFloat）
