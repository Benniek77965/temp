#!/usr/bin/env bash
# 一键：编译 DLL → 检查导出 / 导入 / 位数 → 另一目录重编比对字节（可复现）→ 在 32 位 Wine 里跑 xftest（截图、鼠标、多线程、调用桩、启停）
# 需要：i686-w64-mingw32-g++、wine32、xvfb-run。用法：tests/run_all.sh [截图输出目录] [字体目录（可选，含 HarmonyOS_Sans_SC\…ttf）]
set -e
export LANG=C.UTF-8 LC_ALL=C.UTF-8  # 路径里有中文（依赖库）：Wine 要在 UTF-8 下才认得
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SHOTS="${1:-/tmp/xhhfloat_shots}"
FONTS="${2:-}"
WINE="${WINE:-$(command -v wine || echo /usr/lib/wine/wine)}"
"$ROOT/build.sh"
python3 "$ROOT/tools/check_dll.py" "$ROOT/out/XhhFloat.dll"
TMP="$(mktemp -d)"; cp -r "$ROOT/src" "$ROOT/build.sh" "$TMP/"; (cd "$TMP" && ./build.sh "$TMP/out" >/dev/null)
if cmp -s "$ROOT/out/XhhFloat.dll" "$TMP/out/XhhFloat.dll"; then echo "PASS 换目录重编，字节相同（可复现）"; else echo "FAIL 换目录重编，字节不同（不可复现）"; rm -rf "$TMP"; exit 1; fi; rm -rf "$TMP"
i686-w64-mingw32-g++ -std=c++17 -O1 -static -o "$ROOT/out/xftest.exe" "$ROOT/tests/xftest.cpp" -lgdiplus -lgdi32 -Wl,--no-insert-timestamp
rm -rf "$SHOTS"; mkdir -p "$SHOTS"
export WINEPREFIX="${WINEPREFIX:-$HOME/.wine-xhhfloat}" WINEARCH=win32 WINEDEBUG=-all WINEDLLOVERRIDES="mscoree,mshtml="
WSHOTS="Z:$(echo "$SHOTS" | sed 's#/#\\#g')"
ARGS=("$ROOT/out/XhhFloat.dll" "$WSHOTS")
[ -n "$FONTS" ] && ARGS+=("Z:$(echo "$FONTS" | sed 's#/#\\#g')")
cd "$ROOT/out" && xvfb-run -a -s "-screen 0 1920x1080x24" "$WINE" xftest.exe XhhFloat.dll "${ARGS[1]}" ${ARGS[2]:+"${ARGS[2]}"}
