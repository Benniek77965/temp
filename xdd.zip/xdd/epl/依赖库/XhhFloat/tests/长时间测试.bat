@echo off
rem Long-running test: xftest.exe soak <minutes> [font folder]. Drop the font folder onto this file to include it.
cd /d "%~dp0"
xftest.exe soak 30 %1
