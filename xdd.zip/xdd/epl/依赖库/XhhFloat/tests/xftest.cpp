// XhhFloat 开发者测试（在 Wine 32 位或 Windows 上运行）：截图全部皮肤 × 状态 × 语种，模拟鼠标核对事件，多线程压测，量绘制耗时。
// 用法：xftest.exe <XhhFloat.dll> <输出目录> [字体目录]
#include <windows.h>
#include <gdiplus.h>
#include <stdio.h>
#include <math.h>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <stdarg.h>
#include <shellapi.h>
#include <psapi.h>
// 路径一律是 UTF-8 的 std::string（DLL 的接口也收 UTF-8）；碰文件时才转成宽字符——项目路径里有中文（依赖库），在 Windows 上用 ANSI 的接口会出错
static std::wstring W8(const std::string& u) { int n = MultiByteToWideChar(CP_UTF8, 0, u.c_str(), -1, nullptr, 0); std::wstring w(n > 1 ? n - 1 : 0, 0); if (n > 1) MultiByteToWideChar(CP_UTF8, 0, u.c_str(), -1, &w[0], n); return w; }
static std::string U8W(const std::wstring& w) { int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, nullptr, 0, 0, 0); std::string s(n > 1 ? n - 1 : 0, 0); if (n > 1) WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, &s[0], n, 0, 0); return s; }
static FILE* Fopen8(const std::string& p, const wchar_t* mode) { return _wfopen(W8(p).c_str(), mode); }
static std::wstring g_logPath;  // 每写一次都打开、追加、关上：测试还在跑时也能复制、打包这个文件（原来一直开着写，资源管理器“发送到压缩文件夹”会把它跳过，交上来的结果里没有日志）
static int LogPrintf(const char* fmt, ...) {
  va_list a; va_start(a, fmt); int n = vprintf(fmt, a); va_end(a);
  if (!g_logPath.empty()) { FILE* f = _wfopen(g_logPath.c_str(), L"ab"); if (f) { va_start(a, fmt); vfprintf(f, fmt, a); va_end(a); fclose(f); } }
  return n;
}
#define printf LogPrintf
static bool g_wine = false;
// 易语言「ZLIB压缩数据」格式的解压（测试程序用）：4 字节标记 0D 0F 3E 03＋4 字节原长（小端）＋zlib 数据（RFC 1950 头、RFC 1951 deflate、Adler-32 校验）。
// 项目资源里的 DLL（资源\dll_*.Image.dat）就是这样存的，易语言程序写出前先解开；测试程序原来直接拿它当 DLL 用，Windows 报“损坏的映像”（0xc000012f）
namespace ezl {
struct Huff { short count[16]; short symbol[288]; };
struct St {
  const unsigned char* in; size_t n, pos; unsigned bitbuf; int bitcnt; std::vector<unsigned char>* out; size_t cap; bool err;
  int bits(int need) {
    unsigned long long v = bitbuf;
    while (bitcnt < need) { if (pos >= n) { err = true; return 0; } v |= (unsigned long long)in[pos++] << bitcnt; bitcnt += 8; }
    bitbuf = (unsigned)(v >> need); bitcnt -= need;
    return (int)(v & ((1ull << need) - 1));
  }
};
static int construct(Huff& h, const short* len, int n) {  // 由各符号的码长建范式哈夫曼表：返回 0 完整，>0 不完整，<0 超额
  for (int i = 0; i < 16; i++) h.count[i] = 0;
  for (int s = 0; s < n; s++) h.count[len[s]]++;
  if (h.count[0] == n) return 0;
  int left = 1;
  for (int l = 1; l < 16; l++) { left <<= 1; left -= h.count[l]; if (left < 0) return left; }
  short offs[16]; offs[1] = 0;
  for (int l = 1; l < 15; l++) offs[l + 1] = (short)(offs[l] + h.count[l]);
  for (int s = 0; s < n; s++) if (len[s]) h.symbol[offs[len[s]]++] = (short)s;
  return left;
}
static int decode(St& s, const Huff& h) {
  int code = 0, first = 0, index = 0;
  for (int l = 1; l < 16; l++) {
    code |= s.bits(1); if (s.err) return -1;
    int c = h.count[l];
    if (code - c < first) return h.symbol[index + (code - first)];
    index += c; first += c; first <<= 1; code <<= 1;
  }
  return -1;
}
static bool codes(St& s, const Huff& lc, const Huff& dc) {
  static const short lb[29] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
  static const short le[29] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
  static const short db[30] = {1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577};
  static const short de[30] = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};
  std::vector<unsigned char>& o = *s.out;
  for (;;) {
    int sym = decode(s, lc); if (sym < 0) return false;
    if (sym < 256) { if (o.size() >= s.cap) return false; o.push_back((unsigned char)sym); continue; }
    if (sym == 256) return true;
    sym -= 257; if (sym >= 29) return false;
    int len = lb[sym] + s.bits(le[sym]);
    int ds = decode(s, dc); if (ds < 0 || ds >= 30) return false;
    size_t dist = (size_t)(db[ds] + s.bits(de[ds]));
    if (s.err || dist > o.size() || o.size() + (size_t)len > s.cap) return false;
    size_t from = o.size() - dist;
    for (int i = 0; i < len; i++) o.push_back(o[from + i]);  // 允许重叠（距离小于长度时重复前面的字节）
  }
}
static bool inflate(St& s) {
  static Huff flc, fdc; static bool fixedReady = false;
  int last;
  do {
    last = s.bits(1); int type = s.bits(2); if (s.err) return false;
    if (type == 0) {  // 不压缩的块：跳到字节边界，LEN 与 NLEN 互为反码
      s.bitbuf = 0; s.bitcnt = 0;
      if (s.pos + 4 > s.n) return false;
      unsigned len = s.in[s.pos] | (s.in[s.pos + 1] << 8), nlen = s.in[s.pos + 2] | (s.in[s.pos + 3] << 8); s.pos += 4;
      if ((len ^ 0xFFFF) != nlen || s.pos + len > s.n || s.out->size() + len > s.cap) return false;
      s.out->insert(s.out->end(), s.in + s.pos, s.in + s.pos + len); s.pos += len;
    } else if (type == 1) {  // 固定哈夫曼表
      if (!fixedReady) {
        short l[288];
        for (int i = 0; i < 288; i++) l[i] = (short)(i < 144 ? 8 : i < 256 ? 9 : i < 280 ? 7 : 8);  // 固定表的码长（RFC 1951 3.2.6）
        construct(flc, l, 288);
        for (int i = 0; i < 30; i++) l[i] = 5;
        construct(fdc, l, 30); fixedReady = true;
      }
      if (!codes(s, flc, fdc)) return false;
    } else if (type == 2) {  // 动态哈夫曼表
      static const unsigned char order[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15};
      int nlen = s.bits(5) + 257, ndist = s.bits(5) + 1, ncode = s.bits(4) + 4; if (s.err || nlen > 286 || ndist > 30) return false;
      short l[320]; int i;
      for (i = 0; i < 19; i++) l[order[i]] = (short)(i < ncode ? s.bits(3) : 0);
      Huff lc, dc; if (s.err || construct(lc, l, 19) != 0) return false;
      for (i = 0; i < nlen + ndist;) {
        int sym = decode(s, lc); if (sym < 0) return false;
        if (sym < 16) { l[i++] = (short)sym; continue; }
        int rep, val = 0;
        if (sym == 16) { if (i == 0) return false; val = l[i - 1]; rep = 3 + s.bits(2); }
        else if (sym == 17) rep = 3 + s.bits(3);
        else rep = 11 + s.bits(7);
        if (s.err || i + rep > nlen + ndist) return false;
        while (rep--) l[i++] = (short)val;
      }
      if (l[256] == 0) return false;
      int e = construct(lc, l, nlen); if (e < 0 || (e > 0 && nlen - lc.count[0] != 1)) return false;
      e = construct(dc, l + nlen, ndist); if (e < 0 || (e > 0 && ndist - dc.count[0] != 1)) return false;
      if (!codes(s, lc, dc)) return false;
    } else return false;
  } while (!last);
  return true;
}
// 解开 zlib 数据（RFC 1950）：maxOut 为最多解出的字节数；校验 Adler-32
static bool Zlib(const unsigned char* p, size_t n, std::vector<unsigned char>& out, size_t maxOut) {
  if (n < 6 || (p[0] & 0x0F) != 8 || ((p[0] << 8) | p[1]) % 31 != 0 || (p[1] & 0x20)) return false;
  St s = {p, n, 2, 0, 0, &out, maxOut, false}; out.clear();
  if (!inflate(s)) return false;
  if (s.pos + 4 > n) return false;
  unsigned want = ((unsigned)p[s.pos] << 24) | ((unsigned)p[s.pos + 1] << 16) | ((unsigned)p[s.pos + 2] << 8) | p[s.pos + 3];
  unsigned a = 1, b = 0; for (unsigned char c : out) { a = (a + c) % 65521; b = (b + a) % 65521; }
  return ((b << 16) | a) == want;
}
// 易语言「ZLIB压缩数据」：返回 1 解开了，0 不是这种格式，-1 是这种格式但数据坏了
static int EData(const std::vector<unsigned char>& in, std::vector<unsigned char>& out) {
  if (in.size() < 8 || in[0] != 0x0D || in[1] != 0x0F || in[2] != 0x3E || in[3] != 0x03) return 0;
  size_t len = in[4] | (in[5] << 8) | (in[6] << 16) | ((size_t)in[7] << 24);
  if (len == 0 || len > (256u << 20)) return -1;
  if (!Zlib(in.data() + 8, in.size() - 8, out, len) || out.size() != len) return -1;
  return 1;
}
}  // namespace ezl
// 准备要载入的 DLL：是 DLL 原文件（MZ 开头）就原样用；是易语言「ZLIB压缩数据」就解开写到 dst；都不是返回假并说明原因（不再交给 LoadLibrary，免得 Windows 弹“损坏的映像”）
static bool PrepareDll(const std::wstring& src, const std::wstring& dst, std::string& why, bool* unpacked) {
  std::vector<unsigned char> in; *unpacked = false;
  { FILE* f = _wfopen(src.c_str(), L"rb"); if (!f) { why = "打不开这个文件"; return false; }
    unsigned char b[65536]; size_t k; while ((k = fread(b, 1, sizeof b, f)) > 0) in.insert(in.end(), b, b + k); fclose(f); }
  std::vector<unsigned char> dec; const std::vector<unsigned char>* use = &in;
  if (!(in.size() >= 2 && in[0] == 'M' && in[1] == 'Z')) {
    int r = ezl::EData(in, dec);
    if (r == 0) { why = "既不是 DLL 原文件，也不是易语言「ZLIB压缩数据」的格式"; return false; }
    if (r < 0 || dec.size() < 2 || dec[0] != 'M' || dec[1] != 'Z') { why = "是易语言「ZLIB压缩数据」的格式，但解不开或解出来的不是 DLL（文件坏了）"; return false; }
    use = &dec; *unpacked = true;
  }
  if (src == dst && !*unpacked) return true;
  FILE* g = _wfopen(dst.c_str(), L"wb"); if (!g) { why = "写不出解好的 DLL"; return false; }
  bool ok = fwrite(use->data(), 1, use->size(), g) == use->size(); fclose(g);
  if (!ok) why = "解好的 DLL 没写全";
  return ok;
}
// 等到条件成立（每 25 毫秒看一次，最多 ms 毫秒）：界面线程是异步处理的，机器忙时晚一点也不算错；条件一直不成立才算失败
template <class F> static bool WaitUntil(F cond, int ms) { for (int t = 0; t < ms; t += 25) { if (cond()) return true; Sleep(25); } return (bool)cond(); }  // 在 Wine 里跑：阿拉伯语的排版与 Windows 不同，只报告不判定
// 真机上“点外面”改点悬浮窗自己左边空白、不透明的地方：不会点到别的程序；悬浮窗不接受激活，这一下只会关掉菜单 / 画廊。
// （试过在落点放一个本进程的空白小窗：不论小窗在哪个线程，Wine 里点它都会让悬浮窗之后再显示不出来，所以不用）
typedef INT_PTR(WINAPI* F4)(INT_PTR, INT_PTR, INT_PTR, INT_PTR);  // 与下面同一个类型（C++ 允许重复声明）
static F4 g_info = nullptr, g_thit = nullptr;
static bool BlankSpot(POINT* out) {
  HWND fw = (HWND)g_info(9, 0, 0, 0); RECT wr; if (!fw || !GetWindowRect(fw, &wr)) return false;
  int W = (int)g_info(11, 0, 0, 0), H = (int)g_info(12, 0, 0, 0), m = ((wr.right - wr.left) - W) / 2;
  std::vector<RECT> hs; for (int i = 0; i < 64; i++) { RECT r; INT_PTR id = g_thit(i, (INT_PTR)&r, 0, 0); if (!id) break; hs.push_back(r); }
  for (int x = m + H / 2; x < m + W / 2; x += 3) for (int y = m + H / 3; y < m + H - H / 3; y += 3) {  // 左半边（菜单在右键处往右下弹出）、离圆角远一点
    bool in = false; for (auto& r : hs) if (x >= r.left - 3 && x < r.right + 3 && y >= r.top - 3 && y < r.bottom + 3) { in = true; break; }
    if (!in) { out->x = wr.left + x; out->y = wr.top + y; return true; }
  }
  return false;
}
typedef INT_PTR(WINAPI* F4)(INT_PTR, INT_PTR, INT_PTR, INT_PTR);
// 皮肤编号（与 src/xf.h 的 SK_ 常量相同：按推荐顺序，4 组 × 4 款）
enum { SK_CAPSULE = 1, SK_GLASS, SK_CONSOLE, SK_KEYCAP, SK_AURORA, SK_NEON, SK_CYBER, SK_POP, SK_STICKER, SK_CATEAR, SK_COLLAGE, SK_COMIC, SK_VINYL, SK_CASSETTE, SK_PIXEL, SK_SEAL, SK_COUNT = SK_SEAL };
static const int GALLERY_ROW = 100;  // 对比度记录里“皮肤画廊”用的编号（不与真实皮肤号重复；原来用 9，扩到 16 款后与第 9 款相撞）
static HMODULE M;
static F4 P(const char* n) { F4 f = (F4)(void*)GetProcAddress(M, n); if (!f) { printf("FAIL 缺少导出 %s\n", n); } return f; }
static F4 Start, Stop, Show, SetSkin, SetLang, SetFontDir, SetHot, TInfo, TTime, TClip, Duck, Opt, SetPos, Info, Text, Snap, TMouse, THit, TRender, Ver;
static volatile LONG gEvents[32];
static volatile LONG gArgs[32];
static volatile LONG gEventThread = 0;
static INT_PTR WINAPI Cb(INT_PTR ev, INT_PTR arg) { if (ev > 0 && ev < 32) { gArgs[ev] = (LONG)arg; InterlockedIncrement(&gEvents[ev]); } gEventThread = (LONG)GetCurrentThreadId(); return 0; }
static int fails = 0, passes = 0;
static void Check(bool ok, const char* what) { if (ok) { passes++; printf("PASS %s\n", what); } else { fails++; printf("FAIL %s\n", what); } fflush(stdout); }
static std::string U8(const wchar_t* w) { int n = WideCharToMultiByte(CP_UTF8, 0, w, -1, 0, 0, 0, 0); std::string s(n, 0); WideCharToMultiByte(CP_UTF8, 0, w, -1, &s[0], n, 0, 0); s.resize(n - 1); return s; }
static INT_PTR S(const std::string& s) { return (INT_PTR)s.c_str(); }
struct LangCase { const char* code; const wchar_t* sfx; const wchar_t* bgm; const wchar_t* lng; };
static LangCase LC[] = {
  {"zh-Hans", L"掌声雷动", L"舞曲串烧 Vol.3", L"感谢老板送的嘉年华，全场起立鼓掌"},
  {"en", L"Applause", L"Dance Mix Vol.3", L"Thanks for the gift, everybody stand up and cheer"},
  {"de", L"Applaus", L"Dance-Mix Vol.3", L"Danke für das Geschenk, alle aufstehen und jubeln"},
  {"ja", L"拍手喝采", L"ダンスメドレー Vol.3", L"プレゼントありがとう！みんなで拍手しよう"},
  {"ru", L"Аплодисменты", L"Танцевальный микс 3", L"Спасибо за подарок, все встаём и аплодируем"},
  {"ar", L"تصفيق", L"مزيج رقص 3", L"شكرًا على الهدية، الجميع يصفّق الآن"},
};
static void Reset(const LangCase& L) {
  SetLang(S(L.code), 0, 0, 0);
  SetHot(1, S("F12"), 0, 0);
  TInfo(0, 0, S(""), 0); TInfo(1, 0, S(""), 0);
  TTime(0, 0, 0, 0); TTime(1, 0, 0, 0); TClip(0, 0, 0, 0); TClip(1, 0, 0, 0);
  Duck(0, 0, 0, 0); Opt(101, -1, 0, 0); Opt(102, -1, 0, 0); Opt(2, 0, 0, 0); Opt(103, 0, 0, 0);
}
static void Apply(const char* st, const LangCase& L, int skin) {
  Reset(L);
  std::string sfx = U8(L.sfx), bgm = U8(L.bgm), lng = U8(L.lng);
  auto PlaySfx = [&](const std::string& n) { TInfo(0, 1, S(n), 0); TTime(0, 2000, 5000, 70); };
  auto PlayBgm = [&](int pos) { TInfo(1, 1, S(bgm), 0); TTime(1, pos, 235000, 60); };
  std::string s = st;
  if (s == "off") SetHot(0, S("F12"), 0, 0);
  else if (s == "sfx") PlaySfx(sfx);
  else if (s == "bgm") PlayBgm(151000);
  else if (s == "both") { PlaySfx(sfx); PlayBgm(151000); }
  else if (s == "duck") { PlayBgm(151000); Duck(0, 1, 0, 0); }
  else if (s == "vduck") { PlayBgm(151000); Duck(0, 2, 0, 0); }
  else if (s == "sduck") { PlaySfx(sfx); Duck(1, 0, 0, 0); }   // 1.4.0：音效那一路闪避中——只管音效的 14 款显示的就是这一路（duck / vduck 压的是背景音乐，这 14 款不显示）
  else if (s == "svduck") { PlaySfx(sfx); Duck(2, 0, 0, 0); }
  else if (s == "ending") PlayBgm(227000);
  else if (s == "numlock") SetHot(1, S("F12"), 1, 0);
  else if (s == "hover") { PlaySfx(sfx); PlayBgm(151000); Opt(101, 1, 0, 0); }
  else if (s == "hoveridle") Opt(101, 1, 0, 0);
  else if (s == "nokey") SetHot(1, S(""), 0, 0);
  else if (s == "long") PlaySfx(lng);
  else if (s == "paused") { TInfo(0, 2, S(sfx), 0); TTime(0, 2000, 5000, 0); }
  else if (s == "dock") { PlaySfx(sfx); Opt(2, skin == SK_CAPSULE ? 3 : 1, 0, 0); }
  else if (s == "dark") { PlaySfx(sfx); Opt(102, 1, 0, 0); }
  if (s != "hover" && s != "hoveridle") Opt(101, 0, 0, 0);  // 固定为鼠标不在上面：真实鼠标碰巧停在悬浮窗上时（位置随皮肤变），成对的截图会一张悬停一张不悬停
}
static int RoleOf(int sk) { static const int R[17] = {0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}; return (sk >= 1 && sk <= 16) ? R[sk] : 1; }  // 1.3.0：与 xf_skins.cpp 的 kTraits 一致（1.4.0：黑胶唱机、磁带也只管音效，原来是 2 只管背景音乐）
static void ApplyRoleDuck(const LangCase& L, int sk) {  // 1.3.0：闪避按皮肤的角色——只管音效的放音效、压音效那一路；其余照旧压背景音乐
  if (RoleOf(sk) != 1) { Apply("duck", L, sk); return; }
  Reset(L); TInfo(0, 1, S(U8(L.sfx)), 0); TTime(0, 2000, 5000, 70); Duck(1, 0, 0, 0); Opt(101, 0, 0, 0);
}
static int PngH(const std::string& p) { FILE* f = Fopen8(p, L"rb"); if (!f) return 0; unsigned char h[24] = {0}; size_t n = fread(h, 1, 24, f); fclose(f); if (n < 24) return 0; return (h[20] << 24) | (h[21] << 16) | (h[22] << 8) | h[23]; }
static DWORD WINAPI Worker(LPVOID p) {
  int sd = (int)(INT_PTR)p;
  for (int i = 0; i < 3000; i++) {
    int v = (i * 7919 + sd * 104729) & 1023;
    switch (v % 5) {
      case 0: TInfo(v & 1, v % 3, (INT_PTR)(v & 2 ? "测试名称" : "x"), 0); break;
      case 1: TTime(v & 1, v * 13, 60000, v % 100); break;
      case 2: SetHot(v & 1, (INT_PTR)(v & 4 ? "F8" : ""), v & 8, 0); break;
      case 3: Duck(v % 3, (v / 3) % 3, v & 1, v % 4); break;
      case 4: SetLang((INT_PTR)(v & 1 ? "en" : "ar"), 0, 0, 0); break;
    }
  }
  return 0;
}
// ---------------- 对比度（WCAG 2.x，正文 4.5:1）----------------
// 同一画面画两张：有字（_0）和不画字（_1，选项 111）；画有字那张时用选项 112 记下每段字的颜色和画布上的框。
// 框里两张图不一样的像素就是笔画；在不画字的那张上取这些像素的底色，与记录的文字颜色算对比度。
// 窗口是逐像素透明的：底色带透明时分别垫黑色、白色桌面，取差的那个；文字颜色带透明时叠在底色上算。
// 每段取笔画像素里第 10 百分位的对比度（底色有渐变时看偏差的那一成，不被个别边缘像素左右）。
struct Img { int w = 0, h = 0; std::vector<unsigned> px; };  // 非预乘 ARGB
static bool LoadPng(const std::string& path, Img& im) {
  std::wstring wp(path.size() + 1, 0); wp.resize(MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, &wp[0], (int)wp.size()) - 1);
  Gdiplus::Bitmap b(wp.c_str());
  if (b.GetLastStatus() != Gdiplus::Ok) return false;
  im.w = (int)b.GetWidth(); im.h = (int)b.GetHeight(); im.px.assign((size_t)im.w * im.h, 0);
  Gdiplus::Rect r(0, 0, im.w, im.h); Gdiplus::BitmapData bd;
  if (b.LockBits(&r, Gdiplus::ImageLockModeRead, PixelFormat32bppARGB, &bd) != Gdiplus::Ok) return false;
  for (int y = 0; y < im.h; y++) memcpy(&im.px[(size_t)y * im.w], (const BYTE*)bd.Scan0 + y * bd.Stride, (size_t)im.w * 4);
  b.UnlockBits(&bd);
  return true;
}
struct Rgb { double r, g, b; };
static double Lin(double v) { v /= 255.0; return v <= 0.04045 ? v / 12.92 : pow((v + 0.055) / 1.055, 2.4); }
static double Lum(const Rgb& c) { return 0.2126 * Lin(c.r) + 0.7152 * Lin(c.g) + 0.0722 * Lin(c.b); }
static double Ratio(double a, double b) { if (a < b) std::swap(a, b); return (a + 0.05) / (b + 0.05); }
static Rgb Over(unsigned argb, const Rgb& d) { double a = (argb >> 24) / 255.0; return {((argb >> 16) & 255) * a + d.r * (1 - a), ((argb >> 8) & 255) * a + d.g * (1 - a), (argb & 255) * a + d.b * (1 - a)}; }
static int PmDiff(unsigned p, unsigned q) {  // 预乘后各通道差的最大值
  int pa = p >> 24, qa = q >> 24, d = abs(pa - qa);
  for (int sh = 0; sh <= 16; sh += 8) { int x = (int)((p >> sh) & 255) * pa / 255, y = (int)((q >> sh) & 255) * qa / 255; d = std::max(d, abs(x - y)); }
  return d;
}
struct Seg {
  unsigned col = 0; float x0 = 0, y0 = 0, x1 = 0, y1 = 0, px = 0; int style = 0; char kind = 'T'; std::string text;
  int n = 0; double c10 = 0, cmin = 0, eff = 0; bool aligned = true;  // eff：点阵字打点后按平均亮度算的对比度（0＝没算）
};
static std::vector<Seg> ReadLog(const std::string& path) {
  std::vector<Seg> v; FILE* f = Fopen8(path, L"rb"); if (!f) return v;
  char line[4096];
  while (fgets(line, sizeof line, f)) {
    std::string L = line; while (!L.empty() && (L.back() == '\n' || L.back() == '\r')) L.pop_back();
    std::vector<std::string> F; size_t a = 0;
    for (int i = 0; i < 8; i++) { size_t b = L.find('\t', a); if (b == std::string::npos) break; F.push_back(L.substr(a, b - a)); a = b + 1; }
    if (F.size() < 8) continue;
    Seg s; s.col = (unsigned)strtoul(F[0].c_str(), 0, 16); s.x0 = (float)atof(F[1].c_str()); s.y0 = (float)atof(F[2].c_str()); s.x1 = (float)atof(F[3].c_str()); s.y1 = (float)atof(F[4].c_str());
    s.px = (float)atof(F[5].c_str()); s.style = atoi(F[6].c_str()); s.kind = F[7].empty() ? 'T' : F[7][0]; s.text = L.substr(a);
    v.push_back(s);
  }
  fclose(f);
  return v;
}
static void Measure(const Img& a, const Img& b, Seg& s) {
  int X0 = std::max(0, (int)floorf(s.x0) - 3), Y0 = std::max(0, (int)floorf(s.y0) - 3), X1 = std::min(a.w, (int)ceilf(s.x1) + 3), Y1 = std::min(a.h, (int)ceilf(s.y1) + 3);
  std::vector<double> cs; int best = -1, bestd = 0;
  const Rgb desk[2] = {{0, 0, 0}, {255, 255, 255}}, gray = {128, 128, 128};
  for (int y = Y0; y < Y1; y++) for (int x = X0; x < X1; x++) {
    size_t i = (size_t)y * a.w + x; int d = PmDiff(a.px[i], b.px[i]);
    if (d < 24) continue;  // 不是笔画（或只是笔画边缘极淡的一点）
    if (d > bestd) { bestd = d; best = (int)i; }
    // 这个像素是不是这段字画的：有字图上的颜色应落在“底色 → 文字颜色”的连线附近；别的字、字的阴影、别色的光晕不算
    Rgb bg = Over(b.px[i], gray), fg = Over(s.col, bg), got = Over(a.px[i], gray);
    double vx = fg.r - bg.r, vy = fg.g - bg.g, vz = fg.b - bg.b, ux = got.r - bg.r, uy = got.g - bg.g, uz = got.b - bg.b, nv2 = vx * vx + vy * vy + vz * vz;
    double t = nv2 > 1e-9 ? (ux * vx + uy * vy + uz * vz) / nv2 : 0; t = t < 0 ? 0 : t > 1.2 ? 1.2 : t;
    double ex = ux - t * vx, ey = uy - t * vy, ez = uz - t * vz;
    if (t < 0.05 || sqrt(ex * ex + ey * ey + ez * ez) > 20 + 0.15 * sqrt(nv2)) continue;
    double worst = 1e9;
    for (const Rgb& D : desk) { Rgb bgd = Over(b.px[i], D), fgd = Over(s.col, bgd); worst = std::min(worst, Ratio(Lum(fgd), Lum(bgd))); }
    cs.push_back(worst);
  }
  s.n = (int)cs.size();
  if (best >= 0) {  // 位置自检：两张图差别最大的像素应当是这段字画的（从底色朝记录的文字颜色走、不远远越过）；对不上说明框没落在这段字上
    Rgb bg = Over(b.px[best], gray), got = Over(a.px[best], gray), fg = Over(s.col, bg);
    double vx = fg.r - bg.r, vy = fg.g - bg.g, vz = fg.b - bg.b, ux = got.r - bg.r, uy = got.g - bg.g, uz = got.b - bg.b;
    double nv = sqrt(vx * vx + vy * vy + vz * vz), nu = sqrt(ux * ux + uy * uy + uz * uz);
    s.aligned = nu <= nv * 1.25 + 12 && (nv < 8 || (vx * ux + vy * uy + vz * uz) / (nv * nu + 1e-9) > 0.8);
  }
  if (!s.n) { s.c10 = s.cmin = 1.0; return; }  // 框里没有这段字的笔画：字和底色一样（看不见）或记录的位置不对，按 1:1 算
  std::sort(cs.begin(), cs.end()); s.cmin = cs[0]; s.c10 = cs[cs.size() / 10];
}
// 豁免：有意画得很淡、不承担信息的字（DLL 在画的地方标了种类，理由写在这里）。返回理由，不豁免返回 nullptr
static const char* Exempt(int skin, const char* state, const Seg& s) {
  if (s.kind == 'O') return "熄灭的灯管（关闭状态的装饰：灯牌熄了只剩管壁；状态由点阵屏上的字说明）";
  if (s.kind == 'D') return "未激活的占位（没在放时的 00:00，旁边写着“暂无音效播放”）";
  (void)skin; (void)state;
  return nullptr;
}
// 已知的有意遮盖：别的东西盖在这段字上面，位置自检会对不上（对比度只量露出来的笔画）
static const char* Covered(int skin, const char* state, const Seg& s) {
  if (skin == SK_CASSETTE && !strcmp(state, "numlock") && s.text == "F12") return "便利贴盖住了键帽";
  return nullptr;
}
struct CRow { int skin; std::string state, lang; int pct; Seg s; const char* why; const char* cover; };
static void ContrastCase(const std::string& dir, int skin, const char* state, const char* lang, int pct, std::vector<CRow>& rows, int* shotFail) {
  char base[600]; sprintf(base, "%s\\c%d_%s_%s_%d", dir.c_str(), skin, state, lang, pct);
  std::string p0 = std::string(base) + "_0.png", p1 = std::string(base) + "_1.png", lg = std::string(base) + ".txt";
  DeleteFileW(W8(lg).c_str());
  Opt(111, 0, 0, 0); Opt(112, S(lg), 0, 0);
  bool ok = Snap(S(p0), pct, 0, 0) == 1;
  Opt(112, S(""), 0, 0); Opt(111, 1, 0, 0);
  ok = Snap(S(p1), pct, 0, 0) == 1 && ok;
  Opt(111, 0, 0, 0);
  Img a, b, c;
  if (!ok || !LoadPng(p0, a) || !LoadPng(p1, b) || a.w != b.w || a.h != b.h) { (*shotFail)++; printf("INFO 对比度：截图或读图失败 %s\n", base); return; }
  std::vector<Seg> segs = ReadLog(lg);
  bool dots = false; for (auto& s : segs) if (s.kind == 'L') dots = true;
  if (dots) {  // 点阵字：再画一张不打点的（选项 113），用它找出字本来的笔画范围
    std::string p2 = std::string(base) + "_2.png";
    Opt(113, 1, 0, 0); bool ok2 = Snap(S(p2), pct, 0, 0) == 1; Opt(113, 0, 0, 0);
    if (!ok2 || !LoadPng(p2, c) || c.w != a.w || c.h != a.h) { (*shotFail)++; dots = false; }
  }
  for (Seg& s : segs) {
    bool blank = true; for (char ch : s.text) if (ch != ' ') { blank = false; break; }
    if (blank) continue;
    Measure(a, b, s);
    if (dots && s.kind == 'L') {  // 打点后人眼看到的是一格里亮点与暗缝的平均：在字本来的笔画（不打点那张上着色足的像素）上按线性亮度取平均
      int X0 = std::max(0, (int)floorf(s.x0) - 3), Y0 = std::max(0, (int)floorf(s.y0) - 3), X1 = std::min(a.w, (int)ceilf(s.x1) + 3), Y1 = std::min(a.h, (int)ceilf(s.y1) + 3), mx = 0;
      for (int y = Y0; y < Y1; y++) for (int x = X0; x < X1; x++) { size_t i = (size_t)y * a.w + x; mx = std::max(mx, PmDiff(c.px[i], b.px[i])); }
      double worst = 1e9; const Rgb desk[2] = {{0, 0, 0}, {255, 255, 255}};
      for (const Rgb& D : desk) {
        double lt = 0, lb = 0; int m = 0;
        for (int y = Y0; y < Y1; y++) for (int x = X0; x < X1; x++) { size_t i = (size_t)y * a.w + x; if (mx < 24 || PmDiff(c.px[i], b.px[i]) < mx * 9 / 10) continue;  /* 只取着色足的像素：边缘半透明的像素会把平均拉低 */ lt += Lum(Over(a.px[i], D)); lb += Lum(Over(b.px[i], D)); m++; }
        if (m) worst = std::min(worst, Ratio(lt / m, lb / m));
      }
      if (worst < 1e8) { s.eff = worst; s.c10 = std::min(s.c10, worst); }
    }
    rows.push_back({skin, state, lang, pct, s, Exempt(skin, state, s), Covered(skin, state, s)});
  }
}
static void ContrastSuite(const std::string& out) {
  std::string dir = out + "\\contrast"; CreateDirectoryW(W8(dir).c_str(), 0);
  const char* states[] = {"on", "off", "sfx", "bgm", "both", "duck", "vduck", "sduck", "svduck", "ending", "numlock", "hover", "hoveridle", "nokey", "long", "paused", "dock", "dark"};
  std::vector<CRow> rows; int shotFail = 0;
  for (int skin = 1; skin <= SK_COUNT; skin++) {
    SetSkin(skin, 0, 0, 0);
    for (const char* st : states) {
      if (!strcmp(st, "dark") && skin != SK_GLASS) continue;
      Apply(st, LC[0], skin);
      for (int pct : {100, 150, 200}) ContrastCase(dir, skin, st, "zh-Hans", pct, rows, &shotFail);
    }
    for (int li : {1, 5}) for (const char* st : {"on", "off", "sfx", "bgm"}) { Apply(st, LC[li], skin); ContrastCase(dir, skin, st, LC[li].code, 100, rows, &shotFail); }  // 英文、阿拉伯文（整体镜像）
    for (const char* code : {"zh-Hant", "ja", "ko", "es", "pt-BR", "fr", "de", "id", "th", "vi", "tr", "ru", "ms", "fil", "hi", "it"}) {  // 其余语种看“开启”状态（标签长短不一，看会不会压到别的东西上）
      LangCase L = {code, L"", L"", L""}; Apply("on", L, skin); ContrastCase(dir, skin, "on", code, 100, rows, &shotFail);
    }
  }
  // 毛玻璃组件卡有实时模糊时（底色 84%）：黑、白两种背景都检查——模糊后的背景亮度总在这两者之间，文字对比度也就在两者之间
  Opt(114, 1, 0, 0);
  for (const char* st : {"on", "sfx", "bgm", "off", "numlock", "dark"}) for (int pct : {100, 200}) {
    SetSkin(SK_GLASS, 0, 0, 0); Apply(st, LC[0], SK_GLASS); char lab[32]; sprintf(lab, "%s+glass", st); ContrastCase(dir, SK_GLASS, lab, "zh-Hans", pct, rows, &shotFail);
  }
  Opt(114, 0, 0, 0); Opt(102, -1, 0, 0);
  // 右键菜单（也代表文字提示：同一套配色）
  F4 MSnap = P("XF_TestMenuSnap");
  for (int skin = 1; skin <= SK_COUNT + 1; skin++) {  // 最后一轮：组件卡的深色菜单
    bool dk = skin == SK_COUNT + 1; int sk = dk ? SK_GLASS : skin; Reset(LC[0]); SetSkin(sk, 0, 0, 0); if (dk) Opt(102, 1, 0, 0);
    char base[600]; sprintf(base, "%s\\menu%d%s", dir.c_str(), sk, dk ? "_dark" : "");
    std::string p0 = std::string(base) + "_0.png", p1 = std::string(base) + "_1.png", lg = std::string(base) + ".txt";
    DeleteFileW(W8(lg).c_str()); Opt(111, 0, 0, 0); Opt(112, S(lg), 0, 0);
    bool ok = MSnap(S(p0), 0, 0, 0) == 1; Opt(112, S(""), 0, 0); Opt(111, 1, 0, 0); ok = MSnap(S(p1), 0, 0, 0) == 1 && ok; Opt(111, 0, 0, 0);
    Img a, b;
    if (!ok || !LoadPng(p0, a) || !LoadPng(p1, b)) { shotFail++; continue; }
    for (Seg& s : ReadLog(lg)) { Measure(a, b, s); rows.push_back({sk, dk ? "menu_dark" : "menu", "zh-Hans", 100, s, nullptr, nullptr}); }
  }
  {  // 皮肤画廊：标题、操作说明、16 个名字（画在不镜像的位图上，阿拉伯语也照常判定）
    F4 Gal = P("XF_TestGallery"), Menu = P("XF_TestMenu");
    for (int li : {0, 1, 5}) {
      Reset(LC[li]); SetSkin(1, 0, 0, 0); Menu(9, 0, 0, 0);
      char base[600]; sprintf(base, "%s\\gallery_%s", dir.c_str(), LC[li].code);
      std::string p0 = std::string(base) + "_0.png", p1 = std::string(base) + "_1.png", lg = std::string(base) + ".txt";
      DeleteFileW(W8(lg).c_str()); Opt(111, 0, 0, 0); Opt(112, S(lg), 0, 0);
      bool ok = Gal(1, 0, S(p0), 0) == 1; Opt(112, S(""), 0, 0); Opt(111, 1, 0, 0); ok = Gal(1, 0, S(p1), 0) == 1 && ok; Opt(111, 0, 0, 0);
      Gal(4, 0, 0, 0);
      Img a, b;
      if (!ok || !LoadPng(p0, a) || !LoadPng(p1, b)) { shotFail++; continue; }
      for (Seg& s : ReadLog(lg)) { Measure(a, b, s); rows.push_back({GALLERY_ROW, "gallery", LC[li].code, 100, s, nullptr, nullptr}); }
    }
  }
  Reset(LC[0]); SetSkin(1, 0, 0, 0);
  // 全部结果写成表（方便人看），再按款判定
  FILE* tf = Fopen8(dir + "\\contrast.tsv", L"wb");
  if (tf) fprintf(tf, "skin\tstate\tlang\tpct\tkind\tcolor\tpx\tn\tc10\tcmin\teff\taligned\texempt\tcover\ttext\n");
  for (auto& r : rows) if (tf) fprintf(tf, "%d\t%s\t%s\t%d\t%c\t%08X\t%.1f\t%d\t%.2f\t%.2f\t%.2f\t%d\t%s\t%s\t%s\n", r.skin, r.state.c_str(), r.lang.c_str(), r.pct, r.s.kind, r.s.col, r.s.px, r.s.n, r.s.c10, r.s.cmin, r.s.eff, r.s.aligned ? 1 : 0, r.why ? r.why : "", r.cover ? r.cover : "", r.s.text.c_str());
  if (tf) fclose(tf);
  Check(shotFail == 0, "对比度：有字 / 不画字的截图都画出来了");
  int misplaced = 0;
  for (auto& r : rows) if (!r.s.aligned && !r.cover && (r.lang != "ar" || !g_wine || r.skin == GALLERY_ROW)) { misplaced++; if (misplaced <= 8) printf("INFO 记录的框对不上画面 第 %d 款 %s %s %d%% 「%s」\n", r.skin, r.state.c_str(), r.lang.c_str(), r.pct, r.s.text.c_str()); }
  Check(misplaced == 0 && !rows.empty(), "对比度：每段字记录的位置都落在画面上这段字的笔画上（含图层里画的字；已知的有意遮盖除外）");
  {  // 上下两行字之间留有空隙：按 Windows 常用界面字体（Segoe UI、微软雅黑 UI）的行高（约 1.36 倍字号）算，上一行的下伸笔画（y、g、p）也碰不到下一行。
     // 真机自测发现猫耳胶囊两行的框紧挨着（标题的下伸笔画落进第二行），Wine 的替代字体行高小、看不出来；这一项只用排版位置与字号，与装了什么字体无关。
     // 只看皮肤本身（不含右键菜单、画廊）、横向有重叠的两段字；已知的有意遮盖（磁带上的便利贴）除外
    std::map<std::string, std::vector<const CRow*>> byImg;
    for (auto& r : rows) if (r.s.kind == 'T' && r.s.px > 0 && r.skin >= 1 && r.skin <= SK_COUNT && r.state.compare(0, 4, "menu") != 0 && !r.cover)
      byImg[std::to_string(r.skin) + "|" + r.state + "|" + r.lang + "|" + std::to_string(r.pct)].push_back(&r);
    int pairs = 0, tight = 0; std::string info;
    for (auto& kv : byImg) for (const CRow* a : kv.second) for (const CRow* b : kv.second) {
      if (a == b) continue;
      float ca = (a->s.y0 + a->s.y1) / 2, cb = (b->s.y0 + b->s.y1) / 2, mn = std::min(a->s.px, b->s.px);
      if (cb <= ca + 0.3f * mn) continue;                                              // b 在 a 下面一行（同一行的不算）
      if (std::min(a->s.x1, b->s.x1) - std::max(a->s.x0, b->s.x0) <= 1) continue;      // 横向有重叠
      pairs++;
      float gap = (cb - 0.68f * b->s.px) - (ca + 0.68f * a->s.px);
      if (gap < 0.16f * mn) { tight++; if (info.size() < 600) { char t[400]; sprintf(t, " 第%d款/%s/%s/%d%%「%s」与「%s」%.1f", a->skin, a->state.c_str(), a->lang.c_str(), a->pct, a->s.text.c_str(), b->s.text.c_str(), gap); info += t; } }
    }
    if (!info.empty()) printf("INFO 上下两行字太挤：%s\n", info.c_str());
    char what[200]; sprintf(what, "上下两行字之间按 Windows 字体的行高也留有空隙（%d 对，与装了什么字体无关）", pairs);
    Check(tight == 0 && pairs > 1000, what);
  }
  for (int skin = 1; skin <= SK_COUNT; skin++) {
    int n = 0, bad = 0, ex = 0; double worst = 99;
    for (auto& r : rows) {
      if (r.skin != skin) continue;
      n++;
      if (r.why) { ex++; continue; }
      if (r.cover) continue;  // 已知的有意遮盖（便利贴盖住键帽等）：露出来的只是零星笔画，对比度不判定
      if (r.lang == "ar" && g_wine) { if (r.s.c10 < 4.5) printf("INFO 对比度（阿拉伯语，Wine 下排版与 Windows 不同，只报告）第 %d 款 %s %d%% 「%s」 %.2f\n", skin, r.state.c_str(), r.pct, r.s.text.c_str(), r.s.c10); continue; }
      if (r.s.c10 < 4.5) { bad++; if (bad <= 6) printf("INFO 对比度不足 第 %d 款 %s %s %d%% 「%s」 %.2f（最差 %.2f，文字 #%08X，%d 个笔画像素）\n", skin, r.state.c_str(), r.lang.c_str(), r.pct, r.s.text.c_str(), r.s.c10, r.s.cmin, r.s.col, r.s.n); }
      worst = std::min(worst, r.s.c10);
    }
    char what[200]; sprintf(what, "对比度：第 %d 款 %d 段文字（含右键菜单）都不低于 4.5（豁免 %d 段，阿拉伯语只报告；最低 %.2f）", skin, n, ex, worst);
    Check(bad == 0 && n > 0, what);
  }
  {
    int n = 0, bad = 0; double worst = 99;
    for (auto& r : rows) if (r.skin == GALLERY_ROW) { n++; worst = std::min(worst, r.s.c10); if (r.s.c10 < 4.5) { bad++; printf("INFO 对比度不足 皮肤画廊 %s 「%s」 %.2f\n", r.lang.c_str(), r.s.text.c_str(), r.s.c10); } }
    char what[200]; sprintf(what, "对比度：皮肤画廊 %d 段文字（中、英、阿拉伯）都不低于 4.5（最低 %.2f）", n, worst);
    Check(bad == 0 && n >= 30, what);
  }
}
// ---- 长时间测试（xftest.exe soak [分钟] [字体包目录]，或双击「长时间测试.bat」）：照实际用法不停地变（不切字体目录），每 30 秒记私有内存、句柄、GDI / USER 对象；
// 去掉开头四分之一的预热样本后拟合直线，按每小时的增长判定（10 分钟以下只报告）。不发真实的鼠标键盘输入，测试期间可以照常用电脑
static int RunSoak(int minutes, const std::string& fontDir) {
  typedef BOOL(WINAPI * GPMI)(HANDLE, PPROCESS_MEMORY_COUNTERS, DWORD);
  GPMI gpmi = (GPMI)(void*)GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "K32GetProcessMemoryInfo");
  F4 MSnap = P("XF_TestMenuSnap"), Menu = P("XF_TestMenu"), Gal = P("XF_TestGallery");
  if (!fontDir.empty()) SetFontDir(S(fontDir), 0, 0, 0);
  if (!Start(300, 200, 0, (INT_PTR)Cb)) { printf("FAIL 长时间测试：悬浮窗没能启动\n"); return 1; }
  SetLang(S("zh-Hans"), 0, 0, 0); SetHot(1, S("F12"), 0, 0); Opt(100, 0, 0, 0);
  const char* langs[5] = {"zh-Hans", "en", "ar", "ja", "ru"};
  const char* names[4] = {"\xE6\x8E\x8C\xE5\xA3\xB0\xE9\x9B\xB7\xE5\x8A\xA8", "A very long sound effect name that needs to scroll in the window", "\xD9\x85\xD8\xB1\xD8\xAD\xD8\xA8\xD8\xA7", "X"};
  struct Smp { double min, mem, ws; double h, gdi, user; }; std::vector<Smp> ss;
  DWORD t0 = GetTickCount(), last = 0;
  auto Sample = [&]() {
    PROCESS_MEMORY_COUNTERS_EX pm = {}; pm.cb = sizeof(pm); if (gpmi) gpmi(GetCurrentProcess(), (PPROCESS_MEMORY_COUNTERS)&pm, sizeof(pm));
    DWORD hc = 0; GetProcessHandleCount(GetCurrentProcess(), &hc);
    Smp s; s.min = (GetTickCount() - t0) / 60000.0; s.ws = pm.WorkingSetSize / 1048576.0; s.mem = pm.PrivateUsage ? pm.PrivateUsage / 1048576.0 : s.ws;  // Wine 不给私有内存：改看工作集
    s.h = hc; s.gdi = GetGuiResources(GetCurrentProcess(), GR_GDIOBJECTS); s.user = GetGuiResources(GetCurrentProcess(), GR_USEROBJECTS); ss.push_back(s);
    printf("SAMPLE %5.1f 分钟  私有内存 %7.1f MB  工作集 %7.1f MB  句柄 %4.0f  GDI %4.0f  USER %4.0f\n", s.min, s.mem, s.ws, s.h, s.gdi, s.user);
    last = GetTickCount();
  };
  Sample();
  for (int it = 0; GetTickCount() - t0 < (DWORD)minutes * 60000u; it++) {
    SetSkin(1 + (it / 30) % SK_COUNT, 0, 0, 0);                                                        // 每 3 秒换一款
    TInfo(0, (it / 40) % 5 != 0, S(names[(it / 70) % 4]), 0); TTime(0, (it * 100) % 60000, 60000, 70);
    TInfo(1, (it / 55) % 4 != 0, S(names[(it / 90) % 4]), 0); TTime(1, (it * 100) % 240000, 240000, 60);
    Opt(101, (it / 25) % 3 - 1, 0, 0);                                                           // 悬停：跟鼠标 / 不悬停 / 悬停
    if (it % 600 == 0) SetLang(S(langs[(it / 600) % 5]), 0, 0, 0);                              // 每分钟换一种语言（含阿拉伯语）
    if (it % 50 == 0) Snap(S(std::string("soak_shot.png")), (it / 50) % 2 ? 100 : 200, 0, 0);   // 每 5 秒截一次图
    if (it % 150 == 0) MSnap(S(std::string("soak_menu.png")), 0, 0, 0);                         // 每 15 秒画一次右键菜单
    if (it % 300 == 0) { Menu(9, 0, 0, 0); Sleep(150); Gal(4, 0, 0, 0); }                         // 每 30 秒开关一次画廊
    if (it % 450 == 0) Opt(4, (it / 450) % 2 ? 125 : 100, 0, 0);                                 // 每 45 秒改一次大小
    Sleep(100);
    if (GetTickCount() - last >= 30000) Sample();
  }
  Sample(); Stop(0, 0, 0, 0);
  size_t from = ss.size() / 4; if (from < 1) from = 1;  // 开头四分之一当预热（缓存、字体刚建好）
  auto Slope = [&](double Smp::*f) { double n = 0, mx = 0, my = 0; for (size_t i = from; i < ss.size(); i++) { n++; mx += ss[i].min; my += ss[i].*f; } if (n < 2) return 0.0; mx /= n; my /= n;
    double a = 0, b = 0; for (size_t i = from; i < ss.size(); i++) { a += (ss[i].min - mx) * (ss[i].*f - my); b += (ss[i].min - mx) * (ss[i].min - mx); } return b > 0 ? a / b * 60 : 0.0; };  // 每小时
  double sm = Slope(&Smp::mem), sh = Slope(&Smp::h), sg = Slope(&Smp::gdi), su = Slope(&Smp::user);
  printf("RESULT 预热之后的增长（折算到每小时）：私有内存 %+.1f MB，句柄 %+.0f，GDI %+.0f，USER %+.0f\n", sm, sh, sg, su);
  if (minutes < 10) { printf("INFO 不到 10 分钟：只报告，不判定（时间太短，直线拟合不可靠）\n"); return 0; }
  Check(sm < 10, "长时间测试：内存不随时间上涨（每小时增长不到 10 MB）");
  Check(sg < 20 && su < 20, "长时间测试：GDI / USER 对象不随时间增加（每小时不到 20 个）");
  Check(sh < 50, "长时间测试：句柄不随时间增加（每小时不到 50 个）");
  return fails ? 1 : 0;
}
static void DumpMsgLog() {  // 打印悬浮窗最近处理的消息（XF_GetInfo 26～90，格式见 xf_core.cpp WndProc 前的说明）
  LONG n = (LONG)Info(26, 0, 0, 0); int kk = n < 32 ? (int)n : 32; printf("INFO 悬浮窗最近处理的消息（由远到近）：\n");
  for (int jj = kk - 1; jj >= 0; jj--) { unsigned e = (unsigned)Info(27 + jj, 0, 0, 0), e2 = (unsigned)Info(59 + jj, 0, 0, 0); unsigned mm = e & 0xFFF; const char* nm = "其他"; char b[16];
    switch (mm) { case 0x200: nm = "MOVE"; break; case 0x201: nm = "LDOWN"; break; case 0x202: nm = "LUP"; break; case 0x203: nm = "LDBL"; break; case 0x205: nm = "RUP"; break; case 0x215: nm = "CAPCHG"; break;
      case 0x2A3: nm = "LEAVE"; break; case 0x1F: nm = "CANCELMODE"; break; case 0x211: nm = "ENTERMENU"; break; case 0x212: nm = "EXITMENU"; break; case 0x117: nm = "INITPOPUP"; break; case 0x125: nm = "UNINITPOPUP"; break;
      case 0x06: nm = "ACTIVATE"; break; case 0x1C: nm = "ACTIVATEAPP"; break; case 0x08: nm = "KILLFOCUS"; break; case 0x07: nm = "SETFOCUS"; break; case 0x86: nm = "NCACTIVATE"; break;
      default: sprintf(b, "0x%X", mm); nm = b; }
    printf("INFO    %-11s 按着 %u→%u %s 间隔 %4u 毫秒  wp=%u  坐标 %4u,%4u  坐标处按钮 %2u  按下目标 %2u%s\n", nm, (e >> 12) & 1, (e >> 13) & 1, (e >> 14) & 1 ? "模拟" : "系统", e >> 22, (e >> 15) & 0x7F,
           e2 & 0x7FF, (e2 >> 11) & 0x7FF, (e2 >> 26) & 0xF, (e2 >> 22) & 0xF, (e2 >> 30) & 1 ? "  拖动中" : ""); }
}
// ---- 多显示器与位置记忆（1.2.0）：假显示器——把 DLL 导入表里的 MonitorFromPoint / GetMonitorInfoW / EnumDisplayMonitors 换成按给定布局作答的函数
// （语义同 Windows：显示器矩形的右、下边界不属于它；按点找不到时 NEAREST 取最近的、PRIMARY 取主屏、NULL 返回空）。不开启时原样转给系统，前面的测试不受影响。
// UpdateLayeredWindow 也接在这里：可以让它在一段时间里返回失败（模拟锁屏 / 安全桌面 / 远程桌面切换时贴不上画面）。Wine 与真机都能跑，不需要真的接几块屏
struct FakeMon { RECT rc, wk; bool primary; };
static std::vector<FakeMon> g_fm;
static volatile bool g_fakeOn = false;
static volatile LONG g_ulwFailUntil = 0;  // GetTickCount 早于它时 UpdateLayeredWindow 返回失败（0＝不模拟）
static volatile HWND g_ulwWatch = nullptr; static volatile LONG g_ulwOk = 0;  // 悬浮窗（建窗口时记下）真正贴上画面的次数：按系统 UpdateLayeredWindow 的返回值数——
// DLL 的帧数（XF_GetInfo 15）在 1.2.0 之前失败也算，拿它判断“真的贴上了”在旧版上也会通过，分不出修没修好
static volatile bool g_cursorFail = false;  // 真：GetCursorPos 返回失败（模拟安全桌面等取不到鼠标位置）
typedef HMONITOR(WINAPI* PMFP)(POINT, DWORD); typedef BOOL(WINAPI* PGMI)(HMONITOR, LPMONITORINFO); typedef BOOL(WINAPI* PEDM)(HDC, LPCRECT, MONITORENUMPROC, LPARAM);
typedef BOOL(WINAPI* PULW)(HWND, HDC, POINT*, SIZE*, HDC, POINT*, COLORREF, BLENDFUNCTION*, DWORD);
static PMFP RealMFP; static PGMI RealGMI; static PEDM RealEDM; static PULW RealULW;
typedef BOOL(WINAPI* PGCP)(LPPOINT); static PGCP RealGCP;
static BOOL WINAPI FakeGCP(LPPOINT p) { if (g_cursorFail) { SetLastError(ERROR_ACCESS_DENIED); return FALSE; } return RealGCP(p); }
typedef HWND(WINAPI* PCWE)(DWORD, LPCWSTR, LPCWSTR, DWORD, int, int, int, int, HWND, HMENU, HINSTANCE, LPVOID);
static PCWE RealCWE; static volatile LONG g_skinMode = 0;  // 建窗口时模拟别的模块（换肤库的建窗口钩子等）动手：悬浮窗 1 调 SetLayeredWindowAttributes 2 设 1×1 窗口区域；提示窗、画廊 4 调 SetLayeredWindowAttributes 8 设 1×1 窗口区域
static HWND WINAPI FakeCWE(DWORD ex, LPCWSTR cls, LPCWSTR name, DWORD st, int x, int y, int w, int h, HWND p, HMENU m, HINSTANCE i, LPVOID lp) {
  HWND r = RealCWE(ex, cls, name, st, x, y, w, h, p, m, i, lp);
  if (r && !IS_INTRESOURCE(cls) && !lstrcmpW(cls, L"XhhFloatWindow")) { g_ulwWatch = r; g_ulwOk = 0; }  // 新建的悬浮窗：从这里开始数真正贴上的画面
  if (r && g_skinMode && !IS_INTRESOURCE(cls) && !lstrcmpW(cls, L"XhhFloatWindow")) {
    if (g_skinMode & 1) SetLayeredWindowAttributes(r, 0, 255, LWA_ALPHA);
    if (g_skinMode & 2) SetWindowRgn(r, CreateRectRgn(0, 0, 1, 1), FALSE);
  }
  if (r && g_skinMode && !IS_INTRESOURCE(cls) && (!lstrcmpW(cls, L"XhhFloatTip") || !lstrcmpW(cls, L"XhhFloatGallery"))) {
    if (g_skinMode & 4) SetLayeredWindowAttributes(r, 0, 255, LWA_ALPHA);
    if (g_skinMode & 8) SetWindowRgn(r, CreateRectRgn(0, 0, 1, 1), FALSE);
  }
  return r;
}
static HMONITOR FmH(int i) { return (HMONITOR)(INT_PTR)(0x7F000 + i); }
static int FmI(HMONITOR h) { INT_PTR v = (INT_PTR)h - 0x7F000; return v >= 0 && v < (INT_PTR)g_fm.size() ? (int)v : -1; }
static HMONITOR WINAPI FakeMFP(POINT p, DWORD fl) {
  if (!g_fakeOn) return RealMFP(p, fl);
  for (size_t i = 0; i < g_fm.size(); i++) { const RECT& r = g_fm[i].rc; if (p.x >= r.left && p.x < r.right && p.y >= r.top && p.y < r.bottom) return FmH((int)i); }
  if (fl == MONITOR_DEFAULTTONULL) return nullptr;
  if (fl == MONITOR_DEFAULTTOPRIMARY) for (size_t i = 0; i < g_fm.size(); i++) if (g_fm[i].primary) return FmH((int)i);
  int best = 0; double bd = 1e300;
  for (size_t i = 0; i < g_fm.size(); i++) { const RECT& r = g_fm[i].rc; double dx = p.x < r.left ? r.left - p.x : p.x >= r.right ? p.x - r.right + 1 : 0, dy = p.y < r.top ? r.top - p.y : p.y >= r.bottom ? p.y - r.bottom + 1 : 0; double d = dx * dx + dy * dy; if (d < bd) { bd = d; best = (int)i; } }
  return FmH(best);
}
static BOOL WINAPI FakeGMI(HMONITOR h, LPMONITORINFO mi) {
  if (!g_fakeOn) return RealGMI(h, mi);
  int i = FmI(h); if (i < 0 || !mi) return FALSE;
  mi->rcMonitor = g_fm[i].rc; mi->rcWork = g_fm[i].wk; mi->dwFlags = g_fm[i].primary ? MONITORINFOF_PRIMARY : 0; return TRUE;
}
static BOOL WINAPI FakeEDM(HDC dc, LPCRECT clip, MONITORENUMPROC cb, LPARAM lp) {
  if (!g_fakeOn) return RealEDM(dc, clip, cb, lp);
  for (size_t i = 0; i < g_fm.size(); i++) { RECT r = g_fm[i].rc; if (!cb(FmH((int)i), nullptr, &r, lp)) break; }
  return TRUE;
}
static BOOL WINAPI FakeULW(HWND h, HDC a, POINT* b, SIZE* c, HDC d, POINT* e, COLORREF f, BLENDFUNCTION* g, DWORD fl) {
  LONG until = g_ulwFailUntil; if (until && (LONG)(GetTickCount() - (DWORD)until) < 0) { SetLastError(ERROR_INVALID_PARAMETER); return FALSE; }
  BOOL r = RealULW(h, a, b, c, d, e, f, g, fl);
  if (r && h == g_ulwWatch) InterlockedIncrement(&g_ulwOk);
  return r;
}
static int PatchIat(HMODULE mod, const char* fn, void* repl) {
  BYTE* base = (BYTE*)mod; IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)(base + ((IMAGE_DOS_HEADER*)base)->e_lfanew);
  IMAGE_DATA_DIRECTORY dd = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT]; if (!dd.VirtualAddress) return 0;
  int n = 0;
  for (IMAGE_IMPORT_DESCRIPTOR* d = (IMAGE_IMPORT_DESCRIPTOR*)(base + dd.VirtualAddress); d->Name; d++) {
    if (lstrcmpiA((const char*)(base + d->Name), "user32.dll") != 0) continue;
    IMAGE_THUNK_DATA* o = (IMAGE_THUNK_DATA*)(base + (d->OriginalFirstThunk ? d->OriginalFirstThunk : d->FirstThunk)); IMAGE_THUNK_DATA* f = (IMAGE_THUNK_DATA*)(base + d->FirstThunk);
    for (; o->u1.AddressOfData; o++, f++) {
      if (IMAGE_SNAP_BY_ORDINAL(o->u1.Ordinal) || strcmp((const char*)((IMAGE_IMPORT_BY_NAME*)(base + o->u1.AddressOfData))->Name, fn) != 0) continue;
      DWORD old; VirtualProtect(&f->u1.Function, sizeof(void*), PAGE_READWRITE, &old); f->u1.Function = (ULONG_PTR)repl; VirtualProtect(&f->u1.Function, sizeof(void*), old, &old); n++;
    }
  }
  return n;
}
static bool FakeInstall(HMODULE m) {  // 载入 DLL 之后、第一次 XF_Start 之前
  HMODULE u = GetModuleHandleW(L"user32.dll");
  RealMFP = (PMFP)(void*)GetProcAddress(u, "MonitorFromPoint"); RealGMI = (PGMI)(void*)GetProcAddress(u, "GetMonitorInfoW"); RealEDM = (PEDM)(void*)GetProcAddress(u, "EnumDisplayMonitors"); RealULW = (PULW)(void*)GetProcAddress(u, "UpdateLayeredWindow");
  RealCWE = (PCWE)(void*)GetProcAddress(u, "CreateWindowExW"); RealGCP = (PGCP)(void*)GetProcAddress(u, "GetCursorPos");
  // 各个替换分别装（原来用 && 串起来：前面哪个没装上，后面的就都不装了——拿旧版 DLL 对照时贴画面失败、建窗口被改都注入不进去）
  const char* fns[] = {"MonitorFromPoint", "GetMonitorInfoW", "EnumDisplayMonitors", "UpdateLayeredWindow", "CreateWindowExW", "GetCursorPos"};
  void* fakes[] = {(void*)FakeMFP, (void*)FakeGMI, (void*)FakeEDM, (void*)FakeULW, (void*)FakeCWE, (void*)FakeGCP};
  bool all = true;
  for (int i = 0; i < 6; i++) if (PatchIat(m, fns[i], fakes[i]) != 1) { all = false; printf("INFO 假函数没装上：%s（这个 DLL 没导入它）\n", fns[i]); }
  return all;
}
// 布局：每块屏底下 40 像素当任务栏。R：主屏 0～960、副屏在右 960～1920（都在测试用的 1920×1080 屏幕里，真实光标两块屏都能去）；L：副屏在左（负坐标）；A：副屏在上；1：单屏；
// W数字：单屏、宽度＝数字（测“最多记 8 种布局”用）
static void FakeLayout(const std::string& n) {
  g_fm.clear();
  auto add = [](int l, int t, int r, int b, bool p) { FakeMon m; SetRect(&m.rc, l, t, r, b); m.wk = m.rc; m.wk.bottom -= 40; m.primary = p; g_fm.push_back(m); };
  if (n == "1") add(0, 0, 1920, 1080, true);
  else if (n == "R") { add(0, 0, 960, 1080, true); add(960, 0, 1920, 1080, false); }
  else if (n == "L") { add(0, 0, 1920, 1080, true); add(-1920, 0, 0, 1080, false); }
  else if (n == "A") { add(0, 0, 1920, 1080, true); add(0, -1080, 1920, 0, false); }
  else if (n[0] == 'W') add(0, 0, atoi(n.c_str() + 1), 1080, true);
}
struct Geo { RECT wr; int m, W, H, cl, ct, cr, cb; };
static Geo GeoNow() {
  Geo g = {}; HWND fw = (HWND)Info(9, 0, 0, 0); GetWindowRect(fw, &g.wr); g.W = (int)Info(11, 0, 0, 0); g.H = (int)Info(12, 0, 0, 0);
  g.m = ((g.wr.right - g.wr.left) - g.W) / 2; g.cl = g.wr.left + g.m; g.ct = g.wr.top + g.m; g.cr = g.cl + g.W; g.cb = g.ct + g.H; return g;
}
static bool g_fakeOk = false;
// ---- 1.3.1：个别系统上画不出字（悬浮窗、右键菜单只剩图形）——精绘文字、GDI+ 逐级退路。用选项 116 模拟两种情况：
// 精绘的贴图在那台机器上不起作用（应改走 GDI+）、GDI+ 也画不出字（应改走 GDI）；每种都比较“有字 − 不画字”的笔画像素，并看诊断 102
static void TextFallbackSuite(const std::string& out) {
  Check(Start(100, 100, 0, (INT_PTR)Cb) == 1, "文字退路：启动");
  F4 MSnap = P("XF_TestMenuSnap");
  const LangCase& L = LC[0];
  auto inkDiff = [&](const std::string& a, const std::string& b) { Img x, y; if (!LoadPng(a, x) || !LoadPng(b, y) || x.w != y.w || x.h != y.h) return -1; int n = 0; for (size_t i = 0; i < x.px.size(); i++) if (PmDiff(x.px[i], y.px[i]) > 40) n++; return n; };
  struct M { int bits; const char* name; int mask, want; } modes[] = {{0, "正常", 3, 0}, {1, "精绘贴图不起作用，改走 GDI+", 1, 1}, {3, "精绘与 GDI+ 都画不出字，改走 GDI", 6, 6}};
  int base = -1, baseM = -1;
  for (auto& m : modes) {
    Opt(116, m.bits, 0, 0);
    SetSkin(1, 0, 0, 0); Apply("sfx", L, 1);
    std::string a = out + "\\_txt_a.png", b = out + "\\_txt_b.png", ma = out + "\\_txt_ma.png", mb = out + "\\_txt_mb.png";
    Opt(111, 0, 0, 0); bool ok = Snap(S(a), 100, 0, 0) == 1 && MSnap(S(ma), 0, 0, 0) == 1;
    Opt(111, 1, 0, 0); ok = Snap(S(b), 100, 0, 0) == 1 && MSnap(S(mb), 0, 0, 0) == 1 && ok; Opt(111, 0, 0, 0);
    int n = inkDiff(a, b), nm = inkDiff(ma, mb);
    if (m.bits == 0) { base = n; baseM = nm; }
    char what[300];
    sprintf(what, "文字退路（%s）：悬浮窗画出了字（笔画像素 %d，正常 %d）", m.name, n, base); Check(ok && n > 20 && (base <= 0 || n * 3 > base), what);
    sprintf(what, "文字退路（%s）：右键菜单画出了字（笔画像素 %d，正常 %d）", m.name, nm, baseM); Check(ok && nm > 50 && (baseM <= 0 || nm * 3 > baseM), what);
    int info = (int)Info(102, 0, 0, 0);
    sprintf(what, "文字退路（%s）：诊断 102 为 %d", m.name, info); Check((info & m.mask) == m.want, what);
    { // 斜着盖的印章（印章皮肤闪避中）：精绘不画斜字，GDI+ 画不出时要退到“GDI 画成图再斜着贴”
      SetSkin(SK_SEAL, 0, 0, 0); ApplyRoleDuck(L, SK_SEAL);
      std::string sa = out + "\\_txt_sa.png", sb = out + "\\_txt_sb.png";
      Opt(111, 0, 0, 0); bool ok2 = Snap(S(sa), 100, 0, 0) == 1; Opt(111, 1, 0, 0); ok2 = Snap(S(sb), 100, 0, 0) == 1 && ok2; Opt(111, 0, 0, 0);
      static int baseS = -1; int ns = inkDiff(sa, sb); if (m.bits == 0) baseS = ns;
      sprintf(what, "文字退路（%s）：印章皮肤闪避时的斜章画出了字（笔画像素 %d，正常 %d）", m.name, ns, baseS); Check(ok2 && ns > 20 && (baseS <= 0 || ns * 3 > baseS), what);
    }
  }
  Opt(116, 0, 0, 0);
  Stop(0, 0, 0, 0);
}
// ---- 1.3.1：字体包文件不完整（正在解压、被截断）或字形数据坏了：文字都要画得出——不完整的先用系统字体、写完了自动用上；
// 字形坏了（GDI+ 自检那个字是好的、别的字取不到轮廓）的换回系统字体。不完整的在输出目录里用字体包复制一份截短来造；
// 字形坏了的要有字体包目录下的 _damaged\（tests/run_all.sh 用替身字体时生成），没有就跳过
static std::wstring FindHosFile(const std::wstring& root, const wchar_t* weight) {  // 同 xf_gfx.cpp 的 FindHos
  const wchar_t* dirs[] = {L"HarmonyOS_SansSC\\", L"HarmonyOS Sans\\HarmonyOS_SansSC\\", L"HarmonyOS_Sans_SC\\", L""};
  const wchar_t* names[] = {L"HarmonyOS_SansSC_", L"HarmonyOS_Sans_SC_"}; const wchar_t* exts[] = {L".ttf", L".otf"};
  for (auto d : dirs) for (auto n : names) for (auto e : exts) { std::wstring p = root + L"\\" + d + n + weight + e; DWORD a = GetFileAttributesW(p.c_str()); if (a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY)) return p; }
  return L"";
}
static void HosPackageSuite(const std::string& out, const std::string& fontDir) {
  if (fontDir.empty()) { printf("INFO 没有字体包目录：跳过字体包不完整、字形坏了的 5 项测试\n"); return; }
  std::wstring fm = FindHosFile(W8(fontDir), L"Medium"), fb = FindHosFile(W8(fontDir), L"Bold");
  if (fm.empty() || fb.empty()) { printf("INFO 字体包目录里没有鸿蒙黑体：跳过字体包不完整、字形坏了的测试\n"); return; }
  Check(Start(100, 100, 0, (INT_PTR)Cb) == 1, "字体包退路：启动");
  const LangCase& L = LC[0];
  SetSkin(1, 0, 0, 0); Apply("sfx", L, 1);
  auto ink = [&](const char* tag) -> int {
    std::string a = out + "\\_hp_" + tag + "_a.png", b = out + "\\_hp_" + tag + "_b.png";
    Opt(111, 0, 0, 0); Snap(S(a), 100, 0, 0); Opt(111, 1, 0, 0); Snap(S(b), 100, 0, 0); Opt(111, 0, 0, 0);
    Img x, y; if (!LoadPng(a, x) || !LoadPng(b, y) || x.w != y.w || x.h != y.h) return -1;
    int n = 0; for (size_t i = 0; i < x.px.size(); i++) if (PmDiff(x.px[i], y.px[i]) > 40) n++; return n; };
  char what[300];
  // 1) 不完整：Medium 截掉一半
  std::wstring part = W8(out) + L"\\_hp_part", pd = part + L"\\HarmonyOS_SansSC";
  CreateDirectoryW(part.c_str(), nullptr); CreateDirectoryW(pd.c_str(), nullptr);
  std::wstring pm = pd + L"\\HarmonyOS_SansSC_Medium.ttf", pb = pd + L"\\HarmonyOS_SansSC_Bold.ttf";
  CopyFileW(fm.c_str(), pm.c_str(), FALSE); CopyFileW(fb.c_str(), pb.c_str(), FALSE);
  { HANDLE h = CreateFileW(pm.c_str(), GENERIC_WRITE, 0, nullptr, OPEN_EXISTING, 0, nullptr); LARGE_INTEGER sz = {}; GetFileSizeEx(h, &sz); LARGE_INTEGER half; half.QuadPart = sz.QuadPart / 2; SetFilePointerEx(h, half, nullptr, FILE_BEGIN); SetEndOfFile(h); CloseHandle(h); }
  int len = WideCharToMultiByte(CP_UTF8, 0, part.c_str(), -1, nullptr, 0, nullptr, nullptr); std::string part8(len > 0 ? len - 1 : 0, 0); WideCharToMultiByte(CP_UTF8, 0, part.c_str(), -1, &part8[0], len, nullptr, nullptr);
  SetFontDir(S(part8), 0, 0, 0); Sleep(150);
  int n1 = ink("part"); int st1 = (int)Info(16, 0, 0, 0);
  sprintf(what, "字体包不完整（正在解压）：先用系统字体（状态 %d），文字照样画得出（笔画像素 %d）", st1, n1); Check(st1 == 4 && n1 > 20, what);
  CopyFileW(fm.c_str(), pm.c_str(), FALSE);  // 写完了
  int st2 = 0; for (int i = 0; i < 16 && st2 != 1; i++) { Sleep(300); Snap(S(out + "\\_hp_wait.png"), 100, 0, 0); st2 = (int)Info(16, 0, 0, 0); }
  sprintf(what, "字体包写完了：不用再交代一次，自动用上鸿蒙黑体（状态 %d）", st2); Check(st2 == 1, what);
  // 2) 字形坏了：GDI+ 自检那个字（测）是好的，别的字取不到轮廓
  std::string dmg = fontDir + "\\_damaged";
  if (GetFileAttributesW(W8(dmg).c_str()) != INVALID_FILE_ATTRIBUTES) {
    SetFontDir(S(dmg), 0, 0, 0); Sleep(150);
    Snap(S(out + "\\_hp_dmg0.png"), 100, 0, 0);  // 第一帧用上它、画的时候发现字坏了；下一帧换回系统字体
    int n3 = ink("dmg"); int st3 = (int)Info(16, 0, 0, 0);
    sprintf(what, "字体包里的字形坏了：换回系统字体（状态 %d），文字照样画得出（笔画像素 %d）", st3, n3); Check(st3 == 4 && n3 > 20, what);
  } else printf("INFO 没有 _damaged 目录：跳过字形坏了的测试\n");
  SetFontDir(S(fontDir), 0, 0, 0); Sleep(150); Snap(S(out + "\\_hp_back.png"), 100, 0, 0);
  sprintf(what, "换回好的字体包：又用上鸿蒙黑体（状态 %d）", (int)Info(16, 0, 0, 0)); Check(Info(16, 0, 0, 0) == 1, what);
  Stop(0, 0, 0, 0);
}
static void MultiMonitorSuite(const std::string& out) {
  Check(g_fakeOk, "测试：假显示器接上（导入表替换 MonitorFromPoint、GetMonitorInfoW、EnumDisplayMonitors、UpdateLayeredWindow、CreateWindowExW、GetCursorPos）");
  std::string mem = out + "\\xhhfloat_自测.ini"; DeleteFileW(W8(mem).c_str());
  auto Say = [](const char* tag) { Geo g = GeoNow(); INT_PTR d = Info(5, 0, 0, 0);
    printf("INFO %s：锚点 %d,%d 贴边 %d 锚点在右 %d｜内容 %d,%d～%d,%d｜来源 %d 在主屏 %d 布局 %08X（%d 块屏）记着 %d 种\n", tag, (int)Info(1, 0, 0, 0), (int)Info(2, 0, 0, 0), (int)(d & 0xFF), (int)((d >> 8) & 1),
           g.cl, g.ct, g.cr, g.cb, (int)Info(95, 0, 0, 0), (int)Info(98, 0, 0, 0), (unsigned)Info(96, 0, 0, 0), (int)Info(97, 0, 0, 0), (int)Info(99, 0, 0, 0)); };
  auto Go = [&](const char* layout, INT_PTR x, INT_PTR y, INT_PTR flags, INT_PTR dock, INT_PTR hint, bool useMem) {
    Stop(0, 0, 0, 0); FakeLayout(layout); g_fakeOn = true;
    Opt(2, dock, 0, 0); Opt(9, useMem ? S(mem) : 0, 0, 0); Opt(11, hint, 0, 0);
    memset((void*)gEvents, 0, sizeof(gEvents));
    INT_PTR ok = Start(x, y, flags, (INT_PTR)Cb); WaitUntil([] { return IsWindowVisible((HWND)Info(9, 0, 0, 0)) != 0; }, 2000); return ok == 1; };
  // 拖动：把内容的左上角拖到 (tl, tt)；合成的鼠标消息带“相对窗口当前位置”的坐标，真实光标先移开（见上面“拖动”一节）
  auto DragTo = [&](int tl, int tt) {
    SetCursorPos(5, 1000); Sleep(150);
    HWND fw = (HWND)Info(9, 0, 0, 0); Geo g = GeoNow(); POINT s0; if (!BlankSpot(&s0)) { printf("INFO 找不到空白处\n"); return; }
    int dx = tl - g.cl, dy = tt - g.ct;
    auto MS = [&](int sx, int sy, int kind) { RECT wr; GetWindowRect(fw, &wr); TMouse(kind, sx - wr.left, sy - wr.top, 0); };
    MS(s0.x, s0.y, 1); MS(s0.x, s0.y, 2); MS(s0.x + dx / 2, s0.y + dy / 2, 1); MS(s0.x + dx, s0.y + dy, 1); MS(s0.x + dx, s0.y + dy, 3);
  };
  auto Collapse = [&] { TMouse(6, 0, 0, 0); LONG want = (LONG)ceil(24.0 * Info(8, 0, 0, 0) / 96.0); WaitUntil([&] { return (LONG)Info(12, 0, 0, 0) <= want; }, 3000); Sleep(100); };  // 鼠标离开：贴边的收起成一小截。1.4.0：原来固定等 900 毫秒（离开 0.24 秒＋收起 0.38 秒两个计时，只留 0.28 秒余量），改为等到真的收起（这一节用灵动胶囊，收起后 24 高），最多 3 秒；本来就收着时不用等
  auto Restart = [&](const char* layout, bool useMem, INT_PTR hint) { INT_PTR x = Info(1, 0, 0, 0), y = Info(2, 0, 0, 0), d = Info(5, 0, 0, 0); return Go(layout, x, y, useMem ? 4 : 0, d, hint, useMem); };
  Opt(100, 12345, 0, 0); Opt(101, 0, 0, 0); Reset(LC[0]); SetSkin(1, 0, 0, 0);
  // ① 在两块屏的交界处贴边（原来跳到相邻那块屏的最远端，重启后照旧）
  Go("R", 500, 300, 0, 0, 0, false); { Geo g = GeoNow(); DragTo(1000 - g.W, 300); } Collapse(); Say("R 越过交界 40 像素贴右边");
  { Geo g = GeoNow(); Check((Info(5, 0, 0, 0) & 0xFF) == 2 && g.cr == 960 && Info(98, 0, 0, 0) == 1, "多屏：在交界处贴右边（越过 40 像素松手）——留在主屏右边上（原来跳到右边那块屏的最右端）"); }
  Restart("R", false, 0); { Geo g = GeoNow(); Check(g.cr == 960 && Info(98, 0, 0, 0) == 1, "多屏：按存下的位置重启，仍在主屏右边上"); }
  Go("R", 500, 300, 0, 0, 0, false); { Geo g = GeoNow(); DragTo(960 - g.W, 300); } Collapse();
  { Geo g = GeoNow(); Check(Info(1, 0, 0, 0) == 960 && g.cr == 960, "多屏：右边正好贴齐交界（锚点＝960，按约定不属于主屏）——仍在主屏右边上"); }
  Go("L", 200, 300, 0, 0, 0, false); DragTo(-30, 300); Collapse(); Say("L 越过左边界 30 像素");
  { Geo g = GeoNow(); Check((Info(5, 0, 0, 0) & 0xFF) == 1 && g.cl == 0, "多屏：副屏在左、越过交界贴左边——留在主屏左边上（原来跳到左边那块屏的最左端）"); }
  Go("A", 800, 300, 0, 0, 0, false); DragTo(800, -10); Collapse(); Say("A 越过上边界 10 像素");
  { Geo g = GeoNow(); Check((Info(5, 0, 0, 0) & 0xFF) == 3 && g.ct == 0, "多屏：副屏在上、越过交界贴上边——留在主屏上边（原来跳到上面那块屏的最上端）"); }
  Go("R", 1000, 300, 0, 2 | 0x100, 0, false); Sleep(900);
  { Geo g = GeoNow(); Check(g.cr == 960, "多屏：旧版本存坏的位置（锚点越过交界、贴右边）自动修正回主屏右边"); }
  Go("R", 1920, 300, 0, 2 | 0x100, 0, false); Sleep(900);
  { Geo g = GeoNow(); Check(g.cr == 1920 && Info(98, 0, 0, 0) == 0, "多屏：贴在副屏外侧右边照旧（不误改）"); }
  Go("R", 1300, 300, 0, 0, 0, false); { Geo g = GeoNow(); Check(g.cl == 1300 && Info(98, 0, 0, 0) == 0, "多屏：放在副屏中间照旧"); }
  // ② 位置来源（标志 4）：本机还没有记忆时按账号配置里那份判断
  Go("R", 0, 0, 1 | 4, 0, 0, true); Say("旧坐标 0,0");
  Check(Info(95, 0, 0, 0) == 7 && Info(98, 0, 0, 0) == 1, "位置：没存过 → 默认位置（主屏）");
  Go("R", 1300, 300, 1 | 4, 0, 0, true); Say("旧坐标在副屏");
  Check(Info(95, 0, 0, 0) == 6 && Info(98, 0, 0, 0) == 1 && Info(2, 0, 0, 0) == 300, "位置：原悬浮窗存的坐标在主屏外 → 那一轴按默认、回到主屏（同原悬浮窗；原来按最近的屏照用）");
  Go("R", 400, 300, 1 | 4, 0, 0, true); { Geo g = GeoNow(); Check(Info(95, 0, 0, 0) == 6 && g.cl == 400 && g.ct == 300, "位置：原悬浮窗存的坐标在主屏上 → 照用"); }
  INT_PTR sigR = Info(96, 0, 0, 0);
  Go("R", 1300, 300, 4, 0, sigR, true); { Geo g = GeoNow(); Check(Info(95, 0, 0, 0) == 2 && g.cl == 1300, "位置：账号里的位置是同一种显示布局下存的 → 照用（含副屏）"); }
  Go("R", 1300, 300, 4, 0, 12345, true); Say("别的布局、副屏");
  Check(Info(95, 0, 0, 0) == 4 && Info(98, 0, 0, 0) == 1, "位置：账号里的位置是别的显示布局下存的、不在主屏 → 改用默认位置（可能来自别的电脑）");
  Go("R", 400, 300, 4, 0, 12345, true); { Geo g = GeoNow(); Check(Info(95, 0, 0, 0) == 3 && g.cl == 400, "位置：别的显示布局下存的、在主屏上 → 照用"); }
  Go("R", 1300, 300, 4, 0, 0, true); { Geo g = GeoNow(); Check(Info(95, 0, 0, 0) == 5 && g.cl == 1300, "位置：旧版本存的（没记布局）→ 照用（不让升级的用户挪位置）"); }
  // ③ 本机位置记忆：拖动后记下；同一种布局优先用它；换布局各记各的；运行中接上 / 拔掉显示器时挪到那种布局记着的位置
  Go("R", 400, 300, 4, 0, 12345, true); DragTo(1200, 500); Say("拖到副屏");
  Check(Info(95, 0, 0, 0) == 9 && Info(99, 0, 0, 0) == 1 && GetFileAttributesW(W8(mem).c_str()) != INVALID_FILE_ATTRIBUTES && gEvents[12] == 1, "记忆：拖动后记进本机文件，照常报位置变了");
  Go("R", 400, 300, 4, 0, 12345, true); { Geo g = GeoNow(); Check(Info(95, 0, 0, 0) == 1 && g.cl == 1200 && g.ct == 500, "记忆：同一种显示布局下优先用本机记的位置（账号里那份只作参考）"); }
  Go("1", 400, 300, 4, 0, 12345, true); { Geo g = GeoNow(); Check(Info(95, 0, 0, 0) == 3 && g.cl == 400, "记忆：换成单屏（没记过）→ 按账号里那份判断"); }
  DragTo(300, 600); Check(Info(99, 0, 0, 0) == 2, "记忆：单屏下拖动后，两种布局各记各的");
  { HWND fw = (HWND)Info(9, 0, 0, 0);
    FakeLayout("R"); SendMessageW(fw, WM_DISPLAYCHANGE, 32, MAKELPARAM(1920, 1080)); Sleep(200);
    Geo g = GeoNow(); Check(Info(95, 0, 0, 0) == 1 && g.cl == 1200 && g.ct == 500, "记忆：运行中接上副屏 → 回到那种布局下记着的位置（副屏上）");
    FakeLayout("1"); SendMessageW(fw, WM_DISPLAYCHANGE, 32, MAKELPARAM(1920, 1080)); Sleep(200);
    g = GeoNow(); Check(g.cl == 300 && g.ct == 600, "记忆：运行中拔掉副屏 → 回到单屏时的位置");
    FakeLayout("L"); SendMessageW(fw, WM_DISPLAYCHANGE, 32, MAKELPARAM(1920, 1080)); Sleep(200);
    g = GeoNow(); Check(g.cl == 300 && g.ct == 600 && Info(98, 0, 0, 0) == 1, "记忆：换到没记过的布局 → 位置不动");
    for (int i = 0; i < 9; i++) { char n[16]; sprintf(n, "W%d", 1000 + i * 100); FakeLayout(n); SendMessageW(fw, WM_DISPLAYCHANGE, 32, MAKELPARAM(1000 + i * 100, 1080)); Sleep(80); DragTo(100 + i * 10, 200); }
    wchar_t secs[4096] = L""; DWORD n = GetPrivateProfileSectionNamesW(secs, 4096, W8(mem).c_str()); int cnt = 0; for (const wchar_t* q = secs; q < secs + n && *q; q += wcslen(q) + 1) if (!wcsncmp(q, L"layout_", 7)) cnt++;
    Check(Info(99, 0, 0, 0) == 8 && cnt == 8, "记忆：最多记 8 种显示布局，多了删掉最久没用的"); }
  // ④ 找回悬浮窗：移到鼠标旁边、不贴边、显示出来（隐藏着、贴着边、放在别的屏上都一样）。在真机上屏幕可能没有 1920 宽：按真实光标实际停的位置判断
  auto MonAt = [](POINT p) { for (auto& m : g_fm) if (p.x >= m.rc.left && p.x < m.rc.right && p.y >= m.rc.top && p.y < m.rc.bottom) return m; return g_fm[0]; };
  auto CursorNear = [&](int x, int y) { int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN); if (x > sw - 20) x = sw - 20; if (y > sh - 60) y = sh - 60; SetCursorPos(x, y); Sleep(150); POINT c; GetCursorPos(&c); return c; };
  auto RecoverOk = [&](POINT c, bool wantAbove) {
    Geo g = GeoNow(); FakeMon fm = MonAt(c);
    bool inWork = g.cl >= fm.wk.left && g.cr <= fm.wk.right && g.ct >= fm.wk.top && g.cb <= fm.wk.bottom;
    bool notUnder = !(c.x >= g.cl && c.x < g.cr && c.y >= g.ct && c.y < g.cb);
    bool centered = labs((g.cl + g.cr) / 2 - c.x) <= 1 || g.cl == fm.wk.left || g.cr == fm.wk.right;  // 以鼠标为中，靠边放不下时贴着工作区边
    bool side = wantAbove ? g.cb <= c.y : g.ct > c.y;
    if (!(inWork && notUnder && centered && side)) printf("INFO 找回的位置不对：鼠标 %ld,%ld 内容 %d,%d～%d,%d 工作区 %ld,%ld～%ld,%ld\n", c.x, c.y, g.cl, g.ct, g.cr, g.cb, fm.wk.left, fm.wk.top, fm.wk.right, fm.wk.bottom);
    return inWork && notUnder && centered && side; };
  Go("R", 960, 300, 4, 2 | 0x100, 0, true); Collapse(); Show(0, 0, 0, 0); Sleep(200);
  memset((void*)gEvents, 0, sizeof(gEvents)); POINT c1 = CursorNear(1500, 700);
  Check(Opt(10, 1, 0, 0) == 1, "找回：选项 10 受理");
  WaitUntil([] { return gEvents[12] >= 1; }, 2000); Sleep(150); Say("找回（鼠标在 1500,700 附近）");
  Check(Info(3, 0, 0, 0) == 1 && IsWindowVisible((HWND)Info(9, 0, 0, 0)) && (Info(5, 0, 0, 0) & 0xFF) == 0 && Info(95, 0, 0, 0) == 8 && gEvents[12] == 1 && RecoverOk(c1, true),
        "找回：隐藏着、贴着主屏边 → 显示在鼠标正上方（鼠标所在的那块屏），不贴边、不压着鼠标，报位置变了");
  {  // 找回时鼠标那儿有别的置顶窗口：悬浮窗提到置顶层的最上面，不被它挡着
    WNDCLASSW wc = {}; wc.lpfnWndProc = DefWindowProcW; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"XfTestCover"; RegisterClassW(&wc);
    HWND cover = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE, L"XfTestCover", L"", WS_POPUP, 1000, 400, 900, 600, nullptr, nullptr, wc.hInstance, nullptr);
    ShowWindow(cover, SW_SHOWNOACTIVATE); SetWindowPos(cover, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    HWND fw = (HWND)Info(9, 0, 0, 0); memset((void*)gEvents, 0, sizeof(gEvents)); CursorNear(1500, 700); Opt(10, 1, 0, 0); WaitUntil([] { return gEvents[12] >= 1; }, 2000); Sleep(150);
    bool above = false; for (HWND w = GetTopWindow(nullptr); w; w = GetWindow(w, GW_HWNDNEXT)) { if (w == fw) { above = true; break; } if (w == cover) break; }
    Check(above, "找回：鼠标那儿有别的置顶窗口时，悬浮窗提到它上面");
    DestroyWindow(cover); UnregisterClassW(L"XfTestCover", wc.hInstance);
  }
  Go("R", 400, 300, 4, 0, 0, true); POINT c2 = CursorNear(1500, 8); memset((void*)gEvents, 0, sizeof(gEvents)); Opt(10, 1, 0, 0); WaitUntil([] { return gEvents[12] >= 1; }, 2000); Sleep(150);
  Check(RecoverOk(c2, false), "找回：鼠标在屏幕上沿 → 放在鼠标下方");
  { Geo g0 = GeoNow(); Go("R", 400, 300, 4, 0, 0, true); Geo g = GeoNow(); Check(Info(95, 0, 0, 0) == 1 && g.cl == g0.cl && g.ct == g0.ct, "找回：位置记进本机记忆，重启后还在"); }
  g_cursorFail = true; memset((void*)gEvents, 0, sizeof(gEvents)); Opt(10, 1, 0, 0); WaitUntil([] { return gEvents[12] >= 1; }, 2000); Sleep(150); g_cursorFail = false;
  { POINT pc = {(g_fm[0].wk.left + g_fm[0].wk.right) / 2, (g_fm[0].wk.top + g_fm[0].wk.bottom) / 2}; Check(gEvents[12] == 1 && RecoverOk(pc, true), "找回：取不到鼠标位置（安全桌面等）→ 放在主屏中间"); }
  auto SecName = [] { wchar_t b[32]; swprintf(b, 32, L"layout_%08lX", (unsigned long)(DWORD)Info(96, 0, 0, 0)); return std::wstring(b); };
  { wchar_t mons[256] = L""; GetPrivateProfileStringW(SecName().c_str(), L"monitors", L"", mons, 256, W8(mem).c_str());
    Check(wcscmp(mons, L"0,0,960,1080;960,0,1920,1080") == 0, "记忆：记下这种布局的显示器（供人查看，分号隔开）"); }
  // 坐标极端值（配置损坏）：不溢出，照样摆进可见范围
  Go("1", 0x7FFFFFFF, 0x7FFFFFFF, 0, 0, 0, false); { Geo g = GeoNow(); Check(Info(1, 0, 0, 0) == 1000000 && g.cr <= 1920 && g.cb <= 1040 && g.cl >= 0 && g.ct >= 0, "坐标极端值：限制在合理范围，照样摆进工作区"); }
  { FILE* f = Fopen8(mem, L"wb"); if (f) { char b[16]; sprintf(b, "%08X", (unsigned)Info(96, 0, 0, 0)); fprintf(f, "[order]\r\nlist=%s\r\n[layout_%s]\r\npos=-2147483648,99999999999,2\r\n", b, b); fclose(f); } }
  Go("1", 400, 300, 4, 0, 0, true); { Geo g = GeoNow(); Check(Info(95, 0, 0, 0) == 1 && g.cr <= 1920 && g.cl >= 0 && g.ct >= 0 && g.cb <= 1040, "记忆文件里的坐标是极端值：照样摆进工作区"); }
  { FILE* f = Fopen8(mem, L"wb"); if (f) { fprintf(f, "[order]\r\nlist=zz\r\n[layout_%08X]\r\npos=abc\r\n", (unsigned)Info(96, 0, 0, 0)); fclose(f); } }
  Go("1", 400, 300, 4, 0, 0, true); { Geo g = GeoNow(); Check(Info(95, 0, 0, 0) == 5 && g.cl == 400 && g.ct == 300, "记忆文件损坏：不用它，按账号配置里那份"); }
  // ⑤ 贴画面失败：第一帧没贴上也会自动重试（原来空闲时一直看不见，托盘菜单却显示“隐藏悬浮窗”）
  Stop(0, 0, 0, 0); FakeLayout("1"); Opt(9, 0, 0, 0);
  g_ulwFailUntil = (LONG)(GetTickCount() + 1200);
  { static LONG fr0; fr0 = (LONG)Info(15, 0, 0, 0); LONG bad0 = (LONG)Info(94, 0, 0, 0);  // 帧数、失败次数都是整个进程累计的：看增量
    Start(300, 300, 0, (INT_PTR)Cb); LONG f0 = (LONG)Info(15, 0, 0, 0) - fr0, bad = (LONG)Info(94, 0, 0, 0) - bad0, ok0 = g_ulwOk; bool hidden = !IsWindowVisible((HWND)Info(9, 0, 0, 0));
    printf("INFO 贴画面失败期间：新贴出 %ld 帧、失败 %ld 次、窗口可见 %d\n", (long)f0, (long)bad, hidden ? 0 : 1);
    Check(f0 == 0 && bad >= 1 && hidden && ok0 == 0, "贴画面失败：不算已贴出的帧、窗口先不显示");
    Check(WaitUntil([] { return g_ulwOk >= 1 && (LONG)Info(15, 0, 0, 0) - fr0 >= 1 && IsWindowVisible((HWND)Info(9, 0, 0, 0)); }, 4000), "贴画面失败：之后自动重试、真正贴上并显示出来（画面要素没变也会）"); }
  g_ulwFailUntil = 0;
  // ⑥ 任务栏变高（工作区变小）：马上重新摆，不压在任务栏下面
  Go("1", 400, 1000, 0, 0, 0, false); { Geo g = GeoNow(); Check(g.cb <= 1040, "工作区：开始时在任务栏上面"); }
  g_fm[0].wk.bottom = 1080 - 200; SendMessageW((HWND)Info(9, 0, 0, 0), WM_SETTINGCHANGE, SPI_SETWORKAREA, 0); Sleep(150);
  { Geo g = GeoNow(); Check(g.cb <= 880, "工作区：任务栏变高后马上挪到它上面（原来要等下一次画面变化）"); }
  Stop(0, 0, 0, 0); g_fakeOn = false; Opt(9, 0, 0, 0); Opt(11, 0, 0, 0); Opt(2, 0, 0, 0); Opt(101, -1, 0, 0);
  DeleteFileW(W8(mem).c_str());
}
// ---- 窗口被别的模块改动后自己恢复（1.2.0）：模拟换肤库（SkinSharp 自动模式）、辅助工具在建窗口时、运行中改悬浮窗的窗口
static void SelfHealSuite() {
  auto Rgn = [](HWND h) { HRGN r = CreateRectRgn(0, 0, 0, 0); int k = GetWindowRgn(h, r); DeleteObject(r); return k != ERROR; };
  Stop(0, 0, 0, 0); Opt(9, 0, 0, 0); Opt(2, 0, 0, 0);
  LONG s0 = (LONG)Info(100, 0, 0, 0);
  g_skinMode = 3; Start(300, 300, 0, (INT_PTR)Cb); g_skinMode = 0;
  HWND fw = (HWND)Info(9, 0, 0, 0);
  Check(g_ulwWatch == fw && g_ulwOk >= 1 && IsWindowVisible(fw) && !Rgn(fw) && (LONG)Info(100, 0, 0, 0) > s0,
        "被改动：建窗口时就被调了 SetLayeredWindowAttributes、设了 1×1 窗口区域 → 第一帧照样贴上、不被裁（原来一帧都贴不上，或只剩 1 个像素）");
  LONG s1 = (LONG)Info(100, 0, 0, 0);
  LONG_PTR ex = GetWindowLongPtrW(fw, GWL_EXSTYLE), st = GetWindowLongPtrW(fw, GWL_STYLE);
  SetWindowLongPtrW(fw, GWL_EXSTYLE, (ex | WS_EX_TRANSPARENT) & ~WS_EX_LAYERED); SetWindowLongPtrW(fw, GWL_STYLE, st | WS_CAPTION);
  SetWindowRgn(fw, CreateRectRgn(0, 0, 1, 1), TRUE); SetWindowPos(fw, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
  DWORD tw0 = GetTickCount();  // 1.4.0：等待上限 3.5 秒 → 5 秒（核对周期 2 秒＋机器忙时 3 秒，同本文件“等界面线程最多 2～3 秒”的约定）。刚建好的窗口第一次核对正好在 2 秒，原来只留 1.5 秒余量，全套跑到最后机器忙时偶尔超时；没恢复时报是哪几项
  bool ok = WaitUntil([&] { LONG_PTR e = GetWindowLongPtrW(fw, GWL_EXSTYLE), t = GetWindowLongPtrW(fw, GWL_STYLE);
    return !Rgn(fw) && !(e & WS_EX_TRANSPARENT) && (e & WS_EX_LAYERED) && (e & WS_EX_TOPMOST) && !(t & WS_CAPTION); }, 5000);
  if (!ok) { LONG_PTR e = GetWindowLongPtrW(fw, GWL_EXSTYLE), t = GetWindowLongPtrW(fw, GWL_STYLE);
    printf("INFO 运行中被改动：等了 %lu 毫秒仍有没恢复的——区域 %d 穿透 %d 没分层 %d 不置顶 %d 标题栏 %d（自己恢复 +%ld 次）\n", (unsigned long)(GetTickCount() - tw0), (int)Rgn(fw), (int)!!(e & WS_EX_TRANSPARENT), (int)!(e & WS_EX_LAYERED), (int)!(e & WS_EX_TOPMOST), (int)!!(t & WS_CAPTION), (long)((LONG)Info(100, 0, 0, 0) - s1)); }
  Check(ok && (LONG)Info(100, 0, 0, 0) > s1, "被改动：运行中被加鼠标穿透、摘分层样式、加标题栏、设窗口区域、挪出置顶层 → 下一次核对（每 2 秒一次）自己恢复");
  { LONG k1 = g_ulwOk; SetLayeredWindowAttributes(fw, 0, 255, LWA_ALPHA); SetHot(1, S("F9"), 0, 0);
    Check(WaitUntil([&] { return g_ulwOk > k1; }, 2000), "被改动：运行中被调了 SetLayeredWindowAttributes → 下一帧摘挂分层样式后照样贴上（原来之后一帧也贴不上）"); SetHot(0, S("F9"), 0, 0); }
  printf("INFO 自己恢复 %ld 次，窗口过程被接管 %ld\n", (long)Info(100, 0, 0, 0), (long)Info(101, 0, 0, 0));
  Check(Info(101, 0, 0, 0) == 0, "被改动：窗口过程没被接管时诊断 101 为 0");
  // 提示窗、皮肤画廊在同一个界面线程里建，换肤库的建窗口钩子同样会改它们（原来只有悬浮窗本身会恢复：提示看不见、画廊打不开）
  Stop(0, 0, 0, 0); g_skinMode = 4 | 8; Start(300, 300, 0, (INT_PTR)Cb); g_skinMode = 0;
  HWND tip = FindWindowW(L"XhhFloatTip", nullptr), gal = FindWindowW(L"XhhFloatGallery", nullptr);
  LONG s2 = (LONG)Info(100, 0, 0, 0);
  Opt(5, 1, 0, 0);
  Check(tip && WaitUntil([&] { return Info(17, 0, 0, 0) == 9999 && IsWindowVisible(tip) && !Rgn(tip); }, 2000) && (LONG)Info(100, 0, 0, 0) >= s2 + 2,
        "被改动：提示窗建窗口时被调了 SetLayeredWindowAttributes、设了窗口区域 → 首次提示照样显示、不被裁");
  LONG s3 = (LONG)Info(100, 0, 0, 0); SetCursorPos(5, 1000);
  Check(gal && Opt(7, 1, 0, 0) == 1 && WaitUntil([&] { return Info(19, 0, 0, 0) == 1 && IsWindowVisible(gal) && !Rgn(gal); }, 3000) && (LONG)Info(100, 0, 0, 0) >= s3 + 2,
        "被改动：皮肤画廊建窗口时被调了 SetLayeredWindowAttributes、设了窗口区域 → 照样打开、不被裁");
  Stop(0, 0, 0, 0);
}
int main() {
  { typedef BOOL(WINAPI * SPDAC)(HANDLE); SPDAC f = (SPDAC)(void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetProcessDpiAwarenessContext"); if (!f || !f((HANDLE)(INT_PTR)-4)) SetProcessDPIAware(); }  // 按显示器 DPI 感知：坐标与 DLL 一致，150% 屏上点得准
  g_wine = GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "wine_get_version") != nullptr;
  std::vector<std::string> args; { int n = 0; LPWSTR* a = CommandLineToArgvW(GetCommandLineW(), &n); for (int i = 0; i < n; i++) args.push_back(U8W(a[i])); LocalFree(a); }
  bool soak = args.size() >= 2 && args[1] == "soak"; int soakMin = soak && args.size() >= 3 ? atoi(args[2].c_str()) : 30; if (soakMin < 1) soakMin = 1;
  std::string dllPath, out, fontDir; bool autoMode = soak || args.size() < 3;
  if (!autoMode) { dllPath = args[1]; out = args[2]; if (args.size() > 3) fontDir = args[3]; }  // 用法：xftest <dll> <输出目录> [字体包目录]（tests/run_all.sh 这样调）
  else {  // 在 Windows 上直接双击：自己找 DLL，结果写在旁边的「自测结果」里；把字体包目录拖到 xftest.exe 上运行，多测 7 项字体
    SetConsoleOutputCP(CP_UTF8);
    wchar_t me[MAX_PATH]; GetModuleFileNameW(nullptr, me, MAX_PATH); std::wstring d = me; d = d.substr(0, d.find_last_of(L'\\'));
    if (soak && args.size() >= 4) fontDir = args[3];
    if (!soak && args.size() == 2) { DWORD at = GetFileAttributesW(W8(args[1]).c_str()); if (at != INVALID_FILE_ATTRIBUTES && (at & FILE_ATTRIBUTE_DIRECTORY)) fontDir = args[1]; }
    std::wstring outW = d + L"\\自测结果"; CreateDirectoryW(outW.c_str(), nullptr); out = U8W(outW);
    const wchar_t* cands[3] = {L"\\XhhFloat.dll", L"\\..\\out\\XhhFloat.dll", L"\\..\\..\\..\\资源\\dll_XhhFloat.Image.dat"};
    std::wstring src; for (auto cnd : cands) { std::wstring p = d + cnd; if (GetFileAttributesW(p.c_str()) != INVALID_FILE_ATTRIBUTES) { src = p; break; } }
    if (src.empty()) { printf("没找到 XhhFloat.dll：把它放在 xftest.exe 旁边，或者就在项目的 依赖库\\XhhFloat\\tests 里运行。\n按回车键关闭。\n"); getchar(); return 2; }
    std::wstring dst = outW + L"\\XhhFloat.dll"; dllPath = U8W(dst);  // 复制一份来用：崩溃记录之类写在结果目录里，不弄脏项目
    bool unpacked = false;
    { std::string why;  // 资源里的是易语言「ZLIB压缩数据」：先解开（原来原样复制成 XhhFloat.dll，Windows 报“损坏的映像”0xc000012f）
      if (!PrepareDll(src, dst, why, &unpacked)) { printf("用不了 %s：%s。\n请把编好的 XhhFloat.dll 放在 xftest.exe 旁边再运行。\n按回车键关闭。\n", U8W(src).c_str(), why.c_str()); getchar(); return 2; } }
    g_logPath = outW + (soak ? L"\\长时间测试日志.txt" : L"\\自测日志.txt");  // 双击运行时同时写进日志（先写 UTF-8 的 BOM，之后每次追加）
    { FILE* f = _wfopen(g_logPath.c_str(), L"wb"); if (f) { fputs("\xEF\xBB\xBF", f); fclose(f); } else g_logPath.clear(); }
    if (unpacked) printf("（%s 是易语言「ZLIB压缩数据」，已解开成 %s 再测）\n", U8W(src).c_str(), dllPath.c_str());  // 日志建好之后再写：日志里也有这一行
    if (soak) printf("小红花悬浮窗 长时间测试（%d 分钟）\nDLL：%s\n结果：%s\n\n期间悬浮窗会不停地换皮肤、换语言、放音效；这项测试不动鼠标和键盘，可以照常用电脑，但不要关掉这个窗口。\n约 %d 分钟后窗口里出现 SUMMARY（通过 / 失败）才算测完——测完再打包「自测结果」发过来（中途打包，日志里只有测到一半的数据、没有判定）。\n", soakMin, U8W(src).c_str(), out.c_str(), soakMin + 1);
    else
    printf("小红花悬浮窗 自测\nDLL：%s\n结果：%s\n字体包目录：%s\n\n接下来约 4 分钟会弹出悬浮窗、移动鼠标、按几下 Esc / 方向键 / 回车，期间请不要动鼠标和键盘。\n",
           U8W(src).c_str(), out.c_str(), fontDir.empty() ? "（没有：跳过 7 项字体测试；把字体包目录拖到 xftest.exe 上运行就会测）" : fontDir.c_str());
    for (int i = 5; i > 0; i--) { printf("%d 秒后开始…\n", i); Sleep(1000); }
  }
  ULONG_PTR gdipTok = 0; { Gdiplus::GdiplusStartupInput si; Gdiplus::GdiplusStartup(&gdipTok, &si, nullptr); }  // 对比度检查读截图用
  CreateDirectoryW(W8(out).c_str(), 0);
  if (!autoMode) {  // 命令行给的也可能是资源里压缩着的那份：不是 DLL 原文件就先解开到输出目录；解不开就说明原因，不交给 LoadLibrary（免得 Windows 弹“损坏的映像”）
    unsigned char mz[2] = {0, 0}; { FILE* f = Fopen8(dllPath, L"rb"); if (f) { if (fread(mz, 1, 2, f) != 2) mz[0] = 0; fclose(f); } }
    if (mz[0] != 'M' || mz[1] != 'Z') {
      std::string why; bool unpacked = false; std::wstring dst = W8(out) + L"\\XhhFloat.dll";
      if (!PrepareDll(W8(dllPath), dst, why, &unpacked)) { printf("FAIL 载入 DLL：%s（%s）\n", dllPath.c_str(), why.c_str()); return 1; }
      printf("INFO %s 是易语言「ZLIB压缩数据」，已解开成 %s\n", dllPath.c_str(), U8W(dst).c_str()); dllPath = U8W(dst);
    }
  }
  M = LoadLibraryW(W8(dllPath).c_str());
  Check(M != 0, "载入 DLL");
  if (!M) return 1;
  g_fakeOk = FakeInstall(M);  // 多显示器测试用的假显示器（不开启时原样转给系统）
  Start = P("XF_Start"); Stop = P("XF_Stop"); Show = P("XF_Show"); SetSkin = P("XF_SetSkin"); SetLang = P("XF_SetLanguage"); SetFontDir = P("XF_SetFontDir");
  SetHot = P("XF_SetHotkeys"); TInfo = P("XF_SetTrackInfo"); TTime = P("XF_SetTrackTime"); TClip = P("XF_SetTrackClip"); Duck = P("XF_SetDuck"); Opt = P("XF_SetOption");
  SetPos = P("XF_SetPos"); Info = P("XF_GetInfo"); g_info = Info; Text = P("XF_Text"); Snap = P("XF_Snapshot"); TMouse = P("XF_TestMouse"); THit = P("XF_TestHit"); g_thit = THit; TRender = P("XF_TestRenderTime"); Ver = P("XF_GetVersion");
  if (soak) {
    SetCurrentDirectoryW(W8(out).c_str());  // 截图写在结果目录里
    int rc = RunSoak(soakMin, fontDir);
    printf("SUMMARY 通过 %d 失败 %d\n\n结果在：%s（长时间测试日志.txt）\n按回车键关闭这个窗口。\n", passes, fails, out.c_str());
    if (!g_wine) ShellExecuteW(nullptr, L"open", W8(out).c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    getchar(); return rc;
  }
  if (fails) return 1;
  Check(Ver(0, 0, 0, 0) == 0x00010500, "版本号 1.5.0（鼠标停在悬浮窗上显示软件账号）");
  // 易语言的调用方式：悬浮窗_新版_调用桩（与精易模块 WV内部_调用N 同一写法的机器码）。易语言子程序的框架是 push ebp / mov ebp,esp（还可能有局部变量），
  // 置入代码在框架里取 [ebp+8] 起的参数，leave 恢复 ESP 后 retn 14h。这里照样拼出一个“子程序”，在真实的 x86 上跑
  {
    static const unsigned char stub[] = {0x55, 0x8B, 0xEC, 0x83, 0xEC, 0x20,  // 子程序框架：push ebp / mov ebp,esp / sub esp,20h（局部变量）
      139, 69, 8, 133, 192, 116, 14, 255, 117, 24, 255, 117, 20, 255, 117, 16, 255, 117, 12, 255, 208, 201, 194, 20, 0};  // 置入代码的字节（与易语言源码逐字相同）
    void* mem = VirtualAlloc(0, 4096, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    memcpy(mem, stub, sizeof(stub));
    typedef INT_PTR(WINAPI * Call4)(INT_PTR, INT_PTR, INT_PTR, INT_PTR, INT_PTR);
    Call4 call = (Call4)mem;
    Check(call((INT_PTR)Ver, 0, 0, 0, 0) == 0x00010500, "调用桩：版本号");
    const char* s = (const char*)call((INT_PTR)Text, 33, 0, 0, 0);
    Check(s && strcmp(s, "\xE7\x81\xB5\xE5\x8A\xA8\xE8\x83\xB6\xE5\x9B\x8A") == 0, "调用桩：4 个参数按顺序到达（第 1 款皮肤名“灵动胶囊”）");
    Check(call(0, 1, 2, 3, 4) == 0, "调用桩：地址为 0 时返回 0，不崩溃");
    Check(call((INT_PTR)Info, 7, 0, 0, 0) == 0x00010500, "调用桩：XF_GetInfo");
    VirtualFree(mem, 0, MEM_RELEASE);
  }
  // 文字表：19 个语种 × 全部序号都有内容
  int empty = 0;
    int keys = 0; while (keys < 256 && *(const char*)Text(keys, 0, 0, 0)) keys++;  // 文字表的条数（超出范围的序号返回空串）
    for (int l = 0; l < 19; l++) for (int k = 0; k < keys; k++) { const char* t = (const char*)Text(k, l, 0, 0); if (!t || !*t) empty++; }
    if (keys < 50) empty++;
    for (int k = keys; k < 256; k++) if (*(const char*)Text(k, 0, 0, 0)) { empty++; break; }  // 第一个空串之后不能再有字：否则是表中间缺了一条（上面就会少数）
  Check(empty == 0, "19 个语种的文字没有空项");
  Check(strcmp((const char*)Text(61, 0, 0, 0), u8"找回悬浮窗") == 0 && strcmp((const char*)Text(61, 2, 0, 0), "Bring back floating window") == 0, "托盘菜单文字 61＝找回悬浮窗（易语言按这个序号取）");
  if (!fontDir.empty()) SetFontDir(S(fontDir), 0, 0, 0);
  Opt(100, 12345, 0, 0);  // 动画时刻固定，截图可重复
  { INT_PTR ok = Start(300, 200, 0, (INT_PTR)Cb); if (!ok) printf("INFO 启动失败原因 0x%X\n", (unsigned)Info(13, 0, 0, 0)); Check(ok == 1, "启动悬浮窗线程"); }
  Check(Info(9, 0, 0, 0) != 0, "窗口已创建");
  Check(Info(10, 0, 0, 0) != 0 && Info(10, 0, 0, 0) != (INT_PTR)GetCurrentThreadId(), "悬浮窗在自己的线程里");
  // ---- 截图：16 款 × 状态（中文），再抽 6 个语种的三种状态
  const char* states[] = {"on", "off", "sfx", "bgm", "both", "duck", "vduck", "sduck", "svduck", "ending", "numlock", "hover", "hoveridle", "nokey", "long", "paused", "dock", "dark"};
  int shots = 0, shotFail = 0;
  for (int skin = 1; skin <= SK_COUNT; skin++) {
    SetSkin(skin, 0, 0, 0);
    for (const char* st : states) {
      if (!strcmp(st, "dark") && skin != SK_GLASS) continue;
      Apply(st, LC[0], skin);
      for (int pct : {100, 200}) {
        char path[512]; sprintf(path, "%s\\s%d_%s_%d.png", out.c_str(), skin, st, pct);
        if (Snap(S(path), pct, 0, 0)) shots++; else { shotFail++; printf("INFO 截图失败 %s\n", path); }
      }
    }
    for (int li = 0; li < 6; li++) for (const char* st : {"on", "sfx", "off", "bgm"}) {
      Apply(st, LC[li], skin);
      char path[512]; sprintf(path, "%s\\L%d_%s_%s.png", out.c_str(), skin, LC[li].code, st);
      if (Snap(S(path), 100, 0, 0)) shots++; else shotFail++;
    }
  }
  Check(shotFail == 0, "全部截图成功");
  printf("INFO 截图 %d 张\n", shots);
  ContrastSuite(out);
  // ---- 鼠标：灵动胶囊，开关、键帽、右键、双击、悬停按钮
  Reset(LC[0]); SetSkin(1, 0, 0, 0); Opt(101, -1, 0, 0);
  Snap(S(out + "\\_probe.png"), 100, 0, 0);
  auto FindHit = [&](int want, RECT* rr) { for (int i = 0; i < 64; i++) { RECT r; INT_PTR id = THit(i, (INT_PTR)&r, 0, 0); if (!id) break; if (id == want) { *rr = r; return true; } } return false; };
  // 移动真实光标并等它“落地”：光标位置已更新，且悬浮窗已处理了到这个位置的那条系统移动消息，之后才发模拟的按下 / 抬起。
  // 不等的话，Wine 里负载高时上一个位置的系统移动消息可能在模拟按下之后才到：按着时离按下处很远，被当成拖动，这一下点击就没了、窗口也被拖走
  // （“胶囊：点暂停”偶发失败的原因，用 XF_GetInfo 26～90 的消息记录查实；真实输入按顺序送达，不会这样）
  auto CursorTo = [&](int x, int y) {
    HWND w = (HWND)Info(9, 0, 0, 0); RECT wr; GetWindowRect(w, &wr); POINT want = {wr.left + x, wr.top + y}, cur; GetCursorPos(&cur);
    LONG n0 = (LONG)Info(26, 0, 0, 0);
    SetCursorPos(want.x, want.y);
    if (cur.x == want.x && cur.y == want.y) return;  // 没动：不会有新的移动消息
    WaitUntil([&] {
      POINT p; GetCursorPos(&p); if (p.x != want.x || p.y != want.y) return false;
      LONG n = (LONG)Info(26, 0, 0, 0);
      for (LONG j = 0; j < n - n0 && j < 32; j++) { unsigned e = (unsigned)Info(27 + j, 0, 0, 0), e2 = (unsigned)Info(59 + j, 0, 0, 0);
        if ((e & 0xFFF) == WM_MOUSEMOVE && !((e >> 14) & 1) && (int)(e2 & 0x7FF) == (x & 0x7FF) && (int)((e2 >> 11) & 0x7FF) == (y & 0x7FF)) return true; }
      return false; }, 800);
  };
  auto ClickAt = [&](RECT r) { int x = (r.left + r.right) / 2, y = (r.top + r.bottom) / 2; CursorTo(x, y); TMouse(1, x, y, 0); TMouse(2, x, y, 0); TMouse(3, x, y, 0); };
  RECT r;
  memset((void*)gEvents, 0, sizeof(gEvents));
  Check(FindHit(1, &r), "胶囊：找到开关的可点区域");
  ClickAt(r); Check(gEvents[1] == 1, "胶囊：点开关 → 切换快捷键事件");
  Check(gEventThread != 0 && gEventThread != (LONG)GetCurrentThreadId(), "事件在悬浮窗线程上回调（易语言那边只做投递）");
  Check(FindHit(2, &r), "胶囊：找到键帽"); ClickAt(r); Check(gEvents[2] == 1, "胶囊：点键帽 → 设置切换键");
  int bx = 8, by = 8;  // 边距里（透明处）
  {  // 右键：弹出跟皮肤一致的菜单；按 Esc 关掉，什么也不触发
    LONG before = 0; for (int i = 1; i < 32; i++) before += gEvents[i];
    LONG mn0 = (LONG)Info(91, 0, 0, 0);
    auto OpenMenu = [&](DWORD& t0) { t0 = GetTickCount(); TMouse(8, (int)Info(11, 0, 0, 0) / 2 + 16, 30, 0); HWND w = nullptr;
      for (int i = 0; i < 200 && !w; i++) { Sleep(50); w = FindWindowW(L"#32768", nullptr); }  /* 最多等 10 秒：第一次弹菜单要建字体，单核机器上两套测试并行时超过过 5 秒 */
      return w; };
    DWORD mt0; HWND mw = OpenMenu(mt0);
    if (mw && GetTickCount() - mt0 > 2000) printf("INFO 第一次弹出右键菜单用了 %lu 毫秒\n", GetTickCount() - mt0);
    if (!mw) { printf("INFO 右键菜单没找到：弹过 %ld 次菜单，上一次开了 %ld 毫秒、选了 %ld；已触发的事件：", (long)Info(91, 0, 0, 0), (long)Info(92, 0, 0, 0), (long)Info(93, 0, 0, 0));
      for (int i = 1; i < 32; i++) { if (gEvents[i]) printf(" %d×%ld", i, (long)gEvents[i]); }
      printf("；前台窗口 %p，桌面窗口 %p，悬浮窗 %p\n", (void*)GetForegroundWindow(), (void*)GetDesktopWindow(), (void*)Info(9, 0, 0, 0)); DumpMsgLog();
      // 只在 Wine：菜单其实弹出来了，刚开几十毫秒就因激活转到桌面窗口而取消、什么也没选——消息记录里是 ENTERMENU、CANCELMODE、ACTIVATEAPP 0、EXITMENU。
      // 测试用的虚拟屏幕没有窗口管理器，键盘焦点跟着指针走，菜单正好弹在指针下面，Wine 的焦点同步有时会判定程序失去了焦点（机器忙时才碰上）。
      // Windows 没有这套机制，那里照常严格判定；这里核对过这个特征才重试一次
      if (g_wine && (LONG)Info(91, 0, 0, 0) > mn0 && Info(93, 0, 0, 0) == 0 && Info(92, 0, 0, 0) < 500 && GetForegroundWindow() == GetDesktopWindow()) {
        printf("INFO Wine：菜单弹出 %ld 毫秒后因激活转到桌面而取消（X11 焦点跟随指针的竞争），重试一次\n", (long)Info(92, 0, 0, 0));
        mw = OpenMenu(mt0);
      } }
    Check(mw != nullptr, "右键：弹出菜单");
    if (mw) { PostMessageW(mw, WM_KEYDOWN, VK_ESCAPE, 0); for (int i = 0; i < 40 && FindWindowW(L"#32768", nullptr) && IsWindowVisible(FindWindowW(L"#32768", nullptr)); i++) Sleep(50); }
    Sleep(150);
    LONG after = 0; for (int i = 1; i < 32; i++) after += gEvents[i];
    Check(mw && !IsWindowVisible(mw) && after == before, "菜单按 Esc 关掉：不触发任何操作");
    // 真实的键盘输入（SendInput）也能到达菜单：菜单的所有者被置到前台；点菜单外面也能关掉
    auto MenuOpen = [&]() { TMouse(8, (int)Info(11, 0, 0, 0) / 2 + 16, 30, 0); HWND w = nullptr; for (int i = 0; i < 100 && !(w && IsWindowVisible(w)); i++) { Sleep(50); w = FindWindowW(L"#32768", nullptr); } return w; };
    auto MenuGone = [&](HWND w) { for (int i = 0; i < 40 && IsWindowVisible(w); i++) Sleep(50); return !IsWindowVisible(w); };
    // 要按真实按键的几项：真机上用真实的右键打开（和用户一样——进程收到真实输入，菜单才能拿到前台和键盘；模拟的右键在测试程序不在前台时拿不到）；
    // 按键前确认前台确实在本进程，不在时（期间点了别的窗口、别的程序弹出来）跳过，免得真实按键落到别的程序里
    auto FgInfo = [&]() { HWND f = GetForegroundWindow(); wchar_t cls[64] = L""; if (f) GetClassNameW(f, cls, 64); DWORD pid = 0; if (f) GetWindowThreadProcessId(f, &pid);
      char b[200]; sprintf(b, "前台窗口类名“%s”，%s", U8(cls).c_str(), !f ? "没有前台窗口" : pid == GetCurrentProcessId() ? "是测试程序" : "是别的程序"); return std::string(b); };
    auto MenuOpenKb = [&](bool* ok) -> HWND {
      HWND w = nullptr; POINT bp;
      if (!g_wine && BlankSpot(&bp)) {
        SetCursorPos(bp.x, bp.y); Sleep(50);
        INPUT in[2] = {}; in[0].type = in[1].type = INPUT_MOUSE; in[0].mi.dwFlags = MOUSEEVENTF_RIGHTDOWN; in[1].mi.dwFlags = MOUSEEVENTF_RIGHTUP; SendInput(2, in, sizeof(INPUT));
        for (int i = 0; i < 100 && !(w && IsWindowVisible(w)); i++) { Sleep(50); w = FindWindowW(L"#32768", nullptr); }
      } else w = MenuOpen();
      Sleep(100); DWORD pid = 0; HWND f = GetForegroundWindow(); if (f) GetWindowThreadProcessId(f, &pid);
      *ok = w && pid == GetCurrentProcessId();
      if (w && !*ok) { printf("SKIP 前台不在测试程序（%s）：这一项不发送真实按键，免得落到别的程序里\n", FgInfo().c_str()); PostMessageW(w, WM_KEYDOWN, VK_ESCAPE, 0); if (!MenuGone(w)) PostMessageW((HWND)Info(9, 0, 0, 0), WM_CANCELMODE, 0, 0); MenuGone(w); }
      return w;
    };
    { bool ok = false; HWND w = MenuOpenKb(&ok);
      if (!w) Check(false, "菜单：按真实的 Esc 键关掉（菜单没打开）");
      else if (ok) { INPUT in[2] = {}; in[0].type = in[1].type = INPUT_KEYBOARD; in[0].ki.wVk = in[1].ki.wVk = VK_ESCAPE; in[1].ki.dwFlags = KEYEVENTF_KEYUP; SendInput(2, in, sizeof(INPUT));
        bool gone = MenuGone(w); if (!gone) printf("INFO 菜单没关：%s\n", FgInfo().c_str()); Check(gone, "菜单：按真实的 Esc 键关掉"); }
      SetCursorPos(5, 1000); }
    { HWND w = MenuOpen(); RECT wr; GetWindowRect(w, &wr); POINT o = {wr.right + 200, wr.bottom + 150}; bool skip = !g_wine && !BlankSpot(&o);  /* 真机上点悬浮窗左边空白处，不点桌面 */
      if (skip) { printf("INFO 没找到悬浮窗上的空白处：这一项改用 Esc 关菜单\n"); PostMessageW(w, WM_KEYDOWN, VK_ESCAPE, 0); }
      else {
      SetCursorPos(o.x, o.y); INPUT in[2] = {}; in[0].type = in[1].type = INPUT_MOUSE; in[0].mi.dwFlags = MOUSEEVENTF_LEFTDOWN; in[1].mi.dwFlags = MOUSEEVENTF_LEFTUP; SendInput(2, in, sizeof(INPUT));
      }
      Check(w && MenuGone(w), "菜单：点菜单外面关掉"); }
    // 方向键＋回车（真实按键）：第一项是“打开主面板”（事件 3），往下第三项是“设置切换快捷键…”（事件 2）——顺带核对真实菜单的顺序
    auto KeyPick = [&](int downs, int ev, const char* name) {
      bool ok = false; HWND w = MenuOpenKb(&ok);
      if (!w) { Check(false, (std::string(name) + "（菜单没打开）").c_str()); return; }
      if (ok) {
        std::vector<INPUT> in; for (int i = 0; i < downs; i++) { INPUT d = {}; d.type = INPUT_KEYBOARD; d.ki.wVk = VK_DOWN; in.push_back(d); d.ki.dwFlags = KEYEVENTF_KEYUP; in.push_back(d); }
        INPUT r = {}; r.type = INPUT_KEYBOARD; r.ki.wVk = VK_RETURN; in.push_back(r); r.ki.dwFlags = KEYEVENTF_KEYUP; in.push_back(r);
        LONG before = gEvents[ev]; SendInput((UINT)in.size(), in.data(), sizeof(INPUT));
        bool gone = MenuGone(w); if (!gone) printf("INFO 菜单没关：%s\n", FgInfo().c_str());
        Check(gone && gEvents[ev] == before + 1, name);
      }
      SetCursorPos(5, 1000);
    };
    KeyPick(1, 3, "菜单：方向键选第一项、回车 → 打开主面板");
    KeyPick(3, 2, "菜单：方向键往下第三项、回车 → 设置切换快捷键…");
    { bool fgOk = GetForegroundWindow() != (HWND)Info(9, 0, 0, 0); if (!fgOk) printf("INFO 菜单关掉后：%s\n", FgInfo().c_str());
      Check(fgOk, "菜单关掉后前台还给原来的窗口（悬浮窗不停在前台）"); }
    F4 Menu = P("XF_TestMenu");
    memset((void*)gEvents, 0, sizeof(gEvents));
    Menu(1, 0, 0, 0); Check(gEvents[2] == 1, "菜单「设置切换快捷键…」→ 设置切换键");
    Menu(2, 0, 0, 0); Check(gEvents[1] == 1, "菜单「快捷键开关」→ 切换开关");
    Menu(3, 0, 0, 0); Check(gEvents[3] == 1, "菜单「打开主面板」→ 主面板");
    Menu(103, 0, 0, 0); Check(gEvents[16] == 1 && gArgs[16] == 3, "菜单「皮肤 → 第 3 款」→ 换皮肤事件（参数 3）");  // 皮肤命令 101～116（原来是 11～18）
    Menu(21, 0, 0, 0); Check(gEvents[18] == 1, "菜单「隐藏悬浮窗」→ 隐藏事件");
    Menu(22, 0, 0, 0); Check(gEvents[19] == 1 && gEvents[4] == 0, "菜单「退出」→ 退出事件");
    Menu(1150, 0, 0, 0); Check(gEvents[20] == 1, "菜单「大小 → 150%」→ 大小事件");
    Menu(4, 0, 0, 0); Check(gEvents[6] == 1, "1.3.0 菜单「急停」→ 急停事件（音效、背景音乐都停）");
    Menu(5, 0, 0, 0); Menu(6, 0, 0, 0); Check(gEvents[13] == 1 && gEvents[10] == 1, "1.3.0 菜单「取消闪避」→ 背景音乐那一路 / 音效那一路的取消闪避事件");
    Menu(7, 0, 0, 0); Check(gEvents[21] == 1, "1.3.2 菜单「截屏」→ 截屏事件 21（宿主收到后截屏）");
    F4 MSnap = P("XF_TestMenuSnap");
    for (int sk = 1; sk <= SK_COUNT; sk++) { SetSkin(sk, 0, 0, 0); char p[512]; sprintf(p, "%s\\menu_s%d.png", out.c_str(), sk); Check(MSnap(S(p), 0, 0, 0) == 1, "菜单画成图（跟着皮肤）"); }
    // ---- 1.3.0：按皮肤的角色显示与控制（只管音效 12 款、只管背景音乐 2 款、两路都管 2 款）
    {
      std::string lg = out + "\\_role_log.txt", sN = U8(LC[0].sfx).substr(0, 6), bN = U8(LC[0].bgm).substr(0, 6);  // 掌声 / 舞曲（UTF-8 每字 3 字节；截断、省略号都认得出）
      auto drawn = [&](int sk, const char* st, const std::string& needle) {
        SetSkin(sk, 0, 0, 0); Apply(st, LC[0], sk); DeleteFileW(W8(lg).c_str());
        Opt(112, S(lg), 0, 0); Snap(S(out + "\\_probe_role.png"), 100, 0, 0); Opt(112, S(""), 0, 0);
        std::string tx; FILE* f = Fopen8(lg, L"rb"); if (f) { char bf[4096]; size_t n; while ((n = fread(bf, 1, sizeof bf, f)) > 0) tx.append(bf, n); fclose(f); }
        return tx.find(needle) != std::string::npos; };
      auto has = [&](int id) { RECT q; return FindHit(id, &q); };
      int okShow = 0, okHover = 0; std::string bad1, bad2;
      for (int sk = 1; sk <= SK_COUNT; sk++) {
        int ro = RoleOf(sk);
        bool bgmOnly = drawn(sk, "bgm", bN), bothB = drawn(sk, "both", bN), bothS = drawn(sk, "both", sN), sfxOnly = drawn(sk, "sfx", sN);
        bool good = ro == 1 ? (!bgmOnly && !bothB && bothS && sfxOnly) : ro == 2 ? (bgmOnly && bothB && !bothS && !sfxOnly) : (bgmOnly && bothB && bothS && sfxOnly);
        if (good) okShow++; else bad1 += " " + std::to_string(sk) + ":" + std::to_string(bgmOnly) + std::to_string(bothB) + std::to_string(bothS) + std::to_string(sfxOnly);
        SetSkin(sk, 0, 0, 0); Apply("hover", LC[0], sk); Snap(S(out + "\\_probe_role.png"), 100, 0, 0);
        bool hv = ro == 1 ? (has(13) && has(5) && !has(4) && !has(10) && !has(11) && !has(12)) : ro == 2 ? (has(11) && has(5) && !has(4) && !has(13)) : has(5);
        if (hv) okHover++; else bad2 += " " + std::to_string(sk);
        Opt(101, -1, 0, 0);
      }
      if (!bad1.empty()) printf("INFO 角色显示不符（款:只放背景音乐有背景音乐名/两路都放有背景音乐名/两路都放有音效名/只放音效有音效名）：%s\n", bad1.c_str());
      if (!bad2.empty()) printf("INFO 角色按钮不符：%s\n", bad2.c_str());
      Check(okShow == SK_COUNT, "1.4.0 角色：只管音效的 14 款（含黑胶唱机、磁带）不显示背景音乐名，两路都管的 2 款两路都显示");
      Check(okHover == SK_COUNT, "1.4.0 角色：悬停按钮只作用于显示的那一路（单路的 14 款是音效暂停），急停 16 款都有");
      SetSkin(1, 0, 0, 0); Reset(LC[0]); std::string p0 = out + "\\_role_menu0.png", p1 = out + "\\_role_menu1.png", stopW = U8(L"\u6025\u505c");  // 急停
      auto menuHas = [&](const std::string& png) { DeleteFileW(W8(lg).c_str()); Opt(112, S(lg), 0, 0); MSnap(S(png), 0, 0, 0); Opt(112, S(""), 0, 0);
        std::string tx; FILE* f = Fopen8(lg, L"rb"); if (f) { char bf[4096]; size_t n; while ((n = fread(bf, 1, sizeof bf, f)) > 0) tx.append(bf, n); fclose(f); } return tx.find(stopW) != std::string::npos; };
      bool m0 = menuHas(p0); Apply("bgm", LC[0], 1); bool m1 = menuHas(p1);  // 菜单截图的高度由更高的皮肤子菜单决定，按记下的文字判断
      Check(!m0 && m1, "1.3.0 角色：有东西在放时右键菜单多一项「急停」（只管音效的皮肤只放背景音乐时也点得到）");
      { std::string udW = U8(L"\u53d6\u6d88\u95ea\u907f"), allW = U8(L"\u5168\u90e8\u505c\u6b62");  // 取消闪避 / 全部停止
        auto menuTxt = [&]() { DeleteFileW(W8(lg).c_str()); Opt(112, S(lg), 0, 0); MSnap(S(p1), 0, 0, 0); Opt(112, S(""), 0, 0);
          std::string tx; FILE* f = Fopen8(lg, L"rb"); if (f) { char bf[4096]; size_t n; while ((n = fread(bf, 1, sizeof bf, f)) > 0) tx.append(bf, n); fclose(f); } return tx; };
        Duck(0, 1, 0, 0); std::string mt = menuTxt();  // 灵动胶囊（只管音效）＋只放背景音乐＋背景音乐闪避中：悬浮窗上看不到这一路的闪避，取消要在菜单里点得到
        Check(mt.find(udW) != std::string::npos && mt.find(allW) != std::string::npos, "1.3.0 角色：背景音乐闪避中，只管音效的皮肤右键菜单有「取消闪避」，急停写明「全部停止」");
    { // 1.3.2：宿主交代了才有「截屏」，紧挨在「打开主面板」下面（原悬浮窗右键弹出的托盘菜单里两项也挨着），在「急停」「取消闪避」等出没的项前面，位置固定
      std::string shotW = U8(L"\u622a\u5c4f"), openW = U8(L"\u6253\u5f00\u4e3b\u9762\u677f");
      std::string t0 = menuTxt(); Opt(12, 1, 0, 0); std::string t1 = menuTxt(); Opt(12, 0, 0, 0); std::string t2 = menuTxt();
      size_t po = t1.find(openW), ps = t1.find(shotW), pu = t1.find(udW), pa = t1.find(allW);
      Check(t0.find(shotW) == std::string::npos && t2.find(shotW) == std::string::npos, "1.3.2 右键菜单默认没有「截屏」（宿主没交代 XF_SetOption 12）");
      Check(po != std::string::npos && ps != std::string::npos && po < ps && (pa == std::string::npos || ps < pa) && (pu == std::string::npos || ps < pu), "1.3.2 交代 XF_SetOption 12 后右键菜单有「截屏」，紧挨在「打开主面板」下面、「急停」「取消闪避」前面");
    }
        Duck(0, 0, 0, 0); }
      {  // 画廊：只给两路都管的 2 款标角色（1.4.0 起没有只管背景音乐的皮肤）
        F4 Gal2 = P("XF_TestGallery"); std::string pg = out + "\\_role_gallery.png"; Reset(LC[0]);
        Menu(9, 0, 0, 0); WaitUntil([&] { return Info(19, 0, 0, 0) == 1; }, 3000);  // 先打开画廊（同原有画廊测试）
        DeleteFileW(W8(lg).c_str()); Opt(112, S(lg), 0, 0); bool okg = Gal2(1, 0, S(pg), 0) == 1; Opt(112, S(""), 0, 0); Gal2(4, 0, 0, 0); WaitUntil([&] { return Info(19, 0, 0, 0) == 0; }, 3000);
        std::string tx; FILE* f = Fopen8(lg, L"rb"); if (f) { char bf[4096]; size_t n; while ((n = fread(bf, 1, sizeof bf, f)) > 0) tx.append(bf, n); fclose(f); }
        std::string bgW = U8(L"\u80cc\u666f\u97f3\u4e50"), dualW = U8(L"\u97f3\u6548 + \u80cc\u666f\u97f3\u4e50"); size_t cnt = 0, pos = 0; while ((pos = tx.find(bgW, pos)) != std::string::npos) { cnt++; pos += bgW.size(); }  // 背景音乐 / 音效 + 背景音乐
        size_t cd = 0; pos = 0; while ((pos = tx.find(dualW, pos)) != std::string::npos) { cd++; pos += dualW.size(); }
        if (!(okg && cnt == 2 && cd == 2)) printf("INFO 画廊角色标记：截图%d 背景音乐%zu 两路%zu\n", (int)okg, cnt, cd);
        Check(okg && cnt == 2 && cd == 2, "1.4.0 画廊：只给两路都管的 2 款标「音效 + 背景音乐」，只管音效的 14 款不标（黑胶唱机、磁带原来标「背景音乐」）"); }
      Reset(LC[0]);
    }
    // ---- 1.4.0：磁带读数放大到 16 号字、闪避中照常显示倒计时，闪避印章盖在标签纸右下角（不压读数、读数不压磁带轮、字不伸出印章两头）；
    //      什么都没放时说话闪避不盖印章；画廊的缩略图一律按“快捷键已开启”画，悬浮窗本身照常是真实状态
    {
      F4 Mn = P("XF_TestMenu"), Gl = P("XF_TestGallery");
      std::string lgp = out + "\\_cas_log.txt", pa = out + "\\_cas_a.png", pb = out + "\\_cas_b.png";
      static const char* L19[] = {"zh-Hans", "zh-Hant", "en", "ja", "ko", "es", "pt-BR", "fr", "de", "id", "th", "vi", "tr", "ar", "ru", "ms", "fil", "hi", "it"};
      auto readAll = [&](const std::string& p) { std::string tx; FILE* f = Fopen8(p, L"rb"); if (f) { char bf[4096]; size_t nn; while ((nn = fread(bf, 1, sizeof bf, f)) > 0) tx.append(bf, nn); fclose(f); } return tx; };
      int n = 0, okSize = 0, okApart = 0, okLong = 0, okSide = 0, sideAll = 0, side100 = 0, side200 = 0; std::string bad;
      SetSkin(SK_CASSETTE, 0, 0, 0);
      for (const char* code : L19) for (int dk : {1, 2}) for (int pct : {100, 200}) {
        Reset(LC[0]); SetLang(S(code), 0, 0, 0); TInfo(0, 1, S(U8(LC[0].sfx)), 0); TTime(0, 2000, 5000, 70); Duck(dk, 0, 0, 0); Opt(101, 0, 0, 0);
        DeleteFileW(W8(lgp).c_str()); Opt(112, S(lgp), 0, 0); bool s1 = Snap(S(pa), pct, 0, 0) == 1; Opt(112, S(""), 0, 0);
        Opt(111, 1, 0, 0); bool s2 = Snap(S(pb), pct, 0, 0) == 1; Opt(111, 0, 0, 0);
        std::vector<Seg> sg = ReadLog(lgp); const Seg* lcd = nullptr; const Seg* st = nullptr;
        for (auto& sx : sg) { if (sx.col == 0xFFFFC15A && sx.kind == 'T') lcd = &sx; else if (sx.col == 0xFFB42318) st = &sx; }
        bool rtl = !strcmp(code, "ar"); float k = pct / 100.f, m = ceilf(16 * k);
        char tag[64]; sprintf(tag, " %s/%d/%d%%", code, dk, pct); n++;
        if (!s1 || !s2 || !lcd || !st) { bad += std::string(tag) + "(没画出或没记到读数、印章)"; continue; }
        if (lcd->px >= 16 * k - 0.01f) okSize++; else bad += std::string(tag) + "(读数缩小了)";
        bool apart = std::min(lcd->x1, st->x1) <= std::max(lcd->x0, st->x0) || std::min(lcd->y1, st->y1) <= std::max(lcd->y0, st->y0);
        bool inGap = lcd->x0 >= m + 53 * k && lcd->x1 <= m + 143 * k;  // 两个磁带轮之间（磁带轮最大时的内沿；镜像画布左右对称）
        if (apart && inGap) okApart++; else bad += std::string(tag) + (apart ? "(读数压到磁带轮)" : "(印章压住读数)");
        if (rtl) { okLong++; continue; }  // 阿拉伯语的印章用 Text 画（与量宽同一种画法，不斜着交给 GDI+）；Wine 里阿拉伯语的排版只报告（见 README）
        // 印章上的字在印章框里：有字图与不画字图的差＝笔画；转到印章自己的坐标（-10°）里与边框（不画字图里 #B42318 的像素）的外接框比
        Img A, B; if (!LoadPng(pa, A) || !LoadPng(pb, B) || A.w != B.w || A.h != B.h) { bad += std::string(tag) + "(读图失败)"; continue; }
        int X0 = std::max(0, (int)st->x0 - 40), X1 = std::min(A.w, (int)st->x1 + 40), Y0 = std::max(0, (int)st->y0 - 40), Y1 = std::min(A.h, (int)st->y1 + 40);
        const double ca = cos(10 * 3.14159265358979 / 180), sa = sin(10 * 3.14159265358979 / 180);
        double umin = 1e9, umax = -1e9, vmin = 1e9, vmax = -1e9; std::vector<std::pair<double, double>> ink;
        for (int y = Y0; y < Y1; y++) for (int x = X0; x < X1; x++) {
          unsigned pa1 = A.px[(size_t)y * A.w + x], pb1 = B.px[(size_t)y * B.w + x];
          int br = (pb1 >> 16) & 255, bgc = (pb1 >> 8) & 255, bbc = pb1 & 255, ar = (pa1 >> 16) & 255, ag = (pa1 >> 8) & 255, ab = pa1 & 255;
          double u = x * ca - y * sa, v = x * sa + y * ca;
          if ((pb1 >> 24) > 180 && abs(br - 0xB4) < 45 && abs(bgc - 0x23) < 55 && abs(bbc - 0x18) < 55) { umin = std::min(umin, u); umax = std::max(umax, u); vmin = std::min(vmin, v); vmax = std::max(vmax, v); }
          bool inLcd = x >= lcd->x0 - 3 && x <= lcd->x1 + 3 && y >= lcd->y0 - 3 && y <= lcd->y1 + 3;  // 琥珀色的读数不算
          if (!inLcd && PmDiff(pa1, pb1) >= 24 && ar > ag + 90 && ar > ab + 90) ink.push_back({u, v});
        }
        int outU = 0, outV = 0; for (auto& p : ink) { if (p.first < umin + 1.5 || p.first > umax - 1.5) outU++; if (p.second < vmin - 0.5 || p.second > vmax + 0.5) outV++; }
        if (!ink.empty() && umax > umin && outU == 0) okLong++; else bad += std::string(tag) + "(字伸出印章两头 " + std::to_string(outU) + " 点)";
        sideAll++; if (outV == 0) okSide++; else { (pct == 100 ? side100 : side200)++; if (!g_wine) bad += std::string(tag) + "(字越出印章上下边 " + std::to_string(outV) + " 点)"; }
      }
      if (!bad.empty()) printf("INFO 磁带读数 / 印章：%s\n", bad.c_str());
      Check(okSize == n, "1.4.0 磁带：读数 16 号字（19 个语种 × 闪避 / 说话闪避 × 100%、200%；原来 10 号字）");
      Check(okApart == n, "1.4.0 磁带：闪避中照常显示倒计时，读数在两个磁带轮之间、印章不压读数（原来印章斜盖在屏幕上，读数放大后 19 个语种里 16～17 个压上）");
      Check(okLong == n, "1.4.0 磁带：印章上的字不伸出印章两头（宽度按 GDI+ 的画法量；原来只按精绘量，法、俄等长的字伸出框）");
      if (g_wine) printf("INFO Wine 的 GDI+ 斜着画的字比要求的角度陡约 5°（与改动无关，改前也是这样）：长的字越出印章上下边 100%% %d 组、200%% %d 组（共 %d 组）；真机上判定\n", side100, side200, sideAll);
      else Check(okSide == sideAll, "1.4.0 磁带：印章上的字不越出印章上下边");
      {  // 磁带：待机时悬停不换出走带键（只管音效后待机时的播放键点了没反应：易语言的“音效暂停或继续”在没有音效时什么也不做）；放着音效时悬停照常是三个键
        SetSkin(SK_CASSETTE, 0, 0, 0); Reset(LC[0]); Opt(101, 1, 0, 0); Snap(S(pa), 100, 0, 0); RECT q;
        bool idleKeys = FindHit(13, &q) || FindHit(5, &q) || FindHit(4, &q) || FindHit(11, &q) || FindHit(10, &q) || FindHit(12, &q);
        TInfo(0, 1, S(U8(LC[0].sfx)), 0); TTime(0, 2000, 5000, 70); Snap(S(pa), 100, 0, 0); bool playKeys = FindHit(13, &q) && FindHit(5, &q) && FindHit(6, &q);
        TInfo(0, 2, S(U8(LC[0].sfx)), 0); Snap(S(pa), 100, 0, 0); bool pausedKeys = FindHit(13, &q) && FindHit(5, &q);
        Check(!idleKeys && playKeys && pausedKeys, "1.4.0 磁带：待机时悬停不换出走带键（不留点了没反应的键），放着、暂停着时悬停照常是暂停 / 继续、急停、主面板");
        Opt(101, 0, 0, 0);
      }
      Reset(LC[0]); Duck(2, 2, 0, 0); DeleteFileW(W8(lgp).c_str()); Opt(112, S(lgp), 0, 0); Snap(S(pa), 100, 0, 0); Opt(112, S(""), 0, 0);
      { std::vector<Seg> sg = ReadLog(lgp); bool stamp = false, ready = false; for (auto& sx : sg) { if (sx.col == 0xFFB42318) stamp = true; if (sx.col == 0xFF7CFFB2 && sx.text == "READY") ready = true; }
        Check(!stamp && ready, "1.4.0 磁带：什么都没放时说话闪避不盖印章、读数照常是 READY（与其余各款相同；原来盖印章、读数换成“闪避”）"); }
      Duck(0, 0, 0, 0); Reset(LC[0]); SetSkin(1, 0, 0, 0);
      {  // 画廊：缩略图一律按“快捷键已开启”画
        HWND fw2 = (HWND)Info(9, 0, 0, 0); RECT fr2 = {0, 0, 0, 0}; GetWindowRect(fw2, &fr2);
        int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN), fx = (fr2.left + fr2.right) / 2, fy = (fr2.top + fr2.bottom) / 2;
        SetCursorPos(fx < sw / 2 ? sw - 3 : 3, fy < sh / 2 ? sh - 3 : 3); Sleep(150);  // 真实光标移到离悬浮窗最远的角上：停在卡片上会把那张画成“指着”
        auto galShot = [&](const std::string& p) { Mn(9, 0, 0, 0); WaitUntil([&] { return Info(19, 0, 0, 0) == 1; }, 3000); bool ok = Gl(1, 0, S(p), 0) == 1; Gl(4, 0, 0, 0); WaitUntil([&] { return Info(19, 0, 0, 0) == 0; }, 3000); return ok; };
        std::string g1 = out + "\\_gal_on.png", g2 = out + "\\_gal_off.png", g3 = out + "\\_gal_num.png";
        bool o1 = galShot(g1); SetHot(0, S("F12"), 0, 0); bool o2 = galShot(g2); SetHot(1, S("F12"), 1, 0); bool o3 = galShot(g3);
        Img a1, a2, a3; bool same = o1 && o2 && o3 && LoadPng(g1, a1) && LoadPng(g2, a2) && LoadPng(g3, a3) && a1.w == a2.w && a1.h == a2.h && a1.w == a3.w && a1.h == a3.h && a1.px == a2.px && a1.px == a3.px;
        Check(same, "1.4.0 画廊：快捷键开着、关着、小键盘提醒时画出来逐像素相同（缩略图一律按“已开启”画；原来关着时 16 张全是灰的，小键盘提醒时 16 张全是提醒）");
        SetHot(0, S("F12"), 0, 0); DeleteFileW(W8(lgp).c_str()); Opt(112, S(lgp), 0, 0); Snap(S(out + "\\_gal_real.png"), 100, 0, 0); Opt(112, S(""), 0, 0);
        Check(readAll(lgp).find(U8(L"\u5feb\u6377\u952e\u5df2\u5173\u95ed")) != std::string::npos, "1.4.0 悬浮窗本身照常显示真实的开关（快捷键关着时写“快捷键已关闭”）");  // 快捷键已关闭
        Reset(LC[0]); SetCursorPos(5, 1000);
      }
    }
    // ---- 换皮肤时的实时预览：右键菜单里指着哪款，悬浮窗就临时显示哪款；皮肤画廊
    {
      SetSkin(1, 0, 0, 0); Snap(S(out + "\\_probe_pv.png"), 100, 0, 0);
      HWND fw = (HWND)Info(9, 0, 0, 0); int w0 = (int)Info(11, 0, 0, 0);
      SendMessageW(fw, WM_MENUSELECT, MAKEWPARAM(103, MF_OWNERDRAW), (LPARAM)1);  // 皮肤命令 101～116
      Check(Info(18, 0, 0, 0) == 3 && Info(4, 0, 0, 0) == 1 && (int)Info(11, 0, 0, 0) != w0, "右键菜单里指着第 3 款：悬浮窗临时显示第 3 款（皮肤设置不变）");
      SendMessageW(fw, WM_MENUSELECT, MAKEWPARAM(3, MF_OWNERDRAW), (LPARAM)1);
      Check(Info(18, 0, 0, 0) == 0 && (int)Info(11, 0, 0, 0) == w0, "指到别的项：恢复原来的皮肤");
      F4 Gal = P("XF_TestGallery");
      auto Until = [&](auto cond, int ms) { for (int t = 0; t < ms; t += 25) { if (cond()) return true; Sleep(25); } return (bool)cond(); };  // 等到条件成立（机器忙时界面线程晚一点也不算错）
      memset((void*)gEvents, 0, sizeof(gEvents));
      Menu(9, 0, 0, 0);
      HWND gw = FindWindowW(L"XhhFloatGallery", nullptr);
      Check(Info(19, 0, 0, 0) == 1 && gw && IsWindowVisible(gw), "菜单「预览全部皮肤…」→ 打开皮肤画廊");
      { RECT gr, fr; GetWindowRect(gw, &gr); GetWindowRect(fw, &fr); printf("INFO 画廊 %ld,%ld～%ld,%ld  悬浮窗 %ld,%ld～%ld,%ld\n", gr.left, gr.top, gr.right, gr.bottom, fr.left, fr.top, fr.right, fr.bottom); }
      Gal(2, 5, 0, 0);
      Check(Info(18, 0, 0, 0) == 5 && Info(4, 0, 0, 0) == 1, "画廊：指着第 5 款，悬浮窗临时显示第 5 款");
      Check(Gal(1, 0, S(out + "\\gallery.png"), 0) == 1, "画廊画成图");
      Gal(4, 0, 0, 0);
      Check(Info(19, 0, 0, 0) == 0 && Info(18, 0, 0, 0) == 0 && gEvents[16] == 0 && (int)Info(11, 0, 0, 0) == w0 && !IsWindowVisible(gw), "画廊：Esc 取消——关掉、恢复原来的皮肤、不换");
      Menu(9, 0, 0, 0); Gal(2, 7, 0, 0); Gal(3, 7, 0, 0);
      Check(gEvents[16] == 1 && gArgs[16] == 7 && Info(19, 0, 0, 0) == 0 && Info(18, 0, 0, 0) == 7, "画廊：点第 7 款 → 换皮肤事件（参数 7）；易语言换上之前悬浮窗继续显示第 7 款");
      SetSkin(7, 0, 0, 0);
      Check(Until([&] { return Info(18, 0, 0, 0) == 0 && Info(4, 0, 0, 0) == 7; }, 2000), "易语言换上之后：不再是临时显示");
      SetSkin(1, 0, 0, 0); Sleep(100);
      memset((void*)gEvents, 0, sizeof(gEvents));
      Menu(103, 0, 0, 0);
      Check(gEvents[16] == 1 && gArgs[16] == 3 && Info(18, 0, 0, 0) == 3, "右键菜单选第 3 款：同样先显示第 3 款等易语言换上");
      Sleep(2800);
      Check(Until([&] { return Info(18, 0, 0, 0) == 0 && Info(4, 0, 0, 0) == 1 && (int)Info(11, 0, 0, 0) == w0; }, 3000), "3 秒还没换上（易语言没处理）：恢复原来的皮肤");
      Menu(9, 0, 0, 0); Gal(2, 2, 0, 0);
      { INPUT in = {}; in.type = INPUT_KEYBOARD; in.ki.wVk = VK_ESCAPE; SendInput(1, &in, sizeof(INPUT)); Sleep(200); in.ki.dwFlags = KEYEVENTF_KEYUP; SendInput(1, &in, sizeof(INPUT)); Sleep(150); }
      Check(Until([&] { return Info(19, 0, 0, 0) == 0 && Info(18, 0, 0, 0) == 0; }, 2000), "画廊不抢焦点：按真实的 Esc 键也能取消");
      Menu(9, 0, 0, 0);
      { RECT gr; GetWindowRect(gw, &gr); int cx = gr.left > 300 ? gr.left - 200 : gr.right + 200, cy = gr.bottom + 60; POINT bp; if (!g_wine && BlankSpot(&bp)) { cx = bp.x; cy = bp.y; } SetCursorPos(cx, cy);  /* 真机上点悬浮窗左边空白处 */
        INPUT in = {}; in.type = INPUT_MOUSE; in.mi.dwFlags = MOUSEEVENTF_LEFTDOWN; SendInput(1, &in, sizeof(INPUT)); Sleep(200); in.mi.dwFlags = MOUSEEVENTF_LEFTUP; SendInput(1, &in, sizeof(INPUT)); Sleep(150); }
      Check(Until([&] { return Info(19, 0, 0, 0) == 0 && Info(18, 0, 0, 0) == 0; }, 2000) && gEvents[16] == 1, "画廊：在外面点一下就取消");
      SetCursorPos(5, 1000);
      Opt(7, 1, 0, 0);
      Check(Until([&] { return Info(19, 0, 0, 0) == 1 && IsWindowVisible(gw); }, 3000), "选项 7（托盘菜单「预览全部皮肤…」）：打开皮肤画廊");
      {  // 卡片之间的缝：预览不跳回；离开画廊才恢复。用真实光标（按画廊的排法算位置：边距 12、内边距 14、标题 44、卡片 230×138、间隔 8，乘系统缩放）——
         // 只发模拟的移动消息时，真实光标不在画廊上，Windows 收到 TrackMouseEvent 会马上发“鼠标离开”，预览当场恢复（Wine 不这样，真机上才看出来）
        RECT gr; GetWindowRect(gw, &gr); float k = (float)(gr.right - gr.left) / (972.f + 24.f); int mg = (int)ceilf(12 * k);  // 画廊实际的缩放：屏幕放不下时按工作区缩小过，不能直接用系统缩放
        auto At = [&](float x, float y) { SetCursorPos(gr.left + mg + (int)(x * k), gr.top + mg + (int)(y * k)); };
        At(14 + 230 + 8 + 115, 14 + 44 + 69);  // 第 2 款卡片中间
        bool on2 = Until([&] { return Info(18, 0, 0, 0) == 2; }, 2000);
        At(14 + 230 + 8 + 230 + 4, 14 + 44 + 69);  // 第 2、3 款之间的缝
        Sleep(300); bool kept = Info(18, 0, 0, 0) == 2;
        SetCursorPos(gr.left - 40 > 0 ? gr.left - 40 : gr.right + 40, gr.bottom + 40);  // 离开画廊
        bool back = Until([&] { return Info(18, 0, 0, 0) == 0; }, 2000);
        if (!(on2 && kept && back)) printf("INFO 画廊缝里：指着第 2 款时预览 %s，到缝里 %s，离开后 %s（当前临时显示 %d）\n", on2 ? "是第 2 款" : "不是第 2 款", kept ? "没变" : "变了", back ? "已恢复" : "没恢复", (int)Info(18, 0, 0, 0));
        Check(on2 && kept && back, "画廊：鼠标在卡片之间的缝里预览不跳回，离开画廊才恢复原来的皮肤");
        SetCursorPos(5, 1000);
      }
      {  // 别的窗口到了前台就关（与系统的浮出控件一样；管理员权限的程序在前台、看不到点击时也靠这一条）
        Sleep(600);
        HWND other = CreateWindowExW(0, L"STATIC", L"xftest", WS_POPUP | WS_VISIBLE, 0, 0, 40, 40, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
        SetForegroundWindow(other);
        bool closed = Until([&] { return Info(19, 0, 0, 0) == 0; }, 2000);
        if (!closed) printf("INFO 画廊没关：前台窗口 %s\n", GetForegroundWindow() == other ? "是新窗口" : "不是新窗口（系统没让它到前台）");
        Check(closed || GetForegroundWindow() != other, "画廊：别的窗口到了前台就关");
        DestroyWindow(other); Gal(4, 0, 0, 0);
      }
      { HWND fw = (HWND)Info(9, 0, 0, 0); Show(0, 0, 0, 0); Until([&] { return !IsWindowVisible(fw); }, 2000);  // 悬浮窗隐藏着时（易语言会先 XF_Show 1，这里直接调）：不开画廊、不留计时器，也不出错
        INT_PTR rq = Opt(7, 1, 0, 0);  // 请求时当场判断（原来投递后再判断，配合固定的 Sleep(300)：机器忙时消息晚到，窗口已经又显示，画廊真的打开了、一直开着，后面点暂停的那一下被拿去关画廊）
        Check(rq == 0 && Info(19, 0, 0, 0) == 0 && !IsWindowVisible(gw), "悬浮窗隐藏着时：选项 7 不打开画廊（当场不受理，看不到预览）");
        Show(1, 0, 0, 0); Check(Until([&] { return IsWindowVisible(fw) != 0; }, 3000), "隐藏后再显示：悬浮窗照常显示"); }
      Gal(4, 0, 0, 0);  // 收尾：确认画廊关着再往下测（哪一项出了意外也不连累后面的）
      Check(Until([&] { return Info(19, 0, 0, 0) == 0; }, 2000), "画廊测试结束：画廊关着");
    }
    SetSkin(1, 0, 0, 0); memset((void*)gEvents, 0, sizeof(gEvents));
    Snap(S(out + "\\_probe_menu.png"), 100, 0, 0);  // 换皮肤是投递的、模拟鼠标是直接送达的：先同步画一帧，下面按第 1 款的布局点（原来偶发按上一款的布局点到空处）
  }
  { RECT sw; FindHit(1, &sw); int x = sw.left - 60, y = (sw.top + sw.bottom) / 2; TMouse(4, x, y, 0); }
  Check(gEvents[3] == 1, "胶囊：双击空白处 → 打开主面板");
  (void)bx; (void)by;
  // 悬停：播放中移上去，延时后出现暂停 / 急停 / 主面板
  TInfo(0, 1, S(U8(LC[0].sfx)), 0); TTime(0, 2000, 5000, 70);
  Snap(S(out + "\\_probe2.png"), 100, 0, 0);
  { int hx = 40, hy = 40; CursorTo(hx, hy); TMouse(1, hx, hy, 0); for (int i = 0; i < 40 && (Info(14, 0, 0, 0) & 3) != 3; i++) Sleep(25); Sleep(50); }
  Snap(S(out + "\\_hover_real.png"), 100, 0, 0);
  if (FindHit(13, &r)) {  // 只有图标的按钮：悬停 0.6 秒后出现文字提示，移开就消失
    int x = (r.left + r.right) / 2, y = (r.top + r.bottom) / 2; CursorTo(x, y); TMouse(1, x, y, 0);
    HWND tip = nullptr; for (int i = 0; i < 80; i++) { Sleep(50); tip = FindWindowW(L"XhhFloatTip", nullptr); if (tip && IsWindowVisible(tip) && Info(17, 0, 0, 0) >= 0) break; }
    if (!(tip && IsWindowVisible(tip) && Info(17, 0, 0, 0) == 15)) printf("INFO 提示：窗口 %d 可见 %d 序号 %d 鼠标标志 %d\n", tip != nullptr, tip ? (int)IsWindowVisible(tip) : 0, (int)Info(17, 0, 0, 0), (int)Info(14, 0, 0, 0));
    Check(tip && IsWindowVisible(tip) && Info(17, 0, 0, 0) == 15, "胶囊：悬停在暂停按钮上出现提示「暂停」");
    TMouse(1, 40, 40, 0);
    Check(WaitUntil([&] { return Info(17, 0, 0, 0) == -1 && !IsWindowVisible(tip); }, 2000), "移到别处：提示消失");
  }
  WaitUntil([&] { return (Info(14, 0, 0, 0) & 3) == 3; }, 2000);  // 点之前再确认一次“悬停＋按钮已出现”（与开头等悬停同一个条件）：前面的操作可能留下一条迟到的“鼠标离开”
  Check(FindHit(13, &r), "胶囊：悬停后出现暂停按钮");
  { RECT before = r; LONG ev0 = gEvents[15];
    // 按下之前确认：悬停意图已成立、暂停按钮还在原处。原来移过去马上按：要是悬停刚被收掉，这一下移动会让悬停重新计时（110 毫秒后按钮才出来），
    // 按下时点到的是空处、不算点击（真机上用户点的是已经看得见的按钮，不会这样）；等了多久记下来，悬停被意外收掉时看得出来
    int cx = (r.left + r.right) / 2, cy = (r.top + r.bottom) / 2; CursorTo(cx, cy); TMouse(1, cx, cy, 0);
    DWORD w0 = GetTickCount();
    bool ready = WaitUntil([&] { RECT q; return (Info(14, 0, 0, 0) & 3) == 3 && FindHit(13, &q) && q.left == before.left && q.top == before.top; }, 2000);
    DWORD waited = GetTickCount() - w0; int flagsDown = (int)Info(14, 0, 0, 0);
    if (!ready || waited > 50) printf("INFO 点暂停之前等了 %lu 毫秒才确认按钮在、悬停已成立（%s，鼠标标志 %d）\n", waited, ready ? "已满足" : "没满足", flagsDown);
    TMouse(2, cx, cy, 0); TMouse(3, cx, cy, 0);
    if (gEvents[15] != ev0 + 1) {  // 偶发过：把当时的状态记下来，再出现时能直接看出原因
      printf("INFO 点暂停没触发：事件 15 由 %ld 变 %ld；按钮点前 %ld,%ld～%ld,%ld，点后%s；鼠标标志 %d；没算点击的原因 %d（1 抬起前按下状态已清 2 成了拖动 3 不是同一个按钮）、编号 %d/%d；按着时失去捕获 %d 次；位置变动事件 %ld\n",
             ev0, gEvents[15], before.left, before.top, before.right, before.bottom, FindHit(13, &r) ? "还在" : "不见了", (int)Info(14, 0, 0, 0), (int)(Info(24, 0, 0, 0) & 0xFF), (int)((Info(24, 0, 0, 0) >> 8) & 0xFF), (int)((Info(24, 0, 0, 0) >> 16) & 0xFF), (int)Info(25, 0, 0, 0), gEvents[12]);
      DumpMsgLog();
    }
    Check(gEvents[15] == ev0 + 1, "胶囊：点暂停 → 音效暂停 / 继续事件（1.3.0：只管音效的皮肤只暂停音效）"); }
  Check(FindHit(5, &r), "胶囊：悬停后出现急停按钮"); ClickAt(r); Check(gEvents[6] == 1, "胶囊：点急停 → 急停事件");
  Check(FindHit(6, &r), "胶囊：悬停后出现主面板按钮"); ClickAt(r); Check(gEvents[3] == 2, "胶囊：点主面板 → 打开主面板");
  TMouse(6, 0, 0, 0); Sleep(500);
  // 团播控台：闪避、急停、上一首、下一首
  Reset(LC[0]); SetSkin(SK_CONSOLE, 0, 0, 0); TInfo(1, 1, S(U8(LC[0].bgm)), 0); TTime(1, 151000, 235000, 60);
  Snap(S(out + "\\_probe3.png"), 100, 0, 0);
  memset((void*)gEvents, 0, sizeof(gEvents));
  Check(FindHit(9, &r), "控台：找到闪避按钮（没在闪避时是“开始闪避”）"); ClickAt(r); Check(gEvents[14] == 1, "控台：点闪避 → 开始闪避");
  Duck(0, 1, 0, 0); Snap(S(out + "\\_probe4.png"), 100, 0, 0);
  Check(FindHit(8, &r), "控台：闪避中按钮"); ClickAt(r); Check(gEvents[13] == 1, "控台：点闪避中 → 取消闪避（背景音乐那一路）");
  Check(FindHit(5, &r), "控台：急停按钮"); ClickAt(r); Check(gEvents[6] == 1, "控台：点急停 → 急停");
  Opt(101, 1, 0, 0); Snap(S(out + "\\_probe5.png"), 100, 0, 0);
  Check(FindHit(11, &r), "控台：悬停出现播放 / 暂停"); ClickAt(r); Check(gEvents[8] == 1, "控台：点播放暂停 → 背景音乐播放 / 暂停");
  Check(FindHit(12, &r), "控台：悬停出现下一首"); ClickAt(r); Check(gEvents[9] == 1, "控台：点下一首");
  Opt(101, -1, 0, 0);
  // 新增 9 款：开关、切换键、小键盘提醒、悬停时的急停都点得到、事件对（1.4.0：黑胶唱机悬停是音效的暂停 / 继续、急停、主面板）
  {
    const int fresh[9] = {SK_KEYCAP, SK_AURORA, SK_CYBER, SK_POP, SK_CATEAR, SK_COLLAGE, SK_COMIC, SK_VINYL, SK_SEAL};
    int okSw = 0, okKey = 0, okStop = 0, okNum = 0; std::string miss;
    for (int sk : fresh) {
      Reset(LC[0]); SetSkin(sk, 0, 0, 0); Snap(S(out + "\\_probe_new.png"), 100, 0, 0);
      memset((void*)gEvents, 0, sizeof(gEvents));
      if (FindHit(1, &r)) { ClickAt(r); if (gEvents[1] == 1) okSw++; else miss += " 开关" + std::to_string(sk); } else miss += " 无开关" + std::to_string(sk);
      if (FindHit(2, &r)) { ClickAt(r); if (gEvents[2] == 1) okKey++; else miss += " 键" + std::to_string(sk); } else miss += " 无键" + std::to_string(sk);
      TMouse(6, 0, 0, 0); SetHot(1, S("F12"), 1, 0); Snap(S(out + "\\_probe_new.png"), 100, 0, 0);
      if (FindHit(3, &r)) { ClickAt(r); if (gEvents[11] == 1) okNum++; else miss += " 小键盘" + std::to_string(sk); } else miss += " 无小键盘" + std::to_string(sk);
      TMouse(6, 0, 0, 0); Apply("hover", LC[0], sk); Snap(S(out + "\\_probe_new.png"), 100, 0, 0);
      if (FindHit(5, &r)) { ClickAt(r); if (gEvents[6] == 1) okStop++; else miss += " 急停" + std::to_string(sk); } else miss += " 无急停" + std::to_string(sk);
      if (sk == SK_VINYL) { bool b3 = FindHit(13, &r) && FindHit(5, &r) && FindHit(6, &r) && !FindHit(10, &r) && !FindHit(11, &r) && !FindHit(12, &r); Check(b3, "1.4.0 黑胶唱机：悬停是音效的暂停 / 继续、急停、主面板（不再有背景音乐的上一首、播放暂停、下一首）"); if (FindHit(13, &r)) { ClickAt(r); Check(gEvents[15] == 1, "1.4.0 黑胶唱机：点暂停 → 音效暂停或继续"); } }
      Opt(101, -1, 0, 0); TMouse(6, 0, 0, 0); Sleep(300);
    }
    if (!miss.empty()) printf("INFO 新增各款没点到：%s\n", miss.c_str());
    Check(okSw == 9, "新增 9 款：点开关 → 切换快捷键事件");
    Check(okKey == 9, "新增 9 款：点切换键 → 设置切换键事件");
    Check(okNum == 9, "新增 9 款：小键盘提醒里点“点此打开” → 打开小键盘事件");
    Check(okStop == 9, "新增 9 款：悬停后点急停 → 急停事件");
  }
  {  // 悬停时尺寸不变（贴着屏幕下边时不会把窗口往上挤；灵动胶囊按设计在播放时悬停会变宽、向锚点那侧长，不算）
    // 中英德俄阿 5 种语言 × 5 种状态（播放、暂停、背景音乐、两路都在放、闪避）：暂停时的“已暂停”、闪避的字在各语言里长短不同
    std::string moved; int n = 0, all = 0;
    for (int li : {0, 1, 2, 4, 5}) for (const char* st : {"sfx", "paused", "bgm", "both", "duck"}) for (int sk = 2; sk <= SK_COUNT; sk++) {
      SetSkin(sk, 0, 0, 0); Apply(st, LC[li], sk); Snap(S(out + "\\_probe_sz.png"), 100, 0, 0); int w0 = (int)Info(11, 0, 0, 0), h0 = (int)Info(12, 0, 0, 0);
      Opt(101, 1, 0, 0); Snap(S(out + "\\_probe_sz.png"), 100, 0, 0); int w1 = (int)Info(11, 0, 0, 0), h1 = (int)Info(12, 0, 0, 0);
      all++;
      if (h1 != h0 || abs(w1 - w0) > 2) { if (moved.size() < 700) moved += std::string(" ") + LC[li].code + "/" + st + "/第" + std::to_string(sk) + "款" + std::to_string(w0) + "x" + std::to_string(h0) + "→" + std::to_string(w1) + "x" + std::to_string(h1); } else n++;
      Opt(101, 0, 0, 0);
    }
    Opt(101, -1, 0, 0); Reset(LC[0]);
    if (!moved.empty()) printf("INFO 悬停时尺寸变了：%s\n", moved.c_str());
    // 悬停不能把可点的东西藏起来：未设切换键时的“设切换键”、闪避中的“取消闪避”在悬停时仍点得到（原来有几款悬停后换成一排按钮，鼠标移过去点时它们就不见了）
    std::string lost; int okK = 0, okD = 0;
    for (int sk = 1; sk <= SK_COUNT; sk++) {
      SetSkin(sk, 0, 0, 0); Apply("nokey", LC[0], sk); Opt(101, 1, 0, 0); Snap(S(out + "\\_probe_sz.png"), 100, 0, 0);
      if (FindHit(2, &r)) okK++; else lost += " 第" + std::to_string(sk) + "款设键";
      ApplyRoleDuck(LC[0], sk); Opt(101, 1, 0, 0); Snap(S(out + "\\_probe_sz.png"), 100, 0, 0);
      if (FindHit(RoleOf(sk) == 1 ? 7 : 8, &r)) okD++; else lost += " 第" + std::to_string(sk) + "款取消闪避";  // 1.3.0：只管音效的皮肤闪避的是音效那一路（1.4.0：原来这句注释把 else 吞了，点不到时不报是哪一款）
      Opt(101, -1, 0, 0);
    }
    if (!lost.empty()) printf("INFO 悬停时点不到：%s\n", lost.c_str());
    Check(okK == SK_COUNT, "悬停时仍点得到“设切换键”（16 款）");
    Check(okD == SK_COUNT, "悬停时仍点得到“取消闪避”（16 款）");
    // 闪避中悬停：暂停、急停也都还在（“取消闪避”只换掉主面板；磁带、黑胶唱机是多加一个键）
    int okPS = 0; std::string lost2;
    for (int sk = 1; sk <= SK_COUNT; sk++) {
      SetSkin(sk, 0, 0, 0); ApplyRoleDuck(LC[0], sk); Opt(101, 1, 0, 0); Snap(S(out + "\\_probe_sz.png"), 100, 0, 0);
      bool hasPause = FindHit(4, &r) || FindHit(11, &r) || FindHit(13, &r), hasStop = FindHit(5, &r);  // 暂停：全部暂停（控台、组件卡）或音效暂停（只管音效的 14 款）
      if (hasPause && hasStop) okPS++; else lost2 += " 第" + std::to_string(sk) + "款";
      Opt(101, -1, 0, 0);
    }
    if (!lost2.empty()) printf("INFO 闪避中悬停时少了暂停或急停：%s\n", lost2.c_str());
    Check(okPS == SK_COUNT, "闪避中悬停：暂停、急停都还在（16 款）");
    { char what[220]; sprintf(what, "悬停时尺寸不变（除灵动胶囊外 15 款 × 5 种语言 × 5 种状态，共 %d 组；磁带的走带键放在磁带窗口里）", all); Check(n == all, what); }
    {  // 悬停时标题不换字体：曲名字体故意与界面字体不同（选项 115）再量一遍。真机上曲名的文字界面字体没有时（中文界面放韩文歌名等）曲名改用别的字体，
       // 原来新增几款悬停时标题从曲名字体换成界面字体（宽度跟着变、字形也跳一下）；只装了替代字体的 Wine 里两种字体相同，不加这一步查不出
      int n2 = 0, all2 = 0; std::string moved2;
      Opt(115, 1, 0, 0);
      for (int li : {0, 1}) for (const char* st : {"sfx", "bgm", "duck"}) for (int sk = 2; sk <= SK_COUNT; sk++) {
        SetSkin(sk, 0, 0, 0); Apply(st, LC[li], sk); Snap(S(out + "\\_probe_sz.png"), 100, 0, 0); int w0 = (int)Info(11, 0, 0, 0), h0 = (int)Info(12, 0, 0, 0);
        Opt(101, 1, 0, 0); Snap(S(out + "\\_probe_sz.png"), 100, 0, 0); int w1 = (int)Info(11, 0, 0, 0), h1 = (int)Info(12, 0, 0, 0);
        all2++;
        if (h1 != h0 || abs(w1 - w0) > 2) { if (moved2.size() < 500) moved2 += std::string(" ") + LC[li].code + "/" + st + "/第" + std::to_string(sk) + "款" + std::to_string(w0) + "→" + std::to_string(w1); } else n2++;
        Opt(101, 0, 0, 0);
      }
      Opt(115, 0, 0, 0); Opt(101, -1, 0, 0); Reset(LC[0]);
      if (!moved2.empty()) printf("INFO 曲名字体与界面字体不同时，悬停尺寸变了：%s\n", moved2.c_str());
      char what2[200]; sprintf(what2, "悬停时标题不换字体（曲名字体故意与界面字体不同时再量 %d 组，尺寸都不变）", all2);
      Check(n2 == all2, what2);
    }
    TMouse(6, 0, 0, 0); Sleep(300);
  }
  {  // 可点区域（放大后）不小于 24×24；小于 24 时以中心画直径 24 的圆不碰到别的可点区域（WCAG 2.2 的 2.5.8，含间距例外）
    float k = (float)Info(8, 0, 0, 0) / 96.f, mn = 24 * k - .5f; int nAll = 0, nBad = 0; std::string bad;
    for (int sk = 1; sk <= SK_COUNT; sk++) for (const char* st : {"on", "nokey", "numlock", "sfx", "paused", "duck", "hover", "duckhover", "dock"}) {
      bool dh = !strcmp(st, "duckhover"); Apply(dh ? "duck" : st, LC[0], sk); if (dh) Opt(101, 1, 0, 0);
      Snap(S(out + "\\_probe_hit.png"), 100, 0, 0);
      std::vector<RECT> rs; RECT q; for (int i = 0; i < 64 && THit(i, (INT_PTR)&q, 0, 0); i++) rs.push_back(q);
      for (size_t i = 0; i < rs.size(); i++) {
        nAll++; float w = (float)(rs[i].right - rs[i].left), h = (float)(rs[i].bottom - rs[i].top);
        if (w >= mn && h >= mn) continue;
        float cx = (rs[i].left + rs[i].right) / 2.f, cy = (rs[i].top + rs[i].bottom) / 2.f; bool ok = true;
        for (size_t j = 0; j < rs.size() && ok; j++) if (j != i) {
          float dx = std::max(std::max((float)rs[j].left - cx, 0.f), cx - (float)rs[j].right), dy = std::max(std::max((float)rs[j].top - cy, 0.f), cy - (float)rs[j].bottom);
          if (dx * dx + dy * dy < 12 * k * 12 * k) ok = false;
        }
        if (!ok) { nBad++; if (bad.size() < 400) bad += " 第" + std::to_string(sk) + "款/" + st + "/" + std::to_string((int)w) + "x" + std::to_string((int)h); }
      }
      Opt(101, 0, 0, 0); Opt(2, 0, 0, 0);
    }
    Opt(101, -1, 0, 0);
    if (!bad.empty()) printf("INFO 可点区域不够大：%s\n", bad.c_str());
    char what[200]; sprintf(what, "可点区域：16 款 × 9 种状态共 %d 个，都不小于 24×24（或符合间距例外）", nAll);
    Check(nBad == 0 && nAll > 250, what);  // 1.3.0：只管一路的皮肤不再为另一路画按钮，可点区域总数从 300 多降到 270 左右
  }
  {  // 只有图标的“取消闪避”按钮：悬停 0.6 秒后出现提示「取消闪避」（M_UNDUCK＝60）
    Reset(LC[0]); SetSkin(SK_CAPSULE, 0, 0, 0); TInfo(0, 1, S(U8(LC[0].sfx)), 0); TTime(0, 2000, 60000, 70); Duck(1, 0, 0, 0);  // 1.3.0：灵动胶囊只管音效，闪避的是音效那一路
    Snap(S(out + "\\_probe_tip.png"), 100, 0, 0);
    { int hx = 40, hy = 40; CursorTo(hx, hy); TMouse(1, hx, hy, 0); for (int i = 0; i < 40 && (Info(14, 0, 0, 0) & 3) != 3; i++) Sleep(25); Sleep(80); }
    Snap(S(out + "\\_probe_tip.png"), 100, 0, 0);
    bool shown = false;
    if (FindHit(7, &r)) {
      int x = (r.left + r.right) / 2, y = (r.top + r.bottom) / 2; CursorTo(x, y); TMouse(1, x, y, 0);
      HWND tip = nullptr; for (int i = 0; i < 80; i++) { Sleep(50); tip = FindWindowW(L"XhhFloatTip", nullptr); if (tip && IsWindowVisible(tip) && Info(17, 0, 0, 0) >= 0) break; }
      shown = tip && IsWindowVisible(tip) && Info(17, 0, 0, 0) == 60;
      if (!shown) printf("INFO 取消闪避的提示：窗口 %d 序号 %d\n", tip != nullptr, (int)Info(17, 0, 0, 0));
    } else printf("INFO 取消闪避的提示：悬停后没找到取消闪避按钮\n");
    Check(shown, "胶囊：闪避中悬停在“取消闪避”按钮上出现提示「取消闪避」");
    TMouse(6, 0, 0, 0); SetCursorPos(5, 1000); Sleep(400); Duck(0, 0, 0, 0);
  }
  {  // 系统关闭了动画（选项 109，等同系统设置里关闭动画）：音浪、极光、唱片不再按帧率重画；打开时照常
    Opt(100, 0, 0, 0); int moving = 0, still = 0; std::string info;
    for (int sk : {SK_CAPSULE, SK_AURORA, SK_VINYL}) {
      Reset(LC[0]); Opt(100, 0, 0, 0); SetSkin(sk, 0, 0, 0); if (RoleOf(sk) == 1) { TInfo(0, 1, S(U8(LC[0].sfx)), 0); TTime(0, 2000, 60000, 70); } else { TInfo(1, 1, S(U8(LC[0].bgm)), 0); TTime(1, 151000, 235000, 60); } Snap(S(out + "\\_probe_anim.png"), 100, 0, 0);  // 1.3.0：放各款显示的那一路
      Opt(109, 0, 0, 0); Sleep(400); long f0 = (long)Info(15, 0, 0, 0); Sleep(1000); long f1 = (long)Info(15, 0, 0, 0);
      Opt(109, 1, 0, 0); Sleep(400); long f2 = (long)Info(15, 0, 0, 0); Sleep(1000); long f3 = (long)Info(15, 0, 0, 0);
      if (f1 - f0 >= 5) moving++;
      if (f3 - f2 <= 2) still++;
      info += " 第" + std::to_string(sk) + "款 " + std::to_string(f1 - f0) + "/" + std::to_string(f3 - f2);
      Opt(109, 0, 0, 0);
    }
    printf("INFO 每秒重画（打开动画 / 关闭动画）：%s\n", info.c_str());
    Opt(100, 12345, 0, 0); Reset(LC[0]);
    Check(moving == 3, "打开动画时：灵动胶囊、极光弥散、黑胶唱机播放中照常按帧率重画");
    Check(still == 3, "系统关闭了动画：灵动胶囊、极光弥散、黑胶唱机播放中不再按帧率重画");
  }
  // 拖动：位置改变、贴边
  Reset(LC[0]); SetSkin(1, 0, 0, 0); Snap(S(out + "\\_probe7.png"), 100, 0, 0);
  memset((void*)gEvents, 0, sizeof(gEvents));
  // 合成的拖动开始前，先把真实光标移开：前面的点击把它留在悬浮窗上了。窗口在一个不动的真实光标下面移动时，Windows 会给它发带真实光标位置的
  // WM_MOUSEMOVE，拖动时会把窗口拉向真实光标（真机自测出现过 +188,-10）。真实拖动时真实光标就是拖动点，不会这样
  SetCursorPos(5, 1000); Sleep(150);
  {
    INT_PTR x0 = Info(1, 0, 0, 0), y0 = Info(2, 0, 0, 0);
    RECT tr; FindHit(1, &tr); int px = tr.left - 70, py = (tr.top + tr.bottom) / 2;
    // 合成的鼠标消息必须带“相对窗口当前位置”的坐标（真实消息就是这样）：窗口拖动时在动，每次按当前窗口位置换算
    HWND fw = (HWND)Info(9, 0, 0, 0); RECT w0; GetWindowRect(fw, &w0);
    POINT s0 = {w0.left + px, w0.top + py};
    auto MoveScreen = [&](int sx, int sy, int kind) { RECT wr; GetWindowRect(fw, &wr); TMouse(kind, sx - wr.left, sy - wr.top, 0); };
    MoveScreen(s0.x, s0.y, 1); MoveScreen(s0.x, s0.y, 2);
    MoveScreen(s0.x + 60, s0.y + 30, 1); MoveScreen(s0.x + 120, s0.y + 60, 1); MoveScreen(s0.x + 120, s0.y + 60, 3);
    INT_PTR x1 = Info(1, 0, 0, 0), y1 = Info(2, 0, 0, 0);
    printf("INFO 拖动前锚点 %d,%d  拖动后 %d,%d  事件 %ld\n", (int)x0, (int)y0, (int)x1, (int)y1, gEvents[12]);
    Check(gEvents[12] == 1, "拖动：结束时报位置变了");
    if (!(x1 - x0 == 120 && y1 - y0 == 60)) { POINT cp; GetCursorPos(&cp); RECT wr; GetWindowRect(fw, &wr); printf("INFO 拖动没对上：真实光标 %ld,%ld  悬浮窗 %ld,%ld～%ld,%ld\n", cp.x, cp.y, wr.left, wr.top, wr.right, wr.bottom); }
    Check(x1 - x0 == 120 && y1 - y0 == 60, "拖动：锚点正好移动了拖动的距离（120,60）");
  }
  // ---- 隐藏再显示：画面没变也要重新显示；播放中的动画时钟要重新走起来
  // （等到条件成立为止、最多 2～3 秒，不用固定的等待时间：机器忙时界面线程晚一点处理也不算错）
  auto WaitFor = [&](auto cond, int ms) { for (int t = 0; t < ms; t += 25) { if (cond()) return true; Sleep(25); } return (bool)cond(); };
  {
    Reset(LC[0]); SetSkin(1, 0, 0, 0); Opt(100, 0, 0, 0);  // 不冻结时间：看真实的动画
    TInfo(0, 1, S(U8(LC[0].sfx)), 0); TTime(0, 1000, 60000, 70);
    Sleep(300);
    HWND fw = (HWND)Info(9, 0, 0, 0);
    { LONG f0 = (LONG)Info(15, 0, 0, 0); Check(WaitFor([&] { return (LONG)Info(15, 0, 0, 0) - f0 >= 3; }, 2000), "播放中：动画在走"); }
    Show(0, 0, 0, 0);
    Check(WaitFor([&] { return !IsWindowVisible(fw); }, 2000), "隐藏");
    Sleep(100); LONG f2 = (LONG)Info(15, 0, 0, 0); Sleep(300); LONG f3 = (LONG)Info(15, 0, 0, 0);
    Check(f3 == f2, "隐藏时不画");
    Show(1, 0, 0, 0);
    Check(WaitFor([&] { return IsWindowVisible(fw) != 0; }, 3000), "再显示：画面要素没变也会显示出来");
    { LONG f4 = (LONG)Info(15, 0, 0, 0); Check(WaitFor([&] { return (LONG)Info(15, 0, 0, 0) - f4 >= 3; }, 2000), "再显示后动画时钟重新走起来"); }
    Opt(100, 12345, 0, 0); Reset(LC[0]);
    // 时间冻结、画面完全不变时再隐藏、显示：上一帧的要素与这一帧相同，也必须重新显示出来
    Snap(S(out + "\\_static.png"), 100, 0, 0); Sleep(150);
    Show(0, 0, 0, 0);
    Check(WaitFor([&] { return !IsWindowVisible(fw); }, 2000), "画面不变时隐藏");
    Show(1, 0, 0, 0);
    Check(WaitFor([&] { return IsWindowVisible(fw) != 0; }, 3000), "画面不变时再显示：照样显示出来");
  }
  // ---- 字体包后来才下好（字体目录从空变成有）：画面要素没变也要重画；同一个目录再推一次不重画
  if (!fontDir.empty()) {
    Reset(LC[0]); SetSkin(1, 0, 0, 0); Opt(100, 12345, 0, 0);
    SetFontDir(S(""), 0, 0, 0); Sleep(250);
    LONG a0 = (LONG)Info(15, 0, 0, 0);
    SetFontDir(S(fontDir), 0, 0, 0);
    Check(WaitFor([&] { return (LONG)Info(15, 0, 0, 0) > a0; }, 3000), "字体目录变了：重画（换上鸿蒙黑体）");
    Sleep(300); LONG a1 = (LONG)Info(15, 0, 0, 0);  // 等这一轮重画完
    SetFontDir(S(fontDir), 0, 0, 0); Sleep(250);
    Check((LONG)Info(15, 0, 0, 0) == a1, "同一个字体目录再推一次：不重画");
  }
  // ---- 实际用的中文字体（写进易语言日志用）：0 非简体中文 1 鸿蒙黑体 2 没有字体目录 3 目录里没有鸿蒙黑体文件
  if (!fontDir.empty()) {
    Reset(LC[0]); SetSkin(1, 0, 0, 0);
    SetFontDir(S(fontDir), 0, 0, 0); Snap(S(out + "\\_fs1.png"), 100, 0, 0);
    Check(Info(16, 0, 0, 0) == 1, "简体中文＋字体包目录：用鸿蒙黑体（状态 1）");
    SetFontDir(S(""), 0, 0, 0); Snap(S(out + "\\_fs2.png"), 100, 0, 0);
    Check(Info(16, 0, 0, 0) == 2, "没有字体目录：系统字体（状态 2）");
    SetFontDir(S("Z:\\nonexistent_font_dir"), 0, 0, 0); Snap(S(out + "\\_fs3.png"), 100, 0, 0);
    Check(Info(16, 0, 0, 0) == 3, "字体目录里没有鸿蒙黑体文件：系统字体（状态 3）");
    SetLang(S("en"), 0, 0, 0); Snap(S(out + "\\_fs4.png"), 100, 0, 0);
    Check(Info(16, 0, 0, 0) == 0, "非简体中文界面：状态 0");
    SetLang(S("zh-Hans"), 0, 0, 0); SetFontDir(S(fontDir), 0, 0, 0); Snap(S(out + "\\_fs5.png"), 100, 0, 0);
    Check(Info(16, 0, 0, 0) == 1, "换回字体包目录：又用上鸿蒙黑体");
  }
  // ---- 双击按钮只算一下；按着时失去捕获要收尾
  {
    Reset(LC[0]); SetSkin(1, 0, 0, 0); Snap(S(out + "\\_dbl.png"), 100, 0, 0);
    memset((void*)gEvents, 0, sizeof(gEvents));
    RECT sw; FindHit(1, &sw); int x = (sw.left + sw.right) / 2, y = (sw.top + sw.bottom) / 2;
    CursorTo(x, y); TMouse(1, x, y, 0); TMouse(2, x, y, 0); TMouse(3, x, y, 0); TMouse(4, x, y, 0); TMouse(3, x, y, 0);
    Check(gEvents[1] == 1, "双击开关：只切换一次（与原悬浮窗相同）");
    SetCursorPos(5, 1000); Sleep(150);  // 下面是合成的拖动：真实光标先移开（同上面“拖动”一节的原因）
    HWND fw = (HWND)Info(9, 0, 0, 0); RECT w0; GetWindowRect(fw, &w0);
    int px = sw.left - 70, py = y;
    TMouse(1, px, py, 0); TMouse(2, px, py, 0);
    RECT wr; GetWindowRect(fw, &wr); TMouse(1, (w0.left + px + 40) - wr.left, (w0.top + py + 20) - wr.top, 0);
    Check((Info(14, 0, 0, 0) & 16) != 0, "拖动中");
    TMouse(7, 0, 0, 0);
    Check((Info(14, 0, 0, 0) & 24) == 0, "拖动中失去鼠标捕获：结束拖动，不留按下状态");
    Check(gEvents[12] == 1, "失去捕获时也记下新位置");
  }
  // ---- 多线程压测：4 个线程同时改状态，主线程换皮肤
  {
    HANDLE th[4];
    for (int i = 0; i < 4; i++) th[i] = CreateThread(0, 0, Worker, (LPVOID)(INT_PTR)(i + 1), 0, 0);
    for (int k = 0; k < 40; k++) { SetSkin(1 + k % SK_COUNT, 0, 0, 0); Opt(101, k % 3 - 1, 0, 0); Sleep(10); }
    DWORD w = WaitForMultipleObjects(4, th, TRUE, 30000);
    for (int i = 0; i < 4; i++) CloseHandle(th[i]);
    Check(w == WAIT_OBJECT_0, "多线程同时改状态：不卡死");
    Opt(101, -1, 0, 0);
    Check(Snap(S(out + "\\_after_stress.png"), 100, 0, 0) == 1, "压测后照常绘制");
  }
  // ---- 覆盖率图缓存很小（每画一段字都会触发清缓存）时反复画所有皮肤、两种缩放、长名字：不能出错（原来清缓存发生在画字途中，会读到已释放的内存）
  {
    Opt(107, 3, 0, 0);
    bool ok = true;
    for (int rep = 0; rep < 3 && ok; rep++) for (int skin = 1; skin <= SK_COUNT && ok; skin++) {
      SetSkin(skin, 0, 0, 0); Apply(rep == 0 ? "long" : rep == 1 ? "both" : "hover", LC[0], skin);
      for (int pct : {100, 150, 200}) { char p[512]; sprintf(p, "%s\\_cache_%d_%d.png", out.c_str(), skin, pct); if (Snap(S(p), pct, 0, 0) != 1) ok = false; }
    }
    Opt(107, 0, 0, 0); Reset(LC[0]);
    Check(ok && Info(9, 0, 0, 0) != 0, "缓存不断被清时反复画 16 款 × 3 种缩放：照常完成");
  }
  // ---- 大小：当前这款放大到 150%，窗口跟着变大（像素风 125% 归到 150%）；可点范围下限不随大小变小
  {
    SetSkin(1, 0, 0, 0); Reset(LC[0]); Sleep(150);
    auto WidthAfter = [&](int from) { int w = from; WaitUntil([&] { w = (int)Info(11, 0, 0, 0); return w != from; }, 3000); return w; };  // 等这次改动画出来（宽度变了）再读
    int w0 = (int)Info(11, 0, 0, 0);
    Opt(4, 150, 1, 0); int w1 = WidthAfter(w0);
    Opt(4, 80, 1, 0); int w2 = WidthAfter(w1);
    Opt(4, 100, 1, 0); WidthAfter(w2);
    Check(w1 > w0 * 13 / 10 && w2 < w0 && w2 > w0 * 7 / 10, "大小：150% 变大、80% 变小");
    int wq = (int)Info(11, 0, 0, 0); SetSkin(SK_PIXEL, 0, 0, 0); int p0 = WidthAfter(wq);  // 换成像素风的那一帧画出来之后才是它的宽度
    Opt(4, 125, SK_PIXEL, 0); int p1 = WidthAfter(p0);
    Opt(4, 100, SK_PIXEL, 0); WidthAfter(p1); SetSkin(1, 0, 0, 0);
    Check(p1 > p0 * 14 / 10, "像素风：125% 按 150% 画（整数倍像素）");
  }
  // ---- 毛玻璃组件卡的实时模糊：Wine 里接口不可用——退回 92% 的底、不留背景窗口；强制建背景窗口时它要一直正好在卡片下面
  {
    Reset(LC[0]); SetSkin(SK_GLASS, 0, 0, 0); SetCursorPos(5, 1000); Sleep(400);
    if (g_wine) Check(WaitUntil([&] { return Info(23, 0, 0, 0) == -1 && Info(22, 0, 0, 0) == 0; }, 2000), "毛玻璃：实时模糊接口不可用（Wine）时退回不透明的底，不留背景窗口");
    else printf("INFO 毛玻璃：实时模糊 %s\n", Info(23, 0, 0, 0) == 1 ? "在用" : "没用（系统设置关了透明效果、省电模式、高对比度或接口不可用）");
    if (!g_wine && Info(23, 0, 0, 0) == 1) {  // 真机：卡片后面放红白、蓝白条纹，截屏看卡片上没有小格的那条底：左右两半颜色有差＝透出来了；条纹被抹平＝模糊了
      Opt(102, 0, 0, 0); Sleep(300);  // 固定浅色：“卡片回到截图里”按浅色卡片的亮度判断
      HWND fw0 = (HWND)Info(9, 0, 0, 0); RECT f; GetWindowRect(fw0, &f); int W = (int)Info(11, 0, 0, 0), H = (int)Info(12, 0, 0, 0), m = ((f.right - f.left) - W) / 2;
      int cx = f.left + m, cy = f.top + m; float kk = (float)Info(8, 0, 0, 0) / 96.f;
      struct Pat { static LRESULT CALLBACK Proc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
        if (msg == WM_PAINT) { PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps); RECT rc; GetClientRect(h, &rc);
          for (int x = 0; x < rc.right; x += 6) { bool left = x < rc.right / 2; COLORREF c1 = left ? RGB(255, 0, 0) : RGB(0, 0, 255); RECT s = {x, 0, x + 6, rc.bottom}; HBRUSH b = CreateSolidBrush(((x / 6) % 2) ? RGB(255, 255, 255) : c1); FillRect(dc, &s, b); DeleteObject(b); }
          EndPaint(h, &ps); return 0; }
        return DefWindowProcW(h, msg, wp, lp); } };
      WNDCLASSW pc = {}; pc.lpfnWndProc = Pat::Proc; pc.hInstance = GetModuleHandleW(nullptr); pc.lpszClassName = L"XfTestPattern"; RegisterClassW(&pc);
      HWND pat = CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE, L"XfTestPattern", L"", WS_POPUP, cx, cy, W, H, nullptr, nullptr, pc.hInstance, nullptr);
      ShowWindow(pat, SW_SHOWNOACTIVATE); UpdateWindow(pat); Sleep(700);
      int sy = cy + (int)(3 * kk), sx0 = cx + (int)(28 * kk), sx1 = cx + W - (int)(28 * kk), n = sx1 - sx0;  // 卡片顶边和小格之间的那条底（只有卡片底色）
      auto Strip = [&](std::vector<int>& rb, double& hf, double& lum) {  // 截这一行：每个像素的 R−B、相邻像素的平均跳变、平均亮度
        HDC sdc = GetDC(nullptr), mdc = CreateCompatibleDC(sdc); HBITMAP bm = CreateCompatibleBitmap(sdc, n, 1); HGDIOBJ old = SelectObject(mdc, bm);
        BitBlt(mdc, 0, 0, n, 1, sdc, sx0, sy, SRCCOPY | CAPTUREBLT);
        rb.assign(n, 0); hf = 0; lum = 0;
        for (int x = 0; x < n; x++) { COLORREF c = GetPixel(mdc, x, 0); rb[x] = (int)GetRValue(c) - (int)GetBValue(c); lum += (GetRValue(c) + GetGValue(c) + GetBValue(c)) / 3.0; if (x) hf += abs(rb[x] - rb[x - 1]); }
        hf /= (n - 1); lum /= n;
        SelectObject(mdc, old); DeleteObject(bm); DeleteDC(mdc); ReleaseDC(nullptr, sdc); };
      std::vector<int> rb; double hf, lum0; Strip(rb, hf, lum0);
      double l = 0, r = 0; int q = n / 4; for (int x = 0; x < q; x++) { l += rb[x]; r += rb[n - 1 - x]; } l /= q; r /= q;
      printf("INFO 毛玻璃实测：左半（红白条纹）R−B 平均 %.1f，右半（蓝白条纹）%.1f；相邻像素的平均跳变 %.2f（隔着卡片、不模糊时约 7）\n", l, r, hf);
      Check(l - r > 6, "毛玻璃（真机）：卡片后面的颜色透得出来");
      Check(hf < 2.5, "毛玻璃（真机）：透出来的是模糊的（条纹被抹平）");
      DestroyWindow(pat); UnregisterClassW(L"XfTestPattern", pc.hInstance);
      Opt(102, -1, 0, 0);
    }
    Opt(114, 1, 0, 0);
    HWND fw = (HWND)Info(9, 0, 0, 0);
    auto Under = [&]() { HWND gl = (HWND)Info(22, 0, 0, 0); if (!gl || !IsWindowVisible(gl)) return false; RECT g, f; GetWindowRect(gl, &g); GetWindowRect(fw, &f);
      int W = (int)Info(11, 0, 0, 0), H = (int)Info(12, 0, 0, 0), m = ((f.right - f.left) - W) / 2;
      return g.left == f.left + m + 1 && g.top == f.top + m + 1 && g.right == f.left + m + W - 1 && g.bottom == f.top + m + H - 1; };
    auto Gone = [&]() { HWND gl = (HWND)Info(22, 0, 0, 0); return !gl || !IsWindowVisible(gl); };
    Check(WaitUntil(Under, 2000), "毛玻璃：背景窗口正好在卡片下面（四边往里缩 1 像素）");
    { HWND nx = GetWindow(fw, GW_HWNDNEXT); while (nx && !IsWindowVisible(nx)) nx = GetWindow(nx, GW_HWNDNEXT);  // 隐藏着的窗口（提示、画廊）不算
      Check(nx == (HWND)Info(22, 0, 0, 0), "毛玻璃：背景窗口紧挨在悬浮窗下面（中间没有别的可见窗口）"); }
    { RECT tr; FindHit(1, &tr); RECT w0; GetWindowRect(fw, &w0); POINT s0 = {w0.left + tr.left - 70, w0.top + (tr.top + tr.bottom) / 2};  // 合成的拖动（真实光标已移开）
      auto MoveScreen = [&](int sx, int sy, int kind) { RECT wr; GetWindowRect(fw, &wr); TMouse(kind, sx - wr.left, sy - wr.top, 0); };
      MoveScreen(s0.x, s0.y, 1); MoveScreen(s0.x, s0.y, 2); MoveScreen(s0.x + 25, s0.y + 15, 1);
      Check(Under(), "毛玻璃：拖动中背景窗口跟着走");
      MoveScreen(s0.x + 50, s0.y + 30, 1); MoveScreen(s0.x + 50, s0.y + 30, 3); }
    Check(WaitUntil(Under, 2000), "毛玻璃：拖动结束后仍正好在卡片下面");
    SetSkin(1, 0, 0, 0); Check(WaitUntil(Gone, 2000), "毛玻璃：换成别的款时背景窗口藏起来");
    SetSkin(SK_GLASS, 0, 0, 0); Check(WaitUntil(Under, 2000), "毛玻璃：换回组件卡时背景窗口回来");
    Show(0, 0, 0, 0); Check(WaitUntil(Gone, 2000), "毛玻璃：悬浮窗隐藏时背景窗口也藏");
    Show(1, 0, 0, 0); Check(WaitUntil(Under, 3000), "毛玻璃：再显示时背景窗口跟着回来");
    Opt(114, 0, 0, 0); SetSkin(1, 0, 0, 0); SetSkin(SK_GLASS, 0, 0, 0);
    if (g_wine) Check(WaitUntil([&] { return Info(22, 0, 0, 0) == 0; }, 2000), "毛玻璃：不再强制时（接口不可用）背景窗口收掉");
    Reset(LC[0]); SetSkin(1, 0, 0, 0);
  }
  // ---- 置顶变了：毛玻璃背景跟着换层（关掉置顶时收起，打开时回来、仍紧挨在卡片下面）
  {
    Reset(LC[0]); SetSkin(SK_GLASS, 0, 0, 0); Opt(114, 1, 0, 0); SetCursorPos(5, 1000); Sleep(400);
    HWND fw = (HWND)Info(9, 0, 0, 0);
    auto Below = [&](bool top) { HWND gl = (HWND)Info(22, 0, 0, 0); if (!gl) return false; HWND nx = GetWindow(fw, GW_HWNDNEXT); while (nx && !IsWindowVisible(nx)) nx = GetWindow(nx, GW_HWNDNEXT);
      return nx == gl && ((GetWindowLongW(gl, GWL_EXSTYLE) & WS_EX_TOPMOST) != 0) == top && ((GetWindowLongW(fw, GWL_EXSTYLE) & WS_EX_TOPMOST) != 0) == top; };
    Opt(3, 0, 0, 0); Check(WaitUntil([&] { HWND gl = (HWND)Info(22, 0, 0, 0); return (GetWindowLongW(fw, GWL_EXSTYLE) & WS_EX_TOPMOST) == 0 && (!gl || !IsWindowVisible(gl)); }, 2000),
                           "置顶关掉：卡片进普通层，毛玻璃背景收起（实时模糊只在置顶时用，不会盖住卡片）");
    Opt(3, 1, 0, 0); Check(WaitUntil([&] { return Below(true); }, 2000), "置顶打开：毛玻璃背景回来，仍紧挨在卡片下面");
    Opt(114, 0, 0, 0); Reset(LC[0]); SetSkin(1, 0, 0, 0);
  }
  // ---- 1.3.3：右键菜单开着时，悬浮窗（卡片）、毛玻璃背景、提示都不跑到菜单上面（用户反映“有时候右键菜单被悬浮窗挡住”）。
  // 真机上顶层弹出菜单没有所有者（ReactOS 的 menu.c 注明“In Windows, top menu popup is not owned.”），菜单开着时 SetWindowPos(卡片, HWND_TOPMOST) 就把卡片放到菜单、子菜单上面；
  // Wine 建菜单时把悬浮窗当所有者，拥有的窗口总在所有者上面，原样测不出来——这里把菜单的所有者去掉（GWLP_HWNDPARENT 置 0；真机上本来就没有，什么也不做），照真机的层次关系判定。
  // 改前的 1.3.2 在这一节 7 项失败（①～⑤ 各项“不在菜单上面”与“不新建背景”；其余是前提与菜单关掉后的核对）
  {
    Reset(LC[0]); SetSkin(1, 0, 0, 0); Opt(114, 1, 0, 0); SetCursorPos(5, 1000); Sleep(400);
    HWND fw = (HWND)Info(9, 0, 0, 0);
    auto Menus = [&]() { std::vector<HWND> v; for (HWND w = GetTopWindow(nullptr); w; w = GetWindow(w, GW_HWNDNEXT)) { wchar_t c[16] = L""; GetClassNameW(w, c, 16); if (!wcscmp(c, L"#32768") && IsWindowVisible(w)) v.push_back(w); } return v; };
    auto Unown = [&]() { for (HWND m : Menus()) if (GetWindow(m, GW_OWNER)) SetWindowLongPtrW(m, GWLP_HWNDPARENT, 0); };  // 照真机：顶层菜单没有所有者
    auto AboveMenu = [&](HWND x) {  // x 在不在任何一个开着的菜单上面（z 序从上往下数，先碰到 x）
      std::vector<HWND> ms = Menus(); if (!x || ms.empty()) return false;
      for (HWND w = GetTopWindow(nullptr); w; w = GetWindow(w, GW_HWNDNEXT)) { if (w == x) return true; for (HWND m : ms) if (w == m) return false; }
      return false; };
    auto GlassUnder = [&]() { HWND gl = (HWND)Info(22, 0, 0, 0); if (!gl || !IsWindowVisible(gl)) return false; HWND nx = GetWindow(fw, GW_HWNDNEXT); while (nx && !IsWindowVisible(nx)) nx = GetWindow(nx, GW_HWNDNEXT); return nx == gl; };
    auto OpenM = [&]() -> bool {  // 右键弹出菜单；Wine 里偶尔刚弹出就因激活转到桌面而取消（见上面“右键：弹出菜单”的说明），只在 Wine 里重试
      for (int a = 0; a < 3; a++) {
        TMouse(8, (int)Info(11, 0, 0, 0) / 2 + 16, 30, 0);
        if (WaitUntil([&] { return !Menus().empty(); }, 8000)) { Sleep(300); if (!Menus().empty()) { Unown(); return true; } }
        if (!g_wine) return false;
        printf("INFO Wine：菜单没开成或刚开就关了（弹过 %ld 次，上一次开了 %ld 毫秒、选了 %ld），重试\n", (long)Info(91, 0, 0, 0), (long)Info(92, 0, 0, 0), (long)Info(93, 0, 0, 0)); Sleep(300);
      }
      return false; };
    auto CloseM = [&]() { for (int i = 0; i < 6 && !Menus().empty(); i++) { PostMessageW(Menus().back(), WM_KEYDOWN, VK_ESCAPE, 0); Sleep(150); } WaitUntil([&] { return Menus().empty(); }, 3000); Sleep(200); };
    auto Sel = [&](int skin) { PostMessageW(fw, WM_MENUSELECT, MAKEWPARAM(100 + skin, MF_OWNERDRAW | MF_HILITE), 1); };  // 指着皮肤子菜单的第 skin 款（命令 100＋skin）：与鼠标、方向键指着它时系统发来的消息相同
    // ① 在皮肤子菜单里指到「毛玻璃组件卡」：原来新建背景时把卡片提到置顶层最上面
    if (OpenM()) {
      Sel(SK_GLASS); bool pv = WaitUntil([&] { return Info(18, 0, 0, 0) == SK_GLASS; }, 3000); Sleep(300);
      bool open = !Menus().empty();
      Check(pv && open, "1.3.3 菜单开着时指到「毛玻璃组件卡」：悬浮窗临时显示它，菜单还开着");
      Check(open && !AboveMenu(fw) && !AboveMenu((HWND)Info(22, 0, 0, 0)), "1.3.3 预览毛玻璃组件卡时卡片、背景都在菜单下面（原来卡片被提到菜单、子菜单上面）");
      Check(Info(22, 0, 0, 0) == 0, "1.3.3 菜单开着时不新建毛玻璃背景（新建要先摆层次，等菜单关掉）");
      Sel(SK_CONSOLE); WaitUntil([&] { return Info(18, 0, 0, 0) == SK_CONSOLE; }, 2000); Sleep(200);
      Check(!Menus().empty() && !AboveMenu(fw), "1.3.3 接着指到别的款时卡片仍在菜单下面");
      CloseM();
    } else Check(false, "1.3.3 右键菜单弹出（①）");
    Check(WaitUntil([&] { return Info(18, 0, 0, 0) == 0 && Info(22, 0, 0, 0) == 0; }, 3000), "1.3.3 菜单关掉（没选）后恢复原来的皮肤，没有留下背景窗口");
    // ② 当前就是毛玻璃组件卡：菜单开着时卡片与背景之间夹进了别的置顶窗口（真机上弹菜单前的 SetForegroundWindow 把卡片提到置顶层最上面就会这样；Wine 不这样提，这里直接夹进去），随后重画
    SetSkin(SK_GLASS, 0, 0, 0); Check(WaitUntil(GlassUnder, 3000), "1.3.3 组件卡：背景紧挨在卡片下面（前提）");
    WNDCLASSW cc = {}; cc.lpfnWndProc = DefWindowProcW; cc.hInstance = GetModuleHandleW(nullptr); cc.lpszClassName = L"XfTestZCover"; cc.hbrBackground = (HBRUSH)GetStockObject(GRAY_BRUSH); RegisterClassW(&cc);
    HWND cover = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE, L"XfTestZCover", L"", WS_POPUP, 0, 0, 40, 24, nullptr, nullptr, cc.hInstance, nullptr);
    SetWindowPos(cover, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
    if (OpenM()) {
      SetWindowPos(cover, fw, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
      HWND nx = GetWindow(fw, GW_HWNDNEXT); while (nx && !IsWindowVisible(nx)) nx = GetWindow(nx, GW_HWNDNEXT);
      SetHot(1, S("F11"), 0, 0); Sleep(700);  // 换个键名：投递重画（真机上鼠标离开后的计时、每秒的倒计时、动画时钟也会重画）
      bool open = !Menus().empty();
      Check(nx == cover && open, "1.3.3 组件卡：别的置顶窗口夹在卡片与背景之间、重画时菜单还开着（前提）");
      Check(open && !AboveMenu(fw) && !AboveMenu((HWND)Info(22, 0, 0, 0)), "1.3.3 组件卡：菜单开着时重画，卡片、背景都没有跑到菜单上面（原来重排时把卡片提到菜单上面）");
      CloseM();
      Check(WaitUntil(GlassUnder, 2000), "1.3.3 组件卡：菜单关掉后马上补做，背景又紧挨在卡片下面");
    } else Check(false, "1.3.3 右键菜单弹出（②）");
    DestroyWindow(cover); UnregisterClassW(L"XfTestZCover", cc.hInstance); SetHot(1, S("F12"), 0, 0);
    // ③ 菜单开着时来了“置顶”（选项 3；找回悬浮窗也走这一步）：换层推迟到菜单关掉之后
    if (OpenM()) {
      Opt(3, 1, 0, 0); Sleep(500);
      Check(!Menus().empty() && !AboveMenu(fw), "1.3.3 菜单开着时设置顶（选项 3）：卡片不提到菜单上面（推迟到菜单关掉之后）");
      CloseM();
      Check(WaitUntil([&] { return (GetWindowLongW(fw, GWL_EXSTYLE) & WS_EX_TOPMOST) && GlassUnder(); }, 2000), "1.3.3 菜单关掉后补做换层：卡片置顶，背景仍紧挨在下面");
    } else Check(false, "1.3.3 右键菜单弹出（③）");
    Opt(114, 0, 0, 0); SetSkin(1, 0, 0, 0); Sleep(300);
    // ④ 菜单开着时卡片被别的模块挪出了置顶层：每 2 秒的核对不在菜单开着时提回去（提回置顶层最上面就压到菜单上），菜单关掉后再恢复
    if (OpenM()) {
      SetWindowPos(fw, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE); Sleep(2600);
      Check(!Menus().empty() && !AboveMenu(fw), "1.3.3 菜单开着时卡片被挪出置顶层：每 2 秒的核对不把它提到菜单上面");
      CloseM();
      Check(WaitUntil([&] { return (GetWindowLongW(fw, GWL_EXSTYLE) & WS_EX_TOPMOST) != 0; }, 5000), "1.3.3 菜单关掉后照常恢复置顶");  // 1.4.0：3.5 秒 → 5 秒（菜单关掉后靠下一次 2 秒的核对恢复，与“运行中被改动 → 自己恢复”同理：核对周期 2 秒＋机器忙时 3 秒）
    } else Check(false, "1.3.3 右键菜单弹出（④）");
    // ⑤ 菜单开着时请求首次使用提示（提示窗是置顶的）：等菜单关掉再显示
    if (OpenM()) {
      Opt(5, 1, 0, 0); Sleep(500);
      HWND tip = FindWindowW(L"XhhFloatTip", nullptr);
      Check(!Menus().empty() && !(tip && IsWindowVisible(tip) && AboveMenu(tip)), "1.3.3 菜单开着时请求首次使用提示：提示不压在菜单上（等菜单关掉）");
      CloseM();
      Check(WaitUntil([&] { HWND t = FindWindowW(L"XhhFloatTip", nullptr); return t && IsWindowVisible(t) && Info(17, 0, 0, 0) == 9999; }, 3000), "1.3.3 菜单关掉后照常显示首次使用提示");
      TMouse(2, 8, 8, 0); TMouse(3, 8, 8, 0);  // 点一下边距（透明处）：提示消失，不触发任何操作
      WaitUntil([&] { return Info(17, 0, 0, 0) < 0; }, 2000);
    } else Check(false, "1.3.3 右键菜单弹出（⑤）");
    Reset(LC[0]); SetSkin(1, 0, 0, 0); SetCursorPos(5, 1000); Sleep(300);
  }
  // ---- 易语言按编号取的文字（托盘菜单）：32 子菜单标题、33～48 十六款皮肤名、50 预览全部皮肤…——编号是两边的约定，加删文字时编号会挪动，这里核对
  {
    SetLang(S("zh-Hans"), 0, 0, 0); Sleep(100);
    struct { int n; const char* s; } want[] = {
      {32, u8"悬浮窗皮肤"},
      {33, u8"灵动胶囊"}, {34, u8"毛玻璃组件卡"}, {35, u8"全能控台"}, {36, u8"机械键帽"},
      {37, u8"极光弥散"}, {38, u8"ON AIR 霓虹灯牌"}, {39, u8"赛博机甲"}, {40, u8"多巴胺撞色"},
      {41, u8"小红花贴纸"}, {42, u8"猫耳胶囊"}, {43, u8"拼贴手账"}, {44, u8"漫画波普"},
      {45, u8"黑胶唱机"}, {46, u8"Y2K 随身听磁带"}, {47, u8"像素游戏 HUD"}, {48, u8"国潮印章"},
      {50, u8"预览全部皮肤…"}};
    bool ok = true;
    for (auto& w : want) { const char* t = (const char*)Text(w.n, -1, 0, 0); if (!t || strcmp(t, w.s) != 0) { ok = false; printf("INFO 文字 %d：「%s」，应为「%s」\n", w.n, t ? t : "(空)", w.s); } }
    Check(ok, "易语言按编号取的托盘菜单文字（子菜单标题、十六款皮肤名、预览全部皮肤…）都对得上");
    Reset(LC[0]);
  }
  // ---- 首次使用提示在 XF_Start 之前请求（易语言就是这样调的：先交代好选项再启动）——原来请求被丢掉，提示从没出现过；隐藏着时请求：再显示时出现
  {
    SetCursorPos(5, 1000);
    Stop(0, 0, 0, 0); Opt(5, 1, 0, 0);
    Check(Start(300, 200, 0, (INT_PTR)Cb) == 1, "停止后再启动（启动前先请求首次提示）");
    Check(WaitUntil([&] { HWND t = FindWindowW(L"XhhFloatTip", nullptr); return t && IsWindowVisible(t) && Info(17, 0, 0, 0) == 9999; }, 3000), "首次使用提示：在 XF_Start 之前请求也会显示（易语言的调用顺序）");
    TMouse(1, 40, 30, 0); WaitUntil([&] { return Info(17, 0, 0, 0) != 9999; }, 2000); TMouse(6, 0, 0, 0);
    Show(0, 0, 0, 0); WaitUntil([&] { return !IsWindowVisible((HWND)Info(9, 0, 0, 0)); }, 2000);
    Opt(5, 1, 0, 0); Sleep(300); bool none = Info(17, 0, 0, 0) != 9999;
    Show(1, 0, 0, 0);
    Check(none && WaitUntil([&] { return Info(17, 0, 0, 0) == 9999; }, 3000), "首次使用提示：隐藏着时请求不显示，再显示悬浮窗时出现");
    TMouse(1, 40, 30, 0); WaitUntil([&] { return Info(17, 0, 0, 0) != 9999; }, 2000); TMouse(6, 0, 0, 0); Sleep(200);
  }
  // ---- 首次使用提示：显示出来；鼠标一碰悬浮窗就消失
  {
    SetSkin(1, 0, 0, 0); Reset(LC[0]); SetCursorPos(5, 1000); TMouse(6, 0, 0, 0); Sleep(400);  // 真实鼠标先移开：提示设计上一碰悬浮窗就消失
    Opt(5, 1, 0, 0); HWND tip = nullptr; for (int i = 0; i < 40; i++) { Sleep(50); tip = FindWindowW(L"XhhFloatTip", nullptr); if (tip && IsWindowVisible(tip) && Info(17, 0, 0, 0) == 9999) break; }
    Check(tip && IsWindowVisible(tip) && Info(17, 0, 0, 0) == 9999, "首次使用提示：显示出来");
    Sleep(600); Check(Info(17, 0, 0, 0) == 9999, "首次使用提示：不鼠标碰时持续显示（不被重画收掉）");
    TMouse(1, 40, 30, 0); Sleep(150); TMouse(1, 60, 30, 0);
    Check(WaitUntil([&] { return Info(17, 0, 0, 0) != 9999; }, 2000), "鼠标碰到悬浮窗：首次提示消失"); TMouse(6, 0, 0, 0); Sleep(200);
  }
  // ---- 1.5.0：鼠标停在悬浮窗上显示软件账号（XF_SetOption 13；只显示账号本身，同原悬浮窗给各子控件挂的工具提示）。只有图标的按钮照旧提示自己的作用；
  // 空白处、开关、切换键之间移动时账号提示不收不闪；点过之后、停着不动约 5 秒自己收起之后，要移出再回来才再显示；没有账号时不提示（与 1.4.0 一样）。顺带：提示跟上按钮的意思、悬浮窗的大小
  {
    const int TIP_ACC = 9998, K_PAUSE = 15, K_RESUME = 31;  // XF_GetInfo 17：9998＝软件账号；15、31＝文字序号「暂停」「继续」
    HWND fw = (HWND)Info(9, 0, 0, 0);
    auto TipWnd = [&]() { return FindWindowW(L"XhhFloatTip", nullptr); };
    auto TipIs = [&](int key) { HWND t = TipWnd(); return t && IsWindowVisible(t) && Info(17, 0, 0, 0) == key; };
    auto TipTxt = [&]() { const char* q = (const char*)Info(103, 0, 0, 0); return std::string(q ? q : ""); };
    auto Leave = [&]() { SetCursorPos(5, 1000); TMouse(6, 0, 0, 0); WaitUntil([&] { return (Info(14, 0, 0, 0) & 1) == 0; }, 2000); };
    auto Centered = [&]() {  // 账号提示在悬浮窗内容的正上方（上方放不下时在正下方），左右居中
      HWND t = TipWnd(); RECT tr, wr; if (!t || !GetWindowRect(t, &tr) || !GetWindowRect(fw, &wr)) return false;
      int W = (int)Info(11, 0, 0, 0), H = (int)Info(12, 0, 0, 0), m = ((wr.right - wr.left) - W) / 2, top = wr.top + m, bot = top + H;
      int dc = (tr.left + tr.right) / 2 - (wr.left + wr.right) / 2;
      bool ok = abs(dc) <= 2 && ((tr.bottom <= top && tr.bottom >= top - 12) || (tr.top >= bot && tr.top <= bot + 12));
      if (!ok) printf("INFO 账号提示的位置：提示 %ld,%ld-%ld,%ld 悬浮窗 %ld,%ld-%ld,%ld 内容 %d×%d 边距 %d\n", tr.left, tr.top, tr.right, tr.bottom, wr.left, wr.top, wr.right, wr.bottom, W, H, m);
      return ok;
    };
    POINT bp = {0, 0}; RECT fr = {0, 0, 0, 0}, rs = {0, 0, 0, 0}, rk = {0, 0, 0, 0}; int bx = 0, by = 0; bool hasBlank = false, hs = false, hk = false;
    auto Probe = [&]() {  // 同步画一帧（换皮肤、换状态是投递的），再按此刻的布局找空白处、开关、切换键
      Snap(S(out + "\\_acc_probe.png"), 100, 0, 0); GetWindowRect(fw, &fr);
      hasBlank = BlankSpot(&bp); bx = bp.x - fr.left; by = bp.y - fr.top; hs = FindHit(1, &rs); hk = FindHit(2, &rk);
    };
    auto Hover = [&](int x, int y) { CursorTo(x, y); TMouse(1, x, y, 0); };
    SetSkin(1, 0, 0, 0); Reset(LC[0]); SetHot(1, S("F12"), 0, 0); Opt(101, -1, 0, 0); Opt(13, 0, 0, 0); Leave(); Probe();
    Check(hasBlank && hs && hk, "账号：找到空白处、开关、切换键");
    // ① 没有账号：悬停不提示（与 1.4.0 一样）
    Hover(bx, by); bool none = true; for (int i = 0; i < 40; i++) { if (Info(17, 0, 0, 0) != -1) none = false; Sleep(30); }
    Check(none, "账号：没有账号时悬停在空白处不提示（与原来一样）");
    // ② 有账号：约 0.6 秒后显示账号本身，之前不显示；在悬浮窗正上方、左右居中
    Leave(); Opt(13, S("xhh2026a"), 0, 0);
    { DWORD t0 = GetTickCount(); Hover(bx, by); bool shown = WaitUntil([&] { return TipIs(TIP_ACC); }, 3000); DWORD dt = GetTickCount() - t0;
      if (!shown || dt < 550) printf("INFO 账号提示：显示 %d，用时 %lu 毫秒\n", (int)shown, (unsigned long)dt);
      Check(shown && dt >= 550, "账号：鼠标停在空白处约 0.6 秒后显示账号提示（之前不显示）"); }
    Check(TipTxt() == "xhh2026a", "账号：提示里只有账号本身");
    Check(TipIs(TIP_ACC) && Centered(), "账号：提示在悬浮窗正上方（放不下时正下方）、左右居中");
    // ③ 在空白处、开关、切换键之间移动：账号提示一直在（每 30 毫秒看一次，收起再弹出就能看到）
    { bool steady = hs && hk;
      int pts[3][2] = {{(rs.left + rs.right) / 2, (rs.top + rs.bottom) / 2}, {(rk.left + rk.right) / 2, (rk.top + rk.bottom) / 2}, {bx, by}};
      if (steady) for (auto& q : pts) { Hover(q[0], q[1]); for (int i = 0; i < 10; i++) { if (!TipIs(TIP_ACC)) steady = false; Sleep(30); } }
      Check(steady, "账号：在空白处、开关、切换键之间移动，账号提示一直在（不收不闪）"); }
    // ④ 悬停时悬浮窗变大（这一款改为 150%）：账号提示跟着重摆到正中
    { RECT w0; GetWindowRect(fw, &w0); Opt(4, 150, 1, 0);
      bool grew = WaitUntil([&] { RECT w1; GetWindowRect(fw, &w1); return (w1.right - w1.left) > (w0.right - w0.left); }, 2000);
      Check(grew && WaitUntil([&] { return TipIs(TIP_ACC) && Centered(); }, 2000), "账号：悬停时悬浮窗变大：账号提示跟着重摆到正中（原来留在原处）");
      Leave(); Opt(4, 100, 1, 0); WaitUntil([&] { RECT w1; GetWindowRect(fw, &w1); return (w1.right - w1.left) == (w0.right - w0.left); }, 2000); }
    // ⑤ 只有图标的按钮：换成按钮自己的提示；悬停着时暂停了，提示跟着改成「继续」；按钮收起了，提示也收起。
    // 曲名用长的：灵动胶囊的文字列取“曲名”“标签＋剩余时间 / 已暂停”里宽的（曲名最宽 150）。短曲名（掌声雷动）时文字列跟着“剩余 0:58”“已暂停”的字宽变，
    // 暂停后悬停那一排按钮往左挪 13～15 像素（鸿蒙黑体 15、系统字体 13），光标原来在暂停按钮正中，挪完落到按钮右边的缝里；真机上系统会按不动的光标重新判断
    // （窗口变了大小，给它发一条移动消息），鼠标下就成了空白处、换成账号提示——真机自测第一次跑这两项就是这样失败的；Wine 不重新判断，没测出来。
    // 长曲名时文字列按曲名定宽，暂停前后按钮不挪，这两项只看“提示跟上按钮的意思、按钮收起时提示收起”
    TInfo(0, 1, S(U8(LC[0].lng)), 0); TTime(0, 2000, 60000, 70); Probe(); Hover(bx, by); WaitUntil([&] { return (Info(14, 0, 0, 0) & 3) == 3; }, 2000);
    { RECT rp; Snap(S(out + "\\_acc_probe.png"), 100, 0, 0); bool hp = FindHit(13, &rp);
      if (hp) {
        int px = (rp.left + rp.right) / 2, py = (rp.top + rp.bottom) / 2; Hover(px, py);
        Check(WaitUntil([&] { return TipIs(K_PAUSE); }, 3000), "账号：移到只有图标的按钮上：换成按钮自己的提示「暂停」");
        TInfo(0, 2, S(U8(LC[0].lng)), 0); Snap(S(out + "\\_acc_probe.png"), 100, 0, 0); TMouse(1, px, py, 0);  // 同真机：窗口变了大小，系统按不动的光标重新判断一次（Wine 不发这条移动消息，这里补发）
        bool resume = WaitUntil([&] { return TipIs(K_RESUME) && TipTxt() == (const char*)Text(K_RESUME, -1, 0, 0); }, 2000);
        RECT rp2 = {0, 0, 0, 0}; bool same = FindHit(13, &rp2) && EqualRect(&rp, &rp2);  // 前提：暂停前后按钮没挪（光标还在它上面）
        if (!(resume && same)) printf("INFO 暂停后：提示 %d「%s」，暂停按钮 %ld,%ld-%ld,%ld → %ld,%ld-%ld,%ld\n", (int)Info(17, 0, 0, 0), TipTxt().c_str(), rp.left, rp.top, rp.right, rp.bottom, rp2.left, rp2.top, rp2.right, rp2.bottom);
        Check(same && resume, "悬停着时音效暂停了：提示跟着改成「继续」（原来一直是「暂停」）");
        Opt(13, 0, 0, 0);  // 先清掉账号：按钮收起后光标落在空白处时，账号提示照常出现（那是对的），这一项只看对着按钮的提示收没收
        TInfo(0, 0, S(""), 0); Snap(S(out + "\\_acc_probe.png"), 100, 0, 0); TMouse(1, px, py, 0);  // 同上：按钮收起、窗口变小后系统重新判断一次
        bool gone = WaitUntil([&] { return Info(17, 0, 0, 0) == -1 && !IsWindowVisible(TipWnd()); }, 2000);
        if (!gone) printf("INFO 停了以后：提示 %d「%s」\n", (int)Info(17, 0, 0, 0), TipTxt().c_str());
        Check(gone, "停了、悬停的按钮收起：对着它的提示也收起（原来留在原处）");
        Opt(13, S("xhh2026a"), 0, 0);
      } else Check(false, "账号：播放中悬停找到暂停按钮");
    }
    // ⑥ 点过之后在同一片地方移动不再弹；移出再回来照常显示
    Leave(); Probe(); Hover(bx, by); bool was = WaitUntil([&] { return TipIs(TIP_ACC); }, 3000);
    { TMouse(2, bx, by, 0); TMouse(3, bx, by, 0); bool hid = was && Info(17, 0, 0, 0) == -1;
      if (hk) Hover((rk.left + rk.right) / 2, (rk.top + rk.bottom) / 2);
      Hover(bx, by); bool quiet = true; for (int i = 0; i < 40; i++) { if (Info(17, 0, 0, 0) == TIP_ACC) quiet = false; Sleep(30); }
      Check(hid && quiet, "账号：点了一下就收起，在同一片地方移动不再弹（同系统的工具提示）");
      Leave(); Hover(bx, by);
      Check(WaitUntil([&] { return TipIs(TIP_ACC); }, 3000), "账号：移出悬浮窗再回来，账号提示照常显示"); }
    // ⑦ 显示着时账号换了：提示跟着换；变成空：收起
    Opt(13, S("abc12345"), 0, 0);
    bool chg = WaitUntil([&] { return TipIs(TIP_ACC) && TipTxt() == "abc12345"; }, 2000);
    Check(chg, "账号：显示着时账号换了，提示跟着换");
    Opt(13, S(""), 0, 0);
    Check(chg && WaitUntil([&] { return Info(17, 0, 0, 0) == -1 && !IsWindowVisible(TipWnd()); }, 2000), "账号：账号变成空：提示收起");
    // ⑧ 去掉控制字符、双向控制字符（U+202E）与首尾空白（含全角空格）；最多 64 个字
    Leave(); Opt(13, S("  ab\r\ncd\x01\xE2\x80\xAE" "ef\xE3\x80\x80 "), 0, 0); Hover(bx, by);
    Check(WaitUntil([&] { return TipIs(TIP_ACC); }, 3000) && TipTxt() == "abcdef", "账号：去掉控制字符、双向控制字符与首尾空白");
    Opt(13, S(std::string(200, 'a')), 0, 0);
    Check(WaitUntil([&] { return TipIs(TIP_ACC) && TipTxt() == std::string(64, 'a'); }, 2000), "账号：最多 64 个字");
    // ⑨ 皮肤画廊开着时不提示账号
    { F4 GalA = P("XF_TestGallery"); Opt(13, S("xhh2026a"), 0, 0); Leave();
      Opt(7, 1, 0, 0); bool gopen = WaitUntil([&] { return Info(19, 0, 0, 0) == 1; }, 2000);
      TMouse(1, bx, by, 0); bool quiet = true; for (int i = 0; i < 40; i++) { if (Info(17, 0, 0, 0) == TIP_ACC) quiet = false; Sleep(30); }
      if (GalA) GalA(4, 0, 0, 0); WaitUntil([&] { return Info(19, 0, 0, 0) == 0; }, 2000);
      Leave(); Hover(bx, by); bool back = WaitUntil([&] { return TipIs(TIP_ACC); }, 3000);  // 画廊关掉后照常显示：上面没显示确实是因为画廊开着
      Check(gopen && quiet && back, "账号：皮肤画廊开着时不提示账号（关掉后照常显示）"); }
    // ⑩ 贴边收起着：鼠标移上去先展开，展开后才显示账号、对着展开后的悬浮窗
    { Leave(); Opt(2, 2, 0, 0); Snap(S(out + "\\_acc_probe.png"), 100, 0, 0);
      WaitUntil([&] { RECT w1; GetWindowRect(fw, &w1); return w1.right - w1.left < fr.right - fr.left; }, 2000);
      RECT wr; GetWindowRect(fw, &wr); int W = (int)Info(11, 0, 0, 0), H = (int)Info(12, 0, 0, 0), m = ((wr.right - wr.left) - W) / 2;
      Hover(m + W / 2, m + H / 2);
      bool opened = WaitUntil([&] { RECT w1; GetWindowRect(fw, &w1); return w1.right - w1.left > wr.right - wr.left; }, 2000);
      Check(opened && WaitUntil([&] { return TipIs(TIP_ACC) && Centered(); }, 3000), "账号：贴边收起着时先展开，展开后显示账号、对着展开后的悬浮窗");
      Leave(); Opt(2, 0, 0, 0); }
    // ⑪ 停着不动约 10 倍双击时间（系统工具提示的默认：双击时间 500 毫秒时 5 秒；原悬浮窗的工具提示没改过，也是这样）后自己收起；之后在这片地方移动不再弹，移出再回来照常显示
    { Probe(); DWORD ap = 10 * GetDoubleClickTime(); Leave(); Hover(bx, by);
      bool on = WaitUntil([&] { return TipIs(TIP_ACC); }, 3000); DWORD t1 = GetTickCount(); bool still = on;
      while (on && GetTickCount() - t1 + 700 < ap) { if (!TipIs(TIP_ACC)) still = false; Sleep(100); }
      bool gone = still && WaitUntil([&] { return Info(17, 0, 0, 0) == -1 && !IsWindowVisible(TipWnd()); }, 2500); DWORD dt = GetTickCount() - t1;
      if (hs) Hover((rs.left + rs.right) / 2, (rs.top + rs.bottom) / 2);
      Hover(bx, by); bool quiet = true; for (int i = 0; i < 40; i++) { if (Info(17, 0, 0, 0) == TIP_ACC) quiet = false; Sleep(30); }
      if (!(on && still && gone && quiet)) printf("INFO 账号提示自己收起：显示 %d 一直在 %d 收起 %d（%lu 毫秒，应约 %lu）不再弹 %d\n", (int)on, (int)still, (int)gone, (unsigned long)dt, (unsigned long)ap, (int)quiet);
      Check(on && still && gone && quiet, "账号：停着不动约 10 倍双击时间（默认 5 秒）后自己收起，之后在这片地方移动不再弹（同系统的工具提示）");
      Leave(); Hover(bx, by);
      Check(WaitUntil([&] { return TipIs(TIP_ACC); }, 3000), "账号：自己收起后，移出再回来照常显示"); }
    // ⑫ 右键（弹出菜单）同左键：收起，菜单关掉后在这片地方移动不再弹（原来菜单关掉后移到开关、切换键上就又弹出来）
    { Leave(); Hover(bx, by); bool was = WaitUntil([&] { return TipIs(TIP_ACC); }, 3000);
      TMouse(8, bx, by, 0); HWND mw = nullptr; for (int i = 0; i < 100 && !(mw && IsWindowVisible(mw)); i++) { Sleep(50); mw = FindWindowW(L"#32768", nullptr); }
      bool hid = Info(17, 0, 0, 0) == -1;
      if (mw) { PostMessageW(mw, WM_KEYDOWN, VK_ESCAPE, 0); for (int i = 0; i < 40 && IsWindowVisible(mw); i++) Sleep(50); }
      Sleep(150);
      if (hs) Hover((rs.left + rs.right) / 2, (rs.top + rs.bottom) / 2);
      Hover(bx, by); bool quiet = true; for (int i = 0; i < 40; i++) { if (Info(17, 0, 0, 0) == TIP_ACC) quiet = false; Sleep(30); }
      if (!(was && hid && quiet)) printf("INFO 右键后的账号提示：之前显示 %d 菜单 %d 收起 %d 不再弹 %d\n", (int)was, (int)(mw != nullptr), (int)hid, (int)quiet);
      Check(was && hid && quiet, "账号：右键（弹出菜单）同左键：收起，菜单关掉后在这片地方移动不再弹");
      Leave(); }
    // ⑬ 只是跟着悬浮窗重摆（这里改大小到 125%）不重新计时：仍在第一次显示后约 10 倍双击时间收起（原来每重摆一次就重新计时：放着东西时灵动胶囊的宽度随倒计时的字宽变，提示一直不收）
    { Probe(); DWORD ap = 10 * GetDoubleClickTime(); Leave(); Hover(bx, by);
      bool on = WaitUntil([&] { return TipIs(TIP_ACC); }, 3000); DWORD t0 = GetTickCount(); Sleep(1500);
      RECT w0; GetWindowRect(fw, &w0); Opt(4, 125, 1, 0);
      bool moved = WaitUntil([&] { RECT w1; GetWindowRect(fw, &w1); return (w1.right - w1.left) > (w0.right - w0.left); }, 2000) && WaitUntil([&] { return TipIs(TIP_ACC) && Centered(); }, 2000);
      bool gone = on && WaitUntil([&] { return Info(17, 0, 0, 0) == -1; }, (int)(ap + 1000 - (GetTickCount() - t0))); DWORD dt = GetTickCount() - t0;
      if (!(on && moved && gone)) printf("INFO 重摆后的自己收起：显示 %d 重摆 %d 收起 %d（第一次显示后 %lu 毫秒，应约 %lu）\n", (int)on, (int)moved, (int)gone, (unsigned long)dt, (unsigned long)ap);
      Check(on && moved && gone, "账号：只是跟着悬浮窗重摆不重新计时，仍在第一次显示后约 10 倍双击时间收起");
      Leave(); Opt(4, 100, 1, 0); WaitUntil([&] { RECT w1; GetWindowRect(fw, &w1); return (w1.right - w1.left) == (w0.right - w0.left); }, 2000); }
    // ⑭ 悬浮窗左右只挪了 2 像素：提示不动（不跟着倒计时的字宽抖）；挪了 40 像素：跟着摆到正中
    { Probe(); Leave(); Hover(bx, by); bool on = WaitUntil([&] { return TipIs(TIP_ACC); }, 3000);
      LONG ax = (LONG)Info(1, 0, 0, 0), ay = (LONG)Info(2, 0, 0, 0); INT_PTR ar = (Info(5, 0, 0, 0) & 0x100) ? 1 : 0;
      RECT t0r = {0, 0, 0, 0}, w0; GetWindowRect(TipWnd(), &t0r); GetWindowRect(fw, &w0);
      SetPos(ax - 2, ay, ar, 0); bool m2 = WaitUntil([&] { RECT w1; GetWindowRect(fw, &w1); return w1.left == w0.left - 2; }, 2000); Sleep(300);
      RECT t1r = {0, 0, 0, 0}; GetWindowRect(TipWnd(), &t1r); bool still = TipIs(TIP_ACC) && EqualRect(&t0r, &t1r);
      SetPos(ax - 40, ay, ar, 0); bool m40 = WaitUntil([&] { RECT w1; GetWindowRect(fw, &w1); return w1.left == w0.left - 40; }, 2000);
      bool follow = WaitUntil([&] { return TipIs(TIP_ACC) && Centered(); }, 2000);
      if (!(on && m2 && still && m40 && follow)) printf("INFO 小挪动：显示 %d 挪 2 像素 %d 提示不动 %d（%ld,%ld → %ld,%ld）挪 40 像素 %d 跟着摆正 %d\n", (int)on, (int)m2, (int)still, t0r.left, t0r.top, t1r.left, t1r.top, (int)m40, (int)follow);
      Check(on && m2 && still && m40 && follow, "账号：悬浮窗左右只挪 2 像素时提示不动（不随倒计时的字宽抖），挪 40 像素时跟着摆到正中");
      Leave(); SetPos(ax, ay, ar, 0); WaitUntil([&] { RECT w1; GetWindowRect(fw, &w1); return w1.left == w0.left; }, 2000); }
    // ⑮ 只在悬浮窗本身上显示账号：四周的柔和投影也收鼠标（分层窗口不是全透明就收），停在投影上不显示；从悬浮窗移到投影上就收起，移回来照常显示
    { Probe(); Leave(); RECT wr; GetWindowRect(fw, &wr); int W = (int)Info(11, 0, 0, 0), H = (int)Info(12, 0, 0, 0), m = ((wr.right - wr.left) - W) / 2;
      int sx = m / 2, sy = m + H / 2;  // 左边的投影里：窗口之内、悬浮窗本身之外
      Hover(sx, sy); bool none = true; for (int i = 0; i < 40; i++) { if (Info(17, 0, 0, 0) == TIP_ACC) none = false; Sleep(30); }
      Hover(bx, by); bool on = WaitUntil([&] { return TipIs(TIP_ACC); }, 3000);
      TMouse(1, sx, sy, 0); bool hid = WaitUntil([&] { return Info(17, 0, 0, 0) == -1; }, 1000);
      Hover(bx, by); TMouse(1, bx, by, 0); bool back = WaitUntil([&] { return TipIs(TIP_ACC); }, 3000);
      if (!(none && on && hid && back)) printf("INFO 投影上的账号提示：停在投影上不显示 %d 悬浮窗上显示 %d 移到投影上收起 %d 移回来显示 %d（边距 %d）\n", (int)none, (int)on, (int)hid, (int)back, m);
      Check(none && on && hid && back, "账号：只在悬浮窗本身上显示（停在四周的投影上不显示；移到投影上就收起，移回来照常显示）"); Leave(); }
    // ⑯ 阿拉伯语（整体从右往左）：照样只显示账号本身、在悬浮窗正上方居中
    { SetLang(S("ar"), 0, 0, 0); Probe(); Leave(); Hover(bx, by);
      bool ok = WaitUntil([&] { return TipIs(TIP_ACC); }, 3000) && TipTxt() == "xhh2026a" && Centered();
      Check(ok, "账号：阿拉伯语界面（从右往左）照样只显示账号本身、在悬浮窗正上方居中"); Leave(); SetLang(S("zh-Hans"), 0, 0, 0); Probe(); }
    // ⑰ 上方放不下时（悬浮窗挪到工作区最上面）显示在悬浮窗正下方，仍左右居中、不压到悬浮窗上
    { Probe(); Leave(); LONG ax = (LONG)Info(1, 0, 0, 0), ay = (LONG)Info(2, 0, 0, 0); INT_PTR ar = (Info(5, 0, 0, 0) & 0x100) ? 1 : 0;
      RECT wa; SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0); RECT w0; GetWindowRect(fw, &w0);
      SetPos(ax, wa.top, ar, 0); WaitUntil([&] { RECT w1; GetWindowRect(fw, &w1); return w1.top != w0.top; }, 2000); Probe(); Hover(bx, by);
      bool on = WaitUntil([&] { return TipIs(TIP_ACC); }, 3000); RECT tr = {0, 0, 0, 0}, wr; GetWindowRect(TipWnd(), &tr); GetWindowRect(fw, &wr);
      int W = (int)Info(11, 0, 0, 0), H = (int)Info(12, 0, 0, 0), m = ((wr.right - wr.left) - W) / 2;
      bool below = on && tr.top >= wr.top + m + H && Centered();
      if (!below) printf("INFO 上方放不下时：显示 %d 提示 %ld,%ld-%ld,%ld 悬浮窗内容 %ld,%ld-%ld,%ld\n", (int)on, tr.left, tr.top, tr.right, tr.bottom, wr.left + m, wr.top + m, wr.left + m + W, wr.top + m + H);
      Check(below, "账号：上方放不下时显示在悬浮窗正下方、左右居中，不压到悬浮窗上");
      Leave(); SetPos(ax, ay, ar, 0); WaitUntil([&] { RECT w1; GetWindowRect(fw, &w1); return w1.top == w0.top; }, 2000); Probe(); }
    // ⑱ 1.5.0 暂停、继续前后悬浮窗大小与悬停那一排按钮都不变（16 款 × 19 个语种，悬停时、短曲名）。原来第二行的时间那一格跟着“剩余时间”“已暂停”的字宽变：
    // 默认位置（锚点在右，内容变宽时向左长）下 10 款会挪、最多 102 像素（泰语），锚点在左时阿拉伯语有 7 款挪到光标正好落在急停上
    { static const char* LG[] = {"zh-Hans", "zh-Hant", "en", "ja", "ko", "es", "pt-BR", "fr", "de", "id", "th", "vi", "tr", "ar", "ru", "ms", "fil", "hi", "it"};
      int bad = 0, tot = 0; std::string first; Leave();
      for (int hv = 1; hv >= 0; hv--) { Opt(101, hv, 0, 0);  // 悬停时（按钮那一排）与不悬停时都量
      for (int sk = 1; sk <= SK_COUNT; sk++) { SetSkin(sk, 0, 0, 0);
        for (const char* lg : LG) { SetLang(S(lg), 0, 0, 0);
          std::vector<std::pair<int, RECT>> hh[2]; int W2[2] = {0, 0}, H2[2] = {0, 0};
          for (int k2 = 0; k2 < 2; k2++) { TInfo(0, k2 ? 2 : 1, S("ab"), 0); TTime(0, 2000, 60000, 70); Snap(S(out + "\\_pp_probe.png"), 100, 0, 0);
            for (int i = 0; i < 64; i++) { RECT q; INT_PTR id = THit(i, (INT_PTR)&q, 0, 0); if (!id) break; hh[k2].push_back({(int)id, q}); }
            W2[k2] = (int)Info(11, 0, 0, 0); H2[k2] = (int)Info(12, 0, 0, 0); }
          tot++; bool same = W2[0] == W2[1] && H2[0] == H2[1] && hh[0].size() == hh[1].size();
          for (size_t i = 0; same && i < hh[0].size(); i++) same = hh[0][i].first == hh[1][i].first && EqualRect(&hh[0][i].second, &hh[1][i].second);
          if (!same) { bad++; if (first.empty()) { char b[180]; sprintf(b, "第 %d 款 %s %s：宽高 %dx%d → %dx%d", sk, lg, hv ? "悬停" : "不悬停", W2[0], H2[0], W2[1], H2[1]); first = b; } }
        } } }
      if (bad) printf("INFO 暂停前后有变化：%d / %d 组，第一组 %s\n", bad, tot, first.c_str());
      Check(bad == 0, "1.5.0 暂停、继续前后悬浮窗大小与悬停那一排按钮都不变（16 款 × 19 个语种 × 悬停与不悬停；原来默认位置下 10 款会挪，最多 102 像素，有的挪到急停上）");
      Opt(101, -1, 0, 0); SetLang(S("zh-Hans"), 0, 0, 0); SetSkin(1, 0, 0, 0); TInfo(0, 0, S(""), 0); TTime(0, 0, 0, 0); }
    // ⑲ 端到端：灵动胶囊、短曲名（真机自测里按钮挪走的那种），悬停点暂停，宿主改成暂停后，在同一处再点一下——还是暂停 / 继续，不是点空、不是急停
    { TInfo(0, 1, S(U8(LC[0].sfx)), 0); TTime(0, 2000, 60000, 70); Probe(); Hover(bx, by); WaitUntil([&] { return (Info(14, 0, 0, 0) & 3) == 3; }, 2000);
      RECT rp; Snap(S(out + "\\_acc_probe.png"), 100, 0, 0); bool hp = FindHit(13, &rp); bool ok = false; LONG e15 = gEvents[15], e6 = gEvents[6];
      if (hp) { int px = rp.left + (rp.right - rp.left) * 3 / 4, py = (rp.top + rp.bottom) / 2; CursorTo(px, py);  // 点在按钮偏右的地方（用户点哪儿都行）：原来系统字体时按钮挪 13 像素，正中那一点碰巧还在按钮里
        TMouse(1, px, py, 0); TMouse(2, px, py, 0); TMouse(3, px, py, 0);  // 第一下：暂停（宿主收到事件 15）
        TInfo(0, 2, S(U8(LC[0].sfx)), 0); Snap(S(out + "\\_acc_probe.png"), 100, 0, 0); TMouse(1, px, py, 0);  // 宿主改成暂停；同真机：窗口变了大小时系统按不动的光标重新判断一次
        TMouse(2, px, py, 0); TMouse(3, px, py, 0);  // 第二下：同一处
        ok = gEvents[15] == e15 + 2 && gEvents[6] == e6;
        if (!ok) printf("INFO 连点暂停：事件 15 多了 %ld 次、急停多了 %ld 次\n", (long)(gEvents[15] - e15), (long)(gEvents[6] - e6)); }
      Check(hp && ok, "1.5.0 灵动胶囊：点了暂停接着在同一处再点 → 还是暂停 / 继续（原来按钮挪走 15 像素，点空）");
      Leave(); TInfo(0, 0, S(""), 0); TTime(0, 0, 0, 0); }
    // 记录：放着东西（真实时间、倒计时在走）时灵动胶囊的宽度变不变（这台机器的字体下；变的话就是上面两项要防的情况）
    { Opt(100, 0, 0, 0); SetSkin(1, 0, 0, 0); TInfo(0, 1, S("ab"), 0); TTime(0, 0, 65000, 70); std::vector<int> ws;
      for (int i = 0; i < 25; i++) { Sleep(120); int w = (int)Info(11, 0, 0, 0); if (std::find(ws.begin(), ws.end(), w) == ws.end()) ws.push_back(w); }
      printf("INFO 放着东西时灵动胶囊的宽度（3 秒内）：%d 种", (int)ws.size()); for (int w : ws) printf(" %d", w); printf("\n");
      Opt(100, 12345, 0, 0); TInfo(0, 0, S(""), 0); TTime(0, 0, 0, 0); }
    Opt(13, 0, 0, 0); Reset(LC[0]); Leave(); Snap(S(out + "\\_acc_probe.png"), 100, 0, 0);
    Check(Info(17, 0, 0, 0) == -1, "账号：测完清掉账号，后面的测试照旧没有账号");
  }
  // ---- 长曲名滚动：放不下的曲名先停 1.5 秒再滚；系统关闭动画时不滚（显示省略号）
  {
    auto Px = [&](const std::string& p) { HANDLE f = CreateFileW(W8(p).c_str(), GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, 0, 0); DWORD n = 0; std::string s; if (f != INVALID_HANDLE_VALUE) { n = GetFileSize(f, 0); s.resize(n); DWORD r; ReadFile(f, &s[0], n, &r, 0); CloseHandle(f); } return s; };
    SetSkin(1, 0, 0, 0); Apply("long", LC[0], 1); Opt(101, 0, 0, 0);  // 固定为鼠标不在上面：上一项测试的鼠标离开要 0.24 秒后才生效，原来这几张截图有时是悬停的样子
    Opt(108, 500, 0, 0); Snap(S(out + "\\_mq_a.png"), 100, 0, 0);
    Opt(108, 3500, 0, 0); Snap(S(out + "\\_mq_b.png"), 100, 0, 0);
    Opt(108, -1, 0, 0); Opt(109, 1, 0, 0); Snap(S(out + "\\_mq_c.png"), 100, 0, 0);
    Opt(109, 0, 0, 0);
    std::string a1 = Px(out + "\\_mq_a.png"), b1 = Px(out + "\\_mq_b.png"), c1 = Px(out + "\\_mq_c.png");
    Check(!a1.empty() && a1 != b1, "长曲名：滚动开始后画面在动（1.5 秒后与开头不同）");
    Check(!c1.empty() && c1 != a1, "系统关闭动画：不滚，显示省略号");
    Reset(LC[0]);
  }
  // ---- 绘制耗时：每款 60 帧（播放中、100%）
  Reset(LC[0]); Opt(101, -1, 0, 0);
  TInfo(0, 1, S(U8(LC[0].sfx)), 0); TTime(0, 2000, 5000, 70); TInfo(1, 1, S(U8(LC[0].bgm)), 0); TTime(1, 151000, 235000, 60);
  for (int skin = 1; skin <= SK_COUNT; skin++) {
    SetSkin(skin, 0, 0, 0); Snap(S(out + "\\_t.png"), 100, 0, 0);
    INT_PTR us = TRender(60, 0, 0, 0);
    printf("INFO 第 %d 款 每帧 %.2f 毫秒\n", skin, us / 60.0 / 1000.0);
  }
  // ---- 实际 CPU：真实时间（不冻结）、两路都在放、鼠标不在上面，每款量 2 秒界面线程的 CPU 时间（含跳过不变的帧）
  {
    Opt(100, 0, 0, 0); Opt(101, -1, 0, 0);
    HANDLE th = OpenThread(THREAD_QUERY_INFORMATION, FALSE, (DWORD)Info(10, 0, 0, 0));
    for (int skin = 1; skin <= SK_COUNT; skin++) {
      SetSkin(skin, 0, 0, 0);
      TInfo(0, 1, S(U8(LC[0].sfx)), 0); TInfo(1, 1, S(U8(LC[0].bgm)), 0);
      Sleep(300);
      FILETIME c0, e0, k0, u0, c1, e1, k1, u1; GetThreadTimes(th, &c0, &e0, &k0, &u0);
      LONG f0 = (LONG)Info(15, 0, 0, 0);
      for (int i = 0; i < 20; i++) { TTime(0, 1000 + i * 100, 60000, 60); TTime(1, 151000 + i * 100, 235000, 60); Sleep(100); }  // 与易语言一样每 100 毫秒推一次
      GetThreadTimes(th, &c1, &e1, &k1, &u1);
      ULONGLONG cpu = ((((ULONGLONG)k1.dwHighDateTime << 32) | k1.dwLowDateTime) - (((ULONGLONG)k0.dwHighDateTime << 32) | k0.dwLowDateTime)) +
                      ((((ULONGLONG)u1.dwHighDateTime << 32) | u1.dwLowDateTime) - (((ULONGLONG)u0.dwHighDateTime << 32) | u0.dwLowDateTime));
      printf("INFO CPU 第 %d 款：2 秒内界面线程 %.0f 毫秒（约 %.1f%% 单核），贴出 %ld 帧\n", skin, cpu / 10000.0, cpu / 10000.0 / 2000.0 * 100.0, (long)((LONG)Info(15, 0, 0, 0) - f0));
    }
    CloseHandle(th);
    Opt(100, 12345, 0, 0); Reset(LC[0]);
  }
  // ---- 停止、再启动
  Check(Stop(0, 0, 0, 0) == 1, "停止：线程按时退出");
  // ---- 初始位置：原悬浮窗存的坐标按轴判断（≤0 放默认处）；新版坐标即使是负数（多显示器）也照用
  Check(Start(0, 300, 1, (INT_PTR)Cb) == 1, "旧坐标启动（左边 0、顶边 300）");
  Check((Info(5, 0, 0, 0) & 0x100) != 0 && Info(2, 0, 0, 0) == MulDiv(300, (int)Info(8, 0, 0, 0), 96), "旧坐标：左边 ≤0 放到右侧，顶边照用");
  Stop(0, 0, 0, 0);
  Opt(2, 0, 0, 0);  // 易语言启动前交代贴边（这里：不贴边、锚点在左）
  Check(Start(-50, -40, 0, (INT_PTR)Cb) == 1, "新版坐标启动（负数）");
  printf("INFO 新版坐标启动后 锚点 %d,%d 贴边 0x%X\n", (int)Info(1, 0, 0, 0), (int)Info(2, 0, 0, 0), (unsigned)Info(5, 0, 0, 0));
  Check(Info(1, 0, 0, 0) == -50 && Info(2, 0, 0, 0) == -40 && (Info(5, 0, 0, 0) & 0x100) == 0, "新版坐标：负数不当作没存过");
  Stop(0, 0, 0, 0);
  Check(Info(9, 0, 0, 0) == 0, "停止后窗口已销毁");
  Check(Start(100, 100, 0, (INT_PTR)Cb) == 1, "再次启动");
  Check(Snap(S(out + "\\_restart.png"), 100, 0, 0) == 1, "再次启动后能绘制");
  Check(Stop(0, 0, 0, 0) == 1, "再次停止");
  for (int i = 0; i < 5; i++) { Start(100, 100, 0, (INT_PTR)Cb); Stop(0, 0, 0, 0); }
  // ---- 冷启动很慢、XF_Start 等不及返回失败，调用方随即 XF_Stop：之后不能冒出一个没人管的窗口
  Opt(104, 1200, 0, 0); Opt(105, 250, 0, 0);
  Check(Start(100, 100, 0, (INT_PTR)Cb) == 0 && Info(13, 0, 0, 0) == 0x30000, "启动太慢：XF_Start 按时返回失败（原因 等待超时）");
  Check(Stop(0, 0, 0, 0) == 1, "随即叫停：线程按时退出");
  Sleep(300);
  Check(FindWindowW(L"XhhFloatWindow", nullptr) == nullptr && Info(9, 0, 0, 0) == 0, "叫停之后没有留下窗口");
  Opt(104, 0, 0, 0); Opt(105, 0, 0, 0);
  Check(Start(100, 100, 0, (INT_PTR)Cb) == 1 && IsWindowVisible((HWND)Info(9, 0, 0, 0)), "之后照常启动、显示");
  Stop(0, 0, 0, 0);
  Check(Info(9, 0, 0, 0) == 0, "反复启动停止 5 次");
  // ---- 个别系统上画不出字：逐级退路（1.3.1）
  TextFallbackSuite(out);
  HosPackageSuite(out, fontDir);
  // ---- 多显示器与位置记忆（1.2.0）：交界处贴边、按显示布局记位置、找回、贴画面失败重试、工作区变化
  MultiMonitorSuite(out);
  // ---- 窗口被别的模块改动后自己恢复（1.2.0）
  SelfHealSuite();
  printf("SUMMARY 通过 %d 失败 %d\n", passes, fails);
  if (autoMode) {
    printf("\n结果在：%s（截图、contrast\\contrast.tsv、自测日志.txt）\n%s\n按回车键关闭这个窗口。\n", out.c_str(), fails ? "有失败的项：请把「自测日志.txt」发给开发者。" : "全部通过。");
    if (!g_wine) ShellExecuteW(nullptr, L"open", W8(out).c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    getchar();
  }
  return fails ? 1 : 0;
}
