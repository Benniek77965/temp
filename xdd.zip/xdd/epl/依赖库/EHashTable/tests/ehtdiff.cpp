// ehtdiff —— EHashTable.dll 单线程语义回归测试(Windows,32 位)。
// 用法: ehtdiff.exe <EHashTable.dll 路径> [操作数=400000] [轨迹文件(可选)]
// 用固定种子生成同一串随机操作,覆盖全部 41 个导出(含非法句柄 0/负数/已释放、重复释放、覆盖/不覆盖、
// 整数/长整数/文本/字节集(含嵌入 0)键、超过 15 字节的长值、枚举、批量、保存/载入(含篡改、截断)、收缩),
// 逐条记录返回值与取回数据的摘要(不记指针值),最后与 v1.05(10500,随 18.1.x 发布的 MSVC 版)的结果比对。
// v1.06 只改了句柄注册表的加锁,单线程下每一条结果都必须与 v1.05 相同。
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <cstdarg>

#include <windows.h>
#include <shellapi.h>
typedef int(__stdcall* pf_ht_version)();
typedef int(__stdcall* pf_ht_create)(int, int, int);
typedef int(__stdcall* pf_ht_free)(int);
typedef int(__stdcall* pf_ht_iscreated)(int);
typedef int(__stdcall* pf_ht_clear)(int);
typedef int(__stdcall* pf_ht_count)(int);
typedef int(__stdcall* pf_ht_keytype)(int);
typedef int(__stdcall* pf_ht_valtype)(int);
typedef int(__stdcall* pf_ht_lasterror)(int);
typedef int(__stdcall* pf_ht_set_i)(int, int, const uint8_t*, int, int);
typedef int(__stdcall* pf_ht_set_l)(int, long long, const uint8_t*, int, int);
typedef int(__stdcall* pf_ht_set_t)(int, const char*, const uint8_t*, int, int);
typedef int(__stdcall* pf_ht_set_b)(int, const uint8_t*, int, const uint8_t*, int, int);
typedef int(__stdcall* pf_ht_seti_i)(int, int, int, int);
typedef int(__stdcall* pf_ht_seti_l)(int, long long, int, int);
typedef int(__stdcall* pf_ht_seti_t)(int, const char*, int, int);
typedef int(__stdcall* pf_ht_seti_b)(int, const uint8_t*, int, int, int);
typedef int(__stdcall* pf_ht_batch_seti_t)(int, const char* const*, const int*, int, int);
typedef int(__stdcall* pf_ht_batch_geti_t)(int, const char* const*, int*, int);
typedef int(__stdcall* pf_ht_batch_has_t)(int, const char* const*, int);
typedef int(__stdcall* pf_ht_batch_del_t)(int, const char* const*, int);
typedef int(__stdcall* pf_ht_get_i)(int, int, int*, int*);
typedef int(__stdcall* pf_ht_get_l)(int, long long, int*, int*);
typedef int(__stdcall* pf_ht_get_t)(int, const char*, int*, int*);
typedef int(__stdcall* pf_ht_get_b)(int, const uint8_t*, int, int*, int*);
typedef int(__stdcall* pf_ht_has_i)(int, int);
typedef int(__stdcall* pf_ht_has_l)(int, long long);
typedef int(__stdcall* pf_ht_has_t)(int, const char*);
typedef int(__stdcall* pf_ht_has_b)(int, const uint8_t*, int);
typedef int(__stdcall* pf_ht_del_i)(int, int);
typedef int(__stdcall* pf_ht_del_l)(int, long long);
typedef int(__stdcall* pf_ht_del_t)(int, const char*);
typedef int(__stdcall* pf_ht_del_b)(int, const uint8_t*, int);
typedef int(__stdcall* pf_ht_enum_begin)(int);
typedef int(__stdcall* pf_ht_enum_next)(int, int*, int*, int*, int*);
typedef int(__stdcall* pf_ht_keys)(int, int*, int*);
typedef int(__stdcall* pf_ht_vals)(int, int*, int*);
typedef int(__stdcall* pf_ht_save)(int, int*, int*);
typedef int(__stdcall* pf_ht_load)(int, const uint8_t*, int);
typedef int(__stdcall* pf_ht_capacity)(int);
typedef int(__stdcall* pf_ht_shrink)(int);
static pf_ht_version p_ht_version;
static pf_ht_create p_ht_create;
static pf_ht_free p_ht_free;
static pf_ht_iscreated p_ht_iscreated;
static pf_ht_clear p_ht_clear;
static pf_ht_count p_ht_count;
static pf_ht_keytype p_ht_keytype;
static pf_ht_valtype p_ht_valtype;
static pf_ht_lasterror p_ht_lasterror;
static pf_ht_set_i p_ht_set_i;
static pf_ht_set_l p_ht_set_l;
static pf_ht_set_t p_ht_set_t;
static pf_ht_set_b p_ht_set_b;
static pf_ht_seti_i p_ht_seti_i;
static pf_ht_seti_l p_ht_seti_l;
static pf_ht_seti_t p_ht_seti_t;
static pf_ht_seti_b p_ht_seti_b;
static pf_ht_batch_seti_t p_ht_batch_seti_t;
static pf_ht_batch_geti_t p_ht_batch_geti_t;
static pf_ht_batch_has_t p_ht_batch_has_t;
static pf_ht_batch_del_t p_ht_batch_del_t;
static pf_ht_get_i p_ht_get_i;
static pf_ht_get_l p_ht_get_l;
static pf_ht_get_t p_ht_get_t;
static pf_ht_get_b p_ht_get_b;
static pf_ht_has_i p_ht_has_i;
static pf_ht_has_l p_ht_has_l;
static pf_ht_has_t p_ht_has_t;
static pf_ht_has_b p_ht_has_b;
static pf_ht_del_i p_ht_del_i;
static pf_ht_del_l p_ht_del_l;
static pf_ht_del_t p_ht_del_t;
static pf_ht_del_b p_ht_del_b;
static pf_ht_enum_begin p_ht_enum_begin;
static pf_ht_enum_next p_ht_enum_next;
static pf_ht_keys p_ht_keys;
static pf_ht_vals p_ht_vals;
static pf_ht_save p_ht_save;
static pf_ht_load p_ht_load;
static pf_ht_capacity p_ht_capacity;
static pf_ht_shrink p_ht_shrink;

#define ht_version p_ht_version
#define ht_create p_ht_create
#define ht_free p_ht_free
#define ht_iscreated p_ht_iscreated
#define ht_clear p_ht_clear
#define ht_count p_ht_count
#define ht_keytype p_ht_keytype
#define ht_valtype p_ht_valtype
#define ht_lasterror p_ht_lasterror
#define ht_set_i p_ht_set_i
#define ht_set_l p_ht_set_l
#define ht_set_t p_ht_set_t
#define ht_set_b p_ht_set_b
#define ht_seti_i p_ht_seti_i
#define ht_seti_l p_ht_seti_l
#define ht_seti_t p_ht_seti_t
#define ht_seti_b p_ht_seti_b
#define ht_batch_seti_t p_ht_batch_seti_t
#define ht_batch_geti_t p_ht_batch_geti_t
#define ht_batch_has_t p_ht_batch_has_t
#define ht_batch_del_t p_ht_batch_del_t
#define ht_get_i p_ht_get_i
#define ht_get_l p_ht_get_l
#define ht_get_t p_ht_get_t
#define ht_get_b p_ht_get_b
#define ht_has_i p_ht_has_i
#define ht_has_l p_ht_has_l
#define ht_has_t p_ht_has_t
#define ht_has_b p_ht_has_b
#define ht_del_i p_ht_del_i
#define ht_del_l p_ht_del_l
#define ht_del_t p_ht_del_t
#define ht_del_b p_ht_del_b
#define ht_enum_begin p_ht_enum_begin
#define ht_enum_next p_ht_enum_next
#define ht_keys p_ht_keys
#define ht_vals p_ht_vals
#define ht_save p_ht_save
#define ht_load p_ht_load
#define ht_capacity p_ht_capacity
#define ht_shrink p_ht_shrink
static uint64_t g_sum = 1469598103934665603ULL;   // FNV-1a 64 位,累计全部轨迹行(不含版本号那一行)
static long g_lines = 0;
static FILE* g_trace = nullptr;
static void out(const char* fmt, ...) {
    char buf[512];
    va_list ap; va_start(ap, fmt); int n = std::vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
    if (n < 0) return;
    if (n > (int)sizeof buf - 1) n = (int)sizeof buf - 1;
    for (int i = 0; i < n; ++i) { g_sum ^= (uint8_t)buf[i]; g_sum *= 1099511628211ULL; }
    ++g_lines;
    if (g_trace) std::fwrite(buf, 1, (size_t)n, g_trace);
}
static uint32_t rs = 12345;
static uint32_t rnd() { rs ^= rs << 13; rs ^= rs >> 17; rs ^= rs << 5; return rs; }
static int R(int n) { return (int)(rnd() % (uint32_t)n); }

// 只打印内容摘要（FNV-1a），不打印指针
static uint32_t fnv(const void* p, int n) {
    uint32_t h = 2166136261u; const uint8_t* b = (const uint8_t*)p;
    for (int i = 0; i < n; ++i) { h ^= b[i]; h *= 16777619u; }
    return h;
}
static uint32_t memAt(int ptr, int len) { return (ptr && len > 0) ? fnv(reinterpret_cast<const void*>((uintptr_t)(uint32_t)ptr), len) : 0; }

int main(int argc, char** argv) {
    int wargc = 0; LPWSTR* wargv = CommandLineToArgvW(GetCommandLineW(), &wargc);   // DLL 路径按宽字符取:路径里有中文时与系统代码页无关
    HMODULE m = (wargv && wargc > 1) ? LoadLibraryW(wargv[1]) : nullptr; if (!m) { std::printf("load fail\n"); return 2; }
    p_ht_version = (pf_ht_version)GetProcAddress(m, "ht_version"); if (!p_ht_version) { std::printf("missing ht_version\n"); return 2; }
    p_ht_create = (pf_ht_create)GetProcAddress(m, "ht_create"); if (!p_ht_create) { std::printf("missing ht_create\n"); return 2; }
    p_ht_free = (pf_ht_free)GetProcAddress(m, "ht_free"); if (!p_ht_free) { std::printf("missing ht_free\n"); return 2; }
    p_ht_iscreated = (pf_ht_iscreated)GetProcAddress(m, "ht_iscreated"); if (!p_ht_iscreated) { std::printf("missing ht_iscreated\n"); return 2; }
    p_ht_clear = (pf_ht_clear)GetProcAddress(m, "ht_clear"); if (!p_ht_clear) { std::printf("missing ht_clear\n"); return 2; }
    p_ht_count = (pf_ht_count)GetProcAddress(m, "ht_count"); if (!p_ht_count) { std::printf("missing ht_count\n"); return 2; }
    p_ht_keytype = (pf_ht_keytype)GetProcAddress(m, "ht_keytype"); if (!p_ht_keytype) { std::printf("missing ht_keytype\n"); return 2; }
    p_ht_valtype = (pf_ht_valtype)GetProcAddress(m, "ht_valtype"); if (!p_ht_valtype) { std::printf("missing ht_valtype\n"); return 2; }
    p_ht_lasterror = (pf_ht_lasterror)GetProcAddress(m, "ht_lasterror"); if (!p_ht_lasterror) { std::printf("missing ht_lasterror\n"); return 2; }
    p_ht_set_i = (pf_ht_set_i)GetProcAddress(m, "ht_set_i"); if (!p_ht_set_i) { std::printf("missing ht_set_i\n"); return 2; }
    p_ht_set_l = (pf_ht_set_l)GetProcAddress(m, "ht_set_l"); if (!p_ht_set_l) { std::printf("missing ht_set_l\n"); return 2; }
    p_ht_set_t = (pf_ht_set_t)GetProcAddress(m, "ht_set_t"); if (!p_ht_set_t) { std::printf("missing ht_set_t\n"); return 2; }
    p_ht_set_b = (pf_ht_set_b)GetProcAddress(m, "ht_set_b"); if (!p_ht_set_b) { std::printf("missing ht_set_b\n"); return 2; }
    p_ht_seti_i = (pf_ht_seti_i)GetProcAddress(m, "ht_seti_i"); if (!p_ht_seti_i) { std::printf("missing ht_seti_i\n"); return 2; }
    p_ht_seti_l = (pf_ht_seti_l)GetProcAddress(m, "ht_seti_l"); if (!p_ht_seti_l) { std::printf("missing ht_seti_l\n"); return 2; }
    p_ht_seti_t = (pf_ht_seti_t)GetProcAddress(m, "ht_seti_t"); if (!p_ht_seti_t) { std::printf("missing ht_seti_t\n"); return 2; }
    p_ht_seti_b = (pf_ht_seti_b)GetProcAddress(m, "ht_seti_b"); if (!p_ht_seti_b) { std::printf("missing ht_seti_b\n"); return 2; }
    p_ht_batch_seti_t = (pf_ht_batch_seti_t)GetProcAddress(m, "ht_batch_seti_t"); if (!p_ht_batch_seti_t) { std::printf("missing ht_batch_seti_t\n"); return 2; }
    p_ht_batch_geti_t = (pf_ht_batch_geti_t)GetProcAddress(m, "ht_batch_geti_t"); if (!p_ht_batch_geti_t) { std::printf("missing ht_batch_geti_t\n"); return 2; }
    p_ht_batch_has_t = (pf_ht_batch_has_t)GetProcAddress(m, "ht_batch_has_t"); if (!p_ht_batch_has_t) { std::printf("missing ht_batch_has_t\n"); return 2; }
    p_ht_batch_del_t = (pf_ht_batch_del_t)GetProcAddress(m, "ht_batch_del_t"); if (!p_ht_batch_del_t) { std::printf("missing ht_batch_del_t\n"); return 2; }
    p_ht_get_i = (pf_ht_get_i)GetProcAddress(m, "ht_get_i"); if (!p_ht_get_i) { std::printf("missing ht_get_i\n"); return 2; }
    p_ht_get_l = (pf_ht_get_l)GetProcAddress(m, "ht_get_l"); if (!p_ht_get_l) { std::printf("missing ht_get_l\n"); return 2; }
    p_ht_get_t = (pf_ht_get_t)GetProcAddress(m, "ht_get_t"); if (!p_ht_get_t) { std::printf("missing ht_get_t\n"); return 2; }
    p_ht_get_b = (pf_ht_get_b)GetProcAddress(m, "ht_get_b"); if (!p_ht_get_b) { std::printf("missing ht_get_b\n"); return 2; }
    p_ht_has_i = (pf_ht_has_i)GetProcAddress(m, "ht_has_i"); if (!p_ht_has_i) { std::printf("missing ht_has_i\n"); return 2; }
    p_ht_has_l = (pf_ht_has_l)GetProcAddress(m, "ht_has_l"); if (!p_ht_has_l) { std::printf("missing ht_has_l\n"); return 2; }
    p_ht_has_t = (pf_ht_has_t)GetProcAddress(m, "ht_has_t"); if (!p_ht_has_t) { std::printf("missing ht_has_t\n"); return 2; }
    p_ht_has_b = (pf_ht_has_b)GetProcAddress(m, "ht_has_b"); if (!p_ht_has_b) { std::printf("missing ht_has_b\n"); return 2; }
    p_ht_del_i = (pf_ht_del_i)GetProcAddress(m, "ht_del_i"); if (!p_ht_del_i) { std::printf("missing ht_del_i\n"); return 2; }
    p_ht_del_l = (pf_ht_del_l)GetProcAddress(m, "ht_del_l"); if (!p_ht_del_l) { std::printf("missing ht_del_l\n"); return 2; }
    p_ht_del_t = (pf_ht_del_t)GetProcAddress(m, "ht_del_t"); if (!p_ht_del_t) { std::printf("missing ht_del_t\n"); return 2; }
    p_ht_del_b = (pf_ht_del_b)GetProcAddress(m, "ht_del_b"); if (!p_ht_del_b) { std::printf("missing ht_del_b\n"); return 2; }
    p_ht_enum_begin = (pf_ht_enum_begin)GetProcAddress(m, "ht_enum_begin"); if (!p_ht_enum_begin) { std::printf("missing ht_enum_begin\n"); return 2; }
    p_ht_enum_next = (pf_ht_enum_next)GetProcAddress(m, "ht_enum_next"); if (!p_ht_enum_next) { std::printf("missing ht_enum_next\n"); return 2; }
    p_ht_keys = (pf_ht_keys)GetProcAddress(m, "ht_keys"); if (!p_ht_keys) { std::printf("missing ht_keys\n"); return 2; }
    p_ht_vals = (pf_ht_vals)GetProcAddress(m, "ht_vals"); if (!p_ht_vals) { std::printf("missing ht_vals\n"); return 2; }
    p_ht_save = (pf_ht_save)GetProcAddress(m, "ht_save"); if (!p_ht_save) { std::printf("missing ht_save\n"); return 2; }
    p_ht_load = (pf_ht_load)GetProcAddress(m, "ht_load"); if (!p_ht_load) { std::printf("missing ht_load\n"); return 2; }
    p_ht_capacity = (pf_ht_capacity)GetProcAddress(m, "ht_capacity"); if (!p_ht_capacity) { std::printf("missing ht_capacity\n"); return 2; }
    p_ht_shrink = (pf_ht_shrink)GetProcAddress(m, "ht_shrink"); if (!p_ht_shrink) { std::printf("missing ht_shrink\n"); return 2; }
    int ops = argc > 2 ? std::atoi(argv[2]) : 400000;
    const int ver = ht_version();
    if (argc > 3 && wargv && wargc > 3) g_trace = _wfopen(wargv[3], L"wb");
    const int types[] = {3, 4, 5, 6, 7, 10, 11, 99, 0, 1, 12};
    std::vector<int> hs;                 // 句柄池：含有效、已释放、非法
    std::vector<std::string> savedBlobs; // ht_save 取回的数据（用于 ht_load）
    char kbuf[64];
    std::string val, val2;
    for (int op = 0; op < ops; ++op) {
        if (hs.empty() || R(120) == 0) {
            int kt = types[R(11)], vt = types[R(11)];
            int h = ht_create(kt, vt, R(4) == 0 ? R(100) : 0);
            out("%d create %d %d -> %d\n", op, kt, vt, h);
            hs.push_back(h);
            continue;
        }
        int h;
        int pick = R(20);
        if (pick == 0) h = 0; else if (pick == 1) h = -R(5) - 1; else if (pick == 2) h = 999999; else if (pick < 6) h = hs[R((int)hs.size())]; else { int n = (int)hs.size(); h = hs[n - 1 - R(n < 4 ? n : 4)]; }   // 多数操作落在最近创建的几张（大多仍有效）表上
        int ik = R(24) - 4; long long lk = ((long long)R(3) << 33) + R(24);
        std::snprintf(kbuf, sizeof kbuf, "key_%d%s", R(24), R(4) == 0 ? "_long_text_key_xxxxxxxxxx" : "");
        uint8_t bk[12]; int bkl = 1 + R(12); for (int i = 0; i < bkl; ++i) bk[i] = (uint8_t)(R(4) == 0 ? 0 : R(256));
        val.assign((size_t)R(40), 'a' + R(26)); if (!val.empty() && R(3) == 0) val[0] = '\0';
        int noOvr = R(2);
        int o = 0, l = 0, k1 = 0, k2 = 0, v1 = 0, v2 = 0, r = 0;
        switch (R(40)) {
        case 0: if (R(4)) { out("%d skip\n", op); break; } r = ht_free(h); out("%d free %d -> %d\n", op, h, r); break;
        case 1: r = ht_iscreated(h); out("%d iscreated %d -> %d\n", op, h, r); break;
        case 2: r = ht_clear(h); out("%d clear %d -> %d\n", op, h, r); break;
        case 3: out("%d count %d -> %d kt=%d vt=%d le=%d cap=%d\n", op, h, ht_count(h), ht_keytype(h), ht_valtype(h), ht_lasterror(h), ht_capacity(h)); break;
        case 4: r = ht_set_i(h, ik, (const uint8_t*)val.data(), (int)val.size(), noOvr); out("%d set_i %d %d -> %d\n", op, h, ik, r); break;
        case 5: r = ht_set_l(h, lk, (const uint8_t*)val.data(), (int)val.size(), noOvr); out("%d set_l %d -> %d\n", op, h, r); break;
        case 6: r = ht_set_t(h, kbuf, (const uint8_t*)val.data(), (int)val.size(), noOvr); out("%d set_t %d %s -> %d\n", op, h, kbuf, r); break;
        case 7: r = ht_set_b(h, bk, bkl, (const uint8_t*)val.data(), (int)val.size(), noOvr); out("%d set_b %d -> %d\n", op, h, r); break;
        case 8: r = ht_seti_i(h, ik, R(1000), noOvr); out("%d seti_i %d -> %d\n", op, h, r); break;
        case 9: r = ht_seti_l(h, lk, R(1000), noOvr); out("%d seti_l %d -> %d\n", op, h, r); break;
        case 10: r = ht_seti_t(h, kbuf, R(1000), noOvr); out("%d seti_t %d -> %d\n", op, h, r); break;
        case 11: r = ht_seti_b(h, bk, bkl, R(1000), noOvr); out("%d seti_b %d -> %d\n", op, h, r); break;
        case 12: case 13: {
            const char* ks[6]; std::string kk[6]; int vs[6]; int n = R(6) + (R(10) == 0 ? -1 : 0);
            for (int i = 0; i < 6; ++i) { kk[i] = "key_" + std::to_string(R(80)); ks[i] = kk[i].c_str(); vs[i] = R(500); }
            int sub = R(4);
            if (sub == 0) r = ht_batch_seti_t(h, ks, vs, n, noOvr);
            else if (sub == 1) { int outv[6] = {0}; r = ht_batch_geti_t(h, ks, outv, n); out("%d batch_get out=%d,%d,%d\n", op, outv[0], outv[1], outv[2]); }
            else if (sub == 2) r = ht_batch_has_t(h, ks, n);
            else r = ht_batch_del_t(h, ks, n);
            out("%d batch%d %d n=%d -> %d\n", op, sub, h, n, r);
            break; }
        case 14: r = ht_get_i(h, ik, &o, &l); out("%d get_i %d -> %d len=%d data=%08x\n", op, h, r, l, memAt(o, l)); break;
        case 15: r = ht_get_l(h, lk, &o, &l); out("%d get_l %d -> %d len=%d data=%08x\n", op, h, r, l, memAt(o, l)); break;
        case 16: r = ht_get_t(h, kbuf, &o, &l); out("%d get_t %d -> %d len=%d data=%08x\n", op, h, r, l, memAt(o, l)); break;
        case 17: r = ht_get_b(h, bk, bkl, &o, &l); out("%d get_b %d -> %d len=%d data=%08x\n", op, h, r, l, memAt(o, l)); break;
        case 18: out("%d has %d -> %d %d %d %d\n", op, h, ht_has_i(h, ik), ht_has_l(h, lk), ht_has_t(h, kbuf), ht_has_b(h, bk, bkl)); break;
        case 19: out("%d del %d -> %d %d %d %d\n", op, h, ht_del_i(h, ik), ht_del_l(h, lk), ht_del_t(h, kbuf), ht_del_b(h, bk, bkl)); break;
        case 20: case 21: {
            r = ht_enum_begin(h); int n = 0; uint32_t acc = 0;
            while (ht_enum_next(h, &k1, &k2, &v1, &v2) && n < 100000) { acc = acc * 31 + memAt(k1, k2) + memAt(v1, v2) + (uint32_t)k2 * 7 + (uint32_t)v2; ++n; }
            out("%d enum %d -> %d n=%d acc=%08x\n", op, h, r, n, acc); break; }
        case 22: r = ht_keys(h, &o, &l); out("%d keys %d -> %d len=%d data=%08x\n", op, h, r, l, memAt(o, l)); break;
        case 23: r = ht_vals(h, &o, &l); out("%d vals %d -> %d len=%d data=%08x\n", op, h, r, l, memAt(o, l)); break;
        case 24: r = ht_save(h, &o, &l); out("%d save %d -> %d len=%d data=%08x\n", op, h, r, l, memAt(o, l));
            if (r == 1 && o && l > 0) { savedBlobs.emplace_back(reinterpret_cast<const char*>((uintptr_t)(uint32_t)o), (size_t)l); if (savedBlobs.size() > 20) savedBlobs.erase(savedBlobs.begin()); }
            break;
        case 25: {
            std::string blob;
            if (!savedBlobs.empty() && R(5) != 0) blob = savedBlobs[R((int)savedBlobs.size())]; else blob.assign((size_t)R(40), (char)R(256));
            if (!blob.empty() && R(4) == 0) blob[R((int)blob.size())] ^= (char)(1 + R(255));   // 篡改
            if (!blob.empty() && R(6) == 0) blob.resize(blob.size() - 1 - R((int)blob.size())); // 截断
            r = ht_load(h, (const uint8_t*)blob.data(), (int)blob.size()); out("%d load %d len=%d -> %d le=%d cnt=%d\n", op, h, (int)blob.size(), r, ht_lasterror(h), ht_count(h)); break; }
        case 26: r = ht_shrink(h); out("%d shrink %d -> %d cap=%d\n", op, h, r, ht_capacity(h)); break;
        default: r = ht_set_t(h, kbuf, (const uint8_t*)val.data(), (int)val.size(), noOvr); out("%d set_t2 %d -> %d\n", op, h, r); break;
        }
    }
    // 收尾：全部释放两次（第二次应全部返回 0）
    for (int h : hs) out("final free %d -> %d\n", h, ht_free(h));
    for (int h : hs) out("final free2 %d -> %d\n", h, ht_free(h));
    if (g_trace) std::fclose(g_trace);
    const uint64_t EXPECTED = 0xfb73bcc43a2e8b60ULL;   // v1.05(10500,随 18.1.x 发布的 MSVC 版)在同样参数下的结果
    std::printf("ht_version=%d ops=%d 轨迹行数=%ld 校验和=%016llx\n", ver, ops, g_lines, (unsigned long long)g_sum);
    if (ops != 400000) { std::printf("(非默认操作数,只打印校验和,不判定)\n"); return 0; }
    bool ok = g_sum == EXPECTED;
    std::printf("%s\n", ok ? "RESULT: PASS(单线程语义与 v1.05 完全一致)" : "RESULT: FAIL(与 v1.05 的结果不同)");
    return ok ? 0 : 3;
}
