#!/usr/bin/env bash
# 一键：用 MinGW 按 build_EHashTable_mingw.bat 同样的参数编译 EHashTable.dll → 检查位数 / 导出 / 导入
#       → 编译两个测试程序 → 在 32 位 Wine 里跑多线程并发测试（ehtstress，5 轮）与单线程语义测试（ehtdiff）。
# 需要：i686-w64-mingw32-g++（posix 线程版优先）、wine32（WINEARCH=win32 的前缀）。
# 用法：./run_all.sh [另一份 EHashTable.dll 的路径]
#       不带参数时测本目录上一级 src/hashtable.cpp 现编出来的 DLL；带参数时同样的测试再对那份 DLL 跑一遍（例如旧版，用来对比）。
# 退出码：0=全部通过；1=编译或检查失败；2=测试失败。
set -u
cd "$(dirname "$0")"
ROOT=..
OUT=_build
mkdir -p "$OUT"

CXX=i686-w64-mingw32-g++-posix
command -v "$CXX" >/dev/null 2>&1 || CXX=i686-w64-mingw32-g++
OBJDUMP=i686-w64-mingw32-objdump

echo "== 编译 EHashTable.dll（与 build_EHashTable_mingw.bat 同参数）"
"$CXX" -std=c++17 -O3 -DNDEBUG -fno-rtti -flto -shared -I "$ROOT/third_party" "$ROOT/src/hashtable.cpp" \
    -o "$OUT/EHashTable.dll" -static -static-libgcc -static-libstdc++ -Wl,--kill-at -Wl,--strip-all || exit 1
"$OBJDUMP" -f "$OUT/EHashTable.dll" | grep -q "architecture: i386" || { echo "不是 32 位 DLL"; exit 1; }
NEXP=$("$OBJDUMP" -p "$OUT/EHashTable.dll" | grep -cE '\] ht_[a-z_]+$')
NDEC=$("$OBJDUMP" -p "$OUT/EHashTable.dll" | grep -cE 'ht_.*@[0-9]')
echo "   导出 ht_* = $NEXP 个（应为 41），带 @ 修饰的 = $NDEC 个（应为 0）"
[ "$NEXP" = 41 ] && [ "$NDEC" = 0 ] || exit 1
echo "   依赖：$("$OBJDUMP" -p "$OUT/EHashTable.dll" | grep 'DLL Name' | awk '{print $3}' | tr '\n' ' ')"

echo "== 编译测试程序"
"$CXX" -std=c++17 -O2 -Wall ehtstress.cpp -o "$OUT/ehtstress.exe" -static -lshell32 || exit 1
"$CXX" -std=c++17 -O2 -Wall ehtdiff.cpp -o "$OUT/ehtdiff.exe" -static -lshell32 || exit 1

export WINEDEBUG=-all
export WINEARCH=win32
export WINEPREFIX="${WINEPREFIX:-$HOME/.wine32}"
[ -d "$WINEPREFIX" ] || wineboot -i >/dev/null 2>&1

FAIL=0
run_suite() {   # $1 = DLL 路径
    local dll="$1" i line
    echo "== 测试 $dll"
    for i in 1 2 3 4 5; do
        line=$(wine "$OUT/ehtstress.exe" "$dll" 8 20000 120 2>&1 | tr -d '\r' | tail -2 | tr '\n' ' ')
        echo "   并发第 $i 轮：$line"
        case "$line" in *"RESULT: OK"*) ;; *) FAIL=1 ;; esac
    done
    line=$(wine "$OUT/ehtdiff.exe" "$dll" 2>&1 | tr -d '\r' | tr '\n' ' ')
    echo "   单线程语义：$line"
    case "$line" in *"RESULT: PASS"*) ;; *) FAIL=1 ;; esac
}

run_suite "$OUT/EHashTable.dll"
NEWFAIL=$FAIL
if [ $# -ge 1 ]; then
    FAIL=0
    run_suite "$1"
    echo "   （对比用的那份 DLL 测出问题属预期：v1.05 及以前的注册表不加锁）"
fi
wineserver -k >/dev/null 2>&1
if [ "$NEWFAIL" = 0 ]; then echo "== 全部通过"; exit 0; else echo "== 有测试未通过"; exit 2; fi
