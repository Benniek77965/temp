// ehtstress —— EHashTable.dll 多线程并发回归测试(Windows,32 位)。
// 用法: ehtstress.exe <EHashTable.dll 路径> [工作线程数=8] [每线程轮数=20000] [看门狗秒数=300]
// 模拟 加载全部音效:线程池里几个任务同时 创建 → 写入 → 查询 → 释放 各自的局部表,另一个线程不停查询一张全局表。
// 每个线程只用自己的表(即 DLL 注释里的"每线程一张表")。v1.05 的句柄注册表不加锁,这样用也会出错;v1.06 起不应再出错。
// 卡住:v1.05 的注册表链表被改坏后可能成环,查找或进程退出时会死循环 —— 本程序自带看门狗,
//       超过限定时间没跑完就报 RESULT: HANG 并结束自己;跑完后直接 TerminateProcess 退出,不再执行 DLL 的卸载析构
//       (旧 DLL 在那里也可能死循环),结果只看输出的 RESULT 行与退出码(0=OK,3=ANOMALY,4=HANG,其它=崩溃)。
// 检测:重号(同一句柄同时在两个线程手里)、表里条数不对(查不到自己的表=lost / 查到别的表=foreign)、取值失败、
//       释放自己的句柄失败、全局表查询落空或条数变化;进程崩溃(无结果行,退出码非 0/3)也算失败。
#include <windows.h>
#include <shellapi.h>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <thread>
#include <vector>

typedef int(__stdcall* fn_create)(int, int, int);
typedef int(__stdcall* fn_free)(int);
typedef int(__stdcall* fn_count)(int);
typedef int(__stdcall* fn_set_t)(int, const char*, const unsigned char*, int, int);
typedef int(__stdcall* fn_has_t)(int, const char*);
typedef int(__stdcall* fn_get_t)(int, const char*, int*, int*);
typedef int(__stdcall* fn_version)();

static fn_create p_create; static fn_free p_free; static fn_count p_count;
static fn_set_t p_set_t; static fn_has_t p_has_t; static fn_get_t p_get_t; static fn_version p_version;

enum { T_BOOL = 7, T_TEXT = 10 };
static const int MAXH = 1 << 22;
static std::atomic<int>* g_owner;
static std::atomic<long> g_dup{0}, g_badCount{0}, g_badFree{0}, g_badVal{0}, g_createFail{0}, g_lost{0}, g_foreign{0};
static std::atomic<bool> g_stop{false};

static void worker(int tid, int iters) {
    char key[64];
    std::string val;
    for (int it = 0; it < iters; ++it) {
        int hs[3];
        int expect[3] = {28 + (it % 7), 3 + (it % 5), 60 + (it % 50)};
        for (int k = 0; k < 3; ++k) {
            hs[k] = p_create(T_TEXT, k == 1 ? T_BOOL : T_TEXT, 0);
            if (hs[k] <= 0) { g_createFail++; hs[k] = 0; continue; }
            if (hs[k] < MAXH) { int z = 0; if (!g_owner[hs[k]].compare_exchange_strong(z, tid + 1)) g_dup++; }
        }
        for (int k = 0; k < 3; ++k) {
            if (!hs[k]) continue;
            for (int i = 0; i < expect[k]; ++i) {
                std::snprintf(key, sizeof key, "t%d_i%d_k%d_%d", tid, it, k, i);
                val.assign("VAL_"); val += key; val += "_abcdefghijklmnop";
                p_set_t(hs[k], key, reinterpret_cast<const unsigned char*>(val.data()), (int)val.size(), 0);
            }
        }
        for (int k = 0; k < 3; ++k) {
            if (!hs[k]) continue;
            int c = p_count(hs[k]);
            if (c != expect[k]) { g_badCount++; if (c == -1) g_lost++; else g_foreign++; }   // -1=注册表里找不到这个句柄; 其它=查到的是别的表
            std::snprintf(key, sizeof key, "t%d_i%d_k%d_%d", tid, it, k, expect[k] / 2);
            int p = 0, l = 0;
            if (p_get_t(hs[k], key, &p, &l) != 1 || l < 4) g_badVal++;
        }
        for (int k = 0; k < 3; ++k) {
            if (!hs[k]) continue;
            if (hs[k] < MAXH) g_owner[hs[k]].store(0);
            if (p_free(hs[k]) != 1) g_badFree++;
        }
    }
}

int main(int argc, char** argv) {
    if (argc < 2) { std::printf("用法: ehtstress.exe <EHashTable.dll 路径> [工作线程数=8] [每线程轮数=20000] [看门狗秒数=300]\n"); return 2; }
    int wargc = 0; LPWSTR* wargv = CommandLineToArgvW(GetCommandLineW(), &wargc);   // DLL 路径按宽字符取:路径里有中文时与系统代码页无关
    HMODULE m = (wargv && wargc > 1) ? LoadLibraryW(wargv[1]) : nullptr;
    if (!m) { std::printf("载入 DLL 失败,错误码 %lu\n", GetLastError()); return 2; }
    p_create = (fn_create)GetProcAddress(m, "ht_create");
    p_free = (fn_free)GetProcAddress(m, "ht_free");
    p_count = (fn_count)GetProcAddress(m, "ht_count");
    p_set_t = (fn_set_t)GetProcAddress(m, "ht_set_t");
    p_has_t = (fn_has_t)GetProcAddress(m, "ht_has_t");
    p_get_t = (fn_get_t)GetProcAddress(m, "ht_get_t");
    p_version = (fn_version)GetProcAddress(m, "ht_version");
    if (!p_create || !p_free || !p_count || !p_set_t || !p_has_t || !p_get_t || !p_version) { std::printf("DLL 里缺少需要的导出函数\n"); return 2; }
    int threads = argc > 2 ? std::atoi(argv[2]) : 8;
    int iters = argc > 3 ? std::atoi(argv[3]) : 20000;
    static int s_wd = argc > 4 ? std::atoi(argv[4]) : 300;
    if (s_wd <= 0) s_wd = 300;
    std::thread([] {                                   // 看门狗:正常几秒到几十秒跑完,超过限定秒数视为卡住
        Sleep((DWORD)s_wd * 1000);
        std::printf("RESULT: HANG(超过 %d 秒没跑完:注册表链表可能已被改成环,查找陷入死循环)\n", s_wd);
        std::fflush(stdout);
        TerminateProcess(GetCurrentProcess(), 4);
    }).detach();
    g_owner = new std::atomic<int>[MAXH];
    for (int i = 0; i < MAXH; ++i) g_owner[i].store(0, std::memory_order_relaxed);

    int gh = p_create(T_TEXT, T_BOOL, 0);
    unsigned char one[4] = {1, 0, 0, 0};
    for (int i = 0; i < 500; ++i) { char k[32]; std::snprintf(k, sizeof k, "global_%d", i); p_set_t(gh, k, one, 4, 0); }

    std::vector<std::thread> ts;
    for (int t = 0; t < threads; ++t) ts.emplace_back(worker, t, iters);
    long miss = 0, loops = 0;
    std::thread reader([&] {
        char k[32];
        while (!g_stop.load()) {
            for (int i = 0; i < 500; i += 7) { std::snprintf(k, sizeof k, "global_%d", i); if (p_has_t(gh, k) != 1) miss++; }
            loops++;
        }
    });
    for (auto& t : ts) t.join();
    g_stop = true;
    reader.join();
    int gc = p_count(gh);
    std::printf("ht_version=%d 线程=%d 每线程轮数=%d | 重号=%ld 条数不对=%ld(查不到自己的表=%ld 查到别的表=%ld) 取值失败=%ld 释放自己的句柄失败=%ld 创建失败=%ld | 全局表查询落空=%ld/%ld轮 全局表条数=%d(应为500)\n",
                p_version(), threads, iters, g_dup.load(), g_badCount.load(), g_lost.load(), g_foreign.load(), g_badVal.load(), g_badFree.load(), g_createFail.load(), miss, loops, gc);
    bool ok = !g_dup && !g_badCount && !g_badVal && !g_badFree && !g_createFail && !miss && gc == 500;
    std::printf("%s\n", ok ? "RESULT: OK(未发现异常)" : "RESULT: ANOMALY(注册表被改坏)");
    std::fflush(stdout);
    TerminateProcess(GetCurrentProcess(), ok ? 0 : 3);   // 不走 DLL 卸载析构(见文件开头说明)
    return ok ? 0 : 3;
}
