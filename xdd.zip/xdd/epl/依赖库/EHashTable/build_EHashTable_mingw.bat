@echo off
setlocal

REM ============================================================
REM  EHashTable.dll - MinGW i686 build script
REM  32-bit / __stdcall / undecorated exports / static runtime
REM  Output: EHashTable.dll next to this script
REM  Minimum OS target: Windows 7 (imports only kernel32+msvcrt)
REM
REM  Requires: MinGW-w64 *i686* g++ on PATH
REM    MSYS2:  pacman -S mingw-w64-i686-gcc  then run this from
REM            the "MSYS2 MINGW32" shell, or add
REM            C:\msys64\mingw32\bin to PATH
REM    Also OK: any standalone i686-w64-mingw32 toolchain
REM  NOTE: a plain x86_64 MinGW (without multilib) can NOT build
REM        this 32-bit DLL - the script will refuse it.
REM
REM  Place this script in the project root (next to src\ and
REM  third_party\). No downloads, no CMake, no git needed.
REM ============================================================

set "ROOT=%~dp0"
set "BUILDDIR=%ROOT%_EHashTable_build\mingw"
set "OUTDLL=%ROOT%EHashTable.dll"

echo ============================================================
echo   EHashTable.dll x86 build [MinGW]
echo ============================================================

REM --- Check project layout ---
if not exist "%ROOT%src\hashtable.cpp" (
    echo [BUILD] ERROR: src\hashtable.cpp not found.
    echo [BUILD] Put this script in the project root directory.
    pause & exit /b 1
)
if not exist "%ROOT%third_party\ankerl\unordered_dense.h" (
    echo [BUILD] ERROR: third_party\ankerl\unordered_dense.h not found.
    pause & exit /b 1
)

REM --- Check compiler ---
where g++ >nul 2>nul
if errorlevel 1 (
    echo [BUILD] ERROR: g++ not found on PATH. Need MinGW-w64 i686.
    pause & exit /b 1
)

REM --- Check compiler target: must be 32-bit Windows ---
set "MACHINE="
for /f %%t in ('g++ -dumpmachine 2^>nul') do set "MACHINE=%%t"
echo [BUILD] g++ target: %MACHINE%
echo %MACHINE% | findstr /i "x86_64 aarch64 arm64 msys cygwin" >nul
if not errorlevel 1 (
    echo [BUILD] ERROR: this g++ targets %MACHINE% - it cannot produce
    echo [BUILD] the 32-bit DLL that YiYuYan requires.
    echo [BUILD] Install the i686 toolchain, e.g. MSYS2 MINGW32 shell:
    echo [BUILD]     pacman -S mingw-w64-i686-gcc
    pause & exit /b 1
)
echo %MACHINE% | findstr /i "i686 i386 mingw32" >nul
if errorlevel 1 echo [BUILD] WARNING: unrecognized target, will verify the DLL after build.

REM --- Prepare build dir ---
if exist "%BUILDDIR%" rmdir /s /q "%BUILDDIR%"
mkdir "%BUILDDIR%"
pushd "%BUILDDIR%"

REM --- Compile (same flags as the project's build.sh) ---
echo [BUILD] Compiling...
g++ -std=c++17 -O3 -DNDEBUG -fno-rtti -flto -shared ^
    -I "%ROOT%third_party" ^
    "%ROOT%src\hashtable.cpp" ^
    -o EHashTable.dll ^
    -static -static-libgcc -static-libstdc++ ^
    -Wl,--kill-at -Wl,--strip-all
if errorlevel 1 (
    popd
    echo [BUILD] ERROR: Compilation failed.
    pause & exit /b 1
)
if not exist EHashTable.dll (
    popd
    echo [BUILD] ERROR: EHashTable.dll not produced.
    pause & exit /b 1
)

REM --- Verify PE machine type = i386 [works without binutils] ---
powershell -NoProfile -Command "$b=[IO.File]::ReadAllBytes('EHashTable.dll');$o=[BitConverter]::ToInt32($b,60);exit [int]([BitConverter]::ToUInt16($b,$o+4) -ne 0x14c)"
if errorlevel 1 (
    popd
    echo [BUILD] ERROR: produced DLL is NOT 32-bit x86. Wrong toolchain?
    pause & exit /b 1
)
echo [BUILD] Verified: PE machine = i386 [32-bit]

REM --- Verify exports are undecorated [needs objdump, usually bundled] ---
where objdump >nul 2>nul
if errorlevel 1 (
    echo [BUILD] INFO: objdump not found, skipping export-name check.
    goto :collect
)
objdump -p EHashTable.dll | findstr /r /c:"ht_.*@[0-9]" >nul
if not errorlevel 1 (
    popd
    echo [BUILD] ERROR: exports are still stdcall-decorated - kill-at failed.
    pause & exit /b 1
)
objdump -p EHashTable.dll | findstr /c:"ht_version" >nul
if errorlevel 1 (
    popd
    echo [BUILD] ERROR: export ht_version missing.
    pause & exit /b 1
)
for /f %%c in ('objdump -p EHashTable.dll ^| findstr /r /c:"ht_" ^| find /c /v ""') do set "NEXP=%%c"
echo [BUILD] Verified: %NEXP% undecorated ht_* exports
echo [BUILD] --- DLL dependencies ---
objdump -p EHashTable.dll | findstr /i /c:"DLL Name"

:collect
popd
copy /y "%BUILDDIR%\EHashTable.dll" "%OUTDLL%" >nul

echo.
echo [BUILD] OK: %OUTDLL%
for %%F in ("%OUTDLL%") do echo [BUILD] Size: %%~zF bytes
echo.
echo To clean build cache, delete: %ROOT%_EHashTable_build
pause
