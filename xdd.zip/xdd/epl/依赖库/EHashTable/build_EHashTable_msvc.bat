@echo off
setlocal

REM ============================================================
REM  EHashTable.dll - MSVC x86 build script
REM  32-bit / __stdcall / undecorated exports via auto-generated
REM  .def / static CRT [/MT] - final DLL imports KERNEL32 only
REM  Output: EHashTable.dll next to this script
REM  Minimum OS target: Windows 7 SP1
REM
REM  Can be run from ANY command prompt [auto-detects VS]
REM  Requires: Visual Studio 2017 15.7+ / 2019 / 2022 with the
REM            "Desktop development with C++" workload
REM            [C++17 is required by the source]
REM
REM  Place this script in the project root (next to src\ and
REM  third_party\). No downloads, no CMake, no git needed.
REM ============================================================

set "ROOT=%~dp0"
set "BUILDDIR=%ROOT%_EHashTable_build\msvc"
set "OUTDLL=%ROOT%EHashTable.dll"

echo ============================================================
echo   EHashTable.dll x86 build [MSVC]
echo ============================================================

REM --- Check project layout ---
if not exist "%ROOT%src\hashtable.cpp" (
    echo [BUILD] ERROR: src\hashtable.cpp not found.
    echo [BUILD] Put this script in the project root directory.
    pause & exit /b 1
)
if not exist "%ROOT%third_party\ankerl\unordered_dense.h" (
    echo [BUILD] ERROR: third_party\ankerl\unordered_dense.h not found.
    pause & exit /b 1
)

REM --- If cl.exe is already available AND targets x86, use it ---
REM Do NOT parse localized `cl` banner text (e.g. "for x86").
REM VS developer prompts expose the target architecture reliably via
REM VSCMD_ARG_TGT_ARCH.
where cl.exe >nul 2>nul
if errorlevel 1 goto :find_vs
if /i "%VSCMD_ARG_TGT_ARCH%"=="x86" (
    echo [BUILD] Existing x86 MSVC environment detected.
    goto :do_build
)
echo [BUILD] cl.exe found but not confirmed as x86, reloading VS env...

:find_vs
echo [BUILD] Searching for Visual Studio...

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" goto :try_fixed

set "VSDIR="
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -property installationPath 2^>nul`) do set "VSDIR=%%i"
if not defined VSDIR goto :try_fixed
if not exist "%VSDIR%\VC\Auxiliary\Build\vcvarsall.bat" goto :try_fixed

echo [BUILD] Found VS via vswhere: %VSDIR%
call "%VSDIR%\VC\Auxiliary\Build\vcvarsall.bat" x86 >nul 2>nul
goto :check_cl

:try_fixed
for %%E in (Enterprise Professional Community BuildTools) do (
    if exist "%ProgramFiles%\Microsoft Visual Studio\2022\%%E\VC\Auxiliary\Build\vcvarsall.bat" (
        echo [BUILD] Found VS 2022 %%E
        call "%ProgramFiles%\Microsoft Visual Studio\2022\%%E\VC\Auxiliary\Build\vcvarsall.bat" x86 >nul 2>nul
        goto :check_cl
    )
)
for %%E in (Enterprise Professional Community BuildTools) do (
    if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\%%E\VC\Auxiliary\Build\vcvarsall.bat" (
        echo [BUILD] Found VS 2019 %%E
        call "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\%%E\VC\Auxiliary\Build\vcvarsall.bat" x86 >nul 2>nul
        goto :check_cl
    )
)
for %%E in (Enterprise Professional Community BuildTools) do (
    if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2017\%%E\VC\Auxiliary\Build\vcvarsall.bat" (
        echo [BUILD] Found VS 2017 %%E - needs 15.7+ for C++17
        call "%ProgramFiles(x86)%\Microsoft Visual Studio\2017\%%E\VC\Auxiliary\Build\vcvarsall.bat" x86 >nul 2>nul
        goto :check_cl
    )
)
echo [BUILD] ERROR: Visual Studio not found!
echo [BUILD] Install VS 2019/2022 with "Desktop development with C++".
pause
exit /b 1

:check_cl
where cl.exe >nul 2>nul
if errorlevel 1 (
    echo [BUILD] ERROR: cl.exe still not available after loading VS.
    pause & exit /b 1
)
if /i not "%VSCMD_ARG_TGT_ARCH%"=="x86" (
    echo [BUILD] ERROR: MSVC environment is not targeting x86.
    echo [BUILD] VSCMD_ARG_TGT_ARCH=%VSCMD_ARG_TGT_ARCH%
    pause & exit /b 1
)

:do_build
echo [BUILD] MSVC x86 environment ready

REM --- Prepare build dir ---
if exist "%BUILDDIR%" rmdir /s /q "%BUILDDIR%"
mkdir "%BUILDDIR%"
pushd "%BUILDDIR%"

REM --- Auto-generate .def from source ---
REM MSVC exports __stdcall names decorated as _name@N; YiYuYan looks
REM up undecorated names, so a .def is mandatory. Export lines in the
REM source all have the exact shape:  EXPORT int STDCALL ht_xxx(...)
echo [BUILD] Generating EHashTable.def from src\hashtable.cpp ...
powershell -NoProfile -Command "$n=Select-String -LiteralPath '%ROOT%src\hashtable.cpp' -Pattern '^EXPORT\s+int\s+STDCALL\s+(ht_\w+)' | ForEach-Object { $_.Matches[0].Groups[1].Value }; if($n.Count -lt 1){exit 1}; Set-Content -LiteralPath 'EHashTable.def' -Encoding ASCII -Value (@('LIBRARY EHashTable','EXPORTS')+$n); Write-Host ('[BUILD] .def generated with '+$n.Count+' exports')"
if errorlevel 1 (
    popd
    echo [BUILD] ERROR: failed to generate .def - no exports matched.
    pause & exit /b 1
)
for /f %%c in ('type EHashTable.def ^| find /c /v ""') do set /a DEFEXP=%%c-2

REM --- Compile + link ---
echo [BUILD] Compiling...
cl /nologo /std:c++17 /permissive- /utf-8 /EHsc /GR- ^
   /O2 /Oi /GL /DNDEBUG /MT ^
   /D_WIN32_WINNT=0x0601 /DWINVER=0x0601 ^
   /I "%ROOT%third_party" ^
   "%ROOT%src\hashtable.cpp" ^
   /LD /Fe:EHashTable.dll ^
   /link /DEF:EHashTable.def /LTCG /INCREMENTAL:NO ^
   /OPT:REF /OPT:ICF /RELEASE /SUBSYSTEM:WINDOWS,6.01
if errorlevel 1 (
    popd
    echo [BUILD] ERROR: Compilation failed.
    pause & exit /b 1
)
if not exist EHashTable.dll (
    popd
    echo [BUILD] ERROR: EHashTable.dll not produced.
    pause & exit /b 1
)

REM --- Verify: 32-bit ---
dumpbin /headers EHashTable.dll | findstr /c:"machine (x86)" >nul
if errorlevel 1 (
    popd
    echo [BUILD] ERROR: produced DLL is NOT 32-bit x86.
    pause & exit /b 1
)
echo [BUILD] Verified: PE machine = x86 [32-bit]

REM --- Verify: exports undecorated and complete ---
dumpbin /exports EHashTable.dll | findstr /r /c:"ht_.*@[0-9]" >nul
if not errorlevel 1 (
    popd
    echo [BUILD] ERROR: exports are stdcall-decorated - .def not applied.
    pause & exit /b 1
)
dumpbin /exports EHashTable.dll | findstr /c:"ht_version" >nul
if errorlevel 1 (
    popd
    echo [BUILD] ERROR: export ht_version missing.
    pause & exit /b 1
)
for /f %%c in ('dumpbin /exports EHashTable.dll ^| findstr /r /c:" ht_" ^| find /c /v ""') do set "NEXP=%%c"
if not "%NEXP%"=="%DEFEXP%" (
    popd
    echo [BUILD] ERROR: DLL exports %NEXP% but .def lists %DEFEXP%.
    pause & exit /b 1
)
echo [BUILD] Verified: %NEXP% undecorated ht_* exports [matches .def]
echo [BUILD] --- DLL dependencies ---
dumpbin /dependents EHashTable.dll | findstr /i /c:".dll"

popd
copy /y "%BUILDDIR%\EHashTable.dll" "%OUTDLL%" >nul

echo.
echo [BUILD] OK: %OUTDLL%
for %%F in ("%OUTDLL%") do echo [BUILD] Size: %%~zF bytes
echo.
echo To clean build cache, delete: %ROOT%_EHashTable_build
pause
