// =============================================================================
//  EHashTable —— 供易语言(32位)调用的高性能哈希表 DLL  (v1.06 多线程注册表修复版)
//  核心:ankerl::unordered_dense (MIT)
//
//  本版(10600)相对 v1.05 的改动(对外 41 个导出、参数、返回值、序列化格式完全不变):
//    1) 【修复·崩溃】句柄注册表 g_live / g_nextId 是全进程共享的:每次 ht_* 调用都要经
//       check() 查它,ht_create / ht_free 要改它。v1.05 对它不加任何锁(原注释写的是"单线程
//       访问"),只要两个线程同时调用 —— 哪怕各自只用自己的表,即原注释所说的"每线程一张表"
//       —— 就会并发读写同一个 std::unordered_map 和同一个计数器:链表/桶被改坏,活着的表
//       查不到(调用静默失败、表泄漏),或查到别的表、已释放的表 → 重复释放、释放后使用;
//       两个线程还可能拿到同一个编号(emplace 第二次失败却照样返回该编号)。
//       现场:易语言端 加载全部音效 把 5 个加载任务同时投进线程池,每个任务一开头就
//       创建 两三张局部表、结束时 释放;崩在 EHashTable.dll+0x5BC7 = ht_free 析构元素
//       (~pair<string,string>),元素内存已被别处复用(里面是配置文本)。
//       本版给注册表加读写锁(Windows 为 SRW 锁):查句柄用共享锁(各线程互不阻塞),
//       创建/释放用独占锁;编号分配与登记在同一把独占锁内一次完成并核对登记结果;
//       ht_free 在锁内摘号、锁外析构(大表析构较慢,不拖住其它线程)。
//       锁只保护注册表,不保护表内数据:不同的表可以在不同线程同时使用(多线程下
//       "每线程一张表"从此真正成立);同一张表跨线程使用仍须调用方自行加锁。
//    2) ht_version 返回 10600(易语言端只做 ≥10400 / ≥10100 判断,不受影响)。
//
//  v1.05(10500)相对 v1.04 的改动(对外 41 个导出、参数、返回值、序列化格式完全不变):
//    1) 【修复】读/查/删路径改为"透明异构查找"(string_view 直查,不再构造临时键):
//       - 长键(>15字节)查询彻底零堆分配 → 更快,且从根上不可能抛异常;
//       - 修复了 v1.04 中 ht_get_t/b、ht_has_t/b、ht_del_t/b、ht_batch_geti/has/del_t
//         在"键超出 SSO 且恰逢内存分配失败"时 bad_alloc 穿透 DLL 边界的问题。
//    2) 【修复】写路径(ht_set_*/ht_seti_*)的键构造移入 try 之内(v1.04 中 keyT(key)
//       在实参位置求值、位于 doSet 内部 try 之外,同样可能穿透异常);并借透明
//       try_emplace 做到"单次查找完成 查重+插入","覆盖已有键"时零键分配。
//    3) 【修复】覆盖路径直接 assign(指针,长度),消除 v1.04 的"临时串+赋值"双拷贝。
//    4) 【加固】句柄改为"一次性递增编号"(不再直接暴露表指针):
//       释放后的旧句柄永远无效,即使随后创建了新表也绝不会串台(根治地址复用 ABA);
//       校验成本与 v1.04 相同(一次哈希查找)。句柄依旧是非 0 正整数,外部用法不变。
//    5) 【加固】ht_load 改"两遍制":第一遍零分配校验全部结构(含 cnt 上界预检),
//       数据损坏/被篡改 → 返回 E_BAD_ARG 且【原表内容分毫不动】;
//       第二遍构建到临时表、成功后整体接管 → 即使载入途中内存不足,原表也不丢。
//    6) 【加固】极端场景(哈希表扩容途中内存耗尽)会使底层桶数组暂时为空,
//       v1.04 此后再查询可能越界崩溃;本版在写路径捕获后先尝试重建桶
//       (重建成功=本次插入实际已完成,如实返回 1),仍失败则清空该表保命 ——
//       宁可丢该表数据,绝不崩溃(此情形仅在真实 OOM 下才可能出现)。
//    7) 编译期断言必须以 32 位编译,防止误用 64 位工具链产出句柄被截断的坏 DLL。
//
//  沿用 v1.02+ 的性能设计(语义对外保持一致):
//    · 值"内联"存储:map<string,string>,键值直接放在稠密数组里,
//      无逐项 new/delete;删除为纯稠密数组 swap-pop(无堆释放)。
//    · 键只存一份;表内数据不加锁:单线程下达到极致(易语言常态为单线程)。
//      【同一张表跨线程使用请自行加锁,或每线程一张表。】(v1.06 起句柄注册表自带
//      读写锁,"每线程一张表"在多线程下才真正安全;查句柄只多一次无竞争的共享锁。)
//    · 读/删热点路径无 try/catch(本版起也无需:该路径已不可能抛异常);-O3。
//
//  对外约定不变:32位 / __stdcall / 未修饰名;句柄=非0正整数(v1.05 起为一次性编号);
//  取值返回(内部数据指针, 长度),指针在该键被改写/删除/表结构性修改前有效。
// =============================================================================
#ifdef _WIN32
  // 句柄注册表锁用 SRW 读写锁(Vista 起提供);本 DLL 最低目标 Win7 SP1,与 MSVC 构建脚本的
  // /D_WIN32_WINNT=0x0601 一致。须在包含任何头文件之前定好;windows.h 本身放到文件末尾才包含
  // (见文末"句柄注册表锁(实现)"),它带的大量宏因此影响不到本文件前面的代码。
  #if !defined(_WIN32_WINNT) || _WIN32_WINNT < 0x0601
    #undef _WIN32_WINNT
    #define _WIN32_WINNT 0x0601
  #endif
#endif
#include "ankerl/unordered_dense.h"
#include <string>
#include <string_view>
#include <unordered_map>
#include <cstdint>
#include <cstring>
#include <utility>
#ifndef _WIN32
  #include <shared_mutex>   // 非 Windows 只用于在其它平台上编译做单元/并发测试(Windows 用 SRW 锁,见文末)
#endif

#ifdef _WIN32
  #define EXPORT extern "C" __declspec(dllexport)
  #define STDCALL __stdcall
#else
  #define EXPORT extern "C"
  #define STDCALL
#endif

// 本 DLL 面向易语言(32位进程):句柄/指针都装在 整数型(4字节) 里,64 位编译必然截断出错。
static_assert(sizeof(void*) == 4 && sizeof(int) == 4, "EHashTable 必须用 32 位工具链编译(易语言为 32 位)");

enum { T_INT=3,T_LONG=4,T_FLOAT=5,T_DOUBLE=6,T_BOOL=7,T_TEXT=10,T_BIN=11,T_CUSTOM=99 };
enum { E_OK=0,E_BAD_HANDLE=1,E_BAD_ARG=2,E_NOT_FOUND=3,E_ALLOC=4 };

namespace {

// 透明哈希:同一套 wyhash 既可哈希存储键(std::string)也可直接哈希 string_view,
// 使 find/erase/try_emplace 无需构造临时 std::string —— 查询零分配、零异常。
struct SvHash {
    using is_transparent = void;   // 允许异构查找
    using is_avalanching = void;   // 告知 unordered_dense:哈希已充分雪崩,免二次混合
    uint64_t operator()(std::string_view sv) const noexcept {
        return ankerl::unordered_dense::hash<std::string_view>{}(sv);
    }
};

// 键 -> 值 直接内联进稠密数组;不再有 Entry / 指针间接 / 逐项堆分配。
using Map = ankerl::unordered_dense::map<std::string, std::string, SvHash, std::equal_to<>>;

struct HashTable {
    int keyType = 0;
    int valType = 0;
    int lastError = E_OK;
    Map map;
    Map::iterator enumIt;
    bool enumActive = false;
    std::string scratch;   // 批量/序列化输出缓冲
};

// 存活句柄注册表:句柄=一次性递增编号(1..0x7FFFFFFF),释放后编号永不复用于旧值,
// 旧句柄天然失效 → 既保证不崩溃,也不会误操作到后来新建的表(根治 ABA)。
// 选用 std::unordered_map:其插入具备强异常安全(失败时注册表原状)。
// 注册表全进程共享(所有表、所有线程都经它查句柄),只能在下面的注册表锁内访问。
std::unordered_map<int, HashTable*> g_live;
uint32_t g_nextId = 1;

// 句柄注册表锁(v1.06):g_live / g_nextId 的每次访问都在锁内 ——
//   check()   持共享锁:各线程查句柄互不阻塞;
//   ht_create 持独占锁:"分配编号 + 登记"一步完成(分开做时两个线程会拿到同一个编号);
//   ht_free   持独占锁:查到并摘号;表的析构放到锁外。
// 锁只保护注册表,不保护表内数据:同一张表跨线程使用仍须调用方自行加锁。
// 实现在文件末尾(Windows: SRW 读写锁;其它平台: std::shared_mutex,仅供测试)。
void regLockShared() noexcept;
void regUnlockShared() noexcept;
void regLockExclusive() noexcept;
void regUnlockExclusive() noexcept;
struct RegSharedGuard {
    RegSharedGuard() noexcept { regLockShared(); }
    ~RegSharedGuard() { regUnlockShared(); }
    RegSharedGuard(const RegSharedGuard&) = delete;
    RegSharedGuard& operator=(const RegSharedGuard&) = delete;
};
struct RegExclusiveGuard {
    RegExclusiveGuard() noexcept { regLockExclusive(); }
    ~RegExclusiveGuard() { regUnlockExclusive(); }
    RegExclusiveGuard(const RegExclusiveGuard&) = delete;
    RegExclusiveGuard& operator=(const RegExclusiveGuard&) = delete;
};

inline HashTable* check(int h) {
    if (h == 0) return nullptr;
    RegSharedGuard lk;                         // 与 ht_create/ht_free 的独占写互斥
    auto it = g_live.find(h);
    return it == g_live.end() ? nullptr : it->second;
}

// —— 键/值视图构造(全部 noexcept、零分配;data() 恒非空,杜绝空指针传入 memcmp/memcpy) ——
inline std::string_view keyIv(const int32_t& k)  noexcept { return { reinterpret_cast<const char*>(&k), 4 }; }
inline std::string_view keyLv(const int64_t& k)  noexcept { return { reinterpret_cast<const char*>(&k), 8 }; }
inline std::string_view keyTv(const char* k)     noexcept { return k ? std::string_view(k) : std::string_view("", 0); }
inline std::string_view bytesv(const void* p, int n) noexcept {
    return (p && n > 0) ? std::string_view(static_cast<const char*>(p), (size_t)n) : std::string_view("", 0);
}

bool keyTypeOk(int kt){ return kt==T_INT||kt==T_LONG||kt==T_TEXT||kt==T_BIN; }
bool valTypeOk(int vt){ return vt==T_INT||vt==T_LONG||vt==T_FLOAT||vt==T_DOUBLE||vt==T_BOOL||vt==T_TEXT||vt==T_BIN||vt==T_CUSTOM; }

// 扩容途中 OOM 的善后:unordered_dense 扩容失败会留下"桶数组为空"的状态(唯一指纹:
// bucket_count()==0),此后查询会越界。先试重建桶(reserve 对空桶必然重建;若成功,
// 数据无损);再不行则清空该表 —— 宁可丢数据,绝不让后续调用崩溃。
// 清空后的表处于"空桶休眠态":查/删/枚举/序列化/清空/释放天然安全(空表短路),
// 唯独插入需先重建桶 —— 由 doSet 入口第一行自愈,状态机就此闭合。
// 返回 真=表已完整修复(原有数据+本次插入都在)。
inline bool rescueBuckets(HashTable* t) noexcept {
    try { t->map.reserve(t->map.size()); return true; }   // reserve 对空桶必然重建(库内 0==bucket_count 分支)
    catch (...) {
        try { t->map = Map(); }                            // 数据保不住:优先换成健康空表(仅需最小桶,32字节)
        catch (...) { t->map.clear(); }                    // 连最小桶都没有:清空进入"空桶休眠态"(见上)
        return false;
    }
}

} // namespace

// =================== 生命周期 / 元信息 ===================
EXPORT int STDCALL ht_version() { return 10600; } // 1.06.00(句柄注册表加读写锁,多线程同时创建/释放/使用各自的表不再串表、崩溃;API 与 10400/10500 完全兼容,批量入口 ht_batch_* 自 10400 起提供)

EXPORT int STDCALL ht_create(int keyType, int valType, int capacity) {
    if (!keyTypeOk(keyType)) return 0;
    if (valType == 0) valType = T_INT;
    if (!valTypeOk(valType)) return 0;
    HashTable* t = nullptr;
    try {
        t = new HashTable();                               // 建表与预留容量较慢,放在锁外
        t->keyType = keyType; t->valType = valType;
        if (capacity > 0) t->map.reserve((size_t)capacity);
        uint32_t id = 0;
        bool registered = false;
        {
            RegExclusiveGuard lk;                          // 分配编号与登记必须在同一把独占锁内一次完成
            do {
                id = g_nextId++;
                if (g_nextId > 0x7FFFFFFFu) g_nextId = 1;  // 环绕(需连续创建 21 亿次才会发生)
            } while (g_live.count((int)id) != 0);          // 环绕后跳过仍在用的编号
            registered = g_live.emplace((int)id, t).second; // 失败时强异常安全:注册表原状(锁随异常自动释放)
        }
        if (!registered) { delete t; return 0; }           // 锁内已查过不存在,不会走到;防御:绝不返回一个没登记成本表的编号
        return (int)id;
    } catch (...) { delete t; return 0; }
}

EXPORT int STDCALL ht_free(int h) {
    if (h == 0) return 0;
    HashTable* t = nullptr;
    {
        RegExclusiveGuard lk;
        auto it = g_live.find(h); if (it == g_live.end()) return 0;
        t = it->second; g_live.erase(it);                  // 先在锁内摘号:此后任何线程都查不到它,旧句柄永久失效
    }
    delete t; return 1;                                    // 析构放在锁外:大表析构较慢,不拖住其它线程查句柄
}
EXPORT int STDCALL ht_iscreated(int h) { return check(h) ? 1 : 0; }

EXPORT int STDCALL ht_clear(int h) {
    HashTable* t = check(h); if (!t) return 0;
    t->map.clear(); t->enumActive = false; t->lastError = E_OK; return 1;  // 值内联,无需逐项 delete
}
EXPORT int STDCALL ht_count(int h)   { HashTable* t = check(h); return t ? (int)t->map.size() : -1; }
EXPORT int STDCALL ht_keytype(int h) { HashTable* t = check(h); return t ? t->keyType : 0; }
EXPORT int STDCALL ht_valtype(int h) { HashTable* t = check(h); return t ? t->valType : 0; }
EXPORT int STDCALL ht_lasterror(int h){ HashTable* t = check(h); return t ? t->lastError : E_BAD_HANDLE; }

// 内部统一写入:0 失败 / 1 首次 / 2 覆盖 / 3 不覆盖
// 键/值的一切构造与分配均在 try 之内;透明 try_emplace 单次查找完成 查重+插入:
//   已存在 → 未做任何分配(键零拷贝);不存在 → 就地构造键值。
static inline int doSet(HashTable* t, std::string_view key, const void* v, int vlen, int noOvr) {
    if (t->map.bucket_count() == 0) {                        // 自愈:仅先前极端OOM清空后为空桶休眠态,插入前须先重建最小桶。
        try { t->map.reserve(0); }                           // 独立于主 try:确保主 catch 里"桶为空"必然意味着
        catch (...) { t->lastError = E_ALLOC; return 0; }    // "新元素已进入稠密数组",rescue 成功才可如实返回 1。
    }
    try {
        auto [it, inserted] = t->map.try_emplace(key, bytesv(v, vlen));
        if (!inserted) {
            if (noOvr) { t->lastError = E_OK; return 3; }
            const std::string_view val = bytesv(v, vlen);
            it->second.assign(val.data(), val.size());  // 覆盖:就地改值(单次拷贝;不动表结构,枚举游标仍有效)
            t->lastError = E_OK; return 2;
        }
        t->enumActive = false;
        t->lastError = E_OK; return 1;
    } catch (...) {
        if (t->map.bucket_count() == 0) {       // 只能来自 try_emplace 内部扩容失败 → 新元素必已在稠密数组中
            if (rescueBuckets(t)) { t->enumActive = false; t->lastError = E_OK; return 1; }  // 桶重建成功:插入实际已完成
            t->enumActive = false;              // 表已被清空保命
        }
        t->lastError = E_ALLOC; return 0;       // 常规分配失败:表未被改动,枚举游标依旧有效(与 v1.04 一致)
    }
}

// =================== 添加 ===================
EXPORT int STDCALL ht_set_i(int h,int key,const uint8_t* val,int vlen,int noOvr){ HashTable* t=check(h); if(!t)return 0; return doSet(t,keyIv(key),val,vlen,noOvr); }
EXPORT int STDCALL ht_set_l(int h,long long key,const uint8_t* val,int vlen,int noOvr){ HashTable* t=check(h); if(!t)return 0; return doSet(t,keyLv(key),val,vlen,noOvr); }
EXPORT int STDCALL ht_set_t(int h,const char* key,const uint8_t* val,int vlen,int noOvr){ HashTable* t=check(h); if(!t)return 0; return doSet(t,keyTv(key),val,vlen,noOvr); }
EXPORT int STDCALL ht_set_b(int h,const uint8_t* key,int klen,const uint8_t* val,int vlen,int noOvr){ HashTable* t=check(h); if(!t)return 0; return doSet(t,bytesv(key,klen),val,vlen,noOvr); }

// 整数值直存版:值以 整数型(4字节) 直接传入,免去易语言端"指针到字节集"的每次分配。
// 语义与 ht_set_* 传入 4 字节整数值完全一致(返回 0/1/2/3)。
EXPORT int STDCALL ht_seti_i(int h,int key,int val,int noOvr){ HashTable* t=check(h); if(!t)return 0; return doSet(t,keyIv(key),&val,4,noOvr); }
EXPORT int STDCALL ht_seti_l(int h,long long key,int val,int noOvr){ HashTable* t=check(h); if(!t)return 0; return doSet(t,keyLv(key),&val,4,noOvr); }
EXPORT int STDCALL ht_seti_t(int h,const char* key,int val,int noOvr){ HashTable* t=check(h); if(!t)return 0; return doSet(t,keyTv(key),&val,4,noOvr); }
EXPORT int STDCALL ht_seti_b(int h,const uint8_t* key,int klen,int val,int noOvr){ HashTable* t=check(h); if(!t)return 0; return doSet(t,bytesv(key,klen),&val,4,noOvr); }

// =================== 批量(文本键 + 整数值):一次调用处理整个数组,把每次跨DLL调用的~40ns开销摊到接近零 ===================
// keys = 文本型数组数据地址(char**);vals / valsOut = 整数型数组数据地址(int*)。语义与逐键 ht_seti_t/ht_get_t/ht_has_t/ht_del_t 完全一致。
// 注意:ht_batch_seti_t 中途某条失败(内存不足)不会中断,继续处理其余并只把"新插入条数"计入返回值;
//      如需区分"部分失败"与"键已存在被跳过",事后查 ht_lasterror(失败时为 4)。
EXPORT int STDCALL ht_batch_seti_t(int h,const char* const* keys,const int* vals,int count,int noOvr){
    HashTable* t=check(h); if(!t||!keys||!vals||count<=0) return 0;
    int inserted=0;
    for(int i=0;i<count;i++){ if(doSet(t, keyTv(keys[i]), &vals[i], 4, noOvr)==1) inserted++; }  // doSet 已兜住一切异常
    return inserted; // 新插入条数(覆盖不计)
}
EXPORT int STDCALL ht_batch_geti_t(int h,const char* const* keys,int* valsOut,int count){
    HashTable* t=check(h); if(!t||!keys||!valsOut||count<=0) return 0;
    int hits=0;
    for(int i=0;i<count;i++){
        auto it=t->map.find(keyTv(keys[i]));                 // 透明查找:零分配、零异常
        if(it!=t->map.end() && it->second.size()>=4){ std::memcpy(&valsOut[i], it->second.data(), 4); hits++; }
        else valsOut[i]=0;
    }
    t->lastError=E_OK; return hits; // 命中条数;未命中处写0
}
EXPORT int STDCALL ht_batch_has_t(int h,const char* const* keys,int count){
    HashTable* t=check(h); if(!t||!keys||count<=0) return 0;
    int n=0; for(int i=0;i<count;i++) if(t->map.find(keyTv(keys[i]))!=t->map.end()) n++;
    return n;
}
EXPORT int STDCALL ht_batch_del_t(int h,const char* const* keys,int count){
    HashTable* t=check(h); if(!t||!keys||count<=0) return 0;
    int n=0; for(int i=0;i<count;i++) if(t->map.erase(keyTv(keys[i]))>0) n++;   // 透明删除:零分配、零异常
    if(n) t->enumActive=false;                                                  // swap-pop 使游标失效
    t->lastError=E_OK;
    return n; // 删除条数
}

// =================== 取值(返回内部指针+长度) ===================
static inline int doGet(HashTable* t, std::string_view key, int* outPtr, int* outLen) noexcept {
    auto it = t->map.find(key);                              // 透明查找:零分配、零异常
    if (it == t->map.end()) { t->lastError=E_OK; if(outPtr)*outPtr=0; if(outLen)*outLen=0; return 0; }
    const std::string& s = it->second;
    if (outPtr) *outPtr = static_cast<int>(reinterpret_cast<uintptr_t>(s.data()));
    if (outLen) *outLen = static_cast<int>(s.size());
    t->lastError=E_OK; return 1;
}
EXPORT int STDCALL ht_get_i(int h,int key,int* o,int* l){ HashTable* t=check(h); if(!t){if(o)*o=0;if(l)*l=0;return 0;} return doGet(t,keyIv(key),o,l); }
EXPORT int STDCALL ht_get_l(int h,long long key,int* o,int* l){ HashTable* t=check(h); if(!t){if(o)*o=0;if(l)*l=0;return 0;} return doGet(t,keyLv(key),o,l); }
EXPORT int STDCALL ht_get_t(int h,const char* key,int* o,int* l){ HashTable* t=check(h); if(!t){if(o)*o=0;if(l)*l=0;return 0;} return doGet(t,keyTv(key),o,l); }
EXPORT int STDCALL ht_get_b(int h,const uint8_t* key,int klen,int* o,int* l){ HashTable* t=check(h); if(!t){if(o)*o=0;if(l)*l=0;return 0;} return doGet(t,bytesv(key,klen),o,l); }

// =================== 查询 ===================
EXPORT int STDCALL ht_has_i(int h,int key){ HashTable* t=check(h); if(!t)return 0; return t->map.find(keyIv(key))!=t->map.end(); }
EXPORT int STDCALL ht_has_l(int h,long long key){ HashTable* t=check(h); if(!t)return 0; return t->map.find(keyLv(key))!=t->map.end(); }
EXPORT int STDCALL ht_has_t(int h,const char* key){ HashTable* t=check(h); if(!t)return 0; return t->map.find(keyTv(key))!=t->map.end(); }
EXPORT int STDCALL ht_has_b(int h,const uint8_t* key,int klen){ HashTable* t=check(h); if(!t)return 0; return t->map.find(bytesv(key,klen))!=t->map.end(); }

// =================== 删除(稠密数组 swap-pop,无堆释放;透明删除零分配零异常) ===================
static inline int doDel(HashTable* t, std::string_view key) noexcept {
    if (t->map.erase(key) == 0) { t->lastError=E_OK; return 0; }
    t->enumActive = false; t->lastError=E_OK; return 1;
}
EXPORT int STDCALL ht_del_i(int h,int key){ HashTable* t=check(h); if(!t)return 0; return doDel(t,keyIv(key)); }
EXPORT int STDCALL ht_del_l(int h,long long key){ HashTable* t=check(h); if(!t)return 0; return doDel(t,keyLv(key)); }
EXPORT int STDCALL ht_del_t(int h,const char* key){ HashTable* t=check(h); if(!t)return 0; return doDel(t,keyTv(key)); }
EXPORT int STDCALL ht_del_b(int h,const uint8_t* key,int klen){ HashTable* t=check(h); if(!t)return 0; return doDel(t,bytesv(key,klen)); }

// =================== 枚举(无序) ===================
EXPORT int STDCALL ht_enum_begin(int h){ HashTable* t=check(h); if(!t)return 0; t->enumIt=t->map.begin(); t->enumActive=true; return 1; }
EXPORT int STDCALL ht_enum_next(int h,int* kptr,int* klen,int* vptr,int* vlen){
    HashTable* t=check(h);
    if(!t || !t->enumActive) return 0;
    if(t->enumIt==t->map.end()){ t->enumActive=false; return 0; }
    const auto& kv = *t->enumIt;
    if(kptr)*kptr=static_cast<int>(reinterpret_cast<uintptr_t>(kv.first.data()));
    if(klen)*klen=static_cast<int>(kv.first.size());
    if(vptr)*vptr=static_cast<int>(reinterpret_cast<uintptr_t>(kv.second.data()));
    if(vlen)*vlen=static_cast<int>(kv.second.size());
    ++t->enumIt; return 1;
}

// =================== 批量:取所有键 / 取所有值 ===================
EXPORT int STDCALL ht_keys(int h,int* outPtr,int* outLen){
    HashTable* t=check(h); if(!t){if(outPtr)*outPtr=0;if(outLen)*outLen=0;return 0;}
    try {
        t->scratch.clear();
        size_t est=0; for(auto& kv:t->map) est+=kv.first.size()+5; t->scratch.reserve(est);
        for(auto& kv:t->map){ uint32_t n=(uint32_t)kv.first.size(); t->scratch.append((const char*)&n,4); t->scratch.append(kv.first); t->scratch.push_back('\0'); }
        if(outPtr)*outPtr=static_cast<int>(reinterpret_cast<uintptr_t>(t->scratch.data()));
        if(outLen)*outLen=static_cast<int>(t->scratch.size());
        t->lastError=E_OK; return 1;
    } catch(...){ t->lastError=E_ALLOC; if(outPtr)*outPtr=0; if(outLen)*outLen=0; return 0; }
}
EXPORT int STDCALL ht_vals(int h,int* outPtr,int* outLen){
    HashTable* t=check(h); if(!t){if(outPtr)*outPtr=0;if(outLen)*outLen=0;return 0;}
    try {
        t->scratch.clear();
        size_t est=0; for(auto& kv:t->map) est+=kv.second.size()+5; t->scratch.reserve(est);
        for(auto& kv:t->map){ const std::string& v=kv.second; uint32_t n=(uint32_t)v.size(); t->scratch.append((const char*)&n,4); t->scratch.append(v); t->scratch.push_back('\0'); }
        if(outPtr)*outPtr=static_cast<int>(reinterpret_cast<uintptr_t>(t->scratch.data()));
        if(outLen)*outLen=static_cast<int>(t->scratch.size());
        t->lastError=E_OK; return 1;
    } catch(...){ t->lastError=E_ALLOC; if(outPtr)*outPtr=0; if(outLen)*outLen=0; return 0; }
}

// =================== 序列化:保存 / 载入 ===================
EXPORT int STDCALL ht_save(int h,int* outPtr,int* outLen){
    HashTable* t=check(h); if(!t){if(outPtr)*outPtr=0;if(outLen)*outLen=0;return 0;}
    try {
        t->scratch.clear();
        t->scratch.append("EHT1",4);
        int32_t kt=t->keyType,vt=t->valType,cnt=(int32_t)t->map.size();
        t->scratch.append((const char*)&kt,4); t->scratch.append((const char*)&vt,4); t->scratch.append((const char*)&cnt,4);
        for(auto& kv:t->map){
            uint32_t kn=(uint32_t)kv.first.size();  t->scratch.append((const char*)&kn,4); t->scratch.append(kv.first);
            uint32_t vn=(uint32_t)kv.second.size(); t->scratch.append((const char*)&vn,4); t->scratch.append(kv.second);
        }
        if(outPtr)*outPtr=static_cast<int>(reinterpret_cast<uintptr_t>(t->scratch.data()));
        if(outLen)*outLen=static_cast<int>(t->scratch.size());
        t->lastError=E_OK; return 1;
    } catch(...){ t->lastError=E_ALLOC; if(outPtr)*outPtr=0; if(outLen)*outLen=0; return 0; }
}
// 两遍制载入(格式与 v1.01+ 完全相同):
//   第一遍:零分配校验全部结构 —— 任何损坏/截断/伪造(含 cnt 超出物理上界)一律 E_BAD_ARG,
//           且【原表内容保持原样】;
//   第二遍:构建到临时表,全部成功后整体接管 —— 途中内存不足返回 E_ALLOC,原表同样不丢。
EXPORT int STDCALL ht_load(int h,const uint8_t* buf,int len){
    HashTable* t=check(h); if(!t) return 0;
    if(!buf || len<16){ t->lastError=E_BAD_ARG; return 0; }
    if(std::memcmp(buf,"EHT1",4)!=0){ t->lastError=E_BAD_ARG; return 0; }
    int32_t kt,vt,cnt; std::memcpy(&kt,buf+4,4); std::memcpy(&vt,buf+8,4); std::memcpy(&cnt,buf+12,4);
    if(!keyTypeOk(kt)||!valTypeOk(vt)||cnt<0){ t->lastError=E_BAD_ARG; return 0; }
    if((uint32_t)cnt > (uint32_t)(len-16)/8u){ t->lastError=E_BAD_ARG; return 0; }  // 每条至少8字节,cnt 超界=数据必假
    const uint8_t* const end = buf + len;
    // —— 第一遍:纯走位校验,不做任何分配 ——
    const uint8_t* p = buf + 16;
    for(int32_t i=0;i<cnt;i++){
        uint32_t kn,vn;
        if(end-p<4){ t->lastError=E_BAD_ARG; return 0; }
        std::memcpy(&kn,p,4); p+=4;
        if((uint32_t)(end-p)<kn){ t->lastError=E_BAD_ARG; return 0; }
        p+=kn;
        if(end-p<4){ t->lastError=E_BAD_ARG; return 0; }
        std::memcpy(&vn,p,4); p+=4;
        if((uint32_t)(end-p)<vn){ t->lastError=E_BAD_ARG; return 0; }
        p+=vn;
    }
    // —— 第二遍:构建临时表;成功才接管 ——
    try {
        Map tmp; tmp.reserve((size_t)cnt);
        p = buf + 16;
        for(int32_t i=0;i<cnt;i++){
            uint32_t kn,vn;
            std::memcpy(&kn,p,4); p+=4; const char* kd=(const char*)p; p+=kn;
            std::memcpy(&vn,p,4); p+=4; const char* vd=(const char*)p; p+=vn;
            tmp.try_emplace(std::string(kd,kn), std::string(vd,vn));   // 重复键保首个(与旧版一致)
        }
        t->map = std::move(tmp);
        t->enumActive=false; t->keyType=kt; t->valType=vt;
        t->lastError=E_OK; return 1;
    } catch(...){ t->lastError=E_ALLOC; return 0; }   // 原表未被触碰
}

// =================== 容量 / 收缩 ===================
EXPORT int STDCALL ht_capacity(int h){ HashTable* t=check(h); return t ? (int)t->map.bucket_count() : -1; }
EXPORT int STDCALL ht_shrink(int h){
    HashTable* t=check(h); if(!t)return 0;
    try{ t->map.rehash(0); t->enumActive=false; t->lastError=E_OK; return 1; }
    catch(...){
        if (t->map.bucket_count() == 0) rescueBuckets(t);  // 收缩途中 OOM 同样可能留下空桶,一并善后
        t->enumActive=false; t->lastError=E_ALLOC; return 0;   // 收缩中 values 可能已整理,游标一律作废(安全侧)
    }
}

// =================== 句柄注册表锁(实现) ===================
// windows.h 放在文件末尾才包含:它带的大量宏(ERROR、min/max、各种 E_xxx 等)不会影响到上面的代码。
#ifdef _WIN32
  #ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
  #endif
  #ifndef NOMINMAX
    #define NOMINMAX
  #endif
  #include <windows.h>
namespace {
// SRW 读写锁:静态零初始化(SRWLOCK_INIT),无需初始化/销毁,不会失败、不抛异常,只依赖 KERNEL32;
// 无竞争时加/解锁各一次原子操作。注意 SRW 锁不可重入:持锁期间不得再调用会加锁的函数(本文件内已保证)。
SRWLOCK g_regLock = SRWLOCK_INIT;
void regLockShared() noexcept      { AcquireSRWLockShared(&g_regLock); }
void regUnlockShared() noexcept    { ReleaseSRWLockShared(&g_regLock); }
void regLockExclusive() noexcept   { AcquireSRWLockExclusive(&g_regLock); }
void regUnlockExclusive() noexcept { ReleaseSRWLockExclusive(&g_regLock); }
} // namespace
#else
namespace {
std::shared_mutex g_regLock;              // 仅用于在其它平台上编译做单元/并发测试
void regLockShared() noexcept      { g_regLock.lock_shared(); }
void regUnlockShared() noexcept    { g_regLock.unlock_shared(); }
void regLockExclusive() noexcept   { g_regLock.lock(); }
void regUnlockExclusive() noexcept { g_regLock.unlock(); }
} // namespace
#endif
