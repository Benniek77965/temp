#!/usr/bin/env bash
# 一键：编译 DLL → 检查导出 / 导入 / 位数 → 另一目录重编比对字节（可复现）→ 编译自测程序（自带宿主图标）→ 精绘模块的单元测试
#       → 与悬浮窗同进程共存的测试（有 fontTools 时）→ 在 32 位 Wine 里跑 dntest
# 需要：i686-w64-mingw32-g++、wine32（连同推荐包里的 fonts-wine，没有它 Wine 里建不出字体）、xvfb；中文测试字体用 fonts-droid-fallback（第二个参数可换成别的中文字体，但须是单个 TrueType 文件 .ttf：字体集 .ttc 会让两项“宿主字体”测试失败，这是测试字体的格式问题，不是 DLL 的问题）；
#       共存测试另需 python3 的 fontTools（没有就跳过并说明）。
# 用法：tests/run_all.sh [截图目录] [中文字体文件]
set -e
export LANG=C.UTF-8 LC_ALL=C.UTF-8  # 路径里有中文（依赖库）：Wine 要在 UTF-8 下才认得
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SHOTS="${1:-/tmp/desknotify_shots}"
CJK="${2:-/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf}"
bash "$ROOT/build.sh"
python3 "$ROOT/tools/check_dll.py" "$ROOT/out/DeskNotify.dll"
TMP="$(mktemp -d)"; cp -r "$ROOT/src" "$ROOT/build.sh" "$TMP/"; (cd "$TMP" && bash ./build.sh "$TMP/out" >/dev/null)
if cmp -s "$ROOT/out/DeskNotify.dll" "$TMP/out/DeskNotify.dll"; then echo "PASS 换目录重编，字节相同（可复现）"; else echo "FAIL 换目录重编，字节不同（不可复现）"; rm -rf "$TMP"; exit 1; fi; rm -rf "$TMP"
(cd "$ROOT/tests" && i686-w64-mingw32-windres dntest.rc -O coff -o "$ROOT/out/dntest_res.o")
i686-w64-mingw32-g++ -std=c++17 -O1 -DUNICODE -D_UNICODE -static -o "$ROOT/out/dntest.exe" "$ROOT/tests/dntest.cpp" "$ROOT/out/dntest_res.o" -luser32 -lgdi32 -lshell32 -lpsapi -lgdiplus -Wl,--no-insert-timestamp
rm -f "$ROOT/out/dntest_res.o"; cp "$ROOT/tests/other_256.png" "$ROOT/out/"
rm -rf "$SHOTS"; mkdir -p "$SHOTS"
export WINEPREFIX="${WINEPREFIX:-$HOME/.wine-desknotify}" WINEARCH=win32 WINEDEBUG=-all WINEDLLOVERRIDES="mscoree,mshtml="
W() { echo "Z:$(echo "$1" | sed 's#/#\\#g')"; }
# 单元测试（只在 Wine 里跑：会临时改注册表的字体表，测完删掉）：精绘按注册表找系统字体文件
i686-w64-mingw32-g++ -std=c++17 -O1 -DUNICODE -D_UNICODE -D_WIN32_WINNT=0x0601 -municode -static -I"$ROOT/src" -o "$ROOT/out/unit_fine.exe" "$ROOT/tests/unit_fine.cpp" -lgdiplus -lgdi32 -luser32 -ladvapi32 -Wl,--no-insert-timestamp
(cd "$ROOT/out" && xvfb-run -a -s "-screen 0 640x480x24" wine unit_fine.exe | tr -d '\r') || true
rm -f "$ROOT/out/unit_fine.exe"
# 与悬浮窗（XhhFloat.dll，工程资源里的那份）同进程共存的测试：两边按私有方式登记、映射同一份鸿蒙黑体（替身字体由 fontTools 现场生成）
if python3 -c "import fontTools" 2>/dev/null && [ -f "$ROOT/../../资源/dll_XhhFloat.Image.dat" ]; then
  CO="$(mktemp -d)"; python3 "$ROOT/tools/make_standin_fonts.py" "$CJK" "$CO/fonts" >/dev/null && mkdir -p "$CO/shots" && python3 -c 'import sys,zlib; b=open(sys.argv[1],"rb").read(); open(sys.argv[2],"wb").write(b if b[:2]==b"MZ" else zlib.decompress(b[8:]))' "$ROOT/../../资源/dll_XhhFloat.Image.dat" "$CO/XhhFloat.dll"
  i686-w64-mingw32-g++ -std=c++17 -O1 -DUNICODE -D_UNICODE -static -o "$ROOT/out/coexist.exe" "$ROOT/tests/coexist.cpp" -lgdiplus -lgdi32 -luser32 -lshell32 -Wl,--no-insert-timestamp
  (cd "$ROOT/out" && xvfb-run -a -s "-screen 0 1920x1080x24" wine coexist.exe "$(W "$CO/XhhFloat.dll")" DeskNotify.dll "$(W "$CO/fonts")" "$(W "$CO/shots")" | tr -d '\r') || true
  rm -f "$ROOT/out/coexist.exe"; rm -rf "$CO"
else echo "INFO 没有 fontTools 或工程资源里没有 XhhFloat.dll：跳过与悬浮窗同进程共存的测试"; fi
# 1.1.1：字形坏了的宿主字体（只留 A 的轮廓，别的字取不到轮廓）——测“画的时候发现坏了、换回系统字体再画一遍”；没有 fontTools 或测试字体不是 TrueType 轮廓时跳过
DMG=""
if python3 -c "import fontTools" 2>/dev/null && [ -f "$CJK" ]; then
  python3 - "$CJK" "$ROOT/out/damaged_font.ttf" <<'PY' >/dev/null 2>&1 && DMG="$ROOT/out/damaged_font.ttf"
import sys
from fontTools.ttLib import TTFont
from fontTools.ttLib.tables._g_l_y_f import Glyph
src = sys.argv[1]; ttc = open(src, 'rb').read(4) == b'ttcf'
f = TTFont(src, fontNumber=0) if ttc else TTFont(src); cm = f.getBestCmap(); keep = {'.notdef'} | ({cm[0x41]} if 0x41 in cm else set())
g = f['glyf']
for n in f.getGlyphOrder():
    if n not in keep and g[n].numberOfContours != 0: g[n] = Glyph()
f.save(sys.argv[2])
PY
fi
cd "$ROOT/out" && xvfb-run -a -s "-screen 0 1920x1080x24" wine dntest.exe DeskNotify.dll "$(W "$SHOTS")" "$(W "$CJK")" ${DMG:+"$(W "$DMG")"}
