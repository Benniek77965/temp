// DeskNotify 自测：xvfb-run wine dntest.exe DeskNotify.dll <截图目录(Windows 路径)> [中日韩字体文件]
// 本程序自带一个程序图标（tests/host.ico，取自小红花音效助手的程序图标），用来检验“默认取宿主程序的图标、从图标取强调色”
#include <windows.h>
#include <stdio.h>
#include <string>
#include <vector>
#include <psapi.h>
#include <shlobj.h>
#include <gdiplus.h>
#include <math.h>
typedef INT_PTR(WINAPI* F4)(INT_PTR, INT_PTR, INT_PTR, INT_PTR);
static F4 GetVersion_, Set_, Show_, Update_, Close_, Info_, Stop_, Snap_, Mouse_, Wrap_;
static int passes = 0, fails = 0;
static void Check(bool ok, const char* what) { if (ok) passes++; else fails++; printf("%s %s\n", ok ? "PASS" : "FAIL", what); fflush(stdout); }
static volatile LONG evN = 0, lastEv = 0, lastId = 0; static LONG evLog[4096][2];
static INT_PTR WINAPI Cb(INT_PTR ev, INT_PTR id) { LONG n = InterlockedIncrement(&evN) - 1; if (n < 4096) { evLog[n][0] = (LONG)ev; evLog[n][1] = (LONG)id; } lastEv = (LONG)ev; lastId = (LONG)id; return 0; }
static bool Wait(int ms, bool (*f)(INT_PTR), INT_PTR a) { DWORD t0 = GetTickCount(); while ((int)(GetTickCount() - t0) < ms) { MSG m; while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) DispatchMessageW(&m); if (f(a)) return true; Sleep(10); } return f(a); }
static bool PhaseIs(INT_PTR p) { return Info_(20, 0, 0, 0) == p; }
static bool EvFor(INT_PTR id) { for (LONG i = 0; i < evN && i < 4096; i++) if (evLog[i][1] == id) return true; return false; }
static int EvOf(INT_PTR id) { for (LONG i = 0; i < evN && i < 4096; i++) if (evLog[i][1] == id) return evLog[i][0]; return 0; }
static std::string U8(const wchar_t* w) { int n = WideCharToMultiByte(CP_UTF8, 0, w, -1, nullptr, 0, nullptr, nullptr); std::string s(n, 0); WideCharToMultiByte(CP_UTF8, 0, w, -1, &s[0], n, nullptr, nullptr); s.resize(n - 1); return s; }
// 易语言「ZLIB压缩数据」格式的解压（测试程序用）：4 字节标记 0D 0F 3E 03＋4 字节原长（小端）＋zlib 数据（RFC 1950 头、RFC 1951 deflate、Adler-32 校验）。
// 项目资源里的 DLL（资源\dll_*.Image.dat）就是这样存的，易语言程序写出前先解开；测试程序原来直接拿它当 DLL 用，Windows 报“损坏的映像”（0xc000012f）
namespace ezl {
struct Huff { short count[16]; short symbol[288]; };
struct St {
  const unsigned char* in; size_t n, pos; unsigned bitbuf; int bitcnt; std::vector<unsigned char>* out; size_t cap; bool err;
  int bits(int need) {
    unsigned long long v = bitbuf;
    while (bitcnt < need) { if (pos >= n) { err = true; return 0; } v |= (unsigned long long)in[pos++] << bitcnt; bitcnt += 8; }
    bitbuf = (unsigned)(v >> need); bitcnt -= need;
    return (int)(v & ((1ull << need) - 1));
  }
};
static int construct(Huff& h, const short* len, int n) {  // 由各符号的码长建范式哈夫曼表：返回 0 完整，>0 不完整，<0 超额
  for (int i = 0; i < 16; i++) h.count[i] = 0;
  for (int s = 0; s < n; s++) h.count[len[s]]++;
  if (h.count[0] == n) return 0;
  int left = 1;
  for (int l = 1; l < 16; l++) { left <<= 1; left -= h.count[l]; if (left < 0) return left; }
  short offs[16]; offs[1] = 0;
  for (int l = 1; l < 15; l++) offs[l + 1] = (short)(offs[l] + h.count[l]);
  for (int s = 0; s < n; s++) if (len[s]) h.symbol[offs[len[s]]++] = (short)s;
  return left;
}
static int decode(St& s, const Huff& h) {
  int code = 0, first = 0, index = 0;
  for (int l = 1; l < 16; l++) {
    code |= s.bits(1); if (s.err) return -1;
    int c = h.count[l];
    if (code - c < first) return h.symbol[index + (code - first)];
    index += c; first += c; first <<= 1; code <<= 1;
  }
  return -1;
}
static bool codes(St& s, const Huff& lc, const Huff& dc) {
  static const short lb[29] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
  static const short le[29] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
  static const short db[30] = {1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577};
  static const short de[30] = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};
  std::vector<unsigned char>& o = *s.out;
  for (;;) {
    int sym = decode(s, lc); if (sym < 0) return false;
    if (sym < 256) { if (o.size() >= s.cap) return false; o.push_back((unsigned char)sym); continue; }
    if (sym == 256) return true;
    sym -= 257; if (sym >= 29) return false;
    int len = lb[sym] + s.bits(le[sym]);
    int ds = decode(s, dc); if (ds < 0 || ds >= 30) return false;
    size_t dist = (size_t)(db[ds] + s.bits(de[ds]));
    if (s.err || dist > o.size() || o.size() + (size_t)len > s.cap) return false;
    size_t from = o.size() - dist;
    for (int i = 0; i < len; i++) o.push_back(o[from + i]);  // 允许重叠（距离小于长度时重复前面的字节）
  }
}
static bool inflate(St& s) {
  static Huff flc, fdc; static bool fixedReady = false;
  int last;
  do {
    last = s.bits(1); int type = s.bits(2); if (s.err) return false;
    if (type == 0) {  // 不压缩的块：跳到字节边界，LEN 与 NLEN 互为反码
      s.bitbuf = 0; s.bitcnt = 0;
      if (s.pos + 4 > s.n) return false;
      unsigned len = s.in[s.pos] | (s.in[s.pos + 1] << 8), nlen = s.in[s.pos + 2] | (s.in[s.pos + 3] << 8); s.pos += 4;
      if ((len ^ 0xFFFF) != nlen || s.pos + len > s.n || s.out->size() + len > s.cap) return false;
      s.out->insert(s.out->end(), s.in + s.pos, s.in + s.pos + len); s.pos += len;
    } else if (type == 1) {  // 固定哈夫曼表
      if (!fixedReady) {
        short l[288];
        for (int i = 0; i < 288; i++) l[i] = (short)(i < 144 ? 8 : i < 256 ? 9 : i < 280 ? 7 : 8);  // 固定表的码长（RFC 1951 3.2.6）
        construct(flc, l, 288);
        for (int i = 0; i < 30; i++) l[i] = 5;
        construct(fdc, l, 30); fixedReady = true;
      }
      if (!codes(s, flc, fdc)) return false;
    } else if (type == 2) {  // 动态哈夫曼表
      static const unsigned char order[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15};
      int nlen = s.bits(5) + 257, ndist = s.bits(5) + 1, ncode = s.bits(4) + 4; if (s.err || nlen > 286 || ndist > 30) return false;
      short l[320]; int i;
      for (i = 0; i < 19; i++) l[order[i]] = (short)(i < ncode ? s.bits(3) : 0);
      Huff lc, dc; if (s.err || construct(lc, l, 19) != 0) return false;
      for (i = 0; i < nlen + ndist;) {
        int sym = decode(s, lc); if (sym < 0) return false;
        if (sym < 16) { l[i++] = (short)sym; continue; }
        int rep, val = 0;
        if (sym == 16) { if (i == 0) return false; val = l[i - 1]; rep = 3 + s.bits(2); }
        else if (sym == 17) rep = 3 + s.bits(3);
        else rep = 11 + s.bits(7);
        if (s.err || i + rep > nlen + ndist) return false;
        while (rep--) l[i++] = (short)val;
      }
      if (l[256] == 0) return false;
      int e = construct(lc, l, nlen); if (e < 0 || (e > 0 && nlen - lc.count[0] != 1)) return false;
      e = construct(dc, l + nlen, ndist); if (e < 0 || (e > 0 && ndist - dc.count[0] != 1)) return false;
      if (!codes(s, lc, dc)) return false;
    } else return false;
  } while (!last);
  return true;
}
// 解开 zlib 数据（RFC 1950）：maxOut 为最多解出的字节数；校验 Adler-32
static bool Zlib(const unsigned char* p, size_t n, std::vector<unsigned char>& out, size_t maxOut) {
  if (n < 6 || (p[0] & 0x0F) != 8 || ((p[0] << 8) | p[1]) % 31 != 0 || (p[1] & 0x20)) return false;
  St s = {p, n, 2, 0, 0, &out, maxOut, false}; out.clear();
  if (!inflate(s)) return false;
  if (s.pos + 4 > n) return false;
  unsigned want = ((unsigned)p[s.pos] << 24) | ((unsigned)p[s.pos + 1] << 16) | ((unsigned)p[s.pos + 2] << 8) | p[s.pos + 3];
  unsigned a = 1, b = 0; for (unsigned char c : out) { a = (a + c) % 65521; b = (b + a) % 65521; }
  return ((b << 16) | a) == want;
}
// 易语言「ZLIB压缩数据」：返回 1 解开了，0 不是这种格式，-1 是这种格式但数据坏了
static int EData(const std::vector<unsigned char>& in, std::vector<unsigned char>& out) {
  if (in.size() < 8 || in[0] != 0x0D || in[1] != 0x0F || in[2] != 0x3E || in[3] != 0x03) return 0;
  size_t len = in[4] | (in[5] << 8) | (in[6] << 16) | ((size_t)in[7] << 24);
  if (len == 0 || len > (256u << 20)) return -1;
  if (!Zlib(in.data() + 8, in.size() - 8, out, len) || out.size() != len) return -1;
  return 1;
}
}  // namespace ezl
// 准备要载入的 DLL：是 DLL 原文件（MZ 开头）就原样用；是易语言「ZLIB压缩数据」就解开写到 dst；都不是返回假并说明原因（不再交给 LoadLibrary，免得 Windows 弹“损坏的映像”）
static bool PrepareDll(const std::wstring& src, const std::wstring& dst, std::string& why, bool* unpacked) {
  std::vector<unsigned char> in; *unpacked = false;
  { FILE* f = _wfopen(src.c_str(), L"rb"); if (!f) { why = "打不开这个文件"; return false; }
    unsigned char b[65536]; size_t k; while ((k = fread(b, 1, sizeof b, f)) > 0) in.insert(in.end(), b, b + k); fclose(f); }
  std::vector<unsigned char> dec; const std::vector<unsigned char>* use = &in;
  if (!(in.size() >= 2 && in[0] == 'M' && in[1] == 'Z')) {
    int r = ezl::EData(in, dec);
    if (r == 0) { why = "既不是 DLL 原文件，也不是易语言「ZLIB压缩数据」的格式"; return false; }
    if (r < 0 || dec.size() < 2 || dec[0] != 'M' || dec[1] != 'Z') { why = "是易语言「ZLIB压缩数据」的格式，但解不开或解出来的不是 DLL（文件坏了）"; return false; }
    use = &dec; *unpacked = true;
  }
  if (src == dst && !*unpacked) return true;
  FILE* g = _wfopen(dst.c_str(), L"wb"); if (!g) { why = "写不出解好的 DLL"; return false; }
  bool ok = fwrite(use->data(), 1, use->size(), g) == use->size(); fclose(g);
  if (!ok) why = "解好的 DLL 没写全";
  return ok;
}
static std::wstring W8(const char* s) { int n = MultiByteToWideChar(CP_UTF8, 0, s, -1, nullptr, 0); std::wstring w(n, 0); MultiByteToWideChar(CP_UTF8, 0, s, -1, &w[0], n); w.resize(n - 1); return w; }
static INT_PTR Show(const char* t, const char* b, int ms, int fl = 0) { return Show_((INT_PTR)t, (INT_PTR)b, ms, fl); }
static std::vector<BYTE> BigRleBmp(int w, int h) {  // 一张声明尺寸很大、数据很小的 8 位游程编码 BMP（每行一段 255 个点，其余透明底色）
  std::vector<BYTE> rle; for (int y = 0; y < h; y++) { rle.push_back(255); rle.push_back(1); rle.push_back(0); rle.push_back(0); } rle.push_back(0); rle.push_back(1);
  BITMAPINFOHEADER bi = {}; bi.biSize = sizeof(bi); bi.biWidth = w; bi.biHeight = h; bi.biPlanes = 1; bi.biBitCount = 8; bi.biCompression = BI_RLE8; bi.biSizeImage = (DWORD)rle.size(); bi.biClrUsed = 256;
  BITMAPFILEHEADER fh = {}; fh.bfType = 0x4D42; fh.bfOffBits = sizeof(fh) + sizeof(bi) + 256 * 4; fh.bfSize = fh.bfOffBits + (DWORD)rle.size();
  std::vector<BYTE> out(fh.bfSize); memcpy(out.data(), &fh, sizeof(fh)); memcpy(out.data() + sizeof(fh), &bi, sizeof(bi));
  BYTE* pal = out.data() + sizeof(fh) + sizeof(bi); pal[4] = 0x7E; pal[5] = 0x8E; pal[6] = 0xFC;  // 1 号颜色：珊瑚色
  memcpy(out.data() + fh.bfOffBits, rle.data(), rle.size()); return out;
}
static std::string outDir;
static bool PatchSwdaTrue() {  // Wine 的 SetWindowDisplayAffinity 总是失败：只在本测试进程里把它改成「总是成功」，好把真机上才走的成功路径也测一遍
  static const BYTE stub[] = {0xB8, 1, 0, 0, 0, 0xC2, 8, 0};  // mov eax,1; ret 8（stdcall，两个参数）
  BYTE* p = (BYTE*)(void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetWindowDisplayAffinity"); DWORD old = 0;
  if (!p || !VirtualProtect(p, sizeof(stub), PAGE_EXECUTE_READWRITE, &old)) return false;
  memcpy(p, stub, sizeof(stub)); VirtualProtect(p, sizeof(stub), old, &old); FlushInstructionCache(GetCurrentProcess(), p, sizeof(stub)); return true;
}
static SIZE_T PrivateCommitted() {  // 本进程已提交的私有内存（逐段 VirtualQuery；Wine 不填 GetProcessMemoryInfo 的私有内存计数）
  SIZE_T sum = 0; MEMORY_BASIC_INFORMATION mi; BYTE* p = nullptr;
  while (VirtualQuery(p, &mi, sizeof(mi)) == sizeof(mi)) { if (mi.State == MEM_COMMIT && mi.Type == MEM_PRIVATE) sum += mi.RegionSize; p = (BYTE*)mi.BaseAddress + mi.RegionSize; if ((UINT_PTR)p >= 0x7FFF0000u) break; }
  return sum;
}
static int Snap(const char* name, int pct, int prog) { std::string p = outDir + "\\" + name; return (int)Snap_((INT_PTR)p.c_str(), pct, prog, 0); }
static void CardCenter(int* x, int* y) { int m = (int)Info_(15, 0, 0, 0); *x = m + (int)Info_(7, 0, 0, 0) / 2; *y = m + (int)Info_(8, 0, 0, 0) / 2; }
static DWORD WINAPI Stress(LPVOID p) {
  unsigned s = (unsigned)(UINT_PTR)p * 2654435761u;
  for (int i = 0; i < 150; i++) {
    s = s * 1103515245 + 12345; int r = (s >> 16) % 6;
    if (r == 0) Show("Stress", "parallel calls from many threads", 400 + (s % 600));
    else if (r == 1) Update_(Info_(1, 0, 0, 0), (INT_PTR)"Stress 2", (INT_PTR)"updated body text", 0);
    else if (r == 2) Close_(0, 0, 0, 0);
    else if (r == 3) Info_(2, Info_(1, 0, 0, 0), 0, 0);
    else if (r == 4) Set_(5, (s >> 8) % 3, 0, 0);
    else Set_(1, (INT_PTR)((s & 1) ? "ar" : "en"), 0, 0);
    Sleep(s % 7);
  }
  return 0;
}
// ---- 长时间压测（dntest.exe DLL 结果目录 --soak 秒数）：随机混合各种操作，定期记内存与句柄，看有没有缓慢泄漏、偶发的状态错乱
static unsigned g_rnd = 20261027u;
static unsigned Rnd(unsigned n) { g_rnd = g_rnd * 1664525u + 1013904223u; return (g_rnd >> 8) % n; }
static int RunSoak(int sec) {
  const char* langs[] = {"zh-Hans", "en", "ja", "ko", "zh-Hant", "es", "pt-BR", "fr", "de", "id", "th", "vi", "tr", "ar", "ru", "ms", "fil", "hi", "it"};
  std::string blanks = "Blank lines"; for (int i = 0; i < 400; i++) blanks += "\n"; blanks += "end";
  std::string longT; for (int i = 0; i < 300; i++) longT += u8"很长的正文，用来测试截断与省略。";
  const char* bodies[] = {u8"创建桌面快捷方式失败\n可能是被360安全卫士拦截，建议关闭后重开本软件。", "Hotkeys may not work while another program grabs them.", u8"ربما حظره 360 Total Security. ننصحك بإغلاقه ثم إعادة فتح هذا التطبيق.",
    u8"ไม่สามารถสร้างทางลัดบนเดสก์ท็อปได้ อาจถูกโปรแกรมรักษาความปลอดภัยบล็อก", u8"डेस्कटॉप शॉर्टकट नहीं बन सका। शायद सुरक्षा प्रोग्राम ने रोका।", u8"Emoji 😀🎵🔔 and symbols ✓ ✗ → ←",
    u8"Tab\there\x07 and BOM\uFEFF and line\u2029separator", blanks.c_str(), longT.c_str(), "Short."};
  const char* titles[] = {"", u8"提示", "Notice", u8"تنبيه", u8"แจ้งเตือน", u8"सूचना", u8"一个相当长的标题，用来测试标题最多两行时的均衡与省略效果"};
  printf("长时间压测 %d 秒（随机种子 %u）\n", sec, g_rnd); fflush(stdout);
  DWORD t0 = GetTickCount(), lastSample = t0, lastStop = t0; int ops = 0, shows = 0, stops = 0;
  struct Sample { DWORD t; SIZE_T mem; DWORD gdi, user, h; }; std::vector<Sample> smp; std::vector<SIZE_T> cold, warm;  // 每次停止之前（缓存已热）与之后（界面线程已退出、缓存已释放）的私有内存：同一时刻点、同一状态，才能前后相比
  auto sample = [&]() { Sample s; s.t = GetTickCount() - t0; s.mem = PrivateCommitted(); s.gdi = GetGuiResources(GetCurrentProcess(), GR_GDIOBJECTS); s.user = GetGuiResources(GetCurrentProcess(), GR_USEROBJECTS); s.h = 0; GetProcessHandleCount(GetCurrentProcess(), &s.h); smp.push_back(s);
    printf("  %4lu 秒：私有内存 %lu KB，GDI %lu，USER %lu，内核句柄 %lu，已操作 %d 次（显示 %d、重启 %d）\n", (unsigned long)(s.t / 1000), (unsigned long)(s.mem / 1024), (unsigned long)s.gdi, (unsigned long)s.user, (unsigned long)s.h, ops, shows, stops); fflush(stdout); };
  sample();
  while (GetTickCount() - t0 < (DWORD)sec * 1000) {
    unsigned op = Rnd(100); ops++;
    if (op < 30) { Show(titles[Rnd(7)], bodies[Rnd(10)], 300 + (int)Rnd(2700), (Rnd(5) == 0 ? 1 : 0) | (Rnd(2) ? 4 : 0) | (Rnd(3) == 0 ? 8 : 0)); shows++; }  // 1.2.1：醒目（光晕层、提醒）、尽量不被屏幕采集也混进来
    else if (op < 40) Update_(Info_(1, 0, 0, 0), (INT_PTR)titles[Rnd(7)], (INT_PTR)bodies[Rnd(10)], 0);
    else if (op < 50) Close_(0, 0, 0, 0);
    else if (op < 60) Set_(1, (INT_PTR)langs[Rnd(19)], 0, 0);
    else if (op < 64) Set_(5, Rnd(3), 0, 0);
    else if (op < 68) Set_(3, Rnd(3), 0xFF8A7A, 0);
    else if (op < 71) { unsigned r = Rnd(8); if (r == 0) Set_(9, Rnd(2), 0, 0); else if (r == 1) Set_(10, Rnd(2), 0, 0); else if (r == 2) Set_(11, Rnd(2), 0, 0); else if (r == 3) Set_(106, Rnd(3), 0, 0); else if (r == 4) Set_(111, 300 + (int)Rnd(3000), 0, 0); else Set_(8, Rnd(3), 0, 0); }  // 1.2.1：到场计时、跟随用户的屏幕、系统通知时长、人在不在、轻提醒间隔也随机切
    else if (op < 85) { int cx, cy; CardCenter(&cx, &cy); Mouse_(1, cx + (int)Rnd(9) - 4, cy + (int)Rnd(9) - 4, 0); }
    else if (op < 92) Mouse_(4, 0, 0, 0);
    else { int l = (int)Info_(16, 0, 0, 0), tp = (int)Info_(17, 0, 0, 0); if (Rnd(4) == 0) { Mouse_(2, l + 10, tp + 10, 0); Mouse_(3, l + 10, tp + 10, 0); } }
    if (GetTickCount() - lastStop > 15000) { warm.push_back(PrivateCommitted()); Stop_(0, 0, 0, 0); stops++; lastStop = GetTickCount(); Sleep(100); cold.push_back(PrivateCommitted()); }
    Sleep(30 + Rnd(90));
    MSG m; while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) DispatchMessageW(&m);
    if (GetTickCount() - lastSample >= 10000) { lastSample = GetTickCount(); sample(); }
  }
  Set_(9, 0, 0, 0); Set_(10, 0, 0, 0); Set_(11, 0, 0, 0); Set_(106, 0, 0, 0); Set_(111, 10000, 0, 0);
  Close_(0, 0, 0, 0); Wait(2000, PhaseIs, 0); Sleep(500); sample();
  // 同态相比：冷对冷（每次停止之后）、热对热（每次停止之前，缓存已热）——刚重启时缓存是空的，内存本来就低一截，冷热混着比会把正常的缓存算成“泄漏”
  size_t n3 = smp.size() / 3; const Sample& a = smp[n3 < 1 ? 1 : n3]; const Sample& z = smp.back();
  if (cold.size() >= 4 && warm.size() >= 4) {
    size_t c0 = cold.size() / 4, w3 = warm.size() / 3; SIZE_T pk2 = 0, pk3 = 0;
    long coldKB = (long)(((long long)cold.back() - (long long)cold[c0]) / 1024);
    for (size_t i = w3; i < 2 * w3; i++) if (warm[i] > pk2) pk2 = warm[i];
    for (size_t i = 2 * w3; i < warm.size(); i++) if (warm[i] > pk3) pk3 = warm[i];
    long warmKB = (long)(((long long)pk3 - (long long)pk2) / 1024);
    printf("停止之后（冷态）：第 %d 次到第 %d 次 %+ld KB；停止之前（热态）峰值：中间三分之一 %lu KB → 最后三分之一 %lu KB（%+ld KB）；句柄：GDI %+ld，USER %+ld，内核 %+ld\n",
           (int)c0 + 1, (int)cold.size(), coldKB, (unsigned long)(pk2 / 1024), (unsigned long)(pk3 / 1024), warmKB, (long)z.gdi - (long)a.gdi, (long)z.user - (long)a.user, (long)z.h - (long)a.h);
    Check(coldKB <= 1024 && warmKB <= 3 * 1024, "长时间压测：没有缓慢泄漏（停止后的内存冷态对冷态不涨，停止前的热态峰值不涨）");
  } else printf("  INFO 只停止重启了 %d 次（至少要 4 次，约 1 分钟以上）：时长太短，不做泄漏判定，只看句柄与状态\n", (int)cold.size());
  Check((a.gdi == 0 || z.gdi <= a.gdi + 8) && (a.user == 0 || z.user <= a.user + 4) && (a.h == 0 || z.h <= a.h + 8), "长时间压测：GDI、USER 对象与内核句柄不增长（Wine 不统计时以真机为准）");
  Check(Info_(1, 0, 0, 0) == 0 && Info_(20, 0, 0, 0) == 0, "长时间压测：结束后状态一致（没有在显示的）");
  printf("SUMMARY 通过 %d 失败 %d\n", passes, fails); return fails ? 1 : 0;
}
// 1.1.1：两张卡片截图里不一样的像素数（预乘后任一通道差超过 40）；读不出图返回 -1
static int InkDiff(const std::string& a, const std::string& b) {
  static ULONG_PTR tok = 0; if (!tok) { Gdiplus::GdiplusStartupInput in; Gdiplus::GdiplusStartup(&tok, &in, nullptr); }
  auto load = [](const std::string& p, std::vector<unsigned>& px, int& w, int& h) {
    std::wstring wp(p.size() + 1, 0); wp.resize(MultiByteToWideChar(CP_UTF8, 0, p.c_str(), -1, &wp[0], (int)wp.size()) - 1);
    Gdiplus::Bitmap bm(wp.c_str()); if (bm.GetLastStatus() != Gdiplus::Ok) return false;
    w = (int)bm.GetWidth(); h = (int)bm.GetHeight(); px.assign((size_t)w * h, 0);
    Gdiplus::Rect r(0, 0, w, h); Gdiplus::BitmapData bd;
    if (bm.LockBits(&r, Gdiplus::ImageLockModeRead, PixelFormat32bppPARGB, &bd) != Gdiplus::Ok) return false;
    for (int y = 0; y < h; y++) memcpy(&px[(size_t)y * w], (const BYTE*)bd.Scan0 + y * bd.Stride, (size_t)w * 4);
    bm.UnlockBits(&bd); return true; };
  std::vector<unsigned> x, y; int w1, h1, w2, h2;
  if (!load(a, x, w1, h1) || !load(b, y, w2, h2) || w1 != w2 || h1 != h2) return -1;
  int n = 0;
  for (size_t i = 0; i < x.size(); i++) { int d = 0; for (int sh = 0; sh <= 24; sh += 8) { int u = (int)((x[i] >> sh) & 255) - (int)((y[i] >> sh) & 255); if (u < 0) u = -u; if (u > d) d = u; } if (d > 40) n++; }
  return n;
}
// 1.1.2 测试用：另起一个线程弹真菜单（TrackPopupMenu 是模态的），菜单归这个线程的窗口所有、与卡片无关
struct DnMenuReq { POINT at; volatile HWND owner; volatile DWORD tid; };
static DnMenuReq g_mreq;
static DWORD WINAPI DnMenuThread(LPVOID) {
  WNDCLASSW wc = {}; wc.lpfnWndProc = DefWindowProcW; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"DnTestMenuOwner"; RegisterClassW(&wc);
  HWND o = CreateWindowExW(WS_EX_TOOLWINDOW, L"DnTestMenuOwner", L"", WS_POPUP, 0, 0, 1, 1, nullptr, nullptr, wc.hInstance, nullptr);
  HMENU m = CreatePopupMenu(); for (int i = 1; i <= 8; i++) AppendMenuW(m, MF_STRING, i, (L"Menu item " + std::to_wstring(i)).c_str());
  g_mreq.owner = o; g_mreq.tid = GetCurrentThreadId();
  // 不调 SetForegroundWindow（测试用 Esc / WM_CANCELMODE 关菜单，用不着“点外面关闭”）：所有者当了前台、关菜单后又被销毁时，Wine 会把前台交给不激活的卡片，
  // 卡片的界面线程随即卡在激活切换里（退场动画由 0.16 秒拖到约 2 秒），后面计时类的测试全受牵连——真 Windows 不会激活带 WS_EX_NOACTIVATE 的窗口，但测试不该依赖这一点
  TrackPopupMenu(m, TPM_RETURNCMD | TPM_NONOTIFY, g_mreq.at.x, g_mreq.at.y, 0, o, nullptr);
  DestroyMenu(m); DestroyWindow(o); return 0;
}
// 1.2.0：读 PNG 成预乘 BGRA（醒目卡片截图分析用）
static bool LoadPx(const std::string& p, std::vector<unsigned>& px, int& w, int& h) {
  static ULONG_PTR tok = 0; if (!tok) { Gdiplus::GdiplusStartupInput in; Gdiplus::GdiplusStartup(&tok, &in, nullptr); }
  std::wstring wp(p.size() + 1, 0); wp.resize(MultiByteToWideChar(CP_UTF8, 0, p.c_str(), -1, &wp[0], (int)wp.size()) - 1);
  Gdiplus::Bitmap bm(wp.c_str()); if (bm.GetLastStatus() != Gdiplus::Ok) return false;
  w = (int)bm.GetWidth(); h = (int)bm.GetHeight(); px.assign((size_t)w * h, 0);
  Gdiplus::Rect r(0, 0, w, h); Gdiplus::BitmapData bd;
  if (bm.LockBits(&r, Gdiplus::ImageLockModeRead, PixelFormat32bppPARGB, &bd) != Gdiplus::Ok) return false;
  for (int y = 0; y < h; y++) memcpy(&px[(size_t)y * w], (const BYTE*)bd.Scan0 + y * bd.Stride, (size_t)w * 4);
  bm.UnlockBits(&bd); return true;
}
static double Lum(unsigned rgb) { double c[3] = {((rgb >> 16) & 255) / 255.0, ((rgb >> 8) & 255) / 255.0, (rgb & 255) / 255.0}; for (double& v : c) v = v <= 0.04045 ? v / 12.92 : pow((v + 0.055) / 1.055, 2.4); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; }
static double Contr(unsigned a, unsigned b) { double x = Lum(a), y = Lum(b); if (x < y) { double s = x; x = y; y = s; } return (x + 0.05) / (y + 0.05); }
int main() {
  { typedef BOOL(WINAPI * SPDAC)(HANDLE); SPDAC f = (SPDAC)(void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetProcessDpiAwarenessContext"); if (!f || !f((HANDLE)(INT_PTR)-4)) SetProcessDPIAware(); }  // 按显示器 DPI 感知（同悬浮窗的测试程序）：放光标、取窗口位置都是物理像素，与 DLL 报的坐标一致——缩放不是 100% 的屏上也点得准
  if (GetFileType(GetStdHandle(STD_OUTPUT_HANDLE)) != FILE_TYPE_CHAR) fwrite("\xEF\xBB\xBF", 1, 3, stdout);  // 输出重定向到文件时先写 BOM：Win7 的记事本也能认出 UTF-8
  int argc = 0; LPWSTR* av = CommandLineToArgvW(GetCommandLineW(), &argc);
  if (argc < 3) { printf("usage: dntest.exe DeskNotify.dll outdir [cjkfont]\n"); return 2; }
  outDir = U8(av[2]); int soakSec = 0; if (argc >= 5 && !wcscmp(av[3], L"--soak")) soakSec = _wtoi(av[4]);
  std::string cjk = argc >= 4 && !soakSec ? U8(av[3]) : "";
  std::string dmg = argc >= 5 && !soakSec ? U8(av[4]) : "";  // 1.1.1：字形坏了的宿主字体（run_all.sh 有 fontTools 时用中文测试字体现场生成）
  { wchar_t full[MAX_PATH]; if (GetFullPathNameW(av[2], MAX_PATH, full, nullptr)) SHCreateDirectoryExW(nullptr, full, nullptr); }  // 截图目录不存在时先建好（含中间各级），直接运行本程序也不会因为目录不在而报截图失败
  std::wstring dllUse = av[1];  // 自测.bat 给的是项目资源 资源\dll_DeskNotify.Image.dat：那是易语言「ZLIB压缩数据」，先解开到结果目录（原来直接 LoadLibrary，Windows 报“损坏的映像”0xc000012f）
  { unsigned char mz[2] = {0, 0}; FILE* f = _wfopen(av[1], L"rb"); if (f) { if (fread(mz, 1, 2, f) != 2) mz[0] = 0; fclose(f); }
    if (mz[0] != 'M' || mz[1] != 'Z') {
      wchar_t full[MAX_PATH]; std::wstring dst = (GetFullPathNameW(av[2], MAX_PATH, full, nullptr) ? std::wstring(full) : std::wstring(av[2])) + L"\\DeskNotify.dll";
      std::string why; bool unpacked = false;
      if (!PrepareDll(av[1], dst, why, &unpacked)) { printf("FAIL 载入 DLL：%s（%s）\n", U8(av[1]).c_str(), why.c_str()); return 1; }
      printf("INFO %s 是易语言「ZLIB压缩数据」，已解开成 %s\n", U8(av[1]).c_str(), U8(dst.c_str()).c_str()); dllUse = dst;
    } }
  HMODULE M = LoadLibraryW(dllUse.c_str()); Check(M != nullptr, "载入 DLL");
  if (!M) return 1;
  const char* names[] = {"DN_GetVersion", "DN_Set", "DN_Show", "DN_Update", "DN_Close", "DN_GetInfo", "DN_Stop", "DN_Snapshot", "DN_TestMouse", "DN_TestWrap"};
  F4* ptrs[] = {&GetVersion_, &Set_, &Show_, &Update_, &Close_, &Info_, &Stop_, &Snap_, &Mouse_, &Wrap_};
  bool all = true; for (int i = 0; i < 10; i++) { *ptrs[i] = (F4)(void*)GetProcAddress(M, names[i]); if (!*ptrs[i]) { all = false; printf("  缺少 %s\n", names[i]); } }
  Check(all, "10 个导出接口齐全"); if (!all) return 1;
  Check(GetVersion_(0, 0, 0, 0) == 0x00010205 && Info_(10, 0, 0, 0) == 0x00010205, "版本 1.2.5");
  Check(Set_(6, (INT_PTR)Cb, 0, 0) == 1 && Set_(1, (INT_PTR)"en", 0, 0) == 1 && Set_(5, 1, 0, 0) == 1, "设置回调、语言、浅色");
  Check(Set_(99, 0, 0, 0) == 0 && Set_(5, 7, 0, 0) == 0 && Set_(4, 2, 0, 0) == 0, "不认识的设置、越界参数返回 0");
  if (soakSec > 0) return RunSoak(soakSec);
  // ---- 基本显示
  INT_PTR id = Show("Export finished", "Saved to the Downloads folder. You can drag it straight into your editor.", 8000);
  Check(id > 0 && Info_(1, 0, 0, 0) == id, "DN_Show 返回编号，立刻成为当前这条");
  Check(Wait(1500, PhaseIs, 2), "进场动画结束后处于显示阶段");
  HWND h = (HWND)Info_(3, 0, 0, 0); LONG ex = GetWindowLongW(h, GWL_EXSTYLE);
  Check(IsWindowVisible(h) && (ex & WS_EX_LAYERED) && (ex & WS_EX_TOOLWINDOW) && (ex & WS_EX_TOPMOST) && (ex & WS_EX_NOACTIVATE), "窗口可见，分层＋工具窗口＋置顶＋不激活");
  { int r = (int)Info_(2, id, 0, 0); Check(r > 6000 && r <= 8000, "剩余毫秒在合理范围"); }
  Check((HMODULE)GetClassLongPtrW(h, GCLP_HMODULE) == M, "窗口类登记在 DLL 自己名下（不会与宿主或别的模块的同名类相串）");
  { wchar_t wt[512] = L""; GetWindowTextW(h, wt, 512); Check(wcsstr(wt, L"Export finished") && wcsstr(wt, L"Downloads"), "窗口标题＝提示内容（读屏软件能读到）"); }
  {  // 位置：主屏工作区右下角，留 16 像素（按 DPI）
    int x = (int)Info_(13, 0, 0, 0), y = (int)Info_(14, 0, 0, 0), m = (int)Info_(15, 0, 0, 0), w = (int)Info_(7, 0, 0, 0), hh = (int)Info_(8, 0, 0, 0), dpi = (int)Info_(6, 0, 0, 0);
    int gapR = (int)Info_(28, 0, 0, 0) - (x + m + w), gapB = (int)Info_(29, 0, 0, 0) - (y + m + hh), want = 16 * dpi / 96;
    printf("  卡片 %dx%d，DPI %d，离工作区右 %d 下 %d\n", w, hh, dpi, gapR, gapB);
    Check(abs(gapR - want) <= 2 && abs(gapB - want) <= 2, "贴着主屏工作区右下角（任务栏在哪一边都按工作区算）");
  }
  // ---- 不抢焦点
  {
    WNDCLASSW wc = {}; wc.lpfnWndProc = DefWindowProcW; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"DnTestFg"; RegisterClassW(&wc);
    HWND fg = CreateWindowW(L"DnTestFg", L"fg", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 100, 100, 300, 200, nullptr, nullptr, wc.hInstance, nullptr);
    SetForegroundWindow(fg); MSG m; for (int i = 0; i < 20; i++) { while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) DispatchMessageW(&m); Sleep(10); }
    HWND before = GetForegroundWindow();  // 真 Windows 上测试程序未必拿得到前台（系统的前台锁）：以显示之前的前台窗口为准
    if (before != fg) printf("  INFO 测试窗口没拿到前台（系统前台锁），改为核对显示前后前台窗口不变\n");
    INT_PTR i2 = Show("Focus", "Showing must not take focus away from the window you are using.", 3000, 1);
    Wait(1500, EvFor, id); Wait(1500, PhaseIs, 2);  // 先等旧的一条的回调（替换正在显示的那条时，处理新命令之前阶段仍是“显示”）
    Check(GetForegroundWindow() == before && GetForegroundWindow() != h && GetActiveWindow() != h, "显示（含强制显示）不抢焦点：前台窗口不变");
    Check(EvOf(id) == 3, "被新的一条替换：旧的一条回调事件 3");
    Close_(i2, 0, 0, 0); DestroyWindow(fg);
  }
  // ---- 1.1.2：强制显示每秒提到最上层时，不压在开着的弹出菜单上（任何程序的右键菜单、托盘菜单：类名 #32768 的可见窗口）。卡片默认在右下角，正好是托盘菜单弹出的地方；
  // 原来菜单开着时也照提，打开菜单后 1 秒内卡片就盖到菜单上。这里的菜单归测试线程的窗口所有、与卡片无关，Wine 里照样能复现（真机上顶层弹出菜单本来就没有所有者）
  {
    bool wine = GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "wine_get_version") != nullptr;
    INT_PTR i4 = Show("Stay on top", "Forced display re-checks every second that the card is on top.", 20000, 1);
    Wait(1500, PhaseIs, 2); HWND card = (HWND)Info_(3, 0, 0, 0); RECT cr; GetWindowRect(card, &cr);
    auto MenuOf = [](DWORD tid) -> HWND { for (HWND w = FindWindowExW(nullptr, nullptr, L"#32768", nullptr); w; w = FindWindowExW(nullptr, w, L"#32768", nullptr)) if (IsWindowVisible(w) && GetWindowThreadProcessId(w, nullptr) == tid) return w; return nullptr; };
    auto Above = [](HWND a, HWND b) { for (HWND w = GetTopWindow(nullptr); w; w = GetWindow(w, GW_HWNDNEXT)) { if (w == a) return true; if (w == b) return false; } return false; };
    HWND menu = nullptr; HANDLE th = nullptr;
    for (int attempt = 0; attempt < 3 && !menu; attempt++) {
      g_mreq.at.x = cr.left + 40; g_mreq.at.y = cr.top + 20; g_mreq.owner = nullptr; g_mreq.tid = 0;
      th = CreateThread(nullptr, 0, DnMenuThread, nullptr, 0, nullptr);
      DWORD t0 = GetTickCount(); while (GetTickCount() - t0 < 5000 && !(g_mreq.tid && (menu = MenuOf(g_mreq.tid)))) Sleep(20);
      if (menu) { Sleep(300); if (!IsWindowVisible(menu)) menu = nullptr; }  // Wine：菜单偶尔刚弹出就因激活转到桌面而取消（X11 焦点跟随指针，见 XhhFloat 测试里的说明），只在 Wine 里重试
      if (!menu) { if (g_mreq.owner) PostMessageW(g_mreq.owner, WM_CANCELMODE, 0, 0); WaitForSingleObject(th, 3000); CloseHandle(th); th = nullptr; if (!wine) break; printf("  INFO Wine：菜单没开成或刚开就关了，重试\n"); }
    }
    Check(menu != nullptr, "1.1.2 强制显示：测试用的弹出菜单开在卡片上（前提）");
    if (menu) {
      Sleep(2600);  // 每秒的确认至少走两次
      bool open = IsWindowVisible(menu);
      Check(open && !Above(card, menu), "1.1.2 强制显示：菜单开着时每秒的确认不把卡片提到菜单上面（原来 1 秒内就盖到菜单上）");
      PostMessageW(menu, WM_KEYDOWN, VK_ESCAPE, 0); Sleep(200); if (IsWindowVisible(menu) && g_mreq.owner) PostMessageW(g_mreq.owner, WM_CANCELMODE, 0, 0);
      WaitForSingleObject(th, 3000); CloseHandle(th);
      WNDCLASSW cc = {}; cc.lpfnWndProc = DefWindowProcW; cc.hInstance = GetModuleHandleW(nullptr); cc.lpszClassName = L"DnTestCover"; RegisterClassW(&cc);
      HWND cover = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE, L"DnTestCover", L"", WS_POPUP, cr.left, cr.top, 40, 20, nullptr, nullptr, cc.hInstance, nullptr);
      SetWindowPos(cover, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
      bool coverAbove = Above(cover, card); Sleep(1600);
      Check(coverAbove && Above(card, cover), "1.1.2 强制显示：菜单关掉后照常每秒确认（别的置顶窗口盖上来，1 秒内卡片回到它上面）");
      DestroyWindow(cover); UnregisterClassW(L"DnTestCover", cc.hInstance);
    }
    Close_(i4, 0, 0, 0); Wait(1500, PhaseIs, 0);
  }
  // ---- 倒计时
  {
    DWORD t0 = GetTickCount(); INT_PTR i3 = Show("Timer", "Closes by itself.", 1500);
    bool got = Wait(4000, EvFor, i3); DWORD dt = GetTickCount() - t0;
    printf("  自动关闭用时 %lu 毫秒（设定 1500）\n", (unsigned long)dt);
    Check(got && EvOf(i3) == 1 && dt >= 1400 && dt <= 2100, "倒计时到点自动关闭（事件 1，误差在一帧之内）");
    Check(Info_(1, 0, 0, 0) == 0, "关闭后当前编号为 0");
    Check(Wait(1500, PhaseIs, 0) && Wait(500, [](INT_PTR) { return Info_(27, 0, 0, 0) == 0; }, 0), "退场动画后窗口隐藏");
  }
  // ---- 悬停暂停
  {
    INT_PTR i4 = Show("Hover", "Hover pauses the countdown so long messages can be read.", 1200);
    Wait(1500, PhaseIs, 2);
    int cx, cy; CardCenter(&cx, &cy); int wx = (int)Info_(13, 0, 0, 0), wy = (int)Info_(14, 0, 0, 0);
    SetCursorPos(wx + cx, wy + cy); Mouse_(1, cx, cy, 0);
    Check(Info_(4, 0, 0, 0) == 1, "鼠标指着卡片：处于悬停");
    Sleep(2000); { MSG m; while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) DispatchMessageW(&m); }
    int r = (int)Info_(2, i4, 0, 0);
    Check(Info_(1, 0, 0, 0) == i4 && r > 0, "悬停 2 秒（超过设定的 1.2 秒）仍在显示，倒计时暂停");
    SetCursorPos(5, 5); Mouse_(4, 0, 0, 0);
    int r2 = (int)Info_(2, i4, 0, 0); printf("  离开时剩余 %d 毫秒\n", r2);
    Check(r2 >= 900, "移开后至少再留约 1 秒");
    DWORD t0 = GetTickCount(); bool got = Wait(3500, EvFor, i4); DWORD dt = GetTickCount() - t0;
    Check(got && EvOf(i4) == 1 && dt >= 800, "离开后接着倒计时并自动关闭");
  }
  // ---- 关闭键
  {
    INT_PTR i5 = Show("Close button", "Click the x to dismiss.", 8000);
    Wait(1500, PhaseIs, 2);
    int l = (int)Info_(16, 0, 0, 0), t = (int)Info_(17, 0, 0, 0), r = (int)Info_(18, 0, 0, 0), b = (int)Info_(19, 0, 0, 0), cx = (l + r) / 2, cy = (t + b) / 2;
    Check(r - l >= 24 && b - t >= 24, "关闭键可点范围不小于 24×24（WCAG 2.2 最小目标尺寸）");
    int wx = (int)Info_(13, 0, 0, 0), wy = (int)Info_(14, 0, 0, 0); SetCursorPos(wx + cx, wy + cy);
    Sleep((int)GetDoubleClickTime());  // 1.2.2：出现后双击时间以内按下关闭键不算，先等过这段
    Mouse_(1, cx, cy, 0); Mouse_(2, cx, cy, 0); Mouse_(3, cx, cy, 0);
    Check(Wait(1000, EvFor, i5) && EvOf(i5) == 2, "点关闭键：事件 2");
    SetCursorPos(5, 5); Mouse_(4, 0, 0, 0);
    INT_PTR i6 = Show("Not the button", "Clicking elsewhere does not close.", 8000); Wait(1500, PhaseIs, 2);
    int x2, y2; CardCenter(&x2, &y2); Mouse_(1, x2, y2, 0); Mouse_(2, x2, y2, 0); Mouse_(3, x2, y2, 0); Mouse_(4, 0, 0, 0); Sleep(200);
    Check(Info_(1, 0, 0, 0) == i6, "点卡片别处不会关闭");
    Check(Close_(i6, 0, 0, 0) == 1 && Wait(1000, EvFor, i6) && EvOf(i6) == 3 && Info_(1, 0, 0, 0) == 0, "DN_Close：事件 3，当前编号清零");
    Check(Close_(i6, 0, 0, 0) == 0, "再关同一条返回 0");
  }
  // ---- 改文字
  {
    INT_PTR i7 = Show("Update", "Short.", 8000); Wait(1500, PhaseIs, 2); int h1 = (int)Info_(8, 0, 0, 0);
    Check(Update_(i7, (INT_PTR)"Update", (INT_PTR)"Now a much longer body text that has to wrap onto several lines, so the card must grow taller to fit every line of it.", 0) == 1, "DN_Update 当前这条返回 1");
    Sleep(300); int h2 = (int)Info_(8, 0, 0, 0); printf("  卡片高 %d → %d\n", h1, h2);
    Check(h2 > h1, "改成长文字后卡片变高");
    Check(Update_(i7 + 1000, (INT_PTR)"x", (INT_PTR)"y", 0) == 0, "改不存在的编号返回 0");
    Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);
  }
  // ---- 断行
  {
    auto wrap = [&](const char* lang, const wchar_t* t, float w, std::vector<std::pair<int, int>>& out) {
      Set_(1, (INT_PTR)lang, 0, 0); int buf[512]; std::string u = U8(t); int n = (int)Wrap_((INT_PTR)u.c_str(), (INT_PTR)(w * 10), (INT_PTR)buf, 512); out.clear();
      for (int i = 0; i < n && 2 * i + 1 < 512; i++) out.push_back({buf[2 * i], buf[2 * i + 1]}); return n; };
    std::vector<std::pair<int, int>> L;
    std::wstring th = W8(u8"360 Total Security อาจทำให้ปุ่มลัดของเสียงเอฟเฟกต์ใช้งานไม่ได้ แนะนำให้ปิดโปรแกรมนั้นแล้วเปิดแอปนี้ใหม่");
    int n = wrap("th", th.c_str(), 120, L); bool ok = n > 1;
    for (auto& s : L) { wchar_t c0 = th[s.first]; if (c0 == 0x0E31 || (c0 >= 0x0E34 && c0 <= 0x0E3A) || (c0 >= 0x0E47 && c0 <= 0x0E4E)) ok = false; }
    printf("  泰语断成 %d 行\n", n); Check(ok, "泰语：没有一行以上下标元音、声调符号开头（不拆字符簇）");
    std::wstring hi = W8(u8"360 Total Security साउंड हॉटकी को काम करने से रोक सकता है। कृपया इसे बंद करें और फिर यह ऐप दोबारा खोलें।");
    n = wrap("hi", hi.c_str(), 110, L); ok = n > 1; for (auto& s : L) { wchar_t c0 = hi[s.first]; if ((c0 >= 0x0900 && c0 <= 0x0903) || (c0 >= 0x093A && c0 <= 0x094F) || (c0 >= 0x0951 && c0 <= 0x0957) || c0 == 0x0962 || c0 == 0x0963) ok = false; }
    Check(ok, "印地语：没有一行以元音符号、鼻化符号开头");
    std::wstring zh = W8(u8"F1、F2、F3 已被「注册模式」独占，在其它软件里会失去原来的作用（例如打不出字）。请在「其它设置 → 快捷键模式」切回「监听模式」，或把这些快捷键改成 Ctrl/Alt 组合键或小键盘。");
    n = wrap("zh-Hans", zh.c_str(), 150, L); ok = n > 2; int q1 = (int)zh.find(L"「监听模式」"), q2 = (int)zh.find(L"（例如打不出字）");
    for (auto& s : L) { if (s.first > q1 && s.first < q1 + 6) ok = false; if (s.first > q2 && s.first < q2 + 8) ok = false; wchar_t c0 = zh[s.first]; if (wcschr(L"，。、）」", c0)) ok = false; }
    Check(ok, "中文：短引号词、短括注不拆开，行首没有逗号句号等标点");
    std::wstring en = L"It may have been blocked by 360 Total Security. We suggest closing it and then reopening this app.";
    n = wrap("en", en.c_str(), 160, L); ok = n > 1; std::wstring joined; for (auto& s : L) { if (en[s.first] == L' ' || en[s.second - 1] == L' ') ok = false; joined += en.substr(s.first, s.second - s.first) + L" "; }
    joined.pop_back(); Check(ok && joined == en, "英文：按词断开、行首行尾没有空格、一个字都不丢");
    Set_(1, (INT_PTR)"en", 0, 0);
  }
  // ---- 图标、强调色
  {
    Set_(1, (INT_PTR)"en", 0, 0); INT_PTR i8 = Show("Icon", "Host icon by default.", 6000); Wait(1500, PhaseIs, 2);
    int src = (int)Info_(26, 0, 0, 0); unsigned ac = (unsigned)Info_(9, 0, 0, 0); printf("  宿主图标原图 %d 像素，取到的强调色 #%06X\n", src, ac);
    Check(src >= 22, "默认取宿主程序的图标（按要画的大小取不小于它的一张）");
    Check(Info_(9, 0, 0, 0) != -1 && ((ac >> 16) & 255) > ((ac >> 8) & 255) && ((ac >> 16) & 255) > (ac & 255), "强调色从图标里取（小红花图标→暖红色）");
    Set_(3, 2, 0x2D8CFF, 0); Sleep(200); Check((unsigned)Info_(9, 0, 0, 0) == 0x2D8CFF, "指定强调色");
    Set_(3, 1, 0, 0); Sleep(200); Check(Info_(9, 0, 0, 0) == -1, "不用强调色（中性灰细线）");
    Set_(3, 0, 0, 0); Set_(4, 1, 0, 0); Sleep(200); Check(Info_(26, 0, 0, 0) == 0 && Info_(9, 0, 0, 0) == -1, "不显示图标：没有图标、也就没有从图标取的强调色");
    Snap("noicon_en_light_100.png", 100, 600);
    std::vector<BYTE> png; { wchar_t me[MAX_PATH]; GetModuleFileNameW(nullptr, me, MAX_PATH); wchar_t* sl = wcsrchr(me, L'\\'); if (sl) *sl = 0; FILE* f = _wfopen((std::wstring(me) + L"\\other_256.png").c_str(), L"rb"); if (f) { BYTE b[65536]; size_t k; while ((k = fread(b, 1, sizeof b, f)) > 0) png.insert(png.end(), b, b + k); fclose(f); } }
    if (!png.empty()) { Set_(4, 2, (INT_PTR)png.data(), (INT_PTR)png.size()); Sleep(300); unsigned a2 = (unsigned)Info_(9, 0, 0, 0); printf("  图片数据图标的强调色 #%06X\n", a2);
      Check(Info_(26, 0, 0, 0) > 0 && (a2 & 255) > ((a2 >> 16) & 255), "图标用图片数据（PNG）：蓝色图标→蓝色强调色"); Snap("other_icon_light_100.png", 100, 600); }
    Set_(4, 0, 0, 0); Close_(i8, 0, 0, 0); Wait(1000, PhaseIs, 0);
  }
  // ---- 宿主字体、截图（多语言 × 深浅 × 缩放）
  if (!cjk.empty()) { Check(Set_(2, (INT_PTR)cjk.c_str(), (INT_PTR)cjk.c_str(), 0) == 1, "设置宿主字体文件"); }
  struct S { const char* lang; const char* title; const char* body; } cases[] = {
    {"zh-Hans", u8"360安全卫士可能会导致音效功能的快捷键失效", u8"建议关闭后重开本软件"},
    {"zh-Hans", "", u8"F1、F2、F3 已被「注册模式」独占，在其它软件里会失去原来的作用（例如打不出字）。请在「其它设置 → 快捷键模式」切回「监听模式」，或把这些快捷键改成 Ctrl/Alt 组合键或小键盘。"},
    {"en", "Couldn't create the desktop shortcut.", "It may have been blocked by 360 Total Security. We suggest closing it and then reopening this app."},
    {"ar", u8"تعذّر إنشاء اختصار سطح المكتب.", u8"ربما حظره 360 Total Security. ننصحك بإغلاقه ثم إعادة فتح هذا التطبيق."}};
  int ci = 0;
  for (auto& c : cases) {
    Set_(1, (INT_PTR)c.lang, 0, 0);
    for (int dark = 0; dark < 2; dark++) {
      Set_(5, dark ? 2 : 1, 0, 0); INT_PTR i9 = Show(c.title, c.body, 9000); Wait(1500, PhaseIs, 2);
      if (ci == 0 && dark == 0 && !cjk.empty()) Check(Info_(30, 0, 0, 0) == 1, "中文用上了宿主给的字体文件");
      { int miss = (int)Info_(33, 0, 0, 0); if (strcmp(c.lang, "ar")) { char nm2[128]; sprintf(nm2, "%s：逐段回退后不缺字（不会出现方框），缺 %d", c.lang, miss); Check(miss == 0, nm2); } else printf("  INFO 阿拉伯语缺字 %d（测试环境没有阿拉伯文字体时会缺）\n", miss); }
      if (!strcmp(c.lang, "ar") && dark == 0) { int l = (int)Info_(16, 0, 0, 0), m = (int)Info_(15, 0, 0, 0), w = (int)Info_(7, 0, 0, 0); Check(l < m + w / 2, "阿拉伯语：整体从右往左，关闭键在左边"); }
      for (int pct : {100, 150, 200}) {
        char nm[96]; sprintf(nm, "case%d_%s_%s_%d.png", ci, c.lang, dark ? "dark" : "light", pct);
        int w0 = (int)Info_(7, 0, 0, 0); Check(Snap(nm, pct, 640) == 1, nm);
        if (pct != 100) { (void)w0; }
      }
      Close_(i9, 0, 0, 0); Wait(1000, PhaseIs, 0);
    }
    ci++;
  }
  Set_(1, (INT_PTR)"en", 0, 0); Set_(5, 1, 0, 0);
  // ---- 长文字
  {
    std::string longT(300, 'W'); std::string longB; for (int i = 0; i < 30; i++) longB += "Line number " + std::to_string(i) + " of a very long notification body.\n";
    INT_PTR i10 = Show(longT.c_str(), longB.c_str(), 6000); Wait(1500, PhaseIs, 2);
    Check(Info_(24, 0, 0, 0) <= 2 && Info_(25, 0, 0, 0) <= 8, "很长的标题最多 2 行、正文最多 8 行（多出的省略）");
    Snap("long_en_light_100.png", 100, 300); Close_(i10, 0, 0, 0); Wait(1000, PhaseIs, 0);
  }
  // ---- 高对比度、关闭动画
  { Set_(5, 3, 0, 0); INT_PTR i11 = Show("High contrast", "Uses the system colors.", 6000); Wait(1500, PhaseIs, 2); Check(Snap("hc_en_100.png", 100, 500) == 1, "高对比度主题可绘制"); Close_(i11, 0, 0, 0); Wait(1000, PhaseIs, 0); Set_(5, 1, 0, 0); }
  { Set_(8, 2, 0, 0); INT_PTR i12 = Show("No animation", "Appears and disappears at once.", 6000); Check(Wait(200, PhaseIs, 2), "关闭动画：立刻显示"); Close_(i12, 0, 0, 0); Check(Wait(200, PhaseIs, 0), "关闭动画：立刻消失"); Set_(8, 0, 0, 0); }
  // ---- 易语言接入流程模拟（按 窗口程序集_主窗口 里 弹窗提醒_开启W / 弹窗提醒_关闭 / 弹窗提醒_显示中 的逻辑，回调按“投递到主线程再处理”走）
  {
    Set_(1, (INT_PTR)"zh-Hans", 0, 0); Set_(5, 1, 0, 0); Set_(8, 0, 0, 0);
    struct QI { std::string t, b; int ms; }; struct Epl { INT_PTR cur = 0; bool restore = false; int restSec = 0; std::string rt, rb; LONG seen = 0; std::vector<QI> q; } E;
    E.seen = evN;
    auto show = [&](const char* t, const char* b, int ms, int fl) { E.cur = Show(t, b, ms, fl); return E.cur; };
    auto closeE = [&]() {  // 弹窗提醒_关闭：收起 → 有被顶替的就接着显示 → 还没有在显示的就按先后显示等候队列里的（1.2.0 起排队不再阻塞，见 弹窗提醒_排队_接着显示）
      if (E.cur) { Close_(E.cur, 0, 0, 0); E.cur = 0; }
      if (E.restore && E.restSec > 0) { E.restore = false; show(E.rt.c_str(), E.rb.c_str(), E.restSec * 1000, 0); }
      while (!E.cur && !E.q.empty()) { QI it = E.q.front(); E.q.erase(E.q.begin()); show(it.t.c_str(), it.b.c_str(), it.ms, 0); }
    };
    auto pump = [&]() {  // 主线程处理投递来的事件（弹窗提醒_新版_事件）
      while (E.seen < evN) { LONG i = E.seen++; int ev = evLog[i][0], id = evLog[i][1]; if ((ev == 1 || ev == 2) && id && id == E.cur) closeE(); }
    };
    auto showing = [&]() {  // 弹窗提醒_显示中（含自愈：DLL 已关、回调还在路上）
      if (E.cur) { if (Info_(1, 0, 0, 0) == E.cur) return true; closeE(); if (E.cur) return true; }
      return false;
    };
    INT_PTR a = show(u8"360安全卫士可能会导致音效功能的快捷键失效", u8"建议关闭后重开本软件", 4000, 0); Sleep(1000); pump();
    // 更要紧的“注册模式体检”顶替：记下剩余秒（向上取整），直接 DN_Show（替换）
    Check(showing(), "模拟：A 正在显示");
    E.restore = true; E.restSec = (int)((Info_(2, a, 0, 0) + 999) / 1000); E.rt = u8"360安全卫士可能会导致音效功能的快捷键失效"; E.rb = u8"建议关闭后重开本软件";
    INT_PTR b = show("", u8"F1、F2 已被「注册模式」独占……", 1500, 1);
    printf("  模拟：A 被顶替时剩 %d 秒\n", E.restSec);
    Check(E.restSec >= 2 && E.restSec <= 4, "模拟：顶替时记下的剩余秒数合理");
    DWORD t0 = GetTickCount(); while (GetTickCount() - t0 < 5000 && E.cur == b) { pump(); Sleep(20); }
    Check(EvOf(a) == 3, "模拟：A 被替换，事件 3（易语言不处理）");
    INT_PTR a2 = E.cur; Check(a2 && a2 != b && Info_(1, 0, 0, 0) == a2, "模拟：B 倒计时到了，被顶替的 A 接着显示");
    int r = (int)Info_(2, a2, 0, 0); printf("  模拟：恢复后的 A 设定 %d 秒，现在剩 %d 毫秒\n", E.restSec, r);
    Check(r > (E.restSec - 1) * 1000 && r <= E.restSec * 1000, "模拟：恢复的 A 按剩余秒数接着显示");
    // 排队（1.2.0 起不再阻塞调用方）：A 正显示时 C 排进等候队列、调用方立即返回；A 关掉后（弹窗提醒_关闭 的最后）按先后接着显示 C
    DWORD tq = GetTickCount(); bool queued = showing(); if (queued) E.q.push_back({u8"创建桌面快捷方式失败", u8"可能是被360安全卫士拦截，建议关闭后重开本软件", 1000}); DWORD tret = GetTickCount() - tq;
    while (GetTickCount() - tq < 10000 && !(E.cur && E.cur != a2)) { pump(); Sleep(20); }
    INT_PTR c = E.cur;
    Check(queued && tret < 200 && EvOf(a2) == 1 && c && c != a2 && Info_(1, 0, 0, 0) == c && E.q.empty(), "模拟：排队的 C 不阻塞调用方（立即返回），A 关掉后接着显示");
    // 自愈：回调还没处理时，显示中 发现 DLL 已关，就地按关闭处理
    Sleep(2000); bool s2 = showing(); Check(!s2 && E.cur == 0, "模拟：DLL 已关、回调未处理时 显示中 自愈为“没在显示”");
    pump(); Check(E.cur == 0, "模拟：迟到的回调编号已不是当前这条，不重复处理");
    Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0); Set_(1, (INT_PTR)"en", 0, 0);
  }
  // ---- 段落方向按内容、超长输入、所有字体都没有的字、停止与显示并发
  {
    Set_(1, (INT_PTR)"ar", 0, 0); INT_PTR a1 = Show(u8"创建桌面快捷方式失败", u8"可能是被360安全卫士拦截", 6000); Wait(1500, PhaseIs, 2);
    Check(a1 && Info_(34, 0, 0, 0) == 0, "阿拉伯语界面显示中文原文：段落仍从左往右（句末标点不会跑到行首）");
    Snap("rtl_layout_ltr_text_100.png", 100, 640);
    Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);  // 先关掉再显示：替换正在显示的那条时，界面线程处理新命令之前阶段仍是“显示”，读到的会是上一条
    INT_PTR a2 = Show(u8"تعذّر إنشاء اختصار سطح المكتب.", u8"ربما حظره 360 Total Security.", 6000); Wait(1500, PhaseIs, 2);
    printf("  段落方向读数：阿拉伯语界面＋阿拉伯文 %d\n", (int)Info_(34, 0, 0, 0));
    Check(a2 && Info_(34, 0, 0, 0) == 3, "阿拉伯语界面显示阿拉伯文：标题、正文都从右往左");
    Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);
    Set_(1, (INT_PTR)"en", 0, 0); INT_PTR a3 = Show("Notice", u8"ربما حظره 360 Total Security.", 6000); Wait(1500, PhaseIs, 2);
    printf("  段落方向读数：英文界面＋阿拉伯文正文 %d\n", (int)Info_(34, 0, 0, 0));
    Check(a3 && Info_(34, 0, 0, 0) == 2, "英文界面显示阿拉伯文正文：正文按内容从右往左");
    Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);
    if (!cjk.empty()) {  // 宿主字体文件还没写完（如字体包正在解压）：不闪退、先用系统字体；写完后不必再交代，下一条自动用上；也不占着文件妨碍写入
      auto Wd = [](const std::string& u) { int n = MultiByteToWideChar(CP_UTF8, 0, u.c_str(), -1, nullptr, 0); std::wstring w(n, 0); MultiByteToWideChar(CP_UTF8, 0, u.c_str(), -1, &w[0], n); w.resize(n - 1); return w; };
      std::wstring src = Wd(cjk), part = Wd(outDir) + L"\\partial_font.ttf"; std::string data;
      { HANDLE f = CreateFileW(src.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr); DWORD n = GetFileSize(f, nullptr), got = 0; data.resize(n); ReadFile(f, &data[0], n, &got, nullptr); CloseHandle(f); }
      auto put = [&](size_t len) { HANDLE f = CreateFileW(part.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr); if (f == INVALID_HANDLE_VALUE) return false; DWORD w = 0; bool ok = WriteFile(f, data.data(), (DWORD)len, &w, nullptr) && w == len; CloseHandle(f); return ok; };
      put(data.size() * 4 / 10); std::string pu = U8(part.c_str());
      Set_(1, (INT_PTR)"zh-Hans", 0, 0); Set_(2, (INT_PTR)pu.c_str(), (INT_PTR)pu.c_str(), 0);
      INT_PTR g1 = Show(u8"字体包正在解压", u8"字体文件只写了一部分：先用系统字体显示，不会闪退。", 6000); bool s1 = Wait(2000, PhaseIs, 2); Sleep(200);
      bool c1 = Info_(30, 0, 0, 0) == 0 && Info_(33, 0, 0, 0) == 0;
      bool w2 = put(data.size());  // 接着写完（DLL 若占着这个文件，这里会写不进去）
      Sleep(2200); Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);
      INT_PTR g2 = Show(u8"字体包正在解压", u8"字体文件只写了一部分：先用系统字体显示，不会闪退。", 6000); bool s2 = Wait(2000, PhaseIs, 2); Sleep(200);
      printf("  字体文件只写了 40%%：显示 %d、用了宿主字体 %d；写完（写入%s）之后同样的文字：显示 %d、用了宿主字体 %d\n", (int)s1, (int)c1 ? 0 : 1, w2 ? "成功" : "失败", (int)s2, (int)Info_(30, 0, 0, 0));
      Check(g1 && s1 && c1, "宿主字体文件还没写完：照常显示、改用系统字体（不交给字体引擎，不会读到文件外面）");
      Check(w2 && g2 && s2 && Info_(30, 0, 0, 0) == 1, "字体文件写完后不必再交代：下一条自动用上宿主字体；期间不占着文件、不妨碍写入");
      Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0); Set_(2, (INT_PTR)cjk.c_str(), (INT_PTR)cjk.c_str(), 0); DeleteFileW(part.c_str());
    }
    std::string huge; for (int i = 0; i < 20000; i++) huge += u8"超长正文测试。";
    DWORD t0 = GetTickCount(); INT_PTR a4 = Show(std::string(5000, 'T').c_str(), huge.c_str(), 6000); DWORD dt = GetTickCount() - t0;
    bool shown = Wait(3000, PhaseIs, 2); DWORD dt2 = GetTickCount() - t0;
    printf("  14 万字正文：DN_Show 返回 %lu 毫秒，显示出来 %lu 毫秒，正文 %d 行\n", (unsigned long)dt, (unsigned long)dt2, (int)Info_(25, 0, 0, 0));
    Check(a4 && dt < 200 && shown && Info_(25, 0, 0, 0) <= 8 && Info_(24, 0, 0, 0) <= 2, "超长输入不卡住：很快显示，最多 2 行标题、8 行正文");
    Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);
    std::wstring pua; for (wchar_t ch = 0xE000; ch < 0xE100; ch++) pua += ch;
    SIZE_T m0 = PrivateCommitted(); t0 = GetTickCount(); INT_PTR a5 = Show("Private use", U8(pua.c_str()).c_str(), 6000); bool s5 = Wait(5000, PhaseIs, 2); dt = GetTickCount() - t0; SIZE_T m1 = PrivateCommitted();
    printf("  256 个私用区字符：显示用时 %lu 毫秒，私有内存 +%ld KB，回退后仍缺 %d 字\n", (unsigned long)dt, (long)((long long)m1 - (long long)m0) / 1024, (int)Info_(33, 0, 0, 0));
    Check(a5 && s5 && dt < 1500 && m1 <= m0 + 3 * 1024 * 1024, "所有字体都没有的字：全部字体扫描有时间上限（不卡界面线程），内存不超过 3MB");
    Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);
    { INT_PTR f1 = Show(u8"字体变化", u8"显示中收到字体变化通知：照常显示、不缺字。", 6000); Wait(1500, PhaseIs, 2);
      HWND fh = (HWND)Info_(3, 0, 0, 0); LONG fc0 = (LONG)Info_(41, 0, 0, 0); SendMessageW(fh, WM_FONTCHANGE, 0, 0); Sleep(300); bool reset = Info_(41, 0, 0, 0) == fc0 + 1;
      bool ok1 = Info_(1, 0, 0, 0) == f1 && Info_(20, 0, 0, 0) == 2 && Info_(33, 0, 0, 0) == 0 && Info_(40, 0, 0, 0) == 0;
      INT_PTR f2 = Show(u8"字体变化之后", u8"之后新的一条照常排版、不缺字。", 6000); Wait(1500, EvFor, f1); Wait(1500, PhaseIs, 2); Sleep(300);
      Check(reset && ok1 && f2 && Info_(33, 0, 0, 0) == 0 && Info_(40, 0, 0, 0) == 0, "收到字体变化通知（WM_FONTCHANGE）：系统字体缓存重来（计数加 1），照常显示、不缺字");
      Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0); }
    struct R { static DWORD WINAPI Run(LPVOID) { for (int i = 0; i < 40; i++) { Show("Race", "show while stopping", 3000); Sleep(1); } return 0; } };
    HANDLE th = CreateThread(nullptr, 0, R::Run, nullptr, 0, nullptr); Sleep(5); Stop_(0, 0, 0, 0); Sleep(3); Stop_(0, 0, 0, 0); WaitForSingleObject(th, 30000); CloseHandle(th);
    INT_PTR a6 = Show("After race", "Still works after concurrent stop and show.", 4000);
    Check(a6 && Wait(2000, PhaseIs, 2) && Info_(1, 0, 0, 0) == a6, "停止与显示同时调用：之后照常显示，状态一致");
    Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);
  }
  // ---- 光标停在卡片上没动（系统补发的移动消息）不暂停；悬停暂停有总时长上限；显示期间的开销
  {
    INT_PTR p0 = Show("Probe", "Find where the card appears.", 4000); Wait(1500, PhaseIs, 2);
    int cx, cy; CardCenter(&cx, &cy); int wx = (int)Info_(13, 0, 0, 0), wy = (int)Info_(14, 0, 0, 0); Close_(p0, 0, 0, 0); Wait(1000, PhaseIs, 0);
    SetCursorPos(wx + cx, wy + cy); Sleep(50);  // 光标先停在卡片将要出现的地方，之后不动
    DWORD t0 = GetTickCount(); INT_PTR p1 = Show("Parked cursor", "The cursor rests here but has not moved.", 1500); Wait(1500, PhaseIs, 2);
    Mouse_(1, cx, cy, 0);  // 相当于卡片出现时系统补发的移动消息
    bool got = Wait(4000, EvFor, p1); DWORD dt = GetTickCount() - t0;
    printf("  光标停在卡片上不动：%lu 毫秒后关闭（设定 1500）\n", (unsigned long)dt);
    Check(Info_(4, 0, 0, 0) == 0 && got && EvOf(p1) == 1 && dt < 2600, "光标停在卡片上但没动：不算悬停，照常倒计时（排队的提示不会被挡住）");
    Wait(1000, PhaseIs, 0);
    Set_(101, 1500, 0, 0); SetCursorPos(5, 5); Sleep(50);
    t0 = GetTickCount(); INT_PTR p2 = Show("Pause cap", "Hovering pauses only up to the cap.", 1000); Wait(1500, PhaseIs, 2);
    SetCursorPos(wx + cx, wy + cy); Mouse_(1, cx, cy, 0);
    Check(Info_(4, 0, 0, 0) == 1, "光标真移到卡片上：算悬停");
    got = Wait(6000, EvFor, p2); dt = GetTickCount() - t0;
    printf("  一直悬停：%lu 毫秒后关闭（显示 1000 + 暂停上限 1500）\n", (unsigned long)dt);
    Check(got && EvOf(p2) == 1 && dt >= 2200 && dt < 4500, "一直悬停也会在暂停额度用完后照常关闭");
    SetCursorPos(5, 5); Mouse_(4, 0, 0, 0); Set_(101, 60000, 0, 0); Wait(1000, PhaseIs, 0);
    FILETIME a, b, k0, u0, k1, u1; GetProcessTimes(GetCurrentProcess(), &a, &b, &k0, &u0);
    t0 = GetTickCount(); INT_PTR p3 = Show("Cost", "Measure the cost while the countdown line moves.", 5000); Wait(1500, PhaseIs, 2); Sleep(3000);
    GetProcessTimes(GetCurrentProcess(), &a, &b, &k1, &u1); dt = GetTickCount() - t0;
    auto ft = [](FILETIME f) { return ((unsigned long long)f.dwHighDateTime << 32) | f.dwLowDateTime; };
    double cpu = (double)((ft(k1) - ft(k0)) + (ft(u1) - ft(u0))) / 10000.0 / dt * 100;
    printf("  INFO 显示期间：进程 CPU %.1f%%（单核），每帧平均 %ld 微秒、最大 %ld 微秒，已贴 %ld 帧\n", cpu, (long)Info_(35, 0, 0, 0), (long)Info_(36, 0, 0, 0), (long)Info_(12, 0, 0, 0));
    long d1 = (long)Info_(40, 0, 0, 0);
    SetCursorPos(wx + cx, wy + cy); Mouse_(1, cx, cy, 0); Sleep(700); long d2 = (long)Info_(40, 0, 0, 0);  // 悬停暂停中
    Update_(p3, (INT_PTR)"Cost, updated", (INT_PTR)"New text re-renders the whole card, then only the line again.", 0); Sleep(900); long d3 = (long)Info_(40, 0, 0, 0);
    SetCursorPos(5, 5); Mouse_(4, 0, 0, 0); Sleep(600); long d4 = (long)Info_(40, 0, 0, 0);
    printf("  窗口上的帧与整张重画逐像素比较：显示中 %ld、悬停中 %ld、改文字后 %ld、移开后 %ld 个像素不同\n", d1, d2, d3, d4);
    Check(d1 == 0 && d2 == 0 && d3 == 0 && d4 == 0, "窗口上的帧（只修补细线那几行）与整张重画逐像素相同");
    { Set_(102, 1, 0, 0);  // 当作系统不支持“只交一部分”：每帧都整张提交
      INT_PTR n1 = Show("Full commit", "Every frame is committed whole when partial updates are unavailable.", 4000); bool s1 = Wait(2000, PhaseIs, 2); Sleep(800);
      HWND nh = (HWND)Info_(3, 0, 0, 0); RECT wr; GetWindowRect(nh, &wr); long d = (long)Info_(40, 0, 0, 0);
      bool pos = wr.left == (LONG)Info_(13, 0, 0, 0) && wr.top == (LONG)Info_(14, 0, 0, 0);
      Close_(n1, 0, 0, 0); bool s0 = Wait(2000, PhaseIs, 0) && !IsWindowVisible(nh); Set_(102, 0, 0, 0);
      printf("  每帧整张提交：显示 %d、位置对 %d、与整张重画不同的像素 %ld、退场后隐藏 %d\n", (int)s1, (int)pos, d, (int)s0);
      Check(s1 && pos && d == 0 && s0, "系统不支持只交一部分时：每帧整张提交，进场、退场照常，画面一致"); }
    { // 别的模块（如进程里的换肤库）改了卡片窗口：加鼠标穿透、设窗口区域、调 SetLayeredWindowAttributes——卡片自己恢复，照常显示、能点
      INT_PTR v1 = Show("Interference", "Someone else changes this window; the card repairs itself.", 6000); Wait(2000, PhaseIs, 2); Sleep(300);
      HWND vh = (HWND)Info_(3, 0, 0, 0); LONG r0 = (LONG)Info_(37, 0, 0, 0);
      SetLayeredWindowAttributes(vh, 0, 255, LWA_ALPHA);
      SetWindowLongPtrW(vh, GWL_EXSTYLE, GetWindowLongPtrW(vh, GWL_EXSTYLE) | WS_EX_TRANSPARENT);
      SetWindowRgn(vh, CreateRectRgn(0, 0, 40, 40), TRUE);
      Sleep(400);
      INT_PTR v2 = Show("Interference", "A new card checks the window state again.", 6000); Wait(1500, EvFor, v1); Wait(1500, PhaseIs, 2); Sleep(500);
      HRGN tr = CreateRectRgn(0, 0, 0, 0); int rg = GetWindowRgn(vh, tr); DeleteObject(tr); LONG_PTR ex = GetWindowLongPtrW(vh, GWL_EXSTYLE);
      LONG f0 = (LONG)Info_(12, 0, 0, 0); Sleep(500); LONG f1 = (LONG)Info_(12, 0, 0, 0);
      printf("  外部改动后：区域 %s、鼠标穿透 %s、自己修复 %ld 次、之后 0.5 秒提交 %ld 帧、与整张重画不同的像素 %ld\n", rg == ERROR ? "已去掉" : "还在", (ex & WS_EX_TRANSPARENT) ? "还在" : "已去掉", (long)(Info_(37, 0, 0, 0) - r0), (long)(f1 - f0), (long)Info_(40, 0, 0, 0));
      Check(v2 && rg == ERROR && !(ex & WS_EX_TRANSPARENT) && (ex & WS_EX_LAYERED) && Info_(37, 0, 0, 0) > r0 && f1 > f0 && Info_(40, 0, 0, 0) == 0 && IsWindowVisible(vh),
            "窗口被外部改动（鼠标穿透、窗口区域、SetLayeredWindowAttributes）：显示时自己恢复，照常提交、能点");
      int cx, cy; CardCenter(&cx, &cy); RECT wr; GetWindowRect(vh, &wr); POINT pt = {wr.left + cx, wr.top + cy};
      Check(WindowFromPoint(pt) == vh, "恢复后鼠标点得到卡片（系统命中测试落在卡片窗口上）");
      LONG r1 = (LONG)Info_(37, 0, 0, 0); Set_(103, 3, 0, 0); Update_(v2, (INT_PTR)"Interference", (INT_PTR)"Commits fail three times; the card re-arms the layered style and recovers.", 0); Sleep(800);
      Check(Info_(37, 0, 0, 0) > r1 && Info_(40, 0, 0, 0) == 0 && Info_(1, 0, 0, 0) == v2, "提交连续失败：摘下再挂上分层样式后恢复提交");
      Set_(103, 0, 0, 0); Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);
    }
    { // 省略号只在字符簇边界上切：组合附加符号、泰文元音与声调、代理对（emoji）不会被切开
      auto bad = [](const std::wstring& s, int k) {
        if (k <= 0 || k >= (int)s.size()) return false;
        if (s[k] >= 0xDC00 && s[k] <= 0xDFFF) return true;
        wchar_t ch = s[k]; if ((ch >= 0x0E40 && ch <= 0x0E44) || (ch >= 0x0EC0 && ch <= 0x0EC4)) return false;  // 泰文、老挝文前置元音前面本来就可以切（Unicode 字符簇规则）
        if (ch == 0x0E33 || ch == 0x0EB3) return true;  // SARA AM：Unicode 规定为不能与前字分开的 SpacingMark
        WORD t3 = 0; GetStringTypeW(CT_CTYPE3, &ch, 1, &t3); return (t3 & (C3_NONSPACING | C3_VOWELMARK)) != 0;
      };
      struct Case { const char* lang; std::wstring s; } cs[] = {
        {"en", L"Cafe\u0301 de\u0301ja\u0300 vu\u0302 cre\u0300me bru\u0302le\u0301e pe\u0301tanque"},
        {"th", L"\u0e17\u0e35\u0e48\u0e19\u0e35\u0e48\u0e21\u0e35\u0e19\u0e49\u0e33\u0e43\u0e08\u0e44\u0e21\u0e48\u0e15\u0e49\u0e2d\u0e07\u0e01\u0e31\u0e07\u0e27\u0e25"},
        {"en", L"\U0001F600\U0001F601\U0001F602\U0001F603\U0001F604\U0001F605\U0001F606\U0001F607"}};
      int tries = 0, wrong = 0, shrink = 0;
      for (auto& k : cs) {
        Set_(1, (INT_PTR)k.lang, 0, 0); std::string u = U8(k.s.c_str()); int buf[4];
        for (int w = 8; w < 400; w += 1) { int kept = (int)Wrap_((INT_PTR)u.c_str(), w * 10, (INT_PTR)buf, -1); tries++; if (kept < (int)k.s.size()) { shrink++; if (bad(k.s, kept)) wrong++; } }
      }
      Set_(1, (INT_PTR)"en", 0, 0);
      printf("  省略号：试了 %d 个宽度（%d 次截短），切在字符簇中间 %d 次\n", tries, shrink, wrong);
      Check(shrink > 100 && wrong == 0, "省略号只在字符簇边界上切（组合附加符号、泰文元音与声调、emoji 代理对都不切开）");
    }
    { // 控制字符与段落分隔符：不画成方框，分段与排版一致
      INT_PTR k1 = Show(u8"Tab\there", u8"Line A\u2029Line B\x07\uFEFF and more\rLine C", 6000); Wait(2000, PhaseIs, 2); Sleep(200);
      int tl = (int)Info_(24, 0, 0, 0), bl = (int)Info_(25, 0, 0, 0);
      printf("  控制字符：标题 %d 行、正文 %d 行、缺字 %d\n", tl, bl, (int)Info_(33, 0, 0, 0));
      Check(k1 && tl == 1 && bl == 3 && Info_(33, 0, 0, 0) == 0, "段分隔符、单独的回车算换行；制表符变空格；其它控制字符与 BOM 去掉（不画成方框）");
      Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);
    }
    { // 从右往左时的关闭键：判定区域与画出来的 × 重合（正好是从左往右时的镜像），真的点得到
      Set_(1, (INT_PTR)"en", 0, 0); INT_PTR e1 = Show("Close", "Mirror test.", 6000); Wait(1500, PhaseIs, 2); Sleep(100);
      int mm = (int)Info_(15, 0, 0, 0), ww = (int)Info_(7, 0, 0, 0);
      int lx = ((int)Info_(16, 0, 0, 0) + (int)Info_(18, 0, 0, 0)) / 2, ly = ((int)Info_(17, 0, 0, 0) + (int)Info_(19, 0, 0, 0)) / 2, lw = (int)Info_(18, 0, 0, 0) - (int)Info_(16, 0, 0, 0);
      Close_(e1, 0, 0, 0); Wait(1000, PhaseIs, 0);
      Set_(1, (INT_PTR)"ar", 0, 0); INT_PTR e2 = Show("Close", "Mirror test.", 6000); Wait(1500, PhaseIs, 2); Sleep(100);
      int rx = ((int)Info_(16, 0, 0, 0) + (int)Info_(18, 0, 0, 0)) / 2, ry = ((int)Info_(17, 0, 0, 0) + (int)Info_(19, 0, 0, 0)) / 2, rw = (int)Info_(18, 0, 0, 0) - (int)Info_(16, 0, 0, 0);
      bool mirror = abs((lx - mm) - (mm + ww - rx)) <= 1 && ly == ry && lw == rw;
      Sleep((int)GetDoubleClickTime()); Mouse_(2, rx, ry, 0); Mouse_(3, rx, ry, 0);  // 光标没动：不靠悬停，按下、松开都在关闭键上就关（1.2.2：出现后双击时间以内按下不算，先等过这段）
      bool got = Wait(1500, EvFor, e2);
      printf("  关闭键中心：从左往右 x=%d，从右往左 x=%d（卡片 %d～%d），同一高度 %d；点击后事件 %d\n", lx, rx, mm, mm + ww, (int)(ly == ry), got ? (int)EvOf(e2) : -1);
      Check(mirror && got && EvOf(e2) == 2, "从右往左时关闭键：判定区域与画出来的 × 重合（是从左往右时的镜像），点得到");
      Set_(1, (INT_PTR)"en", 0, 0); Wait(1000, PhaseIs, 0);
    }
    { // 宿主的输入决定分配大小的几处：几千个空行、尺寸很大的图标图片、截图的缩放比例——都有上限，不会因为分配失败而闪退
      std::string body = "First line"; for (int i = 0; i < 3000; i++) body += "\n"; body += "Last line";
      INT_PTR z1 = Show("Blank lines", body.c_str(), 4000); bool s1 = Wait(3000, PhaseIs, 2); Sleep(100);
      int hh = (int)Info_(8, 0, 0, 0), dpi = (int)Info_(6, 0, 0, 0), bl = (int)Info_(25, 0, 0, 0);
      printf("  正文有 3000 个空行：卡片高 %d（DPI %d），正文 %d 行\n", hh, dpi, bl);
      Check(z1 && s1 && hh <= 160 * dpi / 96 && bl == 2, "正文里有几千个空行：连续空行合成一个段间距，卡片高度有上限");
      Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);
      SIZE_T m0 = PrivateCommitted(); std::vector<BYTE> big = BigRleBmp(3000, 3000);
      Check(Set_(4, 2, (INT_PTR)big.data(), (INT_PTR)big.size()) == 1, "交给 DLL 一张 3000×3000 的图标图片");
      INT_PTR z2 = Show("Big icon", "A very large icon image is scaled down before use.", 4000); bool s2 = Wait(3000, PhaseIs, 2); Sleep(200);
      SIZE_T m1 = PrivateCommitted(); int src = (int)Info_(26, 0, 0, 0);
      printf("  3000×3000 的图标图片：用的是 %d 像素的图，私有内存 %+ld KB，强调色 %06lX\n", src, (long)(((long long)m1 - (long long)m0) / 1024), (unsigned long)Info_(9, 0, 0, 0));
      Check(z2 && s2 && src > 0 && src <= 256 && m1 <= m0 + 12 * 1024 * 1024, "宿主给的图标图片很大：先缩到 256 以内再用（不按原尺寸占几十 MB）");
      Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);
      std::vector<BYTE> huge = BigRleBmp(20000, 20000); Set_(4, 2, (INT_PTR)huge.data(), (INT_PTR)huge.size());
      INT_PTR z3 = Show("Huge icon", "A 20000 by 20000 icon image must not crash the host.", 4000); bool s3 = Wait(3000, PhaseIs, 2); Sleep(200);
      printf("  20000×20000 的图标图片：显示 %d，用的是 %d 像素的图\n", (int)s3, (int)Info_(26, 0, 0, 0));
      Check(z3 && s3 && Info_(26, 0, 0, 0) <= 256, "宿主给的图标图片极大（20000×20000）：不会因为分配失败而闪退");
      Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0); Set_(4, 0, 0, 0); Set_(3, 0, 0, 0);
      INT_PTR z4 = Show("Snapshot scale", "Only 25% to 500% is accepted.", 4000); Wait(1500, PhaseIs, 2);
      std::string bad = outDir + "\\bad_scale.png";
      Check(Snap_((INT_PTR)bad.c_str(), 100000, 500, 0) == 0 && Info_(1, 0, 0, 0) == z4 && Info_(20, 0, 0, 0) == 2, "截图的缩放比例超出 25%～500%：拒绝，不按它分配画布");
      Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);
    }
    INT_PTR q1 = Show("Same size A", "First card of the same size.", 6000); Wait(1500, PhaseIs, 2); Sleep(300);
    INT_PTR q2 = Show("Same size B", "Second card, other words.", 6000); Wait(1500, EvFor, q1); Wait(1500, PhaseIs, 2); Sleep(500);
    long d5 = (long)Info_(40, 0, 0, 0); printf("  替换正在显示的同尺寸卡片后：%ld 个像素不同\n", d5);
    Check(q2 && d5 == 0, "替换成同尺寸的新卡片：窗口内容整张换成新的（不会只换细线、留着上一条的文字）");
    Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0);
    Close_(p3, 0, 0, 0); Wait(1000, PhaseIs, 0);
  }
  // ---- 多线程压测
  {
    HANDLE th[4]; for (int i = 0; i < 4; i++) th[i] = CreateThread(nullptr, 0, Stress, (LPVOID)(INT_PTR)(i + 1), 0, nullptr);
    DWORD r = WaitForMultipleObjects(4, th, TRUE, 60000); for (int i = 0; i < 4; i++) CloseHandle(th[i]);
    Close_(0, 0, 0, 0); Set_(1, (INT_PTR)"en", 0, 0); Set_(5, 1, 0, 0);
    Check(r == WAIT_OBJECT_0 && Wait(2000, PhaseIs, 0) && Info_(1, 0, 0, 0) == 0, "4 条线程同时乱调 600 次：不崩溃，收尾后状态一致");
  }
  // ---- 句柄不泄漏、停止与重启
  {
    PROCESS_MEMORY_COUNTERS_EX pm = {}; pm.cb = sizeof(pm);
    for (int i = 0; i < 40; i++) { Show("Warm", "warm up caches", 5000); Sleep(5); Close_(0, 0, 0, 0); } Wait(1500, PhaseIs, 0);
    SIZE_T m0 = PrivateCommitted(); DWORD g0 = GetGuiResources(GetCurrentProcess(), GR_GDIOBJECTS), u0 = GetGuiResources(GetCurrentProcess(), GR_USEROBJECTS), h0 = 0; GetProcessHandleCount(GetCurrentProcess(), &h0);
    for (int i = 0; i < 300; i++) { Show("Cycle", "Show and close repeatedly.", 5000); Sleep(5); Close_(0, 0, 0, 0); }
    Wait(2000, PhaseIs, 0); Sleep(300);
    SIZE_T m1 = PrivateCommitted(); DWORD g1 = GetGuiResources(GetCurrentProcess(), GR_GDIOBJECTS), u1 = GetGuiResources(GetCurrentProcess(), GR_USEROBJECTS), h1 = 0; GetProcessHandleCount(GetCurrentProcess(), &h1);
    printf("  私有内存 %lu KB → %lu KB；GDI 对象 %lu → %lu；USER 对象 %lu → %lu；内核句柄 %lu → %lu%s\n", (unsigned long)(m0 / 1024), (unsigned long)(m1 / 1024), (unsigned long)g0, (unsigned long)g1, (unsigned long)u0, (unsigned long)u1, (unsigned long)h0, (unsigned long)h1,
           g0 == 0 || u0 == 0 || h0 == 0 ? "（为 0 的是 Wine 不统计的项，这些项以真机自测为准）" : "");
    Check(m1 <= m0 + 2 * 1024 * 1024 && (g0 == 0 || g1 <= g0 + 8) && (u0 == 0 || u1 <= u0 + 4) && (h0 == 0 || h1 <= h0 + 8), "反复显示、关闭 300 次：私有内存增长不超过 2MB，GDI、USER 对象与内核句柄不增长");
    { // 反复停止、重启界面线程：每次都新建线程、事件、窗口、DIB——最容易漏关句柄的路径
      DWORD k0 = 0, k1 = 0; GetProcessHandleCount(GetCurrentProcess(), &k0); DWORD rg0 = GetGuiResources(GetCurrentProcess(), GR_GDIOBJECTS), ru0 = GetGuiResources(GetCurrentProcess(), GR_USEROBJECTS); SIZE_T rm0 = PrivateCommitted();
      int shown = 0;
      for (int i = 0; i < 20; i++) { Stop_(0, 0, 0, 0); INT_PTR x = Show("Restart", "Stop and start the UI thread again.", 3000); if (x && Wait(1500, PhaseIs, 2)) shown++; }
      Close_(0, 0, 0, 0); Wait(1500, PhaseIs, 0); Sleep(300);
      GetProcessHandleCount(GetCurrentProcess(), &k1); DWORD rg1 = GetGuiResources(GetCurrentProcess(), GR_GDIOBJECTS), ru1 = GetGuiResources(GetCurrentProcess(), GR_USEROBJECTS); SIZE_T rm1 = PrivateCommitted();
      printf("  停止、重启 20 次：每次都显示出来 %d 次；内核句柄 %lu → %lu；GDI %lu → %lu；USER %lu → %lu；私有内存 %+ld KB\n", shown, (unsigned long)k0, (unsigned long)k1, (unsigned long)rg0, (unsigned long)rg1, (unsigned long)ru0, (unsigned long)ru1, (long)(((long long)rm1 - (long long)rm0) / 1024));
      Check(shown == 20 && (k0 == 0 || k1 <= k0 + 8) && (rg0 == 0 || rg1 <= rg0 + 8) && (ru0 == 0 || ru1 <= ru0 + 4), "反复停止、重启界面线程 20 次：每次都照常显示，内核句柄、GDI、USER 对象不增长");
    }
    Check(Stop_(0, 0, 0, 0) == 1 && Info_(1, 0, 0, 0) == 0, "DN_Stop：界面线程退出");
    INT_PTR i13 = Show("Again", "Starts a new UI thread after stop.", 2000); Check(i13 > 0 && Wait(1500, PhaseIs, 2), "停止后再显示：重新启动");
    Close_(0, 0, 0, 0); Wait(1000, PhaseIs, 0); Stop_(0, 0, 0, 0);
  }
  // ---- 1.2.0：不容易被错过——到场计时（人不在、锁屏、全屏独占时不倒计时，回来再提醒）、系统「通知显示时间」作下限、跟随用户的屏幕、
  // 醒目（起始一侧强调色竖条、对白底≥3:1、光晕提醒、一直在最上层、指过就停）、尽量不被屏幕采集（标志 8）、关闭时的统计。新设置默认都关着：别的工程不受影响
  {
    Set_(1, (INT_PTR)"zh-Hans", 0, 0); Set_(5, 1, 0, 0); Set_(8, 0, 0, 0); Set_(3, 0, 0, 0); Set_(4, 0, 0, 0);
    Check(Set_(9, 2, 0, 0) == 0 && Set_(10, -1, 0, 0) == 0 && Set_(11, 5, 0, 0) == 0 && Set_(106, 3, 0, 0) == 0 && Set_(107, 8, 0, 0) == 0 && Set_(108, -2, 0, 0) == 0 && Set_(109, 50, 0, 0) == 0 && Set_(111, 0, 0, 0) == 0,
          "1.2.0 新设置：越界参数返回 0");
    Set_(106, 2, 0, 0);  // 测试钩子：当作人不在（久没有键鼠输入）
    { INT_PTR a = Show("Default", "Presence-aware countdown is off by default.", 1500); bool got = Wait(4000, EvFor, a);
      Check(got && EvOf(a) == 1 && Info_(46, 0, 0, 0) == 0, "1.2.0 默认不开到场计时：人不在也照常到点关闭（与 1.1.x 相同，别的工程不受影响）"); Wait(1000, PhaseIs, 0); }
    Check(Set_(9, 1, 0, 0) == 1, "1.2.0 开到场计时（DN_Set 9）");
    { INT_PTR a = Show(u8"360安全卫士可能会导致音效功能的快捷键失效", u8"建议关闭后重开本软件", 1500, 4); Wait(1500, PhaseIs, 2); Sleep(2300);
      int r = (int)Info_(2, a, 0, 0), bits = (int)Info_(46, 0, 0, 0), pz = (int)Info_(50, 0, 0, 0); printf("  人不在 2.3 秒后：剩 %d 毫秒，原因位 %d，光晕提醒 %d 次\n", r, bits, pz);
      Check(Info_(1, 0, 0, 0) == a && r >= 1400 && (bits & 1) && pz == 0, "1.2.0 到场计时：人不在时不倒计时，卡片一直等着（落定时人不在，不白白提醒）");
      Set_(106, 1, 0, 0); DWORD t0 = GetTickCount(); int mx = 0; while (!EvFor(a) && GetTickCount() - t0 < 4000) { int v = (int)Info_(49, 0, 0, 0); if (v > mx) mx = v; Sleep(10); } DWORD dt = GetTickCount() - t0;
      printf("  人回来后 %lu 毫秒关闭，期间光晕最强 %d / 1000\n", (unsigned long)dt, mx);
      Check(EvOf(a) == 1 && dt >= 1200 && dt <= 2400, "1.2.0 到场计时：人回来后才接着倒计时，按剩下的时间关闭");
      Check(Info_(54, 0, 0, 0) >= 1 && mx >= 800, "1.2.0 人回来时醒目卡片再提醒一次（光晕）");
      int s56 = (int)Info_(56, 0, 0, 0), s57 = (int)Info_(57, 0, 0, 0); printf("  关闭时的统计：显示 %d 毫秒，因人不在暂停 %d 毫秒，标志 %d\n", s56, s57, (int)Info_(58, 0, 0, 0));
      Check(Info_(55, 0, 0, 0) == a && s57 >= 2000 && (Info_(58, 0, 0, 0) & 2) && s56 >= 3500, "1.2.0 关闭时的统计：编号、显示毫秒、因人不在暂停的毫秒、暂停过");
      Wait(1000, PhaseIs, 0); }
    for (int q : {1, 3}) {  // 锁屏、屏保（QUNS_NOT_PRESENT）与全屏独占的 Direct3D 程序（QUNS_RUNNING_D3D_FULL_SCREEN）时也不倒计时
      Set_(107, q, 0, 0); INT_PTR a = Show("Locked / fullscreen", "Waits until the card can be seen.", 1200); Wait(1500, PhaseIs, 2); Sleep(1700);
      int bits = (int)Info_(46, 0, 0, 0); char nm[200]; sprintf(nm, "1.2.0 到场计时：%s时不倒计时（原因位 %d）", q == 1 ? "锁屏、屏保" : "全屏独占的 Direct3D 程序在前台", bits);
      Check(Info_(1, 0, 0, 0) == a && (bits & (q == 1 ? 2 : 4)) != 0, nm);
      Set_(107, 0, 0, 0); Check(Wait(3500, EvFor, a) && EvOf(a) == 1, q == 1 ? "1.2.0 解锁后接着倒计时并关闭" : "1.2.0 离开全屏独占后接着倒计时并关闭"); Wait(1000, PhaseIs, 0);
    }
    { Set_(106, 2, 0, 0); Set_(110, 1500, 0, 0); DWORD t0 = GetTickCount(); INT_PTR a = Show("Cap", "Not excluded from capture: waits at most a while.", 1000); bool got = Wait(6000, EvFor, a); DWORD dt = GetTickCount() - t0;
      printf("  人不在、没设不被采集：%lu 毫秒后关闭（测试上限 1500＋显示 1000）\n", (unsigned long)dt);
      Check(got && EvOf(a) == 1 && dt >= 2300 && dt <= 4200, "1.2.0 没设不被屏幕采集的卡片：人不在时最多等到上限（默认 5 分钟），免得一直停在可能被录进直播的屏幕上");
      Set_(110, 300000, 0, 0); Set_(106, 1, 0, 0); Wait(1000, PhaseIs, 0); }
    { Set_(106, 2, 0, 0); Set_(110, 1500, 0, 0); Set_(111, 300, 0, 0); int w54 = (int)Info_(54, 0, 0, 0); INT_PTR a = Show("Cap important", "Important card, user away, not excluded from capture.", 1500, 4); bool got = Wait(7000, EvFor, a);
      printf("  醒目卡片到了等待上限：提醒 %d 次，人回来再提醒累计 %d → %d\n", (int)Info_(59, 0, 0, 0), w54, (int)Info_(54, 0, 0, 0));
      Check(got && EvOf(a) == 1 && Info_(55, 0, 0, 0) == a && Info_(59, 0, 0, 0) == 0 && Info_(54, 0, 0, 0) == w54, "1.2.1 醒目卡片到了等待上限照常倒计时：人仍不在，不算回来、不提醒、不催（1.2.0 会误算一次“人回来再提醒”，倒计时期间还会催）");
      Set_(110, 300000, 0, 0); Set_(111, 10000, 0, 0); Set_(106, 1, 0, 0); Wait(1000, PhaseIs, 0); }
    { Check(Set_(11, 1, 0, 0) == 1, "1.2.0 开系统「通知显示时间」作下限（DN_Set 11）"); Set_(108, 3, 0, 0);
      DWORD t0 = GetTickCount(); INT_PTR a = Show("Duration", "The system notification duration is the minimum.", 1000); int r0 = (int)Info_(2, a, 0, 0);
      bool got = Wait(6000, EvFor, a); DWORD dt = GetTickCount() - t0; printf("  要求 1 秒、系统 3 秒：起始剩余 %d 毫秒，%lu 毫秒后关闭\n", r0, (unsigned long)dt);
      Check(r0 > 2500 && got && EvOf(a) == 1 && dt >= 2800 && dt <= 3900 && Info_(52, 0, 0, 0) == 3000, "1.2.0 系统「通知显示时间」比要求的长：按系统的（约 3 秒后关闭）");
      Wait(1000, PhaseIs, 0); Set_(108, 0, 0, 0); INT_PTR b = Show("Duration", "A longer request is kept.", 1500); int rb = (int)Info_(2, b, 0, 0);
      Check(rb > 1000 && rb <= 1500, "1.2.0 系统设得比要求的短（或没设）：按要求的时长"); Close_(b, 0, 0, 0); Wait(1500, PhaseIs, 0); Set_(108, -1, 0, 0); Set_(11, 0, 0, 0); }
    { struct PQ { int n; RECT mon[8]; int primary; int hasFg; RECT fg; int hasCur; POINT cur; int quns; int why; };
      auto pick = [](int hasFg, RECT fg, int hasCur, POINT cur, int quns, int* why) { PQ q = {}; q.n = 3; q.mon[0] = RECT{0, 0, 1920, 1080}; q.mon[1] = RECT{1920, 0, 3840, 1080}; q.mon[2] = RECT{-1280, 0, 0, 1024};
        q.primary = 0; q.hasFg = hasFg; q.fg = fg; q.hasCur = hasCur; q.cur = cur; q.quns = quns; q.why = -1; int r = (int)Info_(100, (INT_PTR)&q, 0, 0); *why = q.why; return r; };
      int w1, w2, w3, w4, w5, w6;
      int r1 = pick(1, RECT{2000, 100, 3000, 900}, 1, POINT{100, 100}, 5, &w1), r2 = pick(1, RECT{1800, 100, 2400, 900}, 0, POINT{0, 0}, 5, &w2), r3 = pick(0, RECT{0, 0, 0, 0}, 1, POINT{-500, 300}, 5, &w3);
      int r4 = pick(0, RECT{0, 0, 0, 0}, 0, POINT{0, 0}, 5, &w4), r5 = pick(1, RECT{1920, 0, 3840, 1080}, 1, POINT{2500, 500}, 3, &w5), r6 = pick(1, RECT{0, 0, 1920, 1080}, 1, POINT{500, 500}, 3, &w6);
      printf("  选屏（屏号/依据）：%d/%d %d/%d %d/%d %d/%d %d/%d %d/%d\n", r1, w1, r2, w2, r3, w3, r4, w4, r5, w5, r6, w6);
      Check(r1 == 1 && w1 == 1, "1.2.0 选屏：前台窗口在副屏、光标在主屏 → 副屏（看前台窗口）");
      Check(r2 == 1 && w2 == 1, "1.2.0 选屏：前台窗口跨两块屏 → 交集大的那块");
      Check(r3 == 2 && w3 == 2 && r4 == 0 && w4 == 0, "1.2.0 选屏：没有前台窗口 → 光标所在的屏；都没有 → 主屏");
      Check(r5 == 0 && w5 == 3 && r6 == 1 && w6 == 3, "1.2.0 选屏：前台那块屏被全屏独占的 Direct3D 程序占着 → 换到另一块（主屏优先）");
      Check(Set_(10, 1, 0, 0) == 1, "1.2.0 开跟随用户的屏幕（DN_Set 10）");
      INT_PTR a = Show("Monitor", "Shown on the monitor you are using.", 3000); Wait(1500, PhaseIs, 2);
      int x = (int)Info_(13, 0, 0, 0), y = (int)Info_(14, 0, 0, 0), m = (int)Info_(15, 0, 0, 0), w = (int)Info_(7, 0, 0, 0), hh = (int)Info_(8, 0, 0, 0), dpi = (int)Info_(6, 0, 0, 0);
      int why = (int)Info_(51, 0, 0, 0); POINT cp = {0, 0}; GetCursorPos(&cp);  // 1.2.3：按选屏依据取对应那块屏的工作区比较（原来拿主屏比，多屏真机上前台窗口在副屏时会误报）
      HMONITOR ex = why == 1 ? MonitorFromWindow(GetForegroundWindow(), MONITOR_DEFAULTTONEAREST) : why == 2 ? MonitorFromPoint(cp, MONITOR_DEFAULTTONEAREST) : MonitorFromPoint(POINT{0, 0}, MONITOR_DEFAULTTOPRIMARY);
      MONITORINFO mi = {sizeof(mi)}; GetMonitorInfoW(ex, &mi); RECT wa = mi.rcWork; int want = 16 * dpi / 96, gr = (int)(wa.right - (x + m + w)), gb = (int)(wa.bottom - (y + m + hh));
      bool sameWa = Info_(28, 0, 0, 0) == wa.right && Info_(29, 0, 0, 0) == wa.bottom && Info_(31, 0, 0, 0) == wa.left && Info_(32, 0, 0, 0) == wa.top;
      printf("  实测：%d 块屏，选屏依据 %d，用的工作区就是依据对应那块屏的 %d，离它右 %d 下 %d\n", GetSystemMetrics(SM_CMONITORS), why, sameWa ? 1 : 0, gr, gb);
      Check(sameWa && abs(gr - want) <= 2 && abs(gb - want) <= 2 && why >= 0 && why <= 2, "1.2.0 跟随用户的屏幕：卡片在选屏依据对应那块屏（前台窗口 / 光标 / 主屏）的工作区右下角（单屏、多屏都对）");
      Close_(a, 0, 0, 0); Wait(1500, PhaseIs, 0); Set_(10, 0, 0, 0); }
    { Set_(9, 0, 0, 0); Set_(3, 2, 0xFF8A7A, 0); Set_(111, 1500, 0, 0);
      INT_PTR a = Show(u8"360安全卫士可能会导致音效功能的快捷键失效", u8"建议关闭后重开本软件", 30000, 4); Wait(1500, PhaseIs, 2);
      int mx = 0, ups = 0, last = 0, mid40 = -2; bool rising = false; DWORD t0 = GetTickCount();
      while (GetTickCount() - t0 < 1600) { int v = (int)Info_(49, 0, 0, 0); if (v > mx) mx = v; if (!rising && v > last + 20) { rising = true; ups++; } if (rising && v < last - 20) rising = false; if (mid40 == -2 && v > 400) mid40 = (int)Info_(40, 0, 0, 0); last = v; Sleep(10); }
      printf("  醒目：光晕最强 %d / 1000，起落 %d 次，提醒中帧与整张重画不同的像素 %d\n", mx, ups, mid40);
      Check(mx >= 900 && ups >= 2, "1.2.0 醒目：落定后两次光晕提醒（强度起落两次，sin² 平滑、1.5 次/秒以内）");
      printf("  INFO 光晕提醒期间每帧耗时（滑动平均）%d 微秒\n", (int)Info_(35, 0, 0, 0));
      Check(mid40 == 0, "1.2.0 醒目：提醒中窗口上的帧与“底稿＋光晕＋细线”整张重画逐像素一致");
      Check(Wait(1500, [](INT_PTR) { return Info_(49, 0, 0, 0) == 0; }, 0) && Info_(40, 0, 0, 0) == 0, "1.2.0 醒目：提醒结束光晕收起，帧与整张重画一致");
      int nb = (int)Info_(50, 0, 0, 0); Sleep(2400); int na = (int)Info_(50, 0, 0, 0);
      Check(na > nb, "1.2.0 醒目：人在、还没指过时隔一会儿再轻提醒一次（测试把间隔改成 1.5 秒，默认 10 秒）");
      std::string pA = outDir + "\\imp_light_rest_100.png", pB = outDir + "\\imp_light_peak_100.png", pC = outDir + "\\plain_light_peak_100.png", pD = outDir + "\\imp_dark_peak_100.png";
      bool sa = Snap_((INT_PTR)pA.c_str(), 100, 700, 0) == 1, sb = Snap_((INT_PTR)pB.c_str(), 100, 700, 1000) == 1;
      unsigned strong = (unsigned)Info_(60, 0, 0, 0); int m = (int)Info_(15, 0, 0, 0), cw = (int)Info_(7, 0, 0, 0), ch = (int)Info_(8, 0, 0, 0);
      int cx, cy; CardCenter(&cx, &cy); int wx = (int)Info_(13, 0, 0, 0), wy = (int)Info_(14, 0, 0, 0); SetCursorPos(wx + cx, wy + cy); Mouse_(1, cx, cy, 0);
      int p0 = (int)Info_(50, 0, 0, 0); Sleep(2600); int p1 = (int)Info_(50, 0, 0, 0); int h49 = (int)Info_(49, 0, 0, 0); SetCursorPos(5, 5); Mouse_(4, 0, 0, 0);
      Check(p1 == p0 && h49 == 0, "1.2.0 醒目：鼠标指过（看到了）就收起光晕，之后不再催");
      Close_(a, 0, 0, 0); Wait(1500, PhaseIs, 0);
      Check(Info_(55, 0, 0, 0) == a && (Info_(58, 0, 0, 0) & 1) && Info_(59, 0, 0, 0) >= 3, "1.2.0 关闭时的统计：记下指过、提醒次数");
      INT_PTR pl = Show(u8"360安全卫士可能会导致音效功能的快捷键失效", u8"建议关闭后重开本软件", 20000, 0); Wait(1500, PhaseIs, 2); bool sc = Snap_((INT_PTR)pC.c_str(), 100, 700, 1000) == 1; Close_(pl, 0, 0, 0); Wait(1500, PhaseIs, 0);
      Set_(5, 2, 0, 0); INT_PTR dk = Show(u8"360安全卫士可能会导致音效功能的快捷键失效", u8"建议关闭后重开本软件", 20000, 4); Wait(1500, PhaseIs, 2); bool sd = Snap_((INT_PTR)pD.c_str(), 100, 700, 1000) == 1;
      unsigned strongDark = (unsigned)Info_(60, 0, 0, 0); Close_(dk, 0, 0, 0); Wait(1500, PhaseIs, 0); Set_(5, 1, 0, 0);
      std::vector<unsigned> A, B, Cc; int w1, h1, w2, h2, w3, h3;
      bool ld = sa && sb && sc && sd && LoadPx(pA, A, w1, h1) && LoadPx(pB, B, w2, h2) && LoadPx(pC, Cc, w3, h3) && w1 == w2 && h1 == h2;
      auto red = [](unsigned v) { int a = (int)(v >> 24), r = (int)((v >> 16) & 255), g = (int)((v >> 8) & 255), b = (int)(v & 255); return a >= 60 && r > g + 30 && r > b + 30; };
      auto outside = [&](int x, int y) { return x < m - 1 || x > m + cw || y < m - 1 || y > m + ch; };
      int nA = 0, nB = 0, nC = 0;
      if (ld) for (int y = 0; y < h1; y++) for (int x = 0; x < w1; x++) if (outside(x, y)) { size_t i = (size_t)y * w1 + x; nA += red(A[i]); nB += red(B[i]); if (w3 == w1 && h3 == h1) nC += red(Cc[i]); }
      unsigned sp = ld ? A[(size_t)(m + ch / 2) * w1 + m + 2] & 0xFFFFFF : 0, pp = ld && w3 > m + 2 && h3 > m + ch / 2 ? Cc[(size_t)(m + ch / 2) * w3 + m + 2] & 0xFFFFFF : 0;
      double crS = Contr(strong & 0xFFFFFF, 0xFFFFFF), crSoft = Contr(0xFF8A7A, 0xFFFFFF), crD = Contr(strongDark & 0xFFFFFF, 0x1E1E23);
      printf("  醒目截图：卡片外的强调色像素 提醒时 %d、平时 %d、普通卡片 %d；竖条 #%06X（加深后 #%06X，对白底 %.2f:1，原来的柔和色 %.2f:1），普通卡片同处 #%06X；深色主题强调色 #%06X 对底色 %.2f:1\n",
             nB, nA, nC, sp, strong & 0xFFFFFF, crS, crSoft, pp, strongDark & 0xFFFFFF, crD);
      Check(ld && nB >= 600 && nA * 10 <= nB && nC == 0, "1.2.0 醒目：提醒时卡片外一圈强调色光晕（平时没有，普通卡片没有）");
      Check(ld && crS >= 3.0 && crSoft < 3.0 && Contr(sp, 0xFFFFFF) >= 2.9 && ((sp >> 16) & 255) > ((sp >> 8) & 255) + 40 && pp != 0 && Contr(pp, 0xFFFFFF) < 1.2, "1.2.0 醒目：起始一侧强调色竖条，颜色加深到对白底≥3:1（普通卡片同处仍是底色）");
      Check(crD >= 3.0, "1.2.0 醒目：深色主题下强调色对底色≥3:1");
      { Set_(5, 2, 0, 0); Set_(3, 2, 0x203060, 0); INT_PTR dk2 = Show("Dark accent", "A dark accent on the dark theme is lightened.", 3000, 4); Wait(1500, PhaseIs, 2); unsigned s2 = (unsigned)Info_(60, 0, 0, 0) & 0xFFFFFF;
        double c0 = Contr(0x203060, 0x1E1E23), c2 = Contr(s2, 0x1E1E23); printf("  深色主题给了深色强调色 #203060（对底色 %.2f:1）：竖条、描边、光晕用 #%06X（%.2f:1）\n", c0, s2, c2);
        Check(c0 < 3.0 && c2 >= 3.0 && Lum(s2) > Lum(0x203060), "1.2.1 深色主题下宿主给了很深的强调色：往亮里调到对底色≥3:1（1.2.0 只会往暗里调，越调越看不见）");
        Close_(dk2, 0, 0, 0); Wait(1500, PhaseIs, 0); Set_(5, 1, 0, 0); Set_(3, 2, 0xFF8A7A, 0); }
      Set_(8, 2, 0, 0); INT_PTR rm = Show("Reduced motion", "A steady glow instead of pulses.", 6000, 4); Wait(500, PhaseIs, 2);
      mx = 0; ups = 0; last = 0; rising = false; t0 = GetTickCount();
      while (GetTickCount() - t0 < 2900) { int v = (int)Info_(49, 0, 0, 0); if (v > mx) mx = v; if (!rising && v > last + 20) { rising = true; ups++; } if (rising && v < last - 20) rising = false; last = v; Sleep(10); }
      printf("  系统关了动画：光晕最强 %d，起落 %d 次，提醒 %d 次\n", mx, ups, (int)Info_(50, 0, 0, 0));
      Check(mx >= 900 && ups == 1 && Info_(50, 0, 0, 0) == 1 && Info_(49, 0, 0, 0) == 0, "1.2.0 醒目：系统关了动画时只有一次不闪的静态光晕（渐显、停留、渐隐），不脉动、不轻提醒");
      Close_(rm, 0, 0, 0); Wait(1000, PhaseIs, 0); Set_(8, 0, 0, 0);
      INT_PTR tp = Show("Stay on top", "Important cards stay above other topmost windows.", 8000, 4); Wait(1500, PhaseIs, 2); HWND card = (HWND)Info_(3, 0, 0, 0); RECT cr; GetWindowRect(card, &cr);
      WNDCLASSW cc = {}; cc.lpfnWndProc = DefWindowProcW; cc.hInstance = GetModuleHandleW(nullptr); cc.lpszClassName = L"DnTestCover2"; RegisterClassW(&cc);
      HWND cover = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE, L"DnTestCover2", L"", WS_POPUP, cr.left, cr.top, 40, 20, nullptr, nullptr, cc.hInstance, nullptr);
      SetWindowPos(cover, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
      auto Above = [](HWND x, HWND y) { for (HWND w = GetTopWindow(nullptr); w; w = GetWindow(w, GW_HWNDNEXT)) { if (w == x) return true; if (w == y) return false; } return false; };
      bool coverAbove = Above(cover, card); Sleep(1600);
      Check(coverAbove && Above(card, cover), "1.2.0 醒目：别的置顶窗口盖上来，1 秒内卡片回到它上面（与强制显示同一套，菜单开着时不提）");
      DestroyWindow(cover); UnregisterClassW(L"DnTestCover2", cc.hInstance); Close_(tp, 0, 0, 0); Wait(1500, PhaseIs, 0);
      INT_PTR build = Info_(42, 0, 0, 0); INT_PTR s8 = Show("Soft no-capture", "Shown even if it cannot be excluded from capture.", 3000, 8); bool shown = s8 != 0 && Wait(2000, PhaseIs, 2);
      printf("  标志 8：显示 %d，设了不被采集 %d，没做到的原因 %d\n", shown ? 1 : 0, (int)Info_(44, 0, 0, 0), (int)Info_(43, 0, 0, 0));
      if (build >= 19041) Check(shown && !EvFor(s8) && Info_(1, 0, 0, 0) == s8 && (Info_(44, 0, 0, 0) == 1 || Info_(43, 0, 0, 0) == 2), "1.2.0 标志 8 尽量不被屏幕采集：设得上就设上，设不上照常显示（不像标志 2 那样宁可不弹）");
      else Check(shown && Info_(44, 0, 0, 0) == 0 && Info_(43, 0, 0, 0) == 1, "1.2.0 标志 8：系统低于 Windows 10 2004 时照常显示");
      Close_(s8, 0, 0, 0); Wait(1500, PhaseIs, 0);
    }
    Set_(9, 0, 0, 0); Set_(10, 0, 0, 0); Set_(11, 0, 0, 0); Set_(106, 0, 0, 0); Set_(107, 0, 0, 0); Set_(108, -1, 0, 0); Set_(109, 10000, 0, 0); Set_(110, 300000, 0, 0); Set_(111, 10000, 0, 0); Set_(3, 0, 0, 0); Set_(1, (INT_PTR)"en", 0, 0);
  }
  {  // ---- 1.2.2：上一条被指过就关掉时，接着出现的新卡片照样提醒；连点关闭键不会顺手关掉紧接着出现在同一位置的下一条
    Set_(3, 2, 0xFF8A7A, 0); Set_(1, (INT_PTR)"zh-Hans", 0, 0);
    INT_PTR a = Show("Hovered", "This one gets hovered, then closed.", 20000, 4); Wait(1500, PhaseIs, 2);
    int cx, cy; CardCenter(&cx, &cy); int wx = (int)Info_(13, 0, 0, 0), wy = (int)Info_(14, 0, 0, 0); SetCursorPos(wx + cx + 3, wy + cy); Mouse_(1, cx + 3, cy, 0);
    bool hov = Info_(4, 0, 0, 0) == 1; Close_(a, 0, 0, 0); Wait(1500, PhaseIs, 0);
    const char* nt = "Next"; const char* nb = "The next card must still get its attention pulses.";
    INT_PTR b = Show(nt, nb, 20000, 4); Wait(1500, PhaseIs, 2); Sleep(900);
    int pb = (int)Info_(50, 0, 0, 0); printf("  上一条指过后关掉：下一条落定后提醒 %d 次\n", pb);
    Check(hov && pb >= 2, "1.2.2 上一条被指过就关掉，接着出现的新卡片照样有落定后的光晕提醒（1.2.0、1.2.1 把上一条的悬停算到这一条头上，整条不提醒）");
    int l = (int)Info_(16, 0, 0, 0), t = (int)Info_(17, 0, 0, 0), r = (int)Info_(18, 0, 0, 0), bt = (int)Info_(19, 0, 0, 0), xx = (l + r) / 2, yy = (t + bt) / 2; wx = (int)Info_(13, 0, 0, 0); wy = (int)Info_(14, 0, 0, 0);
    SetCursorPos(wx + xx, wy + yy); Mouse_(1, xx, yy, 0); Mouse_(2, xx, yy, 0); Mouse_(3, xx, yy, 0);
    bool closedB = Wait(1000, EvFor, b) && EvOf(b) == 2; Wait(1500, PhaseIs, 0);
    INT_PTR c2 = Show(nt, nb, 20000, 4); Wait(1000, [](INT_PTR) { return Info_(20, 0, 0, 0) >= 1; }, 0);  // 1.2.3：一出现就按第二下（真机上双击时间最短可设 0.2 秒，等到落定再按可能已过了这段而误报）
    Mouse_(2, xx, yy, 0); Mouse_(3, xx, yy, 0); Sleep(200);
    bool kept = Info_(1, 0, 0, 0) == c2 && !EvFor(c2);
    Sleep((int)GetDoubleClickTime()); Mouse_(2, xx, yy, 0); Mouse_(3, xx, yy, 0);  // 过了双击时间：光标不动也照常能点
    bool closedC = Wait(1000, EvFor, c2) && EvOf(c2) == 2;
    printf("  连点关闭键：第一下关掉上一条 %d，紧接着出现的这条没被第二下关掉 %d，过了双击时间再点能关 %d\n", closedB ? 1 : 0, kept ? 1 : 0, closedC ? 1 : 0);
    Check(closedB && kept && closedC, "1.2.2 连点关闭键不会顺手关掉紧接着出现在同一位置的下一条：出现后系统双击时间以内按下关闭键不算，过了照常能点（光标不动也行）");
    SetCursorPos(5, 5); Mouse_(4, 0, 0, 0); Close_(0, 0, 0, 0); Wait(1500, PhaseIs, 0); Set_(3, 0, 0, 0); Set_(1, (INT_PTR)"en", 0, 0);
  }
  {  // ---- 1.2.3：卡片等了约 24.8 天以上（到场计时让人不在时卡片一直等着，Windows 10 2004 起不设上限）——用测试钩子 DN_Set 112 把时刻往前挪 2³¹＋1000 毫秒
    Set_(3, 2, 0xFF8A7A, 0);
    INT_PTR a = Show("Long wait", "Shown for more than 24.8 days (simulated).", 60000, 4); Wait(1500, PhaseIs, 2);
    bool hk = Set_(112, (INT_PTR)(LONG)0x800003E8, 0, 0) == 1; Sleep(200);
    int l = (int)Info_(16, 0, 0, 0), t = (int)Info_(17, 0, 0, 0), r = (int)Info_(18, 0, 0, 0), bt = (int)Info_(19, 0, 0, 0), xx = (l + r) / 2, yy = (t + bt) / 2, wx = (int)Info_(13, 0, 0, 0), wy = (int)Info_(14, 0, 0, 0);
    SetCursorPos(wx + xx, wy + yy); Mouse_(1, xx, yy, 0); Mouse_(2, xx, yy, 0); Mouse_(3, xx, yy, 0);
    bool closed = Wait(1000, EvFor, a) && EvOf(a) == 2; int s56 = (int)Info_(56, 0, 0, 0); Wait(1500, PhaseIs, 0);
    printf("  模拟等了 24.8 天以上：点关闭键 %s，记下的显示毫秒 %d\n", closed ? "关掉了" : "没反应", s56);
    Check(hk && closed && s56 == 0x7FFFFFFF, "1.2.3 卡片等了约 24.8 天以上：关闭键照常能点，显示毫秒到顶停在最大值（1.2.2 有符号相减成负数：关闭键一直不认、统计变负）");
    SetCursorPos(5, 5); Mouse_(4, 0, 0, 0);
    Set_(9, 1, 0, 0); Set_(106, 1, 0, 0);
    INT_PTR b = Show("Long away", "Welcome back after a very long absence (simulated).", 60000, 4); Wait(1500, PhaseIs, 2); Sleep(1600);
    Set_(106, 2, 0, 0); Sleep(600); int w0 = (int)Info_(54, 0, 0, 0); Set_(112, (INT_PTR)(LONG)0x800003E8, 0, 0); Sleep(300); Set_(106, 1, 0, 0); Sleep(700); int w1 = (int)Info_(54, 0, 0, 0);
    printf("  模拟离开 24.8 天以上再回来：人回来再提醒 %d → %d\n", w0, w1);
    Check(w1 == w0 + 1, "1.2.3 人离开约 24.8 天以上再回来：照样再提醒一次（1.2.2 有符号相减成负数就不提醒）");
    Close_(b, 0, 0, 0); Wait(1500, PhaseIs, 0); Set_(9, 0, 0, 0); Set_(106, 0, 0, 0); Set_(3, 0, 0, 0);
  }
  {  // ---- 1.2.4：每秒确认在最上层时不跟全屏独占的游戏、用户正在用的置顶窗口抢
    auto Above = [](HWND x, HWND y) { for (HWND w = GetTopWindow(nullptr); w; w = GetWindow(w, GW_HWNDNEXT)) { if (w == x) return true; if (w == y) return false; } return false; };
    WNDCLASSW cc = {}; cc.lpfnWndProc = DefWindowProcW; cc.hInstance = GetModuleHandleW(nullptr); cc.lpszClassName = L"DnTestTopFg"; RegisterClassW(&cc);
    INT_PTR a = Show("Stay out of the way", "Do not fight what the user is using.", 30000, 1); Wait(1500, PhaseIs, 2); HWND card = (HWND)Info_(3, 0, 0, 0); RECT cr; GetWindowRect(card, &cr);  // 强制显示（标志 1）与醒目（标志 4）走同一套每秒确认；用强制显示的卡片测：没有光晕提醒的整张重画（Wine 里整张重画的分层窗口会被挪到最上面，测不准）
    Set_(107, 3, 0, 0);  // 测试钩子：当作全屏独占的 Direct3D 程序在跑
    HWND cov = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE, L"DnTestTopFg", L"", WS_POPUP, cr.left, cr.top, 40, 20, nullptr, nullptr, cc.hInstance, nullptr);
    SetWindowPos(cov, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
    bool b1 = Above(cov, card); Sleep(1600); bool b2 = Above(cov, card); int why2 = (int)Info_(61, 0, 0, 0);
    Set_(107, 0, 0, 0); Sleep(1600); bool b3 = Above(card, cov);
    printf("  全屏独占时：1.6 秒后别的置顶窗口仍在卡片上面 %d（没提的原因 %d），结束后卡片回到上面 %d\n", b2 ? 1 : 0, why2, b3 ? 1 : 0);
    Check(b1 && b2 && why2 == 4 && b3, "1.2.4 全屏独占的 Direct3D 程序在跑时不每秒提层（卡片画不到它上面，提上去只会打扰游戏）；结束后 1 秒内照常回到最上面");
    DestroyWindow(cov);
    HWND fg = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW, L"DnTestTopFg", L"fg", WS_POPUP, cr.left + 30, cr.top + 20, 120, 60, nullptr, nullptr, cc.hInstance, nullptr);
    ShowWindow(fg, SW_SHOW); SetForegroundWindow(fg); { MSG mm; for (int i = 0; i < 20; i++) { while (PeekMessageW(&mm, nullptr, 0, 0, PM_REMOVE)) DispatchMessageW(&mm); Sleep(10); } }
    if (GetForegroundWindow() == fg) {
      bool a1 = Above(fg, card); LONG s0 = (LONG)Info_(62, 0, 0, 0); Sleep(1600); bool a2 = Above(fg, card); int why = (int)Info_(61, 0, 0, 0);
      printf("  前台是与卡片重叠的置顶窗口：1.6 秒后仍在卡片上面 %d（没提的原因 %d）\n", a2 ? 1 : 0, why);
      Check(a1 && a2 && why == 2 && Info_(62, 0, 0, 0) > s0, "1.2.4 前台是与卡片重叠的置顶窗口（用户正在用它，如托盘溢出区）：每秒确认不把卡片提到它上面");
    } else printf("  INFO 测试窗口没拿到前台（系统前台锁）：跳过“前台置顶窗口”一项\n");
    RECT wa2; SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa2, 0);
    HWND big = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW, L"DnTestTopFg", L"big", WS_POPUP, wa2.left, wa2.top, wa2.right - wa2.left, wa2.bottom - wa2.top, nullptr, nullptr, cc.hInstance, nullptr);
    ShowWindow(big, SW_SHOW); SetForegroundWindow(big); { MSG mm; for (int i = 0; i < 20; i++) { while (PeekMessageW(&mm, nullptr, 0, 0, PM_REMOVE)) DispatchMessageW(&mm); Sleep(10); } }
    if (GetForegroundWindow() == big) {
      bool c1 = Above(big, card); Sleep(1600); bool c2 = Above(card, big);
      printf("  前台是占满工作区的置顶窗口：刚出来时盖住卡片 %d，1.6 秒内卡片回到它上面 %d\n", c1 ? 1 : 0, c2 ? 1 : 0);
      Check(c1 && c2, "1.2.5 前台是大的置顶窗口（开了总在最前的直播软件、播放器）时照常每秒提层：只让开小的（托盘溢出区、弹出面板、小工具），不然卡片会被它整个挡住、一直看不到");
    } else printf("  INFO 大窗口没拿到前台（系统前台锁）：跳过“大的前台置顶窗口”一项\n");
    Close_(a, 0, 0, 0); Wait(1500, PhaseIs, 0);  // 先收起卡片再销毁前台窗口：Wine 把前台交给下一个窗口，卡片还开着时会交给不激活的卡片，界面线程卡在激活切换里，后面计时类的测试受牵连（见 1.1.2 那组测试的说明；真 Windows 不会激活带 WS_EX_NOACTIVATE 的窗口）
    DestroyWindow(big); DestroyWindow(fg); UnregisterClassW(L"DnTestTopFg", cc.hInstance);
  }
  {  // ---- 宿主等候队列的约定（易语言 弹窗提醒_排队_接着显示 依赖它）：DN_Show 返回时当前编号已是这条，宿主的循环据此一次只取一条。三条模拟：A 显示中，B、C 排队；A 关掉后只显示 B、C 仍排着；B 关掉后显示 C
    INT_PTR a = Show("Queue A", "Showing now.", 20000, 4); Wait(1500, PhaseIs, 2);
    std::vector<const char*> q = {"Queued B", "Queued C"}; INT_PTR cur = a; std::vector<INT_PTR> got;
    auto Pop = [&]() { while (!q.empty()) { if (cur && Info_(1, 0, 0, 0) == cur) break; cur = Show("Queue", q.front(), 20000, 4); got.push_back(cur); q.erase(q.begin()); } };  // 同 弹窗提醒_排队_接着显示 / 弹窗提醒_显示中_仅查看
    bool sync = Info_(1, 0, 0, 0) == a;
    Close_(a, 0, 0, 0); Wait(1500, EvFor, a); Pop();
    bool step1 = got.size() == 1 && q.size() == 1 && Info_(1, 0, 0, 0) == got[0];
    Wait(1500, PhaseIs, 2); if (!got.empty()) { Close_(got[0], 0, 0, 0); Wait(1500, EvFor, got[0]); } Pop();
    bool step2 = got.size() == 2 && q.empty() && Info_(1, 0, 0, 0) == got[1];
    printf("  宿主等候队列（三条）：A 关掉后取出 %d 条、还排着 %d 条；B 关掉后共取出 %d 条\n", step1 ? 1 : (int)got.size(), step1 ? 1 : (int)q.size(), (int)got.size());
    Check(sync && step1 && step2, "宿主等候队列（三条）：A 关掉后只显示 B、C 仍排着；B 关掉后显示 C（DN_Show 返回时当前编号已是这条，宿主的循环据此一次只取一条）");
    Close_(0, 0, 0, 0); Wait(1500, PhaseIs, 0);
  }
  // ---- 不被屏幕采集（标志 2，1.1.0 起）：系统够新就设 WDA_EXCLUDEFROMCAPTURE 再显示；做不到就不显示（老系统返回 0，设置失败回调事件 4）；不带标志 2 的卡片恢复为可被采集
  {
    typedef BOOL(WINAPI* GWDA)(HWND, DWORD*);
    GWDA gwda = (GWDA)(void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetWindowDisplayAffinity");
    INT_PTR build = Info_(42, 0, 0, 0);
    printf("  系统内部版本号 %d\n", (int)build);
    INT_PTR nc = Show("No capture", "This card must not appear in screen captures.", 4000, 2);
    if (build < 19041) {
      Check(nc == 0 && Info_(43, 0, 0, 0) == 1 && Info_(1, 0, 0, 0) == 0, "不被屏幕采集：系统低于 Windows 10 2004 时不显示（返回 0，原因 1）");
    } else {
      Check(nc != 0, "不被屏幕采集：返回编号");
      Wait(2000, [](INT_PTR id) { return PhaseIs(2) || EvFor(id); }, nc);
      HWND h = (HWND)Info_(3, 0, 0, 0); DWORD aff = 0xFFFF;
      bool got = gwda && gwda(h, &aff);
      if (EvOf(nc) == 4) {
        Check(Info_(43, 0, 0, 0) == 2 && PhaseIs(0) && Info_(1, 0, 0, 0) == 0, "不被屏幕采集：系统没设上时这条不显示、回调事件 4");
        {  // 正在显示一条普通卡片时来了一条设不上的：普通卡片照常按「被替换」回调 3 并立刻收起，新的这条回调 4、不显示，当前编号清零
          INT_PTR a = Show("Visible", "A normal card is on screen.", 4000, 0);
          bool shown = a != 0 && Wait(2000, PhaseIs, 2);
          INT_PTR b2 = Show("No capture", "Rejected while another card is visible.", 4000, 2);
          bool done = Wait(2000, [](INT_PTR id) { return EvFor(id); }, b2);
          Check(shown && done && EvOf(a) == 3 && EvOf(b2) == 4 && PhaseIs(0) && Info_(1, 0, 0, 0) == 0 && Info_(27, 0, 0, 0) == 0,
                "不被屏幕采集：替换正在显示的卡片时没设上——旧的回调 3 并收起，新的回调 4 不显示，窗口隐藏");
        }
        if (PatchSwdaTrue()) {
          INT_PTR n2 = Show("No capture", "Capture-excluded card (system call simulated as successful).", 4000, 2);
          Check(n2 != 0 && Wait(2000, PhaseIs, 2) && Info_(44, 0, 0, 0) == 1 && Info_(1, 0, 0, 0) == n2, "（模拟系统设置成功）不被屏幕采集：卡片照常显示，记为已设置");
          INT_PTR n3 = Show("Normal", "A normal card can be captured again.", 3000, 0);
          bool cleared = Wait(2000, [](INT_PTR) { return Info_(44, 0, 0, 0) == 0; }, 0);   // 等界面线程处理完这条（替换时阶段本来就是「显示」，不能只等阶段）
          Check(n3 != 0 && cleared && Info_(1, 0, 0, 0) == n3 && EvOf(n2) == 3 && Wait(2000, PhaseIs, 2), "（模拟）接着显示不带标志 2 的卡片：新内容贴出去之后恢复为可被采集，前一条按被替换回调 3");
          Close_(0, 0, 0, 0); Wait(1500, PhaseIs, 0);
        } else printf("  INFO 改不了 SetWindowDisplayAffinity：跳过模拟成功路径\n");
      } else {
        printf("  GetWindowDisplayAffinity：%s 0x%lX\n", got ? "成功" : "失败", (unsigned long)aff);
        Check(PhaseIs(2) && Info_(44, 0, 0, 0) == 1 && (!got || aff == 0x11), "不被屏幕采集：卡片显示，窗口设了 WDA_EXCLUDEFROMCAPTURE");
        INT_PTR nn = Show("Normal", "A normal card can be captured again.", 3000, 0);
        Check(nn != 0 && Wait(2000, PhaseIs, 2) && Info_(44, 0, 0, 0) == 0 && (!gwda || (gwda(h, &aff) && aff == 0)), "接着显示不带标志 2 的卡片：恢复为可被采集");
        Check(EvOf(nc) == 3, "带标志 2 的那条被新的一条替换：回调事件 3");
      }
      Close_(0, 0, 0, 0); Wait(1500, PhaseIs, 0);
    }
    INT_PTR keep = Show("Keep", "Shown before a capture-excluded card is rejected.", 4000, 0);
    Wait(2000, PhaseIs, 2);
    Close_(keep, 0, 0, 0); Wait(1500, PhaseIs, 0); Stop_(0, 0, 0, 0);
  }
  {  // 1.2.0 标志 8：系统设得上时设上（Wine 里上面已把 SetWindowDisplayAffinity 改成总是成功——真机走这条路），之后的普通卡片恢复为可被采集
    INT_PTR build = Info_(42, 0, 0, 0); INT_PTR s8 = Show("Soft no-capture", "Excluded from capture when the system supports it.", 3000, 8); bool shown = s8 != 0 && Wait(2000, PhaseIs, 2);
    if (build >= 19041) Check(shown && Info_(44, 0, 0, 0) == 1, "1.2.0 标志 8（系统设得上）：卡片照常显示，设了不被屏幕采集");
    else Check(shown && Info_(44, 0, 0, 0) == 0, "1.2.0 标志 8：系统低于 Windows 10 2004 时照常显示");
    INT_PTR n0 = Show("Normal", "Capturable again.", 2000, 0); bool rep8 = Wait(2000, EvFor, s8);  // 先等被替换的那条的回调（界面线程处理了新命令），再看状态——只等「阶段 2」会在新命令处理之前就返回
    bool clr = Wait(2000, [](INT_PTR) { return Info_(44, 0, 0, 0) == 0; }, 0);  // 「替换」回调在处理新命令的开头发出，恢复可被采集在新内容贴出去之后（命令的末尾）：等最终状态
    Check(n0 != 0 && rep8 && clr && Info_(1, 0, 0, 0) == n0 && Wait(2000, PhaseIs, 2), "1.2.0 标志 8 之后的普通卡片：新内容贴出去之后恢复为可被采集");
    Close_(0, 0, 0, 0); Wait(1500, PhaseIs, 0); Stop_(0, 0, 0, 0);
  }
  if (!dmg.empty()) {  // 1.1.1：宿主字体的字形坏了（GDI+ 自检用的 A 是好的，别的字取不到轮廓）：画的时候发现、换回系统字体再画一遍，文字照样画得出
    Set_(1, (INT_PTR)"zh-Hans", 0, 0); Set_(2, (INT_PTR)dmg.c_str(), (INT_PTR)dmg.c_str(), 0);
    Show("字形坏了的宿主字体 Test", "正文：换回系统字体照样显示。Body 123.", 20000); Sleep(600);
    Set_(105, 0, 0, 0); bool ok = Snap("_dmg_a.png", 100, 1000) == 1; Set_(105, 1, 0, 0); ok = Snap("_dmg_b.png", 100, 1000) == 1 && ok; Set_(105, 0, 0, 0);
    int n = InkDiff(outDir + "\\_dmg_a.png", outDir + "\\_dmg_b.png"); int cus = (int)Info_(30, 0, 0, 0);
    char w[300]; sprintf(w, "宿主字体的字形坏了：换回系统字体（宿主字体在用 %d），文字照样画得出（笔画像素 %d）", cus, n); Check(ok && n > 100 && cus == 0, w);
    Close_(0, 0, 0, 0); Sleep(200); if (!cjk.empty()) Set_(2, (INT_PTR)cjk.c_str(), (INT_PTR)cjk.c_str(), 0); else Set_(2, 0, 0, 0);
  } else printf("INFO 没有字形坏了的宿主字体（需要 fontTools）：跳过 1 项\n");
  // ---- 1.1.1：个别系统上画不出字（卡片只剩图标与底色）——精绘、GDI+ 逐级退路。用 DN_Set 104 模拟：精绘的贴图不起作用（应改走 GDI+）、
  // GDI+ 也画不出字（应改走 GDI）；每种都比较“有字 − 不画字（DN_Set 105）”的笔画像素，并看信息 45
  {
    struct M { int bits; const char* name; int mask, want; } modes[] = {{0, "正常", 3, 0}, {1, "精绘贴图不起作用，改走 GDI+", 1, 1}, {3, "精绘与 GDI+ 都画不出字，改走 GDI", 6, 6}};
    int base = -1;
    for (auto& m : modes) {
      Set_(104, m.bits, 0, 0);
      Show("文字退路 Fallback 测试", "正文：个别系统上画不出字时，换一种画法照样显示。Body text 123.", 20000);
      Sleep(400);
      Set_(105, 0, 0, 0); bool ok = Snap("_txt_a.png", 100, 1000) == 1;
      Set_(105, 1, 0, 0); ok = Snap("_txt_b.png", 100, 1000) == 1 && ok; Set_(105, 0, 0, 0);
      int n = InkDiff(outDir + "\\_txt_a.png", outDir + "\\_txt_b.png");
      if (m.bits == 0) base = n;
      char w[300]; sprintf(w, "文字退路（%s）：卡片画出了字（笔画像素 %d，正常 %d）", m.name, n, base); Check(ok && n > 100 && (base <= 0 || n * 3 > base), w);
      int info = (int)Info_(45, 0, 0, 0); sprintf(w, "文字退路（%s）：信息 45 为 %d", m.name, info); Check((info & m.mask) == m.want, w);
    }
    Set_(104, 0, 0, 0); Close_(0, 0, 0, 0); Sleep(200);
  }
  printf("SUMMARY 通过 %d 失败 %d\n", passes, fails);
  return fails ? 1 : 0;
}
