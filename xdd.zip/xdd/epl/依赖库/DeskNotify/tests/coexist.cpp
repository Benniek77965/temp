// 与悬浮窗（XhhFloat.dll）同进程共存的测试（run_all.sh 在有 fontTools 时跑）：易语言程序里两个 DLL 同时载入、各有界面线程，
// 都按私有方式登记、映射同一份鸿蒙黑体。这里按易语言启动悬浮窗的顺序启动它（简体中文、字体目录、皮肤），显示一个暂停的中文曲名（画面静止），
// 再让 DeskNotify 用同一组字体文件反复显示、改文字、关闭，并停止重启 3 次（每次撤销自己对这些文件的登记、解除映射）。
// 判定：悬浮窗前后一直用着鸿蒙黑体（状态 1）、仍在显示、前后截图逐像素相同；DeskNotify 用上了同一份字体；两边都能正常收尾。
// 用法：coexist.exe XhhFloat.dll DeskNotify.dll 字体目录 截图目录（路径都是 UTF-8 也认得的 Windows 路径）
#include <windows.h>
#include <gdiplus.h>
#include <stdio.h>
#include <string>
using namespace Gdiplus;
typedef INT_PTR (WINAPI* F4)(INT_PTR, INT_PTR, INT_PTR, INT_PTR);
static INT_PTR WINAPI Cb(INT_PTR, INT_PTR) { return 0; }
static int fails = 0, passes = 0;
static void Check(bool ok, const char* what) { printf("%s %s\n", ok ? "PASS" : "FAIL", what); fflush(stdout); if (ok) passes++; else fails++; }
static std::string U8(const wchar_t* w) { int n = WideCharToMultiByte(CP_UTF8, 0, w, -1, nullptr, 0, nullptr, nullptr); std::string s(n, 0); WideCharToMultiByte(CP_UTF8, 0, w, -1, &s[0], n, nullptr, nullptr); s.resize(n - 1); return s; }
static bool SamePng(const std::wstring& a, const std::wstring& b, int* ink) {  // 两张截图逐像素相同；ink＝不透明像素数（确认截到的是真内容）
  Bitmap A(a.c_str()), B(b.c_str()); if (A.GetLastStatus() != Ok || B.GetLastStatus() != Ok || A.GetWidth() != B.GetWidth() || A.GetHeight() != B.GetHeight()) return false;
  int w = A.GetWidth(), h = A.GetHeight(); *ink = 0;
  for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) { Color c1, c2; A.GetPixel(x, y, &c1); B.GetPixel(x, y, &c2); if (c1.GetValue() != c2.GetValue()) return false; if (c1.GetA()) (*ink)++; }
  return true;
}
int main() {
  SetProcessDPIAware();
  int argc = 0; LPWSTR* av = CommandLineToArgvW(GetCommandLineW(), &argc); if (argc < 5) { printf("用法：coexist.exe XhhFloat.dll DeskNotify.dll 字体目录 截图目录\n"); return 2; }
  ULONG_PTR tok; GdiplusStartupInput gi; GdiplusStartup(&tok, &gi, nullptr);
  HMODULE xf = LoadLibraryW(av[1]), dn = LoadLibraryW(av[2]); Check(xf && dn, "两个 DLL 载入同一个进程");
  if (!xf || !dn) return 1;
  auto X = [&](const char* n) { return (F4)GetProcAddress(xf, n); }; auto D = [&](const char* n) { return (F4)GetProcAddress(dn, n); };
  F4 XStart = X("XF_Start"), XStop = X("XF_Stop"), XShow = X("XF_Show"), XSkin = X("XF_SetSkin"), XLang = X("XF_SetLanguage"), XFont = X("XF_SetFontDir"), XTInfo = X("XF_SetTrackInfo"), XInfo = X("XF_GetInfo"), XSnap = X("XF_Snapshot");
  F4 DSet = D("DN_Set"), DShow = D("DN_Show"), DUpd = D("DN_Update"), DClose = D("DN_Close"), DInfo = D("DN_GetInfo"), DStop = D("DN_Stop");
  std::wstring dirW = av[3], shotW = av[4]; std::string dir = U8(dirW.c_str());
  std::string fm = U8((dirW + L"\\HarmonyOS_SansSC\\HarmonyOS_SansSC_Medium.ttf").c_str()), fb = U8((dirW + L"\\HarmonyOS_SansSC\\HarmonyOS_SansSC_Bold.ttf").c_str());
  std::wstring p1 = shotW + L"\\coexist_before.png", p2 = shotW + L"\\coexist_after.png"; std::string p1u = U8(p1.c_str()), p2u = U8(p2.c_str());
  XLang((INT_PTR)"zh-Hans", 0, 0, 0); XFont((INT_PTR)dir.c_str(), 0, 0, 0); XSkin(1, 0, 0, 0);
  Check(XStart(300, 200, 0, (INT_PTR)Cb) == 1, "悬浮窗按易语言的顺序启动");
  XShow(1, 0, 0, 0); XTInfo(0, 2, (INT_PTR)u8"测试曲名：小红花", 0); Sleep(1500);
  int f0 = (int)XInfo(16, 0, 0, 0); bool s1 = XSnap((INT_PTR)p1u.c_str(), 100, 0, 0) == 1;
  Check(f0 == 1, "悬浮窗用上了字体目录里的鸿蒙黑体（状态 1）");
  DSet(6, (INT_PTR)Cb, 0, 0); DSet(1, (INT_PTR)"zh-Hans", 0, 0); DSet(2, (INT_PTR)fm.c_str(), (INT_PTR)fb.c_str(), 0);
  int shows = 0, custom = 0, stops = 0;
  for (int round = 0; round < 3; round++) {
    for (int i = 0; i < 20; i++) {
      INT_PTR id = DShow((INT_PTR)u8"创建桌面快捷方式失败", (INT_PTR)u8"可能是被360安全卫士拦截，建议关闭后重开本软件。", 800, 0); if (id) shows++;
      Sleep(80); if (DInfo(30, 0, 0, 0) == 1) custom++;
      if (i % 5 == 2) DUpd(id, (INT_PTR)u8"提示", (INT_PTR)u8"改过的文字", 0);
      if (i % 7 == 3) DClose(0, 0, 0, 0);
    }
    Sleep(1200); if (DStop(0, 0, 0, 0) == 1) stops++;  // 停止：DeskNotify 撤销自己对这些字体文件的私有登记、解除映射
    Sleep(300);
  }
  printf("  DeskNotify：显示 %d 次，读数里用上同一份宿主字体 %d 次，停止重启 %d 次\n", shows, custom, stops);
  Check(shows == 60 && custom >= 55 && stops == 3, "DeskNotify 用同一组字体文件照常显示，停止重启 3 次");
  int f1 = (int)XInfo(16, 0, 0, 0), vis = (int)XInfo(3, 0, 0, 0);
  XTInfo(0, 2, (INT_PTR)u8"测试曲名：小红花", 0); Sleep(800);
  bool s2 = XSnap((INT_PTR)p2u.c_str(), 100, 0, 0) == 1; int ink = 0; bool same = s1 && s2 && SamePng(p1, p2, &ink);
  printf("  悬浮窗：字体状态 %d → %d，仍在显示 %d，前后截图逐像素相同 %d（不透明像素 %d）\n", f0, f1, vis, (int)same, ink);
  Check(f1 == 1 && vis == 1 && same && ink > 1000, "DeskNotify 撤销登记、解除映射之后：悬浮窗仍用着鸿蒙黑体、仍在显示、画面不变");
  Check(XStop(0, 0, 0, 0) == 1, "两边都能正常收尾");
  GdiplusShutdown(tok);
  printf("SUMMARY 通过 %d 失败 %d\n", passes, fails); return fails ? 1 : 0;
}
