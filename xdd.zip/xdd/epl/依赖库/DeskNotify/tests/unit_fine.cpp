// 精绘模块的单元测试（只在 Wine 里由 run_all.sh 跑：会临时往注册表的字体表写几项，测完删掉；不放进 dntest.exe，免得在真机上留下假的字体项）
// 测的是按注册表找系统字体文件（SystemFontFile）：
//   1. 某一项的路径超长（缓冲区不够）时跳过它接着找，后面的字体照样找得到（原来一律结束枚举）；
//   2. 注册表里的字符串没有以零结尾时，读出来正好是那几个字，不会带出缓冲区外的内容；
//   3.（1.1.1）字体文件完整性（SfntInside）：表目录与每张表都要在文件范围之内，字体集逐款查——没下载完、被截断、被改坏的文件不交给字体引擎。
#include "dn_fine.cpp"
bool DnFontInfo(Font*, std::wstring&, int&) { return false; }  // 本测试不画字：精绘里用到的这个函数给个空实现
#include <stdio.h>
static const wchar_t* KEY = L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Fonts";
static int fails = 0;
static void Check(bool ok, const char* what) { printf("%s %s\n", ok ? "PASS" : "FAIL", what); if (!ok) fails++; }
int wmain() {
  HKEY k; if (RegCreateKeyExW(HKEY_CURRENT_USER, KEY, 0, nullptr, 0, KEY_ALL_ACCESS, nullptr, &k, nullptr) != ERROR_SUCCESS) { printf("FAIL 打不开字体表\n"); return 1; }
  std::wstring longPath = L"C:\\" + std::wstring(300, L'x') + L".ttf";
  RegSetValueExW(k, L"DNUnit Long Entry (TrueType)", 0, REG_SZ, (const BYTE*)longPath.c_str(), (DWORD)((longPath.size() + 1) * 2));
  const wchar_t* tgt = L"C:\\dnunit\\after_long.ttf";
  RegSetValueExW(k, L"DNUnit After (TrueType)", 0, REG_SZ, (const BYTE*)tgt, (DWORD)((wcslen(tgt) + 1) * 2));
  const wchar_t raw[] = L"C:\\dn\\a.ttf";  // 存的时候不带结尾零
  RegSetValueExW(k, L"DNUnit NoNull (TrueType)", 0, REG_SZ, (const BYTE*)raw, (DWORD)(wcslen(raw) * 2));
  RegCloseKey(k);
  std::wstring r1 = SystemFontFile(L"DNUnit After", false), r2 = SystemFontFile(L"DNUnit NoNull", false);
  Check(r1 == tgt, "精绘找系统字体文件：前面有一项路径超长时跳过它，后面的字体照样找得到");
  Check(r2 == raw, "精绘找系统字体文件：注册表里没有以零结尾的路径，读出来正好是那几个字");
  RegOpenKeyExW(HKEY_CURRENT_USER, KEY, 0, KEY_ALL_ACCESS, &k);
  RegDeleteValueW(k, L"DNUnit Long Entry (TrueType)"); RegDeleteValueW(k, L"DNUnit After (TrueType)"); RegDeleteValueW(k, L"DNUnit NoNull (TrueType)"); RegCloseKey(k);
  { // 3. 字体文件完整性（SfntInside）：用合成的最小字体数据测，不依赖测试环境里有什么字体
    auto be32 = [](std::vector<unsigned char>& v, size_t at, unsigned x) { v[at] = (unsigned char)(x >> 24); v[at + 1] = (unsigned char)(x >> 16); v[at + 2] = (unsigned char)(x >> 8); v[at + 3] = (unsigned char)x; };
    auto be16 = [](std::vector<unsigned char>& v, size_t at, unsigned x) { v[at] = (unsigned char)(x >> 8); v[at + 1] = (unsigned char)x; };
    std::vector<unsigned char> f(32, 0);  // 单个字体：12 字节文件头 + 1 条表目录（表在 28 处、长 4）+ 4 字节表数据
    be32(f, 0, 0x00010000); be16(f, 4, 1); be32(f, 12, 0x74657374); be32(f, 20, 28); be32(f, 24, 4);
    Check(SfntInside(f.data(), f.size()), "字体文件完整性：完整的单个字体通过");
    Check(!SfntInside(f.data(), 30), "字体文件完整性：最后一张表超出文件（没下载完）不通过");
    Check(!SfntInside(f.data(), 20), "字体文件完整性：表目录超出文件不通过");
    std::vector<unsigned char> g = f; be32(g, 0, 0x12345678); Check(!SfntInside(g.data(), g.size()), "字体文件完整性：不认识的文件头不通过");
    std::vector<unsigned char> z = f; be16(z, 4, 0); Check(!SfntInside(z.data(), z.size()), "字体文件完整性：一张表也没有不通过");
    std::vector<unsigned char> c(48, 0);  // 字体集：'ttcf' 头（1 款，在 16 处）+ 那一款（表在 44 处、长 4）
    be32(c, 0, 0x74746366); be32(c, 4, 0x00010000); be32(c, 8, 1); be32(c, 12, 16);
    be32(c, 16, 0x00010000); be16(c, 20, 1); be32(c, 28, 0x74657374); be32(c, 36, 44); be32(c, 40, 4);
    Check(SfntInside(c.data(), c.size()), "字体文件完整性：完整的字体集通过");
    Check(!SfntInside(c.data(), c.size() - 2), "字体文件完整性：字体集里某一款的表超出文件不通过");
    std::vector<unsigned char> c0 = c; be32(c0, 8, 0); Check(!SfntInside(c0.data(), c0.size()), "字体文件完整性：字体集里一款也没有不通过");
    std::vector<unsigned char> cb = c; be32(cb, 8, 65); Check(!SfntInside(cb.data(), cb.size()), "字体文件完整性：字体集的款数离谱不通过");
  }
  return fails ? 1 : 0;
}
