#!/usr/bin/env bash
# Linux 交叉编译（tests/run_all.sh 调它）；Windows 上用 build.bat。输出 out/DeskNotify.dll（32 位）
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUTDIR="${1:-$ROOT/out}"
CXX=${CXX:-i686-w64-mingw32-g++}
WINDRES=${WINDRES:-i686-w64-mingw32-windres}
mkdir -p "$OUTDIR"
$WINDRES -i "$ROOT/src/desknotify.rc" -O coff -o "$OUTDIR/desknotify_res.o"
$CXX -std=c++17 -Os -s -shared -static -static-libgcc -static-libstdc++ -ffunction-sections -fdata-sections \
  -fno-exceptions -fno-rtti -fno-asynchronous-unwind-tables -DUNICODE -D_UNICODE -DWINVER=0x0601 -D_WIN32_WINNT=0x0601 \
  -Wall -Wextra -Wno-unused-parameter -Wno-missing-field-initializers -Wno-misleading-indentation -Wno-free-nonheap-object -Wno-unused-function \
  "$ROOT/src/dn_core.cpp" "$ROOT/src/dn_text.cpp" "$ROOT/src/dn_fine.cpp" "$OUTDIR/desknotify_res.o" \
  -o "$OUTDIR/DeskNotify.dll" -Wl,--gc-sections -Wl,--kill-at -Wl,--nxcompat -Wl,--dynamicbase \
  -Wl,--major-subsystem-version,6 -Wl,--minor-subsystem-version,1 -Wl,--no-insert-timestamp -Wl,--disable-auto-image-base \
  -lgdiplus -lgdi32 -luser32 -ladvapi32 -lusp10 -lole32
rm -f "$OUTDIR/desknotify_res.o"
