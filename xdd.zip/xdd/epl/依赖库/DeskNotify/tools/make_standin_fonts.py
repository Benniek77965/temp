#!/usr/bin/env python3
# 生成两份“鸿蒙黑体”的替身字体（同进程共存测试用，见 tests/coexist.cpp）：拿一个中文字体复制两份，按字体包里鸿蒙黑体的命名改名——
# 常规字重族名“HarmonyOS Sans SC Medium”，粗体族名“HarmonyOS Sans SC”（悬浮窗按族名里有没有 Medium 认常规与粗体），放进 目标目录/HarmonyOS_SansSC/。
# 用法：make_standin_fonts.py 源字体 目标目录（需要 fontTools）
import sys, os
from fontTools.ttLib import TTFont
src, out = sys.argv[1], os.path.join(sys.argv[2], 'HarmonyOS_SansSC')
os.makedirs(out, exist_ok=True)
def make(dst, fam, sub, full, ps, tsub, bold):
    f = TTFont(src); nm = f['name']
    for rec in list(nm.names):
        if rec.nameID in (1, 2, 4, 6, 16, 17): nm.removeNames(nameID=rec.nameID)
    for pid, eid, lid in ((3, 1, 0x409), (1, 0, 0)):
        nm.setName(fam, 1, pid, eid, lid); nm.setName(sub, 2, pid, eid, lid); nm.setName(full, 4, pid, eid, lid); nm.setName(ps, 6, pid, eid, lid)
        nm.setName('HarmonyOS Sans SC', 16, pid, eid, lid); nm.setName(tsub, 17, pid, eid, lid)
    f['OS/2'].usWeightClass = 700 if bold else 500
    f['OS/2'].fsSelection = (f['OS/2'].fsSelection & ~0x61) | (0x20 if bold else 0x40)
    f['head'].macStyle = (f['head'].macStyle & ~1) | (1 if bold else 0)
    f.save(os.path.join(out, dst))
make('HarmonyOS_SansSC_Medium.ttf', 'HarmonyOS Sans SC Medium', 'Regular', 'HarmonyOS Sans SC Medium', 'HarmonyOSSansSC-Medium', 'Medium', False)
make('HarmonyOS_SansSC_Bold.ttf', 'HarmonyOS Sans SC', 'Bold', 'HarmonyOS Sans SC Bold', 'HarmonyOSSansSC-Bold', 'Bold', True)
print('替身字体已生成：', out)
