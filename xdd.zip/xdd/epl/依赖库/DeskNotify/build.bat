@echo off
rem Windows ���� MinGW-w64��i686��32 λ������ out\DeskNotify.dll���� build.sh ͬһ�����
setlocal
set ROOT=%~dp0
if not exist "%ROOT%out" mkdir "%ROOT%out"
windres -i "%ROOT%src\desknotify.rc" -O coff -o "%ROOT%out\desknotify_res.o" || exit /b 1
g++ -std=c++17 -Os -s -shared -static -static-libgcc -static-libstdc++ -ffunction-sections -fdata-sections ^
  -fno-exceptions -fno-rtti -fno-asynchronous-unwind-tables -DUNICODE -D_UNICODE -DWINVER=0x0601 -D_WIN32_WINNT=0x0601 ^
  -Wall -Wextra -Wno-unused-parameter -Wno-missing-field-initializers -Wno-misleading-indentation -Wno-free-nonheap-object -Wno-unused-function ^
  "%ROOT%src\dn_core.cpp" "%ROOT%src\dn_text.cpp" "%ROOT%src\dn_fine.cpp" "%ROOT%out\desknotify_res.o" ^
  -o "%ROOT%out\DeskNotify.dll" -Wl,--gc-sections -Wl,--kill-at -Wl,--nxcompat -Wl,--dynamicbase ^
  -Wl,--major-subsystem-version,6 -Wl,--minor-subsystem-version,1 -Wl,--no-insert-timestamp -Wl,--disable-auto-image-base ^
  -lgdiplus -lgdi32 -luser32 -ladvapi32 -lusp10 -lole32 || exit /b 1
del "%ROOT%out\desknotify_res.o"
echo OK: %ROOT%out\DeskNotify.dll
echo �ǵð������Ƴ� ..\..\��Դ\dll_DeskNotify.Image.dat����������Դ dll_DeskNotify��
