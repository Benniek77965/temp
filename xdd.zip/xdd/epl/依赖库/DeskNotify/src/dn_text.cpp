// 文字：字体（按语种的系统字体栈＋宿主给的字体文件）、量与画（中日韩、拉丁、西里尔等走精绘，其余走 GDI+）、断行（Uniscribe 的断行点）
#include "dn.h"
#include <usp10.h>
#include <map>
#include <math.h>
#include <algorithm>

Color C(unsigned rgb, int a) { return Color((BYTE)(a < 0 ? 0 : a > 255 ? 255 : a), (BYTE)(rgb >> 16), (BYTE)(rgb >> 8), (BYTE)rgb); }
std::wstring Utf8ToW(const char* s) {
  if (!s || !*s) return L"";
  int n = MultiByteToWideChar(CP_UTF8, 0, s, -1, nullptr, 0); if (n <= 1) return L"";
  std::wstring w((size_t)n - 1, L'\0'); MultiByteToWideChar(CP_UTF8, 0, s, -1, &w[0], n); return w;
}
std::string WToUtf8(const std::wstring& w) {
  if (w.empty()) return "";
  int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
  std::string s((size_t)n, '\0'); WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n, nullptr, nullptr); return s;
}
void RoundRectPath(GraphicsPath& p, float x, float y, float w, float h, float r) {
  float mx = (w < h ? w : h) / 2; if (r > mx) r = mx;
  if (r <= 0) { p.AddRectangle(RectF(x, y, w, h)); return; }
  p.AddArc(x, y, r * 2, r * 2, 180.f, 90.f); p.AddArc(x + w - r * 2, y, r * 2, r * 2, 270.f, 90.f);
  p.AddArc(x + w - r * 2, y + h - r * 2, r * 2, r * 2, 0.f, 90.f); p.AddArc(x, y + h - r * 2, r * 2, r * 2, 90.f, 90.f); p.CloseFigure();
}
void BoxBlurAlpha(std::vector<unsigned char>& a, int w, int h, int r) {  // 三遍方框模糊（近似高斯）
  if (r <= 0 || w <= 0 || h <= 0) return;
  std::vector<unsigned char> t((size_t)w * h); int d = 2 * r + 1;
  for (int pass = 0; pass < 3; pass++) {
    for (int y = 0; y < h; y++) {
      const unsigned char* row = &a[(size_t)y * w]; int s = 0;
      for (int x = -r; x <= r; x++) s += row[x < 0 ? 0 : x >= w ? w - 1 : x];
      for (int x = 0; x < w; x++) { t[(size_t)y * w + x] = (unsigned char)(s / d); int xo = x - r, xi = x + r + 1; s += row[xi >= w ? w - 1 : xi] - row[xo < 0 ? 0 : xo]; }
    }
    for (int x = 0; x < w; x++) {
      int s = 0;
      for (int y = -r; y <= r; y++) s += t[(size_t)(y < 0 ? 0 : y >= h ? h - 1 : y) * w + x];
      for (int y = 0; y < h; y++) { a[(size_t)y * w + x] = (unsigned char)(s / d); int yo = y - r, yi = y + r + 1; s += t[(size_t)(yi >= h ? h - 1 : yi) * w + x] - t[(size_t)(yo < 0 ? 0 : yo) * w + x]; }
    }
  }
}

// ---------------- 语种 ----------------
static const char* LANGS[] = {"zh-Hans", "zh-Hant", "en", "ja", "ko", "es", "pt-BR", "fr", "de", "id", "th", "vi", "tr", "ar", "ru", "ms", "fil", "hi", "it"};
enum { NL = 19 };
int LangIndex(const char* code) {
  if (!code || !*code) return 2;
  for (int i = 0; i < NL; i++) if (_stricmp(code, LANGS[i]) == 0) return i;
  if (_strnicmp(code, "zh", 2) == 0) return (strstr(code, "Hant") || strstr(code, "TW") || strstr(code, "HK")) ? 1 : 0;
  if (_strnicmp(code, "pt", 2) == 0) return 6;
  for (int i = 0; i < NL; i++) { size_t n = strlen(LANGS[i]); if (n == 2 && _strnicmp(code, LANGS[i], 2) == 0 && (code[2] == 0 || code[2] == '-' || code[2] == '_')) return i; }
  return 2;
}
const char* LangCode(int i) { return (i >= 0 && i < NL) ? LANGS[i] : "en"; }
bool LangRtl(int i) { return i == 13; }

// ---------------- 字体 ----------------
static std::map<Font*, std::pair<std::wstring, int>> g_fontInfo;  // 字体对象 → 建它时要的族名与字形（精绘按这个找字体文件）
bool DnFontInfo(Font* f, std::wstring& fam, int& style) { auto it = g_fontInfo.find(f); if (it == g_fontInfo.end()) return false; fam = it->second.first; style = it->second.second; return true; }
static std::vector<std::pair<std::wstring, bool>> g_famMemo;  // 已装字体的查询结果（系统字体有变化时清掉）
void DnSystemFontsChanged() { g_famMemo.clear(); }
static bool FamilyInstalled(const std::wstring& fam) {
  for (auto& m : g_famMemo) if (m.first == fam) return m.second;
  FontFamily ff(fam.c_str()); bool ok = ff.GetLastStatus() == Ok && ff.IsAvailable();
  g_famMemo.push_back({fam, ok}); return ok;
}
std::vector<std::wstring> Fonts::uiList() {  // 各语种的系统界面字体（与 Windows 自带界面一致）
  const char* code = LangCode(lang); std::vector<std::wstring> v; auto add = [&](const wchar_t* f) { v.push_back(f); };
  if (!strcmp(code, "ja")) { add(L"Yu Gothic UI"); add(L"Meiryo UI"); add(L"Meiryo"); }
  else if (!strcmp(code, "ko")) { add(L"Malgun Gothic"); add(L"Gulim"); }
  else if (!strcmp(code, "zh-Hant")) { add(L"Microsoft JhengHei UI"); add(L"Microsoft JhengHei"); }
  else if (!strcmp(code, "th")) { add(L"Leelawadee UI"); add(L"Leelawadee"); add(L"Tahoma"); }
  else if (!strcmp(code, "hi")) { add(L"Nirmala UI"); add(L"Mangal"); add(L"Segoe UI"); }
  else if (!strcmp(code, "zh-Hans")) { add(L"Microsoft YaHei UI"); add(L"Microsoft YaHei"); }
  add(L"Segoe UI"); add(L"Microsoft YaHei UI"); add(L"Microsoft YaHei"); add(L"Tahoma"); add(L"Arial");
  return v;
}
void Fonts::clear() { for (auto& c : cache) { g_fontInfo.erase(c.f); delete c.f; } cache.clear(); picked.clear(); fbCache.clear(); }
void Fonts::systemChanged() { clear(); dropCov(); allFams.clear(); allTried = false; deadBlocks.clear(); scanMs = 0; }  // 系统装上或卸掉了字体：系统字体的各层缓存都重来（宿主给的字体不受影响）
void Fonts::dropCov() { for (auto* c : cov) { if (c->dc) { SelectObject(c->dc, c->old); DeleteDC(c->dc); } if (c->hf) DeleteObject(c->hf); delete c; } cov.clear(); fbCache.clear(); }  // 扫不到的区块与扫描用时不清：同样的字不会因为缓存重来又扫一遍
void Fonts::dropCustom() {
  clear();  // 先放掉用私有字体集建的字体对象，再删字体集
  delete colR; delete colB; colR = colB = nullptr;
  for (auto& f : added) RemoveFontResourceExW(f.c_str(), FR_PRIVATE, nullptr);
  added.clear(); famR.clear(); famB.clear(); cusOk = false; dropCov();
}
Fonts::~Fonts() { dropCustom(); }
void Fonts::setLang(int l) { if (l != lang) { lang = l; clear(); } }
void Fonts::setCustom(const std::wstring& r, const std::wstring& b) {
  if (r == cusReg && b == cusBold) return;
  dropCustom(); cusReg = r; cusBold = b; cusTried = false;
}
Font* Fonts::get(const std::wstring& fam, float px, int style, FontCollection* col) {
  for (auto& c : cache) if (c.fam == fam && fabsf(c.px - px) < 0.01f && c.style == style) return c.f;
  Font* f = new Font(fam.c_str(), px, style, UnitPixel, col);
  if (f->GetLastStatus() != Ok) { delete f; return nullptr; }
  cache.push_back({fam, px, style, f}); g_fontInfo[f] = {fam, style}; return f;
}
bool Fonts::selfTest(Font* f) {  // 真的画一个字，看有没有像素（个别系统上私有字体建得出来却画不出字）
  if (!f || f->GetLastStatus() != Ok) return false;
  Bitmap b(48, 32, PixelFormat32bppPARGB);
  { Graphics g(&b); g.Clear(Color(0, 0, 0, 0)); g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit); SolidBrush br(Color(255, 0, 0, 0)); g.DrawString(L"A", 1, f, PointF(2, 2), &br); }
  BitmapData bd; Rect r(0, 0, 48, 32); int n = 0;
  if (b.LockBits(&r, ImageLockModeRead, PixelFormat32bppPARGB, &bd) == Ok) {
    for (int y = 0; y < 32; y++) { const unsigned* row = (const unsigned*)((const BYTE*)bd.Scan0 + y * bd.Stride); for (int x = 0; x < 48; x++) if (row[x] >> 24) n++; }
    b.UnlockBits(&bd);
  }
  return n >= 12;
}
static std::wstring FirstFamily(PrivateFontCollection* c) {
  int n = c->GetFamilyCount(); if (n <= 0) return L"";
  FontFamily ff[8]; int got = 0; c->GetFamilies(n > 8 ? 8 : n, ff, &got);
  WCHAR nm[LF_FACESIZE] = {0}; if (got > 0) ff[0].GetFamilyName(nm, 0); return nm;
}
// 字体文件完整：表目录里的每张表都在文件范围之内（字体集逐款检查）。解压、下载到一半的文件不交给任何字体引擎——
// 不靠 GDI+ 恰好先拒绝它（精绘直接按表偏移读文件，截断的文件会读到文件外面）。以允许别人同时写的方式打开、读完就关，不妨碍写文件的一方
static bool SfntComplete(const std::wstring& path) {
  HANDLE f = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING, 0, nullptr);
  if (f == INVALID_HANDLE_VALUE) return false;
  LARGE_INTEGER sz = {}; GetFileSizeEx(f, &sz); const unsigned long long n = (unsigned long long)sz.QuadPart;
  auto rd = [&](unsigned long long off, void* p, DWORD len) { if (off + len > n) return false; OVERLAPPED o = {}; o.Offset = (DWORD)off; o.OffsetHigh = (DWORD)(off >> 32); DWORD got = 0; return ReadFile(f, p, len, &got, &o) && got == len; };
  auto be32 = [](const unsigned char* p) { return ((unsigned)p[0] << 24) | ((unsigned)p[1] << 16) | ((unsigned)p[2] << 8) | p[3]; };
  std::vector<unsigned long long> faces; unsigned char hd[12]; bool ok = false;
  if (rd(0, hd, 12)) {
    if (be32(hd) == 0x74746366) { unsigned cnt = be32(hd + 8); std::vector<unsigned char> o(cnt * 4u); if (cnt > 0 && cnt <= 64 && rd(12, o.data(), cnt * 4u)) for (unsigned i = 0; i < cnt; i++) faces.push_back(be32(&o[i * 4])); }  // ttcf
    else faces.push_back(0);
    ok = !faces.empty();
    for (auto base : faces) {
      unsigned char d[12]; if (!rd(base, d, 12)) { ok = false; break; }
      unsigned v = be32(d), nt = ((unsigned)d[4] << 8) | d[5];
      if ((v != 0x00010000 && v != 0x4F54544F && v != 0x74727565) || nt == 0 || nt > 128) { ok = false; break; }  // TrueType、OpenType（CFF）、旧 Mac TrueType
      std::vector<unsigned char> dir(nt * 16u); if (!rd(base + 12, dir.data(), nt * 16u)) { ok = false; break; }
      for (unsigned i = 0; i < nt; i++) { unsigned long long off = be32(&dir[i * 16 + 8]), len = be32(&dir[i * 16 + 12]); if (off < 12 || off + len > n) { ok = false; break; } }
      if (!ok) break;
    }
  }
  CloseHandle(f); return ok;
}
void Fonts::pollCustom() {  // 上次宿主字体文件还不完整：隔 2 秒以上再看一次，写完了就用上（宿主不必再交代一次）
  if (cusPending && GetTickCount() - cusTry >= 2000) { dropCustom(); cusTried = false; }
}
void Fonts::dropBadCustom() {  // 自绘发现宿主字体里有可见的字取不到轮廓（字形数据坏了）：这份字体 GDI+ 也画不出，本次改用系统字体（宿主换了文件会重新载入）。只在排版开始前调用
  if (cusOk && DnFinePkgBad()) dropCustom();
}
void Fonts::loadCustom() {
  cusTried = true; cusPending = false;
  if (cusReg.empty() && cusBold.empty()) return;
  std::wstring r = cusReg.empty() ? cusBold : cusReg, b = cusBold.empty() ? cusReg : cusBold;
  if (!SfntComplete(r) || (b != r && !SfntComplete(b))) { cusPending = true; cusTry = GetTickCount(); return; }  // 文件还没写完：先用系统字体
  colR = new PrivateFontCollection();
  if (colR->AddFontFile(r.c_str()) != Ok) { dropCustom(); return; }
  famR = FirstFamily(colR);
  if (b == r) famB = famR;
  else { colB = new PrivateFontCollection(); if (colB->AddFontFile(b.c_str()) != Ok) { delete colB; colB = nullptr; b = r; famB = famR; } else famB = FirstFamily(colB); }
  if (famR.empty() || famB.empty()) { dropCustom(); return; }
  DnFineRegisterFile(famR, false, r); DnFineRegisterFile(famB, true, b); if (famB != famR) DnFineRegisterFile(famB, false, b);
  if (AddFontResourceExW(r.c_str(), FR_PRIVATE, nullptr)) added.push_back(r);  // GDI 查字是否齐全要看得到它：只给本进程
  if (b != r && AddFontResourceExW(b.c_str(), FR_PRIVATE, nullptr)) added.push_back(b);
  cusOk = selfTest(get(famR, 16, FontStyleRegular, colR));
  if (!cusOk) dropCustom();
}
Font* Fonts::custom(float px, bool bold) {
  if (!cusTried) loadCustom();
  if (!cusOk) return nullptr;
  FontCollection* cb = colB ? colB : colR;
  Font* f = bold ? get(famB, px, FontStyleBold, cb) : get(famR, px, FontStyleRegular, colR);
  if (!f && bold) f = get(famB, px, FontStyleRegular, cb);
  if (!f) f = get(famR, px, bold ? FontStyleBold : FontStyleRegular, colR);
  return f;
}
Font* Fonts::ui(float px, bool bold) {
  for (auto& fam : uiList()) if (FamilyInstalled(fam)) { Font* f = get(fam, px, bold ? FontStyleBold : FontStyleRegular); if (f) { uiFam = fam; return f; } }
  uiFam = L"Tahoma"; Font* f = get(L"Tahoma", px, bold ? FontStyleBold : FontStyleRegular); return f ? f : get(L"Arial", px, FontStyleRegular);
}
bool Fonts::has(const std::wstring& fam, wchar_t ch) {
  if (ch < 32 || ch == L' ' || ch == 0x3000 || ch == 0x200B || (ch >= 0xD800 && ch <= 0xDFFF)) return true;  // 空白、控制符、代理对不查（代理对跟着前后的字体走）
  Cov* c = nullptr; for (auto* x : cov) if (x->fam == fam) { c = x; break; }
  if (!c) {
    if (cov.size() >= 48) dropCov();  // 上限：常用的字体就那么几十个，超过时整体重来，不会无限增长
    c = new Cov(); c->fam = fam; c->dc = CreateCompatibleDC(nullptr);
    c->hf = CreateFontW(-16, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, 0, 0, fam.c_str()); c->old = SelectObject(c->dc, c->hf);
    WCHAR face[LF_FACESIZE] = {0}; GetTextFaceW(c->dc, LF_FACESIZE, face);
    c->bad = _wcsicmp(face, fam.c_str()) != 0 && !FamilyInstalled(fam) && fam != famR && fam != famB;  // 没装这个字体（系统换成了别的）
    if (c->bad) { SelectObject(c->dc, c->old); DeleteDC(c->dc); DeleteObject(c->hf); c->dc = nullptr; c->hf = nullptr; }  // 没装的只记一个标记，不占 DC 与字体
    cov.push_back(c);
  }
  if (c->bad) return false;
  std::vector<unsigned char>& pg = c->pg[ch >> 8]; if (pg.empty()) pg.assign(256, 0);
  unsigned char& v = pg[ch & 255];
  if (!v) { WORD gi = 0; GetGlyphIndicesW(c->dc, &ch, 1, &gi, GGI_MARK_NONEXISTING_GLYPHS); v = gi == 0xFFFF ? 2 : 1; }
  return v == 1;
}
bool Fonts::covers(const std::wstring& fam, const std::wstring& text, int* missing) {
  int miss = 0; for (wchar_t ch : text) if (!has(fam, ch)) miss++;
  if (missing) *missing = miss; return miss == 0;
}
static int CALLBACK EnumFam(const LOGFONTW* lf, const TEXTMETRICW*, DWORD, LPARAM p) {
  auto* v = (std::vector<std::wstring>*)p; if (lf->lfFaceName[0] && lf->lfFaceName[0] != L'@') { std::wstring n = lf->lfFaceName; for (auto& e : *v) if (e == n) return 1; v->push_back(n); } return 1;
}
Font* Fonts::fallback(wchar_t ch, float px, bool bold, const std::wstring& skip) {
  std::wstring fam; bool found = false;
  for (auto& e : fbCache) if (e.first == ch) { fam = e.second; found = true; break; }
  if (!found) {
    std::vector<std::wstring> cand; if (cusOk) { cand.push_back(famR); if (famB != famR) cand.push_back(famB); }
    for (auto& f : uiList()) cand.push_back(f);
    const wchar_t* more[] = {L"Microsoft YaHei UI", L"Microsoft JhengHei UI", L"Yu Gothic UI", L"Malgun Gothic", L"Segoe UI", L"Segoe UI Symbol", L"Segoe UI Emoji",
                             L"Leelawadee UI", L"Nirmala UI", L"Ebrima", L"Gadugi", L"Microsoft Himalaya", L"Mongolian Baiti", L"Tahoma", L"Arial", L"SimSun"};
    for (auto m : more) cand.push_back(m);
    for (auto& f : cand) if (f != skip && has(f, ch)) { fam = f; break; }
    if (fam.empty() && scanMs < 400 && std::find(deadBlocks.begin(), deadBlocks.end(), ch >> 7) == deadBlocks.end()) {  // 全部字体扫描累计最多 400 毫秒：最坏情况也不会长时间卡住界面线程
      // 最后一招：系统里装的全部字体。用一个临时 DC 逐个试，不给每个字体都建缓存（几百个字体时不至于占几十 MB、上千个 GDI 句柄）；
      // 整段都找不到的区块（如私用区）记下来，同一区块后面的字不再逐个扫
      if (!allTried) { allTried = true; HDC dc = CreateCompatibleDC(nullptr); LOGFONTW lf = {}; lf.lfCharSet = DEFAULT_CHARSET; EnumFontFamiliesExW(dc, &lf, EnumFam, (LPARAM)&allFams, 0); DeleteDC(dc); }
      HDC dc = CreateCompatibleDC(nullptr); DWORD t0 = GetTickCount();
      for (auto& f : allFams) {
        if (f == skip) continue;
        if (scanMs + (GetTickCount() - t0) >= 400) break;
        HFONT hf = CreateFontW(-16, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, 0, 0, f.c_str()); HGDIOBJ o = SelectObject(dc, hf);
        WCHAR face[LF_FACESIZE] = {0}; GetTextFaceW(dc, LF_FACESIZE, face); WORD gi = 0xFFFF; wchar_t c1 = ch;
        if (_wcsicmp(face, f.c_str()) == 0) GetGlyphIndicesW(dc, &c1, 1, &gi, GGI_MARK_NONEXISTING_GLYPHS);
        SelectObject(dc, o); DeleteObject(hf);
        if (gi != 0xFFFF) { fam = f; break; }
      }
      DeleteDC(dc); scanMs += GetTickCount() - t0;
      if (fam.empty()) deadBlocks.push_back(ch >> 7);
    }
    if (fbCache.size() > 512) fbCache.erase(fbCache.begin());
    fbCache.push_back({ch, fam});
  }
  if (fam.empty()) return nullptr;
  FontCollection* col = (cusOk && (fam == famR || fam == famB)) ? ((fam == famB && colB) ? colB : colR) : nullptr;
  Font* f = get(fam, px, bold ? FontStyleBold : FontStyleRegular, col);
  if (!f && bold) f = get(fam, px, FontStyleRegular, col);
  return f;
}
void Fonts::runs(const std::wstring& t, Font* primary, std::vector<Run>& out) {
  out.clear(); std::wstring pf; int st = 0;
  if (t.empty()) return;
  if (!primary || !DnFontInfo(primary, pf, st)) { out.push_back({0, (int)t.size(), primary}); return; }
  bool bold = (st & FontStyleBold) != 0; float px = primary->GetSize(); Font* cur = nullptr; int a = 0;
  for (int i = 0; i < (int)t.size(); i++) {
    wchar_t ch = t[i]; Font* f = cur ? cur : primary;
    bool neutral = ch < 32 || ch == L' ' || ch == 0x3000 || (ch >= 0xD800 && ch <= 0xDFFF) || IsClusterTail(ch);  // 空白、代理对、组合记号与元音记号跟着前面的字（与断行、省略号同一条规则：不把一个字符簇拆到两种字体里）
    if (!neutral) { if (has(pf, ch)) f = primary; else { Font* fb = fallback(ch, px, bold, pf); f = fb ? fb : primary; } }
    if (!cur) cur = f;
    else if (f != cur) { out.push_back({a, i, cur}); a = i; cur = f; }
  }
  out.push_back({a, (int)t.size(), cur ? cur : primary});
}
int Fonts::missing(const std::wstring& t, Font* primary) {
  std::vector<Run> rs; runs(t, primary, rs); int n = 0;
  for (auto& r : rs) { std::wstring fam; int st; if (!r.f || !DnFontInfo(r.f, fam, st)) { n += r.b - r.a; continue; } for (int i = r.a; i < r.b; i++) if (!has(fam, t[i])) n++; }
  return n;
}
Font* Fonts::pick(const std::wstring& text, float px, bool bold) {
  // 选“缺字最少”的字体：宿主给的字体（如品牌字体）优先，其次本语种的系统界面字体，再其次常见的系统字体；都不缺字时用排在前面的。
  // 原来要求“全部字符都能显示”才用宿主字体，否则退回系统字体栈——标题里夹几个它没有的字时，反而换成了缺字更多的字体
  pollCustom();  // 放在查缓存之前：同一段文字再排版时也会再看一次宿主字体是否就绪（就绪时连缓存一起重来）
  for (auto& n : picked) if (n.bold == bold && fabsf(n.px - px) < 0.01f && n.text == text) return n.f;
  Font* r = nullptr; int best = 1 << 30; std::wstring bestFam;
  Font* cf = custom(px, bold);
  if (cf) { int miss = 0; covers(bold ? famB : famR, text, &miss); r = cf; best = miss; }
  if (best > 0) {
    Font* first = ui(px, bold); int miss = 0; covers(uiFam, text, &miss);
    if (miss < best) { r = first; best = miss; bestFam.clear(); }
    if (best > 0) {
      const wchar_t* more[] = {L"Microsoft YaHei UI", L"Microsoft YaHei", L"Microsoft JhengHei UI", L"Malgun Gothic", L"Yu Gothic UI", L"Meiryo UI",
                               L"Segoe UI", L"Leelawadee UI", L"Tahoma", L"Nirmala UI", L"Mangal", L"Segoe UI Symbol", L"Arial"};
      std::vector<std::wstring> cand = uiList(); for (auto m : more) cand.push_back(m);
      for (auto& f : cand) { int ms = 0; covers(f, text, &ms); if (ms < best) { best = ms; bestFam = f; if (!ms) break; } }
      if (!bestFam.empty()) { Font* g = get(bestFam, px, bold ? FontStyleBold : FontStyleRegular); if (g) r = g; }
    }
  }
  if (!r) r = ui(px, bold);
  if (picked.size() > 64) picked.clear();
  picked.push_back({text, px, bold, r});
  return r;
}

// ---------------- 量与画 ----------------
bool StrongRtl(const std::wstring& t) {
  if (t.empty()) return false;
  std::vector<WORD> ty(t.size());
  if (!GetStringTypeW(CT_CTYPE2, t.c_str(), (int)t.size(), ty.data())) return false;
  for (WORD v : ty) { if (v == C2_LEFTTORIGHT) return false; if (v == C2_RIGHTTOLEFT) return true; }
  return false;
}
// ---------------- 文字的最后一道退路：GDI ----------------
// 个别系统上精绘文字、GDI+ 都画不出字（卡片只剩图标与底色）时改用 GDI：GDI 按系统的字体链接自己换字体，兼容面最广。
// 先画成黑底白字的灰度图，再把亮度当覆盖率、换成文字颜色贴到画布上。下面 Text() 里调用时画布已换到设备坐标（不再有变换）
static int g_dnGdipVerdict = -1;       // GDI+ 画字自检：-1 还没试 1 正常 0 画不出字（之后一律走 GDI）
static volatile LONG g_dnGdiUsed = 0;  // 诊断：用 GDI 画过字
bool g_dnTestNoText = false;           // 测试（DN_Set 105）：不画文字（有字图 − 无字图 ＝ 笔画像素）
struct DnGdiFontC { std::wstring fam; int px, style; HFONT hf; };
static std::vector<DnGdiFontC> g_dnGdiFonts;
static HFONT DnGdiFont(const std::wstring& fam, int px, int style) {
  for (auto& f : g_dnGdiFonts) if (f.px == px && f.style == style && f.fam == fam) return f.hf;
  if (g_dnGdiFonts.size() > 24) { for (auto& f : g_dnGdiFonts) DeleteObject(f.hf); g_dnGdiFonts.clear(); }
  HFONT hf = CreateFontW(-px, 0, 0, 0, (style & FontStyleBold) ? FW_BOLD : FW_NORMAL, (style & FontStyleItalic) ? 1 : 0, 0, 0, DEFAULT_CHARSET,
                         OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, DEFAULT_PITCH, fam.c_str());
  g_dnGdiFonts.push_back({fam, px, style, hf});
  return hf;
}
static bool DnGdipWorks(Font* f) {
  if (g_dnGdipVerdict >= 0) return g_dnGdipVerdict == 1;
  int n = 0;
  if (!(g_dnTestTextFail & 2)) {
    Bitmap b(96, 48, PixelFormat32bppPARGB);
    { Graphics g(&b); g.Clear(Color(0, 0, 0, 0)); g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit); SolidBrush br(Color(255, 0, 0, 0)); g.DrawString(L"Ag", 2, f, PointF(2, 2), &br); }
    BitmapData bd; Rect r(0, 0, 96, 48);
    if (b.LockBits(&r, ImageLockModeRead, PixelFormat32bppPARGB, &bd) == Ok) {
      for (int y = 0; y < 48; y++) { const unsigned* row = (const unsigned*)((const BYTE*)bd.Scan0 + y * bd.Stride); for (int x = 0; x < 96; x++) if (row[x] >> 24) n++; }
      b.UnlockBits(&bd);
    }
  }
  g_dnGdipVerdict = n >= 6 ? 1 : 0;
  return g_dnGdipVerdict == 1;
}
static bool DnGdiMeasure(Font* f, const std::wstring& t, float* w) {
  std::wstring fam; int st; if (!f || !DnFontInfo(f, fam, st)) return false;
  int px = (int)lroundf(f->GetSize()); if (px < 1) px = 1;
  HDC dc = CreateCompatibleDC(nullptr); HGDIOBJ o = SelectObject(dc, DnGdiFont(fam, px, st));
  SIZE sz = {0, 0}; BOOL ok = GetTextExtentPoint32W(dc, t.c_str(), (int)t.size(), &sz);
  SelectObject(dc, o); DeleteDC(dc);
  if (!ok) return false;
  *w = (float)sz.cx; return true;
}
// 在设备坐标的框里画一行：devAlign 0 靠左 1 居中 2 靠右；rtl＝从右往左的段落（双向排序、连写交给 GDI）。false＝没画（调用方照旧用 GDI+）
static bool DnGdiDraw(Ctx& c, const std::wstring& t, Font* f, const Color& col, float x, float y, float w, float h, int devAlign, bool rtl) {
  std::wstring fam; int st; if (!f || !DnFontInfo(f, fam, st)) return false;
  int px = (int)lroundf(f->GetSize()); if (px < 1) return false;
  int ox = (int)floorf(x) - 2, oy = (int)floorf(y), bw = (int)ceilf(w) + 6, bh = (int)ceilf(h) + 1;
  if (bw <= 0 || bh <= 0 || bw > 4096 || bh > 1024) return false;
  BITMAPINFO bi = {}; bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = bw; bi.bmiHeader.biHeight = -bh; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
  void* bits = nullptr; HDC dc = CreateCompatibleDC(nullptr); HBITMAP hb = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
  if (!hb || !bits) { if (hb) DeleteObject(hb); DeleteDC(dc); return false; }
  HGDIOBJ ob = SelectObject(dc, hb); memset(bits, 0, (size_t)bw * bh * 4);
  HGDIOBJ of = SelectObject(dc, DnGdiFont(fam, px, st));
  SetBkMode(dc, TRANSPARENT); SetTextColor(dc, RGB(255, 255, 255));
  UINT fmt = DT_SINGLELINE | DT_VCENTER | DT_NOPREFIX | DT_NOCLIP | (rtl ? DT_RTLREADING : 0) | (devAlign == 1 ? DT_CENTER : devAlign == 2 ? DT_RIGHT : DT_LEFT);
  RECT rc = {(LONG)lroundf(x - ox), 0, (LONG)lroundf(x - ox + w), bh};
  DrawTextW(dc, t.c_str(), (int)t.size(), &rc, fmt);
  GdiFlush();
  Bitmap bmp(bw, bh, PixelFormat32bppPARGB); bool ok = false;
  { BitmapData bd; Rect r(0, 0, bw, bh);
    if (bmp.LockBits(&r, ImageLockModeWrite, PixelFormat32bppPARGB, &bd) == Ok) {
      const unsigned* s = (const unsigned*)bits; unsigned ca = col.GetA(), cr = col.GetR(), cg = col.GetG(), cb = col.GetB();
      for (int yy = 0; yy < bh; yy++) {
        unsigned* d = (unsigned*)((BYTE*)bd.Scan0 + yy * bd.Stride);
        for (int xx = 0; xx < bw; xx++) {
          unsigned v = s[(size_t)yy * bw + xx], cov = (v >> 16) & 255, g1 = (v >> 8) & 255, b1 = v & 255;
          if (g1 > cov) cov = g1; if (b1 > cov) cov = b1;
          unsigned a2 = cov * ca / 255;
          d[xx] = a2 ? ((a2 << 24) | ((cr * a2 / 255) << 16) | ((cg * a2 / 255) << 8) | (cb * a2 / 255)) : 0;
        }
      }
      bmp.UnlockBits(&bd); ok = true;
    } }
  SelectObject(dc, of); SelectObject(dc, ob); DeleteObject(hb); DeleteDC(dc);
  if (!ok) return false;
  GraphicsState gs = c.g->Save();
  c.g->SetInterpolationMode(InterpolationModeNearestNeighbor); c.g->SetPixelOffsetMode(PixelOffsetModeHalf);
  c.g->DrawImage(&bmp, Rect(ox, oy, bw, bh), 0, 0, bw, bh, UnitPixel);
  c.g->Restore(gs);
  InterlockedExchange(&g_dnGdiUsed, 1);
  return true;
}
int DnTextPathInfo() { return (DnFineBroken() ? 1 : 0) | (g_dnGdipVerdict == 0 ? 2 : 0) | (g_dnGdiUsed ? 4 : 0); }
void DnTextTestFail(int bits) { DnFineTestFail(bits); g_dnGdipVerdict = -1; InterlockedExchange(&g_dnGdiUsed, 0); }

static float TextW1(Ctx& c, const std::wstring& t, Font* f, bool gdi) {  // 一种字体量一段：从左往右的段落能精绘的用精绘的字宽，从右往左的段落用 GDI+（与画的时候同一套）
  if (t.empty() || !f) return 0;
  { float fw; if (!gdi && DnFineMeasure(f, t, &fw)) return fw; }
  if (!DnGdipWorks(f)) { float gw; if (DnGdiMeasure(f, t, &gw)) return gw; }  // GDI+ 画不出字时走 GDI：量也用 GDI，截断、对齐与画出来的一致
  StringFormat sf(StringFormat::GenericTypographic()); sf.SetFormatFlags(StringFormatFlagsNoWrap | StringFormatFlagsMeasureTrailingSpaces | (gdi ? StringFormatFlagsDirectionRightToLeft : 0));
  RectF r; c.g->MeasureString(t.c_str(), (INT)t.size(), f, PointF(0, 0), &sf, &r); return r.Width;
}
float TextW(Ctx& c, const std::wstring& t, Font* f) {
  if (t.empty() || !f) return 0;
  if (StrongRtl(t) || !c.fonts) return TextW1(c, t, f, StrongRtl(t));
  std::vector<Fonts::Run> rs; c.fonts->runs(t, f, rs);
  if (rs.size() <= 1) return TextW1(c, t, rs.empty() ? f : rs[0].f, false);
  float w = 0; for (auto& r : rs) w += TextW1(c, t.substr(r.a, r.b - r.a), r.f, false); return w;
}
bool IsClusterTail(wchar_t ch) {  // 不能在它前面切开的字：不占位记号、附加符号、元音记号（不靠 Uniscribe：有的实现对泰文不给字符簇边界）、代理对的后半
  if (ch >= 0xDC00 && ch <= 0xDFFF) return true;
  if (ch < 0x0300) return false;
  WORD t = 0; GetStringTypeW(CT_CTYPE3, &ch, 1, &t);
  return (t & (C3_NONSPACING | C3_DIACRITIC | C3_VOWELMARK)) != 0;
}
std::vector<char> CharStops(const std::wstring& s) {  // 字符簇边界：st[i] 为 1 表示可以在第 i 个字之前切开（0 与末尾总可以）。Uniscribe 的 fCharStop 再叠加 IsClusterTail（与断行的硬断同一条规则）
  int n = (int)s.size(); std::vector<char> st(n + 1, 1); if (n < 2) return st;
  for (int i = 1; i < n; i++) if (s[i] >= 0xDC00 && s[i] <= 0xDFFF && s[i - 1] >= 0xD800 && s[i - 1] <= 0xDBFF) st[i] = 0;
  std::vector<SCRIPT_ITEM> it(n + 2); int ni = 0;
  if (FAILED(ScriptItemize(s.c_str(), n, n + 1, nullptr, nullptr, it.data(), &ni))) return st;
  std::vector<SCRIPT_LOGATTR> la(n);
  for (int i = 0; i < ni; i++) { int a = it[i].iCharPos, b = it[i + 1].iCharPos; if (b > a && FAILED(ScriptBreak(s.c_str() + a, b - a, &it[i].a, la.data() + a))) return st; }
  for (int i = 1; i < n; i++) if (!la[i].fCharStop || IsClusterTail(s[i])) st[i] = 0;
  return st;
}
static std::wstring Ellipsize(Ctx& c, const std::wstring& t, Font* f, float w) {  // 自己算省略号：各系统一致，从右往左的文字也按逻辑顺序从尾部截；只在字符簇边界上切
  if (TextW(c, t, f) <= w + 0.5f) return t;
  const std::wstring ell = L"\x2026"; size_t lo = 0, hi = t.size(); std::vector<char> st = CharStops(t);
  auto cutAt = [&](size_t n) {  // 往前退到字符簇边界：不把组合符号、泰文元音与声调、天城文半音符连写、代理对从中间切开
    while (n > 0 && n < t.size() && !st[n]) n--;
    std::wstring s = t.substr(0, n); while (!s.empty() && (s.back() == L' ' || s.back() == 0x3000 || s.back() == L',' || s.back() == 0xFF0C || s.back() == 0x3001)) s.pop_back(); return s; };
  while (lo < hi) { size_t mid = (lo + hi + 1) / 2; if (TextW(c, cutAt(mid) + ell, f) <= w + 0.5f) lo = mid; else hi = mid - 1; }
  std::wstring s = cutAt(lo); return s.empty() ? ell : s + ell;
}
std::wstring DnEllipsize(Ctx& c, const std::wstring& t, Font* f, float w) { return Ellipsize(c, t, f, w); }  // 测试用
void Text(Ctx& c, const std::wstring& t0, Font* f, const Color& col, float x, float y, float w, float h, int align, bool ell) {
  if (!c.draw || t0.empty() || !f || w <= 0 || g_dnTestNoText) return;
  std::wstring t = ell ? Ellipsize(c, t0, f, w) : t0;
  // 版面方向跟界面语言（从右往左的语言整张画布镜像），段落方向跟内容（第一个强方向字符）：阿拉伯语界面里显示没有译文的中文原文时，
  // 文字仍从左往右排（句末标点不会跑到行首），只是靠版面的起始边（右边）对齐。都换算到设备坐标再画（文字本身不能镜像）
  Matrix m; c.g->GetTransform(&m); REAL e[6]; m.GetElements(e); bool mirrored = e[0] * e[3] - e[1] * e[2] < 0;
  PointF p[2] = {PointF(x, y), PointF(x + w, y + h)}; m.TransformPoints(p, 2);
  float dx0 = p[0].X < p[1].X ? p[0].X : p[1].X, dx1 = p[0].X < p[1].X ? p[1].X : p[0].X, dy0 = p[0].Y < p[1].Y ? p[0].Y : p[1].Y, dh = fabsf(p[1].Y - p[0].Y);
  int devAlign = align == 1 ? 1 : ((align == 0) != mirrored ? 0 : 2);  // 设备坐标里：0 靠左 1 居中 2 靠右
  SolidBrush b(col); GraphicsState st = c.g->Save(); c.g->ResetTransform();
  if (StrongRtl(t)) {  // 从右往左的段落：GDI+（双向排序、连写）。带从右往左标志时 Near 在右、Far 在左
    StringFormat sf(StringFormat::GenericTypographic());
    sf.SetFormatFlags(StringFormatFlagsNoWrap | StringFormatFlagsMeasureTrailingSpaces | StringFormatFlagsDirectionRightToLeft);
    sf.SetTrimming(StringTrimmingEllipsisCharacter);  // 文字已按宽度截好；保留这个设置是因为部分实现只在裁剪模式下才做阿拉伯文连写与从右到左排序
    sf.SetAlignment(devAlign == 1 ? StringAlignmentCenter : devAlign == 2 ? StringAlignmentNear : StringAlignmentFar); sf.SetLineAlignment(StringAlignmentCenter);
    if (!(!DnGdipWorks(f) && DnGdiDraw(c, t, f, col, dx0 - 2.f, dy0, dx1 - dx0 + 2.f, dh, devAlign, true)))
      c.g->DrawString(t.c_str(), (INT)t.size(), f, RectF(dx0 - 2.f, dy0, dx1 - dx0 + 2.f, dh), &sf, &b);
  } else {  // 从左往右的段落：按段换字体（主字体没有的字换成有的字体），能精绘的精绘
    std::vector<Fonts::Run> rs; if (c.fonts) c.fonts->runs(t, f, rs); if (rs.empty()) rs.push_back({0, (int)t.size(), f});
    std::vector<float> ws; float tw = 0; for (auto& r : rs) { ws.push_back(TextW1(c, t.substr(r.a, r.b - r.a), r.f, false)); tw += ws.back(); }
    float cx = devAlign == 1 ? dx0 + (dx1 - dx0 - tw) / 2 : devAlign == 2 ? dx1 - tw : dx0;
    StringFormat sf(StringFormat::GenericTypographic()); sf.SetFormatFlags(StringFormatFlagsNoWrap | StringFormatFlagsMeasureTrailingSpaces);
    sf.SetAlignment(StringAlignmentNear); sf.SetLineAlignment(StringAlignmentCenter);
    for (size_t i = 0; i < rs.size(); i++) {
      std::wstring sg = t.substr(rs[i].a, rs[i].b - rs[i].a);
      if (!DnFineDraw(c, sg, rs[i].f, col, cx, dy0, ws[i], dh, 0) && !(!DnGdipWorks(rs[i].f) && DnGdiDraw(c, sg, rs[i].f, col, cx, dy0, ws[i], dh, 0, false)))
        c.g->DrawString(sg.c_str(), (INT)sg.size(), rs[i].f, RectF(cx, dy0, ws[i] + 2.f, dh), &sf, &b);
      cx += ws[i];
    }
  }
  c.g->Restore(st);
}

// ---------------- 断行 ----------------
std::vector<Span> Wrap(Ctx& c, const std::wstring& s, Font* f, const std::function<float(int)>& wOf, int maxLines, bool* overflow) {
  int n = (int)s.size(); std::vector<Span> lines; if (overflow) *overflow = false; if (!n) return lines;
  std::vector<SCRIPT_LOGATTR> la(n + 1); std::vector<SCRIPT_ITEM> it(n + 2); int ni = 0;
  bool okBreak = ScriptItemize(s.c_str(), n, (int)it.size() - 1, nullptr, nullptr, it.data(), &ni) == S_OK;
  for (int i = 0; okBreak && i < ni; i++) ScriptBreak(s.c_str() + it[i].iCharPos, it[i + 1].iCharPos - it[i].iCharPos, &it[i].a, &la[it[i].iCharPos]);
  if (!okBreak) for (int i = 0; i < n; i++) { la[i].fCharStop = 1; la[i].fSoftBreak = 1; la[i].fWhiteSpace = s[i] == L' '; }
  std::vector<char> brk(n + 1, 0); brk[n] = 1;
  for (int i = 1; i < n; i++) brk[i] = ((la[i].fSoftBreak && !la[i].fWhiteSpace) || (la[i - 1].fWhiteSpace && !la[i].fWhiteSpace)) ? 1 : 0;
  const wchar_t *op = L"「『“《（", *cl = L"」』”》）";  // 短引号词、短括注（10 个字以内）中间不断
  for (int i = 0; i < n; i++) { const wchar_t* o = s[i] ? wcschr(op, s[i]) : nullptr; if (!o) continue; for (int j = i + 1; j < n && j <= i + 11; j++) if (s[j] == cl[o - op]) { for (int q = i + 1; q <= j; q++) brk[q] = 0; break; } }
  auto cstop = [&](int b) { return b >= n || (la[b].fCharStop && !IsClusterTail(s[b])); };  // 字符簇边界（不在组合符、元音符号前面，不拆代理对；与省略号同一条规则）
  auto segW = [&](int a, int b) { int e = b; while (e > a && (s[e - 1] == L' ' || s[e - 1] == 0x3000)) e--; return TextW(c, s.substr(a, e - a), f); };
  int pos = 0;
  while (pos < n) {
    while (pos < n && la[pos].fWhiteSpace) pos++;
    if (pos >= n) break;
    float w = wOf((int)lines.size()); int best = -1;
    for (int b = pos + 1; b <= n; b++) { if (!brk[b]) continue; if (segW(pos, b) <= w + 0.5f) best = b; else break; }
    if (best < 0) {  // 一个词都放不下：在字符簇边界上硬断
      int e = pos + 1; while (e < n && !cstop(e)) e++; best = e;
      for (int b = e + 1; b <= n; b++) { if (!cstop(b)) continue; if (segW(pos, b) <= w + 0.5f) best = b; else break; }
    }
    int e = best; while (e > pos && (s[e - 1] == L' ' || s[e - 1] == 0x3000)) e--;
    lines.push_back({pos, e}); pos = best;
    if (maxLines > 0 && (int)lines.size() >= maxLines) {  // 够行数了：后面还有字就报告放不下，不再往下断
      while (pos < n && la[pos].fWhiteSpace) pos++;
      if (pos < n && overflow) *overflow = true;
      break;
    }
  }
  return lines;
}
std::vector<Span> WrapBalanced(Ctx& c, const std::wstring& t, Font* f, float w0, float w1) {
  auto fn = [](float a, float b) { return std::function<float(int)>([=](int i) { return i == 0 ? a : b; }); };
  auto L = Wrap(c, t, f, fn(w0, w1));
  if (L.size() != 2) return L;
  float lo = w1 * 0.4f, hi = w1;
  for (int it = 0; it < 12; it++) { float mid = (lo + hi) / 2; if (Wrap(c, t, f, fn(mid < w0 ? mid : w0, mid)).size() <= 2) hi = mid; else lo = mid; }
  return Wrap(c, t, f, fn(hi < w0 ? hi : w0, hi));
}
namespace __gnu_cxx { void __verbose_terminate_handler() { abort(); } }
