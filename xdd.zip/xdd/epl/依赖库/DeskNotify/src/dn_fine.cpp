// 精绘文字（移植自 XhhFloat 1.1.0 的 xf_fine.cpp，算法与参数不变，只改了符号前缀与头文件）：与浏览器同一种画法——
//   1. 直接从字体文件取字形轮廓、字宽与字偶距（stb_truetype；文件只做内存映射不复制）——字体包里的鸿蒙黑体按路径，系统字体按注册表的字体表找文件；
//      不经过 GDI，所以 Windows 与测试环境取到的轮廓完全相同（曾试过 GDI 的 GetGlyphOutline：Wine 下轮廓比字号大约 5%，不可靠）；
//   2. 自己按面积算每个像素的覆盖率（stb_truetype 的光栅化），横向按 1/4 像素定位、基线对齐整像素（同 Chromium）；
//   3. 按 Skia 的灰度文字修正（伽马＋对比度，按文字颜色的亮度查表）调整覆盖率，再按透明度贴到画布上。
// 这样画出的字与设计稿的字形、粗细一致，而且不依赖 GDI+ / 系统的文字渲染，Windows 与测试环境结果相同。
// 只用于不需要字形变换的文字（中日韩、拉丁、西里尔等，且不在镜像画布上）；阿拉伯文、天城文、泰文、表情等仍走 GDI+。
#include "dn.h"
#define STB_TRUETYPE_IMPLEMENTATION
#define STBTT_assert(x) ((void)0)  // 不带 assert：它会把源码的完整路径编进 DLL，换目录编译就不再逐字节相同
#define STBTT_STATIC
#define stbtt_vertex_type int  // 轮廓坐标用 int（stb 默认 short）
typedef struct { int x, y, cx, cy, cx1, cy1; unsigned char type, padding; } stbtt_vertex;
#define stbtt_vertex stbtt_vertex
#include "stb_truetype.h"
#include <memory>
#include <map>

namespace {
struct FGlyph { bool loaded = false; int adv = 0; stbtt_vertex* v = nullptr; int nv = 0; int minx = 0, miny = 0, maxx = 0, maxy = 0; };
struct FBits { int x0 = 0, y0 = 0, w = 0, h = 0; std::vector<unsigned char> a; };
struct FFace {
  std::wstring fam; bool bold = false; bool ok = false;
  bool pkg = false;  // 字体包里的文件（不是按注册表找到的系统字体）
  int verdict = -1;  // 整条画法的自检（真画几个字、看画布上有没有像素）：-1 还没试 2 正在试 1 正常 0 画不出字（这款字改走 GDI+）
  HANDLE file = INVALID_HANDLE_VALUE, map = nullptr; const unsigned char* data = nullptr;
  stbtt_fontinfo info; int upm = 0; float asc = 0, desc = 0;  // hhea，设计单位；desc 为正
  std::map<int, FGlyph> glyphs;
  std::map<unsigned long long, FBits> bits;  // (字号×64, 字形, 横向 1/4 像素) → 覆盖率图
  ~FFace() { for (auto& g : glyphs) if (g.second.v) stbtt_FreeShape(&info, g.second.v); if (data) UnmapViewOfFile(data); if (map) CloseHandle(map); if (file != INVALID_HANDLE_VALUE) CloseHandle(file); }
};
std::vector<std::unique_ptr<FFace>> g_faces;
struct FReg { std::wstring fam; bool bold; std::wstring path; };
std::vector<FReg> g_regs;  // 字体包里的字体（鸿蒙黑体）：族名 → 文件
bool g_enabled = true;
volatile LONG g_fineBrokenSeen = 0;  // 诊断：有字体没通过整条画法自检（原子标记，任何线程都可读）
volatile LONG g_pkgBad = 0;  // 字体包（宿主给的字体文件）里有可见的字取不到轮廓：字形数据坏了（没写完、被改坏），这份字体 GDI+ 也画不出——让上层在下一帧换回系统字体
bool Blank(wchar_t ch) { return ch == L' ' || ch == L'\t' || ch == 0xA0 || ch == 0x1680 || (ch >= 0x2000 && ch <= 0x200A) || ch == 0x202F || ch == 0x205F || ch == 0x3000; }  // 本来就没有笔画的空白
bool FineDrawImpl(Ctx& c, const std::wstring& t, Font* font, const Color& col, float x, float y, float w, float h, int align);
bool FaceSelfTest(FFace* face, Font* font);
float g_gamma = 1.2f, g_contrast = 0.2f;  // 同 Chromium（Linux）的灰度文字参数

unsigned short BE16(const unsigned char* p) { return (unsigned short)((p[0] << 8) | p[1]); }
unsigned BE32(const unsigned char* p) { return ((unsigned)p[0] << 24) | ((unsigned)p[1] << 16) | ((unsigned)p[2] << 8) | p[3]; }
// 字体文件的表目录都在文件范围之内（字体集逐款查）：没下载完、被截断、被改坏的文件不交给字体引擎——引擎读表时不查边界，会读到映射之外（访问违例）
bool SfntInside(const unsigned char* d, unsigned long long n) {
  auto face = [&](unsigned long long b) {
    if (b + 12 > n) return false;
    unsigned v = BE32(d + b), nt = BE16(d + b + 4);
    if ((v != 0x00010000 && v != 0x4F54544F && v != 0x74727565) || nt == 0 || nt > 128) return false;  // TrueType、OpenType（CFF）、旧 Mac TrueType
    if (b + 12 + 16ull * nt > n) return false;
    for (unsigned i = 0; i < nt; i++) { const unsigned char* e = d + b + 12 + 16 * i; unsigned long long o = BE32(e + 8), l = BE32(e + 12); if (o + l > n) return false; }
    return true; };
  if (n < 12) return false;
  if (BE32(d) == 0x74746366) {  // 'ttcf'
    unsigned cnt = BE32(d + 8); if (cnt == 0 || cnt > 64 || 12 + 4ull * cnt > n) return false;
    for (unsigned i = 0; i < cnt; i++) if (!face(BE32(d + 12 + 4 * i))) return false;
    return true;
  }
  return face(0);
}
bool HasTable(const unsigned char* d, int off, const char* tag) {
  int n = BE16(d + off + 4);
  for (int i = 0; i < n; i++) if (!memcmp(d + off + 12 + 16 * i, tag, 4)) return true;
  return false;
}
std::string Utf8(const std::wstring& w) { int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, nullptr, 0, nullptr, nullptr); std::string s(n > 0 ? n - 1 : 0, 0); if (n > 1) WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, &s[0], n, nullptr, nullptr); return s; }
// 系统字体：从注册表的字体表找文件（HKLM 与本用户安装的 HKCU）
std::wstring SystemFontFile(const std::wstring& fam, bool bold) {
  std::wstring want = bold ? fam + L" Bold" : fam, want2 = bold ? fam + L" Bold" : fam + L" Regular";  // 注册表里有的写“… Regular”
  HKEY roots[2] = {HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER};
  for (HKEY root : roots) {
    HKEY k; if (RegOpenKeyExW(root, L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Fonts", 0, KEY_READ | (root == HKEY_LOCAL_MACHINE ? KEY_WOW64_64KEY : 0), &k) != ERROR_SUCCESS) continue;  // 32 位进程在 64 位系统上读本机（64 位）视图，不读 Wow6432Node 的副本
    std::wstring found;
    for (DWORD i = 0;; i++) {
      WCHAR name[512]; DWORD nl = 512; WCHAR val[MAX_PATH + 1]; DWORD vl = MAX_PATH * sizeof(WCHAR), ty = 0;
      LONG rc = RegEnumValueW(k, i, name, &nl, nullptr, &ty, (BYTE*)val, &vl);
      if (rc == ERROR_MORE_DATA) continue;  // 这一项的名字或路径超长：跳过它接着找后面的（原来一律结束，排在它后面的字体都找不到）
      if (rc != ERROR_SUCCESS) break;       // 没有更多项（或其它错误：不再往下试，免得每项都同样出错时一直转下去）
      if (ty != REG_SZ) continue;
      val[vl / sizeof(WCHAR)] = 0;  // 注册表里的字符串不保证以零结尾：自己补上（缓冲区多留了一个字）
      std::wstring n = name; size_t par = n.rfind(L" ("); if (par != std::wstring::npos) n.resize(par);
      size_t a = 0; bool hit = false;
      while (a <= n.size()) { size_t b = n.find(L" & ", a); std::wstring part = n.substr(a, b == std::wstring::npos ? std::wstring::npos : b - a); if (_wcsicmp(part.c_str(), want.c_str()) == 0 || _wcsicmp(part.c_str(), want2.c_str()) == 0) { hit = true; break; } if (b == std::wstring::npos) break; a = b + 3; }
      if (!hit) continue;
      found = val;
      if (found.find(L'\\') == std::wstring::npos) { WCHAR win[MAX_PATH]; GetWindowsDirectoryW(win, MAX_PATH); found = std::wstring(win) + L"\\Fonts\\" + found; }
      break;
    }
    RegCloseKey(k);
    if (!found.empty()) return found;
  }
  return L"";
}
FFace* Face(const std::wstring& fam, bool bold) {
  for (auto& f : g_faces) if (f->bold == bold && f->fam == fam) return f->ok ? f.get() : nullptr;
  auto f = std::make_unique<FFace>(); f->fam = fam; f->bold = bold;
  FFace* r = f.get(); g_faces.push_back(std::move(f));
  std::wstring path;
  for (auto& g : g_regs) if (g.bold == bold && g.fam == fam) path = g.path;
  bool fromPkg = !path.empty();
  r->pkg = fromPkg;
  if (!fromPkg) path = SystemFontFile(fam, bold);
  if (path.empty()) return nullptr;
  r->file = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING, 0, nullptr);
  if (r->file == INVALID_HANDLE_VALUE) return nullptr;
  r->map = CreateFileMappingW(r->file, nullptr, PAGE_READONLY, 0, 0, nullptr);
  if (!r->map) return nullptr;
  r->data = (const unsigned char*)MapViewOfFile(r->map, FILE_MAP_READ, 0, 0, 0);  // 只映射不复制：用到哪页读哪页
  if (!r->data) return nullptr;
  { LARGE_INTEGER sz = {}; if (!GetFileSizeEx(r->file, &sz) || !SfntInside(r->data, (unsigned long long)sz.QuadPart)) return nullptr; }  // 文件不完整：交给 GDI+
  int off = 0;
  if (!fromPkg) {  // 系统字体可能是字体集（.ttc）：按族名与粗细找那一款
    std::string u = Utf8(fam);
    off = stbtt_FindMatchingFont(r->data, u.c_str(), bold ? STBTT_MACSTYLE_BOLD : STBTT_MACSTYLE_NONE);
    if (off < 0) off = stbtt_FindMatchingFont(r->data, u.c_str(), STBTT_MACSTYLE_DONTCARE);
    if (off < 0) return nullptr;
  } else off = stbtt_GetFontOffsetForIndex(r->data, 0);
  if (off < 0 || HasTable(r->data, off, "fvar") || HasTable(r->data, off, "CFF2")) return nullptr;  // 可变字体不用（取不到选中的那一款）
  if (!stbtt_InitFont(&r->info, r->data, off)) return nullptr;
  { int a, d, g; stbtt_GetFontVMetrics(&r->info, &a, &d, &g); r->asc = (float)a; r->desc = (float)-d; }
  float s1 = stbtt_ScaleForMappingEmToPixels(&r->info, 1.f); if (s1 <= 0) return nullptr;
  r->upm = (int)lroundf(1.f / s1);
  if (r->upm < 16 || r->asc <= 0) return nullptr;
  { float em = (r->asc + r->desc) / r->upm; if (em < 0.6f || em > 3.0f) return nullptr; }  // 行高离谱（改过行距的“美化”字体等）：排版会跑出框，交给 GDI+
  { // 常用字里至少有一个取得到轮廓：只有点阵、轮廓表坏了、文件里该是字形的地方是空的，这里都取不到——不然量得出字宽却画不出字
    static const int probe[] = {0x6D4B, 'A', '0', 0x3042, 0xAC00, 0x0410, 0x0E01};
    bool seen = false, any = false;
    for (int ch : probe) { int gi = stbtt_FindGlyphIndex(&r->info, ch); if (!gi) continue; seen = true; stbtt_vertex* v = nullptr; int nv = stbtt_GetGlyphShape(&r->info, gi, &v); if (v) stbtt_FreeShape(&r->info, v); if (nv > 0) { any = true; break; } }
    if (seen && !any) { if (fromPkg) InterlockedExchange(&g_pkgBad, 1); return nullptr; }  // 1.2.1：字体包里的（宿主给的）这几个常用字全都取不到轮廓：字形数据坏了，也要让上层换回系统字体——原来只是这款不走精绘，宿主字体仍在用，GDI+ 照着坏字形画就没有字（只缺拉丁字母的中文字体最容易这样，见 dntest 的“宿主字体的字形坏了”）
  }
  r->ok = true;
  return r;
}
FGlyph& Glyph(FFace* f, int gi) {
  FGlyph& g = f->glyphs[gi];
  if (g.loaded) return g;
  g.loaded = true;
  int adv = 0, lsb = 0; stbtt_GetGlyphHMetrics(&f->info, gi, &adv, &lsb); g.adv = adv;
  g.nv = stbtt_GetGlyphShape(&f->info, gi, &g.v);
  int x0, y0, x1, y1;
  if (g.nv > 0 && stbtt_GetGlyphBox(&f->info, gi, &x0, &y0, &x1, &y1)) { g.minx = x0; g.miny = y0; g.maxx = x1; g.maxy = y1; }
  else if (g.nv > 0) {
    bool first = true;
    for (int i = 0; i < g.nv; i++) { const stbtt_vertex& v = g.v[i]; int xs[3] = {v.x, v.cx, v.cx1}, ys[3] = {v.y, v.cy, v.cy1}; int k = v.type == STBTT_vcubic ? 3 : v.type == STBTT_vcurve ? 2 : 1;
      for (int j = 0; j < k; j++) { if (first) { g.minx = g.maxx = xs[j]; g.miny = g.maxy = ys[j]; first = false; } if (xs[j] < g.minx) g.minx = xs[j]; if (xs[j] > g.maxx) g.maxx = xs[j]; if (ys[j] < g.miny) g.miny = ys[j]; if (ys[j] > g.maxy) g.maxy = ys[j]; } }
  }
  return g;
}
const FBits& Bits(FFace* f, int gi, float px, int sub) {
  unsigned long long key = ((unsigned long long)(unsigned)lroundf(px * 64) << 24) | ((unsigned long long)gi << 4) | (unsigned)sub;
  auto it = f->bits.find(key);
  if (it != f->bits.end()) return it->second;
  FBits& b = f->bits[key];
  FGlyph& g = Glyph(f, gi);
  if (g.nv <= 0) return b;
  float s = px / f->upm, sx = sub * 0.25f;
  int x0 = (int)floorf(g.minx * s + sx), x1 = (int)ceilf(g.maxx * s + sx), y0 = (int)floorf(-g.maxy * s), y1 = (int)ceilf(-g.miny * s);
  b.x0 = x0; b.y0 = y0; b.w = x1 - x0 + 1; b.h = y1 - y0 + 1;
  if (b.w <= 0 || b.h <= 0 || b.w > 2048 || b.h > 2048) { b.w = b.h = 0; return b; }
  b.a.assign((size_t)b.w * b.h, 0);
  stbtt__bitmap bm; bm.w = b.w; bm.h = b.h; bm.stride = b.w; bm.pixels = b.a.data();
  stbtt_Rasterize(&bm, 0.25f, g.v, g.nv, s, s, sx, 0, x0, y0, 1, nullptr);
  return b;
}
bool Complex(wchar_t ch) {
  return (ch >= 0x0300 && ch <= 0x036F) || (ch >= 0x0590 && ch <= 0x08FF) || (ch >= 0x0900 && ch <= 0x0DFF) || (ch >= 0x0E00 && ch <= 0x0FFF) ||
         (ch >= 0x1000 && ch <= 0x109F) || (ch >= 0x1780 && ch <= 0x18AF) || (ch >= 0x200B && ch <= 0x200F) || (ch >= 0x202A && ch <= 0x202E) ||
         (ch >= 0xD800 && ch <= 0xDFFF) || (ch >= 0xFB1D && ch <= 0xFDFF) || (ch >= 0xFE70 && ch <= 0xFEFF);
}
// 文字 → 字形序列；不支持时返回 false（调用方改走 GDI+）
bool Shape(Font* font, const std::wstring& t, FFace*& face, float& px, std::vector<int>& gi) {
  if (!g_enabled || !font || t.empty()) return false;
  for (wchar_t ch : t) if (Complex(ch)) return false;
  if (font->GetUnit() != UnitPixel) return false;
  std::wstring nm; int style = 0;
  if (!DnFontInfo(font, nm, style)) return false;  // 只认自己建的字体对象（知道它要的是哪一款）
  face = Face(nm, (style & FontStyleBold) != 0);
  if (!face) return false;
  if (face->verdict < 0) { face->verdict = 2; face->verdict = FaceSelfTest(face, font) ? 1 : 0; if (!face->verdict) InterlockedExchange(&g_fineBrokenSeen, 1); }  // 自检没过不等于字体坏了（也可能是这台机器上贴图不起作用）：只改走 GDI+，不换掉字体包  // 第一次用这款字时整条画法自检一次
  if (face->verdict == 0) return false;
  px = font->GetSize();
  gi.resize(t.size());
  for (size_t i = 0; i < t.size(); i++) { gi[i] = stbtt_FindGlyphIndex(&face->info, t[i]); if (!gi[i] && t[i] != L' ') return false; }  // 这个字体里没有的字：整段交给 GDI+（它会换字体）
  for (size_t i = 0; i < t.size(); i++) if (!Blank(t[i]) && Glyph(face, gi[i]).nv <= 0) { if (face->pkg) InterlockedExchange(&g_pkgBad, 1); return false; }  // 可见的字取不到轮廓（字形数据坏了、只有点阵）：整段交给 GDI+，不只画出一部分；字体包里的字坏了还要让上层换回系统字体
  return true;
}
void BuildLut(unsigned char lut[256], const Color& col) {
  // Skia 的灰度文字修正（SkMaskGamma）：按文字颜色的亮度，把覆盖率换成“在线性空间混合再加一点对比度”的结果
  auto lin = [](float v) { return powf(v, g_gamma); };
  float r = col.GetR() / 255.f, gg = col.GetG() / 255.f, b = col.GetB() / 255.f;
  float lum = powf(0.2126f * lin(r) + 0.7152f * lin(gg) + 0.0722f * lin(b), 1.f / g_gamma);
  float src = lum, dst = 1.f - src, linSrc = lin(src), linDst = lin(dst), con = g_contrast * linDst;
  for (int i = 0; i < 256; i++) {
    float a = i / 255.f; a = a + (1.f - a) * con * a;
    float res;
    if (fabsf(src - dst) < 1.f / 256.f) res = a;
    else { float lo = linSrc * a + (1.f - a) * linDst; float out = powf(lo, 1.f / g_gamma); res = (out - dst) / (src - dst); }
    int v = (int)lroundf(res * 255.f); lut[i] = (unsigned char)(v < 0 ? 0 : v > 255 ? 255 : v);
  }
}
}  // namespace

int g_dnTestTextFail = 0;  // 测试（DN_Set 104）：位 0 精绘贴图什么也不贴，位 1 GDI+ 画字自检当作画不出字——模拟个别系统上画不出字
namespace {
// 整条画法自检：用这款字里有的几个常用字，真按精绘画到一张小图上，数一数有没有像素。个别系统上量得出字宽、却画不出字（卡片只剩图标与底色）——
// 不论是字体文件被替换或损坏、还是贴图这一步在那台机器上不起作用，都会在这里查出来，这款字改走 GDI+（必要时再退到 GDI）
bool FaceSelfTest(FFace* face, Font* font) {
  static const wchar_t probe[] = {0x6D4B, 0x8BD5, 'A', 'g', '0', 0x3042, 0xAC00, 0x0410, 0x0E01};
  std::wstring s; for (wchar_t ch : probe) if (stbtt_FindGlyphIndex(&face->info, ch)) { s += ch; if (s.size() >= 3) break; }
  if (s.empty()) return true;
  float px = font->GetSize();
  int W = (int)ceilf(px * (s.size() + 1)) + 8, H = (int)ceilf(px * 2) + 8;
  if (W > 1024) W = 1024; if (H > 256) H = 256; if (W < 16 || H < 8) return true;
  { FFace* f2; float px2; std::vector<int> gi2; if (!Shape(font, s, f2, px2, gi2)) return true; }  // 这段不走精绘：不判
  Bitmap b(W, H, PixelFormat32bppPARGB);
  int n = 0; bool drew;
  { Graphics g(&b); g.Clear(Color(0, 0, 0, 0)); Ctx tc; tc.g = &g; tc.draw = true;
    drew = FineDrawImpl(tc, s, font, Color(255, 0, 0, 0), 2, 2, (float)(W - 4), (float)(H - 4), 0); }
  if (!drew) return false;  // 走精绘却画不出（一个像素都没有、或贴图失败）：判坏
  BitmapData bd; Rect r(0, 0, W, H);
  if (b.LockBits(&r, ImageLockModeRead, PixelFormat32bppPARGB, &bd) == Ok) {
    for (int y = 0; y < H; y++) { const unsigned* row = (const unsigned*)((const BYTE*)bd.Scan0 + y * bd.Stride); for (int x = 0; x < W; x++) if (row[x] >> 24) n++; }
    b.UnlockBits(&bd);
  }
  return n >= 4;
}
}  // namespace
int DnFineBroken() { return g_fineBrokenSeen ? 1 : 0; }
int DnFinePkgBad() { return g_pkgBad ? 1 : 0; }
bool DnFontFileComplete(const std::wstring& path) {  // 字体文件的表目录都在文件范围之内（见 SfntInside）：没写完的字体包先不用
  HANDLE f = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING, 0, nullptr);
  if (f == INVALID_HANDLE_VALUE) return false;
  LARGE_INTEGER sz = {}; bool ok = false;
  if (GetFileSizeEx(f, &sz) && sz.QuadPart >= 12) {
    HANDLE m = CreateFileMappingW(f, nullptr, PAGE_READONLY, 0, 0, nullptr);
    if (m) { const unsigned char* d = (const unsigned char*)MapViewOfFile(m, FILE_MAP_READ, 0, 0, 0); if (d) { ok = SfntInside(d, (unsigned long long)sz.QuadPart); UnmapViewOfFile(d); } CloseHandle(m); }
  }
  CloseHandle(f); return ok;
}
void DnFineTestFail(int bits) { g_dnTestTextFail = bits; g_faces.clear(); InterlockedExchange(&g_fineBrokenSeen, 0); InterlockedExchange(&g_pkgBad, 0); }

void DnFineReset() { g_faces.clear(); }
void DnFineRegisterFile(const std::wstring& fam, bool bold, const std::wstring& path) {
  for (auto& r : g_regs) if (r.fam == fam && r.bold == bold) { if (r.path != path) { r.path = path; g_faces.clear(); InterlockedExchange(&g_pkgBad, 0); } return; }
  g_regs.push_back({fam, bold, path}); g_faces.clear(); InterlockedExchange(&g_pkgBad, 0);
}

// 宽度（逻辑像素，不取整）；false＝这段文字不走精绘
bool DnFineMeasure(Font* font, const std::wstring& t, float* w) {
  FFace* face; float px; std::vector<int> gi;
  if (!Shape(font, t, face, px, gi)) return false;
  long long sum = 0; for (size_t i = 0; i < gi.size(); i++) { sum += Glyph(face, gi[i]).adv; if (i + 1 < gi.size()) sum += stbtt_GetGlyphKernAdvance(&face->info, gi[i], gi[i + 1]); }
  *w = (float)sum * px / face->upm;
  return true;
}
// 在框 (x,y,w,h) 里画一行文字：横向按 align（0 左 1 中 2 右），纵向按 CSS 的行框居中（hhea 的上下高度）；false＝没画（调用方改走 GDI+）
static size_t g_bitsLimit = 4000;  // 覆盖率图缓存上限（每个字体）
bool DnFineDraw(Ctx& c, const std::wstring& t, Font* font, const Color& col, float x, float y, float w, float h, int align) {
  return FineDrawImpl(c, t, font, col, x, y, w, h, align);
}
namespace {
bool FineDrawImpl(Ctx& c, const std::wstring& t, Font* font, const Color& col, float x, float y, float w, float h, int align) {
  Matrix m; c.g->GetTransform(&m); REAL e[6]; m.GetElements(e);
  if (fabsf(e[1]) > 1e-4f || fabsf(e[2]) > 1e-4f || e[0] <= 0 || fabsf(e[0] - e[3]) > 1e-4f) return false;  // 只处理平移＋等比缩放（镜像画布交给 GDI+）
  FFace* face; float px0; std::vector<int> gi;
  if (!Shape(font, t, face, px0, gi)) return false;
  if (!c.draw) return true;
  // 缓存满了只在开始画这一段之前清：画的过程中要保留已经取到的覆盖率图（原来在取图时就清，同一段字里前面取到的图被释放，
  // 之后拼字时读到已释放的内存——字多、字号多（换皮肤、悬停展开、名字换得勤）时才会碰上，表现为偶尔闪退）
  if (face->bits.size() > g_bitsLimit) face->bits.clear();
  float sc = e[0], px = px0 * sc;
  float X = x * sc + e[4], Y = y * sc + e[5], W = w * sc, H = h * sc;
  float k = px / face->upm, tw = 0;
  for (size_t i = 0; i < gi.size(); i++) { tw += Glyph(face, gi[i]).adv * k; if (i + 1 < gi.size()) tw += stbtt_GetGlyphKernAdvance(&face->info, gi[i], gi[i + 1]) * k; }
  float pen = align == 1 ? X + (W - tw) / 2 : align == 2 ? X + W - tw : X;
  float content = (face->asc + face->desc) * k;
  int base = (int)lroundf(Y + (H - content) / 2 + face->asc * k);
  struct Pl { const FBits* b; int x, y; };
  std::vector<Pl> pl; pl.reserve(gi.size());
  int bx0 = INT_MAX, by0 = INT_MAX, bx1 = INT_MIN, by1 = INT_MIN;
  for (size_t gidx = 0; gidx < gi.size(); gidx++) {
    int g = gi[gidx];
    int ix = (int)floorf(pen); int sub = (int)lroundf((pen - ix) * 4); if (sub == 4) { ix++; sub = 0; }
    const FBits& b = Bits(face, g, px, sub);
    if (b.w > 0) {
      Pl p = {&b, ix + b.x0, base + b.y0}; pl.push_back(p);
      if (p.x < bx0) bx0 = p.x; if (p.y < by0) by0 = p.y; if (p.x + b.w > bx1) bx1 = p.x + b.w; if (p.y + b.h > by1) by1 = p.y + b.h;
    }
    pen += Glyph(face, g).adv * k;
    if (gidx + 1 < gi.size()) pen += stbtt_GetGlyphKernAdvance(&face->info, g, gi[gidx + 1]) * k;
  }
  if (pl.empty()) {  // 一个像素都没有：全是空格才算画完；有可见的字却没有像素（取不到轮廓）就交给 GDI+
    for (wchar_t ch : t) if (!Blank(ch)) return false;
    return true;
  }
  int bw = bx1 - bx0, bh = by1 - by0;
  std::vector<unsigned char> cov((size_t)bw * bh, 0);
  for (auto& p : pl) for (int yy = 0; yy < p.b->h; yy++) {
    unsigned char* d = &cov[(size_t)(p.y - by0 + yy) * bw + (p.x - bx0)]; const unsigned char* s = &p.b->a[(size_t)yy * p.b->w];
    for (int xx = 0; xx < p.b->w; xx++) if (s[xx]) d[xx] = (unsigned char)(255 - (255 - d[xx]) * (255 - s[xx]) / 255);  // 相邻字形的边缘重叠时按“叠加覆盖”合成（同逐字 src-over），不是直接相加
  }
  unsigned char lut[256]; BuildLut(lut, col);
  std::vector<unsigned> px32((size_t)bw * bh, 0);
  unsigned ca = col.GetA(), cr = col.GetR(), cg = col.GetG(), cb = col.GetB();
  for (size_t i = 0; i < cov.size(); i++) {
    if (!cov[i]) continue;
    unsigned a = lut[cov[i]] * ca / 255; if (!a) continue;
    px32[i] = (a << 24) | ((cr * a / 255) << 16) | ((cg * a / 255) << 8) | (cb * a / 255);
  }
  if (g_dnTestTextFail & 1) return true;  // 测试：模拟贴图这一步在那台机器上不起作用
  // 覆盖率图用 GDI+ 自己分配的位图（锁定后写入），不用“借用调用方内存”的构造：两种都是标准用法，前者在各版本 GDI+ 上最稳
  Bitmap bmp(bw, bh, PixelFormat32bppPARGB);
  { BitmapData bd; Rect rr(0, 0, bw, bh);
    if (bmp.LockBits(&rr, ImageLockModeWrite, PixelFormat32bppPARGB, &bd) != Ok) return false;
    for (int yy = 0; yy < bh; yy++) memcpy((BYTE*)bd.Scan0 + yy * bd.Stride, &px32[(size_t)yy * bw], (size_t)bw * 4);
    bmp.UnlockBits(&bd); }
  GraphicsState st = c.g->Save();
  c.g->ResetTransform();
  c.g->SetInterpolationMode(InterpolationModeNearestNeighbor); c.g->SetPixelOffsetMode(PixelOffsetModeHalf);
  c.g->DrawImage(&bmp, Rect(bx0, by0, bw, bh), 0, 0, bw, bh, UnitPixel);
  c.g->Restore(st);
  return true;
}
}  // namespace

