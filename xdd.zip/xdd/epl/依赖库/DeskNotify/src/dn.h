// DeskNotify：通用的桌面通知卡片（屏幕角落弹出的提醒）。32 位 DLL，导出接口全部是 stdcall 纯 C、固定 4 个指针宽度的参数，
// 易语言用 调用桩_4参数 (接口地址, 参数1, 参数2, 参数3, 参数4) 调用（不用 DLL 命令：DLL 不在时不会报错退出，调用方退回自己的提示窗口）。
// 卡片在 DLL 自己的界面线程里绘制（逐像素透明的分层窗口 + GDI+），调用方主线程忙时照常显示、照常倒计时；不含任何产品专属的图形与文字：
// 标题、正文由调用方给，图标默认取宿主程序自己的图标，强调色默认从图标里取。
#pragma once
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <gdiplus.h>
#include <string>
#include <vector>
#include <functional>
using namespace Gdiplus;

#define DN_VERSION 0x00010205  // 1.2.5：每秒确认在最上层时只让开小的前台置顶窗口（不超过工作区四分之一），大的照常提（不然卡片会被它整个挡住）。1.2.4：每秒确认在最上层时，前台是与卡片重叠的置顶窗口（用户正在用它，如托盘溢出区）、全屏独占的 Direct3D 程序在跑时这一秒不提（信息 61、62）。1.2.3：卡片显示超过约 24.8 天后关闭键点不动、“人回来再提醒”不触发（有符号相减成负数）——改为无符号相减；计数到顶不溢出；新卡片也复位鼠标跟踪。1.2.2：从隐藏状态出现的卡片不继承上一条的悬停（原来上一条被指过就关掉时，接着出现的这条整条不提醒）；卡片出现（或被替换）后系统双击时间以内按下关闭键不算（连点关闭不会顺手关掉紧接着出现的下一条）。1.2.1：复查修正——到了等待上限照常倒计时不算“人回来”、不催；深色底给了深强调色时往亮里调；宿主字体常用字全无轮廓时也换回系统字体。1.2.0：不容易被错过——到场计时（人不在、锁屏、全屏独占时不倒计时，回来再提醒）、跟随用户的屏幕、系统「通知显示时间」作下限、醒目（标志 4）、尽量不被屏幕采集（标志 8）、关闭时的统计（见 dn_core.cpp）。1.1.2：强制显示的每秒确认在有弹出菜单开着时不提层（原来会盖到托盘菜单、右键菜单上），见 dn_core.cpp AnyMenuOpen。1.1.1：个别系统上画不出字时逐级退路（精绘先整条自检、画不出改走 GDI+，GDI+ 也画不出改走 GDI；信息 45）。1.1.0（标志 2：不被屏幕采集；回调事件 4；信息 42～44）

// ---- 基础
Color C(unsigned rgb, int a = 255);
std::wstring Utf8ToW(const char* s);
std::string WToUtf8(const std::wstring& w);
void RoundRectPath(GraphicsPath& p, float x, float y, float w, float h, float r);
struct PixBuf {  // 预乘 BGRA
  int w = 0, h = 0;
  std::vector<unsigned> px;
  void init(int W, int H) { w = W; h = H; px.assign((size_t)W * H, 0); }
};
void BoxBlurAlpha(std::vector<unsigned char>& a, int w, int h, int r);

// ---- 语种（只用来选系统字体、判断从右往左；DLL 里没有任何界面文字）
int LangIndex(const char* code);  // 未知语种按英文
const char* LangCode(int i);
bool LangRtl(int i);

// ---- 绘制上下文
struct Fonts;
struct Ctx {
  Graphics* g = nullptr;  // 绘制（量尺寸时为测量用的 Graphics）
  bool draw = false;
  float k = 1;            // DPI 缩放
  bool rtl = false;       // 画布整体左右镜像（阿拉伯语等）
  Fonts* fonts = nullptr;
};

// ---- 字体：按语种的系统字体栈；宿主可另给字体文件（常规、粗体）。选缺字最少的字体（一样少时宿主字体优先），缺的字再逐段换成有它的字体
struct Fonts {
  void setLang(int lang);
  void setCustom(const std::wstring& regular, const std::wstring& bold);
  Font* pick(const std::wstring& text, float px, bool bold);  // 这段文字的主字体：缺字最少的（宿主字体优先）；缺的字由 runs 逐段换字体
  bool customInUse() const { return cusOk; }
  void dropBadCustom();
  void clear();
  ~Fonts();
  int lang = 2;
  // 内部
  struct Cached { std::wstring fam; float px; int style; Font* f; };
  std::vector<Cached> cache;
  struct Picked { std::wstring text; float px; bool bold; Font* f; };
  std::vector<Picked> picked;
  std::wstring uiFam;
  std::wstring cusReg, cusBold, famR, famB;
  PrivateFontCollection *colR = nullptr, *colB = nullptr;
  std::vector<std::wstring> added;
  bool cusTried = false, cusOk = false, cusPending = false; DWORD cusTry = 0;  // cusPending：宿主给的字体文件上次看时还不完整（如正在解压），隔一会儿再看
  Font* get(const std::wstring& fam, float px, int style, FontCollection* col = nullptr);
  Font* ui(float px, bool bold);
  Font* custom(float px, bool bold);
  std::vector<std::wstring> uiList();
  bool covers(const std::wstring& fam, const std::wstring& text, int* missing);
  void loadCustom();
  void dropCustom();
  bool selfTest(Font* f);
  // 逐段回退：一行里主字体没有的字，换成有这个字的字体（宿主字体、本语种界面字体、常见系统字体，最后查系统里装的全部字体）
  struct Run { int a, b; Font* f; };
  void runs(const std::wstring& t, Font* primary, std::vector<Run>& out);
  int missing(const std::wstring& t, Font* primary);  // 回退之后仍然没有字体能显示的字数
  bool has(const std::wstring& fam, wchar_t ch);        // 字体有没有这个字（按字体逐字缓存）
  Font* fallback(wchar_t ch, float px, bool bold, const std::wstring& skip);
  struct Cov { std::wstring fam; HDC dc = nullptr; HFONT hf = nullptr; HGDIOBJ old = nullptr; bool bad = false; std::vector<unsigned char> pg[256]; };  // 按 256 字一页、用到才分配
  std::vector<Cov*> cov; std::vector<std::pair<wchar_t, std::wstring>> fbCache; std::vector<std::wstring> allFams; bool allTried = false; std::vector<int> deadBlocks; DWORD scanMs = 0;
  void dropCov();
  void pollCustom();
  void systemChanged();
};
bool DnFontInfo(Font* f, std::wstring& fam, int& style);

// ---- 文字
float TextW(Ctx& c, const std::wstring& t, Font* f);
// 一行文字：超出宽度时加省略号；从右往左的画布上按从右往左排；align 0 起始 1 居中 2 末尾
void Text(Ctx& c, const std::wstring& t, Font* f, const Color& col, float x, float y, float w, float h, int align, bool ell);
// 断行：按 Uniscribe 给的断行点（拉丁按词、中日韩按字、泰语等按词典分词），短引号词不拆，一个词都放不下时只在字符簇边界硬断；
// 返回每行在 t 里的 [起, 止)；wOf(i) 是第 i 行可用的宽度
struct Span { int a, b; };
// maxLines＞0：最多断这么多行，放不下时 *overflow 为真（调用方把最后一行接上余下的文字再加省略号；整段很长时不必把后面的都断完）
std::vector<Span> Wrap(Ctx& c, const std::wstring& t, Font* f, const std::function<float(int)>& wOf, int maxLines = 0, bool* overflow = nullptr);
std::vector<Span> WrapBalanced(Ctx& c, const std::wstring& t, Font* f, float w0, float w1);  // 两行时左右均衡

// 段落方向按内容：第一个强方向字符是从右往左的文字（阿拉伯文、希伯来文等）时为真（Unicode 双向算法 P2，字符类别取自 GetStringTypeW）
bool StrongRtl(const std::wstring& t);
std::vector<char> CharStops(const std::wstring& s);  // 字符簇边界（可切开的位置）
bool IsClusterTail(wchar_t ch);  // 不能在它前面切开的字（记号、代理对后半）
std::wstring DnEllipsize(Ctx& c, const std::wstring& t, Font* f, float w);  // 测试用：按宽度加省略号
void DnSystemFontsChanged();  // 系统字体有变化（WM_FONTCHANGE）：清掉已装字体的查询结果

// ---- 精绘文字（dn_fine.cpp，移植自 XhhFloat 1.1.0 的 xf_fine.cpp）：false＝这段文字不支持，调用方改走 GDI+
bool DnFineMeasure(Font* font, const std::wstring& t, float* w);
bool DnFineDraw(Ctx& c, const std::wstring& t, Font* font, const Color& col, float x, float y, float w, float h, int align);
void DnFineRegisterFile(const std::wstring& fam, bool bold, const std::wstring& path);
void DnFineReset();
int DnFineBroken();            // 有字体没通过精绘自检（改走 GDI+）
int DnFinePkgBad();            // 宿主字体里的字形坏了（见 dn_fine.cpp g_pkgBad）
bool DnFontFileComplete(const std::wstring& path);
void DnFineTestFail(int bits); // 测试：见 DN_Set 104
extern int g_dnTestTextFail;
extern bool g_dnTestNoText;
int DnTextPathInfo();          // 诊断（信息 45）：位 0 有字体没通过精绘自检 位 1 GDI+ 画字自检没通过（一律走 GDI）位 2 用 GDI 画过字
void DnTextTestFail(int bits); // 测试：重新自检
