// 核心：界面线程、逐像素透明的分层窗口、卡片排版与绘制、进出动画、悬停暂停、倒计时、导出接口。
// 调用方从任何线程调接口：只在锁里改共享状态、投递一条消息；排版、绘制、动画、鼠标全在界面线程，调用方主线程忙时照常。
#include "dn.h"
#include <math.h>
#include <stdlib.h>
#define DN_API extern "C" __declspec(dllexport) INT_PTR WINAPI
#define WM_DN_CMD (WM_APP + 1)
#define WM_DN_CALL (WM_APP + 2)
enum { TM_FRAME = 1, TM_TOP = 2 };
enum { EV_TIMEOUT = 1, EV_USER = 2, EV_API = 3, EV_NOCAPTURE = 4 };  // 回调事件：倒计时到了、用户点了关闭、被新的一条替换或调用方关闭、要求不被屏幕采集而没能设置（这条没显示）
typedef INT_PTR(WINAPI* DnCallback)(INT_PTR ev, INT_PTR id);

// ---- 共享状态（g_cs 保护）
static CRITICAL_SECTION g_cs, g_startCs; static volatile LONG g_csInit = 0;
static void EnsureCs() {
  if (InterlockedCompareExchange(&g_csInit, 1, 0) == 0) { InitializeCriticalSection(&g_cs); InitializeCriticalSection(&g_startCs); InterlockedExchange(&g_csInit, 2); }
  while (g_csInit != 2) Sleep(0);
}
static void Lock() { EnterCriticalSection(&g_cs); }
static void Unlock() { LeaveCriticalSection(&g_cs); }
struct Opt {
  std::string lang = "en"; std::wstring fontR, fontB;
  int accentMode = 0; unsigned accentRgb = 0;      // 0 从图标取 1 中性（不用强调色） 2 指定
  int iconMode = 0; std::vector<BYTE> iconBytes;   // 0 宿主程序图标 1 不显示 2 图片数据（PNG 等）
  int theme = 0, corner = 0, anim = 0;             // 主题 0 跟随系统 1 浅 2 深 3 高对比（测试）；角落 0 右下 1 左下 2 右上 3 左上；动画 0 跟随系统 1 开 2 关
  int presence = 0, monPolicy = 0, sysDur = 0;     // 1.2.0：到场计时（只在人在时倒计时）；显示在哪块屏（0 主屏 1 跟随用户）；系统「通知显示时间」作时长下限。默认都关着：别的工程行为不变
  int seq = 0;
};
static Opt g_opt; static DnCallback g_cb = nullptr;
struct Cmd { int op, id, ms, flags; std::wstring title, body; };  // op 1 显示 2 改文字 3 关闭
static std::vector<Cmd> g_cmds;
static int g_nextId = 0, g_cur = 0, g_remain = 0; static DWORD g_stamp = 0; static bool g_running = false;  // 调用方看到的状态：当前编号、剩余毫秒
static HANDLE g_thread = nullptr; static DWORD g_tid = 0; static HWND g_hwnd = nullptr; static int g_startErr = 0;
static volatile LONG g_info[64];  // 界面线程写、任何线程读（DN_GetInfo）
static HINSTANCE g_hMod = nullptr;  // 本 DLL 自己的模块句柄：窗口类登记在 DLL 名下（登记在宿主 exe 名下时，同一进程里别的模块用了同名的类就会串）
static volatile LONG g_noIndirect = 0, g_failUlw = 0;  // 测试用：g_noIndirect 当作“只交一部分”不可用（每帧整张提交）；g_failUlw＞0 时把接下来几次提交当作失败（走重新挂分层的路）
static volatile LONG g_presOv = 0, g_qunsOv = 0, g_idleMs = 10000, g_testMsgDur = -1, g_holdCapNoCap = 300000, g_nudgeMs = 10000;  // 1.2.0：测试钩子（DN_Set 106～111）与默认值：多久没有键鼠输入算人不在（10 秒，比显示时长短：人不在时卡片不会还没被看到就到点关掉）；没设不被屏幕采集的卡片人不在时最多等 5 分钟；醒目卡片每隔 10 秒在场时间轻提醒一次
static volatile LONG g_testAge = 0;  // 1.2.3 测试钩子（DN_Set 112）：把当前这条的出现时刻（人不在时还有离开时刻）往前挪这么多毫秒（按无符号算），模拟等了很久
static volatile LONG g_pauseCap = 60000;  // 每条提示悬停暂停的总时长上限（毫秒）：鼠标一直停在卡片上也不会无限期不关（排队等它关闭的调用方不会被无限期挡住）

// ---- 界面线程私有
struct Toast { int id = 0; std::wstring title, body; int dur = 15000, remain = 15000; DWORD stamp = 0; int flags = 0; };
struct Pal { unsigned bg, title, body, icon, border; int borderA; unsigned hover; int hoverA; bool shadow; float s1, s2; unsigned neutral; int neutralA; };
struct Ui {
  HWND self = nullptr;  // 本界面线程的窗口（界面线程里一律用它；g_hwnd 是给别的线程投递用的，DN_Stop 一开始就清掉）
  Fonts fonts; Bitmap* mb = nullptr; Graphics* mg = nullptr;
  Toast t; int phase = 0; DWORD ph0 = 0; float a0 = 0, y0 = 0, alpha = 0, dy = 0; int animIn = 220;  // 0 隐藏 1 进场 2 显示 3 退场
  bool hover = false, hotClose = false, pressClose = false, tracking = false;
  POINT showPt = {0, 0}; bool moved = false; int pausedMs = 0;  // 出现时的光标位置（光标没动过就不算悬停）、这条已经暂停了多久
  PixBuf base; float W = 0, H = 0, k = 1; int m = 0, dpi = 96, forceDpi = 0; bool dark = false, hc = false, rtl = false, reduce = false;
  RECT closeR = {0, 0, 0, 0}, cardR = {0, 0, 0, 0};
  int optSeq = -1; bool dirty = true; Opt o; Pal pal;
  PixBuf icon; int iconSrc = 0; float iconFor = -1; unsigned accent = 0; bool hasAccent = false;
  RECT wa = {0, 0, 0, 0}; HDC mdc = nullptr; HBITMAP dib = nullptr; void* bits = nullptr; int dibW = 0, dibH = 0;
  float lastBw = -1; int lastX = INT_MIN, lastY = INT_MIN, lastA = -1;  // 上一次贴出去的细线长度、位置、整体透明度：都没变的帧不再提交
  bool noCap = false;  // 窗口当前设了不被屏幕采集（WDA_EXCLUDEFROMCAPTURE）
  unsigned baseGen = 0, dibGen = ~0u;  // 底稿每重画一次加一；窗口位图对应的是哪一版底稿。不一致就整张提交（底稿不论在哪里重画的，都不会只修补细线而留下上一条的文字）
  HMONITOR mon = nullptr;  // 1.2.0：这条卡片显示在哪块屏（从隐藏状态出现时选定，显示期间被替换不跳屏；空＝主屏）
  int absent = 0; DWORD absentSince = 0; int heldMs = 0; bool heldEver = false; int quns = 5; DWORD qunsAt = 0;  // 1.2.0 到场计时：人不在的原因位、从何时起、这条因此暂停了多久；通知状态（每秒最多查一次）
  float halo = 0, lastHalo = 0; PixBuf haloPx; bool trainOn = false, trainStatic = false, animTimer = false; DWORD trainT0 = 0, fadeT0 = 0; int trainN = 0, trainD = 0; float fadeFrom = 0;  // 1.2.0 醒目：光晕层与当前强度、窗口位图里的强度；一串提醒
  int sinceNudge = 0, nudges = 0, pulses = 0; bool hovered = false; DWORD shownAt = 0; unsigned strong = 0;  // 1.2.0：距上次提醒的在场毫秒、轻提醒次数、提醒总次数、指过没有、出现时刻、加深后的强调色
};
static Ui* U_ = nullptr;

static void Fire(int ev, int id) {
  DnCallback cb; Lock(); cb = g_cb; if (ev != EV_API && g_cur == id) g_cur = 0; Unlock();
  InterlockedExchange(&g_info[21], ev); InterlockedExchange(&g_info[22], id); InterlockedIncrement(&g_info[23]);
  if (cb) cb(ev, id);
}
// 1.2.3：计数到顶就停在最大值（到场计时让卡片能等上几周，毫秒数超过 2³¹ 不能变成负数）
static int SatInt(int a, int v) { return v <= 0 ? a : a > 0x7FFFFFFF - v ? 0x7FFFFFFF : a + v; }
static void SatAdd(volatile LONG* p, int v) { LONG o, n; do { o = *p; n = (LONG)SatInt((int)o, v); } while (InterlockedCompareExchange(p, n, o) != o); }
// 1.2.0：刚关掉（或被替换）的这条的统计，供宿主记日志（信息 55～59）。先写各项、最后写编号：读的一方先比编号
static void Record(Ui& u) {
  { DWORD sh = u.shownAt ? GetTickCount() - u.shownAt : 0; InterlockedExchange(&g_info[56], (LONG)(sh > 0x7FFFFFFFu ? 0x7FFFFFFFu : sh)); } InterlockedExchange(&g_info[57], u.heldMs);  // 1.2.3：无符号相减、到顶停在最大值
  InterlockedExchange(&g_info[58], (u.hovered ? 1 : 0) | (u.heldEver ? 2 : 0) | (u.noCap ? 4 : 0)); InterlockedExchange(&g_info[59], u.pulses);
  InterlockedExchange(&g_info[55], u.t.id);
}
static unsigned SysRgb(int i) { COLORREF c = GetSysColor(i); return ((c & 0xFF) << 16) | (c & 0xFF00) | ((c >> 16) & 0xFF); }
static bool SystemDark() {
  HKEY k = nullptr; DWORD v = 1, sz = sizeof(v), ty = 0; bool d = false;
  if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize", 0, KEY_READ, &k) == ERROR_SUCCESS) {
    if (RegQueryValueExW(k, L"AppsUseLightTheme", nullptr, &ty, (BYTE*)&v, &sz) == ERROR_SUCCESS && ty == REG_DWORD) d = (v == 0);
    RegCloseKey(k);
  }
  return d;
}
static bool HighContrast() { HIGHCONTRASTW hc = {sizeof(hc)}; return SystemParametersInfoW(SPI_GETHIGHCONTRAST, sizeof(hc), &hc, 0) && (hc.dwFlags & HCF_HIGHCONTRASTON); }
static bool AnimOff() { BOOL a = TRUE; return SystemParametersInfoW(0x1042 /*SPI_GETCLIENTAREAANIMATION*/, 0, &a, 0) && !a; }
static Pal PalOf(bool dark, bool hc) {
  if (hc) { unsigned bg = SysRgb(COLOR_WINDOW), fg = SysRgb(COLOR_WINDOWTEXT); return {bg, fg, fg, fg, fg, 255, fg, 48, false, 0, 0, SysRgb(COLOR_HIGHLIGHT), 255}; }
  if (dark) return {0x1E1E23, 0xF5F5F7, 0xA6A6AF, 0xA6A6AF, 0xFFFFFF, 26, 0xFFFFFF, 30, true, 0.55f, 0.45f, 0xFFFFFF, 70};
  return {0xFFFFFF, 0x18181B, 0x52525B, 0x71717A, 0x000000, 15, 0x000000, 15, true, 0.12f, 0.07f, 0x18181B, 60};
}
static int MonitorDpi(HMONITOR mon) {
  typedef HRESULT(WINAPI * GDFM)(HMONITOR, int, UINT*, UINT*);
  static GDFM f = nullptr; static bool tried = false;
  if (!tried) { tried = true; HMODULE h = LoadLibraryW(L"shcore.dll"); if (h) f = (GDFM)(void*)GetProcAddress(h, "GetDpiForMonitor"); }  // Win8.1 起才有：按需取地址，Win7 不受影响
  UINT x = 0, y = 0; if (f && mon && SUCCEEDED(f(mon, 0, &x, &y)) && x) return (int)x;
  HDC dc = GetDC(nullptr); int d = GetDeviceCaps(dc, LOGPIXELSX); ReleaseDC(nullptr, dc); return d > 0 ? d : 96;
}

// ---------------- 图标与强调色 ----------------
#pragma pack(push, 2)
struct GrpEntry { BYTE w, h, colors, res; WORD planes, bpp; DWORD bytes; WORD id; };
struct GrpDir { WORD res, type, count; GrpEntry e[1]; };
#pragma pack(pop)
static BOOL CALLBACK FirstGroup(HMODULE, LPCWSTR, LPWSTR name, LONG_PTR p) { *(LPWSTR*)p = IS_INTRESOURCE(name) ? name : _wcsdup(name); return FALSE; }
static bool IconToPix(HICON hi, PixBuf& out) {
  ICONINFO ii; if (!hi || !GetIconInfo(hi, &ii)) return false;
  BITMAP bm = {}; GetObject(ii.hbmColor ? ii.hbmColor : ii.hbmMask, sizeof(bm), &bm);
  int w = bm.bmWidth, h = ii.hbmColor ? bm.bmHeight : bm.bmHeight / 2; bool ok = w > 0 && h > 0;
  if (ok) {
    out.init(w, h);
    BITMAPINFO bi = {}; bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = -h; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
    HDC dc = GetDC(nullptr); bool hasA = false;
    if (ii.hbmColor && GetDIBits(dc, ii.hbmColor, 0, h, out.px.data(), &bi, DIB_RGB_COLORS)) for (unsigned v : out.px) if (v >> 24) { hasA = true; break; }
    if (!hasA) {  // 没有透明度通道的老式图标：按掩码定透明
      std::vector<unsigned> mk((size_t)w * h);
      if (GetDIBits(dc, ii.hbmMask, 0, h, mk.data(), &bi, DIB_RGB_COLORS)) for (size_t i = 0; i < mk.size(); i++) out.px[i] = (mk[i] & 0xFFFFFF) ? 0 : (out.px[i] | 0xFF000000);
    }
    ReleaseDC(nullptr, dc);
    for (auto& v : out.px) { unsigned a = v >> 24; if (a == 255) continue; v = (a << 24) | ((((v >> 16) & 255) * a / 255) << 16) | ((((v >> 8) & 255) * a / 255) << 8) | ((v & 255) * a / 255); }
  }
  if (ii.hbmColor) DeleteObject(ii.hbmColor); if (ii.hbmMask) DeleteObject(ii.hbmMask);
  return ok;
}
static bool HostIcon(int want, PixBuf& out, int* got) {  // 宿主程序的图标（资源里的第一个图标组，与资源管理器显示的相同）：取不小于 want 的最小一张，没有就取最大的
  HMODULE ex = GetModuleHandleW(nullptr); LPWSTR name = nullptr;
  EnumResourceNamesW(ex, RT_GROUP_ICON, FirstGroup, (LONG_PTR)&name);
  if (!name) return false;
  int sz = 0; HRSRC r = FindResourceW(ex, name, RT_GROUP_ICON); HGLOBAL g = r ? LoadResource(ex, r) : nullptr; const GrpDir* d = g ? (const GrpDir*)LockResource(g) : nullptr;
  if (d && d->count) {
    int best = 0, big = 0;
    for (int i = 0; i < d->count; i++) { int s = d->e[i].w ? d->e[i].w : 256; if (s > big) big = s; if (s >= want && (!best || s < best)) best = s; }
    sz = best ? best : big;
  }
  bool ok = false;
  if (sz) { HICON hi = (HICON)LoadImageW(ex, name, IMAGE_ICON, sz, sz, LR_DEFAULTCOLOR); ok = IconToPix(hi, out); if (hi) DestroyIcon(hi); }
  if (!IS_INTRESOURCE(name)) free(name);
  if (got) *got = sz;
  return ok;
}
static bool BytesToPix(const std::vector<BYTE>& b, PixBuf& out) {
  if (b.empty()) return false;
  HGLOBAL hg = GlobalAlloc(GMEM_MOVEABLE, b.size()); if (!hg) return false;
  memcpy(GlobalLock(hg), b.data(), b.size()); GlobalUnlock(hg);
  IStream* st = nullptr; if (CreateStreamOnHGlobal(hg, TRUE, &st) != S_OK) { GlobalFree(hg); return false; }
  bool ok = false;
  { Bitmap bmp(st); UINT w0 = bmp.GetLastStatus() == Ok ? bmp.GetWidth() : 0, h0 = w0 ? bmp.GetHeight() : 0;
    if (w0 > 0 && h0 > 0 && w0 <= 512 && h0 <= 512) { Rect rc(0, 0, (INT)w0, (INT)h0); out.init(rc.Width, rc.Height);
      BitmapData bd; bd.Width = rc.Width; bd.Height = rc.Height; bd.Stride = rc.Width * 4; bd.PixelFormat = PixelFormat32bppPARGB; bd.Scan0 = out.px.data();
      ok = bmp.LockBits(&rc, ImageLockModeRead | ImageLockModeUserInputBuf, PixelFormat32bppPARGB, &bd) == Ok; if (ok) bmp.UnlockBits(&bd); }
    else if (w0 > 0 && h0 > 0) {  // 图片很大：先按比例缩到 256 以内再用（图标最多画 22 像素×缩放）——不按原尺寸分配（上万像素的图要几百 MB，分配失败时进程直接退出）；GDI+ 自己解码失败只返回错误
      float sc = 256.f / (float)(w0 > h0 ? w0 : h0); int w = (int)lroundf(w0 * sc), h = (int)lroundf(h0 * sc); if (w < 1) w = 1; if (h < 1) h = 1;
      out.init(w, h); Bitmap dst(w, h, w * 4, PixelFormat32bppPARGB, (BYTE*)out.px.data());
      { Graphics g(&dst); g.SetCompositingMode(CompositingModeSourceCopy); g.SetInterpolationMode(InterpolationModeHighQualityBicubic); g.SetPixelOffsetMode(PixelOffsetModeHalf);
        ok = g.DrawImage(&bmp, Rect(0, 0, w, h), 0, 0, (INT)w0, (INT)h0, UnitPixel) == Ok; }
      if (!ok) out = PixBuf();
    } }
  st->Release(); return ok;
}
// 从图标取强调色：不透明像素按色相（36 格）统计，权重＝饱和度×明度；主色相够明显（占不透明像素的 15% 以上）才用，
// 色调统一成柔和的一档（不会出现刺眼的“报错红”）；相邻三格做加权圆周平均（红色跨 0°/360° 时不会平均成青色）
static bool AccentFromPix(const PixBuf& p, bool dark, unsigned* out) {
  double hist[36] = {0}, hs[36] = {0}; int opaque = 0;
  for (unsigned v : p.px) {
    unsigned a = v >> 24; if (a < 200) continue; opaque++;
    float R = ((v >> 16) & 255) * 255.f / a / 255.f, G = ((v >> 8) & 255) * 255.f / a / 255.f, B = (v & 255) * 255.f / a / 255.f;
    float mx = R > G ? (R > B ? R : B) : (G > B ? G : B), mn = R < G ? (R < B ? R : B) : (G < B ? G : B), dl = mx - mn, sat = mx > 0 ? dl / mx : 0;
    if (sat < 0.35f || mx < 0.35f || dl <= 0) continue;
    float h = mx == R ? 60 * fmodf((G - B) / dl, 6) : mx == G ? 60 * ((B - R) / dl + 2) : 60 * ((R - G) / dl + 4); if (h < 0) h += 360;
    int bin = (int)(h / 10) % 36; hist[bin] += sat * mx; hs[bin] += h * sat * mx;
  }
  int best = -1; double bw = 0;
  for (int i = 0; i < 36; i++) { if (hist[i] <= 0) continue; double w = hist[i] + hist[(i + 35) % 36] + hist[(i + 1) % 36]; if (w > bw) { bw = w; best = i; } }
  if (best < 0 || opaque == 0 || bw < 0.15 * opaque) return false;
  double cx = 0, cy = 0; for (int d = -1; d <= 1; d++) { int j = (best + d + 36) % 36; if (hist[j] <= 0) continue; double hm = hs[j] / hist[j] * 3.14159265358979 / 180; cx += hist[j] * cos(hm); cy += hist[j] * sin(hm); }
  double hue = atan2(cy, cx) * 180 / 3.14159265358979; if (hue < 0) hue += 360;
  float S = 0.95f, L = dark ? 0.70f : 0.74f, Cc = (1 - fabsf(2 * L - 1)) * S, X = Cc * (1 - fabsf(fmodf((float)hue / 60, 2) - 1)), m = L - Cc / 2;
  int hi = (int)(hue / 60) % 6;
  float r1 = (hi == 0 || hi == 5) ? Cc : (hi == 1 || hi == 4) ? X : 0, g1 = (hi == 1 || hi == 2) ? Cc : (hi == 0 || hi == 3) ? X : 0, b1 = (hi == 3 || hi == 4) ? Cc : (hi == 2 || hi == 5) ? X : 0;
  *out = ((unsigned)lroundf((r1 + m) * 255) << 16) | ((unsigned)lroundf((g1 + m) * 255) << 8) | (unsigned)lroundf((b1 + m) * 255);
  return true;
}

// 1.2.0 醒目卡片的「强」强调色：色相不变、饱和度最多 0.9，亮度往下调到与底色的对比度≥3:1（WCAG 1.4.11 非文字元素）；
// 柔和的强调色在白底上只有 2.3:1（小红花 #FF8A7A），细线、竖条在余光里不显眼。深色主题下柔和的强调色本来就够，原样用
static double RelLum(unsigned rgb) { double c[3] = {((rgb >> 16) & 255) / 255.0, ((rgb >> 8) & 255) / 255.0, (rgb & 255) / 255.0}; for (double& v : c) v = v <= 0.04045 ? v / 12.92 : pow((v + 0.055) / 1.055, 2.4); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; }
static double Contrast(unsigned a, unsigned b) { double x = RelLum(a), y = RelLum(b); if (x < y) { double s = x; x = y; y = s; } return (x + 0.05) / (y + 0.05); }
static unsigned StrongAccent(unsigned acc, unsigned bg) {
  if (Contrast(acc, bg) >= 3.0) return acc;
  float r = ((acc >> 16) & 255) / 255.f, g = ((acc >> 8) & 255) / 255.f, b = (acc & 255) / 255.f, mx = fmaxf(r, fmaxf(g, b)), mn = fminf(r, fminf(g, b)), l = (mx + mn) / 2, d = mx - mn, h = 0;
  float s = d <= 0 ? 0 : d / (1 - fabsf(2 * l - 1)); if (s > 0.9f) s = 0.9f;
  if (d > 0) { h = mx == r ? 60 * fmodf((g - b) / d, 6) : mx == g ? 60 * ((b - r) / d + 2) : 60 * ((r - g) / d + 4); if (h < 0) h += 360; }
  unsigned out = acc; float step = RelLum(bg) > 0.18 ? -0.01f : 0.01f;  // 1.2.1：浅底往暗里调、深底往亮里调（原来只往暗里调：深色主题下宿主给了很深的强调色时越调越看不见）
  for (float L = l; L > 0.04f && L < 0.96f; L += step) {
    float Cc = (1 - fabsf(2 * L - 1)) * s, X = Cc * (1 - fabsf(fmodf(h / 60, 2) - 1)), m = L - Cc / 2; int hi = (int)(h / 60) % 6;
    float r1 = (hi == 0 || hi == 5) ? Cc : (hi == 1 || hi == 4) ? X : 0, g1 = (hi == 1 || hi == 2) ? Cc : (hi == 0 || hi == 3) ? X : 0, b1 = (hi == 3 || hi == 4) ? Cc : (hi == 2 || hi == 5) ? X : 0;
    out = ((unsigned)lroundf((r1 + m) * 255) << 16) | ((unsigned)lroundf((g1 + m) * 255) << 8) | (unsigned)lroundf((b1 + m) * 255);
    if (Contrast(out, bg) >= 3.0) break;
  }
  return out;
}

// ---------------- 排版与绘制 ----------------
struct Line { std::wstring s; float y, w; bool ell; };
struct Lay { float W, H, x0, narrow, wide, cbx, cby, lhT, lhB; bool hasIcon, hasT, rtlT = false, rtlB = false; Font *ft = nullptr, *fb = nullptr; std::vector<Line> tl, bl; };
static std::wstring Clean(std::wstring s, bool oneLine) {  // 换行统一成 \n（标题里换成空格）；其它控制字符、BOM 去掉——不画成方框，排版的分段与画的一致
  std::wstring r; r.reserve(s.size());
  for (size_t i = 0; i < s.size(); i++) {
    wchar_t ch = s[i];
    if (ch == L'\r') { if (i + 1 < s.size() && s[i + 1] == L'\n') continue; ch = L'\n'; }  // \r\n、单独的 \r 都算换行
    if (ch == 0x2028 || ch == 0x2029 || ch == 0x0B || ch == 0x0C || ch == 0x85) ch = L'\n';  // 行分隔符、段分隔符、竖向制表、换页、NEL
    if (ch == L'\t') ch = L' ';
    if (ch == L'\n' && oneLine) ch = L' ';
    if ((ch < 32 && ch != L'\n') || ch == 0x7F || (ch >= 0x80 && ch <= 0x9F) || ch == 0xFEFF) continue;  // 其余 C0/C1 控制字符与 BOM
    r += ch;
  }
  while (!r.empty() && (r.back() == L' ' || r.back() == L'\n')) r.pop_back();
  size_t a = 0; while (a < r.size() && (r[a] == L' ' || r[a] == L'\n')) a++;
  return r.substr(a);
}
static void LayoutCard(Ui& u, Ctx& c, Lay& L) {
  float k = c.k, padL = 16 * k, padR = 16 * k, padT = 14 * k, padB = 15 * k;
  L.W = 360 * k; L.hasIcon = u.icon.w > 0; L.x0 = L.hasIcon ? padL + 22 * k + 12 * k : padL + 2 * k;
  L.cbx = L.W - 26 * k; L.cby = padT + 10.5f * k; L.narrow = (L.cbx - 12 * k - 12 * k) - L.x0; L.wide = L.W - padR - L.x0;
  std::wstring title = Clean(u.t.title, true), body = Clean(u.t.body, false);
  L.hasT = !title.empty(); L.lhT = 21 * k; L.lhB = L.hasT ? 20 * k : 21 * k;
  float y = padT, rowEnd = L.cby + 12 * k;
  auto wAt = [&](float yy) { return yy < rowEnd ? L.narrow : L.wide; };  // 与关闭键同一行的文字给关闭键让位
  if (L.hasT) {
    L.ft = c.fonts->pick(title, 14.5f * k, true);
    auto sp = WrapBalanced(c, title, L.ft, L.narrow, L.wide);
    for (size_t i = 0; i < sp.size() && i < 2; i++) { bool last = i == 1 && sp.size() > 2; std::wstring s = last ? title.substr(sp[i].a) : title.substr(sp[i].a, sp[i].b - sp[i].a); L.tl.push_back({s, y, wAt(y), last}); y += L.lhT; }
  }
  if (!body.empty()) {
    if (L.hasT) y += 4 * k;
    L.fb = c.fonts->pick(body, (L.hasT ? 13 : 13.5f) * k, false);
    const int maxLines = 8; size_t p = 0; bool gap = false;
    while (p <= body.size() && (int)L.bl.size() < maxLines) {
      size_t q = body.find(L'\n', p); if (q == std::wstring::npos) q = body.size();
      std::wstring para = body.substr(p, q - p); float y0 = y; bool more = q < body.size();
      if (para.empty()) {  // 空行：段与段之间最多空半行（连续的空行合成一个）——宿主传来几千个空行时卡片也不会高得没边（画布按卡片高度分配，太大会分配失败而闪退）
        if (!L.bl.empty() && !gap) { y += L.lhB * 0.5f; gap = true; }
        if (!more) break; p = q + 1; continue;
      }
      gap = false; bool over = false; int left = maxLines - (int)L.bl.size();
      auto sp = Wrap(c, para, L.fb, [&](int i) { return wAt(y0 + i * L.lhB); }, left, &over);  // 只断要显示的那几行：整段很长时不必把后面都断完
      for (size_t i = 0; i < sp.size(); i++) {
        bool last = (int)L.bl.size() == maxLines - 1, ell = last && (over || more || i + 1 < sp.size());  // 最后一行：后面还有字就接上余下的文字再加省略号
        L.bl.push_back({ell ? para.substr(sp[i].a) : para.substr(sp[i].a, sp[i].b - sp[i].a), y, wAt(y), ell}); y += L.lhB;
        if (last) break;
      }
      if (!more) break;
      p = q + 1;
    }
  }
  L.H = y + padB; if (L.H < 52 * k) L.H = 52 * k;
  int miss = 0, st = 0; bool cus = false; std::wstring fam;  // 诊断：所选字体缺几个字（0＝不会出现方框）、是否用上了宿主给的字体
  if (L.ft && DnFontInfo(L.ft, fam, st)) { miss += c.fonts->missing(title, L.ft); cus |= fam == c.fonts->famR || fam == c.fonts->famB; }
  if (L.fb && DnFontInfo(L.fb, fam, st)) { miss += c.fonts->missing(body, L.fb); cus |= fam == c.fonts->famR || fam == c.fonts->famB; }
  InterlockedExchange(&g_info[33], miss); InterlockedExchange(&g_info[30], cus && c.fonts->customInUse() ? 1 : 0);
  L.rtlT = StrongRtl(title); L.rtlB = StrongRtl(body); InterlockedExchange(&g_info[34], (L.rtlT ? 1 : 0) | (L.rtlB ? 2 : 0));  // 诊断：段落方向（1 标题 2 正文 从右往左）
}
static void ApplyOptions(Ui& u) {
  Lock(); bool ch = g_opt.seq != u.optSeq; if (ch) u.o = g_opt; Unlock();
  if (ch) { u.optSeq = u.o.seq; int li = LangIndex(u.o.lang.c_str()); u.rtl = LangRtl(li); u.fonts.setLang(li); u.fonts.setCustom(u.o.fontR, u.o.fontB); u.iconFor = -1; }
  bool dark = u.o.theme == 2 || (u.o.theme == 0 && SystemDark()), hc = u.o.theme == 3 || (u.o.theme == 0 && HighContrast());
  if (dark != u.dark || hc != u.hc) u.iconFor = -1;
  u.dark = dark; u.hc = hc; u.pal = PalOf(dark, hc);
  u.reduce = u.o.anim == 2 || (u.o.anim == 0 && AnimOff());
  float want = 22 * u.k;
  if (u.iconFor != want) {  // 图标按这次要画的大小重取（高缩放取大图，不发糊）；强调色按大一些的图统计
    u.iconFor = want; u.icon = PixBuf(); u.iconSrc = 0; PixBuf stat;
    if (u.o.iconMode == 0) { HostIcon((int)ceilf(want), u.icon, &u.iconSrc); HostIcon(48, stat, nullptr); }
    else if (u.o.iconMode == 2) { BytesToPix(u.o.iconBytes, u.icon); u.iconSrc = u.icon.w; stat = u.icon; }
    u.hasAccent = false;
    if (u.hc) {}
    else if (u.o.accentMode == 2) { u.accent = u.o.accentRgb & 0xFFFFFF; u.hasAccent = true; }
    else if (u.o.accentMode == 0 && stat.w > 0) u.hasAccent = AccentFromPix(stat, dark, &u.accent);
  }
  InterlockedExchange(&g_info[9], u.hasAccent ? (LONG)u.accent : -1); InterlockedExchange(&g_info[26], u.iconSrc);
}
static void RenderBase1(Ui& u);
static void RenderBase(Ui& u) {
  u.fonts.dropBadCustom();  // 宿主字体里的字形坏了：排版之前换回系统字体（那时没有字体对象还被用着）
  RenderBase1(u);
  if (u.fonts.customInUse() && DnFinePkgBad()) { u.fonts.dropBadCustom(); RenderBase1(u); }  // 这一次画的时候才发现坏了：换回系统字体再画一遍（只多画这一次）
}
static void RenderBase1(Ui& u) {
  u.baseGen++;
  HMONITOR mon = u.mon; MONITORINFO mi = {sizeof(mi)};  // 1.2.0：出现时选定的那块屏（跟随用户时）；没选、或那块屏拔掉了就用主屏（每次都重新取：主屏可能换了）
  if (!mon || !GetMonitorInfoW(mon, &mi)) { mon = MonitorFromPoint(POINT{0, 0}, MONITOR_DEFAULTTOPRIMARY); u.mon = nullptr; mi.cbSize = sizeof(mi); GetMonitorInfoW(mon, &mi); }
  u.wa = mi.rcWork;
  u.dpi = u.forceDpi ? u.forceDpi : MonitorDpi(mon); u.k = u.dpi / 96.f;
  ApplyOptions(u);
  if (!u.mb) { u.mb = new Bitmap(4, 4, PixelFormat32bppPARGB); u.mg = new Graphics(u.mb); u.mg->SetTextRenderingHint(TextRenderingHintAntiAliasGridFit); }
  Ctx c; c.g = u.mg; c.draw = false; c.k = u.k; c.rtl = u.rtl; c.fonts = &u.fonts;
  Lay L; LayoutCard(u, c, L);
  bool imp = (u.t.flags & 4) != 0;  // 1.2.0 醒目：起始一侧的强调色竖条、强调色描边与粗一点的倒计时线（颜色加深到对底色≥3:1；高对比度用系统高亮色）、光晕层
  if (imp) { unsigned ab = u.hc ? SysRgb(COLOR_HIGHLIGHT) : u.hasAccent ? u.accent : (u.dark ? 0xA6A6AF : 0x71717A); u.strong = u.hc ? ab : StrongAccent(ab, u.pal.bg); }
  InterlockedExchange(&g_info[60], imp ? (LONG)u.strong : -1);
  float k = u.k, W = L.W, H = L.H, r = 14 * k; int m = (int)ceilf(30 * k);
  u.W = W; u.H = H; u.m = m;
  int cw = (int)ceilf(W) + 2 * m, ch = (int)ceilf(H) + 2 * m;
  u.base.init(cw, ch);
  {
    Bitmap bmp(cw, ch, cw * 4, PixelFormat32bppPARGB, (BYTE*)u.base.px.data()); Graphics g(&bmp);
    g.SetSmoothingMode(SmoothingModeAntiAlias); g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit); g.SetPixelOffsetMode(PixelOffsetModeHalf); g.SetInterpolationMode(InterpolationModeHighQualityBicubic);
    if (u.rtl) { Matrix mx(-1, 0, 0, 1, (REAL)(m + W), (REAL)m); g.SetTransform(&mx); } else g.TranslateTransform((REAL)m, (REAL)m);
    Ctx d = c; d.g = &g; d.draw = true; const Pal& p = u.pal;
    { GraphicsPath cp; RoundRectPath(cp, 0, 0, W, H, r); SolidBrush bg(C(p.bg)); g.FillPath(&bg, &cp); }
    if (u.dark && !u.hc) { Pen hl(C(0xFFFFFF, 18), 1 * k); g.DrawLine(&hl, r, 0.5f * k, W - r, 0.5f * k); }
    if (imp) { GraphicsState st = g.Save(); GraphicsPath sp; RoundRectPath(sp, 0, 0, W, H, r); g.SetClip(&sp); SolidBrush sb(C(u.strong)); g.FillRectangle(&sb, 0.f, 0.f, 4 * k, H); g.Restore(st); }  // 1.2.0 醒目：起始一侧 4 设计单位宽的强调色竖条（随圆角裁切；从右往左时在右边）
    { float sw = u.hc ? 2 * k : 1 * k; GraphicsPath bp; RoundRectPath(bp, sw / 2, sw / 2, W - sw, H - sw, r - sw / 2); Pen pn(imp && !u.hc ? C(u.strong, u.dark ? 120 : 96) : C(p.border, p.borderA), sw); g.DrawPath(&pn, &bp); }
    if (L.hasIcon) {  // 图标不跟着画布镜像（标志不能左右翻）：换算到设备坐标再画
      float slot = 22 * k, is = (u.icon.w >= slot && u.icon.w <= slot * 1.15f) ? (float)u.icon.w : slot;
      float ix = 16 * k + (slot - is) / 2, iy = L.cby - is / 2; float dx = roundf(u.rtl ? m + W - ix - is : m + ix), dyy = roundf(m + iy);
      Bitmap ib(u.icon.w, u.icon.h, u.icon.w * 4, PixelFormat32bppPARGB, (BYTE*)u.icon.px.data());
      GraphicsState st = g.Save(); g.ResetTransform(); if (is == (float)u.icon.w) g.SetInterpolationMode(InterpolationModeNearestNeighbor); g.DrawImage(&ib, RectF(dx, dyy, is, is), 0, 0, (REAL)u.icon.w, (REAL)u.icon.h, UnitPixel); g.SetInterpolationMode(InterpolationModeHighQualityBicubic); g.Restore(st);
    }
    for (auto& ln : L.tl) Text(d, ln.s, L.ft, C(p.title), L.x0, ln.y, ln.w, L.lhT, 0, ln.ell);
    for (auto& ln : L.bl) Text(d, ln.s, L.fb, C(L.hasT ? p.body : p.title), L.x0, ln.y, ln.w, L.lhB, 0, ln.ell);
    float dd = 24 * k;
    if (u.hotClose) { SolidBrush hb(C(p.hover, p.hoverA)); g.FillEllipse(&hb, L.cbx - dd / 2, L.cby - dd / 2, dd, dd); }
    { Pen xp(C(u.hotClose ? p.title : p.icon), 1.6f * k); xp.SetStartCap(LineCapRound); xp.SetEndCap(LineCapRound); float s = 3.6f * k;
      g.DrawLine(&xp, L.cbx - s, L.cby - s, L.cbx + s, L.cby + s); g.DrawLine(&xp, L.cbx - s, L.cby + s, L.cbx + s, L.cby - s); }
  }
  if (u.pal.shadow) {  // 两层柔和投影（大而淡的环境投影＋贴边的接触投影），画在卡片下面
    struct Ly { float dy, rad, s; } ly[2] = {{6 * k, 7 * k, u.pal.s1}, {1 * k, 1.2f * k, u.pal.s2}};
    std::vector<float> sa(u.base.px.size(), 0.f);
    for (auto& y : ly) {
      std::vector<unsigned char> a(u.base.px.size(), 0); int dy = (int)roundf(y.dy);
      for (int yy = dy; yy < ch; yy++) for (int xx = 0; xx < cw; xx++) a[(size_t)yy * cw + xx] = (unsigned char)(u.base.px[(size_t)(yy - dy) * cw + xx] >> 24);
      int rr = (int)roundf(y.rad); BoxBlurAlpha(a, cw, ch, rr < 1 ? 1 : rr);
      for (size_t i = 0; i < sa.size(); i++) { float v = a[i] / 255.f * y.s; sa[i] = 1 - (1 - sa[i]) * (1 - v); }
    }
    for (size_t i = 0; i < u.base.px.size(); i++) { unsigned top = u.base.px[i], ta = top >> 24; if (ta == 255) continue; unsigned add = (unsigned)(sa[i] * 255 * (255 - ta) / 255); u.base.px[i] = ((ta + add) << 24) | (top & 0xFFFFFF); }
  }
  u.haloPx = PixBuf();
  if (imp && !u.hc) {  // 1.2.0 醒目：光晕层——卡片外一圈贴边的强调色描边（宽 2.5）＋柔光。提醒时按强度垫在底稿下面（见 ApplyHalo）：卡片本身不透明，只在卡片外看得到
    PixBuf tp; tp.init(cw, ch); std::vector<unsigned char> glow((size_t)cw * ch), ring((size_t)cw * ch);
    { Bitmap tb(cw, ch, cw * 4, PixelFormat32bppPARGB, (BYTE*)tp.px.data()); Graphics tg(&tb); tg.SetSmoothingMode(SmoothingModeAntiAlias); tg.SetPixelOffsetMode(PixelOffsetModeHalf);
      GraphicsPath gp; float e = 2 * k; RoundRectPath(gp, m - e, m - e, W + 2 * e, H + 2 * e, r + e); SolidBrush wb(Color(255, 255, 255, 255)); tg.FillPath(&wb, &gp); }
    for (size_t i = 0; i < glow.size(); i++) glow[i] = (unsigned char)(tp.px[i] >> 24);
    { int rr = (int)roundf(7 * k); BoxBlurAlpha(glow, cw, ch, rr < 1 ? 1 : rr); }
    tp.px.assign(tp.px.size(), 0u);
    { Bitmap tb(cw, ch, cw * 4, PixelFormat32bppPARGB, (BYTE*)tp.px.data()); Graphics tg(&tb); tg.SetSmoothingMode(SmoothingModeAntiAlias); tg.SetPixelOffsetMode(PixelOffsetModeHalf);
      GraphicsPath rp; float o = 1.25f * k; RoundRectPath(rp, m - o, m - o, W + 2 * o, H + 2 * o, r + o); Pen rpn(Color(255, 255, 255, 255), 2.5f * k); tg.DrawPath(&rpn, &rp); }
    for (size_t i = 0; i < ring.size(); i++) ring[i] = (unsigned char)(tp.px[i] >> 24);
    unsigned col = u.strong, cr = (col >> 16) & 255, cg = (col >> 8) & 255, cb = col & 255;  // 1.2.1：深浅主题都用对底色≥3:1 的强调色（原来深色主题直接用强调色：宿主给了深色时光晕看不见）
    u.haloPx.init(cw, ch);
    for (size_t i = 0; i < ring.size(); i++) { unsigned a1 = glow[i] * 3u / 4u, a2 = ring[i] * 235u / 255u, a = a1 > a2 ? a1 : a2; if (a) u.haloPx.px[i] = (a << 24) | ((cr * a / 255) << 16) | ((cg * a / 255) << 8) | (cb * a / 255); }
  }
  float cx0 = L.cbx - 14 * k; int cl = u.rtl ? (int)(m + W - cx0 - 28 * k) : (int)(m + cx0);
  u.closeR = {cl, (int)(m + L.cby - 14 * k), cl + (int)(28 * k), (int)(m + L.cby + 14 * k)};
  u.cardR = {m, m, m + (int)W, m + (int)H};
  InterlockedExchange(&g_info[6], u.dpi); InterlockedExchange(&g_info[7], (LONG)W); InterlockedExchange(&g_info[8], (LONG)H); InterlockedExchange(&g_info[15], m);
  InterlockedExchange(&g_info[16], u.closeR.left); InterlockedExchange(&g_info[17], u.closeR.top); InterlockedExchange(&g_info[18], u.closeR.right); InterlockedExchange(&g_info[19], u.closeR.bottom);
  InterlockedExchange(&g_info[24], (LONG)L.tl.size()); InterlockedExchange(&g_info[25], (LONG)L.bl.size());
  u.dirty = false;
}
static float BarH(const Ui& u) { return ((u.t.flags & 4) ? 3.f : 2.5f) * u.k; }  // 倒计时细线的粗细（1.2.0：醒目卡片粗一点）
static void DrawBar(Ui& u, unsigned* px, float bw) {  // 倒计时细线：卡片底边，被圆角裁住，从起始一侧缩短（画在 px 这张与底稿同尺寸的图上）
  if (bw <= 0) return;
  Bitmap bmp(u.base.w, u.base.h, u.base.w * 4, PixelFormat32bppPARGB, (BYTE*)px); Graphics g(&bmp);
  g.SetSmoothingMode(SmoothingModeAntiAlias); g.SetPixelOffsetMode(PixelOffsetModeHalf);
  float k = u.k, m = (float)u.m; GraphicsPath cp; RoundRectPath(cp, m, m, u.W, u.H, 14 * k); g.SetClip(&cp);
  Color col = u.hc ? C(u.pal.neutral) : (u.t.flags & 4) ? C(u.strong) : u.hasAccent ? C(u.accent) : C(u.pal.neutral, u.pal.neutralA);
  float bh = BarH(u), bx = u.rtl ? m + u.W - bw : m; SolidBrush b(col); g.FillRectangle(&b, bx, m + u.H - bh, bw, bh);
}
static RECT BarStrip(Ui& u) {  // 细线所在的那几行（多留 1 像素），修补与提交都只动这一条
  float m = (float)u.m; RECT r;
  r.left = u.m - 1; r.right = u.m + (int)ceilf(u.W) + 1; r.top = (int)floorf(m + u.H - BarH(u)) - 1; r.bottom = (int)ceilf(m + u.H) + 1;
  if (r.left < 0) r.left = 0; if (r.top < 0) r.top = 0; if (r.right > u.base.w) r.right = u.base.w; if (r.bottom > u.base.h) r.bottom = u.base.h;
  return r;
}
// 1.2.0 醒目：把光晕层按强度 I 垫在底稿下面（底稿在上：out = 底稿 + 光晕×I×(1 − 底稿不透明度)，预乘），只动 rc 这一块；读的是底稿，写进 px
static void ApplyHalo(Ui& u, unsigned* px, float I, RECT rc) {
  if (I <= 0 || u.haloPx.w != u.base.w || u.haloPx.h != u.base.h) return;
  int ii = (int)lroundf(I * 256); if (ii > 256) ii = 256; const int w = u.base.w;
  if (rc.left < 0) rc.left = 0; if (rc.top < 0) rc.top = 0; if (rc.right > w) rc.right = w; if (rc.bottom > u.base.h) rc.bottom = u.base.h;
  for (int y = rc.top; y < rc.bottom; y++) for (int x = rc.left; x < rc.right; x++) {
    size_t i = (size_t)y * w + x; unsigned h = u.haloPx.px[i]; if (!h) continue;
    unsigned b = u.base.px[i], inv = 255 - (b >> 24); if (!inv) continue; unsigned out = 0;
    for (int sh = 0; sh <= 24; sh += 8) { unsigned v = ((b >> sh) & 255) + ((((h >> sh) & 255) * (unsigned)ii) >> 8) * inv / 255; out |= (v > 255 ? 255 : v) << sh; }
    px[i] = out;
  }
}
static void Compose(Ui& u, PixBuf& out, float p, float halo = 0) {  // 底稿（＋光晕）＋倒计时细线（截图用；窗口上的帧见 PushFrame，与这里逐像素相同）
  out = u.base; ApplyHalo(u, out.px.data(), halo, RECT{0, 0, out.w, out.h}); DrawBar(u, out.px.data(), u.W * (p > 1 ? 1 : p));
}
static void PushFrame(Ui& u) {
  // 只有内容变了才重画整张；平时每帧只有倒计时细线在缩短：把细线那几行从底稿恢复、画上新的细线，提交时只交这一条（脏矩形）；
  // 细线、位置、透明度都没变的帧（如悬停暂停时）不提交
  HWND h = u.self; if (!h) return;
  LARGE_INTEGER q0, q1, qf; QueryPerformanceCounter(&q0);
  bool full = false;
  if (u.dirty || u.base.w == 0) RenderBase(u);
  if (u.dibGen != u.baseGen) full = true;
  float hl = ((u.t.flags & 4) && !u.hc && u.haloPx.w == u.base.w && u.haloPx.h == u.base.h) ? u.halo : 0;  // 1.2.0 醒目：光晕强度变了就整张重合成
  if (fabsf(hl - u.lastHalo) * 255 >= 1) full = true;
  float p = u.t.dur > 0 ? (float)u.t.remain / u.t.dur : 0; float bw = u.W * (p > 1 ? 1 : p < 0 ? 0 : p);
  float k = u.k; bool right = u.o.corner == 0 || u.o.corner == 2, bottom = u.o.corner == 0 || u.o.corner == 1;
  int x = right ? u.wa.right - (int)(16 * k) - (int)u.W - u.m : u.wa.left + (int)(16 * k) - u.m;
  int y = bottom ? u.wa.bottom - (int)(16 * k) - (int)u.H - u.m : u.wa.top + (int)(16 * k) - u.m;
  y += (int)lroundf(bottom ? u.dy : -u.dy);
  int a = (int)lroundf(255 * (u.alpha < 0 ? 0 : u.alpha > 1 ? 1 : u.alpha));
  int w = u.base.w, hh = u.base.h;
  HDC sdc = GetDC(nullptr);
  if (!u.mdc) u.mdc = CreateCompatibleDC(sdc);
  if (!u.dib || u.dibW != w || u.dibH != hh) {
    if (u.dib) DeleteObject(u.dib);
    BITMAPINFO bi = {}; bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = -hh; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
    u.dib = CreateDIBSection(u.mdc, &bi, DIB_RGB_COLORS, &u.bits, nullptr, 0); u.dibW = w; u.dibH = hh; SelectObject(u.mdc, u.dib); full = true;
  }
  bool content = false; RECT dirty = {0, 0, w, hh};
  if (u.dib && u.bits) {
    unsigned* px = (unsigned*)u.bits;
    if (full) { memcpy(px, u.base.px.data(), (size_t)w * hh * 4); ApplyHalo(u, px, hl, RECT{0, 0, w, hh}); DrawBar(u, px, bw); u.lastBw = bw; u.lastHalo = hl; u.dibGen = u.baseGen; content = true; }
    else if (fabsf(bw - u.lastBw) >= 0.25f) {
      dirty = BarStrip(u);
      for (int r = dirty.top; r < dirty.bottom; r++) memcpy(px + (size_t)r * w + dirty.left, u.base.px.data() + (size_t)r * w + dirty.left, (size_t)(dirty.right - dirty.left) * 4);
      ApplyHalo(u, px, u.lastHalo, dirty);  // 1.2.0：这几行里卡片外的光晕照旧（与整张合成一致）
      DrawBar(u, px, bw); u.lastBw = bw; content = true;
    }
    if (content || x != u.lastX || y != u.lastY || a != u.lastA) {
      POINT src = {0, 0}, dst = {x, y}; SIZE sz = {w, hh}; BLENDFUNCTION bf = {AC_SRC_OVER, 0, (BYTE)a, AC_SRC_ALPHA};
      UPDATELAYEREDWINDOWINFO ui = {}; ui.cbSize = sizeof(ui); ui.hdcDst = sdc; ui.pptDst = &dst; ui.pblend = &bf; ui.dwFlags = ULW_ALPHA;
      if (content) { ui.psize = &sz; ui.hdcSrc = u.mdc; ui.pptSrc = &src; ui.prcDirty = full ? nullptr : &dirty; }  // 只动了位置、透明度：不交内容
      bool forced = g_failUlw > 0 && InterlockedDecrement(&g_failUlw) >= 0;
      bool ok = !forced && !g_noIndirect && UpdateLayeredWindowIndirect(h, &ui);
      if (!ok && !forced) ok = UpdateLayeredWindow(h, sdc, &dst, &sz, u.mdc, &src, 0, &bf, ULW_ALPHA) != FALSE;  // 只交一部分或只改位置、透明度失败（个别环境）：整张提交——窗口位图里始终是完整的当前画面
      if (!ok) {  // 还是失败：多半是别的模块对窗口调过 SetLayeredWindowAttributes（之后逐像素透明的提交一律失败）——把分层样式摘下再挂上，恢复后整张提交
        LONG_PTR ex = GetWindowLongPtrW(h, GWL_EXSTYLE); SetWindowLongPtrW(h, GWL_EXSTYLE, ex & ~WS_EX_LAYERED); SetWindowLongPtrW(h, GWL_EXSTYLE, ex | WS_EX_LAYERED);
        ok = UpdateLayeredWindow(h, sdc, &dst, &sz, u.mdc, &src, 0, &bf, ULW_ALPHA) != FALSE;
        if (ok) InterlockedIncrement(&g_info[37]);
      }
      if (ok) InterlockedIncrement(&g_info[12]);
      u.lastX = x; u.lastY = y; u.lastA = a;
    }
  }
  ReleaseDC(nullptr, sdc);
  QueryPerformanceCounter(&q1); QueryPerformanceFrequency(&qf); { LONG us = (LONG)((q1.QuadPart - q0.QuadPart) * 1000000 / qf.QuadPart); InterlockedExchange(&g_info[35], (g_info[35] * 7 + us) / 8); if (us > g_info[36]) InterlockedExchange(&g_info[36], us); }  // 诊断：每帧耗时（滑动平均、最大，微秒）
  InterlockedExchange(&g_info[13], x); InterlockedExchange(&g_info[14], y); InterlockedExchange(&g_info[28], u.wa.right); InterlockedExchange(&g_info[29], u.wa.bottom);
  InterlockedExchange(&g_info[31], u.wa.left); InterlockedExchange(&g_info[32], u.wa.top);
  if (u.alpha > 0 && !IsWindowVisible(h)) { ShowWindow(h, SW_SHOWNOACTIVATE); SetWindowPos(h, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE); }
}

// ---------------- 动画与倒计时 ----------------
static float EaseOut(float t) { t = 1 - t; return 1 - t * t * t; }
static float EaseIn(float t) { return t * t * t; }
static bool Pausing(const Ui& u) { return u.hover && u.pausedMs < g_pauseCap; }  // 悬停而且暂停额度没用完
static void Publish(Ui& u) {
  Lock(); if (g_cur == u.t.id && (u.phase == 1 || u.phase == 2)) { g_remain = u.t.remain; g_stamp = GetTickCount(); g_running = !Pausing(u) && !u.absent; } Unlock();
  InterlockedExchange(&g_info[4], u.hover ? 1 : 0); InterlockedExchange(&g_info[20], u.phase);
}
static void SetFrameTimer(Ui& u) {
  HWND h = u.self; if (!h) return;
  if (u.phase == 0) { KillTimer(h, TM_FRAME); KillTimer(h, TM_TOP); return; }
  int iv = (u.phase == 1 || u.phase == 3 || u.trainOn || u.fadeT0) ? 15 : (u.reduce || u.absent) ? 250 : Pausing(u) ? 200 : 33;  // 1.2.0：光晕提醒时与进出场一样 15 毫秒一帧；人不在（不倒计时）时一秒 4 帧就够
  u.animTimer = u.trainOn || u.fadeT0;
  SetTimer(h, TM_FRAME, iv, nullptr);
  if (u.t.flags & 5) SetTimer(h, TM_TOP, 1000, nullptr); else KillTimer(h, TM_TOP);  // 强制显示（标志 1）、醒目（标志 4，1.2.0）：每秒确认一次在最上层
}
// ---------------- 1.2.0：不容易被错过 ----------------
// 到场计时：只在人在的时候倒计时（同系统托盘气泡：用 GetLastInputInfo 判断人在不在，不在就不走表）。返回人不在的原因位：
// 1 一段时间（默认 10 秒）没有键鼠输入；2 锁屏、屏保、切到了别的用户（QUNS_NOT_PRESENT）；4 全屏独占的 Direct3D 程序在前台（QUNS_RUNNING_D3D_FULL_SCREEN，卡片画不到它上面）。
// 通知状态（SHQueryUserNotificationState，Vista 起；按需取地址）每秒最多查一次，有键鼠输入时才查
static int Quns(Ui& u, DWORD now) {
  LONG ov = g_qunsOv; if (ov) return (int)ov;
  if (u.qunsAt && now - u.qunsAt < 1000) return u.quns;
  typedef HRESULT(WINAPI * SQ)(int*); static SQ f = nullptr; static bool tried = false;
  if (!tried) { tried = true; HMODULE h = GetModuleHandleW(L"shell32.dll"); if (!h) { wchar_t p[MAX_PATH + 16]; UINT n = GetSystemDirectoryW(p, MAX_PATH); if (n && n < MAX_PATH) { wcscat(p, L"\\shell32.dll"); h = LoadLibraryW(p); } } if (h) f = (SQ)(void*)GetProcAddress(h, "SHQueryUserNotificationState"); }  // 只从系统目录载入
  int s = 5; if (!f || f(&s) != S_OK) s = 5;
  u.quns = s; u.qunsAt = now ? now : 1; return s;
}
static int AbsentBits(Ui& u, DWORD now) {
  if (!u.o.presence) return 0;
  LONG ov = g_presOv; int b = ov == 2 ? 1 : 0;
  if (!ov) { LASTINPUTINFO li = {sizeof(li)}; if (GetLastInputInfo(&li)) { DWORD idle = now - li.dwTime; InterlockedExchange(&g_info[53], (LONG)(idle > 0x7FFFFFFF ? 0x7FFFFFFF : idle)); if (idle >= (DWORD)g_idleMs) b |= 1; } }
  if (!b || g_qunsOv) { int q = Quns(u, now); if (q == 1) b |= 2; else if (q == 3) b |= 4; }
  return b;
}
// 系统「通知显示时间」（Windows 10「轻松使用 → 显示 → 通知显示时间」、Windows 11「辅助功能 → 视觉效果 → 在此时间后关闭通知」；SPI_GETMESSAGEDURATION，秒）
static int SysMsgMs() {
  LONG ov = g_testMsgDur; if (ov >= 0) return (int)ov * 1000;
  ULONG s = 0; if (!SystemParametersInfoW(0x2016 /*SPI_GETMESSAGEDURATION*/, 0, &s, 0)) return 0;
  if (s > 3600) s = 3600; return (int)s * 1000;
}
// 醒目卡片的光晕提醒：一串 n 次、每次 d 毫秒（强度按 sin² 起落，1.5 次/秒以内，远低于 WCAG 2.3.1 每秒 3 次的闪烁阈值）；系统关了动画时改为一次不闪的静态光晕（渐显 0.15 秒、停 1.6 秒、渐隐 0.6 秒）
static bool StartTrain(Ui& u, int n, int d) {  // 返回是否真的开始提醒（普通卡片、高对比度、指过的不提醒）
  if (!(u.t.flags & 4) || u.hc || u.hovered || !u.self) return false;
  u.trainOn = true; u.trainT0 = GetTickCount(); u.trainStatic = u.reduce; u.trainN = u.reduce ? 1 : n; u.trainD = d; u.fadeT0 = 0;
  u.pulses += u.trainN; u.sinceNudge = 0; InterlockedExchange(&g_info[50], u.pulses); SetFrameTimer(u);
  return true;
}
static void StopTrain(Ui& u) { if (!u.trainOn) return; u.trainOn = false; u.fadeFrom = u.halo; u.fadeT0 = GetTickCount(); if (!u.fadeT0) u.fadeT0 = 1; }  // 0.18 秒内收起
static float TrainNow(Ui& u, DWORD now) {
  float v = 0;
  if (u.trainOn) {
    int t = (int)(now - u.trainT0);
    if (u.trainStatic) { if (t < 150) v = t / 150.f; else if (t < 1750) v = 1; else if (t < 2350) v = 1 - (t - 1750) / 600.f; else u.trainOn = false; }
    else if (t >= u.trainN * u.trainD) u.trainOn = false;
    else { float s = sinf(3.14159265f * (float)(t % u.trainD) / (float)u.trainD); v = s * s; }
  }
  if (u.fadeT0) { int t = (int)(now - u.fadeT0); float f = t >= 180 ? 0 : u.fadeFrom * (1 - t / 180.f); if (t >= 180) u.fadeT0 = 0; if (f > v) v = f; }
  return v < 0 ? 0 : v > 1 ? 1 : v;
}
// 显示在哪块屏。0（默认）主屏；1 跟随用户：前台窗口所在的屏（与前台窗口交集最大的那块）→ 光标所在的屏 → 主屏；
// 前台那块屏正被全屏独占的 Direct3D 程序占着（卡片画不到它上面）且还有别的屏时换到另一块（主屏优先）。纯函数（DN_GetInfo 100 测试用）；why：0 主屏 1 前台窗口 2 光标 3 避开全屏独占
static int PickMon(const RECT* mon, int n, int primary, const RECT* fg, const POINT* cur, int quns, int* why) {
  int best = -1, w = 0; long long area = 0;
  if (primary < 0 || primary >= n) primary = 0;
  if (fg) for (int i = 0; i < n; i++) { RECT r; if (IntersectRect(&r, &mon[i], fg)) { long long a = (long long)(r.right - r.left) * (r.bottom - r.top); if (a > area) { area = a; best = i; } } }
  if (best >= 0) w = 1;
  if (best < 0 && cur) for (int i = 0; i < n; i++) if (PtInRect(&mon[i], *cur)) { best = i; w = 2; break; }
  if (best < 0) { best = primary; w = 0; }
  if (w == 1 && quns == 3 && n > 1) { best = primary != best ? primary : (best == 0 ? 1 : 0); w = 3; }
  if (why) *why = w;
  return best;
}
static BOOL CALLBACK MonCb(HMONITOR h, HDC, LPRECT, LPARAM p) { auto* v = (std::vector<HMONITOR>*)p; if (v->size() < 32) v->push_back(h); return TRUE; }
static bool ShellWnd(HWND w) { wchar_t c[64] = L""; GetClassNameW(w, c, 64); return !wcscmp(c, L"Progman") || !wcscmp(c, L"WorkerW") || !wcscmp(c, L"Shell_TrayWnd") || !wcscmp(c, L"Shell_SecondaryTrayWnd"); }  // 桌面、任务栏：看光标
static HMONITOR ChooseMon(Ui& u) {  // 返回空＝主屏
  int why = 0; HMONITOR got = nullptr;
  if (u.o.monPolicy == 1) {
    std::vector<HMONITOR> hs; EnumDisplayMonitors(nullptr, nullptr, MonCb, (LPARAM)&hs);
    std::vector<RECT> rs; int primary = 0;
    for (size_t i = 0; i < hs.size(); i++) { MONITORINFO mi = {sizeof(mi)}; if (!GetMonitorInfoW(hs[i], &mi)) mi.rcMonitor = RECT{0, 0, 0, 0}; rs.push_back(mi.rcMonitor); if (mi.dwFlags & MONITORINFOF_PRIMARY) primary = (int)i; }
    if (!hs.empty()) {
      HWND fg = GetForegroundWindow(); RECT fr = {0, 0, 0, 0}; POINT cp = {0, 0};
      bool hasFg = fg && fg != u.self && IsWindowVisible(fg) && !IsIconic(fg) && !ShellWnd(fg) && GetWindowRect(fg, &fr) && fr.right > fr.left && fr.bottom > fr.top, hasCur = GetCursorPos(&cp) != FALSE;
      int i = PickMon(rs.data(), (int)rs.size(), primary, hasFg ? &fr : nullptr, hasCur ? &cp : nullptr, Quns(u, GetTickCount()), &why);
      got = hs[i];
    }
  }
  InterlockedExchange(&g_info[51], why); return got;
}
static LRESULT CALLBACK WndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp);
static void EnsureOwnWindowState(Ui& u) {
  // 每次显示前核对窗口是不是还是自己的样子：进程里的换肤库（自动模式会给“所有窗口”换肤）、辅助工具等可能给它加鼠标穿透、设窗口区域、改样式。
  // 有就恢复（卡片要能点、不能被裁）；窗口过程被别的模块接管只记下来（诊断 38），不去动它
  HWND h = u.self; if (!h) return;
  const LONG_PTR want = WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_TOPMOST | WS_EX_NOACTIVATE;
  LONG_PTR ex = GetWindowLongPtrW(h, GWL_EXSTYLE), st = GetWindowLongPtrW(h, GWL_STYLE); bool fixed = false;
  if ((ex & want) != want || (ex & WS_EX_TRANSPARENT)) { SetWindowLongPtrW(h, GWL_EXSTYLE, (ex | want) & ~WS_EX_TRANSPARENT); fixed = true; }
  if (st & (WS_CAPTION | WS_THICKFRAME | WS_SYSMENU | WS_DLGFRAME | WS_BORDER)) { SetWindowLongPtrW(h, GWL_STYLE, (st & WS_VISIBLE) | WS_POPUP); SetWindowPos(h, nullptr, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED); fixed = true; }
  HRGN r = CreateRectRgn(0, 0, 0, 0); if (GetWindowRgn(h, r) != ERROR) { SetWindowRgn(h, nullptr, FALSE); fixed = true; } DeleteObject(r);
  if (fixed) { InterlockedIncrement(&g_info[37]); u.dibGen = ~0u; }  // 修过之后整张重交一次
  InterlockedExchange(&g_info[38], GetWindowLongPtrW(h, GWLP_WNDPROC) != (LONG_PTR)WndProc ? 1 : 0);
}
static void StartExit(Ui& u, int reason) {
  if (u.phase != 1 && u.phase != 2) return;
  int id = u.t.id; u.phase = 3; u.ph0 = GetTickCount(); u.a0 = u.alpha; u.y0 = u.dy;
  if (u.reduce) { u.alpha = 0; u.phase = 0; PushFrame(u); ShowWindow(u.self, SW_HIDE); }
  Publish(u);
  SetFrameTimer(u); Record(u); Fire(reason, id);
}
static void Tick(Ui& u) {
  DWORD now = GetTickCount();
  if (u.phase == 1 || u.phase == 2) {
    int el = (int)(now - u.t.stamp); bool was = Pausing(u);
    int raw = was ? 0 : AbsentBits(u, now);  // 1.2.0 到场计时（悬停时人当然在）
    int ab = (raw && !u.noCap && u.heldMs >= (int)g_holdCapNoCap) ? 0 : raw;  // 没设不被屏幕采集的卡片人不在时最多这样等 5 分钟：一直停在屏幕上可能被录进直播、录屏、共享的画面。1.2.1：到了上限只是照常倒计时——人仍不在（raw），不算回来、不催
    if (was) u.pausedMs += el;  // 悬停时不减倒计时，记进暂停时长；额度用完就照常倒计时
    else if (ab) { u.heldMs = SatInt(u.heldMs, el); SatAdd(&g_info[47], el); }  // 人不在：不倒计时，卡片等着（1.2.3：计数到顶不溢出）
    else {
      u.t.remain -= el;
      if (!raw && u.phase == 2 && (u.t.flags & 4) && !u.hc && !u.reduce && !u.hovered && !u.trainOn && u.nudges < 3) { u.sinceNudge += el; if (u.sinceNudge >= (int)g_nudgeMs) { u.nudges++; StartTrain(u, 1, 800); } }  // 醒目卡片：人在、还没指过时，每隔 10 秒在场时间轻提醒一次，最多 3 次
    }
    if (ab && !u.heldEver) { u.heldEver = true; InterlockedIncrement(&g_info[48]); }
    if (!raw && u.absent && !was && u.phase == 2 && ((DWORD)(now - u.absentSince) >= 2000u || !u.pulses)) { if (StartTrain(u, 2, 650)) InterlockedIncrement(&g_info[54]); }  // 人回来了（卡片一直等着）：再提醒一下。1.2.1：只算真回来了（到了等待上限不算）、真提醒了的（普通卡片不提醒，也不计数）
    if (ab && !u.absent) u.absentSince = now;
    bool chg = (ab != 0) != (u.absent != 0) || (was && !Pausing(u)); u.absent = ab; InterlockedExchange(&g_info[46], ab);
    if (chg) SetFrameTimer(u);
    u.t.stamp = now; if (u.t.remain < 0) u.t.remain = 0;
    Publish(u);
    if (u.t.remain <= 0) { StartExit(u, EV_TIMEOUT); if (u.phase == 0) return; }
  }
  float k = u.k;
  if (u.phase == 1) { float t = (now - u.ph0) / (float)u.animIn; if (t >= 1 || u.reduce) { u.phase = 2; u.alpha = 1; u.dy = 0; if (!u.absent) StartTrain(u, 2, 650); SetFrameTimer(u); } else { float e = EaseOut(t); u.alpha = u.a0 + (1 - u.a0) * e; u.dy = u.y0 * (1 - e); } }  // 1.2.0 醒目：落定后提醒两次（落定时人不在就留到人回来）
  if (u.phase == 3) {
    float t = (now - u.ph0) / 160.f;
    if (t >= 1) { u.alpha = 0; u.phase = 0; ShowWindow(u.self, SW_HIDE); Publish(u); SetFrameTimer(u); return; }  // 先隐藏再公布「阶段 0」：别的线程读到阶段 0 时窗口一定已经藏起来了
    float e = EaseIn(t); u.alpha = u.a0 * (1 - e); u.dy = u.y0 + (6 * k - u.y0) * e;
  }
  u.halo = TrainNow(u, now); InterlockedExchange(&g_info[49], (LONG)lroundf(u.halo * 1000));
  if ((u.trainOn || u.fadeT0 != 0) != u.animTimer) SetFrameTimer(u);
  PushFrame(u);
}
#ifndef WDA_NONE
#define WDA_NONE 0x00000000
#endif
#ifndef WDA_EXCLUDEFROMCAPTURE
#define WDA_EXCLUDEFROMCAPTURE 0x00000011
#endif
// 系统内部版本号（RtlGetVersion 不受兼容模式与清单影响）；Windows 10 之前为 0，比 10 还新的大版本按 99999。只算一次
static LONG OsBuild() {
  static volatile LONG cached = -1;
  LONG b = cached;
  if (b < 0) {
    typedef LONG(WINAPI* RGV)(OSVERSIONINFOW*);
    OSVERSIONINFOW vi = {}; vi.dwOSVersionInfoSize = sizeof(vi);
    RGV f = (RGV)(void*)GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlGetVersion");
    b = (f && f(&vi) == 0) ? (vi.dwMajorVersion > 10 ? 99999 : vi.dwMajorVersion == 10 ? (LONG)vi.dwBuildNumber : 0) : 0;
    InterlockedExchange(&cached, b); InterlockedExchange(&g_info[42], b);
  }
  return b;
}
// 界面线程里调用：设或清「不被屏幕采集」（显示器采集、窗口采集、截图都拿不到这扇窗口，用户自己照常看得见）。
// Windows 10 2004（19041）起才有 WDA_EXCLUDEFROMCAPTURE；更早的系统上同一个值会失败或退化成「采集时显示黑块」，所以调用方先按版本挡住（见 DN_Show）。
// 按需取函数地址，Win7 照常加载本 DLL。状态没变就不调系统函数；返回是否已经是要求的状态。设：在画新内容之前；清：在新内容贴出去之后（见 ProcessCmds）
static bool SetNoCapture(Ui& u, bool on) {
  typedef BOOL(WINAPI* SWDA)(HWND, DWORD);
  static SWDA f = (SWDA)(void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetWindowDisplayAffinity");
  if (on == u.noCap) return true;
  if (!f || !u.self || !f(u.self, on ? WDA_EXCLUDEFROMCAPTURE : WDA_NONE)) return false;
  u.noCap = on; InterlockedExchange(&g_info[44], on ? 1 : 0);
  return true;
}
static void ProcessCmds(Ui& u) {
  std::vector<Cmd> cmds; Lock(); cmds.swap(g_cmds); bool optCh = g_opt.seq != u.optSeq; Unlock();
  { DWORD age = (DWORD)InterlockedExchange(&g_testAge, 0); if (age && (u.phase == 1 || u.phase == 2)) { u.shownAt -= age; if (u.absent) u.absentSince -= age; } }  // 1.2.3 测试钩子（DN_Set 112）
  if (optCh) u.dirty = true;  // 显示中改了设置（语言、字体、强调色、图标、主题……）：按新设置重画
  for (auto& c : cmds) {
    bool vis = u.phase == 1 || u.phase == 2;
    if (c.op == 1) {
      if ((c.flags & 2) && !SetNoCapture(u, true)) {  // 要求不被屏幕采集：先设好再画新内容；没设上就这条不显示（宁可不弹，也不能被录进直播画面），回调事件 4，正在显示的那条照常按「被替换」收起
        InterlockedExchange(&g_info[43], 2);
        if (vis && u.t.id) { Record(u); Fire(EV_API, u.t.id); }
        if (u.phase != 0) { u.alpha = 0; u.phase = 0; ShowWindow(u.self, SW_HIDE); Publish(u); SetFrameTimer(u); }
        Fire(EV_NOCAPTURE, c.id);
        continue;
      }
      if (vis && u.t.id) { Record(u); Fire(EV_API, u.t.id); }  // 正在显示的那条被新的一条替换
      if ((c.flags & 8) && !(c.flags & 2)) { if (OsBuild() < 19041) InterlockedExchange(&g_info[43], 1); else if (!SetNoCapture(u, true)) InterlockedExchange(&g_info[43], 2); }  // 1.2.0 标志 8「尽量不被屏幕采集」：先设好再画新内容；系统不支持或没设上照常显示（与标志 2「宁可不弹」不同）
      if (!vis) { ApplyOptions(u); u.mon = ChooseMon(u); }  // 1.2.0：从隐藏状态出现时选这次显示在哪块屏（显示期间被替换不跳屏）
      u.t = Toast(); u.t.id = c.id; u.t.title = c.title; u.t.body = c.body; u.t.dur = u.t.remain = c.ms; u.t.stamp = GetTickCount(); u.t.flags = c.flags;
      if (!vis) { u.hover = false; u.hotClose = false; u.pressClose = false; u.tracking = false; }  // 1.2.3 起也复位鼠标跟踪：上一条在光标下关掉、系统没送来离开通知时，这条要重新登记，不然光标移开后可能一直算悬停。1.2.2：从隐藏状态出现的新卡片不继承上一条的悬停、关闭键高亮与按下（原来上一条被指过就关掉时，这条会被当成“指过”而整条不提醒，关闭键还画成悬停的样子）
      u.absent = 0; u.heldMs = 0; u.heldEver = false; u.trainOn = false; u.fadeT0 = 0; u.halo = 0; u.sinceNudge = 0; u.nudges = 0; u.pulses = 0; u.hovered = u.hover; u.shownAt = GetTickCount();  // 1.2.0：这条的到场计时、光晕提醒与统计从头算（正在悬停时替换的照旧算指过）
      InterlockedExchange(&g_info[46], 0); InterlockedExchange(&g_info[49], 0); InterlockedExchange(&g_info[50], 0); InterlockedExchange(&g_info[52], c.ms);
      u.dirty = true; RenderBase(u);
      if (vis) { u.phase = 1; u.ph0 = GetTickCount(); u.animIn = 160; u.a0 = 0.35f; u.y0 = 4 * u.k; }  // 替换：轻轻“弹”一下，不重新滑入
      else { u.phase = 1; u.ph0 = GetTickCount(); u.animIn = 220; u.a0 = 0; u.y0 = 12 * u.k; u.alpha = 0; u.dy = u.y0; }
      if (u.reduce) { u.phase = 2; u.alpha = 1; u.dy = 0; if (!AbsentBits(u, GetTickCount())) StartTrain(u, 2, 650); }
      if (!vis) u.hover = false;
      if (!u.hover) { if (!GetCursorPos(&u.showPt)) { u.showPt.x = INT_MIN; u.showPt.y = INT_MIN; } u.moved = false; }  // 记下出现时的光标位置（正在悬停时替换的，照旧算悬停）
      EnsureOwnWindowState(u);  // 窗口被别的模块改过（鼠标穿透、窗口区域、样式）就先恢复
      u.pausedMs = 0;
      SetWindowTextW(u.self, (u.t.title.empty() ? u.t.body : u.t.title + L"\n" + u.t.body).c_str());  // 窗口标题＝提示内容：读屏软件、辅助工具能读到这条提示
      Publish(u);
    } else if (c.op == 2) {
      if (vis && c.id == u.t.id) { u.t.title = c.title; u.t.body = c.body; u.dirty = true; SetWindowTextW(u.self, (u.t.title.empty() ? u.t.body : u.t.title + L"\n" + u.t.body).c_str()); }
    } else if (c.op == 3) {
      if (vis && (c.id == 0 || c.id == u.t.id)) StartExit(u, EV_API);
    }
  }
  if (u.phase != 0) { PushFrame(u); SetFrameTimer(u); }
  if (u.noCap && !(u.t.flags & 10)) SetNoCapture(u, false);  // 当前这条不要求不被采集：等它的内容已经贴出去之后再清（先清的话，上一条要求不被采集的内容可能在清掉的那一瞬间被采集到）
}

// ---------------- 窗口 ----------------
static bool InRect(const RECT& r, int x, int y) { return x >= r.left && x < r.right && y >= r.top && y < r.bottom; }
static void SetHover(Ui& u, bool h) {
  if (u.hover == h) return;
  DWORD now = GetTickCount();
  if (u.phase == 1 || u.phase == 2) { int el = (int)(now - u.t.stamp); if (Pausing(u)) u.pausedMs += el; else if (u.absent) { u.heldMs = SatInt(u.heldMs, el); SatAdd(&g_info[47], el); } else u.t.remain -= el; if (u.t.remain < 0) u.t.remain = 0; }  // 先把这之前的时间按原来的状态记上（1.2.0：人不在、不倒计时的那段记进暂停）
  if (!h && u.pausedMs < g_pauseCap && u.t.remain < 1000) u.t.remain = 1000;  // 移开后至少再留 1 秒，不会一离开就消失（暂停额度用完的不再续）
  if (h) { u.hovered = true; StopTrain(u); }  // 1.2.0：指过就是看到了：光晕提醒收起，之后不再催
  u.t.stamp = now; u.hover = h; Publish(u); SetFrameTimer(u);
}
// 1.1.2：有弹出菜单开着（任何程序的右键菜单、托盘菜单、下拉菜单：类名 #32768 的可见顶层窗口）。强制显示的每秒确认这时不提层——提到置顶层最上面就压在用户正在用的菜单上：
// 真机上顶层弹出菜单没有所有者（ReactOS 的 menu.c 注明“In Windows, top menu popup is not owned.”），不会跟着别的窗口上来；卡片默认在右下角，正好是托盘菜单弹出的地方。
// 菜单关掉后下一秒照常确认。出现时的那一次提层不受影响（新的一条照常出现在最上层，同系统的通知）
static bool AnyMenuOpen() {
  for (HWND w = FindWindowExW(nullptr, nullptr, L"#32768", nullptr); w; w = FindWindowExW(nullptr, w, L"#32768", nullptr))
    if (IsWindowVisible(w)) return true;
  return false;
}
// 1.2.4：前台窗口是置顶的、而且与卡片重叠：用户正在用它（托盘溢出区——本程序的托盘图标常在那里，提示多半是让用户去改设置；任务栏弹出的面板、置顶的小工具等）。
// 每秒的确认这一秒不提层，不盖住用户正在用的东西（同 1.1.2 的弹出菜单）。前台不是置顶窗口时提层只影响别的置顶窗口（如后来弹出的别家提示，它们不抢前台），照常提
static bool TopFgOver(HWND self, const Ui& u) {
  HWND fg = GetForegroundWindow(); if (!fg || fg == self || !IsWindowVisible(fg) || !(GetWindowLongPtrW(fg, GWL_EXSTYLE) & WS_EX_TOPMOST)) return false;
  RECT wr, fr, x; if (!GetWindowRect(self, &wr) || !GetWindowRect(fg, &fr)) return false;
  long long fa = (long long)(fr.right - fr.left) * (fr.bottom - fr.top), wa = (long long)(u.wa.right - u.wa.left) * (u.wa.bottom - u.wa.top);
  if (wa > 0 && fa * 4 > wa) return false;  // 1.2.5：只让开小窗口（不超过卡片所在屏工作区的四分之一：托盘溢出区、任务栏弹出的面板、置顶的小工具）；大的置顶窗口（开了“总在最前”的直播软件、播放器）在前台时照常提——让开的话，用户一点它，它就盖到卡片上面，卡片整个被挡住、倒计时照走，一直看不到
  RECT card = {wr.left + u.cardR.left, wr.top + u.cardR.top, wr.left + u.cardR.right, wr.top + u.cardR.bottom};
  return IntersectRect(&x, &fr, &card) != FALSE;
}
static LRESULT CALLBACK WndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
  Ui* up = U_;
  switch (msg) {
    case WM_MOUSEACTIVATE: return MA_NOACTIVATE;  // 永不抢焦点
    case WM_NCHITTEST: return HTCLIENT;
    case WM_DN_CMD: if (up) ProcessCmds(*up); return 0;
    case WM_TIMER:
      if (!up) return 0;
      if (wp == TM_FRAME) Tick(*up);
      if (wp == TM_TOP && (up->phase == 1 || up->phase == 2)) {  // 强制显示、醒目：每秒确认一次在最上层（不激活）。这一秒不提：1.1.2 有弹出菜单开着（见 AnyMenuOpen）；1.2.4 前台是与卡片重叠的置顶窗口（见 TopFgOver）、全屏独占的 Direct3D 程序在跑（卡片画不到它上面；醒目卡片这时因到场计时一直等着，原来会整局游戏每秒都提到它上面）
        int why = AnyMenuOpen() ? 1 : TopFgOver(h, *up) ? 2 : Quns(*up, GetTickCount()) == 3 ? 4 : 0;
        if (!why) SetWindowPos(h, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOOWNERZORDER);
        else { InterlockedExchange(&g_info[61], why); InterlockedIncrement(&g_info[62]); }
      }
      return 0;
    case WM_SETCURSOR: SetCursor(LoadCursor(nullptr, (up && up->hotClose) ? IDC_HAND : IDC_ARROW)); return TRUE;
    case WM_MOUSEMOVE: {
      if (!up || up->phase == 0 || up->phase == 3) return 0;
      Ui& u = *up; int x = (short)LOWORD(lp), y = (short)HIWORD(lp);
      if (!u.moved) {  // 卡片出现在静止的光标下面时，系统会补发一条移动消息：光标真动过才算悬停（光标常停在屏幕角落，不能因此一直暂停）
        POINT cp = {0, 0};
        if (GetCursorPos(&cp) && cp.x == u.showPt.x && cp.y == u.showPt.y) return 0;  // 读不到光标位置（锁屏、安全桌面等）时当作动过
        u.moved = true;
      }
      if (!u.tracking) { TRACKMOUSEEVENT t = {sizeof(t), TME_LEAVE, h, 0}; TrackMouseEvent(&t); u.tracking = true; }
      SetHover(u, InRect(u.cardR, x, y));
      bool hc = InRect(u.closeR, x, y); if (hc != u.hotClose) { u.hotClose = hc; u.dirty = true; PushFrame(u); }
      return 0;
    }
    case WM_MOUSELEAVE: {
      if (!up) return 0; Ui& u = *up; u.tracking = false; u.pressClose = false;
      if (u.hotClose) { u.hotClose = false; u.dirty = true; if (u.phase) PushFrame(u); }
      SetHover(u, false); return 0;
    }
    case WM_LBUTTONDOWN: if (up && InRect(up->closeR, (short)LOWORD(lp), (short)HIWORD(lp)) && (DWORD)(GetTickCount() - up->shownAt) >= (DWORD)GetDoubleClickTime()) { up->pressClose = true; SetCapture(h); } return 0;  // 1.2.3：无符号相减（卡片因到场计时等了约 24.8 天以上时，有符号相减成负数，关闭键会一直不认）。1.2.2：卡片出现（或被替换）后系统双击时间（默认 0.5 秒）以内按下关闭键不算——宿主的等候队列让下一条紧接着出现在同一位置，连点关闭时第二下不会把它也关掉；过了这段时间光标不动也照常能点（不靠悬停，同原设计）
    case WM_LBUTTONUP: {
      if (!up) return 0; bool was = up->pressClose; up->pressClose = false; if (GetCapture() == h) ReleaseCapture();
      if (was && InRect(up->closeR, (short)LOWORD(lp), (short)HIWORD(lp))) StartExit(*up, EV_USER);
      return 0;
    }
    case WM_DN_CALL: {
      if (wp == 4) { DnTextTestFail((int)lp); if (up) up->dirty = true; return 1; }  // 测试（DN_Set 104）：在界面线程里清掉文字画法的缓存、重新自检
      if (!up) return 0; Ui& u = *up;
      if (wp == 3) {  // 自检：窗口当前的位图与“底稿＋当前长度的细线”整张重画逐像素比较，返回不同的像素数（-1＝没有可比的）
        if (!u.bits || u.dibW != u.base.w || u.dibH != u.base.h || u.lastBw < 0 || u.dibGen != u.baseGen) return (LRESULT)-1;
        PixBuf pb = u.base; ApplyHalo(u, pb.px.data(), u.lastHalo, RECT{0, 0, pb.w, pb.h}); DrawBar(u, pb.px.data(), u.lastBw); const unsigned* a = (const unsigned*)u.bits; LRESULT n = 0;
        for (size_t i = 0; i < pb.px.size(); i++) if (a[i] != pb.px[i]) n++;
        return n;
      }
      if (wp == 1) {  // 测试：把当前这条按给定缩放、剩余比例（1.2.0：与光晕强度）画成 PNG
        struct SQ { const wchar_t* path; int pct; int prog; int halo; } *q = (SQ*)lp;
        if (!u.t.id) return 0;
        if (q->pct != 0 && (q->pct < 25 || q->pct > 500)) return 0;  // 缩放比例只收 25%～500%（画布按它分配，太大会分配失败而闪退）
        int save = u.forceDpi; u.forceDpi = q->pct > 0 ? q->pct * 96 / 100 : 0; u.dirty = true; RenderBase(u);
        PixBuf pb; Compose(u, pb, q->prog / 1000.f, q->halo / 1000.f);  // 与窗口上的帧同一个 DrawBar
        Bitmap bmp(pb.w, pb.h, pb.w * 4, PixelFormat32bppPARGB, (BYTE*)pb.px.data()); Bitmap out(pb.w, pb.h, PixelFormat32bppARGB);
        { Graphics g(&out); g.Clear(Color(0, 0, 0, 0)); g.SetCompositingMode(CompositingModeSourceCopy); g.DrawImage(&bmp, 0, 0, pb.w, pb.h); }
        UINT n = 0, sz = 0; GetImageEncodersSize(&n, &sz); std::vector<BYTE> buf(sz); ImageCodecInfo* ici = (ImageCodecInfo*)buf.data(); GetImageEncoders(n, sz, ici);
        CLSID cls = {}; bool found = false; for (UINT i = 0; i < n; i++) if (!wcscmp(ici[i].MimeType, L"image/png")) { cls = ici[i].Clsid; found = true; }
        bool ok = found && out.Save(q->path, &cls, nullptr) == Ok;
        u.forceDpi = save; u.dirty = true; u.lastBw = -1; if (u.phase) PushFrame(u);
        return ok ? 1 : 0;
      }
      if (wp == 2) {  // 测试：断行（正文字号、给定宽度），返回行数，每行起止写进缓冲
        struct WQ { const wchar_t* t; float w; int* out; int cap; } *q = (WQ*)lp;
        ApplyOptions(u); if (!u.mb) { u.mb = new Bitmap(4, 4, PixelFormat32bppPARGB); u.mg = new Graphics(u.mb); u.mg->SetTextRenderingHint(TextRenderingHintAntiAliasGridFit); }
        Ctx c; c.g = u.mg; c.k = 1; c.rtl = u.rtl; c.fonts = &u.fonts; std::wstring t = q->t; Font* f = u.fonts.pick(t, 13, false);
        if (q->cap < 0) { std::wstring e = DnEllipsize(c, t, f, q->w); return (LRESULT)(e.size() && e.back() == 0x2026 && e != t ? e.size() - 1 : e.size()); }  // 容量为负：测省略号，返回保留的字数
        auto sp = Wrap(c, t, f, [&](int) { return q->w; }); int n = 0;
        for (auto& s : sp) { if (n + 2 <= q->cap) { q->out[n] = s.a; q->out[n + 1] = s.b; } n += 2; }
        return (LRESULT)sp.size();
      }
      return 0;
    }
    case WM_FONTCHANGE:  // 系统装上或卸掉了字体：新装的能用上，卸掉的不再当作“有这个字”
      DnSystemFontsChanged(); if (up) { up->fonts.systemChanged(); InterlockedIncrement(&g_info[41]); up->dirty = true; if (up->phase) PushFrame(*up); }
      return 0;
    case WM_SETTINGCHANGE: case WM_SYSCOLORCHANGE: case WM_DISPLAYCHANGE: case 0x02E0 /*WM_DPICHANGED*/:
      if (up) { up->dirty = true; up->iconFor = -1; if (up->phase) PushFrame(*up); }
      return 0;
    case WM_CLOSE: DestroyWindow(h); return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
  }
  return DefWindowProcW(h, msg, wp, lp);
}
static DWORD WINAPI ThreadMain(LPVOID p) {
  HANDLE ready = (HANDLE)p;
  typedef HANDLE(WINAPI * PSTDAC)(HANDLE);  // 宿主进程多半不感知 DPI：本线程按显示器 DPI 自己画，高分屏上不发糊（Win10 1607 起；更早的系统由系统缩放）
  PSTDAC stdac = (PSTDAC)(void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetThreadDpiAwarenessContext");
  if (stdac && !stdac((HANDLE)(INT_PTR)-4)) stdac((HANDLE)(INT_PTR)-3);
  ULONG_PTR tok = 0; GdiplusStartupInput gi;
  if (GdiplusStartup(&tok, &gi, nullptr) != Ok) { g_startErr = 1; SetEvent(ready); return 1; }
  HINSTANCE hi = g_hMod ? g_hMod : GetModuleHandleW(nullptr);
  WNDCLASSEXW wc = {sizeof(wc)}; wc.lpfnWndProc = WndProc; wc.hInstance = hi; wc.hCursor = LoadCursor(nullptr, IDC_ARROW); wc.lpszClassName = L"DeskNotifyCard"; RegisterClassExW(&wc);
  U_ = new Ui();
  HWND h = CreateWindowExW(WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_TOPMOST | WS_EX_NOACTIVATE, L"DeskNotifyCard", L"", WS_POPUP, 0, 0, 1, 1, nullptr, nullptr, hi, nullptr);
  if (!h) { g_startErr = 0x20000 | (int)(GetLastError() & 0xFFFF); delete U_; U_ = nullptr; UnregisterClassW(L"DeskNotifyCard", hi); GdiplusShutdown(tok); SetEvent(ready); return 1; }
  U_->self = h;
  Lock(); g_hwnd = h; Unlock();
  InterlockedExchange(&g_info[3], (LONG)(INT_PTR)h); InterlockedExchange(&g_info[5], (LONG)GetCurrentThreadId());
  SetEvent(ready);
  MSG m; while (GetMessageW(&m, nullptr, 0, 0) > 0) { TranslateMessage(&m); DispatchMessageW(&m); }
  Lock(); if (g_hwnd == h) g_hwnd = nullptr; Unlock();  // DN_Stop 已经清掉了；只清自己的，不碰之后新启动的
  if (U_->dib) DeleteObject(U_->dib); if (U_->mdc) DeleteDC(U_->mdc);
  delete U_->mg; delete U_->mb; delete U_; U_ = nullptr;  // GDI+ 对象要在 GdiplusShutdown 之前释放
  DnFineReset(); UnregisterClassW(L"DeskNotifyCard", hi); GdiplusShutdown(tok);
  return 0;
}
static bool EnsureThread() {
  EnsureCs();
  Lock(); bool ok = g_hwnd != nullptr; Unlock(); if (ok) return true;
  EnterCriticalSection(&g_startCs);
  Lock(); ok = g_hwnd != nullptr; Unlock();
  if (!ok) {
    if (g_thread) {  // 上一个界面线程还没退完（DN_Stop 等超时）：等它退完再启动，任何时候都只有一条界面线程（字体缓存等只给一条线程用）
      if (WaitForSingleObject(g_thread, 5000) != WAIT_OBJECT_0) { g_startErr = 5; LeaveCriticalSection(&g_startCs); InterlockedExchange(&g_info[11], g_startErr); return false; }
      CloseHandle(g_thread); g_thread = nullptr;
    }
    HANDLE ready = CreateEventW(nullptr, TRUE, FALSE, nullptr); g_startErr = 0;
    HANDLE th = CreateThread(nullptr, 0, ThreadMain, ready, 0, &g_tid);
    if (th) {
      if (WaitForSingleObject(ready, 10000) != WAIT_OBJECT_0) g_startErr = 3;
      Lock(); ok = g_hwnd != nullptr; Unlock();
      if (ok) g_thread = th; else { WaitForSingleObject(th, 1000); CloseHandle(th); }
    } else g_startErr = 4;
    CloseHandle(ready);
  }
  LeaveCriticalSection(&g_startCs);
  InterlockedExchange(&g_info[11], g_startErr);
  return ok;
}
static void Post() { HWND h; Lock(); h = g_hwnd; Unlock(); if (h) PostMessageW(h, WM_DN_CMD, 0, 0); }
static std::wstring Arg(INT_PTR p) { return p ? Utf8ToW((const char*)p) : L""; }
static std::wstring Clamp(std::wstring s, size_t n) {  // 输入上限：卡片最多显示 2 行标题、8 行正文，超长的部分不会显示，先截掉（几十万字也不会卡住界面线程）
  if (s.size() <= n) return s;
  s.resize(n); if (!s.empty() && s.back() >= 0xD800 && s.back() <= 0xDBFF) s.pop_back();
  return s + L"\x2026";
}

// =================================================================================================
// 导出接口：每个都是 4 个指针宽度的参数（易语言用 调用桩_4参数 调用）；任何线程都可以调用
DN_API DN_GetVersion(INT_PTR, INT_PTR, INT_PTR, INT_PTR) { return DN_VERSION; }
// 设置（随时可调，显示中的那条马上按新设置重画）：1 语言（UTF-8 语言代码，如 zh-Hans、en、ar）2 字体文件（常规、粗体，UTF-8 路径；0＝不用）
// 3 强调色（a：0 从图标取 1 不用 2 指定，b＝0xRRGGBB）4 图标（a：0 宿主程序图标 1 不显示 2 图片数据，b＝数据地址，c＝字节数）
// 5 主题（0 跟随系统 1 浅色 2 深色）6 回调（stdcall (事件, 编号)，在 DLL 的界面线程上调用）7 角落（0 右下 1 左下 2 右上 3 左上）8 动画（0 跟随系统 1 开 2 关）
// 1.2.0（都默认关着）：9 到场计时（a：1＝只在人在时倒计时——10 秒内有键鼠输入、没锁屏或屏保、没有全屏独占的 Direct3D 程序；人回来后醒目卡片再提醒一次）
// 10 显示在哪块屏（a：0 主屏 1 跟随用户：前台窗口所在的屏 → 光标所在的屏 → 主屏）11 系统「通知显示时间」作时长下限（a：1＝开）
DN_API DN_Set(INT_PTR opt, INT_PTR a, INT_PTR b, INT_PTR c) {
  EnsureCs(); Lock(); bool ok = true; int textFail = -1;
  switch (opt) {
    case 1: g_opt.lang = a ? (const char*)a : "en"; break;
    case 2: g_opt.fontR = Arg(a); g_opt.fontB = Arg(b); break;
    case 3: if (a < 0 || a > 2) ok = false; else { g_opt.accentMode = (int)a; g_opt.accentRgb = (unsigned)b & 0xFFFFFF; } break;
    case 4: if (a < 0 || a > 2 || (a == 2 && (!b || c <= 0 || c > 8 * 1024 * 1024))) ok = false; else { g_opt.iconMode = (int)a; g_opt.iconBytes.clear(); if (a == 2) g_opt.iconBytes.assign((const BYTE*)b, (const BYTE*)b + c); } break;
    case 5: if (a < 0 || a > 3) ok = false; else g_opt.theme = (int)a; break;
    case 6: g_cb = (DnCallback)a; break;
    case 7: if (a < 0 || a > 3) ok = false; else g_opt.corner = (int)a; break;
    case 8: if (a < 0 || a > 2) ok = false; else g_opt.anim = (int)a; break;
    case 9: if (a < 0 || a > 1) ok = false; else g_opt.presence = (int)a; break;
    case 10: if (a < 0 || a > 1) ok = false; else g_opt.monPolicy = (int)a; break;
    case 11: if (a < 0 || a > 1) ok = false; else g_opt.sysDur = (int)a; break;
    case 106: if (a < 0 || a > 2) ok = false; else InterlockedExchange(&g_presOv, (LONG)a); break;  // 测试用：到场判断（0 照实 1 当作人在 2 当作人不在）
    case 107: if (a < 0 || a > 7) ok = false; else InterlockedExchange(&g_qunsOv, (LONG)a); break;  // 测试用：通知状态（0 照实，1～7 当作这个值）
    case 108: if (a < -1 || a > 3600) ok = false; else InterlockedExchange(&g_testMsgDur, (LONG)a); break;  // 测试用：系统「通知显示时间」（秒；-1 照实）
    case 109: if (a < 100) ok = false; else InterlockedExchange(&g_idleMs, (LONG)a); break;  // 测试用：多久没有键鼠输入算人不在（默认 10000）
    case 110: if (a < 0) ok = false; else InterlockedExchange(&g_holdCapNoCap, (LONG)a); break;  // 测试用：没设不被屏幕采集的卡片人不在时最多等多久（默认 300000）
    case 111: if (a < 100) ok = false; else InterlockedExchange(&g_nudgeMs, (LONG)a); break;
    case 112: if (!a) ok = false; else InterlockedExchange(&g_testAge, (LONG)a); break;  // 测试用：当前这条模拟已显示（人不在时还有已离开）这么多毫秒（按无符号算，可超过 2³¹）  // 测试用：醒目卡片轻提醒的间隔（默认 10000）
    case 101: if (a < 100) ok = false; else InterlockedExchange(&g_pauseCap, (LONG)a); break;  // 测试用：悬停暂停的总时长上限（默认 60000）
    case 102: InterlockedExchange(&g_noIndirect, a ? 1 : 0); break;  // 测试用：不用“只交一部分”的提交
    case 103: InterlockedExchange(&g_failUlw, (LONG)a); break;  // 测试用：接下来这么多次提交当作失败
    case 104: textFail = (int)a; break;  // 测试用：模拟个别系统上画不出字——位 0 精绘贴图不起作用，位 1 GDI+ 画字不起作用（设了就重新自检；清缓存在下面交给界面线程做）
    case 105: g_dnTestNoText = a != 0; break;  // 测试用：不画文字
    default: ok = false;
  }
  if (ok && opt != 6 && (opt < 100 || opt == 104 || opt == 105)) g_opt.seq++;  // 104、105 也要重排重画
  HWND h = g_hwnd; Unlock();
  if (textFail >= 0) {  // 清字体表、重新自检要在界面线程里做（排版、画字不在锁里，跨线程清会与正在画的那一次冲突）；还没有界面线程时直接做
    DWORD_PTR r = 0; if (!h || !SendMessageTimeoutW(h, WM_DN_CALL, 4, (LPARAM)textFail, SMTO_NORMAL, 3000, &r)) DnTextTestFail(textFail);
  }
  if (ok && h) PostMessageW(h, WM_DN_CMD, 0, 0);
  return ok ? 1 : 0;
}
// 显示一条（替换正在显示的那条）：标题、正文（UTF-8，正文里的换行照样换行）、显示毫秒（≤0 按 15000）、标志（1＝强制显示：每秒确认一次在最上层；
// 2＝不被屏幕采集：直播、录屏、截图拿不到这张卡片，要 Windows 10 2004 起，系统不支持时不显示、返回 0（信息 43＝1），设置失败时这条不显示、回调事件 4；
// 1.2.0：4＝醒目（起始一侧强调色竖条、对底色≥3:1 的描边与倒计时线、落定后两次光晕提醒、人在时每 10 秒轻提醒一次最多 3 次、指过就停、一直在最上层）；
// 8＝尽量不被屏幕采集（系统支持就设上，不支持或没设上照常显示；与 2 同给时按 2））。返回编号（失败返回 0）
DN_API DN_Show(INT_PTR title, INT_PTR body, INT_PTR ms, INT_PTR flags) {
  EnsureCs();
  if ((flags & 2) && OsBuild() < 19041) { InterlockedExchange(&g_info[43], 1); return 0; }  // 调用方要的是「宁可不弹，也不能被录进去」：老系统做不到就不显示
  Cmd c; c.op = 1; c.title = Clamp(Arg(title), 512); c.body = Clamp(Arg(body), 4096); c.ms = ms > 0 ? (int)ms : 15000; c.flags = (int)flags; c.id = 0;
  { Lock(); bool sd = g_opt.sysDur != 0; Unlock(); if (sd) { int f = SysMsgMs(); if (f > c.ms) c.ms = f; } }  // 1.2.0：系统「通知显示时间」比给的长时按系统的（微软无障碍要求：通知时长不要写死，按用户在系统里设的来）
  HWND h = nullptr;
  EnterCriticalSection(&g_startCs);  // 与 DN_Stop 互斥：不会出现“确认了线程在、命令还没压进去，线程就被停掉”，命令成了孤儿、编号却显示正在显示
  if (EnsureThread()) { Lock(); if (++g_nextId > 0x7FFFFF) g_nextId = 1; c.id = g_nextId; g_cur = c.id; g_remain = c.ms; g_stamp = GetTickCount(); g_running = false; g_cmds.push_back(c); h = g_hwnd; Unlock(); }
  LeaveCriticalSection(&g_startCs);
  if (h) PostMessageW(h, WM_DN_CMD, 0, 0);
  return c.id;
}
DN_API DN_Update(INT_PTR id, INT_PTR title, INT_PTR body, INT_PTR) {  // 改正在显示的那条的文字（倒计时不变）
  EnsureCs(); Cmd c; c.op = 2; c.id = (int)id; c.ms = 0; c.flags = 0; c.title = Clamp(Arg(title), 512); c.body = Clamp(Arg(body), 4096);
  Lock(); bool cur = g_cur == (int)id && id; if (cur) g_cmds.push_back(c); Unlock();
  if (cur) Post(); return cur ? 1 : 0;
}
DN_API DN_Close(INT_PTR id, INT_PTR, INT_PTR, INT_PTR) {  // 关掉编号为 id 的那条（0＝当前这条）；返回它是否还在显示
  EnsureCs(); Lock(); bool cur = g_cur && (id == 0 || g_cur == (int)id); Cmd c; c.op = 3; c.id = cur ? g_cur : 0; c.ms = 0; c.flags = 0;
  if (cur) { g_cur = 0; g_cmds.push_back(c); } Unlock();
  if (cur) Post(); return cur ? 1 : 0;
}
// 信息：1 当前显示的编号（0＝没有）2 编号为 b 的那条还剩多少毫秒（不是当前这条为 0；鼠标指着时不减）3 窗口句柄 4 鼠标在卡片上 5 界面线程号
// 6 DPI 7 卡片宽 8 卡片高（物理像素）9 实际用的强调色（-1＝没有）10 版本 11 启动失败原因 12 已贴出的帧数 13 14 窗口左、顶 15 投影边距
// 16～19 关闭键的范围（窗口内坐标）20 阶段（0 隐藏 1 进场 2 显示 3 退场）21 22 上一次回调的事件、编号 23 回调次数 24 25 标题、正文行数 26 图标原图尺寸
// 27 窗口可见 28 29 31 32 工作区右、下、左、顶 30 用了宿主给的字体 33 回退之后仍缺的字数（0＝不会出现方框）34 段落方向（1 标题 2 正文 从右往左）35 36 每帧耗时（平均、最大，微秒）37 窗口被外部改动后自己修复的次数 38 窗口过程被别的模块接管（只记录）41 收到字体变化通知、重建系统字体缓存的次数
// 42 系统内部版本号（Windows 10 之前为 0）43 最近一次「不被屏幕采集」没做到的原因（1 系统低于 Windows 10 2004 2 设置失败）44 窗口当前设了不被屏幕采集
// 1.2.0：46 当前这条不倒计时的原因位（1 久没键鼠输入 2 锁屏、屏保 4 全屏独占）47 累计因人不在暂停的毫秒 48 累计暂停过的条数 49 光晕强度×1000 50 这条提醒了几次
// 51 选屏依据（0 主屏 1 前台窗口 2 光标 3 避开全屏独占）52 这条实际的显示毫秒 53 最近一次量到的无输入毫秒 54 累计「人回来再提醒」次数
// 55～59 最后关掉（或被替换）的那条：编号、显示了多少毫秒、因人不在暂停的毫秒、标志（1 指过 2 暂停过 4 不被屏幕采集）、提醒次数 60 醒目卡片加深后的强调色（-1＝不是醒目卡片）
// 1.2.4：61 最近一次每秒确认在最上层时没提的原因（1 有弹出菜单开着 2 前台是与卡片重叠的置顶窗口 4 全屏独占）62 这样没提的累计次数
// 100 测试：选屏纯函数（b＝PQ 结构的地址，见 dntest.cpp）
DN_API DN_GetInfo(INT_PTR what, INT_PTR b, INT_PTR, INT_PTR) {
  EnsureCs();
  if (what == 1) { Lock(); int r = g_cur; Unlock(); return r; }
  if (what == 2) { Lock(); int r = 0; if (g_cur && g_cur == (int)b) { r = g_remain; if (g_running) { int el = (int)(GetTickCount() - g_stamp); r -= el; } if (r < 0) r = 0; } Unlock(); return r; }
  if (what == 10) return DN_VERSION;
  if (what == 100) { struct PQ { int n; RECT mon[8]; int primary; int hasFg; RECT fg; int hasCur; POINT cur; int quns; int why; }; PQ* q = (PQ*)b; if (!q || q->n < 1 || q->n > 8) return -1; int w = 0; int r = PickMon(q->mon, q->n, q->primary, q->hasFg ? &q->fg : nullptr, q->hasCur ? &q->cur : nullptr, q->quns, &w); q->why = w; return r; }
  if (what == 42) return OsBuild();
  if (what == 45) { Lock(); int r = DnTextPathInfo(); Unlock(); return r; }  // 文字实际用的画法（见 DnTextPathInfo）
  if (what == 27) { HWND h; Lock(); h = g_hwnd; Unlock(); return h && IsWindowVisible(h) ? 1 : 0; }
  if (what == 40) { HWND h; Lock(); h = g_hwnd; Unlock(); DWORD_PTR r = (DWORD_PTR)-1; if (h) SendMessageTimeoutW(h, WM_DN_CALL, 3, 0, SMTO_NORMAL, 3000, &r); return (INT_PTR)r; }  // 自检（测试用）：窗口上的帧与整张重画是否逐像素相同
  if (what >= 0 && what < 64) return g_info[what];
  return 0;
}
DN_API DN_Stop(INT_PTR, INT_PTR, INT_PTR, INT_PTR) {  // 关掉窗口与界面线程（最多等 3 秒；正在显示的那条不再回调）；之后再调 DN_Show 会重新启动。不要在回调里调用
  if (!g_csInit) return 1;
  EnterCriticalSection(&g_startCs);
  HWND h; Lock(); h = g_hwnd; g_hwnd = nullptr; g_cur = 0; g_cmds.clear(); Unlock();  // 先清掉投递用的句柄：同时调 DN_Show 的线程会等停完再启动新的界面线程，命令不会投给正在销毁的窗口
  if (h) PostMessageW(h, WM_CLOSE, 0, 0);
  bool done = true;
  if (g_thread) { done = WaitForSingleObject(g_thread, 3000) == WAIT_OBJECT_0; if (done) { CloseHandle(g_thread); g_thread = nullptr; } }  // 超时：留着句柄，下次启动前接着等
  LeaveCriticalSection(&g_startCs);
  return done ? 1 : 0;
}
DN_API DN_Snapshot(INT_PTR path, INT_PTR pct, INT_PTR prog1000, INT_PTR halo1000) {  // 测试：当前这条画成 PNG（缩放百分比、剩余比例×1000；1.2.0：光晕强度×1000，醒目卡片才有）
  EnsureCs(); HWND h; Lock(); h = g_hwnd; Unlock(); if (!h || !path) return 0;
  std::wstring p = Arg(path); int hv = halo1000 < 0 ? 0 : halo1000 > 1000 ? 1000 : (int)halo1000; struct SQ { const wchar_t* path; int pct; int prog; int halo; } q = {p.c_str(), (int)pct, (int)prog1000, hv};
  return SendMessageW(h, WM_DN_CALL, 1, (LPARAM)&q);
}
DN_API DN_TestMouse(INT_PTR kind, INT_PTR x, INT_PTR y, INT_PTR) {  // 测试：模拟鼠标（窗口内坐标）：1 移动 2 左键按下 3 左键抬起 4 离开
  EnsureCs(); HWND h; Lock(); h = g_hwnd; Unlock(); if (!h) return 0; LPARAM lp = MAKELPARAM((WORD)(short)x, (WORD)(short)y);
  switch (kind) { case 1: SendMessageW(h, WM_MOUSEMOVE, 0, lp); break; case 2: SendMessageW(h, WM_LBUTTONDOWN, MK_LBUTTON, lp); break; case 3: SendMessageW(h, WM_LBUTTONUP, 0, lp); break; case 4: SendMessageW(h, WM_MOUSELEAVE, 0, 0); break; default: return 0; }
  return 1;
}
DN_API DN_TestWrap(INT_PTR text, INT_PTR width10, INT_PTR out, INT_PTR cap) {  // 测试：按当前语言、13 像素正文、给定宽度断行，返回行数（每行起止写进 out）
  if (!EnsureThread()) return -1; HWND h; Lock(); h = g_hwnd; Unlock();
  std::wstring t = Arg(text); struct WQ { const wchar_t* t; float w; int* out; int cap; } q = {t.c_str(), width10 / 10.f, (int*)out, (int)cap};
  return SendMessageW(h, WM_DN_CALL, 2, (LPARAM)&q);
}
BOOL WINAPI DllMain(HINSTANCE h, DWORD r, LPVOID) { if (r == DLL_PROCESS_ATTACH) { g_hMod = h; DisableThreadLibraryCalls(h); } return TRUE; }
