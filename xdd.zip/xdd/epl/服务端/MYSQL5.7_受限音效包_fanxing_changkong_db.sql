/*
受限音效包（P1）新增的表：fanxing_changkong_db（与 tb_user 同一个库，即服务端 DataSource_main / DataSource_防CC策略 连的库），MySQL 5.7，InnoDB，ROW_FORMAT=DYNAMIC
- 账号字段与 tb_user.user_name 一致：gbk / gbk_bin（写入时沿用现有写法：校验后直接放进 '...'）
- 包名、名单名、申请留言：utf8mb4（写入时沿用项目 A 的 tb_yinxiao_feedback 的写法：FROM_BASE64('UTF-8 的 base64')）
- 5.7 不执行 CHECK 约束，取值范围由服务端代码保证
- 不改动 tb_user、tb_cos、tb_cos_local
*/
USE `fanxing_changkong_db`;

CREATE TABLE IF NOT EXISTS `tb_yinxiao_rpack` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pack_uuid` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '包标识：随机 128 位的小写十六进制',
  `owner` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '创建者账号',
  `pack_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '包名',
  `scope` tinyint(4) NOT NULL COMMENT '1 只有我自己 2 指定的人',
  `wrapped_key` varbinary(80) NOT NULL COMMENT '主密钥加封后的包钥匙：版本(1)+随机数(12)+密文(32)+标签(16)',
  `mk_version` smallint(6) NOT NULL COMMENT '加封所用主密钥的版本',
  `state` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 待生效（客户端还没写好文件） 1 有效',
  `revoked` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1 已撤销（只挡以后的导入，不挡创建者）',
  `expire_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '过期时间（Unix 秒），0 不过期',
  `quota` int(11) NOT NULL DEFAULT '0' COMMENT '名额 N，0 不开启名额模式',
  `quota_used` int(11) NOT NULL DEFAULT '0' COMMENT '已被领取的名额',
  `apply_enabled` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1 允许申请导入',
  `create_time` bigint(20) NOT NULL,
  `active_time` bigint(20) NOT NULL DEFAULT '0',
  `update_time` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pack_uuid` (`pack_uuid`),
  KEY `owner_state` (`owner`,`state`),
  KEY `state_create` (`state`,`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='受限音效包';

CREATE TABLE IF NOT EXISTS `tb_yinxiao_rpack_member` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pack_id` bigint(20) NOT NULL,
  `user_name` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '账号（区分大小写）',
  `source` tinyint(4) NOT NULL COMMENT '1 创建者添加 2 名额领取 3 同意申请',
  `state` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1 有效 2 已被创建者移除（不能再通过名额获得权限）',
  `add_time` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pack_user` (`pack_id`,`user_name`),
  KEY `user_name` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='受限音效包：包里单独添加的账号';

CREATE TABLE IF NOT EXISTS `tb_yinxiao_rlist` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `owner` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL,
  `list_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `create_time` bigint(20) NOT NULL,
  `update_time` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `owner_name` (`owner`,`list_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='受限音效包：名单';

CREATE TABLE IF NOT EXISTS `tb_yinxiao_rlist_member` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `list_id` bigint(20) NOT NULL,
  `user_name` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL,
  `add_time` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `list_user` (`list_id`,`user_name`),
  KEY `user_name` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='受限音效包：名单成员';

CREATE TABLE IF NOT EXISTS `tb_yinxiao_rpack_list` (
  `pack_id` bigint(20) NOT NULL,
  `list_id` bigint(20) NOT NULL,
  PRIMARY KEY (`pack_id`,`list_id`),
  KEY `list_id` (`list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='受限音效包：包与名单的关联';

CREATE TABLE IF NOT EXISTS `tb_yinxiao_rpack_apply` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pack_id` bigint(20) NOT NULL,
  `owner` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '创建者（冗余，查收件箱用）',
  `applicant` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL,
  `message` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '申请留言',
  `state` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 待处理 1 已同意 2 已拒绝',
  `seen` tinyint(4) NOT NULL DEFAULT '0' COMMENT '创建者是否已看过（软件里的提醒用）',
  `apply_time` bigint(20) NOT NULL,
  `handle_time` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `pack_applicant` (`pack_id`,`applicant`),
  KEY `owner_state` (`owner`,`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='受限音效包：导入申请（同一人对同一包只保留一条）';

CREATE TABLE IF NOT EXISTS `tb_yinxiao_rblock` (
  `owner` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL,
  `blocked_user` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL,
  `create_time` bigint(20) NOT NULL,
  PRIMARY KEY (`owner`,`blocked_user`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='受限音效包：屏蔽（被屏蔽的人不能再申请这位创建者的任何包）';

CREATE TABLE IF NOT EXISTS `tb_yinxiao_rpack_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pack_id` bigint(20) NOT NULL DEFAULT '0',
  `pack_uuid` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `actor` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL,
  `action` varchar(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'create activate key claim approve reject revoke restore delete block remove expire quota',
  `target` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL DEFAULT '' COMMENT '涉及的账号（如被同意的申请人、被移除的成员）',
  `ip` varchar(45) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `log_time` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pack_id` (`pack_id`),
  KEY `actor_time` (`actor`,`log_time`),
  KEY `log_time` (`log_time`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='受限音效包：关键操作留痕（绝不记录钥匙）';

CREATE TABLE IF NOT EXISTS `tb_yinxiao_rrate` (
  `rk` varchar(120) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '计数键：动作|账号 或 动作|IP',
  `win_start` bigint(20) NOT NULL COMMENT '窗口开始（Unix 秒）',
  `cnt` int(11) NOT NULL,
  PRIMARY KEY (`rk`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='受限音效包：频率限制计数（固定窗口）';
