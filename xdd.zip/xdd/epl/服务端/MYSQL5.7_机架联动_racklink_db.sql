/*
机架联动授权库（MySQL 5.7 / InnoDB）。
第一次部署：用现有可管理数据库的MySQL账号导入本文件，然后在服务端窗口填写该账号及 racklink_db。
不需要另外创建MySQL账号；本文件不执行CREATE USER或GRANT，不更改原账号库、原登录会话库。

新建 racklink_db 和以下六张表；原始账号和登录信息仍读取窗口指定的原有数据库：
  racklink_licenses   联动许可、停用状态、有效期来源、设备上限和代次。
  racklink_devices    已绑定设备。
  racklink_sessions   短期通行证会话。
  racklink_nonces     防重放随机数。
  racklink_policy     服务端窗口保存的联动总开关与策略。
  racklink_rate_limits 请求频率计数。

可重复导入：不删除表、不清空记录、不重置已有停用状态、设备绑定或策略。
CREATE TABLE IF NOT EXISTS不会修复手工改坏的旧表结构，服务端启动仍会检查InnoDB、字段和关键索引。
首次建库建表需要当前账号具备CREATE权限；仅旧版许可表缺origin列时需要ALTER权限。
导入完成且六表齐全后，程序正常启动不再执行CREATE；日常仍需对本库SELECT/INSERT/UPDATE/DELETE，
以及对窗口指定的原账号表、登录会话表有SELECT读取权限。可以直接复用已有满足权限的账号。
5.7不执行CHECK约束，取值和JSON策略由服务端代码检查；不要手改授权记录。
*/
CREATE DATABASE IF NOT EXISTS `racklink_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;
USE `racklink_db`;

-- 许可
CREATE TABLE IF NOT EXISTS racklink_licenses (
  id BIGINT NOT NULL AUTO_INCREMENT,
  account VARBINARY(512) NOT NULL,
  salt VARBINARY(16) NOT NULL DEFAULT '',
  credential_hash VARBINARY(32) NOT NULL DEFAULT '',
  product VARBINARY(128) NOT NULL,
  revoked INT NOT NULL DEFAULT 0,
  expires BIGINT NOT NULL,
  max_devices INT NOT NULL,
  generation BIGINT NOT NULL DEFAULT 1,
  auth_mode VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'legacy_session',
  config_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  reset_serial VARBINARY(128) NOT NULL DEFAULT '',
  origin VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'manual',
  PRIMARY KEY(id),
  UNIQUE KEY racklink_product_account(product,account)
) ENGINE=InnoDB;

-- 设备绑定
CREATE TABLE IF NOT EXISTS racklink_devices (
  license_id BIGINT NOT NULL,
  device CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  first_seen BIGINT NOT NULL,
  PRIMARY KEY(license_id,device),
  CONSTRAINT racklink_device_license FOREIGN KEY(license_id) REFERENCES racklink_licenses(id)
) ENGINE=InnoDB;

-- 短期会话
CREATE TABLE IF NOT EXISTS racklink_sessions (
  sid CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  license_id BIGINT NOT NULL,
  device CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  parent BIGINT NOT NULL,
  issued BIGINT NOT NULL,
  expires BIGINT NOT NULL,
  token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  generation BIGINT NOT NULL,
  revoked INT NOT NULL DEFAULT 0,
  PRIMARY KEY(sid),
  KEY racklink_active(license_id,expires),
  KEY racklink_device_issued(license_id,device,issued),
  KEY racklink_session_expire(expires),
  CONSTRAINT racklink_session_license FOREIGN KEY(license_id) REFERENCES racklink_licenses(id)
) ENGINE=InnoDB;

-- 防重放
CREATE TABLE IF NOT EXISTS racklink_nonces (
  license_id BIGINT NOT NULL,
  nonce CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  expires BIGINT NOT NULL,
  PRIMARY KEY(license_id,nonce),
  KEY racklink_nonce_expire(expires),
  KEY racklink_nonce_license_expire(license_id,expires),
  CONSTRAINT racklink_nonce_license FOREIGN KEY(license_id) REFERENCES racklink_licenses(id)
) ENGINE=InnoDB;

-- 策略
CREATE TABLE IF NOT EXISTS racklink_policy (
  id INT NOT NULL,
  body LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY(id)
) ENGINE=InnoDB;

-- 限流
CREATE TABLE IF NOT EXISTS racklink_rate_limits (
  bucket VARBINARY(512) NOT NULL,
  minute BIGINT NOT NULL,
  count INT NOT NULL,
  PRIMARY KEY(bucket,minute),
  KEY racklink_rate_minute(minute)
) ENGINE=InnoDB;

-- MySQL 5.7不支持ADD COLUMN IF NOT EXISTS；旧表缺origin时只补列，已有记录默认manual。
-- 保留原revoked、expires、max_devices、generation及全部已绑定设备，不推断或重写旧限制。
SET @racklink_origin_sql = IF(
  (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='racklink_licenses' AND column_name='origin') = 0,
  'ALTER TABLE racklink_licenses ADD COLUMN origin VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT ''manual''',
  'SELECT 1'
);
PREPARE racklink_origin_stmt FROM @racklink_origin_sql;
EXECUTE racklink_origin_stmt;
DEALLOCATE PREPARE racklink_origin_stmt;
SET @racklink_origin_sql = NULL;

-- 只为新库补一个占位策略；首次成功启动由EPL生成正式策略，已有策略绝不覆盖。
INSERT IGNORE INTO racklink_policy(id,body) VALUES(1,'{}');

-- 导入工具关闭自动提交时，也确保占位记录提交并释放事务锁。
COMMIT;
