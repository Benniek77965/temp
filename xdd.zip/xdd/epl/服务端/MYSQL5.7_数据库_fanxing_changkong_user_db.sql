/*
SQLyog Trial v13.1.9 (64 bit)
MySQL - 5.7.26-log : Database - fanxing_changkong_user_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`fanxing_changkong_user_db` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `fanxing_changkong_user_db`;

/*Table structure for table `guantai_invite_code` */

DROP TABLE IF EXISTS `guantai_invite_code`;

CREATE TABLE `guantai_invite_code` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL COMMENT 'Crockford Base32,存大写去分隔',
  `days_granted` int(11) NOT NULL DEFAULT '0' COMMENT '注册成功赠送天数(0=不赠)',
  `quota` int(11) NOT NULL DEFAULT '1' COMMENT '可用次数',
  `used_count` int(11) NOT NULL DEFAULT '0',
  `expires_at` datetime DEFAULT NULL COMMENT 'NULL=不过期',
  `disabled` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(100) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台注册邀请码(4.0.0 新建)';

/*Table structure for table `guantai_jf_card` */

DROP TABLE IF EXISTS `guantai_jf_card`;

CREATE TABLE `guantai_jf_card` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `card` varchar(32) NOT NULL COMMENT 'JF+6字母+6数字(排除 I/O/0/1)',
  `plan_code` varchar(16) NOT NULL,
  `batch` varchar(32) NOT NULL DEFAULT '' COMMENT '批次号(发卡/召回按批)',
  `note` varchar(100) NOT NULL DEFAULT '',
  `disabled` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=作废(仅未使用卡可召回)',
  `used_by` bigint(20) NOT NULL DEFAULT '0' COMMENT '0=未使用;否则 tb_user.id',
  `used_name` varchar(50) NOT NULL DEFAULT '',
  `used_at` datetime DEFAULT NULL,
  `created_by` varchar(32) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_card` (`card`),
  KEY `idx_batch` (`batch`),
  KEY `idx_used` (`used_by`,`used_at`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=gbk COMMENT='九法VIP卡密池(4.2.0 新建)';

/*Table structure for table `guantai_jf_grant_log` */

DROP TABLE IF EXISTS `guantai_jf_grant_log`;

CREATE TABLE `guantai_jf_grant_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(50) NOT NULL DEFAULT '',
  `source` varchar(16) NOT NULL COMMENT 'order/card/admin/revoke',
  `ref` varchar(64) NOT NULL DEFAULT '' COMMENT '订单号/卡号',
  `plan_code` varchar(16) NOT NULL DEFAULT '',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `jf_hours` int(11) NOT NULL DEFAULT '0' COMMENT '本次九法VIP增量(负=撤销)',
  `dd_hours` int(11) NOT NULL DEFAULT '0' COMMENT '本次赠送小叮当增量',
  `vip_before` datetime DEFAULT NULL,
  `vip_after` datetime DEFAULT NULL,
  `due_before` datetime DEFAULT NULL,
  `due_after` datetime DEFAULT NULL,
  `operator` varchar(32) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`,`id`),
  KEY `idx_time` (`created_at`),
  KEY `idx_source` (`source`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=gbk COMMENT='九法VIP开通流水(唯一对账口径;4.2.0 新建)';

/*Table structure for table `guantai_jf_order` */

DROP TABLE IF EXISTS `guantai_jf_order`;

CREATE TABLE `guantai_jf_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `gateway_order_no` varchar(64) NOT NULL COMMENT '网关订单号(幂等的物理底线)',
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(50) NOT NULL DEFAULT '',
  `plan_code` varchar(16) NOT NULL COMMENT 'd3/m1/m3',
  `jf_hours` int(11) NOT NULL DEFAULT '0' COMMENT '下单时的档位快照(改价不影响在途单)',
  `dd_hours` int(11) NOT NULL DEFAULT '0' COMMENT '同上:赠送小叮当时长快照',
  `amount` decimal(10,2) NOT NULL COMMENT '网关 price(单一真源,非用户请求金额)',
  `status` varchar(16) NOT NULL DEFAULT 'pending' COMMENT 'pending/paid/expired',
  `credited` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=已开通(幂等哨兵)',
  `is_simulate` tinyint(4) NOT NULL DEFAULT '0',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `create_time` datetime NOT NULL,
  `expire_time` datetime DEFAULT NULL,
  `pay_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order` (`gateway_order_no`),
  KEY `idx_user` (`user_id`,`id`),
  KEY `idx_status_time` (`status`,`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=gbk COMMENT='九法VIP在线充值订单(4.2.0 新建)';

/*Table structure for table `guantai_jf_vip` */

DROP TABLE IF EXISTS `guantai_jf_vip`;

CREATE TABLE `guantai_jf_vip` (
  `user_id` bigint(20) NOT NULL COMMENT '关联 tb_user.id',
  `vip_until` datetime NOT NULL COMMENT '九法VIP到期(一律由库钟判定)',
  `first_at` datetime NOT NULL COMMENT '首次开通时刻(留存分析)',
  `total_hours` int(11) NOT NULL DEFAULT '0' COMMENT '累计开通小时数',
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `idx_until` (`vip_until`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='九法VIP到期(4.2.0 新建)';

/*Table structure for table `guantai_login_log` */

DROP TABLE IF EXISTS `guantai_login_log`;

CREATE TABLE `guantai_login_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT '0',
  `user_name` varchar(50) NOT NULL DEFAULT '',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `ua` varchar(200) NOT NULL DEFAULT '',
  `ok` tinyint(4) NOT NULL DEFAULT '0',
  `reason` varchar(30) NOT NULL DEFAULT '' COMMENT 'ok/bad_credentials/banned/expired/throttled',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_name_time` (`user_name`,`created_at`),
  KEY `idx_time` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=58816 DEFAULT CHARSET=gbk COMMENT='观测台登录审计(登录系统 3.8.0 新建)';

/*Table structure for table `guantai_reg_log` */

DROP TABLE IF EXISTS `guantai_reg_log`;

CREATE TABLE `guantai_reg_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '成功时=新 tb_user.id',
  `user_name` varchar(50) NOT NULL DEFAULT '',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `ua` varchar(200) NOT NULL DEFAULT '',
  `fp` char(16) NOT NULL DEFAULT '' COMMENT '设备指纹摘要(前16hex,可空)',
  `invite_id` bigint(20) NOT NULL DEFAULT '0',
  `ok` tinyint(4) NOT NULL DEFAULT '0',
  `reason` varchar(30) NOT NULL DEFAULT '' COMMENT 'ok/name_taken/pow_failed/…',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ip_time` (`ip`,`created_at`),
  KEY `idx_time` (`created_at`),
  KEY `idx_fp` (`fp`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=gbk COMMENT='观测台注册审计(4.0.0 新建；并入每日清扫)';

/*Table structure for table `guantai_sso_ticket` */

DROP TABLE IF EXISTS `guantai_sso_ticket`;

CREATE TABLE `guantai_sso_ticket` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT '关联 tb_user.id(签发方写)',
  `token_hash` char(64) NOT NULL COMMENT '票据的 SHA-256(票据本身不落库)',
  `created_at` datetime NOT NULL COMMENT '签发时刻(签发方写 NOW())',
  `expires_at` datetime NOT NULL COMMENT '签发方定的失效时刻(建议 NOW()+60s)',
  `used` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=已核销(单次有效)',
  `used_at` datetime DEFAULT NULL,
  `used_ip` varchar(45) NOT NULL DEFAULT '',
  `note` varchar(50) NOT NULL DEFAULT '' COMMENT '签发方备注(审计可读,可空)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_token` (`token_hash`),
  KEY `idx_exp` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=25846 DEFAULT CHARSET=gbk COMMENT='跨项目链接快速登录票据(4.1.0 新建;签发方=同库其它项目)';

/*Table structure for table `guantai_user_block` */

DROP TABLE IF EXISTS `guantai_user_block`;

CREATE TABLE `guantai_user_block` (
  `user_id` bigint(20) NOT NULL COMMENT '关联 tb_user.id',
  `reason` varchar(30) NOT NULL DEFAULT '' COMMENT 'malicious_reg/manual/…',
  `note` varchar(100) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk COMMENT='观测台侧封禁(4.0.0 新建；不触碰 tb_user.is_off)';

/*Table structure for table `guantai_user_session` */

DROP TABLE IF EXISTS `guantai_user_session`;

CREATE TABLE `guantai_user_session` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT '关联 tb_user.id',
  `user_name` varchar(50) NOT NULL DEFAULT '' COMMENT '冗余用户名(审计可读)',
  `token_hash` char(64) NOT NULL COMMENT '会话令牌的 SHA-256(令牌本身不落库)',
  `created_at` datetime NOT NULL,
  `last_seen_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `ip` varchar(45) NOT NULL DEFAULT '',
  `ua` varchar(200) NOT NULL DEFAULT '',
  `revoked` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=已失效',
  `revoke_reason` varchar(20) NOT NULL DEFAULT '' COMMENT 'kicked/logout/evicted/admin',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_token` (`token_hash`),
  KEY `idx_user` (`user_id`,`revoked`)
) ENGINE=InnoDB AUTO_INCREMENT=24644 DEFAULT CHARSET=gbk COMMENT='观测台登录会话(登录系统 3.8.0 新建)';

/*Table structure for table `sys_account` */

DROP TABLE IF EXISTS `sys_account`;

CREATE TABLE `sys_account` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL COMMENT '后台登录账号',
  `password_hash` varchar(100) NOT NULL COMMENT 'bcrypt 哈希(60字符,留余量)',
  `role` varchar(16) NOT NULL COMMENT 'admin=管理员, agent=代理',
  `agent_level` int(11) NOT NULL DEFAULT '0' COMMENT '代理等级 admin=0，代理>=1 数字越小级别越高',
  `balance` decimal(14,2) NOT NULL DEFAULT '0.00' COMMENT '代理余额(元)',
  `parent_id` bigint(20) DEFAULT NULL COMMENT '上级代理ID(多级代理用,可空)',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=启用 0=禁用',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_role` (`role`),
  KEY `idx_parent` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='后台账号表(管理员/代理)';

/*Table structure for table `sys_account_perm` */

DROP TABLE IF EXISTS `sys_account_perm`;

CREATE TABLE `sys_account_perm` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_id` bigint(20) NOT NULL COMMENT '账号 sys_account.id',
  `perm_code` varchar(32) NOT NULL COMMENT '功能代码,如 user_manage',
  `create_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_acc_perm` (`account_id`,`perm_code`),
  KEY `idx_perm_acc` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='账号功能权限表';

/*Table structure for table `sys_account_security` */

DROP TABLE IF EXISTS `sys_account_security`;

CREATE TABLE `sys_account_security` (
  `account_id` bigint(20) NOT NULL COMMENT '账号 sys_account.id(主键)',
  `must_change_pwd` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=下次登录必须强制改密;0=正常',
  `update_time` datetime NOT NULL COMMENT '最近一次写入时间(审计)',
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='账号安全标志位(首次登录强制改密等)';

/*Table structure for table `sys_account_session` */

DROP TABLE IF EXISTS `sys_account_session`;

CREATE TABLE `sys_account_session` (
  `account_id` bigint(20) NOT NULL COMMENT '账号 sys_account.id',
  `session_id` varchar(64) NOT NULL COMMENT '当前唯一有效会话(每次登录重置;互顶判据)',
  `login_time` datetime NOT NULL COMMENT '本次登录时间',
  `login_ip` varchar(64) DEFAULT NULL COMMENT '本次登录来源IP(可空)',
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='后台账号当前在线会话(单设备登录互顶)';

/*Table structure for table `sys_account_setting` */

DROP TABLE IF EXISTS `sys_account_setting`;

CREATE TABLE `sys_account_setting` (
  `account_id` bigint(20) NOT NULL COMMENT '账号 sys_account.id',
  `reset_pwd_daily_limit` int(11) DEFAULT NULL COMMENT '每日重置密码上限(空/<=0=不限)',
  `update_time` datetime NOT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='账号设置(每日改密上限等)';

/*Table structure for table `sys_card_owner` */

DROP TABLE IF EXISTS `sys_card_owner`;

CREATE TABLE `sys_card_owner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `recharge_card` varchar(20) NOT NULL COMMENT '卡号(=tb_user_recharge_card.recharge_card)',
  `owner_account_id` bigint(20) NOT NULL COMMENT '归属代理 sys_account.id',
  `acquire_price` decimal(10,2) NOT NULL COMMENT '购入单价(元)',
  `acquire_time` datetime NOT NULL COMMENT '购入时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_recharge_card` (`recharge_card`),
  KEY `idx_owner` (`owner_account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8362 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='卡密归属表(代理持卡)';

/*Table structure for table `sys_card_pool` */

DROP TABLE IF EXISTS `sys_card_pool`;

CREATE TABLE `sys_card_pool` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `recharge_card` varchar(20) NOT NULL COMMENT '卡号(=tb_user_recharge_card.recharge_card)',
  `card_type` varchar(50) NOT NULL COMMENT '卡类型(=tb_user_recharge_type.card_name)',
  `gen_by_account_id` bigint(20) DEFAULT NULL COMMENT '生成者 sys_account.id',
  `create_time` datetime NOT NULL COMMENT '生成时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pool_card` (`recharge_card`),
  KEY `idx_pool_type` (`card_type`)
) ENGINE=InnoDB AUTO_INCREMENT=8367 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='本系统生成卡登记簿';

/*Table structure for table `sys_card_replacement` */

DROP TABLE IF EXISTS `sys_card_replacement`;

CREATE TABLE `sys_card_replacement` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `biz_line` varchar(16) NOT NULL COMMENT '业务线: fanxing|qiangge',
  `old_card` varchar(50) NOT NULL COMMENT '被换出的旧卡卡号',
  `new_card` varchar(50) NOT NULL COMMENT '换入的新卡卡号',
  `user_name` varchar(50) NOT NULL COMMENT '关联用户账号(tb_user/tb_qiangge_user.user_name)',
  `operator_id` bigint(20) NOT NULL COMMENT '操作者 sys_account.id',
  `operator_name` varchar(64) NOT NULL COMMENT '操作者账号(冗余,便于审计)',
  `create_time` datetime NOT NULL COMMENT '换卡时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_repl_old` (`biz_line`,`old_card`) COMMENT '同业务线下,任一卡作为旧卡仅出现一次',
  UNIQUE KEY `uk_repl_new` (`biz_line`,`new_card`) COMMENT '同业务线下,任一卡作为新卡仅出现一次',
  KEY `idx_repl_user` (`biz_line`,`user_name`),
  KEY `idx_repl_op` (`operator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='卡密更换记录(USED卡3天内可换一次,换过的不可再换)';

/*Table structure for table `sys_level_price` */

DROP TABLE IF EXISTS `sys_level_price`;

CREATE TABLE `sys_level_price` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `agent_level` int(11) NOT NULL COMMENT '代理等级',
  `card_type` varchar(50) NOT NULL COMMENT '卡类型名(=tb_user_recharge_type.card_name)',
  `price` decimal(10,2) NOT NULL COMMENT '该等级购该卡类型单价(元)',
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_level_type` (`agent_level`,`card_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='代理等级价格表';

/*Table structure for table `sys_login_attempt` */

DROP TABLE IF EXISTS `sys_login_attempt`;

CREATE TABLE `sys_login_attempt` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL COMMENT '登录入参用户名(账号可能不存在)',
  `ip` varchar(64) DEFAULT NULL COMMENT '客户端 IP(IPv4/IPv6,可空)',
  `fail_time` datetime NOT NULL COMMENT '失败时刻',
  PRIMARY KEY (`id`),
  KEY `idx_username_time` (`username`,`fail_time`),
  KEY `idx_ip_time` (`ip`,`fail_time`),
  KEY `idx_fail_time` (`fail_time`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录失败计数表(节流数据源)';

/*Table structure for table `sys_op_log` */

DROP TABLE IF EXISTS `sys_op_log`;

CREATE TABLE `sys_op_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_id` bigint(20) DEFAULT NULL COMMENT '操作者 sys_account.id',
  `username` varchar(64) DEFAULT NULL COMMENT '操作者账号',
  `action` varchar(64) NOT NULL COMMENT '动作',
  `detail` varchar(1000) DEFAULT NULL COMMENT '详情(JSON文本)',
  `ip` varchar(64) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_account` (`account_id`),
  KEY `idx_action` (`action`)
) ENGINE=InnoDB AUTO_INCREMENT=1752 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='操作审计日志';

/*Table structure for table `sys_qiangge_card_owner` */

DROP TABLE IF EXISTS `sys_qiangge_card_owner`;

CREATE TABLE `sys_qiangge_card_owner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `recharge_card` varchar(50) NOT NULL COMMENT '卡号(=tb_qiangge_user_recharge_card.recharge_card)',
  `owner_account_id` bigint(20) NOT NULL COMMENT '归属代理 sys_account.id',
  `acquire_price` decimal(10,2) NOT NULL COMMENT '购入单价(元)',
  `acquire_time` datetime NOT NULL COMMENT '购入时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_qg_owner_card` (`recharge_card`),
  KEY `idx_qg_owner` (`owner_account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1902 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='抢歌卡密归属表(代理持卡)';

/*Table structure for table `sys_qiangge_card_pool` */

DROP TABLE IF EXISTS `sys_qiangge_card_pool`;

CREATE TABLE `sys_qiangge_card_pool` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `recharge_card` varchar(50) NOT NULL COMMENT '卡号(=tb_qiangge_user_recharge_card.recharge_card)',
  `card_type` varchar(20) NOT NULL COMMENT '卡类型: 月卡/季卡/半年卡/年卡',
  `gen_by_account_id` bigint(20) DEFAULT NULL COMMENT '生成者 sys_account.id',
  `create_time` datetime NOT NULL COMMENT '生成时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_qg_pool_card` (`recharge_card`),
  KEY `idx_qg_pool_type` (`card_type`)
) ENGINE=InnoDB AUTO_INCREMENT=1908 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='抢歌本系统生成卡登记簿';

/*Table structure for table `sys_qiangge_level_price` */

DROP TABLE IF EXISTS `sys_qiangge_level_price`;

CREATE TABLE `sys_qiangge_level_price` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `agent_level` int(11) NOT NULL COMMENT '代理等级',
  `card_type` varchar(20) NOT NULL COMMENT '卡类型: 月卡/季卡/半年卡/年卡',
  `price` decimal(10,2) NOT NULL COMMENT '该等级购该卡类型单价(元)',
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_qg_level_type` (`agent_level`,`card_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='抢歌代理等级价格表';

/*Table structure for table `sys_recharge_order` */

DROP TABLE IF EXISTS `sys_recharge_order`;

CREATE TABLE `sys_recharge_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `gateway_order_no` varchar(64) NOT NULL COMMENT '支付网关返回的订单号(唯一)',
  `account_id` bigint(20) NOT NULL COMMENT '充值的代理 sys_account.id',
  `username` varchar(64) NOT NULL COMMENT '充值的代理账号(冗余,便于审计)',
  `amount` decimal(14,2) NOT NULL COMMENT '充值金额(元)',
  `status` varchar(16) NOT NULL DEFAULT 'pending' COMMENT 'pending/paid/expired',
  `is_simulate` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=模拟订单(非真实支付)',
  `credited` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否已入账(幂等防御)',
  `create_time` datetime NOT NULL COMMENT '下单时间',
  `expire_time` datetime DEFAULT NULL COMMENT '二维码过期时间',
  `pay_time` datetime DEFAULT NULL COMMENT '到账时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_order_no` (`gateway_order_no`),
  KEY `idx_recharge_account` (`account_id`),
  KEY `idx_recharge_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='在线充值订单表';

/*Table structure for table `sys_rentou_card_catalog` */

DROP TABLE IF EXISTS `sys_rentou_card_catalog`;

CREATE TABLE `sys_rentou_card_catalog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `goods_type_id` int(11) NOT NULL COMMENT '商品类型ID(=sendgift_db.tb_goods_type.goods_type_id;全系统业务键)',
  `create_by` bigint(20) DEFAULT NULL COMMENT '加白名单的管理员 sys_account.id',
  `create_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_rt_cat_gtid` (`goods_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='人头可售白名单(决定代理可买哪些商品类型的充值卡;按goods_type_id)';

/*Table structure for table `sys_rentou_card_owner` */

DROP TABLE IF EXISTS `sys_rentou_card_owner`;

CREATE TABLE `sys_rentou_card_owner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `recharge_card` varchar(20) NOT NULL COMMENT '卡号(=tb_user_recharge_crad.card_number)',
  `owner_account_id` bigint(20) NOT NULL COMMENT '归属代理 sys_account.id',
  `acquire_price` decimal(10,2) NOT NULL COMMENT '购入单卡价(元)=gift_sell_price×recharge_num',
  `acquire_time` datetime NOT NULL COMMENT '购入时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_rt_owner_card` (`recharge_card`),
  KEY `idx_rt_owner` (`owner_account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='人头卡密归属表(代理持卡)';

/*Table structure for table `sys_rentou_card_pool` */

DROP TABLE IF EXISTS `sys_rentou_card_pool`;

CREATE TABLE `sys_rentou_card_pool` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `recharge_card` varchar(20) NOT NULL COMMENT '卡号(=sendgift_db.tb_user_recharge_crad.card_number)',
  `goods_type_id` int(11) NOT NULL COMMENT '商品类型ID(=tb_goods_type.goods_type_id)',
  `recharge_num` int(11) NOT NULL COMMENT '每卡充值数量',
  `gen_by_account_id` bigint(20) DEFAULT NULL COMMENT '生成者 sys_account.id',
  `create_time` datetime NOT NULL COMMENT '生成时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_rt_pool_card` (`recharge_card`),
  KEY `idx_rt_pool_type` (`goods_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='人头本系统生成卡登记簿';

/*Table structure for table `sys_rentou_level_price` */

DROP TABLE IF EXISTS `sys_rentou_level_price`;

CREATE TABLE `sys_rentou_level_price` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `agent_level` int(11) NOT NULL COMMENT '代理等级',
  `goods_type_id` int(11) NOT NULL COMMENT '商品类型ID(=sendgift_db.tb_goods_type.goods_type_id)',
  `price` decimal(10,2) NOT NULL COMMENT '该等级购该商品类型的代理单价(元/个);单卡价=price×recharge_num',
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_rt_level_gtid` (`agent_level`,`goods_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='人头代理等级价格表(可选覆盖;未设回退tb_gift原价)';

/*Table structure for table `sys_tulong_card_owner` */

DROP TABLE IF EXISTS `sys_tulong_card_owner`;

CREATE TABLE `sys_tulong_card_owner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `card` varchar(32) NOT NULL COMMENT '卡号(=guantai_jf_card.card)',
  `owner_account_id` bigint(20) NOT NULL COMMENT '归属代理 sys_account.id',
  `acquire_price` decimal(10,2) NOT NULL COMMENT '购入单卡价(元)',
  `acquire_time` datetime NOT NULL COMMENT '购入时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tl_owner_card` (`card`),
  KEY `idx_tl_owner` (`owner_account_id`,`acquire_time`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='屠龙卡密归属表(代理持卡;屠龙渠道收入账本)';

/*Table structure for table `sys_tulong_card_pool` */

DROP TABLE IF EXISTS `sys_tulong_card_pool`;

CREATE TABLE `sys_tulong_card_pool` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `card` varchar(32) NOT NULL COMMENT '卡号(=guantai_jf_card.card)',
  `spec_id` bigint(20) DEFAULT NULL COMMENT '生成时的规格 sys_tulong_card_spec.id(规格可能被删,故可空)',
  `spec_name` varchar(50) NOT NULL DEFAULT '' COMMENT '生成时的规格名快照',
  `plan_code` varchar(16) NOT NULL COMMENT '写进卡的内联时长码快照(如 @H72D72)',
  `jf_hours` int(11) NOT NULL DEFAULT '0' COMMENT '九法VIP增量快照(小时)',
  `dd_hours` int(11) NOT NULL DEFAULT '0' COMMENT '赠送小叮当增量快照(小时)',
  `batch` varchar(32) NOT NULL DEFAULT '' COMMENT '批次号(与 guantai_jf_card.batch 同值)',
  `gen_by_account_id` bigint(20) DEFAULT NULL COMMENT '生成者 sys_account.id',
  `create_time` datetime NOT NULL COMMENT '生成时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tl_pool_card` (`card`),
  KEY `idx_tl_pool_batch` (`batch`),
  KEY `idx_tl_pool_spec` (`spec_id`),
  KEY `idx_tl_pool_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='屠龙本系统生成卡登记簿';

/*Table structure for table `sys_tulong_card_spec` */

DROP TABLE IF EXISTS `sys_tulong_card_spec`;

CREATE TABLE `sys_tulong_card_spec` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `spec_name` varchar(50) NOT NULL COMMENT '运营可见规格名(如"3天卡"/"月卡")',
  `jf_hours` int(11) NOT NULL COMMENT '九法VIP增量(小时);1~87600',
  `dd_hours` int(11) NOT NULL DEFAULT '0' COMMENT '赠送小叮当增量(小时);0=不赠',
  `sort_order` int(11) NOT NULL DEFAULT '0' COMMENT '展示排序(小在前)',
  `enabled` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=可发卡/可售;0=停售(不影响已发出的卡)',
  `create_by` bigint(20) DEFAULT NULL COMMENT '创建者 sys_account.id',
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tl_spec_name` (`spec_name`),
  KEY `idx_tl_spec_sort` (`sort_order`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='屠龙卡规格(→内联时长码;本系统独有,不镜像项目A档位表)';

/*Table structure for table `sys_tulong_level_price` */

DROP TABLE IF EXISTS `sys_tulong_level_price`;

CREATE TABLE `sys_tulong_level_price` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `agent_level` int(11) NOT NULL COMMENT '代理等级',
  `spec_id` bigint(20) NOT NULL COMMENT '规格 sys_tulong_card_spec.id',
  `price` decimal(10,2) NOT NULL COMMENT '该等级购该规格的单卡价(元)',
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tl_level_spec` (`agent_level`,`spec_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='屠龙代理等级价格表(必须显式配置,不回退)';

/*Table structure for table `tb_qiangge_user` */

DROP TABLE IF EXISTS `tb_qiangge_user`;

CREATE TABLE `tb_qiangge_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '账号',
  `count` int(11) NOT NULL COMMENT '次数',
  `due_time` datetime NOT NULL COMMENT '到期时间',
  `room_id` bigint(20) NOT NULL COMMENT '房间号',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=29717 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='抢歌_账户信息表';

/*Table structure for table `tb_qiangge_user_recharge_card` */

DROP TABLE IF EXISTS `tb_qiangge_user_recharge_card`;

CREATE TABLE `tb_qiangge_user_recharge_card` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `recharge_card` varchar(50) NOT NULL COMMENT '充值卡号',
  `count` int(11) NOT NULL COMMENT '次数',
  `use_user_name` varchar(50) CHARACTER SET gbk COLLATE gbk_bin DEFAULT NULL COMMENT '充值用户',
  `create_time` datetime NOT NULL COMMENT '生成时间',
  `recharge_time` datetime NOT NULL COMMENT '充值时间',
  `recharge_type` varchar(20) NOT NULL COMMENT '充值卡类型',
  `recharge_soft` varchar(50) NOT NULL COMMENT '充值软件',
  PRIMARY KEY (`id`),
  UNIQUE KEY `recharge_card` (`recharge_card`)
) ENGINE=InnoDB AUTO_INCREMENT=192933 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='抢歌_账户充值卡表';

/*Table structure for table `tb_user` */

DROP TABLE IF EXISTS `tb_user`;

CREATE TABLE `tb_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '用户名',
  `pass_word` varchar(50) NOT NULL COMMENT '密码',
  `email_account` varchar(320) NOT NULL COMMENT '邮箱账号',
  `email_bind_time` bigint(20) NOT NULL COMMENT '邮箱绑定时间',
  `register_time` datetime NOT NULL COMMENT '注册时间',
  `due_time` datetime NOT NULL COMMENT '到期时间',
  `is_off` varchar(1) NOT NULL COMMENT '是否封停',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=312820 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='用户信息表';

/*Table structure for table `tb_user_recharge_card` */

DROP TABLE IF EXISTS `tb_user_recharge_card`;

CREATE TABLE `tb_user_recharge_card` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `recharge_card` varchar(20) NOT NULL COMMENT '充值卡号',
  `recharge_card_type` varchar(50) NOT NULL COMMENT '充值卡类型',
  `create_time` datetime NOT NULL COMMENT '生成时间',
  `recharge_time` datetime NOT NULL COMMENT '充值时间',
  `user_name` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '充值用户',
  `recharge_type` varchar(50) NOT NULL COMMENT '充值类型',
  PRIMARY KEY (`id`),
  UNIQUE KEY `recharge_card` (`recharge_card`),
  KEY `user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8594356 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='用户充值卡表';

/*Table structure for table `tb_user_recharge_type` */

DROP TABLE IF EXISTS `tb_user_recharge_type`;

CREATE TABLE `tb_user_recharge_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `card_name` varchar(50) NOT NULL COMMENT '卡类型名',
  `card_prefix` varchar(50) NOT NULL COMMENT '卡前缀',
  `card_length` int(11) NOT NULL COMMENT '卡长度',
  `recharge_length` int(11) NOT NULL COMMENT '充值时长',
  PRIMARY KEY (`id`),
  UNIQUE KEY `card_name` (`card_name`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='用户充值卡类型表';

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
