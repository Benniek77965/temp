/*
SQLyog Trial v13.1.9 (64 bit)
MySQL - 5.7.44-log : Database - email_verify_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`email_verify_db` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `email_verify_db`;

/*Table structure for table `tb_verify_log` */

DROP TABLE IF EXISTS `tb_verify_log`;

CREATE TABLE `tb_verify_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `verify_type_id` int(11) NOT NULL COMMENT '验证类型id',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `email_account` varchar(320) NOT NULL COMMENT '邮箱账号',
  `verify_code` varchar(6) NOT NULL COMMENT '验证码',
  `create_time` bigint(20) NOT NULL COMMENT '获取时间',
  `active_time` bigint(20) NOT NULL COMMENT '激活时间',
  `due_time` bigint(20) NOT NULL COMMENT '到期时间',
  `send_count` int(11) NOT NULL COMMENT '发送次数',
  `verify_count` int(11) NOT NULL COMMENT '验证次数',
  `op_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `is_verify_success` int(1) NOT NULL COMMENT '是否验证成功',
  PRIMARY KEY (`id`),
  KEY `email_account` (`email_account`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `verify_type_id` (`verify_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=394669 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='邮箱验证记录表';

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
