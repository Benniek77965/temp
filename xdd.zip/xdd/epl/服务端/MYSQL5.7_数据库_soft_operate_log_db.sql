/*
SQLyog Trial v13.1.9 (64 bit)
MySQL - 5.7.44-log : Database - soft_operate_log_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`soft_operate_log_db` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `soft_operate_log_db`;

/*Table structure for table `tb_login_abnormal_log` */

DROP TABLE IF EXISTS `tb_login_abnormal_log`;

CREATE TABLE `tb_login_abnormal_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `abnormal_type_id` int(11) NOT NULL COMMENT '异常类型id',
  `add_time` bigint(20) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name_soft_type_id_abnormal_type_id` (`user_name`,`soft_type_id`,`abnormal_type_id`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=106167 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录异常表';

/*Table structure for table `tb_login_log` */

DROP TABLE IF EXISTS `tb_login_log`;

CREATE TABLE `tb_login_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202511` */

DROP TABLE IF EXISTS `tb_login_log_202511`;

CREATE TABLE `tb_login_log_202511` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3890317 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202512` */

DROP TABLE IF EXISTS `tb_login_log_202512`;

CREATE TABLE `tb_login_log_202512` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4136637 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202601` */

DROP TABLE IF EXISTS `tb_login_log_202601`;

CREATE TABLE `tb_login_log_202601` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4079241 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202602` */

DROP TABLE IF EXISTS `tb_login_log_202602`;

CREATE TABLE `tb_login_log_202602` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2721590 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202603` */

DROP TABLE IF EXISTS `tb_login_log_202603`;

CREATE TABLE `tb_login_log_202603` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4024249 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202604` */

DROP TABLE IF EXISTS `tb_login_log_202604`;

CREATE TABLE `tb_login_log_202604` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4203908 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202605` */

DROP TABLE IF EXISTS `tb_login_log_202605`;

CREATE TABLE `tb_login_log_202605` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4451163 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202606` */

DROP TABLE IF EXISTS `tb_login_log_202606`;

CREATE TABLE `tb_login_log_202606` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4516935 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202607` */

DROP TABLE IF EXISTS `tb_login_log_202607`;

CREATE TABLE `tb_login_log_202607` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4828604 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202608` */

DROP TABLE IF EXISTS `tb_login_log_202608`;

CREATE TABLE `tb_login_log_202608` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4711299 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202609` */

DROP TABLE IF EXISTS `tb_login_log_202609`;

CREATE TABLE `tb_login_log_202609` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4572906 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202610` */

DROP TABLE IF EXISTS `tb_login_log_202610`;

CREATE TABLE `tb_login_log_202610` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4540102 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202611` */

DROP TABLE IF EXISTS `tb_login_log_202611`;

CREATE TABLE `tb_login_log_202611` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2409786 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*Table structure for table `tb_login_log_202612` */

DROP TABLE IF EXISTS `tb_login_log_202612`;

CREATE TABLE `tb_login_log_202612` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `soft_type_id` int(11) NOT NULL COMMENT '软件类型id',
  `soft_ver` varchar(50) NOT NULL COMMENT '软件版本',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `login_ip` varchar(128) NOT NULL COMMENT '操作IP',
  `country` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `machine_code` varchar(32) NOT NULL COMMENT '机器码',
  `system_major` int(11) NOT NULL COMMENT '系统主版本',
  `system_minor` int(11) NOT NULL COMMENT '系统次版本',
  `system_build` int(11) NOT NULL COMMENT '系统内部版本号',
  `system_product_type` int(11) NOT NULL COMMENT '系统类型',
  `system_bit` int(11) NOT NULL COMMENT '系统位数',
  `is_has_danger_soft_remain` int(11) NOT NULL COMMENT '是否有危险软件残留',
  `is_has_program_language` int(11) NOT NULL COMMENT '是否有编程语言',
  `is_virtual_machine` int(11) NOT NULL COMMENT '是否为虚拟机',
  `login_time` bigint(20) NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `city` (`city`),
  KEY `user_name` (`user_name`),
  KEY `soft_type_id` (`soft_type_id`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='登录记录表';

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
