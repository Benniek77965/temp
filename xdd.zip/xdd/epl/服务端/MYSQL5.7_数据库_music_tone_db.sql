/*
SQLyog Trial v13.1.9 (64 bit)
MySQL - 5.7.44-log : Database - music_tone_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`music_tone_db` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `music_tone_db`;

/*Table structure for table `tb_music_empty_tone` */

DROP TABLE IF EXISTS `tb_music_empty_tone`;

CREATE TABLE `tb_music_empty_tone` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `songName` varchar(180) NOT NULL COMMENT '歌名',
  `songName_treated` varchar(180) NOT NULL COMMENT '歌名_处理过',
  `songName_treated_no_brackets` varchar(180) NOT NULL COMMENT '歌名_处理过_无括号',
  `singer` varchar(180) NOT NULL COMMENT '歌手',
  `singer_treated` varchar(180) NOT NULL COMMENT '歌手_处理过',
  `tone` varchar(3) NOT NULL COMMENT '音调',
  PRIMARY KEY (`id`),
  UNIQUE KEY `songName_treated_singer` (`songName_treated`,`singer`),
  KEY `songName_treated_no_brackets` (`songName_treated_no_brackets`),
  KEY `songName_treated` (`songName_treated`)
) ENGINE=InnoDB AUTO_INCREMENT=46189 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='电音基调库_空基调';

/*Table structure for table `tb_music_error` */

DROP TABLE IF EXISTS `tb_music_error`;

CREATE TABLE `tb_music_error` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `songName` varchar(180) NOT NULL COMMENT '歌名',
  `songName_treated` varchar(180) NOT NULL COMMENT '歌名_处理过',
  `songName_treated_no_brackets` varchar(180) NOT NULL COMMENT '歌名_处理过_无括号',
  `singer` varchar(180) NOT NULL COMMENT '歌手',
  `singer_treated` varchar(180) NOT NULL COMMENT '歌手_处理过',
  `tone` varchar(3) NOT NULL COMMENT '音调',
  PRIMARY KEY (`id`),
  UNIQUE KEY `songName_treated_singer` (`songName_treated`,`singer`),
  KEY `songName_treated_no_brackets` (`songName_treated_no_brackets`),
  KEY `songName_treated` (`songName_treated`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='电音基调库_错误';

/*Table structure for table `tb_music_tone` */

DROP TABLE IF EXISTS `tb_music_tone`;

CREATE TABLE `tb_music_tone` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `songName` varchar(180) NOT NULL COMMENT '歌名',
  `songName_treated` varchar(180) NOT NULL COMMENT '歌名_处理过',
  `songName_treated_no_brackets` varchar(180) NOT NULL COMMENT '歌名_处理过_无括号',
  `singer` varchar(180) NOT NULL COMMENT '歌手',
  `singer_treated` varchar(180) NOT NULL COMMENT '歌手_处理过',
  `tone` varchar(3) NOT NULL COMMENT '音调',
  PRIMARY KEY (`id`),
  UNIQUE KEY `songName_treated_singer` (`songName_treated`,`singer`),
  KEY `songName_treated_no_brackets` (`songName_treated_no_brackets`),
  KEY `songName_treated` (`songName_treated`)
) ENGINE=InnoDB AUTO_INCREMENT=960857 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='电音基调库';

/*Table structure for table `tb_music_tone_user` */

DROP TABLE IF EXISTS `tb_music_tone_user`;

CREATE TABLE `tb_music_tone_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `songName` varchar(180) NOT NULL COMMENT '歌名',
  `songName_treated` varchar(180) NOT NULL COMMENT '歌名_处理过',
  `songName_treated_no_brackets` varchar(180) NOT NULL COMMENT '歌名_处理过_无括号',
  `singer` varchar(180) NOT NULL COMMENT '歌手',
  `singer_treated` varchar(180) NOT NULL COMMENT '歌手_处理过',
  `tone` varchar(3) NOT NULL COMMENT '音调',
  `soft_type` varchar(1) NOT NULL COMMENT '软件类型',
  `user_name` varchar(50) NOT NULL COMMENT '账号',
  PRIMARY KEY (`id`),
  UNIQUE KEY `songName_treated_singer_soft_type_user_name` (`songName_treated`,`singer`,`soft_type`,`user_name`),
  KEY `user_name` (`user_name`),
  KEY `songName_treated_no_brackets` (`songName_treated_no_brackets`),
  KEY `songName_treated` (`songName_treated`)
) ENGINE=InnoDB AUTO_INCREMENT=14409 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='电音基调库_用户';

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
