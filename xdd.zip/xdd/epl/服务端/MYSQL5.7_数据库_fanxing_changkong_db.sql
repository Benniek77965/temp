/*
SQLyog Trial v13.1.9 (64 bit)
MySQL - 5.7.44-log : Database - fanxing_changkong_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`fanxing_changkong_db` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `fanxing_changkong_db`;

/*Table structure for table `tb_big_data_consume` */

DROP TABLE IF EXISTS `tb_big_data_consume`;

CREATE TABLE `tb_big_data_consume` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `giftId` bigint(20) NOT NULL COMMENT '礼物ID',
  `giftname` varchar(20) NOT NULL COMMENT '礼物名',
  `num` int(11) NOT NULL COMMENT '送礼数量',
  `coin` int(11) NOT NULL COMMENT '总消费',
  `price` int(11) NOT NULL COMMENT '礼物价值星币',
  `sentName` varchar(50) NOT NULL COMMENT '送礼者名字',
  `getName` varchar(50) NOT NULL COMMENT '收礼者名字',
  `sentUserId` bigint(20) NOT NULL COMMENT '送礼者UserId',
  `getUserId` bigint(20) NOT NULL COMMENT '收礼者UserId',
  `roomid` bigint(20) NOT NULL COMMENT '房间号',
  `time` bigint(20) NOT NULL COMMENT '时间戳',
  `is_get_star` varchar(1) NOT NULL COMMENT '是否送给主播',
  PRIMARY KEY (`id`),
  KEY `time` (`time`),
  KEY `getUserId` (`getUserId`),
  KEY `roomid` (`roomid`),
  KEY `sentUserId` (`sentUserId`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='大数据_消费记录表';

/*Table structure for table `tb_big_data_new_game_hunt` */

DROP TABLE IF EXISTS `tb_big_data_new_game_hunt`;

CREATE TABLE `tb_big_data_new_game_hunt` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `giftId` bigint(20) NOT NULL COMMENT '礼物ID',
  `giftName` varchar(20) NOT NULL COMMENT '礼物名',
  `num` int(11) NOT NULL COMMENT '挖宝数量',
  `price` int(11) NOT NULL COMMENT '礼物价值星币',
  `cost` int(11) NOT NULL COMMENT '总价值星币',
  `nickName` varchar(50) NOT NULL COMMENT '挖宝者名字',
  `userId` bigint(20) NOT NULL COMMENT '挖宝者UserId',
  `starName` varchar(50) NOT NULL COMMENT '主播名字',
  `roomId` bigint(20) NOT NULL COMMENT '房间号',
  `time` bigint(20) NOT NULL COMMENT '时间戳',
  `is_big` int(11) NOT NULL COMMENT '是否为大礼',
  PRIMARY KEY (`id`),
  KEY `time` (`time`),
  KEY `userId` (`userId`),
  KEY `roomId` (`roomId`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='大数据_挖宝记录表';

/*Table structure for table `tb_big_data_user_query_count_log` */

DROP TABLE IF EXISTS `tb_big_data_user_query_count_log`;

CREATE TABLE `tb_big_data_user_query_count_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '账号',
  `count` smallint(6) NOT NULL COMMENT '次数',
  `date_time` int(11) NOT NULL COMMENT '日期时间戳',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name_date_time` (`user_name`,`date_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2564934 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='查数据_账户查询次数记录表';

/*Table structure for table `tb_chashuju_user` */

DROP TABLE IF EXISTS `tb_chashuju_user`;

CREATE TABLE `tb_chashuju_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '账号',
  `due_time` datetime NOT NULL COMMENT '到期时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='查数据_账户信息表';

/*Table structure for table `tb_chashuju_user_recharge_card` */

DROP TABLE IF EXISTS `tb_chashuju_user_recharge_card`;

CREATE TABLE `tb_chashuju_user_recharge_card` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `recharge_card` varchar(50) NOT NULL COMMENT '充值卡号',
  `use_user_name` varchar(50) CHARACTER SET gbk COLLATE gbk_bin DEFAULT NULL COMMENT '充值用户',
  `recharge_time` datetime NOT NULL COMMENT '充值时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `recharge_card` (`recharge_card`)
) ENGINE=InnoDB AUTO_INCREMENT=3053 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='查数据_账户充值卡表';

/*Table structure for table `tb_ip_address_blacklist` */

DROP TABLE IF EXISTS `tb_ip_address_blacklist`;

CREATE TABLE `tb_ip_address_blacklist` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(128) NOT NULL COMMENT 'IP地址',
  `time_add` datetime NOT NULL COMMENT '加入时间',
  `time_del` datetime NOT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='IP黑名单表';

/*Table structure for table `tb_ip_address_blacklist_config_rule` */

DROP TABLE IF EXISTS `tb_ip_address_blacklist_config_rule`;

CREATE TABLE `tb_ip_address_blacklist_config_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(30) NOT NULL COMMENT '规则名',
  `sec` int(11) NOT NULL COMMENT '秒',
  `freq` int(11) NOT NULL COMMENT '次数',
  `black_time` int(11) NOT NULL COMMENT '拉黑时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='IP黑名单配置规则表';

/*Table structure for table `tb_ip_address_whitelist` */

DROP TABLE IF EXISTS `tb_ip_address_whitelist`;

CREATE TABLE `tb_ip_address_whitelist` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(128) NOT NULL COMMENT 'IP地址',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='IP白名单表';

/*Table structure for table `tb_short_video_like_alt` */

DROP TABLE IF EXISTS `tb_short_video_like_alt`;

CREATE TABLE `tb_short_video_like_alt` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cookie` varchar(1500) NOT NULL COMMENT 'cookie',
  `kugouId` bigint(20) NOT NULL COMMENT 'kugouId',
  `status` int(1) NOT NULL COMMENT '登录状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `kugouId` (`kugouId`)
) ENGINE=InnoDB AUTO_INCREMENT=2467 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='短视频点赞小号表';

/*Table structure for table `tb_short_video_like_black_list` */

DROP TABLE IF EXISTS `tb_short_video_like_black_list`;

CREATE TABLE `tb_short_video_like_black_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `kugou_id` bigint(20) NOT NULL COMMENT 'kugouId',
  `update_time` bigint(20) NOT NULL COMMENT '拉黑时间',
  `alt_type` int(1) NOT NULL COMMENT '小号类型',
  PRIMARY KEY (`id`),
  UNIQUE KEY `kugou_id` (`kugou_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3438008 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='短视频点赞黑名单列表';

/*Table structure for table `tb_short_video_like_log` */

DROP TABLE IF EXISTS `tb_short_video_like_log`;

CREATE TABLE `tb_short_video_like_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `video_id` varchar(32) NOT NULL COMMENT '短视频ID',
  `kugou_id` bigint(20) NOT NULL COMMENT 'kugouId',
  `task_id` bigint(20) NOT NULL COMMENT '任务ID',
  `type` int(1) NOT NULL COMMENT '类型',
  `alt_type` int(1) NOT NULL COMMENT '小号类型',
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `kugou_id` (`kugou_id`),
  KEY `video_id` (`video_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4703704 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='短视频点赞小号记录表';

/*Table structure for table `tb_short_video_like_pay_log` */

DROP TABLE IF EXISTS `tb_short_video_like_pay_log`;

CREATE TABLE `tb_short_video_like_pay_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `video_id` varchar(32) NOT NULL COMMENT '短视频id',
  `cur_likes` int(11) NOT NULL COMMENT '当前点赞数',
  `cur_views` int(11) NOT NULL COMMENT '当前播放数',
  `pay_type` int(1) NOT NULL COMMENT '消费类型',
  `pay_num` int(11) NOT NULL COMMENT '需要数量',
  `real_num` int(11) NOT NULL COMMENT '需要数量',
  `create_time` bigint(20) NOT NULL COMMENT '创建时间',
  `status` int(1) NOT NULL COMMENT '完成状态',
  `alt_type` int(1) NOT NULL COMMENT '小号类型',
  `room_id` bigint(20) NOT NULL COMMENT '房间号',
  `kugou_id` bigint(20) NOT NULL COMMENT 'kugouId',
  `is_refund` bigint(1) NOT NULL COMMENT 'is_refund',
  PRIMARY KEY (`id`),
  KEY `room_id` (`room_id`),
  KEY `user_name` (`user_name`),
  KEY `kugou_id` (`kugou_id`),
  KEY `video_id` (`video_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1837 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='短视频点赞消费记录表';

/*Table structure for table `tb_star_account_kg_mid` */

DROP TABLE IF EXISTS `tb_star_account_kg_mid`;

CREATE TABLE `tb_star_account_kg_mid` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `kugouId` bigint(20) NOT NULL COMMENT 'kugouId',
  `kg_mid` varchar(32) NOT NULL COMMENT 'kg_mid',
  `update_time` bigint(20) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `kugouId` (`kugouId`)
) ENGINE=InnoDB AUTO_INCREMENT=4455 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='主播账号kg_mid表';

/*Table structure for table `tb_star_songblacklist` */

DROP TABLE IF EXISTS `tb_star_songblacklist`;

CREATE TABLE `tb_star_songblacklist` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `room_id` bigint(20) NOT NULL COMMENT '房间号',
  `user_id` bigint(20) NOT NULL COMMENT '繁星ID',
  `song_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '歌名',
  `add_time` bigint(20) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_song_name` (`user_id`,`song_name`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25320 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='主播歌曲黑名单表';

/*Table structure for table `tb_star_songlist` */

DROP TABLE IF EXISTS `tb_star_songlist`;

CREATE TABLE `tb_star_songlist` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `room_id` bigint(20) NOT NULL COMMENT '房间号',
  `user_id` bigint(20) NOT NULL COMMENT '繁星ID',
  `song_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '歌名',
  `singer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '歌手名',
  `file_hash` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'file_hash',
  `duration` int(11) NOT NULL COMMENT 'duration',
  `add_time` bigint(20) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_file_hash` (`user_id`,`file_hash`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=150585 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='主播歌单表';

/*Table structure for table `tb_star_tuiguang` */

DROP TABLE IF EXISTS `tb_star_tuiguang`;

CREATE TABLE `tb_star_tuiguang` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `time` bigint(20) NOT NULL COMMENT '时间',
  `hour` int(11) NOT NULL COMMENT '某点',
  `nick_name` varchar(50) NOT NULL COMMENT '主播名',
  `room_id` bigint(20) NOT NULL COMMENT '房间号',
  `user_id` bigint(20) NOT NULL COMMENT '主播ID',
  `kugou_id` bigint(20) NOT NULL COMMENT '主播kugouId',
  `pic_url` varchar(200) NOT NULL COMMENT '主播头像地址',
  PRIMARY KEY (`id`),
  KEY `getUserId` (`user_id`),
  KEY `roomid` (`kugou_id`),
  KEY `sentUserId` (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='主播推广表';

/*Table structure for table `tb_star_tuiguang_price` */

DROP TABLE IF EXISTS `tb_star_tuiguang_price`;

CREATE TABLE `tb_star_tuiguang_price` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hour` int(11) NOT NULL COMMENT '某点',
  `price` int(11) NOT NULL COMMENT '价格',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hour` (`hour`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='主播推广价格表';

/*Table structure for table `tb_user` */

DROP TABLE IF EXISTS `tb_user`;

CREATE TABLE `tb_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '账号',
  `login_time` varchar(15) NOT NULL COMMENT '登录时间',
  `password` varchar(50) NOT NULL COMMENT '密码',
  `key` varchar(50) NOT NULL COMMENT '密钥',
  `invite_code` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '邀请码',
  `recharge_status_changkong` varchar(1) NOT NULL COMMENT '场控充值状态',
  `recharge_status_qiangge` varchar(1) NOT NULL COMMENT '抢歌充值状态',
  `mac` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name` (`user_name`),
  KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=286117 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='账户信息表';

/*Table structure for table `tb_user_config` */

DROP TABLE IF EXISTS `tb_user_config`;

CREATE TABLE `tb_user_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '账号',
  `soft_config` mediumtext COMMENT '软件配置',
  `update_time` bigint(20) NOT NULL COMMENT '更新时间',
  `config_data` mediumblob COMMENT '压缩后的配置',
  `algo_type` tinyint(4) DEFAULT '0' COMMENT '0:None, 1:Zstd',
  `raw_size` int(11) DEFAULT '0' COMMENT '解压后的原始字节数',
  `md5` char(32) DEFAULT NULL COMMENT '原始数据MD5',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=68940621 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='用户配置表';

/*Table structure for table `tb_user_config_history_log` */

DROP TABLE IF EXISTS `tb_user_config_history_log`;

CREATE TABLE `tb_user_config_history_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '账号',
  `soft_config` mediumtext COMMENT '软件配置',
  `backup_type` int(11) NOT NULL COMMENT '备份类型',
  `update_time` bigint(20) NOT NULL COMMENT '更新时间',
  `config_data` mediumblob COMMENT '压缩后的配置',
  `algo_type` tinyint(4) DEFAULT '0' COMMENT '0:None, 1:Zstd',
  `raw_size` int(11) DEFAULT '0' COMMENT '原始大小',
  `md5` char(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `update_time` (`update_time`),
  KEY `user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5364087 DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='用户配置历史记录表';

/*Table structure for table `tb_user_password_reset_log` */

DROP TABLE IF EXISTS `tb_user_password_reset_log`;

CREATE TABLE `tb_user_password_reset_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL COMMENT '账号',
  `reset_time` bigint(20) NOT NULL COMMENT '重置时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1679 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='重置密码记录表';

/*Table structure for table `tb_xdd_kugou_account` */

DROP TABLE IF EXISTS `tb_xdd_kugou_account`;

CREATE TABLE `tb_xdd_kugou_account` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cookie` varchar(1500) NOT NULL COMMENT 'cookie',
  `kugouId` bigint(20) NOT NULL COMMENT 'kugouId',
  `userId` bigint(20) NOT NULL COMMENT 'userId',
  `nickName` varchar(50) NOT NULL COMMENT '名字',
  `richLevel` int(11) NOT NULL COMMENT '财富等级',
  `starLevel` int(11) NOT NULL COMMENT '明星等级',
  `roomId` bigint(20) NOT NULL COMMENT '房间号',
  `mobile` bigint(11) NOT NULL COMMENT '手机号',
  `status` int(1) NOT NULL COMMENT '登录状态',
  `update_time` bigint(20) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `kugouId` (`kugouId`),
  KEY `update_time` (`update_time`),
  KEY `userId` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk ROW_FORMAT=DYNAMIC COMMENT='小叮当酷狗帐号表';

/*Table structure for table `tb_yinxiao_feedback` */

DROP TABLE IF EXISTS `tb_yinxiao_feedback`;

CREATE TABLE `tb_yinxiao_feedback` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL COMMENT '账号',
  `content_feedback` text NOT NULL COMMENT '反馈内容',
  `content_reply` text NOT NULL COMMENT '回复内容',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `end_time` datetime NOT NULL COMMENT '回复时间',
  PRIMARY KEY (`id`),
  KEY `user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8947 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='音效_反馈表';

/*Table structure for table `tb_yinxiao_feedback_bak_20261018` */

DROP TABLE IF EXISTS `tb_yinxiao_feedback_bak_20261018`;

CREATE TABLE `tb_yinxiao_feedback_bak_20261018` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL COMMENT '账号',
  `content_feedback` varchar(100) NOT NULL COMMENT '反馈内容',
  `content_reply` varchar(100) NOT NULL COMMENT '回复内容',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `end_time` datetime NOT NULL COMMENT '回复时间',
  PRIMARY KEY (`id`),
  KEY `user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8941 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='音效_反馈表';

/*Table structure for table `tb_yinxiao_diag` */

/* 已经按旧版（没有 cpu 列）建过 tb_yinxiao_diag 的，执行下面这一句补上处理器大类这一列，主键随之加上这一列（原有的行记为 -）：
ALTER TABLE `tb_yinxiao_diag` ADD COLUMN `cpu` varchar(16) CHARACTER SET ascii NOT NULL DEFAULT '-' COMMENT '处理器大类：n 非受影响型号；a-mc… 受影响型号及微码区间；-stk1/-stk0 栈是否被改写' AFTER `build`, DROP PRIMARY KEY, ADD PRIMARY KEY (`kind`,`ver`,`build`,`cpu`,`sig`);
*/

/* 已经建过 tb_yinxiao_diag 的（last_detail 还是 varchar(160)），执行下面这一句把它加长到 4000；处理器分布表 tb_yinxiao_diag_cpu 是新加的，执行本文件里它的 CREATE TABLE IF NOT EXISTS 那一段即可（已有的表不受影响）。两件事都要在更新 TCP_主服务端 之前执行：新版客户端上报的运行时出错、原生崩溃的详情最长 3000 个字符（服务端按 4000 收），没加长时，数据库是严格模式的话这些行写不进库（服务端回 busy，客户端留着下次再发），不是严格模式的话详情会被截成 160 个字符。这一句会重建整张表（varchar 从 255 以内加长到 255 以上不能就地修改），表很小，瞬间完成；主键不变：
ALTER TABLE `tb_yinxiao_diag` MODIFY COLUMN `last_detail` varchar(4000) CHARACTER SET ascii NOT NULL DEFAULT '' COMMENT '最近一条的详情（各键含义见建表语句上方的说明）';
*/

/* tb_yinxiao_diag 的 sig（问题签名）与 last_detail（最近一条的详情）怎么看（客户端 诊断摘要_崩溃签名、诊断摘要_崩溃详情、诊断摘要_运行时详情）。各段只有 ASCII 字母、数字与 . _ : @ + - =，原文里的空格、括号、箭头都成了下划线。

sig：
  crash  c异常码@出错位置[_t=exe+相对地址][_f=exe+相对地址]
         出错位置：exe+相对地址＝在主程序里；DLL文件名+偏移＝在别的模块里（不带路径）；nomod＝不属于任何模块（跳到了坏地址）；null＝地址为 0。
         _t＝出错时栈顶往上第一个主程序内的返回地址，_f＝帧链上第一个主程序内的返回地址：离出错处最近的调用者，有才带。
         出错位置落在公共函数里时（如编译器生成的取文本长度函数，几千处都调用它；它在每次编译出的 exe 里的地址不同，用 依赖库\定位运行时错误 的 --调用 查），靠这两段分出是哪条语句。
         _wer 结尾＝系统直接结束、崩溃过滤器拦不到的崩溃（快速失败、堆损坏、栈哨兵失败等），下次启动时从 Windows「应用程序」日志补记：出错位置是模块文件名+偏移（不在任何模块里时记 nomod，地址只在详情里），没有调用者；详情见下面 src=wer；cpu 列第三项记 stkx（不知道栈有没有被改写）。
  runerr 出错位置的两个编号（0x子程序ID_位置；窗口组件类的错误是 0x窗口ID_组件ID）；库命令内部报的错没有位置，为帧链的前几层。
  pagestall 卡顿前的操作。

last_detail（键=值，以下划线分隔；值里也可能有下划线，以「键=」认段）：
  at    出错地址：exe+0x相对地址，或 DLL文件名+0x偏移，或 0x绝对地址（不属于任何模块）。
  acc   访问违例、页面调入失败：r 读 / w 写 / x 执行，冒号后是被访问的地址。页面调入失败时再带 st＝底层状态码、mem＝出错的那页内存的类别（mapped 映射文件 / image 模块映像 / private 私有内存）。
  ip sp bp  出错现场的 EIP、ESP、EBP。
  src=wer  系统日志补记的崩溃：at 出错模块+偏移，modver、modts＝出错模块的版本与时间戳，os 同下；没有调用栈与寄存器。
  err   运行时出错的错误号。
  msg   运行时出错的提示文字（易语言运行库给出的，GBK 字节的十六进制，最多 240 字节；窗口组件类的错误后面带窗口名、组件名）。还原：
        SELECT sig, cnt, CONVERT(UNHEX(SUBSTRING_INDEX(SUBSTRING_INDEX(last_detail, 'msg=', -1), '_', 1)) USING gbk) AS msg FROM tb_yinxiao_diag WHERE kind = 'runerr' AND last_detail LIKE '%msg=%';
  proc  进程：main 主进程；sub1 音效、sub2 登录、sub3 主播定位、sub4 实时监控、sub5 屠龙解密、sub6 屠龙折线图、sub7 音乐盲盒折线图子进程。  thr  出错的线程：ui 界面线程、wk 工作线程。
  step  启动步骤码（主程序 启动诊断_步骤说明）。  os  系统版本.版本号。  bm  界面库拦截无效表的次数.结构尺寸异常的次数。
  top   栈顶地址（只 crash 有）：出错时栈顶到栈帧之间的代码地址，离出错处由近到远，最多 12 个。出错点在不建栈帧的公共函数里时，调用它的那条语句在这一段。
  fc    帧链：沿栈帧往上各层的返回地址。brk＝帧链在这个地址中断（栈上保存的帧指针被改写）。
  sc    栈内代码地址：栈帧之上扫到的主程序代码地址（含早先调用留下的旧值）。src=sp / src=self＝不是从栈帧、而是从栈顶 / 诊断函数自身的栈帧扫的。
  mr    栈内返回地址（只 crash 有）：主程序以外各模块里的返回地址。
  bmi   界面库（黑月界面类）拦截到无效表时记下的现场（有才带，在最后；详情超过 3000 个字符时截掉的是它的尾部）：依次是哈希表函数名、表的地址、线程号、启动步骤、表头各项、键的地址与键对应的窗口类名或成员名。
  cpu cpuid mc  处理器名称（CPUID）、处理器签名（注册表 Identifier）、当前生效的微码（0x十六进制，读不到为 0）：与客户端信息框「处理器」一行相同，客户端另作三段上报，服务端接在详情最后（新客户端的 runerr、crash 才有）。
  地址后面的 _ID_0x…＝从机器码推断的子程序 ID（推断不出时没有）。exe+0x… 这些地址拿出错那一版加壳前的 exe 用 依赖库\定位运行时错误 查：
        python 定位运行时错误.py --调用 加壳前.exe 存了last_detail的文本文件    或    --调用 加壳前.exe "sig 整串"   （列出每个地址所在的子程序 ID，以及返回地址前一条 call 调用了谁；签名里不带 0x 的地址、详情里的 _ID_0x… 都认得）
        python 定位运行时错误.py 出错那一版的.e 0x子程序ID --txt 同版本导出的文本目录   （查出子程序名）
  不上报的内容：账号、IP、文件路径、电脑名称与 Windows 用户名、进程 ID 与出错线程的 ID（bmi 里有界面库自己记下的线程号）。

旧数据怎么看（本次修改之前的客户端发的，请求类型是「诊断摘要」）：crash 的签名里别的模块一律记成 ext，没有 _t、_f；运行时出错、原生崩溃的 last_detail 是「-」。
  那些版本读处理器签名与微码时，注册表路径写成了双反斜杠，Windows 只在系统缓存里正好有这个键时才读得到：旧数据里的 a-mc0（受影响型号读不到微码），以及受影响型号被归成 n 的，可能有一部分是读取失败造成的，不一定是真实情况。

tb_yinxiao_diag_cpu（处理器分布）：同一个问题（kind, ver, build, sig）按处理器名称与微码分别计数，看一个问题集中在哪些处理器上，例如：
        SELECT cpu_name, mc, SUM(cnt) AS n FROM tb_yinxiao_diag_cpu WHERE kind = 'crash' GROUP BY cpu_name, mc ORDER BY n DESC;                    （全部原生崩溃按处理器）
        SELECT cpu_name, mc, cpu_id, cnt FROM tb_yinxiao_diag_cpu WHERE kind = 'crash' AND build = '编译号' AND sig = '签名' ORDER BY cnt DESC;   （某一个问题按处理器）
*/

CREATE TABLE IF NOT EXISTS `tb_yinxiao_diag` (
  `kind` varchar(16) CHARACTER SET ascii NOT NULL COMMENT '类型：runerr 运行时出错、crash 原生崩溃、pagestall 页面卡顿',
  `ver` varchar(32) CHARACTER SET ascii NOT NULL COMMENT '软件版本',
  `build` varchar(16) CHARACTER SET ascii NOT NULL COMMENT '编译号（exe 的 PE 时间戳）',
  `cpu` varchar(16) CHARACTER SET ascii NOT NULL DEFAULT '-' COMMENT '处理器大类：n 非受影响型号；a-mc… 受影响型号及微码区间；-stk1/-stk0 栈是否被改写',
  `sig` varchar(120) CHARACTER SET ascii NOT NULL COMMENT '问题签名',
  `cnt` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '累计次数',
  `first_time` bigint(20) NOT NULL COMMENT '第一次收到（Unix 秒）',
  `last_time` bigint(20) NOT NULL COMMENT '最近一次收到（Unix 秒）',
  `last_detail` varchar(4000) CHARACTER SET ascii NOT NULL DEFAULT '' COMMENT '最近一条的详情（各键含义见建表语句上方的说明）',
  PRIMARY KEY (`kind`,`ver`,`build`,`cpu`,`sig`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='匿名诊断摘要：按问题归类计数，不存账号与 IP；只留最近 1 个月';

/*Table structure for table `tb_yinxiao_diag_cpu` */

CREATE TABLE IF NOT EXISTS `tb_yinxiao_diag_cpu` (
  `kind` varchar(16) CHARACTER SET ascii NOT NULL COMMENT '类型（同 tb_yinxiao_diag）',
  `ver` varchar(32) CHARACTER SET ascii NOT NULL COMMENT '软件版本',
  `build` varchar(16) CHARACTER SET ascii NOT NULL COMMENT '编译号',
  `sig` varchar(120) CHARACTER SET ascii NOT NULL COMMENT '问题签名（同 tb_yinxiao_diag）',
  `cpu_name` varchar(64) CHARACTER SET ascii NOT NULL COMMENT '处理器名称',
  `mc` varchar(16) CHARACTER SET ascii NOT NULL COMMENT '微码（读不到为 0）',
  `cpu_id` varchar(64) CHARACTER SET ascii NOT NULL DEFAULT '-' COMMENT '处理器签名（最近一次的）',
  `cnt` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '累计次数',
  `first_time` bigint(20) NOT NULL COMMENT '第一次收到（Unix 秒）',
  `last_time` bigint(20) NOT NULL COMMENT '最近一次收到（Unix 秒）',
  PRIMARY KEY (`kind`,`ver`,`build`,`sig`,`cpu_name`,`mc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='诊断摘要的处理器分布：每个问题按处理器名称与微码计数；只留最近 1 个月';

/* 已经建过这三张表的，执行下面三句把注释换成精简版（只改注释的列是就地修改；tb_yinxiao_diag 的 last_detail 若还是 varchar(160) 会顺带加长到 4000）。
tb_yinxiao_api_stat 那一句同时把 type_name 从 varbinary 改成 gbk 文本列：原来在数据库工具里显示成乱码，原有数据就是 GBK 字节、原样当作 gbk 文本不转码，服务端照旧写十六进制字面量、代码不用改；gbk_bin 按字节比较，与 varbinary 一样区分大小写。改列会重建这张表，挑请求少的时候执行：
ALTER TABLE `tb_yinxiao_diag` MODIFY COLUMN `kind` varchar(16) CHARACTER SET ascii NOT NULL COMMENT '类型：runerr 运行时出错、crash 原生崩溃、pagestall 页面卡顿', MODIFY COLUMN `ver` varchar(32) CHARACTER SET ascii NOT NULL COMMENT '软件版本', MODIFY COLUMN `build` varchar(16) CHARACTER SET ascii NOT NULL COMMENT '编译号（exe 的 PE 时间戳）', MODIFY COLUMN `cpu` varchar(16) CHARACTER SET ascii NOT NULL DEFAULT '-' COMMENT '处理器大类：n 非受影响型号；a-mc… 受影响型号及微码区间；-stk1/-stk0 栈是否被改写', MODIFY COLUMN `sig` varchar(120) CHARACTER SET ascii NOT NULL COMMENT '问题签名', MODIFY COLUMN `cnt` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '累计次数', MODIFY COLUMN `first_time` bigint(20) NOT NULL COMMENT '第一次收到（Unix 秒）', MODIFY COLUMN `last_time` bigint(20) NOT NULL COMMENT '最近一次收到（Unix 秒）', MODIFY COLUMN `last_detail` varchar(4000) CHARACTER SET ascii NOT NULL DEFAULT '' COMMENT '最近一条的详情（各键含义见建表语句上方的说明）', COMMENT='匿名诊断摘要：按问题归类计数，不存账号与 IP；只留最近 1 个月';
ALTER TABLE `tb_yinxiao_diag_cpu` MODIFY COLUMN `kind` varchar(16) CHARACTER SET ascii NOT NULL COMMENT '类型（同 tb_yinxiao_diag）', MODIFY COLUMN `ver` varchar(32) CHARACTER SET ascii NOT NULL COMMENT '软件版本', MODIFY COLUMN `build` varchar(16) CHARACTER SET ascii NOT NULL COMMENT '编译号', MODIFY COLUMN `sig` varchar(120) CHARACTER SET ascii NOT NULL COMMENT '问题签名（同 tb_yinxiao_diag）', MODIFY COLUMN `cpu_name` varchar(64) CHARACTER SET ascii NOT NULL COMMENT '处理器名称', MODIFY COLUMN `mc` varchar(16) CHARACTER SET ascii NOT NULL COMMENT '微码（读不到为 0）', MODIFY COLUMN `cpu_id` varchar(64) CHARACTER SET ascii NOT NULL DEFAULT '-' COMMENT '处理器签名（最近一次的）', MODIFY COLUMN `cnt` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '累计次数', MODIFY COLUMN `first_time` bigint(20) NOT NULL COMMENT '第一次收到（Unix 秒）', MODIFY COLUMN `last_time` bigint(20) NOT NULL COMMENT '最近一次收到（Unix 秒）', COMMENT='诊断摘要的处理器分布：每个问题按处理器名称与微码计数；只留最近 1 个月';
ALTER TABLE `tb_yinxiao_api_stat` MODIFY COLUMN `hour_start` bigint(20) NOT NULL COMMENT '小时（Unix 秒，整点）', MODIFY COLUMN `srv` varchar(8) CHARACTER SET ascii NOT NULL COMMENT '服务端：main 主服务端、verify 验证服务端', MODIFY COLUMN `type_name` varchar(64) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '请求类型；(无回复)、(其它) 为汇总', MODIFY COLUMN `cnt` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '请求次数', MODIFY COLUMN `err` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '回复「服务器忙」的次数', MODIFY COLUMN `total_ms` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '处理总毫秒', MODIFY COLUMN `max_ms` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最长一次毫秒', COMMENT='服务端接口统计：每台服务端每小时每种请求一行；只留最近 1 个月';
*/

/*Table structure for table `tb_yinxiao_api_stat` */

CREATE TABLE IF NOT EXISTS `tb_yinxiao_api_stat` (
  `hour_start` bigint(20) NOT NULL COMMENT '小时（Unix 秒，整点）',
  `srv` varchar(8) CHARACTER SET ascii NOT NULL COMMENT '服务端：main 主服务端、verify 验证服务端',
  `type_name` varchar(64) CHARACTER SET gbk COLLATE gbk_bin NOT NULL COMMENT '请求类型；(无回复)、(其它) 为汇总',
  `cnt` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '请求次数',
  `err` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '回复「服务器忙」的次数',
  `total_ms` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '处理总毫秒',
  `max_ms` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最长一次毫秒',
  PRIMARY KEY (`hour_start`,`srv`,`type_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='服务端接口统计：每台服务端每小时每种请求一行；只留最近 1 个月';

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
